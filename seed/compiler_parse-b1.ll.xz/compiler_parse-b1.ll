; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr, i64, ptr }
%olang.home = type { ptr, ptr }
%olang.slotscope = type { %olang.scope, i64, [8 x ptr] }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/parse:Parser" = type { ptr, ptr, ptr, ptr, ptr, i64, i64, i32, i32, i32, i32, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i64, i1, i1, i64, i1, i64, i1, i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, i1, i1 }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i64, i64 }
%"compiler/ast:Branch" = type { %"compiler/source:Span", { i64, ptr }, i64 }
%"compiler/token:Token" = type { i32, i8, i32, i32 }
%"compiler/diagmsg:Msg" = type { i32, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/ast:Catch" = type { %"compiler/source:Span", { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i32, %"compiler/source:Span" }
%"compiler/ast:Compr" = type { ptr, ptr, i32, i32, ptr, ptr, i1, i64 }
%"compiler/parse:NameList" = type { { i64, ptr }, { i64, ptr } }
%"compiler/ast:TypeDecl" = type { i32, { i64, ptr }, i1, ptr, i32, i1, ptr, i32 }
%"compiler/ast:Func" = type { %"compiler/source:Span", ptr, i32, ptr, { i64, ptr }, { i64, ptr }, i1, i1, ptr, i32 }
%"compiler/ast:VarDecl" = type { { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, i1, i1, i1 }
%"compiler/ast:CaseDecl" = type { %"compiler/source:Span", i32, { i64, ptr }, i1, ptr }
%"compiler/ast:Sig" = type { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, i1, i1, i1, { i64, ptr }, i1 }
%"compiler/ast:Param" = type { %"compiler/source:Span", i32, ptr, ptr }
%"compiler/ast:JoinS" = type { i1, { i64, ptr }, { i64, ptr } }
%"compiler/ast:Multi" = type { { i64, ptr }, i1, { i64, ptr }, i1 }
%"compiler/ast:MemberDecl" = type { ptr, i32, { i64, ptr }, ptr }
%"compiler/parse:Oracle" = type { %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/scan:Tokens" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/ast:Promise" = type { %"compiler/source:Span", i32, { i64, ptr } }
%"compiler/ast:TopIf" = type { ptr, ptr, ptr, ptr }
%"compiler/ast:StructBody" = type { { i64, ptr }, ptr, { i64, ptr }, %"compiler/source:Span", { i64, ptr }, { i64, ptr } }
%"compiler/ast:TypeParam" = type { %"compiler/source:Span", i32, ptr, { i64, ptr }, i1, ptr }
%"compiler/source:Source" = type { { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/ast:If" = type { ptr, ptr, ptr }
define dso_local ptr @compiler_2fparse_2eaxisSlice(ptr %v0, ptr %v1, ptr %v2, %"compiler/source:Span" %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i1
  %rv = alloca ptr
  %t26 = alloca { i64, [4 x i64] }, align 8
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  store ptr %t1, ptr %l6, !tbaa !29
  store i1 false, ptr %l7, !tbaa !21
  %t2 = load ptr, ptr %l6, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l6, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 28}
  %t8 = icmp eq i64 %t6, 15
  store i1 %t8, ptr %l7, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l7, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t12, i32 0, i32 1
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l3, !tbaa !29
  %t16 = load ptr, ptr %l2, !tbaa !29
  %t18 = getelementptr { i64, [4 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t18, i32 0, i32 2
  %t20 = load ptr, ptr %t19
  store ptr %t20, ptr %l4, !tbaa !29
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t24 = load ptr, ptr %l3, !tbaa !29
  %t25 = load ptr, ptr %l4, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t26
  %t27 = getelementptr { i64, [4 x i64] }, ptr %t26, i32 0, i32 0
  store i64 14, ptr %t27
  %t29 = insertvalue { %"compiler/source:Span", ptr, ptr, ptr } undef, %"compiler/source:Span" %a0, 0
  %t31 = insertvalue { %"compiler/source:Span", ptr, ptr, ptr } %t29, ptr %a1, 1
  %t33 = insertvalue { %"compiler/source:Span", ptr, ptr, ptr } %t31, ptr %t24, 2
  %t35 = insertvalue { %"compiler/source:Span", ptr, ptr, ptr } %t33, ptr %t25, 3
  %t36 = getelementptr { i64, [4 x i64] }, ptr %t26, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr, ptr } %t35, ptr %t36
  %t37 = load { i64, [4 x i64] }, ptr %t26
  %t39 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 40, i64 8)
  store { i64, [4 x i64] } %t37, ptr %t39
  store ptr %t39, ptr %l5, !tbaa !29
  br label %bb11
bb6:
  br i1 true, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  %t41 = load ptr, ptr %l2, !tbaa !29
  store ptr %t41, ptr %l5, !tbaa !29
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_6a8e8c321ae9efcf_109c18a9288531cb)
  unreachable
bb11:
  %t43 = load ptr, ptr %l5, !tbaa !29
  store ptr %t43, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadjacent(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca i32
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l10 = alloca i1
  %l11 = alloca i1
  %l13 = alloca i32
  %l17 = alloca i1
  %l19 = alloca i32
  %l23 = alloca ptr
  %l25 = alloca ptr
  %l26 = alloca i32
  %l28 = alloca ptr
  %l30 = alloca ptr
  %l31 = alloca i32
  %l35 = alloca i1
  %l36 = alloca i1
  %l39 = alloca i1
  %l45 = alloca ptr
  %l47 = alloca ptr
  %l48 = alloca i32
  %l52 = alloca %"compiler/source:Span"
  %l58 = alloca ptr
  %l59 = alloca i1
  %l73 = alloca ptr
  %l76 = alloca %"compiler/source:Span"
  %rv = alloca { i32, ptr }
  %t118 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t4 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t1, i32 5)
  store i1 %t4, ptr %l10
  br label %bb1
bb1:
  %t5 = load i1, ptr %l10, !tbaa !21
  br i1 %t5, label %bb2, label %bb3
bb2:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elook(ptr %v0, ptr %t6, i64 1)
  store i32 %t8, ptr %l13
  br label %bb4
bb3:
  store i1 false, ptr %l11, !tbaa !21
  br label %bb5
bb4:
  %t9 = load i32, ptr %l13, !range !{i32 0, i32 116}
  %t11 = trunc i64 5 to i32
  %t12 = icmp eq i32 %t9, %t11
  %t14 = xor i1 %t12, true
  store i1 %t14, ptr %l11, !tbaa !21
  br label %bb5
bb5:
  %t16 = load i1, ptr %l11, !tbaa !21
  br i1 %t16, label %bb6, label %bb7
bb6:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elook(ptr %v0, ptr %t17, i64 1)
  store i32 %t19, ptr %l19
  br label %bb8
bb7:
  store i1 false, ptr %l17, !tbaa !21
  br label %bb9
bb8:
  %t20 = load i32, ptr %l19, !range !{i32 0, i32 116}
  %t22 = trunc i64 107 to i32
  %t23 = icmp eq i32 %t20, %t22
  %t25 = xor i1 %t23, true
  store i1 %t25, ptr %l17, !tbaa !21
  br label %bb9
bb9:
  %t27 = load i1, ptr %l17, !tbaa !21
  br i1 %t27, label %bb10, label %bb11
bb10:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2epostfix(ptr %v0, ptr %v1, ptr %t28)
  %t31 = extractvalue { i32, ptr } %t30, 1
  %t32 = extractvalue { i32, ptr } %t30, 0
  store i32 %t32, ptr %l26
  %t33 = icmp ne i32 %t32, 0
  br i1 %t33, label %bb13, label %ok.34, !prof !99
ok.34:
  store ptr %t31, ptr %l25
  br label %bb12
bb11:
  br label %bb15
bb12:
  %t35 = load ptr, ptr %l25, !tbaa !29
  store ptr %t35, ptr %l23, !tbaa !29
  br label %bb14
bb13:
  %t36 = load i32, ptr %l26, !tbaa !23
  %t37 = lshr i32 %t36, 16
  %t38 = and i32 %t36, 65535
  %t39 = icmp eq i32 %t37, 1
  %t40 = select i1 %t39, i32 1, i32 0
  %t41 = icmp eq i32 %t36, 0
  %t42 = shl i32 %t40, 16
  %t43 = or i32 %t42, %t38
  %t44 = select i1 %t41, i32 0, i32 %t43
  %t46 = insertvalue { i32, ptr } zeroinitializer, i32 %t44, 0
  store { i32, ptr } %t46, ptr %rv
  br label %ret
bb14:
  %t47 = load ptr, ptr %l23, !tbaa !29
  %t48 = insertvalue { i32, ptr } zeroinitializer, ptr %t47, 1
  store { i32, ptr } %t48, ptr %rv
  br label %ret
bb15:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eoldPiece(ptr %v0, ptr %v1, ptr %t49)
  %t52 = extractvalue { i32, ptr } %t51, 1
  %t53 = extractvalue { i32, ptr } %t51, 0
  store i32 %t53, ptr %l31
  %t54 = icmp ne i32 %t53, 0
  br i1 %t54, label %bb17, label %ok.55, !prof !99
ok.55:
  store ptr %t52, ptr %l30
  br label %bb16
bb16:
  %t56 = load ptr, ptr %l30, !tbaa !29
  store ptr %t56, ptr %l28, !tbaa !29
  br label %bb18
bb17:
  %t57 = load i32, ptr %l31, !tbaa !23
  %t58 = lshr i32 %t57, 16
  %t59 = and i32 %t57, 65535
  %t60 = icmp eq i32 %t58, 1
  %t61 = select i1 %t60, i32 1, i32 0
  %t62 = icmp eq i32 %t57, 0
  %t63 = shl i32 %t61, 16
  %t64 = or i32 %t63, %t59
  %t65 = select i1 %t62, i32 0, i32 %t64
  %t67 = insertvalue { i32, ptr } zeroinitializer, i32 %t65, 0
  store { i32, ptr } %t67, ptr %rv
  br label %ret
bb18:
  %t68 = load ptr, ptr %l28, !tbaa !29
  store ptr %t68, ptr %l2, !tbaa !29
  br label %bb19
bb19:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t72 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t69, i32 5)
  store i1 %t72, ptr %l35
  br label %bb20
bb20:
  %t73 = load i1, ptr %l35, !tbaa !21
  br i1 %t73, label %bb21, label %bb22
bb21:
  store i1 true, ptr %l36, !tbaa !21
  br label %bb24
bb22:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t77 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t74, i32 107)
  store i1 %t77, ptr %l39
  br label %bb23
bb23:
  %t78 = load i1, ptr %l39, !tbaa !21
  store i1 %t78, ptr %l36, !tbaa !21
  br label %bb24
bb24:
  %t79 = load i1, ptr %l36, !tbaa !21
  %t80 = xor i1 %t79, true
  br i1 %t80, label %bb25, label %bb26
bb25:
  br label %bb34
bb26:
  br label %bb27
bb27:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/parse:Parser", ptr %t82, i32 0, i32 52
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"compiler/parse:Parser", ptr %t85, i32 0, i32 10
  %t88 = load i32, ptr %t87, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI32_3e_2ePush_3cI32_3e(ptr %v0, ptr %t84, i32 %t88)
  br label %bb28
bb28:
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t93 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eoldPiece(ptr %v0, ptr %v1, ptr %t91)
  %t94 = extractvalue { i32, ptr } %t93, 1
  %t95 = extractvalue { i32, ptr } %t93, 0
  store i32 %t95, ptr %l48
  %t96 = icmp ne i32 %t95, 0
  br i1 %t96, label %bb30, label %ok.97, !prof !99
ok.97:
  store ptr %t94, ptr %l47
  br label %bb29
bb29:
  %t98 = load ptr, ptr %l47, !tbaa !29
  store ptr %t98, ptr %l45, !tbaa !29
  br label %bb31
bb30:
  %t99 = load i32, ptr %l48, !tbaa !23
  %t100 = lshr i32 %t99, 16
  %t101 = and i32 %t99, 65535
  %t102 = icmp eq i32 %t100, 1
  %t103 = select i1 %t102, i32 1, i32 0
  %t104 = icmp eq i32 %t99, 0
  %t105 = shl i32 %t103, 16
  %t106 = or i32 %t105, %t101
  %t107 = select i1 %t104, i32 0, i32 %t106
  %t109 = insertvalue { i32, ptr } zeroinitializer, i32 %t107, 0
  store { i32, ptr } %t109, ptr %rv
  br label %ret
bb31:
  %t110 = load ptr, ptr %l45, !tbaa !29
  store ptr %t110, ptr %l3, !tbaa !29
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t112 = load i32, ptr %l1, !tbaa !23
  %t115 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t111, i32 %t112)
  store %"compiler/source:Span" %t115, ptr %l52
  br label %bb32
bb32:
  %t116 = load ptr, ptr %l2, !tbaa !29
  %t117 = load ptr, ptr %l3, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t118
  %t119 = getelementptr { i64, [4 x i64] }, ptr %t118, i32 0, i32 0
  store i64 5, ptr %t119
  %t120 = load %"compiler/source:Span", ptr %l52
  %t121 = insertvalue { %"compiler/source:Span", i32, ptr, ptr } undef, %"compiler/source:Span" %t120, 0
  %t123 = insertvalue { %"compiler/source:Span", i32, ptr, ptr } %t121, i32 68, 1
  %t125 = insertvalue { %"compiler/source:Span", i32, ptr, ptr } %t123, ptr %t116, 2
  %t127 = insertvalue { %"compiler/source:Span", i32, ptr, ptr } %t125, ptr %t117, 3
  %t128 = getelementptr { i64, [4 x i64] }, ptr %t118, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr, ptr } %t127, ptr %t128
  %t129 = load { i64, [4 x i64] }, ptr %t118
  %t131 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 40, i64 8)
  store { i64, [4 x i64] } %t129, ptr %t131
  store ptr %t131, ptr %l2, !tbaa !29
  br label %bb33
bb33:
  br label %bb19
bb34:
  %t133 = load ptr, ptr %l2, !tbaa !29
  store ptr %t133, ptr %l58, !tbaa !29
  store i1 false, ptr %l59, !tbaa !21
  %t134 = load ptr, ptr %l58, !tbaa !29
  %t135 = icmp ne ptr %t134, null
  br i1 %t135, label %bb35, label %bb36
bb35:
  %t137 = load ptr, ptr %l58, !tbaa !29
  %t138 = load i64, ptr %t137, !range !{i64 0, i64 28}
  %t140 = icmp eq i64 %t138, 5
  store i1 %t140, ptr %l59, !tbaa !21
  br label %bb36
bb36:
  %t141 = load i1, ptr %l59, !tbaa !21
  %t142 = xor i1 %t141, true
  br i1 %t142, label %bb37, label %bb38
bb37:
  %t144 = load ptr, ptr %l2, !tbaa !29
  %t146 = insertvalue { i32, ptr } zeroinitializer, ptr %t144, 1
  store { i32, ptr } %t146, ptr %rv
  br label %ret
bb38:
  br label %bb39
bb39:
  %t147 = load ptr, ptr %l2, !tbaa !29
  %t149 = getelementptr { i64, [4 x i64] }, ptr %t147, i32 0, i32 1
  %t150 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t149, i32 0, i32 0
  %t151 = load %"compiler/source:Span", ptr %t150
  store %"compiler/source:Span" %t151, ptr %l4
  %t153 = load ptr, ptr %l2, !tbaa !29
  %t155 = getelementptr { i64, [4 x i64] }, ptr %t153, i32 0, i32 1
  %t156 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t155, i32 0, i32 1
  %t157 = load i32, ptr %t156, !range !{i32 0, i32 116}
  store i32 %t157, ptr %l5
  %t159 = load ptr, ptr %l2, !tbaa !29
  %t161 = getelementptr { i64, [4 x i64] }, ptr %t159, i32 0, i32 1
  %t162 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t161, i32 0, i32 2
  %t163 = load ptr, ptr %t162
  store ptr %t163, ptr %l6, !tbaa !29
  %t165 = load ptr, ptr %l2, !tbaa !29
  %t167 = getelementptr { i64, [4 x i64] }, ptr %t165, i32 0, i32 1
  %t168 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t167, i32 0, i32 3
  %t169 = load ptr, ptr %t168
  store ptr %t169, ptr %l7, !tbaa !29
  %t171 = load ptr, ptr %l0, !tbaa !29
  %t173 = getelementptr %"compiler/parse:Parser", ptr %t171, i32 0, i32 51
  store ptr %t173, ptr %l73, !tbaa !29
  %t174 = load ptr, ptr %l0, !tbaa !29
  %t175 = load i32, ptr %l1, !tbaa !23
  %t178 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t174, i32 %t175)
  store %"compiler/source:Span" %t178, ptr %l76
  br label %bb40
bb40:
  %t179 = load ptr, ptr %l73, !tbaa !29
  %t180 = load %"compiler/source:Span", ptr %l76
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ePush_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t179, %"compiler/source:Span" %t180)
  br label %bb41
bb41:
  %t181 = load ptr, ptr %l2, !tbaa !29
  %t183 = insertvalue { i32, ptr } zeroinitializer, ptr %t181, 1
  store { i32, ptr } %t183, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2earrayLit(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca i1
  %l4 = alloca i1
  %l5 = alloca i1
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca i1
  %l9 = alloca ptr
  %l10 = alloca i32
  %l13 = alloca i32
  %l14 = alloca i32
  %l19 = alloca ptr
  %l31 = alloca i64
  %l34 = alloca i1
  %l38 = alloca i1
  %l39 = alloca i1
  %l42 = alloca i1
  %l43 = alloca ptr
  %l45 = alloca { i64, ptr }
  %l47 = alloca i32
  %l49 = alloca ptr
  %l59 = alloca ptr
  %l61 = alloca ptr
  %l62 = alloca i32
  %l64 = alloca ptr
  %l75 = alloca i1
  %l76 = alloca ptr
  %l83 = alloca ptr
  %l84 = alloca i32
  %l86 = alloca ptr
  %l96 = alloca ptr
  %l108 = alloca i1
  %l110 = alloca ptr
  %l113 = alloca ptr
  %l114 = alloca i32
  %l116 = alloca ptr
  %l127 = alloca i1
  %l129 = alloca i1
  %l130 = alloca ptr
  %l137 = alloca ptr
  %l138 = alloca i32
  %l140 = alloca ptr
  %l150 = alloca ptr
  %l163 = alloca i1
  %l166 = alloca i1
  %l167 = alloca i32
  %l169 = alloca ptr
  %l180 = alloca ptr
  %l182 = alloca ptr
  %l183 = alloca i32
  %l185 = alloca ptr
  %l196 = alloca ptr
  %l199 = alloca ptr
  %l200 = alloca i32
  %l202 = alloca ptr
  %l217 = alloca i1
  %l222 = alloca ptr
  %l224 = alloca { i64, ptr }
  %l226 = alloca i32
  %l228 = alloca ptr
  %l239 = alloca i32
  %l242 = alloca %"compiler/source:Span"
  %l244 = alloca ptr
  %l248 = alloca { i64, ptr }
  %l251 = alloca ptr
  %s2 = alloca %olang.scope
  %s28 = alloca %olang.scope
  %rv = alloca { i32, ptr }
  %t621 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t4 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %t1, i32 112)
  %t5 = extractvalue { i32, i32 } %t4, 1
  %t6 = extractvalue { i32, i32 } %t4, 0
  store i32 %t6, ptr %l14
  %t7 = icmp ne i32 %t6, 0
  br i1 %t7, label %bb2, label %ok.8, !prof !99
ok.8:
  store i32 %t5, ptr %l13
  br label %bb1
bb1:
  %t9 = load i32, ptr %l13, !tbaa !23
  store i32 %t9, ptr %l10, !tbaa !23
  br label %bb3
bb2:
  %t10 = load i32, ptr %l14, !tbaa !23
  %t11 = lshr i32 %t10, 16
  %t12 = and i32 %t10, 65535
  %t13 = icmp eq i32 %t11, 1
  %t14 = select i1 %t13, i32 1, i32 0
  %t15 = icmp eq i32 %t10, 0
  %t16 = shl i32 %t14, 16
  %t17 = or i32 %t16, %t12
  %t18 = select i1 %t15, i32 0, i32 %t17
  %t20 = insertvalue { i32, ptr } zeroinitializer, i32 %t18, 0
  store { i32, ptr } %t20, ptr %rv
  br label %ret
bb3:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/parse:Parser", ptr %t21, i32 0, i32 11
  %t24 = load i1, ptr %t23, !tbaa !21
  store i1 %t24, ptr %l3, !tbaa !21
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/parse:Parser", ptr %t26, i32 0, i32 11
  store i1 false, ptr %t28, !tbaa !21
  %t29 = load ptr, ptr %l0, !tbaa !29
  store ptr %t29, ptr %l19, !tbaa !29
  %t30 = load ptr, ptr %l19, !tbaa !29
  %t31 = getelementptr %"compiler/parse:Parser", ptr %t30, i32 0, i32 21
  %t32 = load i64, ptr %t31, !tbaa !24
  %t35 = add i64 %t32, 1
  %t37 = load ptr, ptr %l19, !tbaa !29
  %t38 = getelementptr %"compiler/parse:Parser", ptr %t37, i32 0, i32 21
  store i64 %t35, ptr %t38, !tbaa !24
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/parse:Parser", ptr %t39, i32 0, i32 22
  %t42 = load i1, ptr %t41, !tbaa !21
  store i1 %t42, ptr %l4, !tbaa !21
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/parse:Parser", ptr %t44, i32 0, i32 23
  %t47 = load i1, ptr %t46, !tbaa !21
  store i1 %t47, ptr %l5, !tbaa !21
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/parse:Parser", ptr %t49, i32 0, i32 22
  store i1 false, ptr %t51, !tbaa !21
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/parse:Parser", ptr %t52, i32 0, i32 23
  store i1 true, ptr %t54, !tbaa !21
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/parse:Parser", ptr %t55, i32 0, i32 34
  %t59 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2eLen_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %t57)
  store i64 %t59, ptr %l31
  br label %bb4
bb4:
  %t60 = load i64, ptr %l31, !tbaa !24
  store i64 %t60, ptr %l6, !tbaa !24
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t64 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t61, i32 113)
  store i1 %t64, ptr %l34
  br label %bb5
bb5:
  %t65 = load i1, ptr %l34, !tbaa !21
  %t66 = xor i1 %t65, true
  br i1 %t66, label %bb6, label %bb7
bb6:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t71 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t68, i32 111)
  store i1 %t71, ptr %l38
  br label %bb8
bb7:
  br label %bb67
bb8:
  %t72 = load i1, ptr %l38, !tbaa !21
  br i1 %t72, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l39, !tbaa !21
  br label %bb12
bb10:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t76 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t73, i32 115)
  store i1 %t76, ptr %l42
  br label %bb11
bb11:
  %t77 = load i1, ptr %l42, !tbaa !21
  store i1 %t77, ptr %l39, !tbaa !21
  br label %bb12
bb12:
  %t78 = load i1, ptr %l39, !tbaa !21
  br i1 %t78, label %bb13, label %bb14
bb13:
  store %olang.scope zeroinitializer, ptr %s2
  %t79 = load ptr, ptr %l0, !tbaa !29
  store ptr %t79, ptr %l43, !tbaa !29
  %t81 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eDescribe(ptr %s2, i32 113)
  store { i64, ptr } %t81, ptr %l45
  br label %bb15
bb14:
  br label %bb19
bb15:
  %t82 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t83 = load ptr, ptr %l43, !tbaa !29
  %t85 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2efail(ptr %v0, ptr %s2, ptr %t83, { i64, ptr } %t82)
  store i32 %t85, ptr %l47
  %t86 = icmp ne i32 %t85, 0
  br i1 %t86, label %bb17, label %ok.87, !prof !99
ok.87:
  br label %bb16
bb16:
  br label %bb18
bb17:
  %t88 = load i32, ptr %l47, !tbaa !23
  %t89 = lshr i32 %t88, 16
  %t90 = and i32 %t88, 65535
  %t91 = icmp eq i32 %t89, 1
  %t92 = select i1 %t91, i32 1, i32 0
  %t93 = icmp eq i32 %t88, 0
  %t94 = shl i32 %t92, 16
  %t95 = or i32 %t94, %t90
  %t96 = select i1 %t93, i32 0, i32 %t95
  call void @__olang_scope_close(ptr %s2)
  %t97 = load ptr, ptr %l0, !tbaa !29
  store ptr %t97, ptr %l49, !tbaa !29
  %t98 = load ptr, ptr %l49, !tbaa !29
  %t99 = getelementptr %"compiler/parse:Parser", ptr %t98, i32 0, i32 21
  %t100 = load i64, ptr %t99, !tbaa !24
  %t103 = sub i64 %t100, 1
  %t105 = load ptr, ptr %l49, !tbaa !29
  %t106 = getelementptr %"compiler/parse:Parser", ptr %t105, i32 0, i32 21
  store i64 %t103, ptr %t106, !tbaa !24
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t108 = load i1, ptr %l3, !tbaa !21
  %t111 = getelementptr %"compiler/parse:Parser", ptr %t107, i32 0, i32 11
  store i1 %t108, ptr %t111, !tbaa !21
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t113 = load i1, ptr %l4, !tbaa !21
  %t116 = getelementptr %"compiler/parse:Parser", ptr %t112, i32 0, i32 22
  store i1 %t113, ptr %t116, !tbaa !21
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t118 = load i1, ptr %l5, !tbaa !21
  %t121 = getelementptr %"compiler/parse:Parser", ptr %t117, i32 0, i32 23
  store i1 %t118, ptr %t121, !tbaa !21
  %t123 = insertvalue { i32, ptr } zeroinitializer, i32 %t96, 0
  store { i32, ptr } %t123, ptr %rv
  br label %ret
bb18:
  call void @__olang_scope_close(ptr %s2)
  br label %bb19
bb19:
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t126 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eelem(ptr %v0, ptr %v2, ptr %t124)
  %t127 = extractvalue { i32, ptr } %t126, 1
  %t128 = extractvalue { i32, ptr } %t126, 0
  store i32 %t128, ptr %l62
  %t129 = icmp ne i32 %t128, 0
  br i1 %t129, label %bb21, label %ok.130, !prof !99
ok.130:
  store ptr %t127, ptr %l61
  br label %bb20
bb20:
  %t131 = load ptr, ptr %l61, !tbaa !29
  store ptr %t131, ptr %l59, !tbaa !29
  br label %bb22
bb21:
  %t132 = load i32, ptr %l62, !tbaa !23
  %t133 = lshr i32 %t132, 16
  %t134 = and i32 %t132, 65535
  %t135 = icmp eq i32 %t133, 1
  %t136 = select i1 %t135, i32 1, i32 0
  %t137 = icmp eq i32 %t132, 0
  %t138 = shl i32 %t136, 16
  %t139 = or i32 %t138, %t134
  %t140 = select i1 %t137, i32 0, i32 %t139
  %t141 = load ptr, ptr %l0, !tbaa !29
  store ptr %t141, ptr %l64, !tbaa !29
  %t142 = load ptr, ptr %l64, !tbaa !29
  %t143 = getelementptr %"compiler/parse:Parser", ptr %t142, i32 0, i32 21
  %t144 = load i64, ptr %t143, !tbaa !24
  %t147 = sub i64 %t144, 1
  %t149 = load ptr, ptr %l64, !tbaa !29
  %t150 = getelementptr %"compiler/parse:Parser", ptr %t149, i32 0, i32 21
  store i64 %t147, ptr %t150, !tbaa !24
  %t151 = load ptr, ptr %l0, !tbaa !29
  %t152 = load i1, ptr %l3, !tbaa !21
  %t155 = getelementptr %"compiler/parse:Parser", ptr %t151, i32 0, i32 11
  store i1 %t152, ptr %t155, !tbaa !21
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t157 = load i1, ptr %l4, !tbaa !21
  %t160 = getelementptr %"compiler/parse:Parser", ptr %t156, i32 0, i32 22
  store i1 %t157, ptr %t160, !tbaa !21
  %t161 = load ptr, ptr %l0, !tbaa !29
  %t162 = load i1, ptr %l5, !tbaa !21
  %t165 = getelementptr %"compiler/parse:Parser", ptr %t161, i32 0, i32 23
  store i1 %t162, ptr %t165, !tbaa !21
  %t167 = insertvalue { i32, ptr } zeroinitializer, i32 %t140, 0
  store { i32, ptr } %t167, ptr %rv
  br label %ret
bb22:
  %t168 = load ptr, ptr %l59, !tbaa !29
  store ptr %t168, ptr %l7, !tbaa !29
  %t169 = load ptr, ptr %l0, !tbaa !29
  %t171 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ecomprehends(ptr %v0, ptr %t169)
  store i1 %t171, ptr %l75
  br label %bb23
bb23:
  %t172 = load i1, ptr %l75, !tbaa !21
  br i1 %t172, label %bb24, label %bb25
bb24:
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t174 = load i32, ptr %l1, !tbaa !23
  %t175 = load ptr, ptr %l2, !tbaa !29
  %t177 = load ptr, ptr %l7, !tbaa !29
  %t183 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ecomprehension(ptr %v0, ptr %v1, ptr %v2, ptr %v2, ptr %t173, i32 %t174, ptr %t175, ptr %t177, i32 113)
  %t184 = extractvalue { i32, ptr } %t183, 1
  %t185 = extractvalue { i32, ptr } %t183, 0
  store i32 %t185, ptr %l84
  %t186 = icmp ne i32 %t185, 0
  br i1 %t186, label %bb27, label %ok.187, !prof !99
ok.187:
  store ptr %t184, ptr %l83
  br label %bb26
bb25:
  br label %bb29
bb26:
  %t188 = load ptr, ptr %l83, !tbaa !29
  store ptr %t188, ptr %l76, !tbaa !29
  br label %bb28
bb27:
  %t189 = load i32, ptr %l84, !tbaa !23
  %t190 = lshr i32 %t189, 16
  %t191 = and i32 %t189, 65535
  %t192 = icmp eq i32 %t190, 1
  %t193 = select i1 %t192, i32 1, i32 0
  %t194 = icmp eq i32 %t189, 0
  %t195 = shl i32 %t193, 16
  %t196 = or i32 %t195, %t191
  %t197 = select i1 %t194, i32 0, i32 %t196
  %t198 = load ptr, ptr %l0, !tbaa !29
  store ptr %t198, ptr %l86, !tbaa !29
  %t199 = load ptr, ptr %l86, !tbaa !29
  %t200 = getelementptr %"compiler/parse:Parser", ptr %t199, i32 0, i32 21
  %t201 = load i64, ptr %t200, !tbaa !24
  %t204 = sub i64 %t201, 1
  %t206 = load ptr, ptr %l86, !tbaa !29
  %t207 = getelementptr %"compiler/parse:Parser", ptr %t206, i32 0, i32 21
  store i64 %t204, ptr %t207, !tbaa !24
  %t208 = load ptr, ptr %l0, !tbaa !29
  %t209 = load i1, ptr %l3, !tbaa !21
  %t212 = getelementptr %"compiler/parse:Parser", ptr %t208, i32 0, i32 11
  store i1 %t209, ptr %t212, !tbaa !21
  %t213 = load ptr, ptr %l0, !tbaa !29
  %t214 = load i1, ptr %l4, !tbaa !21
  %t217 = getelementptr %"compiler/parse:Parser", ptr %t213, i32 0, i32 22
  store i1 %t214, ptr %t217, !tbaa !21
  %t218 = load ptr, ptr %l0, !tbaa !29
  %t219 = load i1, ptr %l5, !tbaa !21
  %t222 = getelementptr %"compiler/parse:Parser", ptr %t218, i32 0, i32 23
  store i1 %t219, ptr %t222, !tbaa !21
  %t224 = insertvalue { i32, ptr } zeroinitializer, i32 %t197, 0
  store { i32, ptr } %t224, ptr %rv
  br label %ret
bb28:
  %t225 = load ptr, ptr %l0, !tbaa !29
  store ptr %t225, ptr %l96, !tbaa !29
  %t226 = load ptr, ptr %l96, !tbaa !29
  %t227 = getelementptr %"compiler/parse:Parser", ptr %t226, i32 0, i32 21
  %t228 = load i64, ptr %t227, !tbaa !24
  %t231 = sub i64 %t228, 1
  %t233 = load ptr, ptr %l96, !tbaa !29
  %t234 = getelementptr %"compiler/parse:Parser", ptr %t233, i32 0, i32 21
  store i64 %t231, ptr %t234, !tbaa !24
  %t235 = load ptr, ptr %l0, !tbaa !29
  %t236 = load i1, ptr %l3, !tbaa !21
  %t239 = getelementptr %"compiler/parse:Parser", ptr %t235, i32 0, i32 11
  store i1 %t236, ptr %t239, !tbaa !21
  %t240 = load ptr, ptr %l0, !tbaa !29
  %t241 = load i1, ptr %l4, !tbaa !21
  %t244 = getelementptr %"compiler/parse:Parser", ptr %t240, i32 0, i32 22
  store i1 %t241, ptr %t244, !tbaa !21
  %t245 = load ptr, ptr %l0, !tbaa !29
  %t246 = load i1, ptr %l5, !tbaa !21
  %t249 = getelementptr %"compiler/parse:Parser", ptr %t245, i32 0, i32 23
  store i1 %t246, ptr %t249, !tbaa !21
  %t250 = load ptr, ptr %l76, !tbaa !29
  %t251 = insertvalue { i32, ptr } zeroinitializer, ptr %t250, 1
  store { i32, ptr } %t251, ptr %rv
  br label %ret
bb29:
  %t252 = load ptr, ptr %l0, !tbaa !29
  %t255 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t252, i32 79)
  store i1 %t255, ptr %l108
  br label %bb30
bb30:
  %t256 = load i1, ptr %l108, !tbaa !21
  store i1 %t256, ptr %l8, !tbaa !21
  %t257 = load i1, ptr %l8, !tbaa !21
  br i1 %t257, label %bb31, label %bb32
bb31:
  %t259 = load ptr, ptr %l0, !tbaa !29
  %t260 = load ptr, ptr %l7, !tbaa !29
  %t263 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eentry(ptr %v0, ptr %v2, ptr %v2, ptr %t259, ptr %t260)
  %t264 = extractvalue { i32, ptr } %t263, 1
  %t265 = extractvalue { i32, ptr } %t263, 0
  store i32 %t265, ptr %l114
  %t266 = icmp ne i32 %t265, 0
  br i1 %t266, label %bb34, label %ok.267, !prof !99
ok.267:
  store ptr %t264, ptr %l113
  br label %bb33
bb32:
  br label %bb36
bb33:
  %t268 = load ptr, ptr %l113, !tbaa !29
  store ptr %t268, ptr %l110, !tbaa !29
  br label %bb35
bb34:
  %t269 = load i32, ptr %l114, !tbaa !23
  %t270 = lshr i32 %t269, 16
  %t271 = and i32 %t269, 65535
  %t272 = icmp eq i32 %t270, 1
  %t273 = select i1 %t272, i32 1, i32 0
  %t274 = icmp eq i32 %t269, 0
  %t275 = shl i32 %t273, 16
  %t276 = or i32 %t275, %t271
  %t277 = select i1 %t274, i32 0, i32 %t276
  %t278 = load ptr, ptr %l0, !tbaa !29
  store ptr %t278, ptr %l116, !tbaa !29
  %t279 = load ptr, ptr %l116, !tbaa !29
  %t280 = getelementptr %"compiler/parse:Parser", ptr %t279, i32 0, i32 21
  %t281 = load i64, ptr %t280, !tbaa !24
  %t284 = sub i64 %t281, 1
  %t286 = load ptr, ptr %l116, !tbaa !29
  %t287 = getelementptr %"compiler/parse:Parser", ptr %t286, i32 0, i32 21
  store i64 %t284, ptr %t287, !tbaa !24
  %t288 = load ptr, ptr %l0, !tbaa !29
  %t289 = load i1, ptr %l3, !tbaa !21
  %t292 = getelementptr %"compiler/parse:Parser", ptr %t288, i32 0, i32 11
  store i1 %t289, ptr %t292, !tbaa !21
  %t293 = load ptr, ptr %l0, !tbaa !29
  %t294 = load i1, ptr %l4, !tbaa !21
  %t297 = getelementptr %"compiler/parse:Parser", ptr %t293, i32 0, i32 22
  store i1 %t294, ptr %t297, !tbaa !21
  %t298 = load ptr, ptr %l0, !tbaa !29
  %t299 = load i1, ptr %l5, !tbaa !21
  %t302 = getelementptr %"compiler/parse:Parser", ptr %t298, i32 0, i32 23
  store i1 %t299, ptr %t302, !tbaa !21
  %t304 = insertvalue { i32, ptr } zeroinitializer, i32 %t277, 0
  store { i32, ptr } %t304, ptr %rv
  br label %ret
bb35:
  %t305 = load ptr, ptr %l110, !tbaa !29
  store ptr %t305, ptr %l7, !tbaa !29
  br label %bb36
bb36:
  %t306 = load i1, ptr %l8, !tbaa !21
  br i1 %t306, label %bb37, label %bb38
bb37:
  %t308 = load ptr, ptr %l0, !tbaa !29
  %t310 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ecomprehends(ptr %v0, ptr %t308)
  store i1 %t310, ptr %l129
  br label %bb39
bb38:
  store i1 false, ptr %l127, !tbaa !21
  br label %bb40
bb39:
  %t311 = load i1, ptr %l129, !tbaa !21
  store i1 %t311, ptr %l127, !tbaa !21
  br label %bb40
bb40:
  %t312 = load i1, ptr %l127, !tbaa !21
  br i1 %t312, label %bb41, label %bb42
bb41:
  %t313 = load ptr, ptr %l0, !tbaa !29
  %t314 = load i32, ptr %l1, !tbaa !23
  %t315 = load ptr, ptr %l2, !tbaa !29
  %t317 = load ptr, ptr %l7, !tbaa !29
  %t323 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ecomprehension(ptr %v0, ptr %v1, ptr %v2, ptr %v2, ptr %t313, i32 %t314, ptr %t315, ptr %t317, i32 113)
  %t324 = extractvalue { i32, ptr } %t323, 1
  %t325 = extractvalue { i32, ptr } %t323, 0
  store i32 %t325, ptr %l138
  %t326 = icmp ne i32 %t325, 0
  br i1 %t326, label %bb44, label %ok.327, !prof !99
ok.327:
  store ptr %t324, ptr %l137
  br label %bb43
bb42:
  br label %bb46
bb43:
  %t328 = load ptr, ptr %l137, !tbaa !29
  store ptr %t328, ptr %l130, !tbaa !29
  br label %bb45
bb44:
  %t329 = load i32, ptr %l138, !tbaa !23
  %t330 = lshr i32 %t329, 16
  %t331 = and i32 %t329, 65535
  %t332 = icmp eq i32 %t330, 1
  %t333 = select i1 %t332, i32 1, i32 0
  %t334 = icmp eq i32 %t329, 0
  %t335 = shl i32 %t333, 16
  %t336 = or i32 %t335, %t331
  %t337 = select i1 %t334, i32 0, i32 %t336
  %t338 = load ptr, ptr %l0, !tbaa !29
  store ptr %t338, ptr %l140, !tbaa !29
  %t339 = load ptr, ptr %l140, !tbaa !29
  %t340 = getelementptr %"compiler/parse:Parser", ptr %t339, i32 0, i32 21
  %t341 = load i64, ptr %t340, !tbaa !24
  %t344 = sub i64 %t341, 1
  %t346 = load ptr, ptr %l140, !tbaa !29
  %t347 = getelementptr %"compiler/parse:Parser", ptr %t346, i32 0, i32 21
  store i64 %t344, ptr %t347, !tbaa !24
  %t348 = load ptr, ptr %l0, !tbaa !29
  %t349 = load i1, ptr %l3, !tbaa !21
  %t352 = getelementptr %"compiler/parse:Parser", ptr %t348, i32 0, i32 11
  store i1 %t349, ptr %t352, !tbaa !21
  %t353 = load ptr, ptr %l0, !tbaa !29
  %t354 = load i1, ptr %l4, !tbaa !21
  %t357 = getelementptr %"compiler/parse:Parser", ptr %t353, i32 0, i32 22
  store i1 %t354, ptr %t357, !tbaa !21
  %t358 = load ptr, ptr %l0, !tbaa !29
  %t359 = load i1, ptr %l5, !tbaa !21
  %t362 = getelementptr %"compiler/parse:Parser", ptr %t358, i32 0, i32 23
  store i1 %t359, ptr %t362, !tbaa !21
  %t364 = insertvalue { i32, ptr } zeroinitializer, i32 %t337, 0
  store { i32, ptr } %t364, ptr %rv
  br label %ret
bb45:
  %t365 = load ptr, ptr %l0, !tbaa !29
  store ptr %t365, ptr %l150, !tbaa !29
  %t366 = load ptr, ptr %l150, !tbaa !29
  %t367 = getelementptr %"compiler/parse:Parser", ptr %t366, i32 0, i32 21
  %t368 = load i64, ptr %t367, !tbaa !24
  %t371 = sub i64 %t368, 1
  %t373 = load ptr, ptr %l150, !tbaa !29
  %t374 = getelementptr %"compiler/parse:Parser", ptr %t373, i32 0, i32 21
  store i64 %t371, ptr %t374, !tbaa !24
  %t375 = load ptr, ptr %l0, !tbaa !29
  %t376 = load i1, ptr %l3, !tbaa !21
  %t379 = getelementptr %"compiler/parse:Parser", ptr %t375, i32 0, i32 11
  store i1 %t376, ptr %t379, !tbaa !21
  %t380 = load ptr, ptr %l0, !tbaa !29
  %t381 = load i1, ptr %l4, !tbaa !21
  %t384 = getelementptr %"compiler/parse:Parser", ptr %t380, i32 0, i32 22
  store i1 %t381, ptr %t384, !tbaa !21
  %t385 = load ptr, ptr %l0, !tbaa !29
  %t386 = load i1, ptr %l5, !tbaa !21
  %t389 = getelementptr %"compiler/parse:Parser", ptr %t385, i32 0, i32 23
  store i1 %t386, ptr %t389, !tbaa !21
  %t390 = load ptr, ptr %l130, !tbaa !29
  %t391 = insertvalue { i32, ptr } zeroinitializer, ptr %t390, 1
  store { i32, ptr } %t391, ptr %rv
  br label %ret
bb46:
  %t392 = load ptr, ptr %l0, !tbaa !29
  %t394 = getelementptr %"compiler/parse:Parser", ptr %t392, i32 0, i32 34
  %t395 = load ptr, ptr %l7, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2ePush_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %v2, ptr %t394, ptr %t395)
  br label %bb47
bb47:
  br label %bb48
bb48:
  %t398 = load ptr, ptr %l0, !tbaa !29
  %t401 = call { i32, i1 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2esep(ptr %v0, ptr %t398, i32 113)
  %t402 = extractvalue { i32, i1 } %t401, 1
  %t403 = extractvalue { i32, i1 } %t401, 0
  store i32 %t403, ptr %l167
  %t404 = icmp ne i32 %t403, 0
  br i1 %t404, label %bb50, label %ok.405, !prof !99
ok.405:
  store i1 %t402, ptr %l166
  br label %bb49
bb49:
  %t406 = load i1, ptr %l166, !tbaa !21
  store i1 %t406, ptr %l163, !tbaa !21
  br label %bb51
bb50:
  %t407 = load i32, ptr %l167, !tbaa !23
  %t408 = lshr i32 %t407, 16
  %t409 = and i32 %t407, 65535
  %t410 = icmp eq i32 %t408, 1
  %t411 = select i1 %t410, i32 1, i32 0
  %t412 = icmp eq i32 %t407, 0
  %t413 = shl i32 %t411, 16
  %t414 = or i32 %t413, %t409
  %t415 = select i1 %t412, i32 0, i32 %t414
  %t416 = load ptr, ptr %l0, !tbaa !29
  store ptr %t416, ptr %l169, !tbaa !29
  %t417 = load ptr, ptr %l169, !tbaa !29
  %t418 = getelementptr %"compiler/parse:Parser", ptr %t417, i32 0, i32 21
  %t419 = load i64, ptr %t418, !tbaa !24
  %t422 = sub i64 %t419, 1
  %t424 = load ptr, ptr %l169, !tbaa !29
  %t425 = getelementptr %"compiler/parse:Parser", ptr %t424, i32 0, i32 21
  store i64 %t422, ptr %t425, !tbaa !24
  %t426 = load ptr, ptr %l0, !tbaa !29
  %t427 = load i1, ptr %l3, !tbaa !21
  %t430 = getelementptr %"compiler/parse:Parser", ptr %t426, i32 0, i32 11
  store i1 %t427, ptr %t430, !tbaa !21
  %t431 = load ptr, ptr %l0, !tbaa !29
  %t432 = load i1, ptr %l4, !tbaa !21
  %t435 = getelementptr %"compiler/parse:Parser", ptr %t431, i32 0, i32 22
  store i1 %t432, ptr %t435, !tbaa !21
  %t436 = load ptr, ptr %l0, !tbaa !29
  %t437 = load i1, ptr %l5, !tbaa !21
  %t440 = getelementptr %"compiler/parse:Parser", ptr %t436, i32 0, i32 23
  store i1 %t437, ptr %t440, !tbaa !21
  %t442 = insertvalue { i32, ptr } zeroinitializer, i32 %t415, 0
  store { i32, ptr } %t442, ptr %rv
  br label %ret
bb51:
  %t443 = load i1, ptr %l163, !tbaa !21
  %t444 = xor i1 %t443, true
  br i1 %t444, label %bb52, label %bb53
bb52:
  br label %bb66
bb53:
  br label %bb54
bb54:
  %t446 = load ptr, ptr %l0, !tbaa !29
  %t448 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eelem(ptr %v0, ptr %v0, ptr %t446)
  %t449 = extractvalue { i32, ptr } %t448, 1
  %t450 = extractvalue { i32, ptr } %t448, 0
  store i32 %t450, ptr %l183
  %t451 = icmp ne i32 %t450, 0
  br i1 %t451, label %bb56, label %ok.452, !prof !99
ok.452:
  store ptr %t449, ptr %l182
  br label %bb55
bb55:
  %t453 = load ptr, ptr %l182, !tbaa !29
  store ptr %t453, ptr %l180, !tbaa !29
  br label %bb57
bb56:
  %t454 = load i32, ptr %l183, !tbaa !23
  %t455 = lshr i32 %t454, 16
  %t456 = and i32 %t454, 65535
  %t457 = icmp eq i32 %t455, 1
  %t458 = select i1 %t457, i32 1, i32 0
  %t459 = icmp eq i32 %t454, 0
  %t460 = shl i32 %t458, 16
  %t461 = or i32 %t460, %t456
  %t462 = select i1 %t459, i32 0, i32 %t461
  %t463 = load ptr, ptr %l0, !tbaa !29
  store ptr %t463, ptr %l185, !tbaa !29
  %t464 = load ptr, ptr %l185, !tbaa !29
  %t465 = getelementptr %"compiler/parse:Parser", ptr %t464, i32 0, i32 21
  %t466 = load i64, ptr %t465, !tbaa !24
  %t469 = sub i64 %t466, 1
  %t471 = load ptr, ptr %l185, !tbaa !29
  %t472 = getelementptr %"compiler/parse:Parser", ptr %t471, i32 0, i32 21
  store i64 %t469, ptr %t472, !tbaa !24
  %t473 = load ptr, ptr %l0, !tbaa !29
  %t474 = load i1, ptr %l3, !tbaa !21
  %t477 = getelementptr %"compiler/parse:Parser", ptr %t473, i32 0, i32 11
  store i1 %t474, ptr %t477, !tbaa !21
  %t478 = load ptr, ptr %l0, !tbaa !29
  %t479 = load i1, ptr %l4, !tbaa !21
  %t482 = getelementptr %"compiler/parse:Parser", ptr %t478, i32 0, i32 22
  store i1 %t479, ptr %t482, !tbaa !21
  %t483 = load ptr, ptr %l0, !tbaa !29
  %t484 = load i1, ptr %l5, !tbaa !21
  %t487 = getelementptr %"compiler/parse:Parser", ptr %t483, i32 0, i32 23
  store i1 %t484, ptr %t487, !tbaa !21
  %t489 = insertvalue { i32, ptr } zeroinitializer, i32 %t462, 0
  store { i32, ptr } %t489, ptr %rv
  br label %ret
bb57:
  %t490 = load ptr, ptr %l180, !tbaa !29
  store ptr %t490, ptr %l9, !tbaa !29
  %t491 = load i1, ptr %l8, !tbaa !21
  br i1 %t491, label %bb58, label %bb59
bb58:
  %t493 = load ptr, ptr %l0, !tbaa !29
  %t494 = load ptr, ptr %l9, !tbaa !29
  %t497 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eentry(ptr %v0, ptr %v0, ptr %v0, ptr %t493, ptr %t494)
  %t498 = extractvalue { i32, ptr } %t497, 1
  %t499 = extractvalue { i32, ptr } %t497, 0
  store i32 %t499, ptr %l200
  %t500 = icmp ne i32 %t499, 0
  br i1 %t500, label %bb61, label %ok.501, !prof !99
ok.501:
  store ptr %t498, ptr %l199
  br label %bb60
bb59:
  br label %bb63
bb60:
  %t502 = load ptr, ptr %l199, !tbaa !29
  store ptr %t502, ptr %l196, !tbaa !29
  br label %bb62
bb61:
  %t503 = load i32, ptr %l200, !tbaa !23
  %t504 = lshr i32 %t503, 16
  %t505 = and i32 %t503, 65535
  %t506 = icmp eq i32 %t504, 1
  %t507 = select i1 %t506, i32 1, i32 0
  %t508 = icmp eq i32 %t503, 0
  %t509 = shl i32 %t507, 16
  %t510 = or i32 %t509, %t505
  %t511 = select i1 %t508, i32 0, i32 %t510
  %t512 = load ptr, ptr %l0, !tbaa !29
  store ptr %t512, ptr %l202, !tbaa !29
  %t513 = load ptr, ptr %l202, !tbaa !29
  %t514 = getelementptr %"compiler/parse:Parser", ptr %t513, i32 0, i32 21
  %t515 = load i64, ptr %t514, !tbaa !24
  %t518 = sub i64 %t515, 1
  %t520 = load ptr, ptr %l202, !tbaa !29
  %t521 = getelementptr %"compiler/parse:Parser", ptr %t520, i32 0, i32 21
  store i64 %t518, ptr %t521, !tbaa !24
  %t522 = load ptr, ptr %l0, !tbaa !29
  %t523 = load i1, ptr %l3, !tbaa !21
  %t526 = getelementptr %"compiler/parse:Parser", ptr %t522, i32 0, i32 11
  store i1 %t523, ptr %t526, !tbaa !21
  %t527 = load ptr, ptr %l0, !tbaa !29
  %t528 = load i1, ptr %l4, !tbaa !21
  %t531 = getelementptr %"compiler/parse:Parser", ptr %t527, i32 0, i32 22
  store i1 %t528, ptr %t531, !tbaa !21
  %t532 = load ptr, ptr %l0, !tbaa !29
  %t533 = load i1, ptr %l5, !tbaa !21
  %t536 = getelementptr %"compiler/parse:Parser", ptr %t532, i32 0, i32 23
  store i1 %t533, ptr %t536, !tbaa !21
  %t538 = insertvalue { i32, ptr } zeroinitializer, i32 %t511, 0
  store { i32, ptr } %t538, ptr %rv
  br label %ret
bb62:
  %t539 = load ptr, ptr %l196, !tbaa !29
  store ptr %t539, ptr %l9, !tbaa !29
  br label %bb63
bb63:
  %t540 = load ptr, ptr %l0, !tbaa !29
  %t542 = getelementptr %"compiler/parse:Parser", ptr %t540, i32 0, i32 34
  %t543 = load ptr, ptr %l9, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2ePush_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t542, ptr %t543)
  br label %bb64
bb64:
  br label %bb65
bb65:
  br label %bb48
bb66:
  br label %bb67
bb67:
  %t546 = load ptr, ptr %l0, !tbaa !29
  %t549 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t546, i32 113)
  store i1 %t549, ptr %l217
  br label %bb68
bb68:
  %t550 = load i1, ptr %l217, !tbaa !21
  %t551 = xor i1 %t550, true
  br i1 %t551, label %bb69, label %bb70
bb69:
  store %olang.scope zeroinitializer, ptr %s28
  %t553 = load ptr, ptr %l0, !tbaa !29
  %t555 = getelementptr %"compiler/parse:Parser", ptr %t553, i32 0, i32 34
  %t556 = load i64, ptr %l6, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2eTruncate_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %t555, i64 %t556)
  br label %bb71
bb70:
  br label %bb76
bb71:
  %t559 = load ptr, ptr %l0, !tbaa !29
  store ptr %t559, ptr %l222, !tbaa !29
  %t561 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eDescribe(ptr %s28, i32 113)
  store { i64, ptr } %t561, ptr %l224
  br label %bb72
bb72:
  %t562 = load { i64, ptr }, ptr %l224, !tbaa !27
  %t563 = load ptr, ptr %l222, !tbaa !29
  %t565 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2efail(ptr %v0, ptr %s28, ptr %t563, { i64, ptr } %t562)
  store i32 %t565, ptr %l226
  %t566 = icmp ne i32 %t565, 0
  br i1 %t566, label %bb74, label %ok.567, !prof !99
ok.567:
  br label %bb73
bb73:
  br label %bb75
bb74:
  %t568 = load i32, ptr %l226, !tbaa !23
  %t569 = lshr i32 %t568, 16
  %t570 = and i32 %t568, 65535
  %t571 = icmp eq i32 %t569, 1
  %t572 = select i1 %t571, i32 1, i32 0
  %t573 = icmp eq i32 %t568, 0
  %t574 = shl i32 %t572, 16
  %t575 = or i32 %t574, %t570
  %t576 = select i1 %t573, i32 0, i32 %t575
  call void @__olang_scope_close(ptr %s28)
  %t577 = load ptr, ptr %l0, !tbaa !29
  store ptr %t577, ptr %l228, !tbaa !29
  %t578 = load ptr, ptr %l228, !tbaa !29
  %t579 = getelementptr %"compiler/parse:Parser", ptr %t578, i32 0, i32 21
  %t580 = load i64, ptr %t579, !tbaa !24
  %t583 = sub i64 %t580, 1
  %t585 = load ptr, ptr %l228, !tbaa !29
  %t586 = getelementptr %"compiler/parse:Parser", ptr %t585, i32 0, i32 21
  store i64 %t583, ptr %t586, !tbaa !24
  %t587 = load ptr, ptr %l0, !tbaa !29
  %t588 = load i1, ptr %l3, !tbaa !21
  %t591 = getelementptr %"compiler/parse:Parser", ptr %t587, i32 0, i32 11
  store i1 %t588, ptr %t591, !tbaa !21
  %t592 = load ptr, ptr %l0, !tbaa !29
  %t593 = load i1, ptr %l4, !tbaa !21
  %t596 = getelementptr %"compiler/parse:Parser", ptr %t592, i32 0, i32 22
  store i1 %t593, ptr %t596, !tbaa !21
  %t597 = load ptr, ptr %l0, !tbaa !29
  %t598 = load i1, ptr %l5, !tbaa !21
  %t601 = getelementptr %"compiler/parse:Parser", ptr %t597, i32 0, i32 23
  store i1 %t598, ptr %t601, !tbaa !21
  %t603 = insertvalue { i32, ptr } zeroinitializer, i32 %t576, 0
  store { i32, ptr } %t603, ptr %rv
  br label %ret
bb75:
  call void @__olang_scope_close(ptr %s28)
  br label %bb76
bb76:
  %t604 = load ptr, ptr %l0, !tbaa !29
  %t606 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t604)
  store i32 %t606, ptr %l239
  br label %bb77
bb77:
  %t607 = load ptr, ptr %l0, !tbaa !29
  %t608 = load i32, ptr %l1, !tbaa !23
  %t611 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t607, i32 %t608)
  store %"compiler/source:Span" %t611, ptr %l242
  br label %bb78
bb78:
  %t612 = load ptr, ptr %l2, !tbaa !29
  store ptr %t612, ptr %l244, !tbaa !29
  %t614 = load ptr, ptr %l0, !tbaa !29
  %t616 = getelementptr %"compiler/parse:Parser", ptr %t614, i32 0, i32 34
  %t617 = load i64, ptr %l6, !tbaa !24
  %t620 = call { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %v2, ptr %t616, i64 %t617)
  store { i64, ptr } %t620, ptr %l248
  br label %bb79
bb79:
  store { i64, [4 x i64] } zeroinitializer, ptr %t621
  %t622 = getelementptr { i64, [4 x i64] }, ptr %t621, i32 0, i32 0
  store i64 16, ptr %t622
  %t623 = load %"compiler/source:Span", ptr %l242
  %t624 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } undef, %"compiler/source:Span" %t623, 0
  %t625 = load ptr, ptr %l244, !tbaa !29
  %t626 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } %t624, ptr %t625, 1
  %t627 = load { i64, ptr }, ptr %l248, !tbaa !27
  %t628 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } %t626, { i64, ptr } %t627, 2
  %t629 = getelementptr { i64, [4 x i64] }, ptr %t621, i32 0, i32 1
  store { %"compiler/source:Span", ptr, { i64, ptr } } %t628, ptr %t629
  %t630 = load { i64, [4 x i64] }, ptr %t621
  %t632 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 40, i64 8)
  store { i64, [4 x i64] } %t630, ptr %t632
  %t633 = load ptr, ptr %l0, !tbaa !29
  store ptr %t633, ptr %l251, !tbaa !29
  %t634 = load ptr, ptr %l251, !tbaa !29
  %t635 = getelementptr %"compiler/parse:Parser", ptr %t634, i32 0, i32 21
  %t636 = load i64, ptr %t635, !tbaa !24
  %t639 = sub i64 %t636, 1
  %t641 = load ptr, ptr %l251, !tbaa !29
  %t642 = getelementptr %"compiler/parse:Parser", ptr %t641, i32 0, i32 21
  store i64 %t639, ptr %t642, !tbaa !24
  %t643 = load ptr, ptr %l0, !tbaa !29
  %t644 = load i1, ptr %l3, !tbaa !21
  %t647 = getelementptr %"compiler/parse:Parser", ptr %t643, i32 0, i32 11
  store i1 %t644, ptr %t647, !tbaa !21
  %t648 = load ptr, ptr %l0, !tbaa !29
  %t649 = load i1, ptr %l4, !tbaa !21
  %t652 = getelementptr %"compiler/parse:Parser", ptr %t648, i32 0, i32 22
  store i1 %t649, ptr %t652, !tbaa !21
  %t653 = load ptr, ptr %l0, !tbaa !29
  %t654 = load i1, ptr %l5, !tbaa !21
  %t657 = getelementptr %"compiler/parse:Parser", ptr %t653, i32 0, i32 23
  store i1 %t654, ptr %t657, !tbaa !21
  %t659 = insertvalue { i32, ptr } zeroinitializer, ptr %t632, 1
  store { i32, ptr } %t659, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eatEnd(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l3 = alloca i32
  %l6 = alloca i1
  %l9 = alloca i1
  %l15 = alloca i1
  %l18 = alloca i1
  %l21 = alloca i1
  %l27 = alloca i1
  %l33 = alloca i1
  %l36 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2epeek(ptr %v0, ptr %t1)
  store i32 %t3, ptr %l3
  br label %bb1
bb1:
  %t4 = load i32, ptr %l3, !range !{i32 0, i32 116}
  store i32 %t4, ptr %l1
  %t5 = load i32, ptr %l1, !range !{i32 0, i32 116}
  %t7 = trunc i64 8 to i32
  %t8 = icmp eq i32 %t5, %t7
  br i1 %t8, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb4
bb3:
  %t10 = load i32, ptr %l1, !range !{i32 0, i32 116}
  %t12 = trunc i64 115 to i32
  %t13 = icmp eq i32 %t10, %t12
  store i1 %t13, ptr %l6, !tbaa !21
  br label %bb4
bb4:
  %t15 = load i1, ptr %l6, !tbaa !21
  br i1 %t15, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb7
bb6:
  %t16 = load i32, ptr %l1, !range !{i32 0, i32 116}
  %t18 = trunc i64 0 to i32
  %t19 = icmp eq i32 %t16, %t18
  store i1 %t19, ptr %l9, !tbaa !21
  br label %bb7
bb7:
  %t21 = load i1, ptr %l9, !tbaa !21
  br i1 %t21, label %bb8, label %bb9
bb8:
  store i1 true, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/parse:Parser", ptr %t23, i32 0, i32 17
  %t26 = load i1, ptr %t25, !tbaa !21
  br i1 %t26, label %bb11, label %bb12
bb11:
  %t28 = load i32, ptr %l1, !range !{i32 0, i32 116}
  %t30 = trunc i64 111 to i32
  %t31 = icmp eq i32 %t28, %t30
  br i1 %t31, label %bb13, label %bb14
bb12:
  store i1 false, ptr %l15, !tbaa !21
  br label %bb19
bb13:
  store i1 true, ptr %l18, !tbaa !21
  br label %bb15
bb14:
  %t33 = load i32, ptr %l1, !range !{i32 0, i32 116}
  %t35 = trunc i64 113 to i32
  %t36 = icmp eq i32 %t33, %t35
  store i1 %t36, ptr %l18, !tbaa !21
  br label %bb15
bb15:
  %t38 = load i1, ptr %l18, !tbaa !21
  br i1 %t38, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l21, !tbaa !21
  br label %bb18
bb17:
  %t39 = load i32, ptr %l1, !range !{i32 0, i32 116}
  %t41 = trunc i64 75 to i32
  %t42 = icmp eq i32 %t39, %t41
  store i1 %t42, ptr %l21, !tbaa !21
  br label %bb18
bb18:
  %t44 = load i1, ptr %l21, !tbaa !21
  store i1 %t44, ptr %l15, !tbaa !21
  br label %bb19
bb19:
  %t45 = load i1, ptr %l15, !tbaa !21
  br i1 %t45, label %bb20, label %bb21
bb20:
  store i1 true, ptr %rv
  br label %ret
bb21:
  br label %bb22
bb22:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/parse:Parser", ptr %t47, i32 0, i32 19
  %t50 = load i1, ptr %t49, !tbaa !21
  br i1 %t50, label %bb23, label %bb24
bb23:
  %t52 = load i32, ptr %l1, !range !{i32 0, i32 116}
  %t54 = trunc i64 25 to i32
  %t55 = icmp eq i32 %t52, %t54
  store i1 %t55, ptr %l27, !tbaa !21
  br label %bb25
bb24:
  store i1 false, ptr %l27, !tbaa !21
  br label %bb25
bb25:
  %t57 = load i1, ptr %l27, !tbaa !21
  br i1 %t57, label %bb26, label %bb27
bb26:
  store i1 true, ptr %rv
  br label %ret
bb27:
  br label %bb28
bb28:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/parse:Parser", ptr %t59, i32 0, i32 15
  %t62 = load i1, ptr %t61, !tbaa !21
  br i1 %t62, label %bb29, label %bb30
bb29:
  %t64 = load i32, ptr %l1, !range !{i32 0, i32 116}
  %t66 = trunc i64 10 to i32
  %t67 = icmp eq i32 %t64, %t66
  br i1 %t67, label %bb31, label %bb32
bb30:
  store i1 false, ptr %l33, !tbaa !21
  br label %bb34
bb31:
  store i1 true, ptr %l36, !tbaa !21
  br label %bb33
bb32:
  %t69 = load i32, ptr %l1, !range !{i32 0, i32 116}
  %t71 = trunc i64 12 to i32
  %t72 = icmp eq i32 %t69, %t71
  store i1 %t72, ptr %l36, !tbaa !21
  br label %bb33
bb33:
  %t74 = load i1, ptr %l36, !tbaa !21
  store i1 %t74, ptr %l33, !tbaa !21
  br label %bb34
bb34:
  %t75 = load i1, ptr %l33, !tbaa !21
  store i1 %t75, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ebranch(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i32
  %l7 = alloca { i64, ptr }
  %l9 = alloca i32
  %l12 = alloca i1
  %l15 = alloca i64
  %l16 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l19 = alloca i32
  %l24 = alloca i1
  %l31 = alloca %"compiler/source:Span"
  %l36 = alloca %"compiler/ast:Branch"
  %l42 = alloca %"compiler/source:Span"
  %l45 = alloca %"compiler/ast:Branch"
  %l49 = alloca i1
  %l51 = alloca ptr
  %l53 = alloca { i64, ptr }
  %l55 = alloca i32
  %l59 = alloca i64
  %l62 = alloca { i64, ptr }
  %l64 = alloca { i64, ptr }
  %l65 = alloca i32
  %l70 = alloca i1
  %l78 = alloca i32
  %l88 = alloca i32
  %l91 = alloca %"compiler/source:Span"
  %l96 = alloca %"compiler/ast:Branch"
  %l102 = alloca %"compiler/source:Span"
  %l105 = alloca %"compiler/ast:Branch"
  %s4 = alloca %olang.scope
  %rv = alloca { i32, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ehere(ptr %v0, ptr %t1)
  store i32 %t3, ptr %l9
  br label %bb1
bb1:
  %t4 = load i32, ptr %l9, !tbaa !23
  store i32 %t4, ptr %l1, !tbaa !23
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t8 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t5, i32 79)
  store i1 %t8, ptr %l12
  br label %bb2
bb2:
  %t9 = load i1, ptr %l12, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/parse:Parser", ptr %t10, i32 0, i32 4
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t15 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eHold(ptr %v0, ptr %t13)
  store i64 %t15, ptr %l15
  br label %bb5
bb4:
  br label %bb27
bb5:
  %t16 = load i64, ptr %l15, !tbaa !24
  store i64 %t16, ptr %l2, !tbaa !24
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2elineBody(ptr %v0, ptr %v1, ptr %t17, i1 false)
  %t20 = extractvalue { i32, { i64, ptr } } %t19, 1
  %t21 = extractvalue { i32, { i64, ptr } } %t19, 0
  store i32 %t21, ptr %l19
  %t22 = icmp ne i32 %t21, 0
  br i1 %t22, label %bb7, label %ok.23, !prof !99
ok.23:
  store { i64, ptr } %t20, ptr %l18
  br label %bb6
bb6:
  %t24 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t24, ptr %l16, !tbaa !27
  br label %bb23
bb7:
  br label %bb8
bb8:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/parse:Parser", ptr %t25, i32 0, i32 4
  %t28 = load ptr, ptr %t27, !tbaa !29
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eEndHold(ptr %v0, ptr %t28)
  br label %bb9
bb9:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/parse:Parser", ptr %t30, i32 0, i32 25
  %t33 = load i1, ptr %t32, !tbaa !21
  br i1 %t33, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l24, !tbaa !21
  br label %bb12
bb11:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/parse:Parser", ptr %t35, i32 0, i32 27
  %t38 = load i1, ptr %t37, !tbaa !21
  store i1 %t38, ptr %l24, !tbaa !21
  br label %bb12
bb12:
  %t40 = load i1, ptr %l24, !tbaa !21
  br i1 %t40, label %bb13, label %bb14
bb13:
  %t42 = insertvalue { i32, ptr } zeroinitializer, i32 65536, 0
  store { i32, ptr } %t42, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  %t43 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2esyncFrom(ptr %v0, ptr %t43)
  br label %bb16
bb16:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t46 = load i32, ptr %l1, !tbaa !23
  %t49 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t45, i32 %t46)
  store %"compiler/source:Span" %t49, ptr %l31
  br label %bb17
bb17:
  %t50 = icmp sge i64 0, 0
  br i1 %t50, label %bb18, label %bb19
bb18:
  %t52 = icmp sle i64 0, 1152921504606846975
  br i1 %t52, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @olang_loc_3a014922d706f8ae_e8b2af70e71e377a)
  unreachable
bb20:
  %t54 = mul i64 0, 8
  %t55 = insertvalue { i64, ptr } undef, i64 0, 0
  %t56 = insertvalue { i64, ptr } %t55, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t57 = load i64, ptr %l2, !tbaa !24
  %t58 = load %"compiler/source:Span", ptr %l31
  %t61 = call %"compiler/ast:Branch" @compiler_2fast_3aBranch_2ector(ptr %v1, ptr %v1, %"compiler/source:Span" %t58, { i64, ptr } %t56, i64 %t57)
  store %"compiler/ast:Branch" %t61, ptr %l36
  br label %bb22
bb21:
  call void @__olang_check_failed(ptr @olang_loc_3a014922d706f8ae_e8b2af70e71e377a)
  unreachable
bb22:
  %t62 = load %"compiler/ast:Branch", ptr %l36
  %t63 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 32, i64 8)
  store %"compiler/ast:Branch" %t62, ptr %t63
  %t65 = insertvalue { i32, ptr } zeroinitializer, ptr %t63, 1
  store { i32, ptr } %t65, ptr %rv
  br label %ret
bb23:
  %t66 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t66, ptr %l3, !tbaa !27
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/parse:Parser", ptr %t67, i32 0, i32 4
  %t70 = load ptr, ptr %t69, !tbaa !29
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eEndHold(ptr %v0, ptr %t70)
  br label %bb24
bb24:
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t73 = load i32, ptr %l1, !tbaa !23
  %t76 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t72, i32 %t73)
  store %"compiler/source:Span" %t76, ptr %l42
  br label %bb25
bb25:
  %t77 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t78 = load i64, ptr %l2, !tbaa !24
  %t79 = load %"compiler/source:Span", ptr %l42
  %t82 = call %"compiler/ast:Branch" @compiler_2fast_3aBranch_2ector(ptr %v1, ptr %v1, %"compiler/source:Span" %t79, { i64, ptr } %t77, i64 %t78)
  store %"compiler/ast:Branch" %t82, ptr %l45
  br label %bb26
bb26:
  %t83 = load %"compiler/ast:Branch", ptr %l45
  %t84 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 32, i64 8)
  store %"compiler/ast:Branch" %t83, ptr %t84
  %t86 = insertvalue { i32, ptr } zeroinitializer, ptr %t84, 1
  store { i32, ptr } %t86, ptr %rv
  br label %ret
bb27:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t90 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t87, i32 114)
  store i1 %t90, ptr %l49
  br label %bb28
bb28:
  %t91 = load i1, ptr %l49, !tbaa !21
  %t92 = xor i1 %t91, true
  br i1 %t92, label %bb29, label %bb30
bb29:
  store %olang.scope zeroinitializer, ptr %s4
  %t94 = load ptr, ptr %l0, !tbaa !29
  store ptr %t94, ptr %l51, !tbaa !29
  %t96 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eDescribe(ptr %s4, i32 114)
  store { i64, ptr } %t96, ptr %l53
  br label %bb31
bb30:
  br label %bb35
bb31:
  %t97 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t98 = load ptr, ptr %l51, !tbaa !29
  %t100 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2efail(ptr %v0, ptr %s4, ptr %t98, { i64, ptr } %t97)
  store i32 %t100, ptr %l55
  %t101 = icmp ne i32 %t100, 0
  br i1 %t101, label %bb33, label %ok.102, !prof !99
ok.102:
  br label %bb32
bb32:
  br label %bb34
bb33:
  %t103 = load i32, ptr %l55, !tbaa !23
  %t104 = lshr i32 %t103, 16
  %t105 = and i32 %t103, 65535
  %t106 = icmp eq i32 %t104, 1
  %t107 = select i1 %t106, i32 1, i32 0
  %t108 = icmp eq i32 %t103, 0
  %t109 = shl i32 %t107, 16
  %t110 = or i32 %t109, %t105
  %t111 = select i1 %t108, i32 0, i32 %t110
  call void @__olang_scope_close(ptr %s4)
  %t113 = insertvalue { i32, ptr } zeroinitializer, i32 %t111, 0
  store { i32, ptr } %t113, ptr %rv
  br label %ret
bb34:
  call void @__olang_scope_close(ptr %s4)
  br label %bb35
bb35:
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t116 = getelementptr %"compiler/parse:Parser", ptr %t114, i32 0, i32 4
  %t117 = load ptr, ptr %t116, !tbaa !29
  %t119 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eHold(ptr %v0, ptr %t117)
  store i64 %t119, ptr %l59
  br label %bb36
bb36:
  %t120 = load i64, ptr %l59, !tbaa !24
  store i64 %t120, ptr %l4, !tbaa !24
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t123 = getelementptr %"compiler/parse:Parser", ptr %t121, i32 0, i32 6
  %t124 = load i64, ptr %t123, !tbaa !24
  store i64 %t124, ptr %l5, !tbaa !24
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t128 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eblock(ptr %v0, ptr %v1, ptr %t126)
  %t129 = extractvalue { i32, { i64, ptr } } %t128, 1
  %t130 = extractvalue { i32, { i64, ptr } } %t128, 0
  store i32 %t130, ptr %l65
  %t131 = icmp ne i32 %t130, 0
  br i1 %t131, label %bb38, label %ok.132, !prof !99
ok.132:
  store { i64, ptr } %t129, ptr %l64
  br label %bb37
bb37:
  %t133 = load { i64, ptr }, ptr %l64, !tbaa !27
  store { i64, ptr } %t133, ptr %l62, !tbaa !27
  br label %bb58
bb38:
  br label %bb39
bb39:
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t136 = getelementptr %"compiler/parse:Parser", ptr %t134, i32 0, i32 4
  %t137 = load ptr, ptr %t136, !tbaa !29
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eEndHold(ptr %v0, ptr %t137)
  br label %bb40
bb40:
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t141 = getelementptr %"compiler/parse:Parser", ptr %t139, i32 0, i32 25
  %t142 = load i1, ptr %t141, !tbaa !21
  br i1 %t142, label %bb41, label %bb42
bb41:
  store i1 true, ptr %l70, !tbaa !21
  br label %bb43
bb42:
  %t144 = load ptr, ptr %l0, !tbaa !29
  %t146 = getelementptr %"compiler/parse:Parser", ptr %t144, i32 0, i32 27
  %t147 = load i1, ptr %t146, !tbaa !21
  store i1 %t147, ptr %l70, !tbaa !21
  br label %bb43
bb43:
  %t149 = load i1, ptr %l70, !tbaa !21
  br i1 %t149, label %bb44, label %bb45
bb44:
  %t151 = insertvalue { i32, ptr } zeroinitializer, i32 65536, 0
  store { i32, ptr } %t151, ptr %rv
  br label %ret
bb45:
  br label %bb46
bb46:
  %t152 = load ptr, ptr %l0, !tbaa !29
  %t154 = getelementptr %"compiler/parse:Parser", ptr %t152, i32 0, i32 1
  %t155 = load ptr, ptr %t154, !tbaa !29
  %t156 = load i64, ptr %l5, !tbaa !24
  %t158 = trunc i64 %t156 to i32
  %t161 = call i32 @compiler_2fscan_2ecompiler_2fscan_3aTokens_2eMatch(ptr %v0, ptr %t155, i32 %t158)
  store i32 %t161, ptr %l78
  br label %bb47
bb47:
  %t162 = load i32, ptr %l78, !tbaa !23
  store i32 %t162, ptr %l6, !tbaa !23
  %t163 = load i32, ptr %l6, !tbaa !23
  %t165 = icmp slt i32 %t163, 0
  br i1 %t165, label %bb48, label %bb49
bb48:
  %t168 = insertvalue { i32, ptr } zeroinitializer, i32 65536, 0
  store { i32, ptr } %t168, ptr %rv
  br label %ret
bb49:
  br label %bb50
bb50:
  %t169 = load ptr, ptr %l0, !tbaa !29
  %t170 = load i32, ptr %l6, !tbaa !23
  %t172 = sext i32 %t170 to i64
  %t175 = getelementptr %"compiler/parse:Parser", ptr %t169, i32 0, i32 6
  store i64 %t172, ptr %t175, !tbaa !24
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t179 = getelementptr %"compiler/parse:Parser", ptr %t176, i32 0, i32 7
  store i32 0, ptr %t179
  %t180 = load ptr, ptr %l0, !tbaa !29
  %t182 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t180)
  store i32 %t182, ptr %l88
  br label %bb51
bb51:
  %t183 = load ptr, ptr %l0, !tbaa !29
  %t184 = load i32, ptr %l1, !tbaa !23
  %t187 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t183, i32 %t184)
  store %"compiler/source:Span" %t187, ptr %l91
  br label %bb52
bb52:
  %t188 = icmp sge i64 0, 0
  br i1 %t188, label %bb53, label %bb54
bb53:
  %t190 = icmp sle i64 0, 1152921504606846975
  br i1 %t190, label %bb55, label %bb56
bb54:
  call void @__olang_check_failed(ptr @olang_loc_e5b5865feda95523_92aca47b2e780ecf)
  unreachable
bb55:
  %t192 = mul i64 0, 8
  %t193 = insertvalue { i64, ptr } undef, i64 0, 0
  %t194 = insertvalue { i64, ptr } %t193, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t195 = load i64, ptr %l4, !tbaa !24
  %t196 = load %"compiler/source:Span", ptr %l91
  %t199 = call %"compiler/ast:Branch" @compiler_2fast_3aBranch_2ector(ptr %v1, ptr %v1, %"compiler/source:Span" %t196, { i64, ptr } %t194, i64 %t195)
  store %"compiler/ast:Branch" %t199, ptr %l96
  br label %bb57
bb56:
  call void @__olang_check_failed(ptr @olang_loc_e5b5865feda95523_92aca47b2e780ecf)
  unreachable
bb57:
  %t200 = load %"compiler/ast:Branch", ptr %l96
  %t201 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 32, i64 8)
  store %"compiler/ast:Branch" %t200, ptr %t201
  %t203 = insertvalue { i32, ptr } zeroinitializer, ptr %t201, 1
  store { i32, ptr } %t203, ptr %rv
  br label %ret
bb58:
  %t204 = load { i64, ptr }, ptr %l62, !tbaa !27
  store { i64, ptr } %t204, ptr %l7, !tbaa !27
  %t205 = load ptr, ptr %l0, !tbaa !29
  %t207 = getelementptr %"compiler/parse:Parser", ptr %t205, i32 0, i32 4
  %t208 = load ptr, ptr %t207, !tbaa !29
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eEndHold(ptr %v0, ptr %t208)
  br label %bb59
bb59:
  %t210 = load ptr, ptr %l0, !tbaa !29
  %t211 = load i32, ptr %l1, !tbaa !23
  %t214 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t210, i32 %t211)
  store %"compiler/source:Span" %t214, ptr %l102
  br label %bb60
bb60:
  %t215 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t216 = load i64, ptr %l4, !tbaa !24
  %t217 = load %"compiler/source:Span", ptr %l102
  %t220 = call %"compiler/ast:Branch" @compiler_2fast_3aBranch_2ector(ptr %v1, ptr %v1, %"compiler/source:Span" %t217, { i64, ptr } %t215, i64 %t216)
  store %"compiler/ast:Branch" %t220, ptr %l105
  br label %bb61
bb61:
  %t221 = load %"compiler/ast:Branch", ptr %l105
  %t222 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 32, i64 8)
  store %"compiler/ast:Branch" %t221, ptr %t222
  %t224 = insertvalue { i32, ptr } zeroinitializer, ptr %t222, 1
  store { i32, ptr } %t224, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local { i32, { { i64, ptr }, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ecaseBody(ptr %v0, ptr %v1, ptr %a0, i1 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i1
  %l3 = alloca %"compiler/token:Token"
  %l4 = alloca %"compiler/token:Token"
  %l5 = alloca ptr
  %l6 = alloca i32
  %l10 = alloca i1
  %l11 = alloca i1
  %l14 = alloca i1
  %l16 = alloca i32
  %l17 = alloca i1
  %l18 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l21 = alloca i32
  %l27 = alloca i1
  %l29 = alloca %"compiler/token:Token"
  %l31 = alloca i32
  %l33 = alloca %"compiler/token:Token"
  %l36 = alloca i1
  %l37 = alloca i1
  %l40 = alloca i1
  %l41 = alloca i1
  %l45 = alloca i32
  %l49 = alloca i32
  %l51 = alloca ptr
  %l52 = alloca i32
  %l53 = alloca i32
  %l54 = alloca %"compiler/diagmsg:Msg"
  %l56 = alloca ptr
  %l58 = alloca ptr
  %l59 = alloca i32
  %l69 = alloca i32
  %l70 = alloca { i64, ptr }
  %l72 = alloca { i64, ptr }
  %l73 = alloca i32
  %l75 = alloca ptr
  %l76 = alloca i32
  %l78 = alloca i32
  %l79 = alloca %"compiler/diagmsg:Msg"
  %l82 = alloca { i64, ptr }
  %l85 = alloca %"compiler/source:Span"
  %l89 = alloca { i64, ptr }
  %l91 = alloca { i64, ptr }
  %l92 = alloca i32
  %s4 = alloca %olang.scope
  %rv = alloca { i32, { { i64, ptr }, ptr } }
  %t188 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i1 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t4 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t1, i32 79)
  store i1 %t4, ptr %l10
  br label %bb1
bb1:
  %t5 = load i1, ptr %l10, !tbaa !21
  br i1 %t5, label %bb2, label %bb3
bb2:
  %t6 = load i1, ptr %l1, !tbaa !21
  %t8 = xor i1 %t6, true
  br i1 %t8, label %bb4, label %bb5
bb3:
  store i1 false, ptr %l11, !tbaa !21
  br label %bb9
bb4:
  store i1 true, ptr %l14, !tbaa !21
  br label %bb8
bb5:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elook(ptr %v0, ptr %t10, i64 1)
  store i32 %t12, ptr %l16
  br label %bb6
bb6:
  %t13 = load i32, ptr %l16, !range !{i32 0, i32 116}
  %t14 = call i1 @compiler_2fparse_2eleavingWord(i32 %t13)
  store i1 %t14, ptr %l17
  br label %bb7
bb7:
  %t15 = load i1, ptr %l17, !tbaa !21
  store i1 %t15, ptr %l14, !tbaa !21
  br label %bb8
bb8:
  %t16 = load i1, ptr %l14, !tbaa !21
  store i1 %t16, ptr %l11, !tbaa !21
  br label %bb9
bb9:
  %t17 = load i1, ptr %l11, !tbaa !21
  br i1 %t17, label %bb10, label %bb11
bb10:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2elineBody(ptr %v0, ptr %v1, ptr %t18, i1 false)
  %t21 = extractvalue { i32, { i64, ptr } } %t20, 1
  %t22 = extractvalue { i32, { i64, ptr } } %t20, 0
  store i32 %t22, ptr %l21
  %t23 = icmp ne i32 %t22, 0
  br i1 %t23, label %bb13, label %ok.24, !prof !99
ok.24:
  store { i64, ptr } %t21, ptr %l20
  br label %bb12
bb11:
  br label %bb15
bb12:
  %t25 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t25, ptr %l18, !tbaa !27
  br label %bb14
bb13:
  %t26 = load i32, ptr %l21, !tbaa !23
  %t27 = lshr i32 %t26, 16
  %t28 = and i32 %t26, 65535
  %t29 = icmp eq i32 %t27, 1
  %t30 = select i1 %t29, i32 1, i32 0
  %t31 = icmp eq i32 %t26, 0
  %t32 = shl i32 %t30, 16
  %t33 = or i32 %t32, %t28
  %t34 = select i1 %t31, i32 0, i32 %t33
  %t36 = insertvalue { i32, { { i64, ptr }, ptr } } zeroinitializer, i32 %t34, 0
  store { i32, { { i64, ptr }, ptr } } %t36, ptr %rv
  br label %ret
bb14:
  %t37 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t40 = insertvalue { { i64, ptr }, ptr } undef, { i64, ptr } %t37, 0
  %t41 = insertvalue { { i64, ptr }, ptr } %t40, ptr null, 1
  %t43 = insertvalue { i32, { { i64, ptr }, ptr } } zeroinitializer, { { i64, ptr }, ptr } %t41, 1
  store { i32, { { i64, ptr }, ptr } } %t43, ptr %rv
  br label %ret
bb15:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t47 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t44, i32 79)
  store i1 %t47, ptr %l27
  br label %bb16
bb16:
  %t48 = load i1, ptr %l27, !tbaa !21
  br i1 %t48, label %bb17, label %bb18
bb17:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2etk(ptr %v0, ptr %t49)
  store %"compiler/token:Token" %t51, ptr %l29
  br label %bb19
bb18:
  br label %bb44
bb19:
  %t52 = load %"compiler/token:Token", ptr %l29
  store %"compiler/token:Token" %t52, ptr %l3
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t53)
  store i32 %t55, ptr %l31
  br label %bb20
bb20:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2etk(ptr %v0, ptr %t56)
  store %"compiler/token:Token" %t58, ptr %l33
  br label %bb21
bb21:
  %t59 = load %"compiler/token:Token", ptr %l33
  store %"compiler/token:Token" %t59, ptr %l4
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t63 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t60, i32 8)
  store i1 %t63, ptr %l36
  br label %bb22
bb22:
  %t64 = load i1, ptr %l36, !tbaa !21
  br i1 %t64, label %bb23, label %bb24
bb23:
  store i1 true, ptr %l37, !tbaa !21
  br label %bb26
bb24:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t68 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t65, i32 0)
  store i1 %t68, ptr %l40
  br label %bb25
bb25:
  %t69 = load i1, ptr %l40, !tbaa !21
  store i1 %t69, ptr %l37, !tbaa !21
  br label %bb26
bb26:
  %t70 = load i1, ptr %l37, !tbaa !21
  br i1 %t70, label %bb27, label %bb28
bb27:
  store i1 true, ptr %l41, !tbaa !21
  br label %bb31
bb28:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/parse:Parser", ptr %t71, i32 0, i32 0
  %t74 = load ptr, ptr %t73, !tbaa !29
  %t75 = getelementptr %"compiler/token:Token", ptr %l4, i32 0, i32 2
  %t76 = load i32, ptr %t75, !tbaa !23
  %t79 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aSource_2eLine(ptr %v0, ptr %t74, i32 %t76)
  store i32 %t79, ptr %l45
  br label %bb29
bb29:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t82 = getelementptr %"compiler/parse:Parser", ptr %t80, i32 0, i32 0
  %t83 = load ptr, ptr %t82, !tbaa !29
  %t84 = getelementptr %"compiler/token:Token", ptr %l3, i32 0, i32 2
  %t85 = load i32, ptr %t84, !tbaa !23
  %t88 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aSource_2eLine(ptr %v0, ptr %t83, i32 %t85)
  store i32 %t88, ptr %l49
  br label %bb30
bb30:
  %t89 = load i32, ptr %l45, !tbaa !23
  %t90 = load i32, ptr %l49, !tbaa !23
  %t91 = icmp ne i32 %t89, %t90
  store i1 %t91, ptr %l41, !tbaa !21
  br label %bb31
bb31:
  %t93 = load i1, ptr %l41, !tbaa !21
  br i1 %t93, label %bb32, label %bb33
bb32:
  %t94 = load ptr, ptr %l0, !tbaa !29
  store ptr %t94, ptr %l51, !tbaa !29
  %t95 = getelementptr %"compiler/token:Token", ptr %l3, i32 0, i32 2
  %t96 = load i32, ptr %t95, !tbaa !23
  store i32 %t96, ptr %l52, !tbaa !23
  %t97 = getelementptr %"compiler/token:Token", ptr %l3, i32 0, i32 3
  %t98 = load i32, ptr %t97, !tbaa !23
  store i32 %t98, ptr %l53, !tbaa !23
  %t99 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eLineBodyOnLine(ptr %v0)
  store %"compiler/diagmsg:Msg" %t99, ptr %l54
  br label %bb34
bb33:
  br label %bb36
bb34:
  %t100 = load ptr, ptr %l51, !tbaa !29
  %t101 = load i32, ptr %l52, !tbaa !23
  %t102 = load i32, ptr %l53, !tbaa !23
  %t103 = load %"compiler/diagmsg:Msg", ptr %l54
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereport(ptr %v0, ptr %v0, ptr %t100, i32 %t101, i32 %t102, %"compiler/diagmsg:Msg" %t103)
  br label %bb35
bb35:
  %t105 = insertvalue { i32, { { i64, ptr }, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { { i64, ptr }, ptr } } %t105, ptr %rv
  br label %ret
bb36:
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t108 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexpr(ptr %v0, ptr %v1, ptr %t106)
  %t109 = extractvalue { i32, ptr } %t108, 1
  %t110 = extractvalue { i32, ptr } %t108, 0
  store i32 %t110, ptr %l59
  %t111 = icmp ne i32 %t110, 0
  br i1 %t111, label %bb38, label %ok.112, !prof !99
ok.112:
  store ptr %t109, ptr %l58
  br label %bb37
bb37:
  %t113 = load ptr, ptr %l58, !tbaa !29
  store ptr %t113, ptr %l56, !tbaa !29
  br label %bb39
bb38:
  %t114 = load i32, ptr %l59, !tbaa !23
  %t115 = lshr i32 %t114, 16
  %t116 = and i32 %t114, 65535
  %t117 = icmp eq i32 %t115, 1
  %t118 = select i1 %t117, i32 1, i32 0
  %t119 = icmp eq i32 %t114, 0
  %t120 = shl i32 %t118, 16
  %t121 = or i32 %t120, %t116
  %t122 = select i1 %t119, i32 0, i32 %t121
  %t124 = insertvalue { i32, { { i64, ptr }, ptr } } zeroinitializer, i32 %t122, 0
  store { i32, { { i64, ptr }, ptr } } %t124, ptr %rv
  br label %ret
bb39:
  %t125 = load ptr, ptr %l56, !tbaa !29
  store ptr %t125, ptr %l5, !tbaa !29
  %t126 = icmp sge i64 0, 0
  br i1 %t126, label %bb40, label %bb41
bb40:
  %t128 = icmp sle i64 0, 1152921504606846975
  br i1 %t128, label %bb42, label %bb43
bb41:
  call void @__olang_check_failed(ptr @olang_loc_1409caed80efd5ca_aa5da404b7edad6)
  unreachable
bb42:
  %t130 = mul i64 0, 8
  %t131 = insertvalue { i64, ptr } undef, i64 0, 0
  %t132 = insertvalue { i64, ptr } %t131, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t133 = load ptr, ptr %l5, !tbaa !29
  %t136 = insertvalue { { i64, ptr }, ptr } undef, { i64, ptr } %t132, 0
  %t138 = insertvalue { { i64, ptr }, ptr } %t136, ptr %t133, 1
  %t140 = insertvalue { i32, { { i64, ptr }, ptr } } zeroinitializer, { { i64, ptr }, ptr } %t138, 1
  store { i32, { { i64, ptr }, ptr } } %t140, ptr %rv
  br label %ret
bb43:
  call void @__olang_check_failed(ptr @olang_loc_1409caed80efd5ca_aa5da404b7edad6)
  unreachable
bb44:
  %t141 = load i1, ptr %l1, !tbaa !21
  br i1 %t141, label %bb45, label %bb46
bb45:
  store %olang.scope zeroinitializer, ptr %s4
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t145 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ehere(ptr %v0, ptr %t143)
  store i32 %t145, ptr %l69
  br label %bb47
bb46:
  br label %bb58
bb47:
  %t146 = load i32, ptr %l69, !tbaa !23
  store i32 %t146, ptr %l6, !tbaa !23
  %t147 = load ptr, ptr %l0, !tbaa !29
  %t149 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eblock(ptr %v0, ptr %s4, ptr %t147)
  %t150 = extractvalue { i32, { i64, ptr } } %t149, 1
  %t151 = extractvalue { i32, { i64, ptr } } %t149, 0
  store i32 %t151, ptr %l73
  %t152 = icmp ne i32 %t151, 0
  br i1 %t152, label %bb49, label %ok.153, !prof !99
ok.153:
  store { i64, ptr } %t150, ptr %l72
  br label %bb48
bb48:
  %t154 = load { i64, ptr }, ptr %l72, !tbaa !27
  store { i64, ptr } %t154, ptr %l70, !tbaa !27
  br label %bb50
bb49:
  %t155 = load i32, ptr %l73, !tbaa !23
  %t156 = lshr i32 %t155, 16
  %t157 = and i32 %t155, 65535
  %t158 = icmp eq i32 %t156, 1
  %t159 = select i1 %t158, i32 1, i32 0
  %t160 = icmp eq i32 %t155, 0
  %t161 = shl i32 %t159, 16
  %t162 = or i32 %t161, %t157
  %t163 = select i1 %t160, i32 0, i32 %t162
  call void @__olang_scope_close(ptr %s4)
  %t165 = insertvalue { i32, { { i64, ptr }, ptr } } zeroinitializer, i32 %t163, 0
  store { i32, { { i64, ptr }, ptr } } %t165, ptr %rv
  br label %ret
bb50:
  %t166 = load ptr, ptr %l0, !tbaa !29
  store ptr %t166, ptr %l75, !tbaa !29
  %t167 = load i32, ptr %l6, !tbaa !23
  store i32 %t167, ptr %l76, !tbaa !23
  %t168 = load i32, ptr %l6, !tbaa !23
  %t170 = add i32 %t168, 1
  store i32 %t170, ptr %l78, !tbaa !23
  %t171 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eValueCaseBlock(ptr %v0)
  store %"compiler/diagmsg:Msg" %t171, ptr %l79
  br label %bb51
bb51:
  %t172 = load ptr, ptr %l75, !tbaa !29
  %t173 = load i32, ptr %l76, !tbaa !23
  %t174 = load i32, ptr %l78, !tbaa !23
  %t175 = load %"compiler/diagmsg:Msg", ptr %l79
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereport(ptr %v0, ptr %v0, ptr %t172, i32 %t173, i32 %t174, %"compiler/diagmsg:Msg" %t175)
  br label %bb52
bb52:
  %t176 = icmp sge i64 0, 0
  br i1 %t176, label %bb53, label %bb54
bb53:
  %t178 = icmp sle i64 0, 1152921504606846975
  br i1 %t178, label %bb55, label %bb56
bb54:
  call void @__olang_check_failed(ptr @olang_loc_2c5c6195a47ae69f_51fb0001bc622feb)
  unreachable
bb55:
  %t180 = mul i64 0, 8
  %t181 = insertvalue { i64, ptr } undef, i64 0, 0
  %t182 = insertvalue { i64, ptr } %t181, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t182, ptr %l82, !tbaa !27
  %t183 = load ptr, ptr %l0, !tbaa !29
  %t184 = load i32, ptr %l6, !tbaa !23
  %t187 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t183, i32 %t184)
  store %"compiler/source:Span" %t187, ptr %l85
  br label %bb57
bb56:
  call void @__olang_check_failed(ptr @olang_loc_2c5c6195a47ae69f_51fb0001bc622feb)
  unreachable
bb57:
  store { i64, [4 x i64] } zeroinitializer, ptr %t188
  %t189 = getelementptr { i64, [4 x i64] }, ptr %t188, i32 0, i32 0
  store i64 25, ptr %t189
  %t190 = load %"compiler/source:Span", ptr %l85
  %t191 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t190, 0
  %t192 = insertvalue { %"compiler/source:Span", ptr } %t191, ptr null, 1
  %t193 = getelementptr { i64, [4 x i64] }, ptr %t188, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t192, ptr %t193
  %t194 = load { i64, [4 x i64] }, ptr %t188
  %t196 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 40, i64 8)
  store { i64, [4 x i64] } %t194, ptr %t196
  %t197 = load { i64, ptr }, ptr %l82, !tbaa !27
  %t198 = insertvalue { { i64, ptr }, ptr } undef, { i64, ptr } %t197, 0
  %t200 = insertvalue { { i64, ptr }, ptr } %t198, ptr %t196, 1
  call void @__olang_scope_close(ptr %s4)
  %t202 = insertvalue { i32, { { i64, ptr }, ptr } } zeroinitializer, { { i64, ptr }, ptr } %t200, 1
  store { i32, { { i64, ptr }, ptr } } %t202, ptr %rv
  br label %ret
bb58:
  %t203 = load ptr, ptr %l0, !tbaa !29
  %t205 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eblock(ptr %v0, ptr %v1, ptr %t203)
  %t206 = extractvalue { i32, { i64, ptr } } %t205, 1
  %t207 = extractvalue { i32, { i64, ptr } } %t205, 0
  store i32 %t207, ptr %l92
  %t208 = icmp ne i32 %t207, 0
  br i1 %t208, label %bb60, label %ok.209, !prof !99
ok.209:
  store { i64, ptr } %t206, ptr %l91
  br label %bb59
bb59:
  %t210 = load { i64, ptr }, ptr %l91, !tbaa !27
  store { i64, ptr } %t210, ptr %l89, !tbaa !27
  br label %bb61
bb60:
  %t211 = load i32, ptr %l92, !tbaa !23
  %t212 = lshr i32 %t211, 16
  %t213 = and i32 %t211, 65535
  %t214 = icmp eq i32 %t212, 1
  %t215 = select i1 %t214, i32 1, i32 0
  %t216 = icmp eq i32 %t211, 0
  %t217 = shl i32 %t215, 16
  %t218 = or i32 %t217, %t213
  %t219 = select i1 %t216, i32 0, i32 %t218
  %t221 = insertvalue { i32, { { i64, ptr }, ptr } } zeroinitializer, i32 %t219, 0
  store { i32, { { i64, ptr }, ptr } } %t221, ptr %rv
  br label %ret
bb61:
  %t222 = load { i64, ptr }, ptr %l89, !tbaa !27
  %t225 = insertvalue { { i64, ptr }, ptr } undef, { i64, ptr } %t222, 0
  %t226 = insertvalue { { i64, ptr }, ptr } %t225, ptr null, 1
  %t228 = insertvalue { i32, { { i64, ptr }, ptr } } zeroinitializer, { { i64, ptr }, ptr } %t226, 1
  store { i32, { { i64, ptr }, ptr } } %t228, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { { i64, ptr }, ptr } }, ptr %rv
  ret { i32, { { i64, ptr }, ptr } } %rr
}

define dso_local ptr @compiler_2fparse_2ecompiler_2fparse_3aParser_2ecasePattern(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l11 = alloca i64
  %l19 = alloca { i64, ptr }
  %l23 = alloca ptr
  %l26 = alloca ptr
  %l30 = alloca %"compiler/source:Span"
  %l31 = alloca ptr
  %l35 = alloca { i64, ptr }
  %rv = alloca ptr
  %t53 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/parse:Parser", ptr %t1, i32 0, i32 38
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aPattern_26_3e_2eLen_3ccompiler_2fast_3aPattern_26_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l11
  br label %bb1
bb1:
  %t6 = load i64, ptr %l11, !tbaa !24
  store i64 %t6, ptr %l4, !tbaa !24
  store { i64, ptr } %a3, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t9 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t9, 0
  store i64 %t11, ptr %l7, !tbaa !24
  br label %bb2
bb2:
  %t13 = load i64, ptr %l6, !tbaa !24
  %t14 = load i64, ptr %l7, !tbaa !24
  %t17 = icmp slt i64 %t13, %t14
  %t19 = xor i1 %t17, true
  br i1 %t19, label %bb3, label %bb4
bb3:
  br label %bb9
bb4:
  br label %bb5
bb5:
  %t21 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t21, ptr %l19, !tbaa !27
  %t22 = load i64, ptr %l6, !tbaa !24
  %t24 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = getelementptr ptr, ptr %t25, i64 %t22
  %t27 = load ptr, ptr %t26, !tbaa !39
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/parse:Parser", ptr %t29, i32 0, i32 38
  store ptr %t31, ptr %l23, !tbaa !29
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t36 = call ptr @compiler_2fparse_2ecompiler_2fparse_3aParser_2eitemPattern(ptr %v0, ptr %v2, ptr %v0, ptr %t32, ptr %t27)
  store ptr %t36, ptr %l26
  br label %bb6
bb6:
  %t37 = load ptr, ptr %l23, !tbaa !29
  %t38 = load ptr, ptr %l26, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aPattern_26_3e_2ePush_3ccompiler_2fast_3aPattern_26_3e(ptr %v0, ptr %v0, ptr %t37, ptr %t38)
  br label %bb7
bb7:
  br label %bb8
bb8:
  %t39 = load i64, ptr %l6, !tbaa !24
  %t42 = add i64 %t39, 1
  store i64 %t42, ptr %l6, !tbaa !24
  br label %bb2
bb9:
  store %"compiler/source:Span" %a1, ptr %l30
  store ptr %a2, ptr %l31, !tbaa !29
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/parse:Parser", ptr %t46, i32 0, i32 38
  %t49 = load i64, ptr %l4, !tbaa !24
  %t52 = call { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fast_3aPattern_26_3e(ptr %v0, ptr %v3, ptr %t48, i64 %t49)
  store { i64, ptr } %t52, ptr %l35
  br label %bb10
bb10:
  store { i64, [4 x i64] } zeroinitializer, ptr %t53
  %t54 = getelementptr { i64, [4 x i64] }, ptr %t53, i32 0, i32 0
  store i64 2, ptr %t54
  %t55 = load %"compiler/source:Span", ptr %l30
  %t56 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } undef, %"compiler/source:Span" %t55, 0
  %t57 = load ptr, ptr %l31, !tbaa !29
  %t58 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } %t56, ptr %t57, 1
  %t59 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t60 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } %t58, { i64, ptr } %t59, 2
  %t61 = getelementptr { i64, [4 x i64] }, ptr %t53, i32 0, i32 1
  store { %"compiler/source:Span", ptr, { i64, ptr } } %t60, ptr %t61
  %t62 = load { i64, [4 x i64] }, ptr %t53
  %t64 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 40, i64 8)
  store { i64, [4 x i64] } %t62, ptr %t64
  store ptr %t64, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ecatchLine(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i1
  %l5 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i32
  %rv = alloca { i32, { i64, ptr } }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/parse:Parser", ptr %t1, i32 0, i32 18
  %t4 = load i1, ptr %t3, !tbaa !21
  store i1 %t4, ptr %l1, !tbaa !21
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/parse:Parser", ptr %t6, i32 0, i32 18
  store i1 true, ptr %t8, !tbaa !21
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2elineBody(ptr %v0, ptr %v1, ptr %t9, i1 false)
  %t12 = extractvalue { i32, { i64, ptr } } %t11, 1
  %t13 = extractvalue { i32, { i64, ptr } } %t11, 0
  store i32 %t13, ptr %l8
  %t14 = icmp ne i32 %t13, 0
  br i1 %t14, label %bb2, label %ok.15, !prof !99
ok.15:
  store { i64, ptr } %t12, ptr %l7
  br label %bb1
bb1:
  %t16 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t16, ptr %l5, !tbaa !27
  br label %bb3
bb2:
  %t17 = load i32, ptr %l8, !tbaa !23
  %t18 = lshr i32 %t17, 16
  %t19 = and i32 %t17, 65535
  %t20 = icmp eq i32 %t18, 1
  %t21 = select i1 %t20, i32 1, i32 0
  %t22 = icmp eq i32 %t17, 0
  %t23 = shl i32 %t21, 16
  %t24 = or i32 %t23, %t19
  %t25 = select i1 %t22, i32 0, i32 %t24
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t27 = load i1, ptr %l1, !tbaa !21
  %t30 = getelementptr %"compiler/parse:Parser", ptr %t26, i32 0, i32 18
  store i1 %t27, ptr %t30, !tbaa !21
  %t32 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t25, 0
  store { i32, { i64, ptr } } %t32, ptr %rv
  br label %ret
bb3:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t34 = load i1, ptr %l1, !tbaa !21
  %t37 = getelementptr %"compiler/parse:Parser", ptr %t33, i32 0, i32 18
  store i1 %t34, ptr %t37, !tbaa !21
  %t38 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t39 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t38, 1
  store { i32, { i64, ptr } } %t39, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eclauses(ptr %v0, ptr %v1, ptr %a0, i1 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca %"compiler/source:Span"
  %l8 = alloca %"compiler/token:Token"
  %l9 = alloca { i64, ptr }
  %l10 = alloca i1
  %l11 = alloca ptr
  %l12 = alloca { i64, ptr }
  %l13 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l17 = alloca i1
  %l20 = alloca i32
  %l23 = alloca i64
  %l24 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l28 = alloca i1
  %l29 = alloca ptr
  %l30 = alloca ptr
  %l31 = alloca i64
  %l34 = alloca ptr
  %l35 = alloca i32
  %l39 = alloca i1
  %l41 = alloca %"compiler/source:Span"
  %l43 = alloca i64
  %l45 = alloca i1
  %l48 = alloca i1
  %l50 = alloca %"compiler/token:Token"
  %l51 = alloca i32
  %l53 = alloca i32
  %l54 = alloca i32
  %l58 = alloca %"compiler/source:Span"
  %l64 = alloca i1
  %l65 = alloca i1
  %l68 = alloca i1
  %l71 = alloca i1
  %l72 = alloca { i64, ptr }
  %l74 = alloca { i64, ptr }
  %l75 = alloca i32
  %l77 = alloca ptr
  %l80 = alloca %"compiler/source:Span"
  %l81 = alloca i64
  %l84 = alloca { i64, ptr }
  %l85 = alloca { i64, ptr }
  %l89 = alloca { i64, ptr }
  %l92 = alloca %"compiler/ast:Catch"
  %l95 = alloca { i64, ptr }
  %l97 = alloca { i64, ptr }
  %l98 = alloca i32
  %l102 = alloca i1
  %l103 = alloca ptr
  %l106 = alloca ptr
  %l108 = alloca ptr
  %l109 = alloca i32
  %l112 = alloca ptr
  %l113 = alloca i32
  %l118 = alloca ptr
  %l120 = alloca %"compiler/source:Span"
  %l127 = alloca i1
  %l130 = alloca i1
  %l134 = alloca ptr
  %l136 = alloca { i64, ptr }
  %l138 = alloca i32
  %l143 = alloca { i64, ptr }
  %l144 = alloca ptr
  %l147 = alloca %"compiler/source:Span"
  %l148 = alloca i64
  %l151 = alloca { i64, ptr }
  %l157 = alloca %"compiler/ast:Catch"
  %l160 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aCatch_26_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l13
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l13
  %t3 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %t3
  store ptr %t3, ptr %l2, !tbaa !29
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t8 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t5, i32 12)
  store i1 %t8, ptr %l17
  br label %bb3
bb3:
  %t9 = load i1, ptr %l17, !tbaa !21
  %t10 = xor i1 %t9, true
  br i1 %t10, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s1)
  br label %bb113
bb5:
  br label %bb6
bb6:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t12)
  store i32 %t14, ptr %l20
  br label %bb7
bb7:
  %t15 = load i32, ptr %l20, !tbaa !23
  store i32 %t15, ptr %l3, !tbaa !23
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/parse:Parser", ptr %t16, i32 0, i32 34
  %t20 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2eLen_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %t18)
  store i64 %t20, ptr %l23
  br label %bb8
bb8:
  %t21 = load i64, ptr %l23, !tbaa !24
  store i64 %t21, ptr %l4, !tbaa !24
  %t22 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aPath_26_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t22, ptr %l24
  br label %bb9
bb9:
  %t23 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l24
  %t24 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t23, ptr %t24
  store ptr %t24, ptr %l5, !tbaa !29
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t29 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t26, i32 1)
  store i1 %t29, ptr %l28
  br label %bb10
bb10:
  %t30 = load i1, ptr %l28, !tbaa !21
  br i1 %t30, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb26
bb13:
  %t31 = load ptr, ptr %l5, !tbaa !29
  store ptr %t31, ptr %l29, !tbaa !29
  %t32 = call ptr @__olang_scope_hold(ptr %v1)
  %t33 = ptrtoint ptr %t32 to i64
  store i64 %t33, ptr %l31, !tbaa !24
  %t34 = load i1, ptr @olang_2esole_2eArray_3ccompiler_2fast_3aPath_26_3e_2e_2d1
  br i1 %t34, label %bb14, label %bb15
bb14:
  %t36 = call ptr @__olang_region_make(ptr %v1)
  %t37 = ptrtoint ptr %t36 to i64
  store i64 %t37, ptr %l31, !tbaa !24
  br label %bb15
bb15:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t39 = load i64, ptr %l31
  %t40 = inttoptr i64 %t39 to ptr
  %t42 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2epath(ptr %v0, ptr %t40, ptr %t38)
  %t43 = extractvalue { i32, ptr } %t42, 1
  %t44 = extractvalue { i32, ptr } %t42, 0
  store i32 %t44, ptr %l35
  %t45 = icmp ne i32 %t44, 0
  br i1 %t45, label %bb17, label %ok.46, !prof !99
ok.46:
  store ptr %t43, ptr %l34
  br label %bb16
bb16:
  %t47 = load ptr, ptr %l34, !tbaa !29
  store ptr %t47, ptr %l30, !tbaa !29
  br label %bb18
bb17:
  %t48 = load i32, ptr %l35, !tbaa !23
  %t49 = lshr i32 %t48, 16
  %t50 = and i32 %t48, 65535
  %t51 = icmp eq i32 %t49, 1
  %t52 = select i1 %t51, i32 1, i32 0
  %t53 = icmp eq i32 %t48, 0
  %t54 = shl i32 %t52, 16
  %t55 = or i32 %t54, %t50
  %t56 = select i1 %t53, i32 0, i32 %t55
  call void @__olang_scope_close(ptr %s1)
  %t58 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t56, 0
  store { i32, { i64, ptr } } %t58, ptr %rv
  br label %ret
bb18:
  %t59 = load ptr, ptr %l29, !tbaa !29
  %t60 = load ptr, ptr %l30, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aPath_26_3e_2ePush_3ccompiler_2fast_3aPath_26_3e(ptr %v1, ptr %v1, ptr %t59, ptr %t60)
  br label %bb19
bb19:
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t64 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t61, i32 75)
  store i1 %t64, ptr %l39
  br label %bb20
bb20:
  %t65 = load i1, ptr %l39, !tbaa !21
  %t66 = xor i1 %t65, true
  br i1 %t66, label %bb21, label %bb22
bb21:
  br label %bb25
bb22:
  br label %bb23
bb23:
  br label %bb24
bb24:
  br label %bb13
bb25:
  br label %bb26
bb26:
  store i32 0, ptr %l6, !tbaa !23
  %t68 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s1, i32 0, i32 0)
  store %"compiler/source:Span" %t68, ptr %l41
  br label %bb27
bb27:
  %t69 = load %"compiler/source:Span", ptr %l41
  store %"compiler/source:Span" %t69, ptr %l7
  %t70 = load ptr, ptr %l5, !tbaa !29
  %t72 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aPath_26_3e_2eLen_3ccompiler_2fast_3aPath_26_3e(ptr %v1, ptr %t70)
  store i64 %t72, ptr %l43
  br label %bb28
bb28:
  %t73 = load i64, ptr %l43, !tbaa !24
  %t74 = icmp sgt i64 %t73, 0
  br i1 %t74, label %bb29, label %bb30
bb29:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t79 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t76, i32 1)
  store i1 %t79, ptr %l48
  br label %bb31
bb30:
  store i1 false, ptr %l45, !tbaa !21
  br label %bb32
bb31:
  %t80 = load i1, ptr %l48, !tbaa !21
  store i1 %t80, ptr %l45, !tbaa !21
  br label %bb32
bb32:
  %t81 = load i1, ptr %l45, !tbaa !21
  br i1 %t81, label %bb33, label %bb34
bb33:
  store %olang.scope zeroinitializer, ptr %s5
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2etk(ptr %v0, ptr %t82)
  store %"compiler/token:Token" %t84, ptr %l50
  br label %bb35
bb34:
  br label %bb40
bb35:
  %t85 = load %"compiler/token:Token", ptr %l50
  store %"compiler/token:Token" %t85, ptr %l8
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t88 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ename(ptr %v0, ptr %t86)
  %t89 = extractvalue { i32, i32 } %t88, 1
  %t90 = extractvalue { i32, i32 } %t88, 0
  store i32 %t90, ptr %l54
  %t91 = icmp ne i32 %t90, 0
  br i1 %t91, label %bb37, label %ok.92, !prof !99
ok.92:
  store i32 %t89, ptr %l53
  br label %bb36
bb36:
  %t93 = load i32, ptr %l53, !tbaa !23
  store i32 %t93, ptr %l51, !tbaa !23
  br label %bb38
bb37:
  %t94 = load i32, ptr %l54, !tbaa !23
  %t95 = lshr i32 %t94, 16
  %t96 = and i32 %t94, 65535
  %t97 = icmp eq i32 %t95, 1
  %t98 = select i1 %t97, i32 1, i32 0
  %t99 = icmp eq i32 %t94, 0
  %t100 = shl i32 %t98, 16
  %t101 = or i32 %t100, %t96
  %t102 = select i1 %t99, i32 0, i32 %t101
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s1)
  %t104 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t102, 0
  store { i32, { i64, ptr } } %t104, ptr %rv
  br label %ret
bb38:
  %t105 = load i32, ptr %l51, !tbaa !23
  store i32 %t105, ptr %l6, !tbaa !23
  %t106 = getelementptr %"compiler/token:Token", ptr %l8, i32 0, i32 2
  %t107 = load i32, ptr %t106, !tbaa !23
  %t108 = getelementptr %"compiler/token:Token", ptr %l8, i32 0, i32 3
  %t109 = load i32, ptr %t108, !tbaa !23
  %t112 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s5, i32 %t107, i32 %t109)
  store %"compiler/source:Span" %t112, ptr %l58
  br label %bb39
bb39:
  %t113 = load %"compiler/source:Span", ptr %l58
  store %"compiler/source:Span" %t113, ptr %l7
  call void @__olang_scope_close(ptr %s5)
  br label %bb40
bb40:
  %t114 = icmp sge i64 0, 0
  br i1 %t114, label %bb41, label %bb42
bb41:
  %t116 = icmp sle i64 0, 1152921504606846975
  br i1 %t116, label %bb43, label %bb44
bb42:
  call void @__olang_check_failed(ptr @olang_loc_e74fa2d3d14c2452_7ce0d57fd3650746)
  unreachable
bb43:
  %t118 = mul i64 0, 8
  %t119 = insertvalue { i64, ptr } undef, i64 0, 0
  %t120 = insertvalue { i64, ptr } %t119, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t120, ptr %l9, !tbaa !27
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t125 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t122, i32 114)
  store i1 %t125, ptr %l64
  br label %bb45
bb44:
  call void @__olang_check_failed(ptr @olang_loc_e74fa2d3d14c2452_7ce0d57fd3650746)
  unreachable
bb45:
  %t126 = load i1, ptr %l64, !tbaa !21
  br i1 %t126, label %bb46, label %bb47
bb46:
  store i1 true, ptr %l65, !tbaa !21
  br label %bb49
bb47:
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t130 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t127, i32 79)
  store i1 %t130, ptr %l68
  br label %bb48
bb48:
  %t131 = load i1, ptr %l68, !tbaa !21
  store i1 %t131, ptr %l65, !tbaa !21
  br label %bb49
bb49:
  %t132 = load i1, ptr %l65, !tbaa !21
  store i1 %t132, ptr %l10, !tbaa !21
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t136 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t133, i32 79)
  store i1 %t136, ptr %l71
  br label %bb50
bb50:
  %t137 = load i1, ptr %l71, !tbaa !21
  br i1 %t137, label %bb51, label %bb52
bb51:
  %t138 = load ptr, ptr %l0, !tbaa !29
  %t140 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ecatchLine(ptr %v0, ptr %v1, ptr %t138)
  %t141 = extractvalue { i32, { i64, ptr } } %t140, 1
  %t142 = extractvalue { i32, { i64, ptr } } %t140, 0
  store i32 %t142, ptr %l75
  %t143 = icmp ne i32 %t142, 0
  br i1 %t143, label %bb54, label %ok.144, !prof !99
ok.144:
  store { i64, ptr } %t141, ptr %l74
  br label %bb53
bb52:
  br label %bb63
bb53:
  %t145 = load { i64, ptr }, ptr %l74, !tbaa !27
  store { i64, ptr } %t145, ptr %l72, !tbaa !27
  br label %bb55
bb54:
  %t146 = load i32, ptr %l75, !tbaa !23
  %t147 = lshr i32 %t146, 16
  %t148 = and i32 %t146, 65535
  %t149 = icmp eq i32 %t147, 1
  %t150 = select i1 %t149, i32 1, i32 0
  %t151 = icmp eq i32 %t146, 0
  %t152 = shl i32 %t150, 16
  %t153 = or i32 %t152, %t148
  %t154 = select i1 %t151, i32 0, i32 %t153
  call void @__olang_scope_close(ptr %s1)
  %t156 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t154, 0
  store { i32, { i64, ptr } } %t156, ptr %rv
  br label %ret
bb55:
  %t157 = load { i64, ptr }, ptr %l72, !tbaa !27
  store { i64, ptr } %t157, ptr %l9, !tbaa !27
  %t158 = load ptr, ptr %l2, !tbaa !29
  store ptr %t158, ptr %l77, !tbaa !29
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t160 = load i32, ptr %l3, !tbaa !23
  %t163 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t159, i32 %t160)
  store %"compiler/source:Span" %t163, ptr %l80
  br label %bb56
bb56:
  %t164 = call ptr @__olang_scope_hold(ptr %v1)
  %t165 = ptrtoint ptr %t164 to i64
  store i64 %t165, ptr %l81, !tbaa !24
  %t166 = load i1, ptr @olang_2esole_2ecompiler_2fast_3aCatch_2e1
  br i1 %t166, label %bb57, label %bb58
bb57:
  %t168 = call ptr @__olang_region_make(ptr %v1)
  %t169 = ptrtoint ptr %t168 to i64
  store i64 %t169, ptr %l81, !tbaa !24
  br label %bb58
bb58:
  %t170 = load ptr, ptr %l5, !tbaa !29
  %t171 = load i64, ptr %l81
  %t172 = inttoptr i64 %t171 to ptr
  %t174 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aPath_26_3e_2eToArray_3ccompiler_2fast_3aPath_26_3e(ptr %v1, ptr %t172, ptr %t170)
  store { i64, ptr } %t174, ptr %l84
  br label %bb59
bb59:
  %t175 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t175, ptr %l85, !tbaa !27
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t178 = getelementptr %"compiler/parse:Parser", ptr %t176, i32 0, i32 34
  %t179 = load i64, ptr %l4, !tbaa !24
  %t182 = call { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t178, i64 %t179)
  store { i64, ptr } %t182, ptr %l89
  br label %bb60
bb60:
  %t183 = load i32, ptr %l6, !tbaa !23
  %t184 = load %"compiler/source:Span", ptr %l7
  %t185 = load %"compiler/source:Span", ptr %l80
  %t186 = load { i64, ptr }, ptr %l84, !tbaa !27
  %t187 = load { i64, ptr }, ptr %l85, !tbaa !27
  %t188 = load { i64, ptr }, ptr %l89, !tbaa !27
  %t191 = call %"compiler/ast:Catch" @compiler_2fast_3aCatch_2ector(ptr %v1, ptr %v1, ptr %v0, ptr %v1, %"compiler/source:Span" %t185, { i64, ptr } %t186, { i64, ptr } %t187, { i64, ptr } %t188, i1 true, i32 %t183, %"compiler/source:Span" %t184)
  store %"compiler/ast:Catch" %t191, ptr %l92
  br label %bb61
bb61:
  %t192 = load %"compiler/ast:Catch", ptr %l92
  %t193 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 72, i64 8)
  store %"compiler/ast:Catch" %t192, ptr %t193
  %t194 = load ptr, ptr %l77, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aCatch_26_3e_2ePush_3ccompiler_2fast_3aCatch_26_3e(ptr %v1, ptr %v1, ptr %t194, ptr %t193)
  br label %bb62
bb62:
  call void @__olang_scope_close(ptr %s1)
  br label %bb112
bb63:
  %t196 = load i1, ptr %l10, !tbaa !21
  br i1 %t196, label %bb64, label %bb65
bb64:
  %t198 = load ptr, ptr %l0, !tbaa !29
  %t200 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eblock(ptr %v0, ptr %v1, ptr %t198)
  %t201 = extractvalue { i32, { i64, ptr } } %t200, 1
  %t202 = extractvalue { i32, { i64, ptr } } %t200, 0
  store i32 %t202, ptr %l98
  %t203 = icmp ne i32 %t202, 0
  br i1 %t203, label %bb67, label %ok.204, !prof !99
ok.204:
  store { i64, ptr } %t201, ptr %l97
  br label %bb66
bb65:
  br label %bb69
bb66:
  %t205 = load { i64, ptr }, ptr %l97, !tbaa !27
  store { i64, ptr } %t205, ptr %l95, !tbaa !27
  br label %bb68
bb67:
  %t206 = load i32, ptr %l98, !tbaa !23
  %t207 = lshr i32 %t206, 16
  %t208 = and i32 %t206, 65535
  %t209 = icmp eq i32 %t207, 1
  %t210 = select i1 %t209, i32 1, i32 0
  %t211 = icmp eq i32 %t206, 0
  %t212 = shl i32 %t210, 16
  %t213 = or i32 %t212, %t208
  %t214 = select i1 %t211, i32 0, i32 %t213
  call void @__olang_scope_close(ptr %s1)
  %t216 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t214, 0
  store { i32, { i64, ptr } } %t216, ptr %rv
  br label %ret
bb68:
  %t217 = load { i64, ptr }, ptr %l95, !tbaa !27
  store { i64, ptr } %t217, ptr %l9, !tbaa !27
  br label %bb69
bb69:
  %t218 = load ptr, ptr %l0, !tbaa !29
  %t221 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t218, i32 44)
  store i1 %t221, ptr %l102
  br label %bb70
bb70:
  %t222 = load i1, ptr %l102, !tbaa !21
  br i1 %t222, label %bb71, label %bb72
bb71:
  br label %bb73
bb72:
  %t223 = load i1, ptr %l10, !tbaa !21
  %t225 = xor i1 %t223, true
  br i1 %t225, label %bb97, label %bb98
bb73:
  %t227 = load ptr, ptr %l0, !tbaa !29
  %t229 = getelementptr %"compiler/parse:Parser", ptr %t227, i32 0, i32 50
  %t230 = load i1, ptr %t229, !tbaa !21
  br i1 %t230, label %bb74, label %bb75
bb74:
  %t232 = load ptr, ptr %l0, !tbaa !29
  %t234 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eunary(ptr %v0, ptr %v0, ptr %t232)
  %t235 = extractvalue { i32, ptr } %t234, 1
  %t236 = extractvalue { i32, ptr } %t234, 0
  store i32 %t236, ptr %l109
  %t237 = icmp ne i32 %t236, 0
  br i1 %t237, label %bb77, label %ok.238, !prof !99
ok.238:
  store ptr %t235, ptr %l108
  br label %bb76
bb75:
  %t239 = load ptr, ptr %l0, !tbaa !29
  %t241 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexpr(ptr %v0, ptr %v0, ptr %t239)
  %t242 = extractvalue { i32, ptr } %t241, 1
  %t243 = extractvalue { i32, ptr } %t241, 0
  store i32 %t243, ptr %l113
  %t244 = icmp ne i32 %t243, 0
  br i1 %t244, label %bb79, label %ok.245, !prof !99
ok.245:
  store ptr %t242, ptr %l112
  br label %bb78
bb76:
  %t246 = load ptr, ptr %l108, !tbaa !29
  store ptr %t246, ptr %l106, !tbaa !29
  br label %bb80
bb77:
  %t247 = load i32, ptr %l109, !tbaa !23
  %t248 = lshr i32 %t247, 16
  %t249 = and i32 %t247, 65535
  %t250 = icmp eq i32 %t248, 1
  %t251 = select i1 %t250, i32 1, i32 0
  %t252 = icmp eq i32 %t247, 0
  %t253 = shl i32 %t251, 16
  %t254 = or i32 %t253, %t249
  %t255 = select i1 %t252, i32 0, i32 %t254
  call void @__olang_scope_close(ptr %s1)
  %t257 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t255, 0
  store { i32, { i64, ptr } } %t257, ptr %rv
  br label %ret
bb78:
  %t258 = load ptr, ptr %l112, !tbaa !29
  store ptr %t258, ptr %l106, !tbaa !29
  br label %bb80
bb79:
  %t259 = load i32, ptr %l113, !tbaa !23
  %t260 = lshr i32 %t259, 16
  %t261 = and i32 %t259, 65535
  %t262 = icmp eq i32 %t260, 1
  %t263 = select i1 %t262, i32 1, i32 0
  %t264 = icmp eq i32 %t259, 0
  %t265 = shl i32 %t263, 16
  %t266 = or i32 %t265, %t261
  %t267 = select i1 %t264, i32 0, i32 %t266
  call void @__olang_scope_close(ptr %s1)
  %t269 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t267, 0
  store { i32, { i64, ptr } } %t269, ptr %rv
  br label %ret
bb80:
  %t270 = load ptr, ptr %l106, !tbaa !29
  store ptr %t270, ptr %l103, !tbaa !29
  br label %bb81
bb81:
  %t271 = load ptr, ptr %l103, !tbaa !29
  store ptr %t271, ptr %l11, !tbaa !29
  %t272 = load ptr, ptr %l0, !tbaa !29
  %t274 = getelementptr %"compiler/parse:Parser", ptr %t272, i32 0, i32 50
  %t275 = load i1, ptr %t274, !tbaa !21
  br i1 %t275, label %bb82, label %bb83
bb82:
  %t277 = load ptr, ptr %l0, !tbaa !29
  %t279 = getelementptr %"compiler/parse:Parser", ptr %t277, i32 0, i32 53
  store ptr %t279, ptr %l118, !tbaa !29
  %t280 = load ptr, ptr %l11, !tbaa !29
  %t282 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v0, ptr %t280)
  store %"compiler/source:Span" %t282, ptr %l120
  br label %bb84
bb83:
  br label %bb86
bb84:
  %t283 = getelementptr %"compiler/source:Span", ptr %l120, i32 0, i32 0
  %t284 = load i32, ptr %t283, !tbaa !23
  %t285 = load ptr, ptr %l118, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI32_3e_2ePush_3cI32_3e(ptr %v0, ptr %t285, i32 %t284)
  br label %bb85
bb85:
  br label %bb86
bb86:
  %t287 = load ptr, ptr %l0, !tbaa !29
  %t289 = getelementptr %"compiler/parse:Parser", ptr %t287, i32 0, i32 34
  %t290 = load ptr, ptr %l11, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2ePush_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t289, ptr %t290)
  br label %bb87
bb87:
  %t295 = xor i1 %a1, true
  br i1 %t295, label %bb88, label %bb89
bb88:
  store i1 true, ptr %l127, !tbaa !21
  br label %bb91
bb89:
  %t297 = load ptr, ptr %l0, !tbaa !29
  %t300 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t297, i32 75)
  store i1 %t300, ptr %l130
  br label %bb90
bb90:
  %t301 = load i1, ptr %l130, !tbaa !21
  %t302 = xor i1 %t301, true
  store i1 %t302, ptr %l127, !tbaa !21
  br label %bb91
bb91:
  %t304 = load i1, ptr %l127, !tbaa !21
  br i1 %t304, label %bb92, label %bb93
bb92:
  br label %bb96
bb93:
  br label %bb94
bb94:
  br label %bb95
bb95:
  br label %bb73
bb96:
  br label %bb104
bb97:
  store %olang.scope zeroinitializer, ptr %s13
  %t305 = load ptr, ptr %l0, !tbaa !29
  store ptr %t305, ptr %l134, !tbaa !29
  %t307 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eDescribe(ptr %s13, i32 114)
  store { i64, ptr } %t307, ptr %l136
  br label %bb99
bb98:
  br label %bb103
bb99:
  %t308 = load { i64, ptr }, ptr %l136, !tbaa !27
  %t309 = load ptr, ptr %l134, !tbaa !29
  %t311 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2efail(ptr %v0, ptr %s13, ptr %t309, { i64, ptr } %t308)
  store i32 %t311, ptr %l138
  %t312 = icmp ne i32 %t311, 0
  br i1 %t312, label %bb101, label %ok.313, !prof !99
ok.313:
  br label %bb100
bb100:
  br label %bb102
bb101:
  %t314 = load i32, ptr %l138, !tbaa !23
  %t315 = lshr i32 %t314, 16
  %t316 = and i32 %t314, 65535
  %t317 = icmp eq i32 %t315, 1
  %t318 = select i1 %t317, i32 1, i32 0
  %t319 = icmp eq i32 %t314, 0
  %t320 = shl i32 %t318, 16
  %t321 = or i32 %t320, %t316
  %t322 = select i1 %t319, i32 0, i32 %t321
  call void @__olang_scope_close(ptr %s13)
  call void @__olang_scope_close(ptr %s1)
  %t324 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t322, 0
  store { i32, { i64, ptr } } %t324, ptr %rv
  br label %ret
bb102:
  call void @__olang_scope_close(ptr %s13)
  br label %bb103
bb103:
  br label %bb104
bb104:
  %t325 = load ptr, ptr %l0, !tbaa !29
  %t327 = getelementptr %"compiler/parse:Parser", ptr %t325, i32 0, i32 34
  %t328 = load i64, ptr %l4, !tbaa !24
  %t331 = call { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %t327, i64 %t328)
  store { i64, ptr } %t331, ptr %l143
  br label %bb105
bb105:
  %t332 = load { i64, ptr }, ptr %l143, !tbaa !27
  store { i64, ptr } %t332, ptr %l12, !tbaa !27
  %t333 = load ptr, ptr %l2, !tbaa !29
  store ptr %t333, ptr %l144, !tbaa !29
  %t334 = load ptr, ptr %l0, !tbaa !29
  %t335 = load i32, ptr %l3, !tbaa !23
  %t338 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t334, i32 %t335)
  store %"compiler/source:Span" %t338, ptr %l147
  br label %bb106
bb106:
  %t339 = call ptr @__olang_scope_hold(ptr %v1)
  %t340 = ptrtoint ptr %t339 to i64
  store i64 %t340, ptr %l148, !tbaa !24
  %t341 = load i1, ptr @olang_2esole_2ecompiler_2fast_3aCatch_2e1
  br i1 %t341, label %bb107, label %bb108
bb107:
  %t343 = call ptr @__olang_region_make(ptr %v1)
  %t344 = ptrtoint ptr %t343 to i64
  store i64 %t344, ptr %l148, !tbaa !24
  br label %bb108
bb108:
  %t345 = load ptr, ptr %l5, !tbaa !29
  %t346 = load i64, ptr %l148
  %t347 = inttoptr i64 %t346 to ptr
  %t349 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aPath_26_3e_2eToArray_3ccompiler_2fast_3aPath_26_3e(ptr %v1, ptr %t347, ptr %t345)
  store { i64, ptr } %t349, ptr %l151
  br label %bb109
bb109:
  %t350 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t351 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t352 = load i1, ptr %l10, !tbaa !21
  %t353 = load i32, ptr %l6, !tbaa !23
  %t354 = load %"compiler/source:Span", ptr %l7
  %t355 = load %"compiler/source:Span", ptr %l147
  %t356 = load { i64, ptr }, ptr %l151, !tbaa !27
  %t362 = call %"compiler/ast:Catch" @compiler_2fast_3aCatch_2ector(ptr %v1, ptr %v1, ptr %v1, ptr %v1, %"compiler/source:Span" %t355, { i64, ptr } %t356, { i64, ptr } %t350, { i64, ptr } %t351, i1 %t352, i32 %t353, %"compiler/source:Span" %t354)
  store %"compiler/ast:Catch" %t362, ptr %l157
  br label %bb110
bb110:
  %t363 = load %"compiler/ast:Catch", ptr %l157
  %t364 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 72, i64 8)
  store %"compiler/ast:Catch" %t363, ptr %t364
  %t365 = load ptr, ptr %l144, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aCatch_26_3e_2ePush_3ccompiler_2fast_3aCatch_26_3e(ptr %v1, ptr %v1, ptr %t365, ptr %t364)
  br label %bb111
bb111:
  call void @__olang_scope_close(ptr %s1)
  br label %bb112
bb112:
  br label %bb2
bb113:
  %t367 = load ptr, ptr %l2, !tbaa !29
  %t369 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aCatch_26_3e_2eToArray_3ccompiler_2fast_3aCatch_26_3e(ptr %v1, ptr %v1, ptr %t367)
  store { i64, ptr } %t369, ptr %l160
  br label %bb114
bb114:
  %t370 = load { i64, ptr }, ptr %l160, !tbaa !27
  %t371 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t370, 1
  store { i32, { i64, ptr } } %t371, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ecomprehension(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, i32 %a1, ptr %a2, ptr %a3, i32 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l3 = alloca ptr
  %l5 = alloca i1
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca ptr
  %l9 = alloca i32
  %l10 = alloca i64
  %l11 = alloca ptr
  %l15 = alloca i32
  %l17 = alloca i32
  %l18 = alloca i32
  %l24 = alloca i1
  %l26 = alloca i32
  %l28 = alloca i32
  %l29 = alloca i32
  %l33 = alloca i32
  %l36 = alloca i32
  %l37 = alloca i32
  %l43 = alloca i1
  %l45 = alloca i32
  %l48 = alloca i64
  %l50 = alloca ptr
  %l51 = alloca ptr
  %l53 = alloca ptr
  %l54 = alloca i32
  %l60 = alloca i1
  %l64 = alloca %"compiler/source:Span"
  %l68 = alloca { i64, ptr }
  %l71 = alloca ptr
  %l73 = alloca ptr
  %l74 = alloca i32
  %l81 = alloca i1
  %l82 = alloca ptr
  %l84 = alloca ptr
  %l85 = alloca i32
  %l94 = alloca %"compiler/source:Span"
  %l95 = alloca ptr
  %l96 = alloca i32
  %l97 = alloca i32
  %l102 = alloca %"compiler/ast:Compr"
  %l108 = alloca i32
  %l111 = alloca i32
  %l112 = alloca i32
  %l118 = alloca %"compiler/source:Span"
  %l119 = alloca ptr
  %l120 = alloca ptr
  %l121 = alloca i32
  %l122 = alloca i32
  %l127 = alloca %"compiler/ast:Compr"
  %rv = alloca { i32, ptr }
  %t161 = alloca { i64, [4 x i64] }, align 8
  %t249 = alloca { i64, [4 x i64] }, align 8
  %t315 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/parse:Parser", ptr %t1, i32 0, i32 22
  %t4 = load i1, ptr %t3, !tbaa !21
  store i1 %t4, ptr %l5, !tbaa !21
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/parse:Parser", ptr %t6, i32 0, i32 22
  store i1 true, ptr %t8, !tbaa !21
  store i32 0, ptr %l6, !tbaa !23
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ename(ptr %v0, ptr %t9)
  %t12 = extractvalue { i32, i32 } %t11, 1
  %t13 = extractvalue { i32, i32 } %t11, 0
  store i32 %t13, ptr %l18
  %t14 = icmp ne i32 %t13, 0
  br i1 %t14, label %bb2, label %ok.15, !prof !99
ok.15:
  store i32 %t12, ptr %l17
  br label %bb1
bb1:
  %t16 = load i32, ptr %l17, !tbaa !23
  store i32 %t16, ptr %l15, !tbaa !23
  br label %bb3
bb2:
  %t17 = load i32, ptr %l18, !tbaa !23
  %t18 = lshr i32 %t17, 16
  %t19 = and i32 %t17, 65535
  %t20 = icmp eq i32 %t18, 1
  %t21 = select i1 %t20, i32 1, i32 0
  %t22 = icmp eq i32 %t17, 0
  %t23 = shl i32 %t21, 16
  %t24 = or i32 %t23, %t19
  %t25 = select i1 %t22, i32 0, i32 %t24
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t27 = load i1, ptr %l5, !tbaa !21
  %t30 = getelementptr %"compiler/parse:Parser", ptr %t26, i32 0, i32 22
  store i1 %t27, ptr %t30, !tbaa !21
  %t32 = insertvalue { i32, ptr } zeroinitializer, i32 %t25, 0
  store { i32, ptr } %t32, ptr %rv
  br label %ret
bb3:
  %t33 = load i32, ptr %l15, !tbaa !23
  store i32 %t33, ptr %l7, !tbaa !23
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t37 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t34, i32 75)
  store i1 %t37, ptr %l24
  br label %bb4
bb4:
  %t38 = load i1, ptr %l24, !tbaa !21
  br i1 %t38, label %bb5, label %bb6
bb5:
  %t39 = load i32, ptr %l7, !tbaa !23
  store i32 %t39, ptr %l6, !tbaa !23
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ename(ptr %v0, ptr %t41)
  %t44 = extractvalue { i32, i32 } %t43, 1
  %t45 = extractvalue { i32, i32 } %t43, 0
  store i32 %t45, ptr %l29
  %t46 = icmp ne i32 %t45, 0
  br i1 %t46, label %bb8, label %ok.47, !prof !99
ok.47:
  store i32 %t44, ptr %l28
  br label %bb7
bb6:
  br label %bb10
bb7:
  %t48 = load i32, ptr %l28, !tbaa !23
  store i32 %t48, ptr %l26, !tbaa !23
  br label %bb9
bb8:
  %t49 = load i32, ptr %l29, !tbaa !23
  %t50 = lshr i32 %t49, 16
  %t51 = and i32 %t49, 65535
  %t52 = icmp eq i32 %t50, 1
  %t53 = select i1 %t52, i32 1, i32 0
  %t54 = icmp eq i32 %t49, 0
  %t55 = shl i32 %t53, 16
  %t56 = or i32 %t55, %t51
  %t57 = select i1 %t54, i32 0, i32 %t56
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = load i1, ptr %l5, !tbaa !21
  %t62 = getelementptr %"compiler/parse:Parser", ptr %t58, i32 0, i32 22
  store i1 %t59, ptr %t62, !tbaa !21
  %t64 = insertvalue { i32, ptr } zeroinitializer, i32 %t57, 0
  store { i32, ptr } %t64, ptr %rv
  br label %ret
bb9:
  %t65 = load i32, ptr %l26, !tbaa !23
  store i32 %t65, ptr %l7, !tbaa !23
  br label %bb10
bb10:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t69 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %t66, i32 27)
  %t70 = extractvalue { i32, i32 } %t69, 1
  %t71 = extractvalue { i32, i32 } %t69, 0
  store i32 %t71, ptr %l37
  %t72 = icmp ne i32 %t71, 0
  br i1 %t72, label %bb12, label %ok.73, !prof !99
ok.73:
  store i32 %t70, ptr %l36
  br label %bb11
bb11:
  %t74 = load i32, ptr %l36, !tbaa !23
  store i32 %t74, ptr %l33, !tbaa !23
  br label %bb13
bb12:
  %t75 = load i32, ptr %l37, !tbaa !23
  %t76 = lshr i32 %t75, 16
  %t77 = and i32 %t75, 65535
  %t78 = icmp eq i32 %t76, 1
  %t79 = select i1 %t78, i32 1, i32 0
  %t80 = icmp eq i32 %t75, 0
  %t81 = shl i32 %t79, 16
  %t82 = or i32 %t81, %t77
  %t83 = select i1 %t80, i32 0, i32 %t82
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t85 = load i1, ptr %l5, !tbaa !21
  %t88 = getelementptr %"compiler/parse:Parser", ptr %t84, i32 0, i32 22
  store i1 %t85, ptr %t88, !tbaa !21
  %t90 = insertvalue { i32, ptr } zeroinitializer, i32 %t83, 0
  store { i32, ptr } %t90, ptr %rv
  br label %ret
bb13:
  store ptr null, ptr %l8, !tbaa !29
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t94 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t91, i32 30)
  store i1 %t94, ptr %l43
  br label %bb14
bb14:
  %t95 = load i1, ptr %l43, !tbaa !21
  br i1 %t95, label %bb15, label %bb16
bb15:
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t96)
  store i32 %t98, ptr %l45
  br label %bb17
bb16:
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ebinary(ptr %v0, ptr %v3, ptr %t99, i64 1)
  %t102 = extractvalue { i32, ptr } %t101, 1
  %t103 = extractvalue { i32, ptr } %t101, 0
  store i32 %t103, ptr %l74
  %t104 = icmp ne i32 %t103, 0
  br i1 %t104, label %bb33, label %ok.105, !prof !99
ok.105:
  store ptr %t102, ptr %l73
  br label %bb32
bb17:
  %t106 = load i32, ptr %l45, !tbaa !23
  store i32 %t106, ptr %l9, !tbaa !23
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t109 = getelementptr %"compiler/parse:Parser", ptr %t107, i32 0, i32 34
  %t111 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2eLen_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %t109)
  store i64 %t111, ptr %l48
  br label %bb18
bb18:
  %t112 = load i64, ptr %l48, !tbaa !24
  store i64 %t112, ptr %l10, !tbaa !24
  br label %bb19
bb19:
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t115 = getelementptr %"compiler/parse:Parser", ptr %t113, i32 0, i32 34
  store ptr %t115, ptr %l50, !tbaa !29
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t118 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ebinary(ptr %v0, ptr %v0, ptr %t116, i64 1)
  %t119 = extractvalue { i32, ptr } %t118, 1
  %t120 = extractvalue { i32, ptr } %t118, 0
  store i32 %t120, ptr %l54
  %t121 = icmp ne i32 %t120, 0
  br i1 %t121, label %bb21, label %ok.122, !prof !99
ok.122:
  store ptr %t119, ptr %l53
  br label %bb20
bb20:
  %t123 = load ptr, ptr %l53, !tbaa !29
  store ptr %t123, ptr %l51, !tbaa !29
  br label %bb22
bb21:
  %t124 = load i32, ptr %l54, !tbaa !23
  %t125 = lshr i32 %t124, 16
  %t126 = and i32 %t124, 65535
  %t127 = icmp eq i32 %t125, 1
  %t128 = select i1 %t127, i32 1, i32 0
  %t129 = icmp eq i32 %t124, 0
  %t130 = shl i32 %t128, 16
  %t131 = or i32 %t130, %t126
  %t132 = select i1 %t129, i32 0, i32 %t131
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t134 = load i1, ptr %l5, !tbaa !21
  %t137 = getelementptr %"compiler/parse:Parser", ptr %t133, i32 0, i32 22
  store i1 %t134, ptr %t137, !tbaa !21
  %t139 = insertvalue { i32, ptr } zeroinitializer, i32 %t132, 0
  store { i32, ptr } %t139, ptr %rv
  br label %ret
bb22:
  %t140 = load ptr, ptr %l50, !tbaa !29
  %t141 = load ptr, ptr %l51, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2ePush_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t140, ptr %t141)
  br label %bb23
bb23:
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t145 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t142, i32 75)
  store i1 %t145, ptr %l60
  br label %bb24
bb24:
  %t146 = load i1, ptr %l60, !tbaa !21
  %t147 = xor i1 %t146, true
  br i1 %t147, label %bb25, label %bb26
bb25:
  br label %bb29
bb26:
  br label %bb27
bb27:
  br label %bb28
bb28:
  br label %bb19
bb29:
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t150 = load i32, ptr %l9, !tbaa !23
  %t153 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t149, i32 %t150)
  store %"compiler/source:Span" %t153, ptr %l64
  br label %bb30
bb30:
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t156 = getelementptr %"compiler/parse:Parser", ptr %t154, i32 0, i32 34
  %t157 = load i64, ptr %l10, !tbaa !24
  %t160 = call { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %v3, ptr %t156, i64 %t157)
  store { i64, ptr } %t160, ptr %l68
  br label %bb31
bb31:
  store { i64, [4 x i64] } zeroinitializer, ptr %t161
  %t162 = getelementptr { i64, [4 x i64] }, ptr %t161, i32 0, i32 0
  store i64 22, ptr %t162
  %t163 = load %"compiler/source:Span", ptr %l64
  %t164 = insertvalue { %"compiler/source:Span", { i64, ptr } } undef, %"compiler/source:Span" %t163, 0
  %t165 = load { i64, ptr }, ptr %l68, !tbaa !27
  %t166 = insertvalue { %"compiler/source:Span", { i64, ptr } } %t164, { i64, ptr } %t165, 1
  %t167 = getelementptr { i64, [4 x i64] }, ptr %t161, i32 0, i32 1
  store { %"compiler/source:Span", { i64, ptr } } %t166, ptr %t167
  %t168 = load { i64, [4 x i64] }, ptr %t161
  %t170 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 40, i64 8)
  store { i64, [4 x i64] } %t168, ptr %t170
  store ptr %t170, ptr %l8, !tbaa !29
  br label %bb35
bb32:
  %t172 = load ptr, ptr %l73, !tbaa !29
  store ptr %t172, ptr %l71, !tbaa !29
  br label %bb34
bb33:
  %t173 = load i32, ptr %l74, !tbaa !23
  %t174 = lshr i32 %t173, 16
  %t175 = and i32 %t173, 65535
  %t176 = icmp eq i32 %t174, 1
  %t177 = select i1 %t176, i32 1, i32 0
  %t178 = icmp eq i32 %t173, 0
  %t179 = shl i32 %t177, 16
  %t180 = or i32 %t179, %t175
  %t181 = select i1 %t178, i32 0, i32 %t180
  %t182 = load ptr, ptr %l0, !tbaa !29
  %t183 = load i1, ptr %l5, !tbaa !21
  %t186 = getelementptr %"compiler/parse:Parser", ptr %t182, i32 0, i32 22
  store i1 %t183, ptr %t186, !tbaa !21
  %t188 = insertvalue { i32, ptr } zeroinitializer, i32 %t181, 0
  store { i32, ptr } %t188, ptr %rv
  br label %ret
bb34:
  %t189 = load ptr, ptr %l71, !tbaa !29
  store ptr %t189, ptr %l8, !tbaa !29
  br label %bb35
bb35:
  store ptr null, ptr %l11, !tbaa !29
  %t191 = load ptr, ptr %l0, !tbaa !29
  %t194 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t191, i32 9)
  store i1 %t194, ptr %l81
  br label %bb36
bb36:
  %t195 = load i1, ptr %l81, !tbaa !21
  br i1 %t195, label %bb37, label %bb38
bb37:
  %t196 = load ptr, ptr %l0, !tbaa !29
  %t198 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ebinary(ptr %v0, ptr %v3, ptr %t196, i64 1)
  %t199 = extractvalue { i32, ptr } %t198, 1
  %t200 = extractvalue { i32, ptr } %t198, 0
  store i32 %t200, ptr %l85
  %t201 = icmp ne i32 %t200, 0
  br i1 %t201, label %bb40, label %ok.202, !prof !99
ok.202:
  store ptr %t199, ptr %l84
  br label %bb39
bb38:
  br label %bb42
bb39:
  %t203 = load ptr, ptr %l84, !tbaa !29
  store ptr %t203, ptr %l82, !tbaa !29
  br label %bb41
bb40:
  %t204 = load i32, ptr %l85, !tbaa !23
  %t205 = lshr i32 %t204, 16
  %t206 = and i32 %t204, 65535
  %t207 = icmp eq i32 %t205, 1
  %t208 = select i1 %t207, i32 1, i32 0
  %t209 = icmp eq i32 %t204, 0
  %t210 = shl i32 %t208, 16
  %t211 = or i32 %t210, %t206
  %t212 = select i1 %t209, i32 0, i32 %t211
  %t213 = load ptr, ptr %l0, !tbaa !29
  %t214 = load i1, ptr %l5, !tbaa !21
  %t217 = getelementptr %"compiler/parse:Parser", ptr %t213, i32 0, i32 22
  store i1 %t214, ptr %t217, !tbaa !21
  %t219 = insertvalue { i32, ptr } zeroinitializer, i32 %t212, 0
  store { i32, ptr } %t219, ptr %rv
  br label %ret
bb41:
  %t220 = load ptr, ptr %l82, !tbaa !29
  store ptr %t220, ptr %l11, !tbaa !29
  br label %bb42
bb42:
  %t224 = trunc i64 111 to i32
  %t225 = icmp eq i32 %a4, %t224
  br i1 %t225, label %bb43, label %bb44
bb43:
  %t227 = load ptr, ptr %l0, !tbaa !29
  %t228 = load i32, ptr %l1, !tbaa !23
  %t231 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t227, i32 %t228)
  store %"compiler/source:Span" %t231, ptr %l94
  br label %bb45
bb44:
  br label %bb50
bb45:
  %t232 = load ptr, ptr %l3, !tbaa !29
  store ptr %t232, ptr %l95, !tbaa !29
  %t233 = load i32, ptr %l6, !tbaa !23
  store i32 %t233, ptr %l96, !tbaa !23
  %t234 = load i32, ptr %l7, !tbaa !23
  store i32 %t234, ptr %l97, !tbaa !23
  %t235 = load ptr, ptr %l8, !tbaa !29
  %t237 = icmp eq ptr %t235, null
  br i1 %t237, label %bb46, label %bb47
bb46:
  call void @__olang_check_failed(ptr @olang_loc_562ee49de0d7f4dc_ca929e902ecee878)
  unreachable
bb47:
  br label %bb48
bb48:
  %t239 = load ptr, ptr %l8, !tbaa !29
  %t240 = load ptr, ptr %l11, !tbaa !29
  %t241 = load ptr, ptr %l95, !tbaa !29
  %t242 = load i32, ptr %l96, !tbaa !23
  %t243 = load i32, ptr %l97, !tbaa !23
  %t246 = call %"compiler/ast:Compr" @compiler_2fast_3aCompr_2ector(ptr %v3, ptr %v2, ptr %v3, ptr %v3, ptr %v3, ptr null, ptr %t241, i32 %t242, i32 %t243, ptr %t239, ptr %t240, i1 true, i64 -1)
  store %"compiler/ast:Compr" %t246, ptr %l102
  br label %bb49
bb49:
  %t247 = load %"compiler/ast:Compr", ptr %l102
  %t248 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 56, i64 8)
  store %"compiler/ast:Compr" %t247, ptr %t248
  store { i64, [4 x i64] } zeroinitializer, ptr %t249
  %t250 = getelementptr { i64, [4 x i64] }, ptr %t249, i32 0, i32 0
  store i64 18, ptr %t250
  %t251 = load %"compiler/source:Span", ptr %l94
  %t252 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t251, 0
  %t254 = insertvalue { %"compiler/source:Span", ptr } %t252, ptr %t248, 1
  %t255 = getelementptr { i64, [4 x i64] }, ptr %t249, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t254, ptr %t255
  %t256 = load { i64, [4 x i64] }, ptr %t249
  %t258 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 40, i64 8)
  store { i64, [4 x i64] } %t256, ptr %t258
  %t259 = load ptr, ptr %l0, !tbaa !29
  %t260 = load i1, ptr %l5, !tbaa !21
  %t263 = getelementptr %"compiler/parse:Parser", ptr %t259, i32 0, i32 22
  store i1 %t260, ptr %t263, !tbaa !21
  %t265 = insertvalue { i32, ptr } zeroinitializer, ptr %t258, 1
  store { i32, ptr } %t265, ptr %rv
  br label %ret
bb50:
  %t266 = load ptr, ptr %l0, !tbaa !29
  %t269 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %t266, i32 113)
  %t270 = extractvalue { i32, i32 } %t269, 1
  %t271 = extractvalue { i32, i32 } %t269, 0
  store i32 %t271, ptr %l112
  %t272 = icmp ne i32 %t271, 0
  br i1 %t272, label %bb52, label %ok.273, !prof !99
ok.273:
  store i32 %t270, ptr %l111
  br label %bb51
bb51:
  %t274 = load i32, ptr %l111, !tbaa !23
  store i32 %t274, ptr %l108, !tbaa !23
  br label %bb53
bb52:
  %t275 = load i32, ptr %l112, !tbaa !23
  %t276 = lshr i32 %t275, 16
  %t277 = and i32 %t275, 65535
  %t278 = icmp eq i32 %t276, 1
  %t279 = select i1 %t278, i32 1, i32 0
  %t280 = icmp eq i32 %t275, 0
  %t281 = shl i32 %t279, 16
  %t282 = or i32 %t281, %t277
  %t283 = select i1 %t280, i32 0, i32 %t282
  %t284 = load ptr, ptr %l0, !tbaa !29
  %t285 = load i1, ptr %l5, !tbaa !21
  %t288 = getelementptr %"compiler/parse:Parser", ptr %t284, i32 0, i32 22
  store i1 %t285, ptr %t288, !tbaa !21
  %t290 = insertvalue { i32, ptr } zeroinitializer, i32 %t283, 0
  store { i32, ptr } %t290, ptr %rv
  br label %ret
bb53:
  %t291 = load ptr, ptr %l0, !tbaa !29
  %t292 = load i32, ptr %l1, !tbaa !23
  %t295 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t291, i32 %t292)
  store %"compiler/source:Span" %t295, ptr %l118
  br label %bb54
bb54:
  store ptr %a2, ptr %l119, !tbaa !29
  %t297 = load ptr, ptr %l3, !tbaa !29
  store ptr %t297, ptr %l120, !tbaa !29
  %t298 = load i32, ptr %l6, !tbaa !23
  store i32 %t298, ptr %l121, !tbaa !23
  %t299 = load i32, ptr %l7, !tbaa !23
  store i32 %t299, ptr %l122, !tbaa !23
  %t300 = load ptr, ptr %l8, !tbaa !29
  %t302 = icmp eq ptr %t300, null
  br i1 %t302, label %bb55, label %bb56
bb55:
  call void @__olang_check_failed(ptr @olang_loc_8028beeed4c0afcb_93e9486db4deb497)
  unreachable
bb56:
  br label %bb57
bb57:
  %t304 = load ptr, ptr %l8, !tbaa !29
  %t305 = load ptr, ptr %l11, !tbaa !29
  %t306 = load ptr, ptr %l119, !tbaa !29
  %t307 = load ptr, ptr %l120, !tbaa !29
  %t308 = load i32, ptr %l121, !tbaa !23
  %t309 = load i32, ptr %l122, !tbaa !23
  %t312 = call %"compiler/ast:Compr" @compiler_2fast_3aCompr_2ector(ptr %v1, ptr %v2, ptr %v3, ptr %v3, ptr %v3, ptr %t306, ptr %t307, i32 %t308, i32 %t309, ptr %t304, ptr %t305, i1 false, i64 -1)
  store %"compiler/ast:Compr" %t312, ptr %l127
  br label %bb58
bb58:
  %t313 = load %"compiler/ast:Compr", ptr %l127
  %t314 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 56, i64 8)
  store %"compiler/ast:Compr" %t313, ptr %t314
  store { i64, [4 x i64] } zeroinitializer, ptr %t315
  %t316 = getelementptr { i64, [4 x i64] }, ptr %t315, i32 0, i32 0
  store i64 18, ptr %t316
  %t317 = load %"compiler/source:Span", ptr %l118
  %t318 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t317, 0
  %t320 = insertvalue { %"compiler/source:Span", ptr } %t318, ptr %t314, 1
  %t321 = getelementptr { i64, [4 x i64] }, ptr %t315, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t320, ptr %t321
  %t322 = load { i64, [4 x i64] }, ptr %t315
  %t324 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 40, i64 8)
  store { i64, [4 x i64] } %t322, ptr %t324
  %t325 = load ptr, ptr %l0, !tbaa !29
  %t326 = load i1, ptr %l5, !tbaa !21
  %t329 = getelementptr %"compiler/parse:Parser", ptr %t325, i32 0, i32 22
  store i1 %t326, ptr %t329, !tbaa !21
  %t331 = insertvalue { i32, ptr } zeroinitializer, ptr %t324, 1
  store { i32, ptr } %t331, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2econdFrom(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l6 = alloca i1
  %l8 = alloca i1
  %l12 = alloca i1
  %l14 = alloca i1
  %l17 = alloca i32
  %l18 = alloca ptr
  %l20 = alloca ptr
  %l21 = alloca i32
  %l23 = alloca i32
  %l26 = alloca i32
  %l27 = alloca i32
  %l29 = alloca ptr
  %l31 = alloca ptr
  %l32 = alloca i32
  %l35 = alloca %"compiler/source:Span"
  %l39 = alloca %"compiler/source:Span"
  %rv = alloca { i32, ptr }
  %t102 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t4 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t1, i32 9)
  store i1 %t4, ptr %l6
  br label %bb1
bb1:
  %t5 = load i1, ptr %l6, !tbaa !21
  %t6 = xor i1 %t5, true
  br i1 %t6, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb8
bb3:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/parse:Parser", ptr %t8, i32 0, i32 21
  %t11 = load i64, ptr %t10, !tbaa !24
  %t13 = icmp eq i64 %t11, 0
  br i1 %t13, label %bb4, label %bb5
bb4:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ebreakBefore(ptr %v0, ptr %t15)
  store i1 %t17, ptr %l14
  br label %bb6
bb5:
  store i1 false, ptr %l12, !tbaa !21
  br label %bb7
bb6:
  %t18 = load i1, ptr %l14, !tbaa !21
  store i1 %t18, ptr %l12, !tbaa !21
  br label %bb7
bb7:
  %t19 = load i1, ptr %l12, !tbaa !21
  store i1 %t19, ptr %l8, !tbaa !21
  br label %bb8
bb8:
  %t20 = load i1, ptr %l8, !tbaa !21
  br i1 %t20, label %bb9, label %bb10
bb9:
  %t21 = load ptr, ptr %l1, !tbaa !29
  %t23 = insertvalue { i32, ptr } zeroinitializer, ptr %t21, 1
  store { i32, ptr } %t23, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t24)
  store i32 %t26, ptr %l17
  br label %bb12
bb12:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ebinary(ptr %v0, ptr %v2, ptr %t27, i64 1)
  %t30 = extractvalue { i32, ptr } %t29, 1
  %t31 = extractvalue { i32, ptr } %t29, 0
  store i32 %t31, ptr %l21
  %t32 = icmp ne i32 %t31, 0
  br i1 %t32, label %bb14, label %ok.33, !prof !99
ok.33:
  store ptr %t30, ptr %l20
  br label %bb13
bb13:
  %t34 = load ptr, ptr %l20, !tbaa !29
  store ptr %t34, ptr %l18, !tbaa !29
  br label %bb15
bb14:
  %t35 = load i32, ptr %l21, !tbaa !23
  %t36 = lshr i32 %t35, 16
  %t37 = and i32 %t35, 65535
  %t38 = icmp eq i32 %t36, 1
  %t39 = select i1 %t38, i32 1, i32 0
  %t40 = icmp eq i32 %t35, 0
  %t41 = shl i32 %t39, 16
  %t42 = or i32 %t41, %t37
  %t43 = select i1 %t40, i32 0, i32 %t42
  %t45 = insertvalue { i32, ptr } zeroinitializer, i32 %t43, 0
  store { i32, ptr } %t45, ptr %rv
  br label %ret
bb15:
  %t46 = load ptr, ptr %l18, !tbaa !29
  store ptr %t46, ptr %l2, !tbaa !29
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t50 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %t47, i32 10)
  %t51 = extractvalue { i32, i32 } %t50, 1
  %t52 = extractvalue { i32, i32 } %t50, 0
  store i32 %t52, ptr %l27
  %t53 = icmp ne i32 %t52, 0
  br i1 %t53, label %bb17, label %ok.54, !prof !99
ok.54:
  store i32 %t51, ptr %l26
  br label %bb16
bb16:
  %t55 = load i32, ptr %l26, !tbaa !23
  store i32 %t55, ptr %l23, !tbaa !23
  br label %bb18
bb17:
  %t56 = load i32, ptr %l27, !tbaa !23
  %t57 = lshr i32 %t56, 16
  %t58 = and i32 %t56, 65535
  %t59 = icmp eq i32 %t57, 1
  %t60 = select i1 %t59, i32 1, i32 0
  %t61 = icmp eq i32 %t56, 0
  %t62 = shl i32 %t60, 16
  %t63 = or i32 %t62, %t58
  %t64 = select i1 %t61, i32 0, i32 %t63
  %t66 = insertvalue { i32, ptr } zeroinitializer, i32 %t64, 0
  store { i32, ptr } %t66, ptr %rv
  br label %ret
bb18:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexpr(ptr %v0, ptr %v2, ptr %t67)
  %t70 = extractvalue { i32, ptr } %t69, 1
  %t71 = extractvalue { i32, ptr } %t69, 0
  store i32 %t71, ptr %l32
  %t72 = icmp ne i32 %t71, 0
  br i1 %t72, label %bb20, label %ok.73, !prof !99
ok.73:
  store ptr %t70, ptr %l31
  br label %bb19
bb19:
  %t74 = load ptr, ptr %l31, !tbaa !29
  store ptr %t74, ptr %l29, !tbaa !29
  br label %bb21
bb20:
  %t75 = load i32, ptr %l32, !tbaa !23
  %t76 = lshr i32 %t75, 16
  %t77 = and i32 %t75, 65535
  %t78 = icmp eq i32 %t76, 1
  %t79 = select i1 %t78, i32 1, i32 0
  %t80 = icmp eq i32 %t75, 0
  %t81 = shl i32 %t79, 16
  %t82 = or i32 %t81, %t77
  %t83 = select i1 %t80, i32 0, i32 %t82
  %t85 = insertvalue { i32, ptr } zeroinitializer, i32 %t83, 0
  store { i32, ptr } %t85, ptr %rv
  br label %ret
bb21:
  %t86 = load ptr, ptr %l29, !tbaa !29
  store ptr %t86, ptr %l3, !tbaa !29
  %t87 = load ptr, ptr %l1, !tbaa !29
  %t89 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t87)
  store %"compiler/source:Span" %t89, ptr %l35
  br label %bb22
bb22:
  %t90 = getelementptr %"compiler/source:Span", ptr %l35, i32 0, i32 0
  %t91 = load i32, ptr %t90, !tbaa !23
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"compiler/parse:Parser", ptr %t92, i32 0, i32 10
  %t95 = load i32, ptr %t94, !tbaa !23
  %t98 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v2, i32 %t91, i32 %t95)
  store %"compiler/source:Span" %t98, ptr %l39
  br label %bb23
bb23:
  %t99 = load ptr, ptr %l1, !tbaa !29
  %t100 = load ptr, ptr %l2, !tbaa !29
  %t101 = load ptr, ptr %l3, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t102
  %t103 = getelementptr { i64, [4 x i64] }, ptr %t102, i32 0, i32 0
  store i64 8, ptr %t103
  %t104 = load %"compiler/source:Span", ptr %l39
  %t105 = insertvalue { %"compiler/source:Span", ptr, ptr, ptr } undef, %"compiler/source:Span" %t104, 0
  %t107 = insertvalue { %"compiler/source:Span", ptr, ptr, ptr } %t105, ptr %t99, 1
  %t109 = insertvalue { %"compiler/source:Span", ptr, ptr, ptr } %t107, ptr %t100, 2
  %t111 = insertvalue { %"compiler/source:Span", ptr, ptr, ptr } %t109, ptr %t101, 3
  %t112 = getelementptr { i64, [4 x i64] }, ptr %t102, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr, ptr } %t111, ptr %t112
  %t113 = load { i64, [4 x i64] }, ptr %t102
  %t115 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 40, i64 8)
  store { i64, [4 x i64] } %t113, ptr %t115
  %t117 = insertvalue { i32, ptr } zeroinitializer, ptr %t115, 1
  store { i32, ptr } %t117, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ecountDiag(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l1 = alloca ptr
  %l3 = alloca %"compiler/source:Span"
  %l5 = alloca { i64, ptr }
  %l7 = alloca ptr
  %l8 = alloca i32
  %l9 = alloca i32
  %l14 = alloca %"compiler/diagmsg:Msg"
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/parse:NameList", ptr %t1, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l5, !tbaa !27
  %t5 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t6 = load ptr, ptr %t5, !tbaa !27
  %t7 = getelementptr %"compiler/source:Span", ptr %t6, i64 0
  %t8 = load %"compiler/source:Span", ptr %t7
  store %"compiler/source:Span" %t8, ptr %l3
  store ptr %a0, ptr %l7, !tbaa !29
  %t11 = getelementptr %"compiler/source:Span", ptr %l3, i32 0, i32 0
  %t12 = load i32, ptr %t11, !tbaa !23
  store i32 %t12, ptr %l8, !tbaa !23
  %t13 = getelementptr %"compiler/source:Span", ptr %l3, i32 0, i32 1
  %t14 = load i32, ptr %t13, !tbaa !23
  store i32 %t14, ptr %l9, !tbaa !23
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t17 = getelementptr %"compiler/parse:NameList", ptr %t15, i32 0, i32 0
  %t18 = load { i64, ptr }, ptr %t17, !tbaa !27
  %t20 = extractvalue { i64, ptr } %t18, 0
  %t24 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eVarListCount(ptr %v0, i64 %t20, i64 %a2)
  store %"compiler/diagmsg:Msg" %t24, ptr %l14
  br label %bb1
bb1:
  %t25 = load ptr, ptr %l7, !tbaa !29
  %t26 = load i32, ptr %l8, !tbaa !23
  %t27 = load i32, ptr %l9, !tbaa !23
  %t28 = load %"compiler/diagmsg:Msg", ptr %l14
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereport(ptr %v0, ptr %v0, ptr %t25, i32 %t26, i32 %t27, %"compiler/diagmsg:Msg" %t28)
  br label %bb2
bb2:
  br label %ret
ret:
  ret void
}

define dso_local { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ectorBlock(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i1
  %l5 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i32
  %l11 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca i32
  %rv = alloca { i32, { i64, ptr } }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t4 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t1, i32 79)
  store i1 %t4, ptr %l3
  br label %bb1
bb1:
  %t5 = load i1, ptr %l3, !tbaa !21
  %t6 = xor i1 %t5, true
  br i1 %t6, label %bb2, label %bb3
bb2:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eblock(ptr %v0, ptr %v1, ptr %t8)
  %t11 = extractvalue { i32, { i64, ptr } } %t10, 1
  %t12 = extractvalue { i32, { i64, ptr } } %t10, 0
  store i32 %t12, ptr %l8
  %t13 = icmp ne i32 %t12, 0
  br i1 %t13, label %bb5, label %ok.14, !prof !99
ok.14:
  store { i64, ptr } %t11, ptr %l7
  br label %bb4
bb3:
  br label %bb7
bb4:
  %t15 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t15, ptr %l5, !tbaa !27
  br label %bb6
bb5:
  %t16 = load i32, ptr %l8, !tbaa !23
  %t17 = lshr i32 %t16, 16
  %t18 = and i32 %t16, 65535
  %t19 = icmp eq i32 %t17, 1
  %t20 = select i1 %t19, i32 1, i32 0
  %t21 = icmp eq i32 %t16, 0
  %t22 = shl i32 %t20, 16
  %t23 = or i32 %t22, %t18
  %t24 = select i1 %t21, i32 0, i32 %t23
  %t26 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t24, 0
  store { i32, { i64, ptr } } %t26, ptr %rv
  br label %ret
bb6:
  %t27 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t28 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t27, 1
  store { i32, { i64, ptr } } %t28, ptr %rv
  br label %ret
bb7:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/parse:Parser", ptr %t29, i32 0, i32 20
  store i1 false, ptr %t31, !tbaa !21
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2elineBody(ptr %v0, ptr %v1, ptr %t32, i1 true)
  %t35 = extractvalue { i32, { i64, ptr } } %t34, 1
  %t36 = extractvalue { i32, { i64, ptr } } %t34, 0
  store i32 %t36, ptr %l14
  %t37 = icmp ne i32 %t36, 0
  br i1 %t37, label %bb9, label %ok.38, !prof !99
ok.38:
  store { i64, ptr } %t35, ptr %l13
  br label %bb8
bb8:
  %t39 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t39, ptr %l11, !tbaa !27
  br label %bb10
bb9:
  %t40 = load i32, ptr %l14, !tbaa !23
  %t41 = lshr i32 %t40, 16
  %t42 = and i32 %t40, 65535
  %t43 = icmp eq i32 %t41, 1
  %t44 = select i1 %t43, i32 1, i32 0
  %t45 = icmp eq i32 %t40, 0
  %t46 = shl i32 %t44, 16
  %t47 = or i32 %t46, %t42
  %t48 = select i1 %t45, i32 0, i32 %t47
  %t50 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t48, 0
  store { i32, { i64, ptr } } %t50, ptr %rv
  br label %ret
bb10:
  %t51 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t52 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t51, 1
  store { i32, { i64, ptr } } %t52, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2edecl(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca %"compiler/token:Token"
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca %"compiler/source:Span"
  %l8 = alloca i32
  %l9 = alloca %"compiler/source:Span"
  %l10 = alloca %"compiler/source:Span"
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca %"compiler/token:Token"
  %l14 = alloca { i64, ptr }
  %l15 = alloca ptr
  %l16 = alloca ptr
  %l17 = alloca %"compiler/source:Span"
  %l18 = alloca ptr
  %l19 = alloca %"compiler/token:Token"
  %l20 = alloca i32
  %l21 = alloca ptr
  %l22 = alloca %"compiler/source:Span"
  %l23 = alloca ptr
  %l24 = alloca %"compiler/source:Span"
  %l26 = alloca i32
  %l28 = alloca i32
  %l32 = alloca i32
  %l35 = alloca i1
  %l36 = alloca i32
  %l38 = alloca i32
  %l39 = alloca i32
  %l43 = alloca i1
  %l45 = alloca ptr
  %l47 = alloca { i64, ptr }
  %l49 = alloca i32
  %l52 = alloca %"compiler/token:Token"
  %l54 = alloca i32
  %l55 = alloca %"compiler/source:Span"
  %l57 = alloca %"compiler/source:Span"
  %l58 = alloca i32
  %l62 = alloca %"compiler/source:Span"
  %l64 = alloca i32
  %l66 = alloca %"compiler/source:Span"
  %l67 = alloca i32
  %l70 = alloca %"compiler/source:Span"
  %l76 = alloca ptr
  %l78 = alloca ptr
  %l79 = alloca i32
  %l84 = alloca ptr
  %l86 = alloca ptr
  %l87 = alloca i32
  %l95 = alloca i32
  %l98 = alloca i1
  %l100 = alloca i32
  %l101 = alloca i32
  %l103 = alloca i32
  %l104 = alloca i32
  %l108 = alloca %"compiler/source:Span"
  %l110 = alloca i32
  %l112 = alloca %"compiler/source:Span"
  %l113 = alloca i32
  %l120 = alloca %"compiler/ast:TypeDecl"
  %l124 = alloca %"compiler/source:Span"
  %l126 = alloca %"compiler/source:Span"
  %l127 = alloca i32
  %l131 = alloca i1
  %l132 = alloca ptr
  %l136 = alloca ptr
  %l137 = alloca i32
  %l142 = alloca ptr
  %l144 = alloca { i64, ptr }
  %l146 = alloca i32
  %l148 = alloca ptr
  %l151 = alloca ptr
  %l152 = alloca i32
  %l155 = alloca i32
  %l163 = alloca i32
  %l166 = alloca i1
  %l167 = alloca ptr
  %l169 = alloca ptr
  %l170 = alloca i32
  %l175 = alloca i1
  %l177 = alloca ptr
  %l179 = alloca { i64, ptr }
  %l181 = alloca i32
  %l184 = alloca %"compiler/token:Token"
  %l186 = alloca i32
  %l187 = alloca { i64, ptr }
  %l189 = alloca { i64, ptr }
  %l190 = alloca i32
  %l194 = alloca %"compiler/source:Span"
  %l197 = alloca %"compiler/source:Span"
  %l204 = alloca ptr
  %l206 = alloca ptr
  %l207 = alloca i32
  %l213 = alloca i32
  %l214 = alloca ptr
  %l216 = alloca ptr
  %l217 = alloca i32
  %l221 = alloca i1
  %l222 = alloca ptr
  %l224 = alloca ptr
  %l225 = alloca i32
  %l230 = alloca %"compiler/source:Span"
  %l232 = alloca i32
  %l241 = alloca ptr
  %l243 = alloca %"compiler/token:Token"
  %l244 = alloca { i64, ptr }
  %l245 = alloca i1
  %l246 = alloca i1
  %l248 = alloca i32
  %l252 = alloca i32
  %l253 = alloca ptr
  %l255 = alloca ptr
  %l256 = alloca i32
  %l260 = alloca %"compiler/source:Span"
  %l277 = alloca %"compiler/ast:Func"
  %l282 = alloca i32
  %l286 = alloca %"compiler/token:Token"
  %l287 = alloca i32
  %l289 = alloca i32
  %l290 = alloca i32
  %l293 = alloca i32
  %l294 = alloca ptr
  %l296 = alloca ptr
  %l297 = alloca i32
  %l301 = alloca %"compiler/source:Span"
  %l303 = alloca i32
  %l305 = alloca %"compiler/source:Span"
  %l308 = alloca %"compiler/source:Span"
  %l315 = alloca ptr
  %l317 = alloca ptr
  %l318 = alloca i32
  %l322 = alloca %"compiler/source:Span"
  %l324 = alloca i32
  %l331 = alloca i32
  %s3 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %rv = alloca { i32, ptr }
  %t128 = alloca { i64, [8 x i64] }, align 8
  %t197 = alloca { i64, [8 x i64] }, align 8
  %t274 = alloca { i64, [6 x i64] }, align 8
  %t286 = alloca { i64, [8 x i64] }, align 8
  %t413 = alloca { i64, [8 x i64] }, align 8
  %t525 = alloca { i64, [8 x i64] }, align 8
  %t647 = alloca { i64, [8 x i64] }, align 8
  %t757 = alloca { i64, [8 x i64] }, align 8
  %t853 = alloca { i64, [4 x i64] }, align 8
  %t864 = alloca { i64, [8 x i64] }, align 8
  %t922 = alloca { i64, [8 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ehere(ptr %v0, ptr %t1)
  store i32 %t3, ptr %l26
  br label %bb1
bb1:
  %t4 = load i32, ptr %l26, !tbaa !23
  store i32 %t4, ptr %l1, !tbaa !23
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2epeek(ptr %v0, ptr %t5)
  store i32 %t7, ptr %l28
  br label %bb2
bb2:
  %t8 = load i32, ptr %l28, !range !{i32 0, i32 116}
  store i32 %t8, ptr %l2
  %t9 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t11 = trunc i64 40 to i32
  %t12 = icmp eq i32 %t9, %t11
  br i1 %t12, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb32
bb5:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t14)
  store i32 %t16, ptr %l32
  br label %bb6
bb6:
  store i32 0, ptr %l3, !tbaa !23
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t20 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t17, i32 1)
  store i1 %t20, ptr %l35
  br label %bb7
bb7:
  %t21 = load i1, ptr %l35, !tbaa !21
  br i1 %t21, label %bb8, label %bb9
bb8:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ename(ptr %v0, ptr %t22)
  %t25 = extractvalue { i32, i32 } %t24, 1
  %t26 = extractvalue { i32, i32 } %t24, 0
  store i32 %t26, ptr %l39
  %t27 = icmp ne i32 %t26, 0
  br i1 %t27, label %bb11, label %ok.28, !prof !99
ok.28:
  store i32 %t25, ptr %l38
  br label %bb10
bb9:
  br label %bb13
bb10:
  %t29 = load i32, ptr %l38, !tbaa !23
  store i32 %t29, ptr %l36, !tbaa !23
  br label %bb12
bb11:
  %t30 = load i32, ptr %l39, !tbaa !23
  %t31 = lshr i32 %t30, 16
  %t32 = and i32 %t30, 65535
  %t33 = icmp eq i32 %t31, 1
  %t34 = select i1 %t33, i32 1, i32 0
  %t35 = icmp eq i32 %t30, 0
  %t36 = shl i32 %t34, 16
  %t37 = or i32 %t36, %t32
  %t38 = select i1 %t35, i32 0, i32 %t37
  %t40 = insertvalue { i32, ptr } zeroinitializer, i32 %t38, 0
  store { i32, ptr } %t40, ptr %rv
  br label %ret
bb12:
  %t41 = load i32, ptr %l36, !tbaa !23
  store i32 %t41, ptr %l3, !tbaa !23
  br label %bb13
bb13:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t45 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t42, i32 5)
  store i1 %t45, ptr %l43
  br label %bb14
bb14:
  %t46 = load i1, ptr %l43, !tbaa !21
  %t47 = xor i1 %t46, true
  br i1 %t47, label %bb15, label %bb16
bb15:
  store %olang.scope zeroinitializer, ptr %s3
  %t49 = load ptr, ptr %l0, !tbaa !29
  store ptr %t49, ptr %l45, !tbaa !29
  %t51 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eDescribe(ptr %s3, i32 5)
  store { i64, ptr } %t51, ptr %l47
  br label %bb17
bb16:
  br label %bb21
bb17:
  %t52 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t53 = load ptr, ptr %l45, !tbaa !29
  %t55 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2efail(ptr %v0, ptr %s3, ptr %t53, { i64, ptr } %t52)
  store i32 %t55, ptr %l49
  %t56 = icmp ne i32 %t55, 0
  br i1 %t56, label %bb19, label %ok.57, !prof !99
ok.57:
  br label %bb18
bb18:
  br label %bb20
bb19:
  %t58 = load i32, ptr %l49, !tbaa !23
  %t59 = lshr i32 %t58, 16
  %t60 = and i32 %t58, 65535
  %t61 = icmp eq i32 %t59, 1
  %t62 = select i1 %t61, i32 1, i32 0
  %t63 = icmp eq i32 %t58, 0
  %t64 = shl i32 %t62, 16
  %t65 = or i32 %t64, %t60
  %t66 = select i1 %t63, i32 0, i32 %t65
  call void @__olang_scope_close(ptr %s3)
  %t68 = insertvalue { i32, ptr } zeroinitializer, i32 %t66, 0
  store { i32, ptr } %t68, ptr %rv
  br label %ret
bb20:
  call void @__olang_scope_close(ptr %s3)
  br label %bb21
bb21:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2etk(ptr %v0, ptr %t69)
  store %"compiler/token:Token" %t71, ptr %l52
  br label %bb22
bb22:
  %t72 = load %"compiler/token:Token", ptr %l52
  store %"compiler/token:Token" %t72, ptr %l4
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t73)
  store i32 %t75, ptr %l54
  br label %bb23
bb23:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = call { i32, %"compiler/source:Span" } @compiler_2fparse_2ecompiler_2fparse_3aParser_2elinkClause(ptr %v0, ptr %t76)
  %t79 = extractvalue { i32, %"compiler/source:Span" } %t78, 1
  %t80 = extractvalue { i32, %"compiler/source:Span" } %t78, 0
  store i32 %t80, ptr %l58
  %t81 = icmp ne i32 %t80, 0
  br i1 %t81, label %bb25, label %ok.82, !prof !99
ok.82:
  store %"compiler/source:Span" %t79, ptr %l57
  br label %bb24
bb24:
  %t83 = load %"compiler/source:Span", ptr %l57
  store %"compiler/source:Span" %t83, ptr %l55
  br label %bb26
bb25:
  %t84 = load i32, ptr %l58, !tbaa !23
  %t85 = lshr i32 %t84, 16
  %t86 = and i32 %t84, 65535
  %t87 = icmp eq i32 %t85, 1
  %t88 = select i1 %t87, i32 1, i32 0
  %t89 = icmp eq i32 %t84, 0
  %t90 = shl i32 %t88, 16
  %t91 = or i32 %t90, %t86
  %t92 = select i1 %t89, i32 0, i32 %t91
  %t94 = insertvalue { i32, ptr } zeroinitializer, i32 %t92, 0
  store { i32, ptr } %t94, ptr %rv
  br label %ret
bb26:
  %t95 = load %"compiler/source:Span", ptr %l55
  store %"compiler/source:Span" %t95, ptr %l5
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t97 = load i32, ptr %l1, !tbaa !23
  %t100 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t96, i32 %t97)
  store %"compiler/source:Span" %t100, ptr %l62
  br label %bb27
bb27:
  %t101 = load %"compiler/source:Span", ptr %l62
  store %"compiler/source:Span" %t101, ptr %l6
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eendStmt(ptr %v0, ptr %t102)
  store i32 %t104, ptr %l64
  %t105 = icmp ne i32 %t104, 0
  br i1 %t105, label %bb29, label %ok.106, !prof !99
ok.106:
  br label %bb28
bb28:
  br label %bb30
bb29:
  %t107 = load i32, ptr %l64, !tbaa !23
  %t108 = lshr i32 %t107, 16
  %t109 = and i32 %t107, 65535
  %t110 = icmp eq i32 %t108, 1
  %t111 = select i1 %t110, i32 1, i32 0
  %t112 = icmp eq i32 %t107, 0
  %t113 = shl i32 %t111, 16
  %t114 = or i32 %t113, %t109
  %t115 = select i1 %t112, i32 0, i32 %t114
  %t117 = insertvalue { i32, ptr } zeroinitializer, i32 %t115, 0
  store { i32, ptr } %t117, ptr %rv
  br label %ret
bb30:
  %t118 = load %"compiler/source:Span", ptr %l6
  store %"compiler/source:Span" %t118, ptr %l66
  %t119 = load i32, ptr %l3, !tbaa !23
  store i32 %t119, ptr %l67, !tbaa !23
  %t120 = getelementptr %"compiler/token:Token", ptr %l4, i32 0, i32 2
  %t121 = load i32, ptr %t120, !tbaa !23
  %t122 = getelementptr %"compiler/token:Token", ptr %l4, i32 0, i32 3
  %t123 = load i32, ptr %t122, !tbaa !23
  %t126 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v1, i32 %t121, i32 %t123)
  store %"compiler/source:Span" %t126, ptr %l70
  br label %bb31
bb31:
  %t127 = load %"compiler/source:Span", ptr %l5
  store { i64, [8 x i64] } zeroinitializer, ptr %t128
  %t129 = getelementptr { i64, [8 x i64] }, ptr %t128, i32 0, i32 0
  store i64 5, ptr %t129
  %t130 = load %"compiler/source:Span", ptr %l66
  %t131 = insertvalue { %"compiler/source:Span", i32, %"compiler/source:Span", %"compiler/source:Span" } undef, %"compiler/source:Span" %t130, 0
  %t132 = load i32, ptr %l67, !tbaa !23
  %t133 = insertvalue { %"compiler/source:Span", i32, %"compiler/source:Span", %"compiler/source:Span" } %t131, i32 %t132, 1
  %t134 = load %"compiler/source:Span", ptr %l70
  %t135 = insertvalue { %"compiler/source:Span", i32, %"compiler/source:Span", %"compiler/source:Span" } %t133, %"compiler/source:Span" %t134, 2
  %t137 = insertvalue { %"compiler/source:Span", i32, %"compiler/source:Span", %"compiler/source:Span" } %t135, %"compiler/source:Span" %t127, 3
  %t138 = getelementptr { i64, [8 x i64] }, ptr %t128, i32 0, i32 1
  store { %"compiler/source:Span", i32, %"compiler/source:Span", %"compiler/source:Span" } %t137, ptr %t138
  %t139 = load { i64, [8 x i64] }, ptr %t128
  %t141 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 72, i64 8)
  store { i64, [8 x i64] } %t139, ptr %t141
  %t143 = insertvalue { i32, ptr } zeroinitializer, ptr %t141, 1
  store { i32, ptr } %t143, ptr %rv
  br label %ret
bb32:
  %t144 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t146 = trunc i64 33 to i32
  %t147 = icmp eq i32 %t144, %t146
  br i1 %t147, label %bb33, label %bb34
bb33:
  br label %bb35
bb34:
  br label %bb39
bb35:
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t151 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeDecl(ptr %v0, ptr %v1, ptr %t149)
  %t152 = extractvalue { i32, ptr } %t151, 1
  %t153 = extractvalue { i32, ptr } %t151, 0
  store i32 %t153, ptr %l79
  %t154 = icmp ne i32 %t153, 0
  br i1 %t154, label %bb37, label %ok.155, !prof !99
ok.155:
  store ptr %t152, ptr %l78
  br label %bb36
bb36:
  %t156 = load ptr, ptr %l78, !tbaa !29
  store ptr %t156, ptr %l76, !tbaa !29
  br label %bb38
bb37:
  %t157 = load i32, ptr %l79, !tbaa !23
  %t158 = lshr i32 %t157, 16
  %t159 = and i32 %t157, 65535
  %t160 = icmp eq i32 %t158, 1
  %t161 = select i1 %t160, i32 1, i32 0
  %t162 = icmp eq i32 %t157, 0
  %t163 = shl i32 %t161, 16
  %t164 = or i32 %t163, %t159
  %t165 = select i1 %t162, i32 0, i32 %t164
  %t167 = insertvalue { i32, ptr } zeroinitializer, i32 %t165, 0
  store { i32, ptr } %t167, ptr %rv
  br label %ret
bb38:
  %t168 = load ptr, ptr %l76, !tbaa !29
  %t170 = insertvalue { i32, ptr } zeroinitializer, ptr %t168, 1
  store { i32, ptr } %t170, ptr %rv
  br label %ret
bb39:
  %t171 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t173 = trunc i64 37 to i32
  %t174 = icmp eq i32 %t171, %t173
  br i1 %t174, label %bb40, label %bb41
bb40:
  br label %bb42
bb41:
  br label %bb46
bb42:
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t178 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2efunction(ptr %v0, ptr %v1, ptr %t176)
  %t179 = extractvalue { i32, ptr } %t178, 1
  %t180 = extractvalue { i32, ptr } %t178, 0
  store i32 %t180, ptr %l87
  %t181 = icmp ne i32 %t180, 0
  br i1 %t181, label %bb44, label %ok.182, !prof !99
ok.182:
  store ptr %t179, ptr %l86
  br label %bb43
bb43:
  %t183 = load ptr, ptr %l86, !tbaa !29
  store ptr %t183, ptr %l84, !tbaa !29
  br label %bb45
bb44:
  %t184 = load i32, ptr %l87, !tbaa !23
  %t185 = lshr i32 %t184, 16
  %t186 = and i32 %t184, 65535
  %t187 = icmp eq i32 %t185, 1
  %t188 = select i1 %t187, i32 1, i32 0
  %t189 = icmp eq i32 %t184, 0
  %t190 = shl i32 %t188, 16
  %t191 = or i32 %t190, %t186
  %t192 = select i1 %t189, i32 0, i32 %t191
  %t194 = insertvalue { i32, ptr } zeroinitializer, i32 %t192, 0
  store { i32, ptr } %t194, ptr %rv
  br label %ret
bb45:
  %t195 = load ptr, ptr %l84, !tbaa !29
  store { i64, [8 x i64] } zeroinitializer, ptr %t197
  %t198 = getelementptr { i64, [8 x i64] }, ptr %t197, i32 0, i32 0
  store i64 0, ptr %t198
  %t200 = insertvalue { ptr } undef, ptr %t195, 0
  %t201 = getelementptr { i64, [8 x i64] }, ptr %t197, i32 0, i32 1
  store { ptr } %t200, ptr %t201
  %t202 = load { i64, [8 x i64] }, ptr %t197
  %t204 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 72, i64 8)
  store { i64, [8 x i64] } %t202, ptr %t204
  %t206 = insertvalue { i32, ptr } zeroinitializer, ptr %t204, 1
  store { i32, ptr } %t206, ptr %rv
  br label %ret
bb46:
  %t207 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t209 = trunc i64 43 to i32
  %t210 = icmp eq i32 %t207, %t209
  br i1 %t210, label %bb47, label %bb48
bb47:
  br label %bb49
bb48:
  br label %bb91
bb49:
  %t212 = load ptr, ptr %l0, !tbaa !29
  %t214 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t212)
  store i32 %t214, ptr %l95
  br label %bb50
bb50:
  %t215 = load ptr, ptr %l0, !tbaa !29
  %t218 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t215, i32 33)
  store i1 %t218, ptr %l98
  br label %bb51
bb51:
  %t219 = load i1, ptr %l98, !tbaa !21
  br i1 %t219, label %bb52, label %bb53
bb52:
  %t220 = load ptr, ptr %l0, !tbaa !29
  %t222 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t220)
  store i32 %t222, ptr %l100
  br label %bb54
bb53:
  br label %bb67
bb54:
  %t223 = load ptr, ptr %l0, !tbaa !29
  %t225 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ename(ptr %v0, ptr %t223)
  %t226 = extractvalue { i32, i32 } %t225, 1
  %t227 = extractvalue { i32, i32 } %t225, 0
  store i32 %t227, ptr %l104
  %t228 = icmp ne i32 %t227, 0
  br i1 %t228, label %bb56, label %ok.229, !prof !99
ok.229:
  store i32 %t226, ptr %l103
  br label %bb55
bb55:
  %t230 = load i32, ptr %l103, !tbaa !23
  store i32 %t230, ptr %l101, !tbaa !23
  br label %bb57
bb56:
  %t231 = load i32, ptr %l104, !tbaa !23
  %t232 = lshr i32 %t231, 16
  %t233 = and i32 %t231, 65535
  %t234 = icmp eq i32 %t232, 1
  %t235 = select i1 %t234, i32 1, i32 0
  %t236 = icmp eq i32 %t231, 0
  %t237 = shl i32 %t235, 16
  %t238 = or i32 %t237, %t233
  %t239 = select i1 %t236, i32 0, i32 %t238
  %t241 = insertvalue { i32, ptr } zeroinitializer, i32 %t239, 0
  store { i32, ptr } %t241, ptr %rv
  br label %ret
bb57:
  %t242 = load i32, ptr %l101, !tbaa !23
  store i32 %t242, ptr %l8, !tbaa !23
  %t243 = load ptr, ptr %l0, !tbaa !29
  %t244 = load i32, ptr %l1, !tbaa !23
  %t247 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t243, i32 %t244)
  store %"compiler/source:Span" %t247, ptr %l108
  br label %bb58
bb58:
  %t248 = load %"compiler/source:Span", ptr %l108
  store %"compiler/source:Span" %t248, ptr %l9
  %t249 = load ptr, ptr %l0, !tbaa !29
  %t251 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eendStmt(ptr %v0, ptr %t249)
  store i32 %t251, ptr %l110
  %t252 = icmp ne i32 %t251, 0
  br i1 %t252, label %bb60, label %ok.253, !prof !99
ok.253:
  br label %bb59
bb59:
  br label %bb61
bb60:
  %t254 = load i32, ptr %l110, !tbaa !23
  %t255 = lshr i32 %t254, 16
  %t256 = and i32 %t254, 65535
  %t257 = icmp eq i32 %t255, 1
  %t258 = select i1 %t257, i32 1, i32 0
  %t259 = icmp eq i32 %t254, 0
  %t260 = shl i32 %t258, 16
  %t261 = or i32 %t260, %t256
  %t262 = select i1 %t259, i32 0, i32 %t261
  %t264 = insertvalue { i32, ptr } zeroinitializer, i32 %t262, 0
  store { i32, ptr } %t264, ptr %rv
  br label %ret
bb61:
  %t265 = load %"compiler/source:Span", ptr %l9
  store %"compiler/source:Span" %t265, ptr %l112
  %t266 = load i32, ptr %l8, !tbaa !23
  store i32 %t266, ptr %l113, !tbaa !23
  %t267 = icmp sge i64 0, 0
  br i1 %t267, label %bb62, label %bb63
bb62:
  %t269 = icmp sle i64 0, 1152921504606846975
  br i1 %t269, label %bb64, label %bb65
bb63:
  call void @__olang_check_failed(ptr @olang_loc_acdf3c0d270865a2_ccca0ad6e9b656fe)
  unreachable
bb64:
  %t271 = mul i64 0, 8
  %t272 = insertvalue { i64, ptr } undef, i64 0, 0
  %t273 = insertvalue { i64, ptr } %t272, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, [6 x i64] } zeroinitializer, ptr %t274
  %t275 = getelementptr { i64, [6 x i64] }, ptr %t274, i32 0, i32 0
  store i64 4, ptr %t275
  %t276 = load { i64, [6 x i64] }, ptr %t274
  %t278 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 56, i64 8)
  store { i64, [6 x i64] } %t276, ptr %t278
  %t279 = load i32, ptr %l113, !tbaa !23
  %t283 = call %"compiler/ast:TypeDecl" @compiler_2fast_3aTypeDecl_2ector(ptr %v1, ptr %v1, ptr %v1, ptr %v1, i32 %t279, { i64, ptr } %t273, i1 false, ptr %t278, i32 0, i1 false, ptr null, i32 0)
  store %"compiler/ast:TypeDecl" %t283, ptr %l120
  br label %bb66
bb65:
  call void @__olang_check_failed(ptr @olang_loc_acdf3c0d270865a2_ccca0ad6e9b656fe)
  unreachable
bb66:
  %t284 = load %"compiler/ast:TypeDecl", ptr %l120
  %t285 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 64, i64 8)
  store %"compiler/ast:TypeDecl" %t284, ptr %t285
  store { i64, [8 x i64] } zeroinitializer, ptr %t286
  %t287 = getelementptr { i64, [8 x i64] }, ptr %t286, i32 0, i32 0
  store i64 2, ptr %t287
  %t288 = load %"compiler/source:Span", ptr %l112
  %t289 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t288, 0
  %t291 = insertvalue { %"compiler/source:Span", ptr } %t289, ptr %t285, 1
  %t292 = getelementptr { i64, [8 x i64] }, ptr %t286, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t291, ptr %t292
  %t293 = load { i64, [8 x i64] }, ptr %t286
  %t295 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 72, i64 8)
  store { i64, [8 x i64] } %t293, ptr %t295
  %t297 = insertvalue { i32, ptr } zeroinitializer, ptr %t295, 1
  store { i32, ptr } %t297, ptr %rv
  br label %ret
bb67:
  %t298 = load ptr, ptr %l0, !tbaa !29
  %t300 = call { i32, %"compiler/source:Span" } @compiler_2fparse_2ecompiler_2fparse_3aParser_2elinkClause(ptr %v0, ptr %t298)
  %t301 = extractvalue { i32, %"compiler/source:Span" } %t300, 1
  %t302 = extractvalue { i32, %"compiler/source:Span" } %t300, 0
  store i32 %t302, ptr %l127
  %t303 = icmp ne i32 %t302, 0
  br i1 %t303, label %bb69, label %ok.304, !prof !99
ok.304:
  store %"compiler/source:Span" %t301, ptr %l126
  br label %bb68
bb68:
  %t305 = load %"compiler/source:Span", ptr %l126
  store %"compiler/source:Span" %t305, ptr %l124
  br label %bb70
bb69:
  %t306 = load i32, ptr %l127, !tbaa !23
  %t307 = lshr i32 %t306, 16
  %t308 = and i32 %t306, 65535
  %t309 = icmp eq i32 %t307, 1
  %t310 = select i1 %t309, i32 1, i32 0
  %t311 = icmp eq i32 %t306, 0
  %t312 = shl i32 %t310, 16
  %t313 = or i32 %t312, %t308
  %t314 = select i1 %t311, i32 0, i32 %t313
  %t316 = insertvalue { i32, ptr } zeroinitializer, i32 %t314, 0
  store { i32, ptr } %t316, ptr %rv
  br label %ret
bb70:
  %t317 = load %"compiler/source:Span", ptr %l124
  store %"compiler/source:Span" %t317, ptr %l10
  %t318 = load ptr, ptr %l0, !tbaa !29
  %t321 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t318, i32 114)
  store i1 %t321, ptr %l131
  br label %bb71
bb71:
  %t322 = load i1, ptr %l131, !tbaa !21
  br i1 %t322, label %bb72, label %bb73
bb72:
  %t323 = load ptr, ptr %l0, !tbaa !29
  %t324 = load i32, ptr %l1, !tbaa !23
  %t325 = load %"compiler/source:Span", ptr %l10
  %t329 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexternBlock(ptr %v0, ptr %v1, ptr %t323, i32 %t324, %"compiler/source:Span" %t325)
  %t330 = extractvalue { i32, ptr } %t329, 1
  %t331 = extractvalue { i32, ptr } %t329, 0
  store i32 %t331, ptr %l137
  %t332 = icmp ne i32 %t331, 0
  br i1 %t332, label %bb75, label %ok.333, !prof !99
ok.333:
  store ptr %t330, ptr %l136
  br label %bb74
bb73:
  br label %bb77
bb74:
  %t334 = load ptr, ptr %l136, !tbaa !29
  store ptr %t334, ptr %l132, !tbaa !29
  br label %bb76
bb75:
  %t335 = load i32, ptr %l137, !tbaa !23
  %t336 = lshr i32 %t335, 16
  %t337 = and i32 %t335, 65535
  %t338 = icmp eq i32 %t336, 1
  %t339 = select i1 %t338, i32 1, i32 0
  %t340 = icmp eq i32 %t335, 0
  %t341 = shl i32 %t339, 16
  %t342 = or i32 %t341, %t337
  %t343 = select i1 %t340, i32 0, i32 %t342
  %t345 = insertvalue { i32, ptr } zeroinitializer, i32 %t343, 0
  store { i32, ptr } %t345, ptr %rv
  br label %ret
bb76:
  %t346 = load ptr, ptr %l132, !tbaa !29
  %t348 = insertvalue { i32, ptr } zeroinitializer, ptr %t346, 1
  store { i32, ptr } %t348, ptr %rv
  br label %ret
bb77:
  %t349 = getelementptr %"compiler/source:Span", ptr %l10, i32 0, i32 1
  %t350 = load i32, ptr %t349, !tbaa !23
  %t352 = icmp sgt i32 %t350, 0
  br i1 %t352, label %bb78, label %bb79
bb78:
  store %olang.scope zeroinitializer, ptr %s9
  %t354 = load ptr, ptr %l0, !tbaa !29
  store ptr %t354, ptr %l142, !tbaa !29
  %t356 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eDescribe(ptr %s9, i32 114)
  store { i64, ptr } %t356, ptr %l144
  br label %bb80
bb79:
  br label %bb84
bb80:
  %t357 = load { i64, ptr }, ptr %l144, !tbaa !27
  %t358 = load ptr, ptr %l142, !tbaa !29
  %t360 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2efail(ptr %v0, ptr %s9, ptr %t358, { i64, ptr } %t357)
  store i32 %t360, ptr %l146
  %t361 = icmp ne i32 %t360, 0
  br i1 %t361, label %bb82, label %ok.362, !prof !99
ok.362:
  br label %bb81
bb81:
  br label %bb83
bb82:
  %t363 = load i32, ptr %l146, !tbaa !23
  %t364 = lshr i32 %t363, 16
  %t365 = and i32 %t363, 65535
  %t366 = icmp eq i32 %t364, 1
  %t367 = select i1 %t366, i32 1, i32 0
  %t368 = icmp eq i32 %t363, 0
  %t369 = shl i32 %t367, 16
  %t370 = or i32 %t369, %t365
  %t371 = select i1 %t368, i32 0, i32 %t370
  call void @__olang_scope_close(ptr %s9)
  %t373 = insertvalue { i32, ptr } zeroinitializer, i32 %t371, 0
  store { i32, ptr } %t373, ptr %rv
  br label %ret
bb83:
  call void @__olang_scope_close(ptr %s9)
  br label %bb84
bb84:
  %t374 = load ptr, ptr %l0, !tbaa !29
  %t375 = load i32, ptr %l1, !tbaa !23
  %t378 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexternFn(ptr %v0, ptr %v1, ptr %t374, i32 %t375)
  %t379 = extractvalue { i32, ptr } %t378, 1
  %t380 = extractvalue { i32, ptr } %t378, 0
  store i32 %t380, ptr %l152
  %t381 = icmp ne i32 %t380, 0
  br i1 %t381, label %bb86, label %ok.382, !prof !99
ok.382:
  store ptr %t379, ptr %l151
  br label %bb85
bb85:
  %t383 = load ptr, ptr %l151, !tbaa !29
  store ptr %t383, ptr %l148, !tbaa !29
  br label %bb87
bb86:
  %t384 = load i32, ptr %l152, !tbaa !23
  %t385 = lshr i32 %t384, 16
  %t386 = and i32 %t384, 65535
  %t387 = icmp eq i32 %t385, 1
  %t388 = select i1 %t387, i32 1, i32 0
  %t389 = icmp eq i32 %t384, 0
  %t390 = shl i32 %t388, 16
  %t391 = or i32 %t390, %t386
  %t392 = select i1 %t389, i32 0, i32 %t391
  %t394 = insertvalue { i32, ptr } zeroinitializer, i32 %t392, 0
  store { i32, ptr } %t394, ptr %rv
  br label %ret
bb87:
  %t395 = load ptr, ptr %l148, !tbaa !29
  store ptr %t395, ptr %l11, !tbaa !29
  %t396 = load ptr, ptr %l0, !tbaa !29
  %t398 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eendStmt(ptr %v0, ptr %t396)
  store i32 %t398, ptr %l155
  %t399 = icmp ne i32 %t398, 0
  br i1 %t399, label %bb89, label %ok.400, !prof !99
ok.400:
  br label %bb88
bb88:
  br label %bb90
bb89:
  %t401 = load i32, ptr %l155, !tbaa !23
  %t402 = lshr i32 %t401, 16
  %t403 = and i32 %t401, 65535
  %t404 = icmp eq i32 %t402, 1
  %t405 = select i1 %t404, i32 1, i32 0
  %t406 = icmp eq i32 %t401, 0
  %t407 = shl i32 %t405, 16
  %t408 = or i32 %t407, %t403
  %t409 = select i1 %t406, i32 0, i32 %t408
  %t411 = insertvalue { i32, ptr } zeroinitializer, i32 %t409, 0
  store { i32, ptr } %t411, ptr %rv
  br label %ret
bb90:
  %t412 = load ptr, ptr %l11, !tbaa !29
  store { i64, [8 x i64] } zeroinitializer, ptr %t413
  %t414 = getelementptr { i64, [8 x i64] }, ptr %t413, i32 0, i32 0
  store i64 1, ptr %t414
  %t416 = insertvalue { ptr } undef, ptr %t412, 0
  %t417 = getelementptr { i64, [8 x i64] }, ptr %t413, i32 0, i32 1
  store { ptr } %t416, ptr %t417
  %t418 = load { i64, [8 x i64] }, ptr %t413
  %t420 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 72, i64 8)
  store { i64, [8 x i64] } %t418, ptr %t420
  %t422 = insertvalue { i32, ptr } zeroinitializer, ptr %t420, 1
  store { i32, ptr } %t422, ptr %rv
  br label %ret
bb91:
  %t423 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t425 = trunc i64 41 to i32
  %t426 = icmp eq i32 %t423, %t425
  br i1 %t426, label %bb92, label %bb93
bb92:
  br label %bb94
bb93:
  br label %bb118
bb94:
  %t428 = load ptr, ptr %l0, !tbaa !29
  %t430 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t428)
  store i32 %t430, ptr %l163
  br label %bb95
bb95:
  store ptr null, ptr %l12, !tbaa !29
  %t431 = load ptr, ptr %l0, !tbaa !29
  %t434 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t431, i32 1)
  store i1 %t434, ptr %l166
  br label %bb96
bb96:
  %t435 = load i1, ptr %l166, !tbaa !21
  br i1 %t435, label %bb97, label %bb98
bb97:
  %t436 = load ptr, ptr %l0, !tbaa !29
  %t438 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2epath(ptr %v0, ptr %v1, ptr %t436)
  %t439 = extractvalue { i32, ptr } %t438, 1
  %t440 = extractvalue { i32, ptr } %t438, 0
  store i32 %t440, ptr %l170
  %t441 = icmp ne i32 %t440, 0
  br i1 %t441, label %bb100, label %ok.442, !prof !99
ok.442:
  store ptr %t439, ptr %l169
  br label %bb99
bb98:
  br label %bb102
bb99:
  %t443 = load ptr, ptr %l169, !tbaa !29
  store ptr %t443, ptr %l167, !tbaa !29
  br label %bb101
bb100:
  %t444 = load i32, ptr %l170, !tbaa !23
  %t445 = lshr i32 %t444, 16
  %t446 = and i32 %t444, 65535
  %t447 = icmp eq i32 %t445, 1
  %t448 = select i1 %t447, i32 1, i32 0
  %t449 = icmp eq i32 %t444, 0
  %t450 = shl i32 %t448, 16
  %t451 = or i32 %t450, %t446
  %t452 = select i1 %t449, i32 0, i32 %t451
  %t454 = insertvalue { i32, ptr } zeroinitializer, i32 %t452, 0
  store { i32, ptr } %t454, ptr %rv
  br label %ret
bb101:
  %t455 = load ptr, ptr %l167, !tbaa !29
  store ptr %t455, ptr %l12, !tbaa !29
  br label %bb102
bb102:
  %t457 = load ptr, ptr %l0, !tbaa !29
  %t460 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t457, i32 5)
  store i1 %t460, ptr %l175
  br label %bb103
bb103:
  %t461 = load i1, ptr %l175, !tbaa !21
  %t462 = xor i1 %t461, true
  br i1 %t462, label %bb104, label %bb105
bb104:
  store %olang.scope zeroinitializer, ptr %s12
  %t464 = load ptr, ptr %l0, !tbaa !29
  store ptr %t464, ptr %l177, !tbaa !29
  %t466 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eDescribe(ptr %s12, i32 5)
  store { i64, ptr } %t466, ptr %l179
  br label %bb106
bb105:
  br label %bb110
bb106:
  %t467 = load { i64, ptr }, ptr %l179, !tbaa !27
  %t468 = load ptr, ptr %l177, !tbaa !29
  %t470 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2efail(ptr %v0, ptr %s12, ptr %t468, { i64, ptr } %t467)
  store i32 %t470, ptr %l181
  %t471 = icmp ne i32 %t470, 0
  br i1 %t471, label %bb108, label %ok.472, !prof !99
ok.472:
  br label %bb107
bb107:
  br label %bb109
bb108:
  %t473 = load i32, ptr %l181, !tbaa !23
  %t474 = lshr i32 %t473, 16
  %t475 = and i32 %t473, 65535
  %t476 = icmp eq i32 %t474, 1
  %t477 = select i1 %t476, i32 1, i32 0
  %t478 = icmp eq i32 %t473, 0
  %t479 = shl i32 %t477, 16
  %t480 = or i32 %t479, %t475
  %t481 = select i1 %t478, i32 0, i32 %t480
  call void @__olang_scope_close(ptr %s12)
  %t483 = insertvalue { i32, ptr } zeroinitializer, i32 %t481, 0
  store { i32, ptr } %t483, ptr %rv
  br label %ret
bb109:
  call void @__olang_scope_close(ptr %s12)
  br label %bb110
bb110:
  %t484 = load ptr, ptr %l0, !tbaa !29
  %t486 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2etk(ptr %v0, ptr %t484)
  store %"compiler/token:Token" %t486, ptr %l184
  br label %bb111
bb111:
  %t487 = load %"compiler/token:Token", ptr %l184
  store %"compiler/token:Token" %t487, ptr %l13
  %t488 = load ptr, ptr %l0, !tbaa !29
  %t490 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t488)
  store i32 %t490, ptr %l186
  br label %bb112
bb112:
  %t491 = load ptr, ptr %l0, !tbaa !29
  %t493 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ebody(ptr %v0, ptr %v1, ptr %t491)
  %t494 = extractvalue { i32, { i64, ptr } } %t493, 1
  %t495 = extractvalue { i32, { i64, ptr } } %t493, 0
  store i32 %t495, ptr %l190
  %t496 = icmp ne i32 %t495, 0
  br i1 %t496, label %bb114, label %ok.497, !prof !99
ok.497:
  store { i64, ptr } %t494, ptr %l189
  br label %bb113
bb113:
  %t498 = load { i64, ptr }, ptr %l189, !tbaa !27
  store { i64, ptr } %t498, ptr %l187, !tbaa !27
  br label %bb115
bb114:
  %t499 = load i32, ptr %l190, !tbaa !23
  %t500 = lshr i32 %t499, 16
  %t501 = and i32 %t499, 65535
  %t502 = icmp eq i32 %t500, 1
  %t503 = select i1 %t502, i32 1, i32 0
  %t504 = icmp eq i32 %t499, 0
  %t505 = shl i32 %t503, 16
  %t506 = or i32 %t505, %t501
  %t507 = select i1 %t504, i32 0, i32 %t506
  %t509 = insertvalue { i32, ptr } zeroinitializer, i32 %t507, 0
  store { i32, ptr } %t509, ptr %rv
  br label %ret
bb115:
  %t510 = load { i64, ptr }, ptr %l187, !tbaa !27
  store { i64, ptr } %t510, ptr %l14, !tbaa !27
  %t511 = load ptr, ptr %l0, !tbaa !29
  %t512 = load i32, ptr %l1, !tbaa !23
  %t515 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t511, i32 %t512)
  store %"compiler/source:Span" %t515, ptr %l194
  br label %bb116
bb116:
  %t516 = getelementptr %"compiler/token:Token", ptr %l13, i32 0, i32 2
  %t517 = load i32, ptr %t516, !tbaa !23
  %t518 = getelementptr %"compiler/token:Token", ptr %l13, i32 0, i32 3
  %t519 = load i32, ptr %t518, !tbaa !23
  %t522 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v1, i32 %t517, i32 %t519)
  store %"compiler/source:Span" %t522, ptr %l197
  br label %bb117
bb117:
  %t523 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t524 = load ptr, ptr %l12, !tbaa !29
  store { i64, [8 x i64] } zeroinitializer, ptr %t525
  %t526 = getelementptr { i64, [8 x i64] }, ptr %t525, i32 0, i32 0
  store i64 7, ptr %t526
  %t527 = load %"compiler/source:Span", ptr %l194
  %t528 = insertvalue { %"compiler/source:Span", %"compiler/source:Span", { i64, ptr }, ptr } undef, %"compiler/source:Span" %t527, 0
  %t529 = load %"compiler/source:Span", ptr %l197
  %t530 = insertvalue { %"compiler/source:Span", %"compiler/source:Span", { i64, ptr }, ptr } %t528, %"compiler/source:Span" %t529, 1
  %t532 = insertvalue { %"compiler/source:Span", %"compiler/source:Span", { i64, ptr }, ptr } %t530, { i64, ptr } %t523, 2
  %t534 = insertvalue { %"compiler/source:Span", %"compiler/source:Span", { i64, ptr }, ptr } %t532, ptr %t524, 3
  %t535 = getelementptr { i64, [8 x i64] }, ptr %t525, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/source:Span", { i64, ptr }, ptr } %t534, ptr %t535
  %t536 = load { i64, [8 x i64] }, ptr %t525
  %t538 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 72, i64 8)
  store { i64, [8 x i64] } %t536, ptr %t538
  %t540 = insertvalue { i32, ptr } zeroinitializer, ptr %t538, 1
  store { i32, ptr } %t540, ptr %rv
  br label %ret
bb118:
  %t541 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t543 = trunc i64 9 to i32
  %t544 = icmp eq i32 %t541, %t543
  br i1 %t544, label %bb119, label %bb120
bb119:
  br label %bb121
bb120:
  br label %bb125
bb121:
  %t546 = load ptr, ptr %l0, !tbaa !29
  %t548 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etopIf(ptr %v0, ptr %v1, ptr %t546)
  %t549 = extractvalue { i32, ptr } %t548, 1
  %t550 = extractvalue { i32, ptr } %t548, 0
  store i32 %t550, ptr %l207
  %t551 = icmp ne i32 %t550, 0
  br i1 %t551, label %bb123, label %ok.552, !prof !99
ok.552:
  store ptr %t549, ptr %l206
  br label %bb122
bb122:
  %t553 = load ptr, ptr %l206, !tbaa !29
  store ptr %t553, ptr %l204, !tbaa !29
  br label %bb124
bb123:
  %t554 = load i32, ptr %l207, !tbaa !23
  %t555 = lshr i32 %t554, 16
  %t556 = and i32 %t554, 65535
  %t557 = icmp eq i32 %t555, 1
  %t558 = select i1 %t557, i32 1, i32 0
  %t559 = icmp eq i32 %t554, 0
  %t560 = shl i32 %t558, 16
  %t561 = or i32 %t560, %t556
  %t562 = select i1 %t559, i32 0, i32 %t561
  %t564 = insertvalue { i32, ptr } zeroinitializer, i32 %t562, 0
  store { i32, ptr } %t564, ptr %rv
  br label %ret
bb124:
  %t565 = load ptr, ptr %l204, !tbaa !29
  %t567 = insertvalue { i32, ptr } zeroinitializer, ptr %t565, 1
  store { i32, ptr } %t567, ptr %rv
  br label %ret
bb125:
  %t568 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t570 = trunc i64 24 to i32
  %t571 = icmp eq i32 %t568, %t570
  br i1 %t571, label %bb126, label %bb127
bb126:
  br label %bb128
bb127:
  br label %bb144
bb128:
  %t573 = load ptr, ptr %l0, !tbaa !29
  %t575 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t573)
  store i32 %t575, ptr %l213
  br label %bb129
bb129:
  %t576 = load ptr, ptr %l0, !tbaa !29
  %t578 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexpr(ptr %v0, ptr %v1, ptr %t576)
  %t579 = extractvalue { i32, ptr } %t578, 1
  %t580 = extractvalue { i32, ptr } %t578, 0
  store i32 %t580, ptr %l217
  %t581 = icmp ne i32 %t580, 0
  br i1 %t581, label %bb131, label %ok.582, !prof !99
ok.582:
  store ptr %t579, ptr %l216
  br label %bb130
bb130:
  %t583 = load ptr, ptr %l216, !tbaa !29
  store ptr %t583, ptr %l214, !tbaa !29
  br label %bb132
bb131:
  %t584 = load i32, ptr %l217, !tbaa !23
  %t585 = lshr i32 %t584, 16
  %t586 = and i32 %t584, 65535
  %t587 = icmp eq i32 %t585, 1
  %t588 = select i1 %t587, i32 1, i32 0
  %t589 = icmp eq i32 %t584, 0
  %t590 = shl i32 %t588, 16
  %t591 = or i32 %t590, %t586
  %t592 = select i1 %t589, i32 0, i32 %t591
  %t594 = insertvalue { i32, ptr } zeroinitializer, i32 %t592, 0
  store { i32, ptr } %t594, ptr %rv
  br label %ret
bb132:
  %t595 = load ptr, ptr %l214, !tbaa !29
  store ptr %t595, ptr %l15, !tbaa !29
  store ptr null, ptr %l16, !tbaa !29
  %t596 = load ptr, ptr %l0, !tbaa !29
  %t599 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t596, i32 75)
  store i1 %t599, ptr %l221
  br label %bb133
bb133:
  %t600 = load i1, ptr %l221, !tbaa !21
  br i1 %t600, label %bb134, label %bb135
bb134:
  %t601 = load ptr, ptr %l0, !tbaa !29
  %t603 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexpr(ptr %v0, ptr %v1, ptr %t601)
  %t604 = extractvalue { i32, ptr } %t603, 1
  %t605 = extractvalue { i32, ptr } %t603, 0
  store i32 %t605, ptr %l225
  %t606 = icmp ne i32 %t605, 0
  br i1 %t606, label %bb137, label %ok.607, !prof !99
ok.607:
  store ptr %t604, ptr %l224
  br label %bb136
bb135:
  br label %bb139
bb136:
  %t608 = load ptr, ptr %l224, !tbaa !29
  store ptr %t608, ptr %l222, !tbaa !29
  br label %bb138
bb137:
  %t609 = load i32, ptr %l225, !tbaa !23
  %t610 = lshr i32 %t609, 16
  %t611 = and i32 %t609, 65535
  %t612 = icmp eq i32 %t610, 1
  %t613 = select i1 %t612, i32 1, i32 0
  %t614 = icmp eq i32 %t609, 0
  %t615 = shl i32 %t613, 16
  %t616 = or i32 %t615, %t611
  %t617 = select i1 %t614, i32 0, i32 %t616
  %t619 = insertvalue { i32, ptr } zeroinitializer, i32 %t617, 0
  store { i32, ptr } %t619, ptr %rv
  br label %ret
bb138:
  %t620 = load ptr, ptr %l222, !tbaa !29
  store ptr %t620, ptr %l16, !tbaa !29
  br label %bb139
bb139:
  %t622 = load ptr, ptr %l0, !tbaa !29
  %t623 = load i32, ptr %l1, !tbaa !23
  %t626 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t622, i32 %t623)
  store %"compiler/source:Span" %t626, ptr %l230
  br label %bb140
bb140:
  %t627 = load %"compiler/source:Span", ptr %l230
  store %"compiler/source:Span" %t627, ptr %l17
  %t628 = load ptr, ptr %l0, !tbaa !29
  %t630 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eendStmt(ptr %v0, ptr %t628)
  store i32 %t630, ptr %l232
  %t631 = icmp ne i32 %t630, 0
  br i1 %t631, label %bb142, label %ok.632, !prof !99
ok.632:
  br label %bb141
bb141:
  br label %bb143
bb142:
  %t633 = load i32, ptr %l232, !tbaa !23
  %t634 = lshr i32 %t633, 16
  %t635 = and i32 %t633, 65535
  %t636 = icmp eq i32 %t634, 1
  %t637 = select i1 %t636, i32 1, i32 0
  %t638 = icmp eq i32 %t633, 0
  %t639 = shl i32 %t637, 16
  %t640 = or i32 %t639, %t635
  %t641 = select i1 %t638, i32 0, i32 %t640
  %t643 = insertvalue { i32, ptr } zeroinitializer, i32 %t641, 0
  store { i32, ptr } %t643, ptr %rv
  br label %ret
bb143:
  %t644 = load %"compiler/source:Span", ptr %l17
  %t645 = load ptr, ptr %l15, !tbaa !29
  %t646 = load ptr, ptr %l16, !tbaa !29
  store { i64, [8 x i64] } zeroinitializer, ptr %t647
  %t648 = getelementptr { i64, [8 x i64] }, ptr %t647, i32 0, i32 0
  store i64 10, ptr %t648
  %t650 = insertvalue { %"compiler/source:Span", ptr, ptr } undef, %"compiler/source:Span" %t644, 0
  %t652 = insertvalue { %"compiler/source:Span", ptr, ptr } %t650, ptr %t645, 1
  %t654 = insertvalue { %"compiler/source:Span", ptr, ptr } %t652, ptr %t646, 2
  %t655 = getelementptr { i64, [8 x i64] }, ptr %t647, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr } %t654, ptr %t655
  %t656 = load { i64, [8 x i64] }, ptr %t647
  %t658 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 72, i64 8)
  store { i64, [8 x i64] } %t656, ptr %t658
  %t660 = insertvalue { i32, ptr } zeroinitializer, ptr %t658, 1
  store { i32, ptr } %t660, ptr %rv
  br label %ret
bb144:
  %t661 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t663 = trunc i64 1 to i32
  %t664 = icmp eq i32 %t661, %t663
  br i1 %t664, label %bb145, label %bb146
bb145:
  br label %bb147
bb146:
  br label %bb188
bb147:
  store %olang.scope zeroinitializer, ptr %s16
  %t666 = load ptr, ptr %l0, !tbaa !29
  store ptr %t666, ptr %l241, !tbaa !29
  %t667 = load ptr, ptr %l0, !tbaa !29
  %t669 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2etk(ptr %v0, ptr %t667)
  store %"compiler/token:Token" %t669, ptr %l243
  br label %bb148
bb148:
  %t670 = load ptr, ptr %l241, !tbaa !29
  %t671 = load %"compiler/token:Token", ptr %l243
  %t672 = call { i64, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etext(ptr %v0, ptr %v0, ptr %t670, %"compiler/token:Token" %t671)
  store { i64, ptr } %t672, ptr %l244
  br label %bb149
bb149:
  %t673 = load { i64, ptr }, ptr %l244, !tbaa !27
  %t674 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s16, { i64, ptr } %t673, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d0, i32 0, i32 1) })
  store i1 %t674, ptr %l245
  br label %bb150
bb150:
  %t675 = load i1, ptr %l245, !tbaa !21
  br i1 %t675, label %bb151, label %bb152
bb151:
  %t676 = load ptr, ptr %l0, !tbaa !29
  %t678 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elook(ptr %v0, ptr %t676, i64 1)
  store i32 %t678, ptr %l248
  br label %bb153
bb152:
  store i1 false, ptr %l246, !tbaa !21
  br label %bb154
bb153:
  %t679 = load i32, ptr %l248, !range !{i32 0, i32 116}
  %t681 = trunc i64 37 to i32
  %t682 = icmp eq i32 %t679, %t681
  store i1 %t682, ptr %l246, !tbaa !21
  br label %bb154
bb154:
  %t684 = load i1, ptr %l246, !tbaa !21
  br i1 %t684, label %bb155, label %bb156
bb155:
  %t685 = load ptr, ptr %l0, !tbaa !29
  %t687 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t685)
  store i32 %t687, ptr %l252
  br label %bb157
bb156:
  br label %bb163
bb157:
  %t688 = load ptr, ptr %l0, !tbaa !29
  %t690 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2efunction(ptr %v0, ptr %v1, ptr %t688)
  %t691 = extractvalue { i32, ptr } %t690, 1
  %t692 = extractvalue { i32, ptr } %t690, 0
  store i32 %t692, ptr %l256
  %t693 = icmp ne i32 %t692, 0
  br i1 %t693, label %bb159, label %ok.694, !prof !99
ok.694:
  store ptr %t691, ptr %l255
  br label %bb158
bb158:
  %t695 = load ptr, ptr %l255, !tbaa !29
  store ptr %t695, ptr %l253, !tbaa !29
  br label %bb160
bb159:
  %t696 = load i32, ptr %l256, !tbaa !23
  %t697 = lshr i32 %t696, 16
  %t698 = and i32 %t696, 65535
  %t699 = icmp eq i32 %t697, 1
  %t700 = select i1 %t699, i32 1, i32 0
  %t701 = icmp eq i32 %t696, 0
  %t702 = shl i32 %t700, 16
  %t703 = or i32 %t702, %t698
  %t704 = select i1 %t701, i32 0, i32 %t703
  call void @__olang_scope_close(ptr %s16)
  %t706 = insertvalue { i32, ptr } zeroinitializer, i32 %t704, 0
  store { i32, ptr } %t706, ptr %rv
  br label %ret
bb160:
  %t707 = load ptr, ptr %l253, !tbaa !29
  store ptr %t707, ptr %l18, !tbaa !29
  %t708 = load ptr, ptr %l0, !tbaa !29
  %t709 = load i32, ptr %l1, !tbaa !23
  %t712 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t708, i32 %t709)
  store %"compiler/source:Span" %t712, ptr %l260
  br label %bb161
bb161:
  %t713 = load ptr, ptr %l18, !tbaa !29
  %t715 = getelementptr %"compiler/ast:Func", ptr %t713, i32 0, i32 1
  %t716 = load ptr, ptr %t715, !tbaa !29
  %t717 = load ptr, ptr %l18, !tbaa !29
  %t719 = getelementptr %"compiler/ast:Func", ptr %t717, i32 0, i32 2
  %t720 = load i32, ptr %t719, !tbaa !23
  %t721 = load ptr, ptr %l18, !tbaa !29
  %t723 = getelementptr %"compiler/ast:Func", ptr %t721, i32 0, i32 3
  %t724 = load ptr, ptr %t723, !tbaa !29
  %t725 = load ptr, ptr %l18, !tbaa !29
  %t727 = getelementptr %"compiler/ast:Func", ptr %t725, i32 0, i32 4
  %t728 = load { i64, ptr }, ptr %t727, !tbaa !27
  %t729 = load ptr, ptr %l18, !tbaa !29
  %t731 = getelementptr %"compiler/ast:Func", ptr %t729, i32 0, i32 5
  %t732 = load { i64, ptr }, ptr %t731, !tbaa !27
  %t733 = load ptr, ptr %l18, !tbaa !29
  %t735 = getelementptr %"compiler/ast:Func", ptr %t733, i32 0, i32 6
  %t736 = load i1, ptr %t735, !tbaa !21
  %t737 = load ptr, ptr %l18, !tbaa !29
  %t739 = getelementptr %"compiler/ast:Func", ptr %t737, i32 0, i32 8
  %t740 = load ptr, ptr %t739, !tbaa !29
  %t741 = load ptr, ptr %l18, !tbaa !29
  %t743 = getelementptr %"compiler/ast:Func", ptr %t741, i32 0, i32 9
  %t744 = load i32, ptr %t743, !tbaa !23
  %t745 = load %"compiler/source:Span", ptr %l260
  %t754 = call %"compiler/ast:Func" @compiler_2fast_3aFunc_2ector(ptr %v1, ptr %v1, ptr %v1, ptr %v1, ptr %v1, ptr %v1, %"compiler/source:Span" %t745, ptr %t716, i32 %t720, ptr %t724, { i64, ptr } %t728, { i64, ptr } %t732, i1 %t736, i1 true, ptr %t740, i32 %t744)
  store %"compiler/ast:Func" %t754, ptr %l277
  br label %bb162
bb162:
  %t755 = load %"compiler/ast:Func", ptr %l277
  %t756 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 88, i64 8)
  store %"compiler/ast:Func" %t755, ptr %t756
  store { i64, [8 x i64] } zeroinitializer, ptr %t757
  %t758 = getelementptr { i64, [8 x i64] }, ptr %t757, i32 0, i32 0
  store i64 0, ptr %t758
  %t760 = insertvalue { ptr } undef, ptr %t756, 0
  %t761 = getelementptr { i64, [8 x i64] }, ptr %t757, i32 0, i32 1
  store { ptr } %t760, ptr %t761
  %t762 = load { i64, [8 x i64] }, ptr %t757
  %t764 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 72, i64 8)
  store { i64, [8 x i64] } %t762, ptr %t764
  call void @__olang_scope_close(ptr %s16)
  %t766 = insertvalue { i32, ptr } zeroinitializer, ptr %t764, 1
  store { i32, ptr } %t766, ptr %rv
  br label %ret
bb163:
  %t767 = load ptr, ptr %l0, !tbaa !29
  %t769 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elook(ptr %v0, ptr %t767, i64 1)
  store i32 %t769, ptr %l282
  br label %bb164
bb164:
  %t770 = load i32, ptr %l282, !range !{i32 0, i32 116}
  %t772 = trunc i64 78 to i32
  %t773 = icmp eq i32 %t770, %t772
  br i1 %t773, label %bb165, label %bb166
bb165:
  %t775 = load ptr, ptr %l0, !tbaa !29
  %t777 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2etk(ptr %v0, ptr %t775)
  store %"compiler/token:Token" %t777, ptr %l286
  br label %bb167
bb166:
  br label %bb180
bb167:
  %t778 = load %"compiler/token:Token", ptr %l286
  store %"compiler/token:Token" %t778, ptr %l19
  %t779 = load ptr, ptr %l0, !tbaa !29
  %t781 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ename(ptr %v0, ptr %t779)
  %t782 = extractvalue { i32, i32 } %t781, 1
  %t783 = extractvalue { i32, i32 } %t781, 0
  store i32 %t783, ptr %l290
  %t784 = icmp ne i32 %t783, 0
  br i1 %t784, label %bb169, label %ok.785, !prof !99
ok.785:
  store i32 %t782, ptr %l289
  br label %bb168
bb168:
  %t786 = load i32, ptr %l289, !tbaa !23
  store i32 %t786, ptr %l287, !tbaa !23
  br label %bb170
bb169:
  %t787 = load i32, ptr %l290, !tbaa !23
  %t788 = lshr i32 %t787, 16
  %t789 = and i32 %t787, 65535
  %t790 = icmp eq i32 %t788, 1
  %t791 = select i1 %t790, i32 1, i32 0
  %t792 = icmp eq i32 %t787, 0
  %t793 = shl i32 %t791, 16
  %t794 = or i32 %t793, %t789
  %t795 = select i1 %t792, i32 0, i32 %t794
  call void @__olang_scope_close(ptr %s16)
  %t797 = insertvalue { i32, ptr } zeroinitializer, i32 %t795, 0
  store { i32, ptr } %t797, ptr %rv
  br label %ret
bb170:
  %t798 = load i32, ptr %l287, !tbaa !23
  store i32 %t798, ptr %l20, !tbaa !23
  %t799 = load ptr, ptr %l0, !tbaa !29
  %t801 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t799)
  store i32 %t801, ptr %l293
  br label %bb171
bb171:
  %t802 = load ptr, ptr %l0, !tbaa !29
  %t804 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexpr(ptr %v0, ptr %v1, ptr %t802)
  %t805 = extractvalue { i32, ptr } %t804, 1
  %t806 = extractvalue { i32, ptr } %t804, 0
  store i32 %t806, ptr %l297
  %t807 = icmp ne i32 %t806, 0
  br i1 %t807, label %bb173, label %ok.808, !prof !99
ok.808:
  store ptr %t805, ptr %l296
  br label %bb172
bb172:
  %t809 = load ptr, ptr %l296, !tbaa !29
  store ptr %t809, ptr %l294, !tbaa !29
  br label %bb174
bb173:
  %t810 = load i32, ptr %l297, !tbaa !23
  %t811 = lshr i32 %t810, 16
  %t812 = and i32 %t810, 65535
  %t813 = icmp eq i32 %t811, 1
  %t814 = select i1 %t813, i32 1, i32 0
  %t815 = icmp eq i32 %t810, 0
  %t816 = shl i32 %t814, 16
  %t817 = or i32 %t816, %t812
  %t818 = select i1 %t815, i32 0, i32 %t817
  call void @__olang_scope_close(ptr %s16)
  %t820 = insertvalue { i32, ptr } zeroinitializer, i32 %t818, 0
  store { i32, ptr } %t820, ptr %rv
  br label %ret
bb174:
  %t821 = load ptr, ptr %l294, !tbaa !29
  store ptr %t821, ptr %l21, !tbaa !29
  %t822 = load ptr, ptr %l0, !tbaa !29
  %t823 = load i32, ptr %l1, !tbaa !23
  %t826 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t822, i32 %t823)
  store %"compiler/source:Span" %t826, ptr %l301
  br label %bb175
bb175:
  %t827 = load %"compiler/source:Span", ptr %l301
  store %"compiler/source:Span" %t827, ptr %l22
  %t828 = load ptr, ptr %l0, !tbaa !29
  %t830 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eendStmt(ptr %v0, ptr %t828)
  store i32 %t830, ptr %l303
  %t831 = icmp ne i32 %t830, 0
  br i1 %t831, label %bb177, label %ok.832, !prof !99
ok.832:
  br label %bb176
bb176:
  br label %bb178
bb177:
  %t833 = load i32, ptr %l303, !tbaa !23
  %t834 = lshr i32 %t833, 16
  %t835 = and i32 %t833, 65535
  %t836 = icmp eq i32 %t834, 1
  %t837 = select i1 %t836, i32 1, i32 0
  %t838 = icmp eq i32 %t833, 0
  %t839 = shl i32 %t837, 16
  %t840 = or i32 %t839, %t835
  %t841 = select i1 %t838, i32 0, i32 %t840
  call void @__olang_scope_close(ptr %s16)
  %t843 = insertvalue { i32, ptr } zeroinitializer, i32 %t841, 0
  store { i32, ptr } %t843, ptr %rv
  br label %ret
bb178:
  %t844 = load %"compiler/source:Span", ptr %l22
  store %"compiler/source:Span" %t844, ptr %l305
  %t845 = getelementptr %"compiler/token:Token", ptr %l19, i32 0, i32 2
  %t846 = load i32, ptr %t845, !tbaa !23
  %t847 = getelementptr %"compiler/token:Token", ptr %l19, i32 0, i32 3
  %t848 = load i32, ptr %t847, !tbaa !23
  %t851 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v1, i32 %t846, i32 %t848)
  store %"compiler/source:Span" %t851, ptr %l308
  br label %bb179
bb179:
  %t852 = load i32, ptr %l20, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t853
  %t854 = getelementptr { i64, [4 x i64] }, ptr %t853, i32 0, i32 0
  store i64 0, ptr %t854
  %t855 = load %"compiler/source:Span", ptr %l308
  %t856 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t855, 0
  %t858 = insertvalue { %"compiler/source:Span", i32 } %t856, i32 %t852, 1
  %t859 = getelementptr { i64, [4 x i64] }, ptr %t853, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t858, ptr %t859
  %t860 = load { i64, [4 x i64] }, ptr %t853
  %t862 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 40, i64 8)
  store { i64, [4 x i64] } %t860, ptr %t862
  %t863 = load ptr, ptr %l21, !tbaa !29
  store { i64, [8 x i64] } zeroinitializer, ptr %t864
  %t865 = getelementptr { i64, [8 x i64] }, ptr %t864, i32 0, i32 0
  store i64 9, ptr %t865
  %t866 = load %"compiler/source:Span", ptr %l305
  %t867 = insertvalue { %"compiler/source:Span", ptr, ptr } undef, %"compiler/source:Span" %t866, 0
  %t869 = insertvalue { %"compiler/source:Span", ptr, ptr } %t867, ptr %t862, 1
  %t871 = insertvalue { %"compiler/source:Span", ptr, ptr } %t869, ptr %t863, 2
  %t872 = getelementptr { i64, [8 x i64] }, ptr %t864, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr } %t871, ptr %t872
  %t873 = load { i64, [8 x i64] }, ptr %t864
  %t875 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 72, i64 8)
  store { i64, [8 x i64] } %t873, ptr %t875
  call void @__olang_scope_close(ptr %s16)
  %t877 = insertvalue { i32, ptr } zeroinitializer, ptr %t875, 1
  store { i32, ptr } %t877, ptr %rv
  br label %ret
bb180:
  %t878 = load ptr, ptr %l0, !tbaa !29
  %t880 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2edeclNames(ptr %v0, ptr %v1, ptr %t878, i1 false)
  %t881 = extractvalue { i32, ptr } %t880, 1
  %t882 = extractvalue { i32, ptr } %t880, 0
  store i32 %t882, ptr %l318
  %t883 = icmp ne i32 %t882, 0
  br i1 %t883, label %bb182, label %ok.884, !prof !99
ok.884:
  store ptr %t881, ptr %l317
  br label %bb181
bb181:
  %t885 = load ptr, ptr %l317, !tbaa !29
  store ptr %t885, ptr %l315, !tbaa !29
  br label %bb183
bb182:
  %t886 = load i32, ptr %l318, !tbaa !23
  %t887 = lshr i32 %t886, 16
  %t888 = and i32 %t886, 65535
  %t889 = icmp eq i32 %t887, 1
  %t890 = select i1 %t889, i32 1, i32 0
  %t891 = icmp eq i32 %t886, 0
  %t892 = shl i32 %t890, 16
  %t893 = or i32 %t892, %t888
  %t894 = select i1 %t891, i32 0, i32 %t893
  call void @__olang_scope_close(ptr %s16)
  %t896 = insertvalue { i32, ptr } zeroinitializer, i32 %t894, 0
  store { i32, ptr } %t896, ptr %rv
  br label %ret
bb183:
  %t897 = load ptr, ptr %l315, !tbaa !29
  store ptr %t897, ptr %l23, !tbaa !29
  %t898 = load ptr, ptr %l0, !tbaa !29
  %t899 = load i32, ptr %l1, !tbaa !23
  %t902 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t898, i32 %t899)
  store %"compiler/source:Span" %t902, ptr %l322
  br label %bb184
bb184:
  %t903 = load %"compiler/source:Span", ptr %l322
  store %"compiler/source:Span" %t903, ptr %l24
  %t904 = load ptr, ptr %l0, !tbaa !29
  %t906 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eendStmt(ptr %v0, ptr %t904)
  store i32 %t906, ptr %l324
  %t907 = icmp ne i32 %t906, 0
  br i1 %t907, label %bb186, label %ok.908, !prof !99
ok.908:
  br label %bb185
bb185:
  br label %bb187
bb186:
  %t909 = load i32, ptr %l324, !tbaa !23
  %t910 = lshr i32 %t909, 16
  %t911 = and i32 %t909, 65535
  %t912 = icmp eq i32 %t910, 1
  %t913 = select i1 %t912, i32 1, i32 0
  %t914 = icmp eq i32 %t909, 0
  %t915 = shl i32 %t913, 16
  %t916 = or i32 %t915, %t911
  %t917 = select i1 %t914, i32 0, i32 %t916
  call void @__olang_scope_close(ptr %s16)
  %t919 = insertvalue { i32, ptr } zeroinitializer, i32 %t917, 0
  store { i32, ptr } %t919, ptr %rv
  br label %ret
bb187:
  %t920 = load %"compiler/source:Span", ptr %l24
  %t921 = load ptr, ptr %l23, !tbaa !29
  store { i64, [8 x i64] } zeroinitializer, ptr %t922
  %t923 = getelementptr { i64, [8 x i64] }, ptr %t922, i32 0, i32 0
  store i64 4, ptr %t923
  %t925 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t920, 0
  %t927 = insertvalue { %"compiler/source:Span", ptr } %t925, ptr %t921, 1
  %t928 = getelementptr { i64, [8 x i64] }, ptr %t922, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t927, ptr %t928
  %t929 = load { i64, [8 x i64] }, ptr %t922
  %t931 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 72, i64 8)
  store { i64, [8 x i64] } %t929, ptr %t931
  call void @__olang_scope_close(ptr %s16)
  %t933 = insertvalue { i32, ptr } zeroinitializer, ptr %t931, 1
  store { i32, ptr } %t933, ptr %rv
  br label %ret
bb188:
  br i1 true, label %bb189, label %bb190
bb189:
  br label %bb191
bb190:
  br label %bb195
bb191:
  store %olang.scope zeroinitializer, ptr %s19
  %t934 = load ptr, ptr %l0, !tbaa !29
  %t936 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2efail(ptr %v0, ptr %s19, ptr %t934, { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d1, i32 0, i32 1) })
  store i32 %t936, ptr %l331
  %t937 = icmp ne i32 %t936, 0
  br i1 %t937, label %bb193, label %ok.938, !prof !99
ok.938:
  br label %bb192
bb192:
  br label %bb194
bb193:
  %t939 = load i32, ptr %l331, !tbaa !23
  %t940 = lshr i32 %t939, 16
  %t941 = and i32 %t939, 65535
  %t942 = icmp eq i32 %t940, 1
  %t943 = select i1 %t942, i32 1, i32 0
  %t944 = icmp eq i32 %t939, 0
  %t945 = shl i32 %t943, 16
  %t946 = or i32 %t945, %t941
  %t947 = select i1 %t944, i32 0, i32 %t946
  call void @__olang_scope_close(ptr %s19)
  %t949 = insertvalue { i32, ptr } zeroinitializer, i32 %t947, 0
  store { i32, ptr } %t949, ptr %rv
  br label %ret
bb194:
  call void @__olang_scope_close(ptr %s19)
  br label %bb196
bb195:
  call void @__olang_check_failed(ptr @olang_loc_2df52f758a425120_e9eb2ffac7d00514)
  unreachable
bb196:
  call void @__olang_check_failed(ptr @olang_loc_88d6a58aae0d0f1b_e8616324f90aa74f)
  unreachable
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2edeclNames(ptr %v0, ptr %v1, ptr %a0, i1 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca %"compiler/token:Token"
  %lp5 = alloca ptr
  %l8 = alloca i64
  %l11 = alloca i64
  %l13 = alloca %"compiler/token:Token"
  %l15 = alloca ptr
  %l16 = alloca i32
  %l18 = alloca i32
  %l19 = alloca i32
  %l22 = alloca ptr
  %l25 = alloca %"compiler/source:Span"
  %l28 = alloca i1
  %l30 = alloca i64
  %l35 = alloca { i64, ptr }
  %l36 = alloca i64
  %l41 = alloca { i64, ptr }
  %l42 = alloca %"compiler/parse:NameList"
  %l43 = alloca ptr
  %l47 = alloca ptr
  %l48 = alloca i32
  %s1 = alloca %olang.scope
  %rv = alloca { i32, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/parse:Parser", ptr %t1, i32 0, i32 39
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eLen_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l8
  br label %bb1
bb1:
  %t6 = load i64, ptr %l8, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/parse:Parser", ptr %t7, i32 0, i32 40
  %t11 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eLen_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t9)
  store i64 %t11, ptr %l11
  br label %bb2
bb2:
  %t12 = load i64, ptr %l11, !tbaa !24
  store i64 %t12, ptr %l3, !tbaa !24
  br label %bb3
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2etk(ptr %v0, ptr %t13)
  store %"compiler/token:Token" %t15, ptr %l13
  br label %bb4
bb4:
  %t16 = load %"compiler/token:Token", ptr %l13
  store %"compiler/token:Token" %t16, ptr %l4
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/parse:Parser", ptr %t17, i32 0, i32 39
  store ptr %t19, ptr %l15, !tbaa !29
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ename(ptr %v0, ptr %t20)
  %t23 = extractvalue { i32, i32 } %t22, 1
  %t24 = extractvalue { i32, i32 } %t22, 0
  store i32 %t24, ptr %l19
  %t25 = icmp ne i32 %t24, 0
  br i1 %t25, label %bb6, label %ok.26, !prof !99
ok.26:
  store i32 %t23, ptr %l18
  br label %bb5
bb5:
  %t27 = load i32, ptr %l18, !tbaa !23
  store i32 %t27, ptr %l16, !tbaa !23
  br label %bb7
bb6:
  %t28 = load i32, ptr %l19, !tbaa !23
  %t29 = lshr i32 %t28, 16
  %t30 = and i32 %t28, 65535
  %t31 = icmp eq i32 %t29, 1
  %t32 = select i1 %t31, i32 1, i32 0
  %t33 = icmp eq i32 %t28, 0
  %t34 = shl i32 %t32, 16
  %t35 = or i32 %t34, %t30
  %t36 = select i1 %t33, i32 0, i32 %t35
  call void @__olang_scope_close(ptr %s1)
  %t38 = insertvalue { i32, ptr } zeroinitializer, i32 %t36, 0
  store { i32, ptr } %t38, ptr %rv
  br label %ret
bb7:
  %t39 = load ptr, ptr %l15, !tbaa !29
  %t40 = load i32, ptr %l16, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ePush_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t39, i32 %t40)
  br label %bb8
bb8:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/parse:Parser", ptr %t41, i32 0, i32 40
  store ptr %t43, ptr %l22, !tbaa !29
  %t44 = getelementptr %"compiler/token:Token", ptr %l4, i32 0, i32 2
  %t45 = load i32, ptr %t44, !tbaa !23
  %t46 = getelementptr %"compiler/token:Token", ptr %l4, i32 0, i32 3
  %t47 = load i32, ptr %t46, !tbaa !23
  %t50 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s1, i32 %t45, i32 %t47)
  store %"compiler/source:Span" %t50, ptr %l25
  br label %bb9
bb9:
  %t51 = load ptr, ptr %l22, !tbaa !29
  %t52 = load %"compiler/source:Span", ptr %l25
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ePush_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t51, %"compiler/source:Span" %t52)
  br label %bb10
bb10:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t56 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t53, i32 75)
  store i1 %t56, ptr %l28
  br label %bb11
bb11:
  %t57 = load i1, ptr %l28, !tbaa !21
  %t58 = xor i1 %t57, true
  br i1 %t58, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s1)
  br label %bb16
bb13:
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s1)
  br label %bb15
bb15:
  br label %bb3
bb16:
  %t60 = call ptr @__olang_scope_hold(ptr %v1)
  %t61 = ptrtoint ptr %t60 to i64
  store i64 %t61, ptr %l30, !tbaa !24
  %t62 = load i1, ptr @olang_2esole_2ecompiler_2fparse_3aNameList_2e0
  br i1 %t62, label %bb17, label %bb18
bb17:
  %t64 = call ptr @__olang_region_make(ptr %v1)
  %t65 = ptrtoint ptr %t64 to i64
  store i64 %t65, ptr %l30, !tbaa !24
  br label %bb18
bb18:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"compiler/parse:Parser", ptr %t66, i32 0, i32 39
  %t69 = load i64, ptr %l2, !tbaa !24
  %t70 = load i64, ptr %l30
  %t71 = inttoptr i64 %t70 to ptr
  %t74 = call { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t71, ptr %t68, i64 %t69)
  store { i64, ptr } %t74, ptr %l35
  br label %bb19
bb19:
  %t75 = call ptr @__olang_scope_hold(ptr %v1)
  %t76 = ptrtoint ptr %t75 to i64
  store i64 %t76, ptr %l36, !tbaa !24
  %t77 = load i1, ptr @olang_2esole_2ecompiler_2fparse_3aNameList_2e1
  br i1 %t77, label %bb20, label %bb21
bb20:
  %t79 = call ptr @__olang_region_make(ptr %v1)
  %t80 = ptrtoint ptr %t79 to i64
  store i64 %t80, ptr %l36, !tbaa !24
  br label %bb21
bb21:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"compiler/parse:Parser", ptr %t81, i32 0, i32 40
  %t84 = load i64, ptr %l3, !tbaa !24
  %t85 = load i64, ptr %l36
  %t86 = inttoptr i64 %t85 to ptr
  %t89 = call { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t86, ptr %t83, i64 %t84)
  store { i64, ptr } %t89, ptr %l41
  br label %bb22
bb22:
  %t90 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t91 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t92 = call %"compiler/parse:NameList" @compiler_2fparse_3aNameList_2ector(ptr %v1, ptr %v1, ptr %v1, { i64, ptr } %t90, { i64, ptr } %t91)
  store %"compiler/parse:NameList" %t92, ptr %l42
  br label %bb23
bb23:
  %t93 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 32, i64 8)
  store ptr %t93, ptr %lp5
  %t94 = load %"compiler/parse:NameList", ptr %l42
  %t95 = load ptr, ptr %lp5
  store %"compiler/parse:NameList" %t94, ptr %t95
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t97 = load ptr, ptr %lp5
  %t102 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2edeclRest(ptr %v0, ptr %v1, ptr %v1, ptr %t96, ptr %t97, i1 %a1)
  %t103 = extractvalue { i32, ptr } %t102, 1
  %t104 = extractvalue { i32, ptr } %t102, 0
  store i32 %t104, ptr %l48
  %t105 = icmp ne i32 %t104, 0
  br i1 %t105, label %bb25, label %ok.106, !prof !99
ok.106:
  store ptr %t103, ptr %l47
  br label %bb24
bb24:
  %t107 = load ptr, ptr %l47, !tbaa !29
  store ptr %t107, ptr %l43, !tbaa !29
  br label %bb26
bb25:
  %t108 = load i32, ptr %l48, !tbaa !23
  %t109 = lshr i32 %t108, 16
  %t110 = and i32 %t108, 65535
  %t111 = icmp eq i32 %t109, 1
  %t112 = select i1 %t111, i32 1, i32 0
  %t113 = icmp eq i32 %t108, 0
  %t114 = shl i32 %t112, 16
  %t115 = or i32 %t114, %t110
  %t116 = select i1 %t113, i32 0, i32 %t115
  %t118 = insertvalue { i32, ptr } zeroinitializer, i32 %t116, 0
  store { i32, ptr } %t118, ptr %rv
  br label %ret
bb26:
  %t119 = load ptr, ptr %l43, !tbaa !29
  %t120 = insertvalue { i32, ptr } zeroinitializer, ptr %t119, 1
  store { i32, ptr } %t120, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2edeclRest(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i1 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %lp4 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca ptr
  %l9 = alloca { i64, ptr }
  %l12 = alloca i1
  %l13 = alloca i1
  %l15 = alloca i32
  %l19 = alloca i32
  %l23 = alloca %"compiler/source:Span"
  %l26 = alloca i32
  %l27 = alloca { i64, ptr }
  %l31 = alloca { i64, ptr }
  %l32 = alloca i32
  %l41 = alloca %"compiler/ast:VarDecl"
  %l45 = alloca i1
  %l46 = alloca { i64, ptr }
  %l50 = alloca { i64, ptr }
  %l51 = alloca i32
  %l57 = alloca i1
  %l74 = alloca %"compiler/ast:VarDecl"
  %l78 = alloca i1
  %l79 = alloca { i64, ptr }
  %l83 = alloca { i64, ptr }
  %l84 = alloca i32
  %l90 = alloca i1
  %l107 = alloca %"compiler/ast:VarDecl"
  %l109 = alloca ptr
  %l111 = alloca ptr
  %l112 = alloca i32
  %l119 = alloca i1
  %l120 = alloca { i64, ptr }
  %l124 = alloca { i64, ptr }
  %l125 = alloca i32
  %l133 = alloca i1
  %l150 = alloca %"compiler/ast:VarDecl"
  %rv = alloca { i32, ptr }
  %t27 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i1 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t4 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t1, i32 39)
  store i1 %t4, ptr %l12
  br label %bb1
bb1:
  %t5 = load i1, ptr %l12, !tbaa !21
  br i1 %t5, label %bb2, label %bb3
bb2:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elook(ptr %v0, ptr %t6, i64 1)
  store i32 %t8, ptr %l15
  br label %bb4
bb3:
  store i1 false, ptr %l13, !tbaa !21
  br label %bb5
bb4:
  %t9 = load i32, ptr %l15, !range !{i32 0, i32 116}
  %t11 = trunc i64 80 to i32
  %t12 = icmp eq i32 %t9, %t11
  store i1 %t12, ptr %l13, !tbaa !21
  br label %bb5
bb5:
  %t14 = load i1, ptr %l13, !tbaa !21
  br i1 %t14, label %bb6, label %bb7
bb6:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t15)
  store i32 %t17, ptr %l19
  br label %bb8
bb7:
  br label %bb15
bb8:
  %t18 = load i32, ptr %l19, !tbaa !23
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/parse:Parser", ptr %t20, i32 0, i32 10
  %t23 = load i32, ptr %t22, !tbaa !23
  %t26 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v2, i32 %t18, i32 %t23)
  store %"compiler/source:Span" %t26, ptr %l23
  br label %bb9
bb9:
  store { i64, [5 x i64] } zeroinitializer, ptr %t27
  %t28 = getelementptr { i64, [5 x i64] }, ptr %t27, i32 0, i32 0
  store i64 4, ptr %t28
  %t29 = load %"compiler/source:Span", ptr %l23
  %t30 = insertvalue { %"compiler/source:Span", ptr, i1 } undef, %"compiler/source:Span" %t29, 0
  %t31 = insertvalue { %"compiler/source:Span", ptr, i1 } %t30, ptr null, 1
  %t32 = insertvalue { %"compiler/source:Span", ptr, i1 } %t31, i1 true, 2
  %t33 = getelementptr { i64, [5 x i64] }, ptr %t27, i32 0, i32 1
  store { %"compiler/source:Span", ptr, i1 } %t32, ptr %t33
  %t34 = load { i64, [5 x i64] }, ptr %t27
  %t35 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 48, i64 8)
  store ptr %t35, ptr %lp4
  %t37 = load ptr, ptr %lp4
  store { i64, [5 x i64] } %t34, ptr %t37
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t38)
  store i32 %t40, ptr %l26
  br label %bb10
bb10:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t42 = load ptr, ptr %l1, !tbaa !29
  %t43 = load i1, ptr %l2, !tbaa !21
  %t47 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2evalues(ptr %v0, ptr %v1, ptr %v2, ptr %t41, ptr %t42, i1 %t43)
  %t48 = extractvalue { i32, { i64, ptr } } %t47, 1
  %t49 = extractvalue { i32, { i64, ptr } } %t47, 0
  store i32 %t49, ptr %l32
  %t50 = icmp ne i32 %t49, 0
  br i1 %t50, label %bb12, label %ok.51, !prof !99
ok.51:
  store { i64, ptr } %t48, ptr %l31
  br label %bb11
bb11:
  %t52 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t52, ptr %l27, !tbaa !27
  br label %bb13
bb12:
  %t53 = load i32, ptr %l32, !tbaa !23
  %t54 = lshr i32 %t53, 16
  %t55 = and i32 %t53, 65535
  %t56 = icmp eq i32 %t54, 1
  %t57 = select i1 %t56, i32 1, i32 0
  %t58 = icmp eq i32 %t53, 0
  %t59 = shl i32 %t57, 16
  %t60 = or i32 %t59, %t55
  %t61 = select i1 %t58, i32 0, i32 %t60
  %t63 = insertvalue { i32, ptr } zeroinitializer, i32 %t61, 0
  store { i32, ptr } %t63, ptr %rv
  br label %ret
bb13:
  %t64 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t65 = load ptr, ptr %l1, !tbaa !29
  %t67 = getelementptr %"compiler/parse:NameList", ptr %t65, i32 0, i32 0
  %t68 = load { i64, ptr }, ptr %t67, !tbaa !27
  %t69 = load ptr, ptr %l1, !tbaa !29
  %t71 = getelementptr %"compiler/parse:NameList", ptr %t69, i32 0, i32 1
  %t72 = load { i64, ptr }, ptr %t71, !tbaa !27
  %t73 = load ptr, ptr %lp4
  %t75 = load i1, ptr %l2, !tbaa !21
  %t81 = call %"compiler/ast:VarDecl" @compiler_2fast_3aVarDecl_2ector(ptr %v1, ptr %v1, ptr %v2, ptr %v2, ptr %v2, { i64, ptr } %t68, { i64, ptr } %t72, ptr %t73, { i64, ptr } %t64, i1 true, i1 %t75, i1 false)
  store %"compiler/ast:VarDecl" %t81, ptr %l41
  br label %bb14
bb14:
  %t82 = load %"compiler/ast:VarDecl", ptr %l41
  %t83 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 64, i64 8)
  store %"compiler/ast:VarDecl" %t82, ptr %t83
  %t85 = insertvalue { i32, ptr } zeroinitializer, ptr %t83, 1
  store { i32, ptr } %t85, ptr %rv
  br label %ret
bb15:
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t89 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t86, i32 80)
  store i1 %t89, ptr %l45
  br label %bb16
bb16:
  %t90 = load i1, ptr %l45, !tbaa !21
  br i1 %t90, label %bb17, label %bb18
bb17:
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t92 = load ptr, ptr %l1, !tbaa !29
  %t93 = load i1, ptr %l2, !tbaa !21
  %t97 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2evalues(ptr %v0, ptr %v1, ptr %v2, ptr %t91, ptr %t92, i1 %t93)
  %t98 = extractvalue { i32, { i64, ptr } } %t97, 1
  %t99 = extractvalue { i32, { i64, ptr } } %t97, 0
  store i32 %t99, ptr %l51
  %t100 = icmp ne i32 %t99, 0
  br i1 %t100, label %bb20, label %ok.101, !prof !99
ok.101:
  store { i64, ptr } %t98, ptr %l50
  br label %bb19
bb18:
  br label %bb30
bb19:
  %t102 = load { i64, ptr }, ptr %l50, !tbaa !27
  store { i64, ptr } %t102, ptr %l46, !tbaa !27
  br label %bb21
bb20:
  %t103 = load i32, ptr %l51, !tbaa !23
  %t104 = lshr i32 %t103, 16
  %t105 = and i32 %t103, 65535
  %t106 = icmp eq i32 %t104, 1
  %t107 = select i1 %t106, i32 1, i32 0
  %t108 = icmp eq i32 %t103, 0
  %t109 = shl i32 %t107, 16
  %t110 = or i32 %t109, %t105
  %t111 = select i1 %t108, i32 0, i32 %t110
  %t113 = insertvalue { i32, ptr } zeroinitializer, i32 %t111, 0
  store { i32, ptr } %t113, ptr %rv
  br label %ret
bb21:
  %t114 = load { i64, ptr }, ptr %l46, !tbaa !27
  store { i64, ptr } %t114, ptr %l6, !tbaa !27
  %t115 = load ptr, ptr %l1, !tbaa !29
  %t117 = getelementptr %"compiler/parse:NameList", ptr %t115, i32 0, i32 0
  %t118 = load { i64, ptr }, ptr %t117, !tbaa !27
  %t120 = extractvalue { i64, ptr } %t118, 0
  %t122 = icmp sgt i64 %t120, 1
  br i1 %t122, label %bb22, label %bb23
bb22:
  %t124 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t126 = extractvalue { i64, ptr } %t124, 0
  %t127 = load ptr, ptr %l1, !tbaa !29
  %t129 = getelementptr %"compiler/parse:NameList", ptr %t127, i32 0, i32 0
  %t130 = load { i64, ptr }, ptr %t129, !tbaa !27
  %t132 = extractvalue { i64, ptr } %t130, 0
  %t135 = icmp ne i64 %t126, %t132
  store i1 %t135, ptr %l57, !tbaa !21
  br label %bb24
bb23:
  store i1 false, ptr %l57, !tbaa !21
  br label %bb24
bb24:
  %t137 = load i1, ptr %l57, !tbaa !21
  br i1 %t137, label %bb25, label %bb26
bb25:
  %t138 = load ptr, ptr %l0, !tbaa !29
  %t139 = load ptr, ptr %l1, !tbaa !29
  %t140 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t142 = extractvalue { i64, ptr } %t140, 0
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ecountDiag(ptr %v0, ptr %v1, ptr %t138, ptr %t139, i64 %t142)
  br label %bb27
bb26:
  br label %bb28
bb27:
  br label %bb28
bb28:
  %t146 = load ptr, ptr %l1, !tbaa !29
  %t148 = getelementptr %"compiler/parse:NameList", ptr %t146, i32 0, i32 0
  %t149 = load { i64, ptr }, ptr %t148, !tbaa !27
  %t150 = load ptr, ptr %l1, !tbaa !29
  %t152 = getelementptr %"compiler/parse:NameList", ptr %t150, i32 0, i32 1
  %t153 = load { i64, ptr }, ptr %t152, !tbaa !27
  %t154 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t155 = load i1, ptr %l2, !tbaa !21
  %t160 = call %"compiler/ast:VarDecl" @compiler_2fast_3aVarDecl_2ector(ptr %v1, ptr %v1, ptr %v2, ptr %v2, ptr %v2, { i64, ptr } %t149, { i64, ptr } %t153, ptr null, { i64, ptr } %t154, i1 true, i1 %t155, i1 false)
  store %"compiler/ast:VarDecl" %t160, ptr %l74
  br label %bb29
bb29:
  %t161 = load %"compiler/ast:VarDecl", ptr %l74
  %t162 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 64, i64 8)
  store %"compiler/ast:VarDecl" %t161, ptr %t162
  %t164 = insertvalue { i32, ptr } zeroinitializer, ptr %t162, 1
  store { i32, ptr } %t164, ptr %rv
  br label %ret
bb30:
  %t165 = load ptr, ptr %l0, !tbaa !29
  %t168 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t165, i32 81)
  store i1 %t168, ptr %l78
  br label %bb31
bb31:
  %t169 = load i1, ptr %l78, !tbaa !21
  br i1 %t169, label %bb32, label %bb33
bb32:
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t171 = load ptr, ptr %l1, !tbaa !29
  %t172 = load i1, ptr %l2, !tbaa !21
  %t176 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2evalues(ptr %v0, ptr %v1, ptr %v2, ptr %t170, ptr %t171, i1 %t172)
  %t177 = extractvalue { i32, { i64, ptr } } %t176, 1
  %t178 = extractvalue { i32, { i64, ptr } } %t176, 0
  store i32 %t178, ptr %l84
  %t179 = icmp ne i32 %t178, 0
  br i1 %t179, label %bb35, label %ok.180, !prof !99
ok.180:
  store { i64, ptr } %t177, ptr %l83
  br label %bb34
bb33:
  br label %bb45
bb34:
  %t181 = load { i64, ptr }, ptr %l83, !tbaa !27
  store { i64, ptr } %t181, ptr %l79, !tbaa !27
  br label %bb36
bb35:
  %t182 = load i32, ptr %l84, !tbaa !23
  %t183 = lshr i32 %t182, 16
  %t184 = and i32 %t182, 65535
  %t185 = icmp eq i32 %t183, 1
  %t186 = select i1 %t185, i32 1, i32 0
  %t187 = icmp eq i32 %t182, 0
  %t188 = shl i32 %t186, 16
  %t189 = or i32 %t188, %t184
  %t190 = select i1 %t187, i32 0, i32 %t189
  %t192 = insertvalue { i32, ptr } zeroinitializer, i32 %t190, 0
  store { i32, ptr } %t192, ptr %rv
  br label %ret
bb36:
  %t193 = load { i64, ptr }, ptr %l79, !tbaa !27
  store { i64, ptr } %t193, ptr %l7, !tbaa !27
  %t194 = load ptr, ptr %l1, !tbaa !29
  %t196 = getelementptr %"compiler/parse:NameList", ptr %t194, i32 0, i32 0
  %t197 = load { i64, ptr }, ptr %t196, !tbaa !27
  %t199 = extractvalue { i64, ptr } %t197, 0
  %t201 = icmp sgt i64 %t199, 1
  br i1 %t201, label %bb37, label %bb38
bb37:
  %t203 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t205 = extractvalue { i64, ptr } %t203, 0
  %t206 = load ptr, ptr %l1, !tbaa !29
  %t208 = getelementptr %"compiler/parse:NameList", ptr %t206, i32 0, i32 0
  %t209 = load { i64, ptr }, ptr %t208, !tbaa !27
  %t211 = extractvalue { i64, ptr } %t209, 0
  %t214 = icmp ne i64 %t205, %t211
  store i1 %t214, ptr %l90, !tbaa !21
  br label %bb39
bb38:
  store i1 false, ptr %l90, !tbaa !21
  br label %bb39
bb39:
  %t216 = load i1, ptr %l90, !tbaa !21
  br i1 %t216, label %bb40, label %bb41
bb40:
  %t217 = load ptr, ptr %l0, !tbaa !29
  %t218 = load ptr, ptr %l1, !tbaa !29
  %t219 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t221 = extractvalue { i64, ptr } %t219, 0
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ecountDiag(ptr %v0, ptr %v1, ptr %t217, ptr %t218, i64 %t221)
  br label %bb42
bb41:
  br label %bb43
bb42:
  br label %bb43
bb43:
  %t225 = load ptr, ptr %l1, !tbaa !29
  %t227 = getelementptr %"compiler/parse:NameList", ptr %t225, i32 0, i32 0
  %t228 = load { i64, ptr }, ptr %t227, !tbaa !27
  %t229 = load ptr, ptr %l1, !tbaa !29
  %t231 = getelementptr %"compiler/parse:NameList", ptr %t229, i32 0, i32 1
  %t232 = load { i64, ptr }, ptr %t231, !tbaa !27
  %t233 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t234 = load i1, ptr %l2, !tbaa !21
  %t239 = call %"compiler/ast:VarDecl" @compiler_2fast_3aVarDecl_2ector(ptr %v1, ptr %v1, ptr %v2, ptr %v2, ptr %v2, { i64, ptr } %t228, { i64, ptr } %t232, ptr null, { i64, ptr } %t233, i1 true, i1 %t234, i1 true)
  store %"compiler/ast:VarDecl" %t239, ptr %l107
  br label %bb44
bb44:
  %t240 = load %"compiler/ast:VarDecl", ptr %l107
  %t241 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 64, i64 8)
  store %"compiler/ast:VarDecl" %t240, ptr %t241
  %t243 = insertvalue { i32, ptr } zeroinitializer, ptr %t241, 1
  store { i32, ptr } %t243, ptr %rv
  br label %ret
bb45:
  %t244 = load ptr, ptr %l0, !tbaa !29
  %t246 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeExpr(ptr %v0, ptr %v2, ptr %t244)
  %t247 = extractvalue { i32, ptr } %t246, 1
  %t248 = extractvalue { i32, ptr } %t246, 0
  store i32 %t248, ptr %l112
  %t249 = icmp ne i32 %t248, 0
  br i1 %t249, label %bb47, label %ok.250, !prof !99
ok.250:
  store ptr %t247, ptr %l111
  br label %bb46
bb46:
  %t251 = load ptr, ptr %l111, !tbaa !29
  store ptr %t251, ptr %l109, !tbaa !29
  br label %bb48
bb47:
  %t252 = load i32, ptr %l112, !tbaa !23
  %t253 = lshr i32 %t252, 16
  %t254 = and i32 %t252, 65535
  %t255 = icmp eq i32 %t253, 1
  %t256 = select i1 %t255, i32 1, i32 0
  %t257 = icmp eq i32 %t252, 0
  %t258 = shl i32 %t256, 16
  %t259 = or i32 %t258, %t254
  %t260 = select i1 %t257, i32 0, i32 %t259
  %t262 = insertvalue { i32, ptr } zeroinitializer, i32 %t260, 0
  store { i32, ptr } %t262, ptr %rv
  br label %ret
bb48:
  %t263 = load ptr, ptr %l109, !tbaa !29
  store ptr %t263, ptr %l8, !tbaa !29
  %t264 = icmp sge i64 0, 0
  br i1 %t264, label %bb49, label %bb50
bb49:
  %t266 = icmp sle i64 0, 1152921504606846975
  br i1 %t266, label %bb51, label %bb52
bb50:
  call void @__olang_check_failed(ptr @olang_loc_88b4df24f395cba0_7a8585039ef7582c)
  unreachable
bb51:
  %t268 = mul i64 0, 8
  %t269 = insertvalue { i64, ptr } undef, i64 0, 0
  %t270 = insertvalue { i64, ptr } %t269, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t270, ptr %l9, !tbaa !27
  %t272 = load ptr, ptr %l0, !tbaa !29
  %t275 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t272, i32 78)
  store i1 %t275, ptr %l119
  br label %bb53
bb52:
  call void @__olang_check_failed(ptr @olang_loc_88b4df24f395cba0_7a8585039ef7582c)
  unreachable
bb53:
  %t276 = load i1, ptr %l119, !tbaa !21
  br i1 %t276, label %bb54, label %bb55
bb54:
  %t277 = load ptr, ptr %l0, !tbaa !29
  %t278 = load ptr, ptr %l1, !tbaa !29
  %t279 = load i1, ptr %l2, !tbaa !21
  %t283 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2evalues(ptr %v0, ptr %v1, ptr %v2, ptr %t277, ptr %t278, i1 %t279)
  %t284 = extractvalue { i32, { i64, ptr } } %t283, 1
  %t285 = extractvalue { i32, { i64, ptr } } %t283, 0
  store i32 %t285, ptr %l125
  %t286 = icmp ne i32 %t285, 0
  br i1 %t286, label %bb57, label %ok.287, !prof !99
ok.287:
  store { i64, ptr } %t284, ptr %l124
  br label %bb56
bb55:
  br label %bb66
bb56:
  %t288 = load { i64, ptr }, ptr %l124, !tbaa !27
  store { i64, ptr } %t288, ptr %l120, !tbaa !27
  br label %bb58
bb57:
  %t289 = load i32, ptr %l125, !tbaa !23
  %t290 = lshr i32 %t289, 16
  %t291 = and i32 %t289, 65535
  %t292 = icmp eq i32 %t290, 1
  %t293 = select i1 %t292, i32 1, i32 0
  %t294 = icmp eq i32 %t289, 0
  %t295 = shl i32 %t293, 16
  %t296 = or i32 %t295, %t291
  %t297 = select i1 %t294, i32 0, i32 %t296
  %t299 = insertvalue { i32, ptr } zeroinitializer, i32 %t297, 0
  store { i32, ptr } %t299, ptr %rv
  br label %ret
bb58:
  %t300 = load { i64, ptr }, ptr %l120, !tbaa !27
  store { i64, ptr } %t300, ptr %l9, !tbaa !27
  %t301 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t303 = extractvalue { i64, ptr } %t301, 0
  %t304 = load ptr, ptr %l1, !tbaa !29
  %t306 = getelementptr %"compiler/parse:NameList", ptr %t304, i32 0, i32 0
  %t307 = load { i64, ptr }, ptr %t306, !tbaa !27
  %t309 = extractvalue { i64, ptr } %t307, 0
  %t312 = icmp ne i64 %t303, %t309
  br i1 %t312, label %bb59, label %bb60
bb59:
  %t314 = load ptr, ptr %l1, !tbaa !29
  %t316 = getelementptr %"compiler/parse:NameList", ptr %t314, i32 0, i32 0
  %t317 = load { i64, ptr }, ptr %t316, !tbaa !27
  %t319 = extractvalue { i64, ptr } %t317, 0
  %t321 = icmp sgt i64 %t319, 1
  store i1 %t321, ptr %l133, !tbaa !21
  br label %bb61
bb60:
  store i1 false, ptr %l133, !tbaa !21
  br label %bb61
bb61:
  %t323 = load i1, ptr %l133, !tbaa !21
  br i1 %t323, label %bb62, label %bb63
bb62:
  %t324 = load ptr, ptr %l0, !tbaa !29
  %t325 = load ptr, ptr %l1, !tbaa !29
  %t326 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t328 = extractvalue { i64, ptr } %t326, 0
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ecountDiag(ptr %v0, ptr %v1, ptr %t324, ptr %t325, i64 %t328)
  br label %bb64
bb63:
  br label %bb65
bb64:
  br label %bb65
bb65:
  br label %bb66
bb66:
  %t332 = load ptr, ptr %l1, !tbaa !29
  %t334 = getelementptr %"compiler/parse:NameList", ptr %t332, i32 0, i32 0
  %t335 = load { i64, ptr }, ptr %t334, !tbaa !27
  %t336 = load ptr, ptr %l1, !tbaa !29
  %t338 = getelementptr %"compiler/parse:NameList", ptr %t336, i32 0, i32 1
  %t339 = load { i64, ptr }, ptr %t338, !tbaa !27
  %t340 = load ptr, ptr %l8, !tbaa !29
  %t342 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t343 = load i1, ptr %l2, !tbaa !21
  %t349 = call %"compiler/ast:VarDecl" @compiler_2fast_3aVarDecl_2ector(ptr %v1, ptr %v1, ptr %v2, ptr %v2, ptr %v2, { i64, ptr } %t335, { i64, ptr } %t339, ptr %t340, { i64, ptr } %t342, i1 false, i1 %t343, i1 false)
  store %"compiler/ast:VarDecl" %t349, ptr %l150
  br label %bb67
bb67:
  %t350 = load %"compiler/ast:VarDecl", ptr %l150
  %t351 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 64, i64 8)
  store %"compiler/ast:VarDecl" %t350, ptr %t351
  %t353 = insertvalue { i32, ptr } zeroinitializer, ptr %t351, 1
  store { i32, ptr } %t353, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2edoBody(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i1
  %l2 = alloca i1
  %l5 = alloca { i64, ptr }
  %l8 = alloca i1
  %l10 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca i32
  %l23 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l26 = alloca i32
  %l34 = alloca i1
  %l41 = alloca ptr
  %l43 = alloca i64
  %l44 = alloca %"compiler/diagmsg:Msg"
  %l46 = alloca i32
  %l50 = alloca i32
  %rv = alloca { i32, { i64, ptr } }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t4 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t1, i32 79)
  store i1 %t4, ptr %l8
  br label %bb1
bb1:
  %t5 = load i1, ptr %l8, !tbaa !21
  %t6 = xor i1 %t5, true
  br i1 %t6, label %bb2, label %bb3
bb2:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eblock(ptr %v0, ptr %v1, ptr %t8)
  %t11 = extractvalue { i32, { i64, ptr } } %t10, 1
  %t12 = extractvalue { i32, { i64, ptr } } %t10, 0
  store i32 %t12, ptr %l13
  %t13 = icmp ne i32 %t12, 0
  br i1 %t13, label %bb5, label %ok.14, !prof !99
ok.14:
  store { i64, ptr } %t11, ptr %l12
  br label %bb4
bb3:
  br label %bb7
bb4:
  %t15 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t15, ptr %l10, !tbaa !27
  br label %bb6
bb5:
  %t16 = load i32, ptr %l13, !tbaa !23
  %t17 = lshr i32 %t16, 16
  %t18 = and i32 %t16, 65535
  %t19 = icmp eq i32 %t17, 1
  %t20 = select i1 %t19, i32 1, i32 0
  %t21 = icmp eq i32 %t16, 0
  %t22 = shl i32 %t20, 16
  %t23 = or i32 %t22, %t18
  %t24 = select i1 %t21, i32 0, i32 %t23
  %t26 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t24, 0
  store { i32, { i64, ptr } } %t26, ptr %rv
  br label %ret
bb6:
  %t27 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t28 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t27, 1
  store { i32, { i64, ptr } } %t28, ptr %rv
  br label %ret
bb7:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/parse:Parser", ptr %t29, i32 0, i32 19
  %t32 = load i1, ptr %t31, !tbaa !21
  store i1 %t32, ptr %l1, !tbaa !21
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/parse:Parser", ptr %t34, i32 0, i32 18
  %t37 = load i1, ptr %t36, !tbaa !21
  store i1 %t37, ptr %l2, !tbaa !21
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/parse:Parser", ptr %t39, i32 0, i32 19
  store i1 true, ptr %t43, !tbaa !21
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/parse:Parser", ptr %t44, i32 0, i32 18
  store i1 true, ptr %t48, !tbaa !21
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2elineBody(ptr %v0, ptr %v1, ptr %t49, i1 false)
  %t52 = extractvalue { i32, { i64, ptr } } %t51, 1
  %t53 = extractvalue { i32, { i64, ptr } } %t51, 0
  store i32 %t53, ptr %l26
  %t54 = icmp ne i32 %t53, 0
  br i1 %t54, label %bb9, label %ok.55, !prof !99
ok.55:
  store { i64, ptr } %t52, ptr %l25
  br label %bb8
bb8:
  %t56 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t56, ptr %l23, !tbaa !27
  br label %bb10
bb9:
  %t57 = load i32, ptr %l26, !tbaa !23
  %t58 = lshr i32 %t57, 16
  %t59 = and i32 %t57, 65535
  %t60 = icmp eq i32 %t58, 1
  %t61 = select i1 %t60, i32 1, i32 0
  %t62 = icmp eq i32 %t57, 0
  %t63 = shl i32 %t61, 16
  %t64 = or i32 %t63, %t59
  %t65 = select i1 %t62, i32 0, i32 %t64
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t67 = load i1, ptr %l1, !tbaa !21
  %t70 = getelementptr %"compiler/parse:Parser", ptr %t66, i32 0, i32 19
  store i1 %t67, ptr %t70, !tbaa !21
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t72 = load i1, ptr %l2, !tbaa !21
  %t75 = getelementptr %"compiler/parse:Parser", ptr %t71, i32 0, i32 18
  store i1 %t72, ptr %t75, !tbaa !21
  %t77 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t65, 0
  store { i32, { i64, ptr } } %t77, ptr %rv
  br label %ret
bb10:
  %t78 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t78, ptr %l5, !tbaa !27
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t82 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t79, i32 8)
  store i1 %t82, ptr %l34
  br label %bb11
bb11:
  %t83 = load i1, ptr %l34, !tbaa !21
  %t84 = xor i1 %t83, true
  br i1 %t84, label %bb12, label %bb13
bb12:
  %t86 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t88 = load i1, ptr %l1, !tbaa !21
  %t91 = getelementptr %"compiler/parse:Parser", ptr %t87, i32 0, i32 19
  store i1 %t88, ptr %t91, !tbaa !21
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t93 = load i1, ptr %l2, !tbaa !21
  %t96 = getelementptr %"compiler/parse:Parser", ptr %t92, i32 0, i32 18
  store i1 %t93, ptr %t96, !tbaa !21
  %t98 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t86, 1
  store { i32, { i64, ptr } } %t98, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  %t99 = load ptr, ptr %l0, !tbaa !29
  store ptr %t99, ptr %l41, !tbaa !29
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t102 = getelementptr %"compiler/parse:Parser", ptr %t100, i32 0, i32 6
  %t103 = load i64, ptr %t102, !tbaa !24
  store i64 %t103, ptr %l43, !tbaa !24
  %t104 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eDoLineFor(ptr %v0)
  store %"compiler/diagmsg:Msg" %t104, ptr %l44
  br label %bb15
bb15:
  %t105 = load ptr, ptr %l41, !tbaa !29
  %t106 = load i64, ptr %l43, !tbaa !24
  %t107 = load %"compiler/diagmsg:Msg", ptr %l44
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereportAt(ptr %v0, ptr %v0, ptr %t105, i64 %t106, %"compiler/diagmsg:Msg" %t107)
  br label %bb16
bb16:
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elook(ptr %v0, ptr %t108, i64 1)
  store i32 %t110, ptr %l46
  br label %bb17
bb17:
  %t111 = load i32, ptr %l46, !range !{i32 0, i32 116}
  %t113 = trunc i64 25 to i32
  %t114 = icmp eq i32 %t111, %t113
  br i1 %t114, label %bb18, label %bb19
bb18:
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t118 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t116)
  store i32 %t118, ptr %l50
  br label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb21
bb21:
  %t119 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t121 = load i1, ptr %l1, !tbaa !21
  %t124 = getelementptr %"compiler/parse:Parser", ptr %t120, i32 0, i32 19
  store i1 %t121, ptr %t124, !tbaa !21
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t126 = load i1, ptr %l2, !tbaa !21
  %t129 = getelementptr %"compiler/parse:Parser", ptr %t125, i32 0, i32 18
  store i1 %t126, ptr %t129, !tbaa !21
  %t131 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t119, 1
  store { i32, { i64, ptr } } %t131, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local ptr @compiler_2fparse_2ecompiler_2fparse_3aParser_2eelemsPattern(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l9 = alloca ptr
  %l12 = alloca i64
  %l20 = alloca { i64, ptr }
  %l25 = alloca ptr
  %l27 = alloca i1
  %l42 = alloca %"compiler/source:Span"
  %l43 = alloca ptr
  %l47 = alloca { i64, ptr }
  %rv = alloca ptr
  %t55 = alloca { i64, [4 x i64] }, align 8
  %t80 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/parse:Parser", ptr %t1, i32 0, i32 38
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aPattern_26_3e_2eLen_3ccompiler_2fast_3aPattern_26_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l12
  br label %bb1
bb1:
  %t6 = load i64, ptr %l12, !tbaa !24
  store i64 %t6, ptr %l4, !tbaa !24
  store { i64, ptr } %a3, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t9 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t9, 0
  store i64 %t11, ptr %l7, !tbaa !24
  br label %bb2
bb2:
  %t13 = load i64, ptr %l6, !tbaa !24
  %t14 = load i64, ptr %l7, !tbaa !24
  %t17 = icmp slt i64 %t13, %t14
  %t19 = xor i1 %t17, true
  br i1 %t19, label %bb3, label %bb4
bb3:
  br label %bb14
bb4:
  br label %bb5
bb5:
  %t21 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t21, ptr %l20, !tbaa !27
  %t22 = load i64, ptr %l6, !tbaa !24
  %t24 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = getelementptr ptr, ptr %t25, i64 %t22
  %t27 = load ptr, ptr %t26, !tbaa !39
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t33 = call ptr @compiler_2fparse_2ecompiler_2fparse_3aParser_2epattern(ptr %v0, ptr %v2, ptr %v0, ptr %t29, ptr %t27, i1 false)
  store ptr %t33, ptr %l25
  br label %bb6
bb6:
  %t34 = load ptr, ptr %l25, !tbaa !29
  store ptr %t34, ptr %l9, !tbaa !29
  %t35 = load ptr, ptr %l9, !tbaa !29
  %t37 = call i1 @compiler_2fparse_2evaluePattern(ptr %v0, ptr %t35)
  store i1 %t37, ptr %l27
  br label %bb7
bb7:
  %t38 = load i1, ptr %l27, !tbaa !21
  %t39 = xor i1 %t38, true
  br i1 %t39, label %bb8, label %bb9
bb8:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/parse:Parser", ptr %t41, i32 0, i32 38
  %t44 = load ptr, ptr %l9, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aPattern_26_3e_2ePush_3ccompiler_2fast_3aPattern_26_3e(ptr %v0, ptr %v0, ptr %t43, ptr %t44)
  br label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb13
bb11:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/parse:Parser", ptr %t47, i32 0, i32 38
  %t50 = load i64, ptr %l4, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aPattern_26_3e_2eTrunc_H311fd53ced078d1b110127cfa5549832(ptr %v0, ptr %t49, i64 %t50)
  br label %bb12
bb12:
  %t53 = load %"compiler/source:Span", ptr %l1
  %t54 = load ptr, ptr %l2, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t55
  %t56 = getelementptr { i64, [4 x i64] }, ptr %t55, i32 0, i32 0
  store i64 4, ptr %t56
  %t58 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t53, 0
  %t60 = insertvalue { %"compiler/source:Span", ptr } %t58, ptr %t54, 1
  %t61 = getelementptr { i64, [4 x i64] }, ptr %t55, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t60, ptr %t61
  %t62 = load { i64, [4 x i64] }, ptr %t55
  %t64 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 40, i64 8)
  store { i64, [4 x i64] } %t62, ptr %t64
  store ptr %t64, ptr %rv
  br label %ret
bb13:
  %t66 = load i64, ptr %l6, !tbaa !24
  %t69 = add i64 %t66, 1
  store i64 %t69, ptr %l6, !tbaa !24
  br label %bb2
bb14:
  %t71 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t71, ptr %l42
  %t72 = load ptr, ptr %l2, !tbaa !29
  store ptr %t72, ptr %l43, !tbaa !29
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/parse:Parser", ptr %t73, i32 0, i32 38
  %t76 = load i64, ptr %l4, !tbaa !24
  %t79 = call { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fast_3aPattern_26_3e(ptr %v0, ptr %v3, ptr %t75, i64 %t76)
  store { i64, ptr } %t79, ptr %l47
  br label %bb15
bb15:
  store { i64, [4 x i64] } zeroinitializer, ptr %t80
  %t81 = getelementptr { i64, [4 x i64] }, ptr %t80, i32 0, i32 0
  store i64 6, ptr %t81
  %t82 = load %"compiler/source:Span", ptr %l42
  %t83 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } undef, %"compiler/source:Span" %t82, 0
  %t84 = load ptr, ptr %l43, !tbaa !29
  %t85 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } %t83, ptr %t84, 1
  %t86 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t87 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } %t85, { i64, ptr } %t86, 2
  %t88 = getelementptr { i64, [4 x i64] }, ptr %t80, i32 0, i32 1
  store { %"compiler/source:Span", ptr, { i64, ptr } } %t87, ptr %t88
  %t89 = load { i64, [4 x i64] }, ptr %t80
  %t91 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 40, i64 8)
  store { i64, [4 x i64] } %t89, ptr %t91
  store ptr %t91, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eerrorDecl(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %lp5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca %"compiler/source:Span"
  %l14 = alloca i32
  %l15 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l19 = alloca i1
  %l20 = alloca ptr
  %l21 = alloca ptr
  %l22 = alloca i64
  %l25 = alloca ptr
  %l26 = alloca i32
  %l30 = alloca i1
  %l32 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l36 = alloca i1
  %l39 = alloca i32
  %l42 = alloca i64
  %l45 = alloca i32
  %l48 = alloca i64
  %l53 = alloca i64
  %l57 = alloca i64
  %l60 = alloca i64
  %l78 = alloca i64
  %l82 = alloca ptr
  %l90 = alloca %"compiler/source:Span"
  %l93 = alloca i1
  %l95 = alloca i32
  %l96 = alloca %"compiler/source:Span"
  %l97 = alloca i32
  %l98 = alloca { i64, ptr }
  %l100 = alloca { i64, ptr }
  %l102 = alloca { i64, ptr }
  %s6 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %rv = alloca { i32, ptr }
  %t212 = alloca { i64, [8 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t1)
  store i32 %t3, ptr %l14
  br label %bb1
bb1:
  %t4 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aPath_26_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t4, ptr %l15
  br label %bb2
bb2:
  %t5 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l15
  %t6 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %t6
  store ptr %t6, ptr %l3, !tbaa !29
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t11 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t8, i32 1)
  store i1 %t11, ptr %l19
  br label %bb3
bb3:
  %t12 = load i1, ptr %l19, !tbaa !21
  br i1 %t12, label %bb4, label %bb5
bb4:
  br label %bb6
bb5:
  br label %bb19
bb6:
  %t13 = load ptr, ptr %l3, !tbaa !29
  store ptr %t13, ptr %l20, !tbaa !29
  %t14 = call ptr @__olang_scope_hold(ptr %v1)
  %t15 = ptrtoint ptr %t14 to i64
  store i64 %t15, ptr %l22, !tbaa !24
  %t16 = load i1, ptr @olang_2esole_2eArray_3ccompiler_2fast_3aPath_26_3e_2e_2d1
  br i1 %t16, label %bb7, label %bb8
bb7:
  %t18 = call ptr @__olang_region_make(ptr %v1)
  %t19 = ptrtoint ptr %t18 to i64
  store i64 %t19, ptr %l22, !tbaa !24
  br label %bb8
bb8:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load i64, ptr %l22
  %t22 = inttoptr i64 %t21 to ptr
  %t24 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2epath(ptr %v0, ptr %t22, ptr %t20)
  %t25 = extractvalue { i32, ptr } %t24, 1
  %t26 = extractvalue { i32, ptr } %t24, 0
  store i32 %t26, ptr %l26
  %t27 = icmp ne i32 %t26, 0
  br i1 %t27, label %bb10, label %ok.28, !prof !99
ok.28:
  store ptr %t25, ptr %l25
  br label %bb9
bb9:
  %t29 = load ptr, ptr %l25, !tbaa !29
  store ptr %t29, ptr %l21, !tbaa !29
  br label %bb11
bb10:
  %t30 = load i32, ptr %l26, !tbaa !23
  %t31 = lshr i32 %t30, 16
  %t32 = and i32 %t30, 65535
  %t33 = icmp eq i32 %t31, 1
  %t34 = select i1 %t33, i32 1, i32 0
  %t35 = icmp eq i32 %t30, 0
  %t36 = shl i32 %t34, 16
  %t37 = or i32 %t36, %t32
  %t38 = select i1 %t35, i32 0, i32 %t37
  %t40 = insertvalue { i32, ptr } zeroinitializer, i32 %t38, 0
  store { i32, ptr } %t40, ptr %rv
  br label %ret
bb11:
  %t41 = load ptr, ptr %l20, !tbaa !29
  %t42 = load ptr, ptr %l21, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aPath_26_3e_2ePush_3ccompiler_2fast_3aPath_26_3e(ptr %v1, ptr %v1, ptr %t41, ptr %t42)
  br label %bb12
bb12:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t46 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t43, i32 75)
  store i1 %t46, ptr %l30
  br label %bb13
bb13:
  %t47 = load i1, ptr %l30, !tbaa !21
  %t48 = xor i1 %t47, true
  br i1 %t48, label %bb14, label %bb15
bb14:
  br label %bb18
bb15:
  br label %bb16
bb16:
  br label %bb17
bb17:
  br label %bb6
bb18:
  br label %bb19
bb19:
  %t50 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aCaseDecl_26_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t50, ptr %l32
  br label %bb20
bb20:
  %t51 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l32
  %t52 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t51, ptr %t52
  store ptr %t52, ptr %l4, !tbaa !29
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t57 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t54, i32 114)
  store i1 %t57, ptr %l36
  br label %bb21
bb21:
  %t58 = load i1, ptr %l36, !tbaa !21
  br i1 %t58, label %bb22, label %bb23
bb22:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t60 = load ptr, ptr %l4, !tbaa !29
  %t63 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eerrorWords(ptr %v0, ptr %v1, ptr %t59, ptr %t60)
  store i32 %t63, ptr %l39
  %t64 = icmp ne i32 %t63, 0
  br i1 %t64, label %bb25, label %ok.65, !prof !99
ok.65:
  br label %bb24
bb23:
  %t66 = load ptr, ptr %l3, !tbaa !29
  %t68 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aPath_26_3e_2eLen_3ccompiler_2fast_3aPath_26_3e(ptr %v1, ptr %t66)
  store i64 %t68, ptr %l42
  br label %bb27
bb24:
  br label %bb26
bb25:
  %t69 = load i32, ptr %l39, !tbaa !23
  %t70 = lshr i32 %t69, 16
  %t71 = and i32 %t69, 65535
  %t72 = icmp eq i32 %t70, 1
  %t73 = select i1 %t72, i32 1, i32 0
  %t74 = icmp eq i32 %t69, 0
  %t75 = shl i32 %t73, 16
  %t76 = or i32 %t75, %t71
  %t77 = select i1 %t74, i32 0, i32 %t76
  %t79 = insertvalue { i32, ptr } zeroinitializer, i32 %t77, 0
  store { i32, ptr } %t79, ptr %rv
  br label %ret
bb26:
  br label %bb34
bb27:
  %t80 = load i64, ptr %l42, !tbaa !24
  %t81 = icmp eq i64 %t80, 0
  br i1 %t81, label %bb28, label %bb29
bb28:
  store %olang.scope zeroinitializer, ptr %s6
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2efail(ptr %v0, ptr %s6, ptr %t83, { i64, ptr } { i64 40, ptr getelementptr inbounds (<{ i64, [40 x i8] }>, ptr @.d2, i32 0, i32 1) })
  store i32 %t85, ptr %l45
  %t86 = icmp ne i32 %t85, 0
  br i1 %t86, label %bb31, label %ok.87, !prof !99
ok.87:
  br label %bb30
bb29:
  br label %bb33
bb30:
  br label %bb32
bb31:
  %t88 = load i32, ptr %l45, !tbaa !23
  %t89 = lshr i32 %t88, 16
  %t90 = and i32 %t88, 65535
  %t91 = icmp eq i32 %t89, 1
  %t92 = select i1 %t91, i32 1, i32 0
  %t93 = icmp eq i32 %t88, 0
  %t94 = shl i32 %t92, 16
  %t95 = or i32 %t94, %t90
  %t96 = select i1 %t93, i32 0, i32 %t95
  call void @__olang_scope_close(ptr %s6)
  %t98 = insertvalue { i32, ptr } zeroinitializer, i32 %t96, 0
  store { i32, ptr } %t98, ptr %rv
  br label %ret
bb32:
  call void @__olang_scope_close(ptr %s6)
  br label %bb33
bb33:
  br label %bb34
bb34:
  %t99 = load ptr, ptr %l4, !tbaa !29
  %t101 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aCaseDecl_26_3e_2eLen__H880e577cb0df1a24f608b8ef0d16c17a(ptr %v1, ptr %t99)
  store i64 %t101, ptr %l48
  br label %bb35
bb35:
  %t102 = load i64, ptr %l48, !tbaa !24
  %t103 = icmp sge i64 %t102, 0
  br i1 %t103, label %bb36, label %bb37
bb36:
  %t105 = load i64, ptr %l48, !tbaa !24
  %t106 = icmp sle i64 %t105, 2305843009213693951
  br i1 %t106, label %bb38, label %bb39
bb37:
  call void @__olang_check_failed(ptr @olang_loc_789713e4eee702da_477f9e47229ca02e)
  unreachable
bb38:
  %t108 = load i64, ptr %l48, !tbaa !24
  %t109 = mul i64 %t108, 4
  %t110 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t109)
  %t111 = insertvalue { i64, ptr } undef, i64 %t108, 0
  %t112 = insertvalue { i64, ptr } %t111, ptr %t110, 1
  %t113 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t113, ptr %lp5
  %t115 = load ptr, ptr %lp5
  store { i64, ptr } %t112, ptr %t115, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t116 = load ptr, ptr %l4, !tbaa !29
  %t118 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aCaseDecl_26_3e_2eLen__H880e577cb0df1a24f608b8ef0d16c17a(ptr %v1, ptr %t116)
  store i64 %t118, ptr %l53
  br label %bb40
bb39:
  call void @__olang_check_failed(ptr @olang_loc_789713e4eee702da_477f9e47229ca02e)
  unreachable
bb40:
  %t119 = load i64, ptr %l53, !tbaa !24
  store i64 %t119, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t120 = load i64, ptr %l7, !tbaa !24
  %t121 = load i64, ptr %l6, !tbaa !24
  %t124 = icmp sgt i64 %t120, %t121
  br i1 %t124, label %bb41, label %bb42
bb41:
  %t126 = load i64, ptr %l8, !tbaa !24
  %t128 = icmp sgt i64 %t126, 0
  br i1 %t128, label %bb43, label %bb44
bb42:
  store i64 0, ptr %l57, !tbaa !24
  br label %bb46
bb43:
  %t130 = load i64, ptr %l7, !tbaa !24
  %t131 = load i64, ptr %l6, !tbaa !24
  %t134 = sub i64 %t130, %t131
  %t135 = load i64, ptr %l8, !tbaa !24
  %t138 = add i64 %t134, %t135
  %t140 = sub i64 %t138, 1
  %t141 = load i64, ptr %l8, !tbaa !24
  %t144 = sdiv i64 %t140, %t141
  store i64 %t144, ptr %l60, !tbaa !24
  br label %bb45
bb44:
  store i64 0, ptr %l60, !tbaa !24
  br label %bb45
bb45:
  %t146 = load i64, ptr %l60, !tbaa !24
  store i64 %t146, ptr %l57, !tbaa !24
  br label %bb46
bb46:
  %t147 = load i64, ptr %l57, !tbaa !24
  store i64 %t147, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb47
bb47:
  store %olang.scope zeroinitializer, ptr %s8
  %t148 = load i64, ptr %l10, !tbaa !24
  %t149 = load i64, ptr %l9, !tbaa !24
  %t152 = icmp slt i64 %t148, %t149
  %t154 = xor i1 %t152, true
  br i1 %t154, label %bb48, label %bb49
bb48:
  call void @__olang_scope_close(ptr %s8)
  br label %bb53
bb49:
  br label %bb50
bb50:
  %t156 = load i64, ptr %l6, !tbaa !24
  %t157 = load i64, ptr %l10, !tbaa !24
  %t158 = load i64, ptr %l8, !tbaa !24
  %t161 = mul i64 %t157, %t158
  %t164 = add i64 %t156, %t161
  store i64 %t164, ptr %l11, !tbaa !24
  %t166 = load i64, ptr %l11, !tbaa !24
  store i64 %t166, ptr %l78, !tbaa !24
  %t167 = load ptr, ptr %l4, !tbaa !29
  %t169 = load i64, ptr %l11, !tbaa !24
  %t172 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aCaseDecl_26_3e_2eAt_3ccompiler_2fast_3aCaseDecl_26_3e(ptr %v1, ptr %s8, ptr %t167, i64 %t169)
  store ptr %t172, ptr %l82
  br label %bb51
bb51:
  %t173 = load ptr, ptr %l82, !tbaa !29
  %t175 = getelementptr %"compiler/ast:CaseDecl", ptr %t173, i32 0, i32 1
  %t176 = load i32, ptr %t175, !tbaa !23
  %t178 = load ptr, ptr %lp5
  %t179 = load i64, ptr %l78, !tbaa !24
  %t180 = getelementptr { i64, ptr }, ptr %t178, i32 0, i32 1
  %t181 = load ptr, ptr %t180, !tbaa !27
  %t182 = getelementptr i32, ptr %t181, i64 %t179
  store i32 %t176, ptr %t182, !tbaa !33
  call void @__olang_scope_close(ptr %s8)
  br label %bb52
bb52:
  %t183 = load i64, ptr %l10, !tbaa !24
  %t186 = add i64 %t183, 1
  store i64 %t186, ptr %l10, !tbaa !24
  br label %bb47
bb53:
  %t188 = load ptr, ptr %l0, !tbaa !29
  %t192 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t188, i32 %a1)
  store %"compiler/source:Span" %t192, ptr %l90
  br label %bb54
bb54:
  %t193 = load %"compiler/source:Span", ptr %l90
  store %"compiler/source:Span" %t193, ptr %l12
  %t194 = load ptr, ptr %l0, !tbaa !29
  %t197 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t194, i32 8)
  store i1 %t197, ptr %l93
  br label %bb55
bb55:
  %t198 = load i1, ptr %l93, !tbaa !21
  br i1 %t198, label %bb56, label %bb57
bb56:
  %t199 = load ptr, ptr %l0, !tbaa !29
  %t201 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t199)
  store i32 %t201, ptr %l95
  br label %bb58
bb57:
  br label %bb59
bb58:
  br label %bb59
bb59:
  %t202 = load %"compiler/source:Span", ptr %l12
  store %"compiler/source:Span" %t202, ptr %l96
  store i32 %a2, ptr %l97, !tbaa !23
  %t204 = load ptr, ptr %lp5
  %t205 = load { i64, ptr }, ptr %t204, !tbaa !27
  store { i64, ptr } %t205, ptr %l98, !tbaa !27
  %t206 = load ptr, ptr %l3, !tbaa !29
  %t208 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aPath_26_3e_2eToArray_3ccompiler_2fast_3aPath_26_3e(ptr %v1, ptr %v1, ptr %t206)
  store { i64, ptr } %t208, ptr %l100
  br label %bb60
bb60:
  %t209 = load ptr, ptr %l4, !tbaa !29
  %t211 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aCaseDecl_26_3e_2eToAr_H44f8de0685d71649bf169c234c7a8f4c(ptr %v1, ptr %v1, ptr %t209)
  store { i64, ptr } %t211, ptr %l102
  br label %bb61
bb61:
  store { i64, [8 x i64] } zeroinitializer, ptr %t212
  %t213 = getelementptr { i64, [8 x i64] }, ptr %t212, i32 0, i32 0
  store i64 6, ptr %t213
  %t214 = load %"compiler/source:Span", ptr %l96
  %t215 = insertvalue { %"compiler/source:Span", i32, { i64, ptr }, { i64, ptr }, { i64, ptr } } undef, %"compiler/source:Span" %t214, 0
  %t216 = load i32, ptr %l97, !tbaa !23
  %t217 = insertvalue { %"compiler/source:Span", i32, { i64, ptr }, { i64, ptr }, { i64, ptr } } %t215, i32 %t216, 1
  %t218 = load { i64, ptr }, ptr %l98, !tbaa !27
  %t219 = insertvalue { %"compiler/source:Span", i32, { i64, ptr }, { i64, ptr }, { i64, ptr } } %t217, { i64, ptr } %t218, 2
  %t220 = load { i64, ptr }, ptr %l100, !tbaa !27
  %t221 = insertvalue { %"compiler/source:Span", i32, { i64, ptr }, { i64, ptr }, { i64, ptr } } %t219, { i64, ptr } %t220, 3
  %t222 = load { i64, ptr }, ptr %l102, !tbaa !27
  %t223 = insertvalue { %"compiler/source:Span", i32, { i64, ptr }, { i64, ptr }, { i64, ptr } } %t221, { i64, ptr } %t222, 4
  %t224 = getelementptr { i64, [8 x i64] }, ptr %t212, i32 0, i32 1
  store { %"compiler/source:Span", i32, { i64, ptr }, { i64, ptr }, { i64, ptr } } %t223, ptr %t224
  %t225 = load { i64, [8 x i64] }, ptr %t212
  %t227 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 72, i64 8)
  store { i64, [8 x i64] } %t225, ptr %t227
  %t229 = insertvalue { i32, ptr } zeroinitializer, ptr %t227, 1
  store { i32, ptr } %t229, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eerrorSet(ptr %v0, ptr %v1, ptr %a0, i1 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l5 = alloca i1
  %l9 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l17 = alloca { i64, ptr }
  %l21 = alloca %"compiler/ast:Sig"
  %l23 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l27 = alloca i1
  %l28 = alloca ptr
  %l29 = alloca ptr
  %l30 = alloca i64
  %l33 = alloca ptr
  %l34 = alloca i32
  %l37 = alloca i1
  %l40 = alloca i1
  %l44 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l48 = alloca i64
  %l51 = alloca { i64, ptr }
  %l55 = alloca %"compiler/ast:Sig"
  %rv = alloca { i32, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t4 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t1, i32 77)
  store i1 %t4, ptr %l5
  br label %bb1
bb1:
  %t5 = load i1, ptr %l5, !tbaa !21
  %t6 = xor i1 %t5, true
  br i1 %t6, label %bb2, label %bb3
bb2:
  %t8 = icmp sge i64 0, 0
  br i1 %t8, label %bb4, label %bb5
bb3:
  br label %bb23
bb4:
  %t10 = icmp sle i64 0, 1152921504606846975
  br i1 %t10, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_1981dec301b76378_38f305e42bd9bf3c)
  unreachable
bb6:
  %t12 = mul i64 0, 8
  %t13 = insertvalue { i64, ptr } undef, i64 0, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t14, ptr %l9, !tbaa !27
  %t15 = icmp sge i64 0, 0
  br i1 %t15, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_1981dec301b76378_38f305e42bd9bf3c)
  unreachable
bb8:
  %t17 = icmp sle i64 0, 1152921504606846975
  br i1 %t17, label %bb10, label %bb11
bb9:
  call void @__olang_check_failed(ptr @olang_loc_1981dec301b76378_38f305e42bd9bf3c)
  unreachable
bb10:
  %t19 = mul i64 0, 8
  %t20 = insertvalue { i64, ptr } undef, i64 0, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t21, ptr %l12, !tbaa !27
  %t22 = call ptr @__olang_scope_hold(ptr %v1)
  %t23 = ptrtoint ptr %t22 to i64
  store i64 %t23, ptr %l13, !tbaa !24
  %t24 = load i1, ptr @olang_2esole_2ecompiler_2fast_3aSig_2e3
  br i1 %t24, label %bb12, label %bb13
bb11:
  call void @__olang_check_failed(ptr @olang_loc_1981dec301b76378_38f305e42bd9bf3c)
  unreachable
bb12:
  %t26 = call ptr @__olang_region_make(ptr %v1)
  %t27 = ptrtoint ptr %t26 to i64
  store i64 %t27, ptr %l13, !tbaa !24
  br label %bb13
bb13:
  %t28 = icmp sge i64 0, 0
  br i1 %t28, label %bb14, label %bb15
bb14:
  %t30 = icmp sle i64 0, 1152921504606846975
  br i1 %t30, label %bb16, label %bb17
bb15:
  call void @__olang_check_failed(ptr @olang_loc_1981dec301b76378_38f305e42bd9bf3c)
  unreachable
bb16:
  %t32 = mul i64 0, 8
  %t33 = load i64, ptr %l13
  %t34 = inttoptr i64 %t33 to ptr
  %t35 = insertvalue { i64, ptr } undef, i64 0, 0
  %t36 = insertvalue { i64, ptr } %t35, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t36, ptr %l17, !tbaa !27
  %t37 = icmp sge i64 0, 0
  br i1 %t37, label %bb18, label %bb19
bb17:
  call void @__olang_check_failed(ptr @olang_loc_1981dec301b76378_38f305e42bd9bf3c)
  unreachable
bb18:
  %t39 = icmp sle i64 0, 1152921504606846975
  br i1 %t39, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @olang_loc_1981dec301b76378_38f305e42bd9bf3c)
  unreachable
bb20:
  %t41 = mul i64 0, 8
  %t42 = insertvalue { i64, ptr } undef, i64 0, 0
  %t43 = insertvalue { i64, ptr } %t42, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t44 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t45 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t46 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t48 = call %"compiler/ast:Sig" @compiler_2fast_3aSig_2ector(ptr %v1, ptr %v1, ptr %v1, ptr %v1, ptr %v1, { i64, ptr } %t44, { i64, ptr } %t45, i1 false, { i64, ptr } %t46, i1 false, i1 false, i1 false, { i64, ptr } %t43, i1 false)
  store %"compiler/ast:Sig" %t48, ptr %l21
  br label %bb22
bb21:
  call void @__olang_check_failed(ptr @olang_loc_1981dec301b76378_38f305e42bd9bf3c)
  unreachable
bb22:
  %t49 = load %"compiler/ast:Sig", ptr %l21
  %t50 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 88, i64 8)
  store %"compiler/ast:Sig" %t49, ptr %t50
  %t52 = insertvalue { i32, ptr } zeroinitializer, ptr %t50, 1
  store { i32, ptr } %t52, ptr %rv
  br label %ret
bb23:
  %t53 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aPath_26_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t53, ptr %l23
  br label %bb24
bb24:
  %t54 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l23
  %t55 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t54, ptr %t55
  store ptr %t55, ptr %l2, !tbaa !29
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t60 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t57, i32 1)
  store i1 %t60, ptr %l27
  br label %bb25
bb25:
  %t61 = load i1, ptr %l27, !tbaa !21
  br i1 %t61, label %bb26, label %bb27
bb26:
  br label %bb28
bb27:
  br label %bb44
bb28:
  %t62 = load ptr, ptr %l2, !tbaa !29
  store ptr %t62, ptr %l28, !tbaa !29
  %t63 = call ptr @__olang_scope_hold(ptr %v1)
  %t64 = ptrtoint ptr %t63 to i64
  store i64 %t64, ptr %l30, !tbaa !24
  %t65 = load i1, ptr @olang_2esole_2eArray_3ccompiler_2fast_3aPath_26_3e_2e_2d1
  br i1 %t65, label %bb29, label %bb30
bb29:
  %t67 = call ptr @__olang_region_make(ptr %v1)
  %t68 = ptrtoint ptr %t67 to i64
  store i64 %t68, ptr %l30, !tbaa !24
  br label %bb30
bb30:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t70 = load i64, ptr %l30
  %t71 = inttoptr i64 %t70 to ptr
  %t73 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2epath(ptr %v0, ptr %t71, ptr %t69)
  %t74 = extractvalue { i32, ptr } %t73, 1
  %t75 = extractvalue { i32, ptr } %t73, 0
  store i32 %t75, ptr %l34
  %t76 = icmp ne i32 %t75, 0
  br i1 %t76, label %bb32, label %ok.77, !prof !99
ok.77:
  store ptr %t74, ptr %l33
  br label %bb31
bb31:
  %t78 = load ptr, ptr %l33, !tbaa !29
  store ptr %t78, ptr %l29, !tbaa !29
  br label %bb33
bb32:
  %t79 = load i32, ptr %l34, !tbaa !23
  %t80 = lshr i32 %t79, 16
  %t81 = and i32 %t79, 65535
  %t82 = icmp eq i32 %t80, 1
  %t83 = select i1 %t82, i32 1, i32 0
  %t84 = icmp eq i32 %t79, 0
  %t85 = shl i32 %t83, 16
  %t86 = or i32 %t85, %t81
  %t87 = select i1 %t84, i32 0, i32 %t86
  %t89 = insertvalue { i32, ptr } zeroinitializer, i32 %t87, 0
  store { i32, ptr } %t89, ptr %rv
  br label %ret
bb33:
  %t90 = load ptr, ptr %l28, !tbaa !29
  %t91 = load ptr, ptr %l29, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aPath_26_3e_2ePush_3ccompiler_2fast_3aPath_26_3e(ptr %v1, ptr %v1, ptr %t90, ptr %t91)
  br label %bb34
bb34:
  br i1 %a1, label %bb35, label %bb36
bb35:
  store i1 true, ptr %l37, !tbaa !21
  br label %bb38
bb36:
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t97 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t94, i32 75)
  store i1 %t97, ptr %l40
  br label %bb37
bb37:
  %t98 = load i1, ptr %l40, !tbaa !21
  %t99 = xor i1 %t98, true
  store i1 %t99, ptr %l37, !tbaa !21
  br label %bb38
bb38:
  %t101 = load i1, ptr %l37, !tbaa !21
  br i1 %t101, label %bb39, label %bb40
bb39:
  br label %bb43
bb40:
  br label %bb41
bb41:
  br label %bb42
bb42:
  br label %bb28
bb43:
  br label %bb44
bb44:
  %t102 = icmp sge i64 0, 0
  br i1 %t102, label %bb45, label %bb46
bb45:
  %t104 = icmp sle i64 0, 1152921504606846975
  br i1 %t104, label %bb47, label %bb48
bb46:
  call void @__olang_check_failed(ptr @olang_loc_cd306f178609e3e5_44435844e9b3da89)
  unreachable
bb47:
  %t106 = mul i64 0, 8
  %t107 = insertvalue { i64, ptr } undef, i64 0, 0
  %t108 = insertvalue { i64, ptr } %t107, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t108, ptr %l44, !tbaa !27
  %t109 = icmp sge i64 0, 0
  br i1 %t109, label %bb49, label %bb50
bb48:
  call void @__olang_check_failed(ptr @olang_loc_cd306f178609e3e5_44435844e9b3da89)
  unreachable
bb49:
  %t111 = icmp sle i64 0, 1152921504606846975
  br i1 %t111, label %bb51, label %bb52
bb50:
  call void @__olang_check_failed(ptr @olang_loc_cd306f178609e3e5_44435844e9b3da89)
  unreachable
bb51:
  %t113 = mul i64 0, 8
  %t114 = insertvalue { i64, ptr } undef, i64 0, 0
  %t115 = insertvalue { i64, ptr } %t114, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t115, ptr %l47, !tbaa !27
  %t116 = call ptr @__olang_scope_hold(ptr %v1)
  %t117 = ptrtoint ptr %t116 to i64
  store i64 %t117, ptr %l48, !tbaa !24
  %t118 = load i1, ptr @olang_2esole_2ecompiler_2fast_3aSig_2e3
  br i1 %t118, label %bb53, label %bb54
bb52:
  call void @__olang_check_failed(ptr @olang_loc_cd306f178609e3e5_44435844e9b3da89)
  unreachable
bb53:
  %t120 = call ptr @__olang_region_make(ptr %v1)
  %t121 = ptrtoint ptr %t120 to i64
  store i64 %t121, ptr %l48, !tbaa !24
  br label %bb54
bb54:
  %t122 = load ptr, ptr %l2, !tbaa !29
  %t123 = load i64, ptr %l48
  %t124 = inttoptr i64 %t123 to ptr
  %t126 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aPath_26_3e_2eToArray_3ccompiler_2fast_3aPath_26_3e(ptr %v1, ptr %t124, ptr %t122)
  store { i64, ptr } %t126, ptr %l51
  br label %bb55
bb55:
  %t127 = icmp sge i64 0, 0
  br i1 %t127, label %bb56, label %bb57
bb56:
  %t129 = icmp sle i64 0, 1152921504606846975
  br i1 %t129, label %bb58, label %bb59
bb57:
  call void @__olang_check_failed(ptr @olang_loc_cd306f178609e3e5_44435844e9b3da89)
  unreachable
bb58:
  %t131 = mul i64 0, 8
  %t132 = insertvalue { i64, ptr } undef, i64 0, 0
  %t133 = insertvalue { i64, ptr } %t132, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t134 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t135 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t136 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t138 = call %"compiler/ast:Sig" @compiler_2fast_3aSig_2ector(ptr %v1, ptr %v1, ptr %v1, ptr %v1, ptr %v1, { i64, ptr } %t134, { i64, ptr } %t135, i1 true, { i64, ptr } %t136, i1 false, i1 false, i1 false, { i64, ptr } %t133, i1 false)
  store %"compiler/ast:Sig" %t138, ptr %l55
  br label %bb60
bb59:
  call void @__olang_check_failed(ptr @olang_loc_cd306f178609e3e5_44435844e9b3da89)
  unreachable
bb60:
  %t139 = load %"compiler/ast:Sig", ptr %l55
  %t140 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 88, i64 8)
  store %"compiler/ast:Sig" %t139, ptr %t140
  %t142 = insertvalue { i32, ptr } zeroinitializer, ptr %t140, 1
  store { i32, ptr } %t142, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eerrsArg(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca i32
  %l8 = alloca i32
  %l9 = alloca i32
  %l11 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca i64
  %l18 = alloca ptr
  %l19 = alloca i32
  %l23 = alloca i1
  %l27 = alloca %"compiler/source:Span"
  %l29 = alloca { i64, ptr }
  %rv = alloca { i32, ptr }
  %t74 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ehere(ptr %v0, ptr %t1)
  store i32 %t3, ptr %l4
  br label %bb1
bb1:
  %t4 = load i32, ptr %l4, !tbaa !23
  store i32 %t4, ptr %l1, !tbaa !23
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t8 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %t5, i32 77)
  %t9 = extractvalue { i32, i32 } %t8, 1
  %t10 = extractvalue { i32, i32 } %t8, 0
  store i32 %t10, ptr %l9
  %t11 = icmp ne i32 %t10, 0
  br i1 %t11, label %bb3, label %ok.12, !prof !99
ok.12:
  store i32 %t9, ptr %l8
  br label %bb2
bb2:
  %t13 = load i32, ptr %l8, !tbaa !23
  store i32 %t13, ptr %l5, !tbaa !23
  br label %bb4
bb3:
  %t14 = load i32, ptr %l9, !tbaa !23
  %t15 = lshr i32 %t14, 16
  %t16 = and i32 %t14, 65535
  %t17 = icmp eq i32 %t15, 1
  %t18 = select i1 %t17, i32 1, i32 0
  %t19 = icmp eq i32 %t14, 0
  %t20 = shl i32 %t18, 16
  %t21 = or i32 %t20, %t16
  %t22 = select i1 %t19, i32 0, i32 %t21
  %t24 = insertvalue { i32, ptr } zeroinitializer, i32 %t22, 0
  store { i32, ptr } %t24, ptr %rv
  br label %ret
bb4:
  %t25 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aPath_26_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t25, ptr %l11
  br label %bb5
bb5:
  %t26 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l11
  %t27 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t26, ptr %t27
  store ptr %t27, ptr %l2, !tbaa !29
  br label %bb6
bb6:
  %t29 = load ptr, ptr %l2, !tbaa !29
  store ptr %t29, ptr %l13, !tbaa !29
  %t30 = call ptr @__olang_scope_hold(ptr %v1)
  %t31 = ptrtoint ptr %t30 to i64
  store i64 %t31, ptr %l15, !tbaa !24
  %t32 = load i1, ptr @olang_2esole_2eArray_3ccompiler_2fast_3aPath_26_3e_2e_2d1
  br i1 %t32, label %bb7, label %bb8
bb7:
  %t34 = call ptr @__olang_region_make(ptr %v1)
  %t35 = ptrtoint ptr %t34 to i64
  store i64 %t35, ptr %l15, !tbaa !24
  br label %bb8
bb8:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t37 = load i64, ptr %l15
  %t38 = inttoptr i64 %t37 to ptr
  %t40 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2epath(ptr %v0, ptr %t38, ptr %t36)
  %t41 = extractvalue { i32, ptr } %t40, 1
  %t42 = extractvalue { i32, ptr } %t40, 0
  store i32 %t42, ptr %l19
  %t43 = icmp ne i32 %t42, 0
  br i1 %t43, label %bb10, label %ok.44, !prof !99
ok.44:
  store ptr %t41, ptr %l18
  br label %bb9
bb9:
  %t45 = load ptr, ptr %l18, !tbaa !29
  store ptr %t45, ptr %l14, !tbaa !29
  br label %bb11
bb10:
  %t46 = load i32, ptr %l19, !tbaa !23
  %t47 = lshr i32 %t46, 16
  %t48 = and i32 %t46, 65535
  %t49 = icmp eq i32 %t47, 1
  %t50 = select i1 %t49, i32 1, i32 0
  %t51 = icmp eq i32 %t46, 0
  %t52 = shl i32 %t50, 16
  %t53 = or i32 %t52, %t48
  %t54 = select i1 %t51, i32 0, i32 %t53
  %t56 = insertvalue { i32, ptr } zeroinitializer, i32 %t54, 0
  store { i32, ptr } %t56, ptr %rv
  br label %ret
bb11:
  %t57 = load ptr, ptr %l13, !tbaa !29
  %t58 = load ptr, ptr %l14, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aPath_26_3e_2ePush_3ccompiler_2fast_3aPath_26_3e(ptr %v1, ptr %v1, ptr %t57, ptr %t58)
  br label %bb12
bb12:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t62 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t59, i32 75)
  store i1 %t62, ptr %l23
  br label %bb13
bb13:
  %t63 = load i1, ptr %l23, !tbaa !21
  %t64 = xor i1 %t63, true
  br i1 %t64, label %bb14, label %bb15
bb14:
  br label %bb18
bb15:
  br label %bb16
bb16:
  br label %bb17
bb17:
  br label %bb6
bb18:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t67 = load i32, ptr %l1, !tbaa !23
  %t70 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t66, i32 %t67)
  store %"compiler/source:Span" %t70, ptr %l27
  br label %bb19
bb19:
  %t71 = load ptr, ptr %l2, !tbaa !29
  %t73 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aPath_26_3e_2eToArray_3ccompiler_2fast_3aPath_26_3e(ptr %v1, ptr %v1, ptr %t71)
  store { i64, ptr } %t73, ptr %l29
  br label %bb20
bb20:
  store { i64, [5 x i64] } zeroinitializer, ptr %t74
  %t75 = getelementptr { i64, [5 x i64] }, ptr %t74, i32 0, i32 0
  store i64 6, ptr %t75
  %t76 = load %"compiler/source:Span", ptr %l27
  %t77 = insertvalue { %"compiler/source:Span", { i64, ptr } } undef, %"compiler/source:Span" %t76, 0
  %t78 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t79 = insertvalue { %"compiler/source:Span", { i64, ptr } } %t77, { i64, ptr } %t78, 1
  %t80 = getelementptr { i64, [5 x i64] }, ptr %t74, i32 0, i32 1
  store { %"compiler/source:Span", { i64, ptr } } %t79, ptr %t80
  %t81 = load { i64, [5 x i64] }, ptr %t74
  %t83 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 48, i64 8)
  store { i64, [5 x i64] } %t81, ptr %t83
  %t85 = insertvalue { i32, ptr } zeroinitializer, ptr %t83, 1
  store { i32, ptr } %t85, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexternFn(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i32
  %l10 = alloca i32
  %l12 = alloca i32
  %l13 = alloca i32
  %l16 = alloca ptr
  %l18 = alloca ptr
  %l19 = alloca i32
  %l25 = alloca %"compiler/source:Span"
  %l26 = alloca i32
  %l27 = alloca ptr
  %l30 = alloca { i64, ptr }
  %l34 = alloca %"compiler/ast:Func"
  %rv = alloca { i32, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t4 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %t1, i32 37)
  %t5 = extractvalue { i32, i32 } %t4, 1
  %t6 = extractvalue { i32, i32 } %t4, 0
  store i32 %t6, ptr %l8
  %t7 = icmp ne i32 %t6, 0
  br i1 %t7, label %bb2, label %ok.8, !prof !99
ok.8:
  store i32 %t5, ptr %l7
  br label %bb1
bb1:
  %t9 = load i32, ptr %l7, !tbaa !23
  store i32 %t9, ptr %l4, !tbaa !23
  br label %bb3
bb2:
  %t10 = load i32, ptr %l8, !tbaa !23
  %t11 = lshr i32 %t10, 16
  %t12 = and i32 %t10, 65535
  %t13 = icmp eq i32 %t11, 1
  %t14 = select i1 %t13, i32 1, i32 0
  %t15 = icmp eq i32 %t10, 0
  %t16 = shl i32 %t14, 16
  %t17 = or i32 %t16, %t12
  %t18 = select i1 %t15, i32 0, i32 %t17
  %t20 = insertvalue { i32, ptr } zeroinitializer, i32 %t18, 0
  store { i32, ptr } %t20, ptr %rv
  br label %ret
bb3:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ename(ptr %v0, ptr %t21)
  %t24 = extractvalue { i32, i32 } %t23, 1
  %t25 = extractvalue { i32, i32 } %t23, 0
  store i32 %t25, ptr %l13
  %t26 = icmp ne i32 %t25, 0
  br i1 %t26, label %bb5, label %ok.27, !prof !99
ok.27:
  store i32 %t24, ptr %l12
  br label %bb4
bb4:
  %t28 = load i32, ptr %l12, !tbaa !23
  store i32 %t28, ptr %l10, !tbaa !23
  br label %bb6
bb5:
  %t29 = load i32, ptr %l13, !tbaa !23
  %t30 = lshr i32 %t29, 16
  %t31 = and i32 %t29, 65535
  %t32 = icmp eq i32 %t30, 1
  %t33 = select i1 %t32, i32 1, i32 0
  %t34 = icmp eq i32 %t29, 0
  %t35 = shl i32 %t33, 16
  %t36 = or i32 %t35, %t31
  %t37 = select i1 %t34, i32 0, i32 %t36
  %t39 = insertvalue { i32, ptr } zeroinitializer, i32 %t37, 0
  store { i32, ptr } %t39, ptr %rv
  br label %ret
bb6:
  %t40 = load i32, ptr %l10, !tbaa !23
  store i32 %t40, ptr %l2, !tbaa !23
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/parse:Parser", ptr %t41, i32 0, i32 58
  store i1 true, ptr %t43, !tbaa !21
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2esig(ptr %v0, ptr %v1, ptr %t44, i1 false, i1 false, i1 false, i1 false, i1 false)
  %t47 = extractvalue { i32, ptr } %t46, 1
  %t48 = extractvalue { i32, ptr } %t46, 0
  store i32 %t48, ptr %l19
  %t49 = icmp ne i32 %t48, 0
  br i1 %t49, label %bb8, label %ok.50, !prof !99
ok.50:
  store ptr %t47, ptr %l18
  br label %bb7
bb7:
  %t51 = load ptr, ptr %l18, !tbaa !29
  store ptr %t51, ptr %l16, !tbaa !29
  br label %bb10
bb8:
  br label %bb9
bb9:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/parse:Parser", ptr %t52, i32 0, i32 58
  store i1 false, ptr %t54, !tbaa !21
  %t56 = insertvalue { i32, ptr } zeroinitializer, i32 65536, 0
  store { i32, ptr } %t56, ptr %rv
  br label %ret
bb10:
  %t57 = load ptr, ptr %l16, !tbaa !29
  store ptr %t57, ptr %l3, !tbaa !29
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/parse:Parser", ptr %t58, i32 0, i32 58
  store i1 false, ptr %t60, !tbaa !21
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t65 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t61, i32 %a1)
  store %"compiler/source:Span" %t65, ptr %l25
  br label %bb11
bb11:
  %t66 = load i32, ptr %l2, !tbaa !23
  store i32 %t66, ptr %l26, !tbaa !23
  %t67 = load ptr, ptr %l3, !tbaa !29
  store ptr %t67, ptr %l27, !tbaa !29
  %t68 = icmp sge i64 0, 0
  br i1 %t68, label %bb12, label %bb13
bb12:
  %t70 = icmp sle i64 0, 1152921504606846975
  br i1 %t70, label %bb14, label %bb15
bb13:
  call void @__olang_check_failed(ptr @olang_loc_30a3a318854048f4_b503dd06e25e7b98)
  unreachable
bb14:
  %t72 = mul i64 0, 8
  %t73 = insertvalue { i64, ptr } undef, i64 0, 0
  %t74 = insertvalue { i64, ptr } %t73, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t74, ptr %l30, !tbaa !27
  %t75 = icmp sge i64 0, 0
  br i1 %t75, label %bb16, label %bb17
bb15:
  call void @__olang_check_failed(ptr @olang_loc_30a3a318854048f4_b503dd06e25e7b98)
  unreachable
bb16:
  %t77 = icmp sle i64 0, 1152921504606846975
  br i1 %t77, label %bb18, label %bb19
bb17:
  call void @__olang_check_failed(ptr @olang_loc_30a3a318854048f4_b503dd06e25e7b98)
  unreachable
bb18:
  %t79 = mul i64 0, 8
  %t80 = insertvalue { i64, ptr } undef, i64 0, 0
  %t81 = insertvalue { i64, ptr } %t80, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t82 = load %"compiler/source:Span", ptr %l25
  %t83 = load i32, ptr %l26, !tbaa !23
  %t84 = load ptr, ptr %l27, !tbaa !29
  %t85 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t87 = call %"compiler/ast:Func" @compiler_2fast_3aFunc_2ector(ptr %v1, ptr %v1, ptr %v1, ptr %v1, ptr %v1, ptr %v1, %"compiler/source:Span" %t82, ptr null, i32 %t83, ptr %t84, { i64, ptr } %t85, { i64, ptr } %t81, i1 false, i1 false, ptr null, i32 0)
  store %"compiler/ast:Func" %t87, ptr %l34
  br label %bb20
bb19:
  call void @__olang_check_failed(ptr @olang_loc_30a3a318854048f4_b503dd06e25e7b98)
  unreachable
bb20:
  %t88 = load %"compiler/ast:Func", ptr %l34
  %t89 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 88, i64 8)
  store %"compiler/ast:Func" %t88, ptr %t89
  %t91 = insertvalue { i32, ptr } zeroinitializer, ptr %t89, 1
  store { i32, ptr } %t91, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2efieldDecl(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca %"compiler/token:Token"
  %l5 = alloca i32
  %l7 = alloca %"compiler/token:Token"
  %l9 = alloca i32
  %l11 = alloca ptr
  %l14 = alloca { i64, ptr }
  %l15 = alloca i32
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l18 = alloca i32
  %l19 = alloca ptr
  %l20 = alloca i32
  %l23 = alloca %"compiler/source:Span"
  %l24 = alloca ptr
  %l25 = alloca ptr
  %l26 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca { i32, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ehere(ptr %v0, ptr %t1)
  store i32 %t3, ptr %l5
  br label %bb1
bb1:
  %t4 = load i32, ptr %l5, !tbaa !23
  store i32 %t4, ptr %l1, !tbaa !23
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2etk(ptr %v0, ptr %t5)
  store %"compiler/token:Token" %t7, ptr %l7
  br label %bb2
bb2:
  %t8 = load %"compiler/token:Token", ptr %l7
  store %"compiler/token:Token" %t8, ptr %l2
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t9)
  store i32 %t11, ptr %l9
  br label %bb3
bb3:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/parse:Parser", ptr %t12, i32 0, i32 2
  %t15 = load ptr, ptr %t14, !tbaa !29
  store ptr %t15, ptr %l11, !tbaa !29
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load %"compiler/token:Token", ptr %l2
  %t20 = call { i64, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etext(ptr %v0, ptr %v0, ptr %t16, %"compiler/token:Token" %t17)
  store { i64, ptr } %t20, ptr %l14
  br label %bb4
bb4:
  %t21 = load ptr, ptr %l11, !tbaa !29
  %t22 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t23 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v0, ptr %t21, { i64, ptr } %t22)
  store i32 %t23, ptr %l15
  br label %bb5
bb5:
  %t24 = load i32, ptr %l15, !tbaa !23
  %t25 = load ptr, ptr %l0, !tbaa !29
  store ptr %t25, ptr %l17, !tbaa !29
  %t26 = load i32, ptr %l1, !tbaa !23
  store i32 %t26, ptr %l18, !tbaa !23
  %t27 = load ptr, ptr %l0, !tbaa !29
  store ptr %t27, ptr %l19, !tbaa !29
  store i32 %t24, ptr %l20, !tbaa !23
  %t29 = getelementptr %"compiler/token:Token", ptr %l2, i32 0, i32 2
  %t30 = load i32, ptr %t29, !tbaa !23
  %t31 = getelementptr %"compiler/token:Token", ptr %l2, i32 0, i32 3
  %t32 = load i32, ptr %t31, !tbaa !23
  %t35 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 %t30, i32 %t32)
  store %"compiler/source:Span" %t35, ptr %l23
  br label %bb6
bb6:
  %t36 = load ptr, ptr %l19, !tbaa !29
  %t37 = load i32, ptr %l20, !tbaa !23
  %t38 = load %"compiler/source:Span", ptr %l23
  %t39 = call ptr @compiler_2fparse_2ecompiler_2fparse_3aParser_2eone(ptr %v0, ptr %v1, ptr %t36, i32 %t37, %"compiler/source:Span" %t38)
  store ptr %t39, ptr %l24
  br label %bb7
bb7:
  %t40 = load ptr, ptr %l17, !tbaa !29
  %t41 = load i32, ptr %l18, !tbaa !23
  %t42 = load ptr, ptr %l24, !tbaa !29
  %t43 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2evarDecl(ptr %v0, ptr %v1, ptr %v1, ptr %t40, i32 %t41, ptr %t42)
  %t44 = extractvalue { i32, ptr } %t43, 1
  %t45 = extractvalue { i32, ptr } %t43, 0
  store i32 %t45, ptr %l26
  %t46 = icmp ne i32 %t45, 0
  br i1 %t46, label %bb9, label %ok.47, !prof !99
ok.47:
  store ptr %t44, ptr %l25
  br label %bb8
bb8:
  %t48 = load ptr, ptr %l25, !tbaa !29
  store ptr %t48, ptr %l16, !tbaa !29
  br label %bb10
bb9:
  %t49 = load i32, ptr %l26, !tbaa !23
  %t50 = lshr i32 %t49, 16
  %t51 = and i32 %t49, 65535
  %t52 = icmp eq i32 %t50, 1
  %t53 = select i1 %t52, i32 1, i32 0
  %t54 = icmp eq i32 %t49, 0
  %t55 = shl i32 %t53, 16
  %t56 = or i32 %t55, %t51
  %t57 = select i1 %t54, i32 0, i32 %t56
  call void @__olang_scope_close(ptr %s0)
  %t59 = insertvalue { i32, ptr } zeroinitializer, i32 %t57, 0
  store { i32, ptr } %t59, ptr %rv
  br label %ret
bb10:
  call void @__olang_scope_close(ptr %s0)
  %t60 = load ptr, ptr %l16, !tbaa !29
  %t61 = insertvalue { i32, ptr } zeroinitializer, ptr %t60, 1
  store { i32, ptr } %t61, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2efunction(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca %"compiler/token:Token"
  %l7 = alloca i32
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca ptr
  %l12 = alloca i1
  %l13 = alloca { i64, ptr }
  %l14 = alloca i32
  %l17 = alloca i32
  %l18 = alloca i32
  %l22 = alloca i1
  %l23 = alloca ptr
  %l25 = alloca ptr
  %l26 = alloca i32
  %l29 = alloca i32
  %l32 = alloca i32
  %l33 = alloca i32
  %l35 = alloca i32
  %l37 = alloca i32
  %l38 = alloca i32
  %l41 = alloca i1
  %l43 = alloca %"compiler/token:Token"
  %l44 = alloca i32
  %l46 = alloca i32
  %l47 = alloca i32
  %l54 = alloca i1
  %l55 = alloca { i64, ptr }
  %l57 = alloca { i64, ptr }
  %l58 = alloca i32
  %l62 = alloca %"compiler/source:Span"
  %l63 = alloca i32
  %l70 = alloca i32
  %l73 = alloca i32
  %l74 = alloca i32
  %l76 = alloca i32
  %l78 = alloca i32
  %l79 = alloca i32
  %l82 = alloca ptr
  %l86 = alloca { i64, ptr }
  %l90 = alloca { i64, ptr }
  %l93 = alloca i32
  %l96 = alloca i32
  %l98 = alloca i32
  %l99 = alloca i32
  %l106 = alloca i1
  %l107 = alloca { i64, ptr }
  %l109 = alloca { i64, ptr }
  %l110 = alloca i32
  %l115 = alloca i1
  %l120 = alloca ptr
  %l129 = alloca { i64, ptr }
  %l130 = alloca ptr
  %l134 = alloca i1
  %l136 = alloca i1
  %l137 = alloca i1
  %l139 = alloca i1
  %l140 = alloca i1
  %l142 = alloca i1
  %l143 = alloca i1
  %l145 = alloca i1
  %l146 = alloca ptr
  %l148 = alloca ptr
  %l149 = alloca i32
  %l154 = alloca i1
  %l155 = alloca { i64, ptr }
  %l157 = alloca { i64, ptr }
  %l158 = alloca i32
  %l161 = alloca ptr
  %l164 = alloca %"compiler/source:Span"
  %l165 = alloca ptr
  %l166 = alloca i32
  %l167 = alloca ptr
  %l174 = alloca %"compiler/ast:Func"
  %l181 = alloca %"compiler/source:Span"
  %l189 = alloca %"compiler/ast:Func"
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca { i32, ptr }
  %t170 = alloca i64
  %t181 = alloca { i64, [5 x i64] }, align 8
  %t462 = alloca { i64, [8 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t4 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %t1, i32 37)
  %t5 = extractvalue { i32, i32 } %t4, 1
  %t6 = extractvalue { i32, i32 } %t4, 0
  store i32 %t6, ptr %l18
  %t7 = icmp ne i32 %t6, 0
  br i1 %t7, label %bb2, label %ok.8, !prof !99
ok.8:
  store i32 %t5, ptr %l17
  br label %bb1
bb1:
  %t9 = load i32, ptr %l17, !tbaa !23
  store i32 %t9, ptr %l14, !tbaa !23
  br label %bb3
bb2:
  %t10 = load i32, ptr %l18, !tbaa !23
  %t11 = lshr i32 %t10, 16
  %t12 = and i32 %t10, 65535
  %t13 = icmp eq i32 %t11, 1
  %t14 = select i1 %t13, i32 1, i32 0
  %t15 = icmp eq i32 %t10, 0
  %t16 = shl i32 %t14, 16
  %t17 = or i32 %t16, %t12
  %t18 = select i1 %t15, i32 0, i32 %t17
  call void @__olang_scope_close(ptr %s0)
  %t20 = insertvalue { i32, ptr } zeroinitializer, i32 %t18, 0
  store { i32, ptr } %t20, ptr %rv
  br label %ret
bb3:
  %t21 = load i32, ptr %l14, !tbaa !23
  store i32 %t21, ptr %l1, !tbaa !23
  store ptr null, ptr %l2, !tbaa !29
  store i32 0, ptr %l3, !tbaa !23
  store ptr null, ptr %l4, !tbaa !29
  store i32 0, ptr %l5, !tbaa !23
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t25 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t22, i32 110)
  store i1 %t25, ptr %l22
  br label %bb4
bb4:
  %t26 = load i1, ptr %l22, !tbaa !21
  br i1 %t26, label %bb5, label %bb6
bb5:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eparam(ptr %v0, ptr %v1, ptr %t27, i1 false)
  %t30 = extractvalue { i32, ptr } %t29, 1
  %t31 = extractvalue { i32, ptr } %t29, 0
  store i32 %t31, ptr %l26
  %t32 = icmp ne i32 %t31, 0
  br i1 %t32, label %bb8, label %ok.33, !prof !99
ok.33:
  store ptr %t30, ptr %l25
  br label %bb7
bb6:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eownerAhead(ptr %v0, ptr %t34)
  store i1 %t36, ptr %l41
  br label %bb16
bb7:
  %t37 = load ptr, ptr %l25, !tbaa !29
  store ptr %t37, ptr %l23, !tbaa !29
  br label %bb9
bb8:
  %t38 = load i32, ptr %l26, !tbaa !23
  %t39 = lshr i32 %t38, 16
  %t40 = and i32 %t38, 65535
  %t41 = icmp eq i32 %t39, 1
  %t42 = select i1 %t41, i32 1, i32 0
  %t43 = icmp eq i32 %t38, 0
  %t44 = shl i32 %t42, 16
  %t45 = or i32 %t44, %t40
  %t46 = select i1 %t43, i32 0, i32 %t45
  call void @__olang_scope_close(ptr %s0)
  %t48 = insertvalue { i32, ptr } zeroinitializer, i32 %t46, 0
  store { i32, ptr } %t48, ptr %rv
  br label %ret
bb9:
  %t49 = load ptr, ptr %l23, !tbaa !29
  store ptr %t49, ptr %l2, !tbaa !29
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t54 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %t51, i32 111)
  %t55 = extractvalue { i32, i32 } %t54, 1
  %t56 = extractvalue { i32, i32 } %t54, 0
  store i32 %t56, ptr %l33
  %t57 = icmp ne i32 %t56, 0
  br i1 %t57, label %bb11, label %ok.58, !prof !99
ok.58:
  store i32 %t55, ptr %l32
  br label %bb10
bb10:
  %t59 = load i32, ptr %l32, !tbaa !23
  store i32 %t59, ptr %l29, !tbaa !23
  br label %bb12
bb11:
  %t60 = load i32, ptr %l33, !tbaa !23
  %t61 = lshr i32 %t60, 16
  %t62 = and i32 %t60, 65535
  %t63 = icmp eq i32 %t61, 1
  %t64 = select i1 %t63, i32 1, i32 0
  %t65 = icmp eq i32 %t60, 0
  %t66 = shl i32 %t64, 16
  %t67 = or i32 %t66, %t62
  %t68 = select i1 %t65, i32 0, i32 %t67
  call void @__olang_scope_close(ptr %s0)
  %t70 = insertvalue { i32, ptr } zeroinitializer, i32 %t68, 0
  store { i32, ptr } %t70, ptr %rv
  br label %ret
bb12:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2emethodName(ptr %v0, ptr %t71)
  %t74 = extractvalue { i32, i32 } %t73, 1
  %t75 = extractvalue { i32, i32 } %t73, 0
  store i32 %t75, ptr %l38
  %t76 = icmp ne i32 %t75, 0
  br i1 %t76, label %bb14, label %ok.77, !prof !99
ok.77:
  store i32 %t74, ptr %l37
  br label %bb13
bb13:
  %t78 = load i32, ptr %l37, !tbaa !23
  store i32 %t78, ptr %l35, !tbaa !23
  br label %bb15
bb14:
  %t79 = load i32, ptr %l38, !tbaa !23
  %t80 = lshr i32 %t79, 16
  %t81 = and i32 %t79, 65535
  %t82 = icmp eq i32 %t80, 1
  %t83 = select i1 %t82, i32 1, i32 0
  %t84 = icmp eq i32 %t79, 0
  %t85 = shl i32 %t83, 16
  %t86 = or i32 %t85, %t81
  %t87 = select i1 %t84, i32 0, i32 %t86
  call void @__olang_scope_close(ptr %s0)
  %t89 = insertvalue { i32, ptr } zeroinitializer, i32 %t87, 0
  store { i32, ptr } %t89, ptr %rv
  br label %ret
bb15:
  %t90 = load i32, ptr %l35, !tbaa !23
  store i32 %t90, ptr %l3, !tbaa !23
  br label %bb53
bb16:
  %t91 = load i1, ptr %l41, !tbaa !21
  br i1 %t91, label %bb17, label %bb18
bb17:
  store %olang.scope zeroinitializer, ptr %s3
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2etk(ptr %v0, ptr %t92)
  store %"compiler/token:Token" %t94, ptr %l43
  br label %bb19
bb18:
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t97 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ename(ptr %v0, ptr %t95)
  %t98 = extractvalue { i32, i32 } %t97, 1
  %t99 = extractvalue { i32, i32 } %t97, 0
  store i32 %t99, ptr %l99
  %t100 = icmp ne i32 %t99, 0
  br i1 %t100, label %bb50, label %ok.101, !prof !99
ok.101:
  store i32 %t98, ptr %l98
  br label %bb49
bb19:
  %t102 = load %"compiler/token:Token", ptr %l43
  store %"compiler/token:Token" %t102, ptr %l6
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t105 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ename(ptr %v0, ptr %t103)
  %t106 = extractvalue { i32, i32 } %t105, 1
  %t107 = extractvalue { i32, i32 } %t105, 0
  store i32 %t107, ptr %l47
  %t108 = icmp ne i32 %t107, 0
  br i1 %t108, label %bb21, label %ok.109, !prof !99
ok.109:
  store i32 %t106, ptr %l46
  br label %bb20
bb20:
  %t110 = load i32, ptr %l46, !tbaa !23
  store i32 %t110, ptr %l44, !tbaa !23
  br label %bb22
bb21:
  %t111 = load i32, ptr %l47, !tbaa !23
  %t112 = lshr i32 %t111, 16
  %t113 = and i32 %t111, 65535
  %t114 = icmp eq i32 %t112, 1
  %t115 = select i1 %t114, i32 1, i32 0
  %t116 = icmp eq i32 %t111, 0
  %t117 = shl i32 %t115, 16
  %t118 = or i32 %t117, %t113
  %t119 = select i1 %t116, i32 0, i32 %t118
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t121 = insertvalue { i32, ptr } zeroinitializer, i32 %t119, 0
  store { i32, ptr } %t121, ptr %rv
  br label %ret
bb22:
  %t122 = load i32, ptr %l44, !tbaa !23
  store i32 %t122, ptr %l7, !tbaa !23
  %t123 = icmp sge i64 0, 0
  br i1 %t123, label %bb23, label %bb24
bb23:
  %t125 = icmp sle i64 0, 1152921504606846975
  br i1 %t125, label %bb25, label %bb26
bb24:
  call void @__olang_check_failed(ptr @olang_loc_4c43f34f877e1376_ed14b5a1f1e9a1ea)
  unreachable
bb25:
  %t127 = mul i64 0, 8
  %t128 = insertvalue { i64, ptr } undef, i64 0, 0
  %t129 = insertvalue { i64, ptr } %t128, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t129, ptr %l8, !tbaa !27
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t134 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t131, i32 98)
  store i1 %t134, ptr %l54
  br label %bb27
bb26:
  call void @__olang_check_failed(ptr @olang_loc_4c43f34f877e1376_ed14b5a1f1e9a1ea)
  unreachable
bb27:
  %t135 = load i1, ptr %l54, !tbaa !21
  br i1 %t135, label %bb28, label %bb29
bb28:
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t138 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeArgs(ptr %v0, ptr %v1, ptr %t136)
  %t139 = extractvalue { i32, { i64, ptr } } %t138, 1
  %t140 = extractvalue { i32, { i64, ptr } } %t138, 0
  store i32 %t140, ptr %l58
  %t141 = icmp ne i32 %t140, 0
  br i1 %t141, label %bb31, label %ok.142, !prof !99
ok.142:
  store { i64, ptr } %t139, ptr %l57
  br label %bb30
bb29:
  br label %bb33
bb30:
  %t143 = load { i64, ptr }, ptr %l57, !tbaa !27
  store { i64, ptr } %t143, ptr %l55, !tbaa !27
  br label %bb32
bb31:
  %t144 = load i32, ptr %l58, !tbaa !23
  %t145 = lshr i32 %t144, 16
  %t146 = and i32 %t144, 65535
  %t147 = icmp eq i32 %t145, 1
  %t148 = select i1 %t147, i32 1, i32 0
  %t149 = icmp eq i32 %t144, 0
  %t150 = shl i32 %t148, 16
  %t151 = or i32 %t150, %t146
  %t152 = select i1 %t149, i32 0, i32 %t151
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t154 = insertvalue { i32, ptr } zeroinitializer, i32 %t152, 0
  store { i32, ptr } %t154, ptr %rv
  br label %ret
bb32:
  %t155 = load { i64, ptr }, ptr %l55, !tbaa !27
  store { i64, ptr } %t155, ptr %l8, !tbaa !27
  br label %bb33
bb33:
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t157 = getelementptr %"compiler/token:Token", ptr %l6, i32 0, i32 2
  %t158 = load i32, ptr %t157, !tbaa !23
  %t161 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t156, i32 %t158)
  store %"compiler/source:Span" %t161, ptr %l62
  br label %bb34
bb34:
  %t162 = load i32, ptr %l7, !tbaa !23
  store i32 %t162, ptr %l63, !tbaa !23
  %t163 = icmp sge i64 1, 0
  br i1 %t163, label %bb35, label %bb36
bb35:
  %t165 = icmp sle i64 1, 2305843009213693951
  br i1 %t165, label %bb37, label %bb38
bb36:
  call void @__olang_check_failed(ptr @olang_loc_6416c01e12aaae0b_a3305b3dd64c2cbf)
  unreachable
bb37:
  %t167 = mul i64 1, 4
  %t168 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t167)
  %t169 = load i32, ptr %l63, !tbaa !23
  store i64 0, ptr %t170
  br label %fill.171
fill.171:
  %t174 = load i64, ptr %t170
  %t175 = icmp slt i64 %t174, 1
  br i1 %t175, label %fillb.172, label %filld.173
fillb.172:
  %t176 = getelementptr i32, ptr %t168, i64 %t174
  store i32 %t169, ptr %t176
  %t177 = add i64 %t174, 1
  store i64 %t177, ptr %t170
  br label %fill.171
filld.173:
  %t178 = insertvalue { i64, ptr } undef, i64 1, 0
  %t179 = insertvalue { i64, ptr } %t178, ptr %t168, 1
  %t180 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, [5 x i64] } zeroinitializer, ptr %t181
  %t182 = getelementptr { i64, [5 x i64] }, ptr %t181, i32 0, i32 0
  store i64 0, ptr %t182
  %t183 = load %"compiler/source:Span", ptr %l62
  %t184 = insertvalue { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } undef, %"compiler/source:Span" %t183, 0
  %t186 = insertvalue { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } %t184, { i64, ptr } %t179, 1
  %t188 = insertvalue { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } %t186, { i64, ptr } %t180, 2
  %t189 = getelementptr { i64, [5 x i64] }, ptr %t181, i32 0, i32 1
  store { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } %t188, ptr %t189
  %t190 = load { i64, [5 x i64] }, ptr %t181
  %t192 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 48, i64 8)
  store { i64, [5 x i64] } %t190, ptr %t192
  store ptr %t192, ptr %l4, !tbaa !29
  %t194 = load ptr, ptr %l0, !tbaa !29
  %t197 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %t194, i32 76)
  %t198 = extractvalue { i32, i32 } %t197, 1
  %t199 = extractvalue { i32, i32 } %t197, 0
  store i32 %t199, ptr %l74
  %t200 = icmp ne i32 %t199, 0
  br i1 %t200, label %bb40, label %ok.201, !prof !99
ok.201:
  store i32 %t198, ptr %l73
  br label %bb39
bb38:
  call void @__olang_check_failed(ptr @olang_loc_6416c01e12aaae0b_a3305b3dd64c2cbf)
  unreachable
bb39:
  %t202 = load i32, ptr %l73, !tbaa !23
  store i32 %t202, ptr %l70, !tbaa !23
  br label %bb41
bb40:
  %t203 = load i32, ptr %l74, !tbaa !23
  %t204 = lshr i32 %t203, 16
  %t205 = and i32 %t203, 65535
  %t206 = icmp eq i32 %t204, 1
  %t207 = select i1 %t206, i32 1, i32 0
  %t208 = icmp eq i32 %t203, 0
  %t209 = shl i32 %t207, 16
  %t210 = or i32 %t209, %t205
  %t211 = select i1 %t208, i32 0, i32 %t210
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t213 = insertvalue { i32, ptr } zeroinitializer, i32 %t211, 0
  store { i32, ptr } %t213, ptr %rv
  br label %ret
bb41:
  %t214 = load ptr, ptr %l0, !tbaa !29
  %t216 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2emethodName(ptr %v0, ptr %t214)
  %t217 = extractvalue { i32, i32 } %t216, 1
  %t218 = extractvalue { i32, i32 } %t216, 0
  store i32 %t218, ptr %l79
  %t219 = icmp ne i32 %t218, 0
  br i1 %t219, label %bb43, label %ok.220, !prof !99
ok.220:
  store i32 %t217, ptr %l78
  br label %bb42
bb42:
  %t221 = load i32, ptr %l78, !tbaa !23
  store i32 %t221, ptr %l76, !tbaa !23
  br label %bb44
bb43:
  %t222 = load i32, ptr %l79, !tbaa !23
  %t223 = lshr i32 %t222, 16
  %t224 = and i32 %t222, 65535
  %t225 = icmp eq i32 %t223, 1
  %t226 = select i1 %t225, i32 1, i32 0
  %t227 = icmp eq i32 %t222, 0
  %t228 = shl i32 %t226, 16
  %t229 = or i32 %t228, %t224
  %t230 = select i1 %t227, i32 0, i32 %t229
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t232 = insertvalue { i32, ptr } zeroinitializer, i32 %t230, 0
  store { i32, ptr } %t232, ptr %rv
  br label %ret
bb44:
  %t233 = load i32, ptr %l76, !tbaa !23
  store i32 %t233, ptr %l5, !tbaa !23
  %t234 = load ptr, ptr %l0, !tbaa !29
  %t236 = getelementptr %"compiler/parse:Parser", ptr %t234, i32 0, i32 2
  %t237 = load ptr, ptr %t236, !tbaa !29
  store ptr %t237, ptr %l82, !tbaa !29
  %t238 = load ptr, ptr %l0, !tbaa !29
  %t240 = getelementptr %"compiler/parse:Parser", ptr %t238, i32 0, i32 2
  %t241 = load ptr, ptr %t240, !tbaa !29
  %t242 = load i32, ptr %l7, !tbaa !23
  %t245 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %s3, ptr %t241, i32 %t242)
  store { i64, ptr } %t245, ptr %l86
  br label %bb45
bb45:
  %t246 = load ptr, ptr %l0, !tbaa !29
  %t248 = getelementptr %"compiler/parse:Parser", ptr %t246, i32 0, i32 2
  %t249 = load ptr, ptr %t248, !tbaa !29
  %t250 = load i32, ptr %l5, !tbaa !23
  %t253 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %s3, ptr %t249, i32 %t250)
  store { i64, ptr } %t253, ptr %l90
  br label %bb46
bb46:
  %t254 = load { i64, ptr }, ptr %l86, !tbaa !27
  %t255 = extractvalue { i64, ptr } %t254, 1
  %t256 = extractvalue { i64, ptr } %t254, 0
  %t257 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d3, i32 0, i32 1) }, 1
  %t258 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d3, i32 0, i32 1) }, 0
  %t259 = add i64 %t256, %t258
  %t260 = load { i64, ptr }, ptr %l90, !tbaa !27
  %t261 = extractvalue { i64, ptr } %t260, 1
  %t262 = extractvalue { i64, ptr } %t260, 0
  %t263 = add i64 %t259, %t262
  %t264 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t263)
  call void @olang_textcopy(ptr %t264, ptr %t255, i64 %t256)
  %t265 = getelementptr i8, ptr %t264, i64 %t256
  call void @olang_textcopy(ptr %t265, ptr %t257, i64 %t258)
  %t266 = getelementptr i8, ptr %t265, i64 %t258
  call void @olang_textcopy(ptr %t266, ptr %t261, i64 %t262)
  %t267 = insertvalue { i64, ptr } undef, i64 %t263, 0
  %t268 = insertvalue { i64, ptr } %t267, ptr %t264, 1
  %t270 = load ptr, ptr %l82, !tbaa !29
  %t272 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %s3, ptr %t270, { i64, ptr } %t268)
  store i32 %t272, ptr %l93
  br label %bb47
bb47:
  %t273 = load i32, ptr %l93, !tbaa !23
  store i32 %t273, ptr %l3, !tbaa !23
  %t274 = load ptr, ptr %l0, !tbaa !29
  %t275 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereceiverVars(ptr %v0, ptr %v1, ptr %t274, ptr %t275, i1 false)
  br label %bb48
bb48:
  call void @__olang_scope_close(ptr %s3)
  br label %bb52
bb49:
  %t278 = load i32, ptr %l98, !tbaa !23
  store i32 %t278, ptr %l96, !tbaa !23
  br label %bb51
bb50:
  %t279 = load i32, ptr %l99, !tbaa !23
  %t280 = lshr i32 %t279, 16
  %t281 = and i32 %t279, 65535
  %t282 = icmp eq i32 %t280, 1
  %t283 = select i1 %t282, i32 1, i32 0
  %t284 = icmp eq i32 %t279, 0
  %t285 = shl i32 %t283, 16
  %t286 = or i32 %t285, %t281
  %t287 = select i1 %t284, i32 0, i32 %t286
  call void @__olang_scope_close(ptr %s0)
  %t289 = insertvalue { i32, ptr } zeroinitializer, i32 %t287, 0
  store { i32, ptr } %t289, ptr %rv
  br label %ret
bb51:
  %t290 = load i32, ptr %l96, !tbaa !23
  store i32 %t290, ptr %l3, !tbaa !23
  br label %bb52
bb52:
  br label %bb53
bb53:
  %t291 = icmp sge i64 0, 0
  br i1 %t291, label %bb54, label %bb55
bb54:
  %t293 = icmp sle i64 0, 1152921504606846975
  br i1 %t293, label %bb56, label %bb57
bb55:
  call void @__olang_check_failed(ptr @olang_loc_79faa04a2077f0a8_b4c818f5d0d3035c)
  unreachable
bb56:
  %t295 = mul i64 0, 8
  %t296 = insertvalue { i64, ptr } undef, i64 0, 0
  %t297 = insertvalue { i64, ptr } %t296, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t297, ptr %l9, !tbaa !27
  %t299 = load ptr, ptr %l0, !tbaa !29
  %t302 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t299, i32 98)
  store i1 %t302, ptr %l106
  br label %bb58
bb57:
  call void @__olang_check_failed(ptr @olang_loc_79faa04a2077f0a8_b4c818f5d0d3035c)
  unreachable
bb58:
  %t303 = load i1, ptr %l106, !tbaa !21
  br i1 %t303, label %bb59, label %bb60
bb59:
  %t304 = load ptr, ptr %l0, !tbaa !29
  %t306 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeParams(ptr %v0, ptr %v1, ptr %t304)
  %t307 = extractvalue { i32, { i64, ptr } } %t306, 1
  %t308 = extractvalue { i32, { i64, ptr } } %t306, 0
  store i32 %t308, ptr %l110
  %t309 = icmp ne i32 %t308, 0
  br i1 %t309, label %bb62, label %ok.310, !prof !99
ok.310:
  store { i64, ptr } %t307, ptr %l109
  br label %bb61
bb60:
  br label %bb64
bb61:
  %t311 = load { i64, ptr }, ptr %l109, !tbaa !27
  store { i64, ptr } %t311, ptr %l107, !tbaa !27
  br label %bb63
bb62:
  %t312 = load i32, ptr %l110, !tbaa !23
  %t313 = lshr i32 %t312, 16
  %t314 = and i32 %t312, 65535
  %t315 = icmp eq i32 %t313, 1
  %t316 = select i1 %t315, i32 1, i32 0
  %t317 = icmp eq i32 %t312, 0
  %t318 = shl i32 %t316, 16
  %t319 = or i32 %t318, %t314
  %t320 = select i1 %t317, i32 0, i32 %t319
  call void @__olang_scope_close(ptr %s0)
  %t322 = insertvalue { i32, ptr } zeroinitializer, i32 %t320, 0
  store { i32, ptr } %t322, ptr %rv
  br label %ret
bb63:
  %t323 = load { i64, ptr }, ptr %l107, !tbaa !27
  store { i64, ptr } %t323, ptr %l9, !tbaa !27
  br label %bb64
bb64:
  %t324 = load ptr, ptr %l2, !tbaa !29
  %t326 = icmp eq ptr %t324, null
  %t328 = xor i1 %t326, true
  br i1 %t328, label %bb65, label %bb66
bb65:
  %t330 = load ptr, ptr %l2, !tbaa !29
  %t332 = getelementptr %"compiler/ast:Param", ptr %t330, i32 0, i32 2
  %t333 = load ptr, ptr %t332, !tbaa !29
  %t335 = icmp eq ptr %t333, null
  %t337 = xor i1 %t335, true
  store i1 %t337, ptr %l115, !tbaa !21
  br label %bb67
bb66:
  store i1 false, ptr %l115, !tbaa !21
  br label %bb67
bb67:
  %t339 = load i1, ptr %l115, !tbaa !21
  br i1 %t339, label %bb68, label %bb69
bb68:
  %t340 = load ptr, ptr %l0, !tbaa !29
  store ptr %t340, ptr %l120, !tbaa !29
  %t341 = load ptr, ptr %l2, !tbaa !29
  %t343 = getelementptr %"compiler/ast:Param", ptr %t341, i32 0, i32 2
  %t344 = load ptr, ptr %t343, !tbaa !29
  %t346 = icmp eq ptr %t344, null
  br i1 %t346, label %bb70, label %bb71
bb69:
  br label %bb74
bb70:
  call void @__olang_check_failed(ptr @olang_loc_7ae9d5317a3d4e8f_1e272ac5502f090b)
  unreachable
bb71:
  br label %bb72
bb72:
  %t348 = load ptr, ptr %l2, !tbaa !29
  %t350 = getelementptr %"compiler/ast:Param", ptr %t348, i32 0, i32 2
  %t351 = load ptr, ptr %t350, !tbaa !29
  %t352 = load ptr, ptr %l120, !tbaa !29
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereceiverVars(ptr %v0, ptr %v1, ptr %t352, ptr %t351, i1 false)
  br label %bb73
bb73:
  br label %bb74
bb74:
  %t354 = load ptr, ptr %l0, !tbaa !29
  %t356 = getelementptr %"compiler/parse:Parser", ptr %t354, i32 0, i32 2
  %t357 = load ptr, ptr %t356, !tbaa !29
  %t358 = load i32, ptr %l3, !tbaa !23
  %t361 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %v0, ptr %t357, i32 %t358)
  store { i64, ptr } %t361, ptr %l129
  br label %bb75
bb75:
  %t362 = load { i64, ptr }, ptr %l129, !tbaa !27
  store { i64, ptr } %t362, ptr %l10, !tbaa !27
  %t363 = load ptr, ptr %l0, !tbaa !29
  store ptr %t363, ptr %l130, !tbaa !29
  %t364 = load ptr, ptr %l2, !tbaa !29
  %t366 = icmp eq ptr %t364, null
  %t368 = xor i1 %t366, true
  br i1 %t368, label %bb76, label %bb77
bb76:
  %t370 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t372 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t370, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d4, i32 0, i32 1) })
  store i1 %t372, ptr %l136
  br label %bb78
bb77:
  store i1 false, ptr %l134, !tbaa !21
  br label %bb91
bb78:
  %t373 = load i1, ptr %l136, !tbaa !21
  br i1 %t373, label %bb79, label %bb80
bb79:
  store i1 true, ptr %l137, !tbaa !21
  br label %bb82
bb80:
  %t374 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t376 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t374, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d5, i32 0, i32 1) })
  store i1 %t376, ptr %l139
  br label %bb81
bb81:
  %t377 = load i1, ptr %l139, !tbaa !21
  store i1 %t377, ptr %l137, !tbaa !21
  br label %bb82
bb82:
  %t378 = load i1, ptr %l137, !tbaa !21
  br i1 %t378, label %bb83, label %bb84
bb83:
  store i1 true, ptr %l140, !tbaa !21
  br label %bb86
bb84:
  %t379 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t381 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t379, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d6, i32 0, i32 1) })
  store i1 %t381, ptr %l142
  br label %bb85
bb85:
  %t382 = load i1, ptr %l142, !tbaa !21
  store i1 %t382, ptr %l140, !tbaa !21
  br label %bb86
bb86:
  %t383 = load i1, ptr %l140, !tbaa !21
  br i1 %t383, label %bb87, label %bb88
bb87:
  store i1 true, ptr %l143, !tbaa !21
  br label %bb90
bb88:
  %t384 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t386 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t384, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d7, i32 0, i32 1) })
  store i1 %t386, ptr %l145
  br label %bb89
bb89:
  %t387 = load i1, ptr %l145, !tbaa !21
  store i1 %t387, ptr %l143, !tbaa !21
  br label %bb90
bb90:
  %t388 = load i1, ptr %l143, !tbaa !21
  store i1 %t388, ptr %l134, !tbaa !21
  br label %bb91
bb91:
  %t389 = load i1, ptr %l134, !tbaa !21
  %t390 = load ptr, ptr %l130, !tbaa !29
  %t391 = getelementptr %"compiler/parse:Parser", ptr %t390, i32 0, i32 61
  store i1 %t389, ptr %t391, !tbaa !21
  %t392 = load ptr, ptr %l0, !tbaa !29
  %t394 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2esig(ptr %v0, ptr %v1, ptr %t392, i1 false, i1 false, i1 true, i1 false, i1 false)
  %t395 = extractvalue { i32, ptr } %t394, 1
  %t396 = extractvalue { i32, ptr } %t394, 0
  store i32 %t396, ptr %l149
  %t397 = icmp ne i32 %t396, 0
  br i1 %t397, label %bb93, label %ok.398, !prof !99
ok.398:
  store ptr %t395, ptr %l148
  br label %bb92
bb92:
  %t399 = load ptr, ptr %l148, !tbaa !29
  store ptr %t399, ptr %l146, !tbaa !29
  br label %bb94
bb93:
  %t400 = load i32, ptr %l149, !tbaa !23
  %t401 = lshr i32 %t400, 16
  %t402 = and i32 %t400, 65535
  %t403 = icmp eq i32 %t401, 1
  %t404 = select i1 %t403, i32 1, i32 0
  %t405 = icmp eq i32 %t400, 0
  %t406 = shl i32 %t404, 16
  %t407 = or i32 %t406, %t402
  %t408 = select i1 %t405, i32 0, i32 %t407
  call void @__olang_scope_close(ptr %s0)
  %t410 = insertvalue { i32, ptr } zeroinitializer, i32 %t408, 0
  store { i32, ptr } %t410, ptr %rv
  br label %ret
bb94:
  %t411 = load ptr, ptr %l146, !tbaa !29
  store ptr %t411, ptr %l11, !tbaa !29
  %t412 = load ptr, ptr %l0, !tbaa !29
  %t414 = getelementptr %"compiler/parse:Parser", ptr %t412, i32 0, i32 61
  store i1 false, ptr %t414, !tbaa !21
  %t415 = load ptr, ptr %l0, !tbaa !29
  %t418 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t415, i32 114)
  store i1 %t418, ptr %l154
  br label %bb95
bb95:
  %t419 = load i1, ptr %l154, !tbaa !21
  store i1 %t419, ptr %l12, !tbaa !21
  %t420 = load ptr, ptr %l0, !tbaa !29
  %t422 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ebody(ptr %v0, ptr %v1, ptr %t420)
  %t423 = extractvalue { i32, { i64, ptr } } %t422, 1
  %t424 = extractvalue { i32, { i64, ptr } } %t422, 0
  store i32 %t424, ptr %l158
  %t425 = icmp ne i32 %t424, 0
  br i1 %t425, label %bb97, label %ok.426, !prof !99
ok.426:
  store { i64, ptr } %t423, ptr %l157
  br label %bb96
bb96:
  %t427 = load { i64, ptr }, ptr %l157, !tbaa !27
  store { i64, ptr } %t427, ptr %l155, !tbaa !27
  br label %bb109
bb97:
  br label %bb98
bb98:
  %t428 = load i1, ptr %l12, !tbaa !21
  br i1 %t428, label %bb99, label %bb100
bb99:
  %t430 = load ptr, ptr %l0, !tbaa !29
  %t432 = getelementptr %"compiler/parse:Parser", ptr %t430, i32 0, i32 42
  store ptr %t432, ptr %l161, !tbaa !29
  %t433 = load ptr, ptr %l0, !tbaa !29
  %t434 = load i32, ptr %l1, !tbaa !23
  %t437 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t433, i32 %t434)
  store %"compiler/source:Span" %t437, ptr %l164
  br label %bb101
bb100:
  br label %bb108
bb101:
  %t438 = load ptr, ptr %l2, !tbaa !29
  store ptr %t438, ptr %l165, !tbaa !29
  %t439 = load i32, ptr %l3, !tbaa !23
  store i32 %t439, ptr %l166, !tbaa !23
  %t440 = load ptr, ptr %l11, !tbaa !29
  store ptr %t440, ptr %l167, !tbaa !29
  %t441 = icmp sge i64 0, 0
  br i1 %t441, label %bb102, label %bb103
bb102:
  %t443 = icmp sle i64 0, 1152921504606846975
  br i1 %t443, label %bb104, label %bb105
bb103:
  call void @__olang_check_failed(ptr @olang_loc_a8fa7275eec9c062_f04ec61276511d7e)
  unreachable
bb104:
  %t445 = mul i64 0, 8
  %t446 = insertvalue { i64, ptr } undef, i64 0, 0
  %t447 = insertvalue { i64, ptr } %t446, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t448 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t449 = load ptr, ptr %l4, !tbaa !29
  %t450 = load i32, ptr %l5, !tbaa !23
  %t451 = load %"compiler/source:Span", ptr %l164
  %t452 = load ptr, ptr %l165, !tbaa !29
  %t453 = load i32, ptr %l166, !tbaa !23
  %t454 = load ptr, ptr %l167, !tbaa !29
  %t459 = call %"compiler/ast:Func" @compiler_2fast_3aFunc_2ector(ptr %v1, ptr %v1, ptr %v0, ptr %v1, ptr %v1, ptr %v0, %"compiler/source:Span" %t451, ptr %t452, i32 %t453, ptr %t454, { i64, ptr } %t447, { i64, ptr } %t448, i1 false, i1 false, ptr %t449, i32 %t450)
  store %"compiler/ast:Func" %t459, ptr %l174
  br label %bb106
bb105:
  call void @__olang_check_failed(ptr @olang_loc_a8fa7275eec9c062_f04ec61276511d7e)
  unreachable
bb106:
  %t460 = load %"compiler/ast:Func", ptr %l174
  %t461 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 88, i64 8)
  store %"compiler/ast:Func" %t460, ptr %t461
  store { i64, [8 x i64] } zeroinitializer, ptr %t462
  %t463 = getelementptr { i64, [8 x i64] }, ptr %t462, i32 0, i32 0
  store i64 0, ptr %t463
  %t465 = insertvalue { ptr } undef, ptr %t461, 0
  %t466 = getelementptr { i64, [8 x i64] }, ptr %t462, i32 0, i32 1
  store { ptr } %t465, ptr %t466
  %t467 = load { i64, [8 x i64] }, ptr %t462
  %t469 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 72, i64 8)
  store { i64, [8 x i64] } %t467, ptr %t469
  %t470 = load ptr, ptr %l161, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aDecl_26_3e_2ePush_3ccompiler_2fast_3aDecl_26_3e(ptr %v0, ptr %v0, ptr %t470, ptr %t469)
  br label %bb107
bb107:
  br label %bb108
bb108:
  call void @__olang_scope_close(ptr %s0)
  %t473 = insertvalue { i32, ptr } zeroinitializer, i32 65536, 0
  store { i32, ptr } %t473, ptr %rv
  br label %ret
bb109:
  %t474 = load { i64, ptr }, ptr %l155, !tbaa !27
  store { i64, ptr } %t474, ptr %l13, !tbaa !27
  %t475 = load ptr, ptr %l0, !tbaa !29
  %t476 = load i32, ptr %l1, !tbaa !23
  %t479 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t475, i32 %t476)
  store %"compiler/source:Span" %t479, ptr %l181
  br label %bb110
bb110:
  %t480 = load ptr, ptr %l2, !tbaa !29
  %t481 = load i32, ptr %l3, !tbaa !23
  %t482 = load ptr, ptr %l11, !tbaa !29
  %t483 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t484 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t485 = load ptr, ptr %l4, !tbaa !29
  %t486 = load i32, ptr %l5, !tbaa !23
  %t487 = load %"compiler/source:Span", ptr %l181
  %t495 = call %"compiler/ast:Func" @compiler_2fast_3aFunc_2ector(ptr %v1, ptr %v1, ptr %v1, ptr %v1, ptr %v1, ptr %v1, %"compiler/source:Span" %t487, ptr %t480, i32 %t481, ptr %t482, { i64, ptr } %t483, { i64, ptr } %t484, i1 true, i1 false, ptr %t485, i32 %t486)
  store %"compiler/ast:Func" %t495, ptr %l189
  br label %bb111
bb111:
  %t496 = load %"compiler/ast:Func", ptr %l189
  %t497 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 88, i64 8)
  store %"compiler/ast:Func" %t496, ptr %t497
  call void @__olang_scope_close(ptr %s0)
  %t499 = insertvalue { i32, ptr } zeroinitializer, ptr %t497, 1
  store { i32, ptr } %t499, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eidenStmt(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca %"compiler/token:Token"
  %l4 = alloca i32
  %l5 = alloca %"compiler/source:Span"
  %lp6 = alloca ptr
  %l7 = alloca %"compiler/token:Token"
  %l10 = alloca i32
  %l12 = alloca i32
  %l15 = alloca i1
  %l18 = alloca i1
  %l21 = alloca i1
  %l25 = alloca %"compiler/token:Token"
  %l26 = alloca i32
  %l28 = alloca i32
  %l29 = alloca i32
  %l33 = alloca %"compiler/source:Span"
  %l35 = alloca i32
  %l37 = alloca i64
  %l39 = alloca i32
  %l42 = alloca { i64, ptr }
  %l43 = alloca i64
  %l47 = alloca %"compiler/source:Span"
  %l50 = alloca { i64, ptr }
  %l54 = alloca %"compiler/ast:VarDecl"
  %l61 = alloca i1
  %l64 = alloca i1
  %l67 = alloca i1
  %l70 = alloca i1
  %l73 = alloca i1
  %l76 = alloca i1
  %l79 = alloca i1
  %l82 = alloca i1
  %l85 = alloca i1
  %l89 = alloca %"compiler/token:Token"
  %l90 = alloca i32
  %l92 = alloca i32
  %l93 = alloca i32
  %l95 = alloca ptr
  %l96 = alloca ptr
  %l97 = alloca i32
  %l98 = alloca ptr
  %l99 = alloca i32
  %l102 = alloca %"compiler/source:Span"
  %l103 = alloca ptr
  %l104 = alloca ptr
  %l105 = alloca i32
  %l107 = alloca ptr
  %l109 = alloca ptr
  %l110 = alloca i32
  %s2 = alloca %olang.scope
  %rv = alloca { i32, ptr }
  %t94 = alloca i64
  %t128 = alloca i64
  %t154 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ehere(ptr %v0, ptr %t1)
  store i32 %t3, ptr %l10
  br label %bb1
bb1:
  %t4 = load i32, ptr %l10, !tbaa !23
  store i32 %t4, ptr %l1, !tbaa !23
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elook(ptr %v0, ptr %t5, i64 1)
  store i32 %t7, ptr %l12
  br label %bb2
bb2:
  %t8 = load i32, ptr %l12, !range !{i32 0, i32 116}
  store i32 %t8, ptr %l2
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/parse:Parser", ptr %t9, i32 0, i32 12
  %t12 = load i1, ptr %t11, !tbaa !21
  br i1 %t12, label %bb3, label %bb4
bb3:
  %t14 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t16 = trunc i64 8 to i32
  %t17 = icmp eq i32 %t14, %t16
  br i1 %t17, label %bb5, label %bb6
bb4:
  store i1 false, ptr %l15, !tbaa !21
  br label %bb11
bb5:
  store i1 true, ptr %l18, !tbaa !21
  br label %bb7
bb6:
  %t19 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t21 = trunc i64 115 to i32
  %t22 = icmp eq i32 %t19, %t21
  store i1 %t22, ptr %l18, !tbaa !21
  br label %bb7
bb7:
  %t24 = load i1, ptr %l18, !tbaa !21
  br i1 %t24, label %bb8, label %bb9
bb8:
  store i1 true, ptr %l21, !tbaa !21
  br label %bb10
bb9:
  %t25 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t27 = trunc i64 0 to i32
  %t28 = icmp eq i32 %t25, %t27
  store i1 %t28, ptr %l21, !tbaa !21
  br label %bb10
bb10:
  %t30 = load i1, ptr %l21, !tbaa !21
  store i1 %t30, ptr %l15, !tbaa !21
  br label %bb11
bb11:
  %t31 = load i1, ptr %l15, !tbaa !21
  br i1 %t31, label %bb12, label %bb13
bb12:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2etk(ptr %v0, ptr %t32)
  store %"compiler/token:Token" %t34, ptr %l25
  br label %bb14
bb13:
  br label %bb40
bb14:
  %t35 = load %"compiler/token:Token", ptr %l25
  store %"compiler/token:Token" %t35, ptr %l3
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ename(ptr %v0, ptr %t36)
  %t39 = extractvalue { i32, i32 } %t38, 1
  %t40 = extractvalue { i32, i32 } %t38, 0
  store i32 %t40, ptr %l29
  %t41 = icmp ne i32 %t40, 0
  br i1 %t41, label %bb16, label %ok.42, !prof !99
ok.42:
  store i32 %t39, ptr %l28
  br label %bb15
bb15:
  %t43 = load i32, ptr %l28, !tbaa !23
  store i32 %t43, ptr %l26, !tbaa !23
  br label %bb17
bb16:
  %t44 = load i32, ptr %l29, !tbaa !23
  %t45 = lshr i32 %t44, 16
  %t46 = and i32 %t44, 65535
  %t47 = icmp eq i32 %t45, 1
  %t48 = select i1 %t47, i32 1, i32 0
  %t49 = icmp eq i32 %t44, 0
  %t50 = shl i32 %t48, 16
  %t51 = or i32 %t50, %t46
  %t52 = select i1 %t49, i32 0, i32 %t51
  %t54 = insertvalue { i32, ptr } zeroinitializer, i32 %t52, 0
  store { i32, ptr } %t54, ptr %rv
  br label %ret
bb17:
  %t55 = load i32, ptr %l26, !tbaa !23
  store i32 %t55, ptr %l4, !tbaa !23
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t57 = load i32, ptr %l1, !tbaa !23
  %t60 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t56, i32 %t57)
  store %"compiler/source:Span" %t60, ptr %l33
  br label %bb18
bb18:
  %t61 = load %"compiler/source:Span", ptr %l33
  store %"compiler/source:Span" %t61, ptr %l5
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eendStmt(ptr %v0, ptr %t62)
  store i32 %t64, ptr %l35
  %t65 = icmp ne i32 %t64, 0
  br i1 %t65, label %bb20, label %ok.66, !prof !99
ok.66:
  br label %bb19
bb19:
  br label %bb21
bb20:
  %t67 = load i32, ptr %l35, !tbaa !23
  %t68 = lshr i32 %t67, 16
  %t69 = and i32 %t67, 65535
  %t70 = icmp eq i32 %t68, 1
  %t71 = select i1 %t70, i32 1, i32 0
  %t72 = icmp eq i32 %t67, 0
  %t73 = shl i32 %t71, 16
  %t74 = or i32 %t73, %t69
  %t75 = select i1 %t72, i32 0, i32 %t74
  %t77 = insertvalue { i32, ptr } zeroinitializer, i32 %t75, 0
  store { i32, ptr } %t77, ptr %rv
  br label %ret
bb21:
  %t78 = call ptr @__olang_scope_hold(ptr %v1)
  %t79 = ptrtoint ptr %t78 to i64
  store i64 %t79, ptr %l37, !tbaa !24
  %t80 = load i1, ptr @olang_2esole_2ecompiler_2fast_3aVarDecl_2e0
  br i1 %t80, label %bb22, label %bb23
bb22:
  %t82 = call ptr @__olang_region_make(ptr %v1)
  %t83 = ptrtoint ptr %t82 to i64
  store i64 %t83, ptr %l37, !tbaa !24
  br label %bb23
bb23:
  %t84 = load i32, ptr %l4, !tbaa !23
  store i32 %t84, ptr %l39, !tbaa !23
  %t85 = icmp sge i64 1, 0
  br i1 %t85, label %bb24, label %bb25
bb24:
  %t87 = icmp sle i64 1, 2305843009213693951
  br i1 %t87, label %bb26, label %bb27
bb25:
  call void @__olang_check_failed(ptr @olang_loc_13a9b66eb9aa3f96_3dd1d0a593daf8ba)
  unreachable
bb26:
  %t89 = mul i64 1, 4
  %t90 = load i64, ptr %l37
  %t91 = inttoptr i64 %t90 to ptr
  %t92 = call ptr @__olang_held_alloc(ptr %t91, i64 %t89)
  %t93 = load i32, ptr %l39, !tbaa !23
  store i64 0, ptr %t94
  br label %fill.95
fill.95:
  %t98 = load i64, ptr %t94
  %t99 = icmp slt i64 %t98, 1
  br i1 %t99, label %fillb.96, label %filld.97
fillb.96:
  %t100 = getelementptr i32, ptr %t92, i64 %t98
  store i32 %t93, ptr %t100
  %t101 = add i64 %t98, 1
  store i64 %t101, ptr %t94
  br label %fill.95
filld.97:
  %t102 = insertvalue { i64, ptr } undef, i64 1, 0
  %t103 = insertvalue { i64, ptr } %t102, ptr %t92, 1
  store { i64, ptr } %t103, ptr %l42, !tbaa !27
  %t104 = call ptr @__olang_scope_hold(ptr %v1)
  %t105 = ptrtoint ptr %t104 to i64
  store i64 %t105, ptr %l43, !tbaa !24
  %t106 = load i1, ptr @olang_2esole_2ecompiler_2fast_3aVarDecl_2e1
  br i1 %t106, label %bb28, label %bb29
bb27:
  call void @__olang_check_failed(ptr @olang_loc_13a9b66eb9aa3f96_3dd1d0a593daf8ba)
  unreachable
bb28:
  %t108 = call ptr @__olang_region_make(ptr %v1)
  %t109 = ptrtoint ptr %t108 to i64
  store i64 %t109, ptr %l43, !tbaa !24
  br label %bb29
bb29:
  %t110 = getelementptr %"compiler/token:Token", ptr %l3, i32 0, i32 2
  %t111 = load i32, ptr %t110, !tbaa !23
  %t112 = getelementptr %"compiler/token:Token", ptr %l3, i32 0, i32 3
  %t113 = load i32, ptr %t112, !tbaa !23
  %t114 = load i64, ptr %l43
  %t115 = inttoptr i64 %t114 to ptr
  %t118 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %t115, i32 %t111, i32 %t113)
  store %"compiler/source:Span" %t118, ptr %l47
  br label %bb30
bb30:
  %t119 = icmp sge i64 1, 0
  br i1 %t119, label %bb31, label %bb32
bb31:
  %t121 = icmp sle i64 1, 1152921504606846975
  br i1 %t121, label %bb33, label %bb34
bb32:
  call void @__olang_check_failed(ptr @olang_loc_13a9b66eb9aa3f96_3dd1d0a593daf8ba)
  unreachable
bb33:
  %t123 = mul i64 1, 8
  %t124 = load i64, ptr %l43
  %t125 = inttoptr i64 %t124 to ptr
  %t126 = call ptr @__olang_held_alloc(ptr %t125, i64 %t123)
  %t127 = load %"compiler/source:Span", ptr %l47
  store i64 0, ptr %t128
  br label %fill.129
fill.129:
  %t132 = load i64, ptr %t128
  %t133 = icmp slt i64 %t132, 1
  br i1 %t133, label %fillb.130, label %filld.131
fillb.130:
  %t134 = getelementptr %"compiler/source:Span", ptr %t126, i64 %t132
  store %"compiler/source:Span" %t127, ptr %t134
  %t135 = add i64 %t132, 1
  store i64 %t135, ptr %t128
  br label %fill.129
filld.131:
  %t136 = insertvalue { i64, ptr } undef, i64 1, 0
  %t137 = insertvalue { i64, ptr } %t136, ptr %t126, 1
  store { i64, ptr } %t137, ptr %l50, !tbaa !27
  %t138 = icmp sge i64 0, 0
  br i1 %t138, label %bb35, label %bb36
bb34:
  call void @__olang_check_failed(ptr @olang_loc_13a9b66eb9aa3f96_3dd1d0a593daf8ba)
  unreachable
bb35:
  %t140 = icmp sle i64 0, 1152921504606846975
  br i1 %t140, label %bb37, label %bb38
bb36:
  call void @__olang_check_failed(ptr @olang_loc_b5d05676e64fefab_5744e152e232520f)
  unreachable
bb37:
  %t142 = mul i64 0, 8
  %t143 = insertvalue { i64, ptr } undef, i64 0, 0
  %t144 = insertvalue { i64, ptr } %t143, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t145 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t146 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t148 = call %"compiler/ast:VarDecl" @compiler_2fast_3aVarDecl_2ector(ptr %v1, ptr %v1, ptr %v1, ptr %v1, ptr %v1, { i64, ptr } %t145, { i64, ptr } %t146, ptr null, { i64, ptr } %t144, i1 false, i1 true, i1 false)
  store %"compiler/ast:VarDecl" %t148, ptr %l54
  br label %bb39
bb38:
  call void @__olang_check_failed(ptr @olang_loc_b5d05676e64fefab_5744e152e232520f)
  unreachable
bb39:
  %t149 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 64, i64 8)
  store ptr %t149, ptr %lp6
  %t150 = load %"compiler/ast:VarDecl", ptr %l54
  %t151 = load ptr, ptr %lp6
  store %"compiler/ast:VarDecl" %t150, ptr %t151
  %t152 = load %"compiler/source:Span", ptr %l5
  %t153 = load ptr, ptr %lp6
  store { i64, [4 x i64] } zeroinitializer, ptr %t154
  %t155 = getelementptr { i64, [4 x i64] }, ptr %t154, i32 0, i32 0
  store i64 1, ptr %t155
  %t157 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t152, 0
  %t159 = insertvalue { %"compiler/source:Span", ptr } %t157, ptr %t153, 1
  %t160 = getelementptr { i64, [4 x i64] }, ptr %t154, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t159, ptr %t160
  %t161 = load { i64, [4 x i64] }, ptr %t154
  %t163 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 40, i64 8)
  store { i64, [4 x i64] } %t161, ptr %t163
  %t165 = insertvalue { i32, ptr } zeroinitializer, ptr %t163, 1
  store { i32, ptr } %t165, ptr %rv
  br label %ret
bb40:
  %t166 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t168 = trunc i64 80 to i32
  %t169 = icmp eq i32 %t166, %t168
  br i1 %t169, label %bb41, label %bb42
bb41:
  store i1 true, ptr %l61, !tbaa !21
  br label %bb43
bb42:
  %t171 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t173 = trunc i64 81 to i32
  %t174 = icmp eq i32 %t171, %t173
  store i1 %t174, ptr %l61, !tbaa !21
  br label %bb43
bb43:
  %t176 = load i1, ptr %l61, !tbaa !21
  br i1 %t176, label %bb44, label %bb45
bb44:
  store i1 true, ptr %l64, !tbaa !21
  br label %bb46
bb45:
  %t177 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t179 = trunc i64 1 to i32
  %t180 = icmp eq i32 %t177, %t179
  store i1 %t180, ptr %l64, !tbaa !21
  br label %bb46
bb46:
  %t182 = load i1, ptr %l64, !tbaa !21
  br i1 %t182, label %bb47, label %bb48
bb47:
  store i1 true, ptr %l67, !tbaa !21
  br label %bb49
bb48:
  %t183 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t185 = trunc i64 39 to i32
  %t186 = icmp eq i32 %t183, %t185
  store i1 %t186, ptr %l67, !tbaa !21
  br label %bb49
bb49:
  %t188 = load i1, ptr %l67, !tbaa !21
  br i1 %t188, label %bb50, label %bb51
bb50:
  store i1 true, ptr %l70, !tbaa !21
  br label %bb52
bb51:
  %t189 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t191 = trunc i64 52 to i32
  %t192 = icmp eq i32 %t189, %t191
  store i1 %t192, ptr %l70, !tbaa !21
  br label %bb52
bb52:
  %t194 = load i1, ptr %l70, !tbaa !21
  br i1 %t194, label %bb53, label %bb54
bb53:
  store i1 true, ptr %l73, !tbaa !21
  br label %bb55
bb54:
  %t195 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t197 = trunc i64 37 to i32
  %t198 = icmp eq i32 %t195, %t197
  store i1 %t198, ptr %l73, !tbaa !21
  br label %bb55
bb55:
  %t200 = load i1, ptr %l73, !tbaa !21
  br i1 %t200, label %bb56, label %bb57
bb56:
  store i1 true, ptr %l76, !tbaa !21
  br label %bb58
bb57:
  %t201 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t203 = trunc i64 35 to i32
  %t204 = icmp eq i32 %t201, %t203
  store i1 %t204, ptr %l76, !tbaa !21
  br label %bb58
bb58:
  %t206 = load i1, ptr %l76, !tbaa !21
  br i1 %t206, label %bb59, label %bb60
bb59:
  store i1 true, ptr %l79, !tbaa !21
  br label %bb61
bb60:
  %t207 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t209 = trunc i64 34 to i32
  %t210 = icmp eq i32 %t207, %t209
  store i1 %t210, ptr %l79, !tbaa !21
  br label %bb61
bb61:
  %t212 = load i1, ptr %l79, !tbaa !21
  br i1 %t212, label %bb62, label %bb63
bb62:
  store i1 true, ptr %l82, !tbaa !21
  br label %bb64
bb63:
  %t213 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t215 = trunc i64 67 to i32
  %t216 = icmp eq i32 %t213, %t215
  store i1 %t216, ptr %l82, !tbaa !21
  br label %bb64
bb64:
  %t218 = load i1, ptr %l82, !tbaa !21
  br i1 %t218, label %bb65, label %bb66
bb65:
  store i1 true, ptr %l85, !tbaa !21
  br label %bb67
bb66:
  %t219 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t221 = trunc i64 43 to i32
  %t222 = icmp eq i32 %t219, %t221
  store i1 %t222, ptr %l85, !tbaa !21
  br label %bb67
bb67:
  %t224 = load i1, ptr %l85, !tbaa !21
  br i1 %t224, label %bb68, label %bb69
bb68:
  store %olang.scope zeroinitializer, ptr %s2
  %t225 = load ptr, ptr %l0, !tbaa !29
  %t227 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2etk(ptr %v0, ptr %t225)
  store %"compiler/token:Token" %t227, ptr %l89
  br label %bb70
bb69:
  br label %bb79
bb70:
  %t228 = load %"compiler/token:Token", ptr %l89
  store %"compiler/token:Token" %t228, ptr %l7
  %t229 = load ptr, ptr %l0, !tbaa !29
  %t231 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ename(ptr %v0, ptr %t229)
  %t232 = extractvalue { i32, i32 } %t231, 1
  %t233 = extractvalue { i32, i32 } %t231, 0
  store i32 %t233, ptr %l93
  %t234 = icmp ne i32 %t233, 0
  br i1 %t234, label %bb72, label %ok.235, !prof !99
ok.235:
  store i32 %t232, ptr %l92
  br label %bb71
bb71:
  %t236 = load i32, ptr %l92, !tbaa !23
  store i32 %t236, ptr %l90, !tbaa !23
  br label %bb73
bb72:
  %t237 = load i32, ptr %l93, !tbaa !23
  %t238 = lshr i32 %t237, 16
  %t239 = and i32 %t237, 65535
  %t240 = icmp eq i32 %t238, 1
  %t241 = select i1 %t240, i32 1, i32 0
  %t242 = icmp eq i32 %t237, 0
  %t243 = shl i32 %t241, 16
  %t244 = or i32 %t243, %t239
  %t245 = select i1 %t242, i32 0, i32 %t244
  call void @__olang_scope_close(ptr %s2)
  %t247 = insertvalue { i32, ptr } zeroinitializer, i32 %t245, 0
  store { i32, ptr } %t247, ptr %rv
  br label %ret
bb73:
  %t248 = load i32, ptr %l90, !tbaa !23
  %t249 = load ptr, ptr %l0, !tbaa !29
  store ptr %t249, ptr %l96, !tbaa !29
  %t250 = load i32, ptr %l1, !tbaa !23
  store i32 %t250, ptr %l97, !tbaa !23
  %t251 = load ptr, ptr %l0, !tbaa !29
  store ptr %t251, ptr %l98, !tbaa !29
  store i32 %t248, ptr %l99, !tbaa !23
  %t253 = getelementptr %"compiler/token:Token", ptr %l7, i32 0, i32 2
  %t254 = load i32, ptr %t253, !tbaa !23
  %t255 = getelementptr %"compiler/token:Token", ptr %l7, i32 0, i32 3
  %t256 = load i32, ptr %t255, !tbaa !23
  %t259 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s2, i32 %t254, i32 %t256)
  store %"compiler/source:Span" %t259, ptr %l102
  br label %bb74
bb74:
  %t260 = load ptr, ptr %l98, !tbaa !29
  %t261 = load i32, ptr %l99, !tbaa !23
  %t262 = load %"compiler/source:Span", ptr %l102
  %t263 = call ptr @compiler_2fparse_2ecompiler_2fparse_3aParser_2eone(ptr %v0, ptr %v1, ptr %t260, i32 %t261, %"compiler/source:Span" %t262)
  store ptr %t263, ptr %l103
  br label %bb75
bb75:
  %t264 = load ptr, ptr %l96, !tbaa !29
  %t265 = load i32, ptr %l97, !tbaa !23
  %t266 = load ptr, ptr %l103, !tbaa !29
  %t267 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2evarDecl(ptr %v0, ptr %v1, ptr %v1, ptr %t264, i32 %t265, ptr %t266)
  %t268 = extractvalue { i32, ptr } %t267, 1
  %t269 = extractvalue { i32, ptr } %t267, 0
  store i32 %t269, ptr %l105
  %t270 = icmp ne i32 %t269, 0
  br i1 %t270, label %bb77, label %ok.271, !prof !99
ok.271:
  store ptr %t268, ptr %l104
  br label %bb76
bb76:
  %t272 = load ptr, ptr %l104, !tbaa !29
  store ptr %t272, ptr %l95, !tbaa !29
  br label %bb78
bb77:
  %t273 = load i32, ptr %l105, !tbaa !23
  %t274 = lshr i32 %t273, 16
  %t275 = and i32 %t273, 65535
  %t276 = icmp eq i32 %t274, 1
  %t277 = select i1 %t276, i32 1, i32 0
  %t278 = icmp eq i32 %t273, 0
  %t279 = shl i32 %t277, 16
  %t280 = or i32 %t279, %t275
  %t281 = select i1 %t278, i32 0, i32 %t280
  call void @__olang_scope_close(ptr %s2)
  %t283 = insertvalue { i32, ptr } zeroinitializer, i32 %t281, 0
  store { i32, ptr } %t283, ptr %rv
  br label %ret
bb78:
  call void @__olang_scope_close(ptr %s2)
  %t284 = load ptr, ptr %l95, !tbaa !29
  %t285 = insertvalue { i32, ptr } zeroinitializer, ptr %t284, 1
  store { i32, ptr } %t285, ptr %rv
  br label %ret
bb79:
  %t286 = load ptr, ptr %l0, !tbaa !29
  %t288 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexprStmt(ptr %v0, ptr %v1, ptr %t286)
  %t289 = extractvalue { i32, ptr } %t288, 1
  %t290 = extractvalue { i32, ptr } %t288, 0
  store i32 %t290, ptr %l110
  %t291 = icmp ne i32 %t290, 0
  br i1 %t291, label %bb81, label %ok.292, !prof !99
ok.292:
  store ptr %t289, ptr %l109
  br label %bb80
bb80:
  %t293 = load ptr, ptr %l109, !tbaa !29
  store ptr %t293, ptr %l107, !tbaa !29
  br label %bb82
bb81:
  %t294 = load i32, ptr %l110, !tbaa !23
  %t295 = lshr i32 %t294, 16
  %t296 = and i32 %t294, 65535
  %t297 = icmp eq i32 %t295, 1
  %t298 = select i1 %t297, i32 1, i32 0
  %t299 = icmp eq i32 %t294, 0
  %t300 = shl i32 %t298, 16
  %t301 = or i32 %t300, %t296
  %t302 = select i1 %t299, i32 0, i32 %t301
  %t304 = insertvalue { i32, ptr } zeroinitializer, i32 %t302, 0
  store { i32, ptr } %t304, ptr %rv
  br label %ret
bb82:
  %t305 = load ptr, ptr %l107, !tbaa !29
  %t306 = insertvalue { i32, ptr } zeroinitializer, ptr %t305, 1
  store { i32, ptr } %t306, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eindex(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca i1
  %l5 = alloca i1
  %l6 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca i64
  %l12 = alloca %"compiler/source:Span"
  %l17 = alloca i32
  %l20 = alloca i1
  %l21 = alloca i1
  %l24 = alloca i1
  %l25 = alloca ptr
  %l27 = alloca { i64, ptr }
  %l29 = alloca i32
  %l37 = alloca ptr
  %l43 = alloca i1
  %l44 = alloca i1
  %l47 = alloca i1
  %l51 = alloca i1
  %l53 = alloca ptr
  %l55 = alloca ptr
  %l56 = alloca i32
  %l58 = alloca ptr
  %l68 = alloca i1
  %l69 = alloca ptr
  %l72 = alloca ptr
  %l73 = alloca i32
  %l75 = alloca ptr
  %l83 = alloca ptr
  %l90 = alloca ptr
  %l91 = alloca i32
  %l93 = alloca ptr
  %l101 = alloca ptr
  %l111 = alloca i1
  %l112 = alloca i1
  %l115 = alloca i1
  %l116 = alloca i1
  %l119 = alloca i1
  %l122 = alloca i64
  %l124 = alloca ptr
  %l125 = alloca ptr
  %l128 = alloca ptr
  %l129 = alloca i32
  %l131 = alloca ptr
  %l139 = alloca i1
  %l142 = alloca i1
  %l143 = alloca i32
  %l145 = alloca ptr
  %l155 = alloca ptr
  %l156 = alloca ptr
  %l157 = alloca ptr
  %l158 = alloca ptr
  %l160 = alloca ptr
  %l161 = alloca i32
  %l163 = alloca ptr
  %l171 = alloca ptr
  %l172 = alloca i32
  %l174 = alloca ptr
  %l182 = alloca i32
  %l185 = alloca i32
  %l186 = alloca i32
  %l188 = alloca ptr
  %l198 = alloca %"compiler/source:Span"
  %l199 = alloca ptr
  %l202 = alloca ptr
  %l203 = alloca i32
  %l205 = alloca ptr
  %l213 = alloca ptr
  %l217 = alloca { i64, ptr }
  %l220 = alloca ptr
  %l231 = alloca ptr
  %l232 = alloca ptr
  %l235 = alloca i32
  %l237 = alloca i32
  %l239 = alloca %"compiler/source:Span"
  %l242 = alloca ptr
  %l243 = alloca i32
  %l245 = alloca ptr
  %l255 = alloca i1
  %l256 = alloca i1
  %l258 = alloca i1
  %l260 = alloca i32
  %l263 = alloca %"compiler/source:Span"
  %l266 = alloca ptr
  %l267 = alloca ptr
  %l277 = alloca i64
  %l281 = alloca i1
  %l284 = alloca i1
  %l285 = alloca i32
  %l287 = alloca ptr
  %l297 = alloca ptr
  %l298 = alloca ptr
  %l300 = alloca ptr
  %l301 = alloca i32
  %l303 = alloca ptr
  %l313 = alloca i1
  %l318 = alloca ptr
  %l320 = alloca { i64, ptr }
  %l322 = alloca i32
  %l324 = alloca ptr
  %l333 = alloca i32
  %l336 = alloca %"compiler/source:Span"
  %l337 = alloca ptr
  %l341 = alloca { i64, ptr }
  %l344 = alloca ptr
  %l353 = alloca i32
  %l356 = alloca %"compiler/source:Span"
  %l357 = alloca ptr
  %l363 = alloca ptr
  %s1 = alloca %olang.scope
  %s39 = alloca %olang.scope
  %rv = alloca { i32, ptr }
  %t540 = alloca { i64, [4 x i64] }, align 8
  %t851 = alloca { i64, [4 x i64] }, align 8
  %t901 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t1)
  store %"compiler/source:Span" %t3, ptr %l12
  br label %bb1
bb1:
  %t4 = getelementptr %"compiler/source:Span", ptr %l12, i32 0, i32 0
  %t5 = load i32, ptr %t4, !tbaa !23
  store i32 %t5, ptr %l2, !tbaa !23
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/parse:Parser", ptr %t7, i32 0, i32 6
  %t10 = load i64, ptr %t9, !tbaa !24
  store i64 %t10, ptr %l3, !tbaa !24
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t12)
  store i32 %t14, ptr %l17
  br label %bb2
bb2:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t18 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t15, i32 111)
  store i1 %t18, ptr %l20
  br label %bb3
bb3:
  %t19 = load i1, ptr %l20, !tbaa !21
  br i1 %t19, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l21, !tbaa !21
  br label %bb7
bb5:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t23 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t20, i32 115)
  store i1 %t23, ptr %l24
  br label %bb6
bb6:
  %t24 = load i1, ptr %l24, !tbaa !21
  store i1 %t24, ptr %l21, !tbaa !21
  br label %bb7
bb7:
  %t25 = load i1, ptr %l21, !tbaa !21
  br i1 %t25, label %bb8, label %bb9
bb8:
  store %olang.scope zeroinitializer, ptr %s1
  %t26 = load ptr, ptr %l0, !tbaa !29
  store ptr %t26, ptr %l25, !tbaa !29
  %t28 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eDescribe(ptr %s1, i32 113)
  store { i64, ptr } %t28, ptr %l27
  br label %bb10
bb9:
  br label %bb14
bb10:
  %t29 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t30 = load ptr, ptr %l25, !tbaa !29
  %t32 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2efail(ptr %v0, ptr %s1, ptr %t30, { i64, ptr } %t29)
  store i32 %t32, ptr %l29
  %t33 = icmp ne i32 %t32, 0
  br i1 %t33, label %bb12, label %ok.34, !prof !99
ok.34:
  br label %bb11
bb11:
  br label %bb13
bb12:
  %t35 = load i32, ptr %l29, !tbaa !23
  %t36 = lshr i32 %t35, 16
  %t37 = and i32 %t35, 65535
  %t38 = icmp eq i32 %t36, 1
  %t39 = select i1 %t38, i32 1, i32 0
  %t40 = icmp eq i32 %t35, 0
  %t41 = shl i32 %t39, 16
  %t42 = or i32 %t41, %t37
  %t43 = select i1 %t40, i32 0, i32 %t42
  call void @__olang_scope_close(ptr %s1)
  %t45 = insertvalue { i32, ptr } zeroinitializer, i32 %t43, 0
  store { i32, ptr } %t45, ptr %rv
  br label %ret
bb13:
  call void @__olang_scope_close(ptr %s1)
  br label %bb14
bb14:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/parse:Parser", ptr %t46, i32 0, i32 11
  %t49 = load i1, ptr %t48, !tbaa !21
  store i1 %t49, ptr %l4, !tbaa !21
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = getelementptr %"compiler/parse:Parser", ptr %t51, i32 0, i32 23
  %t54 = load i1, ptr %t53, !tbaa !21
  store i1 %t54, ptr %l5, !tbaa !21
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/parse:Parser", ptr %t56, i32 0, i32 11
  store i1 false, ptr %t58, !tbaa !21
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/parse:Parser", ptr %t59, i32 0, i32 23
  store i1 true, ptr %t61, !tbaa !21
  %t62 = load ptr, ptr %l0, !tbaa !29
  store ptr %t62, ptr %l37, !tbaa !29
  %t63 = load ptr, ptr %l37, !tbaa !29
  %t64 = getelementptr %"compiler/parse:Parser", ptr %t63, i32 0, i32 21
  %t65 = load i64, ptr %t64, !tbaa !24
  %t68 = add i64 %t65, 1
  %t70 = load ptr, ptr %l37, !tbaa !29
  %t71 = getelementptr %"compiler/parse:Parser", ptr %t70, i32 0, i32 21
  store i64 %t68, ptr %t71, !tbaa !24
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t75 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t72, i32 79)
  store i1 %t75, ptr %l43
  br label %bb15
bb15:
  %t76 = load i1, ptr %l43, !tbaa !21
  br i1 %t76, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l44, !tbaa !21
  br label %bb19
bb17:
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t80 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t77, i32 113)
  store i1 %t80, ptr %l47
  br label %bb18
bb18:
  %t81 = load i1, ptr %l47, !tbaa !21
  %t82 = xor i1 %t81, true
  store i1 %t82, ptr %l44, !tbaa !21
  br label %bb19
bb19:
  %t84 = load i1, ptr %l44, !tbaa !21
  br i1 %t84, label %bb20, label %bb21
bb20:
  store ptr null, ptr %l6, !tbaa !29
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t88 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t85, i32 79)
  store i1 %t88, ptr %l51
  br label %bb22
bb21:
  br label %bb127
bb22:
  %t89 = load i1, ptr %l51, !tbaa !21
  %t90 = xor i1 %t89, true
  br i1 %t90, label %bb23, label %bb24
bb23:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eelem(ptr %v0, ptr %v2, ptr %t92)
  %t95 = extractvalue { i32, ptr } %t94, 1
  %t96 = extractvalue { i32, ptr } %t94, 0
  store i32 %t96, ptr %l56
  %t97 = icmp ne i32 %t96, 0
  br i1 %t97, label %bb26, label %ok.98, !prof !99
ok.98:
  store ptr %t95, ptr %l55
  br label %bb25
bb24:
  br label %bb79
bb25:
  %t99 = load ptr, ptr %l55, !tbaa !29
  store ptr %t99, ptr %l53, !tbaa !29
  br label %bb27
bb26:
  %t100 = load i32, ptr %l56, !tbaa !23
  %t101 = lshr i32 %t100, 16
  %t102 = and i32 %t100, 65535
  %t103 = icmp eq i32 %t101, 1
  %t104 = select i1 %t103, i32 1, i32 0
  %t105 = icmp eq i32 %t100, 0
  %t106 = shl i32 %t104, 16
  %t107 = or i32 %t106, %t102
  %t108 = select i1 %t105, i32 0, i32 %t107
  %t109 = load ptr, ptr %l0, !tbaa !29
  store ptr %t109, ptr %l58, !tbaa !29
  %t110 = load ptr, ptr %l58, !tbaa !29
  %t111 = getelementptr %"compiler/parse:Parser", ptr %t110, i32 0, i32 21
  %t112 = load i64, ptr %t111, !tbaa !24
  %t115 = sub i64 %t112, 1
  %t117 = load ptr, ptr %l58, !tbaa !29
  %t118 = getelementptr %"compiler/parse:Parser", ptr %t117, i32 0, i32 21
  store i64 %t115, ptr %t118, !tbaa !24
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t120 = load i1, ptr %l4, !tbaa !21
  %t123 = getelementptr %"compiler/parse:Parser", ptr %t119, i32 0, i32 11
  store i1 %t120, ptr %t123, !tbaa !21
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t125 = load i1, ptr %l5, !tbaa !21
  %t128 = getelementptr %"compiler/parse:Parser", ptr %t124, i32 0, i32 23
  store i1 %t125, ptr %t128, !tbaa !21
  %t130 = insertvalue { i32, ptr } zeroinitializer, i32 %t108, 0
  store { i32, ptr } %t130, ptr %rv
  br label %ret
bb27:
  %t131 = load ptr, ptr %l53, !tbaa !29
  store ptr %t131, ptr %l6, !tbaa !29
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t135 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ecomprehends(ptr %v0, ptr %t133)
  store i1 %t135, ptr %l68
  br label %bb28
bb28:
  %t136 = load i1, ptr %l68, !tbaa !21
  br i1 %t136, label %bb29, label %bb30
bb29:
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t138 = load ptr, ptr %l1, !tbaa !29
  %t141 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexprAsType(ptr %v0, ptr %v1, ptr %v2, ptr %t137, ptr %t138)
  %t142 = extractvalue { i32, ptr } %t141, 1
  %t143 = extractvalue { i32, ptr } %t141, 0
  store i32 %t143, ptr %l73
  %t144 = icmp ne i32 %t143, 0
  br i1 %t144, label %bb32, label %ok.145, !prof !99
ok.145:
  store ptr %t142, ptr %l72
  br label %bb31
bb30:
  br label %bb37
bb31:
  %t146 = load ptr, ptr %l72, !tbaa !29
  store ptr %t146, ptr %l69, !tbaa !29
  br label %bb33
bb32:
  %t147 = load i32, ptr %l73, !tbaa !23
  %t148 = lshr i32 %t147, 16
  %t149 = and i32 %t147, 65535
  %t150 = icmp eq i32 %t148, 1
  %t151 = select i1 %t150, i32 1, i32 0
  %t152 = icmp eq i32 %t147, 0
  %t153 = shl i32 %t151, 16
  %t154 = or i32 %t153, %t149
  %t155 = select i1 %t152, i32 0, i32 %t154
  %t156 = load ptr, ptr %l0, !tbaa !29
  store ptr %t156, ptr %l75, !tbaa !29
  %t157 = load ptr, ptr %l75, !tbaa !29
  %t158 = getelementptr %"compiler/parse:Parser", ptr %t157, i32 0, i32 21
  %t159 = load i64, ptr %t158, !tbaa !24
  %t162 = sub i64 %t159, 1
  %t164 = load ptr, ptr %l75, !tbaa !29
  %t165 = getelementptr %"compiler/parse:Parser", ptr %t164, i32 0, i32 21
  store i64 %t162, ptr %t165, !tbaa !24
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t167 = load i1, ptr %l4, !tbaa !21
  %t170 = getelementptr %"compiler/parse:Parser", ptr %t166, i32 0, i32 11
  store i1 %t167, ptr %t170, !tbaa !21
  %t171 = load ptr, ptr %l0, !tbaa !29
  %t172 = load i1, ptr %l5, !tbaa !21
  %t175 = getelementptr %"compiler/parse:Parser", ptr %t171, i32 0, i32 23
  store i1 %t172, ptr %t175, !tbaa !21
  %t177 = insertvalue { i32, ptr } zeroinitializer, i32 %t155, 0
  store { i32, ptr } %t177, ptr %rv
  br label %ret
bb33:
  %t178 = load ptr, ptr %l69, !tbaa !29
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t180 = load i32, ptr %l2, !tbaa !23
  %t183 = load ptr, ptr %l6, !tbaa !29
  %t189 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ecomprehension(ptr %v0, ptr %v2, ptr %v2, ptr %v2, ptr %t179, i32 %t180, ptr %t178, ptr %t183, i32 113)
  %t190 = extractvalue { i32, ptr } %t189, 1
  %t191 = extractvalue { i32, ptr } %t189, 0
  store i32 %t191, ptr %l91
  %t192 = icmp ne i32 %t191, 0
  br i1 %t192, label %bb35, label %ok.193, !prof !99
ok.193:
  store ptr %t190, ptr %l90
  br label %bb34
bb34:
  %t194 = load ptr, ptr %l90, !tbaa !29
  store ptr %t194, ptr %l83, !tbaa !29
  br label %bb36
bb35:
  %t195 = load i32, ptr %l91, !tbaa !23
  %t196 = lshr i32 %t195, 16
  %t197 = and i32 %t195, 65535
  %t198 = icmp eq i32 %t196, 1
  %t199 = select i1 %t198, i32 1, i32 0
  %t200 = icmp eq i32 %t195, 0
  %t201 = shl i32 %t199, 16
  %t202 = or i32 %t201, %t197
  %t203 = select i1 %t200, i32 0, i32 %t202
  %t204 = load ptr, ptr %l0, !tbaa !29
  store ptr %t204, ptr %l93, !tbaa !29
  %t205 = load ptr, ptr %l93, !tbaa !29
  %t206 = getelementptr %"compiler/parse:Parser", ptr %t205, i32 0, i32 21
  %t207 = load i64, ptr %t206, !tbaa !24
  %t210 = sub i64 %t207, 1
  %t212 = load ptr, ptr %l93, !tbaa !29
  %t213 = getelementptr %"compiler/parse:Parser", ptr %t212, i32 0, i32 21
  store i64 %t210, ptr %t213, !tbaa !24
  %t214 = load ptr, ptr %l0, !tbaa !29
  %t215 = load i1, ptr %l4, !tbaa !21
  %t218 = getelementptr %"compiler/parse:Parser", ptr %t214, i32 0, i32 11
  store i1 %t215, ptr %t218, !tbaa !21
  %t219 = load ptr, ptr %l0, !tbaa !29
  %t220 = load i1, ptr %l5, !tbaa !21
  %t223 = getelementptr %"compiler/parse:Parser", ptr %t219, i32 0, i32 23
  store i1 %t220, ptr %t223, !tbaa !21
  %t225 = insertvalue { i32, ptr } zeroinitializer, i32 %t203, 0
  store { i32, ptr } %t225, ptr %rv
  br label %ret
bb36:
  %t226 = load ptr, ptr %l0, !tbaa !29
  store ptr %t226, ptr %l101, !tbaa !29
  %t227 = load ptr, ptr %l101, !tbaa !29
  %t228 = getelementptr %"compiler/parse:Parser", ptr %t227, i32 0, i32 21
  %t229 = load i64, ptr %t228, !tbaa !24
  %t232 = sub i64 %t229, 1
  %t234 = load ptr, ptr %l101, !tbaa !29
  %t235 = getelementptr %"compiler/parse:Parser", ptr %t234, i32 0, i32 21
  store i64 %t232, ptr %t235, !tbaa !24
  %t236 = load ptr, ptr %l0, !tbaa !29
  %t237 = load i1, ptr %l4, !tbaa !21
  %t240 = getelementptr %"compiler/parse:Parser", ptr %t236, i32 0, i32 11
  store i1 %t237, ptr %t240, !tbaa !21
  %t241 = load ptr, ptr %l0, !tbaa !29
  %t242 = load i1, ptr %l5, !tbaa !21
  %t245 = getelementptr %"compiler/parse:Parser", ptr %t241, i32 0, i32 23
  store i1 %t242, ptr %t245, !tbaa !21
  %t246 = load ptr, ptr %l83, !tbaa !29
  %t247 = insertvalue { i32, ptr } zeroinitializer, ptr %t246, 1
  store { i32, ptr } %t247, ptr %rv
  br label %ret
bb37:
  %t248 = load ptr, ptr %l0, !tbaa !29
  %t251 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t248, i32 79)
  store i1 %t251, ptr %l111
  br label %bb38
bb38:
  %t252 = load i1, ptr %l111, !tbaa !21
  br i1 %t252, label %bb39, label %bb40
bb39:
  %t253 = load ptr, ptr %l0, !tbaa !29
  %t254 = load ptr, ptr %l1, !tbaa !29
  %t257 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eisQualifiedType(ptr %v0, ptr %v1, ptr %t253, ptr %t254)
  store i1 %t257, ptr %l115
  br label %bb41
bb40:
  store i1 false, ptr %l112, !tbaa !21
  br label %bb46
bb41:
  %t258 = load i1, ptr %l115, !tbaa !21
  br i1 %t258, label %bb42, label %bb43
bb42:
  store i1 true, ptr %l116, !tbaa !21
  br label %bb45
bb43:
  %t259 = load ptr, ptr %l0, !tbaa !29
  %t260 = load ptr, ptr %l1, !tbaa !29
  %t263 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2enamesBareType(ptr %v0, ptr %v1, ptr %t259, ptr %t260)
  store i1 %t263, ptr %l119
  br label %bb44
bb44:
  %t264 = load i1, ptr %l119, !tbaa !21
  store i1 %t264, ptr %l116, !tbaa !21
  br label %bb45
bb45:
  %t265 = load i1, ptr %l116, !tbaa !21
  store i1 %t265, ptr %l112, !tbaa !21
  br label %bb46
bb46:
  %t266 = load i1, ptr %l112, !tbaa !21
  br i1 %t266, label %bb47, label %bb48
bb47:
  %t267 = load ptr, ptr %l0, !tbaa !29
  %t269 = getelementptr %"compiler/parse:Parser", ptr %t267, i32 0, i32 34
  %t271 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2eLen_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %t269)
  store i64 %t271, ptr %l122
  br label %bb49
bb48:
  br label %bb78
bb49:
  %t272 = load i64, ptr %l122, !tbaa !24
  store i64 %t272, ptr %l8, !tbaa !24
  %t273 = load ptr, ptr %l0, !tbaa !29
  %t275 = getelementptr %"compiler/parse:Parser", ptr %t273, i32 0, i32 34
  store ptr %t275, ptr %l124, !tbaa !29
  %t276 = load ptr, ptr %l0, !tbaa !29
  %t277 = load ptr, ptr %l6, !tbaa !29
  %t280 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eentry(ptr %v0, ptr %v2, ptr %v0, ptr %t276, ptr %t277)
  %t281 = extractvalue { i32, ptr } %t280, 1
  %t282 = extractvalue { i32, ptr } %t280, 0
  store i32 %t282, ptr %l129
  %t283 = icmp ne i32 %t282, 0
  br i1 %t283, label %bb51, label %ok.284, !prof !99
ok.284:
  store ptr %t281, ptr %l128
  br label %bb50
bb50:
  %t285 = load ptr, ptr %l128, !tbaa !29
  store ptr %t285, ptr %l125, !tbaa !29
  br label %bb52
bb51:
  %t286 = load i32, ptr %l129, !tbaa !23
  %t287 = lshr i32 %t286, 16
  %t288 = and i32 %t286, 65535
  %t289 = icmp eq i32 %t287, 1
  %t290 = select i1 %t289, i32 1, i32 0
  %t291 = icmp eq i32 %t286, 0
  %t292 = shl i32 %t290, 16
  %t293 = or i32 %t292, %t288
  %t294 = select i1 %t291, i32 0, i32 %t293
  %t295 = load ptr, ptr %l0, !tbaa !29
  store ptr %t295, ptr %l131, !tbaa !29
  %t296 = load ptr, ptr %l131, !tbaa !29
  %t297 = getelementptr %"compiler/parse:Parser", ptr %t296, i32 0, i32 21
  %t298 = load i64, ptr %t297, !tbaa !24
  %t301 = sub i64 %t298, 1
  %t303 = load ptr, ptr %l131, !tbaa !29
  %t304 = getelementptr %"compiler/parse:Parser", ptr %t303, i32 0, i32 21
  store i64 %t301, ptr %t304, !tbaa !24
  %t305 = load ptr, ptr %l0, !tbaa !29
  %t306 = load i1, ptr %l4, !tbaa !21
  %t309 = getelementptr %"compiler/parse:Parser", ptr %t305, i32 0, i32 11
  store i1 %t306, ptr %t309, !tbaa !21
  %t310 = load ptr, ptr %l0, !tbaa !29
  %t311 = load i1, ptr %l5, !tbaa !21
  %t314 = getelementptr %"compiler/parse:Parser", ptr %t310, i32 0, i32 23
  store i1 %t311, ptr %t314, !tbaa !21
  %t316 = insertvalue { i32, ptr } zeroinitializer, i32 %t294, 0
  store { i32, ptr } %t316, ptr %rv
  br label %ret
bb52:
  %t317 = load ptr, ptr %l124, !tbaa !29
  %t318 = load ptr, ptr %l125, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2ePush_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t317, ptr %t318)
  br label %bb53
bb53:
  br label %bb54
bb54:
  %t319 = load ptr, ptr %l0, !tbaa !29
  %t322 = call { i32, i1 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2esep(ptr %v0, ptr %t319, i32 113)
  %t323 = extractvalue { i32, i1 } %t322, 1
  %t324 = extractvalue { i32, i1 } %t322, 0
  store i32 %t324, ptr %l143
  %t325 = icmp ne i32 %t324, 0
  br i1 %t325, label %bb56, label %ok.326, !prof !99
ok.326:
  store i1 %t323, ptr %l142
  br label %bb55
bb55:
  %t327 = load i1, ptr %l142, !tbaa !21
  store i1 %t327, ptr %l139, !tbaa !21
  br label %bb57
bb56:
  %t328 = load i32, ptr %l143, !tbaa !23
  %t329 = lshr i32 %t328, 16
  %t330 = and i32 %t328, 65535
  %t331 = icmp eq i32 %t329, 1
  %t332 = select i1 %t331, i32 1, i32 0
  %t333 = icmp eq i32 %t328, 0
  %t334 = shl i32 %t332, 16
  %t335 = or i32 %t334, %t330
  %t336 = select i1 %t333, i32 0, i32 %t335
  %t337 = load ptr, ptr %l0, !tbaa !29
  store ptr %t337, ptr %l145, !tbaa !29
  %t338 = load ptr, ptr %l145, !tbaa !29
  %t339 = getelementptr %"compiler/parse:Parser", ptr %t338, i32 0, i32 21
  %t340 = load i64, ptr %t339, !tbaa !24
  %t343 = sub i64 %t340, 1
  %t345 = load ptr, ptr %l145, !tbaa !29
  %t346 = getelementptr %"compiler/parse:Parser", ptr %t345, i32 0, i32 21
  store i64 %t343, ptr %t346, !tbaa !24
  %t347 = load ptr, ptr %l0, !tbaa !29
  %t348 = load i1, ptr %l4, !tbaa !21
  %t351 = getelementptr %"compiler/parse:Parser", ptr %t347, i32 0, i32 11
  store i1 %t348, ptr %t351, !tbaa !21
  %t352 = load ptr, ptr %l0, !tbaa !29
  %t353 = load i1, ptr %l5, !tbaa !21
  %t356 = getelementptr %"compiler/parse:Parser", ptr %t352, i32 0, i32 23
  store i1 %t353, ptr %t356, !tbaa !21
  %t358 = insertvalue { i32, ptr } zeroinitializer, i32 %t336, 0
  store { i32, ptr } %t358, ptr %rv
  br label %ret
bb57:
  %t359 = load i1, ptr %l139, !tbaa !21
  %t360 = xor i1 %t359, true
  br i1 %t360, label %bb58, label %bb59
bb58:
  br label %bb69
bb59:
  br label %bb60
bb60:
  %t362 = load ptr, ptr %l0, !tbaa !29
  %t364 = getelementptr %"compiler/parse:Parser", ptr %t362, i32 0, i32 34
  store ptr %t364, ptr %l155, !tbaa !29
  %t365 = load ptr, ptr %l0, !tbaa !29
  store ptr %t365, ptr %l157, !tbaa !29
  %t366 = load ptr, ptr %l0, !tbaa !29
  %t368 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eelem(ptr %v0, ptr %v0, ptr %t366)
  %t369 = extractvalue { i32, ptr } %t368, 1
  %t370 = extractvalue { i32, ptr } %t368, 0
  store i32 %t370, ptr %l161
  %t371 = icmp ne i32 %t370, 0
  br i1 %t371, label %bb62, label %ok.372, !prof !99
ok.372:
  store ptr %t369, ptr %l160
  br label %bb61
bb61:
  %t373 = load ptr, ptr %l160, !tbaa !29
  store ptr %t373, ptr %l158, !tbaa !29
  br label %bb63
bb62:
  %t374 = load i32, ptr %l161, !tbaa !23
  %t375 = lshr i32 %t374, 16
  %t376 = and i32 %t374, 65535
  %t377 = icmp eq i32 %t375, 1
  %t378 = select i1 %t377, i32 1, i32 0
  %t379 = icmp eq i32 %t374, 0
  %t380 = shl i32 %t378, 16
  %t381 = or i32 %t380, %t376
  %t382 = select i1 %t379, i32 0, i32 %t381
  %t383 = load ptr, ptr %l0, !tbaa !29
  store ptr %t383, ptr %l163, !tbaa !29
  %t384 = load ptr, ptr %l163, !tbaa !29
  %t385 = getelementptr %"compiler/parse:Parser", ptr %t384, i32 0, i32 21
  %t386 = load i64, ptr %t385, !tbaa !24
  %t389 = sub i64 %t386, 1
  %t391 = load ptr, ptr %l163, !tbaa !29
  %t392 = getelementptr %"compiler/parse:Parser", ptr %t391, i32 0, i32 21
  store i64 %t389, ptr %t392, !tbaa !24
  %t393 = load ptr, ptr %l0, !tbaa !29
  %t394 = load i1, ptr %l4, !tbaa !21
  %t397 = getelementptr %"compiler/parse:Parser", ptr %t393, i32 0, i32 11
  store i1 %t394, ptr %t397, !tbaa !21
  %t398 = load ptr, ptr %l0, !tbaa !29
  %t399 = load i1, ptr %l5, !tbaa !21
  %t402 = getelementptr %"compiler/parse:Parser", ptr %t398, i32 0, i32 23
  store i1 %t399, ptr %t402, !tbaa !21
  %t404 = insertvalue { i32, ptr } zeroinitializer, i32 %t382, 0
  store { i32, ptr } %t404, ptr %rv
  br label %ret
bb63:
  %t405 = load ptr, ptr %l157, !tbaa !29
  %t406 = load ptr, ptr %l158, !tbaa !29
  %t407 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eentry(ptr %v0, ptr %v0, ptr %v0, ptr %t405, ptr %t406)
  %t408 = extractvalue { i32, ptr } %t407, 1
  %t409 = extractvalue { i32, ptr } %t407, 0
  store i32 %t409, ptr %l172
  %t410 = icmp ne i32 %t409, 0
  br i1 %t410, label %bb65, label %ok.411, !prof !99
ok.411:
  store ptr %t408, ptr %l171
  br label %bb64
bb64:
  %t412 = load ptr, ptr %l171, !tbaa !29
  store ptr %t412, ptr %l156, !tbaa !29
  br label %bb66
bb65:
  %t413 = load i32, ptr %l172, !tbaa !23
  %t414 = lshr i32 %t413, 16
  %t415 = and i32 %t413, 65535
  %t416 = icmp eq i32 %t414, 1
  %t417 = select i1 %t416, i32 1, i32 0
  %t418 = icmp eq i32 %t413, 0
  %t419 = shl i32 %t417, 16
  %t420 = or i32 %t419, %t415
  %t421 = select i1 %t418, i32 0, i32 %t420
  %t422 = load ptr, ptr %l0, !tbaa !29
  store ptr %t422, ptr %l174, !tbaa !29
  %t423 = load ptr, ptr %l174, !tbaa !29
  %t424 = getelementptr %"compiler/parse:Parser", ptr %t423, i32 0, i32 21
  %t425 = load i64, ptr %t424, !tbaa !24
  %t428 = sub i64 %t425, 1
  %t430 = load ptr, ptr %l174, !tbaa !29
  %t431 = getelementptr %"compiler/parse:Parser", ptr %t430, i32 0, i32 21
  store i64 %t428, ptr %t431, !tbaa !24
  %t432 = load ptr, ptr %l0, !tbaa !29
  %t433 = load i1, ptr %l4, !tbaa !21
  %t436 = getelementptr %"compiler/parse:Parser", ptr %t432, i32 0, i32 11
  store i1 %t433, ptr %t436, !tbaa !21
  %t437 = load ptr, ptr %l0, !tbaa !29
  %t438 = load i1, ptr %l5, !tbaa !21
  %t441 = getelementptr %"compiler/parse:Parser", ptr %t437, i32 0, i32 23
  store i1 %t438, ptr %t441, !tbaa !21
  %t443 = insertvalue { i32, ptr } zeroinitializer, i32 %t421, 0
  store { i32, ptr } %t443, ptr %rv
  br label %ret
bb66:
  %t444 = load ptr, ptr %l155, !tbaa !29
  %t445 = load ptr, ptr %l156, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2ePush_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t444, ptr %t445)
  br label %bb67
bb67:
  br label %bb68
bb68:
  br label %bb54
bb69:
  %t446 = load ptr, ptr %l0, !tbaa !29
  %t449 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %t446, i32 113)
  %t450 = extractvalue { i32, i32 } %t449, 1
  %t451 = extractvalue { i32, i32 } %t449, 0
  store i32 %t451, ptr %l186
  %t452 = icmp ne i32 %t451, 0
  br i1 %t452, label %bb71, label %ok.453, !prof !99
ok.453:
  store i32 %t450, ptr %l185
  br label %bb70
bb70:
  %t454 = load i32, ptr %l185, !tbaa !23
  store i32 %t454, ptr %l182, !tbaa !23
  br label %bb72
bb71:
  %t455 = load i32, ptr %l186, !tbaa !23
  %t456 = lshr i32 %t455, 16
  %t457 = and i32 %t455, 65535
  %t458 = icmp eq i32 %t456, 1
  %t459 = select i1 %t458, i32 1, i32 0
  %t460 = icmp eq i32 %t455, 0
  %t461 = shl i32 %t459, 16
  %t462 = or i32 %t461, %t457
  %t463 = select i1 %t460, i32 0, i32 %t462
  %t464 = load ptr, ptr %l0, !tbaa !29
  store ptr %t464, ptr %l188, !tbaa !29
  %t465 = load ptr, ptr %l188, !tbaa !29
  %t466 = getelementptr %"compiler/parse:Parser", ptr %t465, i32 0, i32 21
  %t467 = load i64, ptr %t466, !tbaa !24
  %t470 = sub i64 %t467, 1
  %t472 = load ptr, ptr %l188, !tbaa !29
  %t473 = getelementptr %"compiler/parse:Parser", ptr %t472, i32 0, i32 21
  store i64 %t470, ptr %t473, !tbaa !24
  %t474 = load ptr, ptr %l0, !tbaa !29
  %t475 = load i1, ptr %l4, !tbaa !21
  %t478 = getelementptr %"compiler/parse:Parser", ptr %t474, i32 0, i32 11
  store i1 %t475, ptr %t478, !tbaa !21
  %t479 = load ptr, ptr %l0, !tbaa !29
  %t480 = load i1, ptr %l5, !tbaa !21
  %t483 = getelementptr %"compiler/parse:Parser", ptr %t479, i32 0, i32 23
  store i1 %t480, ptr %t483, !tbaa !21
  %t485 = insertvalue { i32, ptr } zeroinitializer, i32 %t463, 0
  store { i32, ptr } %t485, ptr %rv
  br label %ret
bb72:
  %t486 = load ptr, ptr %l0, !tbaa !29
  %t487 = load i32, ptr %l2, !tbaa !23
  %t490 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t486, i32 %t487)
  store %"compiler/source:Span" %t490, ptr %l198
  br label %bb73
bb73:
  %t491 = load ptr, ptr %l0, !tbaa !29
  %t492 = load ptr, ptr %l1, !tbaa !29
  %t495 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexprAsType(ptr %v0, ptr %v1, ptr %v2, ptr %t491, ptr %t492)
  %t496 = extractvalue { i32, ptr } %t495, 1
  %t497 = extractvalue { i32, ptr } %t495, 0
  store i32 %t497, ptr %l203
  %t498 = icmp ne i32 %t497, 0
  br i1 %t498, label %bb75, label %ok.499, !prof !99
ok.499:
  store ptr %t496, ptr %l202
  br label %bb74
bb74:
  %t500 = load ptr, ptr %l202, !tbaa !29
  store ptr %t500, ptr %l199, !tbaa !29
  br label %bb76
bb75:
  %t501 = load i32, ptr %l203, !tbaa !23
  %t502 = lshr i32 %t501, 16
  %t503 = and i32 %t501, 65535
  %t504 = icmp eq i32 %t502, 1
  %t505 = select i1 %t504, i32 1, i32 0
  %t506 = icmp eq i32 %t501, 0
  %t507 = shl i32 %t505, 16
  %t508 = or i32 %t507, %t503
  %t509 = select i1 %t506, i32 0, i32 %t508
  %t510 = load ptr, ptr %l0, !tbaa !29
  store ptr %t510, ptr %l205, !tbaa !29
  %t511 = load ptr, ptr %l205, !tbaa !29
  %t512 = getelementptr %"compiler/parse:Parser", ptr %t511, i32 0, i32 21
  %t513 = load i64, ptr %t512, !tbaa !24
  %t516 = sub i64 %t513, 1
  %t518 = load ptr, ptr %l205, !tbaa !29
  %t519 = getelementptr %"compiler/parse:Parser", ptr %t518, i32 0, i32 21
  store i64 %t516, ptr %t519, !tbaa !24
  %t520 = load ptr, ptr %l0, !tbaa !29
  %t521 = load i1, ptr %l4, !tbaa !21
  %t524 = getelementptr %"compiler/parse:Parser", ptr %t520, i32 0, i32 11
  store i1 %t521, ptr %t524, !tbaa !21
  %t525 = load ptr, ptr %l0, !tbaa !29
  %t526 = load i1, ptr %l5, !tbaa !21
  %t529 = getelementptr %"compiler/parse:Parser", ptr %t525, i32 0, i32 23
  store i1 %t526, ptr %t529, !tbaa !21
  %t531 = insertvalue { i32, ptr } zeroinitializer, i32 %t509, 0
  store { i32, ptr } %t531, ptr %rv
  br label %ret
bb76:
  %t532 = load ptr, ptr %l199, !tbaa !29
  store ptr %t532, ptr %l213, !tbaa !29
  %t533 = load ptr, ptr %l0, !tbaa !29
  %t535 = getelementptr %"compiler/parse:Parser", ptr %t533, i32 0, i32 34
  %t536 = load i64, ptr %l8, !tbaa !24
  %t539 = call { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %v2, ptr %t535, i64 %t536)
  store { i64, ptr } %t539, ptr %l217
  br label %bb77
bb77:
  store { i64, [4 x i64] } zeroinitializer, ptr %t540
  %t541 = getelementptr { i64, [4 x i64] }, ptr %t540, i32 0, i32 0
  store i64 16, ptr %t541
  %t542 = load %"compiler/source:Span", ptr %l198
  %t543 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } undef, %"compiler/source:Span" %t542, 0
  %t544 = load ptr, ptr %l213, !tbaa !29
  %t545 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } %t543, ptr %t544, 1
  %t546 = load { i64, ptr }, ptr %l217, !tbaa !27
  %t547 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } %t545, { i64, ptr } %t546, 2
  %t548 = getelementptr { i64, [4 x i64] }, ptr %t540, i32 0, i32 1
  store { %"compiler/source:Span", ptr, { i64, ptr } } %t547, ptr %t548
  %t549 = load { i64, [4 x i64] }, ptr %t540
  %t551 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 40, i64 8)
  store { i64, [4 x i64] } %t549, ptr %t551
  %t552 = load ptr, ptr %l0, !tbaa !29
  store ptr %t552, ptr %l220, !tbaa !29
  %t553 = load ptr, ptr %l220, !tbaa !29
  %t554 = getelementptr %"compiler/parse:Parser", ptr %t553, i32 0, i32 21
  %t555 = load i64, ptr %t554, !tbaa !24
  %t558 = sub i64 %t555, 1
  %t560 = load ptr, ptr %l220, !tbaa !29
  %t561 = getelementptr %"compiler/parse:Parser", ptr %t560, i32 0, i32 21
  store i64 %t558, ptr %t561, !tbaa !24
  %t562 = load ptr, ptr %l0, !tbaa !29
  %t563 = load i1, ptr %l4, !tbaa !21
  %t566 = getelementptr %"compiler/parse:Parser", ptr %t562, i32 0, i32 11
  store i1 %t563, ptr %t566, !tbaa !21
  %t567 = load ptr, ptr %l0, !tbaa !29
  %t568 = load i1, ptr %l5, !tbaa !21
  %t571 = getelementptr %"compiler/parse:Parser", ptr %t567, i32 0, i32 23
  store i1 %t568, ptr %t571, !tbaa !21
  %t573 = insertvalue { i32, ptr } zeroinitializer, ptr %t551, 1
  store { i32, ptr } %t573, ptr %rv
  br label %ret
bb78:
  br label %bb79
bb79:
  %t574 = load ptr, ptr %l0, !tbaa !29
  %t576 = getelementptr %"compiler/parse:Parser", ptr %t574, i32 0, i32 46
  %t577 = load i64, ptr %l3, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t576, i64 %t577)
  br label %bb80
bb80:
  %t580 = load ptr, ptr %l0, !tbaa !29
  store ptr %t580, ptr %l232, !tbaa !29
  %t581 = load ptr, ptr %l6, !tbaa !29
  %t583 = icmp eq ptr %t581, null
  br i1 %t583, label %bb81, label %bb82
bb81:
  %t585 = load ptr, ptr %l0, !tbaa !29
  %t587 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ehere(ptr %v0, ptr %t585)
  store i32 %t587, ptr %l237
  br label %bb83
bb82:
  %t588 = load ptr, ptr %l6, !tbaa !29
  %t590 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t588)
  store %"compiler/source:Span" %t590, ptr %l239
  br label %bb84
bb83:
  %t591 = load i32, ptr %l237, !tbaa !23
  store i32 %t591, ptr %l235, !tbaa !23
  br label %bb85
bb84:
  %t592 = getelementptr %"compiler/source:Span", ptr %l239, i32 0, i32 0
  %t593 = load i32, ptr %t592, !tbaa !23
  store i32 %t593, ptr %l235, !tbaa !23
  br label %bb85
bb85:
  %t595 = load ptr, ptr %l6, !tbaa !29
  %t596 = load ptr, ptr %l232, !tbaa !29
  %t597 = load i32, ptr %l235, !tbaa !23
  %t599 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaxisItem(ptr %v0, ptr %v2, ptr %v2, ptr %t596, i32 %t597, ptr %t595)
  %t600 = extractvalue { i32, ptr } %t599, 1
  %t601 = extractvalue { i32, ptr } %t599, 0
  store i32 %t601, ptr %l243
  %t602 = icmp ne i32 %t601, 0
  br i1 %t602, label %bb87, label %ok.603, !prof !99
ok.603:
  store ptr %t600, ptr %l242
  br label %bb86
bb86:
  %t604 = load ptr, ptr %l242, !tbaa !29
  store ptr %t604, ptr %l231, !tbaa !29
  br label %bb88
bb87:
  %t605 = load i32, ptr %l243, !tbaa !23
  %t606 = lshr i32 %t605, 16
  %t607 = and i32 %t605, 65535
  %t608 = icmp eq i32 %t606, 1
  %t609 = select i1 %t608, i32 1, i32 0
  %t610 = icmp eq i32 %t605, 0
  %t611 = shl i32 %t609, 16
  %t612 = or i32 %t611, %t607
  %t613 = select i1 %t610, i32 0, i32 %t612
  %t614 = load ptr, ptr %l0, !tbaa !29
  store ptr %t614, ptr %l245, !tbaa !29
  %t615 = load ptr, ptr %l245, !tbaa !29
  %t616 = getelementptr %"compiler/parse:Parser", ptr %t615, i32 0, i32 21
  %t617 = load i64, ptr %t616, !tbaa !24
  %t620 = sub i64 %t617, 1
  %t622 = load ptr, ptr %l245, !tbaa !29
  %t623 = getelementptr %"compiler/parse:Parser", ptr %t622, i32 0, i32 21
  store i64 %t620, ptr %t623, !tbaa !24
  %t624 = load ptr, ptr %l0, !tbaa !29
  %t625 = load i1, ptr %l4, !tbaa !21
  %t628 = getelementptr %"compiler/parse:Parser", ptr %t624, i32 0, i32 11
  store i1 %t625, ptr %t628, !tbaa !21
  %t629 = load ptr, ptr %l0, !tbaa !29
  %t630 = load i1, ptr %l5, !tbaa !21
  %t633 = getelementptr %"compiler/parse:Parser", ptr %t629, i32 0, i32 23
  store i1 %t630, ptr %t633, !tbaa !21
  %t635 = insertvalue { i32, ptr } zeroinitializer, i32 %t613, 0
  store { i32, ptr } %t635, ptr %rv
  br label %ret
bb88:
  %t636 = load ptr, ptr %l231, !tbaa !29
  store ptr %t636, ptr %l9, !tbaa !29
  %t637 = load ptr, ptr %l0, !tbaa !29
  %t640 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t637, i32 113)
  store i1 %t640, ptr %l255
  br label %bb89
bb89:
  %t641 = load i1, ptr %l255, !tbaa !21
  br i1 %t641, label %bb90, label %bb91
bb90:
  %t642 = load ptr, ptr %l9, !tbaa !29
  %t644 = call i1 @compiler_2fparse_2eisAxis(ptr %v2, ptr %t642)
  store i1 %t644, ptr %l258
  br label %bb92
bb91:
  store i1 false, ptr %l256, !tbaa !21
  br label %bb93
bb92:
  %t645 = load i1, ptr %l258, !tbaa !21
  store i1 %t645, ptr %l256, !tbaa !21
  br label %bb93
bb93:
  %t646 = load i1, ptr %l256, !tbaa !21
  br i1 %t646, label %bb94, label %bb95
bb94:
  %t647 = load ptr, ptr %l0, !tbaa !29
  %t649 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t647)
  store i32 %t649, ptr %l260
  br label %bb96
bb95:
  br label %bb99
bb96:
  %t650 = load ptr, ptr %l0, !tbaa !29
  %t651 = load i32, ptr %l2, !tbaa !23
  %t654 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t650, i32 %t651)
  store %"compiler/source:Span" %t654, ptr %l263
  br label %bb97
bb97:
  %t655 = load ptr, ptr %l1, !tbaa !29
  %t656 = load ptr, ptr %l9, !tbaa !29
  %t657 = load %"compiler/source:Span", ptr %l263
  %t660 = call ptr @compiler_2fparse_2eaxisSlice(ptr %v1, ptr %v2, ptr %v2, %"compiler/source:Span" %t657, ptr %t655, ptr %t656)
  store ptr %t660, ptr %l266
  br label %bb98
bb98:
  %t661 = load ptr, ptr %l0, !tbaa !29
  store ptr %t661, ptr %l267, !tbaa !29
  %t662 = load ptr, ptr %l267, !tbaa !29
  %t663 = getelementptr %"compiler/parse:Parser", ptr %t662, i32 0, i32 21
  %t664 = load i64, ptr %t663, !tbaa !24
  %t667 = sub i64 %t664, 1
  %t669 = load ptr, ptr %l267, !tbaa !29
  %t670 = getelementptr %"compiler/parse:Parser", ptr %t669, i32 0, i32 21
  store i64 %t667, ptr %t670, !tbaa !24
  %t671 = load ptr, ptr %l0, !tbaa !29
  %t672 = load i1, ptr %l4, !tbaa !21
  %t675 = getelementptr %"compiler/parse:Parser", ptr %t671, i32 0, i32 11
  store i1 %t672, ptr %t675, !tbaa !21
  %t676 = load ptr, ptr %l0, !tbaa !29
  %t677 = load i1, ptr %l5, !tbaa !21
  %t680 = getelementptr %"compiler/parse:Parser", ptr %t676, i32 0, i32 23
  store i1 %t677, ptr %t680, !tbaa !21
  %t681 = load ptr, ptr %l266, !tbaa !29
  %t682 = insertvalue { i32, ptr } zeroinitializer, ptr %t681, 1
  store { i32, ptr } %t682, ptr %rv
  br label %ret
bb99:
  %t683 = load ptr, ptr %l0, !tbaa !29
  %t685 = getelementptr %"compiler/parse:Parser", ptr %t683, i32 0, i32 34
  %t687 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2eLen_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %t685)
  store i64 %t687, ptr %l277
  br label %bb100
bb100:
  %t688 = load i64, ptr %l277, !tbaa !24
  store i64 %t688, ptr %l10, !tbaa !24
  %t689 = load ptr, ptr %l0, !tbaa !29
  %t691 = getelementptr %"compiler/parse:Parser", ptr %t689, i32 0, i32 34
  %t692 = load ptr, ptr %l9, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2ePush_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %v2, ptr %t691, ptr %t692)
  br label %bb101
bb101:
  br label %bb102
bb102:
  %t695 = load ptr, ptr %l0, !tbaa !29
  %t698 = call { i32, i1 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2esep(ptr %v0, ptr %t695, i32 113)
  %t699 = extractvalue { i32, i1 } %t698, 1
  %t700 = extractvalue { i32, i1 } %t698, 0
  store i32 %t700, ptr %l285
  %t701 = icmp ne i32 %t700, 0
  br i1 %t701, label %bb104, label %ok.702, !prof !99
ok.702:
  store i1 %t699, ptr %l284
  br label %bb103
bb103:
  %t703 = load i1, ptr %l284, !tbaa !21
  store i1 %t703, ptr %l281, !tbaa !21
  br label %bb105
bb104:
  %t704 = load i32, ptr %l285, !tbaa !23
  %t705 = lshr i32 %t704, 16
  %t706 = and i32 %t704, 65535
  %t707 = icmp eq i32 %t705, 1
  %t708 = select i1 %t707, i32 1, i32 0
  %t709 = icmp eq i32 %t704, 0
  %t710 = shl i32 %t708, 16
  %t711 = or i32 %t710, %t706
  %t712 = select i1 %t709, i32 0, i32 %t711
  %t713 = load ptr, ptr %l0, !tbaa !29
  store ptr %t713, ptr %l287, !tbaa !29
  %t714 = load ptr, ptr %l287, !tbaa !29
  %t715 = getelementptr %"compiler/parse:Parser", ptr %t714, i32 0, i32 21
  %t716 = load i64, ptr %t715, !tbaa !24
  %t719 = sub i64 %t716, 1
  %t721 = load ptr, ptr %l287, !tbaa !29
  %t722 = getelementptr %"compiler/parse:Parser", ptr %t721, i32 0, i32 21
  store i64 %t719, ptr %t722, !tbaa !24
  %t723 = load ptr, ptr %l0, !tbaa !29
  %t724 = load i1, ptr %l4, !tbaa !21
  %t727 = getelementptr %"compiler/parse:Parser", ptr %t723, i32 0, i32 11
  store i1 %t724, ptr %t727, !tbaa !21
  %t728 = load ptr, ptr %l0, !tbaa !29
  %t729 = load i1, ptr %l5, !tbaa !21
  %t732 = getelementptr %"compiler/parse:Parser", ptr %t728, i32 0, i32 23
  store i1 %t729, ptr %t732, !tbaa !21
  %t734 = insertvalue { i32, ptr } zeroinitializer, i32 %t712, 0
  store { i32, ptr } %t734, ptr %rv
  br label %ret
bb105:
  %t735 = load i1, ptr %l281, !tbaa !21
  %t736 = xor i1 %t735, true
  br i1 %t736, label %bb106, label %bb107
bb106:
  br label %bb114
bb107:
  br label %bb108
bb108:
  %t738 = load ptr, ptr %l0, !tbaa !29
  %t740 = getelementptr %"compiler/parse:Parser", ptr %t738, i32 0, i32 34
  store ptr %t740, ptr %l297, !tbaa !29
  %t741 = load ptr, ptr %l0, !tbaa !29
  %t743 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2esubItem(ptr %v0, ptr %v0, ptr %t741)
  %t744 = extractvalue { i32, ptr } %t743, 1
  %t745 = extractvalue { i32, ptr } %t743, 0
  store i32 %t745, ptr %l301
  %t746 = icmp ne i32 %t745, 0
  br i1 %t746, label %bb110, label %ok.747, !prof !99
ok.747:
  store ptr %t744, ptr %l300
  br label %bb109
bb109:
  %t748 = load ptr, ptr %l300, !tbaa !29
  store ptr %t748, ptr %l298, !tbaa !29
  br label %bb111
bb110:
  %t749 = load i32, ptr %l301, !tbaa !23
  %t750 = lshr i32 %t749, 16
  %t751 = and i32 %t749, 65535
  %t752 = icmp eq i32 %t750, 1
  %t753 = select i1 %t752, i32 1, i32 0
  %t754 = icmp eq i32 %t749, 0
  %t755 = shl i32 %t753, 16
  %t756 = or i32 %t755, %t751
  %t757 = select i1 %t754, i32 0, i32 %t756
  %t758 = load ptr, ptr %l0, !tbaa !29
  store ptr %t758, ptr %l303, !tbaa !29
  %t759 = load ptr, ptr %l303, !tbaa !29
  %t760 = getelementptr %"compiler/parse:Parser", ptr %t759, i32 0, i32 21
  %t761 = load i64, ptr %t760, !tbaa !24
  %t764 = sub i64 %t761, 1
  %t766 = load ptr, ptr %l303, !tbaa !29
  %t767 = getelementptr %"compiler/parse:Parser", ptr %t766, i32 0, i32 21
  store i64 %t764, ptr %t767, !tbaa !24
  %t768 = load ptr, ptr %l0, !tbaa !29
  %t769 = load i1, ptr %l4, !tbaa !21
  %t772 = getelementptr %"compiler/parse:Parser", ptr %t768, i32 0, i32 11
  store i1 %t769, ptr %t772, !tbaa !21
  %t773 = load ptr, ptr %l0, !tbaa !29
  %t774 = load i1, ptr %l5, !tbaa !21
  %t777 = getelementptr %"compiler/parse:Parser", ptr %t773, i32 0, i32 23
  store i1 %t774, ptr %t777, !tbaa !21
  %t779 = insertvalue { i32, ptr } zeroinitializer, i32 %t757, 0
  store { i32, ptr } %t779, ptr %rv
  br label %ret
bb111:
  %t780 = load ptr, ptr %l297, !tbaa !29
  %t781 = load ptr, ptr %l298, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2ePush_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t780, ptr %t781)
  br label %bb112
bb112:
  br label %bb113
bb113:
  br label %bb102
bb114:
  %t782 = load ptr, ptr %l0, !tbaa !29
  %t785 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t782, i32 113)
  store i1 %t785, ptr %l313
  br label %bb115
bb115:
  %t786 = load i1, ptr %l313, !tbaa !21
  %t787 = xor i1 %t786, true
  br i1 %t787, label %bb116, label %bb117
bb116:
  store %olang.scope zeroinitializer, ptr %s39
  %t789 = load ptr, ptr %l0, !tbaa !29
  %t791 = getelementptr %"compiler/parse:Parser", ptr %t789, i32 0, i32 34
  %t792 = load i64, ptr %l10, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2eTruncate_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %t791, i64 %t792)
  br label %bb118
bb117:
  br label %bb123
bb118:
  %t795 = load ptr, ptr %l0, !tbaa !29
  store ptr %t795, ptr %l318, !tbaa !29
  %t797 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eDescribe(ptr %s39, i32 113)
  store { i64, ptr } %t797, ptr %l320
  br label %bb119
bb119:
  %t798 = load { i64, ptr }, ptr %l320, !tbaa !27
  %t799 = load ptr, ptr %l318, !tbaa !29
  %t801 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2efail(ptr %v0, ptr %s39, ptr %t799, { i64, ptr } %t798)
  store i32 %t801, ptr %l322
  %t802 = icmp ne i32 %t801, 0
  br i1 %t802, label %bb121, label %ok.803, !prof !99
ok.803:
  br label %bb120
bb120:
  br label %bb122
bb121:
  %t804 = load i32, ptr %l322, !tbaa !23
  %t805 = lshr i32 %t804, 16
  %t806 = and i32 %t804, 65535
  %t807 = icmp eq i32 %t805, 1
  %t808 = select i1 %t807, i32 1, i32 0
  %t809 = icmp eq i32 %t804, 0
  %t810 = shl i32 %t808, 16
  %t811 = or i32 %t810, %t806
  %t812 = select i1 %t809, i32 0, i32 %t811
  call void @__olang_scope_close(ptr %s39)
  %t813 = load ptr, ptr %l0, !tbaa !29
  store ptr %t813, ptr %l324, !tbaa !29
  %t814 = load ptr, ptr %l324, !tbaa !29
  %t815 = getelementptr %"compiler/parse:Parser", ptr %t814, i32 0, i32 21
  %t816 = load i64, ptr %t815, !tbaa !24
  %t819 = sub i64 %t816, 1
  %t821 = load ptr, ptr %l324, !tbaa !29
  %t822 = getelementptr %"compiler/parse:Parser", ptr %t821, i32 0, i32 21
  store i64 %t819, ptr %t822, !tbaa !24
  %t823 = load ptr, ptr %l0, !tbaa !29
  %t824 = load i1, ptr %l4, !tbaa !21
  %t827 = getelementptr %"compiler/parse:Parser", ptr %t823, i32 0, i32 11
  store i1 %t824, ptr %t827, !tbaa !21
  %t828 = load ptr, ptr %l0, !tbaa !29
  %t829 = load i1, ptr %l5, !tbaa !21
  %t832 = getelementptr %"compiler/parse:Parser", ptr %t828, i32 0, i32 23
  store i1 %t829, ptr %t832, !tbaa !21
  %t834 = insertvalue { i32, ptr } zeroinitializer, i32 %t812, 0
  store { i32, ptr } %t834, ptr %rv
  br label %ret
bb122:
  call void @__olang_scope_close(ptr %s39)
  br label %bb123
bb123:
  %t835 = load ptr, ptr %l0, !tbaa !29
  %t837 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t835)
  store i32 %t837, ptr %l333
  br label %bb124
bb124:
  %t838 = load ptr, ptr %l0, !tbaa !29
  %t839 = load i32, ptr %l2, !tbaa !23
  %t842 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t838, i32 %t839)
  store %"compiler/source:Span" %t842, ptr %l336
  br label %bb125
bb125:
  %t843 = load ptr, ptr %l1, !tbaa !29
  store ptr %t843, ptr %l337, !tbaa !29
  %t844 = load ptr, ptr %l0, !tbaa !29
  %t846 = getelementptr %"compiler/parse:Parser", ptr %t844, i32 0, i32 34
  %t847 = load i64, ptr %l10, !tbaa !24
  %t850 = call { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %v2, ptr %t846, i64 %t847)
  store { i64, ptr } %t850, ptr %l341
  br label %bb126
bb126:
  store { i64, [4 x i64] } zeroinitializer, ptr %t851
  %t852 = getelementptr { i64, [4 x i64] }, ptr %t851, i32 0, i32 0
  store i64 13, ptr %t852
  %t853 = load %"compiler/source:Span", ptr %l336
  %t854 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } undef, %"compiler/source:Span" %t853, 0
  %t855 = load ptr, ptr %l337, !tbaa !29
  %t856 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } %t854, ptr %t855, 1
  %t857 = load { i64, ptr }, ptr %l341, !tbaa !27
  %t858 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } %t856, { i64, ptr } %t857, 2
  %t859 = getelementptr { i64, [4 x i64] }, ptr %t851, i32 0, i32 1
  store { %"compiler/source:Span", ptr, { i64, ptr } } %t858, ptr %t859
  %t860 = load { i64, [4 x i64] }, ptr %t851
  %t862 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 40, i64 8)
  store { i64, [4 x i64] } %t860, ptr %t862
  %t863 = load ptr, ptr %l0, !tbaa !29
  store ptr %t863, ptr %l344, !tbaa !29
  %t864 = load ptr, ptr %l344, !tbaa !29
  %t865 = getelementptr %"compiler/parse:Parser", ptr %t864, i32 0, i32 21
  %t866 = load i64, ptr %t865, !tbaa !24
  %t869 = sub i64 %t866, 1
  %t871 = load ptr, ptr %l344, !tbaa !29
  %t872 = getelementptr %"compiler/parse:Parser", ptr %t871, i32 0, i32 21
  store i64 %t869, ptr %t872, !tbaa !24
  %t873 = load ptr, ptr %l0, !tbaa !29
  %t874 = load i1, ptr %l4, !tbaa !21
  %t877 = getelementptr %"compiler/parse:Parser", ptr %t873, i32 0, i32 11
  store i1 %t874, ptr %t877, !tbaa !21
  %t878 = load ptr, ptr %l0, !tbaa !29
  %t879 = load i1, ptr %l5, !tbaa !21
  %t882 = getelementptr %"compiler/parse:Parser", ptr %t878, i32 0, i32 23
  store i1 %t879, ptr %t882, !tbaa !21
  %t884 = insertvalue { i32, ptr } zeroinitializer, ptr %t862, 1
  store { i32, ptr } %t884, ptr %rv
  br label %ret
bb127:
  %t885 = load ptr, ptr %l0, !tbaa !29
  %t887 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t885)
  store i32 %t887, ptr %l353
  br label %bb128
bb128:
  %t888 = load ptr, ptr %l0, !tbaa !29
  %t889 = load i32, ptr %l2, !tbaa !23
  %t892 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t888, i32 %t889)
  store %"compiler/source:Span" %t892, ptr %l356
  br label %bb129
bb129:
  %t893 = load ptr, ptr %l1, !tbaa !29
  store ptr %t893, ptr %l357, !tbaa !29
  %t894 = icmp sge i64 0, 0
  br i1 %t894, label %bb130, label %bb131
bb130:
  %t896 = icmp sle i64 0, 1152921504606846975
  br i1 %t896, label %bb132, label %bb133
bb131:
  call void @__olang_check_failed(ptr @olang_loc_d47f6bac3f0e9478_81eee3bd7c45867c)
  unreachable
bb132:
  %t898 = mul i64 0, 8
  %t899 = insertvalue { i64, ptr } undef, i64 0, 0
  %t900 = insertvalue { i64, ptr } %t899, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, [4 x i64] } zeroinitializer, ptr %t901
  %t902 = getelementptr { i64, [4 x i64] }, ptr %t901, i32 0, i32 0
  store i64 13, ptr %t902
  %t903 = load %"compiler/source:Span", ptr %l356
  %t904 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } undef, %"compiler/source:Span" %t903, 0
  %t905 = load ptr, ptr %l357, !tbaa !29
  %t906 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } %t904, ptr %t905, 1
  %t908 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } %t906, { i64, ptr } %t900, 2
  %t909 = getelementptr { i64, [4 x i64] }, ptr %t901, i32 0, i32 1
  store { %"compiler/source:Span", ptr, { i64, ptr } } %t908, ptr %t909
  %t910 = load { i64, [4 x i64] }, ptr %t901
  %t912 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 40, i64 8)
  store { i64, [4 x i64] } %t910, ptr %t912
  %t913 = load ptr, ptr %l0, !tbaa !29
  store ptr %t913, ptr %l363, !tbaa !29
  %t914 = load ptr, ptr %l363, !tbaa !29
  %t915 = getelementptr %"compiler/parse:Parser", ptr %t914, i32 0, i32 21
  %t916 = load i64, ptr %t915, !tbaa !24
  %t919 = sub i64 %t916, 1
  %t921 = load ptr, ptr %l363, !tbaa !29
  %t922 = getelementptr %"compiler/parse:Parser", ptr %t921, i32 0, i32 21
  store i64 %t919, ptr %t922, !tbaa !24
  %t923 = load ptr, ptr %l0, !tbaa !29
  %t924 = load i1, ptr %l4, !tbaa !21
  %t927 = getelementptr %"compiler/parse:Parser", ptr %t923, i32 0, i32 11
  store i1 %t924, ptr %t927, !tbaa !21
  %t928 = load ptr, ptr %l0, !tbaa !29
  %t929 = load i1, ptr %l5, !tbaa !21
  %t932 = getelementptr %"compiler/parse:Parser", ptr %t928, i32 0, i32 23
  store i1 %t929, ptr %t932, !tbaa !21
  %t934 = insertvalue { i32, ptr } zeroinitializer, ptr %t912, 1
  store { i32, ptr } %t934, ptr %rv
  br label %ret
bb133:
  call void @__olang_check_failed(ptr @olang_loc_d47f6bac3f0e9478_81eee3bd7c45867c)
  unreachable
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local ptr @compiler_2fparse_2ecompiler_2fparse_3aParser_2eitemPattern(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i1
  %l15 = alloca %"compiler/source:Span"
  %l16 = alloca i32
  %l19 = alloca ptr
  %l24 = alloca ptr
  %rv = alloca ptr
  %t35 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 28}
  %t8 = icmp eq i64 %t6, 24
  store i1 %t8, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l2
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [4 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t18, i32 0, i32 1
  %t20 = load i32, ptr %t19
  store i32 %t20, ptr %l3, !tbaa !23
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t24 = getelementptr { i64, [4 x i64] }, ptr %t22, i32 0, i32 1
  %t25 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t24, i32 0, i32 2
  %t26 = load ptr, ptr %t25
  store ptr %t26, ptr %l4, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t28 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t28, ptr %l15
  %t29 = load i32, ptr %l3, !tbaa !23
  store i32 %t29, ptr %l16, !tbaa !23
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t31 = load ptr, ptr %l4, !tbaa !29
  %t34 = call ptr @compiler_2fparse_2ecompiler_2fparse_3aParser_2epattern(ptr %v0, ptr %v1, ptr %v2, ptr %t30, ptr %t31, i1 false)
  store ptr %t34, ptr %l19
  br label %bb6
bb6:
  store { i64, [4 x i64] } zeroinitializer, ptr %t35
  %t36 = getelementptr { i64, [4 x i64] }, ptr %t35, i32 0, i32 0
  store i64 8, ptr %t36
  %t37 = load %"compiler/source:Span", ptr %l15
  %t38 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t37, 0
  %t39 = load i32, ptr %l16, !tbaa !23
  %t40 = insertvalue { %"compiler/source:Span", i32, ptr } %t38, i32 %t39, 1
  %t41 = load ptr, ptr %l19, !tbaa !29
  %t42 = insertvalue { %"compiler/source:Span", i32, ptr } %t40, ptr %t41, 2
  %t43 = getelementptr { i64, [4 x i64] }, ptr %t35, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t42, ptr %t43
  %t44 = load { i64, [4 x i64] }, ptr %t35
  %t46 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 40, i64 8)
  store { i64, [4 x i64] } %t44, ptr %t46
  store ptr %t46, ptr %rv
  br label %ret
bb7:
  br i1 true, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb12
bb10:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t49 = load ptr, ptr %l1, !tbaa !29
  %t52 = call ptr @compiler_2fparse_2ecompiler_2fparse_3aParser_2epattern(ptr %v0, ptr %v1, ptr %v2, ptr %t48, ptr %t49, i1 false)
  store ptr %t52, ptr %l24
  br label %bb11
bb11:
  %t53 = load ptr, ptr %l24, !tbaa !29
  store ptr %t53, ptr %rv
  br label %ret
bb12:
  call void @__olang_check_failed(ptr @olang_loc_5d444e9b92bac566_79a754ee236bef22)
  unreachable
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ejoinRest(ptr %v0, ptr %v1, ptr %a0, i1 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i32
  %l10 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca i32
  %l15 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca i32
  %l22 = alloca i1
  %l24 = alloca i32
  %l28 = alloca %"compiler/ast:JoinS"
  %rv = alloca { i32, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t4 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %t1, i32 14)
  %t5 = extractvalue { i32, i32 } %t4, 1
  %t6 = extractvalue { i32, i32 } %t4, 0
  store i32 %t6, ptr %l8
  %t7 = icmp ne i32 %t6, 0
  br i1 %t7, label %bb2, label %ok.8, !prof !99
ok.8:
  store i32 %t5, ptr %l7
  br label %bb1
bb1:
  %t9 = load i32, ptr %l7, !tbaa !23
  store i32 %t9, ptr %l4, !tbaa !23
  br label %bb3
bb2:
  %t10 = load i32, ptr %l8, !tbaa !23
  %t11 = lshr i32 %t10, 16
  %t12 = and i32 %t10, 65535
  %t13 = icmp eq i32 %t11, 1
  %t14 = select i1 %t13, i32 1, i32 0
  %t15 = icmp eq i32 %t10, 0
  %t16 = shl i32 %t14, 16
  %t17 = or i32 %t16, %t12
  %t18 = select i1 %t15, i32 0, i32 %t17
  %t20 = insertvalue { i32, ptr } zeroinitializer, i32 %t18, 0
  store { i32, ptr } %t20, ptr %rv
  br label %ret
bb3:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ebody(ptr %v0, ptr %v1, ptr %t21)
  %t24 = extractvalue { i32, { i64, ptr } } %t23, 1
  %t25 = extractvalue { i32, { i64, ptr } } %t23, 0
  store i32 %t25, ptr %l13
  %t26 = icmp ne i32 %t25, 0
  br i1 %t26, label %bb5, label %ok.27, !prof !99
ok.27:
  store { i64, ptr } %t24, ptr %l12
  br label %bb4
bb4:
  %t28 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t28, ptr %l10, !tbaa !27
  br label %bb6
bb5:
  %t29 = load i32, ptr %l13, !tbaa !23
  %t30 = lshr i32 %t29, 16
  %t31 = and i32 %t29, 65535
  %t32 = icmp eq i32 %t30, 1
  %t33 = select i1 %t32, i32 1, i32 0
  %t34 = icmp eq i32 %t29, 0
  %t35 = shl i32 %t33, 16
  %t36 = or i32 %t35, %t31
  %t37 = select i1 %t34, i32 0, i32 %t36
  %t39 = insertvalue { i32, ptr } zeroinitializer, i32 %t37, 0
  store { i32, ptr } %t39, ptr %rv
  br label %ret
bb6:
  %t40 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t40, ptr %l2, !tbaa !27
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eclauses(ptr %v0, ptr %v1, ptr %t41, i1 false)
  %t44 = extractvalue { i32, { i64, ptr } } %t43, 1
  %t45 = extractvalue { i32, { i64, ptr } } %t43, 0
  store i32 %t45, ptr %l18
  %t46 = icmp ne i32 %t45, 0
  br i1 %t46, label %bb8, label %ok.47, !prof !99
ok.47:
  store { i64, ptr } %t44, ptr %l17
  br label %bb7
bb7:
  %t48 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t48, ptr %l15, !tbaa !27
  br label %bb9
bb8:
  %t49 = load i32, ptr %l18, !tbaa !23
  %t50 = lshr i32 %t49, 16
  %t51 = and i32 %t49, 65535
  %t52 = icmp eq i32 %t50, 1
  %t53 = select i1 %t52, i32 1, i32 0
  %t54 = icmp eq i32 %t49, 0
  %t55 = shl i32 %t53, 16
  %t56 = or i32 %t55, %t51
  %t57 = select i1 %t54, i32 0, i32 %t56
  %t59 = insertvalue { i32, ptr } zeroinitializer, i32 %t57, 0
  store { i32, ptr } %t59, ptr %rv
  br label %ret
bb9:
  %t60 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t60, ptr %l3, !tbaa !27
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t64 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t61, i32 8)
  store i1 %t64, ptr %l22
  br label %bb10
bb10:
  %t65 = load i1, ptr %l22, !tbaa !21
  br i1 %t65, label %bb11, label %bb12
bb11:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t66)
  store i32 %t68, ptr %l24
  br label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb14
bb14:
  %t70 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t71 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t75 = call %"compiler/ast:JoinS" @compiler_2fast_3aJoinS_2ector(ptr %v1, ptr %v1, ptr %v1, i1 %a1, { i64, ptr } %t70, { i64, ptr } %t71)
  store %"compiler/ast:JoinS" %t75, ptr %l28
  br label %bb15
bb15:
  %t76 = load %"compiler/ast:JoinS", ptr %l28
  %t77 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 40, i64 8)
  store %"compiler/ast:JoinS" %t76, ptr %t77
  %t79 = insertvalue { i32, ptr } zeroinitializer, ptr %t77, 1
  store { i32, ptr } %t79, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2elambdaBody(ptr %v0, ptr %v1, ptr %a0, i1 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca i1
  %l8 = alloca i1
  %l10 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca i32
  %l24 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l27 = alloca i32
  %rv = alloca { i32, { i64, ptr } }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t4 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t1, i32 79)
  store i1 %t4, ptr %l8
  br label %bb1
bb1:
  %t5 = load i1, ptr %l8, !tbaa !21
  %t6 = xor i1 %t5, true
  br i1 %t6, label %bb2, label %bb3
bb2:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eblock(ptr %v0, ptr %v1, ptr %t8)
  %t11 = extractvalue { i32, { i64, ptr } } %t10, 1
  %t12 = extractvalue { i32, { i64, ptr } } %t10, 0
  store i32 %t12, ptr %l13
  %t13 = icmp ne i32 %t12, 0
  br i1 %t13, label %bb5, label %ok.14, !prof !99
ok.14:
  store { i64, ptr } %t11, ptr %l12
  br label %bb4
bb3:
  br label %bb7
bb4:
  %t15 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t15, ptr %l10, !tbaa !27
  br label %bb6
bb5:
  %t16 = load i32, ptr %l13, !tbaa !23
  %t17 = lshr i32 %t16, 16
  %t18 = and i32 %t16, 65535
  %t19 = icmp eq i32 %t17, 1
  %t20 = select i1 %t19, i32 1, i32 0
  %t21 = icmp eq i32 %t16, 0
  %t22 = shl i32 %t20, 16
  %t23 = or i32 %t22, %t18
  %t24 = select i1 %t21, i32 0, i32 %t23
  %t26 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t24, 0
  store { i32, { i64, ptr } } %t26, ptr %rv
  br label %ret
bb6:
  %t27 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t28 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t27, 1
  store { i32, { i64, ptr } } %t28, ptr %rv
  br label %ret
bb7:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/parse:Parser", ptr %t29, i32 0, i32 17
  %t32 = load i1, ptr %t31, !tbaa !21
  store i1 %t32, ptr %l2, !tbaa !21
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/parse:Parser", ptr %t34, i32 0, i32 16
  %t37 = load i1, ptr %t36, !tbaa !21
  store i1 %t37, ptr %l3, !tbaa !21
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/parse:Parser", ptr %t41, i32 0, i32 17
  store i1 true, ptr %t45, !tbaa !21
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/parse:Parser", ptr %t46, i32 0, i32 16
  store i1 %a1, ptr %t50, !tbaa !21
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2elineBody(ptr %v0, ptr %v1, ptr %t51, i1 false)
  %t54 = extractvalue { i32, { i64, ptr } } %t53, 1
  %t55 = extractvalue { i32, { i64, ptr } } %t53, 0
  store i32 %t55, ptr %l27
  %t56 = icmp ne i32 %t55, 0
  br i1 %t56, label %bb9, label %ok.57, !prof !99
ok.57:
  store { i64, ptr } %t54, ptr %l26
  br label %bb8
bb8:
  %t58 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t58, ptr %l24, !tbaa !27
  br label %bb10
bb9:
  %t59 = load i32, ptr %l27, !tbaa !23
  %t60 = lshr i32 %t59, 16
  %t61 = and i32 %t59, 65535
  %t62 = icmp eq i32 %t60, 1
  %t63 = select i1 %t62, i32 1, i32 0
  %t64 = icmp eq i32 %t59, 0
  %t65 = shl i32 %t63, 16
  %t66 = or i32 %t65, %t61
  %t67 = select i1 %t64, i32 0, i32 %t66
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t69 = load i1, ptr %l2, !tbaa !21
  %t72 = getelementptr %"compiler/parse:Parser", ptr %t68, i32 0, i32 17
  store i1 %t69, ptr %t72, !tbaa !21
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t74 = load i1, ptr %l3, !tbaa !21
  %t77 = getelementptr %"compiler/parse:Parser", ptr %t73, i32 0, i32 16
  store i1 %t74, ptr %t77, !tbaa !21
  %t79 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t67, 0
  store { i32, { i64, ptr } } %t79, ptr %rv
  br label %ret
bb10:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t81 = load i1, ptr %l2, !tbaa !21
  %t84 = getelementptr %"compiler/parse:Parser", ptr %t80, i32 0, i32 17
  store i1 %t81, ptr %t84, !tbaa !21
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t86 = load i1, ptr %l3, !tbaa !21
  %t89 = getelementptr %"compiler/parse:Parser", ptr %t85, i32 0, i32 16
  store i1 %t86, ptr %t89, !tbaa !21
  %t90 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t91 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t90, 1
  store { i32, { i64, ptr } } %t91, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local ptr @compiler_2fparse_2ecompiler_2fparse_3aParser_2elastField(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l4 = alloca i64
  %l6 = alloca i32
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l12 = alloca %"compiler/source:Span"
  %l15 = alloca { i64, ptr }
  %l17 = alloca ptr
  %l23 = alloca %"compiler/ast:VarDecl"
  %rv = alloca ptr
  %t17 = alloca i64
  %t43 = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call ptr @__olang_scope_hold(ptr %v2)
  %t2 = ptrtoint ptr %t1 to i64
  store i64 %t2, ptr %l4, !tbaa !24
  %t3 = load i1, ptr @olang_2esole_2ecompiler_2fast_3aVarDecl_2e0
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call ptr @__olang_region_make(ptr %v2)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  store i32 %a2, ptr %l6, !tbaa !23
  %t8 = icmp sge i64 1, 0
  br i1 %t8, label %bb3, label %bb4
bb3:
  %t10 = icmp sle i64 1, 2305843009213693951
  br i1 %t10, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_3f19ed1436e26d3c_ab56bc721c08c978)
  unreachable
bb5:
  %t12 = mul i64 1, 4
  %t13 = load i64, ptr %l4
  %t14 = inttoptr i64 %t13 to ptr
  %t15 = call ptr @__olang_held_alloc(ptr %t14, i64 %t12)
  %t16 = load i32, ptr %l6, !tbaa !23
  store i64 0, ptr %t17
  br label %fill.18
fill.18:
  %t21 = load i64, ptr %t17
  %t22 = icmp slt i64 %t21, 1
  br i1 %t22, label %fillb.19, label %filld.20
fillb.19:
  %t23 = getelementptr i32, ptr %t15, i64 %t21
  store i32 %t16, ptr %t23
  %t24 = add i64 %t21, 1
  store i64 %t24, ptr %t17
  br label %fill.18
filld.20:
  %t25 = insertvalue { i64, ptr } undef, i64 1, 0
  %t26 = insertvalue { i64, ptr } %t25, ptr %t15, 1
  store { i64, ptr } %t26, ptr %l9, !tbaa !27
  %t27 = call ptr @__olang_scope_hold(ptr %v2)
  %t28 = ptrtoint ptr %t27 to i64
  store i64 %t28, ptr %l10, !tbaa !24
  %t29 = load i1, ptr @olang_2esole_2ecompiler_2fast_3aVarDecl_2e1
  br i1 %t29, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_3f19ed1436e26d3c_ab56bc721c08c978)
  unreachable
bb7:
  %t31 = call ptr @__olang_region_make(ptr %v2)
  %t32 = ptrtoint ptr %t31 to i64
  store i64 %t32, ptr %l10, !tbaa !24
  br label %bb8
bb8:
  store %"compiler/source:Span" %a3, ptr %l12
  %t34 = icmp sge i64 1, 0
  br i1 %t34, label %bb9, label %bb10
bb9:
  %t36 = icmp sle i64 1, 1152921504606846975
  br i1 %t36, label %bb11, label %bb12
bb10:
  call void @__olang_check_failed(ptr @olang_loc_3f19ed1436e26d3c_ab56bc721c08c978)
  unreachable
bb11:
  %t38 = mul i64 1, 8
  %t39 = load i64, ptr %l10
  %t40 = inttoptr i64 %t39 to ptr
  %t41 = call ptr @__olang_held_alloc(ptr %t40, i64 %t38)
  %t42 = load %"compiler/source:Span", ptr %l12
  store i64 0, ptr %t43
  br label %fill.44
fill.44:
  %t47 = load i64, ptr %t43
  %t48 = icmp slt i64 %t47, 1
  br i1 %t48, label %fillb.45, label %filld.46
fillb.45:
  %t49 = getelementptr %"compiler/source:Span", ptr %t41, i64 %t47
  store %"compiler/source:Span" %t42, ptr %t49
  %t50 = add i64 %t47, 1
  store i64 %t50, ptr %t43
  br label %fill.44
filld.46:
  %t51 = insertvalue { i64, ptr } undef, i64 1, 0
  %t52 = insertvalue { i64, ptr } %t51, ptr %t41, 1
  store { i64, ptr } %t52, ptr %l15, !tbaa !27
  %t53 = load ptr, ptr %l1, !tbaa !29
  %t55 = getelementptr %"compiler/ast:VarDecl", ptr %t53, i32 0, i32 2
  %t56 = load ptr, ptr %t55, !tbaa !29
  store ptr %t56, ptr %l17, !tbaa !29
  %t57 = icmp sge i64 0, 0
  br i1 %t57, label %bb13, label %bb14
bb12:
  call void @__olang_check_failed(ptr @olang_loc_3f19ed1436e26d3c_ab56bc721c08c978)
  unreachable
bb13:
  %t59 = icmp sle i64 0, 1152921504606846975
  br i1 %t59, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_3f19ed1436e26d3c_ab56bc721c08c978)
  unreachable
bb15:
  %t61 = mul i64 0, 8
  %t62 = insertvalue { i64, ptr } undef, i64 0, 0
  %t63 = insertvalue { i64, ptr } %t62, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t64 = load ptr, ptr %l1, !tbaa !29
  %t66 = getelementptr %"compiler/ast:VarDecl", ptr %t64, i32 0, i32 4
  %t67 = load i1, ptr %t66, !tbaa !21
  %t68 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t69 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t70 = load ptr, ptr %l17, !tbaa !29
  %t73 = call %"compiler/ast:VarDecl" @compiler_2fast_3aVarDecl_2ector(ptr %v2, ptr %v2, ptr %v1, ptr %v2, ptr %v2, { i64, ptr } %t68, { i64, ptr } %t69, ptr %t70, { i64, ptr } %t63, i1 %t67, i1 true, i1 false)
  store %"compiler/ast:VarDecl" %t73, ptr %l23
  br label %bb17
bb16:
  call void @__olang_check_failed(ptr @olang_loc_3f19ed1436e26d3c_ab56bc721c08c978)
  unreachable
bb17:
  %t74 = load %"compiler/ast:VarDecl", ptr %l23
  %t75 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 64, i64 8)
  store %"compiler/ast:VarDecl" %t74, ptr %t75
  store ptr %t75, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2elineBody(ptr %v0, ptr %v1, ptr %a0, i1 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i1
  %l2 = alloca %"compiler/token:Token"
  %l3 = alloca %"compiler/token:Token"
  %l4 = alloca { i64, ptr }
  %l5 = alloca i1
  %l6 = alloca i1
  %l7 = alloca ptr
  %l8 = alloca %"compiler/source:Span"
  %l9 = alloca %"compiler/source:Span"
  %l10 = alloca ptr
  %l11 = alloca %"compiler/source:Span"
  %l13 = alloca %"compiler/token:Token"
  %l15 = alloca i32
  %l17 = alloca %"compiler/token:Token"
  %l20 = alloca i1
  %l21 = alloca i1
  %l24 = alloca i1
  %l25 = alloca i1
  %l29 = alloca i32
  %l33 = alloca i32
  %l35 = alloca ptr
  %l36 = alloca i32
  %l37 = alloca i32
  %l38 = alloca %"compiler/diagmsg:Msg"
  %l41 = alloca i32
  %l42 = alloca { i64, ptr }
  %l44 = alloca i1
  %l46 = alloca ptr
  %l47 = alloca i32
  %l48 = alloca i32
  %l50 = alloca %"compiler/diagmsg:Msg"
  %l59 = alloca ptr
  %l61 = alloca ptr
  %l62 = alloca i32
  %l70 = alloca { i64, ptr }
  %l75 = alloca ptr
  %l76 = alloca i1
  %l81 = alloca ptr
  %l82 = alloca i32
  %l83 = alloca i32
  %l84 = alloca %"compiler/diagmsg:Msg"
  %l90 = alloca ptr
  %l91 = alloca i1
  %l100 = alloca ptr
  %l101 = alloca i32
  %l102 = alloca i32
  %l103 = alloca %"compiler/diagmsg:Msg"
  %l109 = alloca ptr
  %l110 = alloca i1
  %l115 = alloca ptr
  %l116 = alloca i32
  %l117 = alloca i32
  %l118 = alloca %"compiler/diagmsg:Msg"
  %l125 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  store ptr %a0, ptr %l0
  store i1 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2etk(ptr %v0, ptr %t1)
  store %"compiler/token:Token" %t3, ptr %l13
  br label %bb1
bb1:
  %t4 = load %"compiler/token:Token", ptr %l13
  store %"compiler/token:Token" %t4, ptr %l2
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t5)
  store i32 %t7, ptr %l15
  br label %bb2
bb2:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2etk(ptr %v0, ptr %t8)
  store %"compiler/token:Token" %t10, ptr %l17
  br label %bb3
bb3:
  %t11 = load %"compiler/token:Token", ptr %l17
  store %"compiler/token:Token" %t11, ptr %l3
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t15 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t12, i32 8)
  store i1 %t15, ptr %l20
  br label %bb4
bb4:
  %t16 = load i1, ptr %l20, !tbaa !21
  br i1 %t16, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l21, !tbaa !21
  br label %bb8
bb6:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t20 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t17, i32 0)
  store i1 %t20, ptr %l24
  br label %bb7
bb7:
  %t21 = load i1, ptr %l24, !tbaa !21
  store i1 %t21, ptr %l21, !tbaa !21
  br label %bb8
bb8:
  %t22 = load i1, ptr %l21, !tbaa !21
  br i1 %t22, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l25, !tbaa !21
  br label %bb13
bb10:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/parse:Parser", ptr %t23, i32 0, i32 0
  %t26 = load ptr, ptr %t25, !tbaa !29
  %t27 = getelementptr %"compiler/token:Token", ptr %l3, i32 0, i32 2
  %t28 = load i32, ptr %t27, !tbaa !23
  %t31 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aSource_2eLine(ptr %v0, ptr %t26, i32 %t28)
  store i32 %t31, ptr %l29
  br label %bb11
bb11:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/parse:Parser", ptr %t32, i32 0, i32 0
  %t35 = load ptr, ptr %t34, !tbaa !29
  %t36 = getelementptr %"compiler/token:Token", ptr %l2, i32 0, i32 2
  %t37 = load i32, ptr %t36, !tbaa !23
  %t40 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aSource_2eLine(ptr %v0, ptr %t35, i32 %t37)
  store i32 %t40, ptr %l33
  br label %bb12
bb12:
  %t41 = load i32, ptr %l29, !tbaa !23
  %t42 = load i32, ptr %l33, !tbaa !23
  %t43 = icmp ne i32 %t41, %t42
  store i1 %t43, ptr %l25, !tbaa !21
  br label %bb13
bb13:
  %t45 = load i1, ptr %l25, !tbaa !21
  br i1 %t45, label %bb14, label %bb15
bb14:
  %t46 = load ptr, ptr %l0, !tbaa !29
  store ptr %t46, ptr %l35, !tbaa !29
  %t47 = getelementptr %"compiler/token:Token", ptr %l2, i32 0, i32 2
  %t48 = load i32, ptr %t47, !tbaa !23
  store i32 %t48, ptr %l36, !tbaa !23
  %t49 = getelementptr %"compiler/token:Token", ptr %l2, i32 0, i32 3
  %t50 = load i32, ptr %t49, !tbaa !23
  store i32 %t50, ptr %l37, !tbaa !23
  %t51 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eLineBodyOnLine(ptr %v0)
  store %"compiler/diagmsg:Msg" %t51, ptr %l38
  br label %bb16
bb15:
  br label %bb18
bb16:
  %t52 = load ptr, ptr %l35, !tbaa !29
  %t53 = load i32, ptr %l36, !tbaa !23
  %t54 = load i32, ptr %l37, !tbaa !23
  %t55 = load %"compiler/diagmsg:Msg", ptr %l38
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereport(ptr %v0, ptr %v0, ptr %t52, i32 %t53, i32 %t54, %"compiler/diagmsg:Msg" %t55)
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s0)
  %t57 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t57, ptr %rv
  br label %ret
bb18:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2epeek(ptr %v0, ptr %t58)
  store i32 %t60, ptr %l41
  br label %bb19
bb19:
  %t61 = load i32, ptr %l41, !range !{i32 0, i32 116}
  %t62 = call { i64, ptr } @compiler_2fparse_2elineBodyRefused(ptr %s0, i32 %t61)
  store { i64, ptr } %t62, ptr %l42
  br label %bb20
bb20:
  %t63 = load { i64, ptr }, ptr %l42, !tbaa !27
  store { i64, ptr } %t63, ptr %l4, !tbaa !27
  %t64 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t66 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t64, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d8, i32 0, i32 1) })
  store i1 %t66, ptr %l44
  br label %bb21
bb21:
  %t67 = load i1, ptr %l44, !tbaa !21
  %t68 = xor i1 %t67, true
  br i1 %t68, label %bb22, label %bb23
bb22:
  %t70 = load ptr, ptr %l0, !tbaa !29
  store ptr %t70, ptr %l46, !tbaa !29
  %t71 = getelementptr %"compiler/token:Token", ptr %l3, i32 0, i32 2
  %t72 = load i32, ptr %t71, !tbaa !23
  store i32 %t72, ptr %l47, !tbaa !23
  %t73 = getelementptr %"compiler/token:Token", ptr %l3, i32 0, i32 3
  %t74 = load i32, ptr %t73, !tbaa !23
  store i32 %t74, ptr %l48, !tbaa !23
  %t75 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t77 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eLineBodyNotSimple(ptr %s0, ptr %v0, { i64, ptr } %t75)
  store %"compiler/diagmsg:Msg" %t77, ptr %l50
  br label %bb24
bb23:
  br label %bb26
bb24:
  %t78 = load ptr, ptr %l46, !tbaa !29
  %t79 = load i32, ptr %l47, !tbaa !23
  %t80 = load i32, ptr %l48, !tbaa !23
  %t81 = load %"compiler/diagmsg:Msg", ptr %l50
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereport(ptr %v0, ptr %v0, ptr %t78, i32 %t79, i32 %t80, %"compiler/diagmsg:Msg" %t81)
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s0)
  %t83 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t83, ptr %rv
  br label %ret
bb26:
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr %"compiler/parse:Parser", ptr %t84, i32 0, i32 15
  %t87 = load i1, ptr %t86, !tbaa !21
  store i1 %t87, ptr %l5, !tbaa !21
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr %"compiler/parse:Parser", ptr %t89, i32 0, i32 15
  store i1 true, ptr %t91, !tbaa !21
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"compiler/parse:Parser", ptr %t92, i32 0, i32 12
  %t95 = load i1, ptr %t94, !tbaa !21
  store i1 %t95, ptr %l6, !tbaa !21
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t98 = load i1, ptr %l1, !tbaa !21
  %t101 = getelementptr %"compiler/parse:Parser", ptr %t97, i32 0, i32 12
  store i1 %t98, ptr %t101, !tbaa !21
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2estmt(ptr %v0, ptr %v1, ptr %t102)
  %t105 = extractvalue { i32, ptr } %t104, 1
  %t106 = extractvalue { i32, ptr } %t104, 0
  store i32 %t106, ptr %l62
  %t107 = icmp ne i32 %t106, 0
  br i1 %t107, label %bb28, label %ok.108, !prof !99
ok.108:
  store ptr %t105, ptr %l61
  br label %bb27
bb27:
  %t109 = load ptr, ptr %l61, !tbaa !29
  store ptr %t109, ptr %l59, !tbaa !29
  br label %bb29
bb28:
  %t110 = load i32, ptr %l62, !tbaa !23
  %t111 = lshr i32 %t110, 16
  %t112 = and i32 %t110, 65535
  %t113 = icmp eq i32 %t111, 1
  %t114 = select i1 %t113, i32 1, i32 0
  %t115 = icmp eq i32 %t110, 0
  %t116 = shl i32 %t114, 16
  %t117 = or i32 %t116, %t112
  %t118 = select i1 %t115, i32 0, i32 %t117
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t120 = load i1, ptr %l6, !tbaa !21
  %t123 = getelementptr %"compiler/parse:Parser", ptr %t119, i32 0, i32 12
  store i1 %t120, ptr %t123, !tbaa !21
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t125 = load i1, ptr %l5, !tbaa !21
  %t128 = getelementptr %"compiler/parse:Parser", ptr %t124, i32 0, i32 15
  store i1 %t125, ptr %t128, !tbaa !21
  call void @__olang_scope_close(ptr %s0)
  %t130 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t118, 0
  store { i32, { i64, ptr } } %t130, ptr %rv
  br label %ret
bb29:
  %t131 = load ptr, ptr %l59, !tbaa !29
  store ptr %t131, ptr %l7, !tbaa !29
  %t132 = load i1, ptr %l1, !tbaa !21
  br i1 %t132, label %bb30, label %bb31
bb30:
  %t134 = load ptr, ptr %l7, !tbaa !29
  %t135 = mul i64 1, 8
  %t136 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t135)
  %t137 = insertvalue { i64, ptr } undef, i64 1, 0
  %t138 = insertvalue { i64, ptr } %t137, ptr %t136, 1
  store { i64, ptr } %t138, ptr %l70, !tbaa !27
  %t140 = getelementptr { i64, ptr }, ptr %l70, i32 0, i32 1
  %t141 = load ptr, ptr %t140, !tbaa !27
  %t142 = getelementptr ptr, ptr %t141, i64 0
  store ptr %t134, ptr %t142, !tbaa !39
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t144 = load i1, ptr %l6, !tbaa !21
  %t147 = getelementptr %"compiler/parse:Parser", ptr %t143, i32 0, i32 12
  store i1 %t144, ptr %t147, !tbaa !21
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t149 = load i1, ptr %l5, !tbaa !21
  %t152 = getelementptr %"compiler/parse:Parser", ptr %t148, i32 0, i32 15
  store i1 %t149, ptr %t152, !tbaa !21
  call void @__olang_scope_close(ptr %s0)
  %t153 = load { i64, ptr }, ptr %l70, !tbaa !27
  %t154 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t153, 1
  store { i32, { i64, ptr } } %t154, ptr %rv
  br label %ret
bb31:
  br label %bb32
bb32:
  %t155 = load ptr, ptr %l7, !tbaa !29
  store ptr %t155, ptr %l75, !tbaa !29
  store i1 false, ptr %l76, !tbaa !21
  %t156 = load ptr, ptr %l75, !tbaa !29
  %t157 = icmp ne ptr %t156, null
  br i1 %t157, label %bb33, label %bb34
bb33:
  %t159 = load ptr, ptr %l75, !tbaa !29
  %t160 = load i64, ptr %t159, !range !{i64 0, i64 22}
  %t162 = icmp eq i64 %t160, 1
  store i1 %t162, ptr %l76, !tbaa !21
  br label %bb34
bb34:
  %t163 = load i1, ptr %l76, !tbaa !21
  br i1 %t163, label %bb35, label %bb36
bb35:
  %t164 = load ptr, ptr %l7, !tbaa !29
  %t166 = getelementptr { i64, [4 x i64] }, ptr %t164, i32 0, i32 1
  %t167 = getelementptr { %"compiler/source:Span", ptr }, ptr %t166, i32 0, i32 0
  %t168 = load %"compiler/source:Span", ptr %t167
  store %"compiler/source:Span" %t168, ptr %l8
  br label %bb37
bb36:
  br label %bb40
bb37:
  store %olang.scope zeroinitializer, ptr %s12
  %t170 = load ptr, ptr %l0, !tbaa !29
  store ptr %t170, ptr %l81, !tbaa !29
  %t171 = getelementptr %"compiler/source:Span", ptr %l8, i32 0, i32 0
  %t172 = load i32, ptr %t171, !tbaa !23
  store i32 %t172, ptr %l82, !tbaa !23
  %t173 = getelementptr %"compiler/source:Span", ptr %l8, i32 0, i32 1
  %t174 = load i32, ptr %t173, !tbaa !23
  store i32 %t174, ptr %l83, !tbaa !23
  %t175 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eLineBodyNotSimple(ptr %s12, ptr %v0, { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d9, i32 0, i32 1) })
  store %"compiler/diagmsg:Msg" %t175, ptr %l84
  br label %bb38
bb38:
  %t176 = load ptr, ptr %l81, !tbaa !29
  %t177 = load i32, ptr %l82, !tbaa !23
  %t178 = load i32, ptr %l83, !tbaa !23
  %t179 = load %"compiler/diagmsg:Msg", ptr %l84
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereport(ptr %v0, ptr %v0, ptr %t176, i32 %t177, i32 %t178, %"compiler/diagmsg:Msg" %t179)
  br label %bb39
bb39:
  call void @__olang_scope_close(ptr %s12)
  %t180 = load ptr, ptr %l0, !tbaa !29
  %t181 = load i1, ptr %l6, !tbaa !21
  %t184 = getelementptr %"compiler/parse:Parser", ptr %t180, i32 0, i32 12
  store i1 %t181, ptr %t184, !tbaa !21
  %t185 = load ptr, ptr %l0, !tbaa !29
  %t186 = load i1, ptr %l5, !tbaa !21
  %t189 = getelementptr %"compiler/parse:Parser", ptr %t185, i32 0, i32 15
  store i1 %t186, ptr %t189, !tbaa !21
  call void @__olang_scope_close(ptr %s0)
  %t191 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t191, ptr %rv
  br label %ret
bb40:
  %t192 = load ptr, ptr %l7, !tbaa !29
  store ptr %t192, ptr %l90, !tbaa !29
  store i1 false, ptr %l91, !tbaa !21
  %t193 = load ptr, ptr %l90, !tbaa !29
  %t194 = icmp ne ptr %t193, null
  br i1 %t194, label %bb41, label %bb42
bb41:
  %t196 = load ptr, ptr %l90, !tbaa !29
  %t197 = load i64, ptr %t196, !range !{i64 0, i64 22}
  %t199 = icmp eq i64 %t197, 2
  store i1 %t199, ptr %l91, !tbaa !21
  br label %bb42
bb42:
  %t200 = load i1, ptr %l91, !tbaa !21
  br i1 %t200, label %bb43, label %bb44
bb43:
  %t201 = load ptr, ptr %l7, !tbaa !29
  %t203 = getelementptr { i64, [4 x i64] }, ptr %t201, i32 0, i32 1
  %t204 = getelementptr { %"compiler/source:Span", ptr }, ptr %t203, i32 0, i32 0
  %t205 = load %"compiler/source:Span", ptr %t204
  store %"compiler/source:Span" %t205, ptr %l9
  %t207 = load ptr, ptr %l7, !tbaa !29
  %t209 = getelementptr { i64, [4 x i64] }, ptr %t207, i32 0, i32 1
  %t210 = getelementptr { %"compiler/source:Span", ptr }, ptr %t209, i32 0, i32 1
  %t211 = load ptr, ptr %t210
  store ptr %t211, ptr %l10, !tbaa !29
  br label %bb45
bb44:
  br label %bb50
bb45:
  %t213 = load ptr, ptr %l10, !tbaa !29
  %t215 = getelementptr %"compiler/ast:Multi", ptr %t213, i32 0, i32 1
  %t216 = load i1, ptr %t215, !tbaa !21
  br i1 %t216, label %bb46, label %bb47
bb46:
  store %olang.scope zeroinitializer, ptr %s17
  %t218 = load ptr, ptr %l0, !tbaa !29
  store ptr %t218, ptr %l100, !tbaa !29
  %t219 = getelementptr %"compiler/source:Span", ptr %l9, i32 0, i32 0
  %t220 = load i32, ptr %t219, !tbaa !23
  store i32 %t220, ptr %l101, !tbaa !23
  %t221 = getelementptr %"compiler/source:Span", ptr %l9, i32 0, i32 1
  %t222 = load i32, ptr %t221, !tbaa !23
  store i32 %t222, ptr %l102, !tbaa !23
  %t223 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eLineBodyNotSimple(ptr %s17, ptr %v0, { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d10, i32 0, i32 1) })
  store %"compiler/diagmsg:Msg" %t223, ptr %l103
  br label %bb48
bb47:
  br label %bb50
bb48:
  %t224 = load ptr, ptr %l100, !tbaa !29
  %t225 = load i32, ptr %l101, !tbaa !23
  %t226 = load i32, ptr %l102, !tbaa !23
  %t227 = load %"compiler/diagmsg:Msg", ptr %l103
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereport(ptr %v0, ptr %v0, ptr %t224, i32 %t225, i32 %t226, %"compiler/diagmsg:Msg" %t227)
  br label %bb49
bb49:
  call void @__olang_scope_close(ptr %s17)
  %t228 = load ptr, ptr %l0, !tbaa !29
  %t229 = load i1, ptr %l6, !tbaa !21
  %t232 = getelementptr %"compiler/parse:Parser", ptr %t228, i32 0, i32 12
  store i1 %t229, ptr %t232, !tbaa !21
  %t233 = load ptr, ptr %l0, !tbaa !29
  %t234 = load i1, ptr %l5, !tbaa !21
  %t237 = getelementptr %"compiler/parse:Parser", ptr %t233, i32 0, i32 15
  store i1 %t234, ptr %t237, !tbaa !21
  call void @__olang_scope_close(ptr %s0)
  %t239 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t239, ptr %rv
  br label %ret
bb50:
  %t240 = load ptr, ptr %l7, !tbaa !29
  store ptr %t240, ptr %l109, !tbaa !29
  store i1 false, ptr %l110, !tbaa !21
  %t241 = load ptr, ptr %l109, !tbaa !29
  %t242 = icmp ne ptr %t241, null
  br i1 %t242, label %bb51, label %bb52
bb51:
  %t244 = load ptr, ptr %l109, !tbaa !29
  %t245 = load i64, ptr %t244, !range !{i64 0, i64 22}
  %t247 = icmp eq i64 %t245, 18
  store i1 %t247, ptr %l110, !tbaa !21
  br label %bb52
bb52:
  %t248 = load i1, ptr %l110, !tbaa !21
  br i1 %t248, label %bb53, label %bb54
bb53:
  %t249 = load ptr, ptr %l7, !tbaa !29
  %t251 = getelementptr { i64, [4 x i64] }, ptr %t249, i32 0, i32 1
  %t252 = getelementptr { %"compiler/source:Span", ptr }, ptr %t251, i32 0, i32 0
  %t253 = load %"compiler/source:Span", ptr %t252
  store %"compiler/source:Span" %t253, ptr %l11
  br label %bb55
bb54:
  br label %bb58
bb55:
  store %olang.scope zeroinitializer, ptr %s22
  %t255 = load ptr, ptr %l0, !tbaa !29
  store ptr %t255, ptr %l115, !tbaa !29
  %t256 = getelementptr %"compiler/source:Span", ptr %l11, i32 0, i32 0
  %t257 = load i32, ptr %t256, !tbaa !23
  store i32 %t257, ptr %l116, !tbaa !23
  %t258 = getelementptr %"compiler/source:Span", ptr %l11, i32 0, i32 1
  %t259 = load i32, ptr %t258, !tbaa !23
  store i32 %t259, ptr %l117, !tbaa !23
  %t260 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eLineBodyNotSimple(ptr %s22, ptr %v0, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d11, i32 0, i32 1) })
  store %"compiler/diagmsg:Msg" %t260, ptr %l118
  br label %bb56
bb56:
  %t261 = load ptr, ptr %l115, !tbaa !29
  %t262 = load i32, ptr %l116, !tbaa !23
  %t263 = load i32, ptr %l117, !tbaa !23
  %t264 = load %"compiler/diagmsg:Msg", ptr %l118
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereport(ptr %v0, ptr %v0, ptr %t261, i32 %t262, i32 %t263, %"compiler/diagmsg:Msg" %t264)
  br label %bb57
bb57:
  call void @__olang_scope_close(ptr %s22)
  %t265 = load ptr, ptr %l0, !tbaa !29
  %t266 = load i1, ptr %l6, !tbaa !21
  %t269 = getelementptr %"compiler/parse:Parser", ptr %t265, i32 0, i32 12
  store i1 %t266, ptr %t269, !tbaa !21
  %t270 = load ptr, ptr %l0, !tbaa !29
  %t271 = load i1, ptr %l5, !tbaa !21
  %t274 = getelementptr %"compiler/parse:Parser", ptr %t270, i32 0, i32 15
  store i1 %t271, ptr %t274, !tbaa !21
  call void @__olang_scope_close(ptr %s0)
  %t276 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t276, ptr %rv
  br label %ret
bb58:
  br i1 true, label %bb59, label %bb60
bb59:
  br label %bb61
bb60:
  br label %bb62
bb61:
  br label %bb63
bb62:
  call void @__olang_check_failed(ptr @olang_loc_a66f16e9609fdd27_2fbef1e5bed159db)
  unreachable
bb63:
  %t277 = load ptr, ptr %l7, !tbaa !29
  %t278 = mul i64 1, 8
  %t279 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t278)
  %t280 = insertvalue { i64, ptr } undef, i64 1, 0
  %t281 = insertvalue { i64, ptr } %t280, ptr %t279, 1
  store { i64, ptr } %t281, ptr %l125, !tbaa !27
  %t283 = getelementptr { i64, ptr }, ptr %l125, i32 0, i32 1
  %t284 = load ptr, ptr %t283, !tbaa !27
  %t285 = getelementptr ptr, ptr %t284, i64 0
  store ptr %t277, ptr %t285, !tbaa !39
  %t286 = load ptr, ptr %l0, !tbaa !29
  %t287 = load i1, ptr %l6, !tbaa !21
  %t290 = getelementptr %"compiler/parse:Parser", ptr %t286, i32 0, i32 12
  store i1 %t287, ptr %t290, !tbaa !21
  %t291 = load ptr, ptr %l0, !tbaa !29
  %t292 = load i1, ptr %l5, !tbaa !21
  %t295 = getelementptr %"compiler/parse:Parser", ptr %t291, i32 0, i32 15
  store i1 %t292, ptr %t295, !tbaa !21
  call void @__olang_scope_close(ptr %s0)
  %t296 = load { i64, ptr }, ptr %l125, !tbaa !27
  %t297 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t296, 1
  store { i32, { i64, ptr } } %t297, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local { i32, %"compiler/source:Span" } @compiler_2fparse_2ecompiler_2fparse_3aParser_2elinkClause(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/token:Token"
  %l4 = alloca i1
  %l5 = alloca i1
  %l6 = alloca ptr
  %l8 = alloca %"compiler/token:Token"
  %l9 = alloca { i64, ptr }
  %l10 = alloca i1
  %l11 = alloca i1
  %l13 = alloca i32
  %l17 = alloca %"compiler/source:Span"
  %l19 = alloca i32
  %l21 = alloca %"compiler/token:Token"
  %l23 = alloca i32
  %l26 = alloca %"compiler/source:Span"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca { i32, %"compiler/source:Span" }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t4 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t1, i32 1)
  store i1 %t4, ptr %l4
  br label %bb1
bb1:
  %t5 = load i1, ptr %l4, !tbaa !21
  br i1 %t5, label %bb2, label %bb3
bb2:
  %t6 = load ptr, ptr %l0, !tbaa !29
  store ptr %t6, ptr %l6, !tbaa !29
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2etk(ptr %v0, ptr %t7)
  store %"compiler/token:Token" %t9, ptr %l8
  br label %bb4
bb3:
  store i1 false, ptr %l5, !tbaa !21
  br label %bb7
bb4:
  %t10 = load ptr, ptr %l6, !tbaa !29
  %t11 = load %"compiler/token:Token", ptr %l8
  %t12 = call { i64, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etext(ptr %v0, ptr %v0, ptr %t10, %"compiler/token:Token" %t11)
  store { i64, ptr } %t12, ptr %l9
  br label %bb5
bb5:
  %t13 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t14 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t13, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d12, i32 0, i32 1) })
  store i1 %t14, ptr %l10
  br label %bb6
bb6:
  %t15 = load i1, ptr %l10, !tbaa !21
  store i1 %t15, ptr %l5, !tbaa !21
  br label %bb7
bb7:
  %t16 = load i1, ptr %l5, !tbaa !21
  br i1 %t16, label %bb8, label %bb9
bb8:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elook(ptr %v0, ptr %t17, i64 1)
  store i32 %t19, ptr %l13
  br label %bb10
bb9:
  store i1 false, ptr %l11, !tbaa !21
  br label %bb11
bb10:
  %t20 = load i32, ptr %l13, !range !{i32 0, i32 116}
  %t22 = trunc i64 5 to i32
  %t23 = icmp eq i32 %t20, %t22
  store i1 %t23, ptr %l11, !tbaa !21
  br label %bb11
bb11:
  %t25 = load i1, ptr %l11, !tbaa !21
  %t26 = xor i1 %t25, true
  br i1 %t26, label %bb12, label %bb13
bb12:
  store %olang.scope zeroinitializer, ptr %s1
  %t28 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s1, i32 0, i32 0)
  store %"compiler/source:Span" %t28, ptr %l17
  br label %bb14
bb13:
  br label %bb15
bb14:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t29 = load %"compiler/source:Span", ptr %l17
  %t30 = insertvalue { i32, %"compiler/source:Span" } zeroinitializer, %"compiler/source:Span" %t29, 1
  store { i32, %"compiler/source:Span" } %t30, ptr %rv
  br label %ret
bb15:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t31)
  store i32 %t33, ptr %l19
  br label %bb16
bb16:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2etk(ptr %v0, ptr %t34)
  store %"compiler/token:Token" %t36, ptr %l21
  br label %bb17
bb17:
  %t37 = load %"compiler/token:Token", ptr %l21
  store %"compiler/token:Token" %t37, ptr %l1
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t38)
  store i32 %t40, ptr %l23
  br label %bb18
bb18:
  %t41 = getelementptr %"compiler/token:Token", ptr %l1, i32 0, i32 2
  %t42 = load i32, ptr %t41, !tbaa !23
  %t43 = getelementptr %"compiler/token:Token", ptr %l1, i32 0, i32 3
  %t44 = load i32, ptr %t43, !tbaa !23
  %t47 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 %t42, i32 %t44)
  store %"compiler/source:Span" %t47, ptr %l26
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s0)
  %t48 = load %"compiler/source:Span", ptr %l26
  %t49 = insertvalue { i32, %"compiler/source:Span" } zeroinitializer, %"compiler/source:Span" %t48, 1
  store { i32, %"compiler/source:Span" } %t49, ptr %rv
  br label %ret
ret:
  %rr = load { i32, %"compiler/source:Span" }, ptr %rv
  ret { i32, %"compiler/source:Span" } %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ememberDecl(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca %"compiler/token:Token"
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %lp5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca { i64, ptr }
  %l8 = alloca ptr
  %l9 = alloca %"compiler/source:Span"
  %l10 = alloca i32
  %l11 = alloca ptr
  %l12 = alloca %"compiler/source:Span"
  %l13 = alloca ptr
  %l15 = alloca %"compiler/token:Token"
  %l16 = alloca i32
  %l18 = alloca i32
  %l19 = alloca i32
  %l26 = alloca i1
  %l27 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l30 = alloca i32
  %l34 = alloca %"compiler/source:Span"
  %l35 = alloca i32
  %l41 = alloca i32
  %l44 = alloca i32
  %l45 = alloca i32
  %l47 = alloca i32
  %l49 = alloca i32
  %l50 = alloca i32
  %l56 = alloca i1
  %l57 = alloca i1
  %l60 = alloca i1
  %l66 = alloca i1
  %l67 = alloca { i64, ptr }
  %l69 = alloca { i64, ptr }
  %l70 = alloca i32
  %l72 = alloca i32
  %l75 = alloca i32
  %l76 = alloca i32
  %l78 = alloca ptr
  %l80 = alloca ptr
  %l81 = alloca i32
  %l85 = alloca %"compiler/source:Span"
  %l87 = alloca i32
  %l89 = alloca %"compiler/source:Span"
  %l94 = alloca %"compiler/ast:MemberDecl"
  %l99 = alloca ptr
  %l103 = alloca { i64, ptr }
  %l107 = alloca { i64, ptr }
  %l110 = alloca i32
  %l111 = alloca ptr
  %l115 = alloca ptr
  %l116 = alloca i32
  %l118 = alloca ptr
  %l121 = alloca %"compiler/source:Span"
  %l122 = alloca i32
  %l129 = alloca %"compiler/ast:TypeDecl"
  %l134 = alloca ptr
  %l135 = alloca i1
  %l142 = alloca %"compiler/source:Span"
  %l157 = alloca %"compiler/ast:TypeDecl"
  %s0 = alloca %olang.scope
  %rv = alloca { i32, ptr }
  %t72 = alloca i64
  %t83 = alloca { i64, [5 x i64] }, align 8
  %t258 = alloca { i64, [8 x i64] }, align 8
  %t348 = alloca { i64, [8 x i64] }, align 8
  %t422 = alloca { i64, [8 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2etk(ptr %v0, ptr %t1)
  store %"compiler/token:Token" %t3, ptr %l15
  br label %bb1
bb1:
  %t4 = load %"compiler/token:Token", ptr %l15
  store %"compiler/token:Token" %t4, ptr %l2
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ename(ptr %v0, ptr %t5)
  %t8 = extractvalue { i32, i32 } %t7, 1
  %t9 = extractvalue { i32, i32 } %t7, 0
  store i32 %t9, ptr %l19
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb3, label %ok.11, !prof !99
ok.11:
  store i32 %t8, ptr %l18
  br label %bb2
bb2:
  %t12 = load i32, ptr %l18, !tbaa !23
  store i32 %t12, ptr %l16, !tbaa !23
  br label %bb4
bb3:
  %t13 = load i32, ptr %l19, !tbaa !23
  %t14 = lshr i32 %t13, 16
  %t15 = and i32 %t13, 65535
  %t16 = icmp eq i32 %t14, 1
  %t17 = select i1 %t16, i32 1, i32 0
  %t18 = icmp eq i32 %t13, 0
  %t19 = shl i32 %t17, 16
  %t20 = or i32 %t19, %t15
  %t21 = select i1 %t18, i32 0, i32 %t20
  call void @__olang_scope_close(ptr %s0)
  %t23 = insertvalue { i32, ptr } zeroinitializer, i32 %t21, 0
  store { i32, ptr } %t23, ptr %rv
  br label %ret
bb4:
  %t24 = load i32, ptr %l16, !tbaa !23
  store i32 %t24, ptr %l3, !tbaa !23
  %t25 = icmp sge i64 0, 0
  br i1 %t25, label %bb5, label %bb6
bb5:
  %t27 = icmp sle i64 0, 1152921504606846975
  br i1 %t27, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_6e79f8a0f2444e80_4f0f22c816480f9c)
  unreachable
bb7:
  %t29 = mul i64 0, 8
  %t30 = insertvalue { i64, ptr } undef, i64 0, 0
  %t31 = insertvalue { i64, ptr } %t30, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t31, ptr %l4, !tbaa !27
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t36 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t33, i32 98)
  store i1 %t36, ptr %l26
  br label %bb9
bb8:
  call void @__olang_check_failed(ptr @olang_loc_6e79f8a0f2444e80_4f0f22c816480f9c)
  unreachable
bb9:
  %t37 = load i1, ptr %l26, !tbaa !21
  br i1 %t37, label %bb10, label %bb11
bb10:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeArgs(ptr %v0, ptr %v1, ptr %t38)
  %t41 = extractvalue { i32, { i64, ptr } } %t40, 1
  %t42 = extractvalue { i32, { i64, ptr } } %t40, 0
  store i32 %t42, ptr %l30
  %t43 = icmp ne i32 %t42, 0
  br i1 %t43, label %bb13, label %ok.44, !prof !99
ok.44:
  store { i64, ptr } %t41, ptr %l29
  br label %bb12
bb11:
  br label %bb15
bb12:
  %t45 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t45, ptr %l27, !tbaa !27
  br label %bb14
bb13:
  %t46 = load i32, ptr %l30, !tbaa !23
  %t47 = lshr i32 %t46, 16
  %t48 = and i32 %t46, 65535
  %t49 = icmp eq i32 %t47, 1
  %t50 = select i1 %t49, i32 1, i32 0
  %t51 = icmp eq i32 %t46, 0
  %t52 = shl i32 %t50, 16
  %t53 = or i32 %t52, %t48
  %t54 = select i1 %t51, i32 0, i32 %t53
  call void @__olang_scope_close(ptr %s0)
  %t56 = insertvalue { i32, ptr } zeroinitializer, i32 %t54, 0
  store { i32, ptr } %t56, ptr %rv
  br label %ret
bb14:
  %t57 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t57, ptr %l4, !tbaa !27
  br label %bb15
bb15:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/token:Token", ptr %l2, i32 0, i32 2
  %t60 = load i32, ptr %t59, !tbaa !23
  %t63 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t58, i32 %t60)
  store %"compiler/source:Span" %t63, ptr %l34
  br label %bb16
bb16:
  %t64 = load i32, ptr %l3, !tbaa !23
  store i32 %t64, ptr %l35, !tbaa !23
  %t65 = icmp sge i64 1, 0
  br i1 %t65, label %bb17, label %bb18
bb17:
  %t67 = icmp sle i64 1, 2305843009213693951
  br i1 %t67, label %bb19, label %bb20
bb18:
  call void @__olang_check_failed(ptr @olang_loc_d5699841f5fe95ad_d2c83eae1a824169)
  unreachable
bb19:
  %t69 = mul i64 1, 4
  %t70 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t69)
  %t71 = load i32, ptr %l35, !tbaa !23
  store i64 0, ptr %t72
  br label %fill.73
fill.73:
  %t76 = load i64, ptr %t72
  %t77 = icmp slt i64 %t76, 1
  br i1 %t77, label %fillb.74, label %filld.75
fillb.74:
  %t78 = getelementptr i32, ptr %t70, i64 %t76
  store i32 %t71, ptr %t78
  %t79 = add i64 %t76, 1
  store i64 %t79, ptr %t72
  br label %fill.73
filld.75:
  %t80 = insertvalue { i64, ptr } undef, i64 1, 0
  %t81 = insertvalue { i64, ptr } %t80, ptr %t70, 1
  %t82 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, [5 x i64] } zeroinitializer, ptr %t83
  %t84 = getelementptr { i64, [5 x i64] }, ptr %t83, i32 0, i32 0
  store i64 0, ptr %t84
  %t85 = load %"compiler/source:Span", ptr %l34
  %t86 = insertvalue { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } undef, %"compiler/source:Span" %t85, 0
  %t88 = insertvalue { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } %t86, { i64, ptr } %t81, 1
  %t90 = insertvalue { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } %t88, { i64, ptr } %t82, 2
  %t91 = getelementptr { i64, [5 x i64] }, ptr %t83, i32 0, i32 1
  store { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } %t90, ptr %t91
  %t92 = load { i64, [5 x i64] }, ptr %t83
  %t93 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 48, i64 8)
  store ptr %t93, ptr %lp5
  %t95 = load ptr, ptr %lp5
  store { i64, [5 x i64] } %t92, ptr %t95
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t99 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %t96, i32 76)
  %t100 = extractvalue { i32, i32 } %t99, 1
  %t101 = extractvalue { i32, i32 } %t99, 0
  store i32 %t101, ptr %l45
  %t102 = icmp ne i32 %t101, 0
  br i1 %t102, label %bb22, label %ok.103, !prof !99
ok.103:
  store i32 %t100, ptr %l44
  br label %bb21
bb20:
  call void @__olang_check_failed(ptr @olang_loc_d5699841f5fe95ad_d2c83eae1a824169)
  unreachable
bb21:
  %t104 = load i32, ptr %l44, !tbaa !23
  store i32 %t104, ptr %l41, !tbaa !23
  br label %bb23
bb22:
  %t105 = load i32, ptr %l45, !tbaa !23
  %t106 = lshr i32 %t105, 16
  %t107 = and i32 %t105, 65535
  %t108 = icmp eq i32 %t106, 1
  %t109 = select i1 %t108, i32 1, i32 0
  %t110 = icmp eq i32 %t105, 0
  %t111 = shl i32 %t109, 16
  %t112 = or i32 %t111, %t107
  %t113 = select i1 %t110, i32 0, i32 %t112
  call void @__olang_scope_close(ptr %s0)
  %t115 = insertvalue { i32, ptr } zeroinitializer, i32 %t113, 0
  store { i32, ptr } %t115, ptr %rv
  br label %ret
bb23:
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t118 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ename(ptr %v0, ptr %t116)
  %t119 = extractvalue { i32, i32 } %t118, 1
  %t120 = extractvalue { i32, i32 } %t118, 0
  store i32 %t120, ptr %l50
  %t121 = icmp ne i32 %t120, 0
  br i1 %t121, label %bb25, label %ok.122, !prof !99
ok.122:
  store i32 %t119, ptr %l49
  br label %bb24
bb24:
  %t123 = load i32, ptr %l49, !tbaa !23
  store i32 %t123, ptr %l47, !tbaa !23
  br label %bb26
bb25:
  %t124 = load i32, ptr %l50, !tbaa !23
  %t125 = lshr i32 %t124, 16
  %t126 = and i32 %t124, 65535
  %t127 = icmp eq i32 %t125, 1
  %t128 = select i1 %t127, i32 1, i32 0
  %t129 = icmp eq i32 %t124, 0
  %t130 = shl i32 %t128, 16
  %t131 = or i32 %t130, %t126
  %t132 = select i1 %t129, i32 0, i32 %t131
  call void @__olang_scope_close(ptr %s0)
  %t134 = insertvalue { i32, ptr } zeroinitializer, i32 %t132, 0
  store { i32, ptr } %t134, ptr %rv
  br label %ret
bb26:
  %t135 = load i32, ptr %l47, !tbaa !23
  store i32 %t135, ptr %l6, !tbaa !23
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t137 = load ptr, ptr %lp5
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereceiverVars(ptr %v0, ptr %v1, ptr %t136, ptr %t137, i1 false)
  br label %bb27
bb27:
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t143 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t140, i32 98)
  store i1 %t143, ptr %l56
  br label %bb28
bb28:
  %t144 = load i1, ptr %l56, !tbaa !21
  br i1 %t144, label %bb29, label %bb30
bb29:
  store i1 true, ptr %l57, !tbaa !21
  br label %bb32
bb30:
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t148 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t145, i32 78)
  store i1 %t148, ptr %l60
  br label %bb31
bb31:
  %t149 = load i1, ptr %l60, !tbaa !21
  store i1 %t149, ptr %l57, !tbaa !21
  br label %bb32
bb32:
  %t150 = load i1, ptr %l57, !tbaa !21
  br i1 %t150, label %bb33, label %bb34
bb33:
  %t151 = icmp sge i64 0, 0
  br i1 %t151, label %bb35, label %bb36
bb34:
  br label %bb57
bb35:
  %t153 = icmp sle i64 0, 1152921504606846975
  br i1 %t153, label %bb37, label %bb38
bb36:
  call void @__olang_check_failed(ptr @olang_loc_9ddf95f323fdbbae_24356cb3d59d532a)
  unreachable
bb37:
  %t155 = mul i64 0, 8
  %t156 = insertvalue { i64, ptr } undef, i64 0, 0
  %t157 = insertvalue { i64, ptr } %t156, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t157, ptr %l7, !tbaa !27
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t162 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t159, i32 98)
  store i1 %t162, ptr %l66
  br label %bb39
bb38:
  call void @__olang_check_failed(ptr @olang_loc_9ddf95f323fdbbae_24356cb3d59d532a)
  unreachable
bb39:
  %t163 = load i1, ptr %l66, !tbaa !21
  br i1 %t163, label %bb40, label %bb41
bb40:
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t166 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeParams(ptr %v0, ptr %v1, ptr %t164)
  %t167 = extractvalue { i32, { i64, ptr } } %t166, 1
  %t168 = extractvalue { i32, { i64, ptr } } %t166, 0
  store i32 %t168, ptr %l70
  %t169 = icmp ne i32 %t168, 0
  br i1 %t169, label %bb43, label %ok.170, !prof !99
ok.170:
  store { i64, ptr } %t167, ptr %l69
  br label %bb42
bb41:
  br label %bb45
bb42:
  %t171 = load { i64, ptr }, ptr %l69, !tbaa !27
  store { i64, ptr } %t171, ptr %l67, !tbaa !27
  br label %bb44
bb43:
  %t172 = load i32, ptr %l70, !tbaa !23
  %t173 = lshr i32 %t172, 16
  %t174 = and i32 %t172, 65535
  %t175 = icmp eq i32 %t173, 1
  %t176 = select i1 %t175, i32 1, i32 0
  %t177 = icmp eq i32 %t172, 0
  %t178 = shl i32 %t176, 16
  %t179 = or i32 %t178, %t174
  %t180 = select i1 %t177, i32 0, i32 %t179
  call void @__olang_scope_close(ptr %s0)
  %t182 = insertvalue { i32, ptr } zeroinitializer, i32 %t180, 0
  store { i32, ptr } %t182, ptr %rv
  br label %ret
bb44:
  %t183 = load { i64, ptr }, ptr %l67, !tbaa !27
  store { i64, ptr } %t183, ptr %l7, !tbaa !27
  br label %bb45
bb45:
  %t184 = load ptr, ptr %l0, !tbaa !29
  %t187 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %t184, i32 78)
  %t188 = extractvalue { i32, i32 } %t187, 1
  %t189 = extractvalue { i32, i32 } %t187, 0
  store i32 %t189, ptr %l76
  %t190 = icmp ne i32 %t189, 0
  br i1 %t190, label %bb47, label %ok.191, !prof !99
ok.191:
  store i32 %t188, ptr %l75
  br label %bb46
bb46:
  %t192 = load i32, ptr %l75, !tbaa !23
  store i32 %t192, ptr %l72, !tbaa !23
  br label %bb48
bb47:
  %t193 = load i32, ptr %l76, !tbaa !23
  %t194 = lshr i32 %t193, 16
  %t195 = and i32 %t193, 65535
  %t196 = icmp eq i32 %t194, 1
  %t197 = select i1 %t196, i32 1, i32 0
  %t198 = icmp eq i32 %t193, 0
  %t199 = shl i32 %t197, 16
  %t200 = or i32 %t199, %t195
  %t201 = select i1 %t198, i32 0, i32 %t200
  call void @__olang_scope_close(ptr %s0)
  %t203 = insertvalue { i32, ptr } zeroinitializer, i32 %t201, 0
  store { i32, ptr } %t203, ptr %rv
  br label %ret
bb48:
  %t204 = load ptr, ptr %l0, !tbaa !29
  %t206 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeExpr(ptr %v0, ptr %v1, ptr %t204)
  %t207 = extractvalue { i32, ptr } %t206, 1
  %t208 = extractvalue { i32, ptr } %t206, 0
  store i32 %t208, ptr %l81
  %t209 = icmp ne i32 %t208, 0
  br i1 %t209, label %bb50, label %ok.210, !prof !99
ok.210:
  store ptr %t207, ptr %l80
  br label %bb49
bb49:
  %t211 = load ptr, ptr %l80, !tbaa !29
  store ptr %t211, ptr %l78, !tbaa !29
  br label %bb51
bb50:
  %t212 = load i32, ptr %l81, !tbaa !23
  %t213 = lshr i32 %t212, 16
  %t214 = and i32 %t212, 65535
  %t215 = icmp eq i32 %t213, 1
  %t216 = select i1 %t215, i32 1, i32 0
  %t217 = icmp eq i32 %t212, 0
  %t218 = shl i32 %t216, 16
  %t219 = or i32 %t218, %t214
  %t220 = select i1 %t217, i32 0, i32 %t219
  call void @__olang_scope_close(ptr %s0)
  %t222 = insertvalue { i32, ptr } zeroinitializer, i32 %t220, 0
  store { i32, ptr } %t222, ptr %rv
  br label %ret
bb51:
  %t223 = load ptr, ptr %l78, !tbaa !29
  store ptr %t223, ptr %l8, !tbaa !29
  %t224 = load ptr, ptr %l0, !tbaa !29
  %t225 = load i32, ptr %l1, !tbaa !23
  %t228 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t224, i32 %t225)
  store %"compiler/source:Span" %t228, ptr %l85
  br label %bb52
bb52:
  %t229 = load %"compiler/source:Span", ptr %l85
  store %"compiler/source:Span" %t229, ptr %l9
  %t230 = load ptr, ptr %l0, !tbaa !29
  %t232 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eendStmt(ptr %v0, ptr %t230)
  store i32 %t232, ptr %l87
  %t233 = icmp ne i32 %t232, 0
  br i1 %t233, label %bb54, label %ok.234, !prof !99
ok.234:
  br label %bb53
bb53:
  br label %bb55
bb54:
  %t235 = load i32, ptr %l87, !tbaa !23
  %t236 = lshr i32 %t235, 16
  %t237 = and i32 %t235, 65535
  %t238 = icmp eq i32 %t236, 1
  %t239 = select i1 %t238, i32 1, i32 0
  %t240 = icmp eq i32 %t235, 0
  %t241 = shl i32 %t239, 16
  %t242 = or i32 %t241, %t237
  %t243 = select i1 %t240, i32 0, i32 %t242
  call void @__olang_scope_close(ptr %s0)
  %t245 = insertvalue { i32, ptr } zeroinitializer, i32 %t243, 0
  store { i32, ptr } %t245, ptr %rv
  br label %ret
bb55:
  %t246 = load %"compiler/source:Span", ptr %l9
  store %"compiler/source:Span" %t246, ptr %l89
  %t247 = load ptr, ptr %lp5
  %t248 = load i32, ptr %l6, !tbaa !23
  %t249 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t250 = load ptr, ptr %l8, !tbaa !29
  %t255 = call %"compiler/ast:MemberDecl" @compiler_2fast_3aMemberDecl_2ector(ptr %v1, ptr %v1, ptr %v1, ptr %v1, ptr %t247, i32 %t248, { i64, ptr } %t249, ptr %t250)
  store %"compiler/ast:MemberDecl" %t255, ptr %l94
  br label %bb56
bb56:
  %t256 = load %"compiler/ast:MemberDecl", ptr %l94
  %t257 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 40, i64 8)
  store %"compiler/ast:MemberDecl" %t256, ptr %t257
  store { i64, [8 x i64] } zeroinitializer, ptr %t258
  %t259 = getelementptr { i64, [8 x i64] }, ptr %t258, i32 0, i32 0
  store i64 3, ptr %t259
  %t260 = load %"compiler/source:Span", ptr %l89
  %t261 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t260, 0
  %t263 = insertvalue { %"compiler/source:Span", ptr } %t261, ptr %t257, 1
  %t264 = getelementptr { i64, [8 x i64] }, ptr %t258, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t263, ptr %t264
  %t265 = load { i64, [8 x i64] }, ptr %t258
  %t267 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 72, i64 8)
  store { i64, [8 x i64] } %t265, ptr %t267
  call void @__olang_scope_close(ptr %s0)
  %t269 = insertvalue { i32, ptr } zeroinitializer, ptr %t267, 1
  store { i32, ptr } %t269, ptr %rv
  br label %ret
bb57:
  %t270 = load ptr, ptr %l0, !tbaa !29
  %t272 = getelementptr %"compiler/parse:Parser", ptr %t270, i32 0, i32 2
  %t273 = load ptr, ptr %t272, !tbaa !29
  store ptr %t273, ptr %l99, !tbaa !29
  %t274 = load ptr, ptr %l0, !tbaa !29
  %t276 = getelementptr %"compiler/parse:Parser", ptr %t274, i32 0, i32 2
  %t277 = load ptr, ptr %t276, !tbaa !29
  %t278 = load i32, ptr %l3, !tbaa !23
  %t281 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %s0, ptr %t277, i32 %t278)
  store { i64, ptr } %t281, ptr %l103
  br label %bb58
bb58:
  %t282 = load ptr, ptr %l0, !tbaa !29
  %t284 = getelementptr %"compiler/parse:Parser", ptr %t282, i32 0, i32 2
  %t285 = load ptr, ptr %t284, !tbaa !29
  %t286 = load i32, ptr %l6, !tbaa !23
  %t289 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %s0, ptr %t285, i32 %t286)
  store { i64, ptr } %t289, ptr %l107
  br label %bb59
bb59:
  %t290 = load { i64, ptr }, ptr %l103, !tbaa !27
  %t291 = extractvalue { i64, ptr } %t290, 1
  %t292 = extractvalue { i64, ptr } %t290, 0
  %t293 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d13, i32 0, i32 1) }, 1
  %t294 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d13, i32 0, i32 1) }, 0
  %t295 = add i64 %t292, %t294
  %t296 = load { i64, ptr }, ptr %l107, !tbaa !27
  %t297 = extractvalue { i64, ptr } %t296, 1
  %t298 = extractvalue { i64, ptr } %t296, 0
  %t299 = add i64 %t295, %t298
  %t300 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t299)
  call void @olang_textcopy(ptr %t300, ptr %t291, i64 %t292)
  %t301 = getelementptr i8, ptr %t300, i64 %t292
  call void @olang_textcopy(ptr %t301, ptr %t293, i64 %t294)
  %t302 = getelementptr i8, ptr %t301, i64 %t294
  call void @olang_textcopy(ptr %t302, ptr %t297, i64 %t298)
  %t303 = insertvalue { i64, ptr } undef, i64 %t299, 0
  %t304 = insertvalue { i64, ptr } %t303, ptr %t300, 1
  %t306 = load ptr, ptr %l99, !tbaa !29
  %t308 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %s0, ptr %t306, { i64, ptr } %t304)
  store i32 %t308, ptr %l110
  br label %bb60
bb60:
  %t309 = load i32, ptr %l110, !tbaa !23
  store i32 %t309, ptr %l10, !tbaa !23
  %t310 = load ptr, ptr %l0, !tbaa !29
  %t311 = load i32, ptr %l1, !tbaa !23
  %t312 = load i32, ptr %l10, !tbaa !23
  %t316 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeDeclRest(ptr %v0, ptr %v1, ptr %t310, i32 %t311, i32 %t312)
  %t317 = extractvalue { i32, ptr } %t316, 1
  %t318 = extractvalue { i32, ptr } %t316, 0
  store i32 %t318, ptr %l116
  %t319 = icmp ne i32 %t318, 0
  br i1 %t319, label %bb62, label %ok.320, !prof !99
ok.320:
  store ptr %t317, ptr %l115
  br label %bb61
bb61:
  %t321 = load ptr, ptr %l115, !tbaa !29
  store ptr %t321, ptr %l111, !tbaa !29
  br label %bb71
bb62:
  br label %bb63
bb63:
  %t322 = load ptr, ptr %l0, !tbaa !29
  %t324 = getelementptr %"compiler/parse:Parser", ptr %t322, i32 0, i32 42
  store ptr %t324, ptr %l118, !tbaa !29
  %t325 = load ptr, ptr %l0, !tbaa !29
  %t326 = load i32, ptr %l1, !tbaa !23
  %t329 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t325, i32 %t326)
  store %"compiler/source:Span" %t329, ptr %l121
  br label %bb64
bb64:
  %t330 = load i32, ptr %l10, !tbaa !23
  store i32 %t330, ptr %l122, !tbaa !23
  %t331 = icmp sge i64 0, 0
  br i1 %t331, label %bb65, label %bb66
bb65:
  %t333 = icmp sle i64 0, 1152921504606846975
  br i1 %t333, label %bb67, label %bb68
bb66:
  call void @__olang_check_failed(ptr @olang_loc_4993d3303aa01823_1a4b1af8a16484ff)
  unreachable
bb67:
  %t335 = mul i64 0, 8
  %t336 = insertvalue { i64, ptr } undef, i64 0, 0
  %t337 = insertvalue { i64, ptr } %t336, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t338 = load ptr, ptr %lp5
  %t339 = load i32, ptr %l6, !tbaa !23
  %t340 = load i32, ptr %l122, !tbaa !23
  %t345 = call %"compiler/ast:TypeDecl" @compiler_2fast_3aTypeDecl_2ector(ptr %v0, ptr %v0, ptr %v1, ptr %v0, i32 %t340, { i64, ptr } %t337, i1 false, ptr null, i32 0, i1 false, ptr %t338, i32 %t339)
  store %"compiler/ast:TypeDecl" %t345, ptr %l129
  br label %bb69
bb68:
  call void @__olang_check_failed(ptr @olang_loc_4993d3303aa01823_1a4b1af8a16484ff)
  unreachable
bb69:
  %t346 = load %"compiler/ast:TypeDecl", ptr %l129
  %t347 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 64, i64 8)
  store %"compiler/ast:TypeDecl" %t346, ptr %t347
  store { i64, [8 x i64] } zeroinitializer, ptr %t348
  %t349 = getelementptr { i64, [8 x i64] }, ptr %t348, i32 0, i32 0
  store i64 2, ptr %t349
  %t350 = load %"compiler/source:Span", ptr %l121
  %t351 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t350, 0
  %t353 = insertvalue { %"compiler/source:Span", ptr } %t351, ptr %t347, 1
  %t354 = getelementptr { i64, [8 x i64] }, ptr %t348, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t353, ptr %t354
  %t355 = load { i64, [8 x i64] }, ptr %t348
  %t357 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 72, i64 8)
  store { i64, [8 x i64] } %t355, ptr %t357
  %t358 = load ptr, ptr %l118, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aDecl_26_3e_2ePush_3ccompiler_2fast_3aDecl_26_3e(ptr %v0, ptr %v0, ptr %t358, ptr %t357)
  br label %bb70
bb70:
  call void @__olang_scope_close(ptr %s0)
  %t361 = insertvalue { i32, ptr } zeroinitializer, i32 65536, 0
  store { i32, ptr } %t361, ptr %rv
  br label %ret
bb71:
  %t362 = load ptr, ptr %l111, !tbaa !29
  store ptr %t362, ptr %l11, !tbaa !29
  %t363 = load ptr, ptr %l11, !tbaa !29
  store ptr %t363, ptr %l134, !tbaa !29
  store i1 false, ptr %l135, !tbaa !21
  %t364 = load ptr, ptr %l134, !tbaa !29
  %t365 = icmp ne ptr %t364, null
  br i1 %t365, label %bb72, label %bb73
bb72:
  %t367 = load ptr, ptr %l134, !tbaa !29
  %t368 = load i64, ptr %t367, !range !{i64 0, i64 12}
  %t370 = icmp eq i64 %t368, 2
  store i1 %t370, ptr %l135, !tbaa !21
  br label %bb73
bb73:
  %t371 = load i1, ptr %l135, !tbaa !21
  br i1 %t371, label %bb74, label %bb75
bb74:
  %t372 = load ptr, ptr %l11, !tbaa !29
  %t374 = getelementptr { i64, [8 x i64] }, ptr %t372, i32 0, i32 1
  %t375 = getelementptr { %"compiler/source:Span", ptr }, ptr %t374, i32 0, i32 0
  %t376 = load %"compiler/source:Span", ptr %t375
  store %"compiler/source:Span" %t376, ptr %l12
  %t378 = load ptr, ptr %l11, !tbaa !29
  %t380 = getelementptr { i64, [8 x i64] }, ptr %t378, i32 0, i32 1
  %t381 = getelementptr { %"compiler/source:Span", ptr }, ptr %t380, i32 0, i32 1
  %t382 = load ptr, ptr %t381
  store ptr %t382, ptr %l13, !tbaa !29
  br label %bb76
bb75:
  br label %bb78
bb76:
  %t384 = load %"compiler/source:Span", ptr %l12
  store %"compiler/source:Span" %t384, ptr %l142
  %t385 = load ptr, ptr %l13, !tbaa !29
  %t387 = getelementptr %"compiler/ast:TypeDecl", ptr %t385, i32 0, i32 0
  %t388 = load i32, ptr %t387, !tbaa !23
  %t389 = load ptr, ptr %l13, !tbaa !29
  %t391 = getelementptr %"compiler/ast:TypeDecl", ptr %t389, i32 0, i32 1
  %t392 = load { i64, ptr }, ptr %t391, !tbaa !27
  %t393 = load ptr, ptr %l13, !tbaa !29
  %t395 = getelementptr %"compiler/ast:TypeDecl", ptr %t393, i32 0, i32 2
  %t396 = load i1, ptr %t395, !tbaa !21
  %t397 = load ptr, ptr %l13, !tbaa !29
  %t399 = getelementptr %"compiler/ast:TypeDecl", ptr %t397, i32 0, i32 3
  %t400 = load ptr, ptr %t399, !tbaa !29
  %t401 = load ptr, ptr %l13, !tbaa !29
  %t403 = getelementptr %"compiler/ast:TypeDecl", ptr %t401, i32 0, i32 4
  %t404 = load i32, ptr %t403, !range !{i32 0, i32 3}
  %t405 = load ptr, ptr %l13, !tbaa !29
  %t407 = getelementptr %"compiler/ast:TypeDecl", ptr %t405, i32 0, i32 5
  %t408 = load i1, ptr %t407, !tbaa !21
  %t409 = load ptr, ptr %lp5
  %t410 = load i32, ptr %l6, !tbaa !23
  %t419 = call %"compiler/ast:TypeDecl" @compiler_2fast_3aTypeDecl_2ector(ptr %v1, ptr %v1, ptr %v1, ptr %v1, i32 %t388, { i64, ptr } %t392, i1 %t396, ptr %t400, i32 %t404, i1 %t408, ptr %t409, i32 %t410)
  store %"compiler/ast:TypeDecl" %t419, ptr %l157
  br label %bb77
bb77:
  %t420 = load %"compiler/ast:TypeDecl", ptr %l157
  %t421 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 64, i64 8)
  store %"compiler/ast:TypeDecl" %t420, ptr %t421
  store { i64, [8 x i64] } zeroinitializer, ptr %t422
  %t423 = getelementptr { i64, [8 x i64] }, ptr %t422, i32 0, i32 0
  store i64 2, ptr %t423
  %t424 = load %"compiler/source:Span", ptr %l142
  %t425 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t424, 0
  %t427 = insertvalue { %"compiler/source:Span", ptr } %t425, ptr %t421, 1
  %t428 = getelementptr { i64, [8 x i64] }, ptr %t422, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t427, ptr %t428
  %t429 = load { i64, [8 x i64] }, ptr %t422
  %t431 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 72, i64 8)
  store { i64, [8 x i64] } %t429, ptr %t431
  call void @__olang_scope_close(ptr %s0)
  %t433 = insertvalue { i32, ptr } zeroinitializer, ptr %t431, 1
  store { i32, ptr } %t433, ptr %rv
  br label %ret
bb78:
  br i1 true, label %bb79, label %bb80
bb79:
  br label %bb81
bb80:
  br label %bb82
bb81:
  %t434 = load ptr, ptr %l11, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  %t436 = insertvalue { i32, ptr } zeroinitializer, ptr %t434, 1
  store { i32, ptr } %t436, ptr %rv
  br label %ret
bb82:
  call void @__olang_check_failed(ptr @olang_loc_951c2a70c5fd1ae3_7af085225755068f)
  unreachable
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2emessageHere(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l3 = alloca i1
  %l6 = alloca i32
  %l7 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ebreakBefore(ptr %v0, ptr %t1)
  store i1 %t3, ptr %l3
  br label %bb1
bb1:
  %t4 = load i1, ptr %l3, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  store i1 false, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2epeek(ptr %v0, ptr %t6)
  store i32 %t8, ptr %l6
  br label %bb5
bb5:
  %t9 = load i32, ptr %l6, !range !{i32 0, i32 116}
  store i32 %t9, ptr %l1
  %t10 = load i32, ptr %l1, !range !{i32 0, i32 116}
  %t12 = trunc i64 5 to i32
  %t13 = icmp eq i32 %t10, %t12
  br i1 %t13, label %bb6, label %bb7
bb6:
  br label %bb16
bb7:
  %t15 = load i32, ptr %l1, !range !{i32 0, i32 116}
  %t17 = trunc i64 107 to i32
  %t18 = icmp eq i32 %t15, %t17
  br i1 %t18, label %bb8, label %bb9
bb8:
  br label %bb16
bb9:
  %t20 = load i32, ptr %l1, !range !{i32 0, i32 116}
  %t22 = trunc i64 1 to i32
  %t23 = icmp eq i32 %t20, %t22
  br i1 %t23, label %bb10, label %bb11
bb10:
  br label %bb16
bb11:
  %t25 = load i32, ptr %l1, !range !{i32 0, i32 116}
  %t27 = trunc i64 110 to i32
  %t28 = icmp eq i32 %t25, %t27
  br i1 %t28, label %bb12, label %bb13
bb12:
  br label %bb16
bb13:
  %t30 = load i32, ptr %l1, !range !{i32 0, i32 116}
  %t32 = trunc i64 2 to i32
  %t33 = icmp eq i32 %t30, %t32
  br i1 %t33, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb17
bb16:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb32
bb17:
  %t35 = load i32, ptr %l1, !range !{i32 0, i32 116}
  %t37 = trunc i64 3 to i32
  %t38 = icmp eq i32 %t35, %t37
  br i1 %t38, label %bb18, label %bb19
bb18:
  br label %bb26
bb19:
  %t40 = load i32, ptr %l1, !range !{i32 0, i32 116}
  %t42 = trunc i64 4 to i32
  %t43 = icmp eq i32 %t40, %t42
  br i1 %t43, label %bb20, label %bb21
bb20:
  br label %bb26
bb21:
  %t45 = load i32, ptr %l1, !range !{i32 0, i32 116}
  %t47 = trunc i64 6 to i32
  %t48 = icmp eq i32 %t45, %t47
  br i1 %t48, label %bb22, label %bb23
bb22:
  br label %bb26
bb23:
  %t50 = load i32, ptr %l1, !range !{i32 0, i32 116}
  %t52 = trunc i64 7 to i32
  %t53 = icmp eq i32 %t50, %t52
  br i1 %t53, label %bb24, label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb27
bb26:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb32
bb27:
  br i1 true, label %bb28, label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb31
bb30:
  store i1 false, ptr %l7, !tbaa !21
  br label %bb32
bb31:
  call void @__olang_check_failed(ptr @olang_loc_2c371f21e588b068_13da37aea4ea5bc)
  unreachable
bb32:
  %t55 = load i1, ptr %l7, !tbaa !21
  store i1 %t55, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2enamesBareType(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i1
  %l4 = alloca ptr
  %l5 = alloca i1
  %l14 = alloca i1
  %rv = alloca i1
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 28}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32 }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t18 = getelementptr %"compiler/parse:Parser", ptr %a0, i32 0, i32 3
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t21 = getelementptr %"compiler/parse:Oracle", ptr %t19, i32 0, i32 0
  %t22 = load i32, ptr %l2, !tbaa !23
  %t25 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3_H8da9376267bda3f76393292be0e507b2(ptr %v0, ptr %t21, i32 %t22)
  store i1 %t25, ptr %l14
  br label %bb6
bb6:
  %t26 = load i1, ptr %l14, !tbaa !21
  store i1 %t26, ptr %l3, !tbaa !21
  br label %bb12
bb7:
  br i1 true, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb11
bb10:
  store i1 false, ptr %l3, !tbaa !21
  br label %bb12
bb11:
  call void @__olang_check_failed(ptr @olang_loc_caaeb8844a43a47_292034e417eae4cb)
  unreachable
bb12:
  %t27 = load i1, ptr %l3, !tbaa !21
  store i1 %t27, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eoldPiece(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l4 = alloca i1
  %l6 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca i32
  %l12 = alloca i32
  %l14 = alloca i32
  %l18 = alloca i32
  %l21 = alloca %"compiler/source:Span"
  %rv = alloca { i32, ptr }
  %t59 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t4 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t1, i32 5)
  store i1 %t4, ptr %l4
  br label %bb1
bb1:
  %t5 = load i1, ptr %l4, !tbaa !21
  %t6 = xor i1 %t5, true
  br i1 %t6, label %bb2, label %bb3
bb2:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2erendering(ptr %v0, ptr %v1, ptr %t8)
  %t11 = extractvalue { i32, ptr } %t10, 1
  %t12 = extractvalue { i32, ptr } %t10, 0
  store i32 %t12, ptr %l9
  %t13 = icmp ne i32 %t12, 0
  br i1 %t13, label %bb5, label %ok.14, !prof !99
ok.14:
  store ptr %t11, ptr %l8
  br label %bb4
bb3:
  br label %bb7
bb4:
  %t15 = load ptr, ptr %l8, !tbaa !29
  store ptr %t15, ptr %l6, !tbaa !29
  br label %bb6
bb5:
  %t16 = load i32, ptr %l9, !tbaa !23
  %t17 = lshr i32 %t16, 16
  %t18 = and i32 %t16, 65535
  %t19 = icmp eq i32 %t17, 1
  %t20 = select i1 %t19, i32 1, i32 0
  %t21 = icmp eq i32 %t16, 0
  %t22 = shl i32 %t20, 16
  %t23 = or i32 %t22, %t18
  %t24 = select i1 %t21, i32 0, i32 %t23
  %t26 = insertvalue { i32, ptr } zeroinitializer, i32 %t24, 0
  store { i32, ptr } %t26, ptr %rv
  br label %ret
bb6:
  %t27 = load ptr, ptr %l6, !tbaa !29
  %t28 = insertvalue { i32, ptr } zeroinitializer, ptr %t27, 1
  store { i32, ptr } %t28, ptr %rv
  br label %ret
bb7:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ehere(ptr %v0, ptr %t29)
  store i32 %t31, ptr %l12
  br label %bb8
bb8:
  %t32 = load i32, ptr %l12, !tbaa !23
  store i32 %t32, ptr %l1, !tbaa !23
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eenter(ptr %v0, ptr %t33)
  store i32 %t35, ptr %l14
  %t36 = icmp ne i32 %t35, 0
  br i1 %t36, label %bb10, label %ok.37, !prof !99
ok.37:
  br label %bb9
bb9:
  br label %bb11
bb10:
  %t38 = load i32, ptr %l14, !tbaa !23
  %t39 = lshr i32 %t38, 16
  %t40 = and i32 %t38, 65535
  %t41 = icmp eq i32 %t39, 1
  %t42 = select i1 %t41, i32 1, i32 0
  %t43 = icmp eq i32 %t38, 0
  %t44 = shl i32 %t42, 16
  %t45 = or i32 %t44, %t40
  %t46 = select i1 %t43, i32 0, i32 %t45
  %t48 = insertvalue { i32, ptr } zeroinitializer, i32 %t46, 0
  store { i32, ptr } %t48, ptr %rv
  br label %ret
bb11:
  %t49 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2eleave(ptr %v0, ptr %t49)
  br label %bb12
bb12:
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t51)
  store i32 %t53, ptr %l18
  br label %bb13
bb13:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t55 = load i32, ptr %l1, !tbaa !23
  %t58 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t54, i32 %t55)
  store %"compiler/source:Span" %t58, ptr %l21
  br label %bb14
bb14:
  store { i64, [4 x i64] } zeroinitializer, ptr %t59
  %t60 = getelementptr { i64, [4 x i64] }, ptr %t59, i32 0, i32 0
  store i64 1, ptr %t60
  %t61 = load %"compiler/source:Span", ptr %l21
  %t62 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t61, 0
  %t64 = insertvalue { %"compiler/source:Span", i32 } %t62, i32 5, 1
  %t65 = getelementptr { i64, [4 x i64] }, ptr %t59, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t64, ptr %t65
  %t66 = load { i64, [4 x i64] }, ptr %t59
  %t68 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 40, i64 8)
  store { i64, [4 x i64] } %t66, ptr %t68
  %t70 = insertvalue { i32, ptr } zeroinitializer, ptr %t68, 1
  store { i32, ptr } %t70, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2epackedWord(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l4 = alloca i1
  %l9 = alloca { i64, ptr }
  %l11 = alloca i64
  %l16 = alloca i32
  %l21 = alloca i1
  %l25 = alloca i1
  %l29 = alloca i1
  %l34 = alloca ptr
  %l36 = alloca i32
  %l38 = alloca %"compiler/token:Token"
  %l39 = alloca i32
  %l40 = alloca %"compiler/diagmsg:Msg"
  %l42 = alloca i32
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t4 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t1, i32 55)
  store i1 %t4, ptr %l4
  br label %bb1
bb1:
  %t5 = load i1, ptr %l4, !tbaa !21
  %t6 = xor i1 %t5, true
  br i1 %t6, label %bb2, label %bb3
bb2:
  store i1 false, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/parse:Parser", ptr %t9, i32 0, i32 1
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t14 = getelementptr %"compiler/scan:Tokens", ptr %t12, i32 0, i32 0
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  store { i64, ptr } %t15, ptr %l9, !tbaa !27
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = call i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eafter(ptr %v0, ptr %t16, i64 1)
  store i64 %t18, ptr %l11
  br label %bb5
bb5:
  %t19 = load i64, ptr %l11, !tbaa !24
  %t20 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = getelementptr %"compiler/token:Token", ptr %t21, i64 %t19
  %t23 = getelementptr %"compiler/token:Token", ptr %t22, i32 0, i32 0
  %t24 = load i32, ptr %t23, !range !{i32 0, i32 116}
  store i32 %t24, ptr %l1
  %t26 = load i32, ptr %l1, !range !{i32 0, i32 116}
  %t28 = trunc i64 34 to i32
  %t29 = icmp eq i32 %t26, %t28
  br i1 %t29, label %bb6, label %bb7
bb6:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t31)
  store i32 %t33, ptr %l16
  br label %bb8
bb7:
  br label %bb9
bb8:
  store i1 true, ptr %rv
  br label %ret
bb9:
  %t35 = load i32, ptr %l1, !range !{i32 0, i32 116}
  %t37 = trunc i64 35 to i32
  %t38 = icmp eq i32 %t35, %t37
  %t40 = xor i1 %t38, true
  br i1 %t40, label %bb10, label %bb11
bb10:
  %t42 = load i32, ptr %l1, !range !{i32 0, i32 116}
  %t44 = trunc i64 22 to i32
  %t45 = icmp eq i32 %t42, %t44
  %t47 = xor i1 %t45, true
  store i1 %t47, ptr %l21, !tbaa !21
  br label %bb12
bb11:
  store i1 false, ptr %l21, !tbaa !21
  br label %bb12
bb12:
  %t49 = load i1, ptr %l21, !tbaa !21
  br i1 %t49, label %bb13, label %bb14
bb13:
  %t50 = load i32, ptr %l1, !range !{i32 0, i32 116}
  %t52 = trunc i64 36 to i32
  %t53 = icmp eq i32 %t50, %t52
  %t55 = xor i1 %t53, true
  store i1 %t55, ptr %l25, !tbaa !21
  br label %bb15
bb14:
  store i1 false, ptr %l25, !tbaa !21
  br label %bb15
bb15:
  %t57 = load i1, ptr %l25, !tbaa !21
  br i1 %t57, label %bb16, label %bb17
bb16:
  %t58 = load i32, ptr %l1, !range !{i32 0, i32 116}
  %t60 = trunc i64 38 to i32
  %t61 = icmp eq i32 %t58, %t60
  %t63 = xor i1 %t61, true
  store i1 %t63, ptr %l29, !tbaa !21
  br label %bb18
bb17:
  store i1 false, ptr %l29, !tbaa !21
  br label %bb18
bb18:
  %t65 = load i1, ptr %l29, !tbaa !21
  br i1 %t65, label %bb19, label %bb20
bb19:
  store i1 false, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  %t67 = load ptr, ptr %l0, !tbaa !29
  store ptr %t67, ptr %l34, !tbaa !29
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ehere(ptr %v0, ptr %t68)
  store i32 %t70, ptr %l36
  br label %bb22
bb22:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2etk(ptr %v0, ptr %t71)
  store %"compiler/token:Token" %t73, ptr %l38
  br label %bb23
bb23:
  %t74 = getelementptr %"compiler/token:Token", ptr %l38, i32 0, i32 3
  %t75 = load i32, ptr %t74, !tbaa !23
  store i32 %t75, ptr %l39, !tbaa !23
  %t76 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePackedNotStruct(ptr %v0)
  store %"compiler/diagmsg:Msg" %t76, ptr %l40
  br label %bb24
bb24:
  %t77 = load ptr, ptr %l34, !tbaa !29
  %t78 = load i32, ptr %l36, !tbaa !23
  %t79 = load i32, ptr %l39, !tbaa !23
  %t80 = load %"compiler/diagmsg:Msg", ptr %l40
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereport(ptr %v0, ptr %v0, ptr %t77, i32 %t78, i32 %t79, %"compiler/diagmsg:Msg" %t80)
  br label %bb25
bb25:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t81)
  store i32 %t83, ptr %l42
  br label %bb26
bb26:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eparams(ptr %v0, ptr %v1, ptr %a0, i1 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i1
  %l4 = alloca i1
  %l5 = alloca i1
  %l6 = alloca i1
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca ptr
  %l35 = alloca i1
  %l39 = alloca i1
  %l41 = alloca i1
  %l45 = alloca i64
  %l48 = alloca i64
  %l67 = alloca i32
  %l73 = alloca ptr
  %l74 = alloca ptr
  %l77 = alloca ptr
  %l78 = alloca i32
  %l82 = alloca i1
  %l85 = alloca i1
  %l86 = alloca i32
  %l93 = alloca ptr
  %l97 = alloca i32
  %l100 = alloca i32
  %l101 = alloca i32
  %l108 = alloca { i64, ptr }
  %rv = alloca { i32, { i64, ptr } }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/parse:Parser", ptr %t1, i32 0, i32 37
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aParam_26_3e_2eLen_3ccompiler_2fast_3aParam_26_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l16
  br label %bb1
bb1:
  %t6 = load i64, ptr %l16, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  store ptr %t7, ptr %l17, !tbaa !29
  %t8 = load ptr, ptr %l17, !tbaa !29
  %t9 = getelementptr %"compiler/parse:Parser", ptr %t8, i32 0, i32 21
  %t10 = load i64, ptr %t9, !tbaa !24
  %t13 = add i64 %t10, 1
  %t15 = load ptr, ptr %l17, !tbaa !29
  %t16 = getelementptr %"compiler/parse:Parser", ptr %t15, i32 0, i32 21
  store i64 %t13, ptr %t16, !tbaa !24
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/parse:Parser", ptr %t17, i32 0, i32 22
  %t20 = load i1, ptr %t19, !tbaa !21
  store i1 %t20, ptr %l3, !tbaa !21
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/parse:Parser", ptr %t22, i32 0, i32 23
  %t25 = load i1, ptr %t24, !tbaa !21
  store i1 %t25, ptr %l4, !tbaa !21
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/parse:Parser", ptr %t27, i32 0, i32 22
  store i1 false, ptr %t29, !tbaa !21
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/parse:Parser", ptr %t30, i32 0, i32 23
  store i1 true, ptr %t32, !tbaa !21
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/parse:Parser", ptr %t33, i32 0, i32 58
  %t36 = load i1, ptr %t35, !tbaa !21
  store i1 %t36, ptr %l5, !tbaa !21
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/parse:Parser", ptr %t38, i32 0, i32 58
  store i1 false, ptr %t40, !tbaa !21
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/parse:Parser", ptr %t41, i32 0, i32 61
  %t44 = load i1, ptr %t43, !tbaa !21
  store i1 %t44, ptr %l6, !tbaa !21
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/parse:Parser", ptr %t46, i32 0, i32 61
  store i1 false, ptr %t48, !tbaa !21
  br label %bb2
bb2:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t52 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t49, i32 111)
  store i1 %t52, ptr %l35
  br label %bb3
bb3:
  %t53 = load i1, ptr %l35, !tbaa !21
  %t54 = xor i1 %t53, true
  %t56 = xor i1 %t54, true
  br i1 %t56, label %bb4, label %bb5
bb4:
  br label %bb38
bb5:
  br label %bb6
bb6:
  %t58 = load i1, ptr %l5, !tbaa !21
  br i1 %t58, label %bb7, label %bb8
bb7:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eellipsis(ptr %v0, ptr %t60)
  store i1 %t62, ptr %l41
  br label %bb9
bb8:
  store i1 false, ptr %l39, !tbaa !21
  br label %bb10
bb9:
  %t63 = load i1, ptr %l41, !tbaa !21
  store i1 %t63, ptr %l39, !tbaa !21
  br label %bb10
bb10:
  %t64 = load i1, ptr %l39, !tbaa !21
  br i1 %t64, label %bb11, label %bb12
bb11:
  store i64 0, ptr %l7, !tbaa !24
  store i64 3, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t65 = load i64, ptr %l8, !tbaa !24
  %t66 = load i64, ptr %l7, !tbaa !24
  %t69 = icmp sgt i64 %t65, %t66
  br i1 %t69, label %bb13, label %bb14
bb12:
  br label %bb26
bb13:
  %t71 = load i64, ptr %l9, !tbaa !24
  %t73 = icmp sgt i64 %t71, 0
  br i1 %t73, label %bb15, label %bb16
bb14:
  store i64 0, ptr %l45, !tbaa !24
  br label %bb18
bb15:
  %t75 = load i64, ptr %l8, !tbaa !24
  %t76 = load i64, ptr %l7, !tbaa !24
  %t79 = sub i64 %t75, %t76
  %t80 = load i64, ptr %l9, !tbaa !24
  %t83 = add i64 %t79, %t80
  %t85 = sub i64 %t83, 1
  %t86 = load i64, ptr %l9, !tbaa !24
  %t89 = sdiv i64 %t85, %t86
  store i64 %t89, ptr %l48, !tbaa !24
  br label %bb17
bb16:
  store i64 0, ptr %l48, !tbaa !24
  br label %bb17
bb17:
  %t91 = load i64, ptr %l48, !tbaa !24
  store i64 %t91, ptr %l45, !tbaa !24
  br label %bb18
bb18:
  %t92 = load i64, ptr %l45, !tbaa !24
  store i64 %t92, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb19
bb19:
  %t93 = load i64, ptr %l11, !tbaa !24
  %t94 = load i64, ptr %l10, !tbaa !24
  %t97 = icmp slt i64 %t93, %t94
  %t99 = xor i1 %t97, true
  br i1 %t99, label %bb20, label %bb21
bb20:
  br label %bb25
bb21:
  br label %bb22
bb22:
  %t101 = load i64, ptr %l7, !tbaa !24
  %t102 = load i64, ptr %l11, !tbaa !24
  %t103 = load i64, ptr %l9, !tbaa !24
  %t106 = mul i64 %t102, %t103
  %t109 = add i64 %t101, %t106
  store i64 %t109, ptr %l12, !tbaa !24
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t113 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t111)
  store i32 %t113, ptr %l67
  br label %bb23
bb23:
  br label %bb24
bb24:
  %t114 = load i64, ptr %l11, !tbaa !24
  %t117 = add i64 %t114, 1
  store i64 %t117, ptr %l11, !tbaa !24
  br label %bb19
bb25:
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t121 = getelementptr %"compiler/parse:Parser", ptr %t119, i32 0, i32 59
  store i1 true, ptr %t121, !tbaa !21
  br label %bb38
bb26:
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t124 = getelementptr %"compiler/parse:Parser", ptr %t122, i32 0, i32 37
  store ptr %t124, ptr %l73, !tbaa !29
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t129 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eparam(ptr %v0, ptr %v0, ptr %t125, i1 %a1)
  %t130 = extractvalue { i32, ptr } %t129, 1
  %t131 = extractvalue { i32, ptr } %t129, 0
  store i32 %t131, ptr %l78
  %t132 = icmp ne i32 %t131, 0
  br i1 %t132, label %bb28, label %ok.133, !prof !99
ok.133:
  store ptr %t130, ptr %l77
  br label %bb27
bb27:
  %t134 = load ptr, ptr %l77, !tbaa !29
  store ptr %t134, ptr %l74, !tbaa !29
  br label %bb29
bb28:
  %t135 = load i32, ptr %l78, !tbaa !23
  %t136 = lshr i32 %t135, 16
  %t137 = and i32 %t135, 65535
  %t138 = icmp eq i32 %t136, 1
  %t139 = select i1 %t138, i32 1, i32 0
  %t140 = icmp eq i32 %t135, 0
  %t141 = shl i32 %t139, 16
  %t142 = or i32 %t141, %t137
  %t143 = select i1 %t140, i32 0, i32 %t142
  %t144 = load ptr, ptr %l0, !tbaa !29
  %t145 = load i1, ptr %l4, !tbaa !21
  %t148 = getelementptr %"compiler/parse:Parser", ptr %t144, i32 0, i32 23
  store i1 %t145, ptr %t148, !tbaa !21
  %t150 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t143, 0
  store { i32, { i64, ptr } } %t150, ptr %rv
  br label %ret
bb29:
  %t151 = load ptr, ptr %l73, !tbaa !29
  %t152 = load ptr, ptr %l74, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aParam_26_3e_2ePush_3ccompiler_2fast_3aParam_26_3e(ptr %v0, ptr %v0, ptr %t151, ptr %t152)
  br label %bb30
bb30:
  %t153 = load ptr, ptr %l0, !tbaa !29
  %t156 = call { i32, i1 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2esep(ptr %v0, ptr %t153, i32 111)
  %t157 = extractvalue { i32, i1 } %t156, 1
  %t158 = extractvalue { i32, i1 } %t156, 0
  store i32 %t158, ptr %l86
  %t159 = icmp ne i32 %t158, 0
  br i1 %t159, label %bb32, label %ok.160, !prof !99
ok.160:
  store i1 %t157, ptr %l85
  br label %bb31
bb31:
  %t161 = load i1, ptr %l85, !tbaa !21
  store i1 %t161, ptr %l82, !tbaa !21
  br label %bb33
bb32:
  %t162 = load i32, ptr %l86, !tbaa !23
  %t163 = lshr i32 %t162, 16
  %t164 = and i32 %t162, 65535
  %t165 = icmp eq i32 %t163, 1
  %t166 = select i1 %t165, i32 1, i32 0
  %t167 = icmp eq i32 %t162, 0
  %t168 = shl i32 %t166, 16
  %t169 = or i32 %t168, %t164
  %t170 = select i1 %t167, i32 0, i32 %t169
  %t171 = load ptr, ptr %l0, !tbaa !29
  %t172 = load i1, ptr %l4, !tbaa !21
  %t175 = getelementptr %"compiler/parse:Parser", ptr %t171, i32 0, i32 23
  store i1 %t172, ptr %t175, !tbaa !21
  %t177 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t170, 0
  store { i32, { i64, ptr } } %t177, ptr %rv
  br label %ret
bb33:
  %t178 = load i1, ptr %l82, !tbaa !21
  %t179 = xor i1 %t178, true
  br i1 %t179, label %bb34, label %bb35
bb34:
  br label %bb38
bb35:
  br label %bb36
bb36:
  br label %bb37
bb37:
  br label %bb2
bb38:
  %t181 = load ptr, ptr %l0, !tbaa !29
  %t182 = load i1, ptr %l3, !tbaa !21
  %t185 = getelementptr %"compiler/parse:Parser", ptr %t181, i32 0, i32 22
  store i1 %t182, ptr %t185, !tbaa !21
  %t186 = load ptr, ptr %l0, !tbaa !29
  store ptr %t186, ptr %l93, !tbaa !29
  %t187 = load ptr, ptr %l93, !tbaa !29
  %t188 = getelementptr %"compiler/parse:Parser", ptr %t187, i32 0, i32 21
  %t189 = load i64, ptr %t188, !tbaa !24
  %t192 = sub i64 %t189, 1
  %t194 = load ptr, ptr %l93, !tbaa !29
  %t195 = getelementptr %"compiler/parse:Parser", ptr %t194, i32 0, i32 21
  store i64 %t192, ptr %t195, !tbaa !24
  %t196 = load ptr, ptr %l0, !tbaa !29
  %t199 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %t196, i32 111)
  %t200 = extractvalue { i32, i32 } %t199, 1
  %t201 = extractvalue { i32, i32 } %t199, 0
  store i32 %t201, ptr %l101
  %t202 = icmp ne i32 %t201, 0
  br i1 %t202, label %bb40, label %ok.203, !prof !99
ok.203:
  store i32 %t200, ptr %l100
  br label %bb39
bb39:
  %t204 = load i32, ptr %l100, !tbaa !23
  store i32 %t204, ptr %l97, !tbaa !23
  br label %bb41
bb40:
  %t205 = load i32, ptr %l101, !tbaa !23
  %t206 = lshr i32 %t205, 16
  %t207 = and i32 %t205, 65535
  %t208 = icmp eq i32 %t206, 1
  %t209 = select i1 %t208, i32 1, i32 0
  %t210 = icmp eq i32 %t205, 0
  %t211 = shl i32 %t209, 16
  %t212 = or i32 %t211, %t207
  %t213 = select i1 %t210, i32 0, i32 %t212
  %t214 = load ptr, ptr %l0, !tbaa !29
  %t215 = load i1, ptr %l4, !tbaa !21
  %t218 = getelementptr %"compiler/parse:Parser", ptr %t214, i32 0, i32 23
  store i1 %t215, ptr %t218, !tbaa !21
  %t220 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t213, 0
  store { i32, { i64, ptr } } %t220, ptr %rv
  br label %ret
bb41:
  %t221 = load ptr, ptr %l0, !tbaa !29
  %t223 = getelementptr %"compiler/parse:Parser", ptr %t221, i32 0, i32 37
  %t224 = load i64, ptr %l2, !tbaa !24
  %t227 = call { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fast_3aParam_26_3e(ptr %v0, ptr %v1, ptr %t223, i64 %t224)
  store { i64, ptr } %t227, ptr %l108
  br label %bb42
bb42:
  %t228 = load { i64, ptr }, ptr %l108, !tbaa !27
  store { i64, ptr } %t228, ptr %l13, !tbaa !27
  %t229 = load ptr, ptr %l0, !tbaa !29
  %t230 = load { i64, ptr }, ptr %l13, !tbaa !27
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2etrailingDefaults(ptr %v0, ptr %v1, ptr %t229, { i64, ptr } %t230)
  br label %bb43
bb43:
  %t233 = load ptr, ptr %l0, !tbaa !29
  %t234 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t235 = load i1, ptr %l5, !tbaa !21
  %t236 = load ptr, ptr %l0, !tbaa !29
  %t238 = getelementptr %"compiler/parse:Parser", ptr %t236, i32 0, i32 60
  %t239 = load i1, ptr %t238, !tbaa !21
  %t240 = load i1, ptr %l6, !tbaa !21
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2espreadRules(ptr %v0, ptr %v1, ptr %t233, { i64, ptr } %t234, i1 %t235, i1 %t239, i1 %t240)
  br label %bb44
bb44:
  %t246 = load ptr, ptr %l0, !tbaa !29
  %t248 = getelementptr %"compiler/parse:Parser", ptr %t246, i32 0, i32 60
  store i1 false, ptr %t248, !tbaa !21
  %t249 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t250 = load ptr, ptr %l0, !tbaa !29
  %t251 = load i1, ptr %l4, !tbaa !21
  %t254 = getelementptr %"compiler/parse:Parser", ptr %t250, i32 0, i32 23
  store i1 %t251, ptr %t254, !tbaa !21
  %t256 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t249, 1
  store { i32, { i64, ptr } } %t256, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local ptr @compiler_2fparse_2ecompiler_2fparse_3aParser_2epattern(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i1 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca i32
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca %"compiler/source:Span"
  %l7 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l9 = alloca %"compiler/source:Span"
  %l10 = alloca ptr
  %l11 = alloca { i64, ptr }
  %l12 = alloca %"compiler/source:Span"
  %l13 = alloca { i64, ptr }
  %l14 = alloca %"compiler/source:Span"
  %l15 = alloca ptr
  %l16 = alloca i32
  %l17 = alloca ptr
  %l18 = alloca i1
  %l28 = alloca { i64, ptr }
  %l29 = alloca i1
  %l42 = alloca ptr
  %l43 = alloca i1
  %l52 = alloca ptr
  %l53 = alloca i1
  %l63 = alloca i1
  %l68 = alloca ptr
  %l73 = alloca ptr
  %l74 = alloca i1
  %l84 = alloca i1
  %l89 = alloca ptr
  %l94 = alloca ptr
  %l95 = alloca i1
  %l102 = alloca ptr
  %l103 = alloca i1
  %l114 = alloca ptr
  %l115 = alloca ptr
  %l116 = alloca i1
  %l123 = alloca ptr
  %l124 = alloca i1
  %l140 = alloca %"compiler/source:Span"
  %s1 = alloca %olang.scope
  %rv = alloca ptr
  %t34 = alloca { i64, [4 x i64] }, align 8
  %t47 = alloca { i64, [4 x i64] }, align 8
  %t60 = alloca { i64, [4 x i64] }, align 8
  %t88 = alloca { i64, [4 x i64] }, align 8
  %t142 = alloca { i64, [4 x i64] }, align 8
  %t196 = alloca { i64, [4 x i64] }, align 8
  %t301 = alloca { i64, [4 x i64] }, align 8
  %t314 = alloca { i64, [4 x i64] }, align 8
  %t329 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i1 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l17, !tbaa !29
  store i1 false, ptr %l18, !tbaa !21
  %t2 = load ptr, ptr %l17, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l17, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 28}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l18, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l18, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32 }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l3
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [4 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32 }, ptr %t18, i32 0, i32 1
  %t20 = load i32, ptr %t19
  store i32 %t20, ptr %l4, !tbaa !23
  br label %bb5
bb4:
  br label %bb14
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/parse:Parser", ptr %t22, i32 0, i32 2
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t26 = load i32, ptr %l4, !tbaa !23
  %t29 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %v0, ptr %t25, i32 %t26)
  store { i64, ptr } %t29, ptr %l28
  br label %bb6
bb6:
  %t30 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t31 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s1, { i64, ptr } %t30, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d14, i32 0, i32 1) })
  store i1 %t31, ptr %l29
  br label %bb7
bb7:
  %t32 = load i1, ptr %l29, !tbaa !21
  br i1 %t32, label %bb8, label %bb9
bb8:
  %t33 = load %"compiler/source:Span", ptr %l3
  store { i64, [4 x i64] } zeroinitializer, ptr %t34
  %t35 = getelementptr { i64, [4 x i64] }, ptr %t34, i32 0, i32 0
  store i64 0, ptr %t35
  %t37 = insertvalue { %"compiler/source:Span" } undef, %"compiler/source:Span" %t33, 0
  %t38 = getelementptr { i64, [4 x i64] }, ptr %t34, i32 0, i32 1
  store { %"compiler/source:Span" } %t37, ptr %t38
  %t39 = load { i64, [4 x i64] }, ptr %t34
  %t41 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 40, i64 8)
  store { i64, [4 x i64] } %t39, ptr %t41
  call void @__olang_scope_close(ptr %s1)
  store ptr %t41, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t43 = load i1, ptr %l2, !tbaa !21
  br i1 %t43, label %bb11, label %bb12
bb11:
  %t45 = load %"compiler/source:Span", ptr %l3
  %t46 = load ptr, ptr %l1, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t47
  %t48 = getelementptr { i64, [4 x i64] }, ptr %t47, i32 0, i32 0
  store i64 1, ptr %t48
  %t50 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t45, 0
  %t52 = insertvalue { %"compiler/source:Span", ptr } %t50, ptr %t46, 1
  %t53 = getelementptr { i64, [4 x i64] }, ptr %t47, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t52, ptr %t53
  %t54 = load { i64, [4 x i64] }, ptr %t47
  %t56 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 40, i64 8)
  store { i64, [4 x i64] } %t54, ptr %t56
  call void @__olang_scope_close(ptr %s1)
  store ptr %t56, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  %t58 = load %"compiler/source:Span", ptr %l3
  %t59 = load i32, ptr %l4, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t60
  %t61 = getelementptr { i64, [4 x i64] }, ptr %t60, i32 0, i32 0
  store i64 3, ptr %t61
  %t63 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t58, 0
  %t65 = insertvalue { %"compiler/source:Span", i32 } %t63, i32 %t59, 1
  %t66 = getelementptr { i64, [4 x i64] }, ptr %t60, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t65, ptr %t66
  %t67 = load { i64, [4 x i64] }, ptr %t60
  %t69 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 40, i64 8)
  store { i64, [4 x i64] } %t67, ptr %t69
  call void @__olang_scope_close(ptr %s1)
  store ptr %t69, ptr %rv
  br label %ret
bb14:
  %t71 = load ptr, ptr %l1, !tbaa !29
  store ptr %t71, ptr %l42, !tbaa !29
  store i1 false, ptr %l43, !tbaa !21
  %t72 = load ptr, ptr %l42, !tbaa !29
  %t73 = icmp ne ptr %t72, null
  br i1 %t73, label %bb15, label %bb16
bb15:
  %t75 = load ptr, ptr %l42, !tbaa !29
  %t76 = load i64, ptr %t75, !range !{i64 0, i64 28}
  %t78 = icmp eq i64 %t76, 12
  store i1 %t78, ptr %l43, !tbaa !21
  br label %bb16
bb16:
  %t79 = load i1, ptr %l43, !tbaa !21
  br i1 %t79, label %bb17, label %bb18
bb17:
  %t80 = load ptr, ptr %l1, !tbaa !29
  %t82 = getelementptr { i64, [4 x i64] }, ptr %t80, i32 0, i32 1
  %t83 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t82, i32 0, i32 0
  %t84 = load %"compiler/source:Span", ptr %t83
  store %"compiler/source:Span" %t84, ptr %l5
  br label %bb19
bb18:
  br label %bb20
bb19:
  %t86 = load %"compiler/source:Span", ptr %l5
  %t87 = load ptr, ptr %l1, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t88
  %t89 = getelementptr { i64, [4 x i64] }, ptr %t88, i32 0, i32 0
  store i64 1, ptr %t89
  %t91 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t86, 0
  %t93 = insertvalue { %"compiler/source:Span", ptr } %t91, ptr %t87, 1
  %t94 = getelementptr { i64, [4 x i64] }, ptr %t88, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t93, ptr %t94
  %t95 = load { i64, [4 x i64] }, ptr %t88
  %t97 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 40, i64 8)
  store { i64, [4 x i64] } %t95, ptr %t97
  store ptr %t97, ptr %rv
  br label %ret
bb20:
  %t99 = load ptr, ptr %l1, !tbaa !29
  store ptr %t99, ptr %l52, !tbaa !29
  store i1 false, ptr %l53, !tbaa !21
  %t100 = load ptr, ptr %l52, !tbaa !29
  %t101 = icmp ne ptr %t100, null
  br i1 %t101, label %bb21, label %bb22
bb21:
  %t103 = load ptr, ptr %l52, !tbaa !29
  %t104 = load i64, ptr %t103, !range !{i64 0, i64 28}
  %t106 = icmp eq i64 %t104, 10
  store i1 %t106, ptr %l53, !tbaa !21
  br label %bb22
bb22:
  %t107 = load i1, ptr %l53, !tbaa !21
  br i1 %t107, label %bb23, label %bb24
bb23:
  %t108 = load ptr, ptr %l1, !tbaa !29
  %t110 = getelementptr { i64, [4 x i64] }, ptr %t108, i32 0, i32 1
  %t111 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t110, i32 0, i32 0
  %t112 = load %"compiler/source:Span", ptr %t111
  store %"compiler/source:Span" %t112, ptr %l6
  %t114 = load ptr, ptr %l1, !tbaa !29
  %t116 = getelementptr { i64, [4 x i64] }, ptr %t114, i32 0, i32 1
  %t117 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t116, i32 0, i32 1
  %t118 = load ptr, ptr %t117
  store ptr %t118, ptr %l7, !tbaa !29
  %t120 = load ptr, ptr %l1, !tbaa !29
  %t122 = getelementptr { i64, [4 x i64] }, ptr %t120, i32 0, i32 1
  %t123 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t122, i32 0, i32 2
  %t124 = load { i64, ptr }, ptr %t123
  store { i64, ptr } %t124, ptr %l8, !tbaa !27
  br label %bb25
bb24:
  br label %bb31
bb25:
  %t126 = load ptr, ptr %l7, !tbaa !29
  %t128 = call i1 @compiler_2fparse_2eisPatPath(ptr %v1, ptr %t126)
  store i1 %t128, ptr %l63
  br label %bb26
bb26:
  %t129 = load i1, ptr %l63, !tbaa !21
  br i1 %t129, label %bb27, label %bb28
bb27:
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t131 = load %"compiler/source:Span", ptr %l6
  %t132 = load ptr, ptr %l7, !tbaa !29
  %t133 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t138 = call ptr @compiler_2fparse_2ecompiler_2fparse_3aParser_2ecasePattern(ptr %v0, ptr %v1, ptr %v1, ptr %v2, ptr %t130, %"compiler/source:Span" %t131, ptr %t132, { i64, ptr } %t133)
  store ptr %t138, ptr %l68
  br label %bb29
bb28:
  br label %bb30
bb29:
  %t139 = load ptr, ptr %l68, !tbaa !29
  store ptr %t139, ptr %rv
  br label %ret
bb30:
  %t140 = load %"compiler/source:Span", ptr %l6
  %t141 = load ptr, ptr %l1, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t142
  %t143 = getelementptr { i64, [4 x i64] }, ptr %t142, i32 0, i32 0
  store i64 4, ptr %t143
  %t145 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t140, 0
  %t147 = insertvalue { %"compiler/source:Span", ptr } %t145, ptr %t141, 1
  %t148 = getelementptr { i64, [4 x i64] }, ptr %t142, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t147, ptr %t148
  %t149 = load { i64, [4 x i64] }, ptr %t142
  %t151 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 40, i64 8)
  store { i64, [4 x i64] } %t149, ptr %t151
  store ptr %t151, ptr %rv
  br label %ret
bb31:
  %t153 = load ptr, ptr %l1, !tbaa !29
  store ptr %t153, ptr %l73, !tbaa !29
  store i1 false, ptr %l74, !tbaa !21
  %t154 = load ptr, ptr %l73, !tbaa !29
  %t155 = icmp ne ptr %t154, null
  br i1 %t155, label %bb32, label %bb33
bb32:
  %t157 = load ptr, ptr %l73, !tbaa !29
  %t158 = load i64, ptr %t157, !range !{i64 0, i64 28}
  %t160 = icmp eq i64 %t158, 13
  store i1 %t160, ptr %l74, !tbaa !21
  br label %bb33
bb33:
  %t161 = load i1, ptr %l74, !tbaa !21
  br i1 %t161, label %bb34, label %bb35
bb34:
  %t162 = load ptr, ptr %l1, !tbaa !29
  %t164 = getelementptr { i64, [4 x i64] }, ptr %t162, i32 0, i32 1
  %t165 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t164, i32 0, i32 0
  %t166 = load %"compiler/source:Span", ptr %t165
  store %"compiler/source:Span" %t166, ptr %l9
  %t168 = load ptr, ptr %l1, !tbaa !29
  %t170 = getelementptr { i64, [4 x i64] }, ptr %t168, i32 0, i32 1
  %t171 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t170, i32 0, i32 1
  %t172 = load ptr, ptr %t171
  store ptr %t172, ptr %l10, !tbaa !29
  %t174 = load ptr, ptr %l1, !tbaa !29
  %t176 = getelementptr { i64, [4 x i64] }, ptr %t174, i32 0, i32 1
  %t177 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t176, i32 0, i32 2
  %t178 = load { i64, ptr }, ptr %t177
  store { i64, ptr } %t178, ptr %l11, !tbaa !27
  br label %bb36
bb35:
  br label %bb42
bb36:
  %t180 = load ptr, ptr %l10, !tbaa !29
  %t182 = call i1 @compiler_2fparse_2eisPath(ptr %v1, ptr %t180)
  store i1 %t182, ptr %l84
  br label %bb37
bb37:
  %t183 = load i1, ptr %l84, !tbaa !21
  br i1 %t183, label %bb38, label %bb39
bb38:
  %t184 = load ptr, ptr %l0, !tbaa !29
  %t185 = load %"compiler/source:Span", ptr %l9
  %t186 = load ptr, ptr %l1, !tbaa !29
  %t187 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t192 = call ptr @compiler_2fparse_2ecompiler_2fparse_3aParser_2eelemsPattern(ptr %v0, ptr %v1, ptr %v1, ptr %v2, ptr %t184, %"compiler/source:Span" %t185, ptr %t186, { i64, ptr } %t187)
  store ptr %t192, ptr %l89
  br label %bb40
bb39:
  br label %bb41
bb40:
  %t193 = load ptr, ptr %l89, !tbaa !29
  store ptr %t193, ptr %rv
  br label %ret
bb41:
  %t194 = load %"compiler/source:Span", ptr %l9
  %t195 = load ptr, ptr %l1, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t196
  %t197 = getelementptr { i64, [4 x i64] }, ptr %t196, i32 0, i32 0
  store i64 4, ptr %t197
  %t199 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t194, 0
  %t201 = insertvalue { %"compiler/source:Span", ptr } %t199, ptr %t195, 1
  %t202 = getelementptr { i64, [4 x i64] }, ptr %t196, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t201, ptr %t202
  %t203 = load { i64, [4 x i64] }, ptr %t196
  %t205 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 40, i64 8)
  store { i64, [4 x i64] } %t203, ptr %t205
  store ptr %t205, ptr %rv
  br label %ret
bb42:
  %t207 = load ptr, ptr %l1, !tbaa !29
  store ptr %t207, ptr %l94, !tbaa !29
  store i1 false, ptr %l95, !tbaa !21
  %t208 = load ptr, ptr %l94, !tbaa !29
  %t209 = icmp ne ptr %t208, null
  br i1 %t209, label %bb43, label %bb44
bb43:
  %t211 = load ptr, ptr %l94, !tbaa !29
  %t212 = load i64, ptr %t211, !range !{i64 0, i64 28}
  %t214 = icmp eq i64 %t212, 16
  store i1 %t214, ptr %l95, !tbaa !21
  br label %bb44
bb44:
  %t215 = load i1, ptr %l95, !tbaa !21
  br i1 %t215, label %bb45, label %bb46
bb45:
  %t216 = load ptr, ptr %l1, !tbaa !29
  %t218 = getelementptr { i64, [4 x i64] }, ptr %t216, i32 0, i32 1
  %t219 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t218, i32 0, i32 0
  %t220 = load %"compiler/source:Span", ptr %t219
  store %"compiler/source:Span" %t220, ptr %l12
  %t222 = load ptr, ptr %l1, !tbaa !29
  %t224 = getelementptr { i64, [4 x i64] }, ptr %t222, i32 0, i32 1
  %t225 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t224, i32 0, i32 2
  %t226 = load { i64, ptr }, ptr %t225
  store { i64, ptr } %t226, ptr %l13, !tbaa !27
  br label %bb51
bb46:
  %t228 = load ptr, ptr %l1, !tbaa !29
  store ptr %t228, ptr %l102, !tbaa !29
  store i1 false, ptr %l103, !tbaa !21
  %t229 = load ptr, ptr %l102, !tbaa !29
  %t230 = icmp ne ptr %t229, null
  br i1 %t230, label %bb47, label %bb48
bb47:
  %t232 = load ptr, ptr %l102, !tbaa !29
  %t233 = load i64, ptr %t232, !range !{i64 0, i64 28}
  %t235 = icmp eq i64 %t233, 17
  store i1 %t235, ptr %l103, !tbaa !21
  br label %bb48
bb48:
  %t236 = load i1, ptr %l103, !tbaa !21
  br i1 %t236, label %bb49, label %bb50
bb49:
  %t237 = load ptr, ptr %l1, !tbaa !29
  %t239 = getelementptr { i64, [4 x i64] }, ptr %t237, i32 0, i32 1
  %t240 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t239, i32 0, i32 0
  %t241 = load %"compiler/source:Span", ptr %t240
  store %"compiler/source:Span" %t241, ptr %l12
  %t243 = load ptr, ptr %l1, !tbaa !29
  %t245 = getelementptr { i64, [4 x i64] }, ptr %t243, i32 0, i32 1
  %t246 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t245, i32 0, i32 1
  %t247 = load { i64, ptr }, ptr %t246
  store { i64, ptr } %t247, ptr %l13, !tbaa !27
  br label %bb51
bb50:
  br label %bb53
bb51:
  %t249 = load ptr, ptr %l0, !tbaa !29
  %t250 = load %"compiler/source:Span", ptr %l12
  %t251 = load ptr, ptr %l1, !tbaa !29
  %t252 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t257 = call ptr @compiler_2fparse_2ecompiler_2fparse_3aParser_2eelemsPattern(ptr %v0, ptr %v1, ptr %v1, ptr %v2, ptr %t249, %"compiler/source:Span" %t250, ptr %t251, { i64, ptr } %t252)
  store ptr %t257, ptr %l114
  br label %bb52
bb52:
  %t258 = load ptr, ptr %l114, !tbaa !29
  store ptr %t258, ptr %rv
  br label %ret
bb53:
  %t259 = load ptr, ptr %l1, !tbaa !29
  store ptr %t259, ptr %l115, !tbaa !29
  store i1 false, ptr %l116, !tbaa !21
  %t260 = load ptr, ptr %l115, !tbaa !29
  %t261 = icmp ne ptr %t260, null
  br i1 %t261, label %bb54, label %bb55
bb54:
  %t263 = load ptr, ptr %l115, !tbaa !29
  %t264 = load i64, ptr %t263, !range !{i64 0, i64 28}
  %t266 = icmp eq i64 %t264, 26
  store i1 %t266, ptr %l116, !tbaa !21
  br label %bb55
bb55:
  %t267 = load i1, ptr %l116, !tbaa !21
  br i1 %t267, label %bb56, label %bb57
bb56:
  %t268 = load ptr, ptr %l1, !tbaa !29
  %t270 = getelementptr { i64, [4 x i64] }, ptr %t268, i32 0, i32 1
  %t271 = getelementptr { %"compiler/source:Span", ptr }, ptr %t270, i32 0, i32 0
  %t272 = load %"compiler/source:Span", ptr %t271
  store %"compiler/source:Span" %t272, ptr %l14
  %t274 = load ptr, ptr %l1, !tbaa !29
  %t276 = getelementptr { i64, [4 x i64] }, ptr %t274, i32 0, i32 1
  %t277 = getelementptr { %"compiler/source:Span", ptr }, ptr %t276, i32 0, i32 1
  %t278 = load ptr, ptr %t277
  store ptr %t278, ptr %l15, !tbaa !29
  br label %bb58
bb57:
  br label %bb73
bb58:
  %t280 = load ptr, ptr %l15, !tbaa !29
  store ptr %t280, ptr %l123, !tbaa !29
  store i1 false, ptr %l124, !tbaa !21
  %t281 = load ptr, ptr %l123, !tbaa !29
  %t282 = icmp ne ptr %t281, null
  br i1 %t282, label %bb59, label %bb60
bb59:
  %t284 = load ptr, ptr %l123, !tbaa !29
  %t285 = load i64, ptr %t284, !range !{i64 0, i64 28}
  %t287 = icmp eq i64 %t285, 0
  store i1 %t287, ptr %l124, !tbaa !21
  br label %bb60
bb60:
  %t288 = load i1, ptr %l124, !tbaa !21
  br i1 %t288, label %bb61, label %bb62
bb61:
  %t289 = load ptr, ptr %l15, !tbaa !29
  %t291 = getelementptr { i64, [4 x i64] }, ptr %t289, i32 0, i32 1
  %t292 = getelementptr { %"compiler/source:Span", i32 }, ptr %t291, i32 0, i32 1
  %t293 = load i32, ptr %t292
  store i32 %t293, ptr %l16, !tbaa !23
  br label %bb63
bb62:
  br label %bb67
bb63:
  %t295 = load i1, ptr %l2, !tbaa !21
  %t297 = xor i1 %t295, true
  br i1 %t297, label %bb64, label %bb65
bb64:
  %t299 = load %"compiler/source:Span", ptr %l14
  %t300 = load i32, ptr %l16, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t301
  %t302 = getelementptr { i64, [4 x i64] }, ptr %t301, i32 0, i32 0
  store i64 7, ptr %t302
  %t304 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t299, 0
  %t306 = insertvalue { %"compiler/source:Span", i32 } %t304, i32 %t300, 1
  %t307 = getelementptr { i64, [4 x i64] }, ptr %t301, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t306, ptr %t307
  %t308 = load { i64, [4 x i64] }, ptr %t301
  %t310 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 40, i64 8)
  store { i64, [4 x i64] } %t308, ptr %t310
  store ptr %t310, ptr %rv
  br label %ret
bb65:
  br label %bb66
bb66:
  br label %bb72
bb67:
  br i1 true, label %bb68, label %bb69
bb68:
  br label %bb70
bb69:
  br label %bb71
bb70:
  br label %bb72
bb71:
  call void @__olang_check_failed(ptr @olang_loc_7ff84c49a98c5d65_799121c0214ef509)
  unreachable
bb72:
  %t312 = load %"compiler/source:Span", ptr %l14
  %t313 = load ptr, ptr %l1, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t314
  %t315 = getelementptr { i64, [4 x i64] }, ptr %t314, i32 0, i32 0
  store i64 4, ptr %t315
  %t317 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t312, 0
  %t319 = insertvalue { %"compiler/source:Span", ptr } %t317, ptr %t313, 1
  %t320 = getelementptr { i64, [4 x i64] }, ptr %t314, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t319, ptr %t320
  %t321 = load { i64, [4 x i64] }, ptr %t314
  %t323 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 40, i64 8)
  store { i64, [4 x i64] } %t321, ptr %t323
  store ptr %t323, ptr %rv
  br label %ret
bb73:
  br i1 true, label %bb74, label %bb75
bb74:
  br label %bb76
bb75:
  br label %bb78
bb76:
  %t325 = load ptr, ptr %l1, !tbaa !29
  %t327 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t325)
  store %"compiler/source:Span" %t327, ptr %l140
  br label %bb77
bb77:
  %t328 = load ptr, ptr %l1, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t329
  %t330 = getelementptr { i64, [4 x i64] }, ptr %t329, i32 0, i32 0
  store i64 4, ptr %t330
  %t331 = load %"compiler/source:Span", ptr %l140
  %t332 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t331, 0
  %t334 = insertvalue { %"compiler/source:Span", ptr } %t332, ptr %t328, 1
  %t335 = getelementptr { i64, [4 x i64] }, ptr %t329, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t334, ptr %t335
  %t336 = load { i64, [4 x i64] }, ptr %t329
  %t338 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 40, i64 8)
  store { i64, [4 x i64] } %t336, ptr %t338
  store ptr %t338, ptr %rv
  br label %ret
bb78:
  call void @__olang_check_failed(ptr @olang_loc_2af5dad726595634_740c4fa339a5cf38)
  unreachable
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eprec(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l13 = alloca i64
  %l18 = alloca i64
  %l23 = alloca i64
  %l32 = alloca i64
  %l39 = alloca i64
  %l50 = alloca i64
  %l53 = alloca i64
  %l60 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l1, !range !{i32 0, i32 116}
  %t3 = trunc i64 46 to i32
  %t4 = icmp eq i32 %t1, %t3
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb4
bb3:
  store i64 1, ptr %l2, !tbaa !24
  br label %bb103
bb4:
  %t6 = load i32, ptr %l1, !range !{i32 0, i32 116}
  %t8 = trunc i64 47 to i32
  %t9 = icmp eq i32 %t6, %t8
  br i1 %t9, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb8
bb7:
  store i64 2, ptr %l2, !tbaa !24
  br label %bb103
bb8:
  %t11 = load i32, ptr %l1, !range !{i32 0, i32 116}
  %t13 = trunc i64 45 to i32
  %t14 = icmp eq i32 %t11, %t13
  br i1 %t14, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  store i64 3, ptr %l2, !tbaa !24
  br label %bb103
bb12:
  %t16 = load i32, ptr %l1, !range !{i32 0, i32 116}
  %t18 = trunc i64 103 to i32
  %t19 = icmp eq i32 %t16, %t18
  br i1 %t19, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb19
bb15:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/parse:Parser", ptr %t21, i32 0, i32 49
  %t24 = load i1, ptr %t23, !tbaa !21
  br i1 %t24, label %bb16, label %bb17
bb16:
  store i64 4, ptr %l13, !tbaa !24
  br label %bb18
bb17:
  store i64 6, ptr %l13, !tbaa !24
  br label %bb18
bb18:
  %t26 = load i64, ptr %l13, !tbaa !24
  store i64 %t26, ptr %l2, !tbaa !24
  br label %bb103
bb19:
  %t27 = load i32, ptr %l1, !range !{i32 0, i32 116}
  %t29 = trunc i64 104 to i32
  %t30 = icmp eq i32 %t27, %t29
  br i1 %t30, label %bb20, label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb26
bb22:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/parse:Parser", ptr %t32, i32 0, i32 49
  %t35 = load i1, ptr %t34, !tbaa !21
  br i1 %t35, label %bb23, label %bb24
bb23:
  store i64 5, ptr %l18, !tbaa !24
  br label %bb25
bb24:
  store i64 7, ptr %l18, !tbaa !24
  br label %bb25
bb25:
  %t37 = load i64, ptr %l18, !tbaa !24
  store i64 %t37, ptr %l2, !tbaa !24
  br label %bb103
bb26:
  %t38 = load i32, ptr %l1, !range !{i32 0, i32 116}
  %t40 = trunc i64 102 to i32
  %t41 = icmp eq i32 %t38, %t40
  br i1 %t41, label %bb27, label %bb28
bb27:
  br label %bb29
bb28:
  br label %bb33
bb29:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/parse:Parser", ptr %t43, i32 0, i32 49
  %t46 = load i1, ptr %t45, !tbaa !21
  br i1 %t46, label %bb30, label %bb31
bb30:
  store i64 6, ptr %l23, !tbaa !24
  br label %bb32
bb31:
  store i64 8, ptr %l23, !tbaa !24
  br label %bb32
bb32:
  %t48 = load i64, ptr %l23, !tbaa !24
  store i64 %t48, ptr %l2, !tbaa !24
  br label %bb103
bb33:
  %t49 = load i32, ptr %l1, !range !{i32 0, i32 116}
  %t51 = trunc i64 95 to i32
  %t52 = icmp eq i32 %t49, %t51
  br i1 %t52, label %bb34, label %bb35
bb34:
  br label %bb40
bb35:
  %t54 = load i32, ptr %l1, !range !{i32 0, i32 116}
  %t56 = trunc i64 96 to i32
  %t57 = icmp eq i32 %t54, %t56
  br i1 %t57, label %bb36, label %bb37
bb36:
  br label %bb40
bb37:
  %t59 = load i32, ptr %l1, !range !{i32 0, i32 116}
  %t61 = trunc i64 28 to i32
  %t62 = icmp eq i32 %t59, %t61
  br i1 %t62, label %bb38, label %bb39
bb38:
  br label %bb40
bb39:
  br label %bb44
bb40:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/parse:Parser", ptr %t64, i32 0, i32 49
  %t67 = load i1, ptr %t66, !tbaa !21
  br i1 %t67, label %bb41, label %bb42
bb41:
  store i64 7, ptr %l32, !tbaa !24
  br label %bb43
bb42:
  store i64 4, ptr %l32, !tbaa !24
  br label %bb43
bb43:
  %t69 = load i64, ptr %l32, !tbaa !24
  store i64 %t69, ptr %l2, !tbaa !24
  br label %bb103
bb44:
  %t70 = load i32, ptr %l1, !range !{i32 0, i32 116}
  %t72 = trunc i64 27 to i32
  %t73 = icmp eq i32 %t70, %t72
  br i1 %t73, label %bb45, label %bb46
bb45:
  br label %bb49
bb46:
  %t75 = load i32, ptr %l1, !range !{i32 0, i32 116}
  %t77 = trunc i64 48 to i32
  %t78 = icmp eq i32 %t75, %t77
  br i1 %t78, label %bb47, label %bb48
bb47:
  br label %bb49
bb48:
  br label %bb53
bb49:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t82 = getelementptr %"compiler/parse:Parser", ptr %t80, i32 0, i32 49
  %t83 = load i1, ptr %t82, !tbaa !21
  br i1 %t83, label %bb50, label %bb51
bb50:
  store i64 8, ptr %l39, !tbaa !24
  br label %bb52
bb51:
  store i64 5, ptr %l39, !tbaa !24
  br label %bb52
bb52:
  %t85 = load i64, ptr %l39, !tbaa !24
  store i64 %t85, ptr %l2, !tbaa !24
  br label %bb103
bb53:
  %t86 = load i32, ptr %l1, !range !{i32 0, i32 116}
  %t88 = trunc i64 98 to i32
  %t89 = icmp eq i32 %t86, %t88
  br i1 %t89, label %bb54, label %bb55
bb54:
  br label %bb62
bb55:
  %t91 = load i32, ptr %l1, !range !{i32 0, i32 116}
  %t93 = trunc i64 99 to i32
  %t94 = icmp eq i32 %t91, %t93
  br i1 %t94, label %bb56, label %bb57
bb56:
  br label %bb62
bb57:
  %t96 = load i32, ptr %l1, !range !{i32 0, i32 116}
  %t98 = trunc i64 100 to i32
  %t99 = icmp eq i32 %t96, %t98
  br i1 %t99, label %bb58, label %bb59
bb58:
  br label %bb62
bb59:
  %t101 = load i32, ptr %l1, !range !{i32 0, i32 116}
  %t103 = trunc i64 101 to i32
  %t104 = icmp eq i32 %t101, %t103
  br i1 %t104, label %bb60, label %bb61
bb60:
  br label %bb62
bb61:
  br label %bb69
bb62:
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t108 = getelementptr %"compiler/parse:Parser", ptr %t106, i32 0, i32 11
  %t109 = load i1, ptr %t108, !tbaa !21
  br i1 %t109, label %bb63, label %bb64
bb63:
  store i64 0, ptr %l50, !tbaa !24
  br label %bb68
bb64:
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t113 = getelementptr %"compiler/parse:Parser", ptr %t111, i32 0, i32 49
  %t114 = load i1, ptr %t113, !tbaa !21
  br i1 %t114, label %bb65, label %bb66
bb65:
  store i64 8, ptr %l53, !tbaa !24
  br label %bb67
bb66:
  store i64 5, ptr %l53, !tbaa !24
  br label %bb67
bb67:
  %t116 = load i64, ptr %l53, !tbaa !24
  store i64 %t116, ptr %l50, !tbaa !24
  br label %bb68
bb68:
  %t117 = load i64, ptr %l50, !tbaa !24
  store i64 %t117, ptr %l2, !tbaa !24
  br label %bb103
bb69:
  %t118 = load i32, ptr %l1, !range !{i32 0, i32 116}
  %t120 = trunc i64 108 to i32
  %t121 = icmp eq i32 %t118, %t120
  br i1 %t121, label %bb70, label %bb71
bb70:
  br label %bb74
bb71:
  %t123 = load i32, ptr %l1, !range !{i32 0, i32 116}
  %t125 = trunc i64 109 to i32
  %t126 = icmp eq i32 %t123, %t125
  br i1 %t126, label %bb72, label %bb73
bb72:
  br label %bb74
bb73:
  br label %bb78
bb74:
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t130 = getelementptr %"compiler/parse:Parser", ptr %t128, i32 0, i32 11
  %t131 = load i1, ptr %t130, !tbaa !21
  br i1 %t131, label %bb75, label %bb76
bb75:
  store i64 0, ptr %l60, !tbaa !24
  br label %bb77
bb76:
  store i64 9, ptr %l60, !tbaa !24
  br label %bb77
bb77:
  %t133 = load i64, ptr %l60, !tbaa !24
  store i64 %t133, ptr %l2, !tbaa !24
  br label %bb103
bb78:
  %t134 = load i32, ptr %l1, !range !{i32 0, i32 116}
  %t136 = trunc i64 68 to i32
  %t137 = icmp eq i32 %t134, %t136
  br i1 %t137, label %bb79, label %bb80
bb79:
  br label %bb83
bb80:
  %t139 = load i32, ptr %l1, !range !{i32 0, i32 116}
  %t141 = trunc i64 69 to i32
  %t142 = icmp eq i32 %t139, %t141
  br i1 %t142, label %bb81, label %bb82
bb81:
  br label %bb83
bb82:
  br label %bb84
bb83:
  store i64 10, ptr %l2, !tbaa !24
  br label %bb103
bb84:
  %t144 = load i32, ptr %l1, !range !{i32 0, i32 116}
  %t146 = trunc i64 70 to i32
  %t147 = icmp eq i32 %t144, %t146
  br i1 %t147, label %bb85, label %bb86
bb85:
  br label %bb93
bb86:
  %t149 = load i32, ptr %l1, !range !{i32 0, i32 116}
  %t151 = trunc i64 72 to i32
  %t152 = icmp eq i32 %t149, %t151
  br i1 %t152, label %bb87, label %bb88
bb87:
  br label %bb93
bb88:
  %t154 = load i32, ptr %l1, !range !{i32 0, i32 116}
  %t156 = trunc i64 73 to i32
  %t157 = icmp eq i32 %t154, %t156
  br i1 %t157, label %bb89, label %bb90
bb89:
  br label %bb93
bb90:
  %t159 = load i32, ptr %l1, !range !{i32 0, i32 116}
  %t161 = trunc i64 74 to i32
  %t162 = icmp eq i32 %t159, %t161
  br i1 %t162, label %bb91, label %bb92
bb91:
  br label %bb93
bb92:
  br label %bb94
bb93:
  store i64 11, ptr %l2, !tbaa !24
  br label %bb103
bb94:
  %t164 = load i32, ptr %l1, !range !{i32 0, i32 116}
  %t166 = trunc i64 71 to i32
  %t167 = icmp eq i32 %t164, %t166
  br i1 %t167, label %bb95, label %bb96
bb95:
  br label %bb97
bb96:
  br label %bb98
bb97:
  store i64 12, ptr %l2, !tbaa !24
  br label %bb103
bb98:
  br i1 true, label %bb99, label %bb100
bb99:
  br label %bb101
bb100:
  br label %bb102
bb101:
  store i64 0, ptr %l2, !tbaa !24
  br label %bb103
bb102:
  call void @__olang_check_failed(ptr @olang_loc_1ff519fafba2f33_696c4c198bd75d77)
  unreachable
bb103:
  %t169 = load i64, ptr %l2, !tbaa !24
  store i64 %t169, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eprimary(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i1
  %l4 = alloca i1
  %l5 = alloca i1
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i1
  %l9 = alloca ptr
  %l10 = alloca { i64, ptr }
  %l11 = alloca i1
  %l12 = alloca ptr
  %l13 = alloca { i64, ptr }
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l17 = alloca %"compiler/token:Token"
  %l18 = alloca i32
  %l19 = alloca i32
  %l20 = alloca { i64, ptr }
  %lp21 = alloca ptr
  %l22 = alloca { i64, ptr }
  %l24 = alloca i32
  %l28 = alloca i32
  %l30 = alloca i32
  %l44 = alloca i32
  %l47 = alloca %"compiler/source:Span"
  %l54 = alloca i32
  %l58 = alloca ptr
  %l68 = alloca ptr
  %l70 = alloca ptr
  %l71 = alloca i32
  %l72 = alloca ptr
  %l83 = alloca ptr
  %l89 = alloca i32
  %l92 = alloca i32
  %l93 = alloca i32
  %l101 = alloca %"compiler/source:Span"
  %l108 = alloca i32
  %l109 = alloca ptr
  %l111 = alloca ptr
  %l112 = alloca i32
  %l116 = alloca %"compiler/source:Span"
  %l128 = alloca i32
  %l129 = alloca ptr
  %l131 = alloca ptr
  %l132 = alloca i32
  %l134 = alloca { i64, ptr }
  %l137 = alloca { i64, ptr }
  %l138 = alloca i32
  %l142 = alloca %"compiler/source:Span"
  %l150 = alloca i32
  %l153 = alloca ptr
  %l155 = alloca ptr
  %l156 = alloca i32
  %l158 = alloca { i64, ptr }
  %l161 = alloca { i64, ptr }
  %l162 = alloca i32
  %l166 = alloca %"compiler/source:Span"
  %l169 = alloca %"compiler/source:Span"
  %l170 = alloca ptr
  %l171 = alloca { i64, ptr }
  %l175 = alloca %"compiler/ast:Func"
  %l181 = alloca ptr
  %l183 = alloca ptr
  %l184 = alloca i32
  %l188 = alloca %"compiler/source:Span"
  %l195 = alloca i32
  %l197 = alloca i1
  %l198 = alloca ptr
  %l200 = alloca ptr
  %l201 = alloca i32
  %l206 = alloca %"compiler/source:Span"
  %l212 = alloca ptr
  %l214 = alloca ptr
  %l215 = alloca i32
  %l217 = alloca ptr
  %l221 = alloca ptr
  %l222 = alloca i32
  %l227 = alloca %"compiler/token:Token"
  %l229 = alloca i32
  %l231 = alloca ptr
  %l234 = alloca { i64, ptr }
  %l235 = alloca i32
  %l238 = alloca i1
  %l243 = alloca i1
  %l245 = alloca i32
  %l246 = alloca { i64, ptr }
  %l248 = alloca { i64, ptr }
  %l249 = alloca i32
  %l253 = alloca %"compiler/source:Span"
  %l256 = alloca %"compiler/source:Span"
  %l262 = alloca ptr
  %l266 = alloca ptr
  %l267 = alloca i32
  %l271 = alloca i1
  %l276 = alloca i1
  %l277 = alloca i1
  %l279 = alloca i1
  %l280 = alloca i1
  %l282 = alloca i1
  %l287 = alloca i1
  %l289 = alloca i1
  %l291 = alloca i1
  %l292 = alloca ptr
  %l294 = alloca %"compiler/token:Token"
  %l295 = alloca i32
  %l297 = alloca %"compiler/token:Token"
  %l298 = alloca i32
  %l301 = alloca { i64, ptr }
  %l302 = alloca %"compiler/diagmsg:Msg"
  %l304 = alloca i32
  %l305 = alloca { i64, ptr }
  %l307 = alloca { i64, ptr }
  %l308 = alloca i32
  %l312 = alloca %"compiler/source:Span"
  %l315 = alloca %"compiler/source:Span"
  %l324 = alloca i1
  %l326 = alloca i32
  %l329 = alloca i1
  %l331 = alloca i32
  %l335 = alloca i32
  %l337 = alloca i1
  %l340 = alloca %"compiler/source:Span"
  %l341 = alloca i32
  %l344 = alloca { i64, ptr }
  %l350 = alloca ptr
  %l351 = alloca ptr
  %l352 = alloca i32
  %l356 = alloca ptr
  %l357 = alloca ptr
  %l358 = alloca i32
  %l362 = alloca %"compiler/source:Span"
  %l369 = alloca i32
  %l372 = alloca i1
  %l375 = alloca i1
  %l377 = alloca i32
  %l380 = alloca i1
  %l385 = alloca i1
  %l387 = alloca i32
  %l390 = alloca %"compiler/source:Span"
  %l391 = alloca i32
  %l394 = alloca { i64, ptr }
  %l403 = alloca ptr
  %l404 = alloca ptr
  %l408 = alloca ptr
  %l409 = alloca i32
  %l412 = alloca i32
  %l415 = alloca %"compiler/source:Span"
  %l421 = alloca ptr
  %l423 = alloca ptr
  %l424 = alloca i32
  %l427 = alloca i32
  %s21 = alloca %olang.scope
  %rv = alloca { i32, ptr }
  %t48 = alloca { i64, [4 x i64] }, align 8
  %t180 = alloca { i64, [4 x i64] }, align 8
  %t226 = alloca { i64, [4 x i64] }, align 8
  %t306 = alloca { i64, [4 x i64] }, align 8
  %t401 = alloca { i64, [4 x i64] }, align 8
  %t444 = alloca { i64, [4 x i64] }, align 8
  %t495 = alloca { i64, [4 x i64] }, align 8
  %t634 = alloca { i64, [4 x i64] }, align 8
  %t645 = alloca { i64, [4 x i64] }, align 8
  %t784 = alloca { i64, [4 x i64] }, align 8
  %t795 = alloca { i64, [4 x i64] }, align 8
  %t852 = alloca i64
  %t869 = alloca { i64, [5 x i64] }, align 8
  %t919 = alloca { i64, [4 x i64] }, align 8
  %t988 = alloca i64
  %t1005 = alloca { i64, [5 x i64] }, align 8
  %t1060 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ehere(ptr %v0, ptr %t1)
  store i32 %t3, ptr %l28
  br label %bb1
bb1:
  %t4 = load i32, ptr %l28, !tbaa !23
  store i32 %t4, ptr %l1, !tbaa !23
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2epeek(ptr %v0, ptr %t5)
  store i32 %t7, ptr %l30
  br label %bb2
bb2:
  %t8 = load i32, ptr %l30, !range !{i32 0, i32 116}
  store i32 %t8, ptr %l2
  %t9 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t11 = trunc i64 2 to i32
  %t12 = icmp eq i32 %t9, %t11
  br i1 %t12, label %bb3, label %bb4
bb3:
  br label %bb15
bb4:
  %t14 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t16 = trunc i64 3 to i32
  %t17 = icmp eq i32 %t14, %t16
  br i1 %t17, label %bb5, label %bb6
bb5:
  br label %bb15
bb6:
  %t19 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t21 = trunc i64 4 to i32
  %t22 = icmp eq i32 %t19, %t21
  br i1 %t22, label %bb7, label %bb8
bb7:
  br label %bb15
bb8:
  %t24 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t26 = trunc i64 6 to i32
  %t27 = icmp eq i32 %t24, %t26
  br i1 %t27, label %bb9, label %bb10
bb9:
  br label %bb15
bb10:
  %t29 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t31 = trunc i64 7 to i32
  %t32 = icmp eq i32 %t29, %t31
  br i1 %t32, label %bb11, label %bb12
bb11:
  br label %bb15
bb12:
  %t34 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t36 = trunc i64 5 to i32
  %t37 = icmp eq i32 %t34, %t36
  br i1 %t37, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb18
bb15:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t39)
  store i32 %t41, ptr %l44
  br label %bb16
bb16:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t43 = load i32, ptr %l1, !tbaa !23
  %t46 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t42, i32 %t43)
  store %"compiler/source:Span" %t46, ptr %l47
  br label %bb17
bb17:
  %t47 = load i32, ptr %l2, !range !{i32 0, i32 116}
  store { i64, [4 x i64] } zeroinitializer, ptr %t48
  %t49 = getelementptr { i64, [4 x i64] }, ptr %t48, i32 0, i32 0
  store i64 1, ptr %t49
  %t50 = load %"compiler/source:Span", ptr %l47
  %t51 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t50, 0
  %t53 = insertvalue { %"compiler/source:Span", i32 } %t51, i32 %t47, 1
  %t54 = getelementptr { i64, [4 x i64] }, ptr %t48, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t53, ptr %t54
  %t55 = load { i64, [4 x i64] }, ptr %t48
  %t57 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 40, i64 8)
  store { i64, [4 x i64] } %t55, ptr %t57
  %t59 = insertvalue { i32, ptr } zeroinitializer, ptr %t57, 1
  store { i32, ptr } %t59, ptr %rv
  br label %ret
bb18:
  %t60 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t62 = trunc i64 110 to i32
  %t63 = icmp eq i32 %t60, %t62
  br i1 %t63, label %bb19, label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb32
bb21:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t65)
  store i32 %t67, ptr %l54
  br label %bb22
bb22:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/parse:Parser", ptr %t68, i32 0, i32 11
  %t71 = load i1, ptr %t70, !tbaa !21
  store i1 %t71, ptr %l3, !tbaa !21
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/parse:Parser", ptr %t73, i32 0, i32 11
  store i1 false, ptr %t75, !tbaa !21
  %t76 = load ptr, ptr %l0, !tbaa !29
  store ptr %t76, ptr %l58, !tbaa !29
  %t77 = load ptr, ptr %l58, !tbaa !29
  %t78 = getelementptr %"compiler/parse:Parser", ptr %t77, i32 0, i32 21
  %t79 = load i64, ptr %t78, !tbaa !24
  %t82 = add i64 %t79, 1
  %t84 = load ptr, ptr %l58, !tbaa !29
  %t85 = getelementptr %"compiler/parse:Parser", ptr %t84, i32 0, i32 21
  store i64 %t82, ptr %t85, !tbaa !24
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t88 = getelementptr %"compiler/parse:Parser", ptr %t86, i32 0, i32 22
  %t89 = load i1, ptr %t88, !tbaa !21
  store i1 %t89, ptr %l4, !tbaa !21
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t93 = getelementptr %"compiler/parse:Parser", ptr %t91, i32 0, i32 23
  %t94 = load i1, ptr %t93, !tbaa !21
  store i1 %t94, ptr %l5, !tbaa !21
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"compiler/parse:Parser", ptr %t96, i32 0, i32 22
  store i1 true, ptr %t98, !tbaa !21
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = getelementptr %"compiler/parse:Parser", ptr %t99, i32 0, i32 23
  store i1 false, ptr %t101, !tbaa !21
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexpr(ptr %v0, ptr %v1, ptr %t102)
  %t105 = extractvalue { i32, ptr } %t104, 1
  %t106 = extractvalue { i32, ptr } %t104, 0
  store i32 %t106, ptr %l71
  %t107 = icmp ne i32 %t106, 0
  br i1 %t107, label %bb24, label %ok.108, !prof !99
ok.108:
  store ptr %t105, ptr %l70
  br label %bb23
bb23:
  %t109 = load ptr, ptr %l70, !tbaa !29
  store ptr %t109, ptr %l68, !tbaa !29
  br label %bb26
bb24:
  br label %bb25
bb25:
  %t110 = load ptr, ptr %l0, !tbaa !29
  store ptr %t110, ptr %l72, !tbaa !29
  %t111 = load ptr, ptr %l72, !tbaa !29
  %t112 = getelementptr %"compiler/parse:Parser", ptr %t111, i32 0, i32 21
  %t113 = load i64, ptr %t112, !tbaa !24
  %t116 = sub i64 %t113, 1
  %t118 = load ptr, ptr %l72, !tbaa !29
  %t119 = getelementptr %"compiler/parse:Parser", ptr %t118, i32 0, i32 21
  store i64 %t116, ptr %t119, !tbaa !24
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t121 = load i1, ptr %l4, !tbaa !21
  %t124 = getelementptr %"compiler/parse:Parser", ptr %t120, i32 0, i32 22
  store i1 %t121, ptr %t124, !tbaa !21
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t126 = load i1, ptr %l5, !tbaa !21
  %t129 = getelementptr %"compiler/parse:Parser", ptr %t125, i32 0, i32 23
  store i1 %t126, ptr %t129, !tbaa !21
  %t131 = insertvalue { i32, ptr } zeroinitializer, i32 65536, 0
  store { i32, ptr } %t131, ptr %rv
  br label %ret
bb26:
  %t132 = load ptr, ptr %l68, !tbaa !29
  store ptr %t132, ptr %l6, !tbaa !29
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t134 = load i1, ptr %l5, !tbaa !21
  %t137 = getelementptr %"compiler/parse:Parser", ptr %t133, i32 0, i32 23
  store i1 %t134, ptr %t137, !tbaa !21
  %t138 = load ptr, ptr %l0, !tbaa !29
  store ptr %t138, ptr %l83, !tbaa !29
  %t139 = load ptr, ptr %l83, !tbaa !29
  %t140 = getelementptr %"compiler/parse:Parser", ptr %t139, i32 0, i32 21
  %t141 = load i64, ptr %t140, !tbaa !24
  %t144 = sub i64 %t141, 1
  %t146 = load ptr, ptr %l83, !tbaa !29
  %t147 = getelementptr %"compiler/parse:Parser", ptr %t146, i32 0, i32 21
  store i64 %t144, ptr %t147, !tbaa !24
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t149 = load i1, ptr %l3, !tbaa !21
  %t152 = getelementptr %"compiler/parse:Parser", ptr %t148, i32 0, i32 11
  store i1 %t149, ptr %t152, !tbaa !21
  %t153 = load ptr, ptr %l0, !tbaa !29
  %t156 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %t153, i32 111)
  %t157 = extractvalue { i32, i32 } %t156, 1
  %t158 = extractvalue { i32, i32 } %t156, 0
  store i32 %t158, ptr %l93
  %t159 = icmp ne i32 %t158, 0
  br i1 %t159, label %bb28, label %ok.160, !prof !99
ok.160:
  store i32 %t157, ptr %l92
  br label %bb27
bb27:
  %t161 = load i32, ptr %l92, !tbaa !23
  store i32 %t161, ptr %l89, !tbaa !23
  br label %bb30
bb28:
  br label %bb29
bb29:
  %t162 = load ptr, ptr %l0, !tbaa !29
  %t163 = load i1, ptr %l4, !tbaa !21
  %t166 = getelementptr %"compiler/parse:Parser", ptr %t162, i32 0, i32 22
  store i1 %t163, ptr %t166, !tbaa !21
  %t168 = insertvalue { i32, ptr } zeroinitializer, i32 65536, 0
  store { i32, ptr } %t168, ptr %rv
  br label %ret
bb30:
  %t169 = load ptr, ptr %l0, !tbaa !29
  %t170 = load i1, ptr %l4, !tbaa !21
  %t173 = getelementptr %"compiler/parse:Parser", ptr %t169, i32 0, i32 22
  store i1 %t170, ptr %t173, !tbaa !21
  %t174 = load ptr, ptr %l0, !tbaa !29
  %t175 = load i32, ptr %l1, !tbaa !23
  %t178 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t174, i32 %t175)
  store %"compiler/source:Span" %t178, ptr %l101
  br label %bb31
bb31:
  %t179 = load ptr, ptr %l6, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t180
  %t181 = getelementptr { i64, [4 x i64] }, ptr %t180, i32 0, i32 0
  store i64 2, ptr %t181
  %t182 = load %"compiler/source:Span", ptr %l101
  %t183 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t182, 0
  %t185 = insertvalue { %"compiler/source:Span", ptr } %t183, ptr %t179, 1
  %t186 = getelementptr { i64, [4 x i64] }, ptr %t180, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t185, ptr %t186
  %t187 = load { i64, [4 x i64] }, ptr %t180
  %t189 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 40, i64 8)
  store { i64, [4 x i64] } %t187, ptr %t189
  %t191 = insertvalue { i32, ptr } zeroinitializer, ptr %t189, 1
  store { i32, ptr } %t191, ptr %rv
  br label %ret
bb32:
  %t192 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t194 = trunc i64 51 to i32
  %t195 = icmp eq i32 %t192, %t194
  br i1 %t195, label %bb33, label %bb34
bb33:
  br label %bb35
bb34:
  br label %bb41
bb35:
  %t197 = load ptr, ptr %l0, !tbaa !29
  %t199 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t197)
  store i32 %t199, ptr %l108
  br label %bb36
bb36:
  %t200 = load ptr, ptr %l0, !tbaa !29
  %t202 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexpr(ptr %v0, ptr %v1, ptr %t200)
  %t203 = extractvalue { i32, ptr } %t202, 1
  %t204 = extractvalue { i32, ptr } %t202, 0
  store i32 %t204, ptr %l112
  %t205 = icmp ne i32 %t204, 0
  br i1 %t205, label %bb38, label %ok.206, !prof !99
ok.206:
  store ptr %t203, ptr %l111
  br label %bb37
bb37:
  %t207 = load ptr, ptr %l111, !tbaa !29
  store ptr %t207, ptr %l109, !tbaa !29
  br label %bb39
bb38:
  %t208 = load i32, ptr %l112, !tbaa !23
  %t209 = lshr i32 %t208, 16
  %t210 = and i32 %t208, 65535
  %t211 = icmp eq i32 %t209, 1
  %t212 = select i1 %t211, i32 1, i32 0
  %t213 = icmp eq i32 %t208, 0
  %t214 = shl i32 %t212, 16
  %t215 = or i32 %t214, %t210
  %t216 = select i1 %t213, i32 0, i32 %t215
  %t218 = insertvalue { i32, ptr } zeroinitializer, i32 %t216, 0
  store { i32, ptr } %t218, ptr %rv
  br label %ret
bb39:
  %t219 = load ptr, ptr %l109, !tbaa !29
  store ptr %t219, ptr %l7, !tbaa !29
  %t220 = load ptr, ptr %l0, !tbaa !29
  %t221 = load i32, ptr %l1, !tbaa !23
  %t224 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t220, i32 %t221)
  store %"compiler/source:Span" %t224, ptr %l116
  br label %bb40
bb40:
  %t225 = load ptr, ptr %l7, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t226
  %t227 = getelementptr { i64, [4 x i64] }, ptr %t226, i32 0, i32 0
  store i64 3, ptr %t227
  %t228 = load %"compiler/source:Span", ptr %l116
  %t229 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t228, 0
  %t231 = insertvalue { %"compiler/source:Span", i32, ptr } %t229, i32 51, 1
  %t233 = insertvalue { %"compiler/source:Span", i32, ptr } %t231, ptr %t225, 2
  %t234 = getelementptr { i64, [4 x i64] }, ptr %t226, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t233, ptr %t234
  %t235 = load { i64, [4 x i64] }, ptr %t226
  %t237 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 40, i64 8)
  store { i64, [4 x i64] } %t235, ptr %t237
  %t239 = insertvalue { i32, ptr } zeroinitializer, ptr %t237, 1
  store { i32, ptr } %t239, ptr %rv
  br label %ret
bb41:
  %t240 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t242 = trunc i64 11 to i32
  %t243 = icmp eq i32 %t240, %t242
  br i1 %t243, label %bb42, label %bb43
bb42:
  br label %bb44
bb43:
  br label %bb53
bb44:
  %t245 = load i32, ptr %l1, !tbaa !23
  %t246 = load ptr, ptr %l0, !tbaa !29
  %t248 = getelementptr %"compiler/parse:Parser", ptr %t246, i32 0, i32 28
  %t249 = load i32, ptr %t248, !tbaa !23
  %t252 = icmp eq i32 %t245, %t249
  store i1 %t252, ptr %l8, !tbaa !21
  %t254 = load ptr, ptr %l0, !tbaa !29
  %t256 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t254)
  store i32 %t256, ptr %l128
  br label %bb45
bb45:
  %t257 = load ptr, ptr %l0, !tbaa !29
  %t259 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexpr(ptr %v0, ptr %v1, ptr %t257)
  %t260 = extractvalue { i32, ptr } %t259, 1
  %t261 = extractvalue { i32, ptr } %t259, 0
  store i32 %t261, ptr %l132
  %t262 = icmp ne i32 %t261, 0
  br i1 %t262, label %bb47, label %ok.263, !prof !99
ok.263:
  store ptr %t260, ptr %l131
  br label %bb46
bb46:
  %t264 = load ptr, ptr %l131, !tbaa !29
  store ptr %t264, ptr %l129, !tbaa !29
  br label %bb48
bb47:
  %t265 = load i32, ptr %l132, !tbaa !23
  %t266 = lshr i32 %t265, 16
  %t267 = and i32 %t265, 65535
  %t268 = icmp eq i32 %t266, 1
  %t269 = select i1 %t268, i32 1, i32 0
  %t270 = icmp eq i32 %t265, 0
  %t271 = shl i32 %t269, 16
  %t272 = or i32 %t271, %t267
  %t273 = select i1 %t270, i32 0, i32 %t272
  %t275 = insertvalue { i32, ptr } zeroinitializer, i32 %t273, 0
  store { i32, ptr } %t275, ptr %rv
  br label %ret
bb48:
  %t276 = load ptr, ptr %l129, !tbaa !29
  store ptr %t276, ptr %l9, !tbaa !29
  %t277 = load ptr, ptr %l0, !tbaa !29
  %t278 = load i1, ptr %l8, !tbaa !21
  %t281 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eclauses(ptr %v0, ptr %v1, ptr %t277, i1 %t278)
  %t282 = extractvalue { i32, { i64, ptr } } %t281, 1
  %t283 = extractvalue { i32, { i64, ptr } } %t281, 0
  store i32 %t283, ptr %l138
  %t284 = icmp ne i32 %t283, 0
  br i1 %t284, label %bb50, label %ok.285, !prof !99
ok.285:
  store { i64, ptr } %t282, ptr %l137
  br label %bb49
bb49:
  %t286 = load { i64, ptr }, ptr %l137, !tbaa !27
  store { i64, ptr } %t286, ptr %l134, !tbaa !27
  br label %bb51
bb50:
  %t287 = load i32, ptr %l138, !tbaa !23
  %t288 = lshr i32 %t287, 16
  %t289 = and i32 %t287, 65535
  %t290 = icmp eq i32 %t288, 1
  %t291 = select i1 %t290, i32 1, i32 0
  %t292 = icmp eq i32 %t287, 0
  %t293 = shl i32 %t291, 16
  %t294 = or i32 %t293, %t289
  %t295 = select i1 %t292, i32 0, i32 %t294
  %t297 = insertvalue { i32, ptr } zeroinitializer, i32 %t295, 0
  store { i32, ptr } %t297, ptr %rv
  br label %ret
bb51:
  %t298 = load { i64, ptr }, ptr %l134, !tbaa !27
  store { i64, ptr } %t298, ptr %l10, !tbaa !27
  %t299 = load ptr, ptr %l0, !tbaa !29
  %t300 = load i32, ptr %l1, !tbaa !23
  %t303 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t299, i32 %t300)
  store %"compiler/source:Span" %t303, ptr %l142
  br label %bb52
bb52:
  %t304 = load ptr, ptr %l9, !tbaa !29
  %t305 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, [4 x i64] } zeroinitializer, ptr %t306
  %t307 = getelementptr { i64, [4 x i64] }, ptr %t306, i32 0, i32 0
  store i64 19, ptr %t307
  %t308 = load %"compiler/source:Span", ptr %l142
  %t309 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } undef, %"compiler/source:Span" %t308, 0
  %t311 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } %t309, ptr %t304, 1
  %t313 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } %t311, { i64, ptr } %t305, 2
  %t314 = getelementptr { i64, [4 x i64] }, ptr %t306, i32 0, i32 1
  store { %"compiler/source:Span", ptr, { i64, ptr } } %t313, ptr %t314
  %t315 = load { i64, [4 x i64] }, ptr %t306
  %t317 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 40, i64 8)
  store { i64, [4 x i64] } %t315, ptr %t317
  %t319 = insertvalue { i32, ptr } zeroinitializer, ptr %t317, 1
  store { i32, ptr } %t319, ptr %rv
  br label %ret
bb53:
  %t320 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t322 = trunc i64 37 to i32
  %t323 = icmp eq i32 %t320, %t322
  br i1 %t323, label %bb54, label %bb55
bb54:
  br label %bb56
bb55:
  br label %bb71
bb56:
  %t325 = load ptr, ptr %l0, !tbaa !29
  %t327 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t325)
  store i32 %t327, ptr %l150
  br label %bb57
bb57:
  %t328 = load ptr, ptr %l0, !tbaa !29
  %t330 = getelementptr %"compiler/parse:Parser", ptr %t328, i32 0, i32 23
  %t331 = load i1, ptr %t330, !tbaa !21
  store i1 %t331, ptr %l11, !tbaa !21
  %t333 = load ptr, ptr %l0, !tbaa !29
  %t335 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2esig(ptr %v0, ptr %v1, ptr %t333, i1 true, i1 true, i1 false, i1 false, i1 false)
  %t336 = extractvalue { i32, ptr } %t335, 1
  %t337 = extractvalue { i32, ptr } %t335, 0
  store i32 %t337, ptr %l156
  %t338 = icmp ne i32 %t337, 0
  br i1 %t338, label %bb59, label %ok.339, !prof !99
ok.339:
  store ptr %t336, ptr %l155
  br label %bb58
bb58:
  %t340 = load ptr, ptr %l155, !tbaa !29
  store ptr %t340, ptr %l153, !tbaa !29
  br label %bb60
bb59:
  %t341 = load i32, ptr %l156, !tbaa !23
  %t342 = lshr i32 %t341, 16
  %t343 = and i32 %t341, 65535
  %t344 = icmp eq i32 %t342, 1
  %t345 = select i1 %t344, i32 1, i32 0
  %t346 = icmp eq i32 %t341, 0
  %t347 = shl i32 %t345, 16
  %t348 = or i32 %t347, %t343
  %t349 = select i1 %t346, i32 0, i32 %t348
  %t351 = insertvalue { i32, ptr } zeroinitializer, i32 %t349, 0
  store { i32, ptr } %t351, ptr %rv
  br label %ret
bb60:
  %t352 = load ptr, ptr %l153, !tbaa !29
  store ptr %t352, ptr %l12, !tbaa !29
  %t353 = load ptr, ptr %l0, !tbaa !29
  %t354 = load i1, ptr %l11, !tbaa !21
  %t357 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2elambdaBody(ptr %v0, ptr %v1, ptr %t353, i1 %t354)
  %t358 = extractvalue { i32, { i64, ptr } } %t357, 1
  %t359 = extractvalue { i32, { i64, ptr } } %t357, 0
  store i32 %t359, ptr %l162
  %t360 = icmp ne i32 %t359, 0
  br i1 %t360, label %bb62, label %ok.361, !prof !99
ok.361:
  store { i64, ptr } %t358, ptr %l161
  br label %bb61
bb61:
  %t362 = load { i64, ptr }, ptr %l161, !tbaa !27
  store { i64, ptr } %t362, ptr %l158, !tbaa !27
  br label %bb63
bb62:
  %t363 = load i32, ptr %l162, !tbaa !23
  %t364 = lshr i32 %t363, 16
  %t365 = and i32 %t363, 65535
  %t366 = icmp eq i32 %t364, 1
  %t367 = select i1 %t366, i32 1, i32 0
  %t368 = icmp eq i32 %t363, 0
  %t369 = shl i32 %t367, 16
  %t370 = or i32 %t369, %t365
  %t371 = select i1 %t368, i32 0, i32 %t370
  %t373 = insertvalue { i32, ptr } zeroinitializer, i32 %t371, 0
  store { i32, ptr } %t373, ptr %rv
  br label %ret
bb63:
  %t374 = load { i64, ptr }, ptr %l158, !tbaa !27
  store { i64, ptr } %t374, ptr %l13, !tbaa !27
  %t375 = load ptr, ptr %l0, !tbaa !29
  %t376 = load i32, ptr %l1, !tbaa !23
  %t379 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t375, i32 %t376)
  store %"compiler/source:Span" %t379, ptr %l166
  br label %bb64
bb64:
  %t380 = load ptr, ptr %l0, !tbaa !29
  %t381 = load i32, ptr %l1, !tbaa !23
  %t384 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t380, i32 %t381)
  store %"compiler/source:Span" %t384, ptr %l169
  br label %bb65
bb65:
  %t385 = load ptr, ptr %l12, !tbaa !29
  store ptr %t385, ptr %l170, !tbaa !29
  %t386 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t386, ptr %l171, !tbaa !27
  %t387 = icmp sge i64 0, 0
  br i1 %t387, label %bb66, label %bb67
bb66:
  %t389 = icmp sle i64 0, 1152921504606846975
  br i1 %t389, label %bb68, label %bb69
bb67:
  call void @__olang_check_failed(ptr @olang_loc_b6007e4d1245e4d6_5e9becbf0504ee4a)
  unreachable
bb68:
  %t391 = mul i64 0, 8
  %t392 = insertvalue { i64, ptr } undef, i64 0, 0
  %t393 = insertvalue { i64, ptr } %t392, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t394 = load %"compiler/source:Span", ptr %l169
  %t395 = load ptr, ptr %l170, !tbaa !29
  %t396 = load { i64, ptr }, ptr %l171, !tbaa !27
  %t398 = call %"compiler/ast:Func" @compiler_2fast_3aFunc_2ector(ptr %v1, ptr %v1, ptr %v1, ptr %v1, ptr %v1, ptr %v1, %"compiler/source:Span" %t394, ptr null, i32 0, ptr %t395, { i64, ptr } %t396, { i64, ptr } %t393, i1 true, i1 false, ptr null, i32 0)
  store %"compiler/ast:Func" %t398, ptr %l175
  br label %bb70
bb69:
  call void @__olang_check_failed(ptr @olang_loc_b6007e4d1245e4d6_5e9becbf0504ee4a)
  unreachable
bb70:
  %t399 = load %"compiler/ast:Func", ptr %l175
  %t400 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 88, i64 8)
  store %"compiler/ast:Func" %t399, ptr %t400
  store { i64, [4 x i64] } zeroinitializer, ptr %t401
  %t402 = getelementptr { i64, [4 x i64] }, ptr %t401, i32 0, i32 0
  store i64 20, ptr %t402
  %t403 = load %"compiler/source:Span", ptr %l166
  %t404 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t403, 0
  %t406 = insertvalue { %"compiler/source:Span", ptr } %t404, ptr %t400, 1
  %t407 = getelementptr { i64, [4 x i64] }, ptr %t401, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t406, ptr %t407
  %t408 = load { i64, [4 x i64] }, ptr %t401
  %t410 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 40, i64 8)
  store { i64, [4 x i64] } %t408, ptr %t410
  %t412 = insertvalue { i32, ptr } zeroinitializer, ptr %t410, 1
  store { i32, ptr } %t412, ptr %rv
  br label %ret
bb71:
  %t413 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t415 = trunc i64 31 to i32
  %t416 = icmp eq i32 %t413, %t415
  br i1 %t416, label %bb72, label %bb73
bb72:
  br label %bb74
bb73:
  br label %bb79
bb74:
  %t418 = load ptr, ptr %l0, !tbaa !29
  %t420 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ematchBody(ptr %v0, ptr %v1, ptr %t418, i1 true)
  %t421 = extractvalue { i32, ptr } %t420, 1
  %t422 = extractvalue { i32, ptr } %t420, 0
  store i32 %t422, ptr %l184
  %t423 = icmp ne i32 %t422, 0
  br i1 %t423, label %bb76, label %ok.424, !prof !99
ok.424:
  store ptr %t421, ptr %l183
  br label %bb75
bb75:
  %t425 = load ptr, ptr %l183, !tbaa !29
  store ptr %t425, ptr %l181, !tbaa !29
  br label %bb77
bb76:
  %t426 = load i32, ptr %l184, !tbaa !23
  %t427 = lshr i32 %t426, 16
  %t428 = and i32 %t426, 65535
  %t429 = icmp eq i32 %t427, 1
  %t430 = select i1 %t429, i32 1, i32 0
  %t431 = icmp eq i32 %t426, 0
  %t432 = shl i32 %t430, 16
  %t433 = or i32 %t432, %t428
  %t434 = select i1 %t431, i32 0, i32 %t433
  %t436 = insertvalue { i32, ptr } zeroinitializer, i32 %t434, 0
  store { i32, ptr } %t436, ptr %rv
  br label %ret
bb77:
  %t437 = load ptr, ptr %l181, !tbaa !29
  store ptr %t437, ptr %l14, !tbaa !29
  %t438 = load ptr, ptr %l0, !tbaa !29
  %t439 = load i32, ptr %l1, !tbaa !23
  %t442 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t438, i32 %t439)
  store %"compiler/source:Span" %t442, ptr %l188
  br label %bb78
bb78:
  %t443 = load ptr, ptr %l14, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t444
  %t445 = getelementptr { i64, [4 x i64] }, ptr %t444, i32 0, i32 0
  store i64 21, ptr %t445
  %t446 = load %"compiler/source:Span", ptr %l188
  %t447 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t446, 0
  %t449 = insertvalue { %"compiler/source:Span", ptr } %t447, ptr %t443, 1
  %t450 = getelementptr { i64, [4 x i64] }, ptr %t444, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t449, ptr %t450
  %t451 = load { i64, [4 x i64] }, ptr %t444
  %t453 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 40, i64 8)
  store { i64, [4 x i64] } %t451, ptr %t453
  %t455 = insertvalue { i32, ptr } zeroinitializer, ptr %t453, 1
  store { i32, ptr } %t455, ptr %rv
  br label %ret
bb79:
  %t456 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t458 = trunc i64 21 to i32
  %t459 = icmp eq i32 %t456, %t458
  br i1 %t459, label %bb80, label %bb81
bb80:
  br label %bb82
bb81:
  br label %bb92
bb82:
  %t461 = load ptr, ptr %l0, !tbaa !29
  %t463 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t461)
  store i32 %t463, ptr %l195
  br label %bb83
bb83:
  store ptr null, ptr %l15, !tbaa !29
  %t464 = load ptr, ptr %l0, !tbaa !29
  %t466 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2emessageHere(ptr %v0, ptr %t464)
  store i1 %t466, ptr %l197
  br label %bb84
bb84:
  %t467 = load i1, ptr %l197, !tbaa !21
  br i1 %t467, label %bb85, label %bb86
bb85:
  %t468 = load ptr, ptr %l0, !tbaa !29
  %t470 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexpr(ptr %v0, ptr %v1, ptr %t468)
  %t471 = extractvalue { i32, ptr } %t470, 1
  %t472 = extractvalue { i32, ptr } %t470, 0
  store i32 %t472, ptr %l201
  %t473 = icmp ne i32 %t472, 0
  br i1 %t473, label %bb88, label %ok.474, !prof !99
ok.474:
  store ptr %t471, ptr %l200
  br label %bb87
bb86:
  br label %bb90
bb87:
  %t475 = load ptr, ptr %l200, !tbaa !29
  store ptr %t475, ptr %l198, !tbaa !29
  br label %bb89
bb88:
  %t476 = load i32, ptr %l201, !tbaa !23
  %t477 = lshr i32 %t476, 16
  %t478 = and i32 %t476, 65535
  %t479 = icmp eq i32 %t477, 1
  %t480 = select i1 %t479, i32 1, i32 0
  %t481 = icmp eq i32 %t476, 0
  %t482 = shl i32 %t480, 16
  %t483 = or i32 %t482, %t478
  %t484 = select i1 %t481, i32 0, i32 %t483
  %t486 = insertvalue { i32, ptr } zeroinitializer, i32 %t484, 0
  store { i32, ptr } %t486, ptr %rv
  br label %ret
bb89:
  %t487 = load ptr, ptr %l198, !tbaa !29
  store ptr %t487, ptr %l15, !tbaa !29
  br label %bb90
bb90:
  %t489 = load ptr, ptr %l0, !tbaa !29
  %t490 = load i32, ptr %l1, !tbaa !23
  %t493 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t489, i32 %t490)
  store %"compiler/source:Span" %t493, ptr %l206
  br label %bb91
bb91:
  %t494 = load ptr, ptr %l15, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t495
  %t496 = getelementptr { i64, [4 x i64] }, ptr %t495, i32 0, i32 0
  store i64 25, ptr %t496
  %t497 = load %"compiler/source:Span", ptr %l206
  %t498 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t497, 0
  %t500 = insertvalue { %"compiler/source:Span", ptr } %t498, ptr %t494, 1
  %t501 = getelementptr { i64, [4 x i64] }, ptr %t495, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t500, ptr %t501
  %t502 = load { i64, [4 x i64] }, ptr %t495
  %t504 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 40, i64 8)
  store { i64, [4 x i64] } %t502, ptr %t504
  %t506 = insertvalue { i32, ptr } zeroinitializer, ptr %t504, 1
  store { i32, ptr } %t506, ptr %rv
  br label %ret
bb92:
  %t507 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t509 = trunc i64 52 to i32
  %t510 = icmp eq i32 %t507, %t509
  br i1 %t510, label %bb93, label %bb94
bb93:
  br label %bb95
bb94:
  br label %bb102
bb95:
  %t512 = load ptr, ptr %l0, !tbaa !29
  %t514 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeExpr(ptr %v0, ptr %v1, ptr %t512)
  %t515 = extractvalue { i32, ptr } %t514, 1
  %t516 = extractvalue { i32, ptr } %t514, 0
  store i32 %t516, ptr %l215
  %t517 = icmp ne i32 %t516, 0
  br i1 %t517, label %bb97, label %ok.518, !prof !99
ok.518:
  store ptr %t515, ptr %l214
  br label %bb96
bb96:
  %t519 = load ptr, ptr %l214, !tbaa !29
  store ptr %t519, ptr %l212, !tbaa !29
  br label %bb98
bb97:
  %t520 = load i32, ptr %l215, !tbaa !23
  %t521 = lshr i32 %t520, 16
  %t522 = and i32 %t520, 65535
  %t523 = icmp eq i32 %t521, 1
  %t524 = select i1 %t523, i32 1, i32 0
  %t525 = icmp eq i32 %t520, 0
  %t526 = shl i32 %t524, 16
  %t527 = or i32 %t526, %t522
  %t528 = select i1 %t525, i32 0, i32 %t527
  %t530 = insertvalue { i32, ptr } zeroinitializer, i32 %t528, 0
  store { i32, ptr } %t530, ptr %rv
  br label %ret
bb98:
  %t531 = load ptr, ptr %l212, !tbaa !29
  %t532 = load ptr, ptr %l0, !tbaa !29
  %t533 = load i32, ptr %l1, !tbaa !23
  %t538 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2earrayLit(ptr %v0, ptr %v1, ptr %v1, ptr %t532, i32 %t533, ptr %t531)
  %t539 = extractvalue { i32, ptr } %t538, 1
  %t540 = extractvalue { i32, ptr } %t538, 0
  store i32 %t540, ptr %l222
  %t541 = icmp ne i32 %t540, 0
  br i1 %t541, label %bb100, label %ok.542, !prof !99
ok.542:
  store ptr %t539, ptr %l221
  br label %bb99
bb99:
  %t543 = load ptr, ptr %l221, !tbaa !29
  store ptr %t543, ptr %l217, !tbaa !29
  br label %bb101
bb100:
  %t544 = load i32, ptr %l222, !tbaa !23
  %t545 = lshr i32 %t544, 16
  %t546 = and i32 %t544, 65535
  %t547 = icmp eq i32 %t545, 1
  %t548 = select i1 %t547, i32 1, i32 0
  %t549 = icmp eq i32 %t544, 0
  %t550 = shl i32 %t548, 16
  %t551 = or i32 %t550, %t546
  %t552 = select i1 %t549, i32 0, i32 %t551
  %t554 = insertvalue { i32, ptr } zeroinitializer, i32 %t552, 0
  store { i32, ptr } %t554, ptr %rv
  br label %ret
bb101:
  %t555 = load ptr, ptr %l217, !tbaa !29
  %t556 = insertvalue { i32, ptr } zeroinitializer, ptr %t555, 1
  store { i32, ptr } %t556, ptr %rv
  br label %ret
bb102:
  %t557 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t559 = trunc i64 1 to i32
  %t560 = icmp eq i32 %t557, %t559
  br i1 %t560, label %bb103, label %bb104
bb103:
  br label %bb105
bb104:
  br label %bb224
bb105:
  %t562 = load ptr, ptr %l0, !tbaa !29
  %t564 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2etk(ptr %v0, ptr %t562)
  store %"compiler/token:Token" %t564, ptr %l227
  br label %bb106
bb106:
  %t565 = load %"compiler/token:Token", ptr %l227
  store %"compiler/token:Token" %t565, ptr %l17
  %t566 = load ptr, ptr %l0, !tbaa !29
  %t568 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elook(ptr %v0, ptr %t566, i64 1)
  store i32 %t568, ptr %l229
  br label %bb107
bb107:
  %t569 = load i32, ptr %l229, !range !{i32 0, i32 116}
  store i32 %t569, ptr %l18
  %t570 = load ptr, ptr %l0, !tbaa !29
  %t572 = getelementptr %"compiler/parse:Parser", ptr %t570, i32 0, i32 2
  %t573 = load ptr, ptr %t572, !tbaa !29
  store ptr %t573, ptr %l231, !tbaa !29
  %t574 = load ptr, ptr %l0, !tbaa !29
  %t575 = load %"compiler/token:Token", ptr %l17
  %t578 = call { i64, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etext(ptr %v0, ptr %v0, ptr %t574, %"compiler/token:Token" %t575)
  store { i64, ptr } %t578, ptr %l234
  br label %bb108
bb108:
  %t579 = load ptr, ptr %l231, !tbaa !29
  %t580 = load { i64, ptr }, ptr %l234, !tbaa !27
  %t581 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v0, ptr %t579, { i64, ptr } %t580)
  store i32 %t581, ptr %l235
  br label %bb109
bb109:
  %t582 = load i32, ptr %l235, !tbaa !23
  store i32 %t582, ptr %l19, !tbaa !23
  %t583 = load i32, ptr %l18, !range !{i32 0, i32 116}
  %t585 = trunc i64 98 to i32
  %t586 = icmp eq i32 %t583, %t585
  br i1 %t586, label %bb110, label %bb111
bb110:
  %t588 = load ptr, ptr %l0, !tbaa !29
  %t590 = getelementptr %"compiler/parse:Parser", ptr %t588, i32 0, i32 3
  %t591 = load ptr, ptr %t590, !tbaa !29
  %t593 = getelementptr %"compiler/parse:Oracle", ptr %t591, i32 0, i32 0
  %t594 = load i32, ptr %l19, !tbaa !23
  %t597 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3_H8da9376267bda3f76393292be0e507b2(ptr %v0, ptr %t593, i32 %t594)
  store i1 %t597, ptr %l243
  br label %bb112
bb111:
  store i1 false, ptr %l238, !tbaa !21
  br label %bb113
bb112:
  %t598 = load i1, ptr %l243, !tbaa !21
  store i1 %t598, ptr %l238, !tbaa !21
  br label %bb113
bb113:
  %t599 = load i1, ptr %l238, !tbaa !21
  br i1 %t599, label %bb114, label %bb115
bb114:
  %t600 = load ptr, ptr %l0, !tbaa !29
  %t602 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t600)
  store i32 %t602, ptr %l245
  br label %bb116
bb115:
  br label %bb125
bb116:
  %t603 = load ptr, ptr %l0, !tbaa !29
  %t605 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeArgs(ptr %v0, ptr %v1, ptr %t603)
  %t606 = extractvalue { i32, { i64, ptr } } %t605, 1
  %t607 = extractvalue { i32, { i64, ptr } } %t605, 0
  store i32 %t607, ptr %l249
  %t608 = icmp ne i32 %t607, 0
  br i1 %t608, label %bb118, label %ok.609, !prof !99
ok.609:
  store { i64, ptr } %t606, ptr %l248
  br label %bb117
bb117:
  %t610 = load { i64, ptr }, ptr %l248, !tbaa !27
  store { i64, ptr } %t610, ptr %l246, !tbaa !27
  br label %bb119
bb118:
  %t611 = load i32, ptr %l249, !tbaa !23
  %t612 = lshr i32 %t611, 16
  %t613 = and i32 %t611, 65535
  %t614 = icmp eq i32 %t612, 1
  %t615 = select i1 %t614, i32 1, i32 0
  %t616 = icmp eq i32 %t611, 0
  %t617 = shl i32 %t615, 16
  %t618 = or i32 %t617, %t613
  %t619 = select i1 %t616, i32 0, i32 %t618
  %t621 = insertvalue { i32, ptr } zeroinitializer, i32 %t619, 0
  store { i32, ptr } %t621, ptr %rv
  br label %ret
bb119:
  %t622 = load { i64, ptr }, ptr %l246, !tbaa !27
  store { i64, ptr } %t622, ptr %l20, !tbaa !27
  %t623 = load ptr, ptr %l0, !tbaa !29
  %t624 = load i32, ptr %l1, !tbaa !23
  %t627 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t623, i32 %t624)
  store %"compiler/source:Span" %t627, ptr %l253
  br label %bb120
bb120:
  %t628 = load ptr, ptr %l0, !tbaa !29
  %t629 = load i32, ptr %l1, !tbaa !23
  %t632 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t628, i32 %t629)
  store %"compiler/source:Span" %t632, ptr %l256
  br label %bb121
bb121:
  %t633 = load i32, ptr %l19, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t634
  %t635 = getelementptr { i64, [4 x i64] }, ptr %t634, i32 0, i32 0
  store i64 0, ptr %t635
  %t636 = load %"compiler/source:Span", ptr %l256
  %t637 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t636, 0
  %t639 = insertvalue { %"compiler/source:Span", i32 } %t637, i32 %t633, 1
  %t640 = getelementptr { i64, [4 x i64] }, ptr %t634, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t639, ptr %t640
  %t641 = load { i64, [4 x i64] }, ptr %t634
  %t643 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 40, i64 8)
  store { i64, [4 x i64] } %t641, ptr %t643
  %t644 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, [4 x i64] } zeroinitializer, ptr %t645
  %t646 = getelementptr { i64, [4 x i64] }, ptr %t645, i32 0, i32 0
  store i64 11, ptr %t646
  %t647 = load %"compiler/source:Span", ptr %l253
  %t648 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } undef, %"compiler/source:Span" %t647, 0
  %t650 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } %t648, ptr %t643, 1
  %t652 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } %t650, { i64, ptr } %t644, 2
  %t653 = getelementptr { i64, [4 x i64] }, ptr %t645, i32 0, i32 1
  store { %"compiler/source:Span", ptr, { i64, ptr } } %t652, ptr %t653
  %t654 = load { i64, [4 x i64] }, ptr %t645
  %t655 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 40, i64 8)
  store ptr %t655, ptr %lp21
  %t657 = load ptr, ptr %lp21
  store { i64, [4 x i64] } %t654, ptr %t657
  %t658 = load ptr, ptr %l0, !tbaa !29
  %t659 = load i32, ptr %l1, !tbaa !23
  %t660 = load ptr, ptr %lp21
  %t664 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eliteralAfterType(ptr %v0, ptr %v1, ptr %v1, ptr %t658, i32 %t659, ptr %t660)
  %t665 = extractvalue { i32, ptr } %t664, 1
  %t666 = extractvalue { i32, ptr } %t664, 0
  store i32 %t666, ptr %l267
  %t667 = icmp ne i32 %t666, 0
  br i1 %t667, label %bb123, label %ok.668, !prof !99
ok.668:
  store ptr %t665, ptr %l266
  br label %bb122
bb122:
  %t669 = load ptr, ptr %l266, !tbaa !29
  store ptr %t669, ptr %l262, !tbaa !29
  br label %bb124
bb123:
  %t670 = load i32, ptr %l267, !tbaa !23
  %t671 = lshr i32 %t670, 16
  %t672 = and i32 %t670, 65535
  %t673 = icmp eq i32 %t671, 1
  %t674 = select i1 %t673, i32 1, i32 0
  %t675 = icmp eq i32 %t670, 0
  %t676 = shl i32 %t674, 16
  %t677 = or i32 %t676, %t672
  %t678 = select i1 %t675, i32 0, i32 %t677
  %t680 = insertvalue { i32, ptr } zeroinitializer, i32 %t678, 0
  store { i32, ptr } %t680, ptr %rv
  br label %ret
bb124:
  %t681 = load ptr, ptr %l262, !tbaa !29
  %t682 = insertvalue { i32, ptr } zeroinitializer, ptr %t681, 1
  store { i32, ptr } %t682, ptr %rv
  br label %ret
bb125:
  %t683 = load i32, ptr %l18, !range !{i32 0, i32 116}
  %t685 = trunc i64 98 to i32
  %t686 = icmp eq i32 %t683, %t685
  br i1 %t686, label %bb126, label %bb127
bb126:
  %t688 = load ptr, ptr %l0, !tbaa !29
  %t690 = getelementptr %"compiler/parse:Parser", ptr %t688, i32 0, i32 3
  %t691 = load ptr, ptr %t690, !tbaa !29
  %t693 = getelementptr %"compiler/parse:Oracle", ptr %t691, i32 0, i32 2
  %t694 = load i32, ptr %l19, !tbaa !23
  %t697 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3_H8da9376267bda3f76393292be0e507b2(ptr %v0, ptr %t693, i32 %t694)
  store i1 %t697, ptr %l276
  br label %bb128
bb127:
  store i1 false, ptr %l271, !tbaa !21
  br label %bb137
bb128:
  %t698 = load i1, ptr %l276, !tbaa !21
  br i1 %t698, label %bb129, label %bb130
bb129:
  store i1 true, ptr %l277, !tbaa !21
  br label %bb132
bb130:
  %t699 = load ptr, ptr %l0, !tbaa !29
  %t701 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeArgsCall(ptr %v0, ptr %t699, i64 1)
  store i1 %t701, ptr %l279
  br label %bb131
bb131:
  %t702 = load i1, ptr %l279, !tbaa !21
  store i1 %t702, ptr %l277, !tbaa !21
  br label %bb132
bb132:
  %t703 = load i1, ptr %l277, !tbaa !21
  br i1 %t703, label %bb133, label %bb134
bb133:
  store i1 true, ptr %l280, !tbaa !21
  br label %bb136
bb134:
  %t704 = load ptr, ptr %l0, !tbaa !29
  %t706 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2espacedTypeArgs(ptr %v0, ptr %t704, i64 1)
  store i1 %t706, ptr %l282
  br label %bb135
bb135:
  %t707 = load i1, ptr %l282, !tbaa !21
  store i1 %t707, ptr %l280, !tbaa !21
  br label %bb136
bb136:
  %t708 = load i1, ptr %l280, !tbaa !21
  store i1 %t708, ptr %l271, !tbaa !21
  br label %bb137
bb137:
  %t709 = load i1, ptr %l271, !tbaa !21
  br i1 %t709, label %bb138, label %bb139
bb138:
  %t710 = load ptr, ptr %l0, !tbaa !29
  %t712 = getelementptr %"compiler/parse:Parser", ptr %t710, i32 0, i32 3
  %t713 = load ptr, ptr %t712, !tbaa !29
  %t715 = getelementptr %"compiler/parse:Oracle", ptr %t713, i32 0, i32 2
  %t716 = load i32, ptr %l19, !tbaa !23
  %t719 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3_H8da9376267bda3f76393292be0e507b2(ptr %v0, ptr %t715, i32 %t716)
  store i1 %t719, ptr %l287
  br label %bb140
bb139:
  br label %bb159
bb140:
  %t720 = load i1, ptr %l287, !tbaa !21
  %t721 = xor i1 %t720, true
  br i1 %t721, label %bb141, label %bb142
bb141:
  %t723 = load ptr, ptr %l0, !tbaa !29
  %t725 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2espacedTypeArgs(ptr %v0, ptr %t723, i64 1)
  store i1 %t725, ptr %l291
  br label %bb143
bb142:
  store i1 false, ptr %l289, !tbaa !21
  br label %bb144
bb143:
  %t726 = load i1, ptr %l291, !tbaa !21
  store i1 %t726, ptr %l289, !tbaa !21
  br label %bb144
bb144:
  %t727 = load i1, ptr %l289, !tbaa !21
  br i1 %t727, label %bb145, label %bb146
bb145:
  %t728 = load ptr, ptr %l0, !tbaa !29
  store ptr %t728, ptr %l292, !tbaa !29
  %t729 = load ptr, ptr %l0, !tbaa !29
  %t731 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2elookTok(ptr %v0, ptr %t729, i64 1)
  store %"compiler/token:Token" %t731, ptr %l294
  br label %bb147
bb146:
  br label %bb152
bb147:
  %t732 = getelementptr %"compiler/token:Token", ptr %l294, i32 0, i32 2
  %t733 = load i32, ptr %t732, !tbaa !23
  store i32 %t733, ptr %l295, !tbaa !23
  %t734 = load ptr, ptr %l0, !tbaa !29
  %t736 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2elookTok(ptr %v0, ptr %t734, i64 1)
  store %"compiler/token:Token" %t736, ptr %l297
  br label %bb148
bb148:
  %t737 = getelementptr %"compiler/token:Token", ptr %l297, i32 0, i32 3
  %t738 = load i32, ptr %t737, !tbaa !23
  store i32 %t738, ptr %l298, !tbaa !23
  %t739 = load ptr, ptr %l0, !tbaa !29
  %t740 = load %"compiler/token:Token", ptr %l17
  %t743 = call { i64, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etext(ptr %v0, ptr %v0, ptr %t739, %"compiler/token:Token" %t740)
  store { i64, ptr } %t743, ptr %l301
  br label %bb149
bb149:
  %t744 = load { i64, ptr }, ptr %l301, !tbaa !27
  %t745 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTypeArgsSpaced(ptr %v0, ptr %v0, { i64, ptr } %t744)
  store %"compiler/diagmsg:Msg" %t745, ptr %l302
  br label %bb150
bb150:
  %t746 = load ptr, ptr %l292, !tbaa !29
  %t747 = load i32, ptr %l295, !tbaa !23
  %t748 = load i32, ptr %l298, !tbaa !23
  %t749 = load %"compiler/diagmsg:Msg", ptr %l302
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereport(ptr %v0, ptr %v0, ptr %t746, i32 %t747, i32 %t748, %"compiler/diagmsg:Msg" %t749)
  br label %bb151
bb151:
  br label %bb152
bb152:
  %t750 = load ptr, ptr %l0, !tbaa !29
  %t752 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t750)
  store i32 %t752, ptr %l304
  br label %bb153
bb153:
  %t753 = load ptr, ptr %l0, !tbaa !29
  %t755 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeArgs(ptr %v0, ptr %v1, ptr %t753)
  %t756 = extractvalue { i32, { i64, ptr } } %t755, 1
  %t757 = extractvalue { i32, { i64, ptr } } %t755, 0
  store i32 %t757, ptr %l308
  %t758 = icmp ne i32 %t757, 0
  br i1 %t758, label %bb155, label %ok.759, !prof !99
ok.759:
  store { i64, ptr } %t756, ptr %l307
  br label %bb154
bb154:
  %t760 = load { i64, ptr }, ptr %l307, !tbaa !27
  store { i64, ptr } %t760, ptr %l305, !tbaa !27
  br label %bb156
bb155:
  %t761 = load i32, ptr %l308, !tbaa !23
  %t762 = lshr i32 %t761, 16
  %t763 = and i32 %t761, 65535
  %t764 = icmp eq i32 %t762, 1
  %t765 = select i1 %t764, i32 1, i32 0
  %t766 = icmp eq i32 %t761, 0
  %t767 = shl i32 %t765, 16
  %t768 = or i32 %t767, %t763
  %t769 = select i1 %t766, i32 0, i32 %t768
  %t771 = insertvalue { i32, ptr } zeroinitializer, i32 %t769, 0
  store { i32, ptr } %t771, ptr %rv
  br label %ret
bb156:
  %t772 = load { i64, ptr }, ptr %l305, !tbaa !27
  store { i64, ptr } %t772, ptr %l22, !tbaa !27
  %t773 = load ptr, ptr %l0, !tbaa !29
  %t774 = load i32, ptr %l1, !tbaa !23
  %t777 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t773, i32 %t774)
  store %"compiler/source:Span" %t777, ptr %l312
  br label %bb157
bb157:
  %t778 = load ptr, ptr %l0, !tbaa !29
  %t779 = load i32, ptr %l1, !tbaa !23
  %t782 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t778, i32 %t779)
  store %"compiler/source:Span" %t782, ptr %l315
  br label %bb158
bb158:
  %t783 = load i32, ptr %l19, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t784
  %t785 = getelementptr { i64, [4 x i64] }, ptr %t784, i32 0, i32 0
  store i64 0, ptr %t785
  %t786 = load %"compiler/source:Span", ptr %l315
  %t787 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t786, 0
  %t789 = insertvalue { %"compiler/source:Span", i32 } %t787, i32 %t783, 1
  %t790 = getelementptr { i64, [4 x i64] }, ptr %t784, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t789, ptr %t790
  %t791 = load { i64, [4 x i64] }, ptr %t784
  %t793 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 40, i64 8)
  store { i64, [4 x i64] } %t791, ptr %t793
  %t794 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, [4 x i64] } zeroinitializer, ptr %t795
  %t796 = getelementptr { i64, [4 x i64] }, ptr %t795, i32 0, i32 0
  store i64 11, ptr %t796
  %t797 = load %"compiler/source:Span", ptr %l312
  %t798 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } undef, %"compiler/source:Span" %t797, 0
  %t800 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } %t798, ptr %t793, 1
  %t802 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } %t800, { i64, ptr } %t794, 2
  %t803 = getelementptr { i64, [4 x i64] }, ptr %t795, i32 0, i32 1
  store { %"compiler/source:Span", ptr, { i64, ptr } } %t802, ptr %t803
  %t804 = load { i64, [4 x i64] }, ptr %t795
  %t806 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 40, i64 8)
  store { i64, [4 x i64] } %t804, ptr %t806
  %t808 = insertvalue { i32, ptr } zeroinitializer, ptr %t806, 1
  store { i32, ptr } %t808, ptr %rv
  br label %ret
bb159:
  %t809 = load i32, ptr %l18, !range !{i32 0, i32 116}
  %t811 = trunc i64 77 to i32
  %t812 = icmp eq i32 %t809, %t811
  br i1 %t812, label %bb160, label %bb161
bb160:
  %t814 = load ptr, ptr %l0, !tbaa !29
  %t816 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elook(ptr %v0, ptr %t814, i64 2)
  store i32 %t816, ptr %l326
  br label %bb162
bb161:
  store i1 false, ptr %l324, !tbaa !21
  br label %bb163
bb162:
  %t817 = load i32, ptr %l326, !range !{i32 0, i32 116}
  %t819 = trunc i64 102 to i32
  %t820 = icmp eq i32 %t817, %t819
  store i1 %t820, ptr %l324, !tbaa !21
  br label %bb163
bb163:
  %t822 = load i1, ptr %l324, !tbaa !21
  br i1 %t822, label %bb164, label %bb165
bb164:
  %t823 = load ptr, ptr %l0, !tbaa !29
  %t825 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elook(ptr %v0, ptr %t823, i64 3)
  store i32 %t825, ptr %l331
  br label %bb166
bb165:
  store i1 false, ptr %l329, !tbaa !21
  br label %bb167
bb166:
  %t826 = load i32, ptr %l331, !range !{i32 0, i32 116}
  %t828 = trunc i64 112 to i32
  %t829 = icmp eq i32 %t826, %t828
  store i1 %t829, ptr %l329, !tbaa !21
  br label %bb167
bb167:
  %t831 = load i1, ptr %l329, !tbaa !21
  br i1 %t831, label %bb168, label %bb169
bb168:
  %t832 = load ptr, ptr %l0, !tbaa !29
  %t834 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t832)
  store i32 %t834, ptr %l335
  br label %bb170
bb169:
  br label %bb189
bb170:
  %t835 = load ptr, ptr %l0, !tbaa !29
  %t837 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2enullMark(ptr %v0, ptr %t835)
  store i1 %t837, ptr %l337
  br label %bb171
bb171:
  %t838 = load i1, ptr %l337, !tbaa !21
  br i1 %t838, label %bb172, label %bb173
bb172:
  %t839 = load ptr, ptr %l0, !tbaa !29
  %t840 = load i32, ptr %l1, !tbaa !23
  %t843 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t839, i32 %t840)
  store %"compiler/source:Span" %t843, ptr %l340
  br label %bb174
bb173:
  br label %bb187
bb174:
  %t844 = load i32, ptr %l19, !tbaa !23
  store i32 %t844, ptr %l341, !tbaa !23
  %t845 = icmp sge i64 1, 0
  br i1 %t845, label %bb175, label %bb176
bb175:
  %t847 = icmp sle i64 1, 2305843009213693951
  br i1 %t847, label %bb177, label %bb178
bb176:
  call void @__olang_check_failed(ptr @olang_loc_fd55a40e832939eb_76ee8367288fff1f)
  unreachable
bb177:
  %t849 = mul i64 1, 4
  %t850 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t849)
  %t851 = load i32, ptr %l341, !tbaa !23
  store i64 0, ptr %t852
  br label %fill.853
fill.853:
  %t856 = load i64, ptr %t852
  %t857 = icmp slt i64 %t856, 1
  br i1 %t857, label %fillb.854, label %filld.855
fillb.854:
  %t858 = getelementptr i32, ptr %t850, i64 %t856
  store i32 %t851, ptr %t858
  %t859 = add i64 %t856, 1
  store i64 %t859, ptr %t852
  br label %fill.853
filld.855:
  %t860 = insertvalue { i64, ptr } undef, i64 1, 0
  %t861 = insertvalue { i64, ptr } %t860, ptr %t850, 1
  store { i64, ptr } %t861, ptr %l344, !tbaa !27
  %t862 = icmp sge i64 0, 0
  br i1 %t862, label %bb179, label %bb180
bb178:
  call void @__olang_check_failed(ptr @olang_loc_fd55a40e832939eb_76ee8367288fff1f)
  unreachable
bb179:
  %t864 = icmp sle i64 0, 1152921504606846975
  br i1 %t864, label %bb181, label %bb182
bb180:
  call void @__olang_check_failed(ptr @olang_loc_fd55a40e832939eb_76ee8367288fff1f)
  unreachable
bb181:
  %t866 = mul i64 0, 8
  %t867 = insertvalue { i64, ptr } undef, i64 0, 0
  %t868 = insertvalue { i64, ptr } %t867, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, [5 x i64] } zeroinitializer, ptr %t869
  %t870 = getelementptr { i64, [5 x i64] }, ptr %t869, i32 0, i32 0
  store i64 0, ptr %t870
  %t871 = load %"compiler/source:Span", ptr %l340
  %t872 = insertvalue { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } undef, %"compiler/source:Span" %t871, 0
  %t873 = load { i64, ptr }, ptr %l344, !tbaa !27
  %t874 = insertvalue { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } %t872, { i64, ptr } %t873, 1
  %t876 = insertvalue { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } %t874, { i64, ptr } %t868, 2
  %t877 = getelementptr { i64, [5 x i64] }, ptr %t869, i32 0, i32 1
  store { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } %t876, ptr %t877
  %t878 = load { i64, [5 x i64] }, ptr %t869
  %t880 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 48, i64 8)
  store { i64, [5 x i64] } %t878, ptr %t880
  %t882 = load ptr, ptr %l0, !tbaa !29
  store ptr %t882, ptr %l351, !tbaa !29
  %t883 = load i32, ptr %l1, !tbaa !23
  store i32 %t883, ptr %l352, !tbaa !23
  %t884 = load ptr, ptr %l0, !tbaa !29
  %t885 = load i32, ptr %l1, !tbaa !23
  %t890 = call ptr @compiler_2fparse_2ecompiler_2fparse_3aParser_2emarkers(ptr %v0, ptr %v1, ptr %v1, ptr %t884, i32 %t885, ptr %t880)
  store ptr %t890, ptr %l356
  br label %bb183
bb182:
  call void @__olang_check_failed(ptr @olang_loc_fd55a40e832939eb_76ee8367288fff1f)
  unreachable
bb183:
  %t891 = load ptr, ptr %l351, !tbaa !29
  %t892 = load i32, ptr %l352, !tbaa !23
  %t893 = load ptr, ptr %l356, !tbaa !29
  %t894 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2earrayLit(ptr %v0, ptr %v1, ptr %v1, ptr %t891, i32 %t892, ptr %t893)
  %t895 = extractvalue { i32, ptr } %t894, 1
  %t896 = extractvalue { i32, ptr } %t894, 0
  store i32 %t896, ptr %l358
  %t897 = icmp ne i32 %t896, 0
  br i1 %t897, label %bb185, label %ok.898, !prof !99
ok.898:
  store ptr %t895, ptr %l357
  br label %bb184
bb184:
  %t899 = load ptr, ptr %l357, !tbaa !29
  store ptr %t899, ptr %l350, !tbaa !29
  br label %bb186
bb185:
  %t900 = load i32, ptr %l358, !tbaa !23
  %t901 = lshr i32 %t900, 16
  %t902 = and i32 %t900, 65535
  %t903 = icmp eq i32 %t901, 1
  %t904 = select i1 %t903, i32 1, i32 0
  %t905 = icmp eq i32 %t900, 0
  %t906 = shl i32 %t904, 16
  %t907 = or i32 %t906, %t902
  %t908 = select i1 %t905, i32 0, i32 %t907
  %t910 = insertvalue { i32, ptr } zeroinitializer, i32 %t908, 0
  store { i32, ptr } %t910, ptr %rv
  br label %ret
bb186:
  %t911 = load ptr, ptr %l350, !tbaa !29
  %t912 = insertvalue { i32, ptr } zeroinitializer, ptr %t911, 1
  store { i32, ptr } %t912, ptr %rv
  br label %ret
bb187:
  %t913 = load ptr, ptr %l0, !tbaa !29
  %t914 = load i32, ptr %l1, !tbaa !23
  %t917 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t913, i32 %t914)
  store %"compiler/source:Span" %t917, ptr %l362
  br label %bb188
bb188:
  %t918 = load i32, ptr %l19, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t919
  %t920 = getelementptr { i64, [4 x i64] }, ptr %t919, i32 0, i32 0
  store i64 0, ptr %t920
  %t921 = load %"compiler/source:Span", ptr %l362
  %t922 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t921, 0
  %t924 = insertvalue { %"compiler/source:Span", i32 } %t922, i32 %t918, 1
  %t925 = getelementptr { i64, [4 x i64] }, ptr %t919, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t924, ptr %t925
  %t926 = load { i64, [4 x i64] }, ptr %t919
  %t928 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 40, i64 8)
  store { i64, [4 x i64] } %t926, ptr %t928
  %t930 = insertvalue { i32, ptr } zeroinitializer, ptr %t928, 1
  store { i32, ptr } %t930, ptr %rv
  br label %ret
bb189:
  %t931 = load i32, ptr %l18, !range !{i32 0, i32 116}
  %t933 = trunc i64 102 to i32
  %t934 = icmp eq i32 %t931, %t933
  br i1 %t934, label %bb190, label %bb191
bb190:
  %t936 = load ptr, ptr %l0, !tbaa !29
  %t938 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elook(ptr %v0, ptr %t936, i64 2)
  store i32 %t938, ptr %l369
  br label %bb192
bb191:
  br label %bb221
bb192:
  %t939 = load i32, ptr %l369, !range !{i32 0, i32 116}
  store i32 %t939, ptr %l24
  %t940 = load i32, ptr %l24, !range !{i32 0, i32 116}
  %t942 = trunc i64 112 to i32
  %t943 = icmp eq i32 %t940, %t942
  br i1 %t943, label %bb193, label %bb194
bb193:
  store i1 true, ptr %l372, !tbaa !21
  br label %bb203
bb194:
  %t945 = load i32, ptr %l24, !range !{i32 0, i32 116}
  %t947 = trunc i64 1 to i32
  %t948 = icmp eq i32 %t945, %t947
  br i1 %t948, label %bb195, label %bb196
bb195:
  %t950 = load ptr, ptr %l0, !tbaa !29
  %t952 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elook(ptr %v0, ptr %t950, i64 3)
  store i32 %t952, ptr %l377
  br label %bb197
bb196:
  store i1 false, ptr %l375, !tbaa !21
  br label %bb198
bb197:
  %t953 = load i32, ptr %l377, !range !{i32 0, i32 116}
  %t955 = trunc i64 112 to i32
  %t956 = icmp eq i32 %t953, %t955
  store i1 %t956, ptr %l375, !tbaa !21
  br label %bb198
bb198:
  %t958 = load i1, ptr %l375, !tbaa !21
  br i1 %t958, label %bb199, label %bb200
bb199:
  %t959 = load ptr, ptr %l0, !tbaa !29
  %t961 = getelementptr %"compiler/parse:Parser", ptr %t959, i32 0, i32 3
  %t962 = load ptr, ptr %t961, !tbaa !29
  %t964 = getelementptr %"compiler/parse:Oracle", ptr %t962, i32 0, i32 0
  %t965 = load i32, ptr %l19, !tbaa !23
  %t968 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3_H8da9376267bda3f76393292be0e507b2(ptr %v0, ptr %t964, i32 %t965)
  store i1 %t968, ptr %l385
  br label %bb201
bb200:
  store i1 false, ptr %l380, !tbaa !21
  br label %bb202
bb201:
  %t969 = load i1, ptr %l385, !tbaa !21
  store i1 %t969, ptr %l380, !tbaa !21
  br label %bb202
bb202:
  %t970 = load i1, ptr %l380, !tbaa !21
  store i1 %t970, ptr %l372, !tbaa !21
  br label %bb203
bb203:
  %t971 = load i1, ptr %l372, !tbaa !21
  br i1 %t971, label %bb204, label %bb205
bb204:
  %t972 = load ptr, ptr %l0, !tbaa !29
  %t974 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t972)
  store i32 %t974, ptr %l387
  br label %bb206
bb205:
  br label %bb220
bb206:
  %t975 = load ptr, ptr %l0, !tbaa !29
  %t976 = load i32, ptr %l1, !tbaa !23
  %t979 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t975, i32 %t976)
  store %"compiler/source:Span" %t979, ptr %l390
  br label %bb207
bb207:
  %t980 = load i32, ptr %l19, !tbaa !23
  store i32 %t980, ptr %l391, !tbaa !23
  %t981 = icmp sge i64 1, 0
  br i1 %t981, label %bb208, label %bb209
bb208:
  %t983 = icmp sle i64 1, 2305843009213693951
  br i1 %t983, label %bb210, label %bb211
bb209:
  call void @__olang_check_failed(ptr @olang_loc_f58c14e72eb20088_8619c4b6e2d8c1bc)
  unreachable
bb210:
  %t985 = mul i64 1, 4
  %t986 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t985)
  %t987 = load i32, ptr %l391, !tbaa !23
  store i64 0, ptr %t988
  br label %fill.989
fill.989:
  %t992 = load i64, ptr %t988
  %t993 = icmp slt i64 %t992, 1
  br i1 %t993, label %fillb.990, label %filld.991
fillb.990:
  %t994 = getelementptr i32, ptr %t986, i64 %t992
  store i32 %t987, ptr %t994
  %t995 = add i64 %t992, 1
  store i64 %t995, ptr %t988
  br label %fill.989
filld.991:
  %t996 = insertvalue { i64, ptr } undef, i64 1, 0
  %t997 = insertvalue { i64, ptr } %t996, ptr %t986, 1
  store { i64, ptr } %t997, ptr %l394, !tbaa !27
  %t998 = icmp sge i64 0, 0
  br i1 %t998, label %bb212, label %bb213
bb211:
  call void @__olang_check_failed(ptr @olang_loc_f58c14e72eb20088_8619c4b6e2d8c1bc)
  unreachable
bb212:
  %t1000 = icmp sle i64 0, 1152921504606846975
  br i1 %t1000, label %bb214, label %bb215
bb213:
  call void @__olang_check_failed(ptr @olang_loc_f58c14e72eb20088_8619c4b6e2d8c1bc)
  unreachable
bb214:
  %t1002 = mul i64 0, 8
  %t1003 = insertvalue { i64, ptr } undef, i64 0, 0
  %t1004 = insertvalue { i64, ptr } %t1003, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, [5 x i64] } zeroinitializer, ptr %t1005
  %t1006 = getelementptr { i64, [5 x i64] }, ptr %t1005, i32 0, i32 0
  store i64 0, ptr %t1006
  %t1007 = load %"compiler/source:Span", ptr %l390
  %t1008 = insertvalue { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } undef, %"compiler/source:Span" %t1007, 0
  %t1009 = load { i64, ptr }, ptr %l394, !tbaa !27
  %t1010 = insertvalue { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } %t1008, { i64, ptr } %t1009, 1
  %t1012 = insertvalue { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } %t1010, { i64, ptr } %t1004, 2
  %t1013 = getelementptr { i64, [5 x i64] }, ptr %t1005, i32 0, i32 1
  store { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } %t1012, ptr %t1013
  %t1014 = load { i64, [5 x i64] }, ptr %t1005
  %t1016 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 48, i64 8)
  store { i64, [5 x i64] } %t1014, ptr %t1016
  %t1018 = load ptr, ptr %l0, !tbaa !29
  %t1019 = load i32, ptr %l1, !tbaa !23
  %t1024 = call ptr @compiler_2fparse_2ecompiler_2fparse_3aParser_2emarkers(ptr %v0, ptr %v1, ptr %v1, ptr %t1018, i32 %t1019, ptr %t1016)
  store ptr %t1024, ptr %l403
  br label %bb216
bb215:
  call void @__olang_check_failed(ptr @olang_loc_f58c14e72eb20088_8619c4b6e2d8c1bc)
  unreachable
bb216:
  %t1025 = load ptr, ptr %l403, !tbaa !29
  %t1026 = load ptr, ptr %l0, !tbaa !29
  %t1027 = load i32, ptr %l1, !tbaa !23
  %t1032 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2earrayLit(ptr %v0, ptr %v1, ptr %v1, ptr %t1026, i32 %t1027, ptr %t1025)
  %t1033 = extractvalue { i32, ptr } %t1032, 1
  %t1034 = extractvalue { i32, ptr } %t1032, 0
  store i32 %t1034, ptr %l409
  %t1035 = icmp ne i32 %t1034, 0
  br i1 %t1035, label %bb218, label %ok.1036, !prof !99
ok.1036:
  store ptr %t1033, ptr %l408
  br label %bb217
bb217:
  %t1037 = load ptr, ptr %l408, !tbaa !29
  store ptr %t1037, ptr %l404, !tbaa !29
  br label %bb219
bb218:
  %t1038 = load i32, ptr %l409, !tbaa !23
  %t1039 = lshr i32 %t1038, 16
  %t1040 = and i32 %t1038, 65535
  %t1041 = icmp eq i32 %t1039, 1
  %t1042 = select i1 %t1041, i32 1, i32 0
  %t1043 = icmp eq i32 %t1038, 0
  %t1044 = shl i32 %t1042, 16
  %t1045 = or i32 %t1044, %t1040
  %t1046 = select i1 %t1043, i32 0, i32 %t1045
  %t1048 = insertvalue { i32, ptr } zeroinitializer, i32 %t1046, 0
  store { i32, ptr } %t1048, ptr %rv
  br label %ret
bb219:
  %t1049 = load ptr, ptr %l404, !tbaa !29
  %t1050 = insertvalue { i32, ptr } zeroinitializer, ptr %t1049, 1
  store { i32, ptr } %t1050, ptr %rv
  br label %ret
bb220:
  br label %bb221
bb221:
  %t1051 = load ptr, ptr %l0, !tbaa !29
  %t1053 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t1051)
  store i32 %t1053, ptr %l412
  br label %bb222
bb222:
  %t1054 = load ptr, ptr %l0, !tbaa !29
  %t1055 = load i32, ptr %l1, !tbaa !23
  %t1058 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t1054, i32 %t1055)
  store %"compiler/source:Span" %t1058, ptr %l415
  br label %bb223
bb223:
  %t1059 = load i32, ptr %l19, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t1060
  %t1061 = getelementptr { i64, [4 x i64] }, ptr %t1060, i32 0, i32 0
  store i64 0, ptr %t1061
  %t1062 = load %"compiler/source:Span", ptr %l415
  %t1063 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t1062, 0
  %t1065 = insertvalue { %"compiler/source:Span", i32 } %t1063, i32 %t1059, 1
  %t1066 = getelementptr { i64, [4 x i64] }, ptr %t1060, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t1065, ptr %t1066
  %t1067 = load { i64, [4 x i64] }, ptr %t1060
  %t1069 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 40, i64 8)
  store { i64, [4 x i64] } %t1067, ptr %t1069
  %t1071 = insertvalue { i32, ptr } zeroinitializer, ptr %t1069, 1
  store { i32, ptr } %t1071, ptr %rv
  br label %ret
bb224:
  %t1072 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t1074 = trunc i64 112 to i32
  %t1075 = icmp eq i32 %t1072, %t1074
  br i1 %t1075, label %bb225, label %bb226
bb225:
  br label %bb227
bb226:
  br label %bb231
bb227:
  %t1077 = load ptr, ptr %l0, !tbaa !29
  %t1079 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ebareLit(ptr %v0, ptr %v1, ptr %t1077)
  %t1080 = extractvalue { i32, ptr } %t1079, 1
  %t1081 = extractvalue { i32, ptr } %t1079, 0
  store i32 %t1081, ptr %l424
  %t1082 = icmp ne i32 %t1081, 0
  br i1 %t1082, label %bb229, label %ok.1083, !prof !99
ok.1083:
  store ptr %t1080, ptr %l423
  br label %bb228
bb228:
  %t1084 = load ptr, ptr %l423, !tbaa !29
  store ptr %t1084, ptr %l421, !tbaa !29
  br label %bb230
bb229:
  %t1085 = load i32, ptr %l424, !tbaa !23
  %t1086 = lshr i32 %t1085, 16
  %t1087 = and i32 %t1085, 65535
  %t1088 = icmp eq i32 %t1086, 1
  %t1089 = select i1 %t1088, i32 1, i32 0
  %t1090 = icmp eq i32 %t1085, 0
  %t1091 = shl i32 %t1089, 16
  %t1092 = or i32 %t1091, %t1087
  %t1093 = select i1 %t1090, i32 0, i32 %t1092
  %t1095 = insertvalue { i32, ptr } zeroinitializer, i32 %t1093, 0
  store { i32, ptr } %t1095, ptr %rv
  br label %ret
bb230:
  %t1096 = load ptr, ptr %l421, !tbaa !29
  %t1097 = insertvalue { i32, ptr } zeroinitializer, ptr %t1096, 1
  store { i32, ptr } %t1097, ptr %rv
  br label %ret
bb231:
  br i1 true, label %bb232, label %bb233
bb232:
  br label %bb234
bb233:
  br label %bb238
bb234:
  store %olang.scope zeroinitializer, ptr %s21
  %t1098 = load ptr, ptr %l0, !tbaa !29
  %t1100 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2efail(ptr %v0, ptr %s21, ptr %t1098, { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d15, i32 0, i32 1) })
  store i32 %t1100, ptr %l427
  %t1101 = icmp ne i32 %t1100, 0
  br i1 %t1101, label %bb236, label %ok.1102, !prof !99
ok.1102:
  br label %bb235
bb235:
  br label %bb237
bb236:
  %t1103 = load i32, ptr %l427, !tbaa !23
  %t1104 = lshr i32 %t1103, 16
  %t1105 = and i32 %t1103, 65535
  %t1106 = icmp eq i32 %t1104, 1
  %t1107 = select i1 %t1106, i32 1, i32 0
  %t1108 = icmp eq i32 %t1103, 0
  %t1109 = shl i32 %t1107, 16
  %t1110 = or i32 %t1109, %t1105
  %t1111 = select i1 %t1108, i32 0, i32 %t1110
  call void @__olang_scope_close(ptr %s21)
  %t1113 = insertvalue { i32, ptr } zeroinitializer, i32 %t1111, 0
  store { i32, ptr } %t1113, ptr %rv
  br label %ret
bb237:
  call void @__olang_scope_close(ptr %s21)
  br label %bb239
bb238:
  call void @__olang_check_failed(ptr @olang_loc_c608f7f9cf1bb136_7782a31fde86d192)
  unreachable
bb239:
  call void @__olang_check_failed(ptr @olang_loc_4bdaee1d5dba1351_2f255a58086b38a5)
  unreachable
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2epromises(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l8 = alloca i32
  %l9 = alloca i1
  %l10 = alloca i1
  %l12 = alloca i1
  %l16 = alloca i32
  %l18 = alloca i32
  %l20 = alloca i32
  %l21 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l25 = alloca i1
  %l28 = alloca ptr
  %l29 = alloca i32
  %l31 = alloca i32
  %l32 = alloca i32
  %l36 = alloca i1
  %l39 = alloca i1
  %l40 = alloca i1
  %l42 = alloca i1
  %l45 = alloca i32
  %l46 = alloca ptr
  %l47 = alloca i32
  %l49 = alloca i32
  %l50 = alloca i32
  %l54 = alloca i1
  %l55 = alloca i1
  %l57 = alloca i1
  %l61 = alloca i32
  %l62 = alloca ptr
  %l63 = alloca i32
  %l65 = alloca i32
  %l66 = alloca i32
  %l68 = alloca ptr
  %l71 = alloca %"compiler/source:Span"
  %l72 = alloca i32
  %l73 = alloca i64
  %l76 = alloca { i64, ptr }
  %l77 = alloca %"compiler/ast:Promise"
  %l80 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aPromise_26_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l5
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l5
  %t3 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %t3
  store ptr %t3, ptr %l1, !tbaa !29
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2epeek(ptr %v0, ptr %t5)
  store i32 %t7, ptr %l8
  br label %bb3
bb3:
  %t8 = load i32, ptr %l8, !range !{i32 0, i32 116}
  %t9 = call i1 @compiler_2fparse_2epromiseWord(i32 %t8)
  store i1 %t9, ptr %l9
  br label %bb4
bb4:
  %t10 = load i1, ptr %l9, !tbaa !21
  br i1 %t10, label %bb5, label %bb6
bb5:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ebreakBefore(ptr %v0, ptr %t11)
  store i1 %t13, ptr %l12
  br label %bb7
bb6:
  store i1 false, ptr %l10, !tbaa !21
  br label %bb8
bb7:
  %t14 = load i1, ptr %l12, !tbaa !21
  %t15 = xor i1 %t14, true
  store i1 %t15, ptr %l10, !tbaa !21
  br label %bb8
bb8:
  %t17 = load i1, ptr %l10, !tbaa !21
  %t18 = xor i1 %t17, true
  br i1 %t18, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s1)
  br label %bb65
bb10:
  br label %bb11
bb11:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ehere(ptr %v0, ptr %t20)
  store i32 %t22, ptr %l16
  br label %bb12
bb12:
  %t23 = load i32, ptr %l16, !tbaa !23
  store i32 %t23, ptr %l2, !tbaa !23
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2epeek(ptr %v0, ptr %t24)
  store i32 %t26, ptr %l18
  br label %bb13
bb13:
  %t27 = load i32, ptr %l18, !range !{i32 0, i32 116}
  store i32 %t27, ptr %l3
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t28)
  store i32 %t30, ptr %l20
  br label %bb14
bb14:
  %t31 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ector(ptr %s1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t31, ptr %l21
  br label %bb15
bb15:
  %t32 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l21
  %t33 = call ptr @__olang_scope_alloc_a(ptr %s1, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t32, ptr %t33
  store ptr %t33, ptr %l4, !tbaa !29
  %t35 = load i32, ptr %l3, !range !{i32 0, i32 116}
  %t37 = trunc i64 65 to i32
  %t38 = icmp eq i32 %t35, %t37
  br i1 %t38, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l25, !tbaa !21
  br label %bb18
bb17:
  %t40 = load i32, ptr %l3, !range !{i32 0, i32 116}
  %t42 = trunc i64 64 to i32
  %t43 = icmp eq i32 %t40, %t42
  store i1 %t43, ptr %l25, !tbaa !21
  br label %bb18
bb18:
  %t45 = load i1, ptr %l25, !tbaa !21
  br i1 %t45, label %bb19, label %bb20
bb19:
  %t46 = load ptr, ptr %l4, !tbaa !29
  store ptr %t46, ptr %l28, !tbaa !29
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ename(ptr %v0, ptr %t47)
  %t50 = extractvalue { i32, i32 } %t49, 1
  %t51 = extractvalue { i32, i32 } %t49, 0
  store i32 %t51, ptr %l32
  %t52 = icmp ne i32 %t51, 0
  br i1 %t52, label %bb22, label %ok.53, !prof !99
ok.53:
  store i32 %t50, ptr %l31
  br label %bb21
bb20:
  br label %bb25
bb21:
  %t54 = load i32, ptr %l31, !tbaa !23
  store i32 %t54, ptr %l29, !tbaa !23
  br label %bb23
bb22:
  %t55 = load i32, ptr %l32, !tbaa !23
  %t56 = lshr i32 %t55, 16
  %t57 = and i32 %t55, 65535
  %t58 = icmp eq i32 %t56, 1
  %t59 = select i1 %t58, i32 1, i32 0
  %t60 = icmp eq i32 %t55, 0
  %t61 = shl i32 %t59, 16
  %t62 = or i32 %t61, %t57
  %t63 = select i1 %t60, i32 0, i32 %t62
  call void @__olang_scope_close(ptr %s1)
  %t65 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t63, 0
  store { i32, { i64, ptr } } %t65, ptr %rv
  br label %ret
bb23:
  %t66 = load ptr, ptr %l28, !tbaa !29
  %t67 = load i32, ptr %l29, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ePush_3ccompiler_2fsource_3aNameId_3e(ptr %s1, ptr %t66, i32 %t67)
  br label %bb24
bb24:
  br label %bb25
bb25:
  %t68 = load i32, ptr %l3, !range !{i32 0, i32 116}
  %t70 = trunc i64 64 to i32
  %t71 = icmp eq i32 %t68, %t70
  br i1 %t71, label %bb26, label %bb27
bb26:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t76 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t73, i32 27)
  store i1 %t76, ptr %l39
  br label %bb28
bb27:
  store i1 false, ptr %l36, !tbaa !21
  br label %bb29
bb28:
  %t77 = load i1, ptr %l39, !tbaa !21
  store i1 %t77, ptr %l36, !tbaa !21
  br label %bb29
bb29:
  %t78 = load i1, ptr %l36, !tbaa !21
  br i1 %t78, label %bb30, label %bb31
bb30:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ebreakBefore(ptr %v0, ptr %t79)
  store i1 %t81, ptr %l42
  br label %bb32
bb31:
  store i1 false, ptr %l40, !tbaa !21
  br label %bb33
bb32:
  %t82 = load i1, ptr %l42, !tbaa !21
  %t83 = xor i1 %t82, true
  store i1 %t83, ptr %l40, !tbaa !21
  br label %bb33
bb33:
  %t85 = load i1, ptr %l40, !tbaa !21
  br i1 %t85, label %bb34, label %bb35
bb34:
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t88 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t86)
  store i32 %t88, ptr %l45
  br label %bb36
bb35:
  br label %bb57
bb36:
  %t89 = load ptr, ptr %l4, !tbaa !29
  store ptr %t89, ptr %l46, !tbaa !29
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t92 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ename(ptr %v0, ptr %t90)
  %t93 = extractvalue { i32, i32 } %t92, 1
  %t94 = extractvalue { i32, i32 } %t92, 0
  store i32 %t94, ptr %l50
  %t95 = icmp ne i32 %t94, 0
  br i1 %t95, label %bb38, label %ok.96, !prof !99
ok.96:
  store i32 %t93, ptr %l49
  br label %bb37
bb37:
  %t97 = load i32, ptr %l49, !tbaa !23
  store i32 %t97, ptr %l47, !tbaa !23
  br label %bb39
bb38:
  %t98 = load i32, ptr %l50, !tbaa !23
  %t99 = lshr i32 %t98, 16
  %t100 = and i32 %t98, 65535
  %t101 = icmp eq i32 %t99, 1
  %t102 = select i1 %t101, i32 1, i32 0
  %t103 = icmp eq i32 %t98, 0
  %t104 = shl i32 %t102, 16
  %t105 = or i32 %t104, %t100
  %t106 = select i1 %t103, i32 0, i32 %t105
  call void @__olang_scope_close(ptr %s1)
  %t108 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t106, 0
  store { i32, { i64, ptr } } %t108, ptr %rv
  br label %ret
bb39:
  %t109 = load ptr, ptr %l46, !tbaa !29
  %t110 = load i32, ptr %l47, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ePush_3ccompiler_2fsource_3aNameId_3e(ptr %s1, ptr %t109, i32 %t110)
  br label %bb40
bb40:
  br label %bb41
bb41:
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t114 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t111, i32 76)
  store i1 %t114, ptr %l54
  br label %bb42
bb42:
  %t115 = load i1, ptr %l54, !tbaa !21
  br i1 %t115, label %bb43, label %bb44
bb43:
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t118 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ebreakBefore(ptr %v0, ptr %t116)
  store i1 %t118, ptr %l57
  br label %bb45
bb44:
  store i1 false, ptr %l55, !tbaa !21
  br label %bb46
bb45:
  %t119 = load i1, ptr %l57, !tbaa !21
  %t120 = xor i1 %t119, true
  store i1 %t120, ptr %l55, !tbaa !21
  br label %bb46
bb46:
  %t122 = load i1, ptr %l55, !tbaa !21
  %t123 = xor i1 %t122, true
  br i1 %t123, label %bb47, label %bb48
bb47:
  br label %bb56
bb48:
  br label %bb49
bb49:
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t127 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t125)
  store i32 %t127, ptr %l61
  br label %bb50
bb50:
  %t128 = load ptr, ptr %l4, !tbaa !29
  store ptr %t128, ptr %l62, !tbaa !29
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t131 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ename(ptr %v0, ptr %t129)
  %t132 = extractvalue { i32, i32 } %t131, 1
  %t133 = extractvalue { i32, i32 } %t131, 0
  store i32 %t133, ptr %l66
  %t134 = icmp ne i32 %t133, 0
  br i1 %t134, label %bb52, label %ok.135, !prof !99
ok.135:
  store i32 %t132, ptr %l65
  br label %bb51
bb51:
  %t136 = load i32, ptr %l65, !tbaa !23
  store i32 %t136, ptr %l63, !tbaa !23
  br label %bb53
bb52:
  %t137 = load i32, ptr %l66, !tbaa !23
  %t138 = lshr i32 %t137, 16
  %t139 = and i32 %t137, 65535
  %t140 = icmp eq i32 %t138, 1
  %t141 = select i1 %t140, i32 1, i32 0
  %t142 = icmp eq i32 %t137, 0
  %t143 = shl i32 %t141, 16
  %t144 = or i32 %t143, %t139
  %t145 = select i1 %t142, i32 0, i32 %t144
  call void @__olang_scope_close(ptr %s1)
  %t147 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t145, 0
  store { i32, { i64, ptr } } %t147, ptr %rv
  br label %ret
bb53:
  %t148 = load ptr, ptr %l62, !tbaa !29
  %t149 = load i32, ptr %l63, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ePush_3ccompiler_2fsource_3aNameId_3e(ptr %s1, ptr %t148, i32 %t149)
  br label %bb54
bb54:
  br label %bb55
bb55:
  br label %bb41
bb56:
  br label %bb57
bb57:
  %t150 = load ptr, ptr %l1, !tbaa !29
  store ptr %t150, ptr %l68, !tbaa !29
  %t151 = load ptr, ptr %l0, !tbaa !29
  %t152 = load i32, ptr %l2, !tbaa !23
  %t155 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t151, i32 %t152)
  store %"compiler/source:Span" %t155, ptr %l71
  br label %bb58
bb58:
  %t156 = load i32, ptr %l3, !range !{i32 0, i32 116}
  store i32 %t156, ptr %l72
  %t157 = call ptr @__olang_scope_hold(ptr %v1)
  %t158 = ptrtoint ptr %t157 to i64
  store i64 %t158, ptr %l73, !tbaa !24
  %t159 = load i1, ptr @olang_2esole_2ecompiler_2fast_3aPromise_2e2
  br i1 %t159, label %bb59, label %bb60
bb59:
  %t161 = call ptr @__olang_region_make(ptr %v1)
  %t162 = ptrtoint ptr %t161 to i64
  store i64 %t162, ptr %l73, !tbaa !24
  br label %bb60
bb60:
  %t163 = load ptr, ptr %l4, !tbaa !29
  %t164 = load i64, ptr %l73
  %t165 = inttoptr i64 %t164 to ptr
  %t167 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eToArra_H4d02a0b2e27e8f31ffc99daa43750593(ptr %s1, ptr %t165, ptr %t163)
  store { i64, ptr } %t167, ptr %l76
  br label %bb61
bb61:
  %t168 = load %"compiler/source:Span", ptr %l71
  %t169 = load i32, ptr %l72, !range !{i32 0, i32 116}
  %t170 = load { i64, ptr }, ptr %l76, !tbaa !27
  %t171 = call %"compiler/ast:Promise" @compiler_2fast_3aPromise_2ector(ptr %v1, ptr %v1, %"compiler/source:Span" %t168, i32 %t169, { i64, ptr } %t170)
  store %"compiler/ast:Promise" %t171, ptr %l77
  br label %bb62
bb62:
  %t172 = load %"compiler/ast:Promise", ptr %l77
  %t173 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 32, i64 8)
  store %"compiler/ast:Promise" %t172, ptr %t173
  %t174 = load ptr, ptr %l68, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aPromise_26_3e_2ePush_3ccompiler_2fast_3aPromise_26_3e(ptr %v1, ptr %v1, ptr %t174, ptr %t173)
  br label %bb63
bb63:
  call void @__olang_scope_close(ptr %s1)
  br label %bb64
bb64:
  br label %bb2
bb65:
  %t176 = load ptr, ptr %l1, !tbaa !29
  %t178 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aPromise_26_3e_2eToArr_H644015b27d5daf4fb4fcf02905144e4c(ptr %v1, ptr %v1, ptr %t176)
  store { i64, ptr } %t178, ptr %l80
  br label %bb66
bb66:
  %t179 = load { i64, ptr }, ptr %l80, !tbaa !27
  %t180 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t179, 1
  store { i32, { i64, ptr } } %t180, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2erendering(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l7 = alloca i32
  %l8 = alloca i32
  %l11 = alloca i32
  %l12 = alloca i32
  %l15 = alloca i32
  %l18 = alloca i1
  %l21 = alloca i1
  %l25 = alloca i32
  %l27 = alloca i32
  %l28 = alloca ptr
  %l30 = alloca ptr
  %l31 = alloca i32
  %l35 = alloca %"compiler/source:Span"
  %l36 = alloca i32
  %l39 = alloca %"compiler/source:Span"
  %l46 = alloca ptr
  %l48 = alloca ptr
  %l49 = alloca i32
  %l53 = alloca %"compiler/source:Span"
  %rv = alloca { i32, ptr }
  %t85 = alloca { i64, [4 x i64] }, align 8
  %t97 = alloca { i64, [4 x i64] }, align 8
  %t137 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ehere(ptr %v0, ptr %t1)
  store i32 %t3, ptr %l7
  br label %bb1
bb1:
  %t4 = load i32, ptr %l7, !tbaa !23
  store i32 %t4, ptr %l1, !tbaa !23
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t8 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %t5, i32 107)
  %t9 = extractvalue { i32, i32 } %t8, 1
  %t10 = extractvalue { i32, i32 } %t8, 0
  store i32 %t10, ptr %l12
  %t11 = icmp ne i32 %t10, 0
  br i1 %t11, label %bb3, label %ok.12, !prof !99
ok.12:
  store i32 %t9, ptr %l11
  br label %bb2
bb2:
  %t13 = load i32, ptr %l11, !tbaa !23
  store i32 %t13, ptr %l8, !tbaa !23
  br label %bb4
bb3:
  %t14 = load i32, ptr %l12, !tbaa !23
  %t15 = lshr i32 %t14, 16
  %t16 = and i32 %t14, 65535
  %t17 = icmp eq i32 %t15, 1
  %t18 = select i1 %t17, i32 1, i32 0
  %t19 = icmp eq i32 %t14, 0
  %t20 = shl i32 %t18, 16
  %t21 = or i32 %t20, %t16
  %t22 = select i1 %t19, i32 0, i32 %t21
  %t24 = insertvalue { i32, ptr } zeroinitializer, i32 %t22, 0
  store { i32, ptr } %t24, ptr %rv
  br label %ret
bb4:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2epeek(ptr %v0, ptr %t25)
  store i32 %t27, ptr %l15
  br label %bb5
bb5:
  %t28 = load i32, ptr %l15, !range !{i32 0, i32 116}
  store i32 %t28, ptr %l2
  %t29 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t31 = trunc i64 69 to i32
  %t32 = icmp eq i32 %t29, %t31
  br i1 %t32, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l18, !tbaa !21
  br label %bb8
bb7:
  %t34 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t36 = trunc i64 105 to i32
  %t37 = icmp eq i32 %t34, %t36
  store i1 %t37, ptr %l18, !tbaa !21
  br label %bb8
bb8:
  %t39 = load i1, ptr %l18, !tbaa !21
  br i1 %t39, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l21, !tbaa !21
  br label %bb11
bb10:
  %t40 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t42 = trunc i64 107 to i32
  %t43 = icmp eq i32 %t40, %t42
  store i1 %t43, ptr %l21, !tbaa !21
  br label %bb11
bb11:
  %t45 = load i1, ptr %l21, !tbaa !21
  br i1 %t45, label %bb12, label %bb13
bb12:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t46)
  store i32 %t48, ptr %l25
  br label %bb14
bb13:
  br label %bb21
bb14:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ehere(ptr %v0, ptr %t49)
  store i32 %t51, ptr %l27
  br label %bb15
bb15:
  %t52 = load i32, ptr %l27, !tbaa !23
  store i32 %t52, ptr %l3, !tbaa !23
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2epostfix(ptr %v0, ptr %v1, ptr %t53)
  %t56 = extractvalue { i32, ptr } %t55, 1
  %t57 = extractvalue { i32, ptr } %t55, 0
  store i32 %t57, ptr %l31
  %t58 = icmp ne i32 %t57, 0
  br i1 %t58, label %bb17, label %ok.59, !prof !99
ok.59:
  store ptr %t56, ptr %l30
  br label %bb16
bb16:
  %t60 = load ptr, ptr %l30, !tbaa !29
  store ptr %t60, ptr %l28, !tbaa !29
  br label %bb18
bb17:
  %t61 = load i32, ptr %l31, !tbaa !23
  %t62 = lshr i32 %t61, 16
  %t63 = and i32 %t61, 65535
  %t64 = icmp eq i32 %t62, 1
  %t65 = select i1 %t64, i32 1, i32 0
  %t66 = icmp eq i32 %t61, 0
  %t67 = shl i32 %t65, 16
  %t68 = or i32 %t67, %t63
  %t69 = select i1 %t66, i32 0, i32 %t68
  %t71 = insertvalue { i32, ptr } zeroinitializer, i32 %t69, 0
  store { i32, ptr } %t71, ptr %rv
  br label %ret
bb18:
  %t72 = load ptr, ptr %l28, !tbaa !29
  store ptr %t72, ptr %l4, !tbaa !29
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t74 = load i32, ptr %l1, !tbaa !23
  %t77 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t73, i32 %t74)
  store %"compiler/source:Span" %t77, ptr %l35
  br label %bb19
bb19:
  store i32 107, ptr %l36
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t79 = load i32, ptr %l3, !tbaa !23
  %t82 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t78, i32 %t79)
  store %"compiler/source:Span" %t82, ptr %l39
  br label %bb20
bb20:
  %t83 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t84 = load ptr, ptr %l4, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t85
  %t86 = getelementptr { i64, [4 x i64] }, ptr %t85, i32 0, i32 0
  store i64 3, ptr %t86
  %t87 = load %"compiler/source:Span", ptr %l39
  %t88 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t87, 0
  %t90 = insertvalue { %"compiler/source:Span", i32, ptr } %t88, i32 %t83, 1
  %t92 = insertvalue { %"compiler/source:Span", i32, ptr } %t90, ptr %t84, 2
  %t93 = getelementptr { i64, [4 x i64] }, ptr %t85, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t92, ptr %t93
  %t94 = load { i64, [4 x i64] }, ptr %t85
  %t96 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 40, i64 8)
  store { i64, [4 x i64] } %t94, ptr %t96
  store { i64, [4 x i64] } zeroinitializer, ptr %t97
  %t98 = getelementptr { i64, [4 x i64] }, ptr %t97, i32 0, i32 0
  store i64 3, ptr %t98
  %t99 = load %"compiler/source:Span", ptr %l35
  %t100 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t99, 0
  %t101 = load i32, ptr %l36, !range !{i32 0, i32 116}
  %t102 = insertvalue { %"compiler/source:Span", i32, ptr } %t100, i32 %t101, 1
  %t104 = insertvalue { %"compiler/source:Span", i32, ptr } %t102, ptr %t96, 2
  %t105 = getelementptr { i64, [4 x i64] }, ptr %t97, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t104, ptr %t105
  %t106 = load { i64, [4 x i64] }, ptr %t97
  %t108 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 40, i64 8)
  store { i64, [4 x i64] } %t106, ptr %t108
  %t110 = insertvalue { i32, ptr } zeroinitializer, ptr %t108, 1
  store { i32, ptr } %t110, ptr %rv
  br label %ret
bb21:
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t113 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2epostfix(ptr %v0, ptr %v1, ptr %t111)
  %t114 = extractvalue { i32, ptr } %t113, 1
  %t115 = extractvalue { i32, ptr } %t113, 0
  store i32 %t115, ptr %l49
  %t116 = icmp ne i32 %t115, 0
  br i1 %t116, label %bb23, label %ok.117, !prof !99
ok.117:
  store ptr %t114, ptr %l48
  br label %bb22
bb22:
  %t118 = load ptr, ptr %l48, !tbaa !29
  store ptr %t118, ptr %l46, !tbaa !29
  br label %bb24
bb23:
  %t119 = load i32, ptr %l49, !tbaa !23
  %t120 = lshr i32 %t119, 16
  %t121 = and i32 %t119, 65535
  %t122 = icmp eq i32 %t120, 1
  %t123 = select i1 %t122, i32 1, i32 0
  %t124 = icmp eq i32 %t119, 0
  %t125 = shl i32 %t123, 16
  %t126 = or i32 %t125, %t121
  %t127 = select i1 %t124, i32 0, i32 %t126
  %t129 = insertvalue { i32, ptr } zeroinitializer, i32 %t127, 0
  store { i32, ptr } %t129, ptr %rv
  br label %ret
bb24:
  %t130 = load ptr, ptr %l46, !tbaa !29
  store ptr %t130, ptr %l5, !tbaa !29
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t132 = load i32, ptr %l1, !tbaa !23
  %t135 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t131, i32 %t132)
  store %"compiler/source:Span" %t135, ptr %l53
  br label %bb25
bb25:
  %t136 = load ptr, ptr %l5, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t137
  %t138 = getelementptr { i64, [4 x i64] }, ptr %t137, i32 0, i32 0
  store i64 3, ptr %t138
  %t139 = load %"compiler/source:Span", ptr %l53
  %t140 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t139, 0
  %t142 = insertvalue { %"compiler/source:Span", i32, ptr } %t140, i32 107, 1
  %t144 = insertvalue { %"compiler/source:Span", i32, ptr } %t142, ptr %t136, 2
  %t145 = getelementptr { i64, [4 x i64] }, ptr %t137, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t144, ptr %t145
  %t146 = load { i64, [4 x i64] }, ptr %t137
  %t148 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 40, i64 8)
  store { i64, [4 x i64] } %t146, ptr %t148
  %t150 = insertvalue { i32, ptr } zeroinitializer, ptr %t148, 1
  store { i32, ptr } %t150, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2esimpleStmt(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i32
  %l13 = alloca i32
  %l15 = alloca i1
  %l17 = alloca i32
  %l18 = alloca ptr
  %l20 = alloca ptr
  %l21 = alloca i32
  %l25 = alloca %"compiler/source:Span"
  %l33 = alloca %"compiler/source:Span"
  %rv = alloca { i32, ptr }
  %t64 = alloca { i64, [4 x i64] }, align 8
  %t86 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ehere(ptr %v0, ptr %t1)
  store i32 %t3, ptr %l6
  br label %bb1
bb1:
  %t4 = load i32, ptr %l6, !tbaa !23
  store i32 %t4, ptr %l1, !tbaa !23
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexpr(ptr %v0, ptr %v1, ptr %t5)
  %t8 = extractvalue { i32, ptr } %t7, 1
  %t9 = extractvalue { i32, ptr } %t7, 0
  store i32 %t9, ptr %l10
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb3, label %ok.11, !prof !99
ok.11:
  store ptr %t8, ptr %l9
  br label %bb2
bb2:
  %t12 = load ptr, ptr %l9, !tbaa !29
  store ptr %t12, ptr %l7, !tbaa !29
  br label %bb4
bb3:
  %t13 = load i32, ptr %l10, !tbaa !23
  %t14 = lshr i32 %t13, 16
  %t15 = and i32 %t13, 65535
  %t16 = icmp eq i32 %t14, 1
  %t17 = select i1 %t16, i32 1, i32 0
  %t18 = icmp eq i32 %t13, 0
  %t19 = shl i32 %t17, 16
  %t20 = or i32 %t19, %t15
  %t21 = select i1 %t18, i32 0, i32 %t20
  %t23 = insertvalue { i32, ptr } zeroinitializer, i32 %t21, 0
  store { i32, ptr } %t23, ptr %rv
  br label %ret
bb4:
  %t24 = load ptr, ptr %l7, !tbaa !29
  store ptr %t24, ptr %l2, !tbaa !29
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2epeek(ptr %v0, ptr %t25)
  store i32 %t27, ptr %l13
  br label %bb5
bb5:
  %t28 = load i32, ptr %l13, !range !{i32 0, i32 116}
  store i32 %t28, ptr %l3
  %t29 = load i32, ptr %l3, !range !{i32 0, i32 116}
  %t31 = call i1 @compiler_2fparse_2eisAssignOp(i32 %t29)
  store i1 %t31, ptr %l15
  br label %bb6
bb6:
  %t32 = load i1, ptr %l15, !tbaa !21
  br i1 %t32, label %bb7, label %bb8
bb7:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t33)
  store i32 %t35, ptr %l17
  br label %bb9
bb8:
  br label %bb14
bb9:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexpr(ptr %v0, ptr %v1, ptr %t36)
  %t39 = extractvalue { i32, ptr } %t38, 1
  %t40 = extractvalue { i32, ptr } %t38, 0
  store i32 %t40, ptr %l21
  %t41 = icmp ne i32 %t40, 0
  br i1 %t41, label %bb11, label %ok.42, !prof !99
ok.42:
  store ptr %t39, ptr %l20
  br label %bb10
bb10:
  %t43 = load ptr, ptr %l20, !tbaa !29
  store ptr %t43, ptr %l18, !tbaa !29
  br label %bb12
bb11:
  %t44 = load i32, ptr %l21, !tbaa !23
  %t45 = lshr i32 %t44, 16
  %t46 = and i32 %t44, 65535
  %t47 = icmp eq i32 %t45, 1
  %t48 = select i1 %t47, i32 1, i32 0
  %t49 = icmp eq i32 %t44, 0
  %t50 = shl i32 %t48, 16
  %t51 = or i32 %t50, %t46
  %t52 = select i1 %t49, i32 0, i32 %t51
  %t54 = insertvalue { i32, ptr } zeroinitializer, i32 %t52, 0
  store { i32, ptr } %t54, ptr %rv
  br label %ret
bb12:
  %t55 = load ptr, ptr %l18, !tbaa !29
  store ptr %t55, ptr %l4, !tbaa !29
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t57 = load i32, ptr %l1, !tbaa !23
  %t60 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t56, i32 %t57)
  store %"compiler/source:Span" %t60, ptr %l25
  br label %bb13
bb13:
  %t61 = load i32, ptr %l3, !range !{i32 0, i32 116}
  %t62 = load ptr, ptr %l2, !tbaa !29
  %t63 = load ptr, ptr %l4, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t64
  %t65 = getelementptr { i64, [4 x i64] }, ptr %t64, i32 0, i32 0
  store i64 3, ptr %t65
  %t66 = load %"compiler/source:Span", ptr %l25
  %t67 = insertvalue { %"compiler/source:Span", i32, ptr, ptr } undef, %"compiler/source:Span" %t66, 0
  %t69 = insertvalue { %"compiler/source:Span", i32, ptr, ptr } %t67, i32 %t61, 1
  %t71 = insertvalue { %"compiler/source:Span", i32, ptr, ptr } %t69, ptr %t62, 2
  %t73 = insertvalue { %"compiler/source:Span", i32, ptr, ptr } %t71, ptr %t63, 3
  %t74 = getelementptr { i64, [4 x i64] }, ptr %t64, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr, ptr } %t73, ptr %t74
  %t75 = load { i64, [4 x i64] }, ptr %t64
  %t77 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 40, i64 8)
  store { i64, [4 x i64] } %t75, ptr %t77
  %t79 = insertvalue { i32, ptr } zeroinitializer, ptr %t77, 1
  store { i32, ptr } %t79, ptr %rv
  br label %ret
bb14:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t81 = load i32, ptr %l1, !tbaa !23
  %t84 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t80, i32 %t81)
  store %"compiler/source:Span" %t84, ptr %l33
  br label %bb15
bb15:
  %t85 = load ptr, ptr %l2, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t86
  %t87 = getelementptr { i64, [4 x i64] }, ptr %t86, i32 0, i32 0
  store i64 0, ptr %t87
  %t88 = load %"compiler/source:Span", ptr %l33
  %t89 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t88, 0
  %t91 = insertvalue { %"compiler/source:Span", ptr } %t89, ptr %t85, 1
  %t92 = getelementptr { i64, [4 x i64] }, ptr %t86, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t91, ptr %t92
  %t93 = load { i64, [4 x i64] }, ptr %t86
  %t95 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 40, i64 8)
  store { i64, [4 x i64] } %t93, ptr %t95
  %t97 = insertvalue { i32, ptr } zeroinitializer, ptr %t95, 1
  store { i32, ptr } %t97, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local void @compiler_2fparse_2ecompiler_2fparse_3aParser_2espreadRules(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i1 %a2, i1 %a3, i1 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i1
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l20 = alloca i64
  %l23 = alloca i64
  %l41 = alloca { i64, ptr }
  %l47 = alloca i1
  %l48 = alloca { i64, ptr }
  %l53 = alloca i1
  %l55 = alloca i1
  %l61 = alloca i1
  %l68 = alloca i1
  %l69 = alloca { i64, ptr }
  %l74 = alloca ptr
  %l75 = alloca { i64, ptr }
  %l78 = alloca i32
  %l79 = alloca { i64, ptr }
  %l82 = alloca i32
  %l83 = alloca %"compiler/diagmsg:Msg"
  %l86 = alloca i1
  %l88 = alloca i1
  %l91 = alloca i1
  %l94 = alloca ptr
  %l96 = alloca %"compiler/source:Span"
  %l97 = alloca i32
  %l99 = alloca %"compiler/source:Span"
  %l100 = alloca i32
  %l102 = alloca { i64, ptr }
  %l104 = alloca { i64, ptr }
  %l105 = alloca %"compiler/diagmsg:Msg"
  %l108 = alloca ptr
  %l109 = alloca { i64, ptr }
  %l112 = alloca i32
  %l113 = alloca { i64, ptr }
  %l116 = alloca i32
  %l117 = alloca %"compiler/diagmsg:Msg"
  %l118 = alloca { i64, ptr }
  %l124 = alloca ptr
  %l125 = alloca { i64, ptr }
  %l132 = alloca %"compiler/source:Span"
  %l133 = alloca i32
  %l134 = alloca { i64, ptr }
  %l141 = alloca %"compiler/source:Span"
  %l142 = alloca i32
  %l143 = alloca %"compiler/diagmsg:Msg"
  %s6 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store i1 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store i64 -1, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  store i64 %t3, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t5 = load i64, ptr %l7, !tbaa !24
  %t6 = load i64, ptr %l6, !tbaa !24
  %t9 = icmp sgt i64 %t5, %t6
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = load i64, ptr %l8, !tbaa !24
  %t13 = icmp sgt i64 %t11, 0
  br i1 %t13, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l20, !tbaa !24
  br label %bb6
bb3:
  %t15 = load i64, ptr %l7, !tbaa !24
  %t16 = load i64, ptr %l6, !tbaa !24
  %t19 = sub i64 %t15, %t16
  %t20 = load i64, ptr %l8, !tbaa !24
  %t23 = add i64 %t19, %t20
  %t25 = sub i64 %t23, 1
  %t26 = load i64, ptr %l8, !tbaa !24
  %t29 = sdiv i64 %t25, %t26
  store i64 %t29, ptr %l23, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l23, !tbaa !24
  br label %bb5
bb5:
  %t31 = load i64, ptr %l23, !tbaa !24
  store i64 %t31, ptr %l20, !tbaa !24
  br label %bb6
bb6:
  %t32 = load i64, ptr %l20, !tbaa !24
  store i64 %t32, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb7
bb7:
  %t33 = load i64, ptr %l10, !tbaa !24
  %t34 = load i64, ptr %l9, !tbaa !24
  %t37 = icmp slt i64 %t33, %t34
  %t39 = xor i1 %t37, true
  br i1 %t39, label %bb8, label %bb9
bb8:
  br label %bb76
bb9:
  br label %bb10
bb10:
  %t41 = load i64, ptr %l6, !tbaa !24
  %t42 = load i64, ptr %l10, !tbaa !24
  %t43 = load i64, ptr %l8, !tbaa !24
  %t46 = mul i64 %t42, %t43
  %t49 = add i64 %t41, %t46
  store i64 %t49, ptr %l11, !tbaa !24
  %t51 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t51, ptr %l41, !tbaa !27
  %t52 = load i64, ptr %l11, !tbaa !24
  %t54 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !27
  %t56 = getelementptr ptr, ptr %t55, i64 %t52
  %t57 = load ptr, ptr %t56, !tbaa !39
  %t59 = getelementptr %"compiler/ast:Param", ptr %t57, i32 0, i32 2
  %t60 = load ptr, ptr %t59, !tbaa !29
  store ptr %t60, ptr %l12, !tbaa !29
  %t62 = load i64, ptr %l5, !tbaa !24
  %t64 = icmp sge i64 %t62, 0
  br i1 %t64, label %bb11, label %bb12
bb11:
  %t66 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t66, ptr %l48, !tbaa !27
  %t67 = load i64, ptr %l11, !tbaa !24
  %t69 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !27
  %t71 = getelementptr ptr, ptr %t70, i64 %t67
  %t72 = load ptr, ptr %t71, !tbaa !39
  %t74 = getelementptr %"compiler/ast:Param", ptr %t72, i32 0, i32 3
  %t75 = load ptr, ptr %t74, !tbaa !29
  %t77 = icmp eq ptr %t75, null
  store i1 %t77, ptr %l47, !tbaa !21
  br label %bb13
bb12:
  store i1 false, ptr %l47, !tbaa !21
  br label %bb13
bb13:
  %t79 = load i1, ptr %l47, !tbaa !21
  br i1 %t79, label %bb14, label %bb15
bb14:
  store i1 %a4, ptr %l53, !tbaa !21
  br label %bb16
bb15:
  store i1 false, ptr %l53, !tbaa !21
  br label %bb16
bb16:
  %t82 = load i1, ptr %l53, !tbaa !21
  br i1 %t82, label %bb17, label %bb18
bb17:
  %t83 = load i64, ptr %l11, !tbaa !24
  %t84 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t86 = extractvalue { i64, ptr } %t84, 0
  %t88 = sub i64 %t86, 1
  %t91 = icmp eq i64 %t83, %t88
  store i1 %t91, ptr %l55, !tbaa !21
  br label %bb19
bb18:
  store i1 false, ptr %l55, !tbaa !21
  br label %bb19
bb19:
  %t93 = load i1, ptr %l55, !tbaa !21
  br i1 %t93, label %bb20, label %bb21
bb20:
  %t94 = load i64, ptr %l11, !tbaa !24
  %t95 = load i64, ptr %l5, !tbaa !24
  %t97 = add i64 %t95, 1
  %t100 = icmp eq i64 %t94, %t97
  store i1 %t100, ptr %l61, !tbaa !21
  br label %bb22
bb21:
  store i1 false, ptr %l61, !tbaa !21
  br label %bb22
bb22:
  %t102 = load i1, ptr %l61, !tbaa !21
  br i1 %t102, label %bb23, label %bb24
bb23:
  br label %bb75
bb24:
  br label %bb25
bb25:
  %t103 = load i64, ptr %l5, !tbaa !24
  %t105 = icmp sge i64 %t103, 0
  br i1 %t105, label %bb26, label %bb27
bb26:
  %t107 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t107, ptr %l69, !tbaa !27
  %t108 = load i64, ptr %l11, !tbaa !24
  %t110 = getelementptr { i64, ptr }, ptr %l69, i32 0, i32 1
  %t111 = load ptr, ptr %t110, !tbaa !27
  %t112 = getelementptr ptr, ptr %t111, i64 %t108
  %t113 = load ptr, ptr %t112, !tbaa !39
  %t115 = getelementptr %"compiler/ast:Param", ptr %t113, i32 0, i32 3
  %t116 = load ptr, ptr %t115, !tbaa !29
  %t118 = icmp eq ptr %t116, null
  store i1 %t118, ptr %l68, !tbaa !21
  br label %bb28
bb27:
  store i1 false, ptr %l68, !tbaa !21
  br label %bb28
bb28:
  %t120 = load i1, ptr %l68, !tbaa !21
  br i1 %t120, label %bb29, label %bb30
bb29:
  %t121 = load ptr, ptr %l0, !tbaa !29
  store ptr %t121, ptr %l74, !tbaa !29
  %t122 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t122, ptr %l75, !tbaa !27
  %t123 = load i64, ptr %l11, !tbaa !24
  %t125 = getelementptr { i64, ptr }, ptr %l75, i32 0, i32 1
  %t126 = load ptr, ptr %t125, !tbaa !27
  %t127 = getelementptr ptr, ptr %t126, i64 %t123
  %t128 = load ptr, ptr %t127, !tbaa !39
  %t130 = getelementptr %"compiler/ast:Param", ptr %t128, i32 0, i32 0
  %t131 = getelementptr %"compiler/source:Span", ptr %t130, i32 0, i32 0
  %t132 = load i32, ptr %t131, !tbaa !23
  store i32 %t132, ptr %l78, !tbaa !23
  %t133 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t133, ptr %l79, !tbaa !27
  %t134 = load i64, ptr %l11, !tbaa !24
  %t136 = getelementptr { i64, ptr }, ptr %l79, i32 0, i32 1
  %t137 = load ptr, ptr %t136, !tbaa !27
  %t138 = getelementptr ptr, ptr %t137, i64 %t134
  %t139 = load ptr, ptr %t138, !tbaa !39
  %t141 = getelementptr %"compiler/ast:Param", ptr %t139, i32 0, i32 0
  %t142 = getelementptr %"compiler/source:Span", ptr %t141, i32 0, i32 1
  %t143 = load i32, ptr %t142, !tbaa !23
  store i32 %t143, ptr %l82, !tbaa !23
  %t144 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eVariadicNotLast(ptr %v0)
  store %"compiler/diagmsg:Msg" %t144, ptr %l83
  br label %bb31
bb30:
  br label %bb33
bb31:
  %t145 = load ptr, ptr %l74, !tbaa !29
  %t146 = load i32, ptr %l78, !tbaa !23
  %t147 = load i32, ptr %l82, !tbaa !23
  %t148 = load %"compiler/diagmsg:Msg", ptr %l83
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereport(ptr %v0, ptr %v0, ptr %t145, i32 %t146, i32 %t147, %"compiler/diagmsg:Msg" %t148)
  br label %bb32
bb32:
  br label %ret
bb33:
  %t149 = load ptr, ptr %l12, !tbaa !29
  %t151 = icmp eq ptr %t149, null
  br i1 %t151, label %bb34, label %bb35
bb34:
  store i1 true, ptr %l86, !tbaa !21
  br label %bb37
bb35:
  %t153 = load ptr, ptr %l12, !tbaa !29
  %t155 = call i1 @compiler_2fparse_2eisSpreadType(ptr %v1, ptr %t153)
  store i1 %t155, ptr %l88
  br label %bb36
bb36:
  %t156 = load i1, ptr %l88, !tbaa !21
  %t157 = xor i1 %t156, true
  store i1 %t157, ptr %l86, !tbaa !21
  br label %bb37
bb37:
  %t159 = load i1, ptr %l86, !tbaa !21
  br i1 %t159, label %bb38, label %bb39
bb38:
  br label %bb75
bb39:
  br label %bb40
bb40:
  %t160 = load i1, ptr %l2, !tbaa !21
  br i1 %t160, label %bb41, label %bb42
bb41:
  store i1 true, ptr %l91, !tbaa !21
  br label %bb43
bb42:
  %t164 = xor i1 %a3, true
  store i1 %t164, ptr %l91, !tbaa !21
  br label %bb43
bb43:
  %t166 = load i1, ptr %l91, !tbaa !21
  br i1 %t166, label %bb44, label %bb45
bb44:
  store %olang.scope zeroinitializer, ptr %s6
  %t167 = load ptr, ptr %l0, !tbaa !29
  store ptr %t167, ptr %l94, !tbaa !29
  %t168 = load ptr, ptr %l12, !tbaa !29
  %t170 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t168)
  store %"compiler/source:Span" %t170, ptr %l96
  br label %bb46
bb45:
  br label %bb56
bb46:
  %t171 = getelementptr %"compiler/source:Span", ptr %l96, i32 0, i32 0
  %t172 = load i32, ptr %t171, !tbaa !23
  store i32 %t172, ptr %l97, !tbaa !23
  %t173 = load ptr, ptr %l12, !tbaa !29
  %t175 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t173)
  store %"compiler/source:Span" %t175, ptr %l99
  br label %bb47
bb47:
  %t176 = getelementptr %"compiler/source:Span", ptr %l99, i32 0, i32 1
  %t177 = load i32, ptr %t176, !tbaa !23
  store i32 %t177, ptr %l100, !tbaa !23
  %t178 = load i1, ptr %l2, !tbaa !21
  br i1 %t178, label %bb48, label %bb49
bb48:
  store { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d16, i32 0, i32 1) }, ptr %l102, !tbaa !27
  br label %bb50
bb49:
  store { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d17, i32 0, i32 1) }, ptr %l102, !tbaa !27
  br label %bb50
bb50:
  %t180 = load i1, ptr %l2, !tbaa !21
  br i1 %t180, label %bb51, label %bb52
bb51:
  store { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d18, i32 0, i32 1) }, ptr %l104, !tbaa !27
  br label %bb53
bb52:
  store { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d19, i32 0, i32 1) }, ptr %l104, !tbaa !27
  br label %bb53
bb53:
  %t182 = load { i64, ptr }, ptr %l102, !tbaa !27
  %t183 = load { i64, ptr }, ptr %l104, !tbaa !27
  %t184 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eVariadicHere(ptr %s6, ptr %s6, ptr %v0, { i64, ptr } %t182, { i64, ptr } %t183)
  store %"compiler/diagmsg:Msg" %t184, ptr %l105
  br label %bb54
bb54:
  %t185 = load ptr, ptr %l94, !tbaa !29
  %t186 = load i32, ptr %l97, !tbaa !23
  %t187 = load i32, ptr %l100, !tbaa !23
  %t188 = load %"compiler/diagmsg:Msg", ptr %l105
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereport(ptr %v0, ptr %v0, ptr %t185, i32 %t186, i32 %t187, %"compiler/diagmsg:Msg" %t188)
  br label %bb55
bb55:
  call void @__olang_scope_close(ptr %s6)
  br label %ret
bb56:
  %t189 = load i64, ptr %l5, !tbaa !24
  %t191 = icmp sge i64 %t189, 0
  br i1 %t191, label %bb57, label %bb58
bb57:
  %t193 = load ptr, ptr %l0, !tbaa !29
  store ptr %t193, ptr %l108, !tbaa !29
  %t194 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t194, ptr %l109, !tbaa !27
  %t195 = load i64, ptr %l11, !tbaa !24
  %t197 = getelementptr { i64, ptr }, ptr %l109, i32 0, i32 1
  %t198 = load ptr, ptr %t197, !tbaa !27
  %t199 = getelementptr ptr, ptr %t198, i64 %t195
  %t200 = load ptr, ptr %t199, !tbaa !39
  %t202 = getelementptr %"compiler/ast:Param", ptr %t200, i32 0, i32 0
  %t203 = getelementptr %"compiler/source:Span", ptr %t202, i32 0, i32 0
  %t204 = load i32, ptr %t203, !tbaa !23
  store i32 %t204, ptr %l112, !tbaa !23
  %t205 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t205, ptr %l113, !tbaa !27
  %t206 = load i64, ptr %l11, !tbaa !24
  %t208 = getelementptr { i64, ptr }, ptr %l113, i32 0, i32 1
  %t209 = load ptr, ptr %t208, !tbaa !27
  %t210 = getelementptr ptr, ptr %t209, i64 %t206
  %t211 = load ptr, ptr %t210, !tbaa !39
  %t213 = getelementptr %"compiler/ast:Param", ptr %t211, i32 0, i32 0
  %t214 = getelementptr %"compiler/source:Span", ptr %t213, i32 0, i32 1
  %t215 = load i32, ptr %t214, !tbaa !23
  store i32 %t215, ptr %l116, !tbaa !23
  %t216 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eVariadicNotLast(ptr %v0)
  store %"compiler/diagmsg:Msg" %t216, ptr %l117
  br label %bb59
bb58:
  br label %bb61
bb59:
  %t217 = load ptr, ptr %l108, !tbaa !29
  %t218 = load i32, ptr %l112, !tbaa !23
  %t219 = load i32, ptr %l116, !tbaa !23
  %t220 = load %"compiler/diagmsg:Msg", ptr %l117
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereport(ptr %v0, ptr %v0, ptr %t217, i32 %t218, i32 %t219, %"compiler/diagmsg:Msg" %t220)
  br label %bb60
bb60:
  br label %ret
bb61:
  %t221 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t221, ptr %l118, !tbaa !27
  %t222 = load i64, ptr %l11, !tbaa !24
  %t224 = getelementptr { i64, ptr }, ptr %l118, i32 0, i32 1
  %t225 = load ptr, ptr %t224, !tbaa !27
  %t226 = getelementptr ptr, ptr %t225, i64 %t222
  %t227 = load ptr, ptr %t226, !tbaa !39
  %t229 = getelementptr %"compiler/ast:Param", ptr %t227, i32 0, i32 3
  %t230 = load ptr, ptr %t229, !tbaa !29
  %t232 = icmp eq ptr %t230, null
  %t234 = xor i1 %t232, true
  br i1 %t234, label %bb62, label %bb63
bb62:
  %t236 = load ptr, ptr %l0, !tbaa !29
  store ptr %t236, ptr %l124, !tbaa !29
  %t237 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t237, ptr %l125, !tbaa !27
  %t238 = load i64, ptr %l11, !tbaa !24
  %t240 = getelementptr { i64, ptr }, ptr %l125, i32 0, i32 1
  %t241 = load ptr, ptr %t240, !tbaa !27
  %t242 = getelementptr ptr, ptr %t241, i64 %t238
  %t243 = load ptr, ptr %t242, !tbaa !39
  %t245 = getelementptr %"compiler/ast:Param", ptr %t243, i32 0, i32 3
  %t246 = load ptr, ptr %t245, !tbaa !29
  store ptr %t246, ptr %l13, !tbaa !29
  %t248 = load ptr, ptr %l13, !tbaa !29
  %t250 = icmp eq ptr %t248, null
  br i1 %t250, label %bb64, label %bb65
bb63:
  br label %bb74
bb64:
  call void @__olang_check_failed(ptr @olang_loc_b4d86fcc9a57c7f6_c634a892523c9252)
  unreachable
bb65:
  br label %bb66
bb66:
  %t252 = load ptr, ptr %l13, !tbaa !29
  %t254 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t252)
  store %"compiler/source:Span" %t254, ptr %l132
  br label %bb67
bb67:
  %t255 = getelementptr %"compiler/source:Span", ptr %l132, i32 0, i32 0
  %t256 = load i32, ptr %t255, !tbaa !23
  store i32 %t256, ptr %l133, !tbaa !23
  %t257 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t257, ptr %l134, !tbaa !27
  %t258 = load i64, ptr %l11, !tbaa !24
  %t260 = getelementptr { i64, ptr }, ptr %l134, i32 0, i32 1
  %t261 = load ptr, ptr %t260, !tbaa !27
  %t262 = getelementptr ptr, ptr %t261, i64 %t258
  %t263 = load ptr, ptr %t262, !tbaa !39
  %t265 = getelementptr %"compiler/ast:Param", ptr %t263, i32 0, i32 3
  %t266 = load ptr, ptr %t265, !tbaa !29
  store ptr %t266, ptr %l14, !tbaa !29
  %t268 = load ptr, ptr %l14, !tbaa !29
  %t270 = icmp eq ptr %t268, null
  br i1 %t270, label %bb68, label %bb69
bb68:
  call void @__olang_check_failed(ptr @olang_loc_b4d86fcc9a57c7f6_c634a892523c9252)
  unreachable
bb69:
  br label %bb70
bb70:
  %t272 = load ptr, ptr %l14, !tbaa !29
  %t274 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t272)
  store %"compiler/source:Span" %t274, ptr %l141
  br label %bb71
bb71:
  %t275 = getelementptr %"compiler/source:Span", ptr %l141, i32 0, i32 1
  %t276 = load i32, ptr %t275, !tbaa !23
  store i32 %t276, ptr %l142, !tbaa !23
  %t277 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eVariadicDefault(ptr %v0)
  store %"compiler/diagmsg:Msg" %t277, ptr %l143
  br label %bb72
bb72:
  %t278 = load ptr, ptr %l124, !tbaa !29
  %t279 = load i32, ptr %l133, !tbaa !23
  %t280 = load i32, ptr %l142, !tbaa !23
  %t281 = load %"compiler/diagmsg:Msg", ptr %l143
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereport(ptr %v0, ptr %v0, ptr %t278, i32 %t279, i32 %t280, %"compiler/diagmsg:Msg" %t281)
  br label %bb73
bb73:
  br label %bb74
bb74:
  %t282 = load i64, ptr %l11, !tbaa !24
  store i64 %t282, ptr %l5, !tbaa !24
  br label %bb75
bb75:
  %t284 = load i64, ptr %l10, !tbaa !24
  %t287 = add i64 %t284, 1
  store i64 %t287, ptr %l10, !tbaa !24
  br label %bb7
bb76:
  br label %ret
ret:
  ret void
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2estmt(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca %"compiler/source:Span"
  %l7 = alloca ptr
  %l8 = alloca %"compiler/source:Span"
  %l9 = alloca { i64, ptr }
  %l10 = alloca %"compiler/source:Span"
  %l11 = alloca ptr
  %l12 = alloca %"compiler/source:Span"
  %l13 = alloca ptr
  %l14 = alloca %"compiler/source:Span"
  %l15 = alloca i32
  %l16 = alloca ptr
  %l17 = alloca %"compiler/source:Span"
  %l18 = alloca ptr
  %l19 = alloca ptr
  %l20 = alloca %"compiler/source:Span"
  %l21 = alloca ptr
  %l22 = alloca { i64, ptr }
  %l23 = alloca %"compiler/source:Span"
  %l24 = alloca i64
  %l25 = alloca { i64, ptr }
  %l26 = alloca ptr
  %l27 = alloca %"compiler/source:Span"
  %l28 = alloca ptr
  %l29 = alloca %"compiler/source:Span"
  %l30 = alloca ptr
  %l31 = alloca i1
  %l32 = alloca { i64, ptr }
  %l33 = alloca %"compiler/source:Span"
  %l34 = alloca { i64, ptr }
  %l35 = alloca %"compiler/token:Token"
  %l36 = alloca { i64, ptr }
  %l37 = alloca %"compiler/source:Span"
  %l39 = alloca i32
  %l42 = alloca i1
  %l44 = alloca i1
  %l45 = alloca ptr
  %l47 = alloca ptr
  %l48 = alloca i32
  %l52 = alloca i32
  %l55 = alloca ptr
  %l57 = alloca ptr
  %l58 = alloca i32
  %l63 = alloca ptr
  %l65 = alloca ptr
  %l66 = alloca i32
  %l71 = alloca i32
  %l75 = alloca i32
  %l76 = alloca ptr
  %l79 = alloca ptr
  %l80 = alloca i32
  %l85 = alloca i32
  %l86 = alloca { i64, ptr }
  %l88 = alloca { i64, ptr }
  %l89 = alloca i32
  %l91 = alloca i32
  %l94 = alloca i32
  %l95 = alloca i32
  %l97 = alloca ptr
  %l99 = alloca ptr
  %l100 = alloca i32
  %l104 = alloca %"compiler/source:Span"
  %l106 = alloca i32
  %l115 = alloca ptr
  %l117 = alloca ptr
  %l118 = alloca i32
  %l122 = alloca %"compiler/source:Span"
  %l125 = alloca i1
  %l127 = alloca i32
  %l135 = alloca i32
  %l140 = alloca i1
  %l142 = alloca i1
  %l145 = alloca ptr
  %l147 = alloca ptr
  %l148 = alloca i32
  %l150 = alloca { i64, ptr }
  %l152 = alloca i1
  %l154 = alloca ptr
  %l156 = alloca i32
  %l157 = alloca { i64, ptr }
  %l159 = alloca { i64, ptr }
  %l160 = alloca i32
  %l164 = alloca %"compiler/source:Span"
  %l166 = alloca i32
  %l175 = alloca i32
  %l176 = alloca ptr
  %l178 = alloca ptr
  %l179 = alloca i32
  %l183 = alloca %"compiler/source:Span"
  %l185 = alloca i32
  %l194 = alloca i32
  %l195 = alloca ptr
  %l197 = alloca ptr
  %l198 = alloca i32
  %l202 = alloca %"compiler/source:Span"
  %l204 = alloca i32
  %l217 = alloca i32
  %l219 = alloca i32
  %l222 = alloca i1
  %l224 = alloca i1
  %l226 = alloca ptr
  %l228 = alloca ptr
  %l229 = alloca i32
  %l234 = alloca %"compiler/source:Span"
  %l236 = alloca i32
  %l246 = alloca i32
  %l247 = alloca ptr
  %l249 = alloca ptr
  %l250 = alloca i32
  %l254 = alloca i1
  %l255 = alloca ptr
  %l257 = alloca ptr
  %l258 = alloca i32
  %l263 = alloca %"compiler/source:Span"
  %l265 = alloca i32
  %l275 = alloca i32
  %l276 = alloca ptr
  %l278 = alloca ptr
  %l279 = alloca i32
  %l283 = alloca i1
  %l284 = alloca { i64, ptr }
  %l286 = alloca { i64, ptr }
  %l287 = alloca i32
  %l292 = alloca %"compiler/source:Span"
  %l294 = alloca i32
  %l305 = alloca i32
  %l308 = alloca i64
  %l310 = alloca ptr
  %l311 = alloca ptr
  %l313 = alloca ptr
  %l314 = alloca i32
  %l318 = alloca i1
  %l322 = alloca i1
  %l326 = alloca { i64, ptr }
  %l330 = alloca ptr
  %l332 = alloca i32
  %l333 = alloca ptr
  %l335 = alloca ptr
  %l336 = alloca i32
  %l340 = alloca %"compiler/source:Span"
  %l342 = alloca i32
  %l351 = alloca i64
  %l358 = alloca ptr
  %l360 = alloca { i64, ptr }
  %l362 = alloca i32
  %l367 = alloca ptr
  %l373 = alloca %"compiler/source:Span"
  %l375 = alloca i32
  %l377 = alloca %"compiler/source:Span"
  %l386 = alloca ptr
  %l388 = alloca ptr
  %l389 = alloca i32
  %l393 = alloca %"compiler/source:Span"
  %l403 = alloca i1
  %l405 = alloca i32
  %l408 = alloca i1
  %l409 = alloca { i64, ptr }
  %l411 = alloca { i64, ptr }
  %l412 = alloca i32
  %l416 = alloca %"compiler/source:Span"
  %l419 = alloca i1
  %l421 = alloca i32
  %l432 = alloca i1
  %l433 = alloca { i64, ptr }
  %l435 = alloca { i64, ptr }
  %l436 = alloca i32
  %l440 = alloca %"compiler/source:Span"
  %l441 = alloca { i64, ptr }
  %l447 = alloca %"compiler/token:Token"
  %l448 = alloca ptr
  %l450 = alloca i32
  %l451 = alloca i32
  %l453 = alloca { i64, ptr }
  %l454 = alloca %"compiler/diagmsg:Msg"
  %l458 = alloca { i64, ptr }
  %l460 = alloca { i64, ptr }
  %l461 = alloca i32
  %l465 = alloca %"compiler/source:Span"
  %l468 = alloca i1
  %l470 = alloca i32
  %l477 = alloca ptr
  %l479 = alloca ptr
  %l480 = alloca i32
  %l484 = alloca ptr
  %l486 = alloca ptr
  %l487 = alloca i32
  %l489 = alloca ptr
  %l491 = alloca ptr
  %l492 = alloca i32
  %s25 = alloca %olang.scope
  %s27 = alloca %olang.scope
  %rv = alloca { i32, ptr }
  %t228 = alloca { i64, [4 x i64] }, align 8
  %t283 = alloca { i64, [4 x i64] }, align 8
  %t408 = alloca { i64, [4 x i64] }, align 8
  %t472 = alloca { i64, [4 x i64] }, align 8
  %t536 = alloca { i64, [4 x i64] }, align 8
  %t628 = alloca { i64, [4 x i64] }, align 8
  %t721 = alloca { i64, [4 x i64] }, align 8
  %t815 = alloca { i64, [4 x i64] }, align 8
  %t945 = alloca { i64, [4 x i64] }, align 8
  %t1042 = alloca { i64, [4 x i64] }, align 8
  %t1087 = alloca { i64, [4 x i64] }, align 8
  %t1159 = alloca { i64, [4 x i64] }, align 8
  %t1170 = alloca { i64, [4 x i64] }, align 8
  %t1220 = alloca { i64, [4 x i64] }, align 8
  %t1295 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ehere(ptr %v0, ptr %t1)
  store i32 %t3, ptr %l39
  br label %bb1
bb1:
  %t4 = load i32, ptr %l39, !tbaa !23
  store i32 %t4, ptr %l1, !tbaa !23
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/parse:Parser", ptr %t5, i32 0, i32 12
  %t8 = load i1, ptr %t7, !tbaa !21
  br i1 %t8, label %bb2, label %bb3
bb2:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ekeywordFieldHere(ptr %v0, ptr %t10)
  store i1 %t12, ptr %l44
  br label %bb4
bb3:
  store i1 false, ptr %l42, !tbaa !21
  br label %bb5
bb4:
  %t13 = load i1, ptr %l44, !tbaa !21
  store i1 %t13, ptr %l42, !tbaa !21
  br label %bb5
bb5:
  %t14 = load i1, ptr %l42, !tbaa !21
  br i1 %t14, label %bb6, label %bb7
bb6:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2efieldDecl(ptr %v0, ptr %v1, ptr %t15)
  %t18 = extractvalue { i32, ptr } %t17, 1
  %t19 = extractvalue { i32, ptr } %t17, 0
  store i32 %t19, ptr %l48
  %t20 = icmp ne i32 %t19, 0
  br i1 %t20, label %bb9, label %ok.21, !prof !99
ok.21:
  store ptr %t18, ptr %l47
  br label %bb8
bb7:
  br label %bb11
bb8:
  %t22 = load ptr, ptr %l47, !tbaa !29
  store ptr %t22, ptr %l45, !tbaa !29
  br label %bb10
bb9:
  %t23 = load i32, ptr %l48, !tbaa !23
  %t24 = lshr i32 %t23, 16
  %t25 = and i32 %t23, 65535
  %t26 = icmp eq i32 %t24, 1
  %t27 = select i1 %t26, i32 1, i32 0
  %t28 = icmp eq i32 %t23, 0
  %t29 = shl i32 %t27, 16
  %t30 = or i32 %t29, %t25
  %t31 = select i1 %t28, i32 0, i32 %t30
  %t33 = insertvalue { i32, ptr } zeroinitializer, i32 %t31, 0
  store { i32, ptr } %t33, ptr %rv
  br label %ret
bb10:
  %t34 = load ptr, ptr %l45, !tbaa !29
  %t35 = insertvalue { i32, ptr } zeroinitializer, ptr %t34, 1
  store { i32, ptr } %t35, ptr %rv
  br label %ret
bb11:
  %t36 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2estmtRoom(ptr %v0, ptr %t36)
  br label %bb12
bb12:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2epeek(ptr %v0, ptr %t38)
  store i32 %t40, ptr %l52
  br label %bb13
bb13:
  %t41 = load i32, ptr %l52, !range !{i32 0, i32 116}
  store i32 %t41, ptr %l2
  %t42 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t44 = trunc i64 9 to i32
  %t45 = icmp eq i32 %t42, %t44
  br i1 %t45, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb20
bb16:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eifStmt(ptr %v0, ptr %v1, ptr %t47)
  %t50 = extractvalue { i32, ptr } %t49, 1
  %t51 = extractvalue { i32, ptr } %t49, 0
  store i32 %t51, ptr %l58
  %t52 = icmp ne i32 %t51, 0
  br i1 %t52, label %bb18, label %ok.53, !prof !99
ok.53:
  store ptr %t50, ptr %l57
  br label %bb17
bb17:
  %t54 = load ptr, ptr %l57, !tbaa !29
  store ptr %t54, ptr %l55, !tbaa !29
  br label %bb19
bb18:
  %t55 = load i32, ptr %l58, !tbaa !23
  %t56 = lshr i32 %t55, 16
  %t57 = and i32 %t55, 65535
  %t58 = icmp eq i32 %t56, 1
  %t59 = select i1 %t58, i32 1, i32 0
  %t60 = icmp eq i32 %t55, 0
  %t61 = shl i32 %t59, 16
  %t62 = or i32 %t61, %t57
  %t63 = select i1 %t60, i32 0, i32 %t62
  %t65 = insertvalue { i32, ptr } zeroinitializer, i32 %t63, 0
  store { i32, ptr } %t65, ptr %rv
  br label %ret
bb19:
  %t66 = load ptr, ptr %l55, !tbaa !29
  %t69 = insertvalue { i32, ptr } zeroinitializer, ptr %t66, 1
  store { i32, ptr } %t69, ptr %rv
  br label %ret
bb20:
  %t70 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t72 = trunc i64 25 to i32
  %t73 = icmp eq i32 %t70, %t72
  br i1 %t73, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb27
bb23:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eforStmt(ptr %v0, ptr %v1, ptr %t75, i32 -1)
  %t78 = extractvalue { i32, ptr } %t77, 1
  %t79 = extractvalue { i32, ptr } %t77, 0
  store i32 %t79, ptr %l66
  %t80 = icmp ne i32 %t79, 0
  br i1 %t80, label %bb25, label %ok.81, !prof !99
ok.81:
  store ptr %t78, ptr %l65
  br label %bb24
bb24:
  %t82 = load ptr, ptr %l65, !tbaa !29
  store ptr %t82, ptr %l63, !tbaa !29
  br label %bb26
bb25:
  %t83 = load i32, ptr %l66, !tbaa !23
  %t84 = lshr i32 %t83, 16
  %t85 = and i32 %t83, 65535
  %t86 = icmp eq i32 %t84, 1
  %t87 = select i1 %t86, i32 1, i32 0
  %t88 = icmp eq i32 %t83, 0
  %t89 = shl i32 %t87, 16
  %t90 = or i32 %t89, %t85
  %t91 = select i1 %t88, i32 0, i32 %t90
  %t93 = insertvalue { i32, ptr } zeroinitializer, i32 %t91, 0
  store { i32, ptr } %t93, ptr %rv
  br label %ret
bb26:
  %t94 = load ptr, ptr %l63, !tbaa !29
  %t95 = insertvalue { i32, ptr } zeroinitializer, ptr %t94, 1
  store { i32, ptr } %t95, ptr %rv
  br label %ret
bb27:
  %t96 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t98 = trunc i64 51 to i32
  %t99 = icmp eq i32 %t96, %t98
  br i1 %t99, label %bb28, label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb38
bb30:
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t103 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elook(ptr %v0, ptr %t101, i64 1)
  store i32 %t103, ptr %l71
  br label %bb31
bb31:
  %t104 = load i32, ptr %l71, !range !{i32 0, i32 116}
  %t106 = trunc i64 25 to i32
  %t107 = icmp eq i32 %t104, %t106
  br i1 %t107, label %bb32, label %bb33
bb32:
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t111 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t109)
  store i32 %t111, ptr %l75
  br label %bb34
bb33:
  br label %bb38
bb34:
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t113 = load i32, ptr %l1, !tbaa !23
  %t116 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eforStmt(ptr %v0, ptr %v1, ptr %t112, i32 %t113)
  %t117 = extractvalue { i32, ptr } %t116, 1
  %t118 = extractvalue { i32, ptr } %t116, 0
  store i32 %t118, ptr %l80
  %t119 = icmp ne i32 %t118, 0
  br i1 %t119, label %bb36, label %ok.120, !prof !99
ok.120:
  store ptr %t117, ptr %l79
  br label %bb35
bb35:
  %t121 = load ptr, ptr %l79, !tbaa !29
  store ptr %t121, ptr %l76, !tbaa !29
  br label %bb37
bb36:
  %t122 = load i32, ptr %l80, !tbaa !23
  %t123 = lshr i32 %t122, 16
  %t124 = and i32 %t122, 65535
  %t125 = icmp eq i32 %t123, 1
  %t126 = select i1 %t125, i32 1, i32 0
  %t127 = icmp eq i32 %t122, 0
  %t128 = shl i32 %t126, 16
  %t129 = or i32 %t128, %t124
  %t130 = select i1 %t127, i32 0, i32 %t129
  %t132 = insertvalue { i32, ptr } zeroinitializer, i32 %t130, 0
  store { i32, ptr } %t132, ptr %rv
  br label %ret
bb37:
  %t133 = load ptr, ptr %l76, !tbaa !29
  %t134 = insertvalue { i32, ptr } zeroinitializer, ptr %t133, 1
  store { i32, ptr } %t134, ptr %rv
  br label %ret
bb38:
  %t135 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t137 = trunc i64 26 to i32
  %t138 = icmp eq i32 %t135, %t137
  br i1 %t138, label %bb39, label %bb40
bb39:
  br label %bb41
bb40:
  br label %bb56
bb41:
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t142 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t140)
  store i32 %t142, ptr %l85
  br label %bb42
bb42:
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t145 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2edoBody(ptr %v0, ptr %v1, ptr %t143)
  %t146 = extractvalue { i32, { i64, ptr } } %t145, 1
  %t147 = extractvalue { i32, { i64, ptr } } %t145, 0
  store i32 %t147, ptr %l89
  %t148 = icmp ne i32 %t147, 0
  br i1 %t148, label %bb44, label %ok.149, !prof !99
ok.149:
  store { i64, ptr } %t146, ptr %l88
  br label %bb43
bb43:
  %t150 = load { i64, ptr }, ptr %l88, !tbaa !27
  store { i64, ptr } %t150, ptr %l86, !tbaa !27
  br label %bb45
bb44:
  %t151 = load i32, ptr %l89, !tbaa !23
  %t152 = lshr i32 %t151, 16
  %t153 = and i32 %t151, 65535
  %t154 = icmp eq i32 %t152, 1
  %t155 = select i1 %t154, i32 1, i32 0
  %t156 = icmp eq i32 %t151, 0
  %t157 = shl i32 %t155, 16
  %t158 = or i32 %t157, %t153
  %t159 = select i1 %t156, i32 0, i32 %t158
  %t161 = insertvalue { i32, ptr } zeroinitializer, i32 %t159, 0
  store { i32, ptr } %t161, ptr %rv
  br label %ret
bb45:
  %t162 = load { i64, ptr }, ptr %l86, !tbaa !27
  store { i64, ptr } %t162, ptr %l4, !tbaa !27
  %t163 = load ptr, ptr %l0, !tbaa !29
  %t166 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %t163, i32 25)
  %t167 = extractvalue { i32, i32 } %t166, 1
  %t168 = extractvalue { i32, i32 } %t166, 0
  store i32 %t168, ptr %l95
  %t169 = icmp ne i32 %t168, 0
  br i1 %t169, label %bb47, label %ok.170, !prof !99
ok.170:
  store i32 %t167, ptr %l94
  br label %bb46
bb46:
  %t171 = load i32, ptr %l94, !tbaa !23
  store i32 %t171, ptr %l91, !tbaa !23
  br label %bb48
bb47:
  %t172 = load i32, ptr %l95, !tbaa !23
  %t173 = lshr i32 %t172, 16
  %t174 = and i32 %t172, 65535
  %t175 = icmp eq i32 %t173, 1
  %t176 = select i1 %t175, i32 1, i32 0
  %t177 = icmp eq i32 %t172, 0
  %t178 = shl i32 %t176, 16
  %t179 = or i32 %t178, %t174
  %t180 = select i1 %t177, i32 0, i32 %t179
  %t182 = insertvalue { i32, ptr } zeroinitializer, i32 %t180, 0
  store { i32, ptr } %t182, ptr %rv
  br label %ret
bb48:
  %t183 = load ptr, ptr %l0, !tbaa !29
  %t185 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexpr(ptr %v0, ptr %v1, ptr %t183)
  %t186 = extractvalue { i32, ptr } %t185, 1
  %t187 = extractvalue { i32, ptr } %t185, 0
  store i32 %t187, ptr %l100
  %t188 = icmp ne i32 %t187, 0
  br i1 %t188, label %bb50, label %ok.189, !prof !99
ok.189:
  store ptr %t186, ptr %l99
  br label %bb49
bb49:
  %t190 = load ptr, ptr %l99, !tbaa !29
  store ptr %t190, ptr %l97, !tbaa !29
  br label %bb51
bb50:
  %t191 = load i32, ptr %l100, !tbaa !23
  %t192 = lshr i32 %t191, 16
  %t193 = and i32 %t191, 65535
  %t194 = icmp eq i32 %t192, 1
  %t195 = select i1 %t194, i32 1, i32 0
  %t196 = icmp eq i32 %t191, 0
  %t197 = shl i32 %t195, 16
  %t198 = or i32 %t197, %t193
  %t199 = select i1 %t196, i32 0, i32 %t198
  %t201 = insertvalue { i32, ptr } zeroinitializer, i32 %t199, 0
  store { i32, ptr } %t201, ptr %rv
  br label %ret
bb51:
  %t202 = load ptr, ptr %l97, !tbaa !29
  store ptr %t202, ptr %l5, !tbaa !29
  %t203 = load ptr, ptr %l0, !tbaa !29
  %t204 = load i32, ptr %l1, !tbaa !23
  %t207 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t203, i32 %t204)
  store %"compiler/source:Span" %t207, ptr %l104
  br label %bb52
bb52:
  %t208 = load %"compiler/source:Span", ptr %l104
  store %"compiler/source:Span" %t208, ptr %l6
  %t209 = load ptr, ptr %l0, !tbaa !29
  %t211 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eendStmt(ptr %v0, ptr %t209)
  store i32 %t211, ptr %l106
  %t212 = icmp ne i32 %t211, 0
  br i1 %t212, label %bb54, label %ok.213, !prof !99
ok.213:
  br label %bb53
bb53:
  br label %bb55
bb54:
  %t214 = load i32, ptr %l106, !tbaa !23
  %t215 = lshr i32 %t214, 16
  %t216 = and i32 %t214, 65535
  %t217 = icmp eq i32 %t215, 1
  %t218 = select i1 %t217, i32 1, i32 0
  %t219 = icmp eq i32 %t214, 0
  %t220 = shl i32 %t218, 16
  %t221 = or i32 %t220, %t216
  %t222 = select i1 %t219, i32 0, i32 %t221
  %t224 = insertvalue { i32, ptr } zeroinitializer, i32 %t222, 0
  store { i32, ptr } %t224, ptr %rv
  br label %ret
bb55:
  %t225 = load %"compiler/source:Span", ptr %l6
  %t226 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t227 = load ptr, ptr %l5, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t228
  %t229 = getelementptr { i64, [4 x i64] }, ptr %t228, i32 0, i32 0
  store i64 10, ptr %t229
  %t231 = insertvalue { %"compiler/source:Span", { i64, ptr }, ptr } undef, %"compiler/source:Span" %t225, 0
  %t233 = insertvalue { %"compiler/source:Span", { i64, ptr }, ptr } %t231, { i64, ptr } %t226, 1
  %t235 = insertvalue { %"compiler/source:Span", { i64, ptr }, ptr } %t233, ptr %t227, 2
  %t236 = getelementptr { i64, [4 x i64] }, ptr %t228, i32 0, i32 1
  store { %"compiler/source:Span", { i64, ptr }, ptr } %t235, ptr %t236
  %t237 = load { i64, [4 x i64] }, ptr %t228
  %t239 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 40, i64 8)
  store { i64, [4 x i64] } %t237, ptr %t239
  %t241 = insertvalue { i32, ptr } zeroinitializer, ptr %t239, 1
  store { i32, ptr } %t241, ptr %rv
  br label %ret
bb56:
  %t242 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t244 = trunc i64 31 to i32
  %t245 = icmp eq i32 %t242, %t244
  br i1 %t245, label %bb57, label %bb58
bb57:
  br label %bb59
bb58:
  br label %bb69
bb59:
  %t247 = load ptr, ptr %l0, !tbaa !29
  %t249 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ematchBody(ptr %v0, ptr %v1, ptr %t247, i1 false)
  %t250 = extractvalue { i32, ptr } %t249, 1
  %t251 = extractvalue { i32, ptr } %t249, 0
  store i32 %t251, ptr %l118
  %t252 = icmp ne i32 %t251, 0
  br i1 %t252, label %bb61, label %ok.253, !prof !99
ok.253:
  store ptr %t250, ptr %l117
  br label %bb60
bb60:
  %t254 = load ptr, ptr %l117, !tbaa !29
  store ptr %t254, ptr %l115, !tbaa !29
  br label %bb62
bb61:
  %t255 = load i32, ptr %l118, !tbaa !23
  %t256 = lshr i32 %t255, 16
  %t257 = and i32 %t255, 65535
  %t258 = icmp eq i32 %t256, 1
  %t259 = select i1 %t258, i32 1, i32 0
  %t260 = icmp eq i32 %t255, 0
  %t261 = shl i32 %t259, 16
  %t262 = or i32 %t261, %t257
  %t263 = select i1 %t260, i32 0, i32 %t262
  %t265 = insertvalue { i32, ptr } zeroinitializer, i32 %t263, 0
  store { i32, ptr } %t265, ptr %rv
  br label %ret
bb62:
  %t266 = load ptr, ptr %l115, !tbaa !29
  store ptr %t266, ptr %l7, !tbaa !29
  %t267 = load ptr, ptr %l0, !tbaa !29
  %t268 = load i32, ptr %l1, !tbaa !23
  %t271 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t267, i32 %t268)
  store %"compiler/source:Span" %t271, ptr %l122
  br label %bb63
bb63:
  %t272 = load %"compiler/source:Span", ptr %l122
  store %"compiler/source:Span" %t272, ptr %l8
  %t273 = load ptr, ptr %l0, !tbaa !29
  %t276 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t273, i32 8)
  store i1 %t276, ptr %l125
  br label %bb64
bb64:
  %t277 = load i1, ptr %l125, !tbaa !21
  br i1 %t277, label %bb65, label %bb66
bb65:
  %t278 = load ptr, ptr %l0, !tbaa !29
  %t280 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t278)
  store i32 %t280, ptr %l127
  br label %bb67
bb66:
  br label %bb68
bb67:
  br label %bb68
bb68:
  %t281 = load %"compiler/source:Span", ptr %l8
  %t282 = load ptr, ptr %l7, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t283
  %t284 = getelementptr { i64, [4 x i64] }, ptr %t283, i32 0, i32 0
  store i64 11, ptr %t284
  %t286 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t281, 0
  %t288 = insertvalue { %"compiler/source:Span", ptr } %t286, ptr %t282, 1
  %t289 = getelementptr { i64, [4 x i64] }, ptr %t283, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t288, ptr %t289
  %t290 = load { i64, [4 x i64] }, ptr %t283
  %t292 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 40, i64 8)
  store { i64, [4 x i64] } %t290, ptr %t292
  %t294 = insertvalue { i32, ptr } zeroinitializer, ptr %t292, 1
  store { i32, ptr } %t294, ptr %rv
  br label %ret
bb69:
  %t295 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t297 = trunc i64 13 to i32
  %t298 = icmp eq i32 %t295, %t297
  br i1 %t298, label %bb70, label %bb71
bb70:
  br label %bb72
bb71:
  br label %bb100
bb72:
  %t300 = load ptr, ptr %l0, !tbaa !29
  %t302 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t300)
  store i32 %t302, ptr %l135
  br label %bb73
bb73:
  %t303 = icmp sge i64 0, 0
  br i1 %t303, label %bb74, label %bb75
bb74:
  %t305 = icmp sle i64 0, 1152921504606846975
  br i1 %t305, label %bb76, label %bb77
bb75:
  call void @__olang_check_failed(ptr @olang_loc_405430454c9e5d04_720bbb7e3dc9fd0)
  unreachable
bb76:
  %t307 = mul i64 0, 8
  %t308 = insertvalue { i64, ptr } undef, i64 0, 0
  %t309 = insertvalue { i64, ptr } %t308, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t309, ptr %l9, !tbaa !27
  %t311 = load ptr, ptr %l0, !tbaa !29
  %t313 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eatEnd(ptr %v0, ptr %t311)
  store i1 %t313, ptr %l140
  br label %bb78
bb77:
  call void @__olang_check_failed(ptr @olang_loc_405430454c9e5d04_720bbb7e3dc9fd0)
  unreachable
bb78:
  %t314 = load i1, ptr %l140, !tbaa !21
  %t315 = xor i1 %t314, true
  br i1 %t315, label %bb79, label %bb80
bb79:
  %t317 = load ptr, ptr %l0, !tbaa !29
  %t319 = getelementptr %"compiler/parse:Parser", ptr %t317, i32 0, i32 16
  %t320 = load i1, ptr %t319, !tbaa !21
  store i1 %t320, ptr %l142, !tbaa !21
  br label %bb81
bb80:
  store i1 false, ptr %l142, !tbaa !21
  br label %bb81
bb81:
  %t322 = load i1, ptr %l142, !tbaa !21
  br i1 %t322, label %bb82, label %bb83
bb82:
  %t323 = load ptr, ptr %l0, !tbaa !29
  %t325 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexpr(ptr %v0, ptr %v1, ptr %t323)
  %t326 = extractvalue { i32, ptr } %t325, 1
  %t327 = extractvalue { i32, ptr } %t325, 0
  store i32 %t327, ptr %l148
  %t328 = icmp ne i32 %t327, 0
  br i1 %t328, label %bb85, label %ok.329, !prof !99
ok.329:
  store ptr %t326, ptr %l147
  br label %bb84
bb83:
  %t330 = load ptr, ptr %l0, !tbaa !29
  %t332 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eatEnd(ptr %v0, ptr %t330)
  store i1 %t332, ptr %l152
  br label %bb87
bb84:
  %t333 = load ptr, ptr %l147, !tbaa !29
  store ptr %t333, ptr %l145, !tbaa !29
  br label %bb86
bb85:
  %t334 = load i32, ptr %l148, !tbaa !23
  %t335 = lshr i32 %t334, 16
  %t336 = and i32 %t334, 65535
  %t337 = icmp eq i32 %t335, 1
  %t338 = select i1 %t337, i32 1, i32 0
  %t339 = icmp eq i32 %t334, 0
  %t340 = shl i32 %t338, 16
  %t341 = or i32 %t340, %t336
  %t342 = select i1 %t339, i32 0, i32 %t341
  %t344 = insertvalue { i32, ptr } zeroinitializer, i32 %t342, 0
  store { i32, ptr } %t344, ptr %rv
  br label %ret
bb86:
  %t345 = mul i64 1, 8
  %t346 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t345)
  %t347 = insertvalue { i64, ptr } undef, i64 1, 0
  %t348 = insertvalue { i64, ptr } %t347, ptr %t346, 1
  store { i64, ptr } %t348, ptr %l150, !tbaa !27
  %t349 = load ptr, ptr %l145, !tbaa !29
  %t350 = getelementptr { i64, ptr }, ptr %l150, i32 0, i32 1
  %t351 = load ptr, ptr %t350, !tbaa !27
  %t352 = getelementptr ptr, ptr %t351, i64 0
  store ptr %t349, ptr %t352, !tbaa !39
  %t353 = load { i64, ptr }, ptr %l150, !tbaa !27
  store { i64, ptr } %t353, ptr %l9, !tbaa !27
  br label %bb95
bb87:
  %t354 = load i1, ptr %l152, !tbaa !21
  %t355 = xor i1 %t354, true
  br i1 %t355, label %bb88, label %bb89
bb88:
  %t357 = load ptr, ptr %l0, !tbaa !29
  store ptr %t357, ptr %l154, !tbaa !29
  %t358 = load ptr, ptr %l0, !tbaa !29
  %t360 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ehere(ptr %v0, ptr %t358)
  store i32 %t360, ptr %l156
  br label %bb90
bb89:
  br label %bb94
bb90:
  %t361 = load i32, ptr %l156, !tbaa !23
  %t362 = load ptr, ptr %l154, !tbaa !29
  %t363 = getelementptr %"compiler/parse:Parser", ptr %t362, i32 0, i32 28
  store i32 %t361, ptr %t363, !tbaa !23
  %t364 = load ptr, ptr %l0, !tbaa !29
  %t366 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexprList(ptr %v0, ptr %v1, ptr %t364)
  %t367 = extractvalue { i32, { i64, ptr } } %t366, 1
  %t368 = extractvalue { i32, { i64, ptr } } %t366, 0
  store i32 %t368, ptr %l160
  %t369 = icmp ne i32 %t368, 0
  br i1 %t369, label %bb92, label %ok.370, !prof !99
ok.370:
  store { i64, ptr } %t367, ptr %l159
  br label %bb91
bb91:
  %t371 = load { i64, ptr }, ptr %l159, !tbaa !27
  store { i64, ptr } %t371, ptr %l157, !tbaa !27
  br label %bb93
bb92:
  %t372 = load i32, ptr %l160, !tbaa !23
  %t373 = lshr i32 %t372, 16
  %t374 = and i32 %t372, 65535
  %t375 = icmp eq i32 %t373, 1
  %t376 = select i1 %t375, i32 1, i32 0
  %t377 = icmp eq i32 %t372, 0
  %t378 = shl i32 %t376, 16
  %t379 = or i32 %t378, %t374
  %t380 = select i1 %t377, i32 0, i32 %t379
  %t382 = insertvalue { i32, ptr } zeroinitializer, i32 %t380, 0
  store { i32, ptr } %t382, ptr %rv
  br label %ret
bb93:
  %t383 = load { i64, ptr }, ptr %l157, !tbaa !27
  store { i64, ptr } %t383, ptr %l9, !tbaa !27
  br label %bb94
bb94:
  br label %bb95
bb95:
  %t384 = load ptr, ptr %l0, !tbaa !29
  %t385 = load i32, ptr %l1, !tbaa !23
  %t388 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t384, i32 %t385)
  store %"compiler/source:Span" %t388, ptr %l164
  br label %bb96
bb96:
  %t389 = load %"compiler/source:Span", ptr %l164
  store %"compiler/source:Span" %t389, ptr %l10
  %t390 = load ptr, ptr %l0, !tbaa !29
  %t392 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eendStmt(ptr %v0, ptr %t390)
  store i32 %t392, ptr %l166
  %t393 = icmp ne i32 %t392, 0
  br i1 %t393, label %bb98, label %ok.394, !prof !99
ok.394:
  br label %bb97
bb97:
  br label %bb99
bb98:
  %t395 = load i32, ptr %l166, !tbaa !23
  %t396 = lshr i32 %t395, 16
  %t397 = and i32 %t395, 65535
  %t398 = icmp eq i32 %t396, 1
  %t399 = select i1 %t398, i32 1, i32 0
  %t400 = icmp eq i32 %t395, 0
  %t401 = shl i32 %t399, 16
  %t402 = or i32 %t401, %t397
  %t403 = select i1 %t400, i32 0, i32 %t402
  %t405 = insertvalue { i32, ptr } zeroinitializer, i32 %t403, 0
  store { i32, ptr } %t405, ptr %rv
  br label %ret
bb99:
  %t406 = load %"compiler/source:Span", ptr %l10
  %t407 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, [4 x i64] } zeroinitializer, ptr %t408
  %t409 = getelementptr { i64, [4 x i64] }, ptr %t408, i32 0, i32 0
  store i64 12, ptr %t409
  %t411 = insertvalue { %"compiler/source:Span", { i64, ptr } } undef, %"compiler/source:Span" %t406, 0
  %t413 = insertvalue { %"compiler/source:Span", { i64, ptr } } %t411, { i64, ptr } %t407, 1
  %t414 = getelementptr { i64, [4 x i64] }, ptr %t408, i32 0, i32 1
  store { %"compiler/source:Span", { i64, ptr } } %t413, ptr %t414
  %t415 = load { i64, [4 x i64] }, ptr %t408
  %t417 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 40, i64 8)
  store { i64, [4 x i64] } %t415, ptr %t417
  %t419 = insertvalue { i32, ptr } zeroinitializer, ptr %t417, 1
  store { i32, ptr } %t419, ptr %rv
  br label %ret
bb100:
  %t420 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t422 = trunc i64 50 to i32
  %t423 = icmp eq i32 %t420, %t422
  br i1 %t423, label %bb101, label %bb102
bb101:
  br label %bb103
bb102:
  br label %bb112
bb103:
  %t425 = load ptr, ptr %l0, !tbaa !29
  %t427 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t425)
  store i32 %t427, ptr %l175
  br label %bb104
bb104:
  %t428 = load ptr, ptr %l0, !tbaa !29
  %t430 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexpr(ptr %v0, ptr %v1, ptr %t428)
  %t431 = extractvalue { i32, ptr } %t430, 1
  %t432 = extractvalue { i32, ptr } %t430, 0
  store i32 %t432, ptr %l179
  %t433 = icmp ne i32 %t432, 0
  br i1 %t433, label %bb106, label %ok.434, !prof !99
ok.434:
  store ptr %t431, ptr %l178
  br label %bb105
bb105:
  %t435 = load ptr, ptr %l178, !tbaa !29
  store ptr %t435, ptr %l176, !tbaa !29
  br label %bb107
bb106:
  %t436 = load i32, ptr %l179, !tbaa !23
  %t437 = lshr i32 %t436, 16
  %t438 = and i32 %t436, 65535
  %t439 = icmp eq i32 %t437, 1
  %t440 = select i1 %t439, i32 1, i32 0
  %t441 = icmp eq i32 %t436, 0
  %t442 = shl i32 %t440, 16
  %t443 = or i32 %t442, %t438
  %t444 = select i1 %t441, i32 0, i32 %t443
  %t446 = insertvalue { i32, ptr } zeroinitializer, i32 %t444, 0
  store { i32, ptr } %t446, ptr %rv
  br label %ret
bb107:
  %t447 = load ptr, ptr %l176, !tbaa !29
  store ptr %t447, ptr %l11, !tbaa !29
  %t448 = load ptr, ptr %l0, !tbaa !29
  %t449 = load i32, ptr %l1, !tbaa !23
  %t452 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t448, i32 %t449)
  store %"compiler/source:Span" %t452, ptr %l183
  br label %bb108
bb108:
  %t453 = load %"compiler/source:Span", ptr %l183
  store %"compiler/source:Span" %t453, ptr %l12
  %t454 = load ptr, ptr %l0, !tbaa !29
  %t456 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eendStmt(ptr %v0, ptr %t454)
  store i32 %t456, ptr %l185
  %t457 = icmp ne i32 %t456, 0
  br i1 %t457, label %bb110, label %ok.458, !prof !99
ok.458:
  br label %bb109
bb109:
  br label %bb111
bb110:
  %t459 = load i32, ptr %l185, !tbaa !23
  %t460 = lshr i32 %t459, 16
  %t461 = and i32 %t459, 65535
  %t462 = icmp eq i32 %t460, 1
  %t463 = select i1 %t462, i32 1, i32 0
  %t464 = icmp eq i32 %t459, 0
  %t465 = shl i32 %t463, 16
  %t466 = or i32 %t465, %t461
  %t467 = select i1 %t464, i32 0, i32 %t466
  %t469 = insertvalue { i32, ptr } zeroinitializer, i32 %t467, 0
  store { i32, ptr } %t469, ptr %rv
  br label %ret
bb111:
  %t470 = load %"compiler/source:Span", ptr %l12
  %t471 = load ptr, ptr %l11, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t472
  %t473 = getelementptr { i64, [4 x i64] }, ptr %t472, i32 0, i32 0
  store i64 15, ptr %t473
  %t475 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t470, 0
  %t477 = insertvalue { %"compiler/source:Span", ptr } %t475, ptr %t471, 1
  %t478 = getelementptr { i64, [4 x i64] }, ptr %t472, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t477, ptr %t478
  %t479 = load { i64, [4 x i64] }, ptr %t472
  %t481 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 40, i64 8)
  store { i64, [4 x i64] } %t479, ptr %t481
  %t483 = insertvalue { i32, ptr } zeroinitializer, ptr %t481, 1
  store { i32, ptr } %t483, ptr %rv
  br label %ret
bb112:
  %t484 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t486 = trunc i64 49 to i32
  %t487 = icmp eq i32 %t484, %t486
  br i1 %t487, label %bb113, label %bb114
bb113:
  br label %bb115
bb114:
  br label %bb124
bb115:
  %t489 = load ptr, ptr %l0, !tbaa !29
  %t491 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t489)
  store i32 %t491, ptr %l194
  br label %bb116
bb116:
  %t492 = load ptr, ptr %l0, !tbaa !29
  %t494 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexpr(ptr %v0, ptr %v1, ptr %t492)
  %t495 = extractvalue { i32, ptr } %t494, 1
  %t496 = extractvalue { i32, ptr } %t494, 0
  store i32 %t496, ptr %l198
  %t497 = icmp ne i32 %t496, 0
  br i1 %t497, label %bb118, label %ok.498, !prof !99
ok.498:
  store ptr %t495, ptr %l197
  br label %bb117
bb117:
  %t499 = load ptr, ptr %l197, !tbaa !29
  store ptr %t499, ptr %l195, !tbaa !29
  br label %bb119
bb118:
  %t500 = load i32, ptr %l198, !tbaa !23
  %t501 = lshr i32 %t500, 16
  %t502 = and i32 %t500, 65535
  %t503 = icmp eq i32 %t501, 1
  %t504 = select i1 %t503, i32 1, i32 0
  %t505 = icmp eq i32 %t500, 0
  %t506 = shl i32 %t504, 16
  %t507 = or i32 %t506, %t502
  %t508 = select i1 %t505, i32 0, i32 %t507
  %t510 = insertvalue { i32, ptr } zeroinitializer, i32 %t508, 0
  store { i32, ptr } %t510, ptr %rv
  br label %ret
bb119:
  %t511 = load ptr, ptr %l195, !tbaa !29
  store ptr %t511, ptr %l13, !tbaa !29
  %t512 = load ptr, ptr %l0, !tbaa !29
  %t513 = load i32, ptr %l1, !tbaa !23
  %t516 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t512, i32 %t513)
  store %"compiler/source:Span" %t516, ptr %l202
  br label %bb120
bb120:
  %t517 = load %"compiler/source:Span", ptr %l202
  store %"compiler/source:Span" %t517, ptr %l14
  %t518 = load ptr, ptr %l0, !tbaa !29
  %t520 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eendStmt(ptr %v0, ptr %t518)
  store i32 %t520, ptr %l204
  %t521 = icmp ne i32 %t520, 0
  br i1 %t521, label %bb122, label %ok.522, !prof !99
ok.522:
  br label %bb121
bb121:
  br label %bb123
bb122:
  %t523 = load i32, ptr %l204, !tbaa !23
  %t524 = lshr i32 %t523, 16
  %t525 = and i32 %t523, 65535
  %t526 = icmp eq i32 %t524, 1
  %t527 = select i1 %t526, i32 1, i32 0
  %t528 = icmp eq i32 %t523, 0
  %t529 = shl i32 %t527, 16
  %t530 = or i32 %t529, %t525
  %t531 = select i1 %t528, i32 0, i32 %t530
  %t533 = insertvalue { i32, ptr } zeroinitializer, i32 %t531, 0
  store { i32, ptr } %t533, ptr %rv
  br label %ret
bb123:
  %t534 = load %"compiler/source:Span", ptr %l14
  %t535 = load ptr, ptr %l13, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t536
  %t537 = getelementptr { i64, [4 x i64] }, ptr %t536, i32 0, i32 0
  store i64 21, ptr %t537
  %t539 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t534, 0
  %t541 = insertvalue { %"compiler/source:Span", ptr } %t539, ptr %t535, 1
  %t542 = getelementptr { i64, [4 x i64] }, ptr %t536, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t541, ptr %t542
  %t543 = load { i64, [4 x i64] }, ptr %t536
  %t545 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 40, i64 8)
  store { i64, [4 x i64] } %t543, ptr %t545
  %t547 = insertvalue { i32, ptr } zeroinitializer, ptr %t545, 1
  store { i32, ptr } %t547, ptr %rv
  br label %ret
bb124:
  %t548 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t550 = trunc i64 19 to i32
  %t551 = icmp eq i32 %t548, %t550
  br i1 %t551, label %bb125, label %bb126
bb125:
  br label %bb131
bb126:
  %t553 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t555 = trunc i64 20 to i32
  %t556 = icmp eq i32 %t553, %t555
  br i1 %t556, label %bb127, label %bb128
bb127:
  br label %bb131
bb128:
  %t558 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t560 = trunc i64 21 to i32
  %t561 = icmp eq i32 %t558, %t560
  br i1 %t561, label %bb129, label %bb130
bb129:
  br label %bb131
bb130:
  br label %bb148
bb131:
  %t563 = load ptr, ptr %l0, !tbaa !29
  %t565 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2epeek(ptr %v0, ptr %t563)
  store i32 %t565, ptr %l217
  br label %bb132
bb132:
  %t566 = load i32, ptr %l217, !range !{i32 0, i32 116}
  store i32 %t566, ptr %l15
  %t567 = load ptr, ptr %l0, !tbaa !29
  %t569 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t567)
  store i32 %t569, ptr %l219
  br label %bb133
bb133:
  store ptr null, ptr %l16, !tbaa !29
  %t570 = load i32, ptr %l15, !range !{i32 0, i32 116}
  %t572 = trunc i64 21 to i32
  %t573 = icmp eq i32 %t570, %t572
  br i1 %t573, label %bb134, label %bb135
bb134:
  %t575 = load ptr, ptr %l0, !tbaa !29
  %t577 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eatEnd(ptr %v0, ptr %t575)
  store i1 %t577, ptr %l224
  br label %bb136
bb135:
  store i1 false, ptr %l222, !tbaa !21
  br label %bb137
bb136:
  %t578 = load i1, ptr %l224, !tbaa !21
  %t579 = xor i1 %t578, true
  store i1 %t579, ptr %l222, !tbaa !21
  br label %bb137
bb137:
  %t581 = load i1, ptr %l222, !tbaa !21
  br i1 %t581, label %bb138, label %bb139
bb138:
  %t582 = load ptr, ptr %l0, !tbaa !29
  %t584 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexpr(ptr %v0, ptr %v1, ptr %t582)
  %t585 = extractvalue { i32, ptr } %t584, 1
  %t586 = extractvalue { i32, ptr } %t584, 0
  store i32 %t586, ptr %l229
  %t587 = icmp ne i32 %t586, 0
  br i1 %t587, label %bb141, label %ok.588, !prof !99
ok.588:
  store ptr %t585, ptr %l228
  br label %bb140
bb139:
  br label %bb143
bb140:
  %t589 = load ptr, ptr %l228, !tbaa !29
  store ptr %t589, ptr %l226, !tbaa !29
  br label %bb142
bb141:
  %t590 = load i32, ptr %l229, !tbaa !23
  %t591 = lshr i32 %t590, 16
  %t592 = and i32 %t590, 65535
  %t593 = icmp eq i32 %t591, 1
  %t594 = select i1 %t593, i32 1, i32 0
  %t595 = icmp eq i32 %t590, 0
  %t596 = shl i32 %t594, 16
  %t597 = or i32 %t596, %t592
  %t598 = select i1 %t595, i32 0, i32 %t597
  %t600 = insertvalue { i32, ptr } zeroinitializer, i32 %t598, 0
  store { i32, ptr } %t600, ptr %rv
  br label %ret
bb142:
  %t601 = load ptr, ptr %l226, !tbaa !29
  store ptr %t601, ptr %l16, !tbaa !29
  br label %bb143
bb143:
  %t603 = load ptr, ptr %l0, !tbaa !29
  %t604 = load i32, ptr %l1, !tbaa !23
  %t607 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t603, i32 %t604)
  store %"compiler/source:Span" %t607, ptr %l234
  br label %bb144
bb144:
  %t608 = load %"compiler/source:Span", ptr %l234
  store %"compiler/source:Span" %t608, ptr %l17
  %t609 = load ptr, ptr %l0, !tbaa !29
  %t611 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eendStmt(ptr %v0, ptr %t609)
  store i32 %t611, ptr %l236
  %t612 = icmp ne i32 %t611, 0
  br i1 %t612, label %bb146, label %ok.613, !prof !99
ok.613:
  br label %bb145
bb145:
  br label %bb147
bb146:
  %t614 = load i32, ptr %l236, !tbaa !23
  %t615 = lshr i32 %t614, 16
  %t616 = and i32 %t614, 65535
  %t617 = icmp eq i32 %t615, 1
  %t618 = select i1 %t617, i32 1, i32 0
  %t619 = icmp eq i32 %t614, 0
  %t620 = shl i32 %t618, 16
  %t621 = or i32 %t620, %t616
  %t622 = select i1 %t619, i32 0, i32 %t621
  %t624 = insertvalue { i32, ptr } zeroinitializer, i32 %t622, 0
  store { i32, ptr } %t624, ptr %rv
  br label %ret
bb147:
  %t625 = load %"compiler/source:Span", ptr %l17
  %t626 = load i32, ptr %l15, !range !{i32 0, i32 116}
  %t627 = load ptr, ptr %l16, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t628
  %t629 = getelementptr { i64, [4 x i64] }, ptr %t628, i32 0, i32 0
  store i64 13, ptr %t629
  %t631 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t625, 0
  %t633 = insertvalue { %"compiler/source:Span", i32, ptr } %t631, i32 %t626, 1
  %t635 = insertvalue { %"compiler/source:Span", i32, ptr } %t633, ptr %t627, 2
  %t636 = getelementptr { i64, [4 x i64] }, ptr %t628, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t635, ptr %t636
  %t637 = load { i64, [4 x i64] }, ptr %t628
  %t639 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 40, i64 8)
  store { i64, [4 x i64] } %t637, ptr %t639
  %t641 = insertvalue { i32, ptr } zeroinitializer, ptr %t639, 1
  store { i32, ptr } %t641, ptr %rv
  br label %ret
bb148:
  %t642 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t644 = trunc i64 24 to i32
  %t645 = icmp eq i32 %t642, %t644
  br i1 %t645, label %bb149, label %bb150
bb149:
  br label %bb151
bb150:
  br label %bb167
bb151:
  %t647 = load ptr, ptr %l0, !tbaa !29
  %t649 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t647)
  store i32 %t649, ptr %l246
  br label %bb152
bb152:
  %t650 = load ptr, ptr %l0, !tbaa !29
  %t652 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexpr(ptr %v0, ptr %v1, ptr %t650)
  %t653 = extractvalue { i32, ptr } %t652, 1
  %t654 = extractvalue { i32, ptr } %t652, 0
  store i32 %t654, ptr %l250
  %t655 = icmp ne i32 %t654, 0
  br i1 %t655, label %bb154, label %ok.656, !prof !99
ok.656:
  store ptr %t653, ptr %l249
  br label %bb153
bb153:
  %t657 = load ptr, ptr %l249, !tbaa !29
  store ptr %t657, ptr %l247, !tbaa !29
  br label %bb155
bb154:
  %t658 = load i32, ptr %l250, !tbaa !23
  %t659 = lshr i32 %t658, 16
  %t660 = and i32 %t658, 65535
  %t661 = icmp eq i32 %t659, 1
  %t662 = select i1 %t661, i32 1, i32 0
  %t663 = icmp eq i32 %t658, 0
  %t664 = shl i32 %t662, 16
  %t665 = or i32 %t664, %t660
  %t666 = select i1 %t663, i32 0, i32 %t665
  %t668 = insertvalue { i32, ptr } zeroinitializer, i32 %t666, 0
  store { i32, ptr } %t668, ptr %rv
  br label %ret
bb155:
  %t669 = load ptr, ptr %l247, !tbaa !29
  store ptr %t669, ptr %l18, !tbaa !29
  store ptr null, ptr %l19, !tbaa !29
  %t670 = load ptr, ptr %l0, !tbaa !29
  %t673 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t670, i32 75)
  store i1 %t673, ptr %l254
  br label %bb156
bb156:
  %t674 = load i1, ptr %l254, !tbaa !21
  br i1 %t674, label %bb157, label %bb158
bb157:
  %t675 = load ptr, ptr %l0, !tbaa !29
  %t677 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexpr(ptr %v0, ptr %v1, ptr %t675)
  %t678 = extractvalue { i32, ptr } %t677, 1
  %t679 = extractvalue { i32, ptr } %t677, 0
  store i32 %t679, ptr %l258
  %t680 = icmp ne i32 %t679, 0
  br i1 %t680, label %bb160, label %ok.681, !prof !99
ok.681:
  store ptr %t678, ptr %l257
  br label %bb159
bb158:
  br label %bb162
bb159:
  %t682 = load ptr, ptr %l257, !tbaa !29
  store ptr %t682, ptr %l255, !tbaa !29
  br label %bb161
bb160:
  %t683 = load i32, ptr %l258, !tbaa !23
  %t684 = lshr i32 %t683, 16
  %t685 = and i32 %t683, 65535
  %t686 = icmp eq i32 %t684, 1
  %t687 = select i1 %t686, i32 1, i32 0
  %t688 = icmp eq i32 %t683, 0
  %t689 = shl i32 %t687, 16
  %t690 = or i32 %t689, %t685
  %t691 = select i1 %t688, i32 0, i32 %t690
  %t693 = insertvalue { i32, ptr } zeroinitializer, i32 %t691, 0
  store { i32, ptr } %t693, ptr %rv
  br label %ret
bb161:
  %t694 = load ptr, ptr %l255, !tbaa !29
  store ptr %t694, ptr %l19, !tbaa !29
  br label %bb162
bb162:
  %t696 = load ptr, ptr %l0, !tbaa !29
  %t697 = load i32, ptr %l1, !tbaa !23
  %t700 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t696, i32 %t697)
  store %"compiler/source:Span" %t700, ptr %l263
  br label %bb163
bb163:
  %t701 = load %"compiler/source:Span", ptr %l263
  store %"compiler/source:Span" %t701, ptr %l20
  %t702 = load ptr, ptr %l0, !tbaa !29
  %t704 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eendStmt(ptr %v0, ptr %t702)
  store i32 %t704, ptr %l265
  %t705 = icmp ne i32 %t704, 0
  br i1 %t705, label %bb165, label %ok.706, !prof !99
ok.706:
  br label %bb164
bb164:
  br label %bb166
bb165:
  %t707 = load i32, ptr %l265, !tbaa !23
  %t708 = lshr i32 %t707, 16
  %t709 = and i32 %t707, 65535
  %t710 = icmp eq i32 %t708, 1
  %t711 = select i1 %t710, i32 1, i32 0
  %t712 = icmp eq i32 %t707, 0
  %t713 = shl i32 %t711, 16
  %t714 = or i32 %t713, %t709
  %t715 = select i1 %t712, i32 0, i32 %t714
  %t717 = insertvalue { i32, ptr } zeroinitializer, i32 %t715, 0
  store { i32, ptr } %t717, ptr %rv
  br label %ret
bb166:
  %t718 = load %"compiler/source:Span", ptr %l20
  %t719 = load ptr, ptr %l18, !tbaa !29
  %t720 = load ptr, ptr %l19, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t721
  %t722 = getelementptr { i64, [4 x i64] }, ptr %t721, i32 0, i32 0
  store i64 14, ptr %t722
  %t724 = insertvalue { %"compiler/source:Span", ptr, ptr } undef, %"compiler/source:Span" %t718, 0
  %t726 = insertvalue { %"compiler/source:Span", ptr, ptr } %t724, ptr %t719, 1
  %t728 = insertvalue { %"compiler/source:Span", ptr, ptr } %t726, ptr %t720, 2
  %t729 = getelementptr { i64, [4 x i64] }, ptr %t721, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr } %t728, ptr %t729
  %t730 = load { i64, [4 x i64] }, ptr %t721
  %t732 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 40, i64 8)
  store { i64, [4 x i64] } %t730, ptr %t732
  %t734 = insertvalue { i32, ptr } zeroinitializer, ptr %t732, 1
  store { i32, ptr } %t734, ptr %rv
  br label %ret
bb167:
  %t735 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t737 = trunc i64 38 to i32
  %t738 = icmp eq i32 %t735, %t737
  br i1 %t738, label %bb168, label %bb169
bb168:
  br label %bb170
bb169:
  br label %bb186
bb170:
  %t740 = load ptr, ptr %l0, !tbaa !29
  %t742 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t740)
  store i32 %t742, ptr %l275
  br label %bb171
bb171:
  %t743 = load ptr, ptr %l0, !tbaa !29
  %t745 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2epath(ptr %v0, ptr %v1, ptr %t743)
  %t746 = extractvalue { i32, ptr } %t745, 1
  %t747 = extractvalue { i32, ptr } %t745, 0
  store i32 %t747, ptr %l279
  %t748 = icmp ne i32 %t747, 0
  br i1 %t748, label %bb173, label %ok.749, !prof !99
ok.749:
  store ptr %t746, ptr %l278
  br label %bb172
bb172:
  %t750 = load ptr, ptr %l278, !tbaa !29
  store ptr %t750, ptr %l276, !tbaa !29
  br label %bb174
bb173:
  %t751 = load i32, ptr %l279, !tbaa !23
  %t752 = lshr i32 %t751, 16
  %t753 = and i32 %t751, 65535
  %t754 = icmp eq i32 %t752, 1
  %t755 = select i1 %t754, i32 1, i32 0
  %t756 = icmp eq i32 %t751, 0
  %t757 = shl i32 %t755, 16
  %t758 = or i32 %t757, %t753
  %t759 = select i1 %t756, i32 0, i32 %t758
  %t761 = insertvalue { i32, ptr } zeroinitializer, i32 %t759, 0
  store { i32, ptr } %t761, ptr %rv
  br label %ret
bb174:
  %t762 = load ptr, ptr %l276, !tbaa !29
  store ptr %t762, ptr %l21, !tbaa !29
  store { i64, ptr } { i64 -1, ptr null }, ptr %l22, !tbaa !27
  %t763 = load ptr, ptr %l0, !tbaa !29
  %t766 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t763, i32 110)
  store i1 %t766, ptr %l283
  br label %bb175
bb175:
  %t767 = load i1, ptr %l283, !tbaa !21
  br i1 %t767, label %bb176, label %bb177
bb176:
  %t768 = load ptr, ptr %l0, !tbaa !29
  %t770 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eargs(ptr %v0, ptr %v1, ptr %t768)
  %t771 = extractvalue { i32, { i64, ptr } } %t770, 1
  %t772 = extractvalue { i32, { i64, ptr } } %t770, 0
  store i32 %t772, ptr %l287
  %t773 = icmp ne i32 %t772, 0
  br i1 %t773, label %bb179, label %ok.774, !prof !99
ok.774:
  store { i64, ptr } %t771, ptr %l286
  br label %bb178
bb177:
  br label %bb181
bb178:
  %t775 = load { i64, ptr }, ptr %l286, !tbaa !27
  store { i64, ptr } %t775, ptr %l284, !tbaa !27
  br label %bb180
bb179:
  %t776 = load i32, ptr %l287, !tbaa !23
  %t777 = lshr i32 %t776, 16
  %t778 = and i32 %t776, 65535
  %t779 = icmp eq i32 %t777, 1
  %t780 = select i1 %t779, i32 1, i32 0
  %t781 = icmp eq i32 %t776, 0
  %t782 = shl i32 %t780, 16
  %t783 = or i32 %t782, %t778
  %t784 = select i1 %t781, i32 0, i32 %t783
  %t786 = insertvalue { i32, ptr } zeroinitializer, i32 %t784, 0
  store { i32, ptr } %t786, ptr %rv
  br label %ret
bb180:
  %t787 = load { i64, ptr }, ptr %l284, !tbaa !27
  store { i64, ptr } %t787, ptr %l22, !tbaa !27
  br label %bb181
bb181:
  %t789 = load ptr, ptr %l0, !tbaa !29
  %t790 = load i32, ptr %l1, !tbaa !23
  %t793 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t789, i32 %t790)
  store %"compiler/source:Span" %t793, ptr %l292
  br label %bb182
bb182:
  %t794 = load %"compiler/source:Span", ptr %l292
  store %"compiler/source:Span" %t794, ptr %l23
  %t795 = load ptr, ptr %l0, !tbaa !29
  %t797 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eendStmt(ptr %v0, ptr %t795)
  store i32 %t797, ptr %l294
  %t798 = icmp ne i32 %t797, 0
  br i1 %t798, label %bb184, label %ok.799, !prof !99
ok.799:
  br label %bb183
bb183:
  br label %bb185
bb184:
  %t800 = load i32, ptr %l294, !tbaa !23
  %t801 = lshr i32 %t800, 16
  %t802 = and i32 %t800, 65535
  %t803 = icmp eq i32 %t801, 1
  %t804 = select i1 %t803, i32 1, i32 0
  %t805 = icmp eq i32 %t800, 0
  %t806 = shl i32 %t804, 16
  %t807 = or i32 %t806, %t802
  %t808 = select i1 %t805, i32 0, i32 %t807
  %t810 = insertvalue { i32, ptr } zeroinitializer, i32 %t808, 0
  store { i32, ptr } %t810, ptr %rv
  br label %ret
bb185:
  %t811 = load %"compiler/source:Span", ptr %l23
  %t812 = load ptr, ptr %l21, !tbaa !29
  %t814 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, [4 x i64] } zeroinitializer, ptr %t815
  %t816 = getelementptr { i64, [4 x i64] }, ptr %t815, i32 0, i32 0
  store i64 16, ptr %t816
  %t818 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } undef, %"compiler/source:Span" %t811, 0
  %t820 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } %t818, ptr %t812, 1
  %t822 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } %t820, { i64, ptr } %t814, 2
  %t823 = getelementptr { i64, [4 x i64] }, ptr %t815, i32 0, i32 1
  store { %"compiler/source:Span", ptr, { i64, ptr } } %t822, ptr %t823
  %t824 = load { i64, [4 x i64] }, ptr %t815
  %t826 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 40, i64 8)
  store { i64, [4 x i64] } %t824, ptr %t826
  %t828 = insertvalue { i32, ptr } zeroinitializer, ptr %t826, 1
  store { i32, ptr } %t828, ptr %rv
  br label %ret
bb186:
  %t829 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t831 = trunc i64 15 to i32
  %t832 = icmp eq i32 %t829, %t831
  br i1 %t832, label %bb187, label %bb188
bb187:
  br label %bb189
bb188:
  br label %bb238
bb189:
  %t834 = load ptr, ptr %l0, !tbaa !29
  %t836 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t834)
  store i32 %t836, ptr %l305
  br label %bb190
bb190:
  %t837 = load ptr, ptr %l0, !tbaa !29
  %t839 = getelementptr %"compiler/parse:Parser", ptr %t837, i32 0, i32 34
  %t841 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2eLen_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %t839)
  store i64 %t841, ptr %l308
  br label %bb191
bb191:
  %t842 = load i64, ptr %l308, !tbaa !24
  store i64 %t842, ptr %l24, !tbaa !24
  br label %bb192
bb192:
  %t843 = load ptr, ptr %l0, !tbaa !29
  %t845 = getelementptr %"compiler/parse:Parser", ptr %t843, i32 0, i32 34
  store ptr %t845, ptr %l310, !tbaa !29
  %t846 = load ptr, ptr %l0, !tbaa !29
  %t848 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexpr(ptr %v0, ptr %v0, ptr %t846)
  %t849 = extractvalue { i32, ptr } %t848, 1
  %t850 = extractvalue { i32, ptr } %t848, 0
  store i32 %t850, ptr %l314
  %t851 = icmp ne i32 %t850, 0
  br i1 %t851, label %bb194, label %ok.852, !prof !99
ok.852:
  store ptr %t849, ptr %l313
  br label %bb193
bb193:
  %t853 = load ptr, ptr %l313, !tbaa !29
  store ptr %t853, ptr %l311, !tbaa !29
  br label %bb195
bb194:
  %t854 = load i32, ptr %l314, !tbaa !23
  %t855 = lshr i32 %t854, 16
  %t856 = and i32 %t854, 65535
  %t857 = icmp eq i32 %t855, 1
  %t858 = select i1 %t857, i32 1, i32 0
  %t859 = icmp eq i32 %t854, 0
  %t860 = shl i32 %t858, 16
  %t861 = or i32 %t860, %t856
  %t862 = select i1 %t859, i32 0, i32 %t861
  %t864 = insertvalue { i32, ptr } zeroinitializer, i32 %t862, 0
  store { i32, ptr } %t864, ptr %rv
  br label %ret
bb195:
  %t865 = load ptr, ptr %l310, !tbaa !29
  %t866 = load ptr, ptr %l311, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2ePush_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t865, ptr %t866)
  br label %bb196
bb196:
  %t867 = load ptr, ptr %l0, !tbaa !29
  %t870 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t867, i32 75)
  store i1 %t870, ptr %l318
  br label %bb197
bb197:
  %t871 = load i1, ptr %l318, !tbaa !21
  %t872 = xor i1 %t871, true
  br i1 %t872, label %bb198, label %bb199
bb198:
  br label %bb202
bb199:
  br label %bb200
bb200:
  br label %bb201
bb201:
  br label %bb192
bb202:
  %t874 = load ptr, ptr %l0, !tbaa !29
  %t877 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t874, i32 78)
  store i1 %t877, ptr %l322
  br label %bb203
bb203:
  %t878 = load i1, ptr %l322, !tbaa !21
  br i1 %t878, label %bb204, label %bb205
bb204:
  %t879 = load ptr, ptr %l0, !tbaa !29
  %t881 = getelementptr %"compiler/parse:Parser", ptr %t879, i32 0, i32 34
  %t882 = load i64, ptr %l24, !tbaa !24
  %t885 = call { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %t881, i64 %t882)
  store { i64, ptr } %t885, ptr %l326
  br label %bb206
bb205:
  br label %bb218
bb206:
  %t886 = load { i64, ptr }, ptr %l326, !tbaa !27
  store { i64, ptr } %t886, ptr %l25, !tbaa !27
  %t887 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t889 = extractvalue { i64, ptr } %t887, 0
  %t891 = icmp sgt i64 %t889, 1
  br i1 %t891, label %bb207, label %bb208
bb207:
  %t893 = load ptr, ptr %l0, !tbaa !29
  store ptr %t893, ptr %l330, !tbaa !29
  %t894 = load ptr, ptr %l0, !tbaa !29
  %t896 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ehere(ptr %v0, ptr %t894)
  store i32 %t896, ptr %l332
  br label %bb209
bb208:
  br label %bb210
bb209:
  %t897 = load i32, ptr %l332, !tbaa !23
  %t898 = load ptr, ptr %l330, !tbaa !29
  %t899 = getelementptr %"compiler/parse:Parser", ptr %t898, i32 0, i32 28
  store i32 %t897, ptr %t899, !tbaa !23
  br label %bb210
bb210:
  %t900 = load ptr, ptr %l0, !tbaa !29
  %t902 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexpr(ptr %v0, ptr %v1, ptr %t900)
  %t903 = extractvalue { i32, ptr } %t902, 1
  %t904 = extractvalue { i32, ptr } %t902, 0
  store i32 %t904, ptr %l336
  %t905 = icmp ne i32 %t904, 0
  br i1 %t905, label %bb212, label %ok.906, !prof !99
ok.906:
  store ptr %t903, ptr %l335
  br label %bb211
bb211:
  %t907 = load ptr, ptr %l335, !tbaa !29
  store ptr %t907, ptr %l333, !tbaa !29
  br label %bb213
bb212:
  %t908 = load i32, ptr %l336, !tbaa !23
  %t909 = lshr i32 %t908, 16
  %t910 = and i32 %t908, 65535
  %t911 = icmp eq i32 %t909, 1
  %t912 = select i1 %t911, i32 1, i32 0
  %t913 = icmp eq i32 %t908, 0
  %t914 = shl i32 %t912, 16
  %t915 = or i32 %t914, %t910
  %t916 = select i1 %t913, i32 0, i32 %t915
  %t918 = insertvalue { i32, ptr } zeroinitializer, i32 %t916, 0
  store { i32, ptr } %t918, ptr %rv
  br label %ret
bb213:
  %t919 = load ptr, ptr %l333, !tbaa !29
  store ptr %t919, ptr %l26, !tbaa !29
  %t920 = load ptr, ptr %l0, !tbaa !29
  %t921 = load i32, ptr %l1, !tbaa !23
  %t924 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t920, i32 %t921)
  store %"compiler/source:Span" %t924, ptr %l340
  br label %bb214
bb214:
  %t925 = load %"compiler/source:Span", ptr %l340
  store %"compiler/source:Span" %t925, ptr %l27
  %t926 = load ptr, ptr %l0, !tbaa !29
  %t928 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eendStmt(ptr %v0, ptr %t926)
  store i32 %t928, ptr %l342
  %t929 = icmp ne i32 %t928, 0
  br i1 %t929, label %bb216, label %ok.930, !prof !99
ok.930:
  br label %bb215
bb215:
  br label %bb217
bb216:
  %t931 = load i32, ptr %l342, !tbaa !23
  %t932 = lshr i32 %t931, 16
  %t933 = and i32 %t931, 65535
  %t934 = icmp eq i32 %t932, 1
  %t935 = select i1 %t934, i32 1, i32 0
  %t936 = icmp eq i32 %t931, 0
  %t937 = shl i32 %t935, 16
  %t938 = or i32 %t937, %t933
  %t939 = select i1 %t936, i32 0, i32 %t938
  %t941 = insertvalue { i32, ptr } zeroinitializer, i32 %t939, 0
  store { i32, ptr } %t941, ptr %rv
  br label %ret
bb217:
  %t942 = load %"compiler/source:Span", ptr %l27
  %t943 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t944 = load ptr, ptr %l26, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t945
  %t946 = getelementptr { i64, [4 x i64] }, ptr %t945, i32 0, i32 0
  store i64 17, ptr %t946
  %t948 = insertvalue { %"compiler/source:Span", { i64, ptr }, ptr } undef, %"compiler/source:Span" %t942, 0
  %t950 = insertvalue { %"compiler/source:Span", { i64, ptr }, ptr } %t948, { i64, ptr } %t943, 1
  %t952 = insertvalue { %"compiler/source:Span", { i64, ptr }, ptr } %t950, ptr %t944, 2
  %t953 = getelementptr { i64, [4 x i64] }, ptr %t945, i32 0, i32 1
  store { %"compiler/source:Span", { i64, ptr }, ptr } %t952, ptr %t953
  %t954 = load { i64, [4 x i64] }, ptr %t945
  %t956 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 40, i64 8)
  store { i64, [4 x i64] } %t954, ptr %t956
  %t958 = insertvalue { i32, ptr } zeroinitializer, ptr %t956, 1
  store { i32, ptr } %t958, ptr %rv
  br label %ret
bb218:
  %t959 = load ptr, ptr %l0, !tbaa !29
  %t961 = getelementptr %"compiler/parse:Parser", ptr %t959, i32 0, i32 34
  %t963 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2eLen_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %t961)
  store i64 %t963, ptr %l351
  br label %bb219
bb219:
  %t964 = load i64, ptr %l24, !tbaa !24
  %t965 = load i64, ptr %l351, !tbaa !24
  %t967 = sub i64 %t965, %t964
  %t969 = icmp ne i64 %t967, 1
  br i1 %t969, label %bb220, label %bb221
bb220:
  store %olang.scope zeroinitializer, ptr %s25
  %t971 = load ptr, ptr %l0, !tbaa !29
  %t973 = getelementptr %"compiler/parse:Parser", ptr %t971, i32 0, i32 34
  %t974 = load i64, ptr %l24, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2eTruncate_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %t973, i64 %t974)
  br label %bb222
bb221:
  br label %bb227
bb222:
  %t977 = load ptr, ptr %l0, !tbaa !29
  store ptr %t977, ptr %l358, !tbaa !29
  %t979 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eDescribe(ptr %s25, i32 78)
  store { i64, ptr } %t979, ptr %l360
  br label %bb223
bb223:
  %t980 = load { i64, ptr }, ptr %l360, !tbaa !27
  %t981 = load ptr, ptr %l358, !tbaa !29
  %t983 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2efail(ptr %v0, ptr %s25, ptr %t981, { i64, ptr } %t980)
  store i32 %t983, ptr %l362
  %t984 = icmp ne i32 %t983, 0
  br i1 %t984, label %bb225, label %ok.985, !prof !99
ok.985:
  br label %bb224
bb224:
  br label %bb226
bb225:
  %t986 = load i32, ptr %l362, !tbaa !23
  %t987 = lshr i32 %t986, 16
  %t988 = and i32 %t986, 65535
  %t989 = icmp eq i32 %t987, 1
  %t990 = select i1 %t989, i32 1, i32 0
  %t991 = icmp eq i32 %t986, 0
  %t992 = shl i32 %t990, 16
  %t993 = or i32 %t992, %t988
  %t994 = select i1 %t991, i32 0, i32 %t993
  call void @__olang_scope_close(ptr %s25)
  %t996 = insertvalue { i32, ptr } zeroinitializer, i32 %t994, 0
  store { i32, ptr } %t996, ptr %rv
  br label %ret
bb226:
  call void @__olang_scope_close(ptr %s25)
  br label %bb227
bb227:
  %t997 = load ptr, ptr %l0, !tbaa !29
  %t999 = getelementptr %"compiler/parse:Parser", ptr %t997, i32 0, i32 34
  %t1000 = load i64, ptr %l24, !tbaa !24
  %t1003 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2eAt_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %t999, i64 %t1000)
  store ptr %t1003, ptr %l367
  br label %bb228
bb228:
  %t1004 = load ptr, ptr %l367, !tbaa !29
  store ptr %t1004, ptr %l28, !tbaa !29
  %t1005 = load ptr, ptr %l0, !tbaa !29
  %t1007 = getelementptr %"compiler/parse:Parser", ptr %t1005, i32 0, i32 34
  %t1008 = load i64, ptr %l24, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2eTruncate_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %t1007, i64 %t1008)
  br label %bb229
bb229:
  %t1011 = load ptr, ptr %l0, !tbaa !29
  %t1012 = load i32, ptr %l1, !tbaa !23
  %t1015 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t1011, i32 %t1012)
  store %"compiler/source:Span" %t1015, ptr %l373
  br label %bb230
bb230:
  %t1016 = load %"compiler/source:Span", ptr %l373
  store %"compiler/source:Span" %t1016, ptr %l29
  %t1017 = load ptr, ptr %l0, !tbaa !29
  %t1019 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eendStmt(ptr %v0, ptr %t1017)
  store i32 %t1019, ptr %l375
  %t1020 = icmp ne i32 %t1019, 0
  br i1 %t1020, label %bb232, label %ok.1021, !prof !99
ok.1021:
  br label %bb231
bb231:
  br label %bb233
bb232:
  %t1022 = load i32, ptr %l375, !tbaa !23
  %t1023 = lshr i32 %t1022, 16
  %t1024 = and i32 %t1022, 65535
  %t1025 = icmp eq i32 %t1023, 1
  %t1026 = select i1 %t1025, i32 1, i32 0
  %t1027 = icmp eq i32 %t1022, 0
  %t1028 = shl i32 %t1026, 16
  %t1029 = or i32 %t1028, %t1024
  %t1030 = select i1 %t1027, i32 0, i32 %t1029
  %t1032 = insertvalue { i32, ptr } zeroinitializer, i32 %t1030, 0
  store { i32, ptr } %t1032, ptr %rv
  br label %ret
bb233:
  %t1033 = load %"compiler/source:Span", ptr %l29
  store %"compiler/source:Span" %t1033, ptr %l377
  %t1034 = icmp sge i64 0, 0
  br i1 %t1034, label %bb234, label %bb235
bb234:
  %t1036 = icmp sle i64 0, 1152921504606846975
  br i1 %t1036, label %bb236, label %bb237
bb235:
  call void @__olang_check_failed(ptr @olang_loc_52ee6a0603ddde11_c2fcf6abb1634cfd)
  unreachable
bb236:
  %t1038 = mul i64 0, 8
  %t1039 = insertvalue { i64, ptr } undef, i64 0, 0
  %t1040 = insertvalue { i64, ptr } %t1039, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t1041 = load ptr, ptr %l28, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t1042
  %t1043 = getelementptr { i64, [4 x i64] }, ptr %t1042, i32 0, i32 0
  store i64 17, ptr %t1043
  %t1044 = load %"compiler/source:Span", ptr %l377
  %t1045 = insertvalue { %"compiler/source:Span", { i64, ptr }, ptr } undef, %"compiler/source:Span" %t1044, 0
  %t1047 = insertvalue { %"compiler/source:Span", { i64, ptr }, ptr } %t1045, { i64, ptr } %t1040, 1
  %t1049 = insertvalue { %"compiler/source:Span", { i64, ptr }, ptr } %t1047, ptr %t1041, 2
  %t1050 = getelementptr { i64, [4 x i64] }, ptr %t1042, i32 0, i32 1
  store { %"compiler/source:Span", { i64, ptr }, ptr } %t1049, ptr %t1050
  %t1051 = load { i64, [4 x i64] }, ptr %t1042
  %t1053 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 40, i64 8)
  store { i64, [4 x i64] } %t1051, ptr %t1053
  %t1055 = insertvalue { i32, ptr } zeroinitializer, ptr %t1053, 1
  store { i32, ptr } %t1055, ptr %rv
  br label %ret
bb237:
  call void @__olang_check_failed(ptr @olang_loc_52ee6a0603ddde11_c2fcf6abb1634cfd)
  unreachable
bb238:
  %t1056 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t1058 = trunc i64 14 to i32
  %t1059 = icmp eq i32 %t1056, %t1058
  br i1 %t1059, label %bb239, label %bb240
bb239:
  br label %bb241
bb240:
  br label %bb246
bb241:
  %t1061 = load ptr, ptr %l0, !tbaa !29
  %t1063 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ejoinRest(ptr %v0, ptr %v1, ptr %t1061, i1 false)
  %t1064 = extractvalue { i32, ptr } %t1063, 1
  %t1065 = extractvalue { i32, ptr } %t1063, 0
  store i32 %t1065, ptr %l389
  %t1066 = icmp ne i32 %t1065, 0
  br i1 %t1066, label %bb243, label %ok.1067, !prof !99
ok.1067:
  store ptr %t1064, ptr %l388
  br label %bb242
bb242:
  %t1068 = load ptr, ptr %l388, !tbaa !29
  store ptr %t1068, ptr %l386, !tbaa !29
  br label %bb244
bb243:
  %t1069 = load i32, ptr %l389, !tbaa !23
  %t1070 = lshr i32 %t1069, 16
  %t1071 = and i32 %t1069, 65535
  %t1072 = icmp eq i32 %t1070, 1
  %t1073 = select i1 %t1072, i32 1, i32 0
  %t1074 = icmp eq i32 %t1069, 0
  %t1075 = shl i32 %t1073, 16
  %t1076 = or i32 %t1075, %t1071
  %t1077 = select i1 %t1074, i32 0, i32 %t1076
  %t1079 = insertvalue { i32, ptr } zeroinitializer, i32 %t1077, 0
  store { i32, ptr } %t1079, ptr %rv
  br label %ret
bb244:
  %t1080 = load ptr, ptr %l386, !tbaa !29
  store ptr %t1080, ptr %l30, !tbaa !29
  %t1081 = load ptr, ptr %l0, !tbaa !29
  %t1082 = load i32, ptr %l1, !tbaa !23
  %t1085 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t1081, i32 %t1082)
  store %"compiler/source:Span" %t1085, ptr %l393
  br label %bb245
bb245:
  %t1086 = load ptr, ptr %l30, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t1087
  %t1088 = getelementptr { i64, [4 x i64] }, ptr %t1087, i32 0, i32 0
  store i64 18, ptr %t1088
  %t1089 = load %"compiler/source:Span", ptr %l393
  %t1090 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t1089, 0
  %t1092 = insertvalue { %"compiler/source:Span", ptr } %t1090, ptr %t1086, 1
  %t1093 = getelementptr { i64, [4 x i64] }, ptr %t1087, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t1092, ptr %t1093
  %t1094 = load { i64, [4 x i64] }, ptr %t1087
  %t1096 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 40, i64 8)
  store { i64, [4 x i64] } %t1094, ptr %t1096
  %t1098 = insertvalue { i32, ptr } zeroinitializer, ptr %t1096, 1
  store { i32, ptr } %t1098, ptr %rv
  br label %ret
bb246:
  %t1099 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t1101 = trunc i64 16 to i32
  %t1102 = icmp eq i32 %t1099, %t1101
  br i1 %t1102, label %bb247, label %bb248
bb247:
  br label %bb251
bb248:
  %t1104 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t1106 = trunc i64 17 to i32
  %t1107 = icmp eq i32 %t1104, %t1106
  br i1 %t1107, label %bb249, label %bb250
bb249:
  br label %bb251
bb250:
  br label %bb282
bb251:
  store %olang.scope zeroinitializer, ptr %s27
  %t1109 = load ptr, ptr %l0, !tbaa !29
  %t1112 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t1109, i32 17)
  store i1 %t1112, ptr %l403
  br label %bb252
bb252:
  %t1113 = load i1, ptr %l403, !tbaa !21
  store i1 %t1113, ptr %l31, !tbaa !21
  %t1114 = load ptr, ptr %l0, !tbaa !29
  %t1116 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t1114)
  store i32 %t1116, ptr %l405
  br label %bb253
bb253:
  %t1117 = load ptr, ptr %l0, !tbaa !29
  %t1120 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t1117, i32 114)
  store i1 %t1120, ptr %l408
  br label %bb254
bb254:
  %t1121 = load i1, ptr %l408, !tbaa !21
  br i1 %t1121, label %bb255, label %bb256
bb255:
  %t1122 = load ptr, ptr %l0, !tbaa !29
  %t1124 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eblock(ptr %v0, ptr %v1, ptr %t1122)
  %t1125 = extractvalue { i32, { i64, ptr } } %t1124, 1
  %t1126 = extractvalue { i32, { i64, ptr } } %t1124, 0
  store i32 %t1126, ptr %l412
  %t1127 = icmp ne i32 %t1126, 0
  br i1 %t1127, label %bb258, label %ok.1128, !prof !99
ok.1128:
  store { i64, ptr } %t1125, ptr %l411
  br label %bb257
bb256:
  br label %bb266
bb257:
  %t1129 = load { i64, ptr }, ptr %l411, !tbaa !27
  store { i64, ptr } %t1129, ptr %l409, !tbaa !27
  br label %bb259
bb258:
  %t1130 = load i32, ptr %l412, !tbaa !23
  %t1131 = lshr i32 %t1130, 16
  %t1132 = and i32 %t1130, 65535
  %t1133 = icmp eq i32 %t1131, 1
  %t1134 = select i1 %t1133, i32 1, i32 0
  %t1135 = icmp eq i32 %t1130, 0
  %t1136 = shl i32 %t1134, 16
  %t1137 = or i32 %t1136, %t1132
  %t1138 = select i1 %t1135, i32 0, i32 %t1137
  call void @__olang_scope_close(ptr %s27)
  %t1140 = insertvalue { i32, ptr } zeroinitializer, i32 %t1138, 0
  store { i32, ptr } %t1140, ptr %rv
  br label %ret
bb259:
  %t1141 = load { i64, ptr }, ptr %l409, !tbaa !27
  store { i64, ptr } %t1141, ptr %l32, !tbaa !27
  %t1142 = load ptr, ptr %l0, !tbaa !29
  %t1143 = load i32, ptr %l1, !tbaa !23
  %t1146 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t1142, i32 %t1143)
  store %"compiler/source:Span" %t1146, ptr %l416
  br label %bb260
bb260:
  %t1147 = load %"compiler/source:Span", ptr %l416
  store %"compiler/source:Span" %t1147, ptr %l33
  %t1148 = load ptr, ptr %l0, !tbaa !29
  %t1151 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t1148, i32 8)
  store i1 %t1151, ptr %l419
  br label %bb261
bb261:
  %t1152 = load i1, ptr %l419, !tbaa !21
  br i1 %t1152, label %bb262, label %bb263
bb262:
  %t1153 = load ptr, ptr %l0, !tbaa !29
  %t1155 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t1153)
  store i32 %t1155, ptr %l421
  br label %bb264
bb263:
  br label %bb265
bb264:
  br label %bb265
bb265:
  %t1156 = load %"compiler/source:Span", ptr %l33
  %t1157 = load %"compiler/source:Span", ptr %l33
  %t1158 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, [4 x i64] } zeroinitializer, ptr %t1159
  %t1160 = getelementptr { i64, [4 x i64] }, ptr %t1159, i32 0, i32 0
  store i64 20, ptr %t1160
  %t1162 = insertvalue { %"compiler/source:Span", { i64, ptr } } undef, %"compiler/source:Span" %t1157, 0
  %t1164 = insertvalue { %"compiler/source:Span", { i64, ptr } } %t1162, { i64, ptr } %t1158, 1
  %t1165 = getelementptr { i64, [4 x i64] }, ptr %t1159, i32 0, i32 1
  store { %"compiler/source:Span", { i64, ptr } } %t1164, ptr %t1165
  %t1166 = load { i64, [4 x i64] }, ptr %t1159
  %t1168 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 40, i64 8)
  store { i64, [4 x i64] } %t1166, ptr %t1168
  %t1169 = load i1, ptr %l31, !tbaa !21
  store { i64, [4 x i64] } zeroinitializer, ptr %t1170
  %t1171 = getelementptr { i64, [4 x i64] }, ptr %t1170, i32 0, i32 0
  store i64 19, ptr %t1171
  %t1173 = insertvalue { %"compiler/source:Span", ptr, i1 } undef, %"compiler/source:Span" %t1156, 0
  %t1175 = insertvalue { %"compiler/source:Span", ptr, i1 } %t1173, ptr %t1168, 1
  %t1177 = insertvalue { %"compiler/source:Span", ptr, i1 } %t1175, i1 %t1169, 2
  %t1178 = getelementptr { i64, [4 x i64] }, ptr %t1170, i32 0, i32 1
  store { %"compiler/source:Span", ptr, i1 } %t1177, ptr %t1178
  %t1179 = load { i64, [4 x i64] }, ptr %t1170
  %t1181 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 40, i64 8)
  store { i64, [4 x i64] } %t1179, ptr %t1181
  call void @__olang_scope_close(ptr %s27)
  %t1183 = insertvalue { i32, ptr } zeroinitializer, ptr %t1181, 1
  store { i32, ptr } %t1183, ptr %rv
  br label %ret
bb266:
  %t1184 = load ptr, ptr %l0, !tbaa !29
  %t1187 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t1184, i32 79)
  store i1 %t1187, ptr %l432
  br label %bb267
bb267:
  %t1188 = load i1, ptr %l432, !tbaa !21
  br i1 %t1188, label %bb268, label %bb269
bb268:
  %t1189 = load ptr, ptr %l0, !tbaa !29
  %t1191 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2elineBody(ptr %v0, ptr %v1, ptr %t1189, i1 false)
  %t1192 = extractvalue { i32, { i64, ptr } } %t1191, 1
  %t1193 = extractvalue { i32, { i64, ptr } } %t1191, 0
  store i32 %t1193, ptr %l436
  %t1194 = icmp ne i32 %t1193, 0
  br i1 %t1194, label %bb271, label %ok.1195, !prof !99
ok.1195:
  store { i64, ptr } %t1192, ptr %l435
  br label %bb270
bb269:
  br label %bb274
bb270:
  %t1196 = load { i64, ptr }, ptr %l435, !tbaa !27
  store { i64, ptr } %t1196, ptr %l433, !tbaa !27
  br label %bb272
bb271:
  %t1197 = load i32, ptr %l436, !tbaa !23
  %t1198 = lshr i32 %t1197, 16
  %t1199 = and i32 %t1197, 65535
  %t1200 = icmp eq i32 %t1198, 1
  %t1201 = select i1 %t1200, i32 1, i32 0
  %t1202 = icmp eq i32 %t1197, 0
  %t1203 = shl i32 %t1201, 16
  %t1204 = or i32 %t1203, %t1199
  %t1205 = select i1 %t1202, i32 0, i32 %t1204
  call void @__olang_scope_close(ptr %s27)
  %t1207 = insertvalue { i32, ptr } zeroinitializer, i32 %t1205, 0
  store { i32, ptr } %t1207, ptr %rv
  br label %ret
bb272:
  %t1208 = load { i64, ptr }, ptr %l433, !tbaa !27
  store { i64, ptr } %t1208, ptr %l34, !tbaa !27
  %t1209 = load ptr, ptr %l0, !tbaa !29
  %t1210 = load i32, ptr %l1, !tbaa !23
  %t1213 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t1209, i32 %t1210)
  store %"compiler/source:Span" %t1213, ptr %l440
  br label %bb273
bb273:
  %t1214 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t1214, ptr %l441, !tbaa !27
  %t1215 = getelementptr { i64, ptr }, ptr %l441, i32 0, i32 1
  %t1216 = load ptr, ptr %t1215, !tbaa !27
  %t1217 = getelementptr ptr, ptr %t1216, i64 0
  %t1218 = load ptr, ptr %t1217, !tbaa !39
  %t1219 = load i1, ptr %l31, !tbaa !21
  store { i64, [4 x i64] } zeroinitializer, ptr %t1220
  %t1221 = getelementptr { i64, [4 x i64] }, ptr %t1220, i32 0, i32 0
  store i64 19, ptr %t1221
  %t1222 = load %"compiler/source:Span", ptr %l440
  %t1223 = insertvalue { %"compiler/source:Span", ptr, i1 } undef, %"compiler/source:Span" %t1222, 0
  %t1225 = insertvalue { %"compiler/source:Span", ptr, i1 } %t1223, ptr %t1218, 1
  %t1227 = insertvalue { %"compiler/source:Span", ptr, i1 } %t1225, i1 %t1219, 2
  %t1228 = getelementptr { i64, [4 x i64] }, ptr %t1220, i32 0, i32 1
  store { %"compiler/source:Span", ptr, i1 } %t1227, ptr %t1228
  %t1229 = load { i64, [4 x i64] }, ptr %t1220
  %t1231 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 40, i64 8)
  store { i64, [4 x i64] } %t1229, ptr %t1231
  call void @__olang_scope_close(ptr %s27)
  %t1233 = insertvalue { i32, ptr } zeroinitializer, ptr %t1231, 1
  store { i32, ptr } %t1233, ptr %rv
  br label %ret
bb274:
  %t1234 = load ptr, ptr %l0, !tbaa !29
  %t1236 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2etk(ptr %v0, ptr %t1234)
  store %"compiler/token:Token" %t1236, ptr %l447
  br label %bb275
bb275:
  %t1237 = load %"compiler/token:Token", ptr %l447
  store %"compiler/token:Token" %t1237, ptr %l35
  %t1238 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1238, ptr %l448, !tbaa !29
  %t1239 = load ptr, ptr %l0, !tbaa !29
  %t1241 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ehere(ptr %v0, ptr %t1239)
  store i32 %t1241, ptr %l450
  br label %bb276
bb276:
  %t1242 = getelementptr %"compiler/token:Token", ptr %l35, i32 0, i32 3
  %t1243 = load i32, ptr %t1242, !tbaa !23
  store i32 %t1243, ptr %l451, !tbaa !23
  %t1244 = load i1, ptr %l31, !tbaa !21
  br i1 %t1244, label %bb277, label %bb278
bb277:
  store { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d20, i32 0, i32 1) }, ptr %l453, !tbaa !27
  br label %bb279
bb278:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d21, i32 0, i32 1) }, ptr %l453, !tbaa !27
  br label %bb279
bb279:
  %t1246 = load { i64, ptr }, ptr %l453, !tbaa !27
  %t1247 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eBareDefer(ptr %s27, ptr %v0, { i64, ptr } %t1246)
  store %"compiler/diagmsg:Msg" %t1247, ptr %l454
  br label %bb280
bb280:
  %t1248 = load ptr, ptr %l448, !tbaa !29
  %t1249 = load i32, ptr %l450, !tbaa !23
  %t1250 = load i32, ptr %l451, !tbaa !23
  %t1251 = load %"compiler/diagmsg:Msg", ptr %l454
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereport(ptr %v0, ptr %v0, ptr %t1248, i32 %t1249, i32 %t1250, %"compiler/diagmsg:Msg" %t1251)
  br label %bb281
bb281:
  call void @__olang_scope_close(ptr %s27)
  %t1253 = insertvalue { i32, ptr } zeroinitializer, i32 65536, 0
  store { i32, ptr } %t1253, ptr %rv
  br label %ret
bb282:
  %t1254 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t1256 = trunc i64 114 to i32
  %t1257 = icmp eq i32 %t1254, %t1256
  br i1 %t1257, label %bb283, label %bb284
bb283:
  br label %bb285
bb284:
  br label %bb295
bb285:
  %t1259 = load ptr, ptr %l0, !tbaa !29
  %t1261 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eblock(ptr %v0, ptr %v1, ptr %t1259)
  %t1262 = extractvalue { i32, { i64, ptr } } %t1261, 1
  %t1263 = extractvalue { i32, { i64, ptr } } %t1261, 0
  store i32 %t1263, ptr %l461
  %t1264 = icmp ne i32 %t1263, 0
  br i1 %t1264, label %bb287, label %ok.1265, !prof !99
ok.1265:
  store { i64, ptr } %t1262, ptr %l460
  br label %bb286
bb286:
  %t1266 = load { i64, ptr }, ptr %l460, !tbaa !27
  store { i64, ptr } %t1266, ptr %l458, !tbaa !27
  br label %bb288
bb287:
  %t1267 = load i32, ptr %l461, !tbaa !23
  %t1268 = lshr i32 %t1267, 16
  %t1269 = and i32 %t1267, 65535
  %t1270 = icmp eq i32 %t1268, 1
  %t1271 = select i1 %t1270, i32 1, i32 0
  %t1272 = icmp eq i32 %t1267, 0
  %t1273 = shl i32 %t1271, 16
  %t1274 = or i32 %t1273, %t1269
  %t1275 = select i1 %t1272, i32 0, i32 %t1274
  %t1277 = insertvalue { i32, ptr } zeroinitializer, i32 %t1275, 0
  store { i32, ptr } %t1277, ptr %rv
  br label %ret
bb288:
  %t1278 = load { i64, ptr }, ptr %l458, !tbaa !27
  store { i64, ptr } %t1278, ptr %l36, !tbaa !27
  %t1279 = load ptr, ptr %l0, !tbaa !29
  %t1280 = load i32, ptr %l1, !tbaa !23
  %t1283 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t1279, i32 %t1280)
  store %"compiler/source:Span" %t1283, ptr %l465
  br label %bb289
bb289:
  %t1284 = load %"compiler/source:Span", ptr %l465
  store %"compiler/source:Span" %t1284, ptr %l37
  %t1285 = load ptr, ptr %l0, !tbaa !29
  %t1288 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t1285, i32 8)
  store i1 %t1288, ptr %l468
  br label %bb290
bb290:
  %t1289 = load i1, ptr %l468, !tbaa !21
  br i1 %t1289, label %bb291, label %bb292
bb291:
  %t1290 = load ptr, ptr %l0, !tbaa !29
  %t1292 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t1290)
  store i32 %t1292, ptr %l470
  br label %bb293
bb292:
  br label %bb294
bb293:
  br label %bb294
bb294:
  %t1293 = load %"compiler/source:Span", ptr %l37
  %t1294 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, [4 x i64] } zeroinitializer, ptr %t1295
  %t1296 = getelementptr { i64, [4 x i64] }, ptr %t1295, i32 0, i32 0
  store i64 20, ptr %t1296
  %t1298 = insertvalue { %"compiler/source:Span", { i64, ptr } } undef, %"compiler/source:Span" %t1293, 0
  %t1300 = insertvalue { %"compiler/source:Span", { i64, ptr } } %t1298, { i64, ptr } %t1294, 1
  %t1301 = getelementptr { i64, [4 x i64] }, ptr %t1295, i32 0, i32 1
  store { %"compiler/source:Span", { i64, ptr } } %t1300, ptr %t1301
  %t1302 = load { i64, [4 x i64] }, ptr %t1295
  %t1304 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 40, i64 8)
  store { i64, [4 x i64] } %t1302, ptr %t1304
  %t1306 = insertvalue { i32, ptr } zeroinitializer, ptr %t1304, 1
  store { i32, ptr } %t1306, ptr %rv
  br label %ret
bb295:
  %t1307 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t1309 = trunc i64 11 to i32
  %t1310 = icmp eq i32 %t1307, %t1309
  br i1 %t1310, label %bb296, label %bb297
bb296:
  br label %bb298
bb297:
  br label %bb302
bb298:
  %t1312 = load ptr, ptr %l0, !tbaa !29
  %t1314 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etryStmt(ptr %v0, ptr %v1, ptr %t1312)
  %t1315 = extractvalue { i32, ptr } %t1314, 1
  %t1316 = extractvalue { i32, ptr } %t1314, 0
  store i32 %t1316, ptr %l480
  %t1317 = icmp ne i32 %t1316, 0
  br i1 %t1317, label %bb300, label %ok.1318, !prof !99
ok.1318:
  store ptr %t1315, ptr %l479
  br label %bb299
bb299:
  %t1319 = load ptr, ptr %l479, !tbaa !29
  store ptr %t1319, ptr %l477, !tbaa !29
  br label %bb301
bb300:
  %t1320 = load i32, ptr %l480, !tbaa !23
  %t1321 = lshr i32 %t1320, 16
  %t1322 = and i32 %t1320, 65535
  %t1323 = icmp eq i32 %t1321, 1
  %t1324 = select i1 %t1323, i32 1, i32 0
  %t1325 = icmp eq i32 %t1320, 0
  %t1326 = shl i32 %t1324, 16
  %t1327 = or i32 %t1326, %t1322
  %t1328 = select i1 %t1325, i32 0, i32 %t1327
  %t1330 = insertvalue { i32, ptr } zeroinitializer, i32 %t1328, 0
  store { i32, ptr } %t1330, ptr %rv
  br label %ret
bb301:
  %t1331 = load ptr, ptr %l477, !tbaa !29
  %t1332 = insertvalue { i32, ptr } zeroinitializer, ptr %t1331, 1
  store { i32, ptr } %t1332, ptr %rv
  br label %ret
bb302:
  %t1333 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t1335 = trunc i64 1 to i32
  %t1336 = icmp eq i32 %t1333, %t1335
  br i1 %t1336, label %bb303, label %bb304
bb303:
  br label %bb305
bb304:
  br label %bb309
bb305:
  %t1338 = load ptr, ptr %l0, !tbaa !29
  %t1340 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eidenStmt(ptr %v0, ptr %v1, ptr %t1338)
  %t1341 = extractvalue { i32, ptr } %t1340, 1
  %t1342 = extractvalue { i32, ptr } %t1340, 0
  store i32 %t1342, ptr %l487
  %t1343 = icmp ne i32 %t1342, 0
  br i1 %t1343, label %bb307, label %ok.1344, !prof !99
ok.1344:
  store ptr %t1341, ptr %l486
  br label %bb306
bb306:
  %t1345 = load ptr, ptr %l486, !tbaa !29
  store ptr %t1345, ptr %l484, !tbaa !29
  br label %bb308
bb307:
  %t1346 = load i32, ptr %l487, !tbaa !23
  %t1347 = lshr i32 %t1346, 16
  %t1348 = and i32 %t1346, 65535
  %t1349 = icmp eq i32 %t1347, 1
  %t1350 = select i1 %t1349, i32 1, i32 0
  %t1351 = icmp eq i32 %t1346, 0
  %t1352 = shl i32 %t1350, 16
  %t1353 = or i32 %t1352, %t1348
  %t1354 = select i1 %t1351, i32 0, i32 %t1353
  %t1356 = insertvalue { i32, ptr } zeroinitializer, i32 %t1354, 0
  store { i32, ptr } %t1356, ptr %rv
  br label %ret
bb308:
  %t1357 = load ptr, ptr %l484, !tbaa !29
  %t1358 = insertvalue { i32, ptr } zeroinitializer, ptr %t1357, 1
  store { i32, ptr } %t1358, ptr %rv
  br label %ret
bb309:
  br i1 true, label %bb310, label %bb311
bb310:
  br label %bb312
bb311:
  br label %bb316
bb312:
  %t1359 = load ptr, ptr %l0, !tbaa !29
  %t1361 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexprStmt(ptr %v0, ptr %v1, ptr %t1359)
  %t1362 = extractvalue { i32, ptr } %t1361, 1
  %t1363 = extractvalue { i32, ptr } %t1361, 0
  store i32 %t1363, ptr %l492
  %t1364 = icmp ne i32 %t1363, 0
  br i1 %t1364, label %bb314, label %ok.1365, !prof !99
ok.1365:
  store ptr %t1362, ptr %l491
  br label %bb313
bb313:
  %t1366 = load ptr, ptr %l491, !tbaa !29
  store ptr %t1366, ptr %l489, !tbaa !29
  br label %bb315
bb314:
  %t1367 = load i32, ptr %l492, !tbaa !23
  %t1368 = lshr i32 %t1367, 16
  %t1369 = and i32 %t1367, 65535
  %t1370 = icmp eq i32 %t1368, 1
  %t1371 = select i1 %t1370, i32 1, i32 0
  %t1372 = icmp eq i32 %t1367, 0
  %t1373 = shl i32 %t1371, 16
  %t1374 = or i32 %t1373, %t1369
  %t1375 = select i1 %t1372, i32 0, i32 %t1374
  %t1377 = insertvalue { i32, ptr } zeroinitializer, i32 %t1375, 0
  store { i32, ptr } %t1377, ptr %rv
  br label %ret
bb315:
  %t1378 = load ptr, ptr %l489, !tbaa !29
  %t1379 = insertvalue { i32, ptr } zeroinitializer, ptr %t1378, 1
  store { i32, ptr } %t1379, ptr %rv
  br label %ret
bb316:
  call void @__olang_check_failed(ptr @olang_loc_98b5a7b541ba17c1_7be6170cba707005)
  unreachable
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local void @compiler_2fparse_2ecompiler_2fparse_3aParser_2estmtRoom(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/parse:Parser", ptr %t1, i32 0, i32 24
  %t4 = load i64, ptr %t3, !tbaa !24
  %t5 = load i64, ptr @G_2ecompiler_2fparse_2eMaxNesting, !tbaa !24
  %t8 = icmp sge i64 %t4, %t5
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/parse:Parser", ptr %t11, i32 0, i32 6
  %t14 = load i64, ptr %t13, !tbaa !24
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2etooDeepAt(ptr %v0, ptr %t10, i64 %t14)
  br label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb4
bb4:
  br label %ret
ret:
  ret void
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etopIf(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i32
  %l12 = alloca %"compiler/source:Span"
  %rv = alloca { i32, ptr }
  %t31 = alloca { i64, [8 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ehere(ptr %v0, ptr %t1)
  store i32 %t3, ptr %l4
  br label %bb1
bb1:
  %t4 = load i32, ptr %l4, !tbaa !23
  store i32 %t4, ptr %l1, !tbaa !23
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etopIfRest(ptr %v0, ptr %v1, ptr %t5)
  %t8 = extractvalue { i32, ptr } %t7, 1
  %t9 = extractvalue { i32, ptr } %t7, 0
  store i32 %t9, ptr %l8
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb3, label %ok.11, !prof !99
ok.11:
  store ptr %t8, ptr %l7
  br label %bb2
bb2:
  %t12 = load ptr, ptr %l7, !tbaa !29
  store ptr %t12, ptr %l5, !tbaa !29
  br label %bb4
bb3:
  %t13 = load i32, ptr %l8, !tbaa !23
  %t14 = lshr i32 %t13, 16
  %t15 = and i32 %t13, 65535
  %t16 = icmp eq i32 %t14, 1
  %t17 = select i1 %t16, i32 1, i32 0
  %t18 = icmp eq i32 %t13, 0
  %t19 = shl i32 %t17, 16
  %t20 = or i32 %t19, %t15
  %t21 = select i1 %t18, i32 0, i32 %t20
  %t23 = insertvalue { i32, ptr } zeroinitializer, i32 %t21, 0
  store { i32, ptr } %t23, ptr %rv
  br label %ret
bb4:
  %t24 = load ptr, ptr %l5, !tbaa !29
  store ptr %t24, ptr %l2, !tbaa !29
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t26 = load i32, ptr %l1, !tbaa !23
  %t29 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t25, i32 %t26)
  store %"compiler/source:Span" %t29, ptr %l12
  br label %bb5
bb5:
  %t30 = load ptr, ptr %l2, !tbaa !29
  store { i64, [8 x i64] } zeroinitializer, ptr %t31
  %t32 = getelementptr { i64, [8 x i64] }, ptr %t31, i32 0, i32 0
  store i64 8, ptr %t32
  %t33 = load %"compiler/source:Span", ptr %l12
  %t34 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t33, 0
  %t36 = insertvalue { %"compiler/source:Span", ptr } %t34, ptr %t30, 1
  %t37 = getelementptr { i64, [8 x i64] }, ptr %t31, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t36, ptr %t37
  %t38 = load { i64, [8 x i64] }, ptr %t31
  %t40 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 72, i64 8)
  store { i64, [8 x i64] } %t38, ptr %t40
  %t42 = insertvalue { i32, ptr } zeroinitializer, ptr %t40, 1
  store { i32, ptr } %t42, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etopIfRest(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l5 = alloca i32
  %l8 = alloca i32
  %l9 = alloca i32
  %l11 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca i32
  %l16 = alloca ptr
  %l18 = alloca ptr
  %l19 = alloca i32
  %l23 = alloca i1
  %l29 = alloca %"compiler/ast:TopIf"
  %l33 = alloca i1
  %l34 = alloca ptr
  %l36 = alloca ptr
  %l37 = alloca i32
  %l45 = alloca %"compiler/ast:TopIf"
  %l47 = alloca ptr
  %l49 = alloca ptr
  %l50 = alloca i32
  %l58 = alloca %"compiler/ast:TopIf"
  %rv = alloca { i32, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t4 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %t1, i32 9)
  %t5 = extractvalue { i32, i32 } %t4, 1
  %t6 = extractvalue { i32, i32 } %t4, 0
  store i32 %t6, ptr %l9
  %t7 = icmp ne i32 %t6, 0
  br i1 %t7, label %bb2, label %ok.8, !prof !99
ok.8:
  store i32 %t5, ptr %l8
  br label %bb1
bb1:
  %t9 = load i32, ptr %l8, !tbaa !23
  store i32 %t9, ptr %l5, !tbaa !23
  br label %bb3
bb2:
  %t10 = load i32, ptr %l9, !tbaa !23
  %t11 = lshr i32 %t10, 16
  %t12 = and i32 %t10, 65535
  %t13 = icmp eq i32 %t11, 1
  %t14 = select i1 %t13, i32 1, i32 0
  %t15 = icmp eq i32 %t10, 0
  %t16 = shl i32 %t14, 16
  %t17 = or i32 %t16, %t12
  %t18 = select i1 %t15, i32 0, i32 %t17
  %t20 = insertvalue { i32, ptr } zeroinitializer, i32 %t18, 0
  store { i32, ptr } %t20, ptr %rv
  br label %ret
bb3:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexpr(ptr %v0, ptr %v1, ptr %t21)
  %t24 = extractvalue { i32, ptr } %t23, 1
  %t25 = extractvalue { i32, ptr } %t23, 0
  store i32 %t25, ptr %l14
  %t26 = icmp ne i32 %t25, 0
  br i1 %t26, label %bb5, label %ok.27, !prof !99
ok.27:
  store ptr %t24, ptr %l13
  br label %bb4
bb4:
  %t28 = load ptr, ptr %l13, !tbaa !29
  store ptr %t28, ptr %l11, !tbaa !29
  br label %bb6
bb5:
  %t29 = load i32, ptr %l14, !tbaa !23
  %t30 = lshr i32 %t29, 16
  %t31 = and i32 %t29, 65535
  %t32 = icmp eq i32 %t30, 1
  %t33 = select i1 %t32, i32 1, i32 0
  %t34 = icmp eq i32 %t29, 0
  %t35 = shl i32 %t33, 16
  %t36 = or i32 %t35, %t31
  %t37 = select i1 %t34, i32 0, i32 %t36
  %t39 = insertvalue { i32, ptr } zeroinitializer, i32 %t37, 0
  store { i32, ptr } %t39, ptr %rv
  br label %ret
bb6:
  %t40 = load ptr, ptr %l11, !tbaa !29
  store ptr %t40, ptr %l1, !tbaa !29
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etopBranch(ptr %v0, ptr %v1, ptr %t41)
  %t44 = extractvalue { i32, ptr } %t43, 1
  %t45 = extractvalue { i32, ptr } %t43, 0
  store i32 %t45, ptr %l19
  %t46 = icmp ne i32 %t45, 0
  br i1 %t46, label %bb8, label %ok.47, !prof !99
ok.47:
  store ptr %t44, ptr %l18
  br label %bb7
bb7:
  %t48 = load ptr, ptr %l18, !tbaa !29
  store ptr %t48, ptr %l16, !tbaa !29
  br label %bb9
bb8:
  %t49 = load i32, ptr %l19, !tbaa !23
  %t50 = lshr i32 %t49, 16
  %t51 = and i32 %t49, 65535
  %t52 = icmp eq i32 %t50, 1
  %t53 = select i1 %t52, i32 1, i32 0
  %t54 = icmp eq i32 %t49, 0
  %t55 = shl i32 %t53, 16
  %t56 = or i32 %t55, %t51
  %t57 = select i1 %t54, i32 0, i32 %t56
  %t59 = insertvalue { i32, ptr } zeroinitializer, i32 %t57, 0
  store { i32, ptr } %t59, ptr %rv
  br label %ret
bb9:
  %t60 = load ptr, ptr %l16, !tbaa !29
  store ptr %t60, ptr %l2, !tbaa !29
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t64 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t61, i32 10)
  store i1 %t64, ptr %l23
  br label %bb10
bb10:
  %t65 = load i1, ptr %l23, !tbaa !21
  %t66 = xor i1 %t65, true
  br i1 %t66, label %bb11, label %bb12
bb11:
  %t68 = load ptr, ptr %l1, !tbaa !29
  %t70 = load ptr, ptr %l2, !tbaa !29
  %t74 = call %"compiler/ast:TopIf" @compiler_2fast_3aTopIf_2ector(ptr %v1, ptr %v1, ptr %v1, ptr %v1, ptr %v1, ptr %t68, ptr %t70, ptr null, ptr null)
  store %"compiler/ast:TopIf" %t74, ptr %l29
  br label %bb13
bb12:
  br label %bb14
bb13:
  %t75 = load %"compiler/ast:TopIf", ptr %l29
  %t76 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 32, i64 8)
  store %"compiler/ast:TopIf" %t75, ptr %t76
  %t78 = insertvalue { i32, ptr } zeroinitializer, ptr %t76, 1
  store { i32, ptr } %t78, ptr %rv
  br label %ret
bb14:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t82 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t79, i32 9)
  store i1 %t82, ptr %l33
  br label %bb15
bb15:
  %t83 = load i1, ptr %l33, !tbaa !21
  br i1 %t83, label %bb16, label %bb17
bb16:
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etopIfRest(ptr %v0, ptr %v1, ptr %t84)
  %t87 = extractvalue { i32, ptr } %t86, 1
  %t88 = extractvalue { i32, ptr } %t86, 0
  store i32 %t88, ptr %l37
  %t89 = icmp ne i32 %t88, 0
  br i1 %t89, label %bb19, label %ok.90, !prof !99
ok.90:
  store ptr %t87, ptr %l36
  br label %bb18
bb17:
  br label %bb22
bb18:
  %t91 = load ptr, ptr %l36, !tbaa !29
  store ptr %t91, ptr %l34, !tbaa !29
  br label %bb20
bb19:
  %t92 = load i32, ptr %l37, !tbaa !23
  %t93 = lshr i32 %t92, 16
  %t94 = and i32 %t92, 65535
  %t95 = icmp eq i32 %t93, 1
  %t96 = select i1 %t95, i32 1, i32 0
  %t97 = icmp eq i32 %t92, 0
  %t98 = shl i32 %t96, 16
  %t99 = or i32 %t98, %t94
  %t100 = select i1 %t97, i32 0, i32 %t99
  %t102 = insertvalue { i32, ptr } zeroinitializer, i32 %t100, 0
  store { i32, ptr } %t102, ptr %rv
  br label %ret
bb20:
  %t103 = load ptr, ptr %l34, !tbaa !29
  %t104 = load ptr, ptr %l1, !tbaa !29
  %t106 = load ptr, ptr %l2, !tbaa !29
  %t113 = call %"compiler/ast:TopIf" @compiler_2fast_3aTopIf_2ector(ptr %v1, ptr %v1, ptr %v1, ptr %v1, ptr %v1, ptr %t104, ptr %t106, ptr %t103, ptr null)
  store %"compiler/ast:TopIf" %t113, ptr %l45
  br label %bb21
bb21:
  %t114 = load %"compiler/ast:TopIf", ptr %l45
  %t115 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 32, i64 8)
  store %"compiler/ast:TopIf" %t114, ptr %t115
  %t117 = insertvalue { i32, ptr } zeroinitializer, ptr %t115, 1
  store { i32, ptr } %t117, ptr %rv
  br label %ret
bb22:
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t120 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etopBranch(ptr %v0, ptr %v1, ptr %t118)
  %t121 = extractvalue { i32, ptr } %t120, 1
  %t122 = extractvalue { i32, ptr } %t120, 0
  store i32 %t122, ptr %l50
  %t123 = icmp ne i32 %t122, 0
  br i1 %t123, label %bb24, label %ok.124, !prof !99
ok.124:
  store ptr %t121, ptr %l49
  br label %bb23
bb23:
  %t125 = load ptr, ptr %l49, !tbaa !29
  store ptr %t125, ptr %l47, !tbaa !29
  br label %bb25
bb24:
  %t126 = load i32, ptr %l50, !tbaa !23
  %t127 = lshr i32 %t126, 16
  %t128 = and i32 %t126, 65535
  %t129 = icmp eq i32 %t127, 1
  %t130 = select i1 %t129, i32 1, i32 0
  %t131 = icmp eq i32 %t126, 0
  %t132 = shl i32 %t130, 16
  %t133 = or i32 %t132, %t128
  %t134 = select i1 %t131, i32 0, i32 %t133
  %t136 = insertvalue { i32, ptr } zeroinitializer, i32 %t134, 0
  store { i32, ptr } %t136, ptr %rv
  br label %ret
bb25:
  %t137 = load ptr, ptr %l47, !tbaa !29
  %t138 = load ptr, ptr %l1, !tbaa !29
  %t140 = load ptr, ptr %l2, !tbaa !29
  %t147 = call %"compiler/ast:TopIf" @compiler_2fast_3aTopIf_2ector(ptr %v1, ptr %v1, ptr %v1, ptr %v1, ptr %v1, ptr %t138, ptr %t140, ptr null, ptr %t137)
  store %"compiler/ast:TopIf" %t147, ptr %l58
  br label %bb26
bb26:
  %t148 = load %"compiler/ast:TopIf", ptr %l58
  %t149 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 32, i64 8)
  store %"compiler/ast:TopIf" %t148, ptr %t149
  %t151 = insertvalue { i32, ptr } zeroinitializer, ptr %t149, 1
  store { i32, ptr } %t151, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local void @compiler_2fparse_2ecompiler_2fparse_3aParser_2etrailingDefaults(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca ptr
  %l14 = alloca { i64, ptr }
  %l22 = alloca ptr
  %l24 = alloca i32
  %l26 = alloca i32
  %l31 = alloca { i64, ptr }
  %l32 = alloca { i64, ptr }
  %l34 = alloca %"compiler/diagmsg:Msg"
  %s5 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i1 false, ptr %l2, !tbaa !21
  store { i64, ptr } %a1, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l5, !tbaa !24
  br label %bb1
bb1:
  %t7 = load i64, ptr %l4, !tbaa !24
  %t8 = load i64, ptr %l5, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  br label %bb16
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t15, ptr %l14, !tbaa !27
  %t16 = load i64, ptr %l4, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr ptr, ptr %t19, i64 %t16
  %t21 = load ptr, ptr %t20, !tbaa !39
  store ptr %t21, ptr %l6, !tbaa !29
  %t23 = load ptr, ptr %l6, !tbaa !29
  %t25 = getelementptr %"compiler/ast:Param", ptr %t23, i32 0, i32 3
  %t26 = load ptr, ptr %t25, !tbaa !29
  %t28 = icmp eq ptr %t26, null
  %t30 = xor i1 %t28, true
  br i1 %t30, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l2, !tbaa !21
  br label %bb14
bb6:
  %t32 = load i1, ptr %l2, !tbaa !21
  br i1 %t32, label %bb7, label %bb8
bb7:
  store %olang.scope zeroinitializer, ptr %s5
  %t34 = load ptr, ptr %l0, !tbaa !29
  store ptr %t34, ptr %l22, !tbaa !29
  %t35 = load ptr, ptr %l6, !tbaa !29
  %t37 = getelementptr %"compiler/ast:Param", ptr %t35, i32 0, i32 0
  %t38 = getelementptr %"compiler/source:Span", ptr %t37, i32 0, i32 0
  %t39 = load i32, ptr %t38, !tbaa !23
  store i32 %t39, ptr %l24, !tbaa !23
  %t40 = load ptr, ptr %l6, !tbaa !29
  %t42 = getelementptr %"compiler/ast:Param", ptr %t40, i32 0, i32 0
  %t43 = getelementptr %"compiler/source:Span", ptr %t42, i32 0, i32 1
  %t44 = load i32, ptr %t43, !tbaa !23
  store i32 %t44, ptr %l26, !tbaa !23
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/parse:Parser", ptr %t45, i32 0, i32 2
  %t48 = load ptr, ptr %t47, !tbaa !29
  %t49 = load ptr, ptr %l6, !tbaa !29
  %t51 = getelementptr %"compiler/ast:Param", ptr %t49, i32 0, i32 1
  %t52 = load i32, ptr %t51, !tbaa !23
  %t55 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %v0, ptr %t48, i32 %t52)
  store { i64, ptr } %t55, ptr %l31
  br label %bb9
bb8:
  br label %bb13
bb9:
  %t56 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t57 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %v0, ptr %s5, { i64, ptr } %t56)
  store { i64, ptr } %t57, ptr %l32
  br label %bb10
bb10:
  %t58 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t60 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eDefaultNotTrailing(ptr %s5, ptr %v0, { i64, ptr } %t58)
  store %"compiler/diagmsg:Msg" %t60, ptr %l34
  br label %bb11
bb11:
  %t61 = load ptr, ptr %l22, !tbaa !29
  %t62 = load i32, ptr %l24, !tbaa !23
  %t63 = load i32, ptr %l26, !tbaa !23
  %t64 = load %"compiler/diagmsg:Msg", ptr %l34
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereport(ptr %v0, ptr %v0, ptr %t61, i32 %t62, i32 %t63, %"compiler/diagmsg:Msg" %t64)
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s5)
  br label %ret
bb13:
  br label %bb14
bb14:
  br label %bb15
bb15:
  %t65 = load i64, ptr %l4, !tbaa !24
  %t68 = add i64 %t65, 1
  store i64 %t68, ptr %l4, !tbaa !24
  br label %bb1
bb16:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeArgsShape(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l3 = alloca i1
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i32
  %l10 = alloca i32
  %l14 = alloca i1
  %l22 = alloca i32
  %l28 = alloca %"compiler/token:Token"
  %l32 = alloca %"compiler/token:Token"
  %l44 = alloca i32
  %l76 = alloca i1
  %l80 = alloca i1
  %l84 = alloca i1
  %l88 = alloca i1
  %l92 = alloca i1
  %l96 = alloca i1
  %l100 = alloca i1
  %l104 = alloca i1
  %l108 = alloca i1
  %l120 = alloca i1
  %l124 = alloca i32
  %l130 = alloca i1
  %l133 = alloca %"compiler/token:Token"
  %l134 = alloca i32
  %l138 = alloca %"compiler/token:Token"
  %l145 = alloca i32
  %l148 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  %t5 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elook(ptr %v0, ptr %t1, i64 %t2)
  store i32 %t5, ptr %l10
  br label %bb1
bb1:
  %t6 = load i32, ptr %l10, !range !{i32 0, i32 116}
  %t8 = trunc i64 98 to i32
  %t9 = icmp eq i32 %t6, %t8
  %t11 = xor i1 %t9, true
  br i1 %t11, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l14, !tbaa !21
  br label %bb4
bb3:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/parse:Parser", ptr %t13, i32 0, i32 7
  %t16 = load i32, ptr %t15, !range !{i32 0, i32 116}
  %t18 = trunc i64 0 to i32
  %t19 = icmp eq i32 %t16, %t18
  %t21 = xor i1 %t19, true
  store i1 %t21, ptr %l14, !tbaa !21
  br label %bb4
bb4:
  %t23 = load i1, ptr %l14, !tbaa !21
  br i1 %t23, label %bb5, label %bb6
bb5:
  store i64 0, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t25 = load i64, ptr %l1, !tbaa !24
  %t27 = icmp eq i64 %t25, 0
  br i1 %t27, label %bb8, label %bb9
bb8:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/parse:Parser", ptr %t29, i32 0, i32 10
  %t32 = load i32, ptr %t31, !tbaa !23
  store i32 %t32, ptr %l22, !tbaa !23
  br label %bb11
bb9:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = load i64, ptr %l1, !tbaa !24
  %t37 = sub i64 %t35, 1
  %t40 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2elookTok(ptr %v0, ptr %t34, i64 %t37)
  store %"compiler/token:Token" %t40, ptr %l28
  br label %bb10
bb10:
  %t41 = getelementptr %"compiler/token:Token", ptr %l28, i32 0, i32 3
  %t42 = load i32, ptr %t41, !tbaa !23
  store i32 %t42, ptr %l22, !tbaa !23
  br label %bb11
bb11:
  %t44 = load i32, ptr %l22, !tbaa !23
  store i32 %t44, ptr %l2, !tbaa !23
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t46 = load i64, ptr %l1, !tbaa !24
  %t49 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2elookTok(ptr %v0, ptr %t45, i64 %t46)
  store %"compiler/token:Token" %t49, ptr %l32
  br label %bb12
bb12:
  %t50 = getelementptr %"compiler/token:Token", ptr %l32, i32 0, i32 2
  %t51 = load i32, ptr %t50, !tbaa !23
  %t52 = load i32, ptr %l2, !tbaa !23
  %t55 = icmp eq i32 %t51, %t52
  store i1 %t55, ptr %l3, !tbaa !21
  store i64 0, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  %t57 = load i64, ptr %l1, !tbaa !24
  store i64 %t57, ptr %l6, !tbaa !24
  br label %bb13
bb13:
  %t59 = load i64, ptr %l6, !tbaa !24
  %t60 = load i64, ptr %l1, !tbaa !24
  %t62 = add i64 %t60, 256
  %t65 = icmp slt i64 %t59, %t62
  %t67 = xor i1 %t65, true
  br i1 %t67, label %bb14, label %bb15
bb14:
  br label %bb92
bb15:
  br label %bb16
bb16:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t70 = load i64, ptr %l6, !tbaa !24
  %t73 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elook(ptr %v0, ptr %t69, i64 %t70)
  store i32 %t73, ptr %l44
  br label %bb17
bb17:
  %t74 = load i32, ptr %l44, !range !{i32 0, i32 116}
  store i32 %t74, ptr %l7
  %t75 = load i32, ptr %l7, !range !{i32 0, i32 116}
  %t77 = trunc i64 98 to i32
  %t78 = icmp eq i32 %t75, %t77
  br i1 %t78, label %bb18, label %bb19
bb18:
  %t80 = load i64, ptr %l4, !tbaa !24
  %t83 = add i64 %t80, 1
  store i64 %t83, ptr %l4, !tbaa !24
  br label %bb65
bb19:
  %t85 = load i32, ptr %l7, !range !{i32 0, i32 116}
  %t87 = trunc i64 100 to i32
  %t88 = icmp eq i32 %t85, %t87
  br i1 %t88, label %bb20, label %bb21
bb20:
  %t90 = load i64, ptr %l4, !tbaa !24
  %t93 = sub i64 %t90, 1
  store i64 %t93, ptr %l4, !tbaa !24
  br label %bb64
bb21:
  %t95 = load i32, ptr %l7, !range !{i32 0, i32 116}
  %t97 = trunc i64 109 to i32
  %t98 = icmp eq i32 %t95, %t97
  br i1 %t98, label %bb22, label %bb23
bb22:
  %t100 = load i64, ptr %l4, !tbaa !24
  %t103 = sub i64 %t100, 2
  store i64 %t103, ptr %l4, !tbaa !24
  br label %bb63
bb23:
  %t105 = load i32, ptr %l7, !range !{i32 0, i32 116}
  %t107 = trunc i64 110 to i32
  %t108 = icmp eq i32 %t105, %t107
  br i1 %t108, label %bb24, label %bb25
bb24:
  %t110 = load i64, ptr %l5, !tbaa !24
  %t113 = add i64 %t110, 1
  store i64 %t113, ptr %l5, !tbaa !24
  br label %bb62
bb25:
  %t115 = load i32, ptr %l7, !range !{i32 0, i32 116}
  %t117 = trunc i64 111 to i32
  %t118 = icmp eq i32 %t115, %t117
  br i1 %t118, label %bb26, label %bb27
bb26:
  %t120 = load i64, ptr %l5, !tbaa !24
  %t122 = icmp eq i64 %t120, 0
  br i1 %t122, label %bb28, label %bb29
bb27:
  %t124 = load i32, ptr %l7, !range !{i32 0, i32 116}
  %t126 = trunc i64 1 to i32
  %t127 = icmp eq i32 %t124, %t126
  %t129 = xor i1 %t127, true
  br i1 %t129, label %bb31, label %bb32
bb28:
  store i64 0, ptr %rv
  br label %ret
bb29:
  br label %bb30
bb30:
  %t132 = load i64, ptr %l5, !tbaa !24
  %t135 = sub i64 %t132, 1
  store i64 %t135, ptr %l5, !tbaa !24
  br label %bb61
bb31:
  %t137 = load i32, ptr %l7, !range !{i32 0, i32 116}
  %t139 = trunc i64 76 to i32
  %t140 = icmp eq i32 %t137, %t139
  %t142 = xor i1 %t140, true
  store i1 %t142, ptr %l76, !tbaa !21
  br label %bb33
bb32:
  store i1 false, ptr %l76, !tbaa !21
  br label %bb33
bb33:
  %t144 = load i1, ptr %l76, !tbaa !21
  br i1 %t144, label %bb34, label %bb35
bb34:
  %t145 = load i32, ptr %l7, !range !{i32 0, i32 116}
  %t147 = trunc i64 75 to i32
  %t148 = icmp eq i32 %t145, %t147
  %t150 = xor i1 %t148, true
  store i1 %t150, ptr %l80, !tbaa !21
  br label %bb36
bb35:
  store i1 false, ptr %l80, !tbaa !21
  br label %bb36
bb36:
  %t152 = load i1, ptr %l80, !tbaa !21
  br i1 %t152, label %bb37, label %bb38
bb37:
  %t153 = load i32, ptr %l7, !range !{i32 0, i32 116}
  %t155 = trunc i64 102 to i32
  %t156 = icmp eq i32 %t153, %t155
  %t158 = xor i1 %t156, true
  store i1 %t158, ptr %l84, !tbaa !21
  br label %bb39
bb38:
  store i1 false, ptr %l84, !tbaa !21
  br label %bb39
bb39:
  %t160 = load i1, ptr %l84, !tbaa !21
  br i1 %t160, label %bb40, label %bb41
bb40:
  %t161 = load i32, ptr %l7, !range !{i32 0, i32 116}
  %t163 = trunc i64 77 to i32
  %t164 = icmp eq i32 %t161, %t163
  %t166 = xor i1 %t164, true
  store i1 %t166, ptr %l88, !tbaa !21
  br label %bb42
bb41:
  store i1 false, ptr %l88, !tbaa !21
  br label %bb42
bb42:
  %t168 = load i1, ptr %l88, !tbaa !21
  br i1 %t168, label %bb43, label %bb44
bb43:
  %t169 = load i32, ptr %l7, !range !{i32 0, i32 116}
  %t171 = trunc i64 39 to i32
  %t172 = icmp eq i32 %t169, %t171
  %t174 = xor i1 %t172, true
  store i1 %t174, ptr %l92, !tbaa !21
  br label %bb45
bb44:
  store i1 false, ptr %l92, !tbaa !21
  br label %bb45
bb45:
  %t176 = load i1, ptr %l92, !tbaa !21
  br i1 %t176, label %bb46, label %bb47
bb46:
  %t177 = load i32, ptr %l7, !range !{i32 0, i32 116}
  %t179 = trunc i64 37 to i32
  %t180 = icmp eq i32 %t177, %t179
  %t182 = xor i1 %t180, true
  store i1 %t182, ptr %l96, !tbaa !21
  br label %bb48
bb47:
  store i1 false, ptr %l96, !tbaa !21
  br label %bb48
bb48:
  %t184 = load i1, ptr %l96, !tbaa !21
  br i1 %t184, label %bb49, label %bb50
bb49:
  %t185 = load i32, ptr %l7, !range !{i32 0, i32 116}
  %t187 = trunc i64 13 to i32
  %t188 = icmp eq i32 %t185, %t187
  %t190 = xor i1 %t188, true
  store i1 %t190, ptr %l100, !tbaa !21
  br label %bb51
bb50:
  store i1 false, ptr %l100, !tbaa !21
  br label %bb51
bb51:
  %t192 = load i1, ptr %l100, !tbaa !21
  br i1 %t192, label %bb52, label %bb53
bb52:
  %t193 = load i32, ptr %l7, !range !{i32 0, i32 116}
  %t195 = trunc i64 52 to i32
  %t196 = icmp eq i32 %t193, %t195
  %t198 = xor i1 %t196, true
  store i1 %t198, ptr %l104, !tbaa !21
  br label %bb54
bb53:
  store i1 false, ptr %l104, !tbaa !21
  br label %bb54
bb54:
  %t200 = load i1, ptr %l104, !tbaa !21
  br i1 %t200, label %bb55, label %bb56
bb55:
  %t201 = load i32, ptr %l7, !range !{i32 0, i32 116}
  %t203 = trunc i64 67 to i32
  %t204 = icmp eq i32 %t201, %t203
  %t206 = xor i1 %t204, true
  store i1 %t206, ptr %l108, !tbaa !21
  br label %bb57
bb56:
  store i1 false, ptr %l108, !tbaa !21
  br label %bb57
bb57:
  %t208 = load i1, ptr %l108, !tbaa !21
  br i1 %t208, label %bb58, label %bb59
bb58:
  store i64 0, ptr %rv
  br label %ret
bb59:
  br label %bb60
bb60:
  br label %bb61
bb61:
  br label %bb62
bb62:
  br label %bb63
bb63:
  br label %bb64
bb64:
  br label %bb65
bb65:
  %t210 = load i64, ptr %l4, !tbaa !24
  %t212 = icmp slt i64 %t210, 0
  br i1 %t212, label %bb66, label %bb67
bb66:
  store i64 0, ptr %rv
  br label %ret
bb67:
  br label %bb68
bb68:
  %t215 = load i64, ptr %l4, !tbaa !24
  %t217 = icmp eq i64 %t215, 0
  br i1 %t217, label %bb69, label %bb70
bb69:
  %t219 = load i64, ptr %l5, !tbaa !24
  %t221 = icmp ne i64 %t219, 0
  br i1 %t221, label %bb71, label %bb72
bb70:
  br label %bb90
bb71:
  store i1 true, ptr %l120, !tbaa !21
  br label %bb74
bb72:
  %t223 = load ptr, ptr %l0, !tbaa !29
  %t224 = load i64, ptr %l6, !tbaa !24
  %t226 = add i64 %t224, 1
  %t229 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elook(ptr %v0, ptr %t223, i64 %t226)
  store i32 %t229, ptr %l124
  br label %bb73
bb73:
  %t230 = load i32, ptr %l124, !range !{i32 0, i32 116}
  %t232 = trunc i64 110 to i32
  %t233 = icmp eq i32 %t230, %t232
  %t235 = xor i1 %t233, true
  store i1 %t235, ptr %l120, !tbaa !21
  br label %bb74
bb74:
  %t237 = load i1, ptr %l120, !tbaa !21
  br i1 %t237, label %bb75, label %bb76
bb75:
  store i64 0, ptr %rv
  br label %ret
bb76:
  br label %bb77
bb77:
  %t239 = load i1, ptr %l3, !tbaa !21
  br i1 %t239, label %bb78, label %bb79
bb78:
  %t241 = load ptr, ptr %l0, !tbaa !29
  %t242 = load i64, ptr %l6, !tbaa !24
  %t245 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2elookTok(ptr %v0, ptr %t241, i64 %t242)
  store %"compiler/token:Token" %t245, ptr %l133
  br label %bb80
bb79:
  store i1 false, ptr %l130, !tbaa !21
  br label %bb82
bb80:
  %t246 = getelementptr %"compiler/token:Token", ptr %l133, i32 0, i32 3
  %t247 = load i32, ptr %t246, !tbaa !23
  store i32 %t247, ptr %l134, !tbaa !23
  %t248 = load ptr, ptr %l0, !tbaa !29
  %t249 = load i64, ptr %l6, !tbaa !24
  %t251 = add i64 %t249, 1
  %t254 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2elookTok(ptr %v0, ptr %t248, i64 %t251)
  store %"compiler/token:Token" %t254, ptr %l138
  br label %bb81
bb81:
  %t255 = getelementptr %"compiler/token:Token", ptr %l138, i32 0, i32 2
  %t256 = load i32, ptr %t255, !tbaa !23
  %t257 = load i32, ptr %l134, !tbaa !23
  %t259 = icmp eq i32 %t257, %t256
  store i1 %t259, ptr %l130, !tbaa !21
  br label %bb82
bb82:
  %t261 = load i1, ptr %l130, !tbaa !21
  br i1 %t261, label %bb83, label %bb84
bb83:
  store i64 2, ptr %rv
  br label %ret
bb84:
  br label %bb85
bb85:
  %t263 = load ptr, ptr %l0, !tbaa !29
  %t264 = load i64, ptr %l6, !tbaa !24
  %t266 = add i64 %t264, 2
  %t269 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elook(ptr %v0, ptr %t263, i64 %t266)
  store i32 %t269, ptr %l145
  br label %bb86
bb86:
  %t270 = load i32, ptr %l145, !range !{i32 0, i32 116}
  %t272 = trunc i64 111 to i32
  %t273 = icmp eq i32 %t270, %t272
  br i1 %t273, label %bb87, label %bb88
bb87:
  store i64 1, ptr %l148, !tbaa !24
  br label %bb89
bb88:
  store i64 0, ptr %l148, !tbaa !24
  br label %bb89
bb89:
  %t275 = load i64, ptr %l148, !tbaa !24
  store i64 %t275, ptr %rv
  br label %ret
bb90:
  %t276 = load i64, ptr %l6, !tbaa !24
  %t279 = add i64 %t276, 1
  store i64 %t279, ptr %l6, !tbaa !24
  br label %bb91
bb91:
  br label %bb13
bb92:
  store i64 0, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeBody(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca %"compiler/source:Span"
  %l7 = alloca { i64, ptr }
  %l8 = alloca i32
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca i32
  %l12 = alloca i32
  %l13 = alloca { i64, ptr }
  %l14 = alloca i1
  %l15 = alloca i32
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l18 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l20 = alloca ptr
  %l21 = alloca i32
  %l22 = alloca ptr
  %l23 = alloca %"compiler/token:Token"
  %l24 = alloca %"compiler/source:Span"
  %l25 = alloca ptr
  %l26 = alloca i32
  %l27 = alloca i32
  %l28 = alloca %"compiler/token:Token"
  %l29 = alloca i32
  %l30 = alloca ptr
  %l31 = alloca ptr
  %l32 = alloca i32
  %l33 = alloca { i64, ptr }
  %l34 = alloca ptr
  %l35 = alloca { i64, ptr }
  %lp36 = alloca ptr
  %l38 = alloca i32
  %l42 = alloca i32
  %l48 = alloca i1
  %l49 = alloca { i64, ptr }
  %l51 = alloca { i64, ptr }
  %l52 = alloca i32
  %l54 = alloca i32
  %l57 = alloca i32
  %l58 = alloca i32
  %l60 = alloca { i64, ptr }
  %l62 = alloca { i64, ptr }
  %l63 = alloca i32
  %l65 = alloca ptr
  %l67 = alloca ptr
  %l68 = alloca i32
  %l71 = alloca { i64, ptr }
  %l73 = alloca { i64, ptr }
  %l74 = alloca i32
  %l76 = alloca %"compiler/source:Span"
  %l82 = alloca i1
  %l84 = alloca i32
  %l85 = alloca { i64, ptr }
  %l87 = alloca { i64, ptr }
  %l88 = alloca i32
  %l92 = alloca %"compiler/source:Span"
  %l100 = alloca %"compiler/ast:StructBody"
  %l107 = alloca i32
  %l110 = alloca i1
  %l112 = alloca i1
  %l115 = alloca i1
  %l117 = alloca ptr
  %l119 = alloca ptr
  %l120 = alloca i32
  %l123 = alloca i32
  %l126 = alloca i32
  %l127 = alloca i32
  %l129 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l134 = alloca i1
  %l138 = alloca i32
  %l139 = alloca i32
  %l141 = alloca i32
  %l142 = alloca i32
  %l149 = alloca i1
  %l150 = alloca { i64, ptr }
  %l152 = alloca { i64, ptr }
  %l153 = alloca i32
  %l157 = alloca i1
  %l159 = alloca i1
  %l162 = alloca i1
  %l164 = alloca i1
  %l167 = alloca i1
  %l169 = alloca i1
  %l172 = alloca i1
  %l174 = alloca i1
  %l177 = alloca i1
  %l180 = alloca i32
  %l181 = alloca ptr
  %l183 = alloca ptr
  %l184 = alloca i32
  %l188 = alloca %"compiler/source:Span"
  %l192 = alloca %"compiler/ast:Param"
  %l194 = alloca { i64, ptr }
  %l197 = alloca i1
  %l198 = alloca ptr
  %l200 = alloca ptr
  %l201 = alloca i32
  %l204 = alloca ptr
  %l207 = alloca %"compiler/source:Span"
  %l212 = alloca %"compiler/ast:CaseDecl"
  %l215 = alloca i32
  %l218 = alloca i32
  %l220 = alloca { i64, ptr }
  %l227 = alloca i32
  %l228 = alloca { i64, ptr }
  %l231 = alloca { i64, ptr }
  %l232 = alloca i32
  %l234 = alloca { i64, ptr }
  %l237 = alloca { i64, ptr }
  %l238 = alloca i32
  %l240 = alloca i32
  %l243 = alloca i32
  %l244 = alloca i32
  %l246 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l251 = alloca i1
  %l255 = alloca i32
  %l258 = alloca i1
  %l260 = alloca %"compiler/token:Token"
  %l262 = alloca i32
  %l265 = alloca %"compiler/source:Span"
  %l270 = alloca %"compiler/ast:Param"
  %l274 = alloca i1
  %l277 = alloca i1
  %l278 = alloca i1
  %l280 = alloca i32
  %l284 = alloca %"compiler/token:Token"
  %l285 = alloca i32
  %l287 = alloca i32
  %l288 = alloca i32
  %l292 = alloca %"compiler/source:Span"
  %l293 = alloca i32
  %l296 = alloca { i64, ptr }
  %l303 = alloca i32
  %l304 = alloca i32
  %l306 = alloca i32
  %l307 = alloca i32
  %l314 = alloca ptr
  %l318 = alloca { i64, ptr }
  %l322 = alloca { i64, ptr }
  %l325 = alloca i32
  %l326 = alloca ptr
  %l328 = alloca ptr
  %l329 = alloca i32
  %l331 = alloca ptr
  %l334 = alloca %"compiler/source:Span"
  %l335 = alloca ptr
  %l336 = alloca i32
  %l337 = alloca ptr
  %l340 = alloca { i64, ptr }
  %l346 = alloca %"compiler/ast:Func"
  %l349 = alloca i32
  %l352 = alloca i32
  %l354 = alloca { i64, ptr }
  %l360 = alloca ptr
  %l362 = alloca ptr
  %l363 = alloca i32
  %l368 = alloca i1
  %l370 = alloca i32
  %l371 = alloca { i64, ptr }
  %l373 = alloca { i64, ptr }
  %l374 = alloca i32
  %l376 = alloca ptr
  %l378 = alloca ptr
  %l379 = alloca i32
  %l381 = alloca { i64, ptr }
  %l383 = alloca { i64, ptr }
  %l384 = alloca i32
  %l386 = alloca { i64, ptr }
  %l389 = alloca { i64, ptr }
  %l391 = alloca i1
  %l393 = alloca { i64, ptr }
  %l397 = alloca %"compiler/ast:Sig"
  %l398 = alloca ptr
  %l401 = alloca %"compiler/source:Span"
  %l402 = alloca ptr
  %l403 = alloca { i64, ptr }
  %l407 = alloca %"compiler/ast:Func"
  %s1 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %rv = alloca { i32, ptr }
  %t190 = alloca { i64, [6 x i64] }, align 8
  %t491 = alloca { i64, [6 x i64] }, align 8
  %t614 = alloca { i64, [5 x i64] }, align 8
  %t688 = alloca i64
  %t705 = alloca { i64, [5 x i64] }, align 8
  %t871 = alloca { i64, [6 x i64] }, align 8
  %t1034 = alloca { i64, [6 x i64] }, align 8
  %t1047 = alloca { i64, [6 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2epeek(ptr %v0, ptr %t1)
  store i32 %t3, ptr %l38
  br label %bb1
bb1:
  %t4 = load i32, ptr %l38, !range !{i32 0, i32 116}
  store i32 %t4, ptr %l1
  %t5 = load i32, ptr %l1, !range !{i32 0, i32 116}
  %t7 = trunc i64 34 to i32
  %t8 = icmp eq i32 %t5, %t7
  br i1 %t8, label %bb2, label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb44
bb4:
  store %olang.scope zeroinitializer, ptr %s1
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t10)
  store i32 %t12, ptr %l42
  br label %bb5
bb5:
  %t13 = icmp sge i64 0, 0
  br i1 %t13, label %bb6, label %bb7
bb6:
  %t15 = icmp sle i64 0, 1152921504606846975
  br i1 %t15, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_e980cdf5146ac576_c2415009b5e84a7a)
  unreachable
bb8:
  %t17 = mul i64 0, 8
  %t18 = insertvalue { i64, ptr } undef, i64 0, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t19, ptr %l2, !tbaa !27
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t24 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t21, i32 98)
  store i1 %t24, ptr %l48
  br label %bb10
bb9:
  call void @__olang_check_failed(ptr @olang_loc_e980cdf5146ac576_c2415009b5e84a7a)
  unreachable
bb10:
  %t25 = load i1, ptr %l48, !tbaa !21
  br i1 %t25, label %bb11, label %bb12
bb11:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeParams(ptr %v0, ptr %v1, ptr %t26)
  %t29 = extractvalue { i32, { i64, ptr } } %t28, 1
  %t30 = extractvalue { i32, { i64, ptr } } %t28, 0
  store i32 %t30, ptr %l52
  %t31 = icmp ne i32 %t30, 0
  br i1 %t31, label %bb14, label %ok.32, !prof !99
ok.32:
  store { i64, ptr } %t29, ptr %l51
  br label %bb13
bb12:
  br label %bb16
bb13:
  %t33 = load { i64, ptr }, ptr %l51, !tbaa !27
  store { i64, ptr } %t33, ptr %l49, !tbaa !27
  br label %bb15
bb14:
  %t34 = load i32, ptr %l52, !tbaa !23
  %t35 = lshr i32 %t34, 16
  %t36 = and i32 %t34, 65535
  %t37 = icmp eq i32 %t35, 1
  %t38 = select i1 %t37, i32 1, i32 0
  %t39 = icmp eq i32 %t34, 0
  %t40 = shl i32 %t38, 16
  %t41 = or i32 %t40, %t36
  %t42 = select i1 %t39, i32 0, i32 %t41
  call void @__olang_scope_close(ptr %s1)
  %t44 = insertvalue { i32, ptr } zeroinitializer, i32 %t42, 0
  store { i32, ptr } %t44, ptr %rv
  br label %ret
bb15:
  %t45 = load { i64, ptr }, ptr %l49, !tbaa !27
  store { i64, ptr } %t45, ptr %l2, !tbaa !27
  br label %bb16
bb16:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t49 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %t46, i32 110)
  %t50 = extractvalue { i32, i32 } %t49, 1
  %t51 = extractvalue { i32, i32 } %t49, 0
  store i32 %t51, ptr %l58
  %t52 = icmp ne i32 %t51, 0
  br i1 %t52, label %bb18, label %ok.53, !prof !99
ok.53:
  store i32 %t50, ptr %l57
  br label %bb17
bb17:
  %t54 = load i32, ptr %l57, !tbaa !23
  store i32 %t54, ptr %l54, !tbaa !23
  br label %bb19
bb18:
  %t55 = load i32, ptr %l58, !tbaa !23
  %t56 = lshr i32 %t55, 16
  %t57 = and i32 %t55, 65535
  %t58 = icmp eq i32 %t56, 1
  %t59 = select i1 %t58, i32 1, i32 0
  %t60 = icmp eq i32 %t55, 0
  %t61 = shl i32 %t59, 16
  %t62 = or i32 %t61, %t57
  %t63 = select i1 %t60, i32 0, i32 %t62
  call void @__olang_scope_close(ptr %s1)
  %t65 = insertvalue { i32, ptr } zeroinitializer, i32 %t63, 0
  store { i32, ptr } %t65, ptr %rv
  br label %ret
bb19:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eparams(ptr %v0, ptr %v1, ptr %t66, i1 false)
  %t69 = extractvalue { i32, { i64, ptr } } %t68, 1
  %t70 = extractvalue { i32, { i64, ptr } } %t68, 0
  store i32 %t70, ptr %l63
  %t71 = icmp ne i32 %t70, 0
  br i1 %t71, label %bb21, label %ok.72, !prof !99
ok.72:
  store { i64, ptr } %t69, ptr %l62
  br label %bb20
bb20:
  %t73 = load { i64, ptr }, ptr %l62, !tbaa !27
  store { i64, ptr } %t73, ptr %l60, !tbaa !27
  br label %bb22
bb21:
  %t74 = load i32, ptr %l63, !tbaa !23
  %t75 = lshr i32 %t74, 16
  %t76 = and i32 %t74, 65535
  %t77 = icmp eq i32 %t75, 1
  %t78 = select i1 %t77, i32 1, i32 0
  %t79 = icmp eq i32 %t74, 0
  %t80 = shl i32 %t78, 16
  %t81 = or i32 %t80, %t76
  %t82 = select i1 %t79, i32 0, i32 %t81
  call void @__olang_scope_close(ptr %s1)
  %t84 = insertvalue { i32, ptr } zeroinitializer, i32 %t82, 0
  store { i32, ptr } %t84, ptr %rv
  br label %ret
bb22:
  %t85 = load { i64, ptr }, ptr %l60, !tbaa !27
  store { i64, ptr } %t85, ptr %l3, !tbaa !27
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t88 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eerrorSet(ptr %v0, ptr %v1, ptr %t86, i1 false)
  %t89 = extractvalue { i32, ptr } %t88, 1
  %t90 = extractvalue { i32, ptr } %t88, 0
  store i32 %t90, ptr %l68
  %t91 = icmp ne i32 %t90, 0
  br i1 %t91, label %bb24, label %ok.92, !prof !99
ok.92:
  store ptr %t89, ptr %l67
  br label %bb23
bb23:
  %t93 = load ptr, ptr %l67, !tbaa !29
  store ptr %t93, ptr %l65, !tbaa !29
  br label %bb25
bb24:
  %t94 = load i32, ptr %l68, !tbaa !23
  %t95 = lshr i32 %t94, 16
  %t96 = and i32 %t94, 65535
  %t97 = icmp eq i32 %t95, 1
  %t98 = select i1 %t97, i32 1, i32 0
  %t99 = icmp eq i32 %t94, 0
  %t100 = shl i32 %t98, 16
  %t101 = or i32 %t100, %t96
  %t102 = select i1 %t99, i32 0, i32 %t101
  call void @__olang_scope_close(ptr %s1)
  %t104 = insertvalue { i32, ptr } zeroinitializer, i32 %t102, 0
  store { i32, ptr } %t104, ptr %rv
  br label %ret
bb25:
  %t105 = load ptr, ptr %l65, !tbaa !29
  store ptr %t105, ptr %l4, !tbaa !29
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t108 = getelementptr %"compiler/parse:Parser", ptr %t106, i32 0, i32 20
  store i1 true, ptr %t108, !tbaa !21
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t111 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ectorBlock(ptr %v0, ptr %v1, ptr %t109)
  %t112 = extractvalue { i32, { i64, ptr } } %t111, 1
  %t113 = extractvalue { i32, { i64, ptr } } %t111, 0
  store i32 %t113, ptr %l74
  %t114 = icmp ne i32 %t113, 0
  br i1 %t114, label %bb27, label %ok.115, !prof !99
ok.115:
  store { i64, ptr } %t112, ptr %l73
  br label %bb26
bb26:
  %t116 = load { i64, ptr }, ptr %l73, !tbaa !27
  store { i64, ptr } %t116, ptr %l71, !tbaa !27
  br label %bb28
bb27:
  %t117 = load i32, ptr %l74, !tbaa !23
  %t118 = lshr i32 %t117, 16
  %t119 = and i32 %t117, 65535
  %t120 = icmp eq i32 %t118, 1
  %t121 = select i1 %t120, i32 1, i32 0
  %t122 = icmp eq i32 %t117, 0
  %t123 = shl i32 %t121, 16
  %t124 = or i32 %t123, %t119
  %t125 = select i1 %t122, i32 0, i32 %t124
  call void @__olang_scope_close(ptr %s1)
  %t127 = insertvalue { i32, ptr } zeroinitializer, i32 %t125, 0
  store { i32, ptr } %t127, ptr %rv
  br label %ret
bb28:
  %t128 = load { i64, ptr }, ptr %l71, !tbaa !27
  store { i64, ptr } %t128, ptr %l5, !tbaa !27
  %t129 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s1, i32 0, i32 0)
  store %"compiler/source:Span" %t129, ptr %l76
  br label %bb29
bb29:
  %t130 = load %"compiler/source:Span", ptr %l76
  store %"compiler/source:Span" %t130, ptr %l6
  %t131 = icmp sge i64 0, 0
  br i1 %t131, label %bb30, label %bb31
bb30:
  %t133 = icmp sle i64 0, 1152921504606846975
  br i1 %t133, label %bb32, label %bb33
bb31:
  call void @__olang_check_failed(ptr @olang_loc_1539ac39f97600b_6c3b4513fd4221cf)
  unreachable
bb32:
  %t135 = mul i64 0, 8
  %t136 = insertvalue { i64, ptr } undef, i64 0, 0
  %t137 = insertvalue { i64, ptr } %t136, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t137, ptr %l7, !tbaa !27
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t142 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t139, i32 42)
  store i1 %t142, ptr %l82
  br label %bb34
bb33:
  call void @__olang_check_failed(ptr @olang_loc_1539ac39f97600b_6c3b4513fd4221cf)
  unreachable
bb34:
  %t143 = load i1, ptr %l82, !tbaa !21
  br i1 %t143, label %bb35, label %bb36
bb35:
  %t144 = load ptr, ptr %l0, !tbaa !29
  %t146 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t144)
  store i32 %t146, ptr %l84
  br label %bb37
bb36:
  br label %bb42
bb37:
  %t147 = load i32, ptr %l84, !tbaa !23
  store i32 %t147, ptr %l8, !tbaa !23
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t150 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ebody(ptr %v0, ptr %v1, ptr %t148)
  %t151 = extractvalue { i32, { i64, ptr } } %t150, 1
  %t152 = extractvalue { i32, { i64, ptr } } %t150, 0
  store i32 %t152, ptr %l88
  %t153 = icmp ne i32 %t152, 0
  br i1 %t153, label %bb39, label %ok.154, !prof !99
ok.154:
  store { i64, ptr } %t151, ptr %l87
  br label %bb38
bb38:
  %t155 = load { i64, ptr }, ptr %l87, !tbaa !27
  store { i64, ptr } %t155, ptr %l85, !tbaa !27
  br label %bb40
bb39:
  %t156 = load i32, ptr %l88, !tbaa !23
  %t157 = lshr i32 %t156, 16
  %t158 = and i32 %t156, 65535
  %t159 = icmp eq i32 %t157, 1
  %t160 = select i1 %t159, i32 1, i32 0
  %t161 = icmp eq i32 %t156, 0
  %t162 = shl i32 %t160, 16
  %t163 = or i32 %t162, %t158
  %t164 = select i1 %t161, i32 0, i32 %t163
  call void @__olang_scope_close(ptr %s1)
  %t166 = insertvalue { i32, ptr } zeroinitializer, i32 %t164, 0
  store { i32, ptr } %t166, ptr %rv
  br label %ret
bb40:
  %t167 = load { i64, ptr }, ptr %l85, !tbaa !27
  store { i64, ptr } %t167, ptr %l7, !tbaa !27
  %t168 = load ptr, ptr %l0, !tbaa !29
  %t169 = load i32, ptr %l8, !tbaa !23
  %t172 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t168, i32 %t169)
  store %"compiler/source:Span" %t172, ptr %l92
  br label %bb41
bb41:
  %t173 = load %"compiler/source:Span", ptr %l92
  store %"compiler/source:Span" %t173, ptr %l6
  br label %bb42
bb42:
  %t174 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t175 = load ptr, ptr %l4, !tbaa !29
  %t177 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t178 = load %"compiler/source:Span", ptr %l6
  %t179 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t180 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t187 = call %"compiler/ast:StructBody" @compiler_2fast_3aStructBody_2ector(ptr %v1, ptr %v1, ptr %v1, ptr %v1, ptr %v1, ptr %v1, { i64, ptr } %t174, ptr %t175, { i64, ptr } %t177, %"compiler/source:Span" %t178, { i64, ptr } %t179, { i64, ptr } %t180)
  store %"compiler/ast:StructBody" %t187, ptr %l100
  br label %bb43
bb43:
  %t188 = load %"compiler/ast:StructBody", ptr %l100
  %t189 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 80, i64 8)
  store %"compiler/ast:StructBody" %t188, ptr %t189
  store { i64, [6 x i64] } zeroinitializer, ptr %t190
  %t191 = getelementptr { i64, [6 x i64] }, ptr %t190, i32 0, i32 0
  store i64 0, ptr %t191
  %t193 = insertvalue { ptr } undef, ptr %t189, 0
  %t194 = getelementptr { i64, [6 x i64] }, ptr %t190, i32 0, i32 1
  store { ptr } %t193, ptr %t194
  %t195 = load { i64, [6 x i64] }, ptr %t190
  %t197 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 56, i64 8)
  store { i64, [6 x i64] } %t195, ptr %t197
  call void @__olang_scope_close(ptr %s1)
  %t199 = insertvalue { i32, ptr } zeroinitializer, ptr %t197, 1
  store { i32, ptr } %t199, ptr %rv
  br label %ret
bb44:
  %t200 = load i32, ptr %l1, !range !{i32 0, i32 116}
  %t202 = trunc i64 35 to i32
  %t203 = icmp eq i32 %t200, %t202
  br i1 %t203, label %bb45, label %bb46
bb45:
  br label %bb47
bb46:
  br label %bb128
bb47:
  %t205 = load ptr, ptr %l0, !tbaa !29
  %t207 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t205)
  store i32 %t207, ptr %l107
  br label %bb48
bb48:
  store ptr null, ptr %l9, !tbaa !29
  %t208 = load ptr, ptr %l0, !tbaa !29
  %t211 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t208, i32 114)
  store i1 %t211, ptr %l110
  br label %bb49
bb49:
  %t212 = load i1, ptr %l110, !tbaa !21
  %t213 = xor i1 %t212, true
  br i1 %t213, label %bb50, label %bb51
bb50:
  %t215 = load ptr, ptr %l0, !tbaa !29
  %t218 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t215, i32 79)
  store i1 %t218, ptr %l115
  br label %bb52
bb51:
  store i1 false, ptr %l112, !tbaa !21
  br label %bb53
bb52:
  %t219 = load i1, ptr %l115, !tbaa !21
  %t220 = xor i1 %t219, true
  store i1 %t220, ptr %l112, !tbaa !21
  br label %bb53
bb53:
  %t222 = load i1, ptr %l112, !tbaa !21
  br i1 %t222, label %bb54, label %bb55
bb54:
  %t223 = load ptr, ptr %l0, !tbaa !29
  %t225 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeExpr(ptr %v0, ptr %v1, ptr %t223)
  %t226 = extractvalue { i32, ptr } %t225, 1
  %t227 = extractvalue { i32, ptr } %t225, 0
  store i32 %t227, ptr %l120
  %t228 = icmp ne i32 %t227, 0
  br i1 %t228, label %bb57, label %ok.229, !prof !99
ok.229:
  store ptr %t226, ptr %l119
  br label %bb56
bb55:
  br label %bb59
bb56:
  %t230 = load ptr, ptr %l119, !tbaa !29
  store ptr %t230, ptr %l117, !tbaa !29
  br label %bb58
bb57:
  %t231 = load i32, ptr %l120, !tbaa !23
  %t232 = lshr i32 %t231, 16
  %t233 = and i32 %t231, 65535
  %t234 = icmp eq i32 %t232, 1
  %t235 = select i1 %t234, i32 1, i32 0
  %t236 = icmp eq i32 %t231, 0
  %t237 = shl i32 %t235, 16
  %t238 = or i32 %t237, %t233
  %t239 = select i1 %t236, i32 0, i32 %t238
  %t241 = insertvalue { i32, ptr } zeroinitializer, i32 %t239, 0
  store { i32, ptr } %t241, ptr %rv
  br label %ret
bb58:
  %t242 = load ptr, ptr %l117, !tbaa !29
  store ptr %t242, ptr %l9, !tbaa !29
  br label %bb59
bb59:
  %t244 = load ptr, ptr %l0, !tbaa !29
  %t247 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %t244, i32 114)
  %t248 = extractvalue { i32, i32 } %t247, 1
  %t249 = extractvalue { i32, i32 } %t247, 0
  store i32 %t249, ptr %l127
  %t250 = icmp ne i32 %t249, 0
  br i1 %t250, label %bb61, label %ok.251, !prof !99
ok.251:
  store i32 %t248, ptr %l126
  br label %bb60
bb60:
  %t252 = load i32, ptr %l126, !tbaa !23
  store i32 %t252, ptr %l123, !tbaa !23
  br label %bb62
bb61:
  %t253 = load i32, ptr %l127, !tbaa !23
  %t254 = lshr i32 %t253, 16
  %t255 = and i32 %t253, 65535
  %t256 = icmp eq i32 %t254, 1
  %t257 = select i1 %t256, i32 1, i32 0
  %t258 = icmp eq i32 %t253, 0
  %t259 = shl i32 %t257, 16
  %t260 = or i32 %t259, %t255
  %t261 = select i1 %t258, i32 0, i32 %t260
  %t263 = insertvalue { i32, ptr } zeroinitializer, i32 %t261, 0
  store { i32, ptr } %t263, ptr %rv
  br label %ret
bb62:
  %t264 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aCaseDecl_26_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t264, ptr %l129
  br label %bb63
bb63:
  %t265 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l129
  %t266 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t265, ptr %t266
  store ptr %t266, ptr %l10, !tbaa !29
  %t268 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2eskipEnds(ptr %v0, ptr %t268)
  br label %bb64
bb64:
  br label %bb65
bb65:
  %t270 = load ptr, ptr %l0, !tbaa !29
  %t273 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t270, i32 115)
  store i1 %t273, ptr %l134
  br label %bb66
bb66:
  %t274 = load i1, ptr %l134, !tbaa !21
  %t275 = xor i1 %t274, true
  %t277 = xor i1 %t275, true
  br i1 %t277, label %bb67, label %bb68
bb67:
  br label %bb125
bb68:
  br label %bb69
bb69:
  %t279 = load ptr, ptr %l0, !tbaa !29
  %t281 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ehere(ptr %v0, ptr %t279)
  store i32 %t281, ptr %l138
  br label %bb70
bb70:
  %t282 = load i32, ptr %l138, !tbaa !23
  store i32 %t282, ptr %l11, !tbaa !23
  %t283 = load ptr, ptr %l0, !tbaa !29
  %t285 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ename(ptr %v0, ptr %t283)
  %t286 = extractvalue { i32, i32 } %t285, 1
  %t287 = extractvalue { i32, i32 } %t285, 0
  store i32 %t287, ptr %l142
  %t288 = icmp ne i32 %t287, 0
  br i1 %t288, label %bb72, label %ok.289, !prof !99
ok.289:
  store i32 %t286, ptr %l141
  br label %bb71
bb71:
  %t290 = load i32, ptr %l141, !tbaa !23
  store i32 %t290, ptr %l139, !tbaa !23
  br label %bb73
bb72:
  %t291 = load i32, ptr %l142, !tbaa !23
  %t292 = lshr i32 %t291, 16
  %t293 = and i32 %t291, 65535
  %t294 = icmp eq i32 %t292, 1
  %t295 = select i1 %t294, i32 1, i32 0
  %t296 = icmp eq i32 %t291, 0
  %t297 = shl i32 %t295, 16
  %t298 = or i32 %t297, %t293
  %t299 = select i1 %t296, i32 0, i32 %t298
  %t301 = insertvalue { i32, ptr } zeroinitializer, i32 %t299, 0
  store { i32, ptr } %t301, ptr %rv
  br label %ret
bb73:
  %t302 = load i32, ptr %l139, !tbaa !23
  store i32 %t302, ptr %l12, !tbaa !23
  %t303 = icmp sge i64 0, 0
  br i1 %t303, label %bb74, label %bb75
bb74:
  %t305 = icmp sle i64 0, 1152921504606846975
  br i1 %t305, label %bb76, label %bb77
bb75:
  call void @__olang_check_failed(ptr @olang_loc_17377aefad64a2a8_5cc0f861968a066c)
  unreachable
bb76:
  %t307 = mul i64 0, 8
  %t308 = insertvalue { i64, ptr } undef, i64 0, 0
  %t309 = insertvalue { i64, ptr } %t308, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t309, ptr %l13, !tbaa !27
  store i1 false, ptr %l14, !tbaa !21
  %t311 = load ptr, ptr %l0, !tbaa !29
  %t314 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t311, i32 110)
  store i1 %t314, ptr %l149
  br label %bb78
bb77:
  call void @__olang_check_failed(ptr @olang_loc_17377aefad64a2a8_5cc0f861968a066c)
  unreachable
bb78:
  %t315 = load i1, ptr %l149, !tbaa !21
  br i1 %t315, label %bb79, label %bb80
bb79:
  %t316 = load ptr, ptr %l0, !tbaa !29
  %t318 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eparams(ptr %v0, ptr %v1, ptr %t316, i1 false)
  %t319 = extractvalue { i32, { i64, ptr } } %t318, 1
  %t320 = extractvalue { i32, { i64, ptr } } %t318, 0
  store i32 %t320, ptr %l153
  %t321 = icmp ne i32 %t320, 0
  br i1 %t321, label %bb82, label %ok.322, !prof !99
ok.322:
  store { i64, ptr } %t319, ptr %l152
  br label %bb81
bb80:
  %t323 = load ptr, ptr %l0, !tbaa !29
  %t326 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t323, i32 75)
  store i1 %t326, ptr %l157
  br label %bb84
bb81:
  %t327 = load { i64, ptr }, ptr %l152, !tbaa !27
  store { i64, ptr } %t327, ptr %l150, !tbaa !27
  br label %bb83
bb82:
  %t328 = load i32, ptr %l153, !tbaa !23
  %t329 = lshr i32 %t328, 16
  %t330 = and i32 %t328, 65535
  %t331 = icmp eq i32 %t329, 1
  %t332 = select i1 %t331, i32 1, i32 0
  %t333 = icmp eq i32 %t328, 0
  %t334 = shl i32 %t332, 16
  %t335 = or i32 %t334, %t330
  %t336 = select i1 %t333, i32 0, i32 %t335
  %t338 = insertvalue { i32, ptr } zeroinitializer, i32 %t336, 0
  store { i32, ptr } %t338, ptr %rv
  br label %ret
bb83:
  %t339 = load { i64, ptr }, ptr %l150, !tbaa !27
  store { i64, ptr } %t339, ptr %l13, !tbaa !27
  br label %bb110
bb84:
  %t340 = load i1, ptr %l157, !tbaa !21
  %t341 = xor i1 %t340, true
  br i1 %t341, label %bb85, label %bb86
bb85:
  %t343 = load ptr, ptr %l0, !tbaa !29
  %t346 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t343, i32 8)
  store i1 %t346, ptr %l162
  br label %bb87
bb86:
  store i1 false, ptr %l159, !tbaa !21
  br label %bb88
bb87:
  %t347 = load i1, ptr %l162, !tbaa !21
  %t348 = xor i1 %t347, true
  store i1 %t348, ptr %l159, !tbaa !21
  br label %bb88
bb88:
  %t350 = load i1, ptr %l159, !tbaa !21
  br i1 %t350, label %bb89, label %bb90
bb89:
  %t351 = load ptr, ptr %l0, !tbaa !29
  %t354 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t351, i32 115)
  store i1 %t354, ptr %l167
  br label %bb91
bb90:
  store i1 false, ptr %l164, !tbaa !21
  br label %bb92
bb91:
  %t355 = load i1, ptr %l167, !tbaa !21
  %t356 = xor i1 %t355, true
  store i1 %t356, ptr %l164, !tbaa !21
  br label %bb92
bb92:
  %t358 = load i1, ptr %l164, !tbaa !21
  br i1 %t358, label %bb93, label %bb94
bb93:
  %t359 = load ptr, ptr %l0, !tbaa !29
  %t362 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t359, i32 0)
  store i1 %t362, ptr %l172
  br label %bb95
bb94:
  store i1 false, ptr %l169, !tbaa !21
  br label %bb96
bb95:
  %t363 = load i1, ptr %l172, !tbaa !21
  %t364 = xor i1 %t363, true
  store i1 %t364, ptr %l169, !tbaa !21
  br label %bb96
bb96:
  %t366 = load i1, ptr %l169, !tbaa !21
  br i1 %t366, label %bb97, label %bb98
bb97:
  %t367 = load ptr, ptr %l0, !tbaa !29
  %t370 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t367, i32 78)
  store i1 %t370, ptr %l177
  br label %bb99
bb98:
  store i1 false, ptr %l174, !tbaa !21
  br label %bb100
bb99:
  %t371 = load i1, ptr %l177, !tbaa !21
  %t372 = xor i1 %t371, true
  store i1 %t372, ptr %l174, !tbaa !21
  br label %bb100
bb100:
  %t374 = load i1, ptr %l174, !tbaa !21
  br i1 %t374, label %bb101, label %bb102
bb101:
  %t375 = load ptr, ptr %l0, !tbaa !29
  %t377 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ehere(ptr %v0, ptr %t375)
  store i32 %t377, ptr %l180
  br label %bb103
bb102:
  br label %bb109
bb103:
  %t378 = load i32, ptr %l180, !tbaa !23
  store i32 %t378, ptr %l15, !tbaa !23
  %t379 = load ptr, ptr %l0, !tbaa !29
  %t381 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeExpr(ptr %v0, ptr %v1, ptr %t379)
  %t382 = extractvalue { i32, ptr } %t381, 1
  %t383 = extractvalue { i32, ptr } %t381, 0
  store i32 %t383, ptr %l184
  %t384 = icmp ne i32 %t383, 0
  br i1 %t384, label %bb105, label %ok.385, !prof !99
ok.385:
  store ptr %t382, ptr %l183
  br label %bb104
bb104:
  %t386 = load ptr, ptr %l183, !tbaa !29
  store ptr %t386, ptr %l181, !tbaa !29
  br label %bb106
bb105:
  %t387 = load i32, ptr %l184, !tbaa !23
  %t388 = lshr i32 %t387, 16
  %t389 = and i32 %t387, 65535
  %t390 = icmp eq i32 %t388, 1
  %t391 = select i1 %t390, i32 1, i32 0
  %t392 = icmp eq i32 %t387, 0
  %t393 = shl i32 %t391, 16
  %t394 = or i32 %t393, %t389
  %t395 = select i1 %t392, i32 0, i32 %t394
  %t397 = insertvalue { i32, ptr } zeroinitializer, i32 %t395, 0
  store { i32, ptr } %t397, ptr %rv
  br label %ret
bb106:
  %t398 = load ptr, ptr %l181, !tbaa !29
  store ptr %t398, ptr %l16, !tbaa !29
  %t399 = load ptr, ptr %l0, !tbaa !29
  %t400 = load i32, ptr %l15, !tbaa !23
  %t403 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t399, i32 %t400)
  store %"compiler/source:Span" %t403, ptr %l188
  br label %bb107
bb107:
  %t404 = load i32, ptr %l12, !tbaa !23
  %t405 = load ptr, ptr %l16, !tbaa !29
  %t407 = load %"compiler/source:Span", ptr %l188
  %t410 = call %"compiler/ast:Param" @compiler_2fast_3aParam_2ector(ptr %v1, ptr %v1, ptr %v1, %"compiler/source:Span" %t407, i32 %t404, ptr %t405, ptr null)
  store %"compiler/ast:Param" %t410, ptr %l192
  br label %bb108
bb108:
  %t411 = load %"compiler/ast:Param", ptr %l192
  %t412 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 32, i64 8)
  store %"compiler/ast:Param" %t411, ptr %t412
  %t413 = mul i64 1, 8
  %t414 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t413)
  %t415 = insertvalue { i64, ptr } undef, i64 1, 0
  %t416 = insertvalue { i64, ptr } %t415, ptr %t414, 1
  store { i64, ptr } %t416, ptr %l194, !tbaa !27
  %t418 = getelementptr { i64, ptr }, ptr %l194, i32 0, i32 1
  %t419 = load ptr, ptr %t418, !tbaa !27
  %t420 = getelementptr ptr, ptr %t419, i64 0
  store ptr %t412, ptr %t420, !tbaa !39
  %t421 = load { i64, ptr }, ptr %l194, !tbaa !27
  store { i64, ptr } %t421, ptr %l13, !tbaa !27
  store i1 true, ptr %l14, !tbaa !21
  br label %bb109
bb109:
  br label %bb110
bb110:
  store ptr null, ptr %l17, !tbaa !29
  %t422 = load ptr, ptr %l0, !tbaa !29
  %t425 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t422, i32 78)
  store i1 %t425, ptr %l197
  br label %bb111
bb111:
  %t426 = load i1, ptr %l197, !tbaa !21
  br i1 %t426, label %bb112, label %bb113
bb112:
  %t427 = load ptr, ptr %l0, !tbaa !29
  %t429 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexpr(ptr %v0, ptr %v1, ptr %t427)
  %t430 = extractvalue { i32, ptr } %t429, 1
  %t431 = extractvalue { i32, ptr } %t429, 0
  store i32 %t431, ptr %l201
  %t432 = icmp ne i32 %t431, 0
  br i1 %t432, label %bb115, label %ok.433, !prof !99
ok.433:
  store ptr %t430, ptr %l200
  br label %bb114
bb113:
  br label %bb117
bb114:
  %t434 = load ptr, ptr %l200, !tbaa !29
  store ptr %t434, ptr %l198, !tbaa !29
  br label %bb116
bb115:
  %t435 = load i32, ptr %l201, !tbaa !23
  %t436 = lshr i32 %t435, 16
  %t437 = and i32 %t435, 65535
  %t438 = icmp eq i32 %t436, 1
  %t439 = select i1 %t438, i32 1, i32 0
  %t440 = icmp eq i32 %t435, 0
  %t441 = shl i32 %t439, 16
  %t442 = or i32 %t441, %t437
  %t443 = select i1 %t440, i32 0, i32 %t442
  %t445 = insertvalue { i32, ptr } zeroinitializer, i32 %t443, 0
  store { i32, ptr } %t445, ptr %rv
  br label %ret
bb116:
  %t446 = load ptr, ptr %l198, !tbaa !29
  store ptr %t446, ptr %l17, !tbaa !29
  br label %bb117
bb117:
  %t448 = load ptr, ptr %l10, !tbaa !29
  store ptr %t448, ptr %l204, !tbaa !29
  %t449 = load ptr, ptr %l0, !tbaa !29
  %t450 = load i32, ptr %l11, !tbaa !23
  %t453 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t449, i32 %t450)
  store %"compiler/source:Span" %t453, ptr %l207
  br label %bb118
bb118:
  %t454 = load i32, ptr %l12, !tbaa !23
  %t455 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t456 = load i1, ptr %l14, !tbaa !21
  %t457 = load ptr, ptr %l17, !tbaa !29
  %t458 = load %"compiler/source:Span", ptr %l207
  %t463 = call %"compiler/ast:CaseDecl" @compiler_2fast_3aCaseDecl_2ector(ptr %v1, ptr %v1, ptr %v1, %"compiler/source:Span" %t458, i32 %t454, { i64, ptr } %t455, i1 %t456, ptr %t457)
  store %"compiler/ast:CaseDecl" %t463, ptr %l212
  br label %bb119
bb119:
  %t464 = load %"compiler/ast:CaseDecl", ptr %l212
  %t465 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 48, i64 8)
  store %"compiler/ast:CaseDecl" %t464, ptr %t465
  %t466 = load ptr, ptr %l204, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aCaseDecl_26_3e_2ePush_H43bc1cace347592514b4248ffd44c907(ptr %v1, ptr %v1, ptr %t466, ptr %t465)
  br label %bb120
bb120:
  %t468 = load ptr, ptr %l0, !tbaa !29
  %t470 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eentryEnd(ptr %v0, ptr %t468)
  store i32 %t470, ptr %l215
  %t471 = icmp ne i32 %t470, 0
  br i1 %t471, label %bb122, label %ok.472, !prof !99
ok.472:
  br label %bb121
bb121:
  br label %bb123
bb122:
  %t473 = load i32, ptr %l215, !tbaa !23
  %t474 = lshr i32 %t473, 16
  %t475 = and i32 %t473, 65535
  %t476 = icmp eq i32 %t474, 1
  %t477 = select i1 %t476, i32 1, i32 0
  %t478 = icmp eq i32 %t473, 0
  %t479 = shl i32 %t477, 16
  %t480 = or i32 %t479, %t475
  %t481 = select i1 %t478, i32 0, i32 %t480
  %t483 = insertvalue { i32, ptr } zeroinitializer, i32 %t481, 0
  store { i32, ptr } %t483, ptr %rv
  br label %ret
bb123:
  br label %bb124
bb124:
  br label %bb65
bb125:
  %t484 = load ptr, ptr %l0, !tbaa !29
  %t486 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t484)
  store i32 %t486, ptr %l218
  br label %bb126
bb126:
  %t487 = load ptr, ptr %l10, !tbaa !29
  %t489 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aCaseDecl_26_3e_2eToAr_H44f8de0685d71649bf169c234c7a8f4c(ptr %v1, ptr %v1, ptr %t487)
  store { i64, ptr } %t489, ptr %l220
  br label %bb127
bb127:
  %t490 = load ptr, ptr %l9, !tbaa !29
  store { i64, [6 x i64] } zeroinitializer, ptr %t491
  %t492 = getelementptr { i64, [6 x i64] }, ptr %t491, i32 0, i32 0
  store i64 1, ptr %t492
  %t493 = load { i64, ptr }, ptr %l220, !tbaa !27
  %t494 = insertvalue { { i64, ptr }, ptr } undef, { i64, ptr } %t493, 0
  %t496 = insertvalue { { i64, ptr }, ptr } %t494, ptr %t490, 1
  %t497 = getelementptr { i64, [6 x i64] }, ptr %t491, i32 0, i32 1
  store { { i64, ptr }, ptr } %t496, ptr %t497
  %t498 = load { i64, [6 x i64] }, ptr %t491
  %t500 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 56, i64 8)
  store { i64, [6 x i64] } %t498, ptr %t500
  %t502 = insertvalue { i32, ptr } zeroinitializer, ptr %t500, 1
  store { i32, ptr } %t502, ptr %rv
  br label %ret
bb128:
  %t503 = load i32, ptr %l1, !range !{i32 0, i32 116}
  %t505 = trunc i64 36 to i32
  %t506 = icmp eq i32 %t503, %t505
  br i1 %t506, label %bb129, label %bb130
bb129:
  br label %bb131
bb130:
  br label %bb213
bb131:
  %t508 = load ptr, ptr %l0, !tbaa !29
  %t510 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t508)
  store i32 %t510, ptr %l227
  br label %bb132
bb132:
  %t511 = load ptr, ptr %l0, !tbaa !29
  %t514 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeList(ptr %v0, ptr %v1, ptr %t511, i32 22)
  %t515 = extractvalue { i32, { i64, ptr } } %t514, 1
  %t516 = extractvalue { i32, { i64, ptr } } %t514, 0
  store i32 %t516, ptr %l232
  %t517 = icmp ne i32 %t516, 0
  br i1 %t517, label %bb134, label %ok.518, !prof !99
ok.518:
  store { i64, ptr } %t515, ptr %l231
  br label %bb133
bb133:
  %t519 = load { i64, ptr }, ptr %l231, !tbaa !27
  store { i64, ptr } %t519, ptr %l228, !tbaa !27
  br label %bb135
bb134:
  %t520 = load i32, ptr %l232, !tbaa !23
  %t521 = lshr i32 %t520, 16
  %t522 = and i32 %t520, 65535
  %t523 = icmp eq i32 %t521, 1
  %t524 = select i1 %t523, i32 1, i32 0
  %t525 = icmp eq i32 %t520, 0
  %t526 = shl i32 %t524, 16
  %t527 = or i32 %t526, %t522
  %t528 = select i1 %t525, i32 0, i32 %t527
  %t530 = insertvalue { i32, ptr } zeroinitializer, i32 %t528, 0
  store { i32, ptr } %t530, ptr %rv
  br label %ret
bb135:
  %t531 = load { i64, ptr }, ptr %l228, !tbaa !27
  store { i64, ptr } %t531, ptr %l18, !tbaa !27
  %t532 = load ptr, ptr %l0, !tbaa !29
  %t535 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeList(ptr %v0, ptr %v1, ptr %t532, i32 25)
  %t536 = extractvalue { i32, { i64, ptr } } %t535, 1
  %t537 = extractvalue { i32, { i64, ptr } } %t535, 0
  store i32 %t537, ptr %l238
  %t538 = icmp ne i32 %t537, 0
  br i1 %t538, label %bb137, label %ok.539, !prof !99
ok.539:
  store { i64, ptr } %t536, ptr %l237
  br label %bb136
bb136:
  %t540 = load { i64, ptr }, ptr %l237, !tbaa !27
  store { i64, ptr } %t540, ptr %l234, !tbaa !27
  br label %bb138
bb137:
  %t541 = load i32, ptr %l238, !tbaa !23
  %t542 = lshr i32 %t541, 16
  %t543 = and i32 %t541, 65535
  %t544 = icmp eq i32 %t542, 1
  %t545 = select i1 %t544, i32 1, i32 0
  %t546 = icmp eq i32 %t541, 0
  %t547 = shl i32 %t545, 16
  %t548 = or i32 %t547, %t543
  %t549 = select i1 %t546, i32 0, i32 %t548
  %t551 = insertvalue { i32, ptr } zeroinitializer, i32 %t549, 0
  store { i32, ptr } %t551, ptr %rv
  br label %ret
bb138:
  %t552 = load { i64, ptr }, ptr %l234, !tbaa !27
  store { i64, ptr } %t552, ptr %l19, !tbaa !27
  %t553 = load ptr, ptr %l0, !tbaa !29
  %t556 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %t553, i32 114)
  %t557 = extractvalue { i32, i32 } %t556, 1
  %t558 = extractvalue { i32, i32 } %t556, 0
  store i32 %t558, ptr %l244
  %t559 = icmp ne i32 %t558, 0
  br i1 %t559, label %bb140, label %ok.560, !prof !99
ok.560:
  store i32 %t557, ptr %l243
  br label %bb139
bb139:
  %t561 = load i32, ptr %l243, !tbaa !23
  store i32 %t561, ptr %l240, !tbaa !23
  br label %bb141
bb140:
  %t562 = load i32, ptr %l244, !tbaa !23
  %t563 = lshr i32 %t562, 16
  %t564 = and i32 %t562, 65535
  %t565 = icmp eq i32 %t563, 1
  %t566 = select i1 %t565, i32 1, i32 0
  %t567 = icmp eq i32 %t562, 0
  %t568 = shl i32 %t566, 16
  %t569 = or i32 %t568, %t564
  %t570 = select i1 %t567, i32 0, i32 %t569
  %t572 = insertvalue { i32, ptr } zeroinitializer, i32 %t570, 0
  store { i32, ptr } %t572, ptr %rv
  br label %ret
bb141:
  %t573 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aFunc_26_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t573, ptr %l246
  br label %bb142
bb142:
  %t574 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l246
  %t575 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t574, ptr %t575
  store ptr %t575, ptr %l20, !tbaa !29
  %t577 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2eskipEnds(ptr %v0, ptr %t577)
  br label %bb143
bb143:
  br label %bb144
bb144:
  %t579 = load ptr, ptr %l0, !tbaa !29
  %t582 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t579, i32 115)
  store i1 %t582, ptr %l251
  br label %bb145
bb145:
  %t583 = load i1, ptr %l251, !tbaa !21
  %t584 = xor i1 %t583, true
  %t586 = xor i1 %t584, true
  br i1 %t586, label %bb146, label %bb147
bb146:
  br label %bb210
bb147:
  br label %bb148
bb148:
  %t588 = load ptr, ptr %l0, !tbaa !29
  %t590 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ehere(ptr %v0, ptr %t588)
  store i32 %t590, ptr %l255
  br label %bb149
bb149:
  %t591 = load i32, ptr %l255, !tbaa !23
  store i32 %t591, ptr %l21, !tbaa !23
  store ptr null, ptr %l22, !tbaa !29
  %t592 = load ptr, ptr %l0, !tbaa !29
  %t595 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t592, i32 39)
  store i1 %t595, ptr %l258
  br label %bb150
bb150:
  %t596 = load i1, ptr %l258, !tbaa !21
  br i1 %t596, label %bb151, label %bb152
bb151:
  store %olang.scope zeroinitializer, ptr %s13
  %t597 = load ptr, ptr %l0, !tbaa !29
  %t599 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2etk(ptr %v0, ptr %t597)
  store %"compiler/token:Token" %t599, ptr %l260
  br label %bb153
bb152:
  br label %bb157
bb153:
  %t600 = load %"compiler/token:Token", ptr %l260
  store %"compiler/token:Token" %t600, ptr %l23
  %t601 = load ptr, ptr %l0, !tbaa !29
  %t603 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t601)
  store i32 %t603, ptr %l262
  br label %bb154
bb154:
  %t604 = getelementptr %"compiler/token:Token", ptr %l23, i32 0, i32 2
  %t605 = load i32, ptr %t604, !tbaa !23
  %t606 = getelementptr %"compiler/token:Token", ptr %l23, i32 0, i32 3
  %t607 = load i32, ptr %t606, !tbaa !23
  %t610 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s13, i32 %t605, i32 %t607)
  store %"compiler/source:Span" %t610, ptr %l265
  br label %bb155
bb155:
  %t611 = load %"compiler/source:Span", ptr %l265
  store %"compiler/source:Span" %t611, ptr %l24
  %t612 = load %"compiler/source:Span", ptr %l24
  %t613 = load %"compiler/source:Span", ptr %l24
  store { i64, [5 x i64] } zeroinitializer, ptr %t614
  %t615 = getelementptr { i64, [5 x i64] }, ptr %t614, i32 0, i32 0
  store i64 4, ptr %t615
  %t617 = insertvalue { %"compiler/source:Span", ptr, i1 } undef, %"compiler/source:Span" %t613, 0
  %t618 = insertvalue { %"compiler/source:Span", ptr, i1 } %t617, ptr null, 1
  %t619 = insertvalue { %"compiler/source:Span", ptr, i1 } %t618, i1 true, 2
  %t620 = getelementptr { i64, [5 x i64] }, ptr %t614, i32 0, i32 1
  store { %"compiler/source:Span", ptr, i1 } %t619, ptr %t620
  %t621 = load { i64, [5 x i64] }, ptr %t614
  %t623 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 48, i64 8)
  store { i64, [5 x i64] } %t621, ptr %t623
  %t626 = call %"compiler/ast:Param" @compiler_2fast_3aParam_2ector(ptr %v1, ptr %v1, ptr %v1, %"compiler/source:Span" %t612, i32 0, ptr %t623, ptr null)
  store %"compiler/ast:Param" %t626, ptr %l270
  br label %bb156
bb156:
  %t627 = load %"compiler/ast:Param", ptr %l270
  %t628 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 32, i64 8)
  store %"compiler/ast:Param" %t627, ptr %t628
  store ptr %t628, ptr %l22, !tbaa !29
  call void @__olang_scope_close(ptr %s13)
  br label %bb157
bb157:
  store ptr null, ptr %l25, !tbaa !29
  store i32 0, ptr %l26, !tbaa !23
  store i32 0, ptr %l27, !tbaa !23
  %t630 = load ptr, ptr %l22, !tbaa !29
  %t632 = icmp eq ptr %t630, null
  br i1 %t632, label %bb158, label %bb159
bb158:
  %t634 = load ptr, ptr %l0, !tbaa !29
  %t637 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t634, i32 1)
  store i1 %t637, ptr %l277
  br label %bb160
bb159:
  store i1 false, ptr %l274, !tbaa !21
  br label %bb161
bb160:
  %t638 = load i1, ptr %l277, !tbaa !21
  store i1 %t638, ptr %l274, !tbaa !21
  br label %bb161
bb161:
  %t639 = load i1, ptr %l274, !tbaa !21
  br i1 %t639, label %bb162, label %bb163
bb162:
  %t640 = load ptr, ptr %l0, !tbaa !29
  %t642 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elook(ptr %v0, ptr %t640, i64 1)
  store i32 %t642, ptr %l280
  br label %bb164
bb163:
  store i1 false, ptr %l278, !tbaa !21
  br label %bb165
bb164:
  %t643 = load i32, ptr %l280, !range !{i32 0, i32 116}
  %t645 = trunc i64 76 to i32
  %t646 = icmp eq i32 %t643, %t645
  store i1 %t646, ptr %l278, !tbaa !21
  br label %bb165
bb165:
  %t648 = load i1, ptr %l278, !tbaa !21
  br i1 %t648, label %bb166, label %bb167
bb166:
  %t649 = load ptr, ptr %l0, !tbaa !29
  %t651 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2etk(ptr %v0, ptr %t649)
  store %"compiler/token:Token" %t651, ptr %l284
  br label %bb168
bb167:
  br label %bb182
bb168:
  %t652 = load %"compiler/token:Token", ptr %l284
  store %"compiler/token:Token" %t652, ptr %l28
  %t653 = load ptr, ptr %l0, !tbaa !29
  %t655 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ename(ptr %v0, ptr %t653)
  %t656 = extractvalue { i32, i32 } %t655, 1
  %t657 = extractvalue { i32, i32 } %t655, 0
  store i32 %t657, ptr %l288
  %t658 = icmp ne i32 %t657, 0
  br i1 %t658, label %bb170, label %ok.659, !prof !99
ok.659:
  store i32 %t656, ptr %l287
  br label %bb169
bb169:
  %t660 = load i32, ptr %l287, !tbaa !23
  store i32 %t660, ptr %l285, !tbaa !23
  br label %bb171
bb170:
  %t661 = load i32, ptr %l288, !tbaa !23
  %t662 = lshr i32 %t661, 16
  %t663 = and i32 %t661, 65535
  %t664 = icmp eq i32 %t662, 1
  %t665 = select i1 %t664, i32 1, i32 0
  %t666 = icmp eq i32 %t661, 0
  %t667 = shl i32 %t665, 16
  %t668 = or i32 %t667, %t663
  %t669 = select i1 %t666, i32 0, i32 %t668
  %t671 = insertvalue { i32, ptr } zeroinitializer, i32 %t669, 0
  store { i32, ptr } %t671, ptr %rv
  br label %ret
bb171:
  %t672 = load i32, ptr %l285, !tbaa !23
  store i32 %t672, ptr %l27, !tbaa !23
  %t673 = getelementptr %"compiler/token:Token", ptr %l28, i32 0, i32 2
  %t674 = load i32, ptr %t673, !tbaa !23
  %t675 = getelementptr %"compiler/token:Token", ptr %l28, i32 0, i32 3
  %t676 = load i32, ptr %t675, !tbaa !23
  %t679 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v1, i32 %t674, i32 %t676)
  store %"compiler/source:Span" %t679, ptr %l292
  br label %bb172
bb172:
  %t680 = load i32, ptr %l27, !tbaa !23
  store i32 %t680, ptr %l293, !tbaa !23
  %t681 = icmp sge i64 1, 0
  br i1 %t681, label %bb173, label %bb174
bb173:
  %t683 = icmp sle i64 1, 2305843009213693951
  br i1 %t683, label %bb175, label %bb176
bb174:
  call void @__olang_check_failed(ptr @olang_loc_2302adf5d350ae95_7d513dc9152d99f9)
  unreachable
bb175:
  %t685 = mul i64 1, 4
  %t686 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t685)
  %t687 = load i32, ptr %l293, !tbaa !23
  store i64 0, ptr %t688
  br label %fill.689
fill.689:
  %t692 = load i64, ptr %t688
  %t693 = icmp slt i64 %t692, 1
  br i1 %t693, label %fillb.690, label %filld.691
fillb.690:
  %t694 = getelementptr i32, ptr %t686, i64 %t692
  store i32 %t687, ptr %t694
  %t695 = add i64 %t692, 1
  store i64 %t695, ptr %t688
  br label %fill.689
filld.691:
  %t696 = insertvalue { i64, ptr } undef, i64 1, 0
  %t697 = insertvalue { i64, ptr } %t696, ptr %t686, 1
  store { i64, ptr } %t697, ptr %l296, !tbaa !27
  %t698 = icmp sge i64 0, 0
  br i1 %t698, label %bb177, label %bb178
bb176:
  call void @__olang_check_failed(ptr @olang_loc_2302adf5d350ae95_7d513dc9152d99f9)
  unreachable
bb177:
  %t700 = icmp sle i64 0, 1152921504606846975
  br i1 %t700, label %bb179, label %bb180
bb178:
  call void @__olang_check_failed(ptr @olang_loc_2302adf5d350ae95_7d513dc9152d99f9)
  unreachable
bb179:
  %t702 = mul i64 0, 8
  %t703 = insertvalue { i64, ptr } undef, i64 0, 0
  %t704 = insertvalue { i64, ptr } %t703, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, [5 x i64] } zeroinitializer, ptr %t705
  %t706 = getelementptr { i64, [5 x i64] }, ptr %t705, i32 0, i32 0
  store i64 0, ptr %t706
  %t707 = load %"compiler/source:Span", ptr %l292
  %t708 = insertvalue { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } undef, %"compiler/source:Span" %t707, 0
  %t709 = load { i64, ptr }, ptr %l296, !tbaa !27
  %t710 = insertvalue { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } %t708, { i64, ptr } %t709, 1
  %t712 = insertvalue { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } %t710, { i64, ptr } %t704, 2
  %t713 = getelementptr { i64, [5 x i64] }, ptr %t705, i32 0, i32 1
  store { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } %t712, ptr %t713
  %t714 = load { i64, [5 x i64] }, ptr %t705
  %t716 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 48, i64 8)
  store { i64, [5 x i64] } %t714, ptr %t716
  store ptr %t716, ptr %l25, !tbaa !29
  %t718 = load ptr, ptr %l0, !tbaa !29
  %t720 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t718)
  store i32 %t720, ptr %l303
  br label %bb181
bb180:
  call void @__olang_check_failed(ptr @olang_loc_2302adf5d350ae95_7d513dc9152d99f9)
  unreachable
bb181:
  br label %bb182
bb182:
  %t721 = load ptr, ptr %l0, !tbaa !29
  %t723 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2emethodName(ptr %v0, ptr %t721)
  %t724 = extractvalue { i32, i32 } %t723, 1
  %t725 = extractvalue { i32, i32 } %t723, 0
  store i32 %t725, ptr %l307
  %t726 = icmp ne i32 %t725, 0
  br i1 %t726, label %bb184, label %ok.727, !prof !99
ok.727:
  store i32 %t724, ptr %l306
  br label %bb183
bb183:
  %t728 = load i32, ptr %l306, !tbaa !23
  store i32 %t728, ptr %l304, !tbaa !23
  br label %bb185
bb184:
  %t729 = load i32, ptr %l307, !tbaa !23
  %t730 = lshr i32 %t729, 16
  %t731 = and i32 %t729, 65535
  %t732 = icmp eq i32 %t730, 1
  %t733 = select i1 %t732, i32 1, i32 0
  %t734 = icmp eq i32 %t729, 0
  %t735 = shl i32 %t733, 16
  %t736 = or i32 %t735, %t731
  %t737 = select i1 %t734, i32 0, i32 %t736
  %t739 = insertvalue { i32, ptr } zeroinitializer, i32 %t737, 0
  store { i32, ptr } %t739, ptr %rv
  br label %ret
bb185:
  %t740 = load i32, ptr %l304, !tbaa !23
  store i32 %t740, ptr %l29, !tbaa !23
  %t741 = load ptr, ptr %l25, !tbaa !29
  %t743 = icmp eq ptr %t741, null
  %t745 = xor i1 %t743, true
  br i1 %t745, label %bb186, label %bb187
bb186:
  store %olang.scope zeroinitializer, ptr %s15
  %t747 = load i32, ptr %l29, !tbaa !23
  store i32 %t747, ptr %l26, !tbaa !23
  %t749 = load ptr, ptr %l0, !tbaa !29
  %t751 = getelementptr %"compiler/parse:Parser", ptr %t749, i32 0, i32 2
  %t752 = load ptr, ptr %t751, !tbaa !29
  store ptr %t752, ptr %l314, !tbaa !29
  %t753 = load ptr, ptr %l0, !tbaa !29
  %t755 = getelementptr %"compiler/parse:Parser", ptr %t753, i32 0, i32 2
  %t756 = load ptr, ptr %t755, !tbaa !29
  %t757 = load i32, ptr %l27, !tbaa !23
  %t760 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %s15, ptr %t756, i32 %t757)
  store { i64, ptr } %t760, ptr %l318
  br label %bb188
bb187:
  br label %bb191
bb188:
  %t761 = load ptr, ptr %l0, !tbaa !29
  %t763 = getelementptr %"compiler/parse:Parser", ptr %t761, i32 0, i32 2
  %t764 = load ptr, ptr %t763, !tbaa !29
  %t765 = load i32, ptr %l26, !tbaa !23
  %t768 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %s15, ptr %t764, i32 %t765)
  store { i64, ptr } %t768, ptr %l322
  br label %bb189
bb189:
  %t769 = load { i64, ptr }, ptr %l318, !tbaa !27
  %t770 = extractvalue { i64, ptr } %t769, 1
  %t771 = extractvalue { i64, ptr } %t769, 0
  %t772 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d22, i32 0, i32 1) }, 1
  %t773 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d22, i32 0, i32 1) }, 0
  %t774 = add i64 %t771, %t773
  %t775 = load { i64, ptr }, ptr %l322, !tbaa !27
  %t776 = extractvalue { i64, ptr } %t775, 1
  %t777 = extractvalue { i64, ptr } %t775, 0
  %t778 = add i64 %t774, %t777
  %t779 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t778)
  call void @olang_textcopy(ptr %t779, ptr %t770, i64 %t771)
  %t780 = getelementptr i8, ptr %t779, i64 %t771
  call void @olang_textcopy(ptr %t780, ptr %t772, i64 %t773)
  %t781 = getelementptr i8, ptr %t780, i64 %t773
  call void @olang_textcopy(ptr %t781, ptr %t776, i64 %t777)
  %t782 = insertvalue { i64, ptr } undef, i64 %t778, 0
  %t783 = insertvalue { i64, ptr } %t782, ptr %t779, 1
  %t785 = load ptr, ptr %l314, !tbaa !29
  %t787 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %s15, ptr %t785, { i64, ptr } %t783)
  store i32 %t787, ptr %l325
  br label %bb190
bb190:
  %t788 = load i32, ptr %l325, !tbaa !23
  store i32 %t788, ptr %l29, !tbaa !23
  call void @__olang_scope_close(ptr %s15)
  br label %bb191
bb191:
  %t789 = load ptr, ptr %l0, !tbaa !29
  %t791 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2esig(ptr %v0, ptr %v1, ptr %t789, i1 false, i1 false, i1 true, i1 true, i1 false)
  %t792 = extractvalue { i32, ptr } %t791, 1
  %t793 = extractvalue { i32, ptr } %t791, 0
  store i32 %t793, ptr %l329
  %t794 = icmp ne i32 %t793, 0
  br i1 %t794, label %bb193, label %ok.795, !prof !99
ok.795:
  store ptr %t792, ptr %l328
  br label %bb192
bb192:
  %t796 = load ptr, ptr %l328, !tbaa !29
  store ptr %t796, ptr %l326, !tbaa !29
  br label %bb194
bb193:
  %t797 = load i32, ptr %l329, !tbaa !23
  %t798 = lshr i32 %t797, 16
  %t799 = and i32 %t797, 65535
  %t800 = icmp eq i32 %t798, 1
  %t801 = select i1 %t800, i32 1, i32 0
  %t802 = icmp eq i32 %t797, 0
  %t803 = shl i32 %t801, 16
  %t804 = or i32 %t803, %t799
  %t805 = select i1 %t802, i32 0, i32 %t804
  %t807 = insertvalue { i32, ptr } zeroinitializer, i32 %t805, 0
  store { i32, ptr } %t807, ptr %rv
  br label %ret
bb194:
  %t808 = load ptr, ptr %l326, !tbaa !29
  store ptr %t808, ptr %l30, !tbaa !29
  %t809 = load ptr, ptr %l20, !tbaa !29
  store ptr %t809, ptr %l331, !tbaa !29
  %t810 = load ptr, ptr %l0, !tbaa !29
  %t811 = load i32, ptr %l21, !tbaa !23
  %t814 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t810, i32 %t811)
  store %"compiler/source:Span" %t814, ptr %l334
  br label %bb195
bb195:
  %t815 = load ptr, ptr %l22, !tbaa !29
  store ptr %t815, ptr %l335, !tbaa !29
  %t816 = load i32, ptr %l29, !tbaa !23
  store i32 %t816, ptr %l336, !tbaa !23
  %t817 = load ptr, ptr %l30, !tbaa !29
  store ptr %t817, ptr %l337, !tbaa !29
  %t818 = icmp sge i64 0, 0
  br i1 %t818, label %bb196, label %bb197
bb196:
  %t820 = icmp sle i64 0, 1152921504606846975
  br i1 %t820, label %bb198, label %bb199
bb197:
  call void @__olang_check_failed(ptr @olang_loc_46374d1b7bb67262_72dce1a2b91be04e)
  unreachable
bb198:
  %t822 = mul i64 0, 8
  %t823 = insertvalue { i64, ptr } undef, i64 0, 0
  %t824 = insertvalue { i64, ptr } %t823, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t824, ptr %l340, !tbaa !27
  %t825 = icmp sge i64 0, 0
  br i1 %t825, label %bb200, label %bb201
bb199:
  call void @__olang_check_failed(ptr @olang_loc_46374d1b7bb67262_72dce1a2b91be04e)
  unreachable
bb200:
  %t827 = icmp sle i64 0, 1152921504606846975
  br i1 %t827, label %bb202, label %bb203
bb201:
  call void @__olang_check_failed(ptr @olang_loc_46374d1b7bb67262_72dce1a2b91be04e)
  unreachable
bb202:
  %t829 = mul i64 0, 8
  %t830 = insertvalue { i64, ptr } undef, i64 0, 0
  %t831 = insertvalue { i64, ptr } %t830, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t832 = load ptr, ptr %l25, !tbaa !29
  %t833 = load i32, ptr %l26, !tbaa !23
  %t834 = load %"compiler/source:Span", ptr %l334
  %t835 = load ptr, ptr %l335, !tbaa !29
  %t836 = load i32, ptr %l336, !tbaa !23
  %t837 = load ptr, ptr %l337, !tbaa !29
  %t838 = load { i64, ptr }, ptr %l340, !tbaa !27
  %t842 = call %"compiler/ast:Func" @compiler_2fast_3aFunc_2ector(ptr %v1, ptr %v1, ptr %v1, ptr %v1, ptr %v1, ptr %v1, %"compiler/source:Span" %t834, ptr %t835, i32 %t836, ptr %t837, { i64, ptr } %t838, { i64, ptr } %t831, i1 false, i1 false, ptr %t832, i32 %t833)
  store %"compiler/ast:Func" %t842, ptr %l346
  br label %bb204
bb203:
  call void @__olang_check_failed(ptr @olang_loc_46374d1b7bb67262_72dce1a2b91be04e)
  unreachable
bb204:
  %t843 = load %"compiler/ast:Func", ptr %l346
  %t844 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 88, i64 8)
  store %"compiler/ast:Func" %t843, ptr %t844
  %t845 = load ptr, ptr %l331, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aFunc_26_3e_2ePush_3ccompiler_2fast_3aFunc_26_3e(ptr %v1, ptr %v1, ptr %t845, ptr %t844)
  br label %bb205
bb205:
  %t847 = load ptr, ptr %l0, !tbaa !29
  %t849 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eentryEnd(ptr %v0, ptr %t847)
  store i32 %t849, ptr %l349
  %t850 = icmp ne i32 %t849, 0
  br i1 %t850, label %bb207, label %ok.851, !prof !99
ok.851:
  br label %bb206
bb206:
  br label %bb208
bb207:
  %t852 = load i32, ptr %l349, !tbaa !23
  %t853 = lshr i32 %t852, 16
  %t854 = and i32 %t852, 65535
  %t855 = icmp eq i32 %t853, 1
  %t856 = select i1 %t855, i32 1, i32 0
  %t857 = icmp eq i32 %t852, 0
  %t858 = shl i32 %t856, 16
  %t859 = or i32 %t858, %t854
  %t860 = select i1 %t857, i32 0, i32 %t859
  %t862 = insertvalue { i32, ptr } zeroinitializer, i32 %t860, 0
  store { i32, ptr } %t862, ptr %rv
  br label %ret
bb208:
  br label %bb209
bb209:
  br label %bb144
bb210:
  %t863 = load ptr, ptr %l0, !tbaa !29
  %t865 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t863)
  store i32 %t865, ptr %l352
  br label %bb211
bb211:
  %t866 = load ptr, ptr %l20, !tbaa !29
  %t868 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aFunc_26_3e_2eToArray_3ccompiler_2fast_3aFunc_26_3e(ptr %v1, ptr %v1, ptr %t866)
  store { i64, ptr } %t868, ptr %l354
  br label %bb212
bb212:
  %t869 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t870 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, [6 x i64] } zeroinitializer, ptr %t871
  %t872 = getelementptr { i64, [6 x i64] }, ptr %t871, i32 0, i32 0
  store i64 2, ptr %t872
  %t873 = load { i64, ptr }, ptr %l354, !tbaa !27
  %t874 = insertvalue { { i64, ptr }, { i64, ptr }, { i64, ptr } } undef, { i64, ptr } %t873, 0
  %t876 = insertvalue { { i64, ptr }, { i64, ptr }, { i64, ptr } } %t874, { i64, ptr } %t869, 1
  %t878 = insertvalue { { i64, ptr }, { i64, ptr }, { i64, ptr } } %t876, { i64, ptr } %t870, 2
  %t879 = getelementptr { i64, [6 x i64] }, ptr %t871, i32 0, i32 1
  store { { i64, ptr }, { i64, ptr }, { i64, ptr } } %t878, ptr %t879
  %t880 = load { i64, [6 x i64] }, ptr %t871
  %t882 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 56, i64 8)
  store { i64, [6 x i64] } %t880, ptr %t882
  %t884 = insertvalue { i32, ptr } zeroinitializer, ptr %t882, 1
  store { i32, ptr } %t884, ptr %rv
  br label %ret
bb213:
  br i1 true, label %bb214, label %bb215
bb214:
  br label %bb216
bb215:
  br label %bb249
bb216:
  %t885 = load ptr, ptr %l0, !tbaa !29
  %t887 = getelementptr %"compiler/parse:Parser", ptr %t885, i32 0, i32 13
  store i1 true, ptr %t887, !tbaa !21
  %t888 = load ptr, ptr %l0, !tbaa !29
  %t890 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeExpr(ptr %v0, ptr %v1, ptr %t888)
  %t891 = extractvalue { i32, ptr } %t890, 1
  %t892 = extractvalue { i32, ptr } %t890, 0
  store i32 %t892, ptr %l363
  %t893 = icmp ne i32 %t892, 0
  br i1 %t893, label %bb218, label %ok.894, !prof !99
ok.894:
  store ptr %t891, ptr %l362
  br label %bb217
bb217:
  %t895 = load ptr, ptr %l362, !tbaa !29
  store ptr %t895, ptr %l360, !tbaa !29
  br label %bb219
bb218:
  %t896 = load i32, ptr %l363, !tbaa !23
  %t897 = lshr i32 %t896, 16
  %t898 = and i32 %t896, 65535
  %t899 = icmp eq i32 %t897, 1
  %t900 = select i1 %t899, i32 1, i32 0
  %t901 = icmp eq i32 %t896, 0
  %t902 = shl i32 %t900, 16
  %t903 = or i32 %t902, %t898
  %t904 = select i1 %t901, i32 0, i32 %t903
  %t906 = insertvalue { i32, ptr } zeroinitializer, i32 %t904, 0
  store { i32, ptr } %t906, ptr %rv
  br label %ret
bb219:
  %t907 = load ptr, ptr %l360, !tbaa !29
  store ptr %t907, ptr %l31, !tbaa !29
  %t908 = load ptr, ptr %l0, !tbaa !29
  %t910 = getelementptr %"compiler/parse:Parser", ptr %t908, i32 0, i32 13
  store i1 false, ptr %t910, !tbaa !21
  %t911 = load ptr, ptr %l0, !tbaa !29
  %t914 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t911, i32 110)
  store i1 %t914, ptr %l368
  br label %bb220
bb220:
  %t915 = load i1, ptr %l368, !tbaa !21
  br i1 %t915, label %bb221, label %bb222
bb221:
  %t916 = load ptr, ptr %l0, !tbaa !29
  %t918 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t916)
  store i32 %t918, ptr %l370
  br label %bb223
bb222:
  br label %bb248
bb223:
  %t919 = load i32, ptr %l370, !tbaa !23
  store i32 %t919, ptr %l32, !tbaa !23
  %t920 = load ptr, ptr %l0, !tbaa !29
  %t922 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eparams(ptr %v0, ptr %v1, ptr %t920, i1 false)
  %t923 = extractvalue { i32, { i64, ptr } } %t922, 1
  %t924 = extractvalue { i32, { i64, ptr } } %t922, 0
  store i32 %t924, ptr %l374
  %t925 = icmp ne i32 %t924, 0
  br i1 %t925, label %bb225, label %ok.926, !prof !99
ok.926:
  store { i64, ptr } %t923, ptr %l373
  br label %bb224
bb224:
  %t927 = load { i64, ptr }, ptr %l373, !tbaa !27
  store { i64, ptr } %t927, ptr %l371, !tbaa !27
  br label %bb226
bb225:
  %t928 = load i32, ptr %l374, !tbaa !23
  %t929 = lshr i32 %t928, 16
  %t930 = and i32 %t928, 65535
  %t931 = icmp eq i32 %t929, 1
  %t932 = select i1 %t931, i32 1, i32 0
  %t933 = icmp eq i32 %t928, 0
  %t934 = shl i32 %t932, 16
  %t935 = or i32 %t934, %t930
  %t936 = select i1 %t933, i32 0, i32 %t935
  %t938 = insertvalue { i32, ptr } zeroinitializer, i32 %t936, 0
  store { i32, ptr } %t938, ptr %rv
  br label %ret
bb226:
  %t939 = load { i64, ptr }, ptr %l371, !tbaa !27
  store { i64, ptr } %t939, ptr %l33, !tbaa !27
  %t940 = load ptr, ptr %l0, !tbaa !29
  %t942 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eerrorSet(ptr %v0, ptr %v1, ptr %t940, i1 false)
  %t943 = extractvalue { i32, ptr } %t942, 1
  %t944 = extractvalue { i32, ptr } %t942, 0
  store i32 %t944, ptr %l379
  %t945 = icmp ne i32 %t944, 0
  br i1 %t945, label %bb228, label %ok.946, !prof !99
ok.946:
  store ptr %t943, ptr %l378
  br label %bb227
bb227:
  %t947 = load ptr, ptr %l378, !tbaa !29
  store ptr %t947, ptr %l376, !tbaa !29
  br label %bb229
bb228:
  %t948 = load i32, ptr %l379, !tbaa !23
  %t949 = lshr i32 %t948, 16
  %t950 = and i32 %t948, 65535
  %t951 = icmp eq i32 %t949, 1
  %t952 = select i1 %t951, i32 1, i32 0
  %t953 = icmp eq i32 %t948, 0
  %t954 = shl i32 %t952, 16
  %t955 = or i32 %t954, %t950
  %t956 = select i1 %t953, i32 0, i32 %t955
  %t958 = insertvalue { i32, ptr } zeroinitializer, i32 %t956, 0
  store { i32, ptr } %t958, ptr %rv
  br label %ret
bb229:
  %t959 = load ptr, ptr %l376, !tbaa !29
  store ptr %t959, ptr %l34, !tbaa !29
  %t960 = load ptr, ptr %l0, !tbaa !29
  %t962 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ebody(ptr %v0, ptr %v1, ptr %t960)
  %t963 = extractvalue { i32, { i64, ptr } } %t962, 1
  %t964 = extractvalue { i32, { i64, ptr } } %t962, 0
  store i32 %t964, ptr %l384
  %t965 = icmp ne i32 %t964, 0
  br i1 %t965, label %bb231, label %ok.966, !prof !99
ok.966:
  store { i64, ptr } %t963, ptr %l383
  br label %bb230
bb230:
  %t967 = load { i64, ptr }, ptr %l383, !tbaa !27
  store { i64, ptr } %t967, ptr %l381, !tbaa !27
  br label %bb232
bb231:
  %t968 = load i32, ptr %l384, !tbaa !23
  %t969 = lshr i32 %t968, 16
  %t970 = and i32 %t968, 65535
  %t971 = icmp eq i32 %t969, 1
  %t972 = select i1 %t971, i32 1, i32 0
  %t973 = icmp eq i32 %t968, 0
  %t974 = shl i32 %t972, 16
  %t975 = or i32 %t974, %t970
  %t976 = select i1 %t973, i32 0, i32 %t975
  %t978 = insertvalue { i32, ptr } zeroinitializer, i32 %t976, 0
  store { i32, ptr } %t978, ptr %rv
  br label %ret
bb232:
  %t979 = load { i64, ptr }, ptr %l381, !tbaa !27
  store { i64, ptr } %t979, ptr %l35, !tbaa !27
  %t980 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t980, ptr %l386, !tbaa !27
  %t981 = icmp sge i64 0, 0
  br i1 %t981, label %bb233, label %bb234
bb233:
  %t983 = icmp sle i64 0, 1152921504606846975
  br i1 %t983, label %bb235, label %bb236
bb234:
  call void @__olang_check_failed(ptr @olang_loc_1c3aa98278e4117_19ec5e3b00828443)
  unreachable
bb235:
  %t985 = mul i64 0, 8
  %t986 = insertvalue { i64, ptr } undef, i64 0, 0
  %t987 = insertvalue { i64, ptr } %t986, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t987, ptr %l389, !tbaa !27
  %t988 = load ptr, ptr %l34, !tbaa !29
  %t990 = getelementptr %"compiler/ast:Sig", ptr %t988, i32 0, i32 2
  %t991 = load i1, ptr %t990, !tbaa !21
  store i1 %t991, ptr %l391, !tbaa !21
  %t992 = load ptr, ptr %l34, !tbaa !29
  %t994 = getelementptr %"compiler/ast:Sig", ptr %t992, i32 0, i32 3
  %t995 = load { i64, ptr }, ptr %t994, !tbaa !27
  store { i64, ptr } %t995, ptr %l393, !tbaa !27
  %t996 = icmp sge i64 0, 0
  br i1 %t996, label %bb237, label %bb238
bb236:
  call void @__olang_check_failed(ptr @olang_loc_1c3aa98278e4117_19ec5e3b00828443)
  unreachable
bb237:
  %t998 = icmp sle i64 0, 1152921504606846975
  br i1 %t998, label %bb239, label %bb240
bb238:
  call void @__olang_check_failed(ptr @olang_loc_1c3aa98278e4117_19ec5e3b00828443)
  unreachable
bb239:
  %t1000 = mul i64 0, 8
  %t1001 = insertvalue { i64, ptr } undef, i64 0, 0
  %t1002 = insertvalue { i64, ptr } %t1001, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t1003 = load { i64, ptr }, ptr %l386, !tbaa !27
  %t1004 = load { i64, ptr }, ptr %l389, !tbaa !27
  %t1005 = load i1, ptr %l391, !tbaa !21
  %t1006 = load { i64, ptr }, ptr %l393, !tbaa !27
  %t1008 = call %"compiler/ast:Sig" @compiler_2fast_3aSig_2ector(ptr %v1, ptr %v1, ptr %v1, ptr %v1, ptr %v1, { i64, ptr } %t1003, { i64, ptr } %t1004, i1 %t1005, { i64, ptr } %t1006, i1 false, i1 false, i1 false, { i64, ptr } %t1002, i1 false)
  store %"compiler/ast:Sig" %t1008, ptr %l397
  br label %bb241
bb240:
  call void @__olang_check_failed(ptr @olang_loc_1c3aa98278e4117_19ec5e3b00828443)
  unreachable
bb241:
  %t1009 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 88, i64 8)
  store ptr %t1009, ptr %lp36
  %t1010 = load %"compiler/ast:Sig", ptr %l397
  %t1011 = load ptr, ptr %lp36
  store %"compiler/ast:Sig" %t1010, ptr %t1011
  %t1012 = load ptr, ptr %l31, !tbaa !29
  store ptr %t1012, ptr %l398, !tbaa !29
  %t1013 = load ptr, ptr %l0, !tbaa !29
  %t1014 = load i32, ptr %l32, !tbaa !23
  %t1017 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t1013, i32 %t1014)
  store %"compiler/source:Span" %t1017, ptr %l401
  br label %bb242
bb242:
  %t1018 = load ptr, ptr %lp36
  store ptr %t1018, ptr %l402, !tbaa !29
  %t1019 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t1019, ptr %l403, !tbaa !27
  %t1020 = icmp sge i64 0, 0
  br i1 %t1020, label %bb243, label %bb244
bb243:
  %t1022 = icmp sle i64 0, 1152921504606846975
  br i1 %t1022, label %bb245, label %bb246
bb244:
  call void @__olang_check_failed(ptr @olang_loc_6cb001083a887f74_65a539ed4a68e820)
  unreachable
bb245:
  %t1024 = mul i64 0, 8
  %t1025 = insertvalue { i64, ptr } undef, i64 0, 0
  %t1026 = insertvalue { i64, ptr } %t1025, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t1027 = load %"compiler/source:Span", ptr %l401
  %t1028 = load ptr, ptr %l402, !tbaa !29
  %t1029 = load { i64, ptr }, ptr %l403, !tbaa !27
  %t1031 = call %"compiler/ast:Func" @compiler_2fast_3aFunc_2ector(ptr %v1, ptr %v1, ptr %v1, ptr %v1, ptr %v1, ptr %v1, %"compiler/source:Span" %t1027, ptr null, i32 0, ptr %t1028, { i64, ptr } %t1029, { i64, ptr } %t1026, i1 true, i1 false, ptr null, i32 0)
  store %"compiler/ast:Func" %t1031, ptr %l407
  br label %bb247
bb246:
  call void @__olang_check_failed(ptr @olang_loc_6cb001083a887f74_65a539ed4a68e820)
  unreachable
bb247:
  %t1032 = load %"compiler/ast:Func", ptr %l407
  %t1033 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 88, i64 8)
  store %"compiler/ast:Func" %t1032, ptr %t1033
  store { i64, [6 x i64] } zeroinitializer, ptr %t1034
  %t1035 = getelementptr { i64, [6 x i64] }, ptr %t1034, i32 0, i32 0
  store i64 3, ptr %t1035
  %t1036 = load ptr, ptr %l398, !tbaa !29
  %t1037 = insertvalue { ptr, ptr } undef, ptr %t1036, 0
  %t1039 = insertvalue { ptr, ptr } %t1037, ptr %t1033, 1
  %t1040 = getelementptr { i64, [6 x i64] }, ptr %t1034, i32 0, i32 1
  store { ptr, ptr } %t1039, ptr %t1040
  %t1041 = load { i64, [6 x i64] }, ptr %t1034
  %t1043 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 56, i64 8)
  store { i64, [6 x i64] } %t1041, ptr %t1043
  %t1045 = insertvalue { i32, ptr } zeroinitializer, ptr %t1043, 1
  store { i32, ptr } %t1045, ptr %rv
  br label %ret
bb248:
  %t1046 = load ptr, ptr %l31, !tbaa !29
  store { i64, [6 x i64] } zeroinitializer, ptr %t1047
  %t1048 = getelementptr { i64, [6 x i64] }, ptr %t1047, i32 0, i32 0
  store i64 3, ptr %t1048
  %t1050 = insertvalue { ptr, ptr } undef, ptr %t1046, 0
  %t1051 = insertvalue { ptr, ptr } %t1050, ptr null, 1
  %t1052 = getelementptr { i64, [6 x i64] }, ptr %t1047, i32 0, i32 1
  store { ptr, ptr } %t1051, ptr %t1052
  %t1053 = load { i64, [6 x i64] }, ptr %t1047
  %t1055 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 56, i64 8)
  store { i64, [6 x i64] } %t1053, ptr %t1055
  %t1057 = insertvalue { i32, ptr } zeroinitializer, ptr %t1055, 1
  store { i32, ptr } %t1057, ptr %rv
  br label %ret
bb249:
  call void @__olang_check_failed(ptr @olang_loc_d672258fb79a6f5a_5ab6544735a7871e)
  unreachable
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeDecl(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i32
  %l10 = alloca i1
  %l11 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca i32
  %l17 = alloca i32
  %l19 = alloca i32
  %l20 = alloca i32
  %l24 = alloca i1
  %l25 = alloca ptr
  %l29 = alloca ptr
  %l30 = alloca i32
  %l32 = alloca ptr
  %l36 = alloca ptr
  %l37 = alloca i32
  %l39 = alloca ptr
  %l42 = alloca %"compiler/source:Span"
  %l47 = alloca %"compiler/ast:TypeDecl"
  %rv = alloca { i32, ptr }
  %t130 = alloca { i64, [8 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t4 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %t1, i32 33)
  %t5 = extractvalue { i32, i32 } %t4, 1
  %t6 = extractvalue { i32, i32 } %t4, 0
  store i32 %t6, ptr %l7
  %t7 = icmp ne i32 %t6, 0
  br i1 %t7, label %bb2, label %ok.8, !prof !99
ok.8:
  store i32 %t5, ptr %l6
  br label %bb1
bb1:
  %t9 = load i32, ptr %l6, !tbaa !23
  store i32 %t9, ptr %l3, !tbaa !23
  br label %bb3
bb2:
  %t10 = load i32, ptr %l7, !tbaa !23
  %t11 = lshr i32 %t10, 16
  %t12 = and i32 %t10, 65535
  %t13 = icmp eq i32 %t11, 1
  %t14 = select i1 %t13, i32 1, i32 0
  %t15 = icmp eq i32 %t10, 0
  %t16 = shl i32 %t14, 16
  %t17 = or i32 %t16, %t12
  %t18 = select i1 %t15, i32 0, i32 %t17
  %t20 = insertvalue { i32, ptr } zeroinitializer, i32 %t18, 0
  store { i32, ptr } %t20, ptr %rv
  br label %ret
bb3:
  %t21 = load i32, ptr %l3, !tbaa !23
  store i32 %t21, ptr %l1, !tbaa !23
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eownerAhead(ptr %v0, ptr %t22)
  store i1 %t24, ptr %l10
  br label %bb4
bb4:
  %t25 = load i1, ptr %l10, !tbaa !21
  br i1 %t25, label %bb5, label %bb6
bb5:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t27 = load i32, ptr %l1, !tbaa !23
  %t30 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ememberDecl(ptr %v0, ptr %v1, ptr %t26, i32 %t27)
  %t31 = extractvalue { i32, ptr } %t30, 1
  %t32 = extractvalue { i32, ptr } %t30, 0
  store i32 %t32, ptr %l15
  %t33 = icmp ne i32 %t32, 0
  br i1 %t33, label %bb8, label %ok.34, !prof !99
ok.34:
  store ptr %t31, ptr %l14
  br label %bb7
bb6:
  br label %bb10
bb7:
  %t35 = load ptr, ptr %l14, !tbaa !29
  store ptr %t35, ptr %l11, !tbaa !29
  br label %bb9
bb8:
  %t36 = load i32, ptr %l15, !tbaa !23
  %t37 = lshr i32 %t36, 16
  %t38 = and i32 %t36, 65535
  %t39 = icmp eq i32 %t37, 1
  %t40 = select i1 %t39, i32 1, i32 0
  %t41 = icmp eq i32 %t36, 0
  %t42 = shl i32 %t40, 16
  %t43 = or i32 %t42, %t38
  %t44 = select i1 %t41, i32 0, i32 %t43
  %t46 = insertvalue { i32, ptr } zeroinitializer, i32 %t44, 0
  store { i32, ptr } %t46, ptr %rv
  br label %ret
bb9:
  %t47 = load ptr, ptr %l11, !tbaa !29
  %t48 = insertvalue { i32, ptr } zeroinitializer, ptr %t47, 1
  store { i32, ptr } %t48, ptr %rv
  br label %ret
bb10:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ename(ptr %v0, ptr %t49)
  %t52 = extractvalue { i32, i32 } %t51, 1
  %t53 = extractvalue { i32, i32 } %t51, 0
  store i32 %t53, ptr %l20
  %t54 = icmp ne i32 %t53, 0
  br i1 %t54, label %bb12, label %ok.55, !prof !99
ok.55:
  store i32 %t52, ptr %l19
  br label %bb11
bb11:
  %t56 = load i32, ptr %l19, !tbaa !23
  store i32 %t56, ptr %l17, !tbaa !23
  br label %bb13
bb12:
  %t57 = load i32, ptr %l20, !tbaa !23
  %t58 = lshr i32 %t57, 16
  %t59 = and i32 %t57, 65535
  %t60 = icmp eq i32 %t58, 1
  %t61 = select i1 %t60, i32 1, i32 0
  %t62 = icmp eq i32 %t57, 0
  %t63 = shl i32 %t61, 16
  %t64 = or i32 %t63, %t59
  %t65 = select i1 %t62, i32 0, i32 %t64
  %t67 = insertvalue { i32, ptr } zeroinitializer, i32 %t65, 0
  store { i32, ptr } %t67, ptr %rv
  br label %ret
bb13:
  %t68 = load i32, ptr %l17, !tbaa !23
  store i32 %t68, ptr %l2, !tbaa !23
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t72 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t69, i32 38)
  store i1 %t72, ptr %l24
  br label %bb14
bb14:
  %t73 = load i1, ptr %l24, !tbaa !21
  br i1 %t73, label %bb15, label %bb16
bb15:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t75 = load i32, ptr %l1, !tbaa !23
  %t76 = load i32, ptr %l2, !tbaa !23
  %t80 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eerrorDecl(ptr %v0, ptr %v1, ptr %t74, i32 %t75, i32 %t76)
  %t81 = extractvalue { i32, ptr } %t80, 1
  %t82 = extractvalue { i32, ptr } %t80, 0
  store i32 %t82, ptr %l30
  %t83 = icmp ne i32 %t82, 0
  br i1 %t83, label %bb18, label %ok.84, !prof !99
ok.84:
  store ptr %t81, ptr %l29
  br label %bb17
bb16:
  br label %bb20
bb17:
  %t85 = load ptr, ptr %l29, !tbaa !29
  store ptr %t85, ptr %l25, !tbaa !29
  br label %bb19
bb18:
  %t86 = load i32, ptr %l30, !tbaa !23
  %t87 = lshr i32 %t86, 16
  %t88 = and i32 %t86, 65535
  %t89 = icmp eq i32 %t87, 1
  %t90 = select i1 %t89, i32 1, i32 0
  %t91 = icmp eq i32 %t86, 0
  %t92 = shl i32 %t90, 16
  %t93 = or i32 %t92, %t88
  %t94 = select i1 %t91, i32 0, i32 %t93
  %t96 = insertvalue { i32, ptr } zeroinitializer, i32 %t94, 0
  store { i32, ptr } %t96, ptr %rv
  br label %ret
bb19:
  %t97 = load ptr, ptr %l25, !tbaa !29
  %t98 = insertvalue { i32, ptr } zeroinitializer, ptr %t97, 1
  store { i32, ptr } %t98, ptr %rv
  br label %ret
bb20:
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t100 = load i32, ptr %l1, !tbaa !23
  %t101 = load i32, ptr %l2, !tbaa !23
  %t105 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeDeclRest(ptr %v0, ptr %v1, ptr %t99, i32 %t100, i32 %t101)
  %t106 = extractvalue { i32, ptr } %t105, 1
  %t107 = extractvalue { i32, ptr } %t105, 0
  store i32 %t107, ptr %l37
  %t108 = icmp ne i32 %t107, 0
  br i1 %t108, label %bb22, label %ok.109, !prof !99
ok.109:
  store ptr %t106, ptr %l36
  br label %bb21
bb21:
  %t110 = load ptr, ptr %l36, !tbaa !29
  store ptr %t110, ptr %l32, !tbaa !29
  br label %bb27
bb22:
  br label %bb23
bb23:
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t113 = getelementptr %"compiler/parse:Parser", ptr %t111, i32 0, i32 42
  store ptr %t113, ptr %l39, !tbaa !29
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t115 = load i32, ptr %l1, !tbaa !23
  %t118 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t114, i32 %t115)
  store %"compiler/source:Span" %t118, ptr %l42
  br label %bb24
bb24:
  %t119 = load i32, ptr %l2, !tbaa !23
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t122 = getelementptr %"compiler/parse:Parser", ptr %t120, i32 0, i32 43
  %t123 = load { i64, ptr }, ptr %t122, !tbaa !27
  %t127 = call %"compiler/ast:TypeDecl" @compiler_2fast_3aTypeDecl_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, i32 %t119, { i64, ptr } %t123, i1 false, ptr null, i32 0, i1 false, ptr null, i32 0)
  store %"compiler/ast:TypeDecl" %t127, ptr %l47
  br label %bb25
bb25:
  %t128 = load %"compiler/ast:TypeDecl", ptr %l47
  %t129 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 64, i64 8)
  store %"compiler/ast:TypeDecl" %t128, ptr %t129
  store { i64, [8 x i64] } zeroinitializer, ptr %t130
  %t131 = getelementptr { i64, [8 x i64] }, ptr %t130, i32 0, i32 0
  store i64 2, ptr %t131
  %t132 = load %"compiler/source:Span", ptr %l42
  %t133 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t132, 0
  %t135 = insertvalue { %"compiler/source:Span", ptr } %t133, ptr %t129, 1
  %t136 = getelementptr { i64, [8 x i64] }, ptr %t130, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t135, ptr %t136
  %t137 = load { i64, [8 x i64] }, ptr %t130
  %t139 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 72, i64 8)
  store { i64, [8 x i64] } %t137, ptr %t139
  %t140 = load ptr, ptr %l39, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aDecl_26_3e_2ePush_3ccompiler_2fast_3aDecl_26_3e(ptr %v0, ptr %v0, ptr %t140, ptr %t139)
  br label %bb26
bb26:
  %t143 = insertvalue { i32, ptr } zeroinitializer, i32 65536, 0
  store { i32, ptr } %t143, ptr %rv
  br label %ret
bb27:
  %t144 = load ptr, ptr %l32, !tbaa !29
  %t145 = insertvalue { i32, ptr } zeroinitializer, ptr %t144, 1
  store { i32, ptr } %t145, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeDeclRest(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i1
  %l7 = alloca i1
  %l8 = alloca ptr
  %l9 = alloca %"compiler/source:Span"
  %l10 = alloca ptr
  %l19 = alloca i1
  %l20 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l23 = alloca i32
  %l30 = alloca i1
  %l31 = alloca i1
  %l34 = alloca i1
  %l35 = alloca i1
  %l38 = alloca { i64, ptr }
  %l40 = alloca i64
  %l42 = alloca i1
  %l45 = alloca i32
  %l46 = alloca i32
  %l52 = alloca ptr
  %l54 = alloca i32
  %l56 = alloca %"compiler/token:Token"
  %l57 = alloca i32
  %l58 = alloca %"compiler/diagmsg:Msg"
  %l61 = alloca i32
  %l63 = alloca i1
  %l66 = alloca i1
  %l67 = alloca ptr
  %l69 = alloca ptr
  %l70 = alloca i32
  %l74 = alloca %"compiler/source:Span"
  %l77 = alloca i1
  %l79 = alloca i32
  %l80 = alloca %"compiler/source:Span"
  %l87 = alloca %"compiler/ast:TypeDecl"
  %rv = alloca { i32, ptr }
  %t180 = alloca { i64, [8 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l10, !tbaa !29
  %t2 = icmp sge i64 0, 0
  br i1 %t2, label %bb1, label %bb2
bb1:
  %t4 = icmp sle i64 0, 1152921504606846975
  br i1 %t4, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_411e8cbc479e6c68_8a93085e0dfe7db4)
  unreachable
bb3:
  %t6 = mul i64 0, 8
  %t7 = insertvalue { i64, ptr } undef, i64 0, 0
  %t8 = insertvalue { i64, ptr } %t7, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t10 = load ptr, ptr %l10, !tbaa !29
  %t11 = getelementptr %"compiler/parse:Parser", ptr %t10, i32 0, i32 43
  store { i64, ptr } %t8, ptr %t11, !tbaa !27
  %t12 = icmp sge i64 0, 0
  br i1 %t12, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_411e8cbc479e6c68_8a93085e0dfe7db4)
  unreachable
bb5:
  %t14 = icmp sle i64 0, 1152921504606846975
  br i1 %t14, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_a3bb9cce88491c55_2084ae246c483bc1)
  unreachable
bb7:
  %t16 = mul i64 0, 8
  %t17 = insertvalue { i64, ptr } undef, i64 0, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t18, ptr %l3, !tbaa !27
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t23 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t20, i32 98)
  store i1 %t23, ptr %l19
  br label %bb9
bb8:
  call void @__olang_check_failed(ptr @olang_loc_a3bb9cce88491c55_2084ae246c483bc1)
  unreachable
bb9:
  %t24 = load i1, ptr %l19, !tbaa !21
  br i1 %t24, label %bb10, label %bb11
bb10:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeParams(ptr %v0, ptr %v1, ptr %t25)
  %t28 = extractvalue { i32, { i64, ptr } } %t27, 1
  %t29 = extractvalue { i32, { i64, ptr } } %t27, 0
  store i32 %t29, ptr %l23
  %t30 = icmp ne i32 %t29, 0
  br i1 %t30, label %bb13, label %ok.31, !prof !99
ok.31:
  store { i64, ptr } %t28, ptr %l22
  br label %bb12
bb11:
  br label %bb15
bb12:
  %t32 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t32, ptr %l20, !tbaa !27
  br label %bb14
bb13:
  %t33 = load i32, ptr %l23, !tbaa !23
  %t34 = lshr i32 %t33, 16
  %t35 = and i32 %t33, 65535
  %t36 = icmp eq i32 %t34, 1
  %t37 = select i1 %t36, i32 1, i32 0
  %t38 = icmp eq i32 %t33, 0
  %t39 = shl i32 %t37, 16
  %t40 = or i32 %t39, %t35
  %t41 = select i1 %t38, i32 0, i32 %t40
  %t43 = insertvalue { i32, ptr } zeroinitializer, i32 %t41, 0
  store { i32, ptr } %t43, ptr %rv
  br label %ret
bb14:
  %t44 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t44, ptr %l3, !tbaa !27
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t46 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t49 = getelementptr %"compiler/parse:Parser", ptr %t45, i32 0, i32 43
  store { i64, ptr } %t46, ptr %t49, !tbaa !27
  br label %bb15
bb15:
  store i32 0, ptr %l4
  br label %bb16
bb16:
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t54 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t51, i32 54)
  store i1 %t54, ptr %l30
  br label %bb17
bb17:
  %t55 = load i1, ptr %l30, !tbaa !21
  br i1 %t55, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l31, !tbaa !21
  br label %bb21
bb19:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t59 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t56, i32 53)
  store i1 %t59, ptr %l34
  br label %bb20
bb20:
  %t60 = load i1, ptr %l34, !tbaa !21
  store i1 %t60, ptr %l31, !tbaa !21
  br label %bb21
bb21:
  %t61 = load i1, ptr %l31, !tbaa !21
  br i1 %t61, label %bb22, label %bb23
bb22:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/parse:Parser", ptr %t62, i32 0, i32 1
  %t65 = load ptr, ptr %t64, !tbaa !29
  %t67 = getelementptr %"compiler/scan:Tokens", ptr %t65, i32 0, i32 0
  %t68 = load { i64, ptr }, ptr %t67, !tbaa !27
  store { i64, ptr } %t68, ptr %l38, !tbaa !27
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = call i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eafter(ptr %v0, ptr %t69, i64 1)
  store i64 %t71, ptr %l40
  br label %bb24
bb23:
  store i1 false, ptr %l35, !tbaa !21
  br label %bb26
bb24:
  %t72 = load i64, ptr %l40, !tbaa !24
  %t73 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t74 = load ptr, ptr %t73, !tbaa !27
  %t75 = getelementptr %"compiler/token:Token", ptr %t74, i64 %t72
  %t76 = getelementptr %"compiler/token:Token", ptr %t75, i32 0, i32 0
  %t77 = load i32, ptr %t76, !range !{i32 0, i32 116}
  %t79 = call i1 @compiler_2fparse_2edeclWordBody(i32 %t77)
  store i1 %t79, ptr %l42
  br label %bb25
bb25:
  %t80 = load i1, ptr %l42, !tbaa !21
  store i1 %t80, ptr %l35, !tbaa !21
  br label %bb26
bb26:
  %t81 = load i1, ptr %l35, !tbaa !21
  %t82 = xor i1 %t81, true
  br i1 %t82, label %bb27, label %bb28
bb27:
  br label %bb44
bb28:
  br label %bb29
bb29:
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2epeek(ptr %v0, ptr %t84)
  store i32 %t86, ptr %l45
  br label %bb30
bb30:
  %t87 = load i32, ptr %l45, !range !{i32 0, i32 116}
  %t88 = call i32 @compiler_2fparse_2edeclWord(i32 %t87)
  store i32 %t88, ptr %l46
  br label %bb31
bb31:
  %t89 = load i32, ptr %l46, !range !{i32 0, i32 3}
  store i32 %t89, ptr %l5
  %t90 = load i32, ptr %l5, !range !{i32 0, i32 3}
  %t92 = trunc i64 0 to i32
  %t93 = icmp eq i32 %t90, %t92
  br i1 %t93, label %bb32, label %bb33
bb32:
  br label %bb44
bb33:
  br label %bb34
bb34:
  %t95 = load i32, ptr %l4, !range !{i32 0, i32 3}
  %t97 = trunc i64 0 to i32
  %t98 = icmp eq i32 %t95, %t97
  %t100 = xor i1 %t98, true
  br i1 %t100, label %bb35, label %bb36
bb35:
  %t102 = load ptr, ptr %l0, !tbaa !29
  store ptr %t102, ptr %l52, !tbaa !29
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t105 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ehere(ptr %v0, ptr %t103)
  store i32 %t105, ptr %l54
  br label %bb37
bb36:
  br label %bb41
bb37:
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t108 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2etk(ptr %v0, ptr %t106)
  store %"compiler/token:Token" %t108, ptr %l56
  br label %bb38
bb38:
  %t109 = getelementptr %"compiler/token:Token", ptr %l56, i32 0, i32 3
  %t110 = load i32, ptr %t109, !tbaa !23
  store i32 %t110, ptr %l57, !tbaa !23
  %t111 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eUniqueImmut(ptr %v0)
  store %"compiler/diagmsg:Msg" %t111, ptr %l58
  br label %bb39
bb39:
  %t112 = load ptr, ptr %l52, !tbaa !29
  %t113 = load i32, ptr %l54, !tbaa !23
  %t114 = load i32, ptr %l57, !tbaa !23
  %t115 = load %"compiler/diagmsg:Msg", ptr %l58
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereport(ptr %v0, ptr %v0, ptr %t112, i32 %t113, i32 %t114, %"compiler/diagmsg:Msg" %t115)
  br label %bb40
bb40:
  br label %bb41
bb41:
  %t116 = load i32, ptr %l5, !range !{i32 0, i32 3}
  store i32 %t116, ptr %l4
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t120 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t118)
  store i32 %t120, ptr %l61
  br label %bb42
bb42:
  br label %bb43
bb43:
  br label %bb16
bb44:
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t123 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2epackedWord(ptr %v0, ptr %t121)
  store i1 %t123, ptr %l63
  br label %bb45
bb45:
  %t124 = load i1, ptr %l63, !tbaa !21
  store i1 %t124, ptr %l6, !tbaa !21
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t128 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t125, i32 22)
  store i1 %t128, ptr %l66
  br label %bb46
bb46:
  %t129 = load i1, ptr %l66, !tbaa !21
  store i1 %t129, ptr %l7, !tbaa !21
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t132 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeBody(ptr %v0, ptr %v1, ptr %t130)
  %t133 = extractvalue { i32, ptr } %t132, 1
  %t134 = extractvalue { i32, ptr } %t132, 0
  store i32 %t134, ptr %l70
  %t135 = icmp ne i32 %t134, 0
  br i1 %t135, label %bb48, label %ok.136, !prof !99
ok.136:
  store ptr %t133, ptr %l69
  br label %bb47
bb47:
  %t137 = load ptr, ptr %l69, !tbaa !29
  store ptr %t137, ptr %l67, !tbaa !29
  br label %bb49
bb48:
  %t138 = load i32, ptr %l70, !tbaa !23
  %t139 = lshr i32 %t138, 16
  %t140 = and i32 %t138, 65535
  %t141 = icmp eq i32 %t139, 1
  %t142 = select i1 %t141, i32 1, i32 0
  %t143 = icmp eq i32 %t138, 0
  %t144 = shl i32 %t142, 16
  %t145 = or i32 %t144, %t140
  %t146 = select i1 %t143, i32 0, i32 %t145
  %t148 = insertvalue { i32, ptr } zeroinitializer, i32 %t146, 0
  store { i32, ptr } %t148, ptr %rv
  br label %ret
bb49:
  %t149 = load ptr, ptr %l67, !tbaa !29
  store ptr %t149, ptr %l8, !tbaa !29
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t154 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t150, i32 %a1)
  store %"compiler/source:Span" %t154, ptr %l74
  br label %bb50
bb50:
  %t155 = load %"compiler/source:Span", ptr %l74
  store %"compiler/source:Span" %t155, ptr %l9
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t159 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t156, i32 8)
  store i1 %t159, ptr %l77
  br label %bb51
bb51:
  %t160 = load i1, ptr %l77, !tbaa !21
  br i1 %t160, label %bb52, label %bb53
bb52:
  %t161 = load ptr, ptr %l0, !tbaa !29
  %t163 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t161)
  store i32 %t163, ptr %l79
  br label %bb54
bb53:
  br label %bb55
bb54:
  br label %bb55
bb55:
  %t164 = load %"compiler/source:Span", ptr %l9
  store %"compiler/source:Span" %t164, ptr %l80
  %t166 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t167 = load i1, ptr %l7, !tbaa !21
  %t168 = load ptr, ptr %l8, !tbaa !29
  %t169 = load i32, ptr %l4, !range !{i32 0, i32 3}
  %t170 = load i1, ptr %l6, !tbaa !21
  %t177 = call %"compiler/ast:TypeDecl" @compiler_2fast_3aTypeDecl_2ector(ptr %v1, ptr %v1, ptr %v1, ptr %v1, i32 %a2, { i64, ptr } %t166, i1 %t167, ptr %t168, i32 %t169, i1 %t170, ptr null, i32 0)
  store %"compiler/ast:TypeDecl" %t177, ptr %l87
  br label %bb56
bb56:
  %t178 = load %"compiler/ast:TypeDecl", ptr %l87
  %t179 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 64, i64 8)
  store %"compiler/ast:TypeDecl" %t178, ptr %t179
  store { i64, [8 x i64] } zeroinitializer, ptr %t180
  %t181 = getelementptr { i64, [8 x i64] }, ptr %t180, i32 0, i32 0
  store i64 2, ptr %t181
  %t182 = load %"compiler/source:Span", ptr %l80
  %t183 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t182, 0
  %t185 = insertvalue { %"compiler/source:Span", ptr } %t183, ptr %t179, 1
  %t186 = getelementptr { i64, [8 x i64] }, ptr %t180, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t185, ptr %t186
  %t187 = load { i64, [8 x i64] }, ptr %t180
  %t189 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 72, i64 8)
  store { i64, [8 x i64] } %t187, ptr %t189
  %t191 = insertvalue { i32, ptr } zeroinitializer, ptr %t189, 1
  store { i32, ptr } %t191, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeList(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l5 = alloca i1
  %l10 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca i32
  %l18 = alloca i1
  %l21 = alloca i1
  %l22 = alloca i32
  %l26 = alloca { i64, ptr }
  %rv = alloca { i32, { i64, ptr } }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t1, i32 %a1)
  store i1 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i1, ptr %l5, !tbaa !21
  %t7 = xor i1 %t6, true
  br i1 %t7, label %bb2, label %bb3
bb2:
  %t9 = icmp sge i64 0, 0
  br i1 %t9, label %bb4, label %bb5
bb3:
  br label %bb8
bb4:
  %t11 = icmp sle i64 0, 1152921504606846975
  br i1 %t11, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_2c29cc2313aef596_a74c39ade1a5acca)
  unreachable
bb6:
  %t13 = mul i64 0, 8
  %t14 = insertvalue { i64, ptr } undef, i64 0, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t17 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t15, 1
  store { i32, { i64, ptr } } %t17, ptr %rv
  br label %ret
bb7:
  call void @__olang_check_failed(ptr @olang_loc_2c29cc2313aef596_a74c39ade1a5acca)
  unreachable
bb8:
  %t18 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aTypeRef_26_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t18, ptr %l10
  br label %bb9
bb9:
  %t19 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l10
  %t20 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t19, ptr %t20
  store ptr %t20, ptr %l2, !tbaa !29
  br label %bb10
bb10:
  %t22 = load ptr, ptr %l2, !tbaa !29
  store ptr %t22, ptr %l12, !tbaa !29
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeExpr(ptr %v0, ptr %v0, ptr %t23)
  %t26 = extractvalue { i32, ptr } %t25, 1
  %t27 = extractvalue { i32, ptr } %t25, 0
  store i32 %t27, ptr %l16
  %t28 = icmp ne i32 %t27, 0
  br i1 %t28, label %bb12, label %ok.29, !prof !99
ok.29:
  store ptr %t26, ptr %l15
  br label %bb11
bb11:
  %t30 = load ptr, ptr %l15, !tbaa !29
  store ptr %t30, ptr %l13, !tbaa !29
  br label %bb13
bb12:
  %t31 = load i32, ptr %l16, !tbaa !23
  %t32 = lshr i32 %t31, 16
  %t33 = and i32 %t31, 65535
  %t34 = icmp eq i32 %t32, 1
  %t35 = select i1 %t34, i32 1, i32 0
  %t36 = icmp eq i32 %t31, 0
  %t37 = shl i32 %t35, 16
  %t38 = or i32 %t37, %t33
  %t39 = select i1 %t36, i32 0, i32 %t38
  %t41 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t39, 0
  store { i32, { i64, ptr } } %t41, ptr %rv
  br label %ret
bb13:
  %t42 = load ptr, ptr %l12, !tbaa !29
  %t43 = load ptr, ptr %l13, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aTypeRef_26_3e_2ePush_3ccompiler_2fast_3aTypeRef_26_3e(ptr %v1, ptr %v0, ptr %t42, ptr %t43)
  br label %bb14
bb14:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t47 = call { i32, i1 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2esep(ptr %v0, ptr %t44, i32 114)
  %t48 = extractvalue { i32, i1 } %t47, 1
  %t49 = extractvalue { i32, i1 } %t47, 0
  store i32 %t49, ptr %l22
  %t50 = icmp ne i32 %t49, 0
  br i1 %t50, label %bb16, label %ok.51, !prof !99
ok.51:
  store i1 %t48, ptr %l21
  br label %bb15
bb15:
  %t52 = load i1, ptr %l21, !tbaa !21
  store i1 %t52, ptr %l18, !tbaa !21
  br label %bb17
bb16:
  %t53 = load i32, ptr %l22, !tbaa !23
  %t54 = lshr i32 %t53, 16
  %t55 = and i32 %t53, 65535
  %t56 = icmp eq i32 %t54, 1
  %t57 = select i1 %t56, i32 1, i32 0
  %t58 = icmp eq i32 %t53, 0
  %t59 = shl i32 %t57, 16
  %t60 = or i32 %t59, %t55
  %t61 = select i1 %t58, i32 0, i32 %t60
  %t63 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t61, 0
  store { i32, { i64, ptr } } %t63, ptr %rv
  br label %ret
bb17:
  %t64 = load i1, ptr %l18, !tbaa !21
  %t65 = xor i1 %t64, true
  br i1 %t65, label %bb18, label %bb19
bb18:
  br label %bb22
bb19:
  br label %bb20
bb20:
  br label %bb21
bb21:
  br label %bb10
bb22:
  %t67 = load ptr, ptr %l2, !tbaa !29
  %t69 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aTypeRef_26_3e_2eToArr_Ha78c9aad18467c47f48c596ab5d9c770(ptr %v1, ptr %v1, ptr %t67)
  store { i64, ptr } %t69, ptr %l26
  br label %bb23
bb23:
  %t70 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t71 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t70, 1
  store { i32, { i64, ptr } } %t71, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeParams(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i1
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca i1
  %l10 = alloca i1
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca i1
  %l14 = alloca i1
  %l16 = alloca i32
  %l21 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l25 = alloca i1
  %l27 = alloca i32
  %l28 = alloca i32
  %l30 = alloca i32
  %l31 = alloca i32
  %l36 = alloca ptr
  %l39 = alloca %"compiler/source:Span"
  %l40 = alloca i32
  %l44 = alloca %"compiler/ast:TypeParam"
  %l47 = alloca i32
  %l48 = alloca i32
  %l50 = alloca i32
  %l51 = alloca i32
  %l56 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l60 = alloca i1
  %l62 = alloca i1
  %l65 = alloca i1
  %l67 = alloca i1
  %l69 = alloca i1
  %l71 = alloca i1
  %l74 = alloca i1
  %l76 = alloca i1
  %l79 = alloca i1
  %l88 = alloca ptr
  %l90 = alloca ptr
  %l91 = alloca i32
  %l105 = alloca i1
  %l112 = alloca ptr
  %l114 = alloca ptr
  %l115 = alloca i32
  %l122 = alloca ptr
  %l125 = alloca %"compiler/source:Span"
  %l126 = alloca i32
  %l127 = alloca ptr
  %l129 = alloca { i64, ptr }
  %l131 = alloca %"compiler/ast:TypeParam"
  %l135 = alloca i1
  %l136 = alloca i1
  %l139 = alloca i1
  %l140 = alloca i32
  %l146 = alloca i32
  %l149 = alloca { i64, ptr }
  %rv = alloca { i32, { i64, ptr } }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eopenAngle(ptr %v0, ptr %t1)
  store i32 %t3, ptr %l16
  %t4 = icmp ne i32 %t3, 0
  br i1 %t4, label %bb2, label %ok.5, !prof !99
ok.5:
  br label %bb1
bb1:
  br label %bb3
bb2:
  %t6 = load i32, ptr %l16, !tbaa !23
  %t7 = lshr i32 %t6, 16
  %t8 = and i32 %t6, 65535
  %t9 = icmp eq i32 %t7, 1
  %t10 = select i1 %t9, i32 1, i32 0
  %t11 = icmp eq i32 %t6, 0
  %t12 = shl i32 %t10, 16
  %t13 = or i32 %t12, %t8
  %t14 = select i1 %t11, i32 0, i32 %t13
  %t16 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t14, 0
  store { i32, { i64, ptr } } %t16, ptr %rv
  br label %ret
bb3:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/parse:Parser", ptr %t17, i32 0, i32 22
  %t20 = load i1, ptr %t19, !tbaa !21
  store i1 %t20, ptr %l1, !tbaa !21
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/parse:Parser", ptr %t22, i32 0, i32 22
  store i1 false, ptr %t24, !tbaa !21
  %t25 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aTypeParam_26_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t25, ptr %l21
  br label %bb4
bb4:
  %t26 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l21
  %t27 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t26, ptr %t27
  store ptr %t27, ptr %l2, !tbaa !29
  br label %bb5
bb5:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t32 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t29, i32 77)
  store i1 %t32, ptr %l25
  br label %bb6
bb6:
  %t33 = load i1, ptr %l25, !tbaa !21
  br i1 %t33, label %bb7, label %bb8
bb7:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ehere(ptr %v0, ptr %t34)
  store i32 %t36, ptr %l27
  br label %bb9
bb8:
  br label %bb21
bb9:
  %t37 = load i32, ptr %l27, !tbaa !23
  store i32 %t37, ptr %l3, !tbaa !23
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ename(ptr %v0, ptr %t38)
  %t41 = extractvalue { i32, i32 } %t40, 1
  %t42 = extractvalue { i32, i32 } %t40, 0
  store i32 %t42, ptr %l31
  %t43 = icmp ne i32 %t42, 0
  br i1 %t43, label %bb11, label %ok.44, !prof !99
ok.44:
  store i32 %t41, ptr %l30
  br label %bb10
bb10:
  %t45 = load i32, ptr %l30, !tbaa !23
  store i32 %t45, ptr %l28, !tbaa !23
  br label %bb12
bb11:
  %t46 = load i32, ptr %l31, !tbaa !23
  %t47 = lshr i32 %t46, 16
  %t48 = and i32 %t46, 65535
  %t49 = icmp eq i32 %t47, 1
  %t50 = select i1 %t49, i32 1, i32 0
  %t51 = icmp eq i32 %t46, 0
  %t52 = shl i32 %t50, 16
  %t53 = or i32 %t52, %t48
  %t54 = select i1 %t51, i32 0, i32 %t53
  %t56 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t54, 0
  store { i32, { i64, ptr } } %t56, ptr %rv
  br label %ret
bb12:
  %t57 = load i32, ptr %l28, !tbaa !23
  store i32 %t57, ptr %l4, !tbaa !23
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/parse:Parser", ptr %t58, i32 0, i32 32
  %t61 = load i32, ptr %l4, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ePush_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t60, i32 %t61)
  br label %bb13
bb13:
  %t64 = load ptr, ptr %l2, !tbaa !29
  store ptr %t64, ptr %l36, !tbaa !29
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t66 = load i32, ptr %l3, !tbaa !23
  %t69 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t65, i32 %t66)
  store %"compiler/source:Span" %t69, ptr %l39
  br label %bb14
bb14:
  %t70 = load i32, ptr %l4, !tbaa !23
  store i32 %t70, ptr %l40, !tbaa !23
  %t71 = icmp sge i64 0, 0
  br i1 %t71, label %bb15, label %bb16
bb15:
  %t73 = icmp sle i64 0, 1152921504606846975
  br i1 %t73, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_1d244c71d015ce10_e3593377956a04fc)
  unreachable
bb17:
  %t75 = mul i64 0, 8
  %t76 = insertvalue { i64, ptr } undef, i64 0, 0
  %t77 = insertvalue { i64, ptr } %t76, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t78 = load %"compiler/source:Span", ptr %l39
  %t79 = load i32, ptr %l40, !tbaa !23
  %t81 = call %"compiler/ast:TypeParam" @compiler_2fast_3aTypeParam_2ector(ptr %v1, ptr %v1, ptr %v1, ptr %v1, %"compiler/source:Span" %t78, i32 %t79, ptr null, { i64, ptr } %t77, i1 true, ptr null)
  store %"compiler/ast:TypeParam" %t81, ptr %l44
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_1d244c71d015ce10_e3593377956a04fc)
  unreachable
bb19:
  %t82 = load %"compiler/ast:TypeParam", ptr %l44
  %t83 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 56, i64 8)
  store %"compiler/ast:TypeParam" %t82, ptr %t83
  %t84 = load ptr, ptr %l36, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aTypeParam_26_3e_2ePus_H37c80a976dd4e939873b1680de0974c7(ptr %v1, ptr %v1, ptr %t84, ptr %t83)
  br label %bb20
bb20:
  br label %bb80
bb21:
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t88 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ehere(ptr %v0, ptr %t86)
  store i32 %t88, ptr %l47
  br label %bb22
bb22:
  %t89 = load i32, ptr %l47, !tbaa !23
  store i32 %t89, ptr %l5, !tbaa !23
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t92 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ename(ptr %v0, ptr %t90)
  %t93 = extractvalue { i32, i32 } %t92, 1
  %t94 = extractvalue { i32, i32 } %t92, 0
  store i32 %t94, ptr %l51
  %t95 = icmp ne i32 %t94, 0
  br i1 %t95, label %bb24, label %ok.96, !prof !99
ok.96:
  store i32 %t93, ptr %l50
  br label %bb23
bb23:
  %t97 = load i32, ptr %l50, !tbaa !23
  store i32 %t97, ptr %l48, !tbaa !23
  br label %bb25
bb24:
  %t98 = load i32, ptr %l51, !tbaa !23
  %t99 = lshr i32 %t98, 16
  %t100 = and i32 %t98, 65535
  %t101 = icmp eq i32 %t99, 1
  %t102 = select i1 %t101, i32 1, i32 0
  %t103 = icmp eq i32 %t98, 0
  %t104 = shl i32 %t102, 16
  %t105 = or i32 %t104, %t100
  %t106 = select i1 %t103, i32 0, i32 %t105
  %t108 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t106, 0
  store { i32, { i64, ptr } } %t108, ptr %rv
  br label %ret
bb25:
  %t109 = load i32, ptr %l48, !tbaa !23
  store i32 %t109, ptr %l6, !tbaa !23
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t112 = getelementptr %"compiler/parse:Parser", ptr %t110, i32 0, i32 32
  %t113 = load i32, ptr %l6, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ePush_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t112, i32 %t113)
  br label %bb26
bb26:
  store ptr null, ptr %l7, !tbaa !29
  %t116 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aTypeRef_26_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t116, ptr %l56
  br label %bb27
bb27:
  %t117 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l56
  %t118 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t117, ptr %t118
  store ptr %t118, ptr %l8, !tbaa !29
  br label %bb28
bb28:
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t123 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t120, i32 75)
  store i1 %t123, ptr %l60
  br label %bb29
bb29:
  %t124 = load i1, ptr %l60, !tbaa !21
  %t125 = xor i1 %t124, true
  br i1 %t125, label %bb30, label %bb31
bb30:
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t130 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t127, i32 8)
  store i1 %t130, ptr %l65
  br label %bb32
bb31:
  store i1 false, ptr %l62, !tbaa !21
  br label %bb33
bb32:
  %t131 = load i1, ptr %l65, !tbaa !21
  %t132 = xor i1 %t131, true
  store i1 %t132, ptr %l62, !tbaa !21
  br label %bb33
bb33:
  %t134 = load i1, ptr %l62, !tbaa !21
  br i1 %t134, label %bb34, label %bb35
bb34:
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t137 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eclosesAngle(ptr %v0, ptr %t135)
  store i1 %t137, ptr %l69
  br label %bb36
bb35:
  store i1 false, ptr %l67, !tbaa !21
  br label %bb37
bb36:
  %t138 = load i1, ptr %l69, !tbaa !21
  %t139 = xor i1 %t138, true
  store i1 %t139, ptr %l67, !tbaa !21
  br label %bb37
bb37:
  %t141 = load i1, ptr %l67, !tbaa !21
  br i1 %t141, label %bb38, label %bb39
bb38:
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t145 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t142, i32 77)
  store i1 %t145, ptr %l74
  br label %bb40
bb39:
  store i1 false, ptr %l71, !tbaa !21
  br label %bb41
bb40:
  %t146 = load i1, ptr %l74, !tbaa !21
  %t147 = xor i1 %t146, true
  store i1 %t147, ptr %l71, !tbaa !21
  br label %bb41
bb41:
  %t149 = load i1, ptr %l71, !tbaa !21
  br i1 %t149, label %bb42, label %bb43
bb42:
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t153 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t150, i32 78)
  store i1 %t153, ptr %l79
  br label %bb44
bb43:
  store i1 false, ptr %l76, !tbaa !21
  br label %bb45
bb44:
  %t154 = load i1, ptr %l79, !tbaa !21
  %t155 = xor i1 %t154, true
  store i1 %t155, ptr %l76, !tbaa !21
  br label %bb45
bb45:
  %t157 = load i1, ptr %l76, !tbaa !21
  %t158 = xor i1 %t157, true
  br i1 %t158, label %bb46, label %bb47
bb46:
  br label %bb57
bb47:
  br label %bb48
bb48:
  %t160 = load ptr, ptr %l0, !tbaa !29
  %t162 = getelementptr %"compiler/parse:Parser", ptr %t160, i32 0, i32 11
  %t163 = load i1, ptr %t162, !tbaa !21
  store i1 %t163, ptr %l9, !tbaa !21
  %t165 = load ptr, ptr %l0, !tbaa !29
  %t167 = getelementptr %"compiler/parse:Parser", ptr %t165, i32 0, i32 23
  %t168 = load i1, ptr %t167, !tbaa !21
  store i1 %t168, ptr %l10, !tbaa !21
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t172 = getelementptr %"compiler/parse:Parser", ptr %t170, i32 0, i32 11
  store i1 true, ptr %t172, !tbaa !21
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t175 = getelementptr %"compiler/parse:Parser", ptr %t173, i32 0, i32 23
  store i1 true, ptr %t175, !tbaa !21
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t178 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeExpr(ptr %v0, ptr %v1, ptr %t176)
  %t179 = extractvalue { i32, ptr } %t178, 1
  %t180 = extractvalue { i32, ptr } %t178, 0
  store i32 %t180, ptr %l91
  %t181 = icmp ne i32 %t180, 0
  br i1 %t181, label %bb50, label %ok.182, !prof !99
ok.182:
  store ptr %t179, ptr %l90
  br label %bb49
bb49:
  %t183 = load ptr, ptr %l90, !tbaa !29
  store ptr %t183, ptr %l88, !tbaa !29
  br label %bb51
bb50:
  %t184 = load i32, ptr %l91, !tbaa !23
  %t185 = lshr i32 %t184, 16
  %t186 = and i32 %t184, 65535
  %t187 = icmp eq i32 %t185, 1
  %t188 = select i1 %t187, i32 1, i32 0
  %t189 = icmp eq i32 %t184, 0
  %t190 = shl i32 %t188, 16
  %t191 = or i32 %t190, %t186
  %t192 = select i1 %t189, i32 0, i32 %t191
  %t194 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t192, 0
  store { i32, { i64, ptr } } %t194, ptr %rv
  br label %ret
bb51:
  %t195 = load ptr, ptr %l88, !tbaa !29
  store ptr %t195, ptr %l11, !tbaa !29
  %t196 = load ptr, ptr %l0, !tbaa !29
  %t197 = load i1, ptr %l9, !tbaa !21
  %t200 = getelementptr %"compiler/parse:Parser", ptr %t196, i32 0, i32 11
  store i1 %t197, ptr %t200, !tbaa !21
  %t201 = load ptr, ptr %l0, !tbaa !29
  %t202 = load i1, ptr %l10, !tbaa !21
  %t205 = getelementptr %"compiler/parse:Parser", ptr %t201, i32 0, i32 23
  store i1 %t202, ptr %t205, !tbaa !21
  %t206 = load ptr, ptr %l7, !tbaa !29
  %t208 = icmp eq ptr %t206, null
  br i1 %t208, label %bb52, label %bb53
bb52:
  %t210 = load ptr, ptr %l11, !tbaa !29
  store ptr %t210, ptr %l7, !tbaa !29
  br label %bb55
bb53:
  %t213 = load ptr, ptr %l8, !tbaa !29
  %t214 = load ptr, ptr %l11, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aTypeRef_26_3e_2ePush_3ccompiler_2fast_3aTypeRef_26_3e(ptr %v1, ptr %v1, ptr %t213, ptr %t214)
  br label %bb54
bb54:
  br label %bb55
bb55:
  br label %bb56
bb56:
  br label %bb28
bb57:
  store ptr null, ptr %l12, !tbaa !29
  %t217 = load ptr, ptr %l0, !tbaa !29
  %t220 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t217, i32 78)
  store i1 %t220, ptr %l105
  br label %bb58
bb58:
  %t221 = load i1, ptr %l105, !tbaa !21
  br i1 %t221, label %bb59, label %bb60
bb59:
  %t222 = load ptr, ptr %l0, !tbaa !29
  %t224 = getelementptr %"compiler/parse:Parser", ptr %t222, i32 0, i32 11
  %t225 = load i1, ptr %t224, !tbaa !21
  store i1 %t225, ptr %l13, !tbaa !21
  %t227 = load ptr, ptr %l0, !tbaa !29
  %t229 = getelementptr %"compiler/parse:Parser", ptr %t227, i32 0, i32 23
  %t230 = load i1, ptr %t229, !tbaa !21
  store i1 %t230, ptr %l14, !tbaa !21
  %t232 = load ptr, ptr %l0, !tbaa !29
  %t234 = getelementptr %"compiler/parse:Parser", ptr %t232, i32 0, i32 11
  store i1 true, ptr %t234, !tbaa !21
  %t235 = load ptr, ptr %l0, !tbaa !29
  %t237 = getelementptr %"compiler/parse:Parser", ptr %t235, i32 0, i32 23
  store i1 true, ptr %t237, !tbaa !21
  %t238 = load ptr, ptr %l0, !tbaa !29
  %t240 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeExpr(ptr %v0, ptr %v1, ptr %t238)
  %t241 = extractvalue { i32, ptr } %t240, 1
  %t242 = extractvalue { i32, ptr } %t240, 0
  store i32 %t242, ptr %l115
  %t243 = icmp ne i32 %t242, 0
  br i1 %t243, label %bb62, label %ok.244, !prof !99
ok.244:
  store ptr %t241, ptr %l114
  br label %bb61
bb60:
  br label %bb64
bb61:
  %t245 = load ptr, ptr %l114, !tbaa !29
  store ptr %t245, ptr %l112, !tbaa !29
  br label %bb63
bb62:
  %t246 = load i32, ptr %l115, !tbaa !23
  %t247 = lshr i32 %t246, 16
  %t248 = and i32 %t246, 65535
  %t249 = icmp eq i32 %t247, 1
  %t250 = select i1 %t249, i32 1, i32 0
  %t251 = icmp eq i32 %t246, 0
  %t252 = shl i32 %t250, 16
  %t253 = or i32 %t252, %t248
  %t254 = select i1 %t251, i32 0, i32 %t253
  %t256 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t254, 0
  store { i32, { i64, ptr } } %t256, ptr %rv
  br label %ret
bb63:
  %t257 = load ptr, ptr %l112, !tbaa !29
  store ptr %t257, ptr %l12, !tbaa !29
  %t259 = load ptr, ptr %l0, !tbaa !29
  %t260 = load i1, ptr %l13, !tbaa !21
  %t263 = getelementptr %"compiler/parse:Parser", ptr %t259, i32 0, i32 11
  store i1 %t260, ptr %t263, !tbaa !21
  %t264 = load ptr, ptr %l0, !tbaa !29
  %t265 = load i1, ptr %l14, !tbaa !21
  %t268 = getelementptr %"compiler/parse:Parser", ptr %t264, i32 0, i32 23
  store i1 %t265, ptr %t268, !tbaa !21
  br label %bb64
bb64:
  %t269 = load ptr, ptr %l2, !tbaa !29
  store ptr %t269, ptr %l122, !tbaa !29
  %t270 = load ptr, ptr %l0, !tbaa !29
  %t271 = load i32, ptr %l5, !tbaa !23
  %t274 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t270, i32 %t271)
  store %"compiler/source:Span" %t274, ptr %l125
  br label %bb65
bb65:
  %t275 = load i32, ptr %l6, !tbaa !23
  store i32 %t275, ptr %l126, !tbaa !23
  %t276 = load ptr, ptr %l7, !tbaa !29
  store ptr %t276, ptr %l127, !tbaa !29
  %t277 = load ptr, ptr %l8, !tbaa !29
  %t279 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aTypeRef_26_3e_2eToArr_Ha78c9aad18467c47f48c596ab5d9c770(ptr %v1, ptr %v1, ptr %t277)
  store { i64, ptr } %t279, ptr %l129
  br label %bb66
bb66:
  %t280 = load ptr, ptr %l12, !tbaa !29
  %t281 = load %"compiler/source:Span", ptr %l125
  %t282 = load i32, ptr %l126, !tbaa !23
  %t283 = load ptr, ptr %l127, !tbaa !29
  %t284 = load { i64, ptr }, ptr %l129, !tbaa !27
  %t286 = call %"compiler/ast:TypeParam" @compiler_2fast_3aTypeParam_2ector(ptr %v1, ptr %v1, ptr %v1, ptr %v1, %"compiler/source:Span" %t281, i32 %t282, ptr %t283, { i64, ptr } %t284, i1 false, ptr %t280)
  store %"compiler/ast:TypeParam" %t286, ptr %l131
  br label %bb67
bb67:
  %t287 = load %"compiler/ast:TypeParam", ptr %l131
  %t288 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 56, i64 8)
  store %"compiler/ast:TypeParam" %t287, ptr %t288
  %t289 = load ptr, ptr %l122, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aTypeParam_26_3e_2ePus_H37c80a976dd4e939873b1680de0974c7(ptr %v1, ptr %v1, ptr %t289, ptr %t288)
  br label %bb68
bb68:
  %t291 = load ptr, ptr %l0, !tbaa !29
  %t294 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t291, i32 77)
  store i1 %t294, ptr %l135
  br label %bb69
bb69:
  %t295 = load i1, ptr %l135, !tbaa !21
  br i1 %t295, label %bb70, label %bb71
bb70:
  br label %bb79
bb71:
  br label %bb72
bb72:
  %t296 = load ptr, ptr %l0, !tbaa !29
  %t299 = call { i32, i1 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2esep(ptr %v0, ptr %t296, i32 100)
  %t300 = extractvalue { i32, i1 } %t299, 1
  %t301 = extractvalue { i32, i1 } %t299, 0
  store i32 %t301, ptr %l140
  %t302 = icmp ne i32 %t301, 0
  br i1 %t302, label %bb74, label %ok.303, !prof !99
ok.303:
  store i1 %t300, ptr %l139
  br label %bb73
bb73:
  %t304 = load i1, ptr %l139, !tbaa !21
  store i1 %t304, ptr %l136, !tbaa !21
  br label %bb75
bb74:
  %t305 = load i32, ptr %l140, !tbaa !23
  %t306 = lshr i32 %t305, 16
  %t307 = and i32 %t305, 65535
  %t308 = icmp eq i32 %t306, 1
  %t309 = select i1 %t308, i32 1, i32 0
  %t310 = icmp eq i32 %t305, 0
  %t311 = shl i32 %t309, 16
  %t312 = or i32 %t311, %t307
  %t313 = select i1 %t310, i32 0, i32 %t312
  %t315 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t313, 0
  store { i32, { i64, ptr } } %t315, ptr %rv
  br label %ret
bb75:
  %t316 = load i1, ptr %l136, !tbaa !21
  %t317 = xor i1 %t316, true
  br i1 %t317, label %bb76, label %bb77
bb76:
  br label %bb80
bb77:
  br label %bb78
bb78:
  br label %bb79
bb79:
  br label %bb5
bb80:
  %t319 = load ptr, ptr %l0, !tbaa !29
  %t320 = load i1, ptr %l1, !tbaa !21
  %t323 = getelementptr %"compiler/parse:Parser", ptr %t319, i32 0, i32 22
  store i1 %t320, ptr %t323, !tbaa !21
  %t324 = load ptr, ptr %l0, !tbaa !29
  %t326 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ecloseAngle(ptr %v0, ptr %t324)
  store i32 %t326, ptr %l146
  %t327 = icmp ne i32 %t326, 0
  br i1 %t327, label %bb82, label %ok.328, !prof !99
ok.328:
  br label %bb81
bb81:
  br label %bb83
bb82:
  %t329 = load i32, ptr %l146, !tbaa !23
  %t330 = lshr i32 %t329, 16
  %t331 = and i32 %t329, 65535
  %t332 = icmp eq i32 %t330, 1
  %t333 = select i1 %t332, i32 1, i32 0
  %t334 = icmp eq i32 %t329, 0
  %t335 = shl i32 %t333, 16
  %t336 = or i32 %t335, %t331
  %t337 = select i1 %t334, i32 0, i32 %t336
  %t339 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t337, 0
  store { i32, { i64, ptr } } %t339, ptr %rv
  br label %ret
bb83:
  %t340 = load ptr, ptr %l2, !tbaa !29
  %t342 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aTypeParam_26_3e_2eToA_H6e630dc6e3e172d7593a8563d6f9ad2c(ptr %v1, ptr %v1, ptr %t340)
  store { i64, ptr } %t342, ptr %l149
  br label %bb84
bb84:
  %t343 = load { i64, ptr }, ptr %l149, !tbaa !27
  %t344 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t343, 1
  store { i32, { i64, ptr } } %t344, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2evalues(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i1 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i64
  %l6 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i32
  %l13 = alloca i64
  %l15 = alloca ptr
  %l16 = alloca ptr
  %l18 = alloca ptr
  %l19 = alloca i32
  %l23 = alloca i64
  %l30 = alloca i1
  %l33 = alloca i1
  %l38 = alloca { i64, ptr }
  %rv = alloca { i32, { i64, ptr } }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t3 = xor i1 %a2, true
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexprList(ptr %v0, ptr %v2, ptr %t5)
  %t8 = extractvalue { i32, { i64, ptr } } %t7, 1
  %t9 = extractvalue { i32, { i64, ptr } } %t7, 0
  store i32 %t9, ptr %l9
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb4, label %ok.11, !prof !99
ok.11:
  store { i64, ptr } %t8, ptr %l8
  br label %bb3
bb2:
  br label %bb6
bb3:
  %t12 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t12, ptr %l6, !tbaa !27
  br label %bb5
bb4:
  %t13 = load i32, ptr %l9, !tbaa !23
  %t14 = lshr i32 %t13, 16
  %t15 = and i32 %t13, 65535
  %t16 = icmp eq i32 %t14, 1
  %t17 = select i1 %t16, i32 1, i32 0
  %t18 = icmp eq i32 %t13, 0
  %t19 = shl i32 %t17, 16
  %t20 = or i32 %t19, %t15
  %t21 = select i1 %t18, i32 0, i32 %t20
  %t23 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t21, 0
  store { i32, { i64, ptr } } %t23, ptr %rv
  br label %ret
bb5:
  %t24 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t25 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t24, 1
  store { i32, { i64, ptr } } %t25, ptr %rv
  br label %ret
bb6:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/parse:Parser", ptr %t26, i32 0, i32 34
  %t30 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2eLen_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %t28)
  store i64 %t30, ptr %l13
  br label %bb7
bb7:
  %t31 = load i64, ptr %l13, !tbaa !24
  store i64 %t31, ptr %l3, !tbaa !24
  br label %bb8
bb8:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/parse:Parser", ptr %t32, i32 0, i32 34
  store ptr %t34, ptr %l15, !tbaa !29
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexpr(ptr %v0, ptr %v0, ptr %t35)
  %t38 = extractvalue { i32, ptr } %t37, 1
  %t39 = extractvalue { i32, ptr } %t37, 0
  store i32 %t39, ptr %l19
  %t40 = icmp ne i32 %t39, 0
  br i1 %t40, label %bb10, label %ok.41, !prof !99
ok.41:
  store ptr %t38, ptr %l18
  br label %bb9
bb9:
  %t42 = load ptr, ptr %l18, !tbaa !29
  store ptr %t42, ptr %l16, !tbaa !29
  br label %bb11
bb10:
  %t43 = load i32, ptr %l19, !tbaa !23
  %t44 = lshr i32 %t43, 16
  %t45 = and i32 %t43, 65535
  %t46 = icmp eq i32 %t44, 1
  %t47 = select i1 %t46, i32 1, i32 0
  %t48 = icmp eq i32 %t43, 0
  %t49 = shl i32 %t47, 16
  %t50 = or i32 %t49, %t45
  %t51 = select i1 %t48, i32 0, i32 %t50
  %t53 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t51, 0
  store { i32, { i64, ptr } } %t53, ptr %rv
  br label %ret
bb11:
  %t54 = load ptr, ptr %l15, !tbaa !29
  %t55 = load ptr, ptr %l16, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2ePush_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t54, ptr %t55)
  br label %bb12
bb12:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/parse:Parser", ptr %t56, i32 0, i32 34
  %t60 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2eLen_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %t58)
  store i64 %t60, ptr %l23
  br label %bb13
bb13:
  %t61 = load i64, ptr %l3, !tbaa !24
  %t62 = load i64, ptr %l23, !tbaa !24
  %t64 = sub i64 %t62, %t61
  %t67 = getelementptr %"compiler/parse:NameList", ptr %a1, i32 0, i32 0
  %t68 = load { i64, ptr }, ptr %t67, !tbaa !27
  %t70 = extractvalue { i64, ptr } %t68, 0
  %t73 = icmp sge i64 %t64, %t70
  br i1 %t73, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l30, !tbaa !21
  br label %bb17
bb15:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t78 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t75, i32 75)
  store i1 %t78, ptr %l33
  br label %bb16
bb16:
  %t79 = load i1, ptr %l33, !tbaa !21
  %t80 = xor i1 %t79, true
  store i1 %t80, ptr %l30, !tbaa !21
  br label %bb17
bb17:
  %t82 = load i1, ptr %l30, !tbaa !21
  br i1 %t82, label %bb18, label %bb19
bb18:
  br label %bb22
bb19:
  br label %bb20
bb20:
  br label %bb21
bb21:
  br label %bb8
bb22:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr %"compiler/parse:Parser", ptr %t83, i32 0, i32 34
  %t86 = load i64, ptr %l3, !tbaa !24
  %t89 = call { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %v2, ptr %t85, i64 %t86)
  store { i64, ptr } %t89, ptr %l38
  br label %bb23
bb23:
  %t90 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t91 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t90, 1
  store { i32, { i64, ptr } } %t91, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eweakType(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l5 = alloca i32
  %l7 = alloca i32
  %l8 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca i32
  %l14 = alloca ptr
  %l17 = alloca ptr
  %l18 = alloca i32
  %l20 = alloca i32
  %l23 = alloca { i64, ptr }
  %l26 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l37 = alloca %"compiler/diagmsg:Msg"
  %s1 = alloca %olang.scope
  %rv = alloca { i32, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ehere(ptr %v0, ptr %t1)
  store i32 %t3, ptr %l5
  br label %bb1
bb1:
  %t4 = load i32, ptr %l5, !tbaa !23
  store i32 %t4, ptr %l1, !tbaa !23
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t5)
  store i32 %t7, ptr %l7
  br label %bb2
bb2:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeExpr(ptr %v0, ptr %v1, ptr %t8)
  %t11 = extractvalue { i32, ptr } %t10, 1
  %t12 = extractvalue { i32, ptr } %t10, 0
  store i32 %t12, ptr %l11
  %t13 = icmp ne i32 %t12, 0
  br i1 %t13, label %bb4, label %ok.14, !prof !99
ok.14:
  store ptr %t11, ptr %l10
  br label %bb3
bb3:
  %t15 = load ptr, ptr %l10, !tbaa !29
  store ptr %t15, ptr %l8, !tbaa !29
  br label %bb5
bb4:
  %t16 = load i32, ptr %l11, !tbaa !23
  %t17 = lshr i32 %t16, 16
  %t18 = and i32 %t16, 65535
  %t19 = icmp eq i32 %t17, 1
  %t20 = select i1 %t19, i32 1, i32 0
  %t21 = icmp eq i32 %t16, 0
  %t22 = shl i32 %t20, 16
  %t23 = or i32 %t22, %t18
  %t24 = select i1 %t21, i32 0, i32 %t23
  %t26 = insertvalue { i32, ptr } zeroinitializer, i32 %t24, 0
  store { i32, ptr } %t26, ptr %rv
  br label %ret
bb5:
  %t27 = load ptr, ptr %l8, !tbaa !29
  store ptr %t27, ptr %l2, !tbaa !29
  %t28 = load ptr, ptr %l2, !tbaa !29
  %t30 = call ptr @compiler_2fparse_2eweakened(ptr %v1, ptr %v1, ptr %t28)
  store ptr %t30, ptr %l14
  br label %bb6
bb6:
  %t31 = load ptr, ptr %l14, !tbaa !29
  store ptr %t31, ptr %l3, !tbaa !29
  %t32 = load ptr, ptr %l3, !tbaa !29
  %t34 = icmp eq ptr %t32, null
  br i1 %t34, label %bb7, label %bb8
bb7:
  store %olang.scope zeroinitializer, ptr %s1
  %t36 = load ptr, ptr %l0, !tbaa !29
  store ptr %t36, ptr %l17, !tbaa !29
  %t37 = load i32, ptr %l1, !tbaa !23
  store i32 %t37, ptr %l18, !tbaa !23
  %t38 = load i32, ptr %l1, !tbaa !23
  %t40 = add i32 %t38, 4
  store i32 %t40, ptr %l20, !tbaa !23
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/parse:Parser", ptr %t41, i32 0, i32 0
  %t44 = load ptr, ptr %t43, !tbaa !29
  %t46 = getelementptr %"compiler/source:Source", ptr %t44, i32 0, i32 1
  %t47 = load { i64, ptr }, ptr %t46, !tbaa !27
  store { i64, ptr } %t47, ptr %l23, !tbaa !27
  %t48 = load i32, ptr %l1, !tbaa !23
  %t50 = sext i32 %t48 to i64
  %t52 = add i64 %t50, 5
  store i64 %t52, ptr %l26, !tbaa !24
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/parse:Parser", ptr %t53, i32 0, i32 10
  %t56 = load i32, ptr %t55, !tbaa !23
  %t58 = sext i32 %t56 to i64
  store i64 %t58, ptr %l29, !tbaa !24
  %t59 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t60 = extractvalue { i64, ptr } %t59, 0
  store i64 %t60, ptr %l30, !tbaa !24
  %t61 = load i64, ptr %l26, !tbaa !24
  %t62 = icmp sge i64 %t61, 0
  br i1 %t62, label %bb9, label %bb10
bb8:
  br label %bb17
bb9:
  %t64 = load i64, ptr %l26, !tbaa !24
  %t65 = load i64, ptr %l29, !tbaa !24
  %t66 = icmp sle i64 %t64, %t65
  br i1 %t66, label %bb11, label %bb12
bb10:
  call void @__olang_check_failed(ptr @olang_loc_2154037c3afdd592_b5cbca897fb2c76e)
  unreachable
bb11:
  %t68 = load i64, ptr %l29, !tbaa !24
  %t69 = load i64, ptr %l30, !tbaa !24
  %t70 = icmp sle i64 %t68, %t69
  br i1 %t70, label %bb13, label %bb14
bb12:
  call void @__olang_check_failed(ptr @olang_loc_2154037c3afdd592_b5cbca897fb2c76e)
  unreachable
bb13:
  %t72 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !27
  %t74 = load i64, ptr %l26, !tbaa !24
  %t75 = load i64, ptr %l29, !tbaa !24
  %t76 = getelementptr i8, ptr %t73, i64 %t74
  %t77 = sub i64 %t75, %t74
  %t78 = insertvalue { i64, ptr } undef, i64 %t77, 0
  %t79 = insertvalue { i64, ptr } %t78, ptr %t76, 1
  %t81 = extractvalue { i64, ptr } %t79, 1
  %t82 = extractvalue { i64, ptr } %t79, 0
  %t83 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t82)
  call void @olang_textcopy(ptr %t83, ptr %t81, i64 %t82)
  %t84 = insertvalue { i64, ptr } undef, i64 %t82, 0
  %t85 = insertvalue { i64, ptr } %t84, ptr %t83, 1
  %t88 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eWeakNotNullable(ptr %s1, ptr %v0, { i64, ptr } %t85)
  store %"compiler/diagmsg:Msg" %t88, ptr %l37
  br label %bb15
bb14:
  call void @__olang_check_failed(ptr @olang_loc_2154037c3afdd592_b5cbca897fb2c76e)
  unreachable
bb15:
  %t89 = load ptr, ptr %l17, !tbaa !29
  %t90 = load i32, ptr %l18, !tbaa !23
  %t91 = load i32, ptr %l20, !tbaa !23
  %t92 = load %"compiler/diagmsg:Msg", ptr %l37
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereport(ptr %v0, ptr %v0, ptr %t89, i32 %t90, i32 %t91, %"compiler/diagmsg:Msg" %t92)
  br label %bb16
bb16:
  %t93 = load ptr, ptr %l2, !tbaa !29
  call void @__olang_scope_close(ptr %s1)
  %t95 = insertvalue { i32, ptr } zeroinitializer, ptr %t93, 1
  store { i32, ptr } %t95, ptr %rv
  br label %ret
bb17:
  %t96 = load ptr, ptr %l3, !tbaa !29
  %t98 = insertvalue { i32, ptr } zeroinitializer, ptr %t96, 1
  store { i32, ptr } %t98, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local i32 @compiler_2fparse_2edeclWord(i32 %a0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca i32
  %rv = alloca i32
  store i32 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t3 = trunc i64 54 to i32
  %t4 = icmp eq i32 %t1, %t3
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb4
bb3:
  store i32 1, ptr %l1
  br label %bb13
bb4:
  %t7 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t9 = trunc i64 53 to i32
  %t10 = icmp eq i32 %t7, %t9
  br i1 %t10, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb8
bb7:
  store i32 2, ptr %l1
  br label %bb13
bb8:
  br i1 true, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  store i32 0, ptr %l1
  br label %bb13
bb12:
  call void @__olang_check_failed(ptr @olang_loc_af06113cf8aef81c_32854973a8f51e0)
  unreachable
bb13:
  %t14 = load i32, ptr %l1, !range !{i32 0, i32 3}
  store i32 %t14, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2fparse_2edeclWordBody(i32 %a0) #0 {
entry:
  %l0 = alloca i32
  %l3 = alloca i1
  %l6 = alloca i1
  %l9 = alloca i1
  %l12 = alloca i1
  %l15 = alloca i1
  %l18 = alloca i1
  %l21 = alloca i1
  %l24 = alloca i1
  %l27 = alloca i1
  %rv = alloca i1
  store i32 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t3 = trunc i64 34 to i32
  %t4 = icmp eq i32 %t1, %t3
  br i1 %t4, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l3, !tbaa !21
  br label %bb3
bb2:
  %t6 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t8 = trunc i64 35 to i32
  %t9 = icmp eq i32 %t6, %t8
  store i1 %t9, ptr %l3, !tbaa !21
  br label %bb3
bb3:
  %t11 = load i1, ptr %l3, !tbaa !21
  br i1 %t11, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb6
bb5:
  %t12 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t14 = trunc i64 22 to i32
  %t15 = icmp eq i32 %t12, %t14
  store i1 %t15, ptr %l6, !tbaa !21
  br label %bb6
bb6:
  %t17 = load i1, ptr %l6, !tbaa !21
  br i1 %t17, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb9
bb8:
  %t18 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t20 = trunc i64 36 to i32
  %t21 = icmp eq i32 %t18, %t20
  store i1 %t21, ptr %l9, !tbaa !21
  br label %bb9
bb9:
  %t23 = load i1, ptr %l9, !tbaa !21
  br i1 %t23, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb12
bb11:
  %t24 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t26 = trunc i64 38 to i32
  %t27 = icmp eq i32 %t24, %t26
  store i1 %t27, ptr %l12, !tbaa !21
  br label %bb12
bb12:
  %t29 = load i1, ptr %l12, !tbaa !21
  br i1 %t29, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb15
bb14:
  %t30 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t32 = trunc i64 1 to i32
  %t33 = icmp eq i32 %t30, %t32
  store i1 %t33, ptr %l15, !tbaa !21
  br label %bb15
bb15:
  %t35 = load i1, ptr %l15, !tbaa !21
  br i1 %t35, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l18, !tbaa !21
  br label %bb18
bb17:
  %t36 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t38 = trunc i64 37 to i32
  %t39 = icmp eq i32 %t36, %t38
  store i1 %t39, ptr %l18, !tbaa !21
  br label %bb18
bb18:
  %t41 = load i1, ptr %l18, !tbaa !21
  br i1 %t41, label %bb19, label %bb20
bb19:
  store i1 true, ptr %l21, !tbaa !21
  br label %bb21
bb20:
  %t42 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t44 = trunc i64 53 to i32
  %t45 = icmp eq i32 %t42, %t44
  store i1 %t45, ptr %l21, !tbaa !21
  br label %bb21
bb21:
  %t47 = load i1, ptr %l21, !tbaa !21
  br i1 %t47, label %bb22, label %bb23
bb22:
  store i1 true, ptr %l24, !tbaa !21
  br label %bb24
bb23:
  %t48 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t50 = trunc i64 54 to i32
  %t51 = icmp eq i32 %t48, %t50
  store i1 %t51, ptr %l24, !tbaa !21
  br label %bb24
bb24:
  %t53 = load i1, ptr %l24, !tbaa !21
  br i1 %t53, label %bb25, label %bb26
bb25:
  store i1 true, ptr %l27, !tbaa !21
  br label %bb27
bb26:
  %t54 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t56 = trunc i64 55 to i32
  %t57 = icmp eq i32 %t54, %t56
  store i1 %t57, ptr %l27, !tbaa !21
  br label %bb27
bb27:
  %t59 = load i1, ptr %l27, !tbaa !21
  store i1 %t59, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fparse_2eisAxis(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a0, ptr %l1, !tbaa !29
  store i1 false, ptr %l2, !tbaa !21
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 28}
  %t8 = icmp eq i64 %t6, 15
  store i1 %t8, ptr %l2, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l2, !tbaa !21
  store i1 %t9, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fparse_2eisJoiningOp(i32 %a0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca i1
  %rv = alloca i1
  store i32 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t3 = trunc i64 68 to i32
  %t4 = icmp eq i32 %t1, %t3
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %bb13
bb2:
  %t6 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t8 = trunc i64 69 to i32
  %t9 = icmp eq i32 %t6, %t8
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb13
bb4:
  %t11 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t13 = trunc i64 70 to i32
  %t14 = icmp eq i32 %t11, %t13
  br i1 %t14, label %bb5, label %bb6
bb5:
  br label %bb13
bb6:
  %t16 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t18 = trunc i64 72 to i32
  %t19 = icmp eq i32 %t16, %t18
  br i1 %t19, label %bb7, label %bb8
bb7:
  br label %bb13
bb8:
  %t21 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t23 = trunc i64 73 to i32
  %t24 = icmp eq i32 %t21, %t23
  br i1 %t24, label %bb9, label %bb10
bb9:
  br label %bb13
bb10:
  %t26 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t28 = trunc i64 74 to i32
  %t29 = icmp eq i32 %t26, %t28
  br i1 %t29, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb14
bb13:
  store i1 true, ptr %l1, !tbaa !21
  br label %bb57
bb14:
  %t31 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t33 = trunc i64 71 to i32
  %t34 = icmp eq i32 %t31, %t33
  br i1 %t34, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb18
bb17:
  store i1 true, ptr %l1, !tbaa !21
  br label %bb57
bb18:
  %t36 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t38 = trunc i64 45 to i32
  %t39 = icmp eq i32 %t36, %t38
  br i1 %t39, label %bb19, label %bb20
bb19:
  br label %bb35
bb20:
  %t41 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t43 = trunc i64 46 to i32
  %t44 = icmp eq i32 %t41, %t43
  br i1 %t44, label %bb21, label %bb22
bb21:
  br label %bb35
bb22:
  %t46 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t48 = trunc i64 47 to i32
  %t49 = icmp eq i32 %t46, %t48
  br i1 %t49, label %bb23, label %bb24
bb23:
  br label %bb35
bb24:
  %t51 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t53 = trunc i64 95 to i32
  %t54 = icmp eq i32 %t51, %t53
  br i1 %t54, label %bb25, label %bb26
bb25:
  br label %bb35
bb26:
  %t56 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t58 = trunc i64 96 to i32
  %t59 = icmp eq i32 %t56, %t58
  br i1 %t59, label %bb27, label %bb28
bb27:
  br label %bb35
bb28:
  %t61 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t63 = trunc i64 28 to i32
  %t64 = icmp eq i32 %t61, %t63
  br i1 %t64, label %bb29, label %bb30
bb29:
  br label %bb35
bb30:
  %t66 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t68 = trunc i64 98 to i32
  %t69 = icmp eq i32 %t66, %t68
  br i1 %t69, label %bb31, label %bb32
bb31:
  br label %bb35
bb32:
  %t71 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t73 = trunc i64 99 to i32
  %t74 = icmp eq i32 %t71, %t73
  br i1 %t74, label %bb33, label %bb34
bb33:
  br label %bb35
bb34:
  br label %bb36
bb35:
  store i1 true, ptr %l1, !tbaa !21
  br label %bb57
bb36:
  %t76 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t78 = trunc i64 100 to i32
  %t79 = icmp eq i32 %t76, %t78
  br i1 %t79, label %bb37, label %bb38
bb37:
  br label %bb51
bb38:
  %t81 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t83 = trunc i64 101 to i32
  %t84 = icmp eq i32 %t81, %t83
  br i1 %t84, label %bb39, label %bb40
bb39:
  br label %bb51
bb40:
  %t86 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t88 = trunc i64 102 to i32
  %t89 = icmp eq i32 %t86, %t88
  br i1 %t89, label %bb41, label %bb42
bb41:
  br label %bb51
bb42:
  %t91 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t93 = trunc i64 103 to i32
  %t94 = icmp eq i32 %t91, %t93
  br i1 %t94, label %bb43, label %bb44
bb43:
  br label %bb51
bb44:
  %t96 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t98 = trunc i64 104 to i32
  %t99 = icmp eq i32 %t96, %t98
  br i1 %t99, label %bb45, label %bb46
bb45:
  br label %bb51
bb46:
  %t101 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t103 = trunc i64 108 to i32
  %t104 = icmp eq i32 %t101, %t103
  br i1 %t104, label %bb47, label %bb48
bb47:
  br label %bb51
bb48:
  %t106 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t108 = trunc i64 109 to i32
  %t109 = icmp eq i32 %t106, %t108
  br i1 %t109, label %bb49, label %bb50
bb49:
  br label %bb51
bb50:
  br label %bb52
bb51:
  store i1 true, ptr %l1, !tbaa !21
  br label %bb57
bb52:
  br i1 true, label %bb53, label %bb54
bb53:
  br label %bb55
bb54:
  br label %bb56
bb55:
  store i1 false, ptr %l1, !tbaa !21
  br label %bb57
bb56:
  call void @__olang_check_failed(ptr @olang_loc_a46c4d4e835a1515_243175b90cb4fb69)
  unreachable
bb57:
  %t111 = load i1, ptr %l1, !tbaa !21
  store i1 %t111, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fparse_2eisLiteral(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca i1
  %l4 = alloca ptr
  %l5 = alloca i1
  %l8 = alloca ptr
  %l9 = alloca i1
  %l18 = alloca i1
  %l20 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 28}
  %t8 = icmp eq i64 %t6, 1
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb6
bb5:
  store i1 true, ptr %l3, !tbaa !21
  br label %bb21
bb6:
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t11 = load ptr, ptr %l8, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb7, label %bb8
bb7:
  %t14 = load ptr, ptr %l8, !tbaa !29
  %t15 = load i64, ptr %t14, !range !{i64 0, i64 28}
  %t17 = icmp eq i64 %t15, 3
  store i1 %t17, ptr %l9, !tbaa !21
  br label %bb8
bb8:
  %t18 = load i1, ptr %l9, !tbaa !21
  br i1 %t18, label %bb9, label %bb10
bb9:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr { i64, [4 x i64] }, ptr %t19, i32 0, i32 1
  %t22 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t21, i32 0, i32 1
  %t23 = load i32, ptr %t22, !range !{i32 0, i32 116}
  store i32 %t23, ptr %l1
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr { i64, [4 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t27, i32 0, i32 2
  %t29 = load ptr, ptr %t28
  store ptr %t29, ptr %l2, !tbaa !29
  br label %bb11
bb10:
  br label %bb16
bb11:
  %t31 = load i32, ptr %l1, !range !{i32 0, i32 116}
  %t33 = trunc i64 69 to i32
  %t34 = icmp eq i32 %t31, %t33
  br i1 %t34, label %bb12, label %bb13
bb12:
  %t36 = load ptr, ptr %l2, !tbaa !29
  %t38 = call i1 @compiler_2fparse_2eisLiteral(ptr %v0, ptr %t36)
  store i1 %t38, ptr %l20
  br label %bb14
bb13:
  store i1 false, ptr %l18, !tbaa !21
  br label %bb15
bb14:
  %t39 = load i1, ptr %l20, !tbaa !21
  store i1 %t39, ptr %l18, !tbaa !21
  br label %bb15
bb15:
  %t40 = load i1, ptr %l18, !tbaa !21
  store i1 %t40, ptr %l3, !tbaa !21
  br label %bb21
bb16:
  br i1 true, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  store i1 false, ptr %l3, !tbaa !21
  br label %bb21
bb20:
  call void @__olang_check_failed(ptr @olang_loc_ed9c9212b4212a6d_b0d1473d5650fc49)
  unreachable
bb21:
  %t41 = load i1, ptr %l3, !tbaa !21
  store i1 %t41, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fparse_2eisPatPath(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i1
  %l4 = alloca ptr
  %l5 = alloca i1
  %l11 = alloca i1
  %l12 = alloca ptr
  %l13 = alloca i1
  %l19 = alloca i1
  %l21 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 28}
  %t8 = icmp eq i64 %t6, 11
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t12, i32 0, i32 1
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = call i1 @compiler_2fparse_2eisPath(ptr %v0, ptr %t16)
  store i1 %t18, ptr %l11
  br label %bb6
bb6:
  %t19 = load i1, ptr %l11, !tbaa !21
  store i1 %t19, ptr %l3, !tbaa !21
  br label %bb20
bb7:
  %t20 = load ptr, ptr %l0, !tbaa !29
  store ptr %t20, ptr %l12, !tbaa !29
  store i1 false, ptr %l13, !tbaa !21
  %t21 = load ptr, ptr %l12, !tbaa !29
  %t22 = icmp ne ptr %t21, null
  br i1 %t22, label %bb8, label %bb9
bb8:
  %t24 = load ptr, ptr %l12, !tbaa !29
  %t25 = load i64, ptr %t24, !range !{i64 0, i64 28}
  %t27 = icmp eq i64 %t25, 12
  store i1 %t27, ptr %l13, !tbaa !21
  br label %bb9
bb9:
  %t28 = load i1, ptr %l13, !tbaa !21
  br i1 %t28, label %bb10, label %bb11
bb10:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr { i64, [4 x i64] }, ptr %t29, i32 0, i32 1
  %t32 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t31, i32 0, i32 1
  %t33 = load ptr, ptr %t32
  store ptr %t33, ptr %l2, !tbaa !29
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t35 = load ptr, ptr %l2, !tbaa !29
  %t37 = call i1 @compiler_2fparse_2eisPatPath(ptr %v0, ptr %t35)
  store i1 %t37, ptr %l19
  br label %bb13
bb13:
  %t38 = load i1, ptr %l19, !tbaa !21
  store i1 %t38, ptr %l3, !tbaa !21
  br label %bb20
bb14:
  br i1 true, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb19
bb17:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = call i1 @compiler_2fparse_2eisPath(ptr %v0, ptr %t39)
  store i1 %t41, ptr %l21
  br label %bb18
bb18:
  %t42 = load i1, ptr %l21, !tbaa !21
  store i1 %t42, ptr %l3, !tbaa !21
  br label %bb20
bb19:
  call void @__olang_check_failed(ptr @olang_loc_df55213c12c66f02_faf3a3bc6284f73e)
  unreachable
bb20:
  %t43 = load i1, ptr %l3, !tbaa !21
  store i1 %t43, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fparse_2eisSpreadType(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a0, ptr %l1, !tbaa !29
  store i1 false, ptr %l2, !tbaa !21
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 7
  store i1 %t8, ptr %l2, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l2, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb6
bb5:
  store i1 true, ptr %rv
  br label %ret
bb6:
  br i1 true, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store i1 false, ptr %rv
  br label %ret
bb10:
  call void @__olang_check_failed(ptr @olang_loc_fcd7f3e04b81968d_d9ee06b55986a881)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fparse_2ekeywordNamesField(i32 %a0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca i1
  %rv = alloca i1
  store i32 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t3 = trunc i64 19 to i32
  %t4 = icmp eq i32 %t1, %t3
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %bb17
bb2:
  %t6 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t8 = trunc i64 20 to i32
  %t9 = icmp eq i32 %t6, %t8
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb17
bb4:
  %t11 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t13 = trunc i64 21 to i32
  %t14 = icmp eq i32 %t11, %t13
  br i1 %t14, label %bb5, label %bb6
bb5:
  br label %bb17
bb6:
  %t16 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t18 = trunc i64 27 to i32
  %t19 = icmp eq i32 %t16, %t18
  br i1 %t19, label %bb7, label %bb8
bb7:
  br label %bb17
bb8:
  %t21 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t23 = trunc i64 28 to i32
  %t24 = icmp eq i32 %t21, %t23
  br i1 %t24, label %bb9, label %bb10
bb9:
  br label %bb17
bb10:
  %t26 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t28 = trunc i64 29 to i32
  %t29 = icmp eq i32 %t26, %t28
  br i1 %t29, label %bb11, label %bb12
bb11:
  br label %bb17
bb12:
  %t31 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t33 = trunc i64 45 to i32
  %t34 = icmp eq i32 %t31, %t33
  br i1 %t34, label %bb13, label %bb14
bb13:
  br label %bb17
bb14:
  %t36 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t38 = trunc i64 46 to i32
  %t39 = icmp eq i32 %t36, %t38
  br i1 %t39, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb18
bb17:
  store i1 true, ptr %l1, !tbaa !21
  br label %bb91
bb18:
  %t41 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t43 = trunc i64 47 to i32
  %t44 = icmp eq i32 %t41, %t43
  br i1 %t44, label %bb19, label %bb20
bb19:
  br label %bb29
bb20:
  %t46 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t48 = trunc i64 30 to i32
  %t49 = icmp eq i32 %t46, %t48
  br i1 %t49, label %bb21, label %bb22
bb21:
  br label %bb29
bb22:
  %t51 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t53 = trunc i64 32 to i32
  %t54 = icmp eq i32 %t51, %t53
  br i1 %t54, label %bb23, label %bb24
bb23:
  br label %bb29
bb24:
  %t56 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t58 = trunc i64 33 to i32
  %t59 = icmp eq i32 %t56, %t58
  br i1 %t59, label %bb25, label %bb26
bb25:
  br label %bb29
bb26:
  %t61 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t63 = trunc i64 34 to i32
  %t64 = icmp eq i32 %t61, %t63
  br i1 %t64, label %bb27, label %bb28
bb27:
  br label %bb29
bb28:
  br label %bb30
bb29:
  store i1 true, ptr %l1, !tbaa !21
  br label %bb91
bb30:
  %t66 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t68 = trunc i64 35 to i32
  %t69 = icmp eq i32 %t66, %t68
  br i1 %t69, label %bb31, label %bb32
bb31:
  br label %bb41
bb32:
  %t71 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t73 = trunc i64 36 to i32
  %t74 = icmp eq i32 %t71, %t73
  br i1 %t74, label %bb33, label %bb34
bb33:
  br label %bb41
bb34:
  %t76 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t78 = trunc i64 22 to i32
  %t79 = icmp eq i32 %t76, %t78
  br i1 %t79, label %bb35, label %bb36
bb35:
  br label %bb41
bb36:
  %t81 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t83 = trunc i64 40 to i32
  %t84 = icmp eq i32 %t81, %t83
  br i1 %t84, label %bb37, label %bb38
bb37:
  br label %bb41
bb38:
  %t86 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t88 = trunc i64 41 to i32
  %t89 = icmp eq i32 %t86, %t88
  br i1 %t89, label %bb39, label %bb40
bb39:
  br label %bb41
bb40:
  br label %bb42
bb41:
  store i1 true, ptr %l1, !tbaa !21
  br label %bb91
bb42:
  %t91 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t93 = trunc i64 43 to i32
  %t94 = icmp eq i32 %t91, %t93
  br i1 %t94, label %bb43, label %bb44
bb43:
  br label %bb47
bb44:
  %t96 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t98 = trunc i64 44 to i32
  %t99 = icmp eq i32 %t96, %t98
  br i1 %t99, label %bb45, label %bb46
bb45:
  br label %bb47
bb46:
  br label %bb48
bb47:
  store i1 true, ptr %l1, !tbaa !21
  br label %bb91
bb48:
  %t101 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t103 = trunc i64 52 to i32
  %t104 = icmp eq i32 %t101, %t103
  br i1 %t104, label %bb49, label %bb50
bb49:
  br label %bb61
bb50:
  %t106 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t108 = trunc i64 53 to i32
  %t109 = icmp eq i32 %t106, %t108
  br i1 %t109, label %bb51, label %bb52
bb51:
  br label %bb61
bb52:
  %t111 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t113 = trunc i64 54 to i32
  %t114 = icmp eq i32 %t111, %t113
  br i1 %t114, label %bb53, label %bb54
bb53:
  br label %bb61
bb54:
  %t116 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t118 = trunc i64 55 to i32
  %t119 = icmp eq i32 %t116, %t118
  br i1 %t119, label %bb55, label %bb56
bb55:
  br label %bb61
bb56:
  %t121 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t123 = trunc i64 56 to i32
  %t124 = icmp eq i32 %t121, %t123
  br i1 %t124, label %bb57, label %bb58
bb57:
  br label %bb61
bb58:
  %t126 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t128 = trunc i64 57 to i32
  %t129 = icmp eq i32 %t126, %t128
  br i1 %t129, label %bb59, label %bb60
bb59:
  br label %bb61
bb60:
  br label %bb62
bb61:
  store i1 true, ptr %l1, !tbaa !21
  br label %bb91
bb62:
  %t131 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t133 = trunc i64 58 to i32
  %t134 = icmp eq i32 %t131, %t133
  br i1 %t134, label %bb63, label %bb64
bb63:
  br label %bb73
bb64:
  %t136 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t138 = trunc i64 59 to i32
  %t139 = icmp eq i32 %t136, %t138
  br i1 %t139, label %bb65, label %bb66
bb65:
  br label %bb73
bb66:
  %t141 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t143 = trunc i64 60 to i32
  %t144 = icmp eq i32 %t141, %t143
  br i1 %t144, label %bb67, label %bb68
bb67:
  br label %bb73
bb68:
  %t146 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t148 = trunc i64 61 to i32
  %t149 = icmp eq i32 %t146, %t148
  br i1 %t149, label %bb69, label %bb70
bb69:
  br label %bb73
bb70:
  %t151 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t153 = trunc i64 62 to i32
  %t154 = icmp eq i32 %t151, %t153
  br i1 %t154, label %bb71, label %bb72
bb71:
  br label %bb73
bb72:
  br label %bb74
bb73:
  store i1 true, ptr %l1, !tbaa !21
  br label %bb91
bb74:
  %t156 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t158 = trunc i64 63 to i32
  %t159 = icmp eq i32 %t156, %t158
  br i1 %t159, label %bb75, label %bb76
bb75:
  br label %bb85
bb76:
  %t161 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t163 = trunc i64 64 to i32
  %t164 = icmp eq i32 %t161, %t163
  br i1 %t164, label %bb77, label %bb78
bb77:
  br label %bb85
bb78:
  %t166 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t168 = trunc i64 65 to i32
  %t169 = icmp eq i32 %t166, %t168
  br i1 %t169, label %bb79, label %bb80
bb79:
  br label %bb85
bb80:
  %t171 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t173 = trunc i64 66 to i32
  %t174 = icmp eq i32 %t171, %t173
  br i1 %t174, label %bb81, label %bb82
bb81:
  br label %bb85
bb82:
  %t176 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t178 = trunc i64 67 to i32
  %t179 = icmp eq i32 %t176, %t178
  br i1 %t179, label %bb83, label %bb84
bb83:
  br label %bb85
bb84:
  br label %bb86
bb85:
  store i1 true, ptr %l1, !tbaa !21
  br label %bb91
bb86:
  br i1 true, label %bb87, label %bb88
bb87:
  br label %bb89
bb88:
  br label %bb90
bb89:
  store i1 false, ptr %l1, !tbaa !21
  br label %bb91
bb90:
  call void @__olang_check_failed(ptr @olang_loc_a4d23bc21c2583e1_78290c8064d2bdc5)
  unreachable
bb91:
  %t181 = load i1, ptr %l1, !tbaa !21
  store i1 %t181, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fparse_2eleavingWord(i32 %a0) #0 {
entry:
  %l0 = alloca i32
  %l3 = alloca i1
  %l6 = alloca i1
  %l9 = alloca i1
  %rv = alloca i1
  store i32 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t3 = trunc i64 13 to i32
  %t4 = icmp eq i32 %t1, %t3
  br i1 %t4, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l3, !tbaa !21
  br label %bb3
bb2:
  %t6 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t8 = trunc i64 19 to i32
  %t9 = icmp eq i32 %t6, %t8
  store i1 %t9, ptr %l3, !tbaa !21
  br label %bb3
bb3:
  %t11 = load i1, ptr %l3, !tbaa !21
  br i1 %t11, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb6
bb5:
  %t12 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t14 = trunc i64 20 to i32
  %t15 = icmp eq i32 %t12, %t14
  store i1 %t15, ptr %l6, !tbaa !21
  br label %bb6
bb6:
  %t17 = load i1, ptr %l6, !tbaa !21
  br i1 %t17, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb9
bb8:
  %t18 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t20 = trunc i64 38 to i32
  %t21 = icmp eq i32 %t18, %t20
  store i1 %t21, ptr %l9, !tbaa !21
  br label %bb9
bb9:
  %t23 = load i1, ptr %l9, !tbaa !21
  store i1 %t23, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2fparse_2elineBodyRefused(ptr %v0, i32 %a0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l30 = alloca { i64, ptr }
  %l32 = alloca { i64, ptr }
  %l34 = alloca i64
  %l35 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store i32 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t3 = trunc i64 9 to i32
  %t4 = icmp eq i32 %t1, %t3
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb4
bb3:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d23, i32 0, i32 1) }, ptr %l4, !tbaa !27
  %t6 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t6, ptr %l1, !tbaa !27
  br label %bb35
bb4:
  %t8 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t10 = trunc i64 25 to i32
  %t11 = icmp eq i32 %t8, %t10
  br i1 %t11, label %bb5, label %bb6
bb5:
  br label %bb9
bb6:
  %t13 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t15 = trunc i64 26 to i32
  %t16 = icmp eq i32 %t13, %t15
  br i1 %t16, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d24, i32 0, i32 1) }, ptr %l10, !tbaa !27
  %t18 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t18, ptr %l1, !tbaa !27
  br label %bb35
bb10:
  %t20 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t22 = trunc i64 31 to i32
  %t23 = icmp eq i32 %t20, %t22
  br i1 %t23, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb14
bb13:
  store { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d25, i32 0, i32 1) }, ptr %l14, !tbaa !27
  %t25 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t25, ptr %l1, !tbaa !27
  br label %bb35
bb14:
  %t27 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t29 = trunc i64 114 to i32
  %t30 = icmp eq i32 %t27, %t29
  br i1 %t30, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb18
bb17:
  store { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d26, i32 0, i32 1) }, ptr %l18, !tbaa !27
  %t32 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t32, ptr %l1, !tbaa !27
  br label %bb35
bb18:
  %t34 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t36 = trunc i64 14 to i32
  %t37 = icmp eq i32 %t34, %t36
  br i1 %t37, label %bb19, label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb22
bb21:
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d27, i32 0, i32 1) }, ptr %l22, !tbaa !27
  %t39 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t39, ptr %l1, !tbaa !27
  br label %bb35
bb22:
  %t41 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t43 = trunc i64 16 to i32
  %t44 = icmp eq i32 %t41, %t43
  br i1 %t44, label %bb23, label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb26
bb25:
  store { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d28, i32 0, i32 1) }, ptr %l26, !tbaa !27
  %t46 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t46, ptr %l1, !tbaa !27
  br label %bb35
bb26:
  %t48 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t50 = trunc i64 17 to i32
  %t51 = icmp eq i32 %t48, %t50
  br i1 %t51, label %bb27, label %bb28
bb27:
  br label %bb29
bb28:
  br label %bb30
bb29:
  store { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d29, i32 0, i32 1) }, ptr %l30, !tbaa !27
  %t53 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t53, ptr %l1, !tbaa !27
  br label %bb35
bb30:
  br i1 true, label %bb31, label %bb32
bb31:
  br label %bb33
bb32:
  br label %bb34
bb33:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d30, i32 0, i32 1) }, ptr %l32, !tbaa !27
  %t55 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t55, ptr %l1, !tbaa !27
  br label %bb35
bb34:
  call void @__olang_check_failed(ptr @olang_loc_944ad1edd3a79eba_8cd1e5aa7bbd35a6)
  unreachable
bb35:
  %t57 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t58 = extractvalue { i64, ptr } %t57, 0
  store i64 %t58, ptr %l34, !tbaa !24
  %t59 = load i64, ptr %l34, !tbaa !24
  %t60 = mul i64 %t59, 1
  %t61 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t60)
  %t62 = insertvalue { i64, ptr } undef, i64 %t59, 0
  %t63 = insertvalue { i64, ptr } %t62, ptr %t61, 1
  store { i64, ptr } %t63, ptr %l35, !tbaa !27
  %t64 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t65 = load ptr, ptr %t64, !tbaa !27
  %t66 = getelementptr { i64, ptr }, ptr %l1, i32 0, i32 1
  %t67 = load ptr, ptr %t66, !tbaa !27
  %t68 = load i64, ptr %l34, !tbaa !24
  %t69 = mul i64 %t68, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t65, ptr %t67, i64 %t69, i1 false)
  %t70 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t70, ptr %l1, !tbaa !27
  %t71 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t71, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2fparse_2epromiseWord(i32 %a0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca i1
  %rv = alloca i1
  store i32 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t3 = trunc i64 57 to i32
  %t4 = icmp eq i32 %t1, %t3
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %bb11
bb2:
  %t6 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t8 = trunc i64 58 to i32
  %t9 = icmp eq i32 %t6, %t8
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb11
bb4:
  %t11 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t13 = trunc i64 59 to i32
  %t14 = icmp eq i32 %t11, %t13
  br i1 %t14, label %bb5, label %bb6
bb5:
  br label %bb11
bb6:
  %t16 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t18 = trunc i64 60 to i32
  %t19 = icmp eq i32 %t16, %t18
  br i1 %t19, label %bb7, label %bb8
bb7:
  br label %bb11
bb8:
  %t21 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t23 = trunc i64 61 to i32
  %t24 = icmp eq i32 %t21, %t23
  br i1 %t24, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  store i1 true, ptr %l1, !tbaa !21
  br label %bb29
bb12:
  %t26 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t28 = trunc i64 62 to i32
  %t29 = icmp eq i32 %t26, %t28
  br i1 %t29, label %bb13, label %bb14
bb13:
  br label %bb23
bb14:
  %t31 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t33 = trunc i64 63 to i32
  %t34 = icmp eq i32 %t31, %t33
  br i1 %t34, label %bb15, label %bb16
bb15:
  br label %bb23
bb16:
  %t36 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t38 = trunc i64 64 to i32
  %t39 = icmp eq i32 %t36, %t38
  br i1 %t39, label %bb17, label %bb18
bb17:
  br label %bb23
bb18:
  %t41 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t43 = trunc i64 65 to i32
  %t44 = icmp eq i32 %t41, %t43
  br i1 %t44, label %bb19, label %bb20
bb19:
  br label %bb23
bb20:
  %t46 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t48 = trunc i64 66 to i32
  %t49 = icmp eq i32 %t46, %t48
  br i1 %t49, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  store i1 true, ptr %l1, !tbaa !21
  br label %bb29
bb24:
  br i1 true, label %bb25, label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb28
bb27:
  store i1 false, ptr %l1, !tbaa !21
  br label %bb29
bb28:
  call void @__olang_check_failed(ptr @olang_loc_674728a9afb53deb_f473243cfc12c1d7)
  unreachable
bb29:
  %t51 = load i1, ptr %l1, !tbaa !21
  store i1 %t51, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2fparse_2eshapeDecl(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca %"std/prelude/text:StringBuilder"
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca %"std/prelude/text:StringBuilder"
  %l11 = alloca ptr
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l18 = alloca i1
  %l29 = alloca { i64, ptr }
  %l31 = alloca %"std/prelude/text:StringBuilder"
  %l32 = alloca ptr
  %l36 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l50 = alloca ptr
  %l54 = alloca { i64, ptr }
  %l61 = alloca { i64, ptr }
  %l62 = alloca ptr
  %l63 = alloca i1
  %l68 = alloca %"std/prelude/text:StringBuilder"
  %l69 = alloca ptr
  %l73 = alloca { i64, ptr }
  %l78 = alloca ptr
  %l79 = alloca i1
  %l91 = alloca { i64, ptr }
  %l94 = alloca ptr
  %l99 = alloca { i64, ptr }
  %l103 = alloca { i64, ptr }
  %l110 = alloca { i64, ptr }
  %l111 = alloca { i64, ptr }
  %l112 = alloca { i64, ptr }
  %l113 = alloca i64
  %l114 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l17, !tbaa !29
  store i1 false, ptr %l18, !tbaa !21
  %t2 = load ptr, ptr %l17, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l17, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 12}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l18, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l18, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [8 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { ptr }, ptr %t12, i32 0, i32 0
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l3, !tbaa !29
  br label %bb5
bb4:
  br label %bb22
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t16 = load ptr, ptr %l3, !tbaa !29
  %t18 = getelementptr %"compiler/ast:Func", ptr %t16, i32 0, i32 6
  %t19 = load i1, ptr %t18, !tbaa !21
  %t21 = xor i1 %t19, true
  br i1 %t21, label %bb6, label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s2
  %t23 = load ptr, ptr %l1, !tbaa !29
  %t24 = load ptr, ptr %l3, !tbaa !29
  %t26 = getelementptr %"compiler/ast:Func", ptr %t24, i32 0, i32 2
  %t27 = load i32, ptr %t26, !tbaa !23
  %t30 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v1, ptr %s2, ptr %t23, i32 %t27)
  store { i64, ptr } %t30, ptr %l29
  br label %bb8
bb7:
  br label %bb9
bb8:
  %t31 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d31, i32 0, i32 1) }, 1
  %t32 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d31, i32 0, i32 1) }, 0
  %t33 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t34 = extractvalue { i64, ptr } %t33, 1
  %t35 = extractvalue { i64, ptr } %t33, 0
  %t36 = add i64 %t32, %t35
  %t37 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d32, i32 0, i32 1) }, 1
  %t38 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d32, i32 0, i32 1) }, 0
  %t39 = add i64 %t36, %t38
  %t40 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t39)
  call void @olang_textcopy(ptr %t40, ptr %t31, i64 %t32)
  %t41 = getelementptr i8, ptr %t40, i64 %t32
  call void @olang_textcopy(ptr %t41, ptr %t34, i64 %t35)
  %t42 = getelementptr i8, ptr %t41, i64 %t35
  call void @olang_textcopy(ptr %t42, ptr %t37, i64 %t38)
  %t43 = insertvalue { i64, ptr } undef, i64 %t39, 0
  %t44 = insertvalue { i64, ptr } %t43, ptr %t40, 1
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s1)
  store { i64, ptr } %t44, ptr %rv
  br label %ret
bb9:
  %t46 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s1)
  store %"std/prelude/text:StringBuilder" %t46, ptr %l31
  br label %bb10
bb10:
  %t47 = load %"std/prelude/text:StringBuilder", ptr %l31
  store %"std/prelude/text:StringBuilder" %t47, ptr %l4
  store ptr %l4, ptr %l32, !tbaa !29
  %t48 = load ptr, ptr %l1, !tbaa !29
  %t49 = load ptr, ptr %l3, !tbaa !29
  %t51 = getelementptr %"compiler/ast:Func", ptr %t49, i32 0, i32 2
  %t52 = load i32, ptr %t51, !tbaa !23
  %t55 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v1, ptr %s1, ptr %t48, i32 %t52)
  store { i64, ptr } %t55, ptr %l36
  br label %bb11
bb11:
  %t56 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d33, i32 0, i32 1) }, 1
  %t57 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d33, i32 0, i32 1) }, 0
  %t58 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t59 = extractvalue { i64, ptr } %t58, 1
  %t60 = extractvalue { i64, ptr } %t58, 0
  %t61 = add i64 %t57, %t60
  %t62 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d34, i32 0, i32 1) }, 1
  %t63 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d34, i32 0, i32 1) }, 0
  %t64 = add i64 %t61, %t63
  %t65 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t64)
  call void @olang_textcopy(ptr %t65, ptr %t56, i64 %t57)
  %t66 = getelementptr i8, ptr %t65, i64 %t57
  call void @olang_textcopy(ptr %t66, ptr %t59, i64 %t60)
  %t67 = getelementptr i8, ptr %t66, i64 %t60
  call void @olang_textcopy(ptr %t67, ptr %t62, i64 %t63)
  %t68 = insertvalue { i64, ptr } undef, i64 %t64, 0
  %t69 = insertvalue { i64, ptr } %t68, ptr %t65, 1
  %t71 = load ptr, ptr %l32, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s1, ptr %s1, ptr %t71, { i64, ptr } %t69)
  br label %bb12
bb12:
  %t73 = load ptr, ptr %l3, !tbaa !29
  %t75 = getelementptr %"compiler/ast:Func", ptr %t73, i32 0, i32 4
  %t76 = load { i64, ptr }, ptr %t75, !tbaa !27
  store { i64, ptr } %t76, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t78 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t80 = extractvalue { i64, ptr } %t78, 0
  store i64 %t80, ptr %l7, !tbaa !24
  br label %bb13
bb13:
  store %olang.scope zeroinitializer, ptr %s6
  %t82 = load i64, ptr %l6, !tbaa !24
  %t83 = load i64, ptr %l7, !tbaa !24
  %t86 = icmp slt i64 %t82, %t83
  %t88 = xor i1 %t86, true
  br i1 %t88, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s6)
  br label %bb20
bb15:
  br label %bb16
bb16:
  %t90 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t90, ptr %l47, !tbaa !27
  %t91 = load i64, ptr %l6, !tbaa !24
  %t93 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t94 = load ptr, ptr %t93, !tbaa !27
  %t95 = getelementptr ptr, ptr %t94, i64 %t91
  %t96 = load ptr, ptr %t95, !tbaa !39
  store ptr %l4, ptr %l50, !tbaa !29
  %t99 = load ptr, ptr %l1, !tbaa !29
  %t104 = call { i64, ptr } @compiler_2fparse_2eshapeStmt(ptr %v0, ptr %v1, ptr %v2, ptr %s6, ptr %t96, ptr %t99, { i64, ptr } %a2)
  store { i64, ptr } %t104, ptr %l54
  br label %bb17
bb17:
  %t105 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d35, i32 0, i32 1) }, 1
  %t106 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d35, i32 0, i32 1) }, 0
  %t107 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t108 = extractvalue { i64, ptr } %t107, 1
  %t109 = extractvalue { i64, ptr } %t107, 0
  %t110 = add i64 %t106, %t109
  %t111 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t110)
  call void @olang_textcopy(ptr %t111, ptr %t105, i64 %t106)
  %t112 = getelementptr i8, ptr %t111, i64 %t106
  call void @olang_textcopy(ptr %t112, ptr %t108, i64 %t109)
  %t113 = insertvalue { i64, ptr } undef, i64 %t110, 0
  %t114 = insertvalue { i64, ptr } %t113, ptr %t111, 1
  %t116 = load ptr, ptr %l50, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s1, ptr %s6, ptr %t116, { i64, ptr } %t114)
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s6)
  br label %bb19
bb19:
  %t118 = load i64, ptr %l6, !tbaa !24
  %t121 = add i64 %t118, 1
  store i64 %t121, ptr %l6, !tbaa !24
  br label %bb13
bb20:
  %t124 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s1, ptr %v3, ptr %l4)
  store { i64, ptr } %t124, ptr %l61
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s1)
  %t125 = load { i64, ptr }, ptr %l61, !tbaa !27
  store { i64, ptr } %t125, ptr %rv
  br label %ret
bb22:
  %t126 = load ptr, ptr %l0, !tbaa !29
  store ptr %t126, ptr %l62, !tbaa !29
  store i1 false, ptr %l63, !tbaa !21
  %t127 = load ptr, ptr %l62, !tbaa !29
  %t128 = icmp ne ptr %t127, null
  br i1 %t128, label %bb23, label %bb24
bb23:
  %t130 = load ptr, ptr %l62, !tbaa !29
  %t131 = load i64, ptr %t130, !range !{i64 0, i64 12}
  %t133 = icmp eq i64 %t131, 2
  store i1 %t133, ptr %l63, !tbaa !21
  br label %bb24
bb24:
  %t134 = load i1, ptr %l63, !tbaa !21
  br i1 %t134, label %bb25, label %bb26
bb25:
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t137 = getelementptr { i64, [8 x i64] }, ptr %t135, i32 0, i32 1
  %t138 = getelementptr { %"compiler/source:Span", ptr }, ptr %t137, i32 0, i32 1
  %t139 = load ptr, ptr %t138
  store ptr %t139, ptr %l9, !tbaa !29
  br label %bb27
bb26:
  br label %bb54
bb27:
  store %olang.scope zeroinitializer, ptr %s9
  %t141 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s9)
  store %"std/prelude/text:StringBuilder" %t141, ptr %l68
  br label %bb28
bb28:
  %t142 = load %"std/prelude/text:StringBuilder", ptr %l68
  store %"std/prelude/text:StringBuilder" %t142, ptr %l10
  store ptr %l10, ptr %l69, !tbaa !29
  %t143 = load ptr, ptr %l1, !tbaa !29
  %t144 = load ptr, ptr %l9, !tbaa !29
  %t146 = getelementptr %"compiler/ast:TypeDecl", ptr %t144, i32 0, i32 0
  %t147 = load i32, ptr %t146, !tbaa !23
  %t150 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v1, ptr %s9, ptr %t143, i32 %t147)
  store { i64, ptr } %t150, ptr %l73
  br label %bb29
bb29:
  %t151 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d36, i32 0, i32 1) }, 1
  %t152 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d36, i32 0, i32 1) }, 0
  %t153 = load { i64, ptr }, ptr %l73, !tbaa !27
  %t154 = extractvalue { i64, ptr } %t153, 1
  %t155 = extractvalue { i64, ptr } %t153, 0
  %t156 = add i64 %t152, %t155
  %t157 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t156)
  call void @olang_textcopy(ptr %t157, ptr %t151, i64 %t152)
  %t158 = getelementptr i8, ptr %t157, i64 %t152
  call void @olang_textcopy(ptr %t158, ptr %t154, i64 %t155)
  %t159 = insertvalue { i64, ptr } undef, i64 %t156, 0
  %t160 = insertvalue { i64, ptr } %t159, ptr %t157, 1
  %t162 = load ptr, ptr %l69, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s9, ptr %s9, ptr %t162, { i64, ptr } %t160)
  br label %bb30
bb30:
  %t164 = load ptr, ptr %l9, !tbaa !29
  %t166 = getelementptr %"compiler/ast:TypeDecl", ptr %t164, i32 0, i32 3
  %t167 = load ptr, ptr %t166, !tbaa !29
  store ptr %t167, ptr %l11, !tbaa !29
  %t169 = load ptr, ptr %l11, !tbaa !29
  store ptr %t169, ptr %l78, !tbaa !29
  store i1 false, ptr %l79, !tbaa !21
  %t170 = load ptr, ptr %l78, !tbaa !29
  %t171 = icmp ne ptr %t170, null
  br i1 %t171, label %bb31, label %bb32
bb31:
  %t173 = load ptr, ptr %l78, !tbaa !29
  %t174 = load i64, ptr %t173, !range !{i64 0, i64 5}
  %t176 = icmp eq i64 %t174, 2
  store i1 %t176, ptr %l79, !tbaa !21
  br label %bb32
bb32:
  %t177 = load i1, ptr %l79, !tbaa !21
  br i1 %t177, label %bb33, label %bb34
bb33:
  %t178 = load ptr, ptr %l11, !tbaa !29
  %t180 = getelementptr { i64, [6 x i64] }, ptr %t178, i32 0, i32 1
  %t181 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr } }, ptr %t180, i32 0, i32 0
  %t182 = load { i64, ptr }, ptr %t181
  store { i64, ptr } %t182, ptr %l12, !tbaa !27
  br label %bb35
bb34:
  br label %bb47
bb35:
  %t184 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t184, ptr %l13, !tbaa !27
  store i64 0, ptr %l14, !tbaa !24
  %t186 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t188 = extractvalue { i64, ptr } %t186, 0
  store i64 %t188, ptr %l15, !tbaa !24
  br label %bb36
bb36:
  store %olang.scope zeroinitializer, ptr %s13
  %t190 = load i64, ptr %l14, !tbaa !24
  %t191 = load i64, ptr %l15, !tbaa !24
  %t194 = icmp slt i64 %t190, %t191
  %t196 = xor i1 %t194, true
  br i1 %t196, label %bb37, label %bb38
bb37:
  call void @__olang_scope_close(ptr %s13)
  br label %bb46
bb38:
  br label %bb39
bb39:
  %t198 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t198, ptr %l91, !tbaa !27
  %t199 = load i64, ptr %l14, !tbaa !24
  %t201 = getelementptr { i64, ptr }, ptr %l91, i32 0, i32 1
  %t202 = load ptr, ptr %t201, !tbaa !27
  %t203 = getelementptr ptr, ptr %t202, i64 %t199
  %t204 = load ptr, ptr %t203, !tbaa !39
  store ptr %t204, ptr %l16, !tbaa !29
  store ptr %l10, ptr %l94, !tbaa !29
  %t206 = load ptr, ptr %l16, !tbaa !29
  %t208 = getelementptr %"compiler/ast:Func", ptr %t206, i32 0, i32 1
  %t209 = load ptr, ptr %t208, !tbaa !29
  %t211 = icmp eq ptr %t209, null
  %t213 = xor i1 %t211, true
  br i1 %t213, label %bb40, label %bb41
bb40:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d37, i32 0, i32 1) }, ptr %l99, !tbaa !27
  br label %bb42
bb41:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d38, i32 0, i32 1) }, ptr %l99, !tbaa !27
  br label %bb42
bb42:
  %t215 = load ptr, ptr %l1, !tbaa !29
  %t216 = load ptr, ptr %l16, !tbaa !29
  %t218 = getelementptr %"compiler/ast:Func", ptr %t216, i32 0, i32 2
  %t219 = load i32, ptr %t218, !tbaa !23
  %t222 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v1, ptr %s13, ptr %t215, i32 %t219)
  store { i64, ptr } %t222, ptr %l103
  br label %bb43
bb43:
  %t223 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d39, i32 0, i32 1) }, 1
  %t224 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d39, i32 0, i32 1) }, 0
  %t225 = load { i64, ptr }, ptr %l99, !tbaa !27
  %t226 = extractvalue { i64, ptr } %t225, 1
  %t227 = extractvalue { i64, ptr } %t225, 0
  %t228 = add i64 %t224, %t227
  %t229 = load { i64, ptr }, ptr %l103, !tbaa !27
  %t230 = extractvalue { i64, ptr } %t229, 1
  %t231 = extractvalue { i64, ptr } %t229, 0
  %t232 = add i64 %t228, %t231
  %t233 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t232)
  call void @olang_textcopy(ptr %t233, ptr %t223, i64 %t224)
  %t234 = getelementptr i8, ptr %t233, i64 %t224
  call void @olang_textcopy(ptr %t234, ptr %t226, i64 %t227)
  %t235 = getelementptr i8, ptr %t234, i64 %t227
  call void @olang_textcopy(ptr %t235, ptr %t230, i64 %t231)
  %t236 = insertvalue { i64, ptr } undef, i64 %t232, 0
  %t237 = insertvalue { i64, ptr } %t236, ptr %t233, 1
  %t239 = load ptr, ptr %l94, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s9, ptr %s13, ptr %t239, { i64, ptr } %t237)
  br label %bb44
bb44:
  call void @__olang_scope_close(ptr %s13)
  br label %bb45
bb45:
  %t241 = load i64, ptr %l14, !tbaa !24
  %t244 = add i64 %t241, 1
  store i64 %t244, ptr %l14, !tbaa !24
  br label %bb36
bb46:
  br label %bb52
bb47:
  br i1 true, label %bb48, label %bb49
bb48:
  br label %bb50
bb49:
  br label %bb51
bb50:
  br label %bb52
bb51:
  call void @__olang_check_failed(ptr @olang_loc_3aa36594c4c33747_9481be0c1eb7a3c3)
  unreachable
bb52:
  %t247 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s9, ptr %v3, ptr %l10)
  store { i64, ptr } %t247, ptr %l110
  br label %bb53
bb53:
  call void @__olang_scope_close(ptr %s9)
  %t248 = load { i64, ptr }, ptr %l110, !tbaa !27
  store { i64, ptr } %t248, ptr %rv
  br label %ret
bb54:
  br i1 true, label %bb55, label %bb56
bb55:
  br label %bb57
bb56:
  br label %bb58
bb57:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d40, i32 0, i32 1) }, ptr %l111, !tbaa !27
  %t249 = load { i64, ptr }, ptr %l111, !tbaa !27
  store { i64, ptr } %t249, ptr %l112, !tbaa !27
  %t250 = load { i64, ptr }, ptr %l112, !tbaa !27
  %t251 = extractvalue { i64, ptr } %t250, 0
  store i64 %t251, ptr %l113, !tbaa !24
  %t252 = load i64, ptr %l113, !tbaa !24
  %t253 = mul i64 %t252, 1
  %t254 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t253)
  %t255 = insertvalue { i64, ptr } undef, i64 %t252, 0
  %t256 = insertvalue { i64, ptr } %t255, ptr %t254, 1
  store { i64, ptr } %t256, ptr %l114, !tbaa !27
  %t257 = getelementptr { i64, ptr }, ptr %l114, i32 0, i32 1
  %t258 = load ptr, ptr %t257, !tbaa !27
  %t259 = getelementptr { i64, ptr }, ptr %l112, i32 0, i32 1
  %t260 = load ptr, ptr %t259, !tbaa !27
  %t261 = load i64, ptr %l113, !tbaa !24
  %t262 = mul i64 %t261, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t258, ptr %t260, i64 %t262, i1 false)
  %t263 = load { i64, ptr }, ptr %l114, !tbaa !27
  store { i64, ptr } %t263, ptr %l112, !tbaa !27
  %t264 = load { i64, ptr }, ptr %l112, !tbaa !27
  store { i64, ptr } %t264, ptr %rv
  br label %ret
bb58:
  call void @__olang_check_failed(ptr @olang_loc_4f160b4312e342e6_588517f053075c42)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fparse_2eshapeStmt(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca { i64, ptr }
  %l10 = alloca ptr
  %l11 = alloca i1
  %l19 = alloca { i64, ptr }
  %l20 = alloca ptr
  %l21 = alloca i1
  %l29 = alloca { i64, ptr }
  %l30 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l38 = alloca ptr
  %l39 = alloca i1
  %l47 = alloca { i64, ptr }
  %l49 = alloca ptr
  %l50 = alloca i1
  %l57 = alloca i64
  %l60 = alloca { i64, ptr }
  %l65 = alloca { i64, ptr }
  %l67 = alloca ptr
  %l68 = alloca i1
  %l75 = alloca i64
  %l78 = alloca { i64, ptr }
  %l81 = alloca { i64, ptr }
  %l86 = alloca ptr
  %l87 = alloca i1
  %l96 = alloca { i64, ptr }
  %l98 = alloca { i64, ptr }
  %l100 = alloca i64
  %l101 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l10, !tbaa !29
  store i1 false, ptr %l11, !tbaa !21
  %t2 = load ptr, ptr %l10, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l10, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 22}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l11, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l11, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", ptr }, ptr %t12, i32 0, i32 1
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l3, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l3, !tbaa !29
  %t17 = load ptr, ptr %l1, !tbaa !29
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t22 = call { i64, ptr } @compiler_2fparse_2eshapeExpr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t16, ptr %t17, { i64, ptr } %t18)
  store { i64, ptr } %t22, ptr %l19
  br label %bb6
bb6:
  %t23 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t23, ptr %l9, !tbaa !27
  br label %bb62
bb7:
  %t24 = load ptr, ptr %l0, !tbaa !29
  store ptr %t24, ptr %l20, !tbaa !29
  store i1 false, ptr %l21, !tbaa !21
  %t25 = load ptr, ptr %l20, !tbaa !29
  %t26 = icmp ne ptr %t25, null
  br i1 %t26, label %bb8, label %bb9
bb8:
  %t28 = load ptr, ptr %l20, !tbaa !29
  %t29 = load i64, ptr %t28, !range !{i64 0, i64 22}
  %t31 = icmp eq i64 %t29, 12
  store i1 %t31, ptr %l21, !tbaa !21
  br label %bb9
bb9:
  %t32 = load i1, ptr %l21, !tbaa !21
  br i1 %t32, label %bb10, label %bb11
bb10:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr { i64, [4 x i64] }, ptr %t33, i32 0, i32 1
  %t36 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t35, i32 0, i32 1
  %t37 = load { i64, ptr }, ptr %t36
  store { i64, ptr } %t37, ptr %l4, !tbaa !27
  br label %bb12
bb11:
  br label %bb17
bb12:
  store %olang.scope zeroinitializer, ptr %s2
  %t39 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t39, 0
  %t43 = icmp sgt i64 %t41, 0
  br i1 %t43, label %bb13, label %bb14
bb13:
  %t45 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t45, ptr %l30, !tbaa !27
  %t46 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !27
  %t48 = getelementptr ptr, ptr %t47, i64 0
  %t49 = load ptr, ptr %t48, !tbaa !39
  %t50 = load ptr, ptr %l1, !tbaa !29
  %t51 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t55 = call { i64, ptr } @compiler_2fparse_2eshapeExpr(ptr %v0, ptr %v1, ptr %v2, ptr %s2, ptr %t49, ptr %t50, { i64, ptr } %t51)
  store { i64, ptr } %t55, ptr %l34
  br label %bb15
bb14:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d41, i32 0, i32 1) }, ptr %l29, !tbaa !27
  br label %bb16
bb15:
  %t56 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d42, i32 0, i32 1) }, 1
  %t57 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d42, i32 0, i32 1) }, 0
  %t58 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t59 = extractvalue { i64, ptr } %t58, 1
  %t60 = extractvalue { i64, ptr } %t58, 0
  %t61 = add i64 %t57, %t60
  %t62 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t61)
  call void @olang_textcopy(ptr %t62, ptr %t56, i64 %t57)
  %t63 = getelementptr i8, ptr %t62, i64 %t57
  call void @olang_textcopy(ptr %t63, ptr %t59, i64 %t60)
  %t64 = insertvalue { i64, ptr } undef, i64 %t61, 0
  %t65 = insertvalue { i64, ptr } %t64, ptr %t62, 1
  store { i64, ptr } %t65, ptr %l29, !tbaa !27
  br label %bb16
bb16:
  %t68 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d43, i32 0, i32 1) }, 1
  %t69 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d43, i32 0, i32 1) }, 0
  %t70 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t71 = extractvalue { i64, ptr } %t70, 1
  %t72 = extractvalue { i64, ptr } %t70, 0
  %t73 = add i64 %t69, %t72
  %t74 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t73)
  call void @olang_textcopy(ptr %t74, ptr %t68, i64 %t69)
  %t75 = getelementptr i8, ptr %t74, i64 %t69
  call void @olang_textcopy(ptr %t75, ptr %t71, i64 %t72)
  %t76 = insertvalue { i64, ptr } undef, i64 %t73, 0
  %t77 = insertvalue { i64, ptr } %t76, ptr %t74, 1
  store { i64, ptr } %t77, ptr %l9, !tbaa !27
  call void @__olang_scope_close(ptr %s2)
  br label %bb62
bb17:
  %t79 = load ptr, ptr %l0, !tbaa !29
  store ptr %t79, ptr %l38, !tbaa !29
  store i1 false, ptr %l39, !tbaa !21
  %t80 = load ptr, ptr %l38, !tbaa !29
  %t81 = icmp ne ptr %t80, null
  br i1 %t81, label %bb18, label %bb19
bb18:
  %t83 = load ptr, ptr %l38, !tbaa !29
  %t84 = load i64, ptr %t83, !range !{i64 0, i64 22}
  %t86 = icmp eq i64 %t84, 15
  store i1 %t86, ptr %l39, !tbaa !21
  br label %bb19
bb19:
  %t87 = load i1, ptr %l39, !tbaa !21
  br i1 %t87, label %bb20, label %bb21
bb20:
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t90 = getelementptr { i64, [4 x i64] }, ptr %t88, i32 0, i32 1
  %t91 = getelementptr { %"compiler/source:Span", ptr }, ptr %t90, i32 0, i32 1
  %t92 = load ptr, ptr %t91
  store ptr %t92, ptr %l5, !tbaa !29
  br label %bb22
bb21:
  br label %bb24
bb22:
  store %olang.scope zeroinitializer, ptr %s5
  %t94 = load ptr, ptr %l5, !tbaa !29
  %t95 = load ptr, ptr %l1, !tbaa !29
  %t96 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t100 = call { i64, ptr } @compiler_2fparse_2eshapeExpr(ptr %v0, ptr %v1, ptr %v2, ptr %s5, ptr %t94, ptr %t95, { i64, ptr } %t96)
  store { i64, ptr } %t100, ptr %l47
  br label %bb23
bb23:
  %t101 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d44, i32 0, i32 1) }, 1
  %t102 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d44, i32 0, i32 1) }, 0
  %t103 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t104 = extractvalue { i64, ptr } %t103, 1
  %t105 = extractvalue { i64, ptr } %t103, 0
  %t106 = add i64 %t102, %t105
  %t107 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t106)
  call void @olang_textcopy(ptr %t107, ptr %t101, i64 %t102)
  %t108 = getelementptr i8, ptr %t107, i64 %t102
  call void @olang_textcopy(ptr %t108, ptr %t104, i64 %t105)
  %t109 = insertvalue { i64, ptr } undef, i64 %t106, 0
  %t110 = insertvalue { i64, ptr } %t109, ptr %t107, 1
  store { i64, ptr } %t110, ptr %l9, !tbaa !27
  call void @__olang_scope_close(ptr %s5)
  br label %bb62
bb24:
  %t112 = load ptr, ptr %l0, !tbaa !29
  store ptr %t112, ptr %l49, !tbaa !29
  store i1 false, ptr %l50, !tbaa !21
  %t113 = load ptr, ptr %l49, !tbaa !29
  %t114 = icmp ne ptr %t113, null
  br i1 %t114, label %bb25, label %bb26
bb25:
  %t116 = load ptr, ptr %l49, !tbaa !29
  %t117 = load i64, ptr %t116, !range !{i64 0, i64 22}
  %t119 = icmp eq i64 %t117, 1
  store i1 %t119, ptr %l50, !tbaa !21
  br label %bb26
bb26:
  %t120 = load i1, ptr %l50, !tbaa !21
  br i1 %t120, label %bb27, label %bb28
bb27:
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t123 = getelementptr { i64, [4 x i64] }, ptr %t121, i32 0, i32 1
  %t124 = getelementptr { %"compiler/source:Span", ptr }, ptr %t123, i32 0, i32 1
  %t125 = load ptr, ptr %t124
  store ptr %t125, ptr %l6, !tbaa !29
  br label %bb29
bb28:
  br label %bb36
bb29:
  %t127 = load ptr, ptr %l6, !tbaa !29
  %t129 = getelementptr %"compiler/ast:VarDecl", ptr %t127, i32 0, i32 0
  %t130 = load { i64, ptr }, ptr %t129, !tbaa !27
  %t132 = extractvalue { i64, ptr } %t130, 0
  store i64 %t132, ptr %l57, !tbaa !24
  %t133 = load ptr, ptr %l6, !tbaa !29
  %t135 = getelementptr %"compiler/ast:VarDecl", ptr %t133, i32 0, i32 4
  %t136 = load i1, ptr %t135, !tbaa !21
  br i1 %t136, label %bb30, label %bb31
bb30:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d45, i32 0, i32 1) }, ptr %l60, !tbaa !27
  br label %bb32
bb31:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d46, i32 0, i32 1) }, ptr %l60, !tbaa !27
  br label %bb32
bb32:
  %t138 = load ptr, ptr %l6, !tbaa !29
  %t140 = getelementptr %"compiler/ast:VarDecl", ptr %t138, i32 0, i32 2
  %t141 = load ptr, ptr %t140, !tbaa !29
  %t143 = icmp eq ptr %t141, null
  %t145 = xor i1 %t143, true
  br i1 %t145, label %bb33, label %bb34
bb33:
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d47, i32 0, i32 1) }, ptr %l65, !tbaa !27
  br label %bb35
bb34:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d48, i32 0, i32 1) }, ptr %l65, !tbaa !27
  br label %bb35
bb35:
  %t147 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d49, i32 0, i32 1) }, 1
  %t148 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d49, i32 0, i32 1) }, 0
  %t149 = load i64, ptr %l57, !tbaa !24
  %t150 = call i64 @__olang_fmt_i64(ptr null, i64 %t149)
  %t151 = add i64 %t148, %t150
  %t152 = load { i64, ptr }, ptr %l60, !tbaa !27
  %t153 = extractvalue { i64, ptr } %t152, 1
  %t154 = extractvalue { i64, ptr } %t152, 0
  %t155 = add i64 %t151, %t154
  %t156 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t157 = extractvalue { i64, ptr } %t156, 1
  %t158 = extractvalue { i64, ptr } %t156, 0
  %t159 = add i64 %t155, %t158
  %t160 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t159)
  call void @olang_textcopy(ptr %t160, ptr %t147, i64 %t148)
  %t161 = getelementptr i8, ptr %t160, i64 %t148
  %t162 = call i64 @__olang_fmt_i64(ptr %t161, i64 %t149)
  %t163 = getelementptr i8, ptr %t161, i64 %t150
  call void @olang_textcopy(ptr %t163, ptr %t153, i64 %t154)
  %t164 = getelementptr i8, ptr %t163, i64 %t154
  call void @olang_textcopy(ptr %t164, ptr %t157, i64 %t158)
  %t165 = insertvalue { i64, ptr } undef, i64 %t159, 0
  %t166 = insertvalue { i64, ptr } %t165, ptr %t160, 1
  store { i64, ptr } %t166, ptr %l9, !tbaa !27
  br label %bb62
bb36:
  %t168 = load ptr, ptr %l0, !tbaa !29
  store ptr %t168, ptr %l67, !tbaa !29
  store i1 false, ptr %l68, !tbaa !21
  %t169 = load ptr, ptr %l67, !tbaa !29
  %t170 = icmp ne ptr %t169, null
  br i1 %t170, label %bb37, label %bb38
bb37:
  %t172 = load ptr, ptr %l67, !tbaa !29
  %t173 = load i64, ptr %t172, !range !{i64 0, i64 22}
  %t175 = icmp eq i64 %t173, 2
  store i1 %t175, ptr %l68, !tbaa !21
  br label %bb38
bb38:
  %t176 = load i1, ptr %l68, !tbaa !21
  br i1 %t176, label %bb39, label %bb40
bb39:
  %t177 = load ptr, ptr %l0, !tbaa !29
  %t179 = getelementptr { i64, [4 x i64] }, ptr %t177, i32 0, i32 1
  %t180 = getelementptr { %"compiler/source:Span", ptr }, ptr %t179, i32 0, i32 1
  %t181 = load ptr, ptr %t180
  store ptr %t181, ptr %l7, !tbaa !29
  br label %bb41
bb40:
  br label %bb48
bb41:
  %t183 = load ptr, ptr %l7, !tbaa !29
  %t185 = getelementptr %"compiler/ast:Multi", ptr %t183, i32 0, i32 0
  %t186 = load { i64, ptr }, ptr %t185, !tbaa !27
  %t188 = extractvalue { i64, ptr } %t186, 0
  store i64 %t188, ptr %l75, !tbaa !24
  %t189 = load ptr, ptr %l7, !tbaa !29
  %t191 = getelementptr %"compiler/ast:Multi", ptr %t189, i32 0, i32 1
  %t192 = load i1, ptr %t191, !tbaa !21
  br i1 %t192, label %bb42, label %bb43
bb42:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d50, i32 0, i32 1) }, ptr %l78, !tbaa !27
  br label %bb47
bb43:
  %t194 = load ptr, ptr %l7, !tbaa !29
  %t196 = getelementptr %"compiler/ast:Multi", ptr %t194, i32 0, i32 3
  %t197 = load i1, ptr %t196, !tbaa !21
  br i1 %t197, label %bb44, label %bb45
bb44:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d51, i32 0, i32 1) }, ptr %l81, !tbaa !27
  br label %bb46
bb45:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d52, i32 0, i32 1) }, ptr %l81, !tbaa !27
  br label %bb46
bb46:
  %t199 = load { i64, ptr }, ptr %l81, !tbaa !27
  store { i64, ptr } %t199, ptr %l78, !tbaa !27
  br label %bb47
bb47:
  %t200 = load ptr, ptr %l7, !tbaa !29
  %t202 = getelementptr %"compiler/ast:Multi", ptr %t200, i32 0, i32 2
  %t203 = load { i64, ptr }, ptr %t202, !tbaa !27
  %t205 = extractvalue { i64, ptr } %t203, 0
  %t206 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d53, i32 0, i32 1) }, 1
  %t207 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d53, i32 0, i32 1) }, 0
  %t208 = load i64, ptr %l75, !tbaa !24
  %t209 = call i64 @__olang_fmt_i64(ptr null, i64 %t208)
  %t210 = add i64 %t207, %t209
  %t211 = load { i64, ptr }, ptr %l78, !tbaa !27
  %t212 = extractvalue { i64, ptr } %t211, 1
  %t213 = extractvalue { i64, ptr } %t211, 0
  %t214 = add i64 %t210, %t213
  %t216 = call i64 @__olang_fmt_i64(ptr null, i64 %t205)
  %t217 = add i64 %t214, %t216
  %t218 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t217)
  call void @olang_textcopy(ptr %t218, ptr %t206, i64 %t207)
  %t219 = getelementptr i8, ptr %t218, i64 %t207
  %t220 = call i64 @__olang_fmt_i64(ptr %t219, i64 %t208)
  %t221 = getelementptr i8, ptr %t219, i64 %t209
  call void @olang_textcopy(ptr %t221, ptr %t212, i64 %t213)
  %t222 = getelementptr i8, ptr %t221, i64 %t213
  %t223 = call i64 @__olang_fmt_i64(ptr %t222, i64 %t205)
  %t224 = insertvalue { i64, ptr } undef, i64 %t217, 0
  %t225 = insertvalue { i64, ptr } %t224, ptr %t218, 1
  store { i64, ptr } %t225, ptr %l9, !tbaa !27
  br label %bb62
bb48:
  %t227 = load ptr, ptr %l0, !tbaa !29
  store ptr %t227, ptr %l86, !tbaa !29
  store i1 false, ptr %l87, !tbaa !21
  %t228 = load ptr, ptr %l86, !tbaa !29
  %t229 = icmp ne ptr %t228, null
  br i1 %t229, label %bb49, label %bb50
bb49:
  %t231 = load ptr, ptr %l86, !tbaa !29
  %t232 = load i64, ptr %t231, !range !{i64 0, i64 22}
  %t234 = icmp eq i64 %t232, 5
  store i1 %t234, ptr %l87, !tbaa !21
  br label %bb50
bb50:
  %t235 = load i1, ptr %l87, !tbaa !21
  br i1 %t235, label %bb51, label %bb52
bb51:
  %t236 = load ptr, ptr %l0, !tbaa !29
  %t238 = getelementptr { i64, [4 x i64] }, ptr %t236, i32 0, i32 1
  %t239 = getelementptr { %"compiler/source:Span", ptr }, ptr %t238, i32 0, i32 1
  %t240 = load ptr, ptr %t239
  store ptr %t240, ptr %l8, !tbaa !29
  br label %bb53
bb52:
  br label %bb57
bb53:
  %t242 = load ptr, ptr %l8, !tbaa !29
  %t244 = getelementptr %"compiler/ast:If", ptr %t242, i32 0, i32 2
  %t245 = load ptr, ptr %t244, !tbaa !29
  %t247 = icmp eq ptr %t245, null
  %t249 = xor i1 %t247, true
  br i1 %t249, label %bb54, label %bb55
bb54:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d54, i32 0, i32 1) }, ptr %l96, !tbaa !27
  br label %bb56
bb55:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d55, i32 0, i32 1) }, ptr %l96, !tbaa !27
  br label %bb56
bb56:
  %t251 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d56, i32 0, i32 1) }, 1
  %t252 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d56, i32 0, i32 1) }, 0
  %t253 = load { i64, ptr }, ptr %l96, !tbaa !27
  %t254 = extractvalue { i64, ptr } %t253, 1
  %t255 = extractvalue { i64, ptr } %t253, 0
  %t256 = add i64 %t252, %t255
  %t257 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t256)
  call void @olang_textcopy(ptr %t257, ptr %t251, i64 %t252)
  %t258 = getelementptr i8, ptr %t257, i64 %t252
  call void @olang_textcopy(ptr %t258, ptr %t254, i64 %t255)
  %t259 = insertvalue { i64, ptr } undef, i64 %t256, 0
  %t260 = insertvalue { i64, ptr } %t259, ptr %t257, 1
  store { i64, ptr } %t260, ptr %l9, !tbaa !27
  br label %bb62
bb57:
  br i1 true, label %bb58, label %bb59
bb58:
  br label %bb60
bb59:
  br label %bb61
bb60:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d57, i32 0, i32 1) }, ptr %l98, !tbaa !27
  %t262 = load { i64, ptr }, ptr %l98, !tbaa !27
  store { i64, ptr } %t262, ptr %l9, !tbaa !27
  br label %bb62
bb61:
  call void @__olang_check_failed(ptr @olang_loc_3758ee0971af8e29_da4aa036e664f025)
  unreachable
bb62:
  %t264 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t265 = extractvalue { i64, ptr } %t264, 0
  store i64 %t265, ptr %l100, !tbaa !24
  %t266 = load i64, ptr %l100, !tbaa !24
  %t267 = mul i64 %t266, 1
  %t268 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t267)
  %t269 = insertvalue { i64, ptr } undef, i64 %t266, 0
  %t270 = insertvalue { i64, ptr } %t269, ptr %t268, 1
  store { i64, ptr } %t270, ptr %l101, !tbaa !27
  %t271 = getelementptr { i64, ptr }, ptr %l101, i32 0, i32 1
  %t272 = load ptr, ptr %t271, !tbaa !27
  %t273 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t274 = load ptr, ptr %t273, !tbaa !27
  %t275 = load i64, ptr %l100, !tbaa !24
  %t276 = mul i64 %t275, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t272, ptr %t274, i64 %t276, i1 false)
  %t277 = load { i64, ptr }, ptr %l101, !tbaa !27
  store { i64, ptr } %t277, ptr %l9, !tbaa !27
  %t278 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t278, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2fparse_2evaluePattern(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i1
  %l9 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  store i1 false, ptr %l3, !tbaa !21
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 9}
  %t8 = icmp eq i64 %t6, 4
  store i1 %t8, ptr %l3, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l3, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", ptr }, ptr %t12, i32 0, i32 1
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = call i1 @compiler_2fparse_2eisLiteral(ptr %v0, ptr %t16)
  store i1 %t18, ptr %l9
  br label %bb6
bb6:
  %t19 = load i1, ptr %l9, !tbaa !21
  %t20 = xor i1 %t19, true
  store i1 %t20, ptr %rv
  br label %ret
bb7:
  br i1 true, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb11
bb10:
  store i1 false, ptr %rv
  br label %ret
bb11:
  call void @__olang_check_failed(ptr @olang_loc_c78d1b8d8b2c466f_3d420e0461112043)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fparse_2eweakened(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca i1
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca ptr
  %l6 = alloca i1
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca i1
  %l19 = alloca ptr
  %l24 = alloca ptr
  %l25 = alloca i1
  %l38 = alloca ptr
  %l42 = alloca ptr
  %rv = alloca ptr
  %t32 = alloca { i64, [5 x i64] }, align 8
  %t92 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t2 = load ptr, ptr %l8, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l8, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 3
  store i1 %t8, ptr %l9, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l9, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", ptr, i1, i1 }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l1
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", ptr, i1, i1 }, ptr %t18, i32 0, i32 1
  %t20 = load ptr, ptr %t19
  store ptr %t20, ptr %l2, !tbaa !29
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr { i64, [5 x i64] }, ptr %t22, i32 0, i32 1
  %t25 = getelementptr { %"compiler/source:Span", ptr, i1, i1 }, ptr %t24, i32 0, i32 2
  %t26 = load i1, ptr %t25
  store i1 %t26, ptr %l3, !tbaa !21
  br label %bb5
bb4:
  br label %bb9
bb5:
  %t28 = load i1, ptr %l3, !tbaa !21
  br i1 %t28, label %bb6, label %bb7
bb6:
  %t30 = load %"compiler/source:Span", ptr %l1
  %t31 = load ptr, ptr %l2, !tbaa !29
  store { i64, [5 x i64] } zeroinitializer, ptr %t32
  %t33 = getelementptr { i64, [5 x i64] }, ptr %t32, i32 0, i32 0
  store i64 3, ptr %t33
  %t35 = insertvalue { %"compiler/source:Span", ptr, i1, i1 } undef, %"compiler/source:Span" %t30, 0
  %t37 = insertvalue { %"compiler/source:Span", ptr, i1, i1 } %t35, ptr %t31, 1
  %t38 = insertvalue { %"compiler/source:Span", ptr, i1, i1 } %t37, i1 true, 2
  %t39 = insertvalue { %"compiler/source:Span", ptr, i1, i1 } %t38, i1 true, 3
  %t40 = getelementptr { i64, [5 x i64] }, ptr %t32, i32 0, i32 1
  store { %"compiler/source:Span", ptr, i1, i1 } %t39, ptr %t40
  %t41 = load { i64, [5 x i64] }, ptr %t32
  %t43 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 48, i64 8)
  store { i64, [5 x i64] } %t41, ptr %t43
  store ptr %t43, ptr %l19, !tbaa !29
  br label %bb8
bb7:
  store ptr null, ptr %l19, !tbaa !29
  br label %bb8
bb8:
  %t45 = load ptr, ptr %l19, !tbaa !29
  store ptr %t45, ptr %rv
  br label %ret
bb9:
  %t46 = load ptr, ptr %l0, !tbaa !29
  store ptr %t46, ptr %l24, !tbaa !29
  store i1 false, ptr %l25, !tbaa !21
  %t47 = load ptr, ptr %l24, !tbaa !29
  %t48 = icmp ne ptr %t47, null
  br i1 %t48, label %bb10, label %bb11
bb10:
  %t50 = load ptr, ptr %l24, !tbaa !29
  %t51 = load i64, ptr %t50, !range !{i64 0, i64 8}
  %t53 = icmp eq i64 %t51, 4
  store i1 %t53, ptr %l25, !tbaa !21
  br label %bb11
bb11:
  %t54 = load i1, ptr %l25, !tbaa !21
  br i1 %t54, label %bb12, label %bb13
bb12:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr { i64, [5 x i64] }, ptr %t55, i32 0, i32 1
  %t58 = getelementptr { %"compiler/source:Span", ptr, i1 }, ptr %t57, i32 0, i32 0
  %t59 = load %"compiler/source:Span", ptr %t58
  store %"compiler/source:Span" %t59, ptr %l4
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = getelementptr { i64, [5 x i64] }, ptr %t61, i32 0, i32 1
  %t64 = getelementptr { %"compiler/source:Span", ptr, i1 }, ptr %t63, i32 0, i32 1
  %t65 = load ptr, ptr %t64
  store ptr %t65, ptr %l5, !tbaa !29
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr { i64, [5 x i64] }, ptr %t67, i32 0, i32 1
  %t70 = getelementptr { %"compiler/source:Span", ptr, i1 }, ptr %t69, i32 0, i32 2
  %t71 = load i1, ptr %t70
  store i1 %t71, ptr %l6, !tbaa !21
  br label %bb14
bb13:
  br label %bb22
bb14:
  %t73 = load ptr, ptr %l5, !tbaa !29
  %t75 = icmp eq ptr %t73, null
  br i1 %t75, label %bb15, label %bb16
bb15:
  store ptr null, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  %t78 = load ptr, ptr %l5, !tbaa !29
  %t80 = call ptr @compiler_2fparse_2eweakened(ptr %v0, ptr %v1, ptr %t78)
  store ptr %t80, ptr %l38
  br label %bb18
bb18:
  %t81 = load ptr, ptr %l38, !tbaa !29
  store ptr %t81, ptr %l7, !tbaa !29
  %t82 = load ptr, ptr %l7, !tbaa !29
  %t84 = icmp eq ptr %t82, null
  %t86 = xor i1 %t84, true
  br i1 %t86, label %bb19, label %bb20
bb19:
  %t88 = load %"compiler/source:Span", ptr %l4
  %t89 = load ptr, ptr %l7, !tbaa !29
  %t91 = load i1, ptr %l6, !tbaa !21
  store { i64, [5 x i64] } zeroinitializer, ptr %t92
  %t93 = getelementptr { i64, [5 x i64] }, ptr %t92, i32 0, i32 0
  store i64 4, ptr %t93
  %t95 = insertvalue { %"compiler/source:Span", ptr, i1 } undef, %"compiler/source:Span" %t88, 0
  %t97 = insertvalue { %"compiler/source:Span", ptr, i1 } %t95, ptr %t89, 1
  %t99 = insertvalue { %"compiler/source:Span", ptr, i1 } %t97, i1 %t91, 2
  %t100 = getelementptr { i64, [5 x i64] }, ptr %t92, i32 0, i32 1
  store { %"compiler/source:Span", ptr, i1 } %t99, ptr %t100
  %t101 = load { i64, [5 x i64] }, ptr %t92
  %t103 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 48, i64 8)
  store { i64, [5 x i64] } %t101, ptr %t103
  store ptr %t103, ptr %l42, !tbaa !29
  br label %bb21
bb20:
  store ptr null, ptr %l42, !tbaa !29
  br label %bb21
bb21:
  %t105 = load ptr, ptr %l42, !tbaa !29
  store ptr %t105, ptr %rv
  br label %ret
bb22:
  br i1 true, label %bb23, label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb26
bb25:
  store ptr null, ptr %rv
  br label %ret
bb26:
  call void @__olang_check_failed(ptr @olang_loc_e0fd5cf4c2bfd9fe_e3c6f8b51d6fcd32)
  unreachable
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fparse_3aOracle_2ector(ptr %out, ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l1 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l2 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l4 = alloca i64
  %l6 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l8 = alloca i64
  %l10 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l12 = alloca i64
  %l14 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l16 = alloca i64
  %l18 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l20 = alloca %"compiler/parse:Oracle"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call ptr @__olang_scope_hold(ptr %v0)
  %t2 = ptrtoint ptr %t1 to i64
  store i64 %t2, ptr %l4, !tbaa !24
  %t3 = load i1, ptr @olang_2esole_2ecompiler_2fparse_3aOracle_2e0
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call ptr @__olang_region_make(ptr %v0)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  %t7 = load i64, ptr %l4
  %t8 = inttoptr i64 %t7 to ptr
  %t9 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3e(ptr %t8)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t9, ptr %l6
  br label %bb3
bb3:
  %t10 = load i1, ptr @olang_2esole_2ecompiler_2fparse_3aOracle_2e0
  br i1 %t10, label %bb4, label %bb5
bb4:
  %t12 = load i64, ptr %l4
  %t13 = inttoptr i64 %t12 to ptr
  %t14 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l6, i32 0, i32 2
  %t15 = load { i64, ptr }, ptr %t14
  %t16 = extractvalue { i64, ptr } %t15, 1
  %t17 = call ptr @__olang_region_or(ptr %t16, ptr null)
  %t18 = call ptr @__olang_region_home(ptr %t17)
  %t19 = icmp ne ptr %t18, null
  %t20 = select i1 %t19, ptr %t18, ptr null
  %t21 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l6, i32 0, i32 1
  %t22 = load { i64, ptr }, ptr %t21
  %t23 = extractvalue { i64, ptr } %t22, 1
  %t24 = call ptr @__olang_region_or(ptr %t23, ptr null)
  %t25 = call ptr @__olang_region_home(ptr %t24)
  %t26 = icmp ne ptr %t25, null
  %t27 = select i1 %t26, ptr %t25, ptr %t20
  %t28 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l6, i32 0, i32 0
  %t29 = load { i64, ptr }, ptr %t28
  %t30 = extractvalue { i64, ptr } %t29, 1
  %t31 = call ptr @__olang_region_or(ptr %t30, ptr null)
  %t32 = call ptr @__olang_region_home(ptr %t31)
  %t33 = icmp ne ptr %t32, null
  %t34 = select i1 %t33, ptr %t32, ptr %t27
  call void @__olang_region_settle_in(ptr %t13, ptr %t34)
  br label %bb5
bb5:
  %t35 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l6
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t35, ptr %l0
  %t36 = call ptr @__olang_scope_hold(ptr %v0)
  %t37 = ptrtoint ptr %t36 to i64
  store i64 %t37, ptr %l8, !tbaa !24
  %t38 = load i1, ptr @olang_2esole_2ecompiler_2fparse_3aOracle_2e1
  br i1 %t38, label %bb6, label %bb7
bb6:
  %t40 = call ptr @__olang_region_make(ptr %v0)
  %t41 = ptrtoint ptr %t40 to i64
  store i64 %t41, ptr %l8, !tbaa !24
  br label %bb7
bb7:
  %t42 = load i64, ptr %l8
  %t43 = inttoptr i64 %t42 to ptr
  %t44 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20Bool_3e(ptr %t43)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t44, ptr %l10
  br label %bb8
bb8:
  %t45 = load i1, ptr @olang_2esole_2ecompiler_2fparse_3aOracle_2e1
  br i1 %t45, label %bb9, label %bb10
bb9:
  %t47 = load i64, ptr %l8
  %t48 = inttoptr i64 %t47 to ptr
  %t49 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l10, i32 0, i32 2
  %t50 = load { i64, ptr }, ptr %t49
  %t51 = extractvalue { i64, ptr } %t50, 1
  %t52 = call ptr @__olang_region_or(ptr %t51, ptr null)
  %t53 = call ptr @__olang_region_home(ptr %t52)
  %t54 = icmp ne ptr %t53, null
  %t55 = select i1 %t54, ptr %t53, ptr null
  %t56 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l10, i32 0, i32 1
  %t57 = load { i64, ptr }, ptr %t56
  %t58 = extractvalue { i64, ptr } %t57, 1
  %t59 = call ptr @__olang_region_or(ptr %t58, ptr null)
  %t60 = call ptr @__olang_region_home(ptr %t59)
  %t61 = icmp ne ptr %t60, null
  %t62 = select i1 %t61, ptr %t60, ptr %t55
  %t63 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l10, i32 0, i32 0
  %t64 = load { i64, ptr }, ptr %t63
  %t65 = extractvalue { i64, ptr } %t64, 1
  %t66 = call ptr @__olang_region_or(ptr %t65, ptr null)
  %t67 = call ptr @__olang_region_home(ptr %t66)
  %t68 = icmp ne ptr %t67, null
  %t69 = select i1 %t68, ptr %t67, ptr %t62
  call void @__olang_region_settle_in(ptr %t48, ptr %t69)
  br label %bb10
bb10:
  %t70 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l10
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t70, ptr %l1
  %t71 = call ptr @__olang_scope_hold(ptr %v0)
  %t72 = ptrtoint ptr %t71 to i64
  store i64 %t72, ptr %l12, !tbaa !24
  %t73 = load i1, ptr @olang_2esole_2ecompiler_2fparse_3aOracle_2e2
  br i1 %t73, label %bb11, label %bb12
bb11:
  %t75 = call ptr @__olang_region_make(ptr %v0)
  %t76 = ptrtoint ptr %t75 to i64
  store i64 %t76, ptr %l12, !tbaa !24
  br label %bb12
bb12:
  %t77 = load i64, ptr %l12
  %t78 = inttoptr i64 %t77 to ptr
  %t79 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3e(ptr %t78)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t79, ptr %l14
  br label %bb13
bb13:
  %t80 = load i1, ptr @olang_2esole_2ecompiler_2fparse_3aOracle_2e2
  br i1 %t80, label %bb14, label %bb15
bb14:
  %t82 = load i64, ptr %l12
  %t83 = inttoptr i64 %t82 to ptr
  %t84 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l14, i32 0, i32 2
  %t85 = load { i64, ptr }, ptr %t84
  %t86 = extractvalue { i64, ptr } %t85, 1
  %t87 = call ptr @__olang_region_or(ptr %t86, ptr null)
  %t88 = call ptr @__olang_region_home(ptr %t87)
  %t89 = icmp ne ptr %t88, null
  %t90 = select i1 %t89, ptr %t88, ptr null
  %t91 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l14, i32 0, i32 1
  %t92 = load { i64, ptr }, ptr %t91
  %t93 = extractvalue { i64, ptr } %t92, 1
  %t94 = call ptr @__olang_region_or(ptr %t93, ptr null)
  %t95 = call ptr @__olang_region_home(ptr %t94)
  %t96 = icmp ne ptr %t95, null
  %t97 = select i1 %t96, ptr %t95, ptr %t90
  %t98 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l14, i32 0, i32 0
  %t99 = load { i64, ptr }, ptr %t98
  %t100 = extractvalue { i64, ptr } %t99, 1
  %t101 = call ptr @__olang_region_or(ptr %t100, ptr null)
  %t102 = call ptr @__olang_region_home(ptr %t101)
  %t103 = icmp ne ptr %t102, null
  %t104 = select i1 %t103, ptr %t102, ptr %t97
  call void @__olang_region_settle_in(ptr %t83, ptr %t104)
  br label %bb15
bb15:
  %t105 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l14
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t105, ptr %l2
  %t106 = call ptr @__olang_scope_hold(ptr %v0)
  %t107 = ptrtoint ptr %t106 to i64
  store i64 %t107, ptr %l16, !tbaa !24
  %t108 = load i1, ptr @olang_2esole_2ecompiler_2fparse_3aOracle_2e3
  br i1 %t108, label %bb16, label %bb17
bb16:
  %t110 = call ptr @__olang_region_make(ptr %v0)
  %t111 = ptrtoint ptr %t110 to i64
  store i64 %t111, ptr %l16, !tbaa !24
  br label %bb17
bb17:
  %t112 = load i64, ptr %l16
  %t113 = inttoptr i64 %t112 to ptr
  %t114 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20Bool_3e(ptr %t113)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t114, ptr %l18
  br label %bb18
bb18:
  %t115 = load i1, ptr @olang_2esole_2ecompiler_2fparse_3aOracle_2e3
  br i1 %t115, label %bb19, label %bb20
bb19:
  %t117 = load i64, ptr %l16
  %t118 = inttoptr i64 %t117 to ptr
  %t119 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l18, i32 0, i32 2
  %t120 = load { i64, ptr }, ptr %t119
  %t121 = extractvalue { i64, ptr } %t120, 1
  %t122 = call ptr @__olang_region_or(ptr %t121, ptr null)
  %t123 = call ptr @__olang_region_home(ptr %t122)
  %t124 = icmp ne ptr %t123, null
  %t125 = select i1 %t124, ptr %t123, ptr null
  %t126 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l18, i32 0, i32 1
  %t127 = load { i64, ptr }, ptr %t126
  %t128 = extractvalue { i64, ptr } %t127, 1
  %t129 = call ptr @__olang_region_or(ptr %t128, ptr null)
  %t130 = call ptr @__olang_region_home(ptr %t129)
  %t131 = icmp ne ptr %t130, null
  %t132 = select i1 %t131, ptr %t130, ptr %t125
  %t133 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l18, i32 0, i32 0
  %t134 = load { i64, ptr }, ptr %t133
  %t135 = extractvalue { i64, ptr } %t134, 1
  %t136 = call ptr @__olang_region_or(ptr %t135, ptr null)
  %t137 = call ptr @__olang_region_home(ptr %t136)
  %t138 = icmp ne ptr %t137, null
  %t139 = select i1 %t138, ptr %t137, ptr %t132
  call void @__olang_region_settle_in(ptr %t118, ptr %t139)
  br label %bb20
bb20:
  %t140 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l18
  %t141 = getelementptr %"compiler/parse:Oracle", ptr %l20, i32 0, i32 0
  %t142 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t142, ptr %t141
  %t143 = getelementptr %"compiler/parse:Oracle", ptr %l20, i32 0, i32 1
  %t144 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t144, ptr %t143
  %t145 = getelementptr %"compiler/parse:Oracle", ptr %l20, i32 0, i32 2
  %t146 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l2
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t146, ptr %t145
  %t147 = getelementptr %"compiler/parse:Oracle", ptr %l20, i32 0, i32 3
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t140, ptr %t147
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l20, i64 288, i1 false)
  br label %ret
ret:
  ret void
}

define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ; B19b: a benchmark build counts what this thread allocates - here and at the slow path's own bump, so each
  ; allocation is counted once wherever it is made (a region's and a forwarded scope's come back through here)
; @bench %bna = load i64, ptr @__olang_bench_allocs
; @bench %bna1 = add i64 %bna, 1
; @bench store i64 %bna1, ptr @__olang_bench_allocs
; @bench %bnb = load i64, ptr @__olang_bench_bytes
; @bench %bnb1 = add i64 %bnb, %size
; @bench store i64 %bnb1, ptr @__olang_bench_bytes
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
declare void @__olang_check_failed(ptr) cold noreturn
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %dh = load ptr, ptr %dheadptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  %hasd = icmp ne ptr %dh, null
  %owns = or i1 %hasf, %hasd
  br i1 %owns, label %owned, label %chunks
owned:
  call void @__olang_scope_close_owned(ptr %scope)
  br label %chunks
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
@__olang_empty_array = external constant [16 x i64]
define available_externally ptr @__olang_scope_hold(ptr %s) alwaysinline {
entry:
  %none = icmp eq ptr %s, null
  br i1 %none, label %plain, label %look
look:
  ; atomic: on a scope that is no stand-in this word is its parts list, which other threads push onto (__olang_scope_part)
  %mp = getelementptr %olang.scope, ptr %s, i32 0, i32 4
  %m = load atomic ptr, ptr %mp monotonic, align 8
  %fresh = icmp eq ptr %m, @__olang_standin_mark
  br i1 %fresh, label %make, label %kept
kept:
  %mi = ptrtoint ptr %m to i64
  %bit = and i64 %mi, 1
  %has = icmp ne i64 %bit, 0
  br i1 %has, label %keeper, label %plain
keeper:
  %ki = and i64 %mi, -2
  %k = inttoptr i64 %ki to ptr
  ret ptr %k
make:
  %f = call ptr @__olang_standin_keeper(ptr %s)
  ret ptr %f
plain:
  ret ptr %s
}
@olang_2esole_2eArray_3ccompiler_2fast_3aPath_26_3e_2e_2d1 = weak hidden constant i1 false
declare ptr @__olang_region_make(ptr) noinline
@olang_2esole_2ecompiler_2fast_3aCatch_2e1 = weak hidden constant i1 false
@.d0 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"export" }>, align 8
@.d1 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"a declaration" }>, align 8
@olang_2esole_2ecompiler_2fparse_3aNameList_2e0 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fparse_3aNameList_2e1 = weak hidden constant i1 false
@.d2 = private constant <{ i64, [40 x i8] }> <{ i64 0, [40 x i8] c"an error type's words or a set's members" }>, align 8
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
@olang_2esole_2ecompiler_2fast_3aSig_2e3 = weak hidden constant i1 false
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
@.d3 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
@.d4 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"SetAt" }>, align 8
@.d5 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"setAt" }>, align 8
@.d6 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"SetSlice" }>, align 8
@.d7 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"setSlice" }>, align 8
@olang_2esole_2ecompiler_2fast_3aVarDecl_2e0 = weak hidden constant i1 false
define available_externally noalias ptr @__olang_held_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
@olang_2esole_2ecompiler_2fast_3aVarDecl_2e1 = weak hidden constant i1 false
@.d8 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d9 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"a declaration" }>, align 8
@.d10 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"a declaration" }>, align 8
@.d11 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"a join" }>, align 8
@.d12 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"link" }>, align 8
@.d13 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d14 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"_" }>, align 8
@.d15 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"an expression" }>, align 8
@olang_2esole_2ecompiler_2fast_3aPromise_2e2 = weak hidden constant i1 false
@.d16 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"an extern's" }>, align 8
@.d17 = private constant <{ i64, [27 x i8] }> <{ i64 0, [27 x i8] c"a constructor's or a case's" }>, align 8
@.d18 = private constant <{ i64, [32 x i8] }> <{ i64 0, [32 x i8] c"C's variable arguments are '...'" }>, align 8
@.d19 = private constant <{ i64, [29 x i8] }> <{ i64 0, [29 x i8] c"take an array, 'xs Array<T>&'" }>, align 8
@.d20 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"errdefer" }>, align 8
@.d21 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"defer" }>, align 8
@.d22 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d23 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"an if" }>, align 8
@.d24 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"a loop" }>, align 8
@.d25 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"a match" }>, align 8
@.d26 = private constant <{ i64, [30 x i8] }> <{ i64 0, [30 x i8] c"a block (a block takes no ':')" }>, align 8
@.d27 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"a join" }>, align 8
@.d28 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"a defer" }>, align 8
@.d29 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"an errdefer" }>, align 8
@.d30 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@.d31 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"fn " }>, align 8
@.d32 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c": -" }>, align 8
@.d33 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"fn " }>, align 8
@.d34 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c":" }>, align 8
@.d35 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d36 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"type " }>, align 8
@.d37 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"mut " }>, align 8
@.d38 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d39 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d40 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"decl" }>, align 8
@.d41 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d42 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d43 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"return" }>, align 8
@.d44 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"become " }>, align 8
@.d45 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" :=" }>, align 8
@.d46 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d47 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" typed" }>, align 8
@.d48 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d49 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"var" }>, align 8
declare i64 @__olang_fmt_i64(ptr, i64)
@.d50 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c":=" }>, align 8
@.d51 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"~" }>, align 8
@.d52 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"=" }>, align 8
@.d53 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"multi" }>, align 8
@.d54 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c" else" }>, align 8
@.d55 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d56 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"if" }>, align 8
@.d57 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"stmt" }>, align 8
@olang_2esole_2ecompiler_2fparse_3aOracle_2e0 = weak hidden constant i1 false
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

declare ptr @__olang_region_or(ptr, ptr)
declare ptr @__olang_region_home(ptr)
declare void @__olang_region_settle_in(ptr, ptr)
@olang_2esole_2ecompiler_2fparse_3aOracle_2e1 = weak hidden constant i1 false
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20Bool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

@olang_2esole_2ecompiler_2fparse_3aOracle_2e2 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fparse_3aOracle_2e3 = weak hidden constant i1 false
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
declare void @__olang_scope_close_owned(ptr) noinline
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
@__olang_standin_mark = external global i64
declare ptr @__olang_standin_keeper(ptr) noinline
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
define available_externally noalias ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  %head = load ptr, ptr %scope, !tbaa !59
  %isslot = icmp eq ptr %head, @__olang_slot_chunk
  br i1 %isslot, label %slot, label %plain
slot:
  %s = call ptr @__olang_slot_alloc(ptr %scope, i64 %rawsize)
  ret ptr %s
plain:
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
@__olang_slot_chunk = external global %olang.chunk
declare noalias ptr @__olang_slot_alloc(ptr, i64) noinline
@olang_loc_6a8e8c321ae9efcf_109c18a9288531cb = external constant [0 x i8]
declare i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elook(ptr %v0, ptr %a0, i64 %a1)
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2epostfix(ptr %v0, ptr %v1, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI32_3e_2ePush_3cI32_3e(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ePush_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2eLen_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %a0)
declare { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eDescribe(ptr %v0, i32 %a0)
declare i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2efail(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eelem(ptr %v0, ptr %v1, ptr %a0)
declare i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ecomprehends(ptr %v0, ptr %a0)
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eentry(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2ePush_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i32, i1 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2esep(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2eTruncate_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %a0)
declare { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2epeek(ptr %v0, ptr %a0)
declare i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ehere(ptr %v0, ptr %a0)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eHold(ptr %v0, ptr %a0)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eEndHold(ptr %v0, ptr %a0)
declare void @compiler_2fparse_2ecompiler_2fparse_3aParser_2esyncFrom(ptr %v0, ptr %a0)
@olang_loc_3a014922d706f8ae_e8b2af70e71e377a = external constant [0 x i8]
declare %"compiler/ast:Branch" @compiler_2fast_3aBranch_2ector(ptr %v0, ptr %v1, %"compiler/source:Span" %a0, { i64, ptr } %a1, i64 %a2)
declare { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eblock(ptr %v0, ptr %v1, ptr %a0)
declare i32 @compiler_2fscan_2ecompiler_2fscan_3aTokens_2eMatch(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_e5b5865feda95523_92aca47b2e780ecf = external constant [0 x i8]
declare %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2etk(ptr %v0, ptr %a0)
declare i32 @compiler_2fsource_2ecompiler_2fsource_3aSource_2eLine(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eLineBodyOnLine(ptr %v0)
declare void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereport(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2, %"compiler/diagmsg:Msg" %a3)
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexpr(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_1409caed80efd5ca_aa5da404b7edad6 = external constant [0 x i8]
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eValueCaseBlock(ptr %v0)
@olang_loc_2c5c6195a47ae69f_51fb0001bc622feb = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aPattern_26_3e_2eLen_3ccompiler_2fast_3aPattern_26_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aPattern_26_3e_2ePush_3ccompiler_2fast_3aPattern_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fast_3aPattern_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aCatch_26_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aPath_26_3e_2ector(ptr %v0, i64 %a0)
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2epath(ptr %v0, ptr %v1, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aPath_26_3e_2ePush_3ccompiler_2fast_3aPath_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aPath_26_3e_2eLen_3ccompiler_2fast_3aPath_26_3e(ptr %v0, ptr %a0)
declare { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ename(ptr %v0, ptr %a0)
@olang_loc_e74fa2d3d14c2452_7ce0d57fd3650746 = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aPath_26_3e_2eToArray_3ccompiler_2fast_3aPath_26_3e(ptr %v0, ptr %v1, ptr %a0)
declare %"compiler/ast:Catch" @compiler_2fast_3aCatch_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, %"compiler/source:Span" %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, i1 %a4, i32 %a5, %"compiler/source:Span" %a6)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aCatch_26_3e_2ePush_3ccompiler_2fast_3aCatch_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eunary(ptr %v0, ptr %v1, ptr %a0)
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v0, ptr %a0)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aCatch_26_3e_2eToArray_3ccompiler_2fast_3aCatch_26_3e(ptr %v0, ptr %v1, ptr %a0)
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ebinary(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_562ee49de0d7f4dc_ca929e902ecee878 = external constant [0 x i8]
declare %"compiler/ast:Compr" @compiler_2fast_3aCompr_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, i32 %a2, i32 %a3, ptr %a4, ptr %a5, i1 %a6, i64 %a7)
@olang_loc_8028beeed4c0afcb_93e9486db4deb497 = external constant [0 x i8]
declare i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ebreakBefore(ptr %v0, ptr %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eVarListCount(ptr %v0, i64 %a0, i64 %a1)
declare i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eendStmt(ptr %v0, ptr %a0)
@olang_loc_acdf3c0d270865a2_ccca0ad6e9b656fe = external constant [0 x i8]
declare %"compiler/ast:TypeDecl" @compiler_2fast_3aTypeDecl_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, i32 %a0, { i64, ptr } %a1, i1 %a2, ptr %a3, i32 %a4, i1 %a5, ptr %a6, i32 %a7)
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexternBlock(ptr %v0, ptr %v1, ptr %a0, i32 %a1, %"compiler/source:Span" %a2)
declare { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ebody(ptr %v0, ptr %v1, ptr %a0)
declare { i64, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etext(ptr %v0, ptr %v1, ptr %a0, %"compiler/token:Token" %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/ast:Func" @compiler_2fast_3aFunc_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, %"compiler/source:Span" %a0, ptr %a1, i32 %a2, ptr %a3, { i64, ptr } %a4, { i64, ptr } %a5, i1 %a6, i1 %a7, ptr %a8, i32 %a9)
@olang_loc_2df52f758a425120_e9eb2ffac7d00514 = external constant [0 x i8]
@olang_loc_88d6a58aae0d0f1b_e8616324f90aa74f = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eLen_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eLen_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ePush_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"compiler/parse:NameList" @compiler_2fparse_3aNameList_2ector(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/ast:VarDecl" @compiler_2fast_3aVarDecl_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, ptr %a2, { i64, ptr } %a3, i1 %a4, i1 %a5, i1 %a6)
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeExpr(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_88b4df24f395cba0_7a8585039ef7582c = external constant [0 x i8]
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eDoLineFor(ptr %v0)
declare void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereportAt(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"compiler/diagmsg:Msg" %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aPattern_26_3e_2eTrunc_H311fd53ced078d1b110127cfa5549832(ptr %v0, ptr %a0, i64 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aCaseDecl_26_3e_2ector(ptr %v0, i64 %a0)
declare i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eerrorWords(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aCaseDecl_26_3e_2eLen__H880e577cb0df1a24f608b8ef0d16c17a(ptr %v0, ptr %a0)
@olang_loc_789713e4eee702da_477f9e47229ca02e = external constant [0 x i8]
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aCaseDecl_26_3e_2eAt_3ccompiler_2fast_3aCaseDecl_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aCaseDecl_26_3e_2eToAr_H44f8de0685d71649bf169c234c7a8f4c(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_1981dec301b76378_38f305e42bd9bf3c = external constant [0 x i8]
declare %"compiler/ast:Sig" @compiler_2fast_3aSig_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, i1 %a2, { i64, ptr } %a3, i1 %a4, i1 %a5, i1 %a6, { i64, ptr } %a7, i1 %a8)
@olang_loc_cd306f178609e3e5_44435844e9b3da89 = external constant [0 x i8]
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2esig(ptr %v0, ptr %v1, ptr %a0, i1 %a1, i1 %a2, i1 %a3, i1 %a4, i1 %a5)
@olang_loc_30a3a318854048f4_b503dd06e25e7b98 = external constant [0 x i8]
declare i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare ptr @compiler_2fparse_2ecompiler_2fparse_3aParser_2eone(ptr %v0, ptr %v1, ptr %a0, i32 %a1, %"compiler/source:Span" %a2)
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2evarDecl(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, ptr %a2)
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eparam(ptr %v0, ptr %v1, ptr %a0, i1 %a1)
declare i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eownerAhead(ptr %v0, ptr %a0)
declare { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2emethodName(ptr %v0, ptr %a0)
@olang_loc_4c43f34f877e1376_ed14b5a1f1e9a1ea = external constant [0 x i8]
declare { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeArgs(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_6416c01e12aaae0b_a3305b3dd64c2cbf = external constant [0 x i8]
declare { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereceiverVars(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2)
@olang_loc_79faa04a2077f0a8_b4c818f5d0d3035c = external constant [0 x i8]
@olang_loc_7ae9d5317a3d4e8f_1e272ac5502f090b = external constant [0 x i8]
@olang_loc_a8fa7275eec9c062_f04ec61276511d7e = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aDecl_26_3e_2ePush_3ccompiler_2fast_3aDecl_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_13a9b66eb9aa3f96_3dd1d0a593daf8ba = external constant [0 x i8]
@olang_loc_b5d05676e64fefab_5744e152e232520f = external constant [0 x i8]
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexprStmt(ptr %v0, ptr %v1, ptr %a0)
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexprAsType(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eisQualifiedType(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaxisItem(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, ptr %a2)
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2esubItem(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_d47f6bac3f0e9478_81eee3bd7c45867c = external constant [0 x i8]
@olang_loc_5d444e9b92bac566_79a754ee236bef22 = external constant [0 x i8]
declare %"compiler/ast:JoinS" @compiler_2fast_3aJoinS_2ector(ptr %v0, ptr %v1, ptr %v2, i1 %a0, { i64, ptr } %a1, { i64, ptr } %a2)
@olang_loc_3f19ed1436e26d3c_ab56bc721c08c978 = external constant [0 x i8]
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eLineBodyNotSimple(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_a66f16e9609fdd27_2fbef1e5bed159db = external constant [0 x i8]
@olang_loc_6e79f8a0f2444e80_4f0f22c816480f9c = external constant [0 x i8]
@olang_loc_d5699841f5fe95ad_d2c83eae1a824169 = external constant [0 x i8]
@olang_loc_9ddf95f323fdbbae_24356cb3d59d532a = external constant [0 x i8]
declare %"compiler/ast:MemberDecl" @compiler_2fast_3aMemberDecl_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, i32 %a1, { i64, ptr } %a2, ptr %a3)
@olang_loc_4993d3303aa01823_1a4b1af8a16484ff = external constant [0 x i8]
@olang_loc_951c2a70c5fd1ae3_7af085225755068f = external constant [0 x i8]
@olang_loc_2c371f21e588b068_13da37aea4ea5bc = external constant [0 x i8]
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3_H8da9376267bda3f76393292be0e507b2(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_caaeb8844a43a47_292034e417eae4cb = external constant [0 x i8]
declare i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eenter(ptr %v0, ptr %a0)
declare void @compiler_2fparse_2ecompiler_2fparse_3aParser_2eleave(ptr %v0, ptr %a0)
declare i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eafter(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePackedNotStruct(ptr %v0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aParam_26_3e_2eLen_3ccompiler_2fast_3aParam_26_3e(ptr %v0, ptr %a0)
declare i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eellipsis(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aParam_26_3e_2ePush_3ccompiler_2fast_3aParam_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fast_3aParam_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @compiler_2fparse_2eisPath(ptr %v0, ptr %a0)
@olang_loc_7ff84c49a98c5d65_799121c0214ef509 = external constant [0 x i8]
@olang_loc_2af5dad726595634_740c4fa339a5cf38 = external constant [0 x i8]
@olang_loc_1ff519fafba2f33_696c4c198bd75d77 = external constant [0 x i8]
@olang_loc_b6007e4d1245e4d6_5e9becbf0504ee4a = external constant [0 x i8]
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ematchBody(ptr %v0, ptr %v1, ptr %a0, i1 %a1)
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eliteralAfterType(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, ptr %a2)
declare i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeArgsCall(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2espacedTypeArgs(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2elookTok(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTypeArgsSpaced(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2enullMark(ptr %v0, ptr %a0)
@olang_loc_fd55a40e832939eb_76ee8367288fff1f = external constant [0 x i8]
declare ptr @compiler_2fparse_2ecompiler_2fparse_3aParser_2emarkers(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, ptr %a2)
@olang_loc_f58c14e72eb20088_8619c4b6e2d8c1bc = external constant [0 x i8]
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ebareLit(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_c608f7f9cf1bb136_7782a31fde86d192 = external constant [0 x i8]
@olang_loc_4bdaee1d5dba1351_2f255a58086b38a5 = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aPromise_26_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ector(ptr %v0, i64 %a0)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eToArra_H4d02a0b2e27e8f31ffc99daa43750593(ptr %v0, ptr %v1, ptr %a0)
declare %"compiler/ast:Promise" @compiler_2fast_3aPromise_2ector(ptr %v0, ptr %v1, %"compiler/source:Span" %a0, i32 %a1, { i64, ptr } %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aPromise_26_3e_2ePush_3ccompiler_2fast_3aPromise_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aPromise_26_3e_2eToArr_H644015b27d5daf4fb4fcf02905144e4c(ptr %v0, ptr %v1, ptr %a0)
declare i1 @compiler_2fparse_2eisAssignOp(i32 %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eVariadicNotLast(ptr %v0)
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v0, ptr %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eVariadicHere(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_b4d86fcc9a57c7f6_c634a892523c9252 = external constant [0 x i8]
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eVariadicDefault(ptr %v0)
declare i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ekeywordFieldHere(ptr %v0, ptr %a0)
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eifStmt(ptr %v0, ptr %v1, ptr %a0)
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eforStmt(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_405430454c9e5d04_720bbb7e3dc9fd0 = external constant [0 x i8]
declare { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexprList(ptr %v0, ptr %v1, ptr %a0)
declare { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eargs(ptr %v0, ptr %v1, ptr %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2eAt_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_52ee6a0603ddde11_c2fcf6abb1634cfd = external constant [0 x i8]
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eBareDefer(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etryStmt(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_98b5a7b541ba17c1_7be6170cba707005 = external constant [0 x i8]
@G_2ecompiler_2fparse_2eMaxNesting = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\20\4E\00\00\00\00\00\00" }>, align 8
declare void @compiler_2fparse_2ecompiler_2fparse_3aParser_2etooDeepAt(ptr %v0, ptr %a0, i64 %a1)
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etopBranch(ptr %v0, ptr %v1, ptr %a0)
declare %"compiler/ast:TopIf" @compiler_2fast_3aTopIf_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, ptr %a2, ptr %a3)
declare { i64, ptr } @compiler_2fmsgs_2eTok(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eDefaultNotTrailing(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_e980cdf5146ac576_c2415009b5e84a7a = external constant [0 x i8]
@olang_loc_1539ac39f97600b_6c3b4513fd4221cf = external constant [0 x i8]
declare %"compiler/ast:StructBody" @compiler_2fast_3aStructBody_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, { i64, ptr } %a0, ptr %a1, { i64, ptr } %a2, %"compiler/source:Span" %a3, { i64, ptr } %a4, { i64, ptr } %a5)
declare void @compiler_2fparse_2ecompiler_2fparse_3aParser_2eskipEnds(ptr %v0, ptr %a0)
@olang_loc_17377aefad64a2a8_5cc0f861968a066c = external constant [0 x i8]
declare %"compiler/ast:Param" @compiler_2fast_3aParam_2ector(ptr %v0, ptr %v1, ptr %v2, %"compiler/source:Span" %a0, i32 %a1, ptr %a2, ptr %a3)
declare %"compiler/ast:CaseDecl" @compiler_2fast_3aCaseDecl_2ector(ptr %v0, ptr %v1, ptr %v2, %"compiler/source:Span" %a0, i32 %a1, { i64, ptr } %a2, i1 %a3, ptr %a4)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aCaseDecl_26_3e_2ePush_H43bc1cace347592514b4248ffd44c907(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eentryEnd(ptr %v0, ptr %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aFunc_26_3e_2ector(ptr %v0, i64 %a0)
@olang_loc_2302adf5d350ae95_7d513dc9152d99f9 = external constant [0 x i8]
@olang_loc_46374d1b7bb67262_72dce1a2b91be04e = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aFunc_26_3e_2ePush_3ccompiler_2fast_3aFunc_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aFunc_26_3e_2eToArray_3ccompiler_2fast_3aFunc_26_3e(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_1c3aa98278e4117_19ec5e3b00828443 = external constant [0 x i8]
@olang_loc_6cb001083a887f74_65a539ed4a68e820 = external constant [0 x i8]
@olang_loc_d672258fb79a6f5a_5ab6544735a7871e = external constant [0 x i8]
@olang_loc_411e8cbc479e6c68_8a93085e0dfe7db4 = external constant [0 x i8]
@olang_loc_a3bb9cce88491c55_2084ae246c483bc1 = external constant [0 x i8]
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eUniqueImmut(ptr %v0)
@olang_loc_2c29cc2313aef596_a74c39ade1a5acca = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aTypeRef_26_3e_2ector(ptr %v0, i64 %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aTypeRef_26_3e_2ePush_3ccompiler_2fast_3aTypeRef_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aTypeRef_26_3e_2eToArr_Ha78c9aad18467c47f48c596ab5d9c770(ptr %v0, ptr %v1, ptr %a0)
declare i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eopenAngle(ptr %v0, ptr %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aTypeParam_26_3e_2ector(ptr %v0, i64 %a0)
@olang_loc_1d244c71d015ce10_e3593377956a04fc = external constant [0 x i8]
declare %"compiler/ast:TypeParam" @compiler_2fast_3aTypeParam_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, %"compiler/source:Span" %a0, i32 %a1, ptr %a2, { i64, ptr } %a3, i1 %a4, ptr %a5)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aTypeParam_26_3e_2ePus_H37c80a976dd4e939873b1680de0974c7(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eclosesAngle(ptr %v0, ptr %a0)
declare i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ecloseAngle(ptr %v0, ptr %a0)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aTypeParam_26_3e_2eToA_H6e630dc6e3e172d7593a8563d6f9ad2c(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_2154037c3afdd592_b5cbca897fb2c76e = external constant [0 x i8]
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eWeakNotNullable(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_af06113cf8aef81c_32854973a8f51e0 = external constant [0 x i8]
@olang_loc_a46c4d4e835a1515_243175b90cb4fb69 = external constant [0 x i8]
@olang_loc_ed9c9212b4212a6d_b0d1473d5650fc49 = external constant [0 x i8]
@olang_loc_df55213c12c66f02_faf3a3bc6284f73e = external constant [0 x i8]
@olang_loc_fcd7f3e04b81968d_d9ee06b55986a881 = external constant [0 x i8]
@olang_loc_a4d23bc21c2583e1_78290c8064d2bdc5 = external constant [0 x i8]
@olang_loc_944ad1edd3a79eba_8cd1e5aa7bbd35a6 = external constant [0 x i8]
@olang_loc_674728a9afb53deb_f473243cfc12c1d7 = external constant [0 x i8]
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_3aa36594c4c33747_9481be0c1eb7a3c3 = external constant [0 x i8]
@olang_loc_4f160b4312e342e6_588517f053075c42 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fparse_2eshapeExpr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, { i64, ptr } %a2)
@olang_loc_3758ee0971af8e29_da4aa036e664f025 = external constant [0 x i8]
@olang_loc_c78d1b8d8b2c466f_3d420e0461112043 = external constant [0 x i8]
@olang_loc_e0fd5cf4c2bfd9fe_e3c6f8b51d6fcd32 = external constant [0 x i8]
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20Bool_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
