; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr, i64, ptr }
%olang.home = type { ptr, ptr }
%olang.slotscope = type { %olang.scope, i64, [8 x ptr] }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/effects:Facts" = type { i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i64, [6 x i64], i64, i64 }
%"compiler/effects:Verdict" = type { { i64, ptr }, { i64, ptr }, i1, i32, { i64, ptr }, i64, %"compiler/source:Span", { i64, ptr } }
%"compiler/source:Span" = type { i32, i32 }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"compiler/effects:part" = type { i64, i64, i32, ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64 }
%"compiler/effects:Effects" = type { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"compiler/effects:Facts", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i64, { i64, ptr }, i1, %"compiler/source:Span", { i64, ptr }, i1, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1, %"compiler/typed:RefsKept", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i64, i64 }
%"compiler/typed:RefsKept" = type { %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/generic:Program" = type { ptr, ptr, %"compiler/types:Table", %"compiler/facts:Table", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"compiler/generic:Origin", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/types:Table" = type { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/facts:Table" = type { %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i64 }
%"compiler/generic:Origin" = type { i64, %"compiler/source:Span", i64, i32 }
%"compiler/typed:Arm" = type { %"compiler/source:Span", { i64, ptr }, ptr, ptr, ptr }
%"compiler/typed:Alt" = type { ptr, { i64, ptr } }
%"compiler/typed:Bind" = type { i32, ptr }
%"compiler/typed:Body" = type { i32, { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i32, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/effects:given" = type { i64, i64, i64, i64, i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64 }
%"compiler/typed:Make" = type { i32, i64, { i64, ptr }, ptr, i32, i32, i1 }
%"compiler/typed:Promote" = type { ptr, i32 }
%"compiler/typed:Text" = type { { i64, ptr }, i32 }
%"compiler/typed:Collect" = type { ptr, ptr, i32, i32, i1, ptr }
%"compiler/typed:Call" = type { ptr, { i64, ptr }, i32, i1, i1 }
%"compiler/typed:Slice" = type { ptr, ptr, ptr, i32 }
%"compiler/typed:Cond" = type { ptr, ptr, ptr }
%"compiler/typed:Seq" = type { { i64, ptr }, ptr, i1 }
%"compiler/typed:Match" = type { { i64, ptr }, { i64, ptr }, ptr, i1 }
%"compiler/typed:Try" = type { ptr, { i64, ptr }, i1, i1, i1 }
%"compiler/effects:fpath" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i32 }
%"compiler/typed:Local" = type { i32, %"compiler/source:Span", i32, i32, i32, { i64, [1 x i64] }, i1, i1 }
%"compiler/effects:fslot" = type { i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i32 }
%"compiler/effects:pend" = type { i64, i64, ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/typed:Capture" = type { i32, ptr }
%"compiler/load:Loader" = type { { i64, ptr }, ptr, ptr, ptr, ptr, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/load:Module" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i64, i1, ptr, ptr, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr, i1, i64, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr, ptr, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/typed:LocalUses" = type { ptr, ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i64, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i32, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i64, i64, i64, i32, i1, i1 }
%"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9" = type { ptr, i64 }
%"compiler/effects:link" = type { i64, i64, i64 }
%"compiler/typed:If" = type { ptr, ptr, ptr }
%"compiler/typed:Join" = type { ptr, i1, { i64, ptr } }
%"compiler/typed:Clause" = type { %"compiler/source:Span", { i64, ptr }, i1, ptr, { i64, ptr }, i64, i32 }
%"compiler/typed:Spawn" = type { { i64, ptr }, ptr, { i64, ptr }, i32 }
%"compiler/effects:pair" = type { i64, i64 }
define dso_local { i64, ptr } @compiler_2feffects_2eBreaks(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l13 = alloca i1
  %l14 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca { i64, ptr }
  %l26 = alloca i1
  %l27 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  %l30 = alloca { i64, ptr }
  %l32 = alloca i64
  %l33 = alloca { i64, ptr }
  %l39 = alloca i1
  %l40 = alloca { i64, ptr }
  %l41 = alloca { i64, ptr }
  %l43 = alloca { i64, ptr }
  %l45 = alloca i64
  %l46 = alloca { i64, ptr }
  %l52 = alloca i1
  %l53 = alloca i1
  %l60 = alloca { i64, ptr }
  %l61 = alloca { i64, ptr }
  %l63 = alloca { i64, ptr }
  %l65 = alloca i64
  %l66 = alloca { i64, ptr }
  %l71 = alloca { i64, ptr }
  %l76 = alloca { i64, ptr }
  %l79 = alloca i1
  %l82 = alloca i1
  %l85 = alloca { i64, ptr }
  %l86 = alloca { i64, ptr }
  %l87 = alloca i64
  %l88 = alloca { i64, ptr }
  %l91 = alloca { i64, ptr }
  %l92 = alloca { i64, ptr }
  %l94 = alloca { i64, ptr }
  %l96 = alloca i64
  %l97 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/effects:Facts", ptr %t1, i32 0, i32 16
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  store { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d0, i32 0, i32 1) }, ptr %l4, !tbaa !27
  %t6 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t6, ptr %l5, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t7, 0
  store i64 %t8, ptr %l6, !tbaa !24
  %t9 = load i64, ptr %l6, !tbaa !24
  %t10 = mul i64 %t9, 1
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  %t12 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t13 = insertvalue { i64, ptr } %t12, ptr %t11, 1
  store { i64, ptr } %t13, ptr %l7, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = load i64, ptr %l6, !tbaa !24
  %t19 = mul i64 %t18, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t15, ptr %t17, i64 %t19, i1 false)
  %t20 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t20, ptr %l5, !tbaa !27
  %t21 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t21, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t22 = load i64, ptr %l1, !tbaa !24
  %t23 = load i64, ptr @G_2ecompiler_2ftypes_2ePromNoalloc, !tbaa !24
  %t26 = icmp eq i64 %t22, %t23
  br i1 %t26, label %bb4, label %bb5
bb4:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t31 = call i1 @compiler_2feffects_2ecompiler_2feffects_3aFacts_2eHolds(ptr %v0, ptr %t28, i32 1)
  store i1 %t31, ptr %l13
  br label %bb6
bb5:
  br label %bb10
bb6:
  %t32 = load i1, ptr %l13, !tbaa !21
  br i1 %t32, label %bb7, label %bb8
bb7:
  store { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d1, i32 0, i32 1) }, ptr %l15, !tbaa !27
  %t33 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t33, ptr %l14, !tbaa !27
  br label %bb9
bb8:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d2, i32 0, i32 1) }, ptr %l17, !tbaa !27
  %t35 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t35, ptr %l14, !tbaa !27
  br label %bb9
bb9:
  %t37 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t38 = extractvalue { i64, ptr } %t37, 0
  store i64 %t38, ptr %l19, !tbaa !24
  %t39 = load i64, ptr %l19, !tbaa !24
  %t40 = mul i64 %t39, 1
  %t41 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t40)
  %t42 = insertvalue { i64, ptr } undef, i64 %t39, 0
  %t43 = insertvalue { i64, ptr } %t42, ptr %t41, 1
  store { i64, ptr } %t43, ptr %l20, !tbaa !27
  %t44 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !27
  %t46 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !27
  %t48 = load i64, ptr %l19, !tbaa !24
  %t49 = mul i64 %t48, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t45, ptr %t47, i64 %t49, i1 false)
  %t50 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t50, ptr %l14, !tbaa !27
  %t51 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t51, ptr %rv
  br label %ret
bb10:
  %t52 = load i64, ptr %l1, !tbaa !24
  %t53 = load i64, ptr @G_2ecompiler_2ftypes_2ePromNoblock, !tbaa !24
  %t56 = icmp eq i64 %t52, %t53
  br i1 %t56, label %bb11, label %bb12
bb11:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t61 = call i1 @compiler_2feffects_2ecompiler_2feffects_3aFacts_2eHolds(ptr %v0, ptr %t58, i32 2)
  store i1 %t61, ptr %l26
  br label %bb13
bb12:
  br label %bb17
bb13:
  %t62 = load i1, ptr %l26, !tbaa !21
  br i1 %t62, label %bb14, label %bb15
bb14:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d3, i32 0, i32 1) }, ptr %l28, !tbaa !27
  %t63 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t63, ptr %l27, !tbaa !27
  br label %bb16
bb15:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d4, i32 0, i32 1) }, ptr %l30, !tbaa !27
  %t65 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t65, ptr %l27, !tbaa !27
  br label %bb16
bb16:
  %t67 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t68 = extractvalue { i64, ptr } %t67, 0
  store i64 %t68, ptr %l32, !tbaa !24
  %t69 = load i64, ptr %l32, !tbaa !24
  %t70 = mul i64 %t69, 1
  %t71 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t70)
  %t72 = insertvalue { i64, ptr } undef, i64 %t69, 0
  %t73 = insertvalue { i64, ptr } %t72, ptr %t71, 1
  store { i64, ptr } %t73, ptr %l33, !tbaa !27
  %t74 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t75 = load ptr, ptr %t74, !tbaa !27
  %t76 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t77 = load ptr, ptr %t76, !tbaa !27
  %t78 = load i64, ptr %l32, !tbaa !24
  %t79 = mul i64 %t78, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t75, ptr %t77, i64 %t79, i1 false)
  %t80 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t80, ptr %l27, !tbaa !27
  %t81 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t81, ptr %rv
  br label %ret
bb17:
  %t82 = load i64, ptr %l1, !tbaa !24
  %t83 = load i64, ptr @G_2ecompiler_2ftypes_2ePromNospawn, !tbaa !24
  %t86 = icmp eq i64 %t82, %t83
  br i1 %t86, label %bb18, label %bb19
bb18:
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t91 = call i1 @compiler_2feffects_2ecompiler_2feffects_3aFacts_2eHolds(ptr %v0, ptr %t88, i32 5)
  store i1 %t91, ptr %l39
  br label %bb20
bb19:
  br label %bb24
bb20:
  %t92 = load i1, ptr %l39, !tbaa !21
  br i1 %t92, label %bb21, label %bb22
bb21:
  store { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d5, i32 0, i32 1) }, ptr %l41, !tbaa !27
  %t93 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t93, ptr %l40, !tbaa !27
  br label %bb23
bb22:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d6, i32 0, i32 1) }, ptr %l43, !tbaa !27
  %t95 = load { i64, ptr }, ptr %l43, !tbaa !27
  store { i64, ptr } %t95, ptr %l40, !tbaa !27
  br label %bb23
bb23:
  %t97 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t98 = extractvalue { i64, ptr } %t97, 0
  store i64 %t98, ptr %l45, !tbaa !24
  %t99 = load i64, ptr %l45, !tbaa !24
  %t100 = mul i64 %t99, 1
  %t101 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t100)
  %t102 = insertvalue { i64, ptr } undef, i64 %t99, 0
  %t103 = insertvalue { i64, ptr } %t102, ptr %t101, 1
  store { i64, ptr } %t103, ptr %l46, !tbaa !27
  %t104 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t105 = load ptr, ptr %t104, !tbaa !27
  %t106 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t107 = load ptr, ptr %t106, !tbaa !27
  %t108 = load i64, ptr %l45, !tbaa !24
  %t109 = mul i64 %t108, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t105, ptr %t107, i64 %t109, i1 false)
  %t110 = load { i64, ptr }, ptr %l46, !tbaa !27
  store { i64, ptr } %t110, ptr %l40, !tbaa !27
  %t111 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t111, ptr %rv
  br label %ret
bb24:
  %t112 = load i64, ptr %l1, !tbaa !24
  %t113 = load i64, ptr @G_2ecompiler_2ftypes_2ePromNoextern, !tbaa !24
  %t116 = icmp eq i64 %t112, %t113
  br i1 %t116, label %bb25, label %bb26
bb25:
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t121 = call i1 @compiler_2feffects_2ecompiler_2feffects_3aFacts_2eHolds(ptr %v0, ptr %t118, i32 4)
  store i1 %t121, ptr %l52
  br label %bb27
bb26:
  br label %bb34
bb27:
  %t122 = load i1, ptr %l52, !tbaa !21
  br i1 %t122, label %bb28, label %bb29
bb28:
  store i1 true, ptr %l53, !tbaa !21
  br label %bb30
bb29:
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t125 = getelementptr %"compiler/effects:Facts", ptr %t123, i32 0, i32 21
  %t126 = load i64, ptr %t125, !tbaa !24
  %t127 = load i64, ptr @G_2ecompiler_2feffects_2eCapThreads, !tbaa !24
  %t129 = xor i64 %t127, -1
  %t132 = and i64 %t126, %t129
  %t134 = icmp ne i64 %t132, 0
  store i1 %t134, ptr %l53, !tbaa !21
  br label %bb30
bb30:
  %t136 = load i1, ptr %l53, !tbaa !21
  br i1 %t136, label %bb31, label %bb32
bb31:
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d7, i32 0, i32 1) }, ptr %l61, !tbaa !27
  %t137 = load { i64, ptr }, ptr %l61, !tbaa !27
  store { i64, ptr } %t137, ptr %l60, !tbaa !27
  br label %bb33
bb32:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d8, i32 0, i32 1) }, ptr %l63, !tbaa !27
  %t139 = load { i64, ptr }, ptr %l63, !tbaa !27
  store { i64, ptr } %t139, ptr %l60, !tbaa !27
  br label %bb33
bb33:
  %t141 = load { i64, ptr }, ptr %l60, !tbaa !27
  %t142 = extractvalue { i64, ptr } %t141, 0
  store i64 %t142, ptr %l65, !tbaa !24
  %t143 = load i64, ptr %l65, !tbaa !24
  %t144 = mul i64 %t143, 1
  %t145 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t144)
  %t146 = insertvalue { i64, ptr } undef, i64 %t143, 0
  %t147 = insertvalue { i64, ptr } %t146, ptr %t145, 1
  store { i64, ptr } %t147, ptr %l66, !tbaa !27
  %t148 = getelementptr { i64, ptr }, ptr %l66, i32 0, i32 1
  %t149 = load ptr, ptr %t148, !tbaa !27
  %t150 = getelementptr { i64, ptr }, ptr %l60, i32 0, i32 1
  %t151 = load ptr, ptr %t150, !tbaa !27
  %t152 = load i64, ptr %l65, !tbaa !24
  %t153 = mul i64 %t152, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t149, ptr %t151, i64 %t153, i1 false)
  %t154 = load { i64, ptr }, ptr %l66, !tbaa !27
  store { i64, ptr } %t154, ptr %l60, !tbaa !27
  %t155 = load { i64, ptr }, ptr %l60, !tbaa !27
  store { i64, ptr } %t155, ptr %rv
  br label %ret
bb34:
  %t156 = load i64, ptr %l1, !tbaa !24
  %t157 = load i64, ptr @G_2ecompiler_2ftypes_2ePromReturns, !tbaa !24
  %t160 = icmp eq i64 %t156, %t157
  br i1 %t160, label %bb35, label %bb36
bb35:
  %t162 = load ptr, ptr %l0, !tbaa !29
  %t164 = call { i64, ptr } @compiler_2feffects_2enotReturning(ptr %v0, ptr %v1, ptr %t162)
  store { i64, ptr } %t164, ptr %l71
  br label %bb37
bb36:
  br label %bb38
bb37:
  %t165 = load { i64, ptr }, ptr %l71, !tbaa !27
  store { i64, ptr } %t165, ptr %rv
  br label %ret
bb38:
  %t166 = load i64, ptr %l1, !tbaa !24
  %t167 = load i64, ptr @G_2ecompiler_2ftypes_2ePromPure, !tbaa !24
  %t170 = icmp eq i64 %t166, %t167
  br i1 %t170, label %bb39, label %bb40
bb39:
  %t172 = load ptr, ptr %l0, !tbaa !29
  %t174 = call { i64, ptr } @compiler_2feffects_2eimpure(ptr %v0, ptr %v1, ptr %t172)
  store { i64, ptr } %t174, ptr %l76
  br label %bb41
bb40:
  br label %bb42
bb41:
  %t175 = load { i64, ptr }, ptr %l76, !tbaa !27
  store { i64, ptr } %t175, ptr %rv
  br label %ret
bb42:
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t178 = getelementptr %"compiler/effects:Facts", ptr %t176, i32 0, i32 17
  %t179 = load i1, ptr %t178, !tbaa !21
  br i1 %t179, label %bb43, label %bb44
bb43:
  store i1 true, ptr %l79, !tbaa !21
  br label %bb45
bb44:
  %t181 = load ptr, ptr %l0, !tbaa !29
  %t183 = getelementptr %"compiler/effects:Facts", ptr %t181, i32 0, i32 12
  %t184 = load i1, ptr %t183, !tbaa !21
  store i1 %t184, ptr %l79, !tbaa !21
  br label %bb45
bb45:
  %t186 = load i1, ptr %l79, !tbaa !21
  br i1 %t186, label %bb46, label %bb47
bb46:
  store i1 true, ptr %l82, !tbaa !21
  br label %bb48
bb47:
  %t187 = load ptr, ptr %l0, !tbaa !29
  %t189 = getelementptr %"compiler/effects:Facts", ptr %t187, i32 0, i32 13
  %t190 = load i1, ptr %t189, !tbaa !21
  store i1 %t190, ptr %l82, !tbaa !21
  br label %bb48
bb48:
  %t192 = load i1, ptr %l82, !tbaa !21
  br i1 %t192, label %bb49, label %bb50
bb49:
  store { i64, ptr } { i64 75, ptr getelementptr inbounds (<{ i64, [75 x i8] }>, ptr @.d9, i32 0, i32 1) }, ptr %l85, !tbaa !27
  %t193 = load { i64, ptr }, ptr %l85, !tbaa !27
  store { i64, ptr } %t193, ptr %l86, !tbaa !27
  %t194 = load { i64, ptr }, ptr %l86, !tbaa !27
  %t195 = extractvalue { i64, ptr } %t194, 0
  store i64 %t195, ptr %l87, !tbaa !24
  %t196 = load i64, ptr %l87, !tbaa !24
  %t197 = mul i64 %t196, 1
  %t198 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t197)
  %t199 = insertvalue { i64, ptr } undef, i64 %t196, 0
  %t200 = insertvalue { i64, ptr } %t199, ptr %t198, 1
  store { i64, ptr } %t200, ptr %l88, !tbaa !27
  %t201 = getelementptr { i64, ptr }, ptr %l88, i32 0, i32 1
  %t202 = load ptr, ptr %t201, !tbaa !27
  %t203 = getelementptr { i64, ptr }, ptr %l86, i32 0, i32 1
  %t204 = load ptr, ptr %t203, !tbaa !27
  %t205 = load i64, ptr %l87, !tbaa !24
  %t206 = mul i64 %t205, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t202, ptr %t204, i64 %t206, i1 false)
  %t207 = load { i64, ptr }, ptr %l88, !tbaa !27
  store { i64, ptr } %t207, ptr %l86, !tbaa !27
  %t208 = load { i64, ptr }, ptr %l86, !tbaa !27
  store { i64, ptr } %t208, ptr %rv
  br label %ret
bb50:
  br label %bb51
bb51:
  %t209 = load ptr, ptr %l0, !tbaa !29
  %t211 = getelementptr %"compiler/effects:Facts", ptr %t209, i32 0, i32 10
  %t212 = load i1, ptr %t211, !tbaa !21
  br i1 %t212, label %bb52, label %bb53
bb52:
  store { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d10, i32 0, i32 1) }, ptr %l92, !tbaa !27
  %t214 = load { i64, ptr }, ptr %l92, !tbaa !27
  store { i64, ptr } %t214, ptr %l91, !tbaa !27
  br label %bb54
bb53:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d11, i32 0, i32 1) }, ptr %l94, !tbaa !27
  %t216 = load { i64, ptr }, ptr %l94, !tbaa !27
  store { i64, ptr } %t216, ptr %l91, !tbaa !27
  br label %bb54
bb54:
  %t218 = load { i64, ptr }, ptr %l91, !tbaa !27
  %t219 = extractvalue { i64, ptr } %t218, 0
  store i64 %t219, ptr %l96, !tbaa !24
  %t220 = load i64, ptr %l96, !tbaa !24
  %t221 = mul i64 %t220, 1
  %t222 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t221)
  %t223 = insertvalue { i64, ptr } undef, i64 %t220, 0
  %t224 = insertvalue { i64, ptr } %t223, ptr %t222, 1
  store { i64, ptr } %t224, ptr %l97, !tbaa !27
  %t225 = getelementptr { i64, ptr }, ptr %l97, i32 0, i32 1
  %t226 = load ptr, ptr %t225, !tbaa !27
  %t227 = getelementptr { i64, ptr }, ptr %l91, i32 0, i32 1
  %t228 = load ptr, ptr %t227, !tbaa !27
  %t229 = load i64, ptr %l96, !tbaa !24
  %t230 = mul i64 %t229, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t226, ptr %t228, i64 %t230, i1 false)
  %t231 = load { i64, ptr }, ptr %l97, !tbaa !27
  store { i64, ptr } %t231, ptr %l91, !tbaa !27
  %t232 = load { i64, ptr }, ptr %l91, !tbaa !27
  store { i64, ptr } %t232, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2feffects_2eMergeCold(ptr %v0, ptr noalias dereferenceable(96) align 8 %a0, %"compiler/effects:Facts" %a1) #0 {
entry:
  %l1 = alloca %"compiler/effects:Facts"
  %l4 = alloca i1
  %s0 = alloca %olang.scope
  store %"compiler/effects:Facts" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = getelementptr %"compiler/effects:Facts", ptr %l1, i32 0, i32 1
  %t2 = load i1, ptr %t1, !tbaa !21
  br i1 %t2, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l4, !tbaa !21
  br label %bb3
bb2:
  %t5 = getelementptr %"compiler/effects:Facts", ptr %l1, i32 0, i32 0
  %t6 = load i1, ptr %t5, !tbaa !21
  store i1 %t6, ptr %l4, !tbaa !21
  br label %bb3
bb3:
  %t8 = load i1, ptr %l4, !tbaa !21
  %t9 = getelementptr %"compiler/effects:Facts", ptr %l1, i32 0, i32 1
  store i1 %t8, ptr %t9, !tbaa !21
  %t10 = getelementptr %"compiler/effects:Facts", ptr %l1, i32 0, i32 0
  store i1 false, ptr %t10, !tbaa !21
  call void @compiler_2feffects_2eMerge(ptr %v0, ptr %s0, ptr %a0, ptr %l1)
  br label %bb4
bb4:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/effects:Verdict" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eJudge(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, ptr %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l4 = alloca %"compiler/effects:Verdict"
  %l5 = alloca i64
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca %"compiler/effects:part"
  %l10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca i64
  %l14 = alloca %"compiler/effects:Facts"
  %l15 = alloca %"compiler/effects:Verdict"
  %l20 = alloca i64
  %l25 = alloca i1
  %l28 = alloca i1
  %l29 = alloca i64
  %l32 = alloca i64
  %l37 = alloca %"compiler/effects:Facts"
  %l46 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l48 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l52 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l54 = alloca i64
  %l56 = alloca i64
  %l61 = alloca %"compiler/effects:part"
  %l63 = alloca %"compiler/effects:part"
  %l67 = alloca i1
  %l71 = alloca i1
  %l74 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l76 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l78 = alloca i64
  %l80 = alloca i64
  %l85 = alloca i64
  %l86 = alloca ptr
  %l89 = alloca %"compiler/effects:Facts"
  %l94 = alloca i1
  %l96 = alloca ptr
  %l97 = alloca %"compiler/effects:Verdict"
  %l99 = alloca %"compiler/effects:Verdict"
  %l100 = alloca i64
  %l103 = alloca { i64, ptr }
  %l105 = alloca %"compiler/effects:Verdict"
  %l112 = alloca i1
  %l116 = alloca i1
  %l123 = alloca i32
  %l127 = alloca i32
  %l134 = alloca i1
  %l140 = alloca ptr
  %l143 = alloca %"compiler/effects:Facts"
  %l148 = alloca i1
  %l150 = alloca ptr
  %l151 = alloca %"compiler/effects:Verdict"
  %l153 = alloca %"compiler/effects:Verdict"
  %l154 = alloca i64
  %l157 = alloca { i64, ptr }
  %l159 = alloca %"compiler/effects:Verdict"
  %l165 = alloca %"compiler/effects:Facts"
  %l167 = alloca i1
  %l173 = alloca i1
  %l175 = alloca ptr
  %l176 = alloca %"compiler/effects:Verdict"
  %l178 = alloca %"compiler/effects:Verdict"
  %l180 = alloca %"compiler/effects:Verdict"
  %l184 = alloca ptr
  %l185 = alloca ptr
  %l186 = alloca i64
  %l187 = alloca i64
  %l191 = alloca %"compiler/effects:Facts"
  %l196 = alloca i1
  %l198 = alloca ptr
  %l199 = alloca %"compiler/effects:Verdict"
  %l201 = alloca %"compiler/effects:Verdict"
  %l203 = alloca %"compiler/effects:Verdict"
  %s0 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %rv = alloca %"compiler/effects:Verdict"
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"compiler/effects:Verdict" @compiler_2feffects_3aVerdict_2ector(ptr %v2)
  store %"compiler/effects:Verdict" %t1, ptr %l15
  br label %bb1
bb1:
  %t2 = load %"compiler/effects:Verdict", ptr %l15
  store %"compiler/effects:Verdict" %t2, ptr %l4
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/effects:Effects", ptr %t3, i32 0, i32 0
  %t6 = load ptr, ptr %t5, !tbaa !29
  %t8 = getelementptr %"compiler/generic:Program", ptr %t6, i32 0, i32 2
  %t12 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePromiseWords(ptr %v0, ptr %t8, i32 %a3)
  store i64 %t12, ptr %l20
  br label %bb2
bb2:
  %t13 = load i64, ptr @G_2ecompiler_2feffects_2eEffectWords, !tbaa !24
  %t14 = load i64, ptr %l20, !tbaa !24
  %t16 = and i64 %t14, %t13
  store i64 %t16, ptr %l5, !tbaa !24
  %t18 = load i64, ptr %l5, !tbaa !24
  %t20 = icmp eq i64 %t18, 0
  br i1 %t20, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l25, !tbaa !21
  br label %bb5
bb4:
  %t22 = load i64, ptr %l1, !tbaa !24
  %t24 = icmp slt i64 %t22, 0
  store i1 %t24, ptr %l25, !tbaa !21
  br label %bb5
bb5:
  %t26 = load i1, ptr %l25, !tbaa !21
  br i1 %t26, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l28, !tbaa !21
  br label %bb9
bb7:
  %t27 = load i64, ptr %l1, !tbaa !24
  store i64 %t27, ptr %l29, !tbaa !24
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/effects:Effects", ptr %t28, i32 0, i32 1
  %t32 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %t30)
  store i64 %t32, ptr %l32
  br label %bb8
bb8:
  %t33 = load i64, ptr %l29, !tbaa !24
  %t34 = load i64, ptr %l32, !tbaa !24
  %t35 = icmp sge i64 %t33, %t34
  store i1 %t35, ptr %l28, !tbaa !21
  br label %bb9
bb9:
  %t37 = load i1, ptr %l28, !tbaa !21
  br i1 %t37, label %bb10, label %bb11
bb10:
  %t38 = load %"compiler/effects:Verdict", ptr %l4
  call void @__olang_scope_close(ptr %s0)
  store %"compiler/effects:Verdict" %t38, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t41 = load i64, ptr %l1, !tbaa !24
  %t44 = call %"compiler/effects:Facts" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eOf(ptr %v0, ptr %t40, i64 %t41)
  store %"compiler/effects:Facts" %t44, ptr %l37
  br label %bb13
bb13:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t46 = load i64, ptr %l1, !tbaa !24
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ewalkBody(ptr %v0, ptr %t45, i64 %t46)
  br label %bb14
bb14:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/effects:Effects", ptr %t49, i32 0, i32 38
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3apart_3e_2eClear_3ccompiler_2feffects_3apart_3e(ptr %v0, ptr %t51)
  br label %bb15
bb15:
  %t53 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eclassify(ptr %v0, ptr %v1, ptr %t53, ptr %a2, i64 0)
  br label %bb16
bb16:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/effects:Effects", ptr %t58, i32 0, i32 38
  %t61 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t60
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t61, ptr %l46
  %t63 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3apart_3e(ptr %s0, ptr %l46)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t63, ptr %l48
  br label %bb17
bb17:
  %t64 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l48
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t64, ptr %l6
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t66 = load i64, ptr %l1, !tbaa !24
  %t70 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ejudgedParts(ptr %v0, ptr %v0, ptr %v0, ptr %t65, i64 %t66, ptr %l6)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t70, ptr %l52
  br label %bb18
bb18:
  %t71 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l52
  %t72 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t71, ptr %t72
  store ptr %t72, ptr %l7, !tbaa !29
  store i64 0, ptr %l8, !tbaa !24
  br label %bb19
bb19:
  %t74 = load i64, ptr %l8, !tbaa !24
  store i64 %t74, ptr %l54, !tbaa !24
  %t75 = load ptr, ptr %l7, !tbaa !29
  %t77 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3apart_3e_2eLen_3ccompiler_2feffects_3apart_3e(ptr %v0, ptr %t75)
  store i64 %t77, ptr %l56
  br label %bb20
bb20:
  %t78 = load i64, ptr %l54, !tbaa !24
  %t79 = load i64, ptr %l56, !tbaa !24
  %t80 = icmp slt i64 %t78, %t79
  %t82 = xor i1 %t80, true
  br i1 %t82, label %bb21, label %bb22
bb21:
  br label %bb112
bb22:
  br label %bb23
bb23:
  %t84 = load ptr, ptr %l7, !tbaa !29
  %t85 = load i64, ptr %l8, !tbaa !24
  %t88 = call %"compiler/effects:part" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3apart_3e_2eAt_3ccompiler_2feffects_3apart_3e(ptr %v0, ptr %v0, ptr %t84, i64 %t85)
  store %"compiler/effects:part" %t88, ptr %l61
  br label %bb24
bb24:
  %t90 = call %"compiler/effects:part" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2feffects_3apart(ptr %v0, ptr %l61)
  store %"compiler/effects:part" %t90, ptr %l63
  br label %bb25
bb25:
  %t91 = load %"compiler/effects:part", ptr %l63
  store %"compiler/effects:part" %t91, ptr %l9
  %t92 = getelementptr %"compiler/effects:part", ptr %l9, i32 0, i32 0
  %t93 = load i64, ptr %t92, !tbaa !24
  %t94 = load i64, ptr @G_2ecompiler_2feffects_2eGivResult, !tbaa !24
  %t97 = icmp eq i64 %t93, %t94
  br i1 %t97, label %bb26, label %bb27
bb26:
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = getelementptr %"compiler/effects:Effects", ptr %t99, i32 0, i32 10
  %t102 = getelementptr %"compiler/effects:part", ptr %l9, i32 0, i32 1
  %t103 = load i64, ptr %t102, !tbaa !24
  %t106 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cI_Hbd09c84b003bb96b764c8a61b7f32193(ptr %v0, ptr %t101, i64 %t103)
  store i1 %t106, ptr %l71
  br label %bb28
bb27:
  store i1 false, ptr %l67, !tbaa !21
  br label %bb29
bb28:
  %t107 = load i1, ptr %l71, !tbaa !21
  store i1 %t107, ptr %l67, !tbaa !21
  br label %bb29
bb29:
  %t108 = load i1, ptr %l67, !tbaa !21
  br i1 %t108, label %bb30, label %bb31
bb30:
  store %olang.scope zeroinitializer, ptr %s5
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t110 = getelementptr %"compiler/effects:part", ptr %l9, i32 0, i32 1
  %t111 = load i64, ptr %t110, !tbaa !24
  %t114 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eretsOf(ptr %v0, ptr %s5, ptr %t109, i64 %t111)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t114, ptr %l74
  br label %bb32
bb31:
  br label %bb51
bb32:
  %t116 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %s5, ptr %l74)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t116, ptr %l76
  br label %bb33
bb33:
  %t117 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l76
  %t118 = call ptr @__olang_scope_alloc_a(ptr %s5, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t117, ptr %t118
  store ptr %t118, ptr %l10, !tbaa !29
  store i64 0, ptr %l11, !tbaa !24
  br label %bb34
bb34:
  store %olang.scope zeroinitializer, ptr %s6
  %t120 = load i64, ptr %l11, !tbaa !24
  store i64 %t120, ptr %l78, !tbaa !24
  %t121 = load ptr, ptr %l10, !tbaa !29
  %t123 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s5, ptr %t121)
  store i64 %t123, ptr %l80
  br label %bb35
bb35:
  %t124 = load i64, ptr %l78, !tbaa !24
  %t125 = load i64, ptr %l80, !tbaa !24
  %t126 = icmp slt i64 %t124, %t125
  %t128 = xor i1 %t126, true
  br i1 %t128, label %bb36, label %bb37
bb36:
  call void @__olang_scope_close(ptr %s6)
  br label %bb50
bb37:
  br label %bb38
bb38:
  %t130 = load ptr, ptr %l10, !tbaa !29
  %t131 = load i64, ptr %l11, !tbaa !24
  %t134 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s5, ptr %t130, i64 %t131)
  store i64 %t134, ptr %l85
  br label %bb39
bb39:
  %t135 = load i64, ptr %l85, !tbaa !24
  store i64 %t135, ptr %l12, !tbaa !24
  %t136 = load ptr, ptr %l0, !tbaa !29
  store ptr %t136, ptr %l86, !tbaa !29
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t138 = load i64, ptr %l12, !tbaa !24
  %t141 = call %"compiler/effects:Facts" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eOf(ptr %v0, ptr %t137, i64 %t138)
  store %"compiler/effects:Facts" %t141, ptr %l89
  br label %bb40
bb40:
  %t142 = load i64, ptr %l5, !tbaa !24
  %t143 = load ptr, ptr %l86, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ejudgeFacts(ptr %v0, ptr %s6, ptr %v2, ptr %t143, ptr %l89, i64 %t142, ptr %l4)
  br label %bb41
bb41:
  %t147 = getelementptr %"compiler/effects:Verdict", ptr %l4, i32 0, i32 0
  %t148 = load { i64, ptr }, ptr %t147, !tbaa !27
  %t150 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s6, { i64, ptr } %t148, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d12, i32 0, i32 1) })
  store i1 %t150, ptr %l94
  br label %bb42
bb42:
  %t151 = load i1, ptr %l94, !tbaa !21
  %t152 = xor i1 %t151, true
  br i1 %t152, label %bb43, label %bb44
bb43:
  store %olang.scope zeroinitializer, ptr %s7
  %t154 = load ptr, ptr %l0, !tbaa !29
  store ptr %t154, ptr %l96, !tbaa !29
  %t155 = load %"compiler/effects:Verdict", ptr %l4
  store %"compiler/effects:Verdict" %t155, ptr %l97
  %t157 = call %"compiler/effects:Verdict" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2feffects_3aVerdict(ptr %s7, ptr %l97)
  store %"compiler/effects:Verdict" %t157, ptr %l99
  br label %bb45
bb44:
  br label %bb48
bb45:
  %t158 = load i64, ptr %l12, !tbaa !24
  store i64 %t158, ptr %l100, !tbaa !24
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t160 = load i64, ptr %l12, !tbaa !24
  %t163 = call { i64, ptr } @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ebodyName(ptr %v0, ptr %s7, ptr %t159, i64 %t160)
  store { i64, ptr } %t163, ptr %l103
  br label %bb46
bb46:
  %t164 = load { i64, ptr }, ptr %l103, !tbaa !27
  %t165 = load ptr, ptr %l96, !tbaa !29
  %t166 = load %"compiler/effects:Verdict", ptr %l99
  %t167 = load i64, ptr %l100, !tbaa !24
  %t169 = call %"compiler/effects:Verdict" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eblame(ptr %v0, ptr %s7, ptr %s7, ptr %v2, ptr %t165, %"compiler/effects:Verdict" %t166, i64 %t167, { i64, ptr } %t164)
  store %"compiler/effects:Verdict" %t169, ptr %l105
  br label %bb47
bb47:
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  %t170 = load %"compiler/effects:Verdict", ptr %l105
  store %"compiler/effects:Verdict" %t170, ptr %rv
  br label %ret
bb48:
  call void @__olang_scope_close(ptr %s6)
  br label %bb49
bb49:
  %t171 = load i64, ptr %l11, !tbaa !24
  %t174 = add i64 %t171, 1
  store i64 %t174, ptr %l11, !tbaa !24
  br label %bb34
bb50:
  call void @__olang_scope_close(ptr %s5)
  br label %bb111
bb51:
  %t176 = getelementptr %"compiler/effects:part", ptr %l9, i32 0, i32 0
  %t177 = load i64, ptr %t176, !tbaa !24
  %t178 = load i64, ptr @G_2ecompiler_2feffects_2eGivSlot, !tbaa !24
  %t181 = icmp eq i64 %t177, %t178
  br i1 %t181, label %bb52, label %bb53
bb52:
  store i1 true, ptr %l112, !tbaa !21
  br label %bb54
bb53:
  %t183 = getelementptr %"compiler/effects:part", ptr %l9, i32 0, i32 0
  %t184 = load i64, ptr %t183, !tbaa !24
  %t185 = load i64, ptr @G_2ecompiler_2feffects_2eGivBound, !tbaa !24
  %t188 = icmp eq i64 %t184, %t185
  store i1 %t188, ptr %l112, !tbaa !21
  br label %bb54
bb54:
  %t190 = load i1, ptr %l112, !tbaa !21
  br i1 %t190, label %bb55, label %bb56
bb55:
  store i1 true, ptr %l116, !tbaa !21
  br label %bb57
bb56:
  %t191 = getelementptr %"compiler/effects:part", ptr %l9, i32 0, i32 0
  %t192 = load i64, ptr %t191, !tbaa !24
  %t193 = load i64, ptr @G_2ecompiler_2feffects_2eGivResult, !tbaa !24
  %t196 = icmp eq i64 %t192, %t193
  store i1 %t196, ptr %l116, !tbaa !21
  br label %bb57
bb57:
  %t198 = load i1, ptr %l116, !tbaa !21
  br i1 %t198, label %bb58, label %bb59
bb58:
  store %olang.scope zeroinitializer, ptr %s9
  %t199 = getelementptr %"compiler/effects:part", ptr %l9, i32 0, i32 0
  %t200 = load i64, ptr %t199, !tbaa !24
  %t201 = load i64, ptr @G_2ecompiler_2feffects_2eGivSlot, !tbaa !24
  %t204 = icmp eq i64 %t200, %t201
  br i1 %t204, label %bb60, label %bb61
bb59:
  br label %bb69
bb60:
  %t206 = load ptr, ptr %l0, !tbaa !29
  %t207 = load i64, ptr %l1, !tbaa !24
  %t208 = getelementptr %"compiler/effects:part", ptr %l9, i32 0, i32 1
  %t209 = load i64, ptr %t208, !tbaa !24
  %t213 = call i32 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eslotType(ptr %v0, ptr %t206, i64 %t207, i64 %t209)
  store i32 %t213, ptr %l127
  br label %bb62
bb61:
  %t214 = getelementptr %"compiler/effects:part", ptr %l9, i32 0, i32 2
  %t215 = load i32, ptr %t214, !tbaa !23
  store i32 %t215, ptr %l123, !tbaa !23
  br label %bb63
bb62:
  %t217 = load i32, ptr %l127, !tbaa !23
  store i32 %t217, ptr %l123, !tbaa !23
  br label %bb63
bb63:
  %t218 = load i32, ptr %l123, !tbaa !23
  %t219 = load ptr, ptr %l0, !tbaa !29
  %t221 = load i64, ptr %l5, !tbaa !24
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ejudgeType(ptr %v0, ptr %v2, ptr %t219, i32 %t218, i64 %t221, ptr %l4)
  br label %bb64
bb64:
  %t226 = getelementptr %"compiler/effects:Verdict", ptr %l4, i32 0, i32 0
  %t227 = load { i64, ptr }, ptr %t226, !tbaa !27
  %t229 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s9, { i64, ptr } %t227, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d13, i32 0, i32 1) })
  store i1 %t229, ptr %l134
  br label %bb65
bb65:
  %t230 = load i1, ptr %l134, !tbaa !21
  %t231 = xor i1 %t230, true
  br i1 %t231, label %bb66, label %bb67
bb66:
  %t233 = load %"compiler/effects:Verdict", ptr %l4
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s0)
  store %"compiler/effects:Verdict" %t233, ptr %rv
  br label %ret
bb67:
  br label %bb68
bb68:
  call void @__olang_scope_close(ptr %s9)
  br label %bb111
bb69:
  %t235 = getelementptr %"compiler/effects:part", ptr %l9, i32 0, i32 0
  %t236 = load i64, ptr %t235, !tbaa !24
  %t237 = load i64, ptr @G_2ecompiler_2feffects_2eGivNamed, !tbaa !24
  %t240 = icmp eq i64 %t236, %t237
  br i1 %t240, label %bb70, label %bb71
bb70:
  store %olang.scope zeroinitializer, ptr %s11
  %t242 = load ptr, ptr %l0, !tbaa !29
  store ptr %t242, ptr %l140, !tbaa !29
  %t243 = load ptr, ptr %l0, !tbaa !29
  %t244 = getelementptr %"compiler/effects:part", ptr %l9, i32 0, i32 1
  %t245 = load i64, ptr %t244, !tbaa !24
  %t248 = call %"compiler/effects:Facts" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eOf(ptr %v0, ptr %t243, i64 %t245)
  store %"compiler/effects:Facts" %t248, ptr %l143
  br label %bb72
bb71:
  br label %bb81
bb72:
  %t249 = load i64, ptr %l5, !tbaa !24
  %t250 = load ptr, ptr %l140, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ejudgeFacts(ptr %v0, ptr %s11, ptr %v2, ptr %t250, ptr %l143, i64 %t249, ptr %l4)
  br label %bb73
bb73:
  %t254 = getelementptr %"compiler/effects:Verdict", ptr %l4, i32 0, i32 0
  %t255 = load { i64, ptr }, ptr %t254, !tbaa !27
  %t257 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s11, { i64, ptr } %t255, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d14, i32 0, i32 1) })
  store i1 %t257, ptr %l148
  br label %bb74
bb74:
  %t258 = load i1, ptr %l148, !tbaa !21
  %t259 = xor i1 %t258, true
  br i1 %t259, label %bb75, label %bb76
bb75:
  store %olang.scope zeroinitializer, ptr %s12
  %t261 = load ptr, ptr %l0, !tbaa !29
  store ptr %t261, ptr %l150, !tbaa !29
  %t262 = load %"compiler/effects:Verdict", ptr %l4
  store %"compiler/effects:Verdict" %t262, ptr %l151
  %t264 = call %"compiler/effects:Verdict" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2feffects_3aVerdict(ptr %s12, ptr %l151)
  store %"compiler/effects:Verdict" %t264, ptr %l153
  br label %bb77
bb76:
  br label %bb80
bb77:
  %t265 = getelementptr %"compiler/effects:part", ptr %l9, i32 0, i32 1
  %t266 = load i64, ptr %t265, !tbaa !24
  store i64 %t266, ptr %l154, !tbaa !24
  %t267 = load ptr, ptr %l0, !tbaa !29
  %t268 = getelementptr %"compiler/effects:part", ptr %l9, i32 0, i32 1
  %t269 = load i64, ptr %t268, !tbaa !24
  %t272 = call { i64, ptr } @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ebodyName(ptr %v0, ptr %s12, ptr %t267, i64 %t269)
  store { i64, ptr } %t272, ptr %l157
  br label %bb78
bb78:
  %t273 = load { i64, ptr }, ptr %l157, !tbaa !27
  %t274 = load ptr, ptr %l150, !tbaa !29
  %t275 = load %"compiler/effects:Verdict", ptr %l153
  %t276 = load i64, ptr %l154, !tbaa !24
  %t278 = call %"compiler/effects:Verdict" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eblame(ptr %v0, ptr %s12, ptr %s12, ptr %v2, ptr %t274, %"compiler/effects:Verdict" %t275, i64 %t276, { i64, ptr } %t273)
  store %"compiler/effects:Verdict" %t278, ptr %l159
  br label %bb79
bb79:
  call void @__olang_scope_close(ptr %s12)
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s0)
  %t279 = load %"compiler/effects:Verdict", ptr %l159
  store %"compiler/effects:Verdict" %t279, ptr %rv
  br label %ret
bb80:
  call void @__olang_scope_close(ptr %s11)
  br label %bb81
bb81:
  %t280 = getelementptr %"compiler/effects:part", ptr %l9, i32 0, i32 0
  %t281 = load i64, ptr %t280, !tbaa !24
  %t282 = load i64, ptr @G_2ecompiler_2feffects_2ePartAdapter, !tbaa !24
  %t285 = icmp eq i64 %t281, %t282
  br i1 %t285, label %bb82, label %bb83
bb82:
  store %olang.scope zeroinitializer, ptr %s13
  %t287 = load ptr, ptr %l0, !tbaa !29
  %t288 = getelementptr %"compiler/effects:part", ptr %l9, i32 0, i32 1
  %t289 = load i64, ptr %t288, !tbaa !24
  %t292 = call %"compiler/effects:Facts" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eOf(ptr %v0, ptr %t287, i64 %t289)
  store %"compiler/effects:Facts" %t292, ptr %l165
  br label %bb84
bb83:
  br label %bb96
bb84:
  %t293 = load %"compiler/effects:Facts", ptr %l165
  store %"compiler/effects:Facts" %t293, ptr %l14
  %t294 = getelementptr %"compiler/effects:Facts", ptr %l14, i32 0, i32 23
  %t295 = load i64, ptr %t294, !tbaa !24
  %t297 = call i1 @compiler_2feffects_2ehasBit(i64 %t295, i64 0)
  store i1 %t297, ptr %l167
  br label %bb85
bb85:
  %t298 = load i1, ptr %l167, !tbaa !21
  br i1 %t298, label %bb86, label %bb87
bb86:
  %t299 = getelementptr %"compiler/effects:Facts", ptr %l14, i32 0, i32 20
  store i1 true, ptr %t299, !tbaa !21
  br label %bb88
bb87:
  br label %bb88
bb88:
  %t300 = load ptr, ptr %l0, !tbaa !29
  %t301 = load i64, ptr %l5, !tbaa !24
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ejudgeFacts(ptr %v0, ptr %s13, ptr %v2, ptr %t300, ptr %l14, i64 %t301, ptr %l4)
  br label %bb89
bb89:
  %t306 = getelementptr %"compiler/effects:Verdict", ptr %l4, i32 0, i32 0
  %t307 = load { i64, ptr }, ptr %t306, !tbaa !27
  %t309 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s13, { i64, ptr } %t307, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d15, i32 0, i32 1) })
  store i1 %t309, ptr %l173
  br label %bb90
bb90:
  %t310 = load i1, ptr %l173, !tbaa !21
  %t311 = xor i1 %t310, true
  br i1 %t311, label %bb91, label %bb92
bb91:
  store %olang.scope zeroinitializer, ptr %s15
  %t313 = load ptr, ptr %l0, !tbaa !29
  store ptr %t313, ptr %l175, !tbaa !29
  %t314 = load %"compiler/effects:Verdict", ptr %l4
  store %"compiler/effects:Verdict" %t314, ptr %l176
  %t316 = call %"compiler/effects:Verdict" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2feffects_3aVerdict(ptr %s15, ptr %l176)
  store %"compiler/effects:Verdict" %t316, ptr %l178
  br label %bb93
bb92:
  br label %bb95
bb93:
  %t317 = getelementptr %"compiler/effects:part", ptr %l9, i32 0, i32 1
  %t318 = load i64, ptr %t317, !tbaa !24
  %t319 = load ptr, ptr %l175, !tbaa !29
  %t320 = load %"compiler/effects:Verdict", ptr %l178
  %t322 = call %"compiler/effects:Verdict" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eblame(ptr %v0, ptr %s15, ptr %s15, ptr %v2, ptr %t319, %"compiler/effects:Verdict" %t320, i64 %t318, { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d16, i32 0, i32 1) })
  store %"compiler/effects:Verdict" %t322, ptr %l180
  br label %bb94
bb94:
  call void @__olang_scope_close(ptr %s15)
  call void @__olang_scope_close(ptr %s13)
  call void @__olang_scope_close(ptr %s0)
  %t323 = load %"compiler/effects:Verdict", ptr %l180
  store %"compiler/effects:Verdict" %t323, ptr %rv
  br label %ret
bb95:
  call void @__olang_scope_close(ptr %s13)
  br label %bb96
bb96:
  %t324 = getelementptr %"compiler/effects:part", ptr %l9, i32 0, i32 0
  %t325 = load i64, ptr %t324, !tbaa !24
  %t326 = load i64, ptr @G_2ecompiler_2feffects_2ePartLambda, !tbaa !24
  %t329 = icmp eq i64 %t325, %t326
  br i1 %t329, label %bb97, label %bb98
bb97:
  store %olang.scope zeroinitializer, ptr %s16
  %t331 = load ptr, ptr %l0, !tbaa !29
  store ptr %t331, ptr %l184, !tbaa !29
  %t332 = load ptr, ptr %l0, !tbaa !29
  store ptr %t332, ptr %l185, !tbaa !29
  %t333 = load i64, ptr %l1, !tbaa !24
  store i64 %t333, ptr %l186, !tbaa !24
  %t334 = getelementptr %"compiler/effects:part", ptr %l9, i32 0, i32 1
  %t335 = load i64, ptr %t334, !tbaa !24
  store i64 %t335, ptr %l187, !tbaa !24
  %t336 = getelementptr %"compiler/effects:part", ptr %l9, i32 0, i32 3
  %t337 = load ptr, ptr %t336, !tbaa !29
  %t339 = icmp eq ptr %t337, null
  br i1 %t339, label %bb99, label %bb100
bb98:
  br label %bb110
bb99:
  call void @__olang_check_failed(ptr @olang_loc_cce6b986552578d0_26bb880b6e07dfc)
  unreachable
bb100:
  br label %bb101
bb101:
  %t341 = getelementptr %"compiler/effects:part", ptr %l9, i32 0, i32 3
  %t342 = load ptr, ptr %t341, !tbaa !29
  %t343 = load ptr, ptr %l185, !tbaa !29
  %t344 = load i64, ptr %l186, !tbaa !24
  %t345 = load i64, ptr %l187, !tbaa !24
  %t347 = call %"compiler/effects:Facts" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2elambdaFacts(ptr %v0, ptr %v0, ptr %t343, i64 %t344, i64 %t345, ptr %t342)
  store %"compiler/effects:Facts" %t347, ptr %l191
  br label %bb102
bb102:
  %t348 = load i64, ptr %l5, !tbaa !24
  %t349 = load ptr, ptr %l184, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ejudgeFacts(ptr %v0, ptr %s16, ptr %v2, ptr %t349, ptr %l191, i64 %t348, ptr %l4)
  br label %bb103
bb103:
  %t353 = getelementptr %"compiler/effects:Verdict", ptr %l4, i32 0, i32 0
  %t354 = load { i64, ptr }, ptr %t353, !tbaa !27
  %t356 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s16, { i64, ptr } %t354, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d17, i32 0, i32 1) })
  store i1 %t356, ptr %l196
  br label %bb104
bb104:
  %t357 = load i1, ptr %l196, !tbaa !21
  %t358 = xor i1 %t357, true
  br i1 %t358, label %bb105, label %bb106
bb105:
  store %olang.scope zeroinitializer, ptr %s17
  %t360 = load ptr, ptr %l0, !tbaa !29
  store ptr %t360, ptr %l198, !tbaa !29
  %t361 = load %"compiler/effects:Verdict", ptr %l4
  store %"compiler/effects:Verdict" %t361, ptr %l199
  %t363 = call %"compiler/effects:Verdict" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2feffects_3aVerdict(ptr %s17, ptr %l199)
  store %"compiler/effects:Verdict" %t363, ptr %l201
  br label %bb107
bb106:
  br label %bb109
bb107:
  %t364 = getelementptr %"compiler/effects:part", ptr %l9, i32 0, i32 1
  %t365 = load i64, ptr %t364, !tbaa !24
  %t366 = load ptr, ptr %l198, !tbaa !29
  %t367 = load %"compiler/effects:Verdict", ptr %l201
  %t369 = call %"compiler/effects:Verdict" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eblame(ptr %v0, ptr %s17, ptr %s17, ptr %v2, ptr %t366, %"compiler/effects:Verdict" %t367, i64 %t365, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d18, i32 0, i32 1) })
  store %"compiler/effects:Verdict" %t369, ptr %l203
  br label %bb108
bb108:
  call void @__olang_scope_close(ptr %s17)
  call void @__olang_scope_close(ptr %s16)
  call void @__olang_scope_close(ptr %s0)
  %t370 = load %"compiler/effects:Verdict", ptr %l203
  store %"compiler/effects:Verdict" %t370, ptr %rv
  br label %ret
bb109:
  call void @__olang_scope_close(ptr %s16)
  br label %bb110
bb110:
  br label %bb111
bb111:
  %t371 = load i64, ptr %l8, !tbaa !24
  %t374 = add i64 %t371, 1
  store i64 %t374, ptr %l8, !tbaa !24
  br label %bb19
bb112:
  %t376 = load %"compiler/effects:Verdict", ptr %l4
  call void @__olang_scope_close(ptr %s0)
  store %"compiler/effects:Verdict" %t376, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/effects:Verdict", ptr %rv
  ret %"compiler/effects:Verdict" %rr
}

define dso_local void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2earm(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca ptr
  %l18 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Arm", ptr %t1, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t6 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  store i64 %t8, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t10 = load i64, ptr %l3, !tbaa !24
  %t11 = load i64, ptr %l4, !tbaa !24
  %t14 = icmp slt i64 %t10, %t11
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb2, label %bb3
bb2:
  br label %bb15
bb3:
  br label %bb4
bb4:
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t18, ptr %l18, !tbaa !27
  %t19 = load i64, ptr %l3, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr ptr, ptr %t22, i64 %t19
  %t24 = load ptr, ptr %t23, !tbaa !39
  store ptr %t24, ptr %l5, !tbaa !29
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t27 = load ptr, ptr %l5, !tbaa !29
  %t29 = getelementptr %"compiler/typed:Alt", ptr %t27, i32 0, i32 0
  %t30 = load ptr, ptr %t29, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eexpr(ptr %v0, ptr %v1, ptr %t26, ptr %t30)
  br label %bb5
bb5:
  %t34 = load ptr, ptr %l5, !tbaa !29
  %t36 = getelementptr %"compiler/typed:Alt", ptr %t34, i32 0, i32 1
  %t37 = load { i64, ptr }, ptr %t36, !tbaa !27
  store { i64, ptr } %t37, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t39 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t39, 0
  store i64 %t41, ptr %l8, !tbaa !24
  br label %bb6
bb6:
  %t43 = load i64, ptr %l7, !tbaa !24
  %t44 = load i64, ptr %l8, !tbaa !24
  %t47 = icmp slt i64 %t43, %t44
  %t49 = xor i1 %t47, true
  br i1 %t49, label %bb7, label %bb8
bb7:
  br label %bb13
bb8:
  br label %bb9
bb9:
  %t51 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t51, ptr %l33, !tbaa !27
  %t52 = load i64, ptr %l7, !tbaa !24
  %t54 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !27
  %t56 = getelementptr ptr, ptr %t55, i64 %t52
  %t57 = load ptr, ptr %t56, !tbaa !39
  store ptr %t57, ptr %l9, !tbaa !29
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t60 = load ptr, ptr %l9, !tbaa !29
  %t62 = getelementptr %"compiler/typed:Bind", ptr %t60, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eexpr(ptr %v0, ptr %v1, ptr %t59, ptr %t63)
  br label %bb10
bb10:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t68 = load ptr, ptr %l9, !tbaa !29
  %t70 = getelementptr %"compiler/typed:Bind", ptr %t68, i32 0, i32 0
  %t71 = load i32, ptr %t70, !tbaa !23
  %t73 = sext i32 %t71 to i64
  %t74 = load ptr, ptr %l9, !tbaa !29
  %t76 = getelementptr %"compiler/typed:Bind", ptr %t74, i32 0, i32 1
  %t77 = load ptr, ptr %t76, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2edefine(ptr %v0, ptr %v1, ptr %t67, i64 %t73, ptr %t77)
  br label %bb11
bb11:
  br label %bb12
bb12:
  %t81 = load i64, ptr %l7, !tbaa !24
  %t84 = add i64 %t81, 1
  store i64 %t84, ptr %l7, !tbaa !24
  br label %bb6
bb13:
  br label %bb14
bb14:
  %t86 = load i64, ptr %l3, !tbaa !24
  %t89 = add i64 %t86, 1
  store i64 %t89, ptr %l3, !tbaa !24
  br label %bb1
bb15:
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t92 = load ptr, ptr %l1, !tbaa !29
  %t94 = getelementptr %"compiler/typed:Arm", ptr %t92, i32 0, i32 2
  %t95 = load ptr, ptr %t94, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eexpr(ptr %v0, ptr %v1, ptr %t91, ptr %t95)
  br label %bb16
bb16:
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t99 = load ptr, ptr %l1, !tbaa !29
  %t101 = getelementptr %"compiler/typed:Arm", ptr %t99, i32 0, i32 3
  %t102 = load ptr, ptr %t101, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eblock(ptr %v0, ptr %v1, ptr %t98, ptr %t102)
  br label %bb17
bb17:
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t106 = load ptr, ptr %l1, !tbaa !29
  %t108 = getelementptr %"compiler/typed:Arm", ptr %t106, i32 0, i32 4
  %t109 = load ptr, ptr %t108, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eexpr(ptr %v0, ptr %v1, ptr %t105, ptr %t109)
  br label %bb18
bb18:
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/effects:Verdict" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eblame(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/effects:Verdict" %a1, i64 %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/effects:Verdict"
  %l2 = alloca i64
  %l4 = alloca %"compiler/effects:Verdict"
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l13 = alloca %"compiler/effects:Verdict"
  %l14 = alloca i64
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca { i64, ptr }
  %l22 = alloca i64
  %l24 = alloca { i64, ptr }
  %l25 = alloca i64
  %l26 = alloca { i64, ptr }
  %l30 = alloca i64
  %l32 = alloca { i64, ptr }
  %l33 = alloca i64
  %l34 = alloca { i64, ptr }
  %l38 = alloca i64
  %l40 = alloca { i64, ptr }
  %l41 = alloca i64
  %l42 = alloca { i64, ptr }
  %l46 = alloca i64
  %l49 = alloca { i64, ptr }
  %l50 = alloca i64
  %l51 = alloca { i64, ptr }
  %l55 = alloca { i64, ptr }
  %l62 = alloca i64
  %l65 = alloca i64
  %l86 = alloca i1
  %l87 = alloca i64
  %l94 = alloca ptr
  %l95 = alloca i64
  %l97 = alloca { i64, ptr }
  %l98 = alloca i64
  %l99 = alloca { i64, ptr }
  %l103 = alloca { i64, ptr }
  %l116 = alloca ptr
  %l121 = alloca i64
  %l124 = alloca { i64, ptr }
  %l125 = alloca i64
  %l126 = alloca { i64, ptr }
  %l130 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/effects:Verdict"
  store ptr %a0, ptr %l0
  store %"compiler/effects:Verdict" %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load %"compiler/effects:Verdict", ptr %l1
  store %"compiler/effects:Verdict" %t1, ptr %l13
  %t3 = call ptr @__olang_scope_hold(ptr %v3)
  %t4 = ptrtoint ptr %t3 to i64
  store i64 %t4, ptr %l14, !tbaa !24
  %t5 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aVerdict_2e0
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = call ptr @__olang_region_make_part(ptr %v3)
  %t8 = ptrtoint ptr %t7 to i64
  store i64 %t8, ptr %l14, !tbaa !24
  br label %bb2
bb2:
  %t9 = getelementptr %"compiler/effects:Verdict", ptr %l13, i32 0, i32 0
  %t10 = load { i64, ptr }, ptr %t9, !tbaa !27
  store { i64, ptr } %t10, ptr %l16, !tbaa !27
  %t11 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t11, 0
  store i64 %t12, ptr %l17, !tbaa !24
  %t13 = load i64, ptr %l17, !tbaa !24
  %t14 = mul i64 %t13, 1
  %t15 = load i64, ptr %l14
  %t16 = inttoptr i64 %t15 to ptr
  %t17 = call ptr @__olang_held_alloc(ptr %t16, i64 %t14)
  %t18 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  store { i64, ptr } %t19, ptr %l18, !tbaa !27
  %t20 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !27
  %t24 = load i64, ptr %l17, !tbaa !24
  %t25 = mul i64 %t24, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t21, ptr %t23, i64 %t25, i1 false)
  %t26 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t27 = getelementptr %"compiler/effects:Verdict", ptr %l13, i32 0, i32 0
  store { i64, ptr } %t26, ptr %t27, !tbaa !27
  %t28 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aVerdict_2e0
  br i1 %t28, label %bb3, label %bb4
bb3:
  %t30 = getelementptr %"compiler/effects:Verdict", ptr %l13, i32 0, i32 0
  %t31 = load { i64, ptr }, ptr %t30, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t31, 0
  %t34 = icmp eq i64 %t32, 0
  br i1 %t34, label %bb5, label %bb6
bb4:
  %t36 = call ptr @__olang_scope_hold(ptr %v3)
  %t37 = ptrtoint ptr %t36 to i64
  store i64 %t37, ptr %l22, !tbaa !24
  %t38 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aVerdict_2e1
  br i1 %t38, label %bb7, label %bb8
bb5:
  %t40 = getelementptr %"compiler/effects:Verdict", ptr %l13, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t40, !tbaa !27
  br label %bb6
bb6:
  %t41 = getelementptr %"compiler/effects:Verdict", ptr %l13, i32 0, i32 0
  %t42 = load i64, ptr %l14
  %t43 = inttoptr i64 %t42 to ptr
  %t44 = load { i64, ptr }, ptr %t41
  %t45 = extractvalue { i64, ptr } %t44, 1
  %t46 = call ptr @__olang_region_or(ptr %t45, ptr null)
  %t47 = icmp ne ptr %t46, null
  %t48 = select i1 %t47, ptr %t46, ptr null
  call void @__olang_region_settle_in(ptr %t43, ptr %t48)
  br label %bb4
bb7:
  %t49 = call ptr @__olang_region_make_part(ptr %v3)
  %t50 = ptrtoint ptr %t49 to i64
  store i64 %t50, ptr %l22, !tbaa !24
  br label %bb8
bb8:
  %t51 = getelementptr %"compiler/effects:Verdict", ptr %l13, i32 0, i32 1
  %t52 = load { i64, ptr }, ptr %t51, !tbaa !27
  store { i64, ptr } %t52, ptr %l24, !tbaa !27
  %t53 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t54 = extractvalue { i64, ptr } %t53, 0
  store i64 %t54, ptr %l25, !tbaa !24
  %t55 = load i64, ptr %l25, !tbaa !24
  %t56 = mul i64 %t55, 1
  %t57 = load i64, ptr %l22
  %t58 = inttoptr i64 %t57 to ptr
  %t59 = call ptr @__olang_held_alloc(ptr %t58, i64 %t56)
  %t60 = insertvalue { i64, ptr } undef, i64 %t55, 0
  %t61 = insertvalue { i64, ptr } %t60, ptr %t59, 1
  store { i64, ptr } %t61, ptr %l26, !tbaa !27
  %t62 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !27
  %t64 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t65 = load ptr, ptr %t64, !tbaa !27
  %t66 = load i64, ptr %l25, !tbaa !24
  %t67 = mul i64 %t66, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t63, ptr %t65, i64 %t67, i1 false)
  %t68 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t69 = getelementptr %"compiler/effects:Verdict", ptr %l13, i32 0, i32 1
  store { i64, ptr } %t68, ptr %t69, !tbaa !27
  %t70 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aVerdict_2e1
  br i1 %t70, label %bb9, label %bb10
bb9:
  %t72 = getelementptr %"compiler/effects:Verdict", ptr %l13, i32 0, i32 1
  %t73 = load { i64, ptr }, ptr %t72, !tbaa !27
  %t74 = extractvalue { i64, ptr } %t73, 0
  %t76 = icmp eq i64 %t74, 0
  br i1 %t76, label %bb11, label %bb12
bb10:
  %t78 = call ptr @__olang_scope_hold(ptr %v3)
  %t79 = ptrtoint ptr %t78 to i64
  store i64 %t79, ptr %l30, !tbaa !24
  %t80 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aVerdict_2e4
  br i1 %t80, label %bb13, label %bb14
bb11:
  %t82 = getelementptr %"compiler/effects:Verdict", ptr %l13, i32 0, i32 1
  store { i64, ptr } zeroinitializer, ptr %t82, !tbaa !27
  br label %bb12
bb12:
  %t83 = getelementptr %"compiler/effects:Verdict", ptr %l13, i32 0, i32 1
  %t84 = load i64, ptr %l22
  %t85 = inttoptr i64 %t84 to ptr
  %t86 = load { i64, ptr }, ptr %t83
  %t87 = extractvalue { i64, ptr } %t86, 1
  %t88 = call ptr @__olang_region_or(ptr %t87, ptr null)
  %t89 = icmp ne ptr %t88, null
  %t90 = select i1 %t89, ptr %t88, ptr null
  call void @__olang_region_settle_in(ptr %t85, ptr %t90)
  br label %bb10
bb13:
  %t91 = call ptr @__olang_region_make_part(ptr %v3)
  %t92 = ptrtoint ptr %t91 to i64
  store i64 %t92, ptr %l30, !tbaa !24
  br label %bb14
bb14:
  %t93 = getelementptr %"compiler/effects:Verdict", ptr %l13, i32 0, i32 4
  %t94 = load { i64, ptr }, ptr %t93, !tbaa !27
  store { i64, ptr } %t94, ptr %l32, !tbaa !27
  %t95 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t96 = extractvalue { i64, ptr } %t95, 0
  store i64 %t96, ptr %l33, !tbaa !24
  %t97 = load i64, ptr %l33, !tbaa !24
  %t98 = mul i64 %t97, 1
  %t99 = load i64, ptr %l30
  %t100 = inttoptr i64 %t99 to ptr
  %t101 = call ptr @__olang_held_alloc(ptr %t100, i64 %t98)
  %t102 = insertvalue { i64, ptr } undef, i64 %t97, 0
  %t103 = insertvalue { i64, ptr } %t102, ptr %t101, 1
  store { i64, ptr } %t103, ptr %l34, !tbaa !27
  %t104 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t105 = load ptr, ptr %t104, !tbaa !27
  %t106 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t107 = load ptr, ptr %t106, !tbaa !27
  %t108 = load i64, ptr %l33, !tbaa !24
  %t109 = mul i64 %t108, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t105, ptr %t107, i64 %t109, i1 false)
  %t110 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t111 = getelementptr %"compiler/effects:Verdict", ptr %l13, i32 0, i32 4
  store { i64, ptr } %t110, ptr %t111, !tbaa !27
  %t112 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aVerdict_2e4
  br i1 %t112, label %bb15, label %bb16
bb15:
  %t114 = getelementptr %"compiler/effects:Verdict", ptr %l13, i32 0, i32 4
  %t115 = load { i64, ptr }, ptr %t114, !tbaa !27
  %t116 = extractvalue { i64, ptr } %t115, 0
  %t118 = icmp eq i64 %t116, 0
  br i1 %t118, label %bb17, label %bb18
bb16:
  %t120 = call ptr @__olang_scope_hold(ptr %v3)
  %t121 = ptrtoint ptr %t120 to i64
  store i64 %t121, ptr %l38, !tbaa !24
  %t122 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aVerdict_2e7
  br i1 %t122, label %bb19, label %bb20
bb17:
  %t124 = getelementptr %"compiler/effects:Verdict", ptr %l13, i32 0, i32 4
  store { i64, ptr } zeroinitializer, ptr %t124, !tbaa !27
  br label %bb18
bb18:
  %t125 = getelementptr %"compiler/effects:Verdict", ptr %l13, i32 0, i32 4
  %t126 = load i64, ptr %l30
  %t127 = inttoptr i64 %t126 to ptr
  %t128 = load { i64, ptr }, ptr %t125
  %t129 = extractvalue { i64, ptr } %t128, 1
  %t130 = call ptr @__olang_region_or(ptr %t129, ptr null)
  %t131 = icmp ne ptr %t130, null
  %t132 = select i1 %t131, ptr %t130, ptr null
  call void @__olang_region_settle_in(ptr %t127, ptr %t132)
  br label %bb16
bb19:
  %t133 = call ptr @__olang_region_make_part(ptr %v3)
  %t134 = ptrtoint ptr %t133 to i64
  store i64 %t134, ptr %l38, !tbaa !24
  br label %bb20
bb20:
  %t135 = getelementptr %"compiler/effects:Verdict", ptr %l13, i32 0, i32 7
  %t136 = load { i64, ptr }, ptr %t135, !tbaa !27
  store { i64, ptr } %t136, ptr %l40, !tbaa !27
  %t137 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t138 = extractvalue { i64, ptr } %t137, 0
  store i64 %t138, ptr %l41, !tbaa !24
  %t139 = load i64, ptr %l41, !tbaa !24
  %t140 = mul i64 %t139, 1
  %t141 = load i64, ptr %l38
  %t142 = inttoptr i64 %t141 to ptr
  %t143 = call ptr @__olang_held_alloc(ptr %t142, i64 %t140)
  %t144 = insertvalue { i64, ptr } undef, i64 %t139, 0
  %t145 = insertvalue { i64, ptr } %t144, ptr %t143, 1
  store { i64, ptr } %t145, ptr %l42, !tbaa !27
  %t146 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t147 = load ptr, ptr %t146, !tbaa !27
  %t148 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t149 = load ptr, ptr %t148, !tbaa !27
  %t150 = load i64, ptr %l41, !tbaa !24
  %t151 = mul i64 %t150, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t147, ptr %t149, i64 %t151, i1 false)
  %t152 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t153 = getelementptr %"compiler/effects:Verdict", ptr %l13, i32 0, i32 7
  store { i64, ptr } %t152, ptr %t153, !tbaa !27
  %t154 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aVerdict_2e7
  br i1 %t154, label %bb21, label %bb22
bb21:
  %t156 = getelementptr %"compiler/effects:Verdict", ptr %l13, i32 0, i32 7
  %t157 = load { i64, ptr }, ptr %t156, !tbaa !27
  %t158 = extractvalue { i64, ptr } %t157, 0
  %t160 = icmp eq i64 %t158, 0
  br i1 %t160, label %bb23, label %bb24
bb22:
  %t162 = load %"compiler/effects:Verdict", ptr %l13
  store %"compiler/effects:Verdict" %t162, ptr %l4
  %t163 = call ptr @__olang_scope_hold(ptr %v3)
  %t164 = ptrtoint ptr %t163 to i64
  store i64 %t164, ptr %l46, !tbaa !24
  %t165 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aVerdict_2e4
  br i1 %t165, label %bb25, label %bb26
bb23:
  %t167 = getelementptr %"compiler/effects:Verdict", ptr %l13, i32 0, i32 7
  store { i64, ptr } zeroinitializer, ptr %t167, !tbaa !27
  br label %bb24
bb24:
  %t168 = getelementptr %"compiler/effects:Verdict", ptr %l13, i32 0, i32 7
  %t169 = load i64, ptr %l38
  %t170 = inttoptr i64 %t169 to ptr
  %t171 = load { i64, ptr }, ptr %t168
  %t172 = extractvalue { i64, ptr } %t171, 1
  %t173 = call ptr @__olang_region_or(ptr %t172, ptr null)
  %t174 = icmp ne ptr %t173, null
  %t175 = select i1 %t174, ptr %t173, ptr null
  call void @__olang_region_settle_in(ptr %t170, ptr %t175)
  br label %bb22
bb25:
  %t176 = call ptr @__olang_region_make_part(ptr %v3)
  %t177 = ptrtoint ptr %t176 to i64
  store i64 %t177, ptr %l46, !tbaa !24
  br label %bb26
bb26:
  store { i64, ptr } %a3, ptr %l49, !tbaa !27
  %t180 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t181 = extractvalue { i64, ptr } %t180, 0
  store i64 %t181, ptr %l50, !tbaa !24
  %t182 = load i64, ptr %l50, !tbaa !24
  %t183 = mul i64 %t182, 1
  %t184 = load i64, ptr %l46
  %t185 = inttoptr i64 %t184 to ptr
  %t186 = call ptr @__olang_held_alloc(ptr %t185, i64 %t183)
  %t187 = insertvalue { i64, ptr } undef, i64 %t182, 0
  %t188 = insertvalue { i64, ptr } %t187, ptr %t186, 1
  store { i64, ptr } %t188, ptr %l51, !tbaa !27
  %t189 = getelementptr { i64, ptr }, ptr %l51, i32 0, i32 1
  %t190 = load ptr, ptr %t189, !tbaa !27
  %t191 = getelementptr { i64, ptr }, ptr %l49, i32 0, i32 1
  %t192 = load ptr, ptr %t191, !tbaa !27
  %t193 = load i64, ptr %l50, !tbaa !24
  %t194 = mul i64 %t193, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t190, ptr %t192, i64 %t194, i1 false)
  %t195 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aVerdict_2e4
  br i1 %t195, label %bb27, label %bb28
bb27:
  %t197 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t198 = extractvalue { i64, ptr } %t197, 0
  %t200 = icmp eq i64 %t198, 0
  br i1 %t200, label %bb29, label %bb30
bb28:
  %t202 = getelementptr %"compiler/effects:Verdict", ptr %l4, i32 0, i32 4
  %t203 = load { i64, ptr }, ptr %t202, !tbaa !27
  store { i64, ptr } %t203, ptr %l55, !tbaa !27
  %t204 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t205 = getelementptr %"compiler/effects:Verdict", ptr %l4, i32 0, i32 4
  store { i64, ptr } %t204, ptr %t205, !tbaa !27
  %t206 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aVerdict_2e4
  br i1 %t206, label %bb31, label %bb32
bb29:
  store { i64, ptr } zeroinitializer, ptr %l51, !tbaa !27
  br label %bb30
bb30:
  %t208 = load i64, ptr %l46
  %t209 = inttoptr i64 %t208 to ptr
  %t210 = load { i64, ptr }, ptr %l51
  %t211 = extractvalue { i64, ptr } %t210, 1
  %t212 = call ptr @__olang_region_or(ptr %t211, ptr null)
  %t213 = icmp ne ptr %t212, null
  %t214 = select i1 %t213, ptr %t212, ptr null
  call void @__olang_region_settle_in(ptr %t209, ptr %t214)
  br label %bb28
bb31:
  %t215 = load { i64, ptr }, ptr %l55
  %t216 = extractvalue { i64, ptr } %t215, 0
  %t217 = extractvalue { i64, ptr } %t215, 1
  call void @__olang_region_release_part(ptr %t217, i64 %t216)
  store { i64, ptr } zeroinitializer, ptr %l55
  br label %bb32
bb32:
  store i64 0, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  %t218 = load [8 x { i64, ptr }], ptr @G_2ecompiler_2ftypes_2ePromiseNames
  store i64 8, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t221 = load i64, ptr %l7, !tbaa !24
  %t222 = load i64, ptr %l6, !tbaa !24
  %t225 = icmp sgt i64 %t221, %t222
  br i1 %t225, label %bb33, label %bb34
bb33:
  %t227 = load i64, ptr %l8, !tbaa !24
  %t229 = icmp sgt i64 %t227, 0
  br i1 %t229, label %bb35, label %bb36
bb34:
  store i64 0, ptr %l62, !tbaa !24
  br label %bb38
bb35:
  %t231 = load i64, ptr %l7, !tbaa !24
  %t232 = load i64, ptr %l6, !tbaa !24
  %t235 = sub i64 %t231, %t232
  %t236 = load i64, ptr %l8, !tbaa !24
  %t239 = add i64 %t235, %t236
  %t241 = sub i64 %t239, 1
  %t242 = load i64, ptr %l8, !tbaa !24
  %t245 = sdiv i64 %t241, %t242
  store i64 %t245, ptr %l65, !tbaa !24
  br label %bb37
bb36:
  store i64 0, ptr %l65, !tbaa !24
  br label %bb37
bb37:
  %t247 = load i64, ptr %l65, !tbaa !24
  store i64 %t247, ptr %l62, !tbaa !24
  br label %bb38
bb38:
  %t248 = load i64, ptr %l62, !tbaa !24
  store i64 %t248, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb39
bb39:
  %t249 = load i64, ptr %l10, !tbaa !24
  %t250 = load i64, ptr %l9, !tbaa !24
  %t253 = icmp slt i64 %t249, %t250
  %t255 = xor i1 %t253, true
  br i1 %t255, label %bb40, label %bb41
bb40:
  br label %bb48
bb41:
  br label %bb42
bb42:
  %t257 = load i64, ptr %l6, !tbaa !24
  %t258 = load i64, ptr %l10, !tbaa !24
  %t259 = load i64, ptr %l8, !tbaa !24
  %t262 = mul i64 %t258, %t259
  %t265 = add i64 %t257, %t262
  store i64 %t265, ptr %l11, !tbaa !24
  %t267 = load i64, ptr %l11, !tbaa !24
  %t269 = getelementptr [8 x { i64, ptr }], ptr @G_2ecompiler_2ftypes_2ePromiseNames, i64 0, i64 %t267
  %t270 = load { i64, ptr }, ptr %t269, !tbaa !37
  %t271 = getelementptr %"compiler/effects:Verdict", ptr %l1, i32 0, i32 0
  %t272 = load { i64, ptr }, ptr %t271, !tbaa !27
  %t273 = load ptr, ptr @__olang_prog_scope
  %t276 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %t273, ptr %s0, { i64, ptr } %t270, { i64, ptr } %t272)
  store i1 %t276, ptr %l86
  br label %bb43
bb43:
  %t277 = load i1, ptr %l86, !tbaa !21
  br i1 %t277, label %bb44, label %bb45
bb44:
  %t278 = load i64, ptr %l11, !tbaa !24
  store i64 %t278, ptr %l87, !tbaa !24
  %t279 = load i64, ptr %l87, !tbaa !24
  %t280 = load i64, ptr %l87, !tbaa !24
  %t281 = shl i64 1, %t280
  store i64 %t281, ptr %l5, !tbaa !24
  br label %bb46
bb45:
  br label %bb46
bb46:
  br label %bb47
bb47:
  %t283 = load i64, ptr %l10, !tbaa !24
  %t286 = add i64 %t283, 1
  store i64 %t286, ptr %l10, !tbaa !24
  br label %bb39
bb48:
  %t288 = load ptr, ptr %l0, !tbaa !29
  %t289 = load i64, ptr %l5, !tbaa !24
  %t292 = getelementptr %"compiler/effects:Effects", ptr %t288, i32 0, i32 49
  store i64 %t289, ptr %t292, !tbaa !24
  %t293 = load ptr, ptr %l0, !tbaa !29
  store ptr %t293, ptr %l94, !tbaa !29
  %t294 = call ptr @__olang_scope_hold(ptr %v0)
  %t295 = ptrtoint ptr %t294 to i64
  store i64 %t295, ptr %l95, !tbaa !24
  %t296 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e50
  br i1 %t296, label %bb49, label %bb50
bb49:
  %t298 = call ptr @__olang_region_make_part(ptr %v0)
  %t299 = ptrtoint ptr %t298 to i64
  store i64 %t299, ptr %l95, !tbaa !24
  br label %bb50
bb50:
  %t300 = getelementptr %"compiler/effects:Verdict", ptr %l1, i32 0, i32 1
  %t301 = load { i64, ptr }, ptr %t300, !tbaa !27
  store { i64, ptr } %t301, ptr %l97, !tbaa !27
  %t302 = load { i64, ptr }, ptr %l97, !tbaa !27
  %t303 = extractvalue { i64, ptr } %t302, 0
  store i64 %t303, ptr %l98, !tbaa !24
  %t304 = load i64, ptr %l98, !tbaa !24
  %t305 = mul i64 %t304, 1
  %t306 = load i64, ptr %l95
  %t307 = inttoptr i64 %t306 to ptr
  %t308 = call ptr @__olang_held_alloc(ptr %t307, i64 %t305)
  %t309 = insertvalue { i64, ptr } undef, i64 %t304, 0
  %t310 = insertvalue { i64, ptr } %t309, ptr %t308, 1
  store { i64, ptr } %t310, ptr %l99, !tbaa !27
  %t311 = getelementptr { i64, ptr }, ptr %l99, i32 0, i32 1
  %t312 = load ptr, ptr %t311, !tbaa !27
  %t313 = getelementptr { i64, ptr }, ptr %l97, i32 0, i32 1
  %t314 = load ptr, ptr %t313, !tbaa !27
  %t315 = load i64, ptr %l98, !tbaa !24
  %t316 = mul i64 %t315, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t312, ptr %t314, i64 %t316, i1 false)
  %t317 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e50
  br i1 %t317, label %bb51, label %bb52
bb51:
  %t319 = load { i64, ptr }, ptr %l99, !tbaa !27
  %t320 = extractvalue { i64, ptr } %t319, 0
  %t322 = icmp eq i64 %t320, 0
  br i1 %t322, label %bb53, label %bb54
bb52:
  %t324 = load ptr, ptr %l94, !tbaa !29
  %t325 = getelementptr %"compiler/effects:Effects", ptr %t324, i32 0, i32 50
  %t326 = load { i64, ptr }, ptr %t325, !tbaa !27
  store { i64, ptr } %t326, ptr %l103, !tbaa !27
  %t327 = load { i64, ptr }, ptr %l99, !tbaa !27
  %t328 = load ptr, ptr %l94, !tbaa !29
  %t329 = getelementptr %"compiler/effects:Effects", ptr %t328, i32 0, i32 50
  store { i64, ptr } %t327, ptr %t329, !tbaa !27
  %t330 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e50
  br i1 %t330, label %bb55, label %bb56
bb53:
  store { i64, ptr } zeroinitializer, ptr %l99, !tbaa !27
  br label %bb54
bb54:
  %t332 = load i64, ptr %l95
  %t333 = inttoptr i64 %t332 to ptr
  %t334 = load { i64, ptr }, ptr %l99
  %t335 = extractvalue { i64, ptr } %t334, 1
  %t336 = call ptr @__olang_region_or(ptr %t335, ptr null)
  %t337 = icmp ne ptr %t336, null
  %t338 = select i1 %t337, ptr %t336, ptr null
  call void @__olang_region_settle_in(ptr %t333, ptr %t338)
  br label %bb52
bb55:
  %t339 = load { i64, ptr }, ptr %l103
  %t340 = extractvalue { i64, ptr } %t339, 0
  %t341 = extractvalue { i64, ptr } %t339, 1
  call void @__olang_region_release_part(ptr %t341, i64 %t340)
  store { i64, ptr } zeroinitializer, ptr %l103
  br label %bb56
bb56:
  %t342 = load ptr, ptr %l0, !tbaa !29
  %t344 = getelementptr %"compiler/effects:Effects", ptr %t342, i32 0, i32 51
  store i1 false, ptr %t344, !tbaa !21
  %t345 = load ptr, ptr %l0, !tbaa !29
  %t346 = load i64, ptr %l2, !tbaa !24
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ewalkBody(ptr %v0, ptr %t345, i64 %t346)
  br label %bb57
bb57:
  %t349 = load ptr, ptr %l0, !tbaa !29
  %t351 = getelementptr %"compiler/effects:Effects", ptr %t349, i32 0, i32 49
  store i64 0, ptr %t351, !tbaa !24
  %t352 = load ptr, ptr %l0, !tbaa !29
  %t354 = getelementptr %"compiler/effects:Effects", ptr %t352, i32 0, i32 51
  %t355 = load i1, ptr %t354, !tbaa !21
  %t357 = xor i1 %t355, true
  br i1 %t357, label %bb58, label %bb59
bb58:
  %t359 = load %"compiler/effects:Verdict", ptr %l4
  call void @__olang_scope_close(ptr %s0)
  store %"compiler/effects:Verdict" %t359, ptr %rv
  br label %ret
bb59:
  br label %bb60
bb60:
  %t361 = load ptr, ptr %l0, !tbaa !29
  %t363 = getelementptr %"compiler/effects:Effects", ptr %t361, i32 0, i32 1
  %t364 = load i64, ptr %l2, !tbaa !24
  %t367 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t363, i64 %t364)
  store ptr %t367, ptr %l116
  br label %bb61
bb61:
  %t368 = load ptr, ptr %l116, !tbaa !29
  %t370 = getelementptr %"compiler/typed:Body", ptr %t368, i32 0, i32 3
  %t371 = load i64, ptr %t370, !tbaa !24
  %t373 = getelementptr %"compiler/effects:Verdict", ptr %l4, i32 0, i32 5
  store i64 %t371, ptr %t373, !tbaa !24
  %t374 = load ptr, ptr %l0, !tbaa !29
  %t376 = getelementptr %"compiler/effects:Effects", ptr %t374, i32 0, i32 52
  %t377 = load %"compiler/source:Span", ptr %t376
  %t379 = getelementptr %"compiler/effects:Verdict", ptr %l4, i32 0, i32 6
  store %"compiler/source:Span" %t377, ptr %t379
  %t380 = call ptr @__olang_scope_hold(ptr %v3)
  %t381 = ptrtoint ptr %t380 to i64
  store i64 %t381, ptr %l121, !tbaa !24
  %t382 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aVerdict_2e7
  br i1 %t382, label %bb62, label %bb63
bb62:
  %t384 = call ptr @__olang_region_make_part(ptr %v3)
  %t385 = ptrtoint ptr %t384 to i64
  store i64 %t385, ptr %l121, !tbaa !24
  br label %bb63
bb63:
  %t386 = load ptr, ptr %l0, !tbaa !29
  %t388 = getelementptr %"compiler/effects:Effects", ptr %t386, i32 0, i32 53
  %t389 = load { i64, ptr }, ptr %t388, !tbaa !27
  store { i64, ptr } %t389, ptr %l124, !tbaa !27
  %t390 = load { i64, ptr }, ptr %l124, !tbaa !27
  %t391 = extractvalue { i64, ptr } %t390, 0
  store i64 %t391, ptr %l125, !tbaa !24
  %t392 = load i64, ptr %l125, !tbaa !24
  %t393 = mul i64 %t392, 1
  %t394 = load i64, ptr %l121
  %t395 = inttoptr i64 %t394 to ptr
  %t396 = call ptr @__olang_held_alloc(ptr %t395, i64 %t393)
  %t397 = insertvalue { i64, ptr } undef, i64 %t392, 0
  %t398 = insertvalue { i64, ptr } %t397, ptr %t396, 1
  store { i64, ptr } %t398, ptr %l126, !tbaa !27
  %t399 = getelementptr { i64, ptr }, ptr %l126, i32 0, i32 1
  %t400 = load ptr, ptr %t399, !tbaa !27
  %t401 = getelementptr { i64, ptr }, ptr %l124, i32 0, i32 1
  %t402 = load ptr, ptr %t401, !tbaa !27
  %t403 = load i64, ptr %l125, !tbaa !24
  %t404 = mul i64 %t403, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t400, ptr %t402, i64 %t404, i1 false)
  %t405 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aVerdict_2e7
  br i1 %t405, label %bb64, label %bb65
bb64:
  %t407 = load { i64, ptr }, ptr %l126, !tbaa !27
  %t408 = extractvalue { i64, ptr } %t407, 0
  %t410 = icmp eq i64 %t408, 0
  br i1 %t410, label %bb66, label %bb67
bb65:
  %t412 = getelementptr %"compiler/effects:Verdict", ptr %l4, i32 0, i32 7
  %t413 = load { i64, ptr }, ptr %t412, !tbaa !27
  store { i64, ptr } %t413, ptr %l130, !tbaa !27
  %t414 = load { i64, ptr }, ptr %l126, !tbaa !27
  %t415 = getelementptr %"compiler/effects:Verdict", ptr %l4, i32 0, i32 7
  store { i64, ptr } %t414, ptr %t415, !tbaa !27
  %t416 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aVerdict_2e7
  br i1 %t416, label %bb68, label %bb69
bb66:
  store { i64, ptr } zeroinitializer, ptr %l126, !tbaa !27
  br label %bb67
bb67:
  %t418 = load i64, ptr %l121
  %t419 = inttoptr i64 %t418 to ptr
  %t420 = load { i64, ptr }, ptr %l126
  %t421 = extractvalue { i64, ptr } %t420, 1
  %t422 = call ptr @__olang_region_or(ptr %t421, ptr null)
  %t423 = icmp ne ptr %t422, null
  %t424 = select i1 %t423, ptr %t422, ptr null
  call void @__olang_region_settle_in(ptr %t419, ptr %t424)
  br label %bb65
bb68:
  %t425 = load { i64, ptr }, ptr %l130
  %t426 = extractvalue { i64, ptr } %t425, 0
  %t427 = extractvalue { i64, ptr } %t425, 1
  call void @__olang_region_release_part(ptr %t427, i64 %t426)
  store { i64, ptr } zeroinitializer, ptr %l130
  br label %bb69
bb69:
  %t428 = load %"compiler/effects:Verdict", ptr %l4
  call void @__olang_scope_close(ptr %s0)
  store %"compiler/effects:Verdict" %t428, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/effects:Verdict", ptr %rv
  ret %"compiler/effects:Verdict" %rr
}

define dso_local %"compiler/effects:Facts" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ebounds(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca %"compiler/effects:Facts"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i1
  %l18 = alloca ptr
  %l19 = alloca i64
  %l20 = alloca %"compiler/effects:given"
  %l21 = alloca %"compiler/effects:Facts"
  %l22 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l26 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l27 = alloca i32
  %l29 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l30 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l34 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l36 = alloca i64
  %l40 = alloca i64
  %l43 = alloca i64
  %l64 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l67 = alloca i64
  %l70 = alloca i1
  %l71 = alloca i64
  %l74 = alloca i64
  %l76 = alloca i1
  %l80 = alloca i64
  %l85 = alloca i64
  %l88 = alloca i64
  %l109 = alloca i64
  %l111 = alloca i1
  %l114 = alloca i64
  %l116 = alloca i64
  %l121 = alloca %"compiler/effects:given"
  %l125 = alloca i1
  %l132 = alloca i1
  %l136 = alloca i1
  %l140 = alloca i1
  %l142 = alloca ptr
  %l147 = alloca %"compiler/effects:Facts"
  %l154 = alloca ptr
  %l157 = alloca ptr
  %l161 = alloca i32
  %l162 = alloca %"compiler/effects:Facts"
  %s0 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %rv = alloca %"compiler/effects:Facts"
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"compiler/effects:Facts" @compiler_2feffects_3aFacts_2ector(ptr %s0)
  store %"compiler/effects:Facts" %t1, ptr %l21
  br label %bb1
bb1:
  %t2 = load %"compiler/effects:Facts", ptr %l21
  store %"compiler/effects:Facts" %t2, ptr %l2
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/effects:Effects", ptr %t3, i32 0, i32 9
  %t6 = load i64, ptr %l1, !tbaa !24
  %t9 = call { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cc_H7b34d2d8e55697dbed551519dd59c955(ptr %v0, ptr %v0, ptr %t5, i64 %t6)
  %t10 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t9, 1
  %t11 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t9, 0
  store i32 %t11, ptr %l27
  %t12 = icmp ne i32 %t11, 0
  br i1 %t12, label %bb3, label %ok.13, !prof !99
ok.13:
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t10, ptr %l26
  br label %bb2
bb2:
  %t15 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3agiven_3e(ptr %s0, ptr %l26)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t15, ptr %l29
  br label %bb5
bb3:
  br label %bb4
bb4:
  %t16 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3agiven_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t16, ptr %l30
  br label %bb6
bb5:
  %t17 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l29
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t17, ptr %l22
  br label %bb7
bb6:
  %t18 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l30
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t18, ptr %l22
  br label %bb7
bb7:
  %t19 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l22
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t19, ptr %l3
  store i64 0, ptr %l4, !tbaa !24
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/effects:Effects", ptr %t20, i32 0, i32 6
  %t23 = load i64, ptr %l1, !tbaa !24
  %t26 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__H7b6d4eff6fc9c3821aae8b284e12e095(ptr %v0, ptr %v0, ptr %t22, i64 %t23)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t26, ptr %l34
  br label %bb8
bb8:
  %t28 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %l34)
  store i64 %t28, ptr %l36
  br label %bb9
bb9:
  %t29 = load i64, ptr %l36, !tbaa !24
  store i64 %t29, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t30 = load i64, ptr %l5, !tbaa !24
  %t31 = load i64, ptr %l4, !tbaa !24
  %t34 = icmp sgt i64 %t30, %t31
  br i1 %t34, label %bb10, label %bb11
bb10:
  %t36 = load i64, ptr %l6, !tbaa !24
  %t38 = icmp sgt i64 %t36, 0
  br i1 %t38, label %bb12, label %bb13
bb11:
  store i64 0, ptr %l40, !tbaa !24
  br label %bb15
bb12:
  %t40 = load i64, ptr %l5, !tbaa !24
  %t41 = load i64, ptr %l4, !tbaa !24
  %t44 = sub i64 %t40, %t41
  %t45 = load i64, ptr %l6, !tbaa !24
  %t48 = add i64 %t44, %t45
  %t50 = sub i64 %t48, 1
  %t51 = load i64, ptr %l6, !tbaa !24
  %t54 = sdiv i64 %t50, %t51
  store i64 %t54, ptr %l43, !tbaa !24
  br label %bb14
bb13:
  store i64 0, ptr %l43, !tbaa !24
  br label %bb14
bb14:
  %t56 = load i64, ptr %l43, !tbaa !24
  store i64 %t56, ptr %l40, !tbaa !24
  br label %bb15
bb15:
  %t57 = load i64, ptr %l40, !tbaa !24
  store i64 %t57, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb16
bb16:
  %t58 = load i64, ptr %l8, !tbaa !24
  %t59 = load i64, ptr %l7, !tbaa !24
  %t62 = icmp slt i64 %t58, %t59
  %t64 = xor i1 %t62, true
  br i1 %t64, label %bb17, label %bb18
bb17:
  br label %bb83
bb18:
  br label %bb19
bb19:
  %t66 = load i64, ptr %l4, !tbaa !24
  %t67 = load i64, ptr %l8, !tbaa !24
  %t68 = load i64, ptr %l6, !tbaa !24
  %t71 = mul i64 %t67, %t68
  %t74 = add i64 %t66, %t71
  store i64 %t74, ptr %l9, !tbaa !24
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"compiler/effects:Effects", ptr %t76, i32 0, i32 6
  %t79 = load i64, ptr %l1, !tbaa !24
  %t82 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__H7b6d4eff6fc9c3821aae8b284e12e095(ptr %v0, ptr %v0, ptr %t78, i64 %t79)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t82, ptr %l64
  br label %bb20
bb20:
  %t83 = load i64, ptr %l9, !tbaa !24
  %t86 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %l64, i64 %t83)
  store i64 %t86, ptr %l67
  br label %bb21
bb21:
  %t87 = load i64, ptr %l67, !tbaa !24
  store i64 %t87, ptr %l10, !tbaa !24
  %t88 = load i64, ptr %l10, !tbaa !24
  %t90 = icmp slt i64 %t88, 0
  br i1 %t90, label %bb22, label %bb23
bb22:
  store i1 true, ptr %l70, !tbaa !21
  br label %bb25
bb23:
  %t92 = load i64, ptr %l10, !tbaa !24
  store i64 %t92, ptr %l71, !tbaa !24
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/effects:Effects", ptr %t93, i32 0, i32 1
  %t97 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %t95)
  store i64 %t97, ptr %l74
  br label %bb24
bb24:
  %t98 = load i64, ptr %l71, !tbaa !24
  %t99 = load i64, ptr %l74, !tbaa !24
  %t100 = icmp sge i64 %t98, %t99
  store i1 %t100, ptr %l70, !tbaa !21
  br label %bb25
bb25:
  %t102 = load i1, ptr %l70, !tbaa !21
  br i1 %t102, label %bb26, label %bb27
bb26:
  store i1 true, ptr %l76, !tbaa !21
  br label %bb29
bb27:
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t105 = getelementptr %"compiler/effects:Effects", ptr %t103, i32 0, i32 12
  %t106 = load i64, ptr %l10, !tbaa !24
  %t109 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t105, i64 %t106)
  store i64 %t109, ptr %l80
  br label %bb28
bb28:
  %t110 = load i64, ptr %l80, !tbaa !24
  %t111 = icmp eq i64 %t110, 0
  store i1 %t111, ptr %l76, !tbaa !21
  br label %bb29
bb29:
  %t113 = load i1, ptr %l76, !tbaa !21
  br i1 %t113, label %bb30, label %bb31
bb30:
  br label %bb82
bb31:
  br label %bb32
bb32:
  store i64 0, ptr %l11, !tbaa !24
  store i64 63, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t114 = load i64, ptr %l12, !tbaa !24
  %t115 = load i64, ptr %l11, !tbaa !24
  %t118 = icmp sgt i64 %t114, %t115
  br i1 %t118, label %bb33, label %bb34
bb33:
  %t120 = load i64, ptr %l13, !tbaa !24
  %t122 = icmp sgt i64 %t120, 0
  br i1 %t122, label %bb35, label %bb36
bb34:
  store i64 0, ptr %l85, !tbaa !24
  br label %bb38
bb35:
  %t124 = load i64, ptr %l12, !tbaa !24
  %t125 = load i64, ptr %l11, !tbaa !24
  %t128 = sub i64 %t124, %t125
  %t129 = load i64, ptr %l13, !tbaa !24
  %t132 = add i64 %t128, %t129
  %t134 = sub i64 %t132, 1
  %t135 = load i64, ptr %l13, !tbaa !24
  %t138 = sdiv i64 %t134, %t135
  store i64 %t138, ptr %l88, !tbaa !24
  br label %bb37
bb36:
  store i64 0, ptr %l88, !tbaa !24
  br label %bb37
bb37:
  %t140 = load i64, ptr %l88, !tbaa !24
  store i64 %t140, ptr %l85, !tbaa !24
  br label %bb38
bb38:
  %t141 = load i64, ptr %l85, !tbaa !24
  store i64 %t141, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb39
bb39:
  %t142 = load i64, ptr %l15, !tbaa !24
  %t143 = load i64, ptr %l14, !tbaa !24
  %t146 = icmp slt i64 %t142, %t143
  %t148 = xor i1 %t146, true
  br i1 %t148, label %bb40, label %bb41
bb40:
  br label %bb81
bb41:
  br label %bb42
bb42:
  %t150 = load i64, ptr %l11, !tbaa !24
  %t151 = load i64, ptr %l15, !tbaa !24
  %t152 = load i64, ptr %l13, !tbaa !24
  %t155 = mul i64 %t151, %t152
  %t158 = add i64 %t150, %t155
  store i64 %t158, ptr %l16, !tbaa !24
  %t160 = load ptr, ptr %l0, !tbaa !29
  %t162 = getelementptr %"compiler/effects:Effects", ptr %t160, i32 0, i32 12
  %t163 = load i64, ptr %l10, !tbaa !24
  %t166 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t162, i64 %t163)
  store i64 %t166, ptr %l109
  br label %bb43
bb43:
  %t167 = load i64, ptr %l16, !tbaa !24
  %t168 = load i64, ptr %l109, !tbaa !24
  %t170 = call i1 @compiler_2feffects_2ehasBit(i64 %t168, i64 %t167)
  store i1 %t170, ptr %l111
  br label %bb44
bb44:
  %t171 = load i1, ptr %l111, !tbaa !21
  %t172 = xor i1 %t171, true
  br i1 %t172, label %bb45, label %bb46
bb45:
  br label %bb80
bb46:
  br label %bb47
bb47:
  store i1 false, ptr %l17, !tbaa !21
  store ptr %l3, ptr %l18, !tbaa !29
  store i64 0, ptr %l19, !tbaa !24
  br label %bb48
bb48:
  %t175 = load i64, ptr %l19, !tbaa !24
  store i64 %t175, ptr %l114, !tbaa !24
  %t176 = load ptr, ptr %l18, !tbaa !29
  %t178 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3agiven_3e_2eLen_3ccompiler_2feffects_3agiven_3e(ptr %s0, ptr %t176)
  store i64 %t178, ptr %l116
  br label %bb49
bb49:
  %t179 = load i64, ptr %l114, !tbaa !24
  %t180 = load i64, ptr %l116, !tbaa !24
  %t181 = icmp slt i64 %t179, %t180
  %t183 = xor i1 %t181, true
  br i1 %t183, label %bb50, label %bb51
bb50:
  br label %bb73
bb51:
  br label %bb52
bb52:
  %t185 = load ptr, ptr %l18, !tbaa !29
  %t186 = load i64, ptr %l19, !tbaa !24
  %t189 = call %"compiler/effects:given" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3agiven_3e_2eAt_3ccompiler_2feffects_3agiven_3e(ptr %s0, ptr %s0, ptr %t185, i64 %t186)
  store %"compiler/effects:given" %t189, ptr %l121
  br label %bb53
bb53:
  %t190 = load %"compiler/effects:given", ptr %l121
  store %"compiler/effects:given" %t190, ptr %l20
  %t191 = getelementptr %"compiler/effects:given", ptr %l20, i32 0, i32 0
  %t192 = load i64, ptr %t191, !tbaa !24
  %t193 = load i64, ptr %l9, !tbaa !24
  %t196 = icmp ne i64 %t192, %t193
  br i1 %t196, label %bb54, label %bb55
bb54:
  store i1 true, ptr %l125, !tbaa !21
  br label %bb56
bb55:
  %t198 = getelementptr %"compiler/effects:given", ptr %l20, i32 0, i32 1
  %t199 = load i64, ptr %t198, !tbaa !24
  %t200 = load i64, ptr %l16, !tbaa !24
  %t203 = icmp ne i64 %t199, %t200
  store i1 %t203, ptr %l125, !tbaa !21
  br label %bb56
bb56:
  %t205 = load i1, ptr %l125, !tbaa !21
  br i1 %t205, label %bb57, label %bb58
bb57:
  br label %bb72
bb58:
  br label %bb59
bb59:
  store i1 true, ptr %l17, !tbaa !21
  %t206 = getelementptr %"compiler/effects:given", ptr %l20, i32 0, i32 2
  %t207 = load i64, ptr %t206, !tbaa !24
  %t208 = load i64, ptr @G_2ecompiler_2feffects_2eGivBound, !tbaa !24
  %t211 = icmp eq i64 %t207, %t208
  br i1 %t211, label %bb60, label %bb61
bb60:
  store i1 true, ptr %l132, !tbaa !21
  br label %bb66
bb61:
  %t213 = getelementptr %"compiler/effects:given", ptr %l20, i32 0, i32 2
  %t214 = load i64, ptr %t213, !tbaa !24
  %t215 = load i64, ptr @G_2ecompiler_2feffects_2eGivResult, !tbaa !24
  %t218 = icmp eq i64 %t214, %t215
  br i1 %t218, label %bb62, label %bb63
bb62:
  %t220 = load ptr, ptr %l0, !tbaa !29
  %t222 = getelementptr %"compiler/effects:Effects", ptr %t220, i32 0, i32 10
  %t223 = getelementptr %"compiler/effects:given", ptr %l20, i32 0, i32 3
  %t224 = load i64, ptr %t223, !tbaa !24
  %t227 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cI_Hbd09c84b003bb96b764c8a61b7f32193(ptr %v0, ptr %t222, i64 %t224)
  store i1 %t227, ptr %l140
  br label %bb64
bb63:
  store i1 false, ptr %l136, !tbaa !21
  br label %bb65
bb64:
  %t228 = load i1, ptr %l140, !tbaa !21
  %t229 = xor i1 %t228, true
  store i1 %t229, ptr %l136, !tbaa !21
  br label %bb65
bb65:
  %t231 = load i1, ptr %l136, !tbaa !21
  store i1 %t231, ptr %l132, !tbaa !21
  br label %bb66
bb66:
  %t232 = load i1, ptr %l132, !tbaa !21
  br i1 %t232, label %bb67, label %bb68
bb67:
  store %olang.scope zeroinitializer, ptr %s10
  store ptr %l2, ptr %l142, !tbaa !29
  %t233 = load ptr, ptr %l0, !tbaa !29
  %t235 = getelementptr %"compiler/effects:Effects", ptr %t233, i32 0, i32 0
  %t236 = load ptr, ptr %t235, !tbaa !29
  %t238 = getelementptr %"compiler/generic:Program", ptr %t236, i32 0, i32 2
  %t239 = getelementptr %"compiler/effects:given", ptr %l20, i32 0, i32 4
  %t240 = load i32, ptr %t239, !tbaa !23
  %t243 = call %"compiler/effects:Facts" @compiler_2feffects_2eFacts_2eBound(ptr %v0, ptr %t238, i32 %t240)
  store %"compiler/effects:Facts" %t243, ptr %l147
  br label %bb69
bb68:
  br label %bb71
bb69:
  %t244 = load ptr, ptr %l142, !tbaa !29
  call void @compiler_2feffects_2eMerge(ptr %s0, ptr %s10, ptr %t244, ptr %l147)
  br label %bb70
bb70:
  call void @__olang_scope_close(ptr %s10)
  br label %bb71
bb71:
  br label %bb72
bb72:
  %t246 = load i64, ptr %l19, !tbaa !24
  %t249 = add i64 %t246, 1
  store i64 %t249, ptr %l19, !tbaa !24
  br label %bb48
bb73:
  %t251 = load i1, ptr %l17, !tbaa !21
  %t253 = xor i1 %t251, true
  br i1 %t253, label %bb74, label %bb75
bb74:
  store %olang.scope zeroinitializer, ptr %s12
  store ptr %l2, ptr %l154, !tbaa !29
  %t255 = load ptr, ptr %l0, !tbaa !29
  %t257 = getelementptr %"compiler/effects:Effects", ptr %t255, i32 0, i32 0
  %t258 = load ptr, ptr %t257, !tbaa !29
  %t260 = getelementptr %"compiler/generic:Program", ptr %t258, i32 0, i32 2
  store ptr %t260, ptr %l157, !tbaa !29
  %t261 = load ptr, ptr %l0, !tbaa !29
  %t262 = load i64, ptr %l10, !tbaa !24
  %t263 = load i64, ptr %l16, !tbaa !24
  %t267 = call i32 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eslotType(ptr %v0, ptr %t261, i64 %t262, i64 %t263)
  store i32 %t267, ptr %l161
  br label %bb76
bb75:
  br label %bb79
bb76:
  %t268 = load ptr, ptr %l157, !tbaa !29
  %t269 = load i32, ptr %l161, !tbaa !23
  %t270 = call %"compiler/effects:Facts" @compiler_2feffects_2eFacts_2eBound(ptr %v0, ptr %t268, i32 %t269)
  store %"compiler/effects:Facts" %t270, ptr %l162
  br label %bb77
bb77:
  %t271 = load ptr, ptr %l154, !tbaa !29
  call void @compiler_2feffects_2eMerge(ptr %s0, ptr %s12, ptr %t271, ptr %l162)
  br label %bb78
bb78:
  call void @__olang_scope_close(ptr %s12)
  br label %bb79
bb79:
  br label %bb80
bb80:
  %t273 = load i64, ptr %l15, !tbaa !24
  %t276 = add i64 %t273, 1
  store i64 %t276, ptr %l15, !tbaa !24
  br label %bb39
bb81:
  br label %bb82
bb82:
  %t278 = load i64, ptr %l8, !tbaa !24
  %t281 = add i64 %t278, 1
  store i64 %t281, ptr %l8, !tbaa !24
  br label %bb16
bb83:
  %t283 = load %"compiler/effects:Facts", ptr %l2
  call void @__olang_scope_close(ptr %s0)
  store %"compiler/effects:Facts" %t283, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/effects:Facts", ptr %rv
  ret %"compiler/effects:Facts" %rr
}

define dso_local i1 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ebuilt(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i1
  %l6 = alloca ptr
  %l7 = alloca i1
  %l10 = alloca ptr
  %l11 = alloca i1
  %l14 = alloca ptr
  %l15 = alloca i1
  %l18 = alloca ptr
  %l19 = alloca i1
  %l22 = alloca ptr
  %l23 = alloca i1
  %l32 = alloca ptr
  %l33 = alloca i1
  %l40 = alloca i1
  %l41 = alloca ptr
  %l42 = alloca i1
  %l49 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l6, !tbaa !29
  store i1 false, ptr %l7, !tbaa !21
  %t2 = load ptr, ptr %l6, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l6, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 5
  store i1 %t8, ptr %l7, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l7, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb17
bb4:
  %t10 = load ptr, ptr %l1, !tbaa !29
  store ptr %t10, ptr %l10, !tbaa !29
  store i1 false, ptr %l11, !tbaa !21
  %t11 = load ptr, ptr %l10, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb5, label %bb6
bb5:
  %t14 = load ptr, ptr %l10, !tbaa !29
  %t15 = load i64, ptr %t14, !range !{i64 0, i64 18}
  %t17 = icmp eq i64 %t15, 8
  store i1 %t17, ptr %l11, !tbaa !21
  br label %bb6
bb6:
  %t18 = load i1, ptr %l11, !tbaa !21
  br i1 %t18, label %bb7, label %bb8
bb7:
  br label %bb17
bb8:
  %t19 = load ptr, ptr %l1, !tbaa !29
  store ptr %t19, ptr %l14, !tbaa !29
  store i1 false, ptr %l15, !tbaa !21
  %t20 = load ptr, ptr %l14, !tbaa !29
  %t21 = icmp ne ptr %t20, null
  br i1 %t21, label %bb9, label %bb10
bb9:
  %t23 = load ptr, ptr %l14, !tbaa !29
  %t24 = load i64, ptr %t23, !range !{i64 0, i64 18}
  %t26 = icmp eq i64 %t24, 16
  store i1 %t26, ptr %l15, !tbaa !21
  br label %bb10
bb10:
  %t27 = load i1, ptr %l15, !tbaa !21
  br i1 %t27, label %bb11, label %bb12
bb11:
  br label %bb17
bb12:
  %t28 = load ptr, ptr %l1, !tbaa !29
  store ptr %t28, ptr %l18, !tbaa !29
  store i1 false, ptr %l19, !tbaa !21
  %t29 = load ptr, ptr %l18, !tbaa !29
  %t30 = icmp ne ptr %t29, null
  br i1 %t30, label %bb13, label %bb14
bb13:
  %t32 = load ptr, ptr %l18, !tbaa !29
  %t33 = load i64, ptr %t32, !range !{i64 0, i64 18}
  %t35 = icmp eq i64 %t33, 0
  store i1 %t35, ptr %l19, !tbaa !21
  br label %bb14
bb14:
  %t36 = load i1, ptr %l19, !tbaa !21
  br i1 %t36, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb18
bb17:
  store i1 true, ptr %l5, !tbaa !21
  br label %bb43
bb18:
  %t37 = load ptr, ptr %l1, !tbaa !29
  store ptr %t37, ptr %l22, !tbaa !29
  store i1 false, ptr %l23, !tbaa !21
  %t38 = load ptr, ptr %l22, !tbaa !29
  %t39 = icmp ne ptr %t38, null
  br i1 %t39, label %bb19, label %bb20
bb19:
  %t41 = load ptr, ptr %l22, !tbaa !29
  %t42 = load i64, ptr %t41, !range !{i64 0, i64 18}
  %t44 = icmp eq i64 %t42, 7
  store i1 %t44, ptr %l23, !tbaa !21
  br label %bb20
bb20:
  %t45 = load i1, ptr %l23, !tbaa !21
  br i1 %t45, label %bb21, label %bb22
bb21:
  %t46 = load ptr, ptr %l1, !tbaa !29
  %t48 = getelementptr { i64, [5 x i64] }, ptr %t46, i32 0, i32 1
  %t49 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t48, i32 0, i32 2
  %t50 = load ptr, ptr %t49
  store ptr %t50, ptr %l2, !tbaa !29
  br label %bb23
bb22:
  br label %bb24
bb23:
  %t52 = load ptr, ptr %l2, !tbaa !29
  %t54 = getelementptr %"compiler/typed:Make", ptr %t52, i32 0, i32 4
  %t55 = load i32, ptr %t54, !tbaa !23
  %t57 = sext i32 %t55 to i64
  %t59 = icmp sge i64 %t57, 0
  store i1 %t59, ptr %l5, !tbaa !21
  br label %bb43
bb24:
  %t61 = load ptr, ptr %l1, !tbaa !29
  store ptr %t61, ptr %l32, !tbaa !29
  store i1 false, ptr %l33, !tbaa !21
  %t62 = load ptr, ptr %l32, !tbaa !29
  %t63 = icmp ne ptr %t62, null
  br i1 %t63, label %bb25, label %bb26
bb25:
  %t65 = load ptr, ptr %l32, !tbaa !29
  %t66 = load i64, ptr %t65, !range !{i64 0, i64 18}
  %t68 = icmp eq i64 %t66, 17
  store i1 %t68, ptr %l33, !tbaa !21
  br label %bb26
bb26:
  %t69 = load i1, ptr %l33, !tbaa !21
  br i1 %t69, label %bb27, label %bb28
bb27:
  %t70 = load ptr, ptr %l1, !tbaa !29
  %t72 = getelementptr { i64, [5 x i64] }, ptr %t70, i32 0, i32 1
  %t73 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t72, i32 0, i32 2
  %t74 = load ptr, ptr %t73
  store ptr %t74, ptr %l3, !tbaa !29
  br label %bb29
bb28:
  br label %bb31
bb29:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t77 = load ptr, ptr %l3, !tbaa !29
  %t80 = call i1 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ebuilt(ptr %v0, ptr %v1, ptr %t76, ptr %t77)
  store i1 %t80, ptr %l40
  br label %bb30
bb30:
  %t81 = load i1, ptr %l40, !tbaa !21
  store i1 %t81, ptr %l5, !tbaa !21
  br label %bb43
bb31:
  %t82 = load ptr, ptr %l1, !tbaa !29
  store ptr %t82, ptr %l41, !tbaa !29
  store i1 false, ptr %l42, !tbaa !21
  %t83 = load ptr, ptr %l41, !tbaa !29
  %t84 = icmp ne ptr %t83, null
  br i1 %t84, label %bb32, label %bb33
bb32:
  %t86 = load ptr, ptr %l41, !tbaa !29
  %t87 = load i64, ptr %t86, !range !{i64 0, i64 18}
  %t89 = icmp eq i64 %t87, 6
  store i1 %t89, ptr %l42, !tbaa !21
  br label %bb33
bb33:
  %t90 = load i1, ptr %l42, !tbaa !21
  br i1 %t90, label %bb34, label %bb35
bb34:
  %t91 = load ptr, ptr %l1, !tbaa !29
  %t93 = getelementptr { i64, [5 x i64] }, ptr %t91, i32 0, i32 1
  %t94 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t93, i32 0, i32 2
  %t95 = load ptr, ptr %t94
  store ptr %t95, ptr %l4, !tbaa !29
  br label %bb36
bb35:
  br label %bb38
bb36:
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t98 = load ptr, ptr %l4, !tbaa !29
  %t101 = call i1 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ectorCall(ptr %v0, ptr %v1, ptr %t97, ptr %t98)
  store i1 %t101, ptr %l49
  br label %bb37
bb37:
  %t102 = load i1, ptr %l49, !tbaa !21
  store i1 %t102, ptr %l5, !tbaa !21
  br label %bb43
bb38:
  br i1 true, label %bb39, label %bb40
bb39:
  br label %bb41
bb40:
  br label %bb42
bb41:
  store i1 false, ptr %l5, !tbaa !21
  br label %bb43
bb42:
  call void @__olang_check_failed(ptr @olang_loc_f7c8ab04542d2f7e_3025df788b022d62)
  unreachable
bb43:
  %t103 = load i1, ptr %l5, !tbaa !21
  store i1 %t103, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2edefine(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i64
  %l6 = alloca i32
  %l9 = alloca i1
  %l13 = alloca i1
  %l16 = alloca ptr
  %l17 = alloca i64
  %l18 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l19 = alloca ptr
  %l23 = alloca ptr
  %l24 = alloca i32
  %l29 = alloca i1
  %l33 = alloca i1
  %l36 = alloca ptr
  %l37 = alloca i64
  %l38 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l39 = alloca ptr
  %l43 = alloca ptr
  %l44 = alloca i32
  %l51 = alloca i1
  %l52 = alloca i1
  %l57 = alloca i1
  %l61 = alloca i64
  %l65 = alloca ptr
  %l66 = alloca i64
  %l67 = alloca i64
  %l68 = alloca i64
  %l72 = alloca i64
  %l73 = alloca i32
  %l78 = alloca ptr
  %l80 = alloca i64
  %l83 = alloca i1
  %l84 = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t1)
  store i32 %t3, ptr %l6
  br label %bb1
bb1:
  %t4 = load i32, ptr %l6, !tbaa !23
  store i32 %t4, ptr %l3, !tbaa !23
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t6 = load i32, ptr %l3, !tbaa !23
  %t9 = call i1 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eisFn(ptr %v0, ptr %t5, i32 %t6)
  store i1 %t9, ptr %l9
  br label %bb2
bb2:
  %t10 = load i1, ptr %l9, !tbaa !21
  br i1 %t10, label %bb3, label %bb4
bb3:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/effects:Effects", ptr %t11, i32 0, i32 39
  %t14 = load i64, ptr %l1, !tbaa !24
  %t17 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cc_H812d4871fea5544bd17001c04038a9fe(ptr %v0, ptr %t13, i64 %t14)
  store i1 %t17, ptr %l13
  br label %bb5
bb4:
  br label %bb17
bb5:
  %t18 = load i1, ptr %l13, !tbaa !21
  %t19 = xor i1 %t18, true
  br i1 %t19, label %bb6, label %bb7
bb6:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/effects:Effects", ptr %t21, i32 0, i32 39
  store ptr %t23, ptr %l16, !tbaa !29
  %t24 = load i64, ptr %l1, !tbaa !24
  store i64 %t24, ptr %l17, !tbaa !24
  %t25 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t25, ptr %l18
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t26 = load ptr, ptr %l16, !tbaa !29
  %t27 = load i64, ptr %l17, !tbaa !24
  %t28 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l18
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cc_Hc680bc8b736298027ff580de04f60380(ptr %v0, ptr %v0, ptr %t26, i64 %t27, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t28)
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/effects:Effects", ptr %t29, i32 0, i32 39
  %t32 = load i64, ptr %l1, !tbaa !24
  %t35 = call { i32, ptr } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cc_Hfb9e5165fbc860148668cf342d052cc0(ptr %v0, ptr %v0, ptr %t31, i64 %t32)
  %t36 = extractvalue { i32, ptr } %t35, 1
  %t37 = extractvalue { i32, ptr } %t35, 0
  store i32 %t37, ptr %l24
  %t38 = icmp ne i32 %t37, 0
  br i1 %t38, label %bb12, label %ok.39, !prof !99
ok.39:
  store ptr %t36, ptr %l23
  br label %bb11
bb11:
  %t40 = load ptr, ptr %l23, !tbaa !29
  store ptr %t40, ptr %l19, !tbaa !29
  br label %bb15
bb12:
  %t41 = load i32, ptr %l24, !tbaa !23
  %t42 = icmp eq i32 %t41, 65536
  br i1 %t42, label %bb13, label %bb14
bb13:
  call void @__olang_bang_failed_plain(ptr @olang_loc_12d41178ea699117_cd5c06b5e62ab993)
  unreachable
bb14:
  call void @__olang_bang_failed_plain(ptr @olang_loc_bfb31f4e096fcfdd_9eff6572189cd471)
  unreachable
bb15:
  %t44 = load ptr, ptr %l2, !tbaa !29
  %t45 = load ptr, ptr %l19, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %t45, ptr %t44)
  br label %bb16
bb16:
  br label %ret
bb17:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t48 = load i32, ptr %l3, !tbaa !23
  %t51 = call i1 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2einstType(ptr %v0, ptr %t47, i32 %t48)
  store i1 %t51, ptr %l29
  br label %bb18
bb18:
  %t52 = load i1, ptr %l29, !tbaa !21
  br i1 %t52, label %bb19, label %bb20
bb19:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/effects:Effects", ptr %t53, i32 0, i32 66
  %t56 = load i64, ptr %l1, !tbaa !24
  %t59 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cc_H812d4871fea5544bd17001c04038a9fe(ptr %v0, ptr %t55, i64 %t56)
  store i1 %t59, ptr %l33
  br label %bb21
bb20:
  br label %bb33
bb21:
  %t60 = load i1, ptr %l33, !tbaa !21
  %t61 = xor i1 %t60, true
  br i1 %t61, label %bb22, label %bb23
bb22:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/effects:Effects", ptr %t63, i32 0, i32 66
  store ptr %t65, ptr %l36, !tbaa !29
  %t66 = load i64, ptr %l1, !tbaa !24
  store i64 %t66, ptr %l37, !tbaa !24
  %t67 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t67, ptr %l38
  br label %bb24
bb23:
  br label %bb26
bb24:
  %t68 = load ptr, ptr %l36, !tbaa !29
  %t69 = load i64, ptr %l37, !tbaa !24
  %t70 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l38
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cc_Hc680bc8b736298027ff580de04f60380(ptr %v0, ptr %v0, ptr %t68, i64 %t69, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t70)
  br label %bb25
bb25:
  br label %bb26
bb26:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/effects:Effects", ptr %t71, i32 0, i32 66
  %t74 = load i64, ptr %l1, !tbaa !24
  %t77 = call { i32, ptr } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cc_Hfb9e5165fbc860148668cf342d052cc0(ptr %v0, ptr %v0, ptr %t73, i64 %t74)
  %t78 = extractvalue { i32, ptr } %t77, 1
  %t79 = extractvalue { i32, ptr } %t77, 0
  store i32 %t79, ptr %l44
  %t80 = icmp ne i32 %t79, 0
  br i1 %t80, label %bb28, label %ok.81, !prof !99
ok.81:
  store ptr %t78, ptr %l43
  br label %bb27
bb27:
  %t82 = load ptr, ptr %l43, !tbaa !29
  store ptr %t82, ptr %l39, !tbaa !29
  br label %bb31
bb28:
  %t83 = load i32, ptr %l44, !tbaa !23
  %t84 = icmp eq i32 %t83, 65536
  br i1 %t84, label %bb29, label %bb30
bb29:
  call void @__olang_bang_failed_plain(ptr @olang_loc_bdb589e9fb60a385_99895746a144f341)
  unreachable
bb30:
  call void @__olang_bang_failed_plain(ptr @olang_loc_6c2f84c28d80f803_c1ff4c3310f9a27)
  unreachable
bb31:
  %t86 = load ptr, ptr %l2, !tbaa !29
  %t87 = load ptr, ptr %l39, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %t87, ptr %t86)
  br label %bb32
bb32:
  br label %bb33
bb33:
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr %"compiler/effects:Effects", ptr %t89, i32 0, i32 0
  %t92 = load ptr, ptr %t91, !tbaa !29
  %t94 = getelementptr %"compiler/generic:Program", ptr %t92, i32 0, i32 2
  %t95 = load i32, ptr %l3, !tbaa !23
  %t98 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t94, i32 %t95)
  store i1 %t98, ptr %l51
  br label %bb34
bb34:
  %t99 = load i1, ptr %l51, !tbaa !21
  br i1 %t99, label %bb35, label %bb36
bb35:
  store i1 true, ptr %l52, !tbaa !21
  br label %bb38
bb36:
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t102 = getelementptr %"compiler/effects:Effects", ptr %t100, i32 0, i32 0
  %t103 = load ptr, ptr %t102, !tbaa !29
  %t105 = getelementptr %"compiler/generic:Program", ptr %t103, i32 0, i32 2
  %t106 = load i32, ptr %l3, !tbaa !23
  %t109 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %t105, i32 %t106)
  store i1 %t109, ptr %l57
  br label %bb37
bb37:
  %t110 = load i1, ptr %l57, !tbaa !21
  store i1 %t110, ptr %l52, !tbaa !21
  br label %bb38
bb38:
  %t111 = load i1, ptr %l52, !tbaa !21
  %t112 = xor i1 %t111, true
  br i1 %t112, label %bb39, label %bb40
bb39:
  br label %ret
bb40:
  br label %bb41
bb41:
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t115 = load ptr, ptr %l2, !tbaa !29
  %t118 = call i64 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2erootBits(ptr %v0, ptr %v1, ptr %t114, ptr %t115, i64 0)
  store i64 %t118, ptr %l61
  br label %bb42
bb42:
  %t119 = load i64, ptr %l61, !tbaa !24
  store i64 %t119, ptr %l4, !tbaa !24
  %t120 = load i64, ptr %l4, !tbaa !24
  %t122 = icmp ne i64 %t120, 0
  br i1 %t122, label %bb43, label %bb44
bb43:
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t126 = getelementptr %"compiler/effects:Effects", ptr %t124, i32 0, i32 32
  store ptr %t126, ptr %l65, !tbaa !29
  %t127 = load i64, ptr %l1, !tbaa !24
  store i64 %t127, ptr %l66, !tbaa !24
  %t128 = load i64, ptr %l4, !tbaa !24
  store i64 %t128, ptr %l67, !tbaa !24
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t131 = getelementptr %"compiler/effects:Effects", ptr %t129, i32 0, i32 32
  %t132 = load i64, ptr %l1, !tbaa !24
  %t135 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t131, i64 %t132)
  %t136 = extractvalue { i32, i64 } %t135, 1
  %t137 = extractvalue { i32, i64 } %t135, 0
  store i32 %t137, ptr %l73
  %t138 = icmp ne i32 %t137, 0
  br i1 %t138, label %bb46, label %ok.139, !prof !99
ok.139:
  store i64 %t136, ptr %l72
  br label %bb45
bb44:
  br label %bb50
bb45:
  %t140 = load i64, ptr %l72, !tbaa !24
  store i64 %t140, ptr %l68, !tbaa !24
  br label %bb48
bb46:
  br label %bb47
bb47:
  store i64 0, ptr %l68, !tbaa !24
  br label %bb48
bb48:
  %t141 = load i64, ptr %l67, !tbaa !24
  %t142 = load i64, ptr %l68, !tbaa !24
  %t143 = or i64 %t141, %t142
  %t144 = load ptr, ptr %l65, !tbaa !29
  %t145 = load i64, ptr %l66, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t144, i64 %t145, i64 %t143)
  br label %bb49
bb49:
  br label %bb50
bb50:
  %t147 = load ptr, ptr %l0, !tbaa !29
  %t149 = getelementptr %"compiler/effects:Effects", ptr %t147, i32 0, i32 2
  %t150 = load i1, ptr %t149, !tbaa !21
  br i1 %t150, label %bb51, label %bb52
bb51:
  %t152 = load ptr, ptr %l0, !tbaa !29
  %t154 = getelementptr %"compiler/effects:Effects", ptr %t152, i32 0, i32 41
  store ptr %t154, ptr %l78, !tbaa !29
  %t155 = load i64, ptr %l1, !tbaa !24
  %t157 = mul i64 2, %t155
  store i64 %t157, ptr %l80, !tbaa !24
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t159 = load ptr, ptr %l2, !tbaa !29
  %t162 = call i1 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ebuilt(ptr %v0, ptr %v1, ptr %t158, ptr %t159)
  store i1 %t162, ptr %l83
  br label %bb53
bb52:
  br label %bb58
bb53:
  %t163 = load i1, ptr %l83, !tbaa !21
  br i1 %t163, label %bb54, label %bb55
bb54:
  store i64 1, ptr %l84, !tbaa !24
  br label %bb56
bb55:
  store i64 0, ptr %l84, !tbaa !24
  br label %bb56
bb56:
  %t164 = load i64, ptr %l80, !tbaa !24
  %t165 = load i64, ptr %l84, !tbaa !24
  %t166 = add i64 %t164, %t165
  %t167 = load ptr, ptr %l78, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t167, i64 %t166)
  br label %bb57
bb57:
  br label %bb58
bb58:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2edropsCalled(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i32
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l19 = alloca i1
  %l24 = alloca i1
  %l25 = alloca i1
  %l30 = alloca i1
  %l36 = alloca i32
  %l41 = alloca i32
  %l48 = alloca i1
  %l53 = alloca ptr
  %l58 = alloca i32
  %l59 = alloca i32
  %l64 = alloca ptr
  %l69 = alloca i32
  %l70 = alloca { i64, ptr }
  %l77 = alloca { i64, ptr }
  %l89 = alloca ptr
  %l94 = alloca i32
  %l95 = alloca { i64, ptr }
  %l102 = alloca { i64, ptr }
  %l120 = alloca ptr
  %l125 = alloca i32
  %l126 = alloca { i64, ptr }
  %l133 = alloca { i64, ptr }
  %l145 = alloca ptr
  %l150 = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l2, !tbaa !24
  %t3 = icmp sgt i64 %t1, 16
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l19, !tbaa !21
  br label %bb4
bb2:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/effects:Effects", ptr %t5, i32 0, i32 0
  %t8 = load ptr, ptr %t7, !tbaa !29
  %t10 = getelementptr %"compiler/generic:Program", ptr %t8, i32 0, i32 2
  %t11 = load i32, ptr %l1, !tbaa !23
  %t14 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t10, i32 %t11)
  store i1 %t14, ptr %l24
  br label %bb3
bb3:
  %t15 = load i1, ptr %l24, !tbaa !21
  store i1 %t15, ptr %l19, !tbaa !21
  br label %bb4
bb4:
  %t16 = load i1, ptr %l19, !tbaa !21
  br i1 %t16, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l25, !tbaa !21
  br label %bb8
bb6:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/effects:Effects", ptr %t17, i32 0, i32 0
  %t20 = load ptr, ptr %t19, !tbaa !29
  %t22 = getelementptr %"compiler/generic:Program", ptr %t20, i32 0, i32 2
  %t23 = load i32, ptr %l1, !tbaa !23
  %t26 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNeedsDrop(ptr %v0, ptr %t22, i32 %t23)
  store i1 %t26, ptr %l30
  br label %bb7
bb7:
  %t27 = load i1, ptr %l30, !tbaa !21
  %t28 = xor i1 %t27, true
  store i1 %t28, ptr %l25, !tbaa !21
  br label %bb8
bb8:
  %t30 = load i1, ptr %l25, !tbaa !21
  br i1 %t30, label %bb9, label %bb10
bb9:
  br label %ret
bb10:
  br label %bb11
bb11:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/effects:Effects", ptr %t31, i32 0, i32 0
  %t34 = load ptr, ptr %t33, !tbaa !29
  %t36 = getelementptr %"compiler/generic:Program", ptr %t34, i32 0, i32 2
  %t37 = load i32, ptr %l1, !tbaa !23
  %t40 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t36, i32 %t37)
  store i32 %t40, ptr %l36
  br label %bb12
bb12:
  %t41 = load i32, ptr %l36, !tbaa !23
  store i32 %t41, ptr %l3, !tbaa !23
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/effects:Effects", ptr %t42, i32 0, i32 0
  %t45 = load ptr, ptr %t44, !tbaa !29
  %t47 = getelementptr %"compiler/generic:Program", ptr %t45, i32 0, i32 2
  %t48 = load i32, ptr %l3, !tbaa !23
  %t51 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t47, i32 %t48)
  store i32 %t51, ptr %l41
  br label %bb13
bb13:
  %t52 = load i32, ptr %l41, !range !{i32 0, i32 33}
  store i32 %t52, ptr %l4
  %t53 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t55 = trunc i64 18 to i32
  %t56 = icmp eq i32 %t53, %t55
  br i1 %t56, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb48
bb16:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/effects:Effects", ptr %t58, i32 0, i32 0
  %t61 = load ptr, ptr %t60, !tbaa !29
  %t63 = getelementptr %"compiler/generic:Program", ptr %t61, i32 0, i32 2
  %t64 = load i32, ptr %l3, !tbaa !23
  %t67 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDestructs(ptr %v0, ptr %t63, i32 %t64)
  store i1 %t67, ptr %l48
  br label %bb17
bb17:
  %t68 = load i1, ptr %l48, !tbaa !21
  br i1 %t68, label %bb18, label %bb19
bb18:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t70 = load i32, ptr %l3, !tbaa !23
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2edtorCalled(ptr %v0, ptr %t69, i32 %t70)
  br label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb21
bb21:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/effects:Effects", ptr %t73, i32 0, i32 0
  %t76 = load ptr, ptr %t75, !tbaa !29
  %t78 = getelementptr %"compiler/generic:Program", ptr %t76, i32 0, i32 2
  store ptr %t78, ptr %l53, !tbaa !29
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/effects:Effects", ptr %t79, i32 0, i32 0
  %t82 = load ptr, ptr %t81, !tbaa !29
  %t84 = getelementptr %"compiler/generic:Program", ptr %t82, i32 0, i32 2
  %t85 = load i32, ptr %l3, !tbaa !23
  %t88 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t84, i32 %t85)
  store i32 %t88, ptr %l58
  br label %bb22
bb22:
  %t89 = load ptr, ptr %l53, !tbaa !29
  %t90 = load i32, ptr %l58, !tbaa !23
  %t91 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t89, i32 %t90)
  store i32 %t91, ptr %l59
  br label %bb23
bb23:
  %t92 = load i32, ptr %l59, !range !{i32 0, i32 6}
  %t94 = trunc i64 0 to i32
  %t95 = icmp eq i32 %t92, %t94
  br i1 %t95, label %bb24, label %bb25
bb24:
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = getelementptr %"compiler/effects:Effects", ptr %t97, i32 0, i32 0
  %t100 = load ptr, ptr %t99, !tbaa !29
  %t102 = getelementptr %"compiler/generic:Program", ptr %t100, i32 0, i32 2
  store ptr %t102, ptr %l64, !tbaa !29
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t105 = getelementptr %"compiler/effects:Effects", ptr %t103, i32 0, i32 0
  %t106 = load ptr, ptr %t105, !tbaa !29
  %t108 = getelementptr %"compiler/generic:Program", ptr %t106, i32 0, i32 2
  %t109 = load i32, ptr %l3, !tbaa !23
  %t112 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t108, i32 %t109)
  store i32 %t112, ptr %l69
  br label %bb26
bb25:
  br label %bb35
bb26:
  %t113 = load ptr, ptr %l64, !tbaa !29
  %t114 = load i32, ptr %l69, !tbaa !23
  %t115 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t113, i32 %t114)
  store { i64, ptr } %t115, ptr %l70
  br label %bb27
bb27:
  %t116 = load { i64, ptr }, ptr %l70, !tbaa !27
  store { i64, ptr } %t116, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t117 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t119 = extractvalue { i64, ptr } %t117, 0
  store i64 %t119, ptr %l7, !tbaa !24
  br label %bb28
bb28:
  %t121 = load i64, ptr %l6, !tbaa !24
  %t122 = load i64, ptr %l7, !tbaa !24
  %t125 = icmp slt i64 %t121, %t122
  %t127 = xor i1 %t125, true
  br i1 %t127, label %bb29, label %bb30
bb29:
  br label %bb34
bb30:
  br label %bb31
bb31:
  %t129 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t129, ptr %l77, !tbaa !27
  %t130 = load i64, ptr %l6, !tbaa !24
  %t132 = getelementptr { i64, ptr }, ptr %l77, i32 0, i32 1
  %t133 = load ptr, ptr %t132, !tbaa !27
  %t134 = getelementptr i32, ptr %t133, i64 %t130
  %t135 = load i32, ptr %t134, !tbaa !33
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t139 = load i64, ptr %l2, !tbaa !24
  %t141 = add i64 %t139, 1
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2edropsCalled(ptr %v0, ptr %t137, i32 %t135, i64 %t141)
  br label %bb32
bb32:
  br label %bb33
bb33:
  %t145 = load i64, ptr %l6, !tbaa !24
  %t148 = add i64 %t145, 1
  store i64 %t148, ptr %l6, !tbaa !24
  br label %bb28
bb34:
  br label %ret
bb35:
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t152 = getelementptr %"compiler/effects:Effects", ptr %t150, i32 0, i32 0
  %t153 = load ptr, ptr %t152, !tbaa !29
  %t155 = getelementptr %"compiler/generic:Program", ptr %t153, i32 0, i32 2
  store ptr %t155, ptr %l89, !tbaa !29
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t158 = getelementptr %"compiler/effects:Effects", ptr %t156, i32 0, i32 0
  %t159 = load ptr, ptr %t158, !tbaa !29
  %t161 = getelementptr %"compiler/generic:Program", ptr %t159, i32 0, i32 2
  %t162 = load i32, ptr %l3, !tbaa !23
  %t165 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %t161, i32 %t162)
  store i32 %t165, ptr %l94
  br label %bb36
bb36:
  %t166 = load ptr, ptr %l89, !tbaa !29
  %t167 = load i32, ptr %l94, !tbaa !23
  %t168 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t166, i32 %t167)
  store { i64, ptr } %t168, ptr %l95
  br label %bb37
bb37:
  %t169 = load { i64, ptr }, ptr %l95, !tbaa !27
  store { i64, ptr } %t169, ptr %l9, !tbaa !27
  store i64 0, ptr %l10, !tbaa !24
  %t170 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t172 = extractvalue { i64, ptr } %t170, 0
  store i64 %t172, ptr %l11, !tbaa !24
  br label %bb38
bb38:
  %t174 = load i64, ptr %l10, !tbaa !24
  %t175 = load i64, ptr %l11, !tbaa !24
  %t178 = icmp slt i64 %t174, %t175
  %t180 = xor i1 %t178, true
  br i1 %t180, label %bb39, label %bb40
bb39:
  br label %bb47
bb40:
  br label %bb41
bb41:
  %t182 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t182, ptr %l102, !tbaa !27
  %t183 = load i64, ptr %l10, !tbaa !24
  %t185 = getelementptr { i64, ptr }, ptr %l102, i32 0, i32 1
  %t186 = load ptr, ptr %t185, !tbaa !27
  %t187 = getelementptr i32, ptr %t186, i64 %t183
  %t188 = load i32, ptr %t187, !tbaa !33
  store i32 %t188, ptr %l12, !tbaa !23
  %t190 = load i32, ptr %l12, !tbaa !23
  %t192 = icmp ne i32 %t190, 0
  br i1 %t192, label %bb42, label %bb43
bb42:
  %t194 = load ptr, ptr %l0, !tbaa !29
  %t195 = load i32, ptr %l12, !tbaa !23
  %t196 = load i64, ptr %l2, !tbaa !24
  %t198 = add i64 %t196, 1
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2edropsCalled(ptr %v0, ptr %t194, i32 %t195, i64 %t198)
  br label %bb44
bb43:
  br label %bb45
bb44:
  br label %bb45
bb45:
  br label %bb46
bb46:
  %t202 = load i64, ptr %l10, !tbaa !24
  %t205 = add i64 %t202, 1
  store i64 %t205, ptr %l10, !tbaa !24
  br label %bb38
bb47:
  br label %bb74
bb48:
  %t207 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t209 = trunc i64 23 to i32
  %t210 = icmp eq i32 %t207, %t209
  br i1 %t210, label %bb49, label %bb50
bb49:
  br label %bb53
bb50:
  %t212 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t214 = trunc i64 22 to i32
  %t215 = icmp eq i32 %t212, %t214
  br i1 %t215, label %bb51, label %bb52
bb51:
  br label %bb53
bb52:
  br label %bb63
bb53:
  %t217 = load ptr, ptr %l0, !tbaa !29
  %t219 = getelementptr %"compiler/effects:Effects", ptr %t217, i32 0, i32 0
  %t220 = load ptr, ptr %t219, !tbaa !29
  %t222 = getelementptr %"compiler/generic:Program", ptr %t220, i32 0, i32 2
  store ptr %t222, ptr %l120, !tbaa !29
  %t223 = load ptr, ptr %l0, !tbaa !29
  %t225 = getelementptr %"compiler/effects:Effects", ptr %t223, i32 0, i32 0
  %t226 = load ptr, ptr %t225, !tbaa !29
  %t228 = getelementptr %"compiler/generic:Program", ptr %t226, i32 0, i32 2
  %t229 = load i32, ptr %l3, !tbaa !23
  %t232 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t228, i32 %t229)
  store i32 %t232, ptr %l125
  br label %bb54
bb54:
  %t233 = load ptr, ptr %l120, !tbaa !29
  %t234 = load i32, ptr %l125, !tbaa !23
  %t235 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t233, i32 %t234)
  store { i64, ptr } %t235, ptr %l126
  br label %bb55
bb55:
  %t236 = load { i64, ptr }, ptr %l126, !tbaa !27
  store { i64, ptr } %t236, ptr %l13, !tbaa !27
  store i64 0, ptr %l14, !tbaa !24
  %t237 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t239 = extractvalue { i64, ptr } %t237, 0
  store i64 %t239, ptr %l15, !tbaa !24
  br label %bb56
bb56:
  %t241 = load i64, ptr %l14, !tbaa !24
  %t242 = load i64, ptr %l15, !tbaa !24
  %t245 = icmp slt i64 %t241, %t242
  %t247 = xor i1 %t245, true
  br i1 %t247, label %bb57, label %bb58
bb57:
  br label %bb62
bb58:
  br label %bb59
bb59:
  %t249 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t249, ptr %l133, !tbaa !27
  %t250 = load i64, ptr %l14, !tbaa !24
  %t252 = getelementptr { i64, ptr }, ptr %l133, i32 0, i32 1
  %t253 = load ptr, ptr %t252, !tbaa !27
  %t254 = getelementptr i32, ptr %t253, i64 %t250
  %t255 = load i32, ptr %t254, !tbaa !33
  %t257 = load ptr, ptr %l0, !tbaa !29
  %t259 = load i64, ptr %l2, !tbaa !24
  %t261 = add i64 %t259, 1
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2edropsCalled(ptr %v0, ptr %t257, i32 %t255, i64 %t261)
  br label %bb60
bb60:
  br label %bb61
bb61:
  %t265 = load i64, ptr %l14, !tbaa !24
  %t268 = add i64 %t265, 1
  store i64 %t268, ptr %l14, !tbaa !24
  br label %bb56
bb62:
  br label %bb74
bb63:
  %t270 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t272 = trunc i64 19 to i32
  %t273 = icmp eq i32 %t270, %t272
  br i1 %t273, label %bb64, label %bb65
bb64:
  br label %bb66
bb65:
  br label %bb69
bb66:
  %t275 = load ptr, ptr %l0, !tbaa !29
  store ptr %t275, ptr %l145, !tbaa !29
  %t276 = load ptr, ptr %l0, !tbaa !29
  %t278 = getelementptr %"compiler/effects:Effects", ptr %t276, i32 0, i32 0
  %t279 = load ptr, ptr %t278, !tbaa !29
  %t281 = getelementptr %"compiler/generic:Program", ptr %t279, i32 0, i32 2
  %t282 = load i32, ptr %l3, !tbaa !23
  %t285 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t281, i32 %t282)
  store i32 %t285, ptr %l150
  br label %bb67
bb67:
  %t286 = load i64, ptr %l2, !tbaa !24
  %t288 = add i64 %t286, 1
  %t289 = load ptr, ptr %l145, !tbaa !29
  %t290 = load i32, ptr %l150, !tbaa !23
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2edropsCalled(ptr %v0, ptr %t289, i32 %t290, i64 %t288)
  br label %bb68
bb68:
  br label %bb74
bb69:
  br i1 true, label %bb70, label %bb71
bb70:
  br label %bb72
bb71:
  br label %bb73
bb72:
  br label %bb74
bb73:
  call void @__olang_check_failed(ptr @olang_loc_a95aecd22ff58df7_af716a2d87a126b3)
  unreachable
bb74:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2edtorCalled(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i32
  %l11 = alloca i64
  %l13 = alloca ptr
  %l18 = alloca i32
  %l19 = alloca i64
  %l20 = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/effects:Effects", ptr %t1, i32 0, i32 56
  %t4 = load i32, ptr %l1, !tbaa !23
  %t7 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e__H165e1ff795edcbb725e28dde18fd1dc2(ptr %v0, ptr %t3, i32 %t4)
  %t8 = extractvalue { i32, i64 } %t7, 1
  %t9 = extractvalue { i32, i64 } %t7, 0
  store i32 %t9, ptr %l8
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb2, label %ok.11, !prof !99
ok.11:
  store i64 %t8, ptr %l7
  br label %bb1
bb1:
  %t12 = load i64, ptr %l7, !tbaa !24
  store i64 %t12, ptr %l3, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  store i64 -1, ptr %l3, !tbaa !24
  br label %bb4
bb4:
  %t13 = load i64, ptr %l3, !tbaa !24
  store i64 %t13, ptr %l2, !tbaa !24
  %t14 = load i64, ptr %l2, !tbaa !24
  %t16 = icmp slt i64 %t14, 0
  br i1 %t16, label %bb5, label %bb6
bb5:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/effects:Effects", ptr %t18, i32 0, i32 56
  store ptr %t20, ptr %l13, !tbaa !29
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/effects:Effects", ptr %t21, i32 0, i32 0
  %t24 = load ptr, ptr %t23, !tbaa !29
  %t26 = getelementptr %"compiler/generic:Program", ptr %t24, i32 0, i32 2
  %t27 = load i32, ptr %l1, !tbaa !23
  %t30 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t26, i32 %t27)
  store i32 %t30, ptr %l18
  br label %bb7
bb6:
  br label %bb12
bb7:
  %t31 = load ptr, ptr %l13, !tbaa !29
  %t32 = load i32, ptr %l18, !tbaa !23
  %t33 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e__H165e1ff795edcbb725e28dde18fd1dc2(ptr %v0, ptr %t31, i32 %t32)
  %t34 = extractvalue { i32, i64 } %t33, 1
  %t35 = extractvalue { i32, i64 } %t33, 0
  store i32 %t35, ptr %l20
  %t36 = icmp ne i32 %t35, 0
  br i1 %t36, label %bb9, label %ok.37, !prof !99
ok.37:
  store i64 %t34, ptr %l19
  br label %bb8
bb8:
  %t38 = load i64, ptr %l19, !tbaa !24
  store i64 %t38, ptr %l11, !tbaa !24
  br label %bb11
bb9:
  br label %bb10
bb10:
  store i64 -1, ptr %l11, !tbaa !24
  br label %bb11
bb11:
  %t39 = load i64, ptr %l11, !tbaa !24
  store i64 %t39, ptr %l2, !tbaa !24
  br label %bb12
bb12:
  %t40 = load i64, ptr %l2, !tbaa !24
  %t42 = icmp sge i64 %t40, 0
  br i1 %t42, label %bb13, label %bb14
bb13:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/effects:Effects", ptr %t44, i32 0, i32 26
  %t47 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t46, i64 %t47)
  br label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb16
bb16:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eexpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca i32
  %l15 = alloca ptr
  %l16 = alloca i32
  %l17 = alloca ptr
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca i64
  %l22 = alloca i32
  %l23 = alloca { i64, ptr }
  %l24 = alloca ptr
  %l25 = alloca ptr
  %l26 = alloca ptr
  %l27 = alloca { i64, ptr }
  %l28 = alloca i64
  %l29 = alloca i64
  %l31 = alloca ptr
  %l32 = alloca { i64, ptr }
  %l33 = alloca i64
  %l34 = alloca i64
  %l36 = alloca { i64, ptr }
  %l37 = alloca i64
  %l38 = alloca i64
  %l40 = alloca ptr
  %l41 = alloca { i64, ptr }
  %l42 = alloca i64
  %l43 = alloca i64
  %l45 = alloca ptr
  %l46 = alloca ptr
  %l49 = alloca ptr
  %l50 = alloca i1
  %l53 = alloca ptr
  %l54 = alloca i1
  %l57 = alloca ptr
  %l58 = alloca i1
  %l70 = alloca ptr
  %l71 = alloca i1
  %l76 = alloca ptr
  %l77 = alloca i1
  %l84 = alloca ptr
  %l85 = alloca i1
  %l97 = alloca i1
  %l98 = alloca ptr
  %l103 = alloca i32
  %l108 = alloca ptr
  %l109 = alloca i1
  %l123 = alloca { i64, ptr }
  %l126 = alloca ptr
  %l127 = alloca i1
  %l138 = alloca ptr
  %l139 = alloca i1
  %l152 = alloca ptr
  %l153 = alloca i1
  %l167 = alloca i1
  %l168 = alloca i1
  %l174 = alloca i1
  %l179 = alloca ptr
  %l180 = alloca i1
  %l191 = alloca i1
  %l195 = alloca i1
  %l209 = alloca { i64, ptr }
  %l218 = alloca ptr
  %l219 = alloca i1
  %l229 = alloca ptr
  %l230 = alloca i1
  %l246 = alloca ptr
  %l247 = alloca i1
  %l263 = alloca ptr
  %l264 = alloca i1
  %l277 = alloca { i64, ptr }
  %l288 = alloca ptr
  %l289 = alloca i1
  %l302 = alloca { i64, ptr }
  %l318 = alloca { i64, ptr }
  %l330 = alloca ptr
  %l336 = alloca ptr
  %l337 = alloca i1
  %l356 = alloca { i64, ptr }
  %l364 = alloca ptr
  %l365 = alloca i1
  %l372 = alloca ptr
  %l373 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l1, !tbaa !29
  store ptr %t5, ptr %l49, !tbaa !29
  store i1 false, ptr %l50, !tbaa !21
  %t6 = load ptr, ptr %l49, !tbaa !29
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %bb4, label %bb5
bb4:
  %t9 = load ptr, ptr %l49, !tbaa !29
  %t10 = load i64, ptr %t9, !range !{i64 0, i64 18}
  %t12 = icmp eq i64 %t10, 0
  store i1 %t12, ptr %l50, !tbaa !21
  br label %bb5
bb5:
  %t13 = load i1, ptr %l50, !tbaa !21
  br i1 %t13, label %bb6, label %bb7
bb6:
  br label %bb12
bb7:
  %t14 = load ptr, ptr %l1, !tbaa !29
  store ptr %t14, ptr %l53, !tbaa !29
  store i1 false, ptr %l54, !tbaa !21
  %t15 = load ptr, ptr %l53, !tbaa !29
  %t16 = icmp ne ptr %t15, null
  br i1 %t16, label %bb8, label %bb9
bb8:
  %t18 = load ptr, ptr %l53, !tbaa !29
  %t19 = load i64, ptr %t18, !range !{i64 0, i64 18}
  %t21 = icmp eq i64 %t19, 1
  store i1 %t21, ptr %l54, !tbaa !21
  br label %bb9
bb9:
  %t22 = load i1, ptr %l54, !tbaa !21
  br i1 %t22, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb208
bb13:
  %t23 = load ptr, ptr %l1, !tbaa !29
  store ptr %t23, ptr %l57, !tbaa !29
  store i1 false, ptr %l58, !tbaa !21
  %t24 = load ptr, ptr %l57, !tbaa !29
  %t25 = icmp ne ptr %t24, null
  br i1 %t25, label %bb14, label %bb15
bb14:
  %t27 = load ptr, ptr %l57, !tbaa !29
  %t28 = load i64, ptr %t27, !range !{i64 0, i64 18}
  %t30 = icmp eq i64 %t28, 2
  store i1 %t30, ptr %l58, !tbaa !21
  br label %bb15
bb15:
  %t31 = load i1, ptr %l58, !tbaa !21
  br i1 %t31, label %bb16, label %bb17
bb16:
  %t32 = load ptr, ptr %l1, !tbaa !29
  %t34 = getelementptr { i64, [5 x i64] }, ptr %t32, i32 0, i32 1
  %t35 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t34, i32 0, i32 1
  %t36 = load i32, ptr %t35
  store i32 %t36, ptr %l2, !tbaa !23
  %t38 = load ptr, ptr %l1, !tbaa !29
  %t40 = getelementptr { i64, [5 x i64] }, ptr %t38, i32 0, i32 1
  %t41 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t40, i32 0, i32 2
  %t42 = load ptr, ptr %t41
  store ptr %t42, ptr %l3, !tbaa !29
  br label %bb18
bb17:
  br label %bb21
bb18:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t45 = load ptr, ptr %l3, !tbaa !29
  %t46 = load i32, ptr %l2, !tbaa !23
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ereadOut(ptr %v0, ptr %v1, ptr %t44, ptr %t45, i32 %t46)
  br label %bb19
bb19:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t51 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eplace(ptr %v0, ptr %v1, ptr %t50, ptr %t51, i1 false)
  br label %bb20
bb20:
  br label %bb208
bb21:
  %t54 = load ptr, ptr %l1, !tbaa !29
  store ptr %t54, ptr %l70, !tbaa !29
  store i1 false, ptr %l71, !tbaa !21
  %t55 = load ptr, ptr %l70, !tbaa !29
  %t56 = icmp ne ptr %t55, null
  br i1 %t56, label %bb22, label %bb23
bb22:
  %t58 = load ptr, ptr %l70, !tbaa !29
  %t59 = load i64, ptr %t58, !range !{i64 0, i64 18}
  %t61 = icmp eq i64 %t59, 3
  store i1 %t61, ptr %l71, !tbaa !21
  br label %bb23
bb23:
  %t62 = load i1, ptr %l71, !tbaa !21
  br i1 %t62, label %bb24, label %bb25
bb24:
  %t63 = load ptr, ptr %l1, !tbaa !29
  %t65 = getelementptr { i64, [5 x i64] }, ptr %t63, i32 0, i32 1
  %t66 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t65, i32 0, i32 2
  %t67 = load ptr, ptr %t66
  store ptr %t67, ptr %l4, !tbaa !29
  br label %bb30
bb25:
  %t69 = load ptr, ptr %l1, !tbaa !29
  store ptr %t69, ptr %l76, !tbaa !29
  store i1 false, ptr %l77, !tbaa !21
  %t70 = load ptr, ptr %l76, !tbaa !29
  %t71 = icmp ne ptr %t70, null
  br i1 %t71, label %bb26, label %bb27
bb26:
  %t73 = load ptr, ptr %l76, !tbaa !29
  %t74 = load i64, ptr %t73, !range !{i64 0, i64 18}
  %t76 = icmp eq i64 %t74, 4
  store i1 %t76, ptr %l77, !tbaa !21
  br label %bb27
bb27:
  %t77 = load i1, ptr %l77, !tbaa !21
  br i1 %t77, label %bb28, label %bb29
bb28:
  %t78 = load ptr, ptr %l1, !tbaa !29
  %t80 = getelementptr { i64, [5 x i64] }, ptr %t78, i32 0, i32 1
  %t81 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t80, i32 0, i32 2
  %t82 = load ptr, ptr %t81
  store ptr %t82, ptr %l4, !tbaa !29
  br label %bb30
bb29:
  br label %bb32
bb30:
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t85 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eplace(ptr %v0, ptr %v1, ptr %t84, ptr %t85, i1 false)
  br label %bb31
bb31:
  br label %bb208
bb32:
  %t88 = load ptr, ptr %l1, !tbaa !29
  store ptr %t88, ptr %l84, !tbaa !29
  store i1 false, ptr %l85, !tbaa !21
  %t89 = load ptr, ptr %l84, !tbaa !29
  %t90 = icmp ne ptr %t89, null
  br i1 %t90, label %bb33, label %bb34
bb33:
  %t92 = load ptr, ptr %l84, !tbaa !29
  %t93 = load i64, ptr %t92, !range !{i64 0, i64 18}
  %t95 = icmp eq i64 %t93, 5
  store i1 %t95, ptr %l85, !tbaa !21
  br label %bb34
bb34:
  %t96 = load i1, ptr %l85, !tbaa !21
  br i1 %t96, label %bb35, label %bb36
bb35:
  %t97 = load ptr, ptr %l1, !tbaa !29
  %t99 = getelementptr { i64, [5 x i64] }, ptr %t97, i32 0, i32 1
  %t100 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t99, i32 0, i32 1
  %t101 = load i32, ptr %t100
  store i32 %t101, ptr %l5, !tbaa !23
  %t103 = load ptr, ptr %l1, !tbaa !29
  %t105 = getelementptr { i64, [5 x i64] }, ptr %t103, i32 0, i32 1
  %t106 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t105, i32 0, i32 2
  %t107 = load ptr, ptr %t106
  store ptr %t107, ptr %l6, !tbaa !29
  br label %bb37
bb36:
  br label %bb45
bb37:
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t111 = getelementptr %"compiler/effects:Effects", ptr %t109, i32 0, i32 25
  %t112 = getelementptr %"compiler/effects:Facts", ptr %t111, i32 0, i32 0
  store i1 true, ptr %t112, !tbaa !21
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t115 = getelementptr %"compiler/effects:Effects", ptr %t113, i32 0, i32 0
  %t116 = load ptr, ptr %t115, !tbaa !29
  %t118 = getelementptr %"compiler/generic:Program", ptr %t116, i32 0, i32 2
  %t119 = load i32, ptr %l5, !tbaa !23
  %t122 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t118, i32 %t119)
  store i1 %t122, ptr %l97
  br label %bb38
bb38:
  %t123 = load i1, ptr %l97, !tbaa !21
  br i1 %t123, label %bb39, label %bb40
bb39:
  %t124 = load ptr, ptr %l0, !tbaa !29
  store ptr %t124, ptr %l98, !tbaa !29
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t127 = getelementptr %"compiler/effects:Effects", ptr %t125, i32 0, i32 0
  %t128 = load ptr, ptr %t127, !tbaa !29
  %t130 = getelementptr %"compiler/generic:Program", ptr %t128, i32 0, i32 2
  %t131 = load i32, ptr %l5, !tbaa !23
  %t134 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t130, i32 %t131)
  store i32 %t134, ptr %l103
  br label %bb41
bb40:
  br label %bb43
bb41:
  %t135 = load ptr, ptr %l98, !tbaa !29
  %t136 = load i32, ptr %l103, !tbaa !23
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2edropsCalled(ptr %v0, ptr %t135, i32 %t136, i64 0)
  br label %bb42
bb42:
  br label %bb43
bb43:
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t138 = load ptr, ptr %l6, !tbaa !29
  %t140 = getelementptr %"compiler/typed:Promote", ptr %t138, i32 0, i32 0
  %t141 = load ptr, ptr %t140, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eexpr(ptr %v0, ptr %v1, ptr %t137, ptr %t141)
  br label %bb44
bb44:
  br label %bb208
bb45:
  %t145 = load ptr, ptr %l1, !tbaa !29
  store ptr %t145, ptr %l108, !tbaa !29
  store i1 false, ptr %l109, !tbaa !21
  %t146 = load ptr, ptr %l108, !tbaa !29
  %t147 = icmp ne ptr %t146, null
  br i1 %t147, label %bb46, label %bb47
bb46:
  %t149 = load ptr, ptr %l108, !tbaa !29
  %t150 = load i64, ptr %t149, !range !{i64 0, i64 18}
  %t152 = icmp eq i64 %t150, 16
  store i1 %t152, ptr %l109, !tbaa !21
  br label %bb47
bb47:
  %t153 = load i1, ptr %l109, !tbaa !21
  br i1 %t153, label %bb48, label %bb49
bb48:
  %t154 = load ptr, ptr %l1, !tbaa !29
  %t156 = getelementptr { i64, [5 x i64] }, ptr %t154, i32 0, i32 1
  %t157 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t156, i32 0, i32 2
  %t158 = load ptr, ptr %t157
  store ptr %t158, ptr %l7, !tbaa !29
  br label %bb50
bb49:
  br label %bb63
bb50:
  %t160 = load ptr, ptr %l0, !tbaa !29
  %t162 = getelementptr %"compiler/effects:Effects", ptr %t160, i32 0, i32 25
  %t163 = getelementptr %"compiler/effects:Facts", ptr %t162, i32 0, i32 0
  store i1 true, ptr %t163, !tbaa !21
  %t164 = load ptr, ptr %l7, !tbaa !29
  %t166 = getelementptr %"compiler/typed:Text", ptr %t164, i32 0, i32 0
  %t167 = load { i64, ptr }, ptr %t166, !tbaa !27
  store { i64, ptr } %t167, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t169 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t171 = extractvalue { i64, ptr } %t169, 0
  store i64 %t171, ptr %l10, !tbaa !24
  br label %bb51
bb51:
  %t173 = load i64, ptr %l9, !tbaa !24
  %t174 = load i64, ptr %l10, !tbaa !24
  %t177 = icmp slt i64 %t173, %t174
  %t179 = xor i1 %t177, true
  br i1 %t179, label %bb52, label %bb53
bb52:
  br label %bb62
bb53:
  br label %bb54
bb54:
  %t181 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t181, ptr %l123, !tbaa !27
  %t182 = load i64, ptr %l9, !tbaa !24
  %t184 = getelementptr { i64, ptr }, ptr %l123, i32 0, i32 1
  %t185 = load ptr, ptr %t184, !tbaa !27
  %t186 = getelementptr ptr, ptr %t185, i64 %t182
  %t187 = load ptr, ptr %t186, !tbaa !39
  store ptr %t187, ptr %l11, !tbaa !29
  %t189 = load ptr, ptr %l11, !tbaa !29
  store ptr %t189, ptr %l126, !tbaa !29
  store i1 false, ptr %l127, !tbaa !21
  %t190 = load ptr, ptr %l126, !tbaa !29
  %t191 = icmp ne ptr %t190, null
  br i1 %t191, label %bb55, label %bb56
bb55:
  %t193 = load ptr, ptr %l126, !tbaa !29
  %t194 = load i64, ptr %t193, !range !{i64 0, i64 2}
  %t196 = icmp eq i64 %t194, 1
  store i1 %t196, ptr %l127, !tbaa !21
  br label %bb56
bb56:
  %t197 = load i1, ptr %l127, !tbaa !21
  br i1 %t197, label %bb57, label %bb58
bb57:
  %t198 = load ptr, ptr %l11, !tbaa !29
  %t200 = getelementptr { i64, [2 x i64] }, ptr %t198, i32 0, i32 1
  %t201 = getelementptr { ptr }, ptr %t200, i32 0, i32 0
  %t202 = load ptr, ptr %t201
  %t204 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eexpr(ptr %v0, ptr %v1, ptr %t204, ptr %t202)
  br label %bb59
bb58:
  br label %bb60
bb59:
  br label %bb60
bb60:
  br label %bb61
bb61:
  %t209 = load i64, ptr %l9, !tbaa !24
  %t212 = add i64 %t209, 1
  store i64 %t212, ptr %l9, !tbaa !24
  br label %bb51
bb62:
  br label %bb208
bb63:
  %t214 = load ptr, ptr %l1, !tbaa !29
  store ptr %t214, ptr %l138, !tbaa !29
  store i1 false, ptr %l139, !tbaa !21
  %t215 = load ptr, ptr %l138, !tbaa !29
  %t216 = icmp ne ptr %t215, null
  br i1 %t216, label %bb64, label %bb65
bb64:
  %t218 = load ptr, ptr %l138, !tbaa !29
  %t219 = load i64, ptr %t218, !range !{i64 0, i64 18}
  %t221 = icmp eq i64 %t219, 8
  store i1 %t221, ptr %l139, !tbaa !21
  br label %bb65
bb65:
  %t222 = load i1, ptr %l139, !tbaa !21
  br i1 %t222, label %bb66, label %bb67
bb66:
  %t223 = load ptr, ptr %l1, !tbaa !29
  %t225 = getelementptr { i64, [5 x i64] }, ptr %t223, i32 0, i32 1
  %t226 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t225, i32 0, i32 2
  %t227 = load ptr, ptr %t226
  store ptr %t227, ptr %l13, !tbaa !29
  br label %bb68
bb67:
  br label %bb71
bb68:
  %t229 = load ptr, ptr %l0, !tbaa !29
  %t231 = getelementptr %"compiler/effects:Effects", ptr %t229, i32 0, i32 25
  %t232 = getelementptr %"compiler/effects:Facts", ptr %t231, i32 0, i32 0
  store i1 true, ptr %t232, !tbaa !21
  %t233 = load ptr, ptr %l0, !tbaa !29
  %t234 = load ptr, ptr %l13, !tbaa !29
  %t236 = getelementptr %"compiler/typed:Collect", ptr %t234, i32 0, i32 0
  %t237 = load ptr, ptr %t236, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eexpr(ptr %v0, ptr %v1, ptr %t233, ptr %t237)
  br label %bb69
bb69:
  %t240 = load ptr, ptr %l0, !tbaa !29
  %t241 = load ptr, ptr %l13, !tbaa !29
  %t243 = getelementptr %"compiler/typed:Collect", ptr %t241, i32 0, i32 1
  %t244 = load ptr, ptr %t243, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eblock(ptr %v0, ptr %v1, ptr %t240, ptr %t244)
  br label %bb70
bb70:
  br label %bb208
bb71:
  %t248 = load ptr, ptr %l1, !tbaa !29
  store ptr %t248, ptr %l152, !tbaa !29
  store i1 false, ptr %l153, !tbaa !21
  %t249 = load ptr, ptr %l152, !tbaa !29
  %t250 = icmp ne ptr %t249, null
  br i1 %t250, label %bb72, label %bb73
bb72:
  %t252 = load ptr, ptr %l152, !tbaa !29
  %t253 = load i64, ptr %t252, !range !{i64 0, i64 18}
  %t255 = icmp eq i64 %t253, 6
  store i1 %t255, ptr %l153, !tbaa !21
  br label %bb73
bb73:
  %t256 = load i1, ptr %l153, !tbaa !21
  br i1 %t256, label %bb74, label %bb75
bb74:
  %t257 = load ptr, ptr %l1, !tbaa !29
  %t259 = getelementptr { i64, [5 x i64] }, ptr %t257, i32 0, i32 1
  %t260 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t259, i32 0, i32 1
  %t261 = load i32, ptr %t260
  store i32 %t261, ptr %l14, !tbaa !23
  %t263 = load ptr, ptr %l1, !tbaa !29
  %t265 = getelementptr { i64, [5 x i64] }, ptr %t263, i32 0, i32 1
  %t266 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t265, i32 0, i32 2
  %t267 = load ptr, ptr %t266
  store ptr %t267, ptr %l15, !tbaa !29
  br label %bb76
bb75:
  br label %bb89
bb76:
  %t269 = load i32, ptr %l14, !tbaa !23
  %t270 = load i32, ptr @G_2ecompiler_2ftypes_2eNoreturnT, !tbaa !23
  %t273 = icmp eq i32 %t269, %t270
  br i1 %t273, label %bb77, label %bb78
bb77:
  %t275 = load ptr, ptr %l0, !tbaa !29
  %t277 = getelementptr %"compiler/effects:Effects", ptr %t275, i32 0, i32 25
  %t278 = getelementptr %"compiler/effects:Facts", ptr %t277, i32 0, i32 18
  store i1 true, ptr %t278, !tbaa !21
  br label %bb79
bb78:
  br label %bb79
bb79:
  %t279 = load ptr, ptr %l0, !tbaa !29
  %t280 = load ptr, ptr %l15, !tbaa !29
  %t281 = load i32, ptr %l14, !tbaa !23
  %t285 = call i1 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eviewCall(ptr %v0, ptr %v1, ptr %t279, ptr %t280, i32 %t281)
  store i1 %t285, ptr %l167
  br label %bb80
bb80:
  %t286 = load i1, ptr %l167, !tbaa !21
  br i1 %t286, label %bb81, label %bb82
bb81:
  %t287 = load ptr, ptr %l0, !tbaa !29
  %t289 = getelementptr %"compiler/effects:Effects", ptr %t287, i32 0, i32 74
  %t290 = load ptr, ptr %l15, !tbaa !29
  %t292 = getelementptr %"compiler/typed:Call", ptr %t290, i32 0, i32 2
  %t293 = load i32, ptr %t292, !tbaa !23
  %t295 = sext i32 %t293 to i64
  %t298 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %t289, i64 %t295)
  store i1 %t298, ptr %l174
  br label %bb83
bb82:
  store i1 false, ptr %l168, !tbaa !21
  br label %bb84
bb83:
  %t299 = load i1, ptr %l174, !tbaa !21
  %t300 = xor i1 %t299, true
  store i1 %t300, ptr %l168, !tbaa !21
  br label %bb84
bb84:
  %t302 = load i1, ptr %l168, !tbaa !21
  br i1 %t302, label %bb85, label %bb86
bb85:
  %t303 = load ptr, ptr %l0, !tbaa !29
  %t305 = getelementptr %"compiler/effects:Effects", ptr %t303, i32 0, i32 25
  %t306 = getelementptr %"compiler/effects:Facts", ptr %t305, i32 0, i32 0
  store i1 true, ptr %t306, !tbaa !21
  br label %bb87
bb86:
  br label %bb87
bb87:
  %t307 = load ptr, ptr %l0, !tbaa !29
  %t308 = load ptr, ptr %l15, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ecall(ptr %v0, ptr %v1, ptr %t307, ptr %t308)
  br label %bb88
bb88:
  br label %bb208
bb89:
  %t311 = load ptr, ptr %l1, !tbaa !29
  store ptr %t311, ptr %l179, !tbaa !29
  store i1 false, ptr %l180, !tbaa !21
  %t312 = load ptr, ptr %l179, !tbaa !29
  %t313 = icmp ne ptr %t312, null
  br i1 %t313, label %bb90, label %bb91
bb90:
  %t315 = load ptr, ptr %l179, !tbaa !29
  %t316 = load i64, ptr %t315, !range !{i64 0, i64 18}
  %t318 = icmp eq i64 %t316, 7
  store i1 %t318, ptr %l180, !tbaa !21
  br label %bb91
bb91:
  %t319 = load i1, ptr %l180, !tbaa !21
  br i1 %t319, label %bb92, label %bb93
bb92:
  %t320 = load ptr, ptr %l1, !tbaa !29
  %t322 = getelementptr { i64, [5 x i64] }, ptr %t320, i32 0, i32 1
  %t323 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t322, i32 0, i32 1
  %t324 = load i32, ptr %t323
  store i32 %t324, ptr %l16, !tbaa !23
  %t326 = load ptr, ptr %l1, !tbaa !29
  %t328 = getelementptr { i64, [5 x i64] }, ptr %t326, i32 0, i32 1
  %t329 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t328, i32 0, i32 2
  %t330 = load ptr, ptr %t329
  store ptr %t330, ptr %l17, !tbaa !29
  br label %bb94
bb93:
  br label %bb110
bb94:
  %t332 = load ptr, ptr %l17, !tbaa !29
  %t334 = getelementptr %"compiler/typed:Make", ptr %t332, i32 0, i32 4
  %t335 = load i32, ptr %t334, !tbaa !23
  %t337 = sext i32 %t335 to i64
  %t339 = icmp sge i64 %t337, 0
  br i1 %t339, label %bb95, label %bb96
bb95:
  %t341 = load ptr, ptr %l0, !tbaa !29
  %t342 = load i32, ptr %l16, !tbaa !23
  %t343 = load ptr, ptr %l17, !tbaa !29
  %t347 = call i1 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2einPlace(ptr %v0, ptr %v1, ptr %t341, i32 %t342, ptr %t343)
  store i1 %t347, ptr %l195
  br label %bb97
bb96:
  store i1 false, ptr %l191, !tbaa !21
  br label %bb98
bb97:
  %t348 = load i1, ptr %l195, !tbaa !21
  %t349 = xor i1 %t348, true
  store i1 %t349, ptr %l191, !tbaa !21
  br label %bb98
bb98:
  %t351 = load i1, ptr %l191, !tbaa !21
  br i1 %t351, label %bb99, label %bb100
bb99:
  %t352 = load ptr, ptr %l0, !tbaa !29
  %t354 = getelementptr %"compiler/effects:Effects", ptr %t352, i32 0, i32 25
  %t355 = getelementptr %"compiler/effects:Facts", ptr %t354, i32 0, i32 0
  store i1 true, ptr %t355, !tbaa !21
  br label %bb101
bb100:
  br label %bb101
bb101:
  %t356 = load ptr, ptr %l0, !tbaa !29
  %t357 = load ptr, ptr %l17, !tbaa !29
  %t359 = getelementptr %"compiler/typed:Make", ptr %t357, i32 0, i32 3
  %t360 = load ptr, ptr %t359, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eexpr(ptr %v0, ptr %v1, ptr %t356, ptr %t360)
  br label %bb102
bb102:
  %t363 = load ptr, ptr %l17, !tbaa !29
  %t365 = getelementptr %"compiler/typed:Make", ptr %t363, i32 0, i32 2
  %t366 = load { i64, ptr }, ptr %t365, !tbaa !27
  store { i64, ptr } %t366, ptr %l18, !tbaa !27
  store i64 0, ptr %l19, !tbaa !24
  %t368 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t370 = extractvalue { i64, ptr } %t368, 0
  store i64 %t370, ptr %l20, !tbaa !24
  br label %bb103
bb103:
  %t372 = load i64, ptr %l19, !tbaa !24
  %t373 = load i64, ptr %l20, !tbaa !24
  %t376 = icmp slt i64 %t372, %t373
  %t378 = xor i1 %t376, true
  br i1 %t378, label %bb104, label %bb105
bb104:
  br label %bb109
bb105:
  br label %bb106
bb106:
  %t380 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t380, ptr %l209, !tbaa !27
  %t381 = load i64, ptr %l19, !tbaa !24
  %t383 = getelementptr { i64, ptr }, ptr %l209, i32 0, i32 1
  %t384 = load ptr, ptr %t383, !tbaa !27
  %t385 = getelementptr ptr, ptr %t384, i64 %t381
  %t386 = load ptr, ptr %t385, !tbaa !39
  %t388 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eexpr(ptr %v0, ptr %v1, ptr %t388, ptr %t386)
  br label %bb107
bb107:
  br label %bb108
bb108:
  %t393 = load i64, ptr %l19, !tbaa !24
  %t396 = add i64 %t393, 1
  store i64 %t396, ptr %l19, !tbaa !24
  br label %bb103
bb109:
  br label %bb208
bb110:
  %t398 = load ptr, ptr %l1, !tbaa !29
  store ptr %t398, ptr %l218, !tbaa !29
  store i1 false, ptr %l219, !tbaa !21
  %t399 = load ptr, ptr %l218, !tbaa !29
  %t400 = icmp ne ptr %t399, null
  br i1 %t400, label %bb111, label %bb112
bb111:
  %t402 = load ptr, ptr %l218, !tbaa !29
  %t403 = load i64, ptr %t402, !range !{i64 0, i64 18}
  %t405 = icmp eq i64 %t403, 9
  store i1 %t405, ptr %l219, !tbaa !21
  br label %bb112
bb112:
  %t406 = load i1, ptr %l219, !tbaa !21
  br i1 %t406, label %bb113, label %bb114
bb113:
  %t407 = load ptr, ptr %l1, !tbaa !29
  %t409 = getelementptr { i64, [5 x i64] }, ptr %t407, i32 0, i32 1
  %t410 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t409, i32 0, i32 2
  %t411 = load i32, ptr %t410, !range !{i32 0, i32 54}
  store i32 %t411, ptr %l22
  %t413 = load ptr, ptr %l1, !tbaa !29
  %t415 = getelementptr { i64, [5 x i64] }, ptr %t413, i32 0, i32 1
  %t416 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t415, i32 0, i32 4
  %t417 = load { i64, ptr }, ptr %t416
  store { i64, ptr } %t417, ptr %l23, !tbaa !27
  br label %bb115
bb114:
  br label %bb117
bb115:
  %t419 = load ptr, ptr %l0, !tbaa !29
  %t420 = load i32, ptr %l22, !range !{i32 0, i32 54}
  %t421 = load { i64, ptr }, ptr %l23, !tbaa !27
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eprim(ptr %v0, ptr %v1, ptr %t419, i32 %t420, { i64, ptr } %t421)
  br label %bb116
bb116:
  br label %bb208
bb117:
  %t425 = load ptr, ptr %l1, !tbaa !29
  store ptr %t425, ptr %l229, !tbaa !29
  store i1 false, ptr %l230, !tbaa !21
  %t426 = load ptr, ptr %l229, !tbaa !29
  %t427 = icmp ne ptr %t426, null
  br i1 %t427, label %bb118, label %bb119
bb118:
  %t429 = load ptr, ptr %l229, !tbaa !29
  %t430 = load i64, ptr %t429, !range !{i64 0, i64 18}
  %t432 = icmp eq i64 %t430, 10
  store i1 %t432, ptr %l230, !tbaa !21
  br label %bb119
bb119:
  %t433 = load i1, ptr %l230, !tbaa !21
  br i1 %t433, label %bb120, label %bb121
bb120:
  %t434 = load ptr, ptr %l1, !tbaa !29
  %t436 = getelementptr { i64, [5 x i64] }, ptr %t434, i32 0, i32 1
  %t437 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t436, i32 0, i32 2
  %t438 = load ptr, ptr %t437
  store ptr %t438, ptr %l24, !tbaa !29
  br label %bb122
bb121:
  br label %bb126
bb122:
  %t440 = load ptr, ptr %l0, !tbaa !29
  %t441 = load ptr, ptr %l24, !tbaa !29
  %t443 = getelementptr %"compiler/typed:Slice", ptr %t441, i32 0, i32 0
  %t444 = load ptr, ptr %t443, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eplace(ptr %v0, ptr %v1, ptr %t440, ptr %t444, i1 false)
  br label %bb123
bb123:
  %t447 = load ptr, ptr %l0, !tbaa !29
  %t448 = load ptr, ptr %l24, !tbaa !29
  %t450 = getelementptr %"compiler/typed:Slice", ptr %t448, i32 0, i32 1
  %t451 = load ptr, ptr %t450, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eexpr(ptr %v0, ptr %v1, ptr %t447, ptr %t451)
  br label %bb124
bb124:
  %t455 = load ptr, ptr %l0, !tbaa !29
  %t456 = load ptr, ptr %l24, !tbaa !29
  %t458 = getelementptr %"compiler/typed:Slice", ptr %t456, i32 0, i32 2
  %t459 = load ptr, ptr %t458, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eexpr(ptr %v0, ptr %v1, ptr %t455, ptr %t459)
  br label %bb125
bb125:
  br label %bb208
bb126:
  %t463 = load ptr, ptr %l1, !tbaa !29
  store ptr %t463, ptr %l246, !tbaa !29
  store i1 false, ptr %l247, !tbaa !21
  %t464 = load ptr, ptr %l246, !tbaa !29
  %t465 = icmp ne ptr %t464, null
  br i1 %t465, label %bb127, label %bb128
bb127:
  %t467 = load ptr, ptr %l246, !tbaa !29
  %t468 = load i64, ptr %t467, !range !{i64 0, i64 18}
  %t470 = icmp eq i64 %t468, 11
  store i1 %t470, ptr %l247, !tbaa !21
  br label %bb128
bb128:
  %t471 = load i1, ptr %l247, !tbaa !21
  br i1 %t471, label %bb129, label %bb130
bb129:
  %t472 = load ptr, ptr %l1, !tbaa !29
  %t474 = getelementptr { i64, [5 x i64] }, ptr %t472, i32 0, i32 1
  %t475 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t474, i32 0, i32 2
  %t476 = load ptr, ptr %t475
  store ptr %t476, ptr %l25, !tbaa !29
  br label %bb131
bb130:
  br label %bb135
bb131:
  %t478 = load ptr, ptr %l0, !tbaa !29
  %t479 = load ptr, ptr %l25, !tbaa !29
  %t481 = getelementptr %"compiler/typed:Cond", ptr %t479, i32 0, i32 0
  %t482 = load ptr, ptr %t481, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eexpr(ptr %v0, ptr %v1, ptr %t478, ptr %t482)
  br label %bb132
bb132:
  %t486 = load ptr, ptr %l0, !tbaa !29
  %t487 = load ptr, ptr %l25, !tbaa !29
  %t489 = getelementptr %"compiler/typed:Cond", ptr %t487, i32 0, i32 1
  %t490 = load ptr, ptr %t489, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eexpr(ptr %v0, ptr %v1, ptr %t486, ptr %t490)
  br label %bb133
bb133:
  %t493 = load ptr, ptr %l0, !tbaa !29
  %t494 = load ptr, ptr %l25, !tbaa !29
  %t496 = getelementptr %"compiler/typed:Cond", ptr %t494, i32 0, i32 2
  %t497 = load ptr, ptr %t496, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eexpr(ptr %v0, ptr %v1, ptr %t493, ptr %t497)
  br label %bb134
bb134:
  br label %bb208
bb135:
  %t501 = load ptr, ptr %l1, !tbaa !29
  store ptr %t501, ptr %l263, !tbaa !29
  store i1 false, ptr %l264, !tbaa !21
  %t502 = load ptr, ptr %l263, !tbaa !29
  %t503 = icmp ne ptr %t502, null
  br i1 %t503, label %bb136, label %bb137
bb136:
  %t505 = load ptr, ptr %l263, !tbaa !29
  %t506 = load i64, ptr %t505, !range !{i64 0, i64 18}
  %t508 = icmp eq i64 %t506, 12
  store i1 %t508, ptr %l264, !tbaa !21
  br label %bb137
bb137:
  %t509 = load i1, ptr %l264, !tbaa !21
  br i1 %t509, label %bb138, label %bb139
bb138:
  %t510 = load ptr, ptr %l1, !tbaa !29
  %t512 = getelementptr { i64, [5 x i64] }, ptr %t510, i32 0, i32 1
  %t513 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t512, i32 0, i32 2
  %t514 = load ptr, ptr %t513
  store ptr %t514, ptr %l26, !tbaa !29
  br label %bb140
bb139:
  br label %bb149
bb140:
  %t516 = load ptr, ptr %l26, !tbaa !29
  %t518 = getelementptr %"compiler/typed:Seq", ptr %t516, i32 0, i32 0
  %t519 = load { i64, ptr }, ptr %t518, !tbaa !27
  store { i64, ptr } %t519, ptr %l27, !tbaa !27
  store i64 0, ptr %l28, !tbaa !24
  %t521 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t523 = extractvalue { i64, ptr } %t521, 0
  store i64 %t523, ptr %l29, !tbaa !24
  br label %bb141
bb141:
  %t525 = load i64, ptr %l28, !tbaa !24
  %t526 = load i64, ptr %l29, !tbaa !24
  %t529 = icmp slt i64 %t525, %t526
  %t531 = xor i1 %t529, true
  br i1 %t531, label %bb142, label %bb143
bb142:
  br label %bb147
bb143:
  br label %bb144
bb144:
  %t533 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t533, ptr %l277, !tbaa !27
  %t534 = load i64, ptr %l28, !tbaa !24
  %t536 = getelementptr { i64, ptr }, ptr %l277, i32 0, i32 1
  %t537 = load ptr, ptr %t536, !tbaa !27
  %t538 = getelementptr ptr, ptr %t537, i64 %t534
  %t539 = load ptr, ptr %t538, !tbaa !39
  %t541 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2estmt(ptr %v0, ptr %v1, ptr %t541, ptr %t539)
  br label %bb145
bb145:
  br label %bb146
bb146:
  %t545 = load i64, ptr %l28, !tbaa !24
  %t548 = add i64 %t545, 1
  store i64 %t548, ptr %l28, !tbaa !24
  br label %bb141
bb147:
  %t550 = load ptr, ptr %l0, !tbaa !29
  %t551 = load ptr, ptr %l26, !tbaa !29
  %t553 = getelementptr %"compiler/typed:Seq", ptr %t551, i32 0, i32 1
  %t554 = load ptr, ptr %t553, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eexpr(ptr %v0, ptr %v1, ptr %t550, ptr %t554)
  br label %bb148
bb148:
  br label %bb208
bb149:
  %t557 = load ptr, ptr %l1, !tbaa !29
  store ptr %t557, ptr %l288, !tbaa !29
  store i1 false, ptr %l289, !tbaa !21
  %t558 = load ptr, ptr %l288, !tbaa !29
  %t559 = icmp ne ptr %t558, null
  br i1 %t559, label %bb150, label %bb151
bb150:
  %t561 = load ptr, ptr %l288, !tbaa !29
  %t562 = load i64, ptr %t561, !range !{i64 0, i64 18}
  %t564 = icmp eq i64 %t562, 13
  store i1 %t564, ptr %l289, !tbaa !21
  br label %bb151
bb151:
  %t565 = load i1, ptr %l289, !tbaa !21
  br i1 %t565, label %bb152, label %bb153
bb152:
  %t566 = load ptr, ptr %l1, !tbaa !29
  %t568 = getelementptr { i64, [5 x i64] }, ptr %t566, i32 0, i32 1
  %t569 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t568, i32 0, i32 2
  %t570 = load ptr, ptr %t569
  store ptr %t570, ptr %l31, !tbaa !29
  br label %bb154
bb153:
  br label %bb176
bb154:
  %t572 = load ptr, ptr %l31, !tbaa !29
  %t574 = getelementptr %"compiler/typed:Match", ptr %t572, i32 0, i32 0
  %t575 = load { i64, ptr }, ptr %t574, !tbaa !27
  store { i64, ptr } %t575, ptr %l32, !tbaa !27
  store i64 0, ptr %l33, !tbaa !24
  %t577 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t579 = extractvalue { i64, ptr } %t577, 0
  store i64 %t579, ptr %l34, !tbaa !24
  br label %bb155
bb155:
  %t581 = load i64, ptr %l33, !tbaa !24
  %t582 = load i64, ptr %l34, !tbaa !24
  %t585 = icmp slt i64 %t581, %t582
  %t587 = xor i1 %t585, true
  br i1 %t587, label %bb156, label %bb157
bb156:
  br label %bb161
bb157:
  br label %bb158
bb158:
  %t589 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t589, ptr %l302, !tbaa !27
  %t590 = load i64, ptr %l33, !tbaa !24
  %t592 = getelementptr { i64, ptr }, ptr %l302, i32 0, i32 1
  %t593 = load ptr, ptr %t592, !tbaa !27
  %t594 = getelementptr ptr, ptr %t593, i64 %t590
  %t595 = load ptr, ptr %t594, !tbaa !39
  %t597 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2estmt(ptr %v0, ptr %v1, ptr %t597, ptr %t595)
  br label %bb159
bb159:
  br label %bb160
bb160:
  %t601 = load i64, ptr %l33, !tbaa !24
  %t604 = add i64 %t601, 1
  store i64 %t604, ptr %l33, !tbaa !24
  br label %bb155
bb161:
  %t606 = load ptr, ptr %l31, !tbaa !29
  %t608 = getelementptr %"compiler/typed:Match", ptr %t606, i32 0, i32 1
  %t609 = load { i64, ptr }, ptr %t608, !tbaa !27
  store { i64, ptr } %t609, ptr %l36, !tbaa !27
  store i64 0, ptr %l37, !tbaa !24
  %t611 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t613 = extractvalue { i64, ptr } %t611, 0
  store i64 %t613, ptr %l38, !tbaa !24
  br label %bb162
bb162:
  %t615 = load i64, ptr %l37, !tbaa !24
  %t616 = load i64, ptr %l38, !tbaa !24
  %t619 = icmp slt i64 %t615, %t616
  %t621 = xor i1 %t619, true
  br i1 %t621, label %bb163, label %bb164
bb163:
  br label %bb168
bb164:
  br label %bb165
bb165:
  %t623 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t623, ptr %l318, !tbaa !27
  %t624 = load i64, ptr %l37, !tbaa !24
  %t626 = getelementptr { i64, ptr }, ptr %l318, i32 0, i32 1
  %t627 = load ptr, ptr %t626, !tbaa !27
  %t628 = getelementptr ptr, ptr %t627, i64 %t624
  %t629 = load ptr, ptr %t628, !tbaa !39
  %t631 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2earm(ptr %v0, ptr %v1, ptr %t631, ptr %t629)
  br label %bb166
bb166:
  br label %bb167
bb167:
  %t635 = load i64, ptr %l37, !tbaa !24
  %t638 = add i64 %t635, 1
  store i64 %t638, ptr %l37, !tbaa !24
  br label %bb162
bb168:
  %t640 = load ptr, ptr %l31, !tbaa !29
  %t642 = getelementptr %"compiler/typed:Match", ptr %t640, i32 0, i32 2
  %t643 = load ptr, ptr %t642, !tbaa !29
  %t645 = icmp eq ptr %t643, null
  %t647 = xor i1 %t645, true
  br i1 %t647, label %bb169, label %bb170
bb169:
  %t649 = load ptr, ptr %l0, !tbaa !29
  store ptr %t649, ptr %l330, !tbaa !29
  %t650 = load ptr, ptr %l31, !tbaa !29
  %t652 = getelementptr %"compiler/typed:Match", ptr %t650, i32 0, i32 2
  %t653 = load ptr, ptr %t652, !tbaa !29
  %t655 = icmp eq ptr %t653, null
  br i1 %t655, label %bb171, label %bb172
bb170:
  br label %bb175
bb171:
  call void @__olang_check_failed(ptr @olang_loc_949627fca0824f08_4c3b1084581425e4)
  unreachable
bb172:
  br label %bb173
bb173:
  %t657 = load ptr, ptr %l31, !tbaa !29
  %t659 = getelementptr %"compiler/typed:Match", ptr %t657, i32 0, i32 2
  %t660 = load ptr, ptr %t659, !tbaa !29
  %t661 = load ptr, ptr %l330, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2earm(ptr %v0, ptr %v1, ptr %t661, ptr %t660)
  br label %bb174
bb174:
  br label %bb175
bb175:
  br label %bb208
bb176:
  %t663 = load ptr, ptr %l1, !tbaa !29
  store ptr %t663, ptr %l336, !tbaa !29
  store i1 false, ptr %l337, !tbaa !21
  %t664 = load ptr, ptr %l336, !tbaa !29
  %t665 = icmp ne ptr %t664, null
  br i1 %t665, label %bb177, label %bb178
bb177:
  %t667 = load ptr, ptr %l336, !tbaa !29
  %t668 = load i64, ptr %t667, !range !{i64 0, i64 18}
  %t670 = icmp eq i64 %t668, 14
  store i1 %t670, ptr %l337, !tbaa !21
  br label %bb178
bb178:
  %t671 = load i1, ptr %l337, !tbaa !21
  br i1 %t671, label %bb179, label %bb180
bb179:
  %t672 = load ptr, ptr %l1, !tbaa !29
  %t674 = getelementptr { i64, [5 x i64] }, ptr %t672, i32 0, i32 1
  %t675 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t674, i32 0, i32 2
  %t676 = load ptr, ptr %t675
  store ptr %t676, ptr %l40, !tbaa !29
  br label %bb181
bb180:
  br label %bb193
bb181:
  %t678 = load ptr, ptr %l40, !tbaa !29
  %t680 = getelementptr %"compiler/typed:Try", ptr %t678, i32 0, i32 2
  %t681 = load i1, ptr %t680, !tbaa !21
  br i1 %t681, label %bb182, label %bb183
bb182:
  %t683 = load ptr, ptr %l0, !tbaa !29
  %t685 = getelementptr %"compiler/effects:Effects", ptr %t683, i32 0, i32 25
  %t686 = getelementptr %"compiler/effects:Facts", ptr %t685, i32 0, i32 18
  store i1 true, ptr %t686, !tbaa !21
  br label %bb184
bb183:
  br label %bb184
bb184:
  %t687 = load ptr, ptr %l0, !tbaa !29
  %t688 = load ptr, ptr %l40, !tbaa !29
  %t690 = getelementptr %"compiler/typed:Try", ptr %t688, i32 0, i32 0
  %t691 = load ptr, ptr %t690, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eexpr(ptr %v0, ptr %v1, ptr %t687, ptr %t691)
  br label %bb185
bb185:
  %t694 = load ptr, ptr %l40, !tbaa !29
  %t696 = getelementptr %"compiler/typed:Try", ptr %t694, i32 0, i32 1
  %t697 = load { i64, ptr }, ptr %t696, !tbaa !27
  store { i64, ptr } %t697, ptr %l41, !tbaa !27
  store i64 0, ptr %l42, !tbaa !24
  %t699 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t701 = extractvalue { i64, ptr } %t699, 0
  store i64 %t701, ptr %l43, !tbaa !24
  br label %bb186
bb186:
  %t703 = load i64, ptr %l42, !tbaa !24
  %t704 = load i64, ptr %l43, !tbaa !24
  %t707 = icmp slt i64 %t703, %t704
  %t709 = xor i1 %t707, true
  br i1 %t709, label %bb187, label %bb188
bb187:
  br label %bb192
bb188:
  br label %bb189
bb189:
  %t711 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t711, ptr %l356, !tbaa !27
  %t712 = load i64, ptr %l42, !tbaa !24
  %t714 = getelementptr { i64, ptr }, ptr %l356, i32 0, i32 1
  %t715 = load ptr, ptr %t714, !tbaa !27
  %t716 = getelementptr ptr, ptr %t715, i64 %t712
  %t717 = load ptr, ptr %t716, !tbaa !39
  %t719 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eclause(ptr %v0, ptr %v1, ptr %t719, ptr %t717)
  br label %bb190
bb190:
  br label %bb191
bb191:
  %t723 = load i64, ptr %l42, !tbaa !24
  %t726 = add i64 %t723, 1
  store i64 %t726, ptr %l42, !tbaa !24
  br label %bb186
bb192:
  br label %bb208
bb193:
  %t728 = load ptr, ptr %l1, !tbaa !29
  store ptr %t728, ptr %l364, !tbaa !29
  store i1 false, ptr %l365, !tbaa !21
  %t729 = load ptr, ptr %l364, !tbaa !29
  %t730 = icmp ne ptr %t729, null
  br i1 %t730, label %bb194, label %bb195
bb194:
  %t732 = load ptr, ptr %l364, !tbaa !29
  %t733 = load i64, ptr %t732, !range !{i64 0, i64 18}
  %t735 = icmp eq i64 %t733, 15
  store i1 %t735, ptr %l365, !tbaa !21
  br label %bb195
bb195:
  %t736 = load i1, ptr %l365, !tbaa !21
  br i1 %t736, label %bb196, label %bb197
bb196:
  %t737 = load ptr, ptr %l1, !tbaa !29
  %t739 = getelementptr { i64, [5 x i64] }, ptr %t737, i32 0, i32 1
  %t740 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t739, i32 0, i32 2
  %t741 = load ptr, ptr %t740
  store ptr %t741, ptr %l45, !tbaa !29
  br label %bb198
bb197:
  br label %bb200
bb198:
  %t743 = load ptr, ptr %l0, !tbaa !29
  %t744 = load ptr, ptr %l45, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2efnVal(ptr %v0, ptr %v1, ptr %t743, ptr %t744)
  br label %bb199
bb199:
  br label %bb208
bb200:
  %t747 = load ptr, ptr %l1, !tbaa !29
  store ptr %t747, ptr %l372, !tbaa !29
  store i1 false, ptr %l373, !tbaa !21
  %t748 = load ptr, ptr %l372, !tbaa !29
  %t749 = icmp ne ptr %t748, null
  br i1 %t749, label %bb201, label %bb202
bb201:
  %t751 = load ptr, ptr %l372, !tbaa !29
  %t752 = load i64, ptr %t751, !range !{i64 0, i64 18}
  %t754 = icmp eq i64 %t752, 17
  store i1 %t754, ptr %l373, !tbaa !21
  br label %bb202
bb202:
  %t755 = load i1, ptr %l373, !tbaa !21
  br i1 %t755, label %bb203, label %bb204
bb203:
  %t756 = load ptr, ptr %l1, !tbaa !29
  %t758 = getelementptr { i64, [5 x i64] }, ptr %t756, i32 0, i32 1
  %t759 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t758, i32 0, i32 2
  %t760 = load ptr, ptr %t759
  store ptr %t760, ptr %l46, !tbaa !29
  br label %bb205
bb204:
  br label %bb207
bb205:
  %t762 = load ptr, ptr %l0, !tbaa !29
  %t763 = load ptr, ptr %l46, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eexpr(ptr %v0, ptr %v1, ptr %t762, ptr %t763)
  br label %bb206
bb206:
  br label %bb208
bb207:
  call void @__olang_check_failed(ptr @olang_loc_ca5d43677e660e3e_842659f2ce3d2d4a)
  unreachable
bb208:
  br label %ret
ret:
  ret void
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2efieldSlots(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca %"compiler/effects:fpath"
  %l16 = alloca i1
  %l17 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l21 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l22 = alloca i32
  %l24 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l25 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l26 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l30 = alloca ptr
  %l33 = alloca i64
  %l37 = alloca i64
  %l40 = alloca i64
  %l58 = alloca ptr
  %l59 = alloca ptr
  %l61 = alloca ptr
  %l65 = alloca i32
  %l67 = alloca %"compiler/typed:Local"
  %l69 = alloca i32
  %l70 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l72 = alloca i64
  %l74 = alloca i64
  %l79 = alloca %"compiler/effects:fpath"
  %l80 = alloca %"compiler/effects:fpath"
  %l81 = alloca i64
  %l83 = alloca { i64, ptr }
  %l84 = alloca i64
  %l85 = alloca { i64, ptr }
  %l89 = alloca ptr
  %l93 = alloca %"compiler/effects:fslot"
  %l95 = alloca %"compiler/effects:fslot"
  %l103 = alloca ptr
  %l104 = alloca i64
  %l105 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l107 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/effects:Effects", ptr %t1, i32 0, i32 64
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cc_H3f7eb4254a4c517352479452f11f6219(ptr %v0, ptr %t3, i64 %t4)
  store i1 %t7, ptr %l16
  br label %bb1
bb1:
  %t8 = load i1, ptr %l16, !tbaa !21
  br i1 %t8, label %bb2, label %bb3
bb2:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/effects:Effects", ptr %t9, i32 0, i32 64
  %t12 = load i64, ptr %l1, !tbaa !24
  %t15 = call { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cc_Hc098dfa5961f28f78d4c086fb0a8b3d1(ptr %v0, ptr %v1, ptr %t11, i64 %t12)
  %t16 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t15, 1
  %t17 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t15, 0
  store i32 %t17, ptr %l22
  %t18 = icmp ne i32 %t17, 0
  br i1 %t18, label %bb5, label %ok.19, !prof !99
ok.19:
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t16, ptr %l21
  br label %bb4
bb3:
  br label %bb10
bb4:
  %t21 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3afslot_3e(ptr %v1, ptr %l21)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t21, ptr %l24
  br label %bb7
bb5:
  br label %bb6
bb6:
  %t22 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3afslot_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t22, ptr %l25
  br label %bb8
bb7:
  %t23 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l24
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t23, ptr %l17
  br label %bb9
bb8:
  %t24 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l25
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t24, ptr %l17
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s0)
  %t25 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l17
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t25, ptr %rv
  br label %ret
bb10:
  %t26 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3afslot_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t26, ptr %l26
  br label %bb11
bb11:
  %t27 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l26
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t27, ptr %l2
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/effects:Effects", ptr %t28, i32 0, i32 1
  %t31 = load i64, ptr %l1, !tbaa !24
  %t34 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t30, i64 %t31)
  store ptr %t34, ptr %l30
  br label %bb12
bb12:
  %t35 = load ptr, ptr %l30, !tbaa !29
  store ptr %t35, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  %t36 = load ptr, ptr %l3, !tbaa !29
  %t38 = getelementptr %"compiler/typed:Body", ptr %t36, i32 0, i32 5
  %t40 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t38)
  store i64 %t40, ptr %l33
  br label %bb13
bb13:
  %t41 = load i64, ptr %l33, !tbaa !24
  store i64 %t41, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t42 = load i64, ptr %l5, !tbaa !24
  %t43 = load i64, ptr %l4, !tbaa !24
  %t46 = icmp sgt i64 %t42, %t43
  br i1 %t46, label %bb14, label %bb15
bb14:
  %t48 = load i64, ptr %l6, !tbaa !24
  %t50 = icmp sgt i64 %t48, 0
  br i1 %t50, label %bb16, label %bb17
bb15:
  store i64 0, ptr %l37, !tbaa !24
  br label %bb19
bb16:
  %t52 = load i64, ptr %l5, !tbaa !24
  %t53 = load i64, ptr %l4, !tbaa !24
  %t56 = sub i64 %t52, %t53
  %t57 = load i64, ptr %l6, !tbaa !24
  %t60 = add i64 %t56, %t57
  %t62 = sub i64 %t60, 1
  %t63 = load i64, ptr %l6, !tbaa !24
  %t66 = sdiv i64 %t62, %t63
  store i64 %t66, ptr %l40, !tbaa !24
  br label %bb18
bb17:
  store i64 0, ptr %l40, !tbaa !24
  br label %bb18
bb18:
  %t68 = load i64, ptr %l40, !tbaa !24
  store i64 %t68, ptr %l37, !tbaa !24
  br label %bb19
bb19:
  %t69 = load i64, ptr %l37, !tbaa !24
  store i64 %t69, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb20
bb20:
  %t70 = load i64, ptr %l8, !tbaa !24
  %t71 = load i64, ptr %l7, !tbaa !24
  %t74 = icmp slt i64 %t70, %t71
  %t76 = xor i1 %t74, true
  br i1 %t76, label %bb21, label %bb22
bb21:
  br label %bb46
bb22:
  br label %bb23
bb23:
  %t78 = load i64, ptr %l4, !tbaa !24
  %t79 = load i64, ptr %l8, !tbaa !24
  %t80 = load i64, ptr %l6, !tbaa !24
  %t83 = mul i64 %t79, %t80
  %t86 = add i64 %t78, %t83
  store i64 %t86, ptr %l9, !tbaa !24
  store %olang.scope zeroinitializer, ptr %s4
  %t88 = load ptr, ptr %l0, !tbaa !29
  store ptr %t88, ptr %l58, !tbaa !29
  %t89 = load ptr, ptr %l0, !tbaa !29
  store ptr %t89, ptr %l59, !tbaa !29
  %t90 = load ptr, ptr %l3, !tbaa !29
  %t92 = getelementptr %"compiler/typed:Body", ptr %t90, i32 0, i32 7
  store ptr %t92, ptr %l61, !tbaa !29
  %t93 = load ptr, ptr %l3, !tbaa !29
  %t95 = getelementptr %"compiler/typed:Body", ptr %t93, i32 0, i32 5
  %t96 = load i64, ptr %l9, !tbaa !24
  %t99 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t95, i64 %t96)
  store i32 %t99, ptr %l65
  br label %bb24
bb24:
  %t100 = load i32, ptr %l65, !tbaa !23
  %t101 = sext i32 %t100 to i64
  %t102 = load ptr, ptr %l61, !tbaa !29
  %t104 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t102, i64 %t101)
  store %"compiler/typed:Local" %t104, ptr %l67
  br label %bb25
bb25:
  %t105 = getelementptr %"compiler/typed:Local", ptr %l67, i32 0, i32 2
  %t106 = load i32, ptr %t105, !tbaa !23
  %t107 = load ptr, ptr %l59, !tbaa !29
  %t109 = call i32 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2estructOf(ptr %v0, ptr %t107, i32 %t106)
  store i32 %t109, ptr %l69
  br label %bb26
bb26:
  %t110 = load ptr, ptr %l58, !tbaa !29
  %t111 = load i32, ptr %l69, !tbaa !23
  %t112 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2epaths(ptr %v0, ptr %s4, ptr %t110, i32 %t111)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t112, ptr %l70
  br label %bb27
bb27:
  %t113 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l70
  %t114 = call ptr @__olang_scope_alloc_a(ptr %s4, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t113, ptr %t114
  store ptr %t114, ptr %l10, !tbaa !29
  store i64 0, ptr %l11, !tbaa !24
  br label %bb28
bb28:
  store %olang.scope zeroinitializer, ptr %s5
  %t116 = load i64, ptr %l11, !tbaa !24
  store i64 %t116, ptr %l72, !tbaa !24
  %t117 = load ptr, ptr %l10, !tbaa !29
  %t119 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3afpath_3e_2eLen_3ccompiler_2feffects_3afpath_3e(ptr %s4, ptr %t117)
  store i64 %t119, ptr %l74
  br label %bb29
bb29:
  %t120 = load i64, ptr %l72, !tbaa !24
  %t121 = load i64, ptr %l74, !tbaa !24
  %t122 = icmp slt i64 %t120, %t121
  %t124 = xor i1 %t122, true
  br i1 %t124, label %bb30, label %bb31
bb30:
  call void @__olang_scope_close(ptr %s5)
  br label %bb44
bb31:
  br label %bb32
bb32:
  %t126 = load ptr, ptr %l10, !tbaa !29
  %t127 = load i64, ptr %l11, !tbaa !24
  %t130 = call %"compiler/effects:fpath" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3afpath_3e_2eAt_3ccompiler_2feffects_3afpath_3e(ptr %s4, ptr %s4, ptr %t126, i64 %t127)
  store %"compiler/effects:fpath" %t130, ptr %l79
  br label %bb33
bb33:
  %t131 = load %"compiler/effects:fpath", ptr %l79
  store %"compiler/effects:fpath" %t131, ptr %l80
  %t132 = call ptr @__olang_scope_hold(ptr %s5)
  %t133 = ptrtoint ptr %t132 to i64
  store i64 %t133, ptr %l81, !tbaa !24
  %t134 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t134, label %bb34, label %bb35
bb34:
  %t136 = call ptr @__olang_region_make_part(ptr %s5)
  %t137 = ptrtoint ptr %t136 to i64
  store i64 %t137, ptr %l81, !tbaa !24
  br label %bb35
bb35:
  %t138 = getelementptr %"compiler/effects:fpath", ptr %l80, i32 0, i32 0
  %t139 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t138, i32 0, i32 0
  %t140 = load { i64, ptr }, ptr %t139, !tbaa !27
  store { i64, ptr } %t140, ptr %l83, !tbaa !27
  %t141 = load { i64, ptr }, ptr %l83, !tbaa !27
  %t142 = extractvalue { i64, ptr } %t141, 0
  store i64 %t142, ptr %l84, !tbaa !24
  %t143 = load i64, ptr %l84, !tbaa !24
  %t144 = mul i64 %t143, 8
  %t145 = load i64, ptr %l81
  %t146 = inttoptr i64 %t145 to ptr
  %t147 = call ptr @__olang_held_alloc(ptr %t146, i64 %t144)
  %t148 = insertvalue { i64, ptr } undef, i64 %t143, 0
  %t149 = insertvalue { i64, ptr } %t148, ptr %t147, 1
  store { i64, ptr } %t149, ptr %l85, !tbaa !27
  %t150 = getelementptr { i64, ptr }, ptr %l85, i32 0, i32 1
  %t151 = load ptr, ptr %t150, !tbaa !27
  %t152 = getelementptr { i64, ptr }, ptr %l83, i32 0, i32 1
  %t153 = load ptr, ptr %t152, !tbaa !27
  %t154 = load i64, ptr %l84, !tbaa !24
  %t155 = mul i64 %t154, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t151, ptr %t153, i64 %t155, i1 false)
  %t156 = load { i64, ptr }, ptr %l85, !tbaa !27
  %t157 = getelementptr %"compiler/effects:fpath", ptr %l80, i32 0, i32 0
  %t158 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t157, i32 0, i32 0
  store { i64, ptr } %t156, ptr %t158, !tbaa !27
  %t159 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t159, label %bb36, label %bb37
bb36:
  %t161 = getelementptr %"compiler/effects:fpath", ptr %l80, i32 0, i32 0
  %t162 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t161, i32 0, i32 0
  %t163 = load { i64, ptr }, ptr %t162, !tbaa !27
  %t164 = extractvalue { i64, ptr } %t163, 0
  %t166 = icmp eq i64 %t164, 0
  br i1 %t166, label %bb38, label %bb39
bb37:
  %t168 = load %"compiler/effects:fpath", ptr %l80
  store %"compiler/effects:fpath" %t168, ptr %l12
  store ptr %l2, ptr %l89, !tbaa !29
  %t169 = load i64, ptr %l9, !tbaa !24
  %t170 = getelementptr %"compiler/effects:fpath", ptr %l12, i32 0, i32 0
  %t171 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t170
  %t172 = getelementptr %"compiler/effects:fpath", ptr %l12, i32 0, i32 1
  %t173 = load i32, ptr %t172, !tbaa !23
  %t177 = call %"compiler/effects:fslot" @compiler_2feffects_3afslot_2ector(ptr %s5, ptr %s5, i64 %t169, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t171, i32 %t173)
  store %"compiler/effects:fslot" %t177, ptr %l93
  br label %bb40
bb38:
  %t178 = getelementptr %"compiler/effects:fpath", ptr %l80, i32 0, i32 0
  %t179 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t178, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t179, !tbaa !27
  br label %bb39
bb39:
  %t180 = getelementptr %"compiler/effects:fpath", ptr %l80, i32 0, i32 0
  %t181 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t180, i32 0, i32 0
  %t182 = load i64, ptr %l81
  %t183 = inttoptr i64 %t182 to ptr
  %t184 = load { i64, ptr }, ptr %t181
  %t185 = extractvalue { i64, ptr } %t184, 1
  %t186 = call ptr @__olang_region_or(ptr %t185, ptr null)
  %t187 = icmp ne ptr %t186, null
  %t188 = select i1 %t187, ptr %t186, ptr null
  call void @__olang_region_settle_in(ptr %t183, ptr %t188)
  br label %bb37
bb40:
  %t190 = call %"compiler/effects:fslot" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2feffects_3afslot(ptr %s5, ptr %l93)
  store %"compiler/effects:fslot" %t190, ptr %l95
  br label %bb41
bb41:
  %t191 = load ptr, ptr %l89, !tbaa !29
  %t192 = load %"compiler/effects:fslot", ptr %l95
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3afslot_3e_2ePush_3ccompiler_2feffects_3afslot_3e(ptr %v1, ptr %s5, ptr %t191, %"compiler/effects:fslot" %t192)
  br label %bb42
bb42:
  call void @__olang_scope_close(ptr %s5)
  br label %bb43
bb43:
  %t193 = load i64, ptr %l11, !tbaa !24
  %t196 = add i64 %t193, 1
  store i64 %t196, ptr %l11, !tbaa !24
  br label %bb28
bb44:
  call void @__olang_scope_close(ptr %s4)
  br label %bb45
bb45:
  %t198 = load i64, ptr %l8, !tbaa !24
  %t201 = add i64 %t198, 1
  store i64 %t201, ptr %l8, !tbaa !24
  br label %bb20
bb46:
  %t203 = load ptr, ptr %l0, !tbaa !29
  %t205 = getelementptr %"compiler/effects:Effects", ptr %t203, i32 0, i32 64
  store ptr %t205, ptr %l103, !tbaa !29
  %t206 = load i64, ptr %l1, !tbaa !24
  store i64 %t206, ptr %l104, !tbaa !24
  %t207 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t207, ptr %l105
  %t209 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3afslot_3e(ptr %s0, ptr %l105)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t209, ptr %l107
  br label %bb47
bb47:
  %t210 = load ptr, ptr %l103, !tbaa !29
  %t211 = load i64, ptr %l104, !tbaa !24
  %t212 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l107
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cc_Hafeff049746af34a0f4960f24da5119b(ptr %v0, ptr %s0, ptr %t210, i64 %t211, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t212)
  br label %bb48
bb48:
  %t213 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l2
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t213, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2efinish(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %lp3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca %"compiler/effects:part"
  %l12 = alloca i64
  %l14 = alloca i64
  %l19 = alloca %"compiler/effects:pend"
  %l21 = alloca %"compiler/effects:pend"
  %l29 = alloca i64
  %l31 = alloca i1
  %l46 = alloca i64
  %l48 = alloca i64
  %l53 = alloca ptr
  %l61 = alloca i64
  %l63 = alloca i64
  %l68 = alloca %"compiler/effects:part"
  %l70 = alloca %"compiler/effects:part"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/effects:Effects", ptr %t1, i32 0, i32 37
  store ptr %t3, ptr %l1, !tbaa !29
  store i64 0, ptr %l2, !tbaa !24
  br label %bb1
bb1:
  %t5 = load i64, ptr %l2, !tbaa !24
  store i64 %t5, ptr %l12, !tbaa !24
  %t6 = load ptr, ptr %l1, !tbaa !29
  %t8 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3apend_3e_2eLen_3ccompiler_2feffects_3apend_3e(ptr %v0, ptr %t6)
  store i64 %t8, ptr %l14
  br label %bb2
bb2:
  %t9 = load i64, ptr %l12, !tbaa !24
  %t10 = load i64, ptr %l14, !tbaa !24
  %t11 = icmp slt i64 %t9, %t10
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb3, label %bb4
bb3:
  br label %bb10
bb4:
  br label %bb5
bb5:
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t16 = load i64, ptr %l2, !tbaa !24
  %t19 = call %"compiler/effects:pend" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3apend_3e_2eAt_3ccompiler_2feffects_3apend_3e(ptr %v0, ptr %v0, ptr %t15, i64 %t16)
  store %"compiler/effects:pend" %t19, ptr %l19
  br label %bb6
bb6:
  %t21 = call %"compiler/effects:pend" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2feffects_3apend(ptr %v0, ptr %l19)
  store %"compiler/effects:pend" %t21, ptr %l21
  br label %bb7
bb7:
  %t22 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 56, i64 8)
  store ptr %t22, ptr %lp3
  %t23 = load %"compiler/effects:pend", ptr %l21
  %t24 = load ptr, ptr %lp3
  store %"compiler/effects:pend" %t23, ptr %t24
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t26 = load ptr, ptr %lp3
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eresolve(ptr %v0, ptr %v0, ptr %t25, ptr %t26)
  br label %bb8
bb8:
  br label %bb9
bb9:
  %t29 = load i64, ptr %l2, !tbaa !24
  %t32 = add i64 %t29, 1
  store i64 %t32, ptr %l2, !tbaa !24
  br label %bb1
bb10:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/effects:Effects", ptr %t34, i32 0, i32 42
  %t38 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t36)
  store i64 %t38, ptr %l29
  br label %bb11
bb11:
  %t39 = load i64, ptr %l29, !tbaa !24
  %t40 = icmp sgt i64 %t39, 0
  br i1 %t40, label %bb12, label %bb13
bb12:
  store i1 true, ptr %l31, !tbaa !21
  br label %bb14
bb13:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/effects:Effects", ptr %t42, i32 0, i32 43
  %t45 = load i1, ptr %t44, !tbaa !21
  store i1 %t45, ptr %l31, !tbaa !21
  br label %bb14
bb14:
  %t47 = load i1, ptr %l31, !tbaa !21
  br i1 %t47, label %bb15, label %bb16
bb15:
  %t48 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eoutsJudged(ptr %v0, ptr %t48)
  br label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb18
bb18:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/effects:Effects", ptr %t50, i32 0, i32 69
  %t53 = load i1, ptr %t52, !tbaa !21
  br i1 %t53, label %bb19, label %bb20
bb19:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/effects:Effects", ptr %t56, i32 0, i32 35
  %t59 = load i64, ptr %t58, !tbaa !24
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eretFields(ptr %v0, ptr %t55, i64 %t59)
  br label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb22
bb22:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/effects:Effects", ptr %t62, i32 0, i32 45
  %t65 = load i1, ptr %t64, !tbaa !21
  %t67 = xor i1 %t65, true
  br i1 %t67, label %bb23, label %bb24
bb23:
  br label %ret
bb24:
  br label %bb25
bb25:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/effects:Effects", ptr %t69, i32 0, i32 48
  store i1 true, ptr %t71, !tbaa !21
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t74 = getelementptr %"compiler/effects:Effects", ptr %t72, i32 0, i32 46
  store ptr %t74, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb26
bb26:
  %t76 = load i64, ptr %l5, !tbaa !24
  store i64 %t76, ptr %l46, !tbaa !24
  %t77 = load ptr, ptr %l4, !tbaa !29
  %t79 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t77)
  store i64 %t79, ptr %l48
  br label %bb27
bb27:
  %t80 = load i64, ptr %l46, !tbaa !24
  %t81 = load i64, ptr %l48, !tbaa !24
  %t82 = icmp slt i64 %t80, %t81
  %t84 = xor i1 %t82, true
  br i1 %t84, label %bb28, label %bb29
bb28:
  br label %bb51
bb29:
  br label %bb30
bb30:
  %t86 = load ptr, ptr %l4, !tbaa !29
  %t87 = load i64, ptr %l5, !tbaa !24
  %t90 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t86, i64 %t87)
  store ptr %t90, ptr %l53
  br label %bb31
bb31:
  %t91 = load ptr, ptr %l53, !tbaa !29
  store ptr %t91, ptr %l6, !tbaa !29
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"compiler/effects:Effects", ptr %t92, i32 0, i32 38
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3apart_3e_2eClear_3ccompiler_2feffects_3apart_3e(ptr %v0, ptr %t94)
  br label %bb32
bb32:
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t97 = load ptr, ptr %l6, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eclassify(ptr %v0, ptr %v0, ptr %t96, ptr %t97, i64 0)
  br label %bb33
bb33:
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t103 = getelementptr %"compiler/effects:Effects", ptr %t101, i32 0, i32 38
  store ptr %t103, ptr %l7, !tbaa !29
  store i64 0, ptr %l8, !tbaa !24
  br label %bb34
bb34:
  %t105 = load i64, ptr %l8, !tbaa !24
  store i64 %t105, ptr %l61, !tbaa !24
  %t106 = load ptr, ptr %l7, !tbaa !29
  %t108 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3apart_3e_2eLen_3ccompiler_2feffects_3apart_3e(ptr %v0, ptr %t106)
  store i64 %t108, ptr %l63
  br label %bb35
bb35:
  %t109 = load i64, ptr %l61, !tbaa !24
  %t110 = load i64, ptr %l63, !tbaa !24
  %t111 = icmp slt i64 %t109, %t110
  %t113 = xor i1 %t111, true
  br i1 %t113, label %bb36, label %bb37
bb36:
  br label %bb49
bb37:
  br label %bb38
bb38:
  %t115 = load ptr, ptr %l7, !tbaa !29
  %t116 = load i64, ptr %l8, !tbaa !24
  %t119 = call %"compiler/effects:part" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3apart_3e_2eAt_3ccompiler_2feffects_3apart_3e(ptr %v0, ptr %v0, ptr %t115, i64 %t116)
  store %"compiler/effects:part" %t119, ptr %l68
  br label %bb39
bb39:
  %t121 = call %"compiler/effects:part" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2feffects_3apart(ptr %v0, ptr %l68)
  store %"compiler/effects:part" %t121, ptr %l70
  br label %bb40
bb40:
  %t122 = load %"compiler/effects:part", ptr %l70
  store %"compiler/effects:part" %t122, ptr %l9
  %t123 = getelementptr %"compiler/effects:part", ptr %l9, i32 0, i32 0
  %t124 = load i64, ptr %t123, !tbaa !24
  %t125 = load i64, ptr @G_2ecompiler_2feffects_2eGivNamed, !tbaa !24
  %t128 = icmp eq i64 %t124, %t125
  br i1 %t128, label %bb41, label %bb42
bb41:
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t132 = getelementptr %"compiler/effects:Effects", ptr %t130, i32 0, i32 47
  %t133 = getelementptr %"compiler/effects:part", ptr %l9, i32 0, i32 1
  %t134 = load i64, ptr %t133, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t132, i64 %t134)
  br label %bb43
bb42:
  %t137 = getelementptr %"compiler/effects:part", ptr %l9, i32 0, i32 0
  %t138 = load i64, ptr %t137, !tbaa !24
  %t139 = load i64, ptr @G_2ecompiler_2feffects_2eGivMade, !tbaa !24
  %t142 = icmp ne i64 %t138, %t139
  br i1 %t142, label %bb44, label %bb45
bb43:
  br label %bb47
bb44:
  %t144 = load ptr, ptr %l0, !tbaa !29
  %t146 = getelementptr %"compiler/effects:Effects", ptr %t144, i32 0, i32 48
  store i1 false, ptr %t146, !tbaa !21
  br label %bb46
bb45:
  br label %bb46
bb46:
  br label %bb47
bb47:
  br label %bb48
bb48:
  %t147 = load i64, ptr %l8, !tbaa !24
  %t150 = add i64 %t147, 1
  store i64 %t150, ptr %l8, !tbaa !24
  br label %bb34
bb49:
  br label %bb50
bb50:
  %t152 = load i64, ptr %l5, !tbaa !24
  %t155 = add i64 %t152, 1
  store i64 %t155, ptr %l5, !tbaa !24
  br label %bb26
bb51:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2efnVal(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca ptr
  %l13 = alloca i32
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca i1
  %l19 = alloca ptr
  %l20 = alloca i1
  %l38 = alloca { i64, ptr }
  %l50 = alloca i64
  %l63 = alloca { i64, ptr }
  %l66 = alloca ptr
  %l69 = alloca i32
  %l70 = alloca i1
  %l72 = alloca ptr
  %l73 = alloca i64
  %l80 = alloca i64
  %l83 = alloca %"compiler/effects:pend"
  %l87 = alloca ptr
  %l88 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l15, !tbaa !29
  store i1 false, ptr %l16, !tbaa !21
  %t2 = load ptr, ptr %l15, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l15, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 3}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l16, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l16, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb6
bb5:
  br label %bb47
bb6:
  %t10 = load ptr, ptr %l1, !tbaa !29
  store ptr %t10, ptr %l19, !tbaa !29
  store i1 false, ptr %l20, !tbaa !21
  %t11 = load ptr, ptr %l19, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb7, label %bb8
bb7:
  %t14 = load ptr, ptr %l19, !tbaa !29
  %t15 = load i64, ptr %t14, !range !{i64 0, i64 3}
  %t17 = icmp eq i64 %t15, 1
  store i1 %t17, ptr %l20, !tbaa !21
  br label %bb8
bb8:
  %t18 = load i1, ptr %l20, !tbaa !21
  br i1 %t18, label %bb9, label %bb10
bb9:
  %t19 = load ptr, ptr %l1, !tbaa !29
  %t21 = getelementptr { i64, [4 x i64] }, ptr %t19, i32 0, i32 1
  %t22 = getelementptr { i32, { i64, ptr }, i32 }, ptr %t21, i32 0, i32 0
  %t23 = load i32, ptr %t22
  store i32 %t23, ptr %l2, !tbaa !23
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr { i64, [4 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { i32, { i64, ptr }, i32 }, ptr %t27, i32 0, i32 1
  %t29 = load { i64, ptr }, ptr %t28
  store { i64, ptr } %t29, ptr %l3, !tbaa !27
  br label %bb11
bb10:
  br label %bb38
bb11:
  %t31 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t33 = extractvalue { i64, ptr } %t31, 0
  %t35 = icmp sgt i64 %t33, 0
  br i1 %t35, label %bb12, label %bb13
bb12:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/effects:Effects", ptr %t37, i32 0, i32 25
  %t40 = getelementptr %"compiler/effects:Facts", ptr %t39, i32 0, i32 0
  store i1 true, ptr %t40, !tbaa !21
  br label %bb14
bb13:
  br label %bb14
bb14:
  %t41 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t41, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t43 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t45 = extractvalue { i64, ptr } %t43, 0
  store i64 %t45, ptr %l6, !tbaa !24
  br label %bb15
bb15:
  %t47 = load i64, ptr %l5, !tbaa !24
  %t48 = load i64, ptr %l6, !tbaa !24
  %t51 = icmp slt i64 %t47, %t48
  %t53 = xor i1 %t51, true
  br i1 %t53, label %bb16, label %bb17
bb16:
  br label %bb21
bb17:
  br label %bb18
bb18:
  %t55 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t55, ptr %l38, !tbaa !27
  %t56 = load i64, ptr %l5, !tbaa !24
  %t58 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !27
  %t60 = getelementptr ptr, ptr %t59, i64 %t56
  %t61 = load ptr, ptr %t60, !tbaa !39
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/typed:Capture", ptr %t61, i32 0, i32 1
  %t67 = load ptr, ptr %t66, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eexpr(ptr %v0, ptr %v1, ptr %t63, ptr %t67)
  br label %bb19
bb19:
  br label %bb20
bb20:
  %t71 = load i64, ptr %l5, !tbaa !24
  %t74 = add i64 %t71, 1
  store i64 %t74, ptr %l5, !tbaa !24
  br label %bb15
bb21:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"compiler/effects:Effects", ptr %t76, i32 0, i32 26
  %t80 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t78)
  store i64 %t80, ptr %l50
  br label %bb22
bb22:
  %t81 = load i64, ptr %l50, !tbaa !24
  store i64 %t81, ptr %l8, !tbaa !24
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/effects:Effects", ptr %t82, i32 0, i32 26
  %t85 = load i32, ptr %l2, !tbaa !23
  %t87 = sext i32 %t85 to i64
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t84, i64 %t87)
  br label %bb23
bb23:
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t92 = getelementptr %"compiler/effects:Effects", ptr %t90, i32 0, i32 44
  store i1 true, ptr %t92, !tbaa !21
  %t93 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t93, ptr %l9, !tbaa !27
  store i64 0, ptr %l10, !tbaa !24
  %t95 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t97 = extractvalue { i64, ptr } %t95, 0
  store i64 %t97, ptr %l11, !tbaa !24
  br label %bb24
bb24:
  %t99 = load i64, ptr %l10, !tbaa !24
  %t100 = load i64, ptr %l11, !tbaa !24
  %t103 = icmp slt i64 %t99, %t100
  %t105 = xor i1 %t103, true
  br i1 %t105, label %bb25, label %bb26
bb25:
  br label %bb37
bb26:
  br label %bb27
bb27:
  %t107 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t107, ptr %l63, !tbaa !27
  %t108 = load i64, ptr %l10, !tbaa !24
  %t110 = getelementptr { i64, ptr }, ptr %l63, i32 0, i32 1
  %t111 = load ptr, ptr %t110, !tbaa !27
  %t112 = getelementptr ptr, ptr %t111, i64 %t108
  %t113 = load ptr, ptr %t112, !tbaa !39
  store ptr %t113, ptr %l12, !tbaa !29
  %t115 = load ptr, ptr %l0, !tbaa !29
  store ptr %t115, ptr %l66, !tbaa !29
  %t116 = load ptr, ptr %l12, !tbaa !29
  %t118 = getelementptr %"compiler/typed:Capture", ptr %t116, i32 0, i32 1
  %t119 = load ptr, ptr %t118, !tbaa !29
  %t121 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t119)
  store i32 %t121, ptr %l69
  br label %bb28
bb28:
  %t122 = load ptr, ptr %l66, !tbaa !29
  %t123 = load i32, ptr %l69, !tbaa !23
  %t124 = call i1 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eisFn(ptr %v0, ptr %t122, i32 %t123)
  store i1 %t124, ptr %l70
  br label %bb29
bb29:
  %t125 = load i1, ptr %l70, !tbaa !21
  br i1 %t125, label %bb30, label %bb31
bb30:
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t128 = getelementptr %"compiler/effects:Effects", ptr %t126, i32 0, i32 37
  store ptr %t128, ptr %l72, !tbaa !29
  %t129 = load i64, ptr %l8, !tbaa !24
  store i64 %t129, ptr %l73, !tbaa !24
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t131 = load i32, ptr %l2, !tbaa !23
  %t133 = sext i32 %t131 to i64
  %t134 = load ptr, ptr %l12, !tbaa !29
  %t136 = getelementptr %"compiler/typed:Capture", ptr %t134, i32 0, i32 0
  %t137 = load i32, ptr %t136, !tbaa !23
  %t139 = sext i32 %t137 to i64
  %t143 = call i64 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ecaptureSlot(ptr %v0, ptr %t130, i64 %t133, i64 %t139)
  store i64 %t143, ptr %l80
  br label %bb32
bb31:
  br label %bb35
bb32:
  %t144 = load ptr, ptr %l12, !tbaa !29
  %t146 = getelementptr %"compiler/typed:Capture", ptr %t144, i32 0, i32 1
  %t147 = load ptr, ptr %t146, !tbaa !29
  %t148 = load i64, ptr %l73, !tbaa !24
  %t149 = load i64, ptr %l80, !tbaa !24
  %t151 = call %"compiler/effects:pend" @compiler_2feffects_3apend_2ector(ptr %v1, ptr %v0, i64 %t148, i64 %t149, ptr %t147)
  store %"compiler/effects:pend" %t151, ptr %l83
  br label %bb33
bb33:
  %t152 = load ptr, ptr %l72, !tbaa !29
  %t153 = load %"compiler/effects:pend", ptr %l83
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3apend_3e_2ePush_3ccompiler_2feffects_3apend_3e(ptr %v0, ptr %v0, ptr %t152, %"compiler/effects:pend" %t153)
  br label %bb34
bb34:
  br label %bb35
bb35:
  br label %bb36
bb36:
  %t154 = load i64, ptr %l10, !tbaa !24
  %t157 = add i64 %t154, 1
  store i64 %t157, ptr %l10, !tbaa !24
  br label %bb24
bb37:
  br label %bb47
bb38:
  %t159 = load ptr, ptr %l1, !tbaa !29
  store ptr %t159, ptr %l87, !tbaa !29
  store i1 false, ptr %l88, !tbaa !21
  %t160 = load ptr, ptr %l87, !tbaa !29
  %t161 = icmp ne ptr %t160, null
  br i1 %t161, label %bb39, label %bb40
bb39:
  %t163 = load ptr, ptr %l87, !tbaa !29
  %t164 = load i64, ptr %t163, !range !{i64 0, i64 3}
  %t166 = icmp eq i64 %t164, 2
  store i1 %t166, ptr %l88, !tbaa !21
  br label %bb40
bb40:
  %t167 = load i1, ptr %l88, !tbaa !21
  br i1 %t167, label %bb41, label %bb42
bb41:
  %t168 = load ptr, ptr %l1, !tbaa !29
  %t170 = getelementptr { i64, [4 x i64] }, ptr %t168, i32 0, i32 1
  %t171 = getelementptr { i32, ptr, i32 }, ptr %t170, i32 0, i32 0
  %t172 = load i32, ptr %t171
  store i32 %t172, ptr %l13, !tbaa !23
  %t174 = load ptr, ptr %l1, !tbaa !29
  %t176 = getelementptr { i64, [4 x i64] }, ptr %t174, i32 0, i32 1
  %t177 = getelementptr { i32, ptr, i32 }, ptr %t176, i32 0, i32 1
  %t178 = load ptr, ptr %t177
  store ptr %t178, ptr %l14, !tbaa !29
  br label %bb43
bb42:
  br label %bb46
bb43:
  %t180 = load ptr, ptr %l0, !tbaa !29
  %t182 = getelementptr %"compiler/effects:Effects", ptr %t180, i32 0, i32 44
  store i1 true, ptr %t182, !tbaa !21
  %t183 = load ptr, ptr %l0, !tbaa !29
  %t185 = getelementptr %"compiler/effects:Effects", ptr %t183, i32 0, i32 25
  %t186 = getelementptr %"compiler/effects:Facts", ptr %t185, i32 0, i32 0
  store i1 true, ptr %t186, !tbaa !21
  %t187 = load ptr, ptr %l0, !tbaa !29
  %t188 = load ptr, ptr %l14, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eexpr(ptr %v0, ptr %v1, ptr %t187, ptr %t188)
  br label %bb44
bb44:
  %t192 = load ptr, ptr %l0, !tbaa !29
  %t194 = getelementptr %"compiler/effects:Effects", ptr %t192, i32 0, i32 26
  %t195 = load i32, ptr %l13, !tbaa !23
  %t197 = sext i32 %t195 to i64
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t194, i64 %t197)
  br label %bb45
bb45:
  br label %bb47
bb46:
  call void @__olang_check_failed(ptr @olang_loc_d8634726df7208f7_383307572af5b0b3)
  unreachable
bb47:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2egrow(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca { i64, [2 x i64] }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l17 = alloca i64
  %l20 = alloca i64
  %l24 = alloca ptr
  %l25 = alloca %"compiler/effects:Facts"
  %l27 = alloca ptr
  %l28 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l30 = alloca ptr
  %l31 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l33 = alloca ptr
  %l34 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l36 = alloca ptr
  %l37 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l39 = alloca ptr
  %l40 = alloca %"compiler/effects:Facts"
  %l63 = alloca i64
  %l67 = alloca i64
  %l70 = alloca i64
  %l91 = alloca ptr
  %l106 = alloca i64
  %l112 = alloca i64
  %l116 = alloca i64
  %l119 = alloca i64
  %l142 = alloca ptr
  %l147 = alloca ptr
  %l153 = alloca ptr
  %s1 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/effects:Effects", ptr %t1, i32 0, i32 17
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l17
  br label %bb2
bb2:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/effects:Effects", ptr %t6, i32 0, i32 1
  %t10 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %t8)
  store i64 %t10, ptr %l20
  br label %bb3
bb3:
  %t11 = load i64, ptr %l17, !tbaa !24
  %t12 = load i64, ptr %l20, !tbaa !24
  %t13 = icmp slt i64 %t11, %t12
  %t15 = xor i1 %t13, true
  br i1 %t15, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s1)
  br label %bb28
bb5:
  br label %bb6
bb6:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/effects:Effects", ptr %t17, i32 0, i32 3
  store ptr %t19, ptr %l24, !tbaa !29
  %t20 = call %"compiler/effects:Facts" @compiler_2feffects_3aFacts_2ector(ptr %s1)
  store %"compiler/effects:Facts" %t20, ptr %l25
  br label %bb7
bb7:
  %t21 = load ptr, ptr %l24, !tbaa !29
  %t22 = load %"compiler/effects:Facts", ptr %l25
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3aFacts_3e_2ePush_3ccompiler_2feffects_3aFacts_3e(ptr %v0, ptr %t21, %"compiler/effects:Facts" %t22)
  br label %bb8
bb8:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/effects:Effects", ptr %t23, i32 0, i32 4
  store ptr %t25, ptr %l27, !tbaa !29
  %t26 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3aGlobalAt_3e_2ector(ptr %s1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t26, ptr %l28
  br label %bb9
bb9:
  %t27 = load ptr, ptr %l27, !tbaa !29
  %t28 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l28
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3ccompiler_2_Hdcca521946d79d494efe15f7d0a69330(ptr %v0, ptr %s1, ptr %t27, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t28)
  br label %bb10
bb10:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/effects:Effects", ptr %t29, i32 0, i32 6
  store ptr %t31, ptr %l30, !tbaa !29
  %t32 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t32, ptr %l31
  br label %bb11
bb11:
  %t33 = load ptr, ptr %l30, !tbaa !29
  %t34 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l31
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__H5a6912247a81ac1f46c16a43fcc4c44a(ptr %v0, ptr %s1, ptr %t33, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t34)
  br label %bb12
bb12:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/effects:Effects", ptr %t35, i32 0, i32 7
  store ptr %t37, ptr %l33, !tbaa !29
  %t38 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t38, ptr %l34
  br label %bb13
bb13:
  %t39 = load ptr, ptr %l33, !tbaa !29
  %t40 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l34
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__H5a6912247a81ac1f46c16a43fcc4c44a(ptr %v0, ptr %s1, ptr %t39, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t40)
  br label %bb14
bb14:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/effects:Effects", ptr %t41, i32 0, i32 8
  store ptr %t43, ptr %l36, !tbaa !29
  %t44 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3alink_3e_2ector(ptr %s1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t44, ptr %l37
  br label %bb15
bb15:
  %t45 = load ptr, ptr %l36, !tbaa !29
  %t46 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l37
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3ccompiler_2_H691765597a1d0d55e0f84306543aa643(ptr %v0, ptr %s1, ptr %t45, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t46)
  br label %bb16
bb16:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/effects:Effects", ptr %t47, i32 0, i32 11
  store ptr %t49, ptr %l39, !tbaa !29
  %t50 = call %"compiler/effects:Facts" @compiler_2feffects_3aFacts_2ector(ptr %s1)
  store %"compiler/effects:Facts" %t50, ptr %l40
  br label %bb17
bb17:
  %t51 = load ptr, ptr %l39, !tbaa !29
  %t52 = load %"compiler/effects:Facts", ptr %l40
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3aFacts_3e_2ePush_3ccompiler_2feffects_3aFacts_3e(ptr %v0, ptr %t51, %"compiler/effects:Facts" %t52)
  br label %bb18
bb18:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/effects:Effects", ptr %t53, i32 0, i32 12
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t55, i64 0)
  br label %bb19
bb19:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/effects:Effects", ptr %t57, i32 0, i32 13
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t59, i64 -1)
  br label %bb20
bb20:
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = getelementptr %"compiler/effects:Effects", ptr %t61, i32 0, i32 14
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t63, i64 -1)
  br label %bb21
bb21:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/effects:Effects", ptr %t65, i32 0, i32 16
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t67, i1 false)
  br label %bb22
bb22:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/effects:Effects", ptr %t69, i32 0, i32 17
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t71, i64 0)
  br label %bb23
bb23:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/effects:Effects", ptr %t73, i32 0, i32 20
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t75, i64 -1)
  br label %bb24
bb24:
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/effects:Effects", ptr %t77, i32 0, i32 21
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t79, i64 0)
  br label %bb25
bb25:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"compiler/effects:Effects", ptr %t81, i32 0, i32 22
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t83, i1 false)
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s1)
  br label %bb27
bb27:
  br label %bb1
bb28:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"compiler/effects:Effects", ptr %t85, i32 0, i32 54
  %t88 = load i1, ptr %t87, !tbaa !21
  %t90 = xor i1 %t88, true
  br i1 %t90, label %bb29, label %bb30
bb29:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"compiler/effects:Effects", ptr %t92, i32 0, i32 54
  store i1 true, ptr %t94, !tbaa !21
  store i64 0, ptr %l1, !tbaa !24
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t97 = getelementptr %"compiler/effects:Effects", ptr %t95, i32 0, i32 1
  %t99 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %t97)
  store i64 %t99, ptr %l63
  br label %bb31
bb30:
  br label %bb49
bb31:
  %t100 = load i64, ptr %l63, !tbaa !24
  store i64 %t100, ptr %l2, !tbaa !24
  store i64 1, ptr %l3, !tbaa !24
  %t101 = load i64, ptr %l2, !tbaa !24
  %t102 = load i64, ptr %l1, !tbaa !24
  %t105 = icmp sgt i64 %t101, %t102
  br i1 %t105, label %bb32, label %bb33
bb32:
  %t107 = load i64, ptr %l3, !tbaa !24
  %t109 = icmp sgt i64 %t107, 0
  br i1 %t109, label %bb34, label %bb35
bb33:
  store i64 0, ptr %l67, !tbaa !24
  br label %bb37
bb34:
  %t111 = load i64, ptr %l2, !tbaa !24
  %t112 = load i64, ptr %l1, !tbaa !24
  %t115 = sub i64 %t111, %t112
  %t116 = load i64, ptr %l3, !tbaa !24
  %t119 = add i64 %t115, %t116
  %t121 = sub i64 %t119, 1
  %t122 = load i64, ptr %l3, !tbaa !24
  %t125 = sdiv i64 %t121, %t122
  store i64 %t125, ptr %l70, !tbaa !24
  br label %bb36
bb35:
  store i64 0, ptr %l70, !tbaa !24
  br label %bb36
bb36:
  %t127 = load i64, ptr %l70, !tbaa !24
  store i64 %t127, ptr %l67, !tbaa !24
  br label %bb37
bb37:
  %t128 = load i64, ptr %l67, !tbaa !24
  store i64 %t128, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb38
bb38:
  %t129 = load i64, ptr %l5, !tbaa !24
  %t130 = load i64, ptr %l4, !tbaa !24
  %t133 = icmp slt i64 %t129, %t130
  %t135 = xor i1 %t133, true
  br i1 %t135, label %bb39, label %bb40
bb39:
  br label %bb48
bb40:
  br label %bb41
bb41:
  %t137 = load i64, ptr %l1, !tbaa !24
  %t138 = load i64, ptr %l5, !tbaa !24
  %t139 = load i64, ptr %l3, !tbaa !24
  %t142 = mul i64 %t138, %t139
  %t145 = add i64 %t137, %t142
  store i64 %t145, ptr %l6, !tbaa !24
  %t147 = load ptr, ptr %l0, !tbaa !29
  %t149 = getelementptr %"compiler/effects:Effects", ptr %t147, i32 0, i32 1
  %t150 = load i64, ptr %l6, !tbaa !24
  %t153 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t149, i64 %t150)
  store ptr %t153, ptr %l91
  br label %bb42
bb42:
  %t154 = load ptr, ptr %l91, !tbaa !29
  %t156 = getelementptr %"compiler/typed:Body", ptr %t154, i32 0, i32 1
  %t157 = load { i64, [2 x i64] }, ptr %t156
  store { i64, [2 x i64] } %t157, ptr %l7
  %t159 = load { i64, [2 x i64] }, ptr %l7
  %t161 = extractvalue { i64, [2 x i64] } %t159, 0
  %t162 = icmp eq i64 %t161, 3
  br i1 %t162, label %bb43, label %bb44
bb43:
  %t164 = getelementptr { i64, [2 x i64] }, ptr %l7, i32 0, i32 1
  %t165 = getelementptr { i32 }, ptr %t164, i32 0, i32 0
  %t166 = load i32, ptr %t165
  %t168 = load ptr, ptr %l0, !tbaa !29
  %t170 = getelementptr %"compiler/effects:Effects", ptr %t168, i32 0, i32 56
  %t172 = load i64, ptr %l6, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e__Hccd9659a44f570da1fa06b019882a84d(ptr %v0, ptr %t170, i32 %t166, i64 %t172)
  br label %bb45
bb44:
  br label %bb46
bb45:
  br label %bb46
bb46:
  br label %bb47
bb47:
  %t176 = load i64, ptr %l5, !tbaa !24
  %t179 = add i64 %t176, 1
  store i64 %t179, ptr %l5, !tbaa !24
  br label %bb38
bb48:
  br label %bb49
bb49:
  %t181 = load ptr, ptr %l0, !tbaa !29
  %t183 = getelementptr %"compiler/effects:Effects", ptr %t181, i32 0, i32 18
  %t185 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eLen_3cI64_2c_20I64_3e(ptr %v0, ptr %t183)
  store i64 %t185, ptr %l106
  br label %bb50
bb50:
  %t186 = load i64, ptr %l106, !tbaa !24
  %t187 = icmp eq i64 %t186, 0
  br i1 %t187, label %bb51, label %bb52
bb51:
  store i64 0, ptr %l9, !tbaa !24
  %t189 = load ptr, ptr %l0, !tbaa !29
  %t191 = getelementptr %"compiler/effects:Effects", ptr %t189, i32 0, i32 0
  %t192 = load ptr, ptr %t191, !tbaa !29
  %t194 = getelementptr %"compiler/generic:Program", ptr %t192, i32 0, i32 0
  %t195 = load ptr, ptr %t194, !tbaa !29
  %t197 = getelementptr %"compiler/load:Loader", ptr %t195, i32 0, i32 10
  %t199 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %t197)
  store i64 %t199, ptr %l112
  br label %bb53
bb52:
  br label %bb72
bb53:
  %t200 = load i64, ptr %l112, !tbaa !24
  store i64 %t200, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t201 = load i64, ptr %l10, !tbaa !24
  %t202 = load i64, ptr %l9, !tbaa !24
  %t205 = icmp sgt i64 %t201, %t202
  br i1 %t205, label %bb54, label %bb55
bb54:
  %t207 = load i64, ptr %l11, !tbaa !24
  %t209 = icmp sgt i64 %t207, 0
  br i1 %t209, label %bb56, label %bb57
bb55:
  store i64 0, ptr %l116, !tbaa !24
  br label %bb59
bb56:
  %t211 = load i64, ptr %l10, !tbaa !24
  %t212 = load i64, ptr %l9, !tbaa !24
  %t215 = sub i64 %t211, %t212
  %t216 = load i64, ptr %l11, !tbaa !24
  %t219 = add i64 %t215, %t216
  %t221 = sub i64 %t219, 1
  %t222 = load i64, ptr %l11, !tbaa !24
  %t225 = sdiv i64 %t221, %t222
  store i64 %t225, ptr %l119, !tbaa !24
  br label %bb58
bb57:
  store i64 0, ptr %l119, !tbaa !24
  br label %bb58
bb58:
  %t227 = load i64, ptr %l119, !tbaa !24
  store i64 %t227, ptr %l116, !tbaa !24
  br label %bb59
bb59:
  %t228 = load i64, ptr %l116, !tbaa !24
  store i64 %t228, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb60
bb60:
  %t229 = load i64, ptr %l13, !tbaa !24
  %t230 = load i64, ptr %l12, !tbaa !24
  %t233 = icmp slt i64 %t229, %t230
  %t235 = xor i1 %t233, true
  br i1 %t235, label %bb61, label %bb62
bb61:
  br label %bb71
bb62:
  br label %bb63
bb63:
  %t237 = load i64, ptr %l9, !tbaa !24
  %t238 = load i64, ptr %l13, !tbaa !24
  %t239 = load i64, ptr %l11, !tbaa !24
  %t242 = mul i64 %t238, %t239
  %t245 = add i64 %t237, %t242
  store i64 %t245, ptr %l14, !tbaa !24
  %t247 = load ptr, ptr %l0, !tbaa !29
  %t249 = getelementptr %"compiler/effects:Effects", ptr %t247, i32 0, i32 0
  %t250 = load ptr, ptr %t249, !tbaa !29
  %t252 = getelementptr %"compiler/generic:Program", ptr %t250, i32 0, i32 0
  %t253 = load ptr, ptr %t252, !tbaa !29
  %t255 = getelementptr %"compiler/load:Loader", ptr %t253, i32 0, i32 10
  %t256 = load i64, ptr %l14, !tbaa !24
  %t259 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t255, i64 %t256)
  store ptr %t259, ptr %l142
  br label %bb64
bb64:
  %t260 = load ptr, ptr %l142, !tbaa !29
  %t262 = getelementptr %"compiler/load:Module", ptr %t260, i32 0, i32 4
  %t263 = load i64, ptr %t262, !tbaa !24
  %t265 = icmp sge i64 %t263, 0
  br i1 %t265, label %bb65, label %bb66
bb65:
  %t267 = load ptr, ptr %l0, !tbaa !29
  %t269 = getelementptr %"compiler/effects:Effects", ptr %t267, i32 0, i32 18
  store ptr %t269, ptr %l147, !tbaa !29
  %t270 = load ptr, ptr %l0, !tbaa !29
  %t272 = getelementptr %"compiler/effects:Effects", ptr %t270, i32 0, i32 0
  %t273 = load ptr, ptr %t272, !tbaa !29
  %t275 = getelementptr %"compiler/generic:Program", ptr %t273, i32 0, i32 0
  %t276 = load ptr, ptr %t275, !tbaa !29
  %t278 = getelementptr %"compiler/load:Loader", ptr %t276, i32 0, i32 10
  %t279 = load i64, ptr %l14, !tbaa !24
  %t282 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t278, i64 %t279)
  store ptr %t282, ptr %l153
  br label %bb67
bb66:
  br label %bb69
bb67:
  %t283 = load ptr, ptr %l153, !tbaa !29
  %t285 = getelementptr %"compiler/load:Module", ptr %t283, i32 0, i32 4
  %t286 = load i64, ptr %t285, !tbaa !24
  %t287 = load i64, ptr %l14, !tbaa !24
  %t288 = load ptr, ptr %l147, !tbaa !29
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t288, i64 %t286, i64 %t287)
  br label %bb68
bb68:
  br label %bb69
bb69:
  br label %bb70
bb70:
  %t291 = load i64, ptr %l13, !tbaa !24
  %t294 = add i64 %t291, 1
  store i64 %t294, ptr %l13, !tbaa !24
  br label %bb60
bb71:
  br label %bb72
bb72:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eholds(ptr %v0, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l5 = alloca i1
  %l6 = alloca i1
  %l12 = alloca i1
  %l16 = alloca i1
  %l17 = alloca i32
  %l18 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l26 = alloca i32
  %l29 = alloca i1
  %l33 = alloca i1
  %s1 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = shl i64 %t1, 32
  %t4 = load i32, ptr %l2, !tbaa !23
  %t6 = sext i32 %t4 to i64
  %t9 = or i64 %t3, %t6
  store i64 %t9, ptr %l3, !tbaa !24
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/effects:Effects", ptr %t11, i32 0, i32 60
  %t14 = load i64, ptr %l3, !tbaa !24
  %t17 = call { i32, i1 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eGet_3cI64_2c_20Bool_3e(ptr %v0, ptr %t13, i64 %t14)
  %t18 = extractvalue { i32, i1 } %t17, 1
  %t19 = extractvalue { i32, i1 } %t17, 0
  store i32 %t19, ptr %l17
  %t20 = icmp ne i32 %t19, 0
  br i1 %t20, label %bb2, label %ok.21, !prof !99
ok.21:
  store i1 %t18, ptr %l16
  br label %bb1
bb1:
  %t22 = load i1, ptr %l16, !tbaa !21
  store i1 %t22, ptr %l12, !tbaa !21
  br label %bb14
bb2:
  br label %bb3
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t23 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %s1)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t23, ptr %l18
  br label %bb4
bb4:
  %t24 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l18
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t24, ptr %l4
  store i1 true, ptr %l5, !tbaa !21
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/effects:Effects", ptr %t25, i32 0, i32 0
  %t28 = load ptr, ptr %t27, !tbaa !29
  %t30 = getelementptr %"compiler/generic:Program", ptr %t28, i32 0, i32 2
  %t31 = load i64, ptr %l1, !tbaa !24
  %t33 = trunc i64 %t31 to i32
  %t38 = call i32 @compiler_2feffects_2eheldIn(ptr %v0, ptr %s1, ptr %t30, i32 %t33, ptr %l4, i64 0)
  store i32 %t38, ptr %l26
  %t39 = icmp ne i32 %t38, 0
  br i1 %t39, label %bb6, label %ok.40, !prof !99
ok.40:
  br label %bb5
bb5:
  br label %bb8
bb6:
  br label %bb7
bb7:
  store i1 false, ptr %l5, !tbaa !21
  br label %bb8
bb8:
  %t41 = load i1, ptr %l5, !tbaa !21
  %t43 = xor i1 %t41, true
  br i1 %t43, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l29, !tbaa !21
  br label %bb12
bb10:
  %t45 = load i32, ptr %l2, !tbaa !23
  %t47 = sext i32 %t45 to i64
  %t50 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %s1, ptr %l4, i64 %t47)
  store i1 %t50, ptr %l33
  br label %bb11
bb11:
  %t51 = load i1, ptr %l33, !tbaa !21
  store i1 %t51, ptr %l29, !tbaa !21
  br label %bb12
bb12:
  %t52 = load i1, ptr %l29, !tbaa !21
  store i1 %t52, ptr %l6, !tbaa !21
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/effects:Effects", ptr %t53, i32 0, i32 60
  %t56 = load i64, ptr %l3, !tbaa !24
  %t57 = load i1, ptr %l6, !tbaa !21
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t55, i64 %t56, i1 %t57)
  br label %bb13
bb13:
  %t61 = load i1, ptr %l6, !tbaa !21
  call void @__olang_scope_close(ptr %s1)
  store i1 %t61, ptr %rv
  br label %ret
bb14:
  %t63 = load i1, ptr %l12, !tbaa !21
  store i1 %t63, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2einPlace(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i32
  %l10 = alloca i1
  %l20 = alloca i32
  %l25 = alloca i1
  %l26 = alloca i1
  %l31 = alloca i32
  %l40 = alloca i32
  %l43 = alloca i1
  %l48 = alloca i32
  %l56 = alloca i1
  %l66 = alloca i32
  %l71 = alloca i1
  %l72 = alloca i1
  %l77 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Make", ptr %t1, i32 0, i32 0
  %t4 = load i32, ptr %t3, !range !{i32 0, i32 5}
  %t6 = trunc i64 3 to i32
  %t7 = icmp eq i32 %t4, %t6
  %t9 = xor i1 %t7, true
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = load ptr, ptr %l2, !tbaa !29
  %t13 = getelementptr %"compiler/typed:Make", ptr %t11, i32 0, i32 0
  %t14 = load i32, ptr %t13, !range !{i32 0, i32 5}
  %t16 = trunc i64 2 to i32
  %t17 = icmp eq i32 %t14, %t16
  %t19 = xor i1 %t17, true
  store i1 %t19, ptr %l10, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l10, !tbaa !21
  br label %bb3
bb3:
  %t21 = load i1, ptr %l10, !tbaa !21
  br i1 %t21, label %bb4, label %bb5
bb4:
  store i1 false, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/effects:Effects", ptr %t23, i32 0, i32 0
  %t26 = load ptr, ptr %t25, !tbaa !29
  %t28 = getelementptr %"compiler/generic:Program", ptr %t26, i32 0, i32 2
  %t32 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t28, i32 %a1)
  store i32 %t32, ptr %l20
  br label %bb7
bb7:
  %t33 = load i32, ptr %l20, !tbaa !23
  store i32 %t33, ptr %l3, !tbaa !23
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/effects:Effects", ptr %t34, i32 0, i32 0
  %t37 = load ptr, ptr %t36, !tbaa !29
  %t39 = getelementptr %"compiler/generic:Program", ptr %t37, i32 0, i32 2
  %t40 = load i32, ptr %l3, !tbaa !23
  %t43 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t39, i32 %t40)
  store i1 %t43, ptr %l25
  br label %bb8
bb8:
  %t44 = load i1, ptr %l25, !tbaa !21
  br i1 %t44, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l26, !tbaa !21
  br label %bb12
bb10:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/effects:Effects", ptr %t45, i32 0, i32 0
  %t48 = load ptr, ptr %t47, !tbaa !29
  %t50 = getelementptr %"compiler/generic:Program", ptr %t48, i32 0, i32 2
  %t51 = load i32, ptr %l3, !tbaa !23
  %t54 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t50, i32 %t51)
  store i32 %t54, ptr %l31
  br label %bb11
bb11:
  %t55 = load i32, ptr %l31, !range !{i32 0, i32 33}
  %t57 = trunc i64 19 to i32
  %t58 = icmp eq i32 %t55, %t57
  %t60 = xor i1 %t58, true
  store i1 %t60, ptr %l26, !tbaa !21
  br label %bb12
bb12:
  %t62 = load i1, ptr %l26, !tbaa !21
  br i1 %t62, label %bb13, label %bb14
bb13:
  store i1 false, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/effects:Effects", ptr %t64, i32 0, i32 0
  %t67 = load ptr, ptr %t66, !tbaa !29
  %t69 = getelementptr %"compiler/generic:Program", ptr %t67, i32 0, i32 2
  %t70 = load i32, ptr %l3, !tbaa !23
  %t73 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t69, i32 %t70)
  store i32 %t73, ptr %l40
  br label %bb16
bb16:
  %t74 = load i32, ptr %l40, !tbaa !23
  store i32 %t74, ptr %l4, !tbaa !23
  %t75 = load i32, ptr %l4, !tbaa !23
  %t77 = icmp eq i32 %t75, 0
  br i1 %t77, label %bb17, label %bb18
bb17:
  store i1 true, ptr %l43, !tbaa !21
  br label %bb20
bb18:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/effects:Effects", ptr %t79, i32 0, i32 0
  %t82 = load ptr, ptr %t81, !tbaa !29
  %t84 = getelementptr %"compiler/generic:Program", ptr %t82, i32 0, i32 2
  %t85 = load i32, ptr %l4, !tbaa !23
  %t88 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t84, i32 %t85)
  store i32 %t88, ptr %l48
  br label %bb19
bb19:
  %t89 = load i32, ptr %l48, !range !{i32 0, i32 33}
  %t91 = trunc i64 26 to i32
  %t92 = icmp eq i32 %t89, %t91
  %t94 = xor i1 %t92, true
  store i1 %t94, ptr %l43, !tbaa !21
  br label %bb20
bb20:
  %t96 = load i1, ptr %l43, !tbaa !21
  br i1 %t96, label %bb21, label %bb22
bb21:
  store i1 false, ptr %rv
  br label %ret
bb22:
  br label %bb23
bb23:
  %t98 = load ptr, ptr %l2, !tbaa !29
  %t100 = getelementptr %"compiler/typed:Make", ptr %t98, i32 0, i32 0
  %t101 = load i32, ptr %t100, !range !{i32 0, i32 5}
  %t103 = trunc i64 2 to i32
  %t104 = icmp eq i32 %t101, %t103
  br i1 %t104, label %bb24, label %bb25
bb24:
  store i1 true, ptr %l56, !tbaa !21
  br label %bb26
bb25:
  %t106 = load ptr, ptr %l2, !tbaa !29
  %t108 = getelementptr %"compiler/typed:Make", ptr %t106, i32 0, i32 2
  %t109 = load { i64, ptr }, ptr %t108, !tbaa !27
  %t111 = extractvalue { i64, ptr } %t109, 0
  %t113 = icmp eq i64 %t111, 0
  store i1 %t113, ptr %l56, !tbaa !21
  br label %bb26
bb26:
  %t115 = load i1, ptr %l56, !tbaa !21
  br i1 %t115, label %bb27, label %bb28
bb27:
  store i1 true, ptr %rv
  br label %ret
bb28:
  br label %bb29
bb29:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr %"compiler/effects:Effects", ptr %t117, i32 0, i32 0
  %t120 = load ptr, ptr %t119, !tbaa !29
  %t122 = getelementptr %"compiler/generic:Program", ptr %t120, i32 0, i32 2
  %t123 = load i32, ptr %l3, !tbaa !23
  %t126 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t122, i32 %t123)
  store i32 %t126, ptr %l66
  br label %bb30
bb30:
  %t127 = load i32, ptr %l66, !tbaa !23
  store i32 %t127, ptr %l5, !tbaa !23
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t130 = getelementptr %"compiler/effects:Effects", ptr %t128, i32 0, i32 0
  %t131 = load ptr, ptr %t130, !tbaa !29
  %t133 = getelementptr %"compiler/generic:Program", ptr %t131, i32 0, i32 2
  %t134 = load i32, ptr %l5, !tbaa !23
  %t137 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOwnedPart(ptr %v0, ptr %t133, i32 %t134)
  store i1 %t137, ptr %l71
  br label %bb31
bb31:
  %t138 = load i1, ptr %l71, !tbaa !21
  br i1 %t138, label %bb32, label %bb33
bb32:
  store i1 true, ptr %l72, !tbaa !21
  br label %bb35
bb33:
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t141 = getelementptr %"compiler/effects:Effects", ptr %t139, i32 0, i32 0
  %t142 = load ptr, ptr %t141, !tbaa !29
  %t144 = getelementptr %"compiler/generic:Program", ptr %t142, i32 0, i32 2
  %t145 = load i32, ptr %l5, !tbaa !23
  %t148 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOwnsParts(ptr %v0, ptr %t144, i32 %t145)
  store i1 %t148, ptr %l77
  br label %bb34
bb34:
  %t149 = load i1, ptr %l77, !tbaa !21
  store i1 %t149, ptr %l72, !tbaa !21
  br label %bb35
bb35:
  %t150 = load i1, ptr %l72, !tbaa !21
  %t151 = xor i1 %t150, true
  store i1 %t151, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ejudgeType(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i64 %a2, ptr %a3) #0 {
entry:
  %l1 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca %"compiler/effects:Facts"
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l16 = alloca %"compiler/effects:Facts"
  %l22 = alloca i64
  %l25 = alloca i64
  %l43 = alloca i64
  %l49 = alloca i1
  %l52 = alloca { i64, ptr }
  %l54 = alloca i1
  %l55 = alloca ptr
  %l56 = alloca i64
  %l60 = alloca { i64, ptr }
  %l61 = alloca i64
  %l62 = alloca { i64, ptr }
  %l66 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  store i32 %a1, ptr %l1
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = getelementptr %"compiler/effects:Effects", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t7 = load i32, ptr %l1, !tbaa !23
  %t10 = call %"compiler/effects:Facts" @compiler_2feffects_2eFacts_2eBound(ptr %v0, ptr %t6, i32 %t7)
  store %"compiler/effects:Facts" %t10, ptr %l16
  br label %bb1
bb1:
  %t11 = load %"compiler/effects:Facts", ptr %l16
  store %"compiler/effects:Facts" %t11, ptr %l4
  %t12 = getelementptr %"compiler/effects:Facts", ptr %l4, i32 0, i32 17
  store i1 false, ptr %t12, !tbaa !21
  store i64 0, ptr %l5, !tbaa !24
  %t13 = load [8 x { i64, ptr }], ptr @G_2ecompiler_2ftypes_2ePromiseNames
  store i64 8, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t16 = load i64, ptr %l6, !tbaa !24
  %t17 = load i64, ptr %l5, !tbaa !24
  %t20 = icmp sgt i64 %t16, %t17
  br i1 %t20, label %bb2, label %bb3
bb2:
  %t22 = load i64, ptr %l7, !tbaa !24
  %t24 = icmp sgt i64 %t22, 0
  br i1 %t24, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l22, !tbaa !24
  br label %bb7
bb4:
  %t26 = load i64, ptr %l6, !tbaa !24
  %t27 = load i64, ptr %l5, !tbaa !24
  %t30 = sub i64 %t26, %t27
  %t31 = load i64, ptr %l7, !tbaa !24
  %t34 = add i64 %t30, %t31
  %t36 = sub i64 %t34, 1
  %t37 = load i64, ptr %l7, !tbaa !24
  %t40 = sdiv i64 %t36, %t37
  store i64 %t40, ptr %l25, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l25, !tbaa !24
  br label %bb6
bb6:
  %t42 = load i64, ptr %l25, !tbaa !24
  store i64 %t42, ptr %l22, !tbaa !24
  br label %bb7
bb7:
  %t43 = load i64, ptr %l22, !tbaa !24
  store i64 %t43, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t44 = load i64, ptr %l9, !tbaa !24
  %t45 = load i64, ptr %l8, !tbaa !24
  %t48 = icmp slt i64 %t44, %t45
  %t50 = xor i1 %t48, true
  br i1 %t50, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb29
bb10:
  br label %bb11
bb11:
  %t52 = load i64, ptr %l5, !tbaa !24
  %t53 = load i64, ptr %l9, !tbaa !24
  %t54 = load i64, ptr %l7, !tbaa !24
  %t57 = mul i64 %t53, %t54
  %t60 = add i64 %t52, %t57
  store i64 %t60, ptr %l10, !tbaa !24
  %t62 = load i64, ptr %l10, !tbaa !24
  store i64 %t62, ptr %l43, !tbaa !24
  %t63 = load i64, ptr %l43, !tbaa !24
  %t64 = load i64, ptr %l43, !tbaa !24
  %t65 = shl i64 1, %t64
  store i64 %t65, ptr %l11, !tbaa !24
  %t68 = load i64, ptr %l11, !tbaa !24
  %t71 = and i64 %a2, %t68
  %t73 = icmp eq i64 %t71, 0
  br i1 %t73, label %bb12, label %bb13
bb12:
  store i1 true, ptr %l49, !tbaa !21
  br label %bb16
bb13:
  %t75 = load i64, ptr %l11, !tbaa !24
  %t78 = call { i64, ptr } @compiler_2feffects_2eBreaks(ptr %s0, ptr %s2, ptr %l4, i64 %t75)
  store { i64, ptr } %t78, ptr %l52
  br label %bb14
bb14:
  %t79 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t81 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s2, ptr %s2, { i64, ptr } %t79, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d19, i32 0, i32 1) })
  store i1 %t81, ptr %l54
  br label %bb15
bb15:
  %t82 = load i1, ptr %l54, !tbaa !21
  store i1 %t82, ptr %l49, !tbaa !21
  br label %bb16
bb16:
  %t83 = load i1, ptr %l49, !tbaa !21
  br i1 %t83, label %bb17, label %bb18
bb17:
  call void @__olang_scope_close(ptr %s2)
  br label %bb28
bb18:
  br label %bb19
bb19:
  %t84 = load ptr, ptr %l3, !tbaa !29
  store ptr %t84, ptr %l55, !tbaa !29
  %t85 = call ptr @__olang_scope_hold(ptr %v1)
  %t86 = ptrtoint ptr %t85 to i64
  store i64 %t86, ptr %l56, !tbaa !24
  %t87 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aVerdict_2e0
  br i1 %t87, label %bb20, label %bb21
bb20:
  %t89 = call ptr @__olang_region_make_part(ptr %v1)
  %t90 = ptrtoint ptr %t89 to i64
  store i64 %t90, ptr %l56, !tbaa !24
  br label %bb21
bb21:
  %t91 = load i64, ptr %l10, !tbaa !24
  %t93 = getelementptr [8 x { i64, ptr }], ptr @G_2ecompiler_2ftypes_2ePromiseNames, i64 0, i64 %t91
  %t94 = load { i64, ptr }, ptr %t93, !tbaa !37
  store { i64, ptr } %t94, ptr %l60, !tbaa !27
  %t96 = load { i64, ptr }, ptr %l60, !tbaa !27
  %t97 = extractvalue { i64, ptr } %t96, 0
  store i64 %t97, ptr %l61, !tbaa !24
  %t98 = load i64, ptr %l61, !tbaa !24
  %t99 = mul i64 %t98, 1
  %t100 = load i64, ptr %l56
  %t101 = inttoptr i64 %t100 to ptr
  %t102 = call ptr @__olang_held_alloc(ptr %t101, i64 %t99)
  %t103 = insertvalue { i64, ptr } undef, i64 %t98, 0
  %t104 = insertvalue { i64, ptr } %t103, ptr %t102, 1
  store { i64, ptr } %t104, ptr %l62, !tbaa !27
  %t105 = getelementptr { i64, ptr }, ptr %l62, i32 0, i32 1
  %t106 = load ptr, ptr %t105, !tbaa !27
  %t107 = getelementptr { i64, ptr }, ptr %l60, i32 0, i32 1
  %t108 = load ptr, ptr %t107, !tbaa !27
  %t109 = load i64, ptr %l61, !tbaa !24
  %t110 = mul i64 %t109, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t106, ptr %t108, i64 %t110, i1 false)
  %t111 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aVerdict_2e0
  br i1 %t111, label %bb22, label %bb23
bb22:
  %t113 = load { i64, ptr }, ptr %l62, !tbaa !27
  %t114 = extractvalue { i64, ptr } %t113, 0
  %t116 = icmp eq i64 %t114, 0
  br i1 %t116, label %bb24, label %bb25
bb23:
  %t118 = load ptr, ptr %l55, !tbaa !29
  %t119 = getelementptr %"compiler/effects:Verdict", ptr %t118, i32 0, i32 0
  %t120 = load { i64, ptr }, ptr %t119, !tbaa !27
  store { i64, ptr } %t120, ptr %l66, !tbaa !27
  %t121 = load { i64, ptr }, ptr %l62, !tbaa !27
  %t122 = load ptr, ptr %l55, !tbaa !29
  %t123 = getelementptr %"compiler/effects:Verdict", ptr %t122, i32 0, i32 0
  store { i64, ptr } %t121, ptr %t123, !tbaa !27
  %t124 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aVerdict_2e0
  br i1 %t124, label %bb26, label %bb27
bb24:
  store { i64, ptr } zeroinitializer, ptr %l62, !tbaa !27
  br label %bb25
bb25:
  %t126 = load i64, ptr %l56
  %t127 = inttoptr i64 %t126 to ptr
  %t128 = load { i64, ptr }, ptr %l62
  %t129 = extractvalue { i64, ptr } %t128, 1
  %t130 = call ptr @__olang_region_or(ptr %t129, ptr null)
  %t131 = icmp ne ptr %t130, null
  %t132 = select i1 %t131, ptr %t130, ptr null
  call void @__olang_region_settle_in(ptr %t127, ptr %t132)
  br label %bb23
bb26:
  %t133 = load { i64, ptr }, ptr %l66
  %t134 = extractvalue { i64, ptr } %t133, 0
  %t135 = extractvalue { i64, ptr } %t133, 1
  call void @__olang_region_release_part(ptr %t135, i64 %t134)
  store { i64, ptr } zeroinitializer, ptr %l66
  br label %bb27
bb27:
  %t136 = load ptr, ptr %l3, !tbaa !29
  %t138 = getelementptr %"compiler/effects:Verdict", ptr %t136, i32 0, i32 2
  store i1 false, ptr %t138, !tbaa !21
  %t139 = load ptr, ptr %l3, !tbaa !29
  %t140 = load i32, ptr %l1, !tbaa !23
  %t143 = getelementptr %"compiler/effects:Verdict", ptr %t139, i32 0, i32 3
  store i32 %t140, ptr %t143, !tbaa !23
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb28:
  %t144 = load i64, ptr %l9, !tbaa !24
  %t147 = add i64 %t144, 1
  store i64 %t147, ptr %l9, !tbaa !24
  br label %bb8
bb29:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ejudgedParts(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, ptr %a2) #0 {
entry:
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca %"compiler/effects:part"
  %l7 = alloca ptr
  %l8 = alloca i64
  %lp9 = alloca ptr
  %l10 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l12 = alloca i64
  %l14 = alloca i64
  %l19 = alloca %"compiler/effects:part"
  %l21 = alloca %"compiler/effects:part"
  %l25 = alloca ptr
  %l26 = alloca %"compiler/effects:part"
  %l28 = alloca %"compiler/effects:part"
  %l32 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l34 = alloca i64
  %l36 = alloca i64
  %l41 = alloca %"compiler/effects:part"
  %l43 = alloca %"compiler/effects:part"
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3apart_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l10
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l10
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l3
  store ptr %a2, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t5 = load i64, ptr %l5, !tbaa !24
  store i64 %t5, ptr %l12, !tbaa !24
  %t6 = load ptr, ptr %l4, !tbaa !29
  %t8 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3apart_3e_2eLen_3ccompiler_2feffects_3apart_3e(ptr %v1, ptr %t6)
  store i64 %t8, ptr %l14
  br label %bb3
bb3:
  %t9 = load i64, ptr %l12, !tbaa !24
  %t10 = load i64, ptr %l14, !tbaa !24
  %t11 = icmp slt i64 %t9, %t10
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s2)
  br label %bb26
bb5:
  br label %bb6
bb6:
  %t15 = load ptr, ptr %l4, !tbaa !29
  %t16 = load i64, ptr %l5, !tbaa !24
  %t19 = call %"compiler/effects:part" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3apart_3e_2eAt_3ccompiler_2feffects_3apart_3e(ptr %v1, ptr %v1, ptr %t15, i64 %t16)
  store %"compiler/effects:part" %t19, ptr %l19
  br label %bb7
bb7:
  %t21 = call %"compiler/effects:part" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2feffects_3apart(ptr %v1, ptr %l19)
  store %"compiler/effects:part" %t21, ptr %l21
  br label %bb8
bb8:
  %t22 = load %"compiler/effects:part", ptr %l21
  store %"compiler/effects:part" %t22, ptr %l6
  %t23 = getelementptr %"compiler/effects:part", ptr %l6, i32 0, i32 0
  %t24 = load i64, ptr %t23, !tbaa !24
  %t25 = load i64, ptr @G_2ecompiler_2feffects_2eGivResField, !tbaa !24
  %t28 = icmp ne i64 %t24, %t25
  br i1 %t28, label %bb9, label %bb10
bb9:
  store %olang.scope zeroinitializer, ptr %s3
  store ptr %l3, ptr %l25, !tbaa !29
  %t30 = load %"compiler/effects:part", ptr %l6
  store %"compiler/effects:part" %t30, ptr %l26
  %t32 = call %"compiler/effects:part" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2feffects_3apart(ptr %s3, ptr %l26)
  store %"compiler/effects:part" %t32, ptr %l28
  br label %bb11
bb10:
  br label %bb13
bb11:
  %t33 = load ptr, ptr %l25, !tbaa !29
  %t34 = load %"compiler/effects:part", ptr %l28
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3apart_3e_2ePush_3ccompiler_2feffects_3apart_3e(ptr %v2, ptr %v2, ptr %t33, %"compiler/effects:part" %t34)
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  br label %bb25
bb13:
  %t40 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2efieldParts(ptr %v0, ptr %s2, ptr %v2, ptr %a0, i64 %a1, ptr %l6)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t40, ptr %l32
  br label %bb14
bb14:
  %t41 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l32
  %t42 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t41, ptr %t42
  store ptr %t42, ptr %l7, !tbaa !29
  store i64 0, ptr %l8, !tbaa !24
  br label %bb15
bb15:
  %t44 = load i64, ptr %l8, !tbaa !24
  store i64 %t44, ptr %l34, !tbaa !24
  %t45 = load ptr, ptr %l7, !tbaa !29
  %t47 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3apart_3e_2eLen_3ccompiler_2feffects_3apart_3e(ptr %v2, ptr %t45)
  store i64 %t47, ptr %l36
  br label %bb16
bb16:
  %t48 = load i64, ptr %l34, !tbaa !24
  %t49 = load i64, ptr %l36, !tbaa !24
  %t50 = icmp slt i64 %t48, %t49
  %t52 = xor i1 %t50, true
  br i1 %t52, label %bb17, label %bb18
bb17:
  br label %bb24
bb18:
  br label %bb19
bb19:
  %t54 = load ptr, ptr %l7, !tbaa !29
  %t55 = load i64, ptr %l8, !tbaa !24
  %t58 = call %"compiler/effects:part" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3apart_3e_2eAt_3ccompiler_2feffects_3apart_3e(ptr %v2, ptr %v2, ptr %t54, i64 %t55)
  store %"compiler/effects:part" %t58, ptr %l41
  br label %bb20
bb20:
  %t60 = call %"compiler/effects:part" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2feffects_3apart(ptr %v2, ptr %l41)
  store %"compiler/effects:part" %t60, ptr %l43
  br label %bb21
bb21:
  %t61 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 72, i64 8)
  store ptr %t61, ptr %lp9
  %t62 = load %"compiler/effects:part", ptr %l43
  %t63 = load ptr, ptr %lp9
  store %"compiler/effects:part" %t62, ptr %t63
  %t64 = load ptr, ptr %lp9
  %t65 = load %"compiler/effects:part", ptr %t64
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3apart_3e_2ePush_3ccompiler_2feffects_3apart_3e(ptr %v2, ptr %v2, ptr %l3, %"compiler/effects:part" %t65)
  br label %bb22
bb22:
  br label %bb23
bb23:
  %t68 = load i64, ptr %l8, !tbaa !24
  %t71 = add i64 %t68, 1
  store i64 %t71, ptr %l8, !tbaa !24
  br label %bb15
bb24:
  call void @__olang_scope_close(ptr %s2)
  br label %bb25
bb25:
  %t73 = load i64, ptr %l5, !tbaa !24
  %t76 = add i64 %t73, 1
  store i64 %t76, ptr %l5, !tbaa !24
  br label %bb2
bb26:
  %t78 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t78, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ekeptLocals(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/typed:LocalUses"
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i32
  %l14 = alloca %"compiler/typed:LocalUses"
  %l19 = alloca i64
  %l23 = alloca i64
  %l26 = alloca i64
  %l45 = alloca ptr
  %l56 = alloca i1
  %l60 = alloca i1
  %l65 = alloca %"compiler/typed:Local"
  %l69 = alloca i1
  %s0 = alloca %olang.scope
  %t8 = alloca %"compiler/typed:LocalUses", align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/effects:Effects", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t7 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2ftyped_2eLocalUses_2eUses(ptr %t8, ptr %v0, ptr %v1, ptr %s0, ptr %t6, ptr %t7)
  call void @llvm.memmove.p0.p0.i64(ptr %l14, ptr %t8, i64 1640, i1 false)
  br label %bb1
bb1:
  call void @llvm.memmove.p0.p0.i64(ptr %l2, ptr %l14, i64 1640, i1 false)
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/effects:Effects", ptr %t11, i32 0, i32 73
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eClear_3cBool_3e(ptr %v0, ptr %t13)
  br label %bb2
bb2:
  store i64 0, ptr %l3, !tbaa !24
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t17 = getelementptr %"compiler/typed:Body", ptr %t15, i32 0, i32 7
  %t19 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eLen_3ccompiler_2ftyped_3aLocal_3e(ptr %v1, ptr %t17)
  store i64 %t19, ptr %l19
  br label %bb3
bb3:
  %t20 = load i64, ptr %l19, !tbaa !24
  store i64 %t20, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t21 = load i64, ptr %l4, !tbaa !24
  %t22 = load i64, ptr %l3, !tbaa !24
  %t25 = icmp sgt i64 %t21, %t22
  br i1 %t25, label %bb4, label %bb5
bb4:
  %t27 = load i64, ptr %l5, !tbaa !24
  %t29 = icmp sgt i64 %t27, 0
  br i1 %t29, label %bb6, label %bb7
bb5:
  store i64 0, ptr %l23, !tbaa !24
  br label %bb9
bb6:
  %t31 = load i64, ptr %l4, !tbaa !24
  %t32 = load i64, ptr %l3, !tbaa !24
  %t35 = sub i64 %t31, %t32
  %t36 = load i64, ptr %l5, !tbaa !24
  %t39 = add i64 %t35, %t36
  %t41 = sub i64 %t39, 1
  %t42 = load i64, ptr %l5, !tbaa !24
  %t45 = sdiv i64 %t41, %t42
  store i64 %t45, ptr %l26, !tbaa !24
  br label %bb8
bb7:
  store i64 0, ptr %l26, !tbaa !24
  br label %bb8
bb8:
  %t47 = load i64, ptr %l26, !tbaa !24
  store i64 %t47, ptr %l23, !tbaa !24
  br label %bb9
bb9:
  %t48 = load i64, ptr %l23, !tbaa !24
  store i64 %t48, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb10
bb10:
  %t49 = load i64, ptr %l7, !tbaa !24
  %t50 = load i64, ptr %l6, !tbaa !24
  %t53 = icmp slt i64 %t49, %t50
  %t55 = xor i1 %t53, true
  br i1 %t55, label %bb11, label %bb12
bb11:
  br label %bb28
bb12:
  br label %bb13
bb13:
  %t57 = load i64, ptr %l3, !tbaa !24
  %t58 = load i64, ptr %l7, !tbaa !24
  %t59 = load i64, ptr %l5, !tbaa !24
  %t62 = mul i64 %t58, %t59
  %t65 = add i64 %t57, %t62
  store i64 %t65, ptr %l8, !tbaa !24
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/effects:Effects", ptr %t67, i32 0, i32 73
  store ptr %t69, ptr %l45, !tbaa !29
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/effects:Effects", ptr %t70, i32 0, i32 71
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/effects:Effects", ptr %t73, i32 0, i32 0
  %t76 = load ptr, ptr %t75, !tbaa !29
  %t78 = getelementptr %"compiler/generic:Program", ptr %t76, i32 0, i32 2
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/effects:Effects", ptr %t79, i32 0, i32 1
  %t82 = load ptr, ptr %l1, !tbaa !29
  %t83 = load i64, ptr %l8, !tbaa !24
  %t90 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aRefsKept_2eKept(ptr %v0, ptr %v0, ptr %v0, ptr %v1, ptr %s0, ptr %t72, ptr %t78, ptr %t81, ptr %t82, ptr %l2, i64 %t83)
  store i1 %t90, ptr %l56
  br label %bb14
bb14:
  %t91 = load ptr, ptr %l45, !tbaa !29
  %t92 = load i1, ptr %l56, !tbaa !21
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t91, i1 %t92)
  br label %bb15
bb15:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/effects:Effects", ptr %t93, i32 0, i32 73
  %t96 = load i64, ptr %l8, !tbaa !24
  %t99 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t95, i64 %t96)
  store i1 %t99, ptr %l60
  br label %bb16
bb16:
  %t100 = load i1, ptr %l60, !tbaa !21
  %t101 = xor i1 %t100, true
  br i1 %t101, label %bb17, label %bb18
bb17:
  br label %bb27
bb18:
  br label %bb19
bb19:
  %t103 = load ptr, ptr %l1, !tbaa !29
  %t105 = getelementptr %"compiler/typed:Body", ptr %t103, i32 0, i32 7
  %t106 = load i64, ptr %l8, !tbaa !24
  %t109 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v1, ptr %t105, i64 %t106)
  store %"compiler/typed:Local" %t109, ptr %l65
  br label %bb20
bb20:
  %t110 = getelementptr %"compiler/typed:Local", ptr %l65, i32 0, i32 4
  %t111 = load i32, ptr %t110, !range !{i32 0, i32 7}
  store i32 %t111, ptr %l9
  %t113 = load i32, ptr %l9, !range !{i32 0, i32 7}
  %t115 = trunc i64 0 to i32
  %t116 = icmp eq i32 %t113, %t115
  br i1 %t116, label %bb21, label %bb22
bb21:
  store i1 true, ptr %l69, !tbaa !21
  br label %bb23
bb22:
  %t118 = load i32, ptr %l9, !range !{i32 0, i32 7}
  %t120 = trunc i64 4 to i32
  %t121 = icmp eq i32 %t118, %t120
  store i1 %t121, ptr %l69, !tbaa !21
  br label %bb23
bb23:
  %t123 = load i1, ptr %l69, !tbaa !21
  br i1 %t123, label %bb24, label %bb25
bb24:
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t126 = getelementptr %"compiler/effects:Effects", ptr %t124, i32 0, i32 25
  %t127 = getelementptr %"compiler/effects:Facts", ptr %t126, i32 0, i32 0
  store i1 true, ptr %t127, !tbaa !21
  br label %bb26
bb25:
  br label %bb26
bb26:
  br label %bb27
bb27:
  %t128 = load i64, ptr %l7, !tbaa !24
  %t131 = add i64 %t128, 1
  store i64 %t131, ptr %l7, !tbaa !24
  br label %bb10
bb28:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eoverlaps(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l3 = alloca ptr
  %l4 = alloca %"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9"
  %l5 = alloca i64
  %l7 = alloca i1
  %l10 = alloca %"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9"
  %l11 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i32
  %l16 = alloca i1
  %l19 = alloca i1
  %l20 = alloca i1
  %l24 = alloca i1
  %rv = alloca i1
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l3, !tbaa !29
  %t3 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v2, ptr %t1, i64 -1)
  store i1 %t3, ptr %l7
  br label %bb1
bb1:
  %t4 = load i1, ptr %l7, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  store i1 true, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t6 = load ptr, ptr %l3, !tbaa !29
  %t8 = call %"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eKeys_3cI64_2c_20Bool_3e(ptr %v2, ptr %v2, ptr %t6)
  store %"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9" %t8, ptr %l10
  br label %bb5
bb5:
  %t9 = load %"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9", ptr %l10
  store %"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9" %t9, ptr %l4
  br label %bb6
bb6:
  %t11 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapKeyIter_3cI64_2c_20Bool_3e_2eNext_3cI64_2c_20Bool_3e(ptr %v2, ptr %l4)
  %t12 = extractvalue { i32, i64 } %t11, 1
  %t13 = extractvalue { i32, i64 } %t11, 0
  store i32 %t13, ptr %l14
  %t14 = icmp ne i32 %t13, 0
  br i1 %t14, label %bb8, label %ok.15, !prof !99
ok.15:
  store i64 %t12, ptr %l13
  br label %bb7
bb7:
  %t16 = load i64, ptr %l13, !tbaa !24
  store i64 %t16, ptr %l11, !tbaa !24
  br label %bb10
bb8:
  %t17 = load i32, ptr %l14, !tbaa !23
  %t18 = ashr i32 %t17, 16
  %t20 = icmp eq i32 %t18, 1
  store i1 %t20, ptr %l16, !tbaa !21
  br label %bb9
bb9:
  br label %bb20
bb10:
  %t21 = load i64, ptr %l11, !tbaa !24
  store i64 %t21, ptr %l5, !tbaa !24
  %t23 = load i64, ptr %l5, !tbaa !24
  %t26 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v1, ptr %a2, i64 %t23)
  store i1 %t26, ptr %l19
  br label %bb11
bb11:
  %t27 = load i1, ptr %l19, !tbaa !21
  br i1 %t27, label %bb12, label %bb13
bb12:
  store i1 true, ptr %l20, !tbaa !21
  br label %bb15
bb13:
  %t29 = load i64, ptr %l5, !tbaa !24
  %t34 = call i1 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eholds(ptr %v0, ptr %a0, i64 %t29, i32 %a1)
  store i1 %t34, ptr %l24
  br label %bb14
bb14:
  %t35 = load i1, ptr %l24, !tbaa !21
  store i1 %t35, ptr %l20, !tbaa !21
  br label %bb15
bb15:
  %t36 = load i1, ptr %l20, !tbaa !21
  br i1 %t36, label %bb16, label %bb17
bb16:
  store i1 true, ptr %rv
  br label %ret
bb17:
  br label %bb18
bb18:
  br label %bb19
bb19:
  br label %bb6
bb20:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2epassCalls(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca i64
  %l4 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca %"compiler/effects:given"
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l15 = alloca i1
  %l17 = alloca i1
  %l21 = alloca i1
  %l24 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l28 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l29 = alloca i32
  %l31 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l32 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l34 = alloca i64
  %l36 = alloca i64
  %l41 = alloca %"compiler/effects:given"
  %l45 = alloca i1
  %l51 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l54 = alloca i64
  %l57 = alloca i1
  %l58 = alloca i64
  %l61 = alloca i64
  %l63 = alloca i1
  %l66 = alloca i1
  %l67 = alloca i1
  %l71 = alloca i64
  %l77 = alloca %"compiler/effects:Facts"
  %l80 = alloca i1
  %l82 = alloca i1
  %l86 = alloca %"compiler/effects:Facts"
  %l89 = alloca i1
  %l94 = alloca %"compiler/effects:Facts"
  %l95 = alloca i64
  %l97 = alloca i64
  %l102 = alloca ptr
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i64 0, ptr %l3, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/effects:Effects", ptr %t1, i32 0, i32 16
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t3, i64 %t4)
  store i1 %t7, ptr %l15
  br label %bb1
bb1:
  %t8 = load i1, ptr %l15, !tbaa !21
  %t9 = xor i1 %t8, true
  br i1 %t9, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l17, !tbaa !21
  br label %bb5
bb3:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/effects:Effects", ptr %t11, i32 0, i32 9
  %t14 = load i64, ptr %l1, !tbaa !24
  %t17 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cc_Hb5dd413d586c55d7ccefa7dbc5ad43c5(ptr %v0, ptr %t13, i64 %t14)
  store i1 %t17, ptr %l21
  br label %bb4
bb4:
  %t18 = load i1, ptr %l21, !tbaa !21
  %t19 = xor i1 %t18, true
  store i1 %t19, ptr %l17, !tbaa !21
  br label %bb5
bb5:
  %t21 = load i1, ptr %l17, !tbaa !21
  br i1 %t21, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s0)
  store i64 0, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/effects:Effects", ptr %t23, i32 0, i32 9
  %t26 = load i64, ptr %l1, !tbaa !24
  %t29 = call { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cc_H7b34d2d8e55697dbed551519dd59c955(ptr %v0, ptr %v0, ptr %t25, i64 %t26)
  %t30 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t29, 1
  %t31 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t29, 0
  store i32 %t31, ptr %l29
  %t32 = icmp ne i32 %t31, 0
  br i1 %t32, label %bb10, label %ok.33, !prof !99
ok.33:
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t30, ptr %l28
  br label %bb9
bb9:
  %t35 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3agiven_3e(ptr %s0, ptr %l28)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t35, ptr %l31
  br label %bb12
bb10:
  br label %bb11
bb11:
  %t36 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3agiven_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t36, ptr %l32
  br label %bb13
bb12:
  %t37 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l31
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t37, ptr %l24
  br label %bb14
bb13:
  %t38 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l32
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t38, ptr %l24
  br label %bb14
bb14:
  %t39 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l24
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t39, ptr %l4
  store ptr %l4, ptr %l5, !tbaa !29
  store i64 0, ptr %l6, !tbaa !24
  br label %bb15
bb15:
  %t41 = load i64, ptr %l6, !tbaa !24
  store i64 %t41, ptr %l34, !tbaa !24
  %t42 = load ptr, ptr %l5, !tbaa !29
  %t44 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3agiven_3e_2eLen_3ccompiler_2feffects_3agiven_3e(ptr %s0, ptr %t42)
  store i64 %t44, ptr %l36
  br label %bb16
bb16:
  %t45 = load i64, ptr %l34, !tbaa !24
  %t46 = load i64, ptr %l36, !tbaa !24
  %t47 = icmp slt i64 %t45, %t46
  %t49 = xor i1 %t47, true
  br i1 %t49, label %bb17, label %bb18
bb17:
  br label %bb58
bb18:
  br label %bb19
bb19:
  %t51 = load ptr, ptr %l5, !tbaa !29
  %t52 = load i64, ptr %l6, !tbaa !24
  %t55 = call %"compiler/effects:given" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3agiven_3e_2eAt_3ccompiler_2feffects_3agiven_3e(ptr %s0, ptr %s0, ptr %t51, i64 %t52)
  store %"compiler/effects:given" %t55, ptr %l41
  br label %bb20
bb20:
  %t56 = load %"compiler/effects:given", ptr %l41
  store %"compiler/effects:given" %t56, ptr %l7
  %t57 = getelementptr %"compiler/effects:given", ptr %l7, i32 0, i32 2
  %t58 = load i64, ptr %t57, !tbaa !24
  %t59 = load i64, ptr @G_2ecompiler_2feffects_2eGivSlot, !tbaa !24
  %t62 = icmp ne i64 %t58, %t59
  br i1 %t62, label %bb21, label %bb22
bb21:
  store i1 true, ptr %l45, !tbaa !21
  br label %bb23
bb22:
  %t64 = getelementptr %"compiler/effects:given", ptr %l7, i32 0, i32 0
  %t65 = load i64, ptr %t64, !tbaa !24
  %t67 = icmp slt i64 %t65, 0
  store i1 %t67, ptr %l45, !tbaa !21
  br label %bb23
bb23:
  %t69 = load i1, ptr %l45, !tbaa !21
  br i1 %t69, label %bb24, label %bb25
bb24:
  br label %bb57
bb25:
  br label %bb26
bb26:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/effects:Effects", ptr %t70, i32 0, i32 6
  %t73 = load i64, ptr %l1, !tbaa !24
  %t76 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__H7b6d4eff6fc9c3821aae8b284e12e095(ptr %v0, ptr %v0, ptr %t72, i64 %t73)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t76, ptr %l51
  br label %bb27
bb27:
  %t77 = getelementptr %"compiler/effects:given", ptr %l7, i32 0, i32 0
  %t78 = load i64, ptr %t77, !tbaa !24
  %t81 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %l51, i64 %t78)
  store i64 %t81, ptr %l54
  br label %bb28
bb28:
  %t82 = load i64, ptr %l54, !tbaa !24
  store i64 %t82, ptr %l8, !tbaa !24
  %t83 = load i64, ptr %l8, !tbaa !24
  %t85 = icmp slt i64 %t83, 0
  br i1 %t85, label %bb29, label %bb30
bb29:
  store i1 true, ptr %l57, !tbaa !21
  br label %bb32
bb30:
  %t87 = load i64, ptr %l8, !tbaa !24
  store i64 %t87, ptr %l58, !tbaa !24
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t90 = getelementptr %"compiler/effects:Effects", ptr %t88, i32 0, i32 1
  %t92 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %t90)
  store i64 %t92, ptr %l61
  br label %bb31
bb31:
  %t93 = load i64, ptr %l58, !tbaa !24
  %t94 = load i64, ptr %l61, !tbaa !24
  %t95 = icmp sge i64 %t93, %t94
  store i1 %t95, ptr %l57, !tbaa !21
  br label %bb32
bb32:
  %t97 = load i1, ptr %l57, !tbaa !21
  br i1 %t97, label %bb33, label %bb34
bb33:
  store i1 true, ptr %l63, !tbaa !21
  br label %bb40
bb34:
  %t99 = load i64, ptr %l8, !tbaa !24
  %t102 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v1, ptr %a2, i64 %t99)
  store i1 %t102, ptr %l66
  br label %bb35
bb35:
  %t103 = load i1, ptr %l66, !tbaa !21
  br i1 %t103, label %bb36, label %bb37
bb36:
  store i1 true, ptr %l67, !tbaa !21
  br label %bb39
bb37:
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t106 = getelementptr %"compiler/effects:Effects", ptr %t104, i32 0, i32 17
  %t107 = load i64, ptr %l8, !tbaa !24
  %t110 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t106, i64 %t107)
  store i64 %t110, ptr %l71
  br label %bb38
bb38:
  %t111 = load i64, ptr %l71, !tbaa !24
  %t112 = icmp eq i64 %t111, 2
  store i1 %t112, ptr %l67, !tbaa !21
  br label %bb39
bb39:
  %t114 = load i1, ptr %l67, !tbaa !21
  %t115 = xor i1 %t114, true
  store i1 %t115, ptr %l63, !tbaa !21
  br label %bb40
bb40:
  %t117 = load i1, ptr %l63, !tbaa !21
  br i1 %t117, label %bb41, label %bb42
bb41:
  br label %bb57
bb42:
  br label %bb43
bb43:
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t120 = getelementptr %"compiler/effects:Effects", ptr %t118, i32 0, i32 11
  %t121 = load i64, ptr %l8, !tbaa !24
  %t124 = call %"compiler/effects:Facts" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3aFacts_3e_2eAt_3ccompiler_2feffects_3aFacts_3e(ptr %v0, ptr %t120, i64 %t121)
  store %"compiler/effects:Facts" %t124, ptr %l77
  br label %bb44
bb44:
  %t125 = getelementptr %"compiler/effects:Facts", ptr %l77, i32 0, i32 24
  %t126 = load i64, ptr %t125, !tbaa !24
  %t127 = getelementptr %"compiler/effects:given", ptr %l7, i32 0, i32 1
  %t128 = load i64, ptr %t127, !tbaa !24
  %t131 = call i1 @compiler_2feffects_2ehasBit(i64 %t126, i64 %t128)
  store i1 %t131, ptr %l80
  br label %bb45
bb45:
  %t132 = load i1, ptr %l80, !tbaa !21
  %t133 = xor i1 %t132, true
  br i1 %t133, label %bb46, label %bb47
bb46:
  store i1 true, ptr %l82, !tbaa !21
  br label %bb50
bb47:
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t137 = getelementptr %"compiler/effects:Effects", ptr %t135, i32 0, i32 11
  %t138 = load i64, ptr %l1, !tbaa !24
  %t141 = call %"compiler/effects:Facts" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3aFacts_3e_2eAt_3ccompiler_2feffects_3aFacts_3e(ptr %v0, ptr %t137, i64 %t138)
  store %"compiler/effects:Facts" %t141, ptr %l86
  br label %bb48
bb48:
  %t142 = getelementptr %"compiler/effects:Facts", ptr %l86, i32 0, i32 24
  %t143 = load i64, ptr %t142, !tbaa !24
  %t144 = getelementptr %"compiler/effects:given", ptr %l7, i32 0, i32 3
  %t145 = load i64, ptr %t144, !tbaa !24
  %t148 = call i1 @compiler_2feffects_2ehasBit(i64 %t143, i64 %t145)
  store i1 %t148, ptr %l89
  br label %bb49
bb49:
  %t149 = load i1, ptr %l89, !tbaa !21
  store i1 %t149, ptr %l82, !tbaa !21
  br label %bb50
bb50:
  %t150 = load i1, ptr %l82, !tbaa !21
  br i1 %t150, label %bb51, label %bb52
bb51:
  br label %bb57
bb52:
  br label %bb53
bb53:
  %t151 = load i64, ptr %l1, !tbaa !24
  store i64 %t151, ptr %l9, !tbaa !24
  %t153 = load ptr, ptr %l0, !tbaa !29
  %t155 = getelementptr %"compiler/effects:Effects", ptr %t153, i32 0, i32 11
  %t156 = load i64, ptr %l1, !tbaa !24
  %t159 = call %"compiler/effects:Facts" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3aFacts_3e_2eAt_3ccompiler_2feffects_3aFacts_3e(ptr %v0, ptr %t155, i64 %t156)
  store %"compiler/effects:Facts" %t159, ptr %l94
  br label %bb54
bb54:
  %t160 = getelementptr %"compiler/effects:Facts", ptr %l94, i32 0, i32 24
  %t161 = load i64, ptr %t160, !tbaa !24
  store i64 %t161, ptr %l95, !tbaa !24
  %t162 = getelementptr %"compiler/effects:given", ptr %l7, i32 0, i32 3
  %t163 = load i64, ptr %t162, !tbaa !24
  %t165 = call i64 @compiler_2feffects_2eparamBit(i64 %t163)
  store i64 %t165, ptr %l97
  br label %bb55
bb55:
  %t166 = load i64, ptr %l95, !tbaa !24
  %t167 = load i64, ptr %l97, !tbaa !24
  %t168 = or i64 %t166, %t167
  store i64 %t168, ptr %l10, !tbaa !24
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t172 = getelementptr %"compiler/effects:Effects", ptr %t170, i32 0, i32 11
  %t173 = load i64, ptr %l9, !tbaa !24
  %t176 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3aFacts_3e_2eRefMut_3ccompiler_2feffects_3aFacts_3e(ptr %v0, ptr %v0, ptr %t172, i64 %t173)
  store ptr %t176, ptr %l102
  br label %bb56
bb56:
  %t177 = load ptr, ptr %l102, !tbaa !29
  %t179 = load i64, ptr %l10, !tbaa !24
  %t182 = getelementptr %"compiler/effects:Facts", ptr %t177, i32 0, i32 24
  store i64 %t179, ptr %t182, !tbaa !24
  %t183 = load i64, ptr %l3, !tbaa !24
  %t186 = add i64 %t183, 1
  store i64 %t186, ptr %l3, !tbaa !24
  br label %bb57
bb57:
  %t188 = load i64, ptr %l6, !tbaa !24
  %t191 = add i64 %t188, 1
  store i64 %t191, ptr %l6, !tbaa !24
  br label %bb15
bb58:
  %t193 = load i64, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t193, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2epassWrites(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca %"compiler/effects:link"
  %l8 = alloca ptr
  %l9 = alloca i64
  %l12 = alloca i1
  %l14 = alloca ptr
  %l15 = alloca i64
  %l18 = alloca i1
  %l20 = alloca i64
  %l21 = alloca i64
  %l26 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l28 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l30 = alloca i64
  %l32 = alloca i64
  %l37 = alloca %"compiler/effects:link"
  %l40 = alloca i1
  %l41 = alloca i64
  %l44 = alloca i64
  %l46 = alloca i1
  %l50 = alloca i64
  %l54 = alloca i1
  %l55 = alloca i1
  %l59 = alloca i64
  %l65 = alloca %"compiler/effects:Facts"
  %l68 = alloca i1
  %l76 = alloca %"compiler/effects:Facts"
  %l79 = alloca i64
  %l81 = alloca i64
  %l86 = alloca i64
  %l91 = alloca ptr
  %l106 = alloca %"compiler/effects:Facts"
  %l109 = alloca i64
  %l111 = alloca i64
  %l116 = alloca i64
  %l121 = alloca ptr
  %l133 = alloca %"compiler/effects:Facts"
  %l136 = alloca i1
  %l141 = alloca %"compiler/effects:Facts"
  %l142 = alloca i64
  %l144 = alloca i64
  %l149 = alloca ptr
  %s1 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l4, !tbaa !24
  store %olang.scope zeroinitializer, ptr %s1
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/effects:Effects", ptr %t1, i32 0, i32 8
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3ccompiler_2_Hec46674a538af874724ad5c9698b0829(ptr %v0, ptr %s1, ptr %t3, i64 %t4)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t7, ptr %l26
  br label %bb1
bb1:
  %t9 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3alink_3e(ptr %s1, ptr %l26)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %l28
  br label %bb2
bb2:
  %t10 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l28
  %t11 = call ptr @__olang_scope_alloc_a(ptr %s1, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t10, ptr %t11
  store ptr %t11, ptr %l5, !tbaa !29
  store i64 0, ptr %l6, !tbaa !24
  br label %bb3
bb3:
  %t13 = load i64, ptr %l6, !tbaa !24
  store i64 %t13, ptr %l30, !tbaa !24
  %t14 = load ptr, ptr %l5, !tbaa !29
  %t16 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3alink_3e_2eLen_3ccompiler_2feffects_3alink_3e(ptr %s1, ptr %t14)
  store i64 %t16, ptr %l32
  br label %bb4
bb4:
  %t17 = load i64, ptr %l30, !tbaa !24
  %t18 = load i64, ptr %l32, !tbaa !24
  %t19 = icmp slt i64 %t17, %t18
  %t21 = xor i1 %t19, true
  br i1 %t21, label %bb5, label %bb6
bb5:
  br label %bb74
bb6:
  br label %bb7
bb7:
  %t23 = load ptr, ptr %l5, !tbaa !29
  %t24 = load i64, ptr %l6, !tbaa !24
  %t27 = call %"compiler/effects:link" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3alink_3e_2eAt_3ccompiler_2feffects_3alink_3e(ptr %s1, ptr %t23, i64 %t24)
  store %"compiler/effects:link" %t27, ptr %l37
  br label %bb8
bb8:
  %t28 = load %"compiler/effects:link", ptr %l37
  store %"compiler/effects:link" %t28, ptr %l7
  %t29 = getelementptr %"compiler/effects:link", ptr %l7, i32 0, i32 0
  %t30 = load i64, ptr %t29, !tbaa !24
  %t32 = icmp slt i64 %t30, 0
  br i1 %t32, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l40, !tbaa !21
  br label %bb12
bb10:
  %t34 = getelementptr %"compiler/effects:link", ptr %l7, i32 0, i32 0
  %t35 = load i64, ptr %t34, !tbaa !24
  store i64 %t35, ptr %l41, !tbaa !24
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/effects:Effects", ptr %t36, i32 0, i32 1
  %t40 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %t38)
  store i64 %t40, ptr %l44
  br label %bb11
bb11:
  %t41 = load i64, ptr %l41, !tbaa !24
  %t42 = load i64, ptr %l44, !tbaa !24
  %t43 = icmp sge i64 %t41, %t42
  store i1 %t43, ptr %l40, !tbaa !21
  br label %bb12
bb12:
  %t45 = load i1, ptr %l40, !tbaa !21
  br i1 %t45, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l46, !tbaa !21
  br label %bb16
bb14:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/effects:Effects", ptr %t46, i32 0, i32 17
  %t49 = getelementptr %"compiler/effects:link", ptr %l7, i32 0, i32 0
  %t50 = load i64, ptr %t49, !tbaa !24
  %t53 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t48, i64 %t50)
  store i64 %t53, ptr %l50
  br label %bb15
bb15:
  %t54 = load i64, ptr %l50, !tbaa !24
  %t55 = icmp slt i64 %t54, 1
  store i1 %t55, ptr %l46, !tbaa !21
  br label %bb16
bb16:
  %t57 = load i1, ptr %l46, !tbaa !21
  br i1 %t57, label %bb17, label %bb18
bb17:
  br label %bb73
bb18:
  br label %bb19
bb19:
  %t59 = getelementptr %"compiler/effects:link", ptr %l7, i32 0, i32 0
  %t60 = load i64, ptr %t59, !tbaa !24
  %t63 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v2, ptr %a3, i64 %t60)
  store i1 %t63, ptr %l54
  br label %bb20
bb20:
  %t64 = load i1, ptr %l54, !tbaa !21
  br i1 %t64, label %bb21, label %bb22
bb21:
  store i1 true, ptr %l55, !tbaa !21
  br label %bb24
bb22:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/effects:Effects", ptr %t65, i32 0, i32 17
  %t68 = getelementptr %"compiler/effects:link", ptr %l7, i32 0, i32 0
  %t69 = load i64, ptr %t68, !tbaa !24
  %t72 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t67, i64 %t69)
  store i64 %t72, ptr %l59
  br label %bb23
bb23:
  %t73 = load i64, ptr %l59, !tbaa !24
  %t74 = icmp eq i64 %t73, 2
  store i1 %t74, ptr %l55, !tbaa !21
  br label %bb24
bb24:
  %t76 = load i1, ptr %l55, !tbaa !21
  %t77 = xor i1 %t76, true
  br i1 %t77, label %bb25, label %bb26
bb25:
  br label %bb73
bb26:
  br label %bb27
bb27:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/effects:Effects", ptr %t79, i32 0, i32 11
  %t82 = getelementptr %"compiler/effects:link", ptr %l7, i32 0, i32 0
  %t83 = load i64, ptr %t82, !tbaa !24
  %t86 = call %"compiler/effects:Facts" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3aFacts_3e_2eAt_3ccompiler_2feffects_3aFacts_3e(ptr %v0, ptr %t81, i64 %t83)
  store %"compiler/effects:Facts" %t86, ptr %l65
  br label %bb28
bb28:
  %t87 = getelementptr %"compiler/effects:Facts", ptr %l65, i32 0, i32 23
  %t88 = load i64, ptr %t87, !tbaa !24
  %t89 = getelementptr %"compiler/effects:link", ptr %l7, i32 0, i32 1
  %t90 = load i64, ptr %t89, !tbaa !24
  %t93 = call i1 @compiler_2feffects_2ehasBit(i64 %t88, i64 %t90)
  store i1 %t93, ptr %l68
  br label %bb29
bb29:
  %t94 = load i1, ptr %l68, !tbaa !21
  %t95 = xor i1 %t94, true
  br i1 %t95, label %bb30, label %bb31
bb30:
  br label %bb73
bb31:
  br label %bb32
bb32:
  %t97 = getelementptr %"compiler/effects:link", ptr %l7, i32 0, i32 2
  %t98 = load i64, ptr %t97, !tbaa !24
  %t99 = load i64, ptr @G_2ecompiler_2feffects_2eglobalParam, !tbaa !24
  %t102 = icmp eq i64 %t98, %t99
  br i1 %t102, label %bb33, label %bb34
bb33:
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t106 = getelementptr %"compiler/effects:Effects", ptr %t104, i32 0, i32 11
  %t107 = load i64, ptr %l1, !tbaa !24
  %t110 = call %"compiler/effects:Facts" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3aFacts_3e_2eAt_3ccompiler_2feffects_3aFacts_3e(ptr %v0, ptr %t106, i64 %t107)
  store %"compiler/effects:Facts" %t110, ptr %l76
  br label %bb35
bb34:
  br label %bb48
bb35:
  %t111 = getelementptr %"compiler/effects:Facts", ptr %l76, i32 0, i32 3
  %t112 = load i1, ptr %t111, !tbaa !21
  br i1 %t112, label %bb36, label %bb37
bb36:
  br label %bb73
bb37:
  br label %bb38
bb38:
  %t114 = load ptr, ptr %l2, !tbaa !29
  store ptr %t114, ptr %l8, !tbaa !29
  store i64 0, ptr %l9, !tbaa !24
  br label %bb39
bb39:
  %t116 = load i64, ptr %l9, !tbaa !24
  store i64 %t116, ptr %l79, !tbaa !24
  %t117 = load ptr, ptr %l8, !tbaa !29
  %t119 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t117)
  store i64 %t119, ptr %l81
  br label %bb40
bb40:
  %t120 = load i64, ptr %l79, !tbaa !24
  %t121 = load i64, ptr %l81, !tbaa !24
  %t122 = icmp slt i64 %t120, %t121
  %t124 = xor i1 %t122, true
  br i1 %t124, label %bb41, label %bb42
bb41:
  br label %bb47
bb42:
  br label %bb43
bb43:
  %t126 = load ptr, ptr %l8, !tbaa !29
  %t127 = load i64, ptr %l9, !tbaa !24
  %t130 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t126, i64 %t127)
  store i64 %t130, ptr %l86
  br label %bb44
bb44:
  %t131 = load i64, ptr %l86, !tbaa !24
  store i1 true, ptr %l12, !tbaa !21
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t136 = getelementptr %"compiler/effects:Effects", ptr %t134, i32 0, i32 11
  %t140 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3aFacts_3e_2eRefMut_3ccompiler_2feffects_3aFacts_3e(ptr %v0, ptr %v0, ptr %t136, i64 %t131)
  store ptr %t140, ptr %l91
  br label %bb45
bb45:
  %t141 = load ptr, ptr %l91, !tbaa !29
  %t143 = load i1, ptr %l12, !tbaa !21
  %t146 = getelementptr %"compiler/effects:Facts", ptr %t141, i32 0, i32 3
  store i1 %t143, ptr %t146, !tbaa !21
  br label %bb46
bb46:
  %t147 = load i64, ptr %l9, !tbaa !24
  %t150 = add i64 %t147, 1
  store i64 %t150, ptr %l9, !tbaa !24
  br label %bb39
bb47:
  %t152 = load i64, ptr %l4, !tbaa !24
  %t155 = add i64 %t152, 1
  store i64 %t155, ptr %l4, !tbaa !24
  br label %bb73
bb48:
  %t157 = getelementptr %"compiler/effects:link", ptr %l7, i32 0, i32 2
  %t158 = load i64, ptr %t157, !tbaa !24
  %t159 = load i64, ptr @G_2ecompiler_2feffects_2eoutParam, !tbaa !24
  %t162 = icmp eq i64 %t158, %t159
  br i1 %t162, label %bb49, label %bb50
bb49:
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t166 = getelementptr %"compiler/effects:Effects", ptr %t164, i32 0, i32 11
  %t167 = load i64, ptr %l1, !tbaa !24
  %t170 = call %"compiler/effects:Facts" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3aFacts_3e_2eAt_3ccompiler_2feffects_3aFacts_3e(ptr %v0, ptr %t166, i64 %t167)
  store %"compiler/effects:Facts" %t170, ptr %l106
  br label %bb51
bb50:
  br label %bb64
bb51:
  %t171 = getelementptr %"compiler/effects:Facts", ptr %l106, i32 0, i32 19
  %t172 = load i1, ptr %t171, !tbaa !21
  br i1 %t172, label %bb52, label %bb53
bb52:
  br label %bb73
bb53:
  br label %bb54
bb54:
  %t174 = load ptr, ptr %l2, !tbaa !29
  store ptr %t174, ptr %l14, !tbaa !29
  store i64 0, ptr %l15, !tbaa !24
  br label %bb55
bb55:
  %t176 = load i64, ptr %l15, !tbaa !24
  store i64 %t176, ptr %l109, !tbaa !24
  %t177 = load ptr, ptr %l14, !tbaa !29
  %t179 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t177)
  store i64 %t179, ptr %l111
  br label %bb56
bb56:
  %t180 = load i64, ptr %l109, !tbaa !24
  %t181 = load i64, ptr %l111, !tbaa !24
  %t182 = icmp slt i64 %t180, %t181
  %t184 = xor i1 %t182, true
  br i1 %t184, label %bb57, label %bb58
bb57:
  br label %bb63
bb58:
  br label %bb59
bb59:
  %t186 = load ptr, ptr %l14, !tbaa !29
  %t187 = load i64, ptr %l15, !tbaa !24
  %t190 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t186, i64 %t187)
  store i64 %t190, ptr %l116
  br label %bb60
bb60:
  %t191 = load i64, ptr %l116, !tbaa !24
  store i1 true, ptr %l18, !tbaa !21
  %t194 = load ptr, ptr %l0, !tbaa !29
  %t196 = getelementptr %"compiler/effects:Effects", ptr %t194, i32 0, i32 11
  %t200 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3aFacts_3e_2eRefMut_3ccompiler_2feffects_3aFacts_3e(ptr %v0, ptr %v0, ptr %t196, i64 %t191)
  store ptr %t200, ptr %l121
  br label %bb61
bb61:
  %t201 = load ptr, ptr %l121, !tbaa !29
  %t203 = load i1, ptr %l18, !tbaa !21
  %t206 = getelementptr %"compiler/effects:Facts", ptr %t201, i32 0, i32 19
  store i1 %t203, ptr %t206, !tbaa !21
  br label %bb62
bb62:
  %t207 = load i64, ptr %l15, !tbaa !24
  %t210 = add i64 %t207, 1
  store i64 %t210, ptr %l15, !tbaa !24
  br label %bb55
bb63:
  %t212 = load i64, ptr %l4, !tbaa !24
  %t215 = add i64 %t212, 1
  store i64 %t215, ptr %l4, !tbaa !24
  br label %bb73
bb64:
  %t217 = load ptr, ptr %l0, !tbaa !29
  %t219 = getelementptr %"compiler/effects:Effects", ptr %t217, i32 0, i32 11
  %t220 = load i64, ptr %l1, !tbaa !24
  %t223 = call %"compiler/effects:Facts" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3aFacts_3e_2eAt_3ccompiler_2feffects_3aFacts_3e(ptr %v0, ptr %t219, i64 %t220)
  store %"compiler/effects:Facts" %t223, ptr %l133
  br label %bb65
bb65:
  %t224 = getelementptr %"compiler/effects:Facts", ptr %l133, i32 0, i32 23
  %t225 = load i64, ptr %t224, !tbaa !24
  %t226 = getelementptr %"compiler/effects:link", ptr %l7, i32 0, i32 2
  %t227 = load i64, ptr %t226, !tbaa !24
  %t230 = call i1 @compiler_2feffects_2ehasBit(i64 %t225, i64 %t227)
  store i1 %t230, ptr %l136
  br label %bb66
bb66:
  %t231 = load i1, ptr %l136, !tbaa !21
  br i1 %t231, label %bb67, label %bb68
bb67:
  br label %bb73
bb68:
  br label %bb69
bb69:
  %t232 = load i64, ptr %l1, !tbaa !24
  store i64 %t232, ptr %l20, !tbaa !24
  %t234 = load ptr, ptr %l0, !tbaa !29
  %t236 = getelementptr %"compiler/effects:Effects", ptr %t234, i32 0, i32 11
  %t237 = load i64, ptr %l1, !tbaa !24
  %t240 = call %"compiler/effects:Facts" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3aFacts_3e_2eAt_3ccompiler_2feffects_3aFacts_3e(ptr %v0, ptr %t236, i64 %t237)
  store %"compiler/effects:Facts" %t240, ptr %l141
  br label %bb70
bb70:
  %t241 = getelementptr %"compiler/effects:Facts", ptr %l141, i32 0, i32 23
  %t242 = load i64, ptr %t241, !tbaa !24
  store i64 %t242, ptr %l142, !tbaa !24
  %t243 = getelementptr %"compiler/effects:link", ptr %l7, i32 0, i32 2
  %t244 = load i64, ptr %t243, !tbaa !24
  %t246 = call i64 @compiler_2feffects_2eparamBit(i64 %t244)
  store i64 %t246, ptr %l144
  br label %bb71
bb71:
  %t247 = load i64, ptr %l142, !tbaa !24
  %t248 = load i64, ptr %l144, !tbaa !24
  %t249 = or i64 %t247, %t248
  store i64 %t249, ptr %l21, !tbaa !24
  %t251 = load ptr, ptr %l0, !tbaa !29
  %t253 = getelementptr %"compiler/effects:Effects", ptr %t251, i32 0, i32 11
  %t254 = load i64, ptr %l20, !tbaa !24
  %t257 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3aFacts_3e_2eRefMut_3ccompiler_2feffects_3aFacts_3e(ptr %v0, ptr %v0, ptr %t253, i64 %t254)
  store ptr %t257, ptr %l149
  br label %bb72
bb72:
  %t258 = load ptr, ptr %l149, !tbaa !29
  %t260 = load i64, ptr %l21, !tbaa !24
  %t263 = getelementptr %"compiler/effects:Facts", ptr %t258, i32 0, i32 23
  store i64 %t260, ptr %t263, !tbaa !24
  %t264 = load i64, ptr %l4, !tbaa !24
  %t267 = add i64 %t264, 1
  store i64 %t267, ptr %l4, !tbaa !24
  br label %bb73
bb73:
  %t269 = load i64, ptr %l6, !tbaa !24
  %t272 = add i64 %t269, 1
  store i64 %t272, ptr %l6, !tbaa !24
  br label %bb3
bb74:
  call void @__olang_scope_close(ptr %s1)
  %t274 = load i64, ptr %l4, !tbaa !24
  store i64 %t274, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eprim(ptr %v0, ptr %v1, ptr %a0, i32 %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l15 = alloca ptr
  %l18 = alloca ptr
  %l19 = alloca { i64, ptr }
  %l21 = alloca i32
  %l22 = alloca i32
  %l37 = alloca { i64, ptr }
  %l53 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l1, !range !{i32 0, i32 54}
  %t3 = trunc i64 29 to i32
  %t4 = icmp eq i32 %t1, %t3
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/effects:Effects", ptr %t6, i32 0, i32 25
  %t9 = getelementptr %"compiler/effects:Facts", ptr %t8, i32 0, i32 14
  store i1 true, ptr %t9, !tbaa !21
  br label %bb42
bb4:
  %t10 = load i32, ptr %l1, !range !{i32 0, i32 54}
  %t12 = trunc i64 31 to i32
  %t13 = icmp eq i32 %t10, %t12
  br i1 %t13, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb14
bb7:
  %t15 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t19 = icmp sgt i64 %t17, 0
  br i1 %t19, label %bb8, label %bb9
bb8:
  %t21 = load ptr, ptr %l0, !tbaa !29
  store ptr %t21, ptr %l15, !tbaa !29
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/effects:Effects", ptr %t22, i32 0, i32 0
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t27 = getelementptr %"compiler/generic:Program", ptr %t25, i32 0, i32 2
  store ptr %t27, ptr %l18, !tbaa !29
  %t28 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t28, ptr %l19, !tbaa !27
  %t29 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !27
  %t31 = getelementptr ptr, ptr %t30, i64 0
  %t32 = load ptr, ptr %t31, !tbaa !39
  %t34 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t32)
  store i32 %t34, ptr %l21
  br label %bb10
bb9:
  br label %bb13
bb10:
  %t35 = load ptr, ptr %l18, !tbaa !29
  %t36 = load i32, ptr %l21, !tbaa !23
  %t37 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t35, i32 %t36)
  store i32 %t37, ptr %l22
  br label %bb11
bb11:
  %t38 = load ptr, ptr %l15, !tbaa !29
  %t39 = load i32, ptr %l22, !tbaa !23
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2edropsCalled(ptr %v0, ptr %t38, i32 %t39, i64 0)
  br label %bb12
bb12:
  br label %bb13
bb13:
  br label %bb42
bb14:
  %t40 = load i32, ptr %l1, !range !{i32 0, i32 54}
  %t42 = trunc i64 25 to i32
  %t43 = icmp eq i32 %t40, %t42
  br i1 %t43, label %bb15, label %bb16
bb15:
  br label %bb25
bb16:
  %t45 = load i32, ptr %l1, !range !{i32 0, i32 54}
  %t47 = trunc i64 26 to i32
  %t48 = icmp eq i32 %t45, %t47
  br i1 %t48, label %bb17, label %bb18
bb17:
  br label %bb25
bb18:
  %t50 = load i32, ptr %l1, !range !{i32 0, i32 54}
  %t52 = trunc i64 27 to i32
  %t53 = icmp eq i32 %t50, %t52
  br i1 %t53, label %bb19, label %bb20
bb19:
  br label %bb25
bb20:
  %t55 = load i32, ptr %l1, !range !{i32 0, i32 54}
  %t57 = trunc i64 28 to i32
  %t58 = icmp eq i32 %t55, %t57
  br i1 %t58, label %bb21, label %bb22
bb21:
  br label %bb25
bb22:
  %t60 = load i32, ptr %l1, !range !{i32 0, i32 54}
  %t62 = trunc i64 41 to i32
  %t63 = icmp eq i32 %t60, %t62
  br i1 %t63, label %bb23, label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb33
bb25:
  %t65 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t67 = extractvalue { i64, ptr } %t65, 0
  %t69 = icmp sgt i64 %t67, 0
  br i1 %t69, label %bb26, label %bb27
bb26:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t72 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t72, ptr %l37, !tbaa !27
  %t73 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t74 = load ptr, ptr %t73, !tbaa !27
  %t75 = getelementptr ptr, ptr %t74, i64 0
  %t76 = load ptr, ptr %t75, !tbaa !39
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ewritten(ptr %v0, ptr %v1, ptr %t71, ptr %t76)
  br label %bb28
bb27:
  br label %bb29
bb28:
  br label %bb29
bb29:
  %t79 = load i32, ptr %l1, !range !{i32 0, i32 54}
  %t81 = trunc i64 41 to i32
  %t82 = icmp eq i32 %t79, %t81
  %t84 = xor i1 %t82, true
  br i1 %t84, label %bb30, label %bb31
bb30:
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t88 = getelementptr %"compiler/effects:Effects", ptr %t86, i32 0, i32 25
  %t89 = getelementptr %"compiler/effects:Facts", ptr %t88, i32 0, i32 6
  store i1 true, ptr %t89, !tbaa !21
  br label %bb32
bb31:
  br label %bb32
bb32:
  br label %bb42
bb33:
  %t90 = load i32, ptr %l1, !range !{i32 0, i32 54}
  %t92 = trunc i64 24 to i32
  %t93 = icmp eq i32 %t90, %t92
  br i1 %t93, label %bb34, label %bb35
bb34:
  br label %bb36
bb35:
  br label %bb37
bb36:
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t97 = getelementptr %"compiler/effects:Effects", ptr %t95, i32 0, i32 25
  %t98 = getelementptr %"compiler/effects:Facts", ptr %t97, i32 0, i32 6
  store i1 true, ptr %t98, !tbaa !21
  br label %bb42
bb37:
  br i1 true, label %bb38, label %bb39
bb38:
  br label %bb40
bb39:
  br label %bb41
bb40:
  br label %bb42
bb41:
  call void @__olang_check_failed(ptr @olang_loc_31e57a958c31a5ba_705aefa950dbf3e6)
  unreachable
bb42:
  %t99 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t99, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t101 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t103 = extractvalue { i64, ptr } %t101, 0
  store i64 %t103, ptr %l5, !tbaa !24
  br label %bb43
bb43:
  %t105 = load i64, ptr %l4, !tbaa !24
  %t106 = load i64, ptr %l5, !tbaa !24
  %t109 = icmp slt i64 %t105, %t106
  %t111 = xor i1 %t109, true
  br i1 %t111, label %bb44, label %bb45
bb44:
  br label %bb49
bb45:
  br label %bb46
bb46:
  %t113 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t113, ptr %l53, !tbaa !27
  %t114 = load i64, ptr %l4, !tbaa !24
  %t116 = getelementptr { i64, ptr }, ptr %l53, i32 0, i32 1
  %t117 = load ptr, ptr %t116, !tbaa !27
  %t118 = getelementptr ptr, ptr %t117, i64 %t114
  %t119 = load ptr, ptr %t118, !tbaa !39
  %t121 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eexpr(ptr %v0, ptr %v1, ptr %t121, ptr %t119)
  br label %bb47
bb47:
  br label %bb48
bb48:
  %t126 = load i64, ptr %l4, !tbaa !24
  %t129 = add i64 %t126, 1
  store i64 %t129, ptr %l4, !tbaa !24
  br label %bb43
bb49:
  br label %ret
ret:
  ret void
}

define dso_local %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ereach(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l12 = alloca i64
  %l13 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l17 = alloca i64
  %l21 = alloca i64
  %l24 = alloca i64
  %l42 = alloca ptr
  %l49 = alloca i64
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i64 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ereachIndex(ptr %v0, ptr %t1, i32 %a1)
  store i64 %t5, ptr %l12
  br label %bb1
bb1:
  %t6 = load i64, ptr %l12, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  %t7 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %v1)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t7, ptr %l13
  br label %bb2
bb2:
  %t8 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l13
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t8, ptr %l3
  store i64 0, ptr %l4, !tbaa !24
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/effects:Effects", ptr %t9, i32 0, i32 59
  %t12 = load i64, ptr %l2, !tbaa !24
  %t15 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t11, i64 %t12)
  store i64 %t15, ptr %l17
  br label %bb3
bb3:
  %t16 = load i64, ptr %l17, !tbaa !24
  store i64 %t16, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t17 = load i64, ptr %l5, !tbaa !24
  %t18 = load i64, ptr %l4, !tbaa !24
  %t21 = icmp sgt i64 %t17, %t18
  br i1 %t21, label %bb4, label %bb5
bb4:
  %t23 = load i64, ptr %l6, !tbaa !24
  %t25 = icmp sgt i64 %t23, 0
  br i1 %t25, label %bb6, label %bb7
bb5:
  store i64 0, ptr %l21, !tbaa !24
  br label %bb9
bb6:
  %t27 = load i64, ptr %l5, !tbaa !24
  %t28 = load i64, ptr %l4, !tbaa !24
  %t31 = sub i64 %t27, %t28
  %t32 = load i64, ptr %l6, !tbaa !24
  %t35 = add i64 %t31, %t32
  %t37 = sub i64 %t35, 1
  %t38 = load i64, ptr %l6, !tbaa !24
  %t41 = sdiv i64 %t37, %t38
  store i64 %t41, ptr %l24, !tbaa !24
  br label %bb8
bb7:
  store i64 0, ptr %l24, !tbaa !24
  br label %bb8
bb8:
  %t43 = load i64, ptr %l24, !tbaa !24
  store i64 %t43, ptr %l21, !tbaa !24
  br label %bb9
bb9:
  %t44 = load i64, ptr %l21, !tbaa !24
  store i64 %t44, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb10
bb10:
  %t45 = load i64, ptr %l8, !tbaa !24
  %t46 = load i64, ptr %l7, !tbaa !24
  %t49 = icmp slt i64 %t45, %t46
  %t51 = xor i1 %t49, true
  br i1 %t51, label %bb11, label %bb12
bb11:
  br label %bb17
bb12:
  br label %bb13
bb13:
  %t53 = load i64, ptr %l4, !tbaa !24
  %t54 = load i64, ptr %l8, !tbaa !24
  %t55 = load i64, ptr %l6, !tbaa !24
  %t58 = mul i64 %t54, %t55
  %t61 = add i64 %t53, %t58
  store ptr %l3, ptr %l42, !tbaa !29
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/effects:Effects", ptr %t63, i32 0, i32 59
  %t66 = load i64, ptr %l2, !tbaa !24
  %t68 = add i64 %t66, 1
  %t72 = add i64 %t68, %t61
  %t75 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t65, i64 %t72)
  store i64 %t75, ptr %l49
  br label %bb14
bb14:
  %t76 = load ptr, ptr %l42, !tbaa !29
  %t77 = load i64, ptr %l49, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v1, ptr %t76, i64 %t77, i1 true)
  br label %bb15
bb15:
  br label %bb16
bb16:
  %t78 = load i64, ptr %l8, !tbaa !24
  %t81 = add i64 %t78, 1
  store i64 %t81, ptr %l8, !tbaa !24
  br label %bb10
bb17:
  %t83 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l3
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t83, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

define dso_local %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ereachBeyond(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l4 = alloca %"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9"
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l18 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l20 = alloca %"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9"
  %l21 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i32
  %l26 = alloca i1
  %l32 = alloca i1
  %l35 = alloca i32
  %l38 = alloca i32
  %l41 = alloca i1
  %l44 = alloca i32
  %l48 = alloca i32
  %l53 = alloca i64
  %l57 = alloca i64
  %l61 = alloca i64
  %l64 = alloca i64
  %l82 = alloca ptr
  %l89 = alloca i64
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/effects:Effects", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  store ptr %t6, ptr %l2, !tbaa !29
  %t8 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %v2)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t8, ptr %l18
  br label %bb1
bb1:
  %t9 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l18
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t9, ptr %l3
  %t12 = call %"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eKeys_3cI64_2c_20Bool_3e(ptr %v1, ptr %v1, ptr %a1)
  store %"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9" %t12, ptr %l20
  br label %bb2
bb2:
  %t13 = load %"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9", ptr %l20
  store %"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9" %t13, ptr %l4
  br label %bb3
bb3:
  %t15 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapKeyIter_3cI64_2c_20Bool_3e_2eNext_3cI64_2c_20Bool_3e(ptr %v1, ptr %l4)
  %t16 = extractvalue { i32, i64 } %t15, 1
  %t17 = extractvalue { i32, i64 } %t15, 0
  store i32 %t17, ptr %l24
  %t18 = icmp ne i32 %t17, 0
  br i1 %t18, label %bb5, label %ok.19, !prof !99
ok.19:
  store i64 %t16, ptr %l23
  br label %bb4
bb4:
  %t20 = load i64, ptr %l23, !tbaa !24
  store i64 %t20, ptr %l21, !tbaa !24
  br label %bb7
bb5:
  %t21 = load i32, ptr %l24, !tbaa !23
  %t22 = ashr i32 %t21, 16
  %t24 = icmp eq i32 %t22, 1
  store i1 %t24, ptr %l26, !tbaa !21
  br label %bb6
bb6:
  br label %bb42
bb7:
  %t25 = load i64, ptr %l21, !tbaa !24
  %t28 = trunc i64 %t25 to i32
  store i32 %t28, ptr %l6, !tbaa !23
  store i32 0, ptr %l7, !tbaa !23
  %t31 = load ptr, ptr %l2, !tbaa !29
  %t32 = load i32, ptr %l6, !tbaa !23
  %t35 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t31, i32 %t32)
  store i1 %t35, ptr %l32
  br label %bb8
bb8:
  %t36 = load i1, ptr %l32, !tbaa !21
  br i1 %t36, label %bb9, label %bb10
bb9:
  %t37 = load ptr, ptr %l2, !tbaa !29
  %t38 = load i32, ptr %l6, !tbaa !23
  %t41 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t37, i32 %t38)
  store i32 %t41, ptr %l35
  br label %bb11
bb10:
  %t42 = load ptr, ptr %l2, !tbaa !29
  %t43 = load i32, ptr %l6, !tbaa !23
  %t46 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t42, i32 %t43)
  store i32 %t46, ptr %l38
  br label %bb12
bb11:
  %t47 = load i32, ptr %l35, !tbaa !23
  store i32 %t47, ptr %l7, !tbaa !23
  br label %bb21
bb12:
  %t48 = load i32, ptr %l38, !range !{i32 0, i32 33}
  %t50 = trunc i64 19 to i32
  %t51 = icmp eq i32 %t48, %t50
  br i1 %t51, label %bb13, label %bb14
bb13:
  %t53 = load ptr, ptr %l2, !tbaa !29
  %t54 = load i32, ptr %l6, !tbaa !23
  %t57 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t53, i32 %t54)
  store i32 %t57, ptr %l44
  br label %bb15
bb14:
  store i1 false, ptr %l41, !tbaa !21
  br label %bb16
bb15:
  %t58 = load i32, ptr %l44, !tbaa !23
  %t59 = icmp eq i32 %t58, 0
  store i1 %t59, ptr %l41, !tbaa !21
  br label %bb16
bb16:
  %t61 = load i1, ptr %l41, !tbaa !21
  br i1 %t61, label %bb17, label %bb18
bb17:
  %t62 = load ptr, ptr %l2, !tbaa !29
  %t63 = load i32, ptr %l6, !tbaa !23
  %t66 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t62, i32 %t63)
  store i32 %t66, ptr %l48
  br label %bb19
bb18:
  br label %bb20
bb19:
  %t67 = load i32, ptr %l48, !tbaa !23
  store i32 %t67, ptr %l7, !tbaa !23
  br label %bb20
bb20:
  br label %bb21
bb21:
  %t68 = load i32, ptr %l7, !tbaa !23
  %t70 = icmp eq i32 %t68, 0
  br i1 %t70, label %bb22, label %bb23
bb22:
  br label %bb41
bb23:
  br label %bb24
bb24:
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t73 = load i32, ptr %l7, !tbaa !23
  %t76 = call i64 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ereachIndex(ptr %v0, ptr %t72, i32 %t73)
  store i64 %t76, ptr %l53
  br label %bb25
bb25:
  %t77 = load i64, ptr %l53, !tbaa !24
  store i64 %t77, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t80 = getelementptr %"compiler/effects:Effects", ptr %t78, i32 0, i32 59
  %t81 = load i64, ptr %l8, !tbaa !24
  %t84 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t80, i64 %t81)
  store i64 %t84, ptr %l57
  br label %bb26
bb26:
  %t85 = load i64, ptr %l57, !tbaa !24
  store i64 %t85, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t86 = load i64, ptr %l10, !tbaa !24
  %t87 = load i64, ptr %l9, !tbaa !24
  %t90 = icmp sgt i64 %t86, %t87
  br i1 %t90, label %bb27, label %bb28
bb27:
  %t92 = load i64, ptr %l11, !tbaa !24
  %t94 = icmp sgt i64 %t92, 0
  br i1 %t94, label %bb29, label %bb30
bb28:
  store i64 0, ptr %l61, !tbaa !24
  br label %bb32
bb29:
  %t96 = load i64, ptr %l10, !tbaa !24
  %t97 = load i64, ptr %l9, !tbaa !24
  %t100 = sub i64 %t96, %t97
  %t101 = load i64, ptr %l11, !tbaa !24
  %t104 = add i64 %t100, %t101
  %t106 = sub i64 %t104, 1
  %t107 = load i64, ptr %l11, !tbaa !24
  %t110 = sdiv i64 %t106, %t107
  store i64 %t110, ptr %l64, !tbaa !24
  br label %bb31
bb30:
  store i64 0, ptr %l64, !tbaa !24
  br label %bb31
bb31:
  %t112 = load i64, ptr %l64, !tbaa !24
  store i64 %t112, ptr %l61, !tbaa !24
  br label %bb32
bb32:
  %t113 = load i64, ptr %l61, !tbaa !24
  store i64 %t113, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb33
bb33:
  %t114 = load i64, ptr %l13, !tbaa !24
  %t115 = load i64, ptr %l12, !tbaa !24
  %t118 = icmp slt i64 %t114, %t115
  %t120 = xor i1 %t118, true
  br i1 %t120, label %bb34, label %bb35
bb34:
  br label %bb40
bb35:
  br label %bb36
bb36:
  %t122 = load i64, ptr %l9, !tbaa !24
  %t123 = load i64, ptr %l13, !tbaa !24
  %t124 = load i64, ptr %l11, !tbaa !24
  %t127 = mul i64 %t123, %t124
  %t130 = add i64 %t122, %t127
  store ptr %l3, ptr %l82, !tbaa !29
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t134 = getelementptr %"compiler/effects:Effects", ptr %t132, i32 0, i32 59
  %t135 = load i64, ptr %l8, !tbaa !24
  %t137 = add i64 %t135, 1
  %t141 = add i64 %t137, %t130
  %t144 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t134, i64 %t141)
  store i64 %t144, ptr %l89
  br label %bb37
bb37:
  %t145 = load ptr, ptr %l82, !tbaa !29
  %t146 = load i64, ptr %l89, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v2, ptr %t145, i64 %t146, i1 true)
  br label %bb38
bb38:
  br label %bb39
bb39:
  %t147 = load i64, ptr %l13, !tbaa !24
  %t150 = add i64 %t147, 1
  store i64 %t150, ptr %l13, !tbaa !24
  br label %bb33
bb40:
  br label %bb41
bb41:
  br label %bb3
bb42:
  %t152 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l3
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t152, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

define dso_local void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ereadOut(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l16 = alloca i1
  %l18 = alloca i1
  %l23 = alloca i1
  %l25 = alloca ptr
  %l29 = alloca i64
  %l32 = alloca i64
  %l35 = alloca i1
  %l40 = alloca i1
  %l43 = alloca ptr
  %l46 = alloca ptr
  %l50 = alloca ptr
  %l53 = alloca i32
  %l54 = alloca i1
  %l59 = alloca i64
  %l63 = alloca i64
  %l66 = alloca i64
  %l85 = alloca i64
  %l89 = alloca i1
  %l91 = alloca { i64, ptr }
  %l94 = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/effects:Effects", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t7 = load i32, ptr %l2, !tbaa !23
  %t10 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t6, i32 %t7)
  store i1 %t10, ptr %l16
  br label %bb1
bb1:
  %t11 = load i1, ptr %l16, !tbaa !21
  %t12 = xor i1 %t11, true
  br i1 %t12, label %bb2, label %bb3
bb2:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/effects:Effects", ptr %t14, i32 0, i32 0
  %t17 = load ptr, ptr %t16, !tbaa !29
  %t19 = getelementptr %"compiler/generic:Program", ptr %t17, i32 0, i32 2
  %t20 = load i32, ptr %l2, !tbaa !23
  %t23 = call i1 @compiler_2ftyped_2eHoldsOwned(ptr %v0, ptr %t19, i32 %t20)
  store i1 %t23, ptr %l23
  br label %bb4
bb3:
  store i1 false, ptr %l18, !tbaa !21
  br label %bb5
bb4:
  %t24 = load i1, ptr %l23, !tbaa !21
  store i1 %t24, ptr %l18, !tbaa !21
  br label %bb5
bb5:
  %t25 = load i1, ptr %l18, !tbaa !21
  br i1 %t25, label %bb6, label %bb7
bb6:
  br label %ret
bb7:
  br label %bb8
bb8:
  %t28 = call ptr @compiler_2ftyped_2eCall_2eQuietRead(ptr %v1, ptr %v1, ptr %a1)
  store ptr %t28, ptr %l25
  br label %bb9
bb9:
  %t29 = load ptr, ptr %l25, !tbaa !29
  store ptr %t29, ptr %l3, !tbaa !29
  %t30 = load ptr, ptr %l3, !tbaa !29
  %t32 = icmp eq ptr %t30, null
  br i1 %t32, label %bb10, label %bb11
bb10:
  br label %ret
bb11:
  br label %bb12
bb12:
  %t34 = load ptr, ptr %l3, !tbaa !29
  %t36 = call i64 @compiler_2ftyped_2eCalleeBody(ptr %v1, ptr %t34)
  store i64 %t36, ptr %l29
  br label %bb13
bb13:
  %t37 = load i64, ptr %l29, !tbaa !24
  store i64 %t37, ptr %l4, !tbaa !24
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t39 = load i64, ptr %l4, !tbaa !24
  %t42 = call i64 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eviewsOf(ptr %v0, ptr %t38, i64 %t39)
  store i64 %t42, ptr %l32
  br label %bb14
bb14:
  %t43 = load i64, ptr %l32, !tbaa !24
  store i64 %t43, ptr %l5, !tbaa !24
  %t44 = load i64, ptr %l5, !tbaa !24
  %t46 = icmp sle i64 %t44, 0
  br i1 %t46, label %bb15, label %bb16
bb15:
  store i1 true, ptr %l35, !tbaa !21
  br label %bb17
bb16:
  %t48 = load i64, ptr %l5, !tbaa !24
  %t49 = load i64, ptr @G_2ecompiler_2ftyped_2eViewOther, !tbaa !24
  %t52 = and i64 %t48, %t49
  %t54 = icmp ne i64 %t52, 0
  store i1 %t54, ptr %l35, !tbaa !21
  br label %bb17
bb17:
  %t56 = load i1, ptr %l35, !tbaa !21
  br i1 %t56, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l40, !tbaa !21
  br label %bb23
bb19:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/effects:Effects", ptr %t57, i32 0, i32 0
  %t60 = load ptr, ptr %t59, !tbaa !29
  %t62 = getelementptr %"compiler/generic:Program", ptr %t60, i32 0, i32 2
  store ptr %t62, ptr %l43, !tbaa !29
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/effects:Effects", ptr %t63, i32 0, i32 0
  %t66 = load ptr, ptr %t65, !tbaa !29
  %t68 = getelementptr %"compiler/generic:Program", ptr %t66, i32 0, i32 2
  store ptr %t68, ptr %l46, !tbaa !29
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/effects:Effects", ptr %t69, i32 0, i32 1
  %t72 = load i64, ptr %l4, !tbaa !24
  %t75 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t71, i64 %t72)
  store ptr %t75, ptr %l50
  br label %bb20
bb20:
  %t76 = load ptr, ptr %l50, !tbaa !29
  %t78 = getelementptr %"compiler/typed:Body", ptr %t76, i32 0, i32 2
  %t79 = load i32, ptr %t78, !tbaa !23
  %t80 = load ptr, ptr %l46, !tbaa !29
  %t82 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t80, i32 %t79)
  store i32 %t82, ptr %l53
  br label %bb21
bb21:
  %t83 = load ptr, ptr %l43, !tbaa !29
  %t84 = load i32, ptr %l53, !tbaa !23
  %t85 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRunsCopy(ptr %v0, ptr %t83, i32 %t84)
  store i1 %t85, ptr %l54
  br label %bb22
bb22:
  %t86 = load i1, ptr %l54, !tbaa !21
  store i1 %t86, ptr %l40, !tbaa !21
  br label %bb23
bb23:
  %t87 = load i1, ptr %l40, !tbaa !21
  br i1 %t87, label %bb24, label %bb25
bb24:
  br label %ret
bb25:
  br label %bb26
bb26:
  store i64 0, ptr %l6, !tbaa !24
  %t88 = load ptr, ptr %l3, !tbaa !29
  %t90 = getelementptr %"compiler/typed:Call", ptr %t88, i32 0, i32 1
  %t91 = load { i64, ptr }, ptr %t90, !tbaa !27
  %t93 = extractvalue { i64, ptr } %t91, 0
  %t94 = load i64, ptr @G_2ecompiler_2ftyped_2eViewBits, !tbaa !24
  %t97 = call i64 @std_2fprelude_2fnumber_2eI64_2eMin_3cI64_3e(i64 %t93, i64 %t94)
  store i64 %t97, ptr %l59
  br label %bb27
bb27:
  %t98 = load i64, ptr %l59, !tbaa !24
  store i64 %t98, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t99 = load i64, ptr %l7, !tbaa !24
  %t100 = load i64, ptr %l6, !tbaa !24
  %t103 = icmp sgt i64 %t99, %t100
  br i1 %t103, label %bb28, label %bb29
bb28:
  %t105 = load i64, ptr %l8, !tbaa !24
  %t107 = icmp sgt i64 %t105, 0
  br i1 %t107, label %bb30, label %bb31
bb29:
  store i64 0, ptr %l63, !tbaa !24
  br label %bb33
bb30:
  %t109 = load i64, ptr %l7, !tbaa !24
  %t110 = load i64, ptr %l6, !tbaa !24
  %t113 = sub i64 %t109, %t110
  %t114 = load i64, ptr %l8, !tbaa !24
  %t117 = add i64 %t113, %t114
  %t119 = sub i64 %t117, 1
  %t120 = load i64, ptr %l8, !tbaa !24
  %t123 = sdiv i64 %t119, %t120
  store i64 %t123, ptr %l66, !tbaa !24
  br label %bb32
bb31:
  store i64 0, ptr %l66, !tbaa !24
  br label %bb32
bb32:
  %t125 = load i64, ptr %l66, !tbaa !24
  store i64 %t125, ptr %l63, !tbaa !24
  br label %bb33
bb33:
  %t126 = load i64, ptr %l63, !tbaa !24
  store i64 %t126, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb34
bb34:
  %t127 = load i64, ptr %l10, !tbaa !24
  %t128 = load i64, ptr %l9, !tbaa !24
  %t131 = icmp slt i64 %t127, %t128
  %t133 = xor i1 %t131, true
  br i1 %t133, label %bb35, label %bb36
bb35:
  br label %bb46
bb36:
  br label %bb37
bb37:
  %t135 = load i64, ptr %l6, !tbaa !24
  %t136 = load i64, ptr %l10, !tbaa !24
  %t137 = load i64, ptr %l8, !tbaa !24
  %t140 = mul i64 %t136, %t137
  %t143 = add i64 %t135, %t140
  store i64 %t143, ptr %l11, !tbaa !24
  %t145 = load i64, ptr %l5, !tbaa !24
  %t146 = load i64, ptr %l11, !tbaa !24
  store i64 %t146, ptr %l85, !tbaa !24
  %t147 = load i64, ptr %l85, !tbaa !24
  %t148 = load i64, ptr %l85, !tbaa !24
  %t149 = shl i64 1, %t148
  %t152 = and i64 %t145, %t149
  %t154 = icmp ne i64 %t152, 0
  br i1 %t154, label %bb38, label %bb39
bb38:
  %t156 = load ptr, ptr %l3, !tbaa !29
  %t158 = getelementptr %"compiler/typed:Call", ptr %t156, i32 0, i32 1
  %t159 = load { i64, ptr }, ptr %t158, !tbaa !27
  store { i64, ptr } %t159, ptr %l91, !tbaa !27
  %t160 = load i64, ptr %l11, !tbaa !24
  %t162 = getelementptr { i64, ptr }, ptr %l91, i32 0, i32 1
  %t163 = load ptr, ptr %t162, !tbaa !27
  %t164 = getelementptr ptr, ptr %t163, i64 %t160
  %t165 = load ptr, ptr %t164, !tbaa !39
  %t167 = call i1 @compiler_2ftyped_2ePlaceRooted(ptr %v1, ptr %t165)
  store i1 %t167, ptr %l94
  br label %bb40
bb39:
  store i1 false, ptr %l89, !tbaa !21
  br label %bb41
bb40:
  %t168 = load i1, ptr %l94, !tbaa !21
  %t169 = xor i1 %t168, true
  store i1 %t169, ptr %l89, !tbaa !21
  br label %bb41
bb41:
  %t171 = load i1, ptr %l89, !tbaa !21
  br i1 %t171, label %bb42, label %bb43
bb42:
  br label %ret
bb43:
  br label %bb44
bb44:
  br label %bb45
bb45:
  %t172 = load i64, ptr %l10, !tbaa !24
  %t175 = add i64 %t172, 1
  store i64 %t175, ptr %l10, !tbaa !24
  br label %bb34
bb46:
  %t177 = load ptr, ptr %l0, !tbaa !29
  %t179 = getelementptr %"compiler/effects:Effects", ptr %t177, i32 0, i32 74
  %t180 = load ptr, ptr %l3, !tbaa !29
  %t182 = getelementptr %"compiler/typed:Call", ptr %t180, i32 0, i32 2
  %t183 = load i32, ptr %t182, !tbaa !23
  %t185 = sext i32 %t183 to i64
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t179, i64 %t185, i1 true)
  br label %bb47
bb47:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eresPart(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, i64 %a1, ptr %a2, ptr %a3, ptr %a4, i64 %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca i64
  %l9 = alloca i1
  %l10 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l11 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca %"compiler/effects:given"
  %l14 = alloca ptr
  %l15 = alloca i64
  %l21 = alloca i1
  %l26 = alloca i1
  %l31 = alloca ptr
  %l33 = alloca %"compiler/effects:part"
  %l35 = alloca %"compiler/effects:part"
  %l40 = alloca i1
  %l45 = alloca i1
  %l49 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l51 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l53 = alloca i64
  %l55 = alloca i64
  %l60 = alloca i64
  %l61 = alloca ptr
  %l66 = alloca %"compiler/effects:part"
  %l74 = alloca i1
  %l78 = alloca i1
  %l81 = alloca ptr
  %l85 = alloca %"compiler/effects:part"
  %l86 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l90 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l91 = alloca i32
  %l93 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l94 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l96 = alloca i64
  %l98 = alloca i64
  %l103 = alloca %"compiler/effects:given"
  %l108 = alloca i1
  %l125 = alloca ptr
  %l129 = alloca %"compiler/effects:part"
  %l133 = alloca i1
  %l137 = alloca i1
  %l139 = alloca ptr
  %l142 = alloca %"compiler/effects:part"
  %l148 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l150 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l152 = alloca i64
  %l154 = alloca i64
  %l159 = alloca i64
  %l160 = alloca ptr
  %l164 = alloca %"compiler/effects:part"
  %l168 = alloca ptr
  %l172 = alloca %"compiler/effects:part"
  %l178 = alloca ptr
  %l182 = alloca %"compiler/effects:part"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s14 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  store ptr %a4, ptr %l4
  store i64 %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l3, !tbaa !29
  %t3 = getelementptr %"compiler/effects:part", ptr %t1, i32 0, i32 0
  %t4 = load i64, ptr %t3, !tbaa !24
  %t5 = load i64, ptr @G_2ecompiler_2feffects_2eGivNamed, !tbaa !24
  %t8 = icmp eq i64 %t4, %t5
  br i1 %t8, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l21, !tbaa !21
  br label %bb3
bb2:
  %t10 = load ptr, ptr %l3, !tbaa !29
  %t12 = getelementptr %"compiler/effects:part", ptr %t10, i32 0, i32 0
  %t13 = load i64, ptr %t12, !tbaa !24
  %t14 = load i64, ptr @G_2ecompiler_2feffects_2eGivMade, !tbaa !24
  %t17 = icmp eq i64 %t13, %t14
  store i1 %t17, ptr %l21, !tbaa !21
  br label %bb3
bb3:
  %t19 = load i1, ptr %l21, !tbaa !21
  br i1 %t19, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l26, !tbaa !21
  br label %bb6
bb5:
  %t20 = load ptr, ptr %l3, !tbaa !29
  %t22 = getelementptr %"compiler/effects:part", ptr %t20, i32 0, i32 0
  %t23 = load i64, ptr %t22, !tbaa !24
  %t24 = load i64, ptr @G_2ecompiler_2feffects_2eGivBound, !tbaa !24
  %t27 = icmp eq i64 %t23, %t24
  store i1 %t27, ptr %l26, !tbaa !21
  br label %bb6
bb6:
  %t29 = load i1, ptr %l26, !tbaa !21
  br i1 %t29, label %bb7, label %bb8
bb7:
  store %olang.scope zeroinitializer, ptr %s1
  %t30 = load ptr, ptr %l4, !tbaa !29
  store ptr %t30, ptr %l31, !tbaa !29
  %t31 = load ptr, ptr %l3, !tbaa !29
  %t33 = load %"compiler/effects:part", ptr %t31
  store %"compiler/effects:part" %t33, ptr %l33
  %t35 = call %"compiler/effects:part" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2feffects_3apart(ptr %s1, ptr %l33)
  store %"compiler/effects:part" %t35, ptr %l35
  br label %bb9
bb8:
  br label %bb11
bb9:
  %t36 = load ptr, ptr %l31, !tbaa !29
  %t37 = load %"compiler/effects:part", ptr %l35
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3apart_3e_2ePush_3ccompiler_2feffects_3apart_3e(ptr %v3, ptr %v3, ptr %t36, %"compiler/effects:part" %t37)
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb11:
  %t38 = load ptr, ptr %l3, !tbaa !29
  %t40 = getelementptr %"compiler/effects:part", ptr %t38, i32 0, i32 0
  %t41 = load i64, ptr %t40, !tbaa !24
  %t42 = load i64, ptr @G_2ecompiler_2feffects_2eGivResult, !tbaa !24
  %t45 = icmp eq i64 %t41, %t42
  br i1 %t45, label %bb12, label %bb13
bb12:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/effects:Effects", ptr %t47, i32 0, i32 10
  %t50 = load ptr, ptr %l3, !tbaa !29
  %t52 = getelementptr %"compiler/effects:part", ptr %t50, i32 0, i32 1
  %t53 = load i64, ptr %t52, !tbaa !24
  %t56 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cI_Hbd09c84b003bb96b764c8a61b7f32193(ptr %v0, ptr %t49, i64 %t53)
  store i1 %t56, ptr %l45
  br label %bb14
bb13:
  store i1 false, ptr %l40, !tbaa !21
  br label %bb15
bb14:
  %t57 = load i1, ptr %l45, !tbaa !21
  store i1 %t57, ptr %l40, !tbaa !21
  br label %bb15
bb15:
  %t58 = load i1, ptr %l40, !tbaa !21
  br i1 %t58, label %bb16, label %bb17
bb16:
  store %olang.scope zeroinitializer, ptr %s3
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t60 = load ptr, ptr %l3, !tbaa !29
  %t62 = getelementptr %"compiler/effects:part", ptr %t60, i32 0, i32 1
  %t63 = load i64, ptr %t62, !tbaa !24
  %t66 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eretsOf(ptr %v0, ptr %s3, ptr %t59, i64 %t63)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t66, ptr %l49
  br label %bb18
bb17:
  br label %bb30
bb18:
  %t68 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %s3, ptr %l49)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t68, ptr %l51
  br label %bb19
bb19:
  %t69 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l51
  %t70 = call ptr @__olang_scope_alloc_a(ptr %s3, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t69, ptr %t70
  store ptr %t70, ptr %l6, !tbaa !29
  store i64 0, ptr %l7, !tbaa !24
  br label %bb20
bb20:
  %t72 = load i64, ptr %l7, !tbaa !24
  store i64 %t72, ptr %l53, !tbaa !24
  %t73 = load ptr, ptr %l6, !tbaa !29
  %t75 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s3, ptr %t73)
  store i64 %t75, ptr %l55
  br label %bb21
bb21:
  %t76 = load i64, ptr %l53, !tbaa !24
  %t77 = load i64, ptr %l55, !tbaa !24
  %t78 = icmp slt i64 %t76, %t77
  %t80 = xor i1 %t78, true
  br i1 %t80, label %bb22, label %bb23
bb22:
  br label %bb29
bb23:
  br label %bb24
bb24:
  %t82 = load ptr, ptr %l6, !tbaa !29
  %t83 = load i64, ptr %l7, !tbaa !24
  %t86 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s3, ptr %t82, i64 %t83)
  store i64 %t86, ptr %l60
  br label %bb25
bb25:
  %t87 = load i64, ptr %l60, !tbaa !24
  %t88 = load ptr, ptr %l4, !tbaa !29
  store ptr %t88, ptr %l61, !tbaa !29
  %t89 = load i64, ptr @G_2ecompiler_2feffects_2eGivNamed, !tbaa !24
  %t91 = load ptr, ptr %l3, !tbaa !29
  %t93 = getelementptr %"compiler/effects:part", ptr %t91, i32 0, i32 2
  %t94 = load i32, ptr %t93, !tbaa !23
  %t98 = call %"compiler/effects:part" @compiler_2feffects_3apart_2ector(ptr %v3, ptr %v3, i64 %t89, i64 %t87, i32 %t94, ptr null)
  store %"compiler/effects:part" %t98, ptr %l66
  br label %bb26
bb26:
  %t99 = load ptr, ptr %l61, !tbaa !29
  %t100 = load %"compiler/effects:part", ptr %l66
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3apart_3e_2ePush_3ccompiler_2feffects_3apart_3e(ptr %v3, ptr %v3, ptr %t99, %"compiler/effects:part" %t100)
  br label %bb27
bb27:
  br label %bb28
bb28:
  %t101 = load i64, ptr %l7, !tbaa !24
  %t104 = add i64 %t101, 1
  store i64 %t104, ptr %l7, !tbaa !24
  br label %bb20
bb29:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb30:
  %t106 = load ptr, ptr %l3, !tbaa !29
  %t108 = getelementptr %"compiler/effects:part", ptr %t106, i32 0, i32 0
  %t109 = load i64, ptr %t108, !tbaa !24
  %t110 = load i64, ptr @G_2ecompiler_2feffects_2eGivSlot, !tbaa !24
  %t113 = icmp ne i64 %t109, %t110
  br i1 %t113, label %bb31, label %bb32
bb31:
  store i1 true, ptr %l74, !tbaa !21
  br label %bb33
bb32:
  %t115 = load ptr, ptr %l2, !tbaa !29
  %t117 = getelementptr %"compiler/effects:given", ptr %t115, i32 0, i32 6
  %t118 = load i64, ptr %t117, !tbaa !24
  %t120 = icmp slt i64 %t118, 0
  store i1 %t120, ptr %l74, !tbaa !21
  br label %bb33
bb33:
  %t122 = load i1, ptr %l74, !tbaa !21
  br i1 %t122, label %bb34, label %bb35
bb34:
  store i1 true, ptr %l78, !tbaa !21
  br label %bb36
bb35:
  %t123 = load i64, ptr %l5, !tbaa !24
  %t125 = icmp sgt i64 %t123, 4
  store i1 %t125, ptr %l78, !tbaa !21
  br label %bb36
bb36:
  %t127 = load i1, ptr %l78, !tbaa !21
  br i1 %t127, label %bb37, label %bb38
bb37:
  %t128 = load ptr, ptr %l4, !tbaa !29
  store ptr %t128, ptr %l81, !tbaa !29
  %t129 = load i64, ptr @G_2ecompiler_2feffects_2eGivBound, !tbaa !24
  %t130 = load ptr, ptr %l3, !tbaa !29
  %t132 = getelementptr %"compiler/effects:part", ptr %t130, i32 0, i32 2
  %t133 = load i32, ptr %t132, !tbaa !23
  %t136 = call %"compiler/effects:part" @compiler_2feffects_3apart_2ector(ptr %v3, ptr %v3, i64 %t129, i64 0, i32 %t133, ptr null)
  store %"compiler/effects:part" %t136, ptr %l85
  br label %bb39
bb38:
  br label %bb41
bb39:
  %t137 = load ptr, ptr %l81, !tbaa !29
  %t138 = load %"compiler/effects:part", ptr %l85
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3apart_3e_2ePush_3ccompiler_2feffects_3apart_3e(ptr %v3, ptr %v3, ptr %t137, %"compiler/effects:part" %t138)
  br label %bb40
bb40:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb41:
  store i1 false, ptr %l9, !tbaa !21
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t141 = getelementptr %"compiler/effects:Effects", ptr %t139, i32 0, i32 9
  %t142 = load i64, ptr %l1, !tbaa !24
  %t145 = call { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cc_H7b34d2d8e55697dbed551519dd59c955(ptr %v0, ptr %v0, ptr %t141, i64 %t142)
  %t146 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t145, 1
  %t147 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t145, 0
  store i32 %t147, ptr %l91
  %t148 = icmp ne i32 %t147, 0
  br i1 %t148, label %bb43, label %ok.149, !prof !99
ok.149:
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t146, ptr %l90
  br label %bb42
bb42:
  %t151 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3agiven_3e(ptr %s0, ptr %l90)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t151, ptr %l93
  br label %bb45
bb43:
  br label %bb44
bb44:
  %t152 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3agiven_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t152, ptr %l94
  br label %bb46
bb45:
  %t153 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l93
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t153, ptr %l86
  br label %bb47
bb46:
  %t154 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l94
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t154, ptr %l86
  br label %bb47
bb47:
  %t155 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l86
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t155, ptr %l10
  store ptr %l10, ptr %l11, !tbaa !29
  store i64 0, ptr %l12, !tbaa !24
  br label %bb48
bb48:
  store %olang.scope zeroinitializer, ptr %s8
  %t157 = load i64, ptr %l12, !tbaa !24
  store i64 %t157, ptr %l96, !tbaa !24
  %t158 = load ptr, ptr %l11, !tbaa !29
  %t160 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3agiven_3e_2eLen_3ccompiler_2feffects_3agiven_3e(ptr %s0, ptr %t158)
  store i64 %t160, ptr %l98
  br label %bb49
bb49:
  %t161 = load i64, ptr %l96, !tbaa !24
  %t162 = load i64, ptr %l98, !tbaa !24
  %t163 = icmp slt i64 %t161, %t162
  %t165 = xor i1 %t163, true
  br i1 %t165, label %bb50, label %bb51
bb50:
  call void @__olang_scope_close(ptr %s8)
  br label %bb96
bb51:
  br label %bb52
bb52:
  %t167 = load ptr, ptr %l11, !tbaa !29
  %t168 = load i64, ptr %l12, !tbaa !24
  %t171 = call %"compiler/effects:given" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3agiven_3e_2eAt_3ccompiler_2feffects_3agiven_3e(ptr %s0, ptr %s0, ptr %t167, i64 %t168)
  store %"compiler/effects:given" %t171, ptr %l103
  br label %bb53
bb53:
  %t172 = load %"compiler/effects:given", ptr %l103
  store %"compiler/effects:given" %t172, ptr %l13
  %t173 = getelementptr %"compiler/effects:given", ptr %l13, i32 0, i32 0
  %t174 = load i64, ptr %t173, !tbaa !24
  %t175 = load ptr, ptr %l2, !tbaa !29
  %t177 = getelementptr %"compiler/effects:given", ptr %t175, i32 0, i32 6
  %t178 = load i64, ptr %t177, !tbaa !24
  %t181 = icmp ne i64 %t174, %t178
  br i1 %t181, label %bb54, label %bb55
bb54:
  store i1 true, ptr %l108, !tbaa !21
  br label %bb56
bb55:
  %t183 = getelementptr %"compiler/effects:given", ptr %l13, i32 0, i32 1
  %t184 = load i64, ptr %t183, !tbaa !24
  %t185 = load ptr, ptr %l3, !tbaa !29
  %t187 = getelementptr %"compiler/effects:part", ptr %t185, i32 0, i32 1
  %t188 = load i64, ptr %t187, !tbaa !24
  %t191 = icmp ne i64 %t184, %t188
  store i1 %t191, ptr %l108, !tbaa !21
  br label %bb56
bb56:
  %t193 = load i1, ptr %l108, !tbaa !21
  br i1 %t193, label %bb57, label %bb58
bb57:
  call void @__olang_scope_close(ptr %s8)
  br label %bb95
bb58:
  br label %bb59
bb59:
  store i1 true, ptr %l9, !tbaa !21
  %t194 = getelementptr %"compiler/effects:given", ptr %l13, i32 0, i32 2
  %t195 = load i64, ptr %t194, !tbaa !24
  %t196 = load i64, ptr @G_2ecompiler_2feffects_2eGivResField, !tbaa !24
  %t199 = icmp eq i64 %t195, %t196
  br i1 %t199, label %bb60, label %bb61
bb60:
  %t201 = load ptr, ptr %l0, !tbaa !29
  %t202 = load i64, ptr %l1, !tbaa !24
  %t203 = load ptr, ptr %l4, !tbaa !29
  %t204 = load i64, ptr %l5, !tbaa !24
  %t206 = add i64 %t204, 1
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eresField(ptr %v0, ptr %s8, ptr %v3, ptr %t201, i64 %t202, ptr %l13, ptr %t203, i64 %t206)
  br label %bb62
bb61:
  br label %bb63
bb62:
  call void @__olang_scope_close(ptr %s8)
  br label %bb95
bb63:
  %t212 = getelementptr %"compiler/effects:given", ptr %l13, i32 0, i32 2
  %t213 = load i64, ptr %t212, !tbaa !24
  %t214 = load i64, ptr @G_2ecompiler_2feffects_2eGivSlot, !tbaa !24
  %t217 = icmp eq i64 %t213, %t214
  br i1 %t217, label %bb64, label %bb65
bb64:
  %t219 = load ptr, ptr %l4, !tbaa !29
  store ptr %t219, ptr %l125, !tbaa !29
  %t220 = load i64, ptr @G_2ecompiler_2feffects_2eGivSlot, !tbaa !24
  %t221 = getelementptr %"compiler/effects:given", ptr %l13, i32 0, i32 3
  %t222 = load i64, ptr %t221, !tbaa !24
  %t223 = getelementptr %"compiler/effects:given", ptr %l13, i32 0, i32 4
  %t224 = load i32, ptr %t223, !tbaa !23
  %t228 = call %"compiler/effects:part" @compiler_2feffects_3apart_2ector(ptr %v3, ptr %v3, i64 %t220, i64 %t222, i32 %t224, ptr null)
  store %"compiler/effects:part" %t228, ptr %l129
  br label %bb66
bb65:
  br label %bb68
bb66:
  %t229 = load ptr, ptr %l125, !tbaa !29
  %t230 = load %"compiler/effects:part", ptr %l129
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3apart_3e_2ePush_3ccompiler_2feffects_3apart_3e(ptr %v3, ptr %v3, ptr %t229, %"compiler/effects:part" %t230)
  br label %bb67
bb67:
  call void @__olang_scope_close(ptr %s8)
  br label %bb95
bb68:
  %t231 = getelementptr %"compiler/effects:given", ptr %l13, i32 0, i32 2
  %t232 = load i64, ptr %t231, !tbaa !24
  %t233 = load i64, ptr @G_2ecompiler_2feffects_2eGivResult, !tbaa !24
  %t236 = icmp eq i64 %t232, %t233
  br i1 %t236, label %bb69, label %bb70
bb69:
  %t238 = load ptr, ptr %l0, !tbaa !29
  %t240 = getelementptr %"compiler/effects:Effects", ptr %t238, i32 0, i32 10
  %t241 = getelementptr %"compiler/effects:given", ptr %l13, i32 0, i32 3
  %t242 = load i64, ptr %t241, !tbaa !24
  %t245 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cI_Hbd09c84b003bb96b764c8a61b7f32193(ptr %v0, ptr %t240, i64 %t242)
  store i1 %t245, ptr %l137
  br label %bb71
bb70:
  store i1 false, ptr %l133, !tbaa !21
  br label %bb72
bb71:
  %t246 = load i1, ptr %l137, !tbaa !21
  %t247 = xor i1 %t246, true
  store i1 %t247, ptr %l133, !tbaa !21
  br label %bb72
bb72:
  %t249 = load i1, ptr %l133, !tbaa !21
  br i1 %t249, label %bb73, label %bb74
bb73:
  %t250 = load ptr, ptr %l4, !tbaa !29
  store ptr %t250, ptr %l139, !tbaa !29
  %t251 = load i64, ptr @G_2ecompiler_2feffects_2eGivBound, !tbaa !24
  %t252 = getelementptr %"compiler/effects:given", ptr %l13, i32 0, i32 4
  %t253 = load i32, ptr %t252, !tbaa !23
  %t256 = call %"compiler/effects:part" @compiler_2feffects_3apart_2ector(ptr %v3, ptr %v3, i64 %t251, i64 0, i32 %t253, ptr null)
  store %"compiler/effects:part" %t256, ptr %l142
  br label %bb75
bb74:
  br label %bb77
bb75:
  %t257 = load ptr, ptr %l139, !tbaa !29
  %t258 = load %"compiler/effects:part", ptr %l142
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3apart_3e_2ePush_3ccompiler_2feffects_3apart_3e(ptr %v3, ptr %v3, ptr %t257, %"compiler/effects:part" %t258)
  br label %bb76
bb76:
  call void @__olang_scope_close(ptr %s8)
  br label %bb95
bb77:
  %t259 = getelementptr %"compiler/effects:given", ptr %l13, i32 0, i32 2
  %t260 = load i64, ptr %t259, !tbaa !24
  %t261 = load i64, ptr @G_2ecompiler_2feffects_2eGivResult, !tbaa !24
  %t264 = icmp eq i64 %t260, %t261
  br i1 %t264, label %bb78, label %bb79
bb78:
  store %olang.scope zeroinitializer, ptr %s14
  %t266 = load ptr, ptr %l0, !tbaa !29
  %t267 = getelementptr %"compiler/effects:given", ptr %l13, i32 0, i32 3
  %t268 = load i64, ptr %t267, !tbaa !24
  %t271 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eretsOf(ptr %v0, ptr %s14, ptr %t266, i64 %t268)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t271, ptr %l148
  br label %bb80
bb79:
  br label %bb92
bb80:
  %t273 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %s14, ptr %l148)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t273, ptr %l150
  br label %bb81
bb81:
  %t274 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l150
  %t275 = call ptr @__olang_scope_alloc_a(ptr %s14, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t274, ptr %t275
  store ptr %t275, ptr %l14, !tbaa !29
  store i64 0, ptr %l15, !tbaa !24
  br label %bb82
bb82:
  %t277 = load i64, ptr %l15, !tbaa !24
  store i64 %t277, ptr %l152, !tbaa !24
  %t278 = load ptr, ptr %l14, !tbaa !29
  %t280 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s14, ptr %t278)
  store i64 %t280, ptr %l154
  br label %bb83
bb83:
  %t281 = load i64, ptr %l152, !tbaa !24
  %t282 = load i64, ptr %l154, !tbaa !24
  %t283 = icmp slt i64 %t281, %t282
  %t285 = xor i1 %t283, true
  br i1 %t285, label %bb84, label %bb85
bb84:
  br label %bb91
bb85:
  br label %bb86
bb86:
  %t287 = load ptr, ptr %l14, !tbaa !29
  %t288 = load i64, ptr %l15, !tbaa !24
  %t291 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s14, ptr %t287, i64 %t288)
  store i64 %t291, ptr %l159
  br label %bb87
bb87:
  %t292 = load i64, ptr %l159, !tbaa !24
  %t293 = load ptr, ptr %l4, !tbaa !29
  store ptr %t293, ptr %l160, !tbaa !29
  %t294 = load i64, ptr @G_2ecompiler_2feffects_2eGivNamed, !tbaa !24
  %t296 = getelementptr %"compiler/effects:given", ptr %l13, i32 0, i32 4
  %t297 = load i32, ptr %t296, !tbaa !23
  %t301 = call %"compiler/effects:part" @compiler_2feffects_3apart_2ector(ptr %v3, ptr %v3, i64 %t294, i64 %t292, i32 %t297, ptr null)
  store %"compiler/effects:part" %t301, ptr %l164
  br label %bb88
bb88:
  %t302 = load ptr, ptr %l160, !tbaa !29
  %t303 = load %"compiler/effects:part", ptr %l164
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3apart_3e_2ePush_3ccompiler_2feffects_3apart_3e(ptr %v3, ptr %v3, ptr %t302, %"compiler/effects:part" %t303)
  br label %bb89
bb89:
  br label %bb90
bb90:
  %t304 = load i64, ptr %l15, !tbaa !24
  %t307 = add i64 %t304, 1
  store i64 %t307, ptr %l15, !tbaa !24
  br label %bb82
bb91:
  call void @__olang_scope_close(ptr %s14)
  call void @__olang_scope_close(ptr %s8)
  br label %bb95
bb92:
  %t309 = load ptr, ptr %l4, !tbaa !29
  store ptr %t309, ptr %l168, !tbaa !29
  %t310 = getelementptr %"compiler/effects:given", ptr %l13, i32 0, i32 2
  %t311 = load i64, ptr %t310, !tbaa !24
  %t312 = getelementptr %"compiler/effects:given", ptr %l13, i32 0, i32 3
  %t313 = load i64, ptr %t312, !tbaa !24
  %t314 = getelementptr %"compiler/effects:given", ptr %l13, i32 0, i32 4
  %t315 = load i32, ptr %t314, !tbaa !23
  %t319 = call %"compiler/effects:part" @compiler_2feffects_3apart_2ector(ptr %v3, ptr %v3, i64 %t311, i64 %t313, i32 %t315, ptr null)
  store %"compiler/effects:part" %t319, ptr %l172
  br label %bb93
bb93:
  %t320 = load ptr, ptr %l168, !tbaa !29
  %t321 = load %"compiler/effects:part", ptr %l172
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3apart_3e_2ePush_3ccompiler_2feffects_3apart_3e(ptr %v3, ptr %v3, ptr %t320, %"compiler/effects:part" %t321)
  br label %bb94
bb94:
  call void @__olang_scope_close(ptr %s8)
  br label %bb95
bb95:
  %t322 = load i64, ptr %l12, !tbaa !24
  %t325 = add i64 %t322, 1
  store i64 %t325, ptr %l12, !tbaa !24
  br label %bb48
bb96:
  %t327 = load i1, ptr %l9, !tbaa !21
  %t329 = xor i1 %t327, true
  br i1 %t329, label %bb97, label %bb98
bb97:
  %t331 = load ptr, ptr %l4, !tbaa !29
  store ptr %t331, ptr %l178, !tbaa !29
  %t332 = load i64, ptr @G_2ecompiler_2feffects_2eGivBound, !tbaa !24
  %t333 = load ptr, ptr %l3, !tbaa !29
  %t335 = getelementptr %"compiler/effects:part", ptr %t333, i32 0, i32 2
  %t336 = load i32, ptr %t335, !tbaa !23
  %t339 = call %"compiler/effects:part" @compiler_2feffects_3apart_2ector(ptr %v3, ptr %v3, i64 %t332, i64 0, i32 %t336, ptr null)
  store %"compiler/effects:part" %t339, ptr %l182
  br label %bb99
bb98:
  br label %bb101
bb99:
  %t340 = load ptr, ptr %l178, !tbaa !29
  %t341 = load %"compiler/effects:part", ptr %l182
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3apart_3e_2ePush_3ccompiler_2feffects_3apart_3e(ptr %v3, ptr %v3, ptr %t340, %"compiler/effects:part" %t341)
  br label %bb100
bb100:
  br label %bb101
bb101:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2erootBits(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca i64
  %l15 = alloca ptr
  %l16 = alloca i1
  %l25 = alloca i64
  %l26 = alloca ptr
  %l34 = alloca i64
  %l35 = alloca i64
  %l41 = alloca i64
  %l43 = alloca ptr
  %l44 = alloca i1
  %l57 = alloca { i64, ptr }
  %l64 = alloca i64
  %l65 = alloca ptr
  %l73 = alloca i64
  %l81 = alloca i64
  %l82 = alloca i64
  %l86 = alloca i64
  %l87 = alloca i32
  %l88 = alloca i64
  %l89 = alloca i64
  %l93 = alloca i64
  %l94 = alloca i32
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l2, !tbaa !24
  %t3 = icmp sgt i64 %t1, 16
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i64 0, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l1, !tbaa !29
  store ptr %t6, ptr %l15, !tbaa !29
  store i1 false, ptr %l16, !tbaa !21
  %t7 = load ptr, ptr %l15, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb4, label %bb5
bb4:
  %t10 = load ptr, ptr %l15, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 18}
  %t13 = icmp eq i64 %t11, 11
  store i1 %t13, ptr %l16, !tbaa !21
  br label %bb5
bb5:
  %t14 = load i1, ptr %l16, !tbaa !21
  br i1 %t14, label %bb6, label %bb7
bb6:
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t17 = getelementptr { i64, [5 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t17, i32 0, i32 2
  %t19 = load ptr, ptr %t18
  store ptr %t19, ptr %l3, !tbaa !29
  br label %bb8
bb7:
  br label %bb17
bb8:
  %t21 = load ptr, ptr %l3, !tbaa !29
  %t23 = getelementptr %"compiler/typed:Cond", ptr %t21, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !29
  %t26 = icmp eq ptr %t24, null
  %t28 = xor i1 %t26, true
  br i1 %t28, label %bb9, label %bb10
bb9:
  %t30 = load ptr, ptr %l0, !tbaa !29
  store ptr %t30, ptr %l26, !tbaa !29
  %t31 = load ptr, ptr %l3, !tbaa !29
  %t33 = getelementptr %"compiler/typed:Cond", ptr %t31, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !29
  %t36 = icmp eq ptr %t34, null
  br i1 %t36, label %bb11, label %bb12
bb10:
  store i64 0, ptr %l25, !tbaa !24
  br label %bb15
bb11:
  call void @__olang_check_failed(ptr @olang_loc_e883a08fe0a2dfcb_10d50552a173805f)
  unreachable
bb12:
  br label %bb13
bb13:
  %t38 = load ptr, ptr %l3, !tbaa !29
  %t40 = getelementptr %"compiler/typed:Cond", ptr %t38, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !29
  %t42 = load i64, ptr %l2, !tbaa !24
  %t44 = add i64 %t42, 1
  %t45 = load ptr, ptr %l26, !tbaa !29
  %t48 = call i64 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2erootBits(ptr %v0, ptr %v1, ptr %t45, ptr %t41, i64 %t44)
  store i64 %t48, ptr %l34
  br label %bb14
bb14:
  %t49 = load i64, ptr %l34, !tbaa !24
  store i64 %t49, ptr %l25, !tbaa !24
  br label %bb15
bb15:
  %t50 = load i64, ptr %l25, !tbaa !24
  store i64 %t50, ptr %l35, !tbaa !24
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = load ptr, ptr %l3, !tbaa !29
  %t55 = getelementptr %"compiler/typed:Cond", ptr %t53, i32 0, i32 2
  %t56 = load ptr, ptr %t55, !tbaa !29
  %t57 = load i64, ptr %l2, !tbaa !24
  %t59 = add i64 %t57, 1
  %t63 = call i64 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2erootBits(ptr %v0, ptr %v1, ptr %t52, ptr %t56, i64 %t59)
  store i64 %t63, ptr %l41
  br label %bb16
bb16:
  %t64 = load i64, ptr %l35, !tbaa !24
  %t65 = load i64, ptr %l41, !tbaa !24
  %t66 = or i64 %t64, %t65
  store i64 %t66, ptr %rv
  br label %ret
bb17:
  %t68 = load ptr, ptr %l1, !tbaa !29
  store ptr %t68, ptr %l43, !tbaa !29
  store i1 false, ptr %l44, !tbaa !21
  %t69 = load ptr, ptr %l43, !tbaa !29
  %t70 = icmp ne ptr %t69, null
  br i1 %t70, label %bb18, label %bb19
bb18:
  %t72 = load ptr, ptr %l43, !tbaa !29
  %t73 = load i64, ptr %t72, !range !{i64 0, i64 18}
  %t75 = icmp eq i64 %t73, 13
  store i1 %t75, ptr %l44, !tbaa !21
  br label %bb19
bb19:
  %t76 = load i1, ptr %l44, !tbaa !21
  br i1 %t76, label %bb20, label %bb21
bb20:
  %t77 = load ptr, ptr %l1, !tbaa !29
  %t79 = getelementptr { i64, [5 x i64] }, ptr %t77, i32 0, i32 1
  %t80 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t79, i32 0, i32 2
  %t81 = load ptr, ptr %t80
  store ptr %t81, ptr %l5, !tbaa !29
  br label %bb22
bb21:
  br label %bb36
bb22:
  store i64 0, ptr %l6, !tbaa !24
  %t83 = load ptr, ptr %l5, !tbaa !29
  %t85 = getelementptr %"compiler/typed:Match", ptr %t83, i32 0, i32 1
  %t86 = load { i64, ptr }, ptr %t85, !tbaa !27
  store { i64, ptr } %t86, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t88 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t90 = extractvalue { i64, ptr } %t88, 0
  store i64 %t90, ptr %l9, !tbaa !24
  br label %bb23
bb23:
  %t92 = load i64, ptr %l8, !tbaa !24
  %t93 = load i64, ptr %l9, !tbaa !24
  %t96 = icmp slt i64 %t92, %t93
  %t98 = xor i1 %t96, true
  br i1 %t98, label %bb24, label %bb25
bb24:
  br label %bb35
bb25:
  br label %bb26
bb26:
  %t100 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t100, ptr %l57, !tbaa !27
  %t101 = load i64, ptr %l8, !tbaa !24
  %t103 = getelementptr { i64, ptr }, ptr %l57, i32 0, i32 1
  %t104 = load ptr, ptr %t103, !tbaa !27
  %t105 = getelementptr ptr, ptr %t104, i64 %t101
  %t106 = load ptr, ptr %t105, !tbaa !39
  store ptr %t106, ptr %l10, !tbaa !29
  %t108 = load ptr, ptr %l10, !tbaa !29
  %t110 = getelementptr %"compiler/typed:Arm", ptr %t108, i32 0, i32 4
  %t111 = load ptr, ptr %t110, !tbaa !29
  %t113 = icmp eq ptr %t111, null
  %t115 = xor i1 %t113, true
  br i1 %t115, label %bb27, label %bb28
bb27:
  %t117 = load i64, ptr %l6, !tbaa !24
  store i64 %t117, ptr %l64, !tbaa !24
  %t118 = load ptr, ptr %l0, !tbaa !29
  store ptr %t118, ptr %l65, !tbaa !29
  %t119 = load ptr, ptr %l10, !tbaa !29
  %t121 = getelementptr %"compiler/typed:Arm", ptr %t119, i32 0, i32 4
  %t122 = load ptr, ptr %t121, !tbaa !29
  %t124 = icmp eq ptr %t122, null
  br i1 %t124, label %bb29, label %bb30
bb28:
  br label %bb33
bb29:
  call void @__olang_check_failed(ptr @olang_loc_be89c63eecba24dc_20b8a06f464464c0)
  unreachable
bb30:
  br label %bb31
bb31:
  %t126 = load ptr, ptr %l10, !tbaa !29
  %t128 = getelementptr %"compiler/typed:Arm", ptr %t126, i32 0, i32 4
  %t129 = load ptr, ptr %t128, !tbaa !29
  %t130 = load i64, ptr %l2, !tbaa !24
  %t132 = add i64 %t130, 1
  %t133 = load ptr, ptr %l65, !tbaa !29
  %t136 = call i64 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2erootBits(ptr %v0, ptr %v1, ptr %t133, ptr %t129, i64 %t132)
  store i64 %t136, ptr %l73
  br label %bb32
bb32:
  %t137 = load i64, ptr %l64, !tbaa !24
  %t138 = load i64, ptr %l73, !tbaa !24
  %t139 = or i64 %t137, %t138
  store i64 %t139, ptr %l6, !tbaa !24
  br label %bb33
bb33:
  br label %bb34
bb34:
  %t141 = load i64, ptr %l8, !tbaa !24
  %t144 = add i64 %t141, 1
  store i64 %t144, ptr %l8, !tbaa !24
  br label %bb23
bb35:
  %t146 = load i64, ptr %l6, !tbaa !24
  store i64 %t146, ptr %rv
  br label %ret
bb36:
  br i1 true, label %bb37, label %bb38
bb37:
  br label %bb39
bb38:
  br label %bb40
bb39:
  br label %bb41
bb40:
  call void @__olang_check_failed(ptr @olang_loc_da29f57e967b0d58_398b0b5997e9910c)
  unreachable
bb41:
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t149 = load ptr, ptr %l1, !tbaa !29
  %t152 = call i64 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eexprRoot(ptr %v0, ptr %v1, ptr %t148, ptr %t149)
  store i64 %t152, ptr %l81
  br label %bb42
bb42:
  %t153 = load i64, ptr %l81, !tbaa !24
  store i64 %t153, ptr %l11, !tbaa !24
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t156 = getelementptr %"compiler/effects:Effects", ptr %t154, i32 0, i32 31
  %t157 = load i64, ptr %l11, !tbaa !24
  %t160 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t156, i64 %t157)
  %t161 = extractvalue { i32, i64 } %t160, 1
  %t162 = extractvalue { i32, i64 } %t160, 0
  store i32 %t162, ptr %l87
  %t163 = icmp ne i32 %t162, 0
  br i1 %t163, label %bb44, label %ok.164, !prof !99
ok.164:
  store i64 %t161, ptr %l86
  br label %bb43
bb43:
  %t165 = load i64, ptr %l86, !tbaa !24
  store i64 %t165, ptr %l82, !tbaa !24
  br label %bb46
bb44:
  br label %bb45
bb45:
  store i64 -1, ptr %l82, !tbaa !24
  br label %bb46
bb46:
  %t166 = load i64, ptr %l82, !tbaa !24
  %t167 = call i64 @compiler_2feffects_2eparamBit(i64 %t166)
  store i64 %t167, ptr %l88
  br label %bb47
bb47:
  %t168 = load ptr, ptr %l0, !tbaa !29
  %t170 = getelementptr %"compiler/effects:Effects", ptr %t168, i32 0, i32 32
  %t171 = load i64, ptr %l11, !tbaa !24
  %t174 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t170, i64 %t171)
  %t175 = extractvalue { i32, i64 } %t174, 1
  %t176 = extractvalue { i32, i64 } %t174, 0
  store i32 %t176, ptr %l94
  %t177 = icmp ne i32 %t176, 0
  br i1 %t177, label %bb49, label %ok.178, !prof !99
ok.178:
  store i64 %t175, ptr %l93
  br label %bb48
bb48:
  %t179 = load i64, ptr %l93, !tbaa !24
  store i64 %t179, ptr %l89, !tbaa !24
  br label %bb51
bb49:
  br label %bb50
bb50:
  store i64 0, ptr %l89, !tbaa !24
  br label %bb51
bb51:
  %t180 = load i64, ptr %l88, !tbaa !24
  %t181 = load i64, ptr %l89, !tbaa !24
  %t182 = or i64 %t180, %t181
  store i64 %t182, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2escanStmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca i64
  %l18 = alloca ptr
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca ptr
  %l23 = alloca ptr
  %l24 = alloca i1
  %l29 = alloca ptr
  %l30 = alloca i1
  %l35 = alloca ptr
  %l36 = alloca i1
  %l44 = alloca ptr
  %l45 = alloca i1
  %l57 = alloca ptr
  %l58 = alloca i1
  %l74 = alloca ptr
  %l75 = alloca i1
  %l87 = alloca ptr
  %l88 = alloca i1
  %l93 = alloca ptr
  %l94 = alloca i1
  %l101 = alloca ptr
  %l102 = alloca i1
  %l107 = alloca ptr
  %l108 = alloca i1
  %l116 = alloca ptr
  %l117 = alloca i1
  %l129 = alloca ptr
  %l130 = alloca i1
  %l135 = alloca ptr
  %l136 = alloca i1
  %l143 = alloca ptr
  %l144 = alloca i1
  %l161 = alloca { i64, ptr }
  %l170 = alloca ptr
  %l171 = alloca i1
  %l184 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l23, !tbaa !29
  store i1 false, ptr %l24, !tbaa !21
  %t2 = load ptr, ptr %l23, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l23, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 17}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l24, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l24, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [3 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb13
bb4:
  %t16 = load ptr, ptr %l1, !tbaa !29
  store ptr %t16, ptr %l29, !tbaa !29
  store i1 false, ptr %l30, !tbaa !21
  %t17 = load ptr, ptr %l29, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb5, label %bb6
bb5:
  %t20 = load ptr, ptr %l29, !tbaa !29
  %t21 = load i64, ptr %t20, !range !{i64 0, i64 17}
  %t23 = icmp eq i64 %t21, 2
  store i1 %t23, ptr %l30, !tbaa !21
  br label %bb6
bb6:
  %t24 = load i1, ptr %l30, !tbaa !21
  br i1 %t24, label %bb7, label %bb8
bb7:
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr { i64, [3 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", ptr }, ptr %t27, i32 0, i32 1
  %t29 = load ptr, ptr %t28
  store ptr %t29, ptr %l2, !tbaa !29
  br label %bb13
bb8:
  %t31 = load ptr, ptr %l1, !tbaa !29
  store ptr %t31, ptr %l35, !tbaa !29
  store i1 false, ptr %l36, !tbaa !21
  %t32 = load ptr, ptr %l35, !tbaa !29
  %t33 = icmp ne ptr %t32, null
  br i1 %t33, label %bb9, label %bb10
bb9:
  %t35 = load ptr, ptr %l35, !tbaa !29
  %t36 = load i64, ptr %t35, !range !{i64 0, i64 17}
  %t38 = icmp eq i64 %t36, 15
  store i1 %t38, ptr %l36, !tbaa !21
  br label %bb10
bb10:
  %t39 = load i1, ptr %l36, !tbaa !21
  br i1 %t39, label %bb11, label %bb12
bb11:
  %t40 = load ptr, ptr %l1, !tbaa !29
  %t42 = getelementptr { i64, [3 x i64] }, ptr %t40, i32 0, i32 1
  %t43 = getelementptr { %"compiler/source:Span", ptr }, ptr %t42, i32 0, i32 1
  %t44 = load ptr, ptr %t43
  store ptr %t44, ptr %l2, !tbaa !29
  br label %bb13
bb12:
  br label %bb15
bb13:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2escanExpr(ptr %v0, ptr %v1, ptr %t46, ptr %t47)
  br label %bb14
bb14:
  br label %bb117
bb15:
  %t51 = load ptr, ptr %l1, !tbaa !29
  store ptr %t51, ptr %l44, !tbaa !29
  store i1 false, ptr %l45, !tbaa !21
  %t52 = load ptr, ptr %l44, !tbaa !29
  %t53 = icmp ne ptr %t52, null
  br i1 %t53, label %bb16, label %bb17
bb16:
  %t55 = load ptr, ptr %l44, !tbaa !29
  %t56 = load i64, ptr %t55, !range !{i64 0, i64 17}
  %t58 = icmp eq i64 %t56, 1
  store i1 %t58, ptr %l45, !tbaa !21
  br label %bb17
bb17:
  %t59 = load i1, ptr %l45, !tbaa !21
  br i1 %t59, label %bb18, label %bb19
bb18:
  %t60 = load ptr, ptr %l1, !tbaa !29
  %t62 = getelementptr { i64, [3 x i64] }, ptr %t60, i32 0, i32 1
  %t63 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t62, i32 0, i32 1
  %t64 = load ptr, ptr %t63
  store ptr %t64, ptr %l3, !tbaa !29
  %t66 = load ptr, ptr %l1, !tbaa !29
  %t68 = getelementptr { i64, [3 x i64] }, ptr %t66, i32 0, i32 1
  %t69 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t68, i32 0, i32 2
  %t70 = load ptr, ptr %t69
  store ptr %t70, ptr %l4, !tbaa !29
  br label %bb20
bb19:
  br label %bb23
bb20:
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t73 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2escanTarget(ptr %v0, ptr %v1, ptr %t72, ptr %t73)
  br label %bb21
bb21:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t77 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2escanExpr(ptr %v0, ptr %v1, ptr %t76, ptr %t77)
  br label %bb22
bb22:
  br label %bb117
bb23:
  %t81 = load ptr, ptr %l1, !tbaa !29
  store ptr %t81, ptr %l57, !tbaa !29
  store i1 false, ptr %l58, !tbaa !21
  %t82 = load ptr, ptr %l57, !tbaa !29
  %t83 = icmp ne ptr %t82, null
  br i1 %t83, label %bb24, label %bb25
bb24:
  %t85 = load ptr, ptr %l57, !tbaa !29
  %t86 = load i64, ptr %t85, !range !{i64 0, i64 17}
  %t88 = icmp eq i64 %t86, 3
  store i1 %t88, ptr %l58, !tbaa !21
  br label %bb25
bb25:
  %t89 = load i1, ptr %l58, !tbaa !21
  br i1 %t89, label %bb26, label %bb27
bb26:
  %t90 = load ptr, ptr %l1, !tbaa !29
  %t92 = getelementptr { i64, [3 x i64] }, ptr %t90, i32 0, i32 1
  %t93 = getelementptr { %"compiler/source:Span", ptr }, ptr %t92, i32 0, i32 1
  %t94 = load ptr, ptr %t93
  store ptr %t94, ptr %l5, !tbaa !29
  br label %bb28
bb27:
  br label %bb32
bb28:
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t97 = load ptr, ptr %l5, !tbaa !29
  %t99 = getelementptr %"compiler/typed:If", ptr %t97, i32 0, i32 0
  %t100 = load ptr, ptr %t99, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2escanExpr(ptr %v0, ptr %v1, ptr %t96, ptr %t100)
  br label %bb29
bb29:
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t105 = load ptr, ptr %l5, !tbaa !29
  %t107 = getelementptr %"compiler/typed:If", ptr %t105, i32 0, i32 1
  %t108 = load ptr, ptr %t107, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2escanBlock(ptr %v0, ptr %v1, ptr %t104, ptr %t108)
  br label %bb30
bb30:
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t113 = load ptr, ptr %l5, !tbaa !29
  %t115 = getelementptr %"compiler/typed:If", ptr %t113, i32 0, i32 2
  %t116 = load ptr, ptr %t115, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2escanBlock(ptr %v0, ptr %v1, ptr %t112, ptr %t116)
  br label %bb31
bb31:
  br label %bb117
bb32:
  %t119 = load ptr, ptr %l1, !tbaa !29
  store ptr %t119, ptr %l74, !tbaa !29
  store i1 false, ptr %l75, !tbaa !21
  %t120 = load ptr, ptr %l74, !tbaa !29
  %t121 = icmp ne ptr %t120, null
  br i1 %t121, label %bb33, label %bb34
bb33:
  %t123 = load ptr, ptr %l74, !tbaa !29
  %t124 = load i64, ptr %t123, !range !{i64 0, i64 17}
  %t126 = icmp eq i64 %t124, 4
  store i1 %t126, ptr %l75, !tbaa !21
  br label %bb34
bb34:
  %t127 = load i1, ptr %l75, !tbaa !21
  br i1 %t127, label %bb35, label %bb36
bb35:
  %t128 = load ptr, ptr %l1, !tbaa !29
  %t130 = getelementptr { i64, [3 x i64] }, ptr %t128, i32 0, i32 1
  %t131 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t130, i32 0, i32 1
  %t132 = load ptr, ptr %t131
  store ptr %t132, ptr %l6, !tbaa !29
  %t134 = load ptr, ptr %l1, !tbaa !29
  %t136 = getelementptr { i64, [3 x i64] }, ptr %t134, i32 0, i32 1
  %t137 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t136, i32 0, i32 2
  %t138 = load ptr, ptr %t137
  store ptr %t138, ptr %l7, !tbaa !29
  br label %bb37
bb36:
  br label %bb40
bb37:
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t141 = load ptr, ptr %l6, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2escanBlock(ptr %v0, ptr %v1, ptr %t140, ptr %t141)
  br label %bb38
bb38:
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t146 = load ptr, ptr %l7, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2escanBlock(ptr %v0, ptr %v1, ptr %t145, ptr %t146)
  br label %bb39
bb39:
  br label %bb117
bb40:
  %t149 = load ptr, ptr %l1, !tbaa !29
  store ptr %t149, ptr %l87, !tbaa !29
  store i1 false, ptr %l88, !tbaa !21
  %t150 = load ptr, ptr %l87, !tbaa !29
  %t151 = icmp ne ptr %t150, null
  br i1 %t151, label %bb41, label %bb42
bb41:
  %t153 = load ptr, ptr %l87, !tbaa !29
  %t154 = load i64, ptr %t153, !range !{i64 0, i64 17}
  %t156 = icmp eq i64 %t154, 6
  store i1 %t156, ptr %l88, !tbaa !21
  br label %bb42
bb42:
  %t157 = load i1, ptr %l88, !tbaa !21
  br i1 %t157, label %bb43, label %bb44
bb43:
  %t158 = load ptr, ptr %l1, !tbaa !29
  %t160 = getelementptr { i64, [3 x i64] }, ptr %t158, i32 0, i32 1
  %t161 = getelementptr { %"compiler/source:Span", ptr }, ptr %t160, i32 0, i32 1
  %t162 = load ptr, ptr %t161
  store ptr %t162, ptr %l8, !tbaa !29
  br label %bb49
bb44:
  %t164 = load ptr, ptr %l1, !tbaa !29
  store ptr %t164, ptr %l93, !tbaa !29
  store i1 false, ptr %l94, !tbaa !21
  %t165 = load ptr, ptr %l93, !tbaa !29
  %t166 = icmp ne ptr %t165, null
  br i1 %t166, label %bb45, label %bb46
bb45:
  %t168 = load ptr, ptr %l93, !tbaa !29
  %t169 = load i64, ptr %t168, !range !{i64 0, i64 17}
  %t171 = icmp eq i64 %t169, 16
  store i1 %t171, ptr %l94, !tbaa !21
  br label %bb46
bb46:
  %t172 = load i1, ptr %l94, !tbaa !21
  br i1 %t172, label %bb47, label %bb48
bb47:
  %t173 = load ptr, ptr %l1, !tbaa !29
  %t175 = getelementptr { i64, [3 x i64] }, ptr %t173, i32 0, i32 1
  %t176 = getelementptr { %"compiler/source:Span", ptr }, ptr %t175, i32 0, i32 1
  %t177 = load ptr, ptr %t176
  store ptr %t177, ptr %l8, !tbaa !29
  br label %bb49
bb48:
  br label %bb51
bb49:
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t180 = load ptr, ptr %l8, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2escanExpr(ptr %v0, ptr %v1, ptr %t179, ptr %t180)
  br label %bb50
bb50:
  br label %bb117
bb51:
  %t183 = load ptr, ptr %l1, !tbaa !29
  store ptr %t183, ptr %l101, !tbaa !29
  store i1 false, ptr %l102, !tbaa !21
  %t184 = load ptr, ptr %l101, !tbaa !29
  %t185 = icmp ne ptr %t184, null
  br i1 %t185, label %bb52, label %bb53
bb52:
  %t187 = load ptr, ptr %l101, !tbaa !29
  %t188 = load i64, ptr %t187, !range !{i64 0, i64 17}
  %t190 = icmp eq i64 %t188, 11
  store i1 %t190, ptr %l102, !tbaa !21
  br label %bb53
bb53:
  %t191 = load i1, ptr %l102, !tbaa !21
  br i1 %t191, label %bb54, label %bb55
bb54:
  %t192 = load ptr, ptr %l1, !tbaa !29
  %t194 = getelementptr { i64, [3 x i64] }, ptr %t192, i32 0, i32 1
  %t195 = getelementptr { %"compiler/source:Span", ptr }, ptr %t194, i32 0, i32 1
  %t196 = load ptr, ptr %t195
  store ptr %t196, ptr %l9, !tbaa !29
  br label %bb60
bb55:
  %t198 = load ptr, ptr %l1, !tbaa !29
  store ptr %t198, ptr %l107, !tbaa !29
  store i1 false, ptr %l108, !tbaa !21
  %t199 = load ptr, ptr %l107, !tbaa !29
  %t200 = icmp ne ptr %t199, null
  br i1 %t200, label %bb56, label %bb57
bb56:
  %t202 = load ptr, ptr %l107, !tbaa !29
  %t203 = load i64, ptr %t202, !range !{i64 0, i64 17}
  %t205 = icmp eq i64 %t203, 12
  store i1 %t205, ptr %l108, !tbaa !21
  br label %bb57
bb57:
  %t206 = load i1, ptr %l108, !tbaa !21
  br i1 %t206, label %bb58, label %bb59
bb58:
  %t207 = load ptr, ptr %l1, !tbaa !29
  %t209 = getelementptr { i64, [3 x i64] }, ptr %t207, i32 0, i32 1
  %t210 = getelementptr { %"compiler/source:Span", ptr }, ptr %t209, i32 0, i32 1
  %t211 = load ptr, ptr %t210
  store ptr %t211, ptr %l9, !tbaa !29
  br label %bb60
bb59:
  br label %bb62
bb60:
  %t213 = load ptr, ptr %l0, !tbaa !29
  %t214 = load ptr, ptr %l9, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2escanBlock(ptr %v0, ptr %v1, ptr %t213, ptr %t214)
  br label %bb61
bb61:
  br label %bb117
bb62:
  %t218 = load ptr, ptr %l1, !tbaa !29
  store ptr %t218, ptr %l116, !tbaa !29
  store i1 false, ptr %l117, !tbaa !21
  %t219 = load ptr, ptr %l116, !tbaa !29
  %t220 = icmp ne ptr %t219, null
  br i1 %t220, label %bb63, label %bb64
bb63:
  %t222 = load ptr, ptr %l116, !tbaa !29
  %t223 = load i64, ptr %t222, !range !{i64 0, i64 17}
  %t225 = icmp eq i64 %t223, 10
  store i1 %t225, ptr %l117, !tbaa !21
  br label %bb64
bb64:
  %t226 = load i1, ptr %l117, !tbaa !21
  br i1 %t226, label %bb65, label %bb66
bb65:
  %t227 = load ptr, ptr %l1, !tbaa !29
  %t229 = getelementptr { i64, [3 x i64] }, ptr %t227, i32 0, i32 1
  %t230 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t229, i32 0, i32 1
  %t231 = load ptr, ptr %t230
  store ptr %t231, ptr %l10, !tbaa !29
  %t233 = load ptr, ptr %l1, !tbaa !29
  %t235 = getelementptr { i64, [3 x i64] }, ptr %t233, i32 0, i32 1
  %t236 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t235, i32 0, i32 2
  %t237 = load ptr, ptr %t236
  store ptr %t237, ptr %l11, !tbaa !29
  br label %bb67
bb66:
  br label %bb70
bb67:
  %t239 = load ptr, ptr %l0, !tbaa !29
  %t240 = load ptr, ptr %l10, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2escanExpr(ptr %v0, ptr %v1, ptr %t239, ptr %t240)
  br label %bb68
bb68:
  %t244 = load ptr, ptr %l0, !tbaa !29
  %t245 = load ptr, ptr %l11, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2escanExpr(ptr %v0, ptr %v1, ptr %t244, ptr %t245)
  br label %bb69
bb69:
  br label %bb117
bb70:
  %t248 = load ptr, ptr %l1, !tbaa !29
  store ptr %t248, ptr %l129, !tbaa !29
  store i1 false, ptr %l130, !tbaa !21
  %t249 = load ptr, ptr %l129, !tbaa !29
  %t250 = icmp ne ptr %t249, null
  br i1 %t250, label %bb71, label %bb72
bb71:
  %t252 = load ptr, ptr %l129, !tbaa !29
  %t253 = load i64, ptr %t252, !range !{i64 0, i64 17}
  %t255 = icmp eq i64 %t253, 9
  store i1 %t255, ptr %l130, !tbaa !21
  br label %bb72
bb72:
  %t256 = load i1, ptr %l130, !tbaa !21
  br i1 %t256, label %bb73, label %bb74
bb73:
  %t257 = load ptr, ptr %l1, !tbaa !29
  %t259 = getelementptr { i64, [3 x i64] }, ptr %t257, i32 0, i32 1
  %t260 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t259, i32 0, i32 2
  %t261 = load ptr, ptr %t260
  store ptr %t261, ptr %l12, !tbaa !29
  br label %bb79
bb74:
  %t263 = load ptr, ptr %l1, !tbaa !29
  store ptr %t263, ptr %l135, !tbaa !29
  store i1 false, ptr %l136, !tbaa !21
  %t264 = load ptr, ptr %l135, !tbaa !29
  %t265 = icmp ne ptr %t264, null
  br i1 %t265, label %bb75, label %bb76
bb75:
  %t267 = load ptr, ptr %l135, !tbaa !29
  %t268 = load i64, ptr %t267, !range !{i64 0, i64 17}
  %t270 = icmp eq i64 %t268, 8
  store i1 %t270, ptr %l136, !tbaa !21
  br label %bb76
bb76:
  %t271 = load i1, ptr %l136, !tbaa !21
  br i1 %t271, label %bb77, label %bb78
bb77:
  %t272 = load ptr, ptr %l1, !tbaa !29
  %t274 = getelementptr { i64, [3 x i64] }, ptr %t272, i32 0, i32 1
  %t275 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t274, i32 0, i32 1
  %t276 = load ptr, ptr %t275
  store ptr %t276, ptr %l12, !tbaa !29
  br label %bb79
bb78:
  br label %bb81
bb79:
  %t278 = load ptr, ptr %l0, !tbaa !29
  %t279 = load ptr, ptr %l12, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2escanExpr(ptr %v0, ptr %v1, ptr %t278, ptr %t279)
  br label %bb80
bb80:
  br label %bb117
bb81:
  %t282 = load ptr, ptr %l1, !tbaa !29
  store ptr %t282, ptr %l143, !tbaa !29
  store i1 false, ptr %l144, !tbaa !21
  %t283 = load ptr, ptr %l143, !tbaa !29
  %t284 = icmp ne ptr %t283, null
  br i1 %t284, label %bb82, label %bb83
bb82:
  %t286 = load ptr, ptr %l143, !tbaa !29
  %t287 = load i64, ptr %t286, !range !{i64 0, i64 17}
  %t289 = icmp eq i64 %t287, 13
  store i1 %t289, ptr %l144, !tbaa !21
  br label %bb83
bb83:
  %t290 = load i1, ptr %l144, !tbaa !21
  br i1 %t290, label %bb84, label %bb85
bb84:
  %t291 = load ptr, ptr %l1, !tbaa !29
  %t293 = getelementptr { i64, [3 x i64] }, ptr %t291, i32 0, i32 1
  %t294 = getelementptr { %"compiler/source:Span", ptr }, ptr %t293, i32 0, i32 1
  %t295 = load ptr, ptr %t294
  store ptr %t295, ptr %l13, !tbaa !29
  br label %bb86
bb85:
  br label %bb95
bb86:
  %t297 = load ptr, ptr %l0, !tbaa !29
  %t298 = load ptr, ptr %l13, !tbaa !29
  %t300 = getelementptr %"compiler/typed:Join", ptr %t298, i32 0, i32 0
  %t301 = load ptr, ptr %t300, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2escanBlock(ptr %v0, ptr %v1, ptr %t297, ptr %t301)
  br label %bb87
bb87:
  %t305 = load ptr, ptr %l13, !tbaa !29
  %t307 = getelementptr %"compiler/typed:Join", ptr %t305, i32 0, i32 2
  %t308 = load { i64, ptr }, ptr %t307, !tbaa !27
  store { i64, ptr } %t308, ptr %l14, !tbaa !27
  store i64 0, ptr %l15, !tbaa !24
  %t310 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t312 = extractvalue { i64, ptr } %t310, 0
  store i64 %t312, ptr %l16, !tbaa !24
  br label %bb88
bb88:
  %t314 = load i64, ptr %l15, !tbaa !24
  %t315 = load i64, ptr %l16, !tbaa !24
  %t318 = icmp slt i64 %t314, %t315
  %t320 = xor i1 %t318, true
  br i1 %t320, label %bb89, label %bb90
bb89:
  br label %bb94
bb90:
  br label %bb91
bb91:
  %t322 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t322, ptr %l161, !tbaa !27
  %t323 = load i64, ptr %l15, !tbaa !24
  %t325 = getelementptr { i64, ptr }, ptr %l161, i32 0, i32 1
  %t326 = load ptr, ptr %t325, !tbaa !27
  %t327 = getelementptr ptr, ptr %t326, i64 %t323
  %t328 = load ptr, ptr %t327, !tbaa !39
  %t330 = load ptr, ptr %l0, !tbaa !29
  %t333 = getelementptr %"compiler/typed:Clause", ptr %t328, i32 0, i32 3
  %t334 = load ptr, ptr %t333, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2escanBlock(ptr %v0, ptr %v1, ptr %t330, ptr %t334)
  br label %bb92
bb92:
  br label %bb93
bb93:
  %t337 = load i64, ptr %l15, !tbaa !24
  %t340 = add i64 %t337, 1
  store i64 %t340, ptr %l15, !tbaa !24
  br label %bb88
bb94:
  br label %bb117
bb95:
  %t342 = load ptr, ptr %l1, !tbaa !29
  store ptr %t342, ptr %l170, !tbaa !29
  store i1 false, ptr %l171, !tbaa !21
  %t343 = load ptr, ptr %l170, !tbaa !29
  %t344 = icmp ne ptr %t343, null
  br i1 %t344, label %bb96, label %bb97
bb96:
  %t346 = load ptr, ptr %l170, !tbaa !29
  %t347 = load i64, ptr %t346, !range !{i64 0, i64 17}
  %t349 = icmp eq i64 %t347, 14
  store i1 %t349, ptr %l171, !tbaa !21
  br label %bb97
bb97:
  %t350 = load i1, ptr %l171, !tbaa !21
  br i1 %t350, label %bb98, label %bb99
bb98:
  %t351 = load ptr, ptr %l1, !tbaa !29
  %t353 = getelementptr { i64, [3 x i64] }, ptr %t351, i32 0, i32 1
  %t354 = getelementptr { %"compiler/source:Span", ptr }, ptr %t353, i32 0, i32 1
  %t355 = load ptr, ptr %t354
  store ptr %t355, ptr %l18, !tbaa !29
  br label %bb100
bb99:
  br label %bb112
bb100:
  %t357 = load ptr, ptr %l18, !tbaa !29
  %t359 = getelementptr %"compiler/typed:Spawn", ptr %t357, i32 0, i32 0
  %t360 = load { i64, ptr }, ptr %t359, !tbaa !27
  store { i64, ptr } %t360, ptr %l19, !tbaa !27
  store i64 0, ptr %l20, !tbaa !24
  %t362 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t364 = extractvalue { i64, ptr } %t362, 0
  store i64 %t364, ptr %l21, !tbaa !24
  br label %bb101
bb101:
  %t366 = load i64, ptr %l20, !tbaa !24
  %t367 = load i64, ptr %l21, !tbaa !24
  %t370 = icmp slt i64 %t366, %t367
  %t372 = xor i1 %t370, true
  br i1 %t372, label %bb102, label %bb103
bb102:
  br label %bb110
bb103:
  br label %bb104
bb104:
  %t374 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t374, ptr %l184, !tbaa !27
  %t375 = load i64, ptr %l20, !tbaa !24
  %t377 = getelementptr { i64, ptr }, ptr %l184, i32 0, i32 1
  %t378 = load ptr, ptr %t377, !tbaa !27
  %t379 = getelementptr ptr, ptr %t378, i64 %t375
  %t380 = load ptr, ptr %t379, !tbaa !39
  store ptr %t380, ptr %l22, !tbaa !29
  %t382 = load ptr, ptr %l22, !tbaa !29
  %t384 = icmp eq ptr %t382, null
  %t386 = xor i1 %t384, true
  br i1 %t386, label %bb105, label %bb106
bb105:
  %t388 = load ptr, ptr %l0, !tbaa !29
  %t389 = load ptr, ptr %l22, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2escanTarget(ptr %v0, ptr %v1, ptr %t388, ptr %t389)
  br label %bb107
bb106:
  br label %bb108
bb107:
  br label %bb108
bb108:
  br label %bb109
bb109:
  %t392 = load i64, ptr %l20, !tbaa !24
  %t395 = add i64 %t392, 1
  store i64 %t395, ptr %l20, !tbaa !24
  br label %bb101
bb110:
  %t397 = load ptr, ptr %l0, !tbaa !29
  %t398 = load ptr, ptr %l18, !tbaa !29
  %t400 = getelementptr %"compiler/typed:Spawn", ptr %t398, i32 0, i32 1
  %t401 = load ptr, ptr %t400, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2escanExpr(ptr %v0, ptr %v1, ptr %t397, ptr %t401)
  br label %bb111
bb111:
  br label %bb117
bb112:
  br i1 true, label %bb113, label %bb114
bb113:
  br label %bb115
bb114:
  br label %bb116
bb115:
  br label %bb117
bb116:
  call void @__olang_check_failed(ptr @olang_loc_376d296af4c830bb_f1e6df173964d75f)
  unreachable
bb117:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2escanTarget(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca i1
  %l14 = alloca ptr
  %l17 = alloca ptr
  %l19 = alloca i32
  %l20 = alloca i32
  %l23 = alloca %"compiler/effects:pair"
  %l24 = alloca ptr
  %l25 = alloca i1
  %l31 = alloca ptr
  %l36 = alloca i32
  %l38 = alloca %"compiler/effects:pair"
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 3
  store i1 %t8, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [4 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t18, i32 0, i32 3
  %t20 = load i64, ptr %t19
  store i64 %t20, ptr %l3, !tbaa !24
  br label %bb5
bb4:
  br label %bb10
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/effects:Effects", ptr %t22, i32 0, i32 62
  store ptr %t24, ptr %l14, !tbaa !29
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/effects:Effects", ptr %t25, i32 0, i32 0
  %t28 = load ptr, ptr %t27, !tbaa !29
  %t30 = getelementptr %"compiler/generic:Program", ptr %t28, i32 0, i32 2
  store ptr %t30, ptr %l17, !tbaa !29
  %t31 = load ptr, ptr %l2, !tbaa !29
  %t33 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v1, ptr %t31)
  store i32 %t33, ptr %l19
  br label %bb6
bb6:
  %t34 = load ptr, ptr %l17, !tbaa !29
  %t35 = load i32, ptr %l19, !tbaa !23
  %t36 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t34, i32 %t35)
  store i32 %t36, ptr %l20
  br label %bb7
bb7:
  %t37 = load i32, ptr %l20, !tbaa !23
  %t38 = sext i32 %t37 to i64
  %t39 = load i64, ptr %l3, !tbaa !24
  %t42 = call %"compiler/effects:pair" @compiler_2feffects_3apair_2ector(ptr %s1, i64 %t38, i64 %t39)
  store %"compiler/effects:pair" %t42, ptr %l23
  br label %bb8
bb8:
  %t43 = load ptr, ptr %l14, !tbaa !29
  %t44 = load %"compiler/effects:pair", ptr %l23
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2feffects_3apair_2c_20Bool_3e_Ha1bc2f35f7d195c0ca99c509224bae7a(ptr %v0, ptr %t43, %"compiler/effects:pair" %t44, i1 true)
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s1)
  br label %bb24
bb10:
  %t45 = load ptr, ptr %l1, !tbaa !29
  store ptr %t45, ptr %l24, !tbaa !29
  store i1 false, ptr %l25, !tbaa !21
  %t46 = load ptr, ptr %l24, !tbaa !29
  %t47 = icmp ne ptr %t46, null
  br i1 %t47, label %bb11, label %bb12
bb11:
  %t49 = load ptr, ptr %l24, !tbaa !29
  %t50 = load i64, ptr %t49, !range !{i64 0, i64 8}
  %t52 = icmp eq i64 %t50, 2
  store i1 %t52, ptr %l25, !tbaa !21
  br label %bb12
bb12:
  %t53 = load i1, ptr %l25, !tbaa !21
  br i1 %t53, label %bb13, label %bb14
bb13:
  %t54 = load ptr, ptr %l1, !tbaa !29
  %t56 = getelementptr { i64, [4 x i64] }, ptr %t54, i32 0, i32 1
  %t57 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t56, i32 0, i32 1
  %t58 = load i32, ptr %t57
  store i32 %t58, ptr %l4, !tbaa !23
  br label %bb15
bb14:
  br label %bb19
bb15:
  store %olang.scope zeroinitializer, ptr %s2
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/effects:Effects", ptr %t60, i32 0, i32 62
  store ptr %t62, ptr %l31, !tbaa !29
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/effects:Effects", ptr %t63, i32 0, i32 0
  %t66 = load ptr, ptr %t65, !tbaa !29
  %t68 = getelementptr %"compiler/generic:Program", ptr %t66, i32 0, i32 2
  %t69 = load i32, ptr %l4, !tbaa !23
  %t72 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t68, i32 %t69)
  store i32 %t72, ptr %l36
  br label %bb16
bb16:
  %t73 = load i32, ptr %l36, !tbaa !23
  %t74 = sext i32 %t73 to i64
  %t76 = call %"compiler/effects:pair" @compiler_2feffects_3apair_2ector(ptr %s2, i64 %t74, i64 -1)
  store %"compiler/effects:pair" %t76, ptr %l38
  br label %bb17
bb17:
  %t77 = load ptr, ptr %l31, !tbaa !29
  %t78 = load %"compiler/effects:pair", ptr %l38
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2feffects_3apair_2c_20Bool_3e_Ha1bc2f35f7d195c0ca99c509224bae7a(ptr %v0, ptr %t77, %"compiler/effects:pair" %t78, i1 true)
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s2)
  br label %bb24
bb19:
  br i1 true, label %bb20, label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  call void @__olang_check_failed(ptr @olang_loc_dbda74c6bd85bcc6_57ce86cdebb39c22)
  unreachable
bb24:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2esettle(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/effects:Facts"
  %l3 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l4 = alloca ptr
  %l5 = alloca i64
  %l7 = alloca i1
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca ptr
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca %"compiler/effects:Facts"
  %l22 = alloca i64
  %l23 = alloca ptr
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i1
  %l27 = alloca i1
  %l28 = alloca ptr
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca ptr
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca ptr
  %l35 = alloca i64
  %l36 = alloca i64
  %l38 = alloca i1
  %l40 = alloca %"compiler/effects:Facts"
  %l41 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l43 = alloca i64
  %l45 = alloca i64
  %l50 = alloca i64
  %l57 = alloca i64
  %l59 = alloca ptr
  %l64 = alloca i64
  %l66 = alloca i64
  %l71 = alloca i64
  %l72 = alloca ptr
  %l76 = alloca %"compiler/effects:Facts"
  %l81 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l83 = alloca i64
  %l87 = alloca i64
  %l90 = alloca i64
  %l111 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l114 = alloca i64
  %l120 = alloca i1
  %l121 = alloca i64
  %l124 = alloca i64
  %l128 = alloca i1
  %l132 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l135 = alloca i1
  %l136 = alloca ptr
  %l140 = alloca %"compiler/effects:Facts"
  %l144 = alloca i64
  %l153 = alloca ptr
  %l157 = alloca %"compiler/effects:Facts"
  %l167 = alloca i64
  %l169 = alloca i64
  %l174 = alloca i64
  %l179 = alloca %"compiler/effects:Facts"
  %l184 = alloca %"compiler/effects:Facts"
  %l194 = alloca i64
  %l196 = alloca i64
  %l201 = alloca i64
  %l202 = alloca i64
  %l207 = alloca i64
  %l211 = alloca i64
  %l220 = alloca i64
  %l222 = alloca i64
  %l227 = alloca i64
  %l229 = alloca ptr
  %l230 = alloca i64
  %l234 = alloca %"compiler/effects:Facts"
  %l236 = alloca ptr
  %l237 = alloca i64
  %l241 = alloca %"compiler/effects:Facts"
  %l243 = alloca i1
  %l248 = alloca i64
  %l250 = alloca i64
  %l255 = alloca i64
  %l258 = alloca i1
  %l262 = alloca i1
  %l263 = alloca i1
  %l266 = alloca i1
  %l274 = alloca i64
  %l276 = alloca i64
  %l281 = alloca i64
  %l287 = alloca ptr
  %s0 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"compiler/effects:Facts" @compiler_2feffects_3aFacts_2ector(ptr %s0)
  store %"compiler/effects:Facts" %t1, ptr %l40
  br label %bb1
bb1:
  %t2 = load %"compiler/effects:Facts", ptr %l40
  store %"compiler/effects:Facts" %t2, ptr %l2
  %t3 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %s0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t3, ptr %l41
  br label %bb2
bb2:
  %t4 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l41
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t4, ptr %l3
  %t5 = load ptr, ptr %l1, !tbaa !29
  store ptr %t5, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb3
bb3:
  %t7 = load i64, ptr %l5, !tbaa !24
  store i64 %t7, ptr %l43, !tbaa !24
  %t8 = load ptr, ptr %l4, !tbaa !29
  %t10 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t8)
  store i64 %t10, ptr %l45
  br label %bb4
bb4:
  %t11 = load i64, ptr %l43, !tbaa !24
  %t12 = load i64, ptr %l45, !tbaa !24
  %t13 = icmp slt i64 %t11, %t12
  %t15 = xor i1 %t13, true
  br i1 %t15, label %bb5, label %bb6
bb5:
  br label %bb11
bb6:
  br label %bb7
bb7:
  %t17 = load ptr, ptr %l4, !tbaa !29
  %t18 = load i64, ptr %l5, !tbaa !24
  %t21 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t17, i64 %t18)
  store i64 %t21, ptr %l50
  br label %bb8
bb8:
  %t22 = load i64, ptr %l50, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %s0, ptr %l3, i64 %t22, i1 true)
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t26 = load i64, ptr %l5, !tbaa !24
  %t29 = add i64 %t26, 1
  store i64 %t29, ptr %l5, !tbaa !24
  br label %bb3
bb11:
  %t31 = load ptr, ptr %l1, !tbaa !29
  %t33 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t31)
  store i64 %t33, ptr %l57
  br label %bb12
bb12:
  %t34 = load i64, ptr %l57, !tbaa !24
  %t35 = icmp sgt i64 %t34, 1
  store i1 %t35, ptr %l7, !tbaa !21
  %t37 = load ptr, ptr %l0, !tbaa !29
  store ptr %t37, ptr %l59, !tbaa !29
  %t38 = load ptr, ptr %l59, !tbaa !29
  %t39 = getelementptr %"compiler/effects:Effects", ptr %t38, i32 0, i32 15
  %t40 = load i64, ptr %t39, !tbaa !24
  %t43 = add i64 %t40, 1
  %t45 = load ptr, ptr %l59, !tbaa !29
  %t46 = getelementptr %"compiler/effects:Effects", ptr %t45, i32 0, i32 15
  store i64 %t43, ptr %t46, !tbaa !24
  %t47 = load ptr, ptr %l1, !tbaa !29
  store ptr %t47, ptr %l8, !tbaa !29
  store i64 0, ptr %l9, !tbaa !24
  br label %bb13
bb13:
  store %olang.scope zeroinitializer, ptr %s5
  %t49 = load i64, ptr %l9, !tbaa !24
  store i64 %t49, ptr %l64, !tbaa !24
  %t50 = load ptr, ptr %l8, !tbaa !29
  %t52 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t50)
  store i64 %t52, ptr %l66
  br label %bb14
bb14:
  %t53 = load i64, ptr %l64, !tbaa !24
  %t54 = load i64, ptr %l66, !tbaa !24
  %t55 = icmp slt i64 %t53, %t54
  %t57 = xor i1 %t55, true
  br i1 %t57, label %bb15, label %bb16
bb15:
  call void @__olang_scope_close(ptr %s5)
  br label %bb66
bb16:
  br label %bb17
bb17:
  %t59 = load ptr, ptr %l8, !tbaa !29
  %t60 = load i64, ptr %l9, !tbaa !24
  %t63 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t59, i64 %t60)
  store i64 %t63, ptr %l71
  br label %bb18
bb18:
  %t64 = load i64, ptr %l71, !tbaa !24
  store i64 %t64, ptr %l10, !tbaa !24
  store ptr %l2, ptr %l72, !tbaa !29
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/effects:Effects", ptr %t65, i32 0, i32 3
  %t68 = load i64, ptr %l10, !tbaa !24
  %t71 = call %"compiler/effects:Facts" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3aFacts_3e_2eAt_3ccompiler_2feffects_3aFacts_3e(ptr %v0, ptr %t67, i64 %t68)
  store %"compiler/effects:Facts" %t71, ptr %l76
  br label %bb19
bb19:
  %t72 = load ptr, ptr %l72, !tbaa !29
  call void @compiler_2feffects_2eMerge(ptr %s0, ptr %s5, ptr %t72, ptr %l76)
  br label %bb20
bb20:
  store i64 0, ptr %l11, !tbaa !24
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr %"compiler/effects:Effects", ptr %t74, i32 0, i32 6
  %t77 = load i64, ptr %l10, !tbaa !24
  %t80 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__H7b6d4eff6fc9c3821aae8b284e12e095(ptr %v0, ptr %v0, ptr %t76, i64 %t77)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t80, ptr %l81
  br label %bb21
bb21:
  %t82 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %l81)
  store i64 %t82, ptr %l83
  br label %bb22
bb22:
  %t83 = load i64, ptr %l83, !tbaa !24
  store i64 %t83, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t84 = load i64, ptr %l12, !tbaa !24
  %t85 = load i64, ptr %l11, !tbaa !24
  %t88 = icmp sgt i64 %t84, %t85
  br i1 %t88, label %bb23, label %bb24
bb23:
  %t90 = load i64, ptr %l13, !tbaa !24
  %t92 = icmp sgt i64 %t90, 0
  br i1 %t92, label %bb25, label %bb26
bb24:
  store i64 0, ptr %l87, !tbaa !24
  br label %bb28
bb25:
  %t94 = load i64, ptr %l12, !tbaa !24
  %t95 = load i64, ptr %l11, !tbaa !24
  %t98 = sub i64 %t94, %t95
  %t99 = load i64, ptr %l13, !tbaa !24
  %t102 = add i64 %t98, %t99
  %t104 = sub i64 %t102, 1
  %t105 = load i64, ptr %l13, !tbaa !24
  %t108 = sdiv i64 %t104, %t105
  store i64 %t108, ptr %l90, !tbaa !24
  br label %bb27
bb26:
  store i64 0, ptr %l90, !tbaa !24
  br label %bb27
bb27:
  %t110 = load i64, ptr %l90, !tbaa !24
  store i64 %t110, ptr %l87, !tbaa !24
  br label %bb28
bb28:
  %t111 = load i64, ptr %l87, !tbaa !24
  store i64 %t111, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb29
bb29:
  store %olang.scope zeroinitializer, ptr %s7
  %t112 = load i64, ptr %l15, !tbaa !24
  %t113 = load i64, ptr %l14, !tbaa !24
  %t116 = icmp slt i64 %t112, %t113
  %t118 = xor i1 %t116, true
  br i1 %t118, label %bb30, label %bb31
bb30:
  call void @__olang_scope_close(ptr %s7)
  br label %bb64
bb31:
  br label %bb32
bb32:
  %t120 = load i64, ptr %l11, !tbaa !24
  %t121 = load i64, ptr %l15, !tbaa !24
  %t122 = load i64, ptr %l13, !tbaa !24
  %t125 = mul i64 %t121, %t122
  %t128 = add i64 %t120, %t125
  store i64 %t128, ptr %l16, !tbaa !24
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t132 = getelementptr %"compiler/effects:Effects", ptr %t130, i32 0, i32 6
  %t133 = load i64, ptr %l10, !tbaa !24
  %t136 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__H7b6d4eff6fc9c3821aae8b284e12e095(ptr %v0, ptr %v0, ptr %t132, i64 %t133)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t136, ptr %l111
  br label %bb33
bb33:
  %t137 = load i64, ptr %l16, !tbaa !24
  %t140 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %l111, i64 %t137)
  store i64 %t140, ptr %l114
  br label %bb34
bb34:
  %t141 = load i64, ptr %l114, !tbaa !24
  store i64 %t141, ptr %l17, !tbaa !24
  %t142 = load i64, ptr %l17, !tbaa !24
  %t143 = load i64, ptr %l10, !tbaa !24
  %t146 = icmp eq i64 %t142, %t143
  br i1 %t146, label %bb35, label %bb36
bb35:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb37
bb36:
  br label %bb37
bb37:
  %t148 = load i64, ptr %l17, !tbaa !24
  %t150 = icmp slt i64 %t148, 0
  br i1 %t150, label %bb38, label %bb39
bb38:
  store i1 true, ptr %l120, !tbaa !21
  br label %bb41
bb39:
  %t152 = load i64, ptr %l17, !tbaa !24
  store i64 %t152, ptr %l121, !tbaa !24
  %t153 = load ptr, ptr %l0, !tbaa !29
  %t155 = getelementptr %"compiler/effects:Effects", ptr %t153, i32 0, i32 1
  %t157 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %t155)
  store i64 %t157, ptr %l124
  br label %bb40
bb40:
  %t158 = load i64, ptr %l121, !tbaa !24
  %t159 = load i64, ptr %l124, !tbaa !24
  %t160 = icmp sge i64 %t158, %t159
  store i1 %t160, ptr %l120, !tbaa !21
  br label %bb41
bb41:
  %t162 = load i1, ptr %l120, !tbaa !21
  br i1 %t162, label %bb42, label %bb43
bb42:
  %t163 = getelementptr %"compiler/effects:Facts", ptr %l2, i32 0, i32 16
  store i1 true, ptr %t163, !tbaa !21
  call void @__olang_scope_close(ptr %s7)
  br label %bb63
bb43:
  br label %bb44
bb44:
  %t164 = load i64, ptr %l17, !tbaa !24
  %t167 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %s0, ptr %l3, i64 %t164)
  store i1 %t167, ptr %l128
  br label %bb45
bb45:
  %t168 = load i1, ptr %l128, !tbaa !21
  br i1 %t168, label %bb46, label %bb47
bb46:
  call void @__olang_scope_close(ptr %s7)
  br label %bb63
bb47:
  br label %bb48
bb48:
  %t169 = load ptr, ptr %l0, !tbaa !29
  %t171 = getelementptr %"compiler/effects:Effects", ptr %t169, i32 0, i32 7
  %t172 = load i64, ptr %l10, !tbaa !24
  %t175 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__H7b6d4eff6fc9c3821aae8b284e12e095(ptr %v0, ptr %v0, ptr %t171, i64 %t172)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t175, ptr %l132
  br label %bb49
bb49:
  %t176 = load i64, ptr %l16, !tbaa !24
  %t179 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eHas_3cI64_3e(ptr %v0, ptr %l132, i64 %t176)
  store i1 %t179, ptr %l135
  br label %bb50
bb50:
  %t180 = load i1, ptr %l135, !tbaa !21
  br i1 %t180, label %bb51, label %bb52
bb51:
  store ptr %l2, ptr %l136, !tbaa !29
  %t181 = load ptr, ptr %l0, !tbaa !29
  %t183 = getelementptr %"compiler/effects:Effects", ptr %t181, i32 0, i32 11
  %t184 = load i64, ptr %l17, !tbaa !24
  %t187 = call %"compiler/effects:Facts" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3aFacts_3e_2eAt_3ccompiler_2feffects_3aFacts_3e(ptr %v0, ptr %t183, i64 %t184)
  store %"compiler/effects:Facts" %t187, ptr %l140
  br label %bb53
bb52:
  br label %bb55
bb53:
  %t188 = load ptr, ptr %l136, !tbaa !29
  %t189 = load %"compiler/effects:Facts", ptr %l140
  call void @compiler_2feffects_2eMergeCold(ptr %s0, ptr %t188, %"compiler/effects:Facts" %t189)
  br label %bb54
bb54:
  call void @__olang_scope_close(ptr %s7)
  br label %bb63
bb55:
  %t190 = load ptr, ptr %l0, !tbaa !29
  %t192 = getelementptr %"compiler/effects:Effects", ptr %t190, i32 0, i32 14
  %t193 = load i64, ptr %l17, !tbaa !24
  %t196 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t192, i64 %t193)
  store i64 %t196, ptr %l144
  br label %bb56
bb56:
  %t197 = load ptr, ptr %l0, !tbaa !29
  %t199 = getelementptr %"compiler/effects:Effects", ptr %t197, i32 0, i32 15
  %t200 = load i64, ptr %t199, !tbaa !24
  %t201 = load i64, ptr %l144, !tbaa !24
  %t203 = icmp eq i64 %t201, %t200
  br i1 %t203, label %bb57, label %bb58
bb57:
  call void @__olang_scope_close(ptr %s7)
  br label %bb63
bb58:
  br label %bb59
bb59:
  %t205 = load ptr, ptr %l0, !tbaa !29
  %t207 = getelementptr %"compiler/effects:Effects", ptr %t205, i32 0, i32 14
  %t208 = load i64, ptr %l17, !tbaa !24
  %t209 = load ptr, ptr %l0, !tbaa !29
  %t211 = getelementptr %"compiler/effects:Effects", ptr %t209, i32 0, i32 15
  %t212 = load i64, ptr %t211, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t207, i64 %t208, i64 %t212)
  br label %bb60
bb60:
  store ptr %l2, ptr %l153, !tbaa !29
  %t216 = load ptr, ptr %l0, !tbaa !29
  %t218 = getelementptr %"compiler/effects:Effects", ptr %t216, i32 0, i32 11
  %t219 = load i64, ptr %l17, !tbaa !24
  %t222 = call %"compiler/effects:Facts" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3aFacts_3e_2eAt_3ccompiler_2feffects_3aFacts_3e(ptr %v0, ptr %t218, i64 %t219)
  store %"compiler/effects:Facts" %t222, ptr %l157
  br label %bb61
bb61:
  %t223 = load ptr, ptr %l153, !tbaa !29
  call void @compiler_2feffects_2eMerge(ptr %s0, ptr %s7, ptr %t223, ptr %l157)
  br label %bb62
bb62:
  call void @__olang_scope_close(ptr %s7)
  br label %bb63
bb63:
  %t225 = load i64, ptr %l15, !tbaa !24
  %t228 = add i64 %t225, 1
  store i64 %t228, ptr %l15, !tbaa !24
  br label %bb29
bb64:
  call void @__olang_scope_close(ptr %s5)
  br label %bb65
bb65:
  %t230 = load i64, ptr %l9, !tbaa !24
  %t233 = add i64 %t230, 1
  store i64 %t233, ptr %l9, !tbaa !24
  br label %bb13
bb66:
  %t235 = load i1, ptr %l7, !tbaa !21
  br i1 %t235, label %bb67, label %bb68
bb67:
  %t237 = getelementptr %"compiler/effects:Facts", ptr %l2, i32 0, i32 10
  store i1 true, ptr %t237, !tbaa !21
  br label %bb69
bb68:
  br label %bb69
bb69:
  %t238 = load ptr, ptr %l1, !tbaa !29
  store ptr %t238, ptr %l18, !tbaa !29
  store i64 0, ptr %l19, !tbaa !24
  br label %bb70
bb70:
  %t240 = load i64, ptr %l19, !tbaa !24
  store i64 %t240, ptr %l167, !tbaa !24
  %t241 = load ptr, ptr %l18, !tbaa !29
  %t243 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t241)
  store i64 %t243, ptr %l169
  br label %bb71
bb71:
  %t244 = load i64, ptr %l167, !tbaa !24
  %t245 = load i64, ptr %l169, !tbaa !24
  %t246 = icmp slt i64 %t244, %t245
  %t248 = xor i1 %t246, true
  br i1 %t248, label %bb72, label %bb73
bb72:
  br label %bb80
bb73:
  br label %bb74
bb74:
  %t250 = load ptr, ptr %l18, !tbaa !29
  %t251 = load i64, ptr %l19, !tbaa !24
  %t254 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t250, i64 %t251)
  store i64 %t254, ptr %l174
  br label %bb75
bb75:
  %t255 = load i64, ptr %l174, !tbaa !24
  store i64 %t255, ptr %l20, !tbaa !24
  %t256 = load %"compiler/effects:Facts", ptr %l2
  store %"compiler/effects:Facts" %t256, ptr %l21
  %t258 = load ptr, ptr %l0, !tbaa !29
  %t260 = getelementptr %"compiler/effects:Effects", ptr %t258, i32 0, i32 3
  %t261 = load i64, ptr %l20, !tbaa !24
  %t264 = call %"compiler/effects:Facts" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3aFacts_3e_2eAt_3ccompiler_2feffects_3aFacts_3e(ptr %v0, ptr %t260, i64 %t261)
  store %"compiler/effects:Facts" %t264, ptr %l179
  br label %bb76
bb76:
  %t265 = getelementptr %"compiler/effects:Facts", ptr %l179, i32 0, i32 23
  %t266 = load i64, ptr %t265, !tbaa !24
  %t268 = getelementptr %"compiler/effects:Facts", ptr %l21, i32 0, i32 23
  store i64 %t266, ptr %t268, !tbaa !24
  %t269 = load ptr, ptr %l0, !tbaa !29
  %t271 = getelementptr %"compiler/effects:Effects", ptr %t269, i32 0, i32 3
  %t272 = load i64, ptr %l20, !tbaa !24
  %t275 = call %"compiler/effects:Facts" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3aFacts_3e_2eAt_3ccompiler_2feffects_3aFacts_3e(ptr %v0, ptr %t271, i64 %t272)
  store %"compiler/effects:Facts" %t275, ptr %l184
  br label %bb77
bb77:
  %t276 = getelementptr %"compiler/effects:Facts", ptr %l184, i32 0, i32 24
  %t277 = load i64, ptr %t276, !tbaa !24
  %t279 = getelementptr %"compiler/effects:Facts", ptr %l21, i32 0, i32 24
  store i64 %t277, ptr %t279, !tbaa !24
  %t280 = load ptr, ptr %l0, !tbaa !29
  %t282 = getelementptr %"compiler/effects:Effects", ptr %t280, i32 0, i32 11
  %t283 = load i64, ptr %l20, !tbaa !24
  %t284 = load %"compiler/effects:Facts", ptr %l21
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3aFacts_3e_2eSetAt_3ccompiler_2feffects_3aFacts_3e(ptr %v0, ptr %t282, i64 %t283, %"compiler/effects:Facts" %t284)
  br label %bb78
bb78:
  br label %bb79
bb79:
  %t288 = load i64, ptr %l19, !tbaa !24
  %t291 = add i64 %t288, 1
  store i64 %t291, ptr %l19, !tbaa !24
  br label %bb70
bb80:
  br label %bb81
bb81:
  store i64 0, ptr %l22, !tbaa !24
  %t293 = load ptr, ptr %l1, !tbaa !29
  store ptr %t293, ptr %l23, !tbaa !29
  store i64 0, ptr %l24, !tbaa !24
  br label %bb82
bb82:
  %t295 = load i64, ptr %l24, !tbaa !24
  store i64 %t295, ptr %l194, !tbaa !24
  %t296 = load ptr, ptr %l23, !tbaa !29
  %t298 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t296)
  store i64 %t298, ptr %l196
  br label %bb83
bb83:
  %t299 = load i64, ptr %l194, !tbaa !24
  %t300 = load i64, ptr %l196, !tbaa !24
  %t301 = icmp slt i64 %t299, %t300
  %t303 = xor i1 %t301, true
  br i1 %t303, label %bb84, label %bb85
bb84:
  br label %bb91
bb85:
  br label %bb86
bb86:
  %t305 = load ptr, ptr %l23, !tbaa !29
  %t306 = load i64, ptr %l24, !tbaa !24
  %t309 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t305, i64 %t306)
  store i64 %t309, ptr %l201
  br label %bb87
bb87:
  %t310 = load i64, ptr %l201, !tbaa !24
  store i64 %t310, ptr %l25, !tbaa !24
  %t311 = load i64, ptr %l22, !tbaa !24
  store i64 %t311, ptr %l202, !tbaa !24
  %t312 = load ptr, ptr %l0, !tbaa !29
  %t313 = load i64, ptr %l25, !tbaa !24
  %t314 = load ptr, ptr %l1, !tbaa !29
  %t319 = call i64 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2epassWrites(ptr %v0, ptr %v1, ptr %s0, ptr %t312, i64 %t313, ptr %t314, ptr %l3)
  store i64 %t319, ptr %l207
  br label %bb88
bb88:
  %t320 = load ptr, ptr %l0, !tbaa !29
  %t321 = load i64, ptr %l25, !tbaa !24
  %t325 = call i64 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2epassCalls(ptr %v0, ptr %s0, ptr %t320, i64 %t321, ptr %l3)
  store i64 %t325, ptr %l211
  br label %bb89
bb89:
  %t326 = load i64, ptr %l207, !tbaa !24
  %t327 = load i64, ptr %l211, !tbaa !24
  %t328 = add i64 %t326, %t327
  %t329 = load i64, ptr %l202, !tbaa !24
  %t331 = add i64 %t329, %t328
  store i64 %t331, ptr %l22, !tbaa !24
  br label %bb90
bb90:
  %t333 = load i64, ptr %l24, !tbaa !24
  %t336 = add i64 %t333, 1
  store i64 %t336, ptr %l24, !tbaa !24
  br label %bb82
bb91:
  %t338 = load i64, ptr %l22, !tbaa !24
  %t340 = icmp eq i64 %t338, 0
  br i1 %t340, label %bb92, label %bb93
bb92:
  br label %bb96
bb93:
  br label %bb94
bb94:
  br label %bb95
bb95:
  br label %bb81
bb96:
  store i1 false, ptr %l26, !tbaa !21
  store i1 false, ptr %l27, !tbaa !21
  %t342 = load ptr, ptr %l1, !tbaa !29
  store ptr %t342, ptr %l28, !tbaa !29
  store i64 0, ptr %l29, !tbaa !24
  br label %bb97
bb97:
  %t344 = load i64, ptr %l29, !tbaa !24
  store i64 %t344, ptr %l220, !tbaa !24
  %t345 = load ptr, ptr %l28, !tbaa !29
  %t347 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t345)
  store i64 %t347, ptr %l222
  br label %bb98
bb98:
  %t348 = load i64, ptr %l220, !tbaa !24
  %t349 = load i64, ptr %l222, !tbaa !24
  %t350 = icmp slt i64 %t348, %t349
  %t352 = xor i1 %t350, true
  br i1 %t352, label %bb99, label %bb100
bb99:
  br label %bb111
bb100:
  br label %bb101
bb101:
  %t354 = load ptr, ptr %l28, !tbaa !29
  %t355 = load i64, ptr %l29, !tbaa !24
  %t358 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t354, i64 %t355)
  store i64 %t358, ptr %l227
  br label %bb102
bb102:
  %t359 = load i64, ptr %l227, !tbaa !24
  store i64 %t359, ptr %l30, !tbaa !24
  %t360 = load ptr, ptr %l0, !tbaa !29
  %t362 = getelementptr %"compiler/effects:Effects", ptr %t360, i32 0, i32 12
  store ptr %t362, ptr %l229, !tbaa !29
  %t363 = load i64, ptr %l30, !tbaa !24
  store i64 %t363, ptr %l230, !tbaa !24
  %t364 = load ptr, ptr %l0, !tbaa !29
  %t366 = getelementptr %"compiler/effects:Effects", ptr %t364, i32 0, i32 11
  %t367 = load i64, ptr %l30, !tbaa !24
  %t370 = call %"compiler/effects:Facts" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3aFacts_3e_2eAt_3ccompiler_2feffects_3aFacts_3e(ptr %v0, ptr %t366, i64 %t367)
  store %"compiler/effects:Facts" %t370, ptr %l234
  br label %bb103
bb103:
  %t371 = getelementptr %"compiler/effects:Facts", ptr %l234, i32 0, i32 24
  %t372 = load i64, ptr %t371, !tbaa !24
  %t373 = load ptr, ptr %l229, !tbaa !29
  %t374 = load i64, ptr %l230, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t373, i64 %t374, i64 %t372)
  br label %bb104
bb104:
  %t376 = load ptr, ptr %l0, !tbaa !29
  store ptr %t376, ptr %l236, !tbaa !29
  %t377 = load i64, ptr %l30, !tbaa !24
  store i64 %t377, ptr %l237, !tbaa !24
  %t378 = load ptr, ptr %l0, !tbaa !29
  %t380 = getelementptr %"compiler/effects:Effects", ptr %t378, i32 0, i32 11
  %t381 = load i64, ptr %l30, !tbaa !24
  %t384 = call %"compiler/effects:Facts" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3aFacts_3e_2eAt_3ccompiler_2feffects_3aFacts_3e(ptr %v0, ptr %t380, i64 %t381)
  store %"compiler/effects:Facts" %t384, ptr %l241
  br label %bb105
bb105:
  %t385 = getelementptr %"compiler/effects:Facts", ptr %l241, i32 0, i32 23
  %t386 = load i64, ptr %t385, !tbaa !24
  %t387 = load ptr, ptr %l236, !tbaa !29
  %t388 = load i64, ptr %l237, !tbaa !24
  %t390 = call i1 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ewritesUnowned(ptr %v0, ptr %t387, i64 %t388, i64 %t386)
  store i1 %t390, ptr %l243
  br label %bb106
bb106:
  %t391 = load i1, ptr %l243, !tbaa !21
  br i1 %t391, label %bb107, label %bb108
bb107:
  store i1 true, ptr %l27, !tbaa !21
  br label %bb109
bb108:
  br label %bb109
bb109:
  br label %bb110
bb110:
  %t392 = load i64, ptr %l29, !tbaa !24
  %t395 = add i64 %t392, 1
  store i64 %t395, ptr %l29, !tbaa !24
  br label %bb97
bb111:
  %t397 = load ptr, ptr %l1, !tbaa !29
  store ptr %t397, ptr %l31, !tbaa !29
  store i64 0, ptr %l32, !tbaa !24
  br label %bb112
bb112:
  %t399 = load i64, ptr %l32, !tbaa !24
  store i64 %t399, ptr %l248, !tbaa !24
  %t400 = load ptr, ptr %l31, !tbaa !29
  %t402 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t400)
  store i64 %t402, ptr %l250
  br label %bb113
bb113:
  %t403 = load i64, ptr %l248, !tbaa !24
  %t404 = load i64, ptr %l250, !tbaa !24
  %t405 = icmp slt i64 %t403, %t404
  %t407 = xor i1 %t405, true
  br i1 %t407, label %bb114, label %bb115
bb114:
  br label %bb130
bb115:
  br label %bb116
bb116:
  %t409 = load ptr, ptr %l31, !tbaa !29
  %t410 = load i64, ptr %l32, !tbaa !24
  %t413 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t409, i64 %t410)
  store i64 %t413, ptr %l255
  br label %bb117
bb117:
  %t414 = load i64, ptr %l255, !tbaa !24
  store i64 %t414, ptr %l33, !tbaa !24
  %t415 = load i1, ptr %l26, !tbaa !21
  %t417 = xor i1 %t415, true
  br i1 %t417, label %bb118, label %bb119
bb118:
  %t419 = load ptr, ptr %l0, !tbaa !29
  %t421 = getelementptr %"compiler/effects:Effects", ptr %t419, i32 0, i32 16
  %t422 = load i64, ptr %l33, !tbaa !24
  %t425 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t421, i64 %t422)
  store i1 %t425, ptr %l262
  br label %bb120
bb119:
  store i1 false, ptr %l258, !tbaa !21
  br label %bb121
bb120:
  %t426 = load i1, ptr %l262, !tbaa !21
  store i1 %t426, ptr %l258, !tbaa !21
  br label %bb121
bb121:
  %t427 = load i1, ptr %l258, !tbaa !21
  br i1 %t427, label %bb122, label %bb123
bb122:
  %t428 = load ptr, ptr %l0, !tbaa !29
  %t429 = load i64, ptr %l33, !tbaa !24
  %t432 = call i1 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ecallsThrough(ptr %v0, ptr %t428, i64 %t429)
  store i1 %t432, ptr %l266
  br label %bb124
bb123:
  store i1 false, ptr %l263, !tbaa !21
  br label %bb125
bb124:
  %t433 = load i1, ptr %l266, !tbaa !21
  store i1 %t433, ptr %l263, !tbaa !21
  br label %bb125
bb125:
  %t434 = load i1, ptr %l263, !tbaa !21
  br i1 %t434, label %bb126, label %bb127
bb126:
  store i1 true, ptr %l26, !tbaa !21
  br label %bb128
bb127:
  br label %bb128
bb128:
  br label %bb129
bb129:
  %t435 = load i64, ptr %l32, !tbaa !24
  %t438 = add i64 %t435, 1
  store i64 %t438, ptr %l32, !tbaa !24
  br label %bb112
bb130:
  %t440 = load i1, ptr %l26, !tbaa !21
  br i1 %t440, label %bb131, label %bb132
bb131:
  %t442 = load ptr, ptr %l0, !tbaa !29
  %t443 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ethroughBounds(ptr %v0, ptr %v1, ptr %t442, ptr %t443)
  br label %bb133
bb132:
  br label %bb134
bb133:
  br label %bb134
bb134:
  %t446 = load ptr, ptr %l1, !tbaa !29
  store ptr %t446, ptr %l34, !tbaa !29
  store i64 0, ptr %l35, !tbaa !24
  br label %bb135
bb135:
  %t448 = load i64, ptr %l35, !tbaa !24
  store i64 %t448, ptr %l274, !tbaa !24
  %t449 = load ptr, ptr %l34, !tbaa !29
  %t451 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t449)
  store i64 %t451, ptr %l276
  br label %bb136
bb136:
  %t452 = load i64, ptr %l274, !tbaa !24
  %t453 = load i64, ptr %l276, !tbaa !24
  %t454 = icmp slt i64 %t452, %t453
  %t456 = xor i1 %t454, true
  br i1 %t456, label %bb137, label %bb138
bb137:
  br label %bb147
bb138:
  br label %bb139
bb139:
  %t458 = load ptr, ptr %l34, !tbaa !29
  %t459 = load i64, ptr %l35, !tbaa !24
  %t462 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t458, i64 %t459)
  store i64 %t462, ptr %l281
  br label %bb140
bb140:
  %t463 = load i64, ptr %l281, !tbaa !24
  store i64 %t463, ptr %l36, !tbaa !24
  %t464 = load i1, ptr %l27, !tbaa !21
  br i1 %t464, label %bb141, label %bb142
bb141:
  %t466 = load i64, ptr %l36, !tbaa !24
  store i1 true, ptr %l38, !tbaa !21
  %t468 = load ptr, ptr %l0, !tbaa !29
  %t470 = getelementptr %"compiler/effects:Effects", ptr %t468, i32 0, i32 11
  %t474 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3aFacts_3e_2eRefMut_3ccompiler_2feffects_3aFacts_3e(ptr %v0, ptr %v0, ptr %t470, i64 %t466)
  store ptr %t474, ptr %l287
  br label %bb143
bb142:
  br label %bb144
bb143:
  %t475 = load ptr, ptr %l287, !tbaa !29
  %t477 = load i1, ptr %l38, !tbaa !21
  %t480 = getelementptr %"compiler/effects:Facts", ptr %t475, i32 0, i32 20
  store i1 %t477, ptr %t480, !tbaa !21
  br label %bb144
bb144:
  %t481 = load ptr, ptr %l0, !tbaa !29
  %t483 = getelementptr %"compiler/effects:Effects", ptr %t481, i32 0, i32 17
  %t484 = load i64, ptr %l36, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t483, i64 %t484, i64 2)
  br label %bb145
bb145:
  br label %bb146
bb146:
  %t487 = load i64, ptr %l35, !tbaa !24
  %t490 = add i64 %t487, 1
  store i64 %t490, ptr %l35, !tbaa !24
  br label %bb135
bb147:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eshapesOf(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i32
  %l16 = alloca i32
  %l17 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i32
  %l26 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l27 = alloca i1
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l37 = alloca ptr
  %l40 = alloca i32
  %l41 = alloca { i64, ptr }
  %l45 = alloca i64
  %l51 = alloca i64
  %l54 = alloca i64
  %l73 = alloca { i64, ptr }
  %l76 = alloca i1
  %l79 = alloca i64
  %l88 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l96 = alloca { i64, ptr }
  %l99 = alloca ptr
  %l102 = alloca i1
  %l103 = alloca i1
  %l106 = alloca i1
  %l108 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l109 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l112 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l118 = alloca i32
  %l122 = alloca i1
  %l126 = alloca i1
  %l129 = alloca i1
  %l130 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l133 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l134 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l140 = alloca i64
  %l143 = alloca i64
  %l162 = alloca i64
  %l166 = alloca ptr
  %l168 = alloca { i64, ptr }
  %l171 = alloca i32
  %l172 = alloca i32
  %l173 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l177 = alloca i32
  %l182 = alloca i1
  %l183 = alloca i1
  %l184 = alloca ptr
  %l185 = alloca i32
  %l186 = alloca ptr
  %l187 = alloca i64
  %l191 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l193 = alloca i1
  %l199 = alloca i64
  %l202 = alloca i64
  %l223 = alloca i1
  %l226 = alloca ptr
  %l227 = alloca i32
  %l228 = alloca ptr
  %l229 = alloca i64
  %l233 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l235 = alloca i1
  %l243 = alloca i64
  %s0 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/effects:Effects", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  store ptr %t6, ptr %l2, !tbaa !29
  %t8 = load ptr, ptr %l2, !tbaa !29
  store ptr %t8, ptr %l37, !tbaa !29
  %t9 = load ptr, ptr %l2, !tbaa !29
  %t10 = load i32, ptr %l1, !tbaa !23
  %t13 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t9, i32 %t10)
  store i32 %t13, ptr %l40
  br label %bb1
bb1:
  %t14 = load ptr, ptr %l37, !tbaa !29
  %t15 = load i32, ptr %l40, !tbaa !23
  %t16 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t14, i32 %t15)
  store { i64, ptr } %t16, ptr %l41
  br label %bb2
bb2:
  %t17 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t17, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  %t18 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t20 = extractvalue { i64, ptr } %t18, 0
  %t22 = icmp slt i64 %t20, 62
  br i1 %t22, label %bb3, label %bb4
bb3:
  %t24 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 0
  store i64 %t26, ptr %l45, !tbaa !24
  br label %bb5
bb4:
  store i64 62, ptr %l45, !tbaa !24
  br label %bb5
bb5:
  %t28 = load i64, ptr %l45, !tbaa !24
  store i64 %t28, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t29 = load i64, ptr %l6, !tbaa !24
  %t30 = load i64, ptr %l5, !tbaa !24
  %t33 = icmp sgt i64 %t29, %t30
  br i1 %t33, label %bb6, label %bb7
bb6:
  %t35 = load i64, ptr %l7, !tbaa !24
  %t37 = icmp sgt i64 %t35, 0
  br i1 %t37, label %bb8, label %bb9
bb7:
  store i64 0, ptr %l51, !tbaa !24
  br label %bb11
bb8:
  %t39 = load i64, ptr %l6, !tbaa !24
  %t40 = load i64, ptr %l5, !tbaa !24
  %t43 = sub i64 %t39, %t40
  %t44 = load i64, ptr %l7, !tbaa !24
  %t47 = add i64 %t43, %t44
  %t49 = sub i64 %t47, 1
  %t50 = load i64, ptr %l7, !tbaa !24
  %t53 = sdiv i64 %t49, %t50
  store i64 %t53, ptr %l54, !tbaa !24
  br label %bb10
bb9:
  store i64 0, ptr %l54, !tbaa !24
  br label %bb10
bb10:
  %t55 = load i64, ptr %l54, !tbaa !24
  store i64 %t55, ptr %l51, !tbaa !24
  br label %bb11
bb11:
  %t56 = load i64, ptr %l51, !tbaa !24
  store i64 %t56, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb12
bb12:
  %t57 = load i64, ptr %l9, !tbaa !24
  %t58 = load i64, ptr %l8, !tbaa !24
  %t61 = icmp slt i64 %t57, %t58
  %t63 = xor i1 %t61, true
  br i1 %t63, label %bb13, label %bb14
bb13:
  br label %bb21
bb14:
  br label %bb15
bb15:
  %t65 = load i64, ptr %l5, !tbaa !24
  %t66 = load i64, ptr %l9, !tbaa !24
  %t67 = load i64, ptr %l7, !tbaa !24
  %t70 = mul i64 %t66, %t67
  %t73 = add i64 %t65, %t70
  store i64 %t73, ptr %l10, !tbaa !24
  %t75 = load ptr, ptr %l2, !tbaa !29
  %t76 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t76, ptr %l73, !tbaa !27
  %t77 = load i64, ptr %l10, !tbaa !24
  %t79 = getelementptr { i64, ptr }, ptr %l73, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !27
  %t81 = getelementptr i32, ptr %t80, i64 %t77
  %t82 = load i32, ptr %t81, !tbaa !33
  %t85 = call i1 @compiler_2feffects_2eexclusiveShape(ptr %v0, ptr %t75, i32 %t82)
  store i1 %t85, ptr %l76
  br label %bb16
bb16:
  %t86 = load i1, ptr %l76, !tbaa !21
  br i1 %t86, label %bb17, label %bb18
bb17:
  %t87 = load i64, ptr %l4, !tbaa !24
  %t89 = load i64, ptr %l10, !tbaa !24
  store i64 %t89, ptr %l79, !tbaa !24
  %t90 = load i64, ptr %l79, !tbaa !24
  %t91 = load i64, ptr %l79, !tbaa !24
  %t92 = shl i64 1, %t91
  %t95 = or i64 %t87, %t92
  store i64 %t95, ptr %l4, !tbaa !24
  br label %bb19
bb18:
  br label %bb19
bb19:
  br label %bb20
bb20:
  %t97 = load i64, ptr %l9, !tbaa !24
  %t100 = add i64 %t97, 1
  store i64 %t100, ptr %l9, !tbaa !24
  br label %bb12
bb21:
  %t102 = load i64, ptr %l4, !tbaa !24
  %t104 = icmp eq i64 %t102, 0
  br i1 %t104, label %bb22, label %bb23
bb22:
  call void @__olang_scope_close(ptr %s0)
  store i64 0, ptr %rv
  br label %ret
bb23:
  br label %bb24
bb24:
  %t107 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t107, ptr %l88
  br label %bb25
bb25:
  %t108 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l88
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t108, ptr %l11
  %t109 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t109, ptr %l12, !tbaa !27
  store i64 0, ptr %l13, !tbaa !24
  %t111 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t113 = extractvalue { i64, ptr } %t111, 0
  store i64 %t113, ptr %l14, !tbaa !24
  br label %bb26
bb26:
  store %olang.scope zeroinitializer, ptr %s7
  %t115 = load i64, ptr %l13, !tbaa !24
  %t116 = load i64, ptr %l14, !tbaa !24
  %t119 = icmp slt i64 %t115, %t116
  %t121 = xor i1 %t119, true
  br i1 %t121, label %bb27, label %bb28
bb27:
  call void @__olang_scope_close(ptr %s7)
  br label %bb42
bb28:
  br label %bb29
bb29:
  %t123 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t123, ptr %l96, !tbaa !27
  %t124 = load i64, ptr %l13, !tbaa !24
  %t126 = getelementptr { i64, ptr }, ptr %l96, i32 0, i32 1
  %t127 = load ptr, ptr %t126, !tbaa !27
  %t128 = getelementptr i32, ptr %t127, i64 %t124
  %t129 = load i32, ptr %t128, !tbaa !33
  store i32 %t129, ptr %l15, !tbaa !23
  store ptr %l11, ptr %l99, !tbaa !29
  %t131 = load ptr, ptr %l2, !tbaa !29
  %t132 = load i32, ptr %l15, !tbaa !23
  %t135 = call i1 @compiler_2feffects_2eplainData(ptr %v0, ptr %t131, i32 %t132)
  store i1 %t135, ptr %l102
  br label %bb30
bb30:
  %t136 = load i1, ptr %l102, !tbaa !21
  br i1 %t136, label %bb31, label %bb32
bb31:
  %t137 = load ptr, ptr %l2, !tbaa !29
  %t138 = load i32, ptr %l15, !tbaa !23
  %t141 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eViaMemory(ptr %v0, ptr %t137, i32 %t138)
  store i1 %t141, ptr %l106
  br label %bb33
bb32:
  store i1 false, ptr %l103, !tbaa !21
  br label %bb34
bb33:
  %t142 = load i1, ptr %l106, !tbaa !21
  %t143 = xor i1 %t142, true
  store i1 %t143, ptr %l103, !tbaa !21
  br label %bb34
bb34:
  %t145 = load i1, ptr %l103, !tbaa !21
  br i1 %t145, label %bb35, label %bb36
bb35:
  %t146 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %s7)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t146, ptr %l109
  br label %bb37
bb36:
  %t147 = load ptr, ptr %l0, !tbaa !29
  %t148 = load i32, ptr %l15, !tbaa !23
  %t151 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ereach(ptr %v0, ptr %s7, ptr %t147, i32 %t148)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t151, ptr %l112
  br label %bb38
bb37:
  %t152 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l109
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t152, ptr %l108
  br label %bb39
bb38:
  %t153 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l112
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t153, ptr %l108
  br label %bb39
bb39:
  %t154 = load ptr, ptr %l99, !tbaa !29
  %t155 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l108
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fmap_3aMap_3cI64_2c_20B_H62acbf8f3c446e07109f0c23ca6f8756(ptr %s0, ptr %s7, ptr %t154, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t155)
  br label %bb40
bb40:
  call void @__olang_scope_close(ptr %s7)
  br label %bb41
bb41:
  %t156 = load i64, ptr %l13, !tbaa !24
  %t159 = add i64 %t156, 1
  store i64 %t159, ptr %l13, !tbaa !24
  br label %bb26
bb42:
  %t161 = load ptr, ptr %l2, !tbaa !29
  %t162 = load i32, ptr %l1, !tbaa !23
  %t165 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t161, i32 %t162)
  store i32 %t165, ptr %l118
  br label %bb43
bb43:
  %t166 = load i32, ptr %l118, !tbaa !23
  store i32 %t166, ptr %l16, !tbaa !23
  %t167 = load i32, ptr %l16, !tbaa !23
  %t168 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t171 = icmp ne i32 %t167, %t168
  br i1 %t171, label %bb44, label %bb45
bb44:
  %t173 = load i32, ptr %l16, !tbaa !23
  %t174 = load i32, ptr @G_2ecompiler_2ftypes_2eNoreturnT, !tbaa !23
  %t177 = icmp ne i32 %t173, %t174
  store i1 %t177, ptr %l122, !tbaa !21
  br label %bb46
bb45:
  store i1 false, ptr %l122, !tbaa !21
  br label %bb46
bb46:
  %t179 = load i1, ptr %l122, !tbaa !21
  br i1 %t179, label %bb47, label %bb48
bb47:
  %t180 = load ptr, ptr %l2, !tbaa !29
  %t181 = load i32, ptr %l16, !tbaa !23
  %t184 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eViaMemory(ptr %v0, ptr %t180, i32 %t181)
  store i1 %t184, ptr %l129
  br label %bb49
bb48:
  store i1 false, ptr %l126, !tbaa !21
  br label %bb50
bb49:
  %t185 = load i1, ptr %l129, !tbaa !21
  store i1 %t185, ptr %l126, !tbaa !21
  br label %bb50
bb50:
  %t186 = load i1, ptr %l126, !tbaa !21
  br i1 %t186, label %bb51, label %bb52
bb51:
  %t187 = load ptr, ptr %l0, !tbaa !29
  %t188 = load i32, ptr %l16, !tbaa !23
  %t191 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ereach(ptr %v0, ptr %s0, ptr %t187, i32 %t188)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t191, ptr %l133
  br label %bb53
bb52:
  %t192 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %s0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t192, ptr %l134
  br label %bb54
bb53:
  %t193 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l133
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t193, ptr %l130
  br label %bb55
bb54:
  %t194 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l134
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t194, ptr %l130
  br label %bb55
bb55:
  %t195 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l130
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t195, ptr %l17
  store i64 0, ptr %l18, !tbaa !24
  store i64 0, ptr %l19, !tbaa !24
  %t196 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t198 = extractvalue { i64, ptr } %t196, 0
  store i64 %t198, ptr %l20, !tbaa !24
  store i64 1, ptr %l21, !tbaa !24
  %t200 = load i64, ptr %l20, !tbaa !24
  %t201 = load i64, ptr %l19, !tbaa !24
  %t204 = icmp sgt i64 %t200, %t201
  br i1 %t204, label %bb56, label %bb57
bb56:
  %t206 = load i64, ptr %l21, !tbaa !24
  %t208 = icmp sgt i64 %t206, 0
  br i1 %t208, label %bb58, label %bb59
bb57:
  store i64 0, ptr %l140, !tbaa !24
  br label %bb61
bb58:
  %t210 = load i64, ptr %l20, !tbaa !24
  %t211 = load i64, ptr %l19, !tbaa !24
  %t214 = sub i64 %t210, %t211
  %t215 = load i64, ptr %l21, !tbaa !24
  %t218 = add i64 %t214, %t215
  %t220 = sub i64 %t218, 1
  %t221 = load i64, ptr %l21, !tbaa !24
  %t224 = sdiv i64 %t220, %t221
  store i64 %t224, ptr %l143, !tbaa !24
  br label %bb60
bb59:
  store i64 0, ptr %l143, !tbaa !24
  br label %bb60
bb60:
  %t226 = load i64, ptr %l143, !tbaa !24
  store i64 %t226, ptr %l140, !tbaa !24
  br label %bb61
bb61:
  %t227 = load i64, ptr %l140, !tbaa !24
  store i64 %t227, ptr %l22, !tbaa !24
  store i64 0, ptr %l23, !tbaa !24
  br label %bb62
bb62:
  store %olang.scope zeroinitializer, ptr %s10
  %t228 = load i64, ptr %l23, !tbaa !24
  %t229 = load i64, ptr %l22, !tbaa !24
  %t232 = icmp slt i64 %t228, %t229
  %t234 = xor i1 %t232, true
  br i1 %t234, label %bb63, label %bb64
bb63:
  call void @__olang_scope_close(ptr %s10)
  br label %bb110
bb64:
  br label %bb65
bb65:
  %t236 = load i64, ptr %l19, !tbaa !24
  %t237 = load i64, ptr %l23, !tbaa !24
  %t238 = load i64, ptr %l21, !tbaa !24
  %t241 = mul i64 %t237, %t238
  %t244 = add i64 %t236, %t241
  store i64 %t244, ptr %l24, !tbaa !24
  %t246 = load i64, ptr %l4, !tbaa !24
  %t247 = load i64, ptr %l24, !tbaa !24
  store i64 %t247, ptr %l162, !tbaa !24
  %t248 = load i64, ptr %l162, !tbaa !24
  %t249 = load i64, ptr %l162, !tbaa !24
  %t250 = shl i64 1, %t249
  %t253 = and i64 %t246, %t250
  %t255 = icmp eq i64 %t253, 0
  br i1 %t255, label %bb66, label %bb67
bb66:
  call void @__olang_scope_close(ptr %s10)
  br label %bb109
bb67:
  br label %bb68
bb68:
  %t257 = load ptr, ptr %l2, !tbaa !29
  store ptr %t257, ptr %l166, !tbaa !29
  %t258 = load ptr, ptr %l2, !tbaa !29
  %t259 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t259, ptr %l168, !tbaa !27
  %t260 = load i64, ptr %l24, !tbaa !24
  %t262 = getelementptr { i64, ptr }, ptr %l168, i32 0, i32 1
  %t263 = load ptr, ptr %t262, !tbaa !27
  %t264 = getelementptr i32, ptr %t263, i64 %t260
  %t265 = load i32, ptr %t264, !tbaa !33
  %t268 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t258, i32 %t265)
  store i32 %t268, ptr %l171
  br label %bb69
bb69:
  %t269 = load ptr, ptr %l166, !tbaa !29
  %t270 = load i32, ptr %l171, !tbaa !23
  %t271 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t269, i32 %t270)
  store i32 %t271, ptr %l172
  br label %bb70
bb70:
  %t272 = load i32, ptr %l172, !tbaa !23
  store i32 %t272, ptr %l25, !tbaa !23
  %t273 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %s10)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t273, ptr %l173
  br label %bb71
bb71:
  %t274 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l173
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t274, ptr %l26
  %t275 = load ptr, ptr %l2, !tbaa !29
  %t276 = load i32, ptr %l25, !tbaa !23
  %t280 = call i32 @compiler_2feffects_2eheldIn(ptr %v0, ptr %s10, ptr %t275, i32 %t276, ptr %l26, i64 0)
  store i32 %t280, ptr %l177
  %t281 = icmp ne i32 %t280, 0
  br i1 %t281, label %bb73, label %ok.282, !prof !99
ok.282:
  br label %bb72
bb72:
  br label %bb75
bb73:
  br label %bb74
bb74:
  call void @__olang_scope_close(ptr %s10)
  br label %bb109
bb75:
  %t283 = load ptr, ptr %l0, !tbaa !29
  %t284 = load i32, ptr %l25, !tbaa !23
  %t289 = call i1 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eoverlaps(ptr %v0, ptr %s10, ptr %s0, ptr %t283, i32 %t284, ptr %l26, ptr %l17)
  store i1 %t289, ptr %l182
  br label %bb76
bb76:
  %t290 = load i1, ptr %l182, !tbaa !21
  br i1 %t290, label %bb77, label %bb78
bb77:
  store i1 true, ptr %l183, !tbaa !21
  br label %bb83
bb78:
  %t291 = load ptr, ptr %l0, !tbaa !29
  store ptr %t291, ptr %l184, !tbaa !29
  %t292 = load i32, ptr %l25, !tbaa !23
  store i32 %t292, ptr %l185, !tbaa !23
  store ptr %l26, ptr %l186, !tbaa !29
  %t293 = call ptr @__olang_scope_hold(ptr %s10)
  %t294 = ptrtoint ptr %t293 to i64
  store i64 %t294, ptr %l187, !tbaa !24
  %t295 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMapKeyIter_3cI64_2c_20Bool_3e_2e0
  br i1 %t295, label %bb79, label %bb80
bb79:
  %t297 = call ptr @__olang_region_make(ptr %s10)
  %t298 = ptrtoint ptr %t297 to i64
  store i64 %t298, ptr %l187, !tbaa !24
  br label %bb80
bb80:
  %t299 = load ptr, ptr %l0, !tbaa !29
  %t300 = load i64, ptr %l187
  %t301 = inttoptr i64 %t300 to ptr
  %t304 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ereachBeyond(ptr %v0, ptr %s10, ptr %t301, ptr %t299, ptr %l26)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t304, ptr %l191
  br label %bb81
bb81:
  %t305 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l191
  %t306 = load i64, ptr %l187
  %t307 = inttoptr i64 %t306 to ptr
  %t308 = call ptr @__olang_scope_alloc_a(ptr %t307, i64 72, i64 8)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t305, ptr %t308
  %t309 = load ptr, ptr %l184, !tbaa !29
  %t310 = load i32, ptr %l185, !tbaa !23
  %t311 = load ptr, ptr %l186, !tbaa !29
  %t313 = call i1 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eoverlaps(ptr %v0, ptr %s10, ptr %s10, ptr %t309, i32 %t310, ptr %t311, ptr %t308)
  store i1 %t313, ptr %l193
  br label %bb82
bb82:
  %t314 = load i1, ptr %l193, !tbaa !21
  store i1 %t314, ptr %l183, !tbaa !21
  br label %bb83
bb83:
  %t315 = load i1, ptr %l183, !tbaa !21
  store i1 %t315, ptr %l27, !tbaa !21
  store i64 0, ptr %l28, !tbaa !24
  %t316 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t318 = extractvalue { i64, ptr } %t316, 0
  store i64 %t318, ptr %l29, !tbaa !24
  store i64 1, ptr %l30, !tbaa !24
  %t320 = load i64, ptr %l29, !tbaa !24
  %t321 = load i64, ptr %l28, !tbaa !24
  %t324 = icmp sgt i64 %t320, %t321
  br i1 %t324, label %bb84, label %bb85
bb84:
  %t326 = load i64, ptr %l30, !tbaa !24
  %t328 = icmp sgt i64 %t326, 0
  br i1 %t328, label %bb86, label %bb87
bb85:
  store i64 0, ptr %l199, !tbaa !24
  br label %bb89
bb86:
  %t330 = load i64, ptr %l29, !tbaa !24
  %t331 = load i64, ptr %l28, !tbaa !24
  %t334 = sub i64 %t330, %t331
  %t335 = load i64, ptr %l30, !tbaa !24
  %t338 = add i64 %t334, %t335
  %t340 = sub i64 %t338, 1
  %t341 = load i64, ptr %l30, !tbaa !24
  %t344 = sdiv i64 %t340, %t341
  store i64 %t344, ptr %l202, !tbaa !24
  br label %bb88
bb87:
  store i64 0, ptr %l202, !tbaa !24
  br label %bb88
bb88:
  %t346 = load i64, ptr %l202, !tbaa !24
  store i64 %t346, ptr %l199, !tbaa !24
  br label %bb89
bb89:
  %t347 = load i64, ptr %l199, !tbaa !24
  store i64 %t347, ptr %l31, !tbaa !24
  store i64 0, ptr %l32, !tbaa !24
  br label %bb90
bb90:
  %t348 = load i64, ptr %l32, !tbaa !24
  %t349 = load i64, ptr %l31, !tbaa !24
  %t352 = icmp slt i64 %t348, %t349
  %t354 = xor i1 %t352, true
  br i1 %t354, label %bb91, label %bb92
bb91:
  br label %bb105
bb92:
  br label %bb93
bb93:
  %t356 = load i64, ptr %l28, !tbaa !24
  %t357 = load i64, ptr %l32, !tbaa !24
  %t358 = load i64, ptr %l30, !tbaa !24
  %t361 = mul i64 %t357, %t358
  %t364 = add i64 %t356, %t361
  store i64 %t364, ptr %l33, !tbaa !24
  %t366 = load i64, ptr %l33, !tbaa !24
  %t367 = load i64, ptr %l24, !tbaa !24
  %t370 = icmp ne i64 %t366, %t367
  br i1 %t370, label %bb94, label %bb95
bb94:
  %t372 = load i1, ptr %l27, !tbaa !21
  %t374 = xor i1 %t372, true
  store i1 %t374, ptr %l223, !tbaa !21
  br label %bb96
bb95:
  store i1 false, ptr %l223, !tbaa !21
  br label %bb96
bb96:
  %t376 = load i1, ptr %l223, !tbaa !21
  br i1 %t376, label %bb97, label %bb98
bb97:
  store %olang.scope zeroinitializer, ptr %s15
  %t377 = load ptr, ptr %l0, !tbaa !29
  store ptr %t377, ptr %l226, !tbaa !29
  %t378 = load i32, ptr %l25, !tbaa !23
  store i32 %t378, ptr %l227, !tbaa !23
  store ptr %l26, ptr %l228, !tbaa !29
  %t379 = call ptr @__olang_scope_hold(ptr %s15)
  %t380 = ptrtoint ptr %t379 to i64
  store i64 %t380, ptr %l229, !tbaa !24
  %t381 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMapKeyIter_3cI64_2c_20Bool_3e_2e0
  br i1 %t381, label %bb99, label %bb100
bb98:
  br label %bb103
bb99:
  %t383 = call ptr @__olang_region_make(ptr %s15)
  %t384 = ptrtoint ptr %t383 to i64
  store i64 %t384, ptr %l229, !tbaa !24
  br label %bb100
bb100:
  %t385 = load i64, ptr %l33, !tbaa !24
  %t388 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fmap_3aMap_3cI64_2c_20B_Hbcd3253946b558e2d8e9e43f4596e7da(ptr %s0, ptr %s0, ptr %l11, i64 %t385)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t388, ptr %l233
  br label %bb101
bb101:
  %t389 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l233
  %t390 = load i64, ptr %l229
  %t391 = inttoptr i64 %t390 to ptr
  %t392 = call ptr @__olang_scope_alloc_a(ptr %t391, i64 72, i64 8)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t389, ptr %t392
  %t393 = load ptr, ptr %l226, !tbaa !29
  %t394 = load i32, ptr %l227, !tbaa !23
  %t395 = load ptr, ptr %l228, !tbaa !29
  %t397 = call i1 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eoverlaps(ptr %v0, ptr %s10, ptr %s15, ptr %t393, i32 %t394, ptr %t395, ptr %t392)
  store i1 %t397, ptr %l235
  br label %bb102
bb102:
  %t398 = load i1, ptr %l235, !tbaa !21
  store i1 %t398, ptr %l27, !tbaa !21
  call void @__olang_scope_close(ptr %s15)
  br label %bb103
bb103:
  br label %bb104
bb104:
  %t399 = load i64, ptr %l32, !tbaa !24
  %t402 = add i64 %t399, 1
  store i64 %t402, ptr %l32, !tbaa !24
  br label %bb90
bb105:
  %t404 = load i1, ptr %l27, !tbaa !21
  %t406 = xor i1 %t404, true
  br i1 %t406, label %bb106, label %bb107
bb106:
  %t408 = load i64, ptr %l18, !tbaa !24
  %t410 = load i64, ptr %l24, !tbaa !24
  store i64 %t410, ptr %l243, !tbaa !24
  %t411 = load i64, ptr %l243, !tbaa !24
  %t412 = load i64, ptr %l243, !tbaa !24
  %t413 = shl i64 1, %t412
  %t416 = or i64 %t408, %t413
  store i64 %t416, ptr %l18, !tbaa !24
  br label %bb108
bb107:
  br label %bb108
bb108:
  call void @__olang_scope_close(ptr %s10)
  br label %bb109
bb109:
  %t418 = load i64, ptr %l23, !tbaa !24
  %t421 = add i64 %t418, 1
  store i64 %t421, ptr %l23, !tbaa !24
  br label %bb62
bb110:
  %t423 = load i64, ptr %l18, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t423, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ethroughBounds(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/effects:Facts"
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca i64
  %l9 = alloca %"compiler/effects:Facts"
  %l11 = alloca i64
  %l13 = alloca i64
  %l18 = alloca i64
  %l21 = alloca i1
  %l22 = alloca ptr
  %l25 = alloca %"compiler/effects:Facts"
  %l31 = alloca i64
  %l33 = alloca i64
  %l38 = alloca i64
  %l42 = alloca ptr
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"compiler/effects:Facts" @compiler_2feffects_3aFacts_2ector(ptr %s0)
  store %"compiler/effects:Facts" %t1, ptr %l9
  br label %bb1
bb1:
  %t2 = load %"compiler/effects:Facts", ptr %l9
  store %"compiler/effects:Facts" %t2, ptr %l2
  %t3 = load ptr, ptr %l1, !tbaa !29
  store ptr %t3, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  %t5 = load i64, ptr %l4, !tbaa !24
  store i64 %t5, ptr %l11, !tbaa !24
  %t6 = load ptr, ptr %l3, !tbaa !29
  %t8 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t6)
  store i64 %t8, ptr %l13
  br label %bb3
bb3:
  %t9 = load i64, ptr %l11, !tbaa !24
  %t10 = load i64, ptr %l13, !tbaa !24
  %t11 = icmp slt i64 %t9, %t10
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb4, label %bb5
bb4:
  br label %bb15
bb5:
  br label %bb6
bb6:
  %t15 = load ptr, ptr %l3, !tbaa !29
  %t16 = load i64, ptr %l4, !tbaa !24
  %t19 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t15, i64 %t16)
  store i64 %t19, ptr %l18
  br label %bb7
bb7:
  %t20 = load i64, ptr %l18, !tbaa !24
  store i64 %t20, ptr %l5, !tbaa !24
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load i64, ptr %l5, !tbaa !24
  %t25 = call i1 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ecallsThrough(ptr %v0, ptr %t21, i64 %t22)
  store i1 %t25, ptr %l21
  br label %bb8
bb8:
  %t26 = load i1, ptr %l21, !tbaa !21
  br i1 %t26, label %bb9, label %bb10
bb9:
  store %olang.scope zeroinitializer, ptr %s3
  store ptr %l2, ptr %l22, !tbaa !29
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load i64, ptr %l5, !tbaa !24
  %t31 = call %"compiler/effects:Facts" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ebounds(ptr %v0, ptr %t27, i64 %t28)
  store %"compiler/effects:Facts" %t31, ptr %l25
  br label %bb11
bb10:
  br label %bb13
bb11:
  %t32 = load ptr, ptr %l22, !tbaa !29
  call void @compiler_2feffects_2eMerge(ptr %s0, ptr %s3, ptr %t32, ptr %l25)
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s3)
  br label %bb13
bb13:
  br label %bb14
bb14:
  %t34 = load i64, ptr %l4, !tbaa !24
  %t37 = add i64 %t34, 1
  store i64 %t37, ptr %l4, !tbaa !24
  br label %bb2
bb15:
  %t39 = load ptr, ptr %l1, !tbaa !29
  store ptr %t39, ptr %l6, !tbaa !29
  store i64 0, ptr %l7, !tbaa !24
  br label %bb16
bb16:
  %t41 = load i64, ptr %l7, !tbaa !24
  store i64 %t41, ptr %l31, !tbaa !24
  %t42 = load ptr, ptr %l6, !tbaa !29
  %t44 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t42)
  store i64 %t44, ptr %l33
  br label %bb17
bb17:
  %t45 = load i64, ptr %l31, !tbaa !24
  %t46 = load i64, ptr %l33, !tbaa !24
  %t47 = icmp slt i64 %t45, %t46
  %t49 = xor i1 %t47, true
  br i1 %t49, label %bb18, label %bb19
bb18:
  br label %bb25
bb19:
  br label %bb20
bb20:
  %t51 = load ptr, ptr %l6, !tbaa !29
  %t52 = load i64, ptr %l7, !tbaa !24
  %t55 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t51, i64 %t52)
  store i64 %t55, ptr %l38
  br label %bb21
bb21:
  %t56 = load i64, ptr %l38, !tbaa !24
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/effects:Effects", ptr %t57, i32 0, i32 11
  %t63 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3aFacts_3e_2eRefMut_3ccompiler_2feffects_3aFacts_3e(ptr %v0, ptr %v0, ptr %t59, i64 %t56)
  store ptr %t63, ptr %l42
  br label %bb22
bb22:
  %t64 = load ptr, ptr %l42, !tbaa !29
  call void @compiler_2feffects_2eMerge(ptr %v0, ptr %s0, ptr %t64, ptr %l2)
  br label %bb23
bb23:
  br label %bb24
bb24:
  %t66 = load i64, ptr %l7, !tbaa !24
  %t69 = add i64 %t66, 1
  store i64 %t69, ptr %l7, !tbaa !24
  br label %bb16
bb25:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eviewCall(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i64
  %l5 = alloca i64
  %l8 = alloca i1
  %l13 = alloca i1
  %l14 = alloca i1
  %l19 = alloca i1
  %l24 = alloca i64
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call i64 @compiler_2ftyped_2eCalleeBody(ptr %v1, ptr %a1)
  store i64 %t3, ptr %l5
  br label %bb1
bb1:
  %t4 = load i64, ptr %l5, !tbaa !24
  store i64 %t4, ptr %l3, !tbaa !24
  %t5 = load i64, ptr %l3, !tbaa !24
  %t7 = icmp slt i64 %t5, 0
  br i1 %t7, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb5
bb3:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/effects:Effects", ptr %t9, i32 0, i32 0
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t14 = getelementptr %"compiler/generic:Program", ptr %t12, i32 0, i32 2
  %t15 = load i32, ptr %l2, !tbaa !23
  %t18 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t14, i32 %t15)
  store i1 %t18, ptr %l13
  br label %bb4
bb4:
  %t19 = load i1, ptr %l13, !tbaa !21
  store i1 %t19, ptr %l8, !tbaa !21
  br label %bb5
bb5:
  %t20 = load i1, ptr %l8, !tbaa !21
  br i1 %t20, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l14, !tbaa !21
  br label %bb9
bb7:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/effects:Effects", ptr %t21, i32 0, i32 0
  %t24 = load ptr, ptr %t23, !tbaa !29
  %t26 = getelementptr %"compiler/generic:Program", ptr %t24, i32 0, i32 2
  %t27 = load i32, ptr %l2, !tbaa !23
  %t30 = call i1 @compiler_2ftyped_2eHoldsOwned(ptr %v0, ptr %t26, i32 %t27)
  store i1 %t30, ptr %l19
  br label %bb8
bb8:
  %t31 = load i1, ptr %l19, !tbaa !21
  %t32 = xor i1 %t31, true
  store i1 %t32, ptr %l14, !tbaa !21
  br label %bb9
bb9:
  %t34 = load i1, ptr %l14, !tbaa !21
  br i1 %t34, label %bb10, label %bb11
bb10:
  store i1 false, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t37 = load i64, ptr %l3, !tbaa !24
  %t40 = call i64 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eviewsOf(ptr %v0, ptr %t36, i64 %t37)
  store i64 %t40, ptr %l24
  br label %bb13
bb13:
  %t41 = load i64, ptr %l24, !tbaa !24
  %t42 = icmp sgt i64 %t41, 0
  store i1 %t42, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ewalkBody(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i32
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca ptr
  %l18 = alloca i64
  %l24 = alloca ptr
  %l25 = alloca ptr
  %l26 = alloca %"compiler/effects:Facts"
  %l27 = alloca ptr
  %l28 = alloca i64
  %l30 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l32 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l35 = alloca ptr
  %l36 = alloca i64
  %l38 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l40 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l43 = alloca ptr
  %l44 = alloca i64
  %l46 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l48 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l52 = alloca ptr
  %l53 = alloca i64
  %l55 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l57 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l62 = alloca i64
  %l68 = alloca i64
  %l74 = alloca i64
  %l80 = alloca i64
  %l86 = alloca i64
  %l92 = alloca i64
  %l100 = alloca i64
  %l106 = alloca i64
  %l111 = alloca ptr
  %l117 = alloca i32
  %l120 = alloca i1
  %l121 = alloca ptr
  %l127 = alloca i32
  %l128 = alloca i1
  %l129 = alloca ptr
  %l135 = alloca i32
  %l138 = alloca i1
  %l139 = alloca ptr
  %l145 = alloca i32
  %l146 = alloca i1
  %l149 = alloca i64
  %l155 = alloca i64
  %l161 = alloca i64
  %l167 = alloca i64
  %l171 = alloca ptr
  %l172 = alloca i64
  %l174 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l176 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l181 = alloca ptr
  %l182 = alloca i64
  %l184 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l186 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l193 = alloca i64
  %l197 = alloca i64
  %l200 = alloca i64
  %l219 = alloca ptr
  %l223 = alloca i32
  %l236 = alloca i64
  %l239 = alloca i64
  %l243 = alloca i64
  %l246 = alloca i64
  %l267 = alloca %"compiler/typed:Local"
  %l281 = alloca ptr
  %l282 = alloca i64
  %l284 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l286 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l293 = alloca i64
  %l295 = alloca i64
  %l300 = alloca i32
  %l308 = alloca ptr
  %l310 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l311 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l318 = alloca ptr
  %l319 = alloca i64
  %l324 = alloca i64
  %l325 = alloca i32
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/effects:Effects", ptr %t1, i32 0, i32 1
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t3, i64 %t4)
  store ptr %t7, ptr %l24
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l24, !tbaa !29
  store ptr %t8, ptr %l2, !tbaa !29
  %t9 = load ptr, ptr %l0, !tbaa !29
  store ptr %t9, ptr %l25, !tbaa !29
  %t10 = call %"compiler/effects:Facts" @compiler_2feffects_3aFacts_2ector(ptr %s0)
  store %"compiler/effects:Facts" %t10, ptr %l26
  br label %bb2
bb2:
  %t11 = load %"compiler/effects:Facts", ptr %l26
  %t12 = load ptr, ptr %l25, !tbaa !29
  %t13 = getelementptr %"compiler/effects:Effects", ptr %t12, i32 0, i32 25
  store %"compiler/effects:Facts" %t11, ptr %t13
  %t14 = load ptr, ptr %l0, !tbaa !29
  store ptr %t14, ptr %l27, !tbaa !29
  %t15 = call ptr @__olang_scope_hold(ptr %v0)
  %t16 = ptrtoint ptr %t15 to i64
  store i64 %t16, ptr %l28, !tbaa !24
  %t17 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e5
  br i1 %t17, label %bb3, label %bb4
bb3:
  %t19 = call ptr @__olang_region_make(ptr %v0)
  %t20 = ptrtoint ptr %t19 to i64
  store i64 %t20, ptr %l28, !tbaa !24
  br label %bb4
bb4:
  %t21 = load i64, ptr %l28
  %t22 = inttoptr i64 %t21 to ptr
  %t23 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3aGlobalAt_3e_2ector(ptr %t22, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t23, ptr %l30
  br label %bb5
bb5:
  %t24 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e5
  br i1 %t24, label %bb6, label %bb7
bb6:
  %t26 = load i64, ptr %l28
  %t27 = inttoptr i64 %t26 to ptr
  %t28 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l30, i32 0, i32 0
  %t29 = load { i64, ptr }, ptr %t28
  %t30 = extractvalue { i64, ptr } %t29, 1
  %t31 = call ptr @__olang_region_or(ptr %t30, ptr null)
  %t32 = call ptr @__olang_region_home(ptr %t31)
  %t33 = icmp ne ptr %t32, null
  %t34 = select i1 %t33, ptr %t32, ptr null
  call void @__olang_region_settle_in(ptr %t27, ptr %t34)
  br label %bb7
bb7:
  %t35 = load ptr, ptr %l27, !tbaa !29
  %t36 = getelementptr %"compiler/effects:Effects", ptr %t35, i32 0, i32 5
  %t37 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t36
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t37, ptr %l32
  %t38 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l30
  %t39 = load ptr, ptr %l27, !tbaa !29
  %t40 = getelementptr %"compiler/effects:Effects", ptr %t39, i32 0, i32 5
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t38, ptr %t40
  %t41 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e5
  br i1 %t41, label %bb8, label %bb9
bb8:
  %t43 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l32, i32 0, i32 0
  %t44 = load { i64, ptr }, ptr %t43
  %t45 = extractvalue { i64, ptr } %t44, 1
  %t46 = call ptr @__olang_region_or(ptr %t45, ptr null)
  %t47 = call ptr @__olang_region_home(ptr %t46)
  %t48 = icmp ne ptr %t47, null
  %t49 = select i1 %t48, ptr %t47, ptr null
  call void @__olang_region_drop(ptr %t49)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" zeroinitializer, ptr %l32
  br label %bb9
bb9:
  %t50 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3aGlobalAt_3e_2e0
  br i1 %t50, label %bb10, label %bb11
bb10:
  %t52 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l32, i32 0, i32 0
  %t53 = load { i64, ptr }, ptr %t52
  %t54 = extractvalue { i64, ptr } %t53, 0
  %t55 = extractvalue { i64, ptr } %t53, 1
  call void @__olang_region_release_part(ptr %t55, i64 %t54)
  store { i64, ptr } zeroinitializer, ptr %t52
  br label %bb11
bb11:
  %t56 = load ptr, ptr %l0, !tbaa !29
  store ptr %t56, ptr %l35, !tbaa !29
  %t57 = call ptr @__olang_scope_hold(ptr %v0)
  %t58 = ptrtoint ptr %t57 to i64
  store i64 %t58, ptr %l36, !tbaa !24
  %t59 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e26
  br i1 %t59, label %bb12, label %bb13
bb12:
  %t61 = call ptr @__olang_region_make(ptr %v0)
  %t62 = ptrtoint ptr %t61 to i64
  store i64 %t62, ptr %l36, !tbaa !24
  br label %bb13
bb13:
  %t63 = load i64, ptr %l36
  %t64 = inttoptr i64 %t63 to ptr
  %t65 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t64, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t65, ptr %l38
  br label %bb14
bb14:
  %t66 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e26
  br i1 %t66, label %bb15, label %bb16
bb15:
  %t68 = load i64, ptr %l36
  %t69 = inttoptr i64 %t68 to ptr
  %t70 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l38, i32 0, i32 0
  %t71 = load { i64, ptr }, ptr %t70
  %t72 = extractvalue { i64, ptr } %t71, 1
  %t73 = call ptr @__olang_region_or(ptr %t72, ptr null)
  %t74 = call ptr @__olang_region_home(ptr %t73)
  %t75 = icmp ne ptr %t74, null
  %t76 = select i1 %t75, ptr %t74, ptr null
  call void @__olang_region_settle_in(ptr %t69, ptr %t76)
  br label %bb16
bb16:
  %t77 = load ptr, ptr %l35, !tbaa !29
  %t78 = getelementptr %"compiler/effects:Effects", ptr %t77, i32 0, i32 26
  %t79 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t78
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t79, ptr %l40
  %t80 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l38
  %t81 = load ptr, ptr %l35, !tbaa !29
  %t82 = getelementptr %"compiler/effects:Effects", ptr %t81, i32 0, i32 26
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t80, ptr %t82
  %t83 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e26
  br i1 %t83, label %bb17, label %bb18
bb17:
  %t85 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l40, i32 0, i32 0
  %t86 = load { i64, ptr }, ptr %t85
  %t87 = extractvalue { i64, ptr } %t86, 1
  %t88 = call ptr @__olang_region_or(ptr %t87, ptr null)
  %t89 = call ptr @__olang_region_home(ptr %t88)
  %t90 = icmp ne ptr %t89, null
  %t91 = select i1 %t90, ptr %t89, ptr null
  call void @__olang_region_drop(ptr %t91)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" zeroinitializer, ptr %l40
  br label %bb18
bb18:
  %t92 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t92, label %bb19, label %bb20
bb19:
  %t94 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l40, i32 0, i32 0
  %t95 = load { i64, ptr }, ptr %t94
  %t96 = extractvalue { i64, ptr } %t95, 0
  %t97 = extractvalue { i64, ptr } %t95, 1
  call void @__olang_region_release_part(ptr %t97, i64 %t96)
  store { i64, ptr } zeroinitializer, ptr %t94
  br label %bb20
bb20:
  %t98 = load ptr, ptr %l0, !tbaa !29
  store ptr %t98, ptr %l43, !tbaa !29
  %t99 = call ptr @__olang_scope_hold(ptr %v0)
  %t100 = ptrtoint ptr %t99 to i64
  store i64 %t100, ptr %l44, !tbaa !24
  %t101 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e27
  br i1 %t101, label %bb21, label %bb22
bb21:
  %t103 = call ptr @__olang_region_make(ptr %v0)
  %t104 = ptrtoint ptr %t103 to i64
  store i64 %t104, ptr %l44, !tbaa !24
  br label %bb22
bb22:
  %t105 = load i64, ptr %l44
  %t106 = inttoptr i64 %t105 to ptr
  %t107 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t106, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t107, ptr %l46
  br label %bb23
bb23:
  %t108 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e27
  br i1 %t108, label %bb24, label %bb25
bb24:
  %t110 = load i64, ptr %l44
  %t111 = inttoptr i64 %t110 to ptr
  %t112 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l46, i32 0, i32 0
  %t113 = load { i64, ptr }, ptr %t112
  %t114 = extractvalue { i64, ptr } %t113, 1
  %t115 = call ptr @__olang_region_or(ptr %t114, ptr null)
  %t116 = call ptr @__olang_region_home(ptr %t115)
  %t117 = icmp ne ptr %t116, null
  %t118 = select i1 %t117, ptr %t116, ptr null
  call void @__olang_region_settle_in(ptr %t111, ptr %t118)
  br label %bb25
bb25:
  %t119 = load ptr, ptr %l43, !tbaa !29
  %t120 = getelementptr %"compiler/effects:Effects", ptr %t119, i32 0, i32 27
  %t121 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t120
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t121, ptr %l48
  %t122 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l46
  %t123 = load ptr, ptr %l43, !tbaa !29
  %t124 = getelementptr %"compiler/effects:Effects", ptr %t123, i32 0, i32 27
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t122, ptr %t124
  %t125 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e27
  br i1 %t125, label %bb26, label %bb27
bb26:
  %t127 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l48, i32 0, i32 0
  %t128 = load { i64, ptr }, ptr %t127
  %t129 = extractvalue { i64, ptr } %t128, 1
  %t130 = call ptr @__olang_region_or(ptr %t129, ptr null)
  %t131 = call ptr @__olang_region_home(ptr %t130)
  %t132 = icmp ne ptr %t131, null
  %t133 = select i1 %t132, ptr %t131, ptr null
  call void @__olang_region_drop(ptr %t133)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" zeroinitializer, ptr %l48
  br label %bb27
bb27:
  %t134 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t134, label %bb28, label %bb29
bb28:
  %t136 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l48, i32 0, i32 0
  %t137 = load { i64, ptr }, ptr %t136
  %t138 = extractvalue { i64, ptr } %t137, 0
  %t139 = extractvalue { i64, ptr } %t137, 1
  call void @__olang_region_release_part(ptr %t139, i64 %t138)
  store { i64, ptr } zeroinitializer, ptr %t136
  br label %bb29
bb29:
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t142 = getelementptr %"compiler/effects:Effects", ptr %t140, i32 0, i32 28
  store i64 0, ptr %t142, !tbaa !24
  %t143 = load ptr, ptr %l0, !tbaa !29
  store ptr %t143, ptr %l52, !tbaa !29
  %t144 = call ptr @__olang_scope_hold(ptr %v0)
  %t145 = ptrtoint ptr %t144 to i64
  store i64 %t145, ptr %l53, !tbaa !24
  %t146 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e29
  br i1 %t146, label %bb30, label %bb31
bb30:
  %t148 = call ptr @__olang_region_make(ptr %v0)
  %t149 = ptrtoint ptr %t148 to i64
  store i64 %t149, ptr %l53, !tbaa !24
  br label %bb31
bb31:
  %t150 = load i64, ptr %l53
  %t151 = inttoptr i64 %t150 to ptr
  %t152 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3alink_3e_2ector(ptr %t151, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t152, ptr %l55
  br label %bb32
bb32:
  %t153 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e29
  br i1 %t153, label %bb33, label %bb34
bb33:
  %t155 = load i64, ptr %l53
  %t156 = inttoptr i64 %t155 to ptr
  %t157 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l55, i32 0, i32 0
  %t158 = load { i64, ptr }, ptr %t157
  %t159 = extractvalue { i64, ptr } %t158, 1
  %t160 = call ptr @__olang_region_or(ptr %t159, ptr null)
  %t161 = call ptr @__olang_region_home(ptr %t160)
  %t162 = icmp ne ptr %t161, null
  %t163 = select i1 %t162, ptr %t161, ptr null
  call void @__olang_region_settle_in(ptr %t156, ptr %t163)
  br label %bb34
bb34:
  %t164 = load ptr, ptr %l52, !tbaa !29
  %t165 = getelementptr %"compiler/effects:Effects", ptr %t164, i32 0, i32 29
  %t166 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t165
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t166, ptr %l57
  %t167 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l55
  %t168 = load ptr, ptr %l52, !tbaa !29
  %t169 = getelementptr %"compiler/effects:Effects", ptr %t168, i32 0, i32 29
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t167, ptr %t169
  %t170 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e29
  br i1 %t170, label %bb35, label %bb36
bb35:
  %t172 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l57, i32 0, i32 0
  %t173 = load { i64, ptr }, ptr %t172
  %t174 = extractvalue { i64, ptr } %t173, 1
  %t175 = call ptr @__olang_region_or(ptr %t174, ptr null)
  %t176 = call ptr @__olang_region_home(ptr %t175)
  %t177 = icmp ne ptr %t176, null
  %t178 = select i1 %t177, ptr %t176, ptr null
  call void @__olang_region_drop(ptr %t178)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" zeroinitializer, ptr %l57
  br label %bb36
bb36:
  %t179 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3alink_3e_2e0
  br i1 %t179, label %bb37, label %bb38
bb37:
  %t181 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l57, i32 0, i32 0
  %t182 = load { i64, ptr }, ptr %t181
  %t183 = extractvalue { i64, ptr } %t182, 0
  %t184 = extractvalue { i64, ptr } %t182, 1
  call void @__olang_region_release_part(ptr %t184, i64 %t183)
  store { i64, ptr } zeroinitializer, ptr %t181
  br label %bb38
bb38:
  %t185 = load ptr, ptr %l0, !tbaa !29
  %t187 = getelementptr %"compiler/effects:Effects", ptr %t185, i32 0, i32 30
  %t189 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3agiven_3e_2eLen_3ccompiler_2feffects_3agiven_3e(ptr %v0, ptr %t187)
  store i64 %t189, ptr %l62
  br label %bb39
bb39:
  %t190 = load i64, ptr %l62, !tbaa !24
  %t191 = icmp sgt i64 %t190, 0
  br i1 %t191, label %bb40, label %bb41
bb40:
  %t193 = load ptr, ptr %l0, !tbaa !29
  %t195 = getelementptr %"compiler/effects:Effects", ptr %t193, i32 0, i32 30
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3agiven_3e_2eClear_3ccompiler_2feffects_3agiven_3e(ptr %v0, ptr %t195)
  br label %bb42
bb41:
  br label %bb43
bb42:
  br label %bb43
bb43:
  %t197 = load ptr, ptr %l0, !tbaa !29
  %t199 = getelementptr %"compiler/effects:Effects", ptr %t197, i32 0, i32 37
  %t201 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3apend_3e_2eLen_3ccompiler_2feffects_3apend_3e(ptr %v0, ptr %t199)
  store i64 %t201, ptr %l68
  br label %bb44
bb44:
  %t202 = load i64, ptr %l68, !tbaa !24
  %t203 = icmp sgt i64 %t202, 0
  br i1 %t203, label %bb45, label %bb46
bb45:
  %t205 = load ptr, ptr %l0, !tbaa !29
  %t207 = getelementptr %"compiler/effects:Effects", ptr %t205, i32 0, i32 37
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3apend_3e_2eClear_3ccompiler_2feffects_3apend_3e(ptr %v0, ptr %t207)
  br label %bb47
bb46:
  br label %bb48
bb47:
  br label %bb48
bb48:
  %t209 = load ptr, ptr %l0, !tbaa !29
  %t211 = getelementptr %"compiler/effects:Effects", ptr %t209, i32 0, i32 39
  %t213 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cc_H0398947fe830469ce1a64c5da7c2d54d(ptr %v0, ptr %t211)
  store i64 %t213, ptr %l74
  br label %bb49
bb49:
  %t214 = load i64, ptr %l74, !tbaa !24
  %t215 = icmp sgt i64 %t214, 0
  br i1 %t215, label %bb50, label %bb51
bb50:
  %t217 = load ptr, ptr %l0, !tbaa !29
  %t219 = getelementptr %"compiler/effects:Effects", ptr %t217, i32 0, i32 39
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cc_H4527323723b724269d0557de47b57e0e(ptr %v0, ptr %t219)
  br label %bb52
bb51:
  br label %bb53
bb52:
  br label %bb53
bb53:
  %t221 = load ptr, ptr %l0, !tbaa !29
  %t223 = getelementptr %"compiler/effects:Effects", ptr %t221, i32 0, i32 40
  %t225 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eLen_3cI64_2c_20Bool_3e(ptr %v0, ptr %t223)
  store i64 %t225, ptr %l80
  br label %bb54
bb54:
  %t226 = load i64, ptr %l80, !tbaa !24
  %t227 = icmp sgt i64 %t226, 0
  br i1 %t227, label %bb55, label %bb56
bb55:
  %t229 = load ptr, ptr %l0, !tbaa !29
  %t231 = getelementptr %"compiler/effects:Effects", ptr %t229, i32 0, i32 40
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eClear_3cI64_2c_20Bool_3e(ptr %v0, ptr %t231)
  br label %bb57
bb56:
  br label %bb58
bb57:
  br label %bb58
bb58:
  %t233 = load ptr, ptr %l0, !tbaa !29
  %t235 = getelementptr %"compiler/effects:Effects", ptr %t233, i32 0, i32 41
  %t237 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t235)
  store i64 %t237, ptr %l86
  br label %bb59
bb59:
  %t238 = load i64, ptr %l86, !tbaa !24
  %t239 = icmp sgt i64 %t238, 0
  br i1 %t239, label %bb60, label %bb61
bb60:
  %t241 = load ptr, ptr %l0, !tbaa !29
  %t243 = getelementptr %"compiler/effects:Effects", ptr %t241, i32 0, i32 41
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t243)
  br label %bb62
bb61:
  br label %bb63
bb62:
  br label %bb63
bb63:
  %t245 = load ptr, ptr %l0, !tbaa !29
  %t247 = getelementptr %"compiler/effects:Effects", ptr %t245, i32 0, i32 42
  %t249 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t247)
  store i64 %t249, ptr %l92
  br label %bb64
bb64:
  %t250 = load i64, ptr %l92, !tbaa !24
  %t251 = icmp sgt i64 %t250, 0
  br i1 %t251, label %bb65, label %bb66
bb65:
  %t253 = load ptr, ptr %l0, !tbaa !29
  %t255 = getelementptr %"compiler/effects:Effects", ptr %t253, i32 0, i32 42
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t255)
  br label %bb67
bb66:
  br label %bb68
bb67:
  br label %bb68
bb68:
  %t257 = load ptr, ptr %l0, !tbaa !29
  %t259 = getelementptr %"compiler/effects:Effects", ptr %t257, i32 0, i32 43
  store i1 false, ptr %t259, !tbaa !21
  %t260 = load ptr, ptr %l0, !tbaa !29
  %t262 = getelementptr %"compiler/effects:Effects", ptr %t260, i32 0, i32 44
  store i1 false, ptr %t262, !tbaa !21
  %t263 = load ptr, ptr %l0, !tbaa !29
  %t265 = getelementptr %"compiler/effects:Effects", ptr %t263, i32 0, i32 46
  %t267 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t265)
  store i64 %t267, ptr %l100
  br label %bb69
bb69:
  %t268 = load i64, ptr %l100, !tbaa !24
  %t269 = icmp sgt i64 %t268, 0
  br i1 %t269, label %bb70, label %bb71
bb70:
  %t271 = load ptr, ptr %l0, !tbaa !29
  %t273 = getelementptr %"compiler/effects:Effects", ptr %t271, i32 0, i32 46
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eClear_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t273)
  br label %bb72
bb71:
  br label %bb73
bb72:
  br label %bb73
bb73:
  %t275 = load ptr, ptr %l0, !tbaa !29
  %t277 = getelementptr %"compiler/effects:Effects", ptr %t275, i32 0, i32 47
  %t279 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t277)
  store i64 %t279, ptr %l106
  br label %bb74
bb74:
  %t280 = load i64, ptr %l106, !tbaa !24
  %t281 = icmp sgt i64 %t280, 0
  br i1 %t281, label %bb75, label %bb76
bb75:
  %t283 = load ptr, ptr %l0, !tbaa !29
  %t285 = getelementptr %"compiler/effects:Effects", ptr %t283, i32 0, i32 47
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t285)
  br label %bb77
bb76:
  br label %bb78
bb77:
  br label %bb78
bb78:
  %t287 = load ptr, ptr %l0, !tbaa !29
  %t289 = getelementptr %"compiler/effects:Effects", ptr %t287, i32 0, i32 48
  store i1 false, ptr %t289, !tbaa !21
  %t290 = load ptr, ptr %l0, !tbaa !29
  store ptr %t290, ptr %l111, !tbaa !29
  %t291 = load ptr, ptr %l0, !tbaa !29
  %t293 = getelementptr %"compiler/effects:Effects", ptr %t291, i32 0, i32 0
  %t294 = load ptr, ptr %t293, !tbaa !29
  %t296 = getelementptr %"compiler/generic:Program", ptr %t294, i32 0, i32 2
  %t297 = load ptr, ptr %l2, !tbaa !29
  %t299 = getelementptr %"compiler/typed:Body", ptr %t297, i32 0, i32 2
  %t300 = load i32, ptr %t299, !tbaa !23
  %t303 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t296, i32 %t300)
  store i32 %t303, ptr %l117
  br label %bb79
bb79:
  %t304 = load i32, ptr %l117, !range !{i32 0, i32 33}
  %t306 = trunc i64 21 to i32
  %t307 = icmp eq i32 %t304, %t306
  br i1 %t307, label %bb80, label %bb81
bb80:
  %t309 = load ptr, ptr %l0, !tbaa !29
  store ptr %t309, ptr %l121, !tbaa !29
  %t310 = load ptr, ptr %l0, !tbaa !29
  %t312 = getelementptr %"compiler/effects:Effects", ptr %t310, i32 0, i32 0
  %t313 = load ptr, ptr %t312, !tbaa !29
  %t315 = getelementptr %"compiler/generic:Program", ptr %t313, i32 0, i32 2
  %t316 = load ptr, ptr %l2, !tbaa !29
  %t318 = getelementptr %"compiler/typed:Body", ptr %t316, i32 0, i32 2
  %t319 = load i32, ptr %t318, !tbaa !23
  %t322 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t315, i32 %t319)
  store i32 %t322, ptr %l127
  br label %bb82
bb81:
  store i1 false, ptr %l120, !tbaa !21
  br label %bb84
bb82:
  %t323 = load ptr, ptr %l121, !tbaa !29
  %t324 = load i32, ptr %l127, !tbaa !23
  %t325 = call i1 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eisFn(ptr %v0, ptr %t323, i32 %t324)
  store i1 %t325, ptr %l128
  br label %bb83
bb83:
  %t326 = load i1, ptr %l128, !tbaa !21
  store i1 %t326, ptr %l120, !tbaa !21
  br label %bb84
bb84:
  %t327 = load i1, ptr %l120, !tbaa !21
  %t328 = load ptr, ptr %l111, !tbaa !29
  %t329 = getelementptr %"compiler/effects:Effects", ptr %t328, i32 0, i32 45
  store i1 %t327, ptr %t329, !tbaa !21
  %t330 = load ptr, ptr %l0, !tbaa !29
  store ptr %t330, ptr %l129, !tbaa !29
  %t331 = load ptr, ptr %l0, !tbaa !29
  %t333 = getelementptr %"compiler/effects:Effects", ptr %t331, i32 0, i32 0
  %t334 = load ptr, ptr %t333, !tbaa !29
  %t336 = getelementptr %"compiler/generic:Program", ptr %t334, i32 0, i32 2
  %t337 = load ptr, ptr %l2, !tbaa !29
  %t339 = getelementptr %"compiler/typed:Body", ptr %t337, i32 0, i32 2
  %t340 = load i32, ptr %t339, !tbaa !23
  %t343 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t336, i32 %t340)
  store i32 %t343, ptr %l135
  br label %bb85
bb85:
  %t344 = load i32, ptr %l135, !range !{i32 0, i32 33}
  %t346 = trunc i64 21 to i32
  %t347 = icmp eq i32 %t344, %t346
  br i1 %t347, label %bb86, label %bb87
bb86:
  %t349 = load ptr, ptr %l0, !tbaa !29
  store ptr %t349, ptr %l139, !tbaa !29
  %t350 = load ptr, ptr %l0, !tbaa !29
  %t352 = getelementptr %"compiler/effects:Effects", ptr %t350, i32 0, i32 0
  %t353 = load ptr, ptr %t352, !tbaa !29
  %t355 = getelementptr %"compiler/generic:Program", ptr %t353, i32 0, i32 2
  %t356 = load ptr, ptr %l2, !tbaa !29
  %t358 = getelementptr %"compiler/typed:Body", ptr %t356, i32 0, i32 2
  %t359 = load i32, ptr %t358, !tbaa !23
  %t362 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t355, i32 %t359)
  store i32 %t362, ptr %l145
  br label %bb88
bb87:
  store i1 false, ptr %l138, !tbaa !21
  br label %bb90
bb88:
  %t363 = load ptr, ptr %l139, !tbaa !29
  %t364 = load i32, ptr %l145, !tbaa !23
  %t365 = call i1 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2einstType(ptr %v0, ptr %t363, i32 %t364)
  store i1 %t365, ptr %l146
  br label %bb89
bb89:
  %t366 = load i1, ptr %l146, !tbaa !21
  store i1 %t366, ptr %l138, !tbaa !21
  br label %bb90
bb90:
  %t367 = load i1, ptr %l138, !tbaa !21
  %t368 = load ptr, ptr %l129, !tbaa !29
  %t369 = getelementptr %"compiler/effects:Effects", ptr %t368, i32 0, i32 69
  store i1 %t367, ptr %t369, !tbaa !21
  %t370 = load ptr, ptr %l0, !tbaa !29
  %t372 = getelementptr %"compiler/effects:Effects", ptr %t370, i32 0, i32 66
  %t374 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cc_H0398947fe830469ce1a64c5da7c2d54d(ptr %v0, ptr %t372)
  store i64 %t374, ptr %l149
  br label %bb91
bb91:
  %t375 = load i64, ptr %l149, !tbaa !24
  %t376 = icmp sgt i64 %t375, 0
  br i1 %t376, label %bb92, label %bb93
bb92:
  %t378 = load ptr, ptr %l0, !tbaa !29
  %t380 = getelementptr %"compiler/effects:Effects", ptr %t378, i32 0, i32 66
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cc_H4527323723b724269d0557de47b57e0e(ptr %v0, ptr %t380)
  br label %bb94
bb93:
  br label %bb95
bb94:
  br label %bb95
bb95:
  %t382 = load ptr, ptr %l0, !tbaa !29
  %t384 = getelementptr %"compiler/effects:Effects", ptr %t382, i32 0, i32 67
  %t386 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eLen_3cI64_2c_20Bool_3e(ptr %v0, ptr %t384)
  store i64 %t386, ptr %l155
  br label %bb96
bb96:
  %t387 = load i64, ptr %l155, !tbaa !24
  %t388 = icmp sgt i64 %t387, 0
  br i1 %t388, label %bb97, label %bb98
bb97:
  %t390 = load ptr, ptr %l0, !tbaa !29
  %t392 = getelementptr %"compiler/effects:Effects", ptr %t390, i32 0, i32 67
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eClear_3cI64_2c_20Bool_3e(ptr %v0, ptr %t392)
  br label %bb99
bb98:
  br label %bb100
bb99:
  br label %bb100
bb100:
  %t394 = load ptr, ptr %l0, !tbaa !29
  %t396 = getelementptr %"compiler/effects:Effects", ptr %t394, i32 0, i32 68
  %t398 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eLen_3cI64_2c_20I64_3e(ptr %v0, ptr %t396)
  store i64 %t398, ptr %l161
  br label %bb101
bb101:
  %t399 = load i64, ptr %l161, !tbaa !24
  %t400 = icmp sgt i64 %t399, 0
  br i1 %t400, label %bb102, label %bb103
bb102:
  %t402 = load ptr, ptr %l0, !tbaa !29
  %t404 = getelementptr %"compiler/effects:Effects", ptr %t402, i32 0, i32 68
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eClear_3cI64_2c_20I64_3e(ptr %v0, ptr %t404)
  br label %bb104
bb103:
  br label %bb105
bb104:
  br label %bb105
bb105:
  %t406 = load ptr, ptr %l0, !tbaa !29
  %t408 = getelementptr %"compiler/effects:Effects", ptr %t406, i32 0, i32 72
  %t410 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eLen_3cI64_2c_20Bool_3e(ptr %v0, ptr %t408)
  store i64 %t410, ptr %l167
  br label %bb106
bb106:
  %t411 = load i64, ptr %l167, !tbaa !24
  %t412 = icmp sgt i64 %t411, 0
  br i1 %t412, label %bb107, label %bb108
bb107:
  %t414 = load ptr, ptr %l0, !tbaa !29
  %t416 = getelementptr %"compiler/effects:Effects", ptr %t414, i32 0, i32 72
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eClear_3cI64_2c_20Bool_3e(ptr %v0, ptr %t416)
  br label %bb109
bb108:
  br label %bb110
bb109:
  br label %bb110
bb110:
  %t418 = load ptr, ptr %l0, !tbaa !29
  store ptr %t418, ptr %l171, !tbaa !29
  %t419 = call ptr @__olang_scope_hold(ptr %v0)
  %t420 = ptrtoint ptr %t419 to i64
  store i64 %t420, ptr %l172, !tbaa !24
  %t421 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e31
  br i1 %t421, label %bb111, label %bb112
bb111:
  %t423 = call ptr @__olang_region_make(ptr %v0)
  %t424 = ptrtoint ptr %t423 to i64
  store i64 %t424, ptr %l172, !tbaa !24
  br label %bb112
bb112:
  %t425 = load i64, ptr %l172
  %t426 = inttoptr i64 %t425 to ptr
  %t427 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ector(ptr %t426)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t427, ptr %l174
  br label %bb113
bb113:
  %t428 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e31
  br i1 %t428, label %bb114, label %bb115
bb114:
  %t430 = load i64, ptr %l172
  %t431 = inttoptr i64 %t430 to ptr
  %t432 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l174, i32 0, i32 2
  %t433 = load { i64, ptr }, ptr %t432
  %t434 = extractvalue { i64, ptr } %t433, 1
  %t435 = call ptr @__olang_region_or(ptr %t434, ptr null)
  %t436 = call ptr @__olang_region_home(ptr %t435)
  %t437 = icmp ne ptr %t436, null
  %t438 = select i1 %t437, ptr %t436, ptr null
  %t439 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l174, i32 0, i32 1
  %t440 = load { i64, ptr }, ptr %t439
  %t441 = extractvalue { i64, ptr } %t440, 1
  %t442 = call ptr @__olang_region_or(ptr %t441, ptr null)
  %t443 = call ptr @__olang_region_home(ptr %t442)
  %t444 = icmp ne ptr %t443, null
  %t445 = select i1 %t444, ptr %t443, ptr %t438
  %t446 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l174, i32 0, i32 0
  %t447 = load { i64, ptr }, ptr %t446
  %t448 = extractvalue { i64, ptr } %t447, 1
  %t449 = call ptr @__olang_region_or(ptr %t448, ptr null)
  %t450 = call ptr @__olang_region_home(ptr %t449)
  %t451 = icmp ne ptr %t450, null
  %t452 = select i1 %t451, ptr %t450, ptr %t445
  call void @__olang_region_settle_in(ptr %t431, ptr %t452)
  br label %bb115
bb115:
  %t453 = load ptr, ptr %l171, !tbaa !29
  %t454 = getelementptr %"compiler/effects:Effects", ptr %t453, i32 0, i32 31
  %t455 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t454
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t455, ptr %l176
  %t456 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l174
  %t457 = load ptr, ptr %l171, !tbaa !29
  %t458 = getelementptr %"compiler/effects:Effects", ptr %t457, i32 0, i32 31
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t456, ptr %t458
  %t459 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e31
  br i1 %t459, label %bb116, label %bb117
bb116:
  %t461 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l176, i32 0, i32 2
  %t462 = load { i64, ptr }, ptr %t461
  %t463 = extractvalue { i64, ptr } %t462, 1
  %t464 = call ptr @__olang_region_or(ptr %t463, ptr null)
  %t465 = call ptr @__olang_region_home(ptr %t464)
  %t466 = icmp ne ptr %t465, null
  %t467 = select i1 %t466, ptr %t465, ptr null
  %t468 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l176, i32 0, i32 1
  %t469 = load { i64, ptr }, ptr %t468
  %t470 = extractvalue { i64, ptr } %t469, 1
  %t471 = call ptr @__olang_region_or(ptr %t470, ptr null)
  %t472 = call ptr @__olang_region_home(ptr %t471)
  %t473 = icmp ne ptr %t472, null
  %t474 = select i1 %t473, ptr %t472, ptr %t467
  %t475 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l176, i32 0, i32 0
  %t476 = load { i64, ptr }, ptr %t475
  %t477 = extractvalue { i64, ptr } %t476, 1
  %t478 = call ptr @__olang_region_or(ptr %t477, ptr null)
  %t479 = call ptr @__olang_region_home(ptr %t478)
  %t480 = icmp ne ptr %t479, null
  %t481 = select i1 %t480, ptr %t479, ptr %t474
  call void @__olang_region_drop(ptr %t481)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" zeroinitializer, ptr %l176
  br label %bb117
bb117:
  %t482 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2e0
  br i1 %t482, label %bb118, label %bb119
bb118:
  %t484 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l176, i32 0, i32 0
  %t485 = load { i64, ptr }, ptr %t484
  %t486 = extractvalue { i64, ptr } %t485, 0
  %t487 = extractvalue { i64, ptr } %t485, 1
  call void @__olang_region_release_part(ptr %t487, i64 %t486)
  store { i64, ptr } zeroinitializer, ptr %t484
  br label %bb119
bb119:
  %t488 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2e1
  br i1 %t488, label %bb120, label %bb121
bb120:
  %t490 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l176, i32 0, i32 1
  %t491 = load { i64, ptr }, ptr %t490
  %t492 = extractvalue { i64, ptr } %t491, 0
  %t493 = extractvalue { i64, ptr } %t491, 1
  call void @__olang_region_release_part(ptr %t493, i64 %t492)
  store { i64, ptr } zeroinitializer, ptr %t490
  br label %bb121
bb121:
  %t494 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2e2
  br i1 %t494, label %bb122, label %bb123
bb122:
  %t496 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l176, i32 0, i32 2
  %t497 = load { i64, ptr }, ptr %t496
  %t498 = extractvalue { i64, ptr } %t497, 0
  %t499 = extractvalue { i64, ptr } %t497, 1
  call void @__olang_region_release_part(ptr %t499, i64 %t498)
  store { i64, ptr } zeroinitializer, ptr %t496
  br label %bb123
bb123:
  %t500 = load ptr, ptr %l0, !tbaa !29
  store ptr %t500, ptr %l181, !tbaa !29
  %t501 = call ptr @__olang_scope_hold(ptr %v0)
  %t502 = ptrtoint ptr %t501 to i64
  store i64 %t502, ptr %l182, !tbaa !24
  %t503 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e32
  br i1 %t503, label %bb124, label %bb125
bb124:
  %t505 = call ptr @__olang_region_make(ptr %v0)
  %t506 = ptrtoint ptr %t505 to i64
  store i64 %t506, ptr %l182, !tbaa !24
  br label %bb125
bb125:
  %t507 = load i64, ptr %l182
  %t508 = inttoptr i64 %t507 to ptr
  %t509 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ector(ptr %t508)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t509, ptr %l184
  br label %bb126
bb126:
  %t510 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e32
  br i1 %t510, label %bb127, label %bb128
bb127:
  %t512 = load i64, ptr %l182
  %t513 = inttoptr i64 %t512 to ptr
  %t514 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l184, i32 0, i32 2
  %t515 = load { i64, ptr }, ptr %t514
  %t516 = extractvalue { i64, ptr } %t515, 1
  %t517 = call ptr @__olang_region_or(ptr %t516, ptr null)
  %t518 = call ptr @__olang_region_home(ptr %t517)
  %t519 = icmp ne ptr %t518, null
  %t520 = select i1 %t519, ptr %t518, ptr null
  %t521 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l184, i32 0, i32 1
  %t522 = load { i64, ptr }, ptr %t521
  %t523 = extractvalue { i64, ptr } %t522, 1
  %t524 = call ptr @__olang_region_or(ptr %t523, ptr null)
  %t525 = call ptr @__olang_region_home(ptr %t524)
  %t526 = icmp ne ptr %t525, null
  %t527 = select i1 %t526, ptr %t525, ptr %t520
  %t528 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l184, i32 0, i32 0
  %t529 = load { i64, ptr }, ptr %t528
  %t530 = extractvalue { i64, ptr } %t529, 1
  %t531 = call ptr @__olang_region_or(ptr %t530, ptr null)
  %t532 = call ptr @__olang_region_home(ptr %t531)
  %t533 = icmp ne ptr %t532, null
  %t534 = select i1 %t533, ptr %t532, ptr %t527
  call void @__olang_region_settle_in(ptr %t513, ptr %t534)
  br label %bb128
bb128:
  %t535 = load ptr, ptr %l181, !tbaa !29
  %t536 = getelementptr %"compiler/effects:Effects", ptr %t535, i32 0, i32 32
  %t537 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t536
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t537, ptr %l186
  %t538 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l184
  %t539 = load ptr, ptr %l181, !tbaa !29
  %t540 = getelementptr %"compiler/effects:Effects", ptr %t539, i32 0, i32 32
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t538, ptr %t540
  %t541 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e32
  br i1 %t541, label %bb129, label %bb130
bb129:
  %t543 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l186, i32 0, i32 2
  %t544 = load { i64, ptr }, ptr %t543
  %t545 = extractvalue { i64, ptr } %t544, 1
  %t546 = call ptr @__olang_region_or(ptr %t545, ptr null)
  %t547 = call ptr @__olang_region_home(ptr %t546)
  %t548 = icmp ne ptr %t547, null
  %t549 = select i1 %t548, ptr %t547, ptr null
  %t550 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l186, i32 0, i32 1
  %t551 = load { i64, ptr }, ptr %t550
  %t552 = extractvalue { i64, ptr } %t551, 1
  %t553 = call ptr @__olang_region_or(ptr %t552, ptr null)
  %t554 = call ptr @__olang_region_home(ptr %t553)
  %t555 = icmp ne ptr %t554, null
  %t556 = select i1 %t555, ptr %t554, ptr %t549
  %t557 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l186, i32 0, i32 0
  %t558 = load { i64, ptr }, ptr %t557
  %t559 = extractvalue { i64, ptr } %t558, 1
  %t560 = call ptr @__olang_region_or(ptr %t559, ptr null)
  %t561 = call ptr @__olang_region_home(ptr %t560)
  %t562 = icmp ne ptr %t561, null
  %t563 = select i1 %t562, ptr %t561, ptr %t556
  call void @__olang_region_drop(ptr %t563)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" zeroinitializer, ptr %l186
  br label %bb130
bb130:
  %t564 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2e0
  br i1 %t564, label %bb131, label %bb132
bb131:
  %t566 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l186, i32 0, i32 0
  %t567 = load { i64, ptr }, ptr %t566
  %t568 = extractvalue { i64, ptr } %t567, 0
  %t569 = extractvalue { i64, ptr } %t567, 1
  call void @__olang_region_release_part(ptr %t569, i64 %t568)
  store { i64, ptr } zeroinitializer, ptr %t566
  br label %bb132
bb132:
  %t570 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2e1
  br i1 %t570, label %bb133, label %bb134
bb133:
  %t572 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l186, i32 0, i32 1
  %t573 = load { i64, ptr }, ptr %t572
  %t574 = extractvalue { i64, ptr } %t573, 0
  %t575 = extractvalue { i64, ptr } %t573, 1
  call void @__olang_region_release_part(ptr %t575, i64 %t574)
  store { i64, ptr } zeroinitializer, ptr %t572
  br label %bb134
bb134:
  %t576 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2e2
  br i1 %t576, label %bb135, label %bb136
bb135:
  %t578 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l186, i32 0, i32 2
  %t579 = load { i64, ptr }, ptr %t578
  %t580 = extractvalue { i64, ptr } %t579, 0
  %t581 = extractvalue { i64, ptr } %t579, 1
  call void @__olang_region_release_part(ptr %t581, i64 %t580)
  store { i64, ptr } zeroinitializer, ptr %t578
  br label %bb136
bb136:
  store i64 0, ptr %l3, !tbaa !24
  %t582 = load ptr, ptr %l2, !tbaa !29
  %t584 = getelementptr %"compiler/typed:Body", ptr %t582, i32 0, i32 5
  %t586 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t584)
  store i64 %t586, ptr %l193
  br label %bb137
bb137:
  %t587 = load i64, ptr %l193, !tbaa !24
  store i64 %t587, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t588 = load i64, ptr %l4, !tbaa !24
  %t589 = load i64, ptr %l3, !tbaa !24
  %t592 = icmp sgt i64 %t588, %t589
  br i1 %t592, label %bb138, label %bb139
bb138:
  %t594 = load i64, ptr %l5, !tbaa !24
  %t596 = icmp sgt i64 %t594, 0
  br i1 %t596, label %bb140, label %bb141
bb139:
  store i64 0, ptr %l197, !tbaa !24
  br label %bb143
bb140:
  %t598 = load i64, ptr %l4, !tbaa !24
  %t599 = load i64, ptr %l3, !tbaa !24
  %t602 = sub i64 %t598, %t599
  %t603 = load i64, ptr %l5, !tbaa !24
  %t606 = add i64 %t602, %t603
  %t608 = sub i64 %t606, 1
  %t609 = load i64, ptr %l5, !tbaa !24
  %t612 = sdiv i64 %t608, %t609
  store i64 %t612, ptr %l200, !tbaa !24
  br label %bb142
bb141:
  store i64 0, ptr %l200, !tbaa !24
  br label %bb142
bb142:
  %t614 = load i64, ptr %l200, !tbaa !24
  store i64 %t614, ptr %l197, !tbaa !24
  br label %bb143
bb143:
  %t615 = load i64, ptr %l197, !tbaa !24
  store i64 %t615, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb144
bb144:
  %t616 = load i64, ptr %l7, !tbaa !24
  %t617 = load i64, ptr %l6, !tbaa !24
  %t620 = icmp slt i64 %t616, %t617
  %t622 = xor i1 %t620, true
  br i1 %t622, label %bb145, label %bb146
bb145:
  br label %bb151
bb146:
  br label %bb147
bb147:
  %t624 = load i64, ptr %l3, !tbaa !24
  %t625 = load i64, ptr %l7, !tbaa !24
  %t626 = load i64, ptr %l5, !tbaa !24
  %t629 = mul i64 %t625, %t626
  %t632 = add i64 %t624, %t629
  store i64 %t632, ptr %l8, !tbaa !24
  %t634 = load ptr, ptr %l0, !tbaa !29
  %t636 = getelementptr %"compiler/effects:Effects", ptr %t634, i32 0, i32 31
  store ptr %t636, ptr %l219, !tbaa !29
  %t637 = load ptr, ptr %l2, !tbaa !29
  %t639 = getelementptr %"compiler/typed:Body", ptr %t637, i32 0, i32 5
  %t640 = load i64, ptr %l8, !tbaa !24
  %t643 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t639, i64 %t640)
  store i32 %t643, ptr %l223
  br label %bb148
bb148:
  %t644 = load i32, ptr %l223, !tbaa !23
  %t645 = sext i32 %t644 to i64
  %t646 = load i64, ptr %l8, !tbaa !24
  %t647 = load ptr, ptr %l219, !tbaa !29
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t647, i64 %t645, i64 %t646)
  br label %bb149
bb149:
  br label %bb150
bb150:
  %t650 = load i64, ptr %l7, !tbaa !24
  %t653 = add i64 %t650, 1
  store i64 %t653, ptr %l7, !tbaa !24
  br label %bb144
bb151:
  %t655 = load ptr, ptr %l2, !tbaa !29
  %t657 = getelementptr %"compiler/typed:Body", ptr %t655, i32 0, i32 1
  %t658 = load { i64, [2 x i64] }, ptr %t657
  %t660 = extractvalue { i64, [2 x i64] } %t658, 0
  %t661 = icmp eq i64 %t660, 4
  br i1 %t661, label %bb152, label %bb153
bb152:
  %t663 = load ptr, ptr %l2, !tbaa !29
  %t665 = getelementptr %"compiler/typed:Body", ptr %t663, i32 0, i32 1
  %t666 = getelementptr { i64, [2 x i64] }, ptr %t665, i32 0, i32 1
  %t667 = getelementptr { i32 }, ptr %t666, i32 0, i32 0
  %t668 = load i32, ptr %t667
  store i32 %t668, ptr %l9, !tbaa !23
  %t670 = load ptr, ptr %l2, !tbaa !29
  %t672 = getelementptr %"compiler/typed:Body", ptr %t670, i32 0, i32 5
  %t674 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t672)
  store i64 %t674, ptr %l236
  br label %bb154
bb153:
  br label %bb173
bb154:
  %t675 = load i64, ptr %l236, !tbaa !24
  store i64 %t675, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  %t676 = load ptr, ptr %l2, !tbaa !29
  %t678 = getelementptr %"compiler/typed:Body", ptr %t676, i32 0, i32 7
  %t680 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eLen_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t678)
  store i64 %t680, ptr %l239
  br label %bb155
bb155:
  %t681 = load i64, ptr %l239, !tbaa !24
  store i64 %t681, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t682 = load i64, ptr %l12, !tbaa !24
  %t683 = load i64, ptr %l11, !tbaa !24
  %t686 = icmp sgt i64 %t682, %t683
  br i1 %t686, label %bb156, label %bb157
bb156:
  %t688 = load i64, ptr %l13, !tbaa !24
  %t690 = icmp sgt i64 %t688, 0
  br i1 %t690, label %bb158, label %bb159
bb157:
  store i64 0, ptr %l243, !tbaa !24
  br label %bb161
bb158:
  %t692 = load i64, ptr %l12, !tbaa !24
  %t693 = load i64, ptr %l11, !tbaa !24
  %t696 = sub i64 %t692, %t693
  %t697 = load i64, ptr %l13, !tbaa !24
  %t700 = add i64 %t696, %t697
  %t702 = sub i64 %t700, 1
  %t703 = load i64, ptr %l13, !tbaa !24
  %t706 = sdiv i64 %t702, %t703
  store i64 %t706, ptr %l246, !tbaa !24
  br label %bb160
bb159:
  store i64 0, ptr %l246, !tbaa !24
  br label %bb160
bb160:
  %t708 = load i64, ptr %l246, !tbaa !24
  store i64 %t708, ptr %l243, !tbaa !24
  br label %bb161
bb161:
  %t709 = load i64, ptr %l243, !tbaa !24
  store i64 %t709, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb162
bb162:
  %t710 = load i64, ptr %l15, !tbaa !24
  %t711 = load i64, ptr %l14, !tbaa !24
  %t714 = icmp slt i64 %t710, %t711
  %t716 = xor i1 %t714, true
  br i1 %t716, label %bb163, label %bb164
bb163:
  br label %bb172
bb164:
  br label %bb165
bb165:
  %t718 = load i64, ptr %l11, !tbaa !24
  %t719 = load i64, ptr %l15, !tbaa !24
  %t720 = load i64, ptr %l13, !tbaa !24
  %t723 = mul i64 %t719, %t720
  %t726 = add i64 %t718, %t723
  store i64 %t726, ptr %l16, !tbaa !24
  %t728 = load ptr, ptr %l2, !tbaa !29
  %t730 = getelementptr %"compiler/typed:Body", ptr %t728, i32 0, i32 7
  %t731 = load i64, ptr %l16, !tbaa !24
  %t734 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t730, i64 %t731)
  store %"compiler/typed:Local" %t734, ptr %l267
  br label %bb166
bb166:
  %t735 = getelementptr %"compiler/typed:Local", ptr %l267, i32 0, i32 4
  %t736 = load i32, ptr %t735, !range !{i32 0, i32 7}
  %t738 = trunc i64 5 to i32
  %t739 = icmp eq i32 %t736, %t738
  %t741 = xor i1 %t739, true
  br i1 %t741, label %bb167, label %bb168
bb167:
  br label %bb171
bb168:
  br label %bb169
bb169:
  %t743 = load ptr, ptr %l0, !tbaa !29
  %t745 = getelementptr %"compiler/effects:Effects", ptr %t743, i32 0, i32 31
  %t746 = load i64, ptr %l16, !tbaa !24
  %t747 = load i64, ptr %l10, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t745, i64 %t746, i64 %t747)
  br label %bb170
bb170:
  %t751 = load i64, ptr %l10, !tbaa !24
  %t754 = add i64 %t751, 1
  store i64 %t754, ptr %l10, !tbaa !24
  br label %bb171
bb171:
  %t756 = load i64, ptr %l15, !tbaa !24
  %t759 = add i64 %t756, 1
  store i64 %t759, ptr %l15, !tbaa !24
  br label %bb162
bb172:
  br label %bb173
bb173:
  %t761 = load ptr, ptr %l0, !tbaa !29
  store ptr %t761, ptr %l281, !tbaa !29
  %t762 = call ptr @__olang_scope_hold(ptr %v0)
  %t763 = ptrtoint ptr %t762 to i64
  store i64 %t763, ptr %l282, !tbaa !24
  %t764 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e33
  br i1 %t764, label %bb174, label %bb175
bb174:
  %t766 = call ptr @__olang_region_make(ptr %v0)
  %t767 = ptrtoint ptr %t766 to i64
  store i64 %t767, ptr %l282, !tbaa !24
  br label %bb175
bb175:
  %t768 = load i64, ptr %l282
  %t769 = inttoptr i64 %t768 to ptr
  %t770 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %t769)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t770, ptr %l284
  br label %bb176
bb176:
  %t771 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e33
  br i1 %t771, label %bb177, label %bb178
bb177:
  %t773 = load i64, ptr %l282
  %t774 = inttoptr i64 %t773 to ptr
  %t775 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l284, i32 0, i32 2
  %t776 = load { i64, ptr }, ptr %t775
  %t777 = extractvalue { i64, ptr } %t776, 1
  %t778 = call ptr @__olang_region_or(ptr %t777, ptr null)
  %t779 = call ptr @__olang_region_home(ptr %t778)
  %t780 = icmp ne ptr %t779, null
  %t781 = select i1 %t780, ptr %t779, ptr null
  %t782 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l284, i32 0, i32 1
  %t783 = load { i64, ptr }, ptr %t782
  %t784 = extractvalue { i64, ptr } %t783, 1
  %t785 = call ptr @__olang_region_or(ptr %t784, ptr null)
  %t786 = call ptr @__olang_region_home(ptr %t785)
  %t787 = icmp ne ptr %t786, null
  %t788 = select i1 %t787, ptr %t786, ptr %t781
  %t789 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l284, i32 0, i32 0
  %t790 = load { i64, ptr }, ptr %t789
  %t791 = extractvalue { i64, ptr } %t790, 1
  %t792 = call ptr @__olang_region_or(ptr %t791, ptr null)
  %t793 = call ptr @__olang_region_home(ptr %t792)
  %t794 = icmp ne ptr %t793, null
  %t795 = select i1 %t794, ptr %t793, ptr %t788
  call void @__olang_region_settle_in(ptr %t774, ptr %t795)
  br label %bb178
bb178:
  %t796 = load ptr, ptr %l281, !tbaa !29
  %t797 = getelementptr %"compiler/effects:Effects", ptr %t796, i32 0, i32 33
  %t798 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t797
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t798, ptr %l286
  %t799 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l284
  %t800 = load ptr, ptr %l281, !tbaa !29
  %t801 = getelementptr %"compiler/effects:Effects", ptr %t800, i32 0, i32 33
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t799, ptr %t801
  %t802 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e33
  br i1 %t802, label %bb179, label %bb180
bb179:
  %t804 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l286, i32 0, i32 2
  %t805 = load { i64, ptr }, ptr %t804
  %t806 = extractvalue { i64, ptr } %t805, 1
  %t807 = call ptr @__olang_region_or(ptr %t806, ptr null)
  %t808 = call ptr @__olang_region_home(ptr %t807)
  %t809 = icmp ne ptr %t808, null
  %t810 = select i1 %t809, ptr %t808, ptr null
  %t811 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l286, i32 0, i32 1
  %t812 = load { i64, ptr }, ptr %t811
  %t813 = extractvalue { i64, ptr } %t812, 1
  %t814 = call ptr @__olang_region_or(ptr %t813, ptr null)
  %t815 = call ptr @__olang_region_home(ptr %t814)
  %t816 = icmp ne ptr %t815, null
  %t817 = select i1 %t816, ptr %t815, ptr %t810
  %t818 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l286, i32 0, i32 0
  %t819 = load { i64, ptr }, ptr %t818
  %t820 = extractvalue { i64, ptr } %t819, 1
  %t821 = call ptr @__olang_region_or(ptr %t820, ptr null)
  %t822 = call ptr @__olang_region_home(ptr %t821)
  %t823 = icmp ne ptr %t822, null
  %t824 = select i1 %t823, ptr %t822, ptr %t817
  call void @__olang_region_drop(ptr %t824)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" zeroinitializer, ptr %l286
  br label %bb180
bb180:
  %t825 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2e0
  br i1 %t825, label %bb181, label %bb182
bb181:
  %t827 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l286, i32 0, i32 0
  %t828 = load { i64, ptr }, ptr %t827
  %t829 = extractvalue { i64, ptr } %t828, 0
  %t830 = extractvalue { i64, ptr } %t828, 1
  call void @__olang_region_release_part(ptr %t830, i64 %t829)
  store { i64, ptr } zeroinitializer, ptr %t827
  br label %bb182
bb182:
  %t831 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2e1
  br i1 %t831, label %bb183, label %bb184
bb183:
  %t833 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l286, i32 0, i32 1
  %t834 = load { i64, ptr }, ptr %t833
  %t835 = extractvalue { i64, ptr } %t834, 0
  %t836 = extractvalue { i64, ptr } %t834, 1
  call void @__olang_region_release_part(ptr %t836, i64 %t835)
  store { i64, ptr } zeroinitializer, ptr %t833
  br label %bb184
bb184:
  %t837 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2e2
  br i1 %t837, label %bb185, label %bb186
bb185:
  %t839 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l286, i32 0, i32 2
  %t840 = load { i64, ptr }, ptr %t839
  %t841 = extractvalue { i64, ptr } %t840, 0
  %t842 = extractvalue { i64, ptr } %t840, 1
  call void @__olang_region_release_part(ptr %t842, i64 %t841)
  store { i64, ptr } zeroinitializer, ptr %t839
  br label %bb186
bb186:
  %t843 = load ptr, ptr %l2, !tbaa !29
  %t845 = getelementptr %"compiler/typed:Body", ptr %t843, i32 0, i32 19
  store ptr %t845, ptr %l17, !tbaa !29
  store i64 0, ptr %l18, !tbaa !24
  br label %bb187
bb187:
  %t847 = load i64, ptr %l18, !tbaa !24
  store i64 %t847, ptr %l293, !tbaa !24
  %t848 = load ptr, ptr %l17, !tbaa !29
  %t850 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2eLen_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %t848)
  store i64 %t850, ptr %l295
  br label %bb188
bb188:
  %t851 = load i64, ptr %l293, !tbaa !24
  %t852 = load i64, ptr %l295, !tbaa !24
  %t853 = icmp slt i64 %t851, %t852
  %t855 = xor i1 %t853, true
  br i1 %t855, label %bb189, label %bb190
bb189:
  br label %bb195
bb190:
  br label %bb191
bb191:
  %t857 = load ptr, ptr %l17, !tbaa !29
  %t858 = load i64, ptr %l18, !tbaa !24
  %t861 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2eAt_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %t857, i64 %t858)
  store i32 %t861, ptr %l300
  br label %bb192
bb192:
  %t862 = load i32, ptr %l300, !tbaa !23
  %t863 = load ptr, ptr %l0, !tbaa !29
  %t865 = getelementptr %"compiler/effects:Effects", ptr %t863, i32 0, i32 33
  %t868 = sext i32 %t862 to i64
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t865, i64 %t868, i1 true)
  br label %bb193
bb193:
  br label %bb194
bb194:
  %t871 = load i64, ptr %l18, !tbaa !24
  %t874 = add i64 %t871, 1
  store i64 %t874, ptr %l18, !tbaa !24
  br label %bb187
bb195:
  %t876 = load ptr, ptr %l0, !tbaa !29
  store ptr %t876, ptr %l308, !tbaa !29
  %t877 = load ptr, ptr %l2, !tbaa !29
  %t879 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @compiler_2ftyped_2eDropsRun(ptr %v0, ptr %v0, ptr %t877)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t879, ptr %l310
  br label %bb196
bb196:
  %t880 = load ptr, ptr %l308, !tbaa !29
  %t881 = getelementptr %"compiler/effects:Effects", ptr %t880, i32 0, i32 34
  %t882 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t881
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t882, ptr %l311
  %t883 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l310
  %t884 = load ptr, ptr %l308, !tbaa !29
  %t885 = getelementptr %"compiler/effects:Effects", ptr %t884, i32 0, i32 34
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t883, ptr %t885
  %t886 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e34
  br i1 %t886, label %bb197, label %bb198
bb197:
  %t888 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l311, i32 0, i32 2
  %t889 = load { i64, ptr }, ptr %t888
  %t890 = extractvalue { i64, ptr } %t889, 1
  %t891 = call ptr @__olang_region_or(ptr %t890, ptr null)
  %t892 = call ptr @__olang_region_home(ptr %t891)
  %t893 = icmp ne ptr %t892, null
  %t894 = select i1 %t893, ptr %t892, ptr null
  %t895 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l311, i32 0, i32 1
  %t896 = load { i64, ptr }, ptr %t895
  %t897 = extractvalue { i64, ptr } %t896, 1
  %t898 = call ptr @__olang_region_or(ptr %t897, ptr null)
  %t899 = call ptr @__olang_region_home(ptr %t898)
  %t900 = icmp ne ptr %t899, null
  %t901 = select i1 %t900, ptr %t899, ptr %t894
  %t902 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l311, i32 0, i32 0
  %t903 = load { i64, ptr }, ptr %t902
  %t904 = extractvalue { i64, ptr } %t903, 1
  %t905 = call ptr @__olang_region_or(ptr %t904, ptr null)
  %t906 = call ptr @__olang_region_home(ptr %t905)
  %t907 = icmp ne ptr %t906, null
  %t908 = select i1 %t907, ptr %t906, ptr %t901
  call void @__olang_region_drop(ptr %t908)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" zeroinitializer, ptr %l311
  br label %bb198
bb198:
  %t909 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2e0
  br i1 %t909, label %bb199, label %bb200
bb199:
  %t911 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l311, i32 0, i32 0
  %t912 = load { i64, ptr }, ptr %t911
  %t913 = extractvalue { i64, ptr } %t912, 0
  %t914 = extractvalue { i64, ptr } %t912, 1
  call void @__olang_region_release_part(ptr %t914, i64 %t913)
  store { i64, ptr } zeroinitializer, ptr %t911
  br label %bb200
bb200:
  %t915 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2e1
  br i1 %t915, label %bb201, label %bb202
bb201:
  %t917 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l311, i32 0, i32 1
  %t918 = load { i64, ptr }, ptr %t917
  %t919 = extractvalue { i64, ptr } %t918, 0
  %t920 = extractvalue { i64, ptr } %t918, 1
  call void @__olang_region_release_part(ptr %t920, i64 %t919)
  store { i64, ptr } zeroinitializer, ptr %t917
  br label %bb202
bb202:
  %t921 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2e2
  br i1 %t921, label %bb203, label %bb204
bb203:
  %t923 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l311, i32 0, i32 2
  %t924 = load { i64, ptr }, ptr %t923
  %t925 = extractvalue { i64, ptr } %t924, 0
  %t926 = extractvalue { i64, ptr } %t924, 1
  call void @__olang_region_release_part(ptr %t926, i64 %t925)
  store { i64, ptr } zeroinitializer, ptr %t923
  br label %bb204
bb204:
  %t927 = load ptr, ptr %l0, !tbaa !29
  %t928 = load i64, ptr %l1, !tbaa !24
  %t931 = getelementptr %"compiler/effects:Effects", ptr %t927, i32 0, i32 35
  store i64 %t928, ptr %t931, !tbaa !24
  %t932 = load ptr, ptr %l0, !tbaa !29
  store ptr %t932, ptr %l318, !tbaa !29
  %t933 = load ptr, ptr %l0, !tbaa !29
  %t935 = getelementptr %"compiler/effects:Effects", ptr %t933, i32 0, i32 18
  %t936 = load ptr, ptr %l2, !tbaa !29
  %t938 = getelementptr %"compiler/typed:Body", ptr %t936, i32 0, i32 3
  %t939 = load i64, ptr %t938, !tbaa !24
  %t942 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t935, i64 %t939)
  %t943 = extractvalue { i32, i64 } %t942, 1
  %t944 = extractvalue { i32, i64 } %t942, 0
  store i32 %t944, ptr %l325
  %t945 = icmp ne i32 %t944, 0
  br i1 %t945, label %bb206, label %ok.946, !prof !99
ok.946:
  store i64 %t943, ptr %l324
  br label %bb205
bb205:
  %t947 = load i64, ptr %l324, !tbaa !24
  store i64 %t947, ptr %l319, !tbaa !24
  br label %bb208
bb206:
  br label %bb207
bb207:
  store i64 -1, ptr %l319, !tbaa !24
  br label %bb208
bb208:
  %t948 = load i64, ptr %l319, !tbaa !24
  %t949 = load ptr, ptr %l318, !tbaa !29
  %t950 = getelementptr %"compiler/effects:Effects", ptr %t949, i32 0, i32 36
  store i64 %t948, ptr %t950, !tbaa !24
  %t951 = load ptr, ptr %l2, !tbaa !29
  %t953 = getelementptr %"compiler/typed:Body", ptr %t951, i32 0, i32 11
  %t954 = load ptr, ptr %t953, !tbaa !29
  %t956 = icmp eq ptr %t954, null
  br i1 %t956, label %bb209, label %bb210
bb209:
  %t958 = load ptr, ptr %l2, !tbaa !29
  %t960 = getelementptr %"compiler/typed:Body", ptr %t958, i32 0, i32 1
  %t961 = load { i64, [2 x i64] }, ptr %t960
  %t965 = extractvalue { i64, [2 x i64] } %t961, 0
  %t966 = icmp eq i64 %t965, 2
  br i1 %t966, label %bb211, label %bb212
bb210:
  %t968 = load ptr, ptr %l0, !tbaa !29
  %t969 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ekeptLocals(ptr %v0, ptr %v0, ptr %t968, ptr %t969)
  br label %bb220
bb211:
  br label %bb213
bb212:
  br label %bb214
bb213:
  br label %bb219
bb214:
  br i1 true, label %bb215, label %bb216
bb215:
  br label %bb217
bb216:
  br label %bb218
bb217:
  %t972 = load ptr, ptr %l0, !tbaa !29
  %t974 = getelementptr %"compiler/effects:Effects", ptr %t972, i32 0, i32 25
  %t975 = getelementptr %"compiler/effects:Facts", ptr %t974, i32 0, i32 16
  store i1 true, ptr %t975, !tbaa !21
  br label %bb219
bb218:
  call void @__olang_check_failed(ptr @olang_loc_1339f6fe14a38149_c7d1650dc39f436d)
  unreachable
bb219:
  br label %bb222
bb220:
  %t976 = load ptr, ptr %l0, !tbaa !29
  %t977 = load ptr, ptr %l2, !tbaa !29
  %t979 = getelementptr %"compiler/typed:Body", ptr %t977, i32 0, i32 11
  %t980 = load ptr, ptr %t979, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eblock(ptr %v0, ptr %v0, ptr %t976, ptr %t980)
  br label %bb221
bb221:
  br label %bb222
bb222:
  %t983 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2efinish(ptr %v0, ptr %t983)
  br label %bb223
bb223:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2feffects_2eheldIn(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i32
  %l14 = alloca i32
  %l20 = alloca i32
  %l23 = alloca ptr
  %l26 = alloca i32
  %l27 = alloca i32
  %l41 = alloca i32
  %l45 = alloca ptr
  %l48 = alloca i32
  %l49 = alloca i32
  %l55 = alloca i1
  %l59 = alloca i1
  %l62 = alloca i1
  %l69 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l3, !tbaa !24
  %t3 = icmp sgt i64 %t1, 64
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i32 65536, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load i32, ptr %l1, !tbaa !23
  %t8 = icmp eq i32 %t6, 0
  br i1 %t8, label %bb4, label %bb5
bb4:
  store i32 0, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = load i32, ptr %l1, !tbaa !23
  %t14 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t10, i32 %t11)
  store i32 %t14, ptr %l14
  br label %bb7
bb7:
  %t15 = load i32, ptr %l14, !tbaa !23
  store i32 %t15, ptr %l4, !tbaa !23
  %t16 = load ptr, ptr %l2, !tbaa !29
  %t17 = load i32, ptr %l4, !tbaa !23
  %t19 = sext i32 %t17 to i64
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v1, ptr %t16, i64 %t19, i1 true)
  br label %bb8
bb8:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = load i32, ptr %l4, !tbaa !23
  %t26 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t22, i32 %t23)
  store i32 %t26, ptr %l20
  br label %bb9
bb9:
  %t27 = load i32, ptr %l20, !range !{i32 0, i32 33}
  store i32 %t27, ptr %l5
  %t28 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t30 = trunc i64 20 to i32
  %t31 = icmp eq i32 %t28, %t30
  br i1 %t31, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb18
bb12:
  %t33 = load ptr, ptr %l0, !tbaa !29
  store ptr %t33, ptr %l23, !tbaa !29
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = load i32, ptr %l4, !tbaa !23
  %t38 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t34, i32 %t35)
  store i32 %t38, ptr %l26
  br label %bb13
bb13:
  %t39 = load ptr, ptr %l23, !tbaa !29
  %t40 = load i32, ptr %l26, !tbaa !23
  %t41 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t39, i32 %t40)
  store i32 %t41, ptr %l27
  br label %bb14
bb14:
  %t42 = load i32, ptr %l27, !range !{i32 0, i32 33}
  %t44 = trunc i64 29 to i32
  %t45 = icmp eq i32 %t42, %t44
  br i1 %t45, label %bb15, label %bb16
bb15:
  store i32 65536, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  br label %bb88
bb18:
  %t48 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t50 = trunc i64 19 to i32
  %t51 = icmp eq i32 %t48, %t50
  br i1 %t51, label %bb19, label %bb20
bb19:
  br label %bb25
bb20:
  %t53 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t55 = trunc i64 22 to i32
  %t56 = icmp eq i32 %t53, %t55
  br i1 %t56, label %bb21, label %bb22
bb21:
  br label %bb25
bb22:
  %t58 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t60 = trunc i64 23 to i32
  %t61 = icmp eq i32 %t58, %t60
  br i1 %t61, label %bb23, label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb29
bb25:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t64 = load i32, ptr %l4, !tbaa !23
  %t65 = load ptr, ptr %l2, !tbaa !29
  %t66 = load i64, ptr %l3, !tbaa !24
  %t71 = call i32 @compiler_2feffects_2eheldInParts(ptr %v0, ptr %v1, ptr %t63, i32 %t64, ptr %t65, i64 %t66)
  store i32 %t71, ptr %l41
  %t72 = icmp ne i32 %t71, 0
  br i1 %t72, label %bb27, label %ok.73, !prof !99
ok.73:
  br label %bb26
bb26:
  br label %bb28
bb27:
  %t74 = load i32, ptr %l41, !tbaa !23
  %t75 = lshr i32 %t74, 16
  %t76 = and i32 %t74, 65535
  %t77 = icmp eq i32 %t75, 1
  %t78 = select i1 %t77, i32 1, i32 0
  %t79 = icmp eq i32 %t74, 0
  %t80 = shl i32 %t78, 16
  %t81 = or i32 %t80, %t76
  %t82 = select i1 %t79, i32 0, i32 %t81
  store i32 %t82, ptr %rv
  br label %ret
bb28:
  br label %bb88
bb29:
  %t84 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t86 = trunc i64 18 to i32
  %t87 = icmp eq i32 %t84, %t86
  br i1 %t87, label %bb30, label %bb31
bb30:
  br label %bb32
bb31:
  br label %bb51
bb32:
  %t89 = load ptr, ptr %l0, !tbaa !29
  store ptr %t89, ptr %l45, !tbaa !29
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t91 = load i32, ptr %l4, !tbaa !23
  %t94 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t90, i32 %t91)
  store i32 %t94, ptr %l48
  br label %bb33
bb33:
  %t95 = load ptr, ptr %l45, !tbaa !29
  %t96 = load i32, ptr %l48, !tbaa !23
  %t97 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t95, i32 %t96)
  store i32 %t97, ptr %l49
  br label %bb34
bb34:
  %t98 = load i32, ptr %l49, !range !{i32 0, i32 6}
  store i32 %t98, ptr %l6
  %t99 = load i32, ptr %l6, !range !{i32 0, i32 6}
  %t101 = trunc i64 2 to i32
  %t102 = icmp eq i32 %t99, %t101
  br i1 %t102, label %bb35, label %bb36
bb35:
  store i32 0, ptr %rv
  br label %ret
bb36:
  br label %bb37
bb37:
  %t104 = load i32, ptr %l6, !range !{i32 0, i32 6}
  %t106 = trunc i64 0 to i32
  %t107 = icmp eq i32 %t104, %t106
  %t109 = xor i1 %t107, true
  br i1 %t109, label %bb38, label %bb39
bb38:
  %t111 = load i32, ptr %l6, !range !{i32 0, i32 6}
  %t113 = trunc i64 1 to i32
  %t114 = icmp eq i32 %t111, %t113
  %t116 = xor i1 %t114, true
  store i1 %t116, ptr %l55, !tbaa !21
  br label %bb40
bb39:
  store i1 false, ptr %l55, !tbaa !21
  br label %bb40
bb40:
  %t118 = load i1, ptr %l55, !tbaa !21
  br i1 %t118, label %bb41, label %bb42
bb41:
  store i1 true, ptr %l59, !tbaa !21
  br label %bb44
bb42:
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t120 = load i32, ptr %l4, !tbaa !23
  %t123 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %t119, i32 %t120)
  store i1 %t123, ptr %l62
  br label %bb43
bb43:
  %t124 = load i1, ptr %l62, !tbaa !21
  %t125 = xor i1 %t124, true
  store i1 %t125, ptr %l59, !tbaa !21
  br label %bb44
bb44:
  %t127 = load i1, ptr %l59, !tbaa !21
  br i1 %t127, label %bb45, label %bb46
bb45:
  store i32 65536, ptr %rv
  br label %ret
bb46:
  br label %bb47
bb47:
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t130 = load i32, ptr %l4, !tbaa !23
  %t131 = load ptr, ptr %l2, !tbaa !29
  %t132 = load i64, ptr %l3, !tbaa !24
  %t137 = call i32 @compiler_2feffects_2eheldInParts(ptr %v0, ptr %v1, ptr %t129, i32 %t130, ptr %t131, i64 %t132)
  store i32 %t137, ptr %l69
  %t138 = icmp ne i32 %t137, 0
  br i1 %t138, label %bb49, label %ok.139, !prof !99
ok.139:
  br label %bb48
bb48:
  br label %bb50
bb49:
  %t140 = load i32, ptr %l69, !tbaa !23
  %t141 = lshr i32 %t140, 16
  %t142 = and i32 %t140, 65535
  %t143 = icmp eq i32 %t141, 1
  %t144 = select i1 %t143, i32 1, i32 0
  %t145 = icmp eq i32 %t140, 0
  %t146 = shl i32 %t144, 16
  %t147 = or i32 %t146, %t142
  %t148 = select i1 %t145, i32 0, i32 %t147
  store i32 %t148, ptr %rv
  br label %ret
bb50:
  br label %bb88
bb51:
  %t150 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t152 = trunc i64 2 to i32
  %t153 = icmp eq i32 %t150, %t152
  br i1 %t153, label %bb52, label %bb53
bb52:
  br label %bb82
bb53:
  %t155 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t157 = trunc i64 3 to i32
  %t158 = icmp eq i32 %t155, %t157
  br i1 %t158, label %bb54, label %bb55
bb54:
  br label %bb82
bb55:
  %t160 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t162 = trunc i64 4 to i32
  %t163 = icmp eq i32 %t160, %t162
  br i1 %t163, label %bb56, label %bb57
bb56:
  br label %bb82
bb57:
  %t165 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t167 = trunc i64 5 to i32
  %t168 = icmp eq i32 %t165, %t167
  br i1 %t168, label %bb58, label %bb59
bb58:
  br label %bb82
bb59:
  %t170 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t172 = trunc i64 6 to i32
  %t173 = icmp eq i32 %t170, %t172
  br i1 %t173, label %bb60, label %bb61
bb60:
  br label %bb82
bb61:
  %t175 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t177 = trunc i64 7 to i32
  %t178 = icmp eq i32 %t175, %t177
  br i1 %t178, label %bb62, label %bb63
bb62:
  br label %bb82
bb63:
  %t180 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t182 = trunc i64 8 to i32
  %t183 = icmp eq i32 %t180, %t182
  br i1 %t183, label %bb64, label %bb65
bb64:
  br label %bb82
bb65:
  %t185 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t187 = trunc i64 9 to i32
  %t188 = icmp eq i32 %t185, %t187
  br i1 %t188, label %bb66, label %bb67
bb66:
  br label %bb82
bb67:
  %t190 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t192 = trunc i64 10 to i32
  %t193 = icmp eq i32 %t190, %t192
  br i1 %t193, label %bb68, label %bb69
bb68:
  br label %bb82
bb69:
  %t195 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t197 = trunc i64 11 to i32
  %t198 = icmp eq i32 %t195, %t197
  br i1 %t198, label %bb70, label %bb71
bb70:
  br label %bb82
bb71:
  %t200 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t202 = trunc i64 12 to i32
  %t203 = icmp eq i32 %t200, %t202
  br i1 %t203, label %bb72, label %bb73
bb72:
  br label %bb82
bb73:
  %t205 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t207 = trunc i64 13 to i32
  %t208 = icmp eq i32 %t205, %t207
  br i1 %t208, label %bb74, label %bb75
bb74:
  br label %bb82
bb75:
  %t210 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t212 = trunc i64 14 to i32
  %t213 = icmp eq i32 %t210, %t212
  br i1 %t213, label %bb76, label %bb77
bb76:
  br label %bb82
bb77:
  %t215 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t217 = trunc i64 31 to i32
  %t218 = icmp eq i32 %t215, %t217
  br i1 %t218, label %bb78, label %bb79
bb78:
  br label %bb82
bb79:
  %t220 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t222 = trunc i64 1 to i32
  %t223 = icmp eq i32 %t220, %t222
  br i1 %t223, label %bb80, label %bb81
bb80:
  br label %bb82
bb81:
  br label %bb83
bb82:
  br label %bb88
bb83:
  br i1 true, label %bb84, label %bb85
bb84:
  br label %bb86
bb85:
  br label %bb87
bb86:
  store i32 65536, ptr %rv
  br label %ret
bb87:
  call void @__olang_check_failed(ptr @olang_loc_5c824f1279c93c35_a4567916a622c1e9)
  unreachable
bb88:
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2feffects_2eheldInAll(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, ptr %a2, i64 %a3) #0 {
entry:
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l15 = alloca { i64, ptr }
  %l23 = alloca i32
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a1, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l6, !tbaa !24
  br label %bb1
bb1:
  %t7 = load i64, ptr %l5, !tbaa !24
  %t8 = load i64, ptr %l6, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  br label %bb9
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t15, ptr %l15, !tbaa !27
  %t16 = load i64, ptr %l5, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr i32, ptr %t19, i64 %t16
  %t21 = load i32, ptr %t20, !tbaa !33
  %t28 = add i64 %a3, 1
  %t33 = call i32 @compiler_2feffects_2eheldIn(ptr %v0, ptr %v2, ptr %a0, i32 %t21, ptr %a2, i64 %t28)
  store i32 %t33, ptr %l23
  %t34 = icmp ne i32 %t33, 0
  br i1 %t34, label %bb6, label %ok.35, !prof !99
ok.35:
  br label %bb5
bb5:
  br label %bb7
bb6:
  %t36 = load i32, ptr %l23, !tbaa !23
  %t37 = lshr i32 %t36, 16
  %t38 = and i32 %t36, 65535
  %t39 = icmp eq i32 %t37, 1
  %t40 = select i1 %t39, i32 1, i32 0
  %t41 = icmp eq i32 %t36, 0
  %t42 = shl i32 %t40, 16
  %t43 = or i32 %t42, %t38
  %t44 = select i1 %t41, i32 0, i32 %t43
  store i32 %t44, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t46 = load i64, ptr %l5, !tbaa !24
  %t49 = add i64 %t46, 1
  store i64 %t49, ptr %l5, !tbaa !24
  br label %bb1
bb9:
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2feffects_2eheldInParts(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca { i32, i32 }
  %l5 = alloca i32
  %l9 = alloca { i32, i32 }
  %l17 = alloca i32
  %l19 = alloca ptr
  %l22 = alloca { i64, ptr }
  %l25 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store ptr %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call { i32, i32 } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHeldParts(ptr %v0, ptr %t1, i32 %a1)
  store { i32, i32 } %t5, ptr %l9
  br label %bb1
bb1:
  %t6 = load { i32, i32 }, ptr %l9
  store { i32, i32 } %t6, ptr %l4
  %t7 = getelementptr { i32, i32 }, ptr %l4, i32 0, i32 0
  %t8 = load i32, ptr %t7, !tbaa !23
  store i32 %t8, ptr %l5, !tbaa !23
  %t10 = getelementptr { i32, i32 }, ptr %l4, i32 0, i32 1
  %t11 = load i32, ptr %t10, !tbaa !23
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = load ptr, ptr %l2, !tbaa !29
  %t16 = load i64, ptr %l3, !tbaa !24
  %t18 = add i64 %t16, 1
  %t23 = call i32 @compiler_2feffects_2eheldIn(ptr %v0, ptr %v1, ptr %t13, i32 %t11, ptr %t15, i64 %t18)
  store i32 %t23, ptr %l17
  %t24 = icmp ne i32 %t23, 0
  br i1 %t24, label %bb3, label %ok.25, !prof !99
ok.25:
  br label %bb2
bb2:
  br label %bb4
bb3:
  %t26 = load i32, ptr %l17, !tbaa !23
  %t27 = lshr i32 %t26, 16
  %t28 = and i32 %t26, 65535
  %t29 = icmp eq i32 %t27, 1
  %t30 = select i1 %t29, i32 1, i32 0
  %t31 = icmp eq i32 %t26, 0
  %t32 = shl i32 %t30, 16
  %t33 = or i32 %t32, %t28
  %t34 = select i1 %t31, i32 0, i32 %t33
  store i32 %t34, ptr %rv
  br label %ret
bb4:
  %t36 = load ptr, ptr %l0, !tbaa !29
  store ptr %t36, ptr %l19, !tbaa !29
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load i32, ptr %l5, !tbaa !23
  %t41 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t37, i32 %t38)
  store { i64, ptr } %t41, ptr %l22
  br label %bb5
bb5:
  %t42 = load ptr, ptr %l2, !tbaa !29
  %t43 = load i64, ptr %l3, !tbaa !24
  %t44 = load ptr, ptr %l19, !tbaa !29
  %t45 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t48 = call i32 @compiler_2feffects_2eheldInAll(ptr %v0, ptr %v0, ptr %v1, ptr %t44, { i64, ptr } %t45, ptr %t42, i64 %t43)
  store i32 %t48, ptr %l25
  %t49 = icmp ne i32 %t48, 0
  br i1 %t49, label %bb7, label %ok.50, !prof !99
ok.50:
  br label %bb6
bb6:
  br label %bb8
bb7:
  %t51 = load i32, ptr %l25, !tbaa !23
  %t52 = lshr i32 %t51, 16
  %t53 = and i32 %t51, 65535
  %t54 = icmp eq i32 %t52, 1
  %t55 = select i1 %t54, i32 1, i32 0
  %t56 = icmp eq i32 %t51, 0
  %t57 = shl i32 %t55, 16
  %t58 = or i32 %t57, %t53
  %t59 = select i1 %t56, i32 0, i32 %t58
  store i32 %t59, ptr %rv
  br label %ret
bb8:
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2feffects_2eimpure(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i1
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca { i64, ptr }
  %l24 = alloca i1
  %l27 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  %l29 = alloca i64
  %l30 = alloca { i64, ptr }
  %l33 = alloca i1
  %l40 = alloca { i64, ptr }
  %l41 = alloca { i64, ptr }
  %l42 = alloca i64
  %l43 = alloca { i64, ptr }
  %l44 = alloca { i64, ptr }
  %l45 = alloca { i64, ptr }
  %l46 = alloca i64
  %l47 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/effects:Facts", ptr %t1, i32 0, i32 12
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l3, !tbaa !21
  br label %bb3
bb2:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/effects:Facts", ptr %t6, i32 0, i32 13
  %t9 = load i1, ptr %t8, !tbaa !21
  store i1 %t9, ptr %l3, !tbaa !21
  br label %bb3
bb3:
  %t11 = load i1, ptr %l3, !tbaa !21
  br i1 %t11, label %bb4, label %bb5
bb4:
  store { i64, ptr } { i64 64, ptr getelementptr inbounds (<{ i64, [64 x i8] }>, ptr @.d20, i32 0, i32 1) }, ptr %l6, !tbaa !27
  %t12 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t12, ptr %l7, !tbaa !27
  %t13 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t14 = extractvalue { i64, ptr } %t13, 0
  store i64 %t14, ptr %l8, !tbaa !24
  %t15 = load i64, ptr %l8, !tbaa !24
  %t16 = mul i64 %t15, 1
  %t17 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t16)
  %t18 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  store { i64, ptr } %t19, ptr %l9, !tbaa !27
  %t20 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !27
  %t24 = load i64, ptr %l8, !tbaa !24
  %t25 = mul i64 %t24, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t21, ptr %t23, i64 %t25, i1 false)
  %t26 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t26, ptr %l7, !tbaa !27
  %t27 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t27, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/effects:Facts", ptr %t28, i32 0, i32 3
  %t31 = load i1, ptr %t30, !tbaa !21
  br i1 %t31, label %bb7, label %bb8
bb7:
  store { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d21, i32 0, i32 1) }, ptr %l12, !tbaa !27
  %t33 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t33, ptr %l13, !tbaa !27
  %t34 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t35 = extractvalue { i64, ptr } %t34, 0
  store i64 %t35, ptr %l14, !tbaa !24
  %t36 = load i64, ptr %l14, !tbaa !24
  %t37 = mul i64 %t36, 1
  %t38 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t37)
  %t39 = insertvalue { i64, ptr } undef, i64 %t36, 0
  %t40 = insertvalue { i64, ptr } %t39, ptr %t38, 1
  store { i64, ptr } %t40, ptr %l15, !tbaa !27
  %t41 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !27
  %t43 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !27
  %t45 = load i64, ptr %l14, !tbaa !24
  %t46 = mul i64 %t45, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t42, ptr %t44, i64 %t46, i1 false)
  %t47 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t47, ptr %l13, !tbaa !27
  %t48 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t48, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/effects:Facts", ptr %t49, i32 0, i32 4
  %t52 = load i1, ptr %t51, !tbaa !21
  br i1 %t52, label %bb10, label %bb11
bb10:
  store { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d22, i32 0, i32 1) }, ptr %l18, !tbaa !27
  %t54 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t54, ptr %l19, !tbaa !27
  %t55 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t56 = extractvalue { i64, ptr } %t55, 0
  store i64 %t56, ptr %l20, !tbaa !24
  %t57 = load i64, ptr %l20, !tbaa !24
  %t58 = mul i64 %t57, 1
  %t59 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t58)
  %t60 = insertvalue { i64, ptr } undef, i64 %t57, 0
  %t61 = insertvalue { i64, ptr } %t60, ptr %t59, 1
  store { i64, ptr } %t61, ptr %l21, !tbaa !27
  %t62 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !27
  %t64 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t65 = load ptr, ptr %t64, !tbaa !27
  %t66 = load i64, ptr %l20, !tbaa !24
  %t67 = mul i64 %t66, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t63, ptr %t65, i64 %t67, i1 false)
  %t68 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t68, ptr %l19, !tbaa !27
  %t69 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t69, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/effects:Facts", ptr %t70, i32 0, i32 20
  %t73 = load i1, ptr %t72, !tbaa !21
  br i1 %t73, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l24, !tbaa !21
  br label %bb15
bb14:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = getelementptr %"compiler/effects:Facts", ptr %t75, i32 0, i32 19
  %t78 = load i1, ptr %t77, !tbaa !21
  store i1 %t78, ptr %l24, !tbaa !21
  br label %bb15
bb15:
  %t80 = load i1, ptr %l24, !tbaa !21
  br i1 %t80, label %bb16, label %bb17
bb16:
  store { i64, ptr } { i64 44, ptr getelementptr inbounds (<{ i64, [44 x i8] }>, ptr @.d23, i32 0, i32 1) }, ptr %l27, !tbaa !27
  %t81 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t81, ptr %l28, !tbaa !27
  %t82 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t83 = extractvalue { i64, ptr } %t82, 0
  store i64 %t83, ptr %l29, !tbaa !24
  %t84 = load i64, ptr %l29, !tbaa !24
  %t85 = mul i64 %t84, 1
  %t86 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t85)
  %t87 = insertvalue { i64, ptr } undef, i64 %t84, 0
  %t88 = insertvalue { i64, ptr } %t87, ptr %t86, 1
  store { i64, ptr } %t88, ptr %l30, !tbaa !27
  %t89 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t90 = load ptr, ptr %t89, !tbaa !27
  %t91 = getelementptr { i64, ptr }, ptr %l28, i32 0, i32 1
  %t92 = load ptr, ptr %t91, !tbaa !27
  %t93 = load i64, ptr %l29, !tbaa !24
  %t94 = mul i64 %t93, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t90, ptr %t92, i64 %t94, i1 false)
  %t95 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t95, ptr %l28, !tbaa !27
  %t96 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t96, ptr %rv
  br label %ret
bb17:
  br label %bb18
bb18:
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = getelementptr %"compiler/effects:Facts", ptr %t97, i32 0, i32 7
  %t100 = load i1, ptr %t99, !tbaa !21
  br i1 %t100, label %bb19, label %bb20
bb19:
  store i1 true, ptr %l33, !tbaa !21
  br label %bb21
bb20:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = getelementptr %"compiler/effects:Facts", ptr %t102, i32 0, i32 21
  %t105 = load i64, ptr %t104, !tbaa !24
  %t106 = load i64, ptr @G_2ecompiler_2feffects_2eCapThreads, !tbaa !24
  %t108 = xor i64 %t106, -1
  %t111 = and i64 %t105, %t108
  %t113 = icmp ne i64 %t111, 0
  store i1 %t113, ptr %l33, !tbaa !21
  br label %bb21
bb21:
  %t115 = load i1, ptr %l33, !tbaa !21
  br i1 %t115, label %bb22, label %bb23
bb22:
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d24, i32 0, i32 1) }, ptr %l40, !tbaa !27
  %t116 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t116, ptr %l41, !tbaa !27
  %t117 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t118 = extractvalue { i64, ptr } %t117, 0
  store i64 %t118, ptr %l42, !tbaa !24
  %t119 = load i64, ptr %l42, !tbaa !24
  %t120 = mul i64 %t119, 1
  %t121 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t120)
  %t122 = insertvalue { i64, ptr } undef, i64 %t119, 0
  %t123 = insertvalue { i64, ptr } %t122, ptr %t121, 1
  store { i64, ptr } %t123, ptr %l43, !tbaa !27
  %t124 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t125 = load ptr, ptr %t124, !tbaa !27
  %t126 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t127 = load ptr, ptr %t126, !tbaa !27
  %t128 = load i64, ptr %l42, !tbaa !24
  %t129 = mul i64 %t128, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t125, ptr %t127, i64 %t129, i1 false)
  %t130 = load { i64, ptr }, ptr %l43, !tbaa !27
  store { i64, ptr } %t130, ptr %l41, !tbaa !27
  %t131 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t131, ptr %rv
  br label %ret
bb23:
  br label %bb24
bb24:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d25, i32 0, i32 1) }, ptr %l44, !tbaa !27
  %t132 = load { i64, ptr }, ptr %l44, !tbaa !27
  store { i64, ptr } %t132, ptr %l45, !tbaa !27
  %t133 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t134 = extractvalue { i64, ptr } %t133, 0
  store i64 %t134, ptr %l46, !tbaa !24
  %t135 = load i64, ptr %l46, !tbaa !24
  %t136 = mul i64 %t135, 1
  %t137 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t136)
  %t138 = insertvalue { i64, ptr } undef, i64 %t135, 0
  %t139 = insertvalue { i64, ptr } %t138, ptr %t137, 1
  store { i64, ptr } %t139, ptr %l47, !tbaa !27
  %t140 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t141 = load ptr, ptr %t140, !tbaa !27
  %t142 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t143 = load ptr, ptr %t142, !tbaa !27
  %t144 = load i64, ptr %l46, !tbaa !24
  %t145 = mul i64 %t144, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t141, ptr %t143, i64 %t145, i1 false)
  %t146 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } %t146, ptr %l45, !tbaa !27
  %t147 = load { i64, ptr }, ptr %l45, !tbaa !27
  store { i64, ptr } %t147, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @compiler_2feffects_2ereachOf(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca i32
  %l5 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l6 = alloca %"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9"
  %l7 = alloca i64
  %l8 = alloca i32
  %l9 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l10 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l14 = alloca i64
  %l17 = alloca i32
  %l19 = alloca i32
  %l20 = alloca i32
  %l24 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l28 = alloca i32
  %l32 = alloca %"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9"
  %l33 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i32
  %l38 = alloca i1
  %l41 = alloca i1
  %l49 = alloca i1
  %l50 = alloca ptr
  %l53 = alloca i32
  %l56 = alloca i32
  %l59 = alloca i1
  %l62 = alloca i32
  %l64 = alloca ptr
  %l67 = alloca i32
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %v1)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l9
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l9
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %l2
  %t3 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %l10
  br label %bb2
bb2:
  %t4 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l10
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t4, ptr %l3
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %l3, i32 %a1)
  br label %bb3
bb3:
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s1
  %t9 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %l3)
  store i64 %t9, ptr %l14
  br label %bb5
bb5:
  %t10 = load i64, ptr %l14, !tbaa !24
  %t11 = icmp sgt i64 %t10, 0
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s1)
  br label %bb54
bb7:
  br label %bb8
bb8:
  %t16 = call { i32, i32 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePop_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %l3)
  %t17 = extractvalue { i32, i32 } %t16, 1
  %t18 = extractvalue { i32, i32 } %t16, 0
  store i32 %t18, ptr %l20
  %t19 = icmp ne i32 %t18, 0
  br i1 %t19, label %bb10, label %ok.20, !prof !99
ok.20:
  store i32 %t17, ptr %l19
  br label %bb9
bb9:
  %t21 = load i32, ptr %l19, !tbaa !23
  store i32 %t21, ptr %l17, !tbaa !23
  br label %bb17
bb10:
  %t22 = load i32, ptr %l20, !tbaa !23
  %t23 = icmp eq i32 %t22, 65536
  br i1 %t23, label %bb11, label %bb12
bb11:
  call void @__olang_bang_failed_plain(ptr @olang_loc_8cdb6f314e44ea1e_676bc508532ca7da)
  unreachable
bb12:
  %t25 = load i32, ptr %l20, !tbaa !23
  %t26 = icmp eq i32 %t25, 65537
  br i1 %t26, label %bb13, label %bb14
bb13:
  call void @__olang_bang_failed_plain(ptr @olang_loc_d7ee797fa7f6623b_1895f13c17379297)
  unreachable
bb14:
  %t28 = load i32, ptr %l20, !tbaa !23
  %t29 = icmp eq i32 %t28, 65538
  br i1 %t29, label %bb15, label %bb16
bb15:
  call void @__olang_bang_failed_plain(ptr @olang_loc_4b9e80d6ce02d043_aa1b3a7e9d52713f)
  unreachable
bb16:
  call void @__olang_bang_failed_plain(ptr @olang_loc_d3858162065e40d5_cb17c0a8f8b74ad1)
  unreachable
bb17:
  %t31 = load i32, ptr %l17, !tbaa !23
  store i32 %t31, ptr %l4, !tbaa !23
  %t32 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %s1)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t32, ptr %l24
  br label %bb18
bb18:
  %t33 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l24
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t33, ptr %l5
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = load i32, ptr %l4, !tbaa !23
  %t39 = call i32 @compiler_2feffects_2eheldIn(ptr %v0, ptr %s1, ptr %t34, i32 %t35, ptr %l5, i64 0)
  store i32 %t39, ptr %l28
  %t40 = icmp ne i32 %t39, 0
  br i1 %t40, label %bb20, label %ok.41, !prof !99
ok.41:
  br label %bb19
bb19:
  br label %bb23
bb20:
  br label %bb21
bb21:
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v1, ptr %l2, i64 -1, i1 true)
  br label %bb22
bb22:
  %t43 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l2
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t43, ptr %rv
  br label %ret
bb23:
  %t46 = call %"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eKeys_3cI64_2c_20Bool_3e(ptr %s1, ptr %s1, ptr %l5)
  store %"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9" %t46, ptr %l32
  br label %bb24
bb24:
  %t47 = load %"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9", ptr %l32
  store %"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9" %t47, ptr %l6
  br label %bb25
bb25:
  %t49 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapKeyIter_3cI64_2c_20Bool_3e_2eNext_3cI64_2c_20Bool_3e(ptr %s1, ptr %l6)
  %t50 = extractvalue { i32, i64 } %t49, 1
  %t51 = extractvalue { i32, i64 } %t49, 0
  store i32 %t51, ptr %l36
  %t52 = icmp ne i32 %t51, 0
  br i1 %t52, label %bb27, label %ok.53, !prof !99
ok.53:
  store i64 %t50, ptr %l35
  br label %bb26
bb26:
  %t54 = load i64, ptr %l35, !tbaa !24
  store i64 %t54, ptr %l33, !tbaa !24
  br label %bb29
bb27:
  %t55 = load i32, ptr %l36, !tbaa !23
  %t56 = ashr i32 %t55, 16
  %t58 = icmp eq i32 %t56, 1
  store i1 %t58, ptr %l38, !tbaa !21
  br label %bb28
bb28:
  br label %bb52
bb29:
  %t59 = load i64, ptr %l33, !tbaa !24
  store i64 %t59, ptr %l7, !tbaa !24
  %t60 = load i64, ptr %l7, !tbaa !24
  %t63 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v1, ptr %l2, i64 %t60)
  store i1 %t63, ptr %l41
  br label %bb30
bb30:
  %t64 = load i1, ptr %l41, !tbaa !21
  br i1 %t64, label %bb31, label %bb32
bb31:
  br label %bb51
bb32:
  br label %bb33
bb33:
  %t65 = load i64, ptr %l7, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v1, ptr %l2, i64 %t65, i1 true)
  br label %bb34
bb34:
  %t68 = load i64, ptr %l7, !tbaa !24
  %t70 = trunc i64 %t68 to i32
  store i32 %t70, ptr %l8, !tbaa !23
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t74 = load i32, ptr %l8, !tbaa !23
  %t77 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t73, i32 %t74)
  store i1 %t77, ptr %l49
  br label %bb35
bb35:
  %t78 = load i1, ptr %l49, !tbaa !21
  br i1 %t78, label %bb36, label %bb37
bb36:
  store ptr %l3, ptr %l50, !tbaa !29
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t80 = load i32, ptr %l8, !tbaa !23
  %t83 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t79, i32 %t80)
  store i32 %t83, ptr %l53
  br label %bb38
bb37:
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t85 = load i32, ptr %l8, !tbaa !23
  %t88 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t84, i32 %t85)
  store i32 %t88, ptr %l56
  br label %bb40
bb38:
  %t89 = load ptr, ptr %l50, !tbaa !29
  %t90 = load i32, ptr %l53, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %t89, i32 %t90)
  br label %bb39
bb39:
  br label %bb50
bb40:
  %t91 = load i32, ptr %l56, !range !{i32 0, i32 33}
  %t93 = trunc i64 19 to i32
  %t94 = icmp eq i32 %t91, %t93
  br i1 %t94, label %bb41, label %bb42
bb41:
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t97 = load i32, ptr %l8, !tbaa !23
  %t100 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t96, i32 %t97)
  store i32 %t100, ptr %l62
  br label %bb43
bb42:
  store i1 false, ptr %l59, !tbaa !21
  br label %bb44
bb43:
  %t101 = load i32, ptr %l62, !tbaa !23
  %t102 = icmp eq i32 %t101, 0
  store i1 %t102, ptr %l59, !tbaa !21
  br label %bb44
bb44:
  %t104 = load i1, ptr %l59, !tbaa !21
  br i1 %t104, label %bb45, label %bb46
bb45:
  store ptr %l3, ptr %l64, !tbaa !29
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t106 = load i32, ptr %l8, !tbaa !23
  %t109 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t105, i32 %t106)
  store i32 %t109, ptr %l67
  br label %bb47
bb46:
  br label %bb49
bb47:
  %t110 = load ptr, ptr %l64, !tbaa !29
  %t111 = load i32, ptr %l67, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %t110, i32 %t111)
  br label %bb48
bb48:
  br label %bb49
bb49:
  br label %bb50
bb50:
  br label %bb51
bb51:
  br label %bb25
bb52:
  call void @__olang_scope_close(ptr %s1)
  br label %bb53
bb53:
  br label %bb4
bb54:
  %t112 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l2
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t112, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

define dso_local %"compiler/effects:fslot" @compiler_2feffects_3afslot_2ector(ptr %v0, ptr %v1, i64 %a0, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a1, i32 %a2) #0 {
entry:
  %rv = alloca %"compiler/effects:fslot"
  br label %start
start:
  br label %bb0
bb0:
  %t8 = insertvalue %"compiler/effects:fslot" undef, i64 %a0, 0
  %t10 = insertvalue %"compiler/effects:fslot" %t8, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a1, 1
  %t12 = insertvalue %"compiler/effects:fslot" %t10, i32 %a2, 2
  store %"compiler/effects:fslot" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/effects:fslot", ptr %rv
  ret %"compiler/effects:fslot" %rr
}

@.d0 = private constant <{ i64, [29 x i8] }> <{ i64 0, [29 x i8] c"reach code that did not check" }>, align 8
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@.d1 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"allocate" }>, align 8
@.d2 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d3 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"block" }>, align 8
@.d4 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d5 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"start a task" }>, align 8
@.d6 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d7 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"call C" }>, align 8
@.d8 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d9 = private constant <{ i64, [75 x i8] }> <{ i64 0, [75 x i8] c"call through a function value it does not follow, which may lead back to it" }>, align 8
@.d10 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"call itself" }>, align 8
@.d11 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %dh = load ptr, ptr %dheadptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  %hasd = icmp ne ptr %dh, null
  %owns = or i1 %hasf, %hasd
  br i1 %owns, label %owned, label %chunks
owned:
  call void @__olang_scope_close_owned(ptr %scope)
  br label %chunks
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3apart_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = call { i64, ptr } @olang_2emir_2eHelperKind_2eCopy_2eArray_3ccompiler_2feffects_3apart_3e(ptr %v0, { i64, ptr } %t4)
  store { i64, ptr } %t6, ptr %l3
  br label %bb1
bb1:
  %t7 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t8 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t7, ptr %t8, !tbaa !27
  %t9 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ; B19b: a benchmark build counts what this thread allocates - here and at the slow path's own bump, so each
  ; allocation is counted once wherever it is made (a region's and a forwarded scope's come back through here)
; @bench %bna = load i64, ptr @__olang_bench_allocs
; @bench %bna1 = add i64 %bna, 1
; @bench store i64 %bna1, ptr @__olang_bench_allocs
; @bench %bnb = load i64, ptr @__olang_bench_bytes
; @bench %bnb1 = add i64 %bnb, %size
; @bench store i64 %bnb1, ptr @__olang_bench_bytes
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
define linkonce_odr %"compiler/effects:part" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2feffects_3apart(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"compiler/effects:part"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %rv = alloca %"compiler/effects:part"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"compiler/effects:part", ptr %a0
  store %"compiler/effects:part" %t2, ptr %l1
  %t3 = getelementptr %"compiler/effects:part", ptr %l1, i32 0, i32 4
  %t5 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %t3)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %l3
  br label %bb1
bb1:
  %t6 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  %t7 = getelementptr %"compiler/effects:part", ptr %l1, i32 0, i32 4
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t6, ptr %t7
  %t8 = load %"compiler/effects:part", ptr %l1
  store %"compiler/effects:part" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/effects:part", ptr %rv
  ret %"compiler/effects:part" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 8
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

@.d12 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
define linkonce_odr %"compiler/effects:Verdict" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2feffects_3aVerdict(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"compiler/effects:Verdict"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca { i64, ptr }
  %rv = alloca %"compiler/effects:Verdict"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"compiler/effects:Verdict", ptr %a0
  store %"compiler/effects:Verdict" %t2, ptr %l1
  %t3 = getelementptr %"compiler/effects:Verdict", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 1
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"compiler/effects:Verdict", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = getelementptr %"compiler/effects:Verdict", ptr %l1, i32 0, i32 1
  %t21 = load { i64, ptr }, ptr %t20, !tbaa !27
  store { i64, ptr } %t21, ptr %l5, !tbaa !27
  %t22 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t22, 0
  store i64 %t23, ptr %l6, !tbaa !24
  %t24 = load i64, ptr %l6, !tbaa !24
  %t25 = mul i64 %t24, 1
  %t26 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t25)
  %t27 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  store { i64, ptr } %t28, ptr %l7, !tbaa !27
  %t29 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !27
  %t31 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = load i64, ptr %l6, !tbaa !24
  %t34 = mul i64 %t33, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t30, ptr %t32, i64 %t34, i1 false)
  %t35 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t36 = getelementptr %"compiler/effects:Verdict", ptr %l1, i32 0, i32 1
  store { i64, ptr } %t35, ptr %t36, !tbaa !27
  %t37 = getelementptr %"compiler/effects:Verdict", ptr %l1, i32 0, i32 4
  %t38 = load { i64, ptr }, ptr %t37, !tbaa !27
  store { i64, ptr } %t38, ptr %l8, !tbaa !27
  %t39 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t40 = extractvalue { i64, ptr } %t39, 0
  store i64 %t40, ptr %l9, !tbaa !24
  %t41 = load i64, ptr %l9, !tbaa !24
  %t42 = mul i64 %t41, 1
  %t43 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t42)
  %t44 = insertvalue { i64, ptr } undef, i64 %t41, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t43, 1
  store { i64, ptr } %t45, ptr %l10, !tbaa !27
  %t46 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !27
  %t48 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !27
  %t50 = load i64, ptr %l9, !tbaa !24
  %t51 = mul i64 %t50, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t47, ptr %t49, i64 %t51, i1 false)
  %t52 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t53 = getelementptr %"compiler/effects:Verdict", ptr %l1, i32 0, i32 4
  store { i64, ptr } %t52, ptr %t53, !tbaa !27
  %t54 = getelementptr %"compiler/effects:Verdict", ptr %l1, i32 0, i32 7
  %t55 = load { i64, ptr }, ptr %t54, !tbaa !27
  store { i64, ptr } %t55, ptr %l11, !tbaa !27
  %t56 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t57 = extractvalue { i64, ptr } %t56, 0
  store i64 %t57, ptr %l12, !tbaa !24
  %t58 = load i64, ptr %l12, !tbaa !24
  %t59 = mul i64 %t58, 1
  %t60 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t59)
  %t61 = insertvalue { i64, ptr } undef, i64 %t58, 0
  %t62 = insertvalue { i64, ptr } %t61, ptr %t60, 1
  store { i64, ptr } %t62, ptr %l13, !tbaa !27
  %t63 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t64 = load ptr, ptr %t63, !tbaa !27
  %t65 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !27
  %t67 = load i64, ptr %l12, !tbaa !24
  %t68 = mul i64 %t67, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t64, ptr %t66, i64 %t68, i1 false)
  %t69 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t70 = getelementptr %"compiler/effects:Verdict", ptr %l1, i32 0, i32 7
  store { i64, ptr } %t69, ptr %t70, !tbaa !27
  %t71 = load %"compiler/effects:Verdict", ptr %l1
  store %"compiler/effects:Verdict" %t71, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/effects:Verdict", ptr %rv
  ret %"compiler/effects:Verdict" %rr
}

@.d13 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d14 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d15 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d16 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"this value's Call" }>, align 8
declare void @__olang_check_failed(ptr) cold noreturn
@.d17 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d18 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"this lambda" }>, align 8
define available_externally ptr @__olang_scope_hold(ptr %s) alwaysinline {
entry:
  %none = icmp eq ptr %s, null
  br i1 %none, label %plain, label %look
look:
  ; atomic: on a scope that is no stand-in this word is its parts list, which other threads push onto (__olang_scope_part)
  %mp = getelementptr %olang.scope, ptr %s, i32 0, i32 4
  %m = load atomic ptr, ptr %mp monotonic, align 8
  %fresh = icmp eq ptr %m, @__olang_standin_mark
  br i1 %fresh, label %make, label %kept
kept:
  %mi = ptrtoint ptr %m to i64
  %bit = and i64 %mi, 1
  %has = icmp ne i64 %bit, 0
  br i1 %has, label %keeper, label %plain
keeper:
  %ki = and i64 %mi, -2
  %k = inttoptr i64 %ki to ptr
  ret ptr %k
make:
  %f = call ptr @__olang_standin_keeper(ptr %s)
  ret ptr %f
plain:
  ret ptr %s
}
@olang_2esole_2ecompiler_2feffects_3aVerdict_2e0 = weak hidden constant i1 false
declare ptr @__olang_region_make_part(ptr) noinline
define available_externally noalias ptr @__olang_held_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
@olang_2esole_2ecompiler_2feffects_3aVerdict_2e1 = weak hidden constant i1 false
declare ptr @__olang_region_or(ptr, ptr)
declare void @__olang_region_settle_in(ptr, ptr)
@olang_2esole_2ecompiler_2feffects_3aVerdict_2e4 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2feffects_3aVerdict_2e7 = weak hidden constant i1 false
declare void @__olang_region_release_part(ptr, i64) noinline
@__olang_prog_scope = external thread_local(initialexec) global ptr
@olang_2esole_2ecompiler_2feffects_3aEffects_2e50 = weak hidden constant i1 false
define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3agiven_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = call { i64, ptr } @olang_2emir_2eHelperKind_2eCopy_2eArray_3ccompiler_2feffects_3agiven_3e(ptr %v0, { i64, ptr } %t4)
  store { i64, ptr } %t6, ptr %l3
  br label %bb1
bb1:
  %t7 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t8 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t7, ptr %t8, !tbaa !27
  %t9 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

declare void @__olang_bang_failed_plain(ptr) cold noreturn
define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3afslot_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = call { i64, ptr } @olang_2emir_2eHelperKind_2eCopy_2eArray_3ccompiler_2feffects_3afslot_3e(ptr %v0, { i64, ptr } %t4)
  store { i64, ptr } %t6, ptr %l3
  br label %bb1
bb1:
  %t7 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t8 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t7, ptr %t8, !tbaa !27
  %t9 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

@olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0 = weak hidden constant i1 false
define linkonce_odr %"compiler/effects:fslot" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2feffects_3afslot(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"compiler/effects:fslot"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %rv = alloca %"compiler/effects:fslot"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"compiler/effects:fslot", ptr %a0
  store %"compiler/effects:fslot" %t2, ptr %l1
  %t3 = getelementptr %"compiler/effects:fslot", ptr %l1, i32 0, i32 1
  %t5 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %t3)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %l3
  br label %bb1
bb1:
  %t6 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  %t7 = getelementptr %"compiler/effects:fslot", ptr %l1, i32 0, i32 1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t6, ptr %t7
  %t8 = load %"compiler/effects:fslot", ptr %l1
  store %"compiler/effects:fslot" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/effects:fslot", ptr %rv
  ret %"compiler/effects:fslot" %rr
}

define linkonce_odr %"compiler/effects:pend" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2feffects_3apend(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"compiler/effects:pend"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %rv = alloca %"compiler/effects:pend"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"compiler/effects:pend", ptr %a0
  store %"compiler/effects:pend" %t2, ptr %l1
  %t3 = getelementptr %"compiler/effects:pend", ptr %l1, i32 0, i32 3
  %t5 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %t3)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %l3
  br label %bb1
bb1:
  %t6 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  %t7 = getelementptr %"compiler/effects:pend", ptr %l1, i32 0, i32 3
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t6, ptr %t7
  %t8 = load %"compiler/effects:pend", ptr %l1
  store %"compiler/effects:pend" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/effects:pend", ptr %rv
  ret %"compiler/effects:pend" %rr
}

@.d19 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3alink_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 24
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 24
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

@olang_2esole_2estd_2fprelude_2fmap_3aMapKeyIter_3cI64_2c_20Bool_3e_2e0 = weak hidden constant i1 false
declare ptr @__olang_region_make(ptr) noinline
@olang_2esole_2ecompiler_2feffects_3aEffects_2e5 = weak hidden constant i1 false
declare ptr @__olang_region_home(ptr)
declare void @__olang_region_drop(ptr) noinline
@olang_2esole_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3aGlobalAt_3e_2e0 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2feffects_3aEffects_2e26 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2feffects_3aEffects_2e27 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2feffects_3aEffects_2e29 = weak hidden constant i1 false
@olang_2esole_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3alink_3e_2e0 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2feffects_3aEffects_2e31 = weak hidden constant i1 false
@olang_2esole_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2e0 = weak hidden constant i1 false
@olang_2esole_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2e1 = weak hidden constant i1 false
@olang_2esole_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2e2 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2feffects_3aEffects_2e32 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2feffects_3aEffects_2e33 = weak hidden constant i1 false
@olang_2esole_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2e0 = weak hidden constant i1 false
@olang_2esole_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2e1 = weak hidden constant i1 false
@olang_2esole_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2e2 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2feffects_3aEffects_2e34 = weak hidden constant i1 false
@.d20 = private constant <{ i64, [64 x i8] }> <{ i64 0, [64 x i8] c"call through a function value or an 'any', which may do anything" }>, align 8
@.d21 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"write a global" }>, align 8
@.d22 = private constant <{ i64, [26 x i8] }> <{ i64 0, [26 x i8] c"read a global that changes" }>, align 8
@.d23 = private constant <{ i64, [44 x i8] }> <{ i64 0, [44 x i8] c"write through what it was not given writably" }>, align 8
@.d24 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"call C" }>, align 8
@.d25 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare void @__olang_scope_close_owned(ptr) noinline
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
define linkonce_odr { i64, ptr } @olang_2emir_2eHelperKind_2eCopy_2eArray_3ccompiler_2feffects_3apart_3e(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l6 = alloca %"compiler/effects:part"
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t2 = extractvalue { i64, ptr } %t1, 0
  store i64 %t2, ptr %l1, !tbaa !24
  %t3 = load i64, ptr %l1, !tbaa !24
  %t4 = mul i64 %t3, 72
  %t5 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t4)
  %t6 = insertvalue { i64, ptr } undef, i64 %t3, 0
  %t7 = insertvalue { i64, ptr } %t6, ptr %t5, 1
  store { i64, ptr } %t7, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  %t8 = load i64, ptr %l3, !tbaa !24
  %t9 = load i64, ptr %l1, !tbaa !24
  %t10 = icmp slt i64 %t8, %t9
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = load i64, ptr %l3, !tbaa !24
  %t13 = getelementptr { i64, ptr }, ptr %l0, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !27
  %t15 = getelementptr %"compiler/effects:part", ptr %t14, i64 %t12
  %t17 = call %"compiler/effects:part" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2feffects_3apart(ptr %v0, ptr %t15)
  store %"compiler/effects:part" %t17, ptr %l6
  br label %bb4
bb3:
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t18, ptr %rv
  br label %ret
bb4:
  %t19 = load %"compiler/effects:part", ptr %l6
  %t20 = load i64, ptr %l3, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr %"compiler/effects:part", ptr %t22, i64 %t20
  store %"compiler/effects:part" %t19, ptr %t23
  %t24 = load i64, ptr %l3, !tbaa !24
  %t25 = add i64 %t24, 1
  store i64 %t25, ptr %l3, !tbaa !24
  br label %bb1
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
@__olang_standin_mark = external global i64
declare ptr @__olang_standin_keeper(ptr) noinline
define available_externally noalias ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  %head = load ptr, ptr %scope, !tbaa !59
  %isslot = icmp eq ptr %head, @__olang_slot_chunk
  br i1 %isslot, label %slot, label %plain
slot:
  %s = call ptr @__olang_slot_alloc(ptr %scope, i64 %rawsize)
  ret ptr %s
plain:
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr { i64, ptr } @olang_2emir_2eHelperKind_2eCopy_2eArray_3ccompiler_2feffects_3agiven_3e(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l6 = alloca %"compiler/effects:given"
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t2 = extractvalue { i64, ptr } %t1, 0
  store i64 %t2, ptr %l1, !tbaa !24
  %t3 = load i64, ptr %l1, !tbaa !24
  %t4 = mul i64 %t3, 80
  %t5 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t4)
  %t6 = insertvalue { i64, ptr } undef, i64 %t3, 0
  %t7 = insertvalue { i64, ptr } %t6, ptr %t5, 1
  store { i64, ptr } %t7, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  %t8 = load i64, ptr %l3, !tbaa !24
  %t9 = load i64, ptr %l1, !tbaa !24
  %t10 = icmp slt i64 %t8, %t9
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = load i64, ptr %l3, !tbaa !24
  %t13 = getelementptr { i64, ptr }, ptr %l0, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !27
  %t15 = getelementptr %"compiler/effects:given", ptr %t14, i64 %t12
  %t17 = call %"compiler/effects:given" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2feffects_3agiven(ptr %v0, ptr %t15)
  store %"compiler/effects:given" %t17, ptr %l6
  br label %bb4
bb3:
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t18, ptr %rv
  br label %ret
bb4:
  %t19 = load %"compiler/effects:given", ptr %l6
  %t20 = load i64, ptr %l3, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr %"compiler/effects:given", ptr %t22, i64 %t20
  store %"compiler/effects:given" %t19, ptr %t23
  %t24 = load i64, ptr %l3, !tbaa !24
  %t25 = add i64 %t24, 1
  store i64 %t25, ptr %l3, !tbaa !24
  br label %bb1
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define linkonce_odr { i64, ptr } @olang_2emir_2eHelperKind_2eCopy_2eArray_3ccompiler_2feffects_3afslot_3e(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l6 = alloca %"compiler/effects:fslot"
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t2 = extractvalue { i64, ptr } %t1, 0
  store i64 %t2, ptr %l1, !tbaa !24
  %t3 = load i64, ptr %l1, !tbaa !24
  %t4 = mul i64 %t3, 48
  %t5 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t4)
  %t6 = insertvalue { i64, ptr } undef, i64 %t3, 0
  %t7 = insertvalue { i64, ptr } %t6, ptr %t5, 1
  store { i64, ptr } %t7, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  %t8 = load i64, ptr %l3, !tbaa !24
  %t9 = load i64, ptr %l1, !tbaa !24
  %t10 = icmp slt i64 %t8, %t9
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = load i64, ptr %l3, !tbaa !24
  %t13 = getelementptr { i64, ptr }, ptr %l0, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !27
  %t15 = getelementptr %"compiler/effects:fslot", ptr %t14, i64 %t12
  %t17 = call %"compiler/effects:fslot" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2feffects_3afslot(ptr %v0, ptr %t15)
  store %"compiler/effects:fslot" %t17, ptr %l6
  br label %bb4
bb3:
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t18, ptr %rv
  br label %ret
bb4:
  %t19 = load %"compiler/effects:fslot", ptr %l6
  %t20 = load i64, ptr %l3, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr %"compiler/effects:fslot", ptr %t22, i64 %t20
  store %"compiler/effects:fslot" %t19, ptr %t23
  %t24 = load i64, ptr %l3, !tbaa !24
  %t25 = add i64 %t24, 1
  store i64 %t25, ptr %l3, !tbaa !24
  br label %bb1
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

@__olang_slot_chunk = external global %olang.chunk
declare noalias ptr @__olang_slot_alloc(ptr, i64) noinline
define linkonce_odr %"compiler/effects:given" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2feffects_3agiven(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"compiler/effects:given"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %rv = alloca %"compiler/effects:given"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"compiler/effects:given", ptr %a0
  store %"compiler/effects:given" %t2, ptr %l1
  %t3 = getelementptr %"compiler/effects:given", ptr %l1, i32 0, i32 5
  %t5 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %t3)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %l3
  br label %bb1
bb1:
  %t6 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  %t7 = getelementptr %"compiler/effects:given", ptr %l1, i32 0, i32 5
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t6, ptr %t7
  %t8 = load %"compiler/effects:given", ptr %l1
  store %"compiler/effects:given" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/effects:given", ptr %rv
  ret %"compiler/effects:given" %rr
}

@G_2ecompiler_2ftypes_2ePromNoalloc = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
declare i1 @compiler_2feffects_2ecompiler_2feffects_3aFacts_2eHolds(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2ePromNoblock = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ftypes_2ePromNospawn = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\08\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ftypes_2ePromNoextern = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\20\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2feffects_2eCapThreads = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\20\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ftypes_2ePromReturns = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare { i64, ptr } @compiler_2feffects_2enotReturning(ptr %v0, ptr %v1, ptr %a0)
@G_2ecompiler_2ftypes_2ePromPure = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\40\00\00\00\00\00\00\00" }>, align 8
declare void @compiler_2feffects_2eMerge(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/effects:Verdict" @compiler_2feffects_3aVerdict_2ector(ptr %v0)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePromiseWords(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2feffects_2eEffectWords = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\7F\00\00\00\00\00\00\00" }>, align 8
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %a0)
declare %"compiler/effects:Facts" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eOf(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3apart_3e_2eClear_3ccompiler_2feffects_3apart_3e(ptr %v0, ptr %a0)
declare void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eclassify(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3apart_3e_2eLen_3ccompiler_2feffects_3apart_3e(ptr %v0, ptr %a0)
declare %"compiler/effects:part" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3apart_3e_2eAt_3ccompiler_2feffects_3apart_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@G_2ecompiler_2feffects_2eGivResult = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00" }>, align 8
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cI_Hbd09c84b003bb96b764c8a61b7f32193(ptr %v0, ptr %a0, i64 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eretsOf(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ejudgeFacts(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i64 %a2, ptr %a3)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ebodyName(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@G_2ecompiler_2feffects_2eGivSlot = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2feffects_2eGivBound = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eslotType(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
@G_2ecompiler_2feffects_2eGivNamed = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2feffects_2ePartAdapter = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\06\00\00\00\00\00\00\00" }>, align 8
declare i1 @compiler_2feffects_2ehasBit(i64 %a0, i64 %a1)
@G_2ecompiler_2feffects_2ePartLambda = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\05\00\00\00\00\00\00\00" }>, align 8
@olang_loc_cce6b986552578d0_26bb880b6e07dfc = external constant [0 x i8]
declare %"compiler/effects:Facts" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2elambdaFacts(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, ptr %a3)
declare void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eblock(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@G_2ecompiler_2ftypes_2ePromiseNames = external constant <{ [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr }>
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"compiler/effects:Facts" @compiler_2feffects_3aFacts_2ector(ptr %v0)
declare { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cc_H7b34d2d8e55697dbed551519dd59c955(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3agiven_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__H7b6d4eff6fc9c3821aae8b284e12e095(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3agiven_3e_2eLen_3ccompiler_2feffects_3agiven_3e(ptr %v0, ptr %a0)
declare %"compiler/effects:given" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3agiven_3e_2eAt_3ccompiler_2feffects_3agiven_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"compiler/effects:Facts" @compiler_2feffects_2eFacts_2eBound(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ectorCall(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_f7c8ab04542d2f7e_3025df788b022d62 = external constant [0 x i8]
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v0, ptr %a0)
declare i1 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eisFn(ptr %v0, ptr %a0, i32 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cc_H812d4871fea5544bd17001c04038a9fe(ptr %v0, ptr %a0, i64 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ector(ptr %v0, i64 %a0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cc_Hc680bc8b736298027ff580de04f60380(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a2)
declare { i32, ptr } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cc_Hfb9e5165fbc860148668cf342d052cc0(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_12d41178ea699117_cd5c06b5e62ab993 = external constant [0 x i8]
@olang_loc_bfb31f4e096fcfdd_9eff6572189cd471 = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2einstType(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_bdb589e9fb60a385_99895746a144f341 = external constant [0 x i8]
@olang_loc_6c2f84c28d80f803_c1ff4c3310f9a27 = external constant [0 x i8]
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %a0, i32 %a1)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNeedsDrop(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDestructs(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_a95aecd22ff58df7_af716a2d87a126b3 = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e__H165e1ff795edcbb725e28dde18fd1dc2(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eplace(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eNoreturnT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\11\00\00\00" }>, align 8
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ecall(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_949627fca0824f08_4c3b1084581425e4 = external constant [0 x i8]
declare void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eclause(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_ca5d43677e660e3e_842659f2ce3d2d4a = external constant [0 x i8]
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cc_H3f7eb4254a4c517352479452f11f6219(ptr %v0, ptr %a0, i64 %a1)
declare { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cc_Hc098dfa5961f28f78d4c086fb0a8b3d1(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3afslot_3e_2ector(ptr %v0, i64 %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2estructOf(ptr %v0, ptr %a0, i32 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2epaths(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3afpath_3e_2eLen_3ccompiler_2feffects_3afpath_3e(ptr %v0, ptr %a0)
declare %"compiler/effects:fpath" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3afpath_3e_2eAt_3ccompiler_2feffects_3afpath_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3afslot_3e_2ePush_3ccompiler_2feffects_3afslot_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/effects:fslot" %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cc_Hafeff049746af34a0f4960f24da5119b(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3apend_3e_2eLen_3ccompiler_2feffects_3apend_3e(ptr %v0, ptr %a0)
declare %"compiler/effects:pend" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3apend_3e_2eAt_3ccompiler_2feffects_3apend_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eresolve(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eoutsJudged(ptr %v0, ptr %a0)
declare void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eretFields(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@G_2ecompiler_2feffects_2eGivMade = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
declare i64 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ecaptureSlot(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare %"compiler/effects:pend" @compiler_2feffects_3apend_2ector(ptr %v0, ptr %v1, i64 %a0, i64 %a1, ptr %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3apend_3e_2ePush_3ccompiler_2feffects_3apend_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/effects:pend" %a1)
@olang_loc_d8634726df7208f7_383307572af5b0b3 = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3aFacts_3e_2ePush_3ccompiler_2feffects_3aFacts_3e(ptr %v0, ptr %a0, %"compiler/effects:Facts" %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3aGlobalAt_3e_2ector(ptr %v0, i64 %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3ccompiler_2_Hdcca521946d79d494efe15f7d0a69330(ptr %v0, ptr %v1, ptr %a0, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__H5a6912247a81ac1f46c16a43fcc4c44a(ptr %v0, ptr %v1, ptr %a0, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3alink_3e_2ector(ptr %v0, i64 %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3ccompiler_2_H691765597a1d0d55e0f84306543aa643(ptr %v0, ptr %v1, ptr %a0, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %a0, i1 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e__Hccd9659a44f570da1fa06b019882a84d(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eLen_3cI64_2c_20I64_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i32, i1 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eGet_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %v0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOwnedPart(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOwnsParts(ptr %v0, ptr %a0, i32 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3apart_3e_2ector(ptr %v0, i64 %a0)
@G_2ecompiler_2feffects_2eGivResField = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\07\00\00\00\00\00\00\00" }>, align 8
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3apart_3e_2ePush_3ccompiler_2feffects_3apart_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/effects:part" %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2efieldParts(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, ptr %a2)
declare void @compiler_2ftyped_2eLocalUses_2eUses(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eClear_3cBool_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eLen_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0)
declare i1 @compiler_2ftyped_2ecompiler_2ftyped_3aRefsKept_2eKept(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4, i64 %a5)
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eKeys_3cI64_2c_20Bool_3e(ptr %v0, ptr %v1, ptr %a0)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapKeyIter_3cI64_2c_20Bool_3e_2eNext_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cc_Hb5dd413d586c55d7ccefa7dbc5ad43c5(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/effects:Facts" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3aFacts_3e_2eAt_3ccompiler_2feffects_3aFacts_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2feffects_2eparamBit(i64 %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3aFacts_3e_2eRefMut_3ccompiler_2feffects_3aFacts_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3ccompiler_2_Hec46674a538af874724ad5c9698b0829(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3alink_3e_2eLen_3ccompiler_2feffects_3alink_3e(ptr %v0, ptr %a0)
declare %"compiler/effects:link" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3alink_3e_2eAt_3ccompiler_2feffects_3alink_3e(ptr %v0, ptr %a0, i64 %a1)
@G_2ecompiler_2feffects_2eglobalParam = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FE\FF\FF\FF\FF\FF\FF\FF" }>, align 8
@G_2ecompiler_2feffects_2eoutParam = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FD\FF\FF\FF\FF\FF\FF\FF" }>, align 8
declare void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ewritten(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_31e57a958c31a5ba_705aefa950dbf3e6 = external constant [0 x i8]
declare i64 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ereachIndex(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftyped_2eHoldsOwned(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2ftyped_2eCall_2eQuietRead(ptr %v0, ptr %v1, ptr %a0)
declare i64 @compiler_2ftyped_2eCalleeBody(ptr %v0, ptr %a0)
declare i64 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eviewsOf(ptr %v0, ptr %a0, i64 %a1)
@G_2ecompiler_2ftyped_2eViewOther = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\40" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRunsCopy(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftyped_2eViewBits = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\3E\00\00\00\00\00\00\00" }>, align 8
declare i64 @std_2fprelude_2fnumber_2eI64_2eMin_3cI64_3e(i64 %a0, i64 %a1)
declare i1 @compiler_2ftyped_2ePlaceRooted(ptr %v0, ptr %a0)
declare %"compiler/effects:part" @compiler_2feffects_3apart_2ector(ptr %v0, ptr %v1, i64 %a0, i64 %a1, i32 %a2, ptr %a3)
declare void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eresField(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, ptr %a2, ptr %a3, i64 %a4)
@olang_loc_e883a08fe0a2dfcb_10d50552a173805f = external constant [0 x i8]
@olang_loc_be89c63eecba24dc_20b8a06f464464c0 = external constant [0 x i8]
@olang_loc_da29f57e967b0d58_398b0b5997e9910c = external constant [0 x i8]
declare i64 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eexprRoot(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2escanExpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2escanBlock(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_376d296af4c830bb_f1e6df173964d75f = external constant [0 x i8]
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v0, ptr %a0)
declare %"compiler/effects:pair" @compiler_2feffects_3apair_2ector(ptr %v0, i64 %a0, i64 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2feffects_3apair_2c_20Bool_3e_Ha1bc2f35f7d195c0ca99c509224bae7a(ptr %v0, ptr %a0, %"compiler/effects:pair" %a1, i1 %a2)
@olang_loc_dbda74c6bd85bcc6_57ce86cdebb39c22 = external constant [0 x i8]
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eHas_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3aFacts_3e_2eSetAt_3ccompiler_2feffects_3aFacts_3e(ptr %v0, ptr %a0, i64 %a1, %"compiler/effects:Facts" %a2)
declare i1 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ewritesUnowned(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i1 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ecallsThrough(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2feffects_2eexclusiveShape(ptr %v0, ptr %a0, i32 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_3e_2ector(ptr %v0, i64 %a0)
declare i1 @compiler_2feffects_2eplainData(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eViaMemory(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fmap_3aMap_3cI64_2c_20B_H62acbf8f3c446e07109f0c23ca6f8756(ptr %v0, ptr %v1, ptr %a0, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %a1)
@G_2ecompiler_2ftypes_2eVoidT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fmap_3aMap_3cI64_2c_20B_Hbcd3253946b558e2d8e9e43f4596e7da(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3agiven_3e_2eClear_3ccompiler_2feffects_3agiven_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3apend_3e_2eClear_3ccompiler_2feffects_3apend_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cc_H0398947fe830469ce1a64c5da7c2d54d(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cc_H4527323723b724269d0557de47b57e0e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eLen_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eClear_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eClear_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eClear_3cI64_2c_20I64_3e(ptr %v0, ptr %a0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ector(ptr %v0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2eLen_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2eAt_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @compiler_2ftyped_2eDropsRun(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_1339f6fe14a38149_c7d1650dc39f436d = external constant [0 x i8]
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_5c824f1279c93c35_a4567916a622c1e9 = external constant [0 x i8]
declare { i32, i32 } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHeldParts(ptr %v0, ptr %a0, i32 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %v0, i64 %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0)
declare { i32, i32 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePop_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0)
@olang_loc_8cdb6f314e44ea1e_676bc508532ca7da = external constant [0 x i8]
@olang_loc_d7ee797fa7f6623b_1895f13c17379297 = external constant [0 x i8]
@olang_loc_4b9e80d6ce02d043_aa1b3a7e9d52713f = external constant [0 x i8]
@olang_loc_d3858162065e40d5_cb17c0a8f8b74ad1 = external constant [0 x i8]

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
