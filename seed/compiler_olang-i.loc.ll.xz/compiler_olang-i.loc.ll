; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

@olang_loc_251e830707558b33_b2bdace7e2a71047 = weak_odr constant [47 x i8] c"compiler/build.olang:937: unreachable reached\0A\00"
@olang_loc_44996bcc7c9bda8_515f8c8db8b0565c = weak_odr constant [47 x i8] c"compiler/build.olang:790: unreachable reached\0A\00"
@olang_loc_4cd8465f442ebc46_73c7e9f900a2458a = weak_odr constant [47 x i8] c"compiler/build.olang:719: unreachable reached\0A\00"
@olang_loc_539f96ece49ac99_8ec4d6c22ed03845 = weak_odr constant [47 x i8] c"compiler/build.olang:696: unreachable reached\0A\00"
@olang_loc_6ff5f1cbdf8b017d_cabbfa25d1d462b1 = weak_odr constant [47 x i8] c"compiler/build.olang:932: unreachable reached\0A\00"
@olang_loc_e43b1413a2a1997d_89f9fa2bec5137e9 = weak_odr constant [47 x i8] c"compiler/build.olang:781: unreachable reached\0A\00"
