; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr, i64, ptr }
%olang.home = type { ptr, ptr }
%olang.slotscope = type { %olang.scope, i64, [8 x ptr] }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/bindgen:Translation" = type { { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, i1 }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/bindgen:gen" = type { { i64, ptr }, i1, i1, { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/text:StringBuilder", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, i64 }
%"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i64, i64 }
%"std/os:Output" = type { i32, { i64, ptr }, { i64, ptr } }
%"compiler/bindgen:cMacro" = type { { i64, ptr }, i1, { i64, ptr }, { i64, ptr }, i1, i1 }
%"compiler/bindgen:ctype" = type { i32, { i64, ptr }, i64, i1, i64, i64 }
%"compiler/bindgen:cx" = type { { i64, ptr }, i64, i64, { i64, ptr } }
%"compiler/bindgen:cparse" = type { { i64, ptr }, { i64, ptr }, i64 }
%"compiler/bindgen:ctp" = type { { i64, ptr }, i64 }
%"compiler/bindgen:record" = type { { i64, ptr }, i1, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, { i64, ptr }, i1, i64, i1, { i64, ptr }, i1, i64, i64, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9" = type { ptr, i64 }
%"std/prelude/text:LineIter" = type { { i64, ptr }, i64 }
%"compiler/bindgen:cFunc" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, { i64, ptr } }
define dso_local %"compiler/bindgen:Translation" @compiler_2fbindgen_2eTranslation_2eTranslate(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %v6, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, { i64, ptr } %a4, { i64, ptr } %a5) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %lp6 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l8 = alloca [2 x { i64, ptr }]
  %l9 = alloca { i64, ptr }
  %lp10 = alloca ptr
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca { i64, ptr }
  %l15 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca i64
  %l20 = alloca ptr
  %l21 = alloca i64
  %l22 = alloca i64
  %lp24 = alloca ptr
  %l25 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l26 = alloca %"std/prelude/text:StringBuilder"
  %l27 = alloca ptr
  %l28 = alloca i64
  %l29 = alloca i64
  %l31 = alloca ptr
  %l32 = alloca { i64, ptr }
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca ptr
  %l36 = alloca { i64, ptr }
  %l37 = alloca i64
  %l38 = alloca { i64, ptr }
  %l39 = alloca i64
  %l40 = alloca i64
  %l42 = alloca { i64, ptr }
  %l43 = alloca i64
  %l44 = alloca %"compiler/bindgen:Translation"
  %l46 = alloca i1
  %l47 = alloca { i64, ptr }
  %l50 = alloca { i64, ptr }
  %l51 = alloca { i64, ptr }
  %l52 = alloca i32
  %l54 = alloca i1
  %l57 = alloca { i64, ptr }
  %l64 = alloca { i64, ptr }
  %l70 = alloca i32
  %l72 = alloca i1
  %l75 = alloca { i64, ptr }
  %l77 = alloca %"compiler/bindgen:Translation"
  %l78 = alloca i64
  %l80 = alloca { i64, ptr }
  %l81 = alloca i64
  %l82 = alloca { i64, ptr }
  %l87 = alloca i32
  %l89 = alloca i1
  %l93 = alloca i1
  %l95 = alloca { i64, ptr }
  %l99 = alloca %"compiler/bindgen:gen"
  %l107 = alloca { i64, ptr }
  %l111 = alloca i1
  %l112 = alloca i1
  %l115 = alloca { i64, ptr }
  %l116 = alloca i1
  %l121 = alloca { i64, ptr }
  %l124 = alloca { i64, ptr }
  %l126 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l136 = alloca { i64, ptr }
  %l161 = alloca %"std/os:Output"
  %l163 = alloca { i64, ptr }
  %l164 = alloca %"std/os:Output"
  %l165 = alloca i32
  %l167 = alloca i1
  %l168 = alloca { i64, ptr }
  %l170 = alloca %"compiler/bindgen:Translation"
  %l171 = alloca i64
  %l173 = alloca { i64, ptr }
  %l174 = alloca i64
  %l175 = alloca { i64, ptr }
  %l180 = alloca i32
  %l182 = alloca i1
  %l189 = alloca { i64, ptr }
  %l190 = alloca i1
  %l191 = alloca i64
  %l194 = alloca { i64, ptr }
  %l196 = alloca { i64, ptr }
  %l198 = alloca %"compiler/bindgen:Translation"
  %l199 = alloca i64
  %l201 = alloca { i64, ptr }
  %l202 = alloca i64
  %l203 = alloca { i64, ptr }
  %l208 = alloca i32
  %l210 = alloca i1
  %l218 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l219 = alloca %"std/prelude/text:StringBuilder"
  %l225 = alloca i64
  %l227 = alloca i64
  %l233 = alloca i64
  %l234 = alloca ptr
  %l235 = alloca i64
  %l236 = alloca i64
  %l239 = alloca %"compiler/bindgen:cMacro"
  %l246 = alloca { i64, ptr }
  %l248 = alloca { i64, ptr }
  %l251 = alloca i32
  %l253 = alloca i1
  %l256 = alloca { i64, ptr }
  %l258 = alloca %"compiler/bindgen:Translation"
  %l259 = alloca i64
  %l261 = alloca { i64, ptr }
  %l262 = alloca i64
  %l263 = alloca { i64, ptr }
  %l268 = alloca i32
  %l270 = alloca i1
  %l273 = alloca ptr
  %l278 = alloca ptr
  %l279 = alloca i32
  %l281 = alloca i1
  %l283 = alloca { i64, ptr }
  %l285 = alloca %"compiler/bindgen:Translation"
  %l286 = alloca i64
  %l288 = alloca { i64, ptr }
  %l289 = alloca i64
  %l290 = alloca { i64, ptr }
  %l295 = alloca i32
  %l297 = alloca i1
  %l304 = alloca { i64, ptr }
  %l312 = alloca { i64, ptr }
  %l316 = alloca { i64, ptr }
  %l318 = alloca { i64, ptr }
  %l320 = alloca i1
  %l322 = alloca i1
  %l324 = alloca i1
  %l326 = alloca i64
  %l328 = alloca i64
  %l329 = alloca i64
  %l333 = alloca { i64, ptr }
  %l334 = alloca i64
  %l335 = alloca i32
  %l336 = alloca i64
  %l337 = alloca i32
  %l340 = alloca i1
  %l341 = alloca i64
  %l343 = alloca i64
  %l346 = alloca { i64, ptr }
  %l354 = alloca { i64, ptr }
  %l358 = alloca { i64, ptr }
  %l360 = alloca i1
  %l361 = alloca i64
  %l362 = alloca { i64, ptr }
  %l363 = alloca i64
  %l364 = alloca i32
  %l365 = alloca i64
  %l366 = alloca i32
  %l367 = alloca ptr
  %l368 = alloca ptr
  %l371 = alloca i64
  %l372 = alloca %"compiler/bindgen:cMacro"
  %l387 = alloca i32
  %l389 = alloca i1
  %l391 = alloca { i64, ptr }
  %l393 = alloca %"compiler/bindgen:Translation"
  %l394 = alloca i64
  %l396 = alloca { i64, ptr }
  %l397 = alloca i64
  %l398 = alloca { i64, ptr }
  %l403 = alloca i32
  %l405 = alloca i1
  %l408 = alloca i64
  %l414 = alloca { i64, ptr }
  %l416 = alloca { i64, ptr }
  %l419 = alloca i64
  %l421 = alloca i1
  %l423 = alloca i1
  %l425 = alloca i64
  %l427 = alloca { i64, ptr }
  %l428 = alloca { i64, ptr }
  %l430 = alloca { i64, ptr }
  %l433 = alloca { i64, ptr }
  %l435 = alloca %"compiler/bindgen:Translation"
  %l436 = alloca i64
  %l438 = alloca { i64, ptr }
  %l439 = alloca i64
  %l440 = alloca { i64, ptr }
  %l445 = alloca i32
  %l447 = alloca i1
  %s0 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %s29 = alloca %olang.scope
  %s40 = alloca %olang.scope
  %s41 = alloca %olang.scope
  %s44 = alloca %olang.scope
  %s45 = alloca %olang.scope
  %s55 = alloca %olang.scope
  %rv = alloca %"compiler/bindgen:Translation"
  %t182 = alloca %"compiler/bindgen:gen", align 8
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  store { i64, ptr } %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"compiler/bindgen:Translation" @compiler_2fbindgen_3aTranslation_2ector(ptr %v6)
  store %"compiler/bindgen:Translation" %t1, ptr %l44
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v6, i64 88, i64 8)
  store ptr %t2, ptr %lp6
  %t3 = load %"compiler/bindgen:Translation", ptr %l44
  %t4 = load ptr, ptr %lp6
  store %"compiler/bindgen:Translation" %t3, ptr %t4
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t7 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s0, { i64, ptr } %t5, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d0, i32 0, i32 1) })
  store i1 %t7, ptr %l46
  br label %bb2
bb2:
  %t8 = load i1, ptr %l46, !tbaa !21
  br i1 %t8, label %bb3, label %bb4
bb3:
  %t9 = load ptr, ptr %lp6
  %t10 = getelementptr %"compiler/bindgen:Translation", ptr %t9, i32 0, i32 3
  %t11 = load { i64, ptr }, ptr %t10, !tbaa !27
  store { i64, ptr } %t11, ptr %l47, !tbaa !27
  %t12 = load ptr, ptr %lp6
  %t13 = getelementptr %"compiler/bindgen:Translation", ptr %t12, i32 0, i32 3
  store { i64, ptr } { i64 53, ptr getelementptr inbounds (<{ i64, [53 x i8] }>, ptr @.d1, i32 0, i32 1) }, ptr %t13, !tbaa !27
  %t14 = load i1, ptr @olang_2esole_2ecompiler_2fbindgen_3aTranslation_2e3
  br i1 %t14, label %bb5, label %bb6
bb4:
  br label %bb7
bb5:
  %t16 = load { i64, ptr }, ptr %l47
  %t17 = extractvalue { i64, ptr } %t16, 1
  call void @__olang_region_release(ptr %t17)
  store { i64, ptr } zeroinitializer, ptr %l47
  br label %bb6
bb6:
  %t18 = load ptr, ptr %lp6
  %t19 = load %"compiler/bindgen:Translation", ptr %t18
  call void @__olang_scope_close(ptr %s0)
  store %"compiler/bindgen:Translation" %t19, ptr %rv
  br label %ret
bb7:
  %t21 = call { i32, { i64, ptr } } @std_2fos_2eMkTemp(ptr %s0, ptr %s0, ptr %s0, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d2, i32 0, i32 1) }, { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d3, i32 0, i32 1) })
  %t22 = extractvalue { i32, { i64, ptr } } %t21, 1
  %t23 = extractvalue { i32, { i64, ptr } } %t21, 0
  store i32 %t23, ptr %l52
  %t24 = icmp ne i32 %t23, 0
  br i1 %t24, label %bb9, label %ok.25, !prof !99
ok.25:
  store { i64, ptr } %t22, ptr %l51
  br label %bb8
bb8:
  %t26 = load { i64, ptr }, ptr %l51, !tbaa !27
  store { i64, ptr } %t26, ptr %l50, !tbaa !27
  br label %bb15
bb9:
  %t27 = load i32, ptr %l52, !tbaa !23
  %t28 = ashr i32 %t27, 16
  %t30 = icmp eq i32 %t28, 1
  store i1 %t30, ptr %l54, !tbaa !21
  %t31 = load i32, ptr %l52, !tbaa !23
  %t32 = ashr i32 %t31, 16
  %t34 = icmp eq i32 %t32, 1
  br i1 %t34, label %bb10, label %bb11
bb10:
  call void @__olang_errpay_pop()
  br label %bb11
bb11:
  br label %bb12
bb12:
  %t36 = load ptr, ptr %lp6
  %t37 = getelementptr %"compiler/bindgen:Translation", ptr %t36, i32 0, i32 3
  %t38 = load { i64, ptr }, ptr %t37, !tbaa !27
  store { i64, ptr } %t38, ptr %l57, !tbaa !27
  %t39 = load ptr, ptr %lp6
  %t40 = getelementptr %"compiler/bindgen:Translation", ptr %t39, i32 0, i32 3
  store { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d4, i32 0, i32 1) }, ptr %t40, !tbaa !27
  %t41 = load i1, ptr @olang_2esole_2ecompiler_2fbindgen_3aTranslation_2e3
  br i1 %t41, label %bb13, label %bb14
bb13:
  %t43 = load { i64, ptr }, ptr %l57
  %t44 = extractvalue { i64, ptr } %t43, 1
  call void @__olang_region_release(ptr %t44)
  store { i64, ptr } zeroinitializer, ptr %l57
  br label %bb14
bb14:
  %t45 = load ptr, ptr %lp6
  %t46 = load %"compiler/bindgen:Translation", ptr %t45
  call void @__olang_scope_close(ptr %s0)
  store %"compiler/bindgen:Translation" %t46, ptr %rv
  br label %ret
bb15:
  %t48 = load { i64, ptr }, ptr %l50, !tbaa !27
  store { i64, ptr } %t48, ptr %l7, !tbaa !27
  %t49 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t51 = insertvalue [2 x { i64, ptr }] undef, { i64, ptr } %t49, 0
  %t52 = insertvalue [2 x { i64, ptr }] %t51, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d5, i32 0, i32 1) }, 1
  store [2 x { i64, ptr }] %t52, ptr %l8
  %t55 = insertvalue { i64, ptr } undef, i64 2, 0
  %t56 = insertvalue { i64, ptr } %t55, ptr %l8, 1
  %t58 = call { i64, ptr } @std_2ffilepath_2eJoin(ptr %s0, ptr %s0, { i64, ptr } %t56)
  store { i64, ptr } %t58, ptr %l64
  br label %bb16
bb16:
  %t59 = load { i64, ptr }, ptr %l64, !tbaa !27
  store { i64, ptr } %t59, ptr %l9, !tbaa !27
  %t60 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t61 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t63 = extractvalue { i64, ptr } %t61, 1
  %t64 = extractvalue { i64, ptr } %t61, 0
  %t65 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d6, i32 0, i32 1) }, 1
  %t66 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d6, i32 0, i32 1) }, 0
  %t67 = add i64 %t64, %t66
  %t68 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t67)
  call void @olang_textcopy(ptr %t68, ptr %t63, i64 %t64)
  %t69 = getelementptr i8, ptr %t68, i64 %t64
  call void @olang_textcopy(ptr %t69, ptr %t65, i64 %t66)
  %t70 = insertvalue { i64, ptr } undef, i64 %t67, 0
  %t71 = insertvalue { i64, ptr } %t70, ptr %t68, 1
  %t74 = extractvalue { i64, ptr } %t71, 0
  %t75 = extractvalue { i64, ptr } %t71, 1
  %t76 = mul i64 %t74, 1
  %t77 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t76)
  call void @llvm.memcpy.p0.p0.i64(ptr %t77, ptr %t75, i64 %t76, i1 false)
  %t78 = insertvalue { i64, ptr } undef, i64 %t74, 0
  %t79 = insertvalue { i64, ptr } %t78, ptr %t77, 1
  %t82 = call i32 @std_2fos_2eWriteFile(ptr %s0, ptr %s0, { i64, ptr } %t60, { i64, ptr } %t79)
  store i32 %t82, ptr %l70
  %t83 = icmp ne i32 %t82, 0
  br i1 %t83, label %bb18, label %ok.84, !prof !99
ok.84:
  br label %bb17
bb17:
  br label %bb36
bb18:
  %t85 = load i32, ptr %l70, !tbaa !23
  %t86 = ashr i32 %t85, 16
  %t88 = icmp eq i32 %t86, 1
  store i1 %t88, ptr %l72, !tbaa !21
  %t89 = load i32, ptr %l70, !tbaa !23
  %t90 = ashr i32 %t89, 16
  %t92 = icmp eq i32 %t90, 1
  br i1 %t92, label %bb19, label %bb20
bb19:
  call void @__olang_errpay_pop()
  br label %bb20
bb20:
  br label %bb21
bb21:
  %t94 = load ptr, ptr %lp6
  %t95 = getelementptr %"compiler/bindgen:Translation", ptr %t94, i32 0, i32 3
  %t96 = load { i64, ptr }, ptr %t95, !tbaa !27
  store { i64, ptr } %t96, ptr %l75, !tbaa !27
  %t97 = load ptr, ptr %lp6
  %t98 = getelementptr %"compiler/bindgen:Translation", ptr %t97, i32 0, i32 3
  store { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d7, i32 0, i32 1) }, ptr %t98, !tbaa !27
  %t99 = load i1, ptr @olang_2esole_2ecompiler_2fbindgen_3aTranslation_2e3
  br i1 %t99, label %bb22, label %bb23
bb22:
  %t101 = load { i64, ptr }, ptr %l75
  %t102 = extractvalue { i64, ptr } %t101, 1
  call void @__olang_region_release(ptr %t102)
  store { i64, ptr } zeroinitializer, ptr %l75
  br label %bb23
bb23:
  %t103 = load ptr, ptr %lp6
  %t104 = load %"compiler/bindgen:Translation", ptr %t103
  store %"compiler/bindgen:Translation" %t104, ptr %l77
  %t105 = call ptr @__olang_scope_hold(ptr %v6)
  %t106 = ptrtoint ptr %t105 to i64
  store i64 %t106, ptr %l78, !tbaa !24
  %t107 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e0
  br i1 %t107, label %bb24, label %bb25
bb24:
  %t109 = call ptr @__olang_region_make_part(ptr %v6)
  %t110 = ptrtoint ptr %t109 to i64
  store i64 %t110, ptr %l78, !tbaa !24
  br label %bb25
bb25:
  %t111 = getelementptr %"compiler/bindgen:Translation", ptr %l77, i32 0, i32 2
  %t112 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t111, i32 0, i32 0
  %t113 = load { i64, ptr }, ptr %t112, !tbaa !27
  store { i64, ptr } %t113, ptr %l80, !tbaa !27
  %t114 = load { i64, ptr }, ptr %l80, !tbaa !27
  %t115 = extractvalue { i64, ptr } %t114, 0
  store i64 %t115, ptr %l81, !tbaa !24
  %t116 = load i64, ptr %l81, !tbaa !24
  %t117 = mul i64 %t116, 16
  %t118 = load i64, ptr %l78
  %t119 = inttoptr i64 %t118 to ptr
  %t120 = call ptr @__olang_held_alloc(ptr %t119, i64 %t117)
  %t121 = insertvalue { i64, ptr } undef, i64 %t116, 0
  %t122 = insertvalue { i64, ptr } %t121, ptr %t120, 1
  store { i64, ptr } %t122, ptr %l82, !tbaa !27
  %t123 = getelementptr { i64, ptr }, ptr %l82, i32 0, i32 1
  %t124 = load ptr, ptr %t123, !tbaa !27
  %t125 = getelementptr { i64, ptr }, ptr %l80, i32 0, i32 1
  %t126 = load ptr, ptr %t125, !tbaa !27
  %t127 = load i64, ptr %l81, !tbaa !24
  %t128 = mul i64 %t127, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t124, ptr %t126, i64 %t128, i1 false)
  %t129 = load { i64, ptr }, ptr %l82, !tbaa !27
  %t130 = getelementptr %"compiler/bindgen:Translation", ptr %l77, i32 0, i32 2
  %t131 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t130, i32 0, i32 0
  store { i64, ptr } %t129, ptr %t131, !tbaa !27
  %t132 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e0
  br i1 %t132, label %bb26, label %bb27
bb26:
  %t134 = getelementptr %"compiler/bindgen:Translation", ptr %l77, i32 0, i32 2
  %t135 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t134, i32 0, i32 0
  %t136 = load { i64, ptr }, ptr %t135, !tbaa !27
  %t137 = extractvalue { i64, ptr } %t136, 0
  %t139 = icmp eq i64 %t137, 0
  br i1 %t139, label %bb28, label %bb29
bb27:
  %t141 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t143 = call i32 @std_2fos_2eRemoveAll(ptr %s0, { i64, ptr } %t141)
  store i32 %t143, ptr %l87
  %t144 = icmp ne i32 %t143, 0
  br i1 %t144, label %bb31, label %ok.145, !prof !99
ok.145:
  br label %bb30
bb28:
  %t146 = getelementptr %"compiler/bindgen:Translation", ptr %l77, i32 0, i32 2
  %t147 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t146, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t147, !tbaa !27
  br label %bb29
bb29:
  %t148 = getelementptr %"compiler/bindgen:Translation", ptr %l77, i32 0, i32 2
  %t149 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t148, i32 0, i32 0
  %t150 = load i64, ptr %l78
  %t151 = inttoptr i64 %t150 to ptr
  %t152 = load { i64, ptr }, ptr %t149
  %t153 = extractvalue { i64, ptr } %t152, 1
  %t154 = call ptr @__olang_region_or(ptr %t153, ptr null)
  %t155 = icmp ne ptr %t154, null
  %t156 = select i1 %t155, ptr %t154, ptr null
  call void @__olang_region_settle_in(ptr %t151, ptr %t156)
  br label %bb27
bb30:
  br label %bb35
bb31:
  %t157 = load i32, ptr %l87, !tbaa !23
  %t158 = ashr i32 %t157, 16
  %t160 = icmp eq i32 %t158, 1
  store i1 %t160, ptr %l89, !tbaa !21
  %t161 = load i32, ptr %l87, !tbaa !23
  %t162 = ashr i32 %t161, 16
  %t164 = icmp eq i32 %t162, 1
  br i1 %t164, label %bb32, label %bb33
bb32:
  call void @__olang_errpay_pop()
  br label %bb33
bb33:
  br label %bb34
bb34:
  br label %bb35
bb35:
  call void @__olang_scope_close(ptr %s0)
  %t166 = load %"compiler/bindgen:Translation", ptr %l77
  store %"compiler/bindgen:Translation" %t166, ptr %rv
  br label %ret
bb36:
  %t167 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t169 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t167, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d8, i32 0, i32 1) })
  store i1 %t169, ptr %l93
  br label %bb37
bb37:
  %t170 = load i1, ptr %l93, !tbaa !21
  %t171 = xor i1 %t170, true
  br i1 %t171, label %bb38, label %bb39
bb38:
  %t173 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t175 = extractvalue { i64, ptr } %t173, 1
  %t176 = extractvalue { i64, ptr } %t173, 0
  %t177 = call ptr @__olang_scope_alloc(ptr %v6, i64 %t176)
  call void @olang_textcopy(ptr %t177, ptr %t175, i64 %t176)
  %t178 = insertvalue { i64, ptr } undef, i64 %t176, 0
  %t179 = insertvalue { i64, ptr } %t178, ptr %t177, 1
  store { i64, ptr } %t179, ptr %l95, !tbaa !27
  br label %bb40
bb39:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d9, i32 0, i32 1) }, ptr %l95, !tbaa !27
  br label %bb40
bb40:
  %t183 = load { i64, ptr }, ptr %l95, !tbaa !27
  call void @compiler_2fbindgen_3agen_2ector(ptr %t182, ptr %v6, ptr %v6, { i64, ptr } %t183)
  call void @llvm.memmove.p0.p0.i64(ptr %l99, ptr %t182, i64 1128, i1 false)
  br label %bb41
bb41:
  %t184 = call ptr @__olang_scope_alloc_a(ptr %v6, i64 1128, i64 8)
  store ptr %t184, ptr %lp10
  %t185 = load ptr, ptr %lp10
  call void @llvm.memmove.p0.p0.i64(ptr %t185, ptr %l99, i64 1128, i1 false)
  %t186 = load ptr, ptr %lp10
  %t187 = getelementptr %"compiler/bindgen:gen", ptr %t186, i32 0, i32 1
  store i1 true, ptr %t187, !tbaa !21
  %t188 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t188, ptr %l11, !tbaa !27
  store i64 0, ptr %l12, !tbaa !24
  %t190 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t192 = extractvalue { i64, ptr } %t190, 0
  store i64 %t192, ptr %l13, !tbaa !24
  br label %bb42
bb42:
  store %olang.scope zeroinitializer, ptr %s10
  %t194 = load i64, ptr %l12, !tbaa !24
  %t195 = load i64, ptr %l13, !tbaa !24
  %t198 = icmp slt i64 %t194, %t195
  %t200 = xor i1 %t198, true
  br i1 %t200, label %bb43, label %bb44
bb43:
  call void @__olang_scope_close(ptr %s10)
  br label %bb55
bb44:
  br label %bb45
bb45:
  %t202 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t202, ptr %l107, !tbaa !27
  %t203 = load i64, ptr %l12, !tbaa !24
  %t205 = getelementptr { i64, ptr }, ptr %l107, i32 0, i32 1
  %t206 = load ptr, ptr %t205, !tbaa !27
  %t207 = getelementptr { i64, ptr }, ptr %t206, i64 %t203
  %t208 = load { i64, ptr }, ptr %t207, !tbaa !37
  store { i64, ptr } %t208, ptr %l14, !tbaa !27
  %t210 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t212 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v3, ptr %s10, { i64, ptr } %t210, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d10, i32 0, i32 1) })
  store i1 %t212, ptr %l111
  br label %bb46
bb46:
  %t213 = load i1, ptr %l111, !tbaa !21
  br i1 %t213, label %bb47, label %bb48
bb47:
  %t214 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d11, i32 0, i32 1) }, ptr %l115, !tbaa !27
  %t217 = load { i64, ptr }, ptr %l115, !tbaa !27
  %t218 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v3, ptr %s10, { i64, ptr } %t214, { i64, ptr } %t217)
  store i1 %t218, ptr %l116
  br label %bb49
bb48:
  store i1 false, ptr %l112, !tbaa !21
  br label %bb50
bb49:
  %t219 = load i1, ptr %l116, !tbaa !21
  store i1 %t219, ptr %l112, !tbaa !21
  br label %bb50
bb50:
  %t220 = load i1, ptr %l112, !tbaa !21
  br i1 %t220, label %bb51, label %bb52
bb51:
  %t221 = load ptr, ptr %lp10
  %t222 = getelementptr %"compiler/bindgen:gen", ptr %t221, i32 0, i32 2
  store i1 true, ptr %t222, !tbaa !21
  br label %bb53
bb52:
  br label %bb53
bb53:
  call void @__olang_scope_close(ptr %s10)
  br label %bb54
bb54:
  %t223 = load i64, ptr %l12, !tbaa !24
  %t226 = add i64 %t223, 1
  store i64 %t226, ptr %l12, !tbaa !24
  br label %bb42
bb55:
  %t229 = load ptr, ptr %lp10
  %t230 = getelementptr %"compiler/bindgen:gen", ptr %t229, i32 0, i32 3
  %t231 = load { i64, ptr }, ptr %t230, !tbaa !27
  store { i64, ptr } %t231, ptr %l121, !tbaa !27
  %t233 = load ptr, ptr %lp10
  %t234 = getelementptr %"compiler/bindgen:gen", ptr %t233, i32 0, i32 3
  store { i64, ptr } %a4, ptr %t234, !tbaa !27
  %t235 = load i1, ptr @olang_2esole_2ecompiler_2fbindgen_3agen_2e3
  br i1 %t235, label %bb56, label %bb57
bb56:
  %t237 = load { i64, ptr }, ptr %l121
  %t238 = extractvalue { i64, ptr } %t237, 1
  call void @__olang_region_release(ptr %t238)
  store { i64, ptr } zeroinitializer, ptr %l121
  br label %bb57
bb57:
  %t239 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t240 = load ptr, ptr %lp10
  %t241 = getelementptr %"compiler/bindgen:gen", ptr %t240, i32 0, i32 4
  %t242 = load { i64, ptr }, ptr %t241, !tbaa !27
  store { i64, ptr } %t242, ptr %l124, !tbaa !27
  %t244 = load ptr, ptr %lp10
  %t245 = getelementptr %"compiler/bindgen:gen", ptr %t244, i32 0, i32 4
  store { i64, ptr } %t239, ptr %t245, !tbaa !27
  %t246 = load i1, ptr @olang_2esole_2ecompiler_2fbindgen_3agen_2e4
  br i1 %t246, label %bb58, label %bb59
bb58:
  %t248 = load { i64, ptr }, ptr %l124
  %t249 = extractvalue { i64, ptr } %t248, 1
  call void @__olang_region_release(ptr %t249)
  store { i64, ptr } zeroinitializer, ptr %l124
  br label %bb59
bb59:
  %t250 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t250, ptr %l126
  br label %bb60
bb60:
  %t251 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l126
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t251, ptr %l15
  %t252 = load { i64, ptr }, ptr %l2, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %v2, ptr %l15, { i64, ptr } %t252)
  br label %bb61
bb61:
  %t255 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t255, ptr %l16, !tbaa !27
  store i64 0, ptr %l17, !tbaa !24
  %t257 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t259 = extractvalue { i64, ptr } %t257, 0
  store i64 %t259, ptr %l18, !tbaa !24
  br label %bb62
bb62:
  %t261 = load i64, ptr %l17, !tbaa !24
  %t262 = load i64, ptr %l18, !tbaa !24
  %t265 = icmp slt i64 %t261, %t262
  %t267 = xor i1 %t265, true
  br i1 %t267, label %bb63, label %bb64
bb63:
  br label %bb68
bb64:
  br label %bb65
bb65:
  %t269 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t269, ptr %l136, !tbaa !27
  %t270 = load i64, ptr %l17, !tbaa !24
  %t272 = getelementptr { i64, ptr }, ptr %l136, i32 0, i32 1
  %t273 = load ptr, ptr %t272, !tbaa !27
  %t274 = getelementptr { i64, ptr }, ptr %t273, i64 %t270
  %t275 = load { i64, ptr }, ptr %t274, !tbaa !37
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %v3, ptr %l15, { i64, ptr } %t275)
  br label %bb66
bb66:
  br label %bb67
bb67:
  %t280 = load i64, ptr %l17, !tbaa !24
  %t283 = add i64 %t280, 1
  store i64 %t283, ptr %l17, !tbaa !24
  br label %bb62
bb68:
  %t285 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t286 = insertvalue [6 x { i64, ptr }] undef, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d12, i32 0, i32 1) }, 0
  %t287 = insertvalue [6 x { i64, ptr }] %t286, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d13, i32 0, i32 1) }, 1
  %t288 = insertvalue [6 x { i64, ptr }] %t287, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d14, i32 0, i32 1) }, 2
  %t289 = insertvalue [6 x { i64, ptr }] %t288, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d15, i32 0, i32 1) }, 3
  %t290 = insertvalue [6 x { i64, ptr }] %t289, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d16, i32 0, i32 1) }, 4
  %t292 = insertvalue [6 x { i64, ptr }] %t290, { i64, ptr } %t285, 5
  %t294 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 96, i64 8)
  store [6 x { i64, ptr }] %t292, ptr %t294
  store ptr %t294, ptr %l20
  store i64 0, ptr %l21, !tbaa !24
  %t296 = load ptr, ptr %l20
  store i64 6, ptr %l22, !tbaa !24
  br label %bb69
bb69:
  %t299 = load i64, ptr %l21, !tbaa !24
  %t300 = load i64, ptr %l22, !tbaa !24
  %t303 = icmp slt i64 %t299, %t300
  %t305 = xor i1 %t303, true
  br i1 %t305, label %bb70, label %bb71
bb70:
  br label %bb75
bb71:
  br label %bb72
bb72:
  %t307 = load ptr, ptr %l20
  %t308 = load i64, ptr %l21, !tbaa !24
  %t311 = getelementptr [6 x { i64, ptr }], ptr %t307, i64 0, i64 %t308
  %t312 = load { i64, ptr }, ptr %t311, !tbaa !37
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l15, { i64, ptr } %t312)
  br label %bb73
bb73:
  br label %bb74
bb74:
  %t317 = load i64, ptr %l21, !tbaa !24
  %t320 = add i64 %t317, 1
  store i64 %t320, ptr %l21, !tbaa !24
  br label %bb69
bb75:
  %t323 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %s0, ptr %s0, ptr %l15)
  store { i64, ptr } %t323, ptr %l163
  br label %bb76
bb76:
  %t324 = load { i64, ptr }, ptr %l163, !tbaa !27
  %t325 = call { i32, %"std/os:Output" } @compiler_2fbindgen_2eclangSays(ptr %s0, ptr %v6, { i64, ptr } %t324)
  %t326 = extractvalue { i32, %"std/os:Output" } %t325, 1
  %t327 = extractvalue { i32, %"std/os:Output" } %t325, 0
  store i32 %t327, ptr %l165
  %t328 = icmp ne i32 %t327, 0
  br i1 %t328, label %bb78, label %ok.329, !prof !99
ok.329:
  store %"std/os:Output" %t326, ptr %l164
  br label %bb77
bb77:
  %t330 = load %"std/os:Output", ptr %l164
  store %"std/os:Output" %t330, ptr %l161
  br label %bb94
bb78:
  %t331 = load i32, ptr %l165, !tbaa !23
  %t332 = ashr i32 %t331, 16
  %t334 = icmp eq i32 %t332, 1
  store i1 %t334, ptr %l167, !tbaa !21
  br label %bb79
bb79:
  %t335 = load ptr, ptr %lp6
  %t336 = getelementptr %"compiler/bindgen:Translation", ptr %t335, i32 0, i32 3
  %t337 = load { i64, ptr }, ptr %t336, !tbaa !27
  store { i64, ptr } %t337, ptr %l168, !tbaa !27
  %t338 = load ptr, ptr %lp6
  %t339 = getelementptr %"compiler/bindgen:Translation", ptr %t338, i32 0, i32 3
  store { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d17, i32 0, i32 1) }, ptr %t339, !tbaa !27
  %t340 = load i1, ptr @olang_2esole_2ecompiler_2fbindgen_3aTranslation_2e3
  br i1 %t340, label %bb80, label %bb81
bb80:
  %t342 = load { i64, ptr }, ptr %l168
  %t343 = extractvalue { i64, ptr } %t342, 1
  call void @__olang_region_release(ptr %t343)
  store { i64, ptr } zeroinitializer, ptr %l168
  br label %bb81
bb81:
  %t344 = load ptr, ptr %lp6
  %t345 = load %"compiler/bindgen:Translation", ptr %t344
  store %"compiler/bindgen:Translation" %t345, ptr %l170
  %t346 = call ptr @__olang_scope_hold(ptr %v6)
  %t347 = ptrtoint ptr %t346 to i64
  store i64 %t347, ptr %l171, !tbaa !24
  %t348 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e0
  br i1 %t348, label %bb82, label %bb83
bb82:
  %t350 = call ptr @__olang_region_make_part(ptr %v6)
  %t351 = ptrtoint ptr %t350 to i64
  store i64 %t351, ptr %l171, !tbaa !24
  br label %bb83
bb83:
  %t352 = getelementptr %"compiler/bindgen:Translation", ptr %l170, i32 0, i32 2
  %t353 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t352, i32 0, i32 0
  %t354 = load { i64, ptr }, ptr %t353, !tbaa !27
  store { i64, ptr } %t354, ptr %l173, !tbaa !27
  %t355 = load { i64, ptr }, ptr %l173, !tbaa !27
  %t356 = extractvalue { i64, ptr } %t355, 0
  store i64 %t356, ptr %l174, !tbaa !24
  %t357 = load i64, ptr %l174, !tbaa !24
  %t358 = mul i64 %t357, 16
  %t359 = load i64, ptr %l171
  %t360 = inttoptr i64 %t359 to ptr
  %t361 = call ptr @__olang_held_alloc(ptr %t360, i64 %t358)
  %t362 = insertvalue { i64, ptr } undef, i64 %t357, 0
  %t363 = insertvalue { i64, ptr } %t362, ptr %t361, 1
  store { i64, ptr } %t363, ptr %l175, !tbaa !27
  %t364 = getelementptr { i64, ptr }, ptr %l175, i32 0, i32 1
  %t365 = load ptr, ptr %t364, !tbaa !27
  %t366 = getelementptr { i64, ptr }, ptr %l173, i32 0, i32 1
  %t367 = load ptr, ptr %t366, !tbaa !27
  %t368 = load i64, ptr %l174, !tbaa !24
  %t369 = mul i64 %t368, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t365, ptr %t367, i64 %t369, i1 false)
  %t370 = load { i64, ptr }, ptr %l175, !tbaa !27
  %t371 = getelementptr %"compiler/bindgen:Translation", ptr %l170, i32 0, i32 2
  %t372 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t371, i32 0, i32 0
  store { i64, ptr } %t370, ptr %t372, !tbaa !27
  %t373 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e0
  br i1 %t373, label %bb84, label %bb85
bb84:
  %t375 = getelementptr %"compiler/bindgen:Translation", ptr %l170, i32 0, i32 2
  %t376 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t375, i32 0, i32 0
  %t377 = load { i64, ptr }, ptr %t376, !tbaa !27
  %t378 = extractvalue { i64, ptr } %t377, 0
  %t380 = icmp eq i64 %t378, 0
  br i1 %t380, label %bb86, label %bb87
bb85:
  %t382 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t384 = call i32 @std_2fos_2eRemoveAll(ptr %s0, { i64, ptr } %t382)
  store i32 %t384, ptr %l180
  %t385 = icmp ne i32 %t384, 0
  br i1 %t385, label %bb89, label %ok.386, !prof !99
ok.386:
  br label %bb88
bb86:
  %t387 = getelementptr %"compiler/bindgen:Translation", ptr %l170, i32 0, i32 2
  %t388 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t387, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t388, !tbaa !27
  br label %bb87
bb87:
  %t389 = getelementptr %"compiler/bindgen:Translation", ptr %l170, i32 0, i32 2
  %t390 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t389, i32 0, i32 0
  %t391 = load i64, ptr %l171
  %t392 = inttoptr i64 %t391 to ptr
  %t393 = load { i64, ptr }, ptr %t390
  %t394 = extractvalue { i64, ptr } %t393, 1
  %t395 = call ptr @__olang_region_or(ptr %t394, ptr null)
  %t396 = icmp ne ptr %t395, null
  %t397 = select i1 %t396, ptr %t395, ptr null
  call void @__olang_region_settle_in(ptr %t392, ptr %t397)
  br label %bb85
bb88:
  br label %bb93
bb89:
  %t398 = load i32, ptr %l180, !tbaa !23
  %t399 = ashr i32 %t398, 16
  %t401 = icmp eq i32 %t399, 1
  store i1 %t401, ptr %l182, !tbaa !21
  %t402 = load i32, ptr %l180, !tbaa !23
  %t403 = ashr i32 %t402, 16
  %t405 = icmp eq i32 %t403, 1
  br i1 %t405, label %bb90, label %bb91
bb90:
  call void @__olang_errpay_pop()
  br label %bb91
bb91:
  br label %bb92
bb92:
  br label %bb93
bb93:
  call void @__olang_scope_close(ptr %s0)
  %t407 = load %"compiler/bindgen:Translation", ptr %l170
  store %"compiler/bindgen:Translation" %t407, ptr %rv
  br label %ret
bb94:
  %t408 = call ptr @__olang_scope_alloc_a(ptr %v6, i64 40, i64 8)
  store ptr %t408, ptr %lp24
  %t409 = load %"std/os:Output", ptr %l161
  %t410 = load ptr, ptr %lp24
  store %"std/os:Output" %t409, ptr %t410
  %t411 = load ptr, ptr %lp24
  %t412 = getelementptr %"std/os:Output", ptr %t411, i32 0, i32 0
  %t413 = load i32, ptr %t412, !tbaa !23
  %t415 = icmp ne i32 %t413, 0
  br i1 %t415, label %bb95, label %bb96
bb95:
  store %olang.scope zeroinitializer, ptr %s23
  %t417 = load ptr, ptr %lp24
  %t418 = getelementptr %"std/os:Output", ptr %t417, i32 0, i32 2
  %t419 = load { i64, ptr }, ptr %t418, !tbaa !27
  store { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d18, i32 0, i32 1) }, ptr %l189, !tbaa !27
  %t422 = load { i64, ptr }, ptr %l189, !tbaa !27
  %t423 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v6, ptr %s23, { i64, ptr } %t419, { i64, ptr } %t422)
  store i1 %t423, ptr %l190
  br label %bb97
bb96:
  br label %bb115
bb97:
  %t424 = load i1, ptr %l190, !tbaa !21
  %t425 = load ptr, ptr %lp6
  %t426 = getelementptr %"compiler/bindgen:Translation", ptr %t425, i32 0, i32 4
  store i1 %t424, ptr %t426, !tbaa !21
  %t427 = call ptr @__olang_scope_hold(ptr %v6)
  %t428 = ptrtoint ptr %t427 to i64
  store i64 %t428, ptr %l191, !tbaa !24
  %t429 = load i1, ptr @olang_2esole_2ecompiler_2fbindgen_3aTranslation_2e3
  br i1 %t429, label %bb98, label %bb99
bb98:
  %t431 = call ptr @__olang_region_make(ptr %v6)
  %t432 = ptrtoint ptr %t431 to i64
  store i64 %t432, ptr %l191, !tbaa !24
  br label %bb99
bb99:
  %t433 = load ptr, ptr %lp24
  %t434 = getelementptr %"std/os:Output", ptr %t433, i32 0, i32 2
  %t435 = load { i64, ptr }, ptr %t434, !tbaa !27
  %t436 = load i64, ptr %l191
  %t437 = inttoptr i64 %t436 to ptr
  %t439 = call { i64, ptr } @compiler_2fbindgen_2efirstError(ptr %v6, ptr %t437, { i64, ptr } %t435)
  store { i64, ptr } %t439, ptr %l194
  br label %bb100
bb100:
  %t440 = load { i64, ptr }, ptr %l194, !tbaa !27
  %t441 = load ptr, ptr %lp6
  %t442 = getelementptr %"compiler/bindgen:Translation", ptr %t441, i32 0, i32 3
  %t443 = load { i64, ptr }, ptr %t442, !tbaa !27
  store { i64, ptr } %t443, ptr %l196, !tbaa !27
  %t445 = load ptr, ptr %lp6
  %t446 = getelementptr %"compiler/bindgen:Translation", ptr %t445, i32 0, i32 3
  store { i64, ptr } %t440, ptr %t446, !tbaa !27
  %t447 = load i1, ptr @olang_2esole_2ecompiler_2fbindgen_3aTranslation_2e3
  br i1 %t447, label %bb101, label %bb102
bb101:
  %t449 = load { i64, ptr }, ptr %l196
  %t450 = extractvalue { i64, ptr } %t449, 1
  call void @__olang_region_release(ptr %t450)
  store { i64, ptr } zeroinitializer, ptr %l196
  br label %bb102
bb102:
  %t451 = load ptr, ptr %lp6
  %t452 = load %"compiler/bindgen:Translation", ptr %t451
  store %"compiler/bindgen:Translation" %t452, ptr %l198
  %t453 = call ptr @__olang_scope_hold(ptr %v6)
  %t454 = ptrtoint ptr %t453 to i64
  store i64 %t454, ptr %l199, !tbaa !24
  %t455 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e0
  br i1 %t455, label %bb103, label %bb104
bb103:
  %t457 = call ptr @__olang_region_make_part(ptr %v6)
  %t458 = ptrtoint ptr %t457 to i64
  store i64 %t458, ptr %l199, !tbaa !24
  br label %bb104
bb104:
  %t459 = getelementptr %"compiler/bindgen:Translation", ptr %l198, i32 0, i32 2
  %t460 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t459, i32 0, i32 0
  %t461 = load { i64, ptr }, ptr %t460, !tbaa !27
  store { i64, ptr } %t461, ptr %l201, !tbaa !27
  %t462 = load { i64, ptr }, ptr %l201, !tbaa !27
  %t463 = extractvalue { i64, ptr } %t462, 0
  store i64 %t463, ptr %l202, !tbaa !24
  %t464 = load i64, ptr %l202, !tbaa !24
  %t465 = mul i64 %t464, 16
  %t466 = load i64, ptr %l199
  %t467 = inttoptr i64 %t466 to ptr
  %t468 = call ptr @__olang_held_alloc(ptr %t467, i64 %t465)
  %t469 = insertvalue { i64, ptr } undef, i64 %t464, 0
  %t470 = insertvalue { i64, ptr } %t469, ptr %t468, 1
  store { i64, ptr } %t470, ptr %l203, !tbaa !27
  %t471 = getelementptr { i64, ptr }, ptr %l203, i32 0, i32 1
  %t472 = load ptr, ptr %t471, !tbaa !27
  %t473 = getelementptr { i64, ptr }, ptr %l201, i32 0, i32 1
  %t474 = load ptr, ptr %t473, !tbaa !27
  %t475 = load i64, ptr %l202, !tbaa !24
  %t476 = mul i64 %t475, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t472, ptr %t474, i64 %t476, i1 false)
  %t477 = load { i64, ptr }, ptr %l203, !tbaa !27
  %t478 = getelementptr %"compiler/bindgen:Translation", ptr %l198, i32 0, i32 2
  %t479 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t478, i32 0, i32 0
  store { i64, ptr } %t477, ptr %t479, !tbaa !27
  %t480 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e0
  br i1 %t480, label %bb105, label %bb106
bb105:
  %t482 = getelementptr %"compiler/bindgen:Translation", ptr %l198, i32 0, i32 2
  %t483 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t482, i32 0, i32 0
  %t484 = load { i64, ptr }, ptr %t483, !tbaa !27
  %t485 = extractvalue { i64, ptr } %t484, 0
  %t487 = icmp eq i64 %t485, 0
  br i1 %t487, label %bb107, label %bb108
bb106:
  call void @__olang_scope_close(ptr %s23)
  %t489 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t491 = call i32 @std_2fos_2eRemoveAll(ptr %s0, { i64, ptr } %t489)
  store i32 %t491, ptr %l208
  %t492 = icmp ne i32 %t491, 0
  br i1 %t492, label %bb110, label %ok.493, !prof !99
ok.493:
  br label %bb109
bb107:
  %t494 = getelementptr %"compiler/bindgen:Translation", ptr %l198, i32 0, i32 2
  %t495 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t494, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t495, !tbaa !27
  br label %bb108
bb108:
  %t496 = getelementptr %"compiler/bindgen:Translation", ptr %l198, i32 0, i32 2
  %t497 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t496, i32 0, i32 0
  %t498 = load i64, ptr %l199
  %t499 = inttoptr i64 %t498 to ptr
  %t500 = load { i64, ptr }, ptr %t497
  %t501 = extractvalue { i64, ptr } %t500, 1
  %t502 = call ptr @__olang_region_or(ptr %t501, ptr null)
  %t503 = icmp ne ptr %t502, null
  %t504 = select i1 %t503, ptr %t502, ptr null
  call void @__olang_region_settle_in(ptr %t499, ptr %t504)
  br label %bb106
bb109:
  br label %bb114
bb110:
  %t505 = load i32, ptr %l208, !tbaa !23
  %t506 = ashr i32 %t505, 16
  %t508 = icmp eq i32 %t506, 1
  store i1 %t508, ptr %l210, !tbaa !21
  %t509 = load i32, ptr %l208, !tbaa !23
  %t510 = ashr i32 %t509, 16
  %t512 = icmp eq i32 %t510, 1
  br i1 %t512, label %bb111, label %bb112
bb111:
  call void @__olang_errpay_pop()
  br label %bb112
bb112:
  br label %bb113
bb113:
  br label %bb114
bb114:
  call void @__olang_scope_close(ptr %s0)
  %t514 = load %"compiler/bindgen:Translation", ptr %l198
  store %"compiler/bindgen:Translation" %t514, ptr %rv
  br label %ret
bb115:
  %t515 = load ptr, ptr %lp10
  %t516 = load ptr, ptr %lp24
  %t517 = getelementptr %"std/os:Output", ptr %t516, i32 0, i32 1
  %t518 = load { i64, ptr }, ptr %t517, !tbaa !27
  %t519 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t520 = load ptr, ptr %lp6
  %t521 = getelementptr %"compiler/bindgen:Translation", ptr %t520, i32 0, i32 2
  call void @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ereadMacros(ptr %v6, ptr %v6, ptr %s0, ptr %s0, ptr %v6, ptr %t515, { i64, ptr } %t518, { i64, ptr } %t519, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d19, i32 0, i32 1) }, ptr %t521)
  br label %bb116
bb116:
  %t526 = load ptr, ptr %lp10
  %t528 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eintMacros(ptr %v6, ptr %s0, ptr %t526)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t528, ptr %l218
  br label %bb117
bb117:
  %t529 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l218
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t529, ptr %l25
  %t530 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t530, ptr %l219
  br label %bb118
bb118:
  %t531 = load %"std/prelude/text:StringBuilder", ptr %l219
  store %"std/prelude/text:StringBuilder" %t531, ptr %l26
  %t532 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t534 = extractvalue { i64, ptr } %t532, 1
  %t535 = extractvalue { i64, ptr } %t532, 0
  %t536 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d20, i32 0, i32 1) }, 1
  %t537 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d20, i32 0, i32 1) }, 0
  %t538 = add i64 %t535, %t537
  %t539 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t538)
  call void @olang_textcopy(ptr %t539, ptr %t534, i64 %t535)
  %t540 = getelementptr i8, ptr %t539, i64 %t535
  call void @olang_textcopy(ptr %t540, ptr %t536, i64 %t537)
  %t541 = insertvalue { i64, ptr } undef, i64 %t538, 0
  %t542 = insertvalue { i64, ptr } %t541, ptr %t539, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l26, { i64, ptr } %t542)
  br label %bb119
bb119:
  store ptr %l25, ptr %l27, !tbaa !29
  store i64 0, ptr %l28, !tbaa !24
  br label %bb120
bb120:
  store %olang.scope zeroinitializer, ptr %s29
  %t547 = load i64, ptr %l28, !tbaa !24
  store i64 %t547, ptr %l225, !tbaa !24
  %t548 = load ptr, ptr %l27, !tbaa !29
  %t550 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t548)
  store i64 %t550, ptr %l227
  br label %bb121
bb121:
  %t551 = load i64, ptr %l225, !tbaa !24
  %t552 = load i64, ptr %l227, !tbaa !24
  %t553 = icmp slt i64 %t551, %t552
  %t555 = xor i1 %t553, true
  br i1 %t555, label %bb122, label %bb123
bb122:
  call void @__olang_scope_close(ptr %s29)
  br label %bb129
bb123:
  br label %bb124
bb124:
  %t557 = load i64, ptr %l28, !tbaa !24
  store i64 %t557, ptr %l29, !tbaa !24
  %t559 = load ptr, ptr %l27, !tbaa !29
  %t560 = load i64, ptr %l28, !tbaa !24
  %t563 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t559, i64 %t560)
  store i64 %t563, ptr %l233
  br label %bb125
bb125:
  %t564 = load i64, ptr %l233, !tbaa !24
  store ptr %l26, ptr %l234, !tbaa !29
  %t565 = load i64, ptr %l29, !tbaa !24
  store i64 %t565, ptr %l235, !tbaa !24
  %t566 = load i64, ptr %l29, !tbaa !24
  store i64 %t566, ptr %l236, !tbaa !24
  %t567 = load ptr, ptr %lp10
  %t568 = getelementptr %"compiler/bindgen:gen", ptr %t567, i32 0, i32 13
  %t572 = call %"compiler/bindgen:cMacro" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3acMacro_3e_2eAt_3ccompiler_2fbindgen_3acMacro_3e(ptr %v6, ptr %v6, ptr %t568, i64 %t564)
  store %"compiler/bindgen:cMacro" %t572, ptr %l239
  br label %bb126
bb126:
  %t573 = getelementptr %"compiler/bindgen:cMacro", ptr %l239, i32 0, i32 0
  %t574 = load { i64, ptr }, ptr %t573, !tbaa !27
  %t575 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d21, i32 0, i32 1) }, 1
  %t576 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d21, i32 0, i32 1) }, 0
  %t577 = load i64, ptr %l235, !tbaa !24
  %t578 = call i64 @__olang_fmt_i64(ptr null, i64 %t577)
  %t579 = add i64 %t576, %t578
  %t580 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d22, i32 0, i32 1) }, 1
  %t581 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d22, i32 0, i32 1) }, 0
  %t582 = add i64 %t579, %t581
  %t583 = load i64, ptr %l236, !tbaa !24
  %t584 = call i64 @__olang_fmt_i64(ptr null, i64 %t583)
  %t585 = add i64 %t582, %t584
  %t586 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d23, i32 0, i32 1) }, 1
  %t587 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d23, i32 0, i32 1) }, 0
  %t588 = add i64 %t585, %t587
  %t590 = extractvalue { i64, ptr } %t574, 1
  %t591 = extractvalue { i64, ptr } %t574, 0
  %t592 = add i64 %t588, %t591
  %t593 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d24, i32 0, i32 1) }, 1
  %t594 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d24, i32 0, i32 1) }, 0
  %t595 = add i64 %t592, %t594
  %t596 = call ptr @__olang_scope_alloc(ptr %s29, i64 %t595)
  call void @olang_textcopy(ptr %t596, ptr %t575, i64 %t576)
  %t597 = getelementptr i8, ptr %t596, i64 %t576
  %t598 = call i64 @__olang_fmt_i64(ptr %t597, i64 %t577)
  %t599 = getelementptr i8, ptr %t597, i64 %t578
  call void @olang_textcopy(ptr %t599, ptr %t580, i64 %t581)
  %t600 = getelementptr i8, ptr %t599, i64 %t581
  %t601 = call i64 @__olang_fmt_i64(ptr %t600, i64 %t583)
  %t602 = getelementptr i8, ptr %t600, i64 %t584
  call void @olang_textcopy(ptr %t602, ptr %t586, i64 %t587)
  %t603 = getelementptr i8, ptr %t602, i64 %t587
  call void @olang_textcopy(ptr %t603, ptr %t590, i64 %t591)
  %t604 = getelementptr i8, ptr %t603, i64 %t591
  call void @olang_textcopy(ptr %t604, ptr %t593, i64 %t594)
  %t605 = insertvalue { i64, ptr } undef, i64 %t595, 0
  %t606 = insertvalue { i64, ptr } %t605, ptr %t596, 1
  %t608 = load ptr, ptr %l234, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s29, ptr %t608, { i64, ptr } %t606)
  br label %bb127
bb127:
  call void @__olang_scope_close(ptr %s29)
  br label %bb128
bb128:
  %t610 = load i64, ptr %l28, !tbaa !24
  %t613 = add i64 %t610, 1
  store i64 %t613, ptr %l28, !tbaa !24
  br label %bb120
bb129:
  %t615 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t615, ptr %l246, !tbaa !27
  %t617 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s0, ptr %l26)
  store { i64, ptr } %t617, ptr %l248
  br label %bb130
bb130:
  %t618 = load { i64, ptr }, ptr %l248, !tbaa !27
  %t620 = extractvalue { i64, ptr } %t618, 0
  %t621 = extractvalue { i64, ptr } %t618, 1
  %t622 = mul i64 %t620, 1
  %t623 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t622)
  call void @llvm.memcpy.p0.p0.i64(ptr %t623, ptr %t621, i64 %t622, i1 false)
  %t624 = insertvalue { i64, ptr } undef, i64 %t620, 0
  %t625 = insertvalue { i64, ptr } %t624, ptr %t623, 1
  %t626 = load { i64, ptr }, ptr %l246, !tbaa !27
  %t628 = call i32 @std_2fos_2eWriteFile(ptr %s0, ptr %s0, { i64, ptr } %t626, { i64, ptr } %t625)
  store i32 %t628, ptr %l251
  %t629 = icmp ne i32 %t628, 0
  br i1 %t629, label %bb132, label %ok.630, !prof !99
ok.630:
  br label %bb131
bb131:
  br label %bb150
bb132:
  %t631 = load i32, ptr %l251, !tbaa !23
  %t632 = ashr i32 %t631, 16
  %t634 = icmp eq i32 %t632, 1
  store i1 %t634, ptr %l253, !tbaa !21
  %t635 = load i32, ptr %l251, !tbaa !23
  %t636 = ashr i32 %t635, 16
  %t638 = icmp eq i32 %t636, 1
  br i1 %t638, label %bb133, label %bb134
bb133:
  call void @__olang_errpay_pop()
  br label %bb134
bb134:
  br label %bb135
bb135:
  %t640 = load ptr, ptr %lp6
  %t641 = getelementptr %"compiler/bindgen:Translation", ptr %t640, i32 0, i32 3
  %t642 = load { i64, ptr }, ptr %t641, !tbaa !27
  store { i64, ptr } %t642, ptr %l256, !tbaa !27
  %t643 = load ptr, ptr %lp6
  %t644 = getelementptr %"compiler/bindgen:Translation", ptr %t643, i32 0, i32 3
  store { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d25, i32 0, i32 1) }, ptr %t644, !tbaa !27
  %t645 = load i1, ptr @olang_2esole_2ecompiler_2fbindgen_3aTranslation_2e3
  br i1 %t645, label %bb136, label %bb137
bb136:
  %t647 = load { i64, ptr }, ptr %l256
  %t648 = extractvalue { i64, ptr } %t647, 1
  call void @__olang_region_release(ptr %t648)
  store { i64, ptr } zeroinitializer, ptr %l256
  br label %bb137
bb137:
  %t649 = load ptr, ptr %lp6
  %t650 = load %"compiler/bindgen:Translation", ptr %t649
  store %"compiler/bindgen:Translation" %t650, ptr %l258
  %t651 = call ptr @__olang_scope_hold(ptr %v6)
  %t652 = ptrtoint ptr %t651 to i64
  store i64 %t652, ptr %l259, !tbaa !24
  %t653 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e0
  br i1 %t653, label %bb138, label %bb139
bb138:
  %t655 = call ptr @__olang_region_make_part(ptr %v6)
  %t656 = ptrtoint ptr %t655 to i64
  store i64 %t656, ptr %l259, !tbaa !24
  br label %bb139
bb139:
  %t657 = getelementptr %"compiler/bindgen:Translation", ptr %l258, i32 0, i32 2
  %t658 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t657, i32 0, i32 0
  %t659 = load { i64, ptr }, ptr %t658, !tbaa !27
  store { i64, ptr } %t659, ptr %l261, !tbaa !27
  %t660 = load { i64, ptr }, ptr %l261, !tbaa !27
  %t661 = extractvalue { i64, ptr } %t660, 0
  store i64 %t661, ptr %l262, !tbaa !24
  %t662 = load i64, ptr %l262, !tbaa !24
  %t663 = mul i64 %t662, 16
  %t664 = load i64, ptr %l259
  %t665 = inttoptr i64 %t664 to ptr
  %t666 = call ptr @__olang_held_alloc(ptr %t665, i64 %t663)
  %t667 = insertvalue { i64, ptr } undef, i64 %t662, 0
  %t668 = insertvalue { i64, ptr } %t667, ptr %t666, 1
  store { i64, ptr } %t668, ptr %l263, !tbaa !27
  %t669 = getelementptr { i64, ptr }, ptr %l263, i32 0, i32 1
  %t670 = load ptr, ptr %t669, !tbaa !27
  %t671 = getelementptr { i64, ptr }, ptr %l261, i32 0, i32 1
  %t672 = load ptr, ptr %t671, !tbaa !27
  %t673 = load i64, ptr %l262, !tbaa !24
  %t674 = mul i64 %t673, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t670, ptr %t672, i64 %t674, i1 false)
  %t675 = load { i64, ptr }, ptr %l263, !tbaa !27
  %t676 = getelementptr %"compiler/bindgen:Translation", ptr %l258, i32 0, i32 2
  %t677 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t676, i32 0, i32 0
  store { i64, ptr } %t675, ptr %t677, !tbaa !27
  %t678 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e0
  br i1 %t678, label %bb140, label %bb141
bb140:
  %t680 = getelementptr %"compiler/bindgen:Translation", ptr %l258, i32 0, i32 2
  %t681 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t680, i32 0, i32 0
  %t682 = load { i64, ptr }, ptr %t681, !tbaa !27
  %t683 = extractvalue { i64, ptr } %t682, 0
  %t685 = icmp eq i64 %t683, 0
  br i1 %t685, label %bb142, label %bb143
bb141:
  %t687 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t689 = call i32 @std_2fos_2eRemoveAll(ptr %s0, { i64, ptr } %t687)
  store i32 %t689, ptr %l268
  %t690 = icmp ne i32 %t689, 0
  br i1 %t690, label %bb145, label %ok.691, !prof !99
ok.691:
  br label %bb144
bb142:
  %t692 = getelementptr %"compiler/bindgen:Translation", ptr %l258, i32 0, i32 2
  %t693 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t692, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t693, !tbaa !27
  br label %bb143
bb143:
  %t694 = getelementptr %"compiler/bindgen:Translation", ptr %l258, i32 0, i32 2
  %t695 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t694, i32 0, i32 0
  %t696 = load i64, ptr %l259
  %t697 = inttoptr i64 %t696 to ptr
  %t698 = load { i64, ptr }, ptr %t695
  %t699 = extractvalue { i64, ptr } %t698, 1
  %t700 = call ptr @__olang_region_or(ptr %t699, ptr null)
  %t701 = icmp ne ptr %t700, null
  %t702 = select i1 %t701, ptr %t700, ptr null
  call void @__olang_region_settle_in(ptr %t697, ptr %t702)
  br label %bb141
bb144:
  br label %bb149
bb145:
  %t703 = load i32, ptr %l268, !tbaa !23
  %t704 = ashr i32 %t703, 16
  %t706 = icmp eq i32 %t704, 1
  store i1 %t706, ptr %l270, !tbaa !21
  %t707 = load i32, ptr %l268, !tbaa !23
  %t708 = ashr i32 %t707, 16
  %t710 = icmp eq i32 %t708, 1
  br i1 %t710, label %bb146, label %bb147
bb146:
  call void @__olang_errpay_pop()
  br label %bb147
bb147:
  br label %bb148
bb148:
  br label %bb149
bb149:
  call void @__olang_scope_close(ptr %s0)
  %t712 = load %"compiler/bindgen:Translation", ptr %l258
  store %"compiler/bindgen:Translation" %t712, ptr %rv
  br label %ret
bb150:
  %t713 = load ptr, ptr %lp10
  %t714 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t715 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t716 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t721 = call { i32, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2edump(ptr %v6, ptr %v2, ptr %v3, ptr %s0, ptr %s0, ptr %t713, { i64, ptr } %t714, { i64, ptr } %t715, { i64, ptr } %t716)
  %t722 = extractvalue { i32, ptr } %t721, 1
  %t723 = extractvalue { i32, ptr } %t721, 0
  store i32 %t723, ptr %l279
  %t724 = icmp ne i32 %t723, 0
  br i1 %t724, label %bb152, label %ok.725, !prof !99
ok.725:
  store ptr %t722, ptr %l278
  br label %bb151
bb151:
  %t726 = load ptr, ptr %l278, !tbaa !29
  store ptr %t726, ptr %l273, !tbaa !29
  br label %bb168
bb152:
  %t727 = load i32, ptr %l279, !tbaa !23
  %t728 = ashr i32 %t727, 16
  %t730 = icmp eq i32 %t728, 1
  store i1 %t730, ptr %l281, !tbaa !21
  br label %bb153
bb153:
  %t731 = load ptr, ptr %lp10
  %t732 = getelementptr %"compiler/bindgen:gen", ptr %t731, i32 0, i32 26
  %t733 = load { i64, ptr }, ptr %t732, !tbaa !27
  %t734 = load ptr, ptr %lp6
  %t735 = getelementptr %"compiler/bindgen:Translation", ptr %t734, i32 0, i32 3
  %t736 = load { i64, ptr }, ptr %t735, !tbaa !27
  store { i64, ptr } %t736, ptr %l283, !tbaa !27
  %t738 = load ptr, ptr %lp6
  %t739 = getelementptr %"compiler/bindgen:Translation", ptr %t738, i32 0, i32 3
  store { i64, ptr } %t733, ptr %t739, !tbaa !27
  %t740 = load i1, ptr @olang_2esole_2ecompiler_2fbindgen_3aTranslation_2e3
  br i1 %t740, label %bb154, label %bb155
bb154:
  %t742 = load { i64, ptr }, ptr %l283
  %t743 = extractvalue { i64, ptr } %t742, 1
  call void @__olang_region_release(ptr %t743)
  store { i64, ptr } zeroinitializer, ptr %l283
  br label %bb155
bb155:
  %t744 = load ptr, ptr %lp6
  %t745 = load %"compiler/bindgen:Translation", ptr %t744
  store %"compiler/bindgen:Translation" %t745, ptr %l285
  %t746 = call ptr @__olang_scope_hold(ptr %v6)
  %t747 = ptrtoint ptr %t746 to i64
  store i64 %t747, ptr %l286, !tbaa !24
  %t748 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e0
  br i1 %t748, label %bb156, label %bb157
bb156:
  %t750 = call ptr @__olang_region_make_part(ptr %v6)
  %t751 = ptrtoint ptr %t750 to i64
  store i64 %t751, ptr %l286, !tbaa !24
  br label %bb157
bb157:
  %t752 = getelementptr %"compiler/bindgen:Translation", ptr %l285, i32 0, i32 2
  %t753 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t752, i32 0, i32 0
  %t754 = load { i64, ptr }, ptr %t753, !tbaa !27
  store { i64, ptr } %t754, ptr %l288, !tbaa !27
  %t755 = load { i64, ptr }, ptr %l288, !tbaa !27
  %t756 = extractvalue { i64, ptr } %t755, 0
  store i64 %t756, ptr %l289, !tbaa !24
  %t757 = load i64, ptr %l289, !tbaa !24
  %t758 = mul i64 %t757, 16
  %t759 = load i64, ptr %l286
  %t760 = inttoptr i64 %t759 to ptr
  %t761 = call ptr @__olang_held_alloc(ptr %t760, i64 %t758)
  %t762 = insertvalue { i64, ptr } undef, i64 %t757, 0
  %t763 = insertvalue { i64, ptr } %t762, ptr %t761, 1
  store { i64, ptr } %t763, ptr %l290, !tbaa !27
  %t764 = getelementptr { i64, ptr }, ptr %l290, i32 0, i32 1
  %t765 = load ptr, ptr %t764, !tbaa !27
  %t766 = getelementptr { i64, ptr }, ptr %l288, i32 0, i32 1
  %t767 = load ptr, ptr %t766, !tbaa !27
  %t768 = load i64, ptr %l289, !tbaa !24
  %t769 = mul i64 %t768, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t765, ptr %t767, i64 %t769, i1 false)
  %t770 = load { i64, ptr }, ptr %l290, !tbaa !27
  %t771 = getelementptr %"compiler/bindgen:Translation", ptr %l285, i32 0, i32 2
  %t772 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t771, i32 0, i32 0
  store { i64, ptr } %t770, ptr %t772, !tbaa !27
  %t773 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e0
  br i1 %t773, label %bb158, label %bb159
bb158:
  %t775 = getelementptr %"compiler/bindgen:Translation", ptr %l285, i32 0, i32 2
  %t776 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t775, i32 0, i32 0
  %t777 = load { i64, ptr }, ptr %t776, !tbaa !27
  %t778 = extractvalue { i64, ptr } %t777, 0
  %t780 = icmp eq i64 %t778, 0
  br i1 %t780, label %bb160, label %bb161
bb159:
  %t782 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t784 = call i32 @std_2fos_2eRemoveAll(ptr %s0, { i64, ptr } %t782)
  store i32 %t784, ptr %l295
  %t785 = icmp ne i32 %t784, 0
  br i1 %t785, label %bb163, label %ok.786, !prof !99
ok.786:
  br label %bb162
bb160:
  %t787 = getelementptr %"compiler/bindgen:Translation", ptr %l285, i32 0, i32 2
  %t788 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t787, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t788, !tbaa !27
  br label %bb161
bb161:
  %t789 = getelementptr %"compiler/bindgen:Translation", ptr %l285, i32 0, i32 2
  %t790 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t789, i32 0, i32 0
  %t791 = load i64, ptr %l286
  %t792 = inttoptr i64 %t791 to ptr
  %t793 = load { i64, ptr }, ptr %t790
  %t794 = extractvalue { i64, ptr } %t793, 1
  %t795 = call ptr @__olang_region_or(ptr %t794, ptr null)
  %t796 = icmp ne ptr %t795, null
  %t797 = select i1 %t796, ptr %t795, ptr null
  call void @__olang_region_settle_in(ptr %t792, ptr %t797)
  br label %bb159
bb162:
  br label %bb167
bb163:
  %t798 = load i32, ptr %l295, !tbaa !23
  %t799 = ashr i32 %t798, 16
  %t801 = icmp eq i32 %t799, 1
  store i1 %t801, ptr %l297, !tbaa !21
  %t802 = load i32, ptr %l295, !tbaa !23
  %t803 = ashr i32 %t802, 16
  %t805 = icmp eq i32 %t803, 1
  br i1 %t805, label %bb164, label %bb165
bb164:
  call void @__olang_errpay_pop()
  br label %bb165
bb165:
  br label %bb166
bb166:
  br label %bb167
bb167:
  call void @__olang_scope_close(ptr %s0)
  %t807 = load %"compiler/bindgen:Translation", ptr %l285
  store %"compiler/bindgen:Translation" %t807, ptr %rv
  br label %ret
bb168:
  %t808 = load ptr, ptr %l273, !tbaa !29
  store ptr %t808, ptr %l31, !tbaa !29
  %t809 = load ptr, ptr %lp10
  %t810 = load ptr, ptr %l31, !tbaa !29
  %t811 = load { i64, ptr }, ptr %l9, !tbaa !27
  call void @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eread(ptr %v6, ptr %s0, ptr %s0, ptr %t809, ptr %t810, { i64, ptr } %t811)
  br label %bb169
bb169:
  %t815 = load ptr, ptr %lp10
  %t816 = getelementptr %"compiler/bindgen:gen", ptr %t815, i32 0, i32 27
  store i64 0, ptr %t816, !tbaa !24
  store %olang.scope zeroinitializer, ptr %s40
  %t817 = load ptr, ptr %l31, !tbaa !29
  %t819 = call { i64, ptr } @compiler_2fbindgen_2einner(ptr %s0, ptr %s40, ptr %t817)
  store { i64, ptr } %t819, ptr %l304
  br label %bb170
bb170:
  %t820 = load { i64, ptr }, ptr %l304, !tbaa !27
  store { i64, ptr } %t820, ptr %l32, !tbaa !27
  store i64 0, ptr %l33, !tbaa !24
  %t822 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t824 = extractvalue { i64, ptr } %t822, 0
  store i64 %t824, ptr %l34, !tbaa !24
  br label %bb171
bb171:
  store %olang.scope zeroinitializer, ptr %s41
  %t826 = load i64, ptr %l33, !tbaa !24
  %t827 = load i64, ptr %l34, !tbaa !24
  %t830 = icmp slt i64 %t826, %t827
  %t832 = xor i1 %t830, true
  br i1 %t832, label %bb172, label %bb173
bb172:
  call void @__olang_scope_close(ptr %s41)
  br label %bb226
bb173:
  br label %bb174
bb174:
  %t834 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t834, ptr %l312, !tbaa !27
  %t835 = load i64, ptr %l33, !tbaa !24
  %t837 = getelementptr { i64, ptr }, ptr %l312, i32 0, i32 1
  %t838 = load ptr, ptr %t837, !tbaa !27
  %t839 = getelementptr ptr, ptr %t838, i64 %t835
  %t840 = load ptr, ptr %t839, !tbaa !39
  store ptr %t840, ptr %l35, !tbaa !29
  %t842 = load ptr, ptr %l35, !tbaa !29
  %t844 = call { i64, ptr } @compiler_2fbindgen_2etext(ptr %s40, ptr %s41, ptr %s41, ptr %t842, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d26, i32 0, i32 1) })
  store { i64, ptr } %t844, ptr %l316
  br label %bb175
bb175:
  %t845 = load { i64, ptr }, ptr %l316, !tbaa !27
  store { i64, ptr } %t845, ptr %l36, !tbaa !27
  %t846 = load ptr, ptr %l35, !tbaa !29
  %t848 = call { i64, ptr } @compiler_2fbindgen_2etext(ptr %s40, ptr %s41, ptr %s41, ptr %t846, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d27, i32 0, i32 1) })
  store { i64, ptr } %t848, ptr %l318
  br label %bb176
bb176:
  %t849 = load { i64, ptr }, ptr %l318, !tbaa !27
  %t851 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s41, ptr %s41, { i64, ptr } %t849, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d28, i32 0, i32 1) })
  store i1 %t851, ptr %l320
  br label %bb177
bb177:
  %t852 = load i1, ptr %l320, !tbaa !21
  %t853 = xor i1 %t852, true
  br i1 %t853, label %bb178, label %bb179
bb178:
  store i1 true, ptr %l322, !tbaa !21
  br label %bb181
bb179:
  %t855 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t857 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s41, ptr %s41, { i64, ptr } %t855, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d29, i32 0, i32 1) })
  store i1 %t857, ptr %l324
  br label %bb180
bb180:
  %t858 = load i1, ptr %l324, !tbaa !21
  %t859 = xor i1 %t858, true
  store i1 %t859, ptr %l322, !tbaa !21
  br label %bb181
bb181:
  %t861 = load i1, ptr %l322, !tbaa !21
  br i1 %t861, label %bb182, label %bb183
bb182:
  call void @__olang_scope_close(ptr %s41)
  br label %bb225
bb183:
  br label %bb184
bb184:
  %t862 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t864 = extractvalue { i64, ptr } %t862, 0
  store i64 %t864, ptr %l328, !tbaa !24
  %t865 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t866 = extractvalue { i64, ptr } %t865, 0
  store i64 %t866, ptr %l329, !tbaa !24
  %t867 = icmp sge i64 9, 0
  br i1 %t867, label %bb185, label %bb186
bb185:
  %t869 = load i64, ptr %l328, !tbaa !24
  %t870 = icmp sle i64 9, %t869
  br i1 %t870, label %bb187, label %bb188
bb186:
  call void @__olang_check_failed(ptr @olang_loc_b774a7292e99a958_2ba7e6e1e518c9cc)
  unreachable
bb187:
  %t872 = load i64, ptr %l328, !tbaa !24
  %t873 = load i64, ptr %l329, !tbaa !24
  %t874 = icmp sle i64 %t872, %t873
  br i1 %t874, label %bb189, label %bb190
bb188:
  call void @__olang_check_failed(ptr @olang_loc_b774a7292e99a958_2ba7e6e1e518c9cc)
  unreachable
bb189:
  %t876 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t877 = load ptr, ptr %t876, !tbaa !27
  %t878 = load i64, ptr %l328, !tbaa !24
  %t879 = getelementptr i8, ptr %t877, i64 9
  %t880 = sub i64 %t878, 9
  %t881 = insertvalue { i64, ptr } undef, i64 %t880, 0
  %t882 = insertvalue { i64, ptr } %t881, ptr %t879, 1
  store { i64, ptr } %t882, ptr %l333, !tbaa !27
  %t883 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s41, i64 10)
  %t884 = extractvalue { i32, i64 } %t883, 1
  %t885 = extractvalue { i32, i64 } %t883, 0
  store i32 %t885, ptr %l335
  %t886 = icmp ne i32 %t885, 0
  br i1 %t886, label %bb192, label %ok.887, !prof !99
ok.887:
  store i64 %t884, ptr %l334
  br label %bb191
bb190:
  call void @__olang_check_failed(ptr @olang_loc_b774a7292e99a958_2ba7e6e1e518c9cc)
  unreachable
bb191:
  %t888 = load { i64, ptr }, ptr %l333, !tbaa !27
  %t889 = load i64, ptr %l334, !tbaa !24
  %t890 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %s41, { i64, ptr } %t888, i64 %t889)
  %t891 = extractvalue { i32, i64 } %t890, 1
  %t892 = extractvalue { i32, i64 } %t890, 0
  store i32 %t892, ptr %l337
  %t893 = icmp ne i32 %t892, 0
  br i1 %t893, label %bb195, label %ok.894, !prof !99
ok.894:
  store i64 %t891, ptr %l336
  br label %bb194
bb192:
  br label %bb193
bb193:
  store i64 -1, ptr %l326, !tbaa !24
  br label %bb196
bb194:
  %t895 = load i64, ptr %l336, !tbaa !24
  store i64 %t895, ptr %l326, !tbaa !24
  br label %bb196
bb195:
  br label %bb193
bb196:
  %t896 = load i64, ptr %l326, !tbaa !24
  store i64 %t896, ptr %l37, !tbaa !24
  %t897 = load i64, ptr %l37, !tbaa !24
  %t899 = icmp slt i64 %t897, 0
  br i1 %t899, label %bb197, label %bb198
bb197:
  store i1 true, ptr %l340, !tbaa !21
  br label %bb200
bb198:
  %t901 = load i64, ptr %l37, !tbaa !24
  store i64 %t901, ptr %l341, !tbaa !24
  %t903 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l25)
  store i64 %t903, ptr %l343
  br label %bb199
bb199:
  %t904 = load i64, ptr %l341, !tbaa !24
  %t905 = load i64, ptr %l343, !tbaa !24
  %t906 = icmp sge i64 %t904, %t905
  store i1 %t906, ptr %l340, !tbaa !21
  br label %bb200
bb200:
  %t908 = load i1, ptr %l340, !tbaa !21
  br i1 %t908, label %bb201, label %bb202
bb201:
  call void @__olang_scope_close(ptr %s41)
  br label %bb225
bb202:
  br label %bb203
bb203:
  store %olang.scope zeroinitializer, ptr %s44
  %t909 = load ptr, ptr %l35, !tbaa !29
  %t911 = call { i64, ptr } @compiler_2fbindgen_2einner(ptr %s40, ptr %s44, ptr %t909)
  store { i64, ptr } %t911, ptr %l346
  br label %bb204
bb204:
  %t912 = load { i64, ptr }, ptr %l346, !tbaa !27
  store { i64, ptr } %t912, ptr %l38, !tbaa !27
  store i64 0, ptr %l39, !tbaa !24
  %t914 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t916 = extractvalue { i64, ptr } %t914, 0
  store i64 %t916, ptr %l40, !tbaa !24
  br label %bb205
bb205:
  store %olang.scope zeroinitializer, ptr %s45
  %t918 = load i64, ptr %l39, !tbaa !24
  %t919 = load i64, ptr %l40, !tbaa !24
  %t922 = icmp slt i64 %t918, %t919
  %t924 = xor i1 %t922, true
  br i1 %t924, label %bb206, label %bb207
bb206:
  call void @__olang_scope_close(ptr %s45)
  br label %bb224
bb207:
  br label %bb208
bb208:
  %t926 = load { i64, ptr }, ptr %l38, !tbaa !27
  store { i64, ptr } %t926, ptr %l354, !tbaa !27
  %t927 = load i64, ptr %l39, !tbaa !24
  %t929 = getelementptr { i64, ptr }, ptr %l354, i32 0, i32 1
  %t930 = load ptr, ptr %t929, !tbaa !27
  %t931 = getelementptr ptr, ptr %t930, i64 %t927
  %t932 = load ptr, ptr %t931, !tbaa !39
  %t936 = call { i64, ptr } @compiler_2fbindgen_2econstValue(ptr %s44, ptr %s45, ptr %t932)
  store { i64, ptr } %t936, ptr %l358
  br label %bb209
bb209:
  %t937 = load { i64, ptr }, ptr %l358, !tbaa !27
  store { i64, ptr } %t937, ptr %l42, !tbaa !27
  %t938 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t940 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s45, ptr %s45, { i64, ptr } %t938, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d30, i32 0, i32 1) })
  store i1 %t940, ptr %l360
  br label %bb210
bb210:
  %t941 = load i1, ptr %l360, !tbaa !21
  br i1 %t941, label %bb211, label %bb212
bb211:
  call void @__olang_scope_close(ptr %s45)
  br label %bb223
bb212:
  br label %bb213
bb213:
  %t942 = load { i64, ptr }, ptr %l42, !tbaa !27
  store { i64, ptr } %t942, ptr %l362, !tbaa !27
  %t943 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s45, i64 10)
  %t944 = extractvalue { i32, i64 } %t943, 1
  %t945 = extractvalue { i32, i64 } %t943, 0
  store i32 %t945, ptr %l364
  %t946 = icmp ne i32 %t945, 0
  br i1 %t946, label %bb215, label %ok.947, !prof !99
ok.947:
  store i64 %t944, ptr %l363
  br label %bb214
bb214:
  %t948 = load { i64, ptr }, ptr %l362, !tbaa !27
  %t949 = load i64, ptr %l363, !tbaa !24
  %t950 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %s45, { i64, ptr } %t948, i64 %t949)
  %t951 = extractvalue { i32, i64 } %t950, 1
  %t952 = extractvalue { i32, i64 } %t950, 0
  store i32 %t952, ptr %l366
  %t953 = icmp ne i32 %t952, 0
  br i1 %t953, label %bb218, label %ok.954, !prof !99
ok.954:
  store i64 %t951, ptr %l365
  br label %bb217
bb215:
  br label %bb216
bb216:
  call void @__olang_scope_close(ptr %s45)
  br label %bb223
bb217:
  %t955 = load i64, ptr %l365, !tbaa !24
  store i64 %t955, ptr %l361, !tbaa !24
  br label %bb219
bb218:
  br label %bb216
bb219:
  %t956 = load i64, ptr %l361, !tbaa !24
  store i64 %t956, ptr %l43, !tbaa !24
  %t957 = load ptr, ptr %lp10
  store ptr %t957, ptr %l367, !tbaa !29
  %t958 = load ptr, ptr %lp10
  %t959 = getelementptr %"compiler/bindgen:gen", ptr %t958, i32 0, i32 13
  store ptr %t959, ptr %l368, !tbaa !29
  %t960 = load i64, ptr %l37, !tbaa !24
  %t963 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l25, i64 %t960)
  store i64 %t963, ptr %l371
  br label %bb220
bb220:
  %t964 = load ptr, ptr %l368, !tbaa !29
  %t965 = load i64, ptr %l371, !tbaa !24
  %t966 = call %"compiler/bindgen:cMacro" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3acMacro_3e_2eAt_3ccompiler_2fbindgen_3acMacro_3e(ptr %v6, ptr %v6, ptr %t964, i64 %t965)
  store %"compiler/bindgen:cMacro" %t966, ptr %l372
  br label %bb221
bb221:
  %t967 = getelementptr %"compiler/bindgen:cMacro", ptr %l372, i32 0, i32 0
  %t968 = load { i64, ptr }, ptr %t967, !tbaa !27
  %t969 = load i64, ptr %l43, !tbaa !24
  %t970 = load ptr, ptr %l367, !tbaa !29
  call void @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2econstant(ptr %v6, ptr %v6, ptr %t970, { i64, ptr } %t968, i64 %t969)
  br label %bb222
bb222:
  call void @__olang_scope_close(ptr %s45)
  br label %bb223
bb223:
  %t973 = load i64, ptr %l39, !tbaa !24
  %t976 = add i64 %t973, 1
  store i64 %t976, ptr %l39, !tbaa !24
  br label %bb205
bb224:
  call void @__olang_scope_close(ptr %s44)
  call void @__olang_scope_close(ptr %s41)
  br label %bb225
bb225:
  %t978 = load i64, ptr %l33, !tbaa !24
  %t981 = add i64 %t978, 1
  store i64 %t981, ptr %l33, !tbaa !24
  br label %bb171
bb226:
  call void @__olang_scope_close(ptr %s40)
  %t983 = load ptr, ptr %lp10
  call void @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eotherConsts(ptr %v6, ptr %t983)
  br label %bb227
bb227:
  %t985 = load ptr, ptr %lp10
  %t986 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t987 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t988 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t989 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t995 = call i32 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2esizes(ptr %v6, ptr %v2, ptr %v3, ptr %s0, ptr %v0, ptr %t985, { i64, ptr } %t986, { i64, ptr } %t987, { i64, ptr } %t988, { i64, ptr } %t989)
  store i32 %t995, ptr %l387
  %t996 = icmp ne i32 %t995, 0
  br i1 %t996, label %bb229, label %ok.997, !prof !99
ok.997:
  br label %bb228
bb228:
  br label %bb245
bb229:
  %t998 = load i32, ptr %l387, !tbaa !23
  %t999 = ashr i32 %t998, 16
  %t1001 = icmp eq i32 %t999, 1
  store i1 %t1001, ptr %l389, !tbaa !21
  br label %bb230
bb230:
  %t1002 = load ptr, ptr %lp10
  %t1003 = getelementptr %"compiler/bindgen:gen", ptr %t1002, i32 0, i32 26
  %t1004 = load { i64, ptr }, ptr %t1003, !tbaa !27
  %t1005 = load ptr, ptr %lp6
  %t1006 = getelementptr %"compiler/bindgen:Translation", ptr %t1005, i32 0, i32 3
  %t1007 = load { i64, ptr }, ptr %t1006, !tbaa !27
  store { i64, ptr } %t1007, ptr %l391, !tbaa !27
  %t1009 = load ptr, ptr %lp6
  %t1010 = getelementptr %"compiler/bindgen:Translation", ptr %t1009, i32 0, i32 3
  store { i64, ptr } %t1004, ptr %t1010, !tbaa !27
  %t1011 = load i1, ptr @olang_2esole_2ecompiler_2fbindgen_3aTranslation_2e3
  br i1 %t1011, label %bb231, label %bb232
bb231:
  %t1013 = load { i64, ptr }, ptr %l391
  %t1014 = extractvalue { i64, ptr } %t1013, 1
  call void @__olang_region_release(ptr %t1014)
  store { i64, ptr } zeroinitializer, ptr %l391
  br label %bb232
bb232:
  %t1015 = load ptr, ptr %lp6
  %t1016 = load %"compiler/bindgen:Translation", ptr %t1015
  store %"compiler/bindgen:Translation" %t1016, ptr %l393
  %t1017 = call ptr @__olang_scope_hold(ptr %v6)
  %t1018 = ptrtoint ptr %t1017 to i64
  store i64 %t1018, ptr %l394, !tbaa !24
  %t1019 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e0
  br i1 %t1019, label %bb233, label %bb234
bb233:
  %t1021 = call ptr @__olang_region_make_part(ptr %v6)
  %t1022 = ptrtoint ptr %t1021 to i64
  store i64 %t1022, ptr %l394, !tbaa !24
  br label %bb234
bb234:
  %t1023 = getelementptr %"compiler/bindgen:Translation", ptr %l393, i32 0, i32 2
  %t1024 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t1023, i32 0, i32 0
  %t1025 = load { i64, ptr }, ptr %t1024, !tbaa !27
  store { i64, ptr } %t1025, ptr %l396, !tbaa !27
  %t1026 = load { i64, ptr }, ptr %l396, !tbaa !27
  %t1027 = extractvalue { i64, ptr } %t1026, 0
  store i64 %t1027, ptr %l397, !tbaa !24
  %t1028 = load i64, ptr %l397, !tbaa !24
  %t1029 = mul i64 %t1028, 16
  %t1030 = load i64, ptr %l394
  %t1031 = inttoptr i64 %t1030 to ptr
  %t1032 = call ptr @__olang_held_alloc(ptr %t1031, i64 %t1029)
  %t1033 = insertvalue { i64, ptr } undef, i64 %t1028, 0
  %t1034 = insertvalue { i64, ptr } %t1033, ptr %t1032, 1
  store { i64, ptr } %t1034, ptr %l398, !tbaa !27
  %t1035 = getelementptr { i64, ptr }, ptr %l398, i32 0, i32 1
  %t1036 = load ptr, ptr %t1035, !tbaa !27
  %t1037 = getelementptr { i64, ptr }, ptr %l396, i32 0, i32 1
  %t1038 = load ptr, ptr %t1037, !tbaa !27
  %t1039 = load i64, ptr %l397, !tbaa !24
  %t1040 = mul i64 %t1039, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t1036, ptr %t1038, i64 %t1040, i1 false)
  %t1041 = load { i64, ptr }, ptr %l398, !tbaa !27
  %t1042 = getelementptr %"compiler/bindgen:Translation", ptr %l393, i32 0, i32 2
  %t1043 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t1042, i32 0, i32 0
  store { i64, ptr } %t1041, ptr %t1043, !tbaa !27
  %t1044 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e0
  br i1 %t1044, label %bb235, label %bb236
bb235:
  %t1046 = getelementptr %"compiler/bindgen:Translation", ptr %l393, i32 0, i32 2
  %t1047 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t1046, i32 0, i32 0
  %t1048 = load { i64, ptr }, ptr %t1047, !tbaa !27
  %t1049 = extractvalue { i64, ptr } %t1048, 0
  %t1051 = icmp eq i64 %t1049, 0
  br i1 %t1051, label %bb237, label %bb238
bb236:
  %t1053 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t1055 = call i32 @std_2fos_2eRemoveAll(ptr %s0, { i64, ptr } %t1053)
  store i32 %t1055, ptr %l403
  %t1056 = icmp ne i32 %t1055, 0
  br i1 %t1056, label %bb240, label %ok.1057, !prof !99
ok.1057:
  br label %bb239
bb237:
  %t1058 = getelementptr %"compiler/bindgen:Translation", ptr %l393, i32 0, i32 2
  %t1059 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t1058, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t1059, !tbaa !27
  br label %bb238
bb238:
  %t1060 = getelementptr %"compiler/bindgen:Translation", ptr %l393, i32 0, i32 2
  %t1061 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t1060, i32 0, i32 0
  %t1062 = load i64, ptr %l394
  %t1063 = inttoptr i64 %t1062 to ptr
  %t1064 = load { i64, ptr }, ptr %t1061
  %t1065 = extractvalue { i64, ptr } %t1064, 1
  %t1066 = call ptr @__olang_region_or(ptr %t1065, ptr null)
  %t1067 = icmp ne ptr %t1066, null
  %t1068 = select i1 %t1067, ptr %t1066, ptr null
  call void @__olang_region_settle_in(ptr %t1063, ptr %t1068)
  br label %bb236
bb239:
  br label %bb244
bb240:
  %t1069 = load i32, ptr %l403, !tbaa !23
  %t1070 = ashr i32 %t1069, 16
  %t1072 = icmp eq i32 %t1070, 1
  store i1 %t1072, ptr %l405, !tbaa !21
  %t1073 = load i32, ptr %l403, !tbaa !23
  %t1074 = ashr i32 %t1073, 16
  %t1076 = icmp eq i32 %t1074, 1
  br i1 %t1076, label %bb241, label %bb242
bb241:
  call void @__olang_errpay_pop()
  br label %bb242
bb242:
  br label %bb243
bb243:
  br label %bb244
bb244:
  call void @__olang_scope_close(ptr %s0)
  %t1078 = load %"compiler/bindgen:Translation", ptr %l393
  store %"compiler/bindgen:Translation" %t1078, ptr %rv
  br label %ret
bb245:
  %t1079 = call ptr @__olang_scope_hold(ptr %v6)
  %t1080 = ptrtoint ptr %t1079 to i64
  store i64 %t1080, ptr %l408, !tbaa !24
  %t1081 = load i1, ptr @olang_2esole_2ecompiler_2fbindgen_3aTranslation_2e0
  br i1 %t1081, label %bb246, label %bb247
bb246:
  %t1083 = call ptr @__olang_region_make(ptr %v6)
  %t1084 = ptrtoint ptr %t1083 to i64
  store i64 %t1084, ptr %l408, !tbaa !24
  br label %bb247
bb247:
  %t1085 = load ptr, ptr %lp10
  %t1086 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t1087 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d31, i32 0, i32 1) }, 1
  %t1088 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d31, i32 0, i32 1) }, 0
  %t1090 = extractvalue { i64, ptr } %t1086, 1
  %t1091 = extractvalue { i64, ptr } %t1086, 0
  %t1092 = add i64 %t1088, %t1091
  %t1093 = extractvalue { i64, ptr } { i64 70, ptr getelementptr inbounds (<{ i64, [70 x i8] }>, ptr @.d32, i32 0, i32 1) }, 1
  %t1094 = extractvalue { i64, ptr } { i64 70, ptr getelementptr inbounds (<{ i64, [70 x i8] }>, ptr @.d32, i32 0, i32 1) }, 0
  %t1095 = add i64 %t1092, %t1094
  %t1096 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1095)
  call void @olang_textcopy(ptr %t1096, ptr %t1087, i64 %t1088)
  %t1097 = getelementptr i8, ptr %t1096, i64 %t1088
  call void @olang_textcopy(ptr %t1097, ptr %t1090, i64 %t1091)
  %t1098 = getelementptr i8, ptr %t1097, i64 %t1091
  call void @olang_textcopy(ptr %t1098, ptr %t1093, i64 %t1094)
  %t1099 = insertvalue { i64, ptr } undef, i64 %t1095, 0
  %t1100 = insertvalue { i64, ptr } %t1099, ptr %t1096, 1
  %t1102 = load i64, ptr %l408
  %t1103 = inttoptr i64 %t1102 to ptr
  %t1106 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ewrite(ptr %v6, ptr %s0, ptr %t1103, ptr %t1085, { i64, ptr } %t1100)
  store { i64, ptr } %t1106, ptr %l414
  br label %bb248
bb248:
  %t1107 = load { i64, ptr }, ptr %l414, !tbaa !27
  %t1108 = load ptr, ptr %lp6
  %t1109 = getelementptr %"compiler/bindgen:Translation", ptr %t1108, i32 0, i32 0
  %t1110 = load { i64, ptr }, ptr %t1109, !tbaa !27
  store { i64, ptr } %t1110, ptr %l416, !tbaa !27
  %t1112 = load ptr, ptr %lp6
  %t1113 = getelementptr %"compiler/bindgen:Translation", ptr %t1112, i32 0, i32 0
  store { i64, ptr } %t1107, ptr %t1113, !tbaa !27
  %t1114 = load i1, ptr @olang_2esole_2ecompiler_2fbindgen_3aTranslation_2e0
  br i1 %t1114, label %bb249, label %bb250
bb249:
  %t1116 = load { i64, ptr }, ptr %l416
  %t1117 = extractvalue { i64, ptr } %t1116, 1
  call void @__olang_region_release(ptr %t1117)
  store { i64, ptr } zeroinitializer, ptr %l416
  br label %bb250
bb250:
  %t1118 = load ptr, ptr %lp10
  %t1119 = getelementptr %"compiler/bindgen:gen", ptr %t1118, i32 0, i32 21
  %t1121 = call i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eLen(ptr %v6, ptr %t1119)
  store i64 %t1121, ptr %l419
  br label %bb251
bb251:
  %t1122 = load i64, ptr %l419, !tbaa !24
  %t1123 = icmp sgt i64 %t1122, 0
  br i1 %t1123, label %bb252, label %bb253
bb252:
  store i1 true, ptr %l421, !tbaa !21
  br label %bb255
bb253:
  %t1125 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t1127 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t1125, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d33, i32 0, i32 1) })
  store i1 %t1127, ptr %l423
  br label %bb254
bb254:
  %t1128 = load i1, ptr %l423, !tbaa !21
  %t1129 = xor i1 %t1128, true
  store i1 %t1129, ptr %l421, !tbaa !21
  br label %bb255
bb255:
  %t1131 = load i1, ptr %l421, !tbaa !21
  br i1 %t1131, label %bb256, label %bb257
bb256:
  store %olang.scope zeroinitializer, ptr %s55
  %t1132 = call ptr @__olang_scope_hold(ptr %v6)
  %t1133 = ptrtoint ptr %t1132 to i64
  store i64 %t1133, ptr %l425, !tbaa !24
  %t1134 = load i1, ptr @olang_2esole_2ecompiler_2fbindgen_3aTranslation_2e1
  br i1 %t1134, label %bb258, label %bb259
bb257:
  br label %bb263
bb258:
  %t1136 = call ptr @__olang_region_make(ptr %v6)
  %t1137 = ptrtoint ptr %t1136 to i64
  store i64 %t1137, ptr %l425, !tbaa !24
  br label %bb259
bb259:
  %t1138 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t1138, ptr %l427, !tbaa !27
  %t1139 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t1139, ptr %l428, !tbaa !27
  %t1140 = load ptr, ptr %lp10
  %t1141 = getelementptr %"compiler/bindgen:gen", ptr %t1140, i32 0, i32 21
  %t1143 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v6, ptr %s55, ptr %t1141)
  store { i64, ptr } %t1143, ptr %l430
  br label %bb260
bb260:
  %t1144 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d34, i32 0, i32 1) }, 1
  %t1145 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d34, i32 0, i32 1) }, 0
  %t1146 = load { i64, ptr }, ptr %l427, !tbaa !27
  %t1147 = extractvalue { i64, ptr } %t1146, 1
  %t1148 = extractvalue { i64, ptr } %t1146, 0
  %t1149 = add i64 %t1145, %t1148
  %t1150 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d35, i32 0, i32 1) }, 1
  %t1151 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d35, i32 0, i32 1) }, 0
  %t1152 = add i64 %t1149, %t1151
  %t1153 = load { i64, ptr }, ptr %l428, !tbaa !27
  %t1154 = extractvalue { i64, ptr } %t1153, 1
  %t1155 = extractvalue { i64, ptr } %t1153, 0
  %t1156 = add i64 %t1152, %t1155
  %t1157 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d36, i32 0, i32 1) }, 1
  %t1158 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d36, i32 0, i32 1) }, 0
  %t1159 = add i64 %t1156, %t1158
  %t1160 = load { i64, ptr }, ptr %l430, !tbaa !27
  %t1161 = extractvalue { i64, ptr } %t1160, 1
  %t1162 = extractvalue { i64, ptr } %t1160, 0
  %t1163 = add i64 %t1159, %t1162
  %t1164 = load i64, ptr %l425
  %t1165 = inttoptr i64 %t1164 to ptr
  %t1166 = call ptr @__olang_held_alloc(ptr %t1165, i64 %t1163)
  call void @olang_textcopy(ptr %t1166, ptr %t1144, i64 %t1145)
  %t1167 = getelementptr i8, ptr %t1166, i64 %t1145
  call void @olang_textcopy(ptr %t1167, ptr %t1147, i64 %t1148)
  %t1168 = getelementptr i8, ptr %t1167, i64 %t1148
  call void @olang_textcopy(ptr %t1168, ptr %t1150, i64 %t1151)
  %t1169 = getelementptr i8, ptr %t1168, i64 %t1151
  call void @olang_textcopy(ptr %t1169, ptr %t1154, i64 %t1155)
  %t1170 = getelementptr i8, ptr %t1169, i64 %t1155
  call void @olang_textcopy(ptr %t1170, ptr %t1157, i64 %t1158)
  %t1171 = getelementptr i8, ptr %t1170, i64 %t1158
  call void @olang_textcopy(ptr %t1171, ptr %t1161, i64 %t1162)
  %t1172 = insertvalue { i64, ptr } undef, i64 %t1163, 0
  %t1173 = insertvalue { i64, ptr } %t1172, ptr %t1166, 1
  %t1175 = load ptr, ptr %lp6
  %t1176 = getelementptr %"compiler/bindgen:Translation", ptr %t1175, i32 0, i32 1
  %t1177 = load { i64, ptr }, ptr %t1176, !tbaa !27
  store { i64, ptr } %t1177, ptr %l433, !tbaa !27
  %t1179 = load ptr, ptr %lp6
  %t1180 = getelementptr %"compiler/bindgen:Translation", ptr %t1179, i32 0, i32 1
  store { i64, ptr } %t1173, ptr %t1180, !tbaa !27
  %t1181 = load i1, ptr @olang_2esole_2ecompiler_2fbindgen_3aTranslation_2e1
  br i1 %t1181, label %bb261, label %bb262
bb261:
  %t1183 = load { i64, ptr }, ptr %l433
  %t1184 = extractvalue { i64, ptr } %t1183, 1
  call void @__olang_region_release(ptr %t1184)
  store { i64, ptr } zeroinitializer, ptr %l433
  br label %bb262
bb262:
  call void @__olang_scope_close(ptr %s55)
  br label %bb263
bb263:
  %t1185 = load ptr, ptr %lp6
  %t1186 = load %"compiler/bindgen:Translation", ptr %t1185
  store %"compiler/bindgen:Translation" %t1186, ptr %l435
  %t1187 = call ptr @__olang_scope_hold(ptr %v6)
  %t1188 = ptrtoint ptr %t1187 to i64
  store i64 %t1188, ptr %l436, !tbaa !24
  %t1189 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e0
  br i1 %t1189, label %bb264, label %bb265
bb264:
  %t1191 = call ptr @__olang_region_make_part(ptr %v6)
  %t1192 = ptrtoint ptr %t1191 to i64
  store i64 %t1192, ptr %l436, !tbaa !24
  br label %bb265
bb265:
  %t1193 = getelementptr %"compiler/bindgen:Translation", ptr %l435, i32 0, i32 2
  %t1194 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t1193, i32 0, i32 0
  %t1195 = load { i64, ptr }, ptr %t1194, !tbaa !27
  store { i64, ptr } %t1195, ptr %l438, !tbaa !27
  %t1196 = load { i64, ptr }, ptr %l438, !tbaa !27
  %t1197 = extractvalue { i64, ptr } %t1196, 0
  store i64 %t1197, ptr %l439, !tbaa !24
  %t1198 = load i64, ptr %l439, !tbaa !24
  %t1199 = mul i64 %t1198, 16
  %t1200 = load i64, ptr %l436
  %t1201 = inttoptr i64 %t1200 to ptr
  %t1202 = call ptr @__olang_held_alloc(ptr %t1201, i64 %t1199)
  %t1203 = insertvalue { i64, ptr } undef, i64 %t1198, 0
  %t1204 = insertvalue { i64, ptr } %t1203, ptr %t1202, 1
  store { i64, ptr } %t1204, ptr %l440, !tbaa !27
  %t1205 = getelementptr { i64, ptr }, ptr %l440, i32 0, i32 1
  %t1206 = load ptr, ptr %t1205, !tbaa !27
  %t1207 = getelementptr { i64, ptr }, ptr %l438, i32 0, i32 1
  %t1208 = load ptr, ptr %t1207, !tbaa !27
  %t1209 = load i64, ptr %l439, !tbaa !24
  %t1210 = mul i64 %t1209, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t1206, ptr %t1208, i64 %t1210, i1 false)
  %t1211 = load { i64, ptr }, ptr %l440, !tbaa !27
  %t1212 = getelementptr %"compiler/bindgen:Translation", ptr %l435, i32 0, i32 2
  %t1213 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t1212, i32 0, i32 0
  store { i64, ptr } %t1211, ptr %t1213, !tbaa !27
  %t1214 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e0
  br i1 %t1214, label %bb266, label %bb267
bb266:
  %t1216 = getelementptr %"compiler/bindgen:Translation", ptr %l435, i32 0, i32 2
  %t1217 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t1216, i32 0, i32 0
  %t1218 = load { i64, ptr }, ptr %t1217, !tbaa !27
  %t1219 = extractvalue { i64, ptr } %t1218, 0
  %t1221 = icmp eq i64 %t1219, 0
  br i1 %t1221, label %bb268, label %bb269
bb267:
  %t1223 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t1225 = call i32 @std_2fos_2eRemoveAll(ptr %s0, { i64, ptr } %t1223)
  store i32 %t1225, ptr %l445
  %t1226 = icmp ne i32 %t1225, 0
  br i1 %t1226, label %bb271, label %ok.1227, !prof !99
ok.1227:
  br label %bb270
bb268:
  %t1228 = getelementptr %"compiler/bindgen:Translation", ptr %l435, i32 0, i32 2
  %t1229 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t1228, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t1229, !tbaa !27
  br label %bb269
bb269:
  %t1230 = getelementptr %"compiler/bindgen:Translation", ptr %l435, i32 0, i32 2
  %t1231 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t1230, i32 0, i32 0
  %t1232 = load i64, ptr %l436
  %t1233 = inttoptr i64 %t1232 to ptr
  %t1234 = load { i64, ptr }, ptr %t1231
  %t1235 = extractvalue { i64, ptr } %t1234, 1
  %t1236 = call ptr @__olang_region_or(ptr %t1235, ptr null)
  %t1237 = icmp ne ptr %t1236, null
  %t1238 = select i1 %t1237, ptr %t1236, ptr null
  call void @__olang_region_settle_in(ptr %t1233, ptr %t1238)
  br label %bb267
bb270:
  br label %bb275
bb271:
  %t1239 = load i32, ptr %l445, !tbaa !23
  %t1240 = ashr i32 %t1239, 16
  %t1242 = icmp eq i32 %t1240, 1
  store i1 %t1242, ptr %l447, !tbaa !21
  %t1243 = load i32, ptr %l445, !tbaa !23
  %t1244 = ashr i32 %t1243, 16
  %t1246 = icmp eq i32 %t1244, 1
  br i1 %t1246, label %bb272, label %bb273
bb272:
  call void @__olang_errpay_pop()
  br label %bb273
bb273:
  br label %bb274
bb274:
  br label %bb275
bb275:
  call void @__olang_scope_close(ptr %s0)
  %t1248 = load %"compiler/bindgen:Translation", ptr %l435
  store %"compiler/bindgen:Translation" %t1248, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/bindgen:Translation", ptr %rv
  ret %"compiler/bindgen:Translation" %rr
}

define dso_local { i64, ptr } @compiler_2fbindgen_2ebitfieldType(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l3 = alloca i1
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca { i64, ptr }
  %l14 = alloca i1
  %l15 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d37, i32 0, i32 1) })
  store i1 %t3, ptr %l3
  br label %bb1
bb1:
  %t4 = load i1, ptr %l3, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  %t5 = load i64, ptr %l1, !tbaa !24
  %t7 = icmp eq i64 %t5, 1
  br i1 %t7, label %bb4, label %bb5
bb3:
  br label %bb7
bb4:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d38, i32 0, i32 1) }, ptr %l7, !tbaa !27
  %t9 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t9, ptr %l6, !tbaa !27
  br label %bb6
bb5:
  %t11 = load i64, ptr %l1, !tbaa !24
  %t12 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d39, i32 0, i32 1) }, 1
  %t13 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d39, i32 0, i32 1) }, 0
  %t15 = call i64 @__olang_fmt_i64(ptr null, i64 %t11)
  %t16 = add i64 %t13, %t15
  %t17 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t16)
  call void @olang_textcopy(ptr %t17, ptr %t12, i64 %t13)
  %t18 = getelementptr i8, ptr %t17, i64 %t13
  %t19 = call i64 @__olang_fmt_i64(ptr %t18, i64 %t11)
  %t20 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t17, 1
  store { i64, ptr } %t21, ptr %l6, !tbaa !27
  br label %bb6
bb6:
  %t23 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t24 = extractvalue { i64, ptr } %t23, 0
  store i64 %t24, ptr %l11, !tbaa !24
  %t25 = load i64, ptr %l11, !tbaa !24
  %t26 = mul i64 %t25, 1
  %t27 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t26)
  %t28 = insertvalue { i64, ptr } undef, i64 %t25, 0
  %t29 = insertvalue { i64, ptr } %t28, ptr %t27, 1
  store { i64, ptr } %t29, ptr %l12, !tbaa !27
  %t30 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !27
  %t32 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !27
  %t34 = load i64, ptr %l11, !tbaa !24
  %t35 = mul i64 %t34, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t31, ptr %t33, i64 %t35, i1 false)
  %t36 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t36, ptr %l6, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t37 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t37, ptr %rv
  br label %ret
bb7:
  %t38 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t40 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t38, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d40, i32 0, i32 1) })
  store i1 %t40, ptr %l14
  br label %bb8
bb8:
  %t41 = load i1, ptr %l14, !tbaa !21
  br i1 %t41, label %bb9, label %bb10
bb9:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d41, i32 0, i32 1) }, ptr %l15, !tbaa !27
  br label %bb11
bb10:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d42, i32 0, i32 1) }, ptr %l15, !tbaa !27
  br label %bb11
bb11:
  %t42 = load i64, ptr %l1, !tbaa !24
  %t43 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t44 = extractvalue { i64, ptr } %t43, 1
  %t45 = extractvalue { i64, ptr } %t43, 0
  %t47 = call i64 @__olang_fmt_i64(ptr null, i64 %t42)
  %t48 = add i64 %t45, %t47
  %t49 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t48)
  call void @olang_textcopy(ptr %t49, ptr %t44, i64 %t45)
  %t50 = getelementptr i8, ptr %t49, i64 %t45
  %t51 = call i64 @__olang_fmt_i64(ptr %t50, i64 %t42)
  %t52 = insertvalue { i64, ptr } undef, i64 %t48, 0
  %t53 = insertvalue { i64, ptr } %t52, ptr %t49, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t53, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i32, i64 } @compiler_2fbindgen_2echarValue(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i8
  %l7 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l16 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l31 = alloca { i64, ptr }
  %l35 = alloca i64
  %l36 = alloca { i64, ptr }
  %l39 = alloca i64
  %l40 = alloca i64
  %l44 = alloca { i64, ptr }
  %l45 = alloca i64
  %l46 = alloca i32
  %l47 = alloca i64
  %l48 = alloca i32
  %l51 = alloca i1
  %l52 = alloca i64
  %l53 = alloca { i64, ptr }
  %l56 = alloca i64
  %l57 = alloca i64
  %l61 = alloca { i64, ptr }
  %l62 = alloca i64
  %l63 = alloca i32
  %l64 = alloca i64
  %l65 = alloca i32
  %l67 = alloca i64
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %rv = alloca { i32, i64 }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp slt i64 %t3, 3
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t8 = insertvalue { i32, i64 } zeroinitializer, i32 65536, 0
  store { i32, i64 } %t8, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t9 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t9, ptr %l7, !tbaa !27
  %t10 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  %t14 = sub i64 %t12, 1
  store i64 %t14, ptr %l10, !tbaa !24
  %t15 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t16 = extractvalue { i64, ptr } %t15, 0
  store i64 %t16, ptr %l11, !tbaa !24
  %t17 = icmp sge i64 1, 0
  br i1 %t17, label %bb4, label %bb5
bb4:
  %t19 = load i64, ptr %l10, !tbaa !24
  %t20 = icmp sle i64 1, %t19
  br i1 %t20, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_e777242b492df290_2cbbd43a2df6cacc)
  unreachable
bb6:
  %t22 = load i64, ptr %l10, !tbaa !24
  %t23 = load i64, ptr %l11, !tbaa !24
  %t24 = icmp sle i64 %t22, %t23
  br i1 %t24, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_e777242b492df290_2cbbd43a2df6cacc)
  unreachable
bb8:
  %t26 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = load i64, ptr %l10, !tbaa !24
  %t29 = getelementptr i8, ptr %t27, i64 1
  %t30 = sub i64 %t28, 1
  %t31 = insertvalue { i64, ptr } undef, i64 %t30, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t29, 1
  store { i64, ptr } %t32, ptr %l1, !tbaa !27
  %t34 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t34, ptr %l16, !tbaa !27
  %t35 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !27
  %t37 = getelementptr i8, ptr %t36, i64 0
  %t38 = load i8, ptr %t37, !tbaa !32
  %t40 = icmp ne i8 %t38, 92
  br i1 %t40, label %bb10, label %bb11
bb9:
  call void @__olang_check_failed(ptr @olang_loc_e777242b492df290_2cbbd43a2df6cacc)
  unreachable
bb10:
  %t42 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t44 = extractvalue { i64, ptr } %t42, 0
  %t46 = icmp ne i64 %t44, 1
  br i1 %t46, label %bb12, label %bb13
bb11:
  br label %bb15
bb12:
  %t49 = insertvalue { i32, i64 } zeroinitializer, i32 65536, 0
  store { i32, i64 } %t49, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  %t50 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t50, ptr %l23, !tbaa !27
  %t51 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t52 = load ptr, ptr %t51, !tbaa !27
  %t53 = getelementptr i8, ptr %t52, i64 0
  %t54 = load i8, ptr %t53, !tbaa !32
  %t57 = zext i8 %t54 to i64
  %t59 = insertvalue { i32, i64 } zeroinitializer, i64 %t57, 1
  store { i32, i64 } %t59, ptr %rv
  br label %ret
bb15:
  %t60 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t62 = extractvalue { i64, ptr } %t60, 0
  %t64 = icmp slt i64 %t62, 2
  br i1 %t64, label %bb16, label %bb17
bb16:
  %t67 = insertvalue { i32, i64 } zeroinitializer, i32 65536, 0
  store { i32, i64 } %t67, ptr %rv
  br label %ret
bb17:
  br label %bb18
bb18:
  %t68 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t68, ptr %l31, !tbaa !27
  %t69 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !27
  %t71 = getelementptr i8, ptr %t70, i64 1
  %t72 = load i8, ptr %t71, !tbaa !32
  store i8 %t72, ptr %l2, !tbaa !22
  %t74 = load i8, ptr %l2, !tbaa !22
  %t76 = icmp eq i8 %t74, 120
  br i1 %t76, label %bb19, label %bb20
bb19:
  store %olang.scope zeroinitializer, ptr %s5
  %t78 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t78, ptr %l36, !tbaa !27
  %t79 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t82 = extractvalue { i64, ptr } %t79, 0
  store i64 %t82, ptr %l39, !tbaa !24
  %t83 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t84 = extractvalue { i64, ptr } %t83, 0
  store i64 %t84, ptr %l40, !tbaa !24
  %t85 = icmp sge i64 2, 0
  br i1 %t85, label %bb21, label %bb22
bb20:
  br label %bb33
bb21:
  %t87 = load i64, ptr %l39, !tbaa !24
  %t88 = icmp sle i64 2, %t87
  br i1 %t88, label %bb23, label %bb24
bb22:
  call void @__olang_check_failed(ptr @olang_loc_aa3527431bc6906d_d98aa20bf76f5ef9)
  unreachable
bb23:
  %t90 = load i64, ptr %l39, !tbaa !24
  %t91 = load i64, ptr %l40, !tbaa !24
  %t92 = icmp sle i64 %t90, %t91
  br i1 %t92, label %bb25, label %bb26
bb24:
  call void @__olang_check_failed(ptr @olang_loc_aa3527431bc6906d_d98aa20bf76f5ef9)
  unreachable
bb25:
  %t94 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !27
  %t96 = load i64, ptr %l39, !tbaa !24
  %t97 = getelementptr i8, ptr %t95, i64 2
  %t98 = sub i64 %t96, 2
  %t99 = insertvalue { i64, ptr } undef, i64 %t98, 0
  %t100 = insertvalue { i64, ptr } %t99, ptr %t97, 1
  store { i64, ptr } %t100, ptr %l44, !tbaa !27
  %t101 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s5, i64 16)
  %t102 = extractvalue { i32, i64 } %t101, 1
  %t103 = extractvalue { i32, i64 } %t101, 0
  store i32 %t103, ptr %l46
  %t104 = icmp ne i32 %t103, 0
  br i1 %t104, label %bb28, label %ok.105, !prof !99
ok.105:
  store i64 %t102, ptr %l45
  br label %bb27
bb26:
  call void @__olang_check_failed(ptr @olang_loc_aa3527431bc6906d_d98aa20bf76f5ef9)
  unreachable
bb27:
  %t106 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t107 = load i64, ptr %l45, !tbaa !24
  %t108 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %v0, { i64, ptr } %t106, i64 %t107)
  %t109 = extractvalue { i32, i64 } %t108, 1
  %t110 = extractvalue { i32, i64 } %t108, 0
  store i32 %t110, ptr %l48
  %t111 = icmp ne i32 %t110, 0
  br i1 %t111, label %bb31, label %ok.112, !prof !99
ok.112:
  store i64 %t109, ptr %l47
  br label %bb30
bb28:
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s5)
  %t114 = insertvalue { i32, i64 } zeroinitializer, i32 65536, 0
  store { i32, i64 } %t114, ptr %rv
  br label %ret
bb30:
  %t115 = load i64, ptr %l47, !tbaa !24
  store i64 %t115, ptr %l35, !tbaa !24
  br label %bb32
bb31:
  br label %bb29
bb32:
  call void @__olang_scope_close(ptr %s5)
  %t116 = load i64, ptr %l35, !tbaa !24
  %t117 = insertvalue { i32, i64 } zeroinitializer, i64 %t116, 1
  store { i32, i64 } %t117, ptr %rv
  br label %ret
bb33:
  %t118 = load i8, ptr %l2, !tbaa !22
  %t120 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t118)
  store i1 %t120, ptr %l51
  br label %bb34
bb34:
  %t121 = load i1, ptr %l51, !tbaa !21
  br i1 %t121, label %bb35, label %bb36
bb35:
  store %olang.scope zeroinitializer, ptr %s7
  %t122 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t122, ptr %l53, !tbaa !27
  %t123 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t126 = extractvalue { i64, ptr } %t123, 0
  store i64 %t126, ptr %l56, !tbaa !24
  %t127 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t128 = extractvalue { i64, ptr } %t127, 0
  store i64 %t128, ptr %l57, !tbaa !24
  %t129 = icmp sge i64 1, 0
  br i1 %t129, label %bb37, label %bb38
bb36:
  br label %bb49
bb37:
  %t131 = load i64, ptr %l56, !tbaa !24
  %t132 = icmp sle i64 1, %t131
  br i1 %t132, label %bb39, label %bb40
bb38:
  call void @__olang_check_failed(ptr @olang_loc_5d1582c4176ede0e_4f5ef5c07175765a)
  unreachable
bb39:
  %t134 = load i64, ptr %l56, !tbaa !24
  %t135 = load i64, ptr %l57, !tbaa !24
  %t136 = icmp sle i64 %t134, %t135
  br i1 %t136, label %bb41, label %bb42
bb40:
  call void @__olang_check_failed(ptr @olang_loc_5d1582c4176ede0e_4f5ef5c07175765a)
  unreachable
bb41:
  %t138 = getelementptr { i64, ptr }, ptr %l53, i32 0, i32 1
  %t139 = load ptr, ptr %t138, !tbaa !27
  %t140 = load i64, ptr %l56, !tbaa !24
  %t141 = getelementptr i8, ptr %t139, i64 1
  %t142 = sub i64 %t140, 1
  %t143 = insertvalue { i64, ptr } undef, i64 %t142, 0
  %t144 = insertvalue { i64, ptr } %t143, ptr %t141, 1
  store { i64, ptr } %t144, ptr %l61, !tbaa !27
  %t145 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s7, i64 8)
  %t146 = extractvalue { i32, i64 } %t145, 1
  %t147 = extractvalue { i32, i64 } %t145, 0
  store i32 %t147, ptr %l63
  %t148 = icmp ne i32 %t147, 0
  br i1 %t148, label %bb44, label %ok.149, !prof !99
ok.149:
  store i64 %t146, ptr %l62
  br label %bb43
bb42:
  call void @__olang_check_failed(ptr @olang_loc_5d1582c4176ede0e_4f5ef5c07175765a)
  unreachable
bb43:
  %t150 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t151 = load i64, ptr %l62, !tbaa !24
  %t152 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %v0, { i64, ptr } %t150, i64 %t151)
  %t153 = extractvalue { i32, i64 } %t152, 1
  %t154 = extractvalue { i32, i64 } %t152, 0
  store i32 %t154, ptr %l65
  %t155 = icmp ne i32 %t154, 0
  br i1 %t155, label %bb47, label %ok.156, !prof !99
ok.156:
  store i64 %t153, ptr %l64
  br label %bb46
bb44:
  br label %bb45
bb45:
  call void @__olang_scope_close(ptr %s7)
  %t158 = insertvalue { i32, i64 } zeroinitializer, i32 65536, 0
  store { i32, i64 } %t158, ptr %rv
  br label %ret
bb46:
  %t159 = load i64, ptr %l64, !tbaa !24
  store i64 %t159, ptr %l52, !tbaa !24
  br label %bb48
bb47:
  br label %bb45
bb48:
  call void @__olang_scope_close(ptr %s7)
  %t160 = load i64, ptr %l52, !tbaa !24
  %t161 = insertvalue { i32, i64 } zeroinitializer, i64 %t160, 1
  store { i32, i64 } %t161, ptr %rv
  br label %ret
bb49:
  %t162 = load i8, ptr %l2, !tbaa !22
  %t164 = icmp eq i8 %t162, 110
  br i1 %t164, label %bb50, label %bb51
bb50:
  br label %bb52
bb51:
  br label %bb53
bb52:
  store i64 10, ptr %l67, !tbaa !24
  br label %bb86
bb53:
  %t166 = load i8, ptr %l2, !tbaa !22
  %t168 = icmp eq i8 %t166, 116
  br i1 %t168, label %bb54, label %bb55
bb54:
  br label %bb56
bb55:
  br label %bb57
bb56:
  store i64 9, ptr %l67, !tbaa !24
  br label %bb86
bb57:
  %t170 = load i8, ptr %l2, !tbaa !22
  %t172 = icmp eq i8 %t170, 114
  br i1 %t172, label %bb58, label %bb59
bb58:
  br label %bb60
bb59:
  br label %bb61
bb60:
  store i64 13, ptr %l67, !tbaa !24
  br label %bb86
bb61:
  %t174 = load i8, ptr %l2, !tbaa !22
  %t176 = icmp eq i8 %t174, 48
  br i1 %t176, label %bb62, label %bb63
bb62:
  br label %bb64
bb63:
  br label %bb65
bb64:
  store i64 0, ptr %l67, !tbaa !24
  br label %bb86
bb65:
  %t178 = load i8, ptr %l2, !tbaa !22
  %t180 = icmp eq i8 %t178, 97
  br i1 %t180, label %bb66, label %bb67
bb66:
  br label %bb68
bb67:
  br label %bb69
bb68:
  store i64 7, ptr %l67, !tbaa !24
  br label %bb86
bb69:
  %t182 = load i8, ptr %l2, !tbaa !22
  %t184 = icmp eq i8 %t182, 98
  br i1 %t184, label %bb70, label %bb71
bb70:
  br label %bb72
bb71:
  br label %bb73
bb72:
  store i64 8, ptr %l67, !tbaa !24
  br label %bb86
bb73:
  %t186 = load i8, ptr %l2, !tbaa !22
  %t188 = icmp eq i8 %t186, 102
  br i1 %t188, label %bb74, label %bb75
bb74:
  br label %bb76
bb75:
  br label %bb77
bb76:
  store i64 12, ptr %l67, !tbaa !24
  br label %bb86
bb77:
  %t190 = load i8, ptr %l2, !tbaa !22
  %t192 = icmp eq i8 %t190, 118
  br i1 %t192, label %bb78, label %bb79
bb78:
  br label %bb80
bb79:
  br label %bb81
bb80:
  store i64 11, ptr %l67, !tbaa !24
  br label %bb86
bb81:
  br i1 true, label %bb82, label %bb83
bb82:
  br label %bb84
bb83:
  br label %bb85
bb84:
  %t194 = load i8, ptr %l2, !tbaa !22
  %t197 = zext i8 %t194 to i64
  store i64 %t197, ptr %l67, !tbaa !24
  br label %bb86
bb85:
  call void @__olang_check_failed(ptr @olang_loc_c1a7519d080599a4_d00fb28b8b3fdec0)
  unreachable
bb86:
  %t199 = load i64, ptr %l67, !tbaa !24
  %t200 = insertvalue { i32, i64 } zeroinitializer, i64 %t199, 1
  store { i32, i64 } %t200, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i64 }, ptr %rv
  ret { i32, i64 } %rr
}

define dso_local { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ecFunc(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/bindgen:ctype" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/bindgen:ctype"
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l5 = alloca i1
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l16 = alloca i32
  %l18 = alloca i1
  %l19 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca { i64, ptr }
  %l23 = alloca ptr
  %l25 = alloca { i64, ptr }
  %l28 = alloca i1
  %l30 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l35 = alloca i64
  %l36 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store %"compiler/bindgen:ctype" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = getelementptr %"compiler/bindgen:ctype", ptr %l1, i32 0, i32 1
  %t2 = load { i64, ptr }, ptr %t1, !tbaa !27
  %t4 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t2, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d43, i32 0, i32 1) })
  store i1 %t4, ptr %l5
  br label %bb1
bb1:
  %t5 = load i1, ptr %l5, !tbaa !21
  br i1 %t5, label %bb2, label %bb3
bb2:
  store { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d44, i32 0, i32 1) }, ptr %l6, !tbaa !27
  %t6 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t6, ptr %l7, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t7, 0
  store i64 %t8, ptr %l8, !tbaa !24
  %t9 = load i64, ptr %l8, !tbaa !24
  %t10 = mul i64 %t9, 1
  %t11 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t10)
  %t12 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t13 = insertvalue { i64, ptr } %t12, ptr %t11, 1
  store { i64, ptr } %t13, ptr %l9, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = load i64, ptr %l8, !tbaa !24
  %t19 = mul i64 %t18, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t15, ptr %t17, i64 %t19, i1 false)
  %t20 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t20, ptr %l7, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t21 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t21, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/bindgen:gen", ptr %t22, i32 0, i32 26
  %t25 = load { i64, ptr }, ptr %t24, !tbaa !27
  store { i64, ptr } %t25, ptr %l2, !tbaa !27
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load %"compiler/bindgen:ctype", ptr %l1
  %t31 = call { i32, { i64, ptr } } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2efnSpelled(ptr %v0, ptr %v1, ptr %s0, ptr %t27, %"compiler/bindgen:ctype" %t28)
  %t32 = extractvalue { i32, { i64, ptr } } %t31, 1
  %t33 = extractvalue { i32, { i64, ptr } } %t31, 0
  store i32 %t33, ptr %l16
  %t34 = icmp ne i32 %t33, 0
  br i1 %t34, label %bb6, label %ok.35, !prof !99
ok.35:
  store { i64, ptr } %t32, ptr %l15
  br label %bb5
bb5:
  %t36 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t36, ptr %l12, !tbaa !27
  br label %bb8
bb6:
  %t37 = load i32, ptr %l16, !tbaa !23
  %t38 = ashr i32 %t37, 16
  %t40 = icmp eq i32 %t38, 1
  store i1 %t40, ptr %l18, !tbaa !21
  br label %bb7
bb7:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d45, i32 0, i32 1) }, ptr %l19, !tbaa !27
  %t41 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t41, ptr %l12, !tbaa !27
  br label %bb8
bb8:
  %t43 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t44 = extractvalue { i64, ptr } %t43, 0
  store i64 %t44, ptr %l21, !tbaa !24
  %t45 = load i64, ptr %l21, !tbaa !24
  %t46 = mul i64 %t45, 1
  %t47 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t46)
  %t48 = insertvalue { i64, ptr } undef, i64 %t45, 0
  %t49 = insertvalue { i64, ptr } %t48, ptr %t47, 1
  store { i64, ptr } %t49, ptr %l22, !tbaa !27
  %t50 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t51 = load ptr, ptr %t50, !tbaa !27
  %t52 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !27
  %t54 = load i64, ptr %l21, !tbaa !24
  %t55 = mul i64 %t54, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t51, ptr %t53, i64 %t55, i1 false)
  %t56 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t56, ptr %l3, !tbaa !27
  %t57 = load ptr, ptr %l0, !tbaa !29
  store ptr %t57, ptr %l23, !tbaa !29
  %t58 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t59 = load ptr, ptr %l23, !tbaa !29
  %t60 = getelementptr %"compiler/bindgen:gen", ptr %t59, i32 0, i32 26
  %t61 = load { i64, ptr }, ptr %t60, !tbaa !27
  store { i64, ptr } %t61, ptr %l25, !tbaa !27
  %t63 = load ptr, ptr %l23, !tbaa !29
  %t64 = getelementptr %"compiler/bindgen:gen", ptr %t63, i32 0, i32 26
  store { i64, ptr } %t58, ptr %t64, !tbaa !27
  %t65 = load i1, ptr @olang_2esole_2ecompiler_2fbindgen_3agen_2e26
  br i1 %t65, label %bb9, label %bb10
bb9:
  %t67 = load { i64, ptr }, ptr %l25
  %t68 = extractvalue { i64, ptr } %t67, 1
  call void @__olang_region_release(ptr %t68)
  store { i64, ptr } zeroinitializer, ptr %l25
  br label %bb10
bb10:
  %t69 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t71 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t69, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d46, i32 0, i32 1) })
  store i1 %t71, ptr %l28
  br label %bb11
bb11:
  %t72 = load i1, ptr %l28, !tbaa !21
  %t73 = xor i1 %t72, true
  br i1 %t73, label %bb12, label %bb13
bb12:
  %t75 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t76 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d47, i32 0, i32 1) }, 1
  %t77 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d47, i32 0, i32 1) }, 0
  %t79 = extractvalue { i64, ptr } %t75, 1
  %t80 = extractvalue { i64, ptr } %t75, 0
  %t81 = add i64 %t77, %t80
  %t82 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t81)
  call void @olang_textcopy(ptr %t82, ptr %t76, i64 %t77)
  %t83 = getelementptr i8, ptr %t82, i64 %t77
  call void @olang_textcopy(ptr %t83, ptr %t79, i64 %t80)
  %t84 = insertvalue { i64, ptr } undef, i64 %t81, 0
  %t85 = insertvalue { i64, ptr } %t84, ptr %t82, 1
  store { i64, ptr } %t85, ptr %l30, !tbaa !27
  br label %bb14
bb13:
  store { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d48, i32 0, i32 1) }, ptr %l33, !tbaa !27
  %t87 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t87, ptr %l30, !tbaa !27
  br label %bb14
bb14:
  %t89 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t90 = extractvalue { i64, ptr } %t89, 0
  store i64 %t90, ptr %l35, !tbaa !24
  %t91 = load i64, ptr %l35, !tbaa !24
  %t92 = mul i64 %t91, 1
  %t93 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t92)
  %t94 = insertvalue { i64, ptr } undef, i64 %t91, 0
  %t95 = insertvalue { i64, ptr } %t94, ptr %t93, 1
  store { i64, ptr } %t95, ptr %l36, !tbaa !27
  %t96 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t97 = load ptr, ptr %t96, !tbaa !27
  %t98 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t99 = load ptr, ptr %t98, !tbaa !27
  %t100 = load i64, ptr %l35, !tbaa !24
  %t101 = mul i64 %t100, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t97, ptr %t99, i64 %t101, i1 false)
  %t102 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t102, ptr %l30, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t103 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t103, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i32, %"compiler/bindgen:cx" } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ecPrimary(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %lp2 = alloca ptr
  %l3 = alloca %"compiler/bindgen:cx"
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"std/prelude/text:StringBuilder"
  %l8 = alloca i64
  %l10 = alloca { i64, ptr }
  %l12 = alloca i1
  %l14 = alloca i32
  %l16 = alloca ptr
  %l21 = alloca i1
  %l22 = alloca %"compiler/bindgen:cx"
  %l25 = alloca %"compiler/bindgen:cx"
  %l26 = alloca i32
  %l29 = alloca { i64, ptr }
  %l31 = alloca i1
  %l34 = alloca i32
  %l36 = alloca ptr
  %l42 = alloca i1
  %l43 = alloca i1
  %l46 = alloca %"compiler/bindgen:cx"
  %l49 = alloca %"compiler/bindgen:cx"
  %l50 = alloca i32
  %l54 = alloca i64
  %l56 = alloca i64
  %l58 = alloca i64
  %l59 = alloca i32
  %l64 = alloca %"compiler/bindgen:cx"
  %l68 = alloca i32
  %l70 = alloca i64
  %l75 = alloca i64
  %l76 = alloca i32
  %l79 = alloca i64
  %l86 = alloca %"compiler/bindgen:cx"
  %l87 = alloca i64
  %l91 = alloca i64
  %l92 = alloca i32
  %l97 = alloca { i64, ptr }
  %l98 = alloca i64
  %l103 = alloca i64
  %l109 = alloca %"compiler/bindgen:cx"
  %l111 = alloca { i64, ptr }
  %l113 = alloca i1
  %l114 = alloca { i64, ptr }
  %l118 = alloca { i64, ptr }
  %l119 = alloca i32
  %l121 = alloca i1
  %l122 = alloca ptr
  %l123 = alloca i64
  %l128 = alloca i32
  %l130 = alloca ptr
  %l134 = alloca %"std/prelude/text:StringBuilder"
  %l140 = alloca { i64, ptr }
  %l142 = alloca i1
  %l148 = alloca { i64, ptr }
  %l150 = alloca i1
  %l152 = alloca ptr
  %l153 = alloca i64
  %l158 = alloca i32
  %l160 = alloca ptr
  %l165 = alloca ptr
  %l166 = alloca ptr
  %l167 = alloca %"compiler/bindgen:cx"
  %l170 = alloca %"compiler/bindgen:cx"
  %l171 = alloca i32
  %l173 = alloca %"compiler/bindgen:cx"
  %l178 = alloca ptr
  %l183 = alloca i64
  %l186 = alloca { i64, ptr }
  %l187 = alloca { i64, ptr }
  %l189 = alloca i1
  %l191 = alloca i64
  %l195 = alloca %"compiler/bindgen:cx"
  %l196 = alloca ptr
  %l197 = alloca i64
  %l202 = alloca i32
  %l205 = alloca %"compiler/bindgen:cx"
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %rv = alloca { i32, %"compiler/bindgen:cx" }
  %t225 = alloca { { i64, ptr }, ptr }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3acparse_2eat(ptr %v1, ptr %v2, ptr %t1)
  store { i64, ptr } %t3, ptr %l10
  br label %bb1
bb1:
  %t4 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 16, i64 8)
  store ptr %t4, ptr %lp2
  %t5 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t6 = load ptr, ptr %lp2
  store { i64, ptr } %t5, ptr %t6, !tbaa !27
  %t7 = load ptr, ptr %lp2
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  %t10 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s0, { i64, ptr } %t8, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d49, i32 0, i32 1) })
  store i1 %t10, ptr %l12
  br label %bb2
bb2:
  %t11 = load i1, ptr %l12, !tbaa !21
  br i1 %t11, label %bb3, label %bb4
bb3:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = call i32 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eskip(ptr %v0, ptr %v0, ptr %t12, { i64, ptr } { i64 47, ptr getelementptr inbounds (<{ i64, [47 x i8] }>, ptr @.d50, i32 0, i32 1) })
  store i32 %t14, ptr %l14
  %t15 = icmp ne i32 %t14, 0
  br i1 %t15, label %bb6, label %ok.16, !prof !99
ok.16:
  br label %bb5
bb4:
  br label %bb8
bb5:
  br label %bb7
bb6:
  %t17 = load i32, ptr %l14, !tbaa !23
  %t18 = lshr i32 %t17, 16
  %t19 = and i32 %t17, 65535
  %t20 = icmp eq i32 %t18, 1
  %t21 = select i1 %t20, i32 1, i32 0
  %t22 = icmp eq i32 %t17, 0
  %t23 = shl i32 %t21, 16
  %t24 = or i32 %t23, %t19
  %t25 = select i1 %t22, i32 0, i32 %t24
  call void @__olang_scope_close(ptr %s0)
  %t27 = insertvalue { i32, %"compiler/bindgen:cx" } zeroinitializer, i32 %t25, 0
  store { i32, %"compiler/bindgen:cx" } %t27, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t28 = load ptr, ptr %l1, !tbaa !29
  store ptr %t28, ptr %l16, !tbaa !29
  %t29 = load ptr, ptr %l16, !tbaa !29
  %t30 = getelementptr %"compiler/bindgen:cparse", ptr %t29, i32 0, i32 2
  %t31 = load i64, ptr %t30, !tbaa !24
  %t34 = add i64 %t31, 1
  %t36 = load ptr, ptr %l16, !tbaa !29
  %t37 = getelementptr %"compiler/bindgen:cparse", ptr %t36, i32 0, i32 2
  store i64 %t34, ptr %t37, !tbaa !24
  %t38 = load ptr, ptr %lp2
  %t39 = load { i64, ptr }, ptr %t38, !tbaa !27
  %t41 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s0, { i64, ptr } %t39, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d51, i32 0, i32 1) })
  store i1 %t41, ptr %l21
  br label %bb9
bb9:
  %t42 = load i1, ptr %l21, !tbaa !21
  br i1 %t42, label %bb10, label %bb11
bb10:
  store %olang.scope zeroinitializer, ptr %s2
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t44 = load ptr, ptr %l1, !tbaa !29
  %t47 = call { i32, %"compiler/bindgen:cx" } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ecExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t43, ptr %t44)
  %t48 = extractvalue { i32, %"compiler/bindgen:cx" } %t47, 1
  %t49 = extractvalue { i32, %"compiler/bindgen:cx" } %t47, 0
  store i32 %t49, ptr %l26
  %t50 = icmp ne i32 %t49, 0
  br i1 %t50, label %bb13, label %ok.51, !prof !99
ok.51:
  store %"compiler/bindgen:cx" %t48, ptr %l25
  br label %bb12
bb11:
  br label %bb23
bb12:
  %t52 = load %"compiler/bindgen:cx", ptr %l25
  store %"compiler/bindgen:cx" %t52, ptr %l22
  br label %bb14
bb13:
  %t53 = load i32, ptr %l26, !tbaa !23
  %t54 = lshr i32 %t53, 16
  %t55 = and i32 %t53, 65535
  %t56 = icmp eq i32 %t54, 1
  %t57 = select i1 %t56, i32 1, i32 0
  %t58 = icmp eq i32 %t53, 0
  %t59 = shl i32 %t57, 16
  %t60 = or i32 %t59, %t55
  %t61 = select i1 %t58, i32 0, i32 %t60
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t63 = insertvalue { i32, %"compiler/bindgen:cx" } zeroinitializer, i32 %t61, 0
  store { i32, %"compiler/bindgen:cx" } %t63, ptr %rv
  br label %ret
bb14:
  %t64 = load %"compiler/bindgen:cx", ptr %l22
  store %"compiler/bindgen:cx" %t64, ptr %l3
  %t65 = load ptr, ptr %l1, !tbaa !29
  %t67 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3acparse_2eat(ptr %v1, ptr %s2, ptr %t65)
  store { i64, ptr } %t67, ptr %l29
  br label %bb15
bb15:
  %t68 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t70 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s2, ptr %s2, { i64, ptr } %t68, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d52, i32 0, i32 1) })
  store i1 %t70, ptr %l31
  br label %bb16
bb16:
  %t71 = load i1, ptr %l31, !tbaa !21
  %t72 = xor i1 %t71, true
  br i1 %t72, label %bb17, label %bb18
bb17:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = call i32 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eskip(ptr %v0, ptr %v0, ptr %t74, { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d53, i32 0, i32 1) })
  store i32 %t76, ptr %l34
  %t77 = icmp ne i32 %t76, 0
  br i1 %t77, label %bb20, label %ok.78, !prof !99
ok.78:
  br label %bb19
bb18:
  br label %bb22
bb19:
  br label %bb21
bb20:
  %t79 = load i32, ptr %l34, !tbaa !23
  %t80 = lshr i32 %t79, 16
  %t81 = and i32 %t79, 65535
  %t82 = icmp eq i32 %t80, 1
  %t83 = select i1 %t82, i32 1, i32 0
  %t84 = icmp eq i32 %t79, 0
  %t85 = shl i32 %t83, 16
  %t86 = or i32 %t85, %t81
  %t87 = select i1 %t84, i32 0, i32 %t86
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t89 = insertvalue { i32, %"compiler/bindgen:cx" } zeroinitializer, i32 %t87, 0
  store { i32, %"compiler/bindgen:cx" } %t89, ptr %rv
  br label %ret
bb21:
  br label %bb22
bb22:
  %t90 = load ptr, ptr %l1, !tbaa !29
  store ptr %t90, ptr %l36, !tbaa !29
  %t91 = load ptr, ptr %l36, !tbaa !29
  %t92 = getelementptr %"compiler/bindgen:cparse", ptr %t91, i32 0, i32 2
  %t93 = load i64, ptr %t92, !tbaa !24
  %t96 = add i64 %t93, 1
  %t98 = load ptr, ptr %l36, !tbaa !29
  %t99 = getelementptr %"compiler/bindgen:cparse", ptr %t98, i32 0, i32 2
  store i64 %t96, ptr %t99, !tbaa !24
  %t100 = load %"compiler/bindgen:cx", ptr %l3
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t102 = insertvalue { i32, %"compiler/bindgen:cx" } zeroinitializer, %"compiler/bindgen:cx" %t100, 1
  store { i32, %"compiler/bindgen:cx" } %t102, ptr %rv
  br label %ret
bb23:
  %t103 = load ptr, ptr %lp2
  %t104 = getelementptr { i64, ptr }, ptr %t103, i32 0, i32 1
  %t105 = load ptr, ptr %t104, !tbaa !27
  %t106 = getelementptr i8, ptr %t105, i64 0
  %t107 = load i8, ptr %t106, !tbaa !32
  %t109 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t107)
  store i1 %t109, ptr %l42
  br label %bb24
bb24:
  %t110 = load i1, ptr %l42, !tbaa !21
  br i1 %t110, label %bb25, label %bb26
bb25:
  store i1 true, ptr %l43, !tbaa !21
  br label %bb27
bb26:
  %t111 = load ptr, ptr %lp2
  %t112 = getelementptr { i64, ptr }, ptr %t111, i32 0, i32 1
  %t113 = load ptr, ptr %t112, !tbaa !27
  %t114 = getelementptr i8, ptr %t113, i64 0
  %t115 = load i8, ptr %t114, !tbaa !32
  %t117 = icmp eq i8 %t115, 46
  store i1 %t117, ptr %l43, !tbaa !21
  br label %bb27
bb27:
  %t119 = load i1, ptr %l43, !tbaa !21
  br i1 %t119, label %bb28, label %bb29
bb28:
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t121 = load ptr, ptr %lp2
  %t122 = load { i64, ptr }, ptr %t121, !tbaa !27
  %t125 = call { i32, %"compiler/bindgen:cx" } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ecNumber(ptr %v0, ptr %v2, ptr %v2, ptr %t120, { i64, ptr } %t122)
  %t126 = extractvalue { i32, %"compiler/bindgen:cx" } %t125, 1
  %t127 = extractvalue { i32, %"compiler/bindgen:cx" } %t125, 0
  store i32 %t127, ptr %l50
  %t128 = icmp ne i32 %t127, 0
  br i1 %t128, label %bb31, label %ok.129, !prof !99
ok.129:
  store %"compiler/bindgen:cx" %t126, ptr %l49
  br label %bb30
bb29:
  br label %bb33
bb30:
  %t130 = load %"compiler/bindgen:cx", ptr %l49
  store %"compiler/bindgen:cx" %t130, ptr %l46
  br label %bb32
bb31:
  %t131 = load i32, ptr %l50, !tbaa !23
  %t132 = lshr i32 %t131, 16
  %t133 = and i32 %t131, 65535
  %t134 = icmp eq i32 %t132, 1
  %t135 = select i1 %t134, i32 1, i32 0
  %t136 = icmp eq i32 %t131, 0
  %t137 = shl i32 %t135, 16
  %t138 = or i32 %t137, %t133
  %t139 = select i1 %t136, i32 0, i32 %t138
  call void @__olang_scope_close(ptr %s0)
  %t141 = insertvalue { i32, %"compiler/bindgen:cx" } zeroinitializer, i32 %t139, 0
  store { i32, %"compiler/bindgen:cx" } %t141, ptr %rv
  br label %ret
bb32:
  call void @__olang_scope_close(ptr %s0)
  %t142 = load %"compiler/bindgen:cx", ptr %l46
  %t143 = insertvalue { i32, %"compiler/bindgen:cx" } zeroinitializer, %"compiler/bindgen:cx" %t142, 1
  store { i32, %"compiler/bindgen:cx" } %t143, ptr %rv
  br label %ret
bb33:
  %t144 = load ptr, ptr %lp2
  %t145 = getelementptr { i64, ptr }, ptr %t144, i32 0, i32 1
  %t146 = load ptr, ptr %t145, !tbaa !27
  %t147 = getelementptr i8, ptr %t146, i64 0
  %t148 = load i8, ptr %t147, !tbaa !32
  %t150 = icmp eq i8 %t148, 39
  br i1 %t150, label %bb34, label %bb35
bb34:
  %t152 = call ptr @__olang_scope_hold(ptr %v2)
  %t153 = ptrtoint ptr %t152 to i64
  store i64 %t153, ptr %l54, !tbaa !24
  %t154 = load i1, ptr @olang_2esole_2ecompiler_2fbindgen_3acx_2e0
  br i1 %t154, label %bb36, label %bb37
bb35:
  br label %bb42
bb36:
  %t156 = call ptr @__olang_region_make(ptr %v2)
  %t157 = ptrtoint ptr %t156 to i64
  store i64 %t157, ptr %l54, !tbaa !24
  br label %bb37
bb37:
  %t158 = load ptr, ptr %lp2
  %t159 = load { i64, ptr }, ptr %t158, !tbaa !27
  %t161 = call { i32, i64 } @compiler_2fbindgen_2echarValue(ptr %v2, { i64, ptr } %t159)
  %t162 = extractvalue { i32, i64 } %t161, 1
  %t163 = extractvalue { i32, i64 } %t161, 0
  store i32 %t163, ptr %l59
  %t164 = icmp ne i32 %t163, 0
  br i1 %t164, label %bb39, label %ok.165, !prof !99
ok.165:
  store i64 %t162, ptr %l58
  br label %bb38
bb38:
  %t166 = load i64, ptr %l58, !tbaa !24
  store i64 %t166, ptr %l56, !tbaa !24
  br label %bb40
bb39:
  %t167 = load i32, ptr %l59, !tbaa !23
  %t168 = lshr i32 %t167, 16
  %t169 = and i32 %t167, 65535
  %t170 = icmp eq i32 %t168, 1
  %t171 = select i1 %t170, i32 1, i32 0
  %t172 = icmp eq i32 %t167, 0
  %t173 = shl i32 %t171, 16
  %t174 = or i32 %t173, %t169
  %t175 = select i1 %t172, i32 0, i32 %t174
  call void @__olang_scope_close(ptr %s0)
  %t177 = insertvalue { i32, %"compiler/bindgen:cx" } zeroinitializer, i32 %t175, 0
  store { i32, %"compiler/bindgen:cx" } %t177, ptr %rv
  br label %ret
bb40:
  %t178 = load i64, ptr %l56, !tbaa !24
  %t179 = call i64 @__olang_fmt_i64(ptr null, i64 %t178)
  %t180 = load i64, ptr %l54
  %t181 = inttoptr i64 %t180 to ptr
  %t182 = call ptr @__olang_held_alloc(ptr %t181, i64 %t179)
  %t183 = call i64 @__olang_fmt_i64(ptr %t182, i64 %t178)
  %t184 = insertvalue { i64, ptr } undef, i64 %t179, 0
  %t185 = insertvalue { i64, ptr } %t184, ptr %t182, 1
  %t187 = load i64, ptr @G_2ecompiler_2fbindgen_2eKInt, !tbaa !24
  %t190 = call %"compiler/bindgen:cx" @compiler_2fbindgen_2ecx_2elit(ptr %v2, ptr %v2, { i64, ptr } %t185, i64 %t187)
  store %"compiler/bindgen:cx" %t190, ptr %l64
  br label %bb41
bb41:
  call void @__olang_scope_close(ptr %s0)
  %t191 = load %"compiler/bindgen:cx", ptr %l64
  %t192 = insertvalue { i32, %"compiler/bindgen:cx" } zeroinitializer, %"compiler/bindgen:cx" %t191, 1
  store { i32, %"compiler/bindgen:cx" } %t192, ptr %rv
  br label %ret
bb42:
  %t193 = load ptr, ptr %lp2
  %t194 = getelementptr { i64, ptr }, ptr %t193, i32 0, i32 1
  %t195 = load ptr, ptr %t194, !tbaa !27
  %t196 = getelementptr i8, ptr %t195, i64 0
  %t197 = load i8, ptr %t196, !tbaa !32
  %t199 = icmp eq i8 %t197, 34
  br i1 %t199, label %bb43, label %bb44
bb43:
  %t201 = load ptr, ptr %l0, !tbaa !29
  %t203 = call i32 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eskip(ptr %v0, ptr %v0, ptr %t201, { i64, ptr } { i64 43, ptr getelementptr inbounds (<{ i64, [43 x i8] }>, ptr @.d54, i32 0, i32 1) })
  store i32 %t203, ptr %l68
  %t204 = icmp ne i32 %t203, 0
  br i1 %t204, label %bb46, label %ok.205, !prof !99
ok.205:
  br label %bb45
bb44:
  br label %bb48
bb45:
  br label %bb47
bb46:
  %t206 = load i32, ptr %l68, !tbaa !23
  %t207 = lshr i32 %t206, 16
  %t208 = and i32 %t206, 65535
  %t209 = icmp eq i32 %t207, 1
  %t210 = select i1 %t209, i32 1, i32 0
  %t211 = icmp eq i32 %t206, 0
  %t212 = shl i32 %t210, 16
  %t213 = or i32 %t212, %t208
  %t214 = select i1 %t211, i32 0, i32 %t213
  call void @__olang_scope_close(ptr %s0)
  %t216 = insertvalue { i32, %"compiler/bindgen:cx" } zeroinitializer, i32 %t214, 0
  store { i32, %"compiler/bindgen:cx" } %t216, ptr %rv
  br label %ret
bb47:
  br label %bb48
bb48:
  %t217 = load ptr, ptr %l1, !tbaa !29
  %t219 = getelementptr %"compiler/bindgen:cparse", ptr %t217, i32 0, i32 1
  %t220 = load { i64, ptr }, ptr %t219, !tbaa !27
  %t221 = load ptr, ptr %lp2
  %t222 = load { i64, ptr }, ptr %t221, !tbaa !27
  %t223 = getelementptr { { i64, ptr }, ptr }, ptr null, i32 1
  %t224 = ptrtoint ptr %t223 to i64
  %t226 = getelementptr { { i64, ptr }, ptr }, ptr %t225, i32 0, i32 0
  store { i64, ptr } %t222, ptr %t226, !tbaa !28
  call void @__olang_scope_escape(ptr %v2)
  %t228 = call ptr @__olang_scope_hold(ptr %v2)
  %t229 = getelementptr { { i64, ptr }, ptr }, ptr %t225, i32 0, i32 1
  store ptr %t228, ptr %t229, !tbaa !28
  %t230 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_55, 0
  %t231 = insertvalue { ptr, ptr } %t230, ptr %t225, 1
  %t234 = extractvalue { ptr, ptr } %t231, 0
  %t235 = extractvalue { ptr, ptr } %t231, 1
  %t236 = call { i32, i64 } @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2eFindIndex_3cstd_2f_H0cdaf28864c9da4990596b1986b376a0(ptr %v1, ptr %s0, { i64, ptr } %t220, ptr %t234, ptr %t235)
  %t237 = extractvalue { i32, i64 } %t236, 1
  %t238 = extractvalue { i32, i64 } %t236, 0
  store i32 %t238, ptr %l76
  %t239 = icmp ne i32 %t238, 0
  br i1 %t239, label %bb50, label %ok.240, !prof !99
ok.240:
  store i64 %t237, ptr %l75
  br label %bb49
bb49:
  %t241 = load i64, ptr %l75, !tbaa !24
  store i64 %t241, ptr %l70, !tbaa !24
  br label %bb52
bb50:
  br label %bb51
bb51:
  store i64 -1, ptr %l70, !tbaa !24
  br label %bb52
bb52:
  %t242 = load i64, ptr %l70, !tbaa !24
  store i64 %t242, ptr %l4, !tbaa !24
  %t243 = load i64, ptr %l4, !tbaa !24
  %t245 = icmp sge i64 %t243, 0
  br i1 %t245, label %bb53, label %bb54
bb53:
  %t247 = call ptr @__olang_scope_hold(ptr %v2)
  %t248 = ptrtoint ptr %t247 to i64
  store i64 %t248, ptr %l79, !tbaa !24
  %t249 = load i1, ptr @olang_2esole_2ecompiler_2fbindgen_3acx_2e0
  br i1 %t249, label %bb55, label %bb56
bb54:
  br label %bb58
bb55:
  %t251 = call ptr @__olang_region_make(ptr %v2)
  %t252 = ptrtoint ptr %t251 to i64
  store i64 %t252, ptr %l79, !tbaa !24
  br label %bb56
bb56:
  %t253 = load i64, ptr %l4, !tbaa !24
  %t254 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d56, i32 0, i32 1) }, 1
  %t255 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d56, i32 0, i32 1) }, 0
  %t257 = call i64 @__olang_fmt_i64(ptr null, i64 %t253)
  %t258 = add i64 %t255, %t257
  %t259 = load i64, ptr %l79
  %t260 = inttoptr i64 %t259 to ptr
  %t261 = call ptr @__olang_held_alloc(ptr %t260, i64 %t258)
  call void @olang_textcopy(ptr %t261, ptr %t254, i64 %t255)
  %t262 = getelementptr i8, ptr %t261, i64 %t255
  %t263 = call i64 @__olang_fmt_i64(ptr %t262, i64 %t253)
  %t264 = insertvalue { i64, ptr } undef, i64 %t258, 0
  %t265 = insertvalue { i64, ptr } %t264, ptr %t261, 1
  %t267 = load i64, ptr @G_2ecompiler_2fbindgen_2eKVar, !tbaa !24
  %t268 = load i64, ptr %l4, !tbaa !24
  %t272 = call %"compiler/bindgen:cx" @compiler_2fbindgen_3acx_2ector(ptr %v2, ptr %v2, ptr %v2, { i64, ptr } %t265, i64 %t267, i64 %t268, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d57, i32 0, i32 1) })
  store %"compiler/bindgen:cx" %t272, ptr %l86
  br label %bb57
bb57:
  call void @__olang_scope_close(ptr %s0)
  %t273 = load %"compiler/bindgen:cx", ptr %l86
  %t274 = insertvalue { i32, %"compiler/bindgen:cx" } zeroinitializer, %"compiler/bindgen:cx" %t273, 1
  store { i32, %"compiler/bindgen:cx" } %t274, ptr %rv
  br label %ret
bb58:
  %t275 = load ptr, ptr %l0, !tbaa !29
  %t277 = getelementptr %"compiler/bindgen:gen", ptr %t275, i32 0, i32 12
  %t278 = load ptr, ptr %lp2
  %t279 = load { i64, ptr }, ptr %t278, !tbaa !27
  %t282 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9162e3b7f03fcbf954b681204d5f6cca(ptr %v0, ptr %v2, ptr %t277, { i64, ptr } %t279)
  %t283 = extractvalue { i32, i64 } %t282, 1
  %t284 = extractvalue { i32, i64 } %t282, 0
  store i32 %t284, ptr %l92
  %t285 = icmp ne i32 %t284, 0
  br i1 %t285, label %bb60, label %ok.286, !prof !99
ok.286:
  store i64 %t283, ptr %l91
  br label %bb59
bb59:
  %t287 = load i64, ptr %l91, !tbaa !24
  store i64 %t287, ptr %l87, !tbaa !24
  br label %bb62
bb60:
  br label %bb61
bb61:
  store i64 -9223372036854775808, ptr %l87, !tbaa !24
  br label %bb62
bb62:
  %t288 = load i64, ptr %l87, !tbaa !24
  store i64 %t288, ptr %l5, !tbaa !24
  %t289 = load i64, ptr %l5, !tbaa !24
  %t291 = icmp ne i64 %t289, -9223372036854775808
  br i1 %t291, label %bb63, label %bb64
bb63:
  %t293 = load i64, ptr %l5, !tbaa !24
  %t295 = icmp slt i64 %t293, 0
  br i1 %t295, label %bb65, label %bb66
bb64:
  br label %bb73
bb65:
  %t297 = call ptr @__olang_scope_hold(ptr %v2)
  %t298 = ptrtoint ptr %t297 to i64
  store i64 %t298, ptr %l98, !tbaa !24
  %t299 = load i1, ptr @olang_2esole_2ecompiler_2fbindgen_3acx_2e0
  br i1 %t299, label %bb67, label %bb68
bb66:
  %t301 = call ptr @__olang_scope_hold(ptr %v2)
  %t302 = ptrtoint ptr %t301 to i64
  store i64 %t302, ptr %l103, !tbaa !24
  %t303 = load i1, ptr @olang_2esole_2ecompiler_2fbindgen_3acx_2e0
  br i1 %t303, label %bb69, label %bb70
bb67:
  %t305 = call ptr @__olang_region_make(ptr %v2)
  %t306 = ptrtoint ptr %t305 to i64
  store i64 %t306, ptr %l98, !tbaa !24
  br label %bb68
bb68:
  %t307 = load i64, ptr %l5, !tbaa !24
  %t308 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d58, i32 0, i32 1) }, 1
  %t309 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d58, i32 0, i32 1) }, 0
  %t311 = call i64 @__olang_fmt_i64(ptr null, i64 %t307)
  %t312 = add i64 %t309, %t311
  %t313 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d59, i32 0, i32 1) }, 1
  %t314 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d59, i32 0, i32 1) }, 0
  %t315 = add i64 %t312, %t314
  %t316 = load i64, ptr %l98
  %t317 = inttoptr i64 %t316 to ptr
  %t318 = call ptr @__olang_held_alloc(ptr %t317, i64 %t315)
  call void @olang_textcopy(ptr %t318, ptr %t308, i64 %t309)
  %t319 = getelementptr i8, ptr %t318, i64 %t309
  %t320 = call i64 @__olang_fmt_i64(ptr %t319, i64 %t307)
  %t321 = getelementptr i8, ptr %t319, i64 %t311
  call void @olang_textcopy(ptr %t321, ptr %t313, i64 %t314)
  %t322 = insertvalue { i64, ptr } undef, i64 %t315, 0
  %t323 = insertvalue { i64, ptr } %t322, ptr %t318, 1
  store { i64, ptr } %t323, ptr %l97, !tbaa !27
  br label %bb71
bb69:
  %t326 = call ptr @__olang_region_make(ptr %v2)
  %t327 = ptrtoint ptr %t326 to i64
  store i64 %t327, ptr %l103, !tbaa !24
  br label %bb70
bb70:
  %t328 = load i64, ptr %l5, !tbaa !24
  %t330 = call i64 @__olang_fmt_i64(ptr null, i64 %t328)
  %t331 = load i64, ptr %l103
  %t332 = inttoptr i64 %t331 to ptr
  %t333 = call ptr @__olang_held_alloc(ptr %t332, i64 %t330)
  %t334 = call i64 @__olang_fmt_i64(ptr %t333, i64 %t328)
  %t335 = insertvalue { i64, ptr } undef, i64 %t330, 0
  %t336 = insertvalue { i64, ptr } %t335, ptr %t333, 1
  store { i64, ptr } %t336, ptr %l97, !tbaa !27
  br label %bb71
bb71:
  %t339 = load i64, ptr @G_2ecompiler_2fbindgen_2eKInt, !tbaa !24
  %t340 = load { i64, ptr }, ptr %l97, !tbaa !27
  %t342 = call %"compiler/bindgen:cx" @compiler_2fbindgen_2ecx_2elit(ptr %v2, ptr %v2, { i64, ptr } %t340, i64 %t339)
  store %"compiler/bindgen:cx" %t342, ptr %l109
  br label %bb72
bb72:
  call void @__olang_scope_close(ptr %s0)
  %t343 = load %"compiler/bindgen:cx", ptr %l109
  %t344 = insertvalue { i32, %"compiler/bindgen:cx" } zeroinitializer, %"compiler/bindgen:cx" %t343, 1
  store { i32, %"compiler/bindgen:cx" } %t344, ptr %rv
  br label %ret
bb73:
  %t345 = load ptr, ptr %l1, !tbaa !29
  %t347 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3acparse_2eat(ptr %v1, ptr %s0, ptr %t345)
  store { i64, ptr } %t347, ptr %l111
  br label %bb74
bb74:
  %t348 = load { i64, ptr }, ptr %l111, !tbaa !27
  %t350 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t348, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d60, i32 0, i32 1) })
  store i1 %t350, ptr %l113
  br label %bb75
bb75:
  %t351 = load i1, ptr %l113, !tbaa !21
  br i1 %t351, label %bb76, label %bb77
bb76:
  store %olang.scope zeroinitializer, ptr %s13
  %t352 = load ptr, ptr %l0, !tbaa !29
  %t354 = getelementptr %"compiler/bindgen:gen", ptr %t352, i32 0, i32 16
  %t355 = load ptr, ptr %lp2
  %t356 = load { i64, ptr }, ptr %t355, !tbaa !27
  %t359 = call { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha4444909f5ef14f7626d25b8f59e6ba2(ptr %v0, ptr %v2, ptr %v2, ptr %t354, { i64, ptr } %t356)
  %t360 = extractvalue { i32, { i64, ptr } } %t359, 1
  %t361 = extractvalue { i32, { i64, ptr } } %t359, 0
  store i32 %t361, ptr %l119
  %t362 = icmp ne i32 %t361, 0
  br i1 %t362, label %bb79, label %ok.363, !prof !99
ok.363:
  store { i64, ptr } %t360, ptr %l118
  br label %bb78
bb77:
  br label %bb129
bb78:
  %t364 = load { i64, ptr }, ptr %l118, !tbaa !27
  store { i64, ptr } %t364, ptr %l114, !tbaa !27
  br label %bb81
bb79:
  br label %bb80
bb80:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d61, i32 0, i32 1) }, ptr %l114, !tbaa !27
  br label %bb81
bb81:
  %t365 = load { i64, ptr }, ptr %l114, !tbaa !27
  store { i64, ptr } %t365, ptr %l6, !tbaa !27
  %t366 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t368 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s13, { i64, ptr } %t366, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d62, i32 0, i32 1) })
  store i1 %t368, ptr %l121
  br label %bb82
bb82:
  %t369 = load i1, ptr %l121, !tbaa !21
  br i1 %t369, label %bb83, label %bb84
bb83:
  %t370 = load ptr, ptr %l0, !tbaa !29
  store ptr %t370, ptr %l122, !tbaa !29
  %t371 = call ptr @__olang_scope_hold(ptr %v0)
  %t372 = ptrtoint ptr %t371 to i64
  store i64 %t372, ptr %l123, !tbaa !24
  %t373 = load i1, ptr @olang_2esole_2ecompiler_2fbindgen_3agen_2e26
  br i1 %t373, label %bb85, label %bb86
bb84:
  br label %bb90
bb85:
  %t375 = call ptr @__olang_region_make(ptr %v0)
  %t376 = ptrtoint ptr %t375 to i64
  store i64 %t376, ptr %l123, !tbaa !24
  br label %bb86
bb86:
  %t377 = load ptr, ptr %lp2
  %t378 = load { i64, ptr }, ptr %t377, !tbaa !27
  %t379 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d63, i32 0, i32 1) }, 1
  %t380 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d63, i32 0, i32 1) }, 0
  %t382 = extractvalue { i64, ptr } %t378, 1
  %t383 = extractvalue { i64, ptr } %t378, 0
  %t384 = add i64 %t380, %t383
  %t385 = extractvalue { i64, ptr } { i64 38, ptr getelementptr inbounds (<{ i64, [38 x i8] }>, ptr @.d64, i32 0, i32 1) }, 1
  %t386 = extractvalue { i64, ptr } { i64 38, ptr getelementptr inbounds (<{ i64, [38 x i8] }>, ptr @.d64, i32 0, i32 1) }, 0
  %t387 = add i64 %t384, %t386
  %t388 = load i64, ptr %l123
  %t389 = inttoptr i64 %t388 to ptr
  %t390 = call ptr @__olang_held_alloc(ptr %t389, i64 %t387)
  call void @olang_textcopy(ptr %t390, ptr %t379, i64 %t380)
  %t391 = getelementptr i8, ptr %t390, i64 %t380
  call void @olang_textcopy(ptr %t391, ptr %t382, i64 %t383)
  %t392 = getelementptr i8, ptr %t391, i64 %t383
  call void @olang_textcopy(ptr %t392, ptr %t385, i64 %t386)
  %t393 = insertvalue { i64, ptr } undef, i64 %t387, 0
  %t394 = insertvalue { i64, ptr } %t393, ptr %t390, 1
  %t396 = load ptr, ptr %l122, !tbaa !29
  %t398 = call i32 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eskip(ptr %v0, ptr %v0, ptr %t396, { i64, ptr } %t394)
  store i32 %t398, ptr %l128
  %t399 = icmp ne i32 %t398, 0
  br i1 %t399, label %bb88, label %ok.400, !prof !99
ok.400:
  br label %bb87
bb87:
  br label %bb89
bb88:
  %t401 = load i32, ptr %l128, !tbaa !23
  %t402 = lshr i32 %t401, 16
  %t403 = and i32 %t401, 65535
  %t404 = icmp eq i32 %t402, 1
  %t405 = select i1 %t404, i32 1, i32 0
  %t406 = icmp eq i32 %t401, 0
  %t407 = shl i32 %t405, 16
  %t408 = or i32 %t407, %t403
  %t409 = select i1 %t406, i32 0, i32 %t408
  call void @__olang_scope_close(ptr %s13)
  call void @__olang_scope_close(ptr %s0)
  %t411 = insertvalue { i32, %"compiler/bindgen:cx" } zeroinitializer, i32 %t409, 0
  store { i32, %"compiler/bindgen:cx" } %t411, ptr %rv
  br label %ret
bb89:
  br label %bb90
bb90:
  %t412 = load ptr, ptr %l1, !tbaa !29
  store ptr %t412, ptr %l130, !tbaa !29
  %t413 = load ptr, ptr %l130, !tbaa !29
  %t414 = getelementptr %"compiler/bindgen:cparse", ptr %t413, i32 0, i32 2
  %t415 = load i64, ptr %t414, !tbaa !24
  %t418 = add i64 %t415, 1
  %t420 = load ptr, ptr %l130, !tbaa !29
  %t421 = getelementptr %"compiler/bindgen:cparse", ptr %t420, i32 0, i32 2
  store i64 %t418, ptr %t421, !tbaa !24
  %t422 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s13)
  store %"std/prelude/text:StringBuilder" %t422, ptr %l134
  br label %bb91
bb91:
  %t423 = load %"std/prelude/text:StringBuilder", ptr %l134
  store %"std/prelude/text:StringBuilder" %t423, ptr %l7
  %t424 = load ptr, ptr %lp2
  %t425 = load { i64, ptr }, ptr %t424, !tbaa !27
  %t427 = extractvalue { i64, ptr } %t425, 1
  %t428 = extractvalue { i64, ptr } %t425, 0
  %t429 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d65, i32 0, i32 1) }, 1
  %t430 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d65, i32 0, i32 1) }, 0
  %t431 = add i64 %t428, %t430
  %t432 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t431)
  call void @olang_textcopy(ptr %t432, ptr %t427, i64 %t428)
  %t433 = getelementptr i8, ptr %t432, i64 %t428
  call void @olang_textcopy(ptr %t433, ptr %t429, i64 %t430)
  %t434 = insertvalue { i64, ptr } undef, i64 %t431, 0
  %t435 = insertvalue { i64, ptr } %t434, ptr %t432, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s13, ptr %s13, ptr %l7, { i64, ptr } %t435)
  br label %bb92
bb92:
  store i64 0, ptr %l8, !tbaa !24
  br label %bb93
bb93:
  store %olang.scope zeroinitializer, ptr %s17
  %t439 = load ptr, ptr %l1, !tbaa !29
  %t441 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3acparse_2eat(ptr %v1, ptr %s17, ptr %t439)
  store { i64, ptr } %t441, ptr %l140
  br label %bb94
bb94:
  %t442 = load { i64, ptr }, ptr %l140, !tbaa !27
  %t444 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s17, ptr %s17, { i64, ptr } %t442, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d66, i32 0, i32 1) })
  store i1 %t444, ptr %l142
  br label %bb95
bb95:
  %t445 = load i1, ptr %l142, !tbaa !21
  %t446 = xor i1 %t445, true
  %t448 = xor i1 %t446, true
  br i1 %t448, label %bb96, label %bb97
bb96:
  call void @__olang_scope_close(ptr %s17)
  br label %bb119
bb97:
  br label %bb98
bb98:
  %t450 = load i64, ptr %l8, !tbaa !24
  %t452 = icmp sgt i64 %t450, 0
  br i1 %t452, label %bb99, label %bb100
bb99:
  store %olang.scope zeroinitializer, ptr %s18
  %t454 = load ptr, ptr %l1, !tbaa !29
  %t456 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3acparse_2eat(ptr %v1, ptr %s18, ptr %t454)
  store { i64, ptr } %t456, ptr %l148
  br label %bb101
bb100:
  br label %bb112
bb101:
  %t457 = load { i64, ptr }, ptr %l148, !tbaa !27
  %t459 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s18, ptr %s18, { i64, ptr } %t457, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d67, i32 0, i32 1) })
  store i1 %t459, ptr %l150
  br label %bb102
bb102:
  %t460 = load i1, ptr %l150, !tbaa !21
  %t461 = xor i1 %t460, true
  br i1 %t461, label %bb103, label %bb104
bb103:
  %t463 = load ptr, ptr %l0, !tbaa !29
  store ptr %t463, ptr %l152, !tbaa !29
  %t464 = call ptr @__olang_scope_hold(ptr %v0)
  %t465 = ptrtoint ptr %t464 to i64
  store i64 %t465, ptr %l153, !tbaa !24
  %t466 = load i1, ptr @olang_2esole_2ecompiler_2fbindgen_3agen_2e26
  br i1 %t466, label %bb105, label %bb106
bb104:
  br label %bb110
bb105:
  %t468 = call ptr @__olang_region_make(ptr %v0)
  %t469 = ptrtoint ptr %t468 to i64
  store i64 %t469, ptr %l153, !tbaa !24
  br label %bb106
bb106:
  %t470 = load ptr, ptr %lp2
  %t471 = load { i64, ptr }, ptr %t470, !tbaa !27
  %t472 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d68, i32 0, i32 1) }, 1
  %t473 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d68, i32 0, i32 1) }, 0
  %t475 = extractvalue { i64, ptr } %t471, 1
  %t476 = extractvalue { i64, ptr } %t471, 0
  %t477 = add i64 %t473, %t476
  %t478 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d69, i32 0, i32 1) }, 1
  %t479 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d69, i32 0, i32 1) }, 0
  %t480 = add i64 %t477, %t479
  %t481 = load i64, ptr %l153
  %t482 = inttoptr i64 %t481 to ptr
  %t483 = call ptr @__olang_held_alloc(ptr %t482, i64 %t480)
  call void @olang_textcopy(ptr %t483, ptr %t472, i64 %t473)
  %t484 = getelementptr i8, ptr %t483, i64 %t473
  call void @olang_textcopy(ptr %t484, ptr %t475, i64 %t476)
  %t485 = getelementptr i8, ptr %t484, i64 %t476
  call void @olang_textcopy(ptr %t485, ptr %t478, i64 %t479)
  %t486 = insertvalue { i64, ptr } undef, i64 %t480, 0
  %t487 = insertvalue { i64, ptr } %t486, ptr %t483, 1
  %t489 = load ptr, ptr %l152, !tbaa !29
  %t491 = call i32 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eskip(ptr %v0, ptr %v0, ptr %t489, { i64, ptr } %t487)
  store i32 %t491, ptr %l158
  %t492 = icmp ne i32 %t491, 0
  br i1 %t492, label %bb108, label %ok.493, !prof !99
ok.493:
  br label %bb107
bb107:
  br label %bb109
bb108:
  %t494 = load i32, ptr %l158, !tbaa !23
  %t495 = lshr i32 %t494, 16
  %t496 = and i32 %t494, 65535
  %t497 = icmp eq i32 %t495, 1
  %t498 = select i1 %t497, i32 1, i32 0
  %t499 = icmp eq i32 %t494, 0
  %t500 = shl i32 %t498, 16
  %t501 = or i32 %t500, %t496
  %t502 = select i1 %t499, i32 0, i32 %t501
  call void @__olang_scope_close(ptr %s18)
  call void @__olang_scope_close(ptr %s17)
  call void @__olang_scope_close(ptr %s13)
  call void @__olang_scope_close(ptr %s0)
  %t504 = insertvalue { i32, %"compiler/bindgen:cx" } zeroinitializer, i32 %t502, 0
  store { i32, %"compiler/bindgen:cx" } %t504, ptr %rv
  br label %ret
bb109:
  br label %bb110
bb110:
  %t505 = load ptr, ptr %l1, !tbaa !29
  store ptr %t505, ptr %l160, !tbaa !29
  %t506 = load ptr, ptr %l160, !tbaa !29
  %t507 = getelementptr %"compiler/bindgen:cparse", ptr %t506, i32 0, i32 2
  %t508 = load i64, ptr %t507, !tbaa !24
  %t511 = add i64 %t508, 1
  %t513 = load ptr, ptr %l160, !tbaa !29
  %t514 = getelementptr %"compiler/bindgen:cparse", ptr %t513, i32 0, i32 2
  store i64 %t511, ptr %t514, !tbaa !24
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s13, ptr %s18, ptr %l7, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d70, i32 0, i32 1) })
  br label %bb111
bb111:
  call void @__olang_scope_close(ptr %s18)
  br label %bb112
bb112:
  store ptr %l7, ptr %l165, !tbaa !29
  %t516 = load ptr, ptr %l0, !tbaa !29
  store ptr %t516, ptr %l166, !tbaa !29
  %t517 = load ptr, ptr %l0, !tbaa !29
  %t518 = load ptr, ptr %l1, !tbaa !29
  %t521 = call { i32, %"compiler/bindgen:cx" } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ecExpr(ptr %v0, ptr %v1, ptr %v0, ptr %t517, ptr %t518)
  %t522 = extractvalue { i32, %"compiler/bindgen:cx" } %t521, 1
  %t523 = extractvalue { i32, %"compiler/bindgen:cx" } %t521, 0
  store i32 %t523, ptr %l171
  %t524 = icmp ne i32 %t523, 0
  br i1 %t524, label %bb114, label %ok.525, !prof !99
ok.525:
  store %"compiler/bindgen:cx" %t522, ptr %l170
  br label %bb113
bb113:
  %t526 = load %"compiler/bindgen:cx", ptr %l170
  store %"compiler/bindgen:cx" %t526, ptr %l167
  br label %bb115
bb114:
  %t527 = load i32, ptr %l171, !tbaa !23
  %t528 = lshr i32 %t527, 16
  %t529 = and i32 %t527, 65535
  %t530 = icmp eq i32 %t528, 1
  %t531 = select i1 %t530, i32 1, i32 0
  %t532 = icmp eq i32 %t527, 0
  %t533 = shl i32 %t531, 16
  %t534 = or i32 %t533, %t529
  %t535 = select i1 %t532, i32 0, i32 %t534
  call void @__olang_scope_close(ptr %s17)
  call void @__olang_scope_close(ptr %s13)
  call void @__olang_scope_close(ptr %s0)
  %t537 = insertvalue { i32, %"compiler/bindgen:cx" } zeroinitializer, i32 %t535, 0
  store { i32, %"compiler/bindgen:cx" } %t537, ptr %rv
  br label %ret
bb115:
  %t538 = load ptr, ptr %l166, !tbaa !29
  %t539 = load %"compiler/bindgen:cx", ptr %l167
  %t540 = call %"compiler/bindgen:cx" @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ecNum(ptr %v0, ptr %v0, ptr %v0, ptr %t538, %"compiler/bindgen:cx" %t539)
  store %"compiler/bindgen:cx" %t540, ptr %l173
  br label %bb116
bb116:
  %t541 = getelementptr %"compiler/bindgen:cx", ptr %l173, i32 0, i32 0
  %t542 = load { i64, ptr }, ptr %t541, !tbaa !27
  %t543 = load ptr, ptr %l165, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s13, ptr %v0, ptr %t543, { i64, ptr } %t542)
  br label %bb117
bb117:
  %t545 = load i64, ptr %l8, !tbaa !24
  %t548 = add i64 %t545, 1
  store i64 %t548, ptr %l8, !tbaa !24
  call void @__olang_scope_close(ptr %s17)
  br label %bb118
bb118:
  br label %bb93
bb119:
  %t550 = load ptr, ptr %l1, !tbaa !29
  store ptr %t550, ptr %l178, !tbaa !29
  %t551 = load ptr, ptr %l178, !tbaa !29
  %t552 = getelementptr %"compiler/bindgen:cparse", ptr %t551, i32 0, i32 2
  %t553 = load i64, ptr %t552, !tbaa !24
  %t556 = add i64 %t553, 1
  %t558 = load ptr, ptr %l178, !tbaa !29
  %t559 = getelementptr %"compiler/bindgen:cparse", ptr %t558, i32 0, i32 2
  store i64 %t556, ptr %t559, !tbaa !24
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s13, ptr %s13, ptr %l7, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d71, i32 0, i32 1) })
  br label %bb120
bb120:
  %t561 = call ptr @__olang_scope_hold(ptr %v2)
  %t562 = ptrtoint ptr %t561 to i64
  store i64 %t562, ptr %l183, !tbaa !24
  %t563 = load i1, ptr @olang_2esole_2ecompiler_2fbindgen_3acx_2e0
  br i1 %t563, label %bb121, label %bb122
bb121:
  %t565 = call ptr @__olang_region_make(ptr %v2)
  %t566 = ptrtoint ptr %t565 to i64
  store i64 %t566, ptr %l183, !tbaa !24
  br label %bb122
bb122:
  %t567 = load i64, ptr %l183
  %t568 = inttoptr i64 %t567 to ptr
  %t570 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s13, ptr %t568, ptr %l7)
  store { i64, ptr } %t570, ptr %l186
  br label %bb123
bb123:
  %t571 = load { i64, ptr }, ptr %l186, !tbaa !27
  store { i64, ptr } %t571, ptr %l187, !tbaa !27
  %t572 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t574 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s13, { i64, ptr } %t572, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d72, i32 0, i32 1) })
  store i1 %t574, ptr %l189
  br label %bb124
bb124:
  %t575 = load i1, ptr %l189, !tbaa !21
  %t576 = xor i1 %t575, true
  br i1 %t576, label %bb125, label %bb126
bb125:
  %t578 = load i64, ptr @G_2ecompiler_2fbindgen_2eKType, !tbaa !24
  store i64 %t578, ptr %l191, !tbaa !24
  br label %bb127
bb126:
  %t580 = load i64, ptr @G_2ecompiler_2fbindgen_2eKBool, !tbaa !24
  store i64 %t580, ptr %l191, !tbaa !24
  br label %bb127
bb127:
  %t582 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t583 = load { i64, ptr }, ptr %l187, !tbaa !27
  %t584 = load i64, ptr %l191, !tbaa !24
  %t586 = call %"compiler/bindgen:cx" @compiler_2fbindgen_3acx_2ector(ptr %v2, ptr %v2, ptr %v2, { i64, ptr } %t583, i64 %t584, i64 -1, { i64, ptr } %t582)
  store %"compiler/bindgen:cx" %t586, ptr %l195
  br label %bb128
bb128:
  call void @__olang_scope_close(ptr %s13)
  call void @__olang_scope_close(ptr %s0)
  %t587 = load %"compiler/bindgen:cx", ptr %l195
  %t588 = insertvalue { i32, %"compiler/bindgen:cx" } zeroinitializer, %"compiler/bindgen:cx" %t587, 1
  store { i32, %"compiler/bindgen:cx" } %t588, ptr %rv
  br label %ret
bb129:
  %t589 = load ptr, ptr %l0, !tbaa !29
  store ptr %t589, ptr %l196, !tbaa !29
  %t590 = call ptr @__olang_scope_hold(ptr %v0)
  %t591 = ptrtoint ptr %t590 to i64
  store i64 %t591, ptr %l197, !tbaa !24
  %t592 = load i1, ptr @olang_2esole_2ecompiler_2fbindgen_3agen_2e26
  br i1 %t592, label %bb130, label %bb131
bb130:
  %t594 = call ptr @__olang_region_make(ptr %v0)
  %t595 = ptrtoint ptr %t594 to i64
  store i64 %t595, ptr %l197, !tbaa !24
  br label %bb131
bb131:
  %t596 = load ptr, ptr %lp2
  %t597 = load { i64, ptr }, ptr %t596, !tbaa !27
  %t598 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d73, i32 0, i32 1) }, 1
  %t599 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d73, i32 0, i32 1) }, 0
  %t601 = extractvalue { i64, ptr } %t597, 1
  %t602 = extractvalue { i64, ptr } %t597, 0
  %t603 = add i64 %t599, %t602
  %t604 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d74, i32 0, i32 1) }, 1
  %t605 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d74, i32 0, i32 1) }, 0
  %t606 = add i64 %t603, %t605
  %t607 = load i64, ptr %l197
  %t608 = inttoptr i64 %t607 to ptr
  %t609 = call ptr @__olang_held_alloc(ptr %t608, i64 %t606)
  call void @olang_textcopy(ptr %t609, ptr %t598, i64 %t599)
  %t610 = getelementptr i8, ptr %t609, i64 %t599
  call void @olang_textcopy(ptr %t610, ptr %t601, i64 %t602)
  %t611 = getelementptr i8, ptr %t610, i64 %t602
  call void @olang_textcopy(ptr %t611, ptr %t604, i64 %t605)
  %t612 = insertvalue { i64, ptr } undef, i64 %t606, 0
  %t613 = insertvalue { i64, ptr } %t612, ptr %t609, 1
  %t615 = load ptr, ptr %l196, !tbaa !29
  %t617 = call i32 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eskip(ptr %v0, ptr %v0, ptr %t615, { i64, ptr } %t613)
  store i32 %t617, ptr %l202
  %t618 = icmp ne i32 %t617, 0
  br i1 %t618, label %bb133, label %ok.619, !prof !99
ok.619:
  br label %bb132
bb132:
  br label %bb134
bb133:
  %t620 = load i32, ptr %l202, !tbaa !23
  %t621 = lshr i32 %t620, 16
  %t622 = and i32 %t620, 65535
  %t623 = icmp eq i32 %t621, 1
  %t624 = select i1 %t623, i32 1, i32 0
  %t625 = icmp eq i32 %t620, 0
  %t626 = shl i32 %t624, 16
  %t627 = or i32 %t626, %t622
  %t628 = select i1 %t625, i32 0, i32 %t627
  call void @__olang_scope_close(ptr %s0)
  %t630 = insertvalue { i32, %"compiler/bindgen:cx" } zeroinitializer, i32 %t628, 0
  store { i32, %"compiler/bindgen:cx" } %t630, ptr %rv
  br label %ret
bb134:
  %t631 = load i64, ptr @G_2ecompiler_2fbindgen_2eKInt, !tbaa !24
  %t633 = call %"compiler/bindgen:cx" @compiler_2fbindgen_2ecx_2elit(ptr %v2, ptr %v2, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d75, i32 0, i32 1) }, i64 %t631)
  store %"compiler/bindgen:cx" %t633, ptr %l205
  br label %bb135
bb135:
  call void @__olang_scope_close(ptr %s0)
  %t634 = load %"compiler/bindgen:cx", ptr %l205
  %t635 = insertvalue { i32, %"compiler/bindgen:cx" } zeroinitializer, %"compiler/bindgen:cx" %t634, 1
  store { i32, %"compiler/bindgen:cx" } %t635, ptr %rv
  br label %ret
ret:
  %rr = load { i32, %"compiler/bindgen:cx" }, ptr %rv
  ret { i32, %"compiler/bindgen:cx" } %rr
}

define dso_local { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ecastType(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l8 = alloca i64
  %l10 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l30 = alloca i1
  %l31 = alloca i1
  %l35 = alloca i1
  %l37 = alloca { i64, ptr }
  %l38 = alloca { i64, ptr }
  %l39 = alloca i64
  %l40 = alloca { i64, ptr }
  %l46 = alloca i64
  %l50 = alloca %"compiler/bindgen:ctype"
  %l54 = alloca { i64, ptr }
  %l55 = alloca { i64, ptr }
  %l56 = alloca i64
  %l57 = alloca { i64, ptr }
  %l61 = alloca %"compiler/bindgen:ctype"
  %l63 = alloca i1
  %l64 = alloca { i64, ptr }
  %l65 = alloca { i64, ptr }
  %l70 = alloca %"compiler/bindgen:ctype"
  %l73 = alloca i64
  %l74 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = call { i64, ptr } @compiler_2fbindgen_2ectokens(ptr %v1, ptr %s0, { i64, ptr } %t1)
  store { i64, ptr } %t3, ptr %l10
  br label %bb1
bb1:
  %t4 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  %t9 = icmp eq i64 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d76, i32 0, i32 1) }, ptr %l14, !tbaa !27
  %t11 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t11, ptr %l15, !tbaa !27
  %t12 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t12, 0
  store i64 %t13, ptr %l16, !tbaa !24
  %t14 = load i64, ptr %l16, !tbaa !24
  %t15 = mul i64 %t14, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t15)
  %t17 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  store { i64, ptr } %t18, ptr %l17, !tbaa !27
  %t19 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !27
  %t21 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = load i64, ptr %l16, !tbaa !24
  %t24 = mul i64 %t23, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t20, ptr %t22, i64 %t24, i1 false)
  %t25 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t25, ptr %l15, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t26 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t26, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t27 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t27, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t29 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t31 = extractvalue { i64, ptr } %t29, 0
  store i64 %t31, ptr %l5, !tbaa !24
  br label %bb5
bb5:
  store %olang.scope zeroinitializer, ptr %s3
  %t33 = load i64, ptr %l4, !tbaa !24
  %t34 = load i64, ptr %l5, !tbaa !24
  %t37 = icmp slt i64 %t33, %t34
  %t39 = xor i1 %t37, true
  br i1 %t39, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s3)
  br label %bb18
bb7:
  br label %bb8
bb8:
  %t41 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t41, ptr %l25, !tbaa !27
  %t42 = load i64, ptr %l4, !tbaa !24
  %t44 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !27
  %t46 = getelementptr { i64, ptr }, ptr %t45, i64 %t42
  %t47 = load { i64, ptr }, ptr %t46, !tbaa !37
  store { i64, ptr } %t47, ptr %l6, !tbaa !27
  %t49 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t53 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2eHas_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %s3, ptr %s0, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x { i64, ptr }] }>, ptr @.d77, i32 0, i32 1) }, { i64, ptr } %t49)
  store i1 %t53, ptr %l30
  br label %bb9
bb9:
  %t54 = load i1, ptr %l30, !tbaa !21
  br i1 %t54, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l31, !tbaa !21
  br label %bb13
bb11:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/bindgen:gen", ptr %t55, i32 0, i32 5
  %t58 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t61 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_He27db0a1785588531472bfd2db42574f(ptr %v0, ptr %s0, ptr %t57, { i64, ptr } %t58)
  store i1 %t61, ptr %l35
  br label %bb12
bb12:
  %t62 = load i1, ptr %l35, !tbaa !21
  store i1 %t62, ptr %l31, !tbaa !21
  br label %bb13
bb13:
  %t63 = load i1, ptr %l31, !tbaa !21
  %t64 = xor i1 %t63, true
  br i1 %t64, label %bb14, label %bb15
bb14:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d78, i32 0, i32 1) }, ptr %l37, !tbaa !27
  %t66 = load { i64, ptr }, ptr %l37, !tbaa !27
  store { i64, ptr } %t66, ptr %l38, !tbaa !27
  %t67 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t68 = extractvalue { i64, ptr } %t67, 0
  store i64 %t68, ptr %l39, !tbaa !24
  %t69 = load i64, ptr %l39, !tbaa !24
  %t70 = mul i64 %t69, 1
  %t71 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t70)
  %t72 = insertvalue { i64, ptr } undef, i64 %t69, 0
  %t73 = insertvalue { i64, ptr } %t72, ptr %t71, 1
  store { i64, ptr } %t73, ptr %l40, !tbaa !27
  %t74 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t75 = load ptr, ptr %t74, !tbaa !27
  %t76 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t77 = load ptr, ptr %t76, !tbaa !27
  %t78 = load i64, ptr %l39, !tbaa !24
  %t79 = mul i64 %t78, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t75, ptr %t77, i64 %t79, i1 false)
  %t80 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t80, ptr %l38, !tbaa !27
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t81 = load { i64, ptr }, ptr %l38, !tbaa !27
  store { i64, ptr } %t81, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s3)
  br label %bb17
bb17:
  %t82 = load i64, ptr %l4, !tbaa !24
  %t85 = add i64 %t82, 1
  store i64 %t85, ptr %l4, !tbaa !24
  br label %bb5
bb18:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t88 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t91 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eparseType(ptr %v0, ptr %v1, ptr %t87, { i64, ptr } %t88, i64 0)
  store i64 %t91, ptr %l46
  br label %bb19
bb19:
  %t92 = load i64, ptr %l46, !tbaa !24
  store i64 %t92, ptr %l8, !tbaa !24
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/bindgen:gen", ptr %t93, i32 0, i32 17
  %t96 = load i64, ptr %l8, !tbaa !24
  %t99 = call %"compiler/bindgen:ctype" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3actype_3e_2eAt_3ccompiler_2fbindgen_3actype_3e(ptr %v0, ptr %s0, ptr %t95, i64 %t96)
  store %"compiler/bindgen:ctype" %t99, ptr %l50
  br label %bb20
bb20:
  %t100 = getelementptr %"compiler/bindgen:ctype", ptr %l50, i32 0, i32 0
  %t101 = load i32, ptr %t100, !range !{i32 0, i32 7}
  %t103 = trunc i64 1 to i32
  %t104 = icmp eq i32 %t101, %t103
  %t106 = xor i1 %t104, true
  br i1 %t106, label %bb21, label %bb22
bb21:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d79, i32 0, i32 1) }, ptr %l54, !tbaa !27
  %t108 = load { i64, ptr }, ptr %l54, !tbaa !27
  store { i64, ptr } %t108, ptr %l55, !tbaa !27
  %t109 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t110 = extractvalue { i64, ptr } %t109, 0
  store i64 %t110, ptr %l56, !tbaa !24
  %t111 = load i64, ptr %l56, !tbaa !24
  %t112 = mul i64 %t111, 1
  %t113 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t112)
  %t114 = insertvalue { i64, ptr } undef, i64 %t111, 0
  %t115 = insertvalue { i64, ptr } %t114, ptr %t113, 1
  store { i64, ptr } %t115, ptr %l57, !tbaa !27
  %t116 = getelementptr { i64, ptr }, ptr %l57, i32 0, i32 1
  %t117 = load ptr, ptr %t116, !tbaa !27
  %t118 = getelementptr { i64, ptr }, ptr %l55, i32 0, i32 1
  %t119 = load ptr, ptr %t118, !tbaa !27
  %t120 = load i64, ptr %l56, !tbaa !24
  %t121 = mul i64 %t120, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t117, ptr %t119, i64 %t121, i1 false)
  %t122 = load { i64, ptr }, ptr %l57, !tbaa !27
  store { i64, ptr } %t122, ptr %l55, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t123 = load { i64, ptr }, ptr %l55, !tbaa !27
  store { i64, ptr } %t123, ptr %rv
  br label %ret
bb22:
  br label %bb23
bb23:
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t126 = getelementptr %"compiler/bindgen:gen", ptr %t124, i32 0, i32 17
  %t127 = load i64, ptr %l8, !tbaa !24
  %t130 = call %"compiler/bindgen:ctype" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3actype_3e_2eAt_3ccompiler_2fbindgen_3actype_3e(ptr %v0, ptr %v0, ptr %t126, i64 %t127)
  store %"compiler/bindgen:ctype" %t130, ptr %l61
  br label %bb24
bb24:
  %t131 = getelementptr %"compiler/bindgen:ctype", ptr %l61, i32 0, i32 1
  %t132 = load { i64, ptr }, ptr %t131, !tbaa !27
  %t134 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t132, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d80, i32 0, i32 1) })
  store i1 %t134, ptr %l63
  br label %bb25
bb25:
  %t135 = load i1, ptr %l63, !tbaa !21
  br i1 %t135, label %bb26, label %bb27
bb26:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d81, i32 0, i32 1) }, ptr %l65, !tbaa !27
  %t136 = load { i64, ptr }, ptr %l65, !tbaa !27
  store { i64, ptr } %t136, ptr %l64, !tbaa !27
  br label %bb29
bb27:
  %t138 = load ptr, ptr %l0, !tbaa !29
  %t140 = getelementptr %"compiler/bindgen:gen", ptr %t138, i32 0, i32 17
  %t141 = load i64, ptr %l8, !tbaa !24
  %t144 = call %"compiler/bindgen:ctype" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3actype_3e_2eAt_3ccompiler_2fbindgen_3actype_3e(ptr %v0, ptr %v0, ptr %t140, i64 %t141)
  store %"compiler/bindgen:ctype" %t144, ptr %l70
  br label %bb28
bb28:
  %t145 = getelementptr %"compiler/bindgen:ctype", ptr %l70, i32 0, i32 1
  %t146 = load { i64, ptr }, ptr %t145, !tbaa !27
  %t148 = extractvalue { i64, ptr } %t146, 1
  %t149 = extractvalue { i64, ptr } %t146, 0
  %t150 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t149)
  call void @olang_textcopy(ptr %t150, ptr %t148, i64 %t149)
  %t151 = insertvalue { i64, ptr } undef, i64 %t149, 0
  %t152 = insertvalue { i64, ptr } %t151, ptr %t150, 1
  store { i64, ptr } %t152, ptr %l64, !tbaa !27
  br label %bb29
bb29:
  %t154 = load { i64, ptr }, ptr %l64, !tbaa !27
  %t155 = extractvalue { i64, ptr } %t154, 0
  store i64 %t155, ptr %l73, !tbaa !24
  %t156 = load i64, ptr %l73, !tbaa !24
  %t157 = mul i64 %t156, 1
  %t158 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t157)
  %t159 = insertvalue { i64, ptr } undef, i64 %t156, 0
  %t160 = insertvalue { i64, ptr } %t159, ptr %t158, 1
  store { i64, ptr } %t160, ptr %l74, !tbaa !27
  %t161 = getelementptr { i64, ptr }, ptr %l74, i32 0, i32 1
  %t162 = load ptr, ptr %t161, !tbaa !27
  %t163 = getelementptr { i64, ptr }, ptr %l64, i32 0, i32 1
  %t164 = load ptr, ptr %t163, !tbaa !27
  %t165 = load i64, ptr %l73, !tbaa !24
  %t166 = mul i64 %t165, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t162, ptr %t164, i64 %t166, i1 false)
  %t167 = load { i64, ptr }, ptr %l74, !tbaa !27
  store { i64, ptr } %t167, ptr %l64, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t168 = load { i64, ptr }, ptr %l64, !tbaa !27
  store { i64, ptr } %t168, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2edeclarator(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2, i1 %a3, i64 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i1
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l10 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l11 = alloca i1
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca ptr
  %l15 = alloca i64
  %l17 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l31 = alloca { i64, ptr }
  %l33 = alloca i1
  %l39 = alloca i64
  %l40 = alloca ptr
  %l45 = alloca { i64, ptr }
  %l47 = alloca i1
  %l48 = alloca i1
  %l50 = alloca { i64, ptr }
  %l52 = alloca i1
  %l55 = alloca { i64, ptr }
  %l57 = alloca i1
  %l58 = alloca ptr
  %l63 = alloca { i64, ptr }
  %l65 = alloca i1
  %l66 = alloca i1
  %l68 = alloca { i64, ptr }
  %l70 = alloca i1
  %l71 = alloca i1
  %l73 = alloca { i64, ptr }
  %l75 = alloca i1
  %l76 = alloca i1
  %l78 = alloca { i64, ptr }
  %l80 = alloca i1
  %l92 = alloca { i64, ptr }
  %l94 = alloca i1
  %l99 = alloca { i64, ptr }
  %l101 = alloca i1
  %l107 = alloca ptr
  %l111 = alloca ptr
  %l115 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l117 = alloca { i64, ptr }
  %l119 = alloca i1
  %l120 = alloca ptr
  %l124 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l131 = alloca i1
  %l133 = alloca { i64, ptr }
  %l135 = alloca i1
  %l139 = alloca { i64, ptr }
  %l141 = alloca i1
  %l142 = alloca ptr
  %l149 = alloca i64
  %l153 = alloca %"compiler/bindgen:ctype"
  %l156 = alloca i1
  %l158 = alloca i64
  %l160 = alloca i1
  %l162 = alloca { i64, ptr }
  %l164 = alloca i1
  %l169 = alloca { i64, ptr }
  %l171 = alloca i1
  %l172 = alloca ptr
  %l176 = alloca ptr
  %l182 = alloca i64
  %l184 = alloca i64
  %l186 = alloca i64
  %l191 = alloca i64
  %l198 = alloca ptr
  %l199 = alloca i32
  %l201 = alloca { i64, ptr }
  %l202 = alloca i64
  %l204 = alloca i64
  %l205 = alloca i64
  %l210 = alloca ptr
  %l215 = alloca { i64, ptr }
  %l217 = alloca i1
  %l218 = alloca ptr
  %l223 = alloca { i64, ptr }
  %l225 = alloca i1
  %l227 = alloca i64
  %l229 = alloca { i64, ptr }
  %l230 = alloca { i64, ptr }
  %l231 = alloca i64
  %l232 = alloca i32
  %l233 = alloca i64
  %l234 = alloca i32
  %l235 = alloca ptr
  %l239 = alloca ptr
  %l246 = alloca i64
  %l250 = alloca i64
  %l253 = alloca i64
  %l271 = alloca ptr
  %l272 = alloca i32
  %l273 = alloca i64
  %l274 = alloca ptr
  %l276 = alloca i64
  %l280 = alloca i64
  %l281 = alloca i64
  %l295 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i64 %a2, ptr %l5, !tbaa !24
  store i1 %a3, ptr %l6, !tbaa !21
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t7 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3actp_2eat(ptr %v1, ptr %s1, ptr %t5, i64 0)
  store { i64, ptr } %t7, ptr %l31
  br label %bb2
bb2:
  %t8 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t10 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s1, ptr %s1, { i64, ptr } %t8, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d82, i32 0, i32 1) })
  store i1 %t10, ptr %l33
  br label %bb3
bb3:
  %t11 = load i1, ptr %l33, !tbaa !21
  %t12 = xor i1 %t11, true
  br i1 %t12, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s1)
  br label %bb24
bb5:
  br label %bb6
bb6:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t15 = load i64, ptr %l5, !tbaa !24
  %t16 = load i1, ptr %l6, !tbaa !21
  %t21 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2enode(ptr %v0, ptr %v0, ptr %t14, i32 3, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d83, i32 0, i32 1) }, i64 %t15, i1 %t16, i64 0)
  store i64 %t21, ptr %l39
  br label %bb7
bb7:
  %t22 = load i64, ptr %l39, !tbaa !24
  store i64 %t22, ptr %l5, !tbaa !24
  %t23 = load ptr, ptr %l1, !tbaa !29
  store ptr %t23, ptr %l40, !tbaa !29
  %t24 = load ptr, ptr %l40, !tbaa !29
  %t25 = getelementptr %"compiler/bindgen:ctp", ptr %t24, i32 0, i32 1
  %t26 = load i64, ptr %t25, !tbaa !24
  %t29 = add i64 %t26, 1
  %t31 = load ptr, ptr %l40, !tbaa !29
  %t32 = getelementptr %"compiler/bindgen:ctp", ptr %t31, i32 0, i32 1
  store i64 %t29, ptr %t32, !tbaa !24
  store i1 false, ptr %l6, !tbaa !21
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t33 = load ptr, ptr %l1, !tbaa !29
  %t35 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3actp_2eat(ptr %v1, ptr %s2, ptr %t33, i64 0)
  store { i64, ptr } %t35, ptr %l45
  br label %bb9
bb9:
  %t36 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t38 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s2, ptr %s2, { i64, ptr } %t36, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d84, i32 0, i32 1) })
  store i1 %t38, ptr %l47
  br label %bb10
bb10:
  %t39 = load i1, ptr %l47, !tbaa !21
  br i1 %t39, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l48, !tbaa !21
  br label %bb15
bb12:
  %t40 = load ptr, ptr %l1, !tbaa !29
  %t42 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3actp_2eat(ptr %v1, ptr %s2, ptr %t40, i64 0)
  store { i64, ptr } %t42, ptr %l50
  br label %bb13
bb13:
  %t43 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t45 = call i1 @compiler_2fbindgen_2epassOver(ptr %s2, { i64, ptr } %t43)
  store i1 %t45, ptr %l52
  br label %bb14
bb14:
  %t46 = load i1, ptr %l52, !tbaa !21
  store i1 %t46, ptr %l48, !tbaa !21
  br label %bb15
bb15:
  %t47 = load i1, ptr %l48, !tbaa !21
  %t48 = xor i1 %t47, true
  br i1 %t48, label %bb16, label %bb17
bb16:
  call void @__olang_scope_close(ptr %s2)
  br label %bb22
bb17:
  br label %bb18
bb18:
  %t50 = load ptr, ptr %l1, !tbaa !29
  %t52 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3actp_2eat(ptr %v1, ptr %s2, ptr %t50, i64 0)
  store { i64, ptr } %t52, ptr %l55
  br label %bb19
bb19:
  %t53 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t55 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s2, ptr %s2, { i64, ptr } %t53, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d85, i32 0, i32 1) })
  store i1 %t55, ptr %l57
  br label %bb20
bb20:
  %t56 = load i1, ptr %l57, !tbaa !21
  store i1 %t56, ptr %l6, !tbaa !21
  %t57 = load ptr, ptr %l1, !tbaa !29
  store ptr %t57, ptr %l58, !tbaa !29
  %t58 = load ptr, ptr %l58, !tbaa !29
  %t59 = getelementptr %"compiler/bindgen:ctp", ptr %t58, i32 0, i32 1
  %t60 = load i64, ptr %t59, !tbaa !24
  %t63 = add i64 %t60, 1
  %t65 = load ptr, ptr %l58, !tbaa !29
  %t66 = getelementptr %"compiler/bindgen:ctp", ptr %t65, i32 0, i32 1
  store i64 %t63, ptr %t66, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb21
bb21:
  br label %bb8
bb22:
  call void @__olang_scope_close(ptr %s1)
  br label %bb23
bb23:
  br label %bb1
bb24:
  store i64 -1, ptr %l7, !tbaa !24
  %t67 = load ptr, ptr %l1, !tbaa !29
  %t69 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3actp_2eat(ptr %v1, ptr %s0, ptr %t67, i64 0)
  store { i64, ptr } %t69, ptr %l63
  br label %bb25
bb25:
  %t70 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t72 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t70, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d86, i32 0, i32 1) })
  store i1 %t72, ptr %l65
  br label %bb26
bb26:
  %t73 = load i1, ptr %l65, !tbaa !21
  br i1 %t73, label %bb27, label %bb28
bb27:
  %t74 = load ptr, ptr %l1, !tbaa !29
  %t76 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3actp_2eat(ptr %v1, ptr %s0, ptr %t74, i64 1)
  store { i64, ptr } %t76, ptr %l68
  br label %bb29
bb28:
  store i1 false, ptr %l66, !tbaa !21
  br label %bb41
bb29:
  %t77 = load { i64, ptr }, ptr %l68, !tbaa !27
  %t79 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t77, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d87, i32 0, i32 1) })
  store i1 %t79, ptr %l70
  br label %bb30
bb30:
  %t80 = load i1, ptr %l70, !tbaa !21
  br i1 %t80, label %bb31, label %bb32
bb31:
  store i1 true, ptr %l71, !tbaa !21
  br label %bb35
bb32:
  %t81 = load ptr, ptr %l1, !tbaa !29
  %t83 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3actp_2eat(ptr %v1, ptr %s0, ptr %t81, i64 1)
  store { i64, ptr } %t83, ptr %l73
  br label %bb33
bb33:
  %t84 = load { i64, ptr }, ptr %l73, !tbaa !27
  %t86 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t84, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d88, i32 0, i32 1) })
  store i1 %t86, ptr %l75
  br label %bb34
bb34:
  %t87 = load i1, ptr %l75, !tbaa !21
  store i1 %t87, ptr %l71, !tbaa !21
  br label %bb35
bb35:
  %t88 = load i1, ptr %l71, !tbaa !21
  br i1 %t88, label %bb36, label %bb37
bb36:
  store i1 true, ptr %l76, !tbaa !21
  br label %bb40
bb37:
  %t89 = load ptr, ptr %l1, !tbaa !29
  %t91 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3actp_2eat(ptr %v1, ptr %s0, ptr %t89, i64 1)
  store { i64, ptr } %t91, ptr %l78
  br label %bb38
bb38:
  %t92 = load { i64, ptr }, ptr %l78, !tbaa !27
  %t94 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t92, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d89, i32 0, i32 1) })
  store i1 %t94, ptr %l80
  br label %bb39
bb39:
  %t95 = load i1, ptr %l80, !tbaa !21
  store i1 %t95, ptr %l76, !tbaa !21
  br label %bb40
bb40:
  %t96 = load i1, ptr %l76, !tbaa !21
  store i1 %t96, ptr %l66, !tbaa !21
  br label %bb41
bb41:
  %t97 = load i1, ptr %l66, !tbaa !21
  br i1 %t97, label %bb42, label %bb43
bb42:
  %t98 = load ptr, ptr %l1, !tbaa !29
  %t100 = getelementptr %"compiler/bindgen:ctp", ptr %t98, i32 0, i32 1
  %t101 = load i64, ptr %t100, !tbaa !24
  %t103 = add i64 %t101, 1
  store i64 %t103, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb44
bb43:
  br label %bb63
bb44:
  store %olang.scope zeroinitializer, ptr %s4
  %t105 = load ptr, ptr %l1, !tbaa !29
  %t107 = getelementptr %"compiler/bindgen:ctp", ptr %t105, i32 0, i32 1
  %t108 = load i64, ptr %t107, !tbaa !24
  %t109 = load ptr, ptr %l1, !tbaa !29
  %t111 = getelementptr %"compiler/bindgen:ctp", ptr %t109, i32 0, i32 0
  %t112 = load { i64, ptr }, ptr %t111, !tbaa !27
  %t114 = extractvalue { i64, ptr } %t112, 0
  %t117 = icmp slt i64 %t108, %t114
  %t119 = xor i1 %t117, true
  br i1 %t119, label %bb45, label %bb46
bb45:
  call void @__olang_scope_close(ptr %s4)
  br label %bb62
bb46:
  br label %bb47
bb47:
  %t121 = load ptr, ptr %l1, !tbaa !29
  %t123 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3actp_2eat(ptr %v1, ptr %s4, ptr %t121, i64 0)
  store { i64, ptr } %t123, ptr %l92
  br label %bb48
bb48:
  %t124 = load { i64, ptr }, ptr %l92, !tbaa !27
  %t126 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s4, ptr %s4, { i64, ptr } %t124, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d90, i32 0, i32 1) })
  store i1 %t126, ptr %l94
  br label %bb49
bb49:
  %t127 = load i1, ptr %l94, !tbaa !21
  br i1 %t127, label %bb50, label %bb51
bb50:
  %t128 = load i64, ptr %l8, !tbaa !24
  %t131 = add i64 %t128, 1
  store i64 %t131, ptr %l8, !tbaa !24
  br label %bb52
bb51:
  br label %bb52
bb52:
  %t133 = load ptr, ptr %l1, !tbaa !29
  %t135 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3actp_2eat(ptr %v1, ptr %s4, ptr %t133, i64 0)
  store { i64, ptr } %t135, ptr %l99
  br label %bb53
bb53:
  %t136 = load { i64, ptr }, ptr %l99, !tbaa !27
  %t138 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s4, ptr %s4, { i64, ptr } %t136, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d91, i32 0, i32 1) })
  store i1 %t138, ptr %l101
  br label %bb54
bb54:
  %t139 = load i1, ptr %l101, !tbaa !21
  br i1 %t139, label %bb55, label %bb56
bb55:
  %t140 = load i64, ptr %l8, !tbaa !24
  %t143 = sub i64 %t140, 1
  store i64 %t143, ptr %l8, !tbaa !24
  %t145 = load i64, ptr %l8, !tbaa !24
  %t147 = icmp eq i64 %t145, 0
  br i1 %t147, label %bb57, label %bb58
bb56:
  br label %bb60
bb57:
  call void @__olang_scope_close(ptr %s4)
  br label %bb62
bb58:
  br label %bb59
bb59:
  br label %bb60
bb60:
  %t149 = load ptr, ptr %l1, !tbaa !29
  store ptr %t149, ptr %l107, !tbaa !29
  %t150 = load ptr, ptr %l107, !tbaa !29
  %t151 = getelementptr %"compiler/bindgen:ctp", ptr %t150, i32 0, i32 1
  %t152 = load i64, ptr %t151, !tbaa !24
  %t155 = add i64 %t152, 1
  %t157 = load ptr, ptr %l107, !tbaa !29
  %t158 = getelementptr %"compiler/bindgen:ctp", ptr %t157, i32 0, i32 1
  store i64 %t155, ptr %t158, !tbaa !24
  call void @__olang_scope_close(ptr %s4)
  br label %bb61
bb61:
  br label %bb44
bb62:
  %t159 = load ptr, ptr %l1, !tbaa !29
  store ptr %t159, ptr %l111, !tbaa !29
  %t160 = load ptr, ptr %l111, !tbaa !29
  %t161 = getelementptr %"compiler/bindgen:ctp", ptr %t160, i32 0, i32 1
  %t162 = load i64, ptr %t161, !tbaa !24
  %t165 = add i64 %t162, 1
  %t167 = load ptr, ptr %l111, !tbaa !29
  %t168 = getelementptr %"compiler/bindgen:ctp", ptr %t167, i32 0, i32 1
  store i64 %t165, ptr %t168, !tbaa !24
  br label %bb63
bb63:
  %t169 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t169, ptr %l115
  br label %bb64
bb64:
  %t170 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l115
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t170, ptr %l9
  br label %bb65
bb65:
  store %olang.scope zeroinitializer, ptr %s8
  %t171 = load ptr, ptr %l1, !tbaa !29
  %t173 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3actp_2eat(ptr %v1, ptr %s8, ptr %t171, i64 0)
  store { i64, ptr } %t173, ptr %l117
  br label %bb66
bb66:
  %t174 = load { i64, ptr }, ptr %l117, !tbaa !27
  %t176 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s8, ptr %s8, { i64, ptr } %t174, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d92, i32 0, i32 1) })
  store i1 %t176, ptr %l119
  br label %bb67
bb67:
  %t177 = load i1, ptr %l119, !tbaa !21
  br i1 %t177, label %bb68, label %bb69
bb68:
  store %olang.scope zeroinitializer, ptr %s9
  %t178 = load ptr, ptr %l1, !tbaa !29
  store ptr %t178, ptr %l120, !tbaa !29
  %t179 = load ptr, ptr %l120, !tbaa !29
  %t180 = getelementptr %"compiler/bindgen:ctp", ptr %t179, i32 0, i32 1
  %t181 = load i64, ptr %t180, !tbaa !24
  %t184 = add i64 %t181, 1
  %t186 = load ptr, ptr %l120, !tbaa !29
  %t187 = getelementptr %"compiler/bindgen:ctp", ptr %t186, i32 0, i32 1
  store i64 %t184, ptr %t187, !tbaa !24
  %t188 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s9, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t188, ptr %l124
  br label %bb70
bb69:
  store %olang.scope zeroinitializer, ptr %s18
  %t189 = load ptr, ptr %l1, !tbaa !29
  %t191 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3actp_2eat(ptr %v1, ptr %s18, ptr %t189, i64 0)
  store { i64, ptr } %t191, ptr %l215
  br label %bb123
bb70:
  %t192 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l124
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t192, ptr %l10
  store i1 false, ptr %l11, !tbaa !21
  br label %bb71
bb71:
  store %olang.scope zeroinitializer, ptr %s10
  %t193 = load ptr, ptr %l1, !tbaa !29
  %t195 = getelementptr %"compiler/bindgen:ctp", ptr %t193, i32 0, i32 1
  %t196 = load i64, ptr %t195, !tbaa !24
  %t197 = load ptr, ptr %l1, !tbaa !29
  %t199 = getelementptr %"compiler/bindgen:ctp", ptr %t197, i32 0, i32 0
  %t200 = load { i64, ptr }, ptr %t199, !tbaa !27
  %t202 = extractvalue { i64, ptr } %t200, 0
  %t205 = icmp slt i64 %t196, %t202
  br i1 %t205, label %bb72, label %bb73
bb72:
  %t207 = load ptr, ptr %l1, !tbaa !29
  %t209 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3actp_2eat(ptr %v1, ptr %s10, ptr %t207, i64 0)
  store { i64, ptr } %t209, ptr %l133
  br label %bb74
bb73:
  store i1 false, ptr %l131, !tbaa !21
  br label %bb76
bb74:
  %t210 = load { i64, ptr }, ptr %l133, !tbaa !27
  %t212 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s10, ptr %s10, { i64, ptr } %t210, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d93, i32 0, i32 1) })
  store i1 %t212, ptr %l135
  br label %bb75
bb75:
  %t213 = load i1, ptr %l135, !tbaa !21
  %t214 = xor i1 %t213, true
  store i1 %t214, ptr %l131, !tbaa !21
  br label %bb76
bb76:
  %t216 = load i1, ptr %l131, !tbaa !21
  %t217 = xor i1 %t216, true
  br i1 %t217, label %bb77, label %bb78
bb77:
  call void @__olang_scope_close(ptr %s10)
  br label %bb106
bb78:
  br label %bb79
bb79:
  %t219 = load ptr, ptr %l1, !tbaa !29
  %t221 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3actp_2eat(ptr %v1, ptr %s10, ptr %t219, i64 0)
  store { i64, ptr } %t221, ptr %l139
  br label %bb80
bb80:
  %t222 = load { i64, ptr }, ptr %l139, !tbaa !27
  %t224 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s10, ptr %s10, { i64, ptr } %t222, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d94, i32 0, i32 1) })
  store i1 %t224, ptr %l141
  br label %bb81
bb81:
  %t225 = load i1, ptr %l141, !tbaa !21
  br i1 %t225, label %bb82, label %bb83
bb82:
  store i1 true, ptr %l11, !tbaa !21
  %t226 = load ptr, ptr %l1, !tbaa !29
  store ptr %t226, ptr %l142, !tbaa !29
  %t227 = load ptr, ptr %l142, !tbaa !29
  %t228 = getelementptr %"compiler/bindgen:ctp", ptr %t227, i32 0, i32 1
  %t229 = load i64, ptr %t228, !tbaa !24
  %t232 = add i64 %t229, 1
  %t234 = load ptr, ptr %l142, !tbaa !29
  %t235 = getelementptr %"compiler/bindgen:ctp", ptr %t234, i32 0, i32 1
  store i64 %t232, ptr %t235, !tbaa !24
  br label %bb99
bb83:
  store %olang.scope zeroinitializer, ptr %s12
  %t236 = load ptr, ptr %l0, !tbaa !29
  %t237 = load ptr, ptr %l1, !tbaa !29
  %t238 = load i64, ptr %l4, !tbaa !24
  %t242 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2etypeName(ptr %v0, ptr %v1, ptr %t236, ptr %t237, i64 %t238)
  store i64 %t242, ptr %l149
  br label %bb84
bb84:
  %t243 = load i64, ptr %l149, !tbaa !24
  store i64 %t243, ptr %l12, !tbaa !24
  %t244 = load ptr, ptr %l0, !tbaa !29
  %t246 = getelementptr %"compiler/bindgen:gen", ptr %t244, i32 0, i32 17
  %t247 = load i64, ptr %l12, !tbaa !24
  %t250 = call %"compiler/bindgen:ctype" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3actype_3e_2eAt_3ccompiler_2fbindgen_3actype_3e(ptr %v0, ptr %s12, ptr %t246, i64 %t247)
  store %"compiler/bindgen:ctype" %t250, ptr %l153
  br label %bb85
bb85:
  %t251 = getelementptr %"compiler/bindgen:ctype", ptr %l153, i32 0, i32 0
  %t252 = load i32, ptr %t251, !range !{i32 0, i32 7}
  %t254 = trunc i64 0 to i32
  %t255 = icmp eq i32 %t252, %t254
  br i1 %t255, label %bb86, label %bb87
bb86:
  %t258 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s9, ptr %l10)
  store i64 %t258, ptr %l158
  br label %bb88
bb87:
  store i1 false, ptr %l156, !tbaa !21
  br label %bb89
bb88:
  %t259 = load i64, ptr %l158, !tbaa !24
  %t260 = icmp eq i64 %t259, 0
  store i1 %t260, ptr %l156, !tbaa !21
  br label %bb89
bb89:
  %t262 = load i1, ptr %l156, !tbaa !21
  br i1 %t262, label %bb90, label %bb91
bb90:
  %t263 = load ptr, ptr %l1, !tbaa !29
  %t265 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3actp_2eat(ptr %v1, ptr %s12, ptr %t263, i64 0)
  store { i64, ptr } %t265, ptr %l162
  br label %bb92
bb91:
  store i1 false, ptr %l160, !tbaa !21
  br label %bb94
bb92:
  %t266 = load { i64, ptr }, ptr %l162, !tbaa !27
  %t268 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s12, ptr %s12, { i64, ptr } %t266, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d95, i32 0, i32 1) })
  store i1 %t268, ptr %l164
  br label %bb93
bb93:
  %t269 = load i1, ptr %l164, !tbaa !21
  store i1 %t269, ptr %l160, !tbaa !21
  br label %bb94
bb94:
  %t270 = load i1, ptr %l160, !tbaa !21
  %t271 = xor i1 %t270, true
  br i1 %t271, label %bb95, label %bb96
bb95:
  %t273 = load i64, ptr %l12, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s9, ptr %l10, i64 %t273)
  br label %bb97
bb96:
  br label %bb98
bb97:
  br label %bb98
bb98:
  call void @__olang_scope_close(ptr %s12)
  br label %bb99
bb99:
  %t276 = load ptr, ptr %l1, !tbaa !29
  %t278 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3actp_2eat(ptr %v1, ptr %s10, ptr %t276, i64 0)
  store { i64, ptr } %t278, ptr %l169
  br label %bb100
bb100:
  %t279 = load { i64, ptr }, ptr %l169, !tbaa !27
  %t281 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s10, ptr %s10, { i64, ptr } %t279, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d96, i32 0, i32 1) })
  store i1 %t281, ptr %l171
  br label %bb101
bb101:
  %t282 = load i1, ptr %l171, !tbaa !21
  br i1 %t282, label %bb102, label %bb103
bb102:
  %t283 = load ptr, ptr %l1, !tbaa !29
  store ptr %t283, ptr %l172, !tbaa !29
  %t284 = load ptr, ptr %l172, !tbaa !29
  %t285 = getelementptr %"compiler/bindgen:ctp", ptr %t284, i32 0, i32 1
  %t286 = load i64, ptr %t285, !tbaa !24
  %t289 = add i64 %t286, 1
  %t291 = load ptr, ptr %l172, !tbaa !29
  %t292 = getelementptr %"compiler/bindgen:ctp", ptr %t291, i32 0, i32 1
  store i64 %t289, ptr %t292, !tbaa !24
  br label %bb104
bb103:
  br label %bb104
bb104:
  call void @__olang_scope_close(ptr %s10)
  br label %bb105
bb105:
  br label %bb71
bb106:
  %t293 = load ptr, ptr %l1, !tbaa !29
  store ptr %t293, ptr %l176, !tbaa !29
  %t294 = load ptr, ptr %l176, !tbaa !29
  %t295 = getelementptr %"compiler/bindgen:ctp", ptr %t294, i32 0, i32 1
  %t296 = load i64, ptr %t295, !tbaa !24
  %t299 = add i64 %t296, 1
  %t301 = load ptr, ptr %l176, !tbaa !29
  %t302 = getelementptr %"compiler/bindgen:ctp", ptr %t301, i32 0, i32 1
  store i64 %t299, ptr %t302, !tbaa !24
  %t303 = load ptr, ptr %l0, !tbaa !29
  %t305 = getelementptr %"compiler/bindgen:gen", ptr %t303, i32 0, i32 18
  %t307 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t305)
  store i64 %t307, ptr %l182
  br label %bb107
bb107:
  %t308 = load i64, ptr %l182, !tbaa !24
  store i64 %t308, ptr %l13, !tbaa !24
  store ptr %l10, ptr %l14, !tbaa !29
  store i64 0, ptr %l15, !tbaa !24
  br label %bb108
bb108:
  %t310 = load i64, ptr %l15, !tbaa !24
  store i64 %t310, ptr %l184, !tbaa !24
  %t311 = load ptr, ptr %l14, !tbaa !29
  %t313 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s9, ptr %t311)
  store i64 %t313, ptr %l186
  br label %bb109
bb109:
  %t314 = load i64, ptr %l184, !tbaa !24
  %t315 = load i64, ptr %l186, !tbaa !24
  %t316 = icmp slt i64 %t314, %t315
  %t318 = xor i1 %t316, true
  br i1 %t318, label %bb110, label %bb111
bb110:
  br label %bb116
bb111:
  br label %bb112
bb112:
  %t320 = load ptr, ptr %l14, !tbaa !29
  %t321 = load i64, ptr %l15, !tbaa !24
  %t324 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s9, ptr %t320, i64 %t321)
  store i64 %t324, ptr %l191
  br label %bb113
bb113:
  %t325 = load i64, ptr %l191, !tbaa !24
  %t326 = load ptr, ptr %l0, !tbaa !29
  %t328 = getelementptr %"compiler/bindgen:gen", ptr %t326, i32 0, i32 18
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t328, i64 %t325)
  br label %bb114
bb114:
  br label %bb115
bb115:
  %t332 = load i64, ptr %l15, !tbaa !24
  %t335 = add i64 %t332, 1
  store i64 %t335, ptr %l15, !tbaa !24
  br label %bb108
bb116:
  %t337 = load ptr, ptr %l0, !tbaa !29
  store ptr %t337, ptr %l198, !tbaa !29
  store i32 5, ptr %l199
  %t338 = load i1, ptr %l11, !tbaa !21
  br i1 %t338, label %bb117, label %bb118
bb117:
  store { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d97, i32 0, i32 1) }, ptr %l201, !tbaa !27
  br label %bb119
bb118:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d98, i32 0, i32 1) }, ptr %l201, !tbaa !27
  br label %bb119
bb119:
  %t340 = load i64, ptr %l5, !tbaa !24
  store i64 %t340, ptr %l202, !tbaa !24
  %t342 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s9, ptr %l10)
  store i64 %t342, ptr %l204
  br label %bb120
bb120:
  %t343 = load ptr, ptr %l198, !tbaa !29
  %t344 = load i32, ptr %l199, !range !{i32 0, i32 7}
  %t345 = load { i64, ptr }, ptr %l201, !tbaa !27
  %t346 = load i64, ptr %l202, !tbaa !24
  %t347 = load i64, ptr %l204, !tbaa !24
  %t348 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2enode(ptr %v0, ptr %v0, ptr %t343, i32 %t344, { i64, ptr } %t345, i64 %t346, i1 false, i64 %t347)
  store i64 %t348, ptr %l205
  br label %bb121
bb121:
  %t349 = load i64, ptr %l205, !tbaa !24
  store i64 %t349, ptr %l17, !tbaa !24
  %t350 = load i64, ptr %l17, !tbaa !24
  %t352 = load ptr, ptr %l0, !tbaa !29
  %t354 = getelementptr %"compiler/bindgen:gen", ptr %t352, i32 0, i32 17
  %t358 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3actype_3e_2eRefMut_3ccompiler_2fbindgen_3actype_3e(ptr %v0, ptr %v0, ptr %t354, i64 %t350)
  store ptr %t358, ptr %l210
  br label %bb122
bb122:
  %t359 = load ptr, ptr %l210, !tbaa !29
  %t361 = load i64, ptr %l13, !tbaa !24
  %t364 = getelementptr %"compiler/bindgen:ctype", ptr %t359, i32 0, i32 5
  store i64 %t361, ptr %t364, !tbaa !24
  %t365 = load i64, ptr %l17, !tbaa !24
  store i64 %t365, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s9)
  br label %bb141
bb123:
  %t367 = load { i64, ptr }, ptr %l215, !tbaa !27
  %t369 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s18, ptr %s18, { i64, ptr } %t367, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d99, i32 0, i32 1) })
  store i1 %t369, ptr %l217
  br label %bb124
bb124:
  %t370 = load i1, ptr %l217, !tbaa !21
  br i1 %t370, label %bb125, label %bb126
bb125:
  store %olang.scope zeroinitializer, ptr %s19
  %t371 = load ptr, ptr %l1, !tbaa !29
  store ptr %t371, ptr %l218, !tbaa !29
  %t372 = load ptr, ptr %l218, !tbaa !29
  %t373 = getelementptr %"compiler/bindgen:ctp", ptr %t372, i32 0, i32 1
  %t374 = load i64, ptr %t373, !tbaa !24
  %t377 = add i64 %t374, 1
  %t379 = load ptr, ptr %l218, !tbaa !29
  %t380 = getelementptr %"compiler/bindgen:ctp", ptr %t379, i32 0, i32 1
  store i64 %t377, ptr %t380, !tbaa !24
  store i64 0, ptr %l20, !tbaa !24
  %t381 = load ptr, ptr %l1, !tbaa !29
  %t383 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3actp_2eat(ptr %v1, ptr %s19, ptr %t381, i64 0)
  store { i64, ptr } %t383, ptr %l223
  br label %bb127
bb126:
  call void @__olang_scope_close(ptr %s18)
  call void @__olang_scope_close(ptr %s8)
  br label %bb143
bb127:
  %t384 = load { i64, ptr }, ptr %l223, !tbaa !27
  %t386 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s19, ptr %s19, { i64, ptr } %t384, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d100, i32 0, i32 1) })
  store i1 %t386, ptr %l225
  br label %bb128
bb128:
  %t387 = load i1, ptr %l225, !tbaa !21
  %t388 = xor i1 %t387, true
  br i1 %t388, label %bb129, label %bb130
bb129:
  store %olang.scope zeroinitializer, ptr %s20
  %t390 = load ptr, ptr %l1, !tbaa !29
  %t392 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3actp_2eat(ptr %v1, ptr %s20, ptr %t390, i64 0)
  store { i64, ptr } %t392, ptr %l229
  br label %bb131
bb130:
  br label %bb138
bb131:
  %t393 = load { i64, ptr }, ptr %l229, !tbaa !27
  store { i64, ptr } %t393, ptr %l230, !tbaa !27
  %t394 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s20, i64 10)
  %t395 = extractvalue { i32, i64 } %t394, 1
  %t396 = extractvalue { i32, i64 } %t394, 0
  store i32 %t396, ptr %l232
  %t397 = icmp ne i32 %t396, 0
  br i1 %t397, label %bb133, label %ok.398, !prof !99
ok.398:
  store i64 %t395, ptr %l231
  br label %bb132
bb132:
  %t399 = load { i64, ptr }, ptr %l230, !tbaa !27
  %t400 = load i64, ptr %l231, !tbaa !24
  %t401 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %s20, { i64, ptr } %t399, i64 %t400)
  %t402 = extractvalue { i32, i64 } %t401, 1
  %t403 = extractvalue { i32, i64 } %t401, 0
  store i32 %t403, ptr %l234
  %t404 = icmp ne i32 %t403, 0
  br i1 %t404, label %bb136, label %ok.405, !prof !99
ok.405:
  store i64 %t402, ptr %l233
  br label %bb135
bb133:
  br label %bb134
bb134:
  store i64 -1, ptr %l227, !tbaa !24
  br label %bb137
bb135:
  %t406 = load i64, ptr %l233, !tbaa !24
  store i64 %t406, ptr %l227, !tbaa !24
  br label %bb137
bb136:
  br label %bb134
bb137:
  %t407 = load i64, ptr %l227, !tbaa !24
  store i64 %t407, ptr %l20, !tbaa !24
  %t408 = load ptr, ptr %l1, !tbaa !29
  store ptr %t408, ptr %l235, !tbaa !29
  %t409 = load ptr, ptr %l235, !tbaa !29
  %t410 = getelementptr %"compiler/bindgen:ctp", ptr %t409, i32 0, i32 1
  %t411 = load i64, ptr %t410, !tbaa !24
  %t414 = add i64 %t411, 1
  %t416 = load ptr, ptr %l235, !tbaa !29
  %t417 = getelementptr %"compiler/bindgen:ctp", ptr %t416, i32 0, i32 1
  store i64 %t414, ptr %t417, !tbaa !24
  call void @__olang_scope_close(ptr %s20)
  br label %bb138
bb138:
  %t418 = load ptr, ptr %l1, !tbaa !29
  store ptr %t418, ptr %l239, !tbaa !29
  %t419 = load ptr, ptr %l239, !tbaa !29
  %t420 = getelementptr %"compiler/bindgen:ctp", ptr %t419, i32 0, i32 1
  %t421 = load i64, ptr %t420, !tbaa !24
  %t424 = add i64 %t421, 1
  %t426 = load ptr, ptr %l239, !tbaa !29
  %t427 = getelementptr %"compiler/bindgen:ctp", ptr %t426, i32 0, i32 1
  store i64 %t424, ptr %t427, !tbaa !24
  %t428 = load i64, ptr %l20, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l9, i64 %t428)
  br label %bb139
bb139:
  call void @__olang_scope_close(ptr %s19)
  br label %bb140
bb140:
  call void @__olang_scope_close(ptr %s18)
  br label %bb141
bb141:
  call void @__olang_scope_close(ptr %s8)
  br label %bb142
bb142:
  br label %bb65
bb143:
  store i64 0, ptr %l21, !tbaa !24
  %t432 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l9)
  store i64 %t432, ptr %l246
  br label %bb144
bb144:
  %t433 = load i64, ptr %l246, !tbaa !24
  store i64 %t433, ptr %l22, !tbaa !24
  store i64 1, ptr %l23, !tbaa !24
  %t434 = load i64, ptr %l22, !tbaa !24
  %t435 = load i64, ptr %l21, !tbaa !24
  %t438 = icmp sgt i64 %t434, %t435
  br i1 %t438, label %bb145, label %bb146
bb145:
  %t440 = load i64, ptr %l23, !tbaa !24
  %t442 = icmp sgt i64 %t440, 0
  br i1 %t442, label %bb147, label %bb148
bb146:
  store i64 0, ptr %l250, !tbaa !24
  br label %bb150
bb147:
  %t444 = load i64, ptr %l22, !tbaa !24
  %t445 = load i64, ptr %l21, !tbaa !24
  %t448 = sub i64 %t444, %t445
  %t449 = load i64, ptr %l23, !tbaa !24
  %t452 = add i64 %t448, %t449
  %t454 = sub i64 %t452, 1
  %t455 = load i64, ptr %l23, !tbaa !24
  %t458 = sdiv i64 %t454, %t455
  store i64 %t458, ptr %l253, !tbaa !24
  br label %bb149
bb148:
  store i64 0, ptr %l253, !tbaa !24
  br label %bb149
bb149:
  %t460 = load i64, ptr %l253, !tbaa !24
  store i64 %t460, ptr %l250, !tbaa !24
  br label %bb150
bb150:
  %t461 = load i64, ptr %l250, !tbaa !24
  store i64 %t461, ptr %l24, !tbaa !24
  store i64 0, ptr %l25, !tbaa !24
  br label %bb151
bb151:
  %t462 = load i64, ptr %l25, !tbaa !24
  %t463 = load i64, ptr %l24, !tbaa !24
  %t466 = icmp slt i64 %t462, %t463
  %t468 = xor i1 %t466, true
  br i1 %t468, label %bb152, label %bb153
bb152:
  br label %bb159
bb153:
  br label %bb154
bb154:
  %t470 = load i64, ptr %l21, !tbaa !24
  %t471 = load i64, ptr %l25, !tbaa !24
  %t472 = load i64, ptr %l23, !tbaa !24
  %t475 = mul i64 %t471, %t472
  %t478 = add i64 %t470, %t475
  store i64 %t478, ptr %l26, !tbaa !24
  %t480 = load ptr, ptr %l0, !tbaa !29
  store ptr %t480, ptr %l271, !tbaa !29
  store i32 4, ptr %l272
  %t481 = load i64, ptr %l5, !tbaa !24
  store i64 %t481, ptr %l273, !tbaa !24
  store ptr %l9, ptr %l274, !tbaa !29
  %t483 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l9)
  store i64 %t483, ptr %l276
  br label %bb155
bb155:
  %t484 = load i64, ptr %l276, !tbaa !24
  %t485 = sub i64 %t484, 1
  %t486 = load i64, ptr %l26, !tbaa !24
  %t489 = sub i64 %t485, %t486
  %t490 = load ptr, ptr %l274, !tbaa !29
  %t492 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t490, i64 %t489)
  store i64 %t492, ptr %l280
  br label %bb156
bb156:
  %t493 = load ptr, ptr %l271, !tbaa !29
  %t494 = load i32, ptr %l272, !range !{i32 0, i32 7}
  %t495 = load i64, ptr %l273, !tbaa !24
  %t496 = load i64, ptr %l280, !tbaa !24
  %t497 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2enode(ptr %v0, ptr %v0, ptr %t493, i32 %t494, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d101, i32 0, i32 1) }, i64 %t495, i1 false, i64 %t496)
  store i64 %t497, ptr %l281
  br label %bb157
bb157:
  %t498 = load i64, ptr %l281, !tbaa !24
  store i64 %t498, ptr %l5, !tbaa !24
  br label %bb158
bb158:
  %t499 = load i64, ptr %l25, !tbaa !24
  %t502 = add i64 %t499, 1
  store i64 %t502, ptr %l25, !tbaa !24
  br label %bb151
bb159:
  %t504 = load i64, ptr %l7, !tbaa !24
  %t506 = icmp sge i64 %t504, 0
  br i1 %t506, label %bb160, label %bb161
bb160:
  %t508 = load ptr, ptr %l1, !tbaa !29
  %t510 = getelementptr %"compiler/bindgen:ctp", ptr %t508, i32 0, i32 1
  %t511 = load i64, ptr %t510, !tbaa !24
  store i64 %t511, ptr %l27, !tbaa !24
  %t513 = load ptr, ptr %l1, !tbaa !29
  %t514 = load i64, ptr %l7, !tbaa !24
  %t517 = getelementptr %"compiler/bindgen:ctp", ptr %t513, i32 0, i32 1
  store i64 %t514, ptr %t517, !tbaa !24
  %t518 = load ptr, ptr %l0, !tbaa !29
  %t519 = load ptr, ptr %l1, !tbaa !29
  %t520 = load i64, ptr %l5, !tbaa !24
  %t521 = load i64, ptr %l4, !tbaa !24
  %t526 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2edeclarator(ptr %v0, ptr %v1, ptr %t518, ptr %t519, i64 %t520, i1 false, i64 %t521)
  store i64 %t526, ptr %l295
  br label %bb162
bb161:
  br label %bb163
bb162:
  %t527 = load i64, ptr %l295, !tbaa !24
  store i64 %t527, ptr %l5, !tbaa !24
  %t528 = load ptr, ptr %l1, !tbaa !29
  %t529 = load i64, ptr %l27, !tbaa !24
  %t532 = getelementptr %"compiler/bindgen:ctp", ptr %t528, i32 0, i32 1
  store i64 %t529, ptr %t532, !tbaa !24
  br label %bb163
bb163:
  %t533 = load i64, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t533, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i32 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eflat(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca %"compiler/bindgen:record"
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l15 = alloca %"compiler/bindgen:record"
  %l16 = alloca %"compiler/bindgen:record"
  %l17 = alloca i64
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca { i64, ptr }
  %l25 = alloca i64
  %l27 = alloca { i64, ptr }
  %l28 = alloca i64
  %l29 = alloca { i64, ptr }
  %l33 = alloca i64
  %l35 = alloca { i64, ptr }
  %l36 = alloca i64
  %l37 = alloca { i64, ptr }
  %l41 = alloca i64
  %l43 = alloca { i64, ptr }
  %l44 = alloca i64
  %l45 = alloca { i64, ptr }
  %l49 = alloca i64
  %l51 = alloca { i64, ptr }
  %l52 = alloca i64
  %l53 = alloca { i64, ptr }
  %l57 = alloca i64
  %l59 = alloca { i64, ptr }
  %l60 = alloca i64
  %l61 = alloca { i64, ptr }
  %l67 = alloca i1
  %l71 = alloca i64
  %l75 = alloca i64
  %l78 = alloca i64
  %l96 = alloca i64
  %l98 = alloca i64
  %l100 = alloca i64
  %l103 = alloca i64
  %l106 = alloca { i64, ptr }
  %l107 = alloca i1
  %l109 = alloca ptr
  %l112 = alloca { i64, ptr }
  %l113 = alloca ptr
  %l116 = alloca { i64, ptr }
  %l123 = alloca %"compiler/bindgen:record"
  %l130 = alloca i32
  %s3 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %rv = alloca i32
  %t5 = alloca %"compiler/bindgen:record", align 8
  %t400 = alloca %"compiler/bindgen:record", align 8
  store ptr %a0, ptr %l0
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/bindgen:gen", ptr %t1, i32 0, i32 6
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eAt_3ccompiler_2fbindgen_3arecord_3e(ptr %t5, ptr %v0, ptr %v0, ptr %t3, i64 %a1)
  call void @llvm.memmove.p0.p0.i64(ptr %l15, ptr %t5, i64 312, i1 false)
  br label %bb1
bb1:
  call void @llvm.memmove.p0.p0.i64(ptr %l16, ptr %l15, i64 312, i1 false)
  %t8 = call ptr @__olang_scope_hold(ptr %v0)
  %t9 = ptrtoint ptr %t8 to i64
  store i64 %t9, ptr %l17, !tbaa !24
  %t10 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e0
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = call ptr @__olang_region_make_part(ptr %v0)
  %t13 = ptrtoint ptr %t12 to i64
  store i64 %t13, ptr %l17, !tbaa !24
  br label %bb3
bb3:
  %t14 = getelementptr %"compiler/bindgen:record", ptr %l16, i32 0, i32 4
  %t15 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t14, i32 0, i32 0
  %t16 = load { i64, ptr }, ptr %t15, !tbaa !27
  store { i64, ptr } %t16, ptr %l19, !tbaa !27
  %t17 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t18 = extractvalue { i64, ptr } %t17, 0
  store i64 %t18, ptr %l20, !tbaa !24
  %t19 = load i64, ptr %l20, !tbaa !24
  %t20 = mul i64 %t19, 16
  %t21 = load i64, ptr %l17
  %t22 = inttoptr i64 %t21 to ptr
  %t23 = call ptr @__olang_held_alloc(ptr %t22, i64 %t20)
  %t24 = insertvalue { i64, ptr } undef, i64 %t19, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t23, 1
  store { i64, ptr } %t25, ptr %l21, !tbaa !27
  %t26 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !27
  %t30 = load i64, ptr %l20, !tbaa !24
  %t31 = mul i64 %t30, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t27, ptr %t29, i64 %t31, i1 false)
  %t32 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t33 = getelementptr %"compiler/bindgen:record", ptr %l16, i32 0, i32 4
  %t34 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t33, i32 0, i32 0
  store { i64, ptr } %t32, ptr %t34, !tbaa !27
  %t35 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e0
  br i1 %t35, label %bb4, label %bb5
bb4:
  %t37 = getelementptr %"compiler/bindgen:record", ptr %l16, i32 0, i32 4
  %t38 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t37, i32 0, i32 0
  %t39 = load { i64, ptr }, ptr %t38, !tbaa !27
  %t40 = extractvalue { i64, ptr } %t39, 0
  %t42 = icmp eq i64 %t40, 0
  br i1 %t42, label %bb6, label %bb7
bb5:
  %t44 = call ptr @__olang_scope_hold(ptr %v0)
  %t45 = ptrtoint ptr %t44 to i64
  store i64 %t45, ptr %l25, !tbaa !24
  %t46 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e0
  br i1 %t46, label %bb8, label %bb9
bb6:
  %t48 = getelementptr %"compiler/bindgen:record", ptr %l16, i32 0, i32 4
  %t49 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t48, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t49, !tbaa !27
  br label %bb7
bb7:
  %t50 = getelementptr %"compiler/bindgen:record", ptr %l16, i32 0, i32 4
  %t51 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t50, i32 0, i32 0
  %t52 = load i64, ptr %l17
  %t53 = inttoptr i64 %t52 to ptr
  %t54 = load { i64, ptr }, ptr %t51
  %t55 = extractvalue { i64, ptr } %t54, 1
  %t56 = call ptr @__olang_region_or(ptr %t55, ptr null)
  %t57 = icmp ne ptr %t56, null
  %t58 = select i1 %t57, ptr %t56, ptr null
  call void @__olang_region_settle_in(ptr %t53, ptr %t58)
  br label %bb5
bb8:
  %t59 = call ptr @__olang_region_make_part(ptr %v0)
  %t60 = ptrtoint ptr %t59 to i64
  store i64 %t60, ptr %l25, !tbaa !24
  br label %bb9
bb9:
  %t61 = getelementptr %"compiler/bindgen:record", ptr %l16, i32 0, i32 5
  %t62 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t61, i32 0, i32 0
  %t63 = load { i64, ptr }, ptr %t62, !tbaa !27
  store { i64, ptr } %t63, ptr %l27, !tbaa !27
  %t64 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t65 = extractvalue { i64, ptr } %t64, 0
  store i64 %t65, ptr %l28, !tbaa !24
  %t66 = load i64, ptr %l28, !tbaa !24
  %t67 = mul i64 %t66, 16
  %t68 = load i64, ptr %l25
  %t69 = inttoptr i64 %t68 to ptr
  %t70 = call ptr @__olang_held_alloc(ptr %t69, i64 %t67)
  %t71 = insertvalue { i64, ptr } undef, i64 %t66, 0
  %t72 = insertvalue { i64, ptr } %t71, ptr %t70, 1
  store { i64, ptr } %t72, ptr %l29, !tbaa !27
  %t73 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t74 = load ptr, ptr %t73, !tbaa !27
  %t75 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = load i64, ptr %l28, !tbaa !24
  %t78 = mul i64 %t77, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t74, ptr %t76, i64 %t78, i1 false)
  %t79 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t80 = getelementptr %"compiler/bindgen:record", ptr %l16, i32 0, i32 5
  %t81 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t80, i32 0, i32 0
  store { i64, ptr } %t79, ptr %t81, !tbaa !27
  %t82 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e0
  br i1 %t82, label %bb10, label %bb11
bb10:
  %t84 = getelementptr %"compiler/bindgen:record", ptr %l16, i32 0, i32 5
  %t85 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t84, i32 0, i32 0
  %t86 = load { i64, ptr }, ptr %t85, !tbaa !27
  %t87 = extractvalue { i64, ptr } %t86, 0
  %t89 = icmp eq i64 %t87, 0
  br i1 %t89, label %bb12, label %bb13
bb11:
  %t91 = call ptr @__olang_scope_hold(ptr %v0)
  %t92 = ptrtoint ptr %t91 to i64
  store i64 %t92, ptr %l33, !tbaa !24
  %t93 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t93, label %bb14, label %bb15
bb12:
  %t95 = getelementptr %"compiler/bindgen:record", ptr %l16, i32 0, i32 5
  %t96 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t95, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t96, !tbaa !27
  br label %bb13
bb13:
  %t97 = getelementptr %"compiler/bindgen:record", ptr %l16, i32 0, i32 5
  %t98 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t97, i32 0, i32 0
  %t99 = load i64, ptr %l25
  %t100 = inttoptr i64 %t99 to ptr
  %t101 = load { i64, ptr }, ptr %t98
  %t102 = extractvalue { i64, ptr } %t101, 1
  %t103 = call ptr @__olang_region_or(ptr %t102, ptr null)
  %t104 = icmp ne ptr %t103, null
  %t105 = select i1 %t104, ptr %t103, ptr null
  call void @__olang_region_settle_in(ptr %t100, ptr %t105)
  br label %bb11
bb14:
  %t106 = call ptr @__olang_region_make_part(ptr %v0)
  %t107 = ptrtoint ptr %t106 to i64
  store i64 %t107, ptr %l33, !tbaa !24
  br label %bb15
bb15:
  %t108 = getelementptr %"compiler/bindgen:record", ptr %l16, i32 0, i32 16
  %t109 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t108, i32 0, i32 0
  %t110 = load { i64, ptr }, ptr %t109, !tbaa !27
  store { i64, ptr } %t110, ptr %l35, !tbaa !27
  %t111 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t112 = extractvalue { i64, ptr } %t111, 0
  store i64 %t112, ptr %l36, !tbaa !24
  %t113 = load i64, ptr %l36, !tbaa !24
  %t114 = mul i64 %t113, 8
  %t115 = load i64, ptr %l33
  %t116 = inttoptr i64 %t115 to ptr
  %t117 = call ptr @__olang_held_alloc(ptr %t116, i64 %t114)
  %t118 = insertvalue { i64, ptr } undef, i64 %t113, 0
  %t119 = insertvalue { i64, ptr } %t118, ptr %t117, 1
  store { i64, ptr } %t119, ptr %l37, !tbaa !27
  %t120 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t121 = load ptr, ptr %t120, !tbaa !27
  %t122 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t123 = load ptr, ptr %t122, !tbaa !27
  %t124 = load i64, ptr %l36, !tbaa !24
  %t125 = mul i64 %t124, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t121, ptr %t123, i64 %t125, i1 false)
  %t126 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t127 = getelementptr %"compiler/bindgen:record", ptr %l16, i32 0, i32 16
  %t128 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t127, i32 0, i32 0
  store { i64, ptr } %t126, ptr %t128, !tbaa !27
  %t129 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t129, label %bb16, label %bb17
bb16:
  %t131 = getelementptr %"compiler/bindgen:record", ptr %l16, i32 0, i32 16
  %t132 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t131, i32 0, i32 0
  %t133 = load { i64, ptr }, ptr %t132, !tbaa !27
  %t134 = extractvalue { i64, ptr } %t133, 0
  %t136 = icmp eq i64 %t134, 0
  br i1 %t136, label %bb18, label %bb19
bb17:
  %t138 = call ptr @__olang_scope_hold(ptr %v0)
  %t139 = ptrtoint ptr %t138 to i64
  store i64 %t139, ptr %l41, !tbaa !24
  %t140 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t140, label %bb20, label %bb21
bb18:
  %t142 = getelementptr %"compiler/bindgen:record", ptr %l16, i32 0, i32 16
  %t143 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t142, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t143, !tbaa !27
  br label %bb19
bb19:
  %t144 = getelementptr %"compiler/bindgen:record", ptr %l16, i32 0, i32 16
  %t145 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t144, i32 0, i32 0
  %t146 = load i64, ptr %l33
  %t147 = inttoptr i64 %t146 to ptr
  %t148 = load { i64, ptr }, ptr %t145
  %t149 = extractvalue { i64, ptr } %t148, 1
  %t150 = call ptr @__olang_region_or(ptr %t149, ptr null)
  %t151 = icmp ne ptr %t150, null
  %t152 = select i1 %t151, ptr %t150, ptr null
  call void @__olang_region_settle_in(ptr %t147, ptr %t152)
  br label %bb17
bb20:
  %t153 = call ptr @__olang_region_make_part(ptr %v0)
  %t154 = ptrtoint ptr %t153 to i64
  store i64 %t154, ptr %l41, !tbaa !24
  br label %bb21
bb21:
  %t155 = getelementptr %"compiler/bindgen:record", ptr %l16, i32 0, i32 17
  %t156 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t155, i32 0, i32 0
  %t157 = load { i64, ptr }, ptr %t156, !tbaa !27
  store { i64, ptr } %t157, ptr %l43, !tbaa !27
  %t158 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t159 = extractvalue { i64, ptr } %t158, 0
  store i64 %t159, ptr %l44, !tbaa !24
  %t160 = load i64, ptr %l44, !tbaa !24
  %t161 = mul i64 %t160, 8
  %t162 = load i64, ptr %l41
  %t163 = inttoptr i64 %t162 to ptr
  %t164 = call ptr @__olang_held_alloc(ptr %t163, i64 %t161)
  %t165 = insertvalue { i64, ptr } undef, i64 %t160, 0
  %t166 = insertvalue { i64, ptr } %t165, ptr %t164, 1
  store { i64, ptr } %t166, ptr %l45, !tbaa !27
  %t167 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t168 = load ptr, ptr %t167, !tbaa !27
  %t169 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t170 = load ptr, ptr %t169, !tbaa !27
  %t171 = load i64, ptr %l44, !tbaa !24
  %t172 = mul i64 %t171, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t168, ptr %t170, i64 %t172, i1 false)
  %t173 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t174 = getelementptr %"compiler/bindgen:record", ptr %l16, i32 0, i32 17
  %t175 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t174, i32 0, i32 0
  store { i64, ptr } %t173, ptr %t175, !tbaa !27
  %t176 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t176, label %bb22, label %bb23
bb22:
  %t178 = getelementptr %"compiler/bindgen:record", ptr %l16, i32 0, i32 17
  %t179 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t178, i32 0, i32 0
  %t180 = load { i64, ptr }, ptr %t179, !tbaa !27
  %t181 = extractvalue { i64, ptr } %t180, 0
  %t183 = icmp eq i64 %t181, 0
  br i1 %t183, label %bb24, label %bb25
bb23:
  %t185 = call ptr @__olang_scope_hold(ptr %v0)
  %t186 = ptrtoint ptr %t185 to i64
  store i64 %t186, ptr %l49, !tbaa !24
  %t187 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t187, label %bb26, label %bb27
bb24:
  %t189 = getelementptr %"compiler/bindgen:record", ptr %l16, i32 0, i32 17
  %t190 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t189, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t190, !tbaa !27
  br label %bb25
bb25:
  %t191 = getelementptr %"compiler/bindgen:record", ptr %l16, i32 0, i32 17
  %t192 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t191, i32 0, i32 0
  %t193 = load i64, ptr %l41
  %t194 = inttoptr i64 %t193 to ptr
  %t195 = load { i64, ptr }, ptr %t192
  %t196 = extractvalue { i64, ptr } %t195, 1
  %t197 = call ptr @__olang_region_or(ptr %t196, ptr null)
  %t198 = icmp ne ptr %t197, null
  %t199 = select i1 %t198, ptr %t197, ptr null
  call void @__olang_region_settle_in(ptr %t194, ptr %t199)
  br label %bb23
bb26:
  %t200 = call ptr @__olang_region_make_part(ptr %v0)
  %t201 = ptrtoint ptr %t200 to i64
  store i64 %t201, ptr %l49, !tbaa !24
  br label %bb27
bb27:
  %t202 = getelementptr %"compiler/bindgen:record", ptr %l16, i32 0, i32 18
  %t203 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t202, i32 0, i32 0
  %t204 = load { i64, ptr }, ptr %t203, !tbaa !27
  store { i64, ptr } %t204, ptr %l51, !tbaa !27
  %t205 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t206 = extractvalue { i64, ptr } %t205, 0
  store i64 %t206, ptr %l52, !tbaa !24
  %t207 = load i64, ptr %l52, !tbaa !24
  %t208 = mul i64 %t207, 8
  %t209 = load i64, ptr %l49
  %t210 = inttoptr i64 %t209 to ptr
  %t211 = call ptr @__olang_held_alloc(ptr %t210, i64 %t208)
  %t212 = insertvalue { i64, ptr } undef, i64 %t207, 0
  %t213 = insertvalue { i64, ptr } %t212, ptr %t211, 1
  store { i64, ptr } %t213, ptr %l53, !tbaa !27
  %t214 = getelementptr { i64, ptr }, ptr %l53, i32 0, i32 1
  %t215 = load ptr, ptr %t214, !tbaa !27
  %t216 = getelementptr { i64, ptr }, ptr %l51, i32 0, i32 1
  %t217 = load ptr, ptr %t216, !tbaa !27
  %t218 = load i64, ptr %l52, !tbaa !24
  %t219 = mul i64 %t218, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t215, ptr %t217, i64 %t219, i1 false)
  %t220 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t221 = getelementptr %"compiler/bindgen:record", ptr %l16, i32 0, i32 18
  %t222 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t221, i32 0, i32 0
  store { i64, ptr } %t220, ptr %t222, !tbaa !27
  %t223 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t223, label %bb28, label %bb29
bb28:
  %t225 = getelementptr %"compiler/bindgen:record", ptr %l16, i32 0, i32 18
  %t226 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t225, i32 0, i32 0
  %t227 = load { i64, ptr }, ptr %t226, !tbaa !27
  %t228 = extractvalue { i64, ptr } %t227, 0
  %t230 = icmp eq i64 %t228, 0
  br i1 %t230, label %bb30, label %bb31
bb29:
  %t232 = call ptr @__olang_scope_hold(ptr %v0)
  %t233 = ptrtoint ptr %t232 to i64
  store i64 %t233, ptr %l57, !tbaa !24
  %t234 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t234, label %bb32, label %bb33
bb30:
  %t236 = getelementptr %"compiler/bindgen:record", ptr %l16, i32 0, i32 18
  %t237 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t236, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t237, !tbaa !27
  br label %bb31
bb31:
  %t238 = getelementptr %"compiler/bindgen:record", ptr %l16, i32 0, i32 18
  %t239 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t238, i32 0, i32 0
  %t240 = load i64, ptr %l49
  %t241 = inttoptr i64 %t240 to ptr
  %t242 = load { i64, ptr }, ptr %t239
  %t243 = extractvalue { i64, ptr } %t242, 1
  %t244 = call ptr @__olang_region_or(ptr %t243, ptr null)
  %t245 = icmp ne ptr %t244, null
  %t246 = select i1 %t245, ptr %t244, ptr null
  call void @__olang_region_settle_in(ptr %t241, ptr %t246)
  br label %bb29
bb32:
  %t247 = call ptr @__olang_region_make_part(ptr %v0)
  %t248 = ptrtoint ptr %t247 to i64
  store i64 %t248, ptr %l57, !tbaa !24
  br label %bb33
bb33:
  %t249 = getelementptr %"compiler/bindgen:record", ptr %l16, i32 0, i32 19
  %t250 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t249, i32 0, i32 0
  %t251 = load { i64, ptr }, ptr %t250, !tbaa !27
  store { i64, ptr } %t251, ptr %l59, !tbaa !27
  %t252 = load { i64, ptr }, ptr %l59, !tbaa !27
  %t253 = extractvalue { i64, ptr } %t252, 0
  store i64 %t253, ptr %l60, !tbaa !24
  %t254 = load i64, ptr %l60, !tbaa !24
  %t255 = mul i64 %t254, 8
  %t256 = load i64, ptr %l57
  %t257 = inttoptr i64 %t256 to ptr
  %t258 = call ptr @__olang_held_alloc(ptr %t257, i64 %t255)
  %t259 = insertvalue { i64, ptr } undef, i64 %t254, 0
  %t260 = insertvalue { i64, ptr } %t259, ptr %t258, 1
  store { i64, ptr } %t260, ptr %l61, !tbaa !27
  %t261 = getelementptr { i64, ptr }, ptr %l61, i32 0, i32 1
  %t262 = load ptr, ptr %t261, !tbaa !27
  %t263 = getelementptr { i64, ptr }, ptr %l59, i32 0, i32 1
  %t264 = load ptr, ptr %t263, !tbaa !27
  %t265 = load i64, ptr %l60, !tbaa !24
  %t266 = mul i64 %t265, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t262, ptr %t264, i64 %t266, i1 false)
  %t267 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t268 = getelementptr %"compiler/bindgen:record", ptr %l16, i32 0, i32 19
  %t269 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t268, i32 0, i32 0
  store { i64, ptr } %t267, ptr %t269, !tbaa !27
  %t270 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t270, label %bb34, label %bb35
bb34:
  %t272 = getelementptr %"compiler/bindgen:record", ptr %l16, i32 0, i32 19
  %t273 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t272, i32 0, i32 0
  %t274 = load { i64, ptr }, ptr %t273, !tbaa !27
  %t275 = extractvalue { i64, ptr } %t274, 0
  %t277 = icmp eq i64 %t275, 0
  br i1 %t277, label %bb36, label %bb37
bb35:
  call void @llvm.memmove.p0.p0.i64(ptr %l4, ptr %l16, i64 312, i1 false)
  %t279 = getelementptr %"compiler/bindgen:record", ptr %l4, i32 0, i32 2
  %t280 = load i1, ptr %t279, !tbaa !21
  %t282 = xor i1 %t280, true
  br i1 %t282, label %bb38, label %bb39
bb36:
  %t284 = getelementptr %"compiler/bindgen:record", ptr %l16, i32 0, i32 19
  %t285 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t284, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t285, !tbaa !27
  br label %bb37
bb37:
  %t286 = getelementptr %"compiler/bindgen:record", ptr %l16, i32 0, i32 19
  %t287 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t286, i32 0, i32 0
  %t288 = load i64, ptr %l57
  %t289 = inttoptr i64 %t288 to ptr
  %t290 = load { i64, ptr }, ptr %t287
  %t291 = extractvalue { i64, ptr } %t290, 1
  %t292 = call ptr @__olang_region_or(ptr %t291, ptr null)
  %t293 = icmp ne ptr %t292, null
  %t294 = select i1 %t293, ptr %t292, ptr null
  call void @__olang_region_settle_in(ptr %t289, ptr %t294)
  br label %bb35
bb38:
  store i1 true, ptr %l67, !tbaa !21
  br label %bb40
bb39:
  %t295 = getelementptr %"compiler/bindgen:record", ptr %l4, i32 0, i32 3
  %t296 = load i1, ptr %t295, !tbaa !21
  store i1 %t296, ptr %l67, !tbaa !21
  br label %bb40
bb40:
  %t298 = load i1, ptr %l67, !tbaa !21
  br i1 %t298, label %bb41, label %bb42
bb41:
  store i32 65536, ptr %rv
  br label %ret
bb42:
  br label %bb43
bb43:
  store i64 0, ptr %l5, !tbaa !24
  %t300 = getelementptr %"compiler/bindgen:record", ptr %l4, i32 0, i32 4
  %t302 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %t300)
  store i64 %t302, ptr %l71
  br label %bb44
bb44:
  %t303 = load i64, ptr %l71, !tbaa !24
  store i64 %t303, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t304 = load i64, ptr %l6, !tbaa !24
  %t305 = load i64, ptr %l5, !tbaa !24
  %t308 = icmp sgt i64 %t304, %t305
  br i1 %t308, label %bb45, label %bb46
bb45:
  %t310 = load i64, ptr %l7, !tbaa !24
  %t312 = icmp sgt i64 %t310, 0
  br i1 %t312, label %bb47, label %bb48
bb46:
  store i64 0, ptr %l75, !tbaa !24
  br label %bb50
bb47:
  %t314 = load i64, ptr %l6, !tbaa !24
  %t315 = load i64, ptr %l5, !tbaa !24
  %t318 = sub i64 %t314, %t315
  %t319 = load i64, ptr %l7, !tbaa !24
  %t322 = add i64 %t318, %t319
  %t324 = sub i64 %t322, 1
  %t325 = load i64, ptr %l7, !tbaa !24
  %t328 = sdiv i64 %t324, %t325
  store i64 %t328, ptr %l78, !tbaa !24
  br label %bb49
bb48:
  store i64 0, ptr %l78, !tbaa !24
  br label %bb49
bb49:
  %t330 = load i64, ptr %l78, !tbaa !24
  store i64 %t330, ptr %l75, !tbaa !24
  br label %bb50
bb50:
  %t331 = load i64, ptr %l75, !tbaa !24
  store i64 %t331, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb51
bb51:
  store %olang.scope zeroinitializer, ptr %s3
  %t332 = load i64, ptr %l9, !tbaa !24
  %t333 = load i64, ptr %l8, !tbaa !24
  %t336 = icmp slt i64 %t332, %t333
  %t338 = xor i1 %t336, true
  br i1 %t338, label %bb52, label %bb53
bb52:
  call void @__olang_scope_close(ptr %s3)
  br label %bb80
bb53:
  br label %bb54
bb54:
  %t340 = load i64, ptr %l5, !tbaa !24
  %t341 = load i64, ptr %l9, !tbaa !24
  %t342 = load i64, ptr %l7, !tbaa !24
  %t345 = mul i64 %t341, %t342
  %t348 = add i64 %t340, %t345
  store i64 %t348, ptr %l10, !tbaa !24
  %t350 = load i64, ptr %l10, !tbaa !24
  store i64 %t350, ptr %l96, !tbaa !24
  %t351 = getelementptr %"compiler/bindgen:record", ptr %l4, i32 0, i32 17
  %t353 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t351)
  store i64 %t353, ptr %l98
  br label %bb55
bb55:
  %t354 = load i64, ptr %l96, !tbaa !24
  %t355 = load i64, ptr %l98, !tbaa !24
  %t356 = icmp slt i64 %t354, %t355
  br i1 %t356, label %bb56, label %bb57
bb56:
  %t358 = getelementptr %"compiler/bindgen:record", ptr %l4, i32 0, i32 17
  %t359 = load i64, ptr %l10, !tbaa !24
  %t362 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t358, i64 %t359)
  store i64 %t362, ptr %l103
  br label %bb58
bb57:
  store i64 -1, ptr %l100, !tbaa !24
  br label %bb59
bb58:
  %t363 = load i64, ptr %l103, !tbaa !24
  store i64 %t363, ptr %l100, !tbaa !24
  br label %bb59
bb59:
  %t364 = load i64, ptr %l100, !tbaa !24
  store i64 %t364, ptr %l11, !tbaa !24
  %t365 = getelementptr %"compiler/bindgen:record", ptr %l4, i32 0, i32 4
  %t366 = load i64, ptr %l10, !tbaa !24
  %t369 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %t365, i64 %t366)
  store { i64, ptr } %t369, ptr %l106
  br label %bb60
bb60:
  %t370 = load { i64, ptr }, ptr %l106, !tbaa !27
  %t371 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s3, { i64, ptr } %t370, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d102, i32 0, i32 1) })
  store i1 %t371, ptr %l107
  br label %bb61
bb61:
  %t372 = load i1, ptr %l107, !tbaa !21
  %t373 = xor i1 %t372, true
  br i1 %t373, label %bb62, label %bb63
bb62:
  %t375 = load ptr, ptr %l2, !tbaa !29
  store ptr %t375, ptr %l109, !tbaa !29
  %t376 = getelementptr %"compiler/bindgen:record", ptr %l4, i32 0, i32 4
  %t377 = load i64, ptr %l10, !tbaa !24
  %t380 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %t376, i64 %t377)
  store { i64, ptr } %t380, ptr %l112
  br label %bb64
bb63:
  %t381 = load i64, ptr %l11, !tbaa !24
  %t383 = icmp slt i64 %t381, 0
  br i1 %t383, label %bb68, label %bb69
bb64:
  %t385 = load ptr, ptr %l109, !tbaa !29
  %t386 = load { i64, ptr }, ptr %l112, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v0, ptr %t385, { i64, ptr } %t386)
  br label %bb65
bb65:
  %t387 = load ptr, ptr %l3, !tbaa !29
  store ptr %t387, ptr %l113, !tbaa !29
  %t388 = getelementptr %"compiler/bindgen:record", ptr %l4, i32 0, i32 5
  %t389 = load i64, ptr %l10, !tbaa !24
  %t392 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %t388, i64 %t389)
  store { i64, ptr } %t392, ptr %l116
  br label %bb66
bb66:
  %t393 = load ptr, ptr %l113, !tbaa !29
  %t394 = load { i64, ptr }, ptr %l116, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v2, ptr %v0, ptr %t393, { i64, ptr } %t394)
  br label %bb67
bb67:
  br label %bb78
bb68:
  call void @__olang_scope_close(ptr %s3)
  store i32 65536, ptr %rv
  br label %ret
bb69:
  store %olang.scope zeroinitializer, ptr %s7
  %t396 = load ptr, ptr %l0, !tbaa !29
  %t398 = getelementptr %"compiler/bindgen:gen", ptr %t396, i32 0, i32 6
  %t399 = load i64, ptr %l11, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eAt_3ccompiler_2fbindgen_3arecord_3e(ptr %t400, ptr %v0, ptr %s7, ptr %t398, i64 %t399)
  call void @llvm.memmove.p0.p0.i64(ptr %l123, ptr %t400, i64 312, i1 false)
  br label %bb70
bb70:
  %t403 = getelementptr %"compiler/bindgen:record", ptr %l123, i32 0, i32 1
  %t404 = load i1, ptr %t403, !tbaa !21
  %t406 = xor i1 %t404, true
  br i1 %t406, label %bb71, label %bb72
bb71:
  %t408 = load ptr, ptr %l0, !tbaa !29
  %t409 = load i64, ptr %l11, !tbaa !24
  %t410 = load ptr, ptr %l2, !tbaa !29
  %t411 = load ptr, ptr %l3, !tbaa !29
  %t416 = call i32 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eflat(ptr %v0, ptr %v1, ptr %v2, ptr %t408, i64 %t409, ptr %t410, ptr %t411)
  store i32 %t416, ptr %l130
  %t417 = icmp ne i32 %t416, 0
  br i1 %t417, label %bb74, label %ok.418, !prof !99
ok.418:
  br label %bb73
bb72:
  br label %bb76
bb73:
  br label %bb75
bb74:
  %t419 = load i32, ptr %l130, !tbaa !23
  %t420 = lshr i32 %t419, 16
  %t421 = and i32 %t419, 65535
  %t422 = icmp eq i32 %t420, 1
  %t423 = select i1 %t422, i32 1, i32 0
  %t424 = icmp eq i32 %t419, 0
  %t425 = shl i32 %t423, 16
  %t426 = or i32 %t425, %t421
  %t427 = select i1 %t424, i32 0, i32 %t426
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s3)
  store i32 %t427, ptr %rv
  br label %ret
bb75:
  br label %bb76
bb76:
  call void @__olang_scope_close(ptr %s7)
  br label %bb77
bb77:
  br label %bb78
bb78:
  call void @__olang_scope_close(ptr %s3)
  br label %bb79
bb79:
  %t429 = load i64, ptr %l9, !tbaa !24
  %t432 = add i64 %t429, 1
  store i64 %t432, ptr %l9, !tbaa !24
  br label %bb51
bb80:
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2efnSpelled(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/bindgen:ctype" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/bindgen:ctype"
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca %"std/prelude/text:StringBuilder"
  %l15 = alloca i64
  %l18 = alloca i64
  %l39 = alloca ptr
  %l40 = alloca i64
  %l41 = alloca { i64, ptr }
  %l42 = alloca ptr
  %l48 = alloca i64
  %l49 = alloca { i64, ptr }
  %l50 = alloca i32
  %l61 = alloca %"compiler/bindgen:ctype"
  %l65 = alloca ptr
  %l66 = alloca { i64, ptr }
  %l69 = alloca { i64, ptr }
  %l70 = alloca i32
  %l75 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  store ptr %a0, ptr %l0
  store %"compiler/bindgen:ctype" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l9
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l9
  store %"std/prelude/text:StringBuilder" %t2, ptr %l2
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l2, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d103, i32 0, i32 1) })
  br label %bb2
bb2:
  store i64 0, ptr %l3, !tbaa !24
  %t4 = getelementptr %"compiler/bindgen:ctype", ptr %l1, i32 0, i32 4
  %t5 = load i64, ptr %t4, !tbaa !24
  store i64 %t5, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t7 = load i64, ptr %l4, !tbaa !24
  %t8 = load i64, ptr %l3, !tbaa !24
  %t11 = icmp sgt i64 %t7, %t8
  br i1 %t11, label %bb3, label %bb4
bb3:
  %t13 = load i64, ptr %l5, !tbaa !24
  %t15 = icmp sgt i64 %t13, 0
  br i1 %t15, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l15, !tbaa !24
  br label %bb8
bb5:
  %t17 = load i64, ptr %l4, !tbaa !24
  %t18 = load i64, ptr %l3, !tbaa !24
  %t21 = sub i64 %t17, %t18
  %t22 = load i64, ptr %l5, !tbaa !24
  %t25 = add i64 %t21, %t22
  %t27 = sub i64 %t25, 1
  %t28 = load i64, ptr %l5, !tbaa !24
  %t31 = sdiv i64 %t27, %t28
  store i64 %t31, ptr %l18, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l18, !tbaa !24
  br label %bb7
bb7:
  %t33 = load i64, ptr %l18, !tbaa !24
  store i64 %t33, ptr %l15, !tbaa !24
  br label %bb8
bb8:
  %t34 = load i64, ptr %l15, !tbaa !24
  store i64 %t34, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t35 = load i64, ptr %l7, !tbaa !24
  %t36 = load i64, ptr %l6, !tbaa !24
  %t39 = icmp slt i64 %t35, %t36
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb23
bb11:
  br label %bb12
bb12:
  %t43 = load i64, ptr %l3, !tbaa !24
  %t44 = load i64, ptr %l7, !tbaa !24
  %t45 = load i64, ptr %l5, !tbaa !24
  %t48 = mul i64 %t44, %t45
  %t51 = add i64 %t43, %t48
  store i64 %t51, ptr %l8, !tbaa !24
  %t53 = load i64, ptr %l8, !tbaa !24
  %t55 = icmp sgt i64 %t53, 0
  br i1 %t55, label %bb13, label %bb14
bb13:
  store %olang.scope zeroinitializer, ptr %s3
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s3, ptr %l2, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d104, i32 0, i32 1) })
  br label %bb15
bb14:
  br label %bb16
bb15:
  call void @__olang_scope_close(ptr %s3)
  br label %bb16
bb16:
  store ptr %l2, ptr %l39, !tbaa !29
  %t58 = load i64, ptr %l8, !tbaa !24
  store i64 %t58, ptr %l40, !tbaa !24
  %t59 = load ptr, ptr %l0, !tbaa !29
  store ptr %t59, ptr %l42, !tbaa !29
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/bindgen:gen", ptr %t60, i32 0, i32 18
  %t63 = getelementptr %"compiler/bindgen:ctype", ptr %l1, i32 0, i32 5
  %t64 = load i64, ptr %t63, !tbaa !24
  %t65 = load i64, ptr %l8, !tbaa !24
  %t68 = add i64 %t64, %t65
  %t71 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t62, i64 %t68)
  store i64 %t71, ptr %l48
  br label %bb17
bb17:
  %t72 = load ptr, ptr %l42, !tbaa !29
  %t73 = load i64, ptr %l48, !tbaa !24
  %t74 = call { i32, { i64, ptr } } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2evalueType(ptr %v0, ptr %s2, ptr %t72, i64 %t73, i1 true)
  %t75 = extractvalue { i32, { i64, ptr } } %t74, 1
  %t76 = extractvalue { i32, { i64, ptr } } %t74, 0
  store i32 %t76, ptr %l50
  %t77 = icmp ne i32 %t76, 0
  br i1 %t77, label %bb19, label %ok.78, !prof !99
ok.78:
  store { i64, ptr } %t75, ptr %l49
  br label %bb18
bb18:
  %t79 = load { i64, ptr }, ptr %l49, !tbaa !27
  store { i64, ptr } %t79, ptr %l41, !tbaa !27
  br label %bb20
bb19:
  %t80 = load i32, ptr %l50, !tbaa !23
  %t81 = lshr i32 %t80, 16
  %t82 = and i32 %t80, 65535
  %t83 = icmp eq i32 %t81, 1
  %t84 = select i1 %t83, i32 1, i32 0
  %t85 = icmp eq i32 %t80, 0
  %t86 = shl i32 %t84, 16
  %t87 = or i32 %t86, %t82
  %t88 = select i1 %t85, i32 0, i32 %t87
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t90 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t88, 0
  store { i32, { i64, ptr } } %t90, ptr %rv
  br label %ret
bb20:
  %t91 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d105, i32 0, i32 1) }, 1
  %t92 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d105, i32 0, i32 1) }, 0
  %t93 = load i64, ptr %l40, !tbaa !24
  %t94 = call i64 @__olang_fmt_i64(ptr null, i64 %t93)
  %t95 = add i64 %t92, %t94
  %t96 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d106, i32 0, i32 1) }, 1
  %t97 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d106, i32 0, i32 1) }, 0
  %t98 = add i64 %t95, %t97
  %t99 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t100 = extractvalue { i64, ptr } %t99, 1
  %t101 = extractvalue { i64, ptr } %t99, 0
  %t102 = add i64 %t98, %t101
  %t103 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t102)
  call void @olang_textcopy(ptr %t103, ptr %t91, i64 %t92)
  %t104 = getelementptr i8, ptr %t103, i64 %t92
  %t105 = call i64 @__olang_fmt_i64(ptr %t104, i64 %t93)
  %t106 = getelementptr i8, ptr %t104, i64 %t94
  call void @olang_textcopy(ptr %t106, ptr %t96, i64 %t97)
  %t107 = getelementptr i8, ptr %t106, i64 %t97
  call void @olang_textcopy(ptr %t107, ptr %t100, i64 %t101)
  %t108 = insertvalue { i64, ptr } undef, i64 %t102, 0
  %t109 = insertvalue { i64, ptr } %t108, ptr %t103, 1
  %t111 = load ptr, ptr %l39, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s2, ptr %t111, { i64, ptr } %t109)
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s2)
  br label %bb22
bb22:
  %t113 = load i64, ptr %l7, !tbaa !24
  %t116 = add i64 %t113, 1
  store i64 %t116, ptr %l7, !tbaa !24
  br label %bb9
bb23:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l2, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d107, i32 0, i32 1) })
  br label %bb24
bb24:
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t121 = getelementptr %"compiler/bindgen:gen", ptr %t119, i32 0, i32 17
  %t122 = getelementptr %"compiler/bindgen:ctype", ptr %l1, i32 0, i32 2
  %t123 = load i64, ptr %t122, !tbaa !24
  %t126 = call %"compiler/bindgen:ctype" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3actype_3e_2eAt_3ccompiler_2fbindgen_3actype_3e(ptr %v0, ptr %s0, ptr %t121, i64 %t123)
  store %"compiler/bindgen:ctype" %t126, ptr %l61
  br label %bb25
bb25:
  %t127 = getelementptr %"compiler/bindgen:ctype", ptr %l61, i32 0, i32 0
  %t128 = load i32, ptr %t127, !range !{i32 0, i32 7}
  %t130 = trunc i64 0 to i32
  %t131 = icmp eq i32 %t128, %t130
  %t133 = xor i1 %t131, true
  br i1 %t133, label %bb26, label %bb27
bb26:
  store %olang.scope zeroinitializer, ptr %s6
  store ptr %l2, ptr %l65, !tbaa !29
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t136 = getelementptr %"compiler/bindgen:ctype", ptr %l1, i32 0, i32 2
  %t137 = load i64, ptr %t136, !tbaa !24
  %t140 = call { i32, { i64, ptr } } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2evalueType(ptr %v0, ptr %s6, ptr %t135, i64 %t137, i1 true)
  %t141 = extractvalue { i32, { i64, ptr } } %t140, 1
  %t142 = extractvalue { i32, { i64, ptr } } %t140, 0
  store i32 %t142, ptr %l70
  %t143 = icmp ne i32 %t142, 0
  br i1 %t143, label %bb29, label %ok.144, !prof !99
ok.144:
  store { i64, ptr } %t141, ptr %l69
  br label %bb28
bb27:
  br label %bb32
bb28:
  %t145 = load { i64, ptr }, ptr %l69, !tbaa !27
  store { i64, ptr } %t145, ptr %l66, !tbaa !27
  br label %bb30
bb29:
  %t146 = load i32, ptr %l70, !tbaa !23
  %t147 = lshr i32 %t146, 16
  %t148 = and i32 %t146, 65535
  %t149 = icmp eq i32 %t147, 1
  %t150 = select i1 %t149, i32 1, i32 0
  %t151 = icmp eq i32 %t146, 0
  %t152 = shl i32 %t150, 16
  %t153 = or i32 %t152, %t148
  %t154 = select i1 %t151, i32 0, i32 %t153
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  %t156 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t154, 0
  store { i32, { i64, ptr } } %t156, ptr %rv
  br label %ret
bb30:
  %t157 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d108, i32 0, i32 1) }, 1
  %t158 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d108, i32 0, i32 1) }, 0
  %t159 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t160 = extractvalue { i64, ptr } %t159, 1
  %t161 = extractvalue { i64, ptr } %t159, 0
  %t162 = add i64 %t158, %t161
  %t163 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t162)
  call void @olang_textcopy(ptr %t163, ptr %t157, i64 %t158)
  %t164 = getelementptr i8, ptr %t163, i64 %t158
  call void @olang_textcopy(ptr %t164, ptr %t160, i64 %t161)
  %t165 = insertvalue { i64, ptr } undef, i64 %t162, 0
  %t166 = insertvalue { i64, ptr } %t165, ptr %t163, 1
  %t168 = load ptr, ptr %l65, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s6, ptr %t168, { i64, ptr } %t166)
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s6)
  br label %bb32
bb32:
  %t171 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v2, ptr %l2)
  store { i64, ptr } %t171, ptr %l75
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s0)
  %t172 = load { i64, ptr }, ptr %l75, !tbaa !27
  %t173 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t172, 1
  store { i32, { i64, ptr } } %t173, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2egapAround(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l16 = alloca %"compiler/bindgen:record"
  %l18 = alloca %"compiler/bindgen:record"
  %l20 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l21 = alloca i64
  %l23 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca { i64, ptr }
  %l30 = alloca i64
  %l35 = alloca i64
  %l38 = alloca i64
  %l59 = alloca i64
  %l63 = alloca i1
  %l67 = alloca i1
  %l74 = alloca i64
  %l79 = alloca i64
  %l87 = alloca i1
  %l90 = alloca i64
  %l94 = alloca %"compiler/bindgen:record"
  %s0 = alloca %olang.scope
  %rv = alloca i64
  %t5 = alloca %"compiler/bindgen:record", align 8
  %t8 = alloca %"compiler/bindgen:record", align 8
  %t173 = alloca %"compiler/bindgen:record", align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i64 0, ptr %l4, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/bindgen:gen", ptr %t1, i32 0, i32 6
  %t4 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eAt_3ccompiler_2fbindgen_3arecord_3e(ptr %t5, ptr %v0, ptr %v0, ptr %t3, i64 %t4)
  call void @llvm.memmove.p0.p0.i64(ptr %l16, ptr %t5, i64 312, i1 false)
  br label %bb1
bb1:
  call void @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2fbindgen_3arecord(ptr %t8, ptr %s0, ptr %l16)
  call void @llvm.memmove.p0.p0.i64(ptr %l18, ptr %t8, i64 312, i1 false)
  br label %bb2
bb2:
  %t10 = getelementptr %"compiler/bindgen:record", ptr %l18, i32 0, i32 18
  %t11 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t10
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t11, ptr %l20
  %t13 = call ptr @__olang_scope_hold(ptr %s0)
  %t14 = ptrtoint ptr %t13 to i64
  store i64 %t14, ptr %l21, !tbaa !24
  %t15 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t15, label %bb3, label %bb4
bb3:
  %t17 = call ptr @__olang_region_make_part(ptr %s0)
  %t18 = ptrtoint ptr %t17 to i64
  store i64 %t18, ptr %l21, !tbaa !24
  br label %bb4
bb4:
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l20, i32 0, i32 0
  %t20 = load { i64, ptr }, ptr %t19, !tbaa !27
  store { i64, ptr } %t20, ptr %l23, !tbaa !27
  %t21 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t22 = extractvalue { i64, ptr } %t21, 0
  store i64 %t22, ptr %l24, !tbaa !24
  %t23 = load i64, ptr %l24, !tbaa !24
  %t24 = mul i64 %t23, 8
  %t25 = load i64, ptr %l21
  %t26 = inttoptr i64 %t25 to ptr
  %t27 = call ptr @__olang_held_alloc(ptr %t26, i64 %t24)
  %t28 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t29 = insertvalue { i64, ptr } %t28, ptr %t27, 1
  store { i64, ptr } %t29, ptr %l25, !tbaa !27
  %t30 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !27
  %t32 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !27
  %t34 = load i64, ptr %l24, !tbaa !24
  %t35 = mul i64 %t34, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t31, ptr %t33, i64 %t35, i1 false)
  %t36 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t37 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l20, i32 0, i32 0
  store { i64, ptr } %t36, ptr %t37, !tbaa !27
  %t38 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t38, label %bb5, label %bb6
bb5:
  %t40 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l20, i32 0, i32 0
  %t41 = load { i64, ptr }, ptr %t40, !tbaa !27
  %t42 = extractvalue { i64, ptr } %t41, 0
  %t44 = icmp eq i64 %t42, 0
  br i1 %t44, label %bb7, label %bb8
bb6:
  %t46 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l20
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t46, ptr %l5
  store i64 0, ptr %l6, !tbaa !24
  %t48 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l5)
  store i64 %t48, ptr %l30
  br label %bb9
bb7:
  %t49 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l20, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t49, !tbaa !27
  br label %bb8
bb8:
  %t50 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l20, i32 0, i32 0
  %t51 = load i64, ptr %l21
  %t52 = inttoptr i64 %t51 to ptr
  %t53 = load { i64, ptr }, ptr %t50
  %t54 = extractvalue { i64, ptr } %t53, 1
  %t55 = call ptr @__olang_region_or(ptr %t54, ptr null)
  %t56 = icmp ne ptr %t55, null
  %t57 = select i1 %t56, ptr %t55, ptr null
  call void @__olang_region_settle_in(ptr %t52, ptr %t57)
  br label %bb6
bb9:
  %t58 = load i64, ptr %l30, !tbaa !24
  %t59 = sdiv i64 %t58, 3
  store i64 %t59, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t61 = load i64, ptr %l7, !tbaa !24
  %t62 = load i64, ptr %l6, !tbaa !24
  %t65 = icmp sgt i64 %t61, %t62
  br i1 %t65, label %bb10, label %bb11
bb10:
  %t67 = load i64, ptr %l8, !tbaa !24
  %t69 = icmp sgt i64 %t67, 0
  br i1 %t69, label %bb12, label %bb13
bb11:
  store i64 0, ptr %l35, !tbaa !24
  br label %bb15
bb12:
  %t71 = load i64, ptr %l7, !tbaa !24
  %t72 = load i64, ptr %l6, !tbaa !24
  %t75 = sub i64 %t71, %t72
  %t76 = load i64, ptr %l8, !tbaa !24
  %t79 = add i64 %t75, %t76
  %t81 = sub i64 %t79, 1
  %t82 = load i64, ptr %l8, !tbaa !24
  %t85 = sdiv i64 %t81, %t82
  store i64 %t85, ptr %l38, !tbaa !24
  br label %bb14
bb13:
  store i64 0, ptr %l38, !tbaa !24
  br label %bb14
bb14:
  %t87 = load i64, ptr %l38, !tbaa !24
  store i64 %t87, ptr %l35, !tbaa !24
  br label %bb15
bb15:
  %t88 = load i64, ptr %l35, !tbaa !24
  store i64 %t88, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb16
bb16:
  %t89 = load i64, ptr %l10, !tbaa !24
  %t90 = load i64, ptr %l9, !tbaa !24
  %t93 = icmp slt i64 %t89, %t90
  %t95 = xor i1 %t93, true
  br i1 %t95, label %bb17, label %bb18
bb17:
  br label %bb32
bb18:
  br label %bb19
bb19:
  %t97 = load i64, ptr %l6, !tbaa !24
  %t98 = load i64, ptr %l10, !tbaa !24
  %t99 = load i64, ptr %l8, !tbaa !24
  %t102 = mul i64 %t98, %t99
  %t105 = add i64 %t97, %t102
  store i64 %t105, ptr %l11, !tbaa !24
  %t107 = load i64, ptr %l11, !tbaa !24
  %t109 = mul i64 3, %t107
  %t112 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l5, i64 %t109)
  store i64 %t112, ptr %l59
  br label %bb20
bb20:
  %t113 = load i64, ptr %l59, !tbaa !24
  store i64 %t113, ptr %l12, !tbaa !24
  %t114 = load i64, ptr %l12, !tbaa !24
  %t115 = load i64, ptr %l4, !tbaa !24
  %t118 = icmp sgt i64 %t114, %t115
  br i1 %t118, label %bb21, label %bb22
bb21:
  %t120 = load i64, ptr %l2, !tbaa !24
  %t121 = load i64, ptr %l4, !tbaa !24
  %t124 = icmp sge i64 %t120, %t121
  store i1 %t124, ptr %l63, !tbaa !21
  br label %bb23
bb22:
  store i1 false, ptr %l63, !tbaa !21
  br label %bb23
bb23:
  %t126 = load i1, ptr %l63, !tbaa !21
  br i1 %t126, label %bb24, label %bb25
bb24:
  %t127 = load i64, ptr %l2, !tbaa !24
  %t128 = load i64, ptr %l3, !tbaa !24
  %t131 = add i64 %t127, %t128
  %t132 = load i64, ptr %l12, !tbaa !24
  %t135 = icmp sle i64 %t131, %t132
  store i1 %t135, ptr %l67, !tbaa !21
  br label %bb26
bb25:
  store i1 false, ptr %l67, !tbaa !21
  br label %bb26
bb26:
  %t137 = load i1, ptr %l67, !tbaa !21
  br i1 %t137, label %bb27, label %bb28
bb27:
  %t138 = load i64, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t138, ptr %rv
  br label %ret
bb28:
  br label %bb29
bb29:
  %t140 = load i64, ptr %l12, !tbaa !24
  store i64 %t140, ptr %l74, !tbaa !24
  %t141 = load i64, ptr %l11, !tbaa !24
  %t143 = mul i64 3, %t141
  %t145 = add i64 %t143, 1
  %t148 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l5, i64 %t145)
  store i64 %t148, ptr %l79
  br label %bb30
bb30:
  %t149 = load i64, ptr %l74, !tbaa !24
  %t150 = load i64, ptr %l79, !tbaa !24
  %t151 = add i64 %t149, %t150
  store i64 %t151, ptr %l4, !tbaa !24
  br label %bb31
bb31:
  %t153 = load i64, ptr %l10, !tbaa !24
  %t156 = add i64 %t153, 1
  store i64 %t156, ptr %l10, !tbaa !24
  br label %bb16
bb32:
  %t158 = load i64, ptr %l2, !tbaa !24
  %t159 = load i64, ptr %l4, !tbaa !24
  %t162 = icmp sge i64 %t158, %t159
  br i1 %t162, label %bb33, label %bb34
bb33:
  %t164 = load i64, ptr %l2, !tbaa !24
  %t165 = load i64, ptr %l3, !tbaa !24
  %t168 = add i64 %t164, %t165
  store i64 %t168, ptr %l90, !tbaa !24
  %t169 = load ptr, ptr %l0, !tbaa !29
  %t171 = getelementptr %"compiler/bindgen:gen", ptr %t169, i32 0, i32 6
  %t172 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eAt_3ccompiler_2fbindgen_3arecord_3e(ptr %t173, ptr %v0, ptr %s0, ptr %t171, i64 %t172)
  call void @llvm.memmove.p0.p0.i64(ptr %l94, ptr %t173, i64 312, i1 false)
  br label %bb35
bb34:
  store i1 false, ptr %l87, !tbaa !21
  br label %bb36
bb35:
  %t176 = getelementptr %"compiler/bindgen:record", ptr %l94, i32 0, i32 13
  %t177 = load i64, ptr %t176, !tbaa !24
  %t178 = load i64, ptr %l90, !tbaa !24
  %t180 = icmp sle i64 %t178, %t177
  store i1 %t180, ptr %l87, !tbaa !21
  br label %bb36
bb36:
  %t182 = load i1, ptr %l87, !tbaa !21
  br i1 %t182, label %bb37, label %bb38
bb37:
  %t183 = load i64, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t183, ptr %rv
  br label %ret
bb38:
  br label %bb39
bb39:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2egapEnd(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l13 = alloca %"compiler/bindgen:record"
  %l15 = alloca %"compiler/bindgen:record"
  %l17 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l18 = alloca i64
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca { i64, ptr }
  %l27 = alloca i64
  %l32 = alloca i64
  %l35 = alloca i64
  %l56 = alloca i64
  %l62 = alloca i64
  %l69 = alloca %"compiler/bindgen:record"
  %s0 = alloca %olang.scope
  %rv = alloca i64
  %t5 = alloca %"compiler/bindgen:record", align 8
  %t8 = alloca %"compiler/bindgen:record", align 8
  %t134 = alloca %"compiler/bindgen:record", align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/bindgen:gen", ptr %t1, i32 0, i32 6
  %t4 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eAt_3ccompiler_2fbindgen_3arecord_3e(ptr %t5, ptr %v0, ptr %v0, ptr %t3, i64 %t4)
  call void @llvm.memmove.p0.p0.i64(ptr %l13, ptr %t5, i64 312, i1 false)
  br label %bb1
bb1:
  call void @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2fbindgen_3arecord(ptr %t8, ptr %s0, ptr %l13)
  call void @llvm.memmove.p0.p0.i64(ptr %l15, ptr %t8, i64 312, i1 false)
  br label %bb2
bb2:
  %t10 = getelementptr %"compiler/bindgen:record", ptr %l15, i32 0, i32 18
  %t11 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t10
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t11, ptr %l17
  %t13 = call ptr @__olang_scope_hold(ptr %s0)
  %t14 = ptrtoint ptr %t13 to i64
  store i64 %t14, ptr %l18, !tbaa !24
  %t15 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t15, label %bb3, label %bb4
bb3:
  %t17 = call ptr @__olang_region_make_part(ptr %s0)
  %t18 = ptrtoint ptr %t17 to i64
  store i64 %t18, ptr %l18, !tbaa !24
  br label %bb4
bb4:
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l17, i32 0, i32 0
  %t20 = load { i64, ptr }, ptr %t19, !tbaa !27
  store { i64, ptr } %t20, ptr %l20, !tbaa !27
  %t21 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t22 = extractvalue { i64, ptr } %t21, 0
  store i64 %t22, ptr %l21, !tbaa !24
  %t23 = load i64, ptr %l21, !tbaa !24
  %t24 = mul i64 %t23, 8
  %t25 = load i64, ptr %l18
  %t26 = inttoptr i64 %t25 to ptr
  %t27 = call ptr @__olang_held_alloc(ptr %t26, i64 %t24)
  %t28 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t29 = insertvalue { i64, ptr } %t28, ptr %t27, 1
  store { i64, ptr } %t29, ptr %l22, !tbaa !27
  %t30 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !27
  %t32 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !27
  %t34 = load i64, ptr %l21, !tbaa !24
  %t35 = mul i64 %t34, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t31, ptr %t33, i64 %t35, i1 false)
  %t36 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t37 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l17, i32 0, i32 0
  store { i64, ptr } %t36, ptr %t37, !tbaa !27
  %t38 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t38, label %bb5, label %bb6
bb5:
  %t40 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l17, i32 0, i32 0
  %t41 = load { i64, ptr }, ptr %t40, !tbaa !27
  %t42 = extractvalue { i64, ptr } %t41, 0
  %t44 = icmp eq i64 %t42, 0
  br i1 %t44, label %bb7, label %bb8
bb6:
  %t46 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l17
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t46, ptr %l3
  store i64 0, ptr %l4, !tbaa !24
  %t48 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l3)
  store i64 %t48, ptr %l27
  br label %bb9
bb7:
  %t49 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l17, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t49, !tbaa !27
  br label %bb8
bb8:
  %t50 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l17, i32 0, i32 0
  %t51 = load i64, ptr %l18
  %t52 = inttoptr i64 %t51 to ptr
  %t53 = load { i64, ptr }, ptr %t50
  %t54 = extractvalue { i64, ptr } %t53, 1
  %t55 = call ptr @__olang_region_or(ptr %t54, ptr null)
  %t56 = icmp ne ptr %t55, null
  %t57 = select i1 %t56, ptr %t55, ptr null
  call void @__olang_region_settle_in(ptr %t52, ptr %t57)
  br label %bb6
bb9:
  %t58 = load i64, ptr %l27, !tbaa !24
  %t59 = sdiv i64 %t58, 3
  store i64 %t59, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t61 = load i64, ptr %l5, !tbaa !24
  %t62 = load i64, ptr %l4, !tbaa !24
  %t65 = icmp sgt i64 %t61, %t62
  br i1 %t65, label %bb10, label %bb11
bb10:
  %t67 = load i64, ptr %l6, !tbaa !24
  %t69 = icmp sgt i64 %t67, 0
  br i1 %t69, label %bb12, label %bb13
bb11:
  store i64 0, ptr %l32, !tbaa !24
  br label %bb15
bb12:
  %t71 = load i64, ptr %l5, !tbaa !24
  %t72 = load i64, ptr %l4, !tbaa !24
  %t75 = sub i64 %t71, %t72
  %t76 = load i64, ptr %l6, !tbaa !24
  %t79 = add i64 %t75, %t76
  %t81 = sub i64 %t79, 1
  %t82 = load i64, ptr %l6, !tbaa !24
  %t85 = sdiv i64 %t81, %t82
  store i64 %t85, ptr %l35, !tbaa !24
  br label %bb14
bb13:
  store i64 0, ptr %l35, !tbaa !24
  br label %bb14
bb14:
  %t87 = load i64, ptr %l35, !tbaa !24
  store i64 %t87, ptr %l32, !tbaa !24
  br label %bb15
bb15:
  %t88 = load i64, ptr %l32, !tbaa !24
  store i64 %t88, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb16
bb16:
  %t89 = load i64, ptr %l8, !tbaa !24
  %t90 = load i64, ptr %l7, !tbaa !24
  %t93 = icmp slt i64 %t89, %t90
  %t95 = xor i1 %t93, true
  br i1 %t95, label %bb17, label %bb18
bb17:
  br label %bb26
bb18:
  br label %bb19
bb19:
  %t97 = load i64, ptr %l4, !tbaa !24
  %t98 = load i64, ptr %l8, !tbaa !24
  %t99 = load i64, ptr %l6, !tbaa !24
  %t102 = mul i64 %t98, %t99
  %t105 = add i64 %t97, %t102
  store i64 %t105, ptr %l9, !tbaa !24
  %t107 = load i64, ptr %l9, !tbaa !24
  %t109 = mul i64 3, %t107
  %t112 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l3, i64 %t109)
  store i64 %t112, ptr %l56
  br label %bb20
bb20:
  %t114 = load i64, ptr %l56, !tbaa !24
  %t116 = icmp sgt i64 %t114, %a2
  br i1 %t116, label %bb21, label %bb22
bb21:
  %t118 = load i64, ptr %l9, !tbaa !24
  %t120 = mul i64 3, %t118
  %t123 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l3, i64 %t120)
  store i64 %t123, ptr %l62
  br label %bb23
bb22:
  br label %bb24
bb23:
  call void @__olang_scope_close(ptr %s0)
  %t124 = load i64, ptr %l62, !tbaa !24
  store i64 %t124, ptr %rv
  br label %ret
bb24:
  br label %bb25
bb25:
  %t125 = load i64, ptr %l8, !tbaa !24
  %t128 = add i64 %t125, 1
  store i64 %t128, ptr %l8, !tbaa !24
  br label %bb16
bb26:
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t132 = getelementptr %"compiler/bindgen:gen", ptr %t130, i32 0, i32 6
  %t133 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eAt_3ccompiler_2fbindgen_3arecord_3e(ptr %t134, ptr %v0, ptr %s0, ptr %t132, i64 %t133)
  call void @llvm.memmove.p0.p0.i64(ptr %l69, ptr %t134, i64 312, i1 false)
  br label %bb27
bb27:
  %t137 = getelementptr %"compiler/bindgen:record", ptr %l69, i32 0, i32 13
  %t138 = load i64, ptr %t137, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t138, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2emacroFns(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca %"compiler/bindgen:cMacro"
  %lp5 = alloca ptr
  %l8 = alloca i64
  %l10 = alloca i64
  %l15 = alloca %"compiler/bindgen:cMacro"
  %l17 = alloca i1
  %l18 = alloca i1
  %l21 = alloca i1
  %l24 = alloca i1
  %l26 = alloca i1
  %l28 = alloca i1
  %l33 = alloca i1
  %l34 = alloca i1
  %l36 = alloca i1
  %l40 = alloca { i64, ptr }
  %l43 = alloca { i64, ptr }
  %l44 = alloca i32
  %l46 = alloca i1
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/bindgen:gen", ptr %t1, i32 0, i32 13
  store ptr %t3, ptr %l1, !tbaa !29
  store i64 0, ptr %l2, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t5 = load i64, ptr %l2, !tbaa !24
  store i64 %t5, ptr %l8, !tbaa !24
  %t6 = load ptr, ptr %l1, !tbaa !29
  %t8 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3acMacro_3e_2eLen_3ccompiler_2fbindgen_3acMacro_3e(ptr %v0, ptr %t6)
  store i64 %t8, ptr %l10
  br label %bb2
bb2:
  %t9 = load i64, ptr %l8, !tbaa !24
  %t10 = load i64, ptr %l10, !tbaa !24
  %t11 = icmp slt i64 %t9, %t10
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb41
bb4:
  br label %bb5
bb5:
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t16 = load i64, ptr %l2, !tbaa !24
  %t19 = call %"compiler/bindgen:cMacro" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3acMacro_3e_2eAt_3ccompiler_2fbindgen_3acMacro_3e(ptr %v0, ptr %v0, ptr %t15, i64 %t16)
  store %"compiler/bindgen:cMacro" %t19, ptr %l15
  br label %bb6
bb6:
  %t20 = load %"compiler/bindgen:cMacro", ptr %l15
  store %"compiler/bindgen:cMacro" %t20, ptr %l3
  %t21 = getelementptr %"compiler/bindgen:cMacro", ptr %l3, i32 0, i32 0
  %t22 = load { i64, ptr }, ptr %t21, !tbaa !27
  %t24 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s2, { i64, ptr } %t22, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d109, i32 0, i32 1) })
  store i1 %t24, ptr %l17
  br label %bb7
bb7:
  %t25 = load i1, ptr %l17, !tbaa !21
  br i1 %t25, label %bb8, label %bb9
bb8:
  store i1 true, ptr %l18, !tbaa !21
  br label %bb10
bb9:
  %t26 = getelementptr %"compiler/bindgen:cMacro", ptr %l3, i32 0, i32 1
  %t27 = load i1, ptr %t26, !tbaa !21
  %t29 = xor i1 %t27, true
  store i1 %t29, ptr %l18, !tbaa !21
  br label %bb10
bb10:
  %t31 = load i1, ptr %l18, !tbaa !21
  br i1 %t31, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l21, !tbaa !21
  br label %bb13
bb12:
  %t32 = getelementptr %"compiler/bindgen:cMacro", ptr %l3, i32 0, i32 4
  %t33 = load i1, ptr %t32, !tbaa !21
  %t35 = xor i1 %t33, true
  store i1 %t35, ptr %l21, !tbaa !21
  br label %bb13
bb13:
  %t37 = load i1, ptr %l21, !tbaa !21
  br i1 %t37, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l24, !tbaa !21
  br label %bb17
bb15:
  %t38 = getelementptr %"compiler/bindgen:cMacro", ptr %l3, i32 0, i32 0
  %t39 = load { i64, ptr }, ptr %t38, !tbaa !27
  %t41 = call i1 @compiler_2fbindgen_2eusable(ptr %v0, { i64, ptr } %t39)
  store i1 %t41, ptr %l26
  br label %bb16
bb16:
  %t42 = load i1, ptr %l26, !tbaa !21
  %t43 = xor i1 %t42, true
  store i1 %t43, ptr %l24, !tbaa !21
  br label %bb17
bb17:
  %t45 = load i1, ptr %l24, !tbaa !21
  br i1 %t45, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l28, !tbaa !21
  br label %bb21
bb19:
  %t46 = getelementptr %"compiler/bindgen:cMacro", ptr %l3, i32 0, i32 0
  %t47 = load { i64, ptr }, ptr %t46, !tbaa !27
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/bindgen:gen", ptr %t49, i32 0, i32 22
  %t55 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9b83f66eba65594537030636cb0b52b7(ptr %v0, ptr %v0, ptr %t51, { i64, ptr } %t47)
  store i1 %t55, ptr %l33
  br label %bb20
bb20:
  %t56 = load i1, ptr %l33, !tbaa !21
  store i1 %t56, ptr %l28, !tbaa !21
  br label %bb21
bb21:
  %t57 = load i1, ptr %l28, !tbaa !21
  br i1 %t57, label %bb22, label %bb23
bb22:
  store i1 true, ptr %l34, !tbaa !21
  br label %bb25
bb23:
  %t58 = getelementptr %"compiler/bindgen:cMacro", ptr %l3, i32 0, i32 0
  %t59 = load { i64, ptr }, ptr %t58, !tbaa !27
  %t61 = call i1 @compiler_2fbindgen_2epreludeName(ptr %v0, { i64, ptr } %t59)
  store i1 %t61, ptr %l36
  br label %bb24
bb24:
  %t62 = load i1, ptr %l36, !tbaa !21
  store i1 %t62, ptr %l34, !tbaa !21
  br label %bb25
bb25:
  %t63 = load i1, ptr %l34, !tbaa !21
  br i1 %t63, label %bb26, label %bb27
bb26:
  call void @__olang_scope_close(ptr %s2)
  br label %bb40
bb27:
  br label %bb28
bb28:
  %t64 = getelementptr %"compiler/bindgen:cMacro", ptr %l3, i32 0, i32 5
  %t65 = load i1, ptr %t64, !tbaa !21
  br i1 %t65, label %bb29, label %bb30
bb29:
  store %olang.scope zeroinitializer, ptr %s4
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"compiler/bindgen:cMacro", ptr %l3, i32 0, i32 0
  %t69 = load { i64, ptr }, ptr %t68, !tbaa !27
  call void @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eskippedMacro(ptr %v0, ptr %v0, ptr %s4, ptr %t67, { i64, ptr } %t69, { i64, ptr } { i64 39, ptr getelementptr inbounds (<{ i64, [39 x i8] }>, ptr @.d110, i32 0, i32 1) })
  br label %bb31
bb30:
  br label %bb32
bb31:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s2)
  br label %bb40
bb32:
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t75 = call { i32, { i64, ptr } } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2emacroFn(ptr %v0, ptr %s2, ptr %v0, ptr %t72, ptr %l3)
  %t76 = extractvalue { i32, { i64, ptr } } %t75, 1
  %t77 = extractvalue { i32, { i64, ptr } } %t75, 0
  store i32 %t77, ptr %l44
  %t78 = icmp ne i32 %t77, 0
  br i1 %t78, label %bb34, label %ok.79, !prof !99
ok.79:
  store { i64, ptr } %t76, ptr %l43
  br label %bb33
bb33:
  %t80 = load { i64, ptr }, ptr %l43, !tbaa !27
  store { i64, ptr } %t80, ptr %l40, !tbaa !27
  br label %bb37
bb34:
  %t81 = load i32, ptr %l44, !tbaa !23
  %t82 = ashr i32 %t81, 16
  %t84 = icmp eq i32 %t82, 1
  store i1 %t84, ptr %l46, !tbaa !21
  br label %bb35
bb35:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr %"compiler/bindgen:cMacro", ptr %l3, i32 0, i32 0
  %t87 = load { i64, ptr }, ptr %t86, !tbaa !27
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t90 = getelementptr %"compiler/bindgen:gen", ptr %t88, i32 0, i32 26
  %t91 = load { i64, ptr }, ptr %t90, !tbaa !27
  call void @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eskippedMacro(ptr %v0, ptr %v0, ptr %v0, ptr %t85, { i64, ptr } %t87, { i64, ptr } %t91)
  br label %bb36
bb36:
  call void @__olang_scope_close(ptr %s2)
  br label %bb40
bb37:
  %t95 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 16, i64 8)
  store ptr %t95, ptr %lp5
  %t96 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t97 = load ptr, ptr %lp5
  store { i64, ptr } %t96, ptr %t97, !tbaa !27
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t100 = getelementptr %"compiler/bindgen:gen", ptr %t98, i32 0, i32 15
  %t101 = load ptr, ptr %lp5
  %t102 = load { i64, ptr }, ptr %t101, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v0, ptr %t100, { i64, ptr } %t102)
  br label %bb38
bb38:
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t107 = getelementptr %"compiler/bindgen:gen", ptr %t105, i32 0, i32 22
  %t108 = getelementptr %"compiler/bindgen:cMacro", ptr %l3, i32 0, i32 0
  %t109 = load { i64, ptr }, ptr %t108, !tbaa !27
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha091d021a90ce6aa48813730c00df6d2(ptr %v0, ptr %v0, ptr %t107, { i64, ptr } %t109, i64 0)
  br label %bb39
bb39:
  call void @__olang_scope_close(ptr %s2)
  br label %bb40
bb40:
  %t112 = load i64, ptr %l2, !tbaa !24
  %t115 = add i64 %t112, 1
  store i64 %t115, ptr %l2, !tbaa !24
  br label %bb1
bb41:
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ememberNumber(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %lp3 = alloca ptr
  %l6 = alloca i64
  %l10 = alloca %"compiler/bindgen:ctype"
  %l14 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l22 = alloca i32
  %l24 = alloca i1
  %l25 = alloca { i64, ptr }
  %l27 = alloca i64
  %l28 = alloca { i64, ptr }
  %l30 = alloca i64
  %l32 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l36 = alloca i64
  %l37 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eparseType(ptr %v0, ptr %v1, ptr %t1, { i64, ptr } %a1, i64 0)
  store i64 %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load i64, ptr %l6, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/bindgen:gen", ptr %t7, i32 0, i32 17
  %t10 = load i64, ptr %l2, !tbaa !24
  %t13 = call %"compiler/bindgen:ctype" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3actype_3e_2eAt_3ccompiler_2fbindgen_3actype_3e(ptr %v0, ptr %s0, ptr %t9, i64 %t10)
  store %"compiler/bindgen:ctype" %t13, ptr %l10
  br label %bb2
bb2:
  %t14 = getelementptr %"compiler/bindgen:ctype", ptr %l10, i32 0, i32 0
  %t15 = load i32, ptr %t14, !range !{i32 0, i32 7}
  %t17 = trunc i64 1 to i32
  %t18 = icmp eq i32 %t15, %t17
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb3, label %bb4
bb3:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d111, i32 0, i32 1) }, ptr %l14, !tbaa !27
  %t22 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t22, ptr %l15, !tbaa !27
  %t23 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t24 = extractvalue { i64, ptr } %t23, 0
  store i64 %t24, ptr %l16, !tbaa !24
  %t25 = load i64, ptr %l16, !tbaa !24
  %t26 = mul i64 %t25, 1
  %t27 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t26)
  %t28 = insertvalue { i64, ptr } undef, i64 %t25, 0
  %t29 = insertvalue { i64, ptr } %t28, ptr %t27, 1
  store { i64, ptr } %t29, ptr %l17, !tbaa !27
  %t30 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !27
  %t32 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !27
  %t34 = load i64, ptr %l16, !tbaa !24
  %t35 = mul i64 %t34, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t31, ptr %t33, i64 %t35, i1 false)
  %t36 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t36, ptr %l15, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t37 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t37, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t39 = load i64, ptr %l2, !tbaa !24
  %t42 = call { i32, { i64, ptr } } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2efieldType(ptr %v0, ptr %v2, ptr %t38, i64 %t39)
  %t43 = extractvalue { i32, { i64, ptr } } %t42, 1
  %t44 = extractvalue { i32, { i64, ptr } } %t42, 0
  store i32 %t44, ptr %l22
  %t45 = icmp ne i32 %t44, 0
  br i1 %t45, label %bb7, label %ok.46, !prof !99
ok.46:
  store { i64, ptr } %t43, ptr %l21
  br label %bb6
bb6:
  %t47 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t47, ptr %l18, !tbaa !27
  br label %bb9
bb7:
  %t48 = load i32, ptr %l22, !tbaa !23
  %t49 = ashr i32 %t48, 16
  %t51 = icmp eq i32 %t49, 1
  store i1 %t51, ptr %l24, !tbaa !21
  br label %bb8
bb8:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d112, i32 0, i32 1) }, ptr %l25, !tbaa !27
  %t52 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t52, ptr %l18, !tbaa !27
  br label %bb9
bb9:
  %t54 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t55 = extractvalue { i64, ptr } %t54, 0
  store i64 %t55, ptr %l27, !tbaa !24
  %t56 = load i64, ptr %l27, !tbaa !24
  %t57 = mul i64 %t56, 1
  %t58 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t57)
  %t59 = insertvalue { i64, ptr } undef, i64 %t56, 0
  %t60 = insertvalue { i64, ptr } %t59, ptr %t58, 1
  store { i64, ptr } %t60, ptr %l28, !tbaa !27
  %t61 = getelementptr { i64, ptr }, ptr %l28, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !27
  %t63 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t64 = load ptr, ptr %t63, !tbaa !27
  %t65 = load i64, ptr %l27, !tbaa !24
  %t66 = mul i64 %t65, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t62, ptr %t64, i64 %t66, i1 false)
  %t67 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 16, i64 8)
  store ptr %t67, ptr %lp3
  %t68 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t69 = load ptr, ptr %lp3
  store { i64, ptr } %t68, ptr %t69, !tbaa !27
  %t70 = load ptr, ptr %lp3
  %t71 = load { i64, ptr }, ptr %t70, !tbaa !27
  %t73 = call i64 @compiler_2fbindgen_2enumBytes(ptr %v2, { i64, ptr } %t71)
  store i64 %t73, ptr %l30
  br label %bb10
bb10:
  %t74 = load i64, ptr %l30, !tbaa !24
  %t75 = icmp sgt i64 %t74, 0
  br i1 %t75, label %bb11, label %bb12
bb11:
  %t77 = load ptr, ptr %lp3
  %t78 = load { i64, ptr }, ptr %t77, !tbaa !27
  store { i64, ptr } %t78, ptr %l32, !tbaa !27
  br label %bb13
bb12:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d113, i32 0, i32 1) }, ptr %l34, !tbaa !27
  %t80 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t80, ptr %l32, !tbaa !27
  br label %bb13
bb13:
  %t82 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t83 = extractvalue { i64, ptr } %t82, 0
  store i64 %t83, ptr %l36, !tbaa !24
  %t84 = load i64, ptr %l36, !tbaa !24
  %t85 = mul i64 %t84, 1
  %t86 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t85)
  %t87 = insertvalue { i64, ptr } undef, i64 %t84, 0
  %t88 = insertvalue { i64, ptr } %t87, ptr %t86, 1
  store { i64, ptr } %t88, ptr %l37, !tbaa !27
  %t89 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t90 = load ptr, ptr %t89, !tbaa !27
  %t91 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t92 = load ptr, ptr %t91, !tbaa !27
  %t93 = load i64, ptr %l36, !tbaa !24
  %t94 = mul i64 %t93, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t90, ptr %t92, i64 %t94, i1 false)
  %t95 = load { i64, ptr }, ptr %l37, !tbaa !27
  store { i64, ptr } %t95, ptr %l32, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t96 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t96, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2enameRecords(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9"
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l13 = alloca %"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9"
  %l14 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l17 = alloca i32
  %l19 = alloca i1
  %l20 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l25 = alloca i32
  %l27 = alloca i1
  %l28 = alloca i1
  %l30 = alloca i1
  %l31 = alloca i1
  %l36 = alloca i1
  %l38 = alloca i1
  %l40 = alloca i1
  %l47 = alloca i64
  %l51 = alloca i64
  %l54 = alloca i64
  %l75 = alloca %"compiler/bindgen:record"
  %l77 = alloca i1
  %l78 = alloca ptr
  %l79 = alloca i64
  %l80 = alloca { i64, ptr }
  %l82 = alloca ptr
  %l86 = alloca %"compiler/bindgen:record"
  %l88 = alloca { i64, ptr }
  %l89 = alloca i32
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %t123 = alloca %"compiler/bindgen:record", align 8
  %t140 = alloca %"compiler/bindgen:record", align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/bindgen:gen", ptr %t1, i32 0, i32 5
  %t5 = call %"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Hd80cb4cbc6ceb8a13686fbc19b8451b4(ptr %v0, ptr %v0, ptr %t3)
  store %"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9" %t5, ptr %l13
  br label %bb1
bb1:
  %t6 = load %"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9", ptr %l13
  store %"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9" %t6, ptr %l1
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t8 = call { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapKeyIter_3cstd_2fprelude_2ftext_3aString_2_H116ed76223103781f5a7340c80f3d0f3(ptr %v0, ptr %v0, ptr %l1)
  %t9 = extractvalue { i32, { i64, ptr } } %t8, 1
  %t10 = extractvalue { i32, { i64, ptr } } %t8, 0
  store i32 %t10, ptr %l17
  %t11 = icmp ne i32 %t10, 0
  br i1 %t11, label %bb4, label %ok.12, !prof !99
ok.12:
  store { i64, ptr } %t9, ptr %l16
  br label %bb3
bb3:
  %t13 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t13, ptr %l14, !tbaa !27
  br label %bb6
bb4:
  %t14 = load i32, ptr %l17, !tbaa !23
  %t15 = ashr i32 %t14, 16
  %t17 = icmp eq i32 %t15, 1
  store i1 %t17, ptr %l19, !tbaa !21
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s2)
  br label %bb29
bb6:
  %t18 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t18, ptr %l2, !tbaa !27
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/bindgen:gen", ptr %t19, i32 0, i32 5
  %t22 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t25 = call { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha4444909f5ef14f7626d25b8f59e6ba2(ptr %v0, ptr %v0, ptr %v0, ptr %t21, { i64, ptr } %t22)
  %t26 = extractvalue { i32, { i64, ptr } } %t25, 1
  %t27 = extractvalue { i32, { i64, ptr } } %t25, 0
  store i32 %t27, ptr %l25
  %t28 = icmp ne i32 %t27, 0
  br i1 %t28, label %bb8, label %ok.29, !prof !99
ok.29:
  store { i64, ptr } %t26, ptr %l24
  br label %bb7
bb7:
  %t30 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t30, ptr %l20, !tbaa !27
  br label %bb10
bb8:
  br label %bb9
bb9:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d114, i32 0, i32 1) }, ptr %l20, !tbaa !27
  br label %bb10
bb10:
  %t31 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t31, ptr %l3, !tbaa !27
  %t32 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t34 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s2, { i64, ptr } %t32, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d115, i32 0, i32 1) })
  store i1 %t34, ptr %l27
  br label %bb11
bb11:
  %t35 = load i1, ptr %l27, !tbaa !21
  br i1 %t35, label %bb12, label %bb13
bb12:
  store i1 true, ptr %l28, !tbaa !21
  br label %bb15
bb13:
  %t36 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t38 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s2, { i64, ptr } %t36, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d116, i32 0, i32 1) })
  store i1 %t38, ptr %l30
  br label %bb14
bb14:
  %t39 = load i1, ptr %l30, !tbaa !21
  store i1 %t39, ptr %l28, !tbaa !21
  br label %bb15
bb15:
  %t40 = load i1, ptr %l28, !tbaa !21
  br i1 %t40, label %bb16, label %bb17
bb16:
  %t41 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/bindgen:gen", ptr %t43, i32 0, i32 23
  %t49 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_He27db0a1785588531472bfd2db42574f(ptr %v0, ptr %v0, ptr %t45, { i64, ptr } %t41)
  store i1 %t49, ptr %l36
  br label %bb18
bb17:
  store i1 false, ptr %l31, !tbaa !21
  br label %bb19
bb18:
  %t50 = load i1, ptr %l36, !tbaa !21
  %t51 = xor i1 %t50, true
  store i1 %t51, ptr %l31, !tbaa !21
  br label %bb19
bb19:
  %t53 = load i1, ptr %l31, !tbaa !21
  br i1 %t53, label %bb20, label %bb21
bb20:
  %t54 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t56 = call i1 @compiler_2fbindgen_2eusable(ptr %v0, { i64, ptr } %t54)
  store i1 %t56, ptr %l40
  br label %bb22
bb21:
  store i1 false, ptr %l38, !tbaa !21
  br label %bb23
bb22:
  %t57 = load i1, ptr %l40, !tbaa !21
  store i1 %t57, ptr %l38, !tbaa !21
  br label %bb23
bb23:
  %t58 = load i1, ptr %l38, !tbaa !21
  br i1 %t58, label %bb24, label %bb25
bb24:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/bindgen:gen", ptr %t59, i32 0, i32 23
  %t62 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t63 = load { i64, ptr }, ptr %l2, !tbaa !27
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H6f7a2f8d839c49b6e7a19c287d4b190c(ptr %v0, ptr %v0, ptr %v0, ptr %t61, { i64, ptr } %t62, { i64, ptr } %t63)
  br label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s2)
  br label %bb28
bb28:
  br label %bb2
bb29:
  store i64 0, ptr %l5, !tbaa !24
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/bindgen:gen", ptr %t67, i32 0, i32 6
  %t71 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eLen_3ccompiler_2fbindgen_3arecord_3e(ptr %v0, ptr %t69)
  store i64 %t71, ptr %l47
  br label %bb30
bb30:
  %t72 = load i64, ptr %l47, !tbaa !24
  store i64 %t72, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t73 = load i64, ptr %l6, !tbaa !24
  %t74 = load i64, ptr %l5, !tbaa !24
  %t77 = icmp sgt i64 %t73, %t74
  br i1 %t77, label %bb31, label %bb32
bb31:
  %t79 = load i64, ptr %l7, !tbaa !24
  %t81 = icmp sgt i64 %t79, 0
  br i1 %t81, label %bb33, label %bb34
bb32:
  store i64 0, ptr %l51, !tbaa !24
  br label %bb36
bb33:
  %t83 = load i64, ptr %l6, !tbaa !24
  %t84 = load i64, ptr %l5, !tbaa !24
  %t87 = sub i64 %t83, %t84
  %t88 = load i64, ptr %l7, !tbaa !24
  %t91 = add i64 %t87, %t88
  %t93 = sub i64 %t91, 1
  %t94 = load i64, ptr %l7, !tbaa !24
  %t97 = sdiv i64 %t93, %t94
  store i64 %t97, ptr %l54, !tbaa !24
  br label %bb35
bb34:
  store i64 0, ptr %l54, !tbaa !24
  br label %bb35
bb35:
  %t99 = load i64, ptr %l54, !tbaa !24
  store i64 %t99, ptr %l51, !tbaa !24
  br label %bb36
bb36:
  %t100 = load i64, ptr %l51, !tbaa !24
  store i64 %t100, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb37
bb37:
  store %olang.scope zeroinitializer, ptr %s5
  %t101 = load i64, ptr %l9, !tbaa !24
  %t102 = load i64, ptr %l8, !tbaa !24
  %t105 = icmp slt i64 %t101, %t102
  %t107 = xor i1 %t105, true
  br i1 %t107, label %bb38, label %bb39
bb38:
  call void @__olang_scope_close(ptr %s5)
  br label %bb53
bb39:
  br label %bb40
bb40:
  %t109 = load i64, ptr %l5, !tbaa !24
  %t110 = load i64, ptr %l9, !tbaa !24
  %t111 = load i64, ptr %l7, !tbaa !24
  %t114 = mul i64 %t110, %t111
  %t117 = add i64 %t109, %t114
  store i64 %t117, ptr %l10, !tbaa !24
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t121 = getelementptr %"compiler/bindgen:gen", ptr %t119, i32 0, i32 6
  %t122 = load i64, ptr %l10, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eAt_3ccompiler_2fbindgen_3arecord_3e(ptr %t123, ptr %v0, ptr %v0, ptr %t121, i64 %t122)
  call void @llvm.memmove.p0.p0.i64(ptr %l75, ptr %t123, i64 312, i1 false)
  br label %bb41
bb41:
  %t126 = getelementptr %"compiler/bindgen:record", ptr %l75, i32 0, i32 0
  %t127 = load { i64, ptr }, ptr %t126, !tbaa !27
  %t129 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s5, { i64, ptr } %t127, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d117, i32 0, i32 1) })
  store i1 %t129, ptr %l77
  br label %bb42
bb42:
  %t130 = load i1, ptr %l77, !tbaa !21
  br i1 %t130, label %bb43, label %bb44
bb43:
  call void @__olang_scope_close(ptr %s5)
  br label %bb52
bb44:
  br label %bb45
bb45:
  %t131 = load ptr, ptr %l0, !tbaa !29
  store ptr %t131, ptr %l78, !tbaa !29
  %t132 = load i64, ptr %l10, !tbaa !24
  store i64 %t132, ptr %l79, !tbaa !24
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t135 = getelementptr %"compiler/bindgen:gen", ptr %t133, i32 0, i32 23
  store ptr %t135, ptr %l82, !tbaa !29
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t138 = getelementptr %"compiler/bindgen:gen", ptr %t136, i32 0, i32 6
  %t139 = load i64, ptr %l10, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eAt_3ccompiler_2fbindgen_3arecord_3e(ptr %t140, ptr %v0, ptr %v0, ptr %t138, i64 %t139)
  call void @llvm.memmove.p0.p0.i64(ptr %l86, ptr %t140, i64 312, i1 false)
  br label %bb46
bb46:
  %t143 = getelementptr %"compiler/bindgen:record", ptr %l86, i32 0, i32 0
  %t144 = load { i64, ptr }, ptr %t143, !tbaa !27
  %t145 = load ptr, ptr %l82, !tbaa !29
  %t147 = call { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha4444909f5ef14f7626d25b8f59e6ba2(ptr %v0, ptr %v0, ptr %v0, ptr %t145, { i64, ptr } %t144)
  %t148 = extractvalue { i32, { i64, ptr } } %t147, 1
  %t149 = extractvalue { i32, { i64, ptr } } %t147, 0
  store i32 %t149, ptr %l89
  %t150 = icmp ne i32 %t149, 0
  br i1 %t150, label %bb48, label %ok.151, !prof !99
ok.151:
  store { i64, ptr } %t148, ptr %l88
  br label %bb47
bb47:
  %t152 = load { i64, ptr }, ptr %l88, !tbaa !27
  store { i64, ptr } %t152, ptr %l80, !tbaa !27
  br label %bb50
bb48:
  br label %bb49
bb49:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d118, i32 0, i32 1) }, ptr %l80, !tbaa !27
  br label %bb50
bb50:
  %t153 = load ptr, ptr %l78, !tbaa !29
  %t154 = load i64, ptr %l79, !tbaa !24
  %t155 = load { i64, ptr }, ptr %l80, !tbaa !27
  call void @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2enameRecord(ptr %v0, ptr %v0, ptr %t153, i64 %t154, { i64, ptr } %t155)
  br label %bb51
bb51:
  call void @__olang_scope_close(ptr %s5)
  br label %bb52
bb52:
  %t156 = load i64, ptr %l9, !tbaa !24
  %t159 = add i64 %t156, 1
  store i64 %t159, ptr %l9, !tbaa !24
  br label %bb37
bb53:
  %t161 = load ptr, ptr %l0, !tbaa !29
  %t163 = getelementptr %"compiler/bindgen:gen", ptr %t161, i32 0, i32 24
  store i1 true, ptr %t163, !tbaa !21
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2enumType(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i64 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i1
  %l6 = alloca i1
  %l9 = alloca i64
  %l11 = alloca i1
  %l12 = alloca i1
  %l14 = alloca i1
  %l17 = alloca i64
  %l19 = alloca i1
  %l20 = alloca ptr
  %l21 = alloca i32
  %l24 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l28 = alloca i64
  %l30 = alloca i1
  %l33 = alloca i64
  %l35 = alloca i1
  %l38 = alloca i64
  %l40 = alloca i64
  %l43 = alloca i64
  %l45 = alloca i1
  %l48 = alloca i64
  %l50 = alloca i1
  %l53 = alloca i64
  %l55 = alloca i1
  %l57 = alloca i64
  %l61 = alloca i1
  %l62 = alloca ptr
  %l63 = alloca i32
  %l65 = alloca { i64, ptr }
  %l66 = alloca i64
  %l69 = alloca i1
  %l72 = alloca i1
  %l76 = alloca ptr
  %l77 = alloca i32
  %l79 = alloca { i64, ptr }
  %l80 = alloca i64
  %l81 = alloca ptr
  %l82 = alloca i32
  %l84 = alloca { i64, ptr }
  %l85 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store i64 %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d119, i32 0, i32 1) })
  store i1 %t3, ptr %l6
  br label %bb1
bb1:
  %t4 = load i1, ptr %l6, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t8 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2enode(ptr %v0, ptr %v0, ptr %t5, i32 0, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d120, i32 0, i32 1) }, i64 -1, i1 false, i64 0)
  store i64 %t8, ptr %l9
  br label %bb4
bb3:
  br label %bb5
bb4:
  call void @__olang_scope_close(ptr %s0)
  %t9 = load i64, ptr %l9, !tbaa !24
  store i64 %t9, ptr %rv
  br label %ret
bb5:
  %t10 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t12 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t10, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d121, i32 0, i32 1) })
  store i1 %t12, ptr %l11
  br label %bb6
bb6:
  %t13 = load i1, ptr %l11, !tbaa !21
  br i1 %t13, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb10
bb8:
  %t14 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t16 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t14, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d122, i32 0, i32 1) })
  store i1 %t16, ptr %l14
  br label %bb9
bb9:
  %t17 = load i1, ptr %l14, !tbaa !21
  store i1 %t17, ptr %l12, !tbaa !21
  br label %bb10
bb10:
  %t18 = load i1, ptr %l12, !tbaa !21
  br i1 %t18, label %bb11, label %bb12
bb11:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t22 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2enode(ptr %v0, ptr %v0, ptr %t19, i32 1, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d123, i32 0, i32 1) }, i64 -1, i1 false, i64 0)
  store i64 %t22, ptr %l17
  br label %bb13
bb12:
  br label %bb14
bb13:
  call void @__olang_scope_close(ptr %s0)
  %t23 = load i64, ptr %l17, !tbaa !24
  store i64 %t23, ptr %rv
  br label %ret
bb14:
  %t24 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t26 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t24, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d124, i32 0, i32 1) })
  store i1 %t26, ptr %l19
  br label %bb15
bb15:
  %t27 = load i1, ptr %l19, !tbaa !21
  br i1 %t27, label %bb16, label %bb17
bb16:
  %t28 = load ptr, ptr %l0, !tbaa !29
  store ptr %t28, ptr %l20, !tbaa !29
  store i32 1, ptr %l21
  %t29 = load i64, ptr %l2, !tbaa !24
  %t31 = icmp eq i64 %t29, 1
  br i1 %t31, label %bb18, label %bb19
bb17:
  br label %bb25
bb18:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d125, i32 0, i32 1) }, ptr %l24, !tbaa !27
  br label %bb23
bb19:
  %t33 = load i64, ptr %l2, !tbaa !24
  %t35 = icmp eq i64 %t33, 2
  br i1 %t35, label %bb20, label %bb21
bb20:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d126, i32 0, i32 1) }, ptr %l27, !tbaa !27
  br label %bb22
bb21:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d127, i32 0, i32 1) }, ptr %l27, !tbaa !27
  br label %bb22
bb22:
  %t37 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t37, ptr %l24, !tbaa !27
  br label %bb23
bb23:
  %t38 = load ptr, ptr %l20, !tbaa !29
  %t39 = load i32, ptr %l21, !range !{i32 0, i32 7}
  %t40 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t41 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2enode(ptr %v0, ptr %v0, ptr %t38, i32 %t39, { i64, ptr } %t40, i64 -1, i1 false, i64 0)
  store i64 %t41, ptr %l28
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s0)
  %t42 = load i64, ptr %l28, !tbaa !24
  store i64 %t42, ptr %rv
  br label %ret
bb25:
  %t43 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t45 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t43, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d128, i32 0, i32 1) })
  store i1 %t45, ptr %l30
  br label %bb26
bb26:
  %t46 = load i1, ptr %l30, !tbaa !21
  br i1 %t46, label %bb27, label %bb28
bb27:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t50 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2enode(ptr %v0, ptr %v0, ptr %t47, i32 1, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d129, i32 0, i32 1) }, i64 -1, i1 false, i64 0)
  store i64 %t50, ptr %l33
  br label %bb29
bb28:
  br label %bb30
bb29:
  call void @__olang_scope_close(ptr %s0)
  %t51 = load i64, ptr %l33, !tbaa !24
  store i64 %t51, ptr %rv
  br label %ret
bb30:
  %t52 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t54 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t52, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d130, i32 0, i32 1) })
  store i1 %t54, ptr %l35
  br label %bb31
bb31:
  %t55 = load i1, ptr %l35, !tbaa !21
  br i1 %t55, label %bb32, label %bb33
bb32:
  %t56 = load i64, ptr %l3, !tbaa !24
  %t58 = icmp sgt i64 %t56, 0
  br i1 %t58, label %bb34, label %bb35
bb33:
  br label %bb39
bb34:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ebad(ptr %v0, ptr %v0, ptr %t60, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d131, i32 0, i32 1) })
  store i64 %t62, ptr %l40
  br label %bb36
bb35:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t66 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2enode(ptr %v0, ptr %v0, ptr %t63, i32 1, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d132, i32 0, i32 1) }, i64 -1, i1 false, i64 0)
  store i64 %t66, ptr %l43
  br label %bb37
bb36:
  %t67 = load i64, ptr %l40, !tbaa !24
  store i64 %t67, ptr %l38, !tbaa !24
  br label %bb38
bb37:
  %t68 = load i64, ptr %l43, !tbaa !24
  store i64 %t68, ptr %l38, !tbaa !24
  br label %bb38
bb38:
  call void @__olang_scope_close(ptr %s0)
  %t69 = load i64, ptr %l38, !tbaa !24
  store i64 %t69, ptr %rv
  br label %ret
bb39:
  %t70 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t72 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t70, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d133, i32 0, i32 1) })
  store i1 %t72, ptr %l45
  br label %bb40
bb40:
  %t73 = load i1, ptr %l45, !tbaa !21
  br i1 %t73, label %bb41, label %bb42
bb41:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t77 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2enode(ptr %v0, ptr %v0, ptr %t74, i32 1, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d134, i32 0, i32 1) }, i64 -1, i1 false, i64 0)
  store i64 %t77, ptr %l48
  br label %bb43
bb42:
  br label %bb44
bb43:
  call void @__olang_scope_close(ptr %s0)
  %t78 = load i64, ptr %l48, !tbaa !24
  store i64 %t78, ptr %rv
  br label %ret
bb44:
  %t79 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t81 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t79, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d135, i32 0, i32 1) })
  store i1 %t81, ptr %l50
  br label %bb45
bb45:
  %t82 = load i1, ptr %l50, !tbaa !21
  br i1 %t82, label %bb46, label %bb47
bb46:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t86 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2enode(ptr %v0, ptr %v0, ptr %t83, i32 1, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d136, i32 0, i32 1) }, i64 -1, i1 false, i64 0)
  store i64 %t86, ptr %l53
  br label %bb48
bb47:
  br label %bb49
bb48:
  call void @__olang_scope_close(ptr %s0)
  %t87 = load i64, ptr %l53, !tbaa !24
  store i64 %t87, ptr %rv
  br label %ret
bb49:
  %t88 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t90 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t88, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d137, i32 0, i32 1) })
  store i1 %t90, ptr %l55
  br label %bb50
bb50:
  %t91 = load i1, ptr %l55, !tbaa !21
  br i1 %t91, label %bb51, label %bb52
bb51:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ebad(ptr %v0, ptr %v0, ptr %t92, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d138, i32 0, i32 1) })
  store i64 %t94, ptr %l57
  br label %bb53
bb52:
  br label %bb54
bb53:
  call void @__olang_scope_close(ptr %s0)
  %t95 = load i64, ptr %l57, !tbaa !24
  store i64 %t95, ptr %rv
  br label %ret
bb54:
  %t96 = load i64, ptr %l2, !tbaa !24
  %t98 = icmp eq i64 %t96, 2
  store i1 %t98, ptr %l4, !tbaa !21
  %t100 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t102 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t100, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d139, i32 0, i32 1) })
  store i1 %t102, ptr %l61
  br label %bb55
bb55:
  %t103 = load i1, ptr %l61, !tbaa !21
  br i1 %t103, label %bb56, label %bb57
bb56:
  %t104 = load ptr, ptr %l0, !tbaa !29
  store ptr %t104, ptr %l62, !tbaa !29
  store i32 1, ptr %l63
  %t105 = load i1, ptr %l4, !tbaa !21
  br i1 %t105, label %bb58, label %bb59
bb57:
  br label %bb62
bb58:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d140, i32 0, i32 1) }, ptr %l65, !tbaa !27
  br label %bb60
bb59:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d141, i32 0, i32 1) }, ptr %l65, !tbaa !27
  br label %bb60
bb60:
  %t107 = load ptr, ptr %l62, !tbaa !29
  %t108 = load i32, ptr %l63, !range !{i32 0, i32 7}
  %t109 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t110 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2enode(ptr %v0, ptr %v0, ptr %t107, i32 %t108, { i64, ptr } %t109, i64 -1, i1 false, i64 0)
  store i64 %t110, ptr %l66
  br label %bb61
bb61:
  call void @__olang_scope_close(ptr %s0)
  %t111 = load i64, ptr %l66, !tbaa !24
  store i64 %t111, ptr %rv
  br label %ret
bb62:
  %t112 = load i64, ptr %l3, !tbaa !24
  %t114 = icmp sgt i64 %t112, 1
  br i1 %t114, label %bb63, label %bb64
bb63:
  store i1 true, ptr %l69, !tbaa !21
  br label %bb68
bb64:
  %t116 = load i64, ptr %l3, !tbaa !24
  %t118 = icmp eq i64 %t116, 1
  br i1 %t118, label %bb65, label %bb66
bb65:
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t122 = getelementptr %"compiler/bindgen:gen", ptr %t120, i32 0, i32 2
  %t123 = load i1, ptr %t122, !tbaa !21
  %t125 = xor i1 %t123, true
  store i1 %t125, ptr %l72, !tbaa !21
  br label %bb67
bb66:
  store i1 false, ptr %l72, !tbaa !21
  br label %bb67
bb67:
  %t127 = load i1, ptr %l72, !tbaa !21
  store i1 %t127, ptr %l69, !tbaa !21
  br label %bb68
bb68:
  %t128 = load i1, ptr %l69, !tbaa !21
  br i1 %t128, label %bb69, label %bb70
bb69:
  %t129 = load ptr, ptr %l0, !tbaa !29
  store ptr %t129, ptr %l76, !tbaa !29
  store i32 1, ptr %l77
  %t130 = load i1, ptr %l4, !tbaa !21
  br i1 %t130, label %bb71, label %bb72
bb70:
  br label %bb75
bb71:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d142, i32 0, i32 1) }, ptr %l79, !tbaa !27
  br label %bb73
bb72:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d143, i32 0, i32 1) }, ptr %l79, !tbaa !27
  br label %bb73
bb73:
  %t132 = load ptr, ptr %l76, !tbaa !29
  %t133 = load i32, ptr %l77, !range !{i32 0, i32 7}
  %t134 = load { i64, ptr }, ptr %l79, !tbaa !27
  %t135 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2enode(ptr %v0, ptr %v0, ptr %t132, i32 %t133, { i64, ptr } %t134, i64 -1, i1 false, i64 0)
  store i64 %t135, ptr %l80
  br label %bb74
bb74:
  call void @__olang_scope_close(ptr %s0)
  %t136 = load i64, ptr %l80, !tbaa !24
  store i64 %t136, ptr %rv
  br label %ret
bb75:
  %t137 = load ptr, ptr %l0, !tbaa !29
  store ptr %t137, ptr %l81, !tbaa !29
  store i32 1, ptr %l82
  %t138 = load i1, ptr %l4, !tbaa !21
  br i1 %t138, label %bb76, label %bb77
bb76:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d144, i32 0, i32 1) }, ptr %l84, !tbaa !27
  br label %bb78
bb77:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d145, i32 0, i32 1) }, ptr %l84, !tbaa !27
  br label %bb78
bb78:
  %t140 = load ptr, ptr %l81, !tbaa !29
  %t141 = load i32, ptr %l82, !range !{i32 0, i32 7}
  %t142 = load { i64, ptr }, ptr %l84, !tbaa !27
  %t143 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2enode(ptr %v0, ptr %v0, ptr %t140, i32 %t141, { i64, ptr } %t142, i64 -1, i1 false, i64 0)
  store i64 %t143, ptr %l85
  br label %bb79
bb79:
  call void @__olang_scope_close(ptr %s0)
  %t144 = load i64, ptr %l85, !tbaa !24
  store i64 %t144, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2epackedFields(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca %"compiler/bindgen:record"
  %l4 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l13 = alloca %"compiler/bindgen:ctype"
  %l14 = alloca i64
  %l15 = alloca { i64, ptr }
  %l16 = alloca %"compiler/bindgen:ctype"
  %l17 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l21 = alloca %"compiler/bindgen:record"
  %l22 = alloca %"compiler/bindgen:record"
  %l23 = alloca i64
  %l25 = alloca { i64, ptr }
  %l26 = alloca i64
  %l27 = alloca { i64, ptr }
  %l31 = alloca i64
  %l33 = alloca { i64, ptr }
  %l34 = alloca i64
  %l35 = alloca { i64, ptr }
  %l39 = alloca i64
  %l41 = alloca { i64, ptr }
  %l42 = alloca i64
  %l43 = alloca { i64, ptr }
  %l47 = alloca i64
  %l49 = alloca { i64, ptr }
  %l50 = alloca i64
  %l51 = alloca { i64, ptr }
  %l55 = alloca i64
  %l57 = alloca { i64, ptr }
  %l58 = alloca i64
  %l59 = alloca { i64, ptr }
  %l63 = alloca i64
  %l65 = alloca { i64, ptr }
  %l66 = alloca i64
  %l67 = alloca { i64, ptr }
  %l73 = alloca i1
  %l75 = alloca i1
  %l77 = alloca i1
  %l79 = alloca i64
  %l82 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l84 = alloca i64
  %l88 = alloca i64
  %l91 = alloca i64
  %l111 = alloca { i64, ptr }
  %l112 = alloca i1
  %l113 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l114 = alloca ptr
  %l117 = alloca { i64, ptr }
  %l118 = alloca i64
  %l122 = alloca %"compiler/bindgen:ctype"
  %l125 = alloca i64
  %l126 = alloca ptr
  %l129 = alloca { i64, ptr }
  %l132 = alloca { i64, ptr }
  %l137 = alloca i1
  %l141 = alloca i1
  %l143 = alloca i1
  %l144 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l145 = alloca ptr
  %l146 = alloca i64
  %l148 = alloca { i64, ptr }
  %l151 = alloca { i64, ptr }
  %l161 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l167 = alloca %"compiler/bindgen:ctype"
  %l171 = alloca i1
  %l173 = alloca i1
  %l174 = alloca i1
  %l176 = alloca i1
  %l177 = alloca i1
  %l179 = alloca i64
  %l181 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l182 = alloca ptr
  %l183 = alloca i64
  %l185 = alloca { i64, ptr }
  %l187 = alloca i1
  %l188 = alloca { i64, ptr }
  %l193 = alloca i64
  %l195 = alloca i64
  %l202 = alloca i1
  %l204 = alloca i64
  %l206 = alloca i1
  %l208 = alloca i1
  %l209 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l210 = alloca ptr
  %l211 = alloca i64
  %l213 = alloca { i64, ptr }
  %l215 = alloca i1
  %l216 = alloca { i64, ptr }
  %l220 = alloca i64
  %l222 = alloca i64
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %t7 = alloca %"compiler/bindgen:record", align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l17
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l17
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l2
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/bindgen:gen", ptr %t3, i32 0, i32 6
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eAt_3ccompiler_2fbindgen_3arecord_3e(ptr %t7, ptr %v0, ptr %v0, ptr %t5, i64 %a1)
  call void @llvm.memmove.p0.p0.i64(ptr %l21, ptr %t7, i64 312, i1 false)
  br label %bb2
bb2:
  call void @llvm.memmove.p0.p0.i64(ptr %l22, ptr %l21, i64 312, i1 false)
  %t10 = call ptr @__olang_scope_hold(ptr %v0)
  %t11 = ptrtoint ptr %t10 to i64
  store i64 %t11, ptr %l23, !tbaa !24
  %t12 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e0
  br i1 %t12, label %bb3, label %bb4
bb3:
  %t14 = call ptr @__olang_region_make_part(ptr %v0)
  %t15 = ptrtoint ptr %t14 to i64
  store i64 %t15, ptr %l23, !tbaa !24
  br label %bb4
bb4:
  %t16 = getelementptr %"compiler/bindgen:record", ptr %l22, i32 0, i32 4
  %t17 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t16, i32 0, i32 0
  %t18 = load { i64, ptr }, ptr %t17, !tbaa !27
  store { i64, ptr } %t18, ptr %l25, !tbaa !27
  %t19 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t20 = extractvalue { i64, ptr } %t19, 0
  store i64 %t20, ptr %l26, !tbaa !24
  %t21 = load i64, ptr %l26, !tbaa !24
  %t22 = mul i64 %t21, 16
  %t23 = load i64, ptr %l23
  %t24 = inttoptr i64 %t23 to ptr
  %t25 = call ptr @__olang_held_alloc(ptr %t24, i64 %t22)
  %t26 = insertvalue { i64, ptr } undef, i64 %t21, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t25, 1
  store { i64, ptr } %t27, ptr %l27, !tbaa !27
  %t28 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !27
  %t30 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !27
  %t32 = load i64, ptr %l26, !tbaa !24
  %t33 = mul i64 %t32, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t29, ptr %t31, i64 %t33, i1 false)
  %t34 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t35 = getelementptr %"compiler/bindgen:record", ptr %l22, i32 0, i32 4
  %t36 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t35, i32 0, i32 0
  store { i64, ptr } %t34, ptr %t36, !tbaa !27
  %t37 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e0
  br i1 %t37, label %bb5, label %bb6
bb5:
  %t39 = getelementptr %"compiler/bindgen:record", ptr %l22, i32 0, i32 4
  %t40 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t39, i32 0, i32 0
  %t41 = load { i64, ptr }, ptr %t40, !tbaa !27
  %t42 = extractvalue { i64, ptr } %t41, 0
  %t44 = icmp eq i64 %t42, 0
  br i1 %t44, label %bb7, label %bb8
bb6:
  %t46 = call ptr @__olang_scope_hold(ptr %v0)
  %t47 = ptrtoint ptr %t46 to i64
  store i64 %t47, ptr %l31, !tbaa !24
  %t48 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e0
  br i1 %t48, label %bb9, label %bb10
bb7:
  %t50 = getelementptr %"compiler/bindgen:record", ptr %l22, i32 0, i32 4
  %t51 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t50, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t51, !tbaa !27
  br label %bb8
bb8:
  %t52 = getelementptr %"compiler/bindgen:record", ptr %l22, i32 0, i32 4
  %t53 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t52, i32 0, i32 0
  %t54 = load i64, ptr %l23
  %t55 = inttoptr i64 %t54 to ptr
  %t56 = load { i64, ptr }, ptr %t53
  %t57 = extractvalue { i64, ptr } %t56, 1
  %t58 = call ptr @__olang_region_or(ptr %t57, ptr null)
  %t59 = icmp ne ptr %t58, null
  %t60 = select i1 %t59, ptr %t58, ptr null
  call void @__olang_region_settle_in(ptr %t55, ptr %t60)
  br label %bb6
bb9:
  %t61 = call ptr @__olang_region_make_part(ptr %v0)
  %t62 = ptrtoint ptr %t61 to i64
  store i64 %t62, ptr %l31, !tbaa !24
  br label %bb10
bb10:
  %t63 = getelementptr %"compiler/bindgen:record", ptr %l22, i32 0, i32 5
  %t64 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t63, i32 0, i32 0
  %t65 = load { i64, ptr }, ptr %t64, !tbaa !27
  store { i64, ptr } %t65, ptr %l33, !tbaa !27
  %t66 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t67 = extractvalue { i64, ptr } %t66, 0
  store i64 %t67, ptr %l34, !tbaa !24
  %t68 = load i64, ptr %l34, !tbaa !24
  %t69 = mul i64 %t68, 16
  %t70 = load i64, ptr %l31
  %t71 = inttoptr i64 %t70 to ptr
  %t72 = call ptr @__olang_held_alloc(ptr %t71, i64 %t69)
  %t73 = insertvalue { i64, ptr } undef, i64 %t68, 0
  %t74 = insertvalue { i64, ptr } %t73, ptr %t72, 1
  store { i64, ptr } %t74, ptr %l35, !tbaa !27
  %t75 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !27
  %t79 = load i64, ptr %l34, !tbaa !24
  %t80 = mul i64 %t79, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t76, ptr %t78, i64 %t80, i1 false)
  %t81 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t82 = getelementptr %"compiler/bindgen:record", ptr %l22, i32 0, i32 5
  %t83 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t82, i32 0, i32 0
  store { i64, ptr } %t81, ptr %t83, !tbaa !27
  %t84 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e0
  br i1 %t84, label %bb11, label %bb12
bb11:
  %t86 = getelementptr %"compiler/bindgen:record", ptr %l22, i32 0, i32 5
  %t87 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t86, i32 0, i32 0
  %t88 = load { i64, ptr }, ptr %t87, !tbaa !27
  %t89 = extractvalue { i64, ptr } %t88, 0
  %t91 = icmp eq i64 %t89, 0
  br i1 %t91, label %bb13, label %bb14
bb12:
  %t93 = call ptr @__olang_scope_hold(ptr %v0)
  %t94 = ptrtoint ptr %t93 to i64
  store i64 %t94, ptr %l39, !tbaa !24
  %t95 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t95, label %bb15, label %bb16
bb13:
  %t97 = getelementptr %"compiler/bindgen:record", ptr %l22, i32 0, i32 5
  %t98 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t97, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t98, !tbaa !27
  br label %bb14
bb14:
  %t99 = getelementptr %"compiler/bindgen:record", ptr %l22, i32 0, i32 5
  %t100 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t99, i32 0, i32 0
  %t101 = load i64, ptr %l31
  %t102 = inttoptr i64 %t101 to ptr
  %t103 = load { i64, ptr }, ptr %t100
  %t104 = extractvalue { i64, ptr } %t103, 1
  %t105 = call ptr @__olang_region_or(ptr %t104, ptr null)
  %t106 = icmp ne ptr %t105, null
  %t107 = select i1 %t106, ptr %t105, ptr null
  call void @__olang_region_settle_in(ptr %t102, ptr %t107)
  br label %bb12
bb15:
  %t108 = call ptr @__olang_region_make_part(ptr %v0)
  %t109 = ptrtoint ptr %t108 to i64
  store i64 %t109, ptr %l39, !tbaa !24
  br label %bb16
bb16:
  %t110 = getelementptr %"compiler/bindgen:record", ptr %l22, i32 0, i32 16
  %t111 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t110, i32 0, i32 0
  %t112 = load { i64, ptr }, ptr %t111, !tbaa !27
  store { i64, ptr } %t112, ptr %l41, !tbaa !27
  %t113 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t114 = extractvalue { i64, ptr } %t113, 0
  store i64 %t114, ptr %l42, !tbaa !24
  %t115 = load i64, ptr %l42, !tbaa !24
  %t116 = mul i64 %t115, 8
  %t117 = load i64, ptr %l39
  %t118 = inttoptr i64 %t117 to ptr
  %t119 = call ptr @__olang_held_alloc(ptr %t118, i64 %t116)
  %t120 = insertvalue { i64, ptr } undef, i64 %t115, 0
  %t121 = insertvalue { i64, ptr } %t120, ptr %t119, 1
  store { i64, ptr } %t121, ptr %l43, !tbaa !27
  %t122 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t123 = load ptr, ptr %t122, !tbaa !27
  %t124 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t125 = load ptr, ptr %t124, !tbaa !27
  %t126 = load i64, ptr %l42, !tbaa !24
  %t127 = mul i64 %t126, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t123, ptr %t125, i64 %t127, i1 false)
  %t128 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t129 = getelementptr %"compiler/bindgen:record", ptr %l22, i32 0, i32 16
  %t130 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t129, i32 0, i32 0
  store { i64, ptr } %t128, ptr %t130, !tbaa !27
  %t131 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t131, label %bb17, label %bb18
bb17:
  %t133 = getelementptr %"compiler/bindgen:record", ptr %l22, i32 0, i32 16
  %t134 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t133, i32 0, i32 0
  %t135 = load { i64, ptr }, ptr %t134, !tbaa !27
  %t136 = extractvalue { i64, ptr } %t135, 0
  %t138 = icmp eq i64 %t136, 0
  br i1 %t138, label %bb19, label %bb20
bb18:
  %t140 = call ptr @__olang_scope_hold(ptr %v0)
  %t141 = ptrtoint ptr %t140 to i64
  store i64 %t141, ptr %l47, !tbaa !24
  %t142 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t142, label %bb21, label %bb22
bb19:
  %t144 = getelementptr %"compiler/bindgen:record", ptr %l22, i32 0, i32 16
  %t145 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t144, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t145, !tbaa !27
  br label %bb20
bb20:
  %t146 = getelementptr %"compiler/bindgen:record", ptr %l22, i32 0, i32 16
  %t147 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t146, i32 0, i32 0
  %t148 = load i64, ptr %l39
  %t149 = inttoptr i64 %t148 to ptr
  %t150 = load { i64, ptr }, ptr %t147
  %t151 = extractvalue { i64, ptr } %t150, 1
  %t152 = call ptr @__olang_region_or(ptr %t151, ptr null)
  %t153 = icmp ne ptr %t152, null
  %t154 = select i1 %t153, ptr %t152, ptr null
  call void @__olang_region_settle_in(ptr %t149, ptr %t154)
  br label %bb18
bb21:
  %t155 = call ptr @__olang_region_make_part(ptr %v0)
  %t156 = ptrtoint ptr %t155 to i64
  store i64 %t156, ptr %l47, !tbaa !24
  br label %bb22
bb22:
  %t157 = getelementptr %"compiler/bindgen:record", ptr %l22, i32 0, i32 17
  %t158 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t157, i32 0, i32 0
  %t159 = load { i64, ptr }, ptr %t158, !tbaa !27
  store { i64, ptr } %t159, ptr %l49, !tbaa !27
  %t160 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t161 = extractvalue { i64, ptr } %t160, 0
  store i64 %t161, ptr %l50, !tbaa !24
  %t162 = load i64, ptr %l50, !tbaa !24
  %t163 = mul i64 %t162, 8
  %t164 = load i64, ptr %l47
  %t165 = inttoptr i64 %t164 to ptr
  %t166 = call ptr @__olang_held_alloc(ptr %t165, i64 %t163)
  %t167 = insertvalue { i64, ptr } undef, i64 %t162, 0
  %t168 = insertvalue { i64, ptr } %t167, ptr %t166, 1
  store { i64, ptr } %t168, ptr %l51, !tbaa !27
  %t169 = getelementptr { i64, ptr }, ptr %l51, i32 0, i32 1
  %t170 = load ptr, ptr %t169, !tbaa !27
  %t171 = getelementptr { i64, ptr }, ptr %l49, i32 0, i32 1
  %t172 = load ptr, ptr %t171, !tbaa !27
  %t173 = load i64, ptr %l50, !tbaa !24
  %t174 = mul i64 %t173, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t170, ptr %t172, i64 %t174, i1 false)
  %t175 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t176 = getelementptr %"compiler/bindgen:record", ptr %l22, i32 0, i32 17
  %t177 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t176, i32 0, i32 0
  store { i64, ptr } %t175, ptr %t177, !tbaa !27
  %t178 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t178, label %bb23, label %bb24
bb23:
  %t180 = getelementptr %"compiler/bindgen:record", ptr %l22, i32 0, i32 17
  %t181 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t180, i32 0, i32 0
  %t182 = load { i64, ptr }, ptr %t181, !tbaa !27
  %t183 = extractvalue { i64, ptr } %t182, 0
  %t185 = icmp eq i64 %t183, 0
  br i1 %t185, label %bb25, label %bb26
bb24:
  %t187 = call ptr @__olang_scope_hold(ptr %v0)
  %t188 = ptrtoint ptr %t187 to i64
  store i64 %t188, ptr %l55, !tbaa !24
  %t189 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t189, label %bb27, label %bb28
bb25:
  %t191 = getelementptr %"compiler/bindgen:record", ptr %l22, i32 0, i32 17
  %t192 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t191, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t192, !tbaa !27
  br label %bb26
bb26:
  %t193 = getelementptr %"compiler/bindgen:record", ptr %l22, i32 0, i32 17
  %t194 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t193, i32 0, i32 0
  %t195 = load i64, ptr %l47
  %t196 = inttoptr i64 %t195 to ptr
  %t197 = load { i64, ptr }, ptr %t194
  %t198 = extractvalue { i64, ptr } %t197, 1
  %t199 = call ptr @__olang_region_or(ptr %t198, ptr null)
  %t200 = icmp ne ptr %t199, null
  %t201 = select i1 %t200, ptr %t199, ptr null
  call void @__olang_region_settle_in(ptr %t196, ptr %t201)
  br label %bb24
bb27:
  %t202 = call ptr @__olang_region_make_part(ptr %v0)
  %t203 = ptrtoint ptr %t202 to i64
  store i64 %t203, ptr %l55, !tbaa !24
  br label %bb28
bb28:
  %t204 = getelementptr %"compiler/bindgen:record", ptr %l22, i32 0, i32 18
  %t205 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t204, i32 0, i32 0
  %t206 = load { i64, ptr }, ptr %t205, !tbaa !27
  store { i64, ptr } %t206, ptr %l57, !tbaa !27
  %t207 = load { i64, ptr }, ptr %l57, !tbaa !27
  %t208 = extractvalue { i64, ptr } %t207, 0
  store i64 %t208, ptr %l58, !tbaa !24
  %t209 = load i64, ptr %l58, !tbaa !24
  %t210 = mul i64 %t209, 8
  %t211 = load i64, ptr %l55
  %t212 = inttoptr i64 %t211 to ptr
  %t213 = call ptr @__olang_held_alloc(ptr %t212, i64 %t210)
  %t214 = insertvalue { i64, ptr } undef, i64 %t209, 0
  %t215 = insertvalue { i64, ptr } %t214, ptr %t213, 1
  store { i64, ptr } %t215, ptr %l59, !tbaa !27
  %t216 = getelementptr { i64, ptr }, ptr %l59, i32 0, i32 1
  %t217 = load ptr, ptr %t216, !tbaa !27
  %t218 = getelementptr { i64, ptr }, ptr %l57, i32 0, i32 1
  %t219 = load ptr, ptr %t218, !tbaa !27
  %t220 = load i64, ptr %l58, !tbaa !24
  %t221 = mul i64 %t220, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t217, ptr %t219, i64 %t221, i1 false)
  %t222 = load { i64, ptr }, ptr %l59, !tbaa !27
  %t223 = getelementptr %"compiler/bindgen:record", ptr %l22, i32 0, i32 18
  %t224 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t223, i32 0, i32 0
  store { i64, ptr } %t222, ptr %t224, !tbaa !27
  %t225 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t225, label %bb29, label %bb30
bb29:
  %t227 = getelementptr %"compiler/bindgen:record", ptr %l22, i32 0, i32 18
  %t228 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t227, i32 0, i32 0
  %t229 = load { i64, ptr }, ptr %t228, !tbaa !27
  %t230 = extractvalue { i64, ptr } %t229, 0
  %t232 = icmp eq i64 %t230, 0
  br i1 %t232, label %bb31, label %bb32
bb30:
  %t234 = call ptr @__olang_scope_hold(ptr %v0)
  %t235 = ptrtoint ptr %t234 to i64
  store i64 %t235, ptr %l63, !tbaa !24
  %t236 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t236, label %bb33, label %bb34
bb31:
  %t238 = getelementptr %"compiler/bindgen:record", ptr %l22, i32 0, i32 18
  %t239 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t238, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t239, !tbaa !27
  br label %bb32
bb32:
  %t240 = getelementptr %"compiler/bindgen:record", ptr %l22, i32 0, i32 18
  %t241 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t240, i32 0, i32 0
  %t242 = load i64, ptr %l55
  %t243 = inttoptr i64 %t242 to ptr
  %t244 = load { i64, ptr }, ptr %t241
  %t245 = extractvalue { i64, ptr } %t244, 1
  %t246 = call ptr @__olang_region_or(ptr %t245, ptr null)
  %t247 = icmp ne ptr %t246, null
  %t248 = select i1 %t247, ptr %t246, ptr null
  call void @__olang_region_settle_in(ptr %t243, ptr %t248)
  br label %bb30
bb33:
  %t249 = call ptr @__olang_region_make_part(ptr %v0)
  %t250 = ptrtoint ptr %t249 to i64
  store i64 %t250, ptr %l63, !tbaa !24
  br label %bb34
bb34:
  %t251 = getelementptr %"compiler/bindgen:record", ptr %l22, i32 0, i32 19
  %t252 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t251, i32 0, i32 0
  %t253 = load { i64, ptr }, ptr %t252, !tbaa !27
  store { i64, ptr } %t253, ptr %l65, !tbaa !27
  %t254 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t255 = extractvalue { i64, ptr } %t254, 0
  store i64 %t255, ptr %l66, !tbaa !24
  %t256 = load i64, ptr %l66, !tbaa !24
  %t257 = mul i64 %t256, 8
  %t258 = load i64, ptr %l63
  %t259 = inttoptr i64 %t258 to ptr
  %t260 = call ptr @__olang_held_alloc(ptr %t259, i64 %t257)
  %t261 = insertvalue { i64, ptr } undef, i64 %t256, 0
  %t262 = insertvalue { i64, ptr } %t261, ptr %t260, 1
  store { i64, ptr } %t262, ptr %l67, !tbaa !27
  %t263 = getelementptr { i64, ptr }, ptr %l67, i32 0, i32 1
  %t264 = load ptr, ptr %t263, !tbaa !27
  %t265 = getelementptr { i64, ptr }, ptr %l65, i32 0, i32 1
  %t266 = load ptr, ptr %t265, !tbaa !27
  %t267 = load i64, ptr %l66, !tbaa !24
  %t268 = mul i64 %t267, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t264, ptr %t266, i64 %t268, i1 false)
  %t269 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t270 = getelementptr %"compiler/bindgen:record", ptr %l22, i32 0, i32 19
  %t271 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t270, i32 0, i32 0
  store { i64, ptr } %t269, ptr %t271, !tbaa !27
  %t272 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t272, label %bb35, label %bb36
bb35:
  %t274 = getelementptr %"compiler/bindgen:record", ptr %l22, i32 0, i32 19
  %t275 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t274, i32 0, i32 0
  %t276 = load { i64, ptr }, ptr %t275, !tbaa !27
  %t277 = extractvalue { i64, ptr } %t276, 0
  %t279 = icmp eq i64 %t277, 0
  br i1 %t279, label %bb37, label %bb38
bb36:
  call void @llvm.memmove.p0.p0.i64(ptr %l3, ptr %l22, i64 312, i1 false)
  %t281 = getelementptr %"compiler/bindgen:record", ptr %l3, i32 0, i32 2
  %t282 = load i1, ptr %t281, !tbaa !21
  %t284 = xor i1 %t282, true
  br i1 %t284, label %bb39, label %bb40
bb37:
  %t286 = getelementptr %"compiler/bindgen:record", ptr %l22, i32 0, i32 19
  %t287 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t286, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t287, !tbaa !27
  br label %bb38
bb38:
  %t288 = getelementptr %"compiler/bindgen:record", ptr %l22, i32 0, i32 19
  %t289 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t288, i32 0, i32 0
  %t290 = load i64, ptr %l63
  %t291 = inttoptr i64 %t290 to ptr
  %t292 = load { i64, ptr }, ptr %t289
  %t293 = extractvalue { i64, ptr } %t292, 1
  %t294 = call ptr @__olang_region_or(ptr %t293, ptr null)
  %t295 = icmp ne ptr %t294, null
  %t296 = select i1 %t295, ptr %t294, ptr null
  call void @__olang_region_settle_in(ptr %t291, ptr %t296)
  br label %bb36
bb39:
  store i1 true, ptr %l73, !tbaa !21
  br label %bb41
bb40:
  %t297 = getelementptr %"compiler/bindgen:record", ptr %l3, i32 0, i32 1
  %t298 = load i1, ptr %t297, !tbaa !21
  store i1 %t298, ptr %l73, !tbaa !21
  br label %bb41
bb41:
  %t300 = load i1, ptr %l73, !tbaa !21
  br i1 %t300, label %bb42, label %bb43
bb42:
  store i1 true, ptr %l75, !tbaa !21
  br label %bb44
bb43:
  %t301 = getelementptr %"compiler/bindgen:record", ptr %l3, i32 0, i32 10
  %t302 = load i1, ptr %t301, !tbaa !21
  store i1 %t302, ptr %l75, !tbaa !21
  br label %bb44
bb44:
  %t304 = load i1, ptr %l75, !tbaa !21
  br i1 %t304, label %bb45, label %bb46
bb45:
  store i1 true, ptr %l77, !tbaa !21
  br label %bb48
bb46:
  %t305 = getelementptr %"compiler/bindgen:record", ptr %l3, i32 0, i32 4
  %t307 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %t305)
  store i64 %t307, ptr %l79
  br label %bb47
bb47:
  %t308 = load i64, ptr %l79, !tbaa !24
  %t309 = icmp eq i64 %t308, 0
  store i1 %t309, ptr %l77, !tbaa !21
  br label %bb48
bb48:
  %t311 = load i1, ptr %l77, !tbaa !21
  br i1 %t311, label %bb49, label %bb50
bb49:
  %t312 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l2
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t312, ptr %rv
  br label %ret
bb50:
  br label %bb51
bb51:
  %t314 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e_2ector(ptr %s0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t314, ptr %l82
  br label %bb52
bb52:
  %t315 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l82
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t315, ptr %l4
  store i64 0, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  %t316 = getelementptr %"compiler/bindgen:record", ptr %l3, i32 0, i32 4
  %t318 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %t316)
  store i64 %t318, ptr %l84
  br label %bb53
bb53:
  %t319 = load i64, ptr %l84, !tbaa !24
  store i64 %t319, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t320 = load i64, ptr %l7, !tbaa !24
  %t321 = load i64, ptr %l6, !tbaa !24
  %t324 = icmp sgt i64 %t320, %t321
  br i1 %t324, label %bb54, label %bb55
bb54:
  %t326 = load i64, ptr %l8, !tbaa !24
  %t328 = icmp sgt i64 %t326, 0
  br i1 %t328, label %bb56, label %bb57
bb55:
  store i64 0, ptr %l88, !tbaa !24
  br label %bb59
bb56:
  %t330 = load i64, ptr %l7, !tbaa !24
  %t331 = load i64, ptr %l6, !tbaa !24
  %t334 = sub i64 %t330, %t331
  %t335 = load i64, ptr %l8, !tbaa !24
  %t338 = add i64 %t334, %t335
  %t340 = sub i64 %t338, 1
  %t341 = load i64, ptr %l8, !tbaa !24
  %t344 = sdiv i64 %t340, %t341
  store i64 %t344, ptr %l91, !tbaa !24
  br label %bb58
bb57:
  store i64 0, ptr %l91, !tbaa !24
  br label %bb58
bb58:
  %t346 = load i64, ptr %l91, !tbaa !24
  store i64 %t346, ptr %l88, !tbaa !24
  br label %bb59
bb59:
  %t347 = load i64, ptr %l88, !tbaa !24
  store i64 %t347, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb60
bb60:
  store %olang.scope zeroinitializer, ptr %s3
  %t348 = load i64, ptr %l10, !tbaa !24
  %t349 = load i64, ptr %l9, !tbaa !24
  %t352 = icmp slt i64 %t348, %t349
  %t354 = xor i1 %t352, true
  br i1 %t354, label %bb61, label %bb62
bb61:
  call void @__olang_scope_close(ptr %s3)
  br label %bb147
bb62:
  br label %bb63
bb63:
  %t356 = load i64, ptr %l6, !tbaa !24
  %t357 = load i64, ptr %l10, !tbaa !24
  %t358 = load i64, ptr %l8, !tbaa !24
  %t361 = mul i64 %t357, %t358
  %t364 = add i64 %t356, %t361
  store i64 %t364, ptr %l11, !tbaa !24
  %t366 = getelementptr %"compiler/bindgen:record", ptr %l3, i32 0, i32 4
  %t367 = load i64, ptr %l11, !tbaa !24
  %t370 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %t366, i64 %t367)
  store { i64, ptr } %t370, ptr %l111
  br label %bb64
bb64:
  %t371 = load { i64, ptr }, ptr %l111, !tbaa !27
  %t372 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s3, { i64, ptr } %t371, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d146, i32 0, i32 1) })
  store i1 %t372, ptr %l112
  br label %bb65
bb65:
  %t373 = load i1, ptr %l112, !tbaa !21
  br i1 %t373, label %bb66, label %bb67
bb66:
  %t374 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t374, ptr %l113
  br label %bb68
bb67:
  br label %bb69
bb68:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t375 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l113
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t375, ptr %rv
  br label %ret
bb69:
  %t376 = load ptr, ptr %l0, !tbaa !29
  store ptr %t376, ptr %l114, !tbaa !29
  %t377 = getelementptr %"compiler/bindgen:record", ptr %l3, i32 0, i32 5
  %t378 = load i64, ptr %l11, !tbaa !24
  %t381 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %t377, i64 %t378)
  store { i64, ptr } %t381, ptr %l117
  br label %bb70
bb70:
  %t382 = load ptr, ptr %l114, !tbaa !29
  %t383 = load { i64, ptr }, ptr %l117, !tbaa !27
  %t384 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eparseType(ptr %v0, ptr %v0, ptr %t382, { i64, ptr } %t383, i64 0)
  store i64 %t384, ptr %l118
  br label %bb71
bb71:
  %t385 = load i64, ptr %l118, !tbaa !24
  %t386 = load ptr, ptr %l0, !tbaa !29
  %t388 = getelementptr %"compiler/bindgen:gen", ptr %t386, i32 0, i32 17
  %t392 = call %"compiler/bindgen:ctype" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3actype_3e_2eAt_3ccompiler_2fbindgen_3actype_3e(ptr %v0, ptr %v0, ptr %t388, i64 %t385)
  store %"compiler/bindgen:ctype" %t392, ptr %l122
  br label %bb72
bb72:
  %t393 = load %"compiler/bindgen:ctype", ptr %l122
  store %"compiler/bindgen:ctype" %t393, ptr %l13
  %t394 = getelementptr %"compiler/bindgen:record", ptr %l3, i32 0, i32 16
  %t395 = load i64, ptr %l11, !tbaa !24
  %t398 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t394, i64 %t395)
  store i64 %t398, ptr %l125
  br label %bb73
bb73:
  %t399 = load i64, ptr %l125, !tbaa !24
  store i64 %t399, ptr %l14, !tbaa !24
  %t400 = load ptr, ptr %l0, !tbaa !29
  store ptr %t400, ptr %l126, !tbaa !29
  %t401 = getelementptr %"compiler/bindgen:record", ptr %l3, i32 0, i32 4
  %t402 = load i64, ptr %l11, !tbaa !24
  %t405 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %t401, i64 %t402)
  store { i64, ptr } %t405, ptr %l129
  br label %bb74
bb74:
  %t406 = load i64, ptr %l11, !tbaa !24
  %t407 = load ptr, ptr %l126, !tbaa !29
  %t408 = load { i64, ptr }, ptr %l129, !tbaa !27
  %t411 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eparamName(ptr %v0, ptr %v0, ptr %s0, ptr %s0, ptr %t407, { i64, ptr } %t408, i64 %t406, ptr %l4)
  store { i64, ptr } %t411, ptr %l132
  br label %bb75
bb75:
  %t412 = load { i64, ptr }, ptr %l132, !tbaa !27
  store { i64, ptr } %t412, ptr %l15, !tbaa !27
  %t413 = load i64, ptr %l14, !tbaa !24
  %t415 = icmp sge i64 %t413, 0
  br i1 %t415, label %bb76, label %bb77
bb76:
  store %olang.scope zeroinitializer, ptr %s5
  %t417 = load i64, ptr %l14, !tbaa !24
  %t419 = icmp eq i64 %t417, 0
  br i1 %t419, label %bb78, label %bb79
bb77:
  br label %bb93
bb78:
  store i1 true, ptr %l137, !tbaa !21
  br label %bb80
bb79:
  %t421 = getelementptr %"compiler/bindgen:ctype", ptr %l13, i32 0, i32 0
  %t422 = load i32, ptr %t421, !range !{i32 0, i32 7}
  %t424 = trunc i64 1 to i32
  %t425 = icmp eq i32 %t422, %t424
  %t427 = xor i1 %t425, true
  store i1 %t427, ptr %l137, !tbaa !21
  br label %bb80
bb80:
  %t429 = load i1, ptr %l137, !tbaa !21
  br i1 %t429, label %bb81, label %bb82
bb81:
  store i1 true, ptr %l141, !tbaa !21
  br label %bb84
bb82:
  %t430 = getelementptr %"compiler/bindgen:ctype", ptr %l13, i32 0, i32 1
  %t431 = load { i64, ptr }, ptr %t430, !tbaa !27
  %t433 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s5, { i64, ptr } %t431, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d147, i32 0, i32 1) })
  store i1 %t433, ptr %l143
  br label %bb83
bb83:
  %t434 = load i1, ptr %l143, !tbaa !21
  store i1 %t434, ptr %l141, !tbaa !21
  br label %bb84
bb84:
  %t435 = load i1, ptr %l141, !tbaa !21
  br i1 %t435, label %bb85, label %bb86
bb85:
  %t436 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t436, ptr %l144
  br label %bb87
bb86:
  br label %bb88
bb87:
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t437 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l144
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t437, ptr %rv
  br label %ret
bb88:
  store ptr %l2, ptr %l145, !tbaa !29
  %t438 = call ptr @__olang_scope_hold(ptr %v1)
  %t439 = ptrtoint ptr %t438 to i64
  store i64 %t439, ptr %l146, !tbaa !24
  %t440 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t440, label %bb89, label %bb90
bb89:
  %t442 = call ptr @__olang_region_make(ptr %v1)
  %t443 = ptrtoint ptr %t442 to i64
  store i64 %t443, ptr %l146, !tbaa !24
  br label %bb90
bb90:
  %t444 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t444, ptr %l148, !tbaa !27
  %t445 = getelementptr %"compiler/bindgen:ctype", ptr %l13, i32 0, i32 1
  %t446 = load { i64, ptr }, ptr %t445, !tbaa !27
  %t447 = load i64, ptr %l14, !tbaa !24
  %t450 = call { i64, ptr } @compiler_2fbindgen_2ebitfieldType(ptr %v0, ptr %s5, { i64, ptr } %t446, i64 %t447)
  store { i64, ptr } %t450, ptr %l151
  br label %bb91
bb91:
  %t451 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d148, i32 0, i32 1) }, 1
  %t452 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d148, i32 0, i32 1) }, 0
  %t453 = load { i64, ptr }, ptr %l148, !tbaa !27
  %t454 = extractvalue { i64, ptr } %t453, 1
  %t455 = extractvalue { i64, ptr } %t453, 0
  %t456 = add i64 %t452, %t455
  %t457 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d149, i32 0, i32 1) }, 1
  %t458 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d149, i32 0, i32 1) }, 0
  %t459 = add i64 %t456, %t458
  %t460 = load { i64, ptr }, ptr %l151, !tbaa !27
  %t461 = extractvalue { i64, ptr } %t460, 1
  %t462 = extractvalue { i64, ptr } %t460, 0
  %t463 = add i64 %t459, %t462
  %t464 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d150, i32 0, i32 1) }, 1
  %t465 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d150, i32 0, i32 1) }, 0
  %t466 = add i64 %t463, %t465
  %t467 = load i64, ptr %l146
  %t468 = inttoptr i64 %t467 to ptr
  %t469 = call ptr @__olang_held_alloc(ptr %t468, i64 %t466)
  call void @olang_textcopy(ptr %t469, ptr %t451, i64 %t452)
  %t470 = getelementptr i8, ptr %t469, i64 %t452
  call void @olang_textcopy(ptr %t470, ptr %t454, i64 %t455)
  %t471 = getelementptr i8, ptr %t470, i64 %t455
  call void @olang_textcopy(ptr %t471, ptr %t457, i64 %t458)
  %t472 = getelementptr i8, ptr %t471, i64 %t458
  call void @olang_textcopy(ptr %t472, ptr %t461, i64 %t462)
  %t473 = getelementptr i8, ptr %t472, i64 %t462
  call void @olang_textcopy(ptr %t473, ptr %t464, i64 %t465)
  %t474 = insertvalue { i64, ptr } undef, i64 %t466, 0
  %t475 = insertvalue { i64, ptr } %t474, ptr %t469, 1
  %t477 = load ptr, ptr %l145, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %t477, { i64, ptr } %t475)
  br label %bb92
bb92:
  %t479 = load i64, ptr %l5, !tbaa !24
  %t481 = load i64, ptr %l14, !tbaa !24
  %t484 = add i64 %t479, %t481
  store i64 %t484, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s3)
  br label %bb146
bb93:
  %t486 = load i64, ptr %l5, !tbaa !24
  %t488 = srem i64 %t486, 8
  %t490 = icmp ne i64 %t488, 0
  br i1 %t490, label %bb94, label %bb95
bb94:
  %t492 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t492, ptr %l161
  br label %bb96
bb95:
  br label %bb97
bb96:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t493 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l161
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t493, ptr %rv
  br label %ret
bb97:
  %t494 = getelementptr %"compiler/bindgen:ctype", ptr %l13, i32 0, i32 0
  %t495 = load i32, ptr %t494, !range !{i32 0, i32 7}
  %t497 = trunc i64 4 to i32
  %t498 = icmp eq i32 %t495, %t497
  br i1 %t498, label %bb98, label %bb99
bb98:
  store %olang.scope zeroinitializer, ptr %s9
  %t500 = load ptr, ptr %l0, !tbaa !29
  %t502 = getelementptr %"compiler/bindgen:gen", ptr %t500, i32 0, i32 17
  %t503 = getelementptr %"compiler/bindgen:ctype", ptr %l13, i32 0, i32 2
  %t504 = load i64, ptr %t503, !tbaa !24
  %t507 = call %"compiler/bindgen:ctype" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3actype_3e_2eAt_3ccompiler_2fbindgen_3actype_3e(ptr %v0, ptr %v0, ptr %t502, i64 %t504)
  store %"compiler/bindgen:ctype" %t507, ptr %l167
  br label %bb100
bb99:
  br label %bb125
bb100:
  %t508 = load %"compiler/bindgen:ctype", ptr %l167
  store %"compiler/bindgen:ctype" %t508, ptr %l16
  %t509 = getelementptr %"compiler/bindgen:ctype", ptr %l16, i32 0, i32 0
  %t510 = load i32, ptr %t509, !range !{i32 0, i32 7}
  %t512 = trunc i64 1 to i32
  %t513 = icmp eq i32 %t510, %t512
  %t515 = xor i1 %t513, true
  br i1 %t515, label %bb101, label %bb102
bb101:
  store i1 true, ptr %l171, !tbaa !21
  br label %bb104
bb102:
  %t517 = getelementptr %"compiler/bindgen:ctype", ptr %l16, i32 0, i32 1
  %t518 = load { i64, ptr }, ptr %t517, !tbaa !27
  %t520 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s9, { i64, ptr } %t518, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d151, i32 0, i32 1) })
  store i1 %t520, ptr %l173
  br label %bb103
bb103:
  %t521 = load i1, ptr %l173, !tbaa !21
  store i1 %t521, ptr %l171, !tbaa !21
  br label %bb104
bb104:
  %t522 = load i1, ptr %l171, !tbaa !21
  br i1 %t522, label %bb105, label %bb106
bb105:
  store i1 true, ptr %l174, !tbaa !21
  br label %bb108
bb106:
  %t523 = getelementptr %"compiler/bindgen:ctype", ptr %l16, i32 0, i32 1
  %t524 = load { i64, ptr }, ptr %t523, !tbaa !27
  %t526 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s9, { i64, ptr } %t524, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d152, i32 0, i32 1) })
  store i1 %t526, ptr %l176
  br label %bb107
bb107:
  %t527 = load i1, ptr %l176, !tbaa !21
  store i1 %t527, ptr %l174, !tbaa !21
  br label %bb108
bb108:
  %t528 = load i1, ptr %l174, !tbaa !21
  br i1 %t528, label %bb109, label %bb110
bb109:
  store i1 true, ptr %l177, !tbaa !21
  br label %bb112
bb110:
  %t529 = getelementptr %"compiler/bindgen:ctype", ptr %l16, i32 0, i32 1
  %t530 = load { i64, ptr }, ptr %t529, !tbaa !27
  %t532 = call i64 @compiler_2fbindgen_2enumBits(ptr %v0, { i64, ptr } %t530)
  store i64 %t532, ptr %l179
  br label %bb111
bb111:
  %t533 = load i64, ptr %l179, !tbaa !24
  %t534 = icmp eq i64 %t533, 0
  store i1 %t534, ptr %l177, !tbaa !21
  br label %bb112
bb112:
  %t536 = load i1, ptr %l177, !tbaa !21
  br i1 %t536, label %bb113, label %bb114
bb113:
  %t537 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t537, ptr %l181
  br label %bb115
bb114:
  br label %bb116
bb115:
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t538 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l181
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t538, ptr %rv
  br label %ret
bb116:
  store ptr %l2, ptr %l182, !tbaa !29
  %t539 = call ptr @__olang_scope_hold(ptr %v1)
  %t540 = ptrtoint ptr %t539 to i64
  store i64 %t540, ptr %l183, !tbaa !24
  %t541 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t541, label %bb117, label %bb118
bb117:
  %t543 = call ptr @__olang_region_make(ptr %v1)
  %t544 = ptrtoint ptr %t543 to i64
  store i64 %t544, ptr %l183, !tbaa !24
  br label %bb118
bb118:
  %t545 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t545, ptr %l185, !tbaa !27
  %t546 = getelementptr %"compiler/bindgen:ctype", ptr %l16, i32 0, i32 1
  %t547 = load { i64, ptr }, ptr %t546, !tbaa !27
  %t549 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s9, { i64, ptr } %t547, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d153, i32 0, i32 1) })
  store i1 %t549, ptr %l187
  br label %bb119
bb119:
  %t550 = load i1, ptr %l187, !tbaa !21
  br i1 %t550, label %bb120, label %bb121
bb120:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d154, i32 0, i32 1) }, ptr %l188, !tbaa !27
  br label %bb122
bb121:
  %t551 = getelementptr %"compiler/bindgen:ctype", ptr %l16, i32 0, i32 1
  %t552 = load { i64, ptr }, ptr %t551, !tbaa !27
  store { i64, ptr } %t552, ptr %l188, !tbaa !27
  br label %bb122
bb122:
  %t554 = getelementptr %"compiler/bindgen:ctype", ptr %l13, i32 0, i32 4
  %t555 = load i64, ptr %t554, !tbaa !24
  %t556 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d155, i32 0, i32 1) }, 1
  %t557 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d155, i32 0, i32 1) }, 0
  %t558 = load { i64, ptr }, ptr %l185, !tbaa !27
  %t559 = extractvalue { i64, ptr } %t558, 1
  %t560 = extractvalue { i64, ptr } %t558, 0
  %t561 = add i64 %t557, %t560
  %t562 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d156, i32 0, i32 1) }, 1
  %t563 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d156, i32 0, i32 1) }, 0
  %t564 = add i64 %t561, %t563
  %t565 = load { i64, ptr }, ptr %l188, !tbaa !27
  %t566 = extractvalue { i64, ptr } %t565, 1
  %t567 = extractvalue { i64, ptr } %t565, 0
  %t568 = add i64 %t564, %t567
  %t569 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d157, i32 0, i32 1) }, 1
  %t570 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d157, i32 0, i32 1) }, 0
  %t571 = add i64 %t568, %t570
  %t573 = call i64 @__olang_fmt_i64(ptr null, i64 %t555)
  %t574 = add i64 %t571, %t573
  %t575 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d158, i32 0, i32 1) }, 1
  %t576 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d158, i32 0, i32 1) }, 0
  %t577 = add i64 %t574, %t576
  %t578 = load i64, ptr %l183
  %t579 = inttoptr i64 %t578 to ptr
  %t580 = call ptr @__olang_held_alloc(ptr %t579, i64 %t577)
  call void @olang_textcopy(ptr %t580, ptr %t556, i64 %t557)
  %t581 = getelementptr i8, ptr %t580, i64 %t557
  call void @olang_textcopy(ptr %t581, ptr %t559, i64 %t560)
  %t582 = getelementptr i8, ptr %t581, i64 %t560
  call void @olang_textcopy(ptr %t582, ptr %t562, i64 %t563)
  %t583 = getelementptr i8, ptr %t582, i64 %t563
  call void @olang_textcopy(ptr %t583, ptr %t566, i64 %t567)
  %t584 = getelementptr i8, ptr %t583, i64 %t567
  call void @olang_textcopy(ptr %t584, ptr %t569, i64 %t570)
  %t585 = getelementptr i8, ptr %t584, i64 %t570
  %t586 = call i64 @__olang_fmt_i64(ptr %t585, i64 %t555)
  %t587 = getelementptr i8, ptr %t585, i64 %t573
  call void @olang_textcopy(ptr %t587, ptr %t575, i64 %t576)
  %t588 = insertvalue { i64, ptr } undef, i64 %t577, 0
  %t589 = insertvalue { i64, ptr } %t588, ptr %t580, 1
  %t591 = load ptr, ptr %l182, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %t591, { i64, ptr } %t589)
  br label %bb123
bb123:
  %t593 = load i64, ptr %l5, !tbaa !24
  store i64 %t593, ptr %l193, !tbaa !24
  %t594 = getelementptr %"compiler/bindgen:ctype", ptr %l16, i32 0, i32 1
  %t595 = load { i64, ptr }, ptr %t594, !tbaa !27
  %t597 = call i64 @compiler_2fbindgen_2enumBits(ptr %v0, { i64, ptr } %t595)
  store i64 %t597, ptr %l195
  br label %bb124
bb124:
  %t598 = getelementptr %"compiler/bindgen:ctype", ptr %l13, i32 0, i32 4
  %t599 = load i64, ptr %t598, !tbaa !24
  %t600 = load i64, ptr %l195, !tbaa !24
  %t602 = mul i64 %t600, %t599
  %t603 = load i64, ptr %l193, !tbaa !24
  %t605 = add i64 %t603, %t602
  store i64 %t605, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s3)
  br label %bb146
bb125:
  %t607 = getelementptr %"compiler/bindgen:ctype", ptr %l13, i32 0, i32 0
  %t608 = load i32, ptr %t607, !range !{i32 0, i32 7}
  %t610 = trunc i64 1 to i32
  %t611 = icmp eq i32 %t608, %t610
  %t613 = xor i1 %t611, true
  br i1 %t613, label %bb126, label %bb127
bb126:
  store i1 true, ptr %l202, !tbaa !21
  br label %bb129
bb127:
  %t615 = getelementptr %"compiler/bindgen:ctype", ptr %l13, i32 0, i32 1
  %t616 = load { i64, ptr }, ptr %t615, !tbaa !27
  %t618 = call i64 @compiler_2fbindgen_2enumBits(ptr %v0, { i64, ptr } %t616)
  store i64 %t618, ptr %l204
  br label %bb128
bb128:
  %t619 = load i64, ptr %l204, !tbaa !24
  %t620 = icmp eq i64 %t619, 0
  store i1 %t620, ptr %l202, !tbaa !21
  br label %bb129
bb129:
  %t622 = load i1, ptr %l202, !tbaa !21
  br i1 %t622, label %bb130, label %bb131
bb130:
  store i1 true, ptr %l206, !tbaa !21
  br label %bb133
bb131:
  %t623 = getelementptr %"compiler/bindgen:ctype", ptr %l13, i32 0, i32 1
  %t624 = load { i64, ptr }, ptr %t623, !tbaa !27
  %t626 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s3, { i64, ptr } %t624, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d159, i32 0, i32 1) })
  store i1 %t626, ptr %l208
  br label %bb132
bb132:
  %t627 = load i1, ptr %l208, !tbaa !21
  store i1 %t627, ptr %l206, !tbaa !21
  br label %bb133
bb133:
  %t628 = load i1, ptr %l206, !tbaa !21
  br i1 %t628, label %bb134, label %bb135
bb134:
  %t629 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t629, ptr %l209
  br label %bb136
bb135:
  br label %bb137
bb136:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t630 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l209
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t630, ptr %rv
  br label %ret
bb137:
  store ptr %l2, ptr %l210, !tbaa !29
  %t631 = call ptr @__olang_scope_hold(ptr %v1)
  %t632 = ptrtoint ptr %t631 to i64
  store i64 %t632, ptr %l211, !tbaa !24
  %t633 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t633, label %bb138, label %bb139
bb138:
  %t635 = call ptr @__olang_region_make(ptr %v1)
  %t636 = ptrtoint ptr %t635 to i64
  store i64 %t636, ptr %l211, !tbaa !24
  br label %bb139
bb139:
  %t637 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t637, ptr %l213, !tbaa !27
  %t638 = getelementptr %"compiler/bindgen:ctype", ptr %l13, i32 0, i32 1
  %t639 = load { i64, ptr }, ptr %t638, !tbaa !27
  %t641 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s3, { i64, ptr } %t639, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d160, i32 0, i32 1) })
  store i1 %t641, ptr %l215
  br label %bb140
bb140:
  %t642 = load i1, ptr %l215, !tbaa !21
  br i1 %t642, label %bb141, label %bb142
bb141:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d161, i32 0, i32 1) }, ptr %l216, !tbaa !27
  br label %bb143
bb142:
  %t643 = getelementptr %"compiler/bindgen:ctype", ptr %l13, i32 0, i32 1
  %t644 = load { i64, ptr }, ptr %t643, !tbaa !27
  store { i64, ptr } %t644, ptr %l216, !tbaa !27
  br label %bb143
bb143:
  %t646 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d162, i32 0, i32 1) }, 1
  %t647 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d162, i32 0, i32 1) }, 0
  %t648 = load { i64, ptr }, ptr %l213, !tbaa !27
  %t649 = extractvalue { i64, ptr } %t648, 1
  %t650 = extractvalue { i64, ptr } %t648, 0
  %t651 = add i64 %t647, %t650
  %t652 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d163, i32 0, i32 1) }, 1
  %t653 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d163, i32 0, i32 1) }, 0
  %t654 = add i64 %t651, %t653
  %t655 = load { i64, ptr }, ptr %l216, !tbaa !27
  %t656 = extractvalue { i64, ptr } %t655, 1
  %t657 = extractvalue { i64, ptr } %t655, 0
  %t658 = add i64 %t654, %t657
  %t659 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d164, i32 0, i32 1) }, 1
  %t660 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d164, i32 0, i32 1) }, 0
  %t661 = add i64 %t658, %t660
  %t662 = load i64, ptr %l211
  %t663 = inttoptr i64 %t662 to ptr
  %t664 = call ptr @__olang_held_alloc(ptr %t663, i64 %t661)
  call void @olang_textcopy(ptr %t664, ptr %t646, i64 %t647)
  %t665 = getelementptr i8, ptr %t664, i64 %t647
  call void @olang_textcopy(ptr %t665, ptr %t649, i64 %t650)
  %t666 = getelementptr i8, ptr %t665, i64 %t650
  call void @olang_textcopy(ptr %t666, ptr %t652, i64 %t653)
  %t667 = getelementptr i8, ptr %t666, i64 %t653
  call void @olang_textcopy(ptr %t667, ptr %t656, i64 %t657)
  %t668 = getelementptr i8, ptr %t667, i64 %t657
  call void @olang_textcopy(ptr %t668, ptr %t659, i64 %t660)
  %t669 = insertvalue { i64, ptr } undef, i64 %t661, 0
  %t670 = insertvalue { i64, ptr } %t669, ptr %t664, 1
  %t672 = load ptr, ptr %l210, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %t672, { i64, ptr } %t670)
  br label %bb144
bb144:
  %t674 = load i64, ptr %l5, !tbaa !24
  store i64 %t674, ptr %l220, !tbaa !24
  %t675 = getelementptr %"compiler/bindgen:ctype", ptr %l13, i32 0, i32 1
  %t676 = load { i64, ptr }, ptr %t675, !tbaa !27
  %t678 = call i64 @compiler_2fbindgen_2enumBits(ptr %v0, { i64, ptr } %t676)
  store i64 %t678, ptr %l222
  br label %bb145
bb145:
  %t679 = load i64, ptr %l220, !tbaa !24
  %t680 = load i64, ptr %l222, !tbaa !24
  %t681 = add i64 %t679, %t680
  store i64 %t681, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb146
bb146:
  %t683 = load i64, ptr %l10, !tbaa !24
  %t686 = add i64 %t683, 1
  store i64 %t686, ptr %l10, !tbaa !24
  br label %bb60
bb147:
  %t688 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l2
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t688, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local i1 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2epackedFloat(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l5 = alloca %"compiler/bindgen:ctype"
  %l9 = alloca %"compiler/bindgen:record"
  %l11 = alloca %"compiler/bindgen:record"
  %l13 = alloca i64
  %l15 = alloca i64
  %l20 = alloca { i64, ptr }
  %l22 = alloca ptr
  %l25 = alloca i64
  %l26 = alloca %"compiler/bindgen:ctype"
  %l29 = alloca i1
  %l31 = alloca i1
  %l32 = alloca i1
  %l34 = alloca i1
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca i1
  %t5 = alloca %"compiler/bindgen:record", align 8
  %t8 = alloca %"compiler/bindgen:record", align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s1
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/bindgen:gen", ptr %t1, i32 0, i32 6
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eAt_3ccompiler_2fbindgen_3arecord_3e(ptr %t5, ptr %v0, ptr %v0, ptr %t3, i64 %a1)
  call void @llvm.memmove.p0.p0.i64(ptr %l9, ptr %t5, i64 312, i1 false)
  br label %bb1
bb1:
  call void @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2fbindgen_3arecord(ptr %t8, ptr %v0, ptr %l9)
  call void @llvm.memmove.p0.p0.i64(ptr %l11, ptr %t8, i64 312, i1 false)
  br label %bb2
bb2:
  %t10 = getelementptr %"compiler/bindgen:record", ptr %l11, i32 0, i32 5
  store ptr %t10, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb3
bb3:
  store %olang.scope zeroinitializer, ptr %s2
  %t12 = load i64, ptr %l3, !tbaa !24
  store i64 %t12, ptr %l13, !tbaa !24
  %t13 = load ptr, ptr %l2, !tbaa !29
  %t15 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s1, ptr %t13)
  store i64 %t15, ptr %l15
  br label %bb4
bb4:
  %t16 = load i64, ptr %l13, !tbaa !24
  %t17 = load i64, ptr %l15, !tbaa !24
  %t18 = icmp slt i64 %t16, %t17
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s2)
  br label %bb23
bb6:
  br label %bb7
bb7:
  %t22 = load ptr, ptr %l2, !tbaa !29
  %t23 = load i64, ptr %l3, !tbaa !24
  %t26 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s1, ptr %s1, ptr %t22, i64 %t23)
  store { i64, ptr } %t26, ptr %l20
  br label %bb8
bb8:
  %t27 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/bindgen:gen", ptr %t28, i32 0, i32 17
  store ptr %t30, ptr %l22, !tbaa !29
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t35 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eparseType(ptr %v0, ptr %s1, ptr %t31, { i64, ptr } %t27, i64 0)
  store i64 %t35, ptr %l25
  br label %bb9
bb9:
  %t36 = load ptr, ptr %l22, !tbaa !29
  %t37 = load i64, ptr %l25, !tbaa !24
  %t38 = call %"compiler/bindgen:ctype" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3actype_3e_2eAt_3ccompiler_2fbindgen_3actype_3e(ptr %v0, ptr %v0, ptr %t36, i64 %t37)
  store %"compiler/bindgen:ctype" %t38, ptr %l26
  br label %bb10
bb10:
  %t39 = load %"compiler/bindgen:ctype", ptr %l26
  store %"compiler/bindgen:ctype" %t39, ptr %l5
  %t40 = getelementptr %"compiler/bindgen:ctype", ptr %l5, i32 0, i32 0
  %t41 = load i32, ptr %t40, !range !{i32 0, i32 7}
  %t43 = trunc i64 1 to i32
  %t44 = icmp eq i32 %t41, %t43
  br i1 %t44, label %bb11, label %bb12
bb11:
  %t46 = getelementptr %"compiler/bindgen:ctype", ptr %l5, i32 0, i32 1
  %t47 = load { i64, ptr }, ptr %t46, !tbaa !27
  %t49 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s2, { i64, ptr } %t47, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d165, i32 0, i32 1) })
  store i1 %t49, ptr %l31
  br label %bb13
bb12:
  store i1 false, ptr %l29, !tbaa !21
  br label %bb18
bb13:
  %t50 = load i1, ptr %l31, !tbaa !21
  br i1 %t50, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l32, !tbaa !21
  br label %bb17
bb15:
  %t51 = getelementptr %"compiler/bindgen:ctype", ptr %l5, i32 0, i32 1
  %t52 = load { i64, ptr }, ptr %t51, !tbaa !27
  %t54 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s2, { i64, ptr } %t52, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d166, i32 0, i32 1) })
  store i1 %t54, ptr %l34
  br label %bb16
bb16:
  %t55 = load i1, ptr %l34, !tbaa !21
  store i1 %t55, ptr %l32, !tbaa !21
  br label %bb17
bb17:
  %t56 = load i1, ptr %l32, !tbaa !21
  store i1 %t56, ptr %l29, !tbaa !21
  br label %bb18
bb18:
  %t57 = load i1, ptr %l29, !tbaa !21
  br i1 %t57, label %bb19, label %bb20
bb19:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s1)
  store i1 true, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s2)
  br label %bb22
bb22:
  %t59 = load i64, ptr %l3, !tbaa !24
  %t62 = add i64 %t59, 1
  store i64 %t62, ptr %l3, !tbaa !24
  br label %bb3
bb23:
  call void @__olang_scope_close(ptr %s1)
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eparamType(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca %"compiler/bindgen:ctype"
  %l3 = alloca i64
  %l7 = alloca %"compiler/bindgen:ctype"
  %l12 = alloca i64
  %l16 = alloca %"compiler/bindgen:record"
  %l18 = alloca i1
  %l22 = alloca %"compiler/bindgen:record"
  %l24 = alloca i64
  %l26 = alloca { i64, ptr }
  %l27 = alloca ptr
  %l28 = alloca ptr
  %l32 = alloca %"compiler/bindgen:record"
  %l34 = alloca %"compiler/bindgen:record"
  %l36 = alloca { i64, ptr }
  %l37 = alloca i64
  %l38 = alloca { i64, ptr }
  %l39 = alloca i32
  %l43 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l48 = alloca i32
  %l52 = alloca { i64, ptr }
  %l55 = alloca { i64, ptr }
  %l56 = alloca i32
  %l58 = alloca { i64, ptr }
  %l61 = alloca { i64, ptr }
  %l62 = alloca i32
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  %t26 = alloca %"compiler/bindgen:record", align 8
  %t36 = alloca %"compiler/bindgen:record", align 8
  %t52 = alloca %"compiler/bindgen:record", align 8
  %t55 = alloca %"compiler/bindgen:record", align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/bindgen:gen", ptr %t1, i32 0, i32 17
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call %"compiler/bindgen:ctype" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3actype_3e_2eAt_3ccompiler_2fbindgen_3actype_3e(ptr %v0, ptr %v0, ptr %t3, i64 %t4)
  store %"compiler/bindgen:ctype" %t7, ptr %l7
  br label %bb1
bb1:
  %t8 = load %"compiler/bindgen:ctype", ptr %l7
  store %"compiler/bindgen:ctype" %t8, ptr %l2
  %t9 = getelementptr %"compiler/bindgen:ctype", ptr %l2, i32 0, i32 0
  %t10 = load i32, ptr %t9, !range !{i32 0, i32 7}
  %t12 = trunc i64 2 to i32
  %t13 = icmp eq i32 %t10, %t12
  br i1 %t13, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/bindgen:ctype", ptr %l2, i32 0, i32 1
  %t17 = load { i64, ptr }, ptr %t16, !tbaa !27
  %t20 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2erecordAt(ptr %v0, ptr %v0, ptr %t15, { i64, ptr } %t17)
  store i64 %t20, ptr %l12
  br label %bb4
bb3:
  br label %bb21
bb4:
  %t21 = load i64, ptr %l12, !tbaa !24
  store i64 %t21, ptr %l3, !tbaa !24
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/bindgen:gen", ptr %t22, i32 0, i32 6
  %t25 = load i64, ptr %l3, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eAt_3ccompiler_2fbindgen_3arecord_3e(ptr %t26, ptr %v0, ptr %s1, ptr %t24, i64 %t25)
  call void @llvm.memmove.p0.p0.i64(ptr %l16, ptr %t26, i64 312, i1 false)
  br label %bb5
bb5:
  %t29 = getelementptr %"compiler/bindgen:record", ptr %l16, i32 0, i32 12
  %t30 = load i1, ptr %t29, !tbaa !21
  br i1 %t30, label %bb6, label %bb7
bb6:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/bindgen:gen", ptr %t32, i32 0, i32 6
  %t35 = load i64, ptr %l3, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eAt_3ccompiler_2fbindgen_3arecord_3e(ptr %t36, ptr %v0, ptr %v0, ptr %t34, i64 %t35)
  call void @llvm.memmove.p0.p0.i64(ptr %l22, ptr %t36, i64 312, i1 false)
  br label %bb8
bb7:
  store i1 false, ptr %l18, !tbaa !21
  br label %bb10
bb8:
  %t39 = getelementptr %"compiler/bindgen:record", ptr %l22, i32 0, i32 5
  %t41 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %t39)
  store i64 %t41, ptr %l24
  br label %bb9
bb9:
  %t42 = load i64, ptr %l24, !tbaa !24
  %t43 = icmp sgt i64 %t42, 0
  store i1 %t43, ptr %l18, !tbaa !21
  br label %bb10
bb10:
  %t45 = load i1, ptr %l18, !tbaa !21
  br i1 %t45, label %bb11, label %bb12
bb11:
  store %olang.scope zeroinitializer, ptr %s2
  %t46 = load ptr, ptr %l0, !tbaa !29
  store ptr %t46, ptr %l27, !tbaa !29
  %t47 = load ptr, ptr %l0, !tbaa !29
  store ptr %t47, ptr %l28, !tbaa !29
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/bindgen:gen", ptr %t48, i32 0, i32 6
  %t51 = load i64, ptr %l3, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eAt_3ccompiler_2fbindgen_3arecord_3e(ptr %t52, ptr %v0, ptr %v0, ptr %t50, i64 %t51)
  call void @llvm.memmove.p0.p0.i64(ptr %l32, ptr %t52, i64 312, i1 false)
  br label %bb13
bb12:
  br label %bb20
bb13:
  call void @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2fbindgen_3arecord(ptr %t55, ptr %s2, ptr %l32)
  call void @llvm.memmove.p0.p0.i64(ptr %l34, ptr %t55, i64 312, i1 false)
  br label %bb14
bb14:
  %t57 = getelementptr %"compiler/bindgen:record", ptr %l34, i32 0, i32 5
  %t59 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %s2, ptr %t57, i64 0)
  store { i64, ptr } %t59, ptr %l36
  br label %bb15
bb15:
  %t60 = load ptr, ptr %l28, !tbaa !29
  %t61 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t62 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eparseType(ptr %v0, ptr %s2, ptr %t60, { i64, ptr } %t61, i64 0)
  store i64 %t62, ptr %l37
  br label %bb16
bb16:
  %t63 = load ptr, ptr %l27, !tbaa !29
  %t64 = load i64, ptr %l37, !tbaa !24
  %t65 = call { i32, { i64, ptr } } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eparamType(ptr %v0, ptr %v1, ptr %t63, i64 %t64)
  %t66 = extractvalue { i32, { i64, ptr } } %t65, 1
  %t67 = extractvalue { i32, { i64, ptr } } %t65, 0
  store i32 %t67, ptr %l39
  %t68 = icmp ne i32 %t67, 0
  br i1 %t68, label %bb18, label %ok.69, !prof !99
ok.69:
  store { i64, ptr } %t66, ptr %l38
  br label %bb17
bb17:
  %t70 = load { i64, ptr }, ptr %l38, !tbaa !27
  store { i64, ptr } %t70, ptr %l26, !tbaa !27
  br label %bb19
bb18:
  %t71 = load i32, ptr %l39, !tbaa !23
  %t72 = lshr i32 %t71, 16
  %t73 = and i32 %t71, 65535
  %t74 = icmp eq i32 %t72, 1
  %t75 = select i1 %t74, i32 1, i32 0
  %t76 = icmp eq i32 %t71, 0
  %t77 = shl i32 %t75, 16
  %t78 = or i32 %t77, %t73
  %t79 = select i1 %t76, i32 0, i32 %t78
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s1)
  %t81 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t79, 0
  store { i32, { i64, ptr } } %t81, ptr %rv
  br label %ret
bb19:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s1)
  %t82 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t83 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t82, 1
  store { i32, { i64, ptr } } %t83, ptr %rv
  br label %ret
bb20:
  call void @__olang_scope_close(ptr %s1)
  br label %bb21
bb21:
  %t84 = getelementptr %"compiler/bindgen:ctype", ptr %l2, i32 0, i32 0
  %t85 = load i32, ptr %t84, !range !{i32 0, i32 7}
  %t87 = trunc i64 3 to i32
  %t88 = icmp eq i32 %t85, %t87
  br i1 %t88, label %bb22, label %bb23
bb22:
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr %"compiler/bindgen:ctype", ptr %l2, i32 0, i32 2
  %t92 = load i64, ptr %t91, !tbaa !24
  %t93 = getelementptr %"compiler/bindgen:ctype", ptr %l2, i32 0, i32 3
  %t94 = load i1, ptr %t93, !tbaa !21
  %t98 = call { i32, { i64, ptr } } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2epointerParam(ptr %v0, ptr %v1, ptr %t90, i64 %t92, i1 %t94)
  %t99 = extractvalue { i32, { i64, ptr } } %t98, 1
  %t100 = extractvalue { i32, { i64, ptr } } %t98, 0
  store i32 %t100, ptr %l48
  %t101 = icmp ne i32 %t100, 0
  br i1 %t101, label %bb25, label %ok.102, !prof !99
ok.102:
  store { i64, ptr } %t99, ptr %l47
  br label %bb24
bb23:
  br label %bb27
bb24:
  %t103 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } %t103, ptr %l43, !tbaa !27
  br label %bb26
bb25:
  %t104 = load i32, ptr %l48, !tbaa !23
  %t105 = lshr i32 %t104, 16
  %t106 = and i32 %t104, 65535
  %t107 = icmp eq i32 %t105, 1
  %t108 = select i1 %t107, i32 1, i32 0
  %t109 = icmp eq i32 %t104, 0
  %t110 = shl i32 %t108, 16
  %t111 = or i32 %t110, %t106
  %t112 = select i1 %t109, i32 0, i32 %t111
  %t114 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t112, 0
  store { i32, { i64, ptr } } %t114, ptr %rv
  br label %ret
bb26:
  %t115 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t116 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t115, 1
  store { i32, { i64, ptr } } %t116, ptr %rv
  br label %ret
bb27:
  %t117 = getelementptr %"compiler/bindgen:ctype", ptr %l2, i32 0, i32 0
  %t118 = load i32, ptr %t117, !range !{i32 0, i32 7}
  %t120 = trunc i64 4 to i32
  %t121 = icmp eq i32 %t118, %t120
  br i1 %t121, label %bb28, label %bb29
bb28:
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t124 = getelementptr %"compiler/bindgen:ctype", ptr %l2, i32 0, i32 2
  %t125 = load i64, ptr %t124, !tbaa !24
  %t128 = call { i32, { i64, ptr } } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2epointerParam(ptr %v0, ptr %v1, ptr %t123, i64 %t125, i1 false)
  %t129 = extractvalue { i32, { i64, ptr } } %t128, 1
  %t130 = extractvalue { i32, { i64, ptr } } %t128, 0
  store i32 %t130, ptr %l56
  %t131 = icmp ne i32 %t130, 0
  br i1 %t131, label %bb31, label %ok.132, !prof !99
ok.132:
  store { i64, ptr } %t129, ptr %l55
  br label %bb30
bb29:
  br label %bb33
bb30:
  %t133 = load { i64, ptr }, ptr %l55, !tbaa !27
  store { i64, ptr } %t133, ptr %l52, !tbaa !27
  br label %bb32
bb31:
  %t134 = load i32, ptr %l56, !tbaa !23
  %t135 = lshr i32 %t134, 16
  %t136 = and i32 %t134, 65535
  %t137 = icmp eq i32 %t135, 1
  %t138 = select i1 %t137, i32 1, i32 0
  %t139 = icmp eq i32 %t134, 0
  %t140 = shl i32 %t138, 16
  %t141 = or i32 %t140, %t136
  %t142 = select i1 %t139, i32 0, i32 %t141
  %t144 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t142, 0
  store { i32, { i64, ptr } } %t144, ptr %rv
  br label %ret
bb32:
  %t145 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t146 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t145, 1
  store { i32, { i64, ptr } } %t146, ptr %rv
  br label %ret
bb33:
  %t147 = load ptr, ptr %l0, !tbaa !29
  %t148 = load i64, ptr %l1, !tbaa !24
  %t151 = call { i32, { i64, ptr } } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2evalueType(ptr %v0, ptr %v1, ptr %t147, i64 %t148, i1 false)
  %t152 = extractvalue { i32, { i64, ptr } } %t151, 1
  %t153 = extractvalue { i32, { i64, ptr } } %t151, 0
  store i32 %t153, ptr %l62
  %t154 = icmp ne i32 %t153, 0
  br i1 %t154, label %bb35, label %ok.155, !prof !99
ok.155:
  store { i64, ptr } %t152, ptr %l61
  br label %bb34
bb34:
  %t156 = load { i64, ptr }, ptr %l61, !tbaa !27
  store { i64, ptr } %t156, ptr %l58, !tbaa !27
  br label %bb36
bb35:
  %t157 = load i32, ptr %l62, !tbaa !23
  %t158 = lshr i32 %t157, 16
  %t159 = and i32 %t157, 65535
  %t160 = icmp eq i32 %t158, 1
  %t161 = select i1 %t160, i32 1, i32 0
  %t162 = icmp eq i32 %t157, 0
  %t163 = shl i32 %t161, 16
  %t164 = or i32 %t163, %t159
  %t165 = select i1 %t162, i32 0, i32 %t164
  %t167 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t165, 0
  store { i32, { i64, ptr } } %t167, ptr %rv
  br label %ret
bb36:
  %t168 = load { i64, ptr }, ptr %l58, !tbaa !27
  %t169 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t168, 1
  store { i32, { i64, ptr } } %t169, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eparseType(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca %"compiler/bindgen:ctp"
  %l4 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l12 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l16 = alloca %"compiler/bindgen:ctp"
  %l20 = alloca i64
  %l25 = alloca ptr
  %l26 = alloca i64
  %l31 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l2, !tbaa !24
  %t3 = icmp sgt i64 %t1, 32
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ebad(ptr %v0, ptr %v0, ptr %t5, { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d167, i32 0, i32 1) })
  store i64 %t7, ptr %l8
  br label %bb3
bb2:
  br label %bb4
bb3:
  call void @__olang_scope_close(ptr %s0)
  %t8 = load i64, ptr %l8, !tbaa !24
  store i64 %t8, ptr %rv
  br label %ret
bb4:
  %t9 = call ptr @__olang_scope_hold(ptr %s0)
  %t10 = ptrtoint ptr %t9 to i64
  store i64 %t10, ptr %l9, !tbaa !24
  %t11 = load i1, ptr @olang_2esole_2ecompiler_2fbindgen_3actp_2e0
  br i1 %t11, label %bb5, label %bb6
bb5:
  %t13 = call ptr @__olang_region_make(ptr %s0)
  %t14 = ptrtoint ptr %t13 to i64
  store i64 %t14, ptr %l9, !tbaa !24
  br label %bb6
bb6:
  %t15 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t16 = load i64, ptr %l9
  %t17 = inttoptr i64 %t16 to ptr
  %t19 = call { i64, ptr } @compiler_2fbindgen_2eplainCall(ptr %v1, ptr %t17, { i64, ptr } %t15)
  store { i64, ptr } %t19, ptr %l12
  br label %bb7
bb7:
  %t20 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t21 = load i64, ptr %l9
  %t22 = inttoptr i64 %t21 to ptr
  %t23 = extractvalue { i64, ptr } %t20, 0
  %t24 = extractvalue { i64, ptr } %t20, 1
  %t25 = mul i64 %t23, 1
  %t26 = call ptr @__olang_held_alloc(ptr %t22, i64 %t25)
  call void @llvm.memcpy.p0.p0.i64(ptr %t26, ptr %t24, i64 %t25, i1 false)
  %t27 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  %t29 = load i64, ptr %l9
  %t30 = inttoptr i64 %t29 to ptr
  %t31 = load i64, ptr %l9
  %t32 = inttoptr i64 %t31 to ptr
  %t34 = call { i64, ptr } @compiler_2fbindgen_2ectokens(ptr %t30, ptr %t32, { i64, ptr } %t28)
  store { i64, ptr } %t34, ptr %l14
  br label %bb8
bb8:
  %t35 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t36 = load i64, ptr %l9
  %t37 = inttoptr i64 %t36 to ptr
  %t38 = extractvalue { i64, ptr } %t35, 0
  %t39 = extractvalue { i64, ptr } %t35, 1
  %t40 = mul i64 %t38, 16
  %t41 = call ptr @__olang_held_alloc(ptr %t37, i64 %t40)
  call void @llvm.memcpy.p0.p0.i64(ptr %t41, ptr %t39, i64 %t40, i1 false)
  %t42 = insertvalue { i64, ptr } undef, i64 %t38, 0
  %t43 = insertvalue { i64, ptr } %t42, ptr %t41, 1
  %t45 = call %"compiler/bindgen:ctp" @compiler_2fbindgen_3actp_2ector(ptr %s0, ptr %s0, { i64, ptr } %t43)
  store %"compiler/bindgen:ctp" %t45, ptr %l16
  br label %bb9
bb9:
  %t46 = load %"compiler/bindgen:ctp", ptr %l16
  store %"compiler/bindgen:ctp" %t46, ptr %l3
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t48 = load i64, ptr %l2, !tbaa !24
  %t52 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2etypeName(ptr %v0, ptr %s0, ptr %t47, ptr %l3, i64 %t48)
  store i64 %t52, ptr %l20
  br label %bb10
bb10:
  %t53 = load i64, ptr %l20, !tbaa !24
  store i64 %t53, ptr %l4, !tbaa !24
  %t54 = getelementptr %"compiler/bindgen:ctp", ptr %l3, i32 0, i32 1
  %t55 = load i64, ptr %t54, !tbaa !24
  %t56 = getelementptr %"compiler/bindgen:ctp", ptr %l3, i32 0, i32 0
  %t57 = load { i64, ptr }, ptr %t56, !tbaa !27
  %t59 = extractvalue { i64, ptr } %t57, 0
  %t62 = icmp slt i64 %t55, %t59
  br i1 %t62, label %bb11, label %bb12
bb11:
  %t64 = load ptr, ptr %l0, !tbaa !29
  store ptr %t64, ptr %l25, !tbaa !29
  %t65 = call ptr @__olang_scope_hold(ptr %v0)
  %t66 = ptrtoint ptr %t65 to i64
  store i64 %t66, ptr %l26, !tbaa !24
  %t67 = load i1, ptr @olang_2esole_2ecompiler_2fbindgen_3actype_2e1
  br i1 %t67, label %bb13, label %bb14
bb12:
  br label %bb16
bb13:
  %t69 = call ptr @__olang_region_make(ptr %v0)
  %t70 = ptrtoint ptr %t69 to i64
  store i64 %t70, ptr %l26, !tbaa !24
  br label %bb14
bb14:
  %t71 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t72 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d168, i32 0, i32 1) }, 1
  %t73 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d168, i32 0, i32 1) }, 0
  %t75 = extractvalue { i64, ptr } %t71, 1
  %t76 = extractvalue { i64, ptr } %t71, 0
  %t77 = add i64 %t73, %t76
  %t78 = extractvalue { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d169, i32 0, i32 1) }, 1
  %t79 = extractvalue { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d169, i32 0, i32 1) }, 0
  %t80 = add i64 %t77, %t79
  %t81 = load i64, ptr %l26
  %t82 = inttoptr i64 %t81 to ptr
  %t83 = call ptr @__olang_held_alloc(ptr %t82, i64 %t80)
  call void @olang_textcopy(ptr %t83, ptr %t72, i64 %t73)
  %t84 = getelementptr i8, ptr %t83, i64 %t73
  call void @olang_textcopy(ptr %t84, ptr %t75, i64 %t76)
  %t85 = getelementptr i8, ptr %t84, i64 %t76
  call void @olang_textcopy(ptr %t85, ptr %t78, i64 %t79)
  %t86 = insertvalue { i64, ptr } undef, i64 %t80, 0
  %t87 = insertvalue { i64, ptr } %t86, ptr %t83, 1
  %t89 = load ptr, ptr %l25, !tbaa !29
  %t91 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ebad(ptr %v0, ptr %v0, ptr %t89, { i64, ptr } %t87)
  store i64 %t91, ptr %l31
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s0)
  %t92 = load i64, ptr %l31, !tbaa !24
  store i64 %t92, ptr %rv
  br label %ret
bb16:
  %t93 = load i64, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t93, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ereadMacros(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, ptr %a4) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %lp5 = alloca ptr
  %l6 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l7 = alloca %"std/prelude/text:LineIter"
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l13 = alloca i64
  %l15 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca { i64, ptr }
  %l20 = alloca i1
  %l21 = alloca ptr
  %l22 = alloca i1
  %l23 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca { i64, ptr }
  %l26 = alloca i64
  %l27 = alloca i64
  %l29 = alloca { i64, ptr }
  %l30 = alloca ptr
  %l31 = alloca i64
  %l32 = alloca { i64, ptr }
  %l34 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l36 = alloca %"std/prelude/text:LineIter"
  %l37 = alloca { i64, ptr }
  %l39 = alloca { i64, ptr }
  %l40 = alloca i32
  %l42 = alloca i1
  %l44 = alloca i1
  %l45 = alloca i1
  %l49 = alloca i1
  %l50 = alloca { i64, ptr }
  %l52 = alloca i1
  %l53 = alloca i64
  %l56 = alloca i64
  %l57 = alloca i32
  %l60 = alloca i64
  %l62 = alloca i64
  %l63 = alloca i32
  %l67 = alloca i64
  %l69 = alloca { i64, ptr }
  %l71 = alloca i64
  %l72 = alloca i64
  %l73 = alloca i64
  %l79 = alloca { i64, ptr }
  %l80 = alloca { i64, ptr }
  %l81 = alloca { i64, ptr }
  %l83 = alloca { i64, ptr }
  %l87 = alloca { i64, ptr }
  %l90 = alloca i1
  %l92 = alloca i1
  %l95 = alloca i1
  %l97 = alloca i1
  %l98 = alloca { i64, ptr }
  %l99 = alloca i64
  %l100 = alloca { i64, ptr }
  %l103 = alloca i1
  %l110 = alloca i1
  %l111 = alloca i1
  %l114 = alloca i1
  %l116 = alloca i1
  %l117 = alloca { i64, ptr }
  %l120 = alloca i64
  %l121 = alloca i64
  %l126 = alloca { i64, ptr }
  %l127 = alloca i64
  %l131 = alloca i64
  %l132 = alloca i32
  %l139 = alloca ptr
  %l140 = alloca ptr
  %l142 = alloca { i64, ptr }
  %l145 = alloca i1
  %l147 = alloca { i64, ptr }
  %l150 = alloca i64
  %l151 = alloca i64
  %l160 = alloca i1
  %l161 = alloca { i64, ptr }
  %l164 = alloca i1
  %l165 = alloca i1
  %l166 = alloca { i64, ptr }
  %l169 = alloca i1
  %l170 = alloca i1
  %l171 = alloca { i64, ptr }
  %l181 = alloca { i64, ptr }
  %l182 = alloca i64
  %l183 = alloca i64
  %l192 = alloca i1
  %l193 = alloca { i64, ptr }
  %l197 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l199 = alloca { i64, ptr }
  %l200 = alloca i64
  %l203 = alloca i64
  %l204 = alloca i64
  %l210 = alloca i64
  %l213 = alloca i64
  %l214 = alloca i32
  %l217 = alloca { i64, ptr }
  %l219 = alloca i64
  %l220 = alloca i64
  %l221 = alloca i64
  %l226 = alloca { i64, ptr }
  %l233 = alloca { i64, ptr }
  %l237 = alloca { i64, ptr }
  %l239 = alloca i1
  %l240 = alloca i1
  %l242 = alloca i1
  %l244 = alloca i1
  %l251 = alloca { i64, ptr }
  %l253 = alloca i64
  %l256 = alloca i64
  %l257 = alloca i64
  %l262 = alloca { i64, ptr }
  %l263 = alloca i1
  %l264 = alloca i64
  %l267 = alloca { i64, ptr }
  %l268 = alloca i64
  %l271 = alloca ptr
  %l272 = alloca { i64, ptr }
  %l275 = alloca i1
  %l276 = alloca i1
  %l278 = alloca i1
  %l279 = alloca %"compiler/bindgen:cMacro"
  %l283 = alloca i64
  %l287 = alloca i64
  %l288 = alloca i32
  %l301 = alloca ptr
  %l302 = alloca { i64, ptr }
  %l305 = alloca i64
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s19 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, ptr } %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d170, i32 0, i32 1) }, ptr %l32, !tbaa !27
  %t1 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 16, i64 8)
  store ptr %t2, ptr %lp5
  %t4 = load ptr, ptr %lp5
  store { i64, ptr } %t1, ptr %t4, !tbaa !27
  %t5 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20Bool_3e_2ector(ptr %s0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t5, ptr %l34
  br label %bb1
bb1:
  %t6 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l34
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t6, ptr %l6
  %t9 = call %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %v1, ptr %v1, { i64, ptr } %a1)
  store %"std/prelude/text:LineIter" %t9, ptr %l36
  br label %bb2
bb2:
  %t10 = load %"std/prelude/text:LineIter", ptr %l36
  store %"std/prelude/text:LineIter" %t10, ptr %l7
  br label %bb3
bb3:
  store %olang.scope zeroinitializer, ptr %s2
  %t12 = call { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %v1, ptr %v1, ptr %l7)
  %t13 = extractvalue { i32, { i64, ptr } } %t12, 1
  %t14 = extractvalue { i32, { i64, ptr } } %t12, 0
  store i32 %t14, ptr %l40
  %t15 = icmp ne i32 %t14, 0
  br i1 %t15, label %bb5, label %ok.16, !prof !99
ok.16:
  store { i64, ptr } %t13, ptr %l39
  br label %bb4
bb4:
  %t17 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t17, ptr %l37, !tbaa !27
  br label %bb7
bb5:
  %t18 = load i32, ptr %l40, !tbaa !23
  %t19 = ashr i32 %t18, 16
  %t21 = icmp eq i32 %t19, 1
  store i1 %t21, ptr %l42, !tbaa !21
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s2)
  br label %bb205
bb7:
  %t22 = load { i64, ptr }, ptr %l37, !tbaa !27
  store { i64, ptr } %t22, ptr %l8, !tbaa !27
  %t23 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t25 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v1, ptr %s2, { i64, ptr } %t23, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d171, i32 0, i32 1) })
  store i1 %t25, ptr %l44
  br label %bb8
bb8:
  %t26 = load i1, ptr %l44, !tbaa !21
  br i1 %t26, label %bb9, label %bb10
bb9:
  %t27 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t27, 0
  %t31 = icmp sgt i64 %t29, 2
  store i1 %t31, ptr %l45, !tbaa !21
  br label %bb11
bb10:
  store i1 false, ptr %l45, !tbaa !21
  br label %bb11
bb11:
  %t33 = load i1, ptr %l45, !tbaa !21
  br i1 %t33, label %bb12, label %bb13
bb12:
  %t34 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t34, ptr %l50, !tbaa !27
  %t35 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !27
  %t37 = getelementptr i8, ptr %t36, i64 2
  %t38 = load i8, ptr %t37, !tbaa !32
  %t40 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t38)
  store i1 %t40, ptr %l52
  br label %bb14
bb13:
  store i1 false, ptr %l49, !tbaa !21
  br label %bb15
bb14:
  %t41 = load i1, ptr %l52, !tbaa !21
  store i1 %t41, ptr %l49, !tbaa !21
  br label %bb15
bb15:
  %t42 = load i1, ptr %l49, !tbaa !21
  br i1 %t42, label %bb16, label %bb17
bb16:
  store %olang.scope zeroinitializer, ptr %s3
  %t43 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t46 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindByte(ptr %v1, { i64, ptr } %t43, i8 34)
  %t47 = extractvalue { i32, i64 } %t46, 1
  %t48 = extractvalue { i32, i64 } %t46, 0
  store i32 %t48, ptr %l57
  %t49 = icmp ne i32 %t48, 0
  br i1 %t49, label %bb19, label %ok.50, !prof !99
ok.50:
  store i64 %t47, ptr %l56
  br label %bb18
bb17:
  br label %bb61
bb18:
  %t51 = load i64, ptr %l56, !tbaa !24
  store i64 %t51, ptr %l53, !tbaa !24
  br label %bb21
bb19:
  br label %bb20
bb20:
  store i64 -1, ptr %l53, !tbaa !24
  br label %bb21
bb21:
  %t52 = load i64, ptr %l53, !tbaa !24
  store i64 %t52, ptr %l9, !tbaa !24
  %t53 = load i64, ptr %l9, !tbaa !24
  %t55 = icmp slt i64 %t53, 0
  br i1 %t55, label %bb22, label %bb23
bb22:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  br label %bb204
bb23:
  br label %bb24
bb24:
  %t57 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t59 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindLast(ptr %v1, ptr %s3, { i64, ptr } %t57, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d172, i32 0, i32 1) })
  %t60 = extractvalue { i32, i64 } %t59, 1
  %t61 = extractvalue { i32, i64 } %t59, 0
  store i32 %t61, ptr %l63
  %t62 = icmp ne i32 %t61, 0
  br i1 %t62, label %bb26, label %ok.63, !prof !99
ok.63:
  store i64 %t60, ptr %l62
  br label %bb25
bb25:
  %t64 = load i64, ptr %l62, !tbaa !24
  store i64 %t64, ptr %l60, !tbaa !24
  br label %bb28
bb26:
  br label %bb27
bb27:
  store i64 -1, ptr %l60, !tbaa !24
  br label %bb28
bb28:
  %t65 = load i64, ptr %l60, !tbaa !24
  store i64 %t65, ptr %l10, !tbaa !24
  %t66 = load i64, ptr %l10, !tbaa !24
  %t67 = load i64, ptr %l9, !tbaa !24
  %t70 = icmp sle i64 %t66, %t67
  br i1 %t70, label %bb29, label %bb30
bb29:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  br label %bb204
bb30:
  br label %bb31
bb31:
  %t72 = call ptr @__olang_scope_hold(ptr %v4)
  %t73 = ptrtoint ptr %t72 to i64
  store i64 %t73, ptr %l67, !tbaa !24
  %t74 = load i1, ptr @olang_2esole_2ecompiler__2fbindgen__2ecompiler__2fbindgen__3agen__2ereadMacros_2elocal_2e5
  br i1 %t74, label %bb32, label %bb33
bb32:
  %t76 = call ptr @__olang_region_make(ptr %v4)
  %t77 = ptrtoint ptr %t76 to i64
  store i64 %t77, ptr %l67, !tbaa !24
  br label %bb33
bb33:
  %t78 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t78, ptr %l69, !tbaa !27
  %t79 = load i64, ptr %l9, !tbaa !24
  %t81 = add i64 %t79, 1
  store i64 %t81, ptr %l71, !tbaa !24
  %t82 = load i64, ptr %l10, !tbaa !24
  store i64 %t82, ptr %l72, !tbaa !24
  %t83 = load { i64, ptr }, ptr %l69, !tbaa !27
  %t84 = extractvalue { i64, ptr } %t83, 0
  store i64 %t84, ptr %l73, !tbaa !24
  %t85 = load i64, ptr %l71, !tbaa !24
  %t86 = icmp sge i64 %t85, 0
  br i1 %t86, label %bb34, label %bb35
bb34:
  %t88 = load i64, ptr %l71, !tbaa !24
  %t89 = load i64, ptr %l72, !tbaa !24
  %t90 = icmp sle i64 %t88, %t89
  br i1 %t90, label %bb36, label %bb37
bb35:
  call void @__olang_check_failed(ptr @olang_loc_beacd36cd332827c_e461632e30adb8c0)
  unreachable
bb36:
  %t92 = load i64, ptr %l72, !tbaa !24
  %t93 = load i64, ptr %l73, !tbaa !24
  %t94 = icmp sle i64 %t92, %t93
  br i1 %t94, label %bb38, label %bb39
bb37:
  call void @__olang_check_failed(ptr @olang_loc_beacd36cd332827c_e461632e30adb8c0)
  unreachable
bb38:
  %t96 = getelementptr { i64, ptr }, ptr %l69, i32 0, i32 1
  %t97 = load ptr, ptr %t96, !tbaa !27
  %t98 = load i64, ptr %l71, !tbaa !24
  %t99 = load i64, ptr %l72, !tbaa !24
  %t100 = getelementptr i8, ptr %t97, i64 %t98
  %t101 = sub i64 %t99, %t98
  %t102 = insertvalue { i64, ptr } undef, i64 %t101, 0
  %t103 = insertvalue { i64, ptr } %t102, ptr %t100, 1
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d173, i32 0, i32 1) }, ptr %l79, !tbaa !27
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d174, i32 0, i32 1) }, ptr %l80, !tbaa !27
  %t106 = load { i64, ptr }, ptr %l79, !tbaa !27
  %t107 = load { i64, ptr }, ptr %l80, !tbaa !27
  %t108 = call { i64, ptr } @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eReplace_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v1, ptr %s3, ptr %s3, ptr %s3, { i64, ptr } %t103, { i64, ptr } %t106, { i64, ptr } %t107)
  store { i64, ptr } %t108, ptr %l81
  br label %bb40
bb39:
  call void @__olang_check_failed(ptr @olang_loc_beacd36cd332827c_e461632e30adb8c0)
  unreachable
bb40:
  %t109 = load { i64, ptr }, ptr %l81, !tbaa !27
  %t111 = extractvalue { i64, ptr } %t109, 1
  %t112 = extractvalue { i64, ptr } %t109, 0
  %t113 = load i64, ptr %l67
  %t114 = inttoptr i64 %t113 to ptr
  %t115 = call ptr @__olang_held_alloc(ptr %t114, i64 %t112)
  call void @olang_textcopy(ptr %t115, ptr %t111, i64 %t112)
  %t116 = insertvalue { i64, ptr } undef, i64 %t112, 0
  %t117 = insertvalue { i64, ptr } %t116, ptr %t115, 1
  store { i64, ptr } %t117, ptr %l83, !tbaa !27
  %t118 = load i1, ptr @olang_2esole_2ecompiler__2fbindgen__2ecompiler__2fbindgen__3agen__2ereadMacros_2elocal_2e5
  br i1 %t118, label %bb41, label %bb42
bb41:
  %t120 = load { i64, ptr }, ptr %l83, !tbaa !27
  %t121 = extractvalue { i64, ptr } %t120, 0
  %t123 = icmp eq i64 %t121, 0
  br i1 %t123, label %bb43, label %bb44
bb42:
  %t125 = load ptr, ptr %lp5
  %t126 = load { i64, ptr }, ptr %t125, !tbaa !27
  store { i64, ptr } %t126, ptr %l87, !tbaa !27
  %t127 = load { i64, ptr }, ptr %l83, !tbaa !27
  %t128 = load ptr, ptr %lp5
  store { i64, ptr } %t127, ptr %t128, !tbaa !27
  %t129 = load i1, ptr @olang_2esole_2ecompiler__2fbindgen__2ecompiler__2fbindgen__3agen__2ereadMacros_2elocal_2e5
  br i1 %t129, label %bb45, label %bb46
bb43:
  store { i64, ptr } zeroinitializer, ptr %l83, !tbaa !27
  br label %bb44
bb44:
  %t131 = load i64, ptr %l67
  %t132 = inttoptr i64 %t131 to ptr
  %t133 = load { i64, ptr }, ptr %l83
  %t134 = extractvalue { i64, ptr } %t133, 1
  %t135 = call ptr @__olang_region_or(ptr %t134, ptr null)
  %t136 = icmp ne ptr %t135, null
  %t137 = select i1 %t136, ptr %t135, ptr null
  call void @__olang_region_settle_in(ptr %t132, ptr %t137)
  br label %bb42
bb45:
  %t138 = load { i64, ptr }, ptr %l87
  %t139 = extractvalue { i64, ptr } %t138, 1
  call void @__olang_region_release(ptr %t139)
  store { i64, ptr } zeroinitializer, ptr %l87
  br label %bb46
bb46:
  %t140 = load ptr, ptr %lp5
  %t141 = load { i64, ptr }, ptr %t140, !tbaa !27
  %t143 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v4, ptr %s3, { i64, ptr } %t141, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d175, i32 0, i32 1) })
  store i1 %t143, ptr %l90
  br label %bb47
bb47:
  %t144 = load i1, ptr %l90, !tbaa !21
  %t145 = xor i1 %t144, true
  br i1 %t145, label %bb48, label %bb49
bb48:
  %t147 = load ptr, ptr %lp5
  %t148 = load { i64, ptr }, ptr %t147, !tbaa !27
  %t149 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t152 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v4, ptr %v2, { i64, ptr } %t148, { i64, ptr } %t149)
  store i1 %t152, ptr %l95
  br label %bb50
bb49:
  store i1 false, ptr %l92, !tbaa !21
  br label %bb51
bb50:
  %t153 = load i1, ptr %l95, !tbaa !21
  %t154 = xor i1 %t153, true
  store i1 %t154, ptr %l92, !tbaa !21
  br label %bb51
bb51:
  %t156 = load i1, ptr %l92, !tbaa !21
  br i1 %t156, label %bb52, label %bb53
bb52:
  %t157 = load ptr, ptr %lp5
  %t158 = load { i64, ptr }, ptr %t157, !tbaa !27
  store { i64, ptr } %t158, ptr %l98, !tbaa !27
  %t159 = load { i64, ptr }, ptr %l98, !tbaa !27
  %t160 = extractvalue { i64, ptr } %t159, 0
  store i64 %t160, ptr %l99, !tbaa !24
  %t161 = load i64, ptr %l99, !tbaa !24
  %t162 = mul i64 %t161, 1
  %t163 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t162)
  %t164 = insertvalue { i64, ptr } undef, i64 %t161, 0
  %t165 = insertvalue { i64, ptr } %t164, ptr %t163, 1
  store { i64, ptr } %t165, ptr %l100, !tbaa !27
  %t166 = getelementptr { i64, ptr }, ptr %l100, i32 0, i32 1
  %t167 = load ptr, ptr %t166, !tbaa !27
  %t168 = getelementptr { i64, ptr }, ptr %l98, i32 0, i32 1
  %t169 = load ptr, ptr %t168, !tbaa !27
  %t170 = load i64, ptr %l99, !tbaa !24
  %t171 = mul i64 %t170, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t167, ptr %t169, i64 %t171, i1 false)
  %t172 = load { i64, ptr }, ptr %l100, !tbaa !27
  %t176 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H6b5ccacad8db807339a3579aa8c82ff8(ptr %s0, ptr %s3, ptr %l6, { i64, ptr } %t172)
  store i1 %t176, ptr %l103
  br label %bb54
bb53:
  store i1 false, ptr %l97, !tbaa !21
  br label %bb55
bb54:
  %t177 = load i1, ptr %l103, !tbaa !21
  %t178 = xor i1 %t177, true
  store i1 %t178, ptr %l97, !tbaa !21
  br label %bb55
bb55:
  %t180 = load i1, ptr %l97, !tbaa !21
  br i1 %t180, label %bb56, label %bb57
bb56:
  %t181 = load ptr, ptr %lp5
  %t182 = load { i64, ptr }, ptr %t181, !tbaa !27
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H2b85ceff512af6e6ca26c554a1c16247(ptr %s0, ptr %v4, ptr %l6, { i64, ptr } %t182, i1 true)
  br label %bb58
bb57:
  br label %bb60
bb58:
  %t186 = load ptr, ptr %lp5
  %t187 = load { i64, ptr }, ptr %t186, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v4, ptr %v4, ptr %a4, { i64, ptr } %t187)
  br label %bb59
bb59:
  br label %bb60
bb60:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  br label %bb204
bb61:
  %t190 = load ptr, ptr %lp5
  %t191 = load { i64, ptr }, ptr %t190, !tbaa !27
  %t193 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v4, ptr %s2, { i64, ptr } %t191, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d176, i32 0, i32 1) })
  store i1 %t193, ptr %l110
  br label %bb62
bb62:
  %t194 = load i1, ptr %l110, !tbaa !21
  br i1 %t194, label %bb63, label %bb64
bb63:
  store i1 true, ptr %l111, !tbaa !21
  br label %bb66
bb64:
  %t195 = load ptr, ptr %lp5
  %t196 = load { i64, ptr }, ptr %t195, !tbaa !27
  %t197 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t200 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v4, ptr %v2, { i64, ptr } %t196, { i64, ptr } %t197)
  store i1 %t200, ptr %l114
  br label %bb65
bb65:
  %t201 = load i1, ptr %l114, !tbaa !21
  store i1 %t201, ptr %l111, !tbaa !21
  br label %bb66
bb66:
  %t202 = load i1, ptr %l111, !tbaa !21
  br i1 %t202, label %bb67, label %bb68
bb67:
  call void @__olang_scope_close(ptr %s2)
  br label %bb204
bb68:
  br label %bb69
bb69:
  %t203 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t205 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v1, ptr %s2, { i64, ptr } %t203, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d177, i32 0, i32 1) })
  store i1 %t205, ptr %l116
  br label %bb70
bb70:
  %t206 = load i1, ptr %l116, !tbaa !21
  br i1 %t206, label %bb71, label %bb72
bb71:
  %t207 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t207, ptr %l117, !tbaa !27
  %t208 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t211 = extractvalue { i64, ptr } %t208, 0
  store i64 %t211, ptr %l120, !tbaa !24
  %t212 = load { i64, ptr }, ptr %l117, !tbaa !27
  %t213 = extractvalue { i64, ptr } %t212, 0
  store i64 %t213, ptr %l121, !tbaa !24
  %t214 = icmp sge i64 7, 0
  br i1 %t214, label %bb73, label %bb74
bb72:
  br label %bb90
bb73:
  %t216 = load i64, ptr %l120, !tbaa !24
  %t217 = icmp sle i64 7, %t216
  br i1 %t217, label %bb75, label %bb76
bb74:
  call void @__olang_check_failed(ptr @olang_loc_88bbbdba37ecb069_7556c3a5c9bf841d)
  unreachable
bb75:
  %t219 = load i64, ptr %l120, !tbaa !24
  %t220 = load i64, ptr %l121, !tbaa !24
  %t221 = icmp sle i64 %t219, %t220
  br i1 %t221, label %bb77, label %bb78
bb76:
  call void @__olang_check_failed(ptr @olang_loc_88bbbdba37ecb069_7556c3a5c9bf841d)
  unreachable
bb77:
  %t223 = getelementptr { i64, ptr }, ptr %l117, i32 0, i32 1
  %t224 = load ptr, ptr %t223, !tbaa !27
  %t225 = load i64, ptr %l120, !tbaa !24
  %t226 = getelementptr i8, ptr %t224, i64 7
  %t227 = sub i64 %t225, 7
  %t228 = insertvalue { i64, ptr } undef, i64 %t227, 0
  %t229 = insertvalue { i64, ptr } %t228, ptr %t226, 1
  %t231 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %v1, ptr %v1, { i64, ptr } %t229)
  store { i64, ptr } %t231, ptr %l126
  br label %bb79
bb78:
  call void @__olang_check_failed(ptr @olang_loc_88bbbdba37ecb069_7556c3a5c9bf841d)
  unreachable
bb79:
  %t232 = load { i64, ptr }, ptr %l126, !tbaa !27
  %t233 = load ptr, ptr %l0, !tbaa !29
  %t235 = getelementptr %"compiler/bindgen:gen", ptr %t233, i32 0, i32 14
  %t239 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9162e3b7f03fcbf954b681204d5f6cca(ptr %v0, ptr %v1, ptr %t235, { i64, ptr } %t232)
  %t240 = extractvalue { i32, i64 } %t239, 1
  %t241 = extractvalue { i32, i64 } %t239, 0
  store i32 %t241, ptr %l132
  %t242 = icmp ne i32 %t241, 0
  br i1 %t242, label %bb81, label %ok.243, !prof !99
ok.243:
  store i64 %t240, ptr %l131
  br label %bb80
bb80:
  %t244 = load i64, ptr %l131, !tbaa !24
  store i64 %t244, ptr %l127, !tbaa !24
  br label %bb83
bb81:
  br label %bb82
bb82:
  store i64 -1, ptr %l127, !tbaa !24
  br label %bb83
bb83:
  %t245 = load i64, ptr %l127, !tbaa !24
  store i64 %t245, ptr %l13, !tbaa !24
  %t246 = load i64, ptr %l13, !tbaa !24
  %t248 = icmp sge i64 %t246, 0
  br i1 %t248, label %bb84, label %bb85
bb84:
  %t250 = load i64, ptr %l13, !tbaa !24
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d178, i32 0, i32 1) }, ptr %l15, !tbaa !27
  %t252 = load ptr, ptr %l0, !tbaa !29
  %t254 = getelementptr %"compiler/bindgen:gen", ptr %t252, i32 0, i32 13
  %t258 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3acMacro_3e_2eRefMu_H9d4ce036ca8f6276b6798968f53e8eb9(ptr %v0, ptr %v0, ptr %t254, i64 %t250)
  store ptr %t258, ptr %l139
  br label %bb86
bb85:
  br label %bb89
bb86:
  %t259 = load ptr, ptr %l139, !tbaa !29
  store ptr %t259, ptr %l140, !tbaa !29
  %t261 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t262 = load ptr, ptr %l140, !tbaa !29
  %t263 = getelementptr %"compiler/bindgen:cMacro", ptr %t262, i32 0, i32 0
  %t264 = load { i64, ptr }, ptr %t263, !tbaa !27
  store { i64, ptr } %t264, ptr %l142, !tbaa !27
  %t266 = load ptr, ptr %l140, !tbaa !29
  %t267 = getelementptr %"compiler/bindgen:cMacro", ptr %t266, i32 0, i32 0
  store { i64, ptr } %t261, ptr %t267, !tbaa !27
  %t268 = load i1, ptr @olang_2esole_2ecompiler_2fbindgen_3acMacro_2e0
  br i1 %t268, label %bb87, label %bb88
bb87:
  %t270 = load { i64, ptr }, ptr %l142
  %t271 = extractvalue { i64, ptr } %t270, 1
  call void @__olang_region_release(ptr %t271)
  store { i64, ptr } zeroinitializer, ptr %l142
  br label %bb88
bb88:
  br label %bb89
bb89:
  call void @__olang_scope_close(ptr %s2)
  br label %bb204
bb90:
  %t272 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t274 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v1, ptr %s2, { i64, ptr } %t272, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d179, i32 0, i32 1) })
  store i1 %t274, ptr %l145
  br label %bb91
bb91:
  %t275 = load i1, ptr %l145, !tbaa !21
  %t276 = xor i1 %t275, true
  br i1 %t276, label %bb92, label %bb93
bb92:
  call void @__olang_scope_close(ptr %s2)
  br label %bb204
bb93:
  br label %bb94
bb94:
  %t278 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t278, ptr %l147, !tbaa !27
  %t279 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t282 = extractvalue { i64, ptr } %t279, 0
  store i64 %t282, ptr %l150, !tbaa !24
  %t283 = load { i64, ptr }, ptr %l147, !tbaa !27
  %t284 = extractvalue { i64, ptr } %t283, 0
  store i64 %t284, ptr %l151, !tbaa !24
  %t285 = icmp sge i64 8, 0
  br i1 %t285, label %bb95, label %bb96
bb95:
  %t287 = load i64, ptr %l150, !tbaa !24
  %t288 = icmp sle i64 8, %t287
  br i1 %t288, label %bb97, label %bb98
bb96:
  call void @__olang_check_failed(ptr @olang_loc_a6c60cdff876254a_2c918d2d7b99843e)
  unreachable
bb97:
  %t290 = load i64, ptr %l150, !tbaa !24
  %t291 = load i64, ptr %l151, !tbaa !24
  %t292 = icmp sle i64 %t290, %t291
  br i1 %t292, label %bb99, label %bb100
bb98:
  call void @__olang_check_failed(ptr @olang_loc_a6c60cdff876254a_2c918d2d7b99843e)
  unreachable
bb99:
  %t294 = getelementptr { i64, ptr }, ptr %l147, i32 0, i32 1
  %t295 = load ptr, ptr %t294, !tbaa !27
  %t296 = load i64, ptr %l150, !tbaa !24
  %t297 = getelementptr i8, ptr %t295, i64 8
  %t298 = sub i64 %t296, 8
  %t299 = insertvalue { i64, ptr } undef, i64 %t298, 0
  %t300 = insertvalue { i64, ptr } %t299, ptr %t297, 1
  store { i64, ptr } %t300, ptr %l17, !tbaa !27
  store i64 0, ptr %l18, !tbaa !24
  br label %bb101
bb100:
  call void @__olang_check_failed(ptr @olang_loc_a6c60cdff876254a_2c918d2d7b99843e)
  unreachable
bb101:
  %t302 = load i64, ptr %l18, !tbaa !24
  %t303 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t305 = extractvalue { i64, ptr } %t303, 0
  %t308 = icmp slt i64 %t302, %t305
  br i1 %t308, label %bb102, label %bb103
bb102:
  %t310 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t310, ptr %l161, !tbaa !27
  %t311 = load i64, ptr %l18, !tbaa !24
  %t313 = getelementptr { i64, ptr }, ptr %l161, i32 0, i32 1
  %t314 = load ptr, ptr %t313, !tbaa !27
  %t315 = getelementptr i8, ptr %t314, i64 %t311
  %t316 = load i8, ptr %t315, !tbaa !32
  %t318 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %t316)
  store i1 %t318, ptr %l164
  br label %bb104
bb103:
  store i1 false, ptr %l160, !tbaa !21
  br label %bb112
bb104:
  %t319 = load i1, ptr %l164, !tbaa !21
  br i1 %t319, label %bb105, label %bb106
bb105:
  store i1 true, ptr %l165, !tbaa !21
  br label %bb108
bb106:
  %t320 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t320, ptr %l166, !tbaa !27
  %t321 = load i64, ptr %l18, !tbaa !24
  %t323 = getelementptr { i64, ptr }, ptr %l166, i32 0, i32 1
  %t324 = load ptr, ptr %t323, !tbaa !27
  %t325 = getelementptr i8, ptr %t324, i64 %t321
  %t326 = load i8, ptr %t325, !tbaa !32
  %t328 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t326)
  store i1 %t328, ptr %l169
  br label %bb107
bb107:
  %t329 = load i1, ptr %l169, !tbaa !21
  store i1 %t329, ptr %l165, !tbaa !21
  br label %bb108
bb108:
  %t330 = load i1, ptr %l165, !tbaa !21
  br i1 %t330, label %bb109, label %bb110
bb109:
  store i1 true, ptr %l170, !tbaa !21
  br label %bb111
bb110:
  %t331 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t331, ptr %l171, !tbaa !27
  %t332 = load i64, ptr %l18, !tbaa !24
  %t334 = getelementptr { i64, ptr }, ptr %l171, i32 0, i32 1
  %t335 = load ptr, ptr %t334, !tbaa !27
  %t336 = getelementptr i8, ptr %t335, i64 %t332
  %t337 = load i8, ptr %t336, !tbaa !32
  %t339 = icmp eq i8 %t337, 95
  store i1 %t339, ptr %l170, !tbaa !21
  br label %bb111
bb111:
  %t341 = load i1, ptr %l170, !tbaa !21
  store i1 %t341, ptr %l160, !tbaa !21
  br label %bb112
bb112:
  %t342 = load i1, ptr %l160, !tbaa !21
  %t343 = xor i1 %t342, true
  br i1 %t343, label %bb113, label %bb114
bb113:
  br label %bb117
bb114:
  br label %bb115
bb115:
  %t345 = load i64, ptr %l18, !tbaa !24
  %t348 = add i64 %t345, 1
  store i64 %t348, ptr %l18, !tbaa !24
  br label %bb116
bb116:
  br label %bb101
bb117:
  %t350 = load i64, ptr %l18, !tbaa !24
  %t352 = icmp eq i64 %t350, 0
  br i1 %t352, label %bb118, label %bb119
bb118:
  call void @__olang_scope_close(ptr %s2)
  br label %bb204
bb119:
  br label %bb120
bb120:
  %t354 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t354, ptr %l181, !tbaa !27
  %t355 = load i64, ptr %l18, !tbaa !24
  store i64 %t355, ptr %l182, !tbaa !24
  %t356 = load { i64, ptr }, ptr %l181, !tbaa !27
  %t357 = extractvalue { i64, ptr } %t356, 0
  store i64 %t357, ptr %l183, !tbaa !24
  %t358 = icmp sge i64 0, 0
  br i1 %t358, label %bb121, label %bb122
bb121:
  %t360 = load i64, ptr %l182, !tbaa !24
  %t361 = icmp sle i64 0, %t360
  br i1 %t361, label %bb123, label %bb124
bb122:
  call void @__olang_check_failed(ptr @olang_loc_5755e6dd02fca827_178a482bfa1e95bb)
  unreachable
bb123:
  %t363 = load i64, ptr %l182, !tbaa !24
  %t364 = load i64, ptr %l183, !tbaa !24
  %t365 = icmp sle i64 %t363, %t364
  br i1 %t365, label %bb125, label %bb126
bb124:
  call void @__olang_check_failed(ptr @olang_loc_5755e6dd02fca827_178a482bfa1e95bb)
  unreachable
bb125:
  %t367 = getelementptr { i64, ptr }, ptr %l181, i32 0, i32 1
  %t368 = load ptr, ptr %t367, !tbaa !27
  %t369 = load i64, ptr %l182, !tbaa !24
  %t370 = getelementptr i8, ptr %t368, i64 0
  %t371 = sub i64 %t369, 0
  %t372 = insertvalue { i64, ptr } undef, i64 %t371, 0
  %t373 = insertvalue { i64, ptr } %t372, ptr %t370, 1
  store { i64, ptr } %t373, ptr %l19, !tbaa !27
  %t375 = load i64, ptr %l18, !tbaa !24
  %t376 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t378 = extractvalue { i64, ptr } %t376, 0
  %t381 = icmp slt i64 %t375, %t378
  br i1 %t381, label %bb127, label %bb128
bb126:
  call void @__olang_check_failed(ptr @olang_loc_5755e6dd02fca827_178a482bfa1e95bb)
  unreachable
bb127:
  %t383 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t383, ptr %l193, !tbaa !27
  %t384 = load i64, ptr %l18, !tbaa !24
  %t386 = getelementptr { i64, ptr }, ptr %l193, i32 0, i32 1
  %t387 = load ptr, ptr %t386, !tbaa !27
  %t388 = getelementptr i8, ptr %t387, i64 %t384
  %t389 = load i8, ptr %t388, !tbaa !32
  %t391 = icmp eq i8 %t389, 40
  store i1 %t391, ptr %l192, !tbaa !21
  br label %bb129
bb128:
  store i1 false, ptr %l192, !tbaa !21
  br label %bb129
bb129:
  %t393 = load i1, ptr %l192, !tbaa !21
  store i1 %t393, ptr %l20, !tbaa !21
  %t394 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t394, ptr %l197
  br label %bb130
bb130:
  %t395 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l197
  %t396 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t395, ptr %t396
  store ptr %t396, ptr %l21, !tbaa !29
  store i1 false, ptr %l22, !tbaa !21
  %t398 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t398, ptr %l199, !tbaa !27
  %t399 = load i64, ptr %l18, !tbaa !24
  store i64 %t399, ptr %l200, !tbaa !24
  %t400 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t403 = extractvalue { i64, ptr } %t400, 0
  store i64 %t403, ptr %l203, !tbaa !24
  %t404 = load { i64, ptr }, ptr %l199, !tbaa !27
  %t405 = extractvalue { i64, ptr } %t404, 0
  store i64 %t405, ptr %l204, !tbaa !24
  %t406 = load i64, ptr %l200, !tbaa !24
  %t407 = icmp sge i64 %t406, 0
  br i1 %t407, label %bb131, label %bb132
bb131:
  %t409 = load i64, ptr %l200, !tbaa !24
  %t410 = load i64, ptr %l203, !tbaa !24
  %t411 = icmp sle i64 %t409, %t410
  br i1 %t411, label %bb133, label %bb134
bb132:
  call void @__olang_check_failed(ptr @olang_loc_4153d023000ff8e8_6b17d300a1e811b4)
  unreachable
bb133:
  %t413 = load i64, ptr %l203, !tbaa !24
  %t414 = load i64, ptr %l204, !tbaa !24
  %t415 = icmp sle i64 %t413, %t414
  br i1 %t415, label %bb135, label %bb136
bb134:
  call void @__olang_check_failed(ptr @olang_loc_4153d023000ff8e8_6b17d300a1e811b4)
  unreachable
bb135:
  %t417 = getelementptr { i64, ptr }, ptr %l199, i32 0, i32 1
  %t418 = load ptr, ptr %t417, !tbaa !27
  %t419 = load i64, ptr %l200, !tbaa !24
  %t420 = load i64, ptr %l203, !tbaa !24
  %t421 = getelementptr i8, ptr %t418, i64 %t419
  %t422 = sub i64 %t420, %t419
  %t423 = insertvalue { i64, ptr } undef, i64 %t422, 0
  %t424 = insertvalue { i64, ptr } %t423, ptr %t421, 1
  store { i64, ptr } %t424, ptr %l23, !tbaa !27
  %t426 = load i1, ptr %l20, !tbaa !21
  br i1 %t426, label %bb137, label %bb138
bb136:
  call void @__olang_check_failed(ptr @olang_loc_4153d023000ff8e8_6b17d300a1e811b4)
  unreachable
bb137:
  %t428 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t431 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindByte(ptr %v1, { i64, ptr } %t428, i8 41)
  %t432 = extractvalue { i32, i64 } %t431, 1
  %t433 = extractvalue { i32, i64 } %t431, 0
  store i32 %t433, ptr %l214
  %t434 = icmp ne i32 %t433, 0
  br i1 %t434, label %bb140, label %ok.435, !prof !99
ok.435:
  store i64 %t432, ptr %l213
  br label %bb139
bb138:
  br label %bb179
bb139:
  %t436 = load i64, ptr %l213, !tbaa !24
  store i64 %t436, ptr %l210, !tbaa !24
  br label %bb142
bb140:
  br label %bb141
bb141:
  store i64 -1, ptr %l210, !tbaa !24
  br label %bb142
bb142:
  %t437 = load i64, ptr %l210, !tbaa !24
  store i64 %t437, ptr %l24, !tbaa !24
  %t438 = load i64, ptr %l24, !tbaa !24
  %t440 = icmp slt i64 %t438, 0
  br i1 %t440, label %bb143, label %bb144
bb143:
  call void @__olang_scope_close(ptr %s2)
  br label %bb204
bb144:
  br label %bb145
bb145:
  store %olang.scope zeroinitializer, ptr %s16
  %t442 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t442, ptr %l217, !tbaa !27
  %t443 = load i64, ptr %l18, !tbaa !24
  %t445 = add i64 %t443, 1
  store i64 %t445, ptr %l219, !tbaa !24
  %t446 = load i64, ptr %l24, !tbaa !24
  store i64 %t446, ptr %l220, !tbaa !24
  %t447 = load { i64, ptr }, ptr %l217, !tbaa !27
  %t448 = extractvalue { i64, ptr } %t447, 0
  store i64 %t448, ptr %l221, !tbaa !24
  %t449 = load i64, ptr %l219, !tbaa !24
  %t450 = icmp sge i64 %t449, 0
  br i1 %t450, label %bb146, label %bb147
bb146:
  %t452 = load i64, ptr %l219, !tbaa !24
  %t453 = load i64, ptr %l220, !tbaa !24
  %t454 = icmp sle i64 %t452, %t453
  br i1 %t454, label %bb148, label %bb149
bb147:
  call void @__olang_check_failed(ptr @olang_loc_ec020a578bdf64c5_799d4029e88195a1)
  unreachable
bb148:
  %t456 = load i64, ptr %l220, !tbaa !24
  %t457 = load i64, ptr %l221, !tbaa !24
  %t458 = icmp sle i64 %t456, %t457
  br i1 %t458, label %bb150, label %bb151
bb149:
  call void @__olang_check_failed(ptr @olang_loc_ec020a578bdf64c5_799d4029e88195a1)
  unreachable
bb150:
  %t460 = getelementptr { i64, ptr }, ptr %l217, i32 0, i32 1
  %t461 = load ptr, ptr %t460, !tbaa !27
  %t462 = load i64, ptr %l219, !tbaa !24
  %t463 = load i64, ptr %l220, !tbaa !24
  %t464 = getelementptr i8, ptr %t461, i64 %t462
  %t465 = sub i64 %t463, %t462
  %t466 = insertvalue { i64, ptr } undef, i64 %t465, 0
  %t467 = insertvalue { i64, ptr } %t466, ptr %t464, 1
  %t469 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eSplit(ptr %v1, ptr %s16, ptr %v1, { i64, ptr } %t467, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d180, i32 0, i32 1) })
  store { i64, ptr } %t469, ptr %l226
  br label %bb152
bb151:
  call void @__olang_check_failed(ptr @olang_loc_ec020a578bdf64c5_799d4029e88195a1)
  unreachable
bb152:
  %t470 = load { i64, ptr }, ptr %l226, !tbaa !27
  store { i64, ptr } %t470, ptr %l25, !tbaa !27
  store i64 0, ptr %l26, !tbaa !24
  %t471 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t473 = extractvalue { i64, ptr } %t471, 0
  store i64 %t473, ptr %l27, !tbaa !24
  br label %bb153
bb153:
  store %olang.scope zeroinitializer, ptr %s17
  %t475 = load i64, ptr %l26, !tbaa !24
  %t476 = load i64, ptr %l27, !tbaa !24
  %t479 = icmp slt i64 %t475, %t476
  %t481 = xor i1 %t479, true
  br i1 %t481, label %bb154, label %bb155
bb154:
  call void @__olang_scope_close(ptr %s17)
  br label %bb172
bb155:
  br label %bb156
bb156:
  %t483 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t483, ptr %l233, !tbaa !27
  %t484 = load i64, ptr %l26, !tbaa !24
  %t486 = getelementptr { i64, ptr }, ptr %l233, i32 0, i32 1
  %t487 = load ptr, ptr %t486, !tbaa !27
  %t488 = getelementptr { i64, ptr }, ptr %t487, i64 %t484
  %t489 = load { i64, ptr }, ptr %t488, !tbaa !37
  %t493 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %v1, ptr %v1, { i64, ptr } %t489)
  store { i64, ptr } %t493, ptr %l237
  br label %bb157
bb157:
  %t494 = load { i64, ptr }, ptr %l237, !tbaa !27
  store { i64, ptr } %t494, ptr %l29, !tbaa !27
  %t495 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t497 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s17, { i64, ptr } %t495, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d181, i32 0, i32 1) })
  store i1 %t497, ptr %l239
  br label %bb158
bb158:
  %t498 = load i1, ptr %l239, !tbaa !21
  br i1 %t498, label %bb159, label %bb160
bb159:
  store i1 true, ptr %l240, !tbaa !21
  br label %bb162
bb160:
  %t499 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t501 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v1, ptr %s17, { i64, ptr } %t499, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d182, i32 0, i32 1) })
  store i1 %t501, ptr %l242
  br label %bb161
bb161:
  %t502 = load i1, ptr %l242, !tbaa !21
  store i1 %t502, ptr %l240, !tbaa !21
  br label %bb162
bb162:
  %t503 = load i1, ptr %l240, !tbaa !21
  br i1 %t503, label %bb163, label %bb164
bb163:
  store i1 true, ptr %l22, !tbaa !21
  br label %bb170
bb164:
  store %olang.scope zeroinitializer, ptr %s19
  %t504 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t506 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s19, { i64, ptr } %t504, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d183, i32 0, i32 1) })
  store i1 %t506, ptr %l244
  br label %bb165
bb165:
  %t507 = load i1, ptr %l244, !tbaa !21
  %t508 = xor i1 %t507, true
  br i1 %t508, label %bb166, label %bb167
bb166:
  %t510 = load ptr, ptr %l21, !tbaa !29
  %t511 = load { i64, ptr }, ptr %l29, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v1, ptr %t510, { i64, ptr } %t511)
  br label %bb168
bb167:
  br label %bb169
bb168:
  br label %bb169
bb169:
  call void @__olang_scope_close(ptr %s19)
  br label %bb170
bb170:
  call void @__olang_scope_close(ptr %s17)
  br label %bb171
bb171:
  %t514 = load i64, ptr %l26, !tbaa !24
  %t517 = add i64 %t514, 1
  store i64 %t517, ptr %l26, !tbaa !24
  br label %bb153
bb172:
  call void @__olang_scope_close(ptr %s16)
  %t519 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t519, ptr %l251, !tbaa !27
  %t520 = load i64, ptr %l24, !tbaa !24
  %t522 = add i64 %t520, 1
  store i64 %t522, ptr %l253, !tbaa !24
  %t523 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t526 = extractvalue { i64, ptr } %t523, 0
  store i64 %t526, ptr %l256, !tbaa !24
  %t527 = load { i64, ptr }, ptr %l251, !tbaa !27
  %t528 = extractvalue { i64, ptr } %t527, 0
  store i64 %t528, ptr %l257, !tbaa !24
  %t529 = load i64, ptr %l253, !tbaa !24
  %t530 = icmp sge i64 %t529, 0
  br i1 %t530, label %bb173, label %bb174
bb173:
  %t532 = load i64, ptr %l253, !tbaa !24
  %t533 = load i64, ptr %l256, !tbaa !24
  %t534 = icmp sle i64 %t532, %t533
  br i1 %t534, label %bb175, label %bb176
bb174:
  call void @__olang_check_failed(ptr @olang_loc_642a74ef72af54a6_43680c0161c24f22)
  unreachable
bb175:
  %t536 = load i64, ptr %l256, !tbaa !24
  %t537 = load i64, ptr %l257, !tbaa !24
  %t538 = icmp sle i64 %t536, %t537
  br i1 %t538, label %bb177, label %bb178
bb176:
  call void @__olang_check_failed(ptr @olang_loc_642a74ef72af54a6_43680c0161c24f22)
  unreachable
bb177:
  %t540 = getelementptr { i64, ptr }, ptr %l251, i32 0, i32 1
  %t541 = load ptr, ptr %t540, !tbaa !27
  %t542 = load i64, ptr %l253, !tbaa !24
  %t543 = load i64, ptr %l256, !tbaa !24
  %t544 = getelementptr i8, ptr %t541, i64 %t542
  %t545 = sub i64 %t543, %t542
  %t546 = insertvalue { i64, ptr } undef, i64 %t545, 0
  %t547 = insertvalue { i64, ptr } %t546, ptr %t544, 1
  store { i64, ptr } %t547, ptr %l23, !tbaa !27
  br label %bb179
bb178:
  call void @__olang_check_failed(ptr @olang_loc_642a74ef72af54a6_43680c0161c24f22)
  unreachable
bb179:
  %t549 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t549, ptr %l262, !tbaa !27
  %t550 = load i1, ptr %l20, !tbaa !21
  store i1 %t550, ptr %l263, !tbaa !21
  %t551 = call ptr @__olang_scope_hold(ptr %v0)
  %t552 = ptrtoint ptr %t551 to i64
  store i64 %t552, ptr %l264, !tbaa !24
  %t553 = load i1, ptr @olang_2esole_2ecompiler_2fbindgen_3acMacro_2e2
  br i1 %t553, label %bb180, label %bb181
bb180:
  %t555 = call ptr @__olang_region_make(ptr %v0)
  %t556 = ptrtoint ptr %t555 to i64
  store i64 %t556, ptr %l264, !tbaa !24
  br label %bb181
bb181:
  %t557 = load ptr, ptr %l21, !tbaa !29
  %t558 = load i64, ptr %l264
  %t559 = inttoptr i64 %t558 to ptr
  %t561 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %v0, ptr %t559, ptr %t557)
  store { i64, ptr } %t561, ptr %l267
  br label %bb182
bb182:
  %t562 = call ptr @__olang_scope_hold(ptr %v1)
  %t563 = ptrtoint ptr %t562 to i64
  store i64 %t563, ptr %l268, !tbaa !24
  %t564 = load i1, ptr @olang_2esole_2ecompiler_2fbindgen_3acMacro_2e3
  br i1 %t564, label %bb183, label %bb184
bb183:
  %t566 = call ptr @__olang_region_make(ptr %v1)
  %t567 = ptrtoint ptr %t566 to i64
  store i64 %t567, ptr %l268, !tbaa !24
  br label %bb184
bb184:
  %t568 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t570 = call ptr @compiler_2fbindgen_2ecLex(ptr %v1, ptr %v1, { i64, ptr } %t568)
  store ptr %t570, ptr %l271
  br label %bb185
bb185:
  %t571 = load i64, ptr %l268
  %t572 = inttoptr i64 %t571 to ptr
  %t573 = load i64, ptr %l268
  %t574 = inttoptr i64 %t573 to ptr
  %t575 = load ptr, ptr %l271, !tbaa !29
  %t576 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %t572, ptr %t574, ptr %t575)
  store { i64, ptr } %t576, ptr %l272
  br label %bb186
bb186:
  %t577 = load ptr, ptr %lp5
  %t578 = load { i64, ptr }, ptr %t577, !tbaa !27
  %t579 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t582 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v4, ptr %v3, { i64, ptr } %t578, { i64, ptr } %t579)
  store i1 %t582, ptr %l275
  br label %bb187
bb187:
  %t583 = load i1, ptr %l275, !tbaa !21
  br i1 %t583, label %bb188, label %bb189
bb188:
  store i1 true, ptr %l276, !tbaa !21
  br label %bb191
bb189:
  %t584 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t586 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v3, ptr %s2, { i64, ptr } %t584, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d184, i32 0, i32 1) })
  store i1 %t586, ptr %l278
  br label %bb190
bb190:
  %t587 = load i1, ptr %l278, !tbaa !21
  store i1 %t587, ptr %l276, !tbaa !21
  br label %bb191
bb191:
  %t588 = load { i64, ptr }, ptr %l262, !tbaa !27
  %t589 = load i1, ptr %l263, !tbaa !21
  %t590 = load { i64, ptr }, ptr %l267, !tbaa !27
  %t591 = load { i64, ptr }, ptr %l272, !tbaa !27
  %t592 = load i1, ptr %l276, !tbaa !21
  %t593 = call %"compiler/bindgen:cMacro" @compiler_2fbindgen_3acMacro_2ector(ptr %v1, ptr %v0, ptr %v1, ptr %v0, { i64, ptr } %t588, i1 %t589, { i64, ptr } %t590, { i64, ptr } %t591, i1 %t592)
  store %"compiler/bindgen:cMacro" %t593, ptr %l279
  br label %bb192
bb192:
  %t594 = load %"compiler/bindgen:cMacro", ptr %l279
  %t595 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 64, i64 8)
  store %"compiler/bindgen:cMacro" %t594, ptr %t595
  store ptr %t595, ptr %l30, !tbaa !29
  %t597 = load ptr, ptr %l30, !tbaa !29
  %t598 = load i1, ptr %l22, !tbaa !21
  %t601 = getelementptr %"compiler/bindgen:cMacro", ptr %t597, i32 0, i32 5
  store i1 %t598, ptr %t601, !tbaa !21
  %t602 = load ptr, ptr %l0, !tbaa !29
  %t604 = getelementptr %"compiler/bindgen:gen", ptr %t602, i32 0, i32 14
  %t605 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t608 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9162e3b7f03fcbf954b681204d5f6cca(ptr %v0, ptr %v1, ptr %t604, { i64, ptr } %t605)
  %t609 = extractvalue { i32, i64 } %t608, 1
  %t610 = extractvalue { i32, i64 } %t608, 0
  store i32 %t610, ptr %l288
  %t611 = icmp ne i32 %t610, 0
  br i1 %t611, label %bb194, label %ok.612, !prof !99
ok.612:
  store i64 %t609, ptr %l287
  br label %bb193
bb193:
  %t613 = load i64, ptr %l287, !tbaa !24
  store i64 %t613, ptr %l283, !tbaa !24
  br label %bb196
bb194:
  br label %bb195
bb195:
  store i64 -1, ptr %l283, !tbaa !24
  br label %bb196
bb196:
  %t614 = load i64, ptr %l283, !tbaa !24
  store i64 %t614, ptr %l31, !tbaa !24
  %t615 = load i64, ptr %l31, !tbaa !24
  %t617 = icmp sge i64 %t615, 0
  br i1 %t617, label %bb197, label %bb198
bb197:
  %t619 = load ptr, ptr %l0, !tbaa !29
  %t621 = getelementptr %"compiler/bindgen:gen", ptr %t619, i32 0, i32 13
  %t622 = load i64, ptr %l31, !tbaa !24
  %t623 = load ptr, ptr %l30, !tbaa !29
  %t625 = load %"compiler/bindgen:cMacro", ptr %t623
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3acMacro_3e_2eSetAt_H7935c3ba4e105e8cc692de439d360efe(ptr %v0, ptr %v0, ptr %t621, i64 %t622, %"compiler/bindgen:cMacro" %t625)
  br label %bb199
bb198:
  %t629 = load ptr, ptr %l0, !tbaa !29
  %t631 = getelementptr %"compiler/bindgen:gen", ptr %t629, i32 0, i32 13
  %t632 = load ptr, ptr %l30, !tbaa !29
  %t634 = load %"compiler/bindgen:cMacro", ptr %t632
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3acMacro_3e_2ePush_3ccompiler_2fbindgen_3acMacro_3e(ptr %v0, ptr %v0, ptr %t631, %"compiler/bindgen:cMacro" %t634)
  br label %bb200
bb199:
  br label %bb203
bb200:
  %t637 = load ptr, ptr %l0, !tbaa !29
  %t639 = getelementptr %"compiler/bindgen:gen", ptr %t637, i32 0, i32 14
  store ptr %t639, ptr %l301, !tbaa !29
  %t640 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t640, ptr %l302, !tbaa !27
  %t641 = load ptr, ptr %l0, !tbaa !29
  %t643 = getelementptr %"compiler/bindgen:gen", ptr %t641, i32 0, i32 13
  %t645 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3acMacro_3e_2eLen_3ccompiler_2fbindgen_3acMacro_3e(ptr %v0, ptr %t643)
  store i64 %t645, ptr %l305
  br label %bb201
bb201:
  %t646 = load i64, ptr %l305, !tbaa !24
  %t647 = sub i64 %t646, 1
  %t648 = load ptr, ptr %l301, !tbaa !29
  %t649 = load { i64, ptr }, ptr %l302, !tbaa !27
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha091d021a90ce6aa48813730c00df6d2(ptr %v0, ptr %v1, ptr %t648, { i64, ptr } %t649, i64 %t647)
  br label %bb202
bb202:
  br label %bb203
bb203:
  call void @__olang_scope_close(ptr %s2)
  br label %bb204
bb204:
  br label %bb3
bb205:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2erecordDecl(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, { i64, ptr } %a2, i1 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i1
  %l4 = alloca i1
  %l5 = alloca i64
  %l9 = alloca i1
  %l12 = alloca i1
  %l14 = alloca i64
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca ptr
  %l19 = alloca { i64, ptr }
  %l21 = alloca i1
  %l24 = alloca i1
  %l27 = alloca i1
  %l29 = alloca i64
  %l31 = alloca { i64, ptr }
  %l33 = alloca i1
  %l35 = alloca i1
  %l37 = alloca ptr
  %l38 = alloca %"compiler/bindgen:record"
  %l41 = alloca i64
  %l44 = alloca ptr
  %l45 = alloca i64
  %l48 = alloca { i64, ptr }
  %l51 = alloca ptr
  %l53 = alloca { i64, ptr }
  %l57 = alloca i64
  %l62 = alloca ptr
  %l70 = alloca ptr
  %l74 = alloca i1
  %l76 = alloca i1
  %l80 = alloca %"compiler/bindgen:record"
  %l86 = alloca ptr
  %l90 = alloca { i64, ptr }
  %l98 = alloca { i64, ptr }
  %l102 = alloca { i64, ptr }
  %l104 = alloca i1
  %l109 = alloca ptr
  %l113 = alloca i1
  %l118 = alloca ptr
  %l122 = alloca i1
  %l123 = alloca i1
  %l125 = alloca { i64, ptr }
  %l127 = alloca i1
  %l130 = alloca i64
  %l132 = alloca i1
  %l133 = alloca ptr
  %l134 = alloca ptr
  %l136 = alloca { i64, ptr }
  %l140 = alloca i1
  %l145 = alloca ptr
  %l147 = alloca ptr
  %l149 = alloca { i64, ptr }
  %l151 = alloca i1
  %l152 = alloca i64
  %l155 = alloca i1
  %l160 = alloca ptr
  %l163 = alloca i64
  %l165 = alloca { i64, ptr }
  %l166 = alloca { i64, ptr }
  %l167 = alloca i64
  %l168 = alloca i32
  %l169 = alloca i64
  %l170 = alloca i32
  %l174 = alloca ptr
  %l176 = alloca ptr
  %l178 = alloca i1
  %l179 = alloca i64
  %l184 = alloca ptr
  %l186 = alloca ptr
  %l187 = alloca i64
  %l190 = alloca { i64, ptr }
  %l195 = alloca ptr
  %l197 = alloca ptr
  %l198 = alloca i64
  %l201 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %t15 = alloca %"compiler/bindgen:record", align 8
  %t20 = alloca %"compiler/bindgen:record", align 8
  %t115 = alloca %"compiler/bindgen:record", align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store i1 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = call { i64, ptr } @compiler_2fbindgen_2etext(ptr %v1, ptr %s0, ptr %s0, ptr %t1, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d185, i32 0, i32 1) })
  store { i64, ptr } %t3, ptr %l31
  br label %bb1
bb1:
  %t4 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t6 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t4, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d186, i32 0, i32 1) })
  store i1 %t6, ptr %l33
  br label %bb2
bb2:
  %t7 = load i1, ptr %l33, !tbaa !21
  store i1 %t7, ptr %l4, !tbaa !21
  store i64 0, ptr %l5, !tbaa !24
  %t8 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t10 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s0, { i64, ptr } %t8, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d187, i32 0, i32 1) })
  store i1 %t10, ptr %l35
  br label %bb3
bb3:
  %t11 = load i1, ptr %l35, !tbaa !21
  br i1 %t11, label %bb4, label %bb5
bb4:
  store %olang.scope zeroinitializer, ptr %s1
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/bindgen:gen", ptr %t12, i32 0, i32 6
  store ptr %t14, ptr %l37, !tbaa !29
  call void @compiler_2fbindgen_3arecord_2ector(ptr %t15, ptr %v0, ptr %v0, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d188, i32 0, i32 1) })
  call void @llvm.memmove.p0.p0.i64(ptr %l38, ptr %t15, i64 312, i1 false)
  br label %bb6
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  store ptr %t16, ptr %l51, !tbaa !29
  %t17 = load i1, ptr %l4, !tbaa !21
  br i1 %t17, label %bb13, label %bb14
bb6:
  %t19 = load ptr, ptr %l37, !tbaa !29
  call void @llvm.memmove.p0.p0.i64(ptr %t20, ptr %l38, i64 312, i1 false)
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2ePush_3ccompiler_2fbindgen_3arecord_3e(ptr %v0, ptr %v0, ptr %t19, ptr %t20)
  br label %bb7
bb7:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/bindgen:gen", ptr %t21, i32 0, i32 6
  %t25 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eLen_3ccompiler_2fbindgen_3arecord_3e(ptr %v0, ptr %t23)
  store i64 %t25, ptr %l41
  br label %bb8
bb8:
  %t26 = load i64, ptr %l41, !tbaa !24
  %t27 = sub i64 %t26, 1
  store i64 %t27, ptr %l5, !tbaa !24
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/bindgen:gen", ptr %t29, i32 0, i32 8
  store ptr %t31, ptr %l44, !tbaa !29
  %t32 = call ptr @__olang_scope_hold(ptr %v0)
  %t33 = ptrtoint ptr %t32 to i64
  store i64 %t33, ptr %l45, !tbaa !24
  %t34 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMapEntry_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e_2e0
  br i1 %t34, label %bb9, label %bb10
bb9:
  %t36 = call ptr @__olang_region_make(ptr %v0)
  %t37 = ptrtoint ptr %t36 to i64
  store i64 %t37, ptr %l45, !tbaa !24
  br label %bb10
bb10:
  %t38 = load ptr, ptr %l1, !tbaa !29
  %t39 = load i64, ptr %l45
  %t40 = inttoptr i64 %t39 to ptr
  %t42 = call { i64, ptr } @compiler_2fbindgen_2etext(ptr %v1, ptr %s1, ptr %t40, ptr %t38, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d189, i32 0, i32 1) })
  store { i64, ptr } %t42, ptr %l48
  br label %bb11
bb11:
  %t43 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t44 = load i64, ptr %l45
  %t45 = inttoptr i64 %t44 to ptr
  %t46 = extractvalue { i64, ptr } %t43, 0
  %t47 = extractvalue { i64, ptr } %t43, 1
  %t48 = mul i64 %t46, 1
  %t49 = call ptr @__olang_held_alloc(ptr %t45, i64 %t48)
  call void @llvm.memcpy.p0.p0.i64(ptr %t49, ptr %t47, i64 %t48, i1 false)
  %t50 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t51 = insertvalue { i64, ptr } %t50, ptr %t49, 1
  %t52 = load i64, ptr %l5, !tbaa !24
  %t53 = load ptr, ptr %l44, !tbaa !29
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha091d021a90ce6aa48813730c00df6d2(ptr %v0, ptr %v0, ptr %t53, { i64, ptr } %t51, i64 %t52)
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s1)
  br label %bb17
bb13:
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d190, i32 0, i32 1) }, ptr %l53, !tbaa !27
  br label %bb15
bb14:
  store { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d191, i32 0, i32 1) }, ptr %l53, !tbaa !27
  br label %bb15
bb15:
  %t56 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t57 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t58 = extractvalue { i64, ptr } %t57, 1
  %t59 = extractvalue { i64, ptr } %t57, 0
  %t61 = extractvalue { i64, ptr } %t56, 1
  %t62 = extractvalue { i64, ptr } %t56, 0
  %t63 = add i64 %t59, %t62
  %t64 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t63)
  call void @olang_textcopy(ptr %t64, ptr %t58, i64 %t59)
  %t65 = getelementptr i8, ptr %t64, i64 %t59
  call void @olang_textcopy(ptr %t65, ptr %t61, i64 %t62)
  %t66 = insertvalue { i64, ptr } undef, i64 %t63, 0
  %t67 = insertvalue { i64, ptr } %t66, ptr %t64, 1
  %t69 = load ptr, ptr %l51, !tbaa !29
  %t71 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2erecordAt(ptr %v0, ptr %v0, ptr %t69, { i64, ptr } %t67)
  store i64 %t71, ptr %l57
  br label %bb16
bb16:
  %t72 = load i64, ptr %l57, !tbaa !24
  store i64 %t72, ptr %l5, !tbaa !24
  br label %bb17
bb17:
  %t73 = load i64, ptr %l5, !tbaa !24
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = getelementptr %"compiler/bindgen:gen", ptr %t75, i32 0, i32 6
  %t81 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eRefMu_Hc21bcd245b67ffb6ee3e145838fcf2cf(ptr %v0, ptr %v0, ptr %t77, i64 %t73)
  store ptr %t81, ptr %l62
  br label %bb18
bb18:
  %t82 = load ptr, ptr %l62, !tbaa !29
  %t84 = load i1, ptr %l4, !tbaa !21
  %t87 = getelementptr %"compiler/bindgen:record", ptr %t82, i32 0, i32 1
  store i1 %t84, ptr %t87, !tbaa !21
  %t88 = load i1, ptr %l3, !tbaa !21
  br i1 %t88, label %bb19, label %bb20
bb19:
  %t90 = load i64, ptr %l5, !tbaa !24
  store i1 true, ptr %l9, !tbaa !21
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"compiler/bindgen:gen", ptr %t92, i32 0, i32 6
  %t98 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eRefMu_Hc21bcd245b67ffb6ee3e145838fcf2cf(ptr %v0, ptr %v0, ptr %t94, i64 %t90)
  store ptr %t98, ptr %l70
  br label %bb21
bb20:
  br label %bb22
bb21:
  %t99 = load ptr, ptr %l70, !tbaa !29
  %t101 = load i1, ptr %l9, !tbaa !21
  %t104 = getelementptr %"compiler/bindgen:record", ptr %t99, i32 0, i32 6
  store i1 %t101, ptr %t104, !tbaa !21
  br label %bb22
bb22:
  %t105 = load ptr, ptr %l1, !tbaa !29
  %t107 = call i1 @compiler_2fbindgen_2eflag(ptr %v1, ptr %s0, ptr %t105, { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d192, i32 0, i32 1) })
  store i1 %t107, ptr %l74
  br label %bb23
bb23:
  %t108 = load i1, ptr %l74, !tbaa !21
  %t109 = xor i1 %t108, true
  br i1 %t109, label %bb24, label %bb25
bb24:
  store i1 true, ptr %l76, !tbaa !21
  br label %bb27
bb25:
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t113 = getelementptr %"compiler/bindgen:gen", ptr %t111, i32 0, i32 6
  %t114 = load i64, ptr %l5, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eAt_3ccompiler_2fbindgen_3arecord_3e(ptr %t115, ptr %v0, ptr %s0, ptr %t113, i64 %t114)
  call void @llvm.memmove.p0.p0.i64(ptr %l80, ptr %t115, i64 312, i1 false)
  br label %bb26
bb26:
  %t118 = getelementptr %"compiler/bindgen:record", ptr %l80, i32 0, i32 2
  %t119 = load i1, ptr %t118, !tbaa !21
  store i1 %t119, ptr %l76, !tbaa !21
  br label %bb27
bb27:
  %t121 = load i1, ptr %l76, !tbaa !21
  br i1 %t121, label %bb28, label %bb29
bb28:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb29:
  br label %bb30
bb30:
  %t122 = load i64, ptr %l5, !tbaa !24
  store i1 true, ptr %l12, !tbaa !21
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t126 = getelementptr %"compiler/bindgen:gen", ptr %t124, i32 0, i32 6
  %t130 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eRefMu_Hc21bcd245b67ffb6ee3e145838fcf2cf(ptr %v0, ptr %v0, ptr %t126, i64 %t122)
  store ptr %t130, ptr %l86
  br label %bb31
bb31:
  %t131 = load ptr, ptr %l86, !tbaa !29
  %t133 = load i1, ptr %l12, !tbaa !21
  %t136 = getelementptr %"compiler/bindgen:record", ptr %t131, i32 0, i32 2
  store i1 %t133, ptr %t136, !tbaa !21
  store i64 -1, ptr %l14, !tbaa !24
  store %olang.scope zeroinitializer, ptr %s6
  %t137 = load ptr, ptr %l1, !tbaa !29
  %t139 = call { i64, ptr } @compiler_2fbindgen_2einner(ptr %v1, ptr %s6, ptr %t137)
  store { i64, ptr } %t139, ptr %l90
  br label %bb32
bb32:
  %t140 = load { i64, ptr }, ptr %l90, !tbaa !27
  store { i64, ptr } %t140, ptr %l15, !tbaa !27
  store i64 0, ptr %l16, !tbaa !24
  %t142 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t144 = extractvalue { i64, ptr } %t142, 0
  store i64 %t144, ptr %l17, !tbaa !24
  br label %bb33
bb33:
  store %olang.scope zeroinitializer, ptr %s7
  %t146 = load i64, ptr %l16, !tbaa !24
  %t147 = load i64, ptr %l17, !tbaa !24
  %t150 = icmp slt i64 %t146, %t147
  %t152 = xor i1 %t150, true
  br i1 %t152, label %bb34, label %bb35
bb34:
  call void @__olang_scope_close(ptr %s7)
  br label %bb104
bb35:
  br label %bb36
bb36:
  %t154 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t154, ptr %l98, !tbaa !27
  %t155 = load i64, ptr %l16, !tbaa !24
  %t157 = getelementptr { i64, ptr }, ptr %l98, i32 0, i32 1
  %t158 = load ptr, ptr %t157, !tbaa !27
  %t159 = getelementptr ptr, ptr %t158, i64 %t155
  %t160 = load ptr, ptr %t159, !tbaa !39
  store ptr %t160, ptr %l18, !tbaa !29
  %t162 = load ptr, ptr %l18, !tbaa !29
  %t164 = call { i64, ptr } @compiler_2fbindgen_2etext(ptr %s6, ptr %s7, ptr %s7, ptr %t162, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d193, i32 0, i32 1) })
  store { i64, ptr } %t164, ptr %l102
  br label %bb37
bb37:
  %t165 = load { i64, ptr }, ptr %l102, !tbaa !27
  store { i64, ptr } %t165, ptr %l19, !tbaa !27
  %t166 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t168 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s7, ptr %s7, { i64, ptr } %t166, { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d194, i32 0, i32 1) })
  store i1 %t168, ptr %l104
  br label %bb38
bb38:
  %t169 = load i1, ptr %l104, !tbaa !21
  br i1 %t169, label %bb39, label %bb40
bb39:
  %t170 = load i64, ptr %l5, !tbaa !24
  store i1 true, ptr %l21, !tbaa !21
  %t172 = load ptr, ptr %l0, !tbaa !29
  %t174 = getelementptr %"compiler/bindgen:gen", ptr %t172, i32 0, i32 6
  %t178 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eRefMu_Hc21bcd245b67ffb6ee3e145838fcf2cf(ptr %v0, ptr %v0, ptr %t174, i64 %t170)
  store ptr %t178, ptr %l109
  br label %bb41
bb40:
  br label %bb42
bb41:
  %t179 = load ptr, ptr %l109, !tbaa !29
  %t181 = load i1, ptr %l21, !tbaa !21
  %t184 = getelementptr %"compiler/bindgen:record", ptr %t179, i32 0, i32 12
  store i1 %t181, ptr %t184, !tbaa !21
  br label %bb42
bb42:
  %t185 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t187 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s7, ptr %s7, { i64, ptr } %t185, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d195, i32 0, i32 1) })
  store i1 %t187, ptr %l113
  br label %bb43
bb43:
  %t188 = load i1, ptr %l113, !tbaa !21
  br i1 %t188, label %bb44, label %bb45
bb44:
  %t189 = load i64, ptr %l5, !tbaa !24
  store i1 true, ptr %l24, !tbaa !21
  %t191 = load ptr, ptr %l0, !tbaa !29
  %t193 = getelementptr %"compiler/bindgen:gen", ptr %t191, i32 0, i32 6
  %t197 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eRefMu_Hc21bcd245b67ffb6ee3e145838fcf2cf(ptr %v0, ptr %v0, ptr %t193, i64 %t189)
  store ptr %t197, ptr %l118
  br label %bb46
bb45:
  br label %bb47
bb46:
  %t198 = load ptr, ptr %l118, !tbaa !29
  %t200 = load i1, ptr %l24, !tbaa !21
  %t203 = getelementptr %"compiler/bindgen:record", ptr %t198, i32 0, i32 15
  store i1 %t200, ptr %t203, !tbaa !21
  br label %bb47
bb47:
  %t204 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t206 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s7, ptr %s7, { i64, ptr } %t204, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d196, i32 0, i32 1) })
  store i1 %t206, ptr %l122
  br label %bb48
bb48:
  %t207 = load i1, ptr %l122, !tbaa !21
  br i1 %t207, label %bb49, label %bb50
bb49:
  %t208 = load ptr, ptr %l18, !tbaa !29
  %t210 = call { i64, ptr } @compiler_2fbindgen_2etext(ptr %s6, ptr %s7, ptr %s7, ptr %t208, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d197, i32 0, i32 1) })
  store { i64, ptr } %t210, ptr %l125
  br label %bb51
bb50:
  store i1 false, ptr %l123, !tbaa !21
  br label %bb53
bb51:
  %t211 = load { i64, ptr }, ptr %l125, !tbaa !27
  %t213 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s7, ptr %s7, { i64, ptr } %t211, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d198, i32 0, i32 1) })
  store i1 %t213, ptr %l127
  br label %bb52
bb52:
  %t214 = load i1, ptr %l127, !tbaa !21
  store i1 %t214, ptr %l123, !tbaa !21
  br label %bb53
bb53:
  %t215 = load i1, ptr %l123, !tbaa !21
  br i1 %t215, label %bb54, label %bb55
bb54:
  %t216 = load ptr, ptr %l0, !tbaa !29
  %t218 = getelementptr %"compiler/bindgen:gen", ptr %t216, i32 0, i32 6
  %t220 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eLen_3ccompiler_2fbindgen_3arecord_3e(ptr %v0, ptr %t218)
  store i64 %t220, ptr %l130
  br label %bb56
bb55:
  br label %bb57
bb56:
  %t221 = load i64, ptr %l130, !tbaa !24
  store i64 %t221, ptr %l14, !tbaa !24
  br label %bb57
bb57:
  %t222 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t224 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s7, ptr %s7, { i64, ptr } %t222, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d199, i32 0, i32 1) })
  store i1 %t224, ptr %l132
  br label %bb58
bb58:
  %t225 = load i1, ptr %l132, !tbaa !21
  br i1 %t225, label %bb59, label %bb60
bb59:
  store %olang.scope zeroinitializer, ptr %s11
  %t226 = load ptr, ptr %l0, !tbaa !29
  store ptr %t226, ptr %l133, !tbaa !29
  %t227 = load ptr, ptr %l18, !tbaa !29
  store ptr %t227, ptr %l134, !tbaa !29
  %t228 = load ptr, ptr %l18, !tbaa !29
  %t230 = call { i64, ptr } @compiler_2fbindgen_2etext(ptr %s6, ptr %s11, ptr %s11, ptr %t228, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d200, i32 0, i32 1) })
  store { i64, ptr } %t230, ptr %l136
  br label %bb61
bb60:
  br label %bb63
bb61:
  %t231 = load { i64, ptr }, ptr %l136, !tbaa !27
  %t232 = load i1, ptr %l3, !tbaa !21
  %t233 = load ptr, ptr %l133, !tbaa !29
  %t234 = load ptr, ptr %l134, !tbaa !29
  call void @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2erecordDecl(ptr %v0, ptr %s6, ptr %s11, ptr %t233, ptr %t234, { i64, ptr } %t231, i1 %t232)
  br label %bb62
bb62:
  call void @__olang_scope_close(ptr %s11)
  br label %bb63
bb63:
  %t237 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t239 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s7, ptr %s7, { i64, ptr } %t237, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d201, i32 0, i32 1) })
  store i1 %t239, ptr %l140
  br label %bb64
bb64:
  %t240 = load i1, ptr %l140, !tbaa !21
  %t241 = xor i1 %t240, true
  br i1 %t241, label %bb65, label %bb66
bb65:
  call void @__olang_scope_close(ptr %s7)
  br label %bb103
bb66:
  br label %bb67
bb67:
  %t243 = load ptr, ptr %l0, !tbaa !29
  %t245 = getelementptr %"compiler/bindgen:gen", ptr %t243, i32 0, i32 6
  %t246 = load i64, ptr %l5, !tbaa !24
  %t249 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eRefMu_Hc21bcd245b67ffb6ee3e145838fcf2cf(ptr %v0, ptr %v0, ptr %t245, i64 %t246)
  store ptr %t249, ptr %l145
  br label %bb68
bb68:
  %t250 = load ptr, ptr %l145, !tbaa !29
  %t252 = getelementptr %"compiler/bindgen:record", ptr %t250, i32 0, i32 17
  store ptr %t252, ptr %l147, !tbaa !29
  %t253 = load ptr, ptr %l18, !tbaa !29
  %t255 = call { i64, ptr } @compiler_2fbindgen_2etext(ptr %s6, ptr %s7, ptr %s7, ptr %t253, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d202, i32 0, i32 1) })
  store { i64, ptr } %t255, ptr %l149
  br label %bb69
bb69:
  %t256 = load { i64, ptr }, ptr %l149, !tbaa !27
  %t258 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s7, ptr %s7, { i64, ptr } %t256, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d203, i32 0, i32 1) })
  store i1 %t258, ptr %l151
  br label %bb70
bb70:
  %t259 = load i1, ptr %l151, !tbaa !21
  br i1 %t259, label %bb71, label %bb72
bb71:
  %t260 = load i64, ptr %l14, !tbaa !24
  store i64 %t260, ptr %l152, !tbaa !24
  br label %bb73
bb72:
  store i64 -1, ptr %l152, !tbaa !24
  br label %bb73
bb73:
  %t262 = load ptr, ptr %l147, !tbaa !29
  %t263 = load i64, ptr %l152, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t262, i64 %t263)
  br label %bb74
bb74:
  %t264 = load ptr, ptr %l18, !tbaa !29
  %t266 = call i1 @compiler_2fbindgen_2eflag(ptr %s6, ptr %s7, ptr %t264, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d204, i32 0, i32 1) })
  store i1 %t266, ptr %l155
  br label %bb75
bb75:
  %t267 = load i1, ptr %l155, !tbaa !21
  br i1 %t267, label %bb76, label %bb77
bb76:
  %t268 = load i64, ptr %l5, !tbaa !24
  store i1 true, ptr %l27, !tbaa !21
  %t270 = load ptr, ptr %l0, !tbaa !29
  %t272 = getelementptr %"compiler/bindgen:gen", ptr %t270, i32 0, i32 6
  %t276 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eRefMu_Hc21bcd245b67ffb6ee3e145838fcf2cf(ptr %v0, ptr %v0, ptr %t272, i64 %t268)
  store ptr %t276, ptr %l160
  br label %bb78
bb77:
  br label %bb79
bb78:
  %t277 = load ptr, ptr %l160, !tbaa !29
  %t279 = load i1, ptr %l27, !tbaa !21
  %t282 = getelementptr %"compiler/bindgen:record", ptr %t277, i32 0, i32 3
  store i1 %t279, ptr %t282, !tbaa !21
  br label %bb79
bb79:
  %t283 = load ptr, ptr %l18, !tbaa !29
  %t285 = call { i64, ptr } @compiler_2fbindgen_2econstValue(ptr %s6, ptr %s7, ptr %t283)
  store { i64, ptr } %t285, ptr %l165
  br label %bb80
bb80:
  %t286 = load { i64, ptr }, ptr %l165, !tbaa !27
  store { i64, ptr } %t286, ptr %l166, !tbaa !27
  %t287 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s7, i64 10)
  %t288 = extractvalue { i32, i64 } %t287, 1
  %t289 = extractvalue { i32, i64 } %t287, 0
  store i32 %t289, ptr %l168
  %t290 = icmp ne i32 %t289, 0
  br i1 %t290, label %bb82, label %ok.291, !prof !99
ok.291:
  store i64 %t288, ptr %l167
  br label %bb81
bb81:
  %t292 = load { i64, ptr }, ptr %l166, !tbaa !27
  %t293 = load i64, ptr %l167, !tbaa !24
  %t294 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %s7, { i64, ptr } %t292, i64 %t293)
  %t295 = extractvalue { i32, i64 } %t294, 1
  %t296 = extractvalue { i32, i64 } %t294, 0
  store i32 %t296, ptr %l170
  %t297 = icmp ne i32 %t296, 0
  br i1 %t297, label %bb85, label %ok.298, !prof !99
ok.298:
  store i64 %t295, ptr %l169
  br label %bb84
bb82:
  br label %bb83
bb83:
  store i64 -1, ptr %l163, !tbaa !24
  br label %bb86
bb84:
  %t299 = load i64, ptr %l169, !tbaa !24
  store i64 %t299, ptr %l163, !tbaa !24
  br label %bb86
bb85:
  br label %bb83
bb86:
  %t300 = load i64, ptr %l163, !tbaa !24
  store i64 %t300, ptr %l29, !tbaa !24
  %t301 = load ptr, ptr %l0, !tbaa !29
  %t303 = getelementptr %"compiler/bindgen:gen", ptr %t301, i32 0, i32 6
  %t304 = load i64, ptr %l5, !tbaa !24
  %t307 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eRefMu_Hc21bcd245b67ffb6ee3e145838fcf2cf(ptr %v0, ptr %v0, ptr %t303, i64 %t304)
  store ptr %t307, ptr %l174
  br label %bb87
bb87:
  %t308 = load ptr, ptr %l174, !tbaa !29
  %t310 = getelementptr %"compiler/bindgen:record", ptr %t308, i32 0, i32 16
  store ptr %t310, ptr %l176, !tbaa !29
  %t311 = load ptr, ptr %l18, !tbaa !29
  %t313 = call i1 @compiler_2fbindgen_2eflag(ptr %s6, ptr %s7, ptr %t311, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d205, i32 0, i32 1) })
  store i1 %t313, ptr %l178
  br label %bb88
bb88:
  %t314 = load i1, ptr %l178, !tbaa !21
  br i1 %t314, label %bb89, label %bb90
bb89:
  %t315 = load i64, ptr %l29, !tbaa !24
  store i64 %t315, ptr %l179, !tbaa !24
  br label %bb91
bb90:
  store i64 -1, ptr %l179, !tbaa !24
  br label %bb91
bb91:
  %t317 = load ptr, ptr %l176, !tbaa !29
  %t318 = load i64, ptr %l179, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t317, i64 %t318)
  br label %bb92
bb92:
  %t319 = load ptr, ptr %l0, !tbaa !29
  %t321 = getelementptr %"compiler/bindgen:gen", ptr %t319, i32 0, i32 6
  %t322 = load i64, ptr %l5, !tbaa !24
  %t325 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eRefMu_Hc21bcd245b67ffb6ee3e145838fcf2cf(ptr %v0, ptr %v0, ptr %t321, i64 %t322)
  store ptr %t325, ptr %l184
  br label %bb93
bb93:
  %t326 = load ptr, ptr %l184, !tbaa !29
  %t328 = getelementptr %"compiler/bindgen:record", ptr %t326, i32 0, i32 4
  store ptr %t328, ptr %l186, !tbaa !29
  %t329 = call ptr @__olang_scope_hold(ptr %v0)
  %t330 = ptrtoint ptr %t329 to i64
  store i64 %t330, ptr %l187, !tbaa !24
  %t331 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t331, label %bb94, label %bb95
bb94:
  %t333 = call ptr @__olang_region_make(ptr %v0)
  %t334 = ptrtoint ptr %t333 to i64
  store i64 %t334, ptr %l187, !tbaa !24
  br label %bb95
bb95:
  %t335 = load ptr, ptr %l18, !tbaa !29
  %t336 = load i64, ptr %l187
  %t337 = inttoptr i64 %t336 to ptr
  %t339 = call { i64, ptr } @compiler_2fbindgen_2etext(ptr %s6, ptr %s7, ptr %t337, ptr %t335, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d206, i32 0, i32 1) })
  store { i64, ptr } %t339, ptr %l190
  br label %bb96
bb96:
  %t340 = load { i64, ptr }, ptr %l190, !tbaa !27
  %t341 = load i64, ptr %l187
  %t342 = inttoptr i64 %t341 to ptr
  %t343 = extractvalue { i64, ptr } %t340, 0
  %t344 = extractvalue { i64, ptr } %t340, 1
  %t345 = mul i64 %t343, 1
  %t346 = call ptr @__olang_held_alloc(ptr %t342, i64 %t345)
  call void @llvm.memcpy.p0.p0.i64(ptr %t346, ptr %t344, i64 %t345, i1 false)
  %t347 = insertvalue { i64, ptr } undef, i64 %t343, 0
  %t348 = insertvalue { i64, ptr } %t347, ptr %t346, 1
  %t349 = load ptr, ptr %l186, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v0, ptr %t349, { i64, ptr } %t348)
  br label %bb97
bb97:
  %t351 = load ptr, ptr %l0, !tbaa !29
  %t353 = getelementptr %"compiler/bindgen:gen", ptr %t351, i32 0, i32 6
  %t354 = load i64, ptr %l5, !tbaa !24
  %t357 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eRefMu_Hc21bcd245b67ffb6ee3e145838fcf2cf(ptr %v0, ptr %v0, ptr %t353, i64 %t354)
  store ptr %t357, ptr %l195
  br label %bb98
bb98:
  %t358 = load ptr, ptr %l195, !tbaa !29
  %t360 = getelementptr %"compiler/bindgen:record", ptr %t358, i32 0, i32 5
  store ptr %t360, ptr %l197, !tbaa !29
  %t361 = call ptr @__olang_scope_hold(ptr %v0)
  %t362 = ptrtoint ptr %t361 to i64
  store i64 %t362, ptr %l198, !tbaa !24
  %t363 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t363, label %bb99, label %bb100
bb99:
  %t365 = call ptr @__olang_region_make(ptr %v0)
  %t366 = ptrtoint ptr %t365 to i64
  store i64 %t366, ptr %l198, !tbaa !24
  br label %bb100
bb100:
  %t367 = load ptr, ptr %l18, !tbaa !29
  %t368 = load i64, ptr %l198
  %t369 = inttoptr i64 %t368 to ptr
  %t371 = call { i64, ptr } @compiler_2fbindgen_2etypeOf(ptr %s6, ptr %t369, ptr %t367)
  store { i64, ptr } %t371, ptr %l201
  br label %bb101
bb101:
  %t372 = load { i64, ptr }, ptr %l201, !tbaa !27
  %t373 = load i64, ptr %l198
  %t374 = inttoptr i64 %t373 to ptr
  %t375 = extractvalue { i64, ptr } %t372, 0
  %t376 = extractvalue { i64, ptr } %t372, 1
  %t377 = mul i64 %t375, 1
  %t378 = call ptr @__olang_held_alloc(ptr %t374, i64 %t377)
  call void @llvm.memcpy.p0.p0.i64(ptr %t378, ptr %t376, i64 %t377, i1 false)
  %t379 = insertvalue { i64, ptr } undef, i64 %t375, 0
  %t380 = insertvalue { i64, ptr } %t379, ptr %t378, 1
  %t381 = load ptr, ptr %l197, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v0, ptr %t381, { i64, ptr } %t380)
  br label %bb102
bb102:
  call void @__olang_scope_close(ptr %s7)
  br label %bb103
bb103:
  %t383 = load i64, ptr %l16, !tbaa !24
  %t386 = add i64 %t383, 1
  store i64 %t386, ptr %l16, !tbaa !24
  br label %bb33
bb104:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2estructDecl(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca i1
  %l4 = alloca %"compiler/bindgen:record"
  %l5 = alloca ptr
  %l6 = alloca i64
  %l9 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca %"std/prelude/text:StringBuilder"
  %l19 = alloca i1
  %l23 = alloca %"compiler/bindgen:record"
  %l24 = alloca %"compiler/bindgen:record"
  %l25 = alloca i64
  %l27 = alloca { i64, ptr }
  %l28 = alloca i64
  %l29 = alloca { i64, ptr }
  %l33 = alloca i64
  %l35 = alloca { i64, ptr }
  %l36 = alloca i64
  %l37 = alloca { i64, ptr }
  %l41 = alloca i64
  %l43 = alloca { i64, ptr }
  %l44 = alloca i64
  %l45 = alloca { i64, ptr }
  %l49 = alloca i64
  %l51 = alloca { i64, ptr }
  %l52 = alloca i64
  %l53 = alloca { i64, ptr }
  %l57 = alloca i64
  %l59 = alloca { i64, ptr }
  %l60 = alloca i64
  %l61 = alloca { i64, ptr }
  %l65 = alloca i64
  %l67 = alloca { i64, ptr }
  %l68 = alloca i64
  %l69 = alloca { i64, ptr }
  %l74 = alloca i1
  %l82 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l84 = alloca i64
  %l86 = alloca i64
  %l91 = alloca { i64, ptr }
  %l99 = alloca { i64, ptr }
  %l108 = alloca { i64, ptr }
  %l111 = alloca { i64, ptr }
  %l114 = alloca { i64, ptr }
  %l122 = alloca ptr
  %l125 = alloca { i64, ptr }
  %l128 = alloca { i64, ptr }
  %l131 = alloca i1
  %l132 = alloca ptr
  %l135 = alloca { i64, ptr }
  %l138 = alloca ptr
  %l141 = alloca { i64, ptr }
  %l144 = alloca { i64, ptr }
  %l145 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l147 = alloca i64
  %l151 = alloca i64
  %l154 = alloca i64
  %l172 = alloca ptr
  %l173 = alloca ptr
  %l174 = alloca ptr
  %l177 = alloca { i64, ptr }
  %l180 = alloca { i64, ptr }
  %l181 = alloca { i64, ptr }
  %l184 = alloca { i64, ptr }
  %l185 = alloca { i64, ptr }
  %l192 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  %t13 = alloca %"compiler/bindgen:record", align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l16
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l16
  store %"std/prelude/text:StringBuilder" %t2, ptr %l2
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call i1 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eplain(ptr %v0, ptr %t3, i64 %t4)
  store i1 %t7, ptr %l19
  br label %bb2
bb2:
  %t8 = load i1, ptr %l19, !tbaa !21
  store i1 %t8, ptr %l3, !tbaa !21
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/bindgen:gen", ptr %t9, i32 0, i32 6
  %t12 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eAt_3ccompiler_2fbindgen_3arecord_3e(ptr %t13, ptr %v0, ptr %v0, ptr %t11, i64 %t12)
  call void @llvm.memmove.p0.p0.i64(ptr %l23, ptr %t13, i64 312, i1 false)
  br label %bb3
bb3:
  call void @llvm.memmove.p0.p0.i64(ptr %l24, ptr %l23, i64 312, i1 false)
  %t16 = call ptr @__olang_scope_hold(ptr %v0)
  %t17 = ptrtoint ptr %t16 to i64
  store i64 %t17, ptr %l25, !tbaa !24
  %t18 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e0
  br i1 %t18, label %bb4, label %bb5
bb4:
  %t20 = call ptr @__olang_region_make_part(ptr %v0)
  %t21 = ptrtoint ptr %t20 to i64
  store i64 %t21, ptr %l25, !tbaa !24
  br label %bb5
bb5:
  %t22 = getelementptr %"compiler/bindgen:record", ptr %l24, i32 0, i32 4
  %t23 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t22, i32 0, i32 0
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  store { i64, ptr } %t24, ptr %l27, !tbaa !27
  %t25 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t25, 0
  store i64 %t26, ptr %l28, !tbaa !24
  %t27 = load i64, ptr %l28, !tbaa !24
  %t28 = mul i64 %t27, 16
  %t29 = load i64, ptr %l25
  %t30 = inttoptr i64 %t29 to ptr
  %t31 = call ptr @__olang_held_alloc(ptr %t30, i64 %t28)
  %t32 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t33 = insertvalue { i64, ptr } %t32, ptr %t31, 1
  store { i64, ptr } %t33, ptr %l29, !tbaa !27
  %t34 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !27
  %t36 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !27
  %t38 = load i64, ptr %l28, !tbaa !24
  %t39 = mul i64 %t38, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t35, ptr %t37, i64 %t39, i1 false)
  %t40 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t41 = getelementptr %"compiler/bindgen:record", ptr %l24, i32 0, i32 4
  %t42 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t41, i32 0, i32 0
  store { i64, ptr } %t40, ptr %t42, !tbaa !27
  %t43 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e0
  br i1 %t43, label %bb6, label %bb7
bb6:
  %t45 = getelementptr %"compiler/bindgen:record", ptr %l24, i32 0, i32 4
  %t46 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t45, i32 0, i32 0
  %t47 = load { i64, ptr }, ptr %t46, !tbaa !27
  %t48 = extractvalue { i64, ptr } %t47, 0
  %t50 = icmp eq i64 %t48, 0
  br i1 %t50, label %bb8, label %bb9
bb7:
  %t52 = call ptr @__olang_scope_hold(ptr %v0)
  %t53 = ptrtoint ptr %t52 to i64
  store i64 %t53, ptr %l33, !tbaa !24
  %t54 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e0
  br i1 %t54, label %bb10, label %bb11
bb8:
  %t56 = getelementptr %"compiler/bindgen:record", ptr %l24, i32 0, i32 4
  %t57 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t56, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t57, !tbaa !27
  br label %bb9
bb9:
  %t58 = getelementptr %"compiler/bindgen:record", ptr %l24, i32 0, i32 4
  %t59 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t58, i32 0, i32 0
  %t60 = load i64, ptr %l25
  %t61 = inttoptr i64 %t60 to ptr
  %t62 = load { i64, ptr }, ptr %t59
  %t63 = extractvalue { i64, ptr } %t62, 1
  %t64 = call ptr @__olang_region_or(ptr %t63, ptr null)
  %t65 = icmp ne ptr %t64, null
  %t66 = select i1 %t65, ptr %t64, ptr null
  call void @__olang_region_settle_in(ptr %t61, ptr %t66)
  br label %bb7
bb10:
  %t67 = call ptr @__olang_region_make_part(ptr %v0)
  %t68 = ptrtoint ptr %t67 to i64
  store i64 %t68, ptr %l33, !tbaa !24
  br label %bb11
bb11:
  %t69 = getelementptr %"compiler/bindgen:record", ptr %l24, i32 0, i32 5
  %t70 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t69, i32 0, i32 0
  %t71 = load { i64, ptr }, ptr %t70, !tbaa !27
  store { i64, ptr } %t71, ptr %l35, !tbaa !27
  %t72 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t73 = extractvalue { i64, ptr } %t72, 0
  store i64 %t73, ptr %l36, !tbaa !24
  %t74 = load i64, ptr %l36, !tbaa !24
  %t75 = mul i64 %t74, 16
  %t76 = load i64, ptr %l33
  %t77 = inttoptr i64 %t76 to ptr
  %t78 = call ptr @__olang_held_alloc(ptr %t77, i64 %t75)
  %t79 = insertvalue { i64, ptr } undef, i64 %t74, 0
  %t80 = insertvalue { i64, ptr } %t79, ptr %t78, 1
  store { i64, ptr } %t80, ptr %l37, !tbaa !27
  %t81 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !27
  %t83 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t84 = load ptr, ptr %t83, !tbaa !27
  %t85 = load i64, ptr %l36, !tbaa !24
  %t86 = mul i64 %t85, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t82, ptr %t84, i64 %t86, i1 false)
  %t87 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t88 = getelementptr %"compiler/bindgen:record", ptr %l24, i32 0, i32 5
  %t89 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t88, i32 0, i32 0
  store { i64, ptr } %t87, ptr %t89, !tbaa !27
  %t90 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e0
  br i1 %t90, label %bb12, label %bb13
bb12:
  %t92 = getelementptr %"compiler/bindgen:record", ptr %l24, i32 0, i32 5
  %t93 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t92, i32 0, i32 0
  %t94 = load { i64, ptr }, ptr %t93, !tbaa !27
  %t95 = extractvalue { i64, ptr } %t94, 0
  %t97 = icmp eq i64 %t95, 0
  br i1 %t97, label %bb14, label %bb15
bb13:
  %t99 = call ptr @__olang_scope_hold(ptr %v0)
  %t100 = ptrtoint ptr %t99 to i64
  store i64 %t100, ptr %l41, !tbaa !24
  %t101 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t101, label %bb16, label %bb17
bb14:
  %t103 = getelementptr %"compiler/bindgen:record", ptr %l24, i32 0, i32 5
  %t104 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t103, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t104, !tbaa !27
  br label %bb15
bb15:
  %t105 = getelementptr %"compiler/bindgen:record", ptr %l24, i32 0, i32 5
  %t106 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t105, i32 0, i32 0
  %t107 = load i64, ptr %l33
  %t108 = inttoptr i64 %t107 to ptr
  %t109 = load { i64, ptr }, ptr %t106
  %t110 = extractvalue { i64, ptr } %t109, 1
  %t111 = call ptr @__olang_region_or(ptr %t110, ptr null)
  %t112 = icmp ne ptr %t111, null
  %t113 = select i1 %t112, ptr %t111, ptr null
  call void @__olang_region_settle_in(ptr %t108, ptr %t113)
  br label %bb13
bb16:
  %t114 = call ptr @__olang_region_make_part(ptr %v0)
  %t115 = ptrtoint ptr %t114 to i64
  store i64 %t115, ptr %l41, !tbaa !24
  br label %bb17
bb17:
  %t116 = getelementptr %"compiler/bindgen:record", ptr %l24, i32 0, i32 16
  %t117 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t116, i32 0, i32 0
  %t118 = load { i64, ptr }, ptr %t117, !tbaa !27
  store { i64, ptr } %t118, ptr %l43, !tbaa !27
  %t119 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t120 = extractvalue { i64, ptr } %t119, 0
  store i64 %t120, ptr %l44, !tbaa !24
  %t121 = load i64, ptr %l44, !tbaa !24
  %t122 = mul i64 %t121, 8
  %t123 = load i64, ptr %l41
  %t124 = inttoptr i64 %t123 to ptr
  %t125 = call ptr @__olang_held_alloc(ptr %t124, i64 %t122)
  %t126 = insertvalue { i64, ptr } undef, i64 %t121, 0
  %t127 = insertvalue { i64, ptr } %t126, ptr %t125, 1
  store { i64, ptr } %t127, ptr %l45, !tbaa !27
  %t128 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t129 = load ptr, ptr %t128, !tbaa !27
  %t130 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t131 = load ptr, ptr %t130, !tbaa !27
  %t132 = load i64, ptr %l44, !tbaa !24
  %t133 = mul i64 %t132, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t129, ptr %t131, i64 %t133, i1 false)
  %t134 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t135 = getelementptr %"compiler/bindgen:record", ptr %l24, i32 0, i32 16
  %t136 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t135, i32 0, i32 0
  store { i64, ptr } %t134, ptr %t136, !tbaa !27
  %t137 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t137, label %bb18, label %bb19
bb18:
  %t139 = getelementptr %"compiler/bindgen:record", ptr %l24, i32 0, i32 16
  %t140 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t139, i32 0, i32 0
  %t141 = load { i64, ptr }, ptr %t140, !tbaa !27
  %t142 = extractvalue { i64, ptr } %t141, 0
  %t144 = icmp eq i64 %t142, 0
  br i1 %t144, label %bb20, label %bb21
bb19:
  %t146 = call ptr @__olang_scope_hold(ptr %v0)
  %t147 = ptrtoint ptr %t146 to i64
  store i64 %t147, ptr %l49, !tbaa !24
  %t148 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t148, label %bb22, label %bb23
bb20:
  %t150 = getelementptr %"compiler/bindgen:record", ptr %l24, i32 0, i32 16
  %t151 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t150, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t151, !tbaa !27
  br label %bb21
bb21:
  %t152 = getelementptr %"compiler/bindgen:record", ptr %l24, i32 0, i32 16
  %t153 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t152, i32 0, i32 0
  %t154 = load i64, ptr %l41
  %t155 = inttoptr i64 %t154 to ptr
  %t156 = load { i64, ptr }, ptr %t153
  %t157 = extractvalue { i64, ptr } %t156, 1
  %t158 = call ptr @__olang_region_or(ptr %t157, ptr null)
  %t159 = icmp ne ptr %t158, null
  %t160 = select i1 %t159, ptr %t158, ptr null
  call void @__olang_region_settle_in(ptr %t155, ptr %t160)
  br label %bb19
bb22:
  %t161 = call ptr @__olang_region_make_part(ptr %v0)
  %t162 = ptrtoint ptr %t161 to i64
  store i64 %t162, ptr %l49, !tbaa !24
  br label %bb23
bb23:
  %t163 = getelementptr %"compiler/bindgen:record", ptr %l24, i32 0, i32 17
  %t164 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t163, i32 0, i32 0
  %t165 = load { i64, ptr }, ptr %t164, !tbaa !27
  store { i64, ptr } %t165, ptr %l51, !tbaa !27
  %t166 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t167 = extractvalue { i64, ptr } %t166, 0
  store i64 %t167, ptr %l52, !tbaa !24
  %t168 = load i64, ptr %l52, !tbaa !24
  %t169 = mul i64 %t168, 8
  %t170 = load i64, ptr %l49
  %t171 = inttoptr i64 %t170 to ptr
  %t172 = call ptr @__olang_held_alloc(ptr %t171, i64 %t169)
  %t173 = insertvalue { i64, ptr } undef, i64 %t168, 0
  %t174 = insertvalue { i64, ptr } %t173, ptr %t172, 1
  store { i64, ptr } %t174, ptr %l53, !tbaa !27
  %t175 = getelementptr { i64, ptr }, ptr %l53, i32 0, i32 1
  %t176 = load ptr, ptr %t175, !tbaa !27
  %t177 = getelementptr { i64, ptr }, ptr %l51, i32 0, i32 1
  %t178 = load ptr, ptr %t177, !tbaa !27
  %t179 = load i64, ptr %l52, !tbaa !24
  %t180 = mul i64 %t179, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t176, ptr %t178, i64 %t180, i1 false)
  %t181 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t182 = getelementptr %"compiler/bindgen:record", ptr %l24, i32 0, i32 17
  %t183 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t182, i32 0, i32 0
  store { i64, ptr } %t181, ptr %t183, !tbaa !27
  %t184 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t184, label %bb24, label %bb25
bb24:
  %t186 = getelementptr %"compiler/bindgen:record", ptr %l24, i32 0, i32 17
  %t187 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t186, i32 0, i32 0
  %t188 = load { i64, ptr }, ptr %t187, !tbaa !27
  %t189 = extractvalue { i64, ptr } %t188, 0
  %t191 = icmp eq i64 %t189, 0
  br i1 %t191, label %bb26, label %bb27
bb25:
  %t193 = call ptr @__olang_scope_hold(ptr %v0)
  %t194 = ptrtoint ptr %t193 to i64
  store i64 %t194, ptr %l57, !tbaa !24
  %t195 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t195, label %bb28, label %bb29
bb26:
  %t197 = getelementptr %"compiler/bindgen:record", ptr %l24, i32 0, i32 17
  %t198 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t197, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t198, !tbaa !27
  br label %bb27
bb27:
  %t199 = getelementptr %"compiler/bindgen:record", ptr %l24, i32 0, i32 17
  %t200 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t199, i32 0, i32 0
  %t201 = load i64, ptr %l49
  %t202 = inttoptr i64 %t201 to ptr
  %t203 = load { i64, ptr }, ptr %t200
  %t204 = extractvalue { i64, ptr } %t203, 1
  %t205 = call ptr @__olang_region_or(ptr %t204, ptr null)
  %t206 = icmp ne ptr %t205, null
  %t207 = select i1 %t206, ptr %t205, ptr null
  call void @__olang_region_settle_in(ptr %t202, ptr %t207)
  br label %bb25
bb28:
  %t208 = call ptr @__olang_region_make_part(ptr %v0)
  %t209 = ptrtoint ptr %t208 to i64
  store i64 %t209, ptr %l57, !tbaa !24
  br label %bb29
bb29:
  %t210 = getelementptr %"compiler/bindgen:record", ptr %l24, i32 0, i32 18
  %t211 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t210, i32 0, i32 0
  %t212 = load { i64, ptr }, ptr %t211, !tbaa !27
  store { i64, ptr } %t212, ptr %l59, !tbaa !27
  %t213 = load { i64, ptr }, ptr %l59, !tbaa !27
  %t214 = extractvalue { i64, ptr } %t213, 0
  store i64 %t214, ptr %l60, !tbaa !24
  %t215 = load i64, ptr %l60, !tbaa !24
  %t216 = mul i64 %t215, 8
  %t217 = load i64, ptr %l57
  %t218 = inttoptr i64 %t217 to ptr
  %t219 = call ptr @__olang_held_alloc(ptr %t218, i64 %t216)
  %t220 = insertvalue { i64, ptr } undef, i64 %t215, 0
  %t221 = insertvalue { i64, ptr } %t220, ptr %t219, 1
  store { i64, ptr } %t221, ptr %l61, !tbaa !27
  %t222 = getelementptr { i64, ptr }, ptr %l61, i32 0, i32 1
  %t223 = load ptr, ptr %t222, !tbaa !27
  %t224 = getelementptr { i64, ptr }, ptr %l59, i32 0, i32 1
  %t225 = load ptr, ptr %t224, !tbaa !27
  %t226 = load i64, ptr %l60, !tbaa !24
  %t227 = mul i64 %t226, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t223, ptr %t225, i64 %t227, i1 false)
  %t228 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t229 = getelementptr %"compiler/bindgen:record", ptr %l24, i32 0, i32 18
  %t230 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t229, i32 0, i32 0
  store { i64, ptr } %t228, ptr %t230, !tbaa !27
  %t231 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t231, label %bb30, label %bb31
bb30:
  %t233 = getelementptr %"compiler/bindgen:record", ptr %l24, i32 0, i32 18
  %t234 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t233, i32 0, i32 0
  %t235 = load { i64, ptr }, ptr %t234, !tbaa !27
  %t236 = extractvalue { i64, ptr } %t235, 0
  %t238 = icmp eq i64 %t236, 0
  br i1 %t238, label %bb32, label %bb33
bb31:
  %t240 = call ptr @__olang_scope_hold(ptr %v0)
  %t241 = ptrtoint ptr %t240 to i64
  store i64 %t241, ptr %l65, !tbaa !24
  %t242 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t242, label %bb34, label %bb35
bb32:
  %t244 = getelementptr %"compiler/bindgen:record", ptr %l24, i32 0, i32 18
  %t245 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t244, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t245, !tbaa !27
  br label %bb33
bb33:
  %t246 = getelementptr %"compiler/bindgen:record", ptr %l24, i32 0, i32 18
  %t247 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t246, i32 0, i32 0
  %t248 = load i64, ptr %l57
  %t249 = inttoptr i64 %t248 to ptr
  %t250 = load { i64, ptr }, ptr %t247
  %t251 = extractvalue { i64, ptr } %t250, 1
  %t252 = call ptr @__olang_region_or(ptr %t251, ptr null)
  %t253 = icmp ne ptr %t252, null
  %t254 = select i1 %t253, ptr %t252, ptr null
  call void @__olang_region_settle_in(ptr %t249, ptr %t254)
  br label %bb31
bb34:
  %t255 = call ptr @__olang_region_make_part(ptr %v0)
  %t256 = ptrtoint ptr %t255 to i64
  store i64 %t256, ptr %l65, !tbaa !24
  br label %bb35
bb35:
  %t257 = getelementptr %"compiler/bindgen:record", ptr %l24, i32 0, i32 19
  %t258 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t257, i32 0, i32 0
  %t259 = load { i64, ptr }, ptr %t258, !tbaa !27
  store { i64, ptr } %t259, ptr %l67, !tbaa !27
  %t260 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t261 = extractvalue { i64, ptr } %t260, 0
  store i64 %t261, ptr %l68, !tbaa !24
  %t262 = load i64, ptr %l68, !tbaa !24
  %t263 = mul i64 %t262, 8
  %t264 = load i64, ptr %l65
  %t265 = inttoptr i64 %t264 to ptr
  %t266 = call ptr @__olang_held_alloc(ptr %t265, i64 %t263)
  %t267 = insertvalue { i64, ptr } undef, i64 %t262, 0
  %t268 = insertvalue { i64, ptr } %t267, ptr %t266, 1
  store { i64, ptr } %t268, ptr %l69, !tbaa !27
  %t269 = getelementptr { i64, ptr }, ptr %l69, i32 0, i32 1
  %t270 = load ptr, ptr %t269, !tbaa !27
  %t271 = getelementptr { i64, ptr }, ptr %l67, i32 0, i32 1
  %t272 = load ptr, ptr %t271, !tbaa !27
  %t273 = load i64, ptr %l68, !tbaa !24
  %t274 = mul i64 %t273, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t270, ptr %t272, i64 %t274, i1 false)
  %t275 = load { i64, ptr }, ptr %l69, !tbaa !27
  %t276 = getelementptr %"compiler/bindgen:record", ptr %l24, i32 0, i32 19
  %t277 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t276, i32 0, i32 0
  store { i64, ptr } %t275, ptr %t277, !tbaa !27
  %t278 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t278, label %bb36, label %bb37
bb36:
  %t280 = getelementptr %"compiler/bindgen:record", ptr %l24, i32 0, i32 19
  %t281 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t280, i32 0, i32 0
  %t282 = load { i64, ptr }, ptr %t281, !tbaa !27
  %t283 = extractvalue { i64, ptr } %t282, 0
  %t285 = icmp eq i64 %t283, 0
  br i1 %t285, label %bb38, label %bb39
bb37:
  call void @llvm.memmove.p0.p0.i64(ptr %l4, ptr %l24, i64 312, i1 false)
  %t287 = load i1, ptr %l3, !tbaa !21
  br i1 %t287, label %bb40, label %bb41
bb38:
  %t289 = getelementptr %"compiler/bindgen:record", ptr %l24, i32 0, i32 19
  %t290 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t289, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t290, !tbaa !27
  br label %bb39
bb39:
  %t291 = getelementptr %"compiler/bindgen:record", ptr %l24, i32 0, i32 19
  %t292 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t291, i32 0, i32 0
  %t293 = load i64, ptr %l65
  %t294 = inttoptr i64 %t293 to ptr
  %t295 = load { i64, ptr }, ptr %t292
  %t296 = extractvalue { i64, ptr } %t295, 1
  %t297 = call ptr @__olang_region_or(ptr %t296, ptr null)
  %t298 = icmp ne ptr %t297, null
  %t299 = select i1 %t298, ptr %t297, ptr null
  call void @__olang_region_settle_in(ptr %t294, ptr %t299)
  br label %bb37
bb40:
  %t300 = getelementptr %"compiler/bindgen:record", ptr %l4, i32 0, i32 15
  %t301 = load i1, ptr %t300, !tbaa !21
  store i1 %t301, ptr %l74, !tbaa !21
  br label %bb42
bb41:
  store i1 false, ptr %l74, !tbaa !21
  br label %bb42
bb42:
  %t303 = load i1, ptr %l74, !tbaa !21
  br i1 %t303, label %bb43, label %bb44
bb43:
  store %olang.scope zeroinitializer, ptr %s1
  %t304 = getelementptr %"compiler/bindgen:record", ptr %l4, i32 0, i32 7
  %t305 = load { i64, ptr }, ptr %t304, !tbaa !27
  %t306 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d207, i32 0, i32 1) }, 1
  %t307 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d207, i32 0, i32 1) }, 0
  %t309 = extractvalue { i64, ptr } %t305, 1
  %t310 = extractvalue { i64, ptr } %t305, 0
  %t311 = add i64 %t307, %t310
  %t312 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d208, i32 0, i32 1) }, 1
  %t313 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d208, i32 0, i32 1) }, 0
  %t314 = add i64 %t311, %t313
  %t315 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t314)
  call void @olang_textcopy(ptr %t315, ptr %t306, i64 %t307)
  %t316 = getelementptr i8, ptr %t315, i64 %t307
  call void @olang_textcopy(ptr %t316, ptr %t309, i64 %t310)
  %t317 = getelementptr i8, ptr %t316, i64 %t310
  call void @olang_textcopy(ptr %t317, ptr %t312, i64 %t313)
  %t318 = insertvalue { i64, ptr } undef, i64 %t314, 0
  %t319 = insertvalue { i64, ptr } %t318, ptr %t315, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s1, ptr %l2, { i64, ptr } %t319)
  br label %bb45
bb44:
  br label %bb58
bb45:
  store %olang.scope zeroinitializer, ptr %s3
  %t323 = load ptr, ptr %l0, !tbaa !29
  %t324 = load i64, ptr %l1, !tbaa !24
  %t327 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2epackedFields(ptr %v0, ptr %s3, ptr %t323, i64 %t324)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t327, ptr %l82
  br label %bb46
bb46:
  %t328 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l82
  %t329 = call ptr @__olang_scope_alloc_a(ptr %s3, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t328, ptr %t329
  store ptr %t329, ptr %l5, !tbaa !29
  store i64 0, ptr %l6, !tbaa !24
  br label %bb47
bb47:
  %t331 = load i64, ptr %l6, !tbaa !24
  store i64 %t331, ptr %l84, !tbaa !24
  %t332 = load ptr, ptr %l5, !tbaa !29
  %t334 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s3, ptr %t332)
  store i64 %t334, ptr %l86
  br label %bb48
bb48:
  %t335 = load i64, ptr %l84, !tbaa !24
  %t336 = load i64, ptr %l86, !tbaa !24
  %t337 = icmp slt i64 %t335, %t336
  %t339 = xor i1 %t337, true
  br i1 %t339, label %bb49, label %bb50
bb49:
  br label %bb55
bb50:
  br label %bb51
bb51:
  %t341 = load ptr, ptr %l5, !tbaa !29
  %t342 = load i64, ptr %l6, !tbaa !24
  %t345 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s3, ptr %s3, ptr %t341, i64 %t342)
  store { i64, ptr } %t345, ptr %l91
  br label %bb52
bb52:
  %t346 = load { i64, ptr }, ptr %l91, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s3, ptr %l2, { i64, ptr } %t346)
  br label %bb53
bb53:
  br label %bb54
bb54:
  %t350 = load i64, ptr %l6, !tbaa !24
  %t353 = add i64 %t350, 1
  store i64 %t353, ptr %l6, !tbaa !24
  br label %bb47
bb55:
  call void @__olang_scope_close(ptr %s3)
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s1, ptr %l2, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d209, i32 0, i32 1) })
  br label %bb56
bb56:
  %t357 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l2)
  store { i64, ptr } %t357, ptr %l99
  br label %bb57
bb57:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t358 = load { i64, ptr }, ptr %l99, !tbaa !27
  store { i64, ptr } %t358, ptr %rv
  br label %ret
bb58:
  %t359 = getelementptr %"compiler/bindgen:record", ptr %l4, i32 0, i32 7
  %t360 = load { i64, ptr }, ptr %t359, !tbaa !27
  %t361 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d210, i32 0, i32 1) }, 1
  %t362 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d210, i32 0, i32 1) }, 0
  %t364 = extractvalue { i64, ptr } %t360, 1
  %t365 = extractvalue { i64, ptr } %t360, 0
  %t366 = add i64 %t362, %t365
  %t367 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d211, i32 0, i32 1) }, 1
  %t368 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d211, i32 0, i32 1) }, 0
  %t369 = add i64 %t366, %t368
  %t370 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t369)
  call void @olang_textcopy(ptr %t370, ptr %t361, i64 %t362)
  %t371 = getelementptr i8, ptr %t370, i64 %t362
  call void @olang_textcopy(ptr %t371, ptr %t364, i64 %t365)
  %t372 = getelementptr i8, ptr %t371, i64 %t365
  call void @olang_textcopy(ptr %t372, ptr %t367, i64 %t368)
  %t373 = insertvalue { i64, ptr } undef, i64 %t369, 0
  %t374 = insertvalue { i64, ptr } %t373, ptr %t370, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l2, { i64, ptr } %t374)
  br label %bb59
bb59:
  %t378 = load i1, ptr %l3, !tbaa !21
  %t380 = xor i1 %t378, true
  br i1 %t380, label %bb60, label %bb61
bb60:
  store %olang.scope zeroinitializer, ptr %s7
  %t382 = getelementptr %"compiler/bindgen:record", ptr %l4, i32 0, i32 14
  %t383 = load i64, ptr %t382, !tbaa !24
  %t385 = icmp eq i64 %t383, 8
  br i1 %t385, label %bb62, label %bb63
bb61:
  br label %bb75
bb62:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d212, i32 0, i32 1) }, ptr %l108, !tbaa !27
  br label %bb70
bb63:
  %t387 = getelementptr %"compiler/bindgen:record", ptr %l4, i32 0, i32 14
  %t388 = load i64, ptr %t387, !tbaa !24
  %t390 = icmp eq i64 %t388, 4
  br i1 %t390, label %bb64, label %bb65
bb64:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d213, i32 0, i32 1) }, ptr %l111, !tbaa !27
  br label %bb69
bb65:
  %t392 = getelementptr %"compiler/bindgen:record", ptr %l4, i32 0, i32 14
  %t393 = load i64, ptr %t392, !tbaa !24
  %t395 = icmp eq i64 %t393, 2
  br i1 %t395, label %bb66, label %bb67
bb66:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d214, i32 0, i32 1) }, ptr %l114, !tbaa !27
  br label %bb68
bb67:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d215, i32 0, i32 1) }, ptr %l114, !tbaa !27
  br label %bb68
bb68:
  %t397 = load { i64, ptr }, ptr %l114, !tbaa !27
  store { i64, ptr } %t397, ptr %l111, !tbaa !27
  br label %bb69
bb69:
  %t398 = load { i64, ptr }, ptr %l111, !tbaa !27
  store { i64, ptr } %t398, ptr %l108, !tbaa !27
  br label %bb70
bb70:
  %t399 = load { i64, ptr }, ptr %l108, !tbaa !27
  %t401 = getelementptr %"compiler/bindgen:record", ptr %l4, i32 0, i32 13
  %t402 = load i64, ptr %t401, !tbaa !24
  %t403 = getelementptr %"compiler/bindgen:record", ptr %l4, i32 0, i32 14
  %t404 = load i64, ptr %t403, !tbaa !24
  %t407 = sdiv i64 %t402, %t404
  %t408 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d216, i32 0, i32 1) }, 1
  %t409 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d216, i32 0, i32 1) }, 0
  %t411 = extractvalue { i64, ptr } %t399, 1
  %t412 = extractvalue { i64, ptr } %t399, 0
  %t413 = add i64 %t409, %t412
  %t414 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d217, i32 0, i32 1) }, 1
  %t415 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d217, i32 0, i32 1) }, 0
  %t416 = add i64 %t413, %t415
  %t418 = call i64 @__olang_fmt_i64(ptr null, i64 %t407)
  %t419 = add i64 %t416, %t418
  %t420 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d218, i32 0, i32 1) }, 1
  %t421 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d218, i32 0, i32 1) }, 0
  %t422 = add i64 %t419, %t421
  %t423 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t422)
  call void @olang_textcopy(ptr %t423, ptr %t408, i64 %t409)
  %t424 = getelementptr i8, ptr %t423, i64 %t409
  call void @olang_textcopy(ptr %t424, ptr %t411, i64 %t412)
  %t425 = getelementptr i8, ptr %t424, i64 %t412
  call void @olang_textcopy(ptr %t425, ptr %t414, i64 %t415)
  %t426 = getelementptr i8, ptr %t425, i64 %t415
  %t427 = call i64 @__olang_fmt_i64(ptr %t426, i64 %t407)
  %t428 = getelementptr i8, ptr %t426, i64 %t418
  call void @olang_textcopy(ptr %t428, ptr %t420, i64 %t421)
  %t429 = insertvalue { i64, ptr } undef, i64 %t422, 0
  %t430 = insertvalue { i64, ptr } %t429, ptr %t423, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s7, ptr %l2, { i64, ptr } %t430)
  br label %bb71
bb71:
  store ptr %l2, ptr %l122, !tbaa !29
  %t434 = load ptr, ptr %l0, !tbaa !29
  %t435 = load i64, ptr %l1, !tbaa !24
  %t438 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eunionAccessors(ptr %v0, ptr %s7, ptr %t434, i64 %t435, i1 false)
  store { i64, ptr } %t438, ptr %l125
  br label %bb72
bb72:
  %t439 = load { i64, ptr }, ptr %l125, !tbaa !27
  %t440 = load ptr, ptr %l122, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s7, ptr %t440, { i64, ptr } %t439)
  br label %bb73
bb73:
  %t443 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l2)
  store { i64, ptr } %t443, ptr %l128
  br label %bb74
bb74:
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s0)
  %t444 = load { i64, ptr }, ptr %l128, !tbaa !27
  store { i64, ptr } %t444, ptr %rv
  br label %ret
bb75:
  %t445 = load ptr, ptr %l0, !tbaa !29
  %t446 = load i64, ptr %l1, !tbaa !24
  %t449 = call i1 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ehasAnon(ptr %v0, ptr %t445, i64 %t446)
  store i1 %t449, ptr %l131
  br label %bb76
bb76:
  %t450 = load i1, ptr %l131, !tbaa !21
  br i1 %t450, label %bb77, label %bb78
bb77:
  store %olang.scope zeroinitializer, ptr %s9
  store ptr %l2, ptr %l132, !tbaa !29
  %t451 = load ptr, ptr %l0, !tbaa !29
  %t452 = load i64, ptr %l1, !tbaa !24
  %t455 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eflatFields(ptr %v0, ptr %s9, ptr %t451, i64 %t452)
  store { i64, ptr } %t455, ptr %l135
  br label %bb79
bb78:
  br label %bb84
bb79:
  %t456 = load { i64, ptr }, ptr %l135, !tbaa !27
  %t457 = extractvalue { i64, ptr } %t456, 1
  %t458 = extractvalue { i64, ptr } %t456, 0
  %t459 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d219, i32 0, i32 1) }, 1
  %t460 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d219, i32 0, i32 1) }, 0
  %t461 = add i64 %t458, %t460
  %t462 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t461)
  call void @olang_textcopy(ptr %t462, ptr %t457, i64 %t458)
  %t463 = getelementptr i8, ptr %t462, i64 %t458
  call void @olang_textcopy(ptr %t463, ptr %t459, i64 %t460)
  %t464 = insertvalue { i64, ptr } undef, i64 %t461, 0
  %t465 = insertvalue { i64, ptr } %t464, ptr %t462, 1
  %t467 = load ptr, ptr %l132, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s9, ptr %t467, { i64, ptr } %t465)
  br label %bb80
bb80:
  store ptr %l2, ptr %l138, !tbaa !29
  %t469 = load ptr, ptr %l0, !tbaa !29
  %t470 = load i64, ptr %l1, !tbaa !24
  %t473 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eunionAccessors(ptr %v0, ptr %s9, ptr %t469, i64 %t470, i1 true)
  store { i64, ptr } %t473, ptr %l141
  br label %bb81
bb81:
  %t474 = load { i64, ptr }, ptr %l141, !tbaa !27
  %t475 = load ptr, ptr %l138, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s9, ptr %t475, { i64, ptr } %t474)
  br label %bb82
bb82:
  %t478 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l2)
  store { i64, ptr } %t478, ptr %l144
  br label %bb83
bb83:
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s0)
  %t479 = load { i64, ptr }, ptr %l144, !tbaa !27
  store { i64, ptr } %t479, ptr %rv
  br label %ret
bb84:
  %t480 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e_2ector(ptr %s0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t480, ptr %l145
  br label %bb85
bb85:
  %t481 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l145
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t481, ptr %l9
  store i64 0, ptr %l10, !tbaa !24
  %t482 = getelementptr %"compiler/bindgen:record", ptr %l4, i32 0, i32 4
  %t484 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %t482)
  store i64 %t484, ptr %l147
  br label %bb86
bb86:
  %t485 = load i64, ptr %l147, !tbaa !24
  store i64 %t485, ptr %l11, !tbaa !24
  store i64 1, ptr %l12, !tbaa !24
  %t486 = load i64, ptr %l11, !tbaa !24
  %t487 = load i64, ptr %l10, !tbaa !24
  %t490 = icmp sgt i64 %t486, %t487
  br i1 %t490, label %bb87, label %bb88
bb87:
  %t492 = load i64, ptr %l12, !tbaa !24
  %t494 = icmp sgt i64 %t492, 0
  br i1 %t494, label %bb89, label %bb90
bb88:
  store i64 0, ptr %l151, !tbaa !24
  br label %bb92
bb89:
  %t496 = load i64, ptr %l11, !tbaa !24
  %t497 = load i64, ptr %l10, !tbaa !24
  %t500 = sub i64 %t496, %t497
  %t501 = load i64, ptr %l12, !tbaa !24
  %t504 = add i64 %t500, %t501
  %t506 = sub i64 %t504, 1
  %t507 = load i64, ptr %l12, !tbaa !24
  %t510 = sdiv i64 %t506, %t507
  store i64 %t510, ptr %l154, !tbaa !24
  br label %bb91
bb90:
  store i64 0, ptr %l154, !tbaa !24
  br label %bb91
bb91:
  %t512 = load i64, ptr %l154, !tbaa !24
  store i64 %t512, ptr %l151, !tbaa !24
  br label %bb92
bb92:
  %t513 = load i64, ptr %l151, !tbaa !24
  store i64 %t513, ptr %l13, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  br label %bb93
bb93:
  store %olang.scope zeroinitializer, ptr %s12
  %t514 = load i64, ptr %l14, !tbaa !24
  %t515 = load i64, ptr %l13, !tbaa !24
  %t518 = icmp slt i64 %t514, %t515
  %t520 = xor i1 %t518, true
  br i1 %t520, label %bb94, label %bb95
bb94:
  call void @__olang_scope_close(ptr %s12)
  br label %bb103
bb95:
  br label %bb96
bb96:
  %t522 = load i64, ptr %l10, !tbaa !24
  %t523 = load i64, ptr %l14, !tbaa !24
  %t524 = load i64, ptr %l12, !tbaa !24
  %t527 = mul i64 %t523, %t524
  %t530 = add i64 %t522, %t527
  store i64 %t530, ptr %l15, !tbaa !24
  store ptr %l2, ptr %l172, !tbaa !29
  %t532 = load ptr, ptr %l0, !tbaa !29
  store ptr %t532, ptr %l173, !tbaa !29
  %t533 = load ptr, ptr %l0, !tbaa !29
  store ptr %t533, ptr %l174, !tbaa !29
  %t534 = getelementptr %"compiler/bindgen:record", ptr %l4, i32 0, i32 4
  %t535 = load i64, ptr %l15, !tbaa !24
  %t538 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %t534, i64 %t535)
  store { i64, ptr } %t538, ptr %l177
  br label %bb97
bb97:
  %t539 = load i64, ptr %l15, !tbaa !24
  %t540 = load ptr, ptr %l174, !tbaa !29
  %t541 = load { i64, ptr }, ptr %l177, !tbaa !27
  %t544 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eparamName(ptr %v0, ptr %v0, ptr %s0, ptr %s0, ptr %t540, { i64, ptr } %t541, i64 %t539, ptr %l9)
  store { i64, ptr } %t544, ptr %l180
  br label %bb98
bb98:
  %t545 = load { i64, ptr }, ptr %l180, !tbaa !27
  %t546 = extractvalue { i64, ptr } %t545, 0
  %t547 = extractvalue { i64, ptr } %t545, 1
  %t548 = mul i64 %t546, 1
  %t549 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t548)
  call void @llvm.memcpy.p0.p0.i64(ptr %t549, ptr %t547, i64 %t548, i1 false)
  %t550 = insertvalue { i64, ptr } undef, i64 %t546, 0
  %t551 = insertvalue { i64, ptr } %t550, ptr %t549, 1
  store { i64, ptr } %t551, ptr %l181, !tbaa !27
  %t552 = getelementptr %"compiler/bindgen:record", ptr %l4, i32 0, i32 5
  %t553 = load i64, ptr %l15, !tbaa !24
  %t556 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %t552, i64 %t553)
  store { i64, ptr } %t556, ptr %l184
  br label %bb99
bb99:
  %t557 = load ptr, ptr %l173, !tbaa !29
  %t558 = load { i64, ptr }, ptr %l181, !tbaa !27
  %t559 = load { i64, ptr }, ptr %l184, !tbaa !27
  %t560 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2efieldLine(ptr %v0, ptr %s12, ptr %v0, ptr %s12, ptr %t557, { i64, ptr } %t558, { i64, ptr } %t559)
  store { i64, ptr } %t560, ptr %l185
  br label %bb100
bb100:
  %t561 = load { i64, ptr }, ptr %l185, !tbaa !27
  %t562 = load ptr, ptr %l172, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s12, ptr %t562, { i64, ptr } %t561)
  br label %bb101
bb101:
  call void @__olang_scope_close(ptr %s12)
  br label %bb102
bb102:
  %t564 = load i64, ptr %l14, !tbaa !24
  %t567 = add i64 %t564, 1
  store i64 %t567, ptr %l14, !tbaa !24
  br label %bb93
bb103:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l2, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d220, i32 0, i32 1) })
  br label %bb104
bb104:
  %t571 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l2)
  store { i64, ptr } %t571, ptr %l192
  br label %bb105
bb105:
  call void @__olang_scope_close(ptr %s0)
  %t572 = load { i64, ptr }, ptr %l192, !tbaa !27
  store { i64, ptr } %t572, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2etypeName(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca i1
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l29 = alloca i1
  %l31 = alloca i1
  %l33 = alloca i1
  %l35 = alloca i1
  %l37 = alloca i1
  %l41 = alloca { i64, ptr }
  %l42 = alloca i64
  %l43 = alloca { i64, ptr }
  %l45 = alloca i1
  %l47 = alloca i1
  %l49 = alloca i1
  %l51 = alloca i1
  %l52 = alloca i64
  %l55 = alloca { i64, ptr }
  %l59 = alloca { i64, ptr }
  %l62 = alloca i1
  %l63 = alloca i1
  %l65 = alloca i1
  %l66 = alloca i1
  %l68 = alloca i1
  %l69 = alloca i64
  %l71 = alloca { i64, ptr }
  %l72 = alloca i64
  %l73 = alloca { i64, ptr }
  %l74 = alloca { i64, ptr }
  %l77 = alloca ptr
  %l82 = alloca { i64, ptr }
  %l83 = alloca { i64, ptr }
  %l86 = alloca i1
  %l87 = alloca i1
  %l89 = alloca i1
  %l90 = alloca i1
  %l92 = alloca i1
  %l93 = alloca i1
  %l96 = alloca i1
  %l99 = alloca i1
  %l103 = alloca i1
  %l105 = alloca i1
  %l106 = alloca i1
  %l109 = alloca i64
  %l111 = alloca { i64, ptr }
  %l112 = alloca i64
  %l113 = alloca { i64, ptr }
  %l114 = alloca { i64, ptr }
  %l117 = alloca ptr
  %l122 = alloca i1
  %l125 = alloca i64
  %l127 = alloca i1
  %l130 = alloca i1
  %l132 = alloca i1
  %l136 = alloca ptr
  %l137 = alloca i64
  %l144 = alloca i64
  %l146 = alloca i1
  %l147 = alloca i1
  %l149 = alloca i1
  %l150 = alloca ptr
  %l151 = alloca i64
  %l156 = alloca i64
  %l157 = alloca ptr
  %l158 = alloca i32
  %l159 = alloca i64
  %l165 = alloca i64
  %l167 = alloca i1
  %l169 = alloca { i64, ptr }
  %l173 = alloca { i64, ptr }
  %l174 = alloca i32
  %l176 = alloca i1
  %l177 = alloca ptr
  %l178 = alloca i64
  %l183 = alloca i64
  %l188 = alloca i64
  %l193 = alloca i64
  %l199 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %s28 = alloca %olang.scope
  %s29 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i64 0, ptr %l3, !tbaa !24
  store i64 0, ptr %l4, !tbaa !24
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d221, i32 0, i32 1) }, ptr %l13, !tbaa !27
  %t1 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t1, ptr %l5, !tbaa !27
  store i1 false, ptr %l6, !tbaa !21
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d222, i32 0, i32 1) }, ptr %l15, !tbaa !27
  %t3 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t3, ptr %l7, !tbaa !27
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d223, i32 0, i32 1) }, ptr %l17, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t5, ptr %l8, !tbaa !27
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t7 = load ptr, ptr %l1, !tbaa !29
  %t9 = getelementptr %"compiler/bindgen:ctp", ptr %t7, i32 0, i32 1
  %t10 = load i64, ptr %t9, !tbaa !24
  %t11 = load ptr, ptr %l1, !tbaa !29
  %t13 = getelementptr %"compiler/bindgen:ctp", ptr %t11, i32 0, i32 0
  %t14 = load { i64, ptr }, ptr %t13, !tbaa !27
  %t16 = extractvalue { i64, ptr } %t14, 0
  %t19 = icmp slt i64 %t10, %t16
  %t21 = xor i1 %t19, true
  br i1 %t21, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s1)
  br label %bb102
bb3:
  br label %bb4
bb4:
  %t23 = load ptr, ptr %l1, !tbaa !29
  %t25 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3actp_2eat(ptr %v1, ptr %s1, ptr %t23, i64 0)
  store { i64, ptr } %t25, ptr %l27
  br label %bb5
bb5:
  %t26 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t26, ptr %l9, !tbaa !27
  %t27 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t29 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s1, ptr %s1, { i64, ptr } %t27, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d224, i32 0, i32 1) })
  store i1 %t29, ptr %l29
  br label %bb6
bb6:
  %t30 = load i1, ptr %l29, !tbaa !21
  br i1 %t30, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb100
bb8:
  %t31 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t33 = call i1 @compiler_2fbindgen_2epassOver(ptr %s1, { i64, ptr } %t31)
  store i1 %t33, ptr %l31
  br label %bb9
bb9:
  %t34 = load i1, ptr %l31, !tbaa !21
  br i1 %t34, label %bb10, label %bb11
bb10:
  br label %bb99
bb11:
  store %olang.scope zeroinitializer, ptr %s5
  %t35 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t37 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s1, ptr %s5, { i64, ptr } %t35, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d225, i32 0, i32 1) })
  store i1 %t37, ptr %l33
  br label %bb12
bb12:
  %t38 = load i1, ptr %l33, !tbaa !21
  br i1 %t38, label %bb13, label %bb14
bb13:
  store i64 1, ptr %l3, !tbaa !24
  br label %bb98
bb14:
  store %olang.scope zeroinitializer, ptr %s7
  %t39 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t41 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s1, ptr %s7, { i64, ptr } %t39, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d226, i32 0, i32 1) })
  store i1 %t41, ptr %l35
  br label %bb15
bb15:
  %t42 = load i1, ptr %l35, !tbaa !21
  br i1 %t42, label %bb16, label %bb17
bb16:
  store i64 2, ptr %l3, !tbaa !24
  br label %bb97
bb17:
  store %olang.scope zeroinitializer, ptr %s9
  %t43 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t45 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s1, ptr %s9, { i64, ptr } %t43, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d227, i32 0, i32 1) })
  store i1 %t45, ptr %l37
  br label %bb18
bb18:
  %t46 = load i1, ptr %l37, !tbaa !21
  br i1 %t46, label %bb19, label %bb20
bb19:
  %t47 = load i64, ptr %l4, !tbaa !24
  %t50 = add i64 %t47, 1
  store i64 %t50, ptr %l4, !tbaa !24
  br label %bb96
bb20:
  store %olang.scope zeroinitializer, ptr %s11
  %t52 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t52, ptr %l41, !tbaa !27
  %t53 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t54 = extractvalue { i64, ptr } %t53, 0
  store i64 %t54, ptr %l42, !tbaa !24
  %t55 = load i64, ptr %l42, !tbaa !24
  %t56 = mul i64 %t55, 1
  %t57 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t56)
  %t58 = insertvalue { i64, ptr } undef, i64 %t55, 0
  %t59 = insertvalue { i64, ptr } %t58, ptr %t57, 1
  store { i64, ptr } %t59, ptr %l43, !tbaa !27
  %t60 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !27
  %t62 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !27
  %t64 = load i64, ptr %l42, !tbaa !24
  %t65 = mul i64 %t64, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t61, ptr %t63, i64 %t65, i1 false)
  %t66 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t69 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2eHas_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %s11, ptr %s11, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x { i64, ptr }] }>, ptr @.d228, i32 0, i32 1) }, { i64, ptr } %t66)
  store i1 %t69, ptr %l45
  br label %bb21
bb21:
  %t70 = load i1, ptr %l45, !tbaa !21
  br i1 %t70, label %bb22, label %bb23
bb22:
  store %olang.scope zeroinitializer, ptr %s12
  %t71 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t73 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s1, ptr %s12, { i64, ptr } %t71, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d229, i32 0, i32 1) })
  store i1 %t73, ptr %l47
  br label %bb24
bb23:
  store %olang.scope zeroinitializer, ptr %s15
  %t74 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t76 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s1, ptr %s15, { i64, ptr } %t74, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d230, i32 0, i32 1) })
  store i1 %t76, ptr %l62
  br label %bb40
bb24:
  %t77 = load i1, ptr %l47, !tbaa !21
  %t78 = xor i1 %t77, true
  br i1 %t78, label %bb25, label %bb26
bb25:
  store i1 true, ptr %l49, !tbaa !21
  br label %bb28
bb26:
  %t80 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t82 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s12, { i64, ptr } %t80, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d231, i32 0, i32 1) })
  store i1 %t82, ptr %l51
  br label %bb27
bb27:
  %t83 = load i1, ptr %l51, !tbaa !21
  store i1 %t83, ptr %l49, !tbaa !21
  br label %bb28
bb28:
  %t84 = load i1, ptr %l49, !tbaa !21
  br i1 %t84, label %bb29, label %bb30
bb29:
  %t85 = call ptr @__olang_scope_hold(ptr %s0)
  %t86 = ptrtoint ptr %t85 to i64
  store i64 %t86, ptr %l52, !tbaa !24
  %t87 = load i1, ptr @olang_2esole_2ecompiler__2fbindgen__2ecompiler__2fbindgen__3agen__2etypeName_2elocal_2e5
  br i1 %t87, label %bb31, label %bb32
bb30:
  br label %bb39
bb31:
  %t89 = call ptr @__olang_region_make(ptr %s0)
  %t90 = ptrtoint ptr %t89 to i64
  store i64 %t90, ptr %l52, !tbaa !24
  br label %bb32
bb32:
  %t91 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t93 = extractvalue { i64, ptr } %t91, 1
  %t94 = extractvalue { i64, ptr } %t91, 0
  %t95 = load i64, ptr %l52
  %t96 = inttoptr i64 %t95 to ptr
  %t97 = call ptr @__olang_held_alloc(ptr %t96, i64 %t94)
  call void @olang_textcopy(ptr %t97, ptr %t93, i64 %t94)
  %t98 = insertvalue { i64, ptr } undef, i64 %t94, 0
  %t99 = insertvalue { i64, ptr } %t98, ptr %t97, 1
  store { i64, ptr } %t99, ptr %l55, !tbaa !27
  %t100 = load i1, ptr @olang_2esole_2ecompiler__2fbindgen__2ecompiler__2fbindgen__3agen__2etypeName_2elocal_2e5
  br i1 %t100, label %bb33, label %bb34
bb33:
  %t102 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t103 = extractvalue { i64, ptr } %t102, 0
  %t105 = icmp eq i64 %t103, 0
  br i1 %t105, label %bb35, label %bb36
bb34:
  %t107 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t107, ptr %l59, !tbaa !27
  %t108 = load { i64, ptr }, ptr %l55, !tbaa !27
  store { i64, ptr } %t108, ptr %l5, !tbaa !27
  %t109 = load i1, ptr @olang_2esole_2ecompiler__2fbindgen__2ecompiler__2fbindgen__3agen__2etypeName_2elocal_2e5
  br i1 %t109, label %bb37, label %bb38
bb35:
  store { i64, ptr } zeroinitializer, ptr %l55, !tbaa !27
  br label %bb36
bb36:
  %t111 = load i64, ptr %l52
  %t112 = inttoptr i64 %t111 to ptr
  %t113 = load { i64, ptr }, ptr %l55
  %t114 = extractvalue { i64, ptr } %t113, 1
  %t115 = call ptr @__olang_region_or(ptr %t114, ptr null)
  %t116 = icmp ne ptr %t115, null
  %t117 = select i1 %t116, ptr %t115, ptr null
  call void @__olang_region_settle_in(ptr %t112, ptr %t117)
  br label %bb34
bb37:
  %t118 = load { i64, ptr }, ptr %l59
  %t119 = extractvalue { i64, ptr } %t118, 1
  call void @__olang_region_release(ptr %t119)
  store { i64, ptr } zeroinitializer, ptr %l59
  br label %bb38
bb38:
  br label %bb39
bb39:
  call void @__olang_scope_close(ptr %s12)
  br label %bb95
bb40:
  %t120 = load i1, ptr %l62, !tbaa !21
  br i1 %t120, label %bb41, label %bb42
bb41:
  store i1 true, ptr %l63, !tbaa !21
  br label %bb44
bb42:
  %t121 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t123 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s1, ptr %s15, { i64, ptr } %t121, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d232, i32 0, i32 1) })
  store i1 %t123, ptr %l65
  br label %bb43
bb43:
  %t124 = load i1, ptr %l65, !tbaa !21
  store i1 %t124, ptr %l63, !tbaa !21
  br label %bb44
bb44:
  %t125 = load i1, ptr %l63, !tbaa !21
  br i1 %t125, label %bb45, label %bb46
bb45:
  store i1 true, ptr %l66, !tbaa !21
  br label %bb48
bb46:
  %t126 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t128 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s1, ptr %s15, { i64, ptr } %t126, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d233, i32 0, i32 1) })
  store i1 %t128, ptr %l68
  br label %bb47
bb47:
  %t129 = load i1, ptr %l68, !tbaa !21
  store i1 %t129, ptr %l66, !tbaa !21
  br label %bb48
bb48:
  %t130 = load i1, ptr %l66, !tbaa !21
  br i1 %t130, label %bb49, label %bb50
bb49:
  %t131 = call ptr @__olang_scope_hold(ptr %s0)
  %t132 = ptrtoint ptr %t131 to i64
  store i64 %t132, ptr %l69, !tbaa !24
  %t133 = load i1, ptr @olang_2esole_2ecompiler__2fbindgen__2ecompiler__2fbindgen__3agen__2etypeName_2elocal_2e7
  br i1 %t133, label %bb51, label %bb52
bb50:
  store %olang.scope zeroinitializer, ptr %s17
  %t135 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t137 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s17, { i64, ptr } %t135, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d234, i32 0, i32 1) })
  store i1 %t137, ptr %l86
  br label %bb60
bb51:
  %t138 = call ptr @__olang_region_make(ptr %s0)
  %t139 = ptrtoint ptr %t138 to i64
  store i64 %t139, ptr %l69, !tbaa !24
  br label %bb52
bb52:
  %t140 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t140, ptr %l71, !tbaa !27
  %t141 = load { i64, ptr }, ptr %l71, !tbaa !27
  %t142 = extractvalue { i64, ptr } %t141, 0
  store i64 %t142, ptr %l72, !tbaa !24
  %t143 = load i64, ptr %l72, !tbaa !24
  %t144 = mul i64 %t143, 1
  %t145 = load i64, ptr %l69
  %t146 = inttoptr i64 %t145 to ptr
  %t147 = call ptr @__olang_held_alloc(ptr %t146, i64 %t144)
  %t148 = insertvalue { i64, ptr } undef, i64 %t143, 0
  %t149 = insertvalue { i64, ptr } %t148, ptr %t147, 1
  store { i64, ptr } %t149, ptr %l73, !tbaa !27
  %t150 = getelementptr { i64, ptr }, ptr %l73, i32 0, i32 1
  %t151 = load ptr, ptr %t150, !tbaa !27
  %t152 = getelementptr { i64, ptr }, ptr %l71, i32 0, i32 1
  %t153 = load ptr, ptr %t152, !tbaa !27
  %t154 = load i64, ptr %l72, !tbaa !24
  %t155 = mul i64 %t154, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t151, ptr %t153, i64 %t155, i1 false)
  %t156 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t156, ptr %l74, !tbaa !27
  %t157 = load { i64, ptr }, ptr %l73, !tbaa !27
  store { i64, ptr } %t157, ptr %l7, !tbaa !27
  %t158 = load i1, ptr @olang_2esole_2ecompiler__2fbindgen__2ecompiler__2fbindgen__3agen__2etypeName_2elocal_2e7
  br i1 %t158, label %bb53, label %bb54
bb53:
  %t160 = load { i64, ptr }, ptr %l74
  %t161 = extractvalue { i64, ptr } %t160, 1
  call void @__olang_region_release(ptr %t161)
  store { i64, ptr } zeroinitializer, ptr %l74
  br label %bb54
bb54:
  %t162 = load i1, ptr @olang_2esole_2ecompiler__2fbindgen__2ecompiler__2fbindgen__3agen__2etypeName_2elocal_2e7
  br i1 %t162, label %bb55, label %bb56
bb55:
  %t164 = load i64, ptr %l69
  %t165 = inttoptr i64 %t164 to ptr
  %t166 = load { i64, ptr }, ptr %l7
  %t167 = extractvalue { i64, ptr } %t166, 1
  %t168 = call ptr @__olang_region_or(ptr %t167, ptr null)
  %t169 = icmp ne ptr %t168, null
  %t170 = select i1 %t169, ptr %t168, ptr null
  call void @__olang_region_settle_in(ptr %t165, ptr %t170)
  br label %bb56
bb56:
  %t171 = load ptr, ptr %l1, !tbaa !29
  store ptr %t171, ptr %l77, !tbaa !29
  %t172 = load ptr, ptr %l77, !tbaa !29
  %t173 = getelementptr %"compiler/bindgen:ctp", ptr %t172, i32 0, i32 1
  %t174 = load i64, ptr %t173, !tbaa !24
  %t177 = add i64 %t174, 1
  %t179 = load ptr, ptr %l77, !tbaa !29
  %t180 = getelementptr %"compiler/bindgen:ctp", ptr %t179, i32 0, i32 1
  store i64 %t177, ptr %t180, !tbaa !24
  %t181 = load ptr, ptr %l1, !tbaa !29
  %t183 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3actp_2eat(ptr %v1, ptr %s0, ptr %t181, i64 0)
  store { i64, ptr } %t183, ptr %l82
  br label %bb57
bb57:
  %t184 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t184, ptr %l83, !tbaa !27
  %t185 = load { i64, ptr }, ptr %l82, !tbaa !27
  store { i64, ptr } %t185, ptr %l8, !tbaa !27
  %t186 = load i1, ptr @olang_2esole_2ecompiler__2fbindgen__2ecompiler__2fbindgen__3agen__2etypeName_2elocal_2e8
  br i1 %t186, label %bb58, label %bb59
bb58:
  %t188 = load { i64, ptr }, ptr %l83
  %t189 = extractvalue { i64, ptr } %t188, 1
  call void @__olang_region_release(ptr %t189)
  store { i64, ptr } zeroinitializer, ptr %l83
  br label %bb59
bb59:
  br label %bb94
bb60:
  %t190 = load i1, ptr %l86, !tbaa !21
  br i1 %t190, label %bb61, label %bb62
bb61:
  %t191 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t193 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s17, { i64, ptr } %t191, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d235, i32 0, i32 1) })
  store i1 %t193, ptr %l89
  br label %bb63
bb62:
  store i1 false, ptr %l87, !tbaa !21
  br label %bb64
bb63:
  %t194 = load i1, ptr %l89, !tbaa !21
  store i1 %t194, ptr %l87, !tbaa !21
  br label %bb64
bb64:
  %t195 = load i1, ptr %l87, !tbaa !21
  br i1 %t195, label %bb65, label %bb66
bb65:
  %t196 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t198 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s17, { i64, ptr } %t196, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d236, i32 0, i32 1) })
  store i1 %t198, ptr %l92
  br label %bb67
bb66:
  store i1 false, ptr %l90, !tbaa !21
  br label %bb68
bb67:
  %t199 = load i1, ptr %l92, !tbaa !21
  store i1 %t199, ptr %l90, !tbaa !21
  br label %bb68
bb68:
  %t200 = load i1, ptr %l90, !tbaa !21
  br i1 %t200, label %bb69, label %bb70
bb69:
  %t201 = load i64, ptr %l3, !tbaa !24
  %t203 = icmp eq i64 %t201, 0
  store i1 %t203, ptr %l93, !tbaa !21
  br label %bb71
bb70:
  store i1 false, ptr %l93, !tbaa !21
  br label %bb71
bb71:
  %t205 = load i1, ptr %l93, !tbaa !21
  br i1 %t205, label %bb72, label %bb73
bb72:
  %t206 = load i64, ptr %l4, !tbaa !24
  %t208 = icmp eq i64 %t206, 0
  store i1 %t208, ptr %l96, !tbaa !21
  br label %bb74
bb73:
  store i1 false, ptr %l96, !tbaa !21
  br label %bb74
bb74:
  %t210 = load i1, ptr %l96, !tbaa !21
  br i1 %t210, label %bb75, label %bb76
bb75:
  %t211 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t213 = extractvalue { i64, ptr } %t211, 0
  %t215 = icmp sgt i64 %t213, 0
  store i1 %t215, ptr %l99, !tbaa !21
  br label %bb77
bb76:
  store i1 false, ptr %l99, !tbaa !21
  br label %bb77
bb77:
  %t217 = load i1, ptr %l99, !tbaa !21
  br i1 %t217, label %bb78, label %bb79
bb78:
  %t218 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t219 = load ptr, ptr %t218, !tbaa !27
  %t220 = getelementptr i8, ptr %t219, i64 0
  %t221 = load i8, ptr %t220, !tbaa !32
  %t223 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %t221)
  store i1 %t223, ptr %l105
  br label %bb80
bb79:
  store i1 false, ptr %l103, !tbaa !21
  br label %bb84
bb80:
  %t224 = load i1, ptr %l105, !tbaa !21
  br i1 %t224, label %bb81, label %bb82
bb81:
  store i1 true, ptr %l106, !tbaa !21
  br label %bb83
bb82:
  %t225 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t226 = load ptr, ptr %t225, !tbaa !27
  %t227 = getelementptr i8, ptr %t226, i64 0
  %t228 = load i8, ptr %t227, !tbaa !32
  %t230 = icmp eq i8 %t228, 95
  store i1 %t230, ptr %l106, !tbaa !21
  br label %bb83
bb83:
  %t232 = load i1, ptr %l106, !tbaa !21
  store i1 %t232, ptr %l103, !tbaa !21
  br label %bb84
bb84:
  %t233 = load i1, ptr %l103, !tbaa !21
  br i1 %t233, label %bb85, label %bb86
bb85:
  %t234 = call ptr @__olang_scope_hold(ptr %s0)
  %t235 = ptrtoint ptr %t234 to i64
  store i64 %t235, ptr %l109, !tbaa !24
  %t236 = load i1, ptr @olang_2esole_2ecompiler__2fbindgen__2ecompiler__2fbindgen__3agen__2etypeName_2elocal_2e8
  br i1 %t236, label %bb87, label %bb88
bb86:
  call void @__olang_scope_close(ptr %s17)
  call void @__olang_scope_close(ptr %s15)
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s1)
  br label %bb102
bb87:
  %t238 = call ptr @__olang_region_make(ptr %s0)
  %t239 = ptrtoint ptr %t238 to i64
  store i64 %t239, ptr %l109, !tbaa !24
  br label %bb88
bb88:
  %t240 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t240, ptr %l111, !tbaa !27
  %t241 = load { i64, ptr }, ptr %l111, !tbaa !27
  %t242 = extractvalue { i64, ptr } %t241, 0
  store i64 %t242, ptr %l112, !tbaa !24
  %t243 = load i64, ptr %l112, !tbaa !24
  %t244 = mul i64 %t243, 1
  %t245 = load i64, ptr %l109
  %t246 = inttoptr i64 %t245 to ptr
  %t247 = call ptr @__olang_held_alloc(ptr %t246, i64 %t244)
  %t248 = insertvalue { i64, ptr } undef, i64 %t243, 0
  %t249 = insertvalue { i64, ptr } %t248, ptr %t247, 1
  store { i64, ptr } %t249, ptr %l113, !tbaa !27
  %t250 = getelementptr { i64, ptr }, ptr %l113, i32 0, i32 1
  %t251 = load ptr, ptr %t250, !tbaa !27
  %t252 = getelementptr { i64, ptr }, ptr %l111, i32 0, i32 1
  %t253 = load ptr, ptr %t252, !tbaa !27
  %t254 = load i64, ptr %l112, !tbaa !24
  %t255 = mul i64 %t254, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t251, ptr %t253, i64 %t255, i1 false)
  %t256 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t256, ptr %l114, !tbaa !27
  %t257 = load { i64, ptr }, ptr %l113, !tbaa !27
  store { i64, ptr } %t257, ptr %l8, !tbaa !27
  %t258 = load i1, ptr @olang_2esole_2ecompiler__2fbindgen__2ecompiler__2fbindgen__3agen__2etypeName_2elocal_2e8
  br i1 %t258, label %bb89, label %bb90
bb89:
  %t260 = load { i64, ptr }, ptr %l114
  %t261 = extractvalue { i64, ptr } %t260, 1
  call void @__olang_region_release(ptr %t261)
  store { i64, ptr } zeroinitializer, ptr %l114
  br label %bb90
bb90:
  %t262 = load i1, ptr @olang_2esole_2ecompiler__2fbindgen__2ecompiler__2fbindgen__3agen__2etypeName_2elocal_2e8
  br i1 %t262, label %bb91, label %bb92
bb91:
  %t264 = load i64, ptr %l109
  %t265 = inttoptr i64 %t264 to ptr
  %t266 = load { i64, ptr }, ptr %l8
  %t267 = extractvalue { i64, ptr } %t266, 1
  %t268 = call ptr @__olang_region_or(ptr %t267, ptr null)
  %t269 = icmp ne ptr %t268, null
  %t270 = select i1 %t269, ptr %t268, ptr null
  call void @__olang_region_settle_in(ptr %t265, ptr %t270)
  br label %bb92
bb92:
  br label %bb93
bb93:
  call void @__olang_scope_close(ptr %s17)
  br label %bb94
bb94:
  call void @__olang_scope_close(ptr %s15)
  br label %bb95
bb95:
  call void @__olang_scope_close(ptr %s11)
  br label %bb96
bb96:
  call void @__olang_scope_close(ptr %s9)
  br label %bb97
bb97:
  call void @__olang_scope_close(ptr %s7)
  br label %bb98
bb98:
  call void @__olang_scope_close(ptr %s5)
  br label %bb99
bb99:
  br label %bb100
bb100:
  %t271 = load ptr, ptr %l1, !tbaa !29
  store ptr %t271, ptr %l117, !tbaa !29
  %t272 = load ptr, ptr %l117, !tbaa !29
  %t273 = getelementptr %"compiler/bindgen:ctp", ptr %t272, i32 0, i32 1
  %t274 = load i64, ptr %t273, !tbaa !24
  %t277 = add i64 %t274, 1
  %t279 = load ptr, ptr %l117, !tbaa !29
  %t280 = getelementptr %"compiler/bindgen:ctp", ptr %t279, i32 0, i32 1
  store i64 %t277, ptr %t280, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  br label %bb101
bb101:
  br label %bb1
bb102:
  store i64 0, ptr %l11, !tbaa !24
  %t281 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t283 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t281, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d237, i32 0, i32 1) })
  store i1 %t283, ptr %l122
  br label %bb103
bb103:
  %t284 = load i1, ptr %l122, !tbaa !21
  br i1 %t284, label %bb104, label %bb105
bb104:
  %t285 = load ptr, ptr %l0, !tbaa !29
  %t288 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2enode(ptr %v0, ptr %v0, ptr %t285, i32 1, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d238, i32 0, i32 1) }, i64 -1, i1 false, i64 0)
  store i64 %t288, ptr %l125
  br label %bb106
bb105:
  store %olang.scope zeroinitializer, ptr %s21
  %t289 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t291 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s21, { i64, ptr } %t289, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d239, i32 0, i32 1) })
  store i1 %t291, ptr %l127
  br label %bb107
bb106:
  %t292 = load i64, ptr %l125, !tbaa !24
  store i64 %t292, ptr %l11, !tbaa !24
  br label %bb152
bb107:
  %t293 = load i1, ptr %l127, !tbaa !21
  %t294 = xor i1 %t293, true
  br i1 %t294, label %bb108, label %bb109
bb108:
  store %olang.scope zeroinitializer, ptr %s22
  %t296 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t298 = call i1 @compiler_2fbindgen_2eusable(ptr %s0, { i64, ptr } %t296)
  store i1 %t298, ptr %l130
  br label %bb110
bb109:
  store %olang.scope zeroinitializer, ptr %s28
  %t299 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t301 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s28, { i64, ptr } %t299, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d240, i32 0, i32 1) })
  store i1 %t301, ptr %l167
  br label %bb134
bb110:
  %t302 = load i1, ptr %l130, !tbaa !21
  %t303 = xor i1 %t302, true
  br i1 %t303, label %bb111, label %bb112
bb111:
  %t305 = load ptr, ptr %l0, !tbaa !29
  %t307 = getelementptr %"compiler/bindgen:gen", ptr %t305, i32 0, i32 1
  %t308 = load i1, ptr %t307, !tbaa !21
  %t310 = xor i1 %t308, true
  store i1 %t310, ptr %l132, !tbaa !21
  br label %bb113
bb112:
  store i1 false, ptr %l132, !tbaa !21
  br label %bb113
bb113:
  %t312 = load i1, ptr %l132, !tbaa !21
  br i1 %t312, label %bb114, label %bb115
bb114:
  %t313 = load ptr, ptr %l0, !tbaa !29
  store ptr %t313, ptr %l136, !tbaa !29
  %t314 = call ptr @__olang_scope_hold(ptr %v0)
  %t315 = ptrtoint ptr %t314 to i64
  store i64 %t315, ptr %l137, !tbaa !24
  %t316 = load i1, ptr @olang_2esole_2ecompiler_2fbindgen_3actype_2e1
  br i1 %t316, label %bb116, label %bb117
bb115:
  br label %bb119
bb116:
  %t318 = call ptr @__olang_region_make(ptr %v0)
  %t319 = ptrtoint ptr %t318 to i64
  store i64 %t319, ptr %l137, !tbaa !24
  br label %bb117
bb117:
  %t320 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t321 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t322 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t323 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d241, i32 0, i32 1) }, 1
  %t324 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d241, i32 0, i32 1) }, 0
  %t326 = extractvalue { i64, ptr } %t320, 1
  %t327 = extractvalue { i64, ptr } %t320, 0
  %t328 = add i64 %t324, %t327
  %t329 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d242, i32 0, i32 1) }, 1
  %t330 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d242, i32 0, i32 1) }, 0
  %t331 = add i64 %t328, %t330
  %t333 = extractvalue { i64, ptr } %t321, 1
  %t334 = extractvalue { i64, ptr } %t321, 0
  %t335 = add i64 %t331, %t334
  %t336 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d243, i32 0, i32 1) }, 1
  %t337 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d243, i32 0, i32 1) }, 0
  %t338 = add i64 %t335, %t337
  %t340 = extractvalue { i64, ptr } %t322, 1
  %t341 = extractvalue { i64, ptr } %t322, 0
  %t342 = add i64 %t338, %t341
  %t343 = extractvalue { i64, ptr } { i64 45, ptr getelementptr inbounds (<{ i64, [45 x i8] }>, ptr @.d244, i32 0, i32 1) }, 1
  %t344 = extractvalue { i64, ptr } { i64 45, ptr getelementptr inbounds (<{ i64, [45 x i8] }>, ptr @.d244, i32 0, i32 1) }, 0
  %t345 = add i64 %t342, %t344
  %t346 = load i64, ptr %l137
  %t347 = inttoptr i64 %t346 to ptr
  %t348 = call ptr @__olang_held_alloc(ptr %t347, i64 %t345)
  call void @olang_textcopy(ptr %t348, ptr %t323, i64 %t324)
  %t349 = getelementptr i8, ptr %t348, i64 %t324
  call void @olang_textcopy(ptr %t349, ptr %t326, i64 %t327)
  %t350 = getelementptr i8, ptr %t349, i64 %t327
  call void @olang_textcopy(ptr %t350, ptr %t329, i64 %t330)
  %t351 = getelementptr i8, ptr %t350, i64 %t330
  call void @olang_textcopy(ptr %t351, ptr %t333, i64 %t334)
  %t352 = getelementptr i8, ptr %t351, i64 %t334
  call void @olang_textcopy(ptr %t352, ptr %t336, i64 %t337)
  %t353 = getelementptr i8, ptr %t352, i64 %t337
  call void @olang_textcopy(ptr %t353, ptr %t340, i64 %t341)
  %t354 = getelementptr i8, ptr %t353, i64 %t341
  call void @olang_textcopy(ptr %t354, ptr %t343, i64 %t344)
  %t355 = insertvalue { i64, ptr } undef, i64 %t345, 0
  %t356 = insertvalue { i64, ptr } %t355, ptr %t348, 1
  %t358 = load ptr, ptr %l136, !tbaa !29
  %t360 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ebad(ptr %v0, ptr %v0, ptr %t358, { i64, ptr } %t356)
  store i64 %t360, ptr %l144
  br label %bb118
bb118:
  call void @__olang_scope_close(ptr %s22)
  call void @__olang_scope_close(ptr %s21)
  call void @__olang_scope_close(ptr %s0)
  %t361 = load i64, ptr %l144, !tbaa !24
  store i64 %t361, ptr %rv
  br label %ret
bb119:
  %t362 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t364 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s22, { i64, ptr } %t362, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d245, i32 0, i32 1) })
  store i1 %t364, ptr %l146
  br label %bb120
bb120:
  %t365 = load i1, ptr %l146, !tbaa !21
  br i1 %t365, label %bb121, label %bb122
bb121:
  store i1 true, ptr %l147, !tbaa !21
  br label %bb124
bb122:
  %t366 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t368 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s22, { i64, ptr } %t366, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d246, i32 0, i32 1) })
  store i1 %t368, ptr %l149
  br label %bb123
bb123:
  %t369 = load i1, ptr %l149, !tbaa !21
  store i1 %t369, ptr %l147, !tbaa !21
  br label %bb124
bb124:
  %t370 = load i1, ptr %l147, !tbaa !21
  br i1 %t370, label %bb125, label %bb126
bb125:
  %t371 = load ptr, ptr %l0, !tbaa !29
  store ptr %t371, ptr %l150, !tbaa !29
  %t372 = call ptr @__olang_scope_hold(ptr %v0)
  %t373 = ptrtoint ptr %t372 to i64
  store i64 %t373, ptr %l151, !tbaa !24
  %t374 = load i1, ptr @olang_2esole_2ecompiler_2fbindgen_3actype_2e1
  br i1 %t374, label %bb127, label %bb128
bb126:
  br label %bb130
bb127:
  %t376 = call ptr @__olang_region_make(ptr %v0)
  %t377 = ptrtoint ptr %t376 to i64
  store i64 %t377, ptr %l151, !tbaa !24
  br label %bb128
bb128:
  %t378 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t379 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d247, i32 0, i32 1) }, 1
  %t380 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d247, i32 0, i32 1) }, 0
  %t382 = extractvalue { i64, ptr } %t378, 1
  %t383 = extractvalue { i64, ptr } %t378, 0
  %t384 = add i64 %t380, %t383
  %t385 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d248, i32 0, i32 1) }, 1
  %t386 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d248, i32 0, i32 1) }, 0
  %t387 = add i64 %t384, %t386
  %t388 = load i64, ptr %l151
  %t389 = inttoptr i64 %t388 to ptr
  %t390 = call ptr @__olang_held_alloc(ptr %t389, i64 %t387)
  call void @olang_textcopy(ptr %t390, ptr %t379, i64 %t380)
  %t391 = getelementptr i8, ptr %t390, i64 %t380
  call void @olang_textcopy(ptr %t391, ptr %t382, i64 %t383)
  %t392 = getelementptr i8, ptr %t391, i64 %t383
  call void @olang_textcopy(ptr %t392, ptr %t385, i64 %t386)
  %t393 = insertvalue { i64, ptr } undef, i64 %t387, 0
  %t394 = insertvalue { i64, ptr } %t393, ptr %t390, 1
  %t396 = load ptr, ptr %l150, !tbaa !29
  %t398 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ebad(ptr %v0, ptr %v0, ptr %t396, { i64, ptr } %t394)
  store i64 %t398, ptr %l156
  br label %bb129
bb129:
  call void @__olang_scope_close(ptr %s22)
  call void @__olang_scope_close(ptr %s21)
  call void @__olang_scope_close(ptr %s0)
  %t399 = load i64, ptr %l156, !tbaa !24
  store i64 %t399, ptr %rv
  br label %ret
bb130:
  %t400 = load ptr, ptr %l0, !tbaa !29
  store ptr %t400, ptr %l157, !tbaa !29
  store i32 2, ptr %l158
  %t401 = call ptr @__olang_scope_hold(ptr %v0)
  %t402 = ptrtoint ptr %t401 to i64
  store i64 %t402, ptr %l159, !tbaa !24
  %t403 = load i1, ptr @olang_2esole_2ecompiler_2fbindgen_3actype_2e1
  br i1 %t403, label %bb131, label %bb132
bb131:
  %t405 = call ptr @__olang_region_make(ptr %v0)
  %t406 = ptrtoint ptr %t405 to i64
  store i64 %t406, ptr %l159, !tbaa !24
  br label %bb132
bb132:
  %t407 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t408 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t410 = extractvalue { i64, ptr } %t407, 1
  %t411 = extractvalue { i64, ptr } %t407, 0
  %t412 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d249, i32 0, i32 1) }, 1
  %t413 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d249, i32 0, i32 1) }, 0
  %t414 = add i64 %t411, %t413
  %t416 = extractvalue { i64, ptr } %t408, 1
  %t417 = extractvalue { i64, ptr } %t408, 0
  %t418 = add i64 %t414, %t417
  %t419 = load i64, ptr %l159
  %t420 = inttoptr i64 %t419 to ptr
  %t421 = call ptr @__olang_held_alloc(ptr %t420, i64 %t418)
  call void @olang_textcopy(ptr %t421, ptr %t410, i64 %t411)
  %t422 = getelementptr i8, ptr %t421, i64 %t411
  call void @olang_textcopy(ptr %t422, ptr %t412, i64 %t413)
  %t423 = getelementptr i8, ptr %t422, i64 %t413
  call void @olang_textcopy(ptr %t423, ptr %t416, i64 %t417)
  %t424 = insertvalue { i64, ptr } undef, i64 %t418, 0
  %t425 = insertvalue { i64, ptr } %t424, ptr %t421, 1
  %t427 = load ptr, ptr %l157, !tbaa !29
  %t428 = load i32, ptr %l158, !range !{i32 0, i32 7}
  %t430 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2enode(ptr %v0, ptr %v0, ptr %t427, i32 %t428, { i64, ptr } %t425, i64 -1, i1 false, i64 0)
  store i64 %t430, ptr %l165
  br label %bb133
bb133:
  %t431 = load i64, ptr %l165, !tbaa !24
  store i64 %t431, ptr %l11, !tbaa !24
  call void @__olang_scope_close(ptr %s22)
  br label %bb151
bb134:
  %t432 = load i1, ptr %l167, !tbaa !21
  %t433 = xor i1 %t432, true
  br i1 %t433, label %bb135, label %bb136
bb135:
  store %olang.scope zeroinitializer, ptr %s29
  %t435 = load ptr, ptr %l0, !tbaa !29
  %t437 = getelementptr %"compiler/bindgen:gen", ptr %t435, i32 0, i32 5
  %t438 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t441 = call { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha4444909f5ef14f7626d25b8f59e6ba2(ptr %v0, ptr %s0, ptr %v0, ptr %t437, { i64, ptr } %t438)
  %t442 = extractvalue { i32, { i64, ptr } } %t441, 1
  %t443 = extractvalue { i32, { i64, ptr } } %t441, 0
  store i32 %t443, ptr %l174
  %t444 = icmp ne i32 %t443, 0
  br i1 %t444, label %bb138, label %ok.445, !prof !99
ok.445:
  store { i64, ptr } %t442, ptr %l173
  br label %bb137
bb136:
  %t446 = load ptr, ptr %l0, !tbaa !29
  %t447 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t448 = load i64, ptr %l3, !tbaa !24
  %t449 = load i64, ptr %l4, !tbaa !24
  %t454 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2enumType(ptr %v0, ptr %s0, ptr %t446, { i64, ptr } %t447, i64 %t448, i64 %t449)
  store i64 %t454, ptr %l193
  br label %bb149
bb137:
  %t455 = load { i64, ptr }, ptr %l173, !tbaa !27
  store { i64, ptr } %t455, ptr %l169, !tbaa !27
  br label %bb140
bb138:
  br label %bb139
bb139:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d250, i32 0, i32 1) }, ptr %l169, !tbaa !27
  br label %bb140
bb140:
  %t456 = load { i64, ptr }, ptr %l169, !tbaa !27
  store { i64, ptr } %t456, ptr %l12, !tbaa !27
  %t457 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t459 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s29, { i64, ptr } %t457, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d251, i32 0, i32 1) })
  store i1 %t459, ptr %l176
  br label %bb141
bb141:
  %t460 = load i1, ptr %l176, !tbaa !21
  br i1 %t460, label %bb142, label %bb143
bb142:
  %t461 = load ptr, ptr %l0, !tbaa !29
  store ptr %t461, ptr %l177, !tbaa !29
  %t462 = call ptr @__olang_scope_hold(ptr %v0)
  %t463 = ptrtoint ptr %t462 to i64
  store i64 %t463, ptr %l178, !tbaa !24
  %t464 = load i1, ptr @olang_2esole_2ecompiler_2fbindgen_3actype_2e1
  br i1 %t464, label %bb144, label %bb145
bb143:
  br label %bb147
bb144:
  %t466 = call ptr @__olang_region_make(ptr %v0)
  %t467 = ptrtoint ptr %t466 to i64
  store i64 %t467, ptr %l178, !tbaa !24
  br label %bb145
bb145:
  %t468 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t469 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d252, i32 0, i32 1) }, 1
  %t470 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d252, i32 0, i32 1) }, 0
  %t472 = extractvalue { i64, ptr } %t468, 1
  %t473 = extractvalue { i64, ptr } %t468, 0
  %t474 = add i64 %t470, %t473
  %t475 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d253, i32 0, i32 1) }, 1
  %t476 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d253, i32 0, i32 1) }, 0
  %t477 = add i64 %t474, %t476
  %t478 = load i64, ptr %l178
  %t479 = inttoptr i64 %t478 to ptr
  %t480 = call ptr @__olang_held_alloc(ptr %t479, i64 %t477)
  call void @olang_textcopy(ptr %t480, ptr %t469, i64 %t470)
  %t481 = getelementptr i8, ptr %t480, i64 %t470
  call void @olang_textcopy(ptr %t481, ptr %t472, i64 %t473)
  %t482 = getelementptr i8, ptr %t481, i64 %t473
  call void @olang_textcopy(ptr %t482, ptr %t475, i64 %t476)
  %t483 = insertvalue { i64, ptr } undef, i64 %t477, 0
  %t484 = insertvalue { i64, ptr } %t483, ptr %t480, 1
  %t486 = load ptr, ptr %l177, !tbaa !29
  %t488 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ebad(ptr %v0, ptr %v0, ptr %t486, { i64, ptr } %t484)
  store i64 %t488, ptr %l183
  br label %bb146
bb146:
  call void @__olang_scope_close(ptr %s29)
  call void @__olang_scope_close(ptr %s28)
  call void @__olang_scope_close(ptr %s21)
  call void @__olang_scope_close(ptr %s0)
  %t489 = load i64, ptr %l183, !tbaa !24
  store i64 %t489, ptr %rv
  br label %ret
bb147:
  %t490 = load ptr, ptr %l0, !tbaa !29
  %t491 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t492 = load i64, ptr %l2, !tbaa !24
  %t494 = add i64 %t492, 1
  %t498 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eparseType(ptr %v0, ptr %v0, ptr %t490, { i64, ptr } %t491, i64 %t494)
  store i64 %t498, ptr %l188
  br label %bb148
bb148:
  %t499 = load i64, ptr %l188, !tbaa !24
  store i64 %t499, ptr %l11, !tbaa !24
  call void @__olang_scope_close(ptr %s29)
  br label %bb150
bb149:
  %t500 = load i64, ptr %l193, !tbaa !24
  store i64 %t500, ptr %l11, !tbaa !24
  br label %bb150
bb150:
  call void @__olang_scope_close(ptr %s28)
  br label %bb151
bb151:
  call void @__olang_scope_close(ptr %s21)
  br label %bb152
bb152:
  %t501 = load ptr, ptr %l0, !tbaa !29
  %t502 = load ptr, ptr %l1, !tbaa !29
  %t503 = load i64, ptr %l11, !tbaa !24
  %t504 = load i1, ptr %l6, !tbaa !21
  %t505 = load i64, ptr %l2, !tbaa !24
  %t511 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2edeclarator(ptr %v0, ptr %v1, ptr %t501, ptr %t502, i64 %t503, i1 %t504, i64 %t505)
  store i64 %t511, ptr %l199
  br label %bb153
bb153:
  call void @__olang_scope_close(ptr %s0)
  %t512 = load i64, ptr %l199, !tbaa !24
  store i64 %t512, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eunionAccessors(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i1 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i1
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l6 = alloca %"compiler/bindgen:record"
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca i64
  %l16 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l17 = alloca ptr
  %l18 = alloca i64
  %l20 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l21 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l22 = alloca ptr
  %l23 = alloca i64
  %l25 = alloca %"std/prelude/text:StringBuilder"
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l39 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l40 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l44 = alloca %"compiler/bindgen:record"
  %l45 = alloca %"compiler/bindgen:record"
  %l46 = alloca i64
  %l48 = alloca { i64, ptr }
  %l49 = alloca i64
  %l50 = alloca { i64, ptr }
  %l54 = alloca i64
  %l56 = alloca { i64, ptr }
  %l57 = alloca i64
  %l58 = alloca { i64, ptr }
  %l62 = alloca i64
  %l64 = alloca { i64, ptr }
  %l65 = alloca i64
  %l66 = alloca { i64, ptr }
  %l70 = alloca i64
  %l72 = alloca { i64, ptr }
  %l73 = alloca i64
  %l74 = alloca { i64, ptr }
  %l78 = alloca i64
  %l80 = alloca { i64, ptr }
  %l81 = alloca i64
  %l82 = alloca { i64, ptr }
  %l86 = alloca i64
  %l88 = alloca { i64, ptr }
  %l89 = alloca i64
  %l90 = alloca { i64, ptr }
  %l96 = alloca i64
  %l100 = alloca i64
  %l103 = alloca i64
  %l123 = alloca { i64, ptr }
  %l124 = alloca i1
  %l125 = alloca ptr
  %l128 = alloca { i64, ptr }
  %l129 = alloca ptr
  %l132 = alloca { i64, ptr }
  %l144 = alloca %"compiler/bindgen:record"
  %l146 = alloca i64
  %l148 = alloca i64
  %l150 = alloca { i64, ptr }
  %l151 = alloca { i64, ptr }
  %l152 = alloca i64
  %l153 = alloca { i64, ptr }
  %l157 = alloca %"compiler/bindgen:record"
  %l159 = alloca %"compiler/bindgen:record"
  %l161 = alloca i64
  %l163 = alloca i64
  %l168 = alloca i64
  %l174 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l176 = alloca i64
  %l178 = alloca i64
  %l183 = alloca { i64, ptr }
  %l190 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l191 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l196 = alloca i32
  %l198 = alloca i1
  %l200 = alloca i64
  %l202 = alloca i64
  %l207 = alloca { i64, ptr }
  %l213 = alloca %"std/prelude/text:StringBuilder"
  %l215 = alloca i64
  %l219 = alloca i64
  %l222 = alloca i64
  %l240 = alloca ptr
  %l243 = alloca { i64, ptr }
  %l244 = alloca { i64, ptr }
  %l247 = alloca { i64, ptr }
  %l249 = alloca i1
  %l250 = alloca i1
  %l253 = alloca i64
  %l255 = alloca i1
  %l257 = alloca i1
  %l259 = alloca i1
  %l264 = alloca i1
  %l266 = alloca i64
  %l269 = alloca ptr
  %l273 = alloca %"compiler/bindgen:record"
  %l274 = alloca { i64, ptr }
  %l275 = alloca { i64, ptr }
  %l276 = alloca { i64, ptr }
  %l280 = alloca %"compiler/bindgen:record"
  %l281 = alloca i64
  %l284 = alloca i64
  %l285 = alloca { i64, ptr }
  %l287 = alloca ptr
  %l288 = alloca i64
  %l291 = alloca i64
  %l293 = alloca i64
  %l296 = alloca i64
  %l300 = alloca i64
  %l302 = alloca i64
  %l306 = alloca %"compiler/bindgen:record"
  %l308 = alloca i64
  %l309 = alloca ptr
  %l313 = alloca %"compiler/bindgen:record"
  %l314 = alloca { i64, ptr }
  %l315 = alloca { i64, ptr }
  %l316 = alloca { i64, ptr }
  %l319 = alloca { i64, ptr }
  %l320 = alloca i64
  %l323 = alloca i64
  %l326 = alloca { i64, ptr }
  %l332 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  %t11 = alloca %"compiler/bindgen:record", align 8
  %t387 = alloca %"compiler/bindgen:record", align 8
  %t419 = alloca %"compiler/bindgen:record", align 8
  %t422 = alloca %"compiler/bindgen:record", align 8
  %t635 = alloca %"compiler/bindgen:record", align 8
  %t646 = alloca %"compiler/bindgen:record", align 8
  %t697 = alloca %"compiler/bindgen:record", align 8
  %t711 = alloca %"compiler/bindgen:record", align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i1 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l38
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l38
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l3
  %t3 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %l39
  br label %bb2
bb2:
  %t4 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l39
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t4, ptr %l4
  %t5 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %l40
  br label %bb3
bb3:
  %t6 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l40
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t6, ptr %l5
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/bindgen:gen", ptr %t7, i32 0, i32 6
  %t10 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eAt_3ccompiler_2fbindgen_3arecord_3e(ptr %t11, ptr %v0, ptr %v0, ptr %t9, i64 %t10)
  call void @llvm.memmove.p0.p0.i64(ptr %l44, ptr %t11, i64 312, i1 false)
  br label %bb4
bb4:
  call void @llvm.memmove.p0.p0.i64(ptr %l45, ptr %l44, i64 312, i1 false)
  %t14 = call ptr @__olang_scope_hold(ptr %v0)
  %t15 = ptrtoint ptr %t14 to i64
  store i64 %t15, ptr %l46, !tbaa !24
  %t16 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e0
  br i1 %t16, label %bb5, label %bb6
bb5:
  %t18 = call ptr @__olang_region_make_part(ptr %v0)
  %t19 = ptrtoint ptr %t18 to i64
  store i64 %t19, ptr %l46, !tbaa !24
  br label %bb6
bb6:
  %t20 = getelementptr %"compiler/bindgen:record", ptr %l45, i32 0, i32 4
  %t21 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t20, i32 0, i32 0
  %t22 = load { i64, ptr }, ptr %t21, !tbaa !27
  store { i64, ptr } %t22, ptr %l48, !tbaa !27
  %t23 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t24 = extractvalue { i64, ptr } %t23, 0
  store i64 %t24, ptr %l49, !tbaa !24
  %t25 = load i64, ptr %l49, !tbaa !24
  %t26 = mul i64 %t25, 16
  %t27 = load i64, ptr %l46
  %t28 = inttoptr i64 %t27 to ptr
  %t29 = call ptr @__olang_held_alloc(ptr %t28, i64 %t26)
  %t30 = insertvalue { i64, ptr } undef, i64 %t25, 0
  %t31 = insertvalue { i64, ptr } %t30, ptr %t29, 1
  store { i64, ptr } %t31, ptr %l50, !tbaa !27
  %t32 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !27
  %t34 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !27
  %t36 = load i64, ptr %l49, !tbaa !24
  %t37 = mul i64 %t36, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t33, ptr %t35, i64 %t37, i1 false)
  %t38 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t39 = getelementptr %"compiler/bindgen:record", ptr %l45, i32 0, i32 4
  %t40 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t39, i32 0, i32 0
  store { i64, ptr } %t38, ptr %t40, !tbaa !27
  %t41 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e0
  br i1 %t41, label %bb7, label %bb8
bb7:
  %t43 = getelementptr %"compiler/bindgen:record", ptr %l45, i32 0, i32 4
  %t44 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t43, i32 0, i32 0
  %t45 = load { i64, ptr }, ptr %t44, !tbaa !27
  %t46 = extractvalue { i64, ptr } %t45, 0
  %t48 = icmp eq i64 %t46, 0
  br i1 %t48, label %bb9, label %bb10
bb8:
  %t50 = call ptr @__olang_scope_hold(ptr %v0)
  %t51 = ptrtoint ptr %t50 to i64
  store i64 %t51, ptr %l54, !tbaa !24
  %t52 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e0
  br i1 %t52, label %bb11, label %bb12
bb9:
  %t54 = getelementptr %"compiler/bindgen:record", ptr %l45, i32 0, i32 4
  %t55 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t54, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t55, !tbaa !27
  br label %bb10
bb10:
  %t56 = getelementptr %"compiler/bindgen:record", ptr %l45, i32 0, i32 4
  %t57 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t56, i32 0, i32 0
  %t58 = load i64, ptr %l46
  %t59 = inttoptr i64 %t58 to ptr
  %t60 = load { i64, ptr }, ptr %t57
  %t61 = extractvalue { i64, ptr } %t60, 1
  %t62 = call ptr @__olang_region_or(ptr %t61, ptr null)
  %t63 = icmp ne ptr %t62, null
  %t64 = select i1 %t63, ptr %t62, ptr null
  call void @__olang_region_settle_in(ptr %t59, ptr %t64)
  br label %bb8
bb11:
  %t65 = call ptr @__olang_region_make_part(ptr %v0)
  %t66 = ptrtoint ptr %t65 to i64
  store i64 %t66, ptr %l54, !tbaa !24
  br label %bb12
bb12:
  %t67 = getelementptr %"compiler/bindgen:record", ptr %l45, i32 0, i32 5
  %t68 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t67, i32 0, i32 0
  %t69 = load { i64, ptr }, ptr %t68, !tbaa !27
  store { i64, ptr } %t69, ptr %l56, !tbaa !27
  %t70 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t71 = extractvalue { i64, ptr } %t70, 0
  store i64 %t71, ptr %l57, !tbaa !24
  %t72 = load i64, ptr %l57, !tbaa !24
  %t73 = mul i64 %t72, 16
  %t74 = load i64, ptr %l54
  %t75 = inttoptr i64 %t74 to ptr
  %t76 = call ptr @__olang_held_alloc(ptr %t75, i64 %t73)
  %t77 = insertvalue { i64, ptr } undef, i64 %t72, 0
  %t78 = insertvalue { i64, ptr } %t77, ptr %t76, 1
  store { i64, ptr } %t78, ptr %l58, !tbaa !27
  %t79 = getelementptr { i64, ptr }, ptr %l58, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !27
  %t81 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !27
  %t83 = load i64, ptr %l57, !tbaa !24
  %t84 = mul i64 %t83, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t80, ptr %t82, i64 %t84, i1 false)
  %t85 = load { i64, ptr }, ptr %l58, !tbaa !27
  %t86 = getelementptr %"compiler/bindgen:record", ptr %l45, i32 0, i32 5
  %t87 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t86, i32 0, i32 0
  store { i64, ptr } %t85, ptr %t87, !tbaa !27
  %t88 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e0
  br i1 %t88, label %bb13, label %bb14
bb13:
  %t90 = getelementptr %"compiler/bindgen:record", ptr %l45, i32 0, i32 5
  %t91 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t90, i32 0, i32 0
  %t92 = load { i64, ptr }, ptr %t91, !tbaa !27
  %t93 = extractvalue { i64, ptr } %t92, 0
  %t95 = icmp eq i64 %t93, 0
  br i1 %t95, label %bb15, label %bb16
bb14:
  %t97 = call ptr @__olang_scope_hold(ptr %v0)
  %t98 = ptrtoint ptr %t97 to i64
  store i64 %t98, ptr %l62, !tbaa !24
  %t99 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t99, label %bb17, label %bb18
bb15:
  %t101 = getelementptr %"compiler/bindgen:record", ptr %l45, i32 0, i32 5
  %t102 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t101, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t102, !tbaa !27
  br label %bb16
bb16:
  %t103 = getelementptr %"compiler/bindgen:record", ptr %l45, i32 0, i32 5
  %t104 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t103, i32 0, i32 0
  %t105 = load i64, ptr %l54
  %t106 = inttoptr i64 %t105 to ptr
  %t107 = load { i64, ptr }, ptr %t104
  %t108 = extractvalue { i64, ptr } %t107, 1
  %t109 = call ptr @__olang_region_or(ptr %t108, ptr null)
  %t110 = icmp ne ptr %t109, null
  %t111 = select i1 %t110, ptr %t109, ptr null
  call void @__olang_region_settle_in(ptr %t106, ptr %t111)
  br label %bb14
bb17:
  %t112 = call ptr @__olang_region_make_part(ptr %v0)
  %t113 = ptrtoint ptr %t112 to i64
  store i64 %t113, ptr %l62, !tbaa !24
  br label %bb18
bb18:
  %t114 = getelementptr %"compiler/bindgen:record", ptr %l45, i32 0, i32 16
  %t115 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t114, i32 0, i32 0
  %t116 = load { i64, ptr }, ptr %t115, !tbaa !27
  store { i64, ptr } %t116, ptr %l64, !tbaa !27
  %t117 = load { i64, ptr }, ptr %l64, !tbaa !27
  %t118 = extractvalue { i64, ptr } %t117, 0
  store i64 %t118, ptr %l65, !tbaa !24
  %t119 = load i64, ptr %l65, !tbaa !24
  %t120 = mul i64 %t119, 8
  %t121 = load i64, ptr %l62
  %t122 = inttoptr i64 %t121 to ptr
  %t123 = call ptr @__olang_held_alloc(ptr %t122, i64 %t120)
  %t124 = insertvalue { i64, ptr } undef, i64 %t119, 0
  %t125 = insertvalue { i64, ptr } %t124, ptr %t123, 1
  store { i64, ptr } %t125, ptr %l66, !tbaa !27
  %t126 = getelementptr { i64, ptr }, ptr %l66, i32 0, i32 1
  %t127 = load ptr, ptr %t126, !tbaa !27
  %t128 = getelementptr { i64, ptr }, ptr %l64, i32 0, i32 1
  %t129 = load ptr, ptr %t128, !tbaa !27
  %t130 = load i64, ptr %l65, !tbaa !24
  %t131 = mul i64 %t130, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t127, ptr %t129, i64 %t131, i1 false)
  %t132 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t133 = getelementptr %"compiler/bindgen:record", ptr %l45, i32 0, i32 16
  %t134 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t133, i32 0, i32 0
  store { i64, ptr } %t132, ptr %t134, !tbaa !27
  %t135 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t135, label %bb19, label %bb20
bb19:
  %t137 = getelementptr %"compiler/bindgen:record", ptr %l45, i32 0, i32 16
  %t138 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t137, i32 0, i32 0
  %t139 = load { i64, ptr }, ptr %t138, !tbaa !27
  %t140 = extractvalue { i64, ptr } %t139, 0
  %t142 = icmp eq i64 %t140, 0
  br i1 %t142, label %bb21, label %bb22
bb20:
  %t144 = call ptr @__olang_scope_hold(ptr %v0)
  %t145 = ptrtoint ptr %t144 to i64
  store i64 %t145, ptr %l70, !tbaa !24
  %t146 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t146, label %bb23, label %bb24
bb21:
  %t148 = getelementptr %"compiler/bindgen:record", ptr %l45, i32 0, i32 16
  %t149 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t148, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t149, !tbaa !27
  br label %bb22
bb22:
  %t150 = getelementptr %"compiler/bindgen:record", ptr %l45, i32 0, i32 16
  %t151 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t150, i32 0, i32 0
  %t152 = load i64, ptr %l62
  %t153 = inttoptr i64 %t152 to ptr
  %t154 = load { i64, ptr }, ptr %t151
  %t155 = extractvalue { i64, ptr } %t154, 1
  %t156 = call ptr @__olang_region_or(ptr %t155, ptr null)
  %t157 = icmp ne ptr %t156, null
  %t158 = select i1 %t157, ptr %t156, ptr null
  call void @__olang_region_settle_in(ptr %t153, ptr %t158)
  br label %bb20
bb23:
  %t159 = call ptr @__olang_region_make_part(ptr %v0)
  %t160 = ptrtoint ptr %t159 to i64
  store i64 %t160, ptr %l70, !tbaa !24
  br label %bb24
bb24:
  %t161 = getelementptr %"compiler/bindgen:record", ptr %l45, i32 0, i32 17
  %t162 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t161, i32 0, i32 0
  %t163 = load { i64, ptr }, ptr %t162, !tbaa !27
  store { i64, ptr } %t163, ptr %l72, !tbaa !27
  %t164 = load { i64, ptr }, ptr %l72, !tbaa !27
  %t165 = extractvalue { i64, ptr } %t164, 0
  store i64 %t165, ptr %l73, !tbaa !24
  %t166 = load i64, ptr %l73, !tbaa !24
  %t167 = mul i64 %t166, 8
  %t168 = load i64, ptr %l70
  %t169 = inttoptr i64 %t168 to ptr
  %t170 = call ptr @__olang_held_alloc(ptr %t169, i64 %t167)
  %t171 = insertvalue { i64, ptr } undef, i64 %t166, 0
  %t172 = insertvalue { i64, ptr } %t171, ptr %t170, 1
  store { i64, ptr } %t172, ptr %l74, !tbaa !27
  %t173 = getelementptr { i64, ptr }, ptr %l74, i32 0, i32 1
  %t174 = load ptr, ptr %t173, !tbaa !27
  %t175 = getelementptr { i64, ptr }, ptr %l72, i32 0, i32 1
  %t176 = load ptr, ptr %t175, !tbaa !27
  %t177 = load i64, ptr %l73, !tbaa !24
  %t178 = mul i64 %t177, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t174, ptr %t176, i64 %t178, i1 false)
  %t179 = load { i64, ptr }, ptr %l74, !tbaa !27
  %t180 = getelementptr %"compiler/bindgen:record", ptr %l45, i32 0, i32 17
  %t181 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t180, i32 0, i32 0
  store { i64, ptr } %t179, ptr %t181, !tbaa !27
  %t182 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t182, label %bb25, label %bb26
bb25:
  %t184 = getelementptr %"compiler/bindgen:record", ptr %l45, i32 0, i32 17
  %t185 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t184, i32 0, i32 0
  %t186 = load { i64, ptr }, ptr %t185, !tbaa !27
  %t187 = extractvalue { i64, ptr } %t186, 0
  %t189 = icmp eq i64 %t187, 0
  br i1 %t189, label %bb27, label %bb28
bb26:
  %t191 = call ptr @__olang_scope_hold(ptr %v0)
  %t192 = ptrtoint ptr %t191 to i64
  store i64 %t192, ptr %l78, !tbaa !24
  %t193 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t193, label %bb29, label %bb30
bb27:
  %t195 = getelementptr %"compiler/bindgen:record", ptr %l45, i32 0, i32 17
  %t196 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t195, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t196, !tbaa !27
  br label %bb28
bb28:
  %t197 = getelementptr %"compiler/bindgen:record", ptr %l45, i32 0, i32 17
  %t198 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t197, i32 0, i32 0
  %t199 = load i64, ptr %l70
  %t200 = inttoptr i64 %t199 to ptr
  %t201 = load { i64, ptr }, ptr %t198
  %t202 = extractvalue { i64, ptr } %t201, 1
  %t203 = call ptr @__olang_region_or(ptr %t202, ptr null)
  %t204 = icmp ne ptr %t203, null
  %t205 = select i1 %t204, ptr %t203, ptr null
  call void @__olang_region_settle_in(ptr %t200, ptr %t205)
  br label %bb26
bb29:
  %t206 = call ptr @__olang_region_make_part(ptr %v0)
  %t207 = ptrtoint ptr %t206 to i64
  store i64 %t207, ptr %l78, !tbaa !24
  br label %bb30
bb30:
  %t208 = getelementptr %"compiler/bindgen:record", ptr %l45, i32 0, i32 18
  %t209 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t208, i32 0, i32 0
  %t210 = load { i64, ptr }, ptr %t209, !tbaa !27
  store { i64, ptr } %t210, ptr %l80, !tbaa !27
  %t211 = load { i64, ptr }, ptr %l80, !tbaa !27
  %t212 = extractvalue { i64, ptr } %t211, 0
  store i64 %t212, ptr %l81, !tbaa !24
  %t213 = load i64, ptr %l81, !tbaa !24
  %t214 = mul i64 %t213, 8
  %t215 = load i64, ptr %l78
  %t216 = inttoptr i64 %t215 to ptr
  %t217 = call ptr @__olang_held_alloc(ptr %t216, i64 %t214)
  %t218 = insertvalue { i64, ptr } undef, i64 %t213, 0
  %t219 = insertvalue { i64, ptr } %t218, ptr %t217, 1
  store { i64, ptr } %t219, ptr %l82, !tbaa !27
  %t220 = getelementptr { i64, ptr }, ptr %l82, i32 0, i32 1
  %t221 = load ptr, ptr %t220, !tbaa !27
  %t222 = getelementptr { i64, ptr }, ptr %l80, i32 0, i32 1
  %t223 = load ptr, ptr %t222, !tbaa !27
  %t224 = load i64, ptr %l81, !tbaa !24
  %t225 = mul i64 %t224, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t221, ptr %t223, i64 %t225, i1 false)
  %t226 = load { i64, ptr }, ptr %l82, !tbaa !27
  %t227 = getelementptr %"compiler/bindgen:record", ptr %l45, i32 0, i32 18
  %t228 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t227, i32 0, i32 0
  store { i64, ptr } %t226, ptr %t228, !tbaa !27
  %t229 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t229, label %bb31, label %bb32
bb31:
  %t231 = getelementptr %"compiler/bindgen:record", ptr %l45, i32 0, i32 18
  %t232 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t231, i32 0, i32 0
  %t233 = load { i64, ptr }, ptr %t232, !tbaa !27
  %t234 = extractvalue { i64, ptr } %t233, 0
  %t236 = icmp eq i64 %t234, 0
  br i1 %t236, label %bb33, label %bb34
bb32:
  %t238 = call ptr @__olang_scope_hold(ptr %v0)
  %t239 = ptrtoint ptr %t238 to i64
  store i64 %t239, ptr %l86, !tbaa !24
  %t240 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t240, label %bb35, label %bb36
bb33:
  %t242 = getelementptr %"compiler/bindgen:record", ptr %l45, i32 0, i32 18
  %t243 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t242, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t243, !tbaa !27
  br label %bb34
bb34:
  %t244 = getelementptr %"compiler/bindgen:record", ptr %l45, i32 0, i32 18
  %t245 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t244, i32 0, i32 0
  %t246 = load i64, ptr %l78
  %t247 = inttoptr i64 %t246 to ptr
  %t248 = load { i64, ptr }, ptr %t245
  %t249 = extractvalue { i64, ptr } %t248, 1
  %t250 = call ptr @__olang_region_or(ptr %t249, ptr null)
  %t251 = icmp ne ptr %t250, null
  %t252 = select i1 %t251, ptr %t250, ptr null
  call void @__olang_region_settle_in(ptr %t247, ptr %t252)
  br label %bb32
bb35:
  %t253 = call ptr @__olang_region_make_part(ptr %v0)
  %t254 = ptrtoint ptr %t253 to i64
  store i64 %t254, ptr %l86, !tbaa !24
  br label %bb36
bb36:
  %t255 = getelementptr %"compiler/bindgen:record", ptr %l45, i32 0, i32 19
  %t256 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t255, i32 0, i32 0
  %t257 = load { i64, ptr }, ptr %t256, !tbaa !27
  store { i64, ptr } %t257, ptr %l88, !tbaa !27
  %t258 = load { i64, ptr }, ptr %l88, !tbaa !27
  %t259 = extractvalue { i64, ptr } %t258, 0
  store i64 %t259, ptr %l89, !tbaa !24
  %t260 = load i64, ptr %l89, !tbaa !24
  %t261 = mul i64 %t260, 8
  %t262 = load i64, ptr %l86
  %t263 = inttoptr i64 %t262 to ptr
  %t264 = call ptr @__olang_held_alloc(ptr %t263, i64 %t261)
  %t265 = insertvalue { i64, ptr } undef, i64 %t260, 0
  %t266 = insertvalue { i64, ptr } %t265, ptr %t264, 1
  store { i64, ptr } %t266, ptr %l90, !tbaa !27
  %t267 = getelementptr { i64, ptr }, ptr %l90, i32 0, i32 1
  %t268 = load ptr, ptr %t267, !tbaa !27
  %t269 = getelementptr { i64, ptr }, ptr %l88, i32 0, i32 1
  %t270 = load ptr, ptr %t269, !tbaa !27
  %t271 = load i64, ptr %l89, !tbaa !24
  %t272 = mul i64 %t271, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t268, ptr %t270, i64 %t272, i1 false)
  %t273 = load { i64, ptr }, ptr %l90, !tbaa !27
  %t274 = getelementptr %"compiler/bindgen:record", ptr %l45, i32 0, i32 19
  %t275 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t274, i32 0, i32 0
  store { i64, ptr } %t273, ptr %t275, !tbaa !27
  %t276 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t276, label %bb37, label %bb38
bb37:
  %t278 = getelementptr %"compiler/bindgen:record", ptr %l45, i32 0, i32 19
  %t279 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t278, i32 0, i32 0
  %t280 = load { i64, ptr }, ptr %t279, !tbaa !27
  %t281 = extractvalue { i64, ptr } %t280, 0
  %t283 = icmp eq i64 %t281, 0
  br i1 %t283, label %bb39, label %bb40
bb38:
  call void @llvm.memmove.p0.p0.i64(ptr %l6, ptr %l45, i64 312, i1 false)
  %t285 = getelementptr %"compiler/bindgen:record", ptr %l6, i32 0, i32 1
  %t286 = load i1, ptr %t285, !tbaa !21
  br i1 %t286, label %bb41, label %bb42
bb39:
  %t288 = getelementptr %"compiler/bindgen:record", ptr %l45, i32 0, i32 19
  %t289 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t288, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t289, !tbaa !27
  br label %bb40
bb40:
  %t290 = getelementptr %"compiler/bindgen:record", ptr %l45, i32 0, i32 19
  %t291 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t290, i32 0, i32 0
  %t292 = load i64, ptr %l86
  %t293 = inttoptr i64 %t292 to ptr
  %t294 = load { i64, ptr }, ptr %t291
  %t295 = extractvalue { i64, ptr } %t294, 1
  %t296 = call ptr @__olang_region_or(ptr %t295, ptr null)
  %t297 = icmp ne ptr %t296, null
  %t298 = select i1 %t297, ptr %t296, ptr null
  call void @__olang_region_settle_in(ptr %t293, ptr %t298)
  br label %bb38
bb41:
  store i64 0, ptr %l7, !tbaa !24
  %t299 = getelementptr %"compiler/bindgen:record", ptr %l6, i32 0, i32 4
  %t301 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %t299)
  store i64 %t301, ptr %l96
  br label %bb43
bb42:
  %t302 = load ptr, ptr %l0, !tbaa !29
  %t303 = load i64, ptr %l1, !tbaa !24
  call void @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eunionFlat(ptr %v0, ptr %s0, ptr %s0, ptr %t302, i64 %t303, i1 false, ptr %l3, ptr %l4)
  br label %bb66
bb43:
  %t308 = load i64, ptr %l96, !tbaa !24
  store i64 %t308, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t309 = load i64, ptr %l8, !tbaa !24
  %t310 = load i64, ptr %l7, !tbaa !24
  %t313 = icmp sgt i64 %t309, %t310
  br i1 %t313, label %bb44, label %bb45
bb44:
  %t315 = load i64, ptr %l9, !tbaa !24
  %t317 = icmp sgt i64 %t315, 0
  br i1 %t317, label %bb46, label %bb47
bb45:
  store i64 0, ptr %l100, !tbaa !24
  br label %bb49
bb46:
  %t319 = load i64, ptr %l8, !tbaa !24
  %t320 = load i64, ptr %l7, !tbaa !24
  %t323 = sub i64 %t319, %t320
  %t324 = load i64, ptr %l9, !tbaa !24
  %t327 = add i64 %t323, %t324
  %t329 = sub i64 %t327, 1
  %t330 = load i64, ptr %l9, !tbaa !24
  %t333 = sdiv i64 %t329, %t330
  store i64 %t333, ptr %l103, !tbaa !24
  br label %bb48
bb47:
  store i64 0, ptr %l103, !tbaa !24
  br label %bb48
bb48:
  %t335 = load i64, ptr %l103, !tbaa !24
  store i64 %t335, ptr %l100, !tbaa !24
  br label %bb49
bb49:
  %t336 = load i64, ptr %l100, !tbaa !24
  store i64 %t336, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb50
bb50:
  store %olang.scope zeroinitializer, ptr %s3
  %t337 = load i64, ptr %l11, !tbaa !24
  %t338 = load i64, ptr %l10, !tbaa !24
  %t341 = icmp slt i64 %t337, %t338
  %t343 = xor i1 %t341, true
  br i1 %t343, label %bb51, label %bb52
bb51:
  call void @__olang_scope_close(ptr %s3)
  br label %bb65
bb52:
  br label %bb53
bb53:
  %t345 = load i64, ptr %l7, !tbaa !24
  %t346 = load i64, ptr %l11, !tbaa !24
  %t347 = load i64, ptr %l9, !tbaa !24
  %t350 = mul i64 %t346, %t347
  %t353 = add i64 %t345, %t350
  store i64 %t353, ptr %l12, !tbaa !24
  %t355 = getelementptr %"compiler/bindgen:record", ptr %l6, i32 0, i32 4
  %t356 = load i64, ptr %l12, !tbaa !24
  %t359 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %t355, i64 %t356)
  store { i64, ptr } %t359, ptr %l123
  br label %bb54
bb54:
  %t360 = load { i64, ptr }, ptr %l123, !tbaa !27
  %t361 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s3, { i64, ptr } %t360, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d254, i32 0, i32 1) })
  store i1 %t361, ptr %l124
  br label %bb55
bb55:
  %t362 = load i1, ptr %l124, !tbaa !21
  br i1 %t362, label %bb56, label %bb57
bb56:
  call void @__olang_scope_close(ptr %s3)
  br label %bb64
bb57:
  br label %bb58
bb58:
  store ptr %l3, ptr %l125, !tbaa !29
  %t363 = getelementptr %"compiler/bindgen:record", ptr %l6, i32 0, i32 4
  %t364 = load i64, ptr %l12, !tbaa !24
  %t367 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %t363, i64 %t364)
  store { i64, ptr } %t367, ptr %l128
  br label %bb59
bb59:
  %t368 = load ptr, ptr %l125, !tbaa !29
  %t369 = load { i64, ptr }, ptr %l128, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %v0, ptr %t368, { i64, ptr } %t369)
  br label %bb60
bb60:
  store ptr %l4, ptr %l129, !tbaa !29
  %t370 = getelementptr %"compiler/bindgen:record", ptr %l6, i32 0, i32 5
  %t371 = load i64, ptr %l12, !tbaa !24
  %t374 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %t370, i64 %t371)
  store { i64, ptr } %t374, ptr %l132
  br label %bb61
bb61:
  %t375 = load ptr, ptr %l129, !tbaa !29
  %t376 = load { i64, ptr }, ptr %l132, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %v0, ptr %t375, { i64, ptr } %t376)
  br label %bb62
bb62:
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l5, i64 0)
  br label %bb63
bb63:
  call void @__olang_scope_close(ptr %s3)
  br label %bb64
bb64:
  %t378 = load i64, ptr %l11, !tbaa !24
  %t381 = add i64 %t378, 1
  store i64 %t381, ptr %l11, !tbaa !24
  br label %bb50
bb65:
  br label %bb84
bb66:
  %t383 = load ptr, ptr %l0, !tbaa !29
  %t385 = getelementptr %"compiler/bindgen:gen", ptr %t383, i32 0, i32 6
  %t386 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eAt_3ccompiler_2fbindgen_3arecord_3e(ptr %t387, ptr %v0, ptr %v0, ptr %t385, i64 %t386)
  call void @llvm.memmove.p0.p0.i64(ptr %l144, ptr %t387, i64 312, i1 false)
  br label %bb67
bb67:
  %t390 = getelementptr %"compiler/bindgen:record", ptr %l144, i32 0, i32 19
  %t392 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t390)
  store i64 %t392, ptr %l146
  br label %bb68
bb68:
  %t394 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %l3)
  store i64 %t394, ptr %l148
  br label %bb69
bb69:
  %t395 = load i64, ptr %l146, !tbaa !24
  %t396 = load i64, ptr %l148, !tbaa !24
  %t397 = icmp ne i64 %t395, %t396
  br i1 %t397, label %bb70, label %bb71
bb70:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d255, i32 0, i32 1) }, ptr %l150, !tbaa !27
  %t399 = load { i64, ptr }, ptr %l150, !tbaa !27
  store { i64, ptr } %t399, ptr %l151, !tbaa !27
  %t400 = load { i64, ptr }, ptr %l151, !tbaa !27
  %t401 = extractvalue { i64, ptr } %t400, 0
  store i64 %t401, ptr %l152, !tbaa !24
  %t402 = load i64, ptr %l152, !tbaa !24
  %t403 = mul i64 %t402, 1
  %t404 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t403)
  %t405 = insertvalue { i64, ptr } undef, i64 %t402, 0
  %t406 = insertvalue { i64, ptr } %t405, ptr %t404, 1
  store { i64, ptr } %t406, ptr %l153, !tbaa !27
  %t407 = getelementptr { i64, ptr }, ptr %l153, i32 0, i32 1
  %t408 = load ptr, ptr %t407, !tbaa !27
  %t409 = getelementptr { i64, ptr }, ptr %l151, i32 0, i32 1
  %t410 = load ptr, ptr %t409, !tbaa !27
  %t411 = load i64, ptr %l152, !tbaa !24
  %t412 = mul i64 %t411, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t408, ptr %t410, i64 %t412, i1 false)
  %t413 = load { i64, ptr }, ptr %l153, !tbaa !27
  store { i64, ptr } %t413, ptr %l151, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t414 = load { i64, ptr }, ptr %l151, !tbaa !27
  store { i64, ptr } %t414, ptr %rv
  br label %ret
bb71:
  br label %bb72
bb72:
  store %olang.scope zeroinitializer, ptr %s8
  %t415 = load ptr, ptr %l0, !tbaa !29
  %t417 = getelementptr %"compiler/bindgen:gen", ptr %t415, i32 0, i32 6
  %t418 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eAt_3ccompiler_2fbindgen_3arecord_3e(ptr %t419, ptr %v0, ptr %v0, ptr %t417, i64 %t418)
  call void @llvm.memmove.p0.p0.i64(ptr %l157, ptr %t419, i64 312, i1 false)
  br label %bb73
bb73:
  call void @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2fbindgen_3arecord(ptr %t422, ptr %v0, ptr %l157)
  call void @llvm.memmove.p0.p0.i64(ptr %l159, ptr %t422, i64 312, i1 false)
  br label %bb74
bb74:
  %t424 = getelementptr %"compiler/bindgen:record", ptr %l159, i32 0, i32 19
  store ptr %t424, ptr %l13, !tbaa !29
  store i64 0, ptr %l14, !tbaa !24
  br label %bb75
bb75:
  %t426 = load i64, ptr %l14, !tbaa !24
  store i64 %t426, ptr %l161, !tbaa !24
  %t427 = load ptr, ptr %l13, !tbaa !29
  %t429 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s8, ptr %t427)
  store i64 %t429, ptr %l163
  br label %bb76
bb76:
  %t430 = load i64, ptr %l161, !tbaa !24
  %t431 = load i64, ptr %l163, !tbaa !24
  %t432 = icmp slt i64 %t430, %t431
  %t434 = xor i1 %t432, true
  br i1 %t434, label %bb77, label %bb78
bb77:
  br label %bb83
bb78:
  br label %bb79
bb79:
  %t436 = load ptr, ptr %l13, !tbaa !29
  %t437 = load i64, ptr %l14, !tbaa !24
  %t440 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s8, ptr %t436, i64 %t437)
  store i64 %t440, ptr %l168
  br label %bb80
bb80:
  %t441 = load i64, ptr %l168, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l5, i64 %t441)
  br label %bb81
bb81:
  br label %bb82
bb82:
  %t445 = load i64, ptr %l14, !tbaa !24
  %t448 = add i64 %t445, 1
  store i64 %t448, ptr %l14, !tbaa !24
  br label %bb75
bb83:
  call void @__olang_scope_close(ptr %s8)
  br label %bb84
bb84:
  %t450 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e_2ector(ptr %s0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t450, ptr %l174
  br label %bb85
bb85:
  %t451 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l174
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t451, ptr %l16
  store ptr %l3, ptr %l17, !tbaa !29
  store i64 0, ptr %l18, !tbaa !24
  br label %bb86
bb86:
  %t453 = load i64, ptr %l18, !tbaa !24
  store i64 %t453, ptr %l176, !tbaa !24
  %t454 = load ptr, ptr %l17, !tbaa !29
  %t456 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %t454)
  store i64 %t456, ptr %l178
  br label %bb87
bb87:
  %t457 = load i64, ptr %l176, !tbaa !24
  %t458 = load i64, ptr %l178, !tbaa !24
  %t459 = icmp slt i64 %t457, %t458
  %t461 = xor i1 %t459, true
  br i1 %t461, label %bb88, label %bb89
bb88:
  br label %bb94
bb89:
  br label %bb90
bb90:
  %t463 = load ptr, ptr %l17, !tbaa !29
  %t464 = load i64, ptr %l18, !tbaa !24
  %t467 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %t463, i64 %t464)
  store { i64, ptr } %t467, ptr %l183
  br label %bb91
bb91:
  %t468 = load { i64, ptr }, ptr %l183, !tbaa !27
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha091d021a90ce6aa48813730c00df6d2(ptr %s0, ptr %s0, ptr %l16, { i64, ptr } %t468, i64 0)
  br label %bb92
bb92:
  br label %bb93
bb93:
  %t472 = load i64, ptr %l18, !tbaa !24
  %t475 = add i64 %t472, 1
  store i64 %t475, ptr %l18, !tbaa !24
  br label %bb86
bb94:
  %t477 = load i1, ptr %l2, !tbaa !21
  br i1 %t477, label %bb95, label %bb96
bb95:
  store %olang.scope zeroinitializer, ptr %s14
  %t479 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t479, ptr %l190
  br label %bb97
bb96:
  br label %bb112
bb97:
  %t480 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l190
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t480, ptr %l20
  %t481 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s14, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t481, ptr %l191
  br label %bb98
bb98:
  %t482 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l191
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t482, ptr %l21
  %t483 = load ptr, ptr %l0, !tbaa !29
  %t484 = load i64, ptr %l1, !tbaa !24
  %t489 = call i32 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eflat(ptr %v0, ptr %s0, ptr %s14, ptr %t483, i64 %t484, ptr %l20, ptr %l21)
  store i32 %t489, ptr %l196
  %t490 = icmp ne i32 %t489, 0
  br i1 %t490, label %bb100, label %ok.491, !prof !99
ok.491:
  br label %bb99
bb99:
  br label %bb102
bb100:
  %t492 = load i32, ptr %l196, !tbaa !23
  %t493 = ashr i32 %t492, 16
  %t495 = icmp eq i32 %t493, 1
  store i1 %t495, ptr %l198, !tbaa !21
  br label %bb101
bb101:
  br label %bb102
bb102:
  store ptr %l20, ptr %l22, !tbaa !29
  store i64 0, ptr %l23, !tbaa !24
  br label %bb103
bb103:
  %t497 = load i64, ptr %l23, !tbaa !24
  store i64 %t497, ptr %l200, !tbaa !24
  %t498 = load ptr, ptr %l22, !tbaa !29
  %t500 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %t498)
  store i64 %t500, ptr %l202
  br label %bb104
bb104:
  %t501 = load i64, ptr %l200, !tbaa !24
  %t502 = load i64, ptr %l202, !tbaa !24
  %t503 = icmp slt i64 %t501, %t502
  %t505 = xor i1 %t503, true
  br i1 %t505, label %bb105, label %bb106
bb105:
  br label %bb111
bb106:
  br label %bb107
bb107:
  %t507 = load ptr, ptr %l22, !tbaa !29
  %t508 = load i64, ptr %l23, !tbaa !24
  %t511 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %t507, i64 %t508)
  store { i64, ptr } %t511, ptr %l207
  br label %bb108
bb108:
  %t512 = load { i64, ptr }, ptr %l207, !tbaa !27
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha091d021a90ce6aa48813730c00df6d2(ptr %s0, ptr %s0, ptr %l16, { i64, ptr } %t512, i64 0)
  br label %bb109
bb109:
  br label %bb110
bb110:
  %t516 = load i64, ptr %l23, !tbaa !24
  %t519 = add i64 %t516, 1
  store i64 %t519, ptr %l23, !tbaa !24
  br label %bb103
bb111:
  call void @__olang_scope_close(ptr %s14)
  br label %bb112
bb112:
  %t521 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t521, ptr %l213
  br label %bb113
bb113:
  %t522 = load %"std/prelude/text:StringBuilder", ptr %l213
  store %"std/prelude/text:StringBuilder" %t522, ptr %l25
  store i64 0, ptr %l26, !tbaa !24
  %t524 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %l3)
  store i64 %t524, ptr %l215
  br label %bb114
bb114:
  %t525 = load i64, ptr %l215, !tbaa !24
  store i64 %t525, ptr %l27, !tbaa !24
  store i64 1, ptr %l28, !tbaa !24
  %t526 = load i64, ptr %l27, !tbaa !24
  %t527 = load i64, ptr %l26, !tbaa !24
  %t530 = icmp sgt i64 %t526, %t527
  br i1 %t530, label %bb115, label %bb116
bb115:
  %t532 = load i64, ptr %l28, !tbaa !24
  %t534 = icmp sgt i64 %t532, 0
  br i1 %t534, label %bb117, label %bb118
bb116:
  store i64 0, ptr %l219, !tbaa !24
  br label %bb120
bb117:
  %t536 = load i64, ptr %l27, !tbaa !24
  %t537 = load i64, ptr %l26, !tbaa !24
  %t540 = sub i64 %t536, %t537
  %t541 = load i64, ptr %l28, !tbaa !24
  %t544 = add i64 %t540, %t541
  %t546 = sub i64 %t544, 1
  %t547 = load i64, ptr %l28, !tbaa !24
  %t550 = sdiv i64 %t546, %t547
  store i64 %t550, ptr %l222, !tbaa !24
  br label %bb119
bb118:
  store i64 0, ptr %l222, !tbaa !24
  br label %bb119
bb119:
  %t552 = load i64, ptr %l222, !tbaa !24
  store i64 %t552, ptr %l219, !tbaa !24
  br label %bb120
bb120:
  %t553 = load i64, ptr %l219, !tbaa !24
  store i64 %t553, ptr %l29, !tbaa !24
  store i64 0, ptr %l30, !tbaa !24
  br label %bb121
bb121:
  store %olang.scope zeroinitializer, ptr %s20
  %t554 = load i64, ptr %l30, !tbaa !24
  %t555 = load i64, ptr %l29, !tbaa !24
  %t558 = icmp slt i64 %t554, %t555
  %t560 = xor i1 %t558, true
  br i1 %t560, label %bb122, label %bb123
bb122:
  call void @__olang_scope_close(ptr %s20)
  br label %bb166
bb123:
  br label %bb124
bb124:
  %t562 = load i64, ptr %l26, !tbaa !24
  %t563 = load i64, ptr %l30, !tbaa !24
  %t564 = load i64, ptr %l28, !tbaa !24
  %t567 = mul i64 %t563, %t564
  %t570 = add i64 %t562, %t567
  store i64 %t570, ptr %l31, !tbaa !24
  %t572 = load ptr, ptr %l0, !tbaa !29
  store ptr %t572, ptr %l240, !tbaa !29
  %t573 = load i64, ptr %l31, !tbaa !24
  %t576 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %l4, i64 %t573)
  store { i64, ptr } %t576, ptr %l243
  br label %bb125
bb125:
  %t577 = load ptr, ptr %l240, !tbaa !29
  %t578 = load { i64, ptr }, ptr %l243, !tbaa !27
  %t579 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ememberNumber(ptr %v0, ptr %s0, ptr %s20, ptr %t577, { i64, ptr } %t578)
  store { i64, ptr } %t579, ptr %l244
  br label %bb126
bb126:
  %t580 = load { i64, ptr }, ptr %l244, !tbaa !27
  store { i64, ptr } %t580, ptr %l32, !tbaa !27
  %t581 = load i64, ptr %l31, !tbaa !24
  %t584 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %l3, i64 %t581)
  store { i64, ptr } %t584, ptr %l247
  br label %bb127
bb127:
  %t585 = load { i64, ptr }, ptr %l247, !tbaa !27
  store { i64, ptr } %t585, ptr %l33, !tbaa !27
  %t586 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t588 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s20, ptr %s20, { i64, ptr } %t586, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d256, i32 0, i32 1) })
  store i1 %t588, ptr %l249
  br label %bb128
bb128:
  %t589 = load i1, ptr %l249, !tbaa !21
  br i1 %t589, label %bb129, label %bb130
bb129:
  store i1 true, ptr %l250, !tbaa !21
  br label %bb132
bb130:
  %t590 = load i64, ptr %l31, !tbaa !24
  %t593 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l5, i64 %t590)
  store i64 %t593, ptr %l253
  br label %bb131
bb131:
  %t594 = load i64, ptr %l253, !tbaa !24
  %t595 = icmp slt i64 %t594, 0
  store i1 %t595, ptr %l250, !tbaa !21
  br label %bb132
bb132:
  %t597 = load i1, ptr %l250, !tbaa !21
  br i1 %t597, label %bb133, label %bb134
bb133:
  store i1 true, ptr %l255, !tbaa !21
  br label %bb136
bb134:
  %t598 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t600 = call i1 @compiler_2fbindgen_2eusable(ptr %s0, { i64, ptr } %t598)
  store i1 %t600, ptr %l257
  br label %bb135
bb135:
  %t601 = load i1, ptr %l257, !tbaa !21
  %t602 = xor i1 %t601, true
  store i1 %t602, ptr %l255, !tbaa !21
  br label %bb136
bb136:
  %t604 = load i1, ptr %l255, !tbaa !21
  br i1 %t604, label %bb137, label %bb138
bb137:
  store i1 true, ptr %l259, !tbaa !21
  br label %bb140
bb138:
  %t605 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t606 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d257, i32 0, i32 1) }, 1
  %t607 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d257, i32 0, i32 1) }, 0
  %t609 = extractvalue { i64, ptr } %t605, 1
  %t610 = extractvalue { i64, ptr } %t605, 0
  %t611 = add i64 %t607, %t610
  %t612 = call ptr @__olang_scope_alloc(ptr %s20, i64 %t611)
  call void @olang_textcopy(ptr %t612, ptr %t606, i64 %t607)
  %t613 = getelementptr i8, ptr %t612, i64 %t607
  call void @olang_textcopy(ptr %t613, ptr %t609, i64 %t610)
  %t614 = insertvalue { i64, ptr } undef, i64 %t611, 0
  %t615 = insertvalue { i64, ptr } %t614, ptr %t612, 1
  %t620 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9b83f66eba65594537030636cb0b52b7(ptr %s0, ptr %s20, ptr %l16, { i64, ptr } %t615)
  store i1 %t620, ptr %l264
  br label %bb139
bb139:
  %t621 = load i1, ptr %l264, !tbaa !21
  store i1 %t621, ptr %l259, !tbaa !21
  br label %bb140
bb140:
  %t622 = load i1, ptr %l259, !tbaa !21
  br i1 %t622, label %bb141, label %bb142
bb141:
  call void @__olang_scope_close(ptr %s20)
  br label %bb165
bb142:
  br label %bb143
bb143:
  %t623 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t625 = call i64 @compiler_2fbindgen_2enumBytes(ptr %s20, { i64, ptr } %t623)
  store i64 %t625, ptr %l266
  br label %bb144
bb144:
  %t626 = load i64, ptr %l266, !tbaa !24
  store i64 %t626, ptr %l35, !tbaa !24
  %t627 = load i1, ptr %l2, !tbaa !21
  %t629 = xor i1 %t627, true
  br i1 %t629, label %bb145, label %bb146
bb145:
  store %olang.scope zeroinitializer, ptr %s23
  store ptr %l25, ptr %l269, !tbaa !29
  %t631 = load ptr, ptr %l0, !tbaa !29
  %t633 = getelementptr %"compiler/bindgen:gen", ptr %t631, i32 0, i32 6
  %t634 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eAt_3ccompiler_2fbindgen_3arecord_3e(ptr %t635, ptr %v0, ptr %v0, ptr %t633, i64 %t634)
  call void @llvm.memmove.p0.p0.i64(ptr %l273, ptr %t635, i64 312, i1 false)
  br label %bb147
bb146:
  br label %bb152
bb147:
  %t638 = getelementptr %"compiler/bindgen:record", ptr %l273, i32 0, i32 7
  %t639 = load { i64, ptr }, ptr %t638, !tbaa !27
  store { i64, ptr } %t639, ptr %l274, !tbaa !27
  %t640 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t640, ptr %l275, !tbaa !27
  %t641 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t641, ptr %l276, !tbaa !27
  %t642 = load ptr, ptr %l0, !tbaa !29
  %t644 = getelementptr %"compiler/bindgen:gen", ptr %t642, i32 0, i32 6
  %t645 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eAt_3ccompiler_2fbindgen_3arecord_3e(ptr %t646, ptr %v0, ptr %s23, ptr %t644, i64 %t645)
  call void @llvm.memmove.p0.p0.i64(ptr %l280, ptr %t646, i64 312, i1 false)
  br label %bb148
bb148:
  %t649 = getelementptr %"compiler/bindgen:record", ptr %l280, i32 0, i32 14
  %t650 = load i64, ptr %t649, !tbaa !24
  store i64 %t650, ptr %l281, !tbaa !24
  %t651 = load i64, ptr %l31, !tbaa !24
  %t654 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l5, i64 %t651)
  store i64 %t654, ptr %l284
  br label %bb149
bb149:
  %t655 = load { i64, ptr }, ptr %l274, !tbaa !27
  %t656 = load { i64, ptr }, ptr %l275, !tbaa !27
  %t657 = load { i64, ptr }, ptr %l276, !tbaa !27
  %t658 = load i64, ptr %l281, !tbaa !24
  %t659 = load i64, ptr %l284, !tbaa !24
  %t660 = call { i64, ptr } @compiler_2fbindgen_2eaccessors(ptr %v0, ptr %s0, ptr %s20, ptr %s23, ptr %s23, { i64, ptr } %t655, { i64, ptr } %t656, { i64, ptr } %t657, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d258, i32 0, i32 1) }, i64 %t658, i64 %t659)
  store { i64, ptr } %t660, ptr %l285
  br label %bb150
bb150:
  %t661 = load { i64, ptr }, ptr %l285, !tbaa !27
  %t662 = load ptr, ptr %l269, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s23, ptr %t662, { i64, ptr } %t661)
  br label %bb151
bb151:
  call void @__olang_scope_close(ptr %s23)
  call void @__olang_scope_close(ptr %s20)
  br label %bb165
bb152:
  %t664 = load ptr, ptr %l0, !tbaa !29
  store ptr %t664, ptr %l287, !tbaa !29
  %t665 = load i64, ptr %l1, !tbaa !24
  store i64 %t665, ptr %l288, !tbaa !24
  %t666 = load i64, ptr %l31, !tbaa !24
  %t669 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l5, i64 %t666)
  store i64 %t669, ptr %l291
  br label %bb153
bb153:
  %t670 = load i64, ptr %l35, !tbaa !24
  %t671 = load ptr, ptr %l287, !tbaa !29
  %t672 = load i64, ptr %l288, !tbaa !24
  %t673 = load i64, ptr %l291, !tbaa !24
  %t675 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2egapAround(ptr %v0, ptr %t671, i64 %t672, i64 %t673, i64 %t670)
  store i64 %t675, ptr %l293
  br label %bb154
bb154:
  %t676 = load i64, ptr %l293, !tbaa !24
  store i64 %t676, ptr %l36, !tbaa !24
  %t677 = load i64, ptr %l36, !tbaa !24
  %t679 = icmp slt i64 %t677, 0
  br i1 %t679, label %bb155, label %bb156
bb155:
  call void @__olang_scope_close(ptr %s20)
  br label %bb165
bb156:
  br label %bb157
bb157:
  %t681 = load i64, ptr %l36, !tbaa !24
  store i64 %t681, ptr %l296, !tbaa !24
  %t682 = load ptr, ptr %l0, !tbaa !29
  %t683 = load i64, ptr %l1, !tbaa !24
  %t684 = load i64, ptr %l36, !tbaa !24
  %t688 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2egapEnd(ptr %v0, ptr %t682, i64 %t683, i64 %t684)
  store i64 %t688, ptr %l300
  br label %bb158
bb158:
  %t689 = load i64, ptr %l36, !tbaa !24
  %t690 = load i64, ptr %l300, !tbaa !24
  %t692 = sub i64 %t690, %t689
  store i64 %t692, ptr %l302, !tbaa !24
  %t693 = load ptr, ptr %l0, !tbaa !29
  %t695 = getelementptr %"compiler/bindgen:gen", ptr %t693, i32 0, i32 6
  %t696 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eAt_3ccompiler_2fbindgen_3arecord_3e(ptr %t697, ptr %v0, ptr %s20, ptr %t695, i64 %t696)
  call void @llvm.memmove.p0.p0.i64(ptr %l306, ptr %t697, i64 312, i1 false)
  br label %bb159
bb159:
  %t700 = getelementptr %"compiler/bindgen:record", ptr %l306, i32 0, i32 14
  %t701 = load i64, ptr %t700, !tbaa !24
  %t702 = load i64, ptr %l296, !tbaa !24
  %t703 = load i64, ptr %l302, !tbaa !24
  %t705 = call i64 @compiler_2fbindgen_2egapWord(i64 %t702, i64 %t703, i64 %t701)
  store i64 %t705, ptr %l308
  br label %bb160
bb160:
  %t706 = load i64, ptr %l308, !tbaa !24
  store i64 %t706, ptr %l37, !tbaa !24
  store ptr %l25, ptr %l309, !tbaa !29
  %t707 = load ptr, ptr %l0, !tbaa !29
  %t709 = getelementptr %"compiler/bindgen:gen", ptr %t707, i32 0, i32 6
  %t710 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eAt_3ccompiler_2fbindgen_3arecord_3e(ptr %t711, ptr %v0, ptr %v0, ptr %t709, i64 %t710)
  call void @llvm.memmove.p0.p0.i64(ptr %l313, ptr %t711, i64 312, i1 false)
  br label %bb161
bb161:
  %t714 = getelementptr %"compiler/bindgen:record", ptr %l313, i32 0, i32 7
  %t715 = load { i64, ptr }, ptr %t714, !tbaa !27
  store { i64, ptr } %t715, ptr %l314, !tbaa !27
  %t716 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t716, ptr %l315, !tbaa !27
  %t717 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t717, ptr %l316, !tbaa !27
  %t718 = load i64, ptr %l36, !tbaa !24
  %t719 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d259, i32 0, i32 1) }, 1
  %t720 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d259, i32 0, i32 1) }, 0
  %t722 = call i64 @__olang_fmt_i64(ptr null, i64 %t718)
  %t723 = add i64 %t720, %t722
  %t724 = call ptr @__olang_scope_alloc(ptr %s20, i64 %t723)
  call void @olang_textcopy(ptr %t724, ptr %t719, i64 %t720)
  %t725 = getelementptr i8, ptr %t724, i64 %t720
  %t726 = call i64 @__olang_fmt_i64(ptr %t725, i64 %t718)
  %t727 = insertvalue { i64, ptr } undef, i64 %t723, 0
  %t728 = insertvalue { i64, ptr } %t727, ptr %t724, 1
  store { i64, ptr } %t728, ptr %l319, !tbaa !27
  %t730 = load i64, ptr %l37, !tbaa !24
  store i64 %t730, ptr %l320, !tbaa !24
  %t731 = load i64, ptr %l31, !tbaa !24
  %t734 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l5, i64 %t731)
  store i64 %t734, ptr %l323
  br label %bb162
bb162:
  %t735 = load i64, ptr %l36, !tbaa !24
  %t736 = load i64, ptr %l323, !tbaa !24
  %t738 = sub i64 %t736, %t735
  %t739 = load { i64, ptr }, ptr %l314, !tbaa !27
  %t740 = load { i64, ptr }, ptr %l315, !tbaa !27
  %t741 = load { i64, ptr }, ptr %l316, !tbaa !27
  %t742 = load { i64, ptr }, ptr %l319, !tbaa !27
  %t743 = load i64, ptr %l320, !tbaa !24
  %t745 = call { i64, ptr } @compiler_2fbindgen_2eaccessors(ptr %v0, ptr %s0, ptr %s20, ptr %s20, ptr %s20, { i64, ptr } %t739, { i64, ptr } %t740, { i64, ptr } %t741, { i64, ptr } %t742, i64 %t743, i64 %t738)
  store { i64, ptr } %t745, ptr %l326
  br label %bb163
bb163:
  %t746 = load { i64, ptr }, ptr %l326, !tbaa !27
  %t747 = load ptr, ptr %l309, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s20, ptr %t747, { i64, ptr } %t746)
  br label %bb164
bb164:
  call void @__olang_scope_close(ptr %s20)
  br label %bb165
bb165:
  %t749 = load i64, ptr %l30, !tbaa !24
  %t752 = add i64 %t749, 1
  store i64 %t752, ptr %l30, !tbaa !24
  br label %bb121
bb166:
  %t755 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l25)
  store { i64, ptr } %t755, ptr %l332
  br label %bb167
bb167:
  call void @__olang_scope_close(ptr %s0)
  %t756 = load { i64, ptr }, ptr %l332, !tbaa !27
  store { i64, ptr } %t756, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eunionMember(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, { i64, ptr } %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l16 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l23 = alloca i64
  %l24 = alloca i32
  %l25 = alloca i64
  %l26 = alloca i32
  %l27 = alloca i64
  %l28 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l30 = alloca i64
  %l31 = alloca i32
  %l32 = alloca i64
  %l33 = alloca i32
  %l36 = alloca i1
  %l37 = alloca i64
  %l39 = alloca i64
  %l41 = alloca i1
  %l44 = alloca i1
  %l45 = alloca i64
  %l47 = alloca ptr
  %l50 = alloca i64
  %l51 = alloca %"compiler/bindgen:record"
  %l53 = alloca i64
  %l56 = alloca ptr
  %l59 = alloca i64
  %l60 = alloca ptr
  %l62 = alloca ptr
  %l63 = alloca i64
  %l64 = alloca i64
  %l66 = alloca { i64, ptr }
  %l67 = alloca { i64, ptr }
  %l68 = alloca i64
  %l69 = alloca i32
  %l70 = alloca i64
  %l71 = alloca i32
  %s0 = alloca %olang.scope
  %t98 = alloca %"compiler/bindgen:record", align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t1, ptr %l7, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t2, 0
  store i64 %t5, ptr %l10, !tbaa !24
  %t6 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t6, 0
  store i64 %t7, ptr %l11, !tbaa !24
  %t8 = icmp sge i64 9, 0
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load i64, ptr %l10, !tbaa !24
  %t11 = icmp sle i64 9, %t10
  br i1 %t11, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_6501bdc18c03b538_5635fa6c34e71ae4)
  unreachable
bb3:
  %t13 = load i64, ptr %l10, !tbaa !24
  %t14 = load i64, ptr %l11, !tbaa !24
  %t15 = icmp sle i64 %t13, %t14
  br i1 %t15, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_6501bdc18c03b538_5635fa6c34e71ae4)
  unreachable
bb5:
  %t17 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t18 = load ptr, ptr %t17, !tbaa !27
  %t19 = load i64, ptr %l10, !tbaa !24
  %t20 = getelementptr i8, ptr %t18, i64 9
  %t21 = sub i64 %t19, 9
  %t22 = insertvalue { i64, ptr } undef, i64 %t21, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t20, 1
  %t25 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eSplit(ptr %v2, ptr %s0, ptr %s0, { i64, ptr } %t23, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d260, i32 0, i32 1) })
  store { i64, ptr } %t25, ptr %l16
  br label %bb7
bb6:
  call void @__olang_check_failed(ptr @olang_loc_6501bdc18c03b538_5635fa6c34e71ae4)
  unreachable
bb7:
  %t26 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t26, ptr %l4, !tbaa !27
  %t27 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t27, 0
  %t31 = icmp ne i64 %t29, 2
  br i1 %t31, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb9:
  br label %bb10
bb10:
  %t33 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t33, ptr %l21, !tbaa !27
  %t34 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !27
  %t36 = getelementptr { i64, ptr }, ptr %t35, i64 0
  %t37 = load { i64, ptr }, ptr %t36, !tbaa !37
  store { i64, ptr } %t37, ptr %l22, !tbaa !27
  %t38 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s0, i64 10)
  %t39 = extractvalue { i32, i64 } %t38, 1
  %t40 = extractvalue { i32, i64 } %t38, 0
  store i32 %t40, ptr %l24
  %t41 = icmp ne i32 %t40, 0
  br i1 %t41, label %bb12, label %ok.42, !prof !99
ok.42:
  store i64 %t39, ptr %l23
  br label %bb11
bb11:
  %t43 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t44 = load i64, ptr %l23, !tbaa !24
  %t45 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %s0, { i64, ptr } %t43, i64 %t44)
  %t46 = extractvalue { i32, i64 } %t45, 1
  %t47 = extractvalue { i32, i64 } %t45, 0
  store i32 %t47, ptr %l26
  %t48 = icmp ne i32 %t47, 0
  br i1 %t48, label %bb15, label %ok.49, !prof !99
ok.49:
  store i64 %t46, ptr %l25
  br label %bb14
bb12:
  br label %bb13
bb13:
  store i64 -1, ptr %l20, !tbaa !24
  br label %bb16
bb14:
  %t50 = load i64, ptr %l25, !tbaa !24
  store i64 %t50, ptr %l20, !tbaa !24
  br label %bb16
bb15:
  br label %bb13
bb16:
  %t51 = load i64, ptr %l20, !tbaa !24
  store i64 %t51, ptr %l5, !tbaa !24
  %t52 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t52, ptr %l28, !tbaa !27
  %t53 = getelementptr { i64, ptr }, ptr %l28, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !27
  %t55 = getelementptr { i64, ptr }, ptr %t54, i64 1
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !37
  store { i64, ptr } %t56, ptr %l29, !tbaa !27
  %t57 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s0, i64 10)
  %t58 = extractvalue { i32, i64 } %t57, 1
  %t59 = extractvalue { i32, i64 } %t57, 0
  store i32 %t59, ptr %l31
  %t60 = icmp ne i32 %t59, 0
  br i1 %t60, label %bb18, label %ok.61, !prof !99
ok.61:
  store i64 %t58, ptr %l30
  br label %bb17
bb17:
  %t62 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t63 = load i64, ptr %l30, !tbaa !24
  %t64 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %s0, { i64, ptr } %t62, i64 %t63)
  %t65 = extractvalue { i32, i64 } %t64, 1
  %t66 = extractvalue { i32, i64 } %t64, 0
  store i32 %t66, ptr %l33
  %t67 = icmp ne i32 %t66, 0
  br i1 %t67, label %bb21, label %ok.68, !prof !99
ok.68:
  store i64 %t65, ptr %l32
  br label %bb20
bb18:
  br label %bb19
bb19:
  store i64 -1, ptr %l27, !tbaa !24
  br label %bb22
bb20:
  %t69 = load i64, ptr %l32, !tbaa !24
  store i64 %t69, ptr %l27, !tbaa !24
  br label %bb22
bb21:
  br label %bb19
bb22:
  %t70 = load i64, ptr %l27, !tbaa !24
  store i64 %t70, ptr %l6, !tbaa !24
  %t71 = load i64, ptr %l5, !tbaa !24
  %t73 = icmp slt i64 %t71, 0
  br i1 %t73, label %bb23, label %bb24
bb23:
  store i1 true, ptr %l36, !tbaa !21
  br label %bb26
bb24:
  %t75 = load i64, ptr %l5, !tbaa !24
  store i64 %t75, ptr %l37, !tbaa !24
  %t76 = load ptr, ptr %l1, !tbaa !29
  %t78 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t76)
  store i64 %t78, ptr %l39
  br label %bb25
bb25:
  %t79 = load i64, ptr %l37, !tbaa !24
  %t80 = load i64, ptr %l39, !tbaa !24
  %t81 = icmp sge i64 %t79, %t80
  store i1 %t81, ptr %l36, !tbaa !21
  br label %bb26
bb26:
  %t83 = load i1, ptr %l36, !tbaa !21
  br i1 %t83, label %bb27, label %bb28
bb27:
  store i1 true, ptr %l41, !tbaa !21
  br label %bb29
bb28:
  %t84 = load i64, ptr %l6, !tbaa !24
  %t86 = icmp slt i64 %t84, 0
  store i1 %t86, ptr %l41, !tbaa !21
  br label %bb29
bb29:
  %t88 = load i1, ptr %l41, !tbaa !21
  br i1 %t88, label %bb30, label %bb31
bb30:
  store i1 true, ptr %l44, !tbaa !21
  br label %bb35
bb31:
  %t89 = load i64, ptr %l6, !tbaa !24
  store i64 %t89, ptr %l45, !tbaa !24
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t92 = getelementptr %"compiler/bindgen:gen", ptr %t90, i32 0, i32 6
  store ptr %t92, ptr %l47, !tbaa !29
  %t93 = load ptr, ptr %l1, !tbaa !29
  %t94 = load i64, ptr %l5, !tbaa !24
  %t97 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t93, i64 %t94)
  store i64 %t97, ptr %l50
  br label %bb32
bb32:
  %t99 = load ptr, ptr %l47, !tbaa !29
  %t100 = load i64, ptr %l50, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eAt_3ccompiler_2fbindgen_3arecord_3e(ptr %t98, ptr %v0, ptr %v0, ptr %t99, i64 %t100)
  call void @llvm.memmove.p0.p0.i64(ptr %l51, ptr %t98, i64 312, i1 false)
  br label %bb33
bb33:
  %t101 = getelementptr %"compiler/bindgen:record", ptr %l51, i32 0, i32 19
  %t103 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t101)
  store i64 %t103, ptr %l53
  br label %bb34
bb34:
  %t104 = load i64, ptr %l45, !tbaa !24
  %t105 = load i64, ptr %l53, !tbaa !24
  %t106 = icmp sge i64 %t104, %t105
  store i1 %t106, ptr %l44, !tbaa !21
  br label %bb35
bb35:
  %t108 = load i1, ptr %l44, !tbaa !21
  br i1 %t108, label %bb36, label %bb37
bb36:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb37:
  br label %bb38
bb38:
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t111 = getelementptr %"compiler/bindgen:gen", ptr %t109, i32 0, i32 6
  store ptr %t111, ptr %l56, !tbaa !29
  %t112 = load ptr, ptr %l1, !tbaa !29
  %t113 = load i64, ptr %l5, !tbaa !24
  %t116 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t112, i64 %t113)
  store i64 %t116, ptr %l59
  br label %bb39
bb39:
  %t117 = load ptr, ptr %l56, !tbaa !29
  %t118 = load i64, ptr %l59, !tbaa !24
  %t119 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eRefMu_Hc21bcd245b67ffb6ee3e145838fcf2cf(ptr %v0, ptr %v0, ptr %t117, i64 %t118)
  store ptr %t119, ptr %l60
  br label %bb40
bb40:
  %t120 = load ptr, ptr %l60, !tbaa !29
  %t122 = getelementptr %"compiler/bindgen:record", ptr %t120, i32 0, i32 19
  store ptr %t122, ptr %l62, !tbaa !29
  %t123 = load i64, ptr %l6, !tbaa !24
  store i64 %t123, ptr %l63, !tbaa !24
  %t126 = call { i64, ptr } @compiler_2fbindgen_2econstValue(ptr %v3, ptr %s0, ptr %a3)
  store { i64, ptr } %t126, ptr %l66
  br label %bb41
bb41:
  %t127 = load { i64, ptr }, ptr %l66, !tbaa !27
  store { i64, ptr } %t127, ptr %l67, !tbaa !27
  %t128 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s0, i64 10)
  %t129 = extractvalue { i32, i64 } %t128, 1
  %t130 = extractvalue { i32, i64 } %t128, 0
  store i32 %t130, ptr %l69
  %t131 = icmp ne i32 %t130, 0
  br i1 %t131, label %bb43, label %ok.132, !prof !99
ok.132:
  store i64 %t129, ptr %l68
  br label %bb42
bb42:
  %t133 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t134 = load i64, ptr %l68, !tbaa !24
  %t135 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %s0, { i64, ptr } %t133, i64 %t134)
  %t136 = extractvalue { i32, i64 } %t135, 1
  %t137 = extractvalue { i32, i64 } %t135, 0
  store i32 %t137, ptr %l71
  %t138 = icmp ne i32 %t137, 0
  br i1 %t138, label %bb46, label %ok.139, !prof !99
ok.139:
  store i64 %t136, ptr %l70
  br label %bb45
bb43:
  br label %bb44
bb44:
  store i64 -1, ptr %l64, !tbaa !24
  br label %bb47
bb45:
  %t140 = load i64, ptr %l70, !tbaa !24
  store i64 %t140, ptr %l64, !tbaa !24
  br label %bb47
bb46:
  br label %bb44
bb47:
  %t141 = load ptr, ptr %l62, !tbaa !29
  %t142 = load i64, ptr %l63, !tbaa !24
  %t143 = load i64, ptr %l64, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t141, i64 %t142, i64 %t143)
  br label %bb48
bb48:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i32, { i64, ptr } } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2evalueType(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i1 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca %"compiler/bindgen:ctype"
  %l4 = alloca i32
  %l5 = alloca i64
  %l6 = alloca %"compiler/bindgen:ctype"
  %l7 = alloca i64
  %l11 = alloca %"compiler/bindgen:ctype"
  %l16 = alloca i1
  %l17 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l22 = alloca i64
  %l23 = alloca { i64, ptr }
  %l28 = alloca i64
  %l31 = alloca i1
  %l34 = alloca i32
  %l39 = alloca %"compiler/bindgen:record"
  %l41 = alloca i1
  %l44 = alloca i1
  %l46 = alloca i32
  %l50 = alloca { i64, ptr }
  %l56 = alloca %"compiler/bindgen:ctype"
  %l59 = alloca i1
  %l60 = alloca { i64, ptr }
  %l61 = alloca { i64, ptr }
  %l62 = alloca i64
  %l63 = alloca { i64, ptr }
  %l68 = alloca { i64, ptr }
  %l73 = alloca i64
  %l76 = alloca i1
  %l80 = alloca { i64, ptr }
  %l84 = alloca { i64, ptr }
  %l87 = alloca { i64, ptr }
  %l89 = alloca ptr
  %l90 = alloca i64
  %l94 = alloca { i64, ptr }
  %l97 = alloca i32
  %l99 = alloca { i64, ptr }
  %l100 = alloca { i64, ptr }
  %l101 = alloca i64
  %l102 = alloca { i64, ptr }
  %l107 = alloca i32
  %l110 = alloca i32
  %l112 = alloca { i64, ptr }
  %l113 = alloca { i64, ptr }
  %l114 = alloca i64
  %l115 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  %t89 = alloca %"compiler/bindgen:record", align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/bindgen:gen", ptr %t1, i32 0, i32 17
  %t7 = call %"compiler/bindgen:ctype" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3actype_3e_2eAt_3ccompiler_2fbindgen_3actype_3e(ptr %v0, ptr %v0, ptr %t3, i64 %a1)
  store %"compiler/bindgen:ctype" %t7, ptr %l11
  br label %bb1
bb1:
  %t8 = load %"compiler/bindgen:ctype", ptr %l11
  store %"compiler/bindgen:ctype" %t8, ptr %l3
  %t9 = getelementptr %"compiler/bindgen:ctype", ptr %l3, i32 0, i32 0
  %t10 = load i32, ptr %t9, !range !{i32 0, i32 7}
  store i32 %t10, ptr %l4
  %t12 = load i32, ptr %l4, !range !{i32 0, i32 7}
  %t14 = trunc i64 1 to i32
  %t15 = icmp eq i32 %t12, %t14
  br i1 %t15, label %bb2, label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb9
bb4:
  store %olang.scope zeroinitializer, ptr %s1
  %t17 = getelementptr %"compiler/bindgen:ctype", ptr %l3, i32 0, i32 1
  %t18 = load { i64, ptr }, ptr %t17, !tbaa !27
  %t20 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s1, { i64, ptr } %t18, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d261, i32 0, i32 1) })
  store i1 %t20, ptr %l16
  br label %bb5
bb5:
  %t21 = load i1, ptr %l16, !tbaa !21
  br i1 %t21, label %bb6, label %bb7
bb6:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d262, i32 0, i32 1) }, ptr %l18, !tbaa !27
  %t22 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t22, ptr %l17, !tbaa !27
  br label %bb8
bb7:
  %t24 = getelementptr %"compiler/bindgen:ctype", ptr %l3, i32 0, i32 1
  %t25 = load { i64, ptr }, ptr %t24, !tbaa !27
  %t27 = extractvalue { i64, ptr } %t25, 1
  %t28 = extractvalue { i64, ptr } %t25, 0
  %t29 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t28)
  call void @olang_textcopy(ptr %t29, ptr %t27, i64 %t28)
  %t30 = insertvalue { i64, ptr } undef, i64 %t28, 0
  %t31 = insertvalue { i64, ptr } %t30, ptr %t29, 1
  store { i64, ptr } %t31, ptr %l17, !tbaa !27
  br label %bb8
bb8:
  %t33 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t34 = extractvalue { i64, ptr } %t33, 0
  store i64 %t34, ptr %l22, !tbaa !24
  %t35 = load i64, ptr %l22, !tbaa !24
  %t36 = mul i64 %t35, 1
  %t37 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t36)
  %t38 = insertvalue { i64, ptr } undef, i64 %t35, 0
  %t39 = insertvalue { i64, ptr } %t38, ptr %t37, 1
  store { i64, ptr } %t39, ptr %l23, !tbaa !27
  %t40 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !27
  %t42 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = load i64, ptr %l22, !tbaa !24
  %t45 = mul i64 %t44, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t41, ptr %t43, i64 %t45, i1 false)
  %t46 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t46, ptr %l17, !tbaa !27
  call void @__olang_scope_close(ptr %s1)
  %t47 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t48 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t47, 1
  store { i32, { i64, ptr } } %t48, ptr %rv
  br label %ret
bb9:
  %t49 = load i32, ptr %l4, !range !{i32 0, i32 7}
  %t51 = trunc i64 2 to i32
  %t52 = icmp eq i32 %t49, %t51
  br i1 %t52, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb33
bb12:
  store %olang.scope zeroinitializer, ptr %s3
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/bindgen:ctype", ptr %l3, i32 0, i32 1
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  %t59 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2erecOf(ptr %v0, ptr %v0, ptr %t54, { i64, ptr } %t56)
  store i64 %t59, ptr %l28
  br label %bb13
bb13:
  %t60 = load i64, ptr %l28, !tbaa !24
  store i64 %t60, ptr %l5, !tbaa !24
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t62 = load i64, ptr %l5, !tbaa !24
  %t65 = call i1 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eplain(ptr %v0, ptr %t61, i64 %t62)
  store i1 %t65, ptr %l31
  br label %bb14
bb14:
  %t66 = load i1, ptr %l31, !tbaa !21
  %t67 = xor i1 %t66, true
  br i1 %t67, label %bb15, label %bb16
bb15:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = call i32 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eskip(ptr %v0, ptr %v0, ptr %t69, { i64, ptr } { i64 46, ptr getelementptr inbounds (<{ i64, [46 x i8] }>, ptr @.d263, i32 0, i32 1) })
  store i32 %t71, ptr %l34
  %t72 = icmp ne i32 %t71, 0
  br i1 %t72, label %bb18, label %ok.73, !prof !99
ok.73:
  br label %bb17
bb16:
  br label %bb20
bb17:
  br label %bb19
bb18:
  %t74 = load i32, ptr %l34, !tbaa !23
  %t75 = lshr i32 %t74, 16
  %t76 = and i32 %t74, 65535
  %t77 = icmp eq i32 %t75, 1
  %t78 = select i1 %t77, i32 1, i32 0
  %t79 = icmp eq i32 %t74, 0
  %t80 = shl i32 %t78, 16
  %t81 = or i32 %t80, %t76
  %t82 = select i1 %t79, i32 0, i32 %t81
  call void @__olang_scope_close(ptr %s3)
  %t84 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t82, 0
  store { i32, { i64, ptr } } %t84, ptr %rv
  br label %ret
bb19:
  br label %bb20
bb20:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"compiler/bindgen:gen", ptr %t85, i32 0, i32 6
  %t88 = load i64, ptr %l5, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eAt_3ccompiler_2fbindgen_3arecord_3e(ptr %t89, ptr %v0, ptr %s3, ptr %t87, i64 %t88)
  call void @llvm.memmove.p0.p0.i64(ptr %l39, ptr %t89, i64 312, i1 false)
  br label %bb21
bb21:
  %t92 = getelementptr %"compiler/bindgen:record", ptr %l39, i32 0, i32 15
  %t93 = load i1, ptr %t92, !tbaa !21
  br i1 %t93, label %bb22, label %bb23
bb22:
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t96 = load i64, ptr %l5, !tbaa !24
  %t99 = call i1 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2epackedFloat(ptr %v0, ptr %t95, i64 %t96)
  store i1 %t99, ptr %l44
  br label %bb24
bb23:
  store i1 false, ptr %l41, !tbaa !21
  br label %bb25
bb24:
  %t100 = load i1, ptr %l44, !tbaa !21
  store i1 %t100, ptr %l41, !tbaa !21
  br label %bb25
bb25:
  %t101 = load i1, ptr %l41, !tbaa !21
  br i1 %t101, label %bb26, label %bb27
bb26:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = call i32 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eskip(ptr %v0, ptr %v0, ptr %t102, { i64, ptr } { i64 47, ptr getelementptr inbounds (<{ i64, [47 x i8] }>, ptr @.d264, i32 0, i32 1) })
  store i32 %t104, ptr %l46
  %t105 = icmp ne i32 %t104, 0
  br i1 %t105, label %bb29, label %ok.106, !prof !99
ok.106:
  br label %bb28
bb27:
  br label %bb31
bb28:
  br label %bb30
bb29:
  %t107 = load i32, ptr %l46, !tbaa !23
  %t108 = lshr i32 %t107, 16
  %t109 = and i32 %t107, 65535
  %t110 = icmp eq i32 %t108, 1
  %t111 = select i1 %t110, i32 1, i32 0
  %t112 = icmp eq i32 %t107, 0
  %t113 = shl i32 %t111, 16
  %t114 = or i32 %t113, %t109
  %t115 = select i1 %t112, i32 0, i32 %t114
  call void @__olang_scope_close(ptr %s3)
  %t117 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t115, 0
  store { i32, { i64, ptr } } %t117, ptr %rv
  br label %ret
bb30:
  br label %bb31
bb31:
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t119 = load i64, ptr %l5, !tbaa !24
  %t122 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ename(ptr %v0, ptr %v1, ptr %t118, i64 %t119)
  store { i64, ptr } %t122, ptr %l50
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s3)
  %t123 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t124 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t123, 1
  store { i32, { i64, ptr } } %t124, ptr %rv
  br label %ret
bb33:
  %t125 = load i32, ptr %l4, !range !{i32 0, i32 7}
  %t127 = trunc i64 3 to i32
  %t128 = icmp eq i32 %t125, %t127
  br i1 %t128, label %bb34, label %bb35
bb34:
  br label %bb36
bb35:
  br label %bb68
bb36:
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t132 = getelementptr %"compiler/bindgen:gen", ptr %t130, i32 0, i32 17
  %t133 = getelementptr %"compiler/bindgen:ctype", ptr %l3, i32 0, i32 2
  %t134 = load i64, ptr %t133, !tbaa !24
  %t137 = call %"compiler/bindgen:ctype" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3actype_3e_2eAt_3ccompiler_2fbindgen_3actype_3e(ptr %v0, ptr %v0, ptr %t132, i64 %t134)
  store %"compiler/bindgen:ctype" %t137, ptr %l56
  br label %bb37
bb37:
  %t138 = load %"compiler/bindgen:ctype", ptr %l56
  store %"compiler/bindgen:ctype" %t138, ptr %l6
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t140 = getelementptr %"compiler/bindgen:ctype", ptr %l3, i32 0, i32 2
  %t141 = load i64, ptr %t140, !tbaa !24
  %t144 = call i1 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eisByte(ptr %v0, ptr %t139, i64 %t141)
  store i1 %t144, ptr %l59
  br label %bb38
bb38:
  %t145 = load i1, ptr %l59, !tbaa !21
  br i1 %t145, label %bb39, label %bb40
bb39:
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d265, i32 0, i32 1) }, ptr %l60, !tbaa !27
  %t146 = load { i64, ptr }, ptr %l60, !tbaa !27
  store { i64, ptr } %t146, ptr %l61, !tbaa !27
  %t147 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t148 = extractvalue { i64, ptr } %t147, 0
  store i64 %t148, ptr %l62, !tbaa !24
  %t149 = load i64, ptr %l62, !tbaa !24
  %t150 = mul i64 %t149, 1
  %t151 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t150)
  %t152 = insertvalue { i64, ptr } undef, i64 %t149, 0
  %t153 = insertvalue { i64, ptr } %t152, ptr %t151, 1
  store { i64, ptr } %t153, ptr %l63, !tbaa !27
  %t154 = getelementptr { i64, ptr }, ptr %l63, i32 0, i32 1
  %t155 = load ptr, ptr %t154, !tbaa !27
  %t156 = getelementptr { i64, ptr }, ptr %l61, i32 0, i32 1
  %t157 = load ptr, ptr %t156, !tbaa !27
  %t158 = load i64, ptr %l62, !tbaa !24
  %t159 = mul i64 %t158, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t155, ptr %t157, i64 %t159, i1 false)
  %t160 = load { i64, ptr }, ptr %l63, !tbaa !27
  store { i64, ptr } %t160, ptr %l61, !tbaa !27
  %t161 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t162 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t161, 1
  store { i32, { i64, ptr } } %t162, ptr %rv
  br label %ret
bb40:
  br label %bb41
bb41:
  %t163 = getelementptr %"compiler/bindgen:ctype", ptr %l6, i32 0, i32 0
  %t164 = load i32, ptr %t163, !range !{i32 0, i32 7}
  %t166 = trunc i64 5 to i32
  %t167 = icmp eq i32 %t164, %t166
  br i1 %t167, label %bb42, label %bb43
bb42:
  %t169 = load ptr, ptr %l0, !tbaa !29
  %t170 = load %"compiler/bindgen:ctype", ptr %l6
  %t173 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ecFunc(ptr %v0, ptr %v0, ptr %v1, ptr %t169, %"compiler/bindgen:ctype" %t170)
  store { i64, ptr } %t173, ptr %l68
  br label %bb44
bb43:
  br label %bb45
bb44:
  %t174 = load { i64, ptr }, ptr %l68, !tbaa !27
  %t175 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t174, 1
  store { i32, { i64, ptr } } %t175, ptr %rv
  br label %ret
bb45:
  %t176 = getelementptr %"compiler/bindgen:ctype", ptr %l6, i32 0, i32 0
  %t177 = load i32, ptr %t176, !range !{i32 0, i32 7}
  %t179 = trunc i64 2 to i32
  %t180 = icmp eq i32 %t177, %t179
  br i1 %t180, label %bb46, label %bb47
bb46:
  store %olang.scope zeroinitializer, ptr %s9
  %t182 = load ptr, ptr %l0, !tbaa !29
  %t183 = getelementptr %"compiler/bindgen:ctype", ptr %l6, i32 0, i32 1
  %t184 = load { i64, ptr }, ptr %t183, !tbaa !27
  %t187 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2erecOf(ptr %v0, ptr %v0, ptr %t182, { i64, ptr } %t184)
  store i64 %t187, ptr %l73
  br label %bb48
bb47:
  br label %bb67
bb48:
  %t188 = load i64, ptr %l73, !tbaa !24
  store i64 %t188, ptr %l7, !tbaa !24
  %t189 = load ptr, ptr %l0, !tbaa !29
  %t190 = load i64, ptr %l7, !tbaa !24
  %t193 = call i1 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eholdable(ptr %v0, ptr %t189, i64 %t190)
  store i1 %t193, ptr %l76
  br label %bb49
bb49:
  %t194 = load i1, ptr %l76, !tbaa !21
  %t195 = xor i1 %t194, true
  br i1 %t195, label %bb50, label %bb51
bb50:
  store %olang.scope zeroinitializer, ptr %s10
  %t197 = load ptr, ptr %l0, !tbaa !29
  %t198 = load i64, ptr %l7, !tbaa !24
  %t201 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ename(ptr %v0, ptr %s10, ptr %t197, i64 %t198)
  store { i64, ptr } %t201, ptr %l80
  br label %bb52
bb51:
  br label %bb53
bb52:
  %t202 = load { i64, ptr }, ptr %l80, !tbaa !27
  %t203 = extractvalue { i64, ptr } %t202, 1
  %t204 = extractvalue { i64, ptr } %t202, 0
  %t205 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d266, i32 0, i32 1) }, 1
  %t206 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d266, i32 0, i32 1) }, 0
  %t207 = add i64 %t204, %t206
  %t208 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t207)
  call void @olang_textcopy(ptr %t208, ptr %t203, i64 %t204)
  %t209 = getelementptr i8, ptr %t208, i64 %t204
  call void @olang_textcopy(ptr %t209, ptr %t205, i64 %t206)
  %t210 = insertvalue { i64, ptr } undef, i64 %t207, 0
  %t211 = insertvalue { i64, ptr } %t210, ptr %t208, 1
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s9)
  %t213 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t211, 1
  store { i32, { i64, ptr } } %t213, ptr %rv
  br label %ret
bb53:
  br i1 %a2, label %bb54, label %bb55
bb54:
  store %olang.scope zeroinitializer, ptr %s12
  %t216 = getelementptr %"compiler/bindgen:ctype", ptr %l3, i32 0, i32 3
  %t217 = load i1, ptr %t216, !tbaa !21
  br i1 %t217, label %bb56, label %bb57
bb55:
  br label %bb60
bb56:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d267, i32 0, i32 1) }, ptr %l84, !tbaa !27
  br label %bb58
bb57:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d268, i32 0, i32 1) }, ptr %l84, !tbaa !27
  br label %bb58
bb58:
  %t219 = load ptr, ptr %l0, !tbaa !29
  %t220 = load i64, ptr %l7, !tbaa !24
  %t223 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ename(ptr %v0, ptr %s12, ptr %t219, i64 %t220)
  store { i64, ptr } %t223, ptr %l87
  br label %bb59
bb59:
  %t224 = load { i64, ptr }, ptr %l84, !tbaa !27
  %t225 = extractvalue { i64, ptr } %t224, 1
  %t226 = extractvalue { i64, ptr } %t224, 0
  %t227 = load { i64, ptr }, ptr %l87, !tbaa !27
  %t228 = extractvalue { i64, ptr } %t227, 1
  %t229 = extractvalue { i64, ptr } %t227, 0
  %t230 = add i64 %t226, %t229
  %t231 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d269, i32 0, i32 1) }, 1
  %t232 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d269, i32 0, i32 1) }, 0
  %t233 = add i64 %t230, %t232
  %t234 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t233)
  call void @olang_textcopy(ptr %t234, ptr %t225, i64 %t226)
  %t235 = getelementptr i8, ptr %t234, i64 %t226
  call void @olang_textcopy(ptr %t235, ptr %t228, i64 %t229)
  %t236 = getelementptr i8, ptr %t235, i64 %t229
  call void @olang_textcopy(ptr %t236, ptr %t231, i64 %t232)
  %t237 = insertvalue { i64, ptr } undef, i64 %t233, 0
  %t238 = insertvalue { i64, ptr } %t237, ptr %t234, 1
  call void @__olang_scope_close(ptr %s12)
  call void @__olang_scope_close(ptr %s9)
  %t240 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t238, 1
  store { i32, { i64, ptr } } %t240, ptr %rv
  br label %ret
bb60:
  %t241 = load ptr, ptr %l0, !tbaa !29
  store ptr %t241, ptr %l89, !tbaa !29
  %t242 = call ptr @__olang_scope_hold(ptr %v0)
  %t243 = ptrtoint ptr %t242 to i64
  store i64 %t243, ptr %l90, !tbaa !24
  %t244 = load i1, ptr @olang_2esole_2ecompiler_2fbindgen_3agen_2e26
  br i1 %t244, label %bb61, label %bb62
bb61:
  %t246 = call ptr @__olang_region_make(ptr %v0)
  %t247 = ptrtoint ptr %t246 to i64
  store i64 %t247, ptr %l90, !tbaa !24
  br label %bb62
bb62:
  %t248 = load ptr, ptr %l0, !tbaa !29
  %t249 = load i64, ptr %l7, !tbaa !24
  %t252 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ename(ptr %v0, ptr %s9, ptr %t248, i64 %t249)
  store { i64, ptr } %t252, ptr %l94
  br label %bb63
bb63:
  %t253 = extractvalue { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d270, i32 0, i32 1) }, 1
  %t254 = extractvalue { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d270, i32 0, i32 1) }, 0
  %t255 = load { i64, ptr }, ptr %l94, !tbaa !27
  %t256 = extractvalue { i64, ptr } %t255, 1
  %t257 = extractvalue { i64, ptr } %t255, 0
  %t258 = add i64 %t254, %t257
  %t259 = extractvalue { i64, ptr } { i64 67, ptr getelementptr inbounds (<{ i64, [67 x i8] }>, ptr @.d271, i32 0, i32 1) }, 1
  %t260 = extractvalue { i64, ptr } { i64 67, ptr getelementptr inbounds (<{ i64, [67 x i8] }>, ptr @.d271, i32 0, i32 1) }, 0
  %t261 = add i64 %t258, %t260
  %t262 = load i64, ptr %l90
  %t263 = inttoptr i64 %t262 to ptr
  %t264 = call ptr @__olang_held_alloc(ptr %t263, i64 %t261)
  call void @olang_textcopy(ptr %t264, ptr %t253, i64 %t254)
  %t265 = getelementptr i8, ptr %t264, i64 %t254
  call void @olang_textcopy(ptr %t265, ptr %t256, i64 %t257)
  %t266 = getelementptr i8, ptr %t265, i64 %t257
  call void @olang_textcopy(ptr %t266, ptr %t259, i64 %t260)
  %t267 = insertvalue { i64, ptr } undef, i64 %t261, 0
  %t268 = insertvalue { i64, ptr } %t267, ptr %t264, 1
  %t270 = load ptr, ptr %l89, !tbaa !29
  %t272 = call i32 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eskip(ptr %v0, ptr %v0, ptr %t270, { i64, ptr } %t268)
  store i32 %t272, ptr %l97
  %t273 = icmp ne i32 %t272, 0
  br i1 %t273, label %bb65, label %ok.274, !prof !99
ok.274:
  br label %bb64
bb64:
  br label %bb66
bb65:
  %t275 = load i32, ptr %l97, !tbaa !23
  %t276 = lshr i32 %t275, 16
  %t277 = and i32 %t275, 65535
  %t278 = icmp eq i32 %t276, 1
  %t279 = select i1 %t278, i32 1, i32 0
  %t280 = icmp eq i32 %t275, 0
  %t281 = shl i32 %t279, 16
  %t282 = or i32 %t281, %t277
  %t283 = select i1 %t280, i32 0, i32 %t282
  call void @__olang_scope_close(ptr %s9)
  %t285 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t283, 0
  store { i32, { i64, ptr } } %t285, ptr %rv
  br label %ret
bb66:
  call void @__olang_scope_close(ptr %s9)
  br label %bb67
bb67:
  store { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d272, i32 0, i32 1) }, ptr %l99, !tbaa !27
  %t286 = load { i64, ptr }, ptr %l99, !tbaa !27
  store { i64, ptr } %t286, ptr %l100, !tbaa !27
  %t287 = load { i64, ptr }, ptr %l100, !tbaa !27
  %t288 = extractvalue { i64, ptr } %t287, 0
  store i64 %t288, ptr %l101, !tbaa !24
  %t289 = load i64, ptr %l101, !tbaa !24
  %t290 = mul i64 %t289, 1
  %t291 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t290)
  %t292 = insertvalue { i64, ptr } undef, i64 %t289, 0
  %t293 = insertvalue { i64, ptr } %t292, ptr %t291, 1
  store { i64, ptr } %t293, ptr %l102, !tbaa !27
  %t294 = getelementptr { i64, ptr }, ptr %l102, i32 0, i32 1
  %t295 = load ptr, ptr %t294, !tbaa !27
  %t296 = getelementptr { i64, ptr }, ptr %l100, i32 0, i32 1
  %t297 = load ptr, ptr %t296, !tbaa !27
  %t298 = load i64, ptr %l101, !tbaa !24
  %t299 = mul i64 %t298, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t295, ptr %t297, i64 %t299, i1 false)
  %t300 = load { i64, ptr }, ptr %l102, !tbaa !27
  store { i64, ptr } %t300, ptr %l100, !tbaa !27
  %t301 = load { i64, ptr }, ptr %l100, !tbaa !27
  %t302 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t301, 1
  store { i32, { i64, ptr } } %t302, ptr %rv
  br label %ret
bb68:
  %t303 = load i32, ptr %l4, !range !{i32 0, i32 7}
  %t305 = trunc i64 6 to i32
  %t306 = icmp eq i32 %t303, %t305
  br i1 %t306, label %bb69, label %bb70
bb69:
  br label %bb71
bb70:
  br label %bb75
bb71:
  %t308 = load ptr, ptr %l0, !tbaa !29
  %t309 = getelementptr %"compiler/bindgen:ctype", ptr %l3, i32 0, i32 1
  %t310 = load { i64, ptr }, ptr %t309, !tbaa !27
  %t313 = call i32 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eskip(ptr %v0, ptr %v0, ptr %t308, { i64, ptr } %t310)
  store i32 %t313, ptr %l107
  %t314 = icmp ne i32 %t313, 0
  br i1 %t314, label %bb73, label %ok.315, !prof !99
ok.315:
  br label %bb72
bb72:
  br label %bb74
bb73:
  %t316 = load i32, ptr %l107, !tbaa !23
  %t317 = lshr i32 %t316, 16
  %t318 = and i32 %t316, 65535
  %t319 = icmp eq i32 %t317, 1
  %t320 = select i1 %t319, i32 1, i32 0
  %t321 = icmp eq i32 %t316, 0
  %t322 = shl i32 %t320, 16
  %t323 = or i32 %t322, %t318
  %t324 = select i1 %t321, i32 0, i32 %t323
  %t326 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t324, 0
  store { i32, { i64, ptr } } %t326, ptr %rv
  br label %ret
bb74:
  br label %bb83
bb75:
  br i1 true, label %bb76, label %bb77
bb76:
  br label %bb78
bb77:
  br label %bb82
bb78:
  %t327 = load ptr, ptr %l0, !tbaa !29
  %t329 = call i32 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eskip(ptr %v0, ptr %v0, ptr %t327, { i64, ptr } { i64 45, ptr getelementptr inbounds (<{ i64, [45 x i8] }>, ptr @.d273, i32 0, i32 1) })
  store i32 %t329, ptr %l110
  %t330 = icmp ne i32 %t329, 0
  br i1 %t330, label %bb80, label %ok.331, !prof !99
ok.331:
  br label %bb79
bb79:
  br label %bb81
bb80:
  %t332 = load i32, ptr %l110, !tbaa !23
  %t333 = lshr i32 %t332, 16
  %t334 = and i32 %t332, 65535
  %t335 = icmp eq i32 %t333, 1
  %t336 = select i1 %t335, i32 1, i32 0
  %t337 = icmp eq i32 %t332, 0
  %t338 = shl i32 %t336, 16
  %t339 = or i32 %t338, %t334
  %t340 = select i1 %t337, i32 0, i32 %t339
  %t342 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t340, 0
  store { i32, { i64, ptr } } %t342, ptr %rv
  br label %ret
bb81:
  br label %bb83
bb82:
  call void @__olang_check_failed(ptr @olang_loc_383dad6bbc51ebc3_b2d1cf432887049f)
  unreachable
bb83:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d274, i32 0, i32 1) }, ptr %l112, !tbaa !27
  %t343 = load { i64, ptr }, ptr %l112, !tbaa !27
  store { i64, ptr } %t343, ptr %l113, !tbaa !27
  %t344 = load { i64, ptr }, ptr %l113, !tbaa !27
  %t345 = extractvalue { i64, ptr } %t344, 0
  store i64 %t345, ptr %l114, !tbaa !24
  %t346 = load i64, ptr %l114, !tbaa !24
  %t347 = mul i64 %t346, 1
  %t348 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t347)
  %t349 = insertvalue { i64, ptr } undef, i64 %t346, 0
  %t350 = insertvalue { i64, ptr } %t349, ptr %t348, 1
  store { i64, ptr } %t350, ptr %l115, !tbaa !27
  %t351 = getelementptr { i64, ptr }, ptr %l115, i32 0, i32 1
  %t352 = load ptr, ptr %t351, !tbaa !27
  %t353 = getelementptr { i64, ptr }, ptr %l113, i32 0, i32 1
  %t354 = load ptr, ptr %t353, !tbaa !27
  %t355 = load i64, ptr %l114, !tbaa !24
  %t356 = mul i64 %t355, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t352, ptr %t354, i64 %t356, i1 false)
  %t357 = load { i64, ptr }, ptr %l115, !tbaa !27
  store { i64, ptr } %t357, ptr %l113, !tbaa !27
  %t358 = load { i64, ptr }, ptr %l113, !tbaa !27
  %t359 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t358, 1
  store { i32, { i64, ptr } } %t359, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local i1 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ewantRecord(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l6 = alloca ptr
  %l15 = alloca i1
  %l20 = alloca i1
  %l23 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/bindgen:gen", ptr %t1, i32 0, i32 6
  %t7 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eRef_3ccompiler_2fbindgen_3arecord_3e(ptr %v0, ptr %v0, ptr %t3, i64 %a1)
  store ptr %t7, ptr %l6
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l6, !tbaa !29
  store ptr %t8, ptr %l2, !tbaa !29
  %t9 = load ptr, ptr %l2, !tbaa !29
  %t11 = getelementptr %"compiler/bindgen:record", ptr %t9, i32 0, i32 8
  %t12 = load i1, ptr %t11, !tbaa !21
  br i1 %t12, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/bindgen:gen", ptr %t15, i32 0, i32 1
  %t18 = load i1, ptr %t17, !tbaa !21
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb5, label %bb6
bb5:
  %t22 = load ptr, ptr %l2, !tbaa !29
  %t24 = getelementptr %"compiler/bindgen:record", ptr %t22, i32 0, i32 6
  %t25 = load i1, ptr %t24, !tbaa !21
  br i1 %t25, label %bb7, label %bb8
bb6:
  br label %bb10
bb7:
  %t27 = load ptr, ptr %l2, !tbaa !29
  %t29 = getelementptr %"compiler/bindgen:record", ptr %t27, i32 0, i32 2
  %t30 = load i1, ptr %t29, !tbaa !21
  store i1 %t30, ptr %l15, !tbaa !21
  br label %bb9
bb8:
  store i1 false, ptr %l15, !tbaa !21
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s0)
  %t32 = load i1, ptr %l15, !tbaa !21
  store i1 %t32, ptr %rv
  br label %ret
bb10:
  %t33 = load ptr, ptr %l2, !tbaa !29
  %t35 = getelementptr %"compiler/bindgen:record", ptr %t33, i32 0, i32 2
  %t36 = load i1, ptr %t35, !tbaa !21
  br i1 %t36, label %bb11, label %bb12
bb11:
  %t38 = load ptr, ptr %l2, !tbaa !29
  %t40 = getelementptr %"compiler/bindgen:record", ptr %t38, i32 0, i32 7
  %t41 = load { i64, ptr }, ptr %t40, !tbaa !27
  %t43 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t41, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d275, i32 0, i32 1) })
  store i1 %t43, ptr %l23
  br label %bb13
bb12:
  store i1 false, ptr %l20, !tbaa !21
  br label %bb14
bb13:
  %t44 = load i1, ptr %l23, !tbaa !21
  %t45 = xor i1 %t44, true
  store i1 %t45, ptr %l20, !tbaa !21
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s0)
  %t47 = load i1, ptr %l20, !tbaa !21
  store i1 %t47, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ewrapper(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l23 = alloca i1
  %l25 = alloca i32
  %l28 = alloca { i64, ptr }
  %l30 = alloca i1
  %l32 = alloca i32
  %l60 = alloca { i64, ptr }
  %l79 = alloca i1
  %l95 = alloca i64
  %l98 = alloca i64
  %s0 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/bindgen:cFunc", ptr %t1, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = call { i64, ptr } @compiler_2fbindgen_2enoReturnOf(ptr %v1, ptr %s0, { i64, ptr } %t4)
  store { i64, ptr } %t6, ptr %l18
  br label %bb1
bb1:
  %t7 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t7, 0
  store i64 %t8, ptr %l19, !tbaa !24
  %t9 = load i64, ptr %l19, !tbaa !24
  %t10 = mul i64 %t9, 1
  %t11 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t10)
  %t12 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t13 = insertvalue { i64, ptr } %t12, ptr %t11, 1
  store { i64, ptr } %t13, ptr %l20, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = load i64, ptr %l19, !tbaa !24
  %t19 = mul i64 %t18, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t15, ptr %t17, i64 %t19, i1 false)
  %t20 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t20, ptr %l2, !tbaa !27
  %t21 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d276, i32 0, i32 1) }, ptr %l22, !tbaa !27
  %t23 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t24 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %s0, ptr %s0, { i64, ptr } %t21, { i64, ptr } %t23)
  store i1 %t24, ptr %l23
  br label %bb2
bb2:
  %t25 = load i1, ptr %l23, !tbaa !21
  br i1 %t25, label %bb3, label %bb4
bb3:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = call i32 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eskip(ptr %v0, ptr %v0, ptr %t26, { i64, ptr } { i64 59, ptr getelementptr inbounds (<{ i64, [59 x i8] }>, ptr @.d277, i32 0, i32 1) })
  store i32 %t28, ptr %l25
  %t29 = icmp ne i32 %t28, 0
  br i1 %t29, label %bb6, label %ok.30, !prof !99
ok.30:
  br label %bb5
bb4:
  br label %bb8
bb5:
  br label %bb7
bb6:
  %t31 = load i32, ptr %l25, !tbaa !23
  %t32 = lshr i32 %t31, 16
  %t33 = and i32 %t31, 65535
  %t34 = icmp eq i32 %t32, 1
  %t35 = select i1 %t34, i32 1, i32 0
  %t36 = icmp eq i32 %t31, 0
  %t37 = shl i32 %t35, 16
  %t38 = or i32 %t37, %t33
  %t39 = select i1 %t36, i32 0, i32 %t38
  call void @__olang_scope_close(ptr %s0)
  %t41 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t39, 0
  store { i32, { i64, ptr } } %t41, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t42 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t44 = call { i64, ptr } @compiler_2fbindgen_2eresultText(ptr %s0, ptr %s0, { i64, ptr } %t42)
  store { i64, ptr } %t44, ptr %l28
  br label %bb9
bb9:
  %t45 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t45, ptr %l3, !tbaa !27
  %t46 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t48 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t46, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d278, i32 0, i32 1) })
  store i1 %t48, ptr %l30
  br label %bb10
bb10:
  %t49 = load i1, ptr %l30, !tbaa !21
  br i1 %t49, label %bb11, label %bb12
bb11:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = call i32 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eskip(ptr %v0, ptr %v0, ptr %t50, { i64, ptr } { i64 55, ptr getelementptr inbounds (<{ i64, [55 x i8] }>, ptr @.d279, i32 0, i32 1) })
  store i32 %t52, ptr %l32
  %t53 = icmp ne i32 %t52, 0
  br i1 %t53, label %bb14, label %ok.54, !prof !99
ok.54:
  br label %bb13
bb12:
  br label %bb16
bb13:
  br label %bb15
bb14:
  %t55 = load i32, ptr %l32, !tbaa !23
  %t56 = lshr i32 %t55, 16
  %t57 = and i32 %t55, 65535
  %t58 = icmp eq i32 %t56, 1
  %t59 = select i1 %t58, i32 1, i32 0
  %t60 = icmp eq i32 %t55, 0
  %t61 = shl i32 %t59, 16
  %t62 = or i32 %t61, %t57
  %t63 = select i1 %t60, i32 0, i32 %t62
  call void @__olang_scope_close(ptr %s0)
  %t65 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t63, 0
  store { i32, { i64, ptr } } %t65, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"compiler/bindgen:gen", ptr %t66, i32 0, i32 3
  %t69 = load { i64, ptr }, ptr %t68, !tbaa !27
  %t70 = load ptr, ptr %l1, !tbaa !29
  %t72 = getelementptr %"compiler/bindgen:cFunc", ptr %t70, i32 0, i32 0
  %t73 = load { i64, ptr }, ptr %t72, !tbaa !27
  %t74 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d280, i32 0, i32 1) }, 1
  %t75 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d280, i32 0, i32 1) }, 0
  %t77 = extractvalue { i64, ptr } %t69, 1
  %t78 = extractvalue { i64, ptr } %t69, 0
  %t79 = add i64 %t75, %t78
  %t80 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d281, i32 0, i32 1) }, 1
  %t81 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d281, i32 0, i32 1) }, 0
  %t82 = add i64 %t79, %t81
  %t84 = extractvalue { i64, ptr } %t73, 1
  %t85 = extractvalue { i64, ptr } %t73, 0
  %t86 = add i64 %t82, %t85
  %t87 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t86)
  call void @olang_textcopy(ptr %t87, ptr %t74, i64 %t75)
  %t88 = getelementptr i8, ptr %t87, i64 %t75
  call void @olang_textcopy(ptr %t88, ptr %t77, i64 %t78)
  %t89 = getelementptr i8, ptr %t88, i64 %t78
  call void @olang_textcopy(ptr %t89, ptr %t80, i64 %t81)
  %t90 = getelementptr i8, ptr %t89, i64 %t81
  call void @olang_textcopy(ptr %t90, ptr %t84, i64 %t85)
  %t91 = insertvalue { i64, ptr } undef, i64 %t86, 0
  %t92 = insertvalue { i64, ptr } %t91, ptr %t87, 1
  store { i64, ptr } %t92, ptr %l4, !tbaa !27
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t96 = getelementptr %"compiler/bindgen:gen", ptr %t94, i32 0, i32 21
  %t97 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t98 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t100 = extractvalue { i64, ptr } %t97, 1
  %t101 = extractvalue { i64, ptr } %t97, 0
  %t102 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d282, i32 0, i32 1) }, 1
  %t103 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d282, i32 0, i32 1) }, 0
  %t104 = add i64 %t101, %t103
  %t106 = extractvalue { i64, ptr } %t98, 1
  %t107 = extractvalue { i64, ptr } %t98, 0
  %t108 = add i64 %t104, %t107
  %t109 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d283, i32 0, i32 1) }, 1
  %t110 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d283, i32 0, i32 1) }, 0
  %t111 = add i64 %t108, %t110
  %t112 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t111)
  call void @olang_textcopy(ptr %t112, ptr %t100, i64 %t101)
  %t113 = getelementptr i8, ptr %t112, i64 %t101
  call void @olang_textcopy(ptr %t113, ptr %t102, i64 %t103)
  %t114 = getelementptr i8, ptr %t113, i64 %t103
  call void @olang_textcopy(ptr %t114, ptr %t106, i64 %t107)
  %t115 = getelementptr i8, ptr %t114, i64 %t107
  call void @olang_textcopy(ptr %t115, ptr %t109, i64 %t110)
  %t116 = insertvalue { i64, ptr } undef, i64 %t111, 0
  %t117 = insertvalue { i64, ptr } %t116, ptr %t112, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s0, ptr %t96, { i64, ptr } %t117)
  br label %bb17
bb17:
  %t121 = load ptr, ptr %l1, !tbaa !29
  %t123 = getelementptr %"compiler/bindgen:cFunc", ptr %t121, i32 0, i32 3
  %t124 = load { i64, ptr }, ptr %t123, !tbaa !27
  %t126 = extractvalue { i64, ptr } %t124, 0
  %t128 = icmp eq i64 %t126, 0
  br i1 %t128, label %bb18, label %bb19
bb18:
  store %olang.scope zeroinitializer, ptr %s5
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t132 = getelementptr %"compiler/bindgen:gen", ptr %t130, i32 0, i32 21
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s5, ptr %t132, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d284, i32 0, i32 1) })
  br label %bb20
bb19:
  br label %bb21
bb20:
  call void @__olang_scope_close(ptr %s5)
  br label %bb21
bb21:
  %t134 = load ptr, ptr %l1, !tbaa !29
  %t136 = getelementptr %"compiler/bindgen:cFunc", ptr %t134, i32 0, i32 3
  %t137 = load { i64, ptr }, ptr %t136, !tbaa !27
  store { i64, ptr } %t137, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t139 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t141 = extractvalue { i64, ptr } %t139, 0
  store i64 %t141, ptr %l7, !tbaa !24
  br label %bb22
bb22:
  store %olang.scope zeroinitializer, ptr %s7
  %t143 = load i64, ptr %l6, !tbaa !24
  %t144 = load i64, ptr %l7, !tbaa !24
  %t147 = icmp slt i64 %t143, %t144
  %t149 = xor i1 %t147, true
  br i1 %t149, label %bb23, label %bb24
bb23:
  call void @__olang_scope_close(ptr %s7)
  br label %bb32
bb24:
  br label %bb25
bb25:
  %t151 = load i64, ptr %l6, !tbaa !24
  store i64 %t151, ptr %l8, !tbaa !24
  %t153 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t153, ptr %l60, !tbaa !27
  %t154 = load i64, ptr %l6, !tbaa !24
  %t156 = getelementptr { i64, ptr }, ptr %l60, i32 0, i32 1
  %t157 = load ptr, ptr %t156, !tbaa !27
  %t158 = getelementptr { i64, ptr }, ptr %t157, i64 %t154
  %t159 = load { i64, ptr }, ptr %t158, !tbaa !37
  store { i64, ptr } %t159, ptr %l9, !tbaa !27
  %t161 = load i64, ptr %l8, !tbaa !24
  %t163 = icmp sgt i64 %t161, 0
  br i1 %t163, label %bb26, label %bb27
bb26:
  store %olang.scope zeroinitializer, ptr %s8
  %t165 = load ptr, ptr %l0, !tbaa !29
  %t167 = getelementptr %"compiler/bindgen:gen", ptr %t165, i32 0, i32 21
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s8, ptr %t167, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d285, i32 0, i32 1) })
  br label %bb28
bb27:
  br label %bb29
bb28:
  call void @__olang_scope_close(ptr %s8)
  br label %bb29
bb29:
  %t169 = load ptr, ptr %l0, !tbaa !29
  %t171 = getelementptr %"compiler/bindgen:gen", ptr %t169, i32 0, i32 21
  %t172 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t173 = load i64, ptr %l8, !tbaa !24
  %t174 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d286, i32 0, i32 1) }, 1
  %t175 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d286, i32 0, i32 1) }, 0
  %t177 = extractvalue { i64, ptr } %t172, 1
  %t178 = extractvalue { i64, ptr } %t172, 0
  %t179 = add i64 %t175, %t178
  %t180 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d287, i32 0, i32 1) }, 1
  %t181 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d287, i32 0, i32 1) }, 0
  %t182 = add i64 %t179, %t181
  %t184 = call i64 @__olang_fmt_i64(ptr null, i64 %t173)
  %t185 = add i64 %t182, %t184
  %t186 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t185)
  call void @olang_textcopy(ptr %t186, ptr %t174, i64 %t175)
  %t187 = getelementptr i8, ptr %t186, i64 %t175
  call void @olang_textcopy(ptr %t187, ptr %t177, i64 %t178)
  %t188 = getelementptr i8, ptr %t187, i64 %t178
  call void @olang_textcopy(ptr %t188, ptr %t180, i64 %t181)
  %t189 = getelementptr i8, ptr %t188, i64 %t181
  %t190 = call i64 @__olang_fmt_i64(ptr %t189, i64 %t173)
  %t191 = insertvalue { i64, ptr } undef, i64 %t185, 0
  %t192 = insertvalue { i64, ptr } %t191, ptr %t186, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s7, ptr %t171, { i64, ptr } %t192)
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s7)
  br label %bb31
bb31:
  %t196 = load i64, ptr %l6, !tbaa !24
  %t199 = add i64 %t196, 1
  store i64 %t199, ptr %l6, !tbaa !24
  br label %bb22
bb32:
  %t201 = load ptr, ptr %l0, !tbaa !29
  %t203 = getelementptr %"compiler/bindgen:gen", ptr %t201, i32 0, i32 21
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s0, ptr %t203, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d288, i32 0, i32 1) })
  br label %bb33
bb33:
  %t205 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t207 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t205, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d289, i32 0, i32 1) })
  store i1 %t207, ptr %l79
  br label %bb34
bb34:
  %t208 = load i1, ptr %l79, !tbaa !21
  %t209 = xor i1 %t208, true
  br i1 %t209, label %bb35, label %bb36
bb35:
  store %olang.scope zeroinitializer, ptr %s11
  %t211 = load ptr, ptr %l0, !tbaa !29
  %t213 = getelementptr %"compiler/bindgen:gen", ptr %t211, i32 0, i32 21
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s11, ptr %t213, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d290, i32 0, i32 1) })
  br label %bb37
bb36:
  br label %bb38
bb37:
  call void @__olang_scope_close(ptr %s11)
  br label %bb38
bb38:
  %t215 = load ptr, ptr %l0, !tbaa !29
  %t217 = getelementptr %"compiler/bindgen:gen", ptr %t215, i32 0, i32 21
  %t218 = load ptr, ptr %l1, !tbaa !29
  %t220 = getelementptr %"compiler/bindgen:cFunc", ptr %t218, i32 0, i32 0
  %t221 = load { i64, ptr }, ptr %t220, !tbaa !27
  %t223 = extractvalue { i64, ptr } %t221, 1
  %t224 = extractvalue { i64, ptr } %t221, 0
  %t225 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d291, i32 0, i32 1) }, 1
  %t226 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d291, i32 0, i32 1) }, 0
  %t227 = add i64 %t224, %t226
  %t228 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t227)
  call void @olang_textcopy(ptr %t228, ptr %t223, i64 %t224)
  %t229 = getelementptr i8, ptr %t228, i64 %t224
  call void @olang_textcopy(ptr %t229, ptr %t225, i64 %t226)
  %t230 = insertvalue { i64, ptr } undef, i64 %t227, 0
  %t231 = insertvalue { i64, ptr } %t230, ptr %t228, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s0, ptr %t217, { i64, ptr } %t231)
  br label %bb39
bb39:
  store i64 0, ptr %l10, !tbaa !24
  %t235 = load ptr, ptr %l1, !tbaa !29
  %t237 = getelementptr %"compiler/bindgen:cFunc", ptr %t235, i32 0, i32 3
  %t238 = load { i64, ptr }, ptr %t237, !tbaa !27
  %t240 = extractvalue { i64, ptr } %t238, 0
  store i64 %t240, ptr %l11, !tbaa !24
  store i64 1, ptr %l12, !tbaa !24
  %t242 = load i64, ptr %l11, !tbaa !24
  %t243 = load i64, ptr %l10, !tbaa !24
  %t246 = icmp sgt i64 %t242, %t243
  br i1 %t246, label %bb40, label %bb41
bb40:
  %t248 = load i64, ptr %l12, !tbaa !24
  %t250 = icmp sgt i64 %t248, 0
  br i1 %t250, label %bb42, label %bb43
bb41:
  store i64 0, ptr %l95, !tbaa !24
  br label %bb45
bb42:
  %t252 = load i64, ptr %l11, !tbaa !24
  %t253 = load i64, ptr %l10, !tbaa !24
  %t256 = sub i64 %t252, %t253
  %t257 = load i64, ptr %l12, !tbaa !24
  %t260 = add i64 %t256, %t257
  %t262 = sub i64 %t260, 1
  %t263 = load i64, ptr %l12, !tbaa !24
  %t266 = sdiv i64 %t262, %t263
  store i64 %t266, ptr %l98, !tbaa !24
  br label %bb44
bb43:
  store i64 0, ptr %l98, !tbaa !24
  br label %bb44
bb44:
  %t268 = load i64, ptr %l98, !tbaa !24
  store i64 %t268, ptr %l95, !tbaa !24
  br label %bb45
bb45:
  %t269 = load i64, ptr %l95, !tbaa !24
  store i64 %t269, ptr %l13, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  br label %bb46
bb46:
  store %olang.scope zeroinitializer, ptr %s14
  %t270 = load i64, ptr %l14, !tbaa !24
  %t271 = load i64, ptr %l13, !tbaa !24
  %t274 = icmp slt i64 %t270, %t271
  %t276 = xor i1 %t274, true
  br i1 %t276, label %bb47, label %bb48
bb47:
  call void @__olang_scope_close(ptr %s14)
  br label %bb56
bb48:
  br label %bb49
bb49:
  %t278 = load i64, ptr %l10, !tbaa !24
  %t279 = load i64, ptr %l14, !tbaa !24
  %t280 = load i64, ptr %l12, !tbaa !24
  %t283 = mul i64 %t279, %t280
  %t286 = add i64 %t278, %t283
  store i64 %t286, ptr %l15, !tbaa !24
  %t288 = load i64, ptr %l15, !tbaa !24
  %t290 = icmp sgt i64 %t288, 0
  br i1 %t290, label %bb50, label %bb51
bb50:
  store %olang.scope zeroinitializer, ptr %s15
  %t292 = load ptr, ptr %l0, !tbaa !29
  %t294 = getelementptr %"compiler/bindgen:gen", ptr %t292, i32 0, i32 21
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s15, ptr %t294, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d292, i32 0, i32 1) })
  br label %bb52
bb51:
  br label %bb53
bb52:
  call void @__olang_scope_close(ptr %s15)
  br label %bb53
bb53:
  %t296 = load ptr, ptr %l0, !tbaa !29
  %t298 = getelementptr %"compiler/bindgen:gen", ptr %t296, i32 0, i32 21
  %t299 = load i64, ptr %l15, !tbaa !24
  %t300 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d293, i32 0, i32 1) }, 1
  %t301 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d293, i32 0, i32 1) }, 0
  %t303 = call i64 @__olang_fmt_i64(ptr null, i64 %t299)
  %t304 = add i64 %t301, %t303
  %t305 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t304)
  call void @olang_textcopy(ptr %t305, ptr %t300, i64 %t301)
  %t306 = getelementptr i8, ptr %t305, i64 %t301
  %t307 = call i64 @__olang_fmt_i64(ptr %t306, i64 %t299)
  %t308 = insertvalue { i64, ptr } undef, i64 %t304, 0
  %t309 = insertvalue { i64, ptr } %t308, ptr %t305, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s14, ptr %t298, { i64, ptr } %t309)
  br label %bb54
bb54:
  call void @__olang_scope_close(ptr %s14)
  br label %bb55
bb55:
  %t313 = load i64, ptr %l14, !tbaa !24
  %t316 = add i64 %t313, 1
  store i64 %t316, ptr %l14, !tbaa !24
  br label %bb46
bb56:
  %t318 = load ptr, ptr %l0, !tbaa !29
  %t320 = getelementptr %"compiler/bindgen:gen", ptr %t318, i32 0, i32 21
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s0, ptr %t320, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d294, i32 0, i32 1) })
  br label %bb57
bb57:
  %t322 = load { i64, ptr }, ptr %l4, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t324 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t322, 1
  store { i32, { i64, ptr } } %t324, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ewrite(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca %"compiler/bindgen:cFunc"
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca %"compiler/bindgen:cFunc"
  %l9 = alloca i64
  %l10 = alloca %"compiler/bindgen:ctype"
  %l12 = alloca i1
  %l14 = alloca %"std/prelude/text:StringBuilder"
  %l15 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l16 = alloca ptr
  %l17 = alloca i64
  %lp18 = alloca ptr
  %l20 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l22 = alloca %"std/prelude/text:StringBuilder"
  %l23 = alloca ptr
  %l24 = alloca i64
  %l26 = alloca %"std/prelude/text:StringBuilder"
  %l27 = alloca %"std/prelude/text:StringBuilder"
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca ptr
  %l35 = alloca i64
  %l37 = alloca ptr
  %l38 = alloca i64
  %l40 = alloca ptr
  %l41 = alloca i64
  %l45 = alloca i64
  %l47 = alloca i64
  %l52 = alloca %"compiler/bindgen:cFunc"
  %l61 = alloca i64
  %l63 = alloca i64
  %l68 = alloca %"compiler/bindgen:cFunc"
  %l70 = alloca { i64, ptr }
  %l71 = alloca i64
  %l72 = alloca { i64, ptr }
  %l75 = alloca i64
  %l79 = alloca %"compiler/bindgen:ctype"
  %l84 = alloca ptr
  %l88 = alloca %"compiler/bindgen:ctype"
  %l90 = alloca %"compiler/bindgen:ctype"
  %l93 = alloca i1
  %l97 = alloca %"compiler/bindgen:ctype"
  %l100 = alloca ptr
  %l104 = alloca %"compiler/bindgen:ctype"
  %l106 = alloca i64
  %l110 = alloca ptr
  %l117 = alloca %"std/prelude/text:StringBuilder"
  %l118 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l121 = alloca i64
  %l123 = alloca i64
  %l128 = alloca %"compiler/bindgen:cFunc"
  %l132 = alloca i1
  %l136 = alloca i1
  %l142 = alloca ptr
  %l143 = alloca i64
  %l149 = alloca i1
  %l151 = alloca ptr
  %l152 = alloca i64
  %l158 = alloca i1
  %l163 = alloca ptr
  %l164 = alloca i64
  %l170 = alloca i1
  %l174 = alloca i1
  %l176 = alloca ptr
  %l177 = alloca i64
  %l182 = alloca { i64, ptr }
  %l185 = alloca { i64, ptr }
  %l186 = alloca i32
  %l188 = alloca i1
  %l190 = alloca ptr
  %l191 = alloca i64
  %l200 = alloca i1
  %l202 = alloca i1
  %l204 = alloca i1
  %l208 = alloca { i64, ptr }
  %l211 = alloca { i64, ptr }
  %l212 = alloca i32
  %l214 = alloca i1
  %l216 = alloca ptr
  %l217 = alloca i64
  %l226 = alloca ptr
  %l227 = alloca i64
  %l241 = alloca %"std/prelude/text:StringBuilder"
  %l246 = alloca i64
  %l248 = alloca i64
  %l253 = alloca { i64, ptr }
  %l261 = alloca %"std/prelude/text:StringBuilder"
  %l262 = alloca %"std/prelude/text:StringBuilder"
  %l265 = alloca i64
  %l269 = alloca i64
  %l272 = alloca i64
  %l293 = alloca ptr
  %l296 = alloca i1
  %l297 = alloca i1
  %l300 = alloca i1
  %l304 = alloca i1
  %l305 = alloca ptr
  %l308 = alloca { i64, ptr }
  %l311 = alloca ptr
  %l315 = alloca ptr
  %l324 = alloca i64
  %l326 = alloca i1
  %l328 = alloca i64
  %l330 = alloca ptr
  %l332 = alloca { i64, ptr }
  %l334 = alloca { i64, ptr }
  %l337 = alloca ptr
  %l339 = alloca { i64, ptr }
  %l343 = alloca i64
  %l348 = alloca i64
  %l350 = alloca i64
  %l355 = alloca { i64, ptr }
  %l365 = alloca i64
  %l370 = alloca i64
  %l372 = alloca i64
  %l377 = alloca { i64, ptr }
  %l387 = alloca i64
  %l392 = alloca i64
  %l394 = alloca i64
  %l399 = alloca { i64, ptr }
  %l408 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %s31 = alloca %olang.scope
  %s35 = alloca %olang.scope
  %s37 = alloca %olang.scope
  %s39 = alloca %olang.scope
  %s42 = alloca %olang.scope
  %s44 = alloca %olang.scope
  %s46 = alloca %olang.scope
  %s49 = alloca %olang.scope
  %s51 = alloca %olang.scope
  %s54 = alloca %olang.scope
  %s56 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/bindgen:gen", ptr %t1, i32 0, i32 9
  store ptr %t3, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  %t5 = load i64, ptr %l3, !tbaa !24
  store i64 %t5, ptr %l45, !tbaa !24
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t8 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3acFunc_3e_2eLen_3ccompiler_2fbindgen_3acFunc_3e(ptr %v0, ptr %t6)
  store i64 %t8, ptr %l47
  br label %bb2
bb2:
  %t9 = load i64, ptr %l45, !tbaa !24
  %t10 = load i64, ptr %l47, !tbaa !24
  %t11 = icmp slt i64 %t9, %t10
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb3, label %bb4
bb3:
  br label %bb9
bb4:
  br label %bb5
bb5:
  %t15 = load ptr, ptr %l2, !tbaa !29
  %t16 = load i64, ptr %l3, !tbaa !24
  %t19 = call %"compiler/bindgen:cFunc" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3acFunc_3e_2eAt_3ccompiler_2fbindgen_3acFunc_3e(ptr %v0, ptr %v0, ptr %t15, i64 %t16)
  store %"compiler/bindgen:cFunc" %t19, ptr %l52
  br label %bb6
bb6:
  %t20 = load %"compiler/bindgen:cFunc", ptr %l52
  store %"compiler/bindgen:cFunc" %t20, ptr %l4
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/bindgen:gen", ptr %t21, i32 0, i32 22
  %t24 = getelementptr %"compiler/bindgen:cFunc", ptr %l4, i32 0, i32 0
  %t25 = load { i64, ptr }, ptr %t24, !tbaa !27
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha091d021a90ce6aa48813730c00df6d2(ptr %v0, ptr %v0, ptr %t23, { i64, ptr } %t25, i64 0)
  br label %bb7
bb7:
  br label %bb8
bb8:
  %t28 = load i64, ptr %l3, !tbaa !24
  %t31 = add i64 %t28, 1
  store i64 %t31, ptr %l3, !tbaa !24
  br label %bb1
bb9:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/bindgen:gen", ptr %t33, i32 0, i32 9
  store ptr %t35, ptr %l5, !tbaa !29
  store i64 0, ptr %l6, !tbaa !24
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s5
  %t37 = load i64, ptr %l6, !tbaa !24
  store i64 %t37, ptr %l61, !tbaa !24
  %t38 = load ptr, ptr %l5, !tbaa !29
  %t40 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3acFunc_3e_2eLen_3ccompiler_2fbindgen_3acFunc_3e(ptr %v0, ptr %t38)
  store i64 %t40, ptr %l63
  br label %bb11
bb11:
  %t41 = load i64, ptr %l61, !tbaa !24
  %t42 = load i64, ptr %l63, !tbaa !24
  %t43 = icmp slt i64 %t41, %t42
  %t45 = xor i1 %t43, true
  br i1 %t45, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s5)
  br label %bb35
bb13:
  br label %bb14
bb14:
  %t47 = load ptr, ptr %l5, !tbaa !29
  %t48 = load i64, ptr %l6, !tbaa !24
  %t51 = call %"compiler/bindgen:cFunc" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3acFunc_3e_2eAt_3ccompiler_2fbindgen_3acFunc_3e(ptr %v0, ptr %v0, ptr %t47, i64 %t48)
  store %"compiler/bindgen:cFunc" %t51, ptr %l68
  br label %bb15
bb15:
  %t52 = load %"compiler/bindgen:cFunc", ptr %l68
  store %"compiler/bindgen:cFunc" %t52, ptr %l7
  %t53 = getelementptr %"compiler/bindgen:cFunc", ptr %l7, i32 0, i32 1
  %t54 = load { i64, ptr }, ptr %t53, !tbaa !27
  %t56 = call { i64, ptr } @compiler_2fbindgen_2enoReturnOf(ptr %v0, ptr %s5, { i64, ptr } %t54)
  store { i64, ptr } %t56, ptr %l70
  br label %bb16
bb16:
  %t57 = load { i64, ptr }, ptr %l70, !tbaa !27
  %t58 = extractvalue { i64, ptr } %t57, 0
  store i64 %t58, ptr %l71, !tbaa !24
  %t59 = load i64, ptr %l71, !tbaa !24
  %t60 = mul i64 %t59, 1
  %t61 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t60)
  %t62 = insertvalue { i64, ptr } undef, i64 %t59, 0
  %t63 = insertvalue { i64, ptr } %t62, ptr %t61, 1
  store { i64, ptr } %t63, ptr %l72, !tbaa !27
  %t64 = getelementptr { i64, ptr }, ptr %l72, i32 0, i32 1
  %t65 = load ptr, ptr %t64, !tbaa !27
  %t66 = getelementptr { i64, ptr }, ptr %l70, i32 0, i32 1
  %t67 = load ptr, ptr %t66, !tbaa !27
  %t68 = load i64, ptr %l71, !tbaa !24
  %t69 = mul i64 %t68, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t65, ptr %t67, i64 %t69, i1 false)
  %t70 = load { i64, ptr }, ptr %l72, !tbaa !27
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t75 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eparseType(ptr %v0, ptr %s5, ptr %t71, { i64, ptr } %t70, i64 0)
  store i64 %t75, ptr %l75
  br label %bb17
bb17:
  %t76 = load i64, ptr %l75, !tbaa !24
  store i64 %t76, ptr %l9, !tbaa !24
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/bindgen:gen", ptr %t77, i32 0, i32 17
  %t80 = load i64, ptr %l9, !tbaa !24
  %t83 = call %"compiler/bindgen:ctype" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3actype_3e_2eAt_3ccompiler_2fbindgen_3actype_3e(ptr %v0, ptr %s5, ptr %t79, i64 %t80)
  store %"compiler/bindgen:ctype" %t83, ptr %l79
  br label %bb18
bb18:
  %t84 = getelementptr %"compiler/bindgen:ctype", ptr %l79, i32 0, i32 0
  %t85 = load i32, ptr %t84, !range !{i32 0, i32 7}
  %t87 = trunc i64 5 to i32
  %t88 = icmp eq i32 %t85, %t87
  %t90 = xor i1 %t88, true
  br i1 %t90, label %bb19, label %bb20
bb19:
  call void @__olang_scope_close(ptr %s5)
  br label %bb34
bb20:
  br label %bb21
bb21:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"compiler/bindgen:gen", ptr %t92, i32 0, i32 17
  store ptr %t94, ptr %l84, !tbaa !29
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t97 = getelementptr %"compiler/bindgen:gen", ptr %t95, i32 0, i32 17
  %t98 = load i64, ptr %l9, !tbaa !24
  %t101 = call %"compiler/bindgen:ctype" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3actype_3e_2eAt_3ccompiler_2fbindgen_3actype_3e(ptr %v0, ptr %s5, ptr %t97, i64 %t98)
  store %"compiler/bindgen:ctype" %t101, ptr %l88
  br label %bb22
bb22:
  %t102 = getelementptr %"compiler/bindgen:ctype", ptr %l88, i32 0, i32 2
  %t103 = load i64, ptr %t102, !tbaa !24
  %t104 = load ptr, ptr %l84, !tbaa !29
  %t106 = call %"compiler/bindgen:ctype" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3actype_3e_2eAt_3ccompiler_2fbindgen_3actype_3e(ptr %v0, ptr %v0, ptr %t104, i64 %t103)
  store %"compiler/bindgen:ctype" %t106, ptr %l90
  br label %bb23
bb23:
  %t107 = load %"compiler/bindgen:ctype", ptr %l90
  store %"compiler/bindgen:ctype" %t107, ptr %l10
  %t108 = getelementptr %"compiler/bindgen:ctype", ptr %l10, i32 0, i32 0
  %t109 = load i32, ptr %t108, !range !{i32 0, i32 7}
  %t111 = trunc i64 3 to i32
  %t112 = icmp eq i32 %t109, %t111
  br i1 %t112, label %bb24, label %bb25
bb24:
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t116 = getelementptr %"compiler/bindgen:gen", ptr %t114, i32 0, i32 17
  %t117 = getelementptr %"compiler/bindgen:ctype", ptr %l10, i32 0, i32 2
  %t118 = load i64, ptr %t117, !tbaa !24
  %t121 = call %"compiler/bindgen:ctype" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3actype_3e_2eAt_3ccompiler_2fbindgen_3actype_3e(ptr %v0, ptr %s5, ptr %t116, i64 %t118)
  store %"compiler/bindgen:ctype" %t121, ptr %l97
  br label %bb26
bb25:
  store i1 false, ptr %l93, !tbaa !21
  br label %bb27
bb26:
  %t122 = getelementptr %"compiler/bindgen:ctype", ptr %l97, i32 0, i32 0
  %t123 = load i32, ptr %t122, !range !{i32 0, i32 7}
  %t125 = trunc i64 2 to i32
  %t126 = icmp eq i32 %t123, %t125
  store i1 %t126, ptr %l93, !tbaa !21
  br label %bb27
bb27:
  %t128 = load i1, ptr %l93, !tbaa !21
  br i1 %t128, label %bb28, label %bb29
bb28:
  %t129 = load ptr, ptr %l0, !tbaa !29
  store ptr %t129, ptr %l100, !tbaa !29
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t132 = getelementptr %"compiler/bindgen:gen", ptr %t130, i32 0, i32 17
  %t133 = getelementptr %"compiler/bindgen:ctype", ptr %l10, i32 0, i32 2
  %t134 = load i64, ptr %t133, !tbaa !24
  %t137 = call %"compiler/bindgen:ctype" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3actype_3e_2eAt_3ccompiler_2fbindgen_3actype_3e(ptr %v0, ptr %v0, ptr %t132, i64 %t134)
  store %"compiler/bindgen:ctype" %t137, ptr %l104
  br label %bb30
bb29:
  br label %bb33
bb30:
  %t138 = getelementptr %"compiler/bindgen:ctype", ptr %l104, i32 0, i32 1
  %t139 = load { i64, ptr }, ptr %t138, !tbaa !27
  %t140 = load ptr, ptr %l100, !tbaa !29
  %t142 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2erecordAt(ptr %v0, ptr %v0, ptr %t140, { i64, ptr } %t139)
  store i64 %t142, ptr %l106
  br label %bb31
bb31:
  %t143 = load i64, ptr %l106, !tbaa !24
  store i1 true, ptr %l12, !tbaa !21
  %t144 = load ptr, ptr %l0, !tbaa !29
  %t146 = getelementptr %"compiler/bindgen:gen", ptr %t144, i32 0, i32 6
  %t150 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eRefMu_Hc21bcd245b67ffb6ee3e145838fcf2cf(ptr %v0, ptr %v0, ptr %t146, i64 %t143)
  store ptr %t150, ptr %l110
  br label %bb32
bb32:
  %t151 = load ptr, ptr %l110, !tbaa !29
  %t153 = load i1, ptr %l12, !tbaa !21
  %t156 = getelementptr %"compiler/bindgen:record", ptr %t151, i32 0, i32 10
  store i1 %t153, ptr %t156, !tbaa !21
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s5)
  br label %bb34
bb34:
  %t157 = load i64, ptr %l6, !tbaa !24
  %t160 = add i64 %t157, 1
  store i64 %t160, ptr %l6, !tbaa !24
  br label %bb10
bb35:
  %t162 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2enameRecords(ptr %v0, ptr %t162)
  br label %bb36
bb36:
  %t164 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t164, ptr %l117
  br label %bb37
bb37:
  %t165 = load %"std/prelude/text:StringBuilder", ptr %l117
  store %"std/prelude/text:StringBuilder" %t165, ptr %l14
  %t166 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e_2ector(ptr %s0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t166, ptr %l118
  br label %bb38
bb38:
  %t167 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l118
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t167, ptr %l15
  %t168 = load ptr, ptr %l0, !tbaa !29
  %t170 = getelementptr %"compiler/bindgen:gen", ptr %t168, i32 0, i32 9
  store ptr %t170, ptr %l16, !tbaa !29
  store i64 0, ptr %l17, !tbaa !24
  br label %bb39
bb39:
  store %olang.scope zeroinitializer, ptr %s10
  %t172 = load i64, ptr %l17, !tbaa !24
  store i64 %t172, ptr %l121, !tbaa !24
  %t173 = load ptr, ptr %l16, !tbaa !29
  %t175 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3acFunc_3e_2eLen_3ccompiler_2fbindgen_3acFunc_3e(ptr %v0, ptr %t173)
  store i64 %t175, ptr %l123
  br label %bb40
bb40:
  %t176 = load i64, ptr %l121, !tbaa !24
  %t177 = load i64, ptr %l123, !tbaa !24
  %t178 = icmp slt i64 %t176, %t177
  %t180 = xor i1 %t178, true
  br i1 %t180, label %bb41, label %bb42
bb41:
  call void @__olang_scope_close(ptr %s10)
  br label %bb118
bb42:
  br label %bb43
bb43:
  %t182 = load ptr, ptr %l16, !tbaa !29
  %t183 = load i64, ptr %l17, !tbaa !24
  %t186 = call %"compiler/bindgen:cFunc" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3acFunc_3e_2eAt_3ccompiler_2fbindgen_3acFunc_3e(ptr %v0, ptr %v0, ptr %t182, i64 %t183)
  store %"compiler/bindgen:cFunc" %t186, ptr %l128
  br label %bb44
bb44:
  %t187 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 88, i64 8)
  store ptr %t187, ptr %lp18
  %t188 = load %"compiler/bindgen:cFunc", ptr %l128
  %t189 = load ptr, ptr %lp18
  store %"compiler/bindgen:cFunc" %t188, ptr %t189
  %t190 = load ptr, ptr %lp18
  %t191 = getelementptr %"compiler/bindgen:cFunc", ptr %t190, i32 0, i32 0
  %t192 = load { i64, ptr }, ptr %t191, !tbaa !27
  %t197 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9b83f66eba65594537030636cb0b52b7(ptr %s0, ptr %v0, ptr %l15, { i64, ptr } %t192)
  store i1 %t197, ptr %l132
  br label %bb45
bb45:
  %t198 = load i1, ptr %l132, !tbaa !21
  br i1 %t198, label %bb46, label %bb47
bb46:
  call void @__olang_scope_close(ptr %s10)
  br label %bb117
bb47:
  br label %bb48
bb48:
  %t199 = load ptr, ptr %lp18
  %t200 = getelementptr %"compiler/bindgen:cFunc", ptr %t199, i32 0, i32 0
  %t201 = load { i64, ptr }, ptr %t200, !tbaa !27
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha091d021a90ce6aa48813730c00df6d2(ptr %s0, ptr %v0, ptr %l15, { i64, ptr } %t201, i64 0)
  br label %bb49
bb49:
  %t204 = load ptr, ptr %lp18
  %t205 = getelementptr %"compiler/bindgen:cFunc", ptr %t204, i32 0, i32 0
  %t206 = load { i64, ptr }, ptr %t205, !tbaa !27
  %t208 = call i1 @compiler_2fbindgen_2eusable(ptr %v0, { i64, ptr } %t206)
  store i1 %t208, ptr %l136
  br label %bb50
bb50:
  %t209 = load i1, ptr %l136, !tbaa !21
  %t210 = xor i1 %t209, true
  br i1 %t210, label %bb51, label %bb52
bb51:
  %t212 = load ptr, ptr %l0, !tbaa !29
  %t214 = getelementptr %"compiler/bindgen:gen", ptr %t212, i32 0, i32 1
  %t215 = load i1, ptr %t214, !tbaa !21
  %t217 = xor i1 %t215, true
  br i1 %t217, label %bb53, label %bb54
bb52:
  br label %bb59
bb53:
  %t219 = load ptr, ptr %l0, !tbaa !29
  %t221 = getelementptr %"compiler/bindgen:gen", ptr %t219, i32 0, i32 19
  store ptr %t221, ptr %l142, !tbaa !29
  %t222 = call ptr @__olang_scope_hold(ptr %v0)
  %t223 = ptrtoint ptr %t222 to i64
  store i64 %t223, ptr %l143, !tbaa !24
  %t224 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t224, label %bb55, label %bb56
bb54:
  br label %bb58
bb55:
  %t226 = call ptr @__olang_region_make(ptr %v0)
  %t227 = ptrtoint ptr %t226 to i64
  store i64 %t227, ptr %l143, !tbaa !24
  br label %bb56
bb56:
  %t228 = load ptr, ptr %lp18
  %t229 = getelementptr %"compiler/bindgen:cFunc", ptr %t228, i32 0, i32 0
  %t230 = load { i64, ptr }, ptr %t229, !tbaa !27
  %t232 = extractvalue { i64, ptr } %t230, 1
  %t233 = extractvalue { i64, ptr } %t230, 0
  %t234 = extractvalue { i64, ptr } { i64 64, ptr getelementptr inbounds (<{ i64, [64 x i8] }>, ptr @.d295, i32 0, i32 1) }, 1
  %t235 = extractvalue { i64, ptr } { i64 64, ptr getelementptr inbounds (<{ i64, [64 x i8] }>, ptr @.d295, i32 0, i32 1) }, 0
  %t236 = add i64 %t233, %t235
  %t237 = load i64, ptr %l143
  %t238 = inttoptr i64 %t237 to ptr
  %t239 = call ptr @__olang_held_alloc(ptr %t238, i64 %t236)
  call void @olang_textcopy(ptr %t239, ptr %t232, i64 %t233)
  %t240 = getelementptr i8, ptr %t239, i64 %t233
  call void @olang_textcopy(ptr %t240, ptr %t234, i64 %t235)
  %t241 = insertvalue { i64, ptr } undef, i64 %t236, 0
  %t242 = insertvalue { i64, ptr } %t241, ptr %t239, 1
  %t244 = load ptr, ptr %l142, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v0, ptr %t244, { i64, ptr } %t242)
  br label %bb57
bb57:
  br label %bb58
bb58:
  call void @__olang_scope_close(ptr %s10)
  br label %bb117
bb59:
  %t246 = load ptr, ptr %lp18
  %t247 = getelementptr %"compiler/bindgen:cFunc", ptr %t246, i32 0, i32 0
  %t248 = load { i64, ptr }, ptr %t247, !tbaa !27
  %t250 = call i1 @compiler_2fbindgen_2epreludeName(ptr %v0, { i64, ptr } %t248)
  store i1 %t250, ptr %l149
  br label %bb60
bb60:
  %t251 = load i1, ptr %l149, !tbaa !21
  br i1 %t251, label %bb61, label %bb62
bb61:
  %t252 = load ptr, ptr %l0, !tbaa !29
  %t254 = getelementptr %"compiler/bindgen:gen", ptr %t252, i32 0, i32 19
  store ptr %t254, ptr %l151, !tbaa !29
  %t255 = call ptr @__olang_scope_hold(ptr %v0)
  %t256 = ptrtoint ptr %t255 to i64
  store i64 %t256, ptr %l152, !tbaa !24
  %t257 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t257, label %bb63, label %bb64
bb62:
  br label %bb66
bb63:
  %t259 = call ptr @__olang_region_make(ptr %v0)
  %t260 = ptrtoint ptr %t259 to i64
  store i64 %t260, ptr %l152, !tbaa !24
  br label %bb64
bb64:
  %t261 = load ptr, ptr %lp18
  %t262 = getelementptr %"compiler/bindgen:cFunc", ptr %t261, i32 0, i32 0
  %t263 = load { i64, ptr }, ptr %t262, !tbaa !27
  %t265 = extractvalue { i64, ptr } %t263, 1
  %t266 = extractvalue { i64, ptr } %t263, 0
  %t267 = extractvalue { i64, ptr } { i64 39, ptr getelementptr inbounds (<{ i64, [39 x i8] }>, ptr @.d296, i32 0, i32 1) }, 1
  %t268 = extractvalue { i64, ptr } { i64 39, ptr getelementptr inbounds (<{ i64, [39 x i8] }>, ptr @.d296, i32 0, i32 1) }, 0
  %t269 = add i64 %t266, %t268
  %t270 = load i64, ptr %l152
  %t271 = inttoptr i64 %t270 to ptr
  %t272 = call ptr @__olang_held_alloc(ptr %t271, i64 %t269)
  call void @olang_textcopy(ptr %t272, ptr %t265, i64 %t266)
  %t273 = getelementptr i8, ptr %t272, i64 %t266
  call void @olang_textcopy(ptr %t273, ptr %t267, i64 %t268)
  %t274 = insertvalue { i64, ptr } undef, i64 %t269, 0
  %t275 = insertvalue { i64, ptr } %t274, ptr %t272, 1
  %t277 = load ptr, ptr %l151, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v0, ptr %t277, { i64, ptr } %t275)
  br label %bb65
bb65:
  call void @__olang_scope_close(ptr %s10)
  br label %bb117
bb66:
  %t279 = load ptr, ptr %lp18
  %t280 = getelementptr %"compiler/bindgen:cFunc", ptr %t279, i32 0, i32 4
  %t281 = load i1, ptr %t280, !tbaa !21
  br i1 %t281, label %bb67, label %bb68
bb67:
  %t283 = load ptr, ptr %l0, !tbaa !29
  %t285 = getelementptr %"compiler/bindgen:gen", ptr %t283, i32 0, i32 1
  %t286 = load i1, ptr %t285, !tbaa !21
  %t288 = xor i1 %t286, true
  store i1 %t288, ptr %l158, !tbaa !21
  br label %bb69
bb68:
  store i1 false, ptr %l158, !tbaa !21
  br label %bb69
bb69:
  %t290 = load i1, ptr %l158, !tbaa !21
  br i1 %t290, label %bb70, label %bb71
bb70:
  %t291 = load ptr, ptr %l0, !tbaa !29
  %t293 = getelementptr %"compiler/bindgen:gen", ptr %t291, i32 0, i32 19
  store ptr %t293, ptr %l163, !tbaa !29
  %t294 = call ptr @__olang_scope_hold(ptr %v0)
  %t295 = ptrtoint ptr %t294 to i64
  store i64 %t295, ptr %l164, !tbaa !24
  %t296 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t296, label %bb72, label %bb73
bb71:
  br label %bb75
bb72:
  %t298 = call ptr @__olang_region_make(ptr %v0)
  %t299 = ptrtoint ptr %t298 to i64
  store i64 %t299, ptr %l164, !tbaa !24
  br label %bb73
bb73:
  %t300 = load ptr, ptr %lp18
  %t301 = getelementptr %"compiler/bindgen:cFunc", ptr %t300, i32 0, i32 0
  %t302 = load { i64, ptr }, ptr %t301, !tbaa !27
  %t304 = extractvalue { i64, ptr } %t302, 1
  %t305 = extractvalue { i64, ptr } %t302, 0
  %t306 = extractvalue { i64, ptr } { i64 52, ptr getelementptr inbounds (<{ i64, [52 x i8] }>, ptr @.d297, i32 0, i32 1) }, 1
  %t307 = extractvalue { i64, ptr } { i64 52, ptr getelementptr inbounds (<{ i64, [52 x i8] }>, ptr @.d297, i32 0, i32 1) }, 0
  %t308 = add i64 %t305, %t307
  %t309 = load i64, ptr %l164
  %t310 = inttoptr i64 %t309 to ptr
  %t311 = call ptr @__olang_held_alloc(ptr %t310, i64 %t308)
  call void @olang_textcopy(ptr %t311, ptr %t304, i64 %t305)
  %t312 = getelementptr i8, ptr %t311, i64 %t305
  call void @olang_textcopy(ptr %t312, ptr %t306, i64 %t307)
  %t313 = insertvalue { i64, ptr } undef, i64 %t308, 0
  %t314 = insertvalue { i64, ptr } %t313, ptr %t311, 1
  %t316 = load ptr, ptr %l163, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v0, ptr %t316, { i64, ptr } %t314)
  br label %bb74
bb74:
  call void @__olang_scope_close(ptr %s10)
  br label %bb117
bb75:
  %t318 = load ptr, ptr %lp18
  %t319 = getelementptr %"compiler/bindgen:cFunc", ptr %t318, i32 0, i32 4
  %t320 = load i1, ptr %t319, !tbaa !21
  br i1 %t320, label %bb76, label %bb77
bb76:
  %t322 = load ptr, ptr %l0, !tbaa !29
  %t324 = getelementptr %"compiler/bindgen:gen", ptr %t322, i32 0, i32 25
  %t325 = load ptr, ptr %lp18
  %t326 = getelementptr %"compiler/bindgen:cFunc", ptr %t325, i32 0, i32 0
  %t327 = load { i64, ptr }, ptr %t326, !tbaa !27
  %t330 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9b83f66eba65594537030636cb0b52b7(ptr %v0, ptr %v0, ptr %t324, { i64, ptr } %t327)
  store i1 %t330, ptr %l174
  br label %bb78
bb77:
  store i1 false, ptr %l170, !tbaa !21
  br label %bb79
bb78:
  %t331 = load i1, ptr %l174, !tbaa !21
  store i1 %t331, ptr %l170, !tbaa !21
  br label %bb79
bb79:
  %t332 = load i1, ptr %l170, !tbaa !21
  br i1 %t332, label %bb80, label %bb81
bb80:
  %t333 = load ptr, ptr %l0, !tbaa !29
  %t335 = getelementptr %"compiler/bindgen:gen", ptr %t333, i32 0, i32 19
  store ptr %t335, ptr %l176, !tbaa !29
  %t336 = call ptr @__olang_scope_hold(ptr %v0)
  %t337 = ptrtoint ptr %t336 to i64
  store i64 %t337, ptr %l177, !tbaa !24
  %t338 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t338, label %bb82, label %bb83
bb81:
  br label %bb85
bb82:
  %t340 = call ptr @__olang_region_make(ptr %v0)
  %t341 = ptrtoint ptr %t340 to i64
  store i64 %t341, ptr %l177, !tbaa !24
  br label %bb83
bb83:
  %t342 = load ptr, ptr %lp18
  %t343 = getelementptr %"compiler/bindgen:cFunc", ptr %t342, i32 0, i32 0
  %t344 = load { i64, ptr }, ptr %t343, !tbaa !27
  %t346 = extractvalue { i64, ptr } %t344, 1
  %t347 = extractvalue { i64, ptr } %t344, 0
  %t348 = extractvalue { i64, ptr } { i64 43, ptr getelementptr inbounds (<{ i64, [43 x i8] }>, ptr @.d298, i32 0, i32 1) }, 1
  %t349 = extractvalue { i64, ptr } { i64 43, ptr getelementptr inbounds (<{ i64, [43 x i8] }>, ptr @.d298, i32 0, i32 1) }, 0
  %t350 = add i64 %t347, %t349
  %t351 = load i64, ptr %l177
  %t352 = inttoptr i64 %t351 to ptr
  %t353 = call ptr @__olang_held_alloc(ptr %t352, i64 %t350)
  call void @olang_textcopy(ptr %t353, ptr %t346, i64 %t347)
  %t354 = getelementptr i8, ptr %t353, i64 %t347
  call void @olang_textcopy(ptr %t354, ptr %t348, i64 %t349)
  %t355 = insertvalue { i64, ptr } undef, i64 %t350, 0
  %t356 = insertvalue { i64, ptr } %t355, ptr %t353, 1
  %t358 = load ptr, ptr %l176, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v0, ptr %t358, { i64, ptr } %t356)
  br label %bb84
bb84:
  call void @__olang_scope_close(ptr %s10)
  br label %bb117
bb85:
  %t360 = load ptr, ptr %l0, !tbaa !29
  %t361 = load ptr, ptr %lp18
  %t364 = call { i32, { i64, ptr } } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2efunction(ptr %v0, ptr %v0, ptr %s10, ptr %t360, ptr %t361)
  %t365 = extractvalue { i32, { i64, ptr } } %t364, 1
  %t366 = extractvalue { i32, { i64, ptr } } %t364, 0
  store i32 %t366, ptr %l186
  %t367 = icmp ne i32 %t366, 0
  br i1 %t367, label %bb87, label %ok.368, !prof !99
ok.368:
  store { i64, ptr } %t365, ptr %l185
  br label %bb86
bb86:
  %t369 = load { i64, ptr }, ptr %l185, !tbaa !27
  store { i64, ptr } %t369, ptr %l182, !tbaa !27
  br label %bb92
bb87:
  %t370 = load i32, ptr %l186, !tbaa !23
  %t371 = ashr i32 %t370, 16
  %t373 = icmp eq i32 %t371, 1
  store i1 %t373, ptr %l188, !tbaa !21
  br label %bb88
bb88:
  %t374 = load ptr, ptr %l0, !tbaa !29
  %t376 = getelementptr %"compiler/bindgen:gen", ptr %t374, i32 0, i32 19
  store ptr %t376, ptr %l190, !tbaa !29
  %t377 = call ptr @__olang_scope_hold(ptr %v0)
  %t378 = ptrtoint ptr %t377 to i64
  store i64 %t378, ptr %l191, !tbaa !24
  %t379 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t379, label %bb89, label %bb90
bb89:
  %t381 = call ptr @__olang_region_make(ptr %v0)
  %t382 = ptrtoint ptr %t381 to i64
  store i64 %t382, ptr %l191, !tbaa !24
  br label %bb90
bb90:
  %t383 = load ptr, ptr %lp18
  %t384 = getelementptr %"compiler/bindgen:cFunc", ptr %t383, i32 0, i32 0
  %t385 = load { i64, ptr }, ptr %t384, !tbaa !27
  %t386 = load ptr, ptr %l0, !tbaa !29
  %t388 = getelementptr %"compiler/bindgen:gen", ptr %t386, i32 0, i32 26
  %t389 = load { i64, ptr }, ptr %t388, !tbaa !27
  %t391 = extractvalue { i64, ptr } %t385, 1
  %t392 = extractvalue { i64, ptr } %t385, 0
  %t393 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d299, i32 0, i32 1) }, 1
  %t394 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d299, i32 0, i32 1) }, 0
  %t395 = add i64 %t392, %t394
  %t397 = extractvalue { i64, ptr } %t389, 1
  %t398 = extractvalue { i64, ptr } %t389, 0
  %t399 = add i64 %t395, %t398
  %t400 = load i64, ptr %l191
  %t401 = inttoptr i64 %t400 to ptr
  %t402 = call ptr @__olang_held_alloc(ptr %t401, i64 %t399)
  call void @olang_textcopy(ptr %t402, ptr %t391, i64 %t392)
  %t403 = getelementptr i8, ptr %t402, i64 %t392
  call void @olang_textcopy(ptr %t403, ptr %t393, i64 %t394)
  %t404 = getelementptr i8, ptr %t403, i64 %t394
  call void @olang_textcopy(ptr %t404, ptr %t397, i64 %t398)
  %t405 = insertvalue { i64, ptr } undef, i64 %t399, 0
  %t406 = insertvalue { i64, ptr } %t405, ptr %t402, 1
  %t408 = load ptr, ptr %l190, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v0, ptr %t408, { i64, ptr } %t406)
  br label %bb91
bb91:
  call void @__olang_scope_close(ptr %s10)
  br label %bb117
bb92:
  %t410 = load { i64, ptr }, ptr %l182, !tbaa !27
  store { i64, ptr } %t410, ptr %l20, !tbaa !27
  %t411 = load ptr, ptr %l0, !tbaa !29
  %t413 = getelementptr %"compiler/bindgen:gen", ptr %t411, i32 0, i32 1
  %t414 = load i1, ptr %t413, !tbaa !21
  br i1 %t414, label %bb93, label %bb94
bb93:
  %t416 = load ptr, ptr %lp18
  %t417 = getelementptr %"compiler/bindgen:cFunc", ptr %t416, i32 0, i32 4
  %t418 = load i1, ptr %t417, !tbaa !21
  br i1 %t418, label %bb95, label %bb96
bb94:
  store i1 false, ptr %l200, !tbaa !21
  br label %bb99
bb95:
  store i1 true, ptr %l202, !tbaa !21
  br label %bb98
bb96:
  %t420 = load ptr, ptr %lp18
  %t421 = getelementptr %"compiler/bindgen:cFunc", ptr %t420, i32 0, i32 5
  %t422 = load { i64, ptr }, ptr %t421, !tbaa !27
  %t424 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s10, { i64, ptr } %t422, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d300, i32 0, i32 1) })
  store i1 %t424, ptr %l204
  br label %bb97
bb97:
  %t425 = load i1, ptr %l204, !tbaa !21
  %t426 = xor i1 %t425, true
  store i1 %t426, ptr %l202, !tbaa !21
  br label %bb98
bb98:
  %t428 = load i1, ptr %l202, !tbaa !21
  store i1 %t428, ptr %l200, !tbaa !21
  br label %bb99
bb99:
  %t429 = load i1, ptr %l200, !tbaa !21
  br i1 %t429, label %bb100, label %bb101
bb100:
  store %olang.scope zeroinitializer, ptr %s23
  %t430 = load ptr, ptr %lp18
  %t431 = getelementptr %"compiler/bindgen:cFunc", ptr %t430, i32 0, i32 5
  %t432 = load { i64, ptr }, ptr %t431, !tbaa !27
  store { i64, ptr } %t432, ptr %l21, !tbaa !27
  %t434 = load ptr, ptr %lp18
  %t435 = getelementptr %"compiler/bindgen:cFunc", ptr %t434, i32 0, i32 4
  %t436 = load i1, ptr %t435, !tbaa !21
  br i1 %t436, label %bb102, label %bb103
bb101:
  br label %bb115
bb102:
  %t438 = load ptr, ptr %l0, !tbaa !29
  %t439 = load ptr, ptr %lp18
  %t442 = call { i32, { i64, ptr } } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ewrapper(ptr %v0, ptr %v0, ptr %s23, ptr %t438, ptr %t439)
  %t443 = extractvalue { i32, { i64, ptr } } %t442, 1
  %t444 = extractvalue { i32, { i64, ptr } } %t442, 0
  store i32 %t444, ptr %l212
  %t445 = icmp ne i32 %t444, 0
  br i1 %t445, label %bb105, label %ok.446, !prof !99
ok.446:
  store { i64, ptr } %t443, ptr %l211
  br label %bb104
bb103:
  br label %bb111
bb104:
  %t447 = load { i64, ptr }, ptr %l211, !tbaa !27
  store { i64, ptr } %t447, ptr %l208, !tbaa !27
  br label %bb110
bb105:
  %t448 = load i32, ptr %l212, !tbaa !23
  %t449 = ashr i32 %t448, 16
  %t451 = icmp eq i32 %t449, 1
  store i1 %t451, ptr %l214, !tbaa !21
  br label %bb106
bb106:
  %t452 = load ptr, ptr %l0, !tbaa !29
  %t454 = getelementptr %"compiler/bindgen:gen", ptr %t452, i32 0, i32 19
  store ptr %t454, ptr %l216, !tbaa !29
  %t455 = call ptr @__olang_scope_hold(ptr %v0)
  %t456 = ptrtoint ptr %t455 to i64
  store i64 %t456, ptr %l217, !tbaa !24
  %t457 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t457, label %bb107, label %bb108
bb107:
  %t459 = call ptr @__olang_region_make(ptr %v0)
  %t460 = ptrtoint ptr %t459 to i64
  store i64 %t460, ptr %l217, !tbaa !24
  br label %bb108
bb108:
  %t461 = load ptr, ptr %lp18
  %t462 = getelementptr %"compiler/bindgen:cFunc", ptr %t461, i32 0, i32 0
  %t463 = load { i64, ptr }, ptr %t462, !tbaa !27
  %t464 = load ptr, ptr %l0, !tbaa !29
  %t466 = getelementptr %"compiler/bindgen:gen", ptr %t464, i32 0, i32 26
  %t467 = load { i64, ptr }, ptr %t466, !tbaa !27
  %t469 = extractvalue { i64, ptr } %t463, 1
  %t470 = extractvalue { i64, ptr } %t463, 0
  %t471 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d301, i32 0, i32 1) }, 1
  %t472 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d301, i32 0, i32 1) }, 0
  %t473 = add i64 %t470, %t472
  %t475 = extractvalue { i64, ptr } %t467, 1
  %t476 = extractvalue { i64, ptr } %t467, 0
  %t477 = add i64 %t473, %t476
  %t478 = load i64, ptr %l217
  %t479 = inttoptr i64 %t478 to ptr
  %t480 = call ptr @__olang_held_alloc(ptr %t479, i64 %t477)
  call void @olang_textcopy(ptr %t480, ptr %t469, i64 %t470)
  %t481 = getelementptr i8, ptr %t480, i64 %t470
  call void @olang_textcopy(ptr %t481, ptr %t471, i64 %t472)
  %t482 = getelementptr i8, ptr %t481, i64 %t472
  call void @olang_textcopy(ptr %t482, ptr %t475, i64 %t476)
  %t483 = insertvalue { i64, ptr } undef, i64 %t477, 0
  %t484 = insertvalue { i64, ptr } %t483, ptr %t480, 1
  %t486 = load ptr, ptr %l216, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v0, ptr %t486, { i64, ptr } %t484)
  br label %bb109
bb109:
  call void @__olang_scope_close(ptr %s23)
  call void @__olang_scope_close(ptr %s10)
  br label %bb117
bb110:
  %t488 = load { i64, ptr }, ptr %l208, !tbaa !27
  store { i64, ptr } %t488, ptr %l21, !tbaa !27
  br label %bb111
bb111:
  %t490 = load ptr, ptr %l0, !tbaa !29
  %t492 = getelementptr %"compiler/bindgen:gen", ptr %t490, i32 0, i32 20
  store ptr %t492, ptr %l226, !tbaa !29
  %t493 = call ptr @__olang_scope_hold(ptr %v0)
  %t494 = ptrtoint ptr %t493 to i64
  store i64 %t494, ptr %l227, !tbaa !24
  %t495 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t495, label %bb112, label %bb113
bb112:
  %t497 = call ptr @__olang_region_make(ptr %v0)
  %t498 = ptrtoint ptr %t497 to i64
  store i64 %t498, ptr %l227, !tbaa !24
  br label %bb113
bb113:
  %t499 = load ptr, ptr %lp18
  %t500 = getelementptr %"compiler/bindgen:cFunc", ptr %t499, i32 0, i32 0
  %t501 = load { i64, ptr }, ptr %t500, !tbaa !27
  %t502 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t504 = extractvalue { i64, ptr } %t501, 1
  %t505 = extractvalue { i64, ptr } %t501, 0
  %t506 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d302, i32 0, i32 1) }, 1
  %t507 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d302, i32 0, i32 1) }, 0
  %t508 = add i64 %t505, %t507
  %t510 = extractvalue { i64, ptr } %t502, 1
  %t511 = extractvalue { i64, ptr } %t502, 0
  %t512 = add i64 %t508, %t511
  %t513 = load i64, ptr %l227
  %t514 = inttoptr i64 %t513 to ptr
  %t515 = call ptr @__olang_held_alloc(ptr %t514, i64 %t512)
  call void @olang_textcopy(ptr %t515, ptr %t504, i64 %t505)
  %t516 = getelementptr i8, ptr %t515, i64 %t505
  call void @olang_textcopy(ptr %t516, ptr %t506, i64 %t507)
  %t517 = getelementptr i8, ptr %t516, i64 %t507
  call void @olang_textcopy(ptr %t517, ptr %t510, i64 %t511)
  %t518 = insertvalue { i64, ptr } undef, i64 %t512, 0
  %t519 = insertvalue { i64, ptr } %t518, ptr %t515, 1
  %t521 = load ptr, ptr %l226, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v0, ptr %t521, { i64, ptr } %t519)
  br label %bb114
bb114:
  call void @__olang_scope_close(ptr %s23)
  br label %bb115
bb115:
  %t523 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t524 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d303, i32 0, i32 1) }, 1
  %t525 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d303, i32 0, i32 1) }, 0
  %t527 = extractvalue { i64, ptr } %t523, 1
  %t528 = extractvalue { i64, ptr } %t523, 0
  %t529 = add i64 %t525, %t528
  %t530 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d304, i32 0, i32 1) }, 1
  %t531 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d304, i32 0, i32 1) }, 0
  %t532 = add i64 %t529, %t531
  %t533 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t532)
  call void @olang_textcopy(ptr %t533, ptr %t524, i64 %t525)
  %t534 = getelementptr i8, ptr %t533, i64 %t525
  call void @olang_textcopy(ptr %t534, ptr %t527, i64 %t528)
  %t535 = getelementptr i8, ptr %t534, i64 %t528
  call void @olang_textcopy(ptr %t535, ptr %t530, i64 %t531)
  %t536 = insertvalue { i64, ptr } undef, i64 %t532, 0
  %t537 = insertvalue { i64, ptr } %t536, ptr %t533, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s10, ptr %l14, { i64, ptr } %t537)
  br label %bb116
bb116:
  call void @__olang_scope_close(ptr %s10)
  br label %bb117
bb117:
  %t541 = load i64, ptr %l17, !tbaa !24
  %t544 = add i64 %t541, 1
  store i64 %t544, ptr %l17, !tbaa !24
  br label %bb39
bb118:
  %t546 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2emacroFns(ptr %v0, ptr %t546)
  br label %bb119
bb119:
  %t548 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t548, ptr %l241
  br label %bb120
bb120:
  %t549 = load %"std/prelude/text:StringBuilder", ptr %l241
  store %"std/prelude/text:StringBuilder" %t549, ptr %l22
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v1, ptr %l22, { i64, ptr } %a1)
  br label %bb121
bb121:
  %t553 = load ptr, ptr %l0, !tbaa !29
  %t555 = getelementptr %"compiler/bindgen:gen", ptr %t553, i32 0, i32 20
  store ptr %t555, ptr %l23, !tbaa !29
  store i64 0, ptr %l24, !tbaa !24
  br label %bb122
bb122:
  store %olang.scope zeroinitializer, ptr %s31
  %t557 = load i64, ptr %l24, !tbaa !24
  store i64 %t557, ptr %l246, !tbaa !24
  %t558 = load ptr, ptr %l23, !tbaa !29
  %t560 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %t558)
  store i64 %t560, ptr %l248
  br label %bb123
bb123:
  %t561 = load i64, ptr %l246, !tbaa !24
  %t562 = load i64, ptr %l248, !tbaa !24
  %t563 = icmp slt i64 %t561, %t562
  %t565 = xor i1 %t563, true
  br i1 %t565, label %bb124, label %bb125
bb124:
  call void @__olang_scope_close(ptr %s31)
  br label %bb130
bb125:
  br label %bb126
bb126:
  %t567 = load ptr, ptr %l23, !tbaa !29
  %t568 = load i64, ptr %l24, !tbaa !24
  %t571 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %t567, i64 %t568)
  store { i64, ptr } %t571, ptr %l253
  br label %bb127
bb127:
  %t572 = load { i64, ptr }, ptr %l253, !tbaa !27
  %t574 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d305, i32 0, i32 1) }, 1
  %t575 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d305, i32 0, i32 1) }, 0
  %t577 = extractvalue { i64, ptr } %t572, 1
  %t578 = extractvalue { i64, ptr } %t572, 0
  %t579 = add i64 %t575, %t578
  %t580 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d306, i32 0, i32 1) }, 1
  %t581 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d306, i32 0, i32 1) }, 0
  %t582 = add i64 %t579, %t581
  %t583 = call ptr @__olang_scope_alloc(ptr %s31, i64 %t582)
  call void @olang_textcopy(ptr %t583, ptr %t574, i64 %t575)
  %t584 = getelementptr i8, ptr %t583, i64 %t575
  call void @olang_textcopy(ptr %t584, ptr %t577, i64 %t578)
  %t585 = getelementptr i8, ptr %t584, i64 %t578
  call void @olang_textcopy(ptr %t585, ptr %t580, i64 %t581)
  %t586 = insertvalue { i64, ptr } undef, i64 %t582, 0
  %t587 = insertvalue { i64, ptr } %t586, ptr %t583, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s31, ptr %l22, { i64, ptr } %t587)
  br label %bb128
bb128:
  call void @__olang_scope_close(ptr %s31)
  br label %bb129
bb129:
  %t591 = load i64, ptr %l24, !tbaa !24
  %t594 = add i64 %t591, 1
  store i64 %t594, ptr %l24, !tbaa !24
  br label %bb122
bb130:
  %t596 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t596, ptr %l261
  br label %bb131
bb131:
  %t597 = load %"std/prelude/text:StringBuilder", ptr %l261
  store %"std/prelude/text:StringBuilder" %t597, ptr %l26
  %t598 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t598, ptr %l262
  br label %bb132
bb132:
  %t599 = load %"std/prelude/text:StringBuilder", ptr %l262
  store %"std/prelude/text:StringBuilder" %t599, ptr %l27
  store i64 0, ptr %l28, !tbaa !24
  %t600 = load ptr, ptr %l0, !tbaa !29
  %t602 = getelementptr %"compiler/bindgen:gen", ptr %t600, i32 0, i32 6
  %t604 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eLen_3ccompiler_2fbindgen_3arecord_3e(ptr %v0, ptr %t602)
  store i64 %t604, ptr %l265
  br label %bb133
bb133:
  %t605 = load i64, ptr %l265, !tbaa !24
  store i64 %t605, ptr %l29, !tbaa !24
  store i64 1, ptr %l30, !tbaa !24
  %t606 = load i64, ptr %l29, !tbaa !24
  %t607 = load i64, ptr %l28, !tbaa !24
  %t610 = icmp sgt i64 %t606, %t607
  br i1 %t610, label %bb134, label %bb135
bb134:
  %t612 = load i64, ptr %l30, !tbaa !24
  %t614 = icmp sgt i64 %t612, 0
  br i1 %t614, label %bb136, label %bb137
bb135:
  store i64 0, ptr %l269, !tbaa !24
  br label %bb139
bb136:
  %t616 = load i64, ptr %l29, !tbaa !24
  %t617 = load i64, ptr %l28, !tbaa !24
  %t620 = sub i64 %t616, %t617
  %t621 = load i64, ptr %l30, !tbaa !24
  %t624 = add i64 %t620, %t621
  %t626 = sub i64 %t624, 1
  %t627 = load i64, ptr %l30, !tbaa !24
  %t630 = sdiv i64 %t626, %t627
  store i64 %t630, ptr %l272, !tbaa !24
  br label %bb138
bb137:
  store i64 0, ptr %l272, !tbaa !24
  br label %bb138
bb138:
  %t632 = load i64, ptr %l272, !tbaa !24
  store i64 %t632, ptr %l269, !tbaa !24
  br label %bb139
bb139:
  %t633 = load i64, ptr %l269, !tbaa !24
  store i64 %t633, ptr %l31, !tbaa !24
  store i64 0, ptr %l32, !tbaa !24
  br label %bb140
bb140:
  store %olang.scope zeroinitializer, ptr %s35
  %t634 = load i64, ptr %l32, !tbaa !24
  %t635 = load i64, ptr %l31, !tbaa !24
  %t638 = icmp slt i64 %t634, %t635
  %t640 = xor i1 %t638, true
  br i1 %t640, label %bb141, label %bb142
bb141:
  call void @__olang_scope_close(ptr %s35)
  br label %bb162
bb142:
  br label %bb143
bb143:
  %t642 = load i64, ptr %l28, !tbaa !24
  %t643 = load i64, ptr %l32, !tbaa !24
  %t644 = load i64, ptr %l30, !tbaa !24
  %t647 = mul i64 %t643, %t644
  %t650 = add i64 %t642, %t647
  store i64 %t650, ptr %l33, !tbaa !24
  %t652 = load ptr, ptr %l0, !tbaa !29
  %t654 = getelementptr %"compiler/bindgen:gen", ptr %t652, i32 0, i32 6
  %t655 = load i64, ptr %l33, !tbaa !24
  %t658 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eRef_3ccompiler_2fbindgen_3arecord_3e(ptr %v0, ptr %v0, ptr %t654, i64 %t655)
  store ptr %t658, ptr %l293
  br label %bb144
bb144:
  %t659 = load ptr, ptr %l293, !tbaa !29
  %t661 = getelementptr %"compiler/bindgen:record", ptr %t659, i32 0, i32 7
  %t662 = load { i64, ptr }, ptr %t661, !tbaa !27
  %t664 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s35, { i64, ptr } %t662, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d307, i32 0, i32 1) })
  store i1 %t664, ptr %l296
  br label %bb145
bb145:
  %t665 = load i1, ptr %l296, !tbaa !21
  br i1 %t665, label %bb146, label %bb147
bb146:
  store i1 true, ptr %l297, !tbaa !21
  br label %bb149
bb147:
  %t666 = load ptr, ptr %l0, !tbaa !29
  %t667 = load i64, ptr %l33, !tbaa !24
  %t670 = call i1 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ewantRecord(ptr %v0, ptr %t666, i64 %t667)
  store i1 %t670, ptr %l300
  br label %bb148
bb148:
  %t671 = load i1, ptr %l300, !tbaa !21
  %t672 = xor i1 %t671, true
  store i1 %t672, ptr %l297, !tbaa !21
  br label %bb149
bb149:
  %t674 = load i1, ptr %l297, !tbaa !21
  br i1 %t674, label %bb150, label %bb151
bb150:
  call void @__olang_scope_close(ptr %s35)
  br label %bb161
bb151:
  br label %bb152
bb152:
  %t675 = load ptr, ptr %l0, !tbaa !29
  %t676 = load i64, ptr %l33, !tbaa !24
  %t679 = call i1 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eholdable(ptr %v0, ptr %t675, i64 %t676)
  store i1 %t679, ptr %l304
  br label %bb153
bb153:
  %t680 = load i1, ptr %l304, !tbaa !21
  br i1 %t680, label %bb154, label %bb155
bb154:
  store %olang.scope zeroinitializer, ptr %s37
  store ptr %l27, ptr %l305, !tbaa !29
  %t681 = load ptr, ptr %l0, !tbaa !29
  %t682 = load i64, ptr %l33, !tbaa !24
  %t685 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2estructDecl(ptr %v0, ptr %s37, ptr %t681, i64 %t682)
  store { i64, ptr } %t685, ptr %l308
  br label %bb156
bb155:
  store %olang.scope zeroinitializer, ptr %s39
  store ptr %l26, ptr %l311, !tbaa !29
  %t686 = load ptr, ptr %l0, !tbaa !29
  %t688 = getelementptr %"compiler/bindgen:gen", ptr %t686, i32 0, i32 6
  %t689 = load i64, ptr %l33, !tbaa !24
  %t692 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eRef_3ccompiler_2fbindgen_3arecord_3e(ptr %v0, ptr %v0, ptr %t688, i64 %t689)
  store ptr %t692, ptr %l315
  br label %bb158
bb156:
  %t693 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d308, i32 0, i32 1) }, 1
  %t694 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d308, i32 0, i32 1) }, 0
  %t695 = load { i64, ptr }, ptr %l308, !tbaa !27
  %t696 = extractvalue { i64, ptr } %t695, 1
  %t697 = extractvalue { i64, ptr } %t695, 0
  %t698 = add i64 %t694, %t697
  %t699 = call ptr @__olang_scope_alloc(ptr %s37, i64 %t698)
  call void @olang_textcopy(ptr %t699, ptr %t693, i64 %t694)
  %t700 = getelementptr i8, ptr %t699, i64 %t694
  call void @olang_textcopy(ptr %t700, ptr %t696, i64 %t697)
  %t701 = insertvalue { i64, ptr } undef, i64 %t698, 0
  %t702 = insertvalue { i64, ptr } %t701, ptr %t699, 1
  %t704 = load ptr, ptr %l305, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s37, ptr %t704, { i64, ptr } %t702)
  br label %bb157
bb157:
  call void @__olang_scope_close(ptr %s37)
  br label %bb160
bb158:
  %t706 = load ptr, ptr %l315, !tbaa !29
  %t708 = getelementptr %"compiler/bindgen:record", ptr %t706, i32 0, i32 7
  %t709 = load { i64, ptr }, ptr %t708, !tbaa !27
  %t710 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d309, i32 0, i32 1) }, 1
  %t711 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d309, i32 0, i32 1) }, 0
  %t713 = extractvalue { i64, ptr } %t709, 1
  %t714 = extractvalue { i64, ptr } %t709, 0
  %t715 = add i64 %t711, %t714
  %t716 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d310, i32 0, i32 1) }, 1
  %t717 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d310, i32 0, i32 1) }, 0
  %t718 = add i64 %t715, %t717
  %t719 = call ptr @__olang_scope_alloc(ptr %s39, i64 %t718)
  call void @olang_textcopy(ptr %t719, ptr %t710, i64 %t711)
  %t720 = getelementptr i8, ptr %t719, i64 %t711
  call void @olang_textcopy(ptr %t720, ptr %t713, i64 %t714)
  %t721 = getelementptr i8, ptr %t720, i64 %t714
  call void @olang_textcopy(ptr %t721, ptr %t716, i64 %t717)
  %t722 = insertvalue { i64, ptr } undef, i64 %t718, 0
  %t723 = insertvalue { i64, ptr } %t722, ptr %t719, 1
  %t725 = load ptr, ptr %l311, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s39, ptr %t725, { i64, ptr } %t723)
  br label %bb159
bb159:
  call void @__olang_scope_close(ptr %s39)
  br label %bb160
bb160:
  call void @__olang_scope_close(ptr %s35)
  br label %bb161
bb161:
  %t727 = load i64, ptr %l32, !tbaa !24
  %t730 = add i64 %t727, 1
  store i64 %t730, ptr %l32, !tbaa !24
  br label %bb140
bb162:
  %t733 = call i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eLen(ptr %s0, ptr %l26)
  store i64 %t733, ptr %l324
  br label %bb163
bb163:
  %t734 = load i64, ptr %l324, !tbaa !24
  %t735 = icmp sgt i64 %t734, 0
  br i1 %t735, label %bb164, label %bb165
bb164:
  store i1 true, ptr %l326, !tbaa !21
  br label %bb167
bb165:
  %t738 = call i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eLen(ptr %s0, ptr %l14)
  store i64 %t738, ptr %l328
  br label %bb166
bb166:
  %t739 = load i64, ptr %l328, !tbaa !24
  %t740 = icmp sgt i64 %t739, 0
  store i1 %t740, ptr %l326, !tbaa !21
  br label %bb167
bb167:
  %t742 = load i1, ptr %l326, !tbaa !21
  br i1 %t742, label %bb168, label %bb169
bb168:
  store %olang.scope zeroinitializer, ptr %s42
  store ptr %l22, ptr %l330, !tbaa !29
  %t744 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s42, ptr %l26)
  store { i64, ptr } %t744, ptr %l332
  br label %bb170
bb169:
  br label %bb173
bb170:
  %t746 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s42, ptr %l14)
  store { i64, ptr } %t746, ptr %l334
  br label %bb171
bb171:
  %t747 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d311, i32 0, i32 1) }, 1
  %t748 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d311, i32 0, i32 1) }, 0
  %t749 = load { i64, ptr }, ptr %l332, !tbaa !27
  %t750 = extractvalue { i64, ptr } %t749, 1
  %t751 = extractvalue { i64, ptr } %t749, 0
  %t752 = add i64 %t748, %t751
  %t753 = load { i64, ptr }, ptr %l334, !tbaa !27
  %t754 = extractvalue { i64, ptr } %t753, 1
  %t755 = extractvalue { i64, ptr } %t753, 0
  %t756 = add i64 %t752, %t755
  %t757 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d312, i32 0, i32 1) }, 1
  %t758 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d312, i32 0, i32 1) }, 0
  %t759 = add i64 %t756, %t758
  %t760 = call ptr @__olang_scope_alloc(ptr %s42, i64 %t759)
  call void @olang_textcopy(ptr %t760, ptr %t747, i64 %t748)
  %t761 = getelementptr i8, ptr %t760, i64 %t748
  call void @olang_textcopy(ptr %t761, ptr %t750, i64 %t751)
  %t762 = getelementptr i8, ptr %t761, i64 %t751
  call void @olang_textcopy(ptr %t762, ptr %t754, i64 %t755)
  %t763 = getelementptr i8, ptr %t762, i64 %t755
  call void @olang_textcopy(ptr %t763, ptr %t757, i64 %t758)
  %t764 = insertvalue { i64, ptr } undef, i64 %t759, 0
  %t765 = insertvalue { i64, ptr } %t764, ptr %t760, 1
  %t767 = load ptr, ptr %l330, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s42, ptr %t767, { i64, ptr } %t765)
  br label %bb172
bb172:
  call void @__olang_scope_close(ptr %s42)
  br label %bb173
bb173:
  store ptr %l22, ptr %l337, !tbaa !29
  %t770 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s0, ptr %l27)
  store { i64, ptr } %t770, ptr %l339
  br label %bb174
bb174:
  %t771 = load { i64, ptr }, ptr %l339, !tbaa !27
  %t772 = load ptr, ptr %l337, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t772, { i64, ptr } %t771)
  br label %bb175
bb175:
  %t774 = load ptr, ptr %l0, !tbaa !29
  %t776 = getelementptr %"compiler/bindgen:gen", ptr %t774, i32 0, i32 10
  %t778 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %t776)
  store i64 %t778, ptr %l343
  br label %bb176
bb176:
  %t779 = load i64, ptr %l343, !tbaa !24
  %t780 = icmp sgt i64 %t779, 0
  br i1 %t780, label %bb177, label %bb178
bb177:
  store %olang.scope zeroinitializer, ptr %s44
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s44, ptr %l22, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d313, i32 0, i32 1) })
  br label %bb179
bb178:
  br label %bb189
bb179:
  %t783 = load ptr, ptr %l0, !tbaa !29
  %t785 = getelementptr %"compiler/bindgen:gen", ptr %t783, i32 0, i32 10
  store ptr %t785, ptr %l34, !tbaa !29
  store i64 0, ptr %l35, !tbaa !24
  br label %bb180
bb180:
  store %olang.scope zeroinitializer, ptr %s46
  %t787 = load i64, ptr %l35, !tbaa !24
  store i64 %t787, ptr %l348, !tbaa !24
  %t788 = load ptr, ptr %l34, !tbaa !29
  %t790 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %t788)
  store i64 %t790, ptr %l350
  br label %bb181
bb181:
  %t791 = load i64, ptr %l348, !tbaa !24
  %t792 = load i64, ptr %l350, !tbaa !24
  %t793 = icmp slt i64 %t791, %t792
  %t795 = xor i1 %t793, true
  br i1 %t795, label %bb182, label %bb183
bb182:
  call void @__olang_scope_close(ptr %s46)
  br label %bb188
bb183:
  br label %bb184
bb184:
  %t797 = load ptr, ptr %l34, !tbaa !29
  %t798 = load i64, ptr %l35, !tbaa !24
  %t801 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %t797, i64 %t798)
  store { i64, ptr } %t801, ptr %l355
  br label %bb185
bb185:
  %t802 = load { i64, ptr }, ptr %l355, !tbaa !27
  %t805 = extractvalue { i64, ptr } %t802, 1
  %t806 = extractvalue { i64, ptr } %t802, 0
  %t807 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d314, i32 0, i32 1) }, 1
  %t808 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d314, i32 0, i32 1) }, 0
  %t809 = add i64 %t806, %t808
  %t810 = call ptr @__olang_scope_alloc(ptr %s46, i64 %t809)
  call void @olang_textcopy(ptr %t810, ptr %t805, i64 %t806)
  %t811 = getelementptr i8, ptr %t810, i64 %t806
  call void @olang_textcopy(ptr %t811, ptr %t807, i64 %t808)
  %t812 = insertvalue { i64, ptr } undef, i64 %t809, 0
  %t813 = insertvalue { i64, ptr } %t812, ptr %t810, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s46, ptr %l22, { i64, ptr } %t813)
  br label %bb186
bb186:
  call void @__olang_scope_close(ptr %s46)
  br label %bb187
bb187:
  %t817 = load i64, ptr %l35, !tbaa !24
  %t820 = add i64 %t817, 1
  store i64 %t820, ptr %l35, !tbaa !24
  br label %bb180
bb188:
  call void @__olang_scope_close(ptr %s44)
  br label %bb189
bb189:
  %t822 = load ptr, ptr %l0, !tbaa !29
  %t824 = getelementptr %"compiler/bindgen:gen", ptr %t822, i32 0, i32 15
  %t826 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %t824)
  store i64 %t826, ptr %l365
  br label %bb190
bb190:
  %t827 = load i64, ptr %l365, !tbaa !24
  %t828 = icmp sgt i64 %t827, 0
  br i1 %t828, label %bb191, label %bb192
bb191:
  store %olang.scope zeroinitializer, ptr %s49
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s49, ptr %l22, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d315, i32 0, i32 1) })
  br label %bb193
bb192:
  br label %bb203
bb193:
  %t831 = load ptr, ptr %l0, !tbaa !29
  %t833 = getelementptr %"compiler/bindgen:gen", ptr %t831, i32 0, i32 15
  store ptr %t833, ptr %l37, !tbaa !29
  store i64 0, ptr %l38, !tbaa !24
  br label %bb194
bb194:
  store %olang.scope zeroinitializer, ptr %s51
  %t835 = load i64, ptr %l38, !tbaa !24
  store i64 %t835, ptr %l370, !tbaa !24
  %t836 = load ptr, ptr %l37, !tbaa !29
  %t838 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %t836)
  store i64 %t838, ptr %l372
  br label %bb195
bb195:
  %t839 = load i64, ptr %l370, !tbaa !24
  %t840 = load i64, ptr %l372, !tbaa !24
  %t841 = icmp slt i64 %t839, %t840
  %t843 = xor i1 %t841, true
  br i1 %t843, label %bb196, label %bb197
bb196:
  call void @__olang_scope_close(ptr %s51)
  br label %bb202
bb197:
  br label %bb198
bb198:
  %t845 = load ptr, ptr %l37, !tbaa !29
  %t846 = load i64, ptr %l38, !tbaa !24
  %t849 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %t845, i64 %t846)
  store { i64, ptr } %t849, ptr %l377
  br label %bb199
bb199:
  %t850 = load { i64, ptr }, ptr %l377, !tbaa !27
  %t853 = extractvalue { i64, ptr } %t850, 1
  %t854 = extractvalue { i64, ptr } %t850, 0
  %t855 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d316, i32 0, i32 1) }, 1
  %t856 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d316, i32 0, i32 1) }, 0
  %t857 = add i64 %t854, %t856
  %t858 = call ptr @__olang_scope_alloc(ptr %s51, i64 %t857)
  call void @olang_textcopy(ptr %t858, ptr %t853, i64 %t854)
  %t859 = getelementptr i8, ptr %t858, i64 %t854
  call void @olang_textcopy(ptr %t859, ptr %t855, i64 %t856)
  %t860 = insertvalue { i64, ptr } undef, i64 %t857, 0
  %t861 = insertvalue { i64, ptr } %t860, ptr %t858, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s51, ptr %l22, { i64, ptr } %t861)
  br label %bb200
bb200:
  call void @__olang_scope_close(ptr %s51)
  br label %bb201
bb201:
  %t865 = load i64, ptr %l38, !tbaa !24
  %t868 = add i64 %t865, 1
  store i64 %t868, ptr %l38, !tbaa !24
  br label %bb194
bb202:
  call void @__olang_scope_close(ptr %s49)
  br label %bb203
bb203:
  %t870 = load ptr, ptr %l0, !tbaa !29
  %t872 = getelementptr %"compiler/bindgen:gen", ptr %t870, i32 0, i32 19
  %t874 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %t872)
  store i64 %t874, ptr %l387
  br label %bb204
bb204:
  %t875 = load i64, ptr %l387, !tbaa !24
  %t876 = icmp sgt i64 %t875, 0
  br i1 %t876, label %bb205, label %bb206
bb205:
  store %olang.scope zeroinitializer, ptr %s54
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s54, ptr %l22, { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d317, i32 0, i32 1) })
  br label %bb207
bb206:
  br label %bb217
bb207:
  %t879 = load ptr, ptr %l0, !tbaa !29
  %t881 = getelementptr %"compiler/bindgen:gen", ptr %t879, i32 0, i32 19
  store ptr %t881, ptr %l40, !tbaa !29
  store i64 0, ptr %l41, !tbaa !24
  br label %bb208
bb208:
  store %olang.scope zeroinitializer, ptr %s56
  %t883 = load i64, ptr %l41, !tbaa !24
  store i64 %t883, ptr %l392, !tbaa !24
  %t884 = load ptr, ptr %l40, !tbaa !29
  %t886 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %t884)
  store i64 %t886, ptr %l394
  br label %bb209
bb209:
  %t887 = load i64, ptr %l392, !tbaa !24
  %t888 = load i64, ptr %l394, !tbaa !24
  %t889 = icmp slt i64 %t887, %t888
  %t891 = xor i1 %t889, true
  br i1 %t891, label %bb210, label %bb211
bb210:
  call void @__olang_scope_close(ptr %s56)
  br label %bb216
bb211:
  br label %bb212
bb212:
  %t893 = load ptr, ptr %l40, !tbaa !29
  %t894 = load i64, ptr %l41, !tbaa !24
  %t897 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %t893, i64 %t894)
  store { i64, ptr } %t897, ptr %l399
  br label %bb213
bb213:
  %t898 = load { i64, ptr }, ptr %l399, !tbaa !27
  %t900 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d318, i32 0, i32 1) }, 1
  %t901 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d318, i32 0, i32 1) }, 0
  %t903 = extractvalue { i64, ptr } %t898, 1
  %t904 = extractvalue { i64, ptr } %t898, 0
  %t905 = add i64 %t901, %t904
  %t906 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d319, i32 0, i32 1) }, 1
  %t907 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d319, i32 0, i32 1) }, 0
  %t908 = add i64 %t905, %t907
  %t909 = call ptr @__olang_scope_alloc(ptr %s56, i64 %t908)
  call void @olang_textcopy(ptr %t909, ptr %t900, i64 %t901)
  %t910 = getelementptr i8, ptr %t909, i64 %t901
  call void @olang_textcopy(ptr %t910, ptr %t903, i64 %t904)
  %t911 = getelementptr i8, ptr %t910, i64 %t904
  call void @olang_textcopy(ptr %t911, ptr %t906, i64 %t907)
  %t912 = insertvalue { i64, ptr } undef, i64 %t908, 0
  %t913 = insertvalue { i64, ptr } %t912, ptr %t909, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s56, ptr %l22, { i64, ptr } %t913)
  br label %bb214
bb214:
  call void @__olang_scope_close(ptr %s56)
  br label %bb215
bb215:
  %t917 = load i64, ptr %l41, !tbaa !24
  %t920 = add i64 %t917, 1
  store i64 %t920, ptr %l41, !tbaa !24
  br label %bb208
bb216:
  call void @__olang_scope_close(ptr %s54)
  br label %bb217
bb217:
  %t923 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v2, ptr %l22)
  store { i64, ptr } %t923, ptr %l408
  br label %bb218
bb218:
  call void @__olang_scope_close(ptr %s0)
  %t924 = load { i64, ptr }, ptr %l408, !tbaa !27
  store { i64, ptr } %t924, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fbindgen_2ectokens(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %lp1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i8
  %l4 = alloca i64
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l11 = alloca { i64, ptr }
  %l22 = alloca i1
  %l23 = alloca i1
  %l25 = alloca i1
  %l26 = alloca i1
  %l33 = alloca i1
  %l34 = alloca { i64, ptr }
  %l37 = alloca i1
  %l38 = alloca i1
  %l39 = alloca { i64, ptr }
  %l42 = alloca i1
  %l43 = alloca i1
  %l44 = alloca { i64, ptr }
  %l58 = alloca i1
  %l59 = alloca { i64, ptr }
  %l67 = alloca ptr
  %l68 = alloca i64
  %l70 = alloca { i64, ptr }
  %l71 = alloca i64
  %l72 = alloca i64
  %l73 = alloca i64
  %l82 = alloca { i64, ptr }
  %l83 = alloca { i64, ptr }
  %l84 = alloca i64
  %l85 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l5
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 32, i64 8)
  store ptr %t2, ptr %lp1
  %t3 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l5
  %t4 = load ptr, ptr %lp1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %t4
  store i64 0, ptr %l2, !tbaa !24
  br label %bb2
bb2:
  %t5 = load i64, ptr %l2, !tbaa !24
  %t6 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  %t11 = icmp slt i64 %t5, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb3, label %bb4
bb3:
  br label %bb59
bb4:
  br label %bb5
bb5:
  %t15 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t15, ptr %l11, !tbaa !27
  %t16 = load i64, ptr %l2, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr i8, ptr %t19, i64 %t16
  %t21 = load i8, ptr %t20, !tbaa !32
  store i8 %t21, ptr %l3, !tbaa !22
  %t23 = load i8, ptr %l3, !tbaa !22
  %t25 = icmp eq i8 %t23, 32
  br i1 %t25, label %bb6, label %bb7
bb6:
  %t27 = load i64, ptr %l2, !tbaa !24
  %t30 = add i64 %t27, 1
  store i64 %t30, ptr %l2, !tbaa !24
  br label %bb58
bb7:
  br label %bb8
bb8:
  %t32 = load i64, ptr %l2, !tbaa !24
  %t34 = add i64 %t32, 1
  store i64 %t34, ptr %l4, !tbaa !24
  %t36 = load i8, ptr %l3, !tbaa !22
  %t38 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %t36)
  store i1 %t38, ptr %l22
  br label %bb9
bb9:
  %t39 = load i1, ptr %l22, !tbaa !21
  br i1 %t39, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l23, !tbaa !21
  br label %bb13
bb11:
  %t40 = load i8, ptr %l3, !tbaa !22
  %t42 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t40)
  store i1 %t42, ptr %l25
  br label %bb12
bb12:
  %t43 = load i1, ptr %l25, !tbaa !21
  store i1 %t43, ptr %l23, !tbaa !21
  br label %bb13
bb13:
  %t44 = load i1, ptr %l23, !tbaa !21
  br i1 %t44, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l26, !tbaa !21
  br label %bb16
bb15:
  %t45 = load i8, ptr %l3, !tbaa !22
  %t47 = icmp eq i8 %t45, 95
  store i1 %t47, ptr %l26, !tbaa !21
  br label %bb16
bb16:
  %t49 = load i1, ptr %l26, !tbaa !21
  br i1 %t49, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  %t50 = load i8, ptr %l3, !tbaa !22
  %t52 = icmp eq i8 %t50, 46
  br i1 %t52, label %bb36, label %bb37
bb19:
  %t54 = load i64, ptr %l4, !tbaa !24
  %t55 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t57 = extractvalue { i64, ptr } %t55, 0
  %t60 = icmp slt i64 %t54, %t57
  br i1 %t60, label %bb20, label %bb21
bb20:
  %t62 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t62, ptr %l34, !tbaa !27
  %t63 = load i64, ptr %l4, !tbaa !24
  %t65 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !27
  %t67 = getelementptr i8, ptr %t66, i64 %t63
  %t68 = load i8, ptr %t67, !tbaa !32
  %t70 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %t68)
  store i1 %t70, ptr %l37
  br label %bb22
bb21:
  store i1 false, ptr %l33, !tbaa !21
  br label %bb30
bb22:
  %t71 = load i1, ptr %l37, !tbaa !21
  br i1 %t71, label %bb23, label %bb24
bb23:
  store i1 true, ptr %l38, !tbaa !21
  br label %bb26
bb24:
  %t72 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t72, ptr %l39, !tbaa !27
  %t73 = load i64, ptr %l4, !tbaa !24
  %t75 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = getelementptr i8, ptr %t76, i64 %t73
  %t78 = load i8, ptr %t77, !tbaa !32
  %t80 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t78)
  store i1 %t80, ptr %l42
  br label %bb25
bb25:
  %t81 = load i1, ptr %l42, !tbaa !21
  store i1 %t81, ptr %l38, !tbaa !21
  br label %bb26
bb26:
  %t82 = load i1, ptr %l38, !tbaa !21
  br i1 %t82, label %bb27, label %bb28
bb27:
  store i1 true, ptr %l43, !tbaa !21
  br label %bb29
bb28:
  %t83 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t83, ptr %l44, !tbaa !27
  %t84 = load i64, ptr %l4, !tbaa !24
  %t86 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t87 = load ptr, ptr %t86, !tbaa !27
  %t88 = getelementptr i8, ptr %t87, i64 %t84
  %t89 = load i8, ptr %t88, !tbaa !32
  %t91 = icmp eq i8 %t89, 95
  store i1 %t91, ptr %l43, !tbaa !21
  br label %bb29
bb29:
  %t93 = load i1, ptr %l43, !tbaa !21
  store i1 %t93, ptr %l33, !tbaa !21
  br label %bb30
bb30:
  %t94 = load i1, ptr %l33, !tbaa !21
  %t95 = xor i1 %t94, true
  br i1 %t95, label %bb31, label %bb32
bb31:
  br label %bb35
bb32:
  br label %bb33
bb33:
  %t97 = load i64, ptr %l4, !tbaa !24
  %t100 = add i64 %t97, 1
  store i64 %t100, ptr %l4, !tbaa !24
  br label %bb34
bb34:
  br label %bb19
bb35:
  br label %bb48
bb36:
  br label %bb38
bb37:
  br label %bb47
bb38:
  %t102 = load i64, ptr %l4, !tbaa !24
  %t103 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t105 = extractvalue { i64, ptr } %t103, 0
  %t108 = icmp slt i64 %t102, %t105
  br i1 %t108, label %bb39, label %bb40
bb39:
  %t110 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t110, ptr %l59, !tbaa !27
  %t111 = load i64, ptr %l4, !tbaa !24
  %t113 = getelementptr { i64, ptr }, ptr %l59, i32 0, i32 1
  %t114 = load ptr, ptr %t113, !tbaa !27
  %t115 = getelementptr i8, ptr %t114, i64 %t111
  %t116 = load i8, ptr %t115, !tbaa !32
  %t118 = icmp eq i8 %t116, 46
  store i1 %t118, ptr %l58, !tbaa !21
  br label %bb41
bb40:
  store i1 false, ptr %l58, !tbaa !21
  br label %bb41
bb41:
  %t120 = load i1, ptr %l58, !tbaa !21
  %t121 = xor i1 %t120, true
  br i1 %t121, label %bb42, label %bb43
bb42:
  br label %bb46
bb43:
  br label %bb44
bb44:
  %t123 = load i64, ptr %l4, !tbaa !24
  %t126 = add i64 %t123, 1
  store i64 %t126, ptr %l4, !tbaa !24
  br label %bb45
bb45:
  br label %bb38
bb46:
  br label %bb47
bb47:
  br label %bb48
bb48:
  %t128 = load ptr, ptr %lp1
  store ptr %t128, ptr %l67, !tbaa !29
  %t129 = call ptr @__olang_scope_hold(ptr %v1)
  %t130 = ptrtoint ptr %t129 to i64
  store i64 %t130, ptr %l68, !tbaa !24
  %t131 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t131, label %bb49, label %bb50
bb49:
  %t133 = call ptr @__olang_region_make(ptr %v1)
  %t134 = ptrtoint ptr %t133 to i64
  store i64 %t134, ptr %l68, !tbaa !24
  br label %bb50
bb50:
  %t135 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t135, ptr %l70, !tbaa !27
  %t136 = load i64, ptr %l2, !tbaa !24
  store i64 %t136, ptr %l71, !tbaa !24
  %t137 = load i64, ptr %l4, !tbaa !24
  store i64 %t137, ptr %l72, !tbaa !24
  %t138 = load { i64, ptr }, ptr %l70, !tbaa !27
  %t139 = extractvalue { i64, ptr } %t138, 0
  store i64 %t139, ptr %l73, !tbaa !24
  %t140 = load i64, ptr %l71, !tbaa !24
  %t141 = icmp sge i64 %t140, 0
  br i1 %t141, label %bb51, label %bb52
bb51:
  %t143 = load i64, ptr %l71, !tbaa !24
  %t144 = load i64, ptr %l72, !tbaa !24
  %t145 = icmp sle i64 %t143, %t144
  br i1 %t145, label %bb53, label %bb54
bb52:
  call void @__olang_check_failed(ptr @olang_loc_12d4b4c126d079e6_1af6ce2ce1af3fd2)
  unreachable
bb53:
  %t147 = load i64, ptr %l72, !tbaa !24
  %t148 = load i64, ptr %l73, !tbaa !24
  %t149 = icmp sle i64 %t147, %t148
  br i1 %t149, label %bb55, label %bb56
bb54:
  call void @__olang_check_failed(ptr @olang_loc_12d4b4c126d079e6_1af6ce2ce1af3fd2)
  unreachable
bb55:
  %t151 = getelementptr { i64, ptr }, ptr %l70, i32 0, i32 1
  %t152 = load ptr, ptr %t151, !tbaa !27
  %t153 = load i64, ptr %l71, !tbaa !24
  %t154 = load i64, ptr %l72, !tbaa !24
  %t155 = getelementptr i8, ptr %t152, i64 %t153
  %t156 = sub i64 %t154, %t153
  %t157 = insertvalue { i64, ptr } undef, i64 %t156, 0
  %t158 = insertvalue { i64, ptr } %t157, ptr %t155, 1
  %t160 = extractvalue { i64, ptr } %t158, 1
  %t161 = extractvalue { i64, ptr } %t158, 0
  %t162 = load i64, ptr %l68
  %t163 = inttoptr i64 %t162 to ptr
  %t164 = call ptr @__olang_held_alloc(ptr %t163, i64 %t161)
  call void @olang_textcopy(ptr %t164, ptr %t160, i64 %t161)
  %t165 = insertvalue { i64, ptr } undef, i64 %t161, 0
  %t166 = insertvalue { i64, ptr } %t165, ptr %t164, 1
  %t168 = load ptr, ptr %l67, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %t168, { i64, ptr } %t166)
  br label %bb57
bb56:
  call void @__olang_check_failed(ptr @olang_loc_12d4b4c126d079e6_1af6ce2ce1af3fd2)
  unreachable
bb57:
  %t170 = load i64, ptr %l4, !tbaa !24
  store i64 %t170, ptr %l2, !tbaa !24
  br label %bb58
bb58:
  br label %bb2
bb59:
  %t172 = load ptr, ptr %lp1
  %t174 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %v1, ptr %v1, ptr %t172)
  store { i64, ptr } %t174, ptr %l82
  br label %bb60
bb60:
  %t175 = load { i64, ptr }, ptr %l82, !tbaa !27
  store { i64, ptr } %t175, ptr %l83, !tbaa !27
  %t176 = load { i64, ptr }, ptr %l83, !tbaa !27
  %t177 = extractvalue { i64, ptr } %t176, 0
  store i64 %t177, ptr %l84, !tbaa !24
  %t178 = load i64, ptr %l84, !tbaa !24
  %t179 = mul i64 %t178, 16
  %t180 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t179)
  %t181 = insertvalue { i64, ptr } undef, i64 %t178, 0
  %t182 = insertvalue { i64, ptr } %t181, ptr %t180, 1
  store { i64, ptr } %t182, ptr %l85, !tbaa !27
  %t183 = getelementptr { i64, ptr }, ptr %l85, i32 0, i32 1
  %t184 = load ptr, ptr %t183, !tbaa !27
  %t185 = getelementptr { i64, ptr }, ptr %l83, i32 0, i32 1
  %t186 = load ptr, ptr %t185, !tbaa !27
  %t187 = load i64, ptr %l84, !tbaa !24
  %t188 = mul i64 %t187, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t184, ptr %t186, i64 %t188, i1 false)
  %t189 = load { i64, ptr }, ptr %l85, !tbaa !27
  store { i64, ptr } %t189, ptr %l83, !tbaa !27
  %t190 = load { i64, ptr }, ptr %l83, !tbaa !27
  store { i64, ptr } %t190, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2fbindgen_2enumBits(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca i1
  %l3 = alloca i1
  %l5 = alloca i1
  %l8 = alloca i1
  %l14 = alloca i64
  %l15 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca i64
  %l23 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca i32
  %l26 = alloca i64
  %l27 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d320, i32 0, i32 1) })
  store i1 %t3, ptr %l2
  br label %bb1
bb1:
  %t4 = load i1, ptr %l2, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l3, !tbaa !21
  br label %bb5
bb3:
  %t5 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t7 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t5, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d321, i32 0, i32 1) })
  store i1 %t7, ptr %l5
  br label %bb4
bb4:
  %t8 = load i1, ptr %l5, !tbaa !21
  store i1 %t8, ptr %l3, !tbaa !21
  br label %bb5
bb5:
  %t9 = load i1, ptr %l3, !tbaa !21
  br i1 %t9, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s0)
  store i64 8, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t11 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t13 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t11, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d322, i32 0, i32 1) })
  store i1 %t13, ptr %l8
  br label %bb9
bb9:
  %t14 = load i1, ptr %l8, !tbaa !21
  br i1 %t14, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s0)
  store i64 16, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t16 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t18 = extractvalue { i64, ptr } %t16, 0
  %t20 = icmp slt i64 %t18, 2
  br i1 %t20, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s0)
  store i64 0, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  %t23 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t23, ptr %l15, !tbaa !27
  %t24 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t27 = extractvalue { i64, ptr } %t24, 0
  store i64 %t27, ptr %l18, !tbaa !24
  %t28 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t28, 0
  store i64 %t29, ptr %l19, !tbaa !24
  %t30 = icmp sge i64 1, 0
  br i1 %t30, label %bb16, label %bb17
bb16:
  %t32 = load i64, ptr %l18, !tbaa !24
  %t33 = icmp sle i64 1, %t32
  br i1 %t33, label %bb18, label %bb19
bb17:
  call void @__olang_check_failed(ptr @olang_loc_b9ed3bac91748577_8bd4ae03d42ae063)
  unreachable
bb18:
  %t35 = load i64, ptr %l18, !tbaa !24
  %t36 = load i64, ptr %l19, !tbaa !24
  %t37 = icmp sle i64 %t35, %t36
  br i1 %t37, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @olang_loc_b9ed3bac91748577_8bd4ae03d42ae063)
  unreachable
bb20:
  %t39 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !27
  %t41 = load i64, ptr %l18, !tbaa !24
  %t42 = getelementptr i8, ptr %t40, i64 1
  %t43 = sub i64 %t41, 1
  %t44 = insertvalue { i64, ptr } undef, i64 %t43, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t42, 1
  store { i64, ptr } %t45, ptr %l23, !tbaa !27
  %t46 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s0, i64 10)
  %t47 = extractvalue { i32, i64 } %t46, 1
  %t48 = extractvalue { i32, i64 } %t46, 0
  store i32 %t48, ptr %l25
  %t49 = icmp ne i32 %t48, 0
  br i1 %t49, label %bb23, label %ok.50, !prof !99
ok.50:
  store i64 %t47, ptr %l24
  br label %bb22
bb21:
  call void @__olang_check_failed(ptr @olang_loc_b9ed3bac91748577_8bd4ae03d42ae063)
  unreachable
bb22:
  %t51 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t52 = load i64, ptr %l24, !tbaa !24
  %t53 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %v0, { i64, ptr } %t51, i64 %t52)
  %t54 = extractvalue { i32, i64 } %t53, 1
  %t55 = extractvalue { i32, i64 } %t53, 0
  store i32 %t55, ptr %l27
  %t56 = icmp ne i32 %t55, 0
  br i1 %t56, label %bb26, label %ok.57, !prof !99
ok.57:
  store i64 %t54, ptr %l26
  br label %bb25
bb23:
  br label %bb24
bb24:
  store i64 0, ptr %l14, !tbaa !24
  br label %bb27
bb25:
  %t58 = load i64, ptr %l26, !tbaa !24
  store i64 %t58, ptr %l14, !tbaa !24
  br label %bb27
bb26:
  br label %bb24
bb27:
  call void @__olang_scope_close(ptr %s0)
  %t59 = load i64, ptr %l14, !tbaa !24
  store i64 %t59, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, ptr } @compiler_2fbindgen_2eplainCall(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d323, i32 0, i32 1) }, ptr %l4, !tbaa !27
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d324, i32 0, i32 1) }, ptr %l5, !tbaa !27
  %t4 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t6 = call { i64, ptr } @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eReplace_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %a0, { i64, ptr } %t4, { i64, ptr } %t5)
  store { i64, ptr } %t6, ptr %l6
  br label %bb1
bb1:
  %t7 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d325, i32 0, i32 1) }, ptr %l9, !tbaa !27
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d326, i32 0, i32 1) }, ptr %l10, !tbaa !27
  %t11 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t12 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t13 = call { i64, ptr } @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eReplace_3cstd_2fprelude_2ftext_3aChar_3e(ptr %s0, ptr %s0, ptr %s0, ptr %v1, { i64, ptr } %t7, { i64, ptr } %t11, { i64, ptr } %t12)
  store { i64, ptr } %t13, ptr %l11
  br label %bb2
bb2:
  %t14 = load { i64, ptr }, ptr %l11, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t14, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @compiler_2fbindgen_2erun(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, ptr %a3) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca [2 x { i64, ptr }]
  %l7 = alloca { i64, ptr }
  %l8 = alloca %"compiler/bindgen:gen"
  %l9 = alloca { i64, ptr }
  %l10 = alloca %"std/os:Output"
  %l11 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l12 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l13 = alloca %"std/prelude/text:StringBuilder"
  %l14 = alloca ptr
  %l15 = alloca i64
  %l16 = alloca i64
  %l18 = alloca ptr
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca ptr
  %l23 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca { i64, ptr }
  %l26 = alloca i64
  %l27 = alloca i64
  %l29 = alloca { i64, ptr }
  %l30 = alloca i64
  %l32 = alloca { i64, ptr }
  %l34 = alloca i1
  %l36 = alloca { i64, ptr }
  %l38 = alloca { i64, ptr }
  %l40 = alloca { i64, ptr }
  %l41 = alloca i32
  %l43 = alloca i1
  %l53 = alloca i1
  %l61 = alloca { i64, ptr }
  %l62 = alloca { i64, ptr }
  %l63 = alloca i32
  %l65 = alloca i1
  %l69 = alloca { i64, ptr }
  %l75 = alloca { i64, ptr }
  %l77 = alloca %"compiler/bindgen:gen"
  %l85 = alloca i32
  %l87 = alloca i1
  %l95 = alloca i32
  %l97 = alloca i32
  %l99 = alloca i1
  %l102 = alloca %"std/os:Output"
  %l105 = alloca { i64, ptr }
  %l106 = alloca %"std/os:Output"
  %l107 = alloca i32
  %l109 = alloca i1
  %l111 = alloca { i64, ptr }
  %l112 = alloca i32
  %l114 = alloca i32
  %l116 = alloca i1
  %l127 = alloca i32
  %l129 = alloca i32
  %l131 = alloca i1
  %l134 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l141 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l142 = alloca %"std/prelude/text:StringBuilder"
  %l148 = alloca i64
  %l150 = alloca i64
  %l156 = alloca i64
  %l157 = alloca ptr
  %l158 = alloca i64
  %l159 = alloca i64
  %l162 = alloca %"compiler/bindgen:cMacro"
  %l169 = alloca { i64, ptr }
  %l171 = alloca { i64, ptr }
  %l174 = alloca i32
  %l176 = alloca i1
  %l184 = alloca i32
  %l186 = alloca i32
  %l188 = alloca i1
  %l191 = alloca ptr
  %l192 = alloca ptr
  %l193 = alloca { i64, ptr }
  %l198 = alloca ptr
  %l199 = alloca i32
  %l201 = alloca i1
  %l208 = alloca i32
  %l210 = alloca i32
  %l212 = alloca i1
  %l219 = alloca { i64, ptr }
  %l227 = alloca { i64, ptr }
  %l231 = alloca { i64, ptr }
  %l233 = alloca { i64, ptr }
  %l235 = alloca i1
  %l237 = alloca i1
  %l239 = alloca i1
  %l241 = alloca i64
  %l243 = alloca i64
  %l244 = alloca i64
  %l248 = alloca { i64, ptr }
  %l249 = alloca i64
  %l250 = alloca i32
  %l251 = alloca i64
  %l252 = alloca i32
  %l255 = alloca i1
  %l256 = alloca i64
  %l258 = alloca i64
  %l261 = alloca { i64, ptr }
  %l269 = alloca { i64, ptr }
  %l273 = alloca { i64, ptr }
  %l275 = alloca i1
  %l276 = alloca i64
  %l277 = alloca { i64, ptr }
  %l278 = alloca i64
  %l279 = alloca i32
  %l280 = alloca i64
  %l281 = alloca i32
  %l282 = alloca ptr
  %l283 = alloca ptr
  %l286 = alloca i64
  %l287 = alloca %"compiler/bindgen:cMacro"
  %l297 = alloca ptr
  %l298 = alloca { i64, ptr }
  %l304 = alloca i32
  %l306 = alloca i1
  %l313 = alloca i32
  %l315 = alloca i32
  %l317 = alloca i1
  %l324 = alloca { i64, ptr }
  %l326 = alloca i1
  %l328 = alloca i32
  %l330 = alloca i1
  %l333 = alloca i32
  %l335 = alloca i32
  %l337 = alloca i1
  %l340 = alloca i32
  %l342 = alloca i32
  %l344 = alloca i1
  %l349 = alloca i32
  %l351 = alloca i1
  %l359 = alloca i32
  %l361 = alloca i32
  %l363 = alloca i1
  %l366 = alloca i32
  %l368 = alloca i32
  %l370 = alloca i1
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s25 = alloca %olang.scope
  %s28 = alloca %olang.scope
  %s33 = alloca %olang.scope
  %s38 = alloca %olang.scope
  %s39 = alloca %olang.scope
  %s42 = alloca %olang.scope
  %s43 = alloca %olang.scope
  %s48 = alloca %olang.scope
  %s62 = alloca %olang.scope
  %rv = alloca i32
  %t119 = alloca %"compiler/bindgen:gen", align 8
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d327, i32 0, i32 1) })
  store i1 %t3, ptr %l34
  br label %bb1
bb1:
  %t4 = load i1, ptr %l34, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t5 = load ptr, ptr %l3, !tbaa !29
  store { i64, ptr } { i64 53, ptr getelementptr inbounds (<{ i64, [53 x i8] }>, ptr @.d328, i32 0, i32 1) }, ptr %l36, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l36, !tbaa !27
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %v3, ptr %s1, ptr %t5, { i64, ptr } %t7)
  br label %bb4
bb3:
  br label %bb5
bb4:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  store i32 2, ptr %rv
  br label %ret
bb5:
  %t9 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t11 = call { i32, { i64, ptr } } @std_2fos_2eRealPath(ptr %v0, ptr %s0, { i64, ptr } %t9)
  %t12 = extractvalue { i32, { i64, ptr } } %t11, 1
  %t13 = extractvalue { i32, { i64, ptr } } %t11, 0
  store i32 %t13, ptr %l41
  %t14 = icmp ne i32 %t13, 0
  br i1 %t14, label %bb7, label %ok.15, !prof !99
ok.15:
  store { i64, ptr } %t12, ptr %l40
  br label %bb6
bb6:
  %t16 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t16, ptr %l38, !tbaa !27
  br label %bb12
bb7:
  %t17 = load i32, ptr %l41, !tbaa !23
  %t18 = ashr i32 %t17, 16
  %t20 = icmp eq i32 %t18, 1
  store i1 %t20, ptr %l43, !tbaa !21
  %t21 = load i32, ptr %l41, !tbaa !23
  %t22 = ashr i32 %t21, 16
  %t24 = icmp eq i32 %t22, 1
  br i1 %t24, label %bb8, label %bb9
bb8:
  call void @__olang_errpay_pop()
  br label %bb9
bb9:
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s2
  %t26 = load ptr, ptr %l3, !tbaa !29
  %t27 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t28 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d329, i32 0, i32 1) }, 1
  %t29 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d329, i32 0, i32 1) }, 0
  %t31 = extractvalue { i64, ptr } %t27, 1
  %t32 = extractvalue { i64, ptr } %t27, 0
  %t33 = add i64 %t29, %t32
  %t34 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d330, i32 0, i32 1) }, 1
  %t35 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d330, i32 0, i32 1) }, 0
  %t36 = add i64 %t33, %t35
  %t37 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t36)
  call void @olang_textcopy(ptr %t37, ptr %t28, i64 %t29)
  %t38 = getelementptr i8, ptr %t37, i64 %t29
  call void @olang_textcopy(ptr %t38, ptr %t31, i64 %t32)
  %t39 = getelementptr i8, ptr %t38, i64 %t32
  call void @olang_textcopy(ptr %t39, ptr %t34, i64 %t35)
  %t40 = insertvalue { i64, ptr } undef, i64 %t36, 0
  %t41 = insertvalue { i64, ptr } %t40, ptr %t37, 1
  %t44 = extractvalue { i64, ptr } %t41, 0
  %t45 = extractvalue { i64, ptr } %t41, 1
  %t46 = mul i64 %t44, 1
  %t47 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t46)
  call void @llvm.memcpy.p0.p0.i64(ptr %t47, ptr %t45, i64 %t46, i1 false)
  %t48 = insertvalue { i64, ptr } undef, i64 %t44, 0
  %t49 = insertvalue { i64, ptr } %t48, ptr %t47, 1
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %v3, ptr %s2, ptr %t26, { i64, ptr } %t49)
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  store i32 2, ptr %rv
  br label %ret
bb12:
  %t53 = load { i64, ptr }, ptr %l38, !tbaa !27
  store { i64, ptr } %t53, ptr %l4, !tbaa !27
  %t54 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t56 = call i1 @std_2fos_2eExists(ptr %s0, { i64, ptr } %t54)
  store i1 %t56, ptr %l53
  br label %bb13
bb13:
  %t57 = load i1, ptr %l53, !tbaa !21
  %t58 = xor i1 %t57, true
  br i1 %t58, label %bb14, label %bb15
bb14:
  store %olang.scope zeroinitializer, ptr %s4
  %t60 = load ptr, ptr %l3, !tbaa !29
  %t61 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t62 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d331, i32 0, i32 1) }, 1
  %t63 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d331, i32 0, i32 1) }, 0
  %t65 = extractvalue { i64, ptr } %t61, 1
  %t66 = extractvalue { i64, ptr } %t61, 0
  %t67 = add i64 %t63, %t66
  %t68 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d332, i32 0, i32 1) }, 1
  %t69 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d332, i32 0, i32 1) }, 0
  %t70 = add i64 %t67, %t69
  %t71 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t70)
  call void @olang_textcopy(ptr %t71, ptr %t62, i64 %t63)
  %t72 = getelementptr i8, ptr %t71, i64 %t63
  call void @olang_textcopy(ptr %t72, ptr %t65, i64 %t66)
  %t73 = getelementptr i8, ptr %t72, i64 %t66
  call void @olang_textcopy(ptr %t73, ptr %t68, i64 %t69)
  %t74 = insertvalue { i64, ptr } undef, i64 %t70, 0
  %t75 = insertvalue { i64, ptr } %t74, ptr %t71, 1
  %t78 = extractvalue { i64, ptr } %t75, 0
  %t79 = extractvalue { i64, ptr } %t75, 1
  %t80 = mul i64 %t78, 1
  %t81 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t80)
  call void @llvm.memcpy.p0.p0.i64(ptr %t81, ptr %t79, i64 %t80, i1 false)
  %t82 = insertvalue { i64, ptr } undef, i64 %t78, 0
  %t83 = insertvalue { i64, ptr } %t82, ptr %t81, 1
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %v3, ptr %s4, ptr %t60, { i64, ptr } %t83)
  br label %bb16
bb15:
  br label %bb17
bb16:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  store i32 2, ptr %rv
  br label %ret
bb17:
  %t87 = call { i32, { i64, ptr } } @std_2fos_2eMkTemp(ptr %s0, ptr %s0, ptr %s0, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d333, i32 0, i32 1) }, { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d334, i32 0, i32 1) })
  %t88 = extractvalue { i32, { i64, ptr } } %t87, 1
  %t89 = extractvalue { i32, { i64, ptr } } %t87, 0
  store i32 %t89, ptr %l63
  %t90 = icmp ne i32 %t89, 0
  br i1 %t90, label %bb19, label %ok.91, !prof !99
ok.91:
  store { i64, ptr } %t88, ptr %l62
  br label %bb18
bb18:
  %t92 = load { i64, ptr }, ptr %l62, !tbaa !27
  store { i64, ptr } %t92, ptr %l61, !tbaa !27
  br label %bb24
bb19:
  %t93 = load i32, ptr %l63, !tbaa !23
  %t94 = ashr i32 %t93, 16
  %t96 = icmp eq i32 %t94, 1
  store i1 %t96, ptr %l65, !tbaa !21
  %t97 = load i32, ptr %l63, !tbaa !23
  %t98 = ashr i32 %t97, 16
  %t100 = icmp eq i32 %t98, 1
  br i1 %t100, label %bb20, label %bb21
bb20:
  call void @__olang_errpay_pop()
  br label %bb21
bb21:
  br label %bb22
bb22:
  store %olang.scope zeroinitializer, ptr %s6
  %t102 = load ptr, ptr %l3, !tbaa !29
  store { i64, ptr } { i64 50, ptr getelementptr inbounds (<{ i64, [50 x i8] }>, ptr @.d335, i32 0, i32 1) }, ptr %l69, !tbaa !27
  %t104 = load { i64, ptr }, ptr %l69, !tbaa !27
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %v3, ptr %s6, ptr %t102, { i64, ptr } %t104)
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  store i32 2, ptr %rv
  br label %ret
bb24:
  %t106 = load { i64, ptr }, ptr %l61, !tbaa !27
  store { i64, ptr } %t106, ptr %l5, !tbaa !27
  %t107 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t109 = insertvalue [2 x { i64, ptr }] undef, { i64, ptr } %t107, 0
  %t110 = insertvalue [2 x { i64, ptr }] %t109, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d336, i32 0, i32 1) }, 1
  store [2 x { i64, ptr }] %t110, ptr %l6
  %t113 = insertvalue { i64, ptr } undef, i64 2, 0
  %t114 = insertvalue { i64, ptr } %t113, ptr %l6, 1
  %t116 = call { i64, ptr } @std_2ffilepath_2eJoin(ptr %s0, ptr %s0, { i64, ptr } %t114)
  store { i64, ptr } %t116, ptr %l75
  br label %bb25
bb25:
  %t117 = load { i64, ptr }, ptr %l75, !tbaa !27
  store { i64, ptr } %t117, ptr %l7, !tbaa !27
  %t118 = load { i64, ptr }, ptr %l4, !tbaa !27
  call void @compiler_2fbindgen_3agen_2ector(ptr %t119, ptr %s0, ptr %s0, { i64, ptr } %t118)
  call void @llvm.memmove.p0.p0.i64(ptr %l77, ptr %t119, i64 1128, i1 false)
  br label %bb26
bb26:
  call void @llvm.memmove.p0.p0.i64(ptr %l8, ptr %l77, i64 1128, i1 false)
  %t121 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t122 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d337, i32 0, i32 1) }, 1
  %t123 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d337, i32 0, i32 1) }, 0
  %t125 = extractvalue { i64, ptr } %t121, 1
  %t126 = extractvalue { i64, ptr } %t121, 0
  %t127 = add i64 %t123, %t126
  %t128 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d338, i32 0, i32 1) }, 1
  %t129 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d338, i32 0, i32 1) }, 0
  %t130 = add i64 %t127, %t129
  %t131 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t130)
  call void @olang_textcopy(ptr %t131, ptr %t122, i64 %t123)
  %t132 = getelementptr i8, ptr %t131, i64 %t123
  call void @olang_textcopy(ptr %t132, ptr %t125, i64 %t126)
  %t133 = getelementptr i8, ptr %t132, i64 %t126
  call void @olang_textcopy(ptr %t133, ptr %t128, i64 %t129)
  %t134 = insertvalue { i64, ptr } undef, i64 %t130, 0
  %t135 = insertvalue { i64, ptr } %t134, ptr %t131, 1
  store { i64, ptr } %t135, ptr %l9, !tbaa !27
  %t137 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t138 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t140 = extractvalue { i64, ptr } %t138, 1
  %t141 = extractvalue { i64, ptr } %t138, 0
  %t142 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d339, i32 0, i32 1) }, 1
  %t143 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d339, i32 0, i32 1) }, 0
  %t144 = add i64 %t141, %t143
  %t145 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t144)
  call void @olang_textcopy(ptr %t145, ptr %t140, i64 %t141)
  %t146 = getelementptr i8, ptr %t145, i64 %t141
  call void @olang_textcopy(ptr %t146, ptr %t142, i64 %t143)
  %t147 = insertvalue { i64, ptr } undef, i64 %t144, 0
  %t148 = insertvalue { i64, ptr } %t147, ptr %t145, 1
  %t151 = extractvalue { i64, ptr } %t148, 0
  %t152 = extractvalue { i64, ptr } %t148, 1
  %t153 = mul i64 %t151, 1
  %t154 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t153)
  call void @llvm.memcpy.p0.p0.i64(ptr %t154, ptr %t152, i64 %t153, i1 false)
  %t155 = insertvalue { i64, ptr } undef, i64 %t151, 0
  %t156 = insertvalue { i64, ptr } %t155, ptr %t154, 1
  %t159 = call i32 @std_2fos_2eWriteFile(ptr %s0, ptr %s0, { i64, ptr } %t137, { i64, ptr } %t156)
  store i32 %t159, ptr %l85
  %t160 = icmp ne i32 %t159, 0
  br i1 %t160, label %bb28, label %ok.161, !prof !99
ok.161:
  br label %bb27
bb27:
  br label %bb39
bb28:
  %t162 = load i32, ptr %l85, !tbaa !23
  %t163 = ashr i32 %t162, 16
  %t165 = icmp eq i32 %t163, 1
  store i1 %t165, ptr %l87, !tbaa !21
  %t166 = load i32, ptr %l85, !tbaa !23
  %t167 = ashr i32 %t166, 16
  %t169 = icmp eq i32 %t167, 1
  br i1 %t169, label %bb29, label %bb30
bb29:
  call void @__olang_errpay_pop()
  br label %bb30
bb30:
  br label %bb31
bb31:
  store %olang.scope zeroinitializer, ptr %s9
  %t171 = load ptr, ptr %l3, !tbaa !29
  %t172 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t173 = extractvalue { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d340, i32 0, i32 1) }, 1
  %t174 = extractvalue { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d340, i32 0, i32 1) }, 0
  %t176 = extractvalue { i64, ptr } %t172, 1
  %t177 = extractvalue { i64, ptr } %t172, 0
  %t178 = add i64 %t174, %t177
  %t179 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d341, i32 0, i32 1) }, 1
  %t180 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d341, i32 0, i32 1) }, 0
  %t181 = add i64 %t178, %t180
  %t182 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t181)
  call void @olang_textcopy(ptr %t182, ptr %t173, i64 %t174)
  %t183 = getelementptr i8, ptr %t182, i64 %t174
  call void @olang_textcopy(ptr %t183, ptr %t176, i64 %t177)
  %t184 = getelementptr i8, ptr %t183, i64 %t177
  call void @olang_textcopy(ptr %t184, ptr %t179, i64 %t180)
  %t185 = insertvalue { i64, ptr } undef, i64 %t181, 0
  %t186 = insertvalue { i64, ptr } %t185, ptr %t182, 1
  %t189 = extractvalue { i64, ptr } %t186, 0
  %t190 = extractvalue { i64, ptr } %t186, 1
  %t191 = mul i64 %t189, 1
  %t192 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t191)
  call void @llvm.memcpy.p0.p0.i64(ptr %t192, ptr %t190, i64 %t191, i1 false)
  %t193 = insertvalue { i64, ptr } undef, i64 %t189, 0
  %t194 = insertvalue { i64, ptr } %t193, ptr %t192, 1
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %v3, ptr %s9, ptr %t171, { i64, ptr } %t194)
  br label %bb32
bb32:
  store i32 2, ptr %l95, !tbaa !23
  call void @__olang_scope_close(ptr %s9)
  %t197 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t199 = call i32 @std_2fos_2eRemoveAll(ptr %s0, { i64, ptr } %t197)
  store i32 %t199, ptr %l97
  %t200 = icmp ne i32 %t199, 0
  br i1 %t200, label %bb34, label %ok.201, !prof !99
ok.201:
  br label %bb33
bb33:
  br label %bb38
bb34:
  %t202 = load i32, ptr %l97, !tbaa !23
  %t203 = ashr i32 %t202, 16
  %t205 = icmp eq i32 %t203, 1
  store i1 %t205, ptr %l99, !tbaa !21
  %t206 = load i32, ptr %l97, !tbaa !23
  %t207 = ashr i32 %t206, 16
  %t209 = icmp eq i32 %t207, 1
  br i1 %t209, label %bb35, label %bb36
bb35:
  call void @__olang_errpay_pop()
  br label %bb36
bb36:
  br label %bb37
bb37:
  br label %bb38
bb38:
  call void @__olang_scope_close(ptr %s0)
  %t211 = load i32, ptr %l95, !tbaa !23
  store i32 %t211, ptr %rv
  br label %ret
bb39:
  %t212 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t213 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t214 = mul i64 7, 16
  %t215 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t214)
  %t216 = insertvalue { i64, ptr } undef, i64 7, 0
  %t217 = insertvalue { i64, ptr } %t216, ptr %t215, 1
  store { i64, ptr } %t217, ptr %l105, !tbaa !27
  %t219 = getelementptr { i64, ptr }, ptr %l105, i32 0, i32 1
  %t220 = load ptr, ptr %t219, !tbaa !27
  %t221 = getelementptr { i64, ptr }, ptr %t220, i64 0
  store { i64, ptr } %t212, ptr %t221, !tbaa !37
  %t222 = getelementptr { i64, ptr }, ptr %l105, i32 0, i32 1
  %t223 = load ptr, ptr %t222, !tbaa !27
  %t224 = getelementptr { i64, ptr }, ptr %t223, i64 1
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d342, i32 0, i32 1) }, ptr %t224, !tbaa !37
  %t225 = getelementptr { i64, ptr }, ptr %l105, i32 0, i32 1
  %t226 = load ptr, ptr %t225, !tbaa !27
  %t227 = getelementptr { i64, ptr }, ptr %t226, i64 2
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d343, i32 0, i32 1) }, ptr %t227, !tbaa !37
  %t228 = getelementptr { i64, ptr }, ptr %l105, i32 0, i32 1
  %t229 = load ptr, ptr %t228, !tbaa !27
  %t230 = getelementptr { i64, ptr }, ptr %t229, i64 3
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d344, i32 0, i32 1) }, ptr %t230, !tbaa !37
  %t231 = getelementptr { i64, ptr }, ptr %l105, i32 0, i32 1
  %t232 = load ptr, ptr %t231, !tbaa !27
  %t233 = getelementptr { i64, ptr }, ptr %t232, i64 4
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d345, i32 0, i32 1) }, ptr %t233, !tbaa !37
  %t234 = getelementptr { i64, ptr }, ptr %l105, i32 0, i32 1
  %t235 = load ptr, ptr %t234, !tbaa !27
  %t236 = getelementptr { i64, ptr }, ptr %t235, i64 5
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d346, i32 0, i32 1) }, ptr %t236, !tbaa !37
  %t238 = getelementptr { i64, ptr }, ptr %l105, i32 0, i32 1
  %t239 = load ptr, ptr %t238, !tbaa !27
  %t240 = getelementptr { i64, ptr }, ptr %t239, i64 6
  store { i64, ptr } %t213, ptr %t240, !tbaa !37
  %t241 = load { i64, ptr }, ptr %l105, !tbaa !27
  %t242 = call { i32, %"std/os:Output" } @compiler_2fbindgen_2eclangSays(ptr %s0, ptr %s0, { i64, ptr } %t241)
  %t243 = extractvalue { i32, %"std/os:Output" } %t242, 1
  %t244 = extractvalue { i32, %"std/os:Output" } %t242, 0
  store i32 %t244, ptr %l107
  %t245 = icmp ne i32 %t244, 0
  br i1 %t245, label %bb41, label %ok.246, !prof !99
ok.246:
  store %"std/os:Output" %t243, ptr %l106
  br label %bb40
bb40:
  %t247 = load %"std/os:Output", ptr %l106
  store %"std/os:Output" %t247, ptr %l102
  br label %bb50
bb41:
  %t248 = load i32, ptr %l107, !tbaa !23
  %t249 = ashr i32 %t248, 16
  %t251 = icmp eq i32 %t249, 1
  store i1 %t251, ptr %l109, !tbaa !21
  br label %bb42
bb42:
  store %olang.scope zeroinitializer, ptr %s14
  %t252 = load ptr, ptr %l3, !tbaa !29
  store { i64, ptr } { i64 39, ptr getelementptr inbounds (<{ i64, [39 x i8] }>, ptr @.d347, i32 0, i32 1) }, ptr %l111, !tbaa !27
  %t254 = load { i64, ptr }, ptr %l111, !tbaa !27
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %v3, ptr %s14, ptr %t252, { i64, ptr } %t254)
  br label %bb43
bb43:
  store i32 2, ptr %l112, !tbaa !23
  call void @__olang_scope_close(ptr %s14)
  %t255 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t257 = call i32 @std_2fos_2eRemoveAll(ptr %s0, { i64, ptr } %t255)
  store i32 %t257, ptr %l114
  %t258 = icmp ne i32 %t257, 0
  br i1 %t258, label %bb45, label %ok.259, !prof !99
ok.259:
  br label %bb44
bb44:
  br label %bb49
bb45:
  %t260 = load i32, ptr %l114, !tbaa !23
  %t261 = ashr i32 %t260, 16
  %t263 = icmp eq i32 %t261, 1
  store i1 %t263, ptr %l116, !tbaa !21
  %t264 = load i32, ptr %l114, !tbaa !23
  %t265 = ashr i32 %t264, 16
  %t267 = icmp eq i32 %t265, 1
  br i1 %t267, label %bb46, label %bb47
bb46:
  call void @__olang_errpay_pop()
  br label %bb47
bb47:
  br label %bb48
bb48:
  br label %bb49
bb49:
  call void @__olang_scope_close(ptr %s0)
  %t269 = load i32, ptr %l112, !tbaa !23
  store i32 %t269, ptr %rv
  br label %ret
bb50:
  %t270 = load %"std/os:Output", ptr %l102
  store %"std/os:Output" %t270, ptr %l10
  %t271 = getelementptr %"std/os:Output", ptr %l10, i32 0, i32 0
  %t272 = load i32, ptr %t271, !tbaa !23
  %t274 = icmp ne i32 %t272, 0
  br i1 %t274, label %bb51, label %bb52
bb51:
  store %olang.scope zeroinitializer, ptr %s18
  %t276 = load ptr, ptr %l3, !tbaa !29
  %t277 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t278 = getelementptr %"std/os:Output", ptr %l10, i32 0, i32 2
  %t279 = load { i64, ptr }, ptr %t278, !tbaa !27
  %t280 = extractvalue { i64, ptr } { i64 37, ptr getelementptr inbounds (<{ i64, [37 x i8] }>, ptr @.d348, i32 0, i32 1) }, 1
  %t281 = extractvalue { i64, ptr } { i64 37, ptr getelementptr inbounds (<{ i64, [37 x i8] }>, ptr @.d348, i32 0, i32 1) }, 0
  %t283 = extractvalue { i64, ptr } %t277, 1
  %t284 = extractvalue { i64, ptr } %t277, 0
  %t285 = add i64 %t281, %t284
  %t286 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d349, i32 0, i32 1) }, 1
  %t287 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d349, i32 0, i32 1) }, 0
  %t288 = add i64 %t285, %t287
  %t290 = extractvalue { i64, ptr } %t279, 1
  %t291 = extractvalue { i64, ptr } %t279, 0
  %t292 = add i64 %t288, %t291
  %t293 = call ptr @__olang_scope_alloc(ptr %s18, i64 %t292)
  call void @olang_textcopy(ptr %t293, ptr %t280, i64 %t281)
  %t294 = getelementptr i8, ptr %t293, i64 %t281
  call void @olang_textcopy(ptr %t294, ptr %t283, i64 %t284)
  %t295 = getelementptr i8, ptr %t294, i64 %t284
  call void @olang_textcopy(ptr %t295, ptr %t286, i64 %t287)
  %t296 = getelementptr i8, ptr %t295, i64 %t287
  call void @olang_textcopy(ptr %t296, ptr %t290, i64 %t291)
  %t297 = insertvalue { i64, ptr } undef, i64 %t292, 0
  %t298 = insertvalue { i64, ptr } %t297, ptr %t293, 1
  %t301 = extractvalue { i64, ptr } %t298, 0
  %t302 = extractvalue { i64, ptr } %t298, 1
  %t303 = mul i64 %t301, 1
  %t304 = call ptr @__olang_scope_alloc(ptr %s18, i64 %t303)
  call void @llvm.memcpy.p0.p0.i64(ptr %t304, ptr %t302, i64 %t303, i1 false)
  %t305 = insertvalue { i64, ptr } undef, i64 %t301, 0
  %t306 = insertvalue { i64, ptr } %t305, ptr %t304, 1
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %v3, ptr %s18, ptr %t276, { i64, ptr } %t306)
  br label %bb53
bb52:
  br label %bb60
bb53:
  store i32 1, ptr %l127, !tbaa !23
  call void @__olang_scope_close(ptr %s18)
  %t309 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t311 = call i32 @std_2fos_2eRemoveAll(ptr %s0, { i64, ptr } %t309)
  store i32 %t311, ptr %l129
  %t312 = icmp ne i32 %t311, 0
  br i1 %t312, label %bb55, label %ok.313, !prof !99
ok.313:
  br label %bb54
bb54:
  br label %bb59
bb55:
  %t314 = load i32, ptr %l129, !tbaa !23
  %t315 = ashr i32 %t314, 16
  %t317 = icmp eq i32 %t315, 1
  store i1 %t317, ptr %l131, !tbaa !21
  %t318 = load i32, ptr %l129, !tbaa !23
  %t319 = ashr i32 %t318, 16
  %t321 = icmp eq i32 %t319, 1
  br i1 %t321, label %bb56, label %bb57
bb56:
  call void @__olang_errpay_pop()
  br label %bb57
bb57:
  br label %bb58
bb58:
  br label %bb59
bb59:
  call void @__olang_scope_close(ptr %s0)
  %t323 = load i32, ptr %l127, !tbaa !23
  store i32 %t323, ptr %rv
  br label %ret
bb60:
  %t324 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t324, ptr %l134
  br label %bb61
bb61:
  %t325 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l134
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t325, ptr %l11
  %t326 = getelementptr %"std/os:Output", ptr %l10, i32 0, i32 1
  %t327 = load { i64, ptr }, ptr %t326, !tbaa !27
  %t328 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t329 = load { i64, ptr }, ptr %l4, !tbaa !27
  call void @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ereadMacros(ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %l8, { i64, ptr } %t327, { i64, ptr } %t328, { i64, ptr } %t329, ptr %l11)
  br label %bb62
bb62:
  %t336 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eintMacros(ptr %s0, ptr %s0, ptr %l8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t336, ptr %l141
  br label %bb63
bb63:
  %t337 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l141
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t337, ptr %l12
  %t338 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t338, ptr %l142
  br label %bb64
bb64:
  %t339 = load %"std/prelude/text:StringBuilder", ptr %l142
  store %"std/prelude/text:StringBuilder" %t339, ptr %l13
  %t340 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t342 = extractvalue { i64, ptr } %t340, 1
  %t343 = extractvalue { i64, ptr } %t340, 0
  %t344 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d350, i32 0, i32 1) }, 1
  %t345 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d350, i32 0, i32 1) }, 0
  %t346 = add i64 %t343, %t345
  %t347 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t346)
  call void @olang_textcopy(ptr %t347, ptr %t342, i64 %t343)
  %t348 = getelementptr i8, ptr %t347, i64 %t343
  call void @olang_textcopy(ptr %t348, ptr %t344, i64 %t345)
  %t349 = insertvalue { i64, ptr } undef, i64 %t346, 0
  %t350 = insertvalue { i64, ptr } %t349, ptr %t347, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l13, { i64, ptr } %t350)
  br label %bb65
bb65:
  store ptr %l12, ptr %l14, !tbaa !29
  store i64 0, ptr %l15, !tbaa !24
  br label %bb66
bb66:
  store %olang.scope zeroinitializer, ptr %s25
  %t355 = load i64, ptr %l15, !tbaa !24
  store i64 %t355, ptr %l148, !tbaa !24
  %t356 = load ptr, ptr %l14, !tbaa !29
  %t358 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t356)
  store i64 %t358, ptr %l150
  br label %bb67
bb67:
  %t359 = load i64, ptr %l148, !tbaa !24
  %t360 = load i64, ptr %l150, !tbaa !24
  %t361 = icmp slt i64 %t359, %t360
  %t363 = xor i1 %t361, true
  br i1 %t363, label %bb68, label %bb69
bb68:
  call void @__olang_scope_close(ptr %s25)
  br label %bb75
bb69:
  br label %bb70
bb70:
  %t365 = load i64, ptr %l15, !tbaa !24
  store i64 %t365, ptr %l16, !tbaa !24
  %t367 = load ptr, ptr %l14, !tbaa !29
  %t368 = load i64, ptr %l15, !tbaa !24
  %t371 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t367, i64 %t368)
  store i64 %t371, ptr %l156
  br label %bb71
bb71:
  %t372 = load i64, ptr %l156, !tbaa !24
  store ptr %l13, ptr %l157, !tbaa !29
  %t373 = load i64, ptr %l16, !tbaa !24
  store i64 %t373, ptr %l158, !tbaa !24
  %t374 = load i64, ptr %l16, !tbaa !24
  store i64 %t374, ptr %l159, !tbaa !24
  %t375 = getelementptr %"compiler/bindgen:gen", ptr %l8, i32 0, i32 13
  %t379 = call %"compiler/bindgen:cMacro" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3acMacro_3e_2eAt_3ccompiler_2fbindgen_3acMacro_3e(ptr %s0, ptr %s0, ptr %t375, i64 %t372)
  store %"compiler/bindgen:cMacro" %t379, ptr %l162
  br label %bb72
bb72:
  %t380 = getelementptr %"compiler/bindgen:cMacro", ptr %l162, i32 0, i32 0
  %t381 = load { i64, ptr }, ptr %t380, !tbaa !27
  %t382 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d351, i32 0, i32 1) }, 1
  %t383 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d351, i32 0, i32 1) }, 0
  %t384 = load i64, ptr %l158, !tbaa !24
  %t385 = call i64 @__olang_fmt_i64(ptr null, i64 %t384)
  %t386 = add i64 %t383, %t385
  %t387 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d352, i32 0, i32 1) }, 1
  %t388 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d352, i32 0, i32 1) }, 0
  %t389 = add i64 %t386, %t388
  %t390 = load i64, ptr %l159, !tbaa !24
  %t391 = call i64 @__olang_fmt_i64(ptr null, i64 %t390)
  %t392 = add i64 %t389, %t391
  %t393 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d353, i32 0, i32 1) }, 1
  %t394 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d353, i32 0, i32 1) }, 0
  %t395 = add i64 %t392, %t394
  %t397 = extractvalue { i64, ptr } %t381, 1
  %t398 = extractvalue { i64, ptr } %t381, 0
  %t399 = add i64 %t395, %t398
  %t400 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d354, i32 0, i32 1) }, 1
  %t401 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d354, i32 0, i32 1) }, 0
  %t402 = add i64 %t399, %t401
  %t403 = call ptr @__olang_scope_alloc(ptr %s25, i64 %t402)
  call void @olang_textcopy(ptr %t403, ptr %t382, i64 %t383)
  %t404 = getelementptr i8, ptr %t403, i64 %t383
  %t405 = call i64 @__olang_fmt_i64(ptr %t404, i64 %t384)
  %t406 = getelementptr i8, ptr %t404, i64 %t385
  call void @olang_textcopy(ptr %t406, ptr %t387, i64 %t388)
  %t407 = getelementptr i8, ptr %t406, i64 %t388
  %t408 = call i64 @__olang_fmt_i64(ptr %t407, i64 %t390)
  %t409 = getelementptr i8, ptr %t407, i64 %t391
  call void @olang_textcopy(ptr %t409, ptr %t393, i64 %t394)
  %t410 = getelementptr i8, ptr %t409, i64 %t394
  call void @olang_textcopy(ptr %t410, ptr %t397, i64 %t398)
  %t411 = getelementptr i8, ptr %t410, i64 %t398
  call void @olang_textcopy(ptr %t411, ptr %t400, i64 %t401)
  %t412 = insertvalue { i64, ptr } undef, i64 %t402, 0
  %t413 = insertvalue { i64, ptr } %t412, ptr %t403, 1
  %t415 = load ptr, ptr %l157, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s25, ptr %t415, { i64, ptr } %t413)
  br label %bb73
bb73:
  call void @__olang_scope_close(ptr %s25)
  br label %bb74
bb74:
  %t417 = load i64, ptr %l15, !tbaa !24
  %t420 = add i64 %t417, 1
  store i64 %t420, ptr %l15, !tbaa !24
  br label %bb66
bb75:
  %t422 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t422, ptr %l169, !tbaa !27
  %t424 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s0, ptr %l13)
  store { i64, ptr } %t424, ptr %l171
  br label %bb76
bb76:
  %t425 = load { i64, ptr }, ptr %l171, !tbaa !27
  %t427 = extractvalue { i64, ptr } %t425, 0
  %t428 = extractvalue { i64, ptr } %t425, 1
  %t429 = mul i64 %t427, 1
  %t430 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t429)
  call void @llvm.memcpy.p0.p0.i64(ptr %t430, ptr %t428, i64 %t429, i1 false)
  %t431 = insertvalue { i64, ptr } undef, i64 %t427, 0
  %t432 = insertvalue { i64, ptr } %t431, ptr %t430, 1
  %t433 = load { i64, ptr }, ptr %l169, !tbaa !27
  %t435 = call i32 @std_2fos_2eWriteFile(ptr %s0, ptr %s0, { i64, ptr } %t433, { i64, ptr } %t432)
  store i32 %t435, ptr %l174
  %t436 = icmp ne i32 %t435, 0
  br i1 %t436, label %bb78, label %ok.437, !prof !99
ok.437:
  br label %bb77
bb77:
  br label %bb89
bb78:
  %t438 = load i32, ptr %l174, !tbaa !23
  %t439 = ashr i32 %t438, 16
  %t441 = icmp eq i32 %t439, 1
  store i1 %t441, ptr %l176, !tbaa !21
  %t442 = load i32, ptr %l174, !tbaa !23
  %t443 = ashr i32 %t442, 16
  %t445 = icmp eq i32 %t443, 1
  br i1 %t445, label %bb79, label %bb80
bb79:
  call void @__olang_errpay_pop()
  br label %bb80
bb80:
  br label %bb81
bb81:
  store %olang.scope zeroinitializer, ptr %s28
  %t447 = load ptr, ptr %l3, !tbaa !29
  %t448 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t449 = extractvalue { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d355, i32 0, i32 1) }, 1
  %t450 = extractvalue { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d355, i32 0, i32 1) }, 0
  %t452 = extractvalue { i64, ptr } %t448, 1
  %t453 = extractvalue { i64, ptr } %t448, 0
  %t454 = add i64 %t450, %t453
  %t455 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d356, i32 0, i32 1) }, 1
  %t456 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d356, i32 0, i32 1) }, 0
  %t457 = add i64 %t454, %t456
  %t458 = call ptr @__olang_scope_alloc(ptr %s28, i64 %t457)
  call void @olang_textcopy(ptr %t458, ptr %t449, i64 %t450)
  %t459 = getelementptr i8, ptr %t458, i64 %t450
  call void @olang_textcopy(ptr %t459, ptr %t452, i64 %t453)
  %t460 = getelementptr i8, ptr %t459, i64 %t453
  call void @olang_textcopy(ptr %t460, ptr %t455, i64 %t456)
  %t461 = insertvalue { i64, ptr } undef, i64 %t457, 0
  %t462 = insertvalue { i64, ptr } %t461, ptr %t458, 1
  %t465 = extractvalue { i64, ptr } %t462, 0
  %t466 = extractvalue { i64, ptr } %t462, 1
  %t467 = mul i64 %t465, 1
  %t468 = call ptr @__olang_scope_alloc(ptr %s28, i64 %t467)
  call void @llvm.memcpy.p0.p0.i64(ptr %t468, ptr %t466, i64 %t467, i1 false)
  %t469 = insertvalue { i64, ptr } undef, i64 %t465, 0
  %t470 = insertvalue { i64, ptr } %t469, ptr %t468, 1
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %v3, ptr %s28, ptr %t447, { i64, ptr } %t470)
  br label %bb82
bb82:
  store i32 2, ptr %l184, !tbaa !23
  call void @__olang_scope_close(ptr %s28)
  %t473 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t475 = call i32 @std_2fos_2eRemoveAll(ptr %s0, { i64, ptr } %t473)
  store i32 %t475, ptr %l186
  %t476 = icmp ne i32 %t475, 0
  br i1 %t476, label %bb84, label %ok.477, !prof !99
ok.477:
  br label %bb83
bb83:
  br label %bb88
bb84:
  %t478 = load i32, ptr %l186, !tbaa !23
  %t479 = ashr i32 %t478, 16
  %t481 = icmp eq i32 %t479, 1
  store i1 %t481, ptr %l188, !tbaa !21
  %t482 = load i32, ptr %l186, !tbaa !23
  %t483 = ashr i32 %t482, 16
  %t485 = icmp eq i32 %t483, 1
  br i1 %t485, label %bb85, label %bb86
bb85:
  call void @__olang_errpay_pop()
  br label %bb86
bb86:
  br label %bb87
bb87:
  br label %bb88
bb88:
  call void @__olang_scope_close(ptr %s0)
  %t487 = load i32, ptr %l184, !tbaa !23
  store i32 %t487, ptr %rv
  br label %ret
bb89:
  store ptr %l8, ptr %l192, !tbaa !29
  %t488 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t488, ptr %l193, !tbaa !27
  %t489 = icmp sge i64 0, 0
  br i1 %t489, label %bb90, label %bb91
bb90:
  %t491 = icmp sle i64 0, 576460752303423487
  br i1 %t491, label %bb92, label %bb93
bb91:
  call void @__olang_check_failed(ptr @olang_loc_2d25c1a9d7803e60_587b957d3d0d6154)
  unreachable
bb92:
  %t493 = mul i64 0, 16
  %t494 = insertvalue { i64, ptr } undef, i64 0, 0
  %t495 = insertvalue { i64, ptr } %t494, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t496 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t497 = load ptr, ptr %l192, !tbaa !29
  %t498 = load { i64, ptr }, ptr %l193, !tbaa !27
  %t501 = call { i32, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2edump(ptr %s0, ptr %v2, ptr %s0, ptr %s0, ptr %s0, ptr %t497, { i64, ptr } %t498, { i64, ptr } %t495, { i64, ptr } %t496)
  %t502 = extractvalue { i32, ptr } %t501, 1
  %t503 = extractvalue { i32, ptr } %t501, 0
  store i32 %t503, ptr %l199
  %t504 = icmp ne i32 %t503, 0
  br i1 %t504, label %bb95, label %ok.505, !prof !99
ok.505:
  store ptr %t502, ptr %l198
  br label %bb94
bb93:
  call void @__olang_check_failed(ptr @olang_loc_2d25c1a9d7803e60_587b957d3d0d6154)
  unreachable
bb94:
  %t506 = load ptr, ptr %l198, !tbaa !29
  store ptr %t506, ptr %l191, !tbaa !29
  br label %bb104
bb95:
  %t507 = load i32, ptr %l199, !tbaa !23
  %t508 = ashr i32 %t507, 16
  %t510 = icmp eq i32 %t508, 1
  store i1 %t510, ptr %l201, !tbaa !21
  br label %bb96
bb96:
  store %olang.scope zeroinitializer, ptr %s33
  %t511 = load ptr, ptr %l3, !tbaa !29
  %t512 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t513 = getelementptr %"compiler/bindgen:gen", ptr %l8, i32 0, i32 26
  %t514 = load { i64, ptr }, ptr %t513, !tbaa !27
  %t515 = extractvalue { i64, ptr } { i64 37, ptr getelementptr inbounds (<{ i64, [37 x i8] }>, ptr @.d357, i32 0, i32 1) }, 1
  %t516 = extractvalue { i64, ptr } { i64 37, ptr getelementptr inbounds (<{ i64, [37 x i8] }>, ptr @.d357, i32 0, i32 1) }, 0
  %t518 = extractvalue { i64, ptr } %t512, 1
  %t519 = extractvalue { i64, ptr } %t512, 0
  %t520 = add i64 %t516, %t519
  %t521 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d358, i32 0, i32 1) }, 1
  %t522 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d358, i32 0, i32 1) }, 0
  %t523 = add i64 %t520, %t522
  %t525 = extractvalue { i64, ptr } %t514, 1
  %t526 = extractvalue { i64, ptr } %t514, 0
  %t527 = add i64 %t523, %t526
  %t528 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d359, i32 0, i32 1) }, 1
  %t529 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d359, i32 0, i32 1) }, 0
  %t530 = add i64 %t527, %t529
  %t531 = call ptr @__olang_scope_alloc(ptr %s33, i64 %t530)
  call void @olang_textcopy(ptr %t531, ptr %t515, i64 %t516)
  %t532 = getelementptr i8, ptr %t531, i64 %t516
  call void @olang_textcopy(ptr %t532, ptr %t518, i64 %t519)
  %t533 = getelementptr i8, ptr %t532, i64 %t519
  call void @olang_textcopy(ptr %t533, ptr %t521, i64 %t522)
  %t534 = getelementptr i8, ptr %t533, i64 %t522
  call void @olang_textcopy(ptr %t534, ptr %t525, i64 %t526)
  %t535 = getelementptr i8, ptr %t534, i64 %t526
  call void @olang_textcopy(ptr %t535, ptr %t528, i64 %t529)
  %t536 = insertvalue { i64, ptr } undef, i64 %t530, 0
  %t537 = insertvalue { i64, ptr } %t536, ptr %t531, 1
  %t540 = extractvalue { i64, ptr } %t537, 0
  %t541 = extractvalue { i64, ptr } %t537, 1
  %t542 = mul i64 %t540, 1
  %t543 = call ptr @__olang_scope_alloc(ptr %s33, i64 %t542)
  call void @llvm.memcpy.p0.p0.i64(ptr %t543, ptr %t541, i64 %t542, i1 false)
  %t544 = insertvalue { i64, ptr } undef, i64 %t540, 0
  %t545 = insertvalue { i64, ptr } %t544, ptr %t543, 1
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %v3, ptr %s33, ptr %t511, { i64, ptr } %t545)
  br label %bb97
bb97:
  store i32 1, ptr %l208, !tbaa !23
  call void @__olang_scope_close(ptr %s33)
  %t548 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t550 = call i32 @std_2fos_2eRemoveAll(ptr %s0, { i64, ptr } %t548)
  store i32 %t550, ptr %l210
  %t551 = icmp ne i32 %t550, 0
  br i1 %t551, label %bb99, label %ok.552, !prof !99
ok.552:
  br label %bb98
bb98:
  br label %bb103
bb99:
  %t553 = load i32, ptr %l210, !tbaa !23
  %t554 = ashr i32 %t553, 16
  %t556 = icmp eq i32 %t554, 1
  store i1 %t556, ptr %l212, !tbaa !21
  %t557 = load i32, ptr %l210, !tbaa !23
  %t558 = ashr i32 %t557, 16
  %t560 = icmp eq i32 %t558, 1
  br i1 %t560, label %bb100, label %bb101
bb100:
  call void @__olang_errpay_pop()
  br label %bb101
bb101:
  br label %bb102
bb102:
  br label %bb103
bb103:
  call void @__olang_scope_close(ptr %s0)
  %t562 = load i32, ptr %l208, !tbaa !23
  store i32 %t562, ptr %rv
  br label %ret
bb104:
  %t563 = load ptr, ptr %l191, !tbaa !29
  store ptr %t563, ptr %l18, !tbaa !29
  %t564 = load ptr, ptr %l18, !tbaa !29
  %t565 = load { i64, ptr }, ptr %l7, !tbaa !27
  call void @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eread(ptr %s0, ptr %s0, ptr %s0, ptr %l8, ptr %t564, { i64, ptr } %t565)
  br label %bb105
bb105:
  %t569 = getelementptr %"compiler/bindgen:gen", ptr %l8, i32 0, i32 27
  store i64 0, ptr %t569, !tbaa !24
  store %olang.scope zeroinitializer, ptr %s38
  %t570 = load ptr, ptr %l18, !tbaa !29
  %t572 = call { i64, ptr } @compiler_2fbindgen_2einner(ptr %s0, ptr %s38, ptr %t570)
  store { i64, ptr } %t572, ptr %l219
  br label %bb106
bb106:
  %t573 = load { i64, ptr }, ptr %l219, !tbaa !27
  store { i64, ptr } %t573, ptr %l19, !tbaa !27
  store i64 0, ptr %l20, !tbaa !24
  %t575 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t577 = extractvalue { i64, ptr } %t575, 0
  store i64 %t577, ptr %l21, !tbaa !24
  br label %bb107
bb107:
  store %olang.scope zeroinitializer, ptr %s39
  %t579 = load i64, ptr %l20, !tbaa !24
  %t580 = load i64, ptr %l21, !tbaa !24
  %t583 = icmp slt i64 %t579, %t580
  %t585 = xor i1 %t583, true
  br i1 %t585, label %bb108, label %bb109
bb108:
  call void @__olang_scope_close(ptr %s39)
  br label %bb162
bb109:
  br label %bb110
bb110:
  %t587 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t587, ptr %l227, !tbaa !27
  %t588 = load i64, ptr %l20, !tbaa !24
  %t590 = getelementptr { i64, ptr }, ptr %l227, i32 0, i32 1
  %t591 = load ptr, ptr %t590, !tbaa !27
  %t592 = getelementptr ptr, ptr %t591, i64 %t588
  %t593 = load ptr, ptr %t592, !tbaa !39
  store ptr %t593, ptr %l22, !tbaa !29
  %t595 = load ptr, ptr %l22, !tbaa !29
  %t597 = call { i64, ptr } @compiler_2fbindgen_2etext(ptr %s38, ptr %s39, ptr %s39, ptr %t595, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d360, i32 0, i32 1) })
  store { i64, ptr } %t597, ptr %l231
  br label %bb111
bb111:
  %t598 = load { i64, ptr }, ptr %l231, !tbaa !27
  store { i64, ptr } %t598, ptr %l23, !tbaa !27
  %t599 = load ptr, ptr %l22, !tbaa !29
  %t601 = call { i64, ptr } @compiler_2fbindgen_2etext(ptr %s38, ptr %s39, ptr %s39, ptr %t599, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d361, i32 0, i32 1) })
  store { i64, ptr } %t601, ptr %l233
  br label %bb112
bb112:
  %t602 = load { i64, ptr }, ptr %l233, !tbaa !27
  %t604 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s39, ptr %s39, { i64, ptr } %t602, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d362, i32 0, i32 1) })
  store i1 %t604, ptr %l235
  br label %bb113
bb113:
  %t605 = load i1, ptr %l235, !tbaa !21
  %t606 = xor i1 %t605, true
  br i1 %t606, label %bb114, label %bb115
bb114:
  store i1 true, ptr %l237, !tbaa !21
  br label %bb117
bb115:
  %t608 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t610 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s39, ptr %s39, { i64, ptr } %t608, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d363, i32 0, i32 1) })
  store i1 %t610, ptr %l239
  br label %bb116
bb116:
  %t611 = load i1, ptr %l239, !tbaa !21
  %t612 = xor i1 %t611, true
  store i1 %t612, ptr %l237, !tbaa !21
  br label %bb117
bb117:
  %t614 = load i1, ptr %l237, !tbaa !21
  br i1 %t614, label %bb118, label %bb119
bb118:
  call void @__olang_scope_close(ptr %s39)
  br label %bb161
bb119:
  br label %bb120
bb120:
  %t615 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t617 = extractvalue { i64, ptr } %t615, 0
  store i64 %t617, ptr %l243, !tbaa !24
  %t618 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t619 = extractvalue { i64, ptr } %t618, 0
  store i64 %t619, ptr %l244, !tbaa !24
  %t620 = icmp sge i64 9, 0
  br i1 %t620, label %bb121, label %bb122
bb121:
  %t622 = load i64, ptr %l243, !tbaa !24
  %t623 = icmp sle i64 9, %t622
  br i1 %t623, label %bb123, label %bb124
bb122:
  call void @__olang_check_failed(ptr @olang_loc_6d7a361a7a168fed_fbeb1a267b83d779)
  unreachable
bb123:
  %t625 = load i64, ptr %l243, !tbaa !24
  %t626 = load i64, ptr %l244, !tbaa !24
  %t627 = icmp sle i64 %t625, %t626
  br i1 %t627, label %bb125, label %bb126
bb124:
  call void @__olang_check_failed(ptr @olang_loc_6d7a361a7a168fed_fbeb1a267b83d779)
  unreachable
bb125:
  %t629 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t630 = load ptr, ptr %t629, !tbaa !27
  %t631 = load i64, ptr %l243, !tbaa !24
  %t632 = getelementptr i8, ptr %t630, i64 9
  %t633 = sub i64 %t631, 9
  %t634 = insertvalue { i64, ptr } undef, i64 %t633, 0
  %t635 = insertvalue { i64, ptr } %t634, ptr %t632, 1
  store { i64, ptr } %t635, ptr %l248, !tbaa !27
  %t636 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s39, i64 10)
  %t637 = extractvalue { i32, i64 } %t636, 1
  %t638 = extractvalue { i32, i64 } %t636, 0
  store i32 %t638, ptr %l250
  %t639 = icmp ne i32 %t638, 0
  br i1 %t639, label %bb128, label %ok.640, !prof !99
ok.640:
  store i64 %t637, ptr %l249
  br label %bb127
bb126:
  call void @__olang_check_failed(ptr @olang_loc_6d7a361a7a168fed_fbeb1a267b83d779)
  unreachable
bb127:
  %t641 = load { i64, ptr }, ptr %l248, !tbaa !27
  %t642 = load i64, ptr %l249, !tbaa !24
  %t643 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %s39, { i64, ptr } %t641, i64 %t642)
  %t644 = extractvalue { i32, i64 } %t643, 1
  %t645 = extractvalue { i32, i64 } %t643, 0
  store i32 %t645, ptr %l252
  %t646 = icmp ne i32 %t645, 0
  br i1 %t646, label %bb131, label %ok.647, !prof !99
ok.647:
  store i64 %t644, ptr %l251
  br label %bb130
bb128:
  br label %bb129
bb129:
  store i64 -1, ptr %l241, !tbaa !24
  br label %bb132
bb130:
  %t648 = load i64, ptr %l251, !tbaa !24
  store i64 %t648, ptr %l241, !tbaa !24
  br label %bb132
bb131:
  br label %bb129
bb132:
  %t649 = load i64, ptr %l241, !tbaa !24
  store i64 %t649, ptr %l24, !tbaa !24
  %t650 = load i64, ptr %l24, !tbaa !24
  %t652 = icmp slt i64 %t650, 0
  br i1 %t652, label %bb133, label %bb134
bb133:
  store i1 true, ptr %l255, !tbaa !21
  br label %bb136
bb134:
  %t654 = load i64, ptr %l24, !tbaa !24
  store i64 %t654, ptr %l256, !tbaa !24
  %t656 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l12)
  store i64 %t656, ptr %l258
  br label %bb135
bb135:
  %t657 = load i64, ptr %l256, !tbaa !24
  %t658 = load i64, ptr %l258, !tbaa !24
  %t659 = icmp sge i64 %t657, %t658
  store i1 %t659, ptr %l255, !tbaa !21
  br label %bb136
bb136:
  %t661 = load i1, ptr %l255, !tbaa !21
  br i1 %t661, label %bb137, label %bb138
bb137:
  call void @__olang_scope_close(ptr %s39)
  br label %bb161
bb138:
  br label %bb139
bb139:
  store %olang.scope zeroinitializer, ptr %s42
  %t662 = load ptr, ptr %l22, !tbaa !29
  %t664 = call { i64, ptr } @compiler_2fbindgen_2einner(ptr %s38, ptr %s42, ptr %t662)
  store { i64, ptr } %t664, ptr %l261
  br label %bb140
bb140:
  %t665 = load { i64, ptr }, ptr %l261, !tbaa !27
  store { i64, ptr } %t665, ptr %l25, !tbaa !27
  store i64 0, ptr %l26, !tbaa !24
  %t667 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t669 = extractvalue { i64, ptr } %t667, 0
  store i64 %t669, ptr %l27, !tbaa !24
  br label %bb141
bb141:
  store %olang.scope zeroinitializer, ptr %s43
  %t671 = load i64, ptr %l26, !tbaa !24
  %t672 = load i64, ptr %l27, !tbaa !24
  %t675 = icmp slt i64 %t671, %t672
  %t677 = xor i1 %t675, true
  br i1 %t677, label %bb142, label %bb143
bb142:
  call void @__olang_scope_close(ptr %s43)
  br label %bb160
bb143:
  br label %bb144
bb144:
  %t679 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t679, ptr %l269, !tbaa !27
  %t680 = load i64, ptr %l26, !tbaa !24
  %t682 = getelementptr { i64, ptr }, ptr %l269, i32 0, i32 1
  %t683 = load ptr, ptr %t682, !tbaa !27
  %t684 = getelementptr ptr, ptr %t683, i64 %t680
  %t685 = load ptr, ptr %t684, !tbaa !39
  %t689 = call { i64, ptr } @compiler_2fbindgen_2econstValue(ptr %s42, ptr %s43, ptr %t685)
  store { i64, ptr } %t689, ptr %l273
  br label %bb145
bb145:
  %t690 = load { i64, ptr }, ptr %l273, !tbaa !27
  store { i64, ptr } %t690, ptr %l29, !tbaa !27
  %t691 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t693 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s43, ptr %s43, { i64, ptr } %t691, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d364, i32 0, i32 1) })
  store i1 %t693, ptr %l275
  br label %bb146
bb146:
  %t694 = load i1, ptr %l275, !tbaa !21
  br i1 %t694, label %bb147, label %bb148
bb147:
  call void @__olang_scope_close(ptr %s43)
  br label %bb159
bb148:
  br label %bb149
bb149:
  %t695 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t695, ptr %l277, !tbaa !27
  %t696 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s43, i64 10)
  %t697 = extractvalue { i32, i64 } %t696, 1
  %t698 = extractvalue { i32, i64 } %t696, 0
  store i32 %t698, ptr %l279
  %t699 = icmp ne i32 %t698, 0
  br i1 %t699, label %bb151, label %ok.700, !prof !99
ok.700:
  store i64 %t697, ptr %l278
  br label %bb150
bb150:
  %t701 = load { i64, ptr }, ptr %l277, !tbaa !27
  %t702 = load i64, ptr %l278, !tbaa !24
  %t703 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %s43, { i64, ptr } %t701, i64 %t702)
  %t704 = extractvalue { i32, i64 } %t703, 1
  %t705 = extractvalue { i32, i64 } %t703, 0
  store i32 %t705, ptr %l281
  %t706 = icmp ne i32 %t705, 0
  br i1 %t706, label %bb154, label %ok.707, !prof !99
ok.707:
  store i64 %t704, ptr %l280
  br label %bb153
bb151:
  br label %bb152
bb152:
  call void @__olang_scope_close(ptr %s43)
  br label %bb159
bb153:
  %t708 = load i64, ptr %l280, !tbaa !24
  store i64 %t708, ptr %l276, !tbaa !24
  br label %bb155
bb154:
  br label %bb152
bb155:
  %t709 = load i64, ptr %l276, !tbaa !24
  store i64 %t709, ptr %l30, !tbaa !24
  store ptr %l8, ptr %l282, !tbaa !29
  %t710 = getelementptr %"compiler/bindgen:gen", ptr %l8, i32 0, i32 13
  store ptr %t710, ptr %l283, !tbaa !29
  %t711 = load i64, ptr %l24, !tbaa !24
  %t714 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l12, i64 %t711)
  store i64 %t714, ptr %l286
  br label %bb156
bb156:
  %t715 = load ptr, ptr %l283, !tbaa !29
  %t716 = load i64, ptr %l286, !tbaa !24
  %t717 = call %"compiler/bindgen:cMacro" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3acMacro_3e_2eAt_3ccompiler_2fbindgen_3acMacro_3e(ptr %s0, ptr %s0, ptr %t715, i64 %t716)
  store %"compiler/bindgen:cMacro" %t717, ptr %l287
  br label %bb157
bb157:
  %t718 = getelementptr %"compiler/bindgen:cMacro", ptr %l287, i32 0, i32 0
  %t719 = load { i64, ptr }, ptr %t718, !tbaa !27
  %t720 = load i64, ptr %l30, !tbaa !24
  %t721 = load ptr, ptr %l282, !tbaa !29
  call void @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2econstant(ptr %s0, ptr %s0, ptr %t721, { i64, ptr } %t719, i64 %t720)
  br label %bb158
bb158:
  call void @__olang_scope_close(ptr %s43)
  br label %bb159
bb159:
  %t724 = load i64, ptr %l26, !tbaa !24
  %t727 = add i64 %t724, 1
  store i64 %t727, ptr %l26, !tbaa !24
  br label %bb141
bb160:
  call void @__olang_scope_close(ptr %s42)
  call void @__olang_scope_close(ptr %s39)
  br label %bb161
bb161:
  %t729 = load i64, ptr %l20, !tbaa !24
  %t732 = add i64 %t729, 1
  store i64 %t732, ptr %l20, !tbaa !24
  br label %bb107
bb162:
  call void @__olang_scope_close(ptr %s38)
  call void @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eotherConsts(ptr %s0, ptr %l8)
  br label %bb163
bb163:
  store ptr %l8, ptr %l297, !tbaa !29
  %t735 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t735, ptr %l298, !tbaa !27
  %t736 = icmp sge i64 0, 0
  br i1 %t736, label %bb164, label %bb165
bb164:
  %t738 = icmp sle i64 0, 576460752303423487
  br i1 %t738, label %bb166, label %bb167
bb165:
  call void @__olang_check_failed(ptr @olang_loc_3c31d34710cd488e_9478fba938690442)
  unreachable
bb166:
  %t740 = mul i64 0, 16
  %t741 = insertvalue { i64, ptr } undef, i64 0, 0
  %t742 = insertvalue { i64, ptr } %t741, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t743 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t744 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t745 = load ptr, ptr %l297, !tbaa !29
  %t746 = load { i64, ptr }, ptr %l298, !tbaa !27
  %t750 = call i32 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2esizes(ptr %s0, ptr %v2, ptr %s0, ptr %s0, ptr %s0, ptr %t745, { i64, ptr } %t746, { i64, ptr } %t742, { i64, ptr } %t743, { i64, ptr } %t744)
  store i32 %t750, ptr %l304
  %t751 = icmp ne i32 %t750, 0
  br i1 %t751, label %bb169, label %ok.752, !prof !99
ok.752:
  br label %bb168
bb167:
  call void @__olang_check_failed(ptr @olang_loc_3c31d34710cd488e_9478fba938690442)
  unreachable
bb168:
  br label %bb178
bb169:
  %t753 = load i32, ptr %l304, !tbaa !23
  %t754 = ashr i32 %t753, 16
  %t756 = icmp eq i32 %t754, 1
  store i1 %t756, ptr %l306, !tbaa !21
  br label %bb170
bb170:
  store %olang.scope zeroinitializer, ptr %s48
  %t757 = load ptr, ptr %l3, !tbaa !29
  %t758 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t759 = getelementptr %"compiler/bindgen:gen", ptr %l8, i32 0, i32 26
  %t760 = load { i64, ptr }, ptr %t759, !tbaa !27
  %t761 = extractvalue { i64, ptr } { i64 37, ptr getelementptr inbounds (<{ i64, [37 x i8] }>, ptr @.d365, i32 0, i32 1) }, 1
  %t762 = extractvalue { i64, ptr } { i64 37, ptr getelementptr inbounds (<{ i64, [37 x i8] }>, ptr @.d365, i32 0, i32 1) }, 0
  %t764 = extractvalue { i64, ptr } %t758, 1
  %t765 = extractvalue { i64, ptr } %t758, 0
  %t766 = add i64 %t762, %t765
  %t767 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d366, i32 0, i32 1) }, 1
  %t768 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d366, i32 0, i32 1) }, 0
  %t769 = add i64 %t766, %t768
  %t771 = extractvalue { i64, ptr } %t760, 1
  %t772 = extractvalue { i64, ptr } %t760, 0
  %t773 = add i64 %t769, %t772
  %t774 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d367, i32 0, i32 1) }, 1
  %t775 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d367, i32 0, i32 1) }, 0
  %t776 = add i64 %t773, %t775
  %t777 = call ptr @__olang_scope_alloc(ptr %s48, i64 %t776)
  call void @olang_textcopy(ptr %t777, ptr %t761, i64 %t762)
  %t778 = getelementptr i8, ptr %t777, i64 %t762
  call void @olang_textcopy(ptr %t778, ptr %t764, i64 %t765)
  %t779 = getelementptr i8, ptr %t778, i64 %t765
  call void @olang_textcopy(ptr %t779, ptr %t767, i64 %t768)
  %t780 = getelementptr i8, ptr %t779, i64 %t768
  call void @olang_textcopy(ptr %t780, ptr %t771, i64 %t772)
  %t781 = getelementptr i8, ptr %t780, i64 %t772
  call void @olang_textcopy(ptr %t781, ptr %t774, i64 %t775)
  %t782 = insertvalue { i64, ptr } undef, i64 %t776, 0
  %t783 = insertvalue { i64, ptr } %t782, ptr %t777, 1
  %t786 = extractvalue { i64, ptr } %t783, 0
  %t787 = extractvalue { i64, ptr } %t783, 1
  %t788 = mul i64 %t786, 1
  %t789 = call ptr @__olang_scope_alloc(ptr %s48, i64 %t788)
  call void @llvm.memcpy.p0.p0.i64(ptr %t789, ptr %t787, i64 %t788, i1 false)
  %t790 = insertvalue { i64, ptr } undef, i64 %t786, 0
  %t791 = insertvalue { i64, ptr } %t790, ptr %t789, 1
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %v3, ptr %s48, ptr %t757, { i64, ptr } %t791)
  br label %bb171
bb171:
  store i32 1, ptr %l313, !tbaa !23
  call void @__olang_scope_close(ptr %s48)
  %t794 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t796 = call i32 @std_2fos_2eRemoveAll(ptr %s0, { i64, ptr } %t794)
  store i32 %t796, ptr %l315
  %t797 = icmp ne i32 %t796, 0
  br i1 %t797, label %bb173, label %ok.798, !prof !99
ok.798:
  br label %bb172
bb172:
  br label %bb177
bb173:
  %t799 = load i32, ptr %l315, !tbaa !23
  %t800 = ashr i32 %t799, 16
  %t802 = icmp eq i32 %t800, 1
  store i1 %t802, ptr %l317, !tbaa !21
  %t803 = load i32, ptr %l315, !tbaa !23
  %t804 = ashr i32 %t803, 16
  %t806 = icmp eq i32 %t804, 1
  br i1 %t806, label %bb174, label %bb175
bb174:
  call void @__olang_errpay_pop()
  br label %bb175
bb175:
  br label %bb176
bb176:
  br label %bb177
bb177:
  call void @__olang_scope_close(ptr %s0)
  %t808 = load i32, ptr %l313, !tbaa !23
  store i32 %t808, ptr %rv
  br label %ret
bb178:
  %t809 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t810 = extractvalue { i64, ptr } { i64 34, ptr getelementptr inbounds (<{ i64, [34 x i8] }>, ptr @.d368, i32 0, i32 1) }, 1
  %t811 = extractvalue { i64, ptr } { i64 34, ptr getelementptr inbounds (<{ i64, [34 x i8] }>, ptr @.d368, i32 0, i32 1) }, 0
  %t813 = extractvalue { i64, ptr } %t809, 1
  %t814 = extractvalue { i64, ptr } %t809, 0
  %t815 = add i64 %t811, %t814
  %t816 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d369, i32 0, i32 1) }, 1
  %t817 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d369, i32 0, i32 1) }, 0
  %t818 = add i64 %t815, %t817
  %t819 = extractvalue { i64, ptr } { i64 104, ptr getelementptr inbounds (<{ i64, [104 x i8] }>, ptr @.d370, i32 0, i32 1) }, 1
  %t820 = extractvalue { i64, ptr } { i64 104, ptr getelementptr inbounds (<{ i64, [104 x i8] }>, ptr @.d370, i32 0, i32 1) }, 0
  %t821 = add i64 %t818, %t820
  %t822 = extractvalue { i64, ptr } { i64 66, ptr getelementptr inbounds (<{ i64, [66 x i8] }>, ptr @.d371, i32 0, i32 1) }, 1
  %t823 = extractvalue { i64, ptr } { i64 66, ptr getelementptr inbounds (<{ i64, [66 x i8] }>, ptr @.d371, i32 0, i32 1) }, 0
  %t824 = add i64 %t821, %t823
  %t825 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t824)
  call void @olang_textcopy(ptr %t825, ptr %t810, i64 %t811)
  %t826 = getelementptr i8, ptr %t825, i64 %t811
  call void @olang_textcopy(ptr %t826, ptr %t813, i64 %t814)
  %t827 = getelementptr i8, ptr %t826, i64 %t814
  call void @olang_textcopy(ptr %t827, ptr %t816, i64 %t817)
  %t828 = getelementptr i8, ptr %t827, i64 %t817
  call void @olang_textcopy(ptr %t828, ptr %t819, i64 %t820)
  %t829 = getelementptr i8, ptr %t828, i64 %t820
  call void @olang_textcopy(ptr %t829, ptr %t822, i64 %t823)
  %t830 = insertvalue { i64, ptr } undef, i64 %t824, 0
  %t831 = insertvalue { i64, ptr } %t830, ptr %t825, 1
  %t836 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ewrite(ptr %s0, ptr %s0, ptr %s0, ptr %l8, { i64, ptr } %t831)
  store { i64, ptr } %t836, ptr %l324
  br label %bb179
bb179:
  %t837 = load { i64, ptr }, ptr %l324, !tbaa !27
  store { i64, ptr } %t837, ptr %l32, !tbaa !27
  %t838 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t840 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t838, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d372, i32 0, i32 1) })
  store i1 %t840, ptr %l326
  br label %bb180
bb180:
  %t841 = load i1, ptr %l326, !tbaa !21
  br i1 %t841, label %bb181, label %bb182
bb181:
  %t842 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t844 = call i32 @std_2fio_2ePut_3cstd_2fprelude_2ftext_3aString_3e({ i64, ptr } %t842)
  store i32 %t844, ptr %l328
  %t845 = icmp ne i32 %t844, 0
  br i1 %t845, label %bb184, label %ok.846, !prof !99
ok.846:
  br label %bb183
bb182:
  br label %bb201
bb183:
  br label %bb194
bb184:
  %t847 = load i32, ptr %l328, !tbaa !23
  %t848 = ashr i32 %t847, 16
  %t850 = icmp eq i32 %t848, 1
  store i1 %t850, ptr %l330, !tbaa !21
  %t851 = load i32, ptr %l328, !tbaa !23
  %t852 = ashr i32 %t851, 16
  %t854 = icmp eq i32 %t852, 1
  br i1 %t854, label %bb185, label %bb186
bb185:
  call void @__olang_errpay_pop()
  br label %bb186
bb186:
  br label %bb187
bb187:
  store i32 1, ptr %l333, !tbaa !23
  %t856 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t858 = call i32 @std_2fos_2eRemoveAll(ptr %s0, { i64, ptr } %t856)
  store i32 %t858, ptr %l335
  %t859 = icmp ne i32 %t858, 0
  br i1 %t859, label %bb189, label %ok.860, !prof !99
ok.860:
  br label %bb188
bb188:
  br label %bb193
bb189:
  %t861 = load i32, ptr %l335, !tbaa !23
  %t862 = ashr i32 %t861, 16
  %t864 = icmp eq i32 %t862, 1
  store i1 %t864, ptr %l337, !tbaa !21
  %t865 = load i32, ptr %l335, !tbaa !23
  %t866 = ashr i32 %t865, 16
  %t868 = icmp eq i32 %t866, 1
  br i1 %t868, label %bb190, label %bb191
bb190:
  call void @__olang_errpay_pop()
  br label %bb191
bb191:
  br label %bb192
bb192:
  br label %bb193
bb193:
  call void @__olang_scope_close(ptr %s0)
  %t870 = load i32, ptr %l333, !tbaa !23
  store i32 %t870, ptr %rv
  br label %ret
bb194:
  store i32 0, ptr %l340, !tbaa !23
  %t871 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t873 = call i32 @std_2fos_2eRemoveAll(ptr %s0, { i64, ptr } %t871)
  store i32 %t873, ptr %l342
  %t874 = icmp ne i32 %t873, 0
  br i1 %t874, label %bb196, label %ok.875, !prof !99
ok.875:
  br label %bb195
bb195:
  br label %bb200
bb196:
  %t876 = load i32, ptr %l342, !tbaa !23
  %t877 = ashr i32 %t876, 16
  %t879 = icmp eq i32 %t877, 1
  store i1 %t879, ptr %l344, !tbaa !21
  %t880 = load i32, ptr %l342, !tbaa !23
  %t881 = ashr i32 %t880, 16
  %t883 = icmp eq i32 %t881, 1
  br i1 %t883, label %bb197, label %bb198
bb197:
  call void @__olang_errpay_pop()
  br label %bb198
bb198:
  br label %bb199
bb199:
  br label %bb200
bb200:
  call void @__olang_scope_close(ptr %s0)
  %t885 = load i32, ptr %l340, !tbaa !23
  store i32 %t885, ptr %rv
  br label %ret
bb201:
  %t886 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t887 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t890 = call i32 @std_2fos_2eWriteFile(ptr %v1, ptr %s0, { i64, ptr } %t886, { i64, ptr } %t887)
  store i32 %t890, ptr %l349
  %t891 = icmp ne i32 %t890, 0
  br i1 %t891, label %bb203, label %ok.892, !prof !99
ok.892:
  br label %bb202
bb202:
  br label %bb214
bb203:
  %t893 = load i32, ptr %l349, !tbaa !23
  %t894 = ashr i32 %t893, 16
  %t896 = icmp eq i32 %t894, 1
  store i1 %t896, ptr %l351, !tbaa !21
  %t897 = load i32, ptr %l349, !tbaa !23
  %t898 = ashr i32 %t897, 16
  %t900 = icmp eq i32 %t898, 1
  br i1 %t900, label %bb204, label %bb205
bb204:
  call void @__olang_errpay_pop()
  br label %bb205
bb205:
  br label %bb206
bb206:
  store %olang.scope zeroinitializer, ptr %s62
  %t902 = load ptr, ptr %l3, !tbaa !29
  %t903 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t904 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d373, i32 0, i32 1) }, 1
  %t905 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d373, i32 0, i32 1) }, 0
  %t907 = extractvalue { i64, ptr } %t903, 1
  %t908 = extractvalue { i64, ptr } %t903, 0
  %t909 = add i64 %t905, %t908
  %t910 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d374, i32 0, i32 1) }, 1
  %t911 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d374, i32 0, i32 1) }, 0
  %t912 = add i64 %t909, %t911
  %t913 = call ptr @__olang_scope_alloc(ptr %s62, i64 %t912)
  call void @olang_textcopy(ptr %t913, ptr %t904, i64 %t905)
  %t914 = getelementptr i8, ptr %t913, i64 %t905
  call void @olang_textcopy(ptr %t914, ptr %t907, i64 %t908)
  %t915 = getelementptr i8, ptr %t914, i64 %t908
  call void @olang_textcopy(ptr %t915, ptr %t910, i64 %t911)
  %t916 = insertvalue { i64, ptr } undef, i64 %t912, 0
  %t917 = insertvalue { i64, ptr } %t916, ptr %t913, 1
  %t920 = extractvalue { i64, ptr } %t917, 0
  %t921 = extractvalue { i64, ptr } %t917, 1
  %t922 = mul i64 %t920, 1
  %t923 = call ptr @__olang_scope_alloc(ptr %s62, i64 %t922)
  call void @llvm.memcpy.p0.p0.i64(ptr %t923, ptr %t921, i64 %t922, i1 false)
  %t924 = insertvalue { i64, ptr } undef, i64 %t920, 0
  %t925 = insertvalue { i64, ptr } %t924, ptr %t923, 1
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %v3, ptr %s62, ptr %t902, { i64, ptr } %t925)
  br label %bb207
bb207:
  store i32 2, ptr %l359, !tbaa !23
  call void @__olang_scope_close(ptr %s62)
  %t928 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t930 = call i32 @std_2fos_2eRemoveAll(ptr %s0, { i64, ptr } %t928)
  store i32 %t930, ptr %l361
  %t931 = icmp ne i32 %t930, 0
  br i1 %t931, label %bb209, label %ok.932, !prof !99
ok.932:
  br label %bb208
bb208:
  br label %bb213
bb209:
  %t933 = load i32, ptr %l361, !tbaa !23
  %t934 = ashr i32 %t933, 16
  %t936 = icmp eq i32 %t934, 1
  store i1 %t936, ptr %l363, !tbaa !21
  %t937 = load i32, ptr %l361, !tbaa !23
  %t938 = ashr i32 %t937, 16
  %t940 = icmp eq i32 %t938, 1
  br i1 %t940, label %bb210, label %bb211
bb210:
  call void @__olang_errpay_pop()
  br label %bb211
bb211:
  br label %bb212
bb212:
  br label %bb213
bb213:
  call void @__olang_scope_close(ptr %s0)
  %t942 = load i32, ptr %l359, !tbaa !23
  store i32 %t942, ptr %rv
  br label %ret
bb214:
  store i32 0, ptr %l366, !tbaa !23
  %t943 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t945 = call i32 @std_2fos_2eRemoveAll(ptr %s0, { i64, ptr } %t943)
  store i32 %t945, ptr %l368
  %t946 = icmp ne i32 %t945, 0
  br i1 %t946, label %bb216, label %ok.947, !prof !99
ok.947:
  br label %bb215
bb215:
  br label %bb220
bb216:
  %t948 = load i32, ptr %l368, !tbaa !23
  %t949 = ashr i32 %t948, 16
  %t951 = icmp eq i32 %t949, 1
  store i1 %t951, ptr %l370, !tbaa !21
  %t952 = load i32, ptr %l368, !tbaa !23
  %t953 = ashr i32 %t952, 16
  %t955 = icmp eq i32 %t953, 1
  br i1 %t955, label %bb217, label %bb218
bb217:
  call void @__olang_errpay_pop()
  br label %bb218
bb218:
  br label %bb219
bb219:
  br label %bb220
bb220:
  call void @__olang_scope_close(ptr %s0)
  %t957 = load i32, ptr %l366, !tbaa !23
  store i32 %t957, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2fbindgen_2etoBits(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l3 = alloca i1
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l9 = alloca i1
  %l10 = alloca i1
  %l12 = alloca i1
  %l13 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca { i64, ptr }
  %l18 = alloca i1
  %l19 = alloca i1
  %l21 = alloca i1
  %l27 = alloca i1
  %l28 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l31 = alloca { i64, ptr }
  %l33 = alloca i64
  %l34 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d375, i32 0, i32 1) })
  store i1 %t3, ptr %l3
  br label %bb1
bb1:
  %t4 = load i1, ptr %l3, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  store { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d376, i32 0, i32 1) }, ptr %l4, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t5, ptr %l5, !tbaa !27
  %t6 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t6, 0
  store i64 %t7, ptr %l6, !tbaa !24
  %t8 = load i64, ptr %l6, !tbaa !24
  %t9 = mul i64 %t8, 1
  %t10 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t9)
  %t11 = insertvalue { i64, ptr } undef, i64 %t8, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l7, !tbaa !27
  %t13 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !27
  %t15 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !27
  %t17 = load i64, ptr %l6, !tbaa !24
  %t18 = mul i64 %t17, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t14, ptr %t16, i64 %t18, i1 false)
  %t19 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t19, ptr %l5, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t20 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t20, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t21 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t23 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t21, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d377, i32 0, i32 1) })
  store i1 %t23, ptr %l9
  br label %bb5
bb5:
  %t24 = load i1, ptr %l9, !tbaa !21
  br i1 %t24, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l10, !tbaa !21
  br label %bb9
bb7:
  %t25 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t27 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t25, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d378, i32 0, i32 1) })
  store i1 %t27, ptr %l12
  br label %bb8
bb8:
  %t28 = load i1, ptr %l12, !tbaa !21
  store i1 %t28, ptr %l10, !tbaa !21
  br label %bb9
bb9:
  %t29 = load i1, ptr %l10, !tbaa !21
  br i1 %t29, label %bb10, label %bb11
bb10:
  store { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d379, i32 0, i32 1) }, ptr %l13, !tbaa !27
  %t30 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t30, ptr %l14, !tbaa !27
  %t31 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t31, 0
  store i64 %t32, ptr %l15, !tbaa !24
  %t33 = load i64, ptr %l15, !tbaa !24
  %t34 = mul i64 %t33, 1
  %t35 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t34)
  %t36 = insertvalue { i64, ptr } undef, i64 %t33, 0
  %t37 = insertvalue { i64, ptr } %t36, ptr %t35, 1
  store { i64, ptr } %t37, ptr %l16, !tbaa !27
  %t38 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t39 = load ptr, ptr %t38, !tbaa !27
  %t40 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !27
  %t42 = load i64, ptr %l15, !tbaa !24
  %t43 = mul i64 %t42, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t39, ptr %t41, i64 %t43, i1 false)
  %t44 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t44, ptr %l14, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t45 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t45, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t46 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t48 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t46, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d380, i32 0, i32 1) })
  store i1 %t48, ptr %l18
  br label %bb13
bb13:
  %t49 = load i1, ptr %l18, !tbaa !21
  br i1 %t49, label %bb14, label %bb15
bb14:
  %t50 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t52 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t50, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d381, i32 0, i32 1) })
  store i1 %t52, ptr %l21
  br label %bb16
bb15:
  store i1 false, ptr %l19, !tbaa !21
  br label %bb17
bb16:
  %t53 = load i1, ptr %l21, !tbaa !21
  %t54 = xor i1 %t53, true
  store i1 %t54, ptr %l19, !tbaa !21
  br label %bb17
bb17:
  %t56 = load i1, ptr %l19, !tbaa !21
  br i1 %t56, label %bb18, label %bb19
bb18:
  %t59 = mul i64 8, %a1
  %t60 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d382, i32 0, i32 1) }, 1
  %t61 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d382, i32 0, i32 1) }, 0
  %t63 = call i64 @__olang_fmt_i64(ptr null, i64 %t59)
  %t64 = add i64 %t61, %t63
  %t65 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d383, i32 0, i32 1) }, 1
  %t66 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d383, i32 0, i32 1) }, 0
  %t67 = add i64 %t64, %t66
  %t68 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t67)
  call void @olang_textcopy(ptr %t68, ptr %t60, i64 %t61)
  %t69 = getelementptr i8, ptr %t68, i64 %t61
  %t70 = call i64 @__olang_fmt_i64(ptr %t69, i64 %t59)
  %t71 = getelementptr i8, ptr %t69, i64 %t63
  call void @olang_textcopy(ptr %t71, ptr %t65, i64 %t66)
  %t72 = insertvalue { i64, ptr } undef, i64 %t67, 0
  %t73 = insertvalue { i64, ptr } %t72, ptr %t68, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t73, ptr %rv
  br label %ret
bb19:
  br label %bb20
bb20:
  %t75 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t77 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t75, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d384, i32 0, i32 1) })
  store i1 %t77, ptr %l27
  br label %bb21
bb21:
  %t78 = load i1, ptr %l27, !tbaa !21
  br i1 %t78, label %bb22, label %bb23
bb22:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d385, i32 0, i32 1) }, ptr %l29, !tbaa !27
  %t79 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t79, ptr %l28, !tbaa !27
  br label %bb24
bb23:
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d386, i32 0, i32 1) }, ptr %l31, !tbaa !27
  %t81 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t81, ptr %l28, !tbaa !27
  br label %bb24
bb24:
  %t83 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t84 = extractvalue { i64, ptr } %t83, 0
  store i64 %t84, ptr %l33, !tbaa !24
  %t85 = load i64, ptr %l33, !tbaa !24
  %t86 = mul i64 %t85, 1
  %t87 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t86)
  %t88 = insertvalue { i64, ptr } undef, i64 %t85, 0
  %t89 = insertvalue { i64, ptr } %t88, ptr %t87, 1
  store { i64, ptr } %t89, ptr %l34, !tbaa !27
  %t90 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t91 = load ptr, ptr %t90, !tbaa !27
  %t92 = getelementptr { i64, ptr }, ptr %l28, i32 0, i32 1
  %t93 = load ptr, ptr %t92, !tbaa !27
  %t94 = load i64, ptr %l33, !tbaa !24
  %t95 = mul i64 %t94, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t91, ptr %t93, i64 %t95, i1 false)
  %t96 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t96, ptr %l28, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t97 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t97, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fbindgen_2ewordOf(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp eq i64 %t1, 8
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t6 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d387, i32 0, i32 1) }, 1
  %t7 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d387, i32 0, i32 1) }, 0
  %t9 = extractvalue { i64, ptr } %t5, 1
  %t10 = extractvalue { i64, ptr } %t5, 0
  %t11 = add i64 %t7, %t10
  %t12 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d388, i32 0, i32 1) }, 1
  %t13 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d388, i32 0, i32 1) }, 0
  %t14 = add i64 %t11, %t13
  %t15 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t14)
  call void @olang_textcopy(ptr %t15, ptr %t6, i64 %t7)
  %t16 = getelementptr i8, ptr %t15, i64 %t7
  call void @olang_textcopy(ptr %t16, ptr %t9, i64 %t10)
  %t17 = getelementptr i8, ptr %t16, i64 %t10
  call void @olang_textcopy(ptr %t17, ptr %t12, i64 %t13)
  %t18 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t15, 1
  store { i64, ptr } %t19, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t21 = load i64, ptr %l1, !tbaa !24
  %t23 = icmp eq i64 %t21, 1
  br i1 %t23, label %bb4, label %bb5
bb4:
  %t25 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t26 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d389, i32 0, i32 1) }, 1
  %t27 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d389, i32 0, i32 1) }, 0
  %t29 = extractvalue { i64, ptr } %t25, 1
  %t30 = extractvalue { i64, ptr } %t25, 0
  %t31 = add i64 %t27, %t30
  %t32 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d390, i32 0, i32 1) }, 1
  %t33 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d390, i32 0, i32 1) }, 0
  %t34 = add i64 %t31, %t33
  %t35 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t34)
  call void @olang_textcopy(ptr %t35, ptr %t26, i64 %t27)
  %t36 = getelementptr i8, ptr %t35, i64 %t27
  call void @olang_textcopy(ptr %t36, ptr %t29, i64 %t30)
  %t37 = getelementptr i8, ptr %t36, i64 %t30
  call void @olang_textcopy(ptr %t37, ptr %t32, i64 %t33)
  %t38 = insertvalue { i64, ptr } undef, i64 %t34, 0
  %t39 = insertvalue { i64, ptr } %t38, ptr %t35, 1
  store { i64, ptr } %t39, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t41 = load i64, ptr %l1, !tbaa !24
  %t43 = mul i64 8, %t41
  %t44 = load i64, ptr %l1, !tbaa !24
  %t46 = mul i64 8, %t44
  %t47 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t48 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d391, i32 0, i32 1) }, 1
  %t49 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d391, i32 0, i32 1) }, 0
  %t51 = call i64 @__olang_fmt_i64(ptr null, i64 %t43)
  %t52 = add i64 %t49, %t51
  %t53 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d392, i32 0, i32 1) }, 1
  %t54 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d392, i32 0, i32 1) }, 0
  %t55 = add i64 %t52, %t54
  %t57 = call i64 @__olang_fmt_i64(ptr null, i64 %t46)
  %t58 = add i64 %t55, %t57
  %t59 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d393, i32 0, i32 1) }, 1
  %t60 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d393, i32 0, i32 1) }, 0
  %t61 = add i64 %t58, %t60
  %t63 = extractvalue { i64, ptr } %t47, 1
  %t64 = extractvalue { i64, ptr } %t47, 0
  %t65 = add i64 %t61, %t64
  %t66 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d394, i32 0, i32 1) }, 1
  %t67 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d394, i32 0, i32 1) }, 0
  %t68 = add i64 %t65, %t67
  %t69 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t68)
  call void @olang_textcopy(ptr %t69, ptr %t48, i64 %t49)
  %t70 = getelementptr i8, ptr %t69, i64 %t49
  %t71 = call i64 @__olang_fmt_i64(ptr %t70, i64 %t43)
  %t72 = getelementptr i8, ptr %t70, i64 %t51
  call void @olang_textcopy(ptr %t72, ptr %t53, i64 %t54)
  %t73 = getelementptr i8, ptr %t72, i64 %t54
  %t74 = call i64 @__olang_fmt_i64(ptr %t73, i64 %t46)
  %t75 = getelementptr i8, ptr %t73, i64 %t57
  call void @olang_textcopy(ptr %t75, ptr %t59, i64 %t60)
  %t76 = getelementptr i8, ptr %t75, i64 %t60
  call void @olang_textcopy(ptr %t76, ptr %t63, i64 %t64)
  %t77 = getelementptr i8, ptr %t76, i64 %t64
  call void @olang_textcopy(ptr %t77, ptr %t66, i64 %t67)
  %t78 = insertvalue { i64, ptr } undef, i64 %t68, 0
  %t79 = insertvalue { i64, ptr } %t78, ptr %t69, 1
  store { i64, ptr } %t79, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"compiler/bindgen:Translation" @compiler_2fbindgen_3aTranslation_2ector(ptr %v0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l5 = alloca i64
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %rv = alloca %"compiler/bindgen:Translation"
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d395, i32 0, i32 1) }, ptr %l0, !tbaa !27
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d396, i32 0, i32 1) }, ptr %l1, !tbaa !27
  %t1 = call ptr @__olang_scope_hold(ptr %v0)
  %t2 = ptrtoint ptr %t1 to i64
  store i64 %t2, ptr %l5, !tbaa !24
  %t3 = load i1, ptr @olang_2esole_2ecompiler_2fbindgen_3aTranslation_2e2
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call ptr @__olang_region_make(ptr %v0)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  %t7 = load i64, ptr %l5
  %t8 = inttoptr i64 %t7 to ptr
  %t9 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %t8, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %l7
  br label %bb3
bb3:
  %t10 = load i1, ptr @olang_2esole_2ecompiler_2fbindgen_3aTranslation_2e2
  br i1 %t10, label %bb4, label %bb5
bb4:
  %t12 = load i64, ptr %l5
  %t13 = inttoptr i64 %t12 to ptr
  %t14 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l7, i32 0, i32 0
  %t15 = load { i64, ptr }, ptr %t14
  %t16 = extractvalue { i64, ptr } %t15, 1
  %t17 = call ptr @__olang_region_or(ptr %t16, ptr null)
  %t18 = call ptr @__olang_region_home(ptr %t17)
  %t19 = icmp ne ptr %t18, null
  %t20 = select i1 %t19, ptr %t18, ptr null
  call void @__olang_region_settle_in(ptr %t13, ptr %t20)
  br label %bb5
bb5:
  %t21 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l7
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d397, i32 0, i32 1) }, ptr %l3, !tbaa !27
  %t22 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t23 = insertvalue %"compiler/bindgen:Translation" undef, { i64, ptr } %t22, 0
  %t24 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t25 = insertvalue %"compiler/bindgen:Translation" %t23, { i64, ptr } %t24, 1
  %t27 = insertvalue %"compiler/bindgen:Translation" %t25, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t21, 2
  %t28 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t29 = insertvalue %"compiler/bindgen:Translation" %t27, { i64, ptr } %t28, 3
  %t31 = insertvalue %"compiler/bindgen:Translation" %t29, i1 false, 4
  store %"compiler/bindgen:Translation" %t31, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/bindgen:Translation", ptr %rv
  ret %"compiler/bindgen:Translation" %rr
}

define dso_local %"compiler/bindgen:cMacro" @compiler_2fbindgen_3acMacro_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, i1 %a1, { i64, ptr } %a2, { i64, ptr } %a3, i1 %a4) #0 {
entry:
  %rv = alloca %"compiler/bindgen:cMacro"
  br label %start
start:
  br label %bb0
bb0:
  %t12 = insertvalue %"compiler/bindgen:cMacro" undef, { i64, ptr } %a0, 0
  %t14 = insertvalue %"compiler/bindgen:cMacro" %t12, i1 %a1, 1
  %t16 = insertvalue %"compiler/bindgen:cMacro" %t14, { i64, ptr } %a2, 2
  %t18 = insertvalue %"compiler/bindgen:cMacro" %t16, { i64, ptr } %a3, 3
  %t20 = insertvalue %"compiler/bindgen:cMacro" %t18, i1 %a4, 4
  %t22 = insertvalue %"compiler/bindgen:cMacro" %t20, i1 false, 5
  store %"compiler/bindgen:cMacro" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/bindgen:cMacro", ptr %rv
  ret %"compiler/bindgen:cMacro" %rr
}

define dso_local %"compiler/bindgen:ctp" @compiler_2fbindgen_3actp_2ector(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %rv = alloca %"compiler/bindgen:ctp"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = insertvalue %"compiler/bindgen:ctp" undef, { i64, ptr } %a0, 0
  %t6 = insertvalue %"compiler/bindgen:ctp" %t4, i64 0, 1
  store %"compiler/bindgen:ctp" %t6, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/bindgen:ctp", ptr %rv
  ret %"compiler/bindgen:ctp" %rr
}

define dso_local void @compiler_2fbindgen_3agen_2ector(ptr %out, ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca i1
  %l3 = alloca i1
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l8 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l9 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l10 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l11 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l12 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l13 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l14 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l15 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l16 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l17 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l18 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l19 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l20 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l21 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l22 = alloca %"std/prelude/text:StringBuilder"
  %l23 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l24 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l25 = alloca i1
  %l27 = alloca { i64, ptr }
  %l30 = alloca i64
  %l32 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l34 = alloca i64
  %l36 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l38 = alloca i64
  %l40 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l42 = alloca i64
  %l44 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l46 = alloca i64
  %l48 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l50 = alloca i64
  %l52 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l54 = alloca i64
  %l56 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l58 = alloca i64
  %l60 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l62 = alloca i64
  %l64 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l66 = alloca i64
  %l68 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l70 = alloca i64
  %l72 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l74 = alloca i64
  %l76 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l78 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l79 = alloca i64
  %l81 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l83 = alloca i64
  %l85 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l87 = alloca i64
  %l89 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l91 = alloca i64
  %l93 = alloca %"std/prelude/text:StringBuilder"
  %l95 = alloca i64
  %l97 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l99 = alloca i64
  %l101 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l103 = alloca i64
  %l105 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l107 = alloca %"compiler/bindgen:gen"
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a0, ptr %l1, !tbaa !27
  store i1 false, ptr %l2, !tbaa !21
  store i1 false, ptr %l3, !tbaa !21
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d398, i32 0, i32 1) }, ptr %l4, !tbaa !27
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d399, i32 0, i32 1) }, ptr %l5, !tbaa !27
  %t3 = call ptr @__olang_scope_hold(ptr %v1)
  %t4 = ptrtoint ptr %t3 to i64
  store i64 %t4, ptr %l30, !tbaa !24
  %t5 = load i1, ptr @olang_2esole_2ecompiler_2fbindgen_3agen_2e5
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = call ptr @__olang_region_make(ptr %v1)
  %t8 = ptrtoint ptr %t7 to i64
  store i64 %t8, ptr %l30, !tbaa !24
  br label %bb2
bb2:
  %t9 = load i64, ptr %l30
  %t10 = inttoptr i64 %t9 to ptr
  %t11 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20std_2fprelude_2ftext_3aString_26_3e_2ector(ptr %t10)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t11, ptr %l32
  br label %bb3
bb3:
  %t12 = load i1, ptr @olang_2esole_2ecompiler_2fbindgen_3agen_2e5
  br i1 %t12, label %bb4, label %bb5
bb4:
  %t14 = load i64, ptr %l30
  %t15 = inttoptr i64 %t14 to ptr
  %t16 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l32, i32 0, i32 2
  %t17 = load { i64, ptr }, ptr %t16
  %t18 = extractvalue { i64, ptr } %t17, 1
  %t19 = call ptr @__olang_region_or(ptr %t18, ptr null)
  %t20 = call ptr @__olang_region_home(ptr %t19)
  %t21 = icmp ne ptr %t20, null
  %t22 = select i1 %t21, ptr %t20, ptr null
  %t23 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l32, i32 0, i32 1
  %t24 = load { i64, ptr }, ptr %t23
  %t25 = extractvalue { i64, ptr } %t24, 1
  %t26 = call ptr @__olang_region_or(ptr %t25, ptr null)
  %t27 = call ptr @__olang_region_home(ptr %t26)
  %t28 = icmp ne ptr %t27, null
  %t29 = select i1 %t28, ptr %t27, ptr %t22
  %t30 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l32, i32 0, i32 0
  %t31 = load { i64, ptr }, ptr %t30
  %t32 = extractvalue { i64, ptr } %t31, 1
  %t33 = call ptr @__olang_region_or(ptr %t32, ptr null)
  %t34 = call ptr @__olang_region_home(ptr %t33)
  %t35 = icmp ne ptr %t34, null
  %t36 = select i1 %t35, ptr %t34, ptr %t29
  call void @__olang_region_settle_in(ptr %t15, ptr %t36)
  br label %bb5
bb5:
  %t37 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l32
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t37, ptr %l6
  %t38 = call ptr @__olang_scope_hold(ptr %v1)
  %t39 = ptrtoint ptr %t38 to i64
  store i64 %t39, ptr %l34, !tbaa !24
  %t40 = load i1, ptr @olang_2esole_2ecompiler_2fbindgen_3agen_2e6
  br i1 %t40, label %bb6, label %bb7
bb6:
  %t42 = call ptr @__olang_region_make(ptr %v1)
  %t43 = ptrtoint ptr %t42 to i64
  store i64 %t43, ptr %l34, !tbaa !24
  br label %bb7
bb7:
  %t44 = load i64, ptr %l34
  %t45 = inttoptr i64 %t44 to ptr
  %t46 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2ector(ptr %t45, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t46, ptr %l36
  br label %bb8
bb8:
  %t47 = load i1, ptr @olang_2esole_2ecompiler_2fbindgen_3agen_2e6
  br i1 %t47, label %bb9, label %bb10
bb9:
  %t49 = load i64, ptr %l34
  %t50 = inttoptr i64 %t49 to ptr
  %t51 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l36, i32 0, i32 0
  %t52 = load { i64, ptr }, ptr %t51
  %t53 = extractvalue { i64, ptr } %t52, 1
  %t54 = call ptr @__olang_region_or(ptr %t53, ptr null)
  %t55 = call ptr @__olang_region_home(ptr %t54)
  %t56 = icmp ne ptr %t55, null
  %t57 = select i1 %t56, ptr %t55, ptr null
  call void @__olang_region_settle_in(ptr %t50, ptr %t57)
  br label %bb10
bb10:
  %t58 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l36
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t58, ptr %l7
  %t59 = call ptr @__olang_scope_hold(ptr %v1)
  %t60 = ptrtoint ptr %t59 to i64
  store i64 %t60, ptr %l38, !tbaa !24
  %t61 = load i1, ptr @olang_2esole_2ecompiler_2fbindgen_3agen_2e7
  br i1 %t61, label %bb11, label %bb12
bb11:
  %t63 = call ptr @__olang_region_make(ptr %v1)
  %t64 = ptrtoint ptr %t63 to i64
  store i64 %t64, ptr %l38, !tbaa !24
  br label %bb12
bb12:
  %t65 = load i64, ptr %l38
  %t66 = inttoptr i64 %t65 to ptr
  %t67 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e_2ector(ptr %t66)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t67, ptr %l40
  br label %bb13
bb13:
  %t68 = load i1, ptr @olang_2esole_2ecompiler_2fbindgen_3agen_2e7
  br i1 %t68, label %bb14, label %bb15
bb14:
  %t70 = load i64, ptr %l38
  %t71 = inttoptr i64 %t70 to ptr
  %t72 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l40, i32 0, i32 2
  %t73 = load { i64, ptr }, ptr %t72
  %t74 = extractvalue { i64, ptr } %t73, 1
  %t75 = call ptr @__olang_region_or(ptr %t74, ptr null)
  %t76 = call ptr @__olang_region_home(ptr %t75)
  %t77 = icmp ne ptr %t76, null
  %t78 = select i1 %t77, ptr %t76, ptr null
  %t79 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l40, i32 0, i32 1
  %t80 = load { i64, ptr }, ptr %t79
  %t81 = extractvalue { i64, ptr } %t80, 1
  %t82 = call ptr @__olang_region_or(ptr %t81, ptr null)
  %t83 = call ptr @__olang_region_home(ptr %t82)
  %t84 = icmp ne ptr %t83, null
  %t85 = select i1 %t84, ptr %t83, ptr %t78
  %t86 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l40, i32 0, i32 0
  %t87 = load { i64, ptr }, ptr %t86
  %t88 = extractvalue { i64, ptr } %t87, 1
  %t89 = call ptr @__olang_region_or(ptr %t88, ptr null)
  %t90 = call ptr @__olang_region_home(ptr %t89)
  %t91 = icmp ne ptr %t90, null
  %t92 = select i1 %t91, ptr %t90, ptr %t85
  call void @__olang_region_settle_in(ptr %t71, ptr %t92)
  br label %bb15
bb15:
  %t93 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l40
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t93, ptr %l8
  %t94 = call ptr @__olang_scope_hold(ptr %v1)
  %t95 = ptrtoint ptr %t94 to i64
  store i64 %t95, ptr %l42, !tbaa !24
  %t96 = load i1, ptr @olang_2esole_2ecompiler_2fbindgen_3agen_2e8
  br i1 %t96, label %bb16, label %bb17
bb16:
  %t98 = call ptr @__olang_region_make(ptr %v1)
  %t99 = ptrtoint ptr %t98 to i64
  store i64 %t99, ptr %l42, !tbaa !24
  br label %bb17
bb17:
  %t100 = load i64, ptr %l42
  %t101 = inttoptr i64 %t100 to ptr
  %t102 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e_2ector(ptr %t101)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t102, ptr %l44
  br label %bb18
bb18:
  %t103 = load i1, ptr @olang_2esole_2ecompiler_2fbindgen_3agen_2e8
  br i1 %t103, label %bb19, label %bb20
bb19:
  %t105 = load i64, ptr %l42
  %t106 = inttoptr i64 %t105 to ptr
  %t107 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l44, i32 0, i32 2
  %t108 = load { i64, ptr }, ptr %t107
  %t109 = extractvalue { i64, ptr } %t108, 1
  %t110 = call ptr @__olang_region_or(ptr %t109, ptr null)
  %t111 = call ptr @__olang_region_home(ptr %t110)
  %t112 = icmp ne ptr %t111, null
  %t113 = select i1 %t112, ptr %t111, ptr null
  %t114 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l44, i32 0, i32 1
  %t115 = load { i64, ptr }, ptr %t114
  %t116 = extractvalue { i64, ptr } %t115, 1
  %t117 = call ptr @__olang_region_or(ptr %t116, ptr null)
  %t118 = call ptr @__olang_region_home(ptr %t117)
  %t119 = icmp ne ptr %t118, null
  %t120 = select i1 %t119, ptr %t118, ptr %t113
  %t121 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l44, i32 0, i32 0
  %t122 = load { i64, ptr }, ptr %t121
  %t123 = extractvalue { i64, ptr } %t122, 1
  %t124 = call ptr @__olang_region_or(ptr %t123, ptr null)
  %t125 = call ptr @__olang_region_home(ptr %t124)
  %t126 = icmp ne ptr %t125, null
  %t127 = select i1 %t126, ptr %t125, ptr %t120
  call void @__olang_region_settle_in(ptr %t106, ptr %t127)
  br label %bb20
bb20:
  %t128 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l44
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t128, ptr %l9
  %t129 = call ptr @__olang_scope_hold(ptr %v1)
  %t130 = ptrtoint ptr %t129 to i64
  store i64 %t130, ptr %l46, !tbaa !24
  %t131 = load i1, ptr @olang_2esole_2ecompiler_2fbindgen_3agen_2e9
  br i1 %t131, label %bb21, label %bb22
bb21:
  %t133 = call ptr @__olang_region_make(ptr %v1)
  %t134 = ptrtoint ptr %t133 to i64
  store i64 %t134, ptr %l46, !tbaa !24
  br label %bb22
bb22:
  %t135 = load i64, ptr %l46
  %t136 = inttoptr i64 %t135 to ptr
  %t137 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3acFunc_3e_2ector(ptr %t136, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t137, ptr %l48
  br label %bb23
bb23:
  %t138 = load i1, ptr @olang_2esole_2ecompiler_2fbindgen_3agen_2e9
  br i1 %t138, label %bb24, label %bb25
bb24:
  %t140 = load i64, ptr %l46
  %t141 = inttoptr i64 %t140 to ptr
  %t142 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l48, i32 0, i32 0
  %t143 = load { i64, ptr }, ptr %t142
  %t144 = extractvalue { i64, ptr } %t143, 1
  %t145 = call ptr @__olang_region_or(ptr %t144, ptr null)
  %t146 = call ptr @__olang_region_home(ptr %t145)
  %t147 = icmp ne ptr %t146, null
  %t148 = select i1 %t147, ptr %t146, ptr null
  call void @__olang_region_settle_in(ptr %t141, ptr %t148)
  br label %bb25
bb25:
  %t149 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l48
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t149, ptr %l10
  %t150 = call ptr @__olang_scope_hold(ptr %v1)
  %t151 = ptrtoint ptr %t150 to i64
  store i64 %t151, ptr %l50, !tbaa !24
  %t152 = load i1, ptr @olang_2esole_2ecompiler_2fbindgen_3agen_2e10
  br i1 %t152, label %bb26, label %bb27
bb26:
  %t154 = call ptr @__olang_region_make(ptr %v1)
  %t155 = ptrtoint ptr %t154 to i64
  store i64 %t155, ptr %l50, !tbaa !24
  br label %bb27
bb27:
  %t156 = load i64, ptr %l50
  %t157 = inttoptr i64 %t156 to ptr
  %t158 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %t157, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t158, ptr %l52
  br label %bb28
bb28:
  %t159 = load i1, ptr @olang_2esole_2ecompiler_2fbindgen_3agen_2e10
  br i1 %t159, label %bb29, label %bb30
bb29:
  %t161 = load i64, ptr %l50
  %t162 = inttoptr i64 %t161 to ptr
  %t163 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l52, i32 0, i32 0
  %t164 = load { i64, ptr }, ptr %t163
  %t165 = extractvalue { i64, ptr } %t164, 1
  %t166 = call ptr @__olang_region_or(ptr %t165, ptr null)
  %t167 = call ptr @__olang_region_home(ptr %t166)
  %t168 = icmp ne ptr %t167, null
  %t169 = select i1 %t168, ptr %t167, ptr null
  call void @__olang_region_settle_in(ptr %t162, ptr %t169)
  br label %bb30
bb30:
  %t170 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l52
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t170, ptr %l11
  %t171 = call ptr @__olang_scope_hold(ptr %v1)
  %t172 = ptrtoint ptr %t171 to i64
  store i64 %t172, ptr %l54, !tbaa !24
  %t173 = load i1, ptr @olang_2esole_2ecompiler_2fbindgen_3agen_2e11
  br i1 %t173, label %bb31, label %bb32
bb31:
  %t175 = call ptr @__olang_region_make(ptr %v1)
  %t176 = ptrtoint ptr %t175 to i64
  store i64 %t176, ptr %l54, !tbaa !24
  br label %bb32
bb32:
  %t177 = load i64, ptr %l54
  %t178 = inttoptr i64 %t177 to ptr
  %t179 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e_2ector(ptr %t178)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t179, ptr %l56
  br label %bb33
bb33:
  %t180 = load i1, ptr @olang_2esole_2ecompiler_2fbindgen_3agen_2e11
  br i1 %t180, label %bb34, label %bb35
bb34:
  %t182 = load i64, ptr %l54
  %t183 = inttoptr i64 %t182 to ptr
  %t184 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l56, i32 0, i32 2
  %t185 = load { i64, ptr }, ptr %t184
  %t186 = extractvalue { i64, ptr } %t185, 1
  %t187 = call ptr @__olang_region_or(ptr %t186, ptr null)
  %t188 = call ptr @__olang_region_home(ptr %t187)
  %t189 = icmp ne ptr %t188, null
  %t190 = select i1 %t189, ptr %t188, ptr null
  %t191 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l56, i32 0, i32 1
  %t192 = load { i64, ptr }, ptr %t191
  %t193 = extractvalue { i64, ptr } %t192, 1
  %t194 = call ptr @__olang_region_or(ptr %t193, ptr null)
  %t195 = call ptr @__olang_region_home(ptr %t194)
  %t196 = icmp ne ptr %t195, null
  %t197 = select i1 %t196, ptr %t195, ptr %t190
  %t198 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l56, i32 0, i32 0
  %t199 = load { i64, ptr }, ptr %t198
  %t200 = extractvalue { i64, ptr } %t199, 1
  %t201 = call ptr @__olang_region_or(ptr %t200, ptr null)
  %t202 = call ptr @__olang_region_home(ptr %t201)
  %t203 = icmp ne ptr %t202, null
  %t204 = select i1 %t203, ptr %t202, ptr %t197
  call void @__olang_region_settle_in(ptr %t183, ptr %t204)
  br label %bb35
bb35:
  %t205 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l56
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t205, ptr %l12
  %t206 = call ptr @__olang_scope_hold(ptr %v1)
  %t207 = ptrtoint ptr %t206 to i64
  store i64 %t207, ptr %l58, !tbaa !24
  %t208 = load i1, ptr @olang_2esole_2ecompiler_2fbindgen_3agen_2e12
  br i1 %t208, label %bb36, label %bb37
bb36:
  %t210 = call ptr @__olang_region_make(ptr %v1)
  %t211 = ptrtoint ptr %t210 to i64
  store i64 %t211, ptr %l58, !tbaa !24
  br label %bb37
bb37:
  %t212 = load i64, ptr %l58
  %t213 = inttoptr i64 %t212 to ptr
  %t214 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e_2ector(ptr %t213)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t214, ptr %l60
  br label %bb38
bb38:
  %t215 = load i1, ptr @olang_2esole_2ecompiler_2fbindgen_3agen_2e12
  br i1 %t215, label %bb39, label %bb40
bb39:
  %t217 = load i64, ptr %l58
  %t218 = inttoptr i64 %t217 to ptr
  %t219 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l60, i32 0, i32 2
  %t220 = load { i64, ptr }, ptr %t219
  %t221 = extractvalue { i64, ptr } %t220, 1
  %t222 = call ptr @__olang_region_or(ptr %t221, ptr null)
  %t223 = call ptr @__olang_region_home(ptr %t222)
  %t224 = icmp ne ptr %t223, null
  %t225 = select i1 %t224, ptr %t223, ptr null
  %t226 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l60, i32 0, i32 1
  %t227 = load { i64, ptr }, ptr %t226
  %t228 = extractvalue { i64, ptr } %t227, 1
  %t229 = call ptr @__olang_region_or(ptr %t228, ptr null)
  %t230 = call ptr @__olang_region_home(ptr %t229)
  %t231 = icmp ne ptr %t230, null
  %t232 = select i1 %t231, ptr %t230, ptr %t225
  %t233 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l60, i32 0, i32 0
  %t234 = load { i64, ptr }, ptr %t233
  %t235 = extractvalue { i64, ptr } %t234, 1
  %t236 = call ptr @__olang_region_or(ptr %t235, ptr null)
  %t237 = call ptr @__olang_region_home(ptr %t236)
  %t238 = icmp ne ptr %t237, null
  %t239 = select i1 %t238, ptr %t237, ptr %t232
  call void @__olang_region_settle_in(ptr %t218, ptr %t239)
  br label %bb40
bb40:
  %t240 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l60
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t240, ptr %l13
  %t241 = call ptr @__olang_scope_hold(ptr %v1)
  %t242 = ptrtoint ptr %t241 to i64
  store i64 %t242, ptr %l62, !tbaa !24
  %t243 = load i1, ptr @olang_2esole_2ecompiler_2fbindgen_3agen_2e13
  br i1 %t243, label %bb41, label %bb42
bb41:
  %t245 = call ptr @__olang_region_make(ptr %v1)
  %t246 = ptrtoint ptr %t245 to i64
  store i64 %t246, ptr %l62, !tbaa !24
  br label %bb42
bb42:
  %t247 = load i64, ptr %l62
  %t248 = inttoptr i64 %t247 to ptr
  %t249 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3acMacro_3e_2ector(ptr %t248, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t249, ptr %l64
  br label %bb43
bb43:
  %t250 = load i1, ptr @olang_2esole_2ecompiler_2fbindgen_3agen_2e13
  br i1 %t250, label %bb44, label %bb45
bb44:
  %t252 = load i64, ptr %l62
  %t253 = inttoptr i64 %t252 to ptr
  %t254 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l64, i32 0, i32 0
  %t255 = load { i64, ptr }, ptr %t254
  %t256 = extractvalue { i64, ptr } %t255, 1
  %t257 = call ptr @__olang_region_or(ptr %t256, ptr null)
  %t258 = call ptr @__olang_region_home(ptr %t257)
  %t259 = icmp ne ptr %t258, null
  %t260 = select i1 %t259, ptr %t258, ptr null
  call void @__olang_region_settle_in(ptr %t253, ptr %t260)
  br label %bb45
bb45:
  %t261 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l64
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t261, ptr %l14
  %t262 = call ptr @__olang_scope_hold(ptr %v1)
  %t263 = ptrtoint ptr %t262 to i64
  store i64 %t263, ptr %l66, !tbaa !24
  %t264 = load i1, ptr @olang_2esole_2ecompiler_2fbindgen_3agen_2e14
  br i1 %t264, label %bb46, label %bb47
bb46:
  %t266 = call ptr @__olang_region_make(ptr %v1)
  %t267 = ptrtoint ptr %t266 to i64
  store i64 %t267, ptr %l66, !tbaa !24
  br label %bb47
bb47:
  %t268 = load i64, ptr %l66
  %t269 = inttoptr i64 %t268 to ptr
  %t270 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e_2ector(ptr %t269)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t270, ptr %l68
  br label %bb48
bb48:
  %t271 = load i1, ptr @olang_2esole_2ecompiler_2fbindgen_3agen_2e14
  br i1 %t271, label %bb49, label %bb50
bb49:
  %t273 = load i64, ptr %l66
  %t274 = inttoptr i64 %t273 to ptr
  %t275 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l68, i32 0, i32 2
  %t276 = load { i64, ptr }, ptr %t275
  %t277 = extractvalue { i64, ptr } %t276, 1
  %t278 = call ptr @__olang_region_or(ptr %t277, ptr null)
  %t279 = call ptr @__olang_region_home(ptr %t278)
  %t280 = icmp ne ptr %t279, null
  %t281 = select i1 %t280, ptr %t279, ptr null
  %t282 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l68, i32 0, i32 1
  %t283 = load { i64, ptr }, ptr %t282
  %t284 = extractvalue { i64, ptr } %t283, 1
  %t285 = call ptr @__olang_region_or(ptr %t284, ptr null)
  %t286 = call ptr @__olang_region_home(ptr %t285)
  %t287 = icmp ne ptr %t286, null
  %t288 = select i1 %t287, ptr %t286, ptr %t281
  %t289 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l68, i32 0, i32 0
  %t290 = load { i64, ptr }, ptr %t289
  %t291 = extractvalue { i64, ptr } %t290, 1
  %t292 = call ptr @__olang_region_or(ptr %t291, ptr null)
  %t293 = call ptr @__olang_region_home(ptr %t292)
  %t294 = icmp ne ptr %t293, null
  %t295 = select i1 %t294, ptr %t293, ptr %t288
  call void @__olang_region_settle_in(ptr %t274, ptr %t295)
  br label %bb50
bb50:
  %t296 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l68
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t296, ptr %l15
  %t297 = call ptr @__olang_scope_hold(ptr %v1)
  %t298 = ptrtoint ptr %t297 to i64
  store i64 %t298, ptr %l70, !tbaa !24
  %t299 = load i1, ptr @olang_2esole_2ecompiler_2fbindgen_3agen_2e15
  br i1 %t299, label %bb51, label %bb52
bb51:
  %t301 = call ptr @__olang_region_make(ptr %v1)
  %t302 = ptrtoint ptr %t301 to i64
  store i64 %t302, ptr %l70, !tbaa !24
  br label %bb52
bb52:
  %t303 = load i64, ptr %l70
  %t304 = inttoptr i64 %t303 to ptr
  %t305 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %t304, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t305, ptr %l72
  br label %bb53
bb53:
  %t306 = load i1, ptr @olang_2esole_2ecompiler_2fbindgen_3agen_2e15
  br i1 %t306, label %bb54, label %bb55
bb54:
  %t308 = load i64, ptr %l70
  %t309 = inttoptr i64 %t308 to ptr
  %t310 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l72, i32 0, i32 0
  %t311 = load { i64, ptr }, ptr %t310
  %t312 = extractvalue { i64, ptr } %t311, 1
  %t313 = call ptr @__olang_region_or(ptr %t312, ptr null)
  %t314 = call ptr @__olang_region_home(ptr %t313)
  %t315 = icmp ne ptr %t314, null
  %t316 = select i1 %t315, ptr %t314, ptr null
  call void @__olang_region_settle_in(ptr %t309, ptr %t316)
  br label %bb55
bb55:
  %t317 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l72
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t317, ptr %l16
  %t318 = call ptr @__olang_scope_hold(ptr %v1)
  %t319 = ptrtoint ptr %t318 to i64
  store i64 %t319, ptr %l74, !tbaa !24
  %t320 = load i1, ptr @olang_2esole_2ecompiler_2fbindgen_3agen_2e16
  br i1 %t320, label %bb56, label %bb57
bb56:
  %t322 = call ptr @__olang_region_make(ptr %v1)
  %t323 = ptrtoint ptr %t322 to i64
  store i64 %t323, ptr %l74, !tbaa !24
  br label %bb57
bb57:
  %t324 = load i64, ptr %l74
  %t325 = inttoptr i64 %t324 to ptr
  %t326 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20std_2fprelude_2ftext_3aString_26_3e_2ector(ptr %t325)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t326, ptr %l76
  br label %bb58
bb58:
  %t327 = load i1, ptr @olang_2esole_2ecompiler_2fbindgen_3agen_2e16
  br i1 %t327, label %bb59, label %bb60
bb59:
  %t329 = load i64, ptr %l74
  %t330 = inttoptr i64 %t329 to ptr
  %t331 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l76, i32 0, i32 2
  %t332 = load { i64, ptr }, ptr %t331
  %t333 = extractvalue { i64, ptr } %t332, 1
  %t334 = call ptr @__olang_region_or(ptr %t333, ptr null)
  %t335 = call ptr @__olang_region_home(ptr %t334)
  %t336 = icmp ne ptr %t335, null
  %t337 = select i1 %t336, ptr %t335, ptr null
  %t338 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l76, i32 0, i32 1
  %t339 = load { i64, ptr }, ptr %t338
  %t340 = extractvalue { i64, ptr } %t339, 1
  %t341 = call ptr @__olang_region_or(ptr %t340, ptr null)
  %t342 = call ptr @__olang_region_home(ptr %t341)
  %t343 = icmp ne ptr %t342, null
  %t344 = select i1 %t343, ptr %t342, ptr %t337
  %t345 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l76, i32 0, i32 0
  %t346 = load { i64, ptr }, ptr %t345
  %t347 = extractvalue { i64, ptr } %t346, 1
  %t348 = call ptr @__olang_region_or(ptr %t347, ptr null)
  %t349 = call ptr @__olang_region_home(ptr %t348)
  %t350 = icmp ne ptr %t349, null
  %t351 = select i1 %t350, ptr %t349, ptr %t344
  call void @__olang_region_settle_in(ptr %t330, ptr %t351)
  br label %bb60
bb60:
  %t352 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l76
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t352, ptr %l17
  %t353 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3actype_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t353, ptr %l78
  br label %bb61
bb61:
  %t354 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l78
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t354, ptr %l18
  %t355 = call ptr @__olang_scope_hold(ptr %v1)
  %t356 = ptrtoint ptr %t355 to i64
  store i64 %t356, ptr %l79, !tbaa !24
  %t357 = load i1, ptr @olang_2esole_2ecompiler_2fbindgen_3agen_2e18
  br i1 %t357, label %bb62, label %bb63
bb62:
  %t359 = call ptr @__olang_region_make(ptr %v1)
  %t360 = ptrtoint ptr %t359 to i64
  store i64 %t360, ptr %l79, !tbaa !24
  br label %bb63
bb63:
  %t361 = load i64, ptr %l79
  %t362 = inttoptr i64 %t361 to ptr
  %t363 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t362, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t363, ptr %l81
  br label %bb64
bb64:
  %t364 = load i1, ptr @olang_2esole_2ecompiler_2fbindgen_3agen_2e18
  br i1 %t364, label %bb65, label %bb66
bb65:
  %t366 = load i64, ptr %l79
  %t367 = inttoptr i64 %t366 to ptr
  %t368 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l81, i32 0, i32 0
  %t369 = load { i64, ptr }, ptr %t368
  %t370 = extractvalue { i64, ptr } %t369, 1
  %t371 = call ptr @__olang_region_or(ptr %t370, ptr null)
  %t372 = call ptr @__olang_region_home(ptr %t371)
  %t373 = icmp ne ptr %t372, null
  %t374 = select i1 %t373, ptr %t372, ptr null
  call void @__olang_region_settle_in(ptr %t367, ptr %t374)
  br label %bb66
bb66:
  %t375 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l81
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t375, ptr %l19
  %t376 = call ptr @__olang_scope_hold(ptr %v1)
  %t377 = ptrtoint ptr %t376 to i64
  store i64 %t377, ptr %l83, !tbaa !24
  %t378 = load i1, ptr @olang_2esole_2ecompiler_2fbindgen_3agen_2e19
  br i1 %t378, label %bb67, label %bb68
bb67:
  %t380 = call ptr @__olang_region_make(ptr %v1)
  %t381 = ptrtoint ptr %t380 to i64
  store i64 %t381, ptr %l83, !tbaa !24
  br label %bb68
bb68:
  %t382 = load i64, ptr %l83
  %t383 = inttoptr i64 %t382 to ptr
  %t384 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %t383, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t384, ptr %l85
  br label %bb69
bb69:
  %t385 = load i1, ptr @olang_2esole_2ecompiler_2fbindgen_3agen_2e19
  br i1 %t385, label %bb70, label %bb71
bb70:
  %t387 = load i64, ptr %l83
  %t388 = inttoptr i64 %t387 to ptr
  %t389 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l85, i32 0, i32 0
  %t390 = load { i64, ptr }, ptr %t389
  %t391 = extractvalue { i64, ptr } %t390, 1
  %t392 = call ptr @__olang_region_or(ptr %t391, ptr null)
  %t393 = call ptr @__olang_region_home(ptr %t392)
  %t394 = icmp ne ptr %t393, null
  %t395 = select i1 %t394, ptr %t393, ptr null
  call void @__olang_region_settle_in(ptr %t388, ptr %t395)
  br label %bb71
bb71:
  %t396 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l85
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t396, ptr %l20
  %t397 = call ptr @__olang_scope_hold(ptr %v1)
  %t398 = ptrtoint ptr %t397 to i64
  store i64 %t398, ptr %l87, !tbaa !24
  %t399 = load i1, ptr @olang_2esole_2ecompiler_2fbindgen_3agen_2e20
  br i1 %t399, label %bb72, label %bb73
bb72:
  %t401 = call ptr @__olang_region_make(ptr %v1)
  %t402 = ptrtoint ptr %t401 to i64
  store i64 %t402, ptr %l87, !tbaa !24
  br label %bb73
bb73:
  %t403 = load i64, ptr %l87
  %t404 = inttoptr i64 %t403 to ptr
  %t405 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %t404, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t405, ptr %l89
  br label %bb74
bb74:
  %t406 = load i1, ptr @olang_2esole_2ecompiler_2fbindgen_3agen_2e20
  br i1 %t406, label %bb75, label %bb76
bb75:
  %t408 = load i64, ptr %l87
  %t409 = inttoptr i64 %t408 to ptr
  %t410 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l89, i32 0, i32 0
  %t411 = load { i64, ptr }, ptr %t410
  %t412 = extractvalue { i64, ptr } %t411, 1
  %t413 = call ptr @__olang_region_or(ptr %t412, ptr null)
  %t414 = call ptr @__olang_region_home(ptr %t413)
  %t415 = icmp ne ptr %t414, null
  %t416 = select i1 %t415, ptr %t414, ptr null
  call void @__olang_region_settle_in(ptr %t409, ptr %t416)
  br label %bb76
bb76:
  %t417 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l89
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t417, ptr %l21
  %t418 = call ptr @__olang_scope_hold(ptr %v1)
  %t419 = ptrtoint ptr %t418 to i64
  store i64 %t419, ptr %l91, !tbaa !24
  %t420 = load i1, ptr @olang_2esole_2ecompiler_2fbindgen_3agen_2e21
  br i1 %t420, label %bb77, label %bb78
bb77:
  %t422 = call ptr @__olang_region_make(ptr %v1)
  %t423 = ptrtoint ptr %t422 to i64
  store i64 %t423, ptr %l91, !tbaa !24
  br label %bb78
bb78:
  %t424 = load i64, ptr %l91
  %t425 = inttoptr i64 %t424 to ptr
  %t426 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %t425)
  store %"std/prelude/text:StringBuilder" %t426, ptr %l93
  br label %bb79
bb79:
  %t427 = load i1, ptr @olang_2esole_2ecompiler_2fbindgen_3agen_2e21
  br i1 %t427, label %bb80, label %bb81
bb80:
  %t429 = load i64, ptr %l91
  %t430 = inttoptr i64 %t429 to ptr
  %t431 = getelementptr %"std/prelude/text:StringBuilder", ptr %l93, i32 0, i32 0
  %t432 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t431, i32 0, i32 0
  %t433 = load { i64, ptr }, ptr %t432
  %t434 = extractvalue { i64, ptr } %t433, 1
  %t435 = call ptr @__olang_region_or(ptr %t434, ptr null)
  %t436 = call ptr @__olang_region_home(ptr %t435)
  %t437 = icmp ne ptr %t436, null
  %t438 = select i1 %t437, ptr %t436, ptr null
  call void @__olang_region_settle_in(ptr %t430, ptr %t438)
  br label %bb81
bb81:
  %t439 = load %"std/prelude/text:StringBuilder", ptr %l93
  store %"std/prelude/text:StringBuilder" %t439, ptr %l22
  %t440 = call ptr @__olang_scope_hold(ptr %v1)
  %t441 = ptrtoint ptr %t440 to i64
  store i64 %t441, ptr %l95, !tbaa !24
  %t442 = load i1, ptr @olang_2esole_2ecompiler_2fbindgen_3agen_2e22
  br i1 %t442, label %bb82, label %bb83
bb82:
  %t444 = call ptr @__olang_region_make(ptr %v1)
  %t445 = ptrtoint ptr %t444 to i64
  store i64 %t445, ptr %l95, !tbaa !24
  br label %bb83
bb83:
  %t446 = load i64, ptr %l95
  %t447 = inttoptr i64 %t446 to ptr
  %t448 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e_2ector(ptr %t447)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t448, ptr %l97
  br label %bb84
bb84:
  %t449 = load i1, ptr @olang_2esole_2ecompiler_2fbindgen_3agen_2e22
  br i1 %t449, label %bb85, label %bb86
bb85:
  %t451 = load i64, ptr %l95
  %t452 = inttoptr i64 %t451 to ptr
  %t453 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l97, i32 0, i32 2
  %t454 = load { i64, ptr }, ptr %t453
  %t455 = extractvalue { i64, ptr } %t454, 1
  %t456 = call ptr @__olang_region_or(ptr %t455, ptr null)
  %t457 = call ptr @__olang_region_home(ptr %t456)
  %t458 = icmp ne ptr %t457, null
  %t459 = select i1 %t458, ptr %t457, ptr null
  %t460 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l97, i32 0, i32 1
  %t461 = load { i64, ptr }, ptr %t460
  %t462 = extractvalue { i64, ptr } %t461, 1
  %t463 = call ptr @__olang_region_or(ptr %t462, ptr null)
  %t464 = call ptr @__olang_region_home(ptr %t463)
  %t465 = icmp ne ptr %t464, null
  %t466 = select i1 %t465, ptr %t464, ptr %t459
  %t467 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l97, i32 0, i32 0
  %t468 = load { i64, ptr }, ptr %t467
  %t469 = extractvalue { i64, ptr } %t468, 1
  %t470 = call ptr @__olang_region_or(ptr %t469, ptr null)
  %t471 = call ptr @__olang_region_home(ptr %t470)
  %t472 = icmp ne ptr %t471, null
  %t473 = select i1 %t472, ptr %t471, ptr %t466
  call void @__olang_region_settle_in(ptr %t452, ptr %t473)
  br label %bb86
bb86:
  %t474 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l97
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t474, ptr %l23
  %t475 = call ptr @__olang_scope_hold(ptr %v1)
  %t476 = ptrtoint ptr %t475 to i64
  store i64 %t476, ptr %l99, !tbaa !24
  %t477 = load i1, ptr @olang_2esole_2ecompiler_2fbindgen_3agen_2e23
  br i1 %t477, label %bb87, label %bb88
bb87:
  %t479 = call ptr @__olang_region_make(ptr %v1)
  %t480 = ptrtoint ptr %t479 to i64
  store i64 %t480, ptr %l99, !tbaa !24
  br label %bb88
bb88:
  %t481 = load i64, ptr %l99
  %t482 = inttoptr i64 %t481 to ptr
  %t483 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20std_2fprelude_2ftext_3aString_26_3e_2ector(ptr %t482)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t483, ptr %l101
  br label %bb89
bb89:
  %t484 = load i1, ptr @olang_2esole_2ecompiler_2fbindgen_3agen_2e23
  br i1 %t484, label %bb90, label %bb91
bb90:
  %t486 = load i64, ptr %l99
  %t487 = inttoptr i64 %t486 to ptr
  %t488 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l101, i32 0, i32 2
  %t489 = load { i64, ptr }, ptr %t488
  %t490 = extractvalue { i64, ptr } %t489, 1
  %t491 = call ptr @__olang_region_or(ptr %t490, ptr null)
  %t492 = call ptr @__olang_region_home(ptr %t491)
  %t493 = icmp ne ptr %t492, null
  %t494 = select i1 %t493, ptr %t492, ptr null
  %t495 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l101, i32 0, i32 1
  %t496 = load { i64, ptr }, ptr %t495
  %t497 = extractvalue { i64, ptr } %t496, 1
  %t498 = call ptr @__olang_region_or(ptr %t497, ptr null)
  %t499 = call ptr @__olang_region_home(ptr %t498)
  %t500 = icmp ne ptr %t499, null
  %t501 = select i1 %t500, ptr %t499, ptr %t494
  %t502 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l101, i32 0, i32 0
  %t503 = load { i64, ptr }, ptr %t502
  %t504 = extractvalue { i64, ptr } %t503, 1
  %t505 = call ptr @__olang_region_or(ptr %t504, ptr null)
  %t506 = call ptr @__olang_region_home(ptr %t505)
  %t507 = icmp ne ptr %t506, null
  %t508 = select i1 %t507, ptr %t506, ptr %t501
  call void @__olang_region_settle_in(ptr %t487, ptr %t508)
  br label %bb91
bb91:
  %t509 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l101
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t509, ptr %l24
  store i1 false, ptr %l25, !tbaa !21
  %t510 = call ptr @__olang_scope_hold(ptr %v1)
  %t511 = ptrtoint ptr %t510 to i64
  store i64 %t511, ptr %l103, !tbaa !24
  %t512 = load i1, ptr @olang_2esole_2ecompiler_2fbindgen_3agen_2e25
  br i1 %t512, label %bb92, label %bb93
bb92:
  %t514 = call ptr @__olang_region_make(ptr %v1)
  %t515 = ptrtoint ptr %t514 to i64
  store i64 %t515, ptr %l103, !tbaa !24
  br label %bb93
bb93:
  %t516 = load i64, ptr %l103
  %t517 = inttoptr i64 %t516 to ptr
  %t518 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e_2ector(ptr %t517)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t518, ptr %l105
  br label %bb94
bb94:
  %t519 = load i1, ptr @olang_2esole_2ecompiler_2fbindgen_3agen_2e25
  br i1 %t519, label %bb95, label %bb96
bb95:
  %t521 = load i64, ptr %l103
  %t522 = inttoptr i64 %t521 to ptr
  %t523 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l105, i32 0, i32 2
  %t524 = load { i64, ptr }, ptr %t523
  %t525 = extractvalue { i64, ptr } %t524, 1
  %t526 = call ptr @__olang_region_or(ptr %t525, ptr null)
  %t527 = call ptr @__olang_region_home(ptr %t526)
  %t528 = icmp ne ptr %t527, null
  %t529 = select i1 %t528, ptr %t527, ptr null
  %t530 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l105, i32 0, i32 1
  %t531 = load { i64, ptr }, ptr %t530
  %t532 = extractvalue { i64, ptr } %t531, 1
  %t533 = call ptr @__olang_region_or(ptr %t532, ptr null)
  %t534 = call ptr @__olang_region_home(ptr %t533)
  %t535 = icmp ne ptr %t534, null
  %t536 = select i1 %t535, ptr %t534, ptr %t529
  %t537 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l105, i32 0, i32 0
  %t538 = load { i64, ptr }, ptr %t537
  %t539 = extractvalue { i64, ptr } %t538, 1
  %t540 = call ptr @__olang_region_or(ptr %t539, ptr null)
  %t541 = call ptr @__olang_region_home(ptr %t540)
  %t542 = icmp ne ptr %t541, null
  %t543 = select i1 %t542, ptr %t541, ptr %t536
  call void @__olang_region_settle_in(ptr %t522, ptr %t543)
  br label %bb96
bb96:
  %t544 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l105
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d400, i32 0, i32 1) }, ptr %l27, !tbaa !27
  %t545 = getelementptr %"compiler/bindgen:gen", ptr %l107, i32 0, i32 0
  %t546 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t546, ptr %t545, !tbaa !27
  %t547 = getelementptr %"compiler/bindgen:gen", ptr %l107, i32 0, i32 1
  %t548 = load i1, ptr %l2, !tbaa !21
  store i1 %t548, ptr %t547, !tbaa !21
  %t549 = getelementptr %"compiler/bindgen:gen", ptr %l107, i32 0, i32 2
  %t550 = load i1, ptr %l3, !tbaa !21
  store i1 %t550, ptr %t549, !tbaa !21
  %t551 = getelementptr %"compiler/bindgen:gen", ptr %l107, i32 0, i32 3
  %t552 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t552, ptr %t551, !tbaa !27
  %t553 = getelementptr %"compiler/bindgen:gen", ptr %l107, i32 0, i32 4
  %t554 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t554, ptr %t553, !tbaa !27
  %t555 = getelementptr %"compiler/bindgen:gen", ptr %l107, i32 0, i32 5
  %t556 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l6
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t556, ptr %t555
  %t557 = getelementptr %"compiler/bindgen:gen", ptr %l107, i32 0, i32 6
  %t558 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l7
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t558, ptr %t557
  %t559 = getelementptr %"compiler/bindgen:gen", ptr %l107, i32 0, i32 7
  %t560 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l8
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t560, ptr %t559
  %t561 = getelementptr %"compiler/bindgen:gen", ptr %l107, i32 0, i32 8
  %t562 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l9
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t562, ptr %t561
  %t563 = getelementptr %"compiler/bindgen:gen", ptr %l107, i32 0, i32 9
  %t564 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l10
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t564, ptr %t563
  %t565 = getelementptr %"compiler/bindgen:gen", ptr %l107, i32 0, i32 10
  %t566 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l11
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t566, ptr %t565
  %t567 = getelementptr %"compiler/bindgen:gen", ptr %l107, i32 0, i32 11
  %t568 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l12
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t568, ptr %t567
  %t569 = getelementptr %"compiler/bindgen:gen", ptr %l107, i32 0, i32 12
  %t570 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l13
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t570, ptr %t569
  %t571 = getelementptr %"compiler/bindgen:gen", ptr %l107, i32 0, i32 13
  %t572 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l14
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t572, ptr %t571
  %t573 = getelementptr %"compiler/bindgen:gen", ptr %l107, i32 0, i32 14
  %t574 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l15
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t574, ptr %t573
  %t575 = getelementptr %"compiler/bindgen:gen", ptr %l107, i32 0, i32 15
  %t576 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l16
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t576, ptr %t575
  %t577 = getelementptr %"compiler/bindgen:gen", ptr %l107, i32 0, i32 16
  %t578 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l17
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t578, ptr %t577
  %t579 = getelementptr %"compiler/bindgen:gen", ptr %l107, i32 0, i32 17
  %t580 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l18
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t580, ptr %t579
  %t581 = getelementptr %"compiler/bindgen:gen", ptr %l107, i32 0, i32 18
  %t582 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l19
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t582, ptr %t581
  %t583 = getelementptr %"compiler/bindgen:gen", ptr %l107, i32 0, i32 19
  %t584 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l20
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t584, ptr %t583
  %t585 = getelementptr %"compiler/bindgen:gen", ptr %l107, i32 0, i32 20
  %t586 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l21
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t586, ptr %t585
  %t587 = getelementptr %"compiler/bindgen:gen", ptr %l107, i32 0, i32 21
  %t588 = load %"std/prelude/text:StringBuilder", ptr %l22
  store %"std/prelude/text:StringBuilder" %t588, ptr %t587
  %t589 = getelementptr %"compiler/bindgen:gen", ptr %l107, i32 0, i32 22
  %t590 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l23
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t590, ptr %t589
  %t591 = getelementptr %"compiler/bindgen:gen", ptr %l107, i32 0, i32 23
  %t592 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l24
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t592, ptr %t591
  %t593 = getelementptr %"compiler/bindgen:gen", ptr %l107, i32 0, i32 24
  %t594 = load i1, ptr %l25, !tbaa !21
  store i1 %t594, ptr %t593, !tbaa !21
  %t595 = getelementptr %"compiler/bindgen:gen", ptr %l107, i32 0, i32 25
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t544, ptr %t595
  %t597 = getelementptr %"compiler/bindgen:gen", ptr %l107, i32 0, i32 26
  %t598 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t598, ptr %t597, !tbaa !27
  %t599 = getelementptr %"compiler/bindgen:gen", ptr %l107, i32 0, i32 27
  store i64 0, ptr %t599, !tbaa !24
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l107, i64 1128, i1 false)
  br label %ret
ret:
  ret void
}

define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ; B19b: a benchmark build counts what this thread allocates - here and at the slow path's own bump, so each
  ; allocation is counted once wherever it is made (a region's and a forwarded scope's come back through here)
; @bench %bna = load i64, ptr @__olang_bench_allocs
; @bench %bna1 = add i64 %bna, 1
; @bench store i64 %bna1, ptr @__olang_bench_allocs
; @bench %bnb = load i64, ptr @__olang_bench_bytes
; @bench %bnb1 = add i64 %bnb, %size
; @bench store i64 %bnb1, ptr @__olang_bench_bytes
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
@.d0 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d1 = private constant <{ i64, [53 x i8] }> <{ i64 0, [53 x i8] c"a C import needs clang, and there is none on the PATH" }>, align 8
@olang_2esole_2ecompiler_2fbindgen_3aTranslation_2e3 = weak hidden constant i1 false
declare void @__olang_region_release(ptr) noinline
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %dh = load ptr, ptr %dheadptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  %hasd = icmp ne ptr %dh, null
  %owns = or i1 %hasf, %hasd
  br i1 %owns, label %owned, label %chunks
owned:
  call void @__olang_scope_close_owned(ptr %scope)
  br label %chunks
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
@.d2 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d3 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"olang-cimport" }>, align 8
declare void @__olang_errpay_pop()
@.d4 = private constant <{ i64, [36 x i8] }> <{ i64 0, [36 x i8] c"a temporary directory cannot be made" }>, align 8
@.d5 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"probe.c" }>, align 8
@.d6 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@.d7 = private constant <{ i64, [27 x i8] }> <{ i64 0, [27 x i8] c"the probe cannot be written" }>, align 8
define available_externally ptr @__olang_scope_hold(ptr %s) alwaysinline {
entry:
  %none = icmp eq ptr %s, null
  br i1 %none, label %plain, label %look
look:
  ; atomic: on a scope that is no stand-in this word is its parts list, which other threads push onto (__olang_scope_part)
  %mp = getelementptr %olang.scope, ptr %s, i32 0, i32 4
  %m = load atomic ptr, ptr %mp monotonic, align 8
  %fresh = icmp eq ptr %m, @__olang_standin_mark
  br i1 %fresh, label %make, label %kept
kept:
  %mi = ptrtoint ptr %m to i64
  %bit = and i64 %mi, 1
  %has = icmp ne i64 %bit, 0
  br i1 %has, label %keeper, label %plain
keeper:
  %ki = and i64 %mi, -2
  %k = inttoptr i64 %ki to ptr
  ret ptr %k
make:
  %f = call ptr @__olang_standin_keeper(ptr %s)
  ret ptr %f
plain:
  ret ptr %s
}
@olang_2esole_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e0 = weak hidden constant i1 false
declare ptr @__olang_region_make_part(ptr) noinline
define available_externally noalias ptr @__olang_held_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare ptr @__olang_region_or(ptr, ptr)
declare void @__olang_region_settle_in(ptr, ptr)
@.d8 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d9 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d10 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"--target=" }>, align 8
@.d11 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"-windows" }>, align 8
@olang_2esole_2ecompiler_2fbindgen_3agen_2e3 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fbindgen_3agen_2e4 = weak hidden constant i1 false
@.d12 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"-E" }>, align 8
@.d13 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"-dD" }>, align 8
@.d14 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"-x" }>, align 8
@.d15 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"c" }>, align 8
@.d16 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"-w" }>, align 8
@.d17 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c"clang could not be run" }>, align 8
@.d18 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"file not found" }>, align 8
declare ptr @__olang_region_make(ptr) noinline
@.d19 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d20 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d21 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"enum __olang_m" }>, align 8
declare i64 @__olang_fmt_i64(ptr, i64)
@.d22 = private constant <{ i64, [24 x i8] }> <{ i64 0, [24 x i8] c" : long long { __olang_v" }>, align 8
@.d23 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" = (" }>, align 8
@.d24 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c") };\0A" }>, align 8
@.d25 = private constant <{ i64, [27 x i8] }> <{ i64 0, [27 x i8] c"the probe cannot be written" }>, align 8
@.d26 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"name" }>, align 8
@.d27 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"kind" }>, align 8
@.d28 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"EnumDecl" }>, align 8
@.d29 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"__olang_m" }>, align 8
declare void @__olang_check_failed(ptr) cold noreturn
@.d30 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2ecompiler_2fbindgen_3aTranslation_2e0 = weak hidden constant i1 false
@.d31 = private constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c"# olang's translation of " }>, align 8
@.d32 = private constant <{ i64, [70 x i8] }> <{ i64 0, [70 x i8] c" (X17), made by the compiler: C's declarations as olang declares them\0A" }>, align 8
@.d33 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2ecompiler_2fbindgen_3aTranslation_2e1 = weak hidden constant i1 false
@.d34 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"/* olang C import: " }>, align 8
@.d35 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" */\0A" }>, align 8
@.d36 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d37 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Bool" }>, align 8
@.d38 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Bool" }>, align 8
@.d39 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"U" }>, align 8
@.d40 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"I" }>, align 8
@.d41 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"I" }>, align 8
@.d42 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"U" }>, align 8
@.d43 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"variadic" }>, align 8
@.d44 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"CVoid?&" }>, align 8
@.d45 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2ecompiler_2fbindgen_3agen_2e26 = weak hidden constant i1 false
@.d46 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d47 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"extern " }>, align 8
@.d48 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"CVoid?&" }>, align 8
@.d49 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d50 = private constant <{ i64, [47 x i8] }> <{ i64 0, [47 x i8] c"its body is empty where an expression is wanted" }>, align 8
@.d51 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d52 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d53 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"a ( with no )" }>, align 8
@olang_2esole_2ecompiler_2fbindgen_3acx_2e0 = weak hidden constant i1 false
@.d54 = private constant <{ i64, [43 x i8] }> <{ i64 0, [43 x i8] c"it holds text where an expression is wanted" }>, align 8
define available_externally void @__olang_scope_escape(ptr %s) alwaysinline {
entry:
  %op = getelementptr %olang.scope, ptr %s, i32 0, i32 3
  %o = load atomic ptr, ptr %op monotonic, align 8
  %un = icmp eq ptr %o, null
  br i1 %un, label %claim, label %done
claim:
  %me = load ptr, ptr @__olang_self
  store atomic ptr %me, ptr %op monotonic, align 8
  br label %done
done:
  ret void
}
define internal i1 @olang_lambda_55(ptr %env, ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l4 = alloca i1
  %rv = alloca i1
  %cp0 = getelementptr { { i64, ptr }, ptr }, ptr %env, i32 0, i32 0
  %cv0 = load { i64, ptr }, ptr %cp0, !tbaa !28
  %vq0 = getelementptr { { i64, ptr }, ptr }, ptr %env, i32 0, i32 1
  %vr0 = load ptr, ptr %vq0, !tbaa !28
  %vc0 = call ptr @__olang_capture_scope(ptr %vr0)
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %vc0, { i64, ptr } %a0, { i64, ptr } %cv0)
  store i1 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i1, ptr %l4, !tbaa !21
  store i1 %t6, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d56 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"a" }>, align 8
@.d57 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d58 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d59 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d60 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d61 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d62 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d63 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"it calls " }>, align 8
@.d64 = private constant <{ i64, [38 x i8] }> <{ i64 0, [38 x i8] c", which is no function of numbers here" }>, align 8
@.d65 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d66 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d67 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"," }>, align 8
@.d68 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"its call of " }>, align 8
@.d69 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c" is not read" }>, align 8
@.d70 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d71 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d72 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Bool" }>, align 8
@.d73 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"it names " }>, align 8
@.d74 = private constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c", which has no value here" }>, align 8
@.d75 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d76 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d77 = private constant <{ i64, [11 x { i64, ptr }] }> <{ i64 0, [11 x { i64, ptr }] [{ i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d401, i32 0, i32 1) }, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d402, i32 0, i32 1) }, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d403, i32 0, i32 1) }, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d404, i32 0, i32 1) }, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d405, i32 0, i32 1) }, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d406, i32 0, i32 1) }, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d407, i32 0, i32 1) }, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d408, i32 0, i32 1) }, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d409, i32 0, i32 1) }, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d410, i32 0, i32 1) }, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d411, i32 0, i32 1) }] }>, align 8
@.d78 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d79 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d80 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"char" }>, align 8
@.d81 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"I8" }>, align 8
@.d82 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"*" }>, align 8
@.d83 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d84 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"const" }>, align 8
@.d85 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"const" }>, align 8
@.d86 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d87 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"*" }>, align 8
@.d88 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d89 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"[" }>, align 8
@.d90 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d91 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d92 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d93 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d94 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"..." }>, align 8
@.d95 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d96 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"," }>, align 8
@.d97 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"variadic" }>, align 8
@.d98 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d99 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"[" }>, align 8
@.d100 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"]" }>, align 8
@.d101 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0 = weak hidden constant i1 false
@.d102 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d103 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"fn?&(" }>, align 8
@.d104 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d105 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"a" }>, align 8
@.d106 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d107 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d108 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
define linkonce_odr void @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2fbindgen_3arecord(ptr %out, ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"compiler/bindgen:record"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l9 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l11 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l13 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  call void @llvm.memmove.p0.p0.i64(ptr %l1, ptr %a0, i64 312, i1 false)
  %t2 = getelementptr %"compiler/bindgen:record", ptr %l1, i32 0, i32 4
  %t4 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, ptr %t2)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t4, ptr %l3
  br label %bb1
bb1:
  %t5 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  %t6 = getelementptr %"compiler/bindgen:record", ptr %l1, i32 0, i32 4
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %t6
  %t7 = getelementptr %"compiler/bindgen:record", ptr %l1, i32 0, i32 5
  %t9 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, ptr %t7)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %l5
  br label %bb2
bb2:
  %t10 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l5
  %t11 = getelementptr %"compiler/bindgen:record", ptr %l1, i32 0, i32 5
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t10, ptr %t11
  %t12 = getelementptr %"compiler/bindgen:record", ptr %l1, i32 0, i32 16
  %t14 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %t12)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t14, ptr %l7
  br label %bb3
bb3:
  %t15 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l7
  %t16 = getelementptr %"compiler/bindgen:record", ptr %l1, i32 0, i32 16
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t15, ptr %t16
  %t17 = getelementptr %"compiler/bindgen:record", ptr %l1, i32 0, i32 17
  %t19 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %t17)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t19, ptr %l9
  br label %bb4
bb4:
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l9
  %t21 = getelementptr %"compiler/bindgen:record", ptr %l1, i32 0, i32 17
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %t21
  %t22 = getelementptr %"compiler/bindgen:record", ptr %l1, i32 0, i32 18
  %t24 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %t22)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t24, ptr %l11
  br label %bb5
bb5:
  %t25 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l11
  %t26 = getelementptr %"compiler/bindgen:record", ptr %l1, i32 0, i32 18
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t25, ptr %t26
  %t27 = getelementptr %"compiler/bindgen:record", ptr %l1, i32 0, i32 19
  %t29 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %t27)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t29, ptr %l13
  br label %bb6
bb6:
  %t30 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l13
  %t31 = getelementptr %"compiler/bindgen:record", ptr %l1, i32 0, i32 19
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t30, ptr %t31
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l1, i64 312, i1 false)
  br label %ret
ret:
  ret void
}

@.d109 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d110 = private constant <{ i64, [39 x i8] }> <{ i64 0, [39 x i8] c"it takes a variable number of arguments" }>, align 8
@.d111 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d112 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d113 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d114 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d115 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"struct " }>, align 8
@.d116 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"union " }>, align 8
@.d117 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d118 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d119 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"void" }>, align 8
@.d120 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d121 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"_Bool" }>, align 8
@.d122 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"bool" }>, align 8
@.d123 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Bool" }>, align 8
@.d124 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"char" }>, align 8
@.d125 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"I8" }>, align 8
@.d126 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"U8" }>, align 8
@.d127 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"char" }>, align 8
@.d128 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"float" }>, align 8
@.d129 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"F32" }>, align 8
@.d130 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"double" }>, align 8
@.d131 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"long double" }>, align 8
@.d132 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"F64" }>, align 8
@.d133 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"_Float16" }>, align 8
@.d134 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"F16" }>, align 8
@.d135 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"__bf16" }>, align 8
@.d136 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"BF16" }>, align 8
@.d137 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"__int128" }>, align 8
@.d138 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"__int128" }>, align 8
@.d139 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"short" }>, align 8
@.d140 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"U16" }>, align 8
@.d141 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I16" }>, align 8
@.d142 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"U64" }>, align 8
@.d143 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I64" }>, align 8
@.d144 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"U32" }>, align 8
@.d145 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I32" }>, align 8
@.d146 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d147 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"F" }>, align 8
@olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1 = weak hidden constant i1 false
@.d148 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"    " }>, align 8
@.d149 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d150 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d151 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"F" }>, align 8
@.d152 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Bool" }>, align 8
@.d153 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"char" }>, align 8
@.d154 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"U8" }>, align 8
@.d155 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"    " }>, align 8
@.d156 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c" := Array<" }>, align 8
@.d157 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c">(" }>, align 8
@.d158 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c")\0A" }>, align 8
@.d159 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Bool" }>, align 8
@.d160 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"char" }>, align 8
@.d161 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"U8" }>, align 8
@.d162 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"    " }>, align 8
@.d163 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d164 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d165 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"F" }>, align 8
@.d166 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"BF16" }>, align 8
@.d167 = private constant <{ i64, [27 x i8] }> <{ i64 0, [27 x i8] c"a typedef that names itself" }>, align 8
@olang_2esole_2ecompiler_2fbindgen_3actp_2e0 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fbindgen_3actype_2e1 = weak hidden constant i1 false
@.d168 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d169 = private constant <{ i64, [31 x i8] }> <{ i64 0, [31 x i8] c"', which is no C type read here" }>, align 8
@.d170 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d171 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"# " }>, align 8
@.d172 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\22" }>, align 8
@olang_2esole_2ecompiler__2fbindgen__2ecompiler__2fbindgen__3agen__2ereadMacros_2elocal_2e5 = weak hidden constant i1 false
@.d173 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"\5C\5C" }>, align 8
@.d174 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\5C" }>, align 8
@.d175 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"<" }>, align 8
@.d176 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"<" }>, align 8
@.d177 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"#undef " }>, align 8
@.d178 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2ecompiler_2fbindgen_3acMacro_2e0 = weak hidden constant i1 false
@.d179 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"#define " }>, align 8
@.d180 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"," }>, align 8
@.d181 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"..." }>, align 8
@.d182 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"..." }>, align 8
@.d183 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2ecompiler_2fbindgen_3acMacro_2e2 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fbindgen_3acMacro_2e3 = weak hidden constant i1 false
@.d184 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d185 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"tagUsed" }>, align 8
@.d186 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"union" }>, align 8
@.d187 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d188 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2estd_2fprelude_2fmap_3aMapEntry_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e_2e0 = weak hidden constant i1 false
@.d189 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"id" }>, align 8
@.d190 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"union " }>, align 8
@.d191 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"struct " }>, align 8
@.d192 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"completeDefinition" }>, align 8
@.d193 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"kind" }>, align 8
@.d194 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"TransparentUnionAttr" }>, align 8
@.d195 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"PackedAttr" }>, align 8
@.d196 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"RecordDecl" }>, align 8
@.d197 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"name" }>, align 8
@.d198 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d199 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"RecordDecl" }>, align 8
@.d200 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"name" }>, align 8
@.d201 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"FieldDecl" }>, align 8
@.d202 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"name" }>, align 8
@.d203 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d204 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"isBitfield" }>, align 8
@.d205 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"isBitfield" }>, align 8
@.d206 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"name" }>, align 8
@.d207 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"type " }>, align 8
@.d208 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c" packed struct() {\0A" }>, align 8
@.d209 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"}\0A" }>, align 8
@.d210 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"type " }>, align 8
@.d211 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c" struct() {\0A" }>, align 8
@.d212 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I64" }>, align 8
@.d213 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I32" }>, align 8
@.d214 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I16" }>, align 8
@.d215 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"U8" }>, align 8
@.d216 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"    bytes := Array<" }>, align 8
@.d217 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c">(" }>, align 8
@.d218 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c")\0A}\0A" }>, align 8
@.d219 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"}\0A" }>, align 8
@.d220 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"}\0A" }>, align 8
@.d221 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d222 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d223 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d224 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"const" }>, align 8
@.d225 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"signed" }>, align 8
@.d226 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"unsigned" }>, align 8
@.d227 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"long" }>, align 8
@.d228 = private constant <{ i64, [11 x { i64, ptr }] }> <{ i64 0, [11 x { i64, ptr }] [{ i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d405, i32 0, i32 1) }, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d401, i32 0, i32 1) }, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d406, i32 0, i32 1) }, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d407, i32 0, i32 1) }, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d408, i32 0, i32 1) }, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d412, i32 0, i32 1) }, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d409, i32 0, i32 1) }, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d413, i32 0, i32 1) }, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d414, i32 0, i32 1) }, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d415, i32 0, i32 1) }, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d416, i32 0, i32 1) }] }>, align 8
@.d229 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"int" }>, align 8
@.d230 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"struct" }>, align 8
@.d231 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2ecompiler__2fbindgen__2ecompiler__2fbindgen__3agen__2etypeName_2elocal_2e5 = weak hidden constant i1 false
@.d232 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"union" }>, align 8
@.d233 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"enum" }>, align 8
@olang_2esole_2ecompiler__2fbindgen__2ecompiler__2fbindgen__3agen__2etypeName_2elocal_2e7 = weak hidden constant i1 false
@.d234 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2ecompiler__2fbindgen__2ecompiler__2fbindgen__3agen__2etypeName_2elocal_2e8 = weak hidden constant i1 false
@.d235 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d236 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d237 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"enum" }>, align 8
@.d238 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I32" }>, align 8
@.d239 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d240 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d241 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d242 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d243 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"', a " }>, align 8
@.d244 = private constant <{ i64, [45 x i8] }> <{ i64 0, [45 x i8] c" with no name of its own, or the C compiler's" }>, align 8
@.d245 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d246 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d247 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"a " }>, align 8
@.d248 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c" with no name" }>, align 8
@.d249 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d250 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d251 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d252 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d253 = private constant <{ i64, [30 x i8] }> <{ i64 0, [30 x i8] c"', a type no declaration names" }>, align 8
@.d254 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d255 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d256 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d257 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"set_" }>, align 8
@.d258 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"bytes" }>, align 8
@.d259 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"c_gap" }>, align 8
@.d260 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"_" }>, align 8
@.d261 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"char" }>, align 8
@.d262 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"I8" }>, align 8
@.d263 = private constant <{ i64, [46 x i8] }> <{ i64 0, [46 x i8] c"a struct by value that is not plain data (X11)" }>, align 8
@.d264 = private constant <{ i64, [47 x i8] }> <{ i64 0, [47 x i8] c"a packed struct holding a float by value (X11a)" }>, align 8
@.d265 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"CStr?&" }>, align 8
@.d266 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"?&" }>, align 8
@.d267 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d268 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"mut " }>, align 8
@.d269 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"?&" }>, align 8
@.d270 = private constant <{ i64, [31 x i8] }> <{ i64 0, [31 x i8] c"a pointer to plain-data struct " }>, align 8
@.d271 = private constant <{ i64, [67 x i8] }> <{ i64 0, [67 x i8] c" as a result - an extern gives only an extern type's reference (X2)" }>, align 8
@.d272 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"CVoid?&" }>, align 8
@.d273 = private constant <{ i64, [45 x i8] }> <{ i64 0, [45 x i8] c"a value of this type, which has no olang form" }>, align 8
@.d274 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d275 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"c_" }>, align 8
@.d276 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"..." }>, align 8
@.d277 = private constant <{ i64, [59 x i8] }> <{ i64 0, [59 x i8] c"static or inline, and taking a variable number of arguments" }>, align 8
@.d278 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d279 = private constant <{ i64, [55 x i8] }> <{ i64 0, [55 x i8] c"static or inline, its result's type no olang form wraps" }>, align 8
@.d280 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"olang_ci_" }>, align 8
@.d281 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"_" }>, align 8
@.d282 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d283 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d284 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"void" }>, align 8
@.d285 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d286 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"__typeof__(" }>, align 8
@.d287 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c") olang_a" }>, align 8
@.d288 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c") { " }>, align 8
@.d289 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"void" }>, align 8
@.d290 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"return " }>, align 8
@.d291 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d292 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d293 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"olang_a" }>, align 8
@.d294 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"); }\0A" }>, align 8
@.d295 = private constant <{ i64, [64 x i8] }> <{ i64 0, [64 x i8] c": a name olang cannot declare (a keyword, or beginning with '_')" }>, align 8
@.d296 = private constant <{ i64, [39 x i8] }> <{ i64 0, [39 x i8] c": a name every olang module has already" }>, align 8
@.d297 = private constant <{ i64, [52 x i8] }> <{ i64 0, [52 x i8] c": static or inline in the header - no symbol to link" }>, align 8
@.d298 = private constant <{ i64, [43 x i8] }> <{ i64 0, [43 x i8] c": static in its file - C's own to that file" }>, align 8
@.d299 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c": " }>, align 8
@.d300 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d301 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c": " }>, align 8
@.d302 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d303 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"    " }>, align 8
@.d304 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d305 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"# symbol " }>, align 8
@.d306 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d307 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d308 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d309 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"    type " }>, align 8
@.d310 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d311 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"\0Aextern {\0A" }>, align 8
@.d312 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"}\0A" }>, align 8
@.d313 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d314 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d315 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d316 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d317 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"\0A# not declared:\0A" }>, align 8
@.d318 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"#   " }>, align 8
@.d319 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d320 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"char" }>, align 8
@.d321 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Bool" }>, align 8
@.d322 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"BF16" }>, align 8
@.d323 = private constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c" __attribute__((cdecl))" }>, align 8
@.d324 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d325 = private constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c" __attribute__((stdcall))" }>, align 8
@.d326 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d327 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d328 = private constant <{ i64, [53 x i8] }> <{ i64 0, [53 x i8] c"olang: bindgen needs clang, which is not on the PATH\0A" }>, align 8
@.d329 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"olang: " }>, align 8
@.d330 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c": no such file\0A" }>, align 8
@.d331 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"olang: " }>, align 8
@.d332 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c": no such file\0A" }>, align 8
@.d333 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d334 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"olang-bindgen" }>, align 8
@.d335 = private constant <{ i64, [50 x i8] }> <{ i64 0, [50 x i8] c"olang: bindgen: cannot make a temporary directory\0A" }>, align 8
@.d336 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"probe.c" }>, align 8
@.d337 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"#include \22" }>, align 8
@.d338 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\22" }>, align 8
@.d339 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d340 = private constant <{ i64, [29 x i8] }> <{ i64 0, [29 x i8] c"olang: bindgen: cannot write " }>, align 8
@.d341 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
@.d342 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"-E" }>, align 8
@.d343 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"-dD" }>, align 8
@.d344 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"-x" }>, align 8
@.d345 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"c" }>, align 8
@.d346 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"-w" }>, align 8
@.d347 = private constant <{ i64, [39 x i8] }> <{ i64 0, [39 x i8] c"olang: bindgen: clang could not be run\0A" }>, align 8
@.d348 = private constant <{ i64, [37 x i8] }> <{ i64 0, [37 x i8] c"olang: bindgen: clang could not read " }>, align 8
@.d349 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c":\0A" }>, align 8
@.d350 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d351 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"enum __olang_m" }>, align 8
@.d352 = private constant <{ i64, [24 x i8] }> <{ i64 0, [24 x i8] c" : long long { __olang_v" }>, align 8
@.d353 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" = (" }>, align 8
@.d354 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c") };\0A" }>, align 8
@.d355 = private constant <{ i64, [29 x i8] }> <{ i64 0, [29 x i8] c"olang: bindgen: cannot write " }>, align 8
@.d356 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@__olang_empty_array = external constant [16 x i64]
@.d357 = private constant <{ i64, [37 x i8] }> <{ i64 0, [37 x i8] c"olang: bindgen: clang could not read " }>, align 8
@.d358 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c": " }>, align 8
@.d359 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d360 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"name" }>, align 8
@.d361 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"kind" }>, align 8
@.d362 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"EnumDecl" }>, align 8
@.d363 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"__olang_m" }>, align 8
@.d364 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d365 = private constant <{ i64, [37 x i8] }> <{ i64 0, [37 x i8] c"olang: bindgen: clang could not read " }>, align 8
@.d366 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c": " }>, align 8
@.d367 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d368 = private constant <{ i64, [34 x i8] }> <{ i64 0, [34 x i8] c"# Generated by olang bindgen from " }>, align 8
@.d369 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c":\0A" }>, align 8
@.d370 = private constant <{ i64, [104 x i8] }> <{ i64 0, [104 x i8] c"# its C declarations as olang declares them (X1-X21) - write the library they are in after \22extern\22, as\0A" }>, align 8
@.d371 = private constant <{ i64, [66 x i8] }> <{ i64 0, [66 x i8] c"# 'extern link \22NAME\22 {' (X9), or import the header itself (X17).\0A" }>, align 8
@.d372 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d373 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"olang: " }>, align 8
@.d374 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c": cannot be written\0A" }>, align 8
@.d375 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Bool" }>, align 8
@.d376 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"U64(1 if v else 0)" }>, align 8
@.d377 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"F" }>, align 8
@.d378 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"BF16" }>, align 8
@.d379 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"U64(v.Bits())" }>, align 8
@.d380 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"I" }>, align 8
@.d381 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I64" }>, align 8
@.d382 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"U64(U" }>, align 8
@.d383 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"(v))" }>, align 8
@.d384 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"U64" }>, align 8
@.d385 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"v" }>, align 8
@.d386 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"U64(v)" }>, align 8
@.d387 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"I64(" }>, align 8
@.d388 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d389 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"U8(" }>, align 8
@.d390 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d391 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"I" }>, align 8
@.d392 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"(U" }>, align 8
@.d393 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d394 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"))" }>, align 8
@.d395 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d396 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2ecompiler_2fbindgen_3aTranslation_2e2 = weak hidden constant i1 false
declare ptr @__olang_region_home(ptr)
@.d397 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d398 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d399 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2ecompiler_2fbindgen_3agen_2e5 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fbindgen_3agen_2e6 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fbindgen_3agen_2e7 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fbindgen_3agen_2e8 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fbindgen_3agen_2e9 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fbindgen_3agen_2e10 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fbindgen_3agen_2e11 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fbindgen_3agen_2e12 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fbindgen_3agen_2e13 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fbindgen_3agen_2e14 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fbindgen_3agen_2e15 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fbindgen_3agen_2e16 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fbindgen_3agen_2e18 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fbindgen_3agen_2e19 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fbindgen_3agen_2e20 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fbindgen_3agen_2e21 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fbindgen_3agen_2e22 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fbindgen_3agen_2e23 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fbindgen_3agen_2e25 = weak hidden constant i1 false
@.d400 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
declare void @__olang_scope_close_owned(ptr) noinline
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
@__olang_standin_mark = external global i64
declare ptr @__olang_standin_keeper(ptr) noinline
define available_externally noalias ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  %head = load ptr, ptr %scope, !tbaa !59
  %isslot = icmp eq ptr %head, @__olang_slot_chunk
  br i1 %isslot, label %slot, label %plain
slot:
  %s = call ptr @__olang_slot_alloc(ptr %scope, i64 %rawsize)
  ret ptr %s
plain:
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
@__olang_self = external thread_local(initialexec) global ptr
define available_externally ptr @__olang_capture_scope(ptr %s) alwaysinline {
entry:
  %isprog = icmp eq ptr %s, null
  br i1 %isprog, label %prog, label %mine
prog:
  %p = load ptr, ptr @__olang_prog_scope
  ret ptr %p
mine:
  %m = call ptr @__olang_scope_mine(ptr %s)
  ret ptr %m
}
@.d401 = private unnamed_addr constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"int" }>, align 8
@.d402 = private unnamed_addr constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"unsigned" }>, align 8
@.d403 = private unnamed_addr constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"signed" }>, align 8
@.d404 = private unnamed_addr constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"long" }>, align 8
@.d405 = private unnamed_addr constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"short" }>, align 8
@.d406 = private unnamed_addr constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"char" }>, align 8
@.d407 = private unnamed_addr constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"float" }>, align 8
@.d408 = private unnamed_addr constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"double" }>, align 8
@.d409 = private unnamed_addr constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"_Bool" }>, align 8
@.d410 = private unnamed_addr constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"const" }>, align 8
@.d411 = private unnamed_addr constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"volatile" }>, align 8
define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 16
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 8
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

@.d412 = private unnamed_addr constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"void" }>, align 8
@.d413 = private unnamed_addr constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"bool" }>, align 8
@.d414 = private unnamed_addr constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"_Float16" }>, align 8
@.d415 = private unnamed_addr constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"__bf16" }>, align 8
@.d416 = private unnamed_addr constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"__int128" }>, align 8
@__olang_slot_chunk = external global %olang.chunk
declare noalias ptr @__olang_slot_alloc(ptr, i64) noinline
@__olang_prog_scope = external thread_local(initialexec) global ptr
define available_externally ptr @__olang_scope_mine(ptr %s) alwaysinline {
entry:
  %op = getelementptr %olang.scope, ptr %s, i32 0, i32 3
  %o = load atomic ptr, ptr %op monotonic, align 8
  %me = load ptr, ptr @__olang_self
  %own = icmp eq ptr %o, %me
  br i1 %own, label %mine, label %slow
mine:
  ret ptr %s
slow:
  %r = call ptr @__olang_scope_mine_slow(ptr %s)
  ret ptr %r
}
declare ptr @__olang_scope_mine_slow(ptr) noinline
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i32, { i64, ptr } } @std_2fos_2eMkTemp(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2ffilepath_2eJoin(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i32 @std_2fos_2eWriteFile(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i32 @std_2fos_2eRemoveAll(ptr %v0, { i64, ptr } %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, i64 %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %v0, ptr %v1, ptr %a0)
declare { i32, %"std/os:Output" } @compiler_2fbindgen_2eclangSays(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2fbindgen_2efirstError(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eintMacros(ptr %v0, ptr %v1, ptr %a0)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/bindgen:cMacro" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3acMacro_3e_2eAt_3ccompiler_2fbindgen_3acMacro_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare { i32, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2edump(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3)
declare void @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eread(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, { i64, ptr } %a2)
declare { i64, ptr } @compiler_2fbindgen_2einner(ptr %v0, ptr %v1, ptr %a0)
declare { i64, ptr } @compiler_2fbindgen_2etext(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
@olang_loc_b774a7292e99a958_2ba7e6e1e518c9cc = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %v0, i64 %a0)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %v0, { i64, ptr } %a0, i64 %a1)
declare { i64, ptr } @compiler_2fbindgen_2econstValue(ptr %v0, ptr %v1, ptr %a0)
declare void @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2econstant(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i64 %a2)
declare void @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eotherConsts(ptr %v0, ptr %a0)
declare i32 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2esizes(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, { i64, ptr } %a4)
declare i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eLen(ptr %v0, ptr %a0)
@olang_loc_e777242b492df290_2cbbd43a2df6cacc = external constant [0 x i8]
@olang_loc_aa3527431bc6906d_d98aa20bf76f5ef9 = external constant [0 x i8]
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %a0)
@olang_loc_5d1582c4176ede0e_4f5ef5c07175765a = external constant [0 x i8]
@olang_loc_c1a7519d080599a4_d00fb28b8b3fdec0 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3acparse_2eat(ptr %v0, ptr %v1, ptr %a0)
declare i32 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eskip(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i32, %"compiler/bindgen:cx" } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ecExpr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare { i32, %"compiler/bindgen:cx" } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ecNumber(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
@G_2ecompiler_2fbindgen_2eKInt = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare %"compiler/bindgen:cx" @compiler_2fbindgen_2ecx_2elit(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1)
declare { i32, i64 } @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2eFindIndex_3cstd_2f_H0cdaf28864c9da4990596b1986b376a0(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1c, ptr %a1e)
@G_2ecompiler_2fbindgen_2eKVar = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
declare %"compiler/bindgen:cx" @compiler_2fbindgen_3acx_2ector(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, i64 %a1, i64 %a2, { i64, ptr } %a3)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9162e3b7f03fcbf954b681204d5f6cca(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha4444909f5ef14f7626d25b8f59e6ba2(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare %"compiler/bindgen:cx" @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ecNum(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/bindgen:cx" %a1)
@G_2ecompiler_2fbindgen_2eKType = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fbindgen_2eKBool = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
declare i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2eHas_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_He27db0a1785588531472bfd2db42574f(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare %"compiler/bindgen:ctype" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3actype_3e_2eAt_3ccompiler_2fbindgen_3actype_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3actp_2eat(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2enode(ptr %v0, ptr %v1, ptr %a0, i32 %a1, { i64, ptr } %a2, i64 %a3, i1 %a4, i64 %a5)
declare i1 @compiler_2fbindgen_2epassOver(ptr %v0, { i64, ptr } %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3actype_3e_2eRefMut_3ccompiler_2fbindgen_3actype_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eAt_3ccompiler_2fbindgen_3arecord_3e(ptr %out, ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %a0)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3acMacro_3e_2eLen_3ccompiler_2fbindgen_3acMacro_3e(ptr %v0, ptr %a0)
declare i1 @compiler_2fbindgen_2eusable(ptr %v0, { i64, ptr } %a0)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9b83f66eba65594537030636cb0b52b7(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i1 @compiler_2fbindgen_2epreludeName(ptr %v0, { i64, ptr } %a0)
declare void @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eskippedMacro(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare { i32, { i64, ptr } } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2emacroFn(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha091d021a90ce6aa48813730c00df6d2(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i64 %a2)
declare { i32, { i64, ptr } } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2efieldType(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @compiler_2fbindgen_2enumBytes(ptr %v0, { i64, ptr } %a0)
declare %"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Hd80cb4cbc6ceb8a13686fbc19b8451b4(ptr %v0, ptr %v1, ptr %a0)
declare { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapKeyIter_3cstd_2fprelude_2ftext_3aString_2_H116ed76223103781f5a7340c80f3d0f3(ptr %v0, ptr %v1, ptr %a0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H6f7a2f8d839c49b6e7a19c287d4b190c(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eLen_3ccompiler_2fbindgen_3arecord_3e(ptr %v0, ptr %a0)
declare void @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2enameRecord(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2)
declare i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ebad(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e_2ector(ptr %v0)
declare { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eparamName(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, i64 %a2, ptr %a3)
declare i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2erecordAt(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i32, { i64, ptr } } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2epointerParam(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i1 %a2)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20Bool_3e_2ector(ptr %v0)
declare %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %v0, ptr %v1, ptr %a0)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindByte(ptr %v0, { i64, ptr } %a0, i8 %a1)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindLast(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_beacd36cd332827c_e461632e30adb8c0 = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eReplace_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H6b5ccacad8db807339a3579aa8c82ff8(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H2b85ceff512af6e6ca26c554a1c16247(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i1 %a2)
@olang_loc_88bbbdba37ecb069_7556c3a5c9bf841d = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3acMacro_3e_2eRefMu_H9d4ce036ca8f6276b6798968f53e8eb9(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_a6c60cdff876254a_2c918d2d7b99843e = external constant [0 x i8]
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %a0)
@olang_loc_5755e6dd02fca827_178a482bfa1e95bb = external constant [0 x i8]
@olang_loc_4153d023000ff8e8_6b17d300a1e811b4 = external constant [0 x i8]
@olang_loc_ec020a578bdf64c5_799d4029e88195a1 = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eSplit(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_642a74ef72af54a6_43680c0161c24f22 = external constant [0 x i8]
declare ptr @compiler_2fbindgen_2ecLex(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3acMacro_3e_2eSetAt_H7935c3ba4e105e8cc692de439d360efe(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"compiler/bindgen:cMacro" %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3acMacro_3e_2ePush_3ccompiler_2fbindgen_3acMacro_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/bindgen:cMacro" %a1)
declare void @compiler_2fbindgen_3arecord_2ector(ptr %out, ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2ePush_3ccompiler_2fbindgen_3arecord_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eRefMu_Hc21bcd245b67ffb6ee3e145838fcf2cf(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @compiler_2fbindgen_2eflag(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2fbindgen_2etypeOf(ptr %v0, ptr %v1, ptr %a0)
declare i1 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eplain(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ehasAnon(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eflatFields(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2efieldLine(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare void @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eunionFlat(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, i1 %a2, ptr %a3, ptr %a4)
declare { i64, ptr } @compiler_2fbindgen_2eaccessors(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, i64 %a4, i64 %a5)
declare i64 @compiler_2fbindgen_2egapWord(i64 %a0, i64 %a1, i64 %a2)
@olang_loc_6501bdc18c03b538_5635fa6c34e71ae4 = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2erecOf(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ename(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eisByte(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eholdable(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_383dad6bbc51ebc3_b2d1cf432887049f = external constant [0 x i8]
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eRef_3ccompiler_2fbindgen_3arecord_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fbindgen_2enoReturnOf(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2fbindgen_2eresultText(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3acFunc_3e_2eLen_3ccompiler_2fbindgen_3acFunc_3e(ptr %v0, ptr %a0)
declare %"compiler/bindgen:cFunc" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3acFunc_3e_2eAt_3ccompiler_2fbindgen_3acFunc_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i32, { i64, ptr } } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2efunction(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
@olang_loc_12d4b4c126d079e6_1af6ce2ce1af3fd2 = external constant [0 x i8]
@olang_loc_b9ed3bac91748577_8bd4ae03d42ae063 = external constant [0 x i8]
declare void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i32, { i64, ptr } } @std_2fos_2eRealPath(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @std_2fos_2eExists(ptr %v0, { i64, ptr } %a0)
@olang_loc_2d25c1a9d7803e60_587b957d3d0d6154 = external constant [0 x i8]
@olang_loc_6d7a361a7a168fed_fbeb1a267b83d779 = external constant [0 x i8]
@olang_loc_3c31d34710cd488e_9478fba938690442 = external constant [0 x i8]
declare i32 @std_2fio_2ePut_3cstd_2fprelude_2ftext_3aString_3e({ i64, ptr } %a0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20std_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3acFunc_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3acMacro_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3actype_3e_2ector(ptr %v0, i64 %a0)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
