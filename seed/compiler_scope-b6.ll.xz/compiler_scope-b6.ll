; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr, i64, ptr }
%olang.home = type { ptr, ptr }
%olang.slotscope = type { %olang.scope, i64, [8 x ptr] }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"compiler/scope:Scoper" = type { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { ptr, ptr }, { ptr, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, i64, i1, %"compiler/source:Span", %"compiler/source:Span", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/typed:Plan", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"compiler/source:Span", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/scope:fsBody", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, ptr, { i64, [2 x i64] }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, [2 x i64] }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i1, i1, i1, i1, i1, i1, { i64, [2 x i64] }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, [2 x i64] }, i1, %"compiler/source:Span", { i64, [2 x i64] }, i1, { i64, [2 x i64] }, i1, i1, i1, %"compiler/source:Span", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/scope:fnRecs", i1, i1, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i64, i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, [2 x i64] }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i64, { i64, [2 x i64] }, i1, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i64, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i64, i64, i1, i32, i1, i1, i1, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i64, %"compiler/source:Span", i64, i1, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i64, i64, i1, i1, i1, i1, i64, i1, i1, i1, i1, i64, i1, i1, i1, i1, i64, %"compiler/source:Span", %"compiler/source:Span", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, ptr, { i64, ptr }, i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/scope:instTree", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/scope:instTree", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"compiler/scope:Gap", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1, i1, i1, i64, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i64, i64, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i64, i64, i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i64, i64 }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/typed:Plan" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/scope:fsBody" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/scope:fnRecs" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/scope:instTree" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/scope:Gap" = type { i64, %"compiler/source:Span", { i64, ptr } }
%"compiler/scope:compRun" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"compiler/diag:Taken", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, ptr, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/diag:Taken" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/scope:rel" = type { { i64, [2 x i64] }, { i64, [2 x i64] }, i1, %"compiler/source:Span", i64, i1, i1 }
%"compiler/scope:summary" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"compiler/scope:fnRecs", %"compiler/scope:instTree", i1, i1, i1, i1 }
%"compiler/typed:Body" = type { i32, { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i32, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/typed:Block" = type { i32, { i64, ptr } }
%"compiler/typed:Capture" = type { i32, ptr }
%"compiler/scope:fnRec" = type { i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1 }
%"compiler/typed:Call" = type { ptr, { i64, ptr }, i32, i1, i1 }
%"compiler/typed:Promote" = type { ptr, i32 }
%"compiler/generic:Program" = type { ptr, ptr, %"compiler/types:Table", %"compiler/facts:Table", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"compiler/generic:Origin", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/types:Table" = type { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/facts:Table" = type { %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i64 }
%"compiler/generic:Origin" = type { i64, %"compiler/source:Span", i64, i32 }
%"compiler/load:Loader" = type { { i64, ptr }, ptr, ptr, ptr, ptr, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/scope:walked" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i32, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" = type { i64, i64 }
%"compiler/typed:Local" = type { i32, %"compiler/source:Span", i32, i32, i32, { i64, [1 x i64] }, i1, i1 }
%"compiler/scope:fsOpen" = type { i32, i1 }
%"compiler/scope:fsRow" = type { i64, { i64, [2 x i64] } }
%"compiler/typed:If" = type { ptr, ptr, ptr }
%"compiler/typed:Join" = type { ptr, i1, { i64, ptr } }
%"compiler/typed:Clause" = type { %"compiler/source:Span", { i64, ptr }, i1, ptr, { i64, ptr }, i64, i32 }
%"compiler/typed:Spawn" = type { { i64, ptr }, ptr, { i64, ptr }, i32 }
%"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9" = type { ptr, i64 }
%"compiler/load:Module" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i64, i1, ptr, ptr, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr, i1, i64, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr, ptr, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/typed:Elem" = type { ptr, ptr, i32 }
%"compiler/typed:Payload" = type { ptr, i64, i32 }
%"compiler/scope:markRead" = type { i64, i64, { i64, [1 x i64] } }
%"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" = type { ptr, i64 }
%"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613" = type { i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/typed:Slice" = type { ptr, ptr, ptr, i32 }
%"compiler/types:DtorWalk" = type { ptr, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/typed:TaskClause" = type { %"compiler/source:Span", { i64, ptr }, i1, ptr }
define dso_local { i64, ptr } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eRunStats(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca ptr
  %l13 = alloca i64
  %l15 = alloca i64
  %l20 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l22 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l24 = alloca i64
  %l26 = alloca i64
  %l31 = alloca ptr
  %l35 = alloca i64
  %l38 = alloca i64
  %l40 = alloca i64
  %l43 = alloca i64
  %l45 = alloca i64
  %l48 = alloca i64
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l1, !tbaa !24
  store i64 0, ptr %l2, !tbaa !24
  store i64 0, ptr %l3, !tbaa !24
  store i64 0, ptr %l4, !tbaa !24
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %a0, i32 0, i32 280
  store ptr %t3, ptr %l5, !tbaa !29
  store i64 0, ptr %l6, !tbaa !24
  br label %bb1
bb1:
  %t5 = load i64, ptr %l6, !tbaa !24
  store i64 %t5, ptr %l13, !tbaa !24
  %t6 = load ptr, ptr %l5, !tbaa !29
  %t8 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cmut_20comp_H43e0789510fdd6e46eb40242e8ebac44(ptr %v0, ptr %t6)
  store i64 %t8, ptr %l15
  br label %bb2
bb2:
  %t9 = load i64, ptr %l13, !tbaa !24
  %t10 = load i64, ptr %l15, !tbaa !24
  %t11 = icmp slt i64 %t9, %t10
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb3, label %bb4
bb3:
  br label %bb20
bb4:
  br label %bb5
bb5:
  %t15 = load ptr, ptr %l5, !tbaa !29
  %t16 = load i64, ptr %l6, !tbaa !24
  %t19 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cmut_20comp_H7e0984339031c6a833031be461c3ee4e(ptr %v0, ptr %v0, ptr %t15, i64 %t16)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t19, ptr %l20
  br label %bb6
bb6:
  %t21 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fscope_3acompRun_26_3e(ptr %v0, ptr %l20)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t21, ptr %l22
  br label %bb7
bb7:
  %t22 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l22
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t22, ptr %l7
  store ptr %l7, ptr %l8, !tbaa !29
  store i64 0, ptr %l9, !tbaa !24
  br label %bb8
bb8:
  %t24 = load i64, ptr %l9, !tbaa !24
  store i64 %t24, ptr %l24, !tbaa !24
  %t25 = load ptr, ptr %l8, !tbaa !29
  %t27 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fscope_3acompRun_26_3e_H0296d27dcb58febef67dd9f1f1b292fb(ptr %v0, ptr %t25)
  store i64 %t27, ptr %l26
  br label %bb9
bb9:
  %t28 = load i64, ptr %l24, !tbaa !24
  %t29 = load i64, ptr %l26, !tbaa !24
  %t30 = icmp slt i64 %t28, %t29
  %t32 = xor i1 %t30, true
  br i1 %t32, label %bb10, label %bb11
bb10:
  br label %bb18
bb11:
  br label %bb12
bb12:
  %t34 = load ptr, ptr %l8, !tbaa !29
  %t35 = load i64, ptr %l9, !tbaa !24
  %t38 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fscope_3acompRun_26_3e_H665b0c71977ef42adbc51fe96e6e85ee(ptr %v0, ptr %v0, ptr %t34, i64 %t35)
  store ptr %t38, ptr %l31
  br label %bb13
bb13:
  %t39 = load ptr, ptr %l31, !tbaa !29
  store ptr %t39, ptr %l10, !tbaa !29
  %t40 = load i64, ptr %l1, !tbaa !24
  %t43 = add i64 %t40, 1
  store i64 %t43, ptr %l1, !tbaa !24
  %t45 = load i64, ptr %l2, !tbaa !24
  store i64 %t45, ptr %l35, !tbaa !24
  %t46 = load ptr, ptr %l10, !tbaa !29
  %t48 = getelementptr %"compiler/scope:compRun", ptr %t46, i32 0, i32 9
  %t50 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3amarkRead_3e_2eLen_3ccompiler_2fscope_3amarkRead_3e(ptr %v0, ptr %t48)
  store i64 %t50, ptr %l38
  br label %bb14
bb14:
  %t51 = load i64, ptr %l35, !tbaa !24
  %t52 = load i64, ptr %l38, !tbaa !24
  %t53 = add i64 %t51, %t52
  store i64 %t53, ptr %l2, !tbaa !24
  %t55 = load i64, ptr %l3, !tbaa !24
  store i64 %t55, ptr %l40, !tbaa !24
  %t56 = load ptr, ptr %l10, !tbaa !29
  %t58 = getelementptr %"compiler/scope:compRun", ptr %t56, i32 0, i32 10
  %t60 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3asumRead_3e_2eLen_3ccompiler_2fscope_3asumRead_3e(ptr %v0, ptr %t58)
  store i64 %t60, ptr %l43
  br label %bb15
bb15:
  %t61 = load i64, ptr %l40, !tbaa !24
  %t62 = load i64, ptr %l43, !tbaa !24
  %t63 = add i64 %t61, %t62
  store i64 %t63, ptr %l3, !tbaa !24
  %t65 = load i64, ptr %l4, !tbaa !24
  store i64 %t65, ptr %l45, !tbaa !24
  %t66 = load ptr, ptr %l10, !tbaa !29
  %t68 = getelementptr %"compiler/scope:compRun", ptr %t66, i32 0, i32 3
  %t70 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aTaken_2eCount(ptr %v0, ptr %t68)
  store i64 %t70, ptr %l48
  br label %bb16
bb16:
  %t71 = load i64, ptr %l45, !tbaa !24
  %t72 = load i64, ptr %l48, !tbaa !24
  %t73 = add i64 %t71, %t72
  store i64 %t73, ptr %l4, !tbaa !24
  br label %bb17
bb17:
  %t75 = load i64, ptr %l9, !tbaa !24
  %t78 = add i64 %t75, 1
  store i64 %t78, ptr %l9, !tbaa !24
  br label %bb8
bb18:
  br label %bb19
bb19:
  %t80 = load i64, ptr %l6, !tbaa !24
  %t83 = add i64 %t80, 1
  store i64 %t83, ptr %l6, !tbaa !24
  br label %bb1
bb20:
  %t85 = load i64, ptr %l1, !tbaa !24
  %t86 = load i64, ptr %l2, !tbaa !24
  %t87 = load i64, ptr %l3, !tbaa !24
  %t88 = load i64, ptr %l4, !tbaa !24
  %t89 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d0, i32 0, i32 1) }, 1
  %t90 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d0, i32 0, i32 1) }, 0
  %t92 = call i64 @__olang_fmt_i64(ptr null, i64 %t85)
  %t93 = add i64 %t90, %t92
  %t94 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d1, i32 0, i32 1) }, 1
  %t95 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d1, i32 0, i32 1) }, 0
  %t96 = add i64 %t93, %t95
  %t98 = call i64 @__olang_fmt_i64(ptr null, i64 %t86)
  %t99 = add i64 %t96, %t98
  %t100 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d2, i32 0, i32 1) }, 1
  %t101 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d2, i32 0, i32 1) }, 0
  %t102 = add i64 %t99, %t101
  %t104 = call i64 @__olang_fmt_i64(ptr null, i64 %t87)
  %t105 = add i64 %t102, %t104
  %t106 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d3, i32 0, i32 1) }, 1
  %t107 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d3, i32 0, i32 1) }, 0
  %t108 = add i64 %t105, %t107
  %t110 = call i64 @__olang_fmt_i64(ptr null, i64 %t88)
  %t111 = add i64 %t108, %t110
  %t112 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t111)
  call void @olang_textcopy(ptr %t112, ptr %t89, i64 %t90)
  %t113 = getelementptr i8, ptr %t112, i64 %t90
  %t114 = call i64 @__olang_fmt_i64(ptr %t113, i64 %t85)
  %t115 = getelementptr i8, ptr %t113, i64 %t92
  call void @olang_textcopy(ptr %t115, ptr %t94, i64 %t95)
  %t116 = getelementptr i8, ptr %t115, i64 %t95
  %t117 = call i64 @__olang_fmt_i64(ptr %t116, i64 %t86)
  %t118 = getelementptr i8, ptr %t116, i64 %t98
  call void @olang_textcopy(ptr %t118, ptr %t100, i64 %t101)
  %t119 = getelementptr i8, ptr %t118, i64 %t101
  %t120 = call i64 @__olang_fmt_i64(ptr %t119, i64 %t87)
  %t121 = getelementptr i8, ptr %t119, i64 %t104
  call void @olang_textcopy(ptr %t121, ptr %t106, i64 %t107)
  %t122 = getelementptr i8, ptr %t121, i64 %t107
  %t123 = call i64 @__olang_fmt_i64(ptr %t122, i64 %t88)
  %t124 = insertvalue { i64, ptr } undef, i64 %t111, 0
  %t125 = insertvalue { i64, ptr } %t124, ptr %t112, 1
  store { i64, ptr } %t125, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eSummary(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca %"compiler/scope:rel"
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca %"std/prelude/text:StringBuilder"
  %l29 = alloca ptr
  %l32 = alloca i64
  %l34 = alloca i64
  %l39 = alloca %"compiler/scope:rel"
  %l40 = alloca ptr
  %l41 = alloca { i64, [2 x i64] }
  %l43 = alloca { i64, ptr }
  %l44 = alloca { i64, [2 x i64] }
  %l47 = alloca { i64, ptr }
  %l53 = alloca { i64, ptr }
  %l60 = alloca i64
  %l64 = alloca i64
  %l67 = alloca i64
  %l85 = alloca ptr
  %l86 = alloca i64
  %l90 = alloca i1
  %l94 = alloca i1
  %l102 = alloca i64
  %l106 = alloca i64
  %l109 = alloca i64
  %l127 = alloca ptr
  %l128 = alloca i64
  %l132 = alloca i1
  %l136 = alloca i1
  %l140 = alloca i1
  %l148 = alloca i64
  %l152 = alloca i64
  %l155 = alloca i64
  %l173 = alloca ptr
  %l174 = alloca i64
  %l178 = alloca { i64, [2 x i64] }
  %l180 = alloca { i64, ptr }
  %l186 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.builder
  %s4room = alloca [64 x i8], align 8
  %s7 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s16 = alloca %olang.builder
  %s16room = alloca [64 x i8], align 8
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l25
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l25
  store %"std/prelude/text:StringBuilder" %t2, ptr %l2
  %t5 = getelementptr %"compiler/scope:Scoper", ptr %a0, i32 0, i32 6
  %t9 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fscope_3asummary_26_3e_Hf018e585e117ec5a1eef851c731bcf79(ptr %v0, ptr %v0, ptr %t5, i64 %a1)
  store ptr %t9, ptr %l29
  br label %bb2
bb2:
  %t10 = load ptr, ptr %l29, !tbaa !29
  store ptr %t10, ptr %l3, !tbaa !29
  %t11 = load ptr, ptr %l3, !tbaa !29
  %t13 = getelementptr %"compiler/scope:summary", ptr %t11, i32 0, i32 0
  store ptr %t13, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb3
bb3:
  store %olang.scope zeroinitializer, ptr %s2
  %t15 = load i64, ptr %l5, !tbaa !24
  store i64 %t15, ptr %l32, !tbaa !24
  %t16 = load ptr, ptr %l4, !tbaa !29
  %t18 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3arel_3e_2eLen_3ccompiler_2fscope_3arel_3e(ptr %v0, ptr %t16)
  store i64 %t18, ptr %l34
  br label %bb4
bb4:
  %t19 = load i64, ptr %l32, !tbaa !24
  %t20 = load i64, ptr %l34, !tbaa !24
  %t21 = icmp slt i64 %t19, %t20
  %t23 = xor i1 %t21, true
  br i1 %t23, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s2)
  br label %bb19
bb6:
  br label %bb7
bb7:
  %t25 = load ptr, ptr %l4, !tbaa !29
  %t26 = load i64, ptr %l5, !tbaa !24
  %t29 = call %"compiler/scope:rel" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3arel_3e_2eAt_3ccompiler_2fscope_3arel_3e(ptr %v0, ptr %t25, i64 %t26)
  store %"compiler/scope:rel" %t29, ptr %l39
  br label %bb8
bb8:
  %t30 = load %"compiler/scope:rel", ptr %l39
  store %"compiler/scope:rel" %t30, ptr %l6
  store ptr %l2, ptr %l40, !tbaa !29
  %t31 = getelementptr %"compiler/scope:rel", ptr %l6, i32 0, i32 0
  %t32 = load { i64, [2 x i64] }, ptr %t31
  store { i64, [2 x i64] } %t32, ptr %l41
  %t33 = getelementptr %"compiler/scope:rel", ptr %l6, i32 0, i32 2
  %t34 = load i1, ptr %t33, !tbaa !21
  br i1 %t34, label %bb9, label %bb10
bb9:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d4, i32 0, i32 1) }, ptr %l43, !tbaa !27
  br label %bb11
bb10:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d5, i32 0, i32 1) }, ptr %l43, !tbaa !27
  br label %bb11
bb11:
  %t36 = getelementptr %"compiler/scope:rel", ptr %l6, i32 0, i32 1
  %t37 = load { i64, [2 x i64] }, ptr %t36
  store { i64, [2 x i64] } %t37, ptr %l44
  %t38 = getelementptr %"compiler/scope:rel", ptr %l6, i32 0, i32 4
  %t39 = load i64, ptr %t38, !tbaa !24
  %t41 = icmp ne i64 %t39, 0
  br i1 %t41, label %bb12, label %bb13
bb12:
  %t43 = getelementptr %"compiler/scope:rel", ptr %l6, i32 0, i32 4
  %t44 = load i64, ptr %t43, !tbaa !24
  %t45 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d6, i32 0, i32 1) }, 1
  %t46 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d6, i32 0, i32 1) }, 0
  %t48 = call i64 @__olang_fmt_i64(ptr null, i64 %t44)
  %t49 = add i64 %t46, %t48
  %t50 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t49)
  call void @olang_textcopy(ptr %t50, ptr %t45, i64 %t46)
  %t51 = getelementptr i8, ptr %t50, i64 %t46
  %t52 = call i64 @__olang_fmt_i64(ptr %t51, i64 %t44)
  %t53 = insertvalue { i64, ptr } undef, i64 %t49, 0
  %t54 = insertvalue { i64, ptr } %t53, ptr %t50, 1
  store { i64, ptr } %t54, ptr %l47, !tbaa !27
  br label %bb14
bb13:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d7, i32 0, i32 1) }, ptr %l47, !tbaa !27
  br label %bb14
bb14:
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s4
  store ptr %s4room, ptr %s4
  %t57 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d8, i32 0, i32 1) }, 1
  %t58 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d8, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t57, i64 %t58)
  call void @olang_2emir_2eHelperKind_2eRender_2ecompiler_2fscope_3aTerm(ptr %s4, ptr %l41, i64 0)
  br label %bb15
bb15:
  %t60 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t61 = extractvalue { i64, ptr } %t60, 1
  %t62 = extractvalue { i64, ptr } %t60, 0
  call void @__olang_sb_put(ptr %s4, ptr %t61, i64 %t62)
  call void @olang_2emir_2eHelperKind_2eRender_2ecompiler_2fscope_3aTerm(ptr %s4, ptr %l44, i64 0)
  br label %bb16
bb16:
  %t64 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t65 = extractvalue { i64, ptr } %t64, 1
  %t66 = extractvalue { i64, ptr } %t64, 0
  call void @__olang_sb_put(ptr %s4, ptr %t65, i64 %t66)
  %t67 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d9, i32 0, i32 1) }, 1
  %t68 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d9, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t67, i64 %t68)
  %t69 = load ptr, ptr %s4
  %t70 = getelementptr %olang.builder, ptr %s4, i32 0, i32 1
  %t71 = load i64, ptr %t70
  %t72 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t71)
  call void @olang_textcopy(ptr %t72, ptr %t69, i64 %t71)
  %t73 = insertvalue { i64, ptr } undef, i64 %t71, 0
  %t74 = insertvalue { i64, ptr } %t73, ptr %t72, 1
  store { i64, ptr } %t74, ptr %l53, !tbaa !27
  %t75 = getelementptr %olang.builder, ptr %s4, i32 0, i32 3
  %t76 = load ptr, ptr %t75
  %t77 = icmp ne ptr %t76, null
  br i1 %t77, label %sbgrew.78, label %sbdone.79
sbgrew.78:
  call void @__olang_sb_done(ptr %s4)
  br label %sbdone.79
sbdone.79:
  %t80 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t81 = load ptr, ptr %l40, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s2, ptr %t81, { i64, ptr } %t80)
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s2)
  br label %bb18
bb18:
  %t83 = load i64, ptr %l5, !tbaa !24
  %t86 = add i64 %t83, 1
  store i64 %t86, ptr %l5, !tbaa !24
  br label %bb3
bb19:
  store i64 0, ptr %l7, !tbaa !24
  %t88 = load ptr, ptr %l3, !tbaa !29
  %t90 = getelementptr %"compiler/scope:summary", ptr %t88, i32 0, i32 1
  %t92 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %t90)
  store i64 %t92, ptr %l60
  br label %bb20
bb20:
  %t93 = load i64, ptr %l60, !tbaa !24
  store i64 %t93, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t94 = load i64, ptr %l8, !tbaa !24
  %t95 = load i64, ptr %l7, !tbaa !24
  %t98 = icmp sgt i64 %t94, %t95
  br i1 %t98, label %bb21, label %bb22
bb21:
  %t100 = load i64, ptr %l9, !tbaa !24
  %t102 = icmp sgt i64 %t100, 0
  br i1 %t102, label %bb23, label %bb24
bb22:
  store i64 0, ptr %l64, !tbaa !24
  br label %bb26
bb23:
  %t104 = load i64, ptr %l8, !tbaa !24
  %t105 = load i64, ptr %l7, !tbaa !24
  %t108 = sub i64 %t104, %t105
  %t109 = load i64, ptr %l9, !tbaa !24
  %t112 = add i64 %t108, %t109
  %t114 = sub i64 %t112, 1
  %t115 = load i64, ptr %l9, !tbaa !24
  %t118 = sdiv i64 %t114, %t115
  store i64 %t118, ptr %l67, !tbaa !24
  br label %bb25
bb24:
  store i64 0, ptr %l67, !tbaa !24
  br label %bb25
bb25:
  %t120 = load i64, ptr %l67, !tbaa !24
  store i64 %t120, ptr %l64, !tbaa !24
  br label %bb26
bb26:
  %t121 = load i64, ptr %l64, !tbaa !24
  store i64 %t121, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb27
bb27:
  store %olang.scope zeroinitializer, ptr %s7
  %t122 = load i64, ptr %l11, !tbaa !24
  %t123 = load i64, ptr %l10, !tbaa !24
  %t126 = icmp slt i64 %t122, %t123
  %t128 = xor i1 %t126, true
  br i1 %t128, label %bb28, label %bb29
bb28:
  call void @__olang_scope_close(ptr %s7)
  br label %bb35
bb29:
  br label %bb30
bb30:
  %t130 = load i64, ptr %l7, !tbaa !24
  %t131 = load i64, ptr %l11, !tbaa !24
  %t132 = load i64, ptr %l9, !tbaa !24
  %t135 = mul i64 %t131, %t132
  %t138 = add i64 %t130, %t135
  store i64 %t138, ptr %l12, !tbaa !24
  store ptr %l2, ptr %l85, !tbaa !29
  %t140 = load i64, ptr %l12, !tbaa !24
  store i64 %t140, ptr %l86, !tbaa !24
  %t141 = load ptr, ptr %l3, !tbaa !29
  %t143 = getelementptr %"compiler/scope:summary", ptr %t141, i32 0, i32 1
  %t144 = load i64, ptr %l12, !tbaa !24
  %t147 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t143, i64 %t144)
  store i1 %t147, ptr %l90
  br label %bb31
bb31:
  %t148 = load ptr, ptr %l3, !tbaa !29
  %t150 = getelementptr %"compiler/scope:summary", ptr %t148, i32 0, i32 2
  %t151 = load i64, ptr %l12, !tbaa !24
  %t154 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t150, i64 %t151)
  store i1 %t154, ptr %l94
  br label %bb32
bb32:
  %t155 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d10, i32 0, i32 1) }, 1
  %t156 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d10, i32 0, i32 1) }, 0
  %t157 = load i64, ptr %l86, !tbaa !24
  %t158 = call i64 @__olang_fmt_i64(ptr null, i64 %t157)
  %t159 = add i64 %t156, %t158
  %t160 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d11, i32 0, i32 1) }, 1
  %t161 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d11, i32 0, i32 1) }, 0
  %t162 = add i64 %t159, %t161
  %t163 = load i1, ptr %l90, !tbaa !21
  %t164 = select i1 %t163, ptr @.c12, ptr @.c13
  %t165 = select i1 %t163, i64 4, i64 5
  %t166 = add i64 %t162, %t165
  %t167 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d14, i32 0, i32 1) }, 1
  %t168 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d14, i32 0, i32 1) }, 0
  %t169 = add i64 %t166, %t168
  %t170 = load i1, ptr %l94, !tbaa !21
  %t171 = select i1 %t170, ptr @.c12, ptr @.c13
  %t172 = select i1 %t170, i64 4, i64 5
  %t173 = add i64 %t169, %t172
  %t174 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d15, i32 0, i32 1) }, 1
  %t175 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d15, i32 0, i32 1) }, 0
  %t176 = add i64 %t173, %t175
  %t177 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t176)
  call void @olang_textcopy(ptr %t177, ptr %t155, i64 %t156)
  %t178 = getelementptr i8, ptr %t177, i64 %t156
  %t179 = call i64 @__olang_fmt_i64(ptr %t178, i64 %t157)
  %t180 = getelementptr i8, ptr %t178, i64 %t158
  call void @olang_textcopy(ptr %t180, ptr %t160, i64 %t161)
  %t181 = getelementptr i8, ptr %t180, i64 %t161
  call void @olang_textcopy(ptr %t181, ptr %t164, i64 %t165)
  %t182 = getelementptr i8, ptr %t181, i64 %t165
  call void @olang_textcopy(ptr %t182, ptr %t167, i64 %t168)
  %t183 = getelementptr i8, ptr %t182, i64 %t168
  call void @olang_textcopy(ptr %t183, ptr %t171, i64 %t172)
  %t184 = getelementptr i8, ptr %t183, i64 %t172
  call void @olang_textcopy(ptr %t184, ptr %t174, i64 %t175)
  %t185 = insertvalue { i64, ptr } undef, i64 %t176, 0
  %t186 = insertvalue { i64, ptr } %t185, ptr %t177, 1
  %t188 = load ptr, ptr %l85, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s7, ptr %t188, { i64, ptr } %t186)
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s7)
  br label %bb34
bb34:
  %t190 = load i64, ptr %l11, !tbaa !24
  %t193 = add i64 %t190, 1
  store i64 %t193, ptr %l11, !tbaa !24
  br label %bb27
bb35:
  store i64 0, ptr %l13, !tbaa !24
  %t195 = load ptr, ptr %l3, !tbaa !29
  %t197 = getelementptr %"compiler/scope:summary", ptr %t195, i32 0, i32 5
  %t199 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %t197)
  store i64 %t199, ptr %l102
  br label %bb36
bb36:
  %t200 = load i64, ptr %l102, !tbaa !24
  store i64 %t200, ptr %l14, !tbaa !24
  store i64 1, ptr %l15, !tbaa !24
  %t201 = load i64, ptr %l14, !tbaa !24
  %t202 = load i64, ptr %l13, !tbaa !24
  %t205 = icmp sgt i64 %t201, %t202
  br i1 %t205, label %bb37, label %bb38
bb37:
  %t207 = load i64, ptr %l15, !tbaa !24
  %t209 = icmp sgt i64 %t207, 0
  br i1 %t209, label %bb39, label %bb40
bb38:
  store i64 0, ptr %l106, !tbaa !24
  br label %bb42
bb39:
  %t211 = load i64, ptr %l14, !tbaa !24
  %t212 = load i64, ptr %l13, !tbaa !24
  %t215 = sub i64 %t211, %t212
  %t216 = load i64, ptr %l15, !tbaa !24
  %t219 = add i64 %t215, %t216
  %t221 = sub i64 %t219, 1
  %t222 = load i64, ptr %l15, !tbaa !24
  %t225 = sdiv i64 %t221, %t222
  store i64 %t225, ptr %l109, !tbaa !24
  br label %bb41
bb40:
  store i64 0, ptr %l109, !tbaa !24
  br label %bb41
bb41:
  %t227 = load i64, ptr %l109, !tbaa !24
  store i64 %t227, ptr %l106, !tbaa !24
  br label %bb42
bb42:
  %t228 = load i64, ptr %l106, !tbaa !24
  store i64 %t228, ptr %l16, !tbaa !24
  store i64 0, ptr %l17, !tbaa !24
  br label %bb43
bb43:
  store %olang.scope zeroinitializer, ptr %s11
  %t229 = load i64, ptr %l17, !tbaa !24
  %t230 = load i64, ptr %l16, !tbaa !24
  %t233 = icmp slt i64 %t229, %t230
  %t235 = xor i1 %t233, true
  br i1 %t235, label %bb44, label %bb45
bb44:
  call void @__olang_scope_close(ptr %s11)
  br label %bb52
bb45:
  br label %bb46
bb46:
  %t237 = load i64, ptr %l13, !tbaa !24
  %t238 = load i64, ptr %l17, !tbaa !24
  %t239 = load i64, ptr %l15, !tbaa !24
  %t242 = mul i64 %t238, %t239
  %t245 = add i64 %t237, %t242
  store i64 %t245, ptr %l18, !tbaa !24
  store ptr %l2, ptr %l127, !tbaa !29
  %t247 = load i64, ptr %l18, !tbaa !24
  store i64 %t247, ptr %l128, !tbaa !24
  %t248 = load ptr, ptr %l3, !tbaa !29
  %t250 = getelementptr %"compiler/scope:summary", ptr %t248, i32 0, i32 5
  %t251 = load i64, ptr %l18, !tbaa !24
  %t254 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t250, i64 %t251)
  store i1 %t254, ptr %l132
  br label %bb47
bb47:
  %t255 = load ptr, ptr %l3, !tbaa !29
  %t257 = getelementptr %"compiler/scope:summary", ptr %t255, i32 0, i32 6
  %t258 = load i64, ptr %l18, !tbaa !24
  %t261 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t257, i64 %t258)
  store i1 %t261, ptr %l136
  br label %bb48
bb48:
  %t262 = load ptr, ptr %l3, !tbaa !29
  %t264 = getelementptr %"compiler/scope:summary", ptr %t262, i32 0, i32 7
  %t265 = load i64, ptr %l18, !tbaa !24
  %t268 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t264, i64 %t265)
  store i1 %t268, ptr %l140
  br label %bb49
bb49:
  %t269 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d16, i32 0, i32 1) }, 1
  %t270 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d16, i32 0, i32 1) }, 0
  %t271 = load i64, ptr %l128, !tbaa !24
  %t272 = call i64 @__olang_fmt_i64(ptr null, i64 %t271)
  %t273 = add i64 %t270, %t272
  %t274 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d17, i32 0, i32 1) }, 1
  %t275 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d17, i32 0, i32 1) }, 0
  %t276 = add i64 %t273, %t275
  %t277 = load i1, ptr %l132, !tbaa !21
  %t278 = select i1 %t277, ptr @.c12, ptr @.c13
  %t279 = select i1 %t277, i64 4, i64 5
  %t280 = add i64 %t276, %t279
  %t281 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d18, i32 0, i32 1) }, 1
  %t282 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d18, i32 0, i32 1) }, 0
  %t283 = add i64 %t280, %t282
  %t284 = load i1, ptr %l136, !tbaa !21
  %t285 = select i1 %t284, ptr @.c12, ptr @.c13
  %t286 = select i1 %t284, i64 4, i64 5
  %t287 = add i64 %t283, %t286
  %t288 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d19, i32 0, i32 1) }, 1
  %t289 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d19, i32 0, i32 1) }, 0
  %t290 = add i64 %t287, %t289
  %t291 = load i1, ptr %l140, !tbaa !21
  %t292 = select i1 %t291, ptr @.c12, ptr @.c13
  %t293 = select i1 %t291, i64 4, i64 5
  %t294 = add i64 %t290, %t293
  %t295 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d20, i32 0, i32 1) }, 1
  %t296 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d20, i32 0, i32 1) }, 0
  %t297 = add i64 %t294, %t296
  %t298 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t297)
  call void @olang_textcopy(ptr %t298, ptr %t269, i64 %t270)
  %t299 = getelementptr i8, ptr %t298, i64 %t270
  %t300 = call i64 @__olang_fmt_i64(ptr %t299, i64 %t271)
  %t301 = getelementptr i8, ptr %t299, i64 %t272
  call void @olang_textcopy(ptr %t301, ptr %t274, i64 %t275)
  %t302 = getelementptr i8, ptr %t301, i64 %t275
  call void @olang_textcopy(ptr %t302, ptr %t278, i64 %t279)
  %t303 = getelementptr i8, ptr %t302, i64 %t279
  call void @olang_textcopy(ptr %t303, ptr %t281, i64 %t282)
  %t304 = getelementptr i8, ptr %t303, i64 %t282
  call void @olang_textcopy(ptr %t304, ptr %t285, i64 %t286)
  %t305 = getelementptr i8, ptr %t304, i64 %t286
  call void @olang_textcopy(ptr %t305, ptr %t288, i64 %t289)
  %t306 = getelementptr i8, ptr %t305, i64 %t289
  call void @olang_textcopy(ptr %t306, ptr %t292, i64 %t293)
  %t307 = getelementptr i8, ptr %t306, i64 %t293
  call void @olang_textcopy(ptr %t307, ptr %t295, i64 %t296)
  %t308 = insertvalue { i64, ptr } undef, i64 %t297, 0
  %t309 = insertvalue { i64, ptr } %t308, ptr %t298, 1
  %t311 = load ptr, ptr %l127, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s11, ptr %t311, { i64, ptr } %t309)
  br label %bb50
bb50:
  call void @__olang_scope_close(ptr %s11)
  br label %bb51
bb51:
  %t313 = load i64, ptr %l17, !tbaa !24
  %t316 = add i64 %t313, 1
  store i64 %t316, ptr %l17, !tbaa !24
  br label %bb43
bb52:
  store i64 0, ptr %l19, !tbaa !24
  %t318 = load ptr, ptr %l3, !tbaa !29
  %t320 = getelementptr %"compiler/scope:summary", ptr %t318, i32 0, i32 11
  %t322 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eLen_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t320)
  store i64 %t322, ptr %l148
  br label %bb53
bb53:
  %t323 = load i64, ptr %l148, !tbaa !24
  store i64 %t323, ptr %l20, !tbaa !24
  store i64 1, ptr %l21, !tbaa !24
  %t324 = load i64, ptr %l20, !tbaa !24
  %t325 = load i64, ptr %l19, !tbaa !24
  %t328 = icmp sgt i64 %t324, %t325
  br i1 %t328, label %bb54, label %bb55
bb54:
  %t330 = load i64, ptr %l21, !tbaa !24
  %t332 = icmp sgt i64 %t330, 0
  br i1 %t332, label %bb56, label %bb57
bb55:
  store i64 0, ptr %l152, !tbaa !24
  br label %bb59
bb56:
  %t334 = load i64, ptr %l20, !tbaa !24
  %t335 = load i64, ptr %l19, !tbaa !24
  %t338 = sub i64 %t334, %t335
  %t339 = load i64, ptr %l21, !tbaa !24
  %t342 = add i64 %t338, %t339
  %t344 = sub i64 %t342, 1
  %t345 = load i64, ptr %l21, !tbaa !24
  %t348 = sdiv i64 %t344, %t345
  store i64 %t348, ptr %l155, !tbaa !24
  br label %bb58
bb57:
  store i64 0, ptr %l155, !tbaa !24
  br label %bb58
bb58:
  %t350 = load i64, ptr %l155, !tbaa !24
  store i64 %t350, ptr %l152, !tbaa !24
  br label %bb59
bb59:
  %t351 = load i64, ptr %l152, !tbaa !24
  store i64 %t351, ptr %l22, !tbaa !24
  store i64 0, ptr %l23, !tbaa !24
  br label %bb60
bb60:
  store %olang.scope zeroinitializer, ptr %s15
  %t352 = load i64, ptr %l23, !tbaa !24
  %t353 = load i64, ptr %l22, !tbaa !24
  %t356 = icmp slt i64 %t352, %t353
  %t358 = xor i1 %t356, true
  br i1 %t358, label %bb61, label %bb62
bb61:
  call void @__olang_scope_close(ptr %s15)
  br label %bb68
bb62:
  br label %bb63
bb63:
  %t360 = load i64, ptr %l19, !tbaa !24
  %t361 = load i64, ptr %l23, !tbaa !24
  %t362 = load i64, ptr %l21, !tbaa !24
  %t365 = mul i64 %t361, %t362
  %t368 = add i64 %t360, %t365
  store i64 %t368, ptr %l24, !tbaa !24
  store ptr %l2, ptr %l173, !tbaa !29
  %t370 = load i64, ptr %l24, !tbaa !24
  store i64 %t370, ptr %l174, !tbaa !24
  %t371 = load ptr, ptr %l3, !tbaa !29
  %t373 = getelementptr %"compiler/scope:summary", ptr %t371, i32 0, i32 11
  %t374 = load i64, ptr %l24, !tbaa !24
  %t377 = call { i64, [2 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eAt_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t373, i64 %t374)
  store { i64, [2 x i64] } %t377, ptr %l178
  br label %bb64
bb64:
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s16
  store ptr %s16room, ptr %s16
  %t378 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d21, i32 0, i32 1) }, 1
  %t379 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d21, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s16, ptr %t378, i64 %t379)
  %t380 = load i64, ptr %l174, !tbaa !24
  %t381 = call ptr @__olang_sb_room(ptr %s16, i64 24)
  %t382 = call i64 @__olang_fmt_i64(ptr %t381, i64 %t380)
  call void @__olang_sb_add(ptr %s16, i64 %t382)
  %t383 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d22, i32 0, i32 1) }, 1
  %t384 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d22, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s16, ptr %t383, i64 %t384)
  call void @olang_2emir_2eHelperKind_2eRender_2ecompiler_2fscope_3aTerm(ptr %s16, ptr %l178, i64 0)
  br label %bb65
bb65:
  %t386 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d23, i32 0, i32 1) }, 1
  %t387 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d23, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s16, ptr %t386, i64 %t387)
  %t388 = load ptr, ptr %s16
  %t389 = getelementptr %olang.builder, ptr %s16, i32 0, i32 1
  %t390 = load i64, ptr %t389
  %t391 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t390)
  call void @olang_textcopy(ptr %t391, ptr %t388, i64 %t390)
  %t392 = insertvalue { i64, ptr } undef, i64 %t390, 0
  %t393 = insertvalue { i64, ptr } %t392, ptr %t391, 1
  store { i64, ptr } %t393, ptr %l180, !tbaa !27
  %t394 = getelementptr %olang.builder, ptr %s16, i32 0, i32 3
  %t395 = load ptr, ptr %t394
  %t396 = icmp ne ptr %t395, null
  br i1 %t396, label %sbgrew.397, label %sbdone.398
sbgrew.397:
  call void @__olang_sb_done(ptr %s16)
  br label %sbdone.398
sbdone.398:
  %t399 = load { i64, ptr }, ptr %l180, !tbaa !27
  %t400 = load ptr, ptr %l173, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s15, ptr %t400, { i64, ptr } %t399)
  br label %bb66
bb66:
  call void @__olang_scope_close(ptr %s15)
  br label %bb67
bb67:
  %t402 = load i64, ptr %l23, !tbaa !24
  %t405 = add i64 %t402, 1
  store i64 %t405, ptr %l23, !tbaa !24
  br label %bb60
bb68:
  %t408 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l2)
  store { i64, ptr } %t408, ptr %l186
  br label %bb69
bb69:
  call void @__olang_scope_close(ptr %s0)
  %t409 = load { i64, ptr }, ptr %l186, !tbaa !27
  store { i64, ptr } %t409, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebuiltField(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca i32
  %l8 = alloca ptr
  %l26 = alloca { i64, ptr }
  %l29 = alloca ptr
  %l30 = alloca i1
  %l41 = alloca ptr
  %l45 = alloca ptr
  %l46 = alloca ptr
  %l48 = alloca i1
  %s5 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Body", ptr %t1, i32 0, i32 11
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = icmp eq ptr %t4, null
  br i1 %t6, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t9 = load ptr, ptr %l1, !tbaa !29
  %t11 = getelementptr %"compiler/typed:Body", ptr %t9, i32 0, i32 11
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t14 = icmp eq ptr %t12, null
  br i1 %t14, label %bb4, label %bb5
bb4:
  call void @__olang_check_failed(ptr @olang_loc_1668eb2d997973a7_ab4d69ddc8fad23)
  unreachable
bb5:
  br label %bb6
bb6:
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr %"compiler/typed:Body", ptr %t16, i32 0, i32 11
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t22 = getelementptr %"compiler/typed:Block", ptr %t19, i32 0, i32 1
  %t23 = load { i64, ptr }, ptr %t22, !tbaa !27
  store { i64, ptr } %t23, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t25 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t27 = extractvalue { i64, ptr } %t25, 0
  store i64 %t27, ptr %l5, !tbaa !24
  br label %bb7
bb7:
  %t29 = load i64, ptr %l4, !tbaa !24
  %t30 = load i64, ptr %l5, !tbaa !24
  %t33 = icmp slt i64 %t29, %t30
  %t35 = xor i1 %t33, true
  br i1 %t35, label %bb8, label %bb9
bb8:
  br label %bb29
bb9:
  br label %bb10
bb10:
  %t37 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t37, ptr %l26, !tbaa !27
  %t38 = load i64, ptr %l4, !tbaa !24
  %t40 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !27
  %t42 = getelementptr ptr, ptr %t41, i64 %t38
  %t43 = load ptr, ptr %t42, !tbaa !39
  store ptr %t43, ptr %l6, !tbaa !29
  %t45 = load ptr, ptr %l6, !tbaa !29
  store ptr %t45, ptr %l29, !tbaa !29
  store i1 false, ptr %l30, !tbaa !21
  %t46 = load ptr, ptr %l29, !tbaa !29
  %t47 = icmp ne ptr %t46, null
  br i1 %t47, label %bb11, label %bb12
bb11:
  %t49 = load ptr, ptr %l29, !tbaa !29
  %t50 = load i64, ptr %t49, !range !{i64 0, i64 17}
  %t52 = icmp eq i64 %t50, 0
  store i1 %t52, ptr %l30, !tbaa !21
  br label %bb12
bb12:
  %t53 = load i1, ptr %l30, !tbaa !21
  br i1 %t53, label %bb13, label %bb14
bb13:
  %t54 = load ptr, ptr %l6, !tbaa !29
  %t56 = getelementptr { i64, [3 x i64] }, ptr %t54, i32 0, i32 1
  %t57 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t56, i32 0, i32 1
  %t58 = load i32, ptr %t57
  store i32 %t58, ptr %l7, !tbaa !23
  %t60 = load ptr, ptr %l6, !tbaa !29
  %t62 = getelementptr { i64, [3 x i64] }, ptr %t60, i32 0, i32 1
  %t63 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t62, i32 0, i32 2
  %t64 = load ptr, ptr %t63
  store ptr %t64, ptr %l8, !tbaa !29
  br label %bb15
bb14:
  br label %bb22
bb15:
  %t66 = load i32, ptr %l7, !tbaa !23
  %t68 = sext i32 %t66 to i64
  %t72 = icmp eq i64 %t68, %a2
  br i1 %t72, label %bb16, label %bb17
bb16:
  store %olang.scope zeroinitializer, ptr %s5
  %t74 = load ptr, ptr %l0, !tbaa !29
  store ptr %t74, ptr %l41, !tbaa !29
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t76 = load ptr, ptr %l8, !tbaa !29
  %t80 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunAway(ptr %v0, ptr %v1, ptr %s5, ptr %t75, ptr %t76)
  store ptr %t80, ptr %l45
  br label %bb18
bb17:
  br label %bb21
bb18:
  %t81 = load ptr, ptr %l45, !tbaa !29
  %t82 = call ptr @compiler_2fscope_2eunPassed(ptr %s5, ptr %s5, ptr %t81)
  store ptr %t82, ptr %l46
  br label %bb19
bb19:
  %t83 = load ptr, ptr %l46, !tbaa !29
  %t84 = load ptr, ptr %l41, !tbaa !29
  %t86 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisFresh(ptr %v0, ptr %s5, ptr %t84, ptr %t83)
  store i1 %t86, ptr %l48
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s5)
  %t87 = load i1, ptr %l48, !tbaa !21
  store i1 %t87, ptr %rv
  br label %ret
bb21:
  br label %bb27
bb22:
  br i1 true, label %bb23, label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb27
bb26:
  call void @__olang_check_failed(ptr @olang_loc_ca9fbb609f85e0bf_654dd6319f2fbb3b)
  unreachable
bb27:
  br label %bb28
bb28:
  %t88 = load i64, ptr %l4, !tbaa !24
  %t91 = add i64 %t88, 1
  store i64 %t91, ptr %l4, !tbaa !24
  br label %bb7
bb29:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecapOuter(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, i64 %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca { i64, [1 x i64] }
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca ptr
  %l14 = alloca { i64, [1 x i64] }
  %l15 = alloca i32
  %l23 = alloca i64
  %l26 = alloca i1
  %l31 = alloca { i64, ptr }
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/typed:Body", ptr %a1, i32 0, i32 6
  %t7 = call { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScopeVar_3e_2eAt_3ccompiler_2ftyped_3aScopeVar_3e(ptr %v1, ptr %t3, i64 %a2)
  store { i64, [1 x i64] } %t7, ptr %l14
  br label %bb1
bb1:
  %t8 = load { i64, [1 x i64] }, ptr %l14
  store { i64, [1 x i64] } %t8, ptr %l4
  %t9 = load { i64, [1 x i64] }, ptr %l4
  %t11 = extractvalue { i64, [1 x i64] } %t9, 0
  %t12 = icmp eq i64 %t11, 4
  br i1 %t12, label %bb2, label %bb3
bb2:
  %t14 = getelementptr { i64, [1 x i64] }, ptr %l4, i32 0, i32 1
  %t15 = getelementptr { i32 }, ptr %t14, i32 0, i32 0
  %t16 = load i32, ptr %t15
  store i32 %t16, ptr %l5, !tbaa !23
  br label %bb4
bb3:
  br label %bb5
bb4:
  %t18 = load i32, ptr %l5, !tbaa !23
  store i32 %t18, ptr %l15, !tbaa !23
  br label %bb10
bb5:
  br i1 true, label %bb6, label %bb7
bb6:
  br label %bb8
bb7:
  br label %bb9
bb8:
  store i32 -1, ptr %l15, !tbaa !23
  br label %bb10
bb9:
  call void @__olang_check_failed(ptr @olang_loc_34786756d9cc10ef_3d198681fdad2233)
  unreachable
bb10:
  %t20 = load i32, ptr %l15, !tbaa !23
  store i32 %t20, ptr %l6, !tbaa !23
  store { i64, ptr } %a3, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t23 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t25 = extractvalue { i64, ptr } %t23, 0
  store i64 %t25, ptr %l9, !tbaa !24
  %t27 = load i64, ptr %l9, !tbaa !24
  %t28 = sub i64 %t27, 1
  store i64 %t28, ptr %l23, !tbaa !24
  %t29 = load i64, ptr %l9, !tbaa !24
  %t30 = icmp slt i64 %t29, 2147483648
  %t31 = load i64, ptr %l8, !tbaa !24
  %t32 = icmp sge i64 %t31, 0
  %t35 = and i1 %t30, %t32
  store i1 %t35, ptr %l26, !tbaa !21
  br label %bb11
bb11:
  %t36 = load i64, ptr %l8, !tbaa !24
  %t37 = load i64, ptr %l9, !tbaa !24
  %t40 = icmp slt i64 %t36, %t37
  %t42 = xor i1 %t40, true
  br i1 %t42, label %bb12, label %bb13
bb12:
  br label %bb19
bb13:
  br label %bb14
bb14:
  %t44 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t44, ptr %l31, !tbaa !27
  %t45 = load i64, ptr %l8, !tbaa !24
  %t47 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t48 = load ptr, ptr %t47, !tbaa !27
  %t49 = getelementptr ptr, ptr %t48, i64 %t45
  %t50 = load ptr, ptr %t49, !tbaa !39
  store ptr %t50, ptr %l10, !tbaa !29
  %t52 = load ptr, ptr %l10, !tbaa !29
  %t54 = getelementptr %"compiler/typed:Capture", ptr %t52, i32 0, i32 0
  %t55 = load i32, ptr %t54, !tbaa !23
  %t56 = load i32, ptr %l6, !tbaa !23
  %t59 = icmp eq i32 %t55, %t56
  br i1 %t59, label %bb15, label %bb16
bb15:
  %t61 = load ptr, ptr %l10, !tbaa !29
  %t63 = getelementptr %"compiler/typed:Capture", ptr %t61, i32 0, i32 1
  %t64 = load ptr, ptr %t63, !tbaa !29
  store ptr %t64, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  br label %bb18
bb18:
  %t67 = load i64, ptr %l8, !tbaa !24
  %t70 = add i64 %t67, 1
  store i64 %t70, ptr %l8, !tbaa !24
  br label %bb11
bb19:
  store ptr null, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecapRoot(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i64 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca ptr
  %l18 = alloca ptr
  %l19 = alloca { i64, ptr }
  %l20 = alloca ptr
  %l29 = alloca i1
  %l38 = alloca { i64, ptr }
  %l42 = alloca %"compiler/scope:fnRecs"
  %l44 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l46 = alloca i64
  %l48 = alloca i1
  %l53 = alloca ptr
  %l55 = alloca %"compiler/scope:fnRec"
  %l57 = alloca ptr
  %l58 = alloca i64
  %l61 = alloca i64
  %l66 = alloca { i64, ptr }
  %l70 = alloca ptr
  %l73 = alloca ptr
  %l80 = alloca ptr
  %l84 = alloca i64
  %l87 = alloca i64
  %l105 = alloca ptr
  %l106 = alloca i1
  %l115 = alloca ptr
  %l119 = alloca ptr
  %l120 = alloca ptr
  %l121 = alloca i1
  %l124 = alloca i1
  %l126 = alloca ptr
  %l127 = alloca i1
  %l134 = alloca %"compiler/scope:fnRec"
  %l136 = alloca i1
  %l139 = alloca i1
  %l140 = alloca ptr
  %l143 = alloca ptr
  %l144 = alloca i1
  %l147 = alloca i1
  %l149 = alloca ptr
  %l150 = alloca i1
  %l160 = alloca ptr
  %l163 = alloca i1
  %l164 = alloca ptr
  %l166 = alloca i32
  %l167 = alloca i1
  %l169 = alloca i1
  %l171 = alloca i1
  %l177 = alloca i1
  %l178 = alloca ptr
  %l182 = alloca ptr
  %l183 = alloca i1
  %s0 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = sub i64 -2, %a3
  store i64 %t3, ptr %l4, !tbaa !24
  %t5 = load i64, ptr %l4, !tbaa !24
  %t7 = sdiv i64 %t5, 4096
  store i64 %t7, ptr %l5, !tbaa !24
  %t9 = load i64, ptr %l4, !tbaa !24
  %t11 = srem i64 %t9, 4096
  store i64 %t11, ptr %l6, !tbaa !24
  %t13 = load i64, ptr %l2, !tbaa !24
  %t15 = icmp slt i64 %t13, 0
  br i1 %t15, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l29, !tbaa !21
  br label %bb3
bb2:
  %t17 = load i64, ptr %l2, !tbaa !24
  %t18 = load ptr, ptr %l1, !tbaa !29
  %t20 = getelementptr %"compiler/typed:Call", ptr %t18, i32 0, i32 1
  %t21 = load { i64, ptr }, ptr %t20, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t26 = icmp sge i64 %t17, %t23
  store i1 %t26, ptr %l29, !tbaa !21
  br label %bb3
bb3:
  %t28 = load i1, ptr %l29, !tbaa !21
  br i1 %t28, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t31 = load ptr, ptr %l1, !tbaa !29
  %t33 = getelementptr %"compiler/typed:Call", ptr %t31, i32 0, i32 1
  %t34 = load { i64, ptr }, ptr %t33, !tbaa !27
  store { i64, ptr } %t34, ptr %l38, !tbaa !27
  %t35 = load i64, ptr %l2, !tbaa !24
  %t37 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t38 = load ptr, ptr %t37, !tbaa !27
  %t39 = getelementptr ptr, ptr %t38, i64 %t35
  %t40 = load ptr, ptr %t39, !tbaa !39
  %t44 = call %"compiler/scope:fnRecs" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2erecsOf(ptr %v0, ptr %v1, ptr %s0, ptr %t30, ptr %t40)
  store %"compiler/scope:fnRecs" %t44, ptr %l42
  br label %bb7
bb7:
  %t45 = getelementptr %"compiler/scope:fnRecs", ptr %l42, i32 0, i32 0
  %t47 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fscope_2esortedRecs(ptr %s0, ptr %s0, ptr %t45)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t47, ptr %l44
  br label %bb8
bb8:
  %t48 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l44
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t48, ptr %l7
  %t50 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3afnRec_3e_2eLen_3ccompiler_2fscope_3afnRec_3e(ptr %s0, ptr %l7)
  store i64 %t50, ptr %l46
  br label %bb9
bb9:
  %t51 = load i64, ptr %l46, !tbaa !24
  %t52 = icmp ne i64 %t51, 1
  br i1 %t52, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l48, !tbaa !21
  br label %bb12
bb11:
  %t54 = load i64, ptr %l5, !tbaa !24
  %t56 = icmp ne i64 %t54, 0
  store i1 %t56, ptr %l48, !tbaa !21
  br label %bb12
bb12:
  %t58 = load i1, ptr %l48, !tbaa !21
  br i1 %t58, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/scope:Scoper", ptr %t60, i32 0, i32 1
  store ptr %t62, ptr %l53, !tbaa !29
  %t64 = call %"compiler/scope:fnRec" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3afnRec_3e_2eAt_3ccompiler_2fscope_3afnRec_3e(ptr %s0, ptr %s0, ptr %l7, i64 0)
  store %"compiler/scope:fnRec" %t64, ptr %l55
  br label %bb16
bb16:
  %t65 = getelementptr %"compiler/scope:fnRec", ptr %l55, i32 0, i32 0
  %t66 = load i64, ptr %t65, !tbaa !24
  %t67 = load ptr, ptr %l53, !tbaa !29
  %t69 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t67, i64 %t66)
  store ptr %t69, ptr %l57
  br label %bb17
bb17:
  %t70 = load ptr, ptr %l57, !tbaa !29
  store ptr %t70, ptr %l8, !tbaa !29
  %t71 = load i64, ptr %l6, !tbaa !24
  store i64 %t71, ptr %l58, !tbaa !24
  %t72 = load ptr, ptr %l8, !tbaa !29
  %t74 = getelementptr %"compiler/typed:Body", ptr %t72, i32 0, i32 6
  %t76 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScopeVar_3e_2eLen_3ccompiler_2ftyped_3aScopeVar_3e(ptr %v0, ptr %t74)
  store i64 %t76, ptr %l61
  br label %bb18
bb18:
  %t77 = load i64, ptr %l58, !tbaa !24
  %t78 = load i64, ptr %l61, !tbaa !24
  %t79 = icmp sge i64 %t77, %t78
  br i1 %t79, label %bb19, label %bb20
bb19:
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t83 = load ptr, ptr %l1, !tbaa !29
  %t85 = getelementptr %"compiler/typed:Call", ptr %t83, i32 0, i32 1
  %t86 = load { i64, ptr }, ptr %t85, !tbaa !27
  store { i64, ptr } %t86, ptr %l66, !tbaa !27
  %t87 = load i64, ptr %l2, !tbaa !24
  %t89 = getelementptr { i64, ptr }, ptr %l66, i32 0, i32 1
  %t90 = load ptr, ptr %t89, !tbaa !27
  %t91 = getelementptr ptr, ptr %t90, i64 %t87
  %t92 = load ptr, ptr %t91, !tbaa !39
  %t96 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunAway(ptr %v0, ptr %v1, ptr %v2, ptr %t82, ptr %t92)
  store ptr %t96, ptr %l70
  br label %bb22
bb22:
  %t97 = load ptr, ptr %l70, !tbaa !29
  store ptr %t97, ptr %l9, !tbaa !29
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t99 = load ptr, ptr %l9, !tbaa !29
  %t102 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2estoredFn(ptr %v0, ptr %v2, ptr %v2, ptr %t98, ptr %t99)
  store ptr %t102, ptr %l73
  br label %bb23
bb23:
  %t103 = load ptr, ptr %l73, !tbaa !29
  store ptr %t103, ptr %l10, !tbaa !29
  %t104 = load ptr, ptr %l10, !tbaa !29
  %t106 = icmp eq ptr %t104, null
  %t108 = xor i1 %t106, true
  br i1 %t108, label %bb24, label %bb25
bb24:
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t111 = load ptr, ptr %l10, !tbaa !29
  %t115 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunAway(ptr %v0, ptr %v2, ptr %v2, ptr %t110, ptr %t111)
  store ptr %t115, ptr %l80
  br label %bb26
bb25:
  br label %bb27
bb26:
  %t116 = load ptr, ptr %l80, !tbaa !29
  store ptr %t116, ptr %l9, !tbaa !29
  br label %bb27
bb27:
  store i64 0, ptr %l11, !tbaa !24
  store i64 8, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t117 = load i64, ptr %l12, !tbaa !24
  %t118 = load i64, ptr %l11, !tbaa !24
  %t121 = icmp sgt i64 %t117, %t118
  br i1 %t121, label %bb28, label %bb29
bb28:
  %t123 = load i64, ptr %l13, !tbaa !24
  %t125 = icmp sgt i64 %t123, 0
  br i1 %t125, label %bb30, label %bb31
bb29:
  store i64 0, ptr %l84, !tbaa !24
  br label %bb33
bb30:
  %t127 = load i64, ptr %l12, !tbaa !24
  %t128 = load i64, ptr %l11, !tbaa !24
  %t131 = sub i64 %t127, %t128
  %t132 = load i64, ptr %l13, !tbaa !24
  %t135 = add i64 %t131, %t132
  %t137 = sub i64 %t135, 1
  %t138 = load i64, ptr %l13, !tbaa !24
  %t141 = sdiv i64 %t137, %t138
  store i64 %t141, ptr %l87, !tbaa !24
  br label %bb32
bb31:
  store i64 0, ptr %l87, !tbaa !24
  br label %bb32
bb32:
  %t143 = load i64, ptr %l87, !tbaa !24
  store i64 %t143, ptr %l84, !tbaa !24
  br label %bb33
bb33:
  %t144 = load i64, ptr %l84, !tbaa !24
  store i64 %t144, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb34
bb34:
  %t145 = load i64, ptr %l15, !tbaa !24
  %t146 = load i64, ptr %l14, !tbaa !24
  %t149 = icmp slt i64 %t145, %t146
  %t151 = xor i1 %t149, true
  br i1 %t151, label %bb35, label %bb36
bb35:
  br label %bb51
bb36:
  br label %bb37
bb37:
  %t153 = load i64, ptr %l11, !tbaa !24
  %t154 = load i64, ptr %l15, !tbaa !24
  %t155 = load i64, ptr %l13, !tbaa !24
  %t158 = mul i64 %t154, %t155
  %t161 = add i64 %t153, %t158
  store i64 %t161, ptr %l16, !tbaa !24
  %t163 = load ptr, ptr %l9, !tbaa !29
  store ptr %t163, ptr %l105, !tbaa !29
  store i1 false, ptr %l106, !tbaa !21
  %t164 = load ptr, ptr %l105, !tbaa !29
  %t165 = icmp ne ptr %t164, null
  br i1 %t165, label %bb38, label %bb39
bb38:
  %t167 = load ptr, ptr %l105, !tbaa !29
  %t168 = load i64, ptr %t167, !range !{i64 0, i64 18}
  %t170 = icmp eq i64 %t168, 5
  store i1 %t170, ptr %l106, !tbaa !21
  br label %bb39
bb39:
  %t171 = load i1, ptr %l106, !tbaa !21
  br i1 %t171, label %bb40, label %bb41
bb40:
  %t172 = load ptr, ptr %l9, !tbaa !29
  %t174 = getelementptr { i64, [5 x i64] }, ptr %t172, i32 0, i32 1
  %t175 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t174, i32 0, i32 2
  %t176 = load ptr, ptr %t175
  store ptr %t176, ptr %l17, !tbaa !29
  br label %bb42
bb41:
  br label %bb44
bb42:
  %t178 = load ptr, ptr %l0, !tbaa !29
  %t179 = load ptr, ptr %l17, !tbaa !29
  %t181 = getelementptr %"compiler/typed:Promote", ptr %t179, i32 0, i32 0
  %t182 = load ptr, ptr %t181, !tbaa !29
  %t186 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunAway(ptr %v0, ptr %v2, ptr %v2, ptr %t178, ptr %t182)
  store ptr %t186, ptr %l115
  br label %bb43
bb43:
  %t187 = load ptr, ptr %l115, !tbaa !29
  store ptr %t187, ptr %l9, !tbaa !29
  br label %bb49
bb44:
  br i1 true, label %bb45, label %bb46
bb45:
  br label %bb47
bb46:
  br label %bb48
bb47:
  br label %bb51
bb48:
  call void @__olang_check_failed(ptr @olang_loc_4facdfbbce427d16_bc8d42a38505ceba)
  unreachable
bb49:
  br label %bb50
bb50:
  %t188 = load i64, ptr %l15, !tbaa !24
  %t191 = add i64 %t188, 1
  store i64 %t191, ptr %l15, !tbaa !24
  br label %bb34
bb51:
  %t193 = load ptr, ptr %l9, !tbaa !29
  store ptr %t193, ptr %l120, !tbaa !29
  store i1 false, ptr %l121, !tbaa !21
  %t194 = load ptr, ptr %l120, !tbaa !29
  %t195 = icmp ne ptr %t194, null
  br i1 %t195, label %bb52, label %bb53
bb52:
  %t197 = load ptr, ptr %l120, !tbaa !29
  %t198 = load i64, ptr %t197, !range !{i64 0, i64 18}
  %t200 = icmp eq i64 %t198, 15
  store i1 %t200, ptr %l121, !tbaa !21
  br label %bb53
bb53:
  %t201 = load i1, ptr %l121, !tbaa !21
  br i1 %t201, label %bb54, label %bb55
bb54:
  %t202 = load ptr, ptr %l9, !tbaa !29
  %t204 = getelementptr { i64, [5 x i64] }, ptr %t202, i32 0, i32 1
  %t205 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t204, i32 0, i32 2
  %t206 = load ptr, ptr %t205
  store ptr %t206, ptr %l126, !tbaa !29
  store i1 false, ptr %l127, !tbaa !21
  %t207 = load ptr, ptr %l126, !tbaa !29
  %t208 = icmp ne ptr %t207, null
  br i1 %t208, label %bb56, label %bb57
bb55:
  store i1 false, ptr %l124, !tbaa !21
  br label %bb58
bb56:
  %t210 = load ptr, ptr %l126, !tbaa !29
  %t211 = load i64, ptr %t210, !range !{i64 0, i64 3}
  %t213 = icmp eq i64 %t211, 2
  store i1 %t213, ptr %l127, !tbaa !21
  br label %bb57
bb57:
  %t214 = load i1, ptr %l127, !tbaa !21
  store i1 %t214, ptr %l124, !tbaa !21
  br label %bb58
bb58:
  %t215 = load i1, ptr %l124, !tbaa !21
  br i1 %t215, label %bb59, label %bb60
bb59:
  %t216 = load ptr, ptr %l9, !tbaa !29
  %t218 = getelementptr { i64, [5 x i64] }, ptr %t216, i32 0, i32 1
  %t219 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t218, i32 0, i32 2
  %t220 = load ptr, ptr %t219
  %t222 = getelementptr { i64, [4 x i64] }, ptr %t220, i32 0, i32 1
  %t223 = getelementptr { i32, ptr, i32 }, ptr %t222, i32 0, i32 1
  %t224 = load ptr, ptr %t223
  store ptr %t224, ptr %l18, !tbaa !29
  br label %bb61
bb60:
  br label %bb70
bb61:
  store %olang.scope zeroinitializer, ptr %s10
  %t227 = call %"compiler/scope:fnRec" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3afnRec_3e_2eAt_3ccompiler_2fscope_3afnRec_3e(ptr %s0, ptr %s10, ptr %l7, i64 0)
  store %"compiler/scope:fnRec" %t227, ptr %l134
  br label %bb62
bb62:
  %t228 = getelementptr %"compiler/scope:fnRec", ptr %l134, i32 0, i32 2
  %t229 = load i1, ptr %t228, !tbaa !21
  br i1 %t229, label %bb63, label %bb64
bb63:
  %t231 = load ptr, ptr %l8, !tbaa !29
  %t232 = load i64, ptr %l6, !tbaa !24
  %t235 = call i1 @compiler_2fscope_2ecapVarOf(ptr %v0, ptr %t231, i64 %t232, i1 true)
  store i1 %t235, ptr %l139
  br label %bb65
bb64:
  store i1 false, ptr %l136, !tbaa !21
  br label %bb66
bb65:
  %t236 = load i1, ptr %l139, !tbaa !21
  store i1 %t236, ptr %l136, !tbaa !21
  br label %bb66
bb66:
  %t237 = load i1, ptr %l136, !tbaa !21
  br i1 %t237, label %bb67, label %bb68
bb67:
  %t238 = load ptr, ptr %l18, !tbaa !29
  store ptr %t238, ptr %l140, !tbaa !29
  br label %bb69
bb68:
  store ptr null, ptr %l140, !tbaa !29
  br label %bb69
bb69:
  %t241 = load ptr, ptr %l140, !tbaa !29
  store ptr %t241, ptr %l119, !tbaa !29
  call void @__olang_scope_close(ptr %s10)
  br label %bb87
bb70:
  %t242 = load ptr, ptr %l9, !tbaa !29
  store ptr %t242, ptr %l143, !tbaa !29
  store i1 false, ptr %l144, !tbaa !21
  %t243 = load ptr, ptr %l143, !tbaa !29
  %t244 = icmp ne ptr %t243, null
  br i1 %t244, label %bb71, label %bb72
bb71:
  %t246 = load ptr, ptr %l143, !tbaa !29
  %t247 = load i64, ptr %t246, !range !{i64 0, i64 18}
  %t249 = icmp eq i64 %t247, 15
  store i1 %t249, ptr %l144, !tbaa !21
  br label %bb72
bb72:
  %t250 = load i1, ptr %l144, !tbaa !21
  br i1 %t250, label %bb73, label %bb74
bb73:
  %t251 = load ptr, ptr %l9, !tbaa !29
  %t253 = getelementptr { i64, [5 x i64] }, ptr %t251, i32 0, i32 1
  %t254 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t253, i32 0, i32 2
  %t255 = load ptr, ptr %t254
  store ptr %t255, ptr %l149, !tbaa !29
  store i1 false, ptr %l150, !tbaa !21
  %t256 = load ptr, ptr %l149, !tbaa !29
  %t257 = icmp ne ptr %t256, null
  br i1 %t257, label %bb75, label %bb76
bb74:
  store i1 false, ptr %l147, !tbaa !21
  br label %bb77
bb75:
  %t259 = load ptr, ptr %l149, !tbaa !29
  %t260 = load i64, ptr %t259, !range !{i64 0, i64 3}
  %t262 = icmp eq i64 %t260, 1
  store i1 %t262, ptr %l150, !tbaa !21
  br label %bb76
bb76:
  %t263 = load i1, ptr %l150, !tbaa !21
  store i1 %t263, ptr %l147, !tbaa !21
  br label %bb77
bb77:
  %t264 = load i1, ptr %l147, !tbaa !21
  br i1 %t264, label %bb78, label %bb79
bb78:
  %t265 = load ptr, ptr %l9, !tbaa !29
  %t267 = getelementptr { i64, [5 x i64] }, ptr %t265, i32 0, i32 1
  %t268 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t267, i32 0, i32 2
  %t269 = load ptr, ptr %t268
  %t271 = getelementptr { i64, [4 x i64] }, ptr %t269, i32 0, i32 1
  %t272 = getelementptr { i32, { i64, ptr }, i32 }, ptr %t271, i32 0, i32 1
  %t273 = load { i64, ptr }, ptr %t272
  store { i64, ptr } %t273, ptr %l19, !tbaa !27
  br label %bb80
bb79:
  br label %bb82
bb80:
  %t275 = load ptr, ptr %l0, !tbaa !29
  %t276 = load ptr, ptr %l8, !tbaa !29
  %t277 = load i64, ptr %l6, !tbaa !24
  %t278 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t283 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecapOuter(ptr %v0, ptr %v0, ptr %v2, ptr %v2, ptr %t275, ptr %t276, i64 %t277, { i64, ptr } %t278)
  store ptr %t283, ptr %l160
  br label %bb81
bb81:
  %t284 = load ptr, ptr %l160, !tbaa !29
  store ptr %t284, ptr %l119, !tbaa !29
  br label %bb87
bb82:
  br i1 true, label %bb83, label %bb84
bb83:
  br label %bb85
bb84:
  br label %bb86
bb85:
  store ptr null, ptr %l119, !tbaa !29
  br label %bb87
bb86:
  call void @__olang_check_failed(ptr @olang_loc_5f5e86560cf90c37_fbfb89ab9edf5b3b)
  unreachable
bb87:
  %t285 = load ptr, ptr %l119, !tbaa !29
  store ptr %t285, ptr %l20, !tbaa !29
  %t286 = load ptr, ptr %l20, !tbaa !29
  %t288 = icmp eq ptr %t286, null
  br i1 %t288, label %bb88, label %bb89
bb88:
  store i1 true, ptr %l163, !tbaa !21
  br label %bb92
bb89:
  %t290 = load ptr, ptr %l0, !tbaa !29
  store ptr %t290, ptr %l164, !tbaa !29
  %t291 = load ptr, ptr %l20, !tbaa !29
  %t293 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v2, ptr %t291)
  store i32 %t293, ptr %l166
  br label %bb90
bb90:
  %t294 = load ptr, ptr %l164, !tbaa !29
  %t295 = load i32, ptr %l166, !tbaa !23
  %t296 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisRef(ptr %v0, ptr %t294, i32 %t295)
  store i1 %t296, ptr %l167
  br label %bb91
bb91:
  %t297 = load i1, ptr %l167, !tbaa !21
  %t298 = xor i1 %t297, true
  store i1 %t298, ptr %l163, !tbaa !21
  br label %bb92
bb92:
  %t300 = load i1, ptr %l163, !tbaa !21
  br i1 %t300, label %bb93, label %bb94
bb93:
  store i1 true, ptr %l169, !tbaa !21
  br label %bb96
bb94:
  %t301 = load ptr, ptr %l20, !tbaa !29
  %t303 = call i1 @compiler_2ftyped_2ePure(ptr %v2, ptr %t301)
  store i1 %t303, ptr %l171
  br label %bb95
bb95:
  %t304 = load i1, ptr %l171, !tbaa !21
  %t305 = xor i1 %t304, true
  store i1 %t305, ptr %l169, !tbaa !21
  br label %bb96
bb96:
  %t307 = load i1, ptr %l169, !tbaa !21
  br i1 %t307, label %bb97, label %bb98
bb97:
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb98:
  br label %bb99
bb99:
  %t309 = load ptr, ptr %l10, !tbaa !29
  %t311 = icmp eq ptr %t309, null
  %t313 = xor i1 %t311, true
  br i1 %t313, label %bb100, label %bb101
bb100:
  %t315 = load ptr, ptr %l0, !tbaa !29
  store ptr %t315, ptr %l178, !tbaa !29
  %t316 = load ptr, ptr %l0, !tbaa !29
  %t317 = load ptr, ptr %l20, !tbaa !29
  %t321 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunAway(ptr %v0, ptr %v2, ptr %s0, ptr %t316, ptr %t317)
  store ptr %t321, ptr %l182
  br label %bb102
bb101:
  store i1 false, ptr %l177, !tbaa !21
  br label %bb104
bb102:
  %t322 = load ptr, ptr %l178, !tbaa !29
  %t323 = load ptr, ptr %l182, !tbaa !29
  %t324 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esteadyLocal(ptr %v0, ptr %s0, ptr %t322, ptr %t323)
  store i1 %t324, ptr %l183
  br label %bb103
bb103:
  %t325 = load i1, ptr %l183, !tbaa !21
  %t326 = xor i1 %t325, true
  store i1 %t326, ptr %l177, !tbaa !21
  br label %bb104
bb104:
  %t328 = load i1, ptr %l177, !tbaa !21
  br i1 %t328, label %bb105, label %bb106
bb105:
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb106:
  br label %bb107
bb107:
  %t330 = load ptr, ptr %l20, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t330, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2echeckReuse(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, i64 %a1, { i64, ptr } %a2, ptr %a3, ptr %a4) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca %"std/prelude/text:StringBuilder"
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca %"compiler/typed:Plan"
  %l13 = alloca %"compiler/typed:Plan"
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca %"std/prelude/text:StringBuilder"
  %l23 = alloca i1
  %l37 = alloca i64
  %l40 = alloca i64
  %l61 = alloca ptr
  %l65 = alloca ptr
  %l66 = alloca i1
  %l68 = alloca ptr
  %l69 = alloca { i64, ptr }
  %l71 = alloca i64
  %l75 = alloca ptr
  %l79 = alloca ptr
  %l80 = alloca { i64, ptr }
  %l86 = alloca %"compiler/typed:Plan"
  %l88 = alloca %"compiler/typed:Plan"
  %l92 = alloca %"compiler/typed:Plan"
  %l94 = alloca %"compiler/typed:Plan"
  %l95 = alloca { i64, ptr }
  %l97 = alloca { i64, ptr }
  %l99 = alloca i1
  %l100 = alloca i1
  %l101 = alloca { i64, ptr }
  %l103 = alloca { i64, ptr }
  %l105 = alloca i1
  %l106 = alloca i1
  %l107 = alloca { i64, ptr }
  %l109 = alloca { i64, ptr }
  %l111 = alloca i1
  %l112 = alloca i1
  %l113 = alloca { i64, ptr }
  %l115 = alloca { i64, ptr }
  %l117 = alloca i1
  %l118 = alloca i1
  %l119 = alloca { i64, ptr }
  %l121 = alloca { i64, ptr }
  %l123 = alloca i1
  %l124 = alloca i1
  %l125 = alloca { i64, ptr }
  %l127 = alloca { i64, ptr }
  %l129 = alloca i1
  %l130 = alloca i1
  %l131 = alloca { i64, ptr }
  %l133 = alloca { i64, ptr }
  %l135 = alloca i1
  %l136 = alloca i1
  %l137 = alloca { i64, ptr }
  %l139 = alloca { i64, ptr }
  %l141 = alloca i1
  %l142 = alloca i1
  %l143 = alloca { i64, ptr }
  %l145 = alloca { i64, ptr }
  %l147 = alloca i1
  %l148 = alloca i1
  %l149 = alloca { i64, ptr }
  %l151 = alloca { i64, ptr }
  %l153 = alloca i1
  %l154 = alloca i1
  %l155 = alloca { i64, ptr }
  %l157 = alloca { i64, ptr }
  %l159 = alloca i1
  %l160 = alloca i1
  %l163 = alloca i1
  %l164 = alloca i1
  %l167 = alloca i1
  %l168 = alloca i1
  %l169 = alloca { i64, ptr }
  %l171 = alloca { i64, ptr }
  %l173 = alloca i1
  %l174 = alloca i1
  %l175 = alloca { i64, ptr }
  %l177 = alloca { i64, ptr }
  %l179 = alloca i1
  %l180 = alloca i1
  %l181 = alloca { i64, ptr }
  %l183 = alloca { i64, ptr }
  %l185 = alloca i1
  %l186 = alloca i1
  %l189 = alloca i1
  %l190 = alloca i1
  %l193 = alloca i1
  %l194 = alloca i1
  %l197 = alloca i1
  %l198 = alloca i1
  %l201 = alloca i1
  %l202 = alloca i1
  %l205 = alloca i1
  %l206 = alloca i1
  %l209 = alloca i1
  %l210 = alloca i1
  %l213 = alloca i1
  %l214 = alloca i1
  %l217 = alloca i1
  %l220 = alloca { i64, ptr }
  %l229 = alloca i64
  %l234 = alloca ptr
  %l239 = alloca i64
  %l242 = alloca i64
  %l245 = alloca ptr
  %l248 = alloca i64
  %l251 = alloca i64
  %l253 = alloca ptr
  %l266 = alloca { i64, ptr }
  %l269 = alloca ptr
  %l270 = alloca i64
  %l274 = alloca ptr
  %l276 = alloca i64
  %l280 = alloca ptr
  %l282 = alloca i32
  %l286 = alloca ptr
  %l288 = alloca { i64, [2 x i64] }
  %l290 = alloca { i64, ptr }
  %l295 = alloca i64
  %l297 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s13 = alloca %olang.builder
  %s13room = alloca [64 x i8], align 8
  %t149 = alloca %"compiler/typed:Plan", align 8
  %t152 = alloca %"compiler/typed:Plan", align 8
  %t158 = alloca %"compiler/typed:Plan", align 8
  %t161 = alloca %"compiler/typed:Plan", align 8
  store ptr %a0, ptr %l0
  store { i64, ptr } %a2, ptr %l2
  store ptr %a3, ptr %l3
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l18
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l18
  store %"std/prelude/text:StringBuilder" %t2, ptr %l5
  %t3 = load ptr, ptr %l4, !tbaa !29
  %t5 = getelementptr %"compiler/scope:compRun", ptr %t3, i32 0, i32 3
  %t6 = load ptr, ptr %l3, !tbaa !29
  %t8 = getelementptr %"compiler/scope:compRun", ptr %t6, i32 0, i32 3
  %t11 = call i1 @compiler_2fdiag_2ecompiler_2fdiag_3aTaken_2eSame(ptr %v3, ptr %v2, ptr %t5, ptr %t8)
  store i1 %t11, ptr %l23
  br label %bb2
bb2:
  %t12 = load i1, ptr %l23, !tbaa !21
  %t13 = xor i1 %t12, true
  br i1 %t13, label %bb3, label %bb4
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s1, ptr %l5, { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d24, i32 0, i32 1) })
  br label %bb5
bb4:
  br label %bb6
bb5:
  call void @__olang_scope_close(ptr %s1)
  br label %bb6
bb6:
  %t16 = load ptr, ptr %l4, !tbaa !29
  %t18 = getelementptr %"compiler/scope:compRun", ptr %t16, i32 0, i32 7
  %t19 = load i64, ptr %t18, !tbaa !24
  %t20 = load ptr, ptr %l3, !tbaa !29
  %t22 = getelementptr %"compiler/scope:compRun", ptr %t20, i32 0, i32 7
  %t23 = load i64, ptr %t22, !tbaa !24
  %t26 = icmp ne i64 %t19, %t23
  br i1 %t26, label %bb7, label %bb8
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s2, ptr %l5, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d25, i32 0, i32 1) })
  br label %bb9
bb8:
  br label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb10
bb10:
  store i64 0, ptr %l6, !tbaa !24
  %t29 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t31 = extractvalue { i64, ptr } %t29, 0
  store i64 %t31, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t33 = load i64, ptr %l7, !tbaa !24
  %t34 = load i64, ptr %l6, !tbaa !24
  %t37 = icmp sgt i64 %t33, %t34
  br i1 %t37, label %bb11, label %bb12
bb11:
  %t39 = load i64, ptr %l8, !tbaa !24
  %t41 = icmp sgt i64 %t39, 0
  br i1 %t41, label %bb13, label %bb14
bb12:
  store i64 0, ptr %l37, !tbaa !24
  br label %bb16
bb13:
  %t43 = load i64, ptr %l7, !tbaa !24
  %t44 = load i64, ptr %l6, !tbaa !24
  %t47 = sub i64 %t43, %t44
  %t48 = load i64, ptr %l8, !tbaa !24
  %t51 = add i64 %t47, %t48
  %t53 = sub i64 %t51, 1
  %t54 = load i64, ptr %l8, !tbaa !24
  %t57 = sdiv i64 %t53, %t54
  store i64 %t57, ptr %l40, !tbaa !24
  br label %bb15
bb14:
  store i64 0, ptr %l40, !tbaa !24
  br label %bb15
bb15:
  %t59 = load i64, ptr %l40, !tbaa !24
  store i64 %t59, ptr %l37, !tbaa !24
  br label %bb16
bb16:
  %t60 = load i64, ptr %l37, !tbaa !24
  store i64 %t60, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb17
bb17:
  store %olang.scope zeroinitializer, ptr %s4
  %t61 = load i64, ptr %l10, !tbaa !24
  %t62 = load i64, ptr %l9, !tbaa !24
  %t65 = icmp slt i64 %t61, %t62
  %t67 = xor i1 %t65, true
  br i1 %t67, label %bb18, label %bb19
bb18:
  call void @__olang_scope_close(ptr %s4)
  br label %bb133
bb19:
  br label %bb20
bb20:
  %t69 = load i64, ptr %l6, !tbaa !24
  %t70 = load i64, ptr %l10, !tbaa !24
  %t71 = load i64, ptr %l8, !tbaa !24
  %t74 = mul i64 %t70, %t71
  %t77 = add i64 %t69, %t74
  store i64 %t77, ptr %l11, !tbaa !24
  %t79 = load ptr, ptr %l4, !tbaa !29
  %t81 = getelementptr %"compiler/scope:compRun", ptr %t79, i32 0, i32 1
  %t82 = load i64, ptr %l11, !tbaa !24
  %t85 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fscope_3asummary_26_3e_Hf018e585e117ec5a1eef851c731bcf79(ptr %v3, ptr %v3, ptr %t81, i64 %t82)
  store ptr %t85, ptr %l61
  br label %bb21
bb21:
  %t86 = load ptr, ptr %l3, !tbaa !29
  %t88 = getelementptr %"compiler/scope:compRun", ptr %t86, i32 0, i32 1
  %t89 = load i64, ptr %l11, !tbaa !24
  %t92 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fscope_3asummary_26_3e_Hf018e585e117ec5a1eef851c731bcf79(ptr %v2, ptr %v2, ptr %t88, i64 %t89)
  store ptr %t92, ptr %l65
  br label %bb22
bb22:
  %t93 = load ptr, ptr %l61, !tbaa !29
  %t94 = load ptr, ptr %l65, !tbaa !29
  %t95 = call i1 @compiler_2fscope_2esameSummary(ptr %v3, ptr %v2, ptr %t93, ptr %t94)
  store i1 %t95, ptr %l66
  br label %bb23
bb23:
  %t96 = load i1, ptr %l66, !tbaa !21
  %t97 = xor i1 %t96, true
  br i1 %t97, label %bb24, label %bb25
bb24:
  store %olang.scope zeroinitializer, ptr %s5
  store ptr %l5, ptr %l68, !tbaa !29
  %t99 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t99, ptr %l69, !tbaa !27
  %t100 = load i64, ptr %l11, !tbaa !24
  %t102 = getelementptr { i64, ptr }, ptr %l69, i32 0, i32 1
  %t103 = load ptr, ptr %t102, !tbaa !27
  %t104 = getelementptr i64, ptr %t103, i64 %t100
  %t105 = load i64, ptr %t104, !tbaa !34
  store i64 %t105, ptr %l71, !tbaa !24
  %t106 = load ptr, ptr %l4, !tbaa !29
  %t108 = getelementptr %"compiler/scope:compRun", ptr %t106, i32 0, i32 1
  %t109 = load i64, ptr %l11, !tbaa !24
  %t112 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fscope_3asummary_26_3e_Hf018e585e117ec5a1eef851c731bcf79(ptr %v3, ptr %v3, ptr %t108, i64 %t109)
  store ptr %t112, ptr %l75
  br label %bb26
bb25:
  br label %bb30
bb26:
  %t113 = load ptr, ptr %l3, !tbaa !29
  %t115 = getelementptr %"compiler/scope:compRun", ptr %t113, i32 0, i32 1
  %t116 = load i64, ptr %l11, !tbaa !24
  %t119 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fscope_3asummary_26_3e_Hf018e585e117ec5a1eef851c731bcf79(ptr %v2, ptr %v2, ptr %t115, i64 %t116)
  store ptr %t119, ptr %l79
  br label %bb27
bb27:
  %t120 = load ptr, ptr %l75, !tbaa !29
  %t121 = load ptr, ptr %l79, !tbaa !29
  %t122 = call { i64, ptr } @compiler_2fscope_2esummaryDiff(ptr %v3, ptr %v2, ptr %s5, ptr %t120, ptr %t121)
  store { i64, ptr } %t122, ptr %l80
  br label %bb28
bb28:
  %t123 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d26, i32 0, i32 1) }, 1
  %t124 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d26, i32 0, i32 1) }, 0
  %t125 = load i64, ptr %l71, !tbaa !24
  %t126 = call i64 @__olang_fmt_i64(ptr null, i64 %t125)
  %t127 = add i64 %t124, %t126
  %t128 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d27, i32 0, i32 1) }, 1
  %t129 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d27, i32 0, i32 1) }, 0
  %t130 = add i64 %t127, %t129
  %t131 = load { i64, ptr }, ptr %l80, !tbaa !27
  %t132 = extractvalue { i64, ptr } %t131, 1
  %t133 = extractvalue { i64, ptr } %t131, 0
  %t134 = add i64 %t130, %t133
  %t135 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t134)
  call void @olang_textcopy(ptr %t135, ptr %t123, i64 %t124)
  %t136 = getelementptr i8, ptr %t135, i64 %t124
  %t137 = call i64 @__olang_fmt_i64(ptr %t136, i64 %t125)
  %t138 = getelementptr i8, ptr %t136, i64 %t126
  call void @olang_textcopy(ptr %t138, ptr %t128, i64 %t129)
  %t139 = getelementptr i8, ptr %t138, i64 %t129
  call void @olang_textcopy(ptr %t139, ptr %t132, i64 %t133)
  %t140 = insertvalue { i64, ptr } undef, i64 %t134, 0
  %t141 = insertvalue { i64, ptr } %t140, ptr %t135, 1
  %t143 = load ptr, ptr %l68, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s5, ptr %t143, { i64, ptr } %t141)
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s5)
  br label %bb30
bb30:
  %t145 = load ptr, ptr %l4, !tbaa !29
  %t147 = getelementptr %"compiler/scope:compRun", ptr %t145, i32 0, i32 0
  %t148 = load i64, ptr %l11, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlan_3e_2eAt_3ccompiler_2ftyped_3aPlan_3e(ptr %t149, ptr %v3, ptr %v3, ptr %t147, i64 %t148)
  call void @llvm.memmove.p0.p0.i64(ptr %l86, ptr %t149, i64 584, i1 false)
  br label %bb31
bb31:
  call void @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2ftyped_3aPlan(ptr %t152, ptr %v3, ptr %l86)
  call void @llvm.memmove.p0.p0.i64(ptr %l88, ptr %t152, i64 584, i1 false)
  br label %bb32
bb32:
  call void @llvm.memmove.p0.p0.i64(ptr %l12, ptr %l88, i64 584, i1 false)
  %t154 = load ptr, ptr %l3, !tbaa !29
  %t156 = getelementptr %"compiler/scope:compRun", ptr %t154, i32 0, i32 0
  %t157 = load i64, ptr %l11, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlan_3e_2eAt_3ccompiler_2ftyped_3aPlan_3e(ptr %t158, ptr %v2, ptr %v2, ptr %t156, i64 %t157)
  call void @llvm.memmove.p0.p0.i64(ptr %l92, ptr %t158, i64 584, i1 false)
  br label %bb33
bb33:
  call void @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2ftyped_3aPlan(ptr %t161, ptr %v2, ptr %l92)
  call void @llvm.memmove.p0.p0.i64(ptr %l94, ptr %t161, i64 584, i1 false)
  br label %bb34
bb34:
  call void @llvm.memmove.p0.p0.i64(ptr %l13, ptr %l94, i64 584, i1 false)
  %t163 = getelementptr %"compiler/typed:Plan", ptr %l12, i32 0, i32 0
  %t164 = load { i64, ptr }, ptr %t163, !tbaa !27
  store { i64, ptr } %t164, ptr %l95, !tbaa !27
  %t165 = getelementptr %"compiler/typed:Plan", ptr %l13, i32 0, i32 0
  %t166 = load { i64, ptr }, ptr %t165, !tbaa !27
  store { i64, ptr } %t166, ptr %l97, !tbaa !27
  %t169 = call i1 @olang_2emir_2eHelperKind_2eEqual_2eArray_3ccompiler_2ftyped_3aScope_3e_26(ptr %l95, ptr %l97)
  store i1 %t169, ptr %l99
  br label %bb35
bb35:
  %t170 = load i1, ptr %l99, !tbaa !21
  br i1 %t170, label %bb36, label %bb37
bb36:
  %t171 = getelementptr %"compiler/typed:Plan", ptr %l12, i32 0, i32 1
  %t172 = load { i64, ptr }, ptr %t171, !tbaa !27
  store { i64, ptr } %t172, ptr %l101, !tbaa !27
  %t173 = getelementptr %"compiler/typed:Plan", ptr %l13, i32 0, i32 1
  %t174 = load { i64, ptr }, ptr %t173, !tbaa !27
  store { i64, ptr } %t174, ptr %l103, !tbaa !27
  %t177 = call i1 @olang_2emir_2eHelperKind_2eEqual_2eArray_3ccompiler_2ftyped_3aScope_3e_26(ptr %l101, ptr %l103)
  store i1 %t177, ptr %l105
  br label %bb38
bb37:
  store i1 false, ptr %l100, !tbaa !21
  br label %bb39
bb38:
  %t178 = load i1, ptr %l105, !tbaa !21
  store i1 %t178, ptr %l100, !tbaa !21
  br label %bb39
bb39:
  %t179 = load i1, ptr %l100, !tbaa !21
  br i1 %t179, label %bb40, label %bb41
bb40:
  %t180 = getelementptr %"compiler/typed:Plan", ptr %l12, i32 0, i32 2
  %t181 = load { i64, ptr }, ptr %t180, !tbaa !27
  store { i64, ptr } %t181, ptr %l107, !tbaa !27
  %t182 = getelementptr %"compiler/typed:Plan", ptr %l13, i32 0, i32 2
  %t183 = load { i64, ptr }, ptr %t182, !tbaa !27
  store { i64, ptr } %t183, ptr %l109, !tbaa !27
  %t186 = call i1 @olang_2emir_2eHelperKind_2eEqual_2eArray_3cBool_3e_26(ptr %l107, ptr %l109)
  store i1 %t186, ptr %l111
  br label %bb42
bb41:
  store i1 false, ptr %l106, !tbaa !21
  br label %bb43
bb42:
  %t187 = load i1, ptr %l111, !tbaa !21
  store i1 %t187, ptr %l106, !tbaa !21
  br label %bb43
bb43:
  %t188 = load i1, ptr %l106, !tbaa !21
  br i1 %t188, label %bb44, label %bb45
bb44:
  %t189 = getelementptr %"compiler/typed:Plan", ptr %l12, i32 0, i32 3
  %t190 = load { i64, ptr }, ptr %t189, !tbaa !27
  store { i64, ptr } %t190, ptr %l113, !tbaa !27
  %t191 = getelementptr %"compiler/typed:Plan", ptr %l13, i32 0, i32 3
  %t192 = load { i64, ptr }, ptr %t191, !tbaa !27
  store { i64, ptr } %t192, ptr %l115, !tbaa !27
  %t195 = call i1 @olang_2emir_2eHelperKind_2eEqual_2eArray_3cBool_3e_26(ptr %l113, ptr %l115)
  store i1 %t195, ptr %l117
  br label %bb46
bb45:
  store i1 false, ptr %l112, !tbaa !21
  br label %bb47
bb46:
  %t196 = load i1, ptr %l117, !tbaa !21
  store i1 %t196, ptr %l112, !tbaa !21
  br label %bb47
bb47:
  %t197 = load i1, ptr %l112, !tbaa !21
  br i1 %t197, label %bb48, label %bb49
bb48:
  %t198 = getelementptr %"compiler/typed:Plan", ptr %l12, i32 0, i32 4
  %t199 = load { i64, ptr }, ptr %t198, !tbaa !27
  store { i64, ptr } %t199, ptr %l119, !tbaa !27
  %t200 = getelementptr %"compiler/typed:Plan", ptr %l13, i32 0, i32 4
  %t201 = load { i64, ptr }, ptr %t200, !tbaa !27
  store { i64, ptr } %t201, ptr %l121, !tbaa !27
  %t204 = call i1 @olang_2emir_2eHelperKind_2eEqual_2eArray_3cBool_3e_26(ptr %l119, ptr %l121)
  store i1 %t204, ptr %l123
  br label %bb50
bb49:
  store i1 false, ptr %l118, !tbaa !21
  br label %bb51
bb50:
  %t205 = load i1, ptr %l123, !tbaa !21
  store i1 %t205, ptr %l118, !tbaa !21
  br label %bb51
bb51:
  %t206 = load i1, ptr %l118, !tbaa !21
  br i1 %t206, label %bb52, label %bb53
bb52:
  %t207 = getelementptr %"compiler/typed:Plan", ptr %l12, i32 0, i32 5
  %t208 = load { i64, ptr }, ptr %t207, !tbaa !27
  store { i64, ptr } %t208, ptr %l125, !tbaa !27
  %t209 = getelementptr %"compiler/typed:Plan", ptr %l13, i32 0, i32 5
  %t210 = load { i64, ptr }, ptr %t209, !tbaa !27
  store { i64, ptr } %t210, ptr %l127, !tbaa !27
  %t213 = call i1 @olang_2emir_2eHelperKind_2eEqual_2eArray_3cBool_3e_26(ptr %l125, ptr %l127)
  store i1 %t213, ptr %l129
  br label %bb54
bb53:
  store i1 false, ptr %l124, !tbaa !21
  br label %bb55
bb54:
  %t214 = load i1, ptr %l129, !tbaa !21
  store i1 %t214, ptr %l124, !tbaa !21
  br label %bb55
bb55:
  %t215 = load i1, ptr %l124, !tbaa !21
  br i1 %t215, label %bb56, label %bb57
bb56:
  %t216 = getelementptr %"compiler/typed:Plan", ptr %l12, i32 0, i32 6
  %t217 = load { i64, ptr }, ptr %t216, !tbaa !27
  store { i64, ptr } %t217, ptr %l131, !tbaa !27
  %t218 = getelementptr %"compiler/typed:Plan", ptr %l13, i32 0, i32 6
  %t219 = load { i64, ptr }, ptr %t218, !tbaa !27
  store { i64, ptr } %t219, ptr %l133, !tbaa !27
  %t222 = call i1 @olang_2emir_2eHelperKind_2eEqual_2eArray_3cI64_3e_26(ptr %l131, ptr %l133)
  store i1 %t222, ptr %l135
  br label %bb58
bb57:
  store i1 false, ptr %l130, !tbaa !21
  br label %bb59
bb58:
  %t223 = load i1, ptr %l135, !tbaa !21
  store i1 %t223, ptr %l130, !tbaa !21
  br label %bb59
bb59:
  %t224 = load i1, ptr %l130, !tbaa !21
  br i1 %t224, label %bb60, label %bb61
bb60:
  %t225 = getelementptr %"compiler/typed:Plan", ptr %l12, i32 0, i32 7
  %t226 = load { i64, ptr }, ptr %t225, !tbaa !27
  store { i64, ptr } %t226, ptr %l137, !tbaa !27
  %t227 = getelementptr %"compiler/typed:Plan", ptr %l13, i32 0, i32 7
  %t228 = load { i64, ptr }, ptr %t227, !tbaa !27
  store { i64, ptr } %t228, ptr %l139, !tbaa !27
  %t231 = call i1 @olang_2emir_2eHelperKind_2eEqual_2eArray_3ccompiler_2ftyped_3aScope_3e_26(ptr %l137, ptr %l139)
  store i1 %t231, ptr %l141
  br label %bb62
bb61:
  store i1 false, ptr %l136, !tbaa !21
  br label %bb63
bb62:
  %t232 = load i1, ptr %l141, !tbaa !21
  store i1 %t232, ptr %l136, !tbaa !21
  br label %bb63
bb63:
  %t233 = load i1, ptr %l136, !tbaa !21
  br i1 %t233, label %bb64, label %bb65
bb64:
  %t234 = getelementptr %"compiler/typed:Plan", ptr %l12, i32 0, i32 8
  %t235 = load { i64, ptr }, ptr %t234, !tbaa !27
  store { i64, ptr } %t235, ptr %l143, !tbaa !27
  %t236 = getelementptr %"compiler/typed:Plan", ptr %l13, i32 0, i32 8
  %t237 = load { i64, ptr }, ptr %t236, !tbaa !27
  store { i64, ptr } %t237, ptr %l145, !tbaa !27
  %t240 = call i1 @olang_2emir_2eHelperKind_2eEqual_2eArray_3ccompiler_2ftyped_3aExpr_3f_26_3e_26(ptr %l143, ptr %l145)
  store i1 %t240, ptr %l147
  br label %bb66
bb65:
  store i1 false, ptr %l142, !tbaa !21
  br label %bb67
bb66:
  %t241 = load i1, ptr %l147, !tbaa !21
  store i1 %t241, ptr %l142, !tbaa !21
  br label %bb67
bb67:
  %t242 = load i1, ptr %l142, !tbaa !21
  br i1 %t242, label %bb68, label %bb69
bb68:
  %t243 = getelementptr %"compiler/typed:Plan", ptr %l12, i32 0, i32 9
  %t244 = load { i64, ptr }, ptr %t243, !tbaa !27
  store { i64, ptr } %t244, ptr %l149, !tbaa !27
  %t245 = getelementptr %"compiler/typed:Plan", ptr %l13, i32 0, i32 9
  %t246 = load { i64, ptr }, ptr %t245, !tbaa !27
  store { i64, ptr } %t246, ptr %l151, !tbaa !27
  %t249 = call i1 @olang_2emir_2eHelperKind_2eEqual_2eArray_3cI64_3e_26(ptr %l149, ptr %l151)
  store i1 %t249, ptr %l153
  br label %bb70
bb69:
  store i1 false, ptr %l148, !tbaa !21
  br label %bb71
bb70:
  %t250 = load i1, ptr %l153, !tbaa !21
  store i1 %t250, ptr %l148, !tbaa !21
  br label %bb71
bb71:
  %t251 = load i1, ptr %l148, !tbaa !21
  br i1 %t251, label %bb72, label %bb73
bb72:
  %t252 = getelementptr %"compiler/typed:Plan", ptr %l12, i32 0, i32 10
  %t253 = load { i64, ptr }, ptr %t252, !tbaa !27
  store { i64, ptr } %t253, ptr %l155, !tbaa !27
  %t254 = getelementptr %"compiler/typed:Plan", ptr %l13, i32 0, i32 10
  %t255 = load { i64, ptr }, ptr %t254, !tbaa !27
  store { i64, ptr } %t255, ptr %l157, !tbaa !27
  %t258 = call i1 @olang_2emir_2eHelperKind_2eEqual_2eArray_3cI64_3e_26(ptr %l155, ptr %l157)
  store i1 %t258, ptr %l159
  br label %bb74
bb73:
  store i1 false, ptr %l154, !tbaa !21
  br label %bb75
bb74:
  %t259 = load i1, ptr %l159, !tbaa !21
  store i1 %t259, ptr %l154, !tbaa !21
  br label %bb75
bb75:
  %t260 = load i1, ptr %l154, !tbaa !21
  br i1 %t260, label %bb76, label %bb77
bb76:
  %t261 = getelementptr %"compiler/typed:Plan", ptr %l12, i32 0, i32 11
  %t262 = getelementptr %"compiler/typed:Plan", ptr %l13, i32 0, i32 11
  %t265 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eEq_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v3, ptr %v2, ptr %t261, ptr %t262)
  store i1 %t265, ptr %l163
  br label %bb78
bb77:
  store i1 false, ptr %l160, !tbaa !21
  br label %bb79
bb78:
  %t266 = load i1, ptr %l163, !tbaa !21
  store i1 %t266, ptr %l160, !tbaa !21
  br label %bb79
bb79:
  %t267 = load i1, ptr %l160, !tbaa !21
  br i1 %t267, label %bb80, label %bb81
bb80:
  %t268 = getelementptr %"compiler/typed:Plan", ptr %l12, i32 0, i32 12
  %t269 = getelementptr %"compiler/typed:Plan", ptr %l13, i32 0, i32 12
  %t272 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eEq_3cI64_3e(ptr %v3, ptr %v2, ptr %t268, ptr %t269)
  store i1 %t272, ptr %l167
  br label %bb82
bb81:
  store i1 false, ptr %l164, !tbaa !21
  br label %bb83
bb82:
  %t273 = load i1, ptr %l167, !tbaa !21
  store i1 %t273, ptr %l164, !tbaa !21
  br label %bb83
bb83:
  %t274 = load i1, ptr %l164, !tbaa !21
  br i1 %t274, label %bb84, label %bb85
bb84:
  %t275 = getelementptr %"compiler/typed:Plan", ptr %l12, i32 0, i32 13
  %t276 = load { i64, ptr }, ptr %t275, !tbaa !27
  store { i64, ptr } %t276, ptr %l169, !tbaa !27
  %t277 = getelementptr %"compiler/typed:Plan", ptr %l13, i32 0, i32 13
  %t278 = load { i64, ptr }, ptr %t277, !tbaa !27
  store { i64, ptr } %t278, ptr %l171, !tbaa !27
  %t281 = call i1 @olang_2emir_2eHelperKind_2eEqual_2eArray_3cI64_3e_26(ptr %l169, ptr %l171)
  store i1 %t281, ptr %l173
  br label %bb86
bb85:
  store i1 false, ptr %l168, !tbaa !21
  br label %bb87
bb86:
  %t282 = load i1, ptr %l173, !tbaa !21
  store i1 %t282, ptr %l168, !tbaa !21
  br label %bb87
bb87:
  %t283 = load i1, ptr %l168, !tbaa !21
  br i1 %t283, label %bb88, label %bb89
bb88:
  %t284 = getelementptr %"compiler/typed:Plan", ptr %l12, i32 0, i32 14
  %t285 = load { i64, ptr }, ptr %t284, !tbaa !27
  store { i64, ptr } %t285, ptr %l175, !tbaa !27
  %t286 = getelementptr %"compiler/typed:Plan", ptr %l13, i32 0, i32 14
  %t287 = load { i64, ptr }, ptr %t286, !tbaa !27
  store { i64, ptr } %t287, ptr %l177, !tbaa !27
  %t290 = call i1 @olang_2emir_2eHelperKind_2eEqual_2eArray_3cI64_3e_26(ptr %l175, ptr %l177)
  store i1 %t290, ptr %l179
  br label %bb90
bb89:
  store i1 false, ptr %l174, !tbaa !21
  br label %bb91
bb90:
  %t291 = load i1, ptr %l179, !tbaa !21
  store i1 %t291, ptr %l174, !tbaa !21
  br label %bb91
bb91:
  %t292 = load i1, ptr %l174, !tbaa !21
  br i1 %t292, label %bb92, label %bb93
bb92:
  %t293 = getelementptr %"compiler/typed:Plan", ptr %l12, i32 0, i32 15
  %t294 = load { i64, ptr }, ptr %t293, !tbaa !27
  store { i64, ptr } %t294, ptr %l181, !tbaa !27
  %t295 = getelementptr %"compiler/typed:Plan", ptr %l13, i32 0, i32 15
  %t296 = load { i64, ptr }, ptr %t295, !tbaa !27
  store { i64, ptr } %t296, ptr %l183, !tbaa !27
  %t299 = call i1 @olang_2emir_2eHelperKind_2eEqual_2eArray_3cI64_3e_26(ptr %l181, ptr %l183)
  store i1 %t299, ptr %l185
  br label %bb94
bb93:
  store i1 false, ptr %l180, !tbaa !21
  br label %bb95
bb94:
  %t300 = load i1, ptr %l185, !tbaa !21
  store i1 %t300, ptr %l180, !tbaa !21
  br label %bb95
bb95:
  %t301 = load i1, ptr %l180, !tbaa !21
  br i1 %t301, label %bb96, label %bb97
bb96:
  %t302 = getelementptr %"compiler/typed:Plan", ptr %l12, i32 0, i32 16
  %t303 = getelementptr %"compiler/typed:Plan", ptr %l13, i32 0, i32 16
  %t306 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScope_3e_2eEq_3ccompiler_2ftyped_3aScope_3e(ptr %v3, ptr %v2, ptr %t302, ptr %t303)
  store i1 %t306, ptr %l189
  br label %bb98
bb97:
  store i1 false, ptr %l186, !tbaa !21
  br label %bb99
bb98:
  %t307 = load i1, ptr %l189, !tbaa !21
  store i1 %t307, ptr %l186, !tbaa !21
  br label %bb99
bb99:
  %t308 = load i1, ptr %l186, !tbaa !21
  br i1 %t308, label %bb100, label %bb101
bb100:
  %t309 = getelementptr %"compiler/typed:Plan", ptr %l12, i32 0, i32 17
  %t310 = getelementptr %"compiler/typed:Plan", ptr %l13, i32 0, i32 17
  %t313 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eEq_3cI64_3e(ptr %v3, ptr %v2, ptr %t309, ptr %t310)
  store i1 %t313, ptr %l193
  br label %bb102
bb101:
  store i1 false, ptr %l190, !tbaa !21
  br label %bb103
bb102:
  %t314 = load i1, ptr %l193, !tbaa !21
  store i1 %t314, ptr %l190, !tbaa !21
  br label %bb103
bb103:
  %t315 = load i1, ptr %l190, !tbaa !21
  br i1 %t315, label %bb104, label %bb105
bb104:
  %t316 = getelementptr %"compiler/typed:Plan", ptr %l12, i32 0, i32 18
  %t317 = getelementptr %"compiler/typed:Plan", ptr %l13, i32 0, i32 18
  %t320 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eEq_3cI64_3e(ptr %v3, ptr %v2, ptr %t316, ptr %t317)
  store i1 %t320, ptr %l197
  br label %bb106
bb105:
  store i1 false, ptr %l194, !tbaa !21
  br label %bb107
bb106:
  %t321 = load i1, ptr %l197, !tbaa !21
  store i1 %t321, ptr %l194, !tbaa !21
  br label %bb107
bb107:
  %t322 = load i1, ptr %l194, !tbaa !21
  br i1 %t322, label %bb108, label %bb109
bb108:
  %t323 = getelementptr %"compiler/typed:Plan", ptr %l12, i32 0, i32 19
  %t324 = getelementptr %"compiler/typed:Plan", ptr %l13, i32 0, i32 19
  %t327 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cc_H80e5c7f116c5eff77ef32968f58f5b4d(ptr %s4, ptr %v2, ptr %t323, ptr %t324)
  store i1 %t327, ptr %l201
  br label %bb110
bb109:
  store i1 false, ptr %l198, !tbaa !21
  br label %bb111
bb110:
  %t328 = load i1, ptr %l201, !tbaa !21
  store i1 %t328, ptr %l198, !tbaa !21
  br label %bb111
bb111:
  %t329 = load i1, ptr %l198, !tbaa !21
  br i1 %t329, label %bb112, label %bb113
bb112:
  %t330 = getelementptr %"compiler/typed:Plan", ptr %l12, i32 0, i32 20
  %t331 = getelementptr %"compiler/typed:Plan", ptr %l13, i32 0, i32 20
  %t334 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eEq_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v3, ptr %v2, ptr %t330, ptr %t331)
  store i1 %t334, ptr %l205
  br label %bb114
bb113:
  store i1 false, ptr %l202, !tbaa !21
  br label %bb115
bb114:
  %t335 = load i1, ptr %l205, !tbaa !21
  store i1 %t335, ptr %l202, !tbaa !21
  br label %bb115
bb115:
  %t336 = load i1, ptr %l202, !tbaa !21
  br i1 %t336, label %bb116, label %bb117
bb116:
  %t337 = getelementptr %"compiler/typed:Plan", ptr %l12, i32 0, i32 21
  %t338 = getelementptr %"compiler/typed:Plan", ptr %l13, i32 0, i32 21
  %t341 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3ccompiler_2_H16eefdf2f060cccd64cc684009ec3f7f(ptr %s4, ptr %s4, ptr %t337, ptr %t338)
  store i1 %t341, ptr %l209
  br label %bb118
bb117:
  store i1 false, ptr %l206, !tbaa !21
  br label %bb119
bb118:
  %t342 = load i1, ptr %l209, !tbaa !21
  store i1 %t342, ptr %l206, !tbaa !21
  br label %bb119
bb119:
  %t343 = load i1, ptr %l206, !tbaa !21
  br i1 %t343, label %bb120, label %bb121
bb120:
  %t344 = getelementptr %"compiler/typed:Plan", ptr %l12, i32 0, i32 22
  %t345 = getelementptr %"compiler/typed:Plan", ptr %l13, i32 0, i32 22
  %t348 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eEq_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v3, ptr %v2, ptr %t344, ptr %t345)
  store i1 %t348, ptr %l213
  br label %bb122
bb121:
  store i1 false, ptr %l210, !tbaa !21
  br label %bb123
bb122:
  %t349 = load i1, ptr %l213, !tbaa !21
  store i1 %t349, ptr %l210, !tbaa !21
  br label %bb123
bb123:
  %t350 = load i1, ptr %l210, !tbaa !21
  br i1 %t350, label %bb124, label %bb125
bb124:
  %t351 = getelementptr %"compiler/typed:Plan", ptr %l12, i32 0, i32 23
  %t352 = getelementptr %"compiler/typed:Plan", ptr %l13, i32 0, i32 23
  %t355 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScope_3e_2eEq_3ccompiler_2ftyped_3aScope_3e(ptr %v3, ptr %v2, ptr %t351, ptr %t352)
  store i1 %t355, ptr %l217
  br label %bb126
bb125:
  store i1 false, ptr %l214, !tbaa !21
  br label %bb127
bb126:
  %t356 = load i1, ptr %l217, !tbaa !21
  store i1 %t356, ptr %l214, !tbaa !21
  br label %bb127
bb127:
  %t357 = load i1, ptr %l214, !tbaa !21
  %t358 = xor i1 %t357, true
  br i1 %t358, label %bb128, label %bb129
bb128:
  store %olang.scope zeroinitializer, ptr %s7
  %t360 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t360, ptr %l220, !tbaa !27
  %t361 = load i64, ptr %l11, !tbaa !24
  %t363 = getelementptr { i64, ptr }, ptr %l220, i32 0, i32 1
  %t364 = load ptr, ptr %t363, !tbaa !27
  %t365 = getelementptr i64, ptr %t364, i64 %t361
  %t366 = load i64, ptr %t365, !tbaa !34
  %t367 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d28, i32 0, i32 1) }, 1
  %t368 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d28, i32 0, i32 1) }, 0
  %t370 = call i64 @__olang_fmt_i64(ptr null, i64 %t366)
  %t371 = add i64 %t368, %t370
  %t372 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t371)
  call void @olang_textcopy(ptr %t372, ptr %t367, i64 %t368)
  %t373 = getelementptr i8, ptr %t372, i64 %t368
  %t374 = call i64 @__olang_fmt_i64(ptr %t373, i64 %t366)
  %t375 = insertvalue { i64, ptr } undef, i64 %t371, 0
  %t376 = insertvalue { i64, ptr } %t375, ptr %t372, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s7, ptr %l5, { i64, ptr } %t376)
  br label %bb130
bb129:
  br label %bb131
bb130:
  call void @__olang_scope_close(ptr %s7)
  br label %bb131
bb131:
  call void @__olang_scope_close(ptr %s4)
  br label %bb132
bb132:
  %t380 = load i64, ptr %l10, !tbaa !24
  %t383 = add i64 %t380, 1
  store i64 %t383, ptr %l10, !tbaa !24
  br label %bb17
bb133:
  %t386 = call i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eLen(ptr %s0, ptr %l5)
  store i64 %t386, ptr %l229
  br label %bb134
bb134:
  %t387 = load i64, ptr %l229, !tbaa !24
  %t388 = icmp eq i64 %t387, 0
  br i1 %t388, label %bb135, label %bb136
bb135:
  %t390 = load ptr, ptr %l0, !tbaa !29
  %t392 = getelementptr %"compiler/scope:Scoper", ptr %t390, i32 0, i32 0
  %t393 = load ptr, ptr %t392, !tbaa !29
  %t395 = getelementptr %"compiler/generic:Program", ptr %t393, i32 0, i32 0
  %t396 = load ptr, ptr %t395, !tbaa !29
  %t398 = getelementptr %"compiler/load:Loader", ptr %t396, i32 0, i32 4
  %t399 = load ptr, ptr %t398, !tbaa !29
  store ptr %t399, ptr %l234, !tbaa !29
  %t400 = load ptr, ptr %l0, !tbaa !29
  %t402 = getelementptr %"compiler/scope:Scoper", ptr %t400, i32 0, i32 0
  %t403 = load ptr, ptr %t402, !tbaa !29
  %t405 = getelementptr %"compiler/generic:Program", ptr %t403, i32 0, i32 0
  %t406 = load ptr, ptr %t405, !tbaa !29
  %t408 = getelementptr %"compiler/load:Loader", ptr %t406, i32 0, i32 4
  %t409 = load ptr, ptr %t408, !tbaa !29
  %t411 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eCount(ptr %v0, ptr %t409)
  store i64 %t411, ptr %l239
  br label %bb137
bb136:
  br label %bb143
bb137:
  %t412 = load ptr, ptr %l4, !tbaa !29
  %t414 = getelementptr %"compiler/scope:compRun", ptr %t412, i32 0, i32 3
  %t416 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aTaken_2eCount(ptr %v3, ptr %t414)
  store i64 %t416, ptr %l242
  br label %bb138
bb138:
  %t417 = load i64, ptr %l239, !tbaa !24
  %t418 = load i64, ptr %l242, !tbaa !24
  %t419 = sub i64 %t417, %t418
  %t420 = load ptr, ptr %l234, !tbaa !29
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eForget(ptr %v0, ptr %t420, i64 %t419, i64 -1)
  br label %bb139
bb139:
  %t422 = load ptr, ptr %l0, !tbaa !29
  %t424 = getelementptr %"compiler/scope:Scoper", ptr %t422, i32 0, i32 3
  store ptr %t424, ptr %l245, !tbaa !29
  %t425 = load ptr, ptr %l0, !tbaa !29
  %t427 = getelementptr %"compiler/scope:Scoper", ptr %t425, i32 0, i32 3
  %t429 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aGap_3e_2eLen_3ccompiler_2fscope_3aGap_3e(ptr %v0, ptr %t427)
  store i64 %t429, ptr %l248
  br label %bb140
bb140:
  %t430 = load ptr, ptr %l4, !tbaa !29
  %t432 = getelementptr %"compiler/scope:compRun", ptr %t430, i32 0, i32 4
  %t434 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aGap_3e_2eLen_3ccompiler_2fscope_3aGap_3e(ptr %v3, ptr %t432)
  store i64 %t434, ptr %l251
  br label %bb141
bb141:
  %t435 = load i64, ptr %l248, !tbaa !24
  %t436 = load i64, ptr %l251, !tbaa !24
  %t437 = sub i64 %t435, %t436
  %t438 = load ptr, ptr %l245, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aGap_3e_2eTruncate_3ccompiler_2fscope_3aGap_3e(ptr %v0, ptr %t438, i64 %t437)
  br label %bb142
bb142:
  %t440 = load ptr, ptr %l0, !tbaa !29
  store ptr %t440, ptr %l253, !tbaa !29
  %t441 = load ptr, ptr %l253, !tbaa !29
  %t442 = getelementptr %"compiler/scope:Scoper", ptr %t441, i32 0, i32 235
  %t443 = load i64, ptr %t442, !tbaa !24
  %t445 = load ptr, ptr %l4, !tbaa !29
  %t447 = getelementptr %"compiler/scope:compRun", ptr %t445, i32 0, i32 7
  %t448 = load i64, ptr %t447, !tbaa !24
  %t451 = sub i64 %t443, %t448
  %t453 = load ptr, ptr %l253, !tbaa !29
  %t454 = getelementptr %"compiler/scope:Scoper", ptr %t453, i32 0, i32 235
  store i64 %t451, ptr %t454, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb143:
  %t455 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t455, ptr %l14, !tbaa !27
  store i64 0, ptr %l15, !tbaa !24
  %t457 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t459 = extractvalue { i64, ptr } %t457, 0
  store i64 %t459, ptr %l16, !tbaa !24
  br label %bb144
bb144:
  store %olang.scope zeroinitializer, ptr %s12
  %t461 = load i64, ptr %l15, !tbaa !24
  %t462 = load i64, ptr %l16, !tbaa !24
  %t465 = icmp slt i64 %t461, %t462
  %t467 = xor i1 %t465, true
  br i1 %t467, label %bb145, label %bb146
bb145:
  call void @__olang_scope_close(ptr %s12)
  br label %bb154
bb146:
  br label %bb147
bb147:
  %t469 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t469, ptr %l266, !tbaa !27
  %t470 = load i64, ptr %l15, !tbaa !24
  %t472 = getelementptr { i64, ptr }, ptr %l266, i32 0, i32 1
  %t473 = load ptr, ptr %t472, !tbaa !27
  %t474 = getelementptr i64, ptr %t473, i64 %t470
  %t475 = load i64, ptr %t474, !tbaa !34
  store i64 %t475, ptr %l17, !tbaa !24
  store ptr %l5, ptr %l269, !tbaa !29
  %t477 = load i64, ptr %l17, !tbaa !24
  store i64 %t477, ptr %l270, !tbaa !24
  %t478 = load ptr, ptr %l0, !tbaa !29
  %t480 = getelementptr %"compiler/scope:Scoper", ptr %t478, i32 0, i32 1
  %t481 = load i64, ptr %l17, !tbaa !24
  %t484 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t480, i64 %t481)
  store ptr %t484, ptr %l274
  br label %bb148
bb148:
  %t485 = load ptr, ptr %l274, !tbaa !29
  %t487 = getelementptr %"compiler/typed:Body", ptr %t485, i32 0, i32 3
  %t488 = load i64, ptr %t487, !tbaa !24
  store i64 %t488, ptr %l276, !tbaa !24
  %t489 = load ptr, ptr %l0, !tbaa !29
  %t491 = getelementptr %"compiler/scope:Scoper", ptr %t489, i32 0, i32 1
  %t492 = load i64, ptr %l17, !tbaa !24
  %t495 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t491, i64 %t492)
  store ptr %t495, ptr %l280
  br label %bb149
bb149:
  %t496 = load ptr, ptr %l280, !tbaa !29
  %t498 = getelementptr %"compiler/typed:Body", ptr %t496, i32 0, i32 4
  %t499 = getelementptr %"compiler/source:Span", ptr %t498, i32 0, i32 0
  %t500 = load i32, ptr %t499, !tbaa !23
  store i32 %t500, ptr %l282, !tbaa !23
  %t501 = load ptr, ptr %l0, !tbaa !29
  %t503 = getelementptr %"compiler/scope:Scoper", ptr %t501, i32 0, i32 1
  %t504 = load i64, ptr %l17, !tbaa !24
  %t507 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t503, i64 %t504)
  store ptr %t507, ptr %l286
  br label %bb150
bb150:
  %t508 = load ptr, ptr %l286, !tbaa !29
  %t510 = getelementptr %"compiler/typed:Body", ptr %t508, i32 0, i32 1
  %t511 = load { i64, [2 x i64] }, ptr %t510
  store { i64, [2 x i64] } %t511, ptr %l288
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s13
  store ptr %s13room, ptr %s13
  %t512 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d29, i32 0, i32 1) }, 1
  %t513 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d29, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s13, ptr %t512, i64 %t513)
  %t514 = load i64, ptr %l270, !tbaa !24
  %t515 = call ptr @__olang_sb_room(ptr %s13, i64 24)
  %t516 = call i64 @__olang_fmt_i64(ptr %t515, i64 %t514)
  call void @__olang_sb_add(ptr %s13, i64 %t516)
  %t517 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d30, i32 0, i32 1) }, 1
  %t518 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d30, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s13, ptr %t517, i64 %t518)
  %t519 = load i64, ptr %l276, !tbaa !24
  %t520 = call ptr @__olang_sb_room(ptr %s13, i64 24)
  %t521 = call i64 @__olang_fmt_i64(ptr %t520, i64 %t519)
  call void @__olang_sb_add(ptr %s13, i64 %t521)
  %t522 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d31, i32 0, i32 1) }, 1
  %t523 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d31, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s13, ptr %t522, i64 %t523)
  %t524 = load i32, ptr %l282, !tbaa !23
  %t525 = sext i32 %t524 to i64
  %t526 = call ptr @__olang_sb_room(ptr %s13, i64 24)
  %t527 = call i64 @__olang_fmt_i64(ptr %t526, i64 %t525)
  call void @__olang_sb_add(ptr %s13, i64 %t527)
  %t528 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d32, i32 0, i32 1) }, 1
  %t529 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d32, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s13, ptr %t528, i64 %t529)
  call void @olang_2emir_2eHelperKind_2eRender_2ecompiler_2ftyped_3aBodyOf(ptr %s13, ptr %l288, i64 0)
  br label %bb151
bb151:
  %t531 = load ptr, ptr %s13
  %t532 = getelementptr %olang.builder, ptr %s13, i32 0, i32 1
  %t533 = load i64, ptr %t532
  %t534 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t533)
  call void @olang_textcopy(ptr %t534, ptr %t531, i64 %t533)
  %t535 = insertvalue { i64, ptr } undef, i64 %t533, 0
  %t536 = insertvalue { i64, ptr } %t535, ptr %t534, 1
  store { i64, ptr } %t536, ptr %l290, !tbaa !27
  %t537 = getelementptr %olang.builder, ptr %s13, i32 0, i32 3
  %t538 = load ptr, ptr %t537
  %t539 = icmp ne ptr %t538, null
  br i1 %t539, label %sbgrew.540, label %sbdone.541
sbgrew.540:
  call void @__olang_sb_done(ptr %s13)
  br label %sbdone.541
sbdone.541:
  %t542 = load { i64, ptr }, ptr %l290, !tbaa !27
  %t543 = load ptr, ptr %l269, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s12, ptr %t543, { i64, ptr } %t542)
  br label %bb152
bb152:
  call void @__olang_scope_close(ptr %s12)
  br label %bb153
bb153:
  %t545 = load i64, ptr %l15, !tbaa !24
  %t548 = add i64 %t545, 1
  store i64 %t548, ptr %l15, !tbaa !24
  br label %bb144
bb154:
  br i1 false, label %bb155, label %bb156
bb155:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb156:
  store i64 %a1, ptr %l295, !tbaa !24
  %t552 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s0, ptr %l5)
  store { i64, ptr } %t552, ptr %l297
  br label %bb157
bb157:
  %t553 = extractvalue { i64, ptr } { i64 28, ptr getelementptr inbounds (<{ i64, [28 x i8] }>, ptr @.d33, i32 0, i32 1) }, 1
  %t554 = extractvalue { i64, ptr } { i64 28, ptr getelementptr inbounds (<{ i64, [28 x i8] }>, ptr @.d33, i32 0, i32 1) }, 0
  %t555 = load i64, ptr %l295, !tbaa !24
  %t556 = call i64 @__olang_fmt_i64(ptr null, i64 %t555)
  %t557 = add i64 %t554, %t556
  %t558 = extractvalue { i64, ptr } { i64 37, ptr getelementptr inbounds (<{ i64, [37 x i8] }>, ptr @.d34, i32 0, i32 1) }, 1
  %t559 = extractvalue { i64, ptr } { i64 37, ptr getelementptr inbounds (<{ i64, [37 x i8] }>, ptr @.d34, i32 0, i32 1) }, 0
  %t560 = add i64 %t557, %t559
  %t561 = load { i64, ptr }, ptr %l297, !tbaa !27
  %t562 = extractvalue { i64, ptr } %t561, 1
  %t563 = extractvalue { i64, ptr } %t561, 0
  %t564 = add i64 %t560, %t563
  %t565 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t564)
  call void @olang_textcopy(ptr %t565, ptr %t553, i64 %t554)
  %t566 = getelementptr i8, ptr %t565, i64 %t554
  %t567 = call i64 @__olang_fmt_i64(ptr %t566, i64 %t555)
  %t568 = getelementptr i8, ptr %t566, i64 %t556
  call void @olang_textcopy(ptr %t568, ptr %t558, i64 %t559)
  %t569 = getelementptr i8, ptr %t568, i64 %t559
  call void @olang_textcopy(ptr %t569, ptr %t562, i64 %t563)
  %t570 = insertvalue { i64, ptr } undef, i64 %t564, 0
  %t571 = insertvalue { i64, ptr } %t570, ptr %t565, 1
  %t574 = extractvalue { i64, ptr } %t571, 1
  %t575 = extractvalue { i64, ptr } %t571, 0
  %t576 = insertvalue { i64, ptr } undef, i64 %t575, 0
  %t577 = insertvalue { i64, ptr } %t576, ptr %t574, 1
  call void @__olang_check_failed_text(ptr @olang_loc_6a87b3eb83e8e753_81a9677ce8feda27, { i64, ptr } %t577)
  unreachable
ret:
  ret void
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecomponents(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca %"compiler/scope:walked"
  %l12 = alloca ptr
  %l13 = alloca i64
  %l15 = alloca ptr
  %l16 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca ptr
  %l26 = alloca i64
  %l27 = alloca ptr
  %l28 = alloca ptr
  %l29 = alloca i64
  %l30 = alloca ptr
  %l31 = alloca ptr
  %l32 = alloca i64
  %l34 = alloca ptr
  %l35 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i64
  %l45 = alloca i64
  %l46 = alloca i64
  %l47 = alloca i64
  %l48 = alloca i64
  %l51 = alloca i64
  %l52 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l53 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l54 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l59 = alloca i64
  %l62 = alloca i64
  %l81 = alloca ptr
  %l84 = alloca i64
  %l87 = alloca %"compiler/scope:walked"
  %l89 = alloca i64
  %l91 = alloca i64
  %l96 = alloca i64
  %l104 = alloca i64
  %l106 = alloca i64
  %l111 = alloca i32
  %l114 = alloca i64
  %l124 = alloca i64
  %l128 = alloca i64
  %l131 = alloca i64
  %l150 = alloca ptr
  %l153 = alloca i64
  %l156 = alloca { i64, ptr }
  %l161 = alloca i64
  %l163 = alloca i64
  %l168 = alloca ptr
  %l171 = alloca ptr
  %l173 = alloca i64
  %l178 = alloca i64
  %l181 = alloca ptr
  %l182 = alloca i64
  %l184 = alloca { i64, ptr }
  %l187 = alloca i64
  %l189 = alloca i64
  %l194 = alloca ptr
  %l199 = alloca ptr
  %l201 = alloca i64
  %l206 = alloca i64
  %l208 = alloca i1
  %l212 = alloca i1
  %l216 = alloca ptr
  %l219 = alloca i64
  %l221 = alloca i64
  %l223 = alloca i64
  %l228 = alloca i64
  %l236 = alloca ptr
  %l239 = alloca i64
  %l241 = alloca i64
  %l243 = alloca i64
  %l248 = alloca i64
  %l256 = alloca i64
  %l260 = alloca i64
  %l263 = alloca i64
  %l282 = alloca ptr
  %l285 = alloca ptr
  %l288 = alloca i32
  %l289 = alloca i32
  %l290 = alloca i64
  %l293 = alloca i64
  %l294 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l308 = alloca ptr
  %l311 = alloca i64
  %l313 = alloca ptr
  %l316 = alloca i64
  %l318 = alloca ptr
  %l321 = alloca i64
  %l323 = alloca i64
  %l333 = alloca i64
  %l336 = alloca i64
  %l357 = alloca i64
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s28 = alloca %olang.scope
  %t73 = alloca %"compiler/scope:walked", align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 1
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l51
  br label %bb1
bb1:
  %t6 = load i64, ptr %l51, !tbaa !24
  store i64 %t6, ptr %l1, !tbaa !24
  %t7 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t7, ptr %l52
  br label %bb2
bb2:
  %t8 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l52
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t8, ptr %l2
  %t9 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %l53
  br label %bb3
bb3:
  %t10 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l53
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t10, ptr %l3
  %t11 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t11, ptr %l54
  br label %bb4
bb4:
  %t12 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l54
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t12, ptr %l4
  store i64 0, ptr %l5, !tbaa !24
  %t13 = load i64, ptr %l1, !tbaa !24
  store i64 %t13, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t15 = load i64, ptr %l6, !tbaa !24
  %t16 = load i64, ptr %l5, !tbaa !24
  %t19 = icmp sgt i64 %t15, %t16
  br i1 %t19, label %bb5, label %bb6
bb5:
  %t21 = load i64, ptr %l7, !tbaa !24
  %t23 = icmp sgt i64 %t21, 0
  br i1 %t23, label %bb7, label %bb8
bb6:
  store i64 0, ptr %l59, !tbaa !24
  br label %bb10
bb7:
  %t25 = load i64, ptr %l6, !tbaa !24
  %t26 = load i64, ptr %l5, !tbaa !24
  %t29 = sub i64 %t25, %t26
  %t30 = load i64, ptr %l7, !tbaa !24
  %t33 = add i64 %t29, %t30
  %t35 = sub i64 %t33, 1
  %t36 = load i64, ptr %l7, !tbaa !24
  %t39 = sdiv i64 %t35, %t36
  store i64 %t39, ptr %l62, !tbaa !24
  br label %bb9
bb8:
  store i64 0, ptr %l62, !tbaa !24
  br label %bb9
bb9:
  %t41 = load i64, ptr %l62, !tbaa !24
  store i64 %t41, ptr %l59, !tbaa !24
  br label %bb10
bb10:
  %t42 = load i64, ptr %l59, !tbaa !24
  store i64 %t42, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb11
bb11:
  store %olang.scope zeroinitializer, ptr %s2
  %t43 = load i64, ptr %l9, !tbaa !24
  %t44 = load i64, ptr %l8, !tbaa !24
  %t47 = icmp slt i64 %t43, %t44
  %t49 = xor i1 %t47, true
  br i1 %t49, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s2)
  br label %bb137
bb13:
  br label %bb14
bb14:
  %t51 = load i64, ptr %l5, !tbaa !24
  %t52 = load i64, ptr %l9, !tbaa !24
  %t53 = load i64, ptr %l7, !tbaa !24
  %t56 = mul i64 %t52, %t53
  %t59 = add i64 %t51, %t56
  store i64 %t59, ptr %l10, !tbaa !24
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = getelementptr %"compiler/scope:Scoper", ptr %t61, i32 0, i32 14
  store ptr %t63, ptr %l81, !tbaa !29
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/scope:Scoper", ptr %t64, i32 0, i32 15
  %t68 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t66)
  store i64 %t68, ptr %l84
  br label %bb15
bb15:
  %t69 = load ptr, ptr %l81, !tbaa !29
  %t70 = load i64, ptr %l84, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t69, i64 %t70)
  br label %bb16
bb16:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t72 = load i64, ptr %l10, !tbaa !24
  call void @compiler_2fscope_2ewalked_2ewalkBody(ptr %t73, ptr %v0, ptr %v0, ptr %t71, i64 %t72)
  call void @llvm.memmove.p0.p0.i64(ptr %l87, ptr %t73, i64 424, i1 false)
  br label %bb17
bb17:
  call void @llvm.memmove.p0.p0.i64(ptr %l11, ptr %l87, i64 424, i1 false)
  %t76 = getelementptr %"compiler/scope:walked", ptr %l11, i32 0, i32 0
  store ptr %t76, ptr %l12, !tbaa !29
  store i64 0, ptr %l13, !tbaa !24
  br label %bb18
bb18:
  %t78 = load i64, ptr %l13, !tbaa !24
  store i64 %t78, ptr %l89, !tbaa !24
  %t79 = load ptr, ptr %l12, !tbaa !29
  %t81 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s2, ptr %t79)
  store i64 %t81, ptr %l91
  br label %bb19
bb19:
  %t82 = load i64, ptr %l89, !tbaa !24
  %t83 = load i64, ptr %l91, !tbaa !24
  %t84 = icmp slt i64 %t82, %t83
  %t86 = xor i1 %t84, true
  br i1 %t86, label %bb20, label %bb21
bb20:
  br label %bb26
bb21:
  br label %bb22
bb22:
  %t88 = load ptr, ptr %l12, !tbaa !29
  %t89 = load i64, ptr %l13, !tbaa !24
  %t92 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s2, ptr %t88, i64 %t89)
  store i64 %t92, ptr %l96
  br label %bb23
bb23:
  %t93 = load i64, ptr %l96, !tbaa !24
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t96 = getelementptr %"compiler/scope:Scoper", ptr %t94, i32 0, i32 15
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t96, i64 %t93)
  br label %bb24
bb24:
  br label %bb25
bb25:
  %t100 = load i64, ptr %l13, !tbaa !24
  %t103 = add i64 %t100, 1
  store i64 %t103, ptr %l13, !tbaa !24
  br label %bb18
bb26:
  %t105 = getelementptr %"compiler/scope:walked", ptr %l11, i32 0, i32 1
  store ptr %t105, ptr %l15, !tbaa !29
  store i64 0, ptr %l16, !tbaa !24
  br label %bb27
bb27:
  %t107 = load i64, ptr %l16, !tbaa !24
  store i64 %t107, ptr %l104, !tbaa !24
  %t108 = load ptr, ptr %l15, !tbaa !29
  %t110 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %s2, ptr %t108)
  store i64 %t110, ptr %l106
  br label %bb28
bb28:
  %t111 = load i64, ptr %l104, !tbaa !24
  %t112 = load i64, ptr %l106, !tbaa !24
  %t113 = icmp slt i64 %t111, %t112
  %t115 = xor i1 %t113, true
  br i1 %t115, label %bb29, label %bb30
bb29:
  br label %bb39
bb30:
  br label %bb31
bb31:
  %t117 = load ptr, ptr %l15, !tbaa !29
  %t118 = load i64, ptr %l16, !tbaa !24
  %t121 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %s2, ptr %t117, i64 %t118)
  store i32 %t121, ptr %l111
  br label %bb32
bb32:
  %t122 = load i32, ptr %l111, !tbaa !23
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t127 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2edtorBody(ptr %v0, ptr %t123, i32 %t122)
  store i64 %t127, ptr %l114
  br label %bb33
bb33:
  %t128 = load i64, ptr %l114, !tbaa !24
  store i64 %t128, ptr %l18, !tbaa !24
  %t129 = load i64, ptr %l18, !tbaa !24
  %t131 = icmp sge i64 %t129, 0
  br i1 %t131, label %bb34, label %bb35
bb34:
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t135 = getelementptr %"compiler/scope:Scoper", ptr %t133, i32 0, i32 15
  %t136 = load i64, ptr %l18, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t135, i64 %t136)
  br label %bb36
bb35:
  br label %bb37
bb36:
  br label %bb37
bb37:
  br label %bb38
bb38:
  %t139 = load i64, ptr %l16, !tbaa !24
  %t142 = add i64 %t139, 1
  store i64 %t142, ptr %l16, !tbaa !24
  br label %bb27
bb39:
  store i64 0, ptr %l19, !tbaa !24
  %t144 = getelementptr %"compiler/scope:walked", ptr %l11, i32 0, i32 13
  %t146 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t144)
  store i64 %t146, ptr %l124
  br label %bb40
bb40:
  %t147 = load i64, ptr %l124, !tbaa !24
  store i64 %t147, ptr %l20, !tbaa !24
  store i64 1, ptr %l21, !tbaa !24
  %t148 = load i64, ptr %l20, !tbaa !24
  %t149 = load i64, ptr %l19, !tbaa !24
  %t152 = icmp sgt i64 %t148, %t149
  br i1 %t152, label %bb41, label %bb42
bb41:
  %t154 = load i64, ptr %l21, !tbaa !24
  %t156 = icmp sgt i64 %t154, 0
  br i1 %t156, label %bb43, label %bb44
bb42:
  store i64 0, ptr %l128, !tbaa !24
  br label %bb46
bb43:
  %t158 = load i64, ptr %l20, !tbaa !24
  %t159 = load i64, ptr %l19, !tbaa !24
  %t162 = sub i64 %t158, %t159
  %t163 = load i64, ptr %l21, !tbaa !24
  %t166 = add i64 %t162, %t163
  %t168 = sub i64 %t166, 1
  %t169 = load i64, ptr %l21, !tbaa !24
  %t172 = sdiv i64 %t168, %t169
  store i64 %t172, ptr %l131, !tbaa !24
  br label %bb45
bb44:
  store i64 0, ptr %l131, !tbaa !24
  br label %bb45
bb45:
  %t174 = load i64, ptr %l131, !tbaa !24
  store i64 %t174, ptr %l128, !tbaa !24
  br label %bb46
bb46:
  %t175 = load i64, ptr %l128, !tbaa !24
  store i64 %t175, ptr %l22, !tbaa !24
  store i64 0, ptr %l23, !tbaa !24
  br label %bb47
bb47:
  %t176 = load i64, ptr %l23, !tbaa !24
  %t177 = load i64, ptr %l22, !tbaa !24
  %t180 = icmp slt i64 %t176, %t177
  %t182 = xor i1 %t180, true
  br i1 %t182, label %bb48, label %bb49
bb48:
  br label %bb55
bb49:
  br label %bb50
bb50:
  %t184 = load i64, ptr %l19, !tbaa !24
  %t185 = load i64, ptr %l23, !tbaa !24
  %t186 = load i64, ptr %l21, !tbaa !24
  %t189 = mul i64 %t185, %t186
  %t192 = add i64 %t184, %t189
  store i64 %t192, ptr %l24, !tbaa !24
  %t194 = load ptr, ptr %l0, !tbaa !29
  %t196 = getelementptr %"compiler/scope:Scoper", ptr %t194, i32 0, i32 264
  store ptr %t196, ptr %l150, !tbaa !29
  %t197 = getelementptr %"compiler/scope:walked", ptr %l11, i32 0, i32 13
  %t198 = load i64, ptr %l24, !tbaa !24
  %t201 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t197, i64 %t198)
  store i64 %t201, ptr %l153
  br label %bb51
bb51:
  %t202 = getelementptr %"compiler/scope:walked", ptr %l11, i32 0, i32 14
  %t203 = load i64, ptr %l24, !tbaa !24
  %t206 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3ccompiler_2ftyped_3aCapture_26__H177492c3cd3f7b9ef9bf3a7d88bd5491(ptr %v0, ptr %v0, ptr %t202, i64 %t203)
  store { i64, ptr } %t206, ptr %l156
  br label %bb52
bb52:
  %t207 = load ptr, ptr %l150, !tbaa !29
  %t208 = load i64, ptr %l153, !tbaa !24
  %t209 = load { i64, ptr }, ptr %l156, !tbaa !27
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Array_3ccompiler_2ftyped_3aCa_H075f4750b9fbd2a4764c573a9763e3f6(ptr %v0, ptr %v0, ptr %t207, i64 %t208, { i64, ptr } %t209)
  br label %bb53
bb53:
  br label %bb54
bb54:
  %t210 = load i64, ptr %l23, !tbaa !24
  %t213 = add i64 %t210, 1
  store i64 %t213, ptr %l23, !tbaa !24
  br label %bb47
bb55:
  %t215 = getelementptr %"compiler/scope:walked", ptr %l11, i32 0, i32 8
  store ptr %t215, ptr %l25, !tbaa !29
  store i64 0, ptr %l26, !tbaa !24
  br label %bb56
bb56:
  %t217 = load i64, ptr %l26, !tbaa !24
  store i64 %t217, ptr %l161, !tbaa !24
  %t218 = load ptr, ptr %l25, !tbaa !29
  %t220 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t218)
  store i64 %t220, ptr %l163
  br label %bb57
bb57:
  %t221 = load i64, ptr %l161, !tbaa !24
  %t222 = load i64, ptr %l163, !tbaa !24
  %t223 = icmp slt i64 %t221, %t222
  %t225 = xor i1 %t223, true
  br i1 %t225, label %bb58, label %bb59
bb58:
  br label %bb66
bb59:
  br label %bb60
bb60:
  %t227 = load ptr, ptr %l25, !tbaa !29
  %t228 = load i64, ptr %l26, !tbaa !24
  %t231 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t227, i64 %t228)
  store ptr %t231, ptr %l168
  br label %bb61
bb61:
  %t232 = load ptr, ptr %l168, !tbaa !29
  store ptr %t232, ptr %l27, !tbaa !29
  %t233 = load i64, ptr %l10, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l2, i64 %t233)
  br label %bb62
bb62:
  store ptr %l3, ptr %l171, !tbaa !29
  %t236 = load ptr, ptr %l27, !tbaa !29
  %t238 = call i64 @compiler_2ftyped_2eCalledBody(ptr %v0, ptr %t236)
  store i64 %t238, ptr %l173
  br label %bb63
bb63:
  %t239 = load ptr, ptr %l171, !tbaa !29
  %t240 = load i64, ptr %l173, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %t239, i64 %t240)
  br label %bb64
bb64:
  br label %bb65
bb65:
  %t241 = load i64, ptr %l26, !tbaa !24
  %t244 = add i64 %t241, 1
  store i64 %t244, ptr %l26, !tbaa !24
  br label %bb56
bb66:
  %t246 = getelementptr %"compiler/scope:walked", ptr %l11, i32 0, i32 8
  %t248 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t246)
  store i64 %t248, ptr %l178
  br label %bb67
bb67:
  %t249 = load i64, ptr %l178, !tbaa !24
  %t250 = icmp sgt i64 %t249, 0
  br i1 %t250, label %bb68, label %bb69
bb68:
  store %olang.scope zeroinitializer, ptr %s16
  %t252 = load ptr, ptr %l0, !tbaa !29
  %t254 = getelementptr %"compiler/scope:Scoper", ptr %t252, i32 0, i32 33
  store ptr %t254, ptr %l181, !tbaa !29
  %t255 = load i64, ptr %l10, !tbaa !24
  store i64 %t255, ptr %l182, !tbaa !24
  %t256 = getelementptr %"compiler/scope:walked", ptr %l11, i32 0, i32 9
  %t258 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2eToArra_Hf068248a0eebef25a501bc77775c8cbf(ptr %v0, ptr %s16, ptr %t256)
  store { i64, ptr } %t258, ptr %l184
  br label %bb70
bb69:
  br label %bb72
bb70:
  %t259 = load { i64, ptr }, ptr %l184, !tbaa !27
  %t260 = load ptr, ptr %l181, !tbaa !29
  %t261 = load i64, ptr %l182, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Array_3ccompiler_2ftyped_3aBl_H2003e1165b947ef2f9b081fd0aeb277d(ptr %v0, ptr %t260, i64 %t261, { i64, ptr } %t259)
  br label %bb71
bb71:
  call void @__olang_scope_close(ptr %s16)
  br label %bb72
bb72:
  %t263 = getelementptr %"compiler/scope:walked", ptr %l11, i32 0, i32 8
  store ptr %t263, ptr %l28, !tbaa !29
  store i64 0, ptr %l29, !tbaa !24
  br label %bb73
bb73:
  %t265 = load i64, ptr %l29, !tbaa !24
  store i64 %t265, ptr %l187, !tbaa !24
  %t266 = load ptr, ptr %l28, !tbaa !29
  %t268 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t266)
  store i64 %t268, ptr %l189
  br label %bb74
bb74:
  %t269 = load i64, ptr %l187, !tbaa !24
  %t270 = load i64, ptr %l189, !tbaa !24
  %t271 = icmp slt i64 %t269, %t270
  %t273 = xor i1 %t271, true
  br i1 %t273, label %bb75, label %bb76
bb75:
  br label %bb83
bb76:
  br label %bb77
bb77:
  %t275 = load ptr, ptr %l28, !tbaa !29
  %t276 = load i64, ptr %l29, !tbaa !24
  %t279 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t275, i64 %t276)
  store ptr %t279, ptr %l194
  br label %bb78
bb78:
  %t280 = load ptr, ptr %l194, !tbaa !29
  store ptr %t280, ptr %l30, !tbaa !29
  %t281 = load ptr, ptr %l0, !tbaa !29
  %t283 = getelementptr %"compiler/scope:Scoper", ptr %t281, i32 0, i32 78
  %t284 = load i64, ptr %l10, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t283, i64 %t284, i1 true)
  br label %bb79
bb79:
  %t287 = load ptr, ptr %l0, !tbaa !29
  %t289 = getelementptr %"compiler/scope:Scoper", ptr %t287, i32 0, i32 78
  store ptr %t289, ptr %l199, !tbaa !29
  %t290 = load ptr, ptr %l30, !tbaa !29
  %t292 = call i64 @compiler_2ftyped_2eCalledBody(ptr %v0, ptr %t290)
  store i64 %t292, ptr %l201
  br label %bb80
bb80:
  %t293 = load ptr, ptr %l199, !tbaa !29
  %t294 = load i64, ptr %l201, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t293, i64 %t294, i1 true)
  br label %bb81
bb81:
  br label %bb82
bb82:
  %t295 = load i64, ptr %l29, !tbaa !24
  %t298 = add i64 %t295, 1
  store i64 %t298, ptr %l29, !tbaa !24
  br label %bb73
bb83:
  %t300 = getelementptr %"compiler/scope:walked", ptr %l11, i32 0, i32 8
  %t302 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t300)
  store i64 %t302, ptr %l206
  br label %bb84
bb84:
  %t303 = load i64, ptr %l206, !tbaa !24
  %t304 = icmp sgt i64 %t303, 0
  br i1 %t304, label %bb85, label %bb86
bb85:
  %t306 = load ptr, ptr %l0, !tbaa !29
  %t307 = load i64, ptr %l10, !tbaa !24
  %t311 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2etailNeeds(ptr %v0, ptr %s2, ptr %t306, i64 %t307, ptr %l11)
  store i1 %t311, ptr %l212
  br label %bb87
bb86:
  store i1 false, ptr %l208, !tbaa !21
  br label %bb88
bb87:
  %t312 = load i1, ptr %l212, !tbaa !21
  store i1 %t312, ptr %l208, !tbaa !21
  br label %bb88
bb88:
  %t313 = load i1, ptr %l208, !tbaa !21
  br i1 %t313, label %bb89, label %bb90
bb89:
  %t314 = load i64, ptr %l10, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l4, i64 %t314)
  br label %bb91
bb90:
  br label %bb92
bb91:
  br label %bb92
bb92:
  %t317 = load ptr, ptr %l0, !tbaa !29
  %t319 = getelementptr %"compiler/scope:Scoper", ptr %t317, i32 0, i32 17
  store ptr %t319, ptr %l216, !tbaa !29
  %t320 = load ptr, ptr %l0, !tbaa !29
  %t322 = getelementptr %"compiler/scope:Scoper", ptr %t320, i32 0, i32 18
  %t324 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t322)
  store i64 %t324, ptr %l219
  br label %bb93
bb93:
  %t325 = load ptr, ptr %l216, !tbaa !29
  %t326 = load i64, ptr %l219, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t325, i64 %t326)
  br label %bb94
bb94:
  %t327 = getelementptr %"compiler/scope:walked", ptr %l11, i32 0, i32 2
  store ptr %t327, ptr %l31, !tbaa !29
  store i64 0, ptr %l32, !tbaa !24
  br label %bb95
bb95:
  %t329 = load i64, ptr %l32, !tbaa !24
  store i64 %t329, ptr %l221, !tbaa !24
  %t330 = load ptr, ptr %l31, !tbaa !29
  %t332 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s2, ptr %t330)
  store i64 %t332, ptr %l223
  br label %bb96
bb96:
  %t333 = load i64, ptr %l221, !tbaa !24
  %t334 = load i64, ptr %l223, !tbaa !24
  %t335 = icmp slt i64 %t333, %t334
  %t337 = xor i1 %t335, true
  br i1 %t337, label %bb97, label %bb98
bb97:
  br label %bb103
bb98:
  br label %bb99
bb99:
  %t339 = load ptr, ptr %l31, !tbaa !29
  %t340 = load i64, ptr %l32, !tbaa !24
  %t343 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s2, ptr %t339, i64 %t340)
  store i64 %t343, ptr %l228
  br label %bb100
bb100:
  %t344 = load i64, ptr %l228, !tbaa !24
  %t345 = load ptr, ptr %l0, !tbaa !29
  %t347 = getelementptr %"compiler/scope:Scoper", ptr %t345, i32 0, i32 18
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t347, i64 %t344)
  br label %bb101
bb101:
  br label %bb102
bb102:
  %t351 = load i64, ptr %l32, !tbaa !24
  %t354 = add i64 %t351, 1
  store i64 %t354, ptr %l32, !tbaa !24
  br label %bb95
bb103:
  %t356 = load ptr, ptr %l0, !tbaa !29
  %t358 = getelementptr %"compiler/scope:Scoper", ptr %t356, i32 0, i32 19
  store ptr %t358, ptr %l236, !tbaa !29
  %t359 = load ptr, ptr %l0, !tbaa !29
  %t361 = getelementptr %"compiler/scope:Scoper", ptr %t359, i32 0, i32 20
  %t363 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t361)
  store i64 %t363, ptr %l239
  br label %bb104
bb104:
  %t364 = load ptr, ptr %l236, !tbaa !29
  %t365 = load i64, ptr %l239, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t364, i64 %t365)
  br label %bb105
bb105:
  %t366 = getelementptr %"compiler/scope:walked", ptr %l11, i32 0, i32 3
  store ptr %t366, ptr %l34, !tbaa !29
  store i64 0, ptr %l35, !tbaa !24
  br label %bb106
bb106:
  %t368 = load i64, ptr %l35, !tbaa !24
  store i64 %t368, ptr %l241, !tbaa !24
  %t369 = load ptr, ptr %l34, !tbaa !29
  %t371 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s2, ptr %t369)
  store i64 %t371, ptr %l243
  br label %bb107
bb107:
  %t372 = load i64, ptr %l241, !tbaa !24
  %t373 = load i64, ptr %l243, !tbaa !24
  %t374 = icmp slt i64 %t372, %t373
  %t376 = xor i1 %t374, true
  br i1 %t376, label %bb108, label %bb109
bb108:
  br label %bb114
bb109:
  br label %bb110
bb110:
  %t378 = load ptr, ptr %l34, !tbaa !29
  %t379 = load i64, ptr %l35, !tbaa !24
  %t382 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s2, ptr %t378, i64 %t379)
  store i64 %t382, ptr %l248
  br label %bb111
bb111:
  %t383 = load i64, ptr %l248, !tbaa !24
  %t384 = load ptr, ptr %l0, !tbaa !29
  %t386 = getelementptr %"compiler/scope:Scoper", ptr %t384, i32 0, i32 20
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t386, i64 %t383)
  br label %bb112
bb112:
  br label %bb113
bb113:
  %t390 = load i64, ptr %l35, !tbaa !24
  %t393 = add i64 %t390, 1
  store i64 %t393, ptr %l35, !tbaa !24
  br label %bb106
bb114:
  store i64 0, ptr %l37, !tbaa !24
  %t395 = getelementptr %"compiler/scope:walked", ptr %l11, i32 0, i32 6
  %t397 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t395)
  store i64 %t397, ptr %l256
  br label %bb115
bb115:
  %t398 = load i64, ptr %l256, !tbaa !24
  store i64 %t398, ptr %l38, !tbaa !24
  store i64 1, ptr %l39, !tbaa !24
  %t399 = load i64, ptr %l38, !tbaa !24
  %t400 = load i64, ptr %l37, !tbaa !24
  %t403 = icmp sgt i64 %t399, %t400
  br i1 %t403, label %bb116, label %bb117
bb116:
  %t405 = load i64, ptr %l39, !tbaa !24
  %t407 = icmp sgt i64 %t405, 0
  br i1 %t407, label %bb118, label %bb119
bb117:
  store i64 0, ptr %l260, !tbaa !24
  br label %bb121
bb118:
  %t409 = load i64, ptr %l38, !tbaa !24
  %t410 = load i64, ptr %l37, !tbaa !24
  %t413 = sub i64 %t409, %t410
  %t414 = load i64, ptr %l39, !tbaa !24
  %t417 = add i64 %t413, %t414
  %t419 = sub i64 %t417, 1
  %t420 = load i64, ptr %l39, !tbaa !24
  %t423 = sdiv i64 %t419, %t420
  store i64 %t423, ptr %l263, !tbaa !24
  br label %bb120
bb119:
  store i64 0, ptr %l263, !tbaa !24
  br label %bb120
bb120:
  %t425 = load i64, ptr %l263, !tbaa !24
  store i64 %t425, ptr %l260, !tbaa !24
  br label %bb121
bb121:
  %t426 = load i64, ptr %l260, !tbaa !24
  store i64 %t426, ptr %l40, !tbaa !24
  store i64 0, ptr %l41, !tbaa !24
  br label %bb122
bb122:
  store %olang.scope zeroinitializer, ptr %s28
  %t427 = load i64, ptr %l41, !tbaa !24
  %t428 = load i64, ptr %l40, !tbaa !24
  %t431 = icmp slt i64 %t427, %t428
  %t433 = xor i1 %t431, true
  br i1 %t433, label %bb123, label %bb124
bb123:
  call void @__olang_scope_close(ptr %s28)
  br label %bb132
bb124:
  br label %bb125
bb125:
  %t435 = load i64, ptr %l37, !tbaa !24
  %t436 = load i64, ptr %l41, !tbaa !24
  %t437 = load i64, ptr %l39, !tbaa !24
  %t440 = mul i64 %t436, %t437
  %t443 = add i64 %t435, %t440
  store i64 %t443, ptr %l42, !tbaa !24
  %t445 = load ptr, ptr %l0, !tbaa !29
  %t447 = getelementptr %"compiler/scope:Scoper", ptr %t445, i32 0, i32 57
  store ptr %t447, ptr %l282, !tbaa !29
  %t448 = load ptr, ptr %l0, !tbaa !29
  %t450 = getelementptr %"compiler/scope:Scoper", ptr %t448, i32 0, i32 0
  %t451 = load ptr, ptr %t450, !tbaa !29
  %t453 = getelementptr %"compiler/generic:Program", ptr %t451, i32 0, i32 2
  store ptr %t453, ptr %l285, !tbaa !29
  %t454 = getelementptr %"compiler/scope:walked", ptr %l11, i32 0, i32 6
  %t455 = load i64, ptr %l42, !tbaa !24
  %t458 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t454, i64 %t455)
  store i32 %t458, ptr %l288
  br label %bb126
bb126:
  %t459 = load ptr, ptr %l285, !tbaa !29
  %t460 = load i32, ptr %l288, !tbaa !23
  %t461 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t459, i32 %t460)
  store i32 %t461, ptr %l289
  br label %bb127
bb127:
  %t462 = load i32, ptr %l289, !tbaa !23
  %t463 = sext i32 %t462 to i64
  store i64 %t463, ptr %l290, !tbaa !24
  %t464 = getelementptr %"compiler/scope:walked", ptr %l11, i32 0, i32 7
  %t465 = load i64, ptr %l42, !tbaa !24
  %t468 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t464, i64 %t465)
  store i64 %t468, ptr %l293
  br label %bb128
bb128:
  %t469 = load i64, ptr %l290, !tbaa !24
  %t470 = load i64, ptr %l293, !tbaa !24
  %t471 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s28, i64 %t469, i64 %t470)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t471, ptr %l294
  br label %bb129
bb129:
  %t472 = load ptr, ptr %l282, !tbaa !29
  %t473 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l294
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1308596c866d4be061d9da9113abde88(ptr %v0, ptr %t472, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t473, i1 true)
  br label %bb130
bb130:
  call void @__olang_scope_close(ptr %s28)
  br label %bb131
bb131:
  %t474 = load i64, ptr %l41, !tbaa !24
  %t477 = add i64 %t474, 1
  store i64 %t477, ptr %l41, !tbaa !24
  br label %bb122
bb132:
  %t479 = load ptr, ptr %l0, !tbaa !29
  %t481 = getelementptr %"compiler/scope:Scoper", ptr %t479, i32 0, i32 21
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t481, i64 -1)
  br label %bb133
bb133:
  %t483 = load ptr, ptr %l0, !tbaa !29
  %t485 = getelementptr %"compiler/scope:Scoper", ptr %t483, i32 0, i32 22
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t485, i64 0)
  br label %bb134
bb134:
  %t487 = load ptr, ptr %l0, !tbaa !29
  %t489 = getelementptr %"compiler/scope:Scoper", ptr %t487, i32 0, i32 23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t489, i1 false)
  br label %bb135
bb135:
  call void @__olang_scope_close(ptr %s2)
  br label %bb136
bb136:
  %t491 = load i64, ptr %l9, !tbaa !24
  %t494 = add i64 %t491, 1
  store i64 %t494, ptr %l9, !tbaa !24
  br label %bb11
bb137:
  %t496 = load ptr, ptr %l0, !tbaa !29
  %t498 = getelementptr %"compiler/scope:Scoper", ptr %t496, i32 0, i32 14
  store ptr %t498, ptr %l308, !tbaa !29
  %t499 = load ptr, ptr %l0, !tbaa !29
  %t501 = getelementptr %"compiler/scope:Scoper", ptr %t499, i32 0, i32 15
  %t503 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t501)
  store i64 %t503, ptr %l311
  br label %bb138
bb138:
  %t504 = load ptr, ptr %l308, !tbaa !29
  %t505 = load i64, ptr %l311, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t504, i64 %t505)
  br label %bb139
bb139:
  %t506 = load ptr, ptr %l0, !tbaa !29
  %t508 = getelementptr %"compiler/scope:Scoper", ptr %t506, i32 0, i32 17
  store ptr %t508, ptr %l313, !tbaa !29
  %t509 = load ptr, ptr %l0, !tbaa !29
  %t511 = getelementptr %"compiler/scope:Scoper", ptr %t509, i32 0, i32 18
  %t513 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t511)
  store i64 %t513, ptr %l316
  br label %bb140
bb140:
  %t514 = load ptr, ptr %l313, !tbaa !29
  %t515 = load i64, ptr %l316, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t514, i64 %t515)
  br label %bb141
bb141:
  %t516 = load ptr, ptr %l0, !tbaa !29
  %t518 = getelementptr %"compiler/scope:Scoper", ptr %t516, i32 0, i32 19
  store ptr %t518, ptr %l318, !tbaa !29
  %t519 = load ptr, ptr %l0, !tbaa !29
  %t521 = getelementptr %"compiler/scope:Scoper", ptr %t519, i32 0, i32 20
  %t523 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t521)
  store i64 %t523, ptr %l321
  br label %bb142
bb142:
  %t524 = load ptr, ptr %l318, !tbaa !29
  %t525 = load i64, ptr %l321, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t524, i64 %t525)
  br label %bb143
bb143:
  %t527 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l4)
  store i64 %t527, ptr %l323
  br label %bb144
bb144:
  %t528 = load i64, ptr %l323, !tbaa !24
  %t529 = icmp sgt i64 %t528, 0
  br i1 %t529, label %bb145, label %bb146
bb145:
  %t531 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2egiveTails(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %t531, ptr %l2, ptr %l3, ptr %l4)
  br label %bb147
bb146:
  br label %bb148
bb147:
  br label %bb148
bb148:
  store i64 0, ptr %l43, !tbaa !24
  %t536 = load i64, ptr %l1, !tbaa !24
  store i64 %t536, ptr %l44, !tbaa !24
  store i64 1, ptr %l45, !tbaa !24
  %t538 = load i64, ptr %l44, !tbaa !24
  %t539 = load i64, ptr %l43, !tbaa !24
  %t542 = icmp sgt i64 %t538, %t539
  br i1 %t542, label %bb149, label %bb150
bb149:
  %t544 = load i64, ptr %l45, !tbaa !24
  %t546 = icmp sgt i64 %t544, 0
  br i1 %t546, label %bb151, label %bb152
bb150:
  store i64 0, ptr %l333, !tbaa !24
  br label %bb154
bb151:
  %t548 = load i64, ptr %l44, !tbaa !24
  %t549 = load i64, ptr %l43, !tbaa !24
  %t552 = sub i64 %t548, %t549
  %t553 = load i64, ptr %l45, !tbaa !24
  %t556 = add i64 %t552, %t553
  %t558 = sub i64 %t556, 1
  %t559 = load i64, ptr %l45, !tbaa !24
  %t562 = sdiv i64 %t558, %t559
  store i64 %t562, ptr %l336, !tbaa !24
  br label %bb153
bb152:
  store i64 0, ptr %l336, !tbaa !24
  br label %bb153
bb153:
  %t564 = load i64, ptr %l336, !tbaa !24
  store i64 %t564, ptr %l333, !tbaa !24
  br label %bb154
bb154:
  %t565 = load i64, ptr %l333, !tbaa !24
  store i64 %t565, ptr %l46, !tbaa !24
  store i64 0, ptr %l47, !tbaa !24
  br label %bb155
bb155:
  %t566 = load i64, ptr %l47, !tbaa !24
  %t567 = load i64, ptr %l46, !tbaa !24
  %t570 = icmp slt i64 %t566, %t567
  %t572 = xor i1 %t570, true
  br i1 %t572, label %bb156, label %bb157
bb156:
  br label %bb165
bb157:
  br label %bb158
bb158:
  %t574 = load i64, ptr %l43, !tbaa !24
  %t575 = load i64, ptr %l47, !tbaa !24
  %t576 = load i64, ptr %l45, !tbaa !24
  %t579 = mul i64 %t575, %t576
  %t582 = add i64 %t574, %t579
  store i64 %t582, ptr %l48, !tbaa !24
  %t584 = load ptr, ptr %l0, !tbaa !29
  %t586 = getelementptr %"compiler/scope:Scoper", ptr %t584, i32 0, i32 21
  %t587 = load i64, ptr %l48, !tbaa !24
  %t590 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t586, i64 %t587)
  store i64 %t590, ptr %l357
  br label %bb159
bb159:
  %t591 = load i64, ptr %l357, !tbaa !24
  %t592 = icmp slt i64 %t591, 0
  br i1 %t592, label %bb160, label %bb161
bb160:
  %t594 = load ptr, ptr %l0, !tbaa !29
  %t595 = load i64, ptr %l48, !tbaa !24
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2evisit(ptr %v0, ptr %t594, i64 %t595)
  br label %bb162
bb161:
  br label %bb163
bb162:
  br label %bb163
bb163:
  br label %bb164
bb164:
  %t598 = load i64, ptr %l47, !tbaa !24
  %t601 = add i64 %t598, 1
  store i64 %t601, ptr %l47, !tbaa !24
  br label %bb155
bb165:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2edecide(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, ptr %a2, { i64, ptr } %a3, i64 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca %"compiler/typed:Local"
  %l7 = alloca i1
  %l8 = alloca { i64, [2 x i64] }
  %l9 = alloca { i64, [1 x i64] }
  %l10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l28 = alloca %"compiler/typed:Local"
  %l38 = alloca i1
  %l44 = alloca i1
  %l45 = alloca i1
  %l48 = alloca i1
  %l52 = alloca i1
  %l55 = alloca { i64, [2 x i64] }
  %l57 = alloca i1
  %l58 = alloca i1
  %l61 = alloca i1
  %l62 = alloca i1
  %l64 = alloca i1
  %l66 = alloca { i64, [2 x i64] }
  %l68 = alloca i1
  %l69 = alloca i1
  %l71 = alloca i1
  %l84 = alloca i1
  %l85 = alloca i1
  %l90 = alloca i1
  %l91 = alloca i1
  %l94 = alloca i1
  %l100 = alloca i1
  %l102 = alloca { i64, ptr }
  %l104 = alloca i64
  %l110 = alloca i1
  %l111 = alloca ptr
  %l116 = alloca i1
  %l117 = alloca i1
  %l122 = alloca i1
  %l126 = alloca i1
  %l135 = alloca ptr
  %l141 = alloca ptr
  %l145 = alloca ptr
  %l151 = alloca i64
  %l152 = alloca ptr
  %l156 = alloca i1
  %l157 = alloca ptr
  %l158 = alloca ptr
  %l162 = alloca i32
  %l163 = alloca i64
  %l164 = alloca ptr
  %l167 = alloca i1
  %l168 = alloca ptr
  %l169 = alloca ptr
  %l173 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l176 = alloca i1
  %l179 = alloca i1
  %l182 = alloca i1
  %l187 = alloca i1
  %l190 = alloca ptr
  %l191 = alloca ptr
  %l195 = alloca i32
  %l196 = alloca i64
  %l199 = alloca ptr
  %l200 = alloca ptr
  %l204 = alloca i32
  %l205 = alloca i64
  %l211 = alloca i1
  %l213 = alloca i1
  %l216 = alloca i1
  %l218 = alloca i1
  %l222 = alloca i1
  %s0 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %t2 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store ptr %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  store i64 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store { i64, [2 x i64] } zeroinitializer, ptr %t2
  %t3 = getelementptr { i64, [2 x i64] }, ptr %t2, i32 0, i32 0
  store i64 0, ptr %t3
  %t4 = load { i64, [2 x i64] }, ptr %t2
  %t7 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 137
  store { i64, [2 x i64] } %t4, ptr %t7
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/scope:Scoper", ptr %t8, i32 0, i32 138
  store i1 false, ptr %t10, !tbaa !21
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/scope:Scoper", ptr %t11, i32 0, i32 139
  store i1 false, ptr %t13, !tbaa !21
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/scope:Scoper", ptr %t14, i32 0, i32 142
  store i1 false, ptr %t16, !tbaa !21
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/scope:Scoper", ptr %t17, i32 0, i32 28
  %t20 = load ptr, ptr %t19, !tbaa !29
  %t22 = icmp eq ptr %t20, null
  br i1 %t22, label %bb1, label %bb2
bb1:
  call void @__olang_check_failed(ptr @olang_loc_be4231f99dfc50a7_6a00356b78c435db)
  unreachable
bb2:
  br label %bb3
bb3:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/scope:Scoper", ptr %t24, i32 0, i32 28
  %t27 = load ptr, ptr %t26, !tbaa !29
  %t30 = getelementptr %"compiler/typed:Body", ptr %t27, i32 0, i32 7
  %t31 = load i32, ptr %l1, !tbaa !23
  %t33 = sext i32 %t31 to i64
  %t36 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t30, i64 %t33)
  store %"compiler/typed:Local" %t36, ptr %l28
  br label %bb4
bb4:
  %t37 = load %"compiler/typed:Local", ptr %l28
  store %"compiler/typed:Local" %t37, ptr %l5
  %t38 = getelementptr %"compiler/typed:Local", ptr %l5, i32 0, i32 4
  %t39 = load i32, ptr %t38, !range !{i32 0, i32 7}
  %t41 = trunc i64 2 to i32
  %t42 = icmp eq i32 %t39, %t41
  br i1 %t42, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb6:
  br label %bb7
bb7:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/scope:Scoper", ptr %t44, i32 0, i32 28
  %t47 = load ptr, ptr %t46, !tbaa !29
  %t49 = icmp eq ptr %t47, null
  br i1 %t49, label %bb8, label %bb9
bb8:
  call void @__olang_check_failed(ptr @olang_loc_badc8ccdfeb92288_a041b08d3fc96aec)
  unreachable
bb9:
  br label %bb10
bb10:
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = getelementptr %"compiler/scope:Scoper", ptr %t51, i32 0, i32 28
  %t54 = load ptr, ptr %t53, !tbaa !29
  %t57 = getelementptr %"compiler/typed:Body", ptr %t54, i32 0, i32 1
  %t58 = load { i64, [2 x i64] }, ptr %t57
  %t62 = extractvalue { i64, [2 x i64] } %t58, 0
  %t63 = icmp eq i64 %t62, 1
  br i1 %t63, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb14
bb13:
  store i1 true, ptr %l38, !tbaa !21
  br label %bb19
bb14:
  br i1 true, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb18
bb17:
  store i1 false, ptr %l38, !tbaa !21
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_58d2ded8d237a84_721cf65762561fa8)
  unreachable
bb19:
  %t65 = load i1, ptr %l38, !tbaa !21
  store i1 %t65, ptr %l7, !tbaa !21
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t67 = load %"compiler/typed:Local", ptr %l5
  %t68 = load ptr, ptr %l2, !tbaa !29
  %t72 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2equalifiesMove(ptr %v0, ptr %v1, ptr %t66, %"compiler/typed:Local" %t67, ptr %t68)
  store i1 %t72, ptr %l44
  br label %bb20
bb20:
  %t73 = load i1, ptr %l44, !tbaa !21
  br i1 %t73, label %bb21, label %bb22
bb21:
  %t74 = load i1, ptr %l7, !tbaa !21
  %t76 = xor i1 %t74, true
  store i1 %t76, ptr %l45, !tbaa !21
  br label %bb23
bb22:
  store i1 false, ptr %l45, !tbaa !21
  br label %bb23
bb23:
  %t78 = load i1, ptr %l45, !tbaa !21
  br i1 %t78, label %bb24, label %bb25
bb24:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t80 = load i32, ptr %l1, !tbaa !23
  %t82 = sext i32 %t80 to i64
  %t85 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eloopElement(ptr %v0, ptr %t79, i64 %t82)
  store i1 %t85, ptr %l52
  br label %bb26
bb25:
  store i1 false, ptr %l48, !tbaa !21
  br label %bb27
bb26:
  %t86 = load i1, ptr %l52, !tbaa !21
  %t87 = xor i1 %t86, true
  store i1 %t87, ptr %l48, !tbaa !21
  br label %bb27
bb27:
  %t89 = load i1, ptr %l48, !tbaa !21
  br i1 %t89, label %bb28, label %bb29
bb28:
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t92 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eresultTerm(ptr %v0, ptr %t90, i64 0)
  store { i64, [2 x i64] } %t92, ptr %l55
  br label %bb30
bb29:
  br label %bb76
bb30:
  %t93 = load { i64, [2 x i64] }, ptr %l55
  store { i64, [2 x i64] } %t93, ptr %l8
  %t94 = load { i64, [2 x i64] }, ptr %l8
  %t96 = call i1 @compiler_2fscope_2eisBlockTerm({ i64, [2 x i64] } %t94)
  store i1 %t96, ptr %l57
  br label %bb31
bb31:
  %t97 = load i1, ptr %l57, !tbaa !21
  br i1 %t97, label %bb32, label %bb33
bb32:
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t99 = getelementptr %"compiler/typed:Local", ptr %l5, i32 0, i32 2
  %t100 = load i32, ptr %t99, !tbaa !23
  %t103 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2earenaValue(ptr %v0, ptr %t98, i32 %t100)
  store i1 %t103, ptr %l61
  br label %bb34
bb33:
  store i1 false, ptr %l58, !tbaa !21
  br label %bb35
bb34:
  %t104 = load i1, ptr %l61, !tbaa !21
  store i1 %t104, ptr %l58, !tbaa !21
  br label %bb35
bb35:
  %t105 = load i1, ptr %l58, !tbaa !21
  br i1 %t105, label %bb36, label %bb37
bb36:
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t108 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ereturnsArray(ptr %v0, ptr %t106)
  store i1 %t108, ptr %l64
  br label %bb38
bb37:
  store i1 false, ptr %l62, !tbaa !21
  br label %bb39
bb38:
  %t109 = load i1, ptr %l64, !tbaa !21
  store i1 %t109, ptr %l62, !tbaa !21
  br label %bb39
bb39:
  %t110 = load i1, ptr %l62, !tbaa !21
  br i1 %t110, label %bb40, label %bb41
bb40:
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t113 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2estorageTerm(ptr %v0, ptr %t111)
  store { i64, [2 x i64] } %t113, ptr %l66
  br label %bb42
bb41:
  br label %bb43
bb42:
  %t114 = load { i64, [2 x i64] }, ptr %l66
  store { i64, [2 x i64] } %t114, ptr %l8
  br label %bb43
bb43:
  %t115 = load { i64, [2 x i64] }, ptr %l8
  %t117 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aTerm_2eRuns({ i64, [2 x i64] } %t115)
  store i1 %t117, ptr %l68
  br label %bb44
bb44:
  %t118 = load i1, ptr %l68, !tbaa !21
  br i1 %t118, label %bb45, label %bb46
bb45:
  %t119 = load { i64, [2 x i64] }, ptr %l8
  %t121 = call i1 @compiler_2fscope_2eisBlockTerm({ i64, [2 x i64] } %t119)
  store i1 %t121, ptr %l71
  br label %bb47
bb46:
  store i1 false, ptr %l69, !tbaa !21
  br label %bb48
bb47:
  %t122 = load i1, ptr %l71, !tbaa !21
  %t123 = xor i1 %t122, true
  store i1 %t123, ptr %l69, !tbaa !21
  br label %bb48
bb48:
  %t125 = load i1, ptr %l69, !tbaa !21
  br i1 %t125, label %bb49, label %bb50
bb49:
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t127 = load i32, ptr %l1, !tbaa !23
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eflowStart(ptr %v0, ptr %t126, i32 %t127, i64 0)
  br label %bb51
bb50:
  br label %bb75
bb51:
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t132 = getelementptr %"compiler/scope:Scoper", ptr %t130, i32 0, i32 155
  store i1 false, ptr %t132, !tbaa !21
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t134 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t135 = load i64, ptr %l4, !tbaa !24
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eflowRun(ptr %v0, ptr %v2, ptr %t133, { i64, ptr } %t134, i64 %t135)
  br label %bb52
bb52:
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t141 = getelementptr %"compiler/scope:Scoper", ptr %t139, i32 0, i32 155
  store i1 true, ptr %t141, !tbaa !21
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t144 = getelementptr %"compiler/scope:Scoper", ptr %t142, i32 0, i32 147
  %t145 = load i32, ptr %l1, !tbaa !23
  %t147 = sext i32 %t145 to i64
  %t150 = call i1 @compiler_2fscope_2eflHas(ptr %v0, ptr %t144, i64 %t147)
  store i1 %t150, ptr %l84
  br label %bb53
bb53:
  %t151 = load i1, ptr %l84, !tbaa !21
  br i1 %t151, label %bb54, label %bb55
bb54:
  store i1 true, ptr %l85, !tbaa !21
  br label %bb61
bb55:
  %t152 = load ptr, ptr %l0, !tbaa !29
  %t154 = getelementptr %"compiler/scope:Scoper", ptr %t152, i32 0, i32 146
  %t155 = load i32, ptr %l1, !tbaa !23
  %t157 = sext i32 %t155 to i64
  %t160 = call i1 @compiler_2fscope_2eflHas(ptr %v0, ptr %t154, i64 %t157)
  store i1 %t160, ptr %l90
  br label %bb56
bb56:
  %t161 = load i1, ptr %l90, !tbaa !21
  br i1 %t161, label %bb57, label %bb58
bb57:
  %t162 = load ptr, ptr %l0, !tbaa !29
  %t163 = load ptr, ptr %l2, !tbaa !29
  %t166 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2etiedToBlock(ptr %v0, ptr %v1, ptr %t162, ptr %t163)
  store i1 %t166, ptr %l94
  br label %bb59
bb58:
  store i1 false, ptr %l91, !tbaa !21
  br label %bb60
bb59:
  %t167 = load i1, ptr %l94, !tbaa !21
  %t168 = xor i1 %t167, true
  store i1 %t168, ptr %l91, !tbaa !21
  br label %bb60
bb60:
  %t170 = load i1, ptr %l91, !tbaa !21
  store i1 %t170, ptr %l85, !tbaa !21
  br label %bb61
bb61:
  %t171 = load i1, ptr %l85, !tbaa !21
  br i1 %t171, label %bb62, label %bb63
bb62:
  %t172 = load ptr, ptr %l0, !tbaa !29
  %t173 = load { i64, [2 x i64] }, ptr %l8
  %t176 = getelementptr %"compiler/scope:Scoper", ptr %t172, i32 0, i32 137
  store { i64, [2 x i64] } %t173, ptr %t176
  %t177 = load ptr, ptr %l0, !tbaa !29
  %t178 = getelementptr %"compiler/typed:Local", ptr %l5, i32 0, i32 2
  %t179 = load i32, ptr %t178, !tbaa !23
  %t182 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2earenaValue(ptr %v0, ptr %t177, i32 %t179)
  store i1 %t182, ptr %l100
  br label %bb64
bb63:
  br label %bb74
bb64:
  %t183 = load i1, ptr %l100, !tbaa !21
  br i1 %t183, label %bb65, label %bb66
bb65:
  %t184 = load ptr, ptr %l0, !tbaa !29
  %t186 = getelementptr %"compiler/scope:Scoper", ptr %t184, i32 0, i32 35
  %t187 = getelementptr %"compiler/typed:Plan", ptr %t186, i32 0, i32 3
  %t188 = load { i64, ptr }, ptr %t187, !tbaa !27
  store { i64, ptr } %t188, ptr %l102, !tbaa !27
  %t189 = load i32, ptr %l1, !tbaa !23
  %t191 = sext i32 %t189 to i64
  store i64 %t191, ptr %l104, !tbaa !24
  %t192 = load ptr, ptr %l0, !tbaa !29
  %t193 = load i32, ptr %l1, !tbaa !23
  %t195 = sext i32 %t193 to i64
  %t196 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t197 = load i64, ptr %l4, !tbaa !24
  %t202 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esoleArray(ptr %v0, ptr %v2, ptr %t192, i64 %t195, { i64, ptr } %t196, i64 %t197)
  store i1 %t202, ptr %l110
  br label %bb67
bb66:
  br label %bb68
bb67:
  %t203 = load i1, ptr %l110, !tbaa !21
  %t204 = load i64, ptr %l104, !tbaa !24
  %t205 = getelementptr { i64, ptr }, ptr %l102, i32 0, i32 1
  %t206 = load ptr, ptr %t205, !tbaa !27
  %t207 = getelementptr i1, ptr %t206, i64 %t204
  store i1 %t203, ptr %t207, !tbaa !31
  br label %bb68
bb68:
  %t208 = load ptr, ptr %l0, !tbaa !29
  store ptr %t208, ptr %l111, !tbaa !29
  %t209 = load ptr, ptr %l0, !tbaa !29
  %t211 = getelementptr %"compiler/scope:Scoper", ptr %t209, i32 0, i32 147
  %t212 = load i32, ptr %l1, !tbaa !23
  %t214 = sext i32 %t212 to i64
  %t217 = call i1 @compiler_2fscope_2eflHas(ptr %v0, ptr %t211, i64 %t214)
  store i1 %t217, ptr %l116
  br label %bb69
bb69:
  %t218 = load i1, ptr %l116, !tbaa !21
  br i1 %t218, label %bb70, label %bb71
bb70:
  %t219 = load ptr, ptr %l0, !tbaa !29
  %t221 = getelementptr %"compiler/scope:Scoper", ptr %t219, i32 0, i32 148
  %t222 = load i32, ptr %l1, !tbaa !23
  %t224 = sext i32 %t222 to i64
  %t227 = call i1 @compiler_2fscope_2eflHas(ptr %v0, ptr %t221, i64 %t224)
  store i1 %t227, ptr %l122
  br label %bb72
bb71:
  store i1 false, ptr %l117, !tbaa !21
  br label %bb73
bb72:
  %t228 = load i1, ptr %l122, !tbaa !21
  %t229 = xor i1 %t228, true
  store i1 %t229, ptr %l117, !tbaa !21
  br label %bb73
bb73:
  %t231 = load i1, ptr %l117, !tbaa !21
  %t232 = load ptr, ptr %l111, !tbaa !29
  %t233 = getelementptr %"compiler/scope:Scoper", ptr %t232, i32 0, i32 138
  store i1 %t231, ptr %t233, !tbaa !21
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb74:
  br label %bb75
bb75:
  br label %bb76
bb76:
  %t234 = load ptr, ptr %l0, !tbaa !29
  %t235 = getelementptr %"compiler/typed:Local", ptr %l5, i32 0, i32 2
  %t236 = load i32, ptr %t235, !tbaa !23
  %t239 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eholds(ptr %v0, ptr %t234, i32 %t236)
  store i1 %t239, ptr %l126
  br label %bb77
bb77:
  %t240 = load i1, ptr %l126, !tbaa !21
  %t241 = xor i1 %t240, true
  br i1 %t241, label %bb78, label %bb79
bb78:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb79:
  br label %bb80
bb80:
  %t243 = getelementptr %"compiler/typed:Local", ptr %l5, i32 0, i32 5
  %t244 = load { i64, [1 x i64] }, ptr %t243
  store { i64, [1 x i64] } %t244, ptr %l9
  %t246 = load { i64, [1 x i64] }, ptr %l9
  %t248 = extractvalue { i64, [1 x i64] } %t246, 0
  %t249 = icmp eq i64 %t248, 0
  br i1 %t249, label %bb81, label %bb82
bb81:
  br label %bb85
bb82:
  %t251 = load { i64, [1 x i64] }, ptr %l9
  %t253 = extractvalue { i64, [1 x i64] } %t251, 0
  %t254 = icmp eq i64 %t253, 4
  br i1 %t254, label %bb83, label %bb84
bb83:
  br label %bb85
bb84:
  br label %bb86
bb85:
  br label %bb91
bb86:
  br i1 true, label %bb87, label %bb88
bb87:
  br label %bb89
bb88:
  br label %bb90
bb89:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb90:
  call void @__olang_check_failed(ptr @olang_loc_36d9ea1b8e0be675_6ae7f20c6157de79)
  unreachable
bb91:
  %t256 = load ptr, ptr %l2, !tbaa !29
  %t259 = call ptr @compiler_2ftyped_2eCall_2eOf(ptr %v1, ptr %v1, ptr %t256)
  store ptr %t259, ptr %l135
  br label %bb92
bb92:
  %t260 = load ptr, ptr %l135, !tbaa !29
  store ptr %t260, ptr %l10, !tbaa !29
  %t261 = load ptr, ptr %l10, !tbaa !29
  %t263 = icmp eq ptr %t261, null
  br i1 %t263, label %bb93, label %bb94
bb93:
  %t265 = load ptr, ptr %l0, !tbaa !29
  %t266 = load ptr, ptr %l2, !tbaa !29
  %t270 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epartCallOf(ptr %v0, ptr %v1, ptr %s0, ptr %t265, ptr %t266)
  store ptr %t270, ptr %l141
  br label %bb95
bb94:
  br label %bb99
bb95:
  %t271 = load ptr, ptr %l141, !tbaa !29
  store ptr %t271, ptr %l10, !tbaa !29
  %t272 = load ptr, ptr %l10, !tbaa !29
  %t274 = icmp eq ptr %t272, null
  br i1 %t274, label %bb96, label %bb97
bb96:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb97:
  br label %bb98
bb98:
  %t276 = load ptr, ptr %l0, !tbaa !29
  %t278 = getelementptr %"compiler/scope:Scoper", ptr %t276, i32 0, i32 142
  store i1 true, ptr %t278, !tbaa !21
  br label %bb99
bb99:
  %t279 = load ptr, ptr %l0, !tbaa !29
  store ptr %t279, ptr %l145, !tbaa !29
  %t280 = load ptr, ptr %l10, !tbaa !29
  %t282 = icmp eq ptr %t280, null
  br i1 %t282, label %bb100, label %bb101
bb100:
  call void @__olang_check_failed(ptr @olang_loc_318ee1b3da3da37b_dfd49c38f0c44407)
  unreachable
bb101:
  br label %bb102
bb102:
  %t284 = load ptr, ptr %l10, !tbaa !29
  %t287 = getelementptr %"compiler/typed:Call", ptr %t284, i32 0, i32 0
  %t288 = load ptr, ptr %t287, !tbaa !29
  %t289 = load ptr, ptr %l145, !tbaa !29
  %t291 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebodyOf(ptr %v0, ptr %v1, ptr %t289, ptr %t288)
  store i64 %t291, ptr %l151
  br label %bb103
bb103:
  %t292 = load i64, ptr %l151, !tbaa !24
  store i64 %t292, ptr %l11, !tbaa !24
  %t293 = load ptr, ptr %l0, !tbaa !29
  store ptr %t293, ptr %l152, !tbaa !29
  %t294 = load ptr, ptr %l10, !tbaa !29
  %t296 = icmp eq ptr %t294, null
  br i1 %t296, label %bb104, label %bb105
bb104:
  call void @__olang_check_failed(ptr @olang_loc_b8fb270bdd73210c_150398a92061e6e8)
  unreachable
bb105:
  br label %bb106
bb106:
  %t298 = load ptr, ptr %l10, !tbaa !29
  %t299 = load ptr, ptr %l152, !tbaa !29
  %t301 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2evalueCall(ptr %v0, ptr %v1, ptr %t299, ptr %t298)
  store i1 %t301, ptr %l156
  br label %bb107
bb107:
  %t302 = load i1, ptr %l156, !tbaa !21
  br i1 %t302, label %bb108, label %bb109
bb108:
  store %olang.scope zeroinitializer, ptr %s14
  %t303 = load ptr, ptr %l0, !tbaa !29
  store ptr %t303, ptr %l157, !tbaa !29
  %t304 = load ptr, ptr %l0, !tbaa !29
  store ptr %t304, ptr %l158, !tbaa !29
  %t305 = load ptr, ptr %l10, !tbaa !29
  %t307 = icmp eq ptr %t305, null
  br i1 %t307, label %bb110, label %bb111
bb109:
  br label %bb123
bb110:
  call void @__olang_check_failed(ptr @olang_loc_6763258997513a41_ec0b86cc45ca0bbd)
  unreachable
bb111:
  br label %bb112
bb112:
  %t309 = load ptr, ptr %l10, !tbaa !29
  %t310 = load ptr, ptr %l158, !tbaa !29
  %t312 = call i32 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecalleeType(ptr %v0, ptr %v1, ptr %t310, ptr %t309)
  store i32 %t312, ptr %l162
  br label %bb113
bb113:
  %t313 = load ptr, ptr %l157, !tbaa !29
  %t314 = load i32, ptr %l162, !tbaa !23
  %t315 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eresultVarOf(ptr %v0, ptr %t313, i32 %t314)
  store i64 %t315, ptr %l163
  br label %bb114
bb114:
  %t316 = load i64, ptr %l163, !tbaa !24
  store i64 %t316, ptr %l12, !tbaa !24
  %t317 = load ptr, ptr %l0, !tbaa !29
  store ptr %t317, ptr %l164, !tbaa !29
  %t318 = load i64, ptr %l12, !tbaa !24
  %t320 = icmp sge i64 %t318, 0
  br i1 %t320, label %bb115, label %bb116
bb115:
  %t322 = load ptr, ptr %l0, !tbaa !29
  store ptr %t322, ptr %l168, !tbaa !29
  %t323 = load ptr, ptr %l0, !tbaa !29
  store ptr %t323, ptr %l169, !tbaa !29
  %t324 = load ptr, ptr %l10, !tbaa !29
  %t326 = icmp eq ptr %t324, null
  br i1 %t326, label %bb117, label %bb118
bb116:
  store i1 false, ptr %l167, !tbaa !21
  br label %bb122
bb117:
  call void @__olang_check_failed(ptr @olang_loc_6767537ca10246ba_b3f77aefc3649fd6)
  unreachable
bb118:
  br label %bb119
bb119:
  %t328 = load ptr, ptr %l10, !tbaa !29
  %t329 = load ptr, ptr %l169, !tbaa !29
  %t331 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecallRels(ptr %v0, ptr %v1, ptr %v0, ptr %t329, ptr %t328)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t331, ptr %l173
  br label %bb120
bb120:
  %t332 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l173
  %t333 = call ptr @__olang_scope_alloc_a(ptr %s14, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t332, ptr %t333
  %t334 = load i64, ptr %l12, !tbaa !24
  %t335 = load ptr, ptr %l168, !tbaa !29
  %t338 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eforcedBy(ptr %v0, ptr %v0, ptr %t335, ptr %t333, i64 %t334)
  store i1 %t338, ptr %l176
  br label %bb121
bb121:
  %t339 = load i1, ptr %l176, !tbaa !21
  store i1 %t339, ptr %l167, !tbaa !21
  br label %bb122
bb122:
  %t340 = load i1, ptr %l167, !tbaa !21
  %t341 = load ptr, ptr %l164, !tbaa !29
  %t342 = getelementptr %"compiler/scope:Scoper", ptr %t341, i32 0, i32 139
  store i1 %t340, ptr %t342, !tbaa !21
  call void @__olang_scope_close(ptr %s14)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb123:
  %t343 = load i64, ptr %l11, !tbaa !24
  %t345 = icmp slt i64 %t343, 0
  br i1 %t345, label %bb124, label %bb125
bb124:
  store i1 true, ptr %l179, !tbaa !21
  br label %bb127
bb125:
  %t347 = load ptr, ptr %l0, !tbaa !29
  %t348 = load i64, ptr %l11, !tbaa !24
  %t351 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esummed(ptr %v0, ptr %t347, i64 %t348)
  store i1 %t351, ptr %l182
  br label %bb126
bb126:
  %t352 = load i1, ptr %l182, !tbaa !21
  %t353 = xor i1 %t352, true
  store i1 %t353, ptr %l179, !tbaa !21
  br label %bb127
bb127:
  %t355 = load i1, ptr %l179, !tbaa !21
  br i1 %t355, label %bb128, label %bb129
bb128:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb129:
  br label %bb130
bb130:
  %t356 = load ptr, ptr %l0, !tbaa !29
  %t357 = load i32, ptr %l1, !tbaa !23
  %t359 = sext i32 %t357 to i64
  %t362 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ewalkLocal(ptr %v0, ptr %t356, i64 %t359)
  store i1 %t362, ptr %l187
  br label %bb131
bb131:
  %t363 = load i1, ptr %l187, !tbaa !21
  br i1 %t363, label %bb132, label %bb133
bb132:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb133:
  br label %bb134
bb134:
  %t364 = load ptr, ptr %l0, !tbaa !29
  %t366 = getelementptr %"compiler/scope:Scoper", ptr %t364, i32 0, i32 0
  %t367 = load ptr, ptr %t366, !tbaa !29
  %t369 = getelementptr %"compiler/generic:Program", ptr %t367, i32 0, i32 2
  store ptr %t369, ptr %l190, !tbaa !29
  %t370 = load ptr, ptr %l0, !tbaa !29
  store ptr %t370, ptr %l191, !tbaa !29
  %t371 = load ptr, ptr %l10, !tbaa !29
  %t373 = icmp eq ptr %t371, null
  br i1 %t373, label %bb135, label %bb136
bb135:
  call void @__olang_check_failed(ptr @olang_loc_5eb3bfaaf86e9baf_8dddb03606b5f843)
  unreachable
bb136:
  br label %bb137
bb137:
  %t375 = load ptr, ptr %l10, !tbaa !29
  %t376 = load ptr, ptr %l191, !tbaa !29
  %t378 = call i32 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecalleeType(ptr %v0, ptr %v1, ptr %t376, ptr %t375)
  store i32 %t378, ptr %l195
  br label %bb138
bb138:
  %t379 = load ptr, ptr %l190, !tbaa !29
  %t380 = load i32, ptr %l195, !tbaa !23
  %t381 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRole(ptr %v0, ptr %t379, i32 %t380)
  store i64 %t381, ptr %l196
  br label %bb139
bb139:
  %t382 = load i64, ptr @G_2ecompiler_2ftypes_2eRoleCtor, !tbaa !24
  %t383 = load i64, ptr %l196, !tbaa !24
  %t385 = icmp eq i64 %t383, %t382
  br i1 %t385, label %bb140, label %bb141
bb140:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb141:
  br label %bb142
bb142:
  %t387 = load ptr, ptr %l0, !tbaa !29
  store ptr %t387, ptr %l199, !tbaa !29
  %t388 = load ptr, ptr %l0, !tbaa !29
  store ptr %t388, ptr %l200, !tbaa !29
  %t389 = load ptr, ptr %l10, !tbaa !29
  %t391 = icmp eq ptr %t389, null
  br i1 %t391, label %bb143, label %bb144
bb143:
  call void @__olang_check_failed(ptr @olang_loc_8d9c16c9e7a15650_5ac0d9bfaf5af2b4)
  unreachable
bb144:
  br label %bb145
bb145:
  %t393 = load ptr, ptr %l10, !tbaa !29
  %t394 = load ptr, ptr %l200, !tbaa !29
  %t396 = call i32 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecalleeType(ptr %v0, ptr %v1, ptr %t394, ptr %t393)
  store i32 %t396, ptr %l204
  br label %bb146
bb146:
  %t397 = load ptr, ptr %l199, !tbaa !29
  %t398 = load i32, ptr %l204, !tbaa !23
  %t399 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eresultVarOf(ptr %v0, ptr %t397, i32 %t398)
  store i64 %t399, ptr %l205
  br label %bb147
bb147:
  %t400 = load i64, ptr %l205, !tbaa !24
  store i64 %t400, ptr %l13, !tbaa !24
  %t401 = load i64, ptr %l13, !tbaa !24
  %t403 = icmp slt i64 %t401, 0
  br i1 %t403, label %bb148, label %bb149
bb148:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb149:
  br label %bb150
bb150:
  %t405 = load ptr, ptr %l0, !tbaa !29
  %t406 = load i64, ptr %l11, !tbaa !24
  %t407 = load i64, ptr %l13, !tbaa !24
  %t411 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esumBuilds(ptr %v0, ptr %t405, i64 %t406, i64 %t407)
  store i1 %t411, ptr %l211
  br label %bb151
bb151:
  %t412 = load i1, ptr %l211, !tbaa !21
  %t413 = xor i1 %t412, true
  br i1 %t413, label %bb152, label %bb153
bb152:
  %t415 = load ptr, ptr %l0, !tbaa !29
  %t416 = load i64, ptr %l11, !tbaa !24
  %t419 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2egenBody(ptr %v0, ptr %t415, i64 %t416)
  store i1 %t419, ptr %l216
  br label %bb154
bb153:
  store i1 false, ptr %l213, !tbaa !21
  br label %bb155
bb154:
  %t420 = load i1, ptr %l216, !tbaa !21
  %t421 = xor i1 %t420, true
  store i1 %t421, ptr %l213, !tbaa !21
  br label %bb155
bb155:
  %t423 = load i1, ptr %l213, !tbaa !21
  br i1 %t423, label %bb156, label %bb157
bb156:
  store i1 true, ptr %l218, !tbaa !21
  br label %bb159
bb157:
  %t424 = load ptr, ptr %l0, !tbaa !29
  %t425 = load i64, ptr %l11, !tbaa !24
  %t426 = load i64, ptr %l13, !tbaa !24
  %t430 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eforced(ptr %v0, ptr %t424, i64 %t425, i64 %t426)
  store i1 %t430, ptr %l222
  br label %bb158
bb158:
  %t431 = load i1, ptr %l222, !tbaa !21
  store i1 %t431, ptr %l218, !tbaa !21
  br label %bb159
bb159:
  %t432 = load i1, ptr %l218, !tbaa !21
  br i1 %t432, label %bb160, label %bb161
bb160:
  %t433 = load ptr, ptr %l0, !tbaa !29
  %t435 = getelementptr %"compiler/scope:Scoper", ptr %t433, i32 0, i32 139
  store i1 true, ptr %t435, !tbaa !21
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb161:
  br label %bb162
bb162:
  %t436 = load ptr, ptr %l0, !tbaa !29
  %t437 = load i32, ptr %l1, !tbaa !23
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eflowStart(ptr %v0, ptr %t436, i32 %t437, i64 1)
  br label %bb163
bb163:
  %t440 = load ptr, ptr %l0, !tbaa !29
  %t441 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t442 = load i64, ptr %l4, !tbaa !24
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eflowRun(ptr %v0, ptr %v2, ptr %t440, { i64, ptr } %t441, i64 %t442)
  br label %bb164
bb164:
  %t446 = load ptr, ptr %l0, !tbaa !29
  %t447 = load ptr, ptr %l0, !tbaa !29
  %t449 = getelementptr %"compiler/scope:Scoper", ptr %t447, i32 0, i32 149
  %t450 = load i1, ptr %t449, !tbaa !21
  %t453 = getelementptr %"compiler/scope:Scoper", ptr %t446, i32 0, i32 139
  store i1 %t450, ptr %t453, !tbaa !21
  %t454 = load ptr, ptr %l0, !tbaa !29
  %t456 = getelementptr %"compiler/scope:Scoper", ptr %t454, i32 0, i32 150
  store i64 0, ptr %t456, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2edropCopied(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca i64
  %l14 = alloca i1
  %l16 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l20 = alloca ptr
  %l23 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l25 = alloca i64
  %l27 = alloca i64
  %l32 = alloca i64
  %l36 = alloca i1
  %l45 = alloca i64
  %l47 = alloca i64
  %l52 = alloca i64
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t5 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecopiedChoice(ptr %v0, ptr %v1, ptr %t1, ptr %t2)
  store i1 %t5, ptr %l14
  br label %bb1
bb1:
  %t6 = load i1, ptr %l14, !tbaa !21
  %t7 = xor i1 %t6, true
  br i1 %t7, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb3:
  br label %bb4
bb4:
  %t9 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %l16
  br label %bb5
bb5:
  %t10 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l16
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t10, ptr %l3
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load ptr, ptr %l1, !tbaa !29
  %t16 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunAway(ptr %v0, ptr %v1, ptr %s0, ptr %t11, ptr %t12)
  store ptr %t16, ptr %l20
  br label %bb6
bb6:
  %t17 = load ptr, ptr %l20, !tbaa !29
  call void @compiler_2fscope_2echoiceReads(ptr %s0, ptr %s0, ptr %t17, ptr %l3)
  br label %bb7
bb7:
  %t20 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %l23
  br label %bb8
bb8:
  %t21 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l23
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t21, ptr %l4
  %t22 = load ptr, ptr %l2, !tbaa !29
  store ptr %t22, ptr %l5, !tbaa !29
  store i64 0, ptr %l6, !tbaa !24
  br label %bb9
bb9:
  %t24 = load i64, ptr %l6, !tbaa !24
  store i64 %t24, ptr %l25, !tbaa !24
  %t25 = load ptr, ptr %l5, !tbaa !29
  %t27 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v2, ptr %t25)
  store i64 %t27, ptr %l27
  br label %bb10
bb10:
  %t28 = load i64, ptr %l25, !tbaa !24
  %t29 = load i64, ptr %l27, !tbaa !24
  %t30 = icmp slt i64 %t28, %t29
  %t32 = xor i1 %t30, true
  br i1 %t32, label %bb11, label %bb12
bb11:
  br label %bb21
bb12:
  br label %bb13
bb13:
  %t34 = load ptr, ptr %l5, !tbaa !29
  %t35 = load i64, ptr %l6, !tbaa !24
  %t38 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v2, ptr %t34, i64 %t35)
  store i64 %t38, ptr %l32
  br label %bb14
bb14:
  %t39 = load i64, ptr %l32, !tbaa !24
  store i64 %t39, ptr %l7, !tbaa !24
  %t40 = load i64, ptr %l7, !tbaa !24
  %t45 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eHas_3cI64_3e(ptr %s0, ptr %l3, i64 %t40)
  store i1 %t45, ptr %l36
  br label %bb15
bb15:
  %t46 = load i1, ptr %l36, !tbaa !21
  %t47 = xor i1 %t46, true
  br i1 %t47, label %bb16, label %bb17
bb16:
  %t49 = load i64, ptr %l7, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l4, i64 %t49)
  br label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb19
bb19:
  br label %bb20
bb20:
  %t52 = load i64, ptr %l6, !tbaa !24
  %t55 = add i64 %t52, 1
  store i64 %t55, ptr %l6, !tbaa !24
  br label %bb9
bb21:
  %t57 = load ptr, ptr %l2, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v2, ptr %t57)
  br label %bb22
bb22:
  store ptr %l4, ptr %l9, !tbaa !29
  store i64 0, ptr %l10, !tbaa !24
  br label %bb23
bb23:
  %t60 = load i64, ptr %l10, !tbaa !24
  store i64 %t60, ptr %l45, !tbaa !24
  %t61 = load ptr, ptr %l9, !tbaa !29
  %t63 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t61)
  store i64 %t63, ptr %l47
  br label %bb24
bb24:
  %t64 = load i64, ptr %l45, !tbaa !24
  %t65 = load i64, ptr %l47, !tbaa !24
  %t66 = icmp slt i64 %t64, %t65
  %t68 = xor i1 %t66, true
  br i1 %t68, label %bb25, label %bb26
bb25:
  br label %bb31
bb26:
  br label %bb27
bb27:
  %t70 = load ptr, ptr %l9, !tbaa !29
  %t71 = load i64, ptr %l10, !tbaa !24
  %t74 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t70, i64 %t71)
  store i64 %t74, ptr %l52
  br label %bb28
bb28:
  %t75 = load i64, ptr %l52, !tbaa !24
  %t76 = load ptr, ptr %l2, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v2, ptr %t76, i64 %t75)
  br label %bb29
bb29:
  br label %bb30
bb30:
  %t80 = load i64, ptr %l10, !tbaa !24
  %t83 = add i64 %t80, 1
  store i64 %t83, ptr %l10, !tbaa !24
  br label %bb23
bb31:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eeqAfter(ptr %v0, ptr %a0, %"compiler/source:Span" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i8
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l9 = alloca ptr
  %l17 = alloca { i64, ptr }
  %l18 = alloca i32
  %l25 = alloca i1
  %l26 = alloca { i64, ptr }
  %l31 = alloca { i64, ptr }
  %l36 = alloca i1
  %l39 = alloca i1
  %l47 = alloca i1
  %l50 = alloca i1
  %l58 = alloca i1
  %l66 = alloca i1
  %l67 = alloca { i64, ptr }
  %l80 = alloca i1
  %l81 = alloca { i64, ptr }
  %l86 = alloca i1
  %l87 = alloca { i64, ptr }
  %l92 = alloca i1
  %l93 = alloca { i64, ptr }
  %l98 = alloca i1
  %l99 = alloca { i64, ptr }
  %l103 = alloca i1
  %l114 = alloca %"compiler/source:Span"
  %s6 = alloca %olang.scope
  %rv = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 12
  store ptr %t3, ptr %l9, !tbaa !29
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t6 = getelementptr %"compiler/scope:Scoper", ptr %t4, i32 0, i32 28
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = icmp eq ptr %t7, null
  br i1 %t9, label %bb1, label %bb2
bb1:
  call void @__olang_check_failed(ptr @olang_loc_7b1e363353e9e01f_5d568e34003a167b)
  unreachable
bb2:
  br label %bb3
bb3:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/scope:Scoper", ptr %t11, i32 0, i32 28
  %t14 = load ptr, ptr %t13, !tbaa !29
  %t17 = getelementptr %"compiler/typed:Body", ptr %t14, i32 0, i32 3
  %t18 = load i64, ptr %t17, !tbaa !24
  %t19 = load ptr, ptr %l9, !tbaa !29
  %t21 = call { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_He9bc6cfad7ef603960b4717f3121b8e8(ptr %v0, ptr %v0, ptr %t19, i64 %t18)
  %t22 = extractvalue { i32, { i64, ptr } } %t21, 1
  %t23 = extractvalue { i32, { i64, ptr } } %t21, 0
  store i32 %t23, ptr %l18
  %t24 = icmp ne i32 %t23, 0
  br i1 %t24, label %bb5, label %ok.25, !prof !99
ok.25:
  store { i64, ptr } %t22, ptr %l17
  br label %bb4
bb4:
  %t26 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t26, ptr %l7, !tbaa !27
  br label %bb7
bb5:
  br label %bb6
bb6:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d35, i32 0, i32 1) }, ptr %l7, !tbaa !27
  br label %bb7
bb7:
  %t27 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t27, ptr %l2, !tbaa !27
  %t28 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 1
  %t29 = load i32, ptr %t28, !tbaa !23
  %t31 = sext i32 %t29 to i64
  store i64 %t31, ptr %l3, !tbaa !24
  store i64 0, ptr %l4, !tbaa !24
  br label %bb8
bb8:
  %t33 = load i64, ptr %l3, !tbaa !24
  %t34 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t36 = extractvalue { i64, ptr } %t34, 0
  %t39 = icmp slt i64 %t33, %t36
  br i1 %t39, label %bb9, label %bb10
bb9:
  %t41 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t41, ptr %l26, !tbaa !27
  %t42 = load i64, ptr %l3, !tbaa !24
  %t44 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !27
  %t46 = getelementptr i8, ptr %t45, i64 %t42
  %t47 = load i8, ptr %t46, !tbaa !32
  %t49 = icmp ne i8 %t47, 10
  store i1 %t49, ptr %l25, !tbaa !21
  br label %bb11
bb10:
  store i1 false, ptr %l25, !tbaa !21
  br label %bb11
bb11:
  %t51 = load i1, ptr %l25, !tbaa !21
  %t52 = xor i1 %t51, true
  br i1 %t52, label %bb12, label %bb13
bb12:
  br label %bb66
bb13:
  br label %bb14
bb14:
  %t54 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t54, ptr %l31, !tbaa !27
  %t55 = load i64, ptr %l3, !tbaa !24
  %t57 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t58 = load ptr, ptr %t57, !tbaa !27
  %t59 = getelementptr i8, ptr %t58, i64 %t55
  %t60 = load i8, ptr %t59, !tbaa !32
  store i8 %t60, ptr %l5, !tbaa !22
  %t62 = load i8, ptr %l5, !tbaa !22
  %t64 = icmp eq i8 %t62, 40
  br i1 %t64, label %bb15, label %bb16
bb15:
  store i1 true, ptr %l36, !tbaa !21
  br label %bb17
bb16:
  %t66 = load i8, ptr %l5, !tbaa !22
  %t68 = icmp eq i8 %t66, 91
  store i1 %t68, ptr %l36, !tbaa !21
  br label %bb17
bb17:
  %t70 = load i1, ptr %l36, !tbaa !21
  br i1 %t70, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l39, !tbaa !21
  br label %bb20
bb19:
  %t71 = load i8, ptr %l5, !tbaa !22
  %t73 = icmp eq i8 %t71, 123
  store i1 %t73, ptr %l39, !tbaa !21
  br label %bb20
bb20:
  %t75 = load i1, ptr %l39, !tbaa !21
  br i1 %t75, label %bb21, label %bb22
bb21:
  %t76 = load i64, ptr %l4, !tbaa !24
  %t79 = add i64 %t76, 1
  store i64 %t79, ptr %l4, !tbaa !24
  br label %bb64
bb22:
  %t81 = load i8, ptr %l5, !tbaa !22
  %t83 = icmp eq i8 %t81, 41
  br i1 %t83, label %bb23, label %bb24
bb23:
  store i1 true, ptr %l47, !tbaa !21
  br label %bb25
bb24:
  %t85 = load i8, ptr %l5, !tbaa !22
  %t87 = icmp eq i8 %t85, 93
  store i1 %t87, ptr %l47, !tbaa !21
  br label %bb25
bb25:
  %t89 = load i1, ptr %l47, !tbaa !21
  br i1 %t89, label %bb26, label %bb27
bb26:
  store i1 true, ptr %l50, !tbaa !21
  br label %bb28
bb27:
  %t90 = load i8, ptr %l5, !tbaa !22
  %t92 = icmp eq i8 %t90, 125
  store i1 %t92, ptr %l50, !tbaa !21
  br label %bb28
bb28:
  %t94 = load i1, ptr %l50, !tbaa !21
  br i1 %t94, label %bb29, label %bb30
bb29:
  %t95 = load i64, ptr %l4, !tbaa !24
  %t98 = sub i64 %t95, 1
  store i64 %t98, ptr %l4, !tbaa !24
  br label %bb63
bb30:
  %t100 = load i8, ptr %l5, !tbaa !22
  %t102 = icmp eq i8 %t100, 61
  br i1 %t102, label %bb31, label %bb32
bb31:
  %t104 = load i64, ptr %l4, !tbaa !24
  %t106 = icmp eq i64 %t104, 0
  store i1 %t106, ptr %l58, !tbaa !21
  br label %bb33
bb32:
  store i1 false, ptr %l58, !tbaa !21
  br label %bb33
bb33:
  %t108 = load i1, ptr %l58, !tbaa !21
  br i1 %t108, label %bb34, label %bb35
bb34:
  store %olang.scope zeroinitializer, ptr %s6
  %t109 = load i64, ptr %l3, !tbaa !24
  %t111 = add i64 %t109, 1
  %t112 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t114 = extractvalue { i64, ptr } %t112, 0
  %t117 = icmp slt i64 %t111, %t114
  br i1 %t117, label %bb36, label %bb37
bb35:
  br label %bb62
bb36:
  %t119 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t119, ptr %l67, !tbaa !27
  %t120 = load i64, ptr %l3, !tbaa !24
  %t122 = add i64 %t120, 1
  %t124 = getelementptr { i64, ptr }, ptr %l67, i32 0, i32 1
  %t125 = load ptr, ptr %t124, !tbaa !27
  %t126 = getelementptr i8, ptr %t125, i64 %t122
  %t127 = load i8, ptr %t126, !tbaa !32
  %t129 = icmp eq i8 %t127, 61
  store i1 %t129, ptr %l66, !tbaa !21
  br label %bb38
bb37:
  store i1 false, ptr %l66, !tbaa !21
  br label %bb38
bb38:
  %t131 = load i1, ptr %l66, !tbaa !21
  br i1 %t131, label %bb39, label %bb40
bb39:
  %t132 = load i64, ptr %l3, !tbaa !24
  %t135 = add i64 %t132, 2
  store i64 %t135, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s6)
  br label %bb65
bb40:
  br label %bb41
bb41:
  %t137 = load i64, ptr %l3, !tbaa !24
  store i64 %t137, ptr %l6, !tbaa !24
  br label %bb42
bb42:
  %t139 = load i64, ptr %l6, !tbaa !24
  %t140 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 1
  %t141 = load i32, ptr %t140, !tbaa !23
  %t143 = sext i32 %t141 to i64
  %t146 = icmp sgt i64 %t139, %t143
  br i1 %t146, label %bb43, label %bb44
bb43:
  %t148 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t148, ptr %l81, !tbaa !27
  %t149 = load i64, ptr %l6, !tbaa !24
  %t151 = sub i64 %t149, 1
  %t153 = getelementptr { i64, ptr }, ptr %l81, i32 0, i32 1
  %t154 = load ptr, ptr %t153, !tbaa !27
  %t155 = getelementptr i8, ptr %t154, i64 %t151
  %t156 = load i8, ptr %t155, !tbaa !32
  %t158 = icmp ne i8 %t156, 32
  store i1 %t158, ptr %l80, !tbaa !21
  br label %bb45
bb44:
  store i1 false, ptr %l80, !tbaa !21
  br label %bb45
bb45:
  %t160 = load i1, ptr %l80, !tbaa !21
  br i1 %t160, label %bb46, label %bb47
bb46:
  %t161 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t161, ptr %l87, !tbaa !27
  %t162 = load i64, ptr %l6, !tbaa !24
  %t164 = sub i64 %t162, 1
  %t166 = getelementptr { i64, ptr }, ptr %l87, i32 0, i32 1
  %t167 = load ptr, ptr %t166, !tbaa !27
  %t168 = getelementptr i8, ptr %t167, i64 %t164
  %t169 = load i8, ptr %t168, !tbaa !32
  %t171 = icmp ne i8 %t169, 41
  store i1 %t171, ptr %l86, !tbaa !21
  br label %bb48
bb47:
  store i1 false, ptr %l86, !tbaa !21
  br label %bb48
bb48:
  %t173 = load i1, ptr %l86, !tbaa !21
  br i1 %t173, label %bb49, label %bb50
bb49:
  %t174 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t174, ptr %l93, !tbaa !27
  %t175 = load i64, ptr %l6, !tbaa !24
  %t177 = sub i64 %t175, 1
  %t179 = getelementptr { i64, ptr }, ptr %l93, i32 0, i32 1
  %t180 = load ptr, ptr %t179, !tbaa !27
  %t181 = getelementptr i8, ptr %t180, i64 %t177
  %t182 = load i8, ptr %t181, !tbaa !32
  %t184 = icmp ne i8 %t182, 93
  store i1 %t184, ptr %l92, !tbaa !21
  br label %bb51
bb50:
  store i1 false, ptr %l92, !tbaa !21
  br label %bb51
bb51:
  %t186 = load i1, ptr %l92, !tbaa !21
  br i1 %t186, label %bb52, label %bb53
bb52:
  %t187 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t187, ptr %l99, !tbaa !27
  %t188 = load i64, ptr %l6, !tbaa !24
  %t190 = sub i64 %t188, 1
  %t192 = getelementptr { i64, ptr }, ptr %l99, i32 0, i32 1
  %t193 = load ptr, ptr %t192, !tbaa !27
  %t194 = getelementptr i8, ptr %t193, i64 %t190
  %t195 = load i8, ptr %t194, !tbaa !32
  %t197 = call i1 @compiler_2fscope_2eisNameChar(i8 %t195)
  store i1 %t197, ptr %l103
  br label %bb54
bb53:
  store i1 false, ptr %l98, !tbaa !21
  br label %bb55
bb54:
  %t198 = load i1, ptr %l103, !tbaa !21
  %t199 = xor i1 %t198, true
  store i1 %t199, ptr %l98, !tbaa !21
  br label %bb55
bb55:
  %t201 = load i1, ptr %l98, !tbaa !21
  %t202 = xor i1 %t201, true
  br i1 %t202, label %bb56, label %bb57
bb56:
  br label %bb60
bb57:
  br label %bb58
bb58:
  %t204 = load i64, ptr %l6, !tbaa !24
  %t207 = sub i64 %t204, 1
  store i64 %t207, ptr %l6, !tbaa !24
  br label %bb59
bb59:
  br label %bb42
bb60:
  %t209 = load i64, ptr %l6, !tbaa !24
  %t211 = trunc i64 %t209 to i32
  %t212 = load i64, ptr %l3, !tbaa !24
  %t214 = add i64 %t212, 1
  %t216 = trunc i64 %t214 to i32
  %t219 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s6, i32 %t211, i32 %t216)
  store %"compiler/source:Span" %t219, ptr %l114
  br label %bb61
bb61:
  call void @__olang_scope_close(ptr %s6)
  %t220 = load %"compiler/source:Span", ptr %l114
  store %"compiler/source:Span" %t220, ptr %rv
  br label %ret
bb62:
  br label %bb63
bb63:
  br label %bb64
bb64:
  %t221 = load i64, ptr %l3, !tbaa !24
  %t224 = add i64 %t221, 1
  store i64 %t224, ptr %l3, !tbaa !24
  br label %bb65
bb65:
  br label %bb8
bb66:
  %t226 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t226, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2efieldSet(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca %"compiler/scope:fsBody"
  %l5 = alloca i32
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca %"compiler/scope:fsOpen"
  %l9 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca %"compiler/scope:fsRow"
  %l15 = alloca i64
  %l18 = alloca i1
  %l21 = alloca i1
  %l24 = alloca i1
  %l27 = alloca i1
  %l29 = alloca %"compiler/scope:fsBody"
  %l34 = alloca %"compiler/scope:fsBody"
  %l35 = alloca i32
  %l37 = alloca %"compiler/scope:fsBody"
  %l43 = alloca i32
  %l46 = alloca i1
  %l49 = alloca ptr
  %l54 = alloca i32
  %l55 = alloca i32
  %l57 = alloca i64
  %l59 = alloca i64
  %l64 = alloca %"compiler/scope:fsOpen"
  %l69 = alloca i1
  %l74 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l76 = alloca i64
  %l78 = alloca i64
  %l83 = alloca %"compiler/scope:fsRow"
  %l91 = alloca i1
  %l95 = alloca { i64, ptr }
  %l98 = alloca i1
  %l107 = alloca { i64, [2 x i64] }
  %s0 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %rv = alloca { i64, [2 x i64] }
  %t28 = alloca { i64, [2 x i64] }, align 8
  %t48 = alloca { i64, [2 x i64] }, align 8
  %t121 = alloca { i64, [2 x i64] }, align 8
  %t170 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2edeclOf(ptr %v0, ptr %t1, i32 %t2)
  store i64 %t5, ptr %l15
  br label %bb1
bb1:
  %t6 = load i64, ptr %l15, !tbaa !24
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t9 = icmp slt i64 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l18, !tbaa !21
  br label %bb4
bb3:
  %t11 = load i64, ptr %l2, !tbaa !24
  %t13 = icmp slt i64 %t11, 0
  store i1 %t13, ptr %l18, !tbaa !21
  br label %bb4
bb4:
  %t15 = load i1, ptr %l18, !tbaa !21
  br i1 %t15, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l21, !tbaa !21
  br label %bb7
bb6:
  %t16 = load i64, ptr %l2, !tbaa !24
  %t18 = icmp sge i64 %t16, 256
  store i1 %t18, ptr %l21, !tbaa !21
  br label %bb7
bb7:
  %t20 = load i1, ptr %l21, !tbaa !21
  br i1 %t20, label %bb8, label %bb9
bb8:
  store i1 true, ptr %l24, !tbaa !21
  br label %bb11
bb9:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load i64, ptr %l3, !tbaa !24
  %t25 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eapartDecl(ptr %v0, ptr %t21, i64 %t22)
  store i1 %t25, ptr %l27
  br label %bb10
bb10:
  %t26 = load i1, ptr %l27, !tbaa !21
  store i1 %t26, ptr %l24, !tbaa !21
  br label %bb11
bb11:
  %t27 = load i1, ptr %l24, !tbaa !21
  br i1 %t27, label %bb12, label %bb13
bb12:
  store { i64, [2 x i64] } zeroinitializer, ptr %t28
  %t29 = getelementptr { i64, [2 x i64] }, ptr %t28, i32 0, i32 0
  store i64 0, ptr %t29
  %t30 = load { i64, [2 x i64] }, ptr %t28
  call void @__olang_scope_close(ptr %s0)
  store { i64, [2 x i64] } %t30, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/scope:Scoper", ptr %t32, i32 0, i32 53
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/scope:Scoper", ptr %t35, i32 0, i32 29
  %t38 = load i64, ptr %t37, !tbaa !24
  %t41 = call { i32, %"compiler/scope:fsBody" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fscope_3afsBody_3e__Hb5653faf0f4c5db756b53371f9538b9d(ptr %v0, ptr %v0, ptr %t34, i64 %t38)
  %t42 = extractvalue { i32, %"compiler/scope:fsBody" } %t41, 1
  %t43 = extractvalue { i32, %"compiler/scope:fsBody" } %t41, 0
  store i32 %t43, ptr %l35
  %t44 = icmp ne i32 %t43, 0
  br i1 %t44, label %bb16, label %ok.45, !prof !99
ok.45:
  store %"compiler/scope:fsBody" %t42, ptr %l34
  br label %bb15
bb15:
  %t47 = call %"compiler/scope:fsBody" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2fscope_3afsBody(ptr %s0, ptr %l34)
  store %"compiler/scope:fsBody" %t47, ptr %l37
  br label %bb18
bb16:
  br label %bb17
bb17:
  store { i64, [2 x i64] } zeroinitializer, ptr %t48
  %t49 = getelementptr { i64, [2 x i64] }, ptr %t48, i32 0, i32 0
  store i64 0, ptr %t49
  %t50 = load { i64, [2 x i64] }, ptr %t48
  call void @__olang_scope_close(ptr %s0)
  store { i64, [2 x i64] } %t50, ptr %rv
  br label %ret
bb18:
  %t52 = load %"compiler/scope:fsBody", ptr %l37
  store %"compiler/scope:fsBody" %t52, ptr %l29
  br label %bb19
bb19:
  %t53 = load %"compiler/scope:fsBody", ptr %l29
  store %"compiler/scope:fsBody" %t53, ptr %l4
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/scope:Scoper", ptr %t54, i32 0, i32 0
  %t57 = load ptr, ptr %t56, !tbaa !29
  %t59 = getelementptr %"compiler/generic:Program", ptr %t57, i32 0, i32 2
  %t60 = load i32, ptr %l1, !tbaa !23
  %t63 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t59, i32 %t60)
  store i32 %t63, ptr %l43
  br label %bb20
bb20:
  %t64 = load i32, ptr %l43, !tbaa !23
  store i32 %t64, ptr %l5, !tbaa !23
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t66 = load i32, ptr %l5, !tbaa !23
  %t69 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisRef(ptr %v0, ptr %t65, i32 %t66)
  store i1 %t69, ptr %l46
  br label %bb21
bb21:
  %t70 = load i1, ptr %l46, !tbaa !21
  br i1 %t70, label %bb22, label %bb23
bb22:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/scope:Scoper", ptr %t71, i32 0, i32 0
  %t74 = load ptr, ptr %t73, !tbaa !29
  %t76 = getelementptr %"compiler/generic:Program", ptr %t74, i32 0, i32 2
  store ptr %t76, ptr %l49, !tbaa !29
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/scope:Scoper", ptr %t77, i32 0, i32 0
  %t80 = load ptr, ptr %t79, !tbaa !29
  %t82 = getelementptr %"compiler/generic:Program", ptr %t80, i32 0, i32 2
  %t83 = load i32, ptr %l5, !tbaa !23
  %t86 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t82, i32 %t83)
  store i32 %t86, ptr %l54
  br label %bb24
bb23:
  br label %bb26
bb24:
  %t87 = load ptr, ptr %l49, !tbaa !29
  %t88 = load i32, ptr %l54, !tbaa !23
  %t89 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t87, i32 %t88)
  store i32 %t89, ptr %l55
  br label %bb25
bb25:
  %t90 = load i32, ptr %l55, !tbaa !23
  store i32 %t90, ptr %l5, !tbaa !23
  br label %bb26
bb26:
  %t91 = getelementptr %"compiler/scope:fsBody", ptr %l4, i32 0, i32 1
  store ptr %t91, ptr %l6, !tbaa !29
  store i64 0, ptr %l7, !tbaa !24
  br label %bb27
bb27:
  %t93 = load i64, ptr %l7, !tbaa !24
  store i64 %t93, ptr %l57, !tbaa !24
  %t94 = load ptr, ptr %l6, !tbaa !29
  %t96 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3afsOpen_3e_2eLen_3ccompiler_2fscope_3afsOpen_3e(ptr %s0, ptr %t94)
  store i64 %t96, ptr %l59
  br label %bb28
bb28:
  %t97 = load i64, ptr %l57, !tbaa !24
  %t98 = load i64, ptr %l59, !tbaa !24
  %t99 = icmp slt i64 %t97, %t98
  %t101 = xor i1 %t99, true
  br i1 %t101, label %bb29, label %bb30
bb29:
  br label %bb38
bb30:
  br label %bb31
bb31:
  %t103 = load ptr, ptr %l6, !tbaa !29
  %t104 = load i64, ptr %l7, !tbaa !24
  %t107 = call %"compiler/scope:fsOpen" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3afsOpen_3e_2eAt_3ccompiler_2fscope_3afsOpen_3e(ptr %s0, ptr %t103, i64 %t104)
  store %"compiler/scope:fsOpen" %t107, ptr %l64
  br label %bb32
bb32:
  %t108 = load %"compiler/scope:fsOpen", ptr %l64
  store %"compiler/scope:fsOpen" %t108, ptr %l8
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t110 = getelementptr %"compiler/scope:fsOpen", ptr %l8, i32 0, i32 0
  %t111 = load i32, ptr %t110, !tbaa !23
  %t112 = load i32, ptr %l5, !tbaa !23
  %t113 = getelementptr %"compiler/scope:fsOpen", ptr %l8, i32 0, i32 1
  %t114 = load i1, ptr %t113, !tbaa !21
  %t119 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2efsReaches(ptr %v0, ptr %t109, i32 %t111, i32 %t112, i1 %t114)
  store i1 %t119, ptr %l69
  br label %bb33
bb33:
  %t120 = load i1, ptr %l69, !tbaa !21
  br i1 %t120, label %bb34, label %bb35
bb34:
  store { i64, [2 x i64] } zeroinitializer, ptr %t121
  %t122 = getelementptr { i64, [2 x i64] }, ptr %t121, i32 0, i32 0
  store i64 0, ptr %t122
  %t123 = load { i64, [2 x i64] }, ptr %t121
  call void @__olang_scope_close(ptr %s0)
  store { i64, [2 x i64] } %t123, ptr %rv
  br label %ret
bb35:
  br label %bb36
bb36:
  br label %bb37
bb37:
  %t125 = load i64, ptr %l7, !tbaa !24
  %t128 = add i64 %t125, 1
  store i64 %t128, ptr %l7, !tbaa !24
  br label %bb27
bb38:
  %t130 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t130, ptr %l74
  br label %bb39
bb39:
  %t131 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l74
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t131, ptr %l9
  %t132 = getelementptr %"compiler/scope:fsBody", ptr %l4, i32 0, i32 0
  store ptr %t132, ptr %l10, !tbaa !29
  store i64 0, ptr %l11, !tbaa !24
  br label %bb40
bb40:
  store %olang.scope zeroinitializer, ptr %s9
  %t134 = load i64, ptr %l11, !tbaa !24
  store i64 %t134, ptr %l76, !tbaa !24
  %t135 = load ptr, ptr %l10, !tbaa !29
  %t137 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3afsRow_3e_2eLen_3ccompiler_2fscope_3afsRow_3e(ptr %s0, ptr %t135)
  store i64 %t137, ptr %l78
  br label %bb41
bb41:
  %t138 = load i64, ptr %l76, !tbaa !24
  %t139 = load i64, ptr %l78, !tbaa !24
  %t140 = icmp slt i64 %t138, %t139
  %t142 = xor i1 %t140, true
  br i1 %t142, label %bb42, label %bb43
bb42:
  call void @__olang_scope_close(ptr %s9)
  br label %bb60
bb43:
  br label %bb44
bb44:
  %t144 = load ptr, ptr %l10, !tbaa !29
  %t145 = load i64, ptr %l11, !tbaa !24
  %t148 = call %"compiler/scope:fsRow" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3afsRow_3e_2eAt_3ccompiler_2fscope_3afsRow_3e(ptr %s0, ptr %t144, i64 %t145)
  store %"compiler/scope:fsRow" %t148, ptr %l83
  br label %bb45
bb45:
  %t149 = load %"compiler/scope:fsRow", ptr %l83
  store %"compiler/scope:fsRow" %t149, ptr %l12
  %t150 = getelementptr %"compiler/scope:fsRow", ptr %l12, i32 0, i32 0
  %t151 = load i64, ptr %t150, !tbaa !24
  %t152 = load i64, ptr %l3, !tbaa !24
  %t154 = mul i64 %t152, 256
  %t155 = load i64, ptr %l2, !tbaa !24
  %t158 = add i64 %t154, %t155
  %t161 = icmp ne i64 %t151, %t158
  br i1 %t161, label %bb46, label %bb47
bb46:
  call void @__olang_scope_close(ptr %s9)
  br label %bb59
bb47:
  br label %bb48
bb48:
  %t163 = getelementptr %"compiler/scope:fsRow", ptr %l12, i32 0, i32 1
  %t164 = load { i64, [2 x i64] }, ptr %t163
  %t166 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aTerm_2eRuns({ i64, [2 x i64] } %t164)
  store i1 %t166, ptr %l91
  br label %bb49
bb49:
  %t167 = load i1, ptr %l91, !tbaa !21
  %t168 = xor i1 %t167, true
  br i1 %t168, label %bb50, label %bb51
bb50:
  store { i64, [2 x i64] } zeroinitializer, ptr %t170
  %t171 = getelementptr { i64, [2 x i64] }, ptr %t170, i32 0, i32 0
  store i64 0, ptr %t171
  %t172 = load { i64, [2 x i64] }, ptr %t170
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s0)
  store { i64, [2 x i64] } %t172, ptr %rv
  br label %ret
bb51:
  br label %bb52
bb52:
  %t175 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eView_3ccompiler_2fscope_3aTerm_3e(ptr %s0, ptr %s0, ptr %l9)
  store { i64, ptr } %t175, ptr %l95
  br label %bb53
bb53:
  %t176 = load %"compiler/scope:fsRow", ptr %l12
  %t177 = getelementptr { %"compiler/scope:fsRow" }, ptr null, i32 1
  %t178 = ptrtoint ptr %t177 to i64
  %t179 = call ptr @__olang_scope_alloc_a(ptr %s9, i64 %t178, i64 8)
  %t180 = getelementptr { %"compiler/scope:fsRow" }, ptr %t179, i32 0, i32 0
  store %"compiler/scope:fsRow" %t176, ptr %t180, !tbaa !28
  %t182 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_36, 0
  %t183 = insertvalue { ptr, ptr } %t182, ptr %t179, 1
  %t184 = load { i64, ptr }, ptr %l95, !tbaa !27
  %t186 = extractvalue { ptr, ptr } %t183, 0
  %t187 = extractvalue { ptr, ptr } %t183, 1
  %t188 = call i1 @std_2fprelude_2farray_2eArray_3ccompiler_2fscope_3aTerm_3e_2eSome_3ccompiler_2fscope_3aTerm_2c_20_3f_3e(ptr %s0, ptr %s9, { i64, ptr } %t184, ptr %t186, ptr %t187)
  store i1 %t188, ptr %l98
  br label %bb54
bb54:
  %t189 = load i1, ptr %l98, !tbaa !21
  %t190 = xor i1 %t189, true
  br i1 %t190, label %bb55, label %bb56
bb55:
  %t192 = getelementptr %"compiler/scope:fsRow", ptr %l12, i32 0, i32 1
  %t193 = load { i64, [2 x i64] }, ptr %t192
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2ePush_3ccompiler_2fscope_3aTerm_3e(ptr %s0, ptr %l9, { i64, [2 x i64] } %t193)
  br label %bb57
bb56:
  br label %bb58
bb57:
  br label %bb58
bb58:
  call void @__olang_scope_close(ptr %s9)
  br label %bb59
bb59:
  %t196 = load i64, ptr %l11, !tbaa !24
  %t199 = add i64 %t196, 1
  store i64 %t199, ptr %l11, !tbaa !24
  br label %bb40
bb60:
  %t201 = load ptr, ptr %l0, !tbaa !29
  %t204 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2etermOf(ptr %v0, ptr %s0, ptr %t201, ptr %l9)
  store { i64, [2 x i64] } %t204, ptr %l107
  br label %bb61
bb61:
  call void @__olang_scope_close(ptr %s0)
  %t205 = load { i64, [2 x i64] }, ptr %l107
  store { i64, [2 x i64] } %t205, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [2 x i64] }, ptr %rv
  ret { i64, [2 x i64] } %rr
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eflAddDirect(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l6 = alloca i64
  %l8 = alloca i64
  %l13 = alloca i64
  %l19 = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a1, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  %t3 = load i64, ptr %l3, !tbaa !24
  store i64 %t3, ptr %l6, !tbaa !24
  %t4 = load ptr, ptr %l2, !tbaa !29
  %t6 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t4)
  store i64 %t6, ptr %l8
  br label %bb2
bb2:
  %t7 = load i64, ptr %l6, !tbaa !24
  %t8 = load i64, ptr %l8, !tbaa !24
  %t9 = icmp slt i64 %t7, %t8
  %t11 = xor i1 %t9, true
  br i1 %t11, label %bb3, label %bb4
bb3:
  br label %bb14
bb4:
  br label %bb5
bb5:
  %t13 = load ptr, ptr %l2, !tbaa !29
  %t14 = load i64, ptr %l3, !tbaa !24
  %t17 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t13, i64 %t14)
  store i64 %t17, ptr %l13
  br label %bb6
bb6:
  %t18 = load i64, ptr %l13, !tbaa !24
  store i64 %t18, ptr %l4, !tbaa !24
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t20 = load i64, ptr %l4, !tbaa !24
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eflAdd(ptr %v0, ptr %t19, i64 %t20)
  br label %bb7
bb7:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/scope:Scoper", ptr %t23, i32 0, i32 147
  %t26 = load i64, ptr %l4, !tbaa !24
  %t29 = call i1 @compiler_2fscope_2eflHas(ptr %v0, ptr %t25, i64 %t26)
  store i1 %t29, ptr %l19
  br label %bb8
bb8:
  %t30 = load i1, ptr %l19, !tbaa !21
  %t31 = xor i1 %t30, true
  br i1 %t31, label %bb9, label %bb10
bb9:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/scope:Scoper", ptr %t33, i32 0, i32 147
  %t36 = load i64, ptr %l4, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t35, i64 %t36)
  br label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb12
bb12:
  br label %bb13
bb13:
  %t39 = load i64, ptr %l3, !tbaa !24
  %t42 = add i64 %t39, 1
  store i64 %t42, ptr %l3, !tbaa !24
  br label %bb1
bb14:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eflInto(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2, ptr %a3, i1 %a4, i1 %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l3 = alloca ptr
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca i64
  %l12 = alloca i1
  %l15 = alloca i1
  %l22 = alloca i1
  %l26 = alloca i1
  %l27 = alloca i1
  %l29 = alloca i1
  %l33 = alloca i1
  %l35 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l44 = alloca i64
  %l46 = alloca i64
  %l51 = alloca i64
  %l57 = alloca i1
  %l67 = alloca i1
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i32 %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l3, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb4
bb2:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t6 = load i32, ptr %l2, !tbaa !23
  %t9 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eholds(ptr %v0, ptr %t5, i32 %t6)
  store i1 %t9, ptr %l15
  br label %bb3
bb3:
  %t10 = load i1, ptr %l15, !tbaa !21
  %t11 = xor i1 %t10, true
  store i1 %t11, ptr %l12, !tbaa !21
  br label %bb4
bb4:
  %t13 = load i1, ptr %l12, !tbaa !21
  br i1 %t13, label %bb5, label %bb6
bb5:
  br label %ret
bb6:
  br label %bb7
bb7:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/scope:Scoper", ptr %t14, i32 0, i32 150
  %t17 = load i64, ptr %t16, !tbaa !24
  %t19 = icmp eq i64 %t17, 0
  br i1 %t19, label %bb8, label %bb9
bb8:
  %t21 = load i64, ptr %l1, !tbaa !24
  %t23 = icmp sge i64 %t21, 0
  br i1 %t23, label %bb10, label %bb11
bb9:
  br label %bb41
bb10:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/scope:Scoper", ptr %t25, i32 0, i32 146
  %t28 = load i64, ptr %l1, !tbaa !24
  %t31 = call i1 @compiler_2fscope_2eflHas(ptr %v0, ptr %t27, i64 %t28)
  store i1 %t31, ptr %l26
  br label %bb12
bb11:
  store i1 false, ptr %l22, !tbaa !21
  br label %bb13
bb12:
  %t32 = load i1, ptr %l26, !tbaa !21
  store i1 %t32, ptr %l22, !tbaa !21
  br label %bb13
bb13:
  %t33 = load i1, ptr %l22, !tbaa !21
  br i1 %t33, label %bb14, label %bb15
bb14:
  br i1 %a5, label %bb16, label %bb17
bb15:
  store i1 false, ptr %l27, !tbaa !21
  br label %bb20
bb16:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t37 = load ptr, ptr %l3, !tbaa !29
  %t38 = load i32, ptr %l2, !tbaa !23
  %t42 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eplainCopyOf(ptr %v0, ptr %v1, ptr %t36, ptr %t37, i32 %t38)
  store i1 %t42, ptr %l33
  br label %bb18
bb17:
  store i1 false, ptr %l29, !tbaa !21
  br label %bb19
bb18:
  %t43 = load i1, ptr %l33, !tbaa !21
  store i1 %t43, ptr %l29, !tbaa !21
  br label %bb19
bb19:
  %t44 = load i1, ptr %l29, !tbaa !21
  %t45 = xor i1 %t44, true
  store i1 %t45, ptr %l27, !tbaa !21
  br label %bb20
bb20:
  %t47 = load i1, ptr %l27, !tbaa !21
  br i1 %t47, label %bb21, label %bb22
bb21:
  store %olang.scope zeroinitializer, ptr %s3
  %t48 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s3, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t48, ptr %l35
  br label %bb23
bb22:
  br label %bb40
bb23:
  %t49 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l35
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t49, ptr %l6
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t51 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecarried(ptr %v0, ptr %v1, ptr %s3, ptr %t50, ptr %t51, ptr %l6)
  br label %bb24
bb24:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t57 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2edropViewed(ptr %v0, ptr %v1, ptr %s3, ptr %t56, ptr %t57, ptr %l6)
  br label %bb25
bb25:
  store ptr %l6, ptr %l7, !tbaa !29
  store i64 0, ptr %l8, !tbaa !24
  br label %bb26
bb26:
  %t62 = load i64, ptr %l8, !tbaa !24
  store i64 %t62, ptr %l44, !tbaa !24
  %t63 = load ptr, ptr %l7, !tbaa !29
  %t65 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s3, ptr %t63)
  store i64 %t65, ptr %l46
  br label %bb27
bb27:
  %t66 = load i64, ptr %l44, !tbaa !24
  %t67 = load i64, ptr %l46, !tbaa !24
  %t68 = icmp slt i64 %t66, %t67
  %t70 = xor i1 %t68, true
  br i1 %t70, label %bb28, label %bb29
bb28:
  br label %bb39
bb29:
  br label %bb30
bb30:
  %t72 = load ptr, ptr %l7, !tbaa !29
  %t73 = load i64, ptr %l8, !tbaa !24
  %t76 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s3, ptr %t72, i64 %t73)
  store i64 %t76, ptr %l51
  br label %bb31
bb31:
  %t77 = load i64, ptr %l51, !tbaa !24
  store i64 %t77, ptr %l9, !tbaa !24
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t79 = load i64, ptr %l9, !tbaa !24
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eflAdd(ptr %v0, ptr %t78, i64 %t79)
  br label %bb32
bb32:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/scope:Scoper", ptr %t82, i32 0, i32 148
  %t85 = load i64, ptr %l9, !tbaa !24
  %t88 = call i1 @compiler_2fscope_2eflHas(ptr %v0, ptr %t84, i64 %t85)
  store i1 %t88, ptr %l57
  br label %bb33
bb33:
  %t89 = load i1, ptr %l57, !tbaa !21
  %t90 = xor i1 %t89, true
  br i1 %t90, label %bb34, label %bb35
bb34:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"compiler/scope:Scoper", ptr %t92, i32 0, i32 148
  %t95 = load i64, ptr %l9, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t94, i64 %t95)
  br label %bb36
bb35:
  br label %bb37
bb36:
  br label %bb37
bb37:
  br label %bb38
bb38:
  %t98 = load i64, ptr %l8, !tbaa !24
  %t101 = add i64 %t98, 1
  store i64 %t101, ptr %l8, !tbaa !24
  br label %bb26
bb39:
  call void @__olang_scope_close(ptr %s3)
  br label %bb40
bb40:
  br label %ret
bb41:
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t104 = load ptr, ptr %l3, !tbaa !29
  %t107 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecarries(ptr %v0, ptr %v1, ptr %t103, ptr %t104)
  store i1 %t107, ptr %l67
  br label %bb42
bb42:
  %t108 = load i1, ptr %l67, !tbaa !21
  %t109 = xor i1 %t108, true
  br i1 %t109, label %bb43, label %bb44
bb43:
  br label %ret
bb44:
  br label %bb45
bb45:
  br i1 %a4, label %bb46, label %bb47
bb46:
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t115 = getelementptr %"compiler/scope:Scoper", ptr %t113, i32 0, i32 149
  store i1 true, ptr %t115, !tbaa !21
  br label %ret
bb47:
  br label %bb48
bb48:
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t117 = load i64, ptr %l1, !tbaa !24
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eflAdd(ptr %v0, ptr %t116, i64 %t117)
  br label %bb49
bb49:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eflStmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca i1
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l14 = alloca i64
  %l15 = alloca ptr
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca ptr
  %l19 = alloca ptr
  %l20 = alloca ptr
  %l21 = alloca ptr
  %l22 = alloca ptr
  %l23 = alloca ptr
  %l24 = alloca { i64, ptr }
  %l25 = alloca i64
  %l26 = alloca i64
  %l28 = alloca ptr
  %l29 = alloca ptr
  %l30 = alloca ptr
  %l33 = alloca ptr
  %l34 = alloca i1
  %l44 = alloca ptr
  %l46 = alloca i64
  %l56 = alloca %"compiler/typed:Local"
  %l60 = alloca ptr
  %l61 = alloca i1
  %l75 = alloca i64
  %l76 = alloca i1
  %l77 = alloca ptr
  %l78 = alloca i1
  %l81 = alloca ptr
  %l82 = alloca i64
  %l84 = alloca i32
  %l86 = alloca ptr
  %l88 = alloca i1
  %l89 = alloca i1
  %l92 = alloca i1
  %l95 = alloca i1
  %l97 = alloca ptr
  %l98 = alloca i1
  %l106 = alloca ptr
  %l107 = alloca i1
  %l123 = alloca ptr
  %l124 = alloca i1
  %l136 = alloca ptr
  %l137 = alloca i1
  %l149 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l167 = alloca i64
  %l169 = alloca i64
  %l171 = alloca i64
  %l176 = alloca i64
  %l180 = alloca i1
  %l184 = alloca i1
  %l194 = alloca i1
  %l196 = alloca ptr
  %l197 = alloca i1
  %l209 = alloca ptr
  %l210 = alloca i1
  %l217 = alloca ptr
  %l218 = alloca i1
  %l226 = alloca ptr
  %l227 = alloca i1
  %l235 = alloca ptr
  %l236 = alloca i1
  %l253 = alloca { i64, ptr }
  %l262 = alloca ptr
  %l263 = alloca i1
  %l275 = alloca i1
  %l279 = alloca i1
  %l281 = alloca ptr
  %l282 = alloca i1
  %l293 = alloca i1
  %l296 = alloca i1
  %l298 = alloca ptr
  %l299 = alloca i1
  %l309 = alloca i1
  %l310 = alloca ptr
  %l314 = alloca i1
  %s11 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l1, !tbaa !29
  store ptr %t5, ptr %l33, !tbaa !29
  store i1 false, ptr %l34, !tbaa !21
  %t6 = load ptr, ptr %l33, !tbaa !29
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %bb4, label %bb5
bb4:
  %t9 = load ptr, ptr %l33, !tbaa !29
  %t10 = load i64, ptr %t9, !range !{i64 0, i64 17}
  %t12 = icmp eq i64 %t10, 0
  store i1 %t12, ptr %l34, !tbaa !21
  br label %bb5
bb5:
  %t13 = load i1, ptr %l34, !tbaa !21
  br i1 %t13, label %bb6, label %bb7
bb6:
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t16 = getelementptr { i64, [3 x i64] }, ptr %t14, i32 0, i32 1
  %t17 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t16, i32 0, i32 1
  %t18 = load i32, ptr %t17
  store i32 %t18, ptr %l2, !tbaa !23
  %t20 = load ptr, ptr %l1, !tbaa !29
  %t22 = getelementptr { i64, [3 x i64] }, ptr %t20, i32 0, i32 1
  %t23 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t22, i32 0, i32 2
  %t24 = load ptr, ptr %t23
  store ptr %t24, ptr %l3, !tbaa !29
  br label %bb8
bb7:
  br label %bb15
bb8:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t27 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eflExpr(ptr %v0, ptr %v1, ptr %t26, ptr %t27)
  br label %bb9
bb9:
  %t31 = load ptr, ptr %l0, !tbaa !29
  store ptr %t31, ptr %l44, !tbaa !29
  %t32 = load i32, ptr %l2, !tbaa !23
  %t34 = sext i32 %t32 to i64
  store i64 %t34, ptr %l46, !tbaa !24
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/scope:Scoper", ptr %t35, i32 0, i32 28
  %t38 = load ptr, ptr %t37, !tbaa !29
  %t40 = icmp eq ptr %t38, null
  br i1 %t40, label %bb10, label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_6038e9a8843bd167_10c714601f259253)
  unreachable
bb11:
  br label %bb12
bb12:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/scope:Scoper", ptr %t42, i32 0, i32 28
  %t45 = load ptr, ptr %t44, !tbaa !29
  %t48 = getelementptr %"compiler/typed:Body", ptr %t45, i32 0, i32 7
  %t49 = load i32, ptr %l2, !tbaa !23
  %t51 = sext i32 %t49 to i64
  %t54 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t48, i64 %t51)
  store %"compiler/typed:Local" %t54, ptr %l56
  br label %bb13
bb13:
  %t55 = getelementptr %"compiler/typed:Local", ptr %l56, i32 0, i32 2
  %t56 = load i32, ptr %t55, !tbaa !23
  %t57 = load ptr, ptr %l3, !tbaa !29
  %t59 = load ptr, ptr %l44, !tbaa !29
  %t60 = load i64, ptr %l46, !tbaa !24
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eflInto(ptr %v0, ptr %v1, ptr %t59, i64 %t60, i32 %t56, ptr %t57, i1 false, i1 true)
  br label %bb14
bb14:
  br label %bb202
bb15:
  %t63 = load ptr, ptr %l1, !tbaa !29
  store ptr %t63, ptr %l60, !tbaa !29
  store i1 false, ptr %l61, !tbaa !21
  %t64 = load ptr, ptr %l60, !tbaa !29
  %t65 = icmp ne ptr %t64, null
  br i1 %t65, label %bb16, label %bb17
bb16:
  %t67 = load ptr, ptr %l60, !tbaa !29
  %t68 = load i64, ptr %t67, !range !{i64 0, i64 17}
  %t70 = icmp eq i64 %t68, 1
  store i1 %t70, ptr %l61, !tbaa !21
  br label %bb17
bb17:
  %t71 = load i1, ptr %l61, !tbaa !21
  br i1 %t71, label %bb18, label %bb19
bb18:
  %t72 = load ptr, ptr %l1, !tbaa !29
  %t74 = getelementptr { i64, [3 x i64] }, ptr %t72, i32 0, i32 1
  %t75 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t74, i32 0, i32 1
  %t76 = load ptr, ptr %t75
  store ptr %t76, ptr %l4, !tbaa !29
  %t78 = load ptr, ptr %l1, !tbaa !29
  %t80 = getelementptr { i64, [3 x i64] }, ptr %t78, i32 0, i32 1
  %t81 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t80, i32 0, i32 2
  %t82 = load ptr, ptr %t81
  store ptr %t82, ptr %l5, !tbaa !29
  br label %bb20
bb19:
  br label %bb45
bb20:
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t85 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eflPlace(ptr %v0, ptr %v1, ptr %t84, ptr %t85)
  br label %bb21
bb21:
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t89 = load ptr, ptr %l5, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eflExpr(ptr %v0, ptr %v1, ptr %t88, ptr %t89)
  br label %bb22
bb22:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t94 = load ptr, ptr %l4, !tbaa !29
  %t97 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eflPlaceRoot(ptr %v0, ptr %v1, ptr %t93, ptr %t94)
  store i64 %t97, ptr %l75
  br label %bb23
bb23:
  %t98 = load i64, ptr %l75, !tbaa !24
  store i64 %t98, ptr %l6, !tbaa !24
  %t99 = load ptr, ptr %l4, !tbaa !29
  store ptr %t99, ptr %l77, !tbaa !29
  store i1 false, ptr %l78, !tbaa !21
  %t100 = load ptr, ptr %l77, !tbaa !29
  %t101 = icmp ne ptr %t100, null
  br i1 %t101, label %bb24, label %bb25
bb24:
  %t103 = load ptr, ptr %l77, !tbaa !29
  %t104 = load i64, ptr %t103, !range !{i64 0, i64 8}
  %t106 = icmp eq i64 %t104, 0
  store i1 %t106, ptr %l78, !tbaa !21
  br label %bb25
bb25:
  %t107 = load i1, ptr %l78, !tbaa !21
  br i1 %t107, label %bb26, label %bb27
bb26:
  br label %bb28
bb27:
  br label %bb29
bb28:
  store i1 true, ptr %l76, !tbaa !21
  br label %bb34
bb29:
  br i1 true, label %bb30, label %bb31
bb30:
  br label %bb32
bb31:
  br label %bb33
bb32:
  store i1 false, ptr %l76, !tbaa !21
  br label %bb34
bb33:
  call void @__olang_check_failed(ptr @olang_loc_c1fa5f0b83cd997f_623e25aaa52b89ab)
  unreachable
bb34:
  %t108 = load i1, ptr %l76, !tbaa !21
  store i1 %t108, ptr %l7, !tbaa !21
  %t109 = load ptr, ptr %l0, !tbaa !29
  store ptr %t109, ptr %l81, !tbaa !29
  %t110 = load i64, ptr %l6, !tbaa !24
  store i64 %t110, ptr %l82, !tbaa !24
  %t111 = load ptr, ptr %l4, !tbaa !29
  %t113 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v1, ptr %t111)
  store i32 %t113, ptr %l84
  br label %bb35
bb35:
  %t114 = load ptr, ptr %l5, !tbaa !29
  store ptr %t114, ptr %l86, !tbaa !29
  %t116 = load ptr, ptr %l4, !tbaa !29
  %t118 = call i1 @compiler_2fscope_2eflThroughRef(ptr %v1, ptr %t116)
  store i1 %t118, ptr %l88
  br label %bb36
bb36:
  %t119 = load i1, ptr %l88, !tbaa !21
  br i1 %t119, label %bb37, label %bb38
bb37:
  store i1 true, ptr %l89, !tbaa !21
  br label %bb39
bb38:
  %t120 = load i64, ptr %l6, !tbaa !24
  %t122 = icmp slt i64 %t120, 0
  store i1 %t122, ptr %l89, !tbaa !21
  br label %bb39
bb39:
  %t124 = load i1, ptr %l89, !tbaa !21
  br i1 %t124, label %bb40, label %bb41
bb40:
  store i1 true, ptr %l92, !tbaa !21
  br label %bb43
bb41:
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t126 = load i64, ptr %l6, !tbaa !24
  %t129 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eoutside(ptr %v0, ptr %t125, i64 %t126)
  store i1 %t129, ptr %l95
  br label %bb42
bb42:
  %t130 = load i1, ptr %l95, !tbaa !21
  store i1 %t130, ptr %l92, !tbaa !21
  br label %bb43
bb43:
  %t131 = load i1, ptr %l7, !tbaa !21
  %t132 = load ptr, ptr %l81, !tbaa !29
  %t133 = load i64, ptr %l82, !tbaa !24
  %t134 = load i32, ptr %l84, !tbaa !23
  %t135 = load ptr, ptr %l86, !tbaa !29
  %t136 = load i1, ptr %l92, !tbaa !21
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eflInto(ptr %v0, ptr %v1, ptr %t132, i64 %t133, i32 %t134, ptr %t135, i1 %t136, i1 %t131)
  br label %bb44
bb44:
  br label %bb202
bb45:
  %t138 = load ptr, ptr %l1, !tbaa !29
  store ptr %t138, ptr %l97, !tbaa !29
  store i1 false, ptr %l98, !tbaa !21
  %t139 = load ptr, ptr %l97, !tbaa !29
  %t140 = icmp ne ptr %t139, null
  br i1 %t140, label %bb46, label %bb47
bb46:
  %t142 = load ptr, ptr %l97, !tbaa !29
  %t143 = load i64, ptr %t142, !range !{i64 0, i64 17}
  %t145 = icmp eq i64 %t143, 2
  store i1 %t145, ptr %l98, !tbaa !21
  br label %bb47
bb47:
  %t146 = load i1, ptr %l98, !tbaa !21
  br i1 %t146, label %bb48, label %bb49
bb48:
  %t147 = load ptr, ptr %l1, !tbaa !29
  %t149 = getelementptr { i64, [3 x i64] }, ptr %t147, i32 0, i32 1
  %t150 = getelementptr { %"compiler/source:Span", ptr }, ptr %t149, i32 0, i32 1
  %t151 = load ptr, ptr %t150
  store ptr %t151, ptr %l8, !tbaa !29
  br label %bb50
bb49:
  br label %bb52
bb50:
  %t153 = load ptr, ptr %l0, !tbaa !29
  %t154 = load ptr, ptr %l8, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eflExpr(ptr %v0, ptr %v1, ptr %t153, ptr %t154)
  br label %bb51
bb51:
  br label %bb202
bb52:
  %t158 = load ptr, ptr %l1, !tbaa !29
  store ptr %t158, ptr %l106, !tbaa !29
  store i1 false, ptr %l107, !tbaa !21
  %t159 = load ptr, ptr %l106, !tbaa !29
  %t160 = icmp ne ptr %t159, null
  br i1 %t160, label %bb53, label %bb54
bb53:
  %t162 = load ptr, ptr %l106, !tbaa !29
  %t163 = load i64, ptr %t162, !range !{i64 0, i64 17}
  %t165 = icmp eq i64 %t163, 3
  store i1 %t165, ptr %l107, !tbaa !21
  br label %bb54
bb54:
  %t166 = load i1, ptr %l107, !tbaa !21
  br i1 %t166, label %bb55, label %bb56
bb55:
  %t167 = load ptr, ptr %l1, !tbaa !29
  %t169 = getelementptr { i64, [3 x i64] }, ptr %t167, i32 0, i32 1
  %t170 = getelementptr { %"compiler/source:Span", ptr }, ptr %t169, i32 0, i32 1
  %t171 = load ptr, ptr %t170
  store ptr %t171, ptr %l9, !tbaa !29
  br label %bb57
bb56:
  br label %bb61
bb57:
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t174 = load ptr, ptr %l9, !tbaa !29
  %t176 = getelementptr %"compiler/typed:If", ptr %t174, i32 0, i32 0
  %t177 = load ptr, ptr %t176, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eflExpr(ptr %v0, ptr %v1, ptr %t173, ptr %t177)
  br label %bb58
bb58:
  %t181 = load ptr, ptr %l0, !tbaa !29
  %t182 = load ptr, ptr %l9, !tbaa !29
  %t184 = getelementptr %"compiler/typed:If", ptr %t182, i32 0, i32 1
  %t185 = load ptr, ptr %t184, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eflBlockOf(ptr %v0, ptr %v1, ptr %t181, ptr %t185)
  br label %bb59
bb59:
  %t189 = load ptr, ptr %l0, !tbaa !29
  %t190 = load ptr, ptr %l9, !tbaa !29
  %t192 = getelementptr %"compiler/typed:If", ptr %t190, i32 0, i32 2
  %t193 = load ptr, ptr %t192, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eflBlockOf(ptr %v0, ptr %v1, ptr %t189, ptr %t193)
  br label %bb60
bb60:
  br label %bb202
bb61:
  %t196 = load ptr, ptr %l1, !tbaa !29
  store ptr %t196, ptr %l123, !tbaa !29
  store i1 false, ptr %l124, !tbaa !21
  %t197 = load ptr, ptr %l123, !tbaa !29
  %t198 = icmp ne ptr %t197, null
  br i1 %t198, label %bb62, label %bb63
bb62:
  %t200 = load ptr, ptr %l123, !tbaa !29
  %t201 = load i64, ptr %t200, !range !{i64 0, i64 17}
  %t203 = icmp eq i64 %t201, 4
  store i1 %t203, ptr %l124, !tbaa !21
  br label %bb63
bb63:
  %t204 = load i1, ptr %l124, !tbaa !21
  br i1 %t204, label %bb64, label %bb65
bb64:
  %t205 = load ptr, ptr %l1, !tbaa !29
  %t207 = getelementptr { i64, [3 x i64] }, ptr %t205, i32 0, i32 1
  %t208 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t207, i32 0, i32 1
  %t209 = load ptr, ptr %t208
  store ptr %t209, ptr %l10, !tbaa !29
  %t211 = load ptr, ptr %l1, !tbaa !29
  %t213 = getelementptr { i64, [3 x i64] }, ptr %t211, i32 0, i32 1
  %t214 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t213, i32 0, i32 2
  %t215 = load ptr, ptr %t214
  store ptr %t215, ptr %l11, !tbaa !29
  br label %bb66
bb65:
  br label %bb69
bb66:
  %t217 = load ptr, ptr %l0, !tbaa !29
  %t218 = load ptr, ptr %l10, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eflBlockOf(ptr %v0, ptr %v1, ptr %t217, ptr %t218)
  br label %bb67
bb67:
  %t222 = load ptr, ptr %l0, !tbaa !29
  %t223 = load ptr, ptr %l11, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eflBlockOf(ptr %v0, ptr %v1, ptr %t222, ptr %t223)
  br label %bb68
bb68:
  br label %bb202
bb69:
  %t226 = load ptr, ptr %l1, !tbaa !29
  store ptr %t226, ptr %l136, !tbaa !29
  store i1 false, ptr %l137, !tbaa !21
  %t227 = load ptr, ptr %l136, !tbaa !29
  %t228 = icmp ne ptr %t227, null
  br i1 %t228, label %bb70, label %bb71
bb70:
  %t230 = load ptr, ptr %l136, !tbaa !29
  %t231 = load i64, ptr %t230, !range !{i64 0, i64 17}
  %t233 = icmp eq i64 %t231, 6
  store i1 %t233, ptr %l137, !tbaa !21
  br label %bb71
bb71:
  %t234 = load i1, ptr %l137, !tbaa !21
  br i1 %t234, label %bb72, label %bb73
bb72:
  %t235 = load ptr, ptr %l1, !tbaa !29
  %t237 = getelementptr { i64, [3 x i64] }, ptr %t235, i32 0, i32 1
  %t238 = getelementptr { %"compiler/source:Span", ptr }, ptr %t237, i32 0, i32 1
  %t239 = load ptr, ptr %t238
  store ptr %t239, ptr %l12, !tbaa !29
  br label %bb74
bb73:
  br label %bb109
bb74:
  %t241 = load ptr, ptr %l0, !tbaa !29
  %t242 = load ptr, ptr %l12, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eflExpr(ptr %v0, ptr %v1, ptr %t241, ptr %t242)
  br label %bb75
bb75:
  %t245 = load ptr, ptr %l12, !tbaa !29
  %t247 = icmp eq ptr %t245, null
  br i1 %t247, label %bb76, label %bb77
bb76:
  br label %ret
bb77:
  br label %bb78
bb78:
  %t249 = load ptr, ptr %l0, !tbaa !29
  %t251 = getelementptr %"compiler/scope:Scoper", ptr %t249, i32 0, i32 150
  %t252 = load i64, ptr %t251, !tbaa !24
  %t254 = icmp eq i64 %t252, 0
  br i1 %t254, label %bb79, label %bb80
bb79:
  store %olang.scope zeroinitializer, ptr %s11
  %t256 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s11, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t256, ptr %l149
  br label %bb81
bb80:
  %t257 = load ptr, ptr %l0, !tbaa !29
  %t258 = load ptr, ptr %l12, !tbaa !29
  %t261 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecarries(ptr %v0, ptr %v1, ptr %t257, ptr %t258)
  store i1 %t261, ptr %l194
  br label %bb104
bb81:
  %t262 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l149
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t262, ptr %l13
  %t263 = load ptr, ptr %l0, !tbaa !29
  %t264 = load ptr, ptr %l12, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecarried(ptr %v0, ptr %v1, ptr %s11, ptr %t263, ptr %t264, ptr %l13)
  br label %bb82
bb82:
  %t269 = load ptr, ptr %l0, !tbaa !29
  %t270 = load ptr, ptr %l12, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ereturnedArrays(ptr %v0, ptr %v1, ptr %s11, ptr %t269, ptr %t270, ptr %l13)
  br label %bb83
bb83:
  %t275 = load ptr, ptr %l0, !tbaa !29
  %t276 = load ptr, ptr %l12, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2edropCopied(ptr %v0, ptr %v1, ptr %s11, ptr %t275, ptr %t276, ptr %l13)
  br label %bb84
bb84:
  %t280 = load ptr, ptr %l0, !tbaa !29
  %t281 = load ptr, ptr %l12, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2edropViewed(ptr %v0, ptr %v1, ptr %s11, ptr %t280, ptr %t281, ptr %l13)
  br label %bb85
bb85:
  %t285 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eflAddDirect(ptr %v0, ptr %s11, ptr %t285, ptr %l13)
  br label %bb86
bb86:
  %t288 = load ptr, ptr %l12, !tbaa !29
  %t290 = call i64 @compiler_2fscope_2ewholeValueRead(ptr %v1, ptr %t288)
  store i64 %t290, ptr %l167
  br label %bb87
bb87:
  %t291 = load i64, ptr %l167, !tbaa !24
  store i64 %t291, ptr %l14, !tbaa !24
  store ptr %l13, ptr %l15, !tbaa !29
  store i64 0, ptr %l16, !tbaa !24
  br label %bb88
bb88:
  %t293 = load i64, ptr %l16, !tbaa !24
  store i64 %t293, ptr %l169, !tbaa !24
  %t294 = load ptr, ptr %l15, !tbaa !29
  %t296 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s11, ptr %t294)
  store i64 %t296, ptr %l171
  br label %bb89
bb89:
  %t297 = load i64, ptr %l169, !tbaa !24
  %t298 = load i64, ptr %l171, !tbaa !24
  %t299 = icmp slt i64 %t297, %t298
  %t301 = xor i1 %t299, true
  br i1 %t301, label %bb90, label %bb91
bb90:
  br label %bb103
bb91:
  br label %bb92
bb92:
  %t303 = load ptr, ptr %l15, !tbaa !29
  %t304 = load i64, ptr %l16, !tbaa !24
  %t307 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s11, ptr %t303, i64 %t304)
  store i64 %t307, ptr %l176
  br label %bb93
bb93:
  %t308 = load i64, ptr %l176, !tbaa !24
  store i64 %t308, ptr %l17, !tbaa !24
  %t309 = load i64, ptr %l17, !tbaa !24
  %t310 = load i64, ptr %l14, !tbaa !24
  %t313 = icmp ne i64 %t309, %t310
  br i1 %t313, label %bb94, label %bb95
bb94:
  %t315 = load ptr, ptr %l0, !tbaa !29
  %t317 = getelementptr %"compiler/scope:Scoper", ptr %t315, i32 0, i32 148
  %t318 = load i64, ptr %l17, !tbaa !24
  %t321 = call i1 @compiler_2fscope_2eflHas(ptr %v0, ptr %t317, i64 %t318)
  store i1 %t321, ptr %l184
  br label %bb96
bb95:
  store i1 false, ptr %l180, !tbaa !21
  br label %bb97
bb96:
  %t322 = load i1, ptr %l184, !tbaa !21
  %t323 = xor i1 %t322, true
  store i1 %t323, ptr %l180, !tbaa !21
  br label %bb97
bb97:
  %t325 = load i1, ptr %l180, !tbaa !21
  br i1 %t325, label %bb98, label %bb99
bb98:
  %t326 = load ptr, ptr %l0, !tbaa !29
  %t328 = getelementptr %"compiler/scope:Scoper", ptr %t326, i32 0, i32 148
  %t329 = load i64, ptr %l17, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t328, i64 %t329)
  br label %bb100
bb99:
  br label %bb101
bb100:
  br label %bb101
bb101:
  br label %bb102
bb102:
  %t332 = load i64, ptr %l16, !tbaa !24
  %t335 = add i64 %t332, 1
  store i64 %t335, ptr %l16, !tbaa !24
  br label %bb88
bb103:
  call void @__olang_scope_close(ptr %s11)
  br label %bb108
bb104:
  %t337 = load i1, ptr %l194, !tbaa !21
  br i1 %t337, label %bb105, label %bb106
bb105:
  %t338 = load ptr, ptr %l0, !tbaa !29
  %t340 = getelementptr %"compiler/scope:Scoper", ptr %t338, i32 0, i32 149
  store i1 true, ptr %t340, !tbaa !21
  br label %bb107
bb106:
  br label %bb107
bb107:
  br label %bb108
bb108:
  br label %bb202
bb109:
  %t341 = load ptr, ptr %l1, !tbaa !29
  store ptr %t341, ptr %l196, !tbaa !29
  store i1 false, ptr %l197, !tbaa !21
  %t342 = load ptr, ptr %l196, !tbaa !29
  %t343 = icmp ne ptr %t342, null
  br i1 %t343, label %bb110, label %bb111
bb110:
  %t345 = load ptr, ptr %l196, !tbaa !29
  %t346 = load i64, ptr %t345, !range !{i64 0, i64 17}
  %t348 = icmp eq i64 %t346, 10
  store i1 %t348, ptr %l197, !tbaa !21
  br label %bb111
bb111:
  %t349 = load i1, ptr %l197, !tbaa !21
  br i1 %t349, label %bb112, label %bb113
bb112:
  %t350 = load ptr, ptr %l1, !tbaa !29
  %t352 = getelementptr { i64, [3 x i64] }, ptr %t350, i32 0, i32 1
  %t353 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t352, i32 0, i32 1
  %t354 = load ptr, ptr %t353
  store ptr %t354, ptr %l18, !tbaa !29
  %t356 = load ptr, ptr %l1, !tbaa !29
  %t358 = getelementptr { i64, [3 x i64] }, ptr %t356, i32 0, i32 1
  %t359 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t358, i32 0, i32 2
  %t360 = load ptr, ptr %t359
  store ptr %t360, ptr %l19, !tbaa !29
  br label %bb114
bb113:
  br label %bb117
bb114:
  %t362 = load ptr, ptr %l0, !tbaa !29
  %t363 = load ptr, ptr %l18, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eflExpr(ptr %v0, ptr %v1, ptr %t362, ptr %t363)
  br label %bb115
bb115:
  %t367 = load ptr, ptr %l0, !tbaa !29
  %t368 = load ptr, ptr %l19, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eflExpr(ptr %v0, ptr %v1, ptr %t367, ptr %t368)
  br label %bb116
bb116:
  br label %bb202
bb117:
  %t371 = load ptr, ptr %l1, !tbaa !29
  store ptr %t371, ptr %l209, !tbaa !29
  store i1 false, ptr %l210, !tbaa !21
  %t372 = load ptr, ptr %l209, !tbaa !29
  %t373 = icmp ne ptr %t372, null
  br i1 %t373, label %bb118, label %bb119
bb118:
  %t375 = load ptr, ptr %l209, !tbaa !29
  %t376 = load i64, ptr %t375, !range !{i64 0, i64 17}
  %t378 = icmp eq i64 %t376, 9
  store i1 %t378, ptr %l210, !tbaa !21
  br label %bb119
bb119:
  %t379 = load i1, ptr %l210, !tbaa !21
  br i1 %t379, label %bb120, label %bb121
bb120:
  %t380 = load ptr, ptr %l1, !tbaa !29
  %t382 = getelementptr { i64, [3 x i64] }, ptr %t380, i32 0, i32 1
  %t383 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t382, i32 0, i32 2
  %t384 = load ptr, ptr %t383
  store ptr %t384, ptr %l20, !tbaa !29
  br label %bb122
bb121:
  br label %bb124
bb122:
  %t386 = load ptr, ptr %l0, !tbaa !29
  %t387 = load ptr, ptr %l20, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eflExpr(ptr %v0, ptr %v1, ptr %t386, ptr %t387)
  br label %bb123
bb123:
  br label %bb202
bb124:
  %t390 = load ptr, ptr %l1, !tbaa !29
  store ptr %t390, ptr %l217, !tbaa !29
  store i1 false, ptr %l218, !tbaa !21
  %t391 = load ptr, ptr %l217, !tbaa !29
  %t392 = icmp ne ptr %t391, null
  br i1 %t392, label %bb125, label %bb126
bb125:
  %t394 = load ptr, ptr %l217, !tbaa !29
  %t395 = load i64, ptr %t394, !range !{i64 0, i64 17}
  %t397 = icmp eq i64 %t395, 11
  store i1 %t397, ptr %l218, !tbaa !21
  br label %bb126
bb126:
  %t398 = load i1, ptr %l218, !tbaa !21
  br i1 %t398, label %bb127, label %bb128
bb127:
  %t399 = load ptr, ptr %l1, !tbaa !29
  %t401 = getelementptr { i64, [3 x i64] }, ptr %t399, i32 0, i32 1
  %t402 = getelementptr { %"compiler/source:Span", ptr }, ptr %t401, i32 0, i32 1
  %t403 = load ptr, ptr %t402
  store ptr %t403, ptr %l21, !tbaa !29
  br label %bb129
bb128:
  br label %bb131
bb129:
  %t405 = load ptr, ptr %l0, !tbaa !29
  %t406 = load ptr, ptr %l21, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eflBlockOf(ptr %v0, ptr %v1, ptr %t405, ptr %t406)
  br label %bb130
bb130:
  br label %bb202
bb131:
  %t410 = load ptr, ptr %l1, !tbaa !29
  store ptr %t410, ptr %l226, !tbaa !29
  store i1 false, ptr %l227, !tbaa !21
  %t411 = load ptr, ptr %l226, !tbaa !29
  %t412 = icmp ne ptr %t411, null
  br i1 %t412, label %bb132, label %bb133
bb132:
  %t414 = load ptr, ptr %l226, !tbaa !29
  %t415 = load i64, ptr %t414, !range !{i64 0, i64 17}
  %t417 = icmp eq i64 %t415, 12
  store i1 %t417, ptr %l227, !tbaa !21
  br label %bb133
bb133:
  %t418 = load i1, ptr %l227, !tbaa !21
  br i1 %t418, label %bb134, label %bb135
bb134:
  %t419 = load ptr, ptr %l1, !tbaa !29
  %t421 = getelementptr { i64, [3 x i64] }, ptr %t419, i32 0, i32 1
  %t422 = getelementptr { %"compiler/source:Span", ptr }, ptr %t421, i32 0, i32 1
  %t423 = load ptr, ptr %t422
  store ptr %t423, ptr %l22, !tbaa !29
  br label %bb136
bb135:
  br label %bb138
bb136:
  %t425 = load ptr, ptr %l0, !tbaa !29
  %t426 = load ptr, ptr %l22, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eflBlockOf(ptr %v0, ptr %v1, ptr %t425, ptr %t426)
  br label %bb137
bb137:
  br label %bb202
bb138:
  %t430 = load ptr, ptr %l1, !tbaa !29
  store ptr %t430, ptr %l235, !tbaa !29
  store i1 false, ptr %l236, !tbaa !21
  %t431 = load ptr, ptr %l235, !tbaa !29
  %t432 = icmp ne ptr %t431, null
  br i1 %t432, label %bb139, label %bb140
bb139:
  %t434 = load ptr, ptr %l235, !tbaa !29
  %t435 = load i64, ptr %t434, !range !{i64 0, i64 17}
  %t437 = icmp eq i64 %t435, 13
  store i1 %t437, ptr %l236, !tbaa !21
  br label %bb140
bb140:
  %t438 = load i1, ptr %l236, !tbaa !21
  br i1 %t438, label %bb141, label %bb142
bb141:
  %t439 = load ptr, ptr %l1, !tbaa !29
  %t441 = getelementptr { i64, [3 x i64] }, ptr %t439, i32 0, i32 1
  %t442 = getelementptr { %"compiler/source:Span", ptr }, ptr %t441, i32 0, i32 1
  %t443 = load ptr, ptr %t442
  store ptr %t443, ptr %l23, !tbaa !29
  br label %bb143
bb142:
  br label %bb152
bb143:
  %t445 = load ptr, ptr %l0, !tbaa !29
  %t446 = load ptr, ptr %l23, !tbaa !29
  %t448 = getelementptr %"compiler/typed:Join", ptr %t446, i32 0, i32 0
  %t449 = load ptr, ptr %t448, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eflBlockOf(ptr %v0, ptr %v1, ptr %t445, ptr %t449)
  br label %bb144
bb144:
  %t453 = load ptr, ptr %l23, !tbaa !29
  %t455 = getelementptr %"compiler/typed:Join", ptr %t453, i32 0, i32 2
  %t456 = load { i64, ptr }, ptr %t455, !tbaa !27
  store { i64, ptr } %t456, ptr %l24, !tbaa !27
  store i64 0, ptr %l25, !tbaa !24
  %t458 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t460 = extractvalue { i64, ptr } %t458, 0
  store i64 %t460, ptr %l26, !tbaa !24
  br label %bb145
bb145:
  %t462 = load i64, ptr %l25, !tbaa !24
  %t463 = load i64, ptr %l26, !tbaa !24
  %t466 = icmp slt i64 %t462, %t463
  %t468 = xor i1 %t466, true
  br i1 %t468, label %bb146, label %bb147
bb146:
  br label %bb151
bb147:
  br label %bb148
bb148:
  %t470 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t470, ptr %l253, !tbaa !27
  %t471 = load i64, ptr %l25, !tbaa !24
  %t473 = getelementptr { i64, ptr }, ptr %l253, i32 0, i32 1
  %t474 = load ptr, ptr %t473, !tbaa !27
  %t475 = getelementptr ptr, ptr %t474, i64 %t471
  %t476 = load ptr, ptr %t475, !tbaa !39
  %t478 = load ptr, ptr %l0, !tbaa !29
  %t481 = getelementptr %"compiler/typed:Clause", ptr %t476, i32 0, i32 3
  %t482 = load ptr, ptr %t481, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eflBlockOf(ptr %v0, ptr %v1, ptr %t478, ptr %t482)
  br label %bb149
bb149:
  br label %bb150
bb150:
  %t485 = load i64, ptr %l25, !tbaa !24
  %t488 = add i64 %t485, 1
  store i64 %t488, ptr %l25, !tbaa !24
  br label %bb145
bb151:
  br label %bb202
bb152:
  %t490 = load ptr, ptr %l1, !tbaa !29
  store ptr %t490, ptr %l262, !tbaa !29
  store i1 false, ptr %l263, !tbaa !21
  %t491 = load ptr, ptr %l262, !tbaa !29
  %t492 = icmp ne ptr %t491, null
  br i1 %t492, label %bb153, label %bb154
bb153:
  %t494 = load ptr, ptr %l262, !tbaa !29
  %t495 = load i64, ptr %t494, !range !{i64 0, i64 17}
  %t497 = icmp eq i64 %t495, 14
  store i1 %t497, ptr %l263, !tbaa !21
  br label %bb154
bb154:
  %t498 = load i1, ptr %l263, !tbaa !21
  br i1 %t498, label %bb155, label %bb156
bb155:
  %t499 = load ptr, ptr %l1, !tbaa !29
  %t501 = getelementptr { i64, [3 x i64] }, ptr %t499, i32 0, i32 1
  %t502 = getelementptr { %"compiler/source:Span", ptr }, ptr %t501, i32 0, i32 1
  %t503 = load ptr, ptr %t502
  store ptr %t503, ptr %l28, !tbaa !29
  br label %bb157
bb156:
  br label %bb166
bb157:
  %t505 = load ptr, ptr %l0, !tbaa !29
  %t506 = load ptr, ptr %l28, !tbaa !29
  %t508 = getelementptr %"compiler/typed:Spawn", ptr %t506, i32 0, i32 1
  %t509 = load ptr, ptr %t508, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eflExpr(ptr %v0, ptr %v1, ptr %t505, ptr %t509)
  br label %bb158
bb158:
  %t513 = load ptr, ptr %l0, !tbaa !29
  %t515 = getelementptr %"compiler/scope:Scoper", ptr %t513, i32 0, i32 150
  %t516 = load i64, ptr %t515, !tbaa !24
  %t518 = icmp eq i64 %t516, 1
  br i1 %t518, label %bb159, label %bb160
bb159:
  %t520 = load ptr, ptr %l0, !tbaa !29
  %t521 = load ptr, ptr %l28, !tbaa !29
  %t523 = getelementptr %"compiler/typed:Spawn", ptr %t521, i32 0, i32 1
  %t524 = load ptr, ptr %t523, !tbaa !29
  %t527 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecarries(ptr %v0, ptr %v1, ptr %t520, ptr %t524)
  store i1 %t527, ptr %l279
  br label %bb161
bb160:
  store i1 false, ptr %l275, !tbaa !21
  br label %bb162
bb161:
  %t528 = load i1, ptr %l279, !tbaa !21
  store i1 %t528, ptr %l275, !tbaa !21
  br label %bb162
bb162:
  %t529 = load i1, ptr %l275, !tbaa !21
  br i1 %t529, label %bb163, label %bb164
bb163:
  %t530 = load ptr, ptr %l0, !tbaa !29
  %t532 = getelementptr %"compiler/scope:Scoper", ptr %t530, i32 0, i32 149
  store i1 true, ptr %t532, !tbaa !21
  br label %bb165
bb164:
  br label %bb165
bb165:
  br label %bb202
bb166:
  %t533 = load ptr, ptr %l1, !tbaa !29
  store ptr %t533, ptr %l281, !tbaa !29
  store i1 false, ptr %l282, !tbaa !21
  %t534 = load ptr, ptr %l281, !tbaa !29
  %t535 = icmp ne ptr %t534, null
  br i1 %t535, label %bb167, label %bb168
bb167:
  %t537 = load ptr, ptr %l281, !tbaa !29
  %t538 = load i64, ptr %t537, !range !{i64 0, i64 17}
  %t540 = icmp eq i64 %t538, 15
  store i1 %t540, ptr %l282, !tbaa !21
  br label %bb168
bb168:
  %t541 = load i1, ptr %l282, !tbaa !21
  br i1 %t541, label %bb169, label %bb170
bb169:
  %t542 = load ptr, ptr %l1, !tbaa !29
  %t544 = getelementptr { i64, [3 x i64] }, ptr %t542, i32 0, i32 1
  %t545 = getelementptr { %"compiler/source:Span", ptr }, ptr %t544, i32 0, i32 1
  %t546 = load ptr, ptr %t545
  store ptr %t546, ptr %l29, !tbaa !29
  br label %bb171
bb170:
  br label %bb180
bb171:
  %t548 = load ptr, ptr %l0, !tbaa !29
  %t549 = load ptr, ptr %l29, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eflExpr(ptr %v0, ptr %v1, ptr %t548, ptr %t549)
  br label %bb172
bb172:
  %t553 = load ptr, ptr %l0, !tbaa !29
  %t555 = getelementptr %"compiler/scope:Scoper", ptr %t553, i32 0, i32 150
  %t556 = load i64, ptr %t555, !tbaa !24
  %t558 = icmp eq i64 %t556, 1
  br i1 %t558, label %bb173, label %bb174
bb173:
  %t560 = load ptr, ptr %l0, !tbaa !29
  %t561 = load ptr, ptr %l29, !tbaa !29
  %t564 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecarries(ptr %v0, ptr %v1, ptr %t560, ptr %t561)
  store i1 %t564, ptr %l296
  br label %bb175
bb174:
  store i1 false, ptr %l293, !tbaa !21
  br label %bb176
bb175:
  %t565 = load i1, ptr %l296, !tbaa !21
  store i1 %t565, ptr %l293, !tbaa !21
  br label %bb176
bb176:
  %t566 = load i1, ptr %l293, !tbaa !21
  br i1 %t566, label %bb177, label %bb178
bb177:
  %t567 = load ptr, ptr %l0, !tbaa !29
  %t569 = getelementptr %"compiler/scope:Scoper", ptr %t567, i32 0, i32 149
  store i1 true, ptr %t569, !tbaa !21
  br label %bb179
bb178:
  br label %bb179
bb179:
  br label %bb202
bb180:
  %t570 = load ptr, ptr %l1, !tbaa !29
  store ptr %t570, ptr %l298, !tbaa !29
  store i1 false, ptr %l299, !tbaa !21
  %t571 = load ptr, ptr %l298, !tbaa !29
  %t572 = icmp ne ptr %t571, null
  br i1 %t572, label %bb181, label %bb182
bb181:
  %t574 = load ptr, ptr %l298, !tbaa !29
  %t575 = load i64, ptr %t574, !range !{i64 0, i64 17}
  %t577 = icmp eq i64 %t575, 16
  store i1 %t577, ptr %l299, !tbaa !21
  br label %bb182
bb182:
  %t578 = load i1, ptr %l299, !tbaa !21
  br i1 %t578, label %bb183, label %bb184
bb183:
  %t579 = load ptr, ptr %l1, !tbaa !29
  %t581 = getelementptr { i64, [3 x i64] }, ptr %t579, i32 0, i32 1
  %t582 = getelementptr { %"compiler/source:Span", ptr }, ptr %t581, i32 0, i32 1
  %t583 = load ptr, ptr %t582
  store ptr %t583, ptr %l30, !tbaa !29
  br label %bb185
bb184:
  br label %bb197
bb185:
  %t585 = load ptr, ptr %l0, !tbaa !29
  %t586 = load ptr, ptr %l30, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eflExpr(ptr %v0, ptr %v1, ptr %t585, ptr %t586)
  br label %bb186
bb186:
  %t589 = load ptr, ptr %l0, !tbaa !29
  %t591 = getelementptr %"compiler/scope:Scoper", ptr %t589, i32 0, i32 150
  %t592 = load i64, ptr %t591, !tbaa !24
  %t594 = icmp eq i64 %t592, 1
  br i1 %t594, label %bb187, label %bb188
bb187:
  %t596 = load ptr, ptr %l0, !tbaa !29
  store ptr %t596, ptr %l310, !tbaa !29
  %t597 = load ptr, ptr %l30, !tbaa !29
  %t599 = icmp eq ptr %t597, null
  br i1 %t599, label %bb189, label %bb190
bb188:
  store i1 false, ptr %l309, !tbaa !21
  br label %bb193
bb189:
  call void @__olang_check_failed(ptr @olang_loc_86dbdc94d883d21d_a5f7ab2189e86539)
  unreachable
bb190:
  br label %bb191
bb191:
  %t601 = load ptr, ptr %l30, !tbaa !29
  %t602 = load ptr, ptr %l310, !tbaa !29
  %t604 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecarries(ptr %v0, ptr %v1, ptr %t602, ptr %t601)
  store i1 %t604, ptr %l314
  br label %bb192
bb192:
  %t605 = load i1, ptr %l314, !tbaa !21
  store i1 %t605, ptr %l309, !tbaa !21
  br label %bb193
bb193:
  %t606 = load i1, ptr %l309, !tbaa !21
  br i1 %t606, label %bb194, label %bb195
bb194:
  %t607 = load ptr, ptr %l0, !tbaa !29
  %t609 = getelementptr %"compiler/scope:Scoper", ptr %t607, i32 0, i32 149
  store i1 true, ptr %t609, !tbaa !21
  br label %bb196
bb195:
  br label %bb196
bb196:
  br label %bb202
bb197:
  br i1 true, label %bb198, label %bb199
bb198:
  br label %bb200
bb199:
  br label %bb201
bb200:
  br label %bb202
bb201:
  call void @__olang_check_failed(ptr @olang_loc_815b49be05c0135_ff7bc6f5d03d3901)
  unreachable
bb202:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eflowRun(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l18 = alloca i64
  %l21 = alloca i64
  %l46 = alloca i64
  %l49 = alloca i64
  %l68 = alloca { i64, ptr }
  %l78 = alloca i1
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l3, !tbaa !24
  store i64 6, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t1 = load i64, ptr %l4, !tbaa !24
  %t2 = load i64, ptr %l3, !tbaa !24
  %t5 = icmp sgt i64 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load i64, ptr %l5, !tbaa !24
  %t9 = icmp sgt i64 %t7, 0
  br i1 %t9, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l18, !tbaa !24
  br label %bb6
bb3:
  %t11 = load i64, ptr %l4, !tbaa !24
  %t12 = load i64, ptr %l3, !tbaa !24
  %t15 = sub i64 %t11, %t12
  %t16 = load i64, ptr %l5, !tbaa !24
  %t19 = add i64 %t15, %t16
  %t21 = sub i64 %t19, 1
  %t22 = load i64, ptr %l5, !tbaa !24
  %t25 = sdiv i64 %t21, %t22
  store i64 %t25, ptr %l21, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l21, !tbaa !24
  br label %bb5
bb5:
  %t27 = load i64, ptr %l21, !tbaa !24
  store i64 %t27, ptr %l18, !tbaa !24
  br label %bb6
bb6:
  %t28 = load i64, ptr %l18, !tbaa !24
  store i64 %t28, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb7
bb7:
  %t29 = load i64, ptr %l7, !tbaa !24
  %t30 = load i64, ptr %l6, !tbaa !24
  %t33 = icmp slt i64 %t29, %t30
  %t35 = xor i1 %t33, true
  br i1 %t35, label %bb8, label %bb9
bb8:
  br label %bb31
bb9:
  br label %bb10
bb10:
  %t37 = load i64, ptr %l3, !tbaa !24
  %t38 = load i64, ptr %l7, !tbaa !24
  %t39 = load i64, ptr %l5, !tbaa !24
  %t42 = mul i64 %t38, %t39
  %t45 = add i64 %t37, %t42
  store i64 %t45, ptr %l8, !tbaa !24
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/scope:Scoper", ptr %t47, i32 0, i32 154
  store i1 false, ptr %t49, !tbaa !21
  store i64 %a2, ptr %l9, !tbaa !24
  %t52 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t54 = extractvalue { i64, ptr } %t52, 0
  store i64 %t54, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t56 = load i64, ptr %l10, !tbaa !24
  %t57 = load i64, ptr %l9, !tbaa !24
  %t60 = icmp sgt i64 %t56, %t57
  br i1 %t60, label %bb11, label %bb12
bb11:
  %t62 = load i64, ptr %l11, !tbaa !24
  %t64 = icmp sgt i64 %t62, 0
  br i1 %t64, label %bb13, label %bb14
bb12:
  store i64 0, ptr %l46, !tbaa !24
  br label %bb16
bb13:
  %t66 = load i64, ptr %l10, !tbaa !24
  %t67 = load i64, ptr %l9, !tbaa !24
  %t70 = sub i64 %t66, %t67
  %t71 = load i64, ptr %l11, !tbaa !24
  %t74 = add i64 %t70, %t71
  %t76 = sub i64 %t74, 1
  %t77 = load i64, ptr %l11, !tbaa !24
  %t80 = sdiv i64 %t76, %t77
  store i64 %t80, ptr %l49, !tbaa !24
  br label %bb15
bb14:
  store i64 0, ptr %l49, !tbaa !24
  br label %bb15
bb15:
  %t82 = load i64, ptr %l49, !tbaa !24
  store i64 %t82, ptr %l46, !tbaa !24
  br label %bb16
bb16:
  %t83 = load i64, ptr %l46, !tbaa !24
  store i64 %t83, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb17
bb17:
  %t84 = load i64, ptr %l13, !tbaa !24
  %t85 = load i64, ptr %l12, !tbaa !24
  %t88 = icmp slt i64 %t84, %t85
  %t90 = xor i1 %t88, true
  br i1 %t90, label %bb18, label %bb19
bb18:
  br label %bb23
bb19:
  br label %bb20
bb20:
  %t92 = load i64, ptr %l9, !tbaa !24
  %t93 = load i64, ptr %l13, !tbaa !24
  %t94 = load i64, ptr %l11, !tbaa !24
  %t97 = mul i64 %t93, %t94
  %t100 = add i64 %t92, %t97
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t103 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t103, ptr %l68, !tbaa !27
  %t106 = getelementptr { i64, ptr }, ptr %l68, i32 0, i32 1
  %t107 = load ptr, ptr %t106, !tbaa !27
  %t108 = getelementptr ptr, ptr %t107, i64 %t100
  %t109 = load ptr, ptr %t108, !tbaa !39
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eflStmt(ptr %v0, ptr %v1, ptr %t102, ptr %t109)
  br label %bb21
bb21:
  br label %bb22
bb22:
  %t113 = load i64, ptr %l13, !tbaa !24
  %t116 = add i64 %t113, 1
  store i64 %t116, ptr %l13, !tbaa !24
  br label %bb17
bb23:
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t120 = getelementptr %"compiler/scope:Scoper", ptr %t118, i32 0, i32 154
  %t121 = load i1, ptr %t120, !tbaa !21
  %t123 = xor i1 %t121, true
  br i1 %t123, label %bb24, label %bb25
bb24:
  store i1 true, ptr %l78, !tbaa !21
  br label %bb26
bb25:
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t127 = getelementptr %"compiler/scope:Scoper", ptr %t125, i32 0, i32 149
  %t128 = load i1, ptr %t127, !tbaa !21
  store i1 %t128, ptr %l78, !tbaa !21
  br label %bb26
bb26:
  %t130 = load i1, ptr %l78, !tbaa !21
  br i1 %t130, label %bb27, label %bb28
bb27:
  br label %bb31
bb28:
  br label %bb29
bb29:
  br label %bb30
bb30:
  %t131 = load i64, ptr %l7, !tbaa !24
  %t134 = add i64 %t131, 1
  store i64 %t134, ptr %l7, !tbaa !24
  br label %bb7
bb31:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eflowStart(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca { i64, [2 x i64] }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l19 = alloca ptr
  %l29 = alloca %"compiler/typed:Local"
  %l38 = alloca { i64, [2 x i64] }
  %l41 = alloca i64
  %l45 = alloca i64
  %l48 = alloca i64
  %l69 = alloca { i64, [2 x i64] }
  %l71 = alloca { i64, [2 x i64] }
  %l73 = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 146
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t3)
  br label %bb1
bb1:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/scope:Scoper", ptr %t5, i32 0, i32 147
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t7)
  br label %bb2
bb2:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/scope:Scoper", ptr %t9, i32 0, i32 148
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t11)
  br label %bb3
bb3:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/scope:Scoper", ptr %t13, i32 0, i32 149
  store i1 false, ptr %t15, !tbaa !21
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load i64, ptr %l2, !tbaa !24
  %t20 = getelementptr %"compiler/scope:Scoper", ptr %t16, i32 0, i32 150
  store i64 %t17, ptr %t20, !tbaa !24
  %t21 = load ptr, ptr %l0, !tbaa !29
  store ptr %t21, ptr %l19, !tbaa !29
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/scope:Scoper", ptr %t22, i32 0, i32 28
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t27 = icmp eq ptr %t25, null
  br i1 %t27, label %bb4, label %bb5
bb4:
  call void @__olang_check_failed(ptr @olang_loc_8ac0dfde81ed52b7_ecd118d92b351383)
  unreachable
bb5:
  br label %bb6
bb6:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/scope:Scoper", ptr %t29, i32 0, i32 28
  %t32 = load ptr, ptr %t31, !tbaa !29
  %t35 = getelementptr %"compiler/typed:Body", ptr %t32, i32 0, i32 7
  %t36 = load i32, ptr %l1, !tbaa !23
  %t38 = sext i32 %t36 to i64
  %t41 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t35, i64 %t38)
  store %"compiler/typed:Local" %t41, ptr %l29
  br label %bb7
bb7:
  %t42 = getelementptr %"compiler/typed:Local", ptr %l29, i32 0, i32 3
  %t43 = load i32, ptr %t42, !tbaa !23
  %t45 = load ptr, ptr %l19, !tbaa !29
  %t46 = getelementptr %"compiler/scope:Scoper", ptr %t45, i32 0, i32 153
  store i32 %t43, ptr %t46, !tbaa !23
  %t47 = load i64, ptr %l2, !tbaa !24
  %t49 = icmp eq i64 %t47, 1
  br i1 %t49, label %bb8, label %bb9
bb8:
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = getelementptr %"compiler/scope:Scoper", ptr %t51, i32 0, i32 146
  %t54 = load i32, ptr %l1, !tbaa !23
  %t56 = sext i32 %t54 to i64
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t53, i64 %t56)
  br label %bb10
bb9:
  br label %bb11
bb10:
  br label %ret
bb11:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eresultTerm(ptr %v0, ptr %t59, i64 0)
  store { i64, [2 x i64] } %t61, ptr %l38
  br label %bb12
bb12:
  %t62 = load { i64, [2 x i64] }, ptr %l38
  store { i64, [2 x i64] } %t62, ptr %l3
  store i64 0, ptr %l4, !tbaa !24
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/scope:Scoper", ptr %t63, i32 0, i32 36
  %t67 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eLen_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t65)
  store i64 %t67, ptr %l41
  br label %bb13
bb13:
  %t68 = load i64, ptr %l41, !tbaa !24
  store i64 %t68, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t69 = load i64, ptr %l5, !tbaa !24
  %t70 = load i64, ptr %l4, !tbaa !24
  %t73 = icmp sgt i64 %t69, %t70
  br i1 %t73, label %bb14, label %bb15
bb14:
  %t75 = load i64, ptr %l6, !tbaa !24
  %t77 = icmp sgt i64 %t75, 0
  br i1 %t77, label %bb16, label %bb17
bb15:
  store i64 0, ptr %l45, !tbaa !24
  br label %bb19
bb16:
  %t79 = load i64, ptr %l5, !tbaa !24
  %t80 = load i64, ptr %l4, !tbaa !24
  %t83 = sub i64 %t79, %t80
  %t84 = load i64, ptr %l6, !tbaa !24
  %t87 = add i64 %t83, %t84
  %t89 = sub i64 %t87, 1
  %t90 = load i64, ptr %l6, !tbaa !24
  %t93 = sdiv i64 %t89, %t90
  store i64 %t93, ptr %l48, !tbaa !24
  br label %bb18
bb17:
  store i64 0, ptr %l48, !tbaa !24
  br label %bb18
bb18:
  %t95 = load i64, ptr %l48, !tbaa !24
  store i64 %t95, ptr %l45, !tbaa !24
  br label %bb19
bb19:
  %t96 = load i64, ptr %l45, !tbaa !24
  store i64 %t96, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb20
bb20:
  %t97 = load i64, ptr %l8, !tbaa !24
  %t98 = load i64, ptr %l7, !tbaa !24
  %t101 = icmp slt i64 %t97, %t98
  %t103 = xor i1 %t101, true
  br i1 %t103, label %bb21, label %bb22
bb21:
  br label %bb31
bb22:
  br label %bb23
bb23:
  %t105 = load i64, ptr %l4, !tbaa !24
  %t106 = load i64, ptr %l8, !tbaa !24
  %t107 = load i64, ptr %l6, !tbaa !24
  %t110 = mul i64 %t106, %t107
  %t113 = add i64 %t105, %t110
  store i64 %t113, ptr %l9, !tbaa !24
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t117 = getelementptr %"compiler/scope:Scoper", ptr %t115, i32 0, i32 36
  %t118 = load i64, ptr %l9, !tbaa !24
  %t121 = call { i64, [2 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eAt_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t117, i64 %t118)
  store { i64, [2 x i64] } %t121, ptr %l69
  br label %bb24
bb24:
  %t122 = load { i64, [2 x i64] }, ptr %l3
  store { i64, [2 x i64] } %t122, ptr %l71
  %t125 = call i1 @olang_2emir_2eHelperKind_2eEqual_2ecompiler_2fscope_3aTerm(ptr %l69, ptr %l71)
  store i1 %t125, ptr %l73
  br label %bb25
bb25:
  %t126 = load i1, ptr %l73, !tbaa !21
  br i1 %t126, label %bb26, label %bb27
bb26:
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t129 = getelementptr %"compiler/scope:Scoper", ptr %t127, i32 0, i32 146
  %t130 = load i64, ptr %l9, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t129, i64 %t130)
  br label %bb28
bb27:
  br label %bb29
bb28:
  br label %bb29
bb29:
  br label %bb30
bb30:
  %t133 = load i64, ptr %l8, !tbaa !24
  %t136 = add i64 %t133, 1
  store i64 %t136, ptr %l8, !tbaa !24
  br label %bb20
bb31:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2efsReaches(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i1 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l4 = alloca i32
  %l11 = alloca i32
  %l17 = alloca i1
  %l20 = alloca i1
  %l23 = alloca ptr
  %l28 = alloca i32
  %l29 = alloca i32
  %l36 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 56
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eClear_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t3)
  br label %bb1
bb1:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/scope:Scoper", ptr %t5, i32 0, i32 0
  %t8 = load ptr, ptr %t7, !tbaa !29
  %t10 = getelementptr %"compiler/generic:Program", ptr %t8, i32 0, i32 2
  %t14 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t10, i32 %a1)
  store i32 %t14, ptr %l11
  br label %bb2
bb2:
  %t15 = load i32, ptr %l11, !tbaa !23
  store i32 %t15, ptr %l4, !tbaa !23
  %t18 = xor i1 %a3, true
  br i1 %t18, label %bb3, label %bb4
bb3:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load i32, ptr %l4, !tbaa !23
  %t22 = load i32, ptr %l2, !tbaa !23
  %t26 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2efsReach(ptr %v0, ptr %t20, i32 %t21, i32 %t22)
  store i1 %t26, ptr %l17
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t27 = load i1, ptr %l17, !tbaa !21
  store i1 %t27, ptr %rv
  br label %ret
bb6:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load i32, ptr %l4, !tbaa !23
  %t32 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisRef(ptr %v0, ptr %t28, i32 %t29)
  store i1 %t32, ptr %l20
  br label %bb7
bb7:
  %t33 = load i1, ptr %l20, !tbaa !21
  br i1 %t33, label %bb8, label %bb9
bb8:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/scope:Scoper", ptr %t34, i32 0, i32 0
  %t37 = load ptr, ptr %t36, !tbaa !29
  %t39 = getelementptr %"compiler/generic:Program", ptr %t37, i32 0, i32 2
  store ptr %t39, ptr %l23, !tbaa !29
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/scope:Scoper", ptr %t40, i32 0, i32 0
  %t43 = load ptr, ptr %t42, !tbaa !29
  %t45 = getelementptr %"compiler/generic:Program", ptr %t43, i32 0, i32 2
  %t46 = load i32, ptr %l4, !tbaa !23
  %t49 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t45, i32 %t46)
  store i32 %t49, ptr %l28
  br label %bb10
bb9:
  br label %bb12
bb10:
  %t50 = load ptr, ptr %l23, !tbaa !29
  %t51 = load i32, ptr %l28, !tbaa !23
  %t52 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t50, i32 %t51)
  store i32 %t52, ptr %l29
  br label %bb11
bb11:
  %t53 = load i32, ptr %l29, !tbaa !23
  store i32 %t53, ptr %l4, !tbaa !23
  br label %bb12
bb12:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/scope:Scoper", ptr %t54, i32 0, i32 56
  %t57 = load i32, ptr %l4, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t56, i32 %t57)
  br label %bb13
bb13:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t61 = load i32, ptr %l4, !tbaa !23
  %t62 = load i32, ptr %l2, !tbaa !23
  %t66 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2efsParts(ptr %v0, ptr %t60, i32 %t61, i32 %t62)
  store i1 %t66, ptr %l36
  br label %bb14
bb14:
  %t67 = load i1, ptr %l36, !tbaa !21
  store i1 %t67, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2egiveTails(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l4 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l5 = alloca ptr
  %l6 = alloca i64
  %l8 = alloca i1
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca %"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9"
  %l17 = alloca ptr
  %l18 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l20 = alloca i64
  %l22 = alloca i64
  %l27 = alloca i64
  %l36 = alloca i64
  %l40 = alloca i64
  %l43 = alloca i64
  %l63 = alloca i64
  %l65 = alloca i1
  %l66 = alloca ptr
  %l69 = alloca i64
  %l70 = alloca i1
  %l71 = alloca ptr
  %l74 = alloca i64
  %l75 = alloca i1
  %l77 = alloca ptr
  %l80 = alloca i64
  %l81 = alloca ptr
  %l84 = alloca i64
  %l89 = alloca %"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9"
  %l90 = alloca i64
  %l92 = alloca i64
  %l93 = alloca i32
  %l95 = alloca i1
  %l99 = alloca ptr
  %l105 = alloca { i64, ptr }
  %l108 = alloca i1
  %l109 = alloca ptr
  %l116 = alloca i32
  %s0 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %t198 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %s0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l18
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l18
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %l4
  store ptr %a3, ptr %l5, !tbaa !29
  store i64 0, ptr %l6, !tbaa !24
  br label %bb2
bb2:
  %t5 = load i64, ptr %l6, !tbaa !24
  store i64 %t5, ptr %l20, !tbaa !24
  %t6 = load ptr, ptr %l5, !tbaa !29
  %t8 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v3, ptr %t6)
  store i64 %t8, ptr %l22
  br label %bb3
bb3:
  %t9 = load i64, ptr %l20, !tbaa !24
  %t10 = load i64, ptr %l22, !tbaa !24
  %t11 = icmp slt i64 %t9, %t10
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb4, label %bb5
bb4:
  br label %bb10
bb5:
  br label %bb6
bb6:
  %t15 = load ptr, ptr %l5, !tbaa !29
  %t16 = load i64, ptr %l6, !tbaa !24
  %t19 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v3, ptr %t15, i64 %t16)
  store i64 %t19, ptr %l27
  br label %bb7
bb7:
  %t20 = load i64, ptr %l27, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %s0, ptr %l4, i64 %t20, i1 true)
  br label %bb8
bb8:
  br label %bb9
bb9:
  %t24 = load i64, ptr %l6, !tbaa !24
  %t27 = add i64 %t24, 1
  store i64 %t27, ptr %l6, !tbaa !24
  br label %bb2
bb10:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb11
bb11:
  %t29 = load i1, ptr %l8, !tbaa !21
  %t31 = xor i1 %t29, true
  br i1 %t31, label %bb12, label %bb13
bb12:
  br label %bb44
bb13:
  br label %bb14
bb14:
  store i1 false, ptr %l8, !tbaa !21
  store i64 0, ptr %l9, !tbaa !24
  %t33 = load ptr, ptr %l1, !tbaa !29
  %t35 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t33)
  store i64 %t35, ptr %l36
  br label %bb15
bb15:
  %t36 = load i64, ptr %l36, !tbaa !24
  store i64 %t36, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t37 = load i64, ptr %l10, !tbaa !24
  %t38 = load i64, ptr %l9, !tbaa !24
  %t41 = icmp sgt i64 %t37, %t38
  br i1 %t41, label %bb16, label %bb17
bb16:
  %t43 = load i64, ptr %l11, !tbaa !24
  %t45 = icmp sgt i64 %t43, 0
  br i1 %t45, label %bb18, label %bb19
bb17:
  store i64 0, ptr %l40, !tbaa !24
  br label %bb21
bb18:
  %t47 = load i64, ptr %l10, !tbaa !24
  %t48 = load i64, ptr %l9, !tbaa !24
  %t51 = sub i64 %t47, %t48
  %t52 = load i64, ptr %l11, !tbaa !24
  %t55 = add i64 %t51, %t52
  %t57 = sub i64 %t55, 1
  %t58 = load i64, ptr %l11, !tbaa !24
  %t61 = sdiv i64 %t57, %t58
  store i64 %t61, ptr %l43, !tbaa !24
  br label %bb20
bb19:
  store i64 0, ptr %l43, !tbaa !24
  br label %bb20
bb20:
  %t63 = load i64, ptr %l43, !tbaa !24
  store i64 %t63, ptr %l40, !tbaa !24
  br label %bb21
bb21:
  %t64 = load i64, ptr %l40, !tbaa !24
  store i64 %t64, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb22
bb22:
  %t65 = load i64, ptr %l13, !tbaa !24
  %t66 = load i64, ptr %l12, !tbaa !24
  %t69 = icmp slt i64 %t65, %t66
  %t71 = xor i1 %t69, true
  br i1 %t71, label %bb23, label %bb24
bb23:
  br label %bb42
bb24:
  br label %bb25
bb25:
  %t73 = load i64, ptr %l9, !tbaa !24
  %t74 = load i64, ptr %l13, !tbaa !24
  %t75 = load i64, ptr %l11, !tbaa !24
  %t78 = mul i64 %t74, %t75
  %t81 = add i64 %t73, %t78
  store i64 %t81, ptr %l14, !tbaa !24
  %t83 = load ptr, ptr %l2, !tbaa !29
  %t84 = load i64, ptr %l14, !tbaa !24
  %t87 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v2, ptr %t83, i64 %t84)
  store i64 %t87, ptr %l63
  br label %bb26
bb26:
  %t88 = load i64, ptr %l63, !tbaa !24
  %t89 = icmp slt i64 %t88, 0
  br i1 %t89, label %bb27, label %bb28
bb27:
  store i1 true, ptr %l65, !tbaa !21
  br label %bb33
bb28:
  store ptr %l4, ptr %l66, !tbaa !29
  %t91 = load ptr, ptr %l1, !tbaa !29
  %t92 = load i64, ptr %l14, !tbaa !24
  %t95 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t91, i64 %t92)
  store i64 %t95, ptr %l69
  br label %bb29
bb29:
  %t96 = load ptr, ptr %l66, !tbaa !29
  %t97 = load i64, ptr %l69, !tbaa !24
  %t98 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %s0, ptr %t96, i64 %t97)
  store i1 %t98, ptr %l70
  br label %bb30
bb30:
  store ptr %l4, ptr %l71, !tbaa !29
  %t99 = load ptr, ptr %l2, !tbaa !29
  %t100 = load i64, ptr %l14, !tbaa !24
  %t103 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v2, ptr %t99, i64 %t100)
  store i64 %t103, ptr %l74
  br label %bb31
bb31:
  %t104 = load ptr, ptr %l71, !tbaa !29
  %t105 = load i64, ptr %l74, !tbaa !24
  %t106 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %s0, ptr %t104, i64 %t105)
  store i1 %t106, ptr %l75
  br label %bb32
bb32:
  %t107 = load i1, ptr %l70, !tbaa !21
  %t108 = load i1, ptr %l75, !tbaa !21
  %t109 = icmp eq i1 %t107, %t108
  store i1 %t109, ptr %l65, !tbaa !21
  br label %bb33
bb33:
  %t111 = load i1, ptr %l65, !tbaa !21
  br i1 %t111, label %bb34, label %bb35
bb34:
  br label %bb41
bb35:
  br label %bb36
bb36:
  store ptr %l4, ptr %l77, !tbaa !29
  %t112 = load ptr, ptr %l1, !tbaa !29
  %t113 = load i64, ptr %l14, !tbaa !24
  %t116 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t112, i64 %t113)
  store i64 %t116, ptr %l80
  br label %bb37
bb37:
  %t117 = load ptr, ptr %l77, !tbaa !29
  %t118 = load i64, ptr %l80, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %s0, ptr %t117, i64 %t118, i1 true)
  br label %bb38
bb38:
  store ptr %l4, ptr %l81, !tbaa !29
  %t119 = load ptr, ptr %l2, !tbaa !29
  %t120 = load i64, ptr %l14, !tbaa !24
  %t123 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v2, ptr %t119, i64 %t120)
  store i64 %t123, ptr %l84
  br label %bb39
bb39:
  %t124 = load ptr, ptr %l81, !tbaa !29
  %t125 = load i64, ptr %l84, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %s0, ptr %t124, i64 %t125, i1 true)
  br label %bb40
bb40:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb41
bb41:
  %t126 = load i64, ptr %l13, !tbaa !24
  %t129 = add i64 %t126, 1
  store i64 %t129, ptr %l13, !tbaa !24
  br label %bb22
bb42:
  br label %bb43
bb43:
  br label %bb11
bb44:
  %t132 = call %"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eKeys_3cI64_2c_20Bool_3e(ptr %s0, ptr %s0, ptr %l4)
  store %"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9" %t132, ptr %l89
  br label %bb45
bb45:
  %t133 = load %"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9", ptr %l89
  store %"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9" %t133, ptr %l15
  br label %bb46
bb46:
  store %olang.scope zeroinitializer, ptr %s10
  %t135 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapKeyIter_3cI64_2c_20Bool_3e_2eNext_3cI64_2c_20Bool_3e(ptr %s0, ptr %l15)
  %t136 = extractvalue { i32, i64 } %t135, 1
  %t137 = extractvalue { i32, i64 } %t135, 0
  store i32 %t137, ptr %l93
  %t138 = icmp ne i32 %t137, 0
  br i1 %t138, label %bb48, label %ok.139, !prof !99
ok.139:
  store i64 %t136, ptr %l92
  br label %bb47
bb47:
  %t140 = load i64, ptr %l92, !tbaa !24
  store i64 %t140, ptr %l90, !tbaa !24
  br label %bb50
bb48:
  %t141 = load i32, ptr %l93, !tbaa !23
  %t142 = ashr i32 %t141, 16
  %t144 = icmp eq i32 %t142, 1
  store i1 %t144, ptr %l95, !tbaa !21
  br label %bb49
bb49:
  call void @__olang_scope_close(ptr %s10)
  br label %bb60
bb50:
  %t145 = load i64, ptr %l90, !tbaa !24
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t148 = getelementptr %"compiler/scope:Scoper", ptr %t146, i32 0, i32 1
  %t152 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t148, i64 %t145)
  store ptr %t152, ptr %l99
  br label %bb51
bb51:
  %t153 = load ptr, ptr %l99, !tbaa !29
  store ptr %t153, ptr %l17, !tbaa !29
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t156 = getelementptr %"compiler/scope:Scoper", ptr %t154, i32 0, i32 0
  %t157 = load ptr, ptr %t156, !tbaa !29
  %t159 = getelementptr %"compiler/generic:Program", ptr %t157, i32 0, i32 2
  %t160 = load ptr, ptr %l17, !tbaa !29
  %t162 = getelementptr %"compiler/typed:Body", ptr %t160, i32 0, i32 2
  %t163 = load i32, ptr %t162, !tbaa !23
  %t166 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopeVarsOf(ptr %v0, ptr %s10, ptr %t159, i32 %t163)
  store { i64, ptr } %t166, ptr %l105
  br label %bb52
bb52:
  %t167 = load { i64, ptr }, ptr %l105, !tbaa !27
  %t168 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_37, 0
  %t169 = insertvalue { ptr, ptr } %t168, ptr null, 1
  %t172 = extractvalue { ptr, ptr } %t169, 0
  %t173 = extractvalue { ptr, ptr } %t169, 1
  %t174 = call i1 @std_2fprelude_2farray_2eArray_3cI64_3e_2eSome_3cI64_2c_20_3f_3e(ptr %s10, ptr %s10, { i64, ptr } %t167, ptr %t172, ptr %t173)
  store i1 %t174, ptr %l108
  br label %bb53
bb53:
  %t175 = load i1, ptr %l108, !tbaa !21
  br i1 %t175, label %bb54, label %bb55
bb54:
  call void @__olang_scope_close(ptr %s10)
  br label %bb59
bb55:
  br label %bb56
bb56:
  %t176 = load ptr, ptr %l17, !tbaa !29
  store ptr %t176, ptr %l109, !tbaa !29
  %t177 = load ptr, ptr %l0, !tbaa !29
  %t179 = getelementptr %"compiler/scope:Scoper", ptr %t177, i32 0, i32 0
  %t180 = load ptr, ptr %t179, !tbaa !29
  %t182 = getelementptr %"compiler/generic:Program", ptr %t180, i32 0, i32 2
  %t183 = load ptr, ptr %l17, !tbaa !29
  %t185 = getelementptr %"compiler/typed:Body", ptr %t183, i32 0, i32 2
  %t186 = load i32, ptr %t185, !tbaa !23
  %t187 = load i64, ptr @G_2ecompiler_2ftypes_2eRoleTail, !tbaa !24
  %t191 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eWithRole(ptr %v0, ptr %t182, i32 %t186, i64 %t187)
  store i32 %t191, ptr %l116
  br label %bb57
bb57:
  %t192 = load i32, ptr %l116, !tbaa !23
  %t193 = load ptr, ptr %l109, !tbaa !29
  %t194 = getelementptr %"compiler/typed:Body", ptr %t193, i32 0, i32 2
  store i32 %t192, ptr %t194, !tbaa !23
  %t195 = load ptr, ptr %l17, !tbaa !29
  %t197 = getelementptr %"compiler/typed:Body", ptr %t195, i32 0, i32 6
  store { i64, [1 x i64] } zeroinitializer, ptr %t198
  %t199 = getelementptr { i64, [1 x i64] }, ptr %t198, i32 0, i32 0
  store i64 1, ptr %t199
  %t200 = load { i64, [1 x i64] }, ptr %t198
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScopeVar_3e_2ePush_3ccompiler_2ftyped_3aScopeVar_3e(ptr %v0, ptr %t197, { i64, [1 x i64] } %t200)
  br label %bb58
bb58:
  call void @__olang_scope_close(ptr %s10)
  br label %bb59
bb59:
  br label %bb46
bb60:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eglobalText(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca %"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9"
  %l3 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l4 = alloca %"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9"
  %l5 = alloca i64
  %l6 = alloca %"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9"
  %l7 = alloca i64
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca { i64, ptr }
  %l14 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l17 = alloca %"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9"
  %l18 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l20 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l21 = alloca i32
  %l23 = alloca i1
  %l24 = alloca ptr
  %l25 = alloca i64
  %l34 = alloca { i64, ptr }
  %l40 = alloca %"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9"
  %l41 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i32
  %l46 = alloca i1
  %l47 = alloca ptr
  %l48 = alloca i64
  %l52 = alloca { i64, ptr }
  %l53 = alloca i1
  %l55 = alloca { i64, ptr }
  %l58 = alloca { i64, ptr }
  %l66 = alloca %"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9"
  %l67 = alloca i64
  %l69 = alloca i64
  %l70 = alloca i32
  %l72 = alloca i1
  %l73 = alloca ptr
  %l74 = alloca i64
  %l78 = alloca i1
  %l79 = alloca i64
  %l84 = alloca i64
  %l86 = alloca { i64, ptr }
  %l92 = alloca ptr
  %l99 = alloca ptr
  %l101 = alloca { i64, ptr }
  %l103 = alloca { i64, ptr }
  %l104 = alloca { i64, ptr }
  %l108 = alloca { i64, ptr }
  %l109 = alloca i64
  %l110 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 326
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/scope:Scoper", ptr %t6, i32 0, i32 327
  %t9 = load { i64, ptr }, ptr %t8, !tbaa !27
  store { i64, ptr } %t9, ptr %l11, !tbaa !27
  %t10 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t10, 0
  store i64 %t11, ptr %l12, !tbaa !24
  %t12 = load i64, ptr %l12, !tbaa !24
  %t13 = mul i64 %t12, 1
  %t14 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t13)
  %t15 = insertvalue { i64, ptr } undef, i64 %t12, 0
  %t16 = insertvalue { i64, ptr } %t15, ptr %t14, 1
  store { i64, ptr } %t16, ptr %l13, !tbaa !27
  %t17 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t18 = load ptr, ptr %t17, !tbaa !27
  %t19 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !27
  %t21 = load i64, ptr %l12, !tbaa !24
  %t22 = mul i64 %t21, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t18, ptr %t20, i64 %t22, i1 false)
  %t23 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t23, ptr %l11, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t24 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t24, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t25 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t25, ptr %l14
  br label %bb4
bb4:
  %t26 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l14
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t26, ptr %l1
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/scope:Scoper", ptr %t27, i32 0, i32 57
  %t31 = call %"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H0d83a40c67cd8749e6caf886dac77c3a(ptr %v0, ptr %v0, ptr %t29)
  store %"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9" %t31, ptr %l17
  br label %bb5
bb5:
  %t32 = load %"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9", ptr %l17
  store %"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9" %t32, ptr %l2
  br label %bb6
bb6:
  store %olang.scope zeroinitializer, ptr %s3
  %t34 = call { i32, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapKeyIter_3cstd_2fpair_3aPair_3cI64_2c_20I6_H50b542c856ab641bdb3083563d5a1f0c(ptr %v0, ptr %l2)
  %t35 = extractvalue { i32, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" } %t34, 1
  %t36 = extractvalue { i32, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" } %t34, 0
  store i32 %t36, ptr %l21
  %t37 = icmp ne i32 %t36, 0
  br i1 %t37, label %bb8, label %ok.38, !prof !99
ok.38:
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t35, ptr %l20
  br label %bb7
bb7:
  %t39 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l20
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t39, ptr %l18
  br label %bb10
bb8:
  %t40 = load i32, ptr %l21, !tbaa !23
  %t41 = ashr i32 %t40, 16
  %t43 = icmp eq i32 %t41, 1
  store i1 %t43, ptr %l23, !tbaa !21
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s3)
  br label %bb16
bb10:
  %t44 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l18
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t44, ptr %l3
  store ptr %l1, ptr %l24, !tbaa !29
  %t45 = call ptr @__olang_scope_hold(ptr %s0)
  %t46 = ptrtoint ptr %t45 to i64
  store i64 %t46, ptr %l25, !tbaa !24
  %t47 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t47, label %bb11, label %bb12
bb11:
  %t49 = call ptr @__olang_region_make(ptr %s0)
  %t50 = ptrtoint ptr %t49 to i64
  store i64 %t50, ptr %l25, !tbaa !24
  br label %bb12
bb12:
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = getelementptr %"compiler/scope:Scoper", ptr %t51, i32 0, i32 0
  %t54 = load ptr, ptr %t53, !tbaa !29
  %t56 = getelementptr %"compiler/generic:Program", ptr %t54, i32 0, i32 2
  %t57 = getelementptr %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l3, i32 0, i32 0
  %t58 = load i64, ptr %t57, !tbaa !24
  %t60 = trunc i64 %t58 to i32
  %t63 = inttoptr i64 0 to ptr
  %t66 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanonNamed(ptr %v0, ptr %s3, ptr %t63, ptr %t56, i32 %t60)
  store { i64, ptr } %t66, ptr %l34
  br label %bb13
bb13:
  %t67 = getelementptr %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l3, i32 0, i32 1
  %t68 = load i64, ptr %t67, !tbaa !24
  %t69 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d38, i32 0, i32 1) }, 1
  %t70 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d38, i32 0, i32 1) }, 0
  %t71 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t72 = extractvalue { i64, ptr } %t71, 1
  %t73 = extractvalue { i64, ptr } %t71, 0
  %t74 = add i64 %t70, %t73
  %t75 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d39, i32 0, i32 1) }, 1
  %t76 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d39, i32 0, i32 1) }, 0
  %t77 = add i64 %t74, %t76
  %t79 = call i64 @__olang_fmt_i64(ptr null, i64 %t68)
  %t80 = add i64 %t77, %t79
  %t81 = load i64, ptr %l25
  %t82 = inttoptr i64 %t81 to ptr
  %t83 = call ptr @__olang_held_alloc(ptr %t82, i64 %t80)
  call void @olang_textcopy(ptr %t83, ptr %t69, i64 %t70)
  %t84 = getelementptr i8, ptr %t83, i64 %t70
  call void @olang_textcopy(ptr %t84, ptr %t72, i64 %t73)
  %t85 = getelementptr i8, ptr %t84, i64 %t73
  call void @olang_textcopy(ptr %t85, ptr %t75, i64 %t76)
  %t86 = getelementptr i8, ptr %t85, i64 %t76
  %t87 = call i64 @__olang_fmt_i64(ptr %t86, i64 %t68)
  %t88 = insertvalue { i64, ptr } undef, i64 %t80, 0
  %t89 = insertvalue { i64, ptr } %t88, ptr %t83, 1
  %t91 = load ptr, ptr %l24, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %t91, { i64, ptr } %t89)
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s3)
  br label %bb15
bb15:
  br label %bb6
bb16:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/scope:Scoper", ptr %t93, i32 0, i32 78
  %t97 = call %"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eKeys_3cI64_2c_20Bool_3e(ptr %v0, ptr %v0, ptr %t95)
  store %"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9" %t97, ptr %l40
  br label %bb17
bb17:
  %t98 = load %"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9", ptr %l40
  store %"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9" %t98, ptr %l4
  br label %bb18
bb18:
  store %olang.scope zeroinitializer, ptr %s6
  %t100 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapKeyIter_3cI64_2c_20Bool_3e_2eNext_3cI64_2c_20Bool_3e(ptr %v0, ptr %l4)
  %t101 = extractvalue { i32, i64 } %t100, 1
  %t102 = extractvalue { i32, i64 } %t100, 0
  store i32 %t102, ptr %l44
  %t103 = icmp ne i32 %t102, 0
  br i1 %t103, label %bb20, label %ok.104, !prof !99
ok.104:
  store i64 %t101, ptr %l43
  br label %bb19
bb19:
  %t105 = load i64, ptr %l43, !tbaa !24
  store i64 %t105, ptr %l41, !tbaa !24
  br label %bb22
bb20:
  %t106 = load i32, ptr %l44, !tbaa !23
  %t107 = ashr i32 %t106, 16
  %t109 = icmp eq i32 %t107, 1
  store i1 %t109, ptr %l46, !tbaa !21
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s6)
  br label %bb33
bb22:
  %t110 = load i64, ptr %l41, !tbaa !24
  store i64 %t110, ptr %l5, !tbaa !24
  store ptr %l1, ptr %l47, !tbaa !29
  %t111 = call ptr @__olang_scope_hold(ptr %s0)
  %t112 = ptrtoint ptr %t111 to i64
  store i64 %t112, ptr %l48, !tbaa !24
  %t113 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t113, label %bb23, label %bb24
bb23:
  %t115 = call ptr @__olang_region_make(ptr %s0)
  %t116 = ptrtoint ptr %t115 to i64
  store i64 %t116, ptr %l48, !tbaa !24
  br label %bb24
bb24:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t118 = load i64, ptr %l5, !tbaa !24
  %t121 = call { i64, ptr } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eNameOf(ptr %v0, ptr %v0, ptr %t117, i64 %t118)
  store { i64, ptr } %t121, ptr %l52
  br label %bb25
bb25:
  %t122 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t123 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s6, { i64, ptr } %t122, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d40, i32 0, i32 1) })
  store i1 %t123, ptr %l53
  br label %bb26
bb26:
  %t124 = load i1, ptr %l53, !tbaa !21
  %t125 = xor i1 %t124, true
  br i1 %t125, label %bb27, label %bb28
bb27:
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t128 = load i64, ptr %l5, !tbaa !24
  %t131 = call { i64, ptr } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eNameOf(ptr %v0, ptr %s6, ptr %t127, i64 %t128)
  store { i64, ptr } %t131, ptr %l58
  br label %bb29
bb28:
  %t132 = load i64, ptr %l5, !tbaa !24
  %t133 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d41, i32 0, i32 1) }, 1
  %t134 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d41, i32 0, i32 1) }, 0
  %t136 = call i64 @__olang_fmt_i64(ptr null, i64 %t132)
  %t137 = add i64 %t134, %t136
  %t138 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t137)
  call void @olang_textcopy(ptr %t138, ptr %t133, i64 %t134)
  %t139 = getelementptr i8, ptr %t138, i64 %t134
  %t140 = call i64 @__olang_fmt_i64(ptr %t139, i64 %t132)
  %t141 = insertvalue { i64, ptr } undef, i64 %t137, 0
  %t142 = insertvalue { i64, ptr } %t141, ptr %t138, 1
  store { i64, ptr } %t142, ptr %l55, !tbaa !27
  br label %bb30
bb29:
  %t145 = load { i64, ptr }, ptr %l58, !tbaa !27
  store { i64, ptr } %t145, ptr %l55, !tbaa !27
  br label %bb30
bb30:
  %t146 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d42, i32 0, i32 1) }, 1
  %t147 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d42, i32 0, i32 1) }, 0
  %t148 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t149 = extractvalue { i64, ptr } %t148, 1
  %t150 = extractvalue { i64, ptr } %t148, 0
  %t151 = add i64 %t147, %t150
  %t152 = load i64, ptr %l48
  %t153 = inttoptr i64 %t152 to ptr
  %t154 = call ptr @__olang_held_alloc(ptr %t153, i64 %t151)
  call void @olang_textcopy(ptr %t154, ptr %t146, i64 %t147)
  %t155 = getelementptr i8, ptr %t154, i64 %t147
  call void @olang_textcopy(ptr %t155, ptr %t149, i64 %t150)
  %t156 = insertvalue { i64, ptr } undef, i64 %t151, 0
  %t157 = insertvalue { i64, ptr } %t156, ptr %t154, 1
  %t159 = load ptr, ptr %l47, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %t159, { i64, ptr } %t157)
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s6)
  br label %bb32
bb32:
  br label %bb18
bb33:
  %t161 = load ptr, ptr %l0, !tbaa !29
  %t163 = getelementptr %"compiler/scope:Scoper", ptr %t161, i32 0, i32 55
  %t165 = call %"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eKeys_3cI64_2c_20Bool_3e(ptr %v0, ptr %v0, ptr %t163)
  store %"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9" %t165, ptr %l66
  br label %bb34
bb34:
  %t166 = load %"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9", ptr %l66
  store %"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9" %t166, ptr %l6
  br label %bb35
bb35:
  %t168 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapKeyIter_3cI64_2c_20Bool_3e_2eNext_3cI64_2c_20Bool_3e(ptr %v0, ptr %l6)
  %t169 = extractvalue { i32, i64 } %t168, 1
  %t170 = extractvalue { i32, i64 } %t168, 0
  store i32 %t170, ptr %l70
  %t171 = icmp ne i32 %t170, 0
  br i1 %t171, label %bb37, label %ok.172, !prof !99
ok.172:
  store i64 %t169, ptr %l69
  br label %bb36
bb36:
  %t173 = load i64, ptr %l69, !tbaa !24
  store i64 %t173, ptr %l67, !tbaa !24
  br label %bb39
bb37:
  %t174 = load i32, ptr %l70, !tbaa !23
  %t175 = ashr i32 %t174, 16
  %t177 = icmp eq i32 %t175, 1
  store i1 %t177, ptr %l72, !tbaa !21
  br label %bb38
bb38:
  br label %bb52
bb39:
  %t178 = load i64, ptr %l67, !tbaa !24
  store i64 %t178, ptr %l7, !tbaa !24
  store ptr %l1, ptr %l73, !tbaa !29
  %t179 = call ptr @__olang_scope_hold(ptr %s0)
  %t180 = ptrtoint ptr %t179 to i64
  store i64 %t180, ptr %l74, !tbaa !24
  %t181 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t181, label %bb40, label %bb41
bb40:
  %t183 = call ptr @__olang_region_make(ptr %s0)
  %t184 = ptrtoint ptr %t183 to i64
  store i64 %t184, ptr %l74, !tbaa !24
  br label %bb41
bb41:
  %t185 = load i64, ptr %l7, !tbaa !24
  %t187 = icmp sge i64 %t185, 0
  br i1 %t187, label %bb42, label %bb43
bb42:
  %t189 = load i64, ptr %l7, !tbaa !24
  store i64 %t189, ptr %l79, !tbaa !24
  %t190 = load ptr, ptr %l0, !tbaa !29
  %t192 = getelementptr %"compiler/scope:Scoper", ptr %t190, i32 0, i32 0
  %t193 = load ptr, ptr %t192, !tbaa !29
  %t195 = getelementptr %"compiler/generic:Program", ptr %t193, i32 0, i32 0
  %t196 = load ptr, ptr %t195, !tbaa !29
  %t198 = getelementptr %"compiler/load:Loader", ptr %t196, i32 0, i32 10
  %t200 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %t198)
  store i64 %t200, ptr %l84
  br label %bb44
bb43:
  store i1 false, ptr %l78, !tbaa !21
  br label %bb45
bb44:
  %t201 = load i64, ptr %l79, !tbaa !24
  %t202 = load i64, ptr %l84, !tbaa !24
  %t203 = icmp slt i64 %t201, %t202
  store i1 %t203, ptr %l78, !tbaa !21
  br label %bb45
bb45:
  %t205 = load i1, ptr %l78, !tbaa !21
  br i1 %t205, label %bb46, label %bb47
bb46:
  %t206 = load ptr, ptr %l0, !tbaa !29
  %t208 = getelementptr %"compiler/scope:Scoper", ptr %t206, i32 0, i32 0
  %t209 = load ptr, ptr %t208, !tbaa !29
  %t211 = getelementptr %"compiler/generic:Program", ptr %t209, i32 0, i32 0
  %t212 = load ptr, ptr %t211, !tbaa !29
  %t214 = getelementptr %"compiler/load:Loader", ptr %t212, i32 0, i32 10
  %t215 = load i64, ptr %l7, !tbaa !24
  %t218 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t214, i64 %t215)
  store ptr %t218, ptr %l92
  br label %bb48
bb47:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d43, i32 0, i32 1) }, ptr %l86, !tbaa !27
  br label %bb49
bb48:
  %t219 = load ptr, ptr %l92, !tbaa !29
  %t221 = getelementptr %"compiler/load:Module", ptr %t219, i32 0, i32 2
  %t222 = load { i64, ptr }, ptr %t221, !tbaa !27
  store { i64, ptr } %t222, ptr %l86, !tbaa !27
  br label %bb49
bb49:
  %t224 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d44, i32 0, i32 1) }, 1
  %t225 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d44, i32 0, i32 1) }, 0
  %t226 = load { i64, ptr }, ptr %l86, !tbaa !27
  %t227 = extractvalue { i64, ptr } %t226, 1
  %t228 = extractvalue { i64, ptr } %t226, 0
  %t229 = add i64 %t225, %t228
  %t230 = load i64, ptr %l74
  %t231 = inttoptr i64 %t230 to ptr
  %t232 = call ptr @__olang_held_alloc(ptr %t231, i64 %t229)
  call void @olang_textcopy(ptr %t232, ptr %t224, i64 %t225)
  %t233 = getelementptr i8, ptr %t232, i64 %t225
  call void @olang_textcopy(ptr %t233, ptr %t227, i64 %t228)
  %t234 = insertvalue { i64, ptr } undef, i64 %t229, 0
  %t235 = insertvalue { i64, ptr } %t234, ptr %t232, 1
  %t237 = load ptr, ptr %l73, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %t237, { i64, ptr } %t235)
  br label %bb50
bb50:
  br label %bb51
bb51:
  br label %bb35
bb52:
  %t239 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_45, 0
  %t240 = insertvalue { ptr, ptr } %t239, ptr null, 1
  %t243 = extractvalue { ptr, ptr } %t240, 0
  %t244 = extractvalue { ptr, ptr } %t240, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H1642129570dad448bb7dcc47c334de83(ptr %s0, ptr %s0, ptr %l1, ptr %t243, ptr %t244)
  br label %bb53
bb53:
  %t245 = load ptr, ptr %l0, !tbaa !29
  store ptr %t245, ptr %l99, !tbaa !29
  %t247 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2eJoin(ptr %s0, ptr %s0, ptr %s0, ptr %l1, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d46, i32 0, i32 1) })
  store { i64, ptr } %t247, ptr %l101
  br label %bb54
bb54:
  %t248 = load { i64, ptr }, ptr %l101, !tbaa !27
  %t250 = call { i64, ptr } @compiler_2fscope_2ehashText(ptr %s0, ptr %v0, { i64, ptr } %t248)
  store { i64, ptr } %t250, ptr %l103
  br label %bb55
bb55:
  %t251 = load ptr, ptr %l99, !tbaa !29
  %t252 = getelementptr %"compiler/scope:Scoper", ptr %t251, i32 0, i32 327
  %t253 = load { i64, ptr }, ptr %t252, !tbaa !27
  store { i64, ptr } %t253, ptr %l104, !tbaa !27
  %t254 = load { i64, ptr }, ptr %l103, !tbaa !27
  %t255 = load ptr, ptr %l99, !tbaa !29
  %t256 = getelementptr %"compiler/scope:Scoper", ptr %t255, i32 0, i32 327
  store { i64, ptr } %t254, ptr %t256, !tbaa !27
  %t257 = load i1, ptr @olang_2esole_2ecompiler_2fscope_3aScoper_2e327
  br i1 %t257, label %bb56, label %bb57
bb56:
  %t259 = load { i64, ptr }, ptr %l104
  %t260 = extractvalue { i64, ptr } %t259, 0
  %t261 = extractvalue { i64, ptr } %t259, 1
  call void @__olang_region_release_part(ptr %t261, i64 %t260)
  store { i64, ptr } zeroinitializer, ptr %l104
  br label %bb57
bb57:
  %t262 = load ptr, ptr %l0, !tbaa !29
  %t264 = getelementptr %"compiler/scope:Scoper", ptr %t262, i32 0, i32 326
  store i1 true, ptr %t264, !tbaa !21
  %t265 = load ptr, ptr %l0, !tbaa !29
  %t267 = getelementptr %"compiler/scope:Scoper", ptr %t265, i32 0, i32 327
  %t268 = load { i64, ptr }, ptr %t267, !tbaa !27
  store { i64, ptr } %t268, ptr %l108, !tbaa !27
  %t269 = load { i64, ptr }, ptr %l108, !tbaa !27
  %t270 = extractvalue { i64, ptr } %t269, 0
  store i64 %t270, ptr %l109, !tbaa !24
  %t271 = load i64, ptr %l109, !tbaa !24
  %t272 = mul i64 %t271, 1
  %t273 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t272)
  %t274 = insertvalue { i64, ptr } undef, i64 %t271, 0
  %t275 = insertvalue { i64, ptr } %t274, ptr %t273, 1
  store { i64, ptr } %t275, ptr %l110, !tbaa !27
  %t276 = getelementptr { i64, ptr }, ptr %l110, i32 0, i32 1
  %t277 = load ptr, ptr %t276, !tbaa !27
  %t278 = getelementptr { i64, ptr }, ptr %l108, i32 0, i32 1
  %t279 = load ptr, ptr %t278, !tbaa !27
  %t280 = load i64, ptr %l109, !tbaa !24
  %t281 = mul i64 %t280, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t277, ptr %t279, i64 %t281, i1 false)
  %t282 = load { i64, ptr }, ptr %l110, !tbaa !27
  store { i64, ptr } %t282, ptr %l108, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t283 = load { i64, ptr }, ptr %l108, !tbaa !27
  store { i64, ptr } %t283, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisData(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l6 = alloca ptr
  %l7 = alloca i1
  %l8 = alloca ptr
  %l9 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t6 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunAway(ptr %v0, ptr %v1, ptr %s0, ptr %a0, ptr %a1)
  store ptr %t6, ptr %l6
  br label %bb1
bb1:
  %t7 = load ptr, ptr %l6, !tbaa !29
  store ptr %t7, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t9 = load ptr, ptr %l8, !tbaa !29
  %t10 = icmp ne ptr %t9, null
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = load ptr, ptr %l8, !tbaa !29
  %t13 = load i64, ptr %t12, !range !{i64 0, i64 18}
  %t15 = icmp eq i64 %t13, 1
  store i1 %t15, ptr %l9, !tbaa !21
  br label %bb3
bb3:
  %t16 = load i1, ptr %l9, !tbaa !21
  br i1 %t16, label %bb4, label %bb5
bb4:
  br label %bb6
bb5:
  br label %bb7
bb6:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb12
bb7:
  br i1 true, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb11
bb10:
  store i1 false, ptr %l7, !tbaa !21
  br label %bb12
bb11:
  call void @__olang_check_failed(ptr @olang_loc_9476cc7193074e76_e8b6eb41d568f08a)
  unreachable
bb12:
  call void @__olang_scope_close(ptr %s0)
  %t17 = load i1, ptr %l7, !tbaa !21
  store i1 %t17, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2elastBracket(ptr %v0, ptr %a0, %"compiler/source:Span" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i8
  %l12 = alloca { i64, ptr }
  %l14 = alloca ptr
  %l22 = alloca { i64, ptr }
  %l23 = alloca i32
  %l31 = alloca i64
  %l34 = alloca i64
  %l43 = alloca i64
  %l46 = alloca i1
  %l60 = alloca { i64, ptr }
  %l78 = alloca i1
  %l81 = alloca i1
  %l92 = alloca %"compiler/source:Span"
  %l98 = alloca %"compiler/source:Span"
  %l99 = alloca ptr
  %l108 = alloca %"compiler/source:Span"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 12
  store ptr %t3, ptr %l14, !tbaa !29
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t6 = getelementptr %"compiler/scope:Scoper", ptr %t4, i32 0, i32 28
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = icmp eq ptr %t7, null
  br i1 %t9, label %bb1, label %bb2
bb1:
  call void @__olang_check_failed(ptr @olang_loc_80dc90fe4960987f_e8c65fabb0c3bdbb)
  unreachable
bb2:
  br label %bb3
bb3:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/scope:Scoper", ptr %t11, i32 0, i32 28
  %t14 = load ptr, ptr %t13, !tbaa !29
  %t17 = getelementptr %"compiler/typed:Body", ptr %t14, i32 0, i32 3
  %t18 = load i64, ptr %t17, !tbaa !24
  %t19 = load ptr, ptr %l14, !tbaa !29
  %t21 = call { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_He9bc6cfad7ef603960b4717f3121b8e8(ptr %v0, ptr %v0, ptr %t19, i64 %t18)
  %t22 = extractvalue { i32, { i64, ptr } } %t21, 1
  %t23 = extractvalue { i32, { i64, ptr } } %t21, 0
  store i32 %t23, ptr %l23
  %t24 = icmp ne i32 %t23, 0
  br i1 %t24, label %bb5, label %ok.25, !prof !99
ok.25:
  store { i64, ptr } %t22, ptr %l22
  br label %bb4
bb4:
  %t26 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t26, ptr %l12, !tbaa !27
  br label %bb7
bb5:
  br label %bb6
bb6:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d47, i32 0, i32 1) }, ptr %l12, !tbaa !27
  br label %bb7
bb7:
  %t27 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t27, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  store i64 -1, ptr %l4, !tbaa !24
  %t28 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t29 = load i32, ptr %t28, !tbaa !23
  %t31 = sext i32 %t29 to i64
  store i64 %t31, ptr %l5, !tbaa !24
  %t33 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 1
  %t34 = load i32, ptr %t33, !tbaa !23
  %t36 = sext i32 %t34 to i64
  store i64 %t36, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t38 = load i64, ptr %l6, !tbaa !24
  %t39 = load i64, ptr %l5, !tbaa !24
  %t42 = icmp sgt i64 %t38, %t39
  br i1 %t42, label %bb8, label %bb9
bb8:
  %t44 = load i64, ptr %l7, !tbaa !24
  %t46 = icmp sgt i64 %t44, 0
  br i1 %t46, label %bb10, label %bb11
bb9:
  store i64 0, ptr %l31, !tbaa !24
  br label %bb13
bb10:
  %t48 = load i64, ptr %l6, !tbaa !24
  %t49 = load i64, ptr %l5, !tbaa !24
  %t52 = sub i64 %t48, %t49
  %t53 = load i64, ptr %l7, !tbaa !24
  %t56 = add i64 %t52, %t53
  %t58 = sub i64 %t56, 1
  %t59 = load i64, ptr %l7, !tbaa !24
  %t62 = sdiv i64 %t58, %t59
  store i64 %t62, ptr %l34, !tbaa !24
  br label %bb12
bb11:
  store i64 0, ptr %l34, !tbaa !24
  br label %bb12
bb12:
  %t64 = load i64, ptr %l34, !tbaa !24
  store i64 %t64, ptr %l31, !tbaa !24
  br label %bb13
bb13:
  %t65 = load i64, ptr %l31, !tbaa !24
  store i64 %t65, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  %t66 = load i64, ptr %l8, !tbaa !24
  %t67 = sub i64 %t66, 1
  store i64 %t67, ptr %l43, !tbaa !24
  %t68 = load i64, ptr %l8, !tbaa !24
  %t69 = icmp slt i64 %t68, 2147483648
  %t70 = load i64, ptr %l9, !tbaa !24
  %t71 = icmp sge i64 %t70, 0
  %t74 = and i1 %t69, %t71
  store i1 %t74, ptr %l46, !tbaa !21
  br label %bb14
bb14:
  %t75 = load i64, ptr %l9, !tbaa !24
  %t76 = load i64, ptr %l8, !tbaa !24
  %t79 = icmp slt i64 %t75, %t76
  %t81 = xor i1 %t79, true
  br i1 %t81, label %bb15, label %bb16
bb15:
  br label %bb40
bb16:
  br label %bb17
bb17:
  %t83 = load i64, ptr %l5, !tbaa !24
  %t84 = load i64, ptr %l9, !tbaa !24
  %t85 = load i64, ptr %l7, !tbaa !24
  %t88 = mul i64 %t84, %t85
  %t91 = add i64 %t83, %t88
  store i64 %t91, ptr %l10, !tbaa !24
  %t93 = load i64, ptr %l10, !tbaa !24
  %t94 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t96 = extractvalue { i64, ptr } %t94, 0
  %t99 = icmp sge i64 %t93, %t96
  br i1 %t99, label %bb18, label %bb19
bb18:
  br label %bb40
bb19:
  br label %bb20
bb20:
  %t101 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t101, ptr %l60, !tbaa !27
  %t102 = load i64, ptr %l10, !tbaa !24
  %t104 = getelementptr { i64, ptr }, ptr %l60, i32 0, i32 1
  %t105 = load ptr, ptr %t104, !tbaa !27
  %t106 = getelementptr i8, ptr %t105, i64 %t102
  %t107 = load i8, ptr %t106, !tbaa !32
  store i8 %t107, ptr %l11, !tbaa !22
  %t109 = load i8, ptr %l11, !tbaa !22
  %t111 = icmp eq i8 %t109, 91
  br i1 %t111, label %bb21, label %bb22
bb21:
  %t113 = load i64, ptr %l3, !tbaa !24
  %t115 = icmp eq i64 %t113, 0
  br i1 %t115, label %bb23, label %bb24
bb22:
  %t117 = load i8, ptr %l11, !tbaa !22
  %t119 = icmp eq i8 %t117, 40
  br i1 %t119, label %bb26, label %bb27
bb23:
  %t121 = load i64, ptr %l10, !tbaa !24
  store i64 %t121, ptr %l4, !tbaa !24
  br label %bb25
bb24:
  br label %bb25
bb25:
  %t123 = load i64, ptr %l3, !tbaa !24
  %t126 = add i64 %t123, 1
  store i64 %t126, ptr %l3, !tbaa !24
  br label %bb38
bb26:
  %t128 = load i64, ptr %l3, !tbaa !24
  %t131 = add i64 %t128, 1
  store i64 %t131, ptr %l3, !tbaa !24
  br label %bb37
bb27:
  %t133 = load i8, ptr %l11, !tbaa !22
  %t135 = icmp eq i8 %t133, 93
  br i1 %t135, label %bb28, label %bb29
bb28:
  store i1 true, ptr %l78, !tbaa !21
  br label %bb30
bb29:
  %t137 = load i8, ptr %l11, !tbaa !22
  %t139 = icmp eq i8 %t137, 41
  store i1 %t139, ptr %l78, !tbaa !21
  br label %bb30
bb30:
  %t141 = load i1, ptr %l78, !tbaa !21
  br i1 %t141, label %bb31, label %bb32
bb31:
  %t142 = load i64, ptr %l3, !tbaa !24
  %t144 = icmp sgt i64 %t142, 0
  store i1 %t144, ptr %l81, !tbaa !21
  br label %bb33
bb32:
  store i1 false, ptr %l81, !tbaa !21
  br label %bb33
bb33:
  %t146 = load i1, ptr %l81, !tbaa !21
  br i1 %t146, label %bb34, label %bb35
bb34:
  %t147 = load i64, ptr %l3, !tbaa !24
  %t150 = sub i64 %t147, 1
  store i64 %t150, ptr %l3, !tbaa !24
  br label %bb36
bb35:
  br label %bb36
bb36:
  br label %bb37
bb37:
  br label %bb38
bb38:
  br label %bb39
bb39:
  %t152 = load i64, ptr %l9, !tbaa !24
  %t155 = add i64 %t152, 1
  store i64 %t155, ptr %l9, !tbaa !24
  br label %bb14
bb40:
  %t157 = load i64, ptr %l4, !tbaa !24
  %t159 = icmp sge i64 %t157, 0
  br i1 %t159, label %bb41, label %bb42
bb41:
  %t161 = load i64, ptr %l4, !tbaa !24
  %t163 = trunc i64 %t161 to i32
  %t164 = load i64, ptr %l4, !tbaa !24
  %t166 = add i64 %t164, 1
  %t168 = trunc i64 %t166 to i32
  %t171 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 %t163, i32 %t168)
  store %"compiler/source:Span" %t171, ptr %l98
  br label %bb43
bb42:
  %t172 = load ptr, ptr %l0, !tbaa !29
  store ptr %t172, ptr %l99, !tbaa !29
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t175 = getelementptr %"compiler/scope:Scoper", ptr %t173, i32 0, i32 28
  %t176 = load ptr, ptr %t175, !tbaa !29
  %t178 = icmp eq ptr %t176, null
  br i1 %t178, label %bb44, label %bb45
bb43:
  %t180 = load %"compiler/source:Span", ptr %l98
  store %"compiler/source:Span" %t180, ptr %l92
  br label %bb48
bb44:
  call void @__olang_check_failed(ptr @olang_loc_e199b27d8a069b60_e8a91e9929fc614c)
  unreachable
bb45:
  br label %bb46
bb46:
  %t181 = load ptr, ptr %l0, !tbaa !29
  %t183 = getelementptr %"compiler/scope:Scoper", ptr %t181, i32 0, i32 28
  %t184 = load ptr, ptr %t183, !tbaa !29
  %t187 = getelementptr %"compiler/typed:Body", ptr %t184, i32 0, i32 3
  %t188 = load i64, ptr %t187, !tbaa !24
  %t189 = load %"compiler/source:Span", ptr %l1
  %t190 = load ptr, ptr %l99, !tbaa !29
  %t193 = call %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2efirstToken(ptr %v0, ptr %t190, i64 %t188, %"compiler/source:Span" %t189)
  store %"compiler/source:Span" %t193, ptr %l108
  br label %bb47
bb47:
  %t194 = load %"compiler/source:Span", ptr %l108
  store %"compiler/source:Span" %t194, ptr %l92
  br label %bb48
bb48:
  call void @__olang_scope_close(ptr %s0)
  %t195 = load %"compiler/source:Span", ptr %l92
  store %"compiler/source:Span" %t195, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2emadePlace(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i32
  %l9 = alloca i64
  %l10 = alloca %"compiler/typed:Local"
  %l11 = alloca ptr
  %l12 = alloca i32
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca i1
  %l17 = alloca i1
  %l18 = alloca i64
  %l22 = alloca ptr
  %l23 = alloca i1
  %l32 = alloca i64
  %l33 = alloca ptr
  %l34 = alloca i1
  %l44 = alloca i64
  %l45 = alloca ptr
  %l46 = alloca i1
  %l56 = alloca i64
  %l57 = alloca ptr
  %l58 = alloca i1
  %l68 = alloca i64
  %l69 = alloca ptr
  %l70 = alloca i1
  %l80 = alloca i64
  %l81 = alloca ptr
  %l82 = alloca i1
  %l97 = alloca %"compiler/typed:Local"
  %l98 = alloca ptr
  %l102 = alloca ptr
  %l103 = alloca i32
  %l116 = alloca i64
  %l123 = alloca ptr
  %l124 = alloca i1
  %l125 = alloca ptr
  %l126 = alloca i1
  %l129 = alloca ptr
  %l130 = alloca i1
  %l133 = alloca ptr
  %l134 = alloca i1
  %l137 = alloca ptr
  %l138 = alloca i1
  %l145 = alloca ptr
  %l148 = alloca i32
  %l149 = alloca i64
  %l154 = alloca ptr
  %l155 = alloca i1
  %l156 = alloca ptr
  %l157 = alloca i1
  %l162 = alloca i1
  %l165 = alloca i1
  %l167 = alloca i1
  %l176 = alloca i64
  %l179 = alloca i64
  %s7 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l2, !tbaa !24
  %t3 = icmp sgt i64 %t1, 32
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i64 -1, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l1, !tbaa !29
  store ptr %t6, ptr %l22, !tbaa !29
  store i1 false, ptr %l23, !tbaa !21
  %t7 = load ptr, ptr %l22, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb4, label %bb5
bb4:
  %t10 = load ptr, ptr %l22, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 8}
  %t13 = icmp eq i64 %t11, 3
  store i1 %t13, ptr %l23, !tbaa !21
  br label %bb5
bb5:
  %t14 = load i1, ptr %l23, !tbaa !21
  br i1 %t14, label %bb6, label %bb7
bb6:
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t17 = getelementptr { i64, [4 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t17, i32 0, i32 2
  %t19 = load ptr, ptr %t18
  store ptr %t19, ptr %l3, !tbaa !29
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load ptr, ptr %l3, !tbaa !29
  %t23 = load i64, ptr %l2, !tbaa !24
  %t25 = add i64 %t23, 1
  %t29 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2emadePlace(ptr %v0, ptr %v1, ptr %t21, ptr %t22, i64 %t25)
  store i64 %t29, ptr %l32
  br label %bb9
bb9:
  %t30 = load i64, ptr %l32, !tbaa !24
  store i64 %t30, ptr %rv
  br label %ret
bb10:
  %t31 = load ptr, ptr %l1, !tbaa !29
  store ptr %t31, ptr %l33, !tbaa !29
  store i1 false, ptr %l34, !tbaa !21
  %t32 = load ptr, ptr %l33, !tbaa !29
  %t33 = icmp ne ptr %t32, null
  br i1 %t33, label %bb11, label %bb12
bb11:
  %t35 = load ptr, ptr %l33, !tbaa !29
  %t36 = load i64, ptr %t35, !range !{i64 0, i64 8}
  %t38 = icmp eq i64 %t36, 4
  store i1 %t38, ptr %l34, !tbaa !21
  br label %bb12
bb12:
  %t39 = load i1, ptr %l34, !tbaa !21
  br i1 %t39, label %bb13, label %bb14
bb13:
  %t40 = load ptr, ptr %l1, !tbaa !29
  %t42 = getelementptr { i64, [4 x i64] }, ptr %t40, i32 0, i32 1
  %t43 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t42, i32 0, i32 2
  %t44 = load ptr, ptr %t43
  store ptr %t44, ptr %l4, !tbaa !29
  br label %bb15
bb14:
  br label %bb17
bb15:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = load ptr, ptr %l4, !tbaa !29
  %t49 = getelementptr %"compiler/typed:Elem", ptr %t47, i32 0, i32 0
  %t50 = load ptr, ptr %t49, !tbaa !29
  %t51 = load i64, ptr %l2, !tbaa !24
  %t53 = add i64 %t51, 1
  %t57 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2emadePlace(ptr %v0, ptr %v1, ptr %t46, ptr %t50, i64 %t53)
  store i64 %t57, ptr %l44
  br label %bb16
bb16:
  %t58 = load i64, ptr %l44, !tbaa !24
  store i64 %t58, ptr %rv
  br label %ret
bb17:
  %t59 = load ptr, ptr %l1, !tbaa !29
  store ptr %t59, ptr %l45, !tbaa !29
  store i1 false, ptr %l46, !tbaa !21
  %t60 = load ptr, ptr %l45, !tbaa !29
  %t61 = icmp ne ptr %t60, null
  br i1 %t61, label %bb18, label %bb19
bb18:
  %t63 = load ptr, ptr %l45, !tbaa !29
  %t64 = load i64, ptr %t63, !range !{i64 0, i64 8}
  %t66 = icmp eq i64 %t64, 5
  store i1 %t66, ptr %l46, !tbaa !21
  br label %bb19
bb19:
  %t67 = load i1, ptr %l46, !tbaa !21
  br i1 %t67, label %bb20, label %bb21
bb20:
  %t68 = load ptr, ptr %l1, !tbaa !29
  %t70 = getelementptr { i64, [4 x i64] }, ptr %t68, i32 0, i32 1
  %t71 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t70, i32 0, i32 2
  %t72 = load ptr, ptr %t71
  store ptr %t72, ptr %l5, !tbaa !29
  br label %bb22
bb21:
  br label %bb24
bb22:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t75 = load ptr, ptr %l5, !tbaa !29
  %t77 = getelementptr %"compiler/typed:Payload", ptr %t75, i32 0, i32 0
  %t78 = load ptr, ptr %t77, !tbaa !29
  %t79 = load i64, ptr %l2, !tbaa !24
  %t81 = add i64 %t79, 1
  %t85 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2emadePlace(ptr %v0, ptr %v1, ptr %t74, ptr %t78, i64 %t81)
  store i64 %t85, ptr %l56
  br label %bb23
bb23:
  %t86 = load i64, ptr %l56, !tbaa !24
  store i64 %t86, ptr %rv
  br label %ret
bb24:
  %t87 = load ptr, ptr %l1, !tbaa !29
  store ptr %t87, ptr %l57, !tbaa !29
  store i1 false, ptr %l58, !tbaa !21
  %t88 = load ptr, ptr %l57, !tbaa !29
  %t89 = icmp ne ptr %t88, null
  br i1 %t89, label %bb25, label %bb26
bb25:
  %t91 = load ptr, ptr %l57, !tbaa !29
  %t92 = load i64, ptr %t91, !range !{i64 0, i64 8}
  %t94 = icmp eq i64 %t92, 2
  store i1 %t94, ptr %l58, !tbaa !21
  br label %bb26
bb26:
  %t95 = load i1, ptr %l58, !tbaa !21
  br i1 %t95, label %bb27, label %bb28
bb27:
  %t96 = load ptr, ptr %l1, !tbaa !29
  %t98 = getelementptr { i64, [4 x i64] }, ptr %t96, i32 0, i32 1
  %t99 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t98, i32 0, i32 2
  %t100 = load ptr, ptr %t99
  store ptr %t100, ptr %l6, !tbaa !29
  br label %bb29
bb28:
  br label %bb31
bb29:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t103 = load ptr, ptr %l6, !tbaa !29
  %t105 = load i64, ptr %l2, !tbaa !24
  %t107 = add i64 %t105, 1
  %t111 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2emadeLocal(ptr %v0, ptr %v1, ptr %t102, ptr %t103, i64 %t107)
  store i64 %t111, ptr %l68
  br label %bb30
bb30:
  %t112 = load i64, ptr %l68, !tbaa !24
  store i64 %t112, ptr %rv
  br label %ret
bb31:
  %t113 = load ptr, ptr %l1, !tbaa !29
  store ptr %t113, ptr %l69, !tbaa !29
  store i1 false, ptr %l70, !tbaa !21
  %t114 = load ptr, ptr %l69, !tbaa !29
  %t115 = icmp ne ptr %t114, null
  br i1 %t115, label %bb32, label %bb33
bb32:
  %t117 = load ptr, ptr %l69, !tbaa !29
  %t118 = load i64, ptr %t117, !range !{i64 0, i64 8}
  %t120 = icmp eq i64 %t118, 6
  store i1 %t120, ptr %l70, !tbaa !21
  br label %bb33
bb33:
  %t121 = load i1, ptr %l70, !tbaa !21
  br i1 %t121, label %bb34, label %bb35
bb34:
  %t122 = load ptr, ptr %l1, !tbaa !29
  %t124 = getelementptr { i64, [4 x i64] }, ptr %t122, i32 0, i32 1
  %t125 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t124, i32 0, i32 2
  %t126 = load ptr, ptr %t125
  store ptr %t126, ptr %l7, !tbaa !29
  br label %bb36
bb35:
  br label %bb38
bb36:
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t129 = load ptr, ptr %l7, !tbaa !29
  %t131 = load i64, ptr %l2, !tbaa !24
  %t133 = add i64 %t131, 1
  %t137 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2emadeLocal(ptr %v0, ptr %v1, ptr %t128, ptr %t129, i64 %t133)
  store i64 %t137, ptr %l80
  br label %bb37
bb37:
  %t138 = load i64, ptr %l80, !tbaa !24
  store i64 %t138, ptr %rv
  br label %ret
bb38:
  %t139 = load ptr, ptr %l1, !tbaa !29
  store ptr %t139, ptr %l81, !tbaa !29
  store i1 false, ptr %l82, !tbaa !21
  %t140 = load ptr, ptr %l81, !tbaa !29
  %t141 = icmp ne ptr %t140, null
  br i1 %t141, label %bb39, label %bb40
bb39:
  %t143 = load ptr, ptr %l81, !tbaa !29
  %t144 = load i64, ptr %t143, !range !{i64 0, i64 8}
  %t146 = icmp eq i64 %t144, 0
  store i1 %t146, ptr %l82, !tbaa !21
  br label %bb40
bb40:
  %t147 = load i1, ptr %l82, !tbaa !21
  br i1 %t147, label %bb41, label %bb42
bb41:
  %t148 = load ptr, ptr %l1, !tbaa !29
  %t150 = getelementptr { i64, [4 x i64] }, ptr %t148, i32 0, i32 1
  %t151 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t150, i32 0, i32 2
  %t152 = load i32, ptr %t151
  store i32 %t152, ptr %l8, !tbaa !23
  br label %bb43
bb42:
  br label %bb125
bb43:
  store %olang.scope zeroinitializer, ptr %s7
  %t154 = load i32, ptr %l8, !tbaa !23
  %t156 = sext i32 %t154 to i64
  store i64 %t156, ptr %l9, !tbaa !24
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t160 = getelementptr %"compiler/scope:Scoper", ptr %t158, i32 0, i32 28
  %t161 = load ptr, ptr %t160, !tbaa !29
  %t163 = icmp eq ptr %t161, null
  br i1 %t163, label %bb44, label %bb45
bb44:
  call void @__olang_check_failed(ptr @olang_loc_e507d0d93dcb1267_6d41e0722b8ffb6b)
  unreachable
bb45:
  br label %bb46
bb46:
  %t165 = load ptr, ptr %l0, !tbaa !29
  %t167 = getelementptr %"compiler/scope:Scoper", ptr %t165, i32 0, i32 28
  %t168 = load ptr, ptr %t167, !tbaa !29
  %t171 = getelementptr %"compiler/typed:Body", ptr %t168, i32 0, i32 7
  %t172 = load i64, ptr %l9, !tbaa !24
  %t175 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t171, i64 %t172)
  store %"compiler/typed:Local" %t175, ptr %l97
  br label %bb47
bb47:
  %t176 = load %"compiler/typed:Local", ptr %l97
  store %"compiler/typed:Local" %t176, ptr %l10
  %t177 = load ptr, ptr %l0, !tbaa !29
  %t179 = getelementptr %"compiler/scope:Scoper", ptr %t177, i32 0, i32 48
  %t180 = load i64, ptr %l9, !tbaa !24
  %t183 = call { i32, ptr } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_H68cd31c3dbcdb47f3349b834dda1e07d(ptr %v0, ptr %v0, ptr %t179, i64 %t180)
  %t184 = extractvalue { i32, ptr } %t183, 1
  %t185 = extractvalue { i32, ptr } %t183, 0
  store i32 %t185, ptr %l103
  %t186 = icmp ne i32 %t185, 0
  br i1 %t186, label %bb49, label %ok.187, !prof !99
ok.187:
  store ptr %t184, ptr %l102
  br label %bb48
bb48:
  %t188 = load ptr, ptr %l102, !tbaa !29
  store ptr %t188, ptr %l98, !tbaa !29
  br label %bb51
bb49:
  br label %bb50
bb50:
  store ptr null, ptr %l98, !tbaa !29
  br label %bb51
bb51:
  %t189 = load ptr, ptr %l98, !tbaa !29
  store ptr %t189, ptr %l11, !tbaa !29
  %t190 = getelementptr %"compiler/typed:Local", ptr %l10, i32 0, i32 4
  %t191 = load i32, ptr %t190, !range !{i32 0, i32 7}
  store i32 %t191, ptr %l12
  %t193 = load i32, ptr %l12, !range !{i32 0, i32 7}
  %t195 = trunc i64 0 to i32
  %t196 = icmp eq i32 %t193, %t195
  br i1 %t196, label %bb52, label %bb53
bb52:
  br label %bb56
bb53:
  %t198 = load i32, ptr %l12, !range !{i32 0, i32 7}
  %t200 = trunc i64 5 to i32
  %t201 = icmp eq i32 %t198, %t200
  br i1 %t201, label %bb54, label %bb55
bb54:
  br label %bb56
bb55:
  br label %bb57
bb56:
  call void @__olang_scope_close(ptr %s7)
  store i64 -1, ptr %rv
  br label %ret
bb57:
  %t204 = load i32, ptr %l12, !range !{i32 0, i32 7}
  %t206 = trunc i64 2 to i32
  %t207 = icmp eq i32 %t204, %t206
  br i1 %t207, label %bb58, label %bb59
bb58:
  br label %bb60
bb59:
  br label %bb62
bb60:
  %t209 = load ptr, ptr %l0, !tbaa !29
  %t210 = load ptr, ptr %l11, !tbaa !29
  %t211 = load i64, ptr %l2, !tbaa !24
  %t213 = add i64 %t211, 1
  %t217 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2emadeLocal(ptr %v0, ptr %v0, ptr %t209, ptr %t210, i64 %t213)
  store i64 %t217, ptr %l116
  br label %bb61
bb61:
  call void @__olang_scope_close(ptr %s7)
  %t218 = load i64, ptr %l116, !tbaa !24
  store i64 %t218, ptr %rv
  br label %ret
bb62:
  br i1 true, label %bb63, label %bb64
bb63:
  br label %bb65
bb64:
  br label %bb66
bb65:
  br label %bb67
bb66:
  call void @__olang_check_failed(ptr @olang_loc_bdf36c9557ac347f_98a403497664a493)
  unreachable
bb67:
  %t219 = load ptr, ptr %l11, !tbaa !29
  %t221 = icmp eq ptr %t219, null
  br i1 %t221, label %bb68, label %bb69
bb68:
  %t223 = load i64, ptr %l9, !tbaa !24
  call void @__olang_scope_close(ptr %s7)
  store i64 %t223, ptr %rv
  br label %ret
bb69:
  br label %bb70
bb70:
  %t225 = load ptr, ptr %l0, !tbaa !29
  %t226 = load ptr, ptr %l11, !tbaa !29
  %t230 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunAway(ptr %v0, ptr %v0, ptr %s7, ptr %t225, ptr %t226)
  store ptr %t230, ptr %l123
  br label %bb71
bb71:
  %t231 = load ptr, ptr %l123, !tbaa !29
  store ptr %t231, ptr %l13, !tbaa !29
  %t232 = load ptr, ptr %l13, !tbaa !29
  store ptr %t232, ptr %l125, !tbaa !29
  store i1 false, ptr %l126, !tbaa !21
  %t233 = load ptr, ptr %l125, !tbaa !29
  %t234 = icmp ne ptr %t233, null
  br i1 %t234, label %bb72, label %bb73
bb72:
  %t236 = load ptr, ptr %l125, !tbaa !29
  %t237 = load i64, ptr %t236, !range !{i64 0, i64 18}
  %t239 = icmp eq i64 %t237, 2
  store i1 %t239, ptr %l126, !tbaa !21
  br label %bb73
bb73:
  %t240 = load i1, ptr %l126, !tbaa !21
  br i1 %t240, label %bb74, label %bb75
bb74:
  br label %bb84
bb75:
  %t241 = load ptr, ptr %l13, !tbaa !29
  store ptr %t241, ptr %l129, !tbaa !29
  store i1 false, ptr %l130, !tbaa !21
  %t242 = load ptr, ptr %l129, !tbaa !29
  %t243 = icmp ne ptr %t242, null
  br i1 %t243, label %bb76, label %bb77
bb76:
  %t245 = load ptr, ptr %l129, !tbaa !29
  %t246 = load i64, ptr %t245, !range !{i64 0, i64 18}
  %t248 = icmp eq i64 %t246, 3
  store i1 %t248, ptr %l130, !tbaa !21
  br label %bb77
bb77:
  %t249 = load i1, ptr %l130, !tbaa !21
  br i1 %t249, label %bb78, label %bb79
bb78:
  br label %bb84
bb79:
  %t250 = load ptr, ptr %l13, !tbaa !29
  store ptr %t250, ptr %l133, !tbaa !29
  store i1 false, ptr %l134, !tbaa !21
  %t251 = load ptr, ptr %l133, !tbaa !29
  %t252 = icmp ne ptr %t251, null
  br i1 %t252, label %bb80, label %bb81
bb80:
  %t254 = load ptr, ptr %l133, !tbaa !29
  %t255 = load i64, ptr %t254, !range !{i64 0, i64 18}
  %t257 = icmp eq i64 %t255, 10
  store i1 %t257, ptr %l134, !tbaa !21
  br label %bb81
bb81:
  %t258 = load i1, ptr %l134, !tbaa !21
  br i1 %t258, label %bb82, label %bb83
bb82:
  br label %bb84
bb83:
  br label %bb85
bb84:
  store i1 true, ptr %l124, !tbaa !21
  br label %bb98
bb85:
  %t259 = load ptr, ptr %l13, !tbaa !29
  store ptr %t259, ptr %l137, !tbaa !29
  store i1 false, ptr %l138, !tbaa !21
  %t260 = load ptr, ptr %l137, !tbaa !29
  %t261 = icmp ne ptr %t260, null
  br i1 %t261, label %bb86, label %bb87
bb86:
  %t263 = load ptr, ptr %l137, !tbaa !29
  %t264 = load i64, ptr %t263, !range !{i64 0, i64 18}
  %t266 = icmp eq i64 %t264, 6
  store i1 %t266, ptr %l138, !tbaa !21
  br label %bb87
bb87:
  %t267 = load i1, ptr %l138, !tbaa !21
  br i1 %t267, label %bb88, label %bb89
bb88:
  %t268 = load ptr, ptr %l13, !tbaa !29
  %t270 = getelementptr { i64, [5 x i64] }, ptr %t268, i32 0, i32 1
  %t271 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t270, i32 0, i32 2
  %t272 = load ptr, ptr %t271
  store ptr %t272, ptr %l14, !tbaa !29
  br label %bb90
bb89:
  br label %bb93
bb90:
  %t274 = load ptr, ptr %l0, !tbaa !29
  %t276 = getelementptr %"compiler/scope:Scoper", ptr %t274, i32 0, i32 0
  %t277 = load ptr, ptr %t276, !tbaa !29
  %t279 = getelementptr %"compiler/generic:Program", ptr %t277, i32 0, i32 2
  store ptr %t279, ptr %l145, !tbaa !29
  %t280 = load ptr, ptr %l0, !tbaa !29
  %t281 = load ptr, ptr %l14, !tbaa !29
  %t284 = call i32 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecalleeType(ptr %v0, ptr %s7, ptr %t280, ptr %t281)
  store i32 %t284, ptr %l148
  br label %bb91
bb91:
  %t285 = load ptr, ptr %l145, !tbaa !29
  %t286 = load i32, ptr %l148, !tbaa !23
  %t287 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResultFrom(ptr %v0, ptr %t285, i32 %t286, i64 0)
  store i64 %t287, ptr %l149
  br label %bb92
bb92:
  %t288 = load i64, ptr %l149, !tbaa !24
  %t289 = icmp sge i64 %t288, 0
  store i1 %t289, ptr %l124, !tbaa !21
  br label %bb98
bb93:
  br i1 true, label %bb94, label %bb95
bb94:
  br label %bb96
bb95:
  br label %bb97
bb96:
  store i1 false, ptr %l124, !tbaa !21
  br label %bb98
bb97:
  call void @__olang_check_failed(ptr @olang_loc_c3a4635b73df0d44_b0216f4acd182078)
  unreachable
bb98:
  %t291 = load i1, ptr %l124, !tbaa !21
  store i1 %t291, ptr %l15, !tbaa !21
  %t292 = load ptr, ptr %l0, !tbaa !29
  %t293 = load ptr, ptr %l11, !tbaa !29
  %t297 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunAway(ptr %v0, ptr %v0, ptr %s7, ptr %t292, ptr %t293)
  store ptr %t297, ptr %l154
  br label %bb99
bb99:
  %t298 = load ptr, ptr %l154, !tbaa !29
  store ptr %t298, ptr %l156, !tbaa !29
  store i1 false, ptr %l157, !tbaa !21
  %t300 = load ptr, ptr %l156, !tbaa !29
  %t301 = icmp ne ptr %t300, null
  br i1 %t301, label %bb100, label %bb101
bb100:
  %t303 = load ptr, ptr %l156, !tbaa !29
  %t304 = load i64, ptr %t303, !range !{i64 0, i64 18}
  %t306 = icmp eq i64 %t304, 10
  store i1 %t306, ptr %l157, !tbaa !21
  br label %bb101
bb101:
  %t307 = load i1, ptr %l157, !tbaa !21
  br i1 %t307, label %bb102, label %bb103
bb102:
  br label %bb104
bb103:
  br label %bb105
bb104:
  store i1 true, ptr %l155, !tbaa !21
  br label %bb110
bb105:
  br i1 true, label %bb106, label %bb107
bb106:
  br label %bb108
bb107:
  br label %bb109
bb108:
  store i1 false, ptr %l155, !tbaa !21
  br label %bb110
bb109:
  call void @__olang_check_failed(ptr @olang_loc_40ec225b43a9c35_aa9faf1719a6cb49)
  unreachable
bb110:
  %t308 = load i1, ptr %l155, !tbaa !21
  store i1 %t308, ptr %l17, !tbaa !21
  %t309 = load i1, ptr %l15, !tbaa !21
  %t311 = xor i1 %t309, true
  br i1 %t311, label %bb111, label %bb112
bb111:
  store i1 true, ptr %l162, !tbaa !21
  br label %bb117
bb112:
  %t313 = load ptr, ptr %l0, !tbaa !29
  %t314 = getelementptr %"compiler/typed:Local", ptr %l10, i32 0, i32 2
  %t315 = load i32, ptr %t314, !tbaa !23
  %t318 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisRef(ptr %v0, ptr %t313, i32 %t315)
  store i1 %t318, ptr %l165
  br label %bb113
bb113:
  %t319 = load i1, ptr %l165, !tbaa !21
  %t320 = xor i1 %t319, true
  br i1 %t320, label %bb114, label %bb115
bb114:
  %t322 = load i1, ptr %l17, !tbaa !21
  %t324 = xor i1 %t322, true
  store i1 %t324, ptr %l167, !tbaa !21
  br label %bb116
bb115:
  store i1 false, ptr %l167, !tbaa !21
  br label %bb116
bb116:
  %t326 = load i1, ptr %l167, !tbaa !21
  store i1 %t326, ptr %l162, !tbaa !21
  br label %bb117
bb117:
  %t327 = load i1, ptr %l162, !tbaa !21
  br i1 %t327, label %bb118, label %bb119
bb118:
  %t328 = load i64, ptr %l9, !tbaa !24
  call void @__olang_scope_close(ptr %s7)
  store i64 %t328, ptr %rv
  br label %ret
bb119:
  br label %bb120
bb120:
  %t330 = load ptr, ptr %l0, !tbaa !29
  %t331 = load ptr, ptr %l11, !tbaa !29
  %t333 = load i64, ptr %l2, !tbaa !24
  %t335 = add i64 %t333, 1
  %t339 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2emadeLocal(ptr %v0, ptr %v0, ptr %t330, ptr %t331, i64 %t335)
  store i64 %t339, ptr %l176
  br label %bb121
bb121:
  %t340 = load i64, ptr %l176, !tbaa !24
  store i64 %t340, ptr %l18, !tbaa !24
  %t341 = load i64, ptr %l18, !tbaa !24
  %t343 = icmp sge i64 %t341, 0
  br i1 %t343, label %bb122, label %bb123
bb122:
  %t345 = load i64, ptr %l18, !tbaa !24
  store i64 %t345, ptr %l179, !tbaa !24
  br label %bb124
bb123:
  %t347 = load i64, ptr %l9, !tbaa !24
  store i64 %t347, ptr %l179, !tbaa !24
  br label %bb124
bb124:
  call void @__olang_scope_close(ptr %s7)
  %t349 = load i64, ptr %l179, !tbaa !24
  store i64 %t349, ptr %rv
  br label %ret
bb125:
  br i1 true, label %bb126, label %bb127
bb126:
  br label %bb128
bb127:
  br label %bb129
bb128:
  br label %bb130
bb129:
  call void @__olang_check_failed(ptr @olang_loc_ee34d1998e8cb262_dc9f2cfe1a0305ee)
  unreachable
bb130:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2emarkAt(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %l13 = alloca ptr
  %l21 = alloca { i64, ptr }
  %l22 = alloca i32
  %l29 = alloca i1
  %l30 = alloca { i64, ptr }
  %l44 = alloca i64
  %l47 = alloca i64
  %l65 = alloca { i64, ptr }
  %l69 = alloca i1
  %l77 = alloca { i64, ptr }
  %l79 = alloca i64
  %l84 = alloca i64
  %l85 = alloca i64
  %l91 = alloca i1
  %l101 = alloca i1
  %l102 = alloca { i64, ptr }
  %l109 = alloca i1
  %l119 = alloca %"compiler/source:Span"
  %s3 = alloca %olang.scope
  %rv = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 12
  store ptr %t3, ptr %l13, !tbaa !29
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t6 = getelementptr %"compiler/scope:Scoper", ptr %t4, i32 0, i32 28
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = icmp eq ptr %t7, null
  br i1 %t9, label %bb1, label %bb2
bb1:
  call void @__olang_check_failed(ptr @olang_loc_b2f9ba032aa0cd37_ded861412cec268b)
  unreachable
bb2:
  br label %bb3
bb3:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/scope:Scoper", ptr %t11, i32 0, i32 28
  %t14 = load ptr, ptr %t13, !tbaa !29
  %t17 = getelementptr %"compiler/typed:Body", ptr %t14, i32 0, i32 3
  %t18 = load i64, ptr %t17, !tbaa !24
  %t19 = load ptr, ptr %l13, !tbaa !29
  %t21 = call { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_He9bc6cfad7ef603960b4717f3121b8e8(ptr %v0, ptr %v0, ptr %t19, i64 %t18)
  %t22 = extractvalue { i32, { i64, ptr } } %t21, 1
  %t23 = extractvalue { i32, { i64, ptr } } %t21, 0
  store i32 %t23, ptr %l22
  %t24 = icmp ne i32 %t23, 0
  br i1 %t24, label %bb5, label %ok.25, !prof !99
ok.25:
  store { i64, ptr } %t22, ptr %l21
  br label %bb4
bb4:
  %t26 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t26, ptr %l11, !tbaa !27
  br label %bb7
bb5:
  br label %bb6
bb6:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d48, i32 0, i32 1) }, ptr %l11, !tbaa !27
  br label %bb7
bb7:
  %t27 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t27, ptr %l3, !tbaa !27
  %t28 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t29 = load i32, ptr %t28, !tbaa !23
  %t31 = sext i32 %t29 to i64
  store i64 %t31, ptr %l4, !tbaa !24
  br label %bb8
bb8:
  %t33 = load i64, ptr %l4, !tbaa !24
  %t34 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t36 = extractvalue { i64, ptr } %t34, 0
  %t39 = icmp slt i64 %t33, %t36
  br i1 %t39, label %bb9, label %bb10
bb9:
  %t41 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t41, ptr %l30, !tbaa !27
  %t42 = load i64, ptr %l4, !tbaa !24
  %t44 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !27
  %t46 = getelementptr i8, ptr %t45, i64 %t42
  %t47 = load i8, ptr %t46, !tbaa !32
  %t49 = icmp ne i8 %t47, 10
  store i1 %t49, ptr %l29, !tbaa !21
  br label %bb11
bb10:
  store i1 false, ptr %l29, !tbaa !21
  br label %bb11
bb11:
  %t51 = load i1, ptr %l29, !tbaa !21
  %t52 = xor i1 %t51, true
  br i1 %t52, label %bb12, label %bb13
bb12:
  br label %bb16
bb13:
  br label %bb14
bb14:
  %t54 = load i64, ptr %l4, !tbaa !24
  %t57 = add i64 %t54, 1
  store i64 %t57, ptr %l4, !tbaa !24
  br label %bb15
bb15:
  br label %bb8
bb16:
  %t59 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t60 = load i32, ptr %t59, !tbaa !23
  %t62 = sext i32 %t60 to i64
  store i64 %t62, ptr %l5, !tbaa !24
  %t64 = load i64, ptr %l4, !tbaa !24
  store i64 %t64, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t66 = load i64, ptr %l6, !tbaa !24
  %t67 = load i64, ptr %l5, !tbaa !24
  %t70 = icmp sgt i64 %t66, %t67
  br i1 %t70, label %bb17, label %bb18
bb17:
  %t72 = load i64, ptr %l7, !tbaa !24
  %t74 = icmp sgt i64 %t72, 0
  br i1 %t74, label %bb19, label %bb20
bb18:
  store i64 0, ptr %l44, !tbaa !24
  br label %bb22
bb19:
  %t76 = load i64, ptr %l6, !tbaa !24
  %t77 = load i64, ptr %l5, !tbaa !24
  %t80 = sub i64 %t76, %t77
  %t81 = load i64, ptr %l7, !tbaa !24
  %t84 = add i64 %t80, %t81
  %t86 = sub i64 %t84, 1
  %t87 = load i64, ptr %l7, !tbaa !24
  %t90 = sdiv i64 %t86, %t87
  store i64 %t90, ptr %l47, !tbaa !24
  br label %bb21
bb20:
  store i64 0, ptr %l47, !tbaa !24
  br label %bb21
bb21:
  %t92 = load i64, ptr %l47, !tbaa !24
  store i64 %t92, ptr %l44, !tbaa !24
  br label %bb22
bb22:
  %t93 = load i64, ptr %l44, !tbaa !24
  store i64 %t93, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb23
bb23:
  store %olang.scope zeroinitializer, ptr %s3
  %t94 = load i64, ptr %l9, !tbaa !24
  %t95 = load i64, ptr %l8, !tbaa !24
  %t98 = icmp slt i64 %t94, %t95
  %t100 = xor i1 %t98, true
  br i1 %t100, label %bb24, label %bb25
bb24:
  call void @__olang_scope_close(ptr %s3)
  br label %bb52
bb25:
  br label %bb26
bb26:
  %t102 = load i64, ptr %l5, !tbaa !24
  %t103 = load i64, ptr %l9, !tbaa !24
  %t104 = load i64, ptr %l7, !tbaa !24
  %t107 = mul i64 %t103, %t104
  %t110 = add i64 %t102, %t107
  store i64 %t110, ptr %l10, !tbaa !24
  %t112 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t112, ptr %l65, !tbaa !27
  %t113 = load i64, ptr %l10, !tbaa !24
  %t115 = getelementptr { i64, ptr }, ptr %l65, i32 0, i32 1
  %t116 = load ptr, ptr %t115, !tbaa !27
  %t117 = getelementptr i8, ptr %t116, i64 %t113
  %t118 = load i8, ptr %t117, !tbaa !32
  %t120 = icmp ne i8 %t118, 38
  br i1 %t120, label %bb27, label %bb28
bb27:
  store i1 true, ptr %l69, !tbaa !21
  br label %bb29
bb28:
  %t122 = load i64, ptr %l10, !tbaa !24
  %t124 = add i64 %t122, 1
  %t125 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t127 = extractvalue { i64, ptr } %t125, 0
  %t130 = add i64 %t124, %t127
  %t131 = load i64, ptr %l4, !tbaa !24
  %t134 = icmp sgt i64 %t130, %t131
  store i1 %t134, ptr %l69, !tbaa !21
  br label %bb29
bb29:
  %t136 = load i1, ptr %l69, !tbaa !21
  br i1 %t136, label %bb30, label %bb31
bb30:
  call void @__olang_scope_close(ptr %s3)
  br label %bb51
bb31:
  br label %bb32
bb32:
  %t137 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t137, ptr %l77, !tbaa !27
  %t138 = load i64, ptr %l10, !tbaa !24
  %t140 = add i64 %t138, 1
  store i64 %t140, ptr %l79, !tbaa !24
  %t141 = load i64, ptr %l10, !tbaa !24
  %t143 = add i64 %t141, 1
  %t144 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t146 = extractvalue { i64, ptr } %t144, 0
  %t149 = add i64 %t143, %t146
  store i64 %t149, ptr %l84, !tbaa !24
  %t150 = load { i64, ptr }, ptr %l77, !tbaa !27
  %t151 = extractvalue { i64, ptr } %t150, 0
  store i64 %t151, ptr %l85, !tbaa !24
  %t152 = load i64, ptr %l79, !tbaa !24
  %t153 = icmp sge i64 %t152, 0
  br i1 %t153, label %bb33, label %bb34
bb33:
  %t155 = load i64, ptr %l79, !tbaa !24
  %t156 = load i64, ptr %l84, !tbaa !24
  %t157 = icmp sle i64 %t155, %t156
  br i1 %t157, label %bb35, label %bb36
bb34:
  call void @__olang_check_failed(ptr @olang_loc_6789d922954f6d60_a7a35b45139b1b94)
  unreachable
bb35:
  %t159 = load i64, ptr %l84, !tbaa !24
  %t160 = load i64, ptr %l85, !tbaa !24
  %t161 = icmp sle i64 %t159, %t160
  br i1 %t161, label %bb37, label %bb38
bb36:
  call void @__olang_check_failed(ptr @olang_loc_6789d922954f6d60_a7a35b45139b1b94)
  unreachable
bb37:
  %t163 = getelementptr { i64, ptr }, ptr %l77, i32 0, i32 1
  %t164 = load ptr, ptr %t163, !tbaa !27
  %t165 = load i64, ptr %l79, !tbaa !24
  %t166 = load i64, ptr %l84, !tbaa !24
  %t167 = getelementptr i8, ptr %t164, i64 %t165
  %t168 = sub i64 %t166, %t165
  %t169 = insertvalue { i64, ptr } undef, i64 %t168, 0
  %t170 = insertvalue { i64, ptr } %t169, ptr %t167, 1
  %t171 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t174 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %t170, { i64, ptr } %t171)
  store i1 %t174, ptr %l91
  br label %bb39
bb38:
  call void @__olang_check_failed(ptr @olang_loc_6789d922954f6d60_a7a35b45139b1b94)
  unreachable
bb39:
  %t175 = load i1, ptr %l91, !tbaa !21
  %t176 = xor i1 %t175, true
  br i1 %t176, label %bb40, label %bb41
bb40:
  call void @__olang_scope_close(ptr %s3)
  br label %bb51
bb41:
  br label %bb42
bb42:
  %t178 = load i64, ptr %l10, !tbaa !24
  %t180 = add i64 %t178, 1
  %t181 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t183 = extractvalue { i64, ptr } %t181, 0
  %t186 = add i64 %t180, %t183
  %t187 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t189 = extractvalue { i64, ptr } %t187, 0
  %t192 = icmp slt i64 %t186, %t189
  br i1 %t192, label %bb43, label %bb44
bb43:
  %t194 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t194, ptr %l102, !tbaa !27
  %t195 = load i64, ptr %l10, !tbaa !24
  %t197 = add i64 %t195, 1
  %t198 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t200 = extractvalue { i64, ptr } %t198, 0
  %t203 = add i64 %t197, %t200
  %t205 = getelementptr { i64, ptr }, ptr %l102, i32 0, i32 1
  %t206 = load ptr, ptr %t205, !tbaa !27
  %t207 = getelementptr i8, ptr %t206, i64 %t203
  %t208 = load i8, ptr %t207, !tbaa !32
  %t210 = call i1 @compiler_2fscope_2eisNameChar(i8 %t208)
  store i1 %t210, ptr %l109
  br label %bb45
bb44:
  store i1 false, ptr %l101, !tbaa !21
  br label %bb46
bb45:
  %t211 = load i1, ptr %l109, !tbaa !21
  store i1 %t211, ptr %l101, !tbaa !21
  br label %bb46
bb46:
  %t212 = load i1, ptr %l101, !tbaa !21
  br i1 %t212, label %bb47, label %bb48
bb47:
  call void @__olang_scope_close(ptr %s3)
  br label %bb51
bb48:
  br label %bb49
bb49:
  %t213 = load i64, ptr %l10, !tbaa !24
  %t215 = add i64 %t213, 1
  %t217 = trunc i64 %t215 to i32
  %t218 = load i64, ptr %l10, !tbaa !24
  %t220 = add i64 %t218, 1
  %t221 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t223 = extractvalue { i64, ptr } %t221, 0
  %t226 = add i64 %t220, %t223
  %t228 = trunc i64 %t226 to i32
  %t231 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s3, i32 %t217, i32 %t228)
  store %"compiler/source:Span" %t231, ptr %l119
  br label %bb50
bb50:
  call void @__olang_scope_close(ptr %s3)
  %t232 = load %"compiler/source:Span", ptr %l119
  store %"compiler/source:Span" %t232, ptr %rv
  br label %ret
bb51:
  %t233 = load i64, ptr %l9, !tbaa !24
  %t236 = add i64 %t233, 1
  store i64 %t236, ptr %l9, !tbaa !24
  br label %bb23
bb52:
  %t238 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t238, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2emarkLines(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l2 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca %"compiler/scope:markRead"
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %lp7 = alloca ptr
  %l8 = alloca %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9"
  %l9 = alloca %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613"
  %l10 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l11 = alloca %"std/prelude/text:StringBuilder"
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l21 = alloca i64
  %l23 = alloca i64
  %l28 = alloca %"compiler/scope:markRead"
  %l29 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l32 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l33 = alloca i32
  %l35 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l36 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l45 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l47 = alloca %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9"
  %l48 = alloca %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613"
  %l50 = alloca %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613"
  %l51 = alloca i32
  %l53 = alloca i1
  %l55 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l56 = alloca i64
  %l58 = alloca { i64, ptr }
  %l59 = alloca i64
  %l60 = alloca { i64, ptr }
  %l66 = alloca %"std/prelude/text:StringBuilder"
  %l67 = alloca ptr
  %l70 = alloca { i64, ptr }
  %l74 = alloca i64
  %l78 = alloca i64
  %l81 = alloca i64
  %l99 = alloca ptr
  %l102 = alloca { i64, ptr }
  %l105 = alloca i64
  %l111 = alloca ptr
  %l112 = alloca i64
  %l115 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cI64_3e_3e(ptr %s0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l18
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l18
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %l2
  %t5 = getelementptr %"compiler/scope:compRun", ptr %a1, i32 0, i32 9
  store ptr %t5, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t7 = load i64, ptr %l4, !tbaa !24
  store i64 %t7, ptr %l21, !tbaa !24
  %t8 = load ptr, ptr %l3, !tbaa !29
  %t10 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3amarkRead_3e_2eLen_3ccompiler_2fscope_3amarkRead_3e(ptr %v1, ptr %t8)
  store i64 %t10, ptr %l23
  br label %bb3
bb3:
  %t11 = load i64, ptr %l21, !tbaa !24
  %t12 = load i64, ptr %l23, !tbaa !24
  %t13 = icmp slt i64 %t11, %t12
  %t15 = xor i1 %t13, true
  br i1 %t15, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s2)
  br label %bb17
bb5:
  br label %bb6
bb6:
  %t17 = load ptr, ptr %l3, !tbaa !29
  %t18 = load i64, ptr %l4, !tbaa !24
  %t21 = call %"compiler/scope:markRead" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3amarkRead_3e_2eAt_3ccompiler_2fscope_3amarkRead_3e(ptr %v1, ptr %t17, i64 %t18)
  store %"compiler/scope:markRead" %t21, ptr %l28
  br label %bb7
bb7:
  %t22 = load %"compiler/scope:markRead", ptr %l28
  store %"compiler/scope:markRead" %t22, ptr %l5
  %t23 = getelementptr %"compiler/scope:markRead", ptr %l5, i32 0, i32 0
  %t24 = load i64, ptr %t23, !tbaa !24
  %t27 = call { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cI_Heebd28230b8fdd871dbb93ccdeb5ff7f(ptr %s0, ptr %s0, ptr %l2, i64 %t24)
  %t28 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t27, 1
  %t29 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t27, 0
  store i32 %t29, ptr %l33
  %t30 = icmp ne i32 %t29, 0
  br i1 %t30, label %bb9, label %ok.31, !prof !99
ok.31:
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t28, ptr %l32
  br label %bb8
bb8:
  %t33 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %s2, ptr %l32)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t33, ptr %l35
  br label %bb11
bb9:
  br label %bb10
bb10:
  %t34 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t34, ptr %l36
  br label %bb12
bb11:
  %t35 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l35
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t35, ptr %l29
  br label %bb13
bb12:
  %t36 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l36
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t36, ptr %l29
  br label %bb13
bb13:
  %t37 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l29
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t37, ptr %l6
  %t38 = getelementptr %"compiler/scope:markRead", ptr %l5, i32 0, i32 1
  %t39 = load i64, ptr %t38, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s2, ptr %l6, i64 %t39)
  br label %bb14
bb14:
  %t42 = getelementptr %"compiler/scope:markRead", ptr %l5, i32 0, i32 0
  %t43 = load i64, ptr %t42, !tbaa !24
  %t44 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l6
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cI_H5b4ed7dba3fb4e44f8784ebbf4461977(ptr %s0, ptr %s2, ptr %l2, i64 %t43, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t44)
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s2)
  br label %bb16
bb16:
  %t48 = load i64, ptr %l4, !tbaa !24
  %t51 = add i64 %t48, 1
  store i64 %t51, ptr %l4, !tbaa !24
  br label %bb2
bb17:
  %t53 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t53, ptr %l45
  br label %bb18
bb18:
  %t54 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 32, i64 8)
  store ptr %t54, ptr %lp7
  %t55 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l45
  %t56 = load ptr, ptr %lp7
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t55, ptr %t56
  %t58 = call %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cI_H8538c7ff23a6122b13758d112708dba7(ptr %s0, ptr %s0, ptr %l2)
  store %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" %t58, ptr %l47
  br label %bb19
bb19:
  %t59 = load %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9", ptr %l47
  store %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" %t59, ptr %l8
  br label %bb20
bb20:
  store %olang.scope zeroinitializer, ptr %s5
  %t61 = call { i32, %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapIter_3cI64_2c_20std_2fprelude_2fvec_3aVec_H07094359971f7e5c30038a271a96bfe1(ptr %s0, ptr %s5, ptr %l8)
  %t62 = extractvalue { i32, %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613" } %t61, 1
  %t63 = extractvalue { i32, %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613" } %t61, 0
  store i32 %t63, ptr %l51
  %t64 = icmp ne i32 %t63, 0
  br i1 %t64, label %bb22, label %ok.65, !prof !99
ok.65:
  store %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613" %t62, ptr %l50
  br label %bb21
bb21:
  %t66 = load %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613", ptr %l50
  store %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613" %t66, ptr %l48
  br label %bb24
bb22:
  %t67 = load i32, ptr %l51, !tbaa !23
  %t68 = ashr i32 %t67, 16
  %t70 = icmp eq i32 %t68, 1
  store i1 %t70, ptr %l53, !tbaa !21
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s5)
  br label %bb58
bb24:
  %t71 = load %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613", ptr %l48
  store %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613" %t71, ptr %l9
  %t72 = getelementptr %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613", ptr %l9, i32 0, i32 1
  %t73 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t72
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t73, ptr %l55
  %t75 = call ptr @__olang_scope_hold(ptr %s5)
  %t76 = ptrtoint ptr %t75 to i64
  store i64 %t76, ptr %l56, !tbaa !24
  %t77 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t77, label %bb25, label %bb26
bb25:
  %t79 = call ptr @__olang_region_make_part(ptr %s5)
  %t80 = ptrtoint ptr %t79 to i64
  store i64 %t80, ptr %l56, !tbaa !24
  br label %bb26
bb26:
  %t81 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l55, i32 0, i32 0
  %t82 = load { i64, ptr }, ptr %t81, !tbaa !27
  store { i64, ptr } %t82, ptr %l58, !tbaa !27
  %t83 = load { i64, ptr }, ptr %l58, !tbaa !27
  %t84 = extractvalue { i64, ptr } %t83, 0
  store i64 %t84, ptr %l59, !tbaa !24
  %t85 = load i64, ptr %l59, !tbaa !24
  %t86 = mul i64 %t85, 8
  %t87 = load i64, ptr %l56
  %t88 = inttoptr i64 %t87 to ptr
  %t89 = call ptr @__olang_held_alloc(ptr %t88, i64 %t86)
  %t90 = insertvalue { i64, ptr } undef, i64 %t85, 0
  %t91 = insertvalue { i64, ptr } %t90, ptr %t89, 1
  store { i64, ptr } %t91, ptr %l60, !tbaa !27
  %t92 = getelementptr { i64, ptr }, ptr %l60, i32 0, i32 1
  %t93 = load ptr, ptr %t92, !tbaa !27
  %t94 = getelementptr { i64, ptr }, ptr %l58, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !27
  %t96 = load i64, ptr %l59, !tbaa !24
  %t97 = mul i64 %t96, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t93, ptr %t95, i64 %t97, i1 false)
  %t98 = load { i64, ptr }, ptr %l60, !tbaa !27
  %t99 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l55, i32 0, i32 0
  store { i64, ptr } %t98, ptr %t99, !tbaa !27
  %t100 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t100, label %bb27, label %bb28
bb27:
  %t102 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l55, i32 0, i32 0
  %t103 = load { i64, ptr }, ptr %t102, !tbaa !27
  %t104 = extractvalue { i64, ptr } %t103, 0
  %t106 = icmp eq i64 %t104, 0
  br i1 %t106, label %bb29, label %bb30
bb28:
  %t108 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l55
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t108, ptr %l10
  %t109 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_49, 0
  %t110 = insertvalue { ptr, ptr } %t109, ptr null, 1
  %t113 = extractvalue { ptr, ptr } %t110, 0
  %t114 = extractvalue { ptr, ptr } %t110, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSort_3cI64_2c_20_3f_3e(ptr %s5, ptr %s5, ptr %l10, ptr %t113, ptr %t114)
  br label %bb31
bb29:
  %t115 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l55, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t115, !tbaa !27
  br label %bb30
bb30:
  %t116 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l55, i32 0, i32 0
  %t117 = load i64, ptr %l56
  %t118 = inttoptr i64 %t117 to ptr
  %t119 = load { i64, ptr }, ptr %t116
  %t120 = extractvalue { i64, ptr } %t119, 1
  %t121 = call ptr @__olang_region_or(ptr %t120, ptr null)
  %t122 = icmp ne ptr %t121, null
  %t123 = select i1 %t122, ptr %t121, ptr null
  call void @__olang_region_settle_in(ptr %t118, ptr %t123)
  br label %bb28
bb31:
  %t124 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s5)
  store %"std/prelude/text:StringBuilder" %t124, ptr %l66
  br label %bb32
bb32:
  %t125 = load %"std/prelude/text:StringBuilder", ptr %l66
  store %"std/prelude/text:StringBuilder" %t125, ptr %l11
  store ptr %l11, ptr %l67, !tbaa !29
  %t127 = getelementptr %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613", ptr %l9, i32 0, i32 0
  %t128 = load i64, ptr %t127, !tbaa !24
  %t131 = call { i64, ptr } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eNameOf(ptr %v0, ptr %s5, ptr %a0, i64 %t128)
  store { i64, ptr } %t131, ptr %l70
  br label %bb33
bb33:
  %t132 = load { i64, ptr }, ptr %l70, !tbaa !27
  %t133 = extractvalue { i64, ptr } %t132, 1
  %t134 = extractvalue { i64, ptr } %t132, 0
  %t135 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d50, i32 0, i32 1) }, 1
  %t136 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d50, i32 0, i32 1) }, 0
  %t137 = add i64 %t134, %t136
  %t138 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t137)
  call void @olang_textcopy(ptr %t138, ptr %t133, i64 %t134)
  %t139 = getelementptr i8, ptr %t138, i64 %t134
  call void @olang_textcopy(ptr %t139, ptr %t135, i64 %t136)
  %t140 = insertvalue { i64, ptr } undef, i64 %t137, 0
  %t141 = insertvalue { i64, ptr } %t140, ptr %t138, 1
  %t143 = load ptr, ptr %l67, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s5, ptr %s5, ptr %t143, { i64, ptr } %t141)
  br label %bb34
bb34:
  store i64 0, ptr %l12, !tbaa !24
  %t146 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s5, ptr %l10)
  store i64 %t146, ptr %l74
  br label %bb35
bb35:
  %t147 = load i64, ptr %l74, !tbaa !24
  store i64 %t147, ptr %l13, !tbaa !24
  store i64 1, ptr %l14, !tbaa !24
  %t148 = load i64, ptr %l13, !tbaa !24
  %t149 = load i64, ptr %l12, !tbaa !24
  %t152 = icmp sgt i64 %t148, %t149
  br i1 %t152, label %bb36, label %bb37
bb36:
  %t154 = load i64, ptr %l14, !tbaa !24
  %t156 = icmp sgt i64 %t154, 0
  br i1 %t156, label %bb38, label %bb39
bb37:
  store i64 0, ptr %l78, !tbaa !24
  br label %bb41
bb38:
  %t158 = load i64, ptr %l13, !tbaa !24
  %t159 = load i64, ptr %l12, !tbaa !24
  %t162 = sub i64 %t158, %t159
  %t163 = load i64, ptr %l14, !tbaa !24
  %t166 = add i64 %t162, %t163
  %t168 = sub i64 %t166, 1
  %t169 = load i64, ptr %l14, !tbaa !24
  %t172 = sdiv i64 %t168, %t169
  store i64 %t172, ptr %l81, !tbaa !24
  br label %bb40
bb39:
  store i64 0, ptr %l81, !tbaa !24
  br label %bb40
bb40:
  %t174 = load i64, ptr %l81, !tbaa !24
  store i64 %t174, ptr %l78, !tbaa !24
  br label %bb41
bb41:
  %t175 = load i64, ptr %l78, !tbaa !24
  store i64 %t175, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  br label %bb42
bb42:
  store %olang.scope zeroinitializer, ptr %s8
  %t176 = load i64, ptr %l16, !tbaa !24
  %t177 = load i64, ptr %l15, !tbaa !24
  %t180 = icmp slt i64 %t176, %t177
  %t182 = xor i1 %t180, true
  br i1 %t182, label %bb43, label %bb44
bb43:
  call void @__olang_scope_close(ptr %s8)
  br label %bb52
bb44:
  br label %bb45
bb45:
  %t184 = load i64, ptr %l12, !tbaa !24
  %t185 = load i64, ptr %l16, !tbaa !24
  %t186 = load i64, ptr %l14, !tbaa !24
  %t189 = mul i64 %t185, %t186
  %t192 = add i64 %t184, %t189
  store i64 %t192, ptr %l17, !tbaa !24
  store ptr %l11, ptr %l99, !tbaa !29
  %t194 = load i64, ptr %l17, !tbaa !24
  %t196 = icmp sgt i64 %t194, 0
  br i1 %t196, label %bb46, label %bb47
bb46:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d51, i32 0, i32 1) }, ptr %l102, !tbaa !27
  br label %bb48
bb47:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d52, i32 0, i32 1) }, ptr %l102, !tbaa !27
  br label %bb48
bb48:
  %t198 = load i64, ptr %l17, !tbaa !24
  %t201 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s5, ptr %l10, i64 %t198)
  store i64 %t201, ptr %l105
  br label %bb49
bb49:
  %t202 = load { i64, ptr }, ptr %l102, !tbaa !27
  %t203 = extractvalue { i64, ptr } %t202, 1
  %t204 = extractvalue { i64, ptr } %t202, 0
  %t205 = load i64, ptr %l105, !tbaa !24
  %t206 = call i64 @__olang_fmt_i64(ptr null, i64 %t205)
  %t207 = add i64 %t204, %t206
  %t208 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t207)
  call void @olang_textcopy(ptr %t208, ptr %t203, i64 %t204)
  %t209 = getelementptr i8, ptr %t208, i64 %t204
  %t210 = call i64 @__olang_fmt_i64(ptr %t209, i64 %t205)
  %t211 = insertvalue { i64, ptr } undef, i64 %t207, 0
  %t212 = insertvalue { i64, ptr } %t211, ptr %t208, 1
  %t214 = load ptr, ptr %l99, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s5, ptr %s8, ptr %t214, { i64, ptr } %t212)
  br label %bb50
bb50:
  call void @__olang_scope_close(ptr %s8)
  br label %bb51
bb51:
  %t216 = load i64, ptr %l16, !tbaa !24
  %t219 = add i64 %t216, 1
  store i64 %t219, ptr %l16, !tbaa !24
  br label %bb42
bb52:
  %t221 = load ptr, ptr %lp7
  store ptr %t221, ptr %l111, !tbaa !29
  %t222 = call ptr @__olang_scope_hold(ptr %v2)
  %t223 = ptrtoint ptr %t222 to i64
  store i64 %t223, ptr %l112, !tbaa !24
  %t224 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t224, label %bb53, label %bb54
bb53:
  %t226 = call ptr @__olang_region_make(ptr %v2)
  %t227 = ptrtoint ptr %t226 to i64
  store i64 %t227, ptr %l112, !tbaa !24
  br label %bb54
bb54:
  %t228 = load i64, ptr %l112
  %t229 = inttoptr i64 %t228 to ptr
  %t231 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s5, ptr %t229, ptr %l11)
  store { i64, ptr } %t231, ptr %l115
  br label %bb55
bb55:
  %t232 = load { i64, ptr }, ptr %l115, !tbaa !27
  %t233 = load ptr, ptr %l111, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v2, ptr %v2, ptr %t233, { i64, ptr } %t232)
  br label %bb56
bb56:
  call void @__olang_scope_close(ptr %s5)
  br label %bb57
bb57:
  br label %bb20
bb58:
  %t235 = load ptr, ptr %lp7
  %t236 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_53, 0
  %t237 = insertvalue { ptr, ptr } %t236, ptr null, 1
  %t240 = extractvalue { ptr, ptr } %t237, 0
  %t241 = extractvalue { ptr, ptr } %t237, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H1642129570dad448bb7dcc47c334de83(ptr %v2, ptr %s0, ptr %t235, ptr %t240, ptr %t241)
  br label %bb59
bb59:
  %t242 = load ptr, ptr %lp7
  %t243 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t242
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t243, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enoteThroughResult(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, ptr %a2, i64 %a3, { i64, ptr } %a4, i64 %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca %"compiler/scope:rel"
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca ptr
  %l17 = alloca i64
  %l22 = alloca i64
  %l25 = alloca i1
  %l28 = alloca i1
  %l31 = alloca ptr
  %l34 = alloca i32
  %l35 = alloca i64
  %l39 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l42 = alloca ptr
  %l45 = alloca i64
  %l47 = alloca i64
  %l52 = alloca %"compiler/scope:rel"
  %l55 = alloca i1
  %l60 = alloca i1
  %l64 = alloca i1
  %l72 = alloca i64
  %l80 = alloca { i64, ptr }
  %l84 = alloca i64
  %l86 = alloca i1
  %l89 = alloca i1
  %l100 = alloca i64
  %l105 = alloca { i64, ptr }
  %l114 = alloca i64
  %l116 = alloca i64
  %l121 = alloca i64
  %l125 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i64 %a3, ptr %l3
  store { i64, ptr } %a4, ptr %l4
  store i64 %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t4 = getelementptr %"compiler/typed:Call", ptr %t2, i32 0, i32 0
  %t5 = load ptr, ptr %t4, !tbaa !29
  %t8 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebodyOf(ptr %v0, ptr %v1, ptr %t1, ptr %t5)
  store i64 %t8, ptr %l22
  br label %bb1
bb1:
  %t9 = load i64, ptr %l22, !tbaa !24
  store i64 %t9, ptr %l6, !tbaa !24
  %t10 = load i64, ptr %l6, !tbaa !24
  %t12 = icmp slt i64 %t10, 0
  br i1 %t12, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l25, !tbaa !21
  br label %bb5
bb3:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t15 = load i64, ptr %l6, !tbaa !24
  %t18 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esummed(ptr %v0, ptr %t14, i64 %t15)
  store i1 %t18, ptr %l28
  br label %bb4
bb4:
  %t19 = load i1, ptr %l28, !tbaa !21
  %t20 = xor i1 %t19, true
  store i1 %t20, ptr %l25, !tbaa !21
  br label %bb5
bb5:
  %t22 = load i1, ptr %l25, !tbaa !21
  br i1 %t22, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t24 = load ptr, ptr %l0, !tbaa !29
  store ptr %t24, ptr %l31, !tbaa !29
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t26 = load ptr, ptr %l2, !tbaa !29
  %t29 = call i32 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecalleeType(ptr %v0, ptr %v1, ptr %t25, ptr %t26)
  store i32 %t29, ptr %l34
  br label %bb9
bb9:
  %t30 = load ptr, ptr %l31, !tbaa !29
  %t31 = load i32, ptr %l34, !tbaa !23
  %t32 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eresultVarOf(ptr %v0, ptr %t30, i32 %t31)
  store i64 %t32, ptr %l35
  br label %bb10
bb10:
  %t33 = load i64, ptr %l35, !tbaa !24
  store i64 %t33, ptr %l7, !tbaa !24
  %t34 = load i64, ptr %l7, !tbaa !24
  %t36 = icmp slt i64 %t34, 0
  br i1 %t36, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  store i64 -1, ptr %l8, !tbaa !24
  %t39 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t39, ptr %l39
  br label %bb14
bb14:
  %t40 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l39
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t40, ptr %l9
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t42 = load i64, ptr %l6, !tbaa !24
  %t45 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esum(ptr %v0, ptr %v0, ptr %t41, i64 %t42)
  store ptr %t45, ptr %l42
  br label %bb15
bb15:
  %t46 = load ptr, ptr %l42, !tbaa !29
  %t48 = getelementptr %"compiler/scope:summary", ptr %t46, i32 0, i32 0
  store ptr %t48, ptr %l10, !tbaa !29
  store i64 0, ptr %l11, !tbaa !24
  br label %bb16
bb16:
  %t50 = load i64, ptr %l11, !tbaa !24
  store i64 %t50, ptr %l45, !tbaa !24
  %t51 = load ptr, ptr %l10, !tbaa !29
  %t53 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3arel_3e_2eLen_3ccompiler_2fscope_3arel_3e(ptr %v0, ptr %t51)
  store i64 %t53, ptr %l47
  br label %bb17
bb17:
  %t54 = load i64, ptr %l45, !tbaa !24
  %t55 = load i64, ptr %l47, !tbaa !24
  %t56 = icmp slt i64 %t54, %t55
  %t58 = xor i1 %t56, true
  br i1 %t58, label %bb18, label %bb19
bb18:
  br label %bb51
bb19:
  br label %bb20
bb20:
  %t60 = load ptr, ptr %l10, !tbaa !29
  %t61 = load i64, ptr %l11, !tbaa !24
  %t64 = call %"compiler/scope:rel" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3arel_3e_2eAt_3ccompiler_2fscope_3arel_3e(ptr %v0, ptr %t60, i64 %t61)
  store %"compiler/scope:rel" %t64, ptr %l52
  br label %bb21
bb21:
  %t65 = load %"compiler/scope:rel", ptr %l52
  store %"compiler/scope:rel" %t65, ptr %l12
  %t66 = getelementptr %"compiler/scope:rel", ptr %l12, i32 0, i32 1
  %t67 = load { i64, [2 x i64] }, ptr %t66
  %t69 = extractvalue { i64, [2 x i64] } %t67, 0
  %t70 = icmp eq i64 %t69, 2
  br i1 %t70, label %bb22, label %bb23
bb22:
  %t72 = getelementptr %"compiler/scope:rel", ptr %l12, i32 0, i32 1
  %t73 = getelementptr { i64, [2 x i64] }, ptr %t72, i32 0, i32 1
  %t74 = getelementptr { i64 }, ptr %t73, i32 0, i32 0
  %t75 = load i64, ptr %t74
  %t76 = load i64, ptr %l7, !tbaa !24
  %t79 = icmp eq i64 %t75, %t76
  store i1 %t79, ptr %l55, !tbaa !21
  br label %bb24
bb23:
  store i1 false, ptr %l55, !tbaa !21
  br label %bb24
bb24:
  %t81 = load i1, ptr %l55, !tbaa !21
  %t82 = xor i1 %t81, true
  br i1 %t82, label %bb25, label %bb26
bb25:
  store i1 true, ptr %l60, !tbaa !21
  br label %bb30
bb26:
  %t84 = getelementptr %"compiler/scope:rel", ptr %l12, i32 0, i32 1
  %t85 = getelementptr { i64, [2 x i64] }, ptr %t84, i32 0, i32 1
  %t86 = getelementptr { i64 }, ptr %t85, i32 0, i32 0
  %t87 = load i64, ptr %t86
  store i64 %t87, ptr %l13, !tbaa !24
  %t89 = getelementptr %"compiler/scope:rel", ptr %l12, i32 0, i32 0
  %t90 = load { i64, [2 x i64] }, ptr %t89
  %t92 = extractvalue { i64, [2 x i64] } %t90, 0
  %t93 = icmp eq i64 %t92, 2
  br i1 %t93, label %bb27, label %bb28
bb27:
  %t95 = getelementptr %"compiler/scope:rel", ptr %l12, i32 0, i32 0
  %t96 = getelementptr { i64, [2 x i64] }, ptr %t95, i32 0, i32 1
  %t97 = getelementptr { i64 }, ptr %t96, i32 0, i32 0
  %t98 = load i64, ptr %t97
  %t99 = load i64, ptr %l7, !tbaa !24
  %t102 = icmp eq i64 %t98, %t99
  store i1 %t102, ptr %l64, !tbaa !21
  br label %bb29
bb28:
  store i1 false, ptr %l64, !tbaa !21
  br label %bb29
bb29:
  %t104 = load i1, ptr %l64, !tbaa !21
  store i1 %t104, ptr %l60, !tbaa !21
  br label %bb30
bb30:
  %t105 = load i1, ptr %l60, !tbaa !21
  br i1 %t105, label %bb31, label %bb32
bb31:
  br label %bb50
bb32:
  br label %bb33
bb33:
  %t106 = getelementptr %"compiler/scope:rel", ptr %l12, i32 0, i32 1
  %t107 = getelementptr { i64, [2 x i64] }, ptr %t106, i32 0, i32 1
  %t108 = getelementptr { i64 }, ptr %t107, i32 0, i32 0
  %t109 = load i64, ptr %t108
  store i64 %t109, ptr %l14, !tbaa !24
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t112 = load ptr, ptr %l2, !tbaa !29
  %t113 = getelementptr %"compiler/scope:rel", ptr %l12, i32 0, i32 0
  %t114 = load { i64, [2 x i64] }, ptr %t113
  %t118 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eargOfVar(ptr %v0, ptr %v1, ptr %t111, ptr %t112, { i64, [2 x i64] } %t114)
  store i64 %t118, ptr %l72
  br label %bb34
bb34:
  %t119 = load i64, ptr %l72, !tbaa !24
  store i64 %t119, ptr %l15, !tbaa !24
  %t120 = load i64, ptr %l15, !tbaa !24
  %t122 = icmp slt i64 %t120, 0
  br i1 %t122, label %bb35, label %bb36
bb35:
  br label %bb50
bb36:
  br label %bb37
bb37:
  %t124 = load i64, ptr %l8, !tbaa !24
  %t126 = icmp slt i64 %t124, 0
  br i1 %t126, label %bb38, label %bb39
bb38:
  %t128 = load i64, ptr %l15, !tbaa !24
  store i64 %t128, ptr %l8, !tbaa !24
  br label %bb40
bb39:
  br label %bb40
bb40:
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t131 = load ptr, ptr %l2, !tbaa !29
  %t133 = getelementptr %"compiler/typed:Call", ptr %t131, i32 0, i32 1
  %t134 = load { i64, ptr }, ptr %t133, !tbaa !27
  store { i64, ptr } %t134, ptr %l80, !tbaa !27
  %t135 = load i64, ptr %l15, !tbaa !24
  %t137 = getelementptr { i64, ptr }, ptr %l80, i32 0, i32 1
  %t138 = load ptr, ptr %t137, !tbaa !27
  %t139 = getelementptr ptr, ptr %t138, i64 %t135
  %t140 = load ptr, ptr %t139, !tbaa !39
  %t144 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2emadeLocal(ptr %v0, ptr %v1, ptr %t130, ptr %t140, i64 0)
  store i64 %t144, ptr %l84
  br label %bb41
bb41:
  %t145 = load i64, ptr %l84, !tbaa !24
  %t146 = icmp sge i64 %t145, 0
  br i1 %t146, label %bb42, label %bb43
bb42:
  %t148 = load i64, ptr %l15, !tbaa !24
  %t151 = call i1 @compiler_2fscope_2eflHas(ptr %s0, ptr %l9, i64 %t148)
  store i1 %t151, ptr %l89
  br label %bb44
bb43:
  store i1 false, ptr %l86, !tbaa !21
  br label %bb45
bb44:
  %t152 = load i1, ptr %l89, !tbaa !21
  %t153 = xor i1 %t152, true
  store i1 %t153, ptr %l86, !tbaa !21
  br label %bb45
bb45:
  %t155 = load i1, ptr %l86, !tbaa !21
  br i1 %t155, label %bb46, label %bb47
bb46:
  %t156 = load i64, ptr %l15, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l9, i64 %t156)
  br label %bb48
bb47:
  br label %bb49
bb48:
  br label %bb49
bb49:
  br label %bb50
bb50:
  %t159 = load i64, ptr %l11, !tbaa !24
  %t162 = add i64 %t159, 1
  store i64 %t162, ptr %l11, !tbaa !24
  br label %bb16
bb51:
  %t164 = load i64, ptr %l8, !tbaa !24
  %t166 = icmp slt i64 %t164, 0
  br i1 %t166, label %bb52, label %bb53
bb52:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb53:
  br label %bb54
bb54:
  %t170 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l9)
  store i64 %t170, ptr %l100
  br label %bb55
bb55:
  %t171 = load i64, ptr %l100, !tbaa !24
  %t172 = icmp eq i64 %t171, 0
  br i1 %t172, label %bb56, label %bb57
bb56:
  %t174 = load ptr, ptr %l0, !tbaa !29
  %t175 = load i64, ptr %l1, !tbaa !24
  %t176 = load ptr, ptr %l2, !tbaa !29
  %t178 = getelementptr %"compiler/typed:Call", ptr %t176, i32 0, i32 1
  %t179 = load { i64, ptr }, ptr %t178, !tbaa !27
  store { i64, ptr } %t179, ptr %l105, !tbaa !27
  %t180 = load i64, ptr %l8, !tbaa !24
  %t182 = getelementptr { i64, ptr }, ptr %l105, i32 0, i32 1
  %t183 = load ptr, ptr %t182, !tbaa !27
  %t184 = getelementptr ptr, ptr %t183, i64 %t180
  %t185 = load ptr, ptr %t184, !tbaa !39
  %t187 = load i64, ptr %l3, !tbaa !24
  %t188 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t189 = load i64, ptr %l5, !tbaa !24
  %t191 = add i64 %t189, 1
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enoteMadeNamed(ptr %v0, ptr %v1, ptr %v2, ptr %t174, i64 %t175, ptr %t185, i64 %t187, { i64, ptr } %t188, i64 %t191)
  br label %bb58
bb57:
  br label %bb59
bb58:
  br label %bb59
bb59:
  store ptr %l9, ptr %l16, !tbaa !29
  store i64 0, ptr %l17, !tbaa !24
  br label %bb60
bb60:
  %t199 = load i64, ptr %l17, !tbaa !24
  store i64 %t199, ptr %l114, !tbaa !24
  %t200 = load ptr, ptr %l16, !tbaa !29
  %t202 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t200)
  store i64 %t202, ptr %l116
  br label %bb61
bb61:
  %t203 = load i64, ptr %l114, !tbaa !24
  %t204 = load i64, ptr %l116, !tbaa !24
  %t205 = icmp slt i64 %t203, %t204
  %t207 = xor i1 %t205, true
  br i1 %t207, label %bb62, label %bb63
bb62:
  br label %bb68
bb63:
  br label %bb64
bb64:
  %t209 = load ptr, ptr %l16, !tbaa !29
  %t210 = load i64, ptr %l17, !tbaa !24
  %t213 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t209, i64 %t210)
  store i64 %t213, ptr %l121
  br label %bb65
bb65:
  %t214 = load i64, ptr %l121, !tbaa !24
  %t215 = load ptr, ptr %l0, !tbaa !29
  %t216 = load i64, ptr %l1, !tbaa !24
  %t217 = load ptr, ptr %l2, !tbaa !29
  %t219 = getelementptr %"compiler/typed:Call", ptr %t217, i32 0, i32 1
  %t220 = load { i64, ptr }, ptr %t219, !tbaa !27
  store { i64, ptr } %t220, ptr %l125, !tbaa !27
  %t223 = getelementptr { i64, ptr }, ptr %l125, i32 0, i32 1
  %t224 = load ptr, ptr %t223, !tbaa !27
  %t225 = getelementptr ptr, ptr %t224, i64 %t214
  %t226 = load ptr, ptr %t225, !tbaa !39
  %t228 = load i64, ptr %l3, !tbaa !24
  %t229 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t230 = load i64, ptr %l5, !tbaa !24
  %t232 = add i64 %t230, 1
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enoteMadeNamed(ptr %v0, ptr %v1, ptr %v2, ptr %t215, i64 %t216, ptr %t226, i64 %t228, { i64, ptr } %t229, i64 %t232)
  br label %bb66
bb66:
  br label %bb67
bb67:
  %t239 = load i64, ptr %l17, !tbaa !24
  %t242 = add i64 %t239, 1
  store i64 %t242, ptr %l17, !tbaa !24
  br label %bb60
bb68:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epartCallOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca i1
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l18 = alloca i1
  %l26 = alloca ptr
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store ptr null, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l1, !tbaa !29
  store ptr %t6, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t7 = load ptr, ptr %l8, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb4, label %bb5
bb4:
  %t10 = load ptr, ptr %l8, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 18}
  %t13 = icmp eq i64 %t11, 2
  store i1 %t13, ptr %l9, !tbaa !21
  br label %bb5
bb5:
  %t14 = load i1, ptr %l9, !tbaa !21
  br i1 %t14, label %bb6, label %bb7
bb6:
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t17 = getelementptr { i64, [5 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t17, i32 0, i32 2
  %t19 = load ptr, ptr %t18
  store ptr %t19, ptr %l2, !tbaa !29
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load ptr, ptr %l2, !tbaa !29
  %t25 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eplaceCallOf(ptr %v0, ptr %v1, ptr %v2, ptr %t21, ptr %t22)
  store ptr %t25, ptr %l16
  br label %bb9
bb9:
  %t26 = load ptr, ptr %l16, !tbaa !29
  store ptr %t26, ptr %l7, !tbaa !29
  br label %bb22
bb10:
  %t27 = load ptr, ptr %l1, !tbaa !29
  store ptr %t27, ptr %l17, !tbaa !29
  store i1 false, ptr %l18, !tbaa !21
  %t28 = load ptr, ptr %l17, !tbaa !29
  %t29 = icmp ne ptr %t28, null
  br i1 %t29, label %bb11, label %bb12
bb11:
  %t31 = load ptr, ptr %l17, !tbaa !29
  %t32 = load i64, ptr %t31, !range !{i64 0, i64 18}
  %t34 = icmp eq i64 %t32, 17
  store i1 %t34, ptr %l18, !tbaa !21
  br label %bb12
bb12:
  %t35 = load i1, ptr %l18, !tbaa !21
  br i1 %t35, label %bb13, label %bb14
bb13:
  %t36 = load ptr, ptr %l1, !tbaa !29
  %t38 = getelementptr { i64, [5 x i64] }, ptr %t36, i32 0, i32 1
  %t39 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t38, i32 0, i32 2
  %t40 = load ptr, ptr %t39
  store ptr %t40, ptr %l3, !tbaa !29
  br label %bb15
bb14:
  br label %bb17
bb15:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t43 = load ptr, ptr %l3, !tbaa !29
  %t47 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epartCallOf(ptr %v0, ptr %v1, ptr %v2, ptr %t42, ptr %t43)
  store ptr %t47, ptr %l26
  br label %bb16
bb16:
  %t48 = load ptr, ptr %l26, !tbaa !29
  store ptr %t48, ptr %l7, !tbaa !29
  br label %bb22
bb17:
  br i1 true, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb21
bb20:
  store ptr null, ptr %l7, !tbaa !29
  br label %bb22
bb21:
  call void @__olang_check_failed(ptr @olang_loc_4a416fba8e98e106_47db22c0e1b8e2f2)
  unreachable
bb22:
  %t49 = load ptr, ptr %l7, !tbaa !29
  store ptr %t49, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eplaceCallOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i1
  %l15 = alloca ptr
  %l16 = alloca ptr
  %l17 = alloca i1
  %l25 = alloca ptr
  %l26 = alloca ptr
  %l27 = alloca i1
  %l35 = alloca ptr
  %l36 = alloca ptr
  %l37 = alloca i1
  %l45 = alloca i1
  %l46 = alloca ptr
  %l49 = alloca ptr
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l7, !tbaa !29
  store i1 false, ptr %l8, !tbaa !21
  %t2 = load ptr, ptr %l7, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l7, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 3
  store i1 %t8, ptr %l8, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l8, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load ptr, ptr %l2, !tbaa !29
  %t20 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eplaceCallOf(ptr %v0, ptr %v1, ptr %v2, ptr %t16, ptr %t17)
  store ptr %t20, ptr %l15
  br label %bb6
bb6:
  %t21 = load ptr, ptr %l15, !tbaa !29
  store ptr %t21, ptr %l6, !tbaa !29
  br label %bb37
bb7:
  %t22 = load ptr, ptr %l1, !tbaa !29
  store ptr %t22, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t23 = load ptr, ptr %l16, !tbaa !29
  %t24 = icmp ne ptr %t23, null
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t26 = load ptr, ptr %l16, !tbaa !29
  %t27 = load i64, ptr %t26, !range !{i64 0, i64 8}
  %t29 = icmp eq i64 %t27, 4
  store i1 %t29, ptr %l17, !tbaa !21
  br label %bb9
bb9:
  %t30 = load i1, ptr %l17, !tbaa !21
  br i1 %t30, label %bb10, label %bb11
bb10:
  %t31 = load ptr, ptr %l1, !tbaa !29
  %t33 = getelementptr { i64, [4 x i64] }, ptr %t31, i32 0, i32 1
  %t34 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t33, i32 0, i32 2
  %t35 = load ptr, ptr %t34
  store ptr %t35, ptr %l3, !tbaa !29
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load ptr, ptr %l3, !tbaa !29
  %t40 = getelementptr %"compiler/typed:Elem", ptr %t38, i32 0, i32 0
  %t41 = load ptr, ptr %t40, !tbaa !29
  %t44 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eplaceCallOf(ptr %v0, ptr %v1, ptr %v2, ptr %t37, ptr %t41)
  store ptr %t44, ptr %l25
  br label %bb13
bb13:
  %t45 = load ptr, ptr %l25, !tbaa !29
  store ptr %t45, ptr %l6, !tbaa !29
  br label %bb37
bb14:
  %t46 = load ptr, ptr %l1, !tbaa !29
  store ptr %t46, ptr %l26, !tbaa !29
  store i1 false, ptr %l27, !tbaa !21
  %t47 = load ptr, ptr %l26, !tbaa !29
  %t48 = icmp ne ptr %t47, null
  br i1 %t48, label %bb15, label %bb16
bb15:
  %t50 = load ptr, ptr %l26, !tbaa !29
  %t51 = load i64, ptr %t50, !range !{i64 0, i64 8}
  %t53 = icmp eq i64 %t51, 5
  store i1 %t53, ptr %l27, !tbaa !21
  br label %bb16
bb16:
  %t54 = load i1, ptr %l27, !tbaa !21
  br i1 %t54, label %bb17, label %bb18
bb17:
  %t55 = load ptr, ptr %l1, !tbaa !29
  %t57 = getelementptr { i64, [4 x i64] }, ptr %t55, i32 0, i32 1
  %t58 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t57, i32 0, i32 2
  %t59 = load ptr, ptr %t58
  store ptr %t59, ptr %l4, !tbaa !29
  br label %bb19
bb18:
  br label %bb21
bb19:
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t62 = load ptr, ptr %l4, !tbaa !29
  %t64 = getelementptr %"compiler/typed:Payload", ptr %t62, i32 0, i32 0
  %t65 = load ptr, ptr %t64, !tbaa !29
  %t68 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eplaceCallOf(ptr %v0, ptr %v1, ptr %v2, ptr %t61, ptr %t65)
  store ptr %t68, ptr %l35
  br label %bb20
bb20:
  %t69 = load ptr, ptr %l35, !tbaa !29
  store ptr %t69, ptr %l6, !tbaa !29
  br label %bb37
bb21:
  %t70 = load ptr, ptr %l1, !tbaa !29
  store ptr %t70, ptr %l36, !tbaa !29
  store i1 false, ptr %l37, !tbaa !21
  %t71 = load ptr, ptr %l36, !tbaa !29
  %t72 = icmp ne ptr %t71, null
  br i1 %t72, label %bb22, label %bb23
bb22:
  %t74 = load ptr, ptr %l36, !tbaa !29
  %t75 = load i64, ptr %t74, !range !{i64 0, i64 8}
  %t77 = icmp eq i64 %t75, 6
  store i1 %t77, ptr %l37, !tbaa !21
  br label %bb23
bb23:
  %t78 = load i1, ptr %l37, !tbaa !21
  br i1 %t78, label %bb24, label %bb25
bb24:
  %t79 = load ptr, ptr %l1, !tbaa !29
  %t81 = getelementptr { i64, [4 x i64] }, ptr %t79, i32 0, i32 1
  %t82 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t81, i32 0, i32 2
  %t83 = load ptr, ptr %t82
  store ptr %t83, ptr %l5, !tbaa !29
  br label %bb26
bb25:
  br label %bb32
bb26:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t86 = load ptr, ptr %l5, !tbaa !29
  %t90 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisFresh(ptr %v0, ptr %v1, ptr %t85, ptr %t86)
  store i1 %t90, ptr %l45
  br label %bb27
bb27:
  %t91 = load i1, ptr %l45, !tbaa !21
  br i1 %t91, label %bb28, label %bb29
bb28:
  %t92 = load ptr, ptr %l5, !tbaa !29
  %t95 = call ptr @compiler_2ftyped_2eCall_2eOf(ptr %v1, ptr %v2, ptr %t92)
  store ptr %t95, ptr %l49
  br label %bb30
bb29:
  store ptr null, ptr %l46, !tbaa !29
  br label %bb31
bb30:
  %t96 = load ptr, ptr %l49, !tbaa !29
  store ptr %t96, ptr %l46, !tbaa !29
  br label %bb31
bb31:
  %t97 = load ptr, ptr %l46, !tbaa !29
  store ptr %t97, ptr %l6, !tbaa !29
  br label %bb37
bb32:
  br i1 true, label %bb33, label %bb34
bb33:
  br label %bb35
bb34:
  br label %bb36
bb35:
  store ptr null, ptr %l6, !tbaa !29
  br label %bb37
bb36:
  call void @__olang_check_failed(ptr @olang_loc_da1486de58138450_28784370eb22bac)
  unreachable
bb37:
  %t98 = load ptr, ptr %l6, !tbaa !29
  store ptr %t98, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eplainCopyOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca ptr
  %l7 = alloca i1
  %l9 = alloca ptr
  %l10 = alloca i1
  %l19 = alloca i1
  %l21 = alloca ptr
  %l22 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisRef(ptr %v0, ptr %t1, i32 %a2)
  store i1 %t5, ptr %l7
  br label %bb1
bb1:
  %t6 = load i1, ptr %l7, !tbaa !21
  br i1 %t6, label %bb2, label %bb3
bb2:
  store i1 false, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t8 = load ptr, ptr %l1, !tbaa !29
  store ptr %t8, ptr %l9, !tbaa !29
  store i1 false, ptr %l10, !tbaa !21
  %t9 = load ptr, ptr %l9, !tbaa !29
  %t10 = icmp ne ptr %t9, null
  br i1 %t10, label %bb5, label %bb6
bb5:
  %t12 = load ptr, ptr %l9, !tbaa !29
  %t13 = load i64, ptr %t12, !range !{i64 0, i64 18}
  %t15 = icmp eq i64 %t13, 2
  store i1 %t15, ptr %l10, !tbaa !21
  br label %bb6
bb6:
  %t16 = load i1, ptr %l10, !tbaa !21
  br i1 %t16, label %bb7, label %bb8
bb7:
  %t17 = load ptr, ptr %l1, !tbaa !29
  %t19 = getelementptr { i64, [5 x i64] }, ptr %t17, i32 0, i32 1
  %t20 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t19, i32 0, i32 1
  %t21 = load i32, ptr %t20
  store i32 %t21, ptr %l3, !tbaa !23
  %t23 = load ptr, ptr %l1, !tbaa !29
  %t25 = getelementptr { i64, [5 x i64] }, ptr %t23, i32 0, i32 1
  %t26 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t25, i32 0, i32 2
  %t27 = load ptr, ptr %t26
  store ptr %t27, ptr %l4, !tbaa !29
  br label %bb9
bb8:
  br label %bb25
bb9:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t30 = load i32, ptr %l3, !tbaa !23
  %t33 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisRef(ptr %v0, ptr %t29, i32 %t30)
  store i1 %t33, ptr %l19
  br label %bb10
bb10:
  %t34 = load i1, ptr %l19, !tbaa !21
  br i1 %t34, label %bb11, label %bb12
bb11:
  store i1 false, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  %t36 = load ptr, ptr %l4, !tbaa !29
  store ptr %t36, ptr %l21, !tbaa !29
  store i1 false, ptr %l22, !tbaa !21
  %t37 = load ptr, ptr %l21, !tbaa !29
  %t38 = icmp ne ptr %t37, null
  br i1 %t38, label %bb14, label %bb15
bb14:
  %t40 = load ptr, ptr %l21, !tbaa !29
  %t41 = load i64, ptr %t40, !range !{i64 0, i64 8}
  %t43 = icmp eq i64 %t41, 0
  store i1 %t43, ptr %l22, !tbaa !21
  br label %bb15
bb15:
  %t44 = load i1, ptr %l22, !tbaa !21
  br i1 %t44, label %bb16, label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb19
bb18:
  store i1 true, ptr %rv
  br label %ret
bb19:
  br i1 true, label %bb20, label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  call void @__olang_check_failed(ptr @olang_loc_b45386ce0764ddbe_c7946361eac41962)
  unreachable
bb24:
  br label %bb30
bb25:
  br i1 true, label %bb26, label %bb27
bb26:
  br label %bb28
bb27:
  br label %bb29
bb28:
  br label %bb30
bb29:
  call void @__olang_check_failed(ptr @olang_loc_535fab4b1fdbd0bf_63b8873d2454f763)
  unreachable
bb30:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epromoteDecl(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i1
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca { i64, [2 x i64] }
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca ptr
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l20 = alloca i64
  %l21 = alloca i64
  %lp22 = alloca ptr
  %l24 = alloca { i64, [1 x i64] }
  %l28 = alloca i64
  %l32 = alloca i64
  %l35 = alloca i64
  %l56 = alloca ptr
  %l59 = alloca i32
  %l68 = alloca i1
  %l71 = alloca ptr
  %l76 = alloca i32
  %l77 = alloca i32
  %l81 = alloca i1
  %l84 = alloca ptr
  %l89 = alloca i32
  %l90 = alloca i32
  %l97 = alloca ptr
  %l100 = alloca i64
  %l104 = alloca i64
  %l107 = alloca i64
  %l127 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l131 = alloca i32
  %l136 = alloca i1
  %l137 = alloca i1
  %l141 = alloca %"compiler/typed:Local"
  %l145 = alloca i1
  %l146 = alloca ptr
  %l150 = alloca %"compiler/typed:Local"
  %l152 = alloca i1
  %l157 = alloca i1
  %l161 = alloca i64
  %l164 = alloca i64
  %l168 = alloca ptr
  %l175 = alloca i32
  %l176 = alloca { i64, ptr }
  %l181 = alloca i1
  %l194 = alloca ptr
  %l200 = alloca i1
  %s7 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %rv = alloca i1
  %t353 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i1 false, ptr %l2, !tbaa !21
  store i64 0, ptr %l3, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 1
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l28
  br label %bb1
bb1:
  %t6 = load i64, ptr %l28, !tbaa !24
  store i64 %t6, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t7 = load i64, ptr %l4, !tbaa !24
  %t8 = load i64, ptr %l3, !tbaa !24
  %t11 = icmp sgt i64 %t7, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load i64, ptr %l5, !tbaa !24
  %t15 = icmp sgt i64 %t13, 0
  br i1 %t15, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l32, !tbaa !24
  br label %bb7
bb4:
  %t17 = load i64, ptr %l4, !tbaa !24
  %t18 = load i64, ptr %l3, !tbaa !24
  %t21 = sub i64 %t17, %t18
  %t22 = load i64, ptr %l5, !tbaa !24
  %t25 = add i64 %t21, %t22
  %t27 = sub i64 %t25, 1
  %t28 = load i64, ptr %l5, !tbaa !24
  %t31 = sdiv i64 %t27, %t28
  store i64 %t31, ptr %l35, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l35, !tbaa !24
  br label %bb6
bb6:
  %t33 = load i64, ptr %l35, !tbaa !24
  store i64 %t33, ptr %l32, !tbaa !24
  br label %bb7
bb7:
  %t34 = load i64, ptr %l32, !tbaa !24
  store i64 %t34, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb8
bb8:
  %t35 = load i64, ptr %l7, !tbaa !24
  %t36 = load i64, ptr %l6, !tbaa !24
  %t39 = icmp slt i64 %t35, %t36
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb9, label %bb10
bb9:
  br label %bb86
bb10:
  br label %bb11
bb11:
  %t43 = load i64, ptr %l3, !tbaa !24
  %t44 = load i64, ptr %l7, !tbaa !24
  %t45 = load i64, ptr %l5, !tbaa !24
  %t48 = mul i64 %t44, %t45
  %t51 = add i64 %t43, %t48
  store i64 %t51, ptr %l8, !tbaa !24
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/scope:Scoper", ptr %t53, i32 0, i32 1
  %t56 = load i64, ptr %l8, !tbaa !24
  %t59 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t55, i64 %t56)
  store ptr %t59, ptr %l56
  br label %bb12
bb12:
  %t60 = load ptr, ptr %l56, !tbaa !29
  %t62 = getelementptr %"compiler/typed:Body", ptr %t60, i32 0, i32 1
  %t63 = load { i64, [2 x i64] }, ptr %t62
  store { i64, [2 x i64] } %t63, ptr %l9
  %t65 = load { i64, [2 x i64] }, ptr %l9
  %t67 = extractvalue { i64, [2 x i64] } %t65, 0
  %t68 = icmp eq i64 %t67, 1
  br i1 %t68, label %bb13, label %bb14
bb13:
  %t70 = getelementptr { i64, [2 x i64] }, ptr %l9, i32 0, i32 1
  %t71 = getelementptr { i32, i32 }, ptr %t70, i32 0, i32 0
  %t72 = load i32, ptr %t71
  store i32 %t72, ptr %l10, !tbaa !23
  br label %bb15
bb14:
  br label %bb16
bb15:
  %t74 = load i32, ptr %l10, !tbaa !23
  store i32 %t74, ptr %l59, !tbaa !23
  br label %bb21
bb16:
  br i1 true, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  %t76 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t76, ptr %l59, !tbaa !23
  br label %bb21
bb20:
  call void @__olang_check_failed(ptr @olang_loc_9a4bec7adca8cb6_596724450ae2f102)
  unreachable
bb21:
  %t78 = load i32, ptr %l59, !tbaa !23
  store i32 %t78, ptr %l11, !tbaa !23
  %t79 = load i32, ptr %l11, !tbaa !23
  %t80 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t83 = icmp eq i32 %t79, %t80
  br i1 %t83, label %bb22, label %bb23
bb22:
  store i1 true, ptr %l68, !tbaa !21
  br label %bb26
bb23:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"compiler/scope:Scoper", ptr %t85, i32 0, i32 0
  %t88 = load ptr, ptr %t87, !tbaa !29
  %t90 = getelementptr %"compiler/generic:Program", ptr %t88, i32 0, i32 2
  store ptr %t90, ptr %l71, !tbaa !29
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t93 = getelementptr %"compiler/scope:Scoper", ptr %t91, i32 0, i32 0
  %t94 = load ptr, ptr %t93, !tbaa !29
  %t96 = getelementptr %"compiler/generic:Program", ptr %t94, i32 0, i32 2
  %t97 = load i32, ptr %l11, !tbaa !23
  %t100 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t96, i32 %t97)
  store i32 %t100, ptr %l76
  br label %bb24
bb24:
  %t101 = load ptr, ptr %l71, !tbaa !29
  %t102 = load i32, ptr %l76, !tbaa !23
  %t103 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t101, i32 %t102)
  store i32 %t103, ptr %l77
  br label %bb25
bb25:
  %t104 = load i32, ptr %l77, !tbaa !23
  %t105 = sext i32 %t104 to i64
  %t106 = load i64, ptr %l1, !tbaa !24
  %t109 = icmp ne i64 %t105, %t106
  store i1 %t109, ptr %l68, !tbaa !21
  br label %bb26
bb26:
  %t111 = load i1, ptr %l68, !tbaa !21
  br i1 %t111, label %bb27, label %bb28
bb27:
  store i1 true, ptr %l81, !tbaa !21
  br label %bb31
bb28:
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t114 = getelementptr %"compiler/scope:Scoper", ptr %t112, i32 0, i32 0
  %t115 = load ptr, ptr %t114, !tbaa !29
  %t117 = getelementptr %"compiler/generic:Program", ptr %t115, i32 0, i32 2
  store ptr %t117, ptr %l84, !tbaa !29
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t120 = getelementptr %"compiler/scope:Scoper", ptr %t118, i32 0, i32 0
  %t121 = load ptr, ptr %t120, !tbaa !29
  %t123 = getelementptr %"compiler/generic:Program", ptr %t121, i32 0, i32 2
  %t124 = load i32, ptr %l11, !tbaa !23
  %t127 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t123, i32 %t124)
  store i32 %t127, ptr %l89
  br label %bb29
bb29:
  %t128 = load ptr, ptr %l84, !tbaa !29
  %t129 = load i32, ptr %l89, !tbaa !23
  %t130 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t128, i32 %t129)
  store i32 %t130, ptr %l90
  br label %bb30
bb30:
  %t131 = load i32, ptr %l90, !range !{i32 0, i32 33}
  %t133 = trunc i64 18 to i32
  %t134 = icmp eq i32 %t131, %t133
  %t136 = xor i1 %t134, true
  store i1 %t136, ptr %l81, !tbaa !21
  br label %bb31
bb31:
  %t138 = load i1, ptr %l81, !tbaa !21
  br i1 %t138, label %bb32, label %bb33
bb32:
  br label %bb85
bb33:
  br label %bb34
bb34:
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t141 = getelementptr %"compiler/scope:Scoper", ptr %t139, i32 0, i32 1
  %t142 = load i64, ptr %l8, !tbaa !24
  %t145 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t141, i64 %t142)
  store ptr %t145, ptr %l97
  br label %bb35
bb35:
  %t146 = load ptr, ptr %l97, !tbaa !29
  store ptr %t146, ptr %l12, !tbaa !29
  store i64 0, ptr %l13, !tbaa !24
  %t147 = load ptr, ptr %l12, !tbaa !29
  %t149 = getelementptr %"compiler/typed:Body", ptr %t147, i32 0, i32 10
  %t151 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t149)
  store i64 %t151, ptr %l100
  br label %bb36
bb36:
  %t152 = load i64, ptr %l100, !tbaa !24
  store i64 %t152, ptr %l14, !tbaa !24
  store i64 1, ptr %l15, !tbaa !24
  %t153 = load i64, ptr %l14, !tbaa !24
  %t154 = load i64, ptr %l13, !tbaa !24
  %t157 = icmp sgt i64 %t153, %t154
  br i1 %t157, label %bb37, label %bb38
bb37:
  %t159 = load i64, ptr %l15, !tbaa !24
  %t161 = icmp sgt i64 %t159, 0
  br i1 %t161, label %bb39, label %bb40
bb38:
  store i64 0, ptr %l104, !tbaa !24
  br label %bb42
bb39:
  %t163 = load i64, ptr %l14, !tbaa !24
  %t164 = load i64, ptr %l13, !tbaa !24
  %t167 = sub i64 %t163, %t164
  %t168 = load i64, ptr %l15, !tbaa !24
  %t171 = add i64 %t167, %t168
  %t173 = sub i64 %t171, 1
  %t174 = load i64, ptr %l15, !tbaa !24
  %t177 = sdiv i64 %t173, %t174
  store i64 %t177, ptr %l107, !tbaa !24
  br label %bb41
bb40:
  store i64 0, ptr %l107, !tbaa !24
  br label %bb41
bb41:
  %t179 = load i64, ptr %l107, !tbaa !24
  store i64 %t179, ptr %l104, !tbaa !24
  br label %bb42
bb42:
  %t180 = load i64, ptr %l104, !tbaa !24
  store i64 %t180, ptr %l16, !tbaa !24
  store i64 0, ptr %l17, !tbaa !24
  br label %bb43
bb43:
  store %olang.scope zeroinitializer, ptr %s7
  %t181 = load i64, ptr %l17, !tbaa !24
  %t182 = load i64, ptr %l16, !tbaa !24
  %t185 = icmp slt i64 %t181, %t182
  %t187 = xor i1 %t185, true
  br i1 %t187, label %bb44, label %bb45
bb44:
  call void @__olang_scope_close(ptr %s7)
  br label %bb84
bb45:
  br label %bb46
bb46:
  %t189 = load i64, ptr %l13, !tbaa !24
  %t190 = load i64, ptr %l17, !tbaa !24
  %t191 = load i64, ptr %l15, !tbaa !24
  %t194 = mul i64 %t190, %t191
  %t197 = add i64 %t189, %t194
  store i64 %t197, ptr %l18, !tbaa !24
  %t199 = load i64, ptr %l1, !tbaa !24
  %t200 = load i64, ptr %l18, !tbaa !24
  %t203 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s7, i64 %t199, i64 %t200)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t203, ptr %l127
  br label %bb47
bb47:
  %t204 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l127
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t204, ptr %l19
  %t205 = load ptr, ptr %l12, !tbaa !29
  %t207 = getelementptr %"compiler/typed:Body", ptr %t205, i32 0, i32 10
  %t208 = load i64, ptr %l18, !tbaa !24
  %t211 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t207, i64 %t208)
  store i32 %t211, ptr %l131
  br label %bb48
bb48:
  %t212 = load i32, ptr %l131, !tbaa !23
  %t213 = sext i32 %t212 to i64
  store i64 %t213, ptr %l20, !tbaa !24
  %t215 = load ptr, ptr %l0, !tbaa !29
  %t217 = getelementptr %"compiler/scope:Scoper", ptr %t215, i32 0, i32 243
  %t218 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l19
  %t221 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %v0, ptr %t217, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t218)
  store i1 %t221, ptr %l136
  br label %bb49
bb49:
  %t222 = load i1, ptr %l136, !tbaa !21
  br i1 %t222, label %bb50, label %bb51
bb50:
  store i1 true, ptr %l137, !tbaa !21
  br label %bb53
bb51:
  %t223 = load ptr, ptr %l12, !tbaa !29
  %t225 = getelementptr %"compiler/typed:Body", ptr %t223, i32 0, i32 7
  %t226 = load i64, ptr %l20, !tbaa !24
  %t229 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t225, i64 %t226)
  store %"compiler/typed:Local" %t229, ptr %l141
  br label %bb52
bb52:
  %t230 = getelementptr %"compiler/typed:Local", ptr %l141, i32 0, i32 5
  %t231 = load { i64, [1 x i64] }, ptr %t230
  %t233 = extractvalue { i64, [1 x i64] } %t231, 0
  %t234 = icmp eq i64 %t233, 1
  %t236 = xor i1 %t234, true
  store i1 %t236, ptr %l137, !tbaa !21
  br label %bb53
bb53:
  %t238 = load i1, ptr %l137, !tbaa !21
  br i1 %t238, label %bb54, label %bb55
bb54:
  store i1 true, ptr %l145, !tbaa !21
  br label %bb58
bb55:
  %t239 = load ptr, ptr %l0, !tbaa !29
  store ptr %t239, ptr %l146, !tbaa !29
  %t240 = load ptr, ptr %l12, !tbaa !29
  %t242 = getelementptr %"compiler/typed:Body", ptr %t240, i32 0, i32 7
  %t243 = load i64, ptr %l20, !tbaa !24
  %t246 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t242, i64 %t243)
  store %"compiler/typed:Local" %t246, ptr %l150
  br label %bb56
bb56:
  %t247 = getelementptr %"compiler/typed:Local", ptr %l150, i32 0, i32 2
  %t248 = load i32, ptr %t247, !tbaa !23
  %t249 = load ptr, ptr %l146, !tbaa !29
  %t251 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisRef(ptr %v0, ptr %t249, i32 %t248)
  store i1 %t251, ptr %l152
  br label %bb57
bb57:
  %t252 = load i1, ptr %l152, !tbaa !21
  %t253 = xor i1 %t252, true
  store i1 %t253, ptr %l145, !tbaa !21
  br label %bb58
bb58:
  %t255 = load i1, ptr %l145, !tbaa !21
  br i1 %t255, label %bb59, label %bb60
bb59:
  call void @__olang_scope_close(ptr %s7)
  br label %bb83
bb60:
  br label %bb61
bb61:
  %t256 = load ptr, ptr %l0, !tbaa !29
  %t257 = load ptr, ptr %l12, !tbaa !29
  %t258 = load i64, ptr %l20, !tbaa !24
  %t262 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebuiltField(ptr %v0, ptr %v0, ptr %t256, ptr %t257, i64 %t258)
  store i1 %t262, ptr %l157
  br label %bb62
bb62:
  %t263 = load i1, ptr %l157, !tbaa !21
  br i1 %t263, label %bb63, label %bb64
bb63:
  call void @__olang_scope_close(ptr %s7)
  br label %bb83
bb64:
  br label %bb65
bb65:
  %t264 = load ptr, ptr %l0, !tbaa !29
  %t265 = load ptr, ptr %l12, !tbaa !29
  %t266 = load i64, ptr %l20, !tbaa !24
  %t270 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebindingParam(ptr %v0, ptr %v0, ptr %t264, ptr %t265, i64 %t266)
  store i64 %t270, ptr %l161
  br label %bb66
bb66:
  %t271 = load i64, ptr %l161, !tbaa !24
  store i64 %t271, ptr %l21, !tbaa !24
  %t272 = load i64, ptr %l21, !tbaa !24
  %t274 = icmp slt i64 %t272, 0
  br i1 %t274, label %bb67, label %bb68
bb67:
  store %olang.scope zeroinitializer, ptr %s10
  %t276 = load i64, ptr %l18, !tbaa !24
  store i64 %t276, ptr %l164, !tbaa !24
  %t277 = load ptr, ptr %l0, !tbaa !29
  %t279 = getelementptr %"compiler/scope:Scoper", ptr %t277, i32 0, i32 0
  %t280 = load ptr, ptr %t279, !tbaa !29
  %t282 = getelementptr %"compiler/generic:Program", ptr %t280, i32 0, i32 0
  %t283 = load ptr, ptr %t282, !tbaa !29
  %t285 = getelementptr %"compiler/load:Loader", ptr %t283, i32 0, i32 3
  %t286 = load ptr, ptr %t285, !tbaa !29
  store ptr %t286, ptr %l168, !tbaa !29
  %t287 = load ptr, ptr %l0, !tbaa !29
  %t289 = getelementptr %"compiler/scope:Scoper", ptr %t287, i32 0, i32 0
  %t290 = load ptr, ptr %t289, !tbaa !29
  %t292 = getelementptr %"compiler/generic:Program", ptr %t290, i32 0, i32 2
  %t293 = load i64, ptr %l1, !tbaa !24
  %t295 = trunc i64 %t293 to i32
  %t299 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %t292, i32 %t295)
  store i32 %t299, ptr %l175
  br label %bb69
bb68:
  br label %bb76
bb69:
  %t300 = load ptr, ptr %l168, !tbaa !29
  %t301 = load i32, ptr %l175, !tbaa !23
  %t302 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %s10, ptr %t300, i32 %t301)
  store { i64, ptr } %t302, ptr %l176
  br label %bb70
bb70:
  %t303 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d54, i32 0, i32 1) }, 1
  %t304 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d54, i32 0, i32 1) }, 0
  %t305 = load i64, ptr %l164, !tbaa !24
  %t306 = call i64 @__olang_fmt_i64(ptr null, i64 %t305)
  %t307 = add i64 %t304, %t306
  %t308 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d55, i32 0, i32 1) }, 1
  %t309 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d55, i32 0, i32 1) }, 0
  %t310 = add i64 %t307, %t309
  %t311 = load { i64, ptr }, ptr %l176, !tbaa !27
  %t312 = extractvalue { i64, ptr } %t311, 1
  %t313 = extractvalue { i64, ptr } %t311, 0
  %t314 = add i64 %t310, %t313
  %t315 = extractvalue { i64, ptr } { i64 37, ptr getelementptr inbounds (<{ i64, [37 x i8] }>, ptr @.d56, i32 0, i32 1) }, 1
  %t316 = extractvalue { i64, ptr } { i64 37, ptr getelementptr inbounds (<{ i64, [37 x i8] }>, ptr @.d56, i32 0, i32 1) }, 0
  %t317 = add i64 %t314, %t316
  %t318 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t317)
  call void @olang_textcopy(ptr %t318, ptr %t303, i64 %t304)
  %t319 = getelementptr i8, ptr %t318, i64 %t304
  %t320 = call i64 @__olang_fmt_i64(ptr %t319, i64 %t305)
  %t321 = getelementptr i8, ptr %t319, i64 %t306
  call void @olang_textcopy(ptr %t321, ptr %t308, i64 %t309)
  %t322 = getelementptr i8, ptr %t321, i64 %t309
  call void @olang_textcopy(ptr %t322, ptr %t312, i64 %t313)
  %t323 = getelementptr i8, ptr %t322, i64 %t313
  call void @olang_textcopy(ptr %t323, ptr %t315, i64 %t316)
  %t324 = insertvalue { i64, ptr } undef, i64 %t317, 0
  %t325 = insertvalue { i64, ptr } %t324, ptr %t318, 1
  %t326 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 16, i64 8)
  store ptr %t326, ptr %lp22
  %t328 = load ptr, ptr %lp22
  store { i64, ptr } %t325, ptr %t328, !tbaa !27
  %t329 = load ptr, ptr %l0, !tbaa !29
  %t331 = getelementptr %"compiler/scope:Scoper", ptr %t329, i32 0, i32 244
  %t332 = load ptr, ptr %lp22
  %t333 = load { i64, ptr }, ptr %t332, !tbaa !27
  %t336 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H0127831368543eff3b7740d7d3240080(ptr %v0, ptr %v0, ptr %t331, { i64, ptr } %t333)
  store i1 %t336, ptr %l181
  br label %bb71
bb71:
  %t337 = load i1, ptr %l181, !tbaa !21
  %t338 = xor i1 %t337, true
  br i1 %t338, label %bb72, label %bb73
bb72:
  %t340 = load ptr, ptr %l0, !tbaa !29
  %t342 = getelementptr %"compiler/scope:Scoper", ptr %t340, i32 0, i32 244
  %t343 = load ptr, ptr %lp22
  %t344 = load { i64, ptr }, ptr %t343, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v0, ptr %t342, { i64, ptr } %t344)
  br label %bb74
bb73:
  br label %bb75
bb74:
  br label %bb75
bb75:
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s7)
  br label %bb83
bb76:
  %t347 = load i64, ptr %l20, !tbaa !24
  %t349 = load i64, ptr %l21, !tbaa !24
  %t351 = trunc i64 %t349 to i32
  store { i64, [1 x i64] } zeroinitializer, ptr %t353
  %t354 = getelementptr { i64, [1 x i64] }, ptr %t353, i32 0, i32 0
  store i64 2, ptr %t354
  %t356 = insertvalue { i32 } undef, i32 %t351, 0
  %t357 = getelementptr { i64, [1 x i64] }, ptr %t353, i32 0, i32 1
  store { i32 } %t356, ptr %t357
  %t358 = load { i64, [1 x i64] }, ptr %t353
  store { i64, [1 x i64] } %t358, ptr %l24
  %t360 = load ptr, ptr %l12, !tbaa !29
  %t362 = getelementptr %"compiler/typed:Body", ptr %t360, i32 0, i32 7
  %t366 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eRefMut_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %v0, ptr %t362, i64 %t347)
  store ptr %t366, ptr %l194
  br label %bb77
bb77:
  %t367 = load ptr, ptr %l194, !tbaa !29
  %t369 = load { i64, [1 x i64] }, ptr %l24
  %t372 = getelementptr %"compiler/typed:Local", ptr %t367, i32 0, i32 5
  store { i64, [1 x i64] } %t369, ptr %t372
  %t373 = load ptr, ptr %l0, !tbaa !29
  %t375 = getelementptr %"compiler/scope:Scoper", ptr %t373, i32 0, i32 242
  %t376 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l19
  %t379 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H874ab6ecb906549bc54547c0392d06e9(ptr %v0, ptr %t375, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t376)
  store i1 %t379, ptr %l200
  br label %bb78
bb78:
  %t380 = load i1, ptr %l200, !tbaa !21
  %t381 = xor i1 %t380, true
  br i1 %t381, label %bb79, label %bb80
bb79:
  store i1 true, ptr %l2, !tbaa !21
  br label %bb81
bb80:
  br label %bb81
bb81:
  %t383 = load ptr, ptr %l0, !tbaa !29
  %t385 = getelementptr %"compiler/scope:Scoper", ptr %t383, i32 0, i32 242
  %t386 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l19
  %t387 = load i64, ptr %l21, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H31314c4e7281f5029d6d8eb3044cef10(ptr %v0, ptr %t385, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t386, i64 %t387)
  br label %bb82
bb82:
  call void @__olang_scope_close(ptr %s7)
  br label %bb83
bb83:
  %t391 = load i64, ptr %l17, !tbaa !24
  %t394 = add i64 %t391, 1
  store i64 %t394, ptr %l17, !tbaa !24
  br label %bb43
bb84:
  br label %bb85
bb85:
  %t396 = load i64, ptr %l7, !tbaa !24
  %t399 = add i64 %t396, 1
  store i64 %t399, ptr %l7, !tbaa !24
  br label %bb8
bb86:
  %t401 = load i1, ptr %l2, !tbaa !21
  store i1 %t401, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2equalifiesMove(ptr %v0, ptr %v1, ptr %a0, %"compiler/typed:Local" %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/typed:Local"
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca { i64, [1 x i64] }
  %l5 = alloca { i64, [1 x i64] }
  %l6 = alloca i32
  %l10 = alloca i1
  %l14 = alloca i1
  %l24 = alloca i1
  %l25 = alloca i1
  %l28 = alloca i1
  %l29 = alloca i1
  %l32 = alloca i1
  %l33 = alloca i1
  %l36 = alloca i1
  %l46 = alloca i1
  %l48 = alloca i1
  %l50 = alloca i1
  %l55 = alloca i1
  %l61 = alloca i32
  %l64 = alloca i1
  %l67 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store %"compiler/typed:Local" %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/typed:Local", ptr %l1, i32 0, i32 2
  %t2 = load i32, ptr %t1, !tbaa !23
  store i32 %t2, ptr %l3, !tbaa !23
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t5 = load i32, ptr %l3, !tbaa !23
  %t8 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisFunc(ptr %v0, ptr %t4, i32 %t5)
  store i1 %t8, ptr %l10
  br label %bb1
bb1:
  %t9 = load i1, ptr %l10, !tbaa !21
  br i1 %t9, label %bb2, label %bb3
bb2:
  store i1 false, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load i32, ptr %l3, !tbaa !23
  %t15 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisRef(ptr %v0, ptr %t11, i32 %t12)
  store i1 %t15, ptr %l14
  br label %bb5
bb5:
  %t16 = load i1, ptr %l14, !tbaa !21
  br i1 %t16, label %bb6, label %bb7
bb6:
  %t17 = getelementptr %"compiler/typed:Local", ptr %l1, i32 0, i32 5
  %t18 = load { i64, [1 x i64] }, ptr %t17
  store { i64, [1 x i64] } %t18, ptr %l4
  %t20 = load { i64, [1 x i64] }, ptr %l4
  %t22 = extractvalue { i64, [1 x i64] } %t20, 0
  %t23 = icmp eq i64 %t22, 1
  br i1 %t23, label %bb8, label %bb9
bb7:
  br label %bb32
bb8:
  br label %bb12
bb9:
  %t25 = load { i64, [1 x i64] }, ptr %l4
  %t27 = extractvalue { i64, [1 x i64] } %t25, 0
  %t28 = icmp eq i64 %t27, 4
  br i1 %t28, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb18
bb13:
  br i1 true, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb17
bb16:
  store i1 false, ptr %rv
  br label %ret
bb17:
  call void @__olang_check_failed(ptr @olang_loc_554265ba1528b3d8_d73d8ae267adc184)
  unreachable
bb18:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load ptr, ptr %l2, !tbaa !29
  %t36 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisFresh(ptr %v0, ptr %v1, ptr %t31, ptr %t32)
  store i1 %t36, ptr %l24
  br label %bb19
bb19:
  %t37 = load i1, ptr %l24, !tbaa !21
  br i1 %t37, label %bb20, label %bb21
bb20:
  store i1 true, ptr %l25, !tbaa !21
  br label %bb23
bb21:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t39 = load ptr, ptr %l2, !tbaa !29
  %t42 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisNullLit(ptr %v0, ptr %v1, ptr %t38, ptr %t39)
  store i1 %t42, ptr %l28
  br label %bb22
bb22:
  %t43 = load i1, ptr %l28, !tbaa !21
  store i1 %t43, ptr %l25, !tbaa !21
  br label %bb23
bb23:
  %t44 = load i1, ptr %l25, !tbaa !21
  br i1 %t44, label %bb24, label %bb25
bb24:
  store i1 true, ptr %l29, !tbaa !21
  br label %bb27
bb25:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t46 = load ptr, ptr %l2, !tbaa !29
  %t49 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisData(ptr %v0, ptr %v1, ptr %t45, ptr %t46)
  store i1 %t49, ptr %l32
  br label %bb26
bb26:
  %t50 = load i1, ptr %l32, !tbaa !21
  store i1 %t50, ptr %l29, !tbaa !21
  br label %bb27
bb27:
  %t51 = load i1, ptr %l29, !tbaa !21
  br i1 %t51, label %bb28, label %bb29
bb28:
  store i1 true, ptr %l33, !tbaa !21
  br label %bb31
bb29:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = load ptr, ptr %l2, !tbaa !29
  %t56 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2estaticLiteral(ptr %v0, ptr %v1, ptr %t52, ptr %t53)
  store i1 %t56, ptr %l36
  br label %bb30
bb30:
  %t57 = load i1, ptr %l36, !tbaa !21
  store i1 %t57, ptr %l33, !tbaa !21
  br label %bb31
bb31:
  %t58 = load i1, ptr %l33, !tbaa !21
  store i1 %t58, ptr %rv
  br label %ret
bb32:
  %t59 = getelementptr %"compiler/typed:Local", ptr %l1, i32 0, i32 5
  %t60 = load { i64, [1 x i64] }, ptr %t59
  store { i64, [1 x i64] } %t60, ptr %l5
  %t62 = load { i64, [1 x i64] }, ptr %l5
  %t64 = extractvalue { i64, [1 x i64] } %t62, 0
  %t65 = icmp eq i64 %t64, 0
  br i1 %t65, label %bb33, label %bb34
bb33:
  br label %bb37
bb34:
  %t67 = load { i64, [1 x i64] }, ptr %l5
  %t69 = extractvalue { i64, [1 x i64] } %t67, 0
  %t70 = icmp eq i64 %t69, 4
  br i1 %t70, label %bb35, label %bb36
bb35:
  br label %bb37
bb36:
  br label %bb38
bb37:
  br label %bb43
bb38:
  br i1 true, label %bb39, label %bb40
bb39:
  br label %bb41
bb40:
  br label %bb42
bb41:
  store i1 false, ptr %rv
  br label %ret
bb42:
  call void @__olang_check_failed(ptr @olang_loc_c484f993348186a9_88a471068962d75)
  unreachable
bb43:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t74 = load ptr, ptr %l2, !tbaa !29
  %t78 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2emadeHere(ptr %v0, ptr %v1, ptr %t73, ptr %t74)
  store i1 %t78, ptr %l46
  br label %bb44
bb44:
  %t79 = load i1, ptr %l46, !tbaa !21
  %t80 = xor i1 %t79, true
  br i1 %t80, label %bb45, label %bb46
bb45:
  %t82 = load ptr, ptr %l2, !tbaa !29
  %t84 = call i1 @compiler_2fscope_2ecopiedRead(ptr %v1, ptr %t82)
  store i1 %t84, ptr %l50
  br label %bb47
bb46:
  store i1 false, ptr %l48, !tbaa !21
  br label %bb48
bb47:
  %t85 = load i1, ptr %l50, !tbaa !21
  %t86 = xor i1 %t85, true
  store i1 %t86, ptr %l48, !tbaa !21
  br label %bb48
bb48:
  %t88 = load i1, ptr %l48, !tbaa !21
  br i1 %t88, label %bb49, label %bb50
bb49:
  store i1 false, ptr %rv
  br label %ret
bb50:
  br label %bb51
bb51:
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t91 = load i32, ptr %l3, !tbaa !23
  %t94 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eholds(ptr %v0, ptr %t90, i32 %t91)
  store i1 %t94, ptr %l55
  br label %bb52
bb52:
  %t95 = load i1, ptr %l55, !tbaa !21
  br i1 %t95, label %bb53, label %bb54
bb53:
  store i1 true, ptr %rv
  br label %ret
bb54:
  br label %bb55
bb55:
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = getelementptr %"compiler/scope:Scoper", ptr %t97, i32 0, i32 0
  %t100 = load ptr, ptr %t99, !tbaa !29
  %t102 = getelementptr %"compiler/generic:Program", ptr %t100, i32 0, i32 2
  %t103 = load i32, ptr %l3, !tbaa !23
  %t106 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t102, i32 %t103)
  store i32 %t106, ptr %l61
  br label %bb56
bb56:
  %t107 = load i32, ptr %l61, !range !{i32 0, i32 33}
  store i32 %t107, ptr %l6
  %t108 = load i32, ptr %l6, !range !{i32 0, i32 33}
  %t110 = trunc i64 19 to i32
  %t111 = icmp eq i32 %t108, %t110
  br i1 %t111, label %bb57, label %bb58
bb57:
  store i1 true, ptr %l64, !tbaa !21
  br label %bb59
bb58:
  %t113 = load i32, ptr %l6, !range !{i32 0, i32 33}
  %t115 = trunc i64 18 to i32
  %t116 = icmp eq i32 %t113, %t115
  store i1 %t116, ptr %l64, !tbaa !21
  br label %bb59
bb59:
  %t118 = load i1, ptr %l64, !tbaa !21
  br i1 %t118, label %bb60, label %bb61
bb60:
  store i1 true, ptr %l67, !tbaa !21
  br label %bb62
bb61:
  %t119 = load i32, ptr %l6, !range !{i32 0, i32 33}
  %t121 = trunc i64 22 to i32
  %t122 = icmp eq i32 %t119, %t121
  store i1 %t122, ptr %l67, !tbaa !21
  br label %bb62
bb62:
  %t124 = load i1, ptr %l67, !tbaa !21
  store i1 %t124, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2erecBeta(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, %"compiler/scope:fnRec" %a1, { i64, ptr } %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/scope:fnRec"
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l31 = alloca i64
  %l34 = alloca i64
  %l43 = alloca i64
  %l46 = alloca i1
  %l56 = alloca { i64, ptr }
  %l61 = alloca { i64, ptr }
  %l68 = alloca i64
  %l69 = alloca { i64, [2 x i64] }
  %l78 = alloca i64
  %l81 = alloca i64
  %l100 = alloca { i64, ptr }
  %l111 = alloca i64
  %l114 = alloca i64
  %l132 = alloca { i64, ptr }
  %l138 = alloca i64
  %l140 = alloca i64
  %l142 = alloca i1
  %l145 = alloca { i64, [2 x i64] }
  %l149 = alloca { i64, ptr }
  %l151 = alloca i64
  %l154 = alloca { i64, [2 x i64] }
  %rv = alloca { i64, ptr }
  %t92 = alloca { i64, [2 x i64] }, align 8
  %t105 = alloca i64
  store ptr %a0, ptr %l0
  store %"compiler/scope:fnRec" %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  store i64 %t3, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  store i64 %t7, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t9 = load i64, ptr %l6, !tbaa !24
  %t10 = load i64, ptr %l5, !tbaa !24
  %t13 = icmp sgt i64 %t9, %t10
  br i1 %t13, label %bb1, label %bb2
bb1:
  %t15 = load i64, ptr %l7, !tbaa !24
  %t17 = icmp sgt i64 %t15, 0
  br i1 %t17, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l31, !tbaa !24
  br label %bb6
bb3:
  %t19 = load i64, ptr %l6, !tbaa !24
  %t20 = load i64, ptr %l5, !tbaa !24
  %t23 = sub i64 %t19, %t20
  %t24 = load i64, ptr %l7, !tbaa !24
  %t27 = add i64 %t23, %t24
  %t29 = sub i64 %t27, 1
  %t30 = load i64, ptr %l7, !tbaa !24
  %t33 = sdiv i64 %t29, %t30
  store i64 %t33, ptr %l34, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l34, !tbaa !24
  br label %bb5
bb5:
  %t35 = load i64, ptr %l34, !tbaa !24
  store i64 %t35, ptr %l31, !tbaa !24
  br label %bb6
bb6:
  %t36 = load i64, ptr %l31, !tbaa !24
  store i64 %t36, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  %t37 = load i64, ptr %l8, !tbaa !24
  %t38 = sub i64 %t37, 1
  store i64 %t38, ptr %l43, !tbaa !24
  %t39 = load i64, ptr %l8, !tbaa !24
  %t40 = icmp slt i64 %t39, 2147483648
  %t41 = load i64, ptr %l9, !tbaa !24
  %t42 = icmp sge i64 %t41, 0
  %t45 = and i1 %t40, %t42
  store i1 %t45, ptr %l46, !tbaa !21
  br label %bb7
bb7:
  %t46 = load i64, ptr %l9, !tbaa !24
  %t47 = load i64, ptr %l8, !tbaa !24
  %t50 = icmp slt i64 %t46, %t47
  %t52 = xor i1 %t50, true
  br i1 %t52, label %bb8, label %bb9
bb8:
  br label %bb15
bb9:
  br label %bb10
bb10:
  %t54 = load i64, ptr %l5, !tbaa !24
  %t55 = load i64, ptr %l9, !tbaa !24
  %t56 = load i64, ptr %l7, !tbaa !24
  %t59 = mul i64 %t55, %t56
  %t62 = add i64 %t54, %t59
  store i64 %t62, ptr %l10, !tbaa !24
  %t64 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t64, ptr %l56, !tbaa !27
  %t65 = load i64, ptr %l10, !tbaa !24
  %t67 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t68 = load ptr, ptr %t67, !tbaa !27
  %t69 = getelementptr i64, ptr %t68, i64 %t65
  %t70 = load i64, ptr %t69, !tbaa !34
  %t71 = load i64, ptr %l4, !tbaa !24
  %t74 = icmp sge i64 %t70, %t71
  br i1 %t74, label %bb11, label %bb12
bb11:
  %t76 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t76, ptr %l61, !tbaa !27
  %t77 = load i64, ptr %l10, !tbaa !24
  %t79 = getelementptr { i64, ptr }, ptr %l61, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !27
  %t81 = getelementptr i64, ptr %t80, i64 %t77
  %t82 = load i64, ptr %t81, !tbaa !34
  %t84 = add i64 %t82, 1
  store i64 %t84, ptr %l4, !tbaa !24
  br label %bb13
bb12:
  br label %bb13
bb13:
  br label %bb14
bb14:
  %t86 = load i64, ptr %l9, !tbaa !24
  %t89 = add i64 %t86, 1
  store i64 %t89, ptr %l9, !tbaa !24
  br label %bb7
bb15:
  %t91 = load i64, ptr %l4, !tbaa !24
  store i64 %t91, ptr %l68, !tbaa !24
  store { i64, [2 x i64] } zeroinitializer, ptr %t92
  %t93 = getelementptr { i64, [2 x i64] }, ptr %t92, i32 0, i32 0
  store i64 6, ptr %t93
  %t94 = load { i64, [2 x i64] }, ptr %t92
  store { i64, [2 x i64] } %t94, ptr %l69
  %t95 = load i64, ptr %l68, !tbaa !24
  %t96 = icmp sge i64 %t95, 0
  br i1 %t96, label %bb16, label %bb17
bb16:
  %t98 = load i64, ptr %l68, !tbaa !24
  %t99 = icmp sle i64 %t98, 384307168202282325
  br i1 %t99, label %bb18, label %bb19
bb17:
  call void @__olang_check_failed(ptr @olang_loc_7e21c4142f0bda85_cfc7aa0bb53bfe81)
  unreachable
bb18:
  %t101 = load i64, ptr %l68, !tbaa !24
  %t102 = mul i64 %t101, 24
  %t103 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t102)
  %t104 = load { i64, [2 x i64] }, ptr %l69
  store i64 0, ptr %t105
  br label %fill.106
fill.106:
  %t109 = load i64, ptr %t105
  %t110 = icmp slt i64 %t109, %t101
  br i1 %t110, label %fillb.107, label %filld.108
fillb.107:
  %t111 = getelementptr { i64, [2 x i64] }, ptr %t103, i64 %t109
  store { i64, [2 x i64] } %t104, ptr %t111
  %t112 = add i64 %t109, 1
  store i64 %t112, ptr %t105
  br label %fill.106
filld.108:
  %t113 = insertvalue { i64, ptr } undef, i64 %t101, 0
  %t114 = insertvalue { i64, ptr } %t113, ptr %t103, 1
  store { i64, ptr } %t114, ptr %l11, !tbaa !27
  store i64 0, ptr %l12, !tbaa !24
  %t116 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t118 = extractvalue { i64, ptr } %t116, 0
  store i64 %t118, ptr %l13, !tbaa !24
  store i64 1, ptr %l14, !tbaa !24
  %t120 = load i64, ptr %l13, !tbaa !24
  %t121 = load i64, ptr %l12, !tbaa !24
  %t124 = icmp sgt i64 %t120, %t121
  br i1 %t124, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @olang_loc_7e21c4142f0bda85_cfc7aa0bb53bfe81)
  unreachable
bb20:
  %t126 = load i64, ptr %l14, !tbaa !24
  %t128 = icmp sgt i64 %t126, 0
  br i1 %t128, label %bb22, label %bb23
bb21:
  store i64 0, ptr %l78, !tbaa !24
  br label %bb25
bb22:
  %t130 = load i64, ptr %l13, !tbaa !24
  %t131 = load i64, ptr %l12, !tbaa !24
  %t134 = sub i64 %t130, %t131
  %t135 = load i64, ptr %l14, !tbaa !24
  %t138 = add i64 %t134, %t135
  %t140 = sub i64 %t138, 1
  %t141 = load i64, ptr %l14, !tbaa !24
  %t144 = sdiv i64 %t140, %t141
  store i64 %t144, ptr %l81, !tbaa !24
  br label %bb24
bb23:
  store i64 0, ptr %l81, !tbaa !24
  br label %bb24
bb24:
  %t146 = load i64, ptr %l81, !tbaa !24
  store i64 %t146, ptr %l78, !tbaa !24
  br label %bb25
bb25:
  %t147 = load i64, ptr %l78, !tbaa !24
  store i64 %t147, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  br label %bb26
bb26:
  %t148 = load i64, ptr %l16, !tbaa !24
  %t149 = load i64, ptr %l15, !tbaa !24
  %t152 = icmp slt i64 %t148, %t149
  %t154 = xor i1 %t152, true
  br i1 %t154, label %bb27, label %bb28
bb27:
  br label %bb31
bb28:
  br label %bb29
bb29:
  %t156 = load i64, ptr %l12, !tbaa !24
  %t157 = load i64, ptr %l16, !tbaa !24
  %t158 = load i64, ptr %l14, !tbaa !24
  %t161 = mul i64 %t157, %t158
  %t164 = add i64 %t156, %t161
  store i64 %t164, ptr %l17, !tbaa !24
  %t166 = load i64, ptr %l17, !tbaa !24
  %t167 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t167, ptr %l100, !tbaa !27
  %t168 = load i64, ptr %l17, !tbaa !24
  %t170 = getelementptr { i64, ptr }, ptr %l100, i32 0, i32 1
  %t171 = load ptr, ptr %t170, !tbaa !27
  %t172 = getelementptr { i64, [2 x i64] }, ptr %t171, i64 %t168
  %t173 = load { i64, [2 x i64] }, ptr %t172
  %t176 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t177 = load ptr, ptr %t176, !tbaa !27
  %t178 = getelementptr { i64, [2 x i64] }, ptr %t177, i64 %t166
  store { i64, [2 x i64] } %t173, ptr %t178
  br label %bb30
bb30:
  %t179 = load i64, ptr %l16, !tbaa !24
  %t182 = add i64 %t179, 1
  store i64 %t182, ptr %l16, !tbaa !24
  br label %bb26
bb31:
  store i64 0, ptr %l18, !tbaa !24
  %t184 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t186 = extractvalue { i64, ptr } %t184, 0
  store i64 %t186, ptr %l19, !tbaa !24
  store i64 1, ptr %l20, !tbaa !24
  %t188 = load i64, ptr %l19, !tbaa !24
  %t189 = load i64, ptr %l18, !tbaa !24
  %t192 = icmp sgt i64 %t188, %t189
  br i1 %t192, label %bb32, label %bb33
bb32:
  %t194 = load i64, ptr %l20, !tbaa !24
  %t196 = icmp sgt i64 %t194, 0
  br i1 %t196, label %bb34, label %bb35
bb33:
  store i64 0, ptr %l111, !tbaa !24
  br label %bb37
bb34:
  %t198 = load i64, ptr %l19, !tbaa !24
  %t199 = load i64, ptr %l18, !tbaa !24
  %t202 = sub i64 %t198, %t199
  %t203 = load i64, ptr %l20, !tbaa !24
  %t206 = add i64 %t202, %t203
  %t208 = sub i64 %t206, 1
  %t209 = load i64, ptr %l20, !tbaa !24
  %t212 = sdiv i64 %t208, %t209
  store i64 %t212, ptr %l114, !tbaa !24
  br label %bb36
bb35:
  store i64 0, ptr %l114, !tbaa !24
  br label %bb36
bb36:
  %t214 = load i64, ptr %l114, !tbaa !24
  store i64 %t214, ptr %l111, !tbaa !24
  br label %bb37
bb37:
  %t215 = load i64, ptr %l111, !tbaa !24
  store i64 %t215, ptr %l21, !tbaa !24
  store i64 0, ptr %l22, !tbaa !24
  br label %bb38
bb38:
  %t216 = load i64, ptr %l22, !tbaa !24
  %t217 = load i64, ptr %l21, !tbaa !24
  %t220 = icmp slt i64 %t216, %t217
  %t222 = xor i1 %t220, true
  br i1 %t222, label %bb39, label %bb40
bb39:
  br label %bb55
bb40:
  br label %bb41
bb41:
  %t224 = load i64, ptr %l18, !tbaa !24
  %t225 = load i64, ptr %l22, !tbaa !24
  %t226 = load i64, ptr %l20, !tbaa !24
  %t229 = mul i64 %t225, %t226
  %t232 = add i64 %t224, %t229
  store i64 %t232, ptr %l23, !tbaa !24
  %t234 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t234, ptr %l132, !tbaa !27
  %t235 = load i64, ptr %l23, !tbaa !24
  %t237 = getelementptr { i64, ptr }, ptr %l132, i32 0, i32 1
  %t238 = load ptr, ptr %t237, !tbaa !27
  %t239 = getelementptr i64, ptr %t238, i64 %t235
  %t240 = load i64, ptr %t239, !tbaa !34
  %t241 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t243 = extractvalue { i64, ptr } %t241, 0
  %t246 = icmp slt i64 %t240, %t243
  br i1 %t246, label %bb42, label %bb43
bb42:
  br label %bb54
bb43:
  br label %bb44
bb44:
  %t248 = load i64, ptr %l23, !tbaa !24
  store i64 %t248, ptr %l138, !tbaa !24
  %t249 = getelementptr %"compiler/scope:fnRec", ptr %l1, i32 0, i32 1
  %t251 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eLen_3ccompiler_2fscope_3aTerm_3e(ptr %v1, ptr %t249)
  store i64 %t251, ptr %l140
  br label %bb45
bb45:
  %t252 = load i64, ptr %l138, !tbaa !24
  %t253 = load i64, ptr %l140, !tbaa !24
  %t254 = icmp slt i64 %t252, %t253
  br i1 %t254, label %bb46, label %bb47
bb46:
  %t256 = getelementptr %"compiler/scope:fnRec", ptr %l1, i32 0, i32 1
  %t257 = load i64, ptr %l23, !tbaa !24
  %t260 = call { i64, [2 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eAt_3ccompiler_2fscope_3aTerm_3e(ptr %v1, ptr %t256, i64 %t257)
  store { i64, [2 x i64] } %t260, ptr %l145
  br label %bb48
bb47:
  store i1 false, ptr %l142, !tbaa !21
  br label %bb49
bb48:
  %t261 = load { i64, [2 x i64] }, ptr %l145
  %t263 = extractvalue { i64, [2 x i64] } %t261, 0
  %t264 = icmp eq i64 %t263, 0
  %t266 = xor i1 %t264, true
  store i1 %t266, ptr %l142, !tbaa !21
  br label %bb49
bb49:
  %t268 = load i1, ptr %l142, !tbaa !21
  br i1 %t268, label %bb50, label %bb51
bb50:
  %t269 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t269, ptr %l149, !tbaa !27
  %t270 = load i64, ptr %l23, !tbaa !24
  %t272 = getelementptr { i64, ptr }, ptr %l149, i32 0, i32 1
  %t273 = load ptr, ptr %t272, !tbaa !27
  %t274 = getelementptr i64, ptr %t273, i64 %t270
  %t275 = load i64, ptr %t274, !tbaa !34
  store i64 %t275, ptr %l151, !tbaa !24
  %t276 = getelementptr %"compiler/scope:fnRec", ptr %l1, i32 0, i32 1
  %t277 = load i64, ptr %l23, !tbaa !24
  %t280 = call { i64, [2 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eAt_3ccompiler_2fscope_3aTerm_3e(ptr %v1, ptr %t276, i64 %t277)
  store { i64, [2 x i64] } %t280, ptr %l154
  br label %bb52
bb51:
  br label %bb53
bb52:
  %t281 = load { i64, [2 x i64] }, ptr %l154
  %t282 = load i64, ptr %l151, !tbaa !24
  %t283 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t284 = load ptr, ptr %t283, !tbaa !27
  %t285 = getelementptr { i64, [2 x i64] }, ptr %t284, i64 %t282
  store { i64, [2 x i64] } %t281, ptr %t285
  br label %bb53
bb53:
  br label %bb54
bb54:
  %t286 = load i64, ptr %l22, !tbaa !24
  %t289 = add i64 %t286, 1
  store i64 %t289, ptr %l22, !tbaa !24
  br label %bb38
bb55:
  %t291 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t291, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ereturnsArray(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca ptr
  %l11 = alloca i32
  %l14 = alloca i1
  %l15 = alloca ptr
  %l18 = alloca ptr
  %l26 = alloca i32
  %l27 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  store ptr %t6, ptr %l3, !tbaa !29
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/scope:Scoper", ptr %t7, i32 0, i32 28
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = icmp eq ptr %t10, null
  br i1 %t12, label %bb1, label %bb2
bb1:
  call void @__olang_check_failed(ptr @olang_loc_d170603cba6c1f57_8f6ba8e3d258e7eb)
  unreachable
bb2:
  br label %bb3
bb3:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/scope:Scoper", ptr %t14, i32 0, i32 28
  %t17 = load ptr, ptr %t16, !tbaa !29
  %t20 = getelementptr %"compiler/typed:Body", ptr %t17, i32 0, i32 2
  %t21 = load i32, ptr %t20, !tbaa !23
  %t22 = load ptr, ptr %l3, !tbaa !29
  %t24 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t22, i32 %t21)
  store i32 %t24, ptr %l11
  br label %bb4
bb4:
  %t25 = load i32, ptr %l11, !range !{i32 0, i32 33}
  %t27 = trunc i64 21 to i32
  %t28 = icmp eq i32 %t25, %t27
  br i1 %t28, label %bb5, label %bb6
bb5:
  %t30 = load ptr, ptr %l0, !tbaa !29
  store ptr %t30, ptr %l15, !tbaa !29
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/scope:Scoper", ptr %t31, i32 0, i32 0
  %t34 = load ptr, ptr %t33, !tbaa !29
  %t36 = getelementptr %"compiler/generic:Program", ptr %t34, i32 0, i32 2
  store ptr %t36, ptr %l18, !tbaa !29
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/scope:Scoper", ptr %t37, i32 0, i32 28
  %t40 = load ptr, ptr %t39, !tbaa !29
  %t42 = icmp eq ptr %t40, null
  br i1 %t42, label %bb7, label %bb8
bb6:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb12
bb7:
  call void @__olang_check_failed(ptr @olang_loc_d170603cba6c1f57_8f6ba8e3d258e7eb)
  unreachable
bb8:
  br label %bb9
bb9:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/scope:Scoper", ptr %t44, i32 0, i32 28
  %t47 = load ptr, ptr %t46, !tbaa !29
  %t50 = getelementptr %"compiler/typed:Body", ptr %t47, i32 0, i32 2
  %t51 = load i32, ptr %t50, !tbaa !23
  %t52 = load ptr, ptr %l18, !tbaa !29
  %t54 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t52, i32 %t51)
  store i32 %t54, ptr %l26
  br label %bb10
bb10:
  %t55 = load ptr, ptr %l15, !tbaa !29
  %t56 = load i32, ptr %l26, !tbaa !23
  %t57 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2earenaValue(ptr %v0, ptr %t55, i32 %t56)
  store i1 %t57, ptr %l27
  br label %bb11
bb11:
  %t58 = load i1, ptr %l27, !tbaa !21
  store i1 %t58, ptr %l14, !tbaa !21
  br label %bb12
bb12:
  %t59 = load i1, ptr %l14, !tbaa !21
  store i1 %t59, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2erunId(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca i64
  %l18 = alloca i1
  %l21 = alloca { i64, ptr }
  %l22 = alloca i64
  %l23 = alloca { i64, ptr }
  %l24 = alloca %"std/prelude/text:StringBuilder"
  %l25 = alloca ptr
  %l27 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l31 = alloca { i64, ptr }
  %l36 = alloca i64
  %l40 = alloca i64
  %l43 = alloca i64
  %l64 = alloca ptr
  %l65 = alloca ptr
  %l69 = alloca { i64, ptr }
  %l72 = alloca { i64, ptr }
  %l77 = alloca { i64, ptr }
  %l85 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l87 = alloca i64
  %l89 = alloca i64
  %l94 = alloca { i64, ptr }
  %l104 = alloca i64
  %l106 = alloca i64
  %l111 = alloca { i64, ptr }
  %l119 = alloca ptr
  %l121 = alloca { i64, ptr }
  %l123 = alloca { i64, ptr }
  %l124 = alloca { i64, ptr }
  %l127 = alloca { i64, ptr }
  %l128 = alloca i64
  %l129 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/scope:compRun", ptr %t1, i32 0, i32 20
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t4, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d57, i32 0, i32 1) })
  store i1 %t6, ptr %l18
  br label %bb1
bb1:
  %t7 = load i1, ptr %l18, !tbaa !21
  %t8 = xor i1 %t7, true
  br i1 %t8, label %bb2, label %bb3
bb2:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr %"compiler/scope:compRun", ptr %t10, i32 0, i32 20
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  store { i64, ptr } %t13, ptr %l21, !tbaa !27
  %t14 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t14, 0
  store i64 %t15, ptr %l22, !tbaa !24
  %t16 = load i64, ptr %l22, !tbaa !24
  %t17 = mul i64 %t16, 1
  %t18 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t17)
  %t19 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t18, 1
  store { i64, ptr } %t20, ptr %l23, !tbaa !27
  %t21 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !27
  %t25 = load i64, ptr %l22, !tbaa !24
  %t26 = mul i64 %t25, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t22, ptr %t24, i64 %t26, i1 false)
  %t27 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t27, ptr %l21, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t28 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t28, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t29 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t29, ptr %l24
  br label %bb5
bb5:
  %t30 = load %"std/prelude/text:StringBuilder", ptr %l24
  store %"std/prelude/text:StringBuilder" %t30, ptr %l2
  store ptr %l2, ptr %l25, !tbaa !29
  %t31 = load ptr, ptr %l1, !tbaa !29
  %t33 = getelementptr %"compiler/scope:compRun", ptr %t31, i32 0, i32 14
  %t34 = load { i64, ptr }, ptr %t33, !tbaa !27
  store { i64, ptr } %t34, ptr %l27, !tbaa !27
  %t35 = load ptr, ptr %l1, !tbaa !29
  %t37 = getelementptr %"compiler/scope:compRun", ptr %t35, i32 0, i32 15
  %t38 = load { i64, ptr }, ptr %t37, !tbaa !27
  store { i64, ptr } %t38, ptr %l29, !tbaa !27
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = call { i64, ptr } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eglobalText(ptr %v0, ptr %s0, ptr %t39)
  store { i64, ptr } %t41, ptr %l31
  br label %bb6
bb6:
  %t42 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t42, 1
  %t44 = extractvalue { i64, ptr } %t42, 0
  %t45 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d58, i32 0, i32 1) }, 1
  %t46 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d58, i32 0, i32 1) }, 0
  %t47 = add i64 %t44, %t46
  %t48 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t49 = extractvalue { i64, ptr } %t48, 1
  %t50 = extractvalue { i64, ptr } %t48, 0
  %t51 = add i64 %t47, %t50
  %t52 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d58, i32 0, i32 1) }, 1
  %t53 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d58, i32 0, i32 1) }, 0
  %t54 = add i64 %t51, %t53
  %t55 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t56 = extractvalue { i64, ptr } %t55, 1
  %t57 = extractvalue { i64, ptr } %t55, 0
  %t58 = add i64 %t54, %t57
  %t59 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d58, i32 0, i32 1) }, 1
  %t60 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d58, i32 0, i32 1) }, 0
  %t61 = add i64 %t58, %t60
  %t62 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t61)
  call void @olang_textcopy(ptr %t62, ptr %t43, i64 %t44)
  %t63 = getelementptr i8, ptr %t62, i64 %t44
  call void @olang_textcopy(ptr %t63, ptr %t45, i64 %t46)
  %t64 = getelementptr i8, ptr %t63, i64 %t46
  call void @olang_textcopy(ptr %t64, ptr %t49, i64 %t50)
  %t65 = getelementptr i8, ptr %t64, i64 %t50
  call void @olang_textcopy(ptr %t65, ptr %t52, i64 %t53)
  %t66 = getelementptr i8, ptr %t65, i64 %t53
  call void @olang_textcopy(ptr %t66, ptr %t56, i64 %t57)
  %t67 = getelementptr i8, ptr %t66, i64 %t57
  call void @olang_textcopy(ptr %t67, ptr %t59, i64 %t60)
  %t68 = insertvalue { i64, ptr } undef, i64 %t61, 0
  %t69 = insertvalue { i64, ptr } %t68, ptr %t62, 1
  %t71 = load ptr, ptr %l25, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t71, { i64, ptr } %t69)
  br label %bb7
bb7:
  store i64 0, ptr %l3, !tbaa !24
  %t73 = load ptr, ptr %l1, !tbaa !29
  %t75 = getelementptr %"compiler/scope:compRun", ptr %t73, i32 0, i32 16
  %t77 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fscope_3acompRun_3f_26_H546292b08567e2b050e63bf3793178cc(ptr %v1, ptr %t75)
  store i64 %t77, ptr %l36
  br label %bb8
bb8:
  %t78 = load i64, ptr %l36, !tbaa !24
  store i64 %t78, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t79 = load i64, ptr %l4, !tbaa !24
  %t80 = load i64, ptr %l3, !tbaa !24
  %t83 = icmp sgt i64 %t79, %t80
  br i1 %t83, label %bb9, label %bb10
bb9:
  %t85 = load i64, ptr %l5, !tbaa !24
  %t87 = icmp sgt i64 %t85, 0
  br i1 %t87, label %bb11, label %bb12
bb10:
  store i64 0, ptr %l40, !tbaa !24
  br label %bb14
bb11:
  %t89 = load i64, ptr %l4, !tbaa !24
  %t90 = load i64, ptr %l3, !tbaa !24
  %t93 = sub i64 %t89, %t90
  %t94 = load i64, ptr %l5, !tbaa !24
  %t97 = add i64 %t93, %t94
  %t99 = sub i64 %t97, 1
  %t100 = load i64, ptr %l5, !tbaa !24
  %t103 = sdiv i64 %t99, %t100
  store i64 %t103, ptr %l43, !tbaa !24
  br label %bb13
bb12:
  store i64 0, ptr %l43, !tbaa !24
  br label %bb13
bb13:
  %t105 = load i64, ptr %l43, !tbaa !24
  store i64 %t105, ptr %l40, !tbaa !24
  br label %bb14
bb14:
  %t106 = load i64, ptr %l40, !tbaa !24
  store i64 %t106, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb15
bb15:
  store %olang.scope zeroinitializer, ptr %s4
  %t107 = load i64, ptr %l7, !tbaa !24
  %t108 = load i64, ptr %l6, !tbaa !24
  %t111 = icmp slt i64 %t107, %t108
  %t113 = xor i1 %t111, true
  br i1 %t113, label %bb16, label %bb17
bb16:
  call void @__olang_scope_close(ptr %s4)
  br label %bb27
bb17:
  br label %bb18
bb18:
  %t115 = load i64, ptr %l3, !tbaa !24
  %t116 = load i64, ptr %l7, !tbaa !24
  %t117 = load i64, ptr %l5, !tbaa !24
  %t120 = mul i64 %t116, %t117
  %t123 = add i64 %t115, %t120
  store i64 %t123, ptr %l8, !tbaa !24
  %t125 = load ptr, ptr %l1, !tbaa !29
  %t127 = getelementptr %"compiler/scope:compRun", ptr %t125, i32 0, i32 16
  %t128 = load i64, ptr %l8, !tbaa !24
  %t131 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fscope_3acompRun_3f_26_H1a636e2bc42fd10a7cda4fcd89cb80cb(ptr %v1, ptr %v1, ptr %t127, i64 %t128)
  store ptr %t131, ptr %l64
  br label %bb19
bb19:
  %t132 = load ptr, ptr %l64, !tbaa !29
  store ptr %t132, ptr %l9, !tbaa !29
  store ptr %l2, ptr %l65, !tbaa !29
  %t133 = load ptr, ptr %l9, !tbaa !29
  %t135 = icmp eq ptr %t133, null
  %t137 = xor i1 %t135, true
  br i1 %t137, label %bb20, label %bb21
bb20:
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t140 = load ptr, ptr %l9, !tbaa !29
  %t143 = call { i64, ptr } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2erunId(ptr %v0, ptr %v1, ptr %s4, ptr %t139, ptr %t140)
  store { i64, ptr } %t143, ptr %l72
  br label %bb22
bb21:
  %t144 = load ptr, ptr %l1, !tbaa !29
  %t146 = getelementptr %"compiler/scope:compRun", ptr %t144, i32 0, i32 17
  %t147 = load i64, ptr %l8, !tbaa !24
  %t150 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v1, ptr %s4, ptr %t146, i64 %t147)
  store { i64, ptr } %t150, ptr %l77
  br label %bb23
bb22:
  %t151 = load { i64, ptr }, ptr %l72, !tbaa !27
  store { i64, ptr } %t151, ptr %l69, !tbaa !27
  br label %bb24
bb23:
  %t153 = load { i64, ptr }, ptr %l77, !tbaa !27
  store { i64, ptr } %t153, ptr %l69, !tbaa !27
  br label %bb24
bb24:
  %t154 = load { i64, ptr }, ptr %l69, !tbaa !27
  %t155 = extractvalue { i64, ptr } %t154, 1
  %t156 = extractvalue { i64, ptr } %t154, 0
  %t157 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d59, i32 0, i32 1) }, 1
  %t158 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d59, i32 0, i32 1) }, 0
  %t159 = add i64 %t156, %t158
  %t160 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t159)
  call void @olang_textcopy(ptr %t160, ptr %t155, i64 %t156)
  %t161 = getelementptr i8, ptr %t160, i64 %t156
  call void @olang_textcopy(ptr %t161, ptr %t157, i64 %t158)
  %t162 = insertvalue { i64, ptr } undef, i64 %t159, 0
  %t163 = insertvalue { i64, ptr } %t162, ptr %t160, 1
  %t165 = load ptr, ptr %l65, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s4, ptr %t165, { i64, ptr } %t163)
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s4)
  br label %bb26
bb26:
  %t167 = load i64, ptr %l7, !tbaa !24
  %t170 = add i64 %t167, 1
  store i64 %t170, ptr %l7, !tbaa !24
  br label %bb15
bb27:
  store %olang.scope zeroinitializer, ptr %s7
  %t172 = load ptr, ptr %l0, !tbaa !29
  %t173 = load ptr, ptr %l1, !tbaa !29
  %t176 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2emarksOf(ptr %v0, ptr %v1, ptr %s7, ptr %t172, ptr %t173)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t176, ptr %l85
  br label %bb28
bb28:
  %t177 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l85
  %t178 = call ptr @__olang_scope_alloc_a(ptr %s7, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t177, ptr %t178
  store ptr %t178, ptr %l10, !tbaa !29
  store i64 0, ptr %l11, !tbaa !24
  br label %bb29
bb29:
  store %olang.scope zeroinitializer, ptr %s8
  %t180 = load i64, ptr %l11, !tbaa !24
  store i64 %t180, ptr %l87, !tbaa !24
  %t181 = load ptr, ptr %l10, !tbaa !29
  %t183 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s7, ptr %t181)
  store i64 %t183, ptr %l89
  br label %bb30
bb30:
  %t184 = load i64, ptr %l87, !tbaa !24
  %t185 = load i64, ptr %l89, !tbaa !24
  %t186 = icmp slt i64 %t184, %t185
  %t188 = xor i1 %t186, true
  br i1 %t188, label %bb31, label %bb32
bb31:
  call void @__olang_scope_close(ptr %s8)
  br label %bb37
bb32:
  br label %bb33
bb33:
  %t190 = load ptr, ptr %l10, !tbaa !29
  %t191 = load i64, ptr %l11, !tbaa !24
  %t194 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s7, ptr %s7, ptr %t190, i64 %t191)
  store { i64, ptr } %t194, ptr %l94
  br label %bb34
bb34:
  %t195 = load { i64, ptr }, ptr %l94, !tbaa !27
  %t198 = extractvalue { i64, ptr } %t195, 1
  %t199 = extractvalue { i64, ptr } %t195, 0
  %t200 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d60, i32 0, i32 1) }, 1
  %t201 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d60, i32 0, i32 1) }, 0
  %t202 = add i64 %t199, %t201
  %t203 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t202)
  call void @olang_textcopy(ptr %t203, ptr %t198, i64 %t199)
  %t204 = getelementptr i8, ptr %t203, i64 %t199
  call void @olang_textcopy(ptr %t204, ptr %t200, i64 %t201)
  %t205 = insertvalue { i64, ptr } undef, i64 %t202, 0
  %t206 = insertvalue { i64, ptr } %t205, ptr %t203, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s8, ptr %l2, { i64, ptr } %t206)
  br label %bb35
bb35:
  call void @__olang_scope_close(ptr %s8)
  br label %bb36
bb36:
  %t210 = load i64, ptr %l11, !tbaa !24
  %t213 = add i64 %t210, 1
  store i64 %t213, ptr %l11, !tbaa !24
  br label %bb29
bb37:
  call void @__olang_scope_close(ptr %s7)
  %t215 = load ptr, ptr %l1, !tbaa !29
  %t217 = getelementptr %"compiler/scope:compRun", ptr %t215, i32 0, i32 18
  store ptr %t217, ptr %l13, !tbaa !29
  store i64 0, ptr %l14, !tbaa !24
  br label %bb38
bb38:
  store %olang.scope zeroinitializer, ptr %s12
  %t219 = load i64, ptr %l14, !tbaa !24
  store i64 %t219, ptr %l104, !tbaa !24
  %t220 = load ptr, ptr %l13, !tbaa !29
  %t222 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v1, ptr %t220)
  store i64 %t222, ptr %l106
  br label %bb39
bb39:
  %t223 = load i64, ptr %l104, !tbaa !24
  %t224 = load i64, ptr %l106, !tbaa !24
  %t225 = icmp slt i64 %t223, %t224
  %t227 = xor i1 %t225, true
  br i1 %t227, label %bb40, label %bb41
bb40:
  call void @__olang_scope_close(ptr %s12)
  br label %bb46
bb41:
  br label %bb42
bb42:
  %t229 = load ptr, ptr %l13, !tbaa !29
  %t230 = load i64, ptr %l14, !tbaa !24
  %t233 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v1, ptr %v1, ptr %t229, i64 %t230)
  store { i64, ptr } %t233, ptr %l111
  br label %bb43
bb43:
  %t234 = load { i64, ptr }, ptr %l111, !tbaa !27
  %t237 = extractvalue { i64, ptr } %t234, 1
  %t238 = extractvalue { i64, ptr } %t234, 0
  %t239 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d61, i32 0, i32 1) }, 1
  %t240 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d61, i32 0, i32 1) }, 0
  %t241 = add i64 %t238, %t240
  %t242 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t241)
  call void @olang_textcopy(ptr %t242, ptr %t237, i64 %t238)
  %t243 = getelementptr i8, ptr %t242, i64 %t238
  call void @olang_textcopy(ptr %t243, ptr %t239, i64 %t240)
  %t244 = insertvalue { i64, ptr } undef, i64 %t241, 0
  %t245 = insertvalue { i64, ptr } %t244, ptr %t242, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s12, ptr %l2, { i64, ptr } %t245)
  br label %bb44
bb44:
  call void @__olang_scope_close(ptr %s12)
  br label %bb45
bb45:
  %t249 = load i64, ptr %l14, !tbaa !24
  %t252 = add i64 %t249, 1
  store i64 %t252, ptr %l14, !tbaa !24
  br label %bb38
bb46:
  %t254 = load ptr, ptr %l1, !tbaa !29
  store ptr %t254, ptr %l119, !tbaa !29
  %t256 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s0, ptr %l2)
  store { i64, ptr } %t256, ptr %l121
  br label %bb47
bb47:
  %t257 = load { i64, ptr }, ptr %l121, !tbaa !27
  %t259 = call { i64, ptr } @compiler_2fscope_2ehashText(ptr %s0, ptr %v1, { i64, ptr } %t257)
  store { i64, ptr } %t259, ptr %l123
  br label %bb48
bb48:
  %t260 = load ptr, ptr %l119, !tbaa !29
  %t261 = getelementptr %"compiler/scope:compRun", ptr %t260, i32 0, i32 20
  %t262 = load { i64, ptr }, ptr %t261, !tbaa !27
  store { i64, ptr } %t262, ptr %l124, !tbaa !27
  %t263 = load { i64, ptr }, ptr %l123, !tbaa !27
  %t264 = load ptr, ptr %l119, !tbaa !29
  %t265 = getelementptr %"compiler/scope:compRun", ptr %t264, i32 0, i32 20
  store { i64, ptr } %t263, ptr %t265, !tbaa !27
  %t266 = load i1, ptr @olang_2esole_2ecompiler_2fscope_3acompRun_2e20
  br i1 %t266, label %bb49, label %bb50
bb49:
  %t268 = load { i64, ptr }, ptr %l124
  %t269 = extractvalue { i64, ptr } %t268, 0
  %t270 = extractvalue { i64, ptr } %t268, 1
  call void @__olang_region_release_part(ptr %t270, i64 %t269)
  store { i64, ptr } zeroinitializer, ptr %l124
  br label %bb50
bb50:
  %t271 = load ptr, ptr %l1, !tbaa !29
  %t273 = getelementptr %"compiler/scope:compRun", ptr %t271, i32 0, i32 20
  %t274 = load { i64, ptr }, ptr %t273, !tbaa !27
  store { i64, ptr } %t274, ptr %l127, !tbaa !27
  %t275 = load { i64, ptr }, ptr %l127, !tbaa !27
  %t276 = extractvalue { i64, ptr } %t275, 0
  store i64 %t276, ptr %l128, !tbaa !24
  %t277 = load i64, ptr %l128, !tbaa !24
  %t278 = mul i64 %t277, 1
  %t279 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t278)
  %t280 = insertvalue { i64, ptr } undef, i64 %t277, 0
  %t281 = insertvalue { i64, ptr } %t280, ptr %t279, 1
  store { i64, ptr } %t281, ptr %l129, !tbaa !27
  %t282 = getelementptr { i64, ptr }, ptr %l129, i32 0, i32 1
  %t283 = load ptr, ptr %t282, !tbaa !27
  %t284 = getelementptr { i64, ptr }, ptr %l127, i32 0, i32 1
  %t285 = load ptr, ptr %t284, !tbaa !27
  %t286 = load i64, ptr %l128, !tbaa !24
  %t287 = mul i64 %t286, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t283, ptr %t285, i64 %t287, i1 false)
  %t288 = load { i64, ptr }, ptr %l129, !tbaa !27
  store { i64, ptr } %t288, ptr %l127, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t289 = load { i64, ptr }, ptr %l127, !tbaa !27
  store { i64, ptr } %t289, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esoleArray(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l19 = alloca i64
  %l22 = alloca i64
  %l41 = alloca { i64, ptr }
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 151
  store i64 %a1, ptr %t5, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/scope:Scoper", ptr %t6, i32 0, i32 152
  store i1 false, ptr %t8, !tbaa !21
  store i64 %a3, ptr %l4, !tbaa !24
  %t11 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t11, 0
  store i64 %t13, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t15 = load i64, ptr %l5, !tbaa !24
  %t16 = load i64, ptr %l4, !tbaa !24
  %t19 = icmp sgt i64 %t15, %t16
  br i1 %t19, label %bb1, label %bb2
bb1:
  %t21 = load i64, ptr %l6, !tbaa !24
  %t23 = icmp sgt i64 %t21, 0
  br i1 %t23, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l19, !tbaa !24
  br label %bb6
bb3:
  %t25 = load i64, ptr %l5, !tbaa !24
  %t26 = load i64, ptr %l4, !tbaa !24
  %t29 = sub i64 %t25, %t26
  %t30 = load i64, ptr %l6, !tbaa !24
  %t33 = add i64 %t29, %t30
  %t35 = sub i64 %t33, 1
  %t36 = load i64, ptr %l6, !tbaa !24
  %t39 = sdiv i64 %t35, %t36
  store i64 %t39, ptr %l22, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l22, !tbaa !24
  br label %bb5
bb5:
  %t41 = load i64, ptr %l22, !tbaa !24
  store i64 %t41, ptr %l19, !tbaa !24
  br label %bb6
bb6:
  %t42 = load i64, ptr %l19, !tbaa !24
  store i64 %t42, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb7
bb7:
  %t43 = load i64, ptr %l8, !tbaa !24
  %t44 = load i64, ptr %l7, !tbaa !24
  %t47 = icmp slt i64 %t43, %t44
  %t49 = xor i1 %t47, true
  br i1 %t49, label %bb8, label %bb9
bb8:
  br label %bb13
bb9:
  br label %bb10
bb10:
  %t51 = load i64, ptr %l4, !tbaa !24
  %t52 = load i64, ptr %l8, !tbaa !24
  %t53 = load i64, ptr %l6, !tbaa !24
  %t56 = mul i64 %t52, %t53
  %t59 = add i64 %t51, %t56
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t62 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t62, ptr %l41, !tbaa !27
  %t65 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !27
  %t67 = getelementptr ptr, ptr %t66, i64 %t59
  %t68 = load ptr, ptr %t67, !tbaa !39
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esoleStmt(ptr %v0, ptr %v1, ptr %t61, ptr %t68)
  br label %bb11
bb11:
  br label %bb12
bb12:
  %t72 = load i64, ptr %l8, !tbaa !24
  %t75 = add i64 %t72, 1
  store i64 %t75, ptr %l8, !tbaa !24
  br label %bb7
bb13:
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/scope:Scoper", ptr %t77, i32 0, i32 152
  %t80 = load i1, ptr %t79, !tbaa !21
  %t82 = xor i1 %t80, true
  store i1 %t82, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esteadyLocal(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca i1
  %l11 = alloca ptr
  %l12 = alloca i1
  %l18 = alloca i64
  %l21 = alloca i1
  %l24 = alloca i1
  %rv = alloca i1
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb9
bb4:
  %t16 = load ptr, ptr %l1, !tbaa !29
  store ptr %t16, ptr %l11, !tbaa !29
  store i1 false, ptr %l12, !tbaa !21
  %t17 = load ptr, ptr %l11, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb5, label %bb6
bb5:
  %t20 = load ptr, ptr %l11, !tbaa !29
  %t21 = load i64, ptr %t20, !range !{i64 0, i64 18}
  %t23 = icmp eq i64 %t21, 3
  store i1 %t23, ptr %l12, !tbaa !21
  br label %bb6
bb6:
  %t24 = load i1, ptr %l12, !tbaa !21
  br i1 %t24, label %bb7, label %bb8
bb7:
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr { i64, [5 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t27, i32 0, i32 2
  %t29 = load ptr, ptr %t28
  store ptr %t29, ptr %l2, !tbaa !29
  br label %bb9
bb8:
  br label %bb11
bb9:
  %t31 = load ptr, ptr %l2, !tbaa !29
  %t33 = call i64 @compiler_2fscope_2ewholeLocal(ptr %v1, ptr %t31)
  store i64 %t33, ptr %l18
  br label %bb10
bb10:
  %t34 = load i64, ptr %l18, !tbaa !24
  store i64 %t34, ptr %l4, !tbaa !24
  br label %bb16
bb11:
  br i1 true, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  store i64 -1, ptr %l4, !tbaa !24
  br label %bb16
bb15:
  call void @__olang_check_failed(ptr @olang_loc_f608b5ac9574e601_8121f96c9d2c9ddd)
  unreachable
bb16:
  %t35 = load i64, ptr %l4, !tbaa !24
  store i64 %t35, ptr %l3, !tbaa !24
  %t36 = load i64, ptr %l3, !tbaa !24
  %t38 = icmp sge i64 %t36, 0
  br i1 %t38, label %bb17, label %bb18
bb17:
  %t41 = load i64, ptr %l3, !tbaa !24
  %t44 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ereassigned(ptr %v0, ptr %a0, i64 %t41)
  store i1 %t44, ptr %l24
  br label %bb19
bb18:
  store i1 false, ptr %l21, !tbaa !21
  br label %bb20
bb19:
  %t45 = load i1, ptr %l24, !tbaa !21
  %t46 = xor i1 %t45, true
  store i1 %t46, ptr %l21, !tbaa !21
  br label %bb20
bb20:
  %t48 = load i1, ptr %l21, !tbaa !21
  store i1 %t48, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2estoredFn(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca i1
  %l12 = alloca i64
  %l15 = alloca i1
  %l24 = alloca %"compiler/typed:Local"
  %l28 = alloca i1
  %l31 = alloca i1
  %l32 = alloca i1
  %l33 = alloca ptr
  %l42 = alloca %"compiler/typed:Local"
  %l44 = alloca i1
  %l55 = alloca ptr
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l2, !tbaa !29
  %t18 = call i64 @compiler_2fscope_2ewholeLocal(ptr %v1, ptr %t16)
  store i64 %t18, ptr %l12
  br label %bb6
bb6:
  %t19 = load i64, ptr %l12, !tbaa !24
  store i64 %t19, ptr %l4, !tbaa !24
  br label %bb12
bb7:
  br i1 true, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb11
bb10:
  store i64 -1, ptr %l4, !tbaa !24
  br label %bb12
bb11:
  call void @__olang_check_failed(ptr @olang_loc_44f4ea69e545b4db_1a5f351e4215689f)
  unreachable
bb12:
  %t20 = load i64, ptr %l4, !tbaa !24
  store i64 %t20, ptr %l3, !tbaa !24
  %t21 = load i64, ptr %l3, !tbaa !24
  %t23 = icmp slt i64 %t21, 0
  br i1 %t23, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb19
bb14:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/scope:Scoper", ptr %t25, i32 0, i32 28
  %t28 = load ptr, ptr %t27, !tbaa !29
  %t30 = icmp eq ptr %t28, null
  br i1 %t30, label %bb15, label %bb16
bb15:
  call void @__olang_check_failed(ptr @olang_loc_cbe1d942d8ca2243_1622ff745ca4c987)
  unreachable
bb16:
  br label %bb17
bb17:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/scope:Scoper", ptr %t32, i32 0, i32 28
  %t35 = load ptr, ptr %t34, !tbaa !29
  %t38 = getelementptr %"compiler/typed:Body", ptr %t35, i32 0, i32 7
  %t39 = load i64, ptr %l3, !tbaa !24
  %t42 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t38, i64 %t39)
  store %"compiler/typed:Local" %t42, ptr %l24
  br label %bb18
bb18:
  %t43 = getelementptr %"compiler/typed:Local", ptr %l24, i32 0, i32 4
  %t44 = load i32, ptr %t43, !range !{i32 0, i32 7}
  %t46 = trunc i64 1 to i32
  %t47 = icmp eq i32 %t44, %t46
  %t49 = xor i1 %t47, true
  store i1 %t49, ptr %l15, !tbaa !21
  br label %bb19
bb19:
  %t51 = load i1, ptr %l15, !tbaa !21
  br i1 %t51, label %bb20, label %bb21
bb20:
  store i1 true, ptr %l28, !tbaa !21
  br label %bb23
bb21:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = load i64, ptr %l3, !tbaa !24
  %t56 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ereassigned(ptr %v0, ptr %t52, i64 %t53)
  store i1 %t56, ptr %l31
  br label %bb22
bb22:
  %t57 = load i1, ptr %l31, !tbaa !21
  store i1 %t57, ptr %l28, !tbaa !21
  br label %bb23
bb23:
  %t58 = load i1, ptr %l28, !tbaa !21
  br i1 %t58, label %bb24, label %bb25
bb24:
  store i1 true, ptr %l32, !tbaa !21
  br label %bb31
bb25:
  %t59 = load ptr, ptr %l0, !tbaa !29
  store ptr %t59, ptr %l33, !tbaa !29
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/scope:Scoper", ptr %t60, i32 0, i32 28
  %t63 = load ptr, ptr %t62, !tbaa !29
  %t65 = icmp eq ptr %t63, null
  br i1 %t65, label %bb26, label %bb27
bb26:
  call void @__olang_check_failed(ptr @olang_loc_cbe1d942d8ca2243_1622ff745ca4c987)
  unreachable
bb27:
  br label %bb28
bb28:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/scope:Scoper", ptr %t67, i32 0, i32 28
  %t70 = load ptr, ptr %t69, !tbaa !29
  %t73 = getelementptr %"compiler/typed:Body", ptr %t70, i32 0, i32 7
  %t74 = load i64, ptr %l3, !tbaa !24
  %t77 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t73, i64 %t74)
  store %"compiler/typed:Local" %t77, ptr %l42
  br label %bb29
bb29:
  %t78 = getelementptr %"compiler/typed:Local", ptr %l42, i32 0, i32 2
  %t79 = load i32, ptr %t78, !tbaa !23
  %t80 = load ptr, ptr %l33, !tbaa !29
  %t82 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisFunc(ptr %v0, ptr %t80, i32 %t79)
  store i1 %t82, ptr %l44
  br label %bb30
bb30:
  %t83 = load i1, ptr %l44, !tbaa !21
  %t84 = xor i1 %t83, true
  store i1 %t84, ptr %l32, !tbaa !21
  br label %bb31
bb31:
  %t86 = load i1, ptr %l32, !tbaa !21
  br i1 %t86, label %bb32, label %bb33
bb32:
  store ptr null, ptr %rv
  br label %ret
bb33:
  br label %bb34
bb34:
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t90 = getelementptr %"compiler/scope:Scoper", ptr %t88, i32 0, i32 28
  %t91 = load ptr, ptr %t90, !tbaa !29
  %t93 = icmp eq ptr %t91, null
  br i1 %t93, label %bb35, label %bb36
bb35:
  call void @__olang_check_failed(ptr @olang_loc_2ca3a0095a8132c2_ea45de2b2f452556)
  unreachable
bb36:
  br label %bb37
bb37:
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t97 = getelementptr %"compiler/scope:Scoper", ptr %t95, i32 0, i32 28
  %t98 = load ptr, ptr %t97, !tbaa !29
  %t101 = getelementptr %"compiler/typed:Body", ptr %t98, i32 0, i32 11
  %t102 = load ptr, ptr %t101, !tbaa !29
  %t103 = load i64, ptr %l3, !tbaa !24
  %t106 = call ptr @compiler_2fscope_2eletOf(ptr %v0, ptr %v2, ptr %t102, i64 %t103)
  store ptr %t106, ptr %l55
  br label %bb38
bb38:
  %t107 = load ptr, ptr %l55, !tbaa !29
  store ptr %t107, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2etailBuilt(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l9 = alloca i32
  %l14 = alloca i1
  %l16 = alloca i1
  %l19 = alloca i1
  %l25 = alloca ptr
  %l26 = alloca ptr
  %l27 = alloca i1
  %l28 = alloca ptr
  %l29 = alloca i1
  %l32 = alloca ptr
  %l33 = alloca i1
  %l36 = alloca ptr
  %l37 = alloca i1
  %l42 = alloca ptr
  %l43 = alloca i1
  %l48 = alloca ptr
  %l49 = alloca i1
  %l58 = alloca i1
  %l60 = alloca ptr
  %l61 = alloca i1
  %l71 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t1)
  store i32 %t3, ptr %l9
  br label %bb1
bb1:
  %t4 = load i32, ptr %l9, !tbaa !23
  store i32 %t4, ptr %l4, !tbaa !23
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/scope:Scoper", ptr %t5, i32 0, i32 0
  %t8 = load ptr, ptr %t7, !tbaa !29
  %t10 = getelementptr %"compiler/generic:Program", ptr %t8, i32 0, i32 2
  %t11 = load i32, ptr %l4, !tbaa !23
  %t14 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %t10, i32 %t11)
  store i1 %t14, ptr %l14
  br label %bb2
bb2:
  %t15 = load i1, ptr %l14, !tbaa !21
  %t16 = xor i1 %t15, true
  br i1 %t16, label %bb3, label %bb4
bb3:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t19 = load i32, ptr %l4, !tbaa !23
  %t22 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2earenaValue(ptr %v0, ptr %t18, i32 %t19)
  store i1 %t22, ptr %l19
  br label %bb5
bb4:
  store i1 false, ptr %l16, !tbaa !21
  br label %bb6
bb5:
  %t23 = load i1, ptr %l19, !tbaa !21
  %t24 = xor i1 %t23, true
  store i1 %t24, ptr %l16, !tbaa !21
  br label %bb6
bb6:
  %t26 = load i1, ptr %l16, !tbaa !21
  br i1 %t26, label %bb7, label %bb8
bb7:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load ptr, ptr %l2, !tbaa !29
  %t33 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunAway(ptr %v0, ptr %v1, ptr %s0, ptr %t28, ptr %t29)
  store ptr %t33, ptr %l25
  br label %bb10
bb10:
  %t34 = load ptr, ptr %l25, !tbaa !29
  %t35 = call ptr @compiler_2fscope_2eunPassed(ptr %s0, ptr %s0, ptr %t34)
  store ptr %t35, ptr %l26
  br label %bb11
bb11:
  %t36 = load ptr, ptr %l26, !tbaa !29
  store ptr %t36, ptr %l5, !tbaa !29
  %t37 = load ptr, ptr %l5, !tbaa !29
  store ptr %t37, ptr %l28, !tbaa !29
  store i1 false, ptr %l29, !tbaa !21
  %t38 = load ptr, ptr %l28, !tbaa !29
  %t39 = icmp ne ptr %t38, null
  br i1 %t39, label %bb12, label %bb13
bb12:
  %t41 = load ptr, ptr %l28, !tbaa !29
  %t42 = load i64, ptr %t41, !range !{i64 0, i64 18}
  %t44 = icmp eq i64 %t42, 1
  store i1 %t44, ptr %l29, !tbaa !21
  br label %bb13
bb13:
  %t45 = load i1, ptr %l29, !tbaa !21
  br i1 %t45, label %bb14, label %bb15
bb14:
  br label %bb20
bb15:
  %t46 = load ptr, ptr %l5, !tbaa !29
  store ptr %t46, ptr %l32, !tbaa !29
  store i1 false, ptr %l33, !tbaa !21
  %t47 = load ptr, ptr %l32, !tbaa !29
  %t48 = icmp ne ptr %t47, null
  br i1 %t48, label %bb16, label %bb17
bb16:
  %t50 = load ptr, ptr %l32, !tbaa !29
  %t51 = load i64, ptr %t50, !range !{i64 0, i64 18}
  %t53 = icmp eq i64 %t51, 0
  store i1 %t53, ptr %l33, !tbaa !21
  br label %bb17
bb17:
  %t54 = load i1, ptr %l33, !tbaa !21
  br i1 %t54, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb21
bb20:
  store i1 false, ptr %l27, !tbaa !21
  br label %bb48
bb21:
  %t55 = load ptr, ptr %l5, !tbaa !29
  store ptr %t55, ptr %l36, !tbaa !29
  store i1 false, ptr %l37, !tbaa !21
  %t56 = load ptr, ptr %l36, !tbaa !29
  %t57 = icmp ne ptr %t56, null
  br i1 %t57, label %bb22, label %bb23
bb22:
  %t59 = load ptr, ptr %l36, !tbaa !29
  %t60 = load i64, ptr %t59, !range !{i64 0, i64 18}
  %t62 = icmp eq i64 %t60, 2
  store i1 %t62, ptr %l37, !tbaa !21
  br label %bb23
bb23:
  %t63 = load i1, ptr %l37, !tbaa !21
  br i1 %t63, label %bb24, label %bb25
bb24:
  %t64 = load ptr, ptr %l5, !tbaa !29
  %t66 = getelementptr { i64, [5 x i64] }, ptr %t64, i32 0, i32 1
  %t67 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t66, i32 0, i32 2
  %t68 = load ptr, ptr %t67
  store ptr %t68, ptr %l6, !tbaa !29
  br label %bb34
bb25:
  %t70 = load ptr, ptr %l5, !tbaa !29
  store ptr %t70, ptr %l42, !tbaa !29
  store i1 false, ptr %l43, !tbaa !21
  %t71 = load ptr, ptr %l42, !tbaa !29
  %t72 = icmp ne ptr %t71, null
  br i1 %t72, label %bb26, label %bb27
bb26:
  %t74 = load ptr, ptr %l42, !tbaa !29
  %t75 = load i64, ptr %t74, !range !{i64 0, i64 18}
  %t77 = icmp eq i64 %t75, 4
  store i1 %t77, ptr %l43, !tbaa !21
  br label %bb27
bb27:
  %t78 = load i1, ptr %l43, !tbaa !21
  br i1 %t78, label %bb28, label %bb29
bb28:
  %t79 = load ptr, ptr %l5, !tbaa !29
  %t81 = getelementptr { i64, [5 x i64] }, ptr %t79, i32 0, i32 1
  %t82 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t81, i32 0, i32 2
  %t83 = load ptr, ptr %t82
  store ptr %t83, ptr %l6, !tbaa !29
  br label %bb34
bb29:
  %t85 = load ptr, ptr %l5, !tbaa !29
  store ptr %t85, ptr %l48, !tbaa !29
  store i1 false, ptr %l49, !tbaa !21
  %t86 = load ptr, ptr %l48, !tbaa !29
  %t87 = icmp ne ptr %t86, null
  br i1 %t87, label %bb30, label %bb31
bb30:
  %t89 = load ptr, ptr %l48, !tbaa !29
  %t90 = load i64, ptr %t89, !range !{i64 0, i64 18}
  %t92 = icmp eq i64 %t90, 3
  store i1 %t92, ptr %l49, !tbaa !21
  br label %bb31
bb31:
  %t93 = load i1, ptr %l49, !tbaa !21
  br i1 %t93, label %bb32, label %bb33
bb32:
  %t94 = load ptr, ptr %l5, !tbaa !29
  %t96 = getelementptr { i64, [5 x i64] }, ptr %t94, i32 0, i32 1
  %t97 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t96, i32 0, i32 2
  %t98 = load ptr, ptr %t97
  store ptr %t98, ptr %l6, !tbaa !29
  br label %bb34
bb33:
  br label %bb36
bb34:
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t101 = load i64, ptr %l1, !tbaa !24
  %t102 = load ptr, ptr %l6, !tbaa !29
  %t103 = load ptr, ptr %l3, !tbaa !29
  %t108 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2etailGiven(ptr %v0, ptr %s0, ptr %v2, ptr %t100, i64 %t101, ptr %t102, ptr %t103)
  store i1 %t108, ptr %l58
  br label %bb35
bb35:
  %t109 = load i1, ptr %l58, !tbaa !21
  %t110 = xor i1 %t109, true
  store i1 %t110, ptr %l27, !tbaa !21
  br label %bb48
bb36:
  %t112 = load ptr, ptr %l5, !tbaa !29
  store ptr %t112, ptr %l60, !tbaa !29
  store i1 false, ptr %l61, !tbaa !21
  %t113 = load ptr, ptr %l60, !tbaa !29
  %t114 = icmp ne ptr %t113, null
  br i1 %t114, label %bb37, label %bb38
bb37:
  %t116 = load ptr, ptr %l60, !tbaa !29
  %t117 = load i64, ptr %t116, !range !{i64 0, i64 18}
  %t119 = icmp eq i64 %t117, 10
  store i1 %t119, ptr %l61, !tbaa !21
  br label %bb38
bb38:
  %t120 = load i1, ptr %l61, !tbaa !21
  br i1 %t120, label %bb39, label %bb40
bb39:
  %t121 = load ptr, ptr %l5, !tbaa !29
  %t123 = getelementptr { i64, [5 x i64] }, ptr %t121, i32 0, i32 1
  %t124 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t123, i32 0, i32 2
  %t125 = load ptr, ptr %t124
  store ptr %t125, ptr %l7, !tbaa !29
  br label %bb41
bb40:
  br label %bb43
bb41:
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t128 = load i64, ptr %l1, !tbaa !24
  %t129 = load ptr, ptr %l7, !tbaa !29
  %t131 = getelementptr %"compiler/typed:Slice", ptr %t129, i32 0, i32 0
  %t132 = load ptr, ptr %t131, !tbaa !29
  %t133 = load ptr, ptr %l3, !tbaa !29
  %t138 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2etailGiven(ptr %v0, ptr %s0, ptr %v2, ptr %t127, i64 %t128, ptr %t132, ptr %t133)
  store i1 %t138, ptr %l71
  br label %bb42
bb42:
  %t139 = load i1, ptr %l71, !tbaa !21
  %t140 = xor i1 %t139, true
  store i1 %t140, ptr %l27, !tbaa !21
  br label %bb48
bb43:
  br i1 true, label %bb44, label %bb45
bb44:
  br label %bb46
bb45:
  br label %bb47
bb46:
  store i1 true, ptr %l27, !tbaa !21
  br label %bb48
bb47:
  call void @__olang_check_failed(ptr @olang_loc_95037a04ed425830_2b58d7c0cb40fd64)
  unreachable
bb48:
  call void @__olang_scope_close(ptr %s0)
  %t142 = load i1, ptr %l27, !tbaa !21
  store i1 %t142, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2etailLifts(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, { i64, ptr } %a2, { i64, ptr } %a3, %"compiler/source:Span" %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca { i64, [2 x i64] }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca ptr
  %l13 = alloca i1
  %l14 = alloca i64
  %l15 = alloca ptr
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca %"compiler/typed:Local"
  %l32 = alloca i64
  %l35 = alloca i64
  %l54 = alloca { i64, ptr }
  %l57 = alloca { i64, ptr }
  %l61 = alloca i1
  %l62 = alloca { i64, ptr }
  %l63 = alloca { i64, ptr }
  %l67 = alloca i1
  %l70 = alloca i1
  %l71 = alloca ptr
  %l73 = alloca i32
  %l74 = alloca i1
  %l76 = alloca i1
  %l79 = alloca i1
  %l80 = alloca ptr
  %l81 = alloca i64
  %l84 = alloca %"compiler/source:Span"
  %l87 = alloca i64
  %l90 = alloca i1
  %l110 = alloca i64
  %l114 = alloca i64
  %l117 = alloca i64
  %l138 = alloca %"compiler/typed:Local"
  %l141 = alloca i1
  %l144 = alloca i1
  %l149 = alloca i1
  %l150 = alloca i1
  %l155 = alloca i1
  %l160 = alloca i1
  %l162 = alloca ptr
  %l163 = alloca i64
  %l166 = alloca %"compiler/source:Span"
  %t5 = alloca { i64, [2 x i64] }, align 8
  %t287 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store %"compiler/source:Span" %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 44
  %t4 = load i64, ptr %t3, !tbaa !24
  store { i64, [2 x i64] } zeroinitializer, ptr %t5
  %t6 = getelementptr { i64, [2 x i64] }, ptr %t5, i32 0, i32 0
  store i64 2, ptr %t6
  %t8 = insertvalue { i64 } undef, i64 %t4, 0
  %t9 = getelementptr { i64, [2 x i64] }, ptr %t5, i32 0, i32 1
  store { i64 } %t8, ptr %t9
  %t10 = load { i64, [2 x i64] }, ptr %t5
  store { i64, [2 x i64] } %t10, ptr %l5
  store i64 0, ptr %l6, !tbaa !24
  %t12 = load ptr, ptr %l1, !tbaa !29
  %t14 = getelementptr %"compiler/typed:Call", ptr %t12, i32 0, i32 1
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 0
  store i64 %t17, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t19 = load i64, ptr %l7, !tbaa !24
  %t20 = load i64, ptr %l6, !tbaa !24
  %t23 = icmp sgt i64 %t19, %t20
  br i1 %t23, label %bb1, label %bb2
bb1:
  %t25 = load i64, ptr %l8, !tbaa !24
  %t27 = icmp sgt i64 %t25, 0
  br i1 %t27, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l32, !tbaa !24
  br label %bb6
bb3:
  %t29 = load i64, ptr %l7, !tbaa !24
  %t30 = load i64, ptr %l6, !tbaa !24
  %t33 = sub i64 %t29, %t30
  %t34 = load i64, ptr %l8, !tbaa !24
  %t37 = add i64 %t33, %t34
  %t39 = sub i64 %t37, 1
  %t40 = load i64, ptr %l8, !tbaa !24
  %t43 = sdiv i64 %t39, %t40
  store i64 %t43, ptr %l35, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l35, !tbaa !24
  br label %bb5
bb5:
  %t45 = load i64, ptr %l35, !tbaa !24
  store i64 %t45, ptr %l32, !tbaa !24
  br label %bb6
bb6:
  %t46 = load i64, ptr %l32, !tbaa !24
  store i64 %t46, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb7
bb7:
  %t47 = load i64, ptr %l10, !tbaa !24
  %t48 = load i64, ptr %l9, !tbaa !24
  %t51 = icmp slt i64 %t47, %t48
  %t53 = xor i1 %t51, true
  br i1 %t53, label %bb8, label %bb9
bb8:
  br label %bb39
bb9:
  br label %bb10
bb10:
  %t55 = load i64, ptr %l6, !tbaa !24
  %t56 = load i64, ptr %l10, !tbaa !24
  %t57 = load i64, ptr %l8, !tbaa !24
  %t60 = mul i64 %t56, %t57
  %t63 = add i64 %t55, %t60
  store i64 %t63, ptr %l11, !tbaa !24
  %t65 = load ptr, ptr %l1, !tbaa !29
  %t67 = getelementptr %"compiler/typed:Call", ptr %t65, i32 0, i32 1
  %t68 = load { i64, ptr }, ptr %t67, !tbaa !27
  store { i64, ptr } %t68, ptr %l54, !tbaa !27
  %t69 = load i64, ptr %l11, !tbaa !24
  %t71 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t72 = load ptr, ptr %t71, !tbaa !27
  %t73 = getelementptr ptr, ptr %t72, i64 %t69
  %t74 = load ptr, ptr %t73, !tbaa !39
  store ptr %t74, ptr %l12, !tbaa !29
  %t76 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t76, ptr %l57, !tbaa !27
  %t77 = load i64, ptr %l11, !tbaa !24
  %t79 = getelementptr { i64, ptr }, ptr %l57, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !27
  %t81 = getelementptr i64, ptr %t80, i64 %t77
  %t82 = load i64, ptr %t81, !tbaa !34
  %t84 = icmp sge i64 %t82, 0
  br i1 %t84, label %bb11, label %bb12
bb11:
  store { i64, ptr } %a3, ptr %l62, !tbaa !27
  %t87 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t87, ptr %l63, !tbaa !27
  %t88 = load i64, ptr %l11, !tbaa !24
  %t90 = getelementptr { i64, ptr }, ptr %l63, i32 0, i32 1
  %t91 = load ptr, ptr %t90, !tbaa !27
  %t92 = getelementptr i64, ptr %t91, i64 %t88
  %t93 = load i64, ptr %t92, !tbaa !34
  %t95 = getelementptr { i64, ptr }, ptr %l62, i32 0, i32 1
  %t96 = load ptr, ptr %t95, !tbaa !27
  %t97 = getelementptr { i64, [2 x i64] }, ptr %t96, i64 %t93
  %t98 = load { i64, [2 x i64] }, ptr %t97
  %t100 = call i1 @compiler_2fscope_2eisBlockTerm({ i64, [2 x i64] } %t98)
  store i1 %t100, ptr %l67
  br label %bb13
bb12:
  store i1 false, ptr %l61, !tbaa !21
  br label %bb14
bb13:
  %t101 = load i1, ptr %l67, !tbaa !21
  store i1 %t101, ptr %l61, !tbaa !21
  br label %bb14
bb14:
  %t102 = load i1, ptr %l61, !tbaa !21
  store i1 %t102, ptr %l13, !tbaa !21
  %t103 = load i1, ptr %l13, !tbaa !21
  %t105 = xor i1 %t103, true
  br i1 %t105, label %bb15, label %bb16
bb15:
  %t107 = load ptr, ptr %l0, !tbaa !29
  store ptr %t107, ptr %l71, !tbaa !29
  %t108 = load ptr, ptr %l12, !tbaa !29
  %t110 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t108)
  store i32 %t110, ptr %l73
  br label %bb17
bb16:
  store i1 false, ptr %l70, !tbaa !21
  br label %bb23
bb17:
  %t111 = load ptr, ptr %l71, !tbaa !29
  %t112 = load i32, ptr %l73, !tbaa !23
  %t113 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2earenaValue(ptr %v0, ptr %t111, i32 %t112)
  store i1 %t113, ptr %l74
  br label %bb18
bb18:
  %t114 = load i1, ptr %l74, !tbaa !21
  %t115 = xor i1 %t114, true
  br i1 %t115, label %bb19, label %bb20
bb19:
  store i1 true, ptr %l76, !tbaa !21
  br label %bb22
bb20:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t118 = load ptr, ptr %l12, !tbaa !29
  %t121 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2etailStorageGiven(ptr %v0, ptr %v1, ptr %t117, ptr %t118)
  store i1 %t121, ptr %l79
  br label %bb21
bb21:
  %t122 = load i1, ptr %l79, !tbaa !21
  store i1 %t122, ptr %l76, !tbaa !21
  br label %bb22
bb22:
  %t123 = load i1, ptr %l76, !tbaa !21
  store i1 %t123, ptr %l70, !tbaa !21
  br label %bb23
bb23:
  %t124 = load i1, ptr %l70, !tbaa !21
  br i1 %t124, label %bb24, label %bb25
bb24:
  br label %bb38
bb25:
  br label %bb26
bb26:
  %t125 = load ptr, ptr %l0, !tbaa !29
  store ptr %t125, ptr %l80, !tbaa !29
  %t126 = load i64, ptr @G_2ecompiler_2fscope_2ePlaceTail, !tbaa !24
  store i64 %t126, ptr %l81, !tbaa !24
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t128 = load %"compiler/source:Span", ptr %l4
  %t131 = call %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enameSpan(ptr %v0, ptr %t127, %"compiler/source:Span" %t128)
  store %"compiler/source:Span" %t131, ptr %l84
  br label %bb27
bb27:
  %t132 = load ptr, ptr %l80, !tbaa !29
  %t133 = load i64, ptr %l81, !tbaa !24
  %t134 = load %"compiler/source:Span", ptr %l84
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eviewing(ptr %v0, ptr %t132, i64 %t133, %"compiler/source:Span" %t134)
  br label %bb28
bb28:
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t136 = load ptr, ptr %l12, !tbaa !29
  %t139 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eclaimRoot(ptr %v0, ptr %v1, ptr %t135, ptr %t136)
  store i64 %t139, ptr %l87
  br label %bb29
bb29:
  %t140 = load i64, ptr %l87, !tbaa !24
  store i64 %t140, ptr %l14, !tbaa !24
  %t141 = load i1, ptr %l13, !tbaa !21
  %t143 = xor i1 %t141, true
  br i1 %t143, label %bb30, label %bb31
bb30:
  %t145 = load i64, ptr %l14, !tbaa !24
  %t147 = icmp sge i64 %t145, 0
  store i1 %t147, ptr %l90, !tbaa !21
  br label %bb32
bb31:
  store i1 false, ptr %l90, !tbaa !21
  br label %bb32
bb32:
  %t149 = load i1, ptr %l90, !tbaa !21
  br i1 %t149, label %bb33, label %bb34
bb33:
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t151 = load i64, ptr %l14, !tbaa !24
  %t152 = load { i64, [2 x i64] }, ptr %l5
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eproposeLocal(ptr %v0, ptr %t150, i64 %t151, { i64, [2 x i64] } %t152, i1 true)
  br label %bb35
bb34:
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t157 = load ptr, ptr %l12, !tbaa !29
  %t158 = load { i64, [2 x i64] }, ptr %l5
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epropose(ptr %v0, ptr %v1, ptr %t156, ptr %t157, { i64, [2 x i64] } %t158)
  br label %bb36
bb35:
  br label %bb37
bb36:
  br label %bb37
bb37:
  %t162 = load ptr, ptr %l0, !tbaa !29
  %t164 = getelementptr %"compiler/scope:Scoper", ptr %t162, i32 0, i32 230
  store i64 0, ptr %t164, !tbaa !24
  br label %bb38
bb38:
  %t165 = load i64, ptr %l10, !tbaa !24
  %t168 = add i64 %t165, 1
  store i64 %t168, ptr %l10, !tbaa !24
  br label %bb7
bb39:
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t172 = getelementptr %"compiler/scope:Scoper", ptr %t170, i32 0, i32 28
  %t173 = load ptr, ptr %t172, !tbaa !29
  %t175 = icmp eq ptr %t173, null
  br i1 %t175, label %bb40, label %bb41
bb40:
  call void @__olang_check_failed(ptr @olang_loc_b16579729361c5ff_a172e348fd9e9523)
  unreachable
bb41:
  br label %bb42
bb42:
  %t177 = load ptr, ptr %l0, !tbaa !29
  %t179 = getelementptr %"compiler/scope:Scoper", ptr %t177, i32 0, i32 28
  %t180 = load ptr, ptr %t179, !tbaa !29
  store ptr %t180, ptr %l15, !tbaa !29
  store i64 0, ptr %l16, !tbaa !24
  %t182 = load ptr, ptr %l15, !tbaa !29
  %t184 = getelementptr %"compiler/typed:Body", ptr %t182, i32 0, i32 7
  %t186 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eLen_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t184)
  store i64 %t186, ptr %l110
  br label %bb43
bb43:
  %t187 = load i64, ptr %l110, !tbaa !24
  store i64 %t187, ptr %l17, !tbaa !24
  store i64 1, ptr %l18, !tbaa !24
  %t188 = load i64, ptr %l17, !tbaa !24
  %t189 = load i64, ptr %l16, !tbaa !24
  %t192 = icmp sgt i64 %t188, %t189
  br i1 %t192, label %bb44, label %bb45
bb44:
  %t194 = load i64, ptr %l18, !tbaa !24
  %t196 = icmp sgt i64 %t194, 0
  br i1 %t196, label %bb46, label %bb47
bb45:
  store i64 0, ptr %l114, !tbaa !24
  br label %bb49
bb46:
  %t198 = load i64, ptr %l17, !tbaa !24
  %t199 = load i64, ptr %l16, !tbaa !24
  %t202 = sub i64 %t198, %t199
  %t203 = load i64, ptr %l18, !tbaa !24
  %t206 = add i64 %t202, %t203
  %t208 = sub i64 %t206, 1
  %t209 = load i64, ptr %l18, !tbaa !24
  %t212 = sdiv i64 %t208, %t209
  store i64 %t212, ptr %l117, !tbaa !24
  br label %bb48
bb47:
  store i64 0, ptr %l117, !tbaa !24
  br label %bb48
bb48:
  %t214 = load i64, ptr %l117, !tbaa !24
  store i64 %t214, ptr %l114, !tbaa !24
  br label %bb49
bb49:
  %t215 = load i64, ptr %l114, !tbaa !24
  store i64 %t215, ptr %l19, !tbaa !24
  store i64 0, ptr %l20, !tbaa !24
  br label %bb50
bb50:
  %t216 = load i64, ptr %l20, !tbaa !24
  %t217 = load i64, ptr %l19, !tbaa !24
  %t220 = icmp slt i64 %t216, %t217
  %t222 = xor i1 %t220, true
  br i1 %t222, label %bb51, label %bb52
bb51:
  br label %bb80
bb52:
  br label %bb53
bb53:
  %t224 = load i64, ptr %l16, !tbaa !24
  %t225 = load i64, ptr %l20, !tbaa !24
  %t226 = load i64, ptr %l18, !tbaa !24
  %t229 = mul i64 %t225, %t226
  %t232 = add i64 %t224, %t229
  store i64 %t232, ptr %l21, !tbaa !24
  %t234 = load ptr, ptr %l15, !tbaa !29
  %t236 = getelementptr %"compiler/typed:Body", ptr %t234, i32 0, i32 7
  %t237 = load i64, ptr %l21, !tbaa !24
  %t240 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t236, i64 %t237)
  store %"compiler/typed:Local" %t240, ptr %l138
  br label %bb54
bb54:
  %t241 = load %"compiler/typed:Local", ptr %l138
  store %"compiler/typed:Local" %t241, ptr %l22
  %t242 = getelementptr %"compiler/typed:Local", ptr %l22, i32 0, i32 4
  %t243 = load i32, ptr %t242, !range !{i32 0, i32 7}
  %t245 = trunc i64 0 to i32
  %t246 = icmp eq i32 %t243, %t245
  br i1 %t246, label %bb55, label %bb56
bb55:
  store i1 true, ptr %l141, !tbaa !21
  br label %bb57
bb56:
  %t248 = getelementptr %"compiler/typed:Local", ptr %l22, i32 0, i32 4
  %t249 = load i32, ptr %t248, !range !{i32 0, i32 7}
  %t251 = trunc i64 6 to i32
  %t252 = icmp eq i32 %t249, %t251
  store i1 %t252, ptr %l141, !tbaa !21
  br label %bb57
bb57:
  %t254 = load i1, ptr %l141, !tbaa !21
  br i1 %t254, label %bb58, label %bb59
bb58:
  store i1 true, ptr %l144, !tbaa !21
  br label %bb60
bb59:
  %t255 = getelementptr %"compiler/typed:Local", ptr %l22, i32 0, i32 4
  %t256 = load i32, ptr %t255, !range !{i32 0, i32 7}
  %t258 = trunc i64 5 to i32
  %t259 = icmp eq i32 %t256, %t258
  store i1 %t259, ptr %l144, !tbaa !21
  br label %bb60
bb60:
  %t261 = load i1, ptr %l144, !tbaa !21
  br i1 %t261, label %bb61, label %bb62
bb61:
  br label %bb79
bb62:
  br label %bb63
bb63:
  %t262 = load ptr, ptr %l0, !tbaa !29
  %t263 = getelementptr %"compiler/typed:Local", ptr %l22, i32 0, i32 2
  %t264 = load i32, ptr %t263, !tbaa !23
  %t267 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisRef(ptr %v0, ptr %t262, i32 %t264)
  store i1 %t267, ptr %l149
  br label %bb64
bb64:
  %t268 = load i1, ptr %l149, !tbaa !21
  br i1 %t268, label %bb65, label %bb66
bb65:
  store i1 true, ptr %l150, !tbaa !21
  br label %bb68
bb66:
  %t269 = load ptr, ptr %l0, !tbaa !29
  %t271 = getelementptr %"compiler/scope:Scoper", ptr %t269, i32 0, i32 0
  %t272 = load ptr, ptr %t271, !tbaa !29
  %t274 = getelementptr %"compiler/generic:Program", ptr %t272, i32 0, i32 2
  %t275 = getelementptr %"compiler/typed:Local", ptr %l22, i32 0, i32 2
  %t276 = load i32, ptr %t275, !tbaa !23
  %t279 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNeedsDrop(ptr %v0, ptr %t274, i32 %t276)
  store i1 %t279, ptr %l155
  br label %bb67
bb67:
  %t280 = load i1, ptr %l155, !tbaa !21
  %t281 = xor i1 %t280, true
  store i1 %t281, ptr %l150, !tbaa !21
  br label %bb68
bb68:
  %t283 = load i1, ptr %l150, !tbaa !21
  br i1 %t283, label %bb69, label %bb70
bb69:
  br label %bb79
bb70:
  br label %bb71
bb71:
  %t284 = load ptr, ptr %l0, !tbaa !29
  %t285 = getelementptr %"compiler/typed:Local", ptr %l22, i32 0, i32 3
  %t286 = load i32, ptr %t285, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t287
  %t288 = getelementptr { i64, [2 x i64] }, ptr %t287, i32 0, i32 0
  store i64 1, ptr %t288
  %t290 = insertvalue { i32 } undef, i32 %t286, 0
  %t291 = getelementptr { i64, [2 x i64] }, ptr %t287, i32 0, i32 1
  store { i32 } %t290, ptr %t291
  %t292 = load { i64, [2 x i64] }, ptr %t287
  %t295 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2etailCloses(ptr %v0, ptr %t284, { i64, [2 x i64] } %t292)
  store i1 %t295, ptr %l160
  br label %bb72
bb72:
  %t296 = load i1, ptr %l160, !tbaa !21
  %t297 = xor i1 %t296, true
  br i1 %t297, label %bb73, label %bb74
bb73:
  br label %bb79
bb74:
  br label %bb75
bb75:
  %t299 = load ptr, ptr %l0, !tbaa !29
  store ptr %t299, ptr %l162, !tbaa !29
  %t300 = load i64, ptr @G_2ecompiler_2fscope_2ePlaceTail, !tbaa !24
  store i64 %t300, ptr %l163, !tbaa !24
  %t301 = load ptr, ptr %l0, !tbaa !29
  %t302 = load %"compiler/source:Span", ptr %l4
  %t305 = call %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enameSpan(ptr %v0, ptr %t301, %"compiler/source:Span" %t302)
  store %"compiler/source:Span" %t305, ptr %l166
  br label %bb76
bb76:
  %t306 = load ptr, ptr %l162, !tbaa !29
  %t307 = load i64, ptr %l163, !tbaa !24
  %t308 = load %"compiler/source:Span", ptr %l166
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eviewing(ptr %v0, ptr %t306, i64 %t307, %"compiler/source:Span" %t308)
  br label %bb77
bb77:
  %t309 = load ptr, ptr %l0, !tbaa !29
  %t310 = load i64, ptr %l21, !tbaa !24
  %t311 = load { i64, [2 x i64] }, ptr %l5
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eproposeLocal(ptr %v0, ptr %t309, i64 %t310, { i64, [2 x i64] } %t311, i1 true)
  br label %bb78
bb78:
  %t315 = load ptr, ptr %l0, !tbaa !29
  %t317 = getelementptr %"compiler/scope:Scoper", ptr %t315, i32 0, i32 230
  store i64 0, ptr %t317, !tbaa !24
  br label %bb79
bb79:
  %t318 = load i64, ptr %l20, !tbaa !24
  %t321 = add i64 %t318, 1
  store i64 %t321, ptr %l20, !tbaa !24
  br label %bb50
bb80:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2etailNeeds(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca %"compiler/types:DtorWalk"
  %l13 = alloca ptr
  %l14 = alloca i64
  %l15 = alloca %"compiler/typed:Local"
  %l16 = alloca %"compiler/scope:walked"
  %l17 = alloca ptr
  %l18 = alloca i64
  %l22 = alloca i64
  %l24 = alloca i64
  %l29 = alloca ptr
  %l32 = alloca ptr
  %l43 = alloca { i64, ptr }
  %l50 = alloca i1
  %l61 = alloca ptr
  %l65 = alloca %"compiler/types:DtorWalk"
  %l68 = alloca i64
  %l70 = alloca i64
  %l75 = alloca %"compiler/typed:Local"
  %l79 = alloca i1
  %l82 = alloca i1
  %l91 = alloca %"compiler/scope:walked"
  %l96 = alloca i64
  %l98 = alloca i64
  %l103 = alloca i32
  %l106 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  %t142 = alloca %"compiler/scope:walked", align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/scope:walked", ptr %t1, i32 0, i32 8
  store ptr %t3, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t5 = load i64, ptr %l4, !tbaa !24
  store i64 %t5, ptr %l22, !tbaa !24
  %t6 = load ptr, ptr %l3, !tbaa !29
  %t8 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v1, ptr %t6)
  store i64 %t8, ptr %l24
  br label %bb2
bb2:
  %t9 = load i64, ptr %l22, !tbaa !24
  %t10 = load i64, ptr %l24, !tbaa !24
  %t11 = icmp slt i64 %t9, %t10
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb3, label %bb4
bb3:
  br label %bb22
bb4:
  br label %bb5
bb5:
  %t15 = load ptr, ptr %l3, !tbaa !29
  %t16 = load i64, ptr %l4, !tbaa !24
  %t19 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v1, ptr %v1, ptr %t15, i64 %t16)
  store ptr %t19, ptr %l29
  br label %bb6
bb6:
  %t20 = load ptr, ptr %l29, !tbaa !29
  %t24 = call ptr @compiler_2ftyped_2eCall_2eOf(ptr %v1, ptr %v1, ptr %t20)
  store ptr %t24, ptr %l32
  br label %bb7
bb7:
  %t25 = load ptr, ptr %l32, !tbaa !29
  store ptr %t25, ptr %l6, !tbaa !29
  %t26 = load ptr, ptr %l6, !tbaa !29
  %t28 = icmp eq ptr %t26, null
  br i1 %t28, label %bb8, label %bb9
bb8:
  br label %bb21
bb9:
  br label %bb10
bb10:
  %t30 = load ptr, ptr %l6, !tbaa !29
  %t32 = getelementptr %"compiler/typed:Call", ptr %t30, i32 0, i32 1
  %t33 = load { i64, ptr }, ptr %t32, !tbaa !27
  store { i64, ptr } %t33, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t35 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t37 = extractvalue { i64, ptr } %t35, 0
  store i64 %t37, ptr %l9, !tbaa !24
  br label %bb11
bb11:
  %t39 = load i64, ptr %l8, !tbaa !24
  %t40 = load i64, ptr %l9, !tbaa !24
  %t43 = icmp slt i64 %t39, %t40
  %t45 = xor i1 %t43, true
  br i1 %t45, label %bb12, label %bb13
bb12:
  br label %bb20
bb13:
  br label %bb14
bb14:
  %t47 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t47, ptr %l43, !tbaa !27
  %t48 = load i64, ptr %l8, !tbaa !24
  %t50 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t51 = load ptr, ptr %t50, !tbaa !27
  %t52 = getelementptr ptr, ptr %t51, i64 %t48
  %t53 = load ptr, ptr %t52, !tbaa !39
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t56 = load i64, ptr %l1, !tbaa !24
  %t58 = load ptr, ptr %l2, !tbaa !29
  %t63 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2etailBuilt(ptr %v0, ptr %v1, ptr %v1, ptr %t55, i64 %t56, ptr %t53, ptr %t58)
  store i1 %t63, ptr %l50
  br label %bb15
bb15:
  %t64 = load i1, ptr %l50, !tbaa !21
  br i1 %t64, label %bb16, label %bb17
bb16:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb17:
  br label %bb18
bb18:
  br label %bb19
bb19:
  %t66 = load i64, ptr %l8, !tbaa !24
  %t69 = add i64 %t66, 1
  store i64 %t69, ptr %l8, !tbaa !24
  br label %bb11
bb20:
  br label %bb21
bb21:
  %t71 = load i64, ptr %l4, !tbaa !24
  %t74 = add i64 %t71, 1
  store i64 %t74, ptr %l4, !tbaa !24
  br label %bb1
bb22:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"compiler/scope:Scoper", ptr %t76, i32 0, i32 1
  %t79 = load i64, ptr %l1, !tbaa !24
  %t82 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t78, i64 %t79)
  store ptr %t82, ptr %l61
  br label %bb23
bb23:
  %t83 = load ptr, ptr %l61, !tbaa !29
  store ptr %t83, ptr %l11, !tbaa !29
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr %"compiler/scope:Scoper", ptr %t84, i32 0, i32 0
  %t87 = load ptr, ptr %t86, !tbaa !29
  %t89 = getelementptr %"compiler/generic:Program", ptr %t87, i32 0, i32 2
  %t91 = call %"compiler/types:DtorWalk" @compiler_2ftypes_3aDtorWalk_2ector(ptr %v0, ptr %s0, ptr %t89)
  store %"compiler/types:DtorWalk" %t91, ptr %l65
  br label %bb24
bb24:
  %t92 = load %"compiler/types:DtorWalk", ptr %l65
  store %"compiler/types:DtorWalk" %t92, ptr %l12
  %t93 = load ptr, ptr %l11, !tbaa !29
  %t95 = getelementptr %"compiler/typed:Body", ptr %t93, i32 0, i32 7
  store ptr %t95, ptr %l13, !tbaa !29
  store i64 0, ptr %l14, !tbaa !24
  br label %bb25
bb25:
  %t97 = load i64, ptr %l14, !tbaa !24
  store i64 %t97, ptr %l68, !tbaa !24
  %t98 = load ptr, ptr %l13, !tbaa !29
  %t100 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eLen_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t98)
  store i64 %t100, ptr %l70
  br label %bb26
bb26:
  %t101 = load i64, ptr %l68, !tbaa !24
  %t102 = load i64, ptr %l70, !tbaa !24
  %t103 = icmp slt i64 %t101, %t102
  %t105 = xor i1 %t103, true
  br i1 %t105, label %bb27, label %bb28
bb27:
  br label %bb39
bb28:
  br label %bb29
bb29:
  %t107 = load ptr, ptr %l13, !tbaa !29
  %t108 = load i64, ptr %l14, !tbaa !24
  %t111 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t107, i64 %t108)
  store %"compiler/typed:Local" %t111, ptr %l75
  br label %bb30
bb30:
  %t112 = load %"compiler/typed:Local", ptr %l75
  store %"compiler/typed:Local" %t112, ptr %l15
  %t113 = getelementptr %"compiler/typed:Local", ptr %l15, i32 0, i32 4
  %t114 = load i32, ptr %t113, !range !{i32 0, i32 7}
  %t116 = trunc i64 0 to i32
  %t117 = icmp eq i32 %t114, %t116
  %t119 = xor i1 %t117, true
  br i1 %t119, label %bb31, label %bb32
bb31:
  %t121 = getelementptr %"compiler/typed:Local", ptr %l15, i32 0, i32 2
  %t122 = load i32, ptr %t121, !tbaa !23
  %t125 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aDtorWalk_2eHolds(ptr %s0, ptr %v0, ptr %l12, i32 %t122)
  store i1 %t125, ptr %l82
  br label %bb33
bb32:
  store i1 false, ptr %l79, !tbaa !21
  br label %bb34
bb33:
  %t126 = load i1, ptr %l82, !tbaa !21
  store i1 %t126, ptr %l79, !tbaa !21
  br label %bb34
bb34:
  %t127 = load i1, ptr %l79, !tbaa !21
  br i1 %t127, label %bb35, label %bb36
bb35:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb36:
  br label %bb37
bb37:
  br label %bb38
bb38:
  %t129 = load i64, ptr %l14, !tbaa !24
  %t132 = add i64 %t129, 1
  store i64 %t132, ptr %l14, !tbaa !24
  br label %bb25
bb39:
  %t134 = load ptr, ptr %l11, !tbaa !29
  %t136 = getelementptr %"compiler/typed:Body", ptr %t134, i32 0, i32 11
  %t137 = load ptr, ptr %t136, !tbaa !29
  %t139 = icmp eq ptr %t137, null
  br i1 %t139, label %bb40, label %bb41
bb40:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb41:
  br label %bb42
bb42:
  call void @olang_2emir_2eHelperKind_2eZero_2ecompiler_2fscope_3awalked(ptr %t142, ptr %s0)
  call void @llvm.memmove.p0.p0.i64(ptr %l91, ptr %t142, i64 424, i1 false)
  br label %bb43
bb43:
  call void @llvm.memmove.p0.p0.i64(ptr %l16, ptr %l91, i64 424, i1 false)
  %t143 = getelementptr %"compiler/scope:walked", ptr %l16, i32 0, i32 11
  store i1 true, ptr %t143, !tbaa !21
  %t144 = load ptr, ptr %l11, !tbaa !29
  %t146 = getelementptr %"compiler/typed:Body", ptr %t144, i32 0, i32 11
  %t147 = load ptr, ptr %t146, !tbaa !29
  call void @compiler_2fscope_2ecollectBlock(ptr %v0, ptr %s0, ptr %t147, ptr %l16)
  br label %bb44
bb44:
  %t150 = getelementptr %"compiler/scope:walked", ptr %l16, i32 0, i32 12
  store ptr %t150, ptr %l17, !tbaa !29
  store i64 0, ptr %l18, !tbaa !24
  br label %bb45
bb45:
  %t152 = load i64, ptr %l18, !tbaa !24
  store i64 %t152, ptr %l96, !tbaa !24
  %t153 = load ptr, ptr %l17, !tbaa !29
  %t155 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %t153)
  store i64 %t155, ptr %l98
  br label %bb46
bb46:
  %t156 = load i64, ptr %l96, !tbaa !24
  %t157 = load i64, ptr %l98, !tbaa !24
  %t158 = icmp slt i64 %t156, %t157
  %t160 = xor i1 %t158, true
  br i1 %t160, label %bb47, label %bb48
bb47:
  br label %bb56
bb48:
  br label %bb49
bb49:
  %t162 = load ptr, ptr %l17, !tbaa !29
  %t163 = load i64, ptr %l18, !tbaa !24
  %t166 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %t162, i64 %t163)
  store i32 %t166, ptr %l103
  br label %bb50
bb50:
  %t167 = load i32, ptr %l103, !tbaa !23
  %t171 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aDtorWalk_2eHolds(ptr %s0, ptr %v0, ptr %l12, i32 %t167)
  store i1 %t171, ptr %l106
  br label %bb51
bb51:
  %t172 = load i1, ptr %l106, !tbaa !21
  br i1 %t172, label %bb52, label %bb53
bb52:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb53:
  br label %bb54
bb54:
  br label %bb55
bb55:
  %t174 = load i64, ptr %l18, !tbaa !24
  %t177 = add i64 %t174, 1
  store i64 %t177, ptr %l18, !tbaa !24
  br label %bb45
bb56:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2etiedToBlock(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca %"compiler/scope:rel"
  %l10 = alloca i64
  %l11 = alloca { i64, [2 x i64] }
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l23 = alloca ptr
  %l29 = alloca i32
  %l33 = alloca i64
  %l36 = alloca i1
  %l39 = alloca ptr
  %l46 = alloca i64
  %l51 = alloca { i64, ptr }
  %l54 = alloca ptr
  %l57 = alloca i64
  %l59 = alloca i64
  %l64 = alloca %"compiler/scope:rel"
  %l67 = alloca i1
  %l83 = alloca i64
  %l86 = alloca i64
  %l109 = alloca i64
  %l112 = alloca i64
  %l119 = alloca i1
  %l124 = alloca i1
  %l127 = alloca { i64, ptr }
  %l131 = alloca { i64, [2 x i64] }
  %l132 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t4 = call ptr @compiler_2ftyped_2eCall_2eOf(ptr %v1, ptr %v1, ptr %a1)
  store ptr %t4, ptr %l23
  br label %bb1
bb1:
  %t5 = load ptr, ptr %l23, !tbaa !29
  store ptr %t5, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t8 = icmp eq ptr %t6, null
  br i1 %t8, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load ptr, ptr %l2, !tbaa !29
  %t15 = call i32 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecalleeType(ptr %v0, ptr %v1, ptr %t11, ptr %t12)
  store i32 %t15, ptr %l29
  br label %bb5
bb5:
  %t16 = load i32, ptr %l29, !tbaa !23
  store i32 %t16, ptr %l3, !tbaa !23
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t18 = load ptr, ptr %l2, !tbaa !29
  %t20 = getelementptr %"compiler/typed:Call", ptr %t18, i32 0, i32 0
  %t21 = load ptr, ptr %t20, !tbaa !29
  %t24 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebodyOf(ptr %v0, ptr %v1, ptr %t17, ptr %t21)
  store i64 %t24, ptr %l33
  br label %bb6
bb6:
  %t25 = load i64, ptr %l33, !tbaa !24
  store i64 %t25, ptr %l4, !tbaa !24
  %t26 = load i64, ptr %l4, !tbaa !24
  %t28 = icmp slt i64 %t26, 0
  br i1 %t28, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l36, !tbaa !21
  br label %bb10
bb8:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t31 = load i64, ptr %l4, !tbaa !24
  %t34 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esum(ptr %v0, ptr %v0, ptr %t30, i64 %t31)
  store ptr %t34, ptr %l39
  br label %bb9
bb9:
  %t35 = load ptr, ptr %l39, !tbaa !29
  %t37 = getelementptr %"compiler/scope:summary", ptr %t35, i32 0, i32 20
  %t38 = load i1, ptr %t37, !tbaa !21
  %t40 = xor i1 %t38, true
  store i1 %t40, ptr %l36, !tbaa !21
  br label %bb10
bb10:
  %t42 = load i1, ptr %l36, !tbaa !21
  br i1 %t42, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t45 = load i32, ptr %l3, !tbaa !23
  %t48 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eresultVarOf(ptr %v0, ptr %t44, i32 %t45)
  store i64 %t48, ptr %l46
  br label %bb14
bb14:
  %t49 = load i64, ptr %l46, !tbaa !24
  store i64 %t49, ptr %l5, !tbaa !24
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/scope:Scoper", ptr %t50, i32 0, i32 0
  %t53 = load ptr, ptr %t52, !tbaa !29
  %t55 = getelementptr %"compiler/generic:Program", ptr %t53, i32 0, i32 2
  %t56 = load i32, ptr %l3, !tbaa !23
  %t59 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopeVarsOf(ptr %v0, ptr %s0, ptr %t55, i32 %t56)
  store { i64, ptr } %t59, ptr %l51
  br label %bb15
bb15:
  %t60 = load { i64, ptr }, ptr %l51, !tbaa !27
  store { i64, ptr } %t60, ptr %l6, !tbaa !27
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t62 = load i64, ptr %l4, !tbaa !24
  %t65 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esum(ptr %v0, ptr %v0, ptr %t61, i64 %t62)
  store ptr %t65, ptr %l54
  br label %bb16
bb16:
  %t66 = load ptr, ptr %l54, !tbaa !29
  %t68 = getelementptr %"compiler/scope:summary", ptr %t66, i32 0, i32 0
  store ptr %t68, ptr %l7, !tbaa !29
  store i64 0, ptr %l8, !tbaa !24
  br label %bb17
bb17:
  %t70 = load i64, ptr %l8, !tbaa !24
  store i64 %t70, ptr %l57, !tbaa !24
  %t71 = load ptr, ptr %l7, !tbaa !29
  %t73 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3arel_3e_2eLen_3ccompiler_2fscope_3arel_3e(ptr %v0, ptr %t71)
  store i64 %t73, ptr %l59
  br label %bb18
bb18:
  %t74 = load i64, ptr %l57, !tbaa !24
  %t75 = load i64, ptr %l59, !tbaa !24
  %t76 = icmp slt i64 %t74, %t75
  %t78 = xor i1 %t76, true
  br i1 %t78, label %bb19, label %bb20
bb19:
  br label %bb66
bb20:
  br label %bb21
bb21:
  %t80 = load ptr, ptr %l7, !tbaa !29
  %t81 = load i64, ptr %l8, !tbaa !24
  %t84 = call %"compiler/scope:rel" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3arel_3e_2eAt_3ccompiler_2fscope_3arel_3e(ptr %v0, ptr %t80, i64 %t81)
  store %"compiler/scope:rel" %t84, ptr %l64
  br label %bb22
bb22:
  %t85 = load %"compiler/scope:rel", ptr %l64
  store %"compiler/scope:rel" %t85, ptr %l9
  %t86 = getelementptr %"compiler/scope:rel", ptr %l9, i32 0, i32 1
  %t87 = load { i64, [2 x i64] }, ptr %t86
  %t89 = extractvalue { i64, [2 x i64] } %t87, 0
  %t90 = icmp eq i64 %t89, 2
  br i1 %t90, label %bb23, label %bb24
bb23:
  %t92 = getelementptr %"compiler/scope:rel", ptr %l9, i32 0, i32 1
  %t93 = getelementptr { i64, [2 x i64] }, ptr %t92, i32 0, i32 1
  %t94 = getelementptr { i64 }, ptr %t93, i32 0, i32 0
  %t95 = load i64, ptr %t94
  %t96 = load i64, ptr %l5, !tbaa !24
  %t99 = icmp eq i64 %t95, %t96
  store i1 %t99, ptr %l67, !tbaa !21
  br label %bb25
bb24:
  store i1 false, ptr %l67, !tbaa !21
  br label %bb25
bb25:
  %t101 = load i1, ptr %l67, !tbaa !21
  %t102 = xor i1 %t101, true
  br i1 %t102, label %bb26, label %bb27
bb26:
  br label %bb65
bb27:
  br label %bb28
bb28:
  %t104 = getelementptr %"compiler/scope:rel", ptr %l9, i32 0, i32 1
  %t105 = getelementptr { i64, [2 x i64] }, ptr %t104, i32 0, i32 1
  %t106 = getelementptr { i64 }, ptr %t105, i32 0, i32 0
  %t107 = load i64, ptr %t106
  store i64 %t107, ptr %l10, !tbaa !24
  %t109 = getelementptr %"compiler/scope:rel", ptr %l9, i32 0, i32 0
  %t110 = load { i64, [2 x i64] }, ptr %t109
  store { i64, [2 x i64] } %t110, ptr %l11
  %t112 = load { i64, [2 x i64] }, ptr %l11
  %t114 = extractvalue { i64, [2 x i64] } %t112, 0
  %t115 = icmp eq i64 %t114, 2
  br i1 %t115, label %bb29, label %bb30
bb29:
  %t117 = getelementptr { i64, [2 x i64] }, ptr %l11, i32 0, i32 1
  %t118 = getelementptr { i64 }, ptr %t117, i32 0, i32 0
  %t119 = load i64, ptr %t118
  store i64 %t119, ptr %l12, !tbaa !24
  br label %bb31
bb30:
  br label %bb59
bb31:
  store i64 0, ptr %l13, !tbaa !24
  %t121 = load ptr, ptr %l2, !tbaa !29
  %t123 = getelementptr %"compiler/typed:Call", ptr %t121, i32 0, i32 1
  %t124 = load { i64, ptr }, ptr %t123, !tbaa !27
  %t126 = extractvalue { i64, ptr } %t124, 0
  store i64 %t126, ptr %l14, !tbaa !24
  store i64 1, ptr %l15, !tbaa !24
  %t128 = load i64, ptr %l14, !tbaa !24
  %t129 = load i64, ptr %l13, !tbaa !24
  %t132 = icmp sgt i64 %t128, %t129
  br i1 %t132, label %bb32, label %bb33
bb32:
  %t134 = load i64, ptr %l15, !tbaa !24
  %t136 = icmp sgt i64 %t134, 0
  br i1 %t136, label %bb34, label %bb35
bb33:
  store i64 0, ptr %l83, !tbaa !24
  br label %bb37
bb34:
  %t138 = load i64, ptr %l14, !tbaa !24
  %t139 = load i64, ptr %l13, !tbaa !24
  %t142 = sub i64 %t138, %t139
  %t143 = load i64, ptr %l15, !tbaa !24
  %t146 = add i64 %t142, %t143
  %t148 = sub i64 %t146, 1
  %t149 = load i64, ptr %l15, !tbaa !24
  %t152 = sdiv i64 %t148, %t149
  store i64 %t152, ptr %l86, !tbaa !24
  br label %bb36
bb35:
  store i64 0, ptr %l86, !tbaa !24
  br label %bb36
bb36:
  %t154 = load i64, ptr %l86, !tbaa !24
  store i64 %t154, ptr %l83, !tbaa !24
  br label %bb37
bb37:
  %t155 = load i64, ptr %l83, !tbaa !24
  store i64 %t155, ptr %l16, !tbaa !24
  store i64 0, ptr %l17, !tbaa !24
  br label %bb38
bb38:
  %t156 = load i64, ptr %l17, !tbaa !24
  %t157 = load i64, ptr %l16, !tbaa !24
  %t160 = icmp slt i64 %t156, %t157
  %t162 = xor i1 %t160, true
  br i1 %t162, label %bb39, label %bb40
bb39:
  br label %bb58
bb40:
  br label %bb41
bb41:
  %t164 = load i64, ptr %l13, !tbaa !24
  %t165 = load i64, ptr %l17, !tbaa !24
  %t166 = load i64, ptr %l15, !tbaa !24
  %t169 = mul i64 %t165, %t166
  %t172 = add i64 %t164, %t169
  store i64 %t172, ptr %l18, !tbaa !24
  %t174 = load ptr, ptr %l0, !tbaa !29
  %t176 = getelementptr %"compiler/scope:Scoper", ptr %t174, i32 0, i32 0
  %t177 = load ptr, ptr %t176, !tbaa !29
  %t179 = getelementptr %"compiler/generic:Program", ptr %t177, i32 0, i32 2
  %t180 = load i32, ptr %l3, !tbaa !23
  %t181 = load i64, ptr %l18, !tbaa !24
  %t185 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShareOf(ptr %v0, ptr %t179, i32 %t180, i64 %t181)
  store i64 %t185, ptr %l109
  br label %bb42
bb42:
  %t186 = load i64, ptr %l109, !tbaa !24
  store i64 %t186, ptr %l19, !tbaa !24
  %t187 = load i64, ptr %l19, !tbaa !24
  %t189 = icmp sge i64 %t187, 0
  br i1 %t189, label %bb43, label %bb44
bb43:
  %t191 = load i64, ptr %l19, !tbaa !24
  store i64 %t191, ptr %l112, !tbaa !24
  br label %bb45
bb44:
  %t193 = load i64, ptr %l18, !tbaa !24
  store i64 %t193, ptr %l112, !tbaa !24
  br label %bb45
bb45:
  %t195 = load i64, ptr %l112, !tbaa !24
  store i64 %t195, ptr %l20, !tbaa !24
  %t196 = load i64, ptr %l12, !tbaa !24
  %t197 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t199 = extractvalue { i64, ptr } %t197, 0
  %t202 = icmp slt i64 %t196, %t199
  br i1 %t202, label %bb46, label %bb47
bb46:
  %t204 = load i64, ptr %l12, !tbaa !24
  %t206 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t207 = load ptr, ptr %t206, !tbaa !27
  %t208 = getelementptr i64, ptr %t207, i64 %t204
  %t209 = load i64, ptr %t208, !tbaa !34
  %t210 = load i64, ptr %l20, !tbaa !24
  %t213 = icmp eq i64 %t209, %t210
  store i1 %t213, ptr %l119, !tbaa !21
  br label %bb48
bb47:
  store i1 false, ptr %l119, !tbaa !21
  br label %bb48
bb48:
  %t215 = load i1, ptr %l119, !tbaa !21
  br i1 %t215, label %bb49, label %bb50
bb49:
  %t216 = load ptr, ptr %l0, !tbaa !29
  %t217 = load ptr, ptr %l2, !tbaa !29
  %t219 = getelementptr %"compiler/typed:Call", ptr %t217, i32 0, i32 1
  %t220 = load { i64, ptr }, ptr %t219, !tbaa !27
  store { i64, ptr } %t220, ptr %l127, !tbaa !27
  %t221 = load i64, ptr %l18, !tbaa !24
  %t223 = getelementptr { i64, ptr }, ptr %l127, i32 0, i32 1
  %t224 = load ptr, ptr %t223, !tbaa !27
  %t225 = getelementptr ptr, ptr %t224, i64 %t221
  %t226 = load ptr, ptr %t225, !tbaa !39
  %t230 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epeekTerm(ptr %v0, ptr %v1, ptr %t216, ptr %t226)
  store { i64, [2 x i64] } %t230, ptr %l131
  br label %bb51
bb50:
  store i1 false, ptr %l124, !tbaa !21
  br label %bb53
bb51:
  %t231 = load { i64, [2 x i64] }, ptr %l131
  %t232 = call i1 @compiler_2fscope_2eisBlockTerm({ i64, [2 x i64] } %t231)
  store i1 %t232, ptr %l132
  br label %bb52
bb52:
  %t233 = load i1, ptr %l132, !tbaa !21
  store i1 %t233, ptr %l124, !tbaa !21
  br label %bb53
bb53:
  %t234 = load i1, ptr %l124, !tbaa !21
  br i1 %t234, label %bb54, label %bb55
bb54:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb55:
  br label %bb56
bb56:
  br label %bb57
bb57:
  %t236 = load i64, ptr %l17, !tbaa !24
  %t239 = add i64 %t236, 1
  store i64 %t239, ptr %l17, !tbaa !24
  br label %bb38
bb58:
  br label %bb64
bb59:
  br i1 true, label %bb60, label %bb61
bb60:
  br label %bb62
bb61:
  br label %bb63
bb62:
  br label %bb64
bb63:
  call void @__olang_check_failed(ptr @olang_loc_9d778c78f7953c66_3314afc5257f7cda)
  unreachable
bb64:
  br label %bb65
bb65:
  %t241 = load i64, ptr %l8, !tbaa !24
  %t244 = add i64 %t241, 1
  store i64 %t244, ptr %l8, !tbaa !24
  br label %bb17
bb66:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eueStmt(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, i64 %a3, i64 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i32
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l18 = alloca ptr
  %l19 = alloca ptr
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca i64
  %l24 = alloca ptr
  %l25 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l26 = alloca { i64, ptr }
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca ptr
  %l30 = alloca { i64, ptr }
  %l31 = alloca i64
  %l32 = alloca i64
  %l34 = alloca ptr
  %l38 = alloca ptr
  %l39 = alloca i1
  %l49 = alloca i1
  %l50 = alloca ptr
  %l55 = alloca %"compiler/typed:Local"
  %l57 = alloca i1
  %l58 = alloca i1
  %l61 = alloca i1
  %l69 = alloca i1
  %l76 = alloca i1
  %l77 = alloca ptr
  %l78 = alloca i1
  %l93 = alloca i1
  %l94 = alloca i1
  %l101 = alloca i1
  %l107 = alloca i1
  %l108 = alloca i1
  %l115 = alloca i1
  %l116 = alloca ptr
  %l117 = alloca i1
  %l128 = alloca i1
  %l129 = alloca ptr
  %l130 = alloca i1
  %l142 = alloca i1
  %l143 = alloca i1
  %l151 = alloca i1
  %l152 = alloca i1
  %l159 = alloca i1
  %l160 = alloca ptr
  %l161 = alloca i1
  %l174 = alloca i1
  %l175 = alloca i1
  %l181 = alloca i1
  %l182 = alloca ptr
  %l183 = alloca i1
  %l188 = alloca ptr
  %l189 = alloca i1
  %l199 = alloca i1
  %l200 = alloca ptr
  %l201 = alloca i1
  %l214 = alloca i1
  %l215 = alloca i1
  %l221 = alloca i1
  %l222 = alloca ptr
  %l223 = alloca i1
  %l233 = alloca i1
  %l234 = alloca ptr
  %l235 = alloca i1
  %l246 = alloca i1
  %l247 = alloca ptr
  %l248 = alloca i1
  %l259 = alloca i1
  %l260 = alloca ptr
  %l261 = alloca i1
  %l273 = alloca i1
  %l284 = alloca { i64, ptr }
  %l293 = alloca i1
  %l300 = alloca ptr
  %l301 = alloca i1
  %l306 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l314 = alloca i1
  %l324 = alloca { i64, ptr }
  %l334 = alloca i1
  %l347 = alloca i1
  %l358 = alloca { i64, ptr }
  %l367 = alloca i1
  %l374 = alloca ptr
  %l375 = alloca i1
  %l386 = alloca i1
  %s20 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i64 %a3, ptr %l3
  store i64 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l2, !tbaa !29
  store ptr %t6, ptr %l38, !tbaa !29
  store i1 false, ptr %l39, !tbaa !21
  %t7 = load ptr, ptr %l38, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb4, label %bb5
bb4:
  %t10 = load ptr, ptr %l38, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 17}
  %t13 = icmp eq i64 %t11, 0
  store i1 %t13, ptr %l39, !tbaa !21
  br label %bb5
bb5:
  %t14 = load i1, ptr %l39, !tbaa !21
  br i1 %t14, label %bb6, label %bb7
bb6:
  %t15 = load ptr, ptr %l2, !tbaa !29
  %t17 = getelementptr { i64, [3 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t17, i32 0, i32 1
  %t19 = load i32, ptr %t18
  store i32 %t19, ptr %l5, !tbaa !23
  %t21 = load ptr, ptr %l2, !tbaa !29
  %t23 = getelementptr { i64, [3 x i64] }, ptr %t21, i32 0, i32 1
  %t24 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t23, i32 0, i32 2
  %t25 = load ptr, ptr %t24
  store ptr %t25, ptr %l6, !tbaa !29
  br label %bb8
bb7:
  br label %bb23
bb8:
  %t27 = load i64, ptr %l4, !tbaa !24
  %t28 = load i64, ptr @G_2ecompiler_2fscope_2eUseOwn, !tbaa !24
  %t31 = icmp eq i64 %t27, %t28
  br i1 %t31, label %bb9, label %bb10
bb9:
  %t33 = load ptr, ptr %l0, !tbaa !29
  store ptr %t33, ptr %l50, !tbaa !29
  %t34 = load ptr, ptr %l1, !tbaa !29
  %t36 = getelementptr %"compiler/typed:Body", ptr %t34, i32 0, i32 7
  %t37 = load i32, ptr %l5, !tbaa !23
  %t39 = sext i32 %t37 to i64
  %t42 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v1, ptr %t36, i64 %t39)
  store %"compiler/typed:Local" %t42, ptr %l55
  br label %bb11
bb10:
  store i1 false, ptr %l49, !tbaa !21
  br label %bb13
bb11:
  %t43 = getelementptr %"compiler/typed:Local", ptr %l55, i32 0, i32 2
  %t44 = load i32, ptr %t43, !tbaa !23
  %t45 = load ptr, ptr %l50, !tbaa !29
  %t47 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisRef(ptr %v0, ptr %t45, i32 %t44)
  store i1 %t47, ptr %l57
  br label %bb12
bb12:
  %t48 = load i1, ptr %l57, !tbaa !21
  store i1 %t48, ptr %l49, !tbaa !21
  br label %bb13
bb13:
  %t49 = load i1, ptr %l49, !tbaa !21
  br i1 %t49, label %bb14, label %bb15
bb14:
  %t50 = load ptr, ptr %l6, !tbaa !29
  %t51 = load i64, ptr %l3, !tbaa !24
  %t54 = call i1 @compiler_2fscope_2eownView(ptr %v2, ptr %t50, i64 %t51)
  store i1 %t54, ptr %l61
  br label %bb16
bb15:
  store i1 false, ptr %l58, !tbaa !21
  br label %bb17
bb16:
  %t55 = load i1, ptr %l61, !tbaa !21
  store i1 %t55, ptr %l58, !tbaa !21
  br label %bb17
bb17:
  %t56 = load i1, ptr %l58, !tbaa !21
  br i1 %t56, label %bb18, label %bb19
bb18:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t58 = load ptr, ptr %l1, !tbaa !29
  %t59 = load ptr, ptr %l1, !tbaa !29
  %t61 = getelementptr %"compiler/typed:Body", ptr %t59, i32 0, i32 11
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t63 = load i32, ptr %l5, !tbaa !23
  %t65 = sext i32 %t63 to i64
  %t66 = load i64, ptr %l4, !tbaa !24
  %t72 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eueBlock(ptr %v0, ptr %v1, ptr %v1, ptr %t57, ptr %t58, ptr %t62, i64 %t65, i64 %t66)
  store i1 %t72, ptr %l69
  br label %bb20
bb19:
  br label %bb21
bb20:
  %t73 = load i1, ptr %l69, !tbaa !21
  store i1 %t73, ptr %rv
  br label %ret
bb21:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t75 = load ptr, ptr %l1, !tbaa !29
  %t76 = load ptr, ptr %l6, !tbaa !29
  %t78 = load i64, ptr %l3, !tbaa !24
  %t79 = load i64, ptr %l4, !tbaa !24
  %t85 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eueExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t74, ptr %t75, ptr %t76, i64 %t78, i64 %t79)
  store i1 %t85, ptr %l76
  br label %bb22
bb22:
  %t86 = load i1, ptr %l76, !tbaa !21
  store i1 %t86, ptr %rv
  br label %ret
bb23:
  %t87 = load ptr, ptr %l2, !tbaa !29
  store ptr %t87, ptr %l77, !tbaa !29
  store i1 false, ptr %l78, !tbaa !21
  %t88 = load ptr, ptr %l77, !tbaa !29
  %t89 = icmp ne ptr %t88, null
  br i1 %t89, label %bb24, label %bb25
bb24:
  %t91 = load ptr, ptr %l77, !tbaa !29
  %t92 = load i64, ptr %t91, !range !{i64 0, i64 17}
  %t94 = icmp eq i64 %t92, 1
  store i1 %t94, ptr %l78, !tbaa !21
  br label %bb25
bb25:
  %t95 = load i1, ptr %l78, !tbaa !21
  br i1 %t95, label %bb26, label %bb27
bb26:
  %t96 = load ptr, ptr %l2, !tbaa !29
  %t98 = getelementptr { i64, [3 x i64] }, ptr %t96, i32 0, i32 1
  %t99 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t98, i32 0, i32 1
  %t100 = load ptr, ptr %t99
  store ptr %t100, ptr %l7, !tbaa !29
  %t102 = load ptr, ptr %l2, !tbaa !29
  %t104 = getelementptr { i64, [3 x i64] }, ptr %t102, i32 0, i32 1
  %t105 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t104, i32 0, i32 2
  %t106 = load ptr, ptr %t105
  store ptr %t106, ptr %l8, !tbaa !29
  br label %bb28
bb27:
  br label %bb42
bb28:
  %t108 = load i64, ptr %l4, !tbaa !24
  %t109 = load i64, ptr @G_2ecompiler_2fscope_2eUseOwn, !tbaa !24
  %t112 = icmp eq i64 %t108, %t109
  br i1 %t112, label %bb29, label %bb30
bb29:
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t115 = load ptr, ptr %l1, !tbaa !29
  %t116 = load ptr, ptr %l7, !tbaa !29
  %t117 = load i64, ptr %l3, !tbaa !24
  %t118 = load i64, ptr %l4, !tbaa !24
  %t124 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eueTarget(ptr %v0, ptr %v1, ptr %v2, ptr %t114, ptr %t115, ptr %t116, i64 %t117, i64 %t118)
  store i1 %t124, ptr %l93
  br label %bb31
bb30:
  br label %bb36
bb31:
  %t125 = load i1, ptr %l93, !tbaa !21
  br i1 %t125, label %bb32, label %bb33
bb32:
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t127 = load ptr, ptr %l1, !tbaa !29
  %t128 = load ptr, ptr %l8, !tbaa !29
  %t130 = load i64, ptr %l3, !tbaa !24
  %t131 = load i64, ptr %l4, !tbaa !24
  %t137 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eueExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t126, ptr %t127, ptr %t128, i64 %t130, i64 %t131)
  store i1 %t137, ptr %l101
  br label %bb34
bb33:
  store i1 false, ptr %l94, !tbaa !21
  br label %bb35
bb34:
  %t138 = load i1, ptr %l101, !tbaa !21
  store i1 %t138, ptr %l94, !tbaa !21
  br label %bb35
bb35:
  %t139 = load i1, ptr %l94, !tbaa !21
  store i1 %t139, ptr %rv
  br label %ret
bb36:
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t141 = load ptr, ptr %l1, !tbaa !29
  %t142 = load ptr, ptr %l7, !tbaa !29
  %t143 = load i64, ptr %l3, !tbaa !24
  %t144 = load i64, ptr %l4, !tbaa !24
  %t150 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2euePlace(ptr %v0, ptr %v1, ptr %v2, ptr %t140, ptr %t141, ptr %t142, i64 %t143, i64 %t144)
  store i1 %t150, ptr %l107
  br label %bb37
bb37:
  %t151 = load i1, ptr %l107, !tbaa !21
  br i1 %t151, label %bb38, label %bb39
bb38:
  %t152 = load ptr, ptr %l0, !tbaa !29
  %t153 = load ptr, ptr %l1, !tbaa !29
  %t154 = load ptr, ptr %l8, !tbaa !29
  %t156 = load i64, ptr %l3, !tbaa !24
  %t157 = load i64, ptr %l4, !tbaa !24
  %t163 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eueExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t152, ptr %t153, ptr %t154, i64 %t156, i64 %t157)
  store i1 %t163, ptr %l115
  br label %bb40
bb39:
  store i1 false, ptr %l108, !tbaa !21
  br label %bb41
bb40:
  %t164 = load i1, ptr %l115, !tbaa !21
  store i1 %t164, ptr %l108, !tbaa !21
  br label %bb41
bb41:
  %t165 = load i1, ptr %l108, !tbaa !21
  store i1 %t165, ptr %rv
  br label %ret
bb42:
  %t166 = load ptr, ptr %l2, !tbaa !29
  store ptr %t166, ptr %l116, !tbaa !29
  store i1 false, ptr %l117, !tbaa !21
  %t167 = load ptr, ptr %l116, !tbaa !29
  %t168 = icmp ne ptr %t167, null
  br i1 %t168, label %bb43, label %bb44
bb43:
  %t170 = load ptr, ptr %l116, !tbaa !29
  %t171 = load i64, ptr %t170, !range !{i64 0, i64 17}
  %t173 = icmp eq i64 %t171, 2
  store i1 %t173, ptr %l117, !tbaa !21
  br label %bb44
bb44:
  %t174 = load i1, ptr %l117, !tbaa !21
  br i1 %t174, label %bb45, label %bb46
bb45:
  %t175 = load ptr, ptr %l2, !tbaa !29
  %t177 = getelementptr { i64, [3 x i64] }, ptr %t175, i32 0, i32 1
  %t178 = getelementptr { %"compiler/source:Span", ptr }, ptr %t177, i32 0, i32 1
  %t179 = load ptr, ptr %t178
  store ptr %t179, ptr %l9, !tbaa !29
  br label %bb47
bb46:
  br label %bb49
bb47:
  %t181 = load ptr, ptr %l0, !tbaa !29
  %t182 = load ptr, ptr %l1, !tbaa !29
  %t183 = load ptr, ptr %l9, !tbaa !29
  %t185 = load i64, ptr %l3, !tbaa !24
  %t186 = load i64, ptr %l4, !tbaa !24
  %t192 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eueExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t181, ptr %t182, ptr %t183, i64 %t185, i64 %t186)
  store i1 %t192, ptr %l128
  br label %bb48
bb48:
  %t193 = load i1, ptr %l128, !tbaa !21
  store i1 %t193, ptr %rv
  br label %ret
bb49:
  %t194 = load ptr, ptr %l2, !tbaa !29
  store ptr %t194, ptr %l129, !tbaa !29
  store i1 false, ptr %l130, !tbaa !21
  %t195 = load ptr, ptr %l129, !tbaa !29
  %t196 = icmp ne ptr %t195, null
  br i1 %t196, label %bb50, label %bb51
bb50:
  %t198 = load ptr, ptr %l129, !tbaa !29
  %t199 = load i64, ptr %t198, !range !{i64 0, i64 17}
  %t201 = icmp eq i64 %t199, 3
  store i1 %t201, ptr %l130, !tbaa !21
  br label %bb51
bb51:
  %t202 = load i1, ptr %l130, !tbaa !21
  br i1 %t202, label %bb52, label %bb53
bb52:
  %t203 = load ptr, ptr %l2, !tbaa !29
  %t205 = getelementptr { i64, [3 x i64] }, ptr %t203, i32 0, i32 1
  %t206 = getelementptr { %"compiler/source:Span", ptr }, ptr %t205, i32 0, i32 1
  %t207 = load ptr, ptr %t206
  store ptr %t207, ptr %l10, !tbaa !29
  br label %bb54
bb53:
  br label %bb64
bb54:
  %t209 = load ptr, ptr %l0, !tbaa !29
  %t210 = load ptr, ptr %l1, !tbaa !29
  %t211 = load ptr, ptr %l10, !tbaa !29
  %t213 = getelementptr %"compiler/typed:If", ptr %t211, i32 0, i32 0
  %t214 = load ptr, ptr %t213, !tbaa !29
  %t216 = load i64, ptr %l3, !tbaa !24
  %t217 = load i64, ptr %l4, !tbaa !24
  %t223 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eueExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t209, ptr %t210, ptr %t214, i64 %t216, i64 %t217)
  store i1 %t223, ptr %l142
  br label %bb55
bb55:
  %t224 = load i1, ptr %l142, !tbaa !21
  br i1 %t224, label %bb56, label %bb57
bb56:
  %t225 = load ptr, ptr %l0, !tbaa !29
  %t226 = load ptr, ptr %l1, !tbaa !29
  %t227 = load ptr, ptr %l10, !tbaa !29
  %t229 = getelementptr %"compiler/typed:If", ptr %t227, i32 0, i32 1
  %t230 = load ptr, ptr %t229, !tbaa !29
  %t232 = load i64, ptr %l3, !tbaa !24
  %t233 = load i64, ptr %l4, !tbaa !24
  %t239 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eueBlock(ptr %v0, ptr %v1, ptr %v2, ptr %t225, ptr %t226, ptr %t230, i64 %t232, i64 %t233)
  store i1 %t239, ptr %l151
  br label %bb58
bb57:
  store i1 false, ptr %l143, !tbaa !21
  br label %bb59
bb58:
  %t240 = load i1, ptr %l151, !tbaa !21
  store i1 %t240, ptr %l143, !tbaa !21
  br label %bb59
bb59:
  %t241 = load i1, ptr %l143, !tbaa !21
  br i1 %t241, label %bb60, label %bb61
bb60:
  %t242 = load ptr, ptr %l0, !tbaa !29
  %t243 = load ptr, ptr %l1, !tbaa !29
  %t244 = load ptr, ptr %l10, !tbaa !29
  %t246 = getelementptr %"compiler/typed:If", ptr %t244, i32 0, i32 2
  %t247 = load ptr, ptr %t246, !tbaa !29
  %t248 = load i64, ptr %l3, !tbaa !24
  %t249 = load i64, ptr %l4, !tbaa !24
  %t255 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eueBlock(ptr %v0, ptr %v1, ptr %v2, ptr %t242, ptr %t243, ptr %t247, i64 %t248, i64 %t249)
  store i1 %t255, ptr %l159
  br label %bb62
bb61:
  store i1 false, ptr %l152, !tbaa !21
  br label %bb63
bb62:
  %t256 = load i1, ptr %l159, !tbaa !21
  store i1 %t256, ptr %l152, !tbaa !21
  br label %bb63
bb63:
  %t257 = load i1, ptr %l152, !tbaa !21
  store i1 %t257, ptr %rv
  br label %ret
bb64:
  %t258 = load ptr, ptr %l2, !tbaa !29
  store ptr %t258, ptr %l160, !tbaa !29
  store i1 false, ptr %l161, !tbaa !21
  %t259 = load ptr, ptr %l160, !tbaa !29
  %t260 = icmp ne ptr %t259, null
  br i1 %t260, label %bb65, label %bb66
bb65:
  %t262 = load ptr, ptr %l160, !tbaa !29
  %t263 = load i64, ptr %t262, !range !{i64 0, i64 17}
  %t265 = icmp eq i64 %t263, 4
  store i1 %t265, ptr %l161, !tbaa !21
  br label %bb66
bb66:
  %t266 = load i1, ptr %l161, !tbaa !21
  br i1 %t266, label %bb67, label %bb68
bb67:
  %t267 = load ptr, ptr %l2, !tbaa !29
  %t269 = getelementptr { i64, [3 x i64] }, ptr %t267, i32 0, i32 1
  %t270 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t269, i32 0, i32 1
  %t271 = load ptr, ptr %t270
  store ptr %t271, ptr %l11, !tbaa !29
  %t273 = load ptr, ptr %l2, !tbaa !29
  %t275 = getelementptr { i64, [3 x i64] }, ptr %t273, i32 0, i32 1
  %t276 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t275, i32 0, i32 2
  %t277 = load ptr, ptr %t276
  store ptr %t277, ptr %l12, !tbaa !29
  br label %bb69
bb68:
  br label %bb75
bb69:
  %t279 = load ptr, ptr %l0, !tbaa !29
  %t280 = load ptr, ptr %l1, !tbaa !29
  %t281 = load ptr, ptr %l11, !tbaa !29
  %t283 = load i64, ptr %l3, !tbaa !24
  %t284 = load i64, ptr %l4, !tbaa !24
  %t290 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eueBlock(ptr %v0, ptr %v1, ptr %v2, ptr %t279, ptr %t280, ptr %t281, i64 %t283, i64 %t284)
  store i1 %t290, ptr %l174
  br label %bb70
bb70:
  %t291 = load i1, ptr %l174, !tbaa !21
  br i1 %t291, label %bb71, label %bb72
bb71:
  %t292 = load ptr, ptr %l0, !tbaa !29
  %t293 = load ptr, ptr %l1, !tbaa !29
  %t294 = load ptr, ptr %l12, !tbaa !29
  %t295 = load i64, ptr %l3, !tbaa !24
  %t296 = load i64, ptr %l4, !tbaa !24
  %t302 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eueBlock(ptr %v0, ptr %v1, ptr %v2, ptr %t292, ptr %t293, ptr %t294, i64 %t295, i64 %t296)
  store i1 %t302, ptr %l181
  br label %bb73
bb72:
  store i1 false, ptr %l175, !tbaa !21
  br label %bb74
bb73:
  %t303 = load i1, ptr %l181, !tbaa !21
  store i1 %t303, ptr %l175, !tbaa !21
  br label %bb74
bb74:
  %t304 = load i1, ptr %l175, !tbaa !21
  store i1 %t304, ptr %rv
  br label %ret
bb75:
  %t305 = load ptr, ptr %l2, !tbaa !29
  store ptr %t305, ptr %l182, !tbaa !29
  store i1 false, ptr %l183, !tbaa !21
  %t306 = load ptr, ptr %l182, !tbaa !29
  %t307 = icmp ne ptr %t306, null
  br i1 %t307, label %bb76, label %bb77
bb76:
  %t309 = load ptr, ptr %l182, !tbaa !29
  %t310 = load i64, ptr %t309, !range !{i64 0, i64 17}
  %t312 = icmp eq i64 %t310, 6
  store i1 %t312, ptr %l183, !tbaa !21
  br label %bb77
bb77:
  %t313 = load i1, ptr %l183, !tbaa !21
  br i1 %t313, label %bb78, label %bb79
bb78:
  %t314 = load ptr, ptr %l2, !tbaa !29
  %t316 = getelementptr { i64, [3 x i64] }, ptr %t314, i32 0, i32 1
  %t317 = getelementptr { %"compiler/source:Span", ptr }, ptr %t316, i32 0, i32 1
  %t318 = load ptr, ptr %t317
  store ptr %t318, ptr %l13, !tbaa !29
  br label %bb84
bb79:
  %t320 = load ptr, ptr %l2, !tbaa !29
  store ptr %t320, ptr %l188, !tbaa !29
  store i1 false, ptr %l189, !tbaa !21
  %t321 = load ptr, ptr %l188, !tbaa !29
  %t322 = icmp ne ptr %t321, null
  br i1 %t322, label %bb80, label %bb81
bb80:
  %t324 = load ptr, ptr %l188, !tbaa !29
  %t325 = load i64, ptr %t324, !range !{i64 0, i64 17}
  %t327 = icmp eq i64 %t325, 16
  store i1 %t327, ptr %l189, !tbaa !21
  br label %bb81
bb81:
  %t328 = load i1, ptr %l189, !tbaa !21
  br i1 %t328, label %bb82, label %bb83
bb82:
  %t329 = load ptr, ptr %l2, !tbaa !29
  %t331 = getelementptr { i64, [3 x i64] }, ptr %t329, i32 0, i32 1
  %t332 = getelementptr { %"compiler/source:Span", ptr }, ptr %t331, i32 0, i32 1
  %t333 = load ptr, ptr %t332
  store ptr %t333, ptr %l13, !tbaa !29
  br label %bb84
bb83:
  br label %bb86
bb84:
  %t335 = load ptr, ptr %l0, !tbaa !29
  %t336 = load ptr, ptr %l1, !tbaa !29
  %t337 = load ptr, ptr %l13, !tbaa !29
  %t338 = load i64, ptr %l3, !tbaa !24
  %t339 = load i64, ptr %l4, !tbaa !24
  %t345 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eueExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t335, ptr %t336, ptr %t337, i64 %t338, i64 %t339)
  store i1 %t345, ptr %l199
  br label %bb85
bb85:
  %t346 = load i1, ptr %l199, !tbaa !21
  store i1 %t346, ptr %rv
  br label %ret
bb86:
  %t347 = load ptr, ptr %l2, !tbaa !29
  store ptr %t347, ptr %l200, !tbaa !29
  store i1 false, ptr %l201, !tbaa !21
  %t348 = load ptr, ptr %l200, !tbaa !29
  %t349 = icmp ne ptr %t348, null
  br i1 %t349, label %bb87, label %bb88
bb87:
  %t351 = load ptr, ptr %l200, !tbaa !29
  %t352 = load i64, ptr %t351, !range !{i64 0, i64 17}
  %t354 = icmp eq i64 %t352, 10
  store i1 %t354, ptr %l201, !tbaa !21
  br label %bb88
bb88:
  %t355 = load i1, ptr %l201, !tbaa !21
  br i1 %t355, label %bb89, label %bb90
bb89:
  %t356 = load ptr, ptr %l2, !tbaa !29
  %t358 = getelementptr { i64, [3 x i64] }, ptr %t356, i32 0, i32 1
  %t359 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t358, i32 0, i32 1
  %t360 = load ptr, ptr %t359
  store ptr %t360, ptr %l14, !tbaa !29
  %t362 = load ptr, ptr %l2, !tbaa !29
  %t364 = getelementptr { i64, [3 x i64] }, ptr %t362, i32 0, i32 1
  %t365 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t364, i32 0, i32 2
  %t366 = load ptr, ptr %t365
  store ptr %t366, ptr %l15, !tbaa !29
  br label %bb91
bb90:
  br label %bb97
bb91:
  %t368 = load ptr, ptr %l0, !tbaa !29
  %t369 = load ptr, ptr %l1, !tbaa !29
  %t370 = load ptr, ptr %l14, !tbaa !29
  %t372 = load i64, ptr %l3, !tbaa !24
  %t373 = load i64, ptr %l4, !tbaa !24
  %t379 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eueExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t368, ptr %t369, ptr %t370, i64 %t372, i64 %t373)
  store i1 %t379, ptr %l214
  br label %bb92
bb92:
  %t380 = load i1, ptr %l214, !tbaa !21
  br i1 %t380, label %bb93, label %bb94
bb93:
  %t381 = load ptr, ptr %l0, !tbaa !29
  %t382 = load ptr, ptr %l1, !tbaa !29
  %t383 = load ptr, ptr %l15, !tbaa !29
  %t384 = load i64, ptr %l3, !tbaa !24
  %t385 = load i64, ptr %l4, !tbaa !24
  %t391 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eueExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t381, ptr %t382, ptr %t383, i64 %t384, i64 %t385)
  store i1 %t391, ptr %l221
  br label %bb95
bb94:
  store i1 false, ptr %l215, !tbaa !21
  br label %bb96
bb95:
  %t392 = load i1, ptr %l221, !tbaa !21
  store i1 %t392, ptr %l215, !tbaa !21
  br label %bb96
bb96:
  %t393 = load i1, ptr %l215, !tbaa !21
  store i1 %t393, ptr %rv
  br label %ret
bb97:
  %t394 = load ptr, ptr %l2, !tbaa !29
  store ptr %t394, ptr %l222, !tbaa !29
  store i1 false, ptr %l223, !tbaa !21
  %t395 = load ptr, ptr %l222, !tbaa !29
  %t396 = icmp ne ptr %t395, null
  br i1 %t396, label %bb98, label %bb99
bb98:
  %t398 = load ptr, ptr %l222, !tbaa !29
  %t399 = load i64, ptr %t398, !range !{i64 0, i64 17}
  %t401 = icmp eq i64 %t399, 9
  store i1 %t401, ptr %l223, !tbaa !21
  br label %bb99
bb99:
  %t402 = load i1, ptr %l223, !tbaa !21
  br i1 %t402, label %bb100, label %bb101
bb100:
  %t403 = load ptr, ptr %l2, !tbaa !29
  %t405 = getelementptr { i64, [3 x i64] }, ptr %t403, i32 0, i32 1
  %t406 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t405, i32 0, i32 2
  %t407 = load ptr, ptr %t406
  store ptr %t407, ptr %l16, !tbaa !29
  br label %bb102
bb101:
  br label %bb104
bb102:
  %t409 = load ptr, ptr %l0, !tbaa !29
  %t410 = load ptr, ptr %l1, !tbaa !29
  %t411 = load ptr, ptr %l16, !tbaa !29
  %t412 = load i64, ptr %l3, !tbaa !24
  %t413 = load i64, ptr %l4, !tbaa !24
  %t419 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eueExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t409, ptr %t410, ptr %t411, i64 %t412, i64 %t413)
  store i1 %t419, ptr %l233
  br label %bb103
bb103:
  %t420 = load i1, ptr %l233, !tbaa !21
  store i1 %t420, ptr %rv
  br label %ret
bb104:
  %t421 = load ptr, ptr %l2, !tbaa !29
  store ptr %t421, ptr %l234, !tbaa !29
  store i1 false, ptr %l235, !tbaa !21
  %t422 = load ptr, ptr %l234, !tbaa !29
  %t423 = icmp ne ptr %t422, null
  br i1 %t423, label %bb105, label %bb106
bb105:
  %t425 = load ptr, ptr %l234, !tbaa !29
  %t426 = load i64, ptr %t425, !range !{i64 0, i64 17}
  %t428 = icmp eq i64 %t426, 11
  store i1 %t428, ptr %l235, !tbaa !21
  br label %bb106
bb106:
  %t429 = load i1, ptr %l235, !tbaa !21
  br i1 %t429, label %bb107, label %bb108
bb107:
  %t430 = load ptr, ptr %l2, !tbaa !29
  %t432 = getelementptr { i64, [3 x i64] }, ptr %t430, i32 0, i32 1
  %t433 = getelementptr { %"compiler/source:Span", ptr }, ptr %t432, i32 0, i32 1
  %t434 = load ptr, ptr %t433
  store ptr %t434, ptr %l17, !tbaa !29
  br label %bb109
bb108:
  br label %bb111
bb109:
  %t436 = load ptr, ptr %l0, !tbaa !29
  %t437 = load ptr, ptr %l1, !tbaa !29
  %t438 = load ptr, ptr %l17, !tbaa !29
  %t440 = load i64, ptr %l3, !tbaa !24
  %t441 = load i64, ptr %l4, !tbaa !24
  %t447 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eueBlock(ptr %v0, ptr %v1, ptr %v2, ptr %t436, ptr %t437, ptr %t438, i64 %t440, i64 %t441)
  store i1 %t447, ptr %l246
  br label %bb110
bb110:
  %t448 = load i1, ptr %l246, !tbaa !21
  store i1 %t448, ptr %rv
  br label %ret
bb111:
  %t449 = load ptr, ptr %l2, !tbaa !29
  store ptr %t449, ptr %l247, !tbaa !29
  store i1 false, ptr %l248, !tbaa !21
  %t450 = load ptr, ptr %l247, !tbaa !29
  %t451 = icmp ne ptr %t450, null
  br i1 %t451, label %bb112, label %bb113
bb112:
  %t453 = load ptr, ptr %l247, !tbaa !29
  %t454 = load i64, ptr %t453, !range !{i64 0, i64 17}
  %t456 = icmp eq i64 %t454, 12
  store i1 %t456, ptr %l248, !tbaa !21
  br label %bb113
bb113:
  %t457 = load i1, ptr %l248, !tbaa !21
  br i1 %t457, label %bb114, label %bb115
bb114:
  %t458 = load ptr, ptr %l2, !tbaa !29
  %t460 = getelementptr { i64, [3 x i64] }, ptr %t458, i32 0, i32 1
  %t461 = getelementptr { %"compiler/source:Span", ptr }, ptr %t460, i32 0, i32 1
  %t462 = load ptr, ptr %t461
  store ptr %t462, ptr %l18, !tbaa !29
  br label %bb116
bb115:
  br label %bb118
bb116:
  %t464 = load ptr, ptr %l0, !tbaa !29
  %t465 = load ptr, ptr %l1, !tbaa !29
  %t466 = load ptr, ptr %l18, !tbaa !29
  %t468 = load i64, ptr %l3, !tbaa !24
  %t469 = load i64, ptr %l4, !tbaa !24
  %t475 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eueBlock(ptr %v0, ptr %v1, ptr %v2, ptr %t464, ptr %t465, ptr %t466, i64 %t468, i64 %t469)
  store i1 %t475, ptr %l259
  br label %bb117
bb117:
  %t476 = load i1, ptr %l259, !tbaa !21
  store i1 %t476, ptr %rv
  br label %ret
bb118:
  %t477 = load ptr, ptr %l2, !tbaa !29
  store ptr %t477, ptr %l260, !tbaa !29
  store i1 false, ptr %l261, !tbaa !21
  %t478 = load ptr, ptr %l260, !tbaa !29
  %t479 = icmp ne ptr %t478, null
  br i1 %t479, label %bb119, label %bb120
bb119:
  %t481 = load ptr, ptr %l260, !tbaa !29
  %t482 = load i64, ptr %t481, !range !{i64 0, i64 17}
  %t484 = icmp eq i64 %t482, 13
  store i1 %t484, ptr %l261, !tbaa !21
  br label %bb120
bb120:
  %t485 = load i1, ptr %l261, !tbaa !21
  br i1 %t485, label %bb121, label %bb122
bb121:
  %t486 = load ptr, ptr %l2, !tbaa !29
  %t488 = getelementptr { i64, [3 x i64] }, ptr %t486, i32 0, i32 1
  %t489 = getelementptr { %"compiler/source:Span", ptr }, ptr %t488, i32 0, i32 1
  %t490 = load ptr, ptr %t489
  store ptr %t490, ptr %l19, !tbaa !29
  br label %bb123
bb122:
  br label %bb138
bb123:
  %t492 = load ptr, ptr %l0, !tbaa !29
  %t493 = load ptr, ptr %l1, !tbaa !29
  %t494 = load ptr, ptr %l19, !tbaa !29
  %t496 = getelementptr %"compiler/typed:Join", ptr %t494, i32 0, i32 0
  %t497 = load ptr, ptr %t496, !tbaa !29
  %t499 = load i64, ptr %l3, !tbaa !24
  %t500 = load i64, ptr %l4, !tbaa !24
  %t506 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eueBlock(ptr %v0, ptr %v1, ptr %v2, ptr %t492, ptr %t493, ptr %t497, i64 %t499, i64 %t500)
  store i1 %t506, ptr %l273
  br label %bb124
bb124:
  %t507 = load i1, ptr %l273, !tbaa !21
  %t508 = xor i1 %t507, true
  br i1 %t508, label %bb125, label %bb126
bb125:
  store i1 false, ptr %rv
  br label %ret
bb126:
  br label %bb127
bb127:
  %t511 = load ptr, ptr %l19, !tbaa !29
  %t513 = getelementptr %"compiler/typed:Join", ptr %t511, i32 0, i32 2
  %t514 = load { i64, ptr }, ptr %t513, !tbaa !27
  store { i64, ptr } %t514, ptr %l20, !tbaa !27
  store i64 0, ptr %l21, !tbaa !24
  %t516 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t518 = extractvalue { i64, ptr } %t516, 0
  store i64 %t518, ptr %l22, !tbaa !24
  br label %bb128
bb128:
  %t520 = load i64, ptr %l21, !tbaa !24
  %t521 = load i64, ptr %l22, !tbaa !24
  %t524 = icmp slt i64 %t520, %t521
  %t526 = xor i1 %t524, true
  br i1 %t526, label %bb129, label %bb130
bb129:
  br label %bb137
bb130:
  br label %bb131
bb131:
  %t528 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t528, ptr %l284, !tbaa !27
  %t529 = load i64, ptr %l21, !tbaa !24
  %t531 = getelementptr { i64, ptr }, ptr %l284, i32 0, i32 1
  %t532 = load ptr, ptr %t531, !tbaa !27
  %t533 = getelementptr ptr, ptr %t532, i64 %t529
  %t534 = load ptr, ptr %t533, !tbaa !39
  %t536 = load ptr, ptr %l0, !tbaa !29
  %t537 = load ptr, ptr %l1, !tbaa !29
  %t540 = getelementptr %"compiler/typed:Clause", ptr %t534, i32 0, i32 3
  %t541 = load ptr, ptr %t540, !tbaa !29
  %t542 = load i64, ptr %l3, !tbaa !24
  %t543 = load i64, ptr %l4, !tbaa !24
  %t549 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eueBlock(ptr %v0, ptr %v1, ptr %v2, ptr %t536, ptr %t537, ptr %t541, i64 %t542, i64 %t543)
  store i1 %t549, ptr %l293
  br label %bb132
bb132:
  %t550 = load i1, ptr %l293, !tbaa !21
  %t551 = xor i1 %t550, true
  br i1 %t551, label %bb133, label %bb134
bb133:
  store i1 false, ptr %rv
  br label %ret
bb134:
  br label %bb135
bb135:
  br label %bb136
bb136:
  %t554 = load i64, ptr %l21, !tbaa !24
  %t557 = add i64 %t554, 1
  store i64 %t557, ptr %l21, !tbaa !24
  br label %bb128
bb137:
  store i1 true, ptr %rv
  br label %ret
bb138:
  %t560 = load ptr, ptr %l2, !tbaa !29
  store ptr %t560, ptr %l300, !tbaa !29
  store i1 false, ptr %l301, !tbaa !21
  %t561 = load ptr, ptr %l300, !tbaa !29
  %t562 = icmp ne ptr %t561, null
  br i1 %t562, label %bb139, label %bb140
bb139:
  %t564 = load ptr, ptr %l300, !tbaa !29
  %t565 = load i64, ptr %t564, !range !{i64 0, i64 17}
  %t567 = icmp eq i64 %t565, 14
  store i1 %t567, ptr %l301, !tbaa !21
  br label %bb140
bb140:
  %t568 = load i1, ptr %l301, !tbaa !21
  br i1 %t568, label %bb141, label %bb142
bb141:
  %t569 = load ptr, ptr %l2, !tbaa !29
  %t571 = getelementptr { i64, [3 x i64] }, ptr %t569, i32 0, i32 1
  %t572 = getelementptr { %"compiler/source:Span", ptr }, ptr %t571, i32 0, i32 1
  %t573 = load ptr, ptr %t572
  store ptr %t573, ptr %l24, !tbaa !29
  br label %bb143
bb142:
  br label %bb177
bb143:
  store %olang.scope zeroinitializer, ptr %s20
  %t575 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s20, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t575, ptr %l306
  br label %bb144
bb144:
  %t576 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l306
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t576, ptr %l25
  %t577 = load ptr, ptr %l0, !tbaa !29
  %t578 = load ptr, ptr %l24, !tbaa !29
  %t580 = getelementptr %"compiler/typed:Spawn", ptr %t578, i32 0, i32 1
  %t581 = load ptr, ptr %t580, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecarried(ptr %v0, ptr %v2, ptr %s20, ptr %t577, ptr %t581, ptr %l25)
  br label %bb145
bb145:
  %t586 = load i64, ptr %l3, !tbaa !24
  %t589 = call i1 @compiler_2fscope_2eflHas(ptr %s20, ptr %l25, i64 %t586)
  store i1 %t589, ptr %l314
  br label %bb146
bb146:
  %t590 = load i1, ptr %l314, !tbaa !21
  br i1 %t590, label %bb147, label %bb148
bb147:
  call void @__olang_scope_close(ptr %s20)
  store i1 false, ptr %rv
  br label %ret
bb148:
  br label %bb149
bb149:
  %t592 = load ptr, ptr %l24, !tbaa !29
  %t594 = getelementptr %"compiler/typed:Spawn", ptr %t592, i32 0, i32 0
  %t595 = load { i64, ptr }, ptr %t594, !tbaa !27
  store { i64, ptr } %t595, ptr %l26, !tbaa !27
  store i64 0, ptr %l27, !tbaa !24
  %t597 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t599 = extractvalue { i64, ptr } %t597, 0
  store i64 %t599, ptr %l28, !tbaa !24
  br label %bb150
bb150:
  %t601 = load i64, ptr %l27, !tbaa !24
  %t602 = load i64, ptr %l28, !tbaa !24
  %t605 = icmp slt i64 %t601, %t602
  %t607 = xor i1 %t605, true
  br i1 %t607, label %bb151, label %bb152
bb151:
  br label %bb162
bb152:
  br label %bb153
bb153:
  %t609 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t609, ptr %l324, !tbaa !27
  %t610 = load i64, ptr %l27, !tbaa !24
  %t612 = getelementptr { i64, ptr }, ptr %l324, i32 0, i32 1
  %t613 = load ptr, ptr %t612, !tbaa !27
  %t614 = getelementptr ptr, ptr %t613, i64 %t610
  %t615 = load ptr, ptr %t614, !tbaa !39
  store ptr %t615, ptr %l29, !tbaa !29
  %t617 = load ptr, ptr %l29, !tbaa !29
  %t619 = icmp eq ptr %t617, null
  br i1 %t619, label %bb154, label %bb155
bb154:
  br label %bb161
bb155:
  br label %bb156
bb156:
  %t621 = load ptr, ptr %l0, !tbaa !29
  %t622 = load ptr, ptr %l1, !tbaa !29
  %t623 = load ptr, ptr %l29, !tbaa !29
  %t624 = load i64, ptr %l3, !tbaa !24
  %t625 = load i64, ptr %l4, !tbaa !24
  %t631 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2euePlace(ptr %v0, ptr %v1, ptr %v2, ptr %t621, ptr %t622, ptr %t623, i64 %t624, i64 %t625)
  store i1 %t631, ptr %l334
  br label %bb157
bb157:
  %t632 = load i1, ptr %l334, !tbaa !21
  %t633 = xor i1 %t632, true
  br i1 %t633, label %bb158, label %bb159
bb158:
  call void @__olang_scope_close(ptr %s20)
  store i1 false, ptr %rv
  br label %ret
bb159:
  br label %bb160
bb160:
  br label %bb161
bb161:
  %t636 = load i64, ptr %l27, !tbaa !24
  %t639 = add i64 %t636, 1
  store i64 %t639, ptr %l27, !tbaa !24
  br label %bb150
bb162:
  %t641 = load ptr, ptr %l0, !tbaa !29
  %t642 = load ptr, ptr %l1, !tbaa !29
  %t643 = load ptr, ptr %l24, !tbaa !29
  %t645 = getelementptr %"compiler/typed:Spawn", ptr %t643, i32 0, i32 1
  %t646 = load ptr, ptr %t645, !tbaa !29
  %t648 = load i64, ptr %l3, !tbaa !24
  %t649 = load i64, ptr %l4, !tbaa !24
  %t655 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eueExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t641, ptr %t642, ptr %t646, i64 %t648, i64 %t649)
  store i1 %t655, ptr %l347
  br label %bb163
bb163:
  %t656 = load i1, ptr %l347, !tbaa !21
  %t657 = xor i1 %t656, true
  br i1 %t657, label %bb164, label %bb165
bb164:
  call void @__olang_scope_close(ptr %s20)
  store i1 false, ptr %rv
  br label %ret
bb165:
  br label %bb166
bb166:
  %t660 = load ptr, ptr %l24, !tbaa !29
  %t662 = getelementptr %"compiler/typed:Spawn", ptr %t660, i32 0, i32 2
  %t663 = load { i64, ptr }, ptr %t662, !tbaa !27
  store { i64, ptr } %t663, ptr %l30, !tbaa !27
  store i64 0, ptr %l31, !tbaa !24
  %t665 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t667 = extractvalue { i64, ptr } %t665, 0
  store i64 %t667, ptr %l32, !tbaa !24
  br label %bb167
bb167:
  %t669 = load i64, ptr %l31, !tbaa !24
  %t670 = load i64, ptr %l32, !tbaa !24
  %t673 = icmp slt i64 %t669, %t670
  %t675 = xor i1 %t673, true
  br i1 %t675, label %bb168, label %bb169
bb168:
  br label %bb176
bb169:
  br label %bb170
bb170:
  %t677 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t677, ptr %l358, !tbaa !27
  %t678 = load i64, ptr %l31, !tbaa !24
  %t680 = getelementptr { i64, ptr }, ptr %l358, i32 0, i32 1
  %t681 = load ptr, ptr %t680, !tbaa !27
  %t682 = getelementptr ptr, ptr %t681, i64 %t678
  %t683 = load ptr, ptr %t682, !tbaa !39
  %t685 = load ptr, ptr %l0, !tbaa !29
  %t686 = load ptr, ptr %l1, !tbaa !29
  %t689 = getelementptr %"compiler/typed:TaskClause", ptr %t683, i32 0, i32 3
  %t690 = load ptr, ptr %t689, !tbaa !29
  %t691 = load i64, ptr %l3, !tbaa !24
  %t692 = load i64, ptr %l4, !tbaa !24
  %t698 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eueExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t685, ptr %t686, ptr %t690, i64 %t691, i64 %t692)
  store i1 %t698, ptr %l367
  br label %bb171
bb171:
  %t699 = load i1, ptr %l367, !tbaa !21
  %t700 = xor i1 %t699, true
  br i1 %t700, label %bb172, label %bb173
bb172:
  call void @__olang_scope_close(ptr %s20)
  store i1 false, ptr %rv
  br label %ret
bb173:
  br label %bb174
bb174:
  br label %bb175
bb175:
  %t703 = load i64, ptr %l31, !tbaa !24
  %t706 = add i64 %t703, 1
  store i64 %t706, ptr %l31, !tbaa !24
  br label %bb167
bb176:
  call void @__olang_scope_close(ptr %s20)
  store i1 true, ptr %rv
  br label %ret
bb177:
  %t709 = load ptr, ptr %l2, !tbaa !29
  store ptr %t709, ptr %l374, !tbaa !29
  store i1 false, ptr %l375, !tbaa !21
  %t710 = load ptr, ptr %l374, !tbaa !29
  %t711 = icmp ne ptr %t710, null
  br i1 %t711, label %bb178, label %bb179
bb178:
  %t713 = load ptr, ptr %l374, !tbaa !29
  %t714 = load i64, ptr %t713, !range !{i64 0, i64 17}
  %t716 = icmp eq i64 %t714, 15
  store i1 %t716, ptr %l375, !tbaa !21
  br label %bb179
bb179:
  %t717 = load i1, ptr %l375, !tbaa !21
  br i1 %t717, label %bb180, label %bb181
bb180:
  %t718 = load ptr, ptr %l2, !tbaa !29
  %t720 = getelementptr { i64, [3 x i64] }, ptr %t718, i32 0, i32 1
  %t721 = getelementptr { %"compiler/source:Span", ptr }, ptr %t720, i32 0, i32 1
  %t722 = load ptr, ptr %t721
  store ptr %t722, ptr %l34, !tbaa !29
  br label %bb182
bb181:
  br label %bb184
bb182:
  %t724 = load ptr, ptr %l0, !tbaa !29
  %t725 = load ptr, ptr %l1, !tbaa !29
  %t726 = load ptr, ptr %l34, !tbaa !29
  %t728 = load i64, ptr %l3, !tbaa !24
  %t729 = load i64, ptr %l4, !tbaa !24
  %t735 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eueExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t724, ptr %t725, ptr %t726, i64 %t728, i64 %t729)
  store i1 %t735, ptr %l386
  br label %bb183
bb183:
  %t736 = load i1, ptr %l386, !tbaa !21
  store i1 %t736, ptr %rv
  br label %ret
bb184:
  br i1 true, label %bb185, label %bb186
bb185:
  br label %bb187
bb186:
  br label %bb188
bb187:
  store i1 true, ptr %rv
  br label %ret
bb188:
  call void @__olang_check_failed(ptr @olang_loc_32fd86c1b7051b0e_a69c29150a84755a)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2evarScopeName(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca { i64, [1 x i64] }
  %l4 = alloca i32
  %l7 = alloca i1
  %l8 = alloca i64
  %l11 = alloca i64
  %l13 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca { i64, ptr }
  %l20 = alloca { i64, [1 x i64] }
  %l21 = alloca { i64, ptr }
  %l28 = alloca ptr
  %l33 = alloca %"compiler/typed:Local"
  %l35 = alloca { i64, ptr }
  %l44 = alloca i64
  %l47 = alloca { i64, ptr }
  %l48 = alloca { i64, ptr }
  %l50 = alloca { i64, ptr }
  %l56 = alloca i1
  %l59 = alloca { i64, ptr }
  %l60 = alloca { i64, ptr }
  %l62 = alloca { i64, ptr }
  %l64 = alloca { i64, ptr }
  %l66 = alloca i64
  %l67 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l2, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb4
bb2:
  %t5 = load i64, ptr %l2, !tbaa !24
  store i64 %t5, ptr %l8, !tbaa !24
  %t6 = load ptr, ptr %l1, !tbaa !29
  %t8 = getelementptr %"compiler/typed:Body", ptr %t6, i32 0, i32 6
  %t10 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScopeVar_3e_2eLen_3ccompiler_2ftyped_3aScopeVar_3e(ptr %v1, ptr %t8)
  store i64 %t10, ptr %l11
  br label %bb3
bb3:
  %t11 = load i64, ptr %l8, !tbaa !24
  %t12 = load i64, ptr %l11, !tbaa !24
  %t13 = icmp sge i64 %t11, %t12
  store i1 %t13, ptr %l7, !tbaa !21
  br label %bb4
bb4:
  %t15 = load i1, ptr %l7, !tbaa !21
  br i1 %t15, label %bb5, label %bb6
bb5:
  store { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d62, i32 0, i32 1) }, ptr %l13, !tbaa !27
  %t16 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t16, ptr %l14, !tbaa !27
  %t17 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t18 = extractvalue { i64, ptr } %t17, 0
  store i64 %t18, ptr %l15, !tbaa !24
  %t19 = load i64, ptr %l15, !tbaa !24
  %t20 = mul i64 %t19, 1
  %t21 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t20)
  %t22 = insertvalue { i64, ptr } undef, i64 %t19, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t21, 1
  store { i64, ptr } %t23, ptr %l16, !tbaa !27
  %t24 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = load i64, ptr %l15, !tbaa !24
  %t29 = mul i64 %t28, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t25, ptr %t27, i64 %t29, i1 false)
  %t30 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t30, ptr %l14, !tbaa !27
  %t31 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t31, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t32 = load ptr, ptr %l1, !tbaa !29
  %t34 = getelementptr %"compiler/typed:Body", ptr %t32, i32 0, i32 6
  %t35 = load i64, ptr %l2, !tbaa !24
  %t38 = call { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScopeVar_3e_2eAt_3ccompiler_2ftyped_3aScopeVar_3e(ptr %v1, ptr %t34, i64 %t35)
  store { i64, [1 x i64] } %t38, ptr %l20
  br label %bb8
bb8:
  %t39 = load { i64, [1 x i64] }, ptr %l20
  store { i64, [1 x i64] } %t39, ptr %l3
  %t40 = load { i64, [1 x i64] }, ptr %l3
  %t42 = extractvalue { i64, [1 x i64] } %t40, 0
  %t43 = icmp eq i64 %t42, 0
  br i1 %t43, label %bb9, label %bb10
bb9:
  %t45 = getelementptr { i64, [1 x i64] }, ptr %l3, i32 0, i32 1
  %t46 = getelementptr { i32 }, ptr %t45, i32 0, i32 0
  %t47 = load i32, ptr %t46
  store i32 %t47, ptr %l4, !tbaa !23
  br label %bb11
bb10:
  br label %bb14
bb11:
  store %olang.scope zeroinitializer, ptr %s2
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/scope:Scoper", ptr %t49, i32 0, i32 0
  %t52 = load ptr, ptr %t51, !tbaa !29
  %t54 = getelementptr %"compiler/generic:Program", ptr %t52, i32 0, i32 0
  %t55 = load ptr, ptr %t54, !tbaa !29
  %t57 = getelementptr %"compiler/load:Loader", ptr %t55, i32 0, i32 3
  %t58 = load ptr, ptr %t57, !tbaa !29
  store ptr %t58, ptr %l28, !tbaa !29
  %t59 = load ptr, ptr %l1, !tbaa !29
  %t61 = getelementptr %"compiler/typed:Body", ptr %t59, i32 0, i32 7
  %t62 = load i32, ptr %l4, !tbaa !23
  %t64 = sext i32 %t62 to i64
  %t67 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v1, ptr %t61, i64 %t64)
  store %"compiler/typed:Local" %t67, ptr %l33
  br label %bb12
bb12:
  %t68 = getelementptr %"compiler/typed:Local", ptr %l33, i32 0, i32 0
  %t69 = load i32, ptr %t68, !tbaa !23
  %t70 = load ptr, ptr %l28, !tbaa !29
  %t72 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %s2, ptr %t70, i32 %t69)
  store { i64, ptr } %t72, ptr %l35
  br label %bb13
bb13:
  %t73 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d63, i32 0, i32 1) }, 1
  %t74 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d63, i32 0, i32 1) }, 0
  %t75 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t76 = extractvalue { i64, ptr } %t75, 1
  %t77 = extractvalue { i64, ptr } %t75, 0
  %t78 = add i64 %t74, %t77
  %t79 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d64, i32 0, i32 1) }, 1
  %t80 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d64, i32 0, i32 1) }, 0
  %t81 = add i64 %t78, %t80
  %t82 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t81)
  call void @olang_textcopy(ptr %t82, ptr %t73, i64 %t74)
  %t83 = getelementptr i8, ptr %t82, i64 %t74
  call void @olang_textcopy(ptr %t83, ptr %t76, i64 %t77)
  %t84 = getelementptr i8, ptr %t83, i64 %t77
  call void @olang_textcopy(ptr %t84, ptr %t79, i64 %t80)
  %t85 = insertvalue { i64, ptr } undef, i64 %t81, 0
  %t86 = insertvalue { i64, ptr } %t85, ptr %t82, 1
  store { i64, ptr } %t86, ptr %l21, !tbaa !27
  call void @__olang_scope_close(ptr %s2)
  br label %bb37
bb14:
  %t88 = load { i64, [1 x i64] }, ptr %l3
  %t90 = extractvalue { i64, [1 x i64] } %t88, 0
  %t91 = icmp eq i64 %t90, 1
  br i1 %t91, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb22
bb17:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/scope:Scoper", ptr %t93, i32 0, i32 0
  %t96 = load ptr, ptr %t95, !tbaa !29
  %t98 = getelementptr %"compiler/generic:Program", ptr %t96, i32 0, i32 2
  %t99 = load ptr, ptr %l1, !tbaa !29
  %t101 = getelementptr %"compiler/typed:Body", ptr %t99, i32 0, i32 2
  %t102 = load i32, ptr %t101, !tbaa !23
  %t105 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRole(ptr %v0, ptr %t98, i32 %t102)
  store i64 %t105, ptr %l44
  br label %bb18
bb18:
  %t106 = load i64, ptr @G_2ecompiler_2ftypes_2eRoleTail, !tbaa !24
  %t107 = load i64, ptr %l44, !tbaa !24
  %t109 = icmp eq i64 %t107, %t106
  br i1 %t109, label %bb19, label %bb20
bb19:
  store { i64, ptr } { i64 34, ptr getelementptr inbounds (<{ i64, [34 x i8] }>, ptr @.d65, i32 0, i32 1) }, ptr %l48, !tbaa !27
  %t111 = load { i64, ptr }, ptr %l48, !tbaa !27
  store { i64, ptr } %t111, ptr %l47, !tbaa !27
  br label %bb21
bb20:
  store { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d66, i32 0, i32 1) }, ptr %l50, !tbaa !27
  %t113 = load { i64, ptr }, ptr %l50, !tbaa !27
  store { i64, ptr } %t113, ptr %l47, !tbaa !27
  br label %bb21
bb21:
  %t115 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } %t115, ptr %l21, !tbaa !27
  br label %bb37
bb22:
  %t116 = load { i64, [1 x i64] }, ptr %l3
  %t118 = extractvalue { i64, [1 x i64] } %t116, 0
  %t119 = icmp eq i64 %t118, 4
  br i1 %t119, label %bb23, label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb32
bb25:
  %t121 = load ptr, ptr %l1, !tbaa !29
  %t123 = getelementptr %"compiler/typed:Body", ptr %t121, i32 0, i32 14
  %t124 = load i1, ptr %t123, !tbaa !21
  br i1 %t124, label %bb26, label %bb27
bb26:
  %t126 = load ptr, ptr %l1, !tbaa !29
  %t128 = getelementptr %"compiler/typed:Body", ptr %t126, i32 0, i32 16
  %t129 = load i1, ptr %t128, !tbaa !21
  store i1 %t129, ptr %l56, !tbaa !21
  br label %bb28
bb27:
  store i1 false, ptr %l56, !tbaa !21
  br label %bb28
bb28:
  %t131 = load i1, ptr %l56, !tbaa !21
  br i1 %t131, label %bb29, label %bb30
bb29:
  store { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d67, i32 0, i32 1) }, ptr %l60, !tbaa !27
  %t132 = load { i64, ptr }, ptr %l60, !tbaa !27
  store { i64, ptr } %t132, ptr %l59, !tbaa !27
  br label %bb31
bb30:
  store { i64, ptr } { i64 37, ptr getelementptr inbounds (<{ i64, [37 x i8] }>, ptr @.d68, i32 0, i32 1) }, ptr %l62, !tbaa !27
  %t134 = load { i64, ptr }, ptr %l62, !tbaa !27
  store { i64, ptr } %t134, ptr %l59, !tbaa !27
  br label %bb31
bb31:
  %t136 = load { i64, ptr }, ptr %l59, !tbaa !27
  store { i64, ptr } %t136, ptr %l21, !tbaa !27
  br label %bb37
bb32:
  br i1 true, label %bb33, label %bb34
bb33:
  br label %bb35
bb34:
  br label %bb36
bb35:
  store { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d69, i32 0, i32 1) }, ptr %l64, !tbaa !27
  %t137 = load { i64, ptr }, ptr %l64, !tbaa !27
  store { i64, ptr } %t137, ptr %l21, !tbaa !27
  br label %bb37
bb36:
  call void @__olang_check_failed(ptr @olang_loc_dc77515c192c1e2e_10e0daed47a736f2)
  unreachable
bb37:
  %t139 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t140 = extractvalue { i64, ptr } %t139, 0
  store i64 %t140, ptr %l66, !tbaa !24
  %t141 = load i64, ptr %l66, !tbaa !24
  %t142 = mul i64 %t141, 1
  %t143 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t142)
  %t144 = insertvalue { i64, ptr } undef, i64 %t141, 0
  %t145 = insertvalue { i64, ptr } %t144, ptr %t143, 1
  store { i64, ptr } %t145, ptr %l67, !tbaa !27
  %t146 = getelementptr { i64, ptr }, ptr %l67, i32 0, i32 1
  %t147 = load ptr, ptr %t146, !tbaa !27
  %t148 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t149 = load ptr, ptr %t148, !tbaa !27
  %t150 = load i64, ptr %l66, !tbaa !24
  %t151 = mul i64 %t150, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t147, ptr %t149, i64 %t151, i1 false)
  %t152 = load { i64, ptr }, ptr %l67, !tbaa !27
  store { i64, ptr } %t152, ptr %l21, !tbaa !27
  %t153 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t153, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eviewInit(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i32
  %l10 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 48
  %t7 = call { i32, ptr } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_H68cd31c3dbcdb47f3349b834dda1e07d(ptr %v0, ptr %v0, ptr %t3, i64 %a1)
  %t8 = extractvalue { i32, ptr } %t7, 1
  %t9 = extractvalue { i32, ptr } %t7, 0
  store i32 %t9, ptr %l8
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb2, label %ok.11, !prof !99
ok.11:
  store ptr %t8, ptr %l7
  br label %bb1
bb1:
  %t12 = load ptr, ptr %l7, !tbaa !29
  store ptr %t12, ptr %l3, !tbaa !29
  br label %bb4
bb2:
  br label %bb3
bb3:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb4:
  %t14 = load ptr, ptr %l3, !tbaa !29
  %t15 = load ptr, ptr %l0, !tbaa !29
  store ptr %t15, ptr %l10, !tbaa !29
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t21 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunAway(ptr %v0, ptr %v0, ptr %s0, ptr %t16, ptr %t14)
  store ptr %t21, ptr %l14
  br label %bb5
bb5:
  %t22 = load ptr, ptr %l14, !tbaa !29
  %t23 = call ptr @compiler_2fscope_2eunPassed(ptr %s0, ptr %s0, ptr %t22)
  store ptr %t23, ptr %l15
  br label %bb6
bb6:
  %t24 = load ptr, ptr %l10, !tbaa !29
  %t25 = load ptr, ptr %l15, !tbaa !29
  %t26 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eviewCall(ptr %v0, ptr %s0, ptr %t24, ptr %t25)
  store i64 %t26, ptr %l16
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s0)
  %t27 = load i64, ptr %l16, !tbaa !24
  store i64 %t27, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eviewSource(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l13 = alloca i64
  %l16 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i32
  %l23 = alloca ptr
  %l27 = alloca ptr
  %l28 = alloca ptr
  %l29 = alloca i64
  %l35 = alloca i64
  %l39 = alloca i64
  %l42 = alloca i64
  %l62 = alloca i1
  %l63 = alloca i64
  %l66 = alloca i64
  %l72 = alloca i1
  %l73 = alloca i64
  %l77 = alloca i64
  %l78 = alloca i32
  %l82 = alloca i64
  %l84 = alloca i64
  %l86 = alloca ptr
  %l90 = alloca i64
  %l91 = alloca i64
  %l92 = alloca i32
  %l96 = alloca i64
  %l100 = alloca i64
  %l104 = alloca i64
  %l108 = alloca i64
  %l114 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t5 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eviewRoot(ptr %v0, ptr %v1, ptr %t1, ptr %t2)
  store i64 %t5, ptr %l13
  br label %bb1
bb1:
  %t6 = load i64, ptr %l13, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  %t7 = load i64, ptr %l2, !tbaa !24
  %t9 = icmp sge i64 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/scope:Scoper", ptr %t11, i32 0, i32 82
  %t14 = load i64, ptr %l2, !tbaa !24
  %t17 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t13, i64 %t14)
  %t18 = extractvalue { i32, i64 } %t17, 1
  %t19 = extractvalue { i32, i64 } %t17, 0
  store i32 %t19, ptr %l21
  %t20 = icmp ne i32 %t19, 0
  br i1 %t20, label %bb5, label %ok.21, !prof !99
ok.21:
  store i64 %t18, ptr %l20
  br label %bb4
bb3:
  br label %bb8
bb4:
  %t22 = load i64, ptr %l20, !tbaa !24
  store i64 %t22, ptr %l16, !tbaa !24
  br label %bb7
bb5:
  br label %bb6
bb6:
  %t23 = load i64, ptr %l2, !tbaa !24
  store i64 %t23, ptr %l16, !tbaa !24
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s0)
  %t25 = load i64, ptr %l16, !tbaa !24
  store i64 %t25, ptr %rv
  br label %ret
bb8:
  %t26 = load ptr, ptr %l0, !tbaa !29
  store ptr %t26, ptr %l23, !tbaa !29
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load ptr, ptr %l1, !tbaa !29
  %t32 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunAway(ptr %v0, ptr %v1, ptr %s0, ptr %t27, ptr %t28)
  store ptr %t32, ptr %l27
  br label %bb9
bb9:
  %t33 = load ptr, ptr %l27, !tbaa !29
  %t34 = call ptr @compiler_2fscope_2eunPassed(ptr %s0, ptr %s0, ptr %t33)
  store ptr %t34, ptr %l28
  br label %bb10
bb10:
  %t35 = load ptr, ptr %l23, !tbaa !29
  %t36 = load ptr, ptr %l28, !tbaa !29
  %t37 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eviewCall(ptr %v0, ptr %s0, ptr %t35, ptr %t36)
  store i64 %t37, ptr %l29
  br label %bb11
bb11:
  %t38 = load i64, ptr %l29, !tbaa !24
  store i64 %t38, ptr %l3, !tbaa !24
  %t39 = load i64, ptr %l3, !tbaa !24
  %t41 = icmp sge i64 %t39, 0
  br i1 %t41, label %bb12, label %bb13
bb12:
  %t43 = load i64, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t43, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t46 = load ptr, ptr %l1, !tbaa !29
  %t49 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ewholeRoot(ptr %v0, ptr %v1, ptr %t45, ptr %t46)
  store i64 %t49, ptr %l35
  br label %bb15
bb15:
  %t50 = load i64, ptr %l35, !tbaa !24
  store i64 %t50, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  store i64 16, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t51 = load i64, ptr %l6, !tbaa !24
  %t52 = load i64, ptr %l5, !tbaa !24
  %t55 = icmp sgt i64 %t51, %t52
  br i1 %t55, label %bb16, label %bb17
bb16:
  %t57 = load i64, ptr %l7, !tbaa !24
  %t59 = icmp sgt i64 %t57, 0
  br i1 %t59, label %bb18, label %bb19
bb17:
  store i64 0, ptr %l39, !tbaa !24
  br label %bb21
bb18:
  %t61 = load i64, ptr %l6, !tbaa !24
  %t62 = load i64, ptr %l5, !tbaa !24
  %t65 = sub i64 %t61, %t62
  %t66 = load i64, ptr %l7, !tbaa !24
  %t69 = add i64 %t65, %t66
  %t71 = sub i64 %t69, 1
  %t72 = load i64, ptr %l7, !tbaa !24
  %t75 = sdiv i64 %t71, %t72
  store i64 %t75, ptr %l42, !tbaa !24
  br label %bb20
bb19:
  store i64 0, ptr %l42, !tbaa !24
  br label %bb20
bb20:
  %t77 = load i64, ptr %l42, !tbaa !24
  store i64 %t77, ptr %l39, !tbaa !24
  br label %bb21
bb21:
  %t78 = load i64, ptr %l39, !tbaa !24
  store i64 %t78, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb22
bb22:
  %t79 = load i64, ptr %l9, !tbaa !24
  %t80 = load i64, ptr %l8, !tbaa !24
  %t83 = icmp slt i64 %t79, %t80
  %t85 = xor i1 %t83, true
  br i1 %t85, label %bb23, label %bb24
bb23:
  br label %bb62
bb24:
  br label %bb25
bb25:
  %t87 = load i64, ptr %l5, !tbaa !24
  %t88 = load i64, ptr %l9, !tbaa !24
  %t89 = load i64, ptr %l7, !tbaa !24
  %t92 = mul i64 %t88, %t89
  %t95 = add i64 %t87, %t92
  store i64 %t95, ptr %l10, !tbaa !24
  %t97 = load i64, ptr %l4, !tbaa !24
  %t99 = icmp slt i64 %t97, 0
  br i1 %t99, label %bb26, label %bb27
bb26:
  store i1 true, ptr %l62, !tbaa !21
  br label %bb29
bb27:
  %t101 = load i64, ptr %l4, !tbaa !24
  store i64 %t101, ptr %l63, !tbaa !24
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = getelementptr %"compiler/scope:Scoper", ptr %t102, i32 0, i32 212
  %t106 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t104)
  store i64 %t106, ptr %l66
  br label %bb28
bb28:
  %t107 = load i64, ptr %l63, !tbaa !24
  %t108 = load i64, ptr %l66, !tbaa !24
  %t109 = icmp sge i64 %t107, %t108
  store i1 %t109, ptr %l62, !tbaa !21
  br label %bb29
bb29:
  %t111 = load i1, ptr %l62, !tbaa !21
  br i1 %t111, label %bb30, label %bb31
bb30:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb31:
  br label %bb32
bb32:
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t115 = getelementptr %"compiler/scope:Scoper", ptr %t113, i32 0, i32 82
  %t116 = load i64, ptr %l4, !tbaa !24
  %t119 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v0, ptr %t115, i64 %t116)
  store i1 %t119, ptr %l72
  br label %bb33
bb33:
  %t120 = load i1, ptr %l72, !tbaa !21
  br i1 %t120, label %bb34, label %bb35
bb34:
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t123 = getelementptr %"compiler/scope:Scoper", ptr %t121, i32 0, i32 82
  %t124 = load i64, ptr %l4, !tbaa !24
  %t127 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t123, i64 %t124)
  %t128 = extractvalue { i32, i64 } %t127, 1
  %t129 = extractvalue { i32, i64 } %t127, 0
  store i32 %t129, ptr %l78
  %t130 = icmp ne i32 %t129, 0
  br i1 %t130, label %bb37, label %ok.131, !prof !99
ok.131:
  store i64 %t128, ptr %l77
  br label %bb36
bb35:
  br label %bb40
bb36:
  %t132 = load i64, ptr %l77, !tbaa !24
  store i64 %t132, ptr %l73, !tbaa !24
  br label %bb39
bb37:
  br label %bb38
bb38:
  store i64 -1, ptr %l73, !tbaa !24
  br label %bb39
bb39:
  call void @__olang_scope_close(ptr %s0)
  %t133 = load i64, ptr %l73, !tbaa !24
  store i64 %t133, ptr %rv
  br label %ret
bb40:
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t136 = getelementptr %"compiler/scope:Scoper", ptr %t134, i32 0, i32 212
  %t137 = load i64, ptr %l4, !tbaa !24
  %t140 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t136, i64 %t137)
  store i64 %t140, ptr %l82
  br label %bb41
bb41:
  %t141 = load i64, ptr %l82, !tbaa !24
  %t142 = icmp sge i64 %t141, 0
  br i1 %t142, label %bb42, label %bb43
bb42:
  %t144 = load ptr, ptr %l0, !tbaa !29
  %t146 = getelementptr %"compiler/scope:Scoper", ptr %t144, i32 0, i32 82
  store ptr %t146, ptr %l86, !tbaa !29
  %t147 = load ptr, ptr %l0, !tbaa !29
  %t149 = getelementptr %"compiler/scope:Scoper", ptr %t147, i32 0, i32 212
  %t150 = load i64, ptr %l4, !tbaa !24
  %t153 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t149, i64 %t150)
  store i64 %t153, ptr %l90
  br label %bb44
bb43:
  br label %bb50
bb44:
  %t154 = load ptr, ptr %l86, !tbaa !29
  %t155 = load i64, ptr %l90, !tbaa !24
  %t156 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t154, i64 %t155)
  %t157 = extractvalue { i32, i64 } %t156, 1
  %t158 = extractvalue { i32, i64 } %t156, 0
  store i32 %t158, ptr %l92
  %t159 = icmp ne i32 %t158, 0
  br i1 %t159, label %bb46, label %ok.160, !prof !99
ok.160:
  store i64 %t157, ptr %l91
  br label %bb45
bb45:
  %t161 = load i64, ptr %l91, !tbaa !24
  store i64 %t161, ptr %l84, !tbaa !24
  br label %bb49
bb46:
  br label %bb47
bb47:
  %t162 = load ptr, ptr %l0, !tbaa !29
  %t164 = getelementptr %"compiler/scope:Scoper", ptr %t162, i32 0, i32 212
  %t165 = load i64, ptr %l4, !tbaa !24
  %t168 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t164, i64 %t165)
  store i64 %t168, ptr %l96
  br label %bb48
bb48:
  %t169 = load i64, ptr %l96, !tbaa !24
  store i64 %t169, ptr %l84, !tbaa !24
  br label %bb49
bb49:
  call void @__olang_scope_close(ptr %s0)
  %t170 = load i64, ptr %l84, !tbaa !24
  store i64 %t170, ptr %rv
  br label %ret
bb50:
  %t171 = load ptr, ptr %l0, !tbaa !29
  %t173 = getelementptr %"compiler/scope:Scoper", ptr %t171, i32 0, i32 211
  %t174 = load i64, ptr %l4, !tbaa !24
  %t177 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t173, i64 %t174)
  store i64 %t177, ptr %l100
  br label %bb51
bb51:
  %t178 = load i64, ptr %l100, !tbaa !24
  %t179 = icmp eq i64 %t178, -2
  br i1 %t179, label %bb52, label %bb53
bb52:
  %t181 = load ptr, ptr %l0, !tbaa !29
  %t182 = load i64, ptr %l4, !tbaa !24
  %t185 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eviewInit(ptr %v0, ptr %t181, i64 %t182)
  store i64 %t185, ptr %l104
  br label %bb54
bb53:
  br label %bb55
bb54:
  call void @__olang_scope_close(ptr %s0)
  %t186 = load i64, ptr %l104, !tbaa !24
  store i64 %t186, ptr %rv
  br label %ret
bb55:
  %t187 = load ptr, ptr %l0, !tbaa !29
  %t189 = getelementptr %"compiler/scope:Scoper", ptr %t187, i32 0, i32 211
  %t190 = load i64, ptr %l4, !tbaa !24
  %t193 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t189, i64 %t190)
  store i64 %t193, ptr %l108
  br label %bb56
bb56:
  %t194 = load i64, ptr %l108, !tbaa !24
  %t195 = icmp slt i64 %t194, 0
  br i1 %t195, label %bb57, label %bb58
bb57:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb58:
  br label %bb59
bb59:
  %t198 = load ptr, ptr %l0, !tbaa !29
  %t200 = getelementptr %"compiler/scope:Scoper", ptr %t198, i32 0, i32 211
  %t201 = load i64, ptr %l4, !tbaa !24
  %t204 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t200, i64 %t201)
  store i64 %t204, ptr %l114
  br label %bb60
bb60:
  %t205 = load i64, ptr %l114, !tbaa !24
  store i64 %t205, ptr %l4, !tbaa !24
  br label %bb61
bb61:
  %t206 = load i64, ptr %l9, !tbaa !24
  %t209 = add i64 %t206, 1
  store i64 %t209, ptr %l9, !tbaa !24
  br label %bb22
bb62:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fscope_2ecopiedRead(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i1
  %l4 = alloca ptr
  %l5 = alloca i1
  %l10 = alloca ptr
  %l11 = alloca i1
  %l15 = alloca ptr
  %l16 = alloca i1
  %l22 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb8
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  store ptr %t16, ptr %l10, !tbaa !29
  store i1 false, ptr %l11, !tbaa !21
  %t17 = load ptr, ptr %l10, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb6, label %bb7
bb6:
  %t20 = load ptr, ptr %l10, !tbaa !29
  %t21 = load i64, ptr %t20, !range !{i64 0, i64 8}
  %t23 = icmp eq i64 %t21, 6
  store i1 %t23, ptr %l11, !tbaa !21
  br label %bb7
bb7:
  %t24 = load i1, ptr %l11, !tbaa !21
  %t25 = xor i1 %t24, true
  store i1 %t25, ptr %l3, !tbaa !21
  br label %bb20
bb8:
  %t27 = load ptr, ptr %l0, !tbaa !29
  store ptr %t27, ptr %l15, !tbaa !29
  store i1 false, ptr %l16, !tbaa !21
  %t28 = load ptr, ptr %l15, !tbaa !29
  %t29 = icmp ne ptr %t28, null
  br i1 %t29, label %bb9, label %bb10
bb9:
  %t31 = load ptr, ptr %l15, !tbaa !29
  %t32 = load i64, ptr %t31, !range !{i64 0, i64 18}
  %t34 = icmp eq i64 %t32, 17
  store i1 %t34, ptr %l16, !tbaa !21
  br label %bb10
bb10:
  %t35 = load i1, ptr %l16, !tbaa !21
  br i1 %t35, label %bb11, label %bb12
bb11:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr { i64, [5 x i64] }, ptr %t36, i32 0, i32 1
  %t39 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t38, i32 0, i32 2
  %t40 = load ptr, ptr %t39
  store ptr %t40, ptr %l2, !tbaa !29
  br label %bb13
bb12:
  br label %bb15
bb13:
  %t42 = load ptr, ptr %l2, !tbaa !29
  %t44 = call i1 @compiler_2fscope_2ecopiedRead(ptr %v0, ptr %t42)
  store i1 %t44, ptr %l22
  br label %bb14
bb14:
  %t45 = load i1, ptr %l22, !tbaa !21
  store i1 %t45, ptr %l3, !tbaa !21
  br label %bb20
bb15:
  br i1 true, label %bb16, label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb19
bb18:
  store i1 false, ptr %l3, !tbaa !21
  br label %bb20
bb19:
  call void @__olang_check_failed(ptr @olang_loc_825a81e7f5138d1b_866e780fc6f79e3f)
  unreachable
bb20:
  %t46 = load i1, ptr %l3, !tbaa !21
  store i1 %t46, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fscope_2ewalked_2ewalkBody(ptr %out, ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %lp2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca %"compiler/scope:walked"
  %l8 = alloca ptr
  %l17 = alloca %"compiler/scope:walked"
  %t1 = alloca %"compiler/scope:walked", align 8
  br label %start
start:
  br label %bb0
bb0:
  call void @olang_2emir_2eHelperKind_2eZero_2ecompiler_2fscope_3awalked(ptr %t1, ptr %v1)
  call void @llvm.memmove.p0.p0.i64(ptr %l4, ptr %t1, i64 424, i1 false)
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 424, i64 8)
  store ptr %t2, ptr %lp2
  %t3 = load ptr, ptr %lp2
  call void @llvm.memmove.p0.p0.i64(ptr %t3, ptr %l4, i64 424, i1 false)
  %t6 = getelementptr %"compiler/scope:Scoper", ptr %a0, i32 0, i32 1
  %t10 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t6, i64 %a1)
  store ptr %t10, ptr %l8
  br label %bb2
bb2:
  %t11 = load ptr, ptr %l8, !tbaa !29
  store ptr %t11, ptr %l3, !tbaa !29
  %t12 = load ptr, ptr %l3, !tbaa !29
  %t14 = getelementptr %"compiler/typed:Body", ptr %t12, i32 0, i32 11
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t17 = icmp eq ptr %t15, null
  %t19 = xor i1 %t17, true
  br i1 %t19, label %bb3, label %bb4
bb3:
  %t21 = load ptr, ptr %l3, !tbaa !29
  %t23 = getelementptr %"compiler/typed:Body", ptr %t21, i32 0, i32 11
  %t24 = load ptr, ptr %t23, !tbaa !29
  %t26 = load ptr, ptr %lp2
  call void @compiler_2fscope_2ecollectBlock(ptr %v0, ptr %v1, ptr %t24, ptr %t26)
  br label %bb5
bb4:
  br label %bb6
bb5:
  br label %bb6
bb6:
  %t29 = load ptr, ptr %lp2
  call void @llvm.memmove.p0.p0.i64(ptr %l17, ptr %t29, i64 424, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l17, i64 424, i1 false)
  br label %ret
ret:
  ret void
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fscope_3acompRun_26_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 8
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

@.d0 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"runs " }>, align 8
declare i64 @__olang_fmt_i64(ptr, i64)
@.d1 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" marks " }>, align 8
@.d2 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" reads " }>, align 8
@.d3 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" diags " }>, align 8
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %dh = load ptr, ptr %dheadptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  %hasd = icmp ne ptr %dh, null
  %owns = or i1 %hasf, %hasd
  br i1 %owns, label %owned, label %chunks
owned:
  call void @__olang_scope_close_owned(ptr %scope)
  br label %chunks
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
@.d4 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" == " }>, align 8
@.d5 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" >= " }>, align 8
@.d6 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c" why " }>, align 8
@.d7 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d8 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"rel " }>, align 8
declare void @__olang_sb_put(ptr, ptr, i64)
define linkonce_odr void @olang_2emir_2eHelperKind_2eRender_2ecompiler_2fscope_3aTerm(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %t1, !range !{i64 0, i64 7}
  switch i64 %t2, label %bb1 [ i64 0, label %bb2 i64 1, label %bb3 i64 2, label %bb4 i64 3, label %bb5 i64 4, label %bb6 i64 5, label %bb7 i64 6, label %bb8 ]
bb1:
  br label %ret
bb2:
  %t4 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d70, i32 0, i32 1) }, 1
  %t5 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d70, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t4, i64 %t5)
  br label %bb1
bb3:
  %t6 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d71, i32 0, i32 1) }, 1
  %t7 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d71, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t6, i64 %t7)
  %t8 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d72, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d72, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t8, i64 %t9)
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr { i64, [2 x i64] }, ptr %t10, i32 0, i32 1
  %t12 = getelementptr { i32 }, ptr %t11, i32 0, i32 0
  %t13 = load i32, ptr %t12
  %t15 = sext i32 %t13 to i64
  %t16 = call ptr @__olang_sb_room(ptr %v0, i64 24)
  %t17 = call i64 @__olang_fmt_i64(ptr %t16, i64 %t15)
  call void @__olang_sb_add(ptr %v0, i64 %t17)
  %t18 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d73, i32 0, i32 1) }, 1
  %t19 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d73, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t18, i64 %t19)
  br label %bb1
bb4:
  %t20 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d74, i32 0, i32 1) }, 1
  %t21 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d74, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t20, i64 %t21)
  %t22 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d72, i32 0, i32 1) }, 1
  %t23 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d72, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t22, i64 %t23)
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr { i64, [2 x i64] }, ptr %t24, i32 0, i32 1
  %t26 = getelementptr { i64 }, ptr %t25, i32 0, i32 0
  %t27 = load i64, ptr %t26
  %t29 = call ptr @__olang_sb_room(ptr %v0, i64 24)
  %t30 = call i64 @__olang_fmt_i64(ptr %t29, i64 %t27)
  call void @__olang_sb_add(ptr %v0, i64 %t30)
  %t31 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d73, i32 0, i32 1) }, 1
  %t32 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d73, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t31, i64 %t32)
  br label %bb1
bb5:
  %t33 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d75, i32 0, i32 1) }, 1
  %t34 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d75, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t33, i64 %t34)
  br label %bb1
bb6:
  %t35 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d76, i32 0, i32 1) }, 1
  %t36 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d76, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t35, i64 %t36)
  %t37 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d72, i32 0, i32 1) }, 1
  %t38 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d72, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t37, i64 %t38)
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr { i64, [2 x i64] }, ptr %t39, i32 0, i32 1
  %t41 = getelementptr { i64, i64 }, ptr %t40, i32 0, i32 0
  %t42 = load i64, ptr %t41
  %t44 = call ptr @__olang_sb_room(ptr %v0, i64 24)
  %t45 = call i64 @__olang_fmt_i64(ptr %t44, i64 %t42)
  call void @__olang_sb_add(ptr %v0, i64 %t45)
  %t46 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d77, i32 0, i32 1) }, 1
  %t47 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d77, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t46, i64 %t47)
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr { i64, [2 x i64] }, ptr %t48, i32 0, i32 1
  %t50 = getelementptr { i64, i64 }, ptr %t49, i32 0, i32 1
  %t51 = load i64, ptr %t50
  %t53 = call ptr @__olang_sb_room(ptr %v0, i64 24)
  %t54 = call i64 @__olang_fmt_i64(ptr %t53, i64 %t51)
  call void @__olang_sb_add(ptr %v0, i64 %t54)
  %t55 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d73, i32 0, i32 1) }, 1
  %t56 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d73, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t55, i64 %t56)
  br label %bb1
bb7:
  %t57 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d78, i32 0, i32 1) }, 1
  %t58 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d78, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t57, i64 %t58)
  %t59 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d72, i32 0, i32 1) }, 1
  %t60 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d72, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t59, i64 %t60)
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr { i64, [2 x i64] }, ptr %t61, i32 0, i32 1
  %t63 = getelementptr { i64 }, ptr %t62, i32 0, i32 0
  %t64 = load i64, ptr %t63
  %t66 = call ptr @__olang_sb_room(ptr %v0, i64 24)
  %t67 = call i64 @__olang_fmt_i64(ptr %t66, i64 %t64)
  call void @__olang_sb_add(ptr %v0, i64 %t67)
  %t68 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d73, i32 0, i32 1) }, 1
  %t69 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d73, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t68, i64 %t69)
  br label %bb1
bb8:
  %t70 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d79, i32 0, i32 1) }, 1
  %t71 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d79, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t70, i64 %t71)
  br label %bb1
ret:
  ret void
}

@.d9 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
declare void @__olang_sb_done(ptr)
@.d10 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"var " }>, align 8
@.d11 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c" builds " }>, align 8
@.c12 = private unnamed_addr constant [5 x i8] c"true\00"
@.c13 = private unnamed_addr constant [6 x i8] c"false\00"
@.d14 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" real " }>, align 8
@.d15 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d16 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"param " }>, align 8
@.d17 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" keeps " }>, align 8
@.d18 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c" stores " }>, align 8
@.d19 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" puts " }>, align 8
@.d20 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d21 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"result binds " }>, align 8
define available_externally ptr @__olang_sb_room(ptr %sb, i64 %need) alwaysinline {
entry:
  %lenp = getelementptr { ptr, i64, i64, ptr }, ptr %sb, i32 0, i32 1
  %capp = getelementptr { ptr, i64, i64, ptr }, ptr %sb, i32 0, i32 2
  %len = load i64, ptr %lenp
  %cap = load i64, ptr %capp
  %want = add i64 %len, %need
  %fits = icmp ule i64 %want, %cap
  br i1 %fits, label %ok, label %grow
ok:
  %data = load ptr, ptr %sb
  %p = getelementptr i8, ptr %data, i64 %len
  ret ptr %p
grow:
  %g = call ptr @__olang_sb_grow(ptr %sb, i64 %need)
  ret ptr %g
}
declare void @__olang_sb_add(ptr, i64)
@.d22 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" at " }>, align 8
@.d23 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
declare void @__olang_check_failed(ptr) cold noreturn
@.d24 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c" diagnostics" }>, align 8
@.d25 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c" refusals" }>, align 8
@.d26 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c" summary of " }>, align 8
@.d27 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c": " }>, align 8
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
define linkonce_odr void @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2ftyped_3aPlan(ptr %out, ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"compiler/typed:Plan"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l9 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l11 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l13 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l15 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l17 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l19 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l21 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  call void @llvm.memmove.p0.p0.i64(ptr %l1, ptr %a0, i64 584, i1 false)
  %t2 = getelementptr %"compiler/typed:Plan", ptr %l1, i32 0, i32 11
  %t4 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t2)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t4, ptr %l3
  br label %bb1
bb1:
  %t5 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  %t6 = getelementptr %"compiler/typed:Plan", ptr %l1, i32 0, i32 11
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %t6
  %t7 = getelementptr %"compiler/typed:Plan", ptr %l1, i32 0, i32 12
  %t9 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %t7)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %l5
  br label %bb2
bb2:
  %t10 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l5
  %t11 = getelementptr %"compiler/typed:Plan", ptr %l1, i32 0, i32 12
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t10, ptr %t11
  %t12 = getelementptr %"compiler/typed:Plan", ptr %l1, i32 0, i32 16
  %t14 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScope_3e(ptr %v0, ptr %t12)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t14, ptr %l7
  br label %bb3
bb3:
  %t15 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l7
  %t16 = getelementptr %"compiler/typed:Plan", ptr %l1, i32 0, i32 16
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t15, ptr %t16
  %t17 = getelementptr %"compiler/typed:Plan", ptr %l1, i32 0, i32 17
  %t19 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %t17)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t19, ptr %l9
  br label %bb4
bb4:
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l9
  %t21 = getelementptr %"compiler/typed:Plan", ptr %l1, i32 0, i32 17
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %t21
  %t22 = getelementptr %"compiler/typed:Plan", ptr %l1, i32 0, i32 18
  %t24 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %t22)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t24, ptr %l11
  br label %bb5
bb5:
  %t25 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l11
  %t26 = getelementptr %"compiler/typed:Plan", ptr %l1, i32 0, i32 18
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t25, ptr %t26
  %t27 = getelementptr %"compiler/typed:Plan", ptr %l1, i32 0, i32 19
  %t29 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fv_H37dabf8663d733dfb3cf8a6ba127be58(ptr %v0, ptr %t27)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t29, ptr %l13
  br label %bb6
bb6:
  %t30 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l13
  %t31 = getelementptr %"compiler/typed:Plan", ptr %l1, i32 0, i32 19
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t30, ptr %t31
  %t32 = getelementptr %"compiler/typed:Plan", ptr %l1, i32 0, i32 20
  %t34 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t32)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t34, ptr %l15
  br label %bb7
bb7:
  %t35 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l15
  %t36 = getelementptr %"compiler/typed:Plan", ptr %l1, i32 0, i32 20
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t35, ptr %t36
  %t37 = getelementptr %"compiler/typed:Plan", ptr %l1, i32 0, i32 21
  %t39 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec__Hdbcf217951d8a5e6be477b9bbf1b3074(ptr %v0, ptr %t37)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t39, ptr %l17
  br label %bb8
bb8:
  %t40 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l17
  %t41 = getelementptr %"compiler/typed:Plan", ptr %l1, i32 0, i32 21
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t40, ptr %t41
  %t42 = getelementptr %"compiler/typed:Plan", ptr %l1, i32 0, i32 22
  %t44 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t42)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t44, ptr %l19
  br label %bb9
bb9:
  %t45 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l19
  %t46 = getelementptr %"compiler/typed:Plan", ptr %l1, i32 0, i32 22
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t45, ptr %t46
  %t47 = getelementptr %"compiler/typed:Plan", ptr %l1, i32 0, i32 23
  %t49 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScope_3e(ptr %v0, ptr %t47)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t49, ptr %l21
  br label %bb10
bb10:
  %t50 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l21
  %t51 = getelementptr %"compiler/typed:Plan", ptr %l1, i32 0, i32 23
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t50, ptr %t51
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l1, i64 584, i1 false)
  br label %ret
ret:
  ret void
}

define linkonce_odr i1 @olang_2emir_2eHelperKind_2eEqual_2eArray_3ccompiler_2ftyped_3aScope_3e_26(ptr %a0, ptr %a1) #0 {
entry:
  %l6 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load { i64, ptr }, ptr %a0, !tbaa !27
  %t4 = load { i64, ptr }, ptr %a1, !tbaa !27
  %t9 = call i1 @olang_2emir_2eHelperKind_2eEqual_2eArray_3ccompiler_2ftyped_3aScope_3e({ i64, ptr } %t2, { i64, ptr } %t4)
  store i1 %t9, ptr %l6
  br label %bb1
bb1:
  %t10 = load i1, ptr %l6, !tbaa !21
  store i1 %t10, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define linkonce_odr i1 @olang_2emir_2eHelperKind_2eEqual_2eArray_3cBool_3e_26(ptr %a0, ptr %a1) #0 {
entry:
  %l6 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load { i64, ptr }, ptr %a0, !tbaa !27
  %t4 = load { i64, ptr }, ptr %a1, !tbaa !27
  %t9 = call i1 @olang_2emir_2eHelperKind_2eEqual_2eArray_3cBool_3e({ i64, ptr } %t2, { i64, ptr } %t4)
  store i1 %t9, ptr %l6
  br label %bb1
bb1:
  %t10 = load i1, ptr %l6, !tbaa !21
  store i1 %t10, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define linkonce_odr i1 @olang_2emir_2eHelperKind_2eEqual_2eArray_3cI64_3e_26(ptr %a0, ptr %a1) #0 {
entry:
  %l6 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load { i64, ptr }, ptr %a0, !tbaa !27
  %t4 = load { i64, ptr }, ptr %a1, !tbaa !27
  %t9 = call i1 @olang_2emir_2eHelperKind_2eEqual_2eArray_3cI64_3e({ i64, ptr } %t2, { i64, ptr } %t4)
  store i1 %t9, ptr %l6
  br label %bb1
bb1:
  %t10 = load i1, ptr %l6, !tbaa !21
  store i1 %t10, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define linkonce_odr i1 @olang_2emir_2eHelperKind_2eEqual_2eArray_3ccompiler_2ftyped_3aExpr_3f_26_3e_26(ptr %a0, ptr %a1) #0 {
entry:
  %l6 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load { i64, ptr }, ptr %a0, !tbaa !27
  %t4 = load { i64, ptr }, ptr %a1, !tbaa !27
  %t9 = call i1 @olang_2emir_2eHelperKind_2eEqual_2eArray_3ccompiler_2ftyped_3aExpr_3f_26_3e({ i64, ptr } %t2, { i64, ptr } %t4)
  store i1 %t9, ptr %l6
  br label %bb1
bb1:
  %t10 = load i1, ptr %l6, !tbaa !21
  store i1 %t10, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d28 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c" plan of " }>, align 8
@.d29 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d30 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"@" }>, align 8
@.d31 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c":" }>, align 8
@.d32 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
define linkonce_odr void @olang_2emir_2eHelperKind_2eRender_2ecompiler_2ftyped_3aBodyOf(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %t1, !range !{i64 0, i64 10}
  switch i64 %t2, label %bb1 [ i64 0, label %bb2 i64 1, label %bb3 i64 2, label %bb4 i64 3, label %bb5 i64 4, label %bb6 i64 5, label %bb7 i64 6, label %bb8 i64 7, label %bb9 i64 8, label %bb10 i64 9, label %bb11 ]
bb1:
  br label %ret
bb2:
  %t4 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d80, i32 0, i32 1) }, 1
  %t5 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d80, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t4, i64 %t5)
  %t6 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d72, i32 0, i32 1) }, 1
  %t7 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d72, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t6, i64 %t7)
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr { i64, [2 x i64] }, ptr %t8, i32 0, i32 1
  %t10 = getelementptr { i64 }, ptr %t9, i32 0, i32 0
  %t11 = load i64, ptr %t10
  %t13 = call ptr @__olang_sb_room(ptr %v0, i64 24)
  %t14 = call i64 @__olang_fmt_i64(ptr %t13, i64 %t11)
  call void @__olang_sb_add(ptr %v0, i64 %t14)
  %t15 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d73, i32 0, i32 1) }, 1
  %t16 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d73, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t15, i64 %t16)
  br label %bb1
bb3:
  %t17 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d81, i32 0, i32 1) }, 1
  %t18 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d81, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t17, i64 %t18)
  %t19 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d72, i32 0, i32 1) }, 1
  %t20 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d72, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t19, i64 %t20)
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr { i64, [2 x i64] }, ptr %t21, i32 0, i32 1
  %t23 = getelementptr { i32, i32 }, ptr %t22, i32 0, i32 0
  %t24 = load i32, ptr %t23
  %t26 = sext i32 %t24 to i64
  %t27 = call ptr @__olang_sb_room(ptr %v0, i64 24)
  %t28 = call i64 @__olang_fmt_i64(ptr %t27, i64 %t26)
  call void @__olang_sb_add(ptr %v0, i64 %t28)
  %t29 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d77, i32 0, i32 1) }, 1
  %t30 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d77, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t29, i64 %t30)
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr { i64, [2 x i64] }, ptr %t31, i32 0, i32 1
  %t33 = getelementptr { i32, i32 }, ptr %t32, i32 0, i32 1
  %t34 = load i32, ptr %t33
  %t36 = sext i32 %t34 to i64
  %t37 = call ptr @__olang_sb_room(ptr %v0, i64 24)
  %t38 = call i64 @__olang_fmt_i64(ptr %t37, i64 %t36)
  call void @__olang_sb_add(ptr %v0, i64 %t38)
  %t39 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d73, i32 0, i32 1) }, 1
  %t40 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d73, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t39, i64 %t40)
  br label %bb1
bb4:
  %t41 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d82, i32 0, i32 1) }, 1
  %t42 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d82, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t41, i64 %t42)
  %t43 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d72, i32 0, i32 1) }, 1
  %t44 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d72, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t43, i64 %t44)
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr { i64, [2 x i64] }, ptr %t45, i32 0, i32 1
  %t47 = getelementptr { i32, i64 }, ptr %t46, i32 0, i32 0
  %t48 = load i32, ptr %t47
  %t50 = sext i32 %t48 to i64
  %t51 = call ptr @__olang_sb_room(ptr %v0, i64 24)
  %t52 = call i64 @__olang_fmt_i64(ptr %t51, i64 %t50)
  call void @__olang_sb_add(ptr %v0, i64 %t52)
  %t53 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d77, i32 0, i32 1) }, 1
  %t54 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d77, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t53, i64 %t54)
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr { i64, [2 x i64] }, ptr %t55, i32 0, i32 1
  %t57 = getelementptr { i32, i64 }, ptr %t56, i32 0, i32 1
  %t58 = load i64, ptr %t57
  %t60 = call ptr @__olang_sb_room(ptr %v0, i64 24)
  %t61 = call i64 @__olang_fmt_i64(ptr %t60, i64 %t58)
  call void @__olang_sb_add(ptr %v0, i64 %t61)
  %t62 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d73, i32 0, i32 1) }, 1
  %t63 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d73, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t62, i64 %t63)
  br label %bb1
bb5:
  %t64 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d83, i32 0, i32 1) }, 1
  %t65 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d83, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t64, i64 %t65)
  %t66 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d72, i32 0, i32 1) }, 1
  %t67 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d72, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t66, i64 %t67)
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr { i64, [2 x i64] }, ptr %t68, i32 0, i32 1
  %t70 = getelementptr { i32 }, ptr %t69, i32 0, i32 0
  %t71 = load i32, ptr %t70
  %t73 = sext i32 %t71 to i64
  %t74 = call ptr @__olang_sb_room(ptr %v0, i64 24)
  %t75 = call i64 @__olang_fmt_i64(ptr %t74, i64 %t73)
  call void @__olang_sb_add(ptr %v0, i64 %t75)
  %t76 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d73, i32 0, i32 1) }, 1
  %t77 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d73, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t76, i64 %t77)
  br label %bb1
bb6:
  %t78 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d84, i32 0, i32 1) }, 1
  %t79 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d84, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t78, i64 %t79)
  %t80 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d72, i32 0, i32 1) }, 1
  %t81 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d72, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t80, i64 %t81)
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr { i64, [2 x i64] }, ptr %t82, i32 0, i32 1
  %t84 = getelementptr { i32 }, ptr %t83, i32 0, i32 0
  %t85 = load i32, ptr %t84
  %t87 = sext i32 %t85 to i64
  %t88 = call ptr @__olang_sb_room(ptr %v0, i64 24)
  %t89 = call i64 @__olang_fmt_i64(ptr %t88, i64 %t87)
  call void @__olang_sb_add(ptr %v0, i64 %t89)
  %t90 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d73, i32 0, i32 1) }, 1
  %t91 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d73, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t90, i64 %t91)
  br label %bb1
bb7:
  %t92 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d85, i32 0, i32 1) }, 1
  %t93 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d85, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t92, i64 %t93)
  %t94 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d72, i32 0, i32 1) }, 1
  %t95 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d72, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t94, i64 %t95)
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t97 = getelementptr { i64, [2 x i64] }, ptr %t96, i32 0, i32 1
  %t98 = getelementptr { i64 }, ptr %t97, i32 0, i32 0
  %t99 = load i64, ptr %t98
  %t101 = call ptr @__olang_sb_room(ptr %v0, i64 24)
  %t102 = call i64 @__olang_fmt_i64(ptr %t101, i64 %t99)
  call void @__olang_sb_add(ptr %v0, i64 %t102)
  %t103 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d73, i32 0, i32 1) }, 1
  %t104 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d73, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t103, i64 %t104)
  br label %bb1
bb8:
  %t105 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d86, i32 0, i32 1) }, 1
  %t106 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d86, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t105, i64 %t106)
  %t107 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d72, i32 0, i32 1) }, 1
  %t108 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d72, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t107, i64 %t108)
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t110 = getelementptr { i64, [2 x i64] }, ptr %t109, i32 0, i32 1
  %t111 = getelementptr { i64, i32 }, ptr %t110, i32 0, i32 0
  %t112 = load i64, ptr %t111
  %t114 = call ptr @__olang_sb_room(ptr %v0, i64 24)
  %t115 = call i64 @__olang_fmt_i64(ptr %t114, i64 %t112)
  call void @__olang_sb_add(ptr %v0, i64 %t115)
  %t116 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d77, i32 0, i32 1) }, 1
  %t117 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d77, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t116, i64 %t117)
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr { i64, [2 x i64] }, ptr %t118, i32 0, i32 1
  %t120 = getelementptr { i64, i32 }, ptr %t119, i32 0, i32 1
  %t121 = load i32, ptr %t120
  %t123 = sext i32 %t121 to i64
  %t124 = call ptr @__olang_sb_room(ptr %v0, i64 24)
  %t125 = call i64 @__olang_fmt_i64(ptr %t124, i64 %t123)
  call void @__olang_sb_add(ptr %v0, i64 %t125)
  %t126 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d73, i32 0, i32 1) }, 1
  %t127 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d73, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t126, i64 %t127)
  br label %bb1
bb9:
  %t128 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d87, i32 0, i32 1) }, 1
  %t129 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d87, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t128, i64 %t129)
  %t130 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d72, i32 0, i32 1) }, 1
  %t131 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d72, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t130, i64 %t131)
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t133 = getelementptr { i64, [2 x i64] }, ptr %t132, i32 0, i32 1
  %t134 = getelementptr { i64, i32 }, ptr %t133, i32 0, i32 0
  %t135 = load i64, ptr %t134
  %t137 = call ptr @__olang_sb_room(ptr %v0, i64 24)
  %t138 = call i64 @__olang_fmt_i64(ptr %t137, i64 %t135)
  call void @__olang_sb_add(ptr %v0, i64 %t138)
  %t139 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d77, i32 0, i32 1) }, 1
  %t140 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d77, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t139, i64 %t140)
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t142 = getelementptr { i64, [2 x i64] }, ptr %t141, i32 0, i32 1
  %t143 = getelementptr { i64, i32 }, ptr %t142, i32 0, i32 1
  %t144 = load i32, ptr %t143
  %t146 = sext i32 %t144 to i64
  %t147 = call ptr @__olang_sb_room(ptr %v0, i64 24)
  %t148 = call i64 @__olang_fmt_i64(ptr %t147, i64 %t146)
  call void @__olang_sb_add(ptr %v0, i64 %t148)
  %t149 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d73, i32 0, i32 1) }, 1
  %t150 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d73, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t149, i64 %t150)
  br label %bb1
bb10:
  %t151 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d88, i32 0, i32 1) }, 1
  %t152 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d88, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t151, i64 %t152)
  %t153 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d72, i32 0, i32 1) }, 1
  %t154 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d72, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t153, i64 %t154)
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t156 = getelementptr { i64, [2 x i64] }, ptr %t155, i32 0, i32 1
  %t157 = getelementptr { i32, i32, i64 }, ptr %t156, i32 0, i32 0
  %t158 = load i32, ptr %t157
  %t160 = sext i32 %t158 to i64
  %t161 = call ptr @__olang_sb_room(ptr %v0, i64 24)
  %t162 = call i64 @__olang_fmt_i64(ptr %t161, i64 %t160)
  call void @__olang_sb_add(ptr %v0, i64 %t162)
  %t163 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d77, i32 0, i32 1) }, 1
  %t164 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d77, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t163, i64 %t164)
  %t165 = load ptr, ptr %l0, !tbaa !29
  %t166 = getelementptr { i64, [2 x i64] }, ptr %t165, i32 0, i32 1
  %t167 = getelementptr { i32, i32, i64 }, ptr %t166, i32 0, i32 1
  call void @olang_2emir_2eHelperKind_2eRender_2ecompiler_2ftyped_3aContractKind(ptr %v0, ptr %t167, i64 %a1)
  br label %bb12
bb11:
  %t170 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d89, i32 0, i32 1) }, 1
  %t171 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d89, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t170, i64 %t171)
  %t172 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d72, i32 0, i32 1) }, 1
  %t173 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d72, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t172, i64 %t173)
  %t174 = load ptr, ptr %l0, !tbaa !29
  %t175 = getelementptr { i64, [2 x i64] }, ptr %t174, i32 0, i32 1
  %t176 = getelementptr { i64, i64 }, ptr %t175, i32 0, i32 0
  %t177 = load i64, ptr %t176
  %t179 = call ptr @__olang_sb_room(ptr %v0, i64 24)
  %t180 = call i64 @__olang_fmt_i64(ptr %t179, i64 %t177)
  call void @__olang_sb_add(ptr %v0, i64 %t180)
  %t181 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d77, i32 0, i32 1) }, 1
  %t182 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d77, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t181, i64 %t182)
  %t183 = load ptr, ptr %l0, !tbaa !29
  %t184 = getelementptr { i64, [2 x i64] }, ptr %t183, i32 0, i32 1
  %t185 = getelementptr { i64, i64 }, ptr %t184, i32 0, i32 1
  %t186 = load i64, ptr %t185
  %t188 = call ptr @__olang_sb_room(ptr %v0, i64 24)
  %t189 = call i64 @__olang_fmt_i64(ptr %t188, i64 %t186)
  call void @__olang_sb_add(ptr %v0, i64 %t189)
  %t190 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d73, i32 0, i32 1) }, 1
  %t191 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d73, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t190, i64 %t191)
  br label %bb1
bb12:
  %t192 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d77, i32 0, i32 1) }, 1
  %t193 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d77, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t192, i64 %t193)
  %t194 = load ptr, ptr %l0, !tbaa !29
  %t195 = getelementptr { i64, [2 x i64] }, ptr %t194, i32 0, i32 1
  %t196 = getelementptr { i32, i32, i64 }, ptr %t195, i32 0, i32 2
  %t197 = load i64, ptr %t196
  %t199 = call ptr @__olang_sb_room(ptr %v0, i64 24)
  %t200 = call i64 @__olang_fmt_i64(ptr %t199, i64 %t197)
  call void @__olang_sb_add(ptr %v0, i64 %t200)
  %t201 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d73, i32 0, i32 1) }, 1
  %t202 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d73, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t201, i64 %t202)
  br label %bb1
ret:
  ret void
}

@.d33 = private constant <{ i64, [28 x i8] }> <{ i64 0, [28 x i8] c"OLANG_SCOPECHECK: component " }>, align 8
@.d34 = private constant <{ i64, [37 x i8] }> <{ i64 0, [37 x i8] c" taken again but judged differently -" }>, align 8
declare void @__olang_check_failed_text(ptr, { i64, ptr }) cold noreturn
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ; B19b: a benchmark build counts what this thread allocates - here and at the slow path's own bump, so each
  ; allocation is counted once wherever it is made (a region's and a forwarded scope's come back through here)
; @bench %bna = load i64, ptr @__olang_bench_allocs
; @bench %bna1 = add i64 %bna, 1
; @bench store i64 %bna1, ptr @__olang_bench_allocs
; @bench %bnb = load i64, ptr @__olang_bench_bytes
; @bench %bnb1 = add i64 %bnb, %size
; @bench store i64 %bnb1, ptr @__olang_bench_bytes
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
@.d35 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
define linkonce_odr %"compiler/scope:fsBody" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2fscope_3afsBody(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"compiler/scope:fsBody"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %rv = alloca %"compiler/scope:fsBody"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"compiler/scope:fsBody", ptr %a0
  store %"compiler/scope:fsBody" %t2, ptr %l1
  %t3 = getelementptr %"compiler/scope:fsBody", ptr %l1, i32 0, i32 0
  %t5 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3afsRow_3e(ptr %v0, ptr %t3)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %l3
  br label %bb1
bb1:
  %t6 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  %t7 = getelementptr %"compiler/scope:fsBody", ptr %l1, i32 0, i32 0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t6, ptr %t7
  %t8 = getelementptr %"compiler/scope:fsBody", ptr %l1, i32 0, i32 1
  %t10 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3afsOpen_3e(ptr %v0, ptr %t8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t10, ptr %l5
  br label %bb2
bb2:
  %t11 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l5
  %t12 = getelementptr %"compiler/scope:fsBody", ptr %l1, i32 0, i32 1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t11, ptr %t12
  %t13 = load %"compiler/scope:fsBody", ptr %l1
  store %"compiler/scope:fsBody" %t13, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/scope:fsBody", ptr %rv
  ret %"compiler/scope:fsBody" %rr
}

define internal i1 @olang_lambda_36(ptr %env, { i64, [2 x i64] } %a0) #0 {
entry:
  %l1 = alloca %"compiler/scope:fsRow"
  %l2 = alloca { i64, [2 x i64] }
  %l4 = alloca { i64, [2 x i64] }
  %l6 = alloca i1
  %rv = alloca i1
  %cp0 = getelementptr { %"compiler/scope:fsRow" }, ptr %env, i32 0, i32 0
  %cv0 = load %"compiler/scope:fsRow", ptr %cp0, !tbaa !28
  store %"compiler/scope:fsRow" %cv0, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store { i64, [2 x i64] } %a0, ptr %l2
  %t2 = getelementptr %"compiler/scope:fsRow", ptr %l1, i32 0, i32 1
  %t3 = load { i64, [2 x i64] }, ptr %t2
  store { i64, [2 x i64] } %t3, ptr %l4
  %t6 = call i1 @olang_2emir_2eHelperKind_2eEqual_2ecompiler_2fscope_3aTerm(ptr %l2, ptr %l4)
  store i1 %t6, ptr %l6
  br label %bb1
bb1:
  %t7 = load i1, ptr %l6, !tbaa !21
  store i1 %t7, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define linkonce_odr i1 @olang_2emir_2eHelperKind_2eEqual_2ecompiler_2fscope_3aTerm(ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca i64
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %t1, !range !{i64 0, i64 7}
  store i64 %t2, ptr %l3, !tbaa !24
  %t3 = load ptr, ptr %l1, !tbaa !29
  %t4 = load i64, ptr %t3, !range !{i64 0, i64 7}
  %t5 = load i64, ptr %l3, !tbaa !24
  %t7 = icmp eq i64 %t5, %t4
  br i1 %t7, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb13
bb2:
  %t9 = load i64, ptr %l3, !tbaa !24
  switch i64 %t9, label %bb3 [ i64 1, label %bb4 i64 2, label %bb5 i64 4, label %bb6 i64 5, label %bb7 ]
bb3:
  br label %bb13
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr { i64, [2 x i64] }, ptr %t10, i32 0, i32 1
  %t12 = getelementptr { i32 }, ptr %t11, i32 0, i32 0
  %t13 = load i32, ptr %t12
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t15 = getelementptr { i64, [2 x i64] }, ptr %t14, i32 0, i32 1
  %t16 = getelementptr { i32 }, ptr %t15, i32 0, i32 0
  %t17 = load i32, ptr %t16
  %t20 = icmp eq i32 %t13, %t17
  br i1 %t20, label %bb8, label %bb1
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr { i64, [2 x i64] }, ptr %t22, i32 0, i32 1
  %t24 = getelementptr { i64 }, ptr %t23, i32 0, i32 0
  %t25 = load i64, ptr %t24
  %t26 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr { i64, [2 x i64] }, ptr %t26, i32 0, i32 1
  %t28 = getelementptr { i64 }, ptr %t27, i32 0, i32 0
  %t29 = load i64, ptr %t28
  %t32 = icmp eq i64 %t25, %t29
  br i1 %t32, label %bb9, label %bb1
bb6:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr { i64, [2 x i64] }, ptr %t34, i32 0, i32 1
  %t36 = getelementptr { i64, i64 }, ptr %t35, i32 0, i32 0
  %t37 = load i64, ptr %t36
  %t38 = load ptr, ptr %l1, !tbaa !29
  %t39 = getelementptr { i64, [2 x i64] }, ptr %t38, i32 0, i32 1
  %t40 = getelementptr { i64, i64 }, ptr %t39, i32 0, i32 0
  %t41 = load i64, ptr %t40
  %t44 = icmp eq i64 %t37, %t41
  br i1 %t44, label %bb10, label %bb1
bb7:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr { i64, [2 x i64] }, ptr %t46, i32 0, i32 1
  %t48 = getelementptr { i64 }, ptr %t47, i32 0, i32 0
  %t49 = load i64, ptr %t48
  %t50 = load ptr, ptr %l1, !tbaa !29
  %t51 = getelementptr { i64, [2 x i64] }, ptr %t50, i32 0, i32 1
  %t52 = getelementptr { i64 }, ptr %t51, i32 0, i32 0
  %t53 = load i64, ptr %t52
  %t56 = icmp eq i64 %t49, %t53
  br i1 %t56, label %bb12, label %bb1
bb8:
  br label %bb3
bb9:
  br label %bb3
bb10:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr { i64, [2 x i64] }, ptr %t58, i32 0, i32 1
  %t60 = getelementptr { i64, i64 }, ptr %t59, i32 0, i32 1
  %t61 = load i64, ptr %t60
  %t62 = load ptr, ptr %l1, !tbaa !29
  %t63 = getelementptr { i64, [2 x i64] }, ptr %t62, i32 0, i32 1
  %t64 = getelementptr { i64, i64 }, ptr %t63, i32 0, i32 1
  %t65 = load i64, ptr %t64
  %t68 = icmp eq i64 %t61, %t65
  br i1 %t68, label %bb11, label %bb1
bb11:
  br label %bb3
bb12:
  br label %bb3
bb13:
  %t70 = load i1, ptr %l2, !tbaa !21
  store i1 %t70, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

define internal i1 @olang_lambda_37(ptr %env, i64 %a0) #0 {
entry:
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load i64, ptr @G_2ecompiler_2ftypes_2eResultVar, !tbaa !24
  %t5 = icmp eq i64 %a0, %t2
  store i1 %t5, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define available_externally ptr @__olang_scope_hold(ptr %s) alwaysinline {
entry:
  %none = icmp eq ptr %s, null
  br i1 %none, label %plain, label %look
look:
  ; atomic: on a scope that is no stand-in this word is its parts list, which other threads push onto (__olang_scope_part)
  %mp = getelementptr %olang.scope, ptr %s, i32 0, i32 4
  %m = load atomic ptr, ptr %mp monotonic, align 8
  %fresh = icmp eq ptr %m, @__olang_standin_mark
  br i1 %fresh, label %make, label %kept
kept:
  %mi = ptrtoint ptr %m to i64
  %bit = and i64 %mi, 1
  %has = icmp ne i64 %bit, 0
  br i1 %has, label %keeper, label %plain
keeper:
  %ki = and i64 %mi, -2
  %k = inttoptr i64 %ki to ptr
  ret ptr %k
make:
  %f = call ptr @__olang_standin_keeper(ptr %s)
  ret ptr %f
plain:
  ret ptr %s
}
@olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1 = weak hidden constant i1 false
declare ptr @__olang_region_make(ptr) noinline
@.d38 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"assigned " }>, align 8
@.d39 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
define available_externally noalias ptr @__olang_held_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
@.d40 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d41 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"#" }>, align 8
@.d42 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"noderived " }>, align 8
@.d43 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"?" }>, align 8
@.d44 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"apart " }>, align 8
define internal i1 @olang_lambda_45(ptr %env, ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l4 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLess(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
  store i1 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i1, ptr %l4, !tbaa !21
  store i1 %t6, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d46 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@olang_2esole_2ecompiler_2fscope_3aScoper_2e327 = weak hidden constant i1 false
declare void @__olang_region_release_part(ptr, i64) noinline
@.d47 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d48 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cI64_3e_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cI64_3e_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 8
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

@olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0 = weak hidden constant i1 false
declare ptr @__olang_region_make_part(ptr) noinline
define internal i1 @olang_lambda_49(ptr %env, i64 %a0, i64 %a1) #0 {
entry:
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t5 = icmp slt i64 %a0, %a1
  store i1 %t5, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

declare ptr @__olang_region_or(ptr, ptr)
declare void @__olang_region_settle_in(ptr, ptr)
@.d50 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\09" }>, align 8
@.d51 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"," }>, align 8
@.d52 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
define internal i1 @olang_lambda_53(ptr %env, ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l4 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLess(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
  store i1 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i1, ptr %l4, !tbaa !21
  store i1 %t6, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d54 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"field " }>, align 8
@.d55 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" of " }>, align 8
@.d56 = private constant <{ i64, [37 x i8] }> <{ i64 0, [37 x i8] c": no constructor parameter to bind to" }>, align 8
@.d57 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d58 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d59 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d60 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d61 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@olang_2esole_2ecompiler_2fscope_3acompRun_2e20 = weak hidden constant i1 false
define linkonce_odr void @olang_2emir_2eHelperKind_2eZero_2ecompiler_2fscope_3awalked(ptr %out, ptr %v0) #0 {
entry:
  %l0 = alloca %"compiler/scope:walked"
  %t1 = alloca %"compiler/scope:walked", align 8
  br label %start
start:
  br label %bb0
bb0:
  call void @compiler_2fscope_3awalked_2ector(ptr %t1, ptr %v0)
  call void @llvm.memmove.p0.p0.i64(ptr %l0, ptr %t1, i64 424, i1 false)
  br label %bb1
bb1:
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l0, i64 424, i1 false)
  br label %ret
ret:
  ret void
}

@.d62 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"a longer-lived scope" }>, align 8
@.d63 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"the scope of what '" }>, align 8
@.d64 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"' refers to" }>, align 8
@.d65 = private constant <{ i64, [34 x i8] }> <{ i64 0, [34 x i8] c"the tail scope of its become chain" }>, align 8
@.d66 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"the result scope" }>, align 8
@.d67 = private constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c"where the generator lives" }>, align 8
@.d68 = private constant <{ i64, [37 x i8] }> <{ i64 0, [37 x i8] c"the scope of what the lambda captured" }>, align 8
@.d69 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"a longer-lived scope" }>, align 8
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
declare void @__olang_scope_close_owned(ptr) noinline
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
@.d70 = private unnamed_addr constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"scope.Term.None" }>, align 8
@.d71 = private unnamed_addr constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"scope.Term.Block" }>, align 8
@.d72 = private unnamed_addr constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d73 = private unnamed_addr constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d74 = private unnamed_addr constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"scope.Term.Var" }>, align 8
@.d75 = private unnamed_addr constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"scope.Term.Program" }>, align 8
@.d76 = private unnamed_addr constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"scope.Term.Derived" }>, align 8
@.d77 = private unnamed_addr constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d78 = private unnamed_addr constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"scope.Term.Set" }>, align 8
@.d79 = private unnamed_addr constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"scope.Term.Untraced" }>, align 8
declare ptr @__olang_sb_grow(ptr, i64) noinline
define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 8
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScope_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 24
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 24
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fv_H37dabf8663d733dfb3cf8a6ba127be58(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %a0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = call { i64, ptr } @olang_2emir_2eHelperKind_2eCopy_2eArray_3cstd_2fprelude_2fmap_3aMapEntry_3cI64_2c_20std__Hc31c075a081277beb11a6149e950d3c3(ptr %v0, { i64, ptr } %t4)
  store { i64, ptr } %t6, ptr %l3
  br label %bb1
bb1:
  %t7 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t8 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t7, ptr %t8, !tbaa !27
  %t9 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 1
  %t10 = load { i64, ptr }, ptr %t9, !tbaa !27
  store { i64, ptr } %t10, ptr %l4, !tbaa !27
  %t11 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t11, 0
  store i64 %t12, ptr %l5, !tbaa !24
  %t13 = load i64, ptr %l5, !tbaa !24
  %t14 = mul i64 %t13, 8
  %t15 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t14)
  %t16 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %t15, 1
  store { i64, ptr } %t17, ptr %l6, !tbaa !27
  %t18 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = load i64, ptr %l5, !tbaa !24
  %t23 = mul i64 %t22, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t19, ptr %t21, i64 %t23, i1 false)
  %t24 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t25 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 1
  store { i64, ptr } %t24, ptr %t25, !tbaa !27
  %t26 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 2
  %t27 = load { i64, ptr }, ptr %t26, !tbaa !27
  store { i64, ptr } %t27, ptr %l7, !tbaa !27
  %t28 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t28, 0
  store i64 %t29, ptr %l8, !tbaa !24
  %t30 = load i64, ptr %l8, !tbaa !24
  %t31 = mul i64 %t30, 8
  %t32 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t31)
  %t33 = insertvalue { i64, ptr } undef, i64 %t30, 0
  %t34 = insertvalue { i64, ptr } %t33, ptr %t32, 1
  store { i64, ptr } %t34, ptr %l9, !tbaa !27
  %t35 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !27
  %t37 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t38 = load ptr, ptr %t37, !tbaa !27
  %t39 = load i64, ptr %l8, !tbaa !24
  %t40 = mul i64 %t39, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t36, ptr %t38, i64 %t40, i1 false)
  %t41 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t42 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 2
  store { i64, ptr } %t41, ptr %t42, !tbaa !27
  %t43 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t43, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec__Hdbcf217951d8a5e6be477b9bbf1b3074(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = call { i64, ptr } @olang_2emir_2eHelperKind_2eCopy_2eArray_3cstd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aDerivedArg_3e_3e(ptr %v0, { i64, ptr } %t4)
  store { i64, ptr } %t6, ptr %l3
  br label %bb1
bb1:
  %t7 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t8 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t7, ptr %t8, !tbaa !27
  %t9 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr i1 @olang_2emir_2eHelperKind_2eEqual_2eArray_3ccompiler_2ftyped_3aScope_3e({ i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i1
  %l3 = alloca i64
  %l6 = alloca i64
  %l10 = alloca i1
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t2 = extractvalue { i64, ptr } %t1, 0
  store i64 %t2, ptr %l3, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t4 = extractvalue { i64, ptr } %t3, 0
  %t5 = load i64, ptr %l3, !tbaa !24
  %t7 = icmp eq i64 %t5, %t4
  br i1 %t7, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb8
bb2:
  store i64 0, ptr %l6, !tbaa !24
  br label %bb3
bb3:
  %t9 = load i64, ptr %l6, !tbaa !24
  %t10 = load i64, ptr %l3, !tbaa !24
  %t11 = icmp slt i64 %t9, %t10
  br i1 %t11, label %bb4, label %bb5
bb4:
  %t13 = load i64, ptr %l6, !tbaa !24
  %t14 = getelementptr { i64, ptr }, ptr %l0, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = getelementptr { i64, [2 x i64] }, ptr %t15, i64 %t13
  %t17 = load i64, ptr %l6, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l1, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr { i64, [2 x i64] }, ptr %t19, i64 %t17
  %t23 = call i1 @olang_2emir_2eHelperKind_2eEqual_2ecompiler_2ftyped_3aScope(ptr %t16, ptr %t20)
  store i1 %t23, ptr %l10
  br label %bb6
bb5:
  br label %bb8
bb6:
  %t24 = load i1, ptr %l10, !tbaa !21
  br i1 %t24, label %bb7, label %bb1
bb7:
  %t25 = load i64, ptr %l6, !tbaa !24
  %t26 = add i64 %t25, 1
  store i64 %t26, ptr %l6, !tbaa !24
  br label %bb3
bb8:
  %t27 = load i1, ptr %l2, !tbaa !21
  store i1 %t27, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define linkonce_odr i1 @olang_2emir_2eHelperKind_2eEqual_2eArray_3cBool_3e({ i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i1
  %l3 = alloca i64
  %l6 = alloca i64
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t2 = extractvalue { i64, ptr } %t1, 0
  store i64 %t2, ptr %l3, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t4 = extractvalue { i64, ptr } %t3, 0
  %t5 = load i64, ptr %l3, !tbaa !24
  %t7 = icmp eq i64 %t5, %t4
  br i1 %t7, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb7
bb2:
  store i64 0, ptr %l6, !tbaa !24
  br label %bb3
bb3:
  %t9 = load i64, ptr %l6, !tbaa !24
  %t10 = load i64, ptr %l3, !tbaa !24
  %t11 = icmp slt i64 %t9, %t10
  br i1 %t11, label %bb4, label %bb5
bb4:
  %t13 = load i64, ptr %l6, !tbaa !24
  %t14 = getelementptr { i64, ptr }, ptr %l0, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = getelementptr i1, ptr %t15, i64 %t13
  %t17 = load i1, ptr %t16, !tbaa !31
  %t18 = load i64, ptr %l6, !tbaa !24
  %t19 = getelementptr { i64, ptr }, ptr %l1, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !27
  %t21 = getelementptr i1, ptr %t20, i64 %t18
  %t22 = load i1, ptr %t21, !tbaa !31
  %t25 = icmp eq i1 %t17, %t22
  br i1 %t25, label %bb6, label %bb1
bb5:
  br label %bb7
bb6:
  %t27 = load i64, ptr %l6, !tbaa !24
  %t28 = add i64 %t27, 1
  store i64 %t28, ptr %l6, !tbaa !24
  br label %bb3
bb7:
  %t29 = load i1, ptr %l2, !tbaa !21
  store i1 %t29, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define linkonce_odr i1 @olang_2emir_2eHelperKind_2eEqual_2eArray_3cI64_3e({ i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i1
  %l3 = alloca i64
  %l6 = alloca i64
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t2 = extractvalue { i64, ptr } %t1, 0
  store i64 %t2, ptr %l3, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t4 = extractvalue { i64, ptr } %t3, 0
  %t5 = load i64, ptr %l3, !tbaa !24
  %t7 = icmp eq i64 %t5, %t4
  br i1 %t7, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb7
bb2:
  store i64 0, ptr %l6, !tbaa !24
  br label %bb3
bb3:
  %t9 = load i64, ptr %l6, !tbaa !24
  %t10 = load i64, ptr %l3, !tbaa !24
  %t11 = icmp slt i64 %t9, %t10
  br i1 %t11, label %bb4, label %bb5
bb4:
  %t13 = load i64, ptr %l6, !tbaa !24
  %t14 = getelementptr { i64, ptr }, ptr %l0, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = getelementptr i64, ptr %t15, i64 %t13
  %t17 = load i64, ptr %t16, !tbaa !34
  %t18 = load i64, ptr %l6, !tbaa !24
  %t19 = getelementptr { i64, ptr }, ptr %l1, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !27
  %t21 = getelementptr i64, ptr %t20, i64 %t18
  %t22 = load i64, ptr %t21, !tbaa !34
  %t25 = icmp eq i64 %t17, %t22
  br i1 %t25, label %bb6, label %bb1
bb5:
  br label %bb7
bb6:
  %t27 = load i64, ptr %l6, !tbaa !24
  %t28 = add i64 %t27, 1
  store i64 %t28, ptr %l6, !tbaa !24
  br label %bb3
bb7:
  %t29 = load i1, ptr %l2, !tbaa !21
  store i1 %t29, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define linkonce_odr i1 @olang_2emir_2eHelperKind_2eEqual_2eArray_3ccompiler_2ftyped_3aExpr_3f_26_3e({ i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i1
  %l3 = alloca i64
  %l6 = alloca i64
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t2 = extractvalue { i64, ptr } %t1, 0
  store i64 %t2, ptr %l3, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t4 = extractvalue { i64, ptr } %t3, 0
  %t5 = load i64, ptr %l3, !tbaa !24
  %t7 = icmp eq i64 %t5, %t4
  br i1 %t7, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb7
bb2:
  store i64 0, ptr %l6, !tbaa !24
  br label %bb3
bb3:
  %t9 = load i64, ptr %l6, !tbaa !24
  %t10 = load i64, ptr %l3, !tbaa !24
  %t11 = icmp slt i64 %t9, %t10
  br i1 %t11, label %bb4, label %bb5
bb4:
  %t13 = load i64, ptr %l6, !tbaa !24
  %t14 = getelementptr { i64, ptr }, ptr %l0, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = getelementptr ptr, ptr %t15, i64 %t13
  %t17 = load ptr, ptr %t16, !tbaa !39
  %t18 = load i64, ptr %l6, !tbaa !24
  %t19 = getelementptr { i64, ptr }, ptr %l1, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !27
  %t21 = getelementptr ptr, ptr %t20, i64 %t18
  %t22 = load ptr, ptr %t21, !tbaa !39
  %t25 = icmp eq ptr %t17, %t22
  br i1 %t25, label %bb6, label %bb1
bb5:
  br label %bb7
bb6:
  %t27 = load i64, ptr %l6, !tbaa !24
  %t28 = add i64 %t27, 1
  store i64 %t28, ptr %l6, !tbaa !24
  br label %bb3
bb7:
  %t29 = load i1, ptr %l2, !tbaa !21
  store i1 %t29, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d80 = private unnamed_addr constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"typed.BodyOf.Fn" }>, align 8
@.d81 = private unnamed_addr constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"typed.BodyOf.Ctor" }>, align 8
@.d82 = private unnamed_addr constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"typed.BodyOf.Case" }>, align 8
@.d83 = private unnamed_addr constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"typed.BodyOf.Dtor" }>, align 8
@.d84 = private unnamed_addr constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"typed.BodyOf.Lambda" }>, align 8
@.d85 = private unnamed_addr constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"typed.BodyOf.Test" }>, align 8
@.d86 = private unnamed_addr constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"typed.BodyOf.Global" }>, align 8
@.d87 = private unnamed_addr constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"typed.BodyOf.Cond" }>, align 8
@.d88 = private unnamed_addr constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"typed.BodyOf.Contract" }>, align 8
define linkonce_odr void @olang_2emir_2eHelperKind_2eRender_2ecompiler_2ftyped_3aContractKind(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load i32, ptr %a0, !range !{i32 0, i32 1}
  %t3 = sext i32 %t2 to i64
  switch i64 %t3, label %bb1 [ i64 0, label %bb2 ]
bb1:
  br label %ret
bb2:
  %t5 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d90, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d90, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t5, i64 %t6)
  br label %bb1
ret:
  ret void
}

@.d89 = private unnamed_addr constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"typed.BodyOf.Thunk" }>, align 8
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3afsRow_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 32
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 32
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3afsOpen_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 8
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

@__olang_standin_mark = external global i64
declare ptr @__olang_standin_keeper(ptr) noinline
define available_externally noalias ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  %head = load ptr, ptr %scope, !tbaa !59
  %isslot = icmp eq ptr %head, @__olang_slot_chunk
  br i1 %isslot, label %slot, label %plain
slot:
  %s = call ptr @__olang_slot_alloc(ptr %scope, i64 %rawsize)
  ret ptr %s
plain:
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr { i64, ptr } @olang_2emir_2eHelperKind_2eCopy_2eArray_3cstd_2fprelude_2fmap_3aMapEntry_3cI64_2c_20std__Hc31c075a081277beb11a6149e950d3c3(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l6 = alloca %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613"
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t2 = extractvalue { i64, ptr } %t1, 0
  store i64 %t2, ptr %l1, !tbaa !24
  %t3 = load i64, ptr %l1, !tbaa !24
  %t4 = mul i64 %t3, 40
  %t5 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t4)
  %t6 = insertvalue { i64, ptr } undef, i64 %t3, 0
  %t7 = insertvalue { i64, ptr } %t6, ptr %t5, 1
  store { i64, ptr } %t7, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  %t8 = load i64, ptr %l3, !tbaa !24
  %t9 = load i64, ptr %l1, !tbaa !24
  %t10 = icmp slt i64 %t8, %t9
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = load i64, ptr %l3, !tbaa !24
  %t13 = getelementptr { i64, ptr }, ptr %l0, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !27
  %t15 = getelementptr %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613", ptr %t14, i64 %t12
  %t17 = call %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMapEntry_3cI64_2c_20std_2fprelud_Hc8a994261b444ea12c5b83da9413a98f(ptr %v0, ptr %t15)
  store %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613" %t17, ptr %l6
  br label %bb4
bb3:
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t18, ptr %rv
  br label %ret
bb4:
  %t19 = load %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613", ptr %l6
  %t20 = load i64, ptr %l3, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613", ptr %t22, i64 %t20
  store %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613" %t19, ptr %t23
  %t24 = load i64, ptr %l3, !tbaa !24
  %t25 = add i64 %t24, 1
  store i64 %t25, ptr %l3, !tbaa !24
  br label %bb1
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define linkonce_odr { i64, ptr } @olang_2emir_2eHelperKind_2eCopy_2eArray_3cstd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aDerivedArg_3e_3e(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t2 = extractvalue { i64, ptr } %t1, 0
  store i64 %t2, ptr %l1, !tbaa !24
  %t3 = load i64, ptr %l1, !tbaa !24
  %t4 = mul i64 %t3, 32
  %t5 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t4)
  %t6 = insertvalue { i64, ptr } undef, i64 %t3, 0
  %t7 = insertvalue { i64, ptr } %t6, ptr %t5, 1
  store { i64, ptr } %t7, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  %t8 = load i64, ptr %l3, !tbaa !24
  %t9 = load i64, ptr %l1, !tbaa !24
  %t10 = icmp slt i64 %t8, %t9
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = load i64, ptr %l3, !tbaa !24
  %t13 = getelementptr { i64, ptr }, ptr %l0, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !27
  %t15 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t14, i64 %t12
  %t17 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aDerivedArg_3e(ptr %v0, ptr %t15)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t17, ptr %l6
  br label %bb4
bb3:
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t18, ptr %rv
  br label %ret
bb4:
  %t19 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l6
  %t20 = load i64, ptr %l3, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t22, i64 %t20
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t19, ptr %t23
  %t24 = load i64, ptr %l3, !tbaa !24
  %t25 = add i64 %t24, 1
  store i64 %t25, ptr %l3, !tbaa !24
  br label %bb1
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define linkonce_odr i1 @olang_2emir_2eHelperKind_2eEqual_2ecompiler_2ftyped_3aScope(ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca i64
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %t1, !range !{i64 0, i64 9}
  store i64 %t2, ptr %l3, !tbaa !24
  %t3 = load ptr, ptr %l1, !tbaa !29
  %t4 = load i64, ptr %t3, !range !{i64 0, i64 9}
  %t5 = load i64, ptr %l3, !tbaa !24
  %t7 = icmp eq i64 %t5, %t4
  br i1 %t7, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb15
bb2:
  %t9 = load i64, ptr %l3, !tbaa !24
  switch i64 %t9, label %bb3 [ i64 1, label %bb4 i64 2, label %bb5 i64 4, label %bb6 i64 7, label %bb7 i64 8, label %bb8 ]
bb3:
  br label %bb15
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr { i64, [2 x i64] }, ptr %t10, i32 0, i32 1
  %t12 = getelementptr { i32 }, ptr %t11, i32 0, i32 0
  %t13 = load i32, ptr %t12
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t15 = getelementptr { i64, [2 x i64] }, ptr %t14, i32 0, i32 1
  %t16 = getelementptr { i32 }, ptr %t15, i32 0, i32 0
  %t17 = load i32, ptr %t16
  %t20 = icmp eq i32 %t13, %t17
  br i1 %t20, label %bb9, label %bb1
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr { i64, [2 x i64] }, ptr %t22, i32 0, i32 1
  %t24 = getelementptr { i64 }, ptr %t23, i32 0, i32 0
  %t25 = load i64, ptr %t24
  %t26 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr { i64, [2 x i64] }, ptr %t26, i32 0, i32 1
  %t28 = getelementptr { i64 }, ptr %t27, i32 0, i32 0
  %t29 = load i64, ptr %t28
  %t32 = icmp eq i64 %t25, %t29
  br i1 %t32, label %bb10, label %bb1
bb6:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr { i64, [2 x i64] }, ptr %t34, i32 0, i32 1
  %t36 = getelementptr { i32 }, ptr %t35, i32 0, i32 0
  %t37 = load i32, ptr %t36
  %t38 = load ptr, ptr %l1, !tbaa !29
  %t39 = getelementptr { i64, [2 x i64] }, ptr %t38, i32 0, i32 1
  %t40 = getelementptr { i32 }, ptr %t39, i32 0, i32 0
  %t41 = load i32, ptr %t40
  %t44 = icmp eq i32 %t37, %t41
  br i1 %t44, label %bb11, label %bb1
bb7:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr { i64, [2 x i64] }, ptr %t46, i32 0, i32 1
  %t48 = getelementptr { i64 }, ptr %t47, i32 0, i32 0
  %t49 = load i64, ptr %t48
  %t50 = load ptr, ptr %l1, !tbaa !29
  %t51 = getelementptr { i64, [2 x i64] }, ptr %t50, i32 0, i32 1
  %t52 = getelementptr { i64 }, ptr %t51, i32 0, i32 0
  %t53 = load i64, ptr %t52
  %t56 = icmp eq i64 %t49, %t53
  br i1 %t56, label %bb12, label %bb1
bb8:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr { i64, [2 x i64] }, ptr %t58, i32 0, i32 1
  %t60 = getelementptr { i64, i64 }, ptr %t59, i32 0, i32 0
  %t61 = load i64, ptr %t60
  %t62 = load ptr, ptr %l1, !tbaa !29
  %t63 = getelementptr { i64, [2 x i64] }, ptr %t62, i32 0, i32 1
  %t64 = getelementptr { i64, i64 }, ptr %t63, i32 0, i32 0
  %t65 = load i64, ptr %t64
  %t68 = icmp eq i64 %t61, %t65
  br i1 %t68, label %bb13, label %bb1
bb9:
  br label %bb3
bb10:
  br label %bb3
bb11:
  br label %bb3
bb12:
  br label %bb3
bb13:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr { i64, [2 x i64] }, ptr %t70, i32 0, i32 1
  %t72 = getelementptr { i64, i64 }, ptr %t71, i32 0, i32 1
  %t73 = load i64, ptr %t72
  %t74 = load ptr, ptr %l1, !tbaa !29
  %t75 = getelementptr { i64, [2 x i64] }, ptr %t74, i32 0, i32 1
  %t76 = getelementptr { i64, i64 }, ptr %t75, i32 0, i32 1
  %t77 = load i64, ptr %t76
  %t80 = icmp eq i64 %t73, %t77
  br i1 %t80, label %bb14, label %bb1
bb14:
  br label %bb3
bb15:
  %t82 = load i1, ptr %l2, !tbaa !21
  store i1 %t82, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d90 = private unnamed_addr constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c"typed.ContractKind.Req" }>, align 8
@__olang_slot_chunk = external global %olang.chunk
declare noalias ptr @__olang_slot_alloc(ptr, i64) noinline
define linkonce_odr %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMapEntry_3cI64_2c_20std_2fprelud_Hc8a994261b444ea12c5b83da9413a98f(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %rv = alloca %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613", ptr %a0
  store %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613", ptr %l1, i32 0, i32 1
  %t5 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aDerivedArg_3e(ptr %v0, ptr %t3)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %l3
  br label %bb1
bb1:
  %t6 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  %t7 = getelementptr %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613", ptr %l1, i32 0, i32 1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t6, ptr %t7
  %t8 = load %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613", ptr %l1
  store %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613", ptr %rv
  ret %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aDerivedArg_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 40
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 40
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cmut_20comp_H43e0789510fdd6e46eb40242e8ebac44(ptr %v0, ptr %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cmut_20comp_H7e0984339031c6a833031be461c3ee4e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fscope_3acompRun_26_3e_H0296d27dcb58febef67dd9f1f1b292fb(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fscope_3acompRun_26_3e_H665b0c71977ef42adbc51fe96e6e85ee(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3amarkRead_3e_2eLen_3ccompiler_2fscope_3amarkRead_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3asumRead_3e_2eLen_3ccompiler_2fscope_3asumRead_3e(ptr %v0, ptr %a0)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aTaken_2eCount(ptr %v0, ptr %a0)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fscope_3asummary_26_3e_Hf018e585e117ec5a1eef851c731bcf79(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3arel_3e_2eLen_3ccompiler_2fscope_3arel_3e(ptr %v0, ptr %a0)
declare %"compiler/scope:rel" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3arel_3e_2eAt_3ccompiler_2fscope_3arel_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %a0)
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eLen_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %a0)
declare { i64, [2 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eAt_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_1668eb2d997973a7_ab4d69ddc8fad23 = external constant [0 x i8]
declare ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunAway(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare ptr @compiler_2fscope_2eunPassed(ptr %v0, ptr %v1, ptr %a0)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisFresh(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_ca9fbb609f85e0bf_654dd6319f2fbb3b = external constant [0 x i8]
declare { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScopeVar_3e_2eAt_3ccompiler_2ftyped_3aScopeVar_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_34786756d9cc10ef_3d198681fdad2233 = external constant [0 x i8]
declare %"compiler/scope:fnRecs" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2erecsOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fscope_2esortedRecs(ptr %v0, ptr %v1, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3afnRec_3e_2eLen_3ccompiler_2fscope_3afnRec_3e(ptr %v0, ptr %a0)
declare %"compiler/scope:fnRec" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3afnRec_3e_2eAt_3ccompiler_2fscope_3afnRec_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScopeVar_3e_2eLen_3ccompiler_2ftyped_3aScopeVar_3e(ptr %v0, ptr %a0)
@olang_loc_4facdfbbce427d16_bc8d42a38505ceba = external constant [0 x i8]
declare i1 @compiler_2fscope_2ecapVarOf(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
@olang_loc_5f5e86560cf90c37_fbfb89ab9edf5b3b = external constant [0 x i8]
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v0, ptr %a0)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisRef(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftyped_2ePure(ptr %v0, ptr %a0)
declare i1 @compiler_2fdiag_2ecompiler_2fdiag_3aTaken_2eSame(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fscope_2esameSummary(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, ptr } @compiler_2fscope_2esummaryDiff(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlan_3e_2eAt_3ccompiler_2ftyped_3aPlan_3e(ptr %out, ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eEq_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eEq_3cI64_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScope_3e_2eEq_3ccompiler_2ftyped_3aScope_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cc_H80e5c7f116c5eff77ef32968f58f5b4d(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3ccompiler_2_H16eefdf2f060cccd64cc684009ec3f7f(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eLen(ptr %v0, ptr %a0)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eCount(ptr %v0, ptr %a0)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eForget(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aGap_3e_2eLen_3ccompiler_2fscope_3aGap_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aGap_3e_2eTruncate_3ccompiler_2fscope_3aGap_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_6a87b3eb83e8e753_81a9677ce8feda27 = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2edtorBody(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3ccompiler_2ftyped_3aCapture_26__H177492c3cd3f7b9ef9bf3a7d88bd5491(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Array_3ccompiler_2ftyped_3aCa_H075f4750b9fbd2a4764c573a9763e3f6(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @compiler_2ftyped_2eCalledBody(ptr %v0, ptr %a0)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2eToArra_Hf068248a0eebef25a501bc77775c8cbf(ptr %v0, ptr %v1, ptr %a0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Array_3ccompiler_2ftyped_3aBl_H2003e1165b947ef2f9b081fd0aeb277d(ptr %v0, ptr %a0, i64 %a1, { i64, ptr } %a2)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %a0, i32 %a1)
declare %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %v0, i64 %a0, i64 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1308596c866d4be061d9da9113abde88(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1, i1 %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %a0, i1 %a1)
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2evisit(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_be4231f99dfc50a7_6a00356b78c435db = external constant [0 x i8]
declare %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_badc8ccdfeb92288_a041b08d3fc96aec = external constant [0 x i8]
@olang_loc_58d2ded8d237a84_721cf65762561fa8 = external constant [0 x i8]
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eloopElement(ptr %v0, ptr %a0, i64 %a1)
declare { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eresultTerm(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fscope_2eisBlockTerm({ i64, [2 x i64] } %a0)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2earenaValue(ptr %v0, ptr %a0, i32 %a1)
declare { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2estorageTerm(ptr %v0, ptr %a0)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aTerm_2eRuns({ i64, [2 x i64] } %a0)
declare i1 @compiler_2fscope_2eflHas(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eholds(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_36d9ea1b8e0be675_6ae7f20c6157de79 = external constant [0 x i8]
declare ptr @compiler_2ftyped_2eCall_2eOf(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_318ee1b3da3da37b_dfd49c38f0c44407 = external constant [0 x i8]
declare i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebodyOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_b8fb270bdd73210c_150398a92061e6e8 = external constant [0 x i8]
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2evalueCall(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_6763258997513a41_ec0b86cc45ca0bbd = external constant [0 x i8]
declare i32 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecalleeType(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eresultVarOf(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_6767537ca10246ba_b3f77aefc3649fd6 = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecallRels(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eforcedBy(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esummed(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ewalkLocal(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_5eb3bfaaf86e9baf_8dddb03606b5f843 = external constant [0 x i8]
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRole(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eRoleCtor = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@olang_loc_8d9c16c9e7a15650_5ac0d9bfaf5af2b4 = external constant [0 x i8]
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esumBuilds(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2egenBody(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eforced(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecopiedChoice(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2fscope_2echoiceReads(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eHas_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %a0)
@olang_loc_7b1e363353e9e01f_5d568e34003a167b = external constant [0 x i8]
declare { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_He9bc6cfad7ef603960b4717f3121b8e8(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @compiler_2fscope_2eisNameChar(i8 %a0)
declare %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %a0, i32 %a1)
declare i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2edeclOf(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eapartDecl(ptr %v0, ptr %a0, i64 %a1)
declare { i32, %"compiler/scope:fsBody" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fscope_3afsBody_3e__Hb5653faf0f4c5db756b53371f9538b9d(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3afsOpen_3e_2eLen_3ccompiler_2fscope_3afsOpen_3e(ptr %v0, ptr %a0)
declare %"compiler/scope:fsOpen" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3afsOpen_3e_2eAt_3ccompiler_2fscope_3afsOpen_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2ector(ptr %v0, i64 %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3afsRow_3e_2eLen_3ccompiler_2fscope_3afsRow_3e(ptr %v0, ptr %a0)
declare %"compiler/scope:fsRow" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3afsRow_3e_2eAt_3ccompiler_2fscope_3afsRow_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eView_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %v1, ptr %a0)
declare i1 @std_2fprelude_2farray_2eArray_3ccompiler_2fscope_3aTerm_3e_2eSome_3ccompiler_2fscope_3aTerm_2c_20_3f_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1c, ptr %a1e)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2ePush_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1)
declare { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2etermOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eflAdd(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecarried(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2edropViewed(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecarries(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eflExpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_6038e9a8843bd167_10c714601f259253 = external constant [0 x i8]
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eflPlace(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eflPlaceRoot(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_c1fa5f0b83cd997f_623e25aaa52b89ab = external constant [0 x i8]
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v0, ptr %a0)
declare i1 @compiler_2fscope_2eflThroughRef(ptr %v0, ptr %a0)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eoutside(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eflBlockOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ereturnedArrays(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare i64 @compiler_2fscope_2ewholeValueRead(ptr %v0, ptr %a0)
@olang_loc_86dbdc94d883d21d_a5f7ab2189e86539 = external constant [0 x i8]
@olang_loc_815b49be05c0135_ff7bc6f5d03d3901 = external constant [0 x i8]
@olang_loc_8ac0dfde81ed52b7_ecd118d92b351383 = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eClear_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2efsReach(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2efsParts(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eKeys_3cI64_2c_20Bool_3e(ptr %v0, ptr %v1, ptr %a0)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapKeyIter_3cI64_2c_20Bool_3e_2eNext_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopeVarsOf(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i1 @std_2fprelude_2farray_2eArray_3cI64_3e_2eSome_3cI64_2c_20_3f_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1c, ptr %a1e)
@G_2ecompiler_2ftypes_2eRoleTail = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eWithRole(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScopeVar_3e_2ePush_3ccompiler_2ftyped_3aScopeVar_3e(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H0d83a40c67cd8749e6caf886dac77c3a(ptr %v0, ptr %v1, ptr %a0)
declare { i32, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapKeyIter_3cstd_2fpair_3aPair_3cI64_2c_20I6_H50b542c856ab641bdb3083563d5a1f0c(ptr %v0, ptr %a0)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanonNamed(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eNameOf(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H1642129570dad448bb7dcc47c334de83(ptr %v0, ptr %v1, ptr %a0, ptr %a1c, ptr %a1e)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2eJoin(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2fscope_2ehashText(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_9476cc7193074e76_e8b6eb41d568f08a = external constant [0 x i8]
@olang_loc_80dc90fe4960987f_e8c65fabb0c3bdbb = external constant [0 x i8]
@olang_loc_e199b27d8a069b60_e8a91e9929fc614c = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2efirstToken(ptr %v0, ptr %a0, i64 %a1, %"compiler/source:Span" %a2)
declare i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2emadeLocal(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2)
@olang_loc_e507d0d93dcb1267_6d41e0722b8ffb6b = external constant [0 x i8]
declare { i32, ptr } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_H68cd31c3dbcdb47f3349b834dda1e07d(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_bdf36c9557ac347f_98a403497664a493 = external constant [0 x i8]
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResultFrom(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
@olang_loc_c3a4635b73df0d44_b0216f4acd182078 = external constant [0 x i8]
@olang_loc_40ec225b43a9c35_aa9faf1719a6cb49 = external constant [0 x i8]
@olang_loc_ee34d1998e8cb262_dc9f2cfe1a0305ee = external constant [0 x i8]
@olang_loc_b2f9ba032aa0cd37_ded861412cec268b = external constant [0 x i8]
@olang_loc_6789d922954f6d60_a7a35b45139b1b94 = external constant [0 x i8]
declare %"compiler/scope:markRead" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3amarkRead_3e_2eAt_3ccompiler_2fscope_3amarkRead_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cI_Heebd28230b8fdd871dbb93ccdeb5ff7f(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cI_H5b4ed7dba3fb4e44f8784ebbf4461977(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a2)
declare %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cI_H8538c7ff23a6122b13758d112708dba7(ptr %v0, ptr %v1, ptr %a0)
declare { i32, %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapIter_3cI64_2c_20std_2fprelude_2fvec_3aVec_H07094359971f7e5c30038a271a96bfe1(ptr %v0, ptr %v1, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSort_3cI64_2c_20_3f_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1c, ptr %a1e)
declare ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esum(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eargOfVar(ptr %v0, ptr %v1, ptr %a0, ptr %a1, { i64, [2 x i64] } %a2)
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enoteMadeNamed(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, ptr %a2, i64 %a3, { i64, ptr } %a4, i64 %a5)
@olang_loc_4a416fba8e98e106_47db22c0e1b8e2f2 = external constant [0 x i8]
@olang_loc_da1486de58138450_28784370eb22bac = external constant [0 x i8]
@olang_loc_b45386ce0764ddbe_c7946361eac41962 = external constant [0 x i8]
@olang_loc_535fab4b1fdbd0bf_63b8873d2454f763 = external constant [0 x i8]
@G_2ecompiler_2ftypes_2eUnknownT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
@olang_loc_9a4bec7adca8cb6_596724450ae2f102 = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebindingParam(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H0127831368543eff3b7740d7d3240080(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eRefMut_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H874ab6ecb906549bc54547c0392d06e9(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H31314c4e7281f5029d6d8eb3044cef10(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1, i64 %a2)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisFunc(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_554265ba1528b3d8_d73d8ae267adc184 = external constant [0 x i8]
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisNullLit(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2estaticLiteral(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_c484f993348186a9_88a471068962d75 = external constant [0 x i8]
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2emadeHere(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_7e21c4142f0bda85_cfc7aa0bb53bfe81 = external constant [0 x i8]
@olang_loc_d170603cba6c1f57_8f6ba8e3d258e7eb = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fscope_3acompRun_3f_26_H546292b08567e2b050e63bf3793178cc(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fscope_3acompRun_3f_26_H1a636e2bc42fd10a7cda4fcd89cb80cb(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2emarksOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %a0)
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esoleStmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @compiler_2fscope_2ewholeLocal(ptr %v0, ptr %a0)
@olang_loc_f608b5ac9574e601_8121f96c9d2c9ddd = external constant [0 x i8]
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ereassigned(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_44f4ea69e545b4db_1a5f351e4215689f = external constant [0 x i8]
@olang_loc_cbe1d942d8ca2243_1622ff745ca4c987 = external constant [0 x i8]
@olang_loc_2ca3a0095a8132c2_ea45de2b2f452556 = external constant [0 x i8]
declare ptr @compiler_2fscope_2eletOf(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2etailGiven(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, ptr %a2, ptr %a3)
@olang_loc_95037a04ed425830_2b58d7c0cb40fd64 = external constant [0 x i8]
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2etailStorageGiven(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@G_2ecompiler_2fscope_2ePlaceTail = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00" }>, align 8
declare %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enameSpan(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eviewing(ptr %v0, ptr %a0, i64 %a1, %"compiler/source:Span" %a2)
declare i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eclaimRoot(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eproposeLocal(ptr %v0, ptr %a0, i64 %a1, { i64, [2 x i64] } %a2, i1 %a3)
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epropose(ptr %v0, ptr %v1, ptr %a0, ptr %a1, { i64, [2 x i64] } %a2)
@olang_loc_b16579729361c5ff_a172e348fd9e9523 = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eLen_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNeedsDrop(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2etailCloses(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1)
declare %"compiler/types:DtorWalk" @compiler_2ftypes_3aDtorWalk_2ector(ptr %v0, ptr %v1, ptr %a0)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aDtorWalk_2eHolds(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare void @compiler_2fscope_2ecollectBlock(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShareOf(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epeekTerm(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_9d778c78f7953c66_3314afc5257f7cda = external constant [0 x i8]
@G_2ecompiler_2fscope_2eUseOwn = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
declare i1 @compiler_2fscope_2eownView(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eueBlock(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, i64 %a3, i64 %a4)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eueExpr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, i64 %a3, i64 %a4)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eueTarget(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, i64 %a3, i64 %a4)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2euePlace(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, i64 %a3, i64 %a4)
@olang_loc_32fd86c1b7051b0e_a69c29150a84755a = external constant [0 x i8]
@olang_loc_dc77515c192c1e2e_10e0daed47a736f2 = external constant [0 x i8]
declare i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eviewCall(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eviewRoot(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ewholeRoot(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_825a81e7f5138d1b_866e780fc6f79e3f = external constant [0 x i8]
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %v0)
@G_2ecompiler_2ftypes_2eResultVar = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FF\FF\FF\FF\FF\FF\FF\FF" }>, align 8
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLess(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cI64_3e_3e_2ector(ptr %v0)
declare void @compiler_2fscope_3awalked_2ector(ptr %out, ptr %v0)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
