; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

@olang_loc_40c52deec0fbfe9_e33e74bb91c9aebd = weak_odr constant [53 x i8] c"std/prelude/map.olang:84: array length out of range\0A\00"
@olang_loc_5328cc7117440877_283420f5d8bf160b = weak_odr constant [53 x i8] c"std/prelude/map.olang:84: array length out of range\0A\00"
@olang_loc_5c756f1c7fd9fb1a_515fcd62410723be = weak_odr constant [53 x i8] c"std/prelude/vec.olang:52: slice bounds out of range\0A\00"
@olang_loc_670dfeb3f2fa0f16_8c906a51aa962942 = weak_odr constant [53 x i8] c"std/prelude/map.olang:84: array length out of range\0A\00"
@olang_loc_bc0d418cc61e0d09_ff2fb75d494642cd = weak_odr constant [41 x i8] c"std/prelude/map.olang:273: null reached\0A\00"
