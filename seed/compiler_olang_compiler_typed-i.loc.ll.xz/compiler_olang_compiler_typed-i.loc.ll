; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

@olang_loc_566aaa77629b4060_a5492627dbb84e04 = weak_odr constant [53 x i8] c"std/prelude/vec.olang:36: array length out of range\0A\00"
@olang_loc_5c753acccd66e3c2_be65dbae5fc3022e = weak_odr constant [53 x i8] c"std/prelude/vec.olang:52: slice bounds out of range\0A\00"
@olang_loc_7adc8ff79be60c48_531a1e2ffc7184cc = weak_odr constant [53 x i8] c"std/prelude/vec.olang:52: slice bounds out of range\0A\00"
@olang_loc_a528e5f06755a409_53a1c31d10ad53cd = weak_odr constant [53 x i8] c"std/prelude/vec.olang:52: slice bounds out of range\0A\00"
