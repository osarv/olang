; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

@olang_loc_7e192aa446ad2963_7007564f689f6a6f = weak_odr constant [54 x i8] c"std/prelude/map.olang:111: array length out of range\0A\00"
@olang_loc_92f00b0ccea4b1f6_e2ce27acdbdb707a = weak_odr constant [53 x i8] c"std/prelude/vec.olang:61: slice bounds out of range\0A\00"
@olang_loc_ad7ed497ea8ab222_f6572ed697be0e6e = weak_odr constant [54 x i8] c"std/prelude/map.olang:105: slice bounds out of range\0A\00"
@olang_loc_ca049a7d99d53f9f_ca8eea9c91e2bc6b = weak_odr constant [54 x i8] c"std/prelude/map.olang:102: slice bounds out of range\0A\00"
@olang_loc_dbd918edf400c308_83ffad66e82d10d4 = weak_odr constant [53 x i8] c"std/prelude/vec.olang:61: slice bounds out of range\0A\00"
@olang_loc_ea97b16da2315d46_982e52ed26fd325a = weak_odr constant [53 x i8] c"std/prelude/vec.olang:61: slice bounds out of range\0A\00"
@olang_loc_eeec50a0cf053cb0_8d6ac20d61b583e4 = weak_odr constant [54 x i8] c"std/prelude/map.olang:122: array length out of range\0A\00"
@olang_loc_f29c9b1d4212afc4_fac8523c05d800d8 = weak_odr constant [53 x i8] c"std/prelude/vec.olang:61: slice bounds out of range\0A\00"
