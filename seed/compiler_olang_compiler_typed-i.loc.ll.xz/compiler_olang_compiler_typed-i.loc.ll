; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

@olang_loc_514d9feb9e57aa2a_d8a3046af59ba0ae = weak_odr constant [53 x i8] c"std/prelude/vec.olang:52: array length out of range\0A\00"
@olang_loc_566aaa77629b4060_a5492627dbb84e04 = weak_odr constant [53 x i8] c"std/prelude/vec.olang:36: array length out of range\0A\00"
@olang_loc_ba3e00c90839f1b8_5c7967588773a2d4 = weak_odr constant [53 x i8] c"std/prelude/vec.olang:52: array length out of range\0A\00"
@olang_loc_c67311e406636f11_8df9aeadbb414fed = weak_odr constant [53 x i8] c"std/prelude/vec.olang:52: array length out of range\0A\00"
