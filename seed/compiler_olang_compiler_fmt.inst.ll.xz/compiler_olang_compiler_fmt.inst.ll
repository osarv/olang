; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"std/prelude/list:listState.9783095779ea18337775adeb6569839d" = type { { i64, ptr }, { i64, ptr }, i64, i64, { i64, ptr }, i64, i64, i64 }
define dso_local void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eTruncate_3cBool_3e(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l21 = alloca i64
  %l27 = alloca ptr
  %l30 = alloca { i64, ptr }
  %l38 = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load i64, ptr %l1, !tbaa !24
  %t7 = load ptr, ptr %l2, !tbaa !29
  %t9 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t7, i32 0, i32 7
  %t10 = load i64, ptr %t9, !tbaa !24
  %t13 = icmp sge i64 %t6, %t10
  br i1 %t13, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t15 = load i64, ptr %l1, !tbaa !24
  %t17 = icmp sle i64 %t15, 0
  br i1 %t17, label %bb4, label %bb5
bb4:
  %t19 = load ptr, ptr %l0, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eClear_3cBool_3e(ptr %v0, ptr %t19)
  br label %bb6
bb5:
  br label %bb7
bb6:
  br label %ret
bb7:
  %t21 = load ptr, ptr %l2, !tbaa !29
  %t22 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3cBool_3e_2evacateFrom_3cBool_3e(ptr %v0, ptr %t21, i64 %t22)
  br label %bb8
bb8:
  %t25 = load i64, ptr %l1, !tbaa !24
  %t27 = sub i64 %t25, 1
  %t28 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunk, !tbaa !24
  %t31 = add i64 %t27, %t28
  store i64 %t31, ptr %l3, !tbaa !24
  %t33 = load i64, ptr %l3, !tbaa !24
  %t35 = call i64 @std_2fprelude_2flist_2ehighBit(i64 %t33)
  store i64 %t35, ptr %l21
  br label %bb9
bb9:
  %t36 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunkLog, !tbaa !24
  %t37 = load i64, ptr %l21, !tbaa !24
  %t39 = sub i64 %t37, %t36
  store i64 %t39, ptr %l4, !tbaa !24
  %t41 = load ptr, ptr %l2, !tbaa !29
  %t42 = load i64, ptr %l4, !tbaa !24
  %t44 = add i64 %t42, 1
  %t47 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t41, i32 0, i32 2
  store i64 %t44, ptr %t47, !tbaa !24
  %t48 = load ptr, ptr %l2, !tbaa !29
  store ptr %t48, ptr %l27, !tbaa !29
  %t49 = load ptr, ptr %l2, !tbaa !29
  %t50 = load i64, ptr %l4, !tbaa !24
  %t53 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3cU64_3e_2echunk_3cU64_3e(ptr %v0, ptr %t49, i64 %t50)
  store { i64, ptr } %t53, ptr %l30
  br label %bb10
bb10:
  %t54 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t55 = load ptr, ptr %l27, !tbaa !29
  %t56 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t55, i32 0, i32 4
  store { i64, ptr } %t54, ptr %t56, !tbaa !27
  %t57 = load ptr, ptr %l2, !tbaa !29
  %t58 = load ptr, ptr %l2, !tbaa !29
  %t60 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t58, i32 0, i32 4
  %t61 = load { i64, ptr }, ptr %t60, !tbaa !27
  %t63 = extractvalue { i64, ptr } %t61, 0
  %t66 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t57, i32 0, i32 6
  store i64 %t63, ptr %t66, !tbaa !24
  %t67 = load ptr, ptr %l2, !tbaa !29
  %t68 = load i64, ptr %l3, !tbaa !24
  %t69 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunk, !tbaa !24
  %t70 = load i64, ptr %l4, !tbaa !24
  store i64 %t70, ptr %l38, !tbaa !24
  %t72 = load i64, ptr %l38, !tbaa !24
  %t73 = load i64, ptr %l38, !tbaa !24
  %t74 = shl i64 %t69, %t73
  %t77 = sub i64 %t68, %t74
  %t79 = add i64 %t77, 1
  %t82 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t67, i32 0, i32 5
  store i64 %t79, ptr %t82, !tbaa !24
  %t83 = load ptr, ptr %l2, !tbaa !29
  %t84 = load i64, ptr %l1, !tbaa !24
  %t87 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t83, i32 0, i32 7
  store i64 %t84, ptr %t87, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eTruncate_3cI64_3e(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l21 = alloca i64
  %l27 = alloca ptr
  %l30 = alloca { i64, ptr }
  %l38 = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load i64, ptr %l1, !tbaa !24
  %t7 = load ptr, ptr %l2, !tbaa !29
  %t9 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t7, i32 0, i32 7
  %t10 = load i64, ptr %t9, !tbaa !24
  %t13 = icmp sge i64 %t6, %t10
  br i1 %t13, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t15 = load i64, ptr %l1, !tbaa !24
  %t17 = icmp sle i64 %t15, 0
  br i1 %t17, label %bb4, label %bb5
bb4:
  %t19 = load ptr, ptr %l0, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t19)
  br label %bb6
bb5:
  br label %bb7
bb6:
  br label %ret
bb7:
  %t21 = load ptr, ptr %l2, !tbaa !29
  %t22 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3cI64_3e_2evacateFrom_3cI64_3e(ptr %v0, ptr %t21, i64 %t22)
  br label %bb8
bb8:
  %t25 = load i64, ptr %l1, !tbaa !24
  %t27 = sub i64 %t25, 1
  %t28 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunk, !tbaa !24
  %t31 = add i64 %t27, %t28
  store i64 %t31, ptr %l3, !tbaa !24
  %t33 = load i64, ptr %l3, !tbaa !24
  %t35 = call i64 @std_2fprelude_2flist_2ehighBit(i64 %t33)
  store i64 %t35, ptr %l21
  br label %bb9
bb9:
  %t36 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunkLog, !tbaa !24
  %t37 = load i64, ptr %l21, !tbaa !24
  %t39 = sub i64 %t37, %t36
  store i64 %t39, ptr %l4, !tbaa !24
  %t41 = load ptr, ptr %l2, !tbaa !29
  %t42 = load i64, ptr %l4, !tbaa !24
  %t44 = add i64 %t42, 1
  %t47 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t41, i32 0, i32 2
  store i64 %t44, ptr %t47, !tbaa !24
  %t48 = load ptr, ptr %l2, !tbaa !29
  store ptr %t48, ptr %l27, !tbaa !29
  %t49 = load ptr, ptr %l2, !tbaa !29
  %t50 = load i64, ptr %l4, !tbaa !24
  %t53 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3cU64_3e_2echunk_3cU64_3e(ptr %v0, ptr %t49, i64 %t50)
  store { i64, ptr } %t53, ptr %l30
  br label %bb10
bb10:
  %t54 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t55 = load ptr, ptr %l27, !tbaa !29
  %t56 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t55, i32 0, i32 4
  store { i64, ptr } %t54, ptr %t56, !tbaa !27
  %t57 = load ptr, ptr %l2, !tbaa !29
  %t58 = load ptr, ptr %l2, !tbaa !29
  %t60 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t58, i32 0, i32 4
  %t61 = load { i64, ptr }, ptr %t60, !tbaa !27
  %t63 = extractvalue { i64, ptr } %t61, 0
  %t66 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t57, i32 0, i32 6
  store i64 %t63, ptr %t66, !tbaa !24
  %t67 = load ptr, ptr %l2, !tbaa !29
  %t68 = load i64, ptr %l3, !tbaa !24
  %t69 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunk, !tbaa !24
  %t70 = load i64, ptr %l4, !tbaa !24
  store i64 %t70, ptr %l38, !tbaa !24
  %t72 = load i64, ptr %l38, !tbaa !24
  %t73 = load i64, ptr %l38, !tbaa !24
  %t74 = shl i64 %t69, %t73
  %t77 = sub i64 %t68, %t74
  %t79 = add i64 %t77, 1
  %t82 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t67, i32 0, i32 5
  store i64 %t79, ptr %t82, !tbaa !24
  %t83 = load ptr, ptr %l2, !tbaa !29
  %t84 = load i64, ptr %l1, !tbaa !24
  %t87 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t83, i32 0, i32 7
  store i64 %t84, ptr %t87, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fdiag_3aSaid_3e_2eLen_3ccompiler_2fdiag_3aSaid_3e(ptr %v0, ptr %a0) #0 {
entry:
  %r = tail call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cU64_3e_2eLen_3cU64_3e(ptr %v0, ptr %a0)
  ret i64 %r
}

define dso_local { i32, i32 } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftoken_3aTok_3e_2eLast_3ccompiler_2ftoken_3aTok_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %rv = alloca { i32, i32 }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l1, !tbaa !29
  %t6 = load ptr, ptr %l1, !tbaa !29
  %t8 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t6, i32 0, i32 7
  %t9 = load i64, ptr %t8, !tbaa !24
  %t11 = icmp eq i64 %t9, 0
  br i1 %t11, label %bb1, label %bb2
bb1:
  %t14 = insertvalue { i32, i32 } zeroinitializer, i32 65536, 0
  store { i32, i32 } %t14, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t17 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t15, i32 0, i32 5
  %t18 = load i64, ptr %t17, !tbaa !24
  %t20 = icmp eq i64 %t18, 0
  br i1 %t20, label %bb4, label %bb5
bb4:
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t23 = load ptr, ptr %l1, !tbaa !29
  %t25 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t23, i32 0, i32 2
  %t26 = load i64, ptr %t25, !tbaa !24
  %t28 = sub i64 %t26, 2
  %t31 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3cU64_3e_2echunk_3cU64_3e(ptr %v0, ptr %t22, i64 %t28)
  store { i64, ptr } %t31, ptr %l16
  br label %bb6
bb5:
  br label %bb7
bb6:
  %t32 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t32, ptr %l2, !tbaa !27
  %t33 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t33, ptr %l17, !tbaa !27
  %t34 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t36 = extractvalue { i64, ptr } %t34, 0
  %t38 = sub i64 %t36, 1
  %t40 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !27
  %t42 = getelementptr i32, ptr %t41, i64 %t38
  %t43 = load i32, ptr %t42
  %t45 = insertvalue { i32, i32 } zeroinitializer, i32 %t43, 1
  store { i32, i32 } %t45, ptr %rv
  br label %ret
bb7:
  %t46 = load ptr, ptr %l1, !tbaa !29
  %t48 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t46, i32 0, i32 4
  %t49 = load { i64, ptr }, ptr %t48, !tbaa !27
  store { i64, ptr } %t49, ptr %l23, !tbaa !27
  %t50 = load ptr, ptr %l1, !tbaa !29
  %t52 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t50, i32 0, i32 5
  %t53 = load i64, ptr %t52, !tbaa !24
  %t55 = sub i64 %t53, 1
  %t57 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t58 = load ptr, ptr %t57, !tbaa !27
  %t59 = getelementptr i32, ptr %t58, i64 %t55
  %t60 = load i32, ptr %t59
  %t62 = insertvalue { i32, i32 } zeroinitializer, i32 %t60, 1
  store { i32, i32 } %t62, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i32 }, ptr %rv
  ret { i32, i32 } %rr
}

define dso_local i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftoken_3aTok_3e_2eLen_3ccompiler_2ftoken_3aTok_3e(ptr %v0, ptr %a0) #0 {
entry:
  %r = tail call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cU64_3e_2eLen_3cU64_3e(ptr %v0, ptr %a0)
  ret i64 %r
}

define dso_local { i32, i32 } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftoken_3aTok_3e_2ePop_3ccompiler_2ftoken_3aTok_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca ptr
  %l10 = alloca { i64, ptr }
  %rv = alloca { i32, i32 }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l1, !tbaa !29
  %t6 = load ptr, ptr %l1, !tbaa !29
  %t8 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t6, i32 0, i32 7
  %t9 = load i64, ptr %t8, !tbaa !24
  %t11 = icmp eq i64 %t9, 0
  br i1 %t11, label %bb1, label %bb2
bb1:
  %t14 = insertvalue { i32, i32 } zeroinitializer, i32 65536, 0
  store { i32, i32 } %t14, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t15 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3cI64_3e_2edropLast_3cI64_3e(ptr %v0, ptr %t15)
  br label %bb4
bb4:
  %t17 = load ptr, ptr %l1, !tbaa !29
  %t19 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t17, i32 0, i32 4
  %t20 = load { i64, ptr }, ptr %t19, !tbaa !27
  store { i64, ptr } %t20, ptr %l10, !tbaa !27
  %t21 = load ptr, ptr %l1, !tbaa !29
  %t23 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t21, i32 0, i32 5
  %t24 = load i64, ptr %t23, !tbaa !24
  %t26 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = getelementptr i32, ptr %t27, i64 %t24
  %t29 = load i32, ptr %t28
  %t31 = insertvalue { i32, i32 } zeroinitializer, i32 %t29, 1
  store { i32, i32 } %t31, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i32 }, ptr %rv
  ret { i32, i32 } %rr
}

define dso_local void @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3ccompiler_2ftoken_3aTok_3e_2edr_Haa853dacfa4b8ca3e1487e13983e66b1(ptr %v0, ptr %a0) #0 {
entry:
  tail call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3cI64_3e_2edropLast_3cI64_3e(ptr %v0, ptr %a0)
  ret void
}

declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eClear_3cBool_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3cBool_3e_2evacateFrom_3cBool_3e(ptr %v0, ptr %a0, i64 %a1)
@G_2estd_2fprelude_2flist_2efirstChunk = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\08\00\00\00\00\00\00\00" }>, align 8
declare i64 @std_2fprelude_2flist_2ehighBit(i64 %a0)
@G_2estd_2fprelude_2flist_2efirstChunkLog = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3cU64_3e_2echunk_3cU64_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3cI64_3e_2evacateFrom_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cU64_3e_2eLen_3cU64_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3cI64_3e_2edropLast_3cI64_3e(ptr %v0, ptr %a0)

!20 = !{!"olang"}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
