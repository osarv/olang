; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/lower:Lowerer" = type { ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i32, i32 }
%"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/typed:Body" = type { i32, { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/mir:Fn" = type { { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/lower:lowering" = type { ptr, ptr, ptr, %"compiler/mir:Fn", i64, { i64, [4 x i64] }, i32, i1, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i32, { i64, [1 x i64] }, %"compiler/typed:Plan" }
%"compiler/typed:Plan" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/generic:Program" = type { ptr, ptr, %"compiler/types:Table", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"compiler/generic:Origin", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/types:Table" = type { ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1 }
%"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/generic:Origin" = type { i64, %"compiler/source:Span", i64 }
%"compiler/mir:Range" = type { i32, i32 }
%"compiler/typed:Promote" = type { ptr, i32 }
%"compiler/typed:Make" = type { i32, i64, { i64, ptr }, ptr, i32, i32 }
%"compiler/mir:Place" = type { { i64, [2 x i64] }, %"compiler/mir:Range" }
%"compiler/lower:level" = type { i32, i32, i32 }
%"compiler/typed:Arm" = type { %"compiler/source:Span", { i64, ptr }, ptr, ptr, ptr }
%"compiler/typed:Block" = type { i32, { i64, ptr } }
%"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" = type { i64, i64 }
%"compiler/load:Loader" = type { { i64, ptr }, ptr, ptr, ptr, ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, { i64, ptr } }
%"compiler/load:Module" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i64, i1, ptr, ptr, { i64, ptr }, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, ptr, ptr, i1, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/mir:Call" = type { { i64, [7 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/mir:Place", i1, i32, i32, i32 }
%"compiler/typed:Call" = type { ptr, { i64, ptr }, { i64, [2 x i64] }, i32, i1 }
%"compiler/lower:tryCtx" = type { i64, { i64, ptr }, i1, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/typed:Clause" = type { %"compiler/source:Span", { i64, ptr }, i1, ptr, { i64, ptr }, i64, i32 }
%"compiler/lower:collectCtx" = type { i32, i32, i32, i32, { i64, [1 x i64] } }
%"compiler/typed:Collect" = type { ptr, ptr, i32, i32 }
%"compiler/typed:Cond" = type { ptr, ptr, ptr }
%"compiler/typed:Seq" = type { { i64, ptr }, ptr }
%"compiler/lower:pl" = type { { i64, [2 x i64] }, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/typed:Item" = type { i32, i64 }
%"compiler/typed:BlockInfo" = type { i32, i32, %"compiler/source:Span" }
%"compiler/mir:ScopeInfo" = type { i32, i32, i32, %"compiler/source:Span", i32 }
%"compiler/lower:Gap" = type { i64, %"compiler/source:Span", { i64, ptr } }
%"compiler/typed:Join" = type { ptr, i1, { i64, ptr } }
%"compiler/lower:loopCtx" = type { i32, i64, i32, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/typed:Payload" = type { ptr, i64, i32 }
%"compiler/mir:Local" = type { i32, %"compiler/source:Span", i32, i32, { i64, [1 x i64] } }
%"compiler/typed:Match" = type { { i64, ptr }, { i64, ptr }, ptr, i1 }
%"compiler/typed:Try" = type { ptr, { i64, ptr }, i1, i1 }
%"compiler/typed:Slice" = type { ptr, ptr, ptr, i32 }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/typed:Local" = type { i32, %"compiler/source:Span", i32, i32, i32, { i64, [2 x i64] } }
%"compiler/typed:Spawn" = type { { i64, ptr }, ptr, { i64, ptr }, i32 }
%"compiler/typed:TaskClause" = type { %"compiler/source:Span", { i64, ptr }, i1, ptr }
%"compiler/typed:If" = type { ptr, ptr, ptr }
define dso_local void @compiler_2flower_2eFailTypes_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  %t1 = insertvalue [5 x { i64, ptr }] undef, { i64, ptr } { i64 10, ptr @.d0 }, 0
  %t2 = insertvalue [5 x { i64, ptr }] %t1, { i64, ptr } { i64 11, ptr @.d1 }, 1
  %t3 = insertvalue [5 x { i64, ptr }] %t2, { i64, ptr } { i64 11, ptr @.d2 }, 2
  %t4 = insertvalue [5 x { i64, ptr }] %t3, { i64, ptr } { i64 9, ptr @.d3 }, 3
  %t5 = insertvalue [5 x { i64, ptr }] %t4, { i64, ptr } { i64 13, ptr @.d4 }, 4
  store [5 x { i64, ptr }] %t5, ptr @G_2ecompiler_2flower_2eFailTypes
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flower_2eFailWords_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  %t1 = insertvalue [5 x { i64, ptr }] undef, { i64, ptr } { i64 12, ptr @.d5 }, 0
  %t2 = insertvalue [5 x { i64, ptr }] %t1, { i64, ptr } { i64 8, ptr @.d6 }, 1
  %t3 = insertvalue [5 x { i64, ptr }] %t2, { i64, ptr } { i64 7, ptr @.d7 }, 2
  %t4 = insertvalue [5 x { i64, ptr }] %t3, { i64, ptr } { i64 10, ptr @.d8 }, 3
  %t5 = insertvalue [5 x { i64, ptr }] %t4, { i64, ptr } { i64 7, ptr @.d9 }, 4
  store [5 x { i64, ptr }] %t5, ptr @G_2ecompiler_2flower_2eFailWords
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flower_2eInvalid_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 2, ptr @G_2ecompiler_2flower_2eInvalid, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flower_2eWrongCase_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 3, ptr @G_2ecompiler_2flower_2eWrongCase, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3aLowerer_2eHasCode(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l2 = alloca ptr
  %l7 = alloca ptr
  %l14 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/lower:Lowerer", ptr %a0, i32 0, i32 1
  %t7 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t3, i64 %a1)
  store ptr %t7, ptr %l7
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l7, !tbaa !29
  store ptr %t8, ptr %l2, !tbaa !29
  %t9 = load ptr, ptr %l2, !tbaa !29
  %t11 = getelementptr %"compiler/typed:Body", ptr %t9, i32 0, i32 11
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t14 = icmp eq ptr %t12, null
  br i1 %t14, label %bb2, label %bb3
bb2:
  store i1 false, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t17 = load ptr, ptr %l2, !tbaa !29
  %t19 = getelementptr %"compiler/typed:Body", ptr %t17, i32 0, i32 1
  %t20 = load { i64, [2 x i64] }, ptr %t19
  %t24 = extractvalue { i64, [2 x i64] } %t20, 0
  %t25 = icmp eq i64 %t24, 2
  br i1 %t25, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb8
bb7:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb13
bb8:
  br i1 true, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  store i1 true, ptr %l14, !tbaa !21
  br label %bb13
bb12:
  call void @__olang_check_failed(ptr @olang_loc_daa9f23a83841987_24921124063ad36b)
  unreachable
bb13:
  %t27 = load i1, ptr %l14, !tbaa !21
  store i1 %t27, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2flower_2ecompiler_2flower_3aLowerer_2eInitModules(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %lp1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l8 = alloca { i64, [2 x i64] }
  %l9 = alloca i64
  %l11 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l14 = alloca i64
  %l18 = alloca i64
  %l21 = alloca i64
  %l42 = alloca ptr
  %l51 = alloca i1
  %s2 = alloca %olang.scope
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l11
  br label %bb1
bb1:
  %t3 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 8, i64 8)
  store ptr %t3, ptr %lp1
  %t4 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l11
  %t5 = load ptr, ptr %lp1
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t4, ptr %t5
  store i64 0, ptr %l2, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/lower:Lowerer", ptr %t6, i32 0, i32 1
  %t10 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_Ha6bcf4d517e3d7b46809e1dbf938da91(ptr %v0, ptr %t8)
  store i64 %t10, ptr %l14
  br label %bb2
bb2:
  %t11 = load i64, ptr %l14, !tbaa !24
  store i64 %t11, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t12 = load i64, ptr %l3, !tbaa !24
  %t13 = load i64, ptr %l2, !tbaa !24
  %t16 = icmp sgt i64 %t12, %t13
  br i1 %t16, label %bb3, label %bb4
bb3:
  %t18 = load i64, ptr %l4, !tbaa !24
  %t20 = icmp sgt i64 %t18, 0
  br i1 %t20, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l18, !tbaa !24
  br label %bb8
bb5:
  %t22 = load i64, ptr %l3, !tbaa !24
  %t23 = load i64, ptr %l2, !tbaa !24
  %t26 = sub i64 %t22, %t23
  %t27 = load i64, ptr %l4, !tbaa !24
  %t30 = add i64 %t26, %t27
  %t32 = sub i64 %t30, 1
  %t33 = load i64, ptr %l4, !tbaa !24
  %t36 = sdiv i64 %t32, %t33
  store i64 %t36, ptr %l21, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l21, !tbaa !24
  br label %bb7
bb7:
  %t38 = load i64, ptr %l21, !tbaa !24
  store i64 %t38, ptr %l18, !tbaa !24
  br label %bb8
bb8:
  %t39 = load i64, ptr %l18, !tbaa !24
  store i64 %t39, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t40 = load i64, ptr %l6, !tbaa !24
  %t41 = load i64, ptr %l5, !tbaa !24
  %t44 = icmp slt i64 %t40, %t41
  %t46 = xor i1 %t44, true
  br i1 %t46, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb29
bb11:
  br label %bb12
bb12:
  %t48 = load i64, ptr %l2, !tbaa !24
  %t49 = load i64, ptr %l6, !tbaa !24
  %t50 = load i64, ptr %l4, !tbaa !24
  %t53 = mul i64 %t49, %t50
  %t56 = add i64 %t48, %t53
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/lower:Lowerer", ptr %t58, i32 0, i32 1
  %t64 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t60, i64 %t56)
  store ptr %t64, ptr %l42
  br label %bb13
bb13:
  %t65 = load ptr, ptr %l42, !tbaa !29
  %t67 = getelementptr %"compiler/typed:Body", ptr %t65, i32 0, i32 1
  %t68 = load { i64, [2 x i64] }, ptr %t67
  store { i64, [2 x i64] } %t68, ptr %l8
  %t70 = load { i64, [2 x i64] }, ptr %l8
  %t72 = extractvalue { i64, [2 x i64] } %t70, 0
  %t73 = icmp eq i64 %t72, 6
  br i1 %t73, label %bb14, label %bb15
bb14:
  %t75 = getelementptr { i64, [2 x i64] }, ptr %l8, i32 0, i32 1
  %t76 = getelementptr { i64, i32 }, ptr %t75, i32 0, i32 0
  %t77 = load i64, ptr %t76
  store i64 %t77, ptr %l9, !tbaa !24
  br label %bb16
bb15:
  br label %bb22
bb16:
  %t79 = load i64, ptr %l9, !tbaa !24
  %t81 = load ptr, ptr %lp1
  %t85 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eHas_3cI64_3e(ptr %v1, ptr %t81, i64 %t79)
  store i1 %t85, ptr %l51
  br label %bb17
bb17:
  %t86 = load i1, ptr %l51, !tbaa !21
  %t87 = xor i1 %t86, true
  br i1 %t87, label %bb18, label %bb19
bb18:
  %t89 = load ptr, ptr %lp1
  %t90 = load i64, ptr %l9, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t89, i64 %t90)
  br label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb21
bb21:
  br label %bb27
bb22:
  br i1 true, label %bb23, label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb27
bb26:
  call void @__olang_check_failed(ptr @olang_loc_e3721461a855ef35_c24433bc0ae5f641)
  unreachable
bb27:
  call void @__olang_scope_close(ptr %s2)
  br label %bb28
bb28:
  %t93 = load i64, ptr %l6, !tbaa !24
  %t95 = add i64 %t93, 1
  store i64 %t95, ptr %l6, !tbaa !24
  br label %bb9
bb29:
  %t97 = load ptr, ptr %lp1
  %t98 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t97
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t98, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3aLowerer_2eLower(ptr %out, ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %lp2 = alloca ptr
  %lp3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %lp10 = alloca ptr
  %l14 = alloca ptr
  %l25 = alloca %"compiler/mir:Fn"
  %l28 = alloca i64
  %l32 = alloca i64
  %l35 = alloca i64
  %l53 = alloca ptr
  %l57 = alloca i32
  %l58 = alloca ptr
  %l62 = alloca { i64, ptr }
  %l71 = alloca %"compiler/lower:lowering"
  %l74 = alloca i64
  %l77 = alloca i64
  %l82 = alloca %"compiler/typed:Plan"
  %l86 = alloca %"compiler/mir:Fn"
  %s2 = alloca %olang.scope
  %t15 = alloca { i64, [2 x i64] }, align 8
  %t36 = alloca %"compiler/mir:Fn", align 8
  %t134 = alloca %"compiler/lower:lowering", align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:Lowerer", ptr %t1, i32 0, i32 1
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v1, ptr %t3, i64 %t4)
  store ptr %t7, ptr %l14
  br label %bb1
bb1:
  %t8 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 8, i64 8)
  store ptr %t8, ptr %lp2
  %t9 = load ptr, ptr %l14, !tbaa !29
  %t10 = load ptr, ptr %lp2
  store ptr %t9, ptr %t10, !tbaa !29
  %t11 = load i64, ptr %l1, !tbaa !24
  %t13 = trunc i64 %t11 to i32
  store { i64, [2 x i64] } zeroinitializer, ptr %t15
  %t16 = getelementptr { i64, [2 x i64] }, ptr %t15, i32 0, i32 0
  store i64 0, ptr %t16
  %t18 = insertvalue { i32 } undef, i32 %t13, 0
  %t19 = getelementptr { i64, [2 x i64] }, ptr %t15, i32 0, i32 1
  store { i32 } %t18, ptr %t19
  %t20 = load { i64, [2 x i64] }, ptr %t15
  %t21 = load ptr, ptr %lp2
  %t22 = load ptr, ptr %t21, !tbaa !29
  %t24 = getelementptr %"compiler/typed:Body", ptr %t22, i32 0, i32 2
  %t25 = load i32, ptr %t24, !tbaa !23
  %t26 = load ptr, ptr %lp2
  %t27 = load ptr, ptr %t26, !tbaa !29
  %t29 = getelementptr %"compiler/typed:Body", ptr %t27, i32 0, i32 3
  %t30 = load i64, ptr %t29, !tbaa !24
  %t31 = load ptr, ptr %lp2
  %t32 = load ptr, ptr %t31, !tbaa !29
  %t34 = getelementptr %"compiler/typed:Body", ptr %t32, i32 0, i32 4
  %t35 = load %"compiler/source:Span", ptr %t34
  call void @compiler_2fmir_3aFn_2ector(ptr %t36, ptr %v1, { i64, [2 x i64] } %t20, i32 %t25, i64 %t30, %"compiler/source:Span" %t35)
  call void @llvm.memmove.p0.p0.i64(ptr %l25, ptr %t36, i64 216, i1 false)
  br label %bb2
bb2:
  %t41 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 216, i64 8)
  store ptr %t41, ptr %lp3
  %t42 = load ptr, ptr %lp3
  call void @llvm.memmove.p0.p0.i64(ptr %t42, ptr %l25, i64 216, i1 false)
  store i64 0, ptr %l4, !tbaa !24
  %t43 = load ptr, ptr %lp2
  %t44 = load ptr, ptr %t43, !tbaa !29
  %t46 = getelementptr %"compiler/typed:Body", ptr %t44, i32 0, i32 13
  %t48 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI32_3e_2eLen_3cI32_3e(ptr %v1, ptr %t46)
  store i64 %t48, ptr %l28
  br label %bb3
bb3:
  %t49 = load i64, ptr %l28, !tbaa !24
  store i64 %t49, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t50 = load i64, ptr %l5, !tbaa !24
  %t51 = load i64, ptr %l4, !tbaa !24
  %t54 = icmp sgt i64 %t50, %t51
  br i1 %t54, label %bb4, label %bb5
bb4:
  %t56 = load i64, ptr %l6, !tbaa !24
  %t58 = icmp sgt i64 %t56, 0
  br i1 %t58, label %bb6, label %bb7
bb5:
  store i64 0, ptr %l32, !tbaa !24
  br label %bb9
bb6:
  %t60 = load i64, ptr %l5, !tbaa !24
  %t61 = load i64, ptr %l4, !tbaa !24
  %t64 = sub i64 %t60, %t61
  %t65 = load i64, ptr %l6, !tbaa !24
  %t68 = add i64 %t64, %t65
  %t70 = sub i64 %t68, 1
  %t71 = load i64, ptr %l6, !tbaa !24
  %t74 = sdiv i64 %t70, %t71
  store i64 %t74, ptr %l35, !tbaa !24
  br label %bb8
bb7:
  store i64 0, ptr %l35, !tbaa !24
  br label %bb8
bb8:
  %t76 = load i64, ptr %l35, !tbaa !24
  store i64 %t76, ptr %l32, !tbaa !24
  br label %bb9
bb9:
  %t77 = load i64, ptr %l32, !tbaa !24
  store i64 %t77, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s2
  %t78 = load i64, ptr %l8, !tbaa !24
  %t79 = load i64, ptr %l7, !tbaa !24
  %t82 = icmp slt i64 %t78, %t79
  %t84 = xor i1 %t82, true
  br i1 %t84, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s2)
  br label %bb19
bb12:
  br label %bb13
bb13:
  %t86 = load i64, ptr %l4, !tbaa !24
  %t87 = load i64, ptr %l8, !tbaa !24
  %t88 = load i64, ptr %l6, !tbaa !24
  %t91 = mul i64 %t87, %t88
  %t94 = add i64 %t86, %t91
  store i64 %t94, ptr %l9, !tbaa !24
  %t96 = load ptr, ptr %lp3
  %t97 = getelementptr %"compiler/mir:Fn", ptr %t96, i32 0, i32 23
  store ptr %t97, ptr %l53, !tbaa !29
  %t98 = load ptr, ptr %lp2
  %t99 = load ptr, ptr %t98, !tbaa !29
  %t101 = getelementptr %"compiler/typed:Body", ptr %t99, i32 0, i32 13
  %t102 = load i64, ptr %l9, !tbaa !24
  %t105 = call i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI32_3e_2eAt_3cI32_3e(ptr %v1, ptr %t101, i64 %t102)
  store i32 %t105, ptr %l57
  br label %bb14
bb14:
  %t106 = load ptr, ptr %l53, !tbaa !29
  %t107 = load i32, ptr %l57, !tbaa !23
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI32_3e_2ePush_3cI32_3e(ptr %v1, ptr %t106, i32 %t107)
  br label %bb15
bb15:
  %t108 = load ptr, ptr %lp3
  %t109 = getelementptr %"compiler/mir:Fn", ptr %t108, i32 0, i32 24
  store ptr %t109, ptr %l58, !tbaa !29
  %t110 = load ptr, ptr %lp2
  %t111 = load ptr, ptr %t110, !tbaa !29
  %t113 = getelementptr %"compiler/typed:Body", ptr %t111, i32 0, i32 14
  %t114 = load i64, ptr %l9, !tbaa !24
  %t117 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v1, ptr %v1, ptr %t113, i64 %t114)
  store { i64, ptr } %t117, ptr %l62
  br label %bb16
bb16:
  %t118 = load ptr, ptr %l58, !tbaa !29
  %t119 = load { i64, ptr }, ptr %l62, !tbaa !27
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v1, ptr %v1, ptr %t118, { i64, ptr } %t119)
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s2)
  br label %bb18
bb18:
  %t120 = load i64, ptr %l8, !tbaa !24
  %t122 = add i64 %t120, 1
  store i64 %t122, ptr %l8, !tbaa !24
  br label %bb10
bb19:
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t125 = load ptr, ptr %lp2
  %t126 = load ptr, ptr %t125, !tbaa !29
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t129 = getelementptr %"compiler/lower:Lowerer", ptr %t127, i32 0, i32 0
  %t130 = load ptr, ptr %t129, !tbaa !29
  %t132 = getelementptr %"compiler/generic:Program", ptr %t130, i32 0, i32 2
  %t133 = load ptr, ptr %lp3
  call void @compiler_2flower_3alowering_2ector(ptr %t134, ptr %v0, ptr %v1, ptr %v0, ptr %v1, ptr %v1, ptr %t124, ptr %t126, ptr %t132, ptr %t133)
  call void @llvm.memmove.p0.p0.i64(ptr %l71, ptr %t134, i64 496, i1 false)
  br label %bb20
bb20:
  %t139 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 496, i64 8)
  store ptr %t139, ptr %lp10
  %t140 = load ptr, ptr %lp10
  call void @llvm.memmove.p0.p0.i64(ptr %t140, ptr %l71, i64 496, i1 false)
  %t141 = load ptr, ptr %lp2
  %t142 = load ptr, ptr %t141, !tbaa !29
  %t144 = getelementptr %"compiler/typed:Body", ptr %t142, i32 0, i32 3
  %t145 = load i64, ptr %t144, !tbaa !24
  %t147 = load ptr, ptr %lp10
  %t148 = getelementptr %"compiler/lower:lowering", ptr %t147, i32 0, i32 4
  store i64 %t145, ptr %t148, !tbaa !24
  %t149 = load i64, ptr %l1, !tbaa !24
  store i64 %t149, ptr %l74, !tbaa !24
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t152 = getelementptr %"compiler/lower:Lowerer", ptr %t150, i32 0, i32 2
  %t154 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlan_3e_2eLen_3ccompiler_2ftyped_3aPlan_3e(ptr %v0, ptr %t152)
  store i64 %t154, ptr %l77
  br label %bb21
bb21:
  %t155 = load i64, ptr %l74, !tbaa !24
  %t156 = load i64, ptr %l77, !tbaa !24
  %t157 = icmp slt i64 %t155, %t156
  br i1 %t157, label %bb22, label %bb23
bb22:
  %t159 = load ptr, ptr %lp10
  %t160 = getelementptr %"compiler/lower:lowering", ptr %t159, i32 0, i32 19
  store i1 true, ptr %t160, !tbaa !21
  %t161 = load ptr, ptr %l0, !tbaa !29
  %t163 = getelementptr %"compiler/lower:Lowerer", ptr %t161, i32 0, i32 2
  %t164 = load i64, ptr %l1, !tbaa !24
  %t167 = call %"compiler/typed:Plan" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlan_3e_2eAt_3ccompiler_2ftyped_3aPlan_3e(ptr %v0, ptr %v1, ptr %t163, i64 %t164)
  store %"compiler/typed:Plan" %t167, ptr %l82
  br label %bb24
bb23:
  br label %bb25
bb24:
  %t168 = load %"compiler/typed:Plan", ptr %l82
  %t169 = load ptr, ptr %lp10
  %t170 = getelementptr %"compiler/lower:lowering", ptr %t169, i32 0, i32 22
  store %"compiler/typed:Plan" %t168, ptr %t170
  br label %bb25
bb25:
  %t171 = load ptr, ptr %lp10
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2erun(ptr %v1, ptr %t171)
  br label %bb26
bb26:
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t174 = load ptr, ptr %lp10
  %t175 = getelementptr %"compiler/lower:lowering", ptr %t174, i32 0, i32 8
  %t176 = load i1, ptr %t175, !tbaa !21
  %t179 = getelementptr %"compiler/lower:Lowerer", ptr %t173, i32 0, i32 4
  store i1 %t176, ptr %t179, !tbaa !21
  %t180 = load ptr, ptr %lp10
  %t181 = getelementptr %"compiler/lower:lowering", ptr %t180, i32 0, i32 3
  call void @llvm.memmove.p0.p0.i64(ptr %l86, ptr %t181, i64 216, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l86, i64 216, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local { i1, { i64, ptr }, { i64, ptr } } @compiler_2flower_2ecompiler_2flower_3aLowerer_2eVerifiedKey(ptr %v0, ptr %v1, ptr %a0, { i64, [2 x i64] } %a1, i1 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca ptr
  %lp4 = alloca ptr
  %l8 = alloca %"compiler/mir:Fn"
  %l12 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l16 = alloca { i1, { i64, ptr }, { i64, ptr } }
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l39 = alloca { i1, { i64, ptr }, { i64, ptr } }
  %l40 = alloca { i64, ptr }
  %l41 = alloca i64
  %l42 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i1, { i64, ptr }, { i64, ptr } }
  %t3 = alloca %"compiler/mir:Fn", align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3aLowerer_2eLowerKey(ptr %t3, ptr %v0, ptr %v0, ptr %t1, { i64, [2 x i64] } %a1)
  call void @llvm.memmove.p0.p0.i64(ptr %l8, ptr %t3, i64 216, i1 false)
  br label %bb1
bb1:
  %t6 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 216, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t6, ptr %l8, i64 216, i1 false)
  store ptr %t6, ptr %l3, !tbaa !29
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/lower:Lowerer", ptr %t8, i32 0, i32 4
  %t11 = load i1, ptr %t10, !tbaa !21
  br i1 %t11, label %bb2, label %bb3
bb2:
  store { i64, ptr } { i64 0, ptr @.d10 }, ptr %l12, !tbaa !27
  %t13 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } { i64 0, ptr @.d11 }, ptr %l14, !tbaa !27
  %t14 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t15 = insertvalue { i1, { i64, ptr }, { i64, ptr } } undef, i1 true, 0
  %t17 = insertvalue { i1, { i64, ptr }, { i64, ptr } } %t15, { i64, ptr } %t13, 1
  %t19 = insertvalue { i1, { i64, ptr }, { i64, ptr } } %t17, { i64, ptr } %t14, 2
  store { i1, { i64, ptr }, { i64, ptr } } %t19, ptr %l16
  %t20 = getelementptr { i1, { i64, ptr }, { i64, ptr } }, ptr %l16, i32 0, i32 1
  %t21 = load { i64, ptr }, ptr %t20, !tbaa !27
  store { i64, ptr } %t21, ptr %l17, !tbaa !27
  %t22 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t22, 0
  store i64 %t23, ptr %l18, !tbaa !24
  %t24 = load i64, ptr %l18, !tbaa !24
  %t25 = mul i64 %t24, 1
  %t26 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t25)
  %t27 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  store { i64, ptr } %t28, ptr %l19, !tbaa !27
  %t29 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !27
  %t31 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = load i64, ptr %l18, !tbaa !24
  %t34 = mul i64 %t33, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t30, ptr %t32, i64 %t34, i1 false)
  %t35 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t36 = getelementptr { i1, { i64, ptr }, { i64, ptr } }, ptr %l16, i32 0, i32 1
  store { i64, ptr } %t35, ptr %t36, !tbaa !27
  %t37 = getelementptr { i1, { i64, ptr }, { i64, ptr } }, ptr %l16, i32 0, i32 2
  %t38 = load { i64, ptr }, ptr %t37, !tbaa !27
  store { i64, ptr } %t38, ptr %l20, !tbaa !27
  %t39 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t40 = extractvalue { i64, ptr } %t39, 0
  store i64 %t40, ptr %l21, !tbaa !24
  %t41 = load i64, ptr %l21, !tbaa !24
  %t42 = mul i64 %t41, 1
  %t43 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t42)
  %t44 = insertvalue { i64, ptr } undef, i64 %t41, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t43, 1
  store { i64, ptr } %t45, ptr %l22, !tbaa !27
  %t46 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !27
  %t48 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !27
  %t50 = load i64, ptr %l21, !tbaa !24
  %t51 = mul i64 %t50, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t47, ptr %t49, i64 %t51, i1 false)
  %t52 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t53 = getelementptr { i1, { i64, ptr }, { i64, ptr } }, ptr %l16, i32 0, i32 2
  store { i64, ptr } %t52, ptr %t53, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t54 = load { i1, { i64, ptr }, { i64, ptr } }, ptr %l16
  store { i1, { i64, ptr }, { i64, ptr } } %t54, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t55 = load ptr, ptr %l3, !tbaa !29
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/lower:Lowerer", ptr %t56, i32 0, i32 0
  %t59 = load ptr, ptr %t58, !tbaa !29
  %t61 = getelementptr %"compiler/generic:Program", ptr %t59, i32 0, i32 2
  %t64 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3aFn_2eVerify(ptr %v0, ptr %v0, ptr %v1, ptr %t55, ptr %t61)
  store { i64, ptr } %t64, ptr %l27
  br label %bb5
bb5:
  %t65 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t65, ptr %lp4
  %t66 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t67 = load ptr, ptr %lp4
  store { i64, ptr } %t66, ptr %t67, !tbaa !27
  br i1 %a2, label %bb6, label %bb7
bb6:
  %t70 = load ptr, ptr %l3, !tbaa !29
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/lower:Lowerer", ptr %t71, i32 0, i32 0
  %t74 = load ptr, ptr %t73, !tbaa !29
  %t76 = getelementptr %"compiler/generic:Program", ptr %t74, i32 0, i32 2
  %t79 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3aFn_2eDump(ptr %v0, ptr %v0, ptr %s0, ptr %t70, ptr %t76)
  store { i64, ptr } %t79, ptr %l34
  br label %bb8
bb7:
  store { i64, ptr } { i64 0, ptr @.d12 }, ptr %l29, !tbaa !27
  br label %bb9
bb8:
  %t80 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t81 = extractvalue { i64, ptr } %t80, 0
  %t82 = extractvalue { i64, ptr } %t80, 1
  %t83 = mul i64 %t81, 1
  %t84 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t83)
  call void @llvm.memcpy.p0.p0.i64(ptr %t84, ptr %t82, i64 %t83, i1 false)
  %t85 = insertvalue { i64, ptr } undef, i64 %t81, 0
  %t86 = insertvalue { i64, ptr } %t85, ptr %t84, 1
  store { i64, ptr } %t86, ptr %l29, !tbaa !27
  br label %bb9
bb9:
  %t88 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t89 = load ptr, ptr %lp4
  %t90 = load { i64, ptr }, ptr %t89, !tbaa !27
  %t93 = insertvalue { i1, { i64, ptr }, { i64, ptr } } undef, i1 false, 0
  %t95 = insertvalue { i1, { i64, ptr }, { i64, ptr } } %t93, { i64, ptr } %t90, 1
  %t97 = insertvalue { i1, { i64, ptr }, { i64, ptr } } %t95, { i64, ptr } %t88, 2
  store { i1, { i64, ptr }, { i64, ptr } } %t97, ptr %l39
  %t98 = getelementptr { i1, { i64, ptr }, { i64, ptr } }, ptr %l39, i32 0, i32 2
  %t99 = load { i64, ptr }, ptr %t98, !tbaa !27
  store { i64, ptr } %t99, ptr %l40, !tbaa !27
  %t100 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t101 = extractvalue { i64, ptr } %t100, 0
  store i64 %t101, ptr %l41, !tbaa !24
  %t102 = load i64, ptr %l41, !tbaa !24
  %t103 = mul i64 %t102, 1
  %t104 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t103)
  %t105 = insertvalue { i64, ptr } undef, i64 %t102, 0
  %t106 = insertvalue { i64, ptr } %t105, ptr %t104, 1
  store { i64, ptr } %t106, ptr %l42, !tbaa !27
  %t107 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t108 = load ptr, ptr %t107, !tbaa !27
  %t109 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t110 = load ptr, ptr %t109, !tbaa !27
  %t111 = load i64, ptr %l41, !tbaa !24
  %t112 = mul i64 %t111, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t108, ptr %t110, i64 %t112, i1 false)
  %t113 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t114 = getelementptr { i1, { i64, ptr }, { i64, ptr } }, ptr %l39, i32 0, i32 2
  store { i64, ptr } %t113, ptr %t114, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t115 = load { i1, { i64, ptr }, { i64, ptr } }, ptr %l39
  store { i1, { i64, ptr }, { i64, ptr } } %t115, ptr %rv
  br label %ret
ret:
  %rr = load { i1, { i64, ptr }, { i64, ptr } }, ptr %rv
  ret { i1, { i64, ptr }, { i64, ptr } } %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3aLowerer_2eadapterFn(ptr %out, ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i32
  %lp12 = alloca ptr
  %lp13 = alloca ptr
  %l18 = alloca ptr
  %l23 = alloca ptr
  %l28 = alloca i32
  %l29 = alloca { i64, ptr }
  %l32 = alloca i64
  %l41 = alloca i64
  %l44 = alloca i64
  %l63 = alloca { i64, ptr }
  %l71 = alloca ptr
  %l76 = alloca i32
  %l81 = alloca i32
  %l86 = alloca i32
  %l87 = alloca i32
  %l89 = alloca %"compiler/typed:Body"
  %l90 = alloca ptr
  %l91 = alloca ptr
  %l94 = alloca ptr
  %l99 = alloca %"compiler/mir:Fn"
  %l101 = alloca %"compiler/lower:lowering"
  %l105 = alloca { i64, ptr }
  %l109 = alloca %"compiler/mir:Fn"
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %t164 = alloca %"compiler/typed:Body", align 8
  %t178 = alloca { i64, [2 x i64] }, align 8
  %t185 = alloca %"compiler/mir:Fn", align 8
  %t190 = alloca %"compiler/lower:lowering", align 8
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:Lowerer", ptr %t1, i32 0, i32 1
  %t4 = load i32, ptr %l1, !tbaa !23
  %t6 = sext i32 %t4 to i64
  %t9 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t3, i64 %t6)
  store ptr %t9, ptr %l18
  br label %bb1
bb1:
  %t10 = load ptr, ptr %l18, !tbaa !29
  %t12 = getelementptr %"compiler/typed:Body", ptr %t10, i32 0, i32 2
  %t13 = load i32, ptr %t12, !tbaa !23
  store i32 %t13, ptr %l2, !tbaa !23
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/lower:Lowerer", ptr %t15, i32 0, i32 0
  %t18 = load ptr, ptr %t17, !tbaa !29
  %t20 = getelementptr %"compiler/generic:Program", ptr %t18, i32 0, i32 2
  store ptr %t20, ptr %l23, !tbaa !29
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/lower:Lowerer", ptr %t21, i32 0, i32 0
  %t24 = load ptr, ptr %t23, !tbaa !29
  %t26 = getelementptr %"compiler/generic:Program", ptr %t24, i32 0, i32 2
  %t27 = load i32, ptr %l2, !tbaa !23
  %t30 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t26, i32 %t27)
  store i32 %t30, ptr %l28
  br label %bb2
bb2:
  %t31 = load ptr, ptr %l23, !tbaa !29
  %t32 = load i32, ptr %l28, !tbaa !23
  %t33 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t31, i32 %t32)
  store { i64, ptr } %t33, ptr %l29
  br label %bb3
bb3:
  %t34 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t34, ptr %l3, !tbaa !27
  %t35 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t37 = extractvalue { i64, ptr } %t35, 0
  %t39 = sub i64 %t37, 1
  store i64 %t39, ptr %l32, !tbaa !24
  %t40 = load i64, ptr %l32, !tbaa !24
  %t41 = icmp sge i64 %t40, 0
  br i1 %t41, label %bb4, label %bb5
bb4:
  %t43 = load i64, ptr %l32, !tbaa !24
  %t44 = icmp sle i64 %t43, 2305843009213693951
  br i1 %t44, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_4e4c17ebfaf5d7b6_624a73934957b6f2)
  unreachable
bb6:
  %t46 = load i64, ptr %l32, !tbaa !24
  %t47 = mul i64 %t46, 4
  %t48 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t47)
  %t49 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t50 = insertvalue { i64, ptr } %t49, ptr %t48, 1
  store { i64, ptr } %t50, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t52 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t54 = extractvalue { i64, ptr } %t52, 0
  store i64 %t54, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t56 = load i64, ptr %l6, !tbaa !24
  %t57 = load i64, ptr %l5, !tbaa !24
  %t60 = icmp sgt i64 %t56, %t57
  br i1 %t60, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_4e4c17ebfaf5d7b6_624a73934957b6f2)
  unreachable
bb8:
  %t62 = load i64, ptr %l7, !tbaa !24
  %t64 = icmp sgt i64 %t62, 0
  br i1 %t64, label %bb10, label %bb11
bb9:
  store i64 0, ptr %l41, !tbaa !24
  br label %bb13
bb10:
  %t66 = load i64, ptr %l6, !tbaa !24
  %t67 = load i64, ptr %l5, !tbaa !24
  %t70 = sub i64 %t66, %t67
  %t71 = load i64, ptr %l7, !tbaa !24
  %t74 = add i64 %t70, %t71
  %t76 = sub i64 %t74, 1
  %t77 = load i64, ptr %l7, !tbaa !24
  %t80 = sdiv i64 %t76, %t77
  store i64 %t80, ptr %l44, !tbaa !24
  br label %bb12
bb11:
  store i64 0, ptr %l44, !tbaa !24
  br label %bb12
bb12:
  %t82 = load i64, ptr %l44, !tbaa !24
  store i64 %t82, ptr %l41, !tbaa !24
  br label %bb13
bb13:
  %t83 = load i64, ptr %l41, !tbaa !24
  store i64 %t83, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb14
bb14:
  store %olang.scope zeroinitializer, ptr %s2
  %t84 = load i64, ptr %l9, !tbaa !24
  %t85 = load i64, ptr %l8, !tbaa !24
  %t88 = icmp slt i64 %t84, %t85
  %t90 = xor i1 %t88, true
  br i1 %t90, label %bb15, label %bb16
bb15:
  call void @__olang_scope_close(ptr %s2)
  br label %bb19
bb16:
  br label %bb17
bb17:
  %t92 = load i64, ptr %l5, !tbaa !24
  %t93 = load i64, ptr %l9, !tbaa !24
  %t94 = load i64, ptr %l7, !tbaa !24
  %t97 = mul i64 %t93, %t94
  %t100 = add i64 %t92, %t97
  store i64 %t100, ptr %l10, !tbaa !24
  %t102 = load i64, ptr %l10, !tbaa !24
  %t103 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t103, ptr %l63, !tbaa !27
  %t104 = load i64, ptr %l10, !tbaa !24
  %t106 = add i64 %t104, 1
  %t108 = getelementptr { i64, ptr }, ptr %l63, i32 0, i32 1
  %t109 = load ptr, ptr %t108, !tbaa !27
  %t110 = getelementptr i32, ptr %t109, i64 %t106
  %t111 = load i32, ptr %t110, !tbaa !33
  %t114 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t115 = load ptr, ptr %t114, !tbaa !27
  %t116 = getelementptr i32, ptr %t115, i64 %t102
  store i32 %t111, ptr %t116, !tbaa !33
  call void @__olang_scope_close(ptr %s2)
  br label %bb18
bb18:
  %t117 = load i64, ptr %l9, !tbaa !24
  %t119 = add i64 %t117, 1
  store i64 %t119, ptr %l9, !tbaa !24
  br label %bb14
bb19:
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t123 = getelementptr %"compiler/lower:Lowerer", ptr %t121, i32 0, i32 0
  %t124 = load ptr, ptr %t123, !tbaa !29
  %t126 = getelementptr %"compiler/generic:Program", ptr %t124, i32 0, i32 2
  store ptr %t126, ptr %l71, !tbaa !29
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t129 = getelementptr %"compiler/lower:Lowerer", ptr %t127, i32 0, i32 0
  %t130 = load ptr, ptr %t129, !tbaa !29
  %t132 = getelementptr %"compiler/generic:Program", ptr %t130, i32 0, i32 2
  %t133 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t136 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s0, ptr %t132, { i64, ptr } %t133)
  store i32 %t136, ptr %l76
  br label %bb20
bb20:
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t139 = getelementptr %"compiler/lower:Lowerer", ptr %t137, i32 0, i32 0
  %t140 = load ptr, ptr %t139, !tbaa !29
  %t142 = getelementptr %"compiler/generic:Program", ptr %t140, i32 0, i32 2
  %t143 = load i32, ptr %l2, !tbaa !23
  %t146 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t142, i32 %t143)
  store i32 %t146, ptr %l81
  br label %bb21
bb21:
  %t147 = load ptr, ptr %l0, !tbaa !29
  %t149 = getelementptr %"compiler/lower:Lowerer", ptr %t147, i32 0, i32 0
  %t150 = load ptr, ptr %t149, !tbaa !29
  %t152 = getelementptr %"compiler/generic:Program", ptr %t150, i32 0, i32 2
  %t153 = load i32, ptr %l2, !tbaa !23
  %t156 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t152, i32 %t153)
  store i32 %t156, ptr %l86
  br label %bb22
bb22:
  %t157 = load ptr, ptr %l71, !tbaa !29
  %t158 = load i32, ptr %l76, !tbaa !23
  %t159 = load i32, ptr %l81, !tbaa !23
  %t160 = load i32, ptr %l86, !tbaa !23
  %t161 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t157, i32 %t158, i32 %t159, i32 %t160, i32 0, i64 0)
  store i32 %t161, ptr %l87
  br label %bb23
bb23:
  %t162 = load i32, ptr %l87, !tbaa !23
  store i32 %t162, ptr %l11, !tbaa !23
  %t163 = load i32, ptr %l11, !tbaa !23
  call void @compiler_2flower_2estandIn(ptr %t164, ptr %v1, i32 %t163)
  call void @llvm.memmove.p0.p0.i64(ptr %l89, ptr %t164, i64 136, i1 false)
  br label %bb24
bb24:
  %t166 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 136, i64 8)
  store ptr %t166, ptr %lp12
  %t167 = load ptr, ptr %lp12
  call void @llvm.memmove.p0.p0.i64(ptr %t167, ptr %l89, i64 136, i1 false)
  %t168 = load ptr, ptr %l0, !tbaa !29
  store ptr %t168, ptr %l90, !tbaa !29
  %t169 = load ptr, ptr %lp12
  store ptr %t169, ptr %l91, !tbaa !29
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t172 = getelementptr %"compiler/lower:Lowerer", ptr %t170, i32 0, i32 0
  %t173 = load ptr, ptr %t172, !tbaa !29
  %t175 = getelementptr %"compiler/generic:Program", ptr %t173, i32 0, i32 2
  store ptr %t175, ptr %l94, !tbaa !29
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t177 = load i32, ptr %l1, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t178
  %t179 = getelementptr { i64, [2 x i64] }, ptr %t178, i32 0, i32 0
  store i64 1, ptr %t179
  %t181 = insertvalue { i32 } undef, i32 %t177, 0
  %t182 = getelementptr { i64, [2 x i64] }, ptr %t178, i32 0, i32 1
  store { i32 } %t181, ptr %t182
  %t183 = load { i64, [2 x i64] }, ptr %t178
  %t184 = load i32, ptr %l11, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3aLowerer_2ebare(ptr %t185, ptr %v0, ptr %v1, ptr %t176, { i64, [2 x i64] } %t183, i32 %t184)
  call void @llvm.memmove.p0.p0.i64(ptr %l99, ptr %t185, i64 216, i1 false)
  br label %bb25
bb25:
  %t189 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 216, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t189, ptr %l99, i64 216, i1 false)
  %t191 = load ptr, ptr %l90, !tbaa !29
  %t192 = load ptr, ptr %l91, !tbaa !29
  %t193 = load ptr, ptr %l94, !tbaa !29
  call void @compiler_2flower_3alowering_2ector(ptr %t190, ptr %v0, ptr %v1, ptr %v0, ptr %v1, ptr %v1, ptr %t191, ptr %t192, ptr %t193, ptr %t189)
  call void @llvm.memmove.p0.p0.i64(ptr %l101, ptr %t190, i64 496, i1 false)
  br label %bb26
bb26:
  %t195 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 496, i64 8)
  store ptr %t195, ptr %lp13
  %t196 = load ptr, ptr %lp13
  call void @llvm.memmove.p0.p0.i64(ptr %t196, ptr %l101, i64 496, i1 false)
  %t197 = load ptr, ptr %lp13
  %t198 = load i32, ptr %l1, !tbaa !23
  %t199 = load i32, ptr %l2, !tbaa !23
  %t200 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t200, ptr %l105, !tbaa !27
  %t201 = getelementptr { i64, ptr }, ptr %l105, i32 0, i32 1
  %t202 = load ptr, ptr %t201, !tbaa !27
  %t203 = getelementptr i32, ptr %t202, i64 0
  %t204 = load i32, ptr %t203, !tbaa !33
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eadapterBody(ptr %v1, ptr %t197, i32 %t198, i32 %t199, i32 %t204)
  br label %bb27
bb27:
  %t209 = load ptr, ptr %l0, !tbaa !29
  %t210 = load ptr, ptr %lp13
  %t211 = getelementptr %"compiler/lower:lowering", ptr %t210, i32 0, i32 8
  %t212 = load i1, ptr %t211, !tbaa !21
  %t215 = getelementptr %"compiler/lower:Lowerer", ptr %t209, i32 0, i32 4
  store i1 %t212, ptr %t215, !tbaa !21
  %t216 = load ptr, ptr %lp13
  %t217 = getelementptr %"compiler/lower:lowering", ptr %t216, i32 0, i32 3
  call void @llvm.memmove.p0.p0.i64(ptr %l109, ptr %t217, i64 216, i1 false)
  call void @__olang_scope_close(ptr %s0)
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l109, i64 216, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2flower_2ecompiler_2flower_3aLowerer_2ehelperTy(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l2 = alloca i32
  %l5 = alloca i32
  %l11 = alloca i32
  %rv = alloca i32
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t3 = trunc i64 0 to i32
  %t4 = icmp eq i32 %a1, %t3
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = load i32, ptr %l2, !tbaa !23
  store i32 %t6, ptr %l5, !tbaa !23
  br label %bb4
bb2:
  %t10 = getelementptr %"compiler/lower:Lowerer", ptr %a0, i32 0, i32 0
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t13 = getelementptr %"compiler/generic:Program", ptr %t11, i32 0, i32 2
  %t14 = load i32, ptr %l2, !tbaa !23
  %t17 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eUnnamed(ptr %v0, ptr %t13, i32 %t14)
  store i32 %t17, ptr %l11
  br label %bb3
bb3:
  %t18 = load i32, ptr %l11, !tbaa !23
  store i32 %t18, ptr %l5, !tbaa !23
  br label %bb4
bb4:
  %t19 = load i32, ptr %l5, !tbaa !23
  store i32 %t19, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2flower_2ecompiler_2flower_3aLowerer_2etext(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca ptr
  %l7 = alloca i32
  %s1 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:Lowerer", ptr %t1, i32 0, i32 15
  %t4 = load i32, ptr %t3, !tbaa !23
  %t6 = icmp slt i32 %t4, 0
  br i1 %t6, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t8 = load ptr, ptr %l0, !tbaa !29
  store ptr %t8, ptr %l4, !tbaa !29
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/lower:Lowerer", ptr %t9, i32 0, i32 0
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t14 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ePreludeType(ptr %v0, ptr %s1, ptr %s1, ptr %t12, { i64, ptr } { i64 16, ptr @.d13 }, { i64, ptr } { i64 6, ptr @.d14 })
  store i32 %t14, ptr %l7
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t15 = load i32, ptr %l7, !tbaa !23
  %t16 = load ptr, ptr %l4, !tbaa !29
  %t17 = getelementptr %"compiler/lower:Lowerer", ptr %t16, i32 0, i32 15
  store i32 %t15, ptr %t17, !tbaa !23
  call void @__olang_scope_close(ptr %s1)
  br label %bb4
bb4:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/lower:Lowerer", ptr %t18, i32 0, i32 15
  %t21 = load i32, ptr %t20, !tbaa !23
  store i32 %t21, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eanyMake(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i32 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca %"compiler/source:Span"
  %l10 = alloca i32
  %l11 = alloca ptr
  %l12 = alloca { i64, [1 x i64] }
  %l13 = alloca ptr
  %l14 = alloca { i64, [4 x i64] }
  %l17 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l22 = alloca ptr
  %l23 = alloca i1
  %l32 = alloca ptr
  %l33 = alloca i1
  %l45 = alloca i1
  %l50 = alloca i1
  %l51 = alloca ptr
  %l53 = alloca { i64, ptr }
  %l55 = alloca i32
  %l56 = alloca i1
  %l60 = alloca { i64, [1 x i64] }
  %l62 = alloca { i64, ptr }
  %l67 = alloca { i64, [4 x i64] }
  %l75 = alloca i1
  %l77 = alloca ptr
  %l78 = alloca { i64, [4 x i64] }
  %l80 = alloca i32
  %l83 = alloca { i64, [4 x i64] }
  %l84 = alloca ptr
  %l85 = alloca i32
  %l86 = alloca i32
  %l90 = alloca { i64, ptr }
  %l91 = alloca %"compiler/mir:Range"
  %l94 = alloca { i64, [4 x i64] }
  %l102 = alloca { i64, [4 x i64] }
  %l103 = alloca ptr
  %l104 = alloca i32
  %l105 = alloca i32
  %l106 = alloca { i64, [4 x i64] }
  %l108 = alloca { i64, ptr }
  %l111 = alloca { i64, [4 x i64] }
  %l112 = alloca { i64, ptr }
  %l114 = alloca { i64, [4 x i64] }
  %l117 = alloca { i64, ptr }
  %l126 = alloca { i64, [4 x i64] }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca { i64, [4 x i64] }
  %t129 = alloca { i64, [4 x i64] }, align 8
  %t177 = alloca { i64, [15 x i64] }, align 8
  %t198 = alloca { i64, [15 x i64] }, align 8
  %t259 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store i32 %a2, ptr %l2
  store %"compiler/source:Span" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t6 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t6, ptr %l20, !tbaa !27
  %t7 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t8 = load ptr, ptr %t7, !tbaa !27
  %t9 = getelementptr ptr, ptr %t8, i64 0
  %t10 = load ptr, ptr %t9, !tbaa !39
  store ptr %t10, ptr %l5, !tbaa !29
  %t12 = load ptr, ptr %l5, !tbaa !29
  store ptr %t12, ptr %l22, !tbaa !29
  store i1 false, ptr %l23, !tbaa !21
  %t13 = load ptr, ptr %l22, !tbaa !29
  %t14 = icmp ne ptr %t13, null
  br i1 %t14, label %bb1, label %bb2
bb1:
  %t16 = load ptr, ptr %l22, !tbaa !29
  %t17 = load i64, ptr %t16
  %t19 = icmp eq i64 %t17, 5
  store i1 %t19, ptr %l23, !tbaa !21
  br label %bb2
bb2:
  %t20 = load i1, ptr %l23, !tbaa !21
  br i1 %t20, label %bb3, label %bb4
bb3:
  %t21 = load ptr, ptr %l5, !tbaa !29
  %t23 = getelementptr { i64, [5 x i64] }, ptr %t21, i32 0, i32 1
  %t24 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t23, i32 0, i32 1
  %t25 = load i32, ptr %t24
  store i32 %t25, ptr %l6, !tbaa !23
  %t27 = load ptr, ptr %l5, !tbaa !29
  %t29 = getelementptr { i64, [5 x i64] }, ptr %t27, i32 0, i32 1
  %t30 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t29, i32 0, i32 2
  %t31 = load ptr, ptr %t30
  store ptr %t31, ptr %l7, !tbaa !29
  br label %bb5
bb4:
  br label %bb44
bb5:
  %t33 = load ptr, ptr %l7, !tbaa !29
  %t35 = getelementptr %"compiler/typed:Promote", ptr %t33, i32 0, i32 0
  %t36 = load ptr, ptr %t35, !tbaa !29
  store ptr %t36, ptr %l8, !tbaa !29
  %t38 = load ptr, ptr %l8, !tbaa !29
  store ptr %t38, ptr %l32, !tbaa !29
  store i1 false, ptr %l33, !tbaa !21
  %t39 = load ptr, ptr %l32, !tbaa !29
  %t40 = icmp ne ptr %t39, null
  br i1 %t40, label %bb6, label %bb7
bb6:
  %t42 = load ptr, ptr %l32, !tbaa !29
  %t43 = load i64, ptr %t42
  %t45 = icmp eq i64 %t43, 7
  store i1 %t45, ptr %l33, !tbaa !21
  br label %bb7
bb7:
  %t46 = load i1, ptr %l33, !tbaa !21
  br i1 %t46, label %bb8, label %bb9
bb8:
  %t47 = load ptr, ptr %l8, !tbaa !29
  %t49 = getelementptr { i64, [5 x i64] }, ptr %t47, i32 0, i32 1
  %t50 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t49, i32 0, i32 0
  %t51 = load %"compiler/source:Span", ptr %t50
  store %"compiler/source:Span" %t51, ptr %l9
  %t53 = load ptr, ptr %l8, !tbaa !29
  %t55 = getelementptr { i64, [5 x i64] }, ptr %t53, i32 0, i32 1
  %t56 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t55, i32 0, i32 1
  %t57 = load i32, ptr %t56
  store i32 %t57, ptr %l10, !tbaa !23
  %t59 = load ptr, ptr %l8, !tbaa !29
  %t61 = getelementptr { i64, [5 x i64] }, ptr %t59, i32 0, i32 1
  %t62 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t61, i32 0, i32 2
  %t63 = load ptr, ptr %t62
  store ptr %t63, ptr %l11, !tbaa !29
  br label %bb10
bb9:
  br label %bb38
bb10:
  %t65 = load ptr, ptr %l11, !tbaa !29
  %t67 = getelementptr %"compiler/typed:Make", ptr %t65, i32 0, i32 0
  %t68 = load i32, ptr %t67
  %t70 = trunc i64 0 to i32
  %t71 = icmp eq i32 %t68, %t70
  br i1 %t71, label %bb11, label %bb12
bb11:
  %t73 = load ptr, ptr %l11, !tbaa !29
  %t75 = getelementptr %"compiler/typed:Make", ptr %t73, i32 0, i32 2
  %t76 = load { i64, ptr }, ptr %t75, !tbaa !27
  %t78 = extractvalue { i64, ptr } %t76, 0
  %t80 = icmp eq i64 %t78, 1
  store i1 %t80, ptr %l45, !tbaa !21
  br label %bb13
bb12:
  store i1 false, ptr %l45, !tbaa !21
  br label %bb13
bb13:
  %t82 = load i1, ptr %l45, !tbaa !21
  br i1 %t82, label %bb14, label %bb15
bb14:
  %t83 = load ptr, ptr %l0, !tbaa !29
  store ptr %t83, ptr %l51, !tbaa !29
  %t84 = load ptr, ptr %l11, !tbaa !29
  %t86 = getelementptr %"compiler/typed:Make", ptr %t84, i32 0, i32 2
  %t87 = load { i64, ptr }, ptr %t86, !tbaa !27
  store { i64, ptr } %t87, ptr %l53, !tbaa !27
  %t88 = getelementptr { i64, ptr }, ptr %l53, i32 0, i32 1
  %t89 = load ptr, ptr %t88, !tbaa !27
  %t90 = getelementptr ptr, ptr %t89, i64 0
  %t91 = load ptr, ptr %t90, !tbaa !39
  %t93 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t91)
  store i32 %t93, ptr %l55
  br label %bb16
bb15:
  store i1 false, ptr %l50, !tbaa !21
  br label %bb18
bb16:
  %t94 = load ptr, ptr %l51, !tbaa !29
  %t95 = load i32, ptr %l55, !tbaa !23
  %t96 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2evalueArray(ptr %v0, ptr %t94, i32 %t95)
  store i1 %t96, ptr %l56
  br label %bb17
bb17:
  %t97 = load i1, ptr %l56, !tbaa !21
  store i1 %t97, ptr %l50, !tbaa !21
  br label %bb18
bb18:
  %t98 = load i1, ptr %l50, !tbaa !21
  br i1 %t98, label %bb19, label %bb20
bb19:
  store %olang.scope zeroinitializer, ptr %s3
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t100 = load ptr, ptr %l7, !tbaa !29
  %t102 = getelementptr %"compiler/typed:Promote", ptr %t100, i32 0, i32 1
  %t103 = load i32, ptr %t102, !tbaa !23
  %t106 = call { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ebuilt(ptr %v0, ptr %t99, i32 %t103)
  store { i64, [1 x i64] } %t106, ptr %l60
  br label %bb21
bb20:
  br label %bb37
bb21:
  %t107 = load { i64, [1 x i64] }, ptr %l60
  store { i64, [1 x i64] } %t107, ptr %l12
  %t108 = load ptr, ptr %l11, !tbaa !29
  %t110 = getelementptr %"compiler/typed:Make", ptr %t108, i32 0, i32 2
  %t111 = load { i64, ptr }, ptr %t110, !tbaa !27
  store { i64, ptr } %t111, ptr %l62, !tbaa !27
  %t112 = getelementptr { i64, ptr }, ptr %l62, i32 0, i32 1
  %t113 = load ptr, ptr %t112, !tbaa !27
  %t114 = getelementptr ptr, ptr %t113, i64 0
  %t115 = load ptr, ptr %t114, !tbaa !39
  store ptr %t115, ptr %l13, !tbaa !29
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t118 = load ptr, ptr %l13, !tbaa !29
  %t122 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v1, ptr %t117, ptr %t118)
  store { i64, [4 x i64] } %t122, ptr %l67
  br label %bb22
bb22:
  %t123 = load { i64, [4 x i64] }, ptr %l67
  store { i64, [4 x i64] } %t123, ptr %l14
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t126 = getelementptr %"compiler/lower:lowering", ptr %t124, i32 0, i32 7
  %t127 = load i1, ptr %t126, !tbaa !21
  br i1 %t127, label %bb23, label %bb24
bb23:
  store { i64, [4 x i64] } zeroinitializer, ptr %t129
  %t130 = getelementptr { i64, [4 x i64] }, ptr %t129, i32 0, i32 0
  store i64 0, ptr %t130
  %t131 = load { i64, [4 x i64] }, ptr %t129
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  store { i64, [4 x i64] } %t131, ptr %rv
  br label %ret
bb24:
  br label %bb25
bb25:
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t135 = getelementptr %"compiler/lower:lowering", ptr %t133, i32 0, i32 2
  %t136 = load ptr, ptr %t135, !tbaa !29
  %t137 = load ptr, ptr %l13, !tbaa !29
  %t141 = call i1 @compiler_2ftyped_2eAnyItemNew(ptr %v0, ptr %v1, ptr %t136, ptr %t137)
  store i1 %t141, ptr %l75
  br label %bb26
bb26:
  %t142 = load i1, ptr %l75, !tbaa !21
  %t143 = xor i1 %t142, true
  br i1 %t143, label %bb27, label %bb28
bb27:
  %t145 = load ptr, ptr %l0, !tbaa !29
  store ptr %t145, ptr %l77, !tbaa !29
  %t146 = load { i64, [4 x i64] }, ptr %l14
  store { i64, [4 x i64] } %t146, ptr %l78
  %t147 = load ptr, ptr %l13, !tbaa !29
  %t149 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t147)
  store i32 %t149, ptr %l80
  br label %bb29
bb28:
  br label %bb31
bb29:
  %t150 = load %"compiler/source:Span", ptr %l3
  %t151 = load { i64, [1 x i64] }, ptr %l12
  %t152 = load ptr, ptr %l77, !tbaa !29
  %t153 = load { i64, [4 x i64] }, ptr %l78
  %t154 = load i32, ptr %l80, !tbaa !23
  %t157 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2earrayCopy(ptr %v0, ptr %t152, { i64, [4 x i64] } %t153, i32 %t154, %"compiler/source:Span" %t150, { i64, [1 x i64] } %t151)
  store { i64, [4 x i64] } %t157, ptr %l83
  br label %bb30
bb30:
  %t158 = load { i64, [4 x i64] }, ptr %l83
  store { i64, [4 x i64] } %t158, ptr %l14
  br label %bb31
bb31:
  %t159 = load ptr, ptr %l0, !tbaa !29
  store ptr %t159, ptr %l84, !tbaa !29
  %t160 = load i32, ptr %l10, !tbaa !23
  store i32 %t160, ptr %l85, !tbaa !23
  %t161 = load i32, ptr %l10, !tbaa !23
  store i32 %t161, ptr %l86, !tbaa !23
  %t162 = load ptr, ptr %l0, !tbaa !29
  %t164 = getelementptr %"compiler/lower:lowering", ptr %t162, i32 0, i32 3
  %t165 = load { i64, [4 x i64] }, ptr %l14
  %t166 = mul i64 1, 40
  %t167 = call ptr @__olang_scope_alloc_zeroed(ptr %s3, i64 %t166)
  %t168 = insertvalue { i64, ptr } undef, i64 1, 0
  %t169 = insertvalue { i64, ptr } %t168, ptr %t167, 1
  store { i64, ptr } %t169, ptr %l90, !tbaa !27
  %t171 = getelementptr { i64, ptr }, ptr %l90, i32 0, i32 1
  %t172 = load ptr, ptr %t171, !tbaa !27
  %t173 = getelementptr { i64, [4 x i64] }, ptr %t172, i64 0
  store { i64, [4 x i64] } %t165, ptr %t173
  %t175 = load { i64, ptr }, ptr %l90, !tbaa !27
  %t176 = call %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eArgs(ptr %v0, ptr %s3, ptr %t164, { i64, ptr } %t175)
  store %"compiler/mir:Range" %t176, ptr %l91
  br label %bb32
bb32:
  store { i64, [15 x i64] } zeroinitializer, ptr %t177
  %t178 = getelementptr { i64, [15 x i64] }, ptr %t177, i32 0, i32 0
  store i64 6, ptr %t178
  %t179 = load i32, ptr %l86, !tbaa !23
  %t180 = insertvalue { i32, i64, %"compiler/mir:Range" } undef, i32 %t179, 0
  %t181 = insertvalue { i32, i64, %"compiler/mir:Range" } %t180, i64 0, 1
  %t182 = load %"compiler/mir:Range", ptr %l91
  %t183 = insertvalue { i32, i64, %"compiler/mir:Range" } %t181, %"compiler/mir:Range" %t182, 2
  %t184 = getelementptr { i64, [15 x i64] }, ptr %t177, i32 0, i32 1
  store { i32, i64, %"compiler/mir:Range" } %t183, ptr %t184
  %t185 = load { i64, [15 x i64] }, ptr %t177
  %t186 = load %"compiler/source:Span", ptr %l9
  %t187 = load ptr, ptr %l84, !tbaa !29
  %t188 = load i32, ptr %l85, !tbaa !23
  %t191 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %t187, i32 %t188, { i64, [15 x i64] } %t185, %"compiler/source:Span" %t186)
  store { i64, [4 x i64] } %t191, ptr %l94
  br label %bb33
bb33:
  %t192 = load { i64, [4 x i64] }, ptr %l94
  %t193 = load ptr, ptr %l0, !tbaa !29
  %t194 = load i32, ptr %l6, !tbaa !23
  %t195 = load { i64, [1 x i64] }, ptr %l12
  %t197 = load i32, ptr %l6, !tbaa !23
  store { i64, [15 x i64] } zeroinitializer, ptr %t198
  %t199 = getelementptr { i64, [15 x i64] }, ptr %t198, i32 0, i32 0
  store i64 7, ptr %t199
  %t201 = insertvalue { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 } undef, { i64, [1 x i64] } %t195, 0
  %t203 = insertvalue { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 } %t201, { i64, [4 x i64] } %t192, 1
  %t205 = insertvalue { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 } %t203, i32 %t197, 2
  %t206 = getelementptr { i64, [15 x i64] }, ptr %t198, i32 0, i32 1
  store { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 } %t205, ptr %t206
  %t207 = load { i64, [15 x i64] }, ptr %t198
  %t208 = load %"compiler/source:Span", ptr %l3
  %t213 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %t193, i32 %t194, { i64, [15 x i64] } %t207, %"compiler/source:Span" %t208)
  store { i64, [4 x i64] } %t213, ptr %l102
  br label %bb34
bb34:
  %t214 = load { i64, [4 x i64] }, ptr %l102
  %t215 = load ptr, ptr %l0, !tbaa !29
  store ptr %t215, ptr %l103, !tbaa !29
  store i32 37, ptr %l104
  %t216 = load i32, ptr %l2, !tbaa !23
  store i32 %t216, ptr %l105, !tbaa !23
  store { i64, [4 x i64] } %t214, ptr %l106
  %t218 = load ptr, ptr %l0, !tbaa !29
  %t219 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t219, ptr %l108, !tbaa !27
  %t220 = getelementptr { i64, ptr }, ptr %l108, i32 0, i32 1
  %t221 = load ptr, ptr %t220, !tbaa !27
  %t222 = getelementptr ptr, ptr %t221, i64 1
  %t223 = load ptr, ptr %t222, !tbaa !39
  %t227 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v1, ptr %t218, ptr %t223)
  store { i64, [4 x i64] } %t227, ptr %l111
  br label %bb35
bb35:
  %t228 = mul i64 2, 40
  %t229 = call ptr @__olang_scope_alloc_zeroed(ptr %s3, i64 %t228)
  %t230 = insertvalue { i64, ptr } undef, i64 2, 0
  %t231 = insertvalue { i64, ptr } %t230, ptr %t229, 1
  store { i64, ptr } %t231, ptr %l112, !tbaa !27
  %t232 = load { i64, [4 x i64] }, ptr %l106
  %t233 = getelementptr { i64, ptr }, ptr %l112, i32 0, i32 1
  %t234 = load ptr, ptr %t233, !tbaa !27
  %t235 = getelementptr { i64, [4 x i64] }, ptr %t234, i64 0
  store { i64, [4 x i64] } %t232, ptr %t235
  %t236 = load { i64, [4 x i64] }, ptr %l111
  %t237 = getelementptr { i64, ptr }, ptr %l112, i32 0, i32 1
  %t238 = load ptr, ptr %t237, !tbaa !27
  %t239 = getelementptr { i64, [4 x i64] }, ptr %t238, i64 1
  store { i64, [4 x i64] } %t236, ptr %t239
  %t240 = load %"compiler/source:Span", ptr %l3
  %t241 = load ptr, ptr %l103, !tbaa !29
  %t242 = load i32, ptr %l104
  %t243 = load i32, ptr %l105, !tbaa !23
  %t244 = load { i64, ptr }, ptr %l112, !tbaa !27
  %t246 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s3, ptr %t241, i32 %t242, i32 %t243, { i64, ptr } %t244, %"compiler/source:Span" %t240)
  store { i64, [4 x i64] } %t246, ptr %l114
  br label %bb36
bb36:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t247 = load { i64, [4 x i64] }, ptr %l114
  store { i64, [4 x i64] } %t247, ptr %rv
  br label %ret
bb37:
  br label %bb43
bb38:
  br i1 true, label %bb39, label %bb40
bb39:
  br label %bb41
bb40:
  br label %bb42
bb41:
  br label %bb43
bb42:
  call void @__olang_check_failed(ptr @olang_loc_95894c0b36292ffb_c517f6bdfd218a6f)
  unreachable
bb43:
  br label %bb49
bb44:
  br i1 true, label %bb45, label %bb46
bb45:
  br label %bb47
bb46:
  br label %bb48
bb47:
  br label %bb49
bb48:
  call void @__olang_check_failed(ptr @olang_loc_e6eae32e21930b7a_6f5872ba2e210dae)
  unreachable
bb49:
  %t248 = load ptr, ptr %l0, !tbaa !29
  %t249 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t252 = call { i64, ptr } @compiler_2flower_2ecompiler_2flower_3alowering_2evals(ptr %v0, ptr %v1, ptr %s0, ptr %t248, { i64, ptr } %t249)
  store { i64, ptr } %t252, ptr %l117
  br label %bb50
bb50:
  %t253 = load { i64, ptr }, ptr %l117, !tbaa !27
  store { i64, ptr } %t253, ptr %l17, !tbaa !27
  %t254 = load ptr, ptr %l0, !tbaa !29
  %t256 = getelementptr %"compiler/lower:lowering", ptr %t254, i32 0, i32 7
  %t257 = load i1, ptr %t256, !tbaa !21
  br i1 %t257, label %bb51, label %bb52
bb51:
  store { i64, [4 x i64] } zeroinitializer, ptr %t259
  %t260 = getelementptr { i64, [4 x i64] }, ptr %t259, i32 0, i32 0
  store i64 0, ptr %t260
  %t261 = load { i64, [4 x i64] }, ptr %t259
  call void @__olang_scope_close(ptr %s0)
  store { i64, [4 x i64] } %t261, ptr %rv
  br label %ret
bb52:
  br label %bb53
bb53:
  %t263 = load ptr, ptr %l0, !tbaa !29
  %t264 = load i32, ptr %l2, !tbaa !23
  %t265 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t266 = load %"compiler/source:Span", ptr %l3
  %t272 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s0, ptr %t263, i32 37, i32 %t264, { i64, ptr } %t265, %"compiler/source:Span" %t266)
  store { i64, [4 x i64] } %t272, ptr %l126
  br label %bb54
bb54:
  call void @__olang_scope_close(ptr %s0)
  %t273 = load { i64, [4 x i64] }, ptr %l126
  store { i64, [4 x i64] } %t273, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2earm(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca { i64, [4 x i64] }
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l8 = alloca { i64, [4 x i64] }
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l13 = alloca { i64, [4 x i64] }
  %l21 = alloca i1
  %l28 = alloca { i64, [4 x i64] }
  %l29 = alloca ptr
  %l31 = alloca %"compiler/source:Span"
  %l33 = alloca %"compiler/mir:Place"
  %l40 = alloca i64
  %l42 = alloca i1
  %l44 = alloca %"compiler/lower:level"
  %l45 = alloca i32
  %l67 = alloca { i64, ptr }
  %l78 = alloca i1
  %l85 = alloca { i64, [4 x i64] }
  %l86 = alloca ptr
  %l88 = alloca %"compiler/source:Span"
  %l90 = alloca %"compiler/mir:Place"
  %l95 = alloca ptr
  %l115 = alloca { i64, ptr }
  %l126 = alloca i1
  %l133 = alloca { i64, [4 x i64] }
  %l134 = alloca ptr
  %l136 = alloca %"compiler/source:Span"
  %l138 = alloca %"compiler/mir:Place"
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %t42 = alloca { i64, [15 x i64] }, align 8
  %t48 = alloca { i64, [21 x i64] }, align 8
  %t173 = alloca { i64, [15 x i64] }, align 8
  %t179 = alloca { i64, [21 x i64] }, align 8
  %t286 = alloca { i64, [15 x i64] }, align 8
  %t292 = alloca { i64, [21 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Arm", ptr %t1, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = icmp eq ptr %t4, null
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t8 = load ptr, ptr %l1, !tbaa !29
  %t10 = getelementptr %"compiler/typed:Arm", ptr %t8, i32 0, i32 4
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t13 = icmp eq ptr %t11, null
  %t15 = xor i1 %t13, true
  br i1 %t15, label %bb3, label %bb4
bb2:
  br label %bb12
bb3:
  %t17 = load i32, ptr %l2, !tbaa !23
  %t18 = load i32, ptr @G_2ecompiler_2fmir_2eNoLocal, !tbaa !23
  %t21 = icmp ne i32 %t17, %t18
  store i1 %t21, ptr %l21, !tbaa !21
  br label %bb5
bb4:
  store i1 false, ptr %l21, !tbaa !21
  br label %bb5
bb5:
  %t23 = load i1, ptr %l21, !tbaa !21
  br i1 %t23, label %bb6, label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s2
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr %"compiler/typed:Arm", ptr %t25, i32 0, i32 4
  %t28 = load ptr, ptr %t27, !tbaa !29
  %t31 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v1, ptr %t24, ptr %t28)
  store { i64, [4 x i64] } %t31, ptr %l28
  br label %bb8
bb7:
  br label %bb11
bb8:
  %t32 = load { i64, [4 x i64] }, ptr %l28
  store { i64, [4 x i64] } %t32, ptr %l3
  %t33 = load ptr, ptr %l0, !tbaa !29
  store ptr %t33, ptr %l29, !tbaa !29
  %t34 = load ptr, ptr %l1, !tbaa !29
  %t36 = getelementptr %"compiler/typed:Arm", ptr %t34, i32 0, i32 0
  %t37 = load %"compiler/source:Span", ptr %t36
  store %"compiler/source:Span" %t37, ptr %l31
  %t38 = load i32, ptr %l2, !tbaa !23
  %t40 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t38)
  store %"compiler/mir:Place" %t40, ptr %l33
  br label %bb9
bb9:
  %t41 = load { i64, [4 x i64] }, ptr %l3
  store { i64, [15 x i64] } zeroinitializer, ptr %t42
  %t43 = getelementptr { i64, [15 x i64] }, ptr %t42, i32 0, i32 0
  store i64 0, ptr %t43
  %t45 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t41, 0
  %t46 = getelementptr { i64, [15 x i64] }, ptr %t42, i32 0, i32 1
  store { { i64, [4 x i64] } } %t45, ptr %t46
  %t47 = load { i64, [15 x i64] }, ptr %t42
  store { i64, [21 x i64] } zeroinitializer, ptr %t48
  %t49 = getelementptr { i64, [21 x i64] }, ptr %t48, i32 0, i32 0
  store i64 0, ptr %t49
  %t50 = load %"compiler/source:Span", ptr %l31
  %t51 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t50, 0
  %t52 = load %"compiler/mir:Place", ptr %l33
  %t53 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t51, %"compiler/mir:Place" %t52, 1
  %t55 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t53, { i64, [15 x i64] } %t47, 2
  %t56 = getelementptr { i64, [21 x i64] }, ptr %t48, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t55, ptr %t56
  %t57 = load { i64, [21 x i64] }, ptr %t48
  %t59 = call ptr @__olang_scope_alloc_a(ptr %s2, i64 176, i64 8)
  store { i64, [21 x i64] } %t57, ptr %t59
  %t60 = load ptr, ptr %l29, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s2, ptr %t60, ptr %t59)
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb11
bb11:
  br label %ret
bb12:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/lower:lowering", ptr %t62, i32 0, i32 9
  %t66 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3alevel_3e_2eLen_3ccompiler_2flower_3alevel_3e(ptr %v0, ptr %t64)
  store i64 %t66, ptr %l40
  br label %bb13
bb13:
  %t67 = load i64, ptr %l40, !tbaa !24
  %t68 = icmp sgt i64 %t67, 0
  br i1 %t68, label %bb14, label %bb15
bb14:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = call %"compiler/lower:level" @compiler_2flower_2ecompiler_2flower_3alowering_2etop(ptr %v0, ptr %t70)
  store %"compiler/lower:level" %t72, ptr %l44
  br label %bb16
bb15:
  store i1 false, ptr %l42, !tbaa !21
  br label %bb20
bb16:
  %t73 = getelementptr %"compiler/lower:level", ptr %l44, i32 0, i32 1
  %t74 = load i32, ptr %t73, !tbaa !23
  store i32 %t74, ptr %l45, !tbaa !23
  %t75 = load ptr, ptr %l1, !tbaa !29
  %t77 = getelementptr %"compiler/typed:Arm", ptr %t75, i32 0, i32 3
  %t78 = load ptr, ptr %t77, !tbaa !29
  %t80 = icmp eq ptr %t78, null
  br i1 %t80, label %bb17, label %bb18
bb17:
  call void @__olang_check_failed(ptr @olang_loc_2262f7260befbeda_ad33d1a86099f68e)
  unreachable
bb18:
  br label %bb19
bb19:
  %t82 = load ptr, ptr %l1, !tbaa !29
  %t84 = getelementptr %"compiler/typed:Arm", ptr %t82, i32 0, i32 3
  %t85 = load ptr, ptr %t84, !tbaa !29
  %t88 = getelementptr %"compiler/typed:Block", ptr %t85, i32 0, i32 0
  %t89 = load i32, ptr %t88, !tbaa !23
  %t90 = load i32, ptr %l45, !tbaa !23
  %t92 = icmp eq i32 %t90, %t89
  store i1 %t92, ptr %l42, !tbaa !21
  br label %bb20
bb20:
  %t94 = load i1, ptr %l42, !tbaa !21
  br i1 %t94, label %bb21, label %bb22
bb21:
  %t95 = load ptr, ptr %l1, !tbaa !29
  %t97 = getelementptr %"compiler/typed:Arm", ptr %t95, i32 0, i32 3
  %t98 = load ptr, ptr %t97, !tbaa !29
  %t100 = icmp eq ptr %t98, null
  br i1 %t100, label %bb23, label %bb24
bb22:
  br label %bb42
bb23:
  call void @__olang_check_failed(ptr @olang_loc_78466967dd42e061_bdc585e3e8213235)
  unreachable
bb24:
  br label %bb25
bb25:
  %t102 = load ptr, ptr %l1, !tbaa !29
  %t104 = getelementptr %"compiler/typed:Arm", ptr %t102, i32 0, i32 3
  %t105 = load ptr, ptr %t104, !tbaa !29
  %t108 = getelementptr %"compiler/typed:Block", ptr %t105, i32 0, i32 1
  %t109 = load { i64, ptr }, ptr %t108, !tbaa !27
  store { i64, ptr } %t109, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t111 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t113 = extractvalue { i64, ptr } %t111, 0
  store i64 %t113, ptr %l6, !tbaa !24
  br label %bb26
bb26:
  store %olang.scope zeroinitializer, ptr %s5
  %t115 = load i64, ptr %l5, !tbaa !24
  %t116 = load i64, ptr %l6, !tbaa !24
  %t119 = icmp slt i64 %t115, %t116
  %t121 = xor i1 %t119, true
  br i1 %t121, label %bb27, label %bb28
bb27:
  call void @__olang_scope_close(ptr %s5)
  br label %bb32
bb28:
  br label %bb29
bb29:
  %t123 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t123, ptr %l67, !tbaa !27
  %t124 = load i64, ptr %l5, !tbaa !24
  %t126 = getelementptr { i64, ptr }, ptr %l67, i32 0, i32 1
  %t127 = load ptr, ptr %t126, !tbaa !27
  %t128 = getelementptr ptr, ptr %t127, i64 %t124
  %t129 = load ptr, ptr %t128, !tbaa !39
  %t131 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estmt(ptr %v0, ptr %v1, ptr %t131, ptr %t129)
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s5)
  br label %bb31
bb31:
  %t135 = load i64, ptr %l5, !tbaa !24
  %t137 = add i64 %t135, 1
  store i64 %t137, ptr %l5, !tbaa !24
  br label %bb26
bb32:
  %t139 = load ptr, ptr %l1, !tbaa !29
  %t141 = getelementptr %"compiler/typed:Arm", ptr %t139, i32 0, i32 4
  %t142 = load ptr, ptr %t141, !tbaa !29
  %t144 = icmp eq ptr %t142, null
  %t146 = xor i1 %t144, true
  br i1 %t146, label %bb33, label %bb34
bb33:
  %t148 = load i32, ptr %l2, !tbaa !23
  %t149 = load i32, ptr @G_2ecompiler_2fmir_2eNoLocal, !tbaa !23
  %t152 = icmp ne i32 %t148, %t149
  store i1 %t152, ptr %l78, !tbaa !21
  br label %bb35
bb34:
  store i1 false, ptr %l78, !tbaa !21
  br label %bb35
bb35:
  %t154 = load i1, ptr %l78, !tbaa !21
  br i1 %t154, label %bb36, label %bb37
bb36:
  store %olang.scope zeroinitializer, ptr %s7
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t156 = load ptr, ptr %l1, !tbaa !29
  %t158 = getelementptr %"compiler/typed:Arm", ptr %t156, i32 0, i32 4
  %t159 = load ptr, ptr %t158, !tbaa !29
  %t162 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v1, ptr %t155, ptr %t159)
  store { i64, [4 x i64] } %t162, ptr %l85
  br label %bb38
bb37:
  br label %bb41
bb38:
  %t163 = load { i64, [4 x i64] }, ptr %l85
  store { i64, [4 x i64] } %t163, ptr %l8
  %t164 = load ptr, ptr %l0, !tbaa !29
  store ptr %t164, ptr %l86, !tbaa !29
  %t165 = load ptr, ptr %l1, !tbaa !29
  %t167 = getelementptr %"compiler/typed:Arm", ptr %t165, i32 0, i32 0
  %t168 = load %"compiler/source:Span", ptr %t167
  store %"compiler/source:Span" %t168, ptr %l88
  %t169 = load i32, ptr %l2, !tbaa !23
  %t171 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t169)
  store %"compiler/mir:Place" %t171, ptr %l90
  br label %bb39
bb39:
  %t172 = load { i64, [4 x i64] }, ptr %l8
  store { i64, [15 x i64] } zeroinitializer, ptr %t173
  %t174 = getelementptr { i64, [15 x i64] }, ptr %t173, i32 0, i32 0
  store i64 0, ptr %t174
  %t176 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t172, 0
  %t177 = getelementptr { i64, [15 x i64] }, ptr %t173, i32 0, i32 1
  store { { i64, [4 x i64] } } %t176, ptr %t177
  %t178 = load { i64, [15 x i64] }, ptr %t173
  store { i64, [21 x i64] } zeroinitializer, ptr %t179
  %t180 = getelementptr { i64, [21 x i64] }, ptr %t179, i32 0, i32 0
  store i64 0, ptr %t180
  %t181 = load %"compiler/source:Span", ptr %l88
  %t182 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t181, 0
  %t183 = load %"compiler/mir:Place", ptr %l90
  %t184 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t182, %"compiler/mir:Place" %t183, 1
  %t186 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t184, { i64, [15 x i64] } %t178, 2
  %t187 = getelementptr { i64, [21 x i64] }, ptr %t179, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t186, ptr %t187
  %t188 = load { i64, [21 x i64] }, ptr %t179
  %t190 = call ptr @__olang_scope_alloc_a(ptr %s7, i64 176, i64 8)
  store { i64, [21 x i64] } %t188, ptr %t190
  %t191 = load ptr, ptr %l86, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s7, ptr %t191, ptr %t190)
  br label %bb40
bb40:
  call void @__olang_scope_close(ptr %s7)
  br label %bb41
bb41:
  br label %ret
bb42:
  %t193 = load ptr, ptr %l0, !tbaa !29
  store ptr %t193, ptr %l95, !tbaa !29
  %t194 = load ptr, ptr %l1, !tbaa !29
  %t196 = getelementptr %"compiler/typed:Arm", ptr %t194, i32 0, i32 3
  %t197 = load ptr, ptr %t196, !tbaa !29
  %t199 = icmp eq ptr %t197, null
  br i1 %t199, label %bb43, label %bb44
bb43:
  call void @__olang_check_failed(ptr @olang_loc_6143a96035d3ceac_ef612191f7538720)
  unreachable
bb44:
  br label %bb45
bb45:
  %t201 = load ptr, ptr %l1, !tbaa !29
  %t203 = getelementptr %"compiler/typed:Arm", ptr %t201, i32 0, i32 3
  %t204 = load ptr, ptr %t203, !tbaa !29
  %t205 = load ptr, ptr %l95, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eopenBlock(ptr %v0, ptr %v1, ptr %t205, ptr %t204, i32 1, i32 0)
  br label %bb46
bb46:
  %t208 = load ptr, ptr %l1, !tbaa !29
  %t210 = getelementptr %"compiler/typed:Arm", ptr %t208, i32 0, i32 3
  %t211 = load ptr, ptr %t210, !tbaa !29
  %t213 = icmp eq ptr %t211, null
  br i1 %t213, label %bb47, label %bb48
bb47:
  call void @__olang_check_failed(ptr @olang_loc_9919e1798def049b_eb223155b689b93f)
  unreachable
bb48:
  br label %bb49
bb49:
  %t215 = load ptr, ptr %l1, !tbaa !29
  %t217 = getelementptr %"compiler/typed:Arm", ptr %t215, i32 0, i32 3
  %t218 = load ptr, ptr %t217, !tbaa !29
  %t221 = getelementptr %"compiler/typed:Block", ptr %t218, i32 0, i32 1
  %t222 = load { i64, ptr }, ptr %t221, !tbaa !27
  store { i64, ptr } %t222, ptr %l9, !tbaa !27
  store i64 0, ptr %l10, !tbaa !24
  %t224 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t226 = extractvalue { i64, ptr } %t224, 0
  store i64 %t226, ptr %l11, !tbaa !24
  br label %bb50
bb50:
  store %olang.scope zeroinitializer, ptr %s9
  %t228 = load i64, ptr %l10, !tbaa !24
  %t229 = load i64, ptr %l11, !tbaa !24
  %t232 = icmp slt i64 %t228, %t229
  %t234 = xor i1 %t232, true
  br i1 %t234, label %bb51, label %bb52
bb51:
  call void @__olang_scope_close(ptr %s9)
  br label %bb56
bb52:
  br label %bb53
bb53:
  %t236 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t236, ptr %l115, !tbaa !27
  %t237 = load i64, ptr %l10, !tbaa !24
  %t239 = getelementptr { i64, ptr }, ptr %l115, i32 0, i32 1
  %t240 = load ptr, ptr %t239, !tbaa !27
  %t241 = getelementptr ptr, ptr %t240, i64 %t237
  %t242 = load ptr, ptr %t241, !tbaa !39
  %t244 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estmt(ptr %v0, ptr %v1, ptr %t244, ptr %t242)
  br label %bb54
bb54:
  call void @__olang_scope_close(ptr %s9)
  br label %bb55
bb55:
  %t248 = load i64, ptr %l10, !tbaa !24
  %t250 = add i64 %t248, 1
  store i64 %t250, ptr %l10, !tbaa !24
  br label %bb50
bb56:
  %t252 = load ptr, ptr %l1, !tbaa !29
  %t254 = getelementptr %"compiler/typed:Arm", ptr %t252, i32 0, i32 4
  %t255 = load ptr, ptr %t254, !tbaa !29
  %t257 = icmp eq ptr %t255, null
  %t259 = xor i1 %t257, true
  br i1 %t259, label %bb57, label %bb58
bb57:
  %t261 = load i32, ptr %l2, !tbaa !23
  %t262 = load i32, ptr @G_2ecompiler_2fmir_2eNoLocal, !tbaa !23
  %t265 = icmp ne i32 %t261, %t262
  store i1 %t265, ptr %l126, !tbaa !21
  br label %bb59
bb58:
  store i1 false, ptr %l126, !tbaa !21
  br label %bb59
bb59:
  %t267 = load i1, ptr %l126, !tbaa !21
  br i1 %t267, label %bb60, label %bb61
bb60:
  store %olang.scope zeroinitializer, ptr %s11
  %t268 = load ptr, ptr %l0, !tbaa !29
  %t269 = load ptr, ptr %l1, !tbaa !29
  %t271 = getelementptr %"compiler/typed:Arm", ptr %t269, i32 0, i32 4
  %t272 = load ptr, ptr %t271, !tbaa !29
  %t275 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v1, ptr %t268, ptr %t272)
  store { i64, [4 x i64] } %t275, ptr %l133
  br label %bb62
bb61:
  br label %bb65
bb62:
  %t276 = load { i64, [4 x i64] }, ptr %l133
  store { i64, [4 x i64] } %t276, ptr %l13
  %t277 = load ptr, ptr %l0, !tbaa !29
  store ptr %t277, ptr %l134, !tbaa !29
  %t278 = load ptr, ptr %l1, !tbaa !29
  %t280 = getelementptr %"compiler/typed:Arm", ptr %t278, i32 0, i32 0
  %t281 = load %"compiler/source:Span", ptr %t280
  store %"compiler/source:Span" %t281, ptr %l136
  %t282 = load i32, ptr %l2, !tbaa !23
  %t284 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t282)
  store %"compiler/mir:Place" %t284, ptr %l138
  br label %bb63
bb63:
  %t285 = load { i64, [4 x i64] }, ptr %l13
  store { i64, [15 x i64] } zeroinitializer, ptr %t286
  %t287 = getelementptr { i64, [15 x i64] }, ptr %t286, i32 0, i32 0
  store i64 0, ptr %t287
  %t289 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t285, 0
  %t290 = getelementptr { i64, [15 x i64] }, ptr %t286, i32 0, i32 1
  store { { i64, [4 x i64] } } %t289, ptr %t290
  %t291 = load { i64, [15 x i64] }, ptr %t286
  store { i64, [21 x i64] } zeroinitializer, ptr %t292
  %t293 = getelementptr { i64, [21 x i64] }, ptr %t292, i32 0, i32 0
  store i64 0, ptr %t293
  %t294 = load %"compiler/source:Span", ptr %l136
  %t295 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t294, 0
  %t296 = load %"compiler/mir:Place", ptr %l138
  %t297 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t295, %"compiler/mir:Place" %t296, 1
  %t299 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t297, { i64, [15 x i64] } %t291, 2
  %t300 = getelementptr { i64, [21 x i64] }, ptr %t292, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t299, ptr %t300
  %t301 = load { i64, [21 x i64] }, ptr %t292
  %t303 = call ptr @__olang_scope_alloc_a(ptr %s11, i64 176, i64 8)
  store { i64, [21 x i64] } %t301, ptr %t303
  %t304 = load ptr, ptr %l134, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s11, ptr %t304, ptr %t303)
  br label %bb64
bb64:
  call void @__olang_scope_close(ptr %s11)
  br label %bb65
bb65:
  %t306 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2ecloseBlock(ptr %v0, ptr %t306)
  br label %bb66
bb66:
  br label %ret
ret:
  ret void
}

define dso_local { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2earrayCopy(ptr %v0, ptr %a0, { i64, [4 x i64] } %a1, i32 %a2, %"compiler/source:Span" %a3, { i64, [1 x i64] } %a4) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca { i64, [4 x i64] }
  %l8 = alloca i32
  %l9 = alloca i32
  %l16 = alloca i32
  %l17 = alloca ptr
  %l18 = alloca i32
  %l19 = alloca i32
  %l21 = alloca %"compiler/mir:Place"
  %l23 = alloca { i64, ptr }
  %l25 = alloca { i64, [4 x i64] }
  %l29 = alloca i32
  %l30 = alloca ptr
  %l33 = alloca i32
  %l34 = alloca i32
  %l35 = alloca ptr
  %l36 = alloca %"compiler/source:Span"
  %l38 = alloca %"compiler/mir:Place"
  %l47 = alloca ptr
  %l48 = alloca %"compiler/source:Span"
  %l50 = alloca %"compiler/mir:Place"
  %l52 = alloca %"compiler/mir:Place"
  %l57 = alloca %"compiler/mir:Place"
  %s0 = alloca %olang.scope
  %rv = alloca { i64, [4 x i64] }
  %t21 = alloca { i64, [4 x i64] }, align 8
  %t70 = alloca { i64, [4 x i64] }, align 8
  %t77 = alloca { i64, [15 x i64] }, align 8
  %t89 = alloca { i64, [21 x i64] }, align 8
  %t112 = alloca { i64, [21 x i64] }, align 8
  %t131 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  store %"compiler/source:Span" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l5, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = load i32, ptr %l2, !tbaa !23
  %t9 = load %"compiler/source:Span", ptr %l3
  %t14 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2elocal(ptr %v0, ptr %t6, { i64, [4 x i64] } %a1, i32 %t8, %"compiler/source:Span" %t9)
  store i32 %t14, ptr %l16
  br label %bb1
bb1:
  %t15 = load i32, ptr %l16, !tbaa !23
  store i32 %t15, ptr %l6, !tbaa !23
  %t16 = load ptr, ptr %l0, !tbaa !29
  store ptr %t16, ptr %l17, !tbaa !29
  store i32 22, ptr %l18
  %t17 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  store i32 %t17, ptr %l19, !tbaa !23
  %t18 = load i32, ptr %l6, !tbaa !23
  %t20 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t18)
  store %"compiler/mir:Place" %t20, ptr %l21
  br label %bb2
bb2:
  store { i64, [4 x i64] } zeroinitializer, ptr %t21
  %t22 = getelementptr { i64, [4 x i64] }, ptr %t21, i32 0, i32 0
  store i64 1, ptr %t22
  %t23 = load %"compiler/mir:Place", ptr %l21
  %t24 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t23, 0
  %t25 = getelementptr { i64, [4 x i64] }, ptr %t21, i32 0, i32 1
  store { %"compiler/mir:Place" } %t24, ptr %t25
  %t26 = load { i64, [4 x i64] }, ptr %t21
  %t27 = mul i64 1, 40
  %t28 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t27)
  %t29 = insertvalue { i64, ptr } undef, i64 1, 0
  %t30 = insertvalue { i64, ptr } %t29, ptr %t28, 1
  store { i64, ptr } %t30, ptr %l23, !tbaa !27
  %t32 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !27
  %t34 = getelementptr { i64, [4 x i64] }, ptr %t33, i64 0
  store { i64, [4 x i64] } %t26, ptr %t34
  %t35 = load %"compiler/source:Span", ptr %l3
  %t36 = load ptr, ptr %l17, !tbaa !29
  %t37 = load i32, ptr %l18
  %t38 = load i32, ptr %l19, !tbaa !23
  %t39 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t41 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s0, ptr %t36, i32 %t37, i32 %t38, { i64, ptr } %t39, %"compiler/source:Span" %t35)
  store { i64, [4 x i64] } %t41, ptr %l25
  br label %bb3
bb3:
  %t42 = load { i64, [4 x i64] }, ptr %l25
  store { i64, [4 x i64] } %t42, ptr %l7
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t44 = load i32, ptr %l2, !tbaa !23
  %t45 = load %"compiler/source:Span", ptr %l3
  %t49 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2etemp(ptr %v0, ptr %t43, i32 %t44, %"compiler/source:Span" %t45)
  store i32 %t49, ptr %l29
  br label %bb4
bb4:
  %t50 = load i32, ptr %l29, !tbaa !23
  store i32 %t50, ptr %l8, !tbaa !23
  %t51 = load ptr, ptr %l5, !tbaa !29
  store ptr %t51, ptr %l30, !tbaa !29
  %t52 = load ptr, ptr %l5, !tbaa !29
  %t53 = load i32, ptr %l2, !tbaa !23
  %t56 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t52, i32 %t53)
  store i32 %t56, ptr %l33
  br label %bb5
bb5:
  %t57 = load ptr, ptr %l30, !tbaa !29
  %t58 = load i32, ptr %l33, !tbaa !23
  %t59 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t57, i32 %t58)
  store i32 %t59, ptr %l34
  br label %bb6
bb6:
  %t60 = load i32, ptr %l34, !tbaa !23
  store i32 %t60, ptr %l9, !tbaa !23
  %t61 = load ptr, ptr %l0, !tbaa !29
  store ptr %t61, ptr %l35, !tbaa !29
  %t62 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t62, ptr %l36
  %t63 = load i32, ptr %l8, !tbaa !23
  %t65 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t63)
  store %"compiler/mir:Place" %t65, ptr %l38
  br label %bb7
bb7:
  %t67 = load i32, ptr %l2, !tbaa !23
  %t68 = load { i64, [4 x i64] }, ptr %l7
  %t69 = load i32, ptr %l9, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t70
  %t71 = getelementptr { i64, [4 x i64] }, ptr %t70, i32 0, i32 0
  store i64 2, ptr %t71
  %t73 = insertvalue { i32, i64 } undef, i32 %t69, 0
  %t74 = insertvalue { i32, i64 } %t73, i64 0, 1
  %t75 = getelementptr { i64, [4 x i64] }, ptr %t70, i32 0, i32 1
  store { i32, i64 } %t74, ptr %t75
  %t76 = load { i64, [4 x i64] }, ptr %t70
  store { i64, [15 x i64] } zeroinitializer, ptr %t77
  %t78 = getelementptr { i64, [15 x i64] }, ptr %t77, i32 0, i32 0
  store i64 8, ptr %t78
  %t80 = insertvalue { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } } undef, { i64, [1 x i64] } %a4, 0
  %t82 = insertvalue { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } } %t80, i32 %t67, 1
  %t84 = insertvalue { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } } %t82, { i64, [4 x i64] } %t68, 2
  %t86 = insertvalue { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } } %t84, { i64, [4 x i64] } %t76, 3
  %t87 = getelementptr { i64, [15 x i64] }, ptr %t77, i32 0, i32 1
  store { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } } %t86, ptr %t87
  %t88 = load { i64, [15 x i64] }, ptr %t77
  store { i64, [21 x i64] } zeroinitializer, ptr %t89
  %t90 = getelementptr { i64, [21 x i64] }, ptr %t89, i32 0, i32 0
  store i64 0, ptr %t90
  %t91 = load %"compiler/source:Span", ptr %l36
  %t92 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t91, 0
  %t93 = load %"compiler/mir:Place", ptr %l38
  %t94 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t92, %"compiler/mir:Place" %t93, 1
  %t96 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t94, { i64, [15 x i64] } %t88, 2
  %t97 = getelementptr { i64, [21 x i64] }, ptr %t89, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t96, ptr %t97
  %t98 = load { i64, [21 x i64] }, ptr %t89
  %t100 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t98, ptr %t100
  %t101 = load ptr, ptr %l35, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s0, ptr %t101, ptr %t100)
  br label %bb8
bb8:
  %t103 = load ptr, ptr %l0, !tbaa !29
  store ptr %t103, ptr %l47, !tbaa !29
  %t104 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t104, ptr %l48
  %t105 = load i32, ptr %l8, !tbaa !23
  %t107 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t105)
  store %"compiler/mir:Place" %t107, ptr %l50
  br label %bb9
bb9:
  %t108 = load i32, ptr %l6, !tbaa !23
  %t110 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t108)
  store %"compiler/mir:Place" %t110, ptr %l52
  br label %bb10
bb10:
  %t111 = load { i64, [4 x i64] }, ptr %l7
  store { i64, [21 x i64] } zeroinitializer, ptr %t112
  %t113 = getelementptr { i64, [21 x i64] }, ptr %t112, i32 0, i32 0
  store i64 10, ptr %t113
  %t114 = load %"compiler/source:Span", ptr %l48
  %t115 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", %"compiler/mir:Place", { i64, [4 x i64] } } undef, %"compiler/source:Span" %t114, 0
  %t116 = load %"compiler/mir:Place", ptr %l50
  %t117 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", %"compiler/mir:Place", { i64, [4 x i64] } } %t115, %"compiler/mir:Place" %t116, 1
  %t118 = load %"compiler/mir:Place", ptr %l52
  %t119 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", %"compiler/mir:Place", { i64, [4 x i64] } } %t117, %"compiler/mir:Place" %t118, 2
  %t121 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", %"compiler/mir:Place", { i64, [4 x i64] } } %t119, { i64, [4 x i64] } %t111, 3
  %t122 = getelementptr { i64, [21 x i64] }, ptr %t112, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Place", %"compiler/mir:Place", { i64, [4 x i64] } } %t121, ptr %t122
  %t123 = load { i64, [21 x i64] }, ptr %t112
  %t125 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t123, ptr %t125
  %t126 = load ptr, ptr %l47, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s0, ptr %t126, ptr %t125)
  br label %bb11
bb11:
  %t128 = load i32, ptr %l8, !tbaa !23
  %t130 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t128)
  store %"compiler/mir:Place" %t130, ptr %l57
  br label %bb12
bb12:
  store { i64, [4 x i64] } zeroinitializer, ptr %t131
  %t132 = getelementptr { i64, [4 x i64] }, ptr %t131, i32 0, i32 0
  store i64 1, ptr %t132
  %t133 = load %"compiler/mir:Place", ptr %l57
  %t134 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t133, 0
  %t135 = getelementptr { i64, [4 x i64] }, ptr %t131, i32 0, i32 1
  store { %"compiler/mir:Place" } %t134, ptr %t135
  %t136 = load { i64, [4 x i64] }, ptr %t131
  call void @__olang_scope_close(ptr %s0)
  store { i64, [4 x i64] } %t136, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2earrayLit(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3, i1 %a4, { i64, [1 x i64] } %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l6 = alloca ptr
  %l7 = alloca i32
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, [4 x i64] }
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca i1
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l24 = alloca i32
  %l34 = alloca { i64, ptr }
  %l40 = alloca i64
  %l42 = alloca ptr
  %l43 = alloca i32
  %l44 = alloca i32
  %l48 = alloca %"compiler/mir:Range"
  %l51 = alloca { i64, [4 x i64] }
  %l52 = alloca ptr
  %l55 = alloca i32
  %l56 = alloca i1
  %l59 = alloca ptr
  %l60 = alloca i32
  %l64 = alloca { i64, [1 x i64] }
  %l69 = alloca { i64, [4 x i64] }
  %l72 = alloca i32
  %l76 = alloca i32
  %l77 = alloca ptr
  %l78 = alloca %"compiler/source:Span"
  %l80 = alloca %"compiler/mir:Place"
  %l82 = alloca { i64, [1 x i64] }
  %l87 = alloca { i64, [1 x i64] }
  %l88 = alloca i32
  %l92 = alloca { i64, [4 x i64] }
  %l98 = alloca ptr
  %l101 = alloca i32
  %l102 = alloca i1
  %l108 = alloca i64
  %l111 = alloca i64
  %l130 = alloca ptr
  %l132 = alloca { i64, [2 x i64] }
  %l134 = alloca { i64, ptr }
  %l138 = alloca { i64, ptr }
  %l141 = alloca { i64, ptr }
  %l142 = alloca %"compiler/mir:Place"
  %l154 = alloca %"compiler/mir:Place"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca { i64, [4 x i64] }
  %t22 = alloca { i64, [4 x i64] }, align 8
  %t40 = alloca { i64, [4 x i64] }, align 8
  %t62 = alloca { i64, [15 x i64] }, align 8
  %t104 = alloca { i64, [15 x i64] }, align 8
  %t162 = alloca { i64, [4 x i64] }, align 8
  %t169 = alloca { i64, [15 x i64] }, align 8
  %t181 = alloca { i64, [21 x i64] }, align 8
  %t259 = alloca { i64, [2 x i64] }, align 8
  %t267 = alloca { i64, [1 x i64] }, align 8
  %t271 = alloca { i64, [1 x i64] }, align 8
  %t291 = alloca { i64, [1 x i64] }, align 8
  %t320 = alloca { i64, [15 x i64] }, align 8
  %t326 = alloca { i64, [21 x i64] }, align 8
  %t347 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  store %"compiler/source:Span" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l6, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t7 = load i32, ptr %l2, !tbaa !23
  %t10 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2earrayOf(ptr %v0, ptr %t6, i32 %t7)
  store i32 %t10, ptr %l24
  br label %bb1
bb1:
  %t11 = load i32, ptr %l24, !tbaa !23
  store i32 %t11, ptr %l7, !tbaa !23
  %t12 = load i32, ptr %l7, !tbaa !23
  %t13 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t16 = icmp eq i32 %t12, %t13
  br i1 %t16, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t19 = load %"compiler/source:Span", ptr %l3
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2egap(ptr %v0, ptr %s1, ptr %t18, %"compiler/source:Span" %t19, { i64, ptr } { i64 43, ptr @.d15 })
  br label %bb4
bb3:
  br label %bb5
bb4:
  store { i64, [4 x i64] } zeroinitializer, ptr %t22
  %t23 = getelementptr { i64, [4 x i64] }, ptr %t22, i32 0, i32 0
  store i64 0, ptr %t23
  %t24 = load { i64, [4 x i64] }, ptr %t22
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  store { i64, [4 x i64] } %t24, ptr %rv
  br label %ret
bb5:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t27 = load ptr, ptr %l1, !tbaa !29
  %t29 = getelementptr %"compiler/typed:Make", ptr %t27, i32 0, i32 2
  %t30 = load { i64, ptr }, ptr %t29, !tbaa !27
  %t33 = call { i64, ptr } @compiler_2flower_2ecompiler_2flower_3alowering_2evals(ptr %v0, ptr %v1, ptr %s0, ptr %t26, { i64, ptr } %t30)
  store { i64, ptr } %t33, ptr %l34
  br label %bb6
bb6:
  %t34 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t34, ptr %l8, !tbaa !27
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/lower:lowering", ptr %t35, i32 0, i32 7
  %t38 = load i1, ptr %t37, !tbaa !21
  br i1 %t38, label %bb7, label %bb8
bb7:
  store { i64, [4 x i64] } zeroinitializer, ptr %t40
  %t41 = getelementptr { i64, [4 x i64] }, ptr %t40, i32 0, i32 0
  store i64 0, ptr %t41
  %t42 = load { i64, [4 x i64] }, ptr %t40
  call void @__olang_scope_close(ptr %s0)
  store { i64, [4 x i64] } %t42, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t45 = load i32, ptr %l7, !tbaa !23
  %t48 = call i64 @compiler_2flower_2ecompiler_2flower_3alowering_2efixedLen(ptr %v0, ptr %t44, i32 %t45)
  store i64 %t48, ptr %l40
  br label %bb10
bb10:
  %t49 = load i64, ptr %l40, !tbaa !24
  %t50 = icmp sge i64 %t49, 0
  br i1 %t50, label %bb11, label %bb12
bb11:
  %t52 = load ptr, ptr %l0, !tbaa !29
  store ptr %t52, ptr %l42, !tbaa !29
  %t53 = load i32, ptr %l7, !tbaa !23
  store i32 %t53, ptr %l43, !tbaa !23
  %t54 = load i32, ptr %l7, !tbaa !23
  store i32 %t54, ptr %l44, !tbaa !23
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/lower:lowering", ptr %t55, i32 0, i32 3
  %t58 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t61 = call %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eArgs(ptr %v0, ptr %s0, ptr %t57, { i64, ptr } %t58)
  store %"compiler/mir:Range" %t61, ptr %l48
  br label %bb13
bb12:
  br label %bb22
bb13:
  store { i64, [15 x i64] } zeroinitializer, ptr %t62
  %t63 = getelementptr { i64, [15 x i64] }, ptr %t62, i32 0, i32 0
  store i64 6, ptr %t63
  %t64 = load i32, ptr %l44, !tbaa !23
  %t65 = insertvalue { i32, i64, %"compiler/mir:Range" } undef, i32 %t64, 0
  %t66 = insertvalue { i32, i64, %"compiler/mir:Range" } %t65, i64 0, 1
  %t67 = load %"compiler/mir:Range", ptr %l48
  %t68 = insertvalue { i32, i64, %"compiler/mir:Range" } %t66, %"compiler/mir:Range" %t67, 2
  %t69 = getelementptr { i64, [15 x i64] }, ptr %t62, i32 0, i32 1
  store { i32, i64, %"compiler/mir:Range" } %t68, ptr %t69
  %t70 = load { i64, [15 x i64] }, ptr %t62
  %t71 = load %"compiler/source:Span", ptr %l3
  %t72 = load ptr, ptr %l42, !tbaa !29
  %t73 = load i32, ptr %l43, !tbaa !23
  %t76 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %t72, i32 %t73, { i64, [15 x i64] } %t70, %"compiler/source:Span" %t71)
  store { i64, [4 x i64] } %t76, ptr %l51
  br label %bb14
bb14:
  %t77 = load { i64, [4 x i64] }, ptr %l51
  store { i64, [4 x i64] } %t77, ptr %l9
  %t78 = load ptr, ptr %l6, !tbaa !29
  store ptr %t78, ptr %l52, !tbaa !29
  %t79 = load ptr, ptr %l6, !tbaa !29
  %t80 = load i32, ptr %l2, !tbaa !23
  %t83 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t79, i32 %t80)
  store i32 %t83, ptr %l55
  br label %bb15
bb15:
  %t84 = load ptr, ptr %l52, !tbaa !29
  %t85 = load i32, ptr %l55, !tbaa !23
  %t86 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t84, i32 %t85)
  store i1 %t86, ptr %l56
  br label %bb16
bb16:
  %t87 = load i1, ptr %l56, !tbaa !21
  %t88 = xor i1 %t87, true
  br i1 %t88, label %bb17, label %bb18
bb17:
  %t90 = load { i64, [4 x i64] }, ptr %l9
  call void @__olang_scope_close(ptr %s0)
  store { i64, [4 x i64] } %t90, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  %t92 = load ptr, ptr %l0, !tbaa !29
  store ptr %t92, ptr %l59, !tbaa !29
  %t93 = load i32, ptr %l2, !tbaa !23
  store i32 %t93, ptr %l60, !tbaa !23
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t95 = load ptr, ptr %l1, !tbaa !29
  %t97 = getelementptr %"compiler/typed:Make", ptr %t95, i32 0, i32 4
  %t98 = load i32, ptr %t97, !tbaa !23
  %t101 = call { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ebuilt(ptr %v0, ptr %t94, i32 %t98)
  store { i64, [1 x i64] } %t101, ptr %l64
  br label %bb20
bb20:
  %t102 = load { i64, [4 x i64] }, ptr %l9
  %t103 = load i32, ptr %l2, !tbaa !23
  store { i64, [15 x i64] } zeroinitializer, ptr %t104
  %t105 = getelementptr { i64, [15 x i64] }, ptr %t104, i32 0, i32 0
  store i64 7, ptr %t105
  %t106 = load { i64, [1 x i64] }, ptr %l64
  %t107 = insertvalue { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 } undef, { i64, [1 x i64] } %t106, 0
  %t109 = insertvalue { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 } %t107, { i64, [4 x i64] } %t102, 1
  %t111 = insertvalue { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 } %t109, i32 %t103, 2
  %t112 = getelementptr { i64, [15 x i64] }, ptr %t104, i32 0, i32 1
  store { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 } %t111, ptr %t112
  %t113 = load { i64, [15 x i64] }, ptr %t104
  %t114 = load %"compiler/source:Span", ptr %l3
  %t115 = load ptr, ptr %l59, !tbaa !29
  %t116 = load i32, ptr %l60, !tbaa !23
  %t119 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %t115, i32 %t116, { i64, [15 x i64] } %t113, %"compiler/source:Span" %t114)
  store { i64, [4 x i64] } %t119, ptr %l69
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s0)
  %t120 = load { i64, [4 x i64] }, ptr %l69
  store { i64, [4 x i64] } %t120, ptr %rv
  br label %ret
bb22:
  %t121 = load ptr, ptr %l6, !tbaa !29
  %t122 = load i32, ptr %l7, !tbaa !23
  %t125 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t121, i32 %t122)
  store i32 %t125, ptr %l72
  br label %bb23
bb23:
  %t126 = load i32, ptr %l72, !tbaa !23
  store i32 %t126, ptr %l10, !tbaa !23
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t128 = load i32, ptr %l2, !tbaa !23
  %t129 = load %"compiler/source:Span", ptr %l3
  %t133 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2etemp(ptr %v0, ptr %t127, i32 %t128, %"compiler/source:Span" %t129)
  store i32 %t133, ptr %l76
  br label %bb24
bb24:
  %t134 = load i32, ptr %l76, !tbaa !23
  store i32 %t134, ptr %l11, !tbaa !23
  %t135 = load ptr, ptr %l0, !tbaa !29
  store ptr %t135, ptr %l77, !tbaa !29
  %t136 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t136, ptr %l78
  %t137 = load i32, ptr %l11, !tbaa !23
  %t139 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t137)
  store %"compiler/mir:Place" %t139, ptr %l80
  br label %bb25
bb25:
  br i1 %a4, label %bb26, label %bb27
bb26:
  store { i64, [1 x i64] } %a5, ptr %l82
  br label %bb29
bb27:
  %t144 = load ptr, ptr %l0, !tbaa !29
  %t145 = load ptr, ptr %l1, !tbaa !29
  %t147 = getelementptr %"compiler/typed:Make", ptr %t145, i32 0, i32 4
  %t148 = load i32, ptr %t147, !tbaa !23
  %t151 = call { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2emadeAt(ptr %v0, ptr %t144, i32 %t148)
  store { i64, [1 x i64] } %t151, ptr %l87
  br label %bb28
bb28:
  %t152 = load { i64, [1 x i64] }, ptr %l87
  store { i64, [1 x i64] } %t152, ptr %l82
  br label %bb29
bb29:
  %t153 = load i32, ptr %l2, !tbaa !23
  store i32 %t153, ptr %l88, !tbaa !23
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t155 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t157 = extractvalue { i64, ptr } %t155, 0
  %t160 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2econstI64(ptr %v0, ptr %t154, i64 %t157)
  store { i64, [4 x i64] } %t160, ptr %l92
  br label %bb30
bb30:
  %t161 = load i32, ptr %l10, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t162
  %t163 = getelementptr { i64, [4 x i64] }, ptr %t162, i32 0, i32 0
  store i64 2, ptr %t163
  %t165 = insertvalue { i32, i64 } undef, i32 %t161, 0
  %t166 = insertvalue { i32, i64 } %t165, i64 0, 1
  %t167 = getelementptr { i64, [4 x i64] }, ptr %t162, i32 0, i32 1
  store { i32, i64 } %t166, ptr %t167
  %t168 = load { i64, [4 x i64] }, ptr %t162
  store { i64, [15 x i64] } zeroinitializer, ptr %t169
  %t170 = getelementptr { i64, [15 x i64] }, ptr %t169, i32 0, i32 0
  store i64 8, ptr %t170
  %t171 = load { i64, [1 x i64] }, ptr %l82
  %t172 = insertvalue { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } } undef, { i64, [1 x i64] } %t171, 0
  %t173 = load i32, ptr %l88, !tbaa !23
  %t174 = insertvalue { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } } %t172, i32 %t173, 1
  %t175 = load { i64, [4 x i64] }, ptr %l92
  %t176 = insertvalue { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } } %t174, { i64, [4 x i64] } %t175, 2
  %t178 = insertvalue { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } } %t176, { i64, [4 x i64] } %t168, 3
  %t179 = getelementptr { i64, [15 x i64] }, ptr %t169, i32 0, i32 1
  store { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } } %t178, ptr %t179
  %t180 = load { i64, [15 x i64] }, ptr %t169
  store { i64, [21 x i64] } zeroinitializer, ptr %t181
  %t182 = getelementptr { i64, [21 x i64] }, ptr %t181, i32 0, i32 0
  store i64 0, ptr %t182
  %t183 = load %"compiler/source:Span", ptr %l78
  %t184 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t183, 0
  %t185 = load %"compiler/mir:Place", ptr %l80
  %t186 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t184, %"compiler/mir:Place" %t185, 1
  %t188 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t186, { i64, [15 x i64] } %t180, 2
  %t189 = getelementptr { i64, [21 x i64] }, ptr %t181, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t188, ptr %t189
  %t190 = load { i64, [21 x i64] }, ptr %t181
  %t192 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t190, ptr %t192
  %t193 = load ptr, ptr %l77, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s0, ptr %t193, ptr %t192)
  br label %bb31
bb31:
  %t195 = load ptr, ptr %l6, !tbaa !29
  store ptr %t195, ptr %l98, !tbaa !29
  %t196 = load ptr, ptr %l6, !tbaa !29
  %t197 = load i32, ptr %l2, !tbaa !23
  %t200 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t196, i32 %t197)
  store i32 %t200, ptr %l101
  br label %bb32
bb32:
  %t201 = load ptr, ptr %l98, !tbaa !29
  %t202 = load i32, ptr %l101, !tbaa !23
  %t203 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t201, i32 %t202)
  store i1 %t203, ptr %l102
  br label %bb33
bb33:
  %t204 = load i1, ptr %l102, !tbaa !21
  store i1 %t204, ptr %l12, !tbaa !21
  store i64 0, ptr %l13, !tbaa !24
  %t205 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t207 = extractvalue { i64, ptr } %t205, 0
  store i64 %t207, ptr %l14, !tbaa !24
  store i64 1, ptr %l15, !tbaa !24
  %t209 = load i64, ptr %l14, !tbaa !24
  %t210 = load i64, ptr %l13, !tbaa !24
  %t213 = icmp sgt i64 %t209, %t210
  br i1 %t213, label %bb34, label %bb35
bb34:
  %t215 = load i64, ptr %l15, !tbaa !24
  %t217 = icmp sgt i64 %t215, 0
  br i1 %t217, label %bb36, label %bb37
bb35:
  store i64 0, ptr %l108, !tbaa !24
  br label %bb39
bb36:
  %t219 = load i64, ptr %l14, !tbaa !24
  %t220 = load i64, ptr %l13, !tbaa !24
  %t223 = sub i64 %t219, %t220
  %t224 = load i64, ptr %l15, !tbaa !24
  %t227 = add i64 %t223, %t224
  %t229 = sub i64 %t227, 1
  %t230 = load i64, ptr %l15, !tbaa !24
  %t233 = sdiv i64 %t229, %t230
  store i64 %t233, ptr %l111, !tbaa !24
  br label %bb38
bb37:
  store i64 0, ptr %l111, !tbaa !24
  br label %bb38
bb38:
  %t235 = load i64, ptr %l111, !tbaa !24
  store i64 %t235, ptr %l108, !tbaa !24
  br label %bb39
bb39:
  %t236 = load i64, ptr %l108, !tbaa !24
  store i64 %t236, ptr %l16, !tbaa !24
  store i64 0, ptr %l17, !tbaa !24
  br label %bb40
bb40:
  store %olang.scope zeroinitializer, ptr %s6
  %t237 = load i64, ptr %l17, !tbaa !24
  %t238 = load i64, ptr %l16, !tbaa !24
  %t241 = icmp slt i64 %t237, %t238
  %t243 = xor i1 %t241, true
  br i1 %t243, label %bb41, label %bb42
bb41:
  call void @__olang_scope_close(ptr %s6)
  br label %bb50
bb42:
  br label %bb43
bb43:
  %t245 = load i64, ptr %l13, !tbaa !24
  %t246 = load i64, ptr %l17, !tbaa !24
  %t247 = load i64, ptr %l15, !tbaa !24
  %t250 = mul i64 %t246, %t247
  %t253 = add i64 %t245, %t250
  store i64 %t253, ptr %l18, !tbaa !24
  %t255 = load ptr, ptr %l0, !tbaa !29
  %t257 = getelementptr %"compiler/lower:lowering", ptr %t255, i32 0, i32 3
  store ptr %t257, ptr %l130, !tbaa !29
  %t258 = load i32, ptr %l11, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t259
  %t260 = getelementptr { i64, [2 x i64] }, ptr %t259, i32 0, i32 0
  store i64 1, ptr %t260
  %t262 = insertvalue { i32 } undef, i32 %t258, 0
  %t263 = getelementptr { i64, [2 x i64] }, ptr %t259, i32 0, i32 1
  store { i32 } %t262, ptr %t263
  %t264 = load { i64, [2 x i64] }, ptr %t259
  store { i64, [2 x i64] } %t264, ptr %l132
  %t265 = load i1, ptr %l12, !tbaa !21
  br i1 %t265, label %bb44, label %bb45
bb44:
  store { i64, [1 x i64] } zeroinitializer, ptr %t267
  %t268 = getelementptr { i64, [1 x i64] }, ptr %t267, i32 0, i32 0
  store i64 3, ptr %t268
  %t269 = load { i64, [1 x i64] }, ptr %t267
  %t270 = load i64, ptr %l18, !tbaa !24
  store { i64, [1 x i64] } zeroinitializer, ptr %t271
  %t272 = getelementptr { i64, [1 x i64] }, ptr %t271, i32 0, i32 0
  store i64 2, ptr %t272
  %t274 = insertvalue { i64 } undef, i64 %t270, 0
  %t275 = getelementptr { i64, [1 x i64] }, ptr %t271, i32 0, i32 1
  store { i64 } %t274, ptr %t275
  %t276 = load { i64, [1 x i64] }, ptr %t271
  %t277 = mul i64 2, 16
  %t278 = call ptr @__olang_scope_alloc_zeroed(ptr %s6, i64 %t277)
  %t279 = insertvalue { i64, ptr } undef, i64 2, 0
  %t280 = insertvalue { i64, ptr } %t279, ptr %t278, 1
  store { i64, ptr } %t280, ptr %l138, !tbaa !27
  %t282 = getelementptr { i64, ptr }, ptr %l138, i32 0, i32 1
  %t283 = load ptr, ptr %t282, !tbaa !27
  %t284 = getelementptr { i64, [1 x i64] }, ptr %t283, i64 0
  store { i64, [1 x i64] } %t269, ptr %t284
  %t286 = getelementptr { i64, ptr }, ptr %l138, i32 0, i32 1
  %t287 = load ptr, ptr %t286, !tbaa !27
  %t288 = getelementptr { i64, [1 x i64] }, ptr %t287, i64 1
  store { i64, [1 x i64] } %t276, ptr %t288
  %t289 = load { i64, ptr }, ptr %l138, !tbaa !27
  store { i64, ptr } %t289, ptr %l134, !tbaa !27
  br label %bb46
bb45:
  %t290 = load i64, ptr %l18, !tbaa !24
  store { i64, [1 x i64] } zeroinitializer, ptr %t291
  %t292 = getelementptr { i64, [1 x i64] }, ptr %t291, i32 0, i32 0
  store i64 2, ptr %t292
  %t294 = insertvalue { i64 } undef, i64 %t290, 0
  %t295 = getelementptr { i64, [1 x i64] }, ptr %t291, i32 0, i32 1
  store { i64 } %t294, ptr %t295
  %t296 = load { i64, [1 x i64] }, ptr %t291
  %t297 = mul i64 1, 16
  %t298 = call ptr @__olang_scope_alloc_zeroed(ptr %s6, i64 %t297)
  %t299 = insertvalue { i64, ptr } undef, i64 1, 0
  %t300 = insertvalue { i64, ptr } %t299, ptr %t298, 1
  store { i64, ptr } %t300, ptr %l141, !tbaa !27
  %t302 = getelementptr { i64, ptr }, ptr %l141, i32 0, i32 1
  %t303 = load ptr, ptr %t302, !tbaa !27
  %t304 = getelementptr { i64, [1 x i64] }, ptr %t303, i64 0
  store { i64, [1 x i64] } %t296, ptr %t304
  %t305 = load { i64, ptr }, ptr %l141, !tbaa !27
  store { i64, ptr } %t305, ptr %l134, !tbaa !27
  br label %bb46
bb46:
  %t306 = load ptr, ptr %l130, !tbaa !29
  %t307 = load { i64, [2 x i64] }, ptr %l132
  %t308 = load { i64, ptr }, ptr %l134, !tbaa !27
  %t309 = call %"compiler/mir:Place" @compiler_2fmir_2ecompiler_2fmir_3aFn_2ePlace(ptr %v0, ptr %s6, ptr %t306, { i64, [2 x i64] } %t307, { i64, ptr } %t308)
  store %"compiler/mir:Place" %t309, ptr %l142
  br label %bb47
bb47:
  %t310 = load %"compiler/mir:Place", ptr %l142
  %t311 = load ptr, ptr %l0, !tbaa !29
  %t312 = load %"compiler/source:Span", ptr %l3
  %t314 = load i64, ptr %l18, !tbaa !24
  %t316 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t317 = load ptr, ptr %t316, !tbaa !27
  %t318 = getelementptr { i64, [4 x i64] }, ptr %t317, i64 %t314
  %t319 = load { i64, [4 x i64] }, ptr %t318
  store { i64, [15 x i64] } zeroinitializer, ptr %t320
  %t321 = getelementptr { i64, [15 x i64] }, ptr %t320, i32 0, i32 0
  store i64 0, ptr %t321
  %t323 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t319, 0
  %t324 = getelementptr { i64, [15 x i64] }, ptr %t320, i32 0, i32 1
  store { { i64, [4 x i64] } } %t323, ptr %t324
  %t325 = load { i64, [15 x i64] }, ptr %t320
  store { i64, [21 x i64] } zeroinitializer, ptr %t326
  %t327 = getelementptr { i64, [21 x i64] }, ptr %t326, i32 0, i32 0
  store i64 0, ptr %t327
  %t329 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t312, 0
  %t331 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t329, %"compiler/mir:Place" %t310, 1
  %t333 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t331, { i64, [15 x i64] } %t325, 2
  %t334 = getelementptr { i64, [21 x i64] }, ptr %t326, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t333, ptr %t334
  %t335 = load { i64, [21 x i64] }, ptr %t326
  %t337 = call ptr @__olang_scope_alloc_a(ptr %s6, i64 176, i64 8)
  store { i64, [21 x i64] } %t335, ptr %t337
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s6, ptr %t311, ptr %t337)
  br label %bb48
bb48:
  call void @__olang_scope_close(ptr %s6)
  br label %bb49
bb49:
  %t340 = load i64, ptr %l17, !tbaa !24
  %t342 = add i64 %t340, 1
  store i64 %t342, ptr %l17, !tbaa !24
  br label %bb40
bb50:
  %t344 = load i32, ptr %l11, !tbaa !23
  %t346 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t344)
  store %"compiler/mir:Place" %t346, ptr %l154
  br label %bb51
bb51:
  store { i64, [4 x i64] } zeroinitializer, ptr %t347
  %t348 = getelementptr { i64, [4 x i64] }, ptr %t347, i32 0, i32 0
  store i64 1, ptr %t348
  %t349 = load %"compiler/mir:Place", ptr %l154
  %t350 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t349, 0
  %t351 = getelementptr { i64, [4 x i64] }, ptr %t347, i32 0, i32 1
  store { %"compiler/mir:Place" } %t350, ptr %t351
  %t352 = load { i64, [4 x i64] }, ptr %t347
  call void @__olang_scope_close(ptr %s0)
  store { i64, [4 x i64] } %t352, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local i32 @compiler_2flower_2ecompiler_2flower_3alowering_2earrayOf(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca i32
  %l8 = alloca i32
  %l11 = alloca i1
  %l12 = alloca ptr
  %l15 = alloca i32
  %l16 = alloca i32
  %l19 = alloca i32
  %l22 = alloca i32
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/lower:lowering", ptr %a0, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t6, i32 %a1)
  store i32 %t10, ptr %l8
  br label %bb1
bb1:
  %t11 = load i32, ptr %l8, !tbaa !23
  store i32 %t11, ptr %l3, !tbaa !23
  %t12 = load ptr, ptr %l2, !tbaa !29
  %t13 = load i32, ptr %l3, !tbaa !23
  %t16 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t12, i32 %t13)
  store i1 %t16, ptr %l11
  br label %bb2
bb2:
  %t17 = load i1, ptr %l11, !tbaa !21
  br i1 %t17, label %bb3, label %bb4
bb3:
  %t18 = load ptr, ptr %l2, !tbaa !29
  store ptr %t18, ptr %l12, !tbaa !29
  %t19 = load ptr, ptr %l2, !tbaa !29
  %t20 = load i32, ptr %l3, !tbaa !23
  %t23 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t19, i32 %t20)
  store i32 %t23, ptr %l15
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t24 = load ptr, ptr %l12, !tbaa !29
  %t25 = load i32, ptr %l15, !tbaa !23
  %t26 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t24, i32 %t25)
  store i32 %t26, ptr %l16
  br label %bb6
bb6:
  %t27 = load i32, ptr %l16, !tbaa !23
  store i32 %t27, ptr %l3, !tbaa !23
  br label %bb7
bb7:
  %t28 = load ptr, ptr %l2, !tbaa !29
  %t29 = load i32, ptr %l3, !tbaa !23
  %t32 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t28, i32 %t29)
  store i32 %t32, ptr %l19
  br label %bb8
bb8:
  %t33 = load i32, ptr %l19
  %t35 = trunc i64 19 to i32
  %t36 = icmp eq i32 %t33, %t35
  br i1 %t36, label %bb9, label %bb10
bb9:
  %t38 = load i32, ptr %l3, !tbaa !23
  store i32 %t38, ptr %l22, !tbaa !23
  br label %bb11
bb10:
  %t40 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t40, ptr %l22, !tbaa !23
  br label %bb11
bb11:
  %t42 = load i32, ptr %l22, !tbaa !23
  store i32 %t42, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2earrayStore(ptr %v0, ptr %a0, %"compiler/mir:Place" %a1, { i64, [4 x i64] } %a2, i32 %a3, i1 %a4, %"compiler/source:Span" %a5, { i64, [1 x i64] } %a6) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/mir:Place"
  %l3 = alloca i32
  %l5 = alloca %"compiler/source:Span"
  %l7 = alloca i32
  %l8 = alloca { i64, [4 x i64] }
  %l9 = alloca { i64, [4 x i64] }
  %l10 = alloca { i64, [4 x i64] }
  %l11 = alloca i32
  %l12 = alloca i32
  %l13 = alloca i32
  %l19 = alloca i32
  %l25 = alloca { i64, ptr }
  %l27 = alloca { i64, [4 x i64] }
  %l28 = alloca ptr
  %l29 = alloca i32
  %l30 = alloca i32
  %l32 = alloca %"compiler/mir:Place"
  %l34 = alloca { i64, ptr }
  %l36 = alloca { i64, [4 x i64] }
  %l42 = alloca { i64, ptr }
  %l44 = alloca { i64, [4 x i64] }
  %l47 = alloca i32
  %l50 = alloca i32
  %l53 = alloca i32
  %l61 = alloca ptr
  %l62 = alloca %"compiler/source:Span"
  %l63 = alloca %"compiler/mir:Place"
  %l65 = alloca %"compiler/mir:Place"
  %l74 = alloca { i64, [4 x i64] }
  %l75 = alloca ptr
  %l77 = alloca %"compiler/mir:Place"
  %l82 = alloca { i64, [4 x i64] }
  %l84 = alloca %"compiler/mir:Place"
  %s0 = alloca %olang.scope
  %t14 = alloca { i64, [4 x i64] }, align 8
  %t41 = alloca { i64, [4 x i64] }, align 8
  %t109 = alloca { i64, [7 x i64] }, align 8
  %t132 = alloca { i64, [21 x i64] }, align 8
  %t165 = alloca { i64, [4 x i64] }, align 8
  %t181 = alloca { i64, [4 x i64] }, align 8
  %t193 = alloca { i64, [15 x i64] }, align 8
  %t199 = alloca { i64, [21 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/mir:Place" %a1, ptr %l1
  store i32 %a3, ptr %l3
  store %"compiler/source:Span" %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = load i32, ptr %l3, !tbaa !23
  %t4 = load %"compiler/source:Span", ptr %l5
  %t9 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2elocal(ptr %v0, ptr %t1, { i64, [4 x i64] } %a2, i32 %t3, %"compiler/source:Span" %t4)
  store i32 %t9, ptr %l19
  br label %bb1
bb1:
  %t10 = load i32, ptr %l19, !tbaa !23
  store i32 %t10, ptr %l7, !tbaa !23
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  %t13 = load %"compiler/mir:Place", ptr %l1
  store { i64, [4 x i64] } zeroinitializer, ptr %t14
  %t15 = getelementptr { i64, [4 x i64] }, ptr %t14, i32 0, i32 0
  store i64 1, ptr %t15
  %t17 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t13, 0
  %t18 = getelementptr { i64, [4 x i64] }, ptr %t14, i32 0, i32 1
  store { %"compiler/mir:Place" } %t17, ptr %t18
  %t19 = load { i64, [4 x i64] }, ptr %t14
  %t20 = mul i64 1, 40
  %t21 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t20)
  %t22 = insertvalue { i64, ptr } undef, i64 1, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t21, 1
  store { i64, ptr } %t23, ptr %l25, !tbaa !27
  %t25 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr { i64, [4 x i64] }, ptr %t26, i64 0
  store { i64, [4 x i64] } %t19, ptr %t27
  %t28 = load %"compiler/source:Span", ptr %l5
  %t32 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t34 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s0, ptr %t11, i32 22, i32 %t12, { i64, ptr } %t32, %"compiler/source:Span" %t28)
  store { i64, [4 x i64] } %t34, ptr %l27
  br label %bb2
bb2:
  %t35 = load { i64, [4 x i64] }, ptr %l27
  store { i64, [4 x i64] } %t35, ptr %l8
  %t36 = load ptr, ptr %l0, !tbaa !29
  store ptr %t36, ptr %l28, !tbaa !29
  store i32 22, ptr %l29
  %t37 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  store i32 %t37, ptr %l30, !tbaa !23
  %t38 = load i32, ptr %l7, !tbaa !23
  %t40 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t38)
  store %"compiler/mir:Place" %t40, ptr %l32
  br label %bb3
bb3:
  store { i64, [4 x i64] } zeroinitializer, ptr %t41
  %t42 = getelementptr { i64, [4 x i64] }, ptr %t41, i32 0, i32 0
  store i64 1, ptr %t42
  %t43 = load %"compiler/mir:Place", ptr %l32
  %t44 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t43, 0
  %t45 = getelementptr { i64, [4 x i64] }, ptr %t41, i32 0, i32 1
  store { %"compiler/mir:Place" } %t44, ptr %t45
  %t46 = load { i64, [4 x i64] }, ptr %t41
  %t47 = mul i64 1, 40
  %t48 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t47)
  %t49 = insertvalue { i64, ptr } undef, i64 1, 0
  %t50 = insertvalue { i64, ptr } %t49, ptr %t48, 1
  store { i64, ptr } %t50, ptr %l34, !tbaa !27
  %t52 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !27
  %t54 = getelementptr { i64, [4 x i64] }, ptr %t53, i64 0
  store { i64, [4 x i64] } %t46, ptr %t54
  %t55 = load %"compiler/source:Span", ptr %l5
  %t56 = load ptr, ptr %l28, !tbaa !29
  %t57 = load i32, ptr %l29
  %t58 = load i32, ptr %l30, !tbaa !23
  %t59 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t61 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s0, ptr %t56, i32 %t57, i32 %t58, { i64, ptr } %t59, %"compiler/source:Span" %t55)
  store { i64, [4 x i64] } %t61, ptr %l36
  br label %bb4
bb4:
  %t62 = load { i64, [4 x i64] }, ptr %l36
  store { i64, [4 x i64] } %t62, ptr %l9
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t64 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t65 = load { i64, [4 x i64] }, ptr %l8
  %t66 = load { i64, [4 x i64] }, ptr %l9
  %t67 = mul i64 2, 40
  %t68 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t67)
  %t69 = insertvalue { i64, ptr } undef, i64 2, 0
  %t70 = insertvalue { i64, ptr } %t69, ptr %t68, 1
  store { i64, ptr } %t70, ptr %l42, !tbaa !27
  %t72 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !27
  %t74 = getelementptr { i64, [4 x i64] }, ptr %t73, i64 0
  store { i64, [4 x i64] } %t65, ptr %t74
  %t76 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t77 = load ptr, ptr %t76, !tbaa !27
  %t78 = getelementptr { i64, [4 x i64] }, ptr %t77, i64 1
  store { i64, [4 x i64] } %t66, ptr %t78
  %t79 = load %"compiler/source:Span", ptr %l5
  %t83 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t85 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s0, ptr %t63, i32 13, i32 %t64, { i64, ptr } %t83, %"compiler/source:Span" %t79)
  store { i64, [4 x i64] } %t85, ptr %l44
  br label %bb5
bb5:
  %t86 = load { i64, [4 x i64] }, ptr %l44
  store { i64, [4 x i64] } %t86, ptr %l10
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr %"compiler/lower:lowering", ptr %t87, i32 0, i32 3
  %t91 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t89)
  store i32 %t91, ptr %l47
  br label %bb6
bb6:
  %t92 = load i32, ptr %l47, !tbaa !23
  store i32 %t92, ptr %l11, !tbaa !23
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/lower:lowering", ptr %t93, i32 0, i32 3
  %t97 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t95)
  store i32 %t97, ptr %l50
  br label %bb7
bb7:
  %t98 = load i32, ptr %l50, !tbaa !23
  store i32 %t98, ptr %l12, !tbaa !23
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = getelementptr %"compiler/lower:lowering", ptr %t99, i32 0, i32 3
  %t103 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t101)
  store i32 %t103, ptr %l53
  br label %bb8
bb8:
  %t104 = load i32, ptr %l53, !tbaa !23
  store i32 %t104, ptr %l13, !tbaa !23
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t106 = load { i64, [4 x i64] }, ptr %l10
  %t107 = load i32, ptr %l11, !tbaa !23
  %t108 = load i32, ptr %l12, !tbaa !23
  store { i64, [7 x i64] } zeroinitializer, ptr %t109
  %t110 = getelementptr { i64, [7 x i64] }, ptr %t109, i32 0, i32 0
  store i64 2, ptr %t110
  %t112 = insertvalue { { i64, [4 x i64] }, i32, i32 } undef, { i64, [4 x i64] } %t106, 0
  %t114 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t112, i32 %t107, 1
  %t116 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t114, i32 %t108, 2
  %t117 = getelementptr { i64, [7 x i64] }, ptr %t109, i32 0, i32 1
  store { { i64, [4 x i64] }, i32, i32 } %t116, ptr %t117
  %t118 = load { i64, [7 x i64] }, ptr %t109
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t105, { i64, [7 x i64] } %t118)
  br label %bb9
bb9:
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t122 = load i32, ptr %l11, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t121, i32 %t122)
  br label %bb10
bb10:
  %t125 = load ptr, ptr %l0, !tbaa !29
  store ptr %t125, ptr %l61, !tbaa !29
  %t126 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t126, ptr %l62
  %t127 = load %"compiler/mir:Place", ptr %l1
  store %"compiler/mir:Place" %t127, ptr %l63
  %t128 = load i32, ptr %l7, !tbaa !23
  %t130 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t128)
  store %"compiler/mir:Place" %t130, ptr %l65
  br label %bb11
bb11:
  %t131 = load { i64, [4 x i64] }, ptr %l9
  store { i64, [21 x i64] } zeroinitializer, ptr %t132
  %t133 = getelementptr { i64, [21 x i64] }, ptr %t132, i32 0, i32 0
  store i64 10, ptr %t133
  %t134 = load %"compiler/source:Span", ptr %l62
  %t135 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", %"compiler/mir:Place", { i64, [4 x i64] } } undef, %"compiler/source:Span" %t134, 0
  %t136 = load %"compiler/mir:Place", ptr %l63
  %t137 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", %"compiler/mir:Place", { i64, [4 x i64] } } %t135, %"compiler/mir:Place" %t136, 1
  %t138 = load %"compiler/mir:Place", ptr %l65
  %t139 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", %"compiler/mir:Place", { i64, [4 x i64] } } %t137, %"compiler/mir:Place" %t138, 2
  %t141 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", %"compiler/mir:Place", { i64, [4 x i64] } } %t139, { i64, [4 x i64] } %t131, 3
  %t142 = getelementptr { i64, [21 x i64] }, ptr %t132, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Place", %"compiler/mir:Place", { i64, [4 x i64] } } %t141, ptr %t142
  %t143 = load { i64, [21 x i64] }, ptr %t132
  %t145 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t143, ptr %t145
  %t146 = load ptr, ptr %l61, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s0, ptr %t146, ptr %t145)
  br label %bb12
bb12:
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t149 = load i32, ptr %l13, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2egoto(ptr %v0, ptr %t148, i32 %t149)
  br label %bb13
bb13:
  %t152 = load ptr, ptr %l0, !tbaa !29
  %t153 = load i32, ptr %l12, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t152, i32 %t153)
  br label %bb14
bb14:
  br i1 %a4, label %bb15, label %bb16
bb15:
  %t158 = load ptr, ptr %l0, !tbaa !29
  store ptr %t158, ptr %l75, !tbaa !29
  %t159 = load i32, ptr %l7, !tbaa !23
  %t161 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t159)
  store %"compiler/mir:Place" %t161, ptr %l77
  br label %bb17
bb16:
  %t162 = load i32, ptr %l7, !tbaa !23
  %t164 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t162)
  store %"compiler/mir:Place" %t164, ptr %l84
  br label %bb19
bb17:
  store { i64, [4 x i64] } zeroinitializer, ptr %t165
  %t166 = getelementptr { i64, [4 x i64] }, ptr %t165, i32 0, i32 0
  store i64 1, ptr %t166
  %t167 = load %"compiler/mir:Place", ptr %l77
  %t168 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t167, 0
  %t169 = getelementptr { i64, [4 x i64] }, ptr %t165, i32 0, i32 1
  store { %"compiler/mir:Place" } %t168, ptr %t169
  %t170 = load { i64, [4 x i64] }, ptr %t165
  %t171 = load i32, ptr %l3, !tbaa !23
  %t172 = load %"compiler/source:Span", ptr %l5
  %t174 = load ptr, ptr %l75, !tbaa !29
  %t179 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2earrayCopy(ptr %v0, ptr %t174, { i64, [4 x i64] } %t170, i32 %t171, %"compiler/source:Span" %t172, { i64, [1 x i64] } %a6)
  store { i64, [4 x i64] } %t179, ptr %l82
  br label %bb18
bb18:
  %t180 = load { i64, [4 x i64] }, ptr %l82
  store { i64, [4 x i64] } %t180, ptr %l74
  br label %bb20
bb19:
  store { i64, [4 x i64] } zeroinitializer, ptr %t181
  %t182 = getelementptr { i64, [4 x i64] }, ptr %t181, i32 0, i32 0
  store i64 1, ptr %t182
  %t183 = load %"compiler/mir:Place", ptr %l84
  %t184 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t183, 0
  %t185 = getelementptr { i64, [4 x i64] }, ptr %t181, i32 0, i32 1
  store { %"compiler/mir:Place" } %t184, ptr %t185
  %t186 = load { i64, [4 x i64] }, ptr %t181
  store { i64, [4 x i64] } %t186, ptr %l74
  br label %bb20
bb20:
  %t188 = load { i64, [4 x i64] }, ptr %l74
  %t189 = load ptr, ptr %l0, !tbaa !29
  %t190 = load %"compiler/source:Span", ptr %l5
  %t191 = load %"compiler/mir:Place", ptr %l1
  store { i64, [15 x i64] } zeroinitializer, ptr %t193
  %t194 = getelementptr { i64, [15 x i64] }, ptr %t193, i32 0, i32 0
  store i64 0, ptr %t194
  %t196 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t188, 0
  %t197 = getelementptr { i64, [15 x i64] }, ptr %t193, i32 0, i32 1
  store { { i64, [4 x i64] } } %t196, ptr %t197
  %t198 = load { i64, [15 x i64] }, ptr %t193
  store { i64, [21 x i64] } zeroinitializer, ptr %t199
  %t200 = getelementptr { i64, [21 x i64] }, ptr %t199, i32 0, i32 0
  store i64 0, ptr %t200
  %t202 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t190, 0
  %t204 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t202, %"compiler/mir:Place" %t191, 1
  %t206 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t204, { i64, [15 x i64] } %t198, 2
  %t207 = getelementptr { i64, [21 x i64] }, ptr %t199, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t206, ptr %t207
  %t208 = load { i64, [21 x i64] }, ptr %t199
  %t210 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t208, ptr %t210
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s0, ptr %t189, ptr %t210)
  br label %bb21
bb21:
  %t213 = load ptr, ptr %l0, !tbaa !29
  %t214 = load i32, ptr %l13, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2egoto(ptr %v0, ptr %t213, i32 %t214)
  br label %bb22
bb22:
  %t217 = load ptr, ptr %l0, !tbaa !29
  %t218 = load i32, ptr %l13, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t217, i32 %t218)
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2eassemble(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca i32
  %l7 = alloca { i64, [4 x i64] }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca { i64, [4 x i64] }
  %l16 = alloca { i64, [1 x i64] }
  %l23 = alloca i1
  %l24 = alloca i32
  %l27 = alloca i32
  %l31 = alloca i32
  %l34 = alloca i32
  %l37 = alloca i1
  %l38 = alloca ptr
  %l41 = alloca i32
  %l42 = alloca i32
  %l49 = alloca i64
  %l51 = alloca i1
  %l58 = alloca ptr
  %l61 = alloca i32
  %l64 = alloca { i64, [4 x i64] }
  %l73 = alloca i64
  %l79 = alloca i64
  %l83 = alloca i64
  %l86 = alloca i64
  %l104 = alloca i64
  %l108 = alloca i32
  %l111 = alloca %"compiler/mir:Place"
  %l115 = alloca ptr
  %l116 = alloca i32
  %l117 = alloca i32
  %l121 = alloca %"compiler/mir:Range"
  %l125 = alloca { i64, [4 x i64] }
  %l130 = alloca { i64, [1 x i64] }
  %l139 = alloca { i64, [4 x i64] }
  %l142 = alloca i32
  %l145 = alloca i1
  %l148 = alloca i1
  %l149 = alloca i1
  %l152 = alloca i1
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %t103 = alloca { i64, [7 x i64] }, align 8
  %t194 = alloca { i64, [4 x i64] }, align 8
  %t219 = alloca { i64, [15 x i64] }, align 8
  %t253 = alloca { i64, [15 x i64] }, align 8
  %t305 = alloca { i64, [21 x i64] }, align 8
  %t329 = alloca { i64, [7 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/lower:lowering", ptr %t6, i32 0, i32 2
  %t9 = load ptr, ptr %t8, !tbaa !29
  store ptr %t9, ptr %l3, !tbaa !29
  %t11 = load ptr, ptr %l3, !tbaa !29
  %t12 = load i32, ptr %l1, !tbaa !23
  %t15 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t11, i32 %t12)
  store i1 %t15, ptr %l23
  br label %bb1
bb1:
  %t16 = load i1, ptr %l23, !tbaa !21
  br i1 %t16, label %bb2, label %bb3
bb2:
  %t17 = load ptr, ptr %l3, !tbaa !29
  %t18 = load i32, ptr %l1, !tbaa !23
  %t21 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t17, i32 %t18)
  store i32 %t21, ptr %l27
  br label %bb4
bb3:
  %t22 = load i32, ptr %l1, !tbaa !23
  store i32 %t22, ptr %l24, !tbaa !23
  br label %bb5
bb4:
  %t24 = load i32, ptr %l27, !tbaa !23
  store i32 %t24, ptr %l24, !tbaa !23
  br label %bb5
bb5:
  %t25 = load i32, ptr %l24, !tbaa !23
  store i32 %t25, ptr %l4, !tbaa !23
  %t26 = load ptr, ptr %l3, !tbaa !29
  %t27 = load i32, ptr %l4, !tbaa !23
  %t30 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t26, i32 %t27)
  store i32 %t30, ptr %l31
  br label %bb6
bb6:
  %t31 = load i32, ptr %l31, !tbaa !23
  store i32 %t31, ptr %l5, !tbaa !23
  %t32 = load ptr, ptr %l3, !tbaa !29
  %t33 = load i32, ptr %l5, !tbaa !23
  %t36 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t32, i32 %t33)
  store i32 %t36, ptr %l34
  br label %bb7
bb7:
  %t37 = load i32, ptr %l34
  %t39 = trunc i64 18 to i32
  %t40 = icmp eq i32 %t37, %t39
  br i1 %t40, label %bb8, label %bb9
bb8:
  %t42 = load ptr, ptr %l3, !tbaa !29
  store ptr %t42, ptr %l38, !tbaa !29
  %t43 = load ptr, ptr %l3, !tbaa !29
  %t44 = load i32, ptr %l5, !tbaa !23
  %t47 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t43, i32 %t44)
  store i32 %t47, ptr %l41
  br label %bb10
bb9:
  store i1 false, ptr %l37, !tbaa !21
  br label %bb12
bb10:
  %t48 = load ptr, ptr %l38, !tbaa !29
  %t49 = load i32, ptr %l41, !tbaa !23
  %t50 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t48, i32 %t49)
  store i32 %t50, ptr %l42
  br label %bb11
bb11:
  %t51 = load i32, ptr %l42
  %t53 = trunc i64 0 to i32
  %t54 = icmp eq i32 %t51, %t53
  store i1 %t54, ptr %l37, !tbaa !21
  br label %bb12
bb12:
  %t56 = load i1, ptr %l37, !tbaa !21
  %t59 = xor i1 %t56, true
  br i1 %t59, label %bb13, label %bb14
bb13:
  %t61 = load ptr, ptr %l2, !tbaa !29
  %t63 = getelementptr %"compiler/typed:Body", ptr %t61, i32 0, i32 10
  %t65 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t63)
  store i64 %t65, ptr %l49
  br label %bb15
bb14:
  br label %bb27
bb15:
  %t66 = load i64, ptr %l49, !tbaa !24
  %t67 = icmp ne i64 %t66, 1
  br i1 %t67, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l51, !tbaa !21
  br label %bb18
bb17:
  %t69 = load i32, ptr %l4, !tbaa !23
  %t70 = load i32, ptr %l1, !tbaa !23
  %t73 = icmp ne i32 %t69, %t70
  store i1 %t73, ptr %l51, !tbaa !21
  br label %bb18
bb18:
  %t75 = load i1, ptr %l51, !tbaa !21
  br i1 %t75, label %bb19, label %bb20
bb19:
  store %olang.scope zeroinitializer, ptr %s2
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t77 = load ptr, ptr %l2, !tbaa !29
  %t79 = getelementptr %"compiler/typed:Body", ptr %t77, i32 0, i32 4
  %t80 = load %"compiler/source:Span", ptr %t79
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2egap(ptr %v0, ptr %s2, ptr %t76, %"compiler/source:Span" %t80, { i64, ptr } { i64 41, ptr @.d16 })
  br label %bb21
bb20:
  br label %bb22
bb21:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb22:
  %t83 = load ptr, ptr %l0, !tbaa !29
  store ptr %t83, ptr %l58, !tbaa !29
  %t84 = load ptr, ptr %l2, !tbaa !29
  %t86 = getelementptr %"compiler/typed:Body", ptr %t84, i32 0, i32 10
  %t88 = call i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t86, i64 0)
  store i32 %t88, ptr %l61
  br label %bb23
bb23:
  %t89 = load i32, ptr %l61, !tbaa !23
  %t91 = load ptr, ptr %l58, !tbaa !29
  %t93 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ecopyLocal(ptr %v0, ptr %t91, i32 %t89)
  store { i64, [4 x i64] } %t93, ptr %l64
  br label %bb24
bb24:
  %t94 = load { i64, [4 x i64] }, ptr %l64
  store { i64, [4 x i64] } %t94, ptr %l7
  %t95 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eleave(ptr %v0, ptr %t95, i64 0)
  br label %bb25
bb25:
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t98 = load ptr, ptr %l2, !tbaa !29
  %t100 = getelementptr %"compiler/typed:Body", ptr %t98, i32 0, i32 4
  %t101 = load %"compiler/source:Span", ptr %t100
  %t102 = load { i64, [4 x i64] }, ptr %l7
  store { i64, [7 x i64] } zeroinitializer, ptr %t103
  %t104 = getelementptr { i64, [7 x i64] }, ptr %t103, i32 0, i32 0
  store i64 5, ptr %t104
  %t106 = insertvalue { %"compiler/source:Span", { i64, [4 x i64] } } undef, %"compiler/source:Span" %t101, 0
  %t108 = insertvalue { %"compiler/source:Span", { i64, [4 x i64] } } %t106, { i64, [4 x i64] } %t102, 1
  %t109 = getelementptr { i64, [7 x i64] }, ptr %t103, i32 0, i32 1
  store { %"compiler/source:Span", { i64, [4 x i64] } } %t108, ptr %t109
  %t110 = load { i64, [7 x i64] }, ptr %t103
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t97, { i64, [7 x i64] } %t110)
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb27:
  %t113 = load ptr, ptr %l2, !tbaa !29
  %t115 = getelementptr %"compiler/typed:Body", ptr %t113, i32 0, i32 10
  %t117 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t115)
  store i64 %t117, ptr %l73
  br label %bb28
bb28:
  %t118 = load i64, ptr %l73, !tbaa !24
  %t119 = icmp sge i64 %t118, 0
  br i1 %t119, label %bb29, label %bb30
bb29:
  %t121 = load i64, ptr %l73, !tbaa !24
  %t122 = icmp sle i64 %t121, 230584300921369395
  br i1 %t122, label %bb31, label %bb32
bb30:
  call void @__olang_check_failed(ptr @olang_loc_b4f44bfc4c4e49f2_17d18a81dcc1f1de)
  unreachable
bb31:
  %t124 = load i64, ptr %l73, !tbaa !24
  %t125 = mul i64 %t124, 40
  %t126 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t125)
  %t127 = insertvalue { i64, ptr } undef, i64 %t124, 0
  %t128 = insertvalue { i64, ptr } %t127, ptr %t126, 1
  store { i64, ptr } %t128, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t130 = load ptr, ptr %l2, !tbaa !29
  %t132 = getelementptr %"compiler/typed:Body", ptr %t130, i32 0, i32 10
  %t134 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t132)
  store i64 %t134, ptr %l79
  br label %bb33
bb32:
  call void @__olang_check_failed(ptr @olang_loc_b4f44bfc4c4e49f2_17d18a81dcc1f1de)
  unreachable
bb33:
  %t135 = load i64, ptr %l79, !tbaa !24
  store i64 %t135, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t136 = load i64, ptr %l10, !tbaa !24
  %t137 = load i64, ptr %l9, !tbaa !24
  %t140 = icmp sgt i64 %t136, %t137
  br i1 %t140, label %bb34, label %bb35
bb34:
  %t142 = load i64, ptr %l11, !tbaa !24
  %t144 = icmp sgt i64 %t142, 0
  br i1 %t144, label %bb36, label %bb37
bb35:
  store i64 0, ptr %l83, !tbaa !24
  br label %bb39
bb36:
  %t146 = load i64, ptr %l10, !tbaa !24
  %t147 = load i64, ptr %l9, !tbaa !24
  %t150 = sub i64 %t146, %t147
  %t151 = load i64, ptr %l11, !tbaa !24
  %t154 = add i64 %t150, %t151
  %t156 = sub i64 %t154, 1
  %t157 = load i64, ptr %l11, !tbaa !24
  %t160 = sdiv i64 %t156, %t157
  store i64 %t160, ptr %l86, !tbaa !24
  br label %bb38
bb37:
  store i64 0, ptr %l86, !tbaa !24
  br label %bb38
bb38:
  %t162 = load i64, ptr %l86, !tbaa !24
  store i64 %t162, ptr %l83, !tbaa !24
  br label %bb39
bb39:
  %t163 = load i64, ptr %l83, !tbaa !24
  store i64 %t163, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb40
bb40:
  store %olang.scope zeroinitializer, ptr %s4
  %t164 = load i64, ptr %l13, !tbaa !24
  %t165 = load i64, ptr %l12, !tbaa !24
  %t168 = icmp slt i64 %t164, %t165
  %t170 = xor i1 %t168, true
  br i1 %t170, label %bb41, label %bb42
bb41:
  call void @__olang_scope_close(ptr %s4)
  br label %bb47
bb42:
  br label %bb43
bb43:
  %t172 = load i64, ptr %l9, !tbaa !24
  %t173 = load i64, ptr %l13, !tbaa !24
  %t174 = load i64, ptr %l11, !tbaa !24
  %t177 = mul i64 %t173, %t174
  %t180 = add i64 %t172, %t177
  store i64 %t180, ptr %l14, !tbaa !24
  %t182 = load i64, ptr %l14, !tbaa !24
  store i64 %t182, ptr %l104, !tbaa !24
  %t183 = load ptr, ptr %l2, !tbaa !29
  %t185 = getelementptr %"compiler/typed:Body", ptr %t183, i32 0, i32 10
  %t186 = load i64, ptr %l14, !tbaa !24
  %t189 = call i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t185, i64 %t186)
  store i32 %t189, ptr %l108
  br label %bb44
bb44:
  %t190 = load i32, ptr %l108, !tbaa !23
  %t193 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t190)
  store %"compiler/mir:Place" %t193, ptr %l111
  br label %bb45
bb45:
  store { i64, [4 x i64] } zeroinitializer, ptr %t194
  %t195 = getelementptr { i64, [4 x i64] }, ptr %t194, i32 0, i32 0
  store i64 1, ptr %t195
  %t196 = load %"compiler/mir:Place", ptr %l111
  %t197 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t196, 0
  %t198 = getelementptr { i64, [4 x i64] }, ptr %t194, i32 0, i32 1
  store { %"compiler/mir:Place" } %t197, ptr %t198
  %t199 = load { i64, [4 x i64] }, ptr %t194
  %t201 = load i64, ptr %l104, !tbaa !24
  %t202 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t203 = load ptr, ptr %t202, !tbaa !27
  %t204 = getelementptr { i64, [4 x i64] }, ptr %t203, i64 %t201
  store { i64, [4 x i64] } %t199, ptr %t204
  call void @__olang_scope_close(ptr %s4)
  br label %bb46
bb46:
  %t205 = load i64, ptr %l13, !tbaa !24
  %t207 = add i64 %t205, 1
  store i64 %t207, ptr %l13, !tbaa !24
  br label %bb40
bb47:
  %t209 = load ptr, ptr %l0, !tbaa !29
  store ptr %t209, ptr %l115, !tbaa !29
  %t210 = load i32, ptr %l4, !tbaa !23
  store i32 %t210, ptr %l116, !tbaa !23
  %t211 = load i32, ptr %l4, !tbaa !23
  store i32 %t211, ptr %l117, !tbaa !23
  %t212 = load ptr, ptr %l0, !tbaa !29
  %t214 = getelementptr %"compiler/lower:lowering", ptr %t212, i32 0, i32 3
  %t215 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t218 = call %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eArgs(ptr %v0, ptr %s0, ptr %t214, { i64, ptr } %t215)
  store %"compiler/mir:Range" %t218, ptr %l121
  br label %bb48
bb48:
  store { i64, [15 x i64] } zeroinitializer, ptr %t219
  %t220 = getelementptr { i64, [15 x i64] }, ptr %t219, i32 0, i32 0
  store i64 6, ptr %t220
  %t221 = load i32, ptr %l117, !tbaa !23
  %t222 = insertvalue { i32, i64, %"compiler/mir:Range" } undef, i32 %t221, 0
  %t223 = insertvalue { i32, i64, %"compiler/mir:Range" } %t222, i64 0, 1
  %t224 = load %"compiler/mir:Range", ptr %l121
  %t225 = insertvalue { i32, i64, %"compiler/mir:Range" } %t223, %"compiler/mir:Range" %t224, 2
  %t226 = getelementptr { i64, [15 x i64] }, ptr %t219, i32 0, i32 1
  store { i32, i64, %"compiler/mir:Range" } %t225, ptr %t226
  %t227 = load { i64, [15 x i64] }, ptr %t219
  %t228 = load ptr, ptr %l2, !tbaa !29
  %t230 = getelementptr %"compiler/typed:Body", ptr %t228, i32 0, i32 4
  %t231 = load %"compiler/source:Span", ptr %t230
  %t232 = load ptr, ptr %l115, !tbaa !29
  %t233 = load i32, ptr %l116, !tbaa !23
  %t236 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %t232, i32 %t233, { i64, [15 x i64] } %t227, %"compiler/source:Span" %t231)
  store { i64, [4 x i64] } %t236, ptr %l125
  br label %bb49
bb49:
  %t237 = load { i64, [4 x i64] }, ptr %l125
  store { i64, [4 x i64] } %t237, ptr %l15
  %t238 = load i32, ptr %l4, !tbaa !23
  %t239 = load i32, ptr %l1, !tbaa !23
  %t242 = icmp ne i32 %t238, %t239
  br i1 %t242, label %bb50, label %bb51
bb50:
  %t244 = load ptr, ptr %l0, !tbaa !29
  %t246 = call { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einstance(ptr %v0, ptr %t244)
  store { i64, [1 x i64] } %t246, ptr %l130
  br label %bb52
bb51:
  br label %bb67
bb52:
  %t247 = load { i64, [1 x i64] }, ptr %l130
  store { i64, [1 x i64] } %t247, ptr %l16
  %t248 = load ptr, ptr %l0, !tbaa !29
  %t249 = load i32, ptr %l1, !tbaa !23
  %t250 = load { i64, [1 x i64] }, ptr %l16
  %t251 = load { i64, [4 x i64] }, ptr %l15
  %t252 = load i32, ptr %l1, !tbaa !23
  store { i64, [15 x i64] } zeroinitializer, ptr %t253
  %t254 = getelementptr { i64, [15 x i64] }, ptr %t253, i32 0, i32 0
  store i64 7, ptr %t254
  %t256 = insertvalue { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 } undef, { i64, [1 x i64] } %t250, 0
  %t258 = insertvalue { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 } %t256, { i64, [4 x i64] } %t251, 1
  %t260 = insertvalue { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 } %t258, i32 %t252, 2
  %t261 = getelementptr { i64, [15 x i64] }, ptr %t253, i32 0, i32 1
  store { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 } %t260, ptr %t261
  %t262 = load { i64, [15 x i64] }, ptr %t253
  %t263 = load ptr, ptr %l2, !tbaa !29
  %t265 = getelementptr %"compiler/typed:Body", ptr %t263, i32 0, i32 4
  %t266 = load %"compiler/source:Span", ptr %t265
  %t271 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %t248, i32 %t249, { i64, [15 x i64] } %t262, %"compiler/source:Span" %t266)
  store { i64, [4 x i64] } %t271, ptr %l139
  br label %bb53
bb53:
  %t272 = load { i64, [4 x i64] }, ptr %l139
  store { i64, [4 x i64] } %t272, ptr %l15
  %t273 = load ptr, ptr %l3, !tbaa !29
  %t274 = load i32, ptr %l5, !tbaa !23
  %t277 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t273, i32 %t274)
  store i32 %t277, ptr %l142
  br label %bb54
bb54:
  %t278 = load i32, ptr %l142
  %t280 = trunc i64 18 to i32
  %t281 = icmp eq i32 %t278, %t280
  br i1 %t281, label %bb55, label %bb56
bb55:
  %t283 = load ptr, ptr %l3, !tbaa !29
  %t284 = load i32, ptr %l5, !tbaa !23
  %t287 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %t283, i32 %t284)
  store i1 %t287, ptr %l148
  br label %bb57
bb56:
  store i1 false, ptr %l145, !tbaa !21
  br label %bb58
bb57:
  %t288 = load i1, ptr %l148, !tbaa !21
  store i1 %t288, ptr %l145, !tbaa !21
  br label %bb58
bb58:
  %t289 = load i1, ptr %l145, !tbaa !21
  br i1 %t289, label %bb59, label %bb60
bb59:
  %t290 = load ptr, ptr %l3, !tbaa !29
  %t291 = load i32, ptr %l5, !tbaa !23
  %t294 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDestructs(ptr %v0, ptr %t290, i32 %t291)
  store i1 %t294, ptr %l152
  br label %bb61
bb60:
  store i1 false, ptr %l149, !tbaa !21
  br label %bb62
bb61:
  %t295 = load i1, ptr %l152, !tbaa !21
  store i1 %t295, ptr %l149, !tbaa !21
  br label %bb62
bb62:
  %t296 = load i1, ptr %l149, !tbaa !21
  br i1 %t296, label %bb63, label %bb64
bb63:
  store %olang.scope zeroinitializer, ptr %s7
  %t297 = load ptr, ptr %l0, !tbaa !29
  %t298 = load ptr, ptr %l2, !tbaa !29
  %t300 = getelementptr %"compiler/typed:Body", ptr %t298, i32 0, i32 4
  %t301 = load %"compiler/source:Span", ptr %t300
  %t302 = load { i64, [1 x i64] }, ptr %l16
  %t303 = load i32, ptr %l4, !tbaa !23
  %t304 = load { i64, [4 x i64] }, ptr %l15
  store { i64, [21 x i64] } zeroinitializer, ptr %t305
  %t306 = getelementptr { i64, [21 x i64] }, ptr %t305, i32 0, i32 0
  store i64 6, ptr %t306
  %t308 = insertvalue { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } undef, %"compiler/source:Span" %t301, 0
  %t310 = insertvalue { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } %t308, { i64, [1 x i64] } %t302, 1
  %t312 = insertvalue { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } %t310, i32 %t303, 2
  %t314 = insertvalue { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } %t312, { i64, [4 x i64] } %t304, 3
  %t315 = getelementptr { i64, [21 x i64] }, ptr %t305, i32 0, i32 1
  store { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } %t314, ptr %t315
  %t316 = load { i64, [21 x i64] }, ptr %t305
  %t318 = call ptr @__olang_scope_alloc_a(ptr %s7, i64 176, i64 8)
  store { i64, [21 x i64] } %t316, ptr %t318
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s7, ptr %t297, ptr %t318)
  br label %bb65
bb64:
  br label %bb66
bb65:
  call void @__olang_scope_close(ptr %s7)
  br label %bb66
bb66:
  br label %bb67
bb67:
  %t321 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eleave(ptr %v0, ptr %t321, i64 0)
  br label %bb68
bb68:
  %t323 = load ptr, ptr %l0, !tbaa !29
  %t324 = load ptr, ptr %l2, !tbaa !29
  %t326 = getelementptr %"compiler/typed:Body", ptr %t324, i32 0, i32 4
  %t327 = load %"compiler/source:Span", ptr %t326
  %t328 = load { i64, [4 x i64] }, ptr %l15
  store { i64, [7 x i64] } zeroinitializer, ptr %t329
  %t330 = getelementptr { i64, [7 x i64] }, ptr %t329, i32 0, i32 0
  store i64 5, ptr %t330
  %t332 = insertvalue { %"compiler/source:Span", { i64, [4 x i64] } } undef, %"compiler/source:Span" %t327, 0
  %t334 = insertvalue { %"compiler/source:Span", { i64, [4 x i64] } } %t332, { i64, [4 x i64] } %t328, 1
  %t335 = getelementptr { i64, [7 x i64] }, ptr %t329, i32 0, i32 1
  store { %"compiler/source:Span", { i64, [4 x i64] } } %t334, ptr %t335
  %t336 = load { i64, [7 x i64] }, ptr %t329
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t323, { i64, [7 x i64] } %t336)
  br label %bb69
bb69:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2eassert(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l3 = alloca ptr
  %l4 = alloca { i64, [4 x i64] }
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca { i64, [4 x i64] }
  %l10 = alloca ptr
  %l17 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l18 = alloca i1
  %l22 = alloca { i64, [4 x i64] }
  %l27 = alloca i32
  %l30 = alloca i32
  %l45 = alloca { i64, [4 x i64] }
  %s0 = alloca %olang.scope
  %t55 = alloca { i64, [7 x i64] }, align 8
  %t71 = alloca { i64, [4 x i64] }, align 8
  %t91 = alloca { i64, [7 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/lower:Lowerer", ptr %t4, i32 0, i32 6
  store ptr %t6, ptr %l10, !tbaa !29
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/lower:lowering", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/typed:Body", ptr %t10, i32 0, i32 0
  %t13 = load i32, ptr %t12, !tbaa !23
  %t15 = sext i32 %t13 to i64
  %t16 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t17 = load i32, ptr %t16, !tbaa !23
  %t19 = sext i32 %t17 to i64
  %t22 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s0, i64 %t15, i64 %t19)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t22, ptr %l17
  br label %bb1
bb1:
  %t23 = load ptr, ptr %l10, !tbaa !29
  %t24 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l17
  %t25 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %v0, ptr %t23, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t24)
  store i1 %t25, ptr %l18
  br label %bb2
bb2:
  %t26 = load i1, ptr %l18, !tbaa !21
  br i1 %t26, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb4:
  br label %bb5
bb5:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t32 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v1, ptr %t27, ptr %a2)
  store { i64, [4 x i64] } %t32, ptr %l22
  br label %bb6
bb6:
  %t33 = load { i64, [4 x i64] }, ptr %l22
  store { i64, [4 x i64] } %t33, ptr %l4
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/lower:lowering", ptr %t34, i32 0, i32 7
  %t37 = load i1, ptr %t36, !tbaa !21
  br i1 %t37, label %bb7, label %bb8
bb7:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb8:
  br label %bb9
bb9:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/lower:lowering", ptr %t39, i32 0, i32 3
  %t43 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t41)
  store i32 %t43, ptr %l27
  br label %bb10
bb10:
  %t44 = load i32, ptr %l27, !tbaa !23
  store i32 %t44, ptr %l5, !tbaa !23
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/lower:lowering", ptr %t45, i32 0, i32 3
  %t49 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t47)
  store i32 %t49, ptr %l30
  br label %bb11
bb11:
  %t50 = load i32, ptr %l30, !tbaa !23
  store i32 %t50, ptr %l6, !tbaa !23
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t52 = load { i64, [4 x i64] }, ptr %l4
  %t53 = load i32, ptr %l5, !tbaa !23
  %t54 = load i32, ptr %l6, !tbaa !23
  store { i64, [7 x i64] } zeroinitializer, ptr %t55
  %t56 = getelementptr { i64, [7 x i64] }, ptr %t55, i32 0, i32 0
  store i64 2, ptr %t56
  %t58 = insertvalue { { i64, [4 x i64] }, i32, i32 } undef, { i64, [4 x i64] } %t52, 0
  %t60 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t58, i32 %t53, 1
  %t62 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t60, i32 %t54, 2
  %t63 = getelementptr { i64, [7 x i64] }, ptr %t55, i32 0, i32 1
  store { { i64, [4 x i64] }, i32, i32 } %t62, ptr %t63
  %t64 = load { i64, [7 x i64] }, ptr %t55
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t51, { i64, [7 x i64] } %t64)
  br label %bb12
bb12:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t68 = load i32, ptr %l6, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t67, i32 %t68)
  br label %bb13
bb13:
  store { i64, [4 x i64] } zeroinitializer, ptr %t71
  %t72 = getelementptr { i64, [4 x i64] }, ptr %t71, i32 0, i32 0
  store i64 0, ptr %t72
  %t73 = load { i64, [4 x i64] }, ptr %t71
  store { i64, [4 x i64] } %t73, ptr %l7
  %t75 = load ptr, ptr %l3, !tbaa !29
  %t77 = icmp eq ptr %t75, null
  %t79 = xor i1 %t77, true
  br i1 %t79, label %bb14, label %bb15
bb14:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t82 = load ptr, ptr %l3, !tbaa !29
  %t86 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v2, ptr %t81, ptr %t82)
  store { i64, [4 x i64] } %t86, ptr %l45
  br label %bb16
bb15:
  br label %bb17
bb16:
  %t87 = load { i64, [4 x i64] }, ptr %l45
  store { i64, [4 x i64] } %t87, ptr %l7
  br label %bb17
bb17:
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t89 = load %"compiler/source:Span", ptr %l1
  %t90 = load { i64, [4 x i64] }, ptr %l7
  store { i64, [7 x i64] } zeroinitializer, ptr %t91
  %t92 = getelementptr { i64, [7 x i64] }, ptr %t91, i32 0, i32 0
  store i64 8, ptr %t92
  %t94 = insertvalue { %"compiler/source:Span", i32, { i64, [4 x i64] } } undef, %"compiler/source:Span" %t89, 0
  %t96 = insertvalue { %"compiler/source:Span", i32, { i64, [4 x i64] } } %t94, i32 5, 1
  %t98 = insertvalue { %"compiler/source:Span", i32, { i64, [4 x i64] } } %t96, { i64, [4 x i64] } %t90, 2
  %t99 = getelementptr { i64, [7 x i64] }, ptr %t91, i32 0, i32 1
  store { %"compiler/source:Span", i32, { i64, [4 x i64] } } %t98, ptr %t99
  %t100 = load { i64, [7 x i64] }, ptr %t91
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t88, { i64, [7 x i64] } %t100)
  br label %bb18
bb18:
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t104 = load i32, ptr %l5, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t103, i32 %t104)
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eaway(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i64
  %l12 = alloca { i64, [4 x i64] }
  %rv = alloca { i64, [4 x i64] }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 4
  %t4 = load i64, ptr %t3, !tbaa !24
  store i64 %t4, ptr %l3, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/lower:lowering", ptr %t6, i32 0, i32 4
  store i64 %a1, ptr %t10, !tbaa !24
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t16 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v1, ptr %t11, ptr %a2)
  store { i64, [4 x i64] } %t16, ptr %l12
  br label %bb1
bb1:
  %t17 = load { i64, [4 x i64] }, ptr %l12
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t19 = load i64, ptr %l3, !tbaa !24
  %t22 = getelementptr %"compiler/lower:lowering", ptr %t18, i32 0, i32 4
  store i64 %t19, ptr %t22, !tbaa !24
  store { i64, [4 x i64] } %t17, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2ebang(ptr %v0, ptr %a0, { i64, [4 x i64] } %a1, i32 %a2, %"compiler/source:Span" %a3, i32 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i32
  %l13 = alloca i32
  %l18 = alloca { i64, ptr }
  %l24 = alloca i64
  %l27 = alloca i64
  %l47 = alloca i32
  %l50 = alloca i32
  %l55 = alloca { i64, ptr }
  %l58 = alloca { i64, ptr }
  %l60 = alloca { i64, [4 x i64] }
  %l71 = alloca { i64, ptr }
  %l80 = alloca ptr
  %l81 = alloca %"compiler/source:Span"
  %l82 = alloca i32
  %l85 = alloca { i64, [4 x i64] }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %t105 = alloca { i64, [7 x i64] }, align 8
  %t133 = alloca { i64, [7 x i64] }, align 8
  %t161 = alloca { i64, [7 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a3, ptr %l3
  store i32 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = load %"compiler/source:Span", ptr %l3
  %t7 = call { i64, ptr } @compiler_2flower_2ecompiler_2flower_3alowering_2ebangNames(ptr %v0, ptr %s0, ptr %t1, i32 %a2, %"compiler/source:Span" %t3)
  store { i64, ptr } %t7, ptr %l18
  br label %bb1
bb1:
  %t8 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t8, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t9 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t9, 0
  store i64 %t11, ptr %l7, !tbaa !24
  store i64 2, ptr %l8, !tbaa !24
  %t13 = load i64, ptr %l7, !tbaa !24
  %t14 = load i64, ptr %l6, !tbaa !24
  %t17 = icmp sgt i64 %t13, %t14
  br i1 %t17, label %bb2, label %bb3
bb2:
  %t19 = load i64, ptr %l8, !tbaa !24
  %t21 = icmp sgt i64 %t19, 0
  br i1 %t21, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l24, !tbaa !24
  br label %bb7
bb4:
  %t23 = load i64, ptr %l7, !tbaa !24
  %t24 = load i64, ptr %l6, !tbaa !24
  %t27 = sub i64 %t23, %t24
  %t28 = load i64, ptr %l8, !tbaa !24
  %t31 = add i64 %t27, %t28
  %t33 = sub i64 %t31, 1
  %t34 = load i64, ptr %l8, !tbaa !24
  %t37 = sdiv i64 %t33, %t34
  store i64 %t37, ptr %l27, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l27, !tbaa !24
  br label %bb6
bb6:
  %t39 = load i64, ptr %l27, !tbaa !24
  store i64 %t39, ptr %l24, !tbaa !24
  br label %bb7
bb7:
  %t40 = load i64, ptr %l24, !tbaa !24
  store i64 %t40, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t41 = load i64, ptr %l10, !tbaa !24
  %t42 = load i64, ptr %l9, !tbaa !24
  %t45 = icmp slt i64 %t41, %t42
  %t47 = xor i1 %t45, true
  br i1 %t47, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb20
bb10:
  br label %bb11
bb11:
  %t49 = load i64, ptr %l6, !tbaa !24
  %t50 = load i64, ptr %l10, !tbaa !24
  %t51 = load i64, ptr %l8, !tbaa !24
  %t54 = mul i64 %t50, %t51
  %t57 = add i64 %t49, %t54
  store i64 %t57, ptr %l11, !tbaa !24
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/lower:lowering", ptr %t59, i32 0, i32 3
  %t63 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t61)
  store i32 %t63, ptr %l47
  br label %bb12
bb12:
  %t64 = load i32, ptr %l47, !tbaa !23
  store i32 %t64, ptr %l12, !tbaa !23
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/lower:lowering", ptr %t65, i32 0, i32 3
  %t69 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t67)
  store i32 %t69, ptr %l50
  br label %bb13
bb13:
  %t70 = load i32, ptr %l50, !tbaa !23
  store i32 %t70, ptr %l13, !tbaa !23
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t72 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t74 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t74, ptr %l55, !tbaa !27
  %t75 = load i64, ptr %l11, !tbaa !24
  %t77 = getelementptr { i64, ptr }, ptr %l55, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !27
  %t79 = getelementptr { i64, [4 x i64] }, ptr %t78, i64 %t75
  %t80 = load { i64, [4 x i64] }, ptr %t79
  %t81 = mul i64 2, 40
  %t82 = call ptr @__olang_scope_alloc_zeroed(ptr %s2, i64 %t81)
  %t83 = insertvalue { i64, ptr } undef, i64 2, 0
  %t84 = insertvalue { i64, ptr } %t83, ptr %t82, 1
  store { i64, ptr } %t84, ptr %l58, !tbaa !27
  %t86 = getelementptr { i64, ptr }, ptr %l58, i32 0, i32 1
  %t87 = load ptr, ptr %t86, !tbaa !27
  %t88 = getelementptr { i64, [4 x i64] }, ptr %t87, i64 0
  store { i64, [4 x i64] } %a1, ptr %t88
  %t90 = getelementptr { i64, ptr }, ptr %l58, i32 0, i32 1
  %t91 = load ptr, ptr %t90, !tbaa !27
  %t92 = getelementptr { i64, [4 x i64] }, ptr %t91, i64 1
  store { i64, [4 x i64] } %t80, ptr %t92
  %t93 = load %"compiler/source:Span", ptr %l3
  %t97 = load { i64, ptr }, ptr %l58, !tbaa !27
  %t99 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s2, ptr %t71, i32 13, i32 %t72, { i64, ptr } %t97, %"compiler/source:Span" %t93)
  store { i64, [4 x i64] } %t99, ptr %l60
  br label %bb14
bb14:
  %t100 = load { i64, [4 x i64] }, ptr %l60
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t103 = load i32, ptr %l12, !tbaa !23
  %t104 = load i32, ptr %l13, !tbaa !23
  store { i64, [7 x i64] } zeroinitializer, ptr %t105
  %t106 = getelementptr { i64, [7 x i64] }, ptr %t105, i32 0, i32 0
  store i64 2, ptr %t106
  %t108 = insertvalue { { i64, [4 x i64] }, i32, i32 } undef, { i64, [4 x i64] } %t100, 0
  %t110 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t108, i32 %t103, 1
  %t112 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t110, i32 %t104, 2
  %t113 = getelementptr { i64, [7 x i64] }, ptr %t105, i32 0, i32 1
  store { { i64, [4 x i64] }, i32, i32 } %t112, ptr %t113
  %t114 = load { i64, [7 x i64] }, ptr %t105
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t101, { i64, [7 x i64] } %t114)
  br label %bb15
bb15:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t118 = load i32, ptr %l12, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t117, i32 %t118)
  br label %bb16
bb16:
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t122 = load %"compiler/source:Span", ptr %l3
  %t123 = load i32, ptr %l4
  %t124 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t124, ptr %l71, !tbaa !27
  %t125 = load i64, ptr %l11, !tbaa !24
  %t127 = add i64 %t125, 1
  %t129 = getelementptr { i64, ptr }, ptr %l71, i32 0, i32 1
  %t130 = load ptr, ptr %t129, !tbaa !27
  %t131 = getelementptr { i64, [4 x i64] }, ptr %t130, i64 %t127
  %t132 = load { i64, [4 x i64] }, ptr %t131
  store { i64, [7 x i64] } zeroinitializer, ptr %t133
  %t134 = getelementptr { i64, [7 x i64] }, ptr %t133, i32 0, i32 0
  store i64 8, ptr %t134
  %t136 = insertvalue { %"compiler/source:Span", i32, { i64, [4 x i64] } } undef, %"compiler/source:Span" %t122, 0
  %t138 = insertvalue { %"compiler/source:Span", i32, { i64, [4 x i64] } } %t136, i32 %t123, 1
  %t140 = insertvalue { %"compiler/source:Span", i32, { i64, [4 x i64] } } %t138, { i64, [4 x i64] } %t132, 2
  %t141 = getelementptr { i64, [7 x i64] }, ptr %t133, i32 0, i32 1
  store { %"compiler/source:Span", i32, { i64, [4 x i64] } } %t140, ptr %t141
  %t142 = load { i64, [7 x i64] }, ptr %t133
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t121, { i64, [7 x i64] } %t142)
  br label %bb17
bb17:
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t146 = load i32, ptr %l13, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t145, i32 %t146)
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s2)
  br label %bb19
bb19:
  %t149 = load i64, ptr %l10, !tbaa !24
  %t151 = add i64 %t149, 1
  store i64 %t151, ptr %l10, !tbaa !24
  br label %bb8
bb20:
  %t153 = load ptr, ptr %l0, !tbaa !29
  store ptr %t153, ptr %l80, !tbaa !29
  %t154 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t154, ptr %l81
  %t155 = load i32, ptr %l4
  store i32 %t155, ptr %l82
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t157 = load %"compiler/source:Span", ptr %l3
  %t160 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2etextData(ptr %v0, ptr %s0, ptr %t156, { i64, ptr } { i64 15, ptr @.d17 }, %"compiler/source:Span" %t157)
  store { i64, [4 x i64] } %t160, ptr %l85
  br label %bb21
bb21:
  store { i64, [7 x i64] } zeroinitializer, ptr %t161
  %t162 = getelementptr { i64, [7 x i64] }, ptr %t161, i32 0, i32 0
  store i64 8, ptr %t162
  %t163 = load %"compiler/source:Span", ptr %l81
  %t164 = insertvalue { %"compiler/source:Span", i32, { i64, [4 x i64] } } undef, %"compiler/source:Span" %t163, 0
  %t165 = load i32, ptr %l82
  %t166 = insertvalue { %"compiler/source:Span", i32, { i64, [4 x i64] } } %t164, i32 %t165, 1
  %t167 = load { i64, [4 x i64] }, ptr %l85
  %t168 = insertvalue { %"compiler/source:Span", i32, { i64, [4 x i64] } } %t166, { i64, [4 x i64] } %t167, 2
  %t169 = getelementptr { i64, [7 x i64] }, ptr %t161, i32 0, i32 1
  store { %"compiler/source:Span", i32, { i64, [4 x i64] } } %t168, ptr %t169
  %t170 = load { i64, [7 x i64] }, ptr %t161
  %t171 = load ptr, ptr %l80, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t171, { i64, [7 x i64] } %t170)
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2flower_2ecompiler_2flower_3alowering_2ebangNames(ptr %v0, ptr %v1, ptr %a0, i32 %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i32
  %l13 = alloca i32
  %l14 = alloca i64
  %l15 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l27 = alloca { i64, ptr }
  %l28 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l35 = alloca i64
  %l38 = alloca i64
  %l57 = alloca { i64, ptr }
  %l60 = alloca i32
  %l63 = alloca i32
  %l69 = alloca i32
  %l72 = alloca i64
  %l79 = alloca ptr
  %l89 = alloca { i64, ptr }
  %l94 = alloca { i64, ptr }
  %l100 = alloca i64
  %l103 = alloca i64
  %l129 = alloca ptr
  %l130 = alloca ptr
  %l131 = alloca { i64, ptr }
  %l133 = alloca ptr
  %l136 = alloca i32
  %l137 = alloca { i64, ptr }
  %l140 = alloca { i64, ptr }
  %l143 = alloca { i64, ptr }
  %l147 = alloca { i64, [4 x i64] }
  %l153 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  %t216 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t6 = load ptr, ptr %l3, !tbaa !29
  %t10 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t6, i32 %a1)
  store { i64, ptr } %t10, ptr %l27
  br label %bb1
bb1:
  %t11 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fmir_3aOperand_3e_2ector(ptr %s0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t12, ptr %l28
  br label %bb2
bb2:
  %t13 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l28
  %t14 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t13, ptr %t14
  store ptr %t14, ptr %l5, !tbaa !29
  store i64 0, ptr %l6, !tbaa !24
  %t16 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t18 = extractvalue { i64, ptr } %t16, 0
  store i64 %t18, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t20 = load i64, ptr %l7, !tbaa !24
  %t21 = load i64, ptr %l6, !tbaa !24
  %t24 = icmp sgt i64 %t20, %t21
  br i1 %t24, label %bb3, label %bb4
bb3:
  %t26 = load i64, ptr %l8, !tbaa !24
  %t28 = icmp sgt i64 %t26, 0
  br i1 %t28, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l35, !tbaa !24
  br label %bb8
bb5:
  %t30 = load i64, ptr %l7, !tbaa !24
  %t31 = load i64, ptr %l6, !tbaa !24
  %t34 = sub i64 %t30, %t31
  %t35 = load i64, ptr %l8, !tbaa !24
  %t38 = add i64 %t34, %t35
  %t40 = sub i64 %t38, 1
  %t41 = load i64, ptr %l8, !tbaa !24
  %t44 = sdiv i64 %t40, %t41
  store i64 %t44, ptr %l38, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l38, !tbaa !24
  br label %bb7
bb7:
  %t46 = load i64, ptr %l38, !tbaa !24
  store i64 %t46, ptr %l35, !tbaa !24
  br label %bb8
bb8:
  %t47 = load i64, ptr %l35, !tbaa !24
  store i64 %t47, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t48 = load i64, ptr %l10, !tbaa !24
  %t49 = load i64, ptr %l9, !tbaa !24
  %t52 = icmp slt i64 %t48, %t49
  %t54 = xor i1 %t52, true
  br i1 %t54, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb42
bb11:
  br label %bb12
bb12:
  %t56 = load i64, ptr %l6, !tbaa !24
  %t57 = load i64, ptr %l10, !tbaa !24
  %t58 = load i64, ptr %l8, !tbaa !24
  %t61 = mul i64 %t57, %t58
  %t64 = add i64 %t56, %t61
  store i64 %t64, ptr %l11, !tbaa !24
  %t66 = load ptr, ptr %l3, !tbaa !29
  %t67 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t67, ptr %l57, !tbaa !27
  %t68 = load i64, ptr %l11, !tbaa !24
  %t70 = getelementptr { i64, ptr }, ptr %l57, i32 0, i32 1
  %t71 = load ptr, ptr %t70, !tbaa !27
  %t72 = getelementptr i32, ptr %t71, i64 %t68
  %t73 = load i32, ptr %t72, !tbaa !33
  %t76 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t66, i32 %t73)
  store i32 %t76, ptr %l60
  br label %bb13
bb13:
  %t77 = load i32, ptr %l60, !tbaa !23
  store i32 %t77, ptr %l12, !tbaa !23
  %t78 = load ptr, ptr %l3, !tbaa !29
  %t79 = load i32, ptr %l12, !tbaa !23
  %t82 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t78, i32 %t79)
  store i32 %t82, ptr %l63
  br label %bb14
bb14:
  %t83 = load i32, ptr %l63
  %t85 = trunc i64 18 to i32
  %t86 = icmp eq i32 %t83, %t85
  %t88 = xor i1 %t86, true
  br i1 %t88, label %bb15, label %bb16
bb15:
  call void @__olang_scope_close(ptr %s2)
  br label %bb41
bb16:
  br label %bb17
bb17:
  %t90 = load ptr, ptr %l3, !tbaa !29
  %t91 = load i32, ptr %l12, !tbaa !23
  %t94 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t90, i32 %t91)
  store i32 %t94, ptr %l69
  br label %bb18
bb18:
  %t95 = load i32, ptr %l69, !tbaa !23
  store i32 %t95, ptr %l13, !tbaa !23
  %t96 = load ptr, ptr %l3, !tbaa !29
  %t97 = load i32, ptr %l13, !tbaa !23
  %t100 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %t96, i32 %t97)
  store i64 %t100, ptr %l72
  br label %bb19
bb19:
  %t101 = load i64, ptr %l72, !tbaa !24
  store i64 %t101, ptr %l14, !tbaa !24
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = getelementptr %"compiler/lower:lowering", ptr %t102, i32 0, i32 0
  %t105 = load ptr, ptr %t104, !tbaa !29
  %t107 = getelementptr %"compiler/lower:Lowerer", ptr %t105, i32 0, i32 0
  %t108 = load ptr, ptr %t107, !tbaa !29
  %t110 = getelementptr %"compiler/generic:Program", ptr %t108, i32 0, i32 0
  %t111 = load ptr, ptr %t110, !tbaa !29
  %t113 = getelementptr %"compiler/load:Loader", ptr %t111, i32 0, i32 5
  %t114 = load i64, ptr %l14, !tbaa !24
  %t117 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t113, i64 %t114)
  store ptr %t117, ptr %l79
  br label %bb20
bb20:
  %t118 = load ptr, ptr %l79, !tbaa !29
  %t120 = getelementptr %"compiler/load:Module", ptr %t118, i32 0, i32 2
  %t121 = load { i64, ptr }, ptr %t120, !tbaa !27
  %t122 = load i64, ptr %l14, !tbaa !24
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t125 = getelementptr %"compiler/lower:lowering", ptr %t123, i32 0, i32 0
  %t126 = load ptr, ptr %t125, !tbaa !29
  %t128 = getelementptr %"compiler/lower:Lowerer", ptr %t126, i32 0, i32 0
  %t129 = load ptr, ptr %t128, !tbaa !29
  %t131 = getelementptr %"compiler/generic:Program", ptr %t129, i32 0, i32 0
  %t132 = load ptr, ptr %t131, !tbaa !29
  %t134 = getelementptr %"compiler/load:Loader", ptr %t132, i32 0, i32 7
  %t135 = load i64, ptr %t134, !tbaa !24
  %t138 = icmp eq i64 %t122, %t135
  %t141 = call { i64, ptr } @compiler_2fload_2eErrQualifier(ptr %v0, ptr %s2, { i64, ptr } %t121, i1 %t138)
  store { i64, ptr } %t141, ptr %l89
  br label %bb21
bb21:
  %t142 = load { i64, ptr }, ptr %l89, !tbaa !27
  store { i64, ptr } %t142, ptr %l15, !tbaa !27
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t145 = getelementptr %"compiler/lower:lowering", ptr %t143, i32 0, i32 0
  %t146 = load ptr, ptr %t145, !tbaa !29
  %t148 = getelementptr %"compiler/lower:Lowerer", ptr %t146, i32 0, i32 0
  %t149 = load ptr, ptr %t148, !tbaa !29
  %t150 = load i32, ptr %l13, !tbaa !23
  %t153 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorWords(ptr %v0, ptr %t149, i32 %t150)
  store { i64, ptr } %t153, ptr %l94
  br label %bb22
bb22:
  %t154 = load { i64, ptr }, ptr %l94, !tbaa !27
  store { i64, ptr } %t154, ptr %l16, !tbaa !27
  store i64 0, ptr %l17, !tbaa !24
  %t155 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t157 = extractvalue { i64, ptr } %t155, 0
  store i64 %t157, ptr %l18, !tbaa !24
  store i64 1, ptr %l19, !tbaa !24
  %t159 = load i64, ptr %l18, !tbaa !24
  %t160 = load i64, ptr %l17, !tbaa !24
  %t163 = icmp sgt i64 %t159, %t160
  br i1 %t163, label %bb23, label %bb24
bb23:
  %t165 = load i64, ptr %l19, !tbaa !24
  %t167 = icmp sgt i64 %t165, 0
  br i1 %t167, label %bb25, label %bb26
bb24:
  store i64 0, ptr %l100, !tbaa !24
  br label %bb28
bb25:
  %t169 = load i64, ptr %l18, !tbaa !24
  %t170 = load i64, ptr %l17, !tbaa !24
  %t173 = sub i64 %t169, %t170
  %t174 = load i64, ptr %l19, !tbaa !24
  %t177 = add i64 %t173, %t174
  %t179 = sub i64 %t177, 1
  %t180 = load i64, ptr %l19, !tbaa !24
  %t183 = sdiv i64 %t179, %t180
  store i64 %t183, ptr %l103, !tbaa !24
  br label %bb27
bb26:
  store i64 0, ptr %l103, !tbaa !24
  br label %bb27
bb27:
  %t185 = load i64, ptr %l103, !tbaa !24
  store i64 %t185, ptr %l100, !tbaa !24
  br label %bb28
bb28:
  %t186 = load i64, ptr %l100, !tbaa !24
  store i64 %t186, ptr %l20, !tbaa !24
  store i64 0, ptr %l21, !tbaa !24
  br label %bb29
bb29:
  store %olang.scope zeroinitializer, ptr %s5
  %t187 = load i64, ptr %l21, !tbaa !24
  %t188 = load i64, ptr %l20, !tbaa !24
  %t191 = icmp slt i64 %t187, %t188
  %t193 = xor i1 %t191, true
  br i1 %t193, label %bb30, label %bb31
bb30:
  call void @__olang_scope_close(ptr %s5)
  br label %bb40
bb31:
  br label %bb32
bb32:
  %t195 = load i64, ptr %l17, !tbaa !24
  %t196 = load i64, ptr %l21, !tbaa !24
  %t197 = load i64, ptr %l19, !tbaa !24
  %t200 = mul i64 %t196, %t197
  %t203 = add i64 %t195, %t200
  store i64 %t203, ptr %l22, !tbaa !24
  %t205 = load ptr, ptr %l5, !tbaa !29
  %t206 = load i32, ptr @G_2ecompiler_2fmir_2eI32T, !tbaa !23
  %t207 = load i64, ptr %l11, !tbaa !24
  %t209 = add i64 %t207, 1
  %t211 = shl i64 %t209, 16
  %t212 = load i64, ptr %l22, !tbaa !24
  %t215 = or i64 %t211, %t212
  store { i64, [4 x i64] } zeroinitializer, ptr %t216
  %t217 = getelementptr { i64, [4 x i64] }, ptr %t216, i32 0, i32 0
  store i64 2, ptr %t217
  %t219 = insertvalue { i32, i64 } undef, i32 %t206, 0
  %t221 = insertvalue { i32, i64 } %t219, i64 %t215, 1
  %t222 = getelementptr { i64, [4 x i64] }, ptr %t216, i32 0, i32 1
  store { i32, i64 } %t221, ptr %t222
  %t223 = load { i64, [4 x i64] }, ptr %t216
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aOperand_3e_2ePush_3ccompiler_2fmir_3aOperand_3e(ptr %s0, ptr %t205, { i64, [4 x i64] } %t223)
  br label %bb33
bb33:
  %t226 = load ptr, ptr %l5, !tbaa !29
  store ptr %t226, ptr %l129, !tbaa !29
  %t227 = load ptr, ptr %l0, !tbaa !29
  store ptr %t227, ptr %l130, !tbaa !29
  %t228 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t228, ptr %l131, !tbaa !27
  %t229 = load ptr, ptr %l3, !tbaa !29
  %t231 = getelementptr %"compiler/types:Table", ptr %t229, i32 0, i32 0
  %t232 = load ptr, ptr %t231, !tbaa !29
  store ptr %t232, ptr %l133, !tbaa !29
  %t233 = load ptr, ptr %l3, !tbaa !29
  %t234 = load i32, ptr %l13, !tbaa !23
  %t237 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %t233, i32 %t234)
  store i32 %t237, ptr %l136
  br label %bb34
bb34:
  %t238 = load ptr, ptr %l133, !tbaa !29
  %t239 = load i32, ptr %l136, !tbaa !23
  %t240 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t238, i32 %t239)
  store { i64, ptr } %t240, ptr %l137
  br label %bb35
bb35:
  %t241 = load ptr, ptr %l3, !tbaa !29
  %t243 = getelementptr %"compiler/types:Table", ptr %t241, i32 0, i32 0
  %t244 = load ptr, ptr %t243, !tbaa !29
  %t245 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t245, ptr %l140, !tbaa !27
  %t246 = load i64, ptr %l22, !tbaa !24
  %t248 = getelementptr { i64, ptr }, ptr %l140, i32 0, i32 1
  %t249 = load ptr, ptr %t248, !tbaa !27
  %t250 = getelementptr i32, ptr %t249, i64 %t246
  %t251 = load i32, ptr %t250, !tbaa !33
  %t254 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t244, i32 %t251)
  store { i64, ptr } %t254, ptr %l143
  br label %bb36
bb36:
  %t255 = load { i64, ptr }, ptr %l131, !tbaa !27
  %t256 = extractvalue { i64, ptr } %t255, 1
  %t257 = extractvalue { i64, ptr } %t255, 0
  %t258 = load { i64, ptr }, ptr %l137, !tbaa !27
  %t259 = extractvalue { i64, ptr } %t258, 1
  %t260 = extractvalue { i64, ptr } %t258, 0
  %t261 = add i64 %t257, %t260
  %t262 = extractvalue { i64, ptr } { i64 1, ptr @.d18 }, 1
  %t263 = extractvalue { i64, ptr } { i64 1, ptr @.d18 }, 0
  %t264 = add i64 %t261, %t263
  %t265 = load { i64, ptr }, ptr %l143, !tbaa !27
  %t266 = extractvalue { i64, ptr } %t265, 1
  %t267 = extractvalue { i64, ptr } %t265, 0
  %t268 = add i64 %t264, %t267
  %t269 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t268)
  call void @olang_textcopy(ptr %t269, ptr %t256, i64 %t257)
  %t270 = getelementptr i8, ptr %t269, i64 %t257
  call void @olang_textcopy(ptr %t270, ptr %t259, i64 %t260)
  %t271 = getelementptr i8, ptr %t270, i64 %t260
  call void @olang_textcopy(ptr %t271, ptr %t262, i64 %t263)
  %t272 = getelementptr i8, ptr %t271, i64 %t263
  call void @olang_textcopy(ptr %t272, ptr %t266, i64 %t267)
  %t273 = insertvalue { i64, ptr } undef, i64 %t268, 0
  %t274 = insertvalue { i64, ptr } %t273, ptr %t269, 1
  %t276 = extractvalue { i64, ptr } %t274, 0
  %t277 = extractvalue { i64, ptr } %t274, 1
  %t278 = mul i64 %t276, 1
  %t279 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t278)
  call void @llvm.memcpy.p0.p0.i64(ptr %t279, ptr %t277, i64 %t278, i1 false)
  %t280 = insertvalue { i64, ptr } undef, i64 %t276, 0
  %t281 = insertvalue { i64, ptr } %t280, ptr %t279, 1
  %t283 = load ptr, ptr %l130, !tbaa !29
  %t286 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2etextData(ptr %v0, ptr %s5, ptr %t283, { i64, ptr } %t281, %"compiler/source:Span" %a2)
  store { i64, [4 x i64] } %t286, ptr %l147
  br label %bb37
bb37:
  %t287 = load ptr, ptr %l129, !tbaa !29
  %t288 = load { i64, [4 x i64] }, ptr %l147
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aOperand_3e_2ePush_3ccompiler_2fmir_3aOperand_3e(ptr %s0, ptr %t287, { i64, [4 x i64] } %t288)
  br label %bb38
bb38:
  call void @__olang_scope_close(ptr %s5)
  br label %bb39
bb39:
  %t289 = load i64, ptr %l21, !tbaa !24
  %t291 = add i64 %t289, 1
  store i64 %t291, ptr %l21, !tbaa !24
  br label %bb29
bb40:
  call void @__olang_scope_close(ptr %s2)
  br label %bb41
bb41:
  %t293 = load i64, ptr %l10, !tbaa !24
  %t295 = add i64 %t293, 1
  store i64 %t295, ptr %l10, !tbaa !24
  br label %bb9
bb42:
  %t297 = load ptr, ptr %l5, !tbaa !29
  %t299 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aOperand_3e_2eToArray_3ccompiler_2fmir_3aOperand_3e(ptr %s0, ptr %v1, ptr %t297)
  store { i64, ptr } %t299, ptr %l153
  br label %bb43
bb43:
  call void @__olang_scope_close(ptr %s0)
  %t300 = load { i64, ptr }, ptr %l153, !tbaa !27
  store { i64, ptr } %t300, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { { i64, [7 x i64] }, i32 } @compiler_2flower_2ecompiler_2flower_3alowering_2ebodyCallee(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l1 = alloca i32
  %l2 = alloca i32
  %l8 = alloca ptr
  %rv = alloca { { i64, [7 x i64] }, i32 }
  %t19 = alloca { i64, [2 x i64] }, align 8
  %t26 = alloca { i64, [7 x i64] }, align 8
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/lower:lowering", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/lower:Lowerer", ptr %t4, i32 0, i32 1
  %t7 = load i32, ptr %l1, !tbaa !23
  %t9 = sext i32 %t7 to i64
  %t12 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t6, i64 %t9)
  store ptr %t12, ptr %l8
  br label %bb1
bb1:
  %t13 = load ptr, ptr %l8, !tbaa !29
  %t15 = getelementptr %"compiler/typed:Body", ptr %t13, i32 0, i32 2
  %t16 = load i32, ptr %t15, !tbaa !23
  store i32 %t16, ptr %l2, !tbaa !23
  %t18 = load i32, ptr %l1, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t19
  %t20 = getelementptr { i64, [2 x i64] }, ptr %t19, i32 0, i32 0
  store i64 0, ptr %t20
  %t22 = insertvalue { i32 } undef, i32 %t18, 0
  %t23 = getelementptr { i64, [2 x i64] }, ptr %t19, i32 0, i32 1
  store { i32 } %t22, ptr %t23
  %t24 = load { i64, [2 x i64] }, ptr %t19
  %t25 = load i32, ptr %l2, !tbaa !23
  store { i64, [7 x i64] } zeroinitializer, ptr %t26
  %t27 = getelementptr { i64, [7 x i64] }, ptr %t26, i32 0, i32 0
  store i64 0, ptr %t27
  %t29 = insertvalue { { i64, [2 x i64] }, i32 } undef, { i64, [2 x i64] } %t24, 0
  %t31 = insertvalue { { i64, [2 x i64] }, i32 } %t29, i32 %t25, 1
  %t32 = getelementptr { i64, [7 x i64] }, ptr %t26, i32 0, i32 1
  store { { i64, [2 x i64] }, i32 } %t31, ptr %t32
  %t33 = load { i64, [7 x i64] }, ptr %t26
  %t34 = load i32, ptr %l2, !tbaa !23
  %t36 = insertvalue { { i64, [7 x i64] }, i32 } undef, { i64, [7 x i64] } %t33, 0
  %t38 = insertvalue { { i64, [7 x i64] }, i32 } %t36, i32 %t34, 1
  store { { i64, [7 x i64] }, i32 } %t38, ptr %rv
  br label %ret
ret:
  %rr = load { { i64, [7 x i64] }, i32 }, ptr %rv
  ret { { i64, [7 x i64] }, i32 } %rr
}

define dso_local { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ebuilt(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l5 = alloca i1
  %l8 = alloca i1
  %l18 = alloca { i64, ptr }
  %l22 = alloca { i64, [1 x i64] }
  %rv = alloca { i64, [1 x i64] }
  %t28 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 19
  %t4 = load i1, ptr %t3, !tbaa !21
  %t6 = xor i1 %t4, true
  br i1 %t6, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l5, !tbaa !21
  br label %bb3
bb2:
  %t8 = load i32, ptr %l1, !tbaa !23
  %t10 = icmp slt i32 %t8, 0
  store i1 %t10, ptr %l5, !tbaa !21
  br label %bb3
bb3:
  %t12 = load i1, ptr %l5, !tbaa !21
  br i1 %t12, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb6
bb5:
  %t13 = load i32, ptr %l1, !tbaa !23
  %t15 = sext i32 %t13 to i64
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/lower:lowering", ptr %t16, i32 0, i32 22
  %t19 = getelementptr %"compiler/typed:Plan", ptr %t18, i32 0, i32 0
  %t20 = load { i64, ptr }, ptr %t19, !tbaa !27
  %t22 = extractvalue { i64, ptr } %t20, 0
  %t25 = icmp sge i64 %t15, %t22
  store i1 %t25, ptr %l8, !tbaa !21
  br label %bb6
bb6:
  %t27 = load i1, ptr %l8, !tbaa !21
  br i1 %t27, label %bb7, label %bb8
bb7:
  store { i64, [1 x i64] } zeroinitializer, ptr %t28
  %t29 = getelementptr { i64, [1 x i64] }, ptr %t28, i32 0, i32 0
  store i64 2, ptr %t29
  %t30 = load { i64, [1 x i64] }, ptr %t28
  store { i64, [1 x i64] } %t30, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/lower:lowering", ptr %t33, i32 0, i32 22
  %t36 = getelementptr %"compiler/typed:Plan", ptr %t35, i32 0, i32 0
  %t37 = load { i64, ptr }, ptr %t36, !tbaa !27
  store { i64, ptr } %t37, ptr %l18, !tbaa !27
  %t38 = load i32, ptr %l1, !tbaa !23
  %t40 = sext i32 %t38 to i64
  %t42 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = getelementptr { i64, [1 x i64] }, ptr %t43, i64 %t40
  %t45 = load { i64, [1 x i64] }, ptr %t44
  %t48 = call { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2escopeRef(ptr %v0, ptr %t32, { i64, [1 x i64] } %t45)
  store { i64, [1 x i64] } %t48, ptr %l22
  br label %bb10
bb10:
  %t49 = load { i64, [1 x i64] }, ptr %l22
  store { i64, [1 x i64] } %t49, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [1 x i64] }, ptr %rv
  ret { i64, [1 x i64] } %rr
}

define dso_local { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ecall(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca ptr
  %l5 = alloca { { i64, [7 x i64] }, i32 }
  %l6 = alloca { i64, [7 x i64] }
  %l7 = alloca i32
  %l8 = alloca %"compiler/mir:Range"
  %l9 = alloca i64
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca %"compiler/mir:Range"
  %l13 = alloca i32
  %l14 = alloca i32
  %l15 = alloca i32
  %l16 = alloca i32
  %l17 = alloca i32
  %l23 = alloca i1
  %l31 = alloca { i64, [4 x i64] }
  %l36 = alloca { { i64, [7 x i64] }, i32 }
  %l46 = alloca %"compiler/mir:Range"
  %l58 = alloca { i64, [4 x i64] }
  %l64 = alloca i32
  %l65 = alloca ptr
  %l69 = alloca i64
  %l72 = alloca %"compiler/mir:Range"
  %l75 = alloca i32
  %l80 = alloca i1
  %l84 = alloca ptr
  %l88 = alloca i32
  %l92 = alloca i32
  %l95 = alloca i32
  %l100 = alloca { i64, ptr }
  %l106 = alloca i32
  %l109 = alloca i32
  %l111 = alloca ptr
  %l112 = alloca { i64, [7 x i64] }
  %l113 = alloca %"compiler/mir:Range"
  %l114 = alloca %"compiler/mir:Range"
  %l118 = alloca %"compiler/mir:Place"
  %l120 = alloca %"compiler/mir:Place"
  %l128 = alloca %"compiler/mir:Call"
  %l129 = alloca i32
  %l139 = alloca ptr
  %l141 = alloca %"compiler/mir:Place"
  %l161 = alloca %"compiler/mir:Place"
  %s0 = alloca %olang.scope
  %rv = alloca { i64, [4 x i64] }
  %t51 = alloca { i64, [4 x i64] }, align 8
  %t70 = alloca { i64, [4 x i64] }, align 8
  %t100 = alloca { i64, [7 x i64] }, align 8
  %t248 = alloca { i64, [7 x i64] }, align 8
  %t272 = alloca { i64, [4 x i64] }, align 8
  %t296 = alloca { i64, [4 x i64] }, align 8
  %t299 = alloca { i64, [7 x i64] }, align 8
  %t311 = alloca { i64, [4 x i64] }, align 8
  %t321 = alloca { i64, [4 x i64] }, align 8
  %t328 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  store %"compiler/source:Span" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t6 = load ptr, ptr %l1, !tbaa !29
  %t8 = getelementptr %"compiler/typed:Call", ptr %t6, i32 0, i32 4
  %t9 = load i1, ptr %t8, !tbaa !21
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = load ptr, ptr %l1, !tbaa !29
  %t13 = getelementptr %"compiler/typed:Call", ptr %t11, i32 0, i32 1
  %t14 = load { i64, ptr }, ptr %t13, !tbaa !27
  %t16 = extractvalue { i64, ptr } %t14, 0
  %t18 = icmp eq i64 %t16, 0
  store i1 %t18, ptr %l23, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l23, !tbaa !21
  br label %bb3
bb3:
  %t20 = load i1, ptr %l23, !tbaa !21
  br i1 %t20, label %bb4, label %bb5
bb4:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load i32, ptr %l2, !tbaa !23
  %t23 = load %"compiler/source:Span", ptr %l3
  %t27 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ezero(ptr %v0, ptr %t21, i32 %t22, %"compiler/source:Span" %t23)
  store { i64, [4 x i64] } %t27, ptr %l31
  br label %bb6
bb5:
  br label %bb7
bb6:
  call void @__olang_scope_close(ptr %s0)
  %t28 = load { i64, [4 x i64] }, ptr %l31
  store { i64, [4 x i64] } %t28, ptr %rv
  br label %ret
bb7:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t30 = load ptr, ptr %l1, !tbaa !29
  %t32 = getelementptr %"compiler/typed:Call", ptr %t30, i32 0, i32 0
  %t33 = load ptr, ptr %t32, !tbaa !29
  %t34 = load %"compiler/source:Span", ptr %l3
  %t38 = call { { i64, [7 x i64] }, i32 } @compiler_2flower_2ecompiler_2flower_3alowering_2ecallee(ptr %v0, ptr %v1, ptr %t29, ptr %t33, %"compiler/source:Span" %t34)
  store { { i64, [7 x i64] }, i32 } %t38, ptr %l36
  br label %bb8
bb8:
  %t39 = load { { i64, [7 x i64] }, i32 }, ptr %l36
  store { { i64, [7 x i64] }, i32 } %t39, ptr %l5
  %t40 = getelementptr { { i64, [7 x i64] }, i32 }, ptr %l5, i32 0, i32 0
  %t41 = load { i64, [7 x i64] }, ptr %t40
  store { i64, [7 x i64] } %t41, ptr %l6
  %t43 = getelementptr { { i64, [7 x i64] }, i32 }, ptr %l5, i32 0, i32 1
  %t44 = load i32, ptr %t43, !tbaa !23
  store i32 %t44, ptr %l7, !tbaa !23
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/lower:lowering", ptr %t46, i32 0, i32 7
  %t49 = load i1, ptr %t48, !tbaa !21
  br i1 %t49, label %bb9, label %bb10
bb9:
  store { i64, [4 x i64] } zeroinitializer, ptr %t51
  %t52 = getelementptr { i64, [4 x i64] }, ptr %t51, i32 0, i32 0
  store i64 0, ptr %t52
  %t53 = load { i64, [4 x i64] }, ptr %t51
  call void @__olang_scope_close(ptr %s0)
  store { i64, [4 x i64] } %t53, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t56 = load ptr, ptr %l1, !tbaa !29
  %t57 = load { i64, [7 x i64] }, ptr %l6
  %t58 = load i32, ptr %l7, !tbaa !23
  %t63 = call %"compiler/mir:Range" @compiler_2flower_2ecompiler_2flower_3alowering_2eargs(ptr %v0, ptr %v1, ptr %t55, ptr %t56, { i64, [7 x i64] } %t57, i32 %t58)
  store %"compiler/mir:Range" %t63, ptr %l46
  br label %bb12
bb12:
  %t64 = load %"compiler/mir:Range", ptr %l46
  store %"compiler/mir:Range" %t64, ptr %l8
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/lower:lowering", ptr %t65, i32 0, i32 7
  %t68 = load i1, ptr %t67, !tbaa !21
  br i1 %t68, label %bb13, label %bb14
bb13:
  store { i64, [4 x i64] } zeroinitializer, ptr %t70
  %t71 = getelementptr { i64, [4 x i64] }, ptr %t70, i32 0, i32 0
  store i64 0, ptr %t71
  %t72 = load { i64, [4 x i64] }, ptr %t70
  call void @__olang_scope_close(ptr %s0)
  store { i64, [4 x i64] } %t72, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  %t74 = load { i64, [7 x i64] }, ptr %l6
  %t76 = extractvalue { i64, [7 x i64] } %t74, 0
  %t77 = icmp eq i64 %t76, 3
  br i1 %t77, label %bb16, label %bb17
bb16:
  %t79 = getelementptr { i64, [7 x i64] }, ptr %l6, i32 0, i32 1
  %t80 = getelementptr { { i64, [4 x i64] }, i64, i32 }, ptr %t79, i32 0, i32 1
  %t81 = load i64, ptr %t80
  store i64 %t81, ptr %l9, !tbaa !24
  %t83 = getelementptr { i64, [7 x i64] }, ptr %l6, i32 0, i32 1
  %t84 = getelementptr { { i64, [4 x i64] }, i64, i32 }, ptr %t83, i32 0, i32 2
  %t85 = load i32, ptr %t84
  store i32 %t85, ptr %l10, !tbaa !23
  br label %bb18
bb17:
  br label %bb20
bb18:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr %"compiler/lower:lowering", ptr %t87, i32 0, i32 3
  %t90 = getelementptr %"compiler/mir:Fn", ptr %t89, i32 0, i32 11
  %t91 = getelementptr %"compiler/mir:Range", ptr %l8, i32 0, i32 0
  %t92 = load i32, ptr %t91, !tbaa !23
  %t94 = sext i32 %t92 to i64
  %t97 = call { i64, [4 x i64] } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aOperand_3e_2eAt_3ccompiler_2fmir_3aOperand_3e(ptr %v0, ptr %t90, i64 %t94)
  store { i64, [4 x i64] } %t97, ptr %l58
  br label %bb19
bb19:
  %t98 = load i64, ptr %l9, !tbaa !24
  %t99 = load i32, ptr %l10, !tbaa !23
  store { i64, [7 x i64] } zeroinitializer, ptr %t100
  %t101 = getelementptr { i64, [7 x i64] }, ptr %t100, i32 0, i32 0
  store i64 3, ptr %t101
  %t102 = load { i64, [4 x i64] }, ptr %l58
  %t103 = insertvalue { { i64, [4 x i64] }, i64, i32 } undef, { i64, [4 x i64] } %t102, 0
  %t105 = insertvalue { { i64, [4 x i64] }, i64, i32 } %t103, i64 %t98, 1
  %t107 = insertvalue { { i64, [4 x i64] }, i64, i32 } %t105, i32 %t99, 2
  %t108 = getelementptr { i64, [7 x i64] }, ptr %t100, i32 0, i32 1
  store { { i64, [4 x i64] }, i64, i32 } %t107, ptr %t108
  %t109 = load { i64, [7 x i64] }, ptr %t100
  store { i64, [7 x i64] } %t109, ptr %l6
  br label %bb25
bb20:
  br i1 true, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb25
bb24:
  call void @__olang_check_failed(ptr @olang_loc_b0754b7649fd7859_91d9947d7b887e0d)
  unreachable
bb25:
  %t111 = load ptr, ptr %l4, !tbaa !29
  %t112 = load i32, ptr %l7, !tbaa !23
  %t115 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t111, i32 %t112)
  store i32 %t115, ptr %l64
  br label %bb26
bb26:
  %t116 = load i32, ptr %l64, !tbaa !23
  store i32 %t116, ptr %l11, !tbaa !23
  %t117 = load ptr, ptr %l0, !tbaa !29
  store ptr %t117, ptr %l65, !tbaa !29
  %t118 = load ptr, ptr %l4, !tbaa !29
  %t119 = load { i64, [7 x i64] }, ptr %l6
  %t120 = load i32, ptr %l7, !tbaa !23
  %t124 = call i64 @compiler_2fmir_2ePassedCount(ptr %v0, ptr %t118, { i64, [7 x i64] } %t119, i32 %t120)
  store i64 %t124, ptr %l69
  br label %bb27
bb27:
  %t125 = load ptr, ptr %l1, !tbaa !29
  %t127 = getelementptr %"compiler/typed:Call", ptr %t125, i32 0, i32 3
  %t128 = load i32, ptr %t127, !tbaa !23
  %t129 = load ptr, ptr %l65, !tbaa !29
  %t130 = load i64, ptr %l69, !tbaa !24
  %t132 = call %"compiler/mir:Range" @compiler_2flower_2ecompiler_2flower_3alowering_2epassed(ptr %v0, ptr %t129, i64 %t130, i32 %t128)
  store %"compiler/mir:Range" %t132, ptr %l72
  br label %bb28
bb28:
  %t133 = load %"compiler/mir:Range", ptr %l72
  store %"compiler/mir:Range" %t133, ptr %l12
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t136 = getelementptr %"compiler/lower:lowering", ptr %t134, i32 0, i32 3
  %t138 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t136)
  store i32 %t138, ptr %l75
  br label %bb29
bb29:
  %t139 = load i32, ptr %l75, !tbaa !23
  store i32 %t139, ptr %l13, !tbaa !23
  %t140 = load i32, ptr @G_2ecompiler_2fmir_2eNoLocal, !tbaa !23
  store i32 %t140, ptr %l14, !tbaa !23
  %t142 = load i32, ptr %l11, !tbaa !23
  %t143 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t146 = icmp ne i32 %t142, %t143
  br i1 %t146, label %bb30, label %bb31
bb30:
  %t148 = load i32, ptr %l11, !tbaa !23
  %t149 = load i32, ptr @G_2ecompiler_2ftypes_2eNoreturnT, !tbaa !23
  %t152 = icmp ne i32 %t148, %t149
  store i1 %t152, ptr %l80, !tbaa !21
  br label %bb32
bb31:
  store i1 false, ptr %l80, !tbaa !21
  br label %bb32
bb32:
  %t154 = load i1, ptr %l80, !tbaa !21
  br i1 %t154, label %bb33, label %bb34
bb33:
  %t155 = load ptr, ptr %l0, !tbaa !29
  store ptr %t155, ptr %l84, !tbaa !29
  %t156 = load i32, ptr %l2, !tbaa !23
  %t157 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t160 = icmp ne i32 %t156, %t157
  br i1 %t160, label %bb35, label %bb36
bb34:
  br label %bb39
bb35:
  %t162 = load i32, ptr %l2, !tbaa !23
  store i32 %t162, ptr %l88, !tbaa !23
  br label %bb37
bb36:
  %t164 = load i32, ptr %l11, !tbaa !23
  store i32 %t164, ptr %l88, !tbaa !23
  br label %bb37
bb37:
  %t166 = load %"compiler/source:Span", ptr %l3
  %t167 = load ptr, ptr %l84, !tbaa !29
  %t168 = load i32, ptr %l88, !tbaa !23
  %t170 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2etemp(ptr %v0, ptr %t167, i32 %t168, %"compiler/source:Span" %t166)
  store i32 %t170, ptr %l92
  br label %bb38
bb38:
  %t171 = load i32, ptr %l92, !tbaa !23
  store i32 %t171, ptr %l14, !tbaa !23
  br label %bb39
bb39:
  %t172 = load ptr, ptr %l4, !tbaa !29
  %t173 = load i32, ptr %l7, !tbaa !23
  %t176 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t172, i32 %t173)
  store i32 %t176, ptr %l95
  br label %bb40
bb40:
  %t177 = load i32, ptr %l95, !tbaa !23
  store i32 %t177, ptr %l15, !tbaa !23
  %t178 = load i32, ptr @G_2ecompiler_2fmir_2eNoLocal, !tbaa !23
  store i32 %t178, ptr %l16, !tbaa !23
  %t180 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  store i32 %t180, ptr %l17, !tbaa !23
  %t182 = load ptr, ptr %l4, !tbaa !29
  %t183 = load i32, ptr %l15, !tbaa !23
  %t186 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t182, i32 %t183)
  store { i64, ptr } %t186, ptr %l100
  br label %bb41
bb41:
  %t187 = load { i64, ptr }, ptr %l100, !tbaa !27
  %t188 = extractvalue { i64, ptr } %t187, 0
  %t190 = icmp sgt i64 %t188, 0
  br i1 %t190, label %bb42, label %bb43
bb42:
  %t192 = load ptr, ptr %l0, !tbaa !29
  %t193 = load i32, ptr @G_2ecompiler_2fmir_2eI32T, !tbaa !23
  %t194 = load %"compiler/source:Span", ptr %l3
  %t198 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2etemp(ptr %v0, ptr %t192, i32 %t193, %"compiler/source:Span" %t194)
  store i32 %t198, ptr %l106
  br label %bb44
bb43:
  br label %bb46
bb44:
  %t199 = load i32, ptr %l106, !tbaa !23
  store i32 %t199, ptr %l16, !tbaa !23
  %t200 = load ptr, ptr %l0, !tbaa !29
  %t202 = getelementptr %"compiler/lower:lowering", ptr %t200, i32 0, i32 3
  %t204 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t202)
  store i32 %t204, ptr %l109
  br label %bb45
bb45:
  %t205 = load i32, ptr %l109, !tbaa !23
  store i32 %t205, ptr %l17, !tbaa !23
  br label %bb46
bb46:
  %t206 = load ptr, ptr %l0, !tbaa !29
  %t208 = getelementptr %"compiler/lower:lowering", ptr %t206, i32 0, i32 3
  store ptr %t208, ptr %l111, !tbaa !29
  %t209 = load { i64, [7 x i64] }, ptr %l6
  store { i64, [7 x i64] } %t209, ptr %l112
  %t210 = load %"compiler/mir:Range", ptr %l8
  store %"compiler/mir:Range" %t210, ptr %l113
  %t211 = load %"compiler/mir:Range", ptr %l12
  store %"compiler/mir:Range" %t211, ptr %l114
  %t212 = load i32, ptr %l14, !tbaa !23
  %t213 = load i32, ptr @G_2ecompiler_2fmir_2eNoLocal, !tbaa !23
  %t216 = icmp ne i32 %t212, %t213
  br i1 %t216, label %bb47, label %bb48
bb47:
  %t218 = load i32, ptr %l14, !tbaa !23
  %t220 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t218)
  store %"compiler/mir:Place" %t220, ptr %l120
  br label %bb49
bb48:
  %t221 = load %"compiler/mir:Place", ptr @G_2ecompiler_2fmir_2eNoPlace
  store %"compiler/mir:Place" %t221, ptr %l118
  br label %bb50
bb49:
  %t223 = load %"compiler/mir:Place", ptr %l120
  store %"compiler/mir:Place" %t223, ptr %l118
  br label %bb50
bb50:
  %t224 = load i32, ptr %l14, !tbaa !23
  %t225 = load i32, ptr @G_2ecompiler_2fmir_2eNoLocal, !tbaa !23
  %t228 = icmp ne i32 %t224, %t225
  %t229 = load i32, ptr %l13, !tbaa !23
  %t230 = load i32, ptr %l16, !tbaa !23
  %t231 = load i32, ptr %l17, !tbaa !23
  %t232 = load { i64, [7 x i64] }, ptr %l112
  %t233 = load %"compiler/mir:Range", ptr %l113
  %t234 = load %"compiler/mir:Range", ptr %l114
  %t235 = load %"compiler/mir:Place", ptr %l118
  %t240 = call %"compiler/mir:Call" @compiler_2fmir_3aCall_2ector(ptr %s0, { i64, [7 x i64] } %t232, %"compiler/mir:Range" %t233, %"compiler/mir:Range" %t234, %"compiler/mir:Place" %t235, i1 %t228, i32 %t229, i32 %t230, i32 %t231)
  store %"compiler/mir:Call" %t240, ptr %l128
  br label %bb51
bb51:
  %t241 = load ptr, ptr %l111, !tbaa !29
  %t242 = load %"compiler/mir:Call", ptr %l128
  %t243 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddCall(ptr %v0, ptr %t241, %"compiler/mir:Call" %t242)
  store i32 %t243, ptr %l129
  br label %bb52
bb52:
  %t244 = load i32, ptr %l129, !tbaa !23
  %t245 = load ptr, ptr %l0, !tbaa !29
  %t246 = load %"compiler/source:Span", ptr %l3
  store { i64, [7 x i64] } zeroinitializer, ptr %t248
  %t249 = getelementptr { i64, [7 x i64] }, ptr %t248, i32 0, i32 0
  store i64 4, ptr %t249
  %t251 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t246, 0
  %t253 = insertvalue { %"compiler/source:Span", i32 } %t251, i32 %t244, 1
  %t254 = getelementptr { i64, [7 x i64] }, ptr %t248, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t253, ptr %t254
  %t255 = load { i64, [7 x i64] }, ptr %t248
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t245, { i64, [7 x i64] } %t255)
  br label %bb53
bb53:
  %t258 = load i32, ptr %l17, !tbaa !23
  %t259 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t262 = icmp ne i32 %t258, %t259
  br i1 %t262, label %bb54, label %bb55
bb54:
  %t264 = load ptr, ptr %l0, !tbaa !29
  %t265 = load i32, ptr %l17, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t264, i32 %t265)
  br label %bb56
bb55:
  br label %bb59
bb56:
  %t268 = load ptr, ptr %l0, !tbaa !29
  store ptr %t268, ptr %l139, !tbaa !29
  %t269 = load i32, ptr %l16, !tbaa !23
  %t271 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t269)
  store %"compiler/mir:Place" %t271, ptr %l141
  br label %bb57
bb57:
  store { i64, [4 x i64] } zeroinitializer, ptr %t272
  %t273 = getelementptr { i64, [4 x i64] }, ptr %t272, i32 0, i32 0
  store i64 1, ptr %t273
  %t274 = load %"compiler/mir:Place", ptr %l141
  %t275 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t274, 0
  %t276 = getelementptr { i64, [4 x i64] }, ptr %t272, i32 0, i32 1
  store { %"compiler/mir:Place" } %t275, ptr %t276
  %t277 = load { i64, [4 x i64] }, ptr %t272
  %t278 = load i32, ptr %l15, !tbaa !23
  %t279 = load %"compiler/source:Span", ptr %l3
  %t280 = load ptr, ptr %l139, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2edispatch(ptr %v0, ptr %t280, { i64, [4 x i64] } %t277, i32 %t278, %"compiler/source:Span" %t279, i1 false)
  br label %bb58
bb58:
  br label %bb59
bb59:
  %t284 = load ptr, ptr %l0, !tbaa !29
  %t285 = load i32, ptr %l13, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t284, i32 %t285)
  br label %bb60
bb60:
  %t288 = load i32, ptr %l11, !tbaa !23
  %t289 = load i32, ptr @G_2ecompiler_2ftypes_2eNoreturnT, !tbaa !23
  %t292 = icmp eq i32 %t288, %t289
  br i1 %t292, label %bb61, label %bb62
bb61:
  %t294 = load ptr, ptr %l0, !tbaa !29
  %t295 = load %"compiler/source:Span", ptr %l3
  store { i64, [4 x i64] } zeroinitializer, ptr %t296
  %t297 = getelementptr { i64, [4 x i64] }, ptr %t296, i32 0, i32 0
  store i64 0, ptr %t297
  %t298 = load { i64, [4 x i64] }, ptr %t296
  store { i64, [7 x i64] } zeroinitializer, ptr %t299
  %t300 = getelementptr { i64, [7 x i64] }, ptr %t299, i32 0, i32 0
  store i64 8, ptr %t300
  %t302 = insertvalue { %"compiler/source:Span", i32, { i64, [4 x i64] } } undef, %"compiler/source:Span" %t295, 0
  %t304 = insertvalue { %"compiler/source:Span", i32, { i64, [4 x i64] } } %t302, i32 3, 1
  %t306 = insertvalue { %"compiler/source:Span", i32, { i64, [4 x i64] } } %t304, { i64, [4 x i64] } %t298, 2
  %t307 = getelementptr { i64, [7 x i64] }, ptr %t299, i32 0, i32 1
  store { %"compiler/source:Span", i32, { i64, [4 x i64] } } %t306, ptr %t307
  %t308 = load { i64, [7 x i64] }, ptr %t299
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t294, { i64, [7 x i64] } %t308)
  br label %bb63
bb62:
  br label %bb64
bb63:
  store { i64, [4 x i64] } zeroinitializer, ptr %t311
  %t312 = getelementptr { i64, [4 x i64] }, ptr %t311, i32 0, i32 0
  store i64 0, ptr %t312
  %t313 = load { i64, [4 x i64] }, ptr %t311
  call void @__olang_scope_close(ptr %s0)
  store { i64, [4 x i64] } %t313, ptr %rv
  br label %ret
bb64:
  %t315 = load i32, ptr %l14, !tbaa !23
  %t316 = load i32, ptr @G_2ecompiler_2fmir_2eNoLocal, !tbaa !23
  %t319 = icmp eq i32 %t315, %t316
  br i1 %t319, label %bb65, label %bb66
bb65:
  store { i64, [4 x i64] } zeroinitializer, ptr %t321
  %t322 = getelementptr { i64, [4 x i64] }, ptr %t321, i32 0, i32 0
  store i64 0, ptr %t322
  %t323 = load { i64, [4 x i64] }, ptr %t321
  call void @__olang_scope_close(ptr %s0)
  store { i64, [4 x i64] } %t323, ptr %rv
  br label %ret
bb66:
  br label %bb67
bb67:
  %t325 = load i32, ptr %l14, !tbaa !23
  %t327 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t325)
  store %"compiler/mir:Place" %t327, ptr %l161
  br label %bb68
bb68:
  store { i64, [4 x i64] } zeroinitializer, ptr %t328
  %t329 = getelementptr { i64, [4 x i64] }, ptr %t328, i32 0, i32 0
  store i64 1, ptr %t329
  %t330 = load %"compiler/mir:Place", ptr %l161
  %t331 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t330, 0
  %t332 = getelementptr { i64, [4 x i64] }, ptr %t328, i32 0, i32 1
  store { %"compiler/mir:Place" } %t331, ptr %t332
  %t333 = load { i64, [4 x i64] }, ptr %t328
  call void @__olang_scope_close(ptr %s0)
  store { i64, [4 x i64] } %t333, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local { { i64, [7 x i64] }, i32 } @compiler_2flower_2ecompiler_2flower_3alowering_2ecallee(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca i32
  %l6 = alloca ptr
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca i64
  %l10 = alloca i32
  %l11 = alloca ptr
  %l12 = alloca i1
  %l19 = alloca { { i64, [7 x i64] }, i32 }
  %l20 = alloca ptr
  %l21 = alloca i1
  %l30 = alloca i32
  %l36 = alloca ptr
  %l37 = alloca i1
  %l44 = alloca { { i64, [7 x i64] }, i32 }
  %l45 = alloca ptr
  %l46 = alloca i1
  %l56 = alloca { { i64, [7 x i64] }, i32 }
  %l57 = alloca ptr
  %l58 = alloca i1
  %rv = alloca { { i64, [7 x i64] }, i32 }
  %t51 = alloca { i64, [7 x i64] }, align 8
  %t136 = alloca { i64, [4 x i64] }, align 8
  %t141 = alloca { i64, [7 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l11, !tbaa !29
  store i1 false, ptr %l12, !tbaa !21
  %t2 = load ptr, ptr %l11, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l11, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l12, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l12, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [3 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { i32 }, ptr %t12, i32 0, i32 0
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l3, !tbaa !23
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load i32, ptr %l3, !tbaa !23
  %t20 = call { { i64, [7 x i64] }, i32 } @compiler_2flower_2ecompiler_2flower_3alowering_2ebodyCallee(ptr %v0, ptr %t16, i32 %t17)
  store { { i64, [7 x i64] }, i32 } %t20, ptr %l19
  br label %bb6
bb6:
  %t21 = load { { i64, [7 x i64] }, i32 }, ptr %l19
  store { { i64, [7 x i64] }, i32 } %t21, ptr %rv
  br label %ret
bb7:
  %t22 = load ptr, ptr %l1, !tbaa !29
  store ptr %t22, ptr %l20, !tbaa !29
  store i1 false, ptr %l21, !tbaa !21
  %t23 = load ptr, ptr %l20, !tbaa !29
  %t24 = icmp ne ptr %t23, null
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t26 = load ptr, ptr %l20, !tbaa !29
  %t27 = load i64, ptr %t26
  %t29 = icmp eq i64 %t27, 1
  store i1 %t29, ptr %l21, !tbaa !21
  br label %bb9
bb9:
  %t30 = load i1, ptr %l21, !tbaa !21
  br i1 %t30, label %bb10, label %bb11
bb10:
  %t31 = load ptr, ptr %l1, !tbaa !29
  %t33 = getelementptr { i64, [3 x i64] }, ptr %t31, i32 0, i32 1
  %t34 = getelementptr { i64 }, ptr %t33, i32 0, i32 0
  %t35 = load i64, ptr %t34
  store i64 %t35, ptr %l4, !tbaa !24
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/lower:lowering", ptr %t37, i32 0, i32 0
  %t40 = load ptr, ptr %t39, !tbaa !29
  %t42 = getelementptr %"compiler/lower:Lowerer", ptr %t40, i32 0, i32 0
  %t43 = load ptr, ptr %t42, !tbaa !29
  %t44 = load i64, ptr %l4, !tbaa !24
  %t47 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t43, i64 %t44)
  store i32 %t47, ptr %l30
  br label %bb13
bb13:
  %t48 = load i32, ptr %l30, !tbaa !23
  store i32 %t48, ptr %l5, !tbaa !23
  %t49 = load i64, ptr %l4, !tbaa !24
  %t50 = load i32, ptr %l5, !tbaa !23
  store { i64, [7 x i64] } zeroinitializer, ptr %t51
  %t52 = getelementptr { i64, [7 x i64] }, ptr %t51, i32 0, i32 0
  store i64 1, ptr %t52
  %t54 = insertvalue { i64, i32 } undef, i64 %t49, 0
  %t56 = insertvalue { i64, i32 } %t54, i32 %t50, 1
  %t57 = getelementptr { i64, [7 x i64] }, ptr %t51, i32 0, i32 1
  store { i64, i32 } %t56, ptr %t57
  %t58 = load { i64, [7 x i64] }, ptr %t51
  %t59 = load i32, ptr %l5, !tbaa !23
  %t61 = insertvalue { { i64, [7 x i64] }, i32 } undef, { i64, [7 x i64] } %t58, 0
  %t63 = insertvalue { { i64, [7 x i64] }, i32 } %t61, i32 %t59, 1
  store { { i64, [7 x i64] }, i32 } %t63, ptr %rv
  br label %ret
bb14:
  %t65 = load ptr, ptr %l1, !tbaa !29
  store ptr %t65, ptr %l36, !tbaa !29
  store i1 false, ptr %l37, !tbaa !21
  %t66 = load ptr, ptr %l36, !tbaa !29
  %t67 = icmp ne ptr %t66, null
  br i1 %t67, label %bb15, label %bb16
bb15:
  %t69 = load ptr, ptr %l36, !tbaa !29
  %t70 = load i64, ptr %t69
  %t72 = icmp eq i64 %t70, 2
  store i1 %t72, ptr %l37, !tbaa !21
  br label %bb16
bb16:
  %t73 = load i1, ptr %l37, !tbaa !21
  br i1 %t73, label %bb17, label %bb18
bb17:
  %t74 = load ptr, ptr %l1, !tbaa !29
  %t76 = getelementptr { i64, [3 x i64] }, ptr %t74, i32 0, i32 1
  %t77 = getelementptr { ptr }, ptr %t76, i32 0, i32 0
  %t78 = load ptr, ptr %t77
  store ptr %t78, ptr %l6, !tbaa !29
  br label %bb19
bb18:
  br label %bb21
bb19:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t81 = load ptr, ptr %l6, !tbaa !29
  %t84 = call { { i64, [7 x i64] }, i32 } @compiler_2flower_2ecompiler_2flower_3alowering_2evalueCallee(ptr %v0, ptr %v1, ptr %t80, ptr %t81)
  store { { i64, [7 x i64] }, i32 } %t84, ptr %l44
  br label %bb20
bb20:
  %t85 = load { { i64, [7 x i64] }, i32 }, ptr %l44
  store { { i64, [7 x i64] }, i32 } %t85, ptr %rv
  br label %ret
bb21:
  %t86 = load ptr, ptr %l1, !tbaa !29
  store ptr %t86, ptr %l45, !tbaa !29
  store i1 false, ptr %l46, !tbaa !21
  %t87 = load ptr, ptr %l45, !tbaa !29
  %t88 = icmp ne ptr %t87, null
  br i1 %t88, label %bb22, label %bb23
bb22:
  %t90 = load ptr, ptr %l45, !tbaa !29
  %t91 = load i64, ptr %t90
  %t93 = icmp eq i64 %t91, 4
  store i1 %t93, ptr %l46, !tbaa !21
  br label %bb23
bb23:
  %t94 = load i1, ptr %l46, !tbaa !21
  br i1 %t94, label %bb24, label %bb25
bb24:
  %t95 = load ptr, ptr %l1, !tbaa !29
  %t97 = getelementptr { i64, [3 x i64] }, ptr %t95, i32 0, i32 1
  %t98 = getelementptr { i32, i32 }, ptr %t97, i32 0, i32 0
  %t99 = load i32, ptr %t98
  store i32 %t99, ptr %l7
  %t101 = load ptr, ptr %l1, !tbaa !29
  %t103 = getelementptr { i64, [3 x i64] }, ptr %t101, i32 0, i32 1
  %t104 = getelementptr { i32, i32 }, ptr %t103, i32 0, i32 1
  %t105 = load i32, ptr %t104
  store i32 %t105, ptr %l8, !tbaa !23
  br label %bb26
bb25:
  br label %bb28
bb26:
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t108 = load i32, ptr %l7
  %t109 = load i32, ptr %l8, !tbaa !23
  %t113 = call { { i64, [7 x i64] }, i32 } @compiler_2flower_2ecompiler_2flower_3alowering_2ehelperCallee(ptr %v0, ptr %t107, i32 %t108, i32 %t109)
  store { { i64, [7 x i64] }, i32 } %t113, ptr %l56
  br label %bb27
bb27:
  %t114 = load { { i64, [7 x i64] }, i32 }, ptr %l56
  store { { i64, [7 x i64] }, i32 } %t114, ptr %rv
  br label %ret
bb28:
  %t115 = load ptr, ptr %l1, !tbaa !29
  store ptr %t115, ptr %l57, !tbaa !29
  store i1 false, ptr %l58, !tbaa !21
  %t116 = load ptr, ptr %l57, !tbaa !29
  %t117 = icmp ne ptr %t116, null
  br i1 %t117, label %bb29, label %bb30
bb29:
  %t119 = load ptr, ptr %l57, !tbaa !29
  %t120 = load i64, ptr %t119
  %t122 = icmp eq i64 %t120, 3
  store i1 %t122, ptr %l58, !tbaa !21
  br label %bb30
bb30:
  %t123 = load i1, ptr %l58, !tbaa !21
  br i1 %t123, label %bb31, label %bb32
bb31:
  %t124 = load ptr, ptr %l1, !tbaa !29
  %t126 = getelementptr { i64, [3 x i64] }, ptr %t124, i32 0, i32 1
  %t127 = getelementptr { i32, i64, i32 }, ptr %t126, i32 0, i32 1
  %t128 = load i64, ptr %t127
  store i64 %t128, ptr %l9, !tbaa !24
  %t130 = load ptr, ptr %l1, !tbaa !29
  %t132 = getelementptr { i64, [3 x i64] }, ptr %t130, i32 0, i32 1
  %t133 = getelementptr { i32, i64, i32 }, ptr %t132, i32 0, i32 2
  %t134 = load i32, ptr %t133
  store i32 %t134, ptr %l10, !tbaa !23
  br label %bb33
bb32:
  br label %bb34
bb33:
  store { i64, [4 x i64] } zeroinitializer, ptr %t136
  %t137 = getelementptr { i64, [4 x i64] }, ptr %t136, i32 0, i32 0
  store i64 0, ptr %t137
  %t138 = load { i64, [4 x i64] }, ptr %t136
  %t139 = load i64, ptr %l9, !tbaa !24
  %t140 = load i32, ptr %l10, !tbaa !23
  store { i64, [7 x i64] } zeroinitializer, ptr %t141
  %t142 = getelementptr { i64, [7 x i64] }, ptr %t141, i32 0, i32 0
  store i64 3, ptr %t142
  %t144 = insertvalue { { i64, [4 x i64] }, i64, i32 } undef, { i64, [4 x i64] } %t138, 0
  %t146 = insertvalue { { i64, [4 x i64] }, i64, i32 } %t144, i64 %t139, 1
  %t148 = insertvalue { { i64, [4 x i64] }, i64, i32 } %t146, i32 %t140, 2
  %t149 = getelementptr { i64, [7 x i64] }, ptr %t141, i32 0, i32 1
  store { { i64, [4 x i64] }, i64, i32 } %t148, ptr %t149
  %t150 = load { i64, [7 x i64] }, ptr %t141
  %t151 = load i32, ptr %l10, !tbaa !23
  %t153 = insertvalue { { i64, [7 x i64] }, i32 } undef, { i64, [7 x i64] } %t150, 0
  %t155 = insertvalue { { i64, [7 x i64] }, i32 } %t153, i32 %t151, 1
  store { { i64, [7 x i64] }, i32 } %t155, ptr %rv
  br label %ret
bb34:
  call void @__olang_check_failed(ptr @olang_loc_21e9da82ebd620c7_b6074e807b9f75fb)
  unreachable
ret:
  %rr = load { { i64, [7 x i64] }, i32 }, ptr %rv
  ret { { i64, [7 x i64] }, i32 } %rr
}

define dso_local { { i64, ptr }, i1 } @compiler_2flower_2ecompiler_2flower_3alowering_2ecasesOf(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l8 = alloca i32
  %l11 = alloca i32
  %l14 = alloca ptr
  %l17 = alloca i32
  %l18 = alloca { i64, ptr }
  %l22 = alloca i32
  %l25 = alloca i1
  %l26 = alloca ptr
  %l29 = alloca i32
  %l30 = alloca i32
  %l33 = alloca i1
  %l36 = alloca i1
  %l37 = alloca ptr
  %l40 = alloca i32
  %l41 = alloca { i64, ptr }
  %rv = alloca { { i64, ptr }, i1 }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t6, i32 %a1)
  store i32 %t10, ptr %l8
  br label %bb1
bb1:
  %t11 = load i32, ptr %l8, !tbaa !23
  store i32 %t11, ptr %l3, !tbaa !23
  %t12 = load ptr, ptr %l2, !tbaa !29
  %t13 = load i32, ptr %l3, !tbaa !23
  %t16 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t12, i32 %t13)
  store i32 %t16, ptr %l11
  br label %bb2
bb2:
  %t17 = load i32, ptr %l11
  %t19 = trunc i64 24 to i32
  %t20 = icmp eq i32 %t17, %t19
  br i1 %t20, label %bb3, label %bb4
bb3:
  %t22 = load ptr, ptr %l0, !tbaa !29
  store ptr %t22, ptr %l14, !tbaa !29
  %t23 = load ptr, ptr %l2, !tbaa !29
  %t24 = load i32, ptr %l3, !tbaa !23
  %t27 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeCases(ptr %v0, ptr %t23, i32 %t24)
  store i32 %t27, ptr %l17
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t28 = load ptr, ptr %l14, !tbaa !29
  %t29 = load i32, ptr %l17, !tbaa !23
  %t30 = call { i64, ptr } @compiler_2flower_2ecompiler_2flower_3alowering_2eitems(ptr %v0, ptr %v1, ptr %t28, i32 %t29)
  store { i64, ptr } %t30, ptr %l18
  br label %bb6
bb6:
  %t31 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t32 = insertvalue { { i64, ptr }, i1 } undef, { i64, ptr } %t31, 0
  %t33 = insertvalue { { i64, ptr }, i1 } %t32, i1 true, 1
  store { { i64, ptr }, i1 } %t33, ptr %rv
  br label %ret
bb7:
  %t35 = load ptr, ptr %l2, !tbaa !29
  %t36 = load i32, ptr %l3, !tbaa !23
  %t39 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t35, i32 %t36)
  store i32 %t39, ptr %l22
  br label %bb8
bb8:
  %t40 = load i32, ptr %l22
  %t42 = trunc i64 18 to i32
  %t43 = icmp eq i32 %t40, %t42
  br i1 %t43, label %bb9, label %bb10
bb9:
  %t45 = load ptr, ptr %l2, !tbaa !29
  store ptr %t45, ptr %l26, !tbaa !29
  %t46 = load ptr, ptr %l2, !tbaa !29
  %t47 = load i32, ptr %l3, !tbaa !23
  %t50 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t46, i32 %t47)
  store i32 %t50, ptr %l29
  br label %bb11
bb10:
  store i1 false, ptr %l25, !tbaa !21
  br label %bb13
bb11:
  %t51 = load ptr, ptr %l26, !tbaa !29
  %t52 = load i32, ptr %l29, !tbaa !23
  %t53 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t51, i32 %t52)
  store i32 %t53, ptr %l30
  br label %bb12
bb12:
  %t54 = load i32, ptr %l30
  %t56 = trunc i64 1 to i32
  %t57 = icmp eq i32 %t54, %t56
  store i1 %t57, ptr %l25, !tbaa !21
  br label %bb13
bb13:
  %t59 = load i1, ptr %l25, !tbaa !21
  br i1 %t59, label %bb14, label %bb15
bb14:
  %t60 = load ptr, ptr %l2, !tbaa !29
  %t61 = load i32, ptr %l3, !tbaa !23
  %t64 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %t60, i32 %t61)
  store i1 %t64, ptr %l36
  br label %bb16
bb15:
  store i1 false, ptr %l33, !tbaa !21
  br label %bb17
bb16:
  %t65 = load i1, ptr %l36, !tbaa !21
  store i1 %t65, ptr %l33, !tbaa !21
  br label %bb17
bb17:
  %t66 = load i1, ptr %l33, !tbaa !21
  br i1 %t66, label %bb18, label %bb19
bb18:
  %t67 = load ptr, ptr %l0, !tbaa !29
  store ptr %t67, ptr %l37, !tbaa !29
  %t68 = load ptr, ptr %l2, !tbaa !29
  %t69 = load i32, ptr %l3, !tbaa !23
  %t72 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %t68, i32 %t69)
  store i32 %t72, ptr %l40
  br label %bb20
bb19:
  br label %bb22
bb20:
  %t73 = load ptr, ptr %l37, !tbaa !29
  %t74 = load i32, ptr %l40, !tbaa !23
  %t75 = call { i64, ptr } @compiler_2flower_2ecompiler_2flower_3alowering_2eitems(ptr %v0, ptr %v1, ptr %t73, i32 %t74)
  store { i64, ptr } %t75, ptr %l41
  br label %bb21
bb21:
  %t76 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t77 = insertvalue { { i64, ptr }, i1 } undef, { i64, ptr } %t76, 0
  %t78 = insertvalue { { i64, ptr }, i1 } %t77, i1 true, 1
  store { { i64, ptr }, i1 } %t78, ptr %rv
  br label %ret
bb22:
  %t80 = icmp sge i64 0, 0
  br i1 %t80, label %bb23, label %bb24
bb23:
  %t82 = icmp sle i64 0, 2305843009213693951
  br i1 %t82, label %bb25, label %bb26
bb24:
  call void @__olang_check_failed(ptr @olang_loc_3b8f4ce72bb8c828_c6f22e3cb9711da4)
  unreachable
bb25:
  %t84 = mul i64 0, 4
  %t85 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t84)
  %t86 = insertvalue { i64, ptr } undef, i64 0, 0
  %t87 = insertvalue { i64, ptr } %t86, ptr %t85, 1
  %t89 = insertvalue { { i64, ptr }, i1 } undef, { i64, ptr } %t87, 0
  %t90 = insertvalue { { i64, ptr }, i1 } %t89, i1 false, 1
  store { { i64, ptr }, i1 } %t90, ptr %rv
  br label %ret
bb26:
  call void @__olang_check_failed(ptr @olang_loc_3b8f4ce72bb8c828_c6f22e3cb9711da4)
  unreachable
ret:
  %rr = load { { i64, ptr }, i1 }, ptr %rv
  ret { { i64, ptr }, i1 } %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2echeck(ptr %v0, ptr %a0, { i64, [4 x i64] } %a1, i32 %a2, i32 %a3, i64 %a4, %"compiler/source:Span" %a5) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca { i32, i64 }
  %l13 = alloca i1
  %l18 = alloca i32
  %l21 = alloca i32
  %l39 = alloca { i32, i64 }
  %l42 = alloca ptr
  %l45 = alloca { i64, [4 x i64] }
  %l49 = alloca i32
  %t28 = alloca { i64, [7 x i64] }, align 8
  %t52 = alloca { i64, [4 x i64] }, align 8
  %t55 = alloca { i64, [7 x i64] }, align 8
  %t85 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  store %"compiler/source:Span" %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 7
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l13, !tbaa !21
  br label %bb3
bb2:
  %t6 = load i32, ptr %l2
  %t8 = trunc i64 0 to i32
  %t9 = icmp eq i32 %t6, %t8
  store i1 %t9, ptr %l13, !tbaa !21
  br label %bb3
bb3:
  %t11 = load i1, ptr %l13, !tbaa !21
  br i1 %t11, label %bb4, label %bb5
bb4:
  br label %ret
bb5:
  br label %bb6
bb6:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/lower:lowering", ptr %t12, i32 0, i32 3
  %t16 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t14)
  store i32 %t16, ptr %l18
  br label %bb7
bb7:
  %t17 = load i32, ptr %l18, !tbaa !23
  store i32 %t17, ptr %l6, !tbaa !23
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/lower:lowering", ptr %t18, i32 0, i32 3
  %t22 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t20)
  store i32 %t22, ptr %l21
  br label %bb8
bb8:
  %t23 = load i32, ptr %l21, !tbaa !23
  store i32 %t23, ptr %l7, !tbaa !23
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = load i32, ptr %l6, !tbaa !23
  %t27 = load i32, ptr %l7, !tbaa !23
  store { i64, [7 x i64] } zeroinitializer, ptr %t28
  %t29 = getelementptr { i64, [7 x i64] }, ptr %t28, i32 0, i32 0
  store i64 2, ptr %t29
  %t31 = insertvalue { { i64, [4 x i64] }, i32, i32 } undef, { i64, [4 x i64] } %a1, 0
  %t33 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t31, i32 %t26, 1
  %t35 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t33, i32 %t27, 2
  %t36 = getelementptr { i64, [7 x i64] }, ptr %t28, i32 0, i32 1
  store { { i64, [4 x i64] }, i32, i32 } %t35, ptr %t36
  %t37 = load { i64, [7 x i64] }, ptr %t28
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t24, { i64, [7 x i64] } %t37)
  br label %bb9
bb9:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t41 = load i32, ptr %l7, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t40, i32 %t41)
  br label %bb10
bb10:
  %t44 = load i32, ptr %l2
  %t46 = trunc i64 1 to i32
  %t47 = icmp eq i32 %t44, %t46
  br i1 %t47, label %bb11, label %bb12
bb11:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t50 = load %"compiler/source:Span", ptr %l5
  store { i64, [4 x i64] } zeroinitializer, ptr %t52
  %t53 = getelementptr { i64, [4 x i64] }, ptr %t52, i32 0, i32 0
  store i64 0, ptr %t53
  %t54 = load { i64, [4 x i64] }, ptr %t52
  store { i64, [7 x i64] } zeroinitializer, ptr %t55
  %t56 = getelementptr { i64, [7 x i64] }, ptr %t55, i32 0, i32 0
  store i64 8, ptr %t56
  %t58 = insertvalue { %"compiler/source:Span", i32, { i64, [4 x i64] } } undef, %"compiler/source:Span" %t50, 0
  %t60 = insertvalue { %"compiler/source:Span", i32, { i64, [4 x i64] } } %t58, i32 %a3, 1
  %t62 = insertvalue { %"compiler/source:Span", i32, { i64, [4 x i64] } } %t60, { i64, [4 x i64] } %t54, 2
  %t63 = getelementptr { i64, [7 x i64] }, ptr %t55, i32 0, i32 1
  store { %"compiler/source:Span", i32, { i64, [4 x i64] } } %t62, ptr %t63
  %t64 = load { i64, [7 x i64] }, ptr %t55
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t49, { i64, [7 x i64] } %t64)
  br label %bb13
bb12:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/lower:lowering", ptr %t67, i32 0, i32 0
  %t70 = load ptr, ptr %t69, !tbaa !29
  %t74 = call { i32, i64 } @compiler_2flower_2ecompiler_2flower_3aLowerer_2efailure(ptr %v0, ptr %t70, i64 %a4)
  store { i32, i64 } %t74, ptr %l39
  br label %bb14
bb13:
  br label %bb17
bb14:
  %t75 = load { i32, i64 }, ptr %l39
  store { i32, i64 } %t75, ptr %l8
  %t76 = getelementptr { i32, i64 }, ptr %l8, i32 0, i32 0
  %t77 = load i32, ptr %t76, !tbaa !23
  %t79 = getelementptr { i32, i64 }, ptr %l8, i32 0, i32 1
  %t80 = load i64, ptr %t79, !tbaa !24
  %t82 = load ptr, ptr %l0, !tbaa !29
  store ptr %t82, ptr %l42, !tbaa !29
  %t83 = load i32, ptr @G_2ecompiler_2fmir_2eI32T, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t85
  %t86 = getelementptr { i64, [4 x i64] }, ptr %t85, i32 0, i32 0
  store i64 2, ptr %t86
  %t88 = insertvalue { i32, i64 } undef, i32 %t83, 0
  %t90 = insertvalue { i32, i64 } %t88, i64 %t80, 1
  %t91 = getelementptr { i64, [4 x i64] }, ptr %t85, i32 0, i32 1
  store { i32, i64 } %t90, ptr %t91
  %t92 = load { i64, [4 x i64] }, ptr %t85
  store { i64, [4 x i64] } %t92, ptr %l45
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/lower:lowering", ptr %t93, i32 0, i32 2
  %t96 = load ptr, ptr %t95, !tbaa !29
  %t100 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList1(ptr %v0, ptr %t96, i32 %t77)
  store i32 %t100, ptr %l49
  br label %bb15
bb15:
  %t101 = load %"compiler/source:Span", ptr %l5
  %t102 = load ptr, ptr %l42, !tbaa !29
  %t103 = load { i64, [4 x i64] }, ptr %l45
  %t104 = load i32, ptr %l49, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2edispatch(ptr %v0, ptr %t102, { i64, [4 x i64] } %t103, i32 %t104, %"compiler/source:Span" %t101, i1 true)
  br label %bb16
bb16:
  br label %bb17
bb17:
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t107 = load i32, ptr %l6, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t106, i32 %t107)
  br label %bb18
bb18:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2eclauses(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/lower:tryCtx" %a1, { i64, ptr } %a2, i32 %a3, i32 %a4, ptr %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/lower:tryCtx"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i32
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca ptr
  %l13 = alloca { i64, [4 x i64] }
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l26 = alloca i64
  %l29 = alloca i64
  %l49 = alloca i32
  %l52 = alloca { i64, ptr }
  %l55 = alloca ptr
  %l58 = alloca i32
  %l60 = alloca ptr
  %l63 = alloca i32
  %l68 = alloca ptr
  %l77 = alloca i1
  %l81 = alloca i1
  %l92 = alloca { i64, ptr }
  %l95 = alloca { i64, [4 x i64] }
  %l96 = alloca ptr
  %l98 = alloca %"compiler/source:Span"
  %l100 = alloca %"compiler/mir:Place"
  %l107 = alloca i64
  %l117 = alloca i64
  %l120 = alloca i64
  %l138 = alloca i64
  %l141 = alloca { i64, ptr }
  %l145 = alloca { i64, [4 x i64] }
  %l148 = alloca ptr
  %l150 = alloca %"compiler/source:Span"
  %l152 = alloca %"compiler/mir:Place"
  %l153 = alloca i32
  %l157 = alloca %"compiler/mir:Range"
  %s2 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %t176 = alloca { i64, [15 x i64] }, align 8
  %t182 = alloca { i64, [21 x i64] }, align 8
  %t299 = alloca { i64, [15 x i64] }, align 8
  %t308 = alloca { i64, [21 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/lower:tryCtx" %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l6, !tbaa !24
  %t1 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  store i64 %t3, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t5 = load i64, ptr %l7, !tbaa !24
  %t6 = load i64, ptr %l6, !tbaa !24
  %t9 = icmp sgt i64 %t5, %t6
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = load i64, ptr %l8, !tbaa !24
  %t13 = icmp sgt i64 %t11, 0
  br i1 %t13, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l26, !tbaa !24
  br label %bb6
bb3:
  %t15 = load i64, ptr %l7, !tbaa !24
  %t16 = load i64, ptr %l6, !tbaa !24
  %t19 = sub i64 %t15, %t16
  %t20 = load i64, ptr %l8, !tbaa !24
  %t23 = add i64 %t19, %t20
  %t25 = sub i64 %t23, 1
  %t26 = load i64, ptr %l8, !tbaa !24
  %t29 = sdiv i64 %t25, %t26
  store i64 %t29, ptr %l29, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l29, !tbaa !24
  br label %bb5
bb5:
  %t31 = load i64, ptr %l29, !tbaa !24
  store i64 %t31, ptr %l26, !tbaa !24
  br label %bb6
bb6:
  %t32 = load i64, ptr %l26, !tbaa !24
  store i64 %t32, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t33 = load i64, ptr %l10, !tbaa !24
  %t34 = load i64, ptr %l9, !tbaa !24
  %t37 = icmp slt i64 %t33, %t34
  %t39 = xor i1 %t37, true
  br i1 %t39, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb63
bb9:
  br label %bb10
bb10:
  %t41 = load i64, ptr %l6, !tbaa !24
  %t42 = load i64, ptr %l10, !tbaa !24
  %t43 = load i64, ptr %l8, !tbaa !24
  %t46 = mul i64 %t42, %t43
  %t49 = add i64 %t41, %t46
  store i64 %t49, ptr %l11, !tbaa !24
  %t51 = getelementptr %"compiler/lower:tryCtx", ptr %l1, i32 0, i32 4
  %t52 = load i64, ptr %l11, !tbaa !24
  %t55 = call i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aBlockId_3e_2eAt_3ccompiler_2fmir_3aBlockId_3e(ptr %v1, ptr %t51, i64 %t52)
  store i32 %t55, ptr %l49
  br label %bb11
bb11:
  %t56 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t57 = load i32, ptr %l49, !tbaa !23
  %t59 = icmp eq i32 %t57, %t56
  br i1 %t59, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s2)
  br label %bb62
bb13:
  br label %bb14
bb14:
  %t61 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t61, ptr %l52, !tbaa !27
  %t62 = load i64, ptr %l11, !tbaa !24
  %t64 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t65 = load ptr, ptr %t64, !tbaa !27
  %t66 = getelementptr ptr, ptr %t65, i64 %t62
  %t67 = load ptr, ptr %t66, !tbaa !39
  store ptr %t67, ptr %l12, !tbaa !29
  %t69 = load ptr, ptr %l0, !tbaa !29
  store ptr %t69, ptr %l55, !tbaa !29
  %t70 = getelementptr %"compiler/lower:tryCtx", ptr %l1, i32 0, i32 4
  %t71 = load i64, ptr %l11, !tbaa !24
  %t74 = call i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aBlockId_3e_2eAt_3ccompiler_2fmir_3aBlockId_3e(ptr %v1, ptr %t70, i64 %t71)
  store i32 %t74, ptr %l58
  br label %bb15
bb15:
  %t75 = load ptr, ptr %l55, !tbaa !29
  %t76 = load i32, ptr %l58, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t75, i32 %t76)
  br label %bb16
bb16:
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/lower:lowering", ptr %t77, i32 0, i32 3
  %t80 = getelementptr %"compiler/mir:Fn", ptr %t79, i32 0, i32 22
  store ptr %t80, ptr %l60, !tbaa !29
  %t81 = getelementptr %"compiler/lower:tryCtx", ptr %l1, i32 0, i32 4
  %t82 = load i64, ptr %l11, !tbaa !24
  %t85 = call i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aBlockId_3e_2eAt_3ccompiler_2fmir_3aBlockId_3e(ptr %v1, ptr %t81, i64 %t82)
  store i32 %t85, ptr %l63
  br label %bb17
bb17:
  %t86 = load ptr, ptr %l60, !tbaa !29
  %t87 = load i32, ptr %l63, !tbaa !23
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aBlockId_3e_2ePush_3ccompiler_2fmir_3aBlockId_3e(ptr %v0, ptr %t86, i32 %t87)
  br label %bb18
bb18:
  %t88 = load ptr, ptr %l12, !tbaa !29
  %t90 = getelementptr %"compiler/typed:Clause", ptr %t88, i32 0, i32 3
  %t91 = load ptr, ptr %t90, !tbaa !29
  %t93 = icmp eq ptr %t91, null
  %t95 = xor i1 %t93, true
  br i1 %t95, label %bb19, label %bb20
bb19:
  %t97 = load ptr, ptr %l0, !tbaa !29
  store ptr %t97, ptr %l68, !tbaa !29
  %t98 = load ptr, ptr %l12, !tbaa !29
  %t100 = getelementptr %"compiler/typed:Clause", ptr %t98, i32 0, i32 3
  %t101 = load ptr, ptr %t100, !tbaa !29
  %t103 = icmp eq ptr %t101, null
  br i1 %t103, label %bb21, label %bb22
bb20:
  br label %bb25
bb21:
  call void @__olang_check_failed(ptr @olang_loc_ed4966d7257d1cce_314b285230575e82)
  unreachable
bb22:
  br label %bb23
bb23:
  %t105 = load ptr, ptr %l12, !tbaa !29
  %t107 = getelementptr %"compiler/typed:Clause", ptr %t105, i32 0, i32 3
  %t108 = load ptr, ptr %t107, !tbaa !29
  %t109 = load ptr, ptr %l68, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eblock(ptr %v0, ptr %v2, ptr %t109, ptr %t108)
  br label %bb24
bb24:
  br label %bb25
bb25:
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t113 = getelementptr %"compiler/lower:lowering", ptr %t111, i32 0, i32 7
  %t114 = load i1, ptr %t113, !tbaa !21
  %t116 = xor i1 %t114, true
  br i1 %t116, label %bb26, label %bb27
bb26:
  %t118 = load i32, ptr %l3, !tbaa !23
  %t119 = load i32, ptr @G_2ecompiler_2fmir_2eNoLocal, !tbaa !23
  %t122 = icmp ne i32 %t118, %t119
  store i1 %t122, ptr %l77, !tbaa !21
  br label %bb28
bb27:
  store i1 false, ptr %l77, !tbaa !21
  br label %bb28
bb28:
  %t124 = load i1, ptr %l77, !tbaa !21
  br i1 %t124, label %bb29, label %bb30
bb29:
  %t125 = load ptr, ptr %l12, !tbaa !29
  %t127 = getelementptr %"compiler/typed:Clause", ptr %t125, i32 0, i32 4
  %t128 = load { i64, ptr }, ptr %t127, !tbaa !27
  %t130 = extractvalue { i64, ptr } %t128, 0
  %t132 = icmp sgt i64 %t130, 0
  store i1 %t132, ptr %l81, !tbaa !21
  br label %bb31
bb30:
  store i1 false, ptr %l81, !tbaa !21
  br label %bb31
bb31:
  %t134 = load i1, ptr %l81, !tbaa !21
  br i1 %t134, label %bb32, label %bb33
bb32:
  %t135 = load ptr, ptr %l12, !tbaa !29
  %t137 = getelementptr %"compiler/typed:Clause", ptr %t135, i32 0, i32 4
  %t138 = load { i64, ptr }, ptr %t137, !tbaa !27
  %t140 = extractvalue { i64, ptr } %t138, 0
  %t142 = icmp eq i64 %t140, 1
  br i1 %t142, label %bb34, label %bb35
bb33:
  br label %bb60
bb34:
  store %olang.scope zeroinitializer, ptr %s6
  %t144 = load ptr, ptr %l0, !tbaa !29
  %t145 = load ptr, ptr %l12, !tbaa !29
  %t147 = getelementptr %"compiler/typed:Clause", ptr %t145, i32 0, i32 4
  %t148 = load { i64, ptr }, ptr %t147, !tbaa !27
  store { i64, ptr } %t148, ptr %l92, !tbaa !27
  %t149 = getelementptr { i64, ptr }, ptr %l92, i32 0, i32 1
  %t150 = load ptr, ptr %t149, !tbaa !27
  %t151 = getelementptr ptr, ptr %t150, i64 0
  %t152 = load ptr, ptr %t151, !tbaa !39
  %t156 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v2, ptr %t144, ptr %t152)
  store { i64, [4 x i64] } %t156, ptr %l95
  br label %bb36
bb35:
  store %olang.scope zeroinitializer, ptr %s7
  %t157 = load ptr, ptr %l12, !tbaa !29
  %t159 = getelementptr %"compiler/typed:Clause", ptr %t157, i32 0, i32 4
  %t160 = load { i64, ptr }, ptr %t159, !tbaa !27
  %t162 = extractvalue { i64, ptr } %t160, 0
  store i64 %t162, ptr %l107, !tbaa !24
  %t163 = load i64, ptr %l107, !tbaa !24
  %t164 = icmp sge i64 %t163, 0
  br i1 %t164, label %bb39, label %bb40
bb36:
  %t166 = load { i64, [4 x i64] }, ptr %l95
  store { i64, [4 x i64] } %t166, ptr %l13
  %t167 = load ptr, ptr %l0, !tbaa !29
  store ptr %t167, ptr %l96, !tbaa !29
  %t168 = load ptr, ptr %l12, !tbaa !29
  %t170 = getelementptr %"compiler/typed:Clause", ptr %t168, i32 0, i32 0
  %t171 = load %"compiler/source:Span", ptr %t170
  store %"compiler/source:Span" %t171, ptr %l98
  %t172 = load i32, ptr %l3, !tbaa !23
  %t174 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t172)
  store %"compiler/mir:Place" %t174, ptr %l100
  br label %bb37
bb37:
  %t175 = load { i64, [4 x i64] }, ptr %l13
  store { i64, [15 x i64] } zeroinitializer, ptr %t176
  %t177 = getelementptr { i64, [15 x i64] }, ptr %t176, i32 0, i32 0
  store i64 0, ptr %t177
  %t179 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t175, 0
  %t180 = getelementptr { i64, [15 x i64] }, ptr %t176, i32 0, i32 1
  store { { i64, [4 x i64] } } %t179, ptr %t180
  %t181 = load { i64, [15 x i64] }, ptr %t176
  store { i64, [21 x i64] } zeroinitializer, ptr %t182
  %t183 = getelementptr { i64, [21 x i64] }, ptr %t182, i32 0, i32 0
  store i64 0, ptr %t183
  %t184 = load %"compiler/source:Span", ptr %l98
  %t185 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t184, 0
  %t186 = load %"compiler/mir:Place", ptr %l100
  %t187 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t185, %"compiler/mir:Place" %t186, 1
  %t189 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t187, { i64, [15 x i64] } %t181, 2
  %t190 = getelementptr { i64, [21 x i64] }, ptr %t182, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t189, ptr %t190
  %t191 = load { i64, [21 x i64] }, ptr %t182
  %t193 = call ptr @__olang_scope_alloc_a(ptr %s6, i64 176, i64 8)
  store { i64, [21 x i64] } %t191, ptr %t193
  %t194 = load ptr, ptr %l96, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s6, ptr %t194, ptr %t193)
  br label %bb38
bb38:
  call void @__olang_scope_close(ptr %s6)
  br label %bb59
bb39:
  %t196 = load i64, ptr %l107, !tbaa !24
  %t197 = icmp sle i64 %t196, 230584300921369395
  br i1 %t197, label %bb41, label %bb42
bb40:
  call void @__olang_check_failed(ptr @olang_loc_4fc14cddf040b63b_d4edc892d8598fd7)
  unreachable
bb41:
  %t199 = load i64, ptr %l107, !tbaa !24
  %t200 = mul i64 %t199, 40
  %t201 = call ptr @__olang_scope_alloc_zeroed(ptr %s7, i64 %t200)
  %t202 = insertvalue { i64, ptr } undef, i64 %t199, 0
  %t203 = insertvalue { i64, ptr } %t202, ptr %t201, 1
  store { i64, ptr } %t203, ptr %l14, !tbaa !27
  store i64 0, ptr %l15, !tbaa !24
  %t205 = load ptr, ptr %l12, !tbaa !29
  %t207 = getelementptr %"compiler/typed:Clause", ptr %t205, i32 0, i32 4
  %t208 = load { i64, ptr }, ptr %t207, !tbaa !27
  %t210 = extractvalue { i64, ptr } %t208, 0
  store i64 %t210, ptr %l16, !tbaa !24
  store i64 1, ptr %l17, !tbaa !24
  %t212 = load i64, ptr %l16, !tbaa !24
  %t213 = load i64, ptr %l15, !tbaa !24
  %t216 = icmp sgt i64 %t212, %t213
  br i1 %t216, label %bb43, label %bb44
bb42:
  call void @__olang_check_failed(ptr @olang_loc_4fc14cddf040b63b_d4edc892d8598fd7)
  unreachable
bb43:
  %t218 = load i64, ptr %l17, !tbaa !24
  %t220 = icmp sgt i64 %t218, 0
  br i1 %t220, label %bb45, label %bb46
bb44:
  store i64 0, ptr %l117, !tbaa !24
  br label %bb48
bb45:
  %t222 = load i64, ptr %l16, !tbaa !24
  %t223 = load i64, ptr %l15, !tbaa !24
  %t226 = sub i64 %t222, %t223
  %t227 = load i64, ptr %l17, !tbaa !24
  %t230 = add i64 %t226, %t227
  %t232 = sub i64 %t230, 1
  %t233 = load i64, ptr %l17, !tbaa !24
  %t236 = sdiv i64 %t232, %t233
  store i64 %t236, ptr %l120, !tbaa !24
  br label %bb47
bb46:
  store i64 0, ptr %l120, !tbaa !24
  br label %bb47
bb47:
  %t238 = load i64, ptr %l120, !tbaa !24
  store i64 %t238, ptr %l117, !tbaa !24
  br label %bb48
bb48:
  %t239 = load i64, ptr %l117, !tbaa !24
  store i64 %t239, ptr %l18, !tbaa !24
  store i64 0, ptr %l19, !tbaa !24
  br label %bb49
bb49:
  store %olang.scope zeroinitializer, ptr %s9
  %t240 = load i64, ptr %l19, !tbaa !24
  %t241 = load i64, ptr %l18, !tbaa !24
  %t244 = icmp slt i64 %t240, %t241
  %t246 = xor i1 %t244, true
  br i1 %t246, label %bb50, label %bb51
bb50:
  call void @__olang_scope_close(ptr %s9)
  br label %bb55
bb51:
  br label %bb52
bb52:
  %t248 = load i64, ptr %l15, !tbaa !24
  %t249 = load i64, ptr %l19, !tbaa !24
  %t250 = load i64, ptr %l17, !tbaa !24
  %t253 = mul i64 %t249, %t250
  %t256 = add i64 %t248, %t253
  store i64 %t256, ptr %l20, !tbaa !24
  %t258 = load i64, ptr %l20, !tbaa !24
  store i64 %t258, ptr %l138, !tbaa !24
  %t259 = load ptr, ptr %l0, !tbaa !29
  %t260 = load ptr, ptr %l12, !tbaa !29
  %t262 = getelementptr %"compiler/typed:Clause", ptr %t260, i32 0, i32 4
  %t263 = load { i64, ptr }, ptr %t262, !tbaa !27
  store { i64, ptr } %t263, ptr %l141, !tbaa !27
  %t264 = load i64, ptr %l20, !tbaa !24
  %t266 = getelementptr { i64, ptr }, ptr %l141, i32 0, i32 1
  %t267 = load ptr, ptr %t266, !tbaa !27
  %t268 = getelementptr ptr, ptr %t267, i64 %t264
  %t269 = load ptr, ptr %t268, !tbaa !39
  %t273 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v2, ptr %t259, ptr %t269)
  store { i64, [4 x i64] } %t273, ptr %l145
  br label %bb53
bb53:
  %t274 = load { i64, [4 x i64] }, ptr %l145
  %t275 = load i64, ptr %l138, !tbaa !24
  %t276 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t277 = load ptr, ptr %t276, !tbaa !27
  %t278 = getelementptr { i64, [4 x i64] }, ptr %t277, i64 %t275
  store { i64, [4 x i64] } %t274, ptr %t278
  call void @__olang_scope_close(ptr %s9)
  br label %bb54
bb54:
  %t279 = load i64, ptr %l19, !tbaa !24
  %t281 = add i64 %t279, 1
  store i64 %t281, ptr %l19, !tbaa !24
  br label %bb49
bb55:
  %t283 = load ptr, ptr %l0, !tbaa !29
  store ptr %t283, ptr %l148, !tbaa !29
  %t284 = load ptr, ptr %l12, !tbaa !29
  %t286 = getelementptr %"compiler/typed:Clause", ptr %t284, i32 0, i32 0
  %t287 = load %"compiler/source:Span", ptr %t286
  store %"compiler/source:Span" %t287, ptr %l150
  %t288 = load i32, ptr %l3, !tbaa !23
  %t290 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t288)
  store %"compiler/mir:Place" %t290, ptr %l152
  br label %bb56
bb56:
  store i32 %a4, ptr %l153, !tbaa !23
  %t292 = load ptr, ptr %l0, !tbaa !29
  %t294 = getelementptr %"compiler/lower:lowering", ptr %t292, i32 0, i32 3
  %t295 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t298 = call %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eArgs(ptr %v0, ptr %s7, ptr %t294, { i64, ptr } %t295)
  store %"compiler/mir:Range" %t298, ptr %l157
  br label %bb57
bb57:
  store { i64, [15 x i64] } zeroinitializer, ptr %t299
  %t300 = getelementptr { i64, [15 x i64] }, ptr %t299, i32 0, i32 0
  store i64 6, ptr %t300
  %t301 = load i32, ptr %l153, !tbaa !23
  %t302 = insertvalue { i32, i64, %"compiler/mir:Range" } undef, i32 %t301, 0
  %t303 = insertvalue { i32, i64, %"compiler/mir:Range" } %t302, i64 0, 1
  %t304 = load %"compiler/mir:Range", ptr %l157
  %t305 = insertvalue { i32, i64, %"compiler/mir:Range" } %t303, %"compiler/mir:Range" %t304, 2
  %t306 = getelementptr { i64, [15 x i64] }, ptr %t299, i32 0, i32 1
  store { i32, i64, %"compiler/mir:Range" } %t305, ptr %t306
  %t307 = load { i64, [15 x i64] }, ptr %t299
  store { i64, [21 x i64] } zeroinitializer, ptr %t308
  %t309 = getelementptr { i64, [21 x i64] }, ptr %t308, i32 0, i32 0
  store i64 0, ptr %t309
  %t310 = load %"compiler/source:Span", ptr %l150
  %t311 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t310, 0
  %t312 = load %"compiler/mir:Place", ptr %l152
  %t313 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t311, %"compiler/mir:Place" %t312, 1
  %t315 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t313, { i64, [15 x i64] } %t307, 2
  %t316 = getelementptr { i64, [21 x i64] }, ptr %t308, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t315, ptr %t316
  %t317 = load { i64, [21 x i64] }, ptr %t308
  %t319 = call ptr @__olang_scope_alloc_a(ptr %s7, i64 176, i64 8)
  store { i64, [21 x i64] } %t317, ptr %t319
  %t320 = load ptr, ptr %l148, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s7, ptr %t320, ptr %t319)
  br label %bb58
bb58:
  call void @__olang_scope_close(ptr %s7)
  br label %bb59
bb59:
  br label %bb60
bb60:
  %t322 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eleaveOpen(ptr %v0, ptr %v3, ptr %t322, ptr %a5)
  br label %bb61
bb61:
  call void @__olang_scope_close(ptr %s2)
  br label %bb62
bb62:
  %t326 = load i64, ptr %l10, !tbaa !24
  %t328 = add i64 %t326, 1
  store i64 %t328, ptr %l10, !tbaa !24
  br label %bb7
bb63:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2ecleanup(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i64
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i32
  %l11 = alloca i32
  %l14 = alloca i32
  %l28 = alloca ptr
  %l32 = alloca ptr
  %s0 = alloca %olang.scope
  %t24 = alloca { i64, [21 x i64] }, align 8
  %t73 = alloca { i64, [7 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 7
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/lower:lowering", ptr %t6, i32 0, i32 11
  %t9 = load i64, ptr %l2, !tbaa !24
  %t12 = call i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeId_3e_2eAt_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t8, i64 %t9)
  store i32 %t12, ptr %l11
  br label %bb4
bb4:
  %t13 = load i32, ptr %l11, !tbaa !23
  store i32 %t13, ptr %l3, !tbaa !23
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/lower:lowering", ptr %t14, i32 0, i32 3
  %t18 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t16)
  store i32 %t18, ptr %l14
  br label %bb5
bb5:
  %t19 = load i32, ptr %l14, !tbaa !23
  store i32 %t19, ptr %l4, !tbaa !23
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load %"compiler/source:Span", ptr %l1
  %t22 = load i32, ptr %l3, !tbaa !23
  %t23 = load i32, ptr %l4, !tbaa !23
  store { i64, [21 x i64] } zeroinitializer, ptr %t24
  %t25 = getelementptr { i64, [21 x i64] }, ptr %t24, i32 0, i32 0
  store i64 13, ptr %t25
  %t27 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %t21, 0
  %t29 = insertvalue { %"compiler/source:Span", i32, i32 } %t27, i32 %t22, 1
  %t31 = insertvalue { %"compiler/source:Span", i32, i32 } %t29, i32 %t23, 2
  %t32 = getelementptr { i64, [21 x i64] }, ptr %t24, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t31, ptr %t32
  %t33 = load { i64, [21 x i64] }, ptr %t24
  %t35 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t33, ptr %t35
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s0, ptr %t20, ptr %t35)
  br label %bb6
bb6:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/lower:lowering", ptr %t38, i32 0, i32 6
  %t41 = load i32, ptr %t40, !tbaa !23
  store i32 %t41, ptr %l5, !tbaa !23
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t44 = load i32, ptr %l4, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t43, i32 %t44)
  br label %bb7
bb7:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/lower:lowering", ptr %t47, i32 0, i32 11
  %t50 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeId_3e_2eSetAt_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t49, i64 %t50, i32 -1)
  br label %bb8
bb8:
  %t53 = load ptr, ptr %l0, !tbaa !29
  store ptr %t53, ptr %l28, !tbaa !29
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/lower:lowering", ptr %t54, i32 0, i32 10
  %t57 = load i64, ptr %l2, !tbaa !24
  %t60 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aBlock_26_3e_2eAt_Hef81d01aee8891fe569e7a3039d88992(ptr %v0, ptr %v0, ptr %t56, i64 %t57)
  store ptr %t60, ptr %l32
  br label %bb9
bb9:
  %t61 = load ptr, ptr %l28, !tbaa !29
  %t62 = load ptr, ptr %l32, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eblock(ptr %v0, ptr %v0, ptr %t61, ptr %t62)
  br label %bb10
bb10:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/lower:lowering", ptr %t63, i32 0, i32 11
  %t66 = load i64, ptr %l2, !tbaa !24
  %t67 = load i32, ptr %l3, !tbaa !23
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeId_3e_2eSetAt_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t65, i64 %t66, i32 %t67)
  br label %bb11
bb11:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t72 = load %"compiler/source:Span", ptr %l1
  store { i64, [7 x i64] } zeroinitializer, ptr %t73
  %t74 = getelementptr { i64, [7 x i64] }, ptr %t73, i32 0, i32 0
  store i64 9, ptr %t74
  %t76 = insertvalue { %"compiler/source:Span" } undef, %"compiler/source:Span" %t72, 0
  %t77 = getelementptr { i64, [7 x i64] }, ptr %t73, i32 0, i32 1
  store { %"compiler/source:Span" } %t76, ptr %t77
  %t78 = load { i64, [7 x i64] }, ptr %t73
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t71, { i64, [7 x i64] } %t78)
  br label %bb12
bb12:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t82 = load i32, ptr %l5, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t81, i32 %t82)
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ecollect(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca { i64, [4 x i64] }
  %l11 = alloca i32
  %l12 = alloca { i64, [1 x i64] }
  %l13 = alloca i32
  %l14 = alloca i32
  %l20 = alloca i32
  %l24 = alloca i1
  %l27 = alloca i64
  %l34 = alloca i32
  %l35 = alloca ptr
  %l38 = alloca i32
  %l40 = alloca i32
  %l42 = alloca { i64, [4 x i64] }
  %l50 = alloca { i64, [4 x i64] }
  %l51 = alloca ptr
  %l52 = alloca { i64, [4 x i64] }
  %l58 = alloca i32
  %l60 = alloca { i64, [4 x i64] }
  %l65 = alloca ptr
  %l66 = alloca i32
  %l67 = alloca i32
  %l68 = alloca { i64, [4 x i64] }
  %l70 = alloca { i64, [4 x i64] }
  %l71 = alloca { i64, ptr }
  %l73 = alloca { i64, [4 x i64] }
  %l87 = alloca i32
  %l91 = alloca { i64, [1 x i64] }
  %l92 = alloca ptr
  %l93 = alloca %"compiler/source:Span"
  %l95 = alloca %"compiler/mir:Place"
  %l107 = alloca i32
  %l108 = alloca ptr
  %l109 = alloca %"compiler/source:Span"
  %l111 = alloca %"compiler/mir:Place"
  %l113 = alloca { i64, [4 x i64] }
  %l118 = alloca ptr
  %l124 = alloca %"compiler/lower:collectCtx"
  %l128 = alloca %"compiler/lower:collectCtx"
  %l131 = alloca %"compiler/lower:collectCtx"
  %l132 = alloca i32
  %l139 = alloca i32
  %l140 = alloca ptr
  %l141 = alloca %"compiler/source:Span"
  %l143 = alloca %"compiler/mir:Place"
  %l144 = alloca { i64, [1 x i64] }
  %l145 = alloca i32
  %l147 = alloca %"compiler/mir:Place"
  %l155 = alloca ptr
  %l157 = alloca { i64, [2 x i64] }
  %l158 = alloca ptr
  %l161 = alloca i32
  %l162 = alloca i1
  %l163 = alloca { i64, ptr }
  %l165 = alloca { i64, ptr }
  %l167 = alloca %"compiler/mir:Place"
  %l168 = alloca ptr
  %l169 = alloca %"compiler/source:Span"
  %l170 = alloca %"compiler/mir:Place"
  %l176 = alloca { i64, ptr }
  %l177 = alloca %"compiler/mir:Place"
  %l179 = alloca %"compiler/mir:Place"
  %l184 = alloca %"compiler/mir:Place"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca { i64, [4 x i64] }
  %t31 = alloca { i64, [4 x i64] }, align 8
  %t152 = alloca { i64, [4 x i64] }, align 8
  %t182 = alloca { i64, [4 x i64] }, align 8
  %t189 = alloca { i64, [15 x i64] }, align 8
  %t201 = alloca { i64, [21 x i64] }, align 8
  %t231 = alloca { i64, [15 x i64] }, align 8
  %t237 = alloca { i64, [21 x i64] }, align 8
  %t289 = alloca { i64, [4 x i64] }, align 8
  %t311 = alloca { i64, [4 x i64] }, align 8
  %t318 = alloca { i64, [4 x i64] }, align 8
  %t325 = alloca { i64, [15 x i64] }, align 8
  %t337 = alloca { i64, [21 x i64] }, align 8
  %t355 = alloca { i64, [2 x i64] }, align 8
  %t371 = alloca { i64, [1 x i64] }, align 8
  %t400 = alloca { i64, [2 x i64] }, align 8
  %t406 = alloca { i64, [1 x i64] }, align 8
  %t424 = alloca { i64, [4 x i64] }, align 8
  %t430 = alloca { i64, [21 x i64] }, align 8
  %t449 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  store %"compiler/source:Span" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t7 = load i32, ptr %l2, !tbaa !23
  %t10 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2earrayOf(ptr %v0, ptr %t6, i32 %t7)
  store i32 %t10, ptr %l20
  br label %bb1
bb1:
  %t11 = load i32, ptr %l20, !tbaa !23
  store i32 %t11, ptr %l5, !tbaa !23
  %t12 = load i32, ptr %l5, !tbaa !23
  %t13 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t16 = icmp eq i32 %t12, %t13
  br i1 %t16, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l24, !tbaa !21
  br label %bb5
bb3:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t19 = load i32, ptr %l5, !tbaa !23
  %t22 = call i64 @compiler_2flower_2ecompiler_2flower_3alowering_2efixedLen(ptr %v0, ptr %t18, i32 %t19)
  store i64 %t22, ptr %l27
  br label %bb4
bb4:
  %t23 = load i64, ptr %l27, !tbaa !24
  %t24 = icmp sge i64 %t23, 0
  store i1 %t24, ptr %l24, !tbaa !21
  br label %bb5
bb5:
  %t26 = load i1, ptr %l24, !tbaa !21
  br i1 %t26, label %bb6, label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s1
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load %"compiler/source:Span", ptr %l3
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2egap(ptr %v0, ptr %s1, ptr %t27, %"compiler/source:Span" %t28, { i64, ptr } { i64 51, ptr @.d19 })
  br label %bb8
bb7:
  br label %bb9
bb8:
  store { i64, [4 x i64] } zeroinitializer, ptr %t31
  %t32 = getelementptr { i64, [4 x i64] }, ptr %t31, i32 0, i32 0
  store i64 0, ptr %t32
  %t33 = load { i64, [4 x i64] }, ptr %t31
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  store { i64, [4 x i64] } %t33, ptr %rv
  br label %ret
bb9:
  %t35 = load ptr, ptr %l4, !tbaa !29
  %t36 = load i32, ptr %l5, !tbaa !23
  %t39 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t35, i32 %t36)
  store i32 %t39, ptr %l34
  br label %bb10
bb10:
  %t40 = load i32, ptr %l34, !tbaa !23
  store i32 %t40, ptr %l6, !tbaa !23
  %t41 = load ptr, ptr %l4, !tbaa !29
  store ptr %t41, ptr %l35, !tbaa !29
  %t42 = load ptr, ptr %l4, !tbaa !29
  %t43 = load i32, ptr %l6, !tbaa !23
  %t46 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArray(ptr %v0, ptr %t42, i32 %t43, i32 0)
  store i32 %t46, ptr %l38
  br label %bb11
bb11:
  %t47 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t48 = load ptr, ptr %l35, !tbaa !29
  %t49 = load i32, ptr %l38, !tbaa !23
  %t51 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t48, i32 %t49, i64 %t47)
  store i32 %t51, ptr %l40
  br label %bb12
bb12:
  %t52 = load i32, ptr %l40, !tbaa !23
  store i32 %t52, ptr %l7, !tbaa !23
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2econstI64(ptr %v0, ptr %t53, i64 100)
  store { i64, [4 x i64] } %t55, ptr %l42
  br label %bb13
bb13:
  %t56 = load { i64, [4 x i64] }, ptr %l42
  store { i64, [4 x i64] } %t56, ptr %l8
  %t57 = load ptr, ptr %l1, !tbaa !29
  %t59 = getelementptr %"compiler/typed:Collect", ptr %t57, i32 0, i32 0
  %t60 = load ptr, ptr %t59, !tbaa !29
  %t62 = icmp eq ptr %t60, null
  %t64 = xor i1 %t62, true
  br i1 %t64, label %bb14, label %bb15
bb14:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t67 = load ptr, ptr %l1, !tbaa !29
  %t69 = getelementptr %"compiler/typed:Collect", ptr %t67, i32 0, i32 0
  %t70 = load ptr, ptr %t69, !tbaa !29
  %t73 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v1, ptr %t66, ptr %t70)
  store { i64, [4 x i64] } %t73, ptr %l50
  br label %bb16
bb15:
  br label %bb28
bb16:
  %t74 = load { i64, [4 x i64] }, ptr %l50
  %t75 = load ptr, ptr %l0, !tbaa !29
  store ptr %t75, ptr %l51, !tbaa !29
  store { i64, [4 x i64] } %t74, ptr %l52
  %t77 = load ptr, ptr %l1, !tbaa !29
  %t79 = getelementptr %"compiler/typed:Collect", ptr %t77, i32 0, i32 0
  %t80 = load ptr, ptr %t79, !tbaa !29
  %t82 = icmp eq ptr %t80, null
  br i1 %t82, label %bb17, label %bb18
bb17:
  call void @__olang_check_failed(ptr @olang_loc_162f2c5d450ff5be_60a02040feb29ca2)
  unreachable
bb18:
  br label %bb19
bb19:
  %t84 = load ptr, ptr %l1, !tbaa !29
  %t86 = getelementptr %"compiler/typed:Collect", ptr %t84, i32 0, i32 0
  %t87 = load ptr, ptr %t86, !tbaa !29
  %t89 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t87)
  store i32 %t89, ptr %l58
  br label %bb20
bb20:
  %t90 = load %"compiler/source:Span", ptr %l3
  %t91 = load ptr, ptr %l51, !tbaa !29
  %t92 = load { i64, [4 x i64] }, ptr %l52
  %t93 = load i32, ptr %l58, !tbaa !23
  %t95 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2easI64(ptr %v0, ptr %t91, { i64, [4 x i64] } %t92, i32 %t93, %"compiler/source:Span" %t90)
  store { i64, [4 x i64] } %t95, ptr %l60
  br label %bb21
bb21:
  %t96 = load { i64, [4 x i64] }, ptr %l60
  store { i64, [4 x i64] } %t96, ptr %l8
  %t97 = load ptr, ptr %l1, !tbaa !29
  %t99 = getelementptr %"compiler/typed:Collect", ptr %t97, i32 0, i32 3
  %t100 = load i32, ptr %t99
  %t102 = trunc i64 0 to i32
  %t103 = icmp eq i32 %t100, %t102
  %t105 = xor i1 %t103, true
  br i1 %t105, label %bb22, label %bb23
bb22:
  store %olang.scope zeroinitializer, ptr %s3
  %t107 = load ptr, ptr %l0, !tbaa !29
  store ptr %t107, ptr %l65, !tbaa !29
  store i32 18, ptr %l66
  %t108 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t108, ptr %l67, !tbaa !23
  %t109 = load { i64, [4 x i64] }, ptr %l8
  store { i64, [4 x i64] } %t109, ptr %l68
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t112 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2econstI64(ptr %v0, ptr %t110, i64 0)
  store { i64, [4 x i64] } %t112, ptr %l70
  br label %bb24
bb23:
  br label %bb27
bb24:
  %t113 = mul i64 2, 40
  %t114 = call ptr @__olang_scope_alloc_zeroed(ptr %s3, i64 %t113)
  %t115 = insertvalue { i64, ptr } undef, i64 2, 0
  %t116 = insertvalue { i64, ptr } %t115, ptr %t114, 1
  store { i64, ptr } %t116, ptr %l71, !tbaa !27
  %t117 = load { i64, [4 x i64] }, ptr %l68
  %t118 = getelementptr { i64, ptr }, ptr %l71, i32 0, i32 1
  %t119 = load ptr, ptr %t118, !tbaa !27
  %t120 = getelementptr { i64, [4 x i64] }, ptr %t119, i64 0
  store { i64, [4 x i64] } %t117, ptr %t120
  %t121 = load { i64, [4 x i64] }, ptr %l70
  %t122 = getelementptr { i64, ptr }, ptr %l71, i32 0, i32 1
  %t123 = load ptr, ptr %t122, !tbaa !27
  %t124 = getelementptr { i64, [4 x i64] }, ptr %t123, i64 1
  store { i64, [4 x i64] } %t121, ptr %t124
  %t125 = load %"compiler/source:Span", ptr %l3
  %t126 = load ptr, ptr %l65, !tbaa !29
  %t127 = load i32, ptr %l66
  %t128 = load i32, ptr %l67, !tbaa !23
  %t129 = load { i64, ptr }, ptr %l71, !tbaa !27
  %t131 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s3, ptr %t126, i32 %t127, i32 %t128, { i64, ptr } %t129, %"compiler/source:Span" %t125)
  store { i64, [4 x i64] } %t131, ptr %l73
  br label %bb25
bb25:
  %t132 = load { i64, [4 x i64] }, ptr %l73
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t135 = load ptr, ptr %l1, !tbaa !29
  %t137 = getelementptr %"compiler/typed:Collect", ptr %t135, i32 0, i32 3
  %t138 = load i32, ptr %t137
  %t139 = load i64, ptr @G_2ecompiler_2flower_2eOutOfBounds, !tbaa !24
  %t140 = load %"compiler/source:Span", ptr %l3
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2echeck(ptr %v0, ptr %t133, { i64, [4 x i64] } %t132, i32 %t138, i32 7, i64 %t139, %"compiler/source:Span" %t140)
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s3)
  br label %bb27
bb27:
  br label %bb28
bb28:
  %t147 = load ptr, ptr %l0, !tbaa !29
  %t149 = getelementptr %"compiler/lower:lowering", ptr %t147, i32 0, i32 7
  %t150 = load i1, ptr %t149, !tbaa !21
  br i1 %t150, label %bb29, label %bb30
bb29:
  store { i64, [4 x i64] } zeroinitializer, ptr %t152
  %t153 = getelementptr { i64, [4 x i64] }, ptr %t152, i32 0, i32 0
  store i64 0, ptr %t153
  %t154 = load { i64, [4 x i64] }, ptr %t152
  call void @__olang_scope_close(ptr %s0)
  store { i64, [4 x i64] } %t154, ptr %rv
  br label %ret
bb30:
  br label %bb31
bb31:
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t157 = load i32, ptr %l7, !tbaa !23
  %t158 = load %"compiler/source:Span", ptr %l3
  %t162 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2etemp(ptr %v0, ptr %t156, i32 %t157, %"compiler/source:Span" %t158)
  store i32 %t162, ptr %l87
  br label %bb32
bb32:
  %t163 = load i32, ptr %l87, !tbaa !23
  store i32 %t163, ptr %l11, !tbaa !23
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t165 = load ptr, ptr %l1, !tbaa !29
  %t167 = getelementptr %"compiler/typed:Collect", ptr %t165, i32 0, i32 2
  %t168 = load i32, ptr %t167, !tbaa !23
  %t171 = call { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ebuilt(ptr %v0, ptr %t164, i32 %t168)
  store { i64, [1 x i64] } %t171, ptr %l91
  br label %bb33
bb33:
  %t172 = load { i64, [1 x i64] }, ptr %l91
  store { i64, [1 x i64] } %t172, ptr %l12
  %t173 = load ptr, ptr %l0, !tbaa !29
  store ptr %t173, ptr %l92, !tbaa !29
  %t174 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t174, ptr %l93
  %t175 = load i32, ptr %l11, !tbaa !23
  %t177 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t175)
  store %"compiler/mir:Place" %t177, ptr %l95
  br label %bb34
bb34:
  %t178 = load { i64, [1 x i64] }, ptr %l12
  %t179 = load i32, ptr %l7, !tbaa !23
  %t180 = load { i64, [4 x i64] }, ptr %l8
  %t181 = load i32, ptr %l6, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t182
  %t183 = getelementptr { i64, [4 x i64] }, ptr %t182, i32 0, i32 0
  store i64 2, ptr %t183
  %t185 = insertvalue { i32, i64 } undef, i32 %t181, 0
  %t186 = insertvalue { i32, i64 } %t185, i64 0, 1
  %t187 = getelementptr { i64, [4 x i64] }, ptr %t182, i32 0, i32 1
  store { i32, i64 } %t186, ptr %t187
  %t188 = load { i64, [4 x i64] }, ptr %t182
  store { i64, [15 x i64] } zeroinitializer, ptr %t189
  %t190 = getelementptr { i64, [15 x i64] }, ptr %t189, i32 0, i32 0
  store i64 8, ptr %t190
  %t192 = insertvalue { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } } undef, { i64, [1 x i64] } %t178, 0
  %t194 = insertvalue { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } } %t192, i32 %t179, 1
  %t196 = insertvalue { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } } %t194, { i64, [4 x i64] } %t180, 2
  %t198 = insertvalue { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } } %t196, { i64, [4 x i64] } %t188, 3
  %t199 = getelementptr { i64, [15 x i64] }, ptr %t189, i32 0, i32 1
  store { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } } %t198, ptr %t199
  %t200 = load { i64, [15 x i64] }, ptr %t189
  store { i64, [21 x i64] } zeroinitializer, ptr %t201
  %t202 = getelementptr { i64, [21 x i64] }, ptr %t201, i32 0, i32 0
  store i64 0, ptr %t202
  %t203 = load %"compiler/source:Span", ptr %l93
  %t204 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t203, 0
  %t205 = load %"compiler/mir:Place", ptr %l95
  %t206 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t204, %"compiler/mir:Place" %t205, 1
  %t208 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t206, { i64, [15 x i64] } %t200, 2
  %t209 = getelementptr { i64, [21 x i64] }, ptr %t201, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t208, ptr %t209
  %t210 = load { i64, [21 x i64] }, ptr %t201
  %t212 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t210, ptr %t212
  %t213 = load ptr, ptr %l92, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s0, ptr %t213, ptr %t212)
  br label %bb35
bb35:
  %t215 = load ptr, ptr %l0, !tbaa !29
  %t216 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  %t217 = load %"compiler/source:Span", ptr %l3
  %t221 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2etemp(ptr %v0, ptr %t215, i32 %t216, %"compiler/source:Span" %t217)
  store i32 %t221, ptr %l107
  br label %bb36
bb36:
  %t222 = load i32, ptr %l107, !tbaa !23
  store i32 %t222, ptr %l13, !tbaa !23
  %t223 = load ptr, ptr %l0, !tbaa !29
  store ptr %t223, ptr %l108, !tbaa !29
  %t224 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t224, ptr %l109
  %t225 = load i32, ptr %l13, !tbaa !23
  %t227 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t225)
  store %"compiler/mir:Place" %t227, ptr %l111
  br label %bb37
bb37:
  %t228 = load ptr, ptr %l0, !tbaa !29
  %t230 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2econstI64(ptr %v0, ptr %t228, i64 0)
  store { i64, [4 x i64] } %t230, ptr %l113
  br label %bb38
bb38:
  store { i64, [15 x i64] } zeroinitializer, ptr %t231
  %t232 = getelementptr { i64, [15 x i64] }, ptr %t231, i32 0, i32 0
  store i64 0, ptr %t232
  %t233 = load { i64, [4 x i64] }, ptr %l113
  %t234 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t233, 0
  %t235 = getelementptr { i64, [15 x i64] }, ptr %t231, i32 0, i32 1
  store { { i64, [4 x i64] } } %t234, ptr %t235
  %t236 = load { i64, [15 x i64] }, ptr %t231
  store { i64, [21 x i64] } zeroinitializer, ptr %t237
  %t238 = getelementptr { i64, [21 x i64] }, ptr %t237, i32 0, i32 0
  store i64 0, ptr %t238
  %t239 = load %"compiler/source:Span", ptr %l109
  %t240 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t239, 0
  %t241 = load %"compiler/mir:Place", ptr %l111
  %t242 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t240, %"compiler/mir:Place" %t241, 1
  %t244 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t242, { i64, [15 x i64] } %t236, 2
  %t245 = getelementptr { i64, [21 x i64] }, ptr %t237, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t244, ptr %t245
  %t246 = load { i64, [21 x i64] }, ptr %t237
  %t248 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t246, ptr %t248
  %t249 = load ptr, ptr %l108, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s0, ptr %t249, ptr %t248)
  br label %bb39
bb39:
  %t251 = load ptr, ptr %l0, !tbaa !29
  %t253 = getelementptr %"compiler/lower:lowering", ptr %t251, i32 0, i32 14
  store ptr %t253, ptr %l118, !tbaa !29
  %t254 = load i32, ptr %l11, !tbaa !23
  %t255 = load i32, ptr %l13, !tbaa !23
  %t256 = load i32, ptr %l6, !tbaa !23
  %t257 = load i32, ptr %l7, !tbaa !23
  %t258 = load { i64, [1 x i64] }, ptr %l12
  %t264 = call %"compiler/lower:collectCtx" @compiler_2flower_3acollectCtx_2ector(ptr %s0, i32 %t254, i32 %t255, i32 %t256, i32 %t257, { i64, [1 x i64] } %t258)
  store %"compiler/lower:collectCtx" %t264, ptr %l124
  br label %bb40
bb40:
  %t265 = load ptr, ptr %l118, !tbaa !29
  %t266 = load %"compiler/lower:collectCtx", ptr %l124
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3acollectCtx_3e_2e_H653cfca5a0404061ead7e6ea50e2c820(ptr %v0, ptr %t265, %"compiler/lower:collectCtx" %t266)
  br label %bb41
bb41:
  %t267 = load ptr, ptr %l0, !tbaa !29
  %t268 = load ptr, ptr %l1, !tbaa !29
  %t270 = getelementptr %"compiler/typed:Collect", ptr %t268, i32 0, i32 1
  %t271 = load ptr, ptr %t270, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eblock(ptr %v0, ptr %v1, ptr %t267, ptr %t271)
  br label %bb42
bb42:
  %t274 = load ptr, ptr %l0, !tbaa !29
  %t276 = getelementptr %"compiler/lower:lowering", ptr %t274, i32 0, i32 14
  %t278 = call { i32, %"compiler/lower:collectCtx" } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3acollectCtx_3e_2e_Hcb64b7cee1ab394e20e0c0dd5741806d(ptr %v0, ptr %t276)
  %t279 = extractvalue { i32, %"compiler/lower:collectCtx" } %t278, 1
  %t280 = extractvalue { i32, %"compiler/lower:collectCtx" } %t278, 0
  store i32 %t280, ptr %l132
  %t281 = icmp ne i32 %t280, 0
  br i1 %t281, label %bb44, label %ok.282
ok.282:
  store %"compiler/lower:collectCtx" %t279, ptr %l131
  br label %bb43
bb43:
  %t283 = load %"compiler/lower:collectCtx", ptr %l131
  store %"compiler/lower:collectCtx" %t283, ptr %l128
  br label %bb46
bb44:
  br label %bb45
bb45:
  call void @__olang_ert_req_clear()
  br label %bb46
bb46:
  %t284 = load ptr, ptr %l0, !tbaa !29
  %t286 = getelementptr %"compiler/lower:lowering", ptr %t284, i32 0, i32 7
  %t287 = load i1, ptr %t286, !tbaa !21
  br i1 %t287, label %bb47, label %bb48
bb47:
  store { i64, [4 x i64] } zeroinitializer, ptr %t289
  %t290 = getelementptr { i64, [4 x i64] }, ptr %t289, i32 0, i32 0
  store i64 0, ptr %t290
  %t291 = load { i64, [4 x i64] }, ptr %t289
  call void @__olang_scope_close(ptr %s0)
  store { i64, [4 x i64] } %t291, ptr %rv
  br label %ret
bb48:
  br label %bb49
bb49:
  %t293 = load ptr, ptr %l0, !tbaa !29
  %t294 = load i32, ptr %l2, !tbaa !23
  %t295 = load %"compiler/source:Span", ptr %l3
  %t299 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2etemp(ptr %v0, ptr %t293, i32 %t294, %"compiler/source:Span" %t295)
  store i32 %t299, ptr %l139
  br label %bb50
bb50:
  %t300 = load i32, ptr %l139, !tbaa !23
  store i32 %t300, ptr %l14, !tbaa !23
  %t301 = load ptr, ptr %l0, !tbaa !29
  store ptr %t301, ptr %l140, !tbaa !29
  %t302 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t302, ptr %l141
  %t303 = load i32, ptr %l14, !tbaa !23
  %t305 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t303)
  store %"compiler/mir:Place" %t305, ptr %l143
  br label %bb51
bb51:
  %t306 = load { i64, [1 x i64] }, ptr %l12
  store { i64, [1 x i64] } %t306, ptr %l144
  %t307 = load i32, ptr %l2, !tbaa !23
  store i32 %t307, ptr %l145, !tbaa !23
  %t308 = load i32, ptr %l13, !tbaa !23
  %t310 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t308)
  store %"compiler/mir:Place" %t310, ptr %l147
  br label %bb52
bb52:
  store { i64, [4 x i64] } zeroinitializer, ptr %t311
  %t312 = getelementptr { i64, [4 x i64] }, ptr %t311, i32 0, i32 0
  store i64 1, ptr %t312
  %t313 = load %"compiler/mir:Place", ptr %l147
  %t314 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t313, 0
  %t315 = getelementptr { i64, [4 x i64] }, ptr %t311, i32 0, i32 1
  store { %"compiler/mir:Place" } %t314, ptr %t315
  %t316 = load { i64, [4 x i64] }, ptr %t311
  %t317 = load i32, ptr %l6, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t318
  %t319 = getelementptr { i64, [4 x i64] }, ptr %t318, i32 0, i32 0
  store i64 2, ptr %t319
  %t321 = insertvalue { i32, i64 } undef, i32 %t317, 0
  %t322 = insertvalue { i32, i64 } %t321, i64 0, 1
  %t323 = getelementptr { i64, [4 x i64] }, ptr %t318, i32 0, i32 1
  store { i32, i64 } %t322, ptr %t323
  %t324 = load { i64, [4 x i64] }, ptr %t318
  store { i64, [15 x i64] } zeroinitializer, ptr %t325
  %t326 = getelementptr { i64, [15 x i64] }, ptr %t325, i32 0, i32 0
  store i64 8, ptr %t326
  %t327 = load { i64, [1 x i64] }, ptr %l144
  %t328 = insertvalue { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } } undef, { i64, [1 x i64] } %t327, 0
  %t329 = load i32, ptr %l145, !tbaa !23
  %t330 = insertvalue { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } } %t328, i32 %t329, 1
  %t332 = insertvalue { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } } %t330, { i64, [4 x i64] } %t316, 2
  %t334 = insertvalue { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } } %t332, { i64, [4 x i64] } %t324, 3
  %t335 = getelementptr { i64, [15 x i64] }, ptr %t325, i32 0, i32 1
  store { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } } %t334, ptr %t335
  %t336 = load { i64, [15 x i64] }, ptr %t325
  store { i64, [21 x i64] } zeroinitializer, ptr %t337
  %t338 = getelementptr { i64, [21 x i64] }, ptr %t337, i32 0, i32 0
  store i64 0, ptr %t338
  %t339 = load %"compiler/source:Span", ptr %l141
  %t340 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t339, 0
  %t341 = load %"compiler/mir:Place", ptr %l143
  %t342 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t340, %"compiler/mir:Place" %t341, 1
  %t344 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t342, { i64, [15 x i64] } %t336, 2
  %t345 = getelementptr { i64, [21 x i64] }, ptr %t337, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t344, ptr %t345
  %t346 = load { i64, [21 x i64] }, ptr %t337
  %t348 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t346, ptr %t348
  %t349 = load ptr, ptr %l140, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s0, ptr %t349, ptr %t348)
  br label %bb53
bb53:
  %t351 = load ptr, ptr %l0, !tbaa !29
  %t353 = getelementptr %"compiler/lower:lowering", ptr %t351, i32 0, i32 3
  store ptr %t353, ptr %l155, !tbaa !29
  %t354 = load i32, ptr %l14, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t355
  %t356 = getelementptr { i64, [2 x i64] }, ptr %t355, i32 0, i32 0
  store i64 1, ptr %t356
  %t358 = insertvalue { i32 } undef, i32 %t354, 0
  %t359 = getelementptr { i64, [2 x i64] }, ptr %t355, i32 0, i32 1
  store { i32 } %t358, ptr %t359
  %t360 = load { i64, [2 x i64] }, ptr %t355
  store { i64, [2 x i64] } %t360, ptr %l157
  %t361 = load ptr, ptr %l4, !tbaa !29
  store ptr %t361, ptr %l158, !tbaa !29
  %t362 = load ptr, ptr %l4, !tbaa !29
  %t363 = load i32, ptr %l2, !tbaa !23
  %t366 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t362, i32 %t363)
  store i32 %t366, ptr %l161
  br label %bb54
bb54:
  %t367 = load ptr, ptr %l158, !tbaa !29
  %t368 = load i32, ptr %l161, !tbaa !23
  %t369 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t367, i32 %t368)
  store i1 %t369, ptr %l162
  br label %bb55
bb55:
  %t370 = load i1, ptr %l162, !tbaa !21
  br i1 %t370, label %bb56, label %bb57
bb56:
  store { i64, [1 x i64] } zeroinitializer, ptr %t371
  %t372 = getelementptr { i64, [1 x i64] }, ptr %t371, i32 0, i32 0
  store i64 3, ptr %t372
  %t373 = load { i64, [1 x i64] }, ptr %t371
  %t374 = mul i64 1, 16
  %t375 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t374)
  %t376 = insertvalue { i64, ptr } undef, i64 1, 0
  %t377 = insertvalue { i64, ptr } %t376, ptr %t375, 1
  store { i64, ptr } %t377, ptr %l165, !tbaa !27
  %t379 = getelementptr { i64, ptr }, ptr %l165, i32 0, i32 1
  %t380 = load ptr, ptr %t379, !tbaa !27
  %t381 = getelementptr { i64, [1 x i64] }, ptr %t380, i64 0
  store { i64, [1 x i64] } %t373, ptr %t381
  %t382 = load { i64, ptr }, ptr %l165, !tbaa !27
  store { i64, ptr } %t382, ptr %l163, !tbaa !27
  br label %bb58
bb57:
  %t383 = mul i64 0, 16
  %t384 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t383)
  %t385 = insertvalue { i64, ptr } undef, i64 0, 0
  %t386 = insertvalue { i64, ptr } %t385, ptr %t384, 1
  store { i64, ptr } %t386, ptr %l163, !tbaa !27
  br label %bb58
bb58:
  %t388 = load ptr, ptr %l155, !tbaa !29
  %t389 = load { i64, [2 x i64] }, ptr %l157
  %t390 = load { i64, ptr }, ptr %l163, !tbaa !27
  %t391 = call %"compiler/mir:Place" @compiler_2fmir_2ecompiler_2fmir_3aFn_2ePlace(ptr %v0, ptr %s0, ptr %t388, { i64, [2 x i64] } %t389, { i64, ptr } %t390)
  store %"compiler/mir:Place" %t391, ptr %l167
  br label %bb59
bb59:
  %t392 = load %"compiler/mir:Place", ptr %l167
  %t393 = load ptr, ptr %l0, !tbaa !29
  store ptr %t393, ptr %l168, !tbaa !29
  %t394 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t394, ptr %l169
  store %"compiler/mir:Place" %t392, ptr %l170
  %t396 = load ptr, ptr %l0, !tbaa !29
  %t398 = getelementptr %"compiler/lower:lowering", ptr %t396, i32 0, i32 3
  %t399 = load i32, ptr %l11, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t400
  %t401 = getelementptr { i64, [2 x i64] }, ptr %t400, i32 0, i32 0
  store i64 1, ptr %t401
  %t403 = insertvalue { i32 } undef, i32 %t399, 0
  %t404 = getelementptr { i64, [2 x i64] }, ptr %t400, i32 0, i32 1
  store { i32 } %t403, ptr %t404
  %t405 = load { i64, [2 x i64] }, ptr %t400
  store { i64, [1 x i64] } zeroinitializer, ptr %t406
  %t407 = getelementptr { i64, [1 x i64] }, ptr %t406, i32 0, i32 0
  store i64 3, ptr %t407
  %t408 = load { i64, [1 x i64] }, ptr %t406
  %t409 = mul i64 1, 16
  %t410 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t409)
  %t411 = insertvalue { i64, ptr } undef, i64 1, 0
  %t412 = insertvalue { i64, ptr } %t411, ptr %t410, 1
  store { i64, ptr } %t412, ptr %l176, !tbaa !27
  %t414 = getelementptr { i64, ptr }, ptr %l176, i32 0, i32 1
  %t415 = load ptr, ptr %t414, !tbaa !27
  %t416 = getelementptr { i64, [1 x i64] }, ptr %t415, i64 0
  store { i64, [1 x i64] } %t408, ptr %t416
  %t419 = load { i64, ptr }, ptr %l176, !tbaa !27
  %t420 = call %"compiler/mir:Place" @compiler_2fmir_2ecompiler_2fmir_3aFn_2ePlace(ptr %v0, ptr %s0, ptr %t398, { i64, [2 x i64] } %t405, { i64, ptr } %t419)
  store %"compiler/mir:Place" %t420, ptr %l177
  br label %bb60
bb60:
  %t421 = load i32, ptr %l13, !tbaa !23
  %t423 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t421)
  store %"compiler/mir:Place" %t423, ptr %l179
  br label %bb61
bb61:
  store { i64, [4 x i64] } zeroinitializer, ptr %t424
  %t425 = getelementptr { i64, [4 x i64] }, ptr %t424, i32 0, i32 0
  store i64 1, ptr %t425
  %t426 = load %"compiler/mir:Place", ptr %l179
  %t427 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t426, 0
  %t428 = getelementptr { i64, [4 x i64] }, ptr %t424, i32 0, i32 1
  store { %"compiler/mir:Place" } %t427, ptr %t428
  %t429 = load { i64, [4 x i64] }, ptr %t424
  store { i64, [21 x i64] } zeroinitializer, ptr %t430
  %t431 = getelementptr { i64, [21 x i64] }, ptr %t430, i32 0, i32 0
  store i64 10, ptr %t431
  %t432 = load %"compiler/source:Span", ptr %l169
  %t433 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", %"compiler/mir:Place", { i64, [4 x i64] } } undef, %"compiler/source:Span" %t432, 0
  %t434 = load %"compiler/mir:Place", ptr %l170
  %t435 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", %"compiler/mir:Place", { i64, [4 x i64] } } %t433, %"compiler/mir:Place" %t434, 1
  %t436 = load %"compiler/mir:Place", ptr %l177
  %t437 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", %"compiler/mir:Place", { i64, [4 x i64] } } %t435, %"compiler/mir:Place" %t436, 2
  %t439 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", %"compiler/mir:Place", { i64, [4 x i64] } } %t437, { i64, [4 x i64] } %t429, 3
  %t440 = getelementptr { i64, [21 x i64] }, ptr %t430, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Place", %"compiler/mir:Place", { i64, [4 x i64] } } %t439, ptr %t440
  %t441 = load { i64, [21 x i64] }, ptr %t430
  %t443 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t441, ptr %t443
  %t444 = load ptr, ptr %l168, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s0, ptr %t444, ptr %t443)
  br label %bb62
bb62:
  %t446 = load i32, ptr %l14, !tbaa !23
  %t448 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t446)
  store %"compiler/mir:Place" %t448, ptr %l184
  br label %bb63
bb63:
  store { i64, [4 x i64] } zeroinitializer, ptr %t449
  %t450 = getelementptr { i64, [4 x i64] }, ptr %t449, i32 0, i32 0
  store i64 1, ptr %t450
  %t451 = load %"compiler/mir:Place", ptr %l184
  %t452 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t451, 0
  %t453 = getelementptr { i64, [4 x i64] }, ptr %t449, i32 0, i32 1
  store { %"compiler/mir:Place" } %t452, ptr %t453
  %t454 = load { i64, [4 x i64] }, ptr %t449
  call void @__olang_scope_close(ptr %s0)
  store { i64, [4 x i64] } %t454, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2econd(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca { i64, [4 x i64] }
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l9 = alloca { i64, [4 x i64] }
  %l10 = alloca { i64, [4 x i64] }
  %l15 = alloca { i64, [4 x i64] }
  %l22 = alloca i32
  %l25 = alloca i32
  %l28 = alloca i32
  %l34 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l40 = alloca { i64, [4 x i64] }
  %l41 = alloca ptr
  %l42 = alloca %"compiler/source:Span"
  %l44 = alloca %"compiler/mir:Place"
  %l57 = alloca { i64, [4 x i64] }
  %l58 = alloca ptr
  %l59 = alloca %"compiler/source:Span"
  %l61 = alloca %"compiler/mir:Place"
  %l71 = alloca %"compiler/mir:Place"
  %s0 = alloca %olang.scope
  %rv = alloca { i64, [4 x i64] }
  %t16 = alloca { i64, [4 x i64] }, align 8
  %t44 = alloca { i64, [7 x i64] }, align 8
  %t78 = alloca { i64, [15 x i64] }, align 8
  %t84 = alloca { i64, [21 x i64] }, align 8
  %t121 = alloca { i64, [15 x i64] }, align 8
  %t127 = alloca { i64, [21 x i64] }, align 8
  %t151 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store %"compiler/source:Span" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t4 = getelementptr %"compiler/typed:Cond", ptr %t2, i32 0, i32 0
  %t5 = load ptr, ptr %t4, !tbaa !29
  %t9 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v1, ptr %t1, ptr %t5)
  store { i64, [4 x i64] } %t9, ptr %l15
  br label %bb1
bb1:
  %t10 = load { i64, [4 x i64] }, ptr %l15
  store { i64, [4 x i64] } %t10, ptr %l4
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/lower:lowering", ptr %t11, i32 0, i32 7
  %t14 = load i1, ptr %t13, !tbaa !21
  br i1 %t14, label %bb2, label %bb3
bb2:
  store { i64, [4 x i64] } zeroinitializer, ptr %t16
  %t17 = getelementptr { i64, [4 x i64] }, ptr %t16, i32 0, i32 0
  store i64 0, ptr %t17
  %t18 = load { i64, [4 x i64] }, ptr %t16
  call void @__olang_scope_close(ptr %s0)
  store { i64, [4 x i64] } %t18, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = load %"compiler/source:Span", ptr %l3
  %t26 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2etemp(ptr %v0, ptr %t20, i32 %a2, %"compiler/source:Span" %t22)
  store i32 %t26, ptr %l22
  br label %bb5
bb5:
  %t27 = load i32, ptr %l22, !tbaa !23
  store i32 %t27, ptr %l5, !tbaa !23
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/lower:lowering", ptr %t28, i32 0, i32 3
  %t32 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t30)
  store i32 %t32, ptr %l25
  br label %bb6
bb6:
  %t33 = load i32, ptr %l25, !tbaa !23
  store i32 %t33, ptr %l6, !tbaa !23
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/lower:lowering", ptr %t34, i32 0, i32 3
  %t38 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t36)
  store i32 %t38, ptr %l28
  br label %bb7
bb7:
  %t39 = load i32, ptr %l28, !tbaa !23
  store i32 %t39, ptr %l7, !tbaa !23
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t41 = load { i64, [4 x i64] }, ptr %l4
  %t42 = load i32, ptr %l6, !tbaa !23
  %t43 = load i32, ptr %l7, !tbaa !23
  store { i64, [7 x i64] } zeroinitializer, ptr %t44
  %t45 = getelementptr { i64, [7 x i64] }, ptr %t44, i32 0, i32 0
  store i64 2, ptr %t45
  %t47 = insertvalue { { i64, [4 x i64] }, i32, i32 } undef, { i64, [4 x i64] } %t41, 0
  %t49 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t47, i32 %t42, 1
  %t51 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t49, i32 %t43, 2
  %t52 = getelementptr { i64, [7 x i64] }, ptr %t44, i32 0, i32 1
  store { { i64, [4 x i64] }, i32, i32 } %t51, ptr %t52
  %t53 = load { i64, [7 x i64] }, ptr %t44
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t40, { i64, [7 x i64] } %t53)
  br label %bb8
bb8:
  %t56 = load ptr, ptr @__olang_prog_scope
  %t57 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aBlockId_3e(ptr %t56)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t57, ptr %l34
  br label %bb9
bb9:
  %t58 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l34
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t58, ptr %l8
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t60 = load i32, ptr %l6, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t59, i32 %t60)
  br label %bb10
bb10:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t64 = load ptr, ptr %l1, !tbaa !29
  %t66 = getelementptr %"compiler/typed:Cond", ptr %t64, i32 0, i32 1
  %t67 = load ptr, ptr %t66, !tbaa !29
  %t70 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v1, ptr %t63, ptr %t67)
  store { i64, [4 x i64] } %t70, ptr %l40
  br label %bb11
bb11:
  %t71 = load { i64, [4 x i64] }, ptr %l40
  store { i64, [4 x i64] } %t71, ptr %l9
  %t72 = load ptr, ptr %l0, !tbaa !29
  store ptr %t72, ptr %l41, !tbaa !29
  %t73 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t73, ptr %l42
  %t74 = load i32, ptr %l5, !tbaa !23
  %t76 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t74)
  store %"compiler/mir:Place" %t76, ptr %l44
  br label %bb12
bb12:
  %t77 = load { i64, [4 x i64] }, ptr %l9
  store { i64, [15 x i64] } zeroinitializer, ptr %t78
  %t79 = getelementptr { i64, [15 x i64] }, ptr %t78, i32 0, i32 0
  store i64 0, ptr %t79
  %t81 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t77, 0
  %t82 = getelementptr { i64, [15 x i64] }, ptr %t78, i32 0, i32 1
  store { { i64, [4 x i64] } } %t81, ptr %t82
  %t83 = load { i64, [15 x i64] }, ptr %t78
  store { i64, [21 x i64] } zeroinitializer, ptr %t84
  %t85 = getelementptr { i64, [21 x i64] }, ptr %t84, i32 0, i32 0
  store i64 0, ptr %t85
  %t86 = load %"compiler/source:Span", ptr %l42
  %t87 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t86, 0
  %t88 = load %"compiler/mir:Place", ptr %l44
  %t89 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t87, %"compiler/mir:Place" %t88, 1
  %t91 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t89, { i64, [15 x i64] } %t83, 2
  %t92 = getelementptr { i64, [21 x i64] }, ptr %t84, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t91, ptr %t92
  %t93 = load { i64, [21 x i64] }, ptr %t84
  %t95 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t93, ptr %t95
  %t96 = load ptr, ptr %l41, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s0, ptr %t96, ptr %t95)
  br label %bb13
bb13:
  %t98 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eleaveOpen(ptr %v0, ptr %s0, ptr %t98, ptr %l8)
  br label %bb14
bb14:
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t102 = load i32, ptr %l7, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t101, i32 %t102)
  br label %bb15
bb15:
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t106 = load ptr, ptr %l1, !tbaa !29
  %t108 = getelementptr %"compiler/typed:Cond", ptr %t106, i32 0, i32 2
  %t109 = load ptr, ptr %t108, !tbaa !29
  %t113 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v1, ptr %t105, ptr %t109)
  store { i64, [4 x i64] } %t113, ptr %l57
  br label %bb16
bb16:
  %t114 = load { i64, [4 x i64] }, ptr %l57
  store { i64, [4 x i64] } %t114, ptr %l10
  %t115 = load ptr, ptr %l0, !tbaa !29
  store ptr %t115, ptr %l58, !tbaa !29
  %t116 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t116, ptr %l59
  %t117 = load i32, ptr %l5, !tbaa !23
  %t119 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t117)
  store %"compiler/mir:Place" %t119, ptr %l61
  br label %bb17
bb17:
  %t120 = load { i64, [4 x i64] }, ptr %l10
  store { i64, [15 x i64] } zeroinitializer, ptr %t121
  %t122 = getelementptr { i64, [15 x i64] }, ptr %t121, i32 0, i32 0
  store i64 0, ptr %t122
  %t124 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t120, 0
  %t125 = getelementptr { i64, [15 x i64] }, ptr %t121, i32 0, i32 1
  store { { i64, [4 x i64] } } %t124, ptr %t125
  %t126 = load { i64, [15 x i64] }, ptr %t121
  store { i64, [21 x i64] } zeroinitializer, ptr %t127
  %t128 = getelementptr { i64, [21 x i64] }, ptr %t127, i32 0, i32 0
  store i64 0, ptr %t128
  %t129 = load %"compiler/source:Span", ptr %l59
  %t130 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t129, 0
  %t131 = load %"compiler/mir:Place", ptr %l61
  %t132 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t130, %"compiler/mir:Place" %t131, 1
  %t134 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t132, { i64, [15 x i64] } %t126, 2
  %t135 = getelementptr { i64, [21 x i64] }, ptr %t127, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t134, ptr %t135
  %t136 = load { i64, [21 x i64] }, ptr %t127
  %t138 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t136, ptr %t138
  %t139 = load ptr, ptr %l58, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s0, ptr %t139, ptr %t138)
  br label %bb18
bb18:
  %t141 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eleaveOpen(ptr %v0, ptr %s0, ptr %t141, ptr %l8)
  br label %bb19
bb19:
  %t144 = load ptr, ptr %l0, !tbaa !29
  %t145 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l8
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2epatch(ptr %v0, ptr %s0, ptr %t144, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t145)
  br label %bb20
bb20:
  %t148 = load i32, ptr %l5, !tbaa !23
  %t150 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t148)
  store %"compiler/mir:Place" %t150, ptr %l71
  br label %bb21
bb21:
  store { i64, [4 x i64] } zeroinitializer, ptr %t151
  %t152 = getelementptr { i64, [4 x i64] }, ptr %t151, i32 0, i32 0
  store i64 1, ptr %t152
  %t153 = load %"compiler/mir:Place", ptr %l71
  %t154 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t153, 0
  %t155 = getelementptr { i64, [4 x i64] }, ptr %t151, i32 0, i32 1
  store { %"compiler/mir:Place" } %t154, ptr %t155
  %t156 = load { i64, [4 x i64] }, ptr %t151
  call void @__olang_scope_close(ptr %s0)
  store { i64, [4 x i64] } %t156, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2econstI64(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %rv = alloca { i64, [4 x i64] }
  %t3 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t3
  %t4 = getelementptr { i64, [4 x i64] }, ptr %t3, i32 0, i32 0
  store i64 2, ptr %t4
  %t6 = insertvalue { i32, i64 } undef, i32 %t1, 0
  %t8 = insertvalue { i32, i64 } %t6, i64 %a1, 1
  %t9 = getelementptr { i64, [4 x i64] }, ptr %t3, i32 0, i32 1
  store { i32, i64 } %t8, ptr %t9
  %t10 = load { i64, [4 x i64] }, ptr %t3
  store { i64, [4 x i64] } %t10, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3alowering_2ecopiesArray(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l5 = alloca i1
  %l10 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2evalueArray(ptr %v0, ptr %t1, i32 %a2)
  store i1 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i1, ptr %l5, !tbaa !21
  %t7 = xor i1 %t6, true
  br i1 %t7, label %bb2, label %bb3
bb2:
  store i1 false, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t14 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2ecopiesValue(ptr %v0, ptr %v1, ptr %t10, ptr %a1)
  store i1 %t14, ptr %l10
  br label %bb5
bb5:
  %t15 = load i1, ptr %l10, !tbaa !21
  store i1 %t15, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3alowering_2ecopiesValue(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i1
  %l8 = alloca ptr
  %l9 = alloca i1
  %l12 = alloca ptr
  %l13 = alloca i1
  %l22 = alloca i1
  %l26 = alloca i1
  %l27 = alloca { i64, ptr }
  %l29 = alloca ptr
  %l32 = alloca i1
  %l33 = alloca ptr
  %l34 = alloca { i64, ptr }
  %l36 = alloca i32
  %l37 = alloca i1
  %l38 = alloca i1
  %l40 = alloca { i64, ptr }
  %l42 = alloca i1
  %l43 = alloca ptr
  %l44 = alloca i1
  %l50 = alloca i1
  %l51 = alloca ptr
  %l52 = alloca i1
  %l59 = alloca i1
  %l60 = alloca ptr
  %l61 = alloca i1
  %l70 = alloca i1
  %l71 = alloca ptr
  %l77 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t2 = load ptr, ptr %l8, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l8, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l9, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l9, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb6
bb5:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb60
bb6:
  %t10 = load ptr, ptr %l1, !tbaa !29
  store ptr %t10, ptr %l12, !tbaa !29
  store i1 false, ptr %l13, !tbaa !21
  %t11 = load ptr, ptr %l12, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb7, label %bb8
bb7:
  %t14 = load ptr, ptr %l12, !tbaa !29
  %t15 = load i64, ptr %t14
  %t17 = icmp eq i64 %t15, 9
  store i1 %t17, ptr %l13, !tbaa !21
  br label %bb8
bb8:
  %t18 = load i1, ptr %l13, !tbaa !21
  br i1 %t18, label %bb9, label %bb10
bb9:
  %t19 = load ptr, ptr %l1, !tbaa !29
  %t21 = getelementptr { i64, [5 x i64] }, ptr %t19, i32 0, i32 1
  %t22 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t21, i32 0, i32 2
  %t23 = load i32, ptr %t22
  store i32 %t23, ptr %l2
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr { i64, [5 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t27, i32 0, i32 4
  %t29 = load { i64, ptr }, ptr %t28
  store { i64, ptr } %t29, ptr %l3, !tbaa !27
  br label %bb11
bb10:
  br label %bb28
bb11:
  %t31 = load i32, ptr %l2
  %t33 = trunc i64 20 to i32
  %t34 = icmp eq i32 %t31, %t33
  br i1 %t34, label %bb12, label %bb13
bb12:
  %t36 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t38 = extractvalue { i64, ptr } %t36, 0
  %t40 = icmp eq i64 %t38, 1
  store i1 %t40, ptr %l22, !tbaa !21
  br label %bb14
bb13:
  store i1 false, ptr %l22, !tbaa !21
  br label %bb14
bb14:
  %t42 = load i1, ptr %l22, !tbaa !21
  br i1 %t42, label %bb15, label %bb16
bb15:
  %t43 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t43, ptr %l27, !tbaa !27
  %t44 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !27
  %t46 = getelementptr ptr, ptr %t45, i64 0
  %t47 = load ptr, ptr %t46, !tbaa !39
  %t49 = call ptr @compiler_2flower_2ederefOf(ptr %v1, ptr %t47)
  store ptr %t49, ptr %l29
  br label %bb17
bb16:
  store i1 false, ptr %l26, !tbaa !21
  br label %bb27
bb17:
  %t50 = load ptr, ptr %l29, !tbaa !29
  %t51 = icmp eq ptr %t50, null
  %t53 = xor i1 %t51, true
  br i1 %t53, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l32, !tbaa !21
  br label %bb26
bb19:
  %t55 = load ptr, ptr %l0, !tbaa !29
  store ptr %t55, ptr %l33, !tbaa !29
  %t56 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t56, ptr %l34, !tbaa !27
  %t57 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t58 = load ptr, ptr %t57, !tbaa !27
  %t59 = getelementptr ptr, ptr %t58, i64 0
  %t60 = load ptr, ptr %t59, !tbaa !39
  %t62 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t60)
  store i32 %t62, ptr %l36
  br label %bb20
bb20:
  %t63 = load ptr, ptr %l33, !tbaa !29
  %t64 = load i32, ptr %l36, !tbaa !23
  %t65 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2evalueArray(ptr %v0, ptr %t63, i32 %t64)
  store i1 %t65, ptr %l37
  br label %bb21
bb21:
  %t66 = load i1, ptr %l37, !tbaa !21
  br i1 %t66, label %bb22, label %bb23
bb22:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t68 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t68, ptr %l40, !tbaa !27
  %t69 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !27
  %t71 = getelementptr ptr, ptr %t70, i64 0
  %t72 = load ptr, ptr %t71, !tbaa !39
  %t75 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2ecopiesValue(ptr %v0, ptr %v1, ptr %t67, ptr %t72)
  store i1 %t75, ptr %l42
  br label %bb24
bb23:
  store i1 false, ptr %l38, !tbaa !21
  br label %bb25
bb24:
  %t76 = load i1, ptr %l42, !tbaa !21
  store i1 %t76, ptr %l38, !tbaa !21
  br label %bb25
bb25:
  %t77 = load i1, ptr %l38, !tbaa !21
  store i1 %t77, ptr %l32, !tbaa !21
  br label %bb26
bb26:
  %t78 = load i1, ptr %l32, !tbaa !21
  store i1 %t78, ptr %l26, !tbaa !21
  br label %bb27
bb27:
  %t79 = load i1, ptr %l26, !tbaa !21
  store i1 %t79, ptr %l7, !tbaa !21
  br label %bb60
bb28:
  %t80 = load ptr, ptr %l1, !tbaa !29
  store ptr %t80, ptr %l43, !tbaa !29
  store i1 false, ptr %l44, !tbaa !21
  %t81 = load ptr, ptr %l43, !tbaa !29
  %t82 = icmp ne ptr %t81, null
  br i1 %t82, label %bb29, label %bb30
bb29:
  %t84 = load ptr, ptr %l43, !tbaa !29
  %t85 = load i64, ptr %t84
  %t87 = icmp eq i64 %t85, 6
  store i1 %t87, ptr %l44, !tbaa !21
  br label %bb30
bb30:
  %t88 = load i1, ptr %l44, !tbaa !21
  br i1 %t88, label %bb31, label %bb32
bb31:
  %t89 = load ptr, ptr %l1, !tbaa !29
  %t91 = getelementptr { i64, [5 x i64] }, ptr %t89, i32 0, i32 1
  %t92 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t91, i32 0, i32 2
  %t93 = load ptr, ptr %t92
  store ptr %t93, ptr %l4, !tbaa !29
  br label %bb33
bb32:
  br label %bb35
bb33:
  %t95 = load ptr, ptr %l4, !tbaa !29
  %t97 = call i1 @compiler_2ftyped_2eScopedCall(ptr %v1, ptr %t95)
  store i1 %t97, ptr %l50
  br label %bb34
bb34:
  %t98 = load i1, ptr %l50, !tbaa !21
  store i1 %t98, ptr %l7, !tbaa !21
  br label %bb60
bb35:
  %t99 = load ptr, ptr %l1, !tbaa !29
  store ptr %t99, ptr %l51, !tbaa !29
  store i1 false, ptr %l52, !tbaa !21
  %t100 = load ptr, ptr %l51, !tbaa !29
  %t101 = icmp ne ptr %t100, null
  br i1 %t101, label %bb36, label %bb37
bb36:
  %t103 = load ptr, ptr %l51, !tbaa !29
  %t104 = load i64, ptr %t103
  %t106 = icmp eq i64 %t104, 17
  store i1 %t106, ptr %l52, !tbaa !21
  br label %bb37
bb37:
  %t107 = load i1, ptr %l52, !tbaa !21
  br i1 %t107, label %bb38, label %bb39
bb38:
  %t108 = load ptr, ptr %l1, !tbaa !29
  %t110 = getelementptr { i64, [5 x i64] }, ptr %t108, i32 0, i32 1
  %t111 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t110, i32 0, i32 2
  %t112 = load ptr, ptr %t111
  store ptr %t112, ptr %l5, !tbaa !29
  br label %bb40
bb39:
  br label %bb42
bb40:
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t115 = load ptr, ptr %l5, !tbaa !29
  %t118 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2ecopiesValue(ptr %v0, ptr %v1, ptr %t114, ptr %t115)
  store i1 %t118, ptr %l59
  br label %bb41
bb41:
  %t119 = load i1, ptr %l59, !tbaa !21
  store i1 %t119, ptr %l7, !tbaa !21
  br label %bb60
bb42:
  %t120 = load ptr, ptr %l1, !tbaa !29
  store ptr %t120, ptr %l60, !tbaa !29
  store i1 false, ptr %l61, !tbaa !21
  %t121 = load ptr, ptr %l60, !tbaa !29
  %t122 = icmp ne ptr %t121, null
  br i1 %t122, label %bb43, label %bb44
bb43:
  %t124 = load ptr, ptr %l60, !tbaa !29
  %t125 = load i64, ptr %t124
  %t127 = icmp eq i64 %t125, 12
  store i1 %t127, ptr %l61, !tbaa !21
  br label %bb44
bb44:
  %t128 = load i1, ptr %l61, !tbaa !21
  br i1 %t128, label %bb45, label %bb46
bb45:
  %t129 = load ptr, ptr %l1, !tbaa !29
  %t131 = getelementptr { i64, [5 x i64] }, ptr %t129, i32 0, i32 1
  %t132 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t131, i32 0, i32 2
  %t133 = load ptr, ptr %t132
  store ptr %t133, ptr %l6, !tbaa !29
  br label %bb47
bb46:
  br label %bb55
bb47:
  %t135 = load ptr, ptr %l6, !tbaa !29
  %t137 = getelementptr %"compiler/typed:Seq", ptr %t135, i32 0, i32 1
  %t138 = load ptr, ptr %t137, !tbaa !29
  %t140 = icmp eq ptr %t138, null
  %t142 = xor i1 %t140, true
  br i1 %t142, label %bb48, label %bb49
bb48:
  %t144 = load ptr, ptr %l0, !tbaa !29
  store ptr %t144, ptr %l71, !tbaa !29
  %t145 = load ptr, ptr %l6, !tbaa !29
  %t147 = getelementptr %"compiler/typed:Seq", ptr %t145, i32 0, i32 1
  %t148 = load ptr, ptr %t147, !tbaa !29
  %t150 = icmp eq ptr %t148, null
  br i1 %t150, label %bb50, label %bb51
bb49:
  store i1 false, ptr %l70, !tbaa !21
  br label %bb54
bb50:
  call void @__olang_check_failed(ptr @olang_loc_755da8ec4c9a9682_903a5def85eef08e)
  unreachable
bb51:
  br label %bb52
bb52:
  %t152 = load ptr, ptr %l6, !tbaa !29
  %t154 = getelementptr %"compiler/typed:Seq", ptr %t152, i32 0, i32 1
  %t155 = load ptr, ptr %t154, !tbaa !29
  %t156 = load ptr, ptr %l71, !tbaa !29
  %t158 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2ecopiesValue(ptr %v0, ptr %v1, ptr %t156, ptr %t155)
  store i1 %t158, ptr %l77
  br label %bb53
bb53:
  %t159 = load i1, ptr %l77, !tbaa !21
  store i1 %t159, ptr %l70, !tbaa !21
  br label %bb54
bb54:
  %t160 = load i1, ptr %l70, !tbaa !21
  store i1 %t160, ptr %l7, !tbaa !21
  br label %bb60
bb55:
  br i1 true, label %bb56, label %bb57
bb56:
  br label %bb58
bb57:
  br label %bb59
bb58:
  store i1 false, ptr %l7, !tbaa !21
  br label %bb60
bb59:
  call void @__olang_check_failed(ptr @olang_loc_429a5ad7d8f4c2a0_c1ea905c2e39baec)
  unreachable
bb60:
  %t161 = load i1, ptr %l7, !tbaa !21
  store i1 %t161, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ecopyLocal(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca %"compiler/mir:Place"
  %rv = alloca { i64, [4 x i64] }
  %t4 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %a1)
  store %"compiler/mir:Place" %t3, ptr %l3
  br label %bb1
bb1:
  store { i64, [4 x i64] } zeroinitializer, ptr %t4
  %t5 = getelementptr { i64, [4 x i64] }, ptr %t4, i32 0, i32 0
  store i64 1, ptr %t5
  %t6 = load %"compiler/mir:Place", ptr %l3
  %t7 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t6, 0
  %t8 = getelementptr { i64, [4 x i64] }, ptr %t4, i32 0, i32 1
  store { %"compiler/mir:Place" } %t7, ptr %t8
  %t9 = load { i64, [4 x i64] }, ptr %t4
  store { i64, [4 x i64] } %t9, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2ederef(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca { i64, [4 x i64] }
  %l8 = alloca { i64, [4 x i64] }
  %l12 = alloca %"compiler/lower:pl"
  %l13 = alloca ptr
  %l14 = alloca { i64, [4 x i64] }
  %l16 = alloca i32
  %l18 = alloca i32
  %l19 = alloca ptr
  %l22 = alloca %"compiler/lower:pl"
  %l24 = alloca %"compiler/lower:pl"
  %rv = alloca %"compiler/lower:pl"
  %t13 = alloca { i64, [2 x i64] }, align 8
  %t33 = alloca { i64, [2 x i64] }, align 8
  %t41 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t6 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v1, ptr %t1, ptr %t2)
  store { i64, [4 x i64] } %t6, ptr %l8
  br label %bb1
bb1:
  %t7 = load { i64, [4 x i64] }, ptr %l8
  store { i64, [4 x i64] } %t7, ptr %l3
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/lower:lowering", ptr %t8, i32 0, i32 7
  %t11 = load i1, ptr %t10, !tbaa !21
  br i1 %t11, label %bb2, label %bb3
bb2:
  store { i64, [2 x i64] } zeroinitializer, ptr %t13
  %t14 = getelementptr { i64, [2 x i64] }, ptr %t13, i32 0, i32 0
  store i64 0, ptr %t14
  %t15 = load { i64, [2 x i64] }, ptr %t13
  %t17 = call %"compiler/lower:pl" @compiler_2flower_3apl_2ector(ptr %v2, { i64, [2 x i64] } %t15)
  store %"compiler/lower:pl" %t17, ptr %l12
  br label %bb4
bb3:
  br label %bb5
bb4:
  %t18 = load %"compiler/lower:pl", ptr %l12
  store %"compiler/lower:pl" %t18, ptr %rv
  br label %ret
bb5:
  %t19 = load ptr, ptr %l0, !tbaa !29
  store ptr %t19, ptr %l13, !tbaa !29
  %t20 = load { i64, [4 x i64] }, ptr %l3
  store { i64, [4 x i64] } %t20, ptr %l14
  %t21 = load ptr, ptr %l1, !tbaa !29
  %t23 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t21)
  store i32 %t23, ptr %l16
  br label %bb6
bb6:
  %t25 = load ptr, ptr %l13, !tbaa !29
  %t26 = load { i64, [4 x i64] }, ptr %l14
  %t27 = load i32, ptr %l16, !tbaa !23
  %t29 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2elocal(ptr %v0, ptr %t25, { i64, [4 x i64] } %t26, i32 %t27, %"compiler/source:Span" %a2)
  store i32 %t29, ptr %l18
  br label %bb7
bb7:
  %t30 = load i32, ptr %l18, !tbaa !23
  %t31 = load ptr, ptr %l0, !tbaa !29
  store ptr %t31, ptr %l19, !tbaa !29
  store { i64, [2 x i64] } zeroinitializer, ptr %t33
  %t34 = getelementptr { i64, [2 x i64] }, ptr %t33, i32 0, i32 0
  store i64 1, ptr %t34
  %t36 = insertvalue { i32 } undef, i32 %t30, 0
  %t37 = getelementptr { i64, [2 x i64] }, ptr %t33, i32 0, i32 1
  store { i32 } %t36, ptr %t37
  %t38 = load { i64, [2 x i64] }, ptr %t33
  %t40 = call %"compiler/lower:pl" @compiler_2flower_3apl_2ector(ptr %v2, { i64, [2 x i64] } %t38)
  store %"compiler/lower:pl" %t40, ptr %l22
  br label %bb8
bb8:
  store { i64, [1 x i64] } zeroinitializer, ptr %t41
  %t42 = getelementptr { i64, [1 x i64] }, ptr %t41, i32 0, i32 0
  store i64 3, ptr %t42
  %t43 = load { i64, [1 x i64] }, ptr %t41
  %t44 = load ptr, ptr %l19, !tbaa !29
  %t45 = load %"compiler/lower:pl", ptr %l22
  %t47 = call %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2ewith(ptr %v0, ptr %v2, ptr %v2, ptr %t44, %"compiler/lower:pl" %t45, { i64, [1 x i64] } %t43)
  store %"compiler/lower:pl" %t47, ptr %l24
  br label %bb9
bb9:
  %t48 = load %"compiler/lower:pl", ptr %l24
  store %"compiler/lower:pl" %t48, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/lower:pl", ptr %rv
  ret %"compiler/lower:pl" %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2edispatch(ptr %v0, ptr %a0, { i64, [4 x i64] } %a1, i32 %a2, %"compiler/source:Span" %a3, i1 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [4 x i64] }
  %l2 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca %"compiler/lower:tryCtx"
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca ptr
  %l16 = alloca { i64, [4 x i64] }
  %l17 = alloca i1
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca %"compiler/typed:Item"
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca { i64, [4 x i64] }
  %l32 = alloca i32
  %l33 = alloca i32
  %l34 = alloca i32
  %l40 = alloca { i64, ptr }
  %l43 = alloca i64
  %l51 = alloca %"compiler/lower:tryCtx"
  %l57 = alloca i64
  %l60 = alloca i64
  %l80 = alloca { i64, ptr }
  %l94 = alloca { i64, ptr }
  %l103 = alloca i64
  %l106 = alloca i64
  %l126 = alloca i1
  %l127 = alloca ptr
  %l129 = alloca { i64, ptr }
  %l132 = alloca i32
  %l135 = alloca i32
  %l136 = alloca i1
  %l151 = alloca { i64, ptr }
  %l153 = alloca { i64, [4 x i64] }
  %l162 = alloca { i64, ptr }
  %l164 = alloca { i64, [4 x i64] }
  %l177 = alloca { i64, ptr }
  %l179 = alloca { i64, [4 x i64] }
  %l182 = alloca { i64, [4 x i64] }
  %l189 = alloca { i64, ptr }
  %l191 = alloca { i64, [4 x i64] }
  %l196 = alloca i1
  %l207 = alloca i32
  %l210 = alloca i32
  %l247 = alloca i32
  %l255 = alloca i64
  %l264 = alloca { i64, ptr }
  %l267 = alloca i1
  %l270 = alloca i64
  %l277 = alloca ptr
  %l278 = alloca %"compiler/source:Span"
  %l286 = alloca { i64, [4 x i64] }
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %t99 = alloca { i64, [4 x i64] }, align 8
  %t223 = alloca { i64, [4 x i64] }, align 8
  %t236 = alloca { i64, [4 x i64] }, align 8
  %t273 = alloca { i64, [4 x i64] }, align 8
  %t313 = alloca { i64, [4 x i64] }, align 8
  %t416 = alloca { i64, [7 x i64] }, align 8
  %t457 = alloca { i64, [21 x i64] }, align 8
  %t551 = alloca { i64, [4 x i64] }, align 8
  %t554 = alloca { i64, [7 x i64] }, align 8
  %t573 = alloca { i64, [15 x i64] }, align 8
  store ptr %a0, ptr %l0
  store { i64, [4 x i64] } %a1, ptr %l1
  store i32 %a2, ptr %l2
  store %"compiler/source:Span" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l5, !tbaa !29
  %t6 = load ptr, ptr %l5, !tbaa !29
  %t7 = load i32, ptr %l2, !tbaa !23
  %t10 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t6, i32 %t7)
  store { i64, ptr } %t10, ptr %l40
  br label %bb1
bb1:
  %t11 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t11, ptr %l6, !tbaa !27
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/lower:lowering", ptr %t12, i32 0, i32 13
  %t16 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3atryCtx_3e_2eLen_3ccompiler_2flower_3atryCtx_3e(ptr %v0, ptr %t14)
  store i64 %t16, ptr %l43
  br label %bb2
bb2:
  %t17 = load i64, ptr %l43, !tbaa !24
  %t18 = sub i64 %t17, 1
  store i64 %t18, ptr %l7, !tbaa !24
  br label %bb3
bb3:
  store %olang.scope zeroinitializer, ptr %s2
  %t20 = load i64, ptr %l7, !tbaa !24
  %t22 = icmp sge i64 %t20, 0
  %t24 = xor i1 %t22, true
  br i1 %t24, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s2)
  br label %bb94
bb5:
  br label %bb6
bb6:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/lower:lowering", ptr %t26, i32 0, i32 13
  %t29 = load i64, ptr %l7, !tbaa !24
  %t32 = call %"compiler/lower:tryCtx" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3atryCtx_3e_2eAt_3ccompiler_2flower_3atryCtx_3e(ptr %v0, ptr %v0, ptr %t28, i64 %t29)
  store %"compiler/lower:tryCtx" %t32, ptr %l51
  br label %bb7
bb7:
  %t33 = load %"compiler/lower:tryCtx", ptr %l51
  store %"compiler/lower:tryCtx" %t33, ptr %l8
  store i64 0, ptr %l9, !tbaa !24
  %t34 = getelementptr %"compiler/lower:tryCtx", ptr %l8, i32 0, i32 1
  %t35 = load { i64, ptr }, ptr %t34, !tbaa !27
  %t37 = extractvalue { i64, ptr } %t35, 0
  store i64 %t37, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t39 = load i64, ptr %l10, !tbaa !24
  %t40 = load i64, ptr %l9, !tbaa !24
  %t43 = icmp sgt i64 %t39, %t40
  br i1 %t43, label %bb8, label %bb9
bb8:
  %t45 = load i64, ptr %l11, !tbaa !24
  %t47 = icmp sgt i64 %t45, 0
  br i1 %t47, label %bb10, label %bb11
bb9:
  store i64 0, ptr %l57, !tbaa !24
  br label %bb13
bb10:
  %t49 = load i64, ptr %l10, !tbaa !24
  %t50 = load i64, ptr %l9, !tbaa !24
  %t53 = sub i64 %t49, %t50
  %t54 = load i64, ptr %l11, !tbaa !24
  %t57 = add i64 %t53, %t54
  %t59 = sub i64 %t57, 1
  %t60 = load i64, ptr %l11, !tbaa !24
  %t63 = sdiv i64 %t59, %t60
  store i64 %t63, ptr %l60, !tbaa !24
  br label %bb12
bb11:
  store i64 0, ptr %l60, !tbaa !24
  br label %bb12
bb12:
  %t65 = load i64, ptr %l60, !tbaa !24
  store i64 %t65, ptr %l57, !tbaa !24
  br label %bb13
bb13:
  %t66 = load i64, ptr %l57, !tbaa !24
  store i64 %t66, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb14
bb14:
  store %olang.scope zeroinitializer, ptr %s4
  %t67 = load i64, ptr %l13, !tbaa !24
  %t68 = load i64, ptr %l12, !tbaa !24
  %t71 = icmp slt i64 %t67, %t68
  %t73 = xor i1 %t71, true
  br i1 %t73, label %bb15, label %bb16
bb15:
  call void @__olang_scope_close(ptr %s4)
  br label %bb81
bb16:
  br label %bb17
bb17:
  %t75 = load i64, ptr %l9, !tbaa !24
  %t76 = load i64, ptr %l13, !tbaa !24
  %t77 = load i64, ptr %l11, !tbaa !24
  %t80 = mul i64 %t76, %t77
  %t83 = add i64 %t75, %t80
  store i64 %t83, ptr %l14, !tbaa !24
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"compiler/lower:lowering", ptr %t85, i32 0, i32 7
  %t88 = load i1, ptr %t87, !tbaa !21
  br i1 %t88, label %bb18, label %bb19
bb18:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s2)
  br label %ret
bb19:
  br label %bb20
bb20:
  %t90 = getelementptr %"compiler/lower:tryCtx", ptr %l8, i32 0, i32 1
  %t91 = load { i64, ptr }, ptr %t90, !tbaa !27
  store { i64, ptr } %t91, ptr %l80, !tbaa !27
  %t92 = load i64, ptr %l14, !tbaa !24
  %t94 = getelementptr { i64, ptr }, ptr %l80, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !27
  %t96 = getelementptr ptr, ptr %t95, i64 %t92
  %t97 = load ptr, ptr %t96, !tbaa !39
  store ptr %t97, ptr %l15, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t99
  %t100 = getelementptr { i64, [4 x i64] }, ptr %t99, i32 0, i32 0
  store i64 0, ptr %t100
  %t101 = load { i64, [4 x i64] }, ptr %t99
  store { i64, [4 x i64] } %t101, ptr %l16
  %t103 = load ptr, ptr %l15, !tbaa !29
  %t105 = getelementptr %"compiler/typed:Clause", ptr %t103, i32 0, i32 2
  %t106 = load i1, ptr %t105, !tbaa !21
  store i1 %t106, ptr %l17, !tbaa !21
  %t108 = load ptr, ptr %l15, !tbaa !29
  %t110 = getelementptr %"compiler/typed:Clause", ptr %t108, i32 0, i32 1
  %t111 = load { i64, ptr }, ptr %t110, !tbaa !27
  store { i64, ptr } %t111, ptr %l18, !tbaa !27
  store i64 0, ptr %l19, !tbaa !24
  %t113 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t115 = extractvalue { i64, ptr } %t113, 0
  store i64 %t115, ptr %l20, !tbaa !24
  br label %bb21
bb21:
  store %olang.scope zeroinitializer, ptr %s7
  %t117 = load i64, ptr %l19, !tbaa !24
  %t118 = load i64, ptr %l20, !tbaa !24
  %t121 = icmp slt i64 %t117, %t118
  %t123 = xor i1 %t121, true
  br i1 %t123, label %bb22, label %bb23
bb22:
  call void @__olang_scope_close(ptr %s7)
  br label %bb63
bb23:
  br label %bb24
bb24:
  %t125 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t125, ptr %l94, !tbaa !27
  %t126 = load i64, ptr %l19, !tbaa !24
  %t128 = getelementptr { i64, ptr }, ptr %l94, i32 0, i32 1
  %t129 = load ptr, ptr %t128, !tbaa !27
  %t130 = getelementptr %"compiler/typed:Item", ptr %t129, i64 %t126
  %t131 = load %"compiler/typed:Item", ptr %t130
  store %"compiler/typed:Item" %t131, ptr %l21
  %t133 = load i1, ptr %l17, !tbaa !21
  br i1 %t133, label %bb25, label %bb26
bb25:
  call void @__olang_scope_close(ptr %s7)
  br label %bb63
bb26:
  br label %bb27
bb27:
  store i64 -1, ptr %l22, !tbaa !24
  store i64 0, ptr %l23, !tbaa !24
  %t135 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t137 = extractvalue { i64, ptr } %t135, 0
  store i64 %t137, ptr %l24, !tbaa !24
  store i64 1, ptr %l25, !tbaa !24
  %t139 = load i64, ptr %l24, !tbaa !24
  %t140 = load i64, ptr %l23, !tbaa !24
  %t143 = icmp sgt i64 %t139, %t140
  br i1 %t143, label %bb28, label %bb29
bb28:
  %t145 = load i64, ptr %l25, !tbaa !24
  %t147 = icmp sgt i64 %t145, 0
  br i1 %t147, label %bb30, label %bb31
bb29:
  store i64 0, ptr %l103, !tbaa !24
  br label %bb33
bb30:
  %t149 = load i64, ptr %l24, !tbaa !24
  %t150 = load i64, ptr %l23, !tbaa !24
  %t153 = sub i64 %t149, %t150
  %t154 = load i64, ptr %l25, !tbaa !24
  %t157 = add i64 %t153, %t154
  %t159 = sub i64 %t157, 1
  %t160 = load i64, ptr %l25, !tbaa !24
  %t163 = sdiv i64 %t159, %t160
  store i64 %t163, ptr %l106, !tbaa !24
  br label %bb32
bb31:
  store i64 0, ptr %l106, !tbaa !24
  br label %bb32
bb32:
  %t165 = load i64, ptr %l106, !tbaa !24
  store i64 %t165, ptr %l103, !tbaa !24
  br label %bb33
bb33:
  %t166 = load i64, ptr %l103, !tbaa !24
  store i64 %t166, ptr %l26, !tbaa !24
  store i64 0, ptr %l27, !tbaa !24
  br label %bb34
bb34:
  store %olang.scope zeroinitializer, ptr %s10
  %t167 = load i64, ptr %l27, !tbaa !24
  %t168 = load i64, ptr %l26, !tbaa !24
  %t171 = icmp slt i64 %t167, %t168
  %t173 = xor i1 %t171, true
  br i1 %t173, label %bb35, label %bb36
bb35:
  call void @__olang_scope_close(ptr %s10)
  br label %bb48
bb36:
  br label %bb37
bb37:
  %t175 = load i64, ptr %l23, !tbaa !24
  %t176 = load i64, ptr %l27, !tbaa !24
  %t177 = load i64, ptr %l25, !tbaa !24
  %t180 = mul i64 %t176, %t177
  %t183 = add i64 %t175, %t180
  store i64 %t183, ptr %l28, !tbaa !24
  %t185 = load i64, ptr %l22, !tbaa !24
  %t187 = icmp slt i64 %t185, 0
  br i1 %t187, label %bb38, label %bb39
bb38:
  %t189 = load ptr, ptr %l5, !tbaa !29
  store ptr %t189, ptr %l127, !tbaa !29
  %t190 = load ptr, ptr %l5, !tbaa !29
  %t191 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t191, ptr %l129, !tbaa !27
  %t192 = load i64, ptr %l28, !tbaa !24
  %t194 = getelementptr { i64, ptr }, ptr %l129, i32 0, i32 1
  %t195 = load ptr, ptr %t194, !tbaa !27
  %t196 = getelementptr i32, ptr %t195, i64 %t192
  %t197 = load i32, ptr %t196, !tbaa !33
  %t200 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t190, i32 %t197)
  store i32 %t200, ptr %l132
  br label %bb40
bb39:
  store i1 false, ptr %l126, !tbaa !21
  br label %bb43
bb40:
  %t201 = load ptr, ptr %l5, !tbaa !29
  %t202 = getelementptr %"compiler/typed:Item", ptr %l21, i32 0, i32 0
  %t203 = load i32, ptr %t202, !tbaa !23
  %t206 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t201, i32 %t203)
  store i32 %t206, ptr %l135
  br label %bb41
bb41:
  %t207 = load ptr, ptr %l127, !tbaa !29
  %t208 = load i32, ptr %l132, !tbaa !23
  %t209 = load i32, ptr %l135, !tbaa !23
  %t210 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t207, i32 %t208, i32 %t209)
  store i1 %t210, ptr %l136
  br label %bb42
bb42:
  %t211 = load i1, ptr %l136, !tbaa !21
  store i1 %t211, ptr %l126, !tbaa !21
  br label %bb43
bb43:
  %t212 = load i1, ptr %l126, !tbaa !21
  br i1 %t212, label %bb44, label %bb45
bb44:
  %t213 = load i64, ptr %l28, !tbaa !24
  store i64 %t213, ptr %l22, !tbaa !24
  br label %bb46
bb45:
  br label %bb46
bb46:
  call void @__olang_scope_close(ptr %s10)
  br label %bb47
bb47:
  %t215 = load i64, ptr %l27, !tbaa !24
  %t217 = add i64 %t215, 1
  store i64 %t217, ptr %l27, !tbaa !24
  br label %bb34
bb48:
  %t219 = load i64, ptr %l22, !tbaa !24
  %t221 = icmp slt i64 %t219, 0
  br i1 %t221, label %bb49, label %bb50
bb49:
  call void @__olang_scope_close(ptr %s7)
  br label %bb62
bb50:
  br label %bb51
bb51:
  store { i64, [4 x i64] } zeroinitializer, ptr %t223
  %t224 = getelementptr { i64, [4 x i64] }, ptr %t223, i32 0, i32 0
  store i64 0, ptr %t224
  %t225 = load { i64, [4 x i64] }, ptr %t223
  store { i64, [4 x i64] } %t225, ptr %l29
  %t227 = getelementptr %"compiler/typed:Item", ptr %l21, i32 0, i32 1
  %t228 = load i64, ptr %t227, !tbaa !24
  %t230 = icmp slt i64 %t228, 0
  br i1 %t230, label %bb52, label %bb53
bb52:
  store %olang.scope zeroinitializer, ptr %s14
  %t232 = load ptr, ptr %l0, !tbaa !29
  %t233 = load i32, ptr @G_2ecompiler_2fmir_2eI32T, !tbaa !23
  %t234 = load { i64, [4 x i64] }, ptr %l1
  %t235 = load i32, ptr @G_2ecompiler_2fmir_2eI32T, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t236
  %t237 = getelementptr { i64, [4 x i64] }, ptr %t236, i32 0, i32 0
  store i64 2, ptr %t237
  %t239 = insertvalue { i32, i64 } undef, i32 %t235, 0
  %t240 = insertvalue { i32, i64 } %t239, i64 16, 1
  %t241 = getelementptr { i64, [4 x i64] }, ptr %t236, i32 0, i32 1
  store { i32, i64 } %t240, ptr %t241
  %t242 = load { i64, [4 x i64] }, ptr %t236
  %t243 = mul i64 2, 40
  %t244 = call ptr @__olang_scope_alloc_zeroed(ptr %s14, i64 %t243)
  %t245 = insertvalue { i64, ptr } undef, i64 2, 0
  %t246 = insertvalue { i64, ptr } %t245, ptr %t244, 1
  store { i64, ptr } %t246, ptr %l151, !tbaa !27
  %t248 = getelementptr { i64, ptr }, ptr %l151, i32 0, i32 1
  %t249 = load ptr, ptr %t248, !tbaa !27
  %t250 = getelementptr { i64, [4 x i64] }, ptr %t249, i64 0
  store { i64, [4 x i64] } %t234, ptr %t250
  %t252 = getelementptr { i64, ptr }, ptr %l151, i32 0, i32 1
  %t253 = load ptr, ptr %t252, !tbaa !27
  %t254 = getelementptr { i64, [4 x i64] }, ptr %t253, i64 1
  store { i64, [4 x i64] } %t242, ptr %t254
  %t255 = load %"compiler/source:Span", ptr %l3
  %t259 = load { i64, ptr }, ptr %l151, !tbaa !27
  %t261 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s14, ptr %t232, i32 9, i32 %t233, { i64, ptr } %t259, %"compiler/source:Span" %t255)
  store { i64, [4 x i64] } %t261, ptr %l153
  br label %bb54
bb53:
  store %olang.scope zeroinitializer, ptr %s15
  %t262 = load i32, ptr @G_2ecompiler_2fmir_2eI32T, !tbaa !23
  %t263 = load i64, ptr %l22, !tbaa !24
  %t265 = add i64 %t263, 1
  %t267 = shl i64 %t265, 16
  %t268 = getelementptr %"compiler/typed:Item", ptr %l21, i32 0, i32 1
  %t269 = load i64, ptr %t268, !tbaa !24
  %t272 = or i64 %t267, %t269
  store { i64, [4 x i64] } zeroinitializer, ptr %t273
  %t274 = getelementptr { i64, [4 x i64] }, ptr %t273, i32 0, i32 0
  store i64 2, ptr %t274
  %t276 = insertvalue { i32, i64 } undef, i32 %t262, 0
  %t278 = insertvalue { i32, i64 } %t276, i64 %t272, 1
  %t279 = getelementptr { i64, [4 x i64] }, ptr %t273, i32 0, i32 1
  store { i32, i64 } %t278, ptr %t279
  %t280 = load { i64, [4 x i64] }, ptr %t273
  %t282 = load ptr, ptr %l0, !tbaa !29
  %t283 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t284 = load { i64, [4 x i64] }, ptr %l1
  %t286 = mul i64 2, 40
  %t287 = call ptr @__olang_scope_alloc_zeroed(ptr %s15, i64 %t286)
  %t288 = insertvalue { i64, ptr } undef, i64 2, 0
  %t289 = insertvalue { i64, ptr } %t288, ptr %t287, 1
  store { i64, ptr } %t289, ptr %l177, !tbaa !27
  %t291 = getelementptr { i64, ptr }, ptr %l177, i32 0, i32 1
  %t292 = load ptr, ptr %t291, !tbaa !27
  %t293 = getelementptr { i64, [4 x i64] }, ptr %t292, i64 0
  store { i64, [4 x i64] } %t284, ptr %t293
  %t295 = getelementptr { i64, ptr }, ptr %l177, i32 0, i32 1
  %t296 = load ptr, ptr %t295, !tbaa !27
  %t297 = getelementptr { i64, [4 x i64] }, ptr %t296, i64 1
  store { i64, [4 x i64] } %t280, ptr %t297
  %t298 = load %"compiler/source:Span", ptr %l3
  %t302 = load { i64, ptr }, ptr %l177, !tbaa !27
  %t304 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s15, ptr %t282, i32 13, i32 %t283, { i64, ptr } %t302, %"compiler/source:Span" %t298)
  store { i64, [4 x i64] } %t304, ptr %l179
  br label %bb56
bb54:
  %t305 = load { i64, [4 x i64] }, ptr %l153
  %t306 = load ptr, ptr %l0, !tbaa !29
  %t307 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t309 = load i32, ptr @G_2ecompiler_2fmir_2eI32T, !tbaa !23
  %t310 = load i64, ptr %l22, !tbaa !24
  %t312 = add i64 %t310, 1
  store { i64, [4 x i64] } zeroinitializer, ptr %t313
  %t314 = getelementptr { i64, [4 x i64] }, ptr %t313, i32 0, i32 0
  store i64 2, ptr %t314
  %t316 = insertvalue { i32, i64 } undef, i32 %t309, 0
  %t318 = insertvalue { i32, i64 } %t316, i64 %t312, 1
  %t319 = getelementptr { i64, [4 x i64] }, ptr %t313, i32 0, i32 1
  store { i32, i64 } %t318, ptr %t319
  %t320 = load { i64, [4 x i64] }, ptr %t313
  %t321 = mul i64 2, 40
  %t322 = call ptr @__olang_scope_alloc_zeroed(ptr %s14, i64 %t321)
  %t323 = insertvalue { i64, ptr } undef, i64 2, 0
  %t324 = insertvalue { i64, ptr } %t323, ptr %t322, 1
  store { i64, ptr } %t324, ptr %l162, !tbaa !27
  %t326 = getelementptr { i64, ptr }, ptr %l162, i32 0, i32 1
  %t327 = load ptr, ptr %t326, !tbaa !27
  %t328 = getelementptr { i64, [4 x i64] }, ptr %t327, i64 0
  store { i64, [4 x i64] } %t305, ptr %t328
  %t330 = getelementptr { i64, ptr }, ptr %l162, i32 0, i32 1
  %t331 = load ptr, ptr %t330, !tbaa !27
  %t332 = getelementptr { i64, [4 x i64] }, ptr %t331, i64 1
  store { i64, [4 x i64] } %t320, ptr %t332
  %t333 = load %"compiler/source:Span", ptr %l3
  %t337 = load { i64, ptr }, ptr %l162, !tbaa !27
  %t339 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s14, ptr %t306, i32 13, i32 %t307, { i64, ptr } %t337, %"compiler/source:Span" %t333)
  store { i64, [4 x i64] } %t339, ptr %l164
  br label %bb55
bb55:
  %t340 = load { i64, [4 x i64] }, ptr %l164
  store { i64, [4 x i64] } %t340, ptr %l29
  call void @__olang_scope_close(ptr %s14)
  br label %bb57
bb56:
  %t341 = load { i64, [4 x i64] }, ptr %l179
  store { i64, [4 x i64] } %t341, ptr %l29
  call void @__olang_scope_close(ptr %s15)
  br label %bb57
bb57:
  %t342 = load { i64, [4 x i64] }, ptr %l16
  %t344 = extractvalue { i64, [4 x i64] } %t342, 0
  %t345 = icmp eq i64 %t344, 0
  br i1 %t345, label %bb58, label %bb59
bb58:
  %t347 = load { i64, [4 x i64] }, ptr %l29
  store { i64, [4 x i64] } %t347, ptr %l182
  br label %bb61
bb59:
  %t349 = load ptr, ptr %l0, !tbaa !29
  %t350 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t351 = load { i64, [4 x i64] }, ptr %l16
  %t352 = load { i64, [4 x i64] }, ptr %l29
  %t353 = mul i64 2, 40
  %t354 = call ptr @__olang_scope_alloc_zeroed(ptr %s7, i64 %t353)
  %t355 = insertvalue { i64, ptr } undef, i64 2, 0
  %t356 = insertvalue { i64, ptr } %t355, ptr %t354, 1
  store { i64, ptr } %t356, ptr %l189, !tbaa !27
  %t358 = getelementptr { i64, ptr }, ptr %l189, i32 0, i32 1
  %t359 = load ptr, ptr %t358, !tbaa !27
  %t360 = getelementptr { i64, [4 x i64] }, ptr %t359, i64 0
  store { i64, [4 x i64] } %t351, ptr %t360
  %t362 = getelementptr { i64, ptr }, ptr %l189, i32 0, i32 1
  %t363 = load ptr, ptr %t362, !tbaa !27
  %t364 = getelementptr { i64, [4 x i64] }, ptr %t363, i64 1
  store { i64, [4 x i64] } %t352, ptr %t364
  %t365 = load %"compiler/source:Span", ptr %l3
  %t369 = load { i64, ptr }, ptr %l189, !tbaa !27
  %t371 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s7, ptr %t349, i32 11, i32 %t350, { i64, ptr } %t369, %"compiler/source:Span" %t365)
  store { i64, [4 x i64] } %t371, ptr %l191
  br label %bb60
bb60:
  %t372 = load { i64, [4 x i64] }, ptr %l191
  store { i64, [4 x i64] } %t372, ptr %l182
  br label %bb61
bb61:
  %t373 = load { i64, [4 x i64] }, ptr %l182
  store { i64, [4 x i64] } %t373, ptr %l16
  call void @__olang_scope_close(ptr %s7)
  br label %bb62
bb62:
  %t374 = load i64, ptr %l19, !tbaa !24
  %t376 = add i64 %t374, 1
  store i64 %t376, ptr %l19, !tbaa !24
  br label %bb21
bb63:
  %t378 = load i1, ptr %l17, !tbaa !21
  %t380 = xor i1 %t378, true
  br i1 %t380, label %bb64, label %bb65
bb64:
  %t382 = load { i64, [4 x i64] }, ptr %l16
  %t384 = extractvalue { i64, [4 x i64] } %t382, 0
  %t385 = icmp eq i64 %t384, 0
  store i1 %t385, ptr %l196, !tbaa !21
  br label %bb66
bb65:
  store i1 false, ptr %l196, !tbaa !21
  br label %bb66
bb66:
  %t387 = load i1, ptr %l196, !tbaa !21
  br i1 %t387, label %bb67, label %bb68
bb67:
  call void @__olang_scope_close(ptr %s4)
  br label %bb80
bb68:
  br label %bb69
bb69:
  %t388 = load i1, ptr %l17, !tbaa !21
  br i1 %t388, label %bb70, label %bb71
bb70:
  %t390 = load ptr, ptr %l0, !tbaa !29
  %t391 = load %"compiler/lower:tryCtx", ptr %l8
  %t392 = load i64, ptr %l14, !tbaa !24
  %t393 = load { i64, [4 x i64] }, ptr %l1
  %t394 = load i32, ptr %l2, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2etoClause(ptr %v0, ptr %v0, ptr %t390, %"compiler/lower:tryCtx" %t391, i64 %t392, { i64, [4 x i64] } %t393, i32 %t394)
  br label %bb72
bb71:
  br label %bb73
bb72:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s2)
  br label %ret
bb73:
  %t400 = load ptr, ptr %l0, !tbaa !29
  %t402 = getelementptr %"compiler/lower:lowering", ptr %t400, i32 0, i32 3
  %t404 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t402)
  store i32 %t404, ptr %l207
  br label %bb74
bb74:
  %t405 = load i32, ptr %l207, !tbaa !23
  store i32 %t405, ptr %l32, !tbaa !23
  %t406 = load ptr, ptr %l0, !tbaa !29
  %t408 = getelementptr %"compiler/lower:lowering", ptr %t406, i32 0, i32 3
  %t410 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t408)
  store i32 %t410, ptr %l210
  br label %bb75
bb75:
  %t411 = load i32, ptr %l210, !tbaa !23
  store i32 %t411, ptr %l33, !tbaa !23
  %t412 = load ptr, ptr %l0, !tbaa !29
  %t413 = load { i64, [4 x i64] }, ptr %l16
  %t414 = load i32, ptr %l32, !tbaa !23
  %t415 = load i32, ptr %l33, !tbaa !23
  store { i64, [7 x i64] } zeroinitializer, ptr %t416
  %t417 = getelementptr { i64, [7 x i64] }, ptr %t416, i32 0, i32 0
  store i64 2, ptr %t417
  %t419 = insertvalue { { i64, [4 x i64] }, i32, i32 } undef, { i64, [4 x i64] } %t413, 0
  %t421 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t419, i32 %t414, 1
  %t423 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t421, i32 %t415, 2
  %t424 = getelementptr { i64, [7 x i64] }, ptr %t416, i32 0, i32 1
  store { { i64, [4 x i64] }, i32, i32 } %t423, ptr %t424
  %t425 = load { i64, [7 x i64] }, ptr %t416
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t412, { i64, [7 x i64] } %t425)
  br label %bb76
bb76:
  %t428 = load ptr, ptr %l0, !tbaa !29
  %t429 = load i32, ptr %l32, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t428, i32 %t429)
  br label %bb77
bb77:
  %t432 = load ptr, ptr %l0, !tbaa !29
  %t433 = load %"compiler/lower:tryCtx", ptr %l8
  %t434 = load i64, ptr %l14, !tbaa !24
  %t435 = load { i64, [4 x i64] }, ptr %l1
  %t436 = load i32, ptr %l2, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2etoClause(ptr %v0, ptr %v0, ptr %t432, %"compiler/lower:tryCtx" %t433, i64 %t434, { i64, [4 x i64] } %t435, i32 %t436)
  br label %bb78
bb78:
  %t442 = load ptr, ptr %l0, !tbaa !29
  %t443 = load i32, ptr %l33, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t442, i32 %t443)
  br label %bb79
bb79:
  call void @__olang_scope_close(ptr %s4)
  br label %bb80
bb80:
  %t446 = load i64, ptr %l13, !tbaa !24
  %t448 = add i64 %t446, 1
  store i64 %t448, ptr %l13, !tbaa !24
  br label %bb14
bb81:
  %t450 = getelementptr %"compiler/lower:tryCtx", ptr %l8, i32 0, i32 2
  %t451 = load i1, ptr %t450, !tbaa !21
  br i1 %t451, label %bb82, label %bb83
bb82:
  br i1 %a4, label %bb84, label %bb85
bb83:
  br label %bb89
bb84:
  store %olang.scope zeroinitializer, ptr %s21
  %t455 = load ptr, ptr %l0, !tbaa !29
  %t456 = load %"compiler/source:Span", ptr %l3
  store { i64, [21 x i64] } zeroinitializer, ptr %t457
  %t458 = getelementptr { i64, [21 x i64] }, ptr %t457, i32 0, i32 0
  store i64 12, ptr %t458
  %t460 = insertvalue { %"compiler/source:Span" } undef, %"compiler/source:Span" %t456, 0
  %t461 = getelementptr { i64, [21 x i64] }, ptr %t457, i32 0, i32 1
  store { %"compiler/source:Span" } %t460, ptr %t461
  %t462 = load { i64, [21 x i64] }, ptr %t457
  %t464 = call ptr @__olang_scope_alloc_a(ptr %s21, i64 176, i64 8)
  store { i64, [21 x i64] } %t462, ptr %t464
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s21, ptr %t455, ptr %t464)
  br label %bb86
bb85:
  br label %bb87
bb86:
  call void @__olang_scope_close(ptr %s21)
  br label %bb87
bb87:
  %t467 = load ptr, ptr %l0, !tbaa !29
  %t468 = load { i64, [4 x i64] }, ptr %l1
  %t469 = load i32, ptr %l2, !tbaa !23
  %t470 = load %"compiler/source:Span", ptr %l3
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2ebang(ptr %v0, ptr %t467, { i64, [4 x i64] } %t468, i32 %t469, %"compiler/source:Span" %t470, i32 10)
  br label %bb88
bb88:
  call void @__olang_scope_close(ptr %s2)
  br label %ret
bb89:
  %t476 = getelementptr %"compiler/lower:tryCtx", ptr %l8, i32 0, i32 3
  %t477 = load i1, ptr %t476, !tbaa !21
  %t479 = xor i1 %t477, true
  br i1 %t479, label %bb90, label %bb91
bb90:
  call void @__olang_scope_close(ptr %s2)
  br label %bb94
bb91:
  br label %bb92
bb92:
  call void @__olang_scope_close(ptr %s2)
  br label %bb93
bb93:
  %t481 = load i64, ptr %l7, !tbaa !24
  %t483 = sub i64 %t481, 1
  store i64 %t483, ptr %l7, !tbaa !24
  br label %bb3
bb94:
  %t485 = load ptr, ptr %l0, !tbaa !29
  %t487 = getelementptr %"compiler/lower:lowering", ptr %t485, i32 0, i32 2
  %t488 = load ptr, ptr %t487, !tbaa !29
  %t489 = load ptr, ptr %l0, !tbaa !29
  %t491 = getelementptr %"compiler/lower:lowering", ptr %t489, i32 0, i32 1
  %t492 = load ptr, ptr %t491, !tbaa !29
  %t494 = getelementptr %"compiler/typed:Body", ptr %t492, i32 0, i32 2
  %t495 = load i32, ptr %t494, !tbaa !23
  %t498 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t488, i32 %t495)
  store i32 %t498, ptr %l247
  br label %bb95
bb95:
  %t499 = load i32, ptr %l247, !tbaa !23
  store i32 %t499, ptr %l34, !tbaa !23
  %t500 = load ptr, ptr %l0, !tbaa !29
  %t502 = getelementptr %"compiler/lower:lowering", ptr %t500, i32 0, i32 1
  %t503 = load ptr, ptr %t502, !tbaa !29
  %t505 = getelementptr %"compiler/typed:Body", ptr %t503, i32 0, i32 1
  %t506 = load { i64, [2 x i64] }, ptr %t505
  %t510 = extractvalue { i64, [2 x i64] } %t506, 0
  %t511 = icmp eq i64 %t510, 5
  br i1 %t511, label %bb96, label %bb97
bb96:
  br label %bb98
bb97:
  br label %bb104
bb98:
  %t513 = load ptr, ptr %l0, !tbaa !29
  %t515 = getelementptr %"compiler/lower:lowering", ptr %t513, i32 0, i32 13
  %t517 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3atryCtx_3e_2eLen_3ccompiler_2flower_3atryCtx_3e(ptr %v0, ptr %t515)
  store i64 %t517, ptr %l255
  br label %bb99
bb99:
  %t518 = load i64, ptr %l255, !tbaa !24
  %t519 = icmp sgt i64 %t518, 0
  br i1 %t519, label %bb100, label %bb101
bb100:
  %t521 = load ptr, ptr %l0, !tbaa !29
  %t522 = load { i64, [4 x i64] }, ptr %l1
  %t523 = load i32, ptr %l2, !tbaa !23
  %t524 = load %"compiler/source:Span", ptr %l3
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2ebang(ptr %v0, ptr %t521, { i64, [4 x i64] } %t522, i32 %t523, %"compiler/source:Span" %t524, i32 11)
  br label %bb102
bb101:
  br label %bb103
bb102:
  br label %ret
bb103:
  br label %bb109
bb104:
  br i1 true, label %bb105, label %bb106
bb105:
  br label %bb107
bb106:
  br label %bb108
bb107:
  br label %bb109
bb108:
  call void @__olang_check_failed(ptr @olang_loc_c6e2ba3cedb073a3_23085f6ef83cda97)
  unreachable
bb109:
  %t530 = load ptr, ptr %l5, !tbaa !29
  %t531 = load i32, ptr %l34, !tbaa !23
  %t534 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t530, i32 %t531)
  store { i64, ptr } %t534, ptr %l264
  br label %bb110
bb110:
  %t535 = load { i64, ptr }, ptr %l264, !tbaa !27
  %t536 = extractvalue { i64, ptr } %t535, 0
  %t538 = icmp eq i64 %t536, 0
  br i1 %t538, label %bb111, label %bb112
bb111:
  store i1 true, ptr %l267, !tbaa !21
  br label %bb114
bb112:
  %t540 = load ptr, ptr %l0, !tbaa !29
  %t542 = getelementptr %"compiler/lower:lowering", ptr %t540, i32 0, i32 13
  %t544 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3atryCtx_3e_2eLen_3ccompiler_2flower_3atryCtx_3e(ptr %v0, ptr %t542)
  store i64 %t544, ptr %l270
  br label %bb113
bb113:
  %t545 = load i64, ptr %l270, !tbaa !24
  %t546 = icmp eq i64 %t545, 0
  store i1 %t546, ptr %l267, !tbaa !21
  br label %bb114
bb114:
  %t548 = load i1, ptr %l267, !tbaa !21
  br i1 %t548, label %bb115, label %bb116
bb115:
  %t549 = load ptr, ptr %l0, !tbaa !29
  %t550 = load %"compiler/source:Span", ptr %l3
  store { i64, [4 x i64] } zeroinitializer, ptr %t551
  %t552 = getelementptr { i64, [4 x i64] }, ptr %t551, i32 0, i32 0
  store i64 0, ptr %t552
  %t553 = load { i64, [4 x i64] }, ptr %t551
  store { i64, [7 x i64] } zeroinitializer, ptr %t554
  %t555 = getelementptr { i64, [7 x i64] }, ptr %t554, i32 0, i32 0
  store i64 8, ptr %t555
  %t557 = insertvalue { %"compiler/source:Span", i32, { i64, [4 x i64] } } undef, %"compiler/source:Span" %t550, 0
  %t559 = insertvalue { %"compiler/source:Span", i32, { i64, [4 x i64] } } %t557, i32 3, 1
  %t561 = insertvalue { %"compiler/source:Span", i32, { i64, [4 x i64] } } %t559, { i64, [4 x i64] } %t553, 2
  %t562 = getelementptr { i64, [7 x i64] }, ptr %t554, i32 0, i32 1
  store { %"compiler/source:Span", i32, { i64, [4 x i64] } } %t561, ptr %t562
  %t563 = load { i64, [7 x i64] }, ptr %t554
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t549, { i64, [7 x i64] } %t563)
  br label %bb117
bb116:
  br label %bb118
bb117:
  br label %ret
bb118:
  %t566 = load ptr, ptr %l0, !tbaa !29
  store ptr %t566, ptr %l277, !tbaa !29
  %t567 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t567, ptr %l278
  %t568 = load ptr, ptr %l0, !tbaa !29
  %t569 = load i32, ptr @G_2ecompiler_2fmir_2eI32T, !tbaa !23
  %t570 = load { i64, [4 x i64] }, ptr %l1
  %t571 = load i32, ptr %l2, !tbaa !23
  %t572 = load i32, ptr %l34, !tbaa !23
  store { i64, [15 x i64] } zeroinitializer, ptr %t573
  %t574 = getelementptr { i64, [15 x i64] }, ptr %t573, i32 0, i32 0
  store i64 11, ptr %t574
  %t576 = insertvalue { { i64, [4 x i64] }, i32, i32 } undef, { i64, [4 x i64] } %t570, 0
  %t578 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t576, i32 %t571, 1
  %t580 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t578, i32 %t572, 2
  %t581 = getelementptr { i64, [15 x i64] }, ptr %t573, i32 0, i32 1
  store { { i64, [4 x i64] }, i32, i32 } %t580, ptr %t581
  %t582 = load { i64, [15 x i64] }, ptr %t573
  %t583 = load %"compiler/source:Span", ptr %l3
  %t588 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %t568, i32 %t569, { i64, [15 x i64] } %t582, %"compiler/source:Span" %t583)
  store { i64, [4 x i64] } %t588, ptr %l286
  br label %bb119
bb119:
  %t589 = load ptr, ptr %l277, !tbaa !29
  %t590 = load %"compiler/source:Span", ptr %l278
  %t591 = load { i64, [4 x i64] }, ptr %l286
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eraise(ptr %v0, ptr %t589, %"compiler/source:Span" %t590, { i64, [4 x i64] } %t591)
  br label %bb120
bb120:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2eepilogue(ptr %v0, ptr %a0, { i64, [4 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %t12 = alloca { i64, [7 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eleave(ptr %v0, ptr %t1, i64 0)
  br label %bb1
bb1:
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t6 = getelementptr %"compiler/lower:lowering", ptr %t4, i32 0, i32 1
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/typed:Body", ptr %t7, i32 0, i32 4
  %t10 = load %"compiler/source:Span", ptr %t9
  store { i64, [7 x i64] } zeroinitializer, ptr %t12
  %t13 = getelementptr { i64, [7 x i64] }, ptr %t12, i32 0, i32 0
  store i64 5, ptr %t13
  %t15 = insertvalue { %"compiler/source:Span", { i64, [4 x i64] } } undef, %"compiler/source:Span" %t10, 0
  %t17 = insertvalue { %"compiler/source:Span", { i64, [4 x i64] } } %t15, { i64, [4 x i64] } %a1, 1
  %t18 = getelementptr { i64, [7 x i64] }, ptr %t12, i32 0, i32 1
  store { %"compiler/source:Span", { i64, [4 x i64] } } %t17, ptr %t18
  %t19 = load { i64, [7 x i64] }, ptr %t12
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t3, { i64, [7 x i64] } %t19)
  br label %bb2
bb2:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2eexitLevel(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca %"compiler/lower:level"
  %l3 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l4 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l17 = alloca i64
  %l18 = alloca ptr
  %l19 = alloca i64
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca i64
  %l24 = alloca %"compiler/source:Span"
  %l25 = alloca i32
  %l26 = alloca i32
  %l28 = alloca i32
  %l29 = alloca i32
  %l35 = alloca %"compiler/lower:level"
  %l36 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l39 = alloca i64
  %l44 = alloca ptr
  %l45 = alloca %"compiler/lower:level"
  %l48 = alloca %"compiler/lower:level"
  %l49 = alloca i32
  %l50 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l53 = alloca i64
  %l57 = alloca i64
  %l60 = alloca i64
  %l81 = alloca i32
  %l89 = alloca { i64, ptr }
  %l92 = alloca { i64, ptr }
  %l93 = alloca i32
  %l102 = alloca { i64, ptr }
  %l114 = alloca i64
  %l122 = alloca ptr
  %l125 = alloca ptr
  %l127 = alloca ptr
  %l130 = alloca i64
  %l131 = alloca ptr
  %l135 = alloca %"compiler/typed:BlockInfo"
  %l141 = alloca ptr
  %l143 = alloca ptr
  %l146 = alloca i64
  %l147 = alloca ptr
  %l151 = alloca { i64, ptr }
  %l154 = alloca { i64, ptr }
  %l155 = alloca i32
  %l164 = alloca { i64, ptr }
  %l177 = alloca i64
  %l181 = alloca ptr
  %l182 = alloca %"compiler/lower:level"
  %l184 = alloca %"compiler/lower:level"
  %l185 = alloca i32
  %l190 = alloca %"compiler/source:Span"
  %l196 = alloca %"compiler/typed:BlockInfo"
  %l207 = alloca %"compiler/mir:ScopeInfo"
  %l211 = alloca i32
  %l215 = alloca { i64, ptr }
  %l230 = alloca i32
  %l241 = alloca i32
  %l244 = alloca i32
  %l259 = alloca ptr
  %l260 = alloca i64
  %l261 = alloca i32
  %l263 = alloca %"compiler/mir:Place"
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s27 = alloca %olang.scope
  %t221 = alloca { i64, [21 x i64] }, align 8
  %t408 = alloca { i64, [7 x i64] }, align 8
  %t451 = alloca { i64, [7 x i64] }, align 8
  %t481 = alloca { i64, [7 x i64] }, align 8
  %t505 = alloca { i64, [21 x i64] }, align 8
  %t524 = alloca { i64, [4 x i64] }, align 8
  %t546 = alloca { i64, [21 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 7
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/lower:lowering", ptr %t6, i32 0, i32 9
  %t9 = load i64, ptr %l1, !tbaa !24
  %t12 = call %"compiler/lower:level" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3alevel_3e_2eAt_3ccompiler_2flower_3alevel_3e(ptr %v0, ptr %t8, i64 %t9)
  store %"compiler/lower:level" %t12, ptr %l35
  br label %bb4
bb4:
  %t13 = load %"compiler/lower:level", ptr %l35
  store %"compiler/lower:level" %t13, ptr %l2
  %t14 = load ptr, ptr @__olang_prog_scope
  %t15 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3alevel_3e(ptr %t14)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t15, ptr %l36
  br label %bb5
bb5:
  %t16 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l36
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t16, ptr %l3
  br label %bb6
bb6:
  store %olang.scope zeroinitializer, ptr %s2
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/lower:lowering", ptr %t17, i32 0, i32 9
  %t21 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3alevel_3e_2eLen_3ccompiler_2flower_3alevel_3e(ptr %v0, ptr %t19)
  store i64 %t21, ptr %l39
  br label %bb7
bb7:
  %t22 = load i64, ptr %l1, !tbaa !24
  %t24 = add i64 %t22, 1
  %t25 = load i64, ptr %l39, !tbaa !24
  %t27 = icmp sgt i64 %t25, %t24
  %t29 = xor i1 %t27, true
  br i1 %t29, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb17
bb9:
  br label %bb10
bb10:
  store ptr %l3, ptr %l44, !tbaa !29
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/lower:lowering", ptr %t31, i32 0, i32 9
  %t35 = call { i32, %"compiler/lower:level" } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3alevel_3e_2ePop_3ccompiler_2flower_3alevel_3e(ptr %v0, ptr %t33)
  %t36 = extractvalue { i32, %"compiler/lower:level" } %t35, 1
  %t37 = extractvalue { i32, %"compiler/lower:level" } %t35, 0
  store i32 %t37, ptr %l49
  %t38 = icmp ne i32 %t37, 0
  br i1 %t38, label %bb12, label %ok.39
ok.39:
  store %"compiler/lower:level" %t36, ptr %l48
  br label %bb11
bb11:
  %t40 = load %"compiler/lower:level", ptr %l48
  store %"compiler/lower:level" %t40, ptr %l45
  br label %bb14
bb12:
  br label %bb13
bb13:
  call void @__olang_ert_req_clear()
  call void @__olang_check_failed(ptr @olang_loc_831aef8878f0c239_4d65f3dd2c1f4c9d)
  unreachable
bb14:
  %t41 = load ptr, ptr %l44, !tbaa !29
  %t42 = load %"compiler/lower:level", ptr %l45
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3alevel_3e_2ePush_3ccompiler_2flower_3alevel_3e(ptr %s0, ptr %t41, %"compiler/lower:level" %t42)
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s2)
  br label %bb16
bb16:
  br label %bb6
bb17:
  %t43 = load ptr, ptr @__olang_prog_scope
  %t44 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t43)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t44, ptr %l50
  br label %bb18
bb18:
  %t45 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l50
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t45, ptr %l4
  store i64 0, ptr %l5, !tbaa !24
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/lower:lowering", ptr %t46, i32 0, i32 10
  %t50 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aBlock_26_3e_2eLe_H8743fc75fe5cead0bda2da42e1adf3f3(ptr %v0, ptr %t48)
  store i64 %t50, ptr %l53
  br label %bb19
bb19:
  %t51 = load i64, ptr %l53, !tbaa !24
  store i64 %t51, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t52 = load i64, ptr %l6, !tbaa !24
  %t53 = load i64, ptr %l5, !tbaa !24
  %t56 = icmp sgt i64 %t52, %t53
  br i1 %t56, label %bb20, label %bb21
bb20:
  %t58 = load i64, ptr %l7, !tbaa !24
  %t60 = icmp sgt i64 %t58, 0
  br i1 %t60, label %bb22, label %bb23
bb21:
  store i64 0, ptr %l57, !tbaa !24
  br label %bb25
bb22:
  %t62 = load i64, ptr %l6, !tbaa !24
  %t63 = load i64, ptr %l5, !tbaa !24
  %t66 = sub i64 %t62, %t63
  %t67 = load i64, ptr %l7, !tbaa !24
  %t70 = add i64 %t66, %t67
  %t72 = sub i64 %t70, 1
  %t73 = load i64, ptr %l7, !tbaa !24
  %t76 = sdiv i64 %t72, %t73
  store i64 %t76, ptr %l60, !tbaa !24
  br label %bb24
bb23:
  store i64 0, ptr %l60, !tbaa !24
  br label %bb24
bb24:
  %t78 = load i64, ptr %l60, !tbaa !24
  store i64 %t78, ptr %l57, !tbaa !24
  br label %bb25
bb25:
  %t79 = load i64, ptr %l57, !tbaa !24
  store i64 %t79, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb26
bb26:
  store %olang.scope zeroinitializer, ptr %s5
  %t80 = load i64, ptr %l9, !tbaa !24
  %t81 = load i64, ptr %l8, !tbaa !24
  %t84 = icmp slt i64 %t80, %t81
  %t86 = xor i1 %t84, true
  br i1 %t86, label %bb27, label %bb28
bb27:
  call void @__olang_scope_close(ptr %s5)
  br label %bb36
bb28:
  br label %bb29
bb29:
  %t88 = load i64, ptr %l5, !tbaa !24
  %t89 = load i64, ptr %l9, !tbaa !24
  %t90 = load i64, ptr %l7, !tbaa !24
  %t93 = mul i64 %t89, %t90
  %t96 = add i64 %t88, %t93
  store i64 %t96, ptr %l10, !tbaa !24
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t100 = getelementptr %"compiler/lower:lowering", ptr %t98, i32 0, i32 11
  %t101 = load i64, ptr %l10, !tbaa !24
  %t104 = call i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeId_3e_2eAt_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t100, i64 %t101)
  store i32 %t104, ptr %l81
  br label %bb30
bb30:
  %t105 = getelementptr %"compiler/lower:level", ptr %l2, i32 0, i32 0
  %t106 = load i32, ptr %t105, !tbaa !23
  %t107 = load i32, ptr %l81, !tbaa !23
  %t109 = icmp eq i32 %t107, %t106
  br i1 %t109, label %bb31, label %bb32
bb31:
  %t111 = load i64, ptr %l10, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l4, i64 %t111)
  br label %bb33
bb32:
  br label %bb34
bb33:
  br label %bb34
bb34:
  call void @__olang_scope_close(ptr %s5)
  br label %bb35
bb35:
  %t114 = load i64, ptr %l9, !tbaa !24
  %t116 = add i64 %t114, 1
  store i64 %t116, ptr %l9, !tbaa !24
  br label %bb26
bb36:
  store ptr %l4, ptr %l11, !tbaa !29
  store i64 0, ptr %l12, !tbaa !24
  br label %bb37
bb37:
  store %olang.scope zeroinitializer, ptr %s9
  %t119 = load ptr, ptr %l11, !tbaa !29
  %t120 = load i64, ptr %l12, !tbaa !24
  %t123 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %s0, ptr %t119, i64 %t120)
  %t124 = extractvalue { i32, { i64, ptr } } %t123, 1
  %t125 = extractvalue { i32, { i64, ptr } } %t123, 0
  store i32 %t125, ptr %l93
  %t126 = icmp ne i32 %t125, 0
  br i1 %t126, label %bb39, label %ok.127
ok.127:
  store { i64, ptr } %t124, ptr %l92
  br label %bb38
bb38:
  %t128 = load { i64, ptr }, ptr %l92, !tbaa !27
  store { i64, ptr } %t128, ptr %l89, !tbaa !27
  br label %bb43
bb39:
  %t129 = load i32, ptr %l93, !tbaa !23
  %t130 = ashr i32 %t129, 16
  %t132 = icmp eq i32 %t130, 1
  br i1 %t132, label %bb40, label %bb41
bb40:
  br label %bb42
bb41:
  call void @__olang_check_failed(ptr @olang_loc_53acd22e8270d268_dadfa79394a107ec)
  unreachable
bb42:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s9)
  br label %bb52
bb43:
  %t134 = load { i64, ptr }, ptr %l89, !tbaa !27
  store { i64, ptr } %t134, ptr %l13, !tbaa !27
  %t135 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t137 = extractvalue { i64, ptr } %t135, 0
  store i64 %t137, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb44
bb44:
  store %olang.scope zeroinitializer, ptr %s10
  %t139 = load i64, ptr %l15, !tbaa !24
  %t140 = load i64, ptr %l14, !tbaa !24
  %t143 = icmp slt i64 %t139, %t140
  %t145 = xor i1 %t143, true
  br i1 %t145, label %bb45, label %bb46
bb45:
  call void @__olang_scope_close(ptr %s10)
  br label %bb50
bb46:
  br label %bb47
bb47:
  %t147 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t147, ptr %l102, !tbaa !27
  %t148 = load i64, ptr %l15, !tbaa !24
  %t150 = getelementptr { i64, ptr }, ptr %l102, i32 0, i32 1
  %t151 = load ptr, ptr %t150, !tbaa !27
  %t152 = getelementptr i64, ptr %t151, i64 %t148
  %t153 = load i64, ptr %t152, !tbaa !34
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t157 = getelementptr %"compiler/lower:lowering", ptr %t155, i32 0, i32 11
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeId_3e_2eSetAt_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t157, i64 %t153, i32 -1)
  br label %bb48
bb48:
  call void @__olang_scope_close(ptr %s10)
  br label %bb49
bb49:
  %t161 = load i64, ptr %l15, !tbaa !24
  %t163 = add i64 %t161, 1
  store i64 %t163, ptr %l15, !tbaa !24
  br label %bb44
bb50:
  %t165 = load i64, ptr %l12, !tbaa !24
  %t166 = load i64, ptr %l14, !tbaa !24
  %t169 = add i64 %t165, %t166
  store i64 %t169, ptr %l12, !tbaa !24
  call void @__olang_scope_close(ptr %s9)
  br label %bb51
bb51:
  br label %bb37
bb52:
  %t172 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l4)
  store i64 %t172, ptr %l114
  br label %bb53
bb53:
  %t173 = load i64, ptr %l114, !tbaa !24
  %t174 = sub i64 %t173, 1
  store i64 %t174, ptr %l17, !tbaa !24
  br label %bb54
bb54:
  store %olang.scope zeroinitializer, ptr %s13
  %t176 = load i64, ptr %l17, !tbaa !24
  %t178 = icmp sge i64 %t176, 0
  %t180 = xor i1 %t178, true
  br i1 %t180, label %bb55, label %bb56
bb55:
  call void @__olang_scope_close(ptr %s13)
  br label %bb69
bb56:
  br label %bb57
bb57:
  %t182 = load ptr, ptr %l0, !tbaa !29
  %t184 = getelementptr %"compiler/lower:lowering", ptr %t182, i32 0, i32 0
  %t185 = load ptr, ptr %t184, !tbaa !29
  %t187 = getelementptr %"compiler/lower:Lowerer", ptr %t185, i32 0, i32 5
  %t188 = load i1, ptr %t187, !tbaa !21
  br i1 %t188, label %bb58, label %bb59
bb58:
  store %olang.scope zeroinitializer, ptr %s14
  %t190 = load ptr, ptr %l0, !tbaa !29
  store ptr %t190, ptr %l122, !tbaa !29
  %t191 = load ptr, ptr %l0, !tbaa !29
  %t193 = getelementptr %"compiler/lower:lowering", ptr %t191, i32 0, i32 1
  %t194 = load ptr, ptr %t193, !tbaa !29
  %t196 = getelementptr %"compiler/typed:Body", ptr %t194, i32 0, i32 8
  store ptr %t196, ptr %l125, !tbaa !29
  %t197 = load ptr, ptr %l0, !tbaa !29
  %t199 = getelementptr %"compiler/lower:lowering", ptr %t197, i32 0, i32 10
  store ptr %t199, ptr %l127, !tbaa !29
  %t200 = load i64, ptr %l17, !tbaa !24
  %t203 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l4, i64 %t200)
  store i64 %t203, ptr %l130
  br label %bb60
bb59:
  br label %bb64
bb60:
  %t204 = load ptr, ptr %l127, !tbaa !29
  %t205 = load i64, ptr %l130, !tbaa !24
  %t206 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aBlock_26_3e_2eAt_Hef81d01aee8891fe569e7a3039d88992(ptr %v0, ptr %s14, ptr %t204, i64 %t205)
  store ptr %t206, ptr %l131
  br label %bb61
bb61:
  %t207 = load ptr, ptr %l131, !tbaa !29
  %t209 = getelementptr %"compiler/typed:Block", ptr %t207, i32 0, i32 0
  %t210 = load i32, ptr %t209, !tbaa !23
  %t212 = sext i32 %t210 to i64
  %t213 = load ptr, ptr %l125, !tbaa !29
  %t215 = call %"compiler/typed:BlockInfo" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aBlockInfo_3e_2eA_Hdb91c1ab6f912bb6141763aa02d0b766(ptr %v0, ptr %t213, i64 %t212)
  store %"compiler/typed:BlockInfo" %t215, ptr %l135
  br label %bb62
bb62:
  %t216 = getelementptr %"compiler/typed:BlockInfo", ptr %l135, i32 0, i32 2
  %t217 = load %"compiler/source:Span", ptr %t216
  %t218 = getelementptr %"compiler/lower:level", ptr %l2, i32 0, i32 0
  %t219 = load i32, ptr %t218, !tbaa !23
  %t220 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  store { i64, [21 x i64] } zeroinitializer, ptr %t221
  %t222 = getelementptr { i64, [21 x i64] }, ptr %t221, i32 0, i32 0
  store i64 13, ptr %t222
  %t224 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %t217, 0
  %t226 = insertvalue { %"compiler/source:Span", i32, i32 } %t224, i32 %t219, 1
  %t228 = insertvalue { %"compiler/source:Span", i32, i32 } %t226, i32 %t220, 2
  %t229 = getelementptr { i64, [21 x i64] }, ptr %t221, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t228, ptr %t229
  %t230 = load { i64, [21 x i64] }, ptr %t221
  %t232 = call ptr @__olang_scope_alloc_a(ptr %s14, i64 176, i64 8)
  store { i64, [21 x i64] } %t230, ptr %t232
  %t233 = load ptr, ptr %l122, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s14, ptr %t233, ptr %t232)
  br label %bb63
bb63:
  call void @__olang_scope_close(ptr %s14)
  br label %bb64
bb64:
  %t235 = load ptr, ptr %l0, !tbaa !29
  store ptr %t235, ptr %l141, !tbaa !29
  %t236 = load ptr, ptr %l0, !tbaa !29
  %t238 = getelementptr %"compiler/lower:lowering", ptr %t236, i32 0, i32 10
  store ptr %t238, ptr %l143, !tbaa !29
  %t239 = load i64, ptr %l17, !tbaa !24
  %t242 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l4, i64 %t239)
  store i64 %t242, ptr %l146
  br label %bb65
bb65:
  %t243 = load ptr, ptr %l143, !tbaa !29
  %t244 = load i64, ptr %l146, !tbaa !24
  %t245 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aBlock_26_3e_2eAt_Hef81d01aee8891fe569e7a3039d88992(ptr %v0, ptr %v0, ptr %t243, i64 %t244)
  store ptr %t245, ptr %l147
  br label %bb66
bb66:
  %t246 = load ptr, ptr %l141, !tbaa !29
  %t247 = load ptr, ptr %l147, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eblock(ptr %v0, ptr %v0, ptr %t246, ptr %t247)
  br label %bb67
bb67:
  call void @__olang_scope_close(ptr %s13)
  br label %bb68
bb68:
  %t248 = load i64, ptr %l17, !tbaa !24
  %t250 = sub i64 %t248, 1
  store i64 %t250, ptr %l17, !tbaa !24
  br label %bb54
bb69:
  store ptr %l4, ptr %l18, !tbaa !29
  store i64 0, ptr %l19, !tbaa !24
  br label %bb70
bb70:
  store %olang.scope zeroinitializer, ptr %s17
  %t253 = load ptr, ptr %l18, !tbaa !29
  %t254 = load i64, ptr %l19, !tbaa !24
  %t257 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %s0, ptr %t253, i64 %t254)
  %t258 = extractvalue { i32, { i64, ptr } } %t257, 1
  %t259 = extractvalue { i32, { i64, ptr } } %t257, 0
  store i32 %t259, ptr %l155
  %t260 = icmp ne i32 %t259, 0
  br i1 %t260, label %bb72, label %ok.261
ok.261:
  store { i64, ptr } %t258, ptr %l154
  br label %bb71
bb71:
  %t262 = load { i64, ptr }, ptr %l154, !tbaa !27
  store { i64, ptr } %t262, ptr %l151, !tbaa !27
  br label %bb76
bb72:
  %t263 = load i32, ptr %l155, !tbaa !23
  %t264 = ashr i32 %t263, 16
  %t266 = icmp eq i32 %t264, 1
  br i1 %t266, label %bb73, label %bb74
bb73:
  br label %bb75
bb74:
  call void @__olang_check_failed(ptr @olang_loc_13daf6ec8e30e943_ad19332534c71267)
  unreachable
bb75:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s17)
  br label %bb85
bb76:
  %t268 = load { i64, ptr }, ptr %l151, !tbaa !27
  store { i64, ptr } %t268, ptr %l20, !tbaa !27
  %t269 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t271 = extractvalue { i64, ptr } %t269, 0
  store i64 %t271, ptr %l21, !tbaa !24
  store i64 0, ptr %l22, !tbaa !24
  br label %bb77
bb77:
  store %olang.scope zeroinitializer, ptr %s18
  %t273 = load i64, ptr %l22, !tbaa !24
  %t274 = load i64, ptr %l21, !tbaa !24
  %t277 = icmp slt i64 %t273, %t274
  %t279 = xor i1 %t277, true
  br i1 %t279, label %bb78, label %bb79
bb78:
  call void @__olang_scope_close(ptr %s18)
  br label %bb83
bb79:
  br label %bb80
bb80:
  %t281 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t281, ptr %l164, !tbaa !27
  %t282 = load i64, ptr %l22, !tbaa !24
  %t284 = getelementptr { i64, ptr }, ptr %l164, i32 0, i32 1
  %t285 = load ptr, ptr %t284, !tbaa !27
  %t286 = getelementptr i64, ptr %t285, i64 %t282
  %t287 = load i64, ptr %t286, !tbaa !34
  %t289 = load ptr, ptr %l0, !tbaa !29
  %t291 = getelementptr %"compiler/lower:lowering", ptr %t289, i32 0, i32 11
  %t293 = getelementptr %"compiler/lower:level", ptr %l2, i32 0, i32 0
  %t294 = load i32, ptr %t293, !tbaa !23
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeId_3e_2eSetAt_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t291, i64 %t287, i32 %t294)
  br label %bb81
bb81:
  call void @__olang_scope_close(ptr %s18)
  br label %bb82
bb82:
  %t298 = load i64, ptr %l22, !tbaa !24
  %t300 = add i64 %t298, 1
  store i64 %t300, ptr %l22, !tbaa !24
  br label %bb77
bb83:
  %t302 = load i64, ptr %l19, !tbaa !24
  %t303 = load i64, ptr %l21, !tbaa !24
  %t306 = add i64 %t302, %t303
  store i64 %t306, ptr %l19, !tbaa !24
  call void @__olang_scope_close(ptr %s17)
  br label %bb84
bb84:
  br label %bb70
bb85:
  br label %bb86
bb86:
  store %olang.scope zeroinitializer, ptr %s20
  %t309 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3alevel_3e_2eLen_3ccompiler_2flower_3alevel_3e(ptr %s0, ptr %l3)
  store i64 %t309, ptr %l177
  br label %bb87
bb87:
  %t310 = load i64, ptr %l177, !tbaa !24
  %t311 = icmp sgt i64 %t310, 0
  %t313 = xor i1 %t311, true
  br i1 %t313, label %bb88, label %bb89
bb88:
  call void @__olang_scope_close(ptr %s20)
  br label %bb97
bb89:
  br label %bb90
bb90:
  %t315 = load ptr, ptr %l0, !tbaa !29
  %t317 = getelementptr %"compiler/lower:lowering", ptr %t315, i32 0, i32 9
  store ptr %t317, ptr %l181, !tbaa !29
  %t319 = call { i32, %"compiler/lower:level" } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3alevel_3e_2ePop_3ccompiler_2flower_3alevel_3e(ptr %s0, ptr %l3)
  %t320 = extractvalue { i32, %"compiler/lower:level" } %t319, 1
  %t321 = extractvalue { i32, %"compiler/lower:level" } %t319, 0
  store i32 %t321, ptr %l185
  %t322 = icmp ne i32 %t321, 0
  br i1 %t322, label %bb92, label %ok.323
ok.323:
  store %"compiler/lower:level" %t320, ptr %l184
  br label %bb91
bb91:
  %t324 = load %"compiler/lower:level", ptr %l184
  store %"compiler/lower:level" %t324, ptr %l182
  br label %bb94
bb92:
  br label %bb93
bb93:
  call void @__olang_ert_req_clear()
  call void @__olang_check_failed(ptr @olang_loc_d7de50d0c280a1c2_f8c3e581c8870786)
  unreachable
bb94:
  %t325 = load ptr, ptr %l181, !tbaa !29
  %t326 = load %"compiler/lower:level", ptr %l182
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3alevel_3e_2ePush_3ccompiler_2flower_3alevel_3e(ptr %v0, ptr %t325, %"compiler/lower:level" %t326)
  br label %bb95
bb95:
  call void @__olang_scope_close(ptr %s20)
  br label %bb96
bb96:
  br label %bb86
bb97:
  %t327 = load ptr, ptr %l0, !tbaa !29
  %t329 = getelementptr %"compiler/lower:lowering", ptr %t327, i32 0, i32 7
  %t330 = load i1, ptr %t329, !tbaa !21
  br i1 %t330, label %bb98, label %bb99
bb98:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb99:
  br label %bb100
bb100:
  %t332 = getelementptr %"compiler/lower:level", ptr %l2, i32 0, i32 1
  %t333 = load i32, ptr %t332, !tbaa !23
  %t335 = icmp sge i32 %t333, 0
  br i1 %t335, label %bb101, label %bb102
bb101:
  %t337 = load ptr, ptr %l0, !tbaa !29
  %t339 = getelementptr %"compiler/lower:lowering", ptr %t337, i32 0, i32 1
  %t340 = load ptr, ptr %t339, !tbaa !29
  %t342 = getelementptr %"compiler/typed:Body", ptr %t340, i32 0, i32 8
  %t343 = getelementptr %"compiler/lower:level", ptr %l2, i32 0, i32 1
  %t344 = load i32, ptr %t343, !tbaa !23
  %t346 = sext i32 %t344 to i64
  %t349 = call %"compiler/typed:BlockInfo" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aBlockInfo_3e_2eA_Hdb91c1ab6f912bb6141763aa02d0b766(ptr %v0, ptr %t342, i64 %t346)
  store %"compiler/typed:BlockInfo" %t349, ptr %l196
  br label %bb103
bb102:
  %t350 = load ptr, ptr %l0, !tbaa !29
  %t352 = getelementptr %"compiler/lower:lowering", ptr %t350, i32 0, i32 1
  %t353 = load ptr, ptr %t352, !tbaa !29
  %t355 = getelementptr %"compiler/typed:Body", ptr %t353, i32 0, i32 4
  %t356 = load %"compiler/source:Span", ptr %t355
  store %"compiler/source:Span" %t356, ptr %l190
  br label %bb104
bb103:
  %t358 = getelementptr %"compiler/typed:BlockInfo", ptr %l196, i32 0, i32 2
  %t359 = load %"compiler/source:Span", ptr %t358
  store %"compiler/source:Span" %t359, ptr %l190
  br label %bb104
bb104:
  %t361 = load %"compiler/source:Span", ptr %l190
  store %"compiler/source:Span" %t361, ptr %l24
  %t362 = getelementptr %"compiler/lower:level", ptr %l2, i32 0, i32 2
  %t363 = load i32, ptr %t362
  %t365 = trunc i64 3 to i32
  %t366 = icmp eq i32 %t363, %t365
  br i1 %t366, label %bb105, label %bb106
bb105:
  %t368 = load ptr, ptr %l0, !tbaa !29
  %t370 = getelementptr %"compiler/lower:lowering", ptr %t368, i32 0, i32 3
  %t371 = getelementptr %"compiler/mir:Fn", ptr %t370, i32 0, i32 8
  %t372 = getelementptr %"compiler/lower:level", ptr %l2, i32 0, i32 0
  %t373 = load i32, ptr %t372, !tbaa !23
  %t375 = sext i32 %t373 to i64
  %t378 = call %"compiler/mir:ScopeInfo" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeInfo_3e_2eAt_3ccompiler_2fmir_3aScopeInfo_3e(ptr %v0, ptr %t371, i64 %t375)
  store %"compiler/mir:ScopeInfo" %t378, ptr %l207
  br label %bb107
bb106:
  br label %bb127
bb107:
  %t379 = getelementptr %"compiler/mir:ScopeInfo", ptr %l207, i32 0, i32 4
  %t380 = load i32, ptr %t379, !tbaa !23
  store i32 %t380, ptr %l25, !tbaa !23
  %t382 = load ptr, ptr %l0, !tbaa !29
  %t384 = getelementptr %"compiler/lower:lowering", ptr %t382, i32 0, i32 3
  %t386 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t384)
  store i32 %t386, ptr %l211
  br label %bb108
bb108:
  %t387 = load i32, ptr %l211, !tbaa !23
  store i32 %t387, ptr %l26, !tbaa !23
  %t388 = load ptr, ptr %l0, !tbaa !29
  %t390 = getelementptr %"compiler/lower:lowering", ptr %t388, i32 0, i32 2
  %t391 = load ptr, ptr %t390, !tbaa !29
  %t392 = load i32, ptr %l25, !tbaa !23
  %t395 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t391, i32 %t392)
  store { i64, ptr } %t395, ptr %l215
  br label %bb109
bb109:
  %t396 = load { i64, ptr }, ptr %l215, !tbaa !27
  %t397 = extractvalue { i64, ptr } %t396, 0
  %t399 = icmp eq i64 %t397, 0
  br i1 %t399, label %bb110, label %bb111
bb110:
  %t401 = load ptr, ptr %l0, !tbaa !29
  %t402 = load %"compiler/source:Span", ptr %l24
  %t403 = getelementptr %"compiler/lower:level", ptr %l2, i32 0, i32 0
  %t404 = load i32, ptr %t403, !tbaa !23
  %t405 = load i32, ptr %l26, !tbaa !23
  %t406 = load i32, ptr @G_2ecompiler_2fmir_2eNoLocal, !tbaa !23
  %t407 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  store { i64, [7 x i64] } zeroinitializer, ptr %t408
  %t409 = getelementptr { i64, [7 x i64] }, ptr %t408, i32 0, i32 0
  store i64 7, ptr %t409
  %t411 = insertvalue { %"compiler/source:Span", i32, i32, i32, i32 } undef, %"compiler/source:Span" %t402, 0
  %t413 = insertvalue { %"compiler/source:Span", i32, i32, i32, i32 } %t411, i32 %t404, 1
  %t415 = insertvalue { %"compiler/source:Span", i32, i32, i32, i32 } %t413, i32 %t405, 2
  %t417 = insertvalue { %"compiler/source:Span", i32, i32, i32, i32 } %t415, i32 %t406, 3
  %t419 = insertvalue { %"compiler/source:Span", i32, i32, i32, i32 } %t417, i32 %t407, 4
  %t420 = getelementptr { i64, [7 x i64] }, ptr %t408, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32, i32, i32 } %t419, ptr %t420
  %t421 = load { i64, [7 x i64] }, ptr %t408
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t401, { i64, [7 x i64] } %t421)
  br label %bb112
bb111:
  %t424 = load ptr, ptr %l0, !tbaa !29
  %t426 = getelementptr %"compiler/lower:lowering", ptr %t424, i32 0, i32 18
  %t427 = load i1, ptr %t426, !tbaa !21
  br i1 %t427, label %bb113, label %bb114
bb112:
  br label %bb125
bb113:
  %t429 = load ptr, ptr %l0, !tbaa !29
  %t430 = load i32, ptr @G_2ecompiler_2fmir_2eI32T, !tbaa !23
  %t431 = load %"compiler/source:Span", ptr %l24
  %t435 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2etemp(ptr %v0, ptr %t429, i32 %t430, %"compiler/source:Span" %t431)
  store i32 %t435, ptr %l230
  br label %bb115
bb114:
  store %olang.scope zeroinitializer, ptr %s27
  %t436 = load ptr, ptr %l0, !tbaa !29
  %t437 = load i32, ptr @G_2ecompiler_2fmir_2eI32T, !tbaa !23
  %t438 = load %"compiler/source:Span", ptr %l24
  %t442 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2etemp(ptr %v0, ptr %t436, i32 %t437, %"compiler/source:Span" %t438)
  store i32 %t442, ptr %l241
  br label %bb117
bb115:
  %t443 = load i32, ptr %l230, !tbaa !23
  %t444 = load ptr, ptr %l0, !tbaa !29
  %t445 = load %"compiler/source:Span", ptr %l24
  %t446 = getelementptr %"compiler/lower:level", ptr %l2, i32 0, i32 0
  %t447 = load i32, ptr %t446, !tbaa !23
  %t448 = load i32, ptr %l26, !tbaa !23
  %t450 = load i32, ptr %l26, !tbaa !23
  store { i64, [7 x i64] } zeroinitializer, ptr %t451
  %t452 = getelementptr { i64, [7 x i64] }, ptr %t451, i32 0, i32 0
  store i64 7, ptr %t452
  %t454 = insertvalue { %"compiler/source:Span", i32, i32, i32, i32 } undef, %"compiler/source:Span" %t445, 0
  %t456 = insertvalue { %"compiler/source:Span", i32, i32, i32, i32 } %t454, i32 %t447, 1
  %t458 = insertvalue { %"compiler/source:Span", i32, i32, i32, i32 } %t456, i32 %t448, 2
  %t460 = insertvalue { %"compiler/source:Span", i32, i32, i32, i32 } %t458, i32 %t443, 3
  %t462 = insertvalue { %"compiler/source:Span", i32, i32, i32, i32 } %t460, i32 %t450, 4
  %t463 = getelementptr { i64, [7 x i64] }, ptr %t451, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32, i32, i32 } %t462, ptr %t463
  %t464 = load { i64, [7 x i64] }, ptr %t451
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t444, { i64, [7 x i64] } %t464)
  br label %bb116
bb116:
  br label %bb124
bb117:
  %t467 = load i32, ptr %l241, !tbaa !23
  store i32 %t467, ptr %l28, !tbaa !23
  %t468 = load ptr, ptr %l0, !tbaa !29
  %t470 = getelementptr %"compiler/lower:lowering", ptr %t468, i32 0, i32 3
  %t472 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t470)
  store i32 %t472, ptr %l244
  br label %bb118
bb118:
  %t473 = load i32, ptr %l244, !tbaa !23
  store i32 %t473, ptr %l29, !tbaa !23
  %t474 = load ptr, ptr %l0, !tbaa !29
  %t475 = load %"compiler/source:Span", ptr %l24
  %t476 = getelementptr %"compiler/lower:level", ptr %l2, i32 0, i32 0
  %t477 = load i32, ptr %t476, !tbaa !23
  %t478 = load i32, ptr %l26, !tbaa !23
  %t479 = load i32, ptr %l28, !tbaa !23
  %t480 = load i32, ptr %l29, !tbaa !23
  store { i64, [7 x i64] } zeroinitializer, ptr %t481
  %t482 = getelementptr { i64, [7 x i64] }, ptr %t481, i32 0, i32 0
  store i64 7, ptr %t482
  %t484 = insertvalue { %"compiler/source:Span", i32, i32, i32, i32 } undef, %"compiler/source:Span" %t475, 0
  %t486 = insertvalue { %"compiler/source:Span", i32, i32, i32, i32 } %t484, i32 %t477, 1
  %t488 = insertvalue { %"compiler/source:Span", i32, i32, i32, i32 } %t486, i32 %t478, 2
  %t490 = insertvalue { %"compiler/source:Span", i32, i32, i32, i32 } %t488, i32 %t479, 3
  %t492 = insertvalue { %"compiler/source:Span", i32, i32, i32, i32 } %t490, i32 %t480, 4
  %t493 = getelementptr { i64, [7 x i64] }, ptr %t481, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32, i32, i32 } %t492, ptr %t493
  %t494 = load { i64, [7 x i64] }, ptr %t481
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t474, { i64, [7 x i64] } %t494)
  br label %bb119
bb119:
  %t497 = load ptr, ptr %l0, !tbaa !29
  %t498 = load i32, ptr %l29, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t497, i32 %t498)
  br label %bb120
bb120:
  %t501 = load ptr, ptr %l0, !tbaa !29
  %t502 = load %"compiler/source:Span", ptr %l24
  %t503 = getelementptr %"compiler/lower:level", ptr %l2, i32 0, i32 0
  %t504 = load i32, ptr %t503, !tbaa !23
  store { i64, [21 x i64] } zeroinitializer, ptr %t505
  %t506 = getelementptr { i64, [21 x i64] }, ptr %t505, i32 0, i32 0
  store i64 4, ptr %t506
  %t508 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t502, 0
  %t510 = insertvalue { %"compiler/source:Span", i32 } %t508, i32 %t504, 1
  %t511 = getelementptr { i64, [21 x i64] }, ptr %t505, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t510, ptr %t511
  %t512 = load { i64, [21 x i64] }, ptr %t505
  %t514 = call ptr @__olang_scope_alloc_a(ptr %s27, i64 176, i64 8)
  store { i64, [21 x i64] } %t512, ptr %t514
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s27, ptr %t501, ptr %t514)
  br label %bb121
bb121:
  %t517 = load ptr, ptr %l0, !tbaa !29
  store ptr %t517, ptr %l259, !tbaa !29
  %t518 = load i64, ptr %l1, !tbaa !24
  store i64 %t518, ptr %l260, !tbaa !24
  %t519 = getelementptr %"compiler/lower:level", ptr %l2, i32 0, i32 0
  %t520 = load i32, ptr %t519, !tbaa !23
  store i32 %t520, ptr %l261, !tbaa !23
  %t521 = load i32, ptr %l28, !tbaa !23
  %t523 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t521)
  store %"compiler/mir:Place" %t523, ptr %l263
  br label %bb122
bb122:
  store { i64, [4 x i64] } zeroinitializer, ptr %t524
  %t525 = getelementptr { i64, [4 x i64] }, ptr %t524, i32 0, i32 0
  store i64 1, ptr %t525
  %t526 = load %"compiler/mir:Place", ptr %l263
  %t527 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t526, 0
  %t528 = getelementptr { i64, [4 x i64] }, ptr %t524, i32 0, i32 1
  store { %"compiler/mir:Place" } %t527, ptr %t528
  %t529 = load { i64, [4 x i64] }, ptr %t524
  %t530 = load i32, ptr %l25, !tbaa !23
  %t531 = load %"compiler/source:Span", ptr %l24
  %t532 = load ptr, ptr %l259, !tbaa !29
  %t533 = load i64, ptr %l260, !tbaa !24
  %t534 = load i32, ptr %l261, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2ejoinFailed(ptr %v0, ptr %t532, i64 %t533, i32 %t534, { i64, [4 x i64] } %t529, i32 %t530, %"compiler/source:Span" %t531)
  br label %bb123
bb123:
  call void @__olang_scope_close(ptr %s27)
  br label %bb124
bb124:
  br label %bb125
bb125:
  %t538 = load ptr, ptr %l0, !tbaa !29
  %t539 = load i32, ptr %l26, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t538, i32 %t539)
  br label %bb126
bb126:
  br label %bb127
bb127:
  %t542 = load ptr, ptr %l0, !tbaa !29
  %t543 = load %"compiler/source:Span", ptr %l24
  %t544 = getelementptr %"compiler/lower:level", ptr %l2, i32 0, i32 0
  %t545 = load i32, ptr %t544, !tbaa !23
  store { i64, [21 x i64] } zeroinitializer, ptr %t546
  %t547 = getelementptr { i64, [21 x i64] }, ptr %t546, i32 0, i32 0
  store i64 4, ptr %t547
  %t549 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t543, 0
  %t551 = insertvalue { %"compiler/source:Span", i32 } %t549, i32 %t545, 1
  %t552 = getelementptr { i64, [21 x i64] }, ptr %t546, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t551, ptr %t552
  %t553 = load { i64, [21 x i64] }, ptr %t546
  %t555 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t553, ptr %t555
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s0, ptr %t542, ptr %t555)
  br label %bb128
bb128:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2flower_2ecompiler_2flower_3alowering_2eflag(ptr %v0, ptr %a0, i1 %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l7 = alloca i32
  %l8 = alloca ptr
  %l9 = alloca %"compiler/source:Span"
  %l11 = alloca %"compiler/mir:Place"
  %l15 = alloca { i64, [4 x i64] }
  %s0 = alloca %olang.scope
  %rv = alloca i32
  %t21 = alloca { i64, [15 x i64] }, align 8
  %t27 = alloca { i64, [21 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t3 = load %"compiler/source:Span", ptr %l2
  %t7 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2etemp(ptr %v0, ptr %t1, i32 %t2, %"compiler/source:Span" %t3)
  store i32 %t7, ptr %l7
  br label %bb1
bb1:
  %t8 = load i32, ptr %l7, !tbaa !23
  store i32 %t8, ptr %l3, !tbaa !23
  %t9 = load ptr, ptr %l0, !tbaa !29
  store ptr %t9, ptr %l8, !tbaa !29
  %t10 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t10, ptr %l9
  %t11 = load i32, ptr %l3, !tbaa !23
  %t13 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t11)
  store %"compiler/mir:Place" %t13, ptr %l11
  br label %bb2
bb2:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = load %"compiler/source:Span", ptr %l2
  %t20 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2econstBool(ptr %v0, ptr %t14, i1 %a1, %"compiler/source:Span" %t16)
  store { i64, [4 x i64] } %t20, ptr %l15
  br label %bb3
bb3:
  store { i64, [15 x i64] } zeroinitializer, ptr %t21
  %t22 = getelementptr { i64, [15 x i64] }, ptr %t21, i32 0, i32 0
  store i64 0, ptr %t22
  %t23 = load { i64, [4 x i64] }, ptr %l15
  %t24 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t23, 0
  %t25 = getelementptr { i64, [15 x i64] }, ptr %t21, i32 0, i32 1
  store { { i64, [4 x i64] } } %t24, ptr %t25
  %t26 = load { i64, [15 x i64] }, ptr %t21
  store { i64, [21 x i64] } zeroinitializer, ptr %t27
  %t28 = getelementptr { i64, [21 x i64] }, ptr %t27, i32 0, i32 0
  store i64 0, ptr %t28
  %t29 = load %"compiler/source:Span", ptr %l9
  %t30 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t29, 0
  %t31 = load %"compiler/mir:Place", ptr %l11
  %t32 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t30, %"compiler/mir:Place" %t31, 1
  %t34 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t32, { i64, [15 x i64] } %t26, 2
  %t35 = getelementptr { i64, [21 x i64] }, ptr %t27, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t34, ptr %t35
  %t36 = load { i64, [21 x i64] }, ptr %t27
  %t38 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t36, ptr %t38
  %t39 = load ptr, ptr %l8, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s0, ptr %t39, ptr %t38)
  br label %bb4
bb4:
  %t41 = load i32, ptr %l3, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t41, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2egap(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l8 = alloca ptr
  %l15 = alloca %"compiler/lower:Gap"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 8
  %t4 = load i1, ptr %t3, !tbaa !21
  %t6 = xor i1 %t4, true
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/lower:lowering", ptr %t8, i32 0, i32 0
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t13 = getelementptr %"compiler/lower:Lowerer", ptr %t11, i32 0, i32 3
  store ptr %t13, ptr %l8, !tbaa !29
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/lower:lowering", ptr %t14, i32 0, i32 4
  %t17 = load i64, ptr %t16, !tbaa !24
  %t21 = extractvalue { i64, ptr } %a2, 1
  %t22 = extractvalue { i64, ptr } %a2, 0
  %t23 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t22)
  call void @olang_textcopy(ptr %t23, ptr %t21, i64 %t22)
  %t24 = insertvalue { i64, ptr } undef, i64 %t22, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t23, 1
  %t27 = extractvalue { i64, ptr } %t25, 0
  %t28 = extractvalue { i64, ptr } %t25, 1
  %t29 = mul i64 %t27, 1
  %t30 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t29)
  call void @llvm.memcpy.p0.p0.i64(ptr %t30, ptr %t28, i64 %t29, i1 false)
  %t31 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  %t36 = call %"compiler/lower:Gap" @compiler_2flower_3aGap_2ector(ptr %v0, ptr %v0, i64 %t17, %"compiler/source:Span" %a1, { i64, ptr } %t32)
  store %"compiler/lower:Gap" %t36, ptr %l15
  br label %bb3
bb2:
  br label %bb5
bb3:
  %t37 = load ptr, ptr %l8, !tbaa !29
  %t38 = load %"compiler/lower:Gap", ptr %l15
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3aGap_3e_2ePush_3ccompiler_2flower_3aGap_3e(ptr %v0, ptr %v0, ptr %t37, %"compiler/lower:Gap" %t38)
  br label %bb4
bb4:
  br label %bb5
bb5:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/lower:lowering", ptr %t39, i32 0, i32 8
  store i1 true, ptr %t41, !tbaa !21
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2ehelper(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca %"compiler/lower:pl"
  %l18 = alloca %"compiler/lower:pl"
  %l20 = alloca %"compiler/lower:pl"
  %l21 = alloca ptr
  %l27 = alloca { i64, [4 x i64] }
  %l32 = alloca ptr
  %l33 = alloca ptr
  %l35 = alloca %"compiler/lower:pl"
  %l38 = alloca { i64, [4 x i64] }
  %l44 = alloca { i64, ptr }
  %l45 = alloca ptr
  %l49 = alloca { i64, ptr }
  %l51 = alloca { i64, ptr }
  %l53 = alloca ptr
  %l57 = alloca { i64, [4 x i64] }
  %l62 = alloca { i64, ptr }
  %l63 = alloca ptr
  %l64 = alloca %"compiler/mir:Place"
  %l66 = alloca ptr
  %l68 = alloca %"compiler/lower:pl"
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %t96 = alloca { i64, [1 x i64] }, align 8
  %t131 = alloca { i64, [1 x i64] }, align 8
  %t146 = alloca { i64, [4 x i64] }, align 8
  %t160 = alloca { i64, [1 x i64] }, align 8
  %t172 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/lower:lowering", ptr %t6, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t11 = getelementptr %"compiler/typed:Body", ptr %t9, i32 0, i32 4
  %t12 = load %"compiler/source:Span", ptr %t11
  store %"compiler/source:Span" %t12, ptr %l4
  %t14 = load i32, ptr %l1
  %t16 = trunc i64 1 to i32
  %t17 = icmp eq i32 %t14, %t16
  br i1 %t17, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb9
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t20 = mul i64 0, 16
  %t21 = call ptr @__olang_scope_alloc_zeroed(ptr %s1, i64 %t20)
  %t22 = insertvalue { i64, ptr } undef, i64 0, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t21, 1
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eprologue(ptr %v0, ptr %s1, ptr %t19, { i64, ptr } %t23)
  br label %bb4
bb4:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = call %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2eat(ptr %v0, ptr %s1, ptr %t26, i32 0)
  store %"compiler/lower:pl" %t28, ptr %l18
  br label %bb5
bb5:
  %t29 = load %"compiler/lower:pl", ptr %l18
  store %"compiler/lower:pl" %t29, ptr %l5
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = call %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2eat(ptr %v0, ptr %s1, ptr %t30, i32 1)
  store %"compiler/lower:pl" %t32, ptr %l20
  br label %bb6
bb6:
  %t33 = load %"compiler/lower:pl", ptr %l20
  %t34 = load ptr, ptr %l0, !tbaa !29
  store ptr %t34, ptr %l21, !tbaa !29
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load %"compiler/lower:pl", ptr %l5
  %t38 = load i32, ptr %l2, !tbaa !23
  %t39 = load %"compiler/source:Span", ptr %l4
  %t45 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eequalAt(ptr %v0, ptr %s1, ptr %s1, ptr %t35, %"compiler/lower:pl" %t36, %"compiler/lower:pl" %t33, i32 %t38, %"compiler/source:Span" %t39, i1 true)
  store { i64, [4 x i64] } %t45, ptr %l27
  br label %bb7
bb7:
  %t46 = load ptr, ptr %l21, !tbaa !29
  %t47 = load { i64, [4 x i64] }, ptr %l27
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eepilogue(ptr %v0, ptr %t46, { i64, [4 x i64] } %t47)
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s1)
  br label %bb38
bb9:
  %t48 = load i32, ptr %l1
  %t50 = trunc i64 2 to i32
  %t51 = icmp eq i32 %t48, %t50
  br i1 %t51, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb17
bb12:
  store %olang.scope zeroinitializer, ptr %s2
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t54 = mul i64 0, 16
  %t55 = call ptr @__olang_scope_alloc_zeroed(ptr %s2, i64 %t54)
  %t56 = insertvalue { i64, ptr } undef, i64 0, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t55, 1
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eprologue(ptr %v0, ptr %s2, ptr %t53, { i64, ptr } %t57)
  br label %bb13
bb13:
  %t60 = load ptr, ptr %l0, !tbaa !29
  store ptr %t60, ptr %l32, !tbaa !29
  %t61 = load ptr, ptr %l0, !tbaa !29
  store ptr %t61, ptr %l33, !tbaa !29
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = call %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2eat(ptr %v0, ptr %s2, ptr %t62, i32 0)
  store %"compiler/lower:pl" %t64, ptr %l35
  br label %bb14
bb14:
  %t65 = load i32, ptr %l2, !tbaa !23
  %t66 = load %"compiler/source:Span", ptr %l4
  %t67 = load ptr, ptr %l33, !tbaa !29
  %t68 = load %"compiler/lower:pl", ptr %l35
  %t71 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ehashAt(ptr %v0, ptr %s2, ptr %t67, %"compiler/lower:pl" %t68, i32 %t65, %"compiler/source:Span" %t66, i1 true)
  store { i64, [4 x i64] } %t71, ptr %l38
  br label %bb15
bb15:
  %t72 = load ptr, ptr %l32, !tbaa !29
  %t73 = load { i64, [4 x i64] }, ptr %l38
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eepilogue(ptr %v0, ptr %t72, { i64, [4 x i64] } %t73)
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s2)
  br label %bb38
bb17:
  %t74 = load i32, ptr %l1
  %t76 = trunc i64 3 to i32
  %t77 = icmp eq i32 %t74, %t76
  br i1 %t77, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb28
bb20:
  store %olang.scope zeroinitializer, ptr %s3
  %t79 = load ptr, ptr %l3, !tbaa !29
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t82 = getelementptr %"compiler/lower:lowering", ptr %t80, i32 0, i32 3
  %t83 = getelementptr %"compiler/mir:Fn", ptr %t82, i32 0, i32 1
  %t84 = load i32, ptr %t83, !tbaa !23
  %t87 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopeVarsOf(ptr %v0, ptr %s3, ptr %t79, i32 %t84)
  store { i64, ptr } %t87, ptr %l44
  br label %bb21
bb21:
  %t88 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t89 = load ptr, ptr %l0, !tbaa !29
  store ptr %t89, ptr %l45, !tbaa !29
  %t92 = extractvalue { i64, ptr } %t88, 0
  %t94 = icmp sgt i64 %t92, 0
  br i1 %t94, label %bb22, label %bb23
bb22:
  store { i64, [1 x i64] } zeroinitializer, ptr %t96
  %t97 = getelementptr { i64, [1 x i64] }, ptr %t96, i32 0, i32 0
  store i64 1, ptr %t97
  %t98 = load { i64, [1 x i64] }, ptr %t96
  %t99 = mul i64 1, 16
  %t100 = call ptr @__olang_scope_alloc_zeroed(ptr %s3, i64 %t99)
  %t101 = insertvalue { i64, ptr } undef, i64 1, 0
  %t102 = insertvalue { i64, ptr } %t101, ptr %t100, 1
  store { i64, ptr } %t102, ptr %l51, !tbaa !27
  %t104 = getelementptr { i64, ptr }, ptr %l51, i32 0, i32 1
  %t105 = load ptr, ptr %t104, !tbaa !27
  %t106 = getelementptr { i64, [1 x i64] }, ptr %t105, i64 0
  store { i64, [1 x i64] } %t98, ptr %t106
  %t107 = load { i64, ptr }, ptr %l51, !tbaa !27
  store { i64, ptr } %t107, ptr %l49, !tbaa !27
  br label %bb24
bb23:
  %t108 = mul i64 0, 16
  %t109 = call ptr @__olang_scope_alloc_zeroed(ptr %s3, i64 %t108)
  %t110 = insertvalue { i64, ptr } undef, i64 0, 0
  %t111 = insertvalue { i64, ptr } %t110, ptr %t109, 1
  store { i64, ptr } %t111, ptr %l49, !tbaa !27
  br label %bb24
bb24:
  %t113 = load ptr, ptr %l45, !tbaa !29
  %t114 = load { i64, ptr }, ptr %l49, !tbaa !27
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eprologue(ptr %v0, ptr %s3, ptr %t113, { i64, ptr } %t114)
  br label %bb25
bb25:
  %t115 = load ptr, ptr %l0, !tbaa !29
  store ptr %t115, ptr %l53, !tbaa !29
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t117 = load i32, ptr %l2, !tbaa !23
  %t118 = load %"compiler/source:Span", ptr %l4
  %t122 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ezeroOf(ptr %v0, ptr %t116, i32 %t117, %"compiler/source:Span" %t118)
  store { i64, [4 x i64] } %t122, ptr %l57
  br label %bb26
bb26:
  %t123 = load ptr, ptr %l53, !tbaa !29
  %t124 = load { i64, [4 x i64] }, ptr %l57
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eepilogue(ptr %v0, ptr %t123, { i64, [4 x i64] } %t124)
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s3)
  br label %bb38
bb28:
  %t125 = load i32, ptr %l1
  %t127 = trunc i64 0 to i32
  %t128 = icmp eq i32 %t125, %t127
  br i1 %t128, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb37
bb31:
  store %olang.scope zeroinitializer, ptr %s4
  %t130 = load ptr, ptr %l0, !tbaa !29
  store { i64, [1 x i64] } zeroinitializer, ptr %t131
  %t132 = getelementptr { i64, [1 x i64] }, ptr %t131, i32 0, i32 0
  store i64 5, ptr %t132
  %t133 = load { i64, [1 x i64] }, ptr %t131
  %t134 = mul i64 1, 16
  %t135 = call ptr @__olang_scope_alloc_zeroed(ptr %s4, i64 %t134)
  %t136 = insertvalue { i64, ptr } undef, i64 1, 0
  %t137 = insertvalue { i64, ptr } %t136, ptr %t135, 1
  store { i64, ptr } %t137, ptr %l62, !tbaa !27
  %t139 = getelementptr { i64, ptr }, ptr %l62, i32 0, i32 1
  %t140 = load ptr, ptr %t139, !tbaa !27
  %t141 = getelementptr { i64, [1 x i64] }, ptr %t140, i64 0
  store { i64, [1 x i64] } %t133, ptr %t141
  %t143 = load { i64, ptr }, ptr %l62, !tbaa !27
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eprologue(ptr %v0, ptr %s4, ptr %t130, { i64, ptr } %t143)
  br label %bb32
bb32:
  %t144 = load ptr, ptr %l0, !tbaa !29
  store ptr %t144, ptr %l63, !tbaa !29
  %t145 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 1)
  store %"compiler/mir:Place" %t145, ptr %l64
  br label %bb33
bb33:
  store { i64, [4 x i64] } zeroinitializer, ptr %t146
  %t147 = getelementptr { i64, [4 x i64] }, ptr %t146, i32 0, i32 0
  store i64 1, ptr %t147
  %t148 = load %"compiler/mir:Place", ptr %l64
  %t149 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t148, 0
  %t150 = getelementptr { i64, [4 x i64] }, ptr %t146, i32 0, i32 1
  store { %"compiler/mir:Place" } %t149, ptr %t150
  %t151 = load { i64, [4 x i64] }, ptr %t146
  %t153 = load ptr, ptr %l63, !tbaa !29
  %t154 = getelementptr %"compiler/lower:lowering", ptr %t153, i32 0, i32 5
  store { i64, [4 x i64] } %t151, ptr %t154
  %t155 = load ptr, ptr %l0, !tbaa !29
  store ptr %t155, ptr %l66, !tbaa !29
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t158 = call %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2eat(ptr %v0, ptr %s4, ptr %t156, i32 0)
  store %"compiler/lower:pl" %t158, ptr %l68
  br label %bb34
bb34:
  %t159 = load i32, ptr %l2, !tbaa !23
  store { i64, [1 x i64] } zeroinitializer, ptr %t160
  %t161 = getelementptr { i64, [1 x i64] }, ptr %t160, i32 0, i32 0
  store i64 1, ptr %t161
  %t162 = insertvalue { i64 } undef, i64 0, 0
  %t163 = getelementptr { i64, [1 x i64] }, ptr %t160, i32 0, i32 1
  store { i64 } %t162, ptr %t163
  %t164 = load { i64, [1 x i64] }, ptr %t160
  %t165 = load %"compiler/source:Span", ptr %l4
  %t166 = load ptr, ptr %l66, !tbaa !29
  %t167 = load %"compiler/lower:pl", ptr %l68
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2erenderAt(ptr %v0, ptr %s4, ptr %t166, %"compiler/lower:pl" %t167, i32 %t159, { i64, [1 x i64] } %t164, %"compiler/source:Span" %t165, i1 true)
  br label %bb35
bb35:
  %t171 = load ptr, ptr %l0, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t172
  %t173 = getelementptr { i64, [4 x i64] }, ptr %t172, i32 0, i32 0
  store i64 0, ptr %t173
  %t174 = load { i64, [4 x i64] }, ptr %t172
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eepilogue(ptr %v0, ptr %t171, { i64, [4 x i64] } %t174)
  br label %bb36
bb36:
  call void @__olang_scope_close(ptr %s4)
  br label %bb38
bb37:
  call void @__olang_check_failed(ptr @olang_loc_30767a805df234bd_503f920f410b6239)
  unreachable
bb38:
  br label %ret
ret:
  ret void
}

define dso_local { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ehelperCall(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, i32 %a2, { i64, ptr } %a3, { i64, ptr } %a4, i32 %a5, %"compiler/source:Span" %a6) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l5 = alloca i32
  %l6 = alloca %"compiler/source:Span"
  %l7 = alloca i32
  %l8 = alloca { i64, [2 x i64] }
  %l9 = alloca i32
  %l10 = alloca i32
  %l16 = alloca i32
  %l21 = alloca i32
  %l30 = alloca i32
  %l38 = alloca i32
  %l40 = alloca ptr
  %l43 = alloca { i64, [7 x i64] }
  %l47 = alloca %"compiler/mir:Range"
  %l51 = alloca %"compiler/mir:Range"
  %l55 = alloca %"compiler/mir:Place"
  %l57 = alloca %"compiler/mir:Place"
  %l65 = alloca %"compiler/mir:Call"
  %l66 = alloca i32
  %l76 = alloca { i64, [4 x i64] }
  %l79 = alloca %"compiler/mir:Place"
  %s0 = alloca %olang.scope
  %rv = alloca { i64, [4 x i64] }
  %t25 = alloca { i64, [2 x i64] }, align 8
  %t68 = alloca { i64, [7 x i64] }, align 8
  %t126 = alloca { i64, [7 x i64] }, align 8
  %t146 = alloca { i64, [4 x i64] }, align 8
  %t153 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  store i32 %a5, ptr %l5
  store %"compiler/source:Span" %a6, ptr %l6
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i32, ptr %l1
  %t6 = load i32, ptr %l2, !tbaa !23
  %t10 = call i32 @compiler_2flower_2ecompiler_2flower_3aLowerer_2ehelperTy(ptr %v0, ptr %t4, i32 %t5, i32 %t6)
  store i32 %t10, ptr %l16
  br label %bb1
bb1:
  %t11 = load i32, ptr %l16, !tbaa !23
  store i32 %t11, ptr %l2, !tbaa !23
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/lower:lowering", ptr %t12, i32 0, i32 2
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t16 = load i32, ptr %l1
  %t17 = load i32, ptr %l2, !tbaa !23
  %t21 = call i32 @compiler_2fmir_2eHelperType(ptr %v0, ptr %t15, i32 %t16, i32 %t17)
  store i32 %t21, ptr %l21
  br label %bb2
bb2:
  %t22 = load i32, ptr %l21, !tbaa !23
  store i32 %t22, ptr %l7, !tbaa !23
  %t23 = load i32, ptr %l1
  %t24 = load i32, ptr %l2, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t25
  %t26 = getelementptr { i64, [2 x i64] }, ptr %t25, i32 0, i32 0
  store i64 2, ptr %t26
  %t28 = insertvalue { i32, i32 } undef, i32 %t23, 0
  %t30 = insertvalue { i32, i32 } %t28, i32 %t24, 1
  %t31 = getelementptr { i64, [2 x i64] }, ptr %t25, i32 0, i32 1
  store { i32, i32 } %t30, ptr %t31
  %t32 = load { i64, [2 x i64] }, ptr %t25
  store { i64, [2 x i64] } %t32, ptr %l8
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/lower:lowering", ptr %t34, i32 0, i32 0
  %t37 = load ptr, ptr %t36, !tbaa !29
  %t38 = load { i64, [2 x i64] }, ptr %l8
  call void @compiler_2flower_2ecompiler_2flower_3aLowerer_2eWant(ptr %v0, ptr %t37, { i64, [2 x i64] } %t38)
  br label %bb3
bb3:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/lower:lowering", ptr %t41, i32 0, i32 3
  %t45 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t43)
  store i32 %t45, ptr %l30
  br label %bb4
bb4:
  %t46 = load i32, ptr %l30, !tbaa !23
  store i32 %t46, ptr %l9, !tbaa !23
  %t47 = load i32, ptr @G_2ecompiler_2fmir_2eNoLocal, !tbaa !23
  store i32 %t47, ptr %l10, !tbaa !23
  %t49 = load i32, ptr %l5, !tbaa !23
  %t50 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t53 = icmp ne i32 %t49, %t50
  br i1 %t53, label %bb5, label %bb6
bb5:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t56 = load i32, ptr %l5, !tbaa !23
  %t57 = load %"compiler/source:Span", ptr %l6
  %t61 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2etemp(ptr %v0, ptr %t55, i32 %t56, %"compiler/source:Span" %t57)
  store i32 %t61, ptr %l38
  br label %bb7
bb6:
  br label %bb8
bb7:
  %t62 = load i32, ptr %l38, !tbaa !23
  store i32 %t62, ptr %l10, !tbaa !23
  br label %bb8
bb8:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/lower:lowering", ptr %t63, i32 0, i32 3
  store ptr %t65, ptr %l40, !tbaa !29
  %t66 = load { i64, [2 x i64] }, ptr %l8
  %t67 = load i32, ptr %l7, !tbaa !23
  store { i64, [7 x i64] } zeroinitializer, ptr %t68
  %t69 = getelementptr { i64, [7 x i64] }, ptr %t68, i32 0, i32 0
  store i64 0, ptr %t69
  %t71 = insertvalue { { i64, [2 x i64] }, i32 } undef, { i64, [2 x i64] } %t66, 0
  %t73 = insertvalue { { i64, [2 x i64] }, i32 } %t71, i32 %t67, 1
  %t74 = getelementptr { i64, [7 x i64] }, ptr %t68, i32 0, i32 1
  store { { i64, [2 x i64] }, i32 } %t73, ptr %t74
  %t75 = load { i64, [7 x i64] }, ptr %t68
  store { i64, [7 x i64] } %t75, ptr %l43
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"compiler/lower:lowering", ptr %t76, i32 0, i32 3
  %t82 = call %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eArgs(ptr %v0, ptr %v1, ptr %t78, { i64, ptr } %a3)
  store %"compiler/mir:Range" %t82, ptr %l47
  br label %bb9
bb9:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr %"compiler/lower:lowering", ptr %t83, i32 0, i32 3
  %t89 = call %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eScopeRefs(ptr %v0, ptr %v2, ptr %t85, { i64, ptr } %a4)
  store %"compiler/mir:Range" %t89, ptr %l51
  br label %bb10
bb10:
  %t90 = load i32, ptr %l10, !tbaa !23
  %t91 = load i32, ptr @G_2ecompiler_2fmir_2eNoLocal, !tbaa !23
  %t94 = icmp ne i32 %t90, %t91
  br i1 %t94, label %bb11, label %bb12
bb11:
  %t96 = load i32, ptr %l10, !tbaa !23
  %t98 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t96)
  store %"compiler/mir:Place" %t98, ptr %l57
  br label %bb13
bb12:
  %t99 = load %"compiler/mir:Place", ptr @G_2ecompiler_2fmir_2eNoPlace
  store %"compiler/mir:Place" %t99, ptr %l55
  br label %bb14
bb13:
  %t101 = load %"compiler/mir:Place", ptr %l57
  store %"compiler/mir:Place" %t101, ptr %l55
  br label %bb14
bb14:
  %t102 = load i32, ptr %l10, !tbaa !23
  %t103 = load i32, ptr @G_2ecompiler_2fmir_2eNoLocal, !tbaa !23
  %t106 = icmp ne i32 %t102, %t103
  %t107 = load i32, ptr %l9, !tbaa !23
  %t108 = load i32, ptr @G_2ecompiler_2fmir_2eNoLocal, !tbaa !23
  %t109 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t110 = load { i64, [7 x i64] }, ptr %l43
  %t111 = load %"compiler/mir:Range", ptr %l47
  %t112 = load %"compiler/mir:Range", ptr %l51
  %t113 = load %"compiler/mir:Place", ptr %l55
  %t118 = call %"compiler/mir:Call" @compiler_2fmir_3aCall_2ector(ptr %s0, { i64, [7 x i64] } %t110, %"compiler/mir:Range" %t111, %"compiler/mir:Range" %t112, %"compiler/mir:Place" %t113, i1 %t106, i32 %t107, i32 %t108, i32 %t109)
  store %"compiler/mir:Call" %t118, ptr %l65
  br label %bb15
bb15:
  %t119 = load ptr, ptr %l40, !tbaa !29
  %t120 = load %"compiler/mir:Call", ptr %l65
  %t121 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddCall(ptr %v0, ptr %t119, %"compiler/mir:Call" %t120)
  store i32 %t121, ptr %l66
  br label %bb16
bb16:
  %t122 = load i32, ptr %l66, !tbaa !23
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t124 = load %"compiler/source:Span", ptr %l6
  store { i64, [7 x i64] } zeroinitializer, ptr %t126
  %t127 = getelementptr { i64, [7 x i64] }, ptr %t126, i32 0, i32 0
  store i64 4, ptr %t127
  %t129 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t124, 0
  %t131 = insertvalue { %"compiler/source:Span", i32 } %t129, i32 %t122, 1
  %t132 = getelementptr { i64, [7 x i64] }, ptr %t126, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t131, ptr %t132
  %t133 = load { i64, [7 x i64] }, ptr %t126
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t123, { i64, [7 x i64] } %t133)
  br label %bb17
bb17:
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t137 = load i32, ptr %l9, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t136, i32 %t137)
  br label %bb18
bb18:
  %t140 = load i32, ptr %l10, !tbaa !23
  %t141 = load i32, ptr @G_2ecompiler_2fmir_2eNoLocal, !tbaa !23
  %t144 = icmp eq i32 %t140, %t141
  br i1 %t144, label %bb19, label %bb20
bb19:
  store { i64, [4 x i64] } zeroinitializer, ptr %t146
  %t147 = getelementptr { i64, [4 x i64] }, ptr %t146, i32 0, i32 0
  store i64 0, ptr %t147
  %t148 = load { i64, [4 x i64] }, ptr %t146
  store { i64, [4 x i64] } %t148, ptr %l76
  br label %bb22
bb20:
  %t150 = load i32, ptr %l10, !tbaa !23
  %t152 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t150)
  store %"compiler/mir:Place" %t152, ptr %l79
  br label %bb21
bb21:
  store { i64, [4 x i64] } zeroinitializer, ptr %t153
  %t154 = getelementptr { i64, [4 x i64] }, ptr %t153, i32 0, i32 0
  store i64 1, ptr %t154
  %t155 = load %"compiler/mir:Place", ptr %l79
  %t156 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t155, 0
  %t157 = getelementptr { i64, [4 x i64] }, ptr %t153, i32 0, i32 1
  store { %"compiler/mir:Place" } %t156, ptr %t157
  %t158 = load { i64, [4 x i64] }, ptr %t153
  store { i64, [4 x i64] } %t158, ptr %l76
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s0)
  %t160 = load { i64, [4 x i64] }, ptr %l76
  store { i64, [4 x i64] } %t160, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local { { i64, [7 x i64] }, i32 } @compiler_2flower_2ecompiler_2flower_3alowering_2ehelperCallee(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca i32
  %l7 = alloca i32
  %l14 = alloca i32
  %l19 = alloca i32
  %rv = alloca { { i64, [7 x i64] }, i32 }
  %t37 = alloca { i64, [2 x i64] }, align 8
  %t49 = alloca { i64, [2 x i64] }, align 8
  %t58 = alloca { i64, [7 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t3 = trunc i64 0 to i32
  %t4 = icmp eq i32 %a1, %t3
  br i1 %t4, label %bb1, label %bb2
bb1:
  store i32 1, ptr %l7
  br label %bb3
bb2:
  store i32 2, ptr %l7
  br label %bb3
bb3:
  %t8 = load i32, ptr %l7
  store i32 %t8, ptr %l3
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/lower:lowering", ptr %t9, i32 0, i32 0
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t13 = load i32, ptr %l3
  %t14 = load i32, ptr %l2, !tbaa !23
  %t18 = call i32 @compiler_2flower_2ecompiler_2flower_3aLowerer_2ehelperTy(ptr %v0, ptr %t12, i32 %t13, i32 %t14)
  store i32 %t18, ptr %l14
  br label %bb4
bb4:
  %t19 = load i32, ptr %l14, !tbaa !23
  store i32 %t19, ptr %l2, !tbaa !23
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/lower:lowering", ptr %t20, i32 0, i32 2
  %t23 = load ptr, ptr %t22, !tbaa !29
  %t24 = load i32, ptr %l3
  %t25 = load i32, ptr %l2, !tbaa !23
  %t29 = call i32 @compiler_2fmir_2eHelperType(ptr %v0, ptr %t23, i32 %t24, i32 %t25)
  store i32 %t29, ptr %l19
  br label %bb5
bb5:
  %t30 = load i32, ptr %l19, !tbaa !23
  store i32 %t30, ptr %l4, !tbaa !23
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/lower:lowering", ptr %t31, i32 0, i32 0
  %t34 = load ptr, ptr %t33, !tbaa !29
  %t35 = load i32, ptr %l3
  %t36 = load i32, ptr %l2, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t37
  %t38 = getelementptr { i64, [2 x i64] }, ptr %t37, i32 0, i32 0
  store i64 2, ptr %t38
  %t40 = insertvalue { i32, i32 } undef, i32 %t35, 0
  %t42 = insertvalue { i32, i32 } %t40, i32 %t36, 1
  %t43 = getelementptr { i64, [2 x i64] }, ptr %t37, i32 0, i32 1
  store { i32, i32 } %t42, ptr %t43
  %t44 = load { i64, [2 x i64] }, ptr %t37
  call void @compiler_2flower_2ecompiler_2flower_3aLowerer_2eWant(ptr %v0, ptr %t34, { i64, [2 x i64] } %t44)
  br label %bb6
bb6:
  %t47 = load i32, ptr %l3
  %t48 = load i32, ptr %l2, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t49
  %t50 = getelementptr { i64, [2 x i64] }, ptr %t49, i32 0, i32 0
  store i64 2, ptr %t50
  %t52 = insertvalue { i32, i32 } undef, i32 %t47, 0
  %t54 = insertvalue { i32, i32 } %t52, i32 %t48, 1
  %t55 = getelementptr { i64, [2 x i64] }, ptr %t49, i32 0, i32 1
  store { i32, i32 } %t54, ptr %t55
  %t56 = load { i64, [2 x i64] }, ptr %t49
  %t57 = load i32, ptr %l4, !tbaa !23
  store { i64, [7 x i64] } zeroinitializer, ptr %t58
  %t59 = getelementptr { i64, [7 x i64] }, ptr %t58, i32 0, i32 0
  store i64 0, ptr %t59
  %t61 = insertvalue { { i64, [2 x i64] }, i32 } undef, { i64, [2 x i64] } %t56, 0
  %t63 = insertvalue { { i64, [2 x i64] }, i32 } %t61, i32 %t57, 1
  %t64 = getelementptr { i64, [7 x i64] }, ptr %t58, i32 0, i32 1
  store { { i64, [2 x i64] }, i32 } %t63, ptr %t64
  %t65 = load { i64, [7 x i64] }, ptr %t58
  %t66 = load i32, ptr %l4, !tbaa !23
  %t68 = insertvalue { { i64, [7 x i64] }, i32 } undef, { i64, [7 x i64] } %t65, 0
  %t70 = insertvalue { { i64, [7 x i64] }, i32 } %t68, i32 %t66, 1
  store { { i64, [7 x i64] }, i32 } %t70, ptr %rv
  br label %ret
ret:
  %rr = load { { i64, [7 x i64] }, i32 }, ptr %rv
  ret { { i64, [7 x i64] }, i32 } %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2einner(ptr %v0, ptr %v1, ptr %a0, %"compiler/lower:pl" %a1, i32 %a2, { i64, [1 x i64] } %a3, %"compiler/source:Span" %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/lower:pl"
  %l2 = alloca i32
  %l3 = alloca { i64, [1 x i64] }
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca i32
  %l12 = alloca i32
  %l15 = alloca i1
  %l16 = alloca ptr
  %l17 = alloca %"compiler/source:Span"
  %l18 = alloca { i64, [1 x i64] }
  %l19 = alloca i32
  %l20 = alloca ptr
  %l21 = alloca i32
  %l24 = alloca %"compiler/mir:Place"
  %l28 = alloca { i64, [4 x i64] }
  %l33 = alloca i1
  %l34 = alloca i1
  %l37 = alloca i1
  %l39 = alloca ptr
  %l40 = alloca %"compiler/source:Span"
  %l41 = alloca { i64, [1 x i64] }
  %l42 = alloca i32
  %l43 = alloca ptr
  %l44 = alloca i32
  %l47 = alloca %"compiler/mir:Place"
  %l51 = alloca { i64, [4 x i64] }
  %l56 = alloca i1
  %l60 = alloca i1
  %l64 = alloca i1
  %l68 = alloca i1
  %l70 = alloca ptr
  %l71 = alloca %"compiler/source:Span"
  %l72 = alloca { i64, [1 x i64] }
  %l73 = alloca i32
  %l74 = alloca ptr
  %l75 = alloca i32
  %l78 = alloca %"compiler/mir:Place"
  %l82 = alloca { i64, [4 x i64] }
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %t28 = alloca { i64, [4 x i64] }, align 8
  %t34 = alloca { i64, [15 x i64] }, align 8
  %t46 = alloca { i64, [21 x i64] }, align 8
  %t87 = alloca { i64, [4 x i64] }, align 8
  %t93 = alloca { i64, [15 x i64] }, align 8
  %t105 = alloca { i64, [21 x i64] }, align 8
  %t160 = alloca { i64, [4 x i64] }, align 8
  %t166 = alloca { i64, [15 x i64] }, align 8
  %t178 = alloca { i64, [21 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/lower:pl" %a1, ptr %l1
  store i32 %a2, ptr %l2
  store { i64, [1 x i64] } %a3, ptr %l3
  store %"compiler/source:Span" %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l5, !tbaa !29
  %t6 = load ptr, ptr %l5, !tbaa !29
  %t7 = load i32, ptr %l2, !tbaa !23
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t6, i32 %t7)
  store i32 %t10, ptr %l12
  br label %bb1
bb1:
  %t11 = load i32, ptr %l12, !tbaa !23
  store i32 %t11, ptr %l6, !tbaa !23
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load i32, ptr %l2, !tbaa !23
  %t16 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eisChar(ptr %v0, ptr %t12, i32 %t13)
  store i1 %t16, ptr %l15
  br label %bb2
bb2:
  %t17 = load i1, ptr %l15, !tbaa !21
  br i1 %t17, label %bb3, label %bb4
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t18 = load ptr, ptr %l0, !tbaa !29
  store ptr %t18, ptr %l16, !tbaa !29
  %t19 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t19, ptr %l17
  %t20 = load { i64, [1 x i64] }, ptr %l3
  store { i64, [1 x i64] } %t20, ptr %l18
  store i32 3, ptr %l19
  %t21 = load ptr, ptr %l0, !tbaa !29
  store ptr %t21, ptr %l20, !tbaa !29
  %t22 = load i32, ptr %l2, !tbaa !23
  store i32 %t22, ptr %l21, !tbaa !23
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load %"compiler/lower:pl", ptr %l1
  %t27 = call %"compiler/mir:Place" @compiler_2flower_2ecompiler_2flower_3alowering_2emk(ptr %v0, ptr %v1, ptr %t23, %"compiler/lower:pl" %t24)
  store %"compiler/mir:Place" %t27, ptr %l24
  br label %bb5
bb4:
  br label %bb8
bb5:
  store { i64, [4 x i64] } zeroinitializer, ptr %t28
  %t29 = getelementptr { i64, [4 x i64] }, ptr %t28, i32 0, i32 0
  store i64 1, ptr %t29
  %t30 = load %"compiler/mir:Place", ptr %l24
  %t31 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t30, 0
  %t32 = getelementptr { i64, [4 x i64] }, ptr %t28, i32 0, i32 1
  store { %"compiler/mir:Place" } %t31, ptr %t32
  %t33 = load { i64, [4 x i64] }, ptr %t28
  store { i64, [15 x i64] } zeroinitializer, ptr %t34
  %t35 = getelementptr { i64, [15 x i64] }, ptr %t34, i32 0, i32 0
  store i64 0, ptr %t35
  %t37 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t33, 0
  %t38 = getelementptr { i64, [15 x i64] }, ptr %t34, i32 0, i32 1
  store { { i64, [4 x i64] } } %t37, ptr %t38
  %t39 = load { i64, [15 x i64] }, ptr %t34
  %t40 = load %"compiler/source:Span", ptr %l4
  %t41 = load ptr, ptr %l20, !tbaa !29
  %t42 = load i32, ptr %l21, !tbaa !23
  %t45 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %t41, i32 %t42, { i64, [15 x i64] } %t39, %"compiler/source:Span" %t40)
  store { i64, [4 x i64] } %t45, ptr %l28
  br label %bb6
bb6:
  store { i64, [21 x i64] } zeroinitializer, ptr %t46
  %t47 = getelementptr { i64, [21 x i64] }, ptr %t46, i32 0, i32 0
  store i64 9, ptr %t47
  %t48 = load %"compiler/source:Span", ptr %l17
  %t49 = insertvalue { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } undef, %"compiler/source:Span" %t48, 0
  %t50 = load { i64, [1 x i64] }, ptr %l18
  %t51 = insertvalue { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } %t49, { i64, [1 x i64] } %t50, 1
  %t52 = load i32, ptr %l19
  %t53 = insertvalue { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } %t51, i32 %t52, 2
  %t54 = load { i64, [4 x i64] }, ptr %l28
  %t55 = insertvalue { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } %t53, { i64, [4 x i64] } %t54, 3
  %t56 = getelementptr { i64, [21 x i64] }, ptr %t46, i32 0, i32 1
  store { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } %t55, ptr %t56
  %t57 = load { i64, [21 x i64] }, ptr %t46
  %t59 = call ptr @__olang_scope_alloc_a(ptr %s1, i64 176, i64 8)
  store { i64, [21 x i64] } %t57, ptr %t59
  %t60 = load ptr, ptr %l16, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s1, ptr %t60, ptr %t59)
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s1)
  br label %ret
bb8:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t63 = load i32, ptr %l2, !tbaa !23
  %t66 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eisText(ptr %v0, ptr %t62, i32 %t63)
  store i1 %t66, ptr %l33
  br label %bb9
bb9:
  %t67 = load i1, ptr %l33, !tbaa !21
  br i1 %t67, label %bb10, label %bb11
bb10:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t69 = load i32, ptr %l2, !tbaa !23
  %t72 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2ehasStr(ptr %v0, ptr %t68, i32 %t69)
  store i1 %t72, ptr %l37
  br label %bb12
bb11:
  store i1 false, ptr %l34, !tbaa !21
  br label %bb13
bb12:
  %t73 = load i1, ptr %l37, !tbaa !21
  %t74 = xor i1 %t73, true
  store i1 %t74, ptr %l34, !tbaa !21
  br label %bb13
bb13:
  %t76 = load i1, ptr %l34, !tbaa !21
  br i1 %t76, label %bb14, label %bb15
bb14:
  store %olang.scope zeroinitializer, ptr %s2
  %t77 = load ptr, ptr %l0, !tbaa !29
  store ptr %t77, ptr %l39, !tbaa !29
  %t78 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t78, ptr %l40
  %t79 = load { i64, [1 x i64] }, ptr %l3
  store { i64, [1 x i64] } %t79, ptr %l41
  store i32 1, ptr %l42
  %t80 = load ptr, ptr %l0, !tbaa !29
  store ptr %t80, ptr %l43, !tbaa !29
  %t81 = load i32, ptr %l2, !tbaa !23
  store i32 %t81, ptr %l44, !tbaa !23
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t83 = load %"compiler/lower:pl", ptr %l1
  %t86 = call %"compiler/mir:Place" @compiler_2flower_2ecompiler_2flower_3alowering_2emk(ptr %v0, ptr %v1, ptr %t82, %"compiler/lower:pl" %t83)
  store %"compiler/mir:Place" %t86, ptr %l47
  br label %bb16
bb15:
  br label %bb19
bb16:
  store { i64, [4 x i64] } zeroinitializer, ptr %t87
  %t88 = getelementptr { i64, [4 x i64] }, ptr %t87, i32 0, i32 0
  store i64 1, ptr %t88
  %t89 = load %"compiler/mir:Place", ptr %l47
  %t90 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t89, 0
  %t91 = getelementptr { i64, [4 x i64] }, ptr %t87, i32 0, i32 1
  store { %"compiler/mir:Place" } %t90, ptr %t91
  %t92 = load { i64, [4 x i64] }, ptr %t87
  store { i64, [15 x i64] } zeroinitializer, ptr %t93
  %t94 = getelementptr { i64, [15 x i64] }, ptr %t93, i32 0, i32 0
  store i64 0, ptr %t94
  %t96 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t92, 0
  %t97 = getelementptr { i64, [15 x i64] }, ptr %t93, i32 0, i32 1
  store { { i64, [4 x i64] } } %t96, ptr %t97
  %t98 = load { i64, [15 x i64] }, ptr %t93
  %t99 = load %"compiler/source:Span", ptr %l4
  %t100 = load ptr, ptr %l43, !tbaa !29
  %t101 = load i32, ptr %l44, !tbaa !23
  %t104 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %t100, i32 %t101, { i64, [15 x i64] } %t98, %"compiler/source:Span" %t99)
  store { i64, [4 x i64] } %t104, ptr %l51
  br label %bb17
bb17:
  store { i64, [21 x i64] } zeroinitializer, ptr %t105
  %t106 = getelementptr { i64, [21 x i64] }, ptr %t105, i32 0, i32 0
  store i64 9, ptr %t106
  %t107 = load %"compiler/source:Span", ptr %l40
  %t108 = insertvalue { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } undef, %"compiler/source:Span" %t107, 0
  %t109 = load { i64, [1 x i64] }, ptr %l41
  %t110 = insertvalue { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } %t108, { i64, [1 x i64] } %t109, 1
  %t111 = load i32, ptr %l42
  %t112 = insertvalue { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } %t110, i32 %t111, 2
  %t113 = load { i64, [4 x i64] }, ptr %l51
  %t114 = insertvalue { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } %t112, { i64, [4 x i64] } %t113, 3
  %t115 = getelementptr { i64, [21 x i64] }, ptr %t105, i32 0, i32 1
  store { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } %t114, ptr %t115
  %t116 = load { i64, [21 x i64] }, ptr %t105
  %t118 = call ptr @__olang_scope_alloc_a(ptr %s2, i64 176, i64 8)
  store { i64, [21 x i64] } %t116, ptr %t118
  %t119 = load ptr, ptr %l39, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s2, ptr %t119, ptr %t118)
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s2)
  br label %ret
bb19:
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t122 = load i32, ptr %l2, !tbaa !23
  %t125 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2escalar(ptr %v0, ptr %t121, i32 %t122)
  store i1 %t125, ptr %l56
  br label %bb20
bb20:
  %t126 = load i1, ptr %l56, !tbaa !21
  br i1 %t126, label %bb21, label %bb22
bb21:
  store %olang.scope zeroinitializer, ptr %s3
  store i32 7, ptr %l7
  %t128 = load ptr, ptr %l5, !tbaa !29
  %t129 = load i32, ptr %l6, !tbaa !23
  %t132 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %t128, i32 %t129)
  store i1 %t132, ptr %l60
  br label %bb23
bb22:
  br label %bb38
bb23:
  %t133 = load i1, ptr %l60, !tbaa !21
  br i1 %t133, label %bb24, label %bb25
bb24:
  store i32 5, ptr %l7
  br label %bb34
bb25:
  %t135 = load ptr, ptr %l5, !tbaa !29
  %t136 = load i32, ptr %l6, !tbaa !23
  %t139 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %t135, i32 %t136)
  store i1 %t139, ptr %l64
  br label %bb26
bb26:
  %t140 = load i1, ptr %l64, !tbaa !21
  br i1 %t140, label %bb27, label %bb28
bb27:
  store i32 4, ptr %l7
  br label %bb33
bb28:
  %t142 = load ptr, ptr %l5, !tbaa !29
  %t143 = load i32, ptr %l6, !tbaa !23
  %t146 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %t142, i32 %t143)
  store i1 %t146, ptr %l68
  br label %bb29
bb29:
  %t147 = load i1, ptr %l68, !tbaa !21
  br i1 %t147, label %bb30, label %bb31
bb30:
  store i32 6, ptr %l7
  br label %bb32
bb31:
  br label %bb32
bb32:
  br label %bb33
bb33:
  br label %bb34
bb34:
  %t149 = load ptr, ptr %l0, !tbaa !29
  store ptr %t149, ptr %l70, !tbaa !29
  %t150 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t150, ptr %l71
  %t151 = load { i64, [1 x i64] }, ptr %l3
  store { i64, [1 x i64] } %t151, ptr %l72
  %t152 = load i32, ptr %l7
  store i32 %t152, ptr %l73
  %t153 = load ptr, ptr %l0, !tbaa !29
  store ptr %t153, ptr %l74, !tbaa !29
  %t154 = load i32, ptr %l2, !tbaa !23
  store i32 %t154, ptr %l75, !tbaa !23
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t156 = load %"compiler/lower:pl", ptr %l1
  %t159 = call %"compiler/mir:Place" @compiler_2flower_2ecompiler_2flower_3alowering_2emk(ptr %v0, ptr %v1, ptr %t155, %"compiler/lower:pl" %t156)
  store %"compiler/mir:Place" %t159, ptr %l78
  br label %bb35
bb35:
  store { i64, [4 x i64] } zeroinitializer, ptr %t160
  %t161 = getelementptr { i64, [4 x i64] }, ptr %t160, i32 0, i32 0
  store i64 1, ptr %t161
  %t162 = load %"compiler/mir:Place", ptr %l78
  %t163 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t162, 0
  %t164 = getelementptr { i64, [4 x i64] }, ptr %t160, i32 0, i32 1
  store { %"compiler/mir:Place" } %t163, ptr %t164
  %t165 = load { i64, [4 x i64] }, ptr %t160
  store { i64, [15 x i64] } zeroinitializer, ptr %t166
  %t167 = getelementptr { i64, [15 x i64] }, ptr %t166, i32 0, i32 0
  store i64 0, ptr %t167
  %t169 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t165, 0
  %t170 = getelementptr { i64, [15 x i64] }, ptr %t166, i32 0, i32 1
  store { { i64, [4 x i64] } } %t169, ptr %t170
  %t171 = load { i64, [15 x i64] }, ptr %t166
  %t172 = load %"compiler/source:Span", ptr %l4
  %t173 = load ptr, ptr %l74, !tbaa !29
  %t174 = load i32, ptr %l75, !tbaa !23
  %t177 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %t173, i32 %t174, { i64, [15 x i64] } %t171, %"compiler/source:Span" %t172)
  store { i64, [4 x i64] } %t177, ptr %l82
  br label %bb36
bb36:
  store { i64, [21 x i64] } zeroinitializer, ptr %t178
  %t179 = getelementptr { i64, [21 x i64] }, ptr %t178, i32 0, i32 0
  store i64 9, ptr %t179
  %t180 = load %"compiler/source:Span", ptr %l71
  %t181 = insertvalue { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } undef, %"compiler/source:Span" %t180, 0
  %t182 = load { i64, [1 x i64] }, ptr %l72
  %t183 = insertvalue { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } %t181, { i64, [1 x i64] } %t182, 1
  %t184 = load i32, ptr %l73
  %t185 = insertvalue { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } %t183, i32 %t184, 2
  %t186 = load { i64, [4 x i64] }, ptr %l82
  %t187 = insertvalue { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } %t185, { i64, [4 x i64] } %t186, 3
  %t188 = getelementptr { i64, [21 x i64] }, ptr %t178, i32 0, i32 1
  store { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } %t187, ptr %t188
  %t189 = load { i64, [21 x i64] }, ptr %t178
  %t191 = call ptr @__olang_scope_alloc_a(ptr %s3, i64 176, i64 8)
  store { i64, [21 x i64] } %t189, ptr %t191
  %t192 = load ptr, ptr %l70, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s3, ptr %t192, ptr %t191)
  br label %bb37
bb37:
  call void @__olang_scope_close(ptr %s3)
  br label %ret
bb38:
  %t194 = load ptr, ptr %l0, !tbaa !29
  %t195 = load %"compiler/lower:pl", ptr %l1
  %t196 = load i32, ptr %l2, !tbaa !23
  %t197 = load { i64, [1 x i64] }, ptr %l3
  %t198 = load %"compiler/source:Span", ptr %l4
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2erenderAt(ptr %v0, ptr %v1, ptr %t194, %"compiler/lower:pl" %t195, i32 %t196, { i64, [1 x i64] } %t197, %"compiler/source:Span" %t198, i1 false)
  br label %bb39
bb39:
  br label %ret
ret:
  ret void
}

define dso_local { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %a0, i32 %a1, { i64, [15 x i64] } %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca i32
  %l8 = alloca i32
  %l9 = alloca ptr
  %l10 = alloca %"compiler/source:Span"
  %l12 = alloca %"compiler/mir:Place"
  %l17 = alloca %"compiler/mir:Place"
  %s0 = alloca %olang.scope
  %rv = alloca { i64, [4 x i64] }
  %t15 = alloca { i64, [21 x i64] }, align 8
  %t32 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = load %"compiler/source:Span", ptr %l3
  %t7 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2etemp(ptr %v0, ptr %t1, i32 %a1, %"compiler/source:Span" %t3)
  store i32 %t7, ptr %l8
  br label %bb1
bb1:
  %t8 = load i32, ptr %l8, !tbaa !23
  store i32 %t8, ptr %l4, !tbaa !23
  %t9 = load ptr, ptr %l0, !tbaa !29
  store ptr %t9, ptr %l9, !tbaa !29
  %t10 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t10, ptr %l10
  %t11 = load i32, ptr %l4, !tbaa !23
  %t13 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t11)
  store %"compiler/mir:Place" %t13, ptr %l12
  br label %bb2
bb2:
  store { i64, [21 x i64] } zeroinitializer, ptr %t15
  %t16 = getelementptr { i64, [21 x i64] }, ptr %t15, i32 0, i32 0
  store i64 0, ptr %t16
  %t17 = load %"compiler/source:Span", ptr %l10
  %t18 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t17, 0
  %t19 = load %"compiler/mir:Place", ptr %l12
  %t20 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t18, %"compiler/mir:Place" %t19, 1
  %t22 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t20, { i64, [15 x i64] } %a2, 2
  %t23 = getelementptr { i64, [21 x i64] }, ptr %t15, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t22, ptr %t23
  %t24 = load { i64, [21 x i64] }, ptr %t15
  %t26 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t24, ptr %t26
  %t27 = load ptr, ptr %l9, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s0, ptr %t27, ptr %t26)
  br label %bb3
bb3:
  %t29 = load i32, ptr %l4, !tbaa !23
  %t31 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t29)
  store %"compiler/mir:Place" %t31, ptr %l17
  br label %bb4
bb4:
  store { i64, [4 x i64] } zeroinitializer, ptr %t32
  %t33 = getelementptr { i64, [4 x i64] }, ptr %t32, i32 0, i32 0
  store i64 1, ptr %t33
  %t34 = load %"compiler/mir:Place", ptr %l17
  %t35 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t34, 0
  %t36 = getelementptr { i64, [4 x i64] }, ptr %t32, i32 0, i32 1
  store { %"compiler/mir:Place" } %t35, ptr %t36
  %t37 = load { i64, [4 x i64] }, ptr %t32
  call void @__olang_scope_close(ptr %s0)
  store { i64, [4 x i64] } %t37, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eisChar(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l16 = alloca i64
  %l19 = alloca i64
  %l37 = alloca ptr
  %l38 = alloca i32
  %l41 = alloca i32
  %l42 = alloca i1
  %l46 = alloca i32
  %l49 = alloca i1
  %l50 = alloca ptr
  %l53 = alloca i32
  %l54 = alloca i32
  %l57 = alloca i1
  %l60 = alloca i1
  %l65 = alloca i32
  %s2 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  store i32 %a1, ptr %l3, !tbaa !23
  store i64 0, ptr %l4, !tbaa !24
  store i64 16, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t8 = load i64, ptr %l5, !tbaa !24
  %t9 = load i64, ptr %l4, !tbaa !24
  %t12 = icmp sgt i64 %t8, %t9
  br i1 %t12, label %bb1, label %bb2
bb1:
  %t14 = load i64, ptr %l6, !tbaa !24
  %t16 = icmp sgt i64 %t14, 0
  br i1 %t16, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l16, !tbaa !24
  br label %bb6
bb3:
  %t18 = load i64, ptr %l5, !tbaa !24
  %t19 = load i64, ptr %l4, !tbaa !24
  %t22 = sub i64 %t18, %t19
  %t23 = load i64, ptr %l6, !tbaa !24
  %t26 = add i64 %t22, %t23
  %t28 = sub i64 %t26, 1
  %t29 = load i64, ptr %l6, !tbaa !24
  %t32 = sdiv i64 %t28, %t29
  store i64 %t32, ptr %l19, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l19, !tbaa !24
  br label %bb5
bb5:
  %t34 = load i64, ptr %l19, !tbaa !24
  store i64 %t34, ptr %l16, !tbaa !24
  br label %bb6
bb6:
  %t35 = load i64, ptr %l16, !tbaa !24
  store i64 %t35, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t36 = load i64, ptr %l8, !tbaa !24
  %t37 = load i64, ptr %l7, !tbaa !24
  %t40 = icmp slt i64 %t36, %t37
  %t42 = xor i1 %t40, true
  br i1 %t42, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb31
bb9:
  br label %bb10
bb10:
  %t44 = load i64, ptr %l4, !tbaa !24
  %t45 = load i64, ptr %l8, !tbaa !24
  %t46 = load i64, ptr %l6, !tbaa !24
  %t49 = mul i64 %t45, %t46
  %t52 = add i64 %t44, %t49
  store i64 %t52, ptr %l9, !tbaa !24
  %t54 = load ptr, ptr %l2, !tbaa !29
  store ptr %t54, ptr %l37, !tbaa !29
  %t55 = load i32, ptr %l3, !tbaa !23
  store i32 %t55, ptr %l38, !tbaa !23
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/lower:lowering", ptr %t56, i32 0, i32 0
  %t59 = load ptr, ptr %t58, !tbaa !29
  %t61 = call i32 @compiler_2flower_2ecompiler_2flower_3aLowerer_2echar(ptr %v0, ptr %t59)
  store i32 %t61, ptr %l41
  br label %bb11
bb11:
  %t62 = load ptr, ptr %l37, !tbaa !29
  %t63 = load i32, ptr %l38, !tbaa !23
  %t64 = load i32, ptr %l41, !tbaa !23
  %t65 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t62, i32 %t63, i32 %t64)
  store i1 %t65, ptr %l42
  br label %bb12
bb12:
  %t66 = load i1, ptr %l42, !tbaa !21
  br i1 %t66, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s2)
  store i1 true, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  %t68 = load ptr, ptr %l2, !tbaa !29
  %t69 = load i32, ptr %l3, !tbaa !23
  %t72 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t68, i32 %t69)
  store i32 %t72, ptr %l46
  br label %bb16
bb16:
  %t73 = load i32, ptr %l46
  %t75 = trunc i64 18 to i32
  %t76 = icmp eq i32 %t73, %t75
  br i1 %t76, label %bb17, label %bb18
bb17:
  %t78 = load ptr, ptr %l2, !tbaa !29
  store ptr %t78, ptr %l50, !tbaa !29
  %t79 = load ptr, ptr %l2, !tbaa !29
  %t80 = load i32, ptr %l3, !tbaa !23
  %t83 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t79, i32 %t80)
  store i32 %t83, ptr %l53
  br label %bb19
bb18:
  store i1 false, ptr %l49, !tbaa !21
  br label %bb21
bb19:
  %t84 = load ptr, ptr %l50, !tbaa !29
  %t85 = load i32, ptr %l53, !tbaa !23
  %t86 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t84, i32 %t85)
  store i32 %t86, ptr %l54
  br label %bb20
bb20:
  %t87 = load i32, ptr %l54
  %t89 = trunc i64 4 to i32
  %t90 = icmp eq i32 %t87, %t89
  store i1 %t90, ptr %l49, !tbaa !21
  br label %bb21
bb21:
  %t92 = load i1, ptr %l49, !tbaa !21
  br i1 %t92, label %bb22, label %bb23
bb22:
  %t93 = load ptr, ptr %l2, !tbaa !29
  %t94 = load i32, ptr %l3, !tbaa !23
  %t97 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %t93, i32 %t94)
  store i1 %t97, ptr %l60
  br label %bb24
bb23:
  store i1 false, ptr %l57, !tbaa !21
  br label %bb25
bb24:
  %t98 = load i1, ptr %l60, !tbaa !21
  store i1 %t98, ptr %l57, !tbaa !21
  br label %bb25
bb25:
  %t99 = load i1, ptr %l57, !tbaa !21
  %t100 = xor i1 %t99, true
  br i1 %t100, label %bb26, label %bb27
bb26:
  call void @__olang_scope_close(ptr %s2)
  store i1 false, ptr %rv
  br label %ret
bb27:
  br label %bb28
bb28:
  %t103 = load ptr, ptr %l2, !tbaa !29
  %t104 = load i32, ptr %l3, !tbaa !23
  %t107 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %t103, i32 %t104)
  store i32 %t107, ptr %l65
  br label %bb29
bb29:
  %t108 = load i32, ptr %l65, !tbaa !23
  store i32 %t108, ptr %l3, !tbaa !23
  call void @__olang_scope_close(ptr %s2)
  br label %bb30
bb30:
  %t109 = load i64, ptr %l8, !tbaa !24
  %t111 = add i64 %t109, 1
  store i64 %t111, ptr %l8, !tbaa !24
  br label %bb7
bb31:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2flower_2ecompiler_2flower_3alowering_2eitems(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %lp3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l13 = alloca { i64, ptr }
  %l15 = alloca i64
  %l24 = alloca i64
  %l27 = alloca i64
  %l46 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/lower:lowering", ptr %a0, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t8 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t4, i32 %a1)
  store { i64, ptr } %t8, ptr %l13
  br label %bb1
bb1:
  %t9 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t9, ptr %l2, !tbaa !27
  %t10 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l15, !tbaa !24
  %t13 = load i64, ptr %l15, !tbaa !24
  %t14 = icmp sge i64 %t13, 0
  br i1 %t14, label %bb2, label %bb3
bb2:
  %t16 = load i64, ptr %l15, !tbaa !24
  %t17 = icmp sle i64 %t16, 2305843009213693951
  br i1 %t17, label %bb4, label %bb5
bb3:
  call void @__olang_check_failed(ptr @olang_loc_fe6f132f471090d8_e27fa787bcbe9484)
  unreachable
bb4:
  %t19 = load i64, ptr %l15, !tbaa !24
  %t20 = mul i64 %t19, 4
  %t21 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t20)
  %t22 = insertvalue { i64, ptr } undef, i64 %t19, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t21, 1
  %t24 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t24, ptr %lp3
  %t26 = load ptr, ptr %lp3
  store { i64, ptr } %t23, ptr %t26, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t27 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t27, 0
  store i64 %t29, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t31 = load i64, ptr %l5, !tbaa !24
  %t32 = load i64, ptr %l4, !tbaa !24
  %t35 = icmp sgt i64 %t31, %t32
  br i1 %t35, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_fe6f132f471090d8_e27fa787bcbe9484)
  unreachable
bb6:
  %t37 = load i64, ptr %l6, !tbaa !24
  %t39 = icmp sgt i64 %t37, 0
  br i1 %t39, label %bb8, label %bb9
bb7:
  store i64 0, ptr %l24, !tbaa !24
  br label %bb11
bb8:
  %t41 = load i64, ptr %l5, !tbaa !24
  %t42 = load i64, ptr %l4, !tbaa !24
  %t45 = sub i64 %t41, %t42
  %t46 = load i64, ptr %l6, !tbaa !24
  %t49 = add i64 %t45, %t46
  %t51 = sub i64 %t49, 1
  %t52 = load i64, ptr %l6, !tbaa !24
  %t55 = sdiv i64 %t51, %t52
  store i64 %t55, ptr %l27, !tbaa !24
  br label %bb10
bb9:
  store i64 0, ptr %l27, !tbaa !24
  br label %bb10
bb10:
  %t57 = load i64, ptr %l27, !tbaa !24
  store i64 %t57, ptr %l24, !tbaa !24
  br label %bb11
bb11:
  %t58 = load i64, ptr %l24, !tbaa !24
  store i64 %t58, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb12
bb12:
  store %olang.scope zeroinitializer, ptr %s2
  %t59 = load i64, ptr %l8, !tbaa !24
  %t60 = load i64, ptr %l7, !tbaa !24
  %t63 = icmp slt i64 %t59, %t60
  %t65 = xor i1 %t63, true
  br i1 %t65, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s2)
  br label %bb17
bb14:
  br label %bb15
bb15:
  %t67 = load i64, ptr %l4, !tbaa !24
  %t68 = load i64, ptr %l8, !tbaa !24
  %t69 = load i64, ptr %l6, !tbaa !24
  %t72 = mul i64 %t68, %t69
  %t75 = add i64 %t67, %t72
  store i64 %t75, ptr %l9, !tbaa !24
  %t77 = load i64, ptr %l9, !tbaa !24
  %t78 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t78, ptr %l46, !tbaa !27
  %t79 = load i64, ptr %l9, !tbaa !24
  %t81 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !27
  %t83 = getelementptr i32, ptr %t82, i64 %t79
  %t84 = load i32, ptr %t83, !tbaa !33
  %t86 = load ptr, ptr %lp3
  %t88 = getelementptr { i64, ptr }, ptr %t86, i32 0, i32 1
  %t89 = load ptr, ptr %t88, !tbaa !27
  %t90 = getelementptr i32, ptr %t89, i64 %t77
  store i32 %t84, ptr %t90, !tbaa !33
  call void @__olang_scope_close(ptr %s2)
  br label %bb16
bb16:
  %t91 = load i64, ptr %l8, !tbaa !24
  %t93 = add i64 %t91, 1
  store i64 %t93, ptr %l8, !tbaa !24
  br label %bb12
bb17:
  %t95 = load ptr, ptr %lp3
  %t96 = load { i64, ptr }, ptr %t95, !tbaa !27
  store { i64, ptr } %t96, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2ejoin(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l13 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l17 = alloca i32
  %l20 = alloca i64
  %l23 = alloca %"compiler/lower:tryCtx"
  %l33 = alloca { i64, ptr }
  %l51 = alloca ptr
  %l53 = alloca %"compiler/lower:level"
  %l64 = alloca { i64, ptr }
  %l72 = alloca %"compiler/lower:tryCtx"
  %l75 = alloca %"compiler/lower:tryCtx"
  %l76 = alloca i32
  %l77 = alloca i32
  %l80 = alloca i32
  %l81 = alloca i32
  %l82 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t4 = getelementptr %"compiler/typed:Join", ptr %t2, i32 0, i32 0
  %t5 = load ptr, ptr %t4, !tbaa !29
  %t8 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2ejoinErrors(ptr %v0, ptr %v1, ptr %t1, ptr %t5)
  store i32 %t8, ptr %l17
  br label %bb1
bb1:
  %t9 = load i32, ptr %l17, !tbaa !23
  store i32 %t9, ptr %l3, !tbaa !23
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/lower:lowering", ptr %t10, i32 0, i32 9
  %t14 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3alevel_3e_2eLen_3ccompiler_2flower_3alevel_3e(ptr %v0, ptr %t12)
  store i64 %t14, ptr %l20
  br label %bb2
bb2:
  %t15 = load ptr, ptr %l2, !tbaa !29
  %t17 = getelementptr %"compiler/typed:Join", ptr %t15, i32 0, i32 2
  %t18 = load { i64, ptr }, ptr %t17, !tbaa !27
  %t19 = load i64, ptr %l20, !tbaa !24
  %t21 = call %"compiler/lower:tryCtx" @compiler_2flower_3atryCtx_2ector(ptr %v1, ptr %v0, i64 %t19, { i64, ptr } %t18, i1 false, i1 false)
  store %"compiler/lower:tryCtx" %t21, ptr %l23
  br label %bb3
bb3:
  %t22 = load %"compiler/lower:tryCtx", ptr %l23
  %t23 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store %"compiler/lower:tryCtx" %t22, ptr %t23
  store ptr %t23, ptr %l4, !tbaa !29
  %t25 = load ptr, ptr %l2, !tbaa !29
  %t27 = getelementptr %"compiler/typed:Join", ptr %t25, i32 0, i32 2
  %t28 = load { i64, ptr }, ptr %t27, !tbaa !27
  store { i64, ptr } %t28, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t30 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t30, 0
  store i64 %t32, ptr %l7, !tbaa !24
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s2
  %t34 = load i64, ptr %l6, !tbaa !24
  %t35 = load i64, ptr %l7, !tbaa !24
  %t38 = icmp slt i64 %t34, %t35
  %t40 = xor i1 %t38, true
  br i1 %t40, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s2)
  br label %bb10
bb6:
  br label %bb7
bb7:
  %t42 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t42, ptr %l33, !tbaa !27
  %t43 = load i64, ptr %l6, !tbaa !24
  %t45 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !27
  %t47 = getelementptr ptr, ptr %t46, i64 %t43
  %t48 = load ptr, ptr %t47, !tbaa !39
  store ptr %t48, ptr %l8, !tbaa !29
  %t50 = load ptr, ptr %l4, !tbaa !29
  %t52 = getelementptr %"compiler/lower:tryCtx", ptr %t50, i32 0, i32 4
  %t53 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aBlockId_3e_2ePush_3ccompiler_2fmir_3aBlockId_3e(ptr %v0, ptr %t52, i32 %t53)
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb9
bb9:
  %t56 = load i64, ptr %l6, !tbaa !24
  %t58 = add i64 %t56, 1
  store i64 %t58, ptr %l6, !tbaa !24
  br label %bb4
bb10:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t61 = load ptr, ptr %l2, !tbaa !29
  %t63 = getelementptr %"compiler/typed:Join", ptr %t61, i32 0, i32 0
  %t64 = load ptr, ptr %t63, !tbaa !29
  %t65 = load i32, ptr %l3, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eopenBlock(ptr %v0, ptr %v1, ptr %t60, ptr %t64, i32 3, i32 %t65)
  br label %bb11
bb11:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/lower:lowering", ptr %t70, i32 0, i32 16
  %t73 = load ptr, ptr %l4, !tbaa !29
  %t75 = load %"compiler/lower:tryCtx", ptr %t73
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3atryCtx_3e_2ePush_3ccompiler_2flower_3atryCtx_3e(ptr %v0, ptr %v0, ptr %t72, %"compiler/lower:tryCtx" %t75)
  br label %bb12
bb12:
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t80 = getelementptr %"compiler/lower:lowering", ptr %t78, i32 0, i32 17
  store ptr %t80, ptr %l51, !tbaa !29
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = call %"compiler/lower:level" @compiler_2flower_2ecompiler_2flower_3alowering_2etop(ptr %v0, ptr %t81)
  store %"compiler/lower:level" %t83, ptr %l53
  br label %bb13
bb13:
  %t84 = getelementptr %"compiler/lower:level", ptr %l53, i32 0, i32 0
  %t85 = load i32, ptr %t84, !tbaa !23
  %t86 = load ptr, ptr %l51, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeId_3e_2ePush_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t86, i32 %t85)
  br label %bb14
bb14:
  %t88 = load ptr, ptr %l2, !tbaa !29
  %t90 = getelementptr %"compiler/typed:Join", ptr %t88, i32 0, i32 0
  %t91 = load ptr, ptr %t90, !tbaa !29
  %t93 = getelementptr %"compiler/typed:Block", ptr %t91, i32 0, i32 1
  %t94 = load { i64, ptr }, ptr %t93, !tbaa !27
  store { i64, ptr } %t94, ptr %l9, !tbaa !27
  store i64 0, ptr %l10, !tbaa !24
  %t96 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t98 = extractvalue { i64, ptr } %t96, 0
  store i64 %t98, ptr %l11, !tbaa !24
  br label %bb15
bb15:
  store %olang.scope zeroinitializer, ptr %s5
  %t100 = load i64, ptr %l10, !tbaa !24
  %t101 = load i64, ptr %l11, !tbaa !24
  %t104 = icmp slt i64 %t100, %t101
  %t106 = xor i1 %t104, true
  br i1 %t106, label %bb16, label %bb17
bb16:
  call void @__olang_scope_close(ptr %s5)
  br label %bb21
bb17:
  br label %bb18
bb18:
  %t108 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t108, ptr %l64, !tbaa !27
  %t109 = load i64, ptr %l10, !tbaa !24
  %t111 = getelementptr { i64, ptr }, ptr %l64, i32 0, i32 1
  %t112 = load ptr, ptr %t111, !tbaa !27
  %t113 = getelementptr ptr, ptr %t112, i64 %t109
  %t114 = load ptr, ptr %t113, !tbaa !39
  %t116 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estmt(ptr %v0, ptr %v1, ptr %t116, ptr %t114)
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s5)
  br label %bb20
bb20:
  %t120 = load i64, ptr %l10, !tbaa !24
  %t122 = add i64 %t120, 1
  store i64 %t122, ptr %l10, !tbaa !24
  br label %bb15
bb21:
  %t124 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2ecloseBlock(ptr %v0, ptr %t124)
  br label %bb22
bb22:
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t128 = getelementptr %"compiler/lower:lowering", ptr %t126, i32 0, i32 16
  %t130 = call { i32, %"compiler/lower:tryCtx" } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3atryCtx_3e_2ePop_3ccompiler_2flower_3atryCtx_3e(ptr %v0, ptr %v0, ptr %t128)
  %t131 = extractvalue { i32, %"compiler/lower:tryCtx" } %t130, 1
  %t132 = extractvalue { i32, %"compiler/lower:tryCtx" } %t130, 0
  store i32 %t132, ptr %l76
  %t133 = icmp ne i32 %t132, 0
  br i1 %t133, label %bb24, label %ok.134
ok.134:
  store %"compiler/lower:tryCtx" %t131, ptr %l75
  br label %bb23
bb23:
  %t135 = load %"compiler/lower:tryCtx", ptr %l75
  store %"compiler/lower:tryCtx" %t135, ptr %l72
  br label %bb26
bb24:
  br label %bb25
bb25:
  call void @__olang_ert_req_clear()
  br label %bb26
bb26:
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t138 = getelementptr %"compiler/lower:lowering", ptr %t136, i32 0, i32 17
  %t140 = call { i32, i32 } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeId_3e_2ePop_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t138)
  %t141 = extractvalue { i32, i32 } %t140, 1
  %t142 = extractvalue { i32, i32 } %t140, 0
  store i32 %t142, ptr %l81
  %t143 = icmp ne i32 %t142, 0
  br i1 %t143, label %bb28, label %ok.144
ok.144:
  store i32 %t141, ptr %l80
  br label %bb27
bb27:
  %t145 = load i32, ptr %l80, !tbaa !23
  store i32 %t145, ptr %l77, !tbaa !23
  br label %bb30
bb28:
  br label %bb29
bb29:
  call void @__olang_ert_req_clear()
  br label %bb30
bb30:
  %t146 = load ptr, ptr @__olang_prog_scope
  %t147 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aBlockId_3e(ptr %t146)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t147, ptr %l82
  br label %bb31
bb31:
  %t148 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l82
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t148, ptr %l13
  %t149 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eleaveOpen(ptr %v0, ptr %s0, ptr %t149, ptr %l13)
  br label %bb32
bb32:
  %t152 = load ptr, ptr %l0, !tbaa !29
  %t153 = load ptr, ptr %l4, !tbaa !29
  %t155 = load %"compiler/lower:tryCtx", ptr %t153
  %t156 = load ptr, ptr %l2, !tbaa !29
  %t158 = getelementptr %"compiler/typed:Join", ptr %t156, i32 0, i32 2
  %t159 = load { i64, ptr }, ptr %t158, !tbaa !27
  %t160 = load i32, ptr @G_2ecompiler_2fmir_2eNoLocal, !tbaa !23
  %t161 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eclauses(ptr %v0, ptr %v0, ptr %v1, ptr %s0, ptr %t152, %"compiler/lower:tryCtx" %t155, { i64, ptr } %t159, i32 %t160, i32 %t161, ptr %l13)
  br label %bb33
bb33:
  %t168 = load ptr, ptr %l0, !tbaa !29
  %t169 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l13
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2epatch(ptr %v0, ptr %s0, ptr %t168, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t169)
  br label %bb34
bb34:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2ejump(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca %"compiler/lower:loopCtx"
  %l8 = alloca i64
  %l16 = alloca %"compiler/lower:loopCtx"
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 12
  %t5 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3aloopCtx_3e_2eLen_3ccompiler_2flower_3aloopCtx_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l8
  br label %bb1
bb1:
  %t6 = load i64, ptr %l8, !tbaa !24
  %t7 = sub i64 %t6, 1
  store i64 %t7, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t9 = load i64, ptr %l4, !tbaa !24
  %t11 = icmp sge i64 %t9, 0
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb17
bb4:
  br label %bb5
bb5:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/lower:lowering", ptr %t15, i32 0, i32 12
  %t18 = load i64, ptr %l4, !tbaa !24
  %t21 = call %"compiler/lower:loopCtx" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3aloopCtx_3e_2eAt_3ccompiler_2flower_3aloopCtx_3e(ptr %v0, ptr %v0, ptr %t17, i64 %t18)
  store %"compiler/lower:loopCtx" %t21, ptr %l16
  br label %bb6
bb6:
  %t22 = load %"compiler/lower:loopCtx", ptr %l16
  store %"compiler/lower:loopCtx" %t22, ptr %l5
  %t23 = getelementptr %"compiler/lower:loopCtx", ptr %l5, i32 0, i32 0
  %t24 = load i32, ptr %t23, !tbaa !23
  %t28 = icmp eq i32 %t24, %a3
  br i1 %t28, label %bb7, label %bb8
bb7:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/lower:loopCtx", ptr %l5, i32 0, i32 1
  %t32 = load i64, ptr %t31, !tbaa !24
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eleave(ptr %v0, ptr %t30, i64 %t32)
  br label %bb9
bb8:
  br label %bb15
bb9:
  %t37 = trunc i64 0 to i32
  %t38 = icmp eq i32 %a2, %t37
  br i1 %t38, label %bb10, label %bb11
bb10:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/lower:loopCtx", ptr %l5, i32 0, i32 3
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eleaveOpen(ptr %v0, ptr %v0, ptr %t40, ptr %t41)
  br label %bb12
bb11:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/lower:loopCtx", ptr %l5, i32 0, i32 4
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eleaveOpen(ptr %v0, ptr %v0, ptr %t44, ptr %t45)
  br label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb15:
  call void @__olang_scope_close(ptr %s2)
  br label %bb16
bb16:
  %t48 = load i64, ptr %l4, !tbaa !24
  %t50 = sub i64 %t48, 1
  store i64 %t50, ptr %l4, !tbaa !24
  br label %bb2
bb17:
  %t52 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2egap(ptr %v0, ptr %s0, ptr %t52, %"compiler/source:Span" %a1, { i64, ptr } { i64 38, ptr @.d20 })
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2eloop(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca %"compiler/lower:loopCtx"
  %l8 = alloca i32
  %l14 = alloca ptr
  %l16 = alloca i32
  %l19 = alloca i64
  %l20 = alloca %"compiler/lower:loopCtx"
  %l24 = alloca ptr
  %l27 = alloca i64
  %l29 = alloca %"compiler/lower:loopCtx"
  %l33 = alloca i64
  %l44 = alloca %"compiler/lower:loopCtx"
  %l47 = alloca %"compiler/lower:loopCtx"
  %l48 = alloca i32
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 3
  %t5 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t3)
  store i32 %t5, ptr %l8
  br label %bb1
bb1:
  %t6 = load i32, ptr %l8, !tbaa !23
  store i32 %t6, ptr %l4, !tbaa !23
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load i32, ptr %l4, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2egoto(ptr %v0, ptr %t7, i32 %t8)
  br label %bb2
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load i32, ptr %l4, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t11, i32 %t12)
  br label %bb3
bb3:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/lower:lowering", ptr %t15, i32 0, i32 12
  store ptr %t17, ptr %l14, !tbaa !29
  %t18 = load ptr, ptr %l2, !tbaa !29
  %t20 = getelementptr %"compiler/typed:Block", ptr %t18, i32 0, i32 0
  %t21 = load i32, ptr %t20, !tbaa !23
  store i32 %t21, ptr %l16, !tbaa !23
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/lower:lowering", ptr %t22, i32 0, i32 9
  %t26 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3alevel_3e_2eLen_3ccompiler_2flower_3alevel_3e(ptr %v0, ptr %t24)
  store i64 %t26, ptr %l19
  br label %bb4
bb4:
  %t27 = load i32, ptr %l16, !tbaa !23
  %t28 = load i64, ptr %l19, !tbaa !24
  %t29 = call %"compiler/lower:loopCtx" @compiler_2flower_3aloopCtx_2ector(ptr %v0, i32 %t27, i64 %t28)
  store %"compiler/lower:loopCtx" %t29, ptr %l20
  br label %bb5
bb5:
  %t30 = load ptr, ptr %l14, !tbaa !29
  %t31 = load %"compiler/lower:loopCtx", ptr %l20
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3aloopCtx_3e_2ePus_Hecf1f3338ace0b99f129de91c7b21562(ptr %v0, ptr %v0, ptr %t30, %"compiler/lower:loopCtx" %t31)
  br label %bb6
bb6:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t33 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eblock(ptr %v0, ptr %v1, ptr %t32, ptr %t33)
  br label %bb7
bb7:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/lower:lowering", ptr %t36, i32 0, i32 12
  store ptr %t38, ptr %l24, !tbaa !29
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/lower:lowering", ptr %t39, i32 0, i32 12
  %t43 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3aloopCtx_3e_2eLen_3ccompiler_2flower_3aloopCtx_3e(ptr %v0, ptr %t41)
  store i64 %t43, ptr %l27
  br label %bb8
bb8:
  %t44 = load i64, ptr %l27, !tbaa !24
  %t45 = sub i64 %t44, 1
  %t46 = load ptr, ptr %l24, !tbaa !29
  %t48 = call %"compiler/lower:loopCtx" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3aloopCtx_3e_2eAt_3ccompiler_2flower_3aloopCtx_3e(ptr %v0, ptr %v0, ptr %t46, i64 %t45)
  store %"compiler/lower:loopCtx" %t48, ptr %l29
  br label %bb9
bb9:
  %t49 = load %"compiler/lower:loopCtx", ptr %l29
  store %"compiler/lower:loopCtx" %t49, ptr %l5
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/lower:loopCtx", ptr %l5, i32 0, i32 4
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eleaveOpen(ptr %v0, ptr %v0, ptr %t50, ptr %t51)
  br label %bb10
bb10:
  %t54 = getelementptr %"compiler/lower:loopCtx", ptr %l5, i32 0, i32 4
  %t56 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aBlockId_3e_2eLen_3ccompiler_2fmir_3aBlockId_3e(ptr %v0, ptr %t54)
  store i64 %t56, ptr %l33
  br label %bb11
bb11:
  %t57 = load i64, ptr %l33, !tbaa !24
  %t58 = icmp sgt i64 %t57, 0
  br i1 %t58, label %bb12, label %bb13
bb12:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/lower:loopCtx", ptr %l5, i32 0, i32 4
  %t62 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t61
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2epatch(ptr %v0, ptr %v0, ptr %t60, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t62)
  br label %bb14
bb13:
  br label %bb20
bb14:
  %t65 = load ptr, ptr %l3, !tbaa !29
  %t67 = icmp eq ptr %t65, null
  %t69 = xor i1 %t67, true
  br i1 %t69, label %bb15, label %bb16
bb15:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t72 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eblock(ptr %v0, ptr %v2, ptr %t71, ptr %t72)
  br label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb18
bb18:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t76 = load i32, ptr %l4, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2egoto(ptr %v0, ptr %t75, i32 %t76)
  br label %bb19
bb19:
  br label %bb20
bb20:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/lower:lowering", ptr %t79, i32 0, i32 12
  %t83 = call { i32, %"compiler/lower:loopCtx" } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3aloopCtx_3e_2ePop_3ccompiler_2flower_3aloopCtx_3e(ptr %v0, ptr %v0, ptr %t81)
  %t84 = extractvalue { i32, %"compiler/lower:loopCtx" } %t83, 1
  %t85 = extractvalue { i32, %"compiler/lower:loopCtx" } %t83, 0
  store i32 %t85, ptr %l48
  %t86 = icmp ne i32 %t85, 0
  br i1 %t86, label %bb22, label %ok.87
ok.87:
  store %"compiler/lower:loopCtx" %t84, ptr %l47
  br label %bb21
bb21:
  %t88 = load %"compiler/lower:loopCtx", ptr %l47
  store %"compiler/lower:loopCtx" %t88, ptr %l44
  br label %bb24
bb22:
  br label %bb23
bb23:
  call void @__olang_ert_req_clear()
  br label %bb24
bb24:
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t90 = getelementptr %"compiler/lower:loopCtx", ptr %l5, i32 0, i32 3
  %t91 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t90
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2epatch(ptr %v0, ptr %v0, ptr %t89, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t91)
  br label %bb25
bb25:
  br label %ret
ret:
  ret void
}

define dso_local { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2emadeAt(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l6 = alloca i1
  %l13 = alloca { i64, [1 x i64] }
  %rv = alloca { i64, [1 x i64] }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l1, !tbaa !23
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"compiler/lower:lowering", ptr %t2, i32 0, i32 20
  %t5 = load i32, ptr %t4, !tbaa !23
  %t8 = icmp eq i32 %t1, %t5
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load i32, ptr %l1, !tbaa !23
  %t12 = icmp sge i32 %t10, 0
  store i1 %t12, ptr %l6, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l6, !tbaa !21
  br label %bb3
bb3:
  %t14 = load i1, ptr %l6, !tbaa !21
  br i1 %t14, label %bb4, label %bb5
bb4:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/lower:lowering", ptr %t15, i32 0, i32 21
  %t18 = load { i64, [1 x i64] }, ptr %t17
  store { i64, [1 x i64] } %t18, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load i32, ptr %l1, !tbaa !23
  %t24 = call { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ebuilt(ptr %v0, ptr %t20, i32 %t21)
  store { i64, [1 x i64] } %t24, ptr %l13
  br label %bb7
bb7:
  %t25 = load { i64, [1 x i64] }, ptr %l13
  store { i64, [1 x i64] } %t25, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [1 x i64] }, ptr %rv
  ret { i64, [1 x i64] } %rr
}

define dso_local { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2emake(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca { i64, ptr }
  %l7 = alloca i32
  %l8 = alloca { i64, [4 x i64] }
  %l20 = alloca { i64, ptr }
  %l27 = alloca i1
  %l30 = alloca i1
  %l33 = alloca i32
  %l34 = alloca ptr
  %l35 = alloca i32
  %l36 = alloca i32
  %l38 = alloca i64
  %l42 = alloca %"compiler/mir:Range"
  %l45 = alloca { i64, [4 x i64] }
  %l46 = alloca ptr
  %l47 = alloca i32
  %l51 = alloca { i64, [1 x i64] }
  %l56 = alloca { i64, [4 x i64] }
  %l57 = alloca ptr
  %l58 = alloca i32
  %l59 = alloca i32
  %l61 = alloca i64
  %l65 = alloca %"compiler/mir:Range"
  %l68 = alloca { i64, [4 x i64] }
  %l76 = alloca { i64, [4 x i64] }
  %l84 = alloca { i64, [4 x i64] }
  %s1 = alloca %olang.scope
  %rv = alloca { i64, [4 x i64] }
  %t35 = alloca { i64, [4 x i64] }, align 8
  %t73 = alloca { i64, [15 x i64] }, align 8
  %t102 = alloca { i64, [15 x i64] }, align 8
  %t133 = alloca { i64, [15 x i64] }, align 8
  %t159 = alloca { i64, [1 x i64] }, align 8
  %t178 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  store %"compiler/source:Span" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t6 = load ptr, ptr %l1, !tbaa !29
  %t8 = getelementptr %"compiler/typed:Make", ptr %t6, i32 0, i32 0
  %t9 = load i32, ptr %t8
  store i32 %t9, ptr %l5
  %t11 = load i32, ptr %l5
  %t13 = trunc i64 0 to i32
  %t14 = icmp eq i32 %t11, %t13
  br i1 %t14, label %bb1, label %bb2
bb1:
  br label %bb5
bb2:
  %t16 = load i32, ptr %l5
  %t18 = trunc i64 1 to i32
  %t19 = icmp eq i32 %t16, %t18
  br i1 %t19, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb24
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t24 = getelementptr %"compiler/typed:Make", ptr %t22, i32 0, i32 2
  %t25 = load { i64, ptr }, ptr %t24, !tbaa !27
  %t28 = call { i64, ptr } @compiler_2flower_2ecompiler_2flower_3alowering_2evals(ptr %v0, ptr %v1, ptr %s1, ptr %t21, { i64, ptr } %t25)
  store { i64, ptr } %t28, ptr %l20
  br label %bb6
bb6:
  %t29 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t29, ptr %l6, !tbaa !27
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/lower:lowering", ptr %t30, i32 0, i32 7
  %t33 = load i1, ptr %t32, !tbaa !21
  br i1 %t33, label %bb7, label %bb8
bb7:
  store { i64, [4 x i64] } zeroinitializer, ptr %t35
  %t36 = getelementptr { i64, [4 x i64] }, ptr %t35, i32 0, i32 0
  store i64 0, ptr %t36
  %t37 = load { i64, [4 x i64] }, ptr %t35
  call void @__olang_scope_close(ptr %s1)
  store { i64, [4 x i64] } %t37, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t39 = load ptr, ptr %l1, !tbaa !29
  %t41 = getelementptr %"compiler/typed:Make", ptr %t39, i32 0, i32 4
  %t42 = load i32, ptr %t41, !tbaa !23
  %t44 = icmp sge i32 %t42, 0
  br i1 %t44, label %bb10, label %bb11
bb10:
  %t46 = load ptr, ptr %l4, !tbaa !29
  %t47 = load i32, ptr %l2, !tbaa !23
  %t50 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t46, i32 %t47)
  store i1 %t50, ptr %l30
  br label %bb12
bb11:
  store i1 false, ptr %l27, !tbaa !21
  br label %bb13
bb12:
  %t51 = load i1, ptr %l30, !tbaa !21
  store i1 %t51, ptr %l27, !tbaa !21
  br label %bb13
bb13:
  %t52 = load i1, ptr %l27, !tbaa !21
  br i1 %t52, label %bb14, label %bb15
bb14:
  %t53 = load ptr, ptr %l4, !tbaa !29
  %t54 = load i32, ptr %l2, !tbaa !23
  %t57 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t53, i32 %t54)
  store i32 %t57, ptr %l33
  br label %bb16
bb15:
  br label %bb21
bb16:
  %t58 = load i32, ptr %l33, !tbaa !23
  store i32 %t58, ptr %l7, !tbaa !23
  %t59 = load ptr, ptr %l0, !tbaa !29
  store ptr %t59, ptr %l34, !tbaa !29
  %t60 = load i32, ptr %l7, !tbaa !23
  store i32 %t60, ptr %l35, !tbaa !23
  %t61 = load i32, ptr %l7, !tbaa !23
  store i32 %t61, ptr %l36, !tbaa !23
  %t62 = load ptr, ptr %l1, !tbaa !29
  %t64 = getelementptr %"compiler/typed:Make", ptr %t62, i32 0, i32 1
  %t65 = load i64, ptr %t64, !tbaa !24
  store i64 %t65, ptr %l38, !tbaa !24
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"compiler/lower:lowering", ptr %t66, i32 0, i32 3
  %t69 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t72 = call %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eArgs(ptr %v0, ptr %s1, ptr %t68, { i64, ptr } %t69)
  store %"compiler/mir:Range" %t72, ptr %l42
  br label %bb17
bb17:
  store { i64, [15 x i64] } zeroinitializer, ptr %t73
  %t74 = getelementptr { i64, [15 x i64] }, ptr %t73, i32 0, i32 0
  store i64 6, ptr %t74
  %t75 = load i32, ptr %l36, !tbaa !23
  %t76 = insertvalue { i32, i64, %"compiler/mir:Range" } undef, i32 %t75, 0
  %t77 = load i64, ptr %l38, !tbaa !24
  %t78 = insertvalue { i32, i64, %"compiler/mir:Range" } %t76, i64 %t77, 1
  %t79 = load %"compiler/mir:Range", ptr %l42
  %t80 = insertvalue { i32, i64, %"compiler/mir:Range" } %t78, %"compiler/mir:Range" %t79, 2
  %t81 = getelementptr { i64, [15 x i64] }, ptr %t73, i32 0, i32 1
  store { i32, i64, %"compiler/mir:Range" } %t80, ptr %t81
  %t82 = load { i64, [15 x i64] }, ptr %t73
  %t83 = load %"compiler/source:Span", ptr %l3
  %t84 = load ptr, ptr %l34, !tbaa !29
  %t85 = load i32, ptr %l35, !tbaa !23
  %t88 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %t84, i32 %t85, { i64, [15 x i64] } %t82, %"compiler/source:Span" %t83)
  store { i64, [4 x i64] } %t88, ptr %l45
  br label %bb18
bb18:
  %t89 = load { i64, [4 x i64] }, ptr %l45
  store { i64, [4 x i64] } %t89, ptr %l8
  %t90 = load ptr, ptr %l0, !tbaa !29
  store ptr %t90, ptr %l46, !tbaa !29
  %t91 = load i32, ptr %l2, !tbaa !23
  store i32 %t91, ptr %l47, !tbaa !23
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t93 = load ptr, ptr %l1, !tbaa !29
  %t95 = getelementptr %"compiler/typed:Make", ptr %t93, i32 0, i32 4
  %t96 = load i32, ptr %t95, !tbaa !23
  %t99 = call { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ebuilt(ptr %v0, ptr %t92, i32 %t96)
  store { i64, [1 x i64] } %t99, ptr %l51
  br label %bb19
bb19:
  %t100 = load { i64, [4 x i64] }, ptr %l8
  %t101 = load i32, ptr %l2, !tbaa !23
  store { i64, [15 x i64] } zeroinitializer, ptr %t102
  %t103 = getelementptr { i64, [15 x i64] }, ptr %t102, i32 0, i32 0
  store i64 7, ptr %t103
  %t104 = load { i64, [1 x i64] }, ptr %l51
  %t105 = insertvalue { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 } undef, { i64, [1 x i64] } %t104, 0
  %t107 = insertvalue { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 } %t105, { i64, [4 x i64] } %t100, 1
  %t109 = insertvalue { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 } %t107, i32 %t101, 2
  %t110 = getelementptr { i64, [15 x i64] }, ptr %t102, i32 0, i32 1
  store { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 } %t109, ptr %t110
  %t111 = load { i64, [15 x i64] }, ptr %t102
  %t112 = load %"compiler/source:Span", ptr %l3
  %t113 = load ptr, ptr %l46, !tbaa !29
  %t114 = load i32, ptr %l47, !tbaa !23
  %t117 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %t113, i32 %t114, { i64, [15 x i64] } %t111, %"compiler/source:Span" %t112)
  store { i64, [4 x i64] } %t117, ptr %l56
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s1)
  %t118 = load { i64, [4 x i64] }, ptr %l56
  store { i64, [4 x i64] } %t118, ptr %rv
  br label %ret
bb21:
  %t119 = load ptr, ptr %l0, !tbaa !29
  store ptr %t119, ptr %l57, !tbaa !29
  %t120 = load i32, ptr %l2, !tbaa !23
  store i32 %t120, ptr %l58, !tbaa !23
  %t121 = load i32, ptr %l2, !tbaa !23
  store i32 %t121, ptr %l59, !tbaa !23
  %t122 = load ptr, ptr %l1, !tbaa !29
  %t124 = getelementptr %"compiler/typed:Make", ptr %t122, i32 0, i32 1
  %t125 = load i64, ptr %t124, !tbaa !24
  store i64 %t125, ptr %l61, !tbaa !24
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t128 = getelementptr %"compiler/lower:lowering", ptr %t126, i32 0, i32 3
  %t129 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t132 = call %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eArgs(ptr %v0, ptr %s1, ptr %t128, { i64, ptr } %t129)
  store %"compiler/mir:Range" %t132, ptr %l65
  br label %bb22
bb22:
  store { i64, [15 x i64] } zeroinitializer, ptr %t133
  %t134 = getelementptr { i64, [15 x i64] }, ptr %t133, i32 0, i32 0
  store i64 6, ptr %t134
  %t135 = load i32, ptr %l59, !tbaa !23
  %t136 = insertvalue { i32, i64, %"compiler/mir:Range" } undef, i32 %t135, 0
  %t137 = load i64, ptr %l61, !tbaa !24
  %t138 = insertvalue { i32, i64, %"compiler/mir:Range" } %t136, i64 %t137, 1
  %t139 = load %"compiler/mir:Range", ptr %l65
  %t140 = insertvalue { i32, i64, %"compiler/mir:Range" } %t138, %"compiler/mir:Range" %t139, 2
  %t141 = getelementptr { i64, [15 x i64] }, ptr %t133, i32 0, i32 1
  store { i32, i64, %"compiler/mir:Range" } %t140, ptr %t141
  %t142 = load { i64, [15 x i64] }, ptr %t133
  %t143 = load %"compiler/source:Span", ptr %l3
  %t144 = load ptr, ptr %l57, !tbaa !29
  %t145 = load i32, ptr %l58, !tbaa !23
  %t148 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %t144, i32 %t145, { i64, [15 x i64] } %t142, %"compiler/source:Span" %t143)
  store { i64, [4 x i64] } %t148, ptr %l68
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s1)
  %t149 = load { i64, [4 x i64] }, ptr %l68
  store { i64, [4 x i64] } %t149, ptr %rv
  br label %ret
bb24:
  %t150 = load i32, ptr %l5
  %t152 = trunc i64 2 to i32
  %t153 = icmp eq i32 %t150, %t152
  br i1 %t153, label %bb25, label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb29
bb27:
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t156 = load ptr, ptr %l1, !tbaa !29
  %t157 = load i32, ptr %l2, !tbaa !23
  %t158 = load %"compiler/source:Span", ptr %l3
  store { i64, [1 x i64] } zeroinitializer, ptr %t159
  %t160 = getelementptr { i64, [1 x i64] }, ptr %t159, i32 0, i32 0
  store i64 2, ptr %t160
  %t161 = load { i64, [1 x i64] }, ptr %t159
  %t167 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2earrayLit(ptr %v0, ptr %v1, ptr %t155, ptr %t156, i32 %t157, %"compiler/source:Span" %t158, i1 false, { i64, [1 x i64] } %t161)
  store { i64, [4 x i64] } %t167, ptr %l76
  br label %bb28
bb28:
  %t168 = load { i64, [4 x i64] }, ptr %l76
  store { i64, [4 x i64] } %t168, ptr %rv
  br label %ret
bb29:
  %t169 = load i32, ptr %l5
  %t171 = trunc i64 3 to i32
  %t172 = icmp eq i32 %t169, %t171
  br i1 %t172, label %bb30, label %bb31
bb30:
  br label %bb32
bb31:
  br label %bb34
bb32:
  %t174 = load ptr, ptr %l0, !tbaa !29
  %t175 = load ptr, ptr %l1, !tbaa !29
  %t176 = load i32, ptr %l2, !tbaa !23
  %t177 = load %"compiler/source:Span", ptr %l3
  store { i64, [1 x i64] } zeroinitializer, ptr %t178
  %t179 = getelementptr { i64, [1 x i64] }, ptr %t178, i32 0, i32 0
  store i64 2, ptr %t179
  %t180 = load { i64, [1 x i64] }, ptr %t178
  %t186 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2efill(ptr %v0, ptr %v1, ptr %t174, ptr %t175, i32 %t176, %"compiler/source:Span" %t177, i1 false, { i64, [1 x i64] } %t180)
  store { i64, [4 x i64] } %t186, ptr %l84
  br label %bb33
bb33:
  %t187 = load { i64, [4 x i64] }, ptr %l84
  store { i64, [4 x i64] } %t187, ptr %rv
  br label %ret
bb34:
  call void @__olang_check_failed(ptr @olang_loc_c00faf6434efe24b_96f261c8870620df)
  unreachable
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2emix(ptr %v0, ptr %a0, { i64, [4 x i64] } %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca { i64, [4 x i64] }
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca { i64, [4 x i64] }
  %l9 = alloca { i64, [4 x i64] }
  %l10 = alloca { i64, ptr }
  %l12 = alloca { i64, [4 x i64] }
  %l13 = alloca ptr
  %l14 = alloca i32
  %l15 = alloca i32
  %l16 = alloca { i64, [4 x i64] }
  %l17 = alloca ptr
  %l18 = alloca i32
  %l19 = alloca i32
  %l20 = alloca { i64, [4 x i64] }
  %l22 = alloca { i64, [4 x i64] }
  %l23 = alloca { i64, ptr }
  %l25 = alloca { i64, [4 x i64] }
  %l26 = alloca { i64, ptr }
  %l28 = alloca { i64, [4 x i64] }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, [4 x i64] }
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i32 5, ptr %l5
  %t2 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  store i32 %t2, ptr %l6, !tbaa !23
  store { i64, [4 x i64] } %a1, ptr %l7
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t6 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2econstI64(ptr %v0, ptr %t4, i64 -7046029254386353131)
  store { i64, [4 x i64] } %t6, ptr %l9
  br label %bb1
bb1:
  %t7 = mul i64 2, 40
  %t8 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t7)
  %t9 = insertvalue { i64, ptr } undef, i64 2, 0
  %t10 = insertvalue { i64, ptr } %t9, ptr %t8, 1
  store { i64, ptr } %t10, ptr %l10, !tbaa !27
  %t11 = load { i64, [4 x i64] }, ptr %l7
  %t12 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, [4 x i64] }, ptr %t13, i64 0
  store { i64, [4 x i64] } %t11, ptr %t14
  %t15 = load { i64, [4 x i64] }, ptr %l9
  %t16 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = getelementptr { i64, [4 x i64] }, ptr %t17, i64 1
  store { i64, [4 x i64] } %t15, ptr %t18
  %t19 = load %"compiler/source:Span", ptr %l2
  %t20 = load ptr, ptr %l4, !tbaa !29
  %t21 = load i32, ptr %l5
  %t22 = load i32, ptr %l6, !tbaa !23
  %t23 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t25 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s0, ptr %t20, i32 %t21, i32 %t22, { i64, ptr } %t23, %"compiler/source:Span" %t19)
  store { i64, [4 x i64] } %t25, ptr %l12
  br label %bb2
bb2:
  %t26 = load { i64, [4 x i64] }, ptr %l12
  store { i64, [4 x i64] } %t26, ptr %l3
  %t27 = load ptr, ptr %l0, !tbaa !29
  store ptr %t27, ptr %l13, !tbaa !29
  store i32 12, ptr %l14
  %t28 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  store i32 %t28, ptr %l15, !tbaa !23
  %t29 = load { i64, [4 x i64] }, ptr %l3
  store { i64, [4 x i64] } %t29, ptr %l16
  %t30 = load ptr, ptr %l0, !tbaa !29
  store ptr %t30, ptr %l17, !tbaa !29
  store i32 9, ptr %l18
  %t31 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  store i32 %t31, ptr %l19, !tbaa !23
  %t32 = load { i64, [4 x i64] }, ptr %l3
  store { i64, [4 x i64] } %t32, ptr %l20
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2econstI64(ptr %v0, ptr %t33, i64 29)
  store { i64, [4 x i64] } %t35, ptr %l22
  br label %bb3
bb3:
  %t36 = mul i64 2, 40
  %t37 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t36)
  %t38 = insertvalue { i64, ptr } undef, i64 2, 0
  %t39 = insertvalue { i64, ptr } %t38, ptr %t37, 1
  store { i64, ptr } %t39, ptr %l23, !tbaa !27
  %t40 = load { i64, [4 x i64] }, ptr %l20
  %t41 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !27
  %t43 = getelementptr { i64, [4 x i64] }, ptr %t42, i64 0
  store { i64, [4 x i64] } %t40, ptr %t43
  %t44 = load { i64, [4 x i64] }, ptr %l22
  %t45 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !27
  %t47 = getelementptr { i64, [4 x i64] }, ptr %t46, i64 1
  store { i64, [4 x i64] } %t44, ptr %t47
  %t48 = load %"compiler/source:Span", ptr %l2
  %t49 = load ptr, ptr %l17, !tbaa !29
  %t50 = load i32, ptr %l18
  %t51 = load i32, ptr %l19, !tbaa !23
  %t52 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t54 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s0, ptr %t49, i32 %t50, i32 %t51, { i64, ptr } %t52, %"compiler/source:Span" %t48)
  store { i64, [4 x i64] } %t54, ptr %l25
  br label %bb4
bb4:
  %t55 = mul i64 2, 40
  %t56 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t55)
  %t57 = insertvalue { i64, ptr } undef, i64 2, 0
  %t58 = insertvalue { i64, ptr } %t57, ptr %t56, 1
  store { i64, ptr } %t58, ptr %l26, !tbaa !27
  %t59 = load { i64, [4 x i64] }, ptr %l16
  %t60 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !27
  %t62 = getelementptr { i64, [4 x i64] }, ptr %t61, i64 0
  store { i64, [4 x i64] } %t59, ptr %t62
  %t63 = load { i64, [4 x i64] }, ptr %l25
  %t64 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t65 = load ptr, ptr %t64, !tbaa !27
  %t66 = getelementptr { i64, [4 x i64] }, ptr %t65, i64 1
  store { i64, [4 x i64] } %t63, ptr %t66
  %t67 = load %"compiler/source:Span", ptr %l2
  %t68 = load ptr, ptr %l13, !tbaa !29
  %t69 = load i32, ptr %l14
  %t70 = load i32, ptr %l15, !tbaa !23
  %t71 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t73 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s0, ptr %t68, i32 %t69, i32 %t70, { i64, ptr } %t71, %"compiler/source:Span" %t67)
  store { i64, [4 x i64] } %t73, ptr %l28
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s0)
  %t74 = load { i64, [4 x i64] }, ptr %l28
  store { i64, [4 x i64] } %t74, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local %"compiler/mir:Place" @compiler_2flower_2ecompiler_2flower_3alowering_2emk(ptr %v0, ptr %v1, ptr %a0, %"compiler/lower:pl" %a1) #0 {
entry:
  %l1 = alloca %"compiler/lower:pl"
  %l3 = alloca ptr
  %l4 = alloca { i64, [2 x i64] }
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"compiler/mir:Place"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/mir:Place"
  store %"compiler/lower:pl" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = getelementptr %"compiler/lower:lowering", ptr %a0, i32 0, i32 3
  store ptr %t3, ptr %l3, !tbaa !29
  %t4 = getelementptr %"compiler/lower:pl", ptr %l1, i32 0, i32 0
  %t5 = load { i64, [2 x i64] }, ptr %t4
  store { i64, [2 x i64] } %t5, ptr %l4
  %t6 = getelementptr %"compiler/lower:pl", ptr %l1, i32 0, i32 1
  %t8 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aProj_3e_2eToArray_3ccompiler_2fmir_3aProj_3e(ptr %v1, ptr %s0, ptr %t6)
  store { i64, ptr } %t8, ptr %l6
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l3, !tbaa !29
  %t10 = load { i64, [2 x i64] }, ptr %l4
  %t11 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t12 = call %"compiler/mir:Place" @compiler_2fmir_2ecompiler_2fmir_3aFn_2ePlace(ptr %v0, ptr %s0, ptr %t9, { i64, [2 x i64] } %t10, { i64, ptr } %t11)
  store %"compiler/mir:Place" %t12, ptr %l7
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  %t13 = load %"compiler/mir:Place", ptr %l7
  store %"compiler/mir:Place" %t13, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/mir:Place", ptr %rv
  ret %"compiler/mir:Place" %rr
}

define dso_local i64 @compiler_2flower_2ecompiler_2flower_3alowering_2emodule(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l12 = alloca i64
  %l16 = alloca i64
  %l19 = alloca i64
  %l43 = alloca ptr
  %s2 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l1, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/lower:Lowerer", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/generic:Program", ptr %t7, i32 0, i32 0
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/load:Loader", ptr %t10, i32 0, i32 5
  %t14 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_He36936f29a17adf60cb2ecc49df5337f(ptr %v0, ptr %t12)
  store i64 %t14, ptr %l12
  br label %bb1
bb1:
  %t15 = load i64, ptr %l12, !tbaa !24
  store i64 %t15, ptr %l2, !tbaa !24
  store i64 1, ptr %l3, !tbaa !24
  %t16 = load i64, ptr %l2, !tbaa !24
  %t17 = load i64, ptr %l1, !tbaa !24
  %t20 = icmp sgt i64 %t16, %t17
  br i1 %t20, label %bb2, label %bb3
bb2:
  %t22 = load i64, ptr %l3, !tbaa !24
  %t24 = icmp sgt i64 %t22, 0
  br i1 %t24, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l16, !tbaa !24
  br label %bb7
bb4:
  %t26 = load i64, ptr %l2, !tbaa !24
  %t27 = load i64, ptr %l1, !tbaa !24
  %t30 = sub i64 %t26, %t27
  %t31 = load i64, ptr %l3, !tbaa !24
  %t34 = add i64 %t30, %t31
  %t36 = sub i64 %t34, 1
  %t37 = load i64, ptr %l3, !tbaa !24
  %t40 = sdiv i64 %t36, %t37
  store i64 %t40, ptr %l19, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l19, !tbaa !24
  br label %bb6
bb6:
  %t42 = load i64, ptr %l19, !tbaa !24
  store i64 %t42, ptr %l16, !tbaa !24
  br label %bb7
bb7:
  %t43 = load i64, ptr %l16, !tbaa !24
  store i64 %t43, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t44 = load i64, ptr %l5, !tbaa !24
  %t45 = load i64, ptr %l4, !tbaa !24
  %t48 = icmp slt i64 %t44, %t45
  %t50 = xor i1 %t48, true
  br i1 %t50, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb17
bb10:
  br label %bb11
bb11:
  %t52 = load i64, ptr %l1, !tbaa !24
  %t53 = load i64, ptr %l5, !tbaa !24
  %t54 = load i64, ptr %l3, !tbaa !24
  %t57 = mul i64 %t53, %t54
  %t60 = add i64 %t52, %t57
  store i64 %t60, ptr %l6, !tbaa !24
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/lower:lowering", ptr %t62, i32 0, i32 0
  %t65 = load ptr, ptr %t64, !tbaa !29
  %t67 = getelementptr %"compiler/lower:Lowerer", ptr %t65, i32 0, i32 0
  %t68 = load ptr, ptr %t67, !tbaa !29
  %t70 = getelementptr %"compiler/generic:Program", ptr %t68, i32 0, i32 0
  %t71 = load ptr, ptr %t70, !tbaa !29
  %t73 = getelementptr %"compiler/load:Loader", ptr %t71, i32 0, i32 5
  %t74 = load i64, ptr %l6, !tbaa !24
  %t77 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t73, i64 %t74)
  store ptr %t77, ptr %l43
  br label %bb12
bb12:
  %t78 = load ptr, ptr %l43, !tbaa !29
  %t80 = getelementptr %"compiler/load:Module", ptr %t78, i32 0, i32 4
  %t81 = load i64, ptr %t80, !tbaa !24
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/lower:lowering", ptr %t82, i32 0, i32 4
  %t85 = load i64, ptr %t84, !tbaa !24
  %t88 = icmp eq i64 %t81, %t85
  br i1 %t88, label %bb13, label %bb14
bb13:
  %t90 = load i64, ptr %l6, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  store i64 %t90, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s2)
  br label %bb16
bb16:
  %t92 = load i64, ptr %l5, !tbaa !24
  %t94 = add i64 %t92, 1
  store i64 %t94, ptr %l5, !tbaa !24
  br label %bb8
bb17:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local %"compiler/mir:Range" @compiler_2flower_2ecompiler_2flower_3alowering_2epassed(ptr %v0, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l18 = alloca i64
  %l21 = alloca i64
  %l43 = alloca i1
  %l46 = alloca i1
  %l53 = alloca i64
  %l54 = alloca ptr
  %l59 = alloca { i64, [1 x i64] }
  %l60 = alloca { i64, [1 x i64] }
  %l66 = alloca %"compiler/mir:Range"
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca %"compiler/mir:Range"
  %t63 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l1, !tbaa !24
  store i64 %t1, ptr %l10, !tbaa !24
  %t2 = load i64, ptr %l10, !tbaa !24
  %t3 = icmp sge i64 %t2, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load i64, ptr %l10, !tbaa !24
  %t6 = icmp sle i64 %t5, 576460752303423487
  br i1 %t6, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_279896acdd8c6bde_4c10668047ad718a)
  unreachable
bb3:
  %t8 = load i64, ptr %l10, !tbaa !24
  %t9 = mul i64 %t8, 16
  %t10 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t9)
  %t11 = insertvalue { i64, ptr } undef, i64 %t8, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t14 = load i64, ptr %l1, !tbaa !24
  store i64 %t14, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t16 = load i64, ptr %l5, !tbaa !24
  %t17 = load i64, ptr %l4, !tbaa !24
  %t20 = icmp sgt i64 %t16, %t17
  br i1 %t20, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_279896acdd8c6bde_4c10668047ad718a)
  unreachable
bb5:
  %t22 = load i64, ptr %l6, !tbaa !24
  %t24 = icmp sgt i64 %t22, 0
  br i1 %t24, label %bb7, label %bb8
bb6:
  store i64 0, ptr %l18, !tbaa !24
  br label %bb10
bb7:
  %t26 = load i64, ptr %l5, !tbaa !24
  %t27 = load i64, ptr %l4, !tbaa !24
  %t30 = sub i64 %t26, %t27
  %t31 = load i64, ptr %l6, !tbaa !24
  %t34 = add i64 %t30, %t31
  %t36 = sub i64 %t34, 1
  %t37 = load i64, ptr %l6, !tbaa !24
  %t40 = sdiv i64 %t36, %t37
  store i64 %t40, ptr %l21, !tbaa !24
  br label %bb9
bb8:
  store i64 0, ptr %l21, !tbaa !24
  br label %bb9
bb9:
  %t42 = load i64, ptr %l21, !tbaa !24
  store i64 %t42, ptr %l18, !tbaa !24
  br label %bb10
bb10:
  %t43 = load i64, ptr %l18, !tbaa !24
  store i64 %t43, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb11
bb11:
  store %olang.scope zeroinitializer, ptr %s2
  %t44 = load i64, ptr %l8, !tbaa !24
  %t45 = load i64, ptr %l7, !tbaa !24
  %t48 = icmp slt i64 %t44, %t45
  %t50 = xor i1 %t48, true
  br i1 %t50, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s2)
  br label %bb27
bb13:
  br label %bb14
bb14:
  %t52 = load i64, ptr %l4, !tbaa !24
  %t53 = load i64, ptr %l8, !tbaa !24
  %t54 = load i64, ptr %l6, !tbaa !24
  %t57 = mul i64 %t53, %t54
  %t60 = add i64 %t52, %t57
  store i64 %t60, ptr %l9, !tbaa !24
  %t62 = load i64, ptr %l9, !tbaa !24
  store { i64, [1 x i64] } zeroinitializer, ptr %t63
  %t64 = getelementptr { i64, [1 x i64] }, ptr %t63, i32 0, i32 0
  store i64 2, ptr %t64
  %t65 = load { i64, [1 x i64] }, ptr %t63
  %t68 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t69 = load ptr, ptr %t68, !tbaa !27
  %t70 = getelementptr { i64, [1 x i64] }, ptr %t69, i64 %t62
  store { i64, [1 x i64] } %t65, ptr %t70
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/lower:lowering", ptr %t71, i32 0, i32 19
  %t74 = load i1, ptr %t73, !tbaa !21
  br i1 %t74, label %bb15, label %bb16
bb15:
  %t76 = load i32, ptr %l2, !tbaa !23
  %t78 = icmp sge i32 %t76, 0
  store i1 %t78, ptr %l43, !tbaa !21
  br label %bb17
bb16:
  store i1 false, ptr %l43, !tbaa !21
  br label %bb17
bb17:
  %t80 = load i1, ptr %l43, !tbaa !21
  br i1 %t80, label %bb18, label %bb19
bb18:
  %t81 = load i32, ptr %l2, !tbaa !23
  %t83 = sext i32 %t81 to i64
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr %"compiler/lower:lowering", ptr %t84, i32 0, i32 22
  %t87 = getelementptr %"compiler/typed:Plan", ptr %t86, i32 0, i32 0
  %t88 = load { i64, ptr }, ptr %t87, !tbaa !27
  %t90 = extractvalue { i64, ptr } %t88, 0
  %t93 = icmp slt i64 %t83, %t90
  store i1 %t93, ptr %l46, !tbaa !21
  br label %bb20
bb19:
  store i1 false, ptr %l46, !tbaa !21
  br label %bb20
bb20:
  %t95 = load i1, ptr %l46, !tbaa !21
  br i1 %t95, label %bb21, label %bb22
bb21:
  %t96 = load i64, ptr %l9, !tbaa !24
  store i64 %t96, ptr %l53, !tbaa !24
  %t97 = load ptr, ptr %l0, !tbaa !29
  store ptr %t97, ptr %l54, !tbaa !29
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t100 = getelementptr %"compiler/lower:lowering", ptr %t98, i32 0, i32 22
  %t101 = load i32, ptr %l2, !tbaa !23
  %t102 = load i64, ptr %l9, !tbaa !24
  %t106 = call { i64, [1 x i64] } @compiler_2ftyped_2ecompiler_2ftyped_3aPlan_2ePassed(ptr %v0, ptr %t100, i32 %t101, i64 %t102)
  store { i64, [1 x i64] } %t106, ptr %l59
  br label %bb23
bb22:
  br label %bb25
bb23:
  %t107 = load ptr, ptr %l54, !tbaa !29
  %t108 = load { i64, [1 x i64] }, ptr %l59
  %t109 = call { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2escopeRef(ptr %v0, ptr %t107, { i64, [1 x i64] } %t108)
  store { i64, [1 x i64] } %t109, ptr %l60
  br label %bb24
bb24:
  %t110 = load { i64, [1 x i64] }, ptr %l60
  %t111 = load i64, ptr %l53, !tbaa !24
  %t112 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t113 = load ptr, ptr %t112, !tbaa !27
  %t114 = getelementptr { i64, [1 x i64] }, ptr %t113, i64 %t111
  store { i64, [1 x i64] } %t110, ptr %t114
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s2)
  br label %bb26
bb26:
  %t115 = load i64, ptr %l8, !tbaa !24
  %t117 = add i64 %t115, 1
  store i64 %t117, ptr %l8, !tbaa !24
  br label %bb11
bb27:
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t121 = getelementptr %"compiler/lower:lowering", ptr %t119, i32 0, i32 3
  %t122 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t125 = call %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eScopeRefs(ptr %v0, ptr %s0, ptr %t121, { i64, ptr } %t122)
  store %"compiler/mir:Range" %t125, ptr %l66
  br label %bb28
bb28:
  call void @__olang_scope_close(ptr %s0)
  %t126 = load %"compiler/mir:Range", ptr %l66
  store %"compiler/mir:Range" %t126, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/mir:Range", ptr %rv
  ret %"compiler/mir:Range" %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2epatch(ptr %v0, ptr %v1, ptr %a0, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l10 = alloca i64
  %l15 = alloca i32
  %l17 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l21 = alloca i32
  %l30 = alloca { i64, ptr }
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %t57 = alloca { i64, [7 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aBlockId_3e_2eLen_3ccompiler_2fmir_3aBlockId_3e(ptr %v1, ptr %l1)
  store i64 %t2, ptr %l10
  br label %bb1
bb1:
  %t3 = load i64, ptr %l10, !tbaa !24
  %t4 = icmp eq i64 %t3, 0
  br i1 %t4, label %bb2, label %bb3
bb2:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/lower:lowering", ptr %t6, i32 0, i32 7
  store i1 true, ptr %t8, !tbaa !21
  br label %ret
bb3:
  br label %bb4
bb4:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/lower:lowering", ptr %t9, i32 0, i32 3
  %t13 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t11)
  store i32 %t13, ptr %l15
  br label %bb5
bb5:
  %t14 = load i32, ptr %l15, !tbaa !23
  store i32 %t14, ptr %l2, !tbaa !23
  store ptr %l1, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  br label %bb6
bb6:
  store %olang.scope zeroinitializer, ptr %s3
  %t16 = load ptr, ptr %l3, !tbaa !29
  %t17 = load i64, ptr %l4, !tbaa !24
  %t20 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aBlockId_3e_2eRunFrom_3ccompiler_2fmir_3aBlockId_3e(ptr %v1, ptr %t16, i64 %t17)
  %t21 = extractvalue { i32, { i64, ptr } } %t20, 1
  %t22 = extractvalue { i32, { i64, ptr } } %t20, 0
  store i32 %t22, ptr %l21
  %t23 = icmp ne i32 %t22, 0
  br i1 %t23, label %bb8, label %ok.24
ok.24:
  store { i64, ptr } %t21, ptr %l20
  br label %bb7
bb7:
  %t25 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t25, ptr %l17, !tbaa !27
  br label %bb12
bb8:
  %t26 = load i32, ptr %l21, !tbaa !23
  %t27 = ashr i32 %t26, 16
  %t29 = icmp eq i32 %t27, 1
  br i1 %t29, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_678a134ca8e67a35_be411b19d54605f9)
  unreachable
bb11:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s3)
  br label %bb21
bb12:
  %t31 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t31, ptr %l5, !tbaa !27
  %t32 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t34 = extractvalue { i64, ptr } %t32, 0
  store i64 %t34, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb13
bb13:
  store %olang.scope zeroinitializer, ptr %s4
  %t36 = load i64, ptr %l7, !tbaa !24
  %t37 = load i64, ptr %l6, !tbaa !24
  %t40 = icmp slt i64 %t36, %t37
  %t42 = xor i1 %t40, true
  br i1 %t42, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s4)
  br label %bb19
bb15:
  br label %bb16
bb16:
  %t44 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t44, ptr %l30, !tbaa !27
  %t45 = load i64, ptr %l7, !tbaa !24
  %t47 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t48 = load ptr, ptr %t47, !tbaa !27
  %t49 = getelementptr i32, ptr %t48, i64 %t45
  %t50 = load i32, ptr %t49, !tbaa !33
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/lower:lowering", ptr %t52, i32 0, i32 3
  %t56 = load i32, ptr %l2, !tbaa !23
  store { i64, [7 x i64] } zeroinitializer, ptr %t57
  %t58 = getelementptr { i64, [7 x i64] }, ptr %t57, i32 0, i32 0
  store i64 1, ptr %t58
  %t60 = insertvalue { i32 } undef, i32 %t56, 0
  %t61 = getelementptr { i64, [7 x i64] }, ptr %t57, i32 0, i32 1
  store { i32 } %t60, ptr %t61
  %t62 = load { i64, [7 x i64] }, ptr %t57
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eEnd(ptr %v0, ptr %t54, i32 %t50, { i64, [7 x i64] } %t62)
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s4)
  br label %bb18
bb18:
  %t66 = load i64, ptr %l7, !tbaa !24
  %t68 = add i64 %t66, 1
  store i64 %t68, ptr %l7, !tbaa !24
  br label %bb13
bb19:
  %t70 = load i64, ptr %l4, !tbaa !24
  %t71 = load i64, ptr %l6, !tbaa !24
  %t74 = add i64 %t70, %t71
  store i64 %t74, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb20
bb20:
  br label %bb6
bb21:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t77 = load i32, ptr %l2, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t76, i32 %t77)
  br label %bb22
bb22:
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2epayload(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %lp3 = alloca ptr
  %l10 = alloca %"compiler/lower:pl"
  %l18 = alloca ptr
  %l19 = alloca i32
  %l22 = alloca %"compiler/mir:Place"
  %l25 = alloca { i64, [4 x i64] }
  %l26 = alloca ptr
  %l27 = alloca i32
  %l28 = alloca i32
  %l29 = alloca { i64, [4 x i64] }
  %l33 = alloca { i64, [4 x i64] }
  %l34 = alloca { i64, ptr }
  %l36 = alloca { i64, [4 x i64] }
  %l49 = alloca %"compiler/lower:pl"
  %s2 = alloca %olang.scope
  %rv = alloca %"compiler/lower:pl"
  %t39 = alloca { i64, [15 x i64] }, align 8
  %t104 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t4 = getelementptr %"compiler/typed:Payload", ptr %t2, i32 0, i32 0
  %t5 = load ptr, ptr %t4, !tbaa !29
  %t9 = call %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2eplace(ptr %v0, ptr %v1, ptr %v2, ptr %t1, ptr %t5)
  store %"compiler/lower:pl" %t9, ptr %l10
  br label %bb1
bb1:
  %t10 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 32, i64 8)
  store ptr %t10, ptr %lp3
  %t11 = load %"compiler/lower:pl", ptr %l10
  %t12 = load ptr, ptr %lp3
  store %"compiler/lower:pl" %t11, ptr %t12
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/lower:lowering", ptr %t13, i32 0, i32 7
  %t16 = load i1, ptr %t15, !tbaa !21
  br i1 %t16, label %bb2, label %bb3
bb2:
  %t18 = load ptr, ptr %lp3
  %t19 = load %"compiler/lower:pl", ptr %t18
  store %"compiler/lower:pl" %t19, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t21 = load ptr, ptr %l1, !tbaa !29
  %t23 = getelementptr %"compiler/typed:Payload", ptr %t21, i32 0, i32 2
  %t24 = load i32, ptr %t23
  %t26 = trunc i64 0 to i32
  %t27 = icmp eq i32 %t24, %t26
  %t29 = xor i1 %t27, true
  br i1 %t29, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s2
  %t31 = load ptr, ptr %l0, !tbaa !29
  store ptr %t31, ptr %l18, !tbaa !29
  %t32 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  store i32 %t32, ptr %l19, !tbaa !23
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t34 = load ptr, ptr %lp3
  %t35 = load %"compiler/lower:pl", ptr %t34
  %t38 = call %"compiler/mir:Place" @compiler_2flower_2ecompiler_2flower_3alowering_2emk(ptr %v0, ptr %v2, ptr %t33, %"compiler/lower:pl" %t35)
  store %"compiler/mir:Place" %t38, ptr %l22
  br label %bb7
bb6:
  br label %bb12
bb7:
  store { i64, [15 x i64] } zeroinitializer, ptr %t39
  %t40 = getelementptr { i64, [15 x i64] }, ptr %t39, i32 0, i32 0
  store i64 5, ptr %t40
  %t41 = load %"compiler/mir:Place", ptr %l22
  %t42 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t41, 0
  %t43 = getelementptr { i64, [15 x i64] }, ptr %t39, i32 0, i32 1
  store { %"compiler/mir:Place" } %t42, ptr %t43
  %t44 = load { i64, [15 x i64] }, ptr %t39
  %t45 = load %"compiler/source:Span", ptr %l2
  %t46 = load ptr, ptr %l18, !tbaa !29
  %t47 = load i32, ptr %l19, !tbaa !23
  %t50 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %t46, i32 %t47, { i64, [15 x i64] } %t44, %"compiler/source:Span" %t45)
  store { i64, [4 x i64] } %t50, ptr %l25
  br label %bb8
bb8:
  %t51 = load { i64, [4 x i64] }, ptr %l25
  %t52 = load ptr, ptr %l0, !tbaa !29
  store ptr %t52, ptr %l26, !tbaa !29
  store i32 13, ptr %l27
  %t53 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t53, ptr %l28, !tbaa !23
  store { i64, [4 x i64] } %t51, ptr %l29
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t56 = load ptr, ptr %l1, !tbaa !29
  %t58 = getelementptr %"compiler/typed:Payload", ptr %t56, i32 0, i32 1
  %t59 = load i64, ptr %t58, !tbaa !24
  %t62 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2econstI64(ptr %v0, ptr %t55, i64 %t59)
  store { i64, [4 x i64] } %t62, ptr %l33
  br label %bb9
bb9:
  %t63 = mul i64 2, 40
  %t64 = call ptr @__olang_scope_alloc_zeroed(ptr %s2, i64 %t63)
  %t65 = insertvalue { i64, ptr } undef, i64 2, 0
  %t66 = insertvalue { i64, ptr } %t65, ptr %t64, 1
  store { i64, ptr } %t66, ptr %l34, !tbaa !27
  %t67 = load { i64, [4 x i64] }, ptr %l29
  %t68 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t69 = load ptr, ptr %t68, !tbaa !27
  %t70 = getelementptr { i64, [4 x i64] }, ptr %t69, i64 0
  store { i64, [4 x i64] } %t67, ptr %t70
  %t71 = load { i64, [4 x i64] }, ptr %l33
  %t72 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !27
  %t74 = getelementptr { i64, [4 x i64] }, ptr %t73, i64 1
  store { i64, [4 x i64] } %t71, ptr %t74
  %t75 = load %"compiler/source:Span", ptr %l2
  %t76 = load ptr, ptr %l26, !tbaa !29
  %t77 = load i32, ptr %l27
  %t78 = load i32, ptr %l28, !tbaa !23
  %t79 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t81 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s2, ptr %t76, i32 %t77, i32 %t78, { i64, ptr } %t79, %"compiler/source:Span" %t75)
  store { i64, [4 x i64] } %t81, ptr %l36
  br label %bb10
bb10:
  %t82 = load { i64, [4 x i64] }, ptr %l36
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = load ptr, ptr %l1, !tbaa !29
  %t87 = getelementptr %"compiler/typed:Payload", ptr %t85, i32 0, i32 2
  %t88 = load i32, ptr %t87
  %t89 = load i64, ptr @G_2ecompiler_2flower_2eWrongCase, !tbaa !24
  %t90 = load %"compiler/source:Span", ptr %l2
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2echeck(ptr %v0, ptr %t83, { i64, [4 x i64] } %t82, i32 %t88, i32 8, i64 %t89, %"compiler/source:Span" %t90)
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s2)
  br label %bb12
bb12:
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t98 = load ptr, ptr %lp3
  %t99 = load %"compiler/lower:pl", ptr %t98
  %t100 = load ptr, ptr %l1, !tbaa !29
  %t102 = getelementptr %"compiler/typed:Payload", ptr %t100, i32 0, i32 1
  %t103 = load i64, ptr %t102, !tbaa !24
  store { i64, [1 x i64] } zeroinitializer, ptr %t104
  %t105 = getelementptr { i64, [1 x i64] }, ptr %t104, i32 0, i32 0
  store i64 4, ptr %t105
  %t107 = insertvalue { i64 } undef, i64 %t103, 0
  %t108 = getelementptr { i64, [1 x i64] }, ptr %t104, i32 0, i32 1
  store { i64 } %t107, ptr %t108
  %t109 = load { i64, [1 x i64] }, ptr %t104
  %t113 = call %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2ewith(ptr %v0, ptr %v2, ptr %v2, ptr %t97, %"compiler/lower:pl" %t99, { i64, [1 x i64] } %t109)
  store %"compiler/lower:pl" %t113, ptr %l49
  br label %bb13
bb13:
  %t114 = load %"compiler/lower:pl", ptr %l49
  store %"compiler/lower:pl" %t114, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/lower:pl", ptr %rv
  ret %"compiler/lower:pl" %rr
}

define dso_local { { i64, [4 x i64] }, i32 } @compiler_2flower_2ecompiler_2flower_3alowering_2epiece(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca ptr
  %l7 = alloca %"compiler/lower:pl"
  %l8 = alloca i32
  %l12 = alloca i32
  %l15 = alloca i32
  %l16 = alloca ptr
  %l19 = alloca i32
  %l20 = alloca i1
  %l22 = alloca i1
  %l26 = alloca i1
  %l29 = alloca i64
  %l31 = alloca ptr
  %l32 = alloca i1
  %l40 = alloca %"compiler/lower:pl"
  %l49 = alloca i32
  %l50 = alloca ptr
  %l51 = alloca i32
  %l54 = alloca %"compiler/mir:Place"
  %l58 = alloca { i64, [4 x i64] }
  %l64 = alloca { i64, [4 x i64] }
  %rv = alloca { { i64, [4 x i64] }, i32 }
  %t71 = alloca { i64, [4 x i64] }, align 8
  %t96 = alloca { i64, [15 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t6 = load ptr, ptr %l1, !tbaa !29
  %t8 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t6)
  store i32 %t8, ptr %l12
  br label %bb1
bb1:
  %t9 = load i32, ptr %l12, !tbaa !23
  store i32 %t9, ptr %l4, !tbaa !23
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = load i32, ptr %l4, !tbaa !23
  %t14 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2earrayOf(ptr %v0, ptr %t10, i32 %t11)
  store i32 %t14, ptr %l15
  br label %bb2
bb2:
  %t15 = load i32, ptr %l15, !tbaa !23
  store i32 %t15, ptr %l5, !tbaa !23
  %t16 = load ptr, ptr %l3, !tbaa !29
  store ptr %t16, ptr %l16, !tbaa !29
  %t17 = load ptr, ptr %l3, !tbaa !29
  %t18 = load i32, ptr %l4, !tbaa !23
  %t21 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t17, i32 %t18)
  store i32 %t21, ptr %l19
  br label %bb3
bb3:
  %t22 = load ptr, ptr %l16, !tbaa !29
  %t23 = load i32, ptr %l19, !tbaa !23
  %t24 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t22, i32 %t23)
  store i1 %t24, ptr %l20
  br label %bb4
bb4:
  %t25 = load i1, ptr %l20, !tbaa !21
  %t26 = xor i1 %t25, true
  br i1 %t26, label %bb5, label %bb6
bb5:
  %t28 = load i32, ptr %l5, !tbaa !23
  %t29 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t32 = icmp ne i32 %t28, %t29
  store i1 %t32, ptr %l22, !tbaa !21
  br label %bb7
bb6:
  store i1 false, ptr %l22, !tbaa !21
  br label %bb7
bb7:
  %t34 = load i1, ptr %l22, !tbaa !21
  br i1 %t34, label %bb8, label %bb9
bb8:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load i32, ptr %l5, !tbaa !23
  %t39 = call i64 @compiler_2flower_2ecompiler_2flower_3alowering_2efixedLen(ptr %v0, ptr %t35, i32 %t36)
  store i64 %t39, ptr %l29
  br label %bb10
bb9:
  store i1 false, ptr %l26, !tbaa !21
  br label %bb11
bb10:
  %t40 = load i64, ptr %l29, !tbaa !24
  %t41 = icmp sge i64 %t40, 0
  store i1 %t41, ptr %l26, !tbaa !21
  br label %bb11
bb11:
  %t43 = load i1, ptr %l26, !tbaa !21
  br i1 %t43, label %bb12, label %bb13
bb12:
  %t44 = load ptr, ptr %l1, !tbaa !29
  store ptr %t44, ptr %l31, !tbaa !29
  store i1 false, ptr %l32, !tbaa !21
  %t45 = load ptr, ptr %l31, !tbaa !29
  %t46 = icmp ne ptr %t45, null
  br i1 %t46, label %bb14, label %bb15
bb13:
  br label %bb32
bb14:
  %t48 = load ptr, ptr %l31, !tbaa !29
  %t49 = load i64, ptr %t48
  %t51 = icmp eq i64 %t49, 2
  store i1 %t51, ptr %l32, !tbaa !21
  br label %bb15
bb15:
  %t52 = load i1, ptr %l32, !tbaa !21
  br i1 %t52, label %bb16, label %bb17
bb16:
  %t53 = load ptr, ptr %l1, !tbaa !29
  %t55 = getelementptr { i64, [5 x i64] }, ptr %t53, i32 0, i32 1
  %t56 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t55, i32 0, i32 2
  %t57 = load ptr, ptr %t56
  store ptr %t57, ptr %l6, !tbaa !29
  br label %bb18
bb17:
  br label %bb26
bb18:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t60 = load ptr, ptr %l6, !tbaa !29
  %t64 = call %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2eplace(ptr %v0, ptr %v1, ptr %v0, ptr %t59, ptr %t60)
  store %"compiler/lower:pl" %t64, ptr %l40
  br label %bb19
bb19:
  %t65 = load %"compiler/lower:pl", ptr %l40
  store %"compiler/lower:pl" %t65, ptr %l7
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"compiler/lower:lowering", ptr %t66, i32 0, i32 7
  %t69 = load i1, ptr %t68, !tbaa !21
  br i1 %t69, label %bb20, label %bb21
bb20:
  store { i64, [4 x i64] } zeroinitializer, ptr %t71
  %t72 = getelementptr { i64, [4 x i64] }, ptr %t71, i32 0, i32 0
  store i64 0, ptr %t72
  %t73 = load { i64, [4 x i64] }, ptr %t71
  %t74 = load i32, ptr %l4, !tbaa !23
  %t76 = insertvalue { { i64, [4 x i64] }, i32 } undef, { i64, [4 x i64] } %t73, 0
  %t78 = insertvalue { { i64, [4 x i64] }, i32 } %t76, i32 %t74, 1
  store { { i64, [4 x i64] }, i32 } %t78, ptr %rv
  br label %ret
bb21:
  br label %bb22
bb22:
  %t80 = load ptr, ptr %l3, !tbaa !29
  %t81 = load i32, ptr %l4, !tbaa !23
  %t82 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t86 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t80, i32 %t81, i64 %t82)
  store i32 %t86, ptr %l49
  br label %bb23
bb23:
  %t87 = load i32, ptr %l49, !tbaa !23
  store i32 %t87, ptr %l8, !tbaa !23
  %t88 = load ptr, ptr %l0, !tbaa !29
  store ptr %t88, ptr %l50, !tbaa !29
  %t89 = load i32, ptr %l8, !tbaa !23
  store i32 %t89, ptr %l51, !tbaa !23
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t91 = load %"compiler/lower:pl", ptr %l7
  %t94 = call %"compiler/mir:Place" @compiler_2flower_2ecompiler_2flower_3alowering_2emk(ptr %v0, ptr %v0, ptr %t90, %"compiler/lower:pl" %t91)
  store %"compiler/mir:Place" %t94, ptr %l54
  br label %bb24
bb24:
  %t95 = load i32, ptr %l8, !tbaa !23
  store { i64, [15 x i64] } zeroinitializer, ptr %t96
  %t97 = getelementptr { i64, [15 x i64] }, ptr %t96, i32 0, i32 0
  store i64 1, ptr %t97
  %t98 = load %"compiler/mir:Place", ptr %l54
  %t99 = insertvalue { %"compiler/mir:Place", i32 } undef, %"compiler/mir:Place" %t98, 0
  %t101 = insertvalue { %"compiler/mir:Place", i32 } %t99, i32 %t95, 1
  %t102 = getelementptr { i64, [15 x i64] }, ptr %t96, i32 0, i32 1
  store { %"compiler/mir:Place", i32 } %t101, ptr %t102
  %t103 = load { i64, [15 x i64] }, ptr %t96
  %t105 = load ptr, ptr %l50, !tbaa !29
  %t106 = load i32, ptr %l51, !tbaa !23
  %t109 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %t105, i32 %t106, { i64, [15 x i64] } %t103, %"compiler/source:Span" %a2)
  store { i64, [4 x i64] } %t109, ptr %l58
  br label %bb25
bb25:
  %t110 = load i32, ptr %l8, !tbaa !23
  %t111 = load { i64, [4 x i64] }, ptr %l58
  %t112 = insertvalue { { i64, [4 x i64] }, i32 } undef, { i64, [4 x i64] } %t111, 0
  %t114 = insertvalue { { i64, [4 x i64] }, i32 } %t112, i32 %t110, 1
  store { { i64, [4 x i64] }, i32 } %t114, ptr %rv
  br label %ret
bb26:
  br i1 true, label %bb27, label %bb28
bb27:
  br label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb31
bb30:
  call void @__olang_check_failed(ptr @olang_loc_eff9370fb6cf39b1_ff4f9c232720af7d)
  unreachable
bb31:
  br label %bb32
bb32:
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t117 = load ptr, ptr %l1, !tbaa !29
  %t121 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v1, ptr %t116, ptr %t117)
  store { i64, [4 x i64] } %t121, ptr %l64
  br label %bb33
bb33:
  %t122 = load i32, ptr %l4, !tbaa !23
  %t123 = load { i64, [4 x i64] }, ptr %l64
  %t124 = insertvalue { { i64, [4 x i64] }, i32 } undef, { i64, [4 x i64] } %t123, 0
  %t126 = insertvalue { { i64, [4 x i64] }, i32 } %t124, i32 %t122, 1
  store { { i64, [4 x i64] }, i32 } %t126, ptr %rv
  br label %ret
ret:
  %rr = load { { i64, [4 x i64] }, i32 }, ptr %rv
  ret { { i64, [4 x i64] }, i32 } %rr
}

define dso_local { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eplaceStorage(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca { i64, [1 x i64] }
  %l4 = alloca ptr
  %l5 = alloca i1
  %l12 = alloca { i64, [1 x i64] }
  %rv = alloca { i64, [1 x i64] }
  %t22 = alloca { i64, [1 x i64] }, align 8
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t17 = load i32, ptr %l2, !tbaa !23
  %t20 = call { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2estorageOf(ptr %v0, ptr %a0, i32 %t17)
  store { i64, [1 x i64] } %t20, ptr %l12
  br label %bb6
bb6:
  %t21 = load { i64, [1 x i64] }, ptr %l12
  store { i64, [1 x i64] } %t21, ptr %l3
  br label %bb12
bb7:
  br i1 true, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb11
bb10:
  store { i64, [1 x i64] } zeroinitializer, ptr %t22
  %t23 = getelementptr { i64, [1 x i64] }, ptr %t22, i32 0, i32 0
  store i64 2, ptr %t23
  %t24 = load { i64, [1 x i64] }, ptr %t22
  store { i64, [1 x i64] } %t24, ptr %l3
  br label %bb12
bb11:
  call void @__olang_check_failed(ptr @olang_loc_4fc653f117519a1d_d526ff90513f5371)
  unreachable
bb12:
  %t26 = load { i64, [1 x i64] }, ptr %l3
  store { i64, [1 x i64] } %t26, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [1 x i64] }, ptr %rv
  ret { i64, [1 x i64] } %rr
}

define dso_local { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2, { i64, ptr } %a3, %"compiler/source:Span" %a4) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i32
  %l12 = alloca %"compiler/mir:Range"
  %l15 = alloca { i64, [4 x i64] }
  %rv = alloca { i64, [4 x i64] }
  %t12 = alloca { i64, [15 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  %t2 = load i32, ptr %l2, !tbaa !23
  store i32 %t2, ptr %l6, !tbaa !23
  store i32 %a1, ptr %l7
  %t4 = load i32, ptr %l2, !tbaa !23
  store i32 %t4, ptr %l8, !tbaa !23
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/lower:lowering", ptr %t5, i32 0, i32 3
  %t11 = call %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eArgs(ptr %v0, ptr %v1, ptr %t7, { i64, ptr } %a3)
  store %"compiler/mir:Range" %t11, ptr %l12
  br label %bb1
bb1:
  store { i64, [15 x i64] } zeroinitializer, ptr %t12
  %t13 = getelementptr { i64, [15 x i64] }, ptr %t12, i32 0, i32 0
  store i64 3, ptr %t13
  %t14 = load i32, ptr %l7
  %t15 = insertvalue { i32, i32, %"compiler/mir:Range" } undef, i32 %t14, 0
  %t16 = load i32, ptr %l8, !tbaa !23
  %t17 = insertvalue { i32, i32, %"compiler/mir:Range" } %t15, i32 %t16, 1
  %t18 = load %"compiler/mir:Range", ptr %l12
  %t19 = insertvalue { i32, i32, %"compiler/mir:Range" } %t17, %"compiler/mir:Range" %t18, 2
  %t20 = getelementptr { i64, [15 x i64] }, ptr %t12, i32 0, i32 1
  store { i32, i32, %"compiler/mir:Range" } %t19, ptr %t20
  %t21 = load { i64, [15 x i64] }, ptr %t12
  %t23 = load ptr, ptr %l5, !tbaa !29
  %t24 = load i32, ptr %l6, !tbaa !23
  %t27 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %t23, i32 %t24, { i64, [15 x i64] } %t21, %"compiler/source:Span" %a4)
  store { i64, [4 x i64] } %t27, ptr %l15
  br label %bb2
bb2:
  %t28 = load { i64, [4 x i64] }, ptr %l15
  store { i64, [4 x i64] } %t28, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2epromote(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i32
  %l9 = alloca { i64, [1 x i64] }
  %l13 = alloca i32
  %l14 = alloca { i64, ptr }
  %l15 = alloca ptr
  %l16 = alloca i32
  %l17 = alloca ptr
  %l18 = alloca i32
  %l19 = alloca { i64, [1 x i64] }
  %l20 = alloca { i64, [4 x i64] }
  %l21 = alloca { i64, [1 x i64] }
  %l22 = alloca { i64, [4 x i64] }
  %l23 = alloca ptr
  %l28 = alloca i32
  %l29 = alloca ptr
  %l32 = alloca i32
  %l33 = alloca i1
  %l34 = alloca i1
  %l38 = alloca i1
  %l41 = alloca i64
  %l45 = alloca ptr
  %l46 = alloca i1
  %l54 = alloca i1
  %l58 = alloca i1
  %l69 = alloca ptr
  %l73 = alloca { i64, [1 x i64] }
  %l77 = alloca { i64, [4 x i64] }
  %l83 = alloca { i64, [4 x i64] }
  %l89 = alloca { i64, [4 x i64] }
  %l97 = alloca ptr
  %l98 = alloca i1
  %l107 = alloca i1
  %l111 = alloca i1
  %l114 = alloca i32
  %l116 = alloca { i64, ptr }
  %l118 = alloca ptr
  %l119 = alloca i1
  %l128 = alloca i32
  %l132 = alloca i1
  %l136 = alloca i1
  %l137 = alloca ptr
  %l140 = alloca i32
  %l141 = alloca i1
  %l143 = alloca i1
  %l147 = alloca i1
  %l150 = alloca i64
  %l155 = alloca { i64, [1 x i64] }
  %l159 = alloca { i64, [4 x i64] }
  %l165 = alloca { i64, [4 x i64] }
  %l171 = alloca { i64, [4 x i64] }
  %l176 = alloca { i64, [4 x i64] }
  %l183 = alloca { i64, [1 x i64] }
  %l191 = alloca { i64, [4 x i64] }
  %l196 = alloca i1
  %l197 = alloca i1
  %l198 = alloca ptr
  %l201 = alloca i32
  %l202 = alloca i32
  %l205 = alloca i1
  %l206 = alloca ptr
  %l209 = alloca i32
  %l210 = alloca i1
  %l211 = alloca i1
  %l212 = alloca ptr
  %l215 = alloca i32
  %l216 = alloca i1
  %l217 = alloca ptr
  %l218 = alloca %"compiler/source:Span"
  %l219 = alloca { i64, [1 x i64] }
  %l222 = alloca i32
  %s11 = alloca %olang.scope
  %rv = alloca { i64, [4 x i64] }
  %t125 = alloca { i64, [1 x i64] }, align 8
  %t138 = alloca { i64, [1 x i64] }, align 8
  %t344 = alloca { i64, [4 x i64] }, align 8
  %t362 = alloca { i64, [15 x i64] }, align 8
  %t436 = alloca { i64, [21 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  store %"compiler/source:Span" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t7 = load i32, ptr %l2, !tbaa !23
  %t10 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2earrayOf(ptr %v0, ptr %t6, i32 %t7)
  store i32 %t10, ptr %l28
  br label %bb1
bb1:
  %t11 = load i32, ptr %l28, !tbaa !23
  store i32 %t11, ptr %l5, !tbaa !23
  %t12 = load ptr, ptr %l4, !tbaa !29
  store ptr %t12, ptr %l29, !tbaa !29
  %t13 = load ptr, ptr %l4, !tbaa !29
  %t14 = load i32, ptr %l2, !tbaa !23
  %t17 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t13, i32 %t14)
  store i32 %t17, ptr %l32
  br label %bb2
bb2:
  %t18 = load ptr, ptr %l29, !tbaa !29
  %t19 = load i32, ptr %l32, !tbaa !23
  %t20 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t18, i32 %t19)
  store i1 %t20, ptr %l33
  br label %bb3
bb3:
  %t21 = load i1, ptr %l33, !tbaa !21
  br i1 %t21, label %bb4, label %bb5
bb4:
  %t22 = load i32, ptr %l5, !tbaa !23
  %t23 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t26 = icmp ne i32 %t22, %t23
  store i1 %t26, ptr %l34, !tbaa !21
  br label %bb6
bb5:
  store i1 false, ptr %l34, !tbaa !21
  br label %bb6
bb6:
  %t28 = load i1, ptr %l34, !tbaa !21
  br i1 %t28, label %bb7, label %bb8
bb7:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t30 = load i32, ptr %l5, !tbaa !23
  %t33 = call i64 @compiler_2flower_2ecompiler_2flower_3alowering_2efixedLen(ptr %v0, ptr %t29, i32 %t30)
  store i64 %t33, ptr %l41
  br label %bb9
bb8:
  store i1 false, ptr %l38, !tbaa !21
  br label %bb10
bb9:
  %t34 = load i64, ptr %l41, !tbaa !24
  %t35 = icmp slt i64 %t34, 0
  store i1 %t35, ptr %l38, !tbaa !21
  br label %bb10
bb10:
  %t37 = load i1, ptr %l38, !tbaa !21
  br i1 %t37, label %bb11, label %bb12
bb11:
  %t38 = load ptr, ptr %l1, !tbaa !29
  %t40 = getelementptr %"compiler/typed:Promote", ptr %t38, i32 0, i32 0
  %t41 = load ptr, ptr %t40, !tbaa !29
  store ptr %t41, ptr %l6, !tbaa !29
  %t43 = load ptr, ptr %l6, !tbaa !29
  store ptr %t43, ptr %l45, !tbaa !29
  store i1 false, ptr %l46, !tbaa !21
  %t44 = load ptr, ptr %l45, !tbaa !29
  %t45 = icmp ne ptr %t44, null
  br i1 %t45, label %bb13, label %bb14
bb12:
  br label %bb91
bb13:
  %t47 = load ptr, ptr %l45, !tbaa !29
  %t48 = load i64, ptr %t47
  %t50 = icmp eq i64 %t48, 7
  store i1 %t50, ptr %l46, !tbaa !21
  br label %bb14
bb14:
  %t51 = load i1, ptr %l46, !tbaa !21
  br i1 %t51, label %bb15, label %bb16
bb15:
  %t52 = load ptr, ptr %l6, !tbaa !29
  %t54 = getelementptr { i64, [5 x i64] }, ptr %t52, i32 0, i32 1
  %t55 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t54, i32 0, i32 2
  %t56 = load ptr, ptr %t55
  store ptr %t56, ptr %l7, !tbaa !29
  br label %bb17
bb16:
  br label %bb33
bb17:
  %t58 = load ptr, ptr %l7, !tbaa !29
  %t60 = getelementptr %"compiler/typed:Make", ptr %t58, i32 0, i32 0
  %t61 = load i32, ptr %t60
  %t63 = trunc i64 3 to i32
  %t64 = icmp eq i32 %t61, %t63
  br i1 %t64, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l54, !tbaa !21
  br label %bb20
bb19:
  %t66 = load ptr, ptr %l7, !tbaa !29
  %t68 = getelementptr %"compiler/typed:Make", ptr %t66, i32 0, i32 0
  %t69 = load i32, ptr %t68
  %t71 = trunc i64 2 to i32
  %t72 = icmp eq i32 %t69, %t71
  store i1 %t72, ptr %l54, !tbaa !21
  br label %bb20
bb20:
  %t74 = load i1, ptr %l54, !tbaa !21
  br i1 %t74, label %bb21, label %bb22
bb21:
  %t75 = load ptr, ptr %l7, !tbaa !29
  %t77 = getelementptr %"compiler/typed:Make", ptr %t75, i32 0, i32 4
  %t78 = load i32, ptr %t77, !tbaa !23
  %t80 = icmp sge i32 %t78, 0
  store i1 %t80, ptr %l58, !tbaa !21
  br label %bb23
bb22:
  store i1 false, ptr %l58, !tbaa !21
  br label %bb23
bb23:
  %t82 = load i1, ptr %l58, !tbaa !21
  br i1 %t82, label %bb24, label %bb25
bb24:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr %"compiler/lower:lowering", ptr %t83, i32 0, i32 20
  %t86 = load i32, ptr %t85, !tbaa !23
  store i32 %t86, ptr %l8, !tbaa !23
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t90 = getelementptr %"compiler/lower:lowering", ptr %t88, i32 0, i32 21
  %t91 = load { i64, [1 x i64] }, ptr %t90
  store { i64, [1 x i64] } %t91, ptr %l9
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t94 = load ptr, ptr %l7, !tbaa !29
  %t96 = getelementptr %"compiler/typed:Make", ptr %t94, i32 0, i32 4
  %t97 = load i32, ptr %t96, !tbaa !23
  %t100 = getelementptr %"compiler/lower:lowering", ptr %t93, i32 0, i32 20
  store i32 %t97, ptr %t100, !tbaa !23
  %t101 = load ptr, ptr %l0, !tbaa !29
  store ptr %t101, ptr %l69, !tbaa !29
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t103 = load ptr, ptr %l1, !tbaa !29
  %t105 = getelementptr %"compiler/typed:Promote", ptr %t103, i32 0, i32 1
  %t106 = load i32, ptr %t105, !tbaa !23
  %t109 = call { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ebuilt(ptr %v0, ptr %t102, i32 %t106)
  store { i64, [1 x i64] } %t109, ptr %l73
  br label %bb26
bb25:
  br label %bb32
bb26:
  %t110 = load { i64, [1 x i64] }, ptr %l73
  %t111 = load ptr, ptr %l69, !tbaa !29
  %t112 = getelementptr %"compiler/lower:lowering", ptr %t111, i32 0, i32 21
  store { i64, [1 x i64] } %t110, ptr %t112
  %t113 = load ptr, ptr %l7, !tbaa !29
  %t115 = getelementptr %"compiler/typed:Make", ptr %t113, i32 0, i32 0
  %t116 = load i32, ptr %t115
  %t118 = trunc i64 3 to i32
  %t119 = icmp eq i32 %t116, %t118
  br i1 %t119, label %bb27, label %bb28
bb27:
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t122 = load ptr, ptr %l7, !tbaa !29
  %t123 = load i32, ptr %l2, !tbaa !23
  %t124 = load %"compiler/source:Span", ptr %l3
  store { i64, [1 x i64] } zeroinitializer, ptr %t125
  %t126 = getelementptr { i64, [1 x i64] }, ptr %t125, i32 0, i32 0
  store i64 2, ptr %t126
  %t127 = load { i64, [1 x i64] }, ptr %t125
  %t133 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2efill(ptr %v0, ptr %v1, ptr %t121, ptr %t122, i32 %t123, %"compiler/source:Span" %t124, i1 false, { i64, [1 x i64] } %t127)
  store { i64, [4 x i64] } %t133, ptr %l83
  br label %bb29
bb28:
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t135 = load ptr, ptr %l7, !tbaa !29
  %t136 = load i32, ptr %l2, !tbaa !23
  %t137 = load %"compiler/source:Span", ptr %l3
  store { i64, [1 x i64] } zeroinitializer, ptr %t138
  %t139 = getelementptr { i64, [1 x i64] }, ptr %t138, i32 0, i32 0
  store i64 2, ptr %t139
  %t140 = load { i64, [1 x i64] }, ptr %t138
  %t146 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2earrayLit(ptr %v0, ptr %v1, ptr %t134, ptr %t135, i32 %t136, %"compiler/source:Span" %t137, i1 false, { i64, [1 x i64] } %t140)
  store { i64, [4 x i64] } %t146, ptr %l89
  br label %bb30
bb29:
  %t147 = load { i64, [4 x i64] }, ptr %l83
  store { i64, [4 x i64] } %t147, ptr %l77
  br label %bb31
bb30:
  %t148 = load { i64, [4 x i64] }, ptr %l89
  store { i64, [4 x i64] } %t148, ptr %l77
  br label %bb31
bb31:
  %t149 = load { i64, [4 x i64] }, ptr %l77
  %t150 = load i32, ptr %l8, !tbaa !23
  %t152 = load { i64, [1 x i64] }, ptr %l9
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t158 = getelementptr %"compiler/lower:lowering", ptr %t154, i32 0, i32 20
  store i32 %t150, ptr %t158, !tbaa !23
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t163 = getelementptr %"compiler/lower:lowering", ptr %t159, i32 0, i32 21
  store { i64, [1 x i64] } %t152, ptr %t163
  store { i64, [4 x i64] } %t149, ptr %rv
  br label %ret
bb32:
  br label %bb90
bb33:
  %t166 = load ptr, ptr %l6, !tbaa !29
  store ptr %t166, ptr %l97, !tbaa !29
  store i1 false, ptr %l98, !tbaa !21
  %t167 = load ptr, ptr %l97, !tbaa !29
  %t168 = icmp ne ptr %t167, null
  br i1 %t168, label %bb34, label %bb35
bb34:
  %t170 = load ptr, ptr %l97, !tbaa !29
  %t171 = load i64, ptr %t170
  %t173 = icmp eq i64 %t171, 9
  store i1 %t173, ptr %l98, !tbaa !21
  br label %bb35
bb35:
  %t174 = load i1, ptr %l98, !tbaa !21
  br i1 %t174, label %bb36, label %bb37
bb36:
  %t175 = load ptr, ptr %l6, !tbaa !29
  %t177 = getelementptr { i64, [5 x i64] }, ptr %t175, i32 0, i32 1
  %t178 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t177, i32 0, i32 2
  %t179 = load i32, ptr %t178
  store i32 %t179, ptr %l13
  %t181 = load ptr, ptr %l6, !tbaa !29
  %t183 = getelementptr { i64, [5 x i64] }, ptr %t181, i32 0, i32 1
  %t184 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t183, i32 0, i32 4
  %t185 = load { i64, ptr }, ptr %t184
  store { i64, ptr } %t185, ptr %l14, !tbaa !27
  br label %bb38
bb37:
  br label %bb85
bb38:
  %t187 = load i32, ptr %l13
  %t189 = trunc i64 20 to i32
  %t190 = icmp eq i32 %t187, %t189
  br i1 %t190, label %bb39, label %bb40
bb39:
  %t192 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t194 = extractvalue { i64, ptr } %t192, 0
  %t196 = icmp eq i64 %t194, 1
  store i1 %t196, ptr %l107, !tbaa !21
  br label %bb41
bb40:
  store i1 false, ptr %l107, !tbaa !21
  br label %bb41
bb41:
  %t198 = load i1, ptr %l107, !tbaa !21
  br i1 %t198, label %bb42, label %bb43
bb42:
  %t199 = load ptr, ptr %l4, !tbaa !29
  %t200 = load i32, ptr %l5, !tbaa !23
  %t203 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t199, i32 %t200)
  store i32 %t203, ptr %l114
  br label %bb44
bb43:
  store i1 false, ptr %l111, !tbaa !21
  br label %bb45
bb44:
  %t204 = load i32, ptr %l114, !tbaa !23
  %t205 = icmp eq i32 %t204, 0
  store i1 %t205, ptr %l111, !tbaa !21
  br label %bb45
bb45:
  %t207 = load i1, ptr %l111, !tbaa !21
  br i1 %t207, label %bb46, label %bb47
bb46:
  %t208 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t208, ptr %l116, !tbaa !27
  %t209 = getelementptr { i64, ptr }, ptr %l116, i32 0, i32 1
  %t210 = load ptr, ptr %t209, !tbaa !27
  %t211 = getelementptr ptr, ptr %t210, i64 0
  %t212 = load ptr, ptr %t211, !tbaa !39
  store ptr %t212, ptr %l15, !tbaa !29
  %t214 = load ptr, ptr %l15, !tbaa !29
  store ptr %t214, ptr %l118, !tbaa !29
  store i1 false, ptr %l119, !tbaa !21
  %t215 = load ptr, ptr %l118, !tbaa !29
  %t216 = icmp ne ptr %t215, null
  br i1 %t216, label %bb48, label %bb49
bb47:
  br label %bb84
bb48:
  %t218 = load ptr, ptr %l118, !tbaa !29
  %t219 = load i64, ptr %t218
  %t221 = icmp eq i64 %t219, 7
  store i1 %t221, ptr %l119, !tbaa !21
  br label %bb49
bb49:
  %t222 = load i1, ptr %l119, !tbaa !21
  br i1 %t222, label %bb50, label %bb51
bb50:
  %t223 = load ptr, ptr %l15, !tbaa !29
  %t225 = getelementptr { i64, [5 x i64] }, ptr %t223, i32 0, i32 1
  %t226 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t225, i32 0, i32 1
  %t227 = load i32, ptr %t226
  store i32 %t227, ptr %l16, !tbaa !23
  %t229 = load ptr, ptr %l15, !tbaa !29
  %t231 = getelementptr { i64, [5 x i64] }, ptr %t229, i32 0, i32 1
  %t232 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t231, i32 0, i32 2
  %t233 = load ptr, ptr %t232
  store ptr %t233, ptr %l17, !tbaa !29
  br label %bb52
bb51:
  br label %bb78
bb52:
  %t235 = load ptr, ptr %l0, !tbaa !29
  %t236 = load i32, ptr %l16, !tbaa !23
  %t239 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2earrayOf(ptr %v0, ptr %t235, i32 %t236)
  store i32 %t239, ptr %l128
  br label %bb53
bb53:
  %t240 = load i32, ptr %l128, !tbaa !23
  store i32 %t240, ptr %l18, !tbaa !23
  %t241 = load ptr, ptr %l17, !tbaa !29
  %t243 = getelementptr %"compiler/typed:Make", ptr %t241, i32 0, i32 0
  %t244 = load i32, ptr %t243
  %t246 = trunc i64 3 to i32
  %t247 = icmp eq i32 %t244, %t246
  br i1 %t247, label %bb54, label %bb55
bb54:
  store i1 true, ptr %l132, !tbaa !21
  br label %bb56
bb55:
  %t249 = load ptr, ptr %l17, !tbaa !29
  %t251 = getelementptr %"compiler/typed:Make", ptr %t249, i32 0, i32 0
  %t252 = load i32, ptr %t251
  %t254 = trunc i64 2 to i32
  %t255 = icmp eq i32 %t252, %t254
  store i1 %t255, ptr %l132, !tbaa !21
  br label %bb56
bb56:
  %t257 = load i1, ptr %l132, !tbaa !21
  br i1 %t257, label %bb57, label %bb58
bb57:
  %t258 = load ptr, ptr %l4, !tbaa !29
  store ptr %t258, ptr %l137, !tbaa !29
  %t259 = load ptr, ptr %l4, !tbaa !29
  %t260 = load i32, ptr %l16, !tbaa !23
  %t263 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t259, i32 %t260)
  store i32 %t263, ptr %l140
  br label %bb59
bb58:
  store i1 false, ptr %l136, !tbaa !21
  br label %bb61
bb59:
  %t264 = load ptr, ptr %l137, !tbaa !29
  %t265 = load i32, ptr %l140, !tbaa !23
  %t266 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t264, i32 %t265)
  store i1 %t266, ptr %l141
  br label %bb60
bb60:
  %t267 = load i1, ptr %l141, !tbaa !21
  %t268 = xor i1 %t267, true
  store i1 %t268, ptr %l136, !tbaa !21
  br label %bb61
bb61:
  %t270 = load i1, ptr %l136, !tbaa !21
  br i1 %t270, label %bb62, label %bb63
bb62:
  %t271 = load i32, ptr %l18, !tbaa !23
  %t272 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t275 = icmp ne i32 %t271, %t272
  store i1 %t275, ptr %l143, !tbaa !21
  br label %bb64
bb63:
  store i1 false, ptr %l143, !tbaa !21
  br label %bb64
bb64:
  %t277 = load i1, ptr %l143, !tbaa !21
  br i1 %t277, label %bb65, label %bb66
bb65:
  %t278 = load ptr, ptr %l0, !tbaa !29
  %t279 = load i32, ptr %l18, !tbaa !23
  %t282 = call i64 @compiler_2flower_2ecompiler_2flower_3alowering_2efixedLen(ptr %v0, ptr %t278, i32 %t279)
  store i64 %t282, ptr %l150
  br label %bb67
bb66:
  store i1 false, ptr %l147, !tbaa !21
  br label %bb68
bb67:
  %t283 = load i64, ptr %l150, !tbaa !24
  %t284 = icmp sge i64 %t283, 0
  store i1 %t284, ptr %l147, !tbaa !21
  br label %bb68
bb68:
  %t286 = load i1, ptr %l147, !tbaa !21
  br i1 %t286, label %bb69, label %bb70
bb69:
  %t287 = load ptr, ptr %l0, !tbaa !29
  %t288 = load ptr, ptr %l1, !tbaa !29
  %t290 = getelementptr %"compiler/typed:Promote", ptr %t288, i32 0, i32 1
  %t291 = load i32, ptr %t290, !tbaa !23
  %t294 = call { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ebuilt(ptr %v0, ptr %t287, i32 %t291)
  store { i64, [1 x i64] } %t294, ptr %l155
  br label %bb71
bb70:
  br label %bb77
bb71:
  %t295 = load { i64, [1 x i64] }, ptr %l155
  store { i64, [1 x i64] } %t295, ptr %l19
  %t296 = load ptr, ptr %l17, !tbaa !29
  %t298 = getelementptr %"compiler/typed:Make", ptr %t296, i32 0, i32 0
  %t299 = load i32, ptr %t298
  %t301 = trunc i64 3 to i32
  %t302 = icmp eq i32 %t299, %t301
  br i1 %t302, label %bb72, label %bb73
bb72:
  %t304 = load ptr, ptr %l0, !tbaa !29
  %t305 = load ptr, ptr %l17, !tbaa !29
  %t306 = load i32, ptr %l2, !tbaa !23
  %t307 = load %"compiler/source:Span", ptr %l3
  %t308 = load { i64, [1 x i64] }, ptr %l19
  %t314 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2efill(ptr %v0, ptr %v1, ptr %t304, ptr %t305, i32 %t306, %"compiler/source:Span" %t307, i1 true, { i64, [1 x i64] } %t308)
  store { i64, [4 x i64] } %t314, ptr %l165
  br label %bb74
bb73:
  %t315 = load ptr, ptr %l0, !tbaa !29
  %t316 = load ptr, ptr %l17, !tbaa !29
  %t317 = load i32, ptr %l2, !tbaa !23
  %t318 = load %"compiler/source:Span", ptr %l3
  %t319 = load { i64, [1 x i64] }, ptr %l19
  %t325 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2earrayLit(ptr %v0, ptr %v1, ptr %t315, ptr %t316, i32 %t317, %"compiler/source:Span" %t318, i1 true, { i64, [1 x i64] } %t319)
  store { i64, [4 x i64] } %t325, ptr %l171
  br label %bb75
bb74:
  %t326 = load { i64, [4 x i64] }, ptr %l165
  store { i64, [4 x i64] } %t326, ptr %l159
  br label %bb76
bb75:
  %t327 = load { i64, [4 x i64] }, ptr %l171
  store { i64, [4 x i64] } %t327, ptr %l159
  br label %bb76
bb76:
  %t328 = load { i64, [4 x i64] }, ptr %l159
  store { i64, [4 x i64] } %t328, ptr %rv
  br label %ret
bb77:
  br label %bb83
bb78:
  br i1 true, label %bb79, label %bb80
bb79:
  br label %bb81
bb80:
  br label %bb82
bb81:
  br label %bb83
bb82:
  call void @__olang_check_failed(ptr @olang_loc_f5162d6fd39a8c0b_7722e13858f6fdef)
  unreachable
bb83:
  br label %bb84
bb84:
  br label %bb90
bb85:
  br i1 true, label %bb86, label %bb87
bb86:
  br label %bb88
bb87:
  br label %bb89
bb88:
  br label %bb90
bb89:
  call void @__olang_check_failed(ptr @olang_loc_3c6cf9f7cb6c21ca_21635d3489f6812e)
  unreachable
bb90:
  br label %bb91
bb91:
  %t329 = load ptr, ptr %l0, !tbaa !29
  %t330 = load ptr, ptr %l1, !tbaa !29
  %t332 = getelementptr %"compiler/typed:Promote", ptr %t330, i32 0, i32 0
  %t333 = load ptr, ptr %t332, !tbaa !29
  %t337 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v1, ptr %t329, ptr %t333)
  store { i64, [4 x i64] } %t337, ptr %l176
  br label %bb92
bb92:
  %t338 = load { i64, [4 x i64] }, ptr %l176
  store { i64, [4 x i64] } %t338, ptr %l20
  %t339 = load ptr, ptr %l0, !tbaa !29
  %t341 = getelementptr %"compiler/lower:lowering", ptr %t339, i32 0, i32 7
  %t342 = load i1, ptr %t341, !tbaa !21
  br i1 %t342, label %bb93, label %bb94
bb93:
  store { i64, [4 x i64] } zeroinitializer, ptr %t344
  %t345 = getelementptr { i64, [4 x i64] }, ptr %t344, i32 0, i32 0
  store i64 0, ptr %t345
  %t346 = load { i64, [4 x i64] }, ptr %t344
  store { i64, [4 x i64] } %t346, ptr %rv
  br label %ret
bb94:
  br label %bb95
bb95:
  %t348 = load ptr, ptr %l0, !tbaa !29
  %t349 = load ptr, ptr %l1, !tbaa !29
  %t351 = getelementptr %"compiler/typed:Promote", ptr %t349, i32 0, i32 1
  %t352 = load i32, ptr %t351, !tbaa !23
  %t355 = call { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ebuilt(ptr %v0, ptr %t348, i32 %t352)
  store { i64, [1 x i64] } %t355, ptr %l183
  br label %bb96
bb96:
  %t356 = load { i64, [1 x i64] }, ptr %l183
  store { i64, [1 x i64] } %t356, ptr %l21
  %t357 = load ptr, ptr %l0, !tbaa !29
  %t358 = load i32, ptr %l2, !tbaa !23
  %t359 = load { i64, [1 x i64] }, ptr %l21
  %t360 = load { i64, [4 x i64] }, ptr %l20
  %t361 = load i32, ptr %l2, !tbaa !23
  store { i64, [15 x i64] } zeroinitializer, ptr %t362
  %t363 = getelementptr { i64, [15 x i64] }, ptr %t362, i32 0, i32 0
  store i64 7, ptr %t363
  %t365 = insertvalue { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 } undef, { i64, [1 x i64] } %t359, 0
  %t367 = insertvalue { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 } %t365, { i64, [4 x i64] } %t360, 1
  %t369 = insertvalue { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 } %t367, i32 %t361, 2
  %t370 = getelementptr { i64, [15 x i64] }, ptr %t362, i32 0, i32 1
  store { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 } %t369, ptr %t370
  %t371 = load { i64, [15 x i64] }, ptr %t362
  %t372 = load %"compiler/source:Span", ptr %l3
  %t377 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %t357, i32 %t358, { i64, [15 x i64] } %t371, %"compiler/source:Span" %t372)
  store { i64, [4 x i64] } %t377, ptr %l191
  br label %bb97
bb97:
  %t378 = load { i64, [4 x i64] }, ptr %l191
  store { i64, [4 x i64] } %t378, ptr %l22
  %t379 = load ptr, ptr %l0, !tbaa !29
  %t381 = getelementptr %"compiler/lower:lowering", ptr %t379, i32 0, i32 2
  %t382 = load ptr, ptr %t381, !tbaa !29
  store ptr %t382, ptr %l23, !tbaa !29
  %t384 = load ptr, ptr %l23, !tbaa !29
  %t385 = load i32, ptr %l2, !tbaa !23
  %t388 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t384, i32 %t385)
  store i1 %t388, ptr %l196
  br label %bb98
bb98:
  %t389 = load i1, ptr %l196, !tbaa !21
  br i1 %t389, label %bb99, label %bb100
bb99:
  %t390 = load ptr, ptr %l23, !tbaa !29
  store ptr %t390, ptr %l198, !tbaa !29
  %t391 = load ptr, ptr %l23, !tbaa !29
  %t392 = load i32, ptr %l2, !tbaa !23
  %t395 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t391, i32 %t392)
  store i32 %t395, ptr %l201
  br label %bb101
bb100:
  store i1 false, ptr %l197, !tbaa !21
  br label %bb103
bb101:
  %t396 = load ptr, ptr %l198, !tbaa !29
  %t397 = load i32, ptr %l201, !tbaa !23
  %t398 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t396, i32 %t397)
  store i32 %t398, ptr %l202
  br label %bb102
bb102:
  %t399 = load i32, ptr %l202
  %t401 = trunc i64 18 to i32
  %t402 = icmp eq i32 %t399, %t401
  store i1 %t402, ptr %l197, !tbaa !21
  br label %bb103
bb103:
  %t404 = load i1, ptr %l197, !tbaa !21
  br i1 %t404, label %bb104, label %bb105
bb104:
  %t405 = load ptr, ptr %l23, !tbaa !29
  store ptr %t405, ptr %l206, !tbaa !29
  %t406 = load ptr, ptr %l23, !tbaa !29
  %t407 = load i32, ptr %l2, !tbaa !23
  %t410 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t406, i32 %t407)
  store i32 %t410, ptr %l209
  br label %bb106
bb105:
  store i1 false, ptr %l205, !tbaa !21
  br label %bb108
bb106:
  %t411 = load ptr, ptr %l206, !tbaa !29
  %t412 = load i32, ptr %l209, !tbaa !23
  %t413 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %t411, i32 %t412)
  store i1 %t413, ptr %l210
  br label %bb107
bb107:
  %t414 = load i1, ptr %l210, !tbaa !21
  store i1 %t414, ptr %l205, !tbaa !21
  br label %bb108
bb108:
  %t415 = load i1, ptr %l205, !tbaa !21
  br i1 %t415, label %bb109, label %bb110
bb109:
  %t416 = load ptr, ptr %l23, !tbaa !29
  store ptr %t416, ptr %l212, !tbaa !29
  %t417 = load ptr, ptr %l23, !tbaa !29
  %t418 = load i32, ptr %l2, !tbaa !23
  %t421 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t417, i32 %t418)
  store i32 %t421, ptr %l215
  br label %bb111
bb110:
  store i1 false, ptr %l211, !tbaa !21
  br label %bb113
bb111:
  %t422 = load ptr, ptr %l212, !tbaa !29
  %t423 = load i32, ptr %l215, !tbaa !23
  %t424 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDestructs(ptr %v0, ptr %t422, i32 %t423)
  store i1 %t424, ptr %l216
  br label %bb112
bb112:
  %t425 = load i1, ptr %l216, !tbaa !21
  store i1 %t425, ptr %l211, !tbaa !21
  br label %bb113
bb113:
  %t426 = load i1, ptr %l211, !tbaa !21
  br i1 %t426, label %bb114, label %bb115
bb114:
  store %olang.scope zeroinitializer, ptr %s11
  %t427 = load ptr, ptr %l0, !tbaa !29
  store ptr %t427, ptr %l217, !tbaa !29
  %t428 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t428, ptr %l218
  %t429 = load { i64, [1 x i64] }, ptr %l21
  store { i64, [1 x i64] } %t429, ptr %l219
  %t430 = load ptr, ptr %l23, !tbaa !29
  %t431 = load i32, ptr %l2, !tbaa !23
  %t434 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t430, i32 %t431)
  store i32 %t434, ptr %l222
  br label %bb116
bb115:
  br label %bb118
bb116:
  %t435 = load { i64, [4 x i64] }, ptr %l22
  store { i64, [21 x i64] } zeroinitializer, ptr %t436
  %t437 = getelementptr { i64, [21 x i64] }, ptr %t436, i32 0, i32 0
  store i64 6, ptr %t437
  %t438 = load %"compiler/source:Span", ptr %l218
  %t439 = insertvalue { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } undef, %"compiler/source:Span" %t438, 0
  %t440 = load { i64, [1 x i64] }, ptr %l219
  %t441 = insertvalue { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } %t439, { i64, [1 x i64] } %t440, 1
  %t442 = load i32, ptr %l222, !tbaa !23
  %t443 = insertvalue { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } %t441, i32 %t442, 2
  %t445 = insertvalue { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } %t443, { i64, [4 x i64] } %t435, 3
  %t446 = getelementptr { i64, [21 x i64] }, ptr %t436, i32 0, i32 1
  store { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } %t445, ptr %t446
  %t447 = load { i64, [21 x i64] }, ptr %t436
  %t449 = call ptr @__olang_scope_alloc_a(ptr %s11, i64 176, i64 8)
  store { i64, [21 x i64] } %t447, ptr %t449
  %t450 = load ptr, ptr %l217, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s11, ptr %t450, ptr %t449)
  br label %bb117
bb117:
  call void @__olang_scope_close(ptr %s11)
  br label %bb118
bb118:
  %t452 = load { i64, [4 x i64] }, ptr %l22
  store { i64, [4 x i64] } %t452, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2eraise(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, { i64, [4 x i64] } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l4 = alloca i1
  %l6 = alloca ptr
  %l12 = alloca i32
  %l13 = alloca { i64, ptr }
  %l25 = alloca i32
  %l32 = alloca ptr
  %l33 = alloca %"compiler/source:Span"
  %l35 = alloca %"compiler/mir:Place"
  %t29 = alloca { i64, [4 x i64] }, align 8
  %t32 = alloca { i64, [7 x i64] }, align 8
  %t74 = alloca { i64, [4 x i64] }, align 8
  %t80 = alloca { i64, [7 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l6, !tbaa !29
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/lower:lowering", ptr %t5, i32 0, i32 2
  %t8 = load ptr, ptr %t7, !tbaa !29
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/lower:lowering", ptr %t9, i32 0, i32 1
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t14 = getelementptr %"compiler/typed:Body", ptr %t12, i32 0, i32 2
  %t15 = load i32, ptr %t14, !tbaa !23
  %t18 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t8, i32 %t15)
  store i32 %t18, ptr %l12
  br label %bb1
bb1:
  %t19 = load ptr, ptr %l6, !tbaa !29
  %t20 = load i32, ptr %l12, !tbaa !23
  %t21 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t19, i32 %t20)
  store { i64, ptr } %t21, ptr %l13
  br label %bb2
bb2:
  %t22 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t22, 0
  %t25 = icmp eq i64 %t23, 0
  br i1 %t25, label %bb3, label %bb4
bb3:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load %"compiler/source:Span", ptr %l1
  store { i64, [4 x i64] } zeroinitializer, ptr %t29
  %t30 = getelementptr { i64, [4 x i64] }, ptr %t29, i32 0, i32 0
  store i64 0, ptr %t30
  %t31 = load { i64, [4 x i64] }, ptr %t29
  store { i64, [7 x i64] } zeroinitializer, ptr %t32
  %t33 = getelementptr { i64, [7 x i64] }, ptr %t32, i32 0, i32 0
  store i64 8, ptr %t33
  %t35 = insertvalue { %"compiler/source:Span", i32, { i64, [4 x i64] } } undef, %"compiler/source:Span" %t28, 0
  %t37 = insertvalue { %"compiler/source:Span", i32, { i64, [4 x i64] } } %t35, i32 3, 1
  %t39 = insertvalue { %"compiler/source:Span", i32, { i64, [4 x i64] } } %t37, { i64, [4 x i64] } %t31, 2
  %t40 = getelementptr { i64, [7 x i64] }, ptr %t32, i32 0, i32 1
  store { %"compiler/source:Span", i32, { i64, [4 x i64] } } %t39, ptr %t40
  %t41 = load { i64, [7 x i64] }, ptr %t32
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t27, { i64, [7 x i64] } %t41)
  br label %bb5
bb4:
  br label %bb6
bb5:
  br label %ret
bb6:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = load i32, ptr @G_2ecompiler_2fmir_2eI32T, !tbaa !23
  %t47 = load %"compiler/source:Span", ptr %l1
  %t52 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2elocal(ptr %v0, ptr %t44, { i64, [4 x i64] } %a2, i32 %t46, %"compiler/source:Span" %t47)
  store i32 %t52, ptr %l25
  br label %bb7
bb7:
  %t53 = load i32, ptr %l25, !tbaa !23
  store i32 %t53, ptr %l3, !tbaa !23
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/lower:lowering", ptr %t54, i32 0, i32 18
  %t57 = load i1, ptr %t56, !tbaa !21
  store i1 %t57, ptr %l4, !tbaa !21
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/lower:lowering", ptr %t59, i32 0, i32 18
  store i1 true, ptr %t61, !tbaa !21
  %t62 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eleave(ptr %v0, ptr %t62, i64 0)
  br label %bb8
bb8:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t65 = load i1, ptr %l4, !tbaa !21
  %t68 = getelementptr %"compiler/lower:lowering", ptr %t64, i32 0, i32 18
  store i1 %t65, ptr %t68, !tbaa !21
  %t69 = load ptr, ptr %l0, !tbaa !29
  store ptr %t69, ptr %l32, !tbaa !29
  %t70 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t70, ptr %l33
  %t71 = load i32, ptr %l3, !tbaa !23
  %t73 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t71)
  store %"compiler/mir:Place" %t73, ptr %l35
  br label %bb9
bb9:
  store { i64, [4 x i64] } zeroinitializer, ptr %t74
  %t75 = getelementptr { i64, [4 x i64] }, ptr %t74, i32 0, i32 0
  store i64 1, ptr %t75
  %t76 = load %"compiler/mir:Place", ptr %l35
  %t77 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t76, 0
  %t78 = getelementptr { i64, [4 x i64] }, ptr %t74, i32 0, i32 1
  store { %"compiler/mir:Place" } %t77, ptr %t78
  %t79 = load { i64, [4 x i64] }, ptr %t74
  store { i64, [7 x i64] } zeroinitializer, ptr %t80
  %t81 = getelementptr { i64, [7 x i64] }, ptr %t80, i32 0, i32 0
  store i64 6, ptr %t81
  %t82 = load %"compiler/source:Span", ptr %l33
  %t83 = insertvalue { %"compiler/source:Span", { i64, [4 x i64] } } undef, %"compiler/source:Span" %t82, 0
  %t85 = insertvalue { %"compiler/source:Span", { i64, [4 x i64] } } %t83, { i64, [4 x i64] } %t79, 1
  %t86 = getelementptr { i64, [7 x i64] }, ptr %t80, i32 0, i32 1
  store { %"compiler/source:Span", { i64, [4 x i64] } } %t85, ptr %t86
  %t87 = load { i64, [7 x i64] }, ptr %t80
  %t88 = load ptr, ptr %l32, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t88, { i64, [7 x i64] } %t87)
  br label %bb10
bb10:
  br label %ret
ret:
  ret void
}

define dso_local { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eread(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca %"compiler/lower:pl"
  %l8 = alloca %"compiler/lower:pl"
  %l12 = alloca ptr
  %l13 = alloca i32
  %l16 = alloca %"compiler/mir:Place"
  %l20 = alloca { i64, [4 x i64] }
  %rv = alloca { i64, [4 x i64] }
  %t13 = alloca { i64, [4 x i64] }, align 8
  %t24 = alloca { i64, [4 x i64] }, align 8
  %t30 = alloca { i64, [15 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t6 = call %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2eplace(ptr %v0, ptr %v1, ptr %v0, ptr %t1, ptr %a1)
  store %"compiler/lower:pl" %t6, ptr %l8
  br label %bb1
bb1:
  %t7 = load %"compiler/lower:pl", ptr %l8
  store %"compiler/lower:pl" %t7, ptr %l4
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/lower:lowering", ptr %t8, i32 0, i32 7
  %t11 = load i1, ptr %t10, !tbaa !21
  br i1 %t11, label %bb2, label %bb3
bb2:
  store { i64, [4 x i64] } zeroinitializer, ptr %t13
  %t14 = getelementptr { i64, [4 x i64] }, ptr %t13, i32 0, i32 0
  store i64 0, ptr %t14
  %t15 = load { i64, [4 x i64] }, ptr %t13
  store { i64, [4 x i64] } %t15, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t17 = load ptr, ptr %l0, !tbaa !29
  store ptr %t17, ptr %l12, !tbaa !29
  store i32 %a2, ptr %l13, !tbaa !23
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t20 = load %"compiler/lower:pl", ptr %l4
  %t23 = call %"compiler/mir:Place" @compiler_2flower_2ecompiler_2flower_3alowering_2emk(ptr %v0, ptr %v0, ptr %t19, %"compiler/lower:pl" %t20)
  store %"compiler/mir:Place" %t23, ptr %l16
  br label %bb5
bb5:
  store { i64, [4 x i64] } zeroinitializer, ptr %t24
  %t25 = getelementptr { i64, [4 x i64] }, ptr %t24, i32 0, i32 0
  store i64 1, ptr %t25
  %t26 = load %"compiler/mir:Place", ptr %l16
  %t27 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t26, 0
  %t28 = getelementptr { i64, [4 x i64] }, ptr %t24, i32 0, i32 1
  store { %"compiler/mir:Place" } %t27, ptr %t28
  %t29 = load { i64, [4 x i64] }, ptr %t24
  store { i64, [15 x i64] } zeroinitializer, ptr %t30
  %t31 = getelementptr { i64, [15 x i64] }, ptr %t30, i32 0, i32 0
  store i64 0, ptr %t31
  %t33 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t29, 0
  %t34 = getelementptr { i64, [15 x i64] }, ptr %t30, i32 0, i32 1
  store { { i64, [4 x i64] } } %t33, ptr %t34
  %t35 = load { i64, [15 x i64] }, ptr %t30
  %t37 = load ptr, ptr %l12, !tbaa !29
  %t38 = load i32, ptr %l13, !tbaa !23
  %t41 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %t37, i32 %t38, { i64, [15 x i64] } %t35, %"compiler/source:Span" %a3)
  store { i64, [4 x i64] } %t41, ptr %l20
  br label %bb6
bb6:
  %t42 = load { i64, [4 x i64] }, ptr %l20
  store { i64, [4 x i64] } %t42, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local i32 @compiler_2flower_2ecompiler_2flower_3alowering_2ereadOnly(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l1 = alloca i32
  %l2 = alloca ptr
  %l7 = alloca i1
  %l8 = alloca ptr
  %l11 = alloca i32
  %l14 = alloca i64
  %l18 = alloca i32
  %rv = alloca i32
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/lower:lowering", ptr %a0, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t7 = load i32, ptr %l1, !tbaa !23
  %t10 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t6, i32 %t7)
  store i1 %t10, ptr %l7
  br label %bb1
bb1:
  %t11 = load i1, ptr %l7, !tbaa !21
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t12 = load ptr, ptr %l2, !tbaa !29
  store ptr %t12, ptr %l8, !tbaa !29
  %t13 = load ptr, ptr %l2, !tbaa !29
  %t14 = load i32, ptr %l1, !tbaa !23
  %t17 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t13, i32 %t14)
  store i32 %t17, ptr %l11
  br label %bb4
bb3:
  br label %bb7
bb4:
  %t18 = load ptr, ptr %l2, !tbaa !29
  %t19 = load i32, ptr %l1, !tbaa !23
  %t22 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t18, i32 %t19)
  store i64 %t22, ptr %l14
  br label %bb5
bb5:
  %t23 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t25 = sub i64 -1, %t23
  %t26 = load i64, ptr %l14, !tbaa !24
  %t28 = and i64 %t26, %t25
  %t29 = load ptr, ptr %l8, !tbaa !29
  %t30 = load i32, ptr %l11, !tbaa !23
  %t32 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t29, i32 %t30, i64 %t28)
  store i32 %t32, ptr %l18
  br label %bb6
bb6:
  %t33 = load i32, ptr %l18, !tbaa !23
  store i32 %t33, ptr %rv
  br label %ret
bb7:
  %t34 = load i32, ptr %l1, !tbaa !23
  store i32 %t34, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2erefTo(ptr %v0, ptr %v1, ptr %a0, %"compiler/lower:pl" %a1, i32 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca i32
  %l9 = alloca i32
  %l10 = alloca ptr
  %l11 = alloca i32
  %l14 = alloca %"compiler/mir:Place"
  %l18 = alloca { i64, [4 x i64] }
  %rv = alloca { i64, [4 x i64] }
  %t20 = alloca { i64, [15 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t4, i32 %a2, i64 %t6)
  store i32 %t10, ptr %l9
  br label %bb1
bb1:
  %t11 = load i32, ptr %l9, !tbaa !23
  store i32 %t11, ptr %l4, !tbaa !23
  %t12 = load ptr, ptr %l0, !tbaa !29
  store ptr %t12, ptr %l10, !tbaa !29
  %t13 = load i32, ptr %l4, !tbaa !23
  store i32 %t13, ptr %l11, !tbaa !23
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t18 = call %"compiler/mir:Place" @compiler_2flower_2ecompiler_2flower_3alowering_2emk(ptr %v0, ptr %v1, ptr %t14, %"compiler/lower:pl" %a1)
  store %"compiler/mir:Place" %t18, ptr %l14
  br label %bb2
bb2:
  %t19 = load i32, ptr %l4, !tbaa !23
  store { i64, [15 x i64] } zeroinitializer, ptr %t20
  %t21 = getelementptr { i64, [15 x i64] }, ptr %t20, i32 0, i32 0
  store i64 1, ptr %t21
  %t22 = load %"compiler/mir:Place", ptr %l14
  %t23 = insertvalue { %"compiler/mir:Place", i32 } undef, %"compiler/mir:Place" %t22, 0
  %t25 = insertvalue { %"compiler/mir:Place", i32 } %t23, i32 %t19, 1
  %t26 = getelementptr { i64, [15 x i64] }, ptr %t20, i32 0, i32 1
  store { %"compiler/mir:Place", i32 } %t25, ptr %t26
  %t27 = load { i64, [15 x i64] }, ptr %t20
  %t29 = load ptr, ptr %l10, !tbaa !29
  %t30 = load i32, ptr %l11, !tbaa !23
  %t33 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %t29, i32 %t30, { i64, [15 x i64] } %t27, %"compiler/source:Span" %a3)
  store { i64, [4 x i64] } %t33, ptr %l18
  br label %bb3
bb3:
  %t34 = load { i64, [4 x i64] }, ptr %l18
  store { i64, [4 x i64] } %t34, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2erender(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1, { i64, [4 x i64] } %a2, i32 %a3, %"compiler/source:Span" %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [1 x i64] }
  %l2 = alloca { i64, [4 x i64] }
  %l3 = alloca i32
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i1
  %l9 = alloca i32
  %l10 = alloca { i64, [4 x i64] }
  %l11 = alloca { i64, [7 x i64] }
  %l12 = alloca i32
  %l19 = alloca i1
  %l22 = alloca ptr
  %l25 = alloca i32
  %l26 = alloca i1
  %l34 = alloca i32
  %l38 = alloca i1
  %l41 = alloca i1
  %l49 = alloca i1
  %l53 = alloca i1
  %l57 = alloca i1
  %l61 = alloca i1
  %l75 = alloca i32
  %l79 = alloca i32
  %l80 = alloca ptr
  %l81 = alloca ptr
  %l84 = alloca i32
  %l85 = alloca { i64, ptr }
  %l86 = alloca { i64, ptr }
  %l87 = alloca i32
  %l92 = alloca i32
  %l93 = alloca %"compiler/mir:Place"
  %l94 = alloca ptr
  %l97 = alloca i32
  %l98 = alloca { i64, ptr }
  %l99 = alloca { i64, ptr }
  %l103 = alloca { i64, [4 x i64] }
  %l116 = alloca i32
  %l118 = alloca ptr
  %l119 = alloca { i64, [7 x i64] }
  %l121 = alloca ptr
  %l122 = alloca { i64, [4 x i64] }
  %l124 = alloca { i64, [4 x i64] }
  %l125 = alloca { i64, ptr }
  %l126 = alloca %"compiler/mir:Range"
  %l130 = alloca { i64, ptr }
  %l131 = alloca %"compiler/mir:Range"
  %l136 = alloca %"compiler/mir:Call"
  %l137 = alloca i32
  %s0 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %t100 = alloca { i64, [21 x i64] }, align 8
  %t173 = alloca { i64, [15 x i64] }, align 8
  %t189 = alloca { i64, [2 x i64] }, align 8
  %t198 = alloca { i64, [7 x i64] }, align 8
  %t212 = alloca { i64, [2 x i64] }, align 8
  %t288 = alloca { i64, [7 x i64] }, align 8
  store ptr %a0, ptr %l0
  store { i64, [1 x i64] } %a1, ptr %l1
  store { i64, [4 x i64] } %a2, ptr %l2
  store i32 %a3, ptr %l3
  store %"compiler/source:Span" %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l5, !tbaa !29
  %t6 = load i32, ptr %l3, !tbaa !23
  %t7 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t10 = icmp eq i32 %t6, %t7
  br i1 %t10, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l19, !tbaa !21
  br label %bb3
bb2:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/lower:lowering", ptr %t12, i32 0, i32 8
  %t15 = load i1, ptr %t14, !tbaa !21
  store i1 %t15, ptr %l19, !tbaa !21
  br label %bb3
bb3:
  %t17 = load i1, ptr %l19, !tbaa !21
  br i1 %t17, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb5:
  br label %bb6
bb6:
  %t18 = load ptr, ptr %l5, !tbaa !29
  store ptr %t18, ptr %l22, !tbaa !29
  %t19 = load ptr, ptr %l5, !tbaa !29
  %t20 = load i32, ptr %l3, !tbaa !23
  %t23 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t19, i32 %t20)
  store i32 %t23, ptr %l25
  br label %bb7
bb7:
  %t24 = load ptr, ptr %l22, !tbaa !29
  %t25 = load i32, ptr %l25, !tbaa !23
  %t26 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsAny(ptr %v0, ptr %t24, i32 %t25)
  store i1 %t26, ptr %l26
  br label %bb8
bb8:
  %t27 = load i1, ptr %l26, !tbaa !21
  br i1 %t27, label %bb9, label %bb10
bb9:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load { i64, [1 x i64] }, ptr %l1
  %t30 = load { i64, [4 x i64] }, ptr %l2
  %t31 = load i32, ptr %l3, !tbaa !23
  %t32 = load %"compiler/source:Span", ptr %l4
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2erenderAny(ptr %v0, ptr %t28, { i64, [1 x i64] } %t29, { i64, [4 x i64] } %t30, i32 %t31, i1 true, %"compiler/source:Span" %t32)
  br label %bb11
bb10:
  br label %bb12
bb11:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb12:
  %t38 = load ptr, ptr %l5, !tbaa !29
  %t39 = load i32, ptr %l3, !tbaa !23
  %t42 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t38, i32 %t39)
  store i32 %t42, ptr %l34
  br label %bb13
bb13:
  %t43 = load i32, ptr %l34, !tbaa !23
  store i32 %t43, ptr %l6, !tbaa !23
  store i32 7, ptr %l7
  store i1 true, ptr %l8, !tbaa !21
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t46 = load i32, ptr %l3, !tbaa !23
  %t49 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2ehasStr(ptr %v0, ptr %t45, i32 %t46)
  store i1 %t49, ptr %l38
  br label %bb14
bb14:
  %t50 = load i1, ptr %l38, !tbaa !21
  br i1 %t50, label %bb15, label %bb16
bb15:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb40
bb16:
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t52 = load i32, ptr %l3, !tbaa !23
  %t55 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eisChar(ptr %v0, ptr %t51, i32 %t52)
  store i1 %t55, ptr %l41
  br label %bb17
bb17:
  %t56 = load i1, ptr %l41, !tbaa !21
  br i1 %t56, label %bb18, label %bb19
bb18:
  store i32 2, ptr %l7
  br label %bb39
bb19:
  %t58 = load i32, ptr %l6, !tbaa !23
  %t59 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t62 = icmp eq i32 %t58, %t59
  br i1 %t62, label %bb20, label %bb21
bb20:
  store i32 7, ptr %l7
  br label %bb38
bb21:
  %t65 = load ptr, ptr %l5, !tbaa !29
  %t66 = load i32, ptr %l6, !tbaa !23
  %t69 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %t65, i32 %t66)
  store i1 %t69, ptr %l49
  br label %bb22
bb22:
  %t70 = load i1, ptr %l49, !tbaa !21
  br i1 %t70, label %bb23, label %bb24
bb23:
  store i32 5, ptr %l7
  br label %bb37
bb24:
  %t72 = load ptr, ptr %l5, !tbaa !29
  %t73 = load i32, ptr %l6, !tbaa !23
  %t76 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %t72, i32 %t73)
  store i1 %t76, ptr %l53
  br label %bb25
bb25:
  %t77 = load i1, ptr %l53, !tbaa !21
  br i1 %t77, label %bb26, label %bb27
bb26:
  store i32 4, ptr %l7
  br label %bb36
bb27:
  %t79 = load ptr, ptr %l5, !tbaa !29
  %t80 = load i32, ptr %l6, !tbaa !23
  %t83 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %t79, i32 %t80)
  store i1 %t83, ptr %l57
  br label %bb28
bb28:
  %t84 = load i1, ptr %l57, !tbaa !21
  br i1 %t84, label %bb29, label %bb30
bb29:
  store i32 6, ptr %l7
  br label %bb35
bb30:
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t87 = load i32, ptr %l3, !tbaa !23
  %t90 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eisText(ptr %v0, ptr %t86, i32 %t87)
  store i1 %t90, ptr %l61
  br label %bb31
bb31:
  %t91 = load i1, ptr %l61, !tbaa !21
  br i1 %t91, label %bb32, label %bb33
bb32:
  store i32 0, ptr %l7
  br label %bb34
bb33:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb34
bb34:
  br label %bb35
bb35:
  br label %bb36
bb36:
  br label %bb37
bb37:
  br label %bb38
bb38:
  br label %bb39
bb39:
  br label %bb40
bb40:
  %t93 = load i1, ptr %l8, !tbaa !21
  br i1 %t93, label %bb41, label %bb42
bb41:
  store %olang.scope zeroinitializer, ptr %s17
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t96 = load %"compiler/source:Span", ptr %l4
  %t97 = load { i64, [1 x i64] }, ptr %l1
  %t98 = load i32, ptr %l7
  %t99 = load { i64, [4 x i64] }, ptr %l2
  store { i64, [21 x i64] } zeroinitializer, ptr %t100
  %t101 = getelementptr { i64, [21 x i64] }, ptr %t100, i32 0, i32 0
  store i64 9, ptr %t101
  %t103 = insertvalue { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } undef, %"compiler/source:Span" %t96, 0
  %t105 = insertvalue { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } %t103, { i64, [1 x i64] } %t97, 1
  %t107 = insertvalue { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } %t105, i32 %t98, 2
  %t109 = insertvalue { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } %t107, { i64, [4 x i64] } %t99, 3
  %t110 = getelementptr { i64, [21 x i64] }, ptr %t100, i32 0, i32 1
  store { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } %t109, ptr %t110
  %t111 = load { i64, [21 x i64] }, ptr %t100
  %t113 = call ptr @__olang_scope_alloc_a(ptr %s17, i64 176, i64 8)
  store { i64, [21 x i64] } %t111, ptr %t113
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s17, ptr %t95, ptr %t113)
  br label %bb43
bb42:
  br label %bb44
bb43:
  call void @__olang_scope_close(ptr %s17)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb44:
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t118 = getelementptr %"compiler/lower:lowering", ptr %t116, i32 0, i32 0
  %t119 = load ptr, ptr %t118, !tbaa !29
  %t120 = load i32, ptr %l3, !tbaa !23
  %t124 = call i32 @compiler_2flower_2ecompiler_2flower_3aLowerer_2ehelperTy(ptr %v0, ptr %t119, i32 0, i32 %t120)
  store i32 %t124, ptr %l75
  br label %bb45
bb45:
  %t125 = load i32, ptr %l75, !tbaa !23
  store i32 %t125, ptr %l3, !tbaa !23
  %t126 = load ptr, ptr %l5, !tbaa !29
  %t127 = load i32, ptr %l3, !tbaa !23
  %t131 = call i32 @compiler_2fmir_2eHelperType(ptr %v0, ptr %t126, i32 0, i32 %t127)
  store i32 %t131, ptr %l79
  br label %bb46
bb46:
  %t132 = load i32, ptr %l79, !tbaa !23
  store i32 %t132, ptr %l9, !tbaa !23
  %t133 = load ptr, ptr %l0, !tbaa !29
  store ptr %t133, ptr %l80, !tbaa !29
  %t134 = load ptr, ptr %l5, !tbaa !29
  store ptr %t134, ptr %l81, !tbaa !29
  %t135 = load ptr, ptr %l5, !tbaa !29
  %t136 = load i32, ptr %l9, !tbaa !23
  %t139 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t135, i32 %t136)
  store i32 %t139, ptr %l84
  br label %bb47
bb47:
  %t140 = load ptr, ptr %l81, !tbaa !29
  %t141 = load i32, ptr %l84, !tbaa !23
  %t142 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t140, i32 %t141)
  store { i64, ptr } %t142, ptr %l85
  br label %bb48
bb48:
  %t143 = load { i64, ptr }, ptr %l85, !tbaa !27
  store { i64, ptr } %t143, ptr %l86, !tbaa !27
  %t144 = getelementptr { i64, ptr }, ptr %l86, i32 0, i32 1
  %t145 = load ptr, ptr %t144, !tbaa !27
  %t146 = getelementptr i32, ptr %t145, i64 0
  %t147 = load i32, ptr %t146, !tbaa !33
  store i32 %t147, ptr %l87, !tbaa !23
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t149 = load { i64, [4 x i64] }, ptr %l2
  %t150 = load i32, ptr %l3, !tbaa !23
  %t151 = load %"compiler/source:Span", ptr %l4
  %t156 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2elocal(ptr %v0, ptr %t148, { i64, [4 x i64] } %t149, i32 %t150, %"compiler/source:Span" %t151)
  store i32 %t156, ptr %l92
  br label %bb49
bb49:
  %t157 = load i32, ptr %l92, !tbaa !23
  %t158 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t157)
  store %"compiler/mir:Place" %t158, ptr %l93
  br label %bb50
bb50:
  %t159 = load ptr, ptr %l5, !tbaa !29
  store ptr %t159, ptr %l94, !tbaa !29
  %t160 = load ptr, ptr %l5, !tbaa !29
  %t161 = load i32, ptr %l9, !tbaa !23
  %t164 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t160, i32 %t161)
  store i32 %t164, ptr %l97
  br label %bb51
bb51:
  %t165 = load ptr, ptr %l94, !tbaa !29
  %t166 = load i32, ptr %l97, !tbaa !23
  %t167 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t165, i32 %t166)
  store { i64, ptr } %t167, ptr %l98
  br label %bb52
bb52:
  %t168 = load { i64, ptr }, ptr %l98, !tbaa !27
  store { i64, ptr } %t168, ptr %l99, !tbaa !27
  %t169 = getelementptr { i64, ptr }, ptr %l99, i32 0, i32 1
  %t170 = load ptr, ptr %t169, !tbaa !27
  %t171 = getelementptr i32, ptr %t170, i64 0
  %t172 = load i32, ptr %t171, !tbaa !33
  store { i64, [15 x i64] } zeroinitializer, ptr %t173
  %t174 = getelementptr { i64, [15 x i64] }, ptr %t173, i32 0, i32 0
  store i64 1, ptr %t174
  %t175 = load %"compiler/mir:Place", ptr %l93
  %t176 = insertvalue { %"compiler/mir:Place", i32 } undef, %"compiler/mir:Place" %t175, 0
  %t178 = insertvalue { %"compiler/mir:Place", i32 } %t176, i32 %t172, 1
  %t179 = getelementptr { i64, [15 x i64] }, ptr %t173, i32 0, i32 1
  store { %"compiler/mir:Place", i32 } %t178, ptr %t179
  %t180 = load { i64, [15 x i64] }, ptr %t173
  %t181 = load %"compiler/source:Span", ptr %l4
  %t182 = load ptr, ptr %l80, !tbaa !29
  %t183 = load i32, ptr %l87, !tbaa !23
  %t186 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %t182, i32 %t183, { i64, [15 x i64] } %t180, %"compiler/source:Span" %t181)
  store { i64, [4 x i64] } %t186, ptr %l103
  br label %bb53
bb53:
  %t187 = load { i64, [4 x i64] }, ptr %l103
  store { i64, [4 x i64] } %t187, ptr %l10
  %t188 = load i32, ptr %l3, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t189
  %t190 = getelementptr { i64, [2 x i64] }, ptr %t189, i32 0, i32 0
  store i64 2, ptr %t190
  %t192 = insertvalue { i32, i32 } undef, i32 0, 0
  %t194 = insertvalue { i32, i32 } %t192, i32 %t188, 1
  %t195 = getelementptr { i64, [2 x i64] }, ptr %t189, i32 0, i32 1
  store { i32, i32 } %t194, ptr %t195
  %t196 = load { i64, [2 x i64] }, ptr %t189
  %t197 = load i32, ptr %l9, !tbaa !23
  store { i64, [7 x i64] } zeroinitializer, ptr %t198
  %t199 = getelementptr { i64, [7 x i64] }, ptr %t198, i32 0, i32 0
  store i64 0, ptr %t199
  %t201 = insertvalue { { i64, [2 x i64] }, i32 } undef, { i64, [2 x i64] } %t196, 0
  %t203 = insertvalue { { i64, [2 x i64] }, i32 } %t201, i32 %t197, 1
  %t204 = getelementptr { i64, [7 x i64] }, ptr %t198, i32 0, i32 1
  store { { i64, [2 x i64] }, i32 } %t203, ptr %t204
  %t205 = load { i64, [7 x i64] }, ptr %t198
  store { i64, [7 x i64] } %t205, ptr %l11
  %t207 = load ptr, ptr %l0, !tbaa !29
  %t209 = getelementptr %"compiler/lower:lowering", ptr %t207, i32 0, i32 0
  %t210 = load ptr, ptr %t209, !tbaa !29
  %t211 = load i32, ptr %l3, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t212
  %t213 = getelementptr { i64, [2 x i64] }, ptr %t212, i32 0, i32 0
  store i64 2, ptr %t213
  %t215 = insertvalue { i32, i32 } undef, i32 0, 0
  %t217 = insertvalue { i32, i32 } %t215, i32 %t211, 1
  %t218 = getelementptr { i64, [2 x i64] }, ptr %t212, i32 0, i32 1
  store { i32, i32 } %t217, ptr %t218
  %t219 = load { i64, [2 x i64] }, ptr %t212
  call void @compiler_2flower_2ecompiler_2flower_3aLowerer_2eWant(ptr %v0, ptr %t210, { i64, [2 x i64] } %t219)
  br label %bb54
bb54:
  %t222 = load ptr, ptr %l0, !tbaa !29
  %t224 = getelementptr %"compiler/lower:lowering", ptr %t222, i32 0, i32 3
  %t226 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t224)
  store i32 %t226, ptr %l116
  br label %bb55
bb55:
  %t227 = load i32, ptr %l116, !tbaa !23
  store i32 %t227, ptr %l12, !tbaa !23
  %t228 = load ptr, ptr %l0, !tbaa !29
  %t230 = getelementptr %"compiler/lower:lowering", ptr %t228, i32 0, i32 3
  store ptr %t230, ptr %l118, !tbaa !29
  %t231 = load { i64, [7 x i64] }, ptr %l11
  store { i64, [7 x i64] } %t231, ptr %l119
  %t232 = load ptr, ptr %l0, !tbaa !29
  %t234 = getelementptr %"compiler/lower:lowering", ptr %t232, i32 0, i32 3
  store ptr %t234, ptr %l121, !tbaa !29
  %t235 = load { i64, [4 x i64] }, ptr %l10
  store { i64, [4 x i64] } %t235, ptr %l122
  %t236 = load ptr, ptr %l0, !tbaa !29
  %t238 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2edepth(ptr %v0, ptr %t236)
  store { i64, [4 x i64] } %t238, ptr %l124
  br label %bb56
bb56:
  %t239 = mul i64 2, 40
  %t240 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t239)
  %t241 = insertvalue { i64, ptr } undef, i64 2, 0
  %t242 = insertvalue { i64, ptr } %t241, ptr %t240, 1
  store { i64, ptr } %t242, ptr %l125, !tbaa !27
  %t243 = load { i64, [4 x i64] }, ptr %l122
  %t244 = getelementptr { i64, ptr }, ptr %l125, i32 0, i32 1
  %t245 = load ptr, ptr %t244, !tbaa !27
  %t246 = getelementptr { i64, [4 x i64] }, ptr %t245, i64 0
  store { i64, [4 x i64] } %t243, ptr %t246
  %t247 = load { i64, [4 x i64] }, ptr %l124
  %t248 = getelementptr { i64, ptr }, ptr %l125, i32 0, i32 1
  %t249 = load ptr, ptr %t248, !tbaa !27
  %t250 = getelementptr { i64, [4 x i64] }, ptr %t249, i64 1
  store { i64, [4 x i64] } %t247, ptr %t250
  %t251 = load ptr, ptr %l121, !tbaa !29
  %t252 = load { i64, ptr }, ptr %l125, !tbaa !27
  %t253 = call %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eArgs(ptr %v0, ptr %s0, ptr %t251, { i64, ptr } %t252)
  store %"compiler/mir:Range" %t253, ptr %l126
  br label %bb57
bb57:
  %t254 = load ptr, ptr %l0, !tbaa !29
  %t256 = getelementptr %"compiler/lower:lowering", ptr %t254, i32 0, i32 3
  %t257 = load { i64, [1 x i64] }, ptr %l1
  %t258 = mul i64 1, 16
  %t259 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t258)
  %t260 = insertvalue { i64, ptr } undef, i64 1, 0
  %t261 = insertvalue { i64, ptr } %t260, ptr %t259, 1
  store { i64, ptr } %t261, ptr %l130, !tbaa !27
  %t263 = getelementptr { i64, ptr }, ptr %l130, i32 0, i32 1
  %t264 = load ptr, ptr %t263, !tbaa !27
  %t265 = getelementptr { i64, [1 x i64] }, ptr %t264, i64 0
  store { i64, [1 x i64] } %t257, ptr %t265
  %t267 = load { i64, ptr }, ptr %l130, !tbaa !27
  %t268 = call %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eScopeRefs(ptr %v0, ptr %s0, ptr %t256, { i64, ptr } %t267)
  store %"compiler/mir:Range" %t268, ptr %l131
  br label %bb58
bb58:
  %t269 = load %"compiler/mir:Place", ptr @G_2ecompiler_2fmir_2eNoPlace
  %t270 = load i32, ptr %l12, !tbaa !23
  %t271 = load i32, ptr @G_2ecompiler_2fmir_2eNoLocal, !tbaa !23
  %t272 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t273 = load { i64, [7 x i64] }, ptr %l119
  %t274 = load %"compiler/mir:Range", ptr %l126
  %t275 = load %"compiler/mir:Range", ptr %l131
  %t280 = call %"compiler/mir:Call" @compiler_2fmir_3aCall_2ector(ptr %s0, { i64, [7 x i64] } %t273, %"compiler/mir:Range" %t274, %"compiler/mir:Range" %t275, %"compiler/mir:Place" %t269, i1 false, i32 %t270, i32 %t271, i32 %t272)
  store %"compiler/mir:Call" %t280, ptr %l136
  br label %bb59
bb59:
  %t281 = load ptr, ptr %l118, !tbaa !29
  %t282 = load %"compiler/mir:Call", ptr %l136
  %t283 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddCall(ptr %v0, ptr %t281, %"compiler/mir:Call" %t282)
  store i32 %t283, ptr %l137
  br label %bb60
bb60:
  %t284 = load i32, ptr %l137, !tbaa !23
  %t285 = load ptr, ptr %l0, !tbaa !29
  %t286 = load %"compiler/source:Span", ptr %l4
  store { i64, [7 x i64] } zeroinitializer, ptr %t288
  %t289 = getelementptr { i64, [7 x i64] }, ptr %t288, i32 0, i32 0
  store i64 4, ptr %t289
  %t291 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t286, 0
  %t293 = insertvalue { %"compiler/source:Span", i32 } %t291, i32 %t284, 1
  %t294 = getelementptr { i64, [7 x i64] }, ptr %t288, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t293, ptr %t294
  %t295 = load { i64, [7 x i64] }, ptr %t288
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t285, { i64, [7 x i64] } %t295)
  br label %bb61
bb61:
  %t298 = load ptr, ptr %l0, !tbaa !29
  %t299 = load i32, ptr %l12, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t298, i32 %t299)
  br label %bb62
bb62:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2erenderAny(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1, { i64, [4 x i64] } %a2, i32 %a3, i1 %a4, %"compiler/source:Span" %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [1 x i64] }
  %l3 = alloca i32
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca ptr
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca { i64, [4 x i64] }
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca { i64, [4 x i64] }
  %l13 = alloca { i64, [4 x i64] }
  %l14 = alloca i32
  %l15 = alloca i32
  %l16 = alloca { i64, [4 x i64] }
  %l17 = alloca i32
  %l18 = alloca { i64, [7 x i64] }
  %l19 = alloca i32
  %l27 = alloca i32
  %l30 = alloca i32
  %l31 = alloca ptr
  %l34 = alloca i32
  %l35 = alloca i1
  %l36 = alloca ptr
  %l37 = alloca i32
  %l38 = alloca i32
  %l40 = alloca %"compiler/mir:Place"
  %l44 = alloca { i64, ptr }
  %l46 = alloca { i64, [4 x i64] }
  %l49 = alloca i32
  %l52 = alloca i32
  %l68 = alloca { i64, [4 x i64] }
  %l69 = alloca ptr
  %l70 = alloca i32
  %l71 = alloca i32
  %l72 = alloca { i64, [4 x i64] }
  %l74 = alloca { i64, [4 x i64] }
  %l75 = alloca { i64, ptr }
  %l77 = alloca { i64, [4 x i64] }
  %l80 = alloca i32
  %l83 = alloca i32
  %l98 = alloca ptr
  %l99 = alloca i32
  %l100 = alloca i32
  %l101 = alloca { i64, [4 x i64] }
  %l103 = alloca { i64, [4 x i64] }
  %l104 = alloca { i64, ptr }
  %l106 = alloca { i64, [4 x i64] }
  %l107 = alloca ptr
  %l108 = alloca i32
  %l109 = alloca ptr
  %l112 = alloca i32
  %l113 = alloca i32
  %l114 = alloca i32
  %l116 = alloca %"compiler/mir:Place"
  %l117 = alloca { i64, [4 x i64] }
  %l119 = alloca i64
  %l124 = alloca i32
  %l126 = alloca ptr
  %l127 = alloca { i64, [7 x i64] }
  %l129 = alloca ptr
  %l131 = alloca %"compiler/mir:Place"
  %l134 = alloca { i64, ptr }
  %l135 = alloca %"compiler/mir:Range"
  %l139 = alloca { i64, ptr }
  %l140 = alloca %"compiler/mir:Range"
  %l145 = alloca %"compiler/mir:Call"
  %l146 = alloca i32
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %t37 = alloca { i64, [4 x i64] }, align 8
  %t44 = alloca { i64, [4 x i64] }, align 8
  %t87 = alloca { i64, [7 x i64] }, align 8
  %t163 = alloca { i64, [7 x i64] }, align 8
  %t237 = alloca { i64, [4 x i64] }, align 8
  %t246 = alloca { i64, [7 x i64] }, align 8
  %t273 = alloca { i64, [4 x i64] }, align 8
  %t329 = alloca { i64, [7 x i64] }, align 8
  store ptr %a0, ptr %l0
  store { i64, [1 x i64] } %a1, ptr %l1
  store i32 %a3, ptr %l3
  store %"compiler/source:Span" %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l6, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = load i32, ptr %l3, !tbaa !23
  %t9 = load %"compiler/source:Span", ptr %l5
  %t14 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2elocal(ptr %v0, ptr %t6, { i64, [4 x i64] } %a2, i32 %t8, %"compiler/source:Span" %t9)
  store i32 %t14, ptr %l27
  br label %bb1
bb1:
  %t15 = load i32, ptr %l27, !tbaa !23
  store i32 %t15, ptr %l7, !tbaa !23
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/lower:lowering", ptr %t16, i32 0, i32 3
  %t20 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t18)
  store i32 %t20, ptr %l30
  br label %bb2
bb2:
  %t21 = load i32, ptr %l30, !tbaa !23
  store i32 %t21, ptr %l8, !tbaa !23
  %t22 = load ptr, ptr %l6, !tbaa !29
  store ptr %t22, ptr %l31, !tbaa !29
  %t23 = load ptr, ptr %l6, !tbaa !29
  %t24 = load i32, ptr %l3, !tbaa !23
  %t27 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t23, i32 %t24)
  store i32 %t27, ptr %l34
  br label %bb3
bb3:
  %t28 = load ptr, ptr %l31, !tbaa !29
  %t29 = load i32, ptr %l34, !tbaa !23
  %t30 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNullable(ptr %v0, ptr %t28, i32 %t29)
  store i1 %t30, ptr %l35
  br label %bb4
bb4:
  %t31 = load i1, ptr %l35, !tbaa !21
  br i1 %t31, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t32 = load ptr, ptr %l0, !tbaa !29
  store ptr %t32, ptr %l36, !tbaa !29
  store i32 14, ptr %l37
  %t33 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t33, ptr %l38, !tbaa !23
  %t34 = load i32, ptr %l7, !tbaa !23
  %t36 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t34)
  store %"compiler/mir:Place" %t36, ptr %l40
  br label %bb7
bb6:
  br label %bb16
bb7:
  store { i64, [4 x i64] } zeroinitializer, ptr %t37
  %t38 = getelementptr { i64, [4 x i64] }, ptr %t37, i32 0, i32 0
  store i64 1, ptr %t38
  %t39 = load %"compiler/mir:Place", ptr %l40
  %t40 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t39, 0
  %t41 = getelementptr { i64, [4 x i64] }, ptr %t37, i32 0, i32 1
  store { %"compiler/mir:Place" } %t40, ptr %t41
  %t42 = load { i64, [4 x i64] }, ptr %t37
  %t43 = load i32, ptr %l3, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t44
  %t45 = getelementptr { i64, [4 x i64] }, ptr %t44, i32 0, i32 0
  store i64 2, ptr %t45
  %t47 = insertvalue { i32, i64 } undef, i32 %t43, 0
  %t48 = insertvalue { i32, i64 } %t47, i64 0, 1
  %t49 = getelementptr { i64, [4 x i64] }, ptr %t44, i32 0, i32 1
  store { i32, i64 } %t48, ptr %t49
  %t50 = load { i64, [4 x i64] }, ptr %t44
  %t51 = mul i64 2, 40
  %t52 = call ptr @__olang_scope_alloc_zeroed(ptr %s1, i64 %t51)
  %t53 = insertvalue { i64, ptr } undef, i64 2, 0
  %t54 = insertvalue { i64, ptr } %t53, ptr %t52, 1
  store { i64, ptr } %t54, ptr %l44, !tbaa !27
  %t56 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t57 = load ptr, ptr %t56, !tbaa !27
  %t58 = getelementptr { i64, [4 x i64] }, ptr %t57, i64 0
  store { i64, [4 x i64] } %t42, ptr %t58
  %t60 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !27
  %t62 = getelementptr { i64, [4 x i64] }, ptr %t61, i64 1
  store { i64, [4 x i64] } %t50, ptr %t62
  %t63 = load %"compiler/source:Span", ptr %l5
  %t64 = load ptr, ptr %l36, !tbaa !29
  %t65 = load i32, ptr %l37
  %t66 = load i32, ptr %l38, !tbaa !23
  %t67 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t69 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s1, ptr %t64, i32 %t65, i32 %t66, { i64, ptr } %t67, %"compiler/source:Span" %t63)
  store { i64, [4 x i64] } %t69, ptr %l46
  br label %bb8
bb8:
  %t70 = load { i64, [4 x i64] }, ptr %l46
  store { i64, [4 x i64] } %t70, ptr %l9
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/lower:lowering", ptr %t71, i32 0, i32 3
  %t75 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t73)
  store i32 %t75, ptr %l49
  br label %bb9
bb9:
  %t76 = load i32, ptr %l49, !tbaa !23
  store i32 %t76, ptr %l10, !tbaa !23
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/lower:lowering", ptr %t77, i32 0, i32 3
  %t81 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t79)
  store i32 %t81, ptr %l52
  br label %bb10
bb10:
  %t82 = load i32, ptr %l52, !tbaa !23
  store i32 %t82, ptr %l11, !tbaa !23
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t84 = load { i64, [4 x i64] }, ptr %l9
  %t85 = load i32, ptr %l10, !tbaa !23
  %t86 = load i32, ptr %l11, !tbaa !23
  store { i64, [7 x i64] } zeroinitializer, ptr %t87
  %t88 = getelementptr { i64, [7 x i64] }, ptr %t87, i32 0, i32 0
  store i64 2, ptr %t88
  %t90 = insertvalue { { i64, [4 x i64] }, i32, i32 } undef, { i64, [4 x i64] } %t84, 0
  %t92 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t90, i32 %t85, 1
  %t94 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t92, i32 %t86, 2
  %t95 = getelementptr { i64, [7 x i64] }, ptr %t87, i32 0, i32 1
  store { { i64, [4 x i64] }, i32, i32 } %t94, ptr %t95
  %t96 = load { i64, [7 x i64] }, ptr %t87
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t83, { i64, [7 x i64] } %t96)
  br label %bb11
bb11:
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t100 = load i32, ptr %l11, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t99, i32 %t100)
  br label %bb12
bb12:
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t104 = load { i64, [1 x i64] }, ptr %l1
  %t105 = load %"compiler/source:Span", ptr %l5
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eword(ptr %v0, ptr %s1, ptr %t103, { i64, [1 x i64] } %t104, { i64, ptr } { i64 4, ptr @.d21 }, %"compiler/source:Span" %t105)
  br label %bb13
bb13:
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t110 = load i32, ptr %l8, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2egoto(ptr %v0, ptr %t109, i32 %t110)
  br label %bb14
bb14:
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t114 = load i32, ptr %l10, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t113, i32 %t114)
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s1)
  br label %bb16
bb16:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2edepth(ptr %v0, ptr %t117)
  store { i64, [4 x i64] } %t119, ptr %l68
  br label %bb17
bb17:
  %t120 = load { i64, [4 x i64] }, ptr %l68
  store { i64, [4 x i64] } %t120, ptr %l12
  %t121 = load ptr, ptr %l0, !tbaa !29
  store ptr %t121, ptr %l69, !tbaa !29
  store i32 18, ptr %l70
  %t122 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t122, ptr %l71, !tbaa !23
  %t123 = load { i64, [4 x i64] }, ptr %l12
  store { i64, [4 x i64] } %t123, ptr %l72
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t126 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2econstI64(ptr %v0, ptr %t124, i64 8)
  store { i64, [4 x i64] } %t126, ptr %l74
  br label %bb18
bb18:
  %t127 = mul i64 2, 40
  %t128 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t127)
  %t129 = insertvalue { i64, ptr } undef, i64 2, 0
  %t130 = insertvalue { i64, ptr } %t129, ptr %t128, 1
  store { i64, ptr } %t130, ptr %l75, !tbaa !27
  %t131 = load { i64, [4 x i64] }, ptr %l72
  %t132 = getelementptr { i64, ptr }, ptr %l75, i32 0, i32 1
  %t133 = load ptr, ptr %t132, !tbaa !27
  %t134 = getelementptr { i64, [4 x i64] }, ptr %t133, i64 0
  store { i64, [4 x i64] } %t131, ptr %t134
  %t135 = load { i64, [4 x i64] }, ptr %l74
  %t136 = getelementptr { i64, ptr }, ptr %l75, i32 0, i32 1
  %t137 = load ptr, ptr %t136, !tbaa !27
  %t138 = getelementptr { i64, [4 x i64] }, ptr %t137, i64 1
  store { i64, [4 x i64] } %t135, ptr %t138
  %t139 = load %"compiler/source:Span", ptr %l5
  %t140 = load ptr, ptr %l69, !tbaa !29
  %t141 = load i32, ptr %l70
  %t142 = load i32, ptr %l71, !tbaa !23
  %t143 = load { i64, ptr }, ptr %l75, !tbaa !27
  %t145 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s0, ptr %t140, i32 %t141, i32 %t142, { i64, ptr } %t143, %"compiler/source:Span" %t139)
  store { i64, [4 x i64] } %t145, ptr %l77
  br label %bb19
bb19:
  %t146 = load { i64, [4 x i64] }, ptr %l77
  store { i64, [4 x i64] } %t146, ptr %l13
  %t147 = load ptr, ptr %l0, !tbaa !29
  %t149 = getelementptr %"compiler/lower:lowering", ptr %t147, i32 0, i32 3
  %t151 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t149)
  store i32 %t151, ptr %l80
  br label %bb20
bb20:
  %t152 = load i32, ptr %l80, !tbaa !23
  store i32 %t152, ptr %l14, !tbaa !23
  %t153 = load ptr, ptr %l0, !tbaa !29
  %t155 = getelementptr %"compiler/lower:lowering", ptr %t153, i32 0, i32 3
  %t157 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t155)
  store i32 %t157, ptr %l83
  br label %bb21
bb21:
  %t158 = load i32, ptr %l83, !tbaa !23
  store i32 %t158, ptr %l15, !tbaa !23
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t160 = load { i64, [4 x i64] }, ptr %l13
  %t161 = load i32, ptr %l14, !tbaa !23
  %t162 = load i32, ptr %l15, !tbaa !23
  store { i64, [7 x i64] } zeroinitializer, ptr %t163
  %t164 = getelementptr { i64, [7 x i64] }, ptr %t163, i32 0, i32 0
  store i64 2, ptr %t164
  %t166 = insertvalue { { i64, [4 x i64] }, i32, i32 } undef, { i64, [4 x i64] } %t160, 0
  %t168 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t166, i32 %t161, 1
  %t170 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t168, i32 %t162, 2
  %t171 = getelementptr { i64, [7 x i64] }, ptr %t163, i32 0, i32 1
  store { { i64, [4 x i64] }, i32, i32 } %t170, ptr %t171
  %t172 = load { i64, [7 x i64] }, ptr %t163
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t159, { i64, [7 x i64] } %t172)
  br label %bb22
bb22:
  %t175 = load ptr, ptr %l0, !tbaa !29
  %t176 = load i32, ptr %l14, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t175, i32 %t176)
  br label %bb23
bb23:
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t180 = load { i64, [1 x i64] }, ptr %l1
  %t181 = load %"compiler/source:Span", ptr %l5
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eword(ptr %v0, ptr %s0, ptr %t179, { i64, [1 x i64] } %t180, { i64, ptr } { i64 3, ptr @.d22 }, %"compiler/source:Span" %t181)
  br label %bb24
bb24:
  %t185 = load ptr, ptr %l0, !tbaa !29
  %t186 = load i32, ptr %l8, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2egoto(ptr %v0, ptr %t185, i32 %t186)
  br label %bb25
bb25:
  %t189 = load ptr, ptr %l0, !tbaa !29
  %t190 = load i32, ptr %l15, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t189, i32 %t190)
  br label %bb26
bb26:
  %t193 = load ptr, ptr %l0, !tbaa !29
  store ptr %t193, ptr %l98, !tbaa !29
  store i32 3, ptr %l99
  %t194 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  store i32 %t194, ptr %l100, !tbaa !23
  %t195 = load { i64, [4 x i64] }, ptr %l12
  store { i64, [4 x i64] } %t195, ptr %l101
  %t196 = load ptr, ptr %l0, !tbaa !29
  %t198 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2econstI64(ptr %v0, ptr %t196, i64 1)
  store { i64, [4 x i64] } %t198, ptr %l103
  br label %bb27
bb27:
  %t199 = mul i64 2, 40
  %t200 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t199)
  %t201 = insertvalue { i64, ptr } undef, i64 2, 0
  %t202 = insertvalue { i64, ptr } %t201, ptr %t200, 1
  store { i64, ptr } %t202, ptr %l104, !tbaa !27
  %t203 = load { i64, [4 x i64] }, ptr %l101
  %t204 = getelementptr { i64, ptr }, ptr %l104, i32 0, i32 1
  %t205 = load ptr, ptr %t204, !tbaa !27
  %t206 = getelementptr { i64, [4 x i64] }, ptr %t205, i64 0
  store { i64, [4 x i64] } %t203, ptr %t206
  %t207 = load { i64, [4 x i64] }, ptr %l103
  %t208 = getelementptr { i64, ptr }, ptr %l104, i32 0, i32 1
  %t209 = load ptr, ptr %t208, !tbaa !27
  %t210 = getelementptr { i64, [4 x i64] }, ptr %t209, i64 1
  store { i64, [4 x i64] } %t207, ptr %t210
  %t211 = load %"compiler/source:Span", ptr %l5
  %t212 = load ptr, ptr %l98, !tbaa !29
  %t213 = load i32, ptr %l99
  %t214 = load i32, ptr %l100, !tbaa !23
  %t215 = load { i64, ptr }, ptr %l104, !tbaa !27
  %t217 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s0, ptr %t212, i32 %t213, i32 %t214, { i64, ptr } %t215, %"compiler/source:Span" %t211)
  store { i64, [4 x i64] } %t217, ptr %l106
  br label %bb28
bb28:
  %t218 = load { i64, [4 x i64] }, ptr %l106
  store { i64, [4 x i64] } %t218, ptr %l16
  %t219 = load ptr, ptr %l6, !tbaa !29
  store ptr %t219, ptr %l107, !tbaa !29
  store i32 0, ptr %l108
  %t220 = load ptr, ptr %l6, !tbaa !29
  store ptr %t220, ptr %l109, !tbaa !29
  %t221 = load ptr, ptr %l6, !tbaa !29
  %t222 = load i32, ptr %l3, !tbaa !23
  %t225 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t221, i32 %t222)
  store i32 %t225, ptr %l112
  br label %bb29
bb29:
  %t226 = load ptr, ptr %l109, !tbaa !29
  %t227 = load i32, ptr %l112, !tbaa !23
  %t228 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t226, i32 %t227)
  store i32 %t228, ptr %l113
  br label %bb30
bb30:
  %t229 = load ptr, ptr %l107, !tbaa !29
  %t230 = load i32, ptr %l108
  %t231 = load i32, ptr %l113, !tbaa !23
  %t232 = call i32 @compiler_2fmir_2eHelperType(ptr %v0, ptr %t229, i32 %t230, i32 %t231)
  store i32 %t232, ptr %l114
  br label %bb31
bb31:
  %t233 = load i32, ptr %l114, !tbaa !23
  store i32 %t233, ptr %l17, !tbaa !23
  %t234 = load i32, ptr %l7, !tbaa !23
  %t236 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t234)
  store %"compiler/mir:Place" %t236, ptr %l116
  br label %bb32
bb32:
  store { i64, [4 x i64] } zeroinitializer, ptr %t237
  %t238 = getelementptr { i64, [4 x i64] }, ptr %t237, i32 0, i32 0
  store i64 1, ptr %t238
  %t239 = load %"compiler/mir:Place", ptr %l116
  %t240 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t239, 0
  %t241 = getelementptr { i64, [4 x i64] }, ptr %t237, i32 0, i32 1
  store { %"compiler/mir:Place" } %t240, ptr %t241
  %t242 = load { i64, [4 x i64] }, ptr %t237
  store { i64, [4 x i64] } %t242, ptr %l117
  br i1 %a4, label %bb33, label %bb34
bb33:
  store i64 -1, ptr %l119, !tbaa !24
  br label %bb35
bb34:
  store i64 -2, ptr %l119, !tbaa !24
  br label %bb35
bb35:
  %t245 = load i32, ptr %l17, !tbaa !23
  store { i64, [7 x i64] } zeroinitializer, ptr %t246
  %t247 = getelementptr { i64, [7 x i64] }, ptr %t246, i32 0, i32 0
  store i64 3, ptr %t247
  %t248 = load { i64, [4 x i64] }, ptr %l117
  %t249 = insertvalue { { i64, [4 x i64] }, i64, i32 } undef, { i64, [4 x i64] } %t248, 0
  %t250 = load i64, ptr %l119, !tbaa !24
  %t251 = insertvalue { { i64, [4 x i64] }, i64, i32 } %t249, i64 %t250, 1
  %t253 = insertvalue { { i64, [4 x i64] }, i64, i32 } %t251, i32 %t245, 2
  %t254 = getelementptr { i64, [7 x i64] }, ptr %t246, i32 0, i32 1
  store { { i64, [4 x i64] }, i64, i32 } %t253, ptr %t254
  %t255 = load { i64, [7 x i64] }, ptr %t246
  store { i64, [7 x i64] } %t255, ptr %l18
  %t257 = load ptr, ptr %l0, !tbaa !29
  %t259 = getelementptr %"compiler/lower:lowering", ptr %t257, i32 0, i32 3
  %t261 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t259)
  store i32 %t261, ptr %l124
  br label %bb36
bb36:
  %t262 = load i32, ptr %l124, !tbaa !23
  store i32 %t262, ptr %l19, !tbaa !23
  %t263 = load ptr, ptr %l0, !tbaa !29
  %t265 = getelementptr %"compiler/lower:lowering", ptr %t263, i32 0, i32 3
  store ptr %t265, ptr %l126, !tbaa !29
  %t266 = load { i64, [7 x i64] }, ptr %l18
  store { i64, [7 x i64] } %t266, ptr %l127
  %t267 = load ptr, ptr %l0, !tbaa !29
  %t269 = getelementptr %"compiler/lower:lowering", ptr %t267, i32 0, i32 3
  store ptr %t269, ptr %l129, !tbaa !29
  %t270 = load i32, ptr %l7, !tbaa !23
  %t272 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t270)
  store %"compiler/mir:Place" %t272, ptr %l131
  br label %bb37
bb37:
  store { i64, [4 x i64] } zeroinitializer, ptr %t273
  %t274 = getelementptr { i64, [4 x i64] }, ptr %t273, i32 0, i32 0
  store i64 1, ptr %t274
  %t275 = load %"compiler/mir:Place", ptr %l131
  %t276 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t275, 0
  %t277 = getelementptr { i64, [4 x i64] }, ptr %t273, i32 0, i32 1
  store { %"compiler/mir:Place" } %t276, ptr %t277
  %t278 = load { i64, [4 x i64] }, ptr %t273
  %t279 = load { i64, [4 x i64] }, ptr %l16
  %t280 = mul i64 2, 40
  %t281 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t280)
  %t282 = insertvalue { i64, ptr } undef, i64 2, 0
  %t283 = insertvalue { i64, ptr } %t282, ptr %t281, 1
  store { i64, ptr } %t283, ptr %l134, !tbaa !27
  %t285 = getelementptr { i64, ptr }, ptr %l134, i32 0, i32 1
  %t286 = load ptr, ptr %t285, !tbaa !27
  %t287 = getelementptr { i64, [4 x i64] }, ptr %t286, i64 0
  store { i64, [4 x i64] } %t278, ptr %t287
  %t289 = getelementptr { i64, ptr }, ptr %l134, i32 0, i32 1
  %t290 = load ptr, ptr %t289, !tbaa !27
  %t291 = getelementptr { i64, [4 x i64] }, ptr %t290, i64 1
  store { i64, [4 x i64] } %t279, ptr %t291
  %t292 = load ptr, ptr %l129, !tbaa !29
  %t293 = load { i64, ptr }, ptr %l134, !tbaa !27
  %t294 = call %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eArgs(ptr %v0, ptr %s0, ptr %t292, { i64, ptr } %t293)
  store %"compiler/mir:Range" %t294, ptr %l135
  br label %bb38
bb38:
  %t295 = load ptr, ptr %l0, !tbaa !29
  %t297 = getelementptr %"compiler/lower:lowering", ptr %t295, i32 0, i32 3
  %t298 = load { i64, [1 x i64] }, ptr %l1
  %t299 = mul i64 1, 16
  %t300 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t299)
  %t301 = insertvalue { i64, ptr } undef, i64 1, 0
  %t302 = insertvalue { i64, ptr } %t301, ptr %t300, 1
  store { i64, ptr } %t302, ptr %l139, !tbaa !27
  %t304 = getelementptr { i64, ptr }, ptr %l139, i32 0, i32 1
  %t305 = load ptr, ptr %t304, !tbaa !27
  %t306 = getelementptr { i64, [1 x i64] }, ptr %t305, i64 0
  store { i64, [1 x i64] } %t298, ptr %t306
  %t308 = load { i64, ptr }, ptr %l139, !tbaa !27
  %t309 = call %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eScopeRefs(ptr %v0, ptr %s0, ptr %t297, { i64, ptr } %t308)
  store %"compiler/mir:Range" %t309, ptr %l140
  br label %bb39
bb39:
  %t310 = load %"compiler/mir:Place", ptr @G_2ecompiler_2fmir_2eNoPlace
  %t311 = load i32, ptr %l19, !tbaa !23
  %t312 = load i32, ptr @G_2ecompiler_2fmir_2eNoLocal, !tbaa !23
  %t313 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t314 = load { i64, [7 x i64] }, ptr %l127
  %t315 = load %"compiler/mir:Range", ptr %l135
  %t316 = load %"compiler/mir:Range", ptr %l140
  %t321 = call %"compiler/mir:Call" @compiler_2fmir_3aCall_2ector(ptr %s0, { i64, [7 x i64] } %t314, %"compiler/mir:Range" %t315, %"compiler/mir:Range" %t316, %"compiler/mir:Place" %t310, i1 false, i32 %t311, i32 %t312, i32 %t313)
  store %"compiler/mir:Call" %t321, ptr %l145
  br label %bb40
bb40:
  %t322 = load ptr, ptr %l126, !tbaa !29
  %t323 = load %"compiler/mir:Call", ptr %l145
  %t324 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddCall(ptr %v0, ptr %t322, %"compiler/mir:Call" %t323)
  store i32 %t324, ptr %l146
  br label %bb41
bb41:
  %t325 = load i32, ptr %l146, !tbaa !23
  %t326 = load ptr, ptr %l0, !tbaa !29
  %t327 = load %"compiler/source:Span", ptr %l5
  store { i64, [7 x i64] } zeroinitializer, ptr %t329
  %t330 = getelementptr { i64, [7 x i64] }, ptr %t329, i32 0, i32 0
  store i64 4, ptr %t330
  %t332 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t327, 0
  %t334 = insertvalue { %"compiler/source:Span", i32 } %t332, i32 %t325, 1
  %t335 = getelementptr { i64, [7 x i64] }, ptr %t329, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t334, ptr %t335
  %t336 = load { i64, [7 x i64] }, ptr %t329
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t326, { i64, [7 x i64] } %t336)
  br label %bb42
bb42:
  %t339 = load ptr, ptr %l0, !tbaa !29
  %t340 = load i32, ptr %l19, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t339, i32 %t340)
  br label %bb43
bb43:
  %t343 = load ptr, ptr %l0, !tbaa !29
  %t344 = load i32, ptr %l8, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2egoto(ptr %v0, ptr %t343, i32 %t344)
  br label %bb44
bb44:
  %t347 = load ptr, ptr %l0, !tbaa !29
  %t348 = load i32, ptr %l8, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t347, i32 %t348)
  br label %bb45
bb45:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eretCopies(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca i64
  %l18 = alloca ptr
  %l19 = alloca ptr
  %l20 = alloca i64
  %l21 = alloca { i64, ptr }
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca %"compiler/lower:level"
  %l25 = alloca ptr
  %l26 = alloca ptr
  %l27 = alloca i32
  %l33 = alloca i1
  %l34 = alloca ptr
  %l35 = alloca i1
  %l44 = alloca i1
  %l45 = alloca i1
  %l51 = alloca i1
  %l52 = alloca ptr
  %l53 = alloca i1
  %l66 = alloca { i64, ptr }
  %l73 = alloca i1
  %l81 = alloca i1
  %l82 = alloca ptr
  %l91 = alloca i1
  %l92 = alloca ptr
  %l93 = alloca i1
  %l102 = alloca i1
  %l112 = alloca { i64, ptr }
  %l123 = alloca { i64, ptr }
  %l130 = alloca i1
  %l137 = alloca ptr
  %l138 = alloca i1
  %l147 = alloca i1
  %l151 = alloca i1
  %l160 = alloca i64
  %l165 = alloca { i64, ptr }
  %l168 = alloca { i64, ptr }
  %l169 = alloca i32
  %l178 = alloca { i64, ptr }
  %l191 = alloca ptr
  %l192 = alloca ptr
  %l193 = alloca i1
  %l198 = alloca ptr
  %l199 = alloca i1
  %l208 = alloca %"compiler/mir:Local"
  %l209 = alloca { i64, [1 x i64] }
  %l210 = alloca ptr
  %l212 = alloca { i64, [1 x i64] }
  %l214 = alloca i1
  %l216 = alloca i1
  %l218 = alloca { i64, ptr }
  %s6 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s24 = alloca %olang.scope
  %s25 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t7 = load i32, ptr %l2, !tbaa !23
  %t10 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2evalueArray(ptr %v0, ptr %t6, i32 %t7)
  store i1 %t10, ptr %l33
  br label %bb4
bb4:
  %t11 = load i1, ptr %l33, !tbaa !21
  br i1 %t11, label %bb5, label %bb6
bb5:
  %t12 = load ptr, ptr %l1, !tbaa !29
  store ptr %t12, ptr %l34, !tbaa !29
  store i1 false, ptr %l35, !tbaa !21
  %t13 = load ptr, ptr %l34, !tbaa !29
  %t14 = icmp ne ptr %t13, null
  br i1 %t14, label %bb7, label %bb8
bb6:
  br label %bb79
bb7:
  %t16 = load ptr, ptr %l34, !tbaa !29
  %t17 = load i64, ptr %t16
  %t19 = icmp eq i64 %t17, 11
  store i1 %t19, ptr %l35, !tbaa !21
  br label %bb8
bb8:
  %t20 = load i1, ptr %l35, !tbaa !21
  br i1 %t20, label %bb9, label %bb10
bb9:
  %t21 = load ptr, ptr %l1, !tbaa !29
  %t23 = getelementptr { i64, [5 x i64] }, ptr %t21, i32 0, i32 1
  %t24 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t23, i32 0, i32 2
  %t25 = load ptr, ptr %t24
  store ptr %t25, ptr %l3, !tbaa !29
  br label %bb11
bb10:
  br label %bb17
bb11:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load ptr, ptr %l3, !tbaa !29
  %t30 = getelementptr %"compiler/typed:Cond", ptr %t28, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !29
  %t32 = load i32, ptr %l2, !tbaa !23
  %t36 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eretCopies(ptr %v0, ptr %v1, ptr %t27, ptr %t31, i32 %t32)
  store i1 %t36, ptr %l44
  br label %bb12
bb12:
  %t37 = load i1, ptr %l44, !tbaa !21
  br i1 %t37, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l45, !tbaa !21
  br label %bb16
bb14:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t39 = load ptr, ptr %l3, !tbaa !29
  %t41 = getelementptr %"compiler/typed:Cond", ptr %t39, i32 0, i32 2
  %t42 = load ptr, ptr %t41, !tbaa !29
  %t44 = load i32, ptr %l2, !tbaa !23
  %t48 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eretCopies(ptr %v0, ptr %v1, ptr %t38, ptr %t42, i32 %t44)
  store i1 %t48, ptr %l51
  br label %bb15
bb15:
  %t49 = load i1, ptr %l51, !tbaa !21
  store i1 %t49, ptr %l45, !tbaa !21
  br label %bb16
bb16:
  %t50 = load i1, ptr %l45, !tbaa !21
  store i1 %t50, ptr %rv
  br label %ret
bb17:
  %t51 = load ptr, ptr %l1, !tbaa !29
  store ptr %t51, ptr %l52, !tbaa !29
  store i1 false, ptr %l53, !tbaa !21
  %t52 = load ptr, ptr %l52, !tbaa !29
  %t53 = icmp ne ptr %t52, null
  br i1 %t53, label %bb18, label %bb19
bb18:
  %t55 = load ptr, ptr %l52, !tbaa !29
  %t56 = load i64, ptr %t55
  %t58 = icmp eq i64 %t56, 13
  store i1 %t58, ptr %l53, !tbaa !21
  br label %bb19
bb19:
  %t59 = load i1, ptr %l53, !tbaa !21
  br i1 %t59, label %bb20, label %bb21
bb20:
  %t60 = load ptr, ptr %l1, !tbaa !29
  %t62 = getelementptr { i64, [5 x i64] }, ptr %t60, i32 0, i32 1
  %t63 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t62, i32 0, i32 2
  %t64 = load ptr, ptr %t63
  store ptr %t64, ptr %l4, !tbaa !29
  br label %bb22
bb21:
  br label %bb40
bb22:
  %t66 = load ptr, ptr %l4, !tbaa !29
  %t68 = getelementptr %"compiler/typed:Match", ptr %t66, i32 0, i32 1
  %t69 = load { i64, ptr }, ptr %t68, !tbaa !27
  store { i64, ptr } %t69, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t71 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t73 = extractvalue { i64, ptr } %t71, 0
  store i64 %t73, ptr %l7, !tbaa !24
  br label %bb23
bb23:
  store %olang.scope zeroinitializer, ptr %s6
  %t75 = load i64, ptr %l6, !tbaa !24
  %t76 = load i64, ptr %l7, !tbaa !24
  %t79 = icmp slt i64 %t75, %t76
  %t81 = xor i1 %t79, true
  br i1 %t81, label %bb24, label %bb25
bb24:
  call void @__olang_scope_close(ptr %s6)
  br label %bb32
bb25:
  br label %bb26
bb26:
  %t83 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t83, ptr %l66, !tbaa !27
  %t84 = load i64, ptr %l6, !tbaa !24
  %t86 = getelementptr { i64, ptr }, ptr %l66, i32 0, i32 1
  %t87 = load ptr, ptr %t86, !tbaa !27
  %t88 = getelementptr ptr, ptr %t87, i64 %t84
  %t89 = load ptr, ptr %t88, !tbaa !39
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"compiler/typed:Arm", ptr %t89, i32 0, i32 4
  %t95 = load ptr, ptr %t94, !tbaa !29
  %t96 = load i32, ptr %l2, !tbaa !23
  %t100 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eretCopies(ptr %v0, ptr %v1, ptr %t91, ptr %t95, i32 %t96)
  store i1 %t100, ptr %l73
  br label %bb27
bb27:
  %t101 = load i1, ptr %l73, !tbaa !21
  br i1 %t101, label %bb28, label %bb29
bb28:
  call void @__olang_scope_close(ptr %s6)
  store i1 true, ptr %rv
  br label %ret
bb29:
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s6)
  br label %bb31
bb31:
  %t103 = load i64, ptr %l6, !tbaa !24
  %t105 = add i64 %t103, 1
  store i64 %t105, ptr %l6, !tbaa !24
  br label %bb23
bb32:
  %t107 = load ptr, ptr %l4, !tbaa !29
  %t109 = getelementptr %"compiler/typed:Match", ptr %t107, i32 0, i32 2
  %t110 = load ptr, ptr %t109, !tbaa !29
  %t112 = icmp eq ptr %t110, null
  %t114 = xor i1 %t112, true
  br i1 %t114, label %bb33, label %bb34
bb33:
  %t116 = load ptr, ptr %l0, !tbaa !29
  store ptr %t116, ptr %l82, !tbaa !29
  %t117 = load ptr, ptr %l4, !tbaa !29
  %t119 = getelementptr %"compiler/typed:Match", ptr %t117, i32 0, i32 2
  %t120 = load ptr, ptr %t119, !tbaa !29
  %t122 = icmp eq ptr %t120, null
  br i1 %t122, label %bb35, label %bb36
bb34:
  store i1 false, ptr %l81, !tbaa !21
  br label %bb39
bb35:
  call void @__olang_check_failed(ptr @olang_loc_ddcb411f232bf43e_ce3417657830a5fa)
  unreachable
bb36:
  br label %bb37
bb37:
  %t124 = load ptr, ptr %l4, !tbaa !29
  %t126 = getelementptr %"compiler/typed:Match", ptr %t124, i32 0, i32 2
  %t127 = load ptr, ptr %t126, !tbaa !29
  %t130 = getelementptr %"compiler/typed:Arm", ptr %t127, i32 0, i32 4
  %t131 = load ptr, ptr %t130, !tbaa !29
  %t132 = load i32, ptr %l2, !tbaa !23
  %t133 = load ptr, ptr %l82, !tbaa !29
  %t136 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eretCopies(ptr %v0, ptr %v1, ptr %t133, ptr %t131, i32 %t132)
  store i1 %t136, ptr %l91
  br label %bb38
bb38:
  %t137 = load i1, ptr %l91, !tbaa !21
  store i1 %t137, ptr %l81, !tbaa !21
  br label %bb39
bb39:
  %t138 = load i1, ptr %l81, !tbaa !21
  store i1 %t138, ptr %rv
  br label %ret
bb40:
  %t139 = load ptr, ptr %l1, !tbaa !29
  store ptr %t139, ptr %l92, !tbaa !29
  store i1 false, ptr %l93, !tbaa !21
  %t140 = load ptr, ptr %l92, !tbaa !29
  %t141 = icmp ne ptr %t140, null
  br i1 %t141, label %bb41, label %bb42
bb41:
  %t143 = load ptr, ptr %l92, !tbaa !29
  %t144 = load i64, ptr %t143
  %t146 = icmp eq i64 %t144, 14
  store i1 %t146, ptr %l93, !tbaa !21
  br label %bb42
bb42:
  %t147 = load i1, ptr %l93, !tbaa !21
  br i1 %t147, label %bb43, label %bb44
bb43:
  %t148 = load ptr, ptr %l1, !tbaa !29
  %t150 = getelementptr { i64, [5 x i64] }, ptr %t148, i32 0, i32 1
  %t151 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t150, i32 0, i32 2
  %t152 = load ptr, ptr %t151
  store ptr %t152, ptr %l9, !tbaa !29
  br label %bb45
bb44:
  br label %bb66
bb45:
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t155 = load ptr, ptr %l9, !tbaa !29
  %t157 = getelementptr %"compiler/typed:Try", ptr %t155, i32 0, i32 0
  %t158 = load ptr, ptr %t157, !tbaa !29
  %t159 = load i32, ptr %l2, !tbaa !23
  %t163 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eretCopies(ptr %v0, ptr %v1, ptr %t154, ptr %t158, i32 %t159)
  store i1 %t163, ptr %l102
  br label %bb46
bb46:
  %t164 = load i1, ptr %l102, !tbaa !21
  br i1 %t164, label %bb47, label %bb48
bb47:
  store i1 true, ptr %rv
  br label %ret
bb48:
  br label %bb49
bb49:
  %t166 = load ptr, ptr %l9, !tbaa !29
  %t168 = getelementptr %"compiler/typed:Try", ptr %t166, i32 0, i32 1
  %t169 = load { i64, ptr }, ptr %t168, !tbaa !27
  store { i64, ptr } %t169, ptr %l10, !tbaa !27
  store i64 0, ptr %l11, !tbaa !24
  %t171 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t173 = extractvalue { i64, ptr } %t171, 0
  store i64 %t173, ptr %l12, !tbaa !24
  br label %bb50
bb50:
  store %olang.scope zeroinitializer, ptr %s12
  %t175 = load i64, ptr %l11, !tbaa !24
  %t176 = load i64, ptr %l12, !tbaa !24
  %t179 = icmp slt i64 %t175, %t176
  %t181 = xor i1 %t179, true
  br i1 %t181, label %bb51, label %bb52
bb51:
  call void @__olang_scope_close(ptr %s12)
  br label %bb65
bb52:
  br label %bb53
bb53:
  %t183 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t183, ptr %l112, !tbaa !27
  %t184 = load i64, ptr %l11, !tbaa !24
  %t186 = getelementptr { i64, ptr }, ptr %l112, i32 0, i32 1
  %t187 = load ptr, ptr %t186, !tbaa !27
  %t188 = getelementptr ptr, ptr %t187, i64 %t184
  %t189 = load ptr, ptr %t188, !tbaa !39
  %t193 = getelementptr %"compiler/typed:Clause", ptr %t189, i32 0, i32 4
  %t194 = load { i64, ptr }, ptr %t193, !tbaa !27
  store { i64, ptr } %t194, ptr %l14, !tbaa !27
  store i64 0, ptr %l15, !tbaa !24
  %t196 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t198 = extractvalue { i64, ptr } %t196, 0
  store i64 %t198, ptr %l16, !tbaa !24
  br label %bb54
bb54:
  store %olang.scope zeroinitializer, ptr %s14
  %t200 = load i64, ptr %l15, !tbaa !24
  %t201 = load i64, ptr %l16, !tbaa !24
  %t204 = icmp slt i64 %t200, %t201
  %t206 = xor i1 %t204, true
  br i1 %t206, label %bb55, label %bb56
bb55:
  call void @__olang_scope_close(ptr %s14)
  br label %bb63
bb56:
  br label %bb57
bb57:
  %t208 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t208, ptr %l123, !tbaa !27
  %t209 = load i64, ptr %l15, !tbaa !24
  %t211 = getelementptr { i64, ptr }, ptr %l123, i32 0, i32 1
  %t212 = load ptr, ptr %t211, !tbaa !27
  %t213 = getelementptr ptr, ptr %t212, i64 %t209
  %t214 = load ptr, ptr %t213, !tbaa !39
  %t216 = load ptr, ptr %l0, !tbaa !29
  %t219 = load i32, ptr %l2, !tbaa !23
  %t223 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eretCopies(ptr %v0, ptr %v1, ptr %t216, ptr %t214, i32 %t219)
  store i1 %t223, ptr %l130
  br label %bb58
bb58:
  %t224 = load i1, ptr %l130, !tbaa !21
  br i1 %t224, label %bb59, label %bb60
bb59:
  call void @__olang_scope_close(ptr %s14)
  call void @__olang_scope_close(ptr %s12)
  store i1 true, ptr %rv
  br label %ret
bb60:
  br label %bb61
bb61:
  call void @__olang_scope_close(ptr %s14)
  br label %bb62
bb62:
  %t226 = load i64, ptr %l15, !tbaa !24
  %t228 = add i64 %t226, 1
  store i64 %t228, ptr %l15, !tbaa !24
  br label %bb54
bb63:
  call void @__olang_scope_close(ptr %s12)
  br label %bb64
bb64:
  %t230 = load i64, ptr %l11, !tbaa !24
  %t232 = add i64 %t230, 1
  store i64 %t232, ptr %l11, !tbaa !24
  br label %bb50
bb65:
  store i1 false, ptr %rv
  br label %ret
bb66:
  %t235 = load ptr, ptr %l1, !tbaa !29
  store ptr %t235, ptr %l137, !tbaa !29
  store i1 false, ptr %l138, !tbaa !21
  %t236 = load ptr, ptr %l137, !tbaa !29
  %t237 = icmp ne ptr %t236, null
  br i1 %t237, label %bb67, label %bb68
bb67:
  %t239 = load ptr, ptr %l137, !tbaa !29
  %t240 = load i64, ptr %t239
  %t242 = icmp eq i64 %t240, 12
  store i1 %t242, ptr %l138, !tbaa !21
  br label %bb68
bb68:
  %t243 = load i1, ptr %l138, !tbaa !21
  br i1 %t243, label %bb69, label %bb70
bb69:
  %t244 = load ptr, ptr %l1, !tbaa !29
  %t246 = getelementptr { i64, [5 x i64] }, ptr %t244, i32 0, i32 1
  %t247 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t246, i32 0, i32 2
  %t248 = load ptr, ptr %t247
  store ptr %t248, ptr %l18, !tbaa !29
  br label %bb71
bb70:
  br label %bb73
bb71:
  %t250 = load ptr, ptr %l0, !tbaa !29
  %t251 = load ptr, ptr %l18, !tbaa !29
  %t253 = getelementptr %"compiler/typed:Seq", ptr %t251, i32 0, i32 1
  %t254 = load ptr, ptr %t253, !tbaa !29
  %t255 = load i32, ptr %l2, !tbaa !23
  %t259 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eretCopies(ptr %v0, ptr %v1, ptr %t250, ptr %t254, i32 %t255)
  store i1 %t259, ptr %l147
  br label %bb72
bb72:
  %t260 = load i1, ptr %l147, !tbaa !21
  store i1 %t260, ptr %rv
  br label %ret
bb73:
  br i1 true, label %bb74, label %bb75
bb74:
  br label %bb76
bb75:
  br label %bb77
bb76:
  br label %bb78
bb77:
  call void @__olang_check_failed(ptr @olang_loc_ecde87765d07009c_52dfe83edba10a08)
  unreachable
bb78:
  br label %bb79
bb79:
  %t261 = load ptr, ptr %l0, !tbaa !29
  %t262 = load ptr, ptr %l1, !tbaa !29
  %t263 = load i32, ptr %l2, !tbaa !23
  %t267 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2ecopiesArray(ptr %v0, ptr %v1, ptr %t261, ptr %t262, i32 %t263)
  store i1 %t267, ptr %l151
  br label %bb80
bb80:
  %t268 = load i1, ptr %l151, !tbaa !21
  %t269 = xor i1 %t268, true
  br i1 %t269, label %bb81, label %bb82
bb81:
  store i1 false, ptr %rv
  br label %ret
bb82:
  br label %bb83
bb83:
  %t272 = load ptr, ptr %l0, !tbaa !29
  %t274 = getelementptr %"compiler/lower:lowering", ptr %t272, i32 0, i32 19
  %t275 = load i1, ptr %t274, !tbaa !21
  %t277 = xor i1 %t275, true
  br i1 %t277, label %bb84, label %bb85
bb84:
  store i1 true, ptr %rv
  br label %ret
bb85:
  br label %bb86
bb86:
  %t280 = load ptr, ptr %l0, !tbaa !29
  %t282 = getelementptr %"compiler/lower:lowering", ptr %t280, i32 0, i32 10
  %t284 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aBlock_26_3e_2eLe_H8743fc75fe5cead0bda2da42e1adf3f3(ptr %v0, ptr %t282)
  store i64 %t284, ptr %l160
  br label %bb87
bb87:
  %t285 = load i64, ptr %l160, !tbaa !24
  %t286 = icmp sgt i64 %t285, 0
  br i1 %t286, label %bb88, label %bb89
bb88:
  store i1 true, ptr %rv
  br label %ret
bb89:
  br label %bb90
bb90:
  %t289 = load ptr, ptr %l0, !tbaa !29
  %t291 = getelementptr %"compiler/lower:lowering", ptr %t289, i32 0, i32 9
  store ptr %t291, ptr %l19, !tbaa !29
  store i64 0, ptr %l20, !tbaa !24
  br label %bb91
bb91:
  store %olang.scope zeroinitializer, ptr %s24
  %t293 = load ptr, ptr %l19, !tbaa !29
  %t294 = load i64, ptr %l20, !tbaa !24
  %t297 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3alevel_3e_2eRunFrom_3ccompiler_2flower_3alevel_3e(ptr %v0, ptr %t293, i64 %t294)
  %t298 = extractvalue { i32, { i64, ptr } } %t297, 1
  %t299 = extractvalue { i32, { i64, ptr } } %t297, 0
  store i32 %t299, ptr %l169
  %t300 = icmp ne i32 %t299, 0
  br i1 %t300, label %bb93, label %ok.301
ok.301:
  store { i64, ptr } %t298, ptr %l168
  br label %bb92
bb92:
  %t302 = load { i64, ptr }, ptr %l168, !tbaa !27
  store { i64, ptr } %t302, ptr %l165, !tbaa !27
  br label %bb97
bb93:
  %t303 = load i32, ptr %l169, !tbaa !23
  %t304 = ashr i32 %t303, 16
  %t306 = icmp eq i32 %t304, 1
  br i1 %t306, label %bb94, label %bb95
bb94:
  br label %bb96
bb95:
  call void @__olang_check_failed(ptr @olang_loc_2e0d72be7b5575d7_214712821f524de3)
  unreachable
bb96:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s24)
  br label %bb108
bb97:
  %t308 = load { i64, ptr }, ptr %l165, !tbaa !27
  store { i64, ptr } %t308, ptr %l21, !tbaa !27
  %t309 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t311 = extractvalue { i64, ptr } %t309, 0
  store i64 %t311, ptr %l22, !tbaa !24
  store i64 0, ptr %l23, !tbaa !24
  br label %bb98
bb98:
  store %olang.scope zeroinitializer, ptr %s25
  %t313 = load i64, ptr %l23, !tbaa !24
  %t314 = load i64, ptr %l22, !tbaa !24
  %t317 = icmp slt i64 %t313, %t314
  %t319 = xor i1 %t317, true
  br i1 %t319, label %bb99, label %bb100
bb99:
  call void @__olang_scope_close(ptr %s25)
  br label %bb106
bb100:
  br label %bb101
bb101:
  %t321 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t321, ptr %l178, !tbaa !27
  %t322 = load i64, ptr %l23, !tbaa !24
  %t324 = getelementptr { i64, ptr }, ptr %l178, i32 0, i32 1
  %t325 = load ptr, ptr %t324, !tbaa !27
  %t326 = getelementptr %"compiler/lower:level", ptr %t325, i64 %t322
  %t327 = load %"compiler/lower:level", ptr %t326
  store %"compiler/lower:level" %t327, ptr %l24
  %t329 = getelementptr %"compiler/lower:level", ptr %l24, i32 0, i32 2
  %t330 = load i32, ptr %t329
  %t332 = trunc i64 3 to i32
  %t333 = icmp eq i32 %t330, %t332
  br i1 %t333, label %bb102, label %bb103
bb102:
  call void @__olang_scope_close(ptr %s25)
  call void @__olang_scope_close(ptr %s24)
  store i1 true, ptr %rv
  br label %ret
bb103:
  br label %bb104
bb104:
  call void @__olang_scope_close(ptr %s25)
  br label %bb105
bb105:
  %t336 = load i64, ptr %l23, !tbaa !24
  %t338 = add i64 %t336, 1
  store i64 %t338, ptr %l23, !tbaa !24
  br label %bb98
bb106:
  %t340 = load i64, ptr %l20, !tbaa !24
  %t341 = load i64, ptr %l22, !tbaa !24
  %t344 = add i64 %t340, %t341
  store i64 %t344, ptr %l20, !tbaa !24
  call void @__olang_scope_close(ptr %s24)
  br label %bb107
bb107:
  br label %bb91
bb108:
  %t346 = load ptr, ptr %l0, !tbaa !29
  %t347 = load ptr, ptr %l1, !tbaa !29
  %t350 = call ptr @compiler_2flower_2ecompiler_2flower_3alowering_2eunconvert(ptr %v0, ptr %v1, ptr %t346, ptr %t347)
  store ptr %t350, ptr %l191
  br label %bb109
bb109:
  %t351 = load ptr, ptr %l191, !tbaa !29
  store ptr %t351, ptr %l25, !tbaa !29
  %t352 = load ptr, ptr %l25, !tbaa !29
  store ptr %t352, ptr %l192, !tbaa !29
  store i1 false, ptr %l193, !tbaa !21
  %t353 = load ptr, ptr %l192, !tbaa !29
  %t354 = icmp ne ptr %t353, null
  br i1 %t354, label %bb110, label %bb111
bb110:
  %t356 = load ptr, ptr %l192, !tbaa !29
  %t357 = load i64, ptr %t356
  %t359 = icmp eq i64 %t357, 2
  store i1 %t359, ptr %l193, !tbaa !21
  br label %bb111
bb111:
  %t360 = load i1, ptr %l193, !tbaa !21
  br i1 %t360, label %bb112, label %bb113
bb112:
  %t361 = load ptr, ptr %l25, !tbaa !29
  %t363 = getelementptr { i64, [5 x i64] }, ptr %t361, i32 0, i32 1
  %t364 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t363, i32 0, i32 2
  %t365 = load ptr, ptr %t364
  store ptr %t365, ptr %l26, !tbaa !29
  br label %bb114
bb113:
  br label %bb132
bb114:
  %t367 = load ptr, ptr %l26, !tbaa !29
  store ptr %t367, ptr %l198, !tbaa !29
  store i1 false, ptr %l199, !tbaa !21
  %t368 = load ptr, ptr %l198, !tbaa !29
  %t369 = icmp ne ptr %t368, null
  br i1 %t369, label %bb115, label %bb116
bb115:
  %t371 = load ptr, ptr %l198, !tbaa !29
  %t372 = load i64, ptr %t371
  %t374 = icmp eq i64 %t372, 0
  store i1 %t374, ptr %l199, !tbaa !21
  br label %bb116
bb116:
  %t375 = load i1, ptr %l199, !tbaa !21
  br i1 %t375, label %bb117, label %bb118
bb117:
  %t376 = load ptr, ptr %l26, !tbaa !29
  %t378 = getelementptr { i64, [4 x i64] }, ptr %t376, i32 0, i32 1
  %t379 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t378, i32 0, i32 2
  %t380 = load i32, ptr %t379
  store i32 %t380, ptr %l27, !tbaa !23
  br label %bb119
bb118:
  br label %bb126
bb119:
  %t382 = load ptr, ptr %l0, !tbaa !29
  %t384 = getelementptr %"compiler/lower:lowering", ptr %t382, i32 0, i32 3
  %t385 = getelementptr %"compiler/mir:Fn", ptr %t384, i32 0, i32 7
  %t386 = load i32, ptr %l27, !tbaa !23
  %t388 = sext i32 %t386 to i64
  %t391 = call %"compiler/mir:Local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aLocal_3e_2eAt_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %t385, i64 %t388)
  store %"compiler/mir:Local" %t391, ptr %l208
  br label %bb120
bb120:
  %t392 = getelementptr %"compiler/mir:Local", ptr %l208, i32 0, i32 4
  %t393 = load { i64, [1 x i64] }, ptr %t392
  store { i64, [1 x i64] } %t393, ptr %l209
  store ptr %l209, ptr %l210, !tbaa !29
  %t394 = load ptr, ptr %l0, !tbaa !29
  %t396 = call { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eresultScope(ptr %v0, ptr %t394)
  store { i64, [1 x i64] } %t396, ptr %l212
  br label %bb121
bb121:
  %t397 = load ptr, ptr %l210, !tbaa !29
  %t399 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fmir_3aScopeRef(ptr %t397, ptr %l212)
  store i1 %t399, ptr %l214
  br label %bb122
bb122:
  %t400 = load i1, ptr %l214, !tbaa !21
  %t401 = xor i1 %t400, true
  br i1 %t401, label %bb123, label %bb124
bb123:
  store i1 true, ptr %l216, !tbaa !21
  br label %bb125
bb124:
  %t403 = load ptr, ptr %l0, !tbaa !29
  %t405 = getelementptr %"compiler/lower:lowering", ptr %t403, i32 0, i32 22
  %t406 = getelementptr %"compiler/typed:Plan", ptr %t405, i32 0, i32 3
  %t407 = load { i64, ptr }, ptr %t406, !tbaa !27
  store { i64, ptr } %t407, ptr %l218, !tbaa !27
  %t408 = load i32, ptr %l27, !tbaa !23
  %t410 = sext i32 %t408 to i64
  %t412 = getelementptr { i64, ptr }, ptr %l218, i32 0, i32 1
  %t413 = load ptr, ptr %t412, !tbaa !27
  %t414 = getelementptr i1, ptr %t413, i64 %t410
  %t415 = load i1, ptr %t414, !tbaa !31
  %t417 = xor i1 %t415, true
  store i1 %t417, ptr %l216, !tbaa !21
  br label %bb125
bb125:
  %t419 = load i1, ptr %l216, !tbaa !21
  store i1 %t419, ptr %rv
  br label %ret
bb126:
  br i1 true, label %bb127, label %bb128
bb127:
  br label %bb129
bb128:
  br label %bb130
bb129:
  br label %bb131
bb130:
  call void @__olang_check_failed(ptr @olang_loc_4b16c1f6667ae236_8522eea6e5c16fe2)
  unreachable
bb131:
  br label %bb137
bb132:
  br i1 true, label %bb133, label %bb134
bb133:
  br label %bb135
bb134:
  br label %bb136
bb135:
  br label %bb137
bb136:
  call void @__olang_check_failed(ptr @olang_loc_d0e8b819f5194451_9afcdf330b6f59b5)
  unreachable
bb137:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3alowering_2escalar(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l6 = alloca i32
  %l10 = alloca i1
  %l14 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t8 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t4, i32 %a1)
  store i32 %t8, ptr %l6
  br label %bb1
bb1:
  %t9 = load i32, ptr %l6, !tbaa !23
  store i32 %t9, ptr %l2, !tbaa !23
  %t10 = load i32, ptr %l2, !tbaa !23
  %t11 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t14 = icmp eq i32 %t10, %t11
  br i1 %t14, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l10, !tbaa !21
  br label %bb5
bb3:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/lower:lowering", ptr %t16, i32 0, i32 2
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t20 = load i32, ptr %l2, !tbaa !23
  %t23 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNumber(ptr %v0, ptr %t19, i32 %t20)
  store i1 %t23, ptr %l14
  br label %bb4
bb4:
  %t24 = load i1, ptr %l14, !tbaa !21
  store i1 %t24, ptr %l10, !tbaa !21
  br label %bb5
bb5:
  %t25 = load i1, ptr %l10, !tbaa !21
  store i1 %t25, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eslice(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca %"compiler/lower:pl"
  %l5 = alloca { i64, [4 x i64] }
  %l6 = alloca { i64, [4 x i64] }
  %l7 = alloca { i64, [4 x i64] }
  %l8 = alloca { i64, [4 x i64] }
  %l9 = alloca { i64, [4 x i64] }
  %l17 = alloca %"compiler/lower:pl"
  %l22 = alloca { i64, [4 x i64] }
  %l27 = alloca { i64, [4 x i64] }
  %l31 = alloca ptr
  %l32 = alloca { i64, [4 x i64] }
  %l35 = alloca i32
  %l37 = alloca { i64, [4 x i64] }
  %l38 = alloca ptr
  %l39 = alloca { i64, [4 x i64] }
  %l42 = alloca i32
  %l44 = alloca { i64, [4 x i64] }
  %l49 = alloca ptr
  %l50 = alloca i32
  %l51 = alloca i32
  %l54 = alloca %"compiler/mir:Place"
  %l56 = alloca { i64, ptr }
  %l58 = alloca { i64, [4 x i64] }
  %l59 = alloca ptr
  %l60 = alloca i32
  %l61 = alloca i32
  %l62 = alloca { i64, [4 x i64] }
  %l64 = alloca { i64, [4 x i64] }
  %l65 = alloca { i64, ptr }
  %l67 = alloca { i64, [4 x i64] }
  %l80 = alloca { i64, ptr }
  %l82 = alloca { i64, [4 x i64] }
  %l95 = alloca { i64, ptr }
  %l97 = alloca { i64, [4 x i64] }
  %l105 = alloca ptr
  %l106 = alloca i32
  %l109 = alloca %"compiler/mir:Place"
  %l115 = alloca { i64, [4 x i64] }
  %s2 = alloca %olang.scope
  %rv = alloca { i64, [4 x i64] }
  %t36 = alloca { i64, [4 x i64] }, align 8
  %t87 = alloca { i64, [4 x i64] }, align 8
  %t235 = alloca { i64, [15 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  store %"compiler/source:Span" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t4 = getelementptr %"compiler/typed:Slice", ptr %t2, i32 0, i32 0
  %t5 = load ptr, ptr %t4, !tbaa !29
  %t9 = call %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2eplace(ptr %v0, ptr %v1, ptr %v0, ptr %t1, ptr %t5)
  store %"compiler/lower:pl" %t9, ptr %l17
  br label %bb1
bb1:
  %t10 = load %"compiler/lower:pl", ptr %l17
  store %"compiler/lower:pl" %t10, ptr %l4
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load ptr, ptr %l1, !tbaa !29
  %t14 = getelementptr %"compiler/typed:Slice", ptr %t12, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t19 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v1, ptr %t11, ptr %t15)
  store { i64, [4 x i64] } %t19, ptr %l22
  br label %bb2
bb2:
  %t20 = load { i64, [4 x i64] }, ptr %l22
  store { i64, [4 x i64] } %t20, ptr %l5
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t24 = getelementptr %"compiler/typed:Slice", ptr %t22, i32 0, i32 2
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t29 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v1, ptr %t21, ptr %t25)
  store { i64, [4 x i64] } %t29, ptr %l27
  br label %bb3
bb3:
  %t30 = load { i64, [4 x i64] }, ptr %l27
  store { i64, [4 x i64] } %t30, ptr %l6
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/lower:lowering", ptr %t31, i32 0, i32 7
  %t34 = load i1, ptr %t33, !tbaa !21
  br i1 %t34, label %bb4, label %bb5
bb4:
  store { i64, [4 x i64] } zeroinitializer, ptr %t36
  %t37 = getelementptr { i64, [4 x i64] }, ptr %t36, i32 0, i32 0
  store i64 0, ptr %t37
  %t38 = load { i64, [4 x i64] }, ptr %t36
  store { i64, [4 x i64] } %t38, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t40 = load ptr, ptr %l0, !tbaa !29
  store ptr %t40, ptr %l31, !tbaa !29
  %t41 = load { i64, [4 x i64] }, ptr %l5
  store { i64, [4 x i64] } %t41, ptr %l32
  %t42 = load ptr, ptr %l1, !tbaa !29
  %t44 = getelementptr %"compiler/typed:Slice", ptr %t42, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !29
  %t47 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t45)
  store i32 %t47, ptr %l35
  br label %bb7
bb7:
  %t48 = load %"compiler/source:Span", ptr %l3
  %t49 = load ptr, ptr %l31, !tbaa !29
  %t50 = load { i64, [4 x i64] }, ptr %l32
  %t51 = load i32, ptr %l35, !tbaa !23
  %t53 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2easI64(ptr %v0, ptr %t49, { i64, [4 x i64] } %t50, i32 %t51, %"compiler/source:Span" %t48)
  store { i64, [4 x i64] } %t53, ptr %l37
  br label %bb8
bb8:
  %t54 = load { i64, [4 x i64] }, ptr %l37
  store { i64, [4 x i64] } %t54, ptr %l7
  %t55 = load ptr, ptr %l0, !tbaa !29
  store ptr %t55, ptr %l38, !tbaa !29
  %t56 = load { i64, [4 x i64] }, ptr %l6
  store { i64, [4 x i64] } %t56, ptr %l39
  %t57 = load ptr, ptr %l1, !tbaa !29
  %t59 = getelementptr %"compiler/typed:Slice", ptr %t57, i32 0, i32 2
  %t60 = load ptr, ptr %t59, !tbaa !29
  %t62 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t60)
  store i32 %t62, ptr %l42
  br label %bb9
bb9:
  %t63 = load %"compiler/source:Span", ptr %l3
  %t64 = load ptr, ptr %l38, !tbaa !29
  %t65 = load { i64, [4 x i64] }, ptr %l39
  %t66 = load i32, ptr %l42, !tbaa !23
  %t68 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2easI64(ptr %v0, ptr %t64, { i64, [4 x i64] } %t65, i32 %t66, %"compiler/source:Span" %t63)
  store { i64, [4 x i64] } %t68, ptr %l44
  br label %bb10
bb10:
  %t69 = load { i64, [4 x i64] }, ptr %l44
  store { i64, [4 x i64] } %t69, ptr %l8
  %t70 = load ptr, ptr %l1, !tbaa !29
  %t72 = getelementptr %"compiler/typed:Slice", ptr %t70, i32 0, i32 3
  %t73 = load i32, ptr %t72
  %t75 = trunc i64 0 to i32
  %t76 = icmp eq i32 %t73, %t75
  %t78 = xor i1 %t76, true
  br i1 %t78, label %bb11, label %bb12
bb11:
  store %olang.scope zeroinitializer, ptr %s2
  %t80 = load ptr, ptr %l0, !tbaa !29
  store ptr %t80, ptr %l49, !tbaa !29
  store i32 22, ptr %l50
  %t81 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  store i32 %t81, ptr %l51, !tbaa !23
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t83 = load %"compiler/lower:pl", ptr %l4
  %t86 = call %"compiler/mir:Place" @compiler_2flower_2ecompiler_2flower_3alowering_2emk(ptr %v0, ptr %v0, ptr %t82, %"compiler/lower:pl" %t83)
  store %"compiler/mir:Place" %t86, ptr %l54
  br label %bb13
bb12:
  br label %bb22
bb13:
  store { i64, [4 x i64] } zeroinitializer, ptr %t87
  %t88 = getelementptr { i64, [4 x i64] }, ptr %t87, i32 0, i32 0
  store i64 1, ptr %t88
  %t89 = load %"compiler/mir:Place", ptr %l54
  %t90 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t89, 0
  %t91 = getelementptr { i64, [4 x i64] }, ptr %t87, i32 0, i32 1
  store { %"compiler/mir:Place" } %t90, ptr %t91
  %t92 = load { i64, [4 x i64] }, ptr %t87
  %t93 = mul i64 1, 40
  %t94 = call ptr @__olang_scope_alloc_zeroed(ptr %s2, i64 %t93)
  %t95 = insertvalue { i64, ptr } undef, i64 1, 0
  %t96 = insertvalue { i64, ptr } %t95, ptr %t94, 1
  store { i64, ptr } %t96, ptr %l56, !tbaa !27
  %t98 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t99 = load ptr, ptr %t98, !tbaa !27
  %t100 = getelementptr { i64, [4 x i64] }, ptr %t99, i64 0
  store { i64, [4 x i64] } %t92, ptr %t100
  %t101 = load %"compiler/source:Span", ptr %l3
  %t102 = load ptr, ptr %l49, !tbaa !29
  %t103 = load i32, ptr %l50
  %t104 = load i32, ptr %l51, !tbaa !23
  %t105 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t107 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s2, ptr %t102, i32 %t103, i32 %t104, { i64, ptr } %t105, %"compiler/source:Span" %t101)
  store { i64, [4 x i64] } %t107, ptr %l58
  br label %bb14
bb14:
  %t108 = load { i64, [4 x i64] }, ptr %l58
  store { i64, [4 x i64] } %t108, ptr %l9
  %t109 = load ptr, ptr %l0, !tbaa !29
  store ptr %t109, ptr %l59, !tbaa !29
  store i32 18, ptr %l60
  %t110 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t110, ptr %l61, !tbaa !23
  %t111 = load { i64, [4 x i64] }, ptr %l7
  store { i64, [4 x i64] } %t111, ptr %l62
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t114 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2econstI64(ptr %v0, ptr %t112, i64 0)
  store { i64, [4 x i64] } %t114, ptr %l64
  br label %bb15
bb15:
  %t115 = mul i64 2, 40
  %t116 = call ptr @__olang_scope_alloc_zeroed(ptr %s2, i64 %t115)
  %t117 = insertvalue { i64, ptr } undef, i64 2, 0
  %t118 = insertvalue { i64, ptr } %t117, ptr %t116, 1
  store { i64, ptr } %t118, ptr %l65, !tbaa !27
  %t119 = load { i64, [4 x i64] }, ptr %l62
  %t120 = getelementptr { i64, ptr }, ptr %l65, i32 0, i32 1
  %t121 = load ptr, ptr %t120, !tbaa !27
  %t122 = getelementptr { i64, [4 x i64] }, ptr %t121, i64 0
  store { i64, [4 x i64] } %t119, ptr %t122
  %t123 = load { i64, [4 x i64] }, ptr %l64
  %t124 = getelementptr { i64, ptr }, ptr %l65, i32 0, i32 1
  %t125 = load ptr, ptr %t124, !tbaa !27
  %t126 = getelementptr { i64, [4 x i64] }, ptr %t125, i64 1
  store { i64, [4 x i64] } %t123, ptr %t126
  %t127 = load %"compiler/source:Span", ptr %l3
  %t128 = load ptr, ptr %l59, !tbaa !29
  %t129 = load i32, ptr %l60
  %t130 = load i32, ptr %l61, !tbaa !23
  %t131 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t133 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s2, ptr %t128, i32 %t129, i32 %t130, { i64, ptr } %t131, %"compiler/source:Span" %t127)
  store { i64, [4 x i64] } %t133, ptr %l67
  br label %bb16
bb16:
  %t134 = load { i64, [4 x i64] }, ptr %l67
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t137 = load ptr, ptr %l1, !tbaa !29
  %t139 = getelementptr %"compiler/typed:Slice", ptr %t137, i32 0, i32 3
  %t140 = load i32, ptr %t139
  %t141 = load i64, ptr @G_2ecompiler_2flower_2eOutOfBounds, !tbaa !24
  %t142 = load %"compiler/source:Span", ptr %l3
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2echeck(ptr %v0, ptr %t135, { i64, [4 x i64] } %t134, i32 %t140, i32 6, i64 %t141, %"compiler/source:Span" %t142)
  br label %bb17
bb17:
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t150 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t151 = load { i64, [4 x i64] }, ptr %l7
  %t152 = load { i64, [4 x i64] }, ptr %l8
  %t153 = mul i64 2, 40
  %t154 = call ptr @__olang_scope_alloc_zeroed(ptr %s2, i64 %t153)
  %t155 = insertvalue { i64, ptr } undef, i64 2, 0
  %t156 = insertvalue { i64, ptr } %t155, ptr %t154, 1
  store { i64, ptr } %t156, ptr %l80, !tbaa !27
  %t158 = getelementptr { i64, ptr }, ptr %l80, i32 0, i32 1
  %t159 = load ptr, ptr %t158, !tbaa !27
  %t160 = getelementptr { i64, [4 x i64] }, ptr %t159, i64 0
  store { i64, [4 x i64] } %t151, ptr %t160
  %t162 = getelementptr { i64, ptr }, ptr %l80, i32 0, i32 1
  %t163 = load ptr, ptr %t162, !tbaa !27
  %t164 = getelementptr { i64, [4 x i64] }, ptr %t163, i64 1
  store { i64, [4 x i64] } %t152, ptr %t164
  %t165 = load %"compiler/source:Span", ptr %l3
  %t169 = load { i64, ptr }, ptr %l80, !tbaa !27
  %t171 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s2, ptr %t149, i32 16, i32 %t150, { i64, ptr } %t169, %"compiler/source:Span" %t165)
  store { i64, [4 x i64] } %t171, ptr %l82
  br label %bb18
bb18:
  %t172 = load { i64, [4 x i64] }, ptr %l82
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t175 = load ptr, ptr %l1, !tbaa !29
  %t177 = getelementptr %"compiler/typed:Slice", ptr %t175, i32 0, i32 3
  %t178 = load i32, ptr %t177
  %t179 = load i64, ptr @G_2ecompiler_2flower_2eOutOfBounds, !tbaa !24
  %t180 = load %"compiler/source:Span", ptr %l3
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2echeck(ptr %v0, ptr %t173, { i64, [4 x i64] } %t172, i32 %t178, i32 6, i64 %t179, %"compiler/source:Span" %t180)
  br label %bb19
bb19:
  %t187 = load ptr, ptr %l0, !tbaa !29
  %t188 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t189 = load { i64, [4 x i64] }, ptr %l8
  %t190 = load { i64, [4 x i64] }, ptr %l9
  %t191 = mul i64 2, 40
  %t192 = call ptr @__olang_scope_alloc_zeroed(ptr %s2, i64 %t191)
  %t193 = insertvalue { i64, ptr } undef, i64 2, 0
  %t194 = insertvalue { i64, ptr } %t193, ptr %t192, 1
  store { i64, ptr } %t194, ptr %l95, !tbaa !27
  %t196 = getelementptr { i64, ptr }, ptr %l95, i32 0, i32 1
  %t197 = load ptr, ptr %t196, !tbaa !27
  %t198 = getelementptr { i64, [4 x i64] }, ptr %t197, i64 0
  store { i64, [4 x i64] } %t189, ptr %t198
  %t200 = getelementptr { i64, ptr }, ptr %l95, i32 0, i32 1
  %t201 = load ptr, ptr %t200, !tbaa !27
  %t202 = getelementptr { i64, [4 x i64] }, ptr %t201, i64 1
  store { i64, [4 x i64] } %t190, ptr %t202
  %t203 = load %"compiler/source:Span", ptr %l3
  %t207 = load { i64, ptr }, ptr %l95, !tbaa !27
  %t209 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s2, ptr %t187, i32 16, i32 %t188, { i64, ptr } %t207, %"compiler/source:Span" %t203)
  store { i64, [4 x i64] } %t209, ptr %l97
  br label %bb20
bb20:
  %t210 = load { i64, [4 x i64] }, ptr %l97
  %t211 = load ptr, ptr %l0, !tbaa !29
  %t213 = load ptr, ptr %l1, !tbaa !29
  %t215 = getelementptr %"compiler/typed:Slice", ptr %t213, i32 0, i32 3
  %t216 = load i32, ptr %t215
  %t217 = load i64, ptr @G_2ecompiler_2flower_2eOutOfBounds, !tbaa !24
  %t218 = load %"compiler/source:Span", ptr %l3
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2echeck(ptr %v0, ptr %t211, { i64, [4 x i64] } %t210, i32 %t216, i32 6, i64 %t217, %"compiler/source:Span" %t218)
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s2)
  br label %bb22
bb22:
  %t225 = load ptr, ptr %l0, !tbaa !29
  store ptr %t225, ptr %l105, !tbaa !29
  %t226 = load i32, ptr %l2, !tbaa !23
  store i32 %t226, ptr %l106, !tbaa !23
  %t227 = load ptr, ptr %l0, !tbaa !29
  %t228 = load %"compiler/lower:pl", ptr %l4
  %t231 = call %"compiler/mir:Place" @compiler_2flower_2ecompiler_2flower_3alowering_2emk(ptr %v0, ptr %v0, ptr %t227, %"compiler/lower:pl" %t228)
  store %"compiler/mir:Place" %t231, ptr %l109
  br label %bb23
bb23:
  %t232 = load { i64, [4 x i64] }, ptr %l7
  %t233 = load { i64, [4 x i64] }, ptr %l8
  %t234 = load i32, ptr %l2, !tbaa !23
  store { i64, [15 x i64] } zeroinitializer, ptr %t235
  %t236 = getelementptr { i64, [15 x i64] }, ptr %t235, i32 0, i32 0
  store i64 9, ptr %t236
  %t237 = load %"compiler/mir:Place", ptr %l109
  %t238 = insertvalue { %"compiler/mir:Place", { i64, [4 x i64] }, { i64, [4 x i64] }, i32 } undef, %"compiler/mir:Place" %t237, 0
  %t240 = insertvalue { %"compiler/mir:Place", { i64, [4 x i64] }, { i64, [4 x i64] }, i32 } %t238, { i64, [4 x i64] } %t232, 1
  %t242 = insertvalue { %"compiler/mir:Place", { i64, [4 x i64] }, { i64, [4 x i64] }, i32 } %t240, { i64, [4 x i64] } %t233, 2
  %t244 = insertvalue { %"compiler/mir:Place", { i64, [4 x i64] }, { i64, [4 x i64] }, i32 } %t242, i32 %t234, 3
  %t245 = getelementptr { i64, [15 x i64] }, ptr %t235, i32 0, i32 1
  store { %"compiler/mir:Place", { i64, [4 x i64] }, { i64, [4 x i64] }, i32 } %t244, ptr %t245
  %t246 = load { i64, [15 x i64] }, ptr %t235
  %t247 = load %"compiler/source:Span", ptr %l3
  %t248 = load ptr, ptr %l105, !tbaa !29
  %t249 = load i32, ptr %l106, !tbaa !23
  %t252 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %t248, i32 %t249, { i64, [15 x i64] } %t246, %"compiler/source:Span" %t247)
  store { i64, [4 x i64] } %t252, ptr %l115
  br label %bb24
bb24:
  %t253 = load { i64, [4 x i64] }, ptr %l115
  store { i64, [4 x i64] } %t253, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2espawnErrors(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l1 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l17 = alloca { i64, ptr }
  %s3 = alloca %olang.scope
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t7 = getelementptr %"compiler/typed:Block", ptr %t5, i32 0, i32 1
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  store { i64, ptr } %t8, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l5, !tbaa !24
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s3
  %t14 = load i64, ptr %l4, !tbaa !24
  %t15 = load i64, ptr %l5, !tbaa !24
  %t18 = icmp slt i64 %t14, %t15
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s3)
  br label %bb10
bb6:
  br label %bb7
bb7:
  %t22 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t22, ptr %l17, !tbaa !27
  %t23 = load i64, ptr %l4, !tbaa !24
  %t25 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr ptr, ptr %t26, i64 %t23
  %t28 = load ptr, ptr %t27, !tbaa !39
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estmtSpawnErrors(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %t28, ptr %a2)
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s3)
  br label %bb9
bb9:
  %t36 = load i64, ptr %l4, !tbaa !24
  %t38 = add i64 %t36, 1
  store i64 %t38, ptr %l4, !tbaa !24
  br label %bb4
bb10:
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2flower_2ecompiler_2flower_3alowering_2espell(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i1 %a2, i1 %a3, i1 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i1
  %l3 = alloca i1
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca %"std/prelude/text:StringBuilder"
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l17 = alloca %"std/prelude/text:StringBuilder"
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca %"std/prelude/text:StringBuilder"
  %l26 = alloca i32
  %l27 = alloca { i64, ptr }
  %l28 = alloca i1
  %l29 = alloca i1
  %l30 = alloca { i64, ptr }
  %l31 = alloca { i64, ptr }
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca { i64, ptr }
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i64
  %l46 = alloca i64
  %l47 = alloca i64
  %l48 = alloca i64
  %l49 = alloca i64
  %l50 = alloca i64
  %l51 = alloca i64
  %l56 = alloca i32
  %l61 = alloca ptr
  %l62 = alloca ptr
  %l65 = alloca i32
  %l66 = alloca i32
  %l67 = alloca { i64, ptr }
  %l68 = alloca ptr
  %l71 = alloca i32
  %l72 = alloca { i64, ptr }
  %l78 = alloca %"std/prelude/text:StringBuilder"
  %l87 = alloca i64
  %l90 = alloca i64
  %l111 = alloca ptr
  %l113 = alloca { i64, ptr }
  %l116 = alloca { i64, ptr }
  %l122 = alloca { i64, ptr }
  %l123 = alloca { i64, ptr }
  %l124 = alloca i64
  %l125 = alloca { i64, ptr }
  %l130 = alloca i64
  %l134 = alloca { i64, ptr }
  %l135 = alloca { i64, ptr }
  %l136 = alloca ptr
  %l139 = alloca i32
  %l141 = alloca { i64, ptr }
  %l144 = alloca i64
  %l148 = alloca { i64, ptr }
  %l152 = alloca ptr
  %l155 = alloca i32
  %l157 = alloca { i64, ptr }
  %l161 = alloca ptr
  %l164 = alloca i32
  %l165 = alloca { i64, ptr }
  %l171 = alloca i64
  %l175 = alloca %"std/prelude/text:StringBuilder"
  %l176 = alloca ptr
  %l179 = alloca i32
  %l180 = alloca { i64, ptr }
  %l187 = alloca i64
  %l190 = alloca i64
  %l211 = alloca ptr
  %l213 = alloca { i64, ptr }
  %l216 = alloca { i64, ptr }
  %l222 = alloca { i64, ptr }
  %l223 = alloca { i64, ptr }
  %l224 = alloca i64
  %l225 = alloca { i64, ptr }
  %l228 = alloca %"std/prelude/text:StringBuilder"
  %l231 = alloca i32
  %l232 = alloca ptr
  %l235 = alloca i32
  %l236 = alloca { i64, ptr }
  %l239 = alloca i32
  %l242 = alloca i1
  %l243 = alloca ptr
  %l246 = alloca i32
  %l247 = alloca { i64, ptr }
  %l250 = alloca i1
  %l255 = alloca i1
  %l257 = alloca i1
  %l259 = alloca i1
  %l266 = alloca ptr
  %l269 = alloca i32
  %l270 = alloca { i64, ptr }
  %l273 = alloca { i64, ptr }
  %l279 = alloca i64
  %l282 = alloca i64
  %l308 = alloca ptr
  %l311 = alloca { i64, ptr }
  %l316 = alloca { i64, ptr }
  %l319 = alloca ptr
  %l321 = alloca { i64, ptr }
  %l324 = alloca { i64, ptr }
  %l331 = alloca i32
  %l334 = alloca ptr
  %l337 = alloca i32
  %l338 = alloca { i64, ptr }
  %l344 = alloca i64
  %l347 = alloca i64
  %l365 = alloca ptr
  %l368 = alloca { i64, ptr }
  %l370 = alloca { i64, ptr }
  %l373 = alloca { i64, ptr }
  %l384 = alloca i1
  %l387 = alloca i32
  %l390 = alloca i1
  %l391 = alloca ptr
  %l394 = alloca i32
  %l395 = alloca { i64, ptr }
  %l398 = alloca ptr
  %l402 = alloca { i64, ptr }
  %l414 = alloca i64
  %l417 = alloca i64
  %l435 = alloca ptr
  %l438 = alloca { i64, ptr }
  %l439 = alloca ptr
  %l441 = alloca { i64, ptr }
  %l444 = alloca i32
  %l445 = alloca { i64, ptr }
  %l453 = alloca { i64, ptr }
  %l454 = alloca { i64, ptr }
  %l455 = alloca i64
  %l456 = alloca { i64, ptr }
  %l459 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %s25 = alloca %olang.scope
  %s26 = alloca %olang.scope
  %s27 = alloca %olang.scope
  %s32 = alloca %olang.scope
  %s36 = alloca %olang.scope
  %s38 = alloca %olang.scope
  %s40 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i1 %a2, ptr %l2
  store i1 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l5, !tbaa !29
  %t6 = load ptr, ptr %l5, !tbaa !29
  %t7 = load i32, ptr %l1, !tbaa !23
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t6, i32 %t7)
  store i32 %t10, ptr %l56
  br label %bb1
bb1:
  %t11 = load i32, ptr %l56
  store i32 %t11, ptr %l6
  %t12 = load i32, ptr %l6
  %t14 = trunc i64 18 to i32
  %t15 = icmp eq i32 %t12, %t14
  br i1 %t15, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/lower:lowering", ptr %t17, i32 0, i32 2
  %t20 = load ptr, ptr %t19, !tbaa !29
  %t22 = getelementptr %"compiler/types:Table", ptr %t20, i32 0, i32 0
  %t23 = load ptr, ptr %t22, !tbaa !29
  store ptr %t23, ptr %l61, !tbaa !29
  %t24 = load ptr, ptr %l5, !tbaa !29
  store ptr %t24, ptr %l62, !tbaa !29
  %t25 = load ptr, ptr %l5, !tbaa !29
  %t26 = load i32, ptr %l1, !tbaa !23
  %t29 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t25, i32 %t26)
  store i32 %t29, ptr %l65
  br label %bb4
bb3:
  br label %bb35
bb4:
  %t30 = load ptr, ptr %l62, !tbaa !29
  %t31 = load i32, ptr %l65, !tbaa !23
  %t32 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %t30, i32 %t31)
  store i32 %t32, ptr %l66
  br label %bb5
bb5:
  %t33 = load ptr, ptr %l61, !tbaa !29
  %t34 = load i32, ptr %l66, !tbaa !23
  %t35 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t33, i32 %t34)
  store { i64, ptr } %t35, ptr %l67
  br label %bb6
bb6:
  %t36 = load { i64, ptr }, ptr %l67, !tbaa !27
  store { i64, ptr } %t36, ptr %l7, !tbaa !27
  %t37 = load ptr, ptr %l5, !tbaa !29
  store ptr %t37, ptr %l68, !tbaa !29
  %t38 = load ptr, ptr %l5, !tbaa !29
  %t39 = load i32, ptr %l1, !tbaa !23
  %t42 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %t38, i32 %t39)
  store i32 %t42, ptr %l71
  br label %bb7
bb7:
  %t43 = load ptr, ptr %l68, !tbaa !29
  %t44 = load i32, ptr %l71, !tbaa !23
  %t45 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t43, i32 %t44)
  store { i64, ptr } %t45, ptr %l72
  br label %bb8
bb8:
  %t46 = load { i64, ptr }, ptr %l72, !tbaa !27
  store { i64, ptr } %t46, ptr %l8, !tbaa !27
  %t47 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t49 = extractvalue { i64, ptr } %t47, 0
  %t51 = icmp eq i64 %t49, 0
  br i1 %t51, label %bb9, label %bb10
bb9:
  %t53 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t55 = extractvalue { i64, ptr } %t53, 1
  %t56 = extractvalue { i64, ptr } %t53, 0
  %t57 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t56)
  call void @olang_textcopy(ptr %t57, ptr %t55, i64 %t56)
  %t58 = insertvalue { i64, ptr } undef, i64 %t56, 0
  %t59 = insertvalue { i64, ptr } %t58, ptr %t57, 1
  call void @__olang_scope_close(ptr %s1)
  store { i64, ptr } %t59, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t61 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s1)
  store %"std/prelude/text:StringBuilder" %t61, ptr %l78
  br label %bb12
bb12:
  %t62 = load %"std/prelude/text:StringBuilder", ptr %l78
  store %"std/prelude/text:StringBuilder" %t62, ptr %l9
  %t63 = load { i64, ptr }, ptr %l7, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s1, ptr %v0, ptr %l9, { i64, ptr } %t63)
  br label %bb13
bb13:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s1, ptr %l9, i8 60)
  br label %bb14
bb14:
  store i64 0, ptr %l10, !tbaa !24
  %t67 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t69 = extractvalue { i64, ptr } %t67, 0
  store i64 %t69, ptr %l11, !tbaa !24
  store i64 1, ptr %l12, !tbaa !24
  %t71 = load i64, ptr %l11, !tbaa !24
  %t72 = load i64, ptr %l10, !tbaa !24
  %t75 = icmp sgt i64 %t71, %t72
  br i1 %t75, label %bb15, label %bb16
bb15:
  %t77 = load i64, ptr %l12, !tbaa !24
  %t79 = icmp sgt i64 %t77, 0
  br i1 %t79, label %bb17, label %bb18
bb16:
  store i64 0, ptr %l87, !tbaa !24
  br label %bb20
bb17:
  %t81 = load i64, ptr %l11, !tbaa !24
  %t82 = load i64, ptr %l10, !tbaa !24
  %t85 = sub i64 %t81, %t82
  %t86 = load i64, ptr %l12, !tbaa !24
  %t89 = add i64 %t85, %t86
  %t91 = sub i64 %t89, 1
  %t92 = load i64, ptr %l12, !tbaa !24
  %t95 = sdiv i64 %t91, %t92
  store i64 %t95, ptr %l90, !tbaa !24
  br label %bb19
bb18:
  store i64 0, ptr %l90, !tbaa !24
  br label %bb19
bb19:
  %t97 = load i64, ptr %l90, !tbaa !24
  store i64 %t97, ptr %l87, !tbaa !24
  br label %bb20
bb20:
  %t98 = load i64, ptr %l87, !tbaa !24
  store i64 %t98, ptr %l13, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  br label %bb21
bb21:
  store %olang.scope zeroinitializer, ptr %s5
  %t99 = load i64, ptr %l14, !tbaa !24
  %t100 = load i64, ptr %l13, !tbaa !24
  %t103 = icmp slt i64 %t99, %t100
  %t105 = xor i1 %t103, true
  br i1 %t105, label %bb22, label %bb23
bb22:
  call void @__olang_scope_close(ptr %s5)
  br label %bb32
bb23:
  br label %bb24
bb24:
  %t107 = load i64, ptr %l10, !tbaa !24
  %t108 = load i64, ptr %l14, !tbaa !24
  %t109 = load i64, ptr %l12, !tbaa !24
  %t112 = mul i64 %t108, %t109
  %t115 = add i64 %t107, %t112
  store i64 %t115, ptr %l15, !tbaa !24
  %t117 = load i64, ptr %l15, !tbaa !24
  %t119 = icmp sgt i64 %t117, 0
  br i1 %t119, label %bb25, label %bb26
bb25:
  store %olang.scope zeroinitializer, ptr %s6
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s1, ptr %s6, ptr %l9, { i64, ptr } { i64 2, ptr @.d23 })
  br label %bb27
bb26:
  br label %bb28
bb27:
  call void @__olang_scope_close(ptr %s6)
  br label %bb28
bb28:
  store ptr %l9, ptr %l111, !tbaa !29
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t123 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t123, ptr %l113, !tbaa !27
  %t124 = load i64, ptr %l15, !tbaa !24
  %t126 = getelementptr { i64, ptr }, ptr %l113, i32 0, i32 1
  %t127 = load ptr, ptr %t126, !tbaa !27
  %t128 = getelementptr i32, ptr %t127, i64 %t124
  %t129 = load i32, ptr %t128, !tbaa !33
  %t132 = call { i64, ptr } @compiler_2flower_2ecompiler_2flower_3alowering_2espell(ptr %v0, ptr %s5, ptr %t122, i32 %t129, i1 true, i1 true, i1 false)
  store { i64, ptr } %t132, ptr %l116
  br label %bb29
bb29:
  %t133 = load { i64, ptr }, ptr %l116, !tbaa !27
  %t134 = extractvalue { i64, ptr } %t133, 0
  %t135 = extractvalue { i64, ptr } %t133, 1
  %t136 = mul i64 %t134, 1
  %t137 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t136)
  call void @llvm.memcpy.p0.p0.i64(ptr %t137, ptr %t135, i64 %t136, i1 false)
  %t138 = insertvalue { i64, ptr } undef, i64 %t134, 0
  %t139 = insertvalue { i64, ptr } %t138, ptr %t137, 1
  %t140 = load ptr, ptr %l111, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s1, ptr %s5, ptr %t140, { i64, ptr } %t139)
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s5)
  br label %bb31
bb31:
  %t142 = load i64, ptr %l14, !tbaa !24
  %t144 = add i64 %t142, 1
  store i64 %t144, ptr %l14, !tbaa !24
  br label %bb21
bb32:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s1, ptr %l9, i8 62)
  br label %bb33
bb33:
  %t148 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s1, ptr %v1, ptr %l9)
  store { i64, ptr } %t148, ptr %l122
  br label %bb34
bb34:
  %t149 = load { i64, ptr }, ptr %l122, !tbaa !27
  store { i64, ptr } %t149, ptr %l123, !tbaa !27
  %t150 = load { i64, ptr }, ptr %l123, !tbaa !27
  %t151 = extractvalue { i64, ptr } %t150, 0
  store i64 %t151, ptr %l124, !tbaa !24
  %t152 = load i64, ptr %l124, !tbaa !24
  %t153 = mul i64 %t152, 1
  %t154 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t153)
  %t155 = insertvalue { i64, ptr } undef, i64 %t152, 0
  %t156 = insertvalue { i64, ptr } %t155, ptr %t154, 1
  store { i64, ptr } %t156, ptr %l125, !tbaa !27
  %t157 = getelementptr { i64, ptr }, ptr %l125, i32 0, i32 1
  %t158 = load ptr, ptr %t157, !tbaa !27
  %t159 = getelementptr { i64, ptr }, ptr %l123, i32 0, i32 1
  %t160 = load ptr, ptr %t159, !tbaa !27
  %t161 = load i64, ptr %l124, !tbaa !24
  %t162 = mul i64 %t161, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t158, ptr %t160, i64 %t162, i1 false)
  %t163 = load { i64, ptr }, ptr %l125, !tbaa !27
  store { i64, ptr } %t163, ptr %l123, !tbaa !27
  call void @__olang_scope_close(ptr %s1)
  %t164 = load { i64, ptr }, ptr %l123, !tbaa !27
  store { i64, ptr } %t164, ptr %rv
  br label %ret
bb35:
  %t165 = load i32, ptr %l6
  %t167 = trunc i64 20 to i32
  %t168 = icmp eq i32 %t165, %t167
  br i1 %t168, label %bb36, label %bb37
bb36:
  store %olang.scope zeroinitializer, ptr %s8
  %t170 = load ptr, ptr %l5, !tbaa !29
  %t171 = load i32, ptr %l1, !tbaa !23
  %t174 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t170, i32 %t171)
  store i64 %t174, ptr %l130
  br label %bb38
bb37:
  br label %bb48
bb38:
  %t175 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t176 = load i64, ptr %l130, !tbaa !24
  %t178 = and i64 %t176, %t175
  %t180 = icmp ne i64 %t178, 0
  br i1 %t180, label %bb39, label %bb40
bb39:
  store { i64, ptr } { i64 4, ptr @.d24 }, ptr %l134, !tbaa !27
  br label %bb41
bb40:
  store { i64, ptr } { i64 0, ptr @.d25 }, ptr %l134, !tbaa !27
  br label %bb41
bb41:
  %t182 = load { i64, ptr }, ptr %l134, !tbaa !27
  store { i64, ptr } %t182, ptr %l135, !tbaa !27
  %t184 = load ptr, ptr %l0, !tbaa !29
  store ptr %t184, ptr %l136, !tbaa !29
  %t185 = load ptr, ptr %l5, !tbaa !29
  %t186 = load i32, ptr %l1, !tbaa !23
  %t189 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t185, i32 %t186)
  store i32 %t189, ptr %l139
  br label %bb42
bb42:
  %t190 = load i1, ptr %l3, !tbaa !21
  %t191 = load ptr, ptr %l136, !tbaa !29
  %t192 = load i32, ptr %l139, !tbaa !23
  %t194 = call { i64, ptr } @compiler_2flower_2ecompiler_2flower_3alowering_2espell(ptr %v0, ptr %s8, ptr %t191, i32 %t192, i1 true, i1 %t190, i1 false)
  store { i64, ptr } %t194, ptr %l141
  br label %bb43
bb43:
  %t195 = load ptr, ptr %l5, !tbaa !29
  %t196 = load i32, ptr %l1, !tbaa !23
  %t199 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t195, i32 %t196)
  store i64 %t199, ptr %l144
  br label %bb44
bb44:
  %t200 = load i64, ptr @G_2ecompiler_2ftypes_2eNullable, !tbaa !24
  %t201 = load i64, ptr %l144, !tbaa !24
  %t203 = and i64 %t201, %t200
  %t205 = icmp ne i64 %t203, 0
  br i1 %t205, label %bb45, label %bb46
bb45:
  store { i64, ptr } { i64 2, ptr @.d26 }, ptr %l148, !tbaa !27
  br label %bb47
bb46:
  store { i64, ptr } { i64 1, ptr @.d27 }, ptr %l148, !tbaa !27
  br label %bb47
bb47:
  %t207 = load { i64, ptr }, ptr %l135, !tbaa !27
  %t208 = extractvalue { i64, ptr } %t207, 1
  %t209 = extractvalue { i64, ptr } %t207, 0
  %t210 = load { i64, ptr }, ptr %l141, !tbaa !27
  %t211 = extractvalue { i64, ptr } %t210, 1
  %t212 = extractvalue { i64, ptr } %t210, 0
  %t213 = add i64 %t209, %t212
  %t214 = load { i64, ptr }, ptr %l148, !tbaa !27
  %t215 = extractvalue { i64, ptr } %t214, 1
  %t216 = extractvalue { i64, ptr } %t214, 0
  %t217 = add i64 %t213, %t216
  %t218 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t217)
  call void @olang_textcopy(ptr %t218, ptr %t208, i64 %t209)
  %t219 = getelementptr i8, ptr %t218, i64 %t209
  call void @olang_textcopy(ptr %t219, ptr %t211, i64 %t212)
  %t220 = getelementptr i8, ptr %t219, i64 %t212
  call void @olang_textcopy(ptr %t220, ptr %t215, i64 %t216)
  %t221 = insertvalue { i64, ptr } undef, i64 %t217, 0
  %t222 = insertvalue { i64, ptr } %t221, ptr %t218, 1
  call void @__olang_scope_close(ptr %s8)
  store { i64, ptr } %t222, ptr %rv
  br label %ret
bb48:
  %t224 = load i32, ptr %l6
  %t226 = trunc i64 29 to i32
  %t227 = icmp eq i32 %t224, %t226
  br i1 %t227, label %bb49, label %bb50
bb49:
  store %olang.scope zeroinitializer, ptr %s10
  %t229 = load ptr, ptr %l0, !tbaa !29
  store ptr %t229, ptr %l152, !tbaa !29
  %t230 = load ptr, ptr %l5, !tbaa !29
  %t231 = load i32, ptr %l1, !tbaa !23
  %t234 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAnyTrait(ptr %v0, ptr %t230, i32 %t231)
  store i32 %t234, ptr %l155
  br label %bb51
bb50:
  br label %bb53
bb51:
  %t235 = load i1, ptr %l3, !tbaa !21
  %t236 = load ptr, ptr %l152, !tbaa !29
  %t237 = load i32, ptr %l155, !tbaa !23
  %t239 = call { i64, ptr } @compiler_2flower_2ecompiler_2flower_3alowering_2espell(ptr %v0, ptr %s10, ptr %t236, i32 %t237, i1 true, i1 %t235, i1 false)
  store { i64, ptr } %t239, ptr %l157
  br label %bb52
bb52:
  %t240 = extractvalue { i64, ptr } { i64 4, ptr @.d28 }, 1
  %t241 = extractvalue { i64, ptr } { i64 4, ptr @.d28 }, 0
  %t242 = load { i64, ptr }, ptr %l157, !tbaa !27
  %t243 = extractvalue { i64, ptr } %t242, 1
  %t244 = extractvalue { i64, ptr } %t242, 0
  %t245 = add i64 %t241, %t244
  %t246 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t245)
  call void @olang_textcopy(ptr %t246, ptr %t240, i64 %t241)
  %t247 = getelementptr i8, ptr %t246, i64 %t241
  call void @olang_textcopy(ptr %t247, ptr %t243, i64 %t244)
  %t248 = insertvalue { i64, ptr } undef, i64 %t245, 0
  %t249 = insertvalue { i64, ptr } %t248, ptr %t246, 1
  call void @__olang_scope_close(ptr %s10)
  store { i64, ptr } %t249, ptr %rv
  br label %ret
bb53:
  %t251 = load i32, ptr %l6
  %t253 = trunc i64 19 to i32
  %t254 = icmp eq i32 %t251, %t253
  br i1 %t254, label %bb54, label %bb55
bb54:
  store %olang.scope zeroinitializer, ptr %s12
  %t256 = load ptr, ptr %l0, !tbaa !29
  store ptr %t256, ptr %l161, !tbaa !29
  %t257 = load ptr, ptr %l5, !tbaa !29
  %t258 = load i32, ptr %l1, !tbaa !23
  %t261 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t257, i32 %t258)
  store i32 %t261, ptr %l164
  br label %bb56
bb55:
  br label %bb58
bb56:
  %t262 = load ptr, ptr %l161, !tbaa !29
  %t263 = load i32, ptr %l164, !tbaa !23
  %t264 = call { i64, ptr } @compiler_2flower_2ecompiler_2flower_3alowering_2espell(ptr %v0, ptr %s12, ptr %t262, i32 %t263, i1 true, i1 true, i1 false)
  store { i64, ptr } %t264, ptr %l165
  br label %bb57
bb57:
  %t265 = extractvalue { i64, ptr } { i64 6, ptr @.d29 }, 1
  %t266 = extractvalue { i64, ptr } { i64 6, ptr @.d29 }, 0
  %t267 = load { i64, ptr }, ptr %l165, !tbaa !27
  %t268 = extractvalue { i64, ptr } %t267, 1
  %t269 = extractvalue { i64, ptr } %t267, 0
  %t270 = add i64 %t266, %t269
  %t271 = extractvalue { i64, ptr } { i64 1, ptr @.d30 }, 1
  %t272 = extractvalue { i64, ptr } { i64 1, ptr @.d30 }, 0
  %t273 = add i64 %t270, %t272
  %t274 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t273)
  call void @olang_textcopy(ptr %t274, ptr %t265, i64 %t266)
  %t275 = getelementptr i8, ptr %t274, i64 %t266
  call void @olang_textcopy(ptr %t275, ptr %t268, i64 %t269)
  %t276 = getelementptr i8, ptr %t275, i64 %t269
  call void @olang_textcopy(ptr %t276, ptr %t271, i64 %t272)
  %t277 = insertvalue { i64, ptr } undef, i64 %t273, 0
  %t278 = insertvalue { i64, ptr } %t277, ptr %t274, 1
  call void @__olang_scope_close(ptr %s12)
  store { i64, ptr } %t278, ptr %rv
  br label %ret
bb58:
  %t280 = load i32, ptr %l6
  %t282 = trunc i64 26 to i32
  %t283 = icmp eq i32 %t280, %t282
  br i1 %t283, label %bb59, label %bb60
bb59:
  %t285 = load ptr, ptr %l5, !tbaa !29
  %t286 = load i32, ptr %l1, !tbaa !23
  %t289 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstValue(ptr %v0, ptr %t285, i32 %t286)
  store i64 %t289, ptr %l171
  br label %bb61
bb60:
  br label %bb62
bb61:
  %t290 = load i64, ptr %l171, !tbaa !24
  %t291 = call i64 @__olang_fmt_i64(ptr null, i64 %t290)
  %t292 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t291)
  %t293 = call i64 @__olang_fmt_i64(ptr %t292, i64 %t290)
  %t294 = insertvalue { i64, ptr } undef, i64 %t291, 0
  %t295 = insertvalue { i64, ptr } %t294, ptr %t292, 1
  store { i64, ptr } %t295, ptr %rv
  br label %ret
bb62:
  %t297 = load i32, ptr %l6
  %t299 = trunc i64 22 to i32
  %t300 = icmp eq i32 %t297, %t299
  br i1 %t300, label %bb63, label %bb64
bb63:
  store %olang.scope zeroinitializer, ptr %s16
  %t302 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s16)
  store %"std/prelude/text:StringBuilder" %t302, ptr %l175
  br label %bb65
bb64:
  br label %bb89
bb65:
  %t303 = load %"std/prelude/text:StringBuilder", ptr %l175
  store %"std/prelude/text:StringBuilder" %t303, ptr %l17
  %t304 = load ptr, ptr %l5, !tbaa !29
  store ptr %t304, ptr %l176, !tbaa !29
  %t305 = load ptr, ptr %l5, !tbaa !29
  %t306 = load i32, ptr %l1, !tbaa !23
  %t309 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t305, i32 %t306)
  store i32 %t309, ptr %l179
  br label %bb66
bb66:
  %t310 = load ptr, ptr %l176, !tbaa !29
  %t311 = load i32, ptr %l179, !tbaa !23
  %t312 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t310, i32 %t311)
  store { i64, ptr } %t312, ptr %l180
  br label %bb67
bb67:
  %t313 = load { i64, ptr }, ptr %l180, !tbaa !27
  store { i64, ptr } %t313, ptr %l18, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s16, ptr %l17, i8 40)
  br label %bb68
bb68:
  store i64 0, ptr %l19, !tbaa !24
  %t315 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t317 = extractvalue { i64, ptr } %t315, 0
  store i64 %t317, ptr %l20, !tbaa !24
  store i64 1, ptr %l21, !tbaa !24
  %t319 = load i64, ptr %l20, !tbaa !24
  %t320 = load i64, ptr %l19, !tbaa !24
  %t323 = icmp sgt i64 %t319, %t320
  br i1 %t323, label %bb69, label %bb70
bb69:
  %t325 = load i64, ptr %l21, !tbaa !24
  %t327 = icmp sgt i64 %t325, 0
  br i1 %t327, label %bb71, label %bb72
bb70:
  store i64 0, ptr %l187, !tbaa !24
  br label %bb74
bb71:
  %t329 = load i64, ptr %l20, !tbaa !24
  %t330 = load i64, ptr %l19, !tbaa !24
  %t333 = sub i64 %t329, %t330
  %t334 = load i64, ptr %l21, !tbaa !24
  %t337 = add i64 %t333, %t334
  %t339 = sub i64 %t337, 1
  %t340 = load i64, ptr %l21, !tbaa !24
  %t343 = sdiv i64 %t339, %t340
  store i64 %t343, ptr %l190, !tbaa !24
  br label %bb73
bb72:
  store i64 0, ptr %l190, !tbaa !24
  br label %bb73
bb73:
  %t345 = load i64, ptr %l190, !tbaa !24
  store i64 %t345, ptr %l187, !tbaa !24
  br label %bb74
bb74:
  %t346 = load i64, ptr %l187, !tbaa !24
  store i64 %t346, ptr %l22, !tbaa !24
  store i64 0, ptr %l23, !tbaa !24
  br label %bb75
bb75:
  store %olang.scope zeroinitializer, ptr %s18
  %t347 = load i64, ptr %l23, !tbaa !24
  %t348 = load i64, ptr %l22, !tbaa !24
  %t351 = icmp slt i64 %t347, %t348
  %t353 = xor i1 %t351, true
  br i1 %t353, label %bb76, label %bb77
bb76:
  call void @__olang_scope_close(ptr %s18)
  br label %bb86
bb77:
  br label %bb78
bb78:
  %t355 = load i64, ptr %l19, !tbaa !24
  %t356 = load i64, ptr %l23, !tbaa !24
  %t357 = load i64, ptr %l21, !tbaa !24
  %t360 = mul i64 %t356, %t357
  %t363 = add i64 %t355, %t360
  store i64 %t363, ptr %l24, !tbaa !24
  %t365 = load i64, ptr %l24, !tbaa !24
  %t367 = icmp sgt i64 %t365, 0
  br i1 %t367, label %bb79, label %bb80
bb79:
  store %olang.scope zeroinitializer, ptr %s19
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s16, ptr %s19, ptr %l17, { i64, ptr } { i64 2, ptr @.d31 })
  br label %bb81
bb80:
  br label %bb82
bb81:
  call void @__olang_scope_close(ptr %s19)
  br label %bb82
bb82:
  store ptr %l17, ptr %l211, !tbaa !29
  %t370 = load ptr, ptr %l0, !tbaa !29
  %t371 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t371, ptr %l213, !tbaa !27
  %t372 = load i64, ptr %l24, !tbaa !24
  %t374 = getelementptr { i64, ptr }, ptr %l213, i32 0, i32 1
  %t375 = load ptr, ptr %t374, !tbaa !27
  %t376 = getelementptr i32, ptr %t375, i64 %t372
  %t377 = load i32, ptr %t376, !tbaa !33
  %t380 = call { i64, ptr } @compiler_2flower_2ecompiler_2flower_3alowering_2espell(ptr %v0, ptr %s18, ptr %t370, i32 %t377, i1 true, i1 true, i1 false)
  store { i64, ptr } %t380, ptr %l216
  br label %bb83
bb83:
  %t381 = load { i64, ptr }, ptr %l216, !tbaa !27
  %t382 = extractvalue { i64, ptr } %t381, 0
  %t383 = extractvalue { i64, ptr } %t381, 1
  %t384 = mul i64 %t382, 1
  %t385 = call ptr @__olang_scope_alloc(ptr %s18, i64 %t384)
  call void @llvm.memcpy.p0.p0.i64(ptr %t385, ptr %t383, i64 %t384, i1 false)
  %t386 = insertvalue { i64, ptr } undef, i64 %t382, 0
  %t387 = insertvalue { i64, ptr } %t386, ptr %t385, 1
  %t388 = load ptr, ptr %l211, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s16, ptr %s18, ptr %t388, { i64, ptr } %t387)
  br label %bb84
bb84:
  call void @__olang_scope_close(ptr %s18)
  br label %bb85
bb85:
  %t390 = load i64, ptr %l23, !tbaa !24
  %t392 = add i64 %t390, 1
  store i64 %t392, ptr %l23, !tbaa !24
  br label %bb75
bb86:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s16, ptr %l17, i8 41)
  br label %bb87
bb87:
  %t396 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s16, ptr %v1, ptr %l17)
  store { i64, ptr } %t396, ptr %l222
  br label %bb88
bb88:
  %t397 = load { i64, ptr }, ptr %l222, !tbaa !27
  store { i64, ptr } %t397, ptr %l223, !tbaa !27
  %t398 = load { i64, ptr }, ptr %l223, !tbaa !27
  %t399 = extractvalue { i64, ptr } %t398, 0
  store i64 %t399, ptr %l224, !tbaa !24
  %t400 = load i64, ptr %l224, !tbaa !24
  %t401 = mul i64 %t400, 1
  %t402 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t401)
  %t403 = insertvalue { i64, ptr } undef, i64 %t400, 0
  %t404 = insertvalue { i64, ptr } %t403, ptr %t402, 1
  store { i64, ptr } %t404, ptr %l225, !tbaa !27
  %t405 = getelementptr { i64, ptr }, ptr %l225, i32 0, i32 1
  %t406 = load ptr, ptr %t405, !tbaa !27
  %t407 = getelementptr { i64, ptr }, ptr %l223, i32 0, i32 1
  %t408 = load ptr, ptr %t407, !tbaa !27
  %t409 = load i64, ptr %l224, !tbaa !24
  %t410 = mul i64 %t409, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t406, ptr %t408, i64 %t410, i1 false)
  %t411 = load { i64, ptr }, ptr %l225, !tbaa !27
  store { i64, ptr } %t411, ptr %l223, !tbaa !27
  call void @__olang_scope_close(ptr %s16)
  %t412 = load { i64, ptr }, ptr %l223, !tbaa !27
  store { i64, ptr } %t412, ptr %rv
  br label %ret
bb89:
  %t413 = load i32, ptr %l6
  %t415 = trunc i64 21 to i32
  %t416 = icmp eq i32 %t413, %t415
  br i1 %t416, label %bb90, label %bb91
bb90:
  store %olang.scope zeroinitializer, ptr %s21
  %t418 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s21)
  store %"std/prelude/text:StringBuilder" %t418, ptr %l228
  br label %bb92
bb91:
  br label %bb214
bb92:
  %t419 = load %"std/prelude/text:StringBuilder", ptr %l228
  store %"std/prelude/text:StringBuilder" %t419, ptr %l25
  %t420 = load ptr, ptr %l5, !tbaa !29
  %t421 = load i32, ptr %l1, !tbaa !23
  %t424 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t420, i32 %t421)
  store i32 %t424, ptr %l231
  br label %bb93
bb93:
  %t425 = load i32, ptr %l231, !tbaa !23
  store i32 %t425, ptr %l26, !tbaa !23
  %t426 = load ptr, ptr %l5, !tbaa !29
  store ptr %t426, ptr %l232, !tbaa !29
  %t427 = load ptr, ptr %l5, !tbaa !29
  %t428 = load i32, ptr %l1, !tbaa !23
  %t431 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t427, i32 %t428)
  store i32 %t431, ptr %l235
  br label %bb94
bb94:
  %t432 = load ptr, ptr %l232, !tbaa !29
  %t433 = load i32, ptr %l235, !tbaa !23
  %t434 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t432, i32 %t433)
  store { i64, ptr } %t434, ptr %l236
  br label %bb95
bb95:
  %t435 = load { i64, ptr }, ptr %l236, !tbaa !27
  store { i64, ptr } %t435, ptr %l27, !tbaa !27
  %t436 = load ptr, ptr %l5, !tbaa !29
  %t437 = load i32, ptr %l26, !tbaa !23
  %t440 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t436, i32 %t437)
  store i32 %t440, ptr %l239
  br label %bb96
bb96:
  %t441 = load i32, ptr %l239
  %t443 = trunc i64 22 to i32
  %t444 = icmp eq i32 %t441, %t443
  br i1 %t444, label %bb97, label %bb98
bb97:
  %t446 = load ptr, ptr %l5, !tbaa !29
  store ptr %t446, ptr %l243, !tbaa !29
  %t447 = load ptr, ptr %l5, !tbaa !29
  %t448 = load i32, ptr %l26, !tbaa !23
  %t451 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t447, i32 %t448)
  store i32 %t451, ptr %l246
  br label %bb99
bb98:
  store i1 false, ptr %l242, !tbaa !21
  br label %bb101
bb99:
  %t452 = load ptr, ptr %l243, !tbaa !29
  %t453 = load i32, ptr %l246, !tbaa !23
  %t454 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t452, i32 %t453)
  store { i64, ptr } %t454, ptr %l247
  br label %bb100
bb100:
  %t455 = load { i64, ptr }, ptr %l247, !tbaa !27
  %t456 = extractvalue { i64, ptr } %t455, 0
  %t458 = icmp sgt i64 %t456, 1
  store i1 %t458, ptr %l242, !tbaa !21
  br label %bb101
bb101:
  %t460 = load i1, ptr %l242, !tbaa !21
  br i1 %t460, label %bb102, label %bb103
bb102:
  store i1 true, ptr %l250, !tbaa !21
  br label %bb104
bb103:
  %t461 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t463 = extractvalue { i64, ptr } %t461, 0
  %t465 = icmp sgt i64 %t463, 1
  store i1 %t465, ptr %l250, !tbaa !21
  br label %bb104
bb104:
  %t467 = load i1, ptr %l250, !tbaa !21
  store i1 %t467, ptr %l28, !tbaa !21
  %t468 = load i1, ptr %l2, !tbaa !21
  br i1 %t468, label %bb105, label %bb106
bb105:
  br i1 %a4, label %bb107, label %bb108
bb106:
  store i1 false, ptr %l255, !tbaa !21
  br label %bb113
bb107:
  store i1 true, ptr %l257, !tbaa !21
  br label %bb112
bb108:
  %t472 = load i1, ptr %l3, !tbaa !21
  br i1 %t472, label %bb109, label %bb110
bb109:
  %t474 = load i1, ptr %l28, !tbaa !21
  store i1 %t474, ptr %l259, !tbaa !21
  br label %bb111
bb110:
  store i1 false, ptr %l259, !tbaa !21
  br label %bb111
bb111:
  %t476 = load i1, ptr %l259, !tbaa !21
  store i1 %t476, ptr %l257, !tbaa !21
  br label %bb112
bb112:
  %t477 = load i1, ptr %l257, !tbaa !21
  store i1 %t477, ptr %l255, !tbaa !21
  br label %bb113
bb113:
  %t478 = load i1, ptr %l255, !tbaa !21
  store i1 %t478, ptr %l29, !tbaa !21
  %t479 = load i1, ptr %l29, !tbaa !21
  br i1 %t479, label %bb114, label %bb115
bb114:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s21, ptr %l25, i8 40)
  br label %bb116
bb115:
  br label %bb117
bb116:
  br label %bb117
bb117:
  %t482 = load i1, ptr %l2, !tbaa !21
  br i1 %t482, label %bb118, label %bb119
bb118:
  store %olang.scope zeroinitializer, ptr %s23
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s21, ptr %s23, ptr %l25, { i64, ptr } { i64 2, ptr @.d32 })
  br label %bb120
bb119:
  br label %bb121
bb120:
  call void @__olang_scope_close(ptr %s23)
  br label %bb121
bb121:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s21, ptr %l25, i8 40)
  br label %bb122
bb122:
  %t486 = load ptr, ptr %l5, !tbaa !29
  store ptr %t486, ptr %l266, !tbaa !29
  %t487 = load ptr, ptr %l5, !tbaa !29
  %t488 = load i32, ptr %l1, !tbaa !23
  %t491 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t487, i32 %t488)
  store i32 %t491, ptr %l269
  br label %bb123
bb123:
  %t492 = load ptr, ptr %l266, !tbaa !29
  %t493 = load i32, ptr %l269, !tbaa !23
  %t494 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t492, i32 %t493)
  store { i64, ptr } %t494, ptr %l270
  br label %bb124
bb124:
  %t495 = load { i64, ptr }, ptr %l270, !tbaa !27
  store { i64, ptr } %t495, ptr %l30, !tbaa !27
  %t496 = load ptr, ptr %l5, !tbaa !29
  %t497 = load i32, ptr %l1, !tbaa !23
  %t500 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNamesOf(ptr %v0, ptr %t496, i32 %t497)
  store { i64, ptr } %t500, ptr %l273
  br label %bb125
bb125:
  %t501 = load { i64, ptr }, ptr %l273, !tbaa !27
  store { i64, ptr } %t501, ptr %l31, !tbaa !27
  store i64 0, ptr %l32, !tbaa !24
  %t502 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t504 = extractvalue { i64, ptr } %t502, 0
  store i64 %t504, ptr %l33, !tbaa !24
  store i64 1, ptr %l34, !tbaa !24
  %t506 = load i64, ptr %l33, !tbaa !24
  %t507 = load i64, ptr %l32, !tbaa !24
  %t510 = icmp sgt i64 %t506, %t507
  br i1 %t510, label %bb126, label %bb127
bb126:
  %t512 = load i64, ptr %l34, !tbaa !24
  %t514 = icmp sgt i64 %t512, 0
  br i1 %t514, label %bb128, label %bb129
bb127:
  store i64 0, ptr %l279, !tbaa !24
  br label %bb131
bb128:
  %t516 = load i64, ptr %l33, !tbaa !24
  %t517 = load i64, ptr %l32, !tbaa !24
  %t520 = sub i64 %t516, %t517
  %t521 = load i64, ptr %l34, !tbaa !24
  %t524 = add i64 %t520, %t521
  %t526 = sub i64 %t524, 1
  %t527 = load i64, ptr %l34, !tbaa !24
  %t530 = sdiv i64 %t526, %t527
  store i64 %t530, ptr %l282, !tbaa !24
  br label %bb130
bb129:
  store i64 0, ptr %l282, !tbaa !24
  br label %bb130
bb130:
  %t532 = load i64, ptr %l282, !tbaa !24
  store i64 %t532, ptr %l279, !tbaa !24
  br label %bb131
bb131:
  %t533 = load i64, ptr %l279, !tbaa !24
  store i64 %t533, ptr %l35, !tbaa !24
  store i64 0, ptr %l36, !tbaa !24
  br label %bb132
bb132:
  store %olang.scope zeroinitializer, ptr %s25
  %t534 = load i64, ptr %l36, !tbaa !24
  %t535 = load i64, ptr %l35, !tbaa !24
  %t538 = icmp slt i64 %t534, %t535
  %t540 = xor i1 %t538, true
  br i1 %t540, label %bb133, label %bb134
bb133:
  call void @__olang_scope_close(ptr %s25)
  br label %bb148
bb134:
  br label %bb135
bb135:
  %t542 = load i64, ptr %l32, !tbaa !24
  %t543 = load i64, ptr %l36, !tbaa !24
  %t544 = load i64, ptr %l34, !tbaa !24
  %t547 = mul i64 %t543, %t544
  %t550 = add i64 %t542, %t547
  store i64 %t550, ptr %l37, !tbaa !24
  %t552 = load i64, ptr %l37, !tbaa !24
  %t554 = icmp sgt i64 %t552, 0
  br i1 %t554, label %bb136, label %bb137
bb136:
  store %olang.scope zeroinitializer, ptr %s26
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s21, ptr %s26, ptr %l25, { i64, ptr } { i64 2, ptr @.d33 })
  br label %bb138
bb137:
  br label %bb139
bb138:
  call void @__olang_scope_close(ptr %s26)
  br label %bb139
bb139:
  %t557 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t559 = extractvalue { i64, ptr } %t557, 0
  %t560 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t562 = extractvalue { i64, ptr } %t560, 0
  %t565 = icmp eq i64 %t559, %t562
  br i1 %t565, label %bb140, label %bb141
bb140:
  store %olang.scope zeroinitializer, ptr %s27
  store ptr %l25, ptr %l308, !tbaa !29
  %t567 = load ptr, ptr %l5, !tbaa !29
  %t569 = getelementptr %"compiler/types:Table", ptr %t567, i32 0, i32 0
  %t570 = load ptr, ptr %t569, !tbaa !29
  %t571 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t571, ptr %l311, !tbaa !27
  %t572 = load i64, ptr %l37, !tbaa !24
  %t574 = getelementptr { i64, ptr }, ptr %l311, i32 0, i32 1
  %t575 = load ptr, ptr %t574, !tbaa !27
  %t576 = getelementptr i64, ptr %t575, i64 %t572
  %t577 = load i64, ptr %t576, !tbaa !34
  %t579 = trunc i64 %t577 to i32
  %t583 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t570, i32 %t579)
  store { i64, ptr } %t583, ptr %l316
  br label %bb142
bb141:
  br label %bb144
bb142:
  %t584 = load { i64, ptr }, ptr %l316, !tbaa !27
  %t585 = extractvalue { i64, ptr } %t584, 1
  %t586 = extractvalue { i64, ptr } %t584, 0
  %t587 = extractvalue { i64, ptr } { i64 1, ptr @.d34 }, 1
  %t588 = extractvalue { i64, ptr } { i64 1, ptr @.d34 }, 0
  %t589 = add i64 %t586, %t588
  %t590 = call ptr @__olang_scope_alloc(ptr %s27, i64 %t589)
  call void @olang_textcopy(ptr %t590, ptr %t585, i64 %t586)
  %t591 = getelementptr i8, ptr %t590, i64 %t586
  call void @olang_textcopy(ptr %t591, ptr %t587, i64 %t588)
  %t592 = insertvalue { i64, ptr } undef, i64 %t589, 0
  %t593 = insertvalue { i64, ptr } %t592, ptr %t590, 1
  %t595 = extractvalue { i64, ptr } %t593, 0
  %t596 = extractvalue { i64, ptr } %t593, 1
  %t597 = mul i64 %t595, 1
  %t598 = call ptr @__olang_scope_alloc(ptr %s27, i64 %t597)
  call void @llvm.memcpy.p0.p0.i64(ptr %t598, ptr %t596, i64 %t597, i1 false)
  %t599 = insertvalue { i64, ptr } undef, i64 %t595, 0
  %t600 = insertvalue { i64, ptr } %t599, ptr %t598, 1
  %t601 = load ptr, ptr %l308, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s21, ptr %s27, ptr %t601, { i64, ptr } %t600)
  br label %bb143
bb143:
  call void @__olang_scope_close(ptr %s27)
  br label %bb144
bb144:
  store ptr %l25, ptr %l319, !tbaa !29
  %t603 = load ptr, ptr %l0, !tbaa !29
  %t604 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t604, ptr %l321, !tbaa !27
  %t605 = load i64, ptr %l37, !tbaa !24
  %t607 = getelementptr { i64, ptr }, ptr %l321, i32 0, i32 1
  %t608 = load ptr, ptr %t607, !tbaa !27
  %t609 = getelementptr i32, ptr %t608, i64 %t605
  %t610 = load i32, ptr %t609, !tbaa !33
  %t613 = call { i64, ptr } @compiler_2flower_2ecompiler_2flower_3alowering_2espell(ptr %v0, ptr %s25, ptr %t603, i32 %t610, i1 true, i1 true, i1 false)
  store { i64, ptr } %t613, ptr %l324
  br label %bb145
bb145:
  %t614 = load { i64, ptr }, ptr %l324, !tbaa !27
  %t615 = extractvalue { i64, ptr } %t614, 0
  %t616 = extractvalue { i64, ptr } %t614, 1
  %t617 = mul i64 %t615, 1
  %t618 = call ptr @__olang_scope_alloc(ptr %s25, i64 %t617)
  call void @llvm.memcpy.p0.p0.i64(ptr %t618, ptr %t616, i64 %t617, i1 false)
  %t619 = insertvalue { i64, ptr } undef, i64 %t615, 0
  %t620 = insertvalue { i64, ptr } %t619, ptr %t618, 1
  %t621 = load ptr, ptr %l319, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s21, ptr %s25, ptr %t621, { i64, ptr } %t620)
  br label %bb146
bb146:
  call void @__olang_scope_close(ptr %s25)
  br label %bb147
bb147:
  %t623 = load i64, ptr %l36, !tbaa !24
  %t625 = add i64 %t623, 1
  store i64 %t625, ptr %l36, !tbaa !24
  br label %bb132
bb148:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s21, ptr %l25, i8 41)
  br label %bb149
bb149:
  %t628 = load ptr, ptr %l5, !tbaa !29
  %t629 = load i32, ptr %l26, !tbaa !23
  %t632 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t628, i32 %t629)
  store i32 %t632, ptr %l331
  br label %bb150
bb150:
  %t633 = load i32, ptr %l331
  %t635 = trunc i64 22 to i32
  %t636 = icmp eq i32 %t633, %t635
  br i1 %t636, label %bb151, label %bb152
bb151:
  %t638 = load ptr, ptr %l5, !tbaa !29
  store ptr %t638, ptr %l334, !tbaa !29
  %t639 = load ptr, ptr %l5, !tbaa !29
  %t640 = load i32, ptr %l26, !tbaa !23
  %t643 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t639, i32 %t640)
  store i32 %t643, ptr %l337
  br label %bb153
bb152:
  %t644 = load i32, ptr %l26, !tbaa !23
  %t645 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t648 = icmp ne i32 %t644, %t645
  br i1 %t648, label %bb172, label %bb173
bb153:
  %t650 = load ptr, ptr %l334, !tbaa !29
  %t651 = load i32, ptr %l337, !tbaa !23
  %t652 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t650, i32 %t651)
  store { i64, ptr } %t652, ptr %l338
  br label %bb154
bb154:
  %t653 = load { i64, ptr }, ptr %l338, !tbaa !27
  store { i64, ptr } %t653, ptr %l38, !tbaa !27
  store i64 0, ptr %l39, !tbaa !24
  %t654 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t656 = extractvalue { i64, ptr } %t654, 0
  store i64 %t656, ptr %l40, !tbaa !24
  store i64 1, ptr %l41, !tbaa !24
  %t658 = load i64, ptr %l40, !tbaa !24
  %t659 = load i64, ptr %l39, !tbaa !24
  %t662 = icmp sgt i64 %t658, %t659
  br i1 %t662, label %bb155, label %bb156
bb155:
  %t664 = load i64, ptr %l41, !tbaa !24
  %t666 = icmp sgt i64 %t664, 0
  br i1 %t666, label %bb157, label %bb158
bb156:
  store i64 0, ptr %l344, !tbaa !24
  br label %bb160
bb157:
  %t668 = load i64, ptr %l40, !tbaa !24
  %t669 = load i64, ptr %l39, !tbaa !24
  %t672 = sub i64 %t668, %t669
  %t673 = load i64, ptr %l41, !tbaa !24
  %t676 = add i64 %t672, %t673
  %t678 = sub i64 %t676, 1
  %t679 = load i64, ptr %l41, !tbaa !24
  %t682 = sdiv i64 %t678, %t679
  store i64 %t682, ptr %l347, !tbaa !24
  br label %bb159
bb158:
  store i64 0, ptr %l347, !tbaa !24
  br label %bb159
bb159:
  %t684 = load i64, ptr %l347, !tbaa !24
  store i64 %t684, ptr %l344, !tbaa !24
  br label %bb160
bb160:
  %t685 = load i64, ptr %l344, !tbaa !24
  store i64 %t685, ptr %l42, !tbaa !24
  store i64 0, ptr %l43, !tbaa !24
  br label %bb161
bb161:
  store %olang.scope zeroinitializer, ptr %s32
  %t686 = load i64, ptr %l43, !tbaa !24
  %t687 = load i64, ptr %l42, !tbaa !24
  %t690 = icmp slt i64 %t686, %t687
  %t692 = xor i1 %t690, true
  br i1 %t692, label %bb162, label %bb163
bb162:
  call void @__olang_scope_close(ptr %s32)
  br label %bb171
bb163:
  br label %bb164
bb164:
  %t694 = load i64, ptr %l39, !tbaa !24
  %t695 = load i64, ptr %l43, !tbaa !24
  %t696 = load i64, ptr %l41, !tbaa !24
  %t699 = mul i64 %t695, %t696
  %t702 = add i64 %t694, %t699
  store i64 %t702, ptr %l44, !tbaa !24
  store ptr %l25, ptr %l365, !tbaa !29
  %t704 = load i64, ptr %l44, !tbaa !24
  %t706 = icmp sgt i64 %t704, 0
  br i1 %t706, label %bb165, label %bb166
bb165:
  store { i64, ptr } { i64 2, ptr @.d35 }, ptr %l368, !tbaa !27
  br label %bb167
bb166:
  store { i64, ptr } { i64 1, ptr @.d36 }, ptr %l368, !tbaa !27
  br label %bb167
bb167:
  %t708 = load ptr, ptr %l0, !tbaa !29
  %t709 = load { i64, ptr }, ptr %l38, !tbaa !27
  store { i64, ptr } %t709, ptr %l370, !tbaa !27
  %t710 = load i64, ptr %l44, !tbaa !24
  %t712 = getelementptr { i64, ptr }, ptr %l370, i32 0, i32 1
  %t713 = load ptr, ptr %t712, !tbaa !27
  %t714 = getelementptr i32, ptr %t713, i64 %t710
  %t715 = load i32, ptr %t714, !tbaa !33
  %t718 = call { i64, ptr } @compiler_2flower_2ecompiler_2flower_3alowering_2espell(ptr %v0, ptr %s32, ptr %t708, i32 %t715, i1 true, i1 true, i1 false)
  store { i64, ptr } %t718, ptr %l373
  br label %bb168
bb168:
  %t719 = load { i64, ptr }, ptr %l368, !tbaa !27
  %t720 = extractvalue { i64, ptr } %t719, 1
  %t721 = extractvalue { i64, ptr } %t719, 0
  %t722 = load { i64, ptr }, ptr %l373, !tbaa !27
  %t723 = extractvalue { i64, ptr } %t722, 1
  %t724 = extractvalue { i64, ptr } %t722, 0
  %t725 = add i64 %t721, %t724
  %t726 = call ptr @__olang_scope_alloc(ptr %s32, i64 %t725)
  call void @olang_textcopy(ptr %t726, ptr %t720, i64 %t721)
  %t727 = getelementptr i8, ptr %t726, i64 %t721
  call void @olang_textcopy(ptr %t727, ptr %t723, i64 %t724)
  %t728 = insertvalue { i64, ptr } undef, i64 %t725, 0
  %t729 = insertvalue { i64, ptr } %t728, ptr %t726, 1
  %t731 = extractvalue { i64, ptr } %t729, 0
  %t732 = extractvalue { i64, ptr } %t729, 1
  %t733 = mul i64 %t731, 1
  %t734 = call ptr @__olang_scope_alloc(ptr %s32, i64 %t733)
  call void @llvm.memcpy.p0.p0.i64(ptr %t734, ptr %t732, i64 %t733, i1 false)
  %t735 = insertvalue { i64, ptr } undef, i64 %t731, 0
  %t736 = insertvalue { i64, ptr } %t735, ptr %t734, 1
  %t737 = load ptr, ptr %l365, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s21, ptr %s32, ptr %t737, { i64, ptr } %t736)
  br label %bb169
bb169:
  call void @__olang_scope_close(ptr %s32)
  br label %bb170
bb170:
  %t739 = load i64, ptr %l43, !tbaa !24
  %t741 = add i64 %t739, 1
  store i64 %t741, ptr %l43, !tbaa !24
  br label %bb161
bb171:
  br label %bb186
bb172:
  store %olang.scope zeroinitializer, ptr %s36
  %t743 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t745 = extractvalue { i64, ptr } %t743, 0
  %t747 = icmp sgt i64 %t745, 0
  br i1 %t747, label %bb174, label %bb175
bb173:
  br label %bb185
bb174:
  %t749 = load ptr, ptr %l5, !tbaa !29
  %t750 = load i32, ptr %l26, !tbaa !23
  %t753 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t749, i32 %t750)
  store i32 %t753, ptr %l387
  br label %bb176
bb175:
  store i1 false, ptr %l384, !tbaa !21
  br label %bb177
bb176:
  %t754 = load i32, ptr %l387
  %t756 = trunc i64 21 to i32
  %t757 = icmp eq i32 %t754, %t756
  store i1 %t757, ptr %l384, !tbaa !21
  br label %bb177
bb177:
  %t759 = load i1, ptr %l384, !tbaa !21
  br i1 %t759, label %bb178, label %bb179
bb178:
  %t760 = load ptr, ptr %l5, !tbaa !29
  store ptr %t760, ptr %l391, !tbaa !29
  %t761 = load ptr, ptr %l5, !tbaa !29
  %t762 = load i32, ptr %l26, !tbaa !23
  %t765 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t761, i32 %t762)
  store i32 %t765, ptr %l394
  br label %bb180
bb179:
  store i1 false, ptr %l390, !tbaa !21
  br label %bb182
bb180:
  %t766 = load ptr, ptr %l391, !tbaa !29
  %t767 = load i32, ptr %l394, !tbaa !23
  %t768 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t766, i32 %t767)
  store { i64, ptr } %t768, ptr %l395
  br label %bb181
bb181:
  %t769 = load { i64, ptr }, ptr %l395, !tbaa !27
  %t770 = extractvalue { i64, ptr } %t769, 0
  %t772 = icmp eq i64 %t770, 0
  store i1 %t772, ptr %l390, !tbaa !21
  br label %bb182
bb182:
  %t774 = load i1, ptr %l390, !tbaa !21
  store ptr %l25, ptr %l398, !tbaa !29
  %t775 = load ptr, ptr %l0, !tbaa !29
  %t776 = load i32, ptr %l26, !tbaa !23
  %t781 = call { i64, ptr } @compiler_2flower_2ecompiler_2flower_3alowering_2espell(ptr %v0, ptr %s36, ptr %t775, i32 %t776, i1 true, i1 true, i1 %t774)
  store { i64, ptr } %t781, ptr %l402
  br label %bb183
bb183:
  %t782 = extractvalue { i64, ptr } { i64 1, ptr @.d37 }, 1
  %t783 = extractvalue { i64, ptr } { i64 1, ptr @.d37 }, 0
  %t784 = load { i64, ptr }, ptr %l402, !tbaa !27
  %t785 = extractvalue { i64, ptr } %t784, 1
  %t786 = extractvalue { i64, ptr } %t784, 0
  %t787 = add i64 %t783, %t786
  %t788 = call ptr @__olang_scope_alloc(ptr %s36, i64 %t787)
  call void @olang_textcopy(ptr %t788, ptr %t782, i64 %t783)
  %t789 = getelementptr i8, ptr %t788, i64 %t783
  call void @olang_textcopy(ptr %t789, ptr %t785, i64 %t786)
  %t790 = insertvalue { i64, ptr } undef, i64 %t787, 0
  %t791 = insertvalue { i64, ptr } %t790, ptr %t788, 1
  %t793 = extractvalue { i64, ptr } %t791, 0
  %t794 = extractvalue { i64, ptr } %t791, 1
  %t795 = mul i64 %t793, 1
  %t796 = call ptr @__olang_scope_alloc(ptr %s36, i64 %t795)
  call void @llvm.memcpy.p0.p0.i64(ptr %t796, ptr %t794, i64 %t795, i1 false)
  %t797 = insertvalue { i64, ptr } undef, i64 %t793, 0
  %t798 = insertvalue { i64, ptr } %t797, ptr %t796, 1
  %t799 = load ptr, ptr %l398, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s21, ptr %s36, ptr %t799, { i64, ptr } %t798)
  br label %bb184
bb184:
  call void @__olang_scope_close(ptr %s36)
  br label %bb185
bb185:
  br label %bb186
bb186:
  %t801 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t803 = extractvalue { i64, ptr } %t801, 0
  %t805 = icmp sgt i64 %t803, 0
  br i1 %t805, label %bb187, label %bb188
bb187:
  store %olang.scope zeroinitializer, ptr %s38
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s21, ptr %s38, ptr %l25, { i64, ptr } { i64 2, ptr @.d38 })
  br label %bb189
bb188:
  br label %bb208
bb189:
  store i64 0, ptr %l46, !tbaa !24
  %t808 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t810 = extractvalue { i64, ptr } %t808, 0
  store i64 %t810, ptr %l47, !tbaa !24
  store i64 1, ptr %l48, !tbaa !24
  %t812 = load i64, ptr %l47, !tbaa !24
  %t813 = load i64, ptr %l46, !tbaa !24
  %t816 = icmp sgt i64 %t812, %t813
  br i1 %t816, label %bb190, label %bb191
bb190:
  %t818 = load i64, ptr %l48, !tbaa !24
  %t820 = icmp sgt i64 %t818, 0
  br i1 %t820, label %bb192, label %bb193
bb191:
  store i64 0, ptr %l414, !tbaa !24
  br label %bb195
bb192:
  %t822 = load i64, ptr %l47, !tbaa !24
  %t823 = load i64, ptr %l46, !tbaa !24
  %t826 = sub i64 %t822, %t823
  %t827 = load i64, ptr %l48, !tbaa !24
  %t830 = add i64 %t826, %t827
  %t832 = sub i64 %t830, 1
  %t833 = load i64, ptr %l48, !tbaa !24
  %t836 = sdiv i64 %t832, %t833
  store i64 %t836, ptr %l417, !tbaa !24
  br label %bb194
bb193:
  store i64 0, ptr %l417, !tbaa !24
  br label %bb194
bb194:
  %t838 = load i64, ptr %l417, !tbaa !24
  store i64 %t838, ptr %l414, !tbaa !24
  br label %bb195
bb195:
  %t839 = load i64, ptr %l414, !tbaa !24
  store i64 %t839, ptr %l49, !tbaa !24
  store i64 0, ptr %l50, !tbaa !24
  br label %bb196
bb196:
  store %olang.scope zeroinitializer, ptr %s40
  %t840 = load i64, ptr %l50, !tbaa !24
  %t841 = load i64, ptr %l49, !tbaa !24
  %t844 = icmp slt i64 %t840, %t841
  %t846 = xor i1 %t844, true
  br i1 %t846, label %bb197, label %bb198
bb197:
  call void @__olang_scope_close(ptr %s40)
  br label %bb207
bb198:
  br label %bb199
bb199:
  %t848 = load i64, ptr %l46, !tbaa !24
  %t849 = load i64, ptr %l50, !tbaa !24
  %t850 = load i64, ptr %l48, !tbaa !24
  %t853 = mul i64 %t849, %t850
  %t856 = add i64 %t848, %t853
  store i64 %t856, ptr %l51, !tbaa !24
  store ptr %l25, ptr %l435, !tbaa !29
  %t858 = load i64, ptr %l51, !tbaa !24
  %t860 = icmp sgt i64 %t858, 0
  br i1 %t860, label %bb200, label %bb201
bb200:
  store { i64, ptr } { i64 2, ptr @.d39 }, ptr %l438, !tbaa !27
  br label %bb202
bb201:
  store { i64, ptr } { i64 1, ptr @.d40 }, ptr %l438, !tbaa !27
  br label %bb202
bb202:
  %t862 = load ptr, ptr %l0, !tbaa !29
  store ptr %t862, ptr %l439, !tbaa !29
  %t863 = load ptr, ptr %l5, !tbaa !29
  %t864 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t864, ptr %l441, !tbaa !27
  %t865 = load i64, ptr %l51, !tbaa !24
  %t867 = getelementptr { i64, ptr }, ptr %l441, i32 0, i32 1
  %t868 = load ptr, ptr %t867, !tbaa !27
  %t869 = getelementptr i32, ptr %t868, i64 %t865
  %t870 = load i32, ptr %t869, !tbaa !33
  %t873 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t863, i32 %t870)
  store i32 %t873, ptr %l444
  br label %bb203
bb203:
  %t874 = load ptr, ptr %l439, !tbaa !29
  %t875 = load i32, ptr %l444, !tbaa !23
  %t876 = call { i64, ptr } @compiler_2flower_2ecompiler_2flower_3alowering_2espell(ptr %v0, ptr %s40, ptr %t874, i32 %t875, i1 true, i1 false, i1 false)
  store { i64, ptr } %t876, ptr %l445
  br label %bb204
bb204:
  %t877 = load { i64, ptr }, ptr %l438, !tbaa !27
  %t878 = extractvalue { i64, ptr } %t877, 1
  %t879 = extractvalue { i64, ptr } %t877, 0
  %t880 = load { i64, ptr }, ptr %l445, !tbaa !27
  %t881 = extractvalue { i64, ptr } %t880, 1
  %t882 = extractvalue { i64, ptr } %t880, 0
  %t883 = add i64 %t879, %t882
  %t884 = call ptr @__olang_scope_alloc(ptr %s40, i64 %t883)
  call void @olang_textcopy(ptr %t884, ptr %t878, i64 %t879)
  %t885 = getelementptr i8, ptr %t884, i64 %t879
  call void @olang_textcopy(ptr %t885, ptr %t881, i64 %t882)
  %t886 = insertvalue { i64, ptr } undef, i64 %t883, 0
  %t887 = insertvalue { i64, ptr } %t886, ptr %t884, 1
  %t889 = extractvalue { i64, ptr } %t887, 0
  %t890 = extractvalue { i64, ptr } %t887, 1
  %t891 = mul i64 %t889, 1
  %t892 = call ptr @__olang_scope_alloc(ptr %s40, i64 %t891)
  call void @llvm.memcpy.p0.p0.i64(ptr %t892, ptr %t890, i64 %t891, i1 false)
  %t893 = insertvalue { i64, ptr } undef, i64 %t889, 0
  %t894 = insertvalue { i64, ptr } %t893, ptr %t892, 1
  %t895 = load ptr, ptr %l435, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s21, ptr %s40, ptr %t895, { i64, ptr } %t894)
  br label %bb205
bb205:
  call void @__olang_scope_close(ptr %s40)
  br label %bb206
bb206:
  %t897 = load i64, ptr %l50, !tbaa !24
  %t899 = add i64 %t897, 1
  store i64 %t899, ptr %l50, !tbaa !24
  br label %bb196
bb207:
  call void @__olang_scope_close(ptr %s38)
  br label %bb208
bb208:
  %t901 = load i1, ptr %l29, !tbaa !21
  br i1 %t901, label %bb209, label %bb210
bb209:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s21, ptr %l25, i8 41)
  br label %bb211
bb210:
  br label %bb212
bb211:
  br label %bb212
bb212:
  %t905 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s21, ptr %v1, ptr %l25)
  store { i64, ptr } %t905, ptr %l453
  br label %bb213
bb213:
  %t906 = load { i64, ptr }, ptr %l453, !tbaa !27
  store { i64, ptr } %t906, ptr %l454, !tbaa !27
  %t907 = load { i64, ptr }, ptr %l454, !tbaa !27
  %t908 = extractvalue { i64, ptr } %t907, 0
  store i64 %t908, ptr %l455, !tbaa !24
  %t909 = load i64, ptr %l455, !tbaa !24
  %t910 = mul i64 %t909, 1
  %t911 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t910)
  %t912 = insertvalue { i64, ptr } undef, i64 %t909, 0
  %t913 = insertvalue { i64, ptr } %t912, ptr %t911, 1
  store { i64, ptr } %t913, ptr %l456, !tbaa !27
  %t914 = getelementptr { i64, ptr }, ptr %l456, i32 0, i32 1
  %t915 = load ptr, ptr %t914, !tbaa !27
  %t916 = getelementptr { i64, ptr }, ptr %l454, i32 0, i32 1
  %t917 = load ptr, ptr %t916, !tbaa !27
  %t918 = load i64, ptr %l455, !tbaa !24
  %t919 = mul i64 %t918, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t915, ptr %t917, i64 %t919, i1 false)
  %t920 = load { i64, ptr }, ptr %l456, !tbaa !27
  store { i64, ptr } %t920, ptr %l454, !tbaa !27
  call void @__olang_scope_close(ptr %s21)
  %t921 = load { i64, ptr }, ptr %l454, !tbaa !27
  store { i64, ptr } %t921, ptr %rv
  br label %ret
bb214:
  %t922 = load ptr, ptr %l5, !tbaa !29
  %t923 = load i32, ptr %l1, !tbaa !23
  %t926 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %v1, ptr %t922, i32 %t923)
  store { i64, ptr } %t926, ptr %l459
  br label %bb215
bb215:
  %t927 = load { i64, ptr }, ptr %l459, !tbaa !27
  store { i64, ptr } %t927, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 6
  store i32 %a1, ptr %t5, !tbaa !23
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/lower:lowering", ptr %t6, i32 0, i32 7
  store i1 false, ptr %t8, !tbaa !21
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca { i64, [4 x i64] }
  %l7 = alloca %"compiler/source:Span"
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca %"compiler/lower:pl"
  %l11 = alloca { i64, [4 x i64] }
  %l12 = alloca i1
  %l13 = alloca ptr
  %l14 = alloca %"compiler/source:Span"
  %l15 = alloca ptr
  %l16 = alloca %"compiler/source:Span"
  %l17 = alloca ptr
  %l18 = alloca ptr
  %l19 = alloca %"compiler/source:Span"
  %l20 = alloca i32
  %l21 = alloca i32
  %l22 = alloca %"compiler/source:Span"
  %l23 = alloca ptr
  %l24 = alloca %"compiler/source:Span"
  %l25 = alloca i32
  %l26 = alloca i64
  %l28 = alloca %"compiler/source:Span"
  %l29 = alloca ptr
  %l30 = alloca i32
  %l31 = alloca { i64, [4 x i64] }
  %l32 = alloca %"compiler/source:Span"
  %l33 = alloca i32
  %l34 = alloca ptr
  %l35 = alloca { i64, [4 x i64] }
  %l36 = alloca i32
  %l37 = alloca %"compiler/source:Span"
  %l38 = alloca ptr
  %l39 = alloca ptr
  %l40 = alloca ptr
  %l41 = alloca %"compiler/source:Span"
  %l42 = alloca ptr
  %l43 = alloca %"compiler/source:Span"
  %l44 = alloca ptr
  %l45 = alloca %"compiler/source:Span"
  %l46 = alloca ptr
  %l47 = alloca %"compiler/source:Span"
  %l48 = alloca ptr
  %l51 = alloca ptr
  %l52 = alloca i1
  %l66 = alloca %"compiler/typed:Local"
  %l68 = alloca ptr
  %l72 = alloca { i64, [4 x i64] }
  %l77 = alloca { i64, [4 x i64] }
  %l81 = alloca i1
  %l82 = alloca i1
  %l86 = alloca ptr
  %l87 = alloca { i64, [4 x i64] }
  %l88 = alloca i32
  %l89 = alloca %"compiler/source:Span"
  %l92 = alloca { i64, [1 x i64] }
  %l93 = alloca { i64, [4 x i64] }
  %l98 = alloca %"compiler/mir:Local"
  %l109 = alloca ptr
  %l110 = alloca %"compiler/source:Span"
  %l114 = alloca %"compiler/mir:Place"
  %l119 = alloca ptr
  %l120 = alloca i1
  %l132 = alloca %"compiler/lower:pl"
  %l136 = alloca ptr
  %l140 = alloca { i64, [4 x i64] }
  %l142 = alloca ptr
  %l144 = alloca i32
  %l146 = alloca { i64, [4 x i64] }
  %l147 = alloca %"compiler/lower:pl"
  %l150 = alloca %"compiler/lower:pl"
  %l151 = alloca i32
  %l152 = alloca ptr
  %l154 = alloca i32
  %l155 = alloca i1
  %l156 = alloca i1
  %l160 = alloca ptr
  %l161 = alloca ptr
  %l163 = alloca i32
  %l164 = alloca i1
  %l165 = alloca ptr
  %l168 = alloca %"compiler/mir:Place"
  %l169 = alloca { i64, [4 x i64] }
  %l171 = alloca i32
  %l172 = alloca i1
  %l173 = alloca %"compiler/source:Span"
  %l176 = alloca { i64, [1 x i64] }
  %l177 = alloca ptr
  %l178 = alloca %"compiler/source:Span"
  %l181 = alloca %"compiler/mir:Place"
  %l186 = alloca ptr
  %l187 = alloca i1
  %l195 = alloca { i64, [4 x i64] }
  %l196 = alloca ptr
  %l197 = alloca i1
  %l207 = alloca ptr
  %l208 = alloca i1
  %l221 = alloca ptr
  %l222 = alloca i1
  %l235 = alloca ptr
  %l236 = alloca i1
  %l246 = alloca ptr
  %l247 = alloca i1
  %l257 = alloca ptr
  %l263 = alloca i32
  %l266 = alloca i64
  %l272 = alloca ptr
  %l273 = alloca i1
  %l285 = alloca { i64, [4 x i64] }
  %l289 = alloca i1
  %l291 = alloca ptr
  %l297 = alloca i32
  %l298 = alloca { i64, ptr }
  %l301 = alloca ptr
  %l302 = alloca %"compiler/source:Span"
  %l303 = alloca ptr
  %l304 = alloca i32
  %l305 = alloca { i64, [4 x i64] }
  %l306 = alloca i32
  %l312 = alloca i32
  %l315 = alloca { i64, [4 x i64] }
  %l322 = alloca ptr
  %l323 = alloca i1
  %l339 = alloca { i64, [4 x i64] }
  %l342 = alloca i32
  %l353 = alloca ptr
  %l354 = alloca i1
  %l367 = alloca ptr
  %l368 = alloca i1
  %l375 = alloca ptr
  %l376 = alloca i1
  %l387 = alloca ptr
  %l389 = alloca %"compiler/lower:level"
  %l394 = alloca ptr
  %l395 = alloca %"compiler/source:Span"
  %l398 = alloca i64
  %l400 = alloca ptr
  %l401 = alloca i1
  %l411 = alloca ptr
  %l412 = alloca i1
  %l422 = alloca ptr
  %l423 = alloca i1
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %t121 = alloca { i64, [21 x i64] }, align 8
  %t141 = alloca { i64, [15 x i64] }, align 8
  %t147 = alloca { i64, [21 x i64] }, align 8
  %t289 = alloca { i64, [15 x i64] }, align 8
  %t295 = alloca { i64, [21 x i64] }, align 8
  %t511 = alloca { i64, [4 x i64] }, align 8
  %t617 = alloca { i64, [15 x i64] }, align 8
  %t669 = alloca { i64, [4 x i64] }, align 8
  %t705 = alloca { i64, [7 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 7
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l1, !tbaa !29
  store ptr %t6, ptr %l51, !tbaa !29
  store i1 false, ptr %l52, !tbaa !21
  %t7 = load ptr, ptr %l51, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb4, label %bb5
bb4:
  %t10 = load ptr, ptr %l51, !tbaa !29
  %t11 = load i64, ptr %t10
  %t13 = icmp eq i64 %t11, 0
  store i1 %t13, ptr %l52, !tbaa !21
  br label %bb5
bb5:
  %t14 = load i1, ptr %l52, !tbaa !21
  br i1 %t14, label %bb6, label %bb7
bb6:
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t17 = getelementptr { i64, [3 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t17, i32 0, i32 0
  %t19 = load %"compiler/source:Span", ptr %t18
  store %"compiler/source:Span" %t19, ptr %l2
  %t21 = load ptr, ptr %l1, !tbaa !29
  %t23 = getelementptr { i64, [3 x i64] }, ptr %t21, i32 0, i32 1
  %t24 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t23, i32 0, i32 1
  %t25 = load i32, ptr %t24
  store i32 %t25, ptr %l3, !tbaa !23
  %t27 = load ptr, ptr %l1, !tbaa !29
  %t29 = getelementptr { i64, [3 x i64] }, ptr %t27, i32 0, i32 1
  %t30 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t29, i32 0, i32 2
  %t31 = load ptr, ptr %t30
  store ptr %t31, ptr %l4, !tbaa !29
  br label %bb8
bb7:
  br label %bb28
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/lower:lowering", ptr %t33, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !29
  %t38 = getelementptr %"compiler/typed:Body", ptr %t36, i32 0, i32 7
  %t39 = load i32, ptr %l3, !tbaa !23
  %t41 = sext i32 %t39 to i64
  %t44 = call %"compiler/typed:Local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t38, i64 %t41)
  store %"compiler/typed:Local" %t44, ptr %l66
  br label %bb9
bb9:
  %t45 = getelementptr %"compiler/typed:Local", ptr %l66, i32 0, i32 2
  %t46 = load i32, ptr %t45, !tbaa !23
  store i32 %t46, ptr %l5, !tbaa !23
  %t48 = load ptr, ptr %l0, !tbaa !29
  store ptr %t48, ptr %l68, !tbaa !29
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t50 = load ptr, ptr %l4, !tbaa !29
  %t54 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v1, ptr %t49, ptr %t50)
  store { i64, [4 x i64] } %t54, ptr %l72
  br label %bb10
bb10:
  %t55 = load ptr, ptr %l4, !tbaa !29
  %t57 = load i32, ptr %l5, !tbaa !23
  %t58 = load %"compiler/source:Span", ptr %l2
  %t59 = load ptr, ptr %l68, !tbaa !29
  %t60 = load { i64, [4 x i64] }, ptr %l72
  %t64 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2efit(ptr %v0, ptr %v1, ptr %t59, { i64, [4 x i64] } %t60, ptr %t55, i32 %t57, %"compiler/source:Span" %t58)
  store { i64, [4 x i64] } %t64, ptr %l77
  br label %bb11
bb11:
  %t65 = load { i64, [4 x i64] }, ptr %l77
  store { i64, [4 x i64] } %t65, ptr %l6
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t67 = load ptr, ptr %l4, !tbaa !29
  %t68 = load i32, ptr %l5, !tbaa !23
  %t72 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2ecopiesArray(ptr %v0, ptr %v1, ptr %t66, ptr %t67, i32 %t68)
  store i1 %t72, ptr %l81
  br label %bb12
bb12:
  %t73 = load i1, ptr %l81, !tbaa !21
  br i1 %t73, label %bb13, label %bb14
bb13:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr %"compiler/lower:lowering", ptr %t74, i32 0, i32 7
  %t77 = load i1, ptr %t76, !tbaa !21
  %t79 = xor i1 %t77, true
  store i1 %t79, ptr %l82, !tbaa !21
  br label %bb15
bb14:
  store i1 false, ptr %l82, !tbaa !21
  br label %bb15
bb15:
  %t81 = load i1, ptr %l82, !tbaa !21
  br i1 %t81, label %bb16, label %bb17
bb16:
  %t82 = load ptr, ptr %l0, !tbaa !29
  store ptr %t82, ptr %l86, !tbaa !29
  %t83 = load { i64, [4 x i64] }, ptr %l6
  store { i64, [4 x i64] } %t83, ptr %l87
  %t84 = load i32, ptr %l5, !tbaa !23
  store i32 %t84, ptr %l88, !tbaa !23
  %t85 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t85, ptr %l89
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t87 = load i32, ptr %l3, !tbaa !23
  %t90 = call { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2estorageOf(ptr %v0, ptr %t86, i32 %t87)
  store { i64, [1 x i64] } %t90, ptr %l92
  br label %bb18
bb17:
  br label %bb20
bb18:
  %t91 = load ptr, ptr %l86, !tbaa !29
  %t92 = load { i64, [4 x i64] }, ptr %l87
  %t93 = load i32, ptr %l88, !tbaa !23
  %t94 = load %"compiler/source:Span", ptr %l89
  %t95 = load { i64, [1 x i64] }, ptr %l92
  %t96 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2earrayCopy(ptr %v0, ptr %t91, { i64, [4 x i64] } %t92, i32 %t93, %"compiler/source:Span" %t94, { i64, [1 x i64] } %t95)
  store { i64, [4 x i64] } %t96, ptr %l93
  br label %bb19
bb19:
  %t97 = load { i64, [4 x i64] }, ptr %l93
  store { i64, [4 x i64] } %t97, ptr %l6
  br label %bb20
bb20:
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t100 = getelementptr %"compiler/lower:lowering", ptr %t98, i32 0, i32 3
  %t101 = getelementptr %"compiler/mir:Fn", ptr %t100, i32 0, i32 7
  %t102 = load i32, ptr %l3, !tbaa !23
  %t104 = sext i32 %t102 to i64
  %t107 = call %"compiler/mir:Local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aLocal_3e_2eAt_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %t101, i64 %t104)
  store %"compiler/mir:Local" %t107, ptr %l98
  br label %bb21
bb21:
  %t108 = getelementptr %"compiler/mir:Local", ptr %l98, i32 0, i32 4
  %t109 = load { i64, [1 x i64] }, ptr %t108
  %t111 = extractvalue { i64, [1 x i64] } %t109, 0
  %t112 = icmp eq i64 %t111, 3
  %t114 = xor i1 %t112, true
  br i1 %t114, label %bb22, label %bb23
bb22:
  store %olang.scope zeroinitializer, ptr %s4
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t117 = load %"compiler/source:Span", ptr %l2
  %t118 = load i32, ptr %l3, !tbaa !23
  store { i64, [21 x i64] } zeroinitializer, ptr %t121
  %t122 = getelementptr { i64, [21 x i64] }, ptr %t121, i32 0, i32 0
  store i64 1, ptr %t122
  %t124 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t117, 0
  %t126 = insertvalue { %"compiler/source:Span", i32 } %t124, i32 %t118, 1
  %t127 = getelementptr { i64, [21 x i64] }, ptr %t121, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t126, ptr %t127
  %t128 = load { i64, [21 x i64] }, ptr %t121
  %t130 = call ptr @__olang_scope_alloc_a(ptr %s4, i64 176, i64 8)
  store { i64, [21 x i64] } %t128, ptr %t130
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s4, ptr %t116, ptr %t130)
  br label %bb24
bb23:
  br label %bb25
bb24:
  call void @__olang_scope_close(ptr %s4)
  br label %bb25
bb25:
  %t133 = load ptr, ptr %l0, !tbaa !29
  store ptr %t133, ptr %l109, !tbaa !29
  %t134 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t134, ptr %l110
  %t135 = load i32, ptr %l3, !tbaa !23
  %t139 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t135)
  store %"compiler/mir:Place" %t139, ptr %l114
  br label %bb26
bb26:
  %t140 = load { i64, [4 x i64] }, ptr %l6
  store { i64, [15 x i64] } zeroinitializer, ptr %t141
  %t142 = getelementptr { i64, [15 x i64] }, ptr %t141, i32 0, i32 0
  store i64 0, ptr %t142
  %t144 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t140, 0
  %t145 = getelementptr { i64, [15 x i64] }, ptr %t141, i32 0, i32 1
  store { { i64, [4 x i64] } } %t144, ptr %t145
  %t146 = load { i64, [15 x i64] }, ptr %t141
  store { i64, [21 x i64] } zeroinitializer, ptr %t147
  %t148 = getelementptr { i64, [21 x i64] }, ptr %t147, i32 0, i32 0
  store i64 0, ptr %t148
  %t149 = load %"compiler/source:Span", ptr %l110
  %t150 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t149, 0
  %t151 = load %"compiler/mir:Place", ptr %l114
  %t152 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t150, %"compiler/mir:Place" %t151, 1
  %t154 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t152, { i64, [15 x i64] } %t146, 2
  %t155 = getelementptr { i64, [21 x i64] }, ptr %t147, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t154, ptr %t155
  %t156 = load { i64, [21 x i64] }, ptr %t147
  %t158 = call ptr @__olang_scope_alloc_a(ptr %s2, i64 176, i64 8)
  store { i64, [21 x i64] } %t156, ptr %t158
  %t159 = load ptr, ptr %l109, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s2, ptr %t159, ptr %t158)
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s2)
  br label %bb192
bb28:
  %t161 = load ptr, ptr %l1, !tbaa !29
  store ptr %t161, ptr %l119, !tbaa !29
  store i1 false, ptr %l120, !tbaa !21
  %t162 = load ptr, ptr %l119, !tbaa !29
  %t163 = icmp ne ptr %t162, null
  br i1 %t163, label %bb29, label %bb30
bb29:
  %t165 = load ptr, ptr %l119, !tbaa !29
  %t166 = load i64, ptr %t165
  %t168 = icmp eq i64 %t166, 1
  store i1 %t168, ptr %l120, !tbaa !21
  br label %bb30
bb30:
  %t169 = load i1, ptr %l120, !tbaa !21
  br i1 %t169, label %bb31, label %bb32
bb31:
  %t170 = load ptr, ptr %l1, !tbaa !29
  %t172 = getelementptr { i64, [3 x i64] }, ptr %t170, i32 0, i32 1
  %t173 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t172, i32 0, i32 0
  %t174 = load %"compiler/source:Span", ptr %t173
  store %"compiler/source:Span" %t174, ptr %l7
  %t176 = load ptr, ptr %l1, !tbaa !29
  %t178 = getelementptr { i64, [3 x i64] }, ptr %t176, i32 0, i32 1
  %t179 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t178, i32 0, i32 1
  %t180 = load ptr, ptr %t179
  store ptr %t180, ptr %l8, !tbaa !29
  %t182 = load ptr, ptr %l1, !tbaa !29
  %t184 = getelementptr { i64, [3 x i64] }, ptr %t182, i32 0, i32 1
  %t185 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t184, i32 0, i32 2
  %t186 = load ptr, ptr %t185
  store ptr %t186, ptr %l9, !tbaa !29
  br label %bb33
bb32:
  br label %bb59
bb33:
  %t188 = load ptr, ptr %l0, !tbaa !29
  %t189 = load ptr, ptr %l8, !tbaa !29
  %t193 = call %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2eplace(ptr %v0, ptr %v1, ptr %v0, ptr %t188, ptr %t189)
  store %"compiler/lower:pl" %t193, ptr %l132
  br label %bb34
bb34:
  %t194 = load %"compiler/lower:pl", ptr %l132
  store %"compiler/lower:pl" %t194, ptr %l10
  %t195 = load ptr, ptr %l0, !tbaa !29
  %t197 = getelementptr %"compiler/lower:lowering", ptr %t195, i32 0, i32 15
  %t198 = load %"compiler/lower:pl", ptr %l10
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3apl_3e_2ePush_3ccompiler_2flower_3apl_3e(ptr %v0, ptr %v0, ptr %t197, %"compiler/lower:pl" %t198)
  br label %bb35
bb35:
  %t201 = load ptr, ptr %l0, !tbaa !29
  store ptr %t201, ptr %l136, !tbaa !29
  %t202 = load ptr, ptr %l0, !tbaa !29
  %t203 = load ptr, ptr %l9, !tbaa !29
  %t207 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v1, ptr %t202, ptr %t203)
  store { i64, [4 x i64] } %t207, ptr %l140
  br label %bb36
bb36:
  %t208 = load ptr, ptr %l9, !tbaa !29
  store ptr %t208, ptr %l142, !tbaa !29
  %t210 = load ptr, ptr %l8, !tbaa !29
  %t212 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aPlace_2eType(ptr %v1, ptr %t210)
  store i32 %t212, ptr %l144
  br label %bb37
bb37:
  %t213 = load %"compiler/source:Span", ptr %l7
  %t214 = load ptr, ptr %l136, !tbaa !29
  %t215 = load { i64, [4 x i64] }, ptr %l140
  %t216 = load ptr, ptr %l142, !tbaa !29
  %t217 = load i32, ptr %l144, !tbaa !23
  %t219 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2efit(ptr %v0, ptr %v1, ptr %t214, { i64, [4 x i64] } %t215, ptr %t216, i32 %t217, %"compiler/source:Span" %t213)
  store { i64, [4 x i64] } %t219, ptr %l146
  br label %bb38
bb38:
  %t220 = load { i64, [4 x i64] }, ptr %l146
  store { i64, [4 x i64] } %t220, ptr %l11
  %t221 = load ptr, ptr %l0, !tbaa !29
  %t223 = getelementptr %"compiler/lower:lowering", ptr %t221, i32 0, i32 15
  %t225 = call { i32, %"compiler/lower:pl" } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3apl_3e_2ePop_3ccompiler_2flower_3apl_3e(ptr %v0, ptr %v0, ptr %t223)
  %t226 = extractvalue { i32, %"compiler/lower:pl" } %t225, 1
  %t227 = extractvalue { i32, %"compiler/lower:pl" } %t225, 0
  store i32 %t227, ptr %l151
  %t228 = icmp ne i32 %t227, 0
  br i1 %t228, label %bb40, label %ok.229
ok.229:
  store %"compiler/lower:pl" %t226, ptr %l150
  br label %bb39
bb39:
  %t230 = load %"compiler/lower:pl", ptr %l150
  store %"compiler/lower:pl" %t230, ptr %l147
  br label %bb42
bb40:
  br label %bb41
bb41:
  call void @__olang_ert_req_clear()
  br label %bb42
bb42:
  %t231 = load ptr, ptr %l0, !tbaa !29
  store ptr %t231, ptr %l152, !tbaa !29
  %t232 = load ptr, ptr %l8, !tbaa !29
  %t234 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aPlace_2eType(ptr %v1, ptr %t232)
  store i32 %t234, ptr %l154
  br label %bb43
bb43:
  %t235 = load ptr, ptr %l152, !tbaa !29
  %t236 = load i32, ptr %l154, !tbaa !23
  %t237 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2evalueArray(ptr %v0, ptr %t235, i32 %t236)
  store i1 %t237, ptr %l155
  br label %bb44
bb44:
  %t238 = load i1, ptr %l155, !tbaa !21
  br i1 %t238, label %bb45, label %bb46
bb45:
  %t239 = load ptr, ptr %l0, !tbaa !29
  %t241 = getelementptr %"compiler/lower:lowering", ptr %t239, i32 0, i32 7
  %t242 = load i1, ptr %t241, !tbaa !21
  %t244 = xor i1 %t242, true
  store i1 %t244, ptr %l156, !tbaa !21
  br label %bb47
bb46:
  store i1 false, ptr %l156, !tbaa !21
  br label %bb47
bb47:
  %t246 = load i1, ptr %l156, !tbaa !21
  br i1 %t246, label %bb48, label %bb49
bb48:
  %t247 = load ptr, ptr %l0, !tbaa !29
  store ptr %t247, ptr %l160, !tbaa !29
  %t248 = load ptr, ptr %l9, !tbaa !29
  store ptr %t248, ptr %l161, !tbaa !29
  %t249 = load ptr, ptr %l8, !tbaa !29
  %t251 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aPlace_2eType(ptr %v1, ptr %t249)
  store i32 %t251, ptr %l163
  br label %bb50
bb49:
  store %olang.scope zeroinitializer, ptr %s8
  %t252 = load ptr, ptr %l0, !tbaa !29
  store ptr %t252, ptr %l177, !tbaa !29
  %t253 = load %"compiler/source:Span", ptr %l7
  store %"compiler/source:Span" %t253, ptr %l178
  %t254 = load ptr, ptr %l0, !tbaa !29
  %t255 = load %"compiler/lower:pl", ptr %l10
  %t258 = call %"compiler/mir:Place" @compiler_2flower_2ecompiler_2flower_3alowering_2emk(ptr %v0, ptr %v0, ptr %t254, %"compiler/lower:pl" %t255)
  store %"compiler/mir:Place" %t258, ptr %l181
  br label %bb56
bb50:
  %t259 = load ptr, ptr %l160, !tbaa !29
  %t260 = load ptr, ptr %l161, !tbaa !29
  %t261 = load i32, ptr %l163, !tbaa !23
  %t262 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2ecopiesArray(ptr %v0, ptr %v1, ptr %t259, ptr %t260, i32 %t261)
  store i1 %t262, ptr %l164
  br label %bb51
bb51:
  %t263 = load i1, ptr %l164, !tbaa !21
  store i1 %t263, ptr %l12, !tbaa !21
  %t264 = load ptr, ptr %l0, !tbaa !29
  store ptr %t264, ptr %l165, !tbaa !29
  %t265 = load ptr, ptr %l0, !tbaa !29
  %t266 = load %"compiler/lower:pl", ptr %l10
  %t269 = call %"compiler/mir:Place" @compiler_2flower_2ecompiler_2flower_3alowering_2emk(ptr %v0, ptr %v0, ptr %t265, %"compiler/lower:pl" %t266)
  store %"compiler/mir:Place" %t269, ptr %l168
  br label %bb52
bb52:
  %t270 = load { i64, [4 x i64] }, ptr %l11
  store { i64, [4 x i64] } %t270, ptr %l169
  %t271 = load ptr, ptr %l8, !tbaa !29
  %t273 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aPlace_2eType(ptr %v1, ptr %t271)
  store i32 %t273, ptr %l171
  br label %bb53
bb53:
  %t274 = load i1, ptr %l12, !tbaa !21
  store i1 %t274, ptr %l172, !tbaa !21
  %t275 = load %"compiler/source:Span", ptr %l7
  store %"compiler/source:Span" %t275, ptr %l173
  %t276 = load ptr, ptr %l0, !tbaa !29
  %t277 = load ptr, ptr %l8, !tbaa !29
  %t280 = call { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eplaceStorage(ptr %v0, ptr %v1, ptr %t276, ptr %t277)
  store { i64, [1 x i64] } %t280, ptr %l176
  br label %bb54
bb54:
  %t281 = load ptr, ptr %l165, !tbaa !29
  %t282 = load %"compiler/mir:Place", ptr %l168
  %t283 = load { i64, [4 x i64] }, ptr %l169
  %t284 = load i32, ptr %l171, !tbaa !23
  %t285 = load i1, ptr %l172, !tbaa !21
  %t286 = load %"compiler/source:Span", ptr %l173
  %t287 = load { i64, [1 x i64] }, ptr %l176
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2earrayStore(ptr %v0, ptr %t281, %"compiler/mir:Place" %t282, { i64, [4 x i64] } %t283, i32 %t284, i1 %t285, %"compiler/source:Span" %t286, { i64, [1 x i64] } %t287)
  br label %bb55
bb55:
  br label %bb58
bb56:
  %t288 = load { i64, [4 x i64] }, ptr %l11
  store { i64, [15 x i64] } zeroinitializer, ptr %t289
  %t290 = getelementptr { i64, [15 x i64] }, ptr %t289, i32 0, i32 0
  store i64 0, ptr %t290
  %t292 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t288, 0
  %t293 = getelementptr { i64, [15 x i64] }, ptr %t289, i32 0, i32 1
  store { { i64, [4 x i64] } } %t292, ptr %t293
  %t294 = load { i64, [15 x i64] }, ptr %t289
  store { i64, [21 x i64] } zeroinitializer, ptr %t295
  %t296 = getelementptr { i64, [21 x i64] }, ptr %t295, i32 0, i32 0
  store i64 0, ptr %t296
  %t297 = load %"compiler/source:Span", ptr %l178
  %t298 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t297, 0
  %t299 = load %"compiler/mir:Place", ptr %l181
  %t300 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t298, %"compiler/mir:Place" %t299, 1
  %t302 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t300, { i64, [15 x i64] } %t294, 2
  %t303 = getelementptr { i64, [21 x i64] }, ptr %t295, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t302, ptr %t303
  %t304 = load { i64, [21 x i64] }, ptr %t295
  %t306 = call ptr @__olang_scope_alloc_a(ptr %s8, i64 176, i64 8)
  store { i64, [21 x i64] } %t304, ptr %t306
  %t307 = load ptr, ptr %l177, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s8, ptr %t307, ptr %t306)
  br label %bb57
bb57:
  call void @__olang_scope_close(ptr %s8)
  br label %bb58
bb58:
  br label %bb192
bb59:
  %t309 = load ptr, ptr %l1, !tbaa !29
  store ptr %t309, ptr %l186, !tbaa !29
  store i1 false, ptr %l187, !tbaa !21
  %t310 = load ptr, ptr %l186, !tbaa !29
  %t311 = icmp ne ptr %t310, null
  br i1 %t311, label %bb60, label %bb61
bb60:
  %t313 = load ptr, ptr %l186, !tbaa !29
  %t314 = load i64, ptr %t313
  %t316 = icmp eq i64 %t314, 2
  store i1 %t316, ptr %l187, !tbaa !21
  br label %bb61
bb61:
  %t317 = load i1, ptr %l187, !tbaa !21
  br i1 %t317, label %bb62, label %bb63
bb62:
  %t318 = load ptr, ptr %l1, !tbaa !29
  %t320 = getelementptr { i64, [3 x i64] }, ptr %t318, i32 0, i32 1
  %t321 = getelementptr { %"compiler/source:Span", ptr }, ptr %t320, i32 0, i32 1
  %t322 = load ptr, ptr %t321
  store ptr %t322, ptr %l13, !tbaa !29
  br label %bb64
bb63:
  br label %bb66
bb64:
  %t324 = load ptr, ptr %l0, !tbaa !29
  %t325 = load ptr, ptr %l13, !tbaa !29
  %t329 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v1, ptr %t324, ptr %t325)
  store { i64, [4 x i64] } %t329, ptr %l195
  br label %bb65
bb65:
  br label %bb192
bb66:
  %t330 = load ptr, ptr %l1, !tbaa !29
  store ptr %t330, ptr %l196, !tbaa !29
  store i1 false, ptr %l197, !tbaa !21
  %t331 = load ptr, ptr %l196, !tbaa !29
  %t332 = icmp ne ptr %t331, null
  br i1 %t332, label %bb67, label %bb68
bb67:
  %t334 = load ptr, ptr %l196, !tbaa !29
  %t335 = load i64, ptr %t334
  %t337 = icmp eq i64 %t335, 3
  store i1 %t337, ptr %l197, !tbaa !21
  br label %bb68
bb68:
  %t338 = load i1, ptr %l197, !tbaa !21
  br i1 %t338, label %bb69, label %bb70
bb69:
  %t339 = load ptr, ptr %l1, !tbaa !29
  %t341 = getelementptr { i64, [3 x i64] }, ptr %t339, i32 0, i32 1
  %t342 = getelementptr { %"compiler/source:Span", ptr }, ptr %t341, i32 0, i32 0
  %t343 = load %"compiler/source:Span", ptr %t342
  store %"compiler/source:Span" %t343, ptr %l14
  %t345 = load ptr, ptr %l1, !tbaa !29
  %t347 = getelementptr { i64, [3 x i64] }, ptr %t345, i32 0, i32 1
  %t348 = getelementptr { %"compiler/source:Span", ptr }, ptr %t347, i32 0, i32 1
  %t349 = load ptr, ptr %t348
  store ptr %t349, ptr %l15, !tbaa !29
  br label %bb71
bb70:
  br label %bb73
bb71:
  %t351 = load ptr, ptr %l0, !tbaa !29
  %t352 = load %"compiler/source:Span", ptr %l14
  %t353 = load ptr, ptr %l15, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eifStmt(ptr %v0, ptr %v1, ptr %t351, %"compiler/source:Span" %t352, ptr %t353)
  br label %bb72
bb72:
  br label %bb192
bb73:
  %t357 = load ptr, ptr %l1, !tbaa !29
  store ptr %t357, ptr %l207, !tbaa !29
  store i1 false, ptr %l208, !tbaa !21
  %t358 = load ptr, ptr %l207, !tbaa !29
  %t359 = icmp ne ptr %t358, null
  br i1 %t359, label %bb74, label %bb75
bb74:
  %t361 = load ptr, ptr %l207, !tbaa !29
  %t362 = load i64, ptr %t361
  %t364 = icmp eq i64 %t362, 4
  store i1 %t364, ptr %l208, !tbaa !21
  br label %bb75
bb75:
  %t365 = load i1, ptr %l208, !tbaa !21
  br i1 %t365, label %bb76, label %bb77
bb76:
  %t366 = load ptr, ptr %l1, !tbaa !29
  %t368 = getelementptr { i64, [3 x i64] }, ptr %t366, i32 0, i32 1
  %t369 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t368, i32 0, i32 0
  %t370 = load %"compiler/source:Span", ptr %t369
  store %"compiler/source:Span" %t370, ptr %l16
  %t372 = load ptr, ptr %l1, !tbaa !29
  %t374 = getelementptr { i64, [3 x i64] }, ptr %t372, i32 0, i32 1
  %t375 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t374, i32 0, i32 1
  %t376 = load ptr, ptr %t375
  store ptr %t376, ptr %l17, !tbaa !29
  %t378 = load ptr, ptr %l1, !tbaa !29
  %t380 = getelementptr { i64, [3 x i64] }, ptr %t378, i32 0, i32 1
  %t381 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t380, i32 0, i32 2
  %t382 = load ptr, ptr %t381
  store ptr %t382, ptr %l18, !tbaa !29
  br label %bb78
bb77:
  br label %bb80
bb78:
  %t384 = load ptr, ptr %l0, !tbaa !29
  %t385 = load %"compiler/source:Span", ptr %l16
  %t386 = load ptr, ptr %l17, !tbaa !29
  %t387 = load ptr, ptr %l18, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eloop(ptr %v0, ptr %v1, ptr %v1, ptr %t384, %"compiler/source:Span" %t385, ptr %t386, ptr %t387)
  br label %bb79
bb79:
  br label %bb192
bb80:
  %t392 = load ptr, ptr %l1, !tbaa !29
  store ptr %t392, ptr %l221, !tbaa !29
  store i1 false, ptr %l222, !tbaa !21
  %t393 = load ptr, ptr %l221, !tbaa !29
  %t394 = icmp ne ptr %t393, null
  br i1 %t394, label %bb81, label %bb82
bb81:
  %t396 = load ptr, ptr %l221, !tbaa !29
  %t397 = load i64, ptr %t396
  %t399 = icmp eq i64 %t397, 5
  store i1 %t399, ptr %l222, !tbaa !21
  br label %bb82
bb82:
  %t400 = load i1, ptr %l222, !tbaa !21
  br i1 %t400, label %bb83, label %bb84
bb83:
  %t401 = load ptr, ptr %l1, !tbaa !29
  %t403 = getelementptr { i64, [3 x i64] }, ptr %t401, i32 0, i32 1
  %t404 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t403, i32 0, i32 0
  %t405 = load %"compiler/source:Span", ptr %t404
  store %"compiler/source:Span" %t405, ptr %l19
  %t407 = load ptr, ptr %l1, !tbaa !29
  %t409 = getelementptr { i64, [3 x i64] }, ptr %t407, i32 0, i32 1
  %t410 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t409, i32 0, i32 1
  %t411 = load i32, ptr %t410
  store i32 %t411, ptr %l20
  %t413 = load ptr, ptr %l1, !tbaa !29
  %t415 = getelementptr { i64, [3 x i64] }, ptr %t413, i32 0, i32 1
  %t416 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t415, i32 0, i32 2
  %t417 = load i32, ptr %t416
  store i32 %t417, ptr %l21, !tbaa !23
  br label %bb85
bb84:
  br label %bb87
bb85:
  %t419 = load ptr, ptr %l0, !tbaa !29
  %t420 = load %"compiler/source:Span", ptr %l19
  %t421 = load i32, ptr %l20
  %t422 = load i32, ptr %l21, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2ejump(ptr %v0, ptr %t419, %"compiler/source:Span" %t420, i32 %t421, i32 %t422)
  br label %bb86
bb86:
  br label %bb192
bb87:
  %t427 = load ptr, ptr %l1, !tbaa !29
  store ptr %t427, ptr %l235, !tbaa !29
  store i1 false, ptr %l236, !tbaa !21
  %t428 = load ptr, ptr %l235, !tbaa !29
  %t429 = icmp ne ptr %t428, null
  br i1 %t429, label %bb88, label %bb89
bb88:
  %t431 = load ptr, ptr %l235, !tbaa !29
  %t432 = load i64, ptr %t431
  %t434 = icmp eq i64 %t432, 6
  store i1 %t434, ptr %l236, !tbaa !21
  br label %bb89
bb89:
  %t435 = load i1, ptr %l236, !tbaa !21
  br i1 %t435, label %bb90, label %bb91
bb90:
  %t436 = load ptr, ptr %l1, !tbaa !29
  %t438 = getelementptr { i64, [3 x i64] }, ptr %t436, i32 0, i32 1
  %t439 = getelementptr { %"compiler/source:Span", ptr }, ptr %t438, i32 0, i32 0
  %t440 = load %"compiler/source:Span", ptr %t439
  store %"compiler/source:Span" %t440, ptr %l22
  %t442 = load ptr, ptr %l1, !tbaa !29
  %t444 = getelementptr { i64, [3 x i64] }, ptr %t442, i32 0, i32 1
  %t445 = getelementptr { %"compiler/source:Span", ptr }, ptr %t444, i32 0, i32 1
  %t446 = load ptr, ptr %t445
  store ptr %t446, ptr %l23, !tbaa !29
  br label %bb92
bb91:
  br label %bb94
bb92:
  %t448 = load ptr, ptr %l0, !tbaa !29
  %t449 = load %"compiler/source:Span", ptr %l22
  %t450 = load ptr, ptr %l23, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eret(ptr %v0, ptr %v1, ptr %t448, %"compiler/source:Span" %t449, ptr %t450)
  br label %bb93
bb93:
  br label %bb192
bb94:
  %t454 = load ptr, ptr %l1, !tbaa !29
  store ptr %t454, ptr %l246, !tbaa !29
  store i1 false, ptr %l247, !tbaa !21
  %t455 = load ptr, ptr %l246, !tbaa !29
  %t456 = icmp ne ptr %t455, null
  br i1 %t456, label %bb95, label %bb96
bb95:
  %t458 = load ptr, ptr %l246, !tbaa !29
  %t459 = load i64, ptr %t458
  %t461 = icmp eq i64 %t459, 7
  store i1 %t461, ptr %l247, !tbaa !21
  br label %bb96
bb96:
  %t462 = load i1, ptr %l247, !tbaa !21
  br i1 %t462, label %bb97, label %bb98
bb97:
  %t463 = load ptr, ptr %l1, !tbaa !29
  %t465 = getelementptr { i64, [3 x i64] }, ptr %t463, i32 0, i32 1
  %t466 = getelementptr { %"compiler/source:Span", i32, i64 }, ptr %t465, i32 0, i32 0
  %t467 = load %"compiler/source:Span", ptr %t466
  store %"compiler/source:Span" %t467, ptr %l24
  %t469 = load ptr, ptr %l1, !tbaa !29
  %t471 = getelementptr { i64, [3 x i64] }, ptr %t469, i32 0, i32 1
  %t472 = getelementptr { %"compiler/source:Span", i32, i64 }, ptr %t471, i32 0, i32 1
  %t473 = load i32, ptr %t472
  store i32 %t473, ptr %l25, !tbaa !23
  %t475 = load ptr, ptr %l1, !tbaa !29
  %t477 = getelementptr { i64, [3 x i64] }, ptr %t475, i32 0, i32 1
  %t478 = getelementptr { %"compiler/source:Span", i32, i64 }, ptr %t477, i32 0, i32 2
  %t479 = load i64, ptr %t478
  store i64 %t479, ptr %l26, !tbaa !24
  br label %bb99
bb98:
  br label %bb103
bb99:
  %t481 = load ptr, ptr %l0, !tbaa !29
  %t483 = getelementptr %"compiler/lower:lowering", ptr %t481, i32 0, i32 2
  %t484 = load ptr, ptr %t483, !tbaa !29
  store ptr %t484, ptr %l257, !tbaa !29
  %t485 = load ptr, ptr %l0, !tbaa !29
  %t487 = getelementptr %"compiler/lower:lowering", ptr %t485, i32 0, i32 2
  %t488 = load ptr, ptr %t487, !tbaa !29
  %t489 = load ptr, ptr %l0, !tbaa !29
  %t491 = getelementptr %"compiler/lower:lowering", ptr %t489, i32 0, i32 1
  %t492 = load ptr, ptr %t491, !tbaa !29
  %t494 = getelementptr %"compiler/typed:Body", ptr %t492, i32 0, i32 2
  %t495 = load i32, ptr %t494, !tbaa !23
  %t498 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t488, i32 %t495)
  store i32 %t498, ptr %l263
  br label %bb100
bb100:
  %t499 = load i32, ptr %l25, !tbaa !23
  %t500 = load i64, ptr %l26, !tbaa !24
  %t501 = load ptr, ptr %l257, !tbaa !29
  %t502 = load i32, ptr %l263, !tbaa !23
  %t505 = call i64 @compiler_2fmir_2eErrorCode(ptr %v0, ptr %t501, i32 %t502, i32 %t499, i64 %t500)
  store i64 %t505, ptr %l266
  br label %bb101
bb101:
  %t506 = load i64, ptr %l266, !tbaa !24
  %t507 = load ptr, ptr %l0, !tbaa !29
  %t508 = load %"compiler/source:Span", ptr %l24
  %t509 = load i32, ptr @G_2ecompiler_2fmir_2eI32T, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t511
  %t512 = getelementptr { i64, [4 x i64] }, ptr %t511, i32 0, i32 0
  store i64 2, ptr %t512
  %t514 = insertvalue { i32, i64 } undef, i32 %t509, 0
  %t516 = insertvalue { i32, i64 } %t514, i64 %t506, 1
  %t517 = getelementptr { i64, [4 x i64] }, ptr %t511, i32 0, i32 1
  store { i32, i64 } %t516, ptr %t517
  %t518 = load { i64, [4 x i64] }, ptr %t511
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eraise(ptr %v0, ptr %t507, %"compiler/source:Span" %t508, { i64, [4 x i64] } %t518)
  br label %bb102
bb102:
  br label %bb192
bb103:
  %t522 = load ptr, ptr %l1, !tbaa !29
  store ptr %t522, ptr %l272, !tbaa !29
  store i1 false, ptr %l273, !tbaa !21
  %t523 = load ptr, ptr %l272, !tbaa !29
  %t524 = icmp ne ptr %t523, null
  br i1 %t524, label %bb104, label %bb105
bb104:
  %t526 = load ptr, ptr %l272, !tbaa !29
  %t527 = load i64, ptr %t526
  %t529 = icmp eq i64 %t527, 8
  store i1 %t529, ptr %l273, !tbaa !21
  br label %bb105
bb105:
  %t530 = load i1, ptr %l273, !tbaa !21
  br i1 %t530, label %bb106, label %bb107
bb106:
  %t531 = load ptr, ptr %l1, !tbaa !29
  %t533 = getelementptr { i64, [3 x i64] }, ptr %t531, i32 0, i32 1
  %t534 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t533, i32 0, i32 0
  %t535 = load %"compiler/source:Span", ptr %t534
  store %"compiler/source:Span" %t535, ptr %l28
  %t537 = load ptr, ptr %l1, !tbaa !29
  %t539 = getelementptr { i64, [3 x i64] }, ptr %t537, i32 0, i32 1
  %t540 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t539, i32 0, i32 1
  %t541 = load ptr, ptr %t540
  store ptr %t541, ptr %l29, !tbaa !29
  %t543 = load ptr, ptr %l1, !tbaa !29
  %t545 = getelementptr { i64, [3 x i64] }, ptr %t543, i32 0, i32 1
  %t546 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t545, i32 0, i32 2
  %t547 = load i32, ptr %t546
  store i32 %t547, ptr %l30, !tbaa !23
  br label %bb108
bb107:
  br label %bb125
bb108:
  %t549 = load ptr, ptr %l0, !tbaa !29
  %t550 = load ptr, ptr %l29, !tbaa !29
  %t554 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v1, ptr %t549, ptr %t550)
  store { i64, [4 x i64] } %t554, ptr %l285
  br label %bb109
bb109:
  %t555 = load { i64, [4 x i64] }, ptr %l285
  store { i64, [4 x i64] } %t555, ptr %l31
  %t556 = load ptr, ptr %l0, !tbaa !29
  %t558 = getelementptr %"compiler/lower:lowering", ptr %t556, i32 0, i32 7
  %t559 = load i1, ptr %t558, !tbaa !21
  %t561 = xor i1 %t559, true
  br i1 %t561, label %bb110, label %bb111
bb110:
  %t563 = load ptr, ptr %l0, !tbaa !29
  %t565 = getelementptr %"compiler/lower:lowering", ptr %t563, i32 0, i32 2
  %t566 = load ptr, ptr %t565, !tbaa !29
  store ptr %t566, ptr %l291, !tbaa !29
  %t567 = load ptr, ptr %l0, !tbaa !29
  %t569 = getelementptr %"compiler/lower:lowering", ptr %t567, i32 0, i32 2
  %t570 = load ptr, ptr %t569, !tbaa !29
  %t571 = load ptr, ptr %l0, !tbaa !29
  %t573 = getelementptr %"compiler/lower:lowering", ptr %t571, i32 0, i32 1
  %t574 = load ptr, ptr %t573, !tbaa !29
  %t576 = getelementptr %"compiler/typed:Body", ptr %t574, i32 0, i32 2
  %t577 = load i32, ptr %t576, !tbaa !23
  %t580 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t570, i32 %t577)
  store i32 %t580, ptr %l297
  br label %bb112
bb111:
  store i1 false, ptr %l289, !tbaa !21
  br label %bb114
bb112:
  %t581 = load ptr, ptr %l291, !tbaa !29
  %t582 = load i32, ptr %l297, !tbaa !23
  %t583 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t581, i32 %t582)
  store { i64, ptr } %t583, ptr %l298
  br label %bb113
bb113:
  %t584 = load { i64, ptr }, ptr %l298, !tbaa !27
  %t585 = extractvalue { i64, ptr } %t584, 0
  %t587 = icmp sgt i64 %t585, 0
  store i1 %t587, ptr %l289, !tbaa !21
  br label %bb114
bb114:
  %t589 = load i1, ptr %l289, !tbaa !21
  br i1 %t589, label %bb115, label %bb116
bb115:
  %t590 = load ptr, ptr %l0, !tbaa !29
  store ptr %t590, ptr %l301, !tbaa !29
  %t591 = load %"compiler/source:Span", ptr %l28
  store %"compiler/source:Span" %t591, ptr %l302
  %t592 = load ptr, ptr %l0, !tbaa !29
  store ptr %t592, ptr %l303, !tbaa !29
  %t593 = load i32, ptr @G_2ecompiler_2fmir_2eI32T, !tbaa !23
  store i32 %t593, ptr %l304, !tbaa !23
  %t594 = load { i64, [4 x i64] }, ptr %l31
  store { i64, [4 x i64] } %t594, ptr %l305
  %t595 = load i32, ptr %l30, !tbaa !23
  store i32 %t595, ptr %l306, !tbaa !23
  %t596 = load ptr, ptr %l0, !tbaa !29
  %t598 = getelementptr %"compiler/lower:lowering", ptr %t596, i32 0, i32 2
  %t599 = load ptr, ptr %t598, !tbaa !29
  %t600 = load ptr, ptr %l0, !tbaa !29
  %t602 = getelementptr %"compiler/lower:lowering", ptr %t600, i32 0, i32 1
  %t603 = load ptr, ptr %t602, !tbaa !29
  %t605 = getelementptr %"compiler/typed:Body", ptr %t603, i32 0, i32 2
  %t606 = load i32, ptr %t605, !tbaa !23
  %t609 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t599, i32 %t606)
  store i32 %t609, ptr %l312
  br label %bb117
bb116:
  %t610 = load ptr, ptr %l0, !tbaa !29
  %t612 = getelementptr %"compiler/lower:lowering", ptr %t610, i32 0, i32 7
  %t613 = load i1, ptr %t612, !tbaa !21
  %t615 = xor i1 %t613, true
  br i1 %t615, label %bb120, label %bb121
bb117:
  store { i64, [15 x i64] } zeroinitializer, ptr %t617
  %t618 = getelementptr { i64, [15 x i64] }, ptr %t617, i32 0, i32 0
  store i64 11, ptr %t618
  %t619 = load { i64, [4 x i64] }, ptr %l305
  %t620 = insertvalue { { i64, [4 x i64] }, i32, i32 } undef, { i64, [4 x i64] } %t619, 0
  %t621 = load i32, ptr %l306, !tbaa !23
  %t622 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t620, i32 %t621, 1
  %t623 = load i32, ptr %l312, !tbaa !23
  %t624 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t622, i32 %t623, 2
  %t625 = getelementptr { i64, [15 x i64] }, ptr %t617, i32 0, i32 1
  store { { i64, [4 x i64] }, i32, i32 } %t624, ptr %t625
  %t626 = load { i64, [15 x i64] }, ptr %t617
  %t627 = load %"compiler/source:Span", ptr %l28
  %t628 = load ptr, ptr %l303, !tbaa !29
  %t629 = load i32, ptr %l304, !tbaa !23
  %t632 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %t628, i32 %t629, { i64, [15 x i64] } %t626, %"compiler/source:Span" %t627)
  store { i64, [4 x i64] } %t632, ptr %l315
  br label %bb118
bb118:
  %t633 = load ptr, ptr %l301, !tbaa !29
  %t634 = load %"compiler/source:Span", ptr %l302
  %t635 = load { i64, [4 x i64] }, ptr %l315
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eraise(ptr %v0, ptr %t633, %"compiler/source:Span" %t634, { i64, [4 x i64] } %t635)
  br label %bb119
bb119:
  br label %bb124
bb120:
  %t636 = load ptr, ptr %l0, !tbaa !29
  %t637 = load %"compiler/source:Span", ptr %l28
  %t638 = load { i64, [4 x i64] }, ptr %l31
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eraise(ptr %v0, ptr %t636, %"compiler/source:Span" %t637, { i64, [4 x i64] } %t638)
  br label %bb122
bb121:
  br label %bb123
bb122:
  br label %bb123
bb123:
  br label %bb124
bb124:
  br label %bb192
bb125:
  %t642 = load ptr, ptr %l1, !tbaa !29
  store ptr %t642, ptr %l322, !tbaa !29
  store i1 false, ptr %l323, !tbaa !21
  %t643 = load ptr, ptr %l322, !tbaa !29
  %t644 = icmp ne ptr %t643, null
  br i1 %t644, label %bb126, label %bb127
bb126:
  %t646 = load ptr, ptr %l322, !tbaa !29
  %t647 = load i64, ptr %t646
  %t649 = icmp eq i64 %t647, 9
  store i1 %t649, ptr %l323, !tbaa !21
  br label %bb127
bb127:
  %t650 = load i1, ptr %l323, !tbaa !21
  br i1 %t650, label %bb128, label %bb129
bb128:
  %t651 = load ptr, ptr %l1, !tbaa !29
  %t653 = getelementptr { i64, [3 x i64] }, ptr %t651, i32 0, i32 1
  %t654 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t653, i32 0, i32 0
  %t655 = load %"compiler/source:Span", ptr %t654
  store %"compiler/source:Span" %t655, ptr %l32
  %t657 = load ptr, ptr %l1, !tbaa !29
  %t659 = getelementptr { i64, [3 x i64] }, ptr %t657, i32 0, i32 1
  %t660 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t659, i32 0, i32 1
  %t661 = load i32, ptr %t660
  store i32 %t661, ptr %l33
  %t663 = load ptr, ptr %l1, !tbaa !29
  %t665 = getelementptr { i64, [3 x i64] }, ptr %t663, i32 0, i32 1
  %t666 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t665, i32 0, i32 2
  %t667 = load ptr, ptr %t666
  store ptr %t667, ptr %l34, !tbaa !29
  br label %bb130
bb129:
  br label %bb142
bb130:
  store { i64, [4 x i64] } zeroinitializer, ptr %t669
  %t670 = getelementptr { i64, [4 x i64] }, ptr %t669, i32 0, i32 0
  store i64 0, ptr %t670
  %t671 = load { i64, [4 x i64] }, ptr %t669
  store { i64, [4 x i64] } %t671, ptr %l35
  %t673 = load ptr, ptr %l34, !tbaa !29
  %t675 = icmp eq ptr %t673, null
  %t677 = xor i1 %t675, true
  br i1 %t677, label %bb131, label %bb132
bb131:
  %t679 = load ptr, ptr %l0, !tbaa !29
  %t680 = load ptr, ptr %l34, !tbaa !29
  %t684 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v1, ptr %t679, ptr %t680)
  store { i64, [4 x i64] } %t684, ptr %l339
  br label %bb133
bb132:
  br label %bb134
bb133:
  %t685 = load { i64, [4 x i64] }, ptr %l339
  store { i64, [4 x i64] } %t685, ptr %l35
  br label %bb134
bb134:
  %t686 = load i32, ptr %l33
  %t688 = trunc i64 1 to i32
  %t689 = icmp eq i32 %t686, %t688
  br i1 %t689, label %bb135, label %bb136
bb135:
  store i32 4, ptr %l342
  br label %bb137
bb136:
  store i32 3, ptr %l342
  br label %bb137
bb137:
  %t693 = load i32, ptr %l342
  store i32 %t693, ptr %l36
  %t694 = load ptr, ptr %l0, !tbaa !29
  %t696 = getelementptr %"compiler/lower:lowering", ptr %t694, i32 0, i32 7
  %t697 = load i1, ptr %t696, !tbaa !21
  %t699 = xor i1 %t697, true
  br i1 %t699, label %bb138, label %bb139
bb138:
  %t701 = load ptr, ptr %l0, !tbaa !29
  %t702 = load %"compiler/source:Span", ptr %l32
  %t703 = load i32, ptr %l36
  %t704 = load { i64, [4 x i64] }, ptr %l35
  store { i64, [7 x i64] } zeroinitializer, ptr %t705
  %t706 = getelementptr { i64, [7 x i64] }, ptr %t705, i32 0, i32 0
  store i64 8, ptr %t706
  %t708 = insertvalue { %"compiler/source:Span", i32, { i64, [4 x i64] } } undef, %"compiler/source:Span" %t702, 0
  %t710 = insertvalue { %"compiler/source:Span", i32, { i64, [4 x i64] } } %t708, i32 %t703, 1
  %t712 = insertvalue { %"compiler/source:Span", i32, { i64, [4 x i64] } } %t710, { i64, [4 x i64] } %t704, 2
  %t713 = getelementptr { i64, [7 x i64] }, ptr %t705, i32 0, i32 1
  store { %"compiler/source:Span", i32, { i64, [4 x i64] } } %t712, ptr %t713
  %t714 = load { i64, [7 x i64] }, ptr %t705
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t701, { i64, [7 x i64] } %t714)
  br label %bb140
bb139:
  br label %bb141
bb140:
  br label %bb141
bb141:
  br label %bb192
bb142:
  %t717 = load ptr, ptr %l1, !tbaa !29
  store ptr %t717, ptr %l353, !tbaa !29
  store i1 false, ptr %l354, !tbaa !21
  %t718 = load ptr, ptr %l353, !tbaa !29
  %t719 = icmp ne ptr %t718, null
  br i1 %t719, label %bb143, label %bb144
bb143:
  %t721 = load ptr, ptr %l353, !tbaa !29
  %t722 = load i64, ptr %t721
  %t724 = icmp eq i64 %t722, 10
  store i1 %t724, ptr %l354, !tbaa !21
  br label %bb144
bb144:
  %t725 = load i1, ptr %l354, !tbaa !21
  br i1 %t725, label %bb145, label %bb146
bb145:
  %t726 = load ptr, ptr %l1, !tbaa !29
  %t728 = getelementptr { i64, [3 x i64] }, ptr %t726, i32 0, i32 1
  %t729 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t728, i32 0, i32 0
  %t730 = load %"compiler/source:Span", ptr %t729
  store %"compiler/source:Span" %t730, ptr %l37
  %t732 = load ptr, ptr %l1, !tbaa !29
  %t734 = getelementptr { i64, [3 x i64] }, ptr %t732, i32 0, i32 1
  %t735 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t734, i32 0, i32 1
  %t736 = load ptr, ptr %t735
  store ptr %t736, ptr %l38, !tbaa !29
  %t738 = load ptr, ptr %l1, !tbaa !29
  %t740 = getelementptr { i64, [3 x i64] }, ptr %t738, i32 0, i32 1
  %t741 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t740, i32 0, i32 2
  %t742 = load ptr, ptr %t741
  store ptr %t742, ptr %l39, !tbaa !29
  br label %bb147
bb146:
  br label %bb149
bb147:
  %t744 = load ptr, ptr %l0, !tbaa !29
  %t745 = load %"compiler/source:Span", ptr %l37
  %t746 = load ptr, ptr %l38, !tbaa !29
  %t747 = load ptr, ptr %l39, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eassert(ptr %v0, ptr %v1, ptr %v1, ptr %t744, %"compiler/source:Span" %t745, ptr %t746, ptr %t747)
  br label %bb148
bb148:
  br label %bb192
bb149:
  %t752 = load ptr, ptr %l1, !tbaa !29
  store ptr %t752, ptr %l367, !tbaa !29
  store i1 false, ptr %l368, !tbaa !21
  %t753 = load ptr, ptr %l367, !tbaa !29
  %t754 = icmp ne ptr %t753, null
  br i1 %t754, label %bb150, label %bb151
bb150:
  %t756 = load ptr, ptr %l367, !tbaa !29
  %t757 = load i64, ptr %t756
  %t759 = icmp eq i64 %t757, 11
  store i1 %t759, ptr %l368, !tbaa !21
  br label %bb151
bb151:
  %t760 = load i1, ptr %l368, !tbaa !21
  br i1 %t760, label %bb152, label %bb153
bb152:
  %t761 = load ptr, ptr %l1, !tbaa !29
  %t763 = getelementptr { i64, [3 x i64] }, ptr %t761, i32 0, i32 1
  %t764 = getelementptr { %"compiler/source:Span", ptr }, ptr %t763, i32 0, i32 1
  %t765 = load ptr, ptr %t764
  store ptr %t765, ptr %l40, !tbaa !29
  br label %bb154
bb153:
  br label %bb156
bb154:
  %t767 = load ptr, ptr %l0, !tbaa !29
  %t768 = load ptr, ptr %l40, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eblock(ptr %v0, ptr %v1, ptr %t767, ptr %t768)
  br label %bb155
bb155:
  br label %bb192
bb156:
  %t771 = load ptr, ptr %l1, !tbaa !29
  store ptr %t771, ptr %l375, !tbaa !29
  store i1 false, ptr %l376, !tbaa !21
  %t772 = load ptr, ptr %l375, !tbaa !29
  %t773 = icmp ne ptr %t772, null
  br i1 %t773, label %bb157, label %bb158
bb157:
  %t775 = load ptr, ptr %l375, !tbaa !29
  %t776 = load i64, ptr %t775
  %t778 = icmp eq i64 %t776, 12
  store i1 %t778, ptr %l376, !tbaa !21
  br label %bb158
bb158:
  %t779 = load i1, ptr %l376, !tbaa !21
  br i1 %t779, label %bb159, label %bb160
bb159:
  %t780 = load ptr, ptr %l1, !tbaa !29
  %t782 = getelementptr { i64, [3 x i64] }, ptr %t780, i32 0, i32 1
  %t783 = getelementptr { %"compiler/source:Span", ptr }, ptr %t782, i32 0, i32 0
  %t784 = load %"compiler/source:Span", ptr %t783
  store %"compiler/source:Span" %t784, ptr %l41
  %t786 = load ptr, ptr %l1, !tbaa !29
  %t788 = getelementptr { i64, [3 x i64] }, ptr %t786, i32 0, i32 1
  %t789 = getelementptr { %"compiler/source:Span", ptr }, ptr %t788, i32 0, i32 1
  %t790 = load ptr, ptr %t789
  store ptr %t790, ptr %l42, !tbaa !29
  br label %bb161
bb160:
  br label %bb170
bb161:
  %t792 = load ptr, ptr %l0, !tbaa !29
  %t794 = getelementptr %"compiler/lower:lowering", ptr %t792, i32 0, i32 10
  %t795 = load ptr, ptr %l42, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aBlock_26_3e_2ePu_H0a6921d1f6104d156ffed3729e33edeb(ptr %v0, ptr %v1, ptr %t794, ptr %t795)
  br label %bb162
bb162:
  %t798 = load ptr, ptr %l0, !tbaa !29
  %t800 = getelementptr %"compiler/lower:lowering", ptr %t798, i32 0, i32 11
  store ptr %t800, ptr %l387, !tbaa !29
  %t801 = load ptr, ptr %l0, !tbaa !29
  %t803 = call %"compiler/lower:level" @compiler_2flower_2ecompiler_2flower_3alowering_2etop(ptr %v0, ptr %t801)
  store %"compiler/lower:level" %t803, ptr %l389
  br label %bb163
bb163:
  %t804 = getelementptr %"compiler/lower:level", ptr %l389, i32 0, i32 0
  %t805 = load i32, ptr %t804, !tbaa !23
  %t806 = load ptr, ptr %l387, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeId_3e_2ePush_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t806, i32 %t805)
  br label %bb164
bb164:
  %t808 = load ptr, ptr %l0, !tbaa !29
  %t810 = getelementptr %"compiler/lower:lowering", ptr %t808, i32 0, i32 0
  %t811 = load ptr, ptr %t810, !tbaa !29
  %t813 = getelementptr %"compiler/lower:Lowerer", ptr %t811, i32 0, i32 5
  %t814 = load i1, ptr %t813, !tbaa !21
  br i1 %t814, label %bb165, label %bb166
bb165:
  %t816 = load ptr, ptr %l0, !tbaa !29
  store ptr %t816, ptr %l394, !tbaa !29
  %t817 = load %"compiler/source:Span", ptr %l41
  store %"compiler/source:Span" %t817, ptr %l395
  %t818 = load ptr, ptr %l0, !tbaa !29
  %t820 = getelementptr %"compiler/lower:lowering", ptr %t818, i32 0, i32 10
  %t822 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aBlock_26_3e_2eLe_H8743fc75fe5cead0bda2da42e1adf3f3(ptr %v0, ptr %t820)
  store i64 %t822, ptr %l398
  br label %bb167
bb166:
  br label %bb169
bb167:
  %t823 = load i64, ptr %l398, !tbaa !24
  %t824 = sub i64 %t823, 1
  %t825 = load ptr, ptr %l394, !tbaa !29
  %t826 = load %"compiler/source:Span", ptr %l395
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2ecleanup(ptr %v0, ptr %t825, %"compiler/source:Span" %t826, i64 %t824)
  br label %bb168
bb168:
  br label %bb169
bb169:
  br label %bb192
bb170:
  %t828 = load ptr, ptr %l1, !tbaa !29
  store ptr %t828, ptr %l400, !tbaa !29
  store i1 false, ptr %l401, !tbaa !21
  %t829 = load ptr, ptr %l400, !tbaa !29
  %t830 = icmp ne ptr %t829, null
  br i1 %t830, label %bb171, label %bb172
bb171:
  %t832 = load ptr, ptr %l400, !tbaa !29
  %t833 = load i64, ptr %t832
  %t835 = icmp eq i64 %t833, 13
  store i1 %t835, ptr %l401, !tbaa !21
  br label %bb172
bb172:
  %t836 = load i1, ptr %l401, !tbaa !21
  br i1 %t836, label %bb173, label %bb174
bb173:
  %t837 = load ptr, ptr %l1, !tbaa !29
  %t839 = getelementptr { i64, [3 x i64] }, ptr %t837, i32 0, i32 1
  %t840 = getelementptr { %"compiler/source:Span", ptr }, ptr %t839, i32 0, i32 0
  %t841 = load %"compiler/source:Span", ptr %t840
  store %"compiler/source:Span" %t841, ptr %l43
  %t843 = load ptr, ptr %l1, !tbaa !29
  %t845 = getelementptr { i64, [3 x i64] }, ptr %t843, i32 0, i32 1
  %t846 = getelementptr { %"compiler/source:Span", ptr }, ptr %t845, i32 0, i32 1
  %t847 = load ptr, ptr %t846
  store ptr %t847, ptr %l44, !tbaa !29
  br label %bb175
bb174:
  br label %bb177
bb175:
  %t849 = load ptr, ptr %l0, !tbaa !29
  %t850 = load %"compiler/source:Span", ptr %l43
  %t851 = load ptr, ptr %l44, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2ejoin(ptr %v0, ptr %v1, ptr %t849, %"compiler/source:Span" %t850, ptr %t851)
  br label %bb176
bb176:
  br label %bb192
bb177:
  %t855 = load ptr, ptr %l1, !tbaa !29
  store ptr %t855, ptr %l411, !tbaa !29
  store i1 false, ptr %l412, !tbaa !21
  %t856 = load ptr, ptr %l411, !tbaa !29
  %t857 = icmp ne ptr %t856, null
  br i1 %t857, label %bb178, label %bb179
bb178:
  %t859 = load ptr, ptr %l411, !tbaa !29
  %t860 = load i64, ptr %t859
  %t862 = icmp eq i64 %t860, 14
  store i1 %t862, ptr %l412, !tbaa !21
  br label %bb179
bb179:
  %t863 = load i1, ptr %l412, !tbaa !21
  br i1 %t863, label %bb180, label %bb181
bb180:
  %t864 = load ptr, ptr %l1, !tbaa !29
  %t866 = getelementptr { i64, [3 x i64] }, ptr %t864, i32 0, i32 1
  %t867 = getelementptr { %"compiler/source:Span", ptr }, ptr %t866, i32 0, i32 0
  %t868 = load %"compiler/source:Span", ptr %t867
  store %"compiler/source:Span" %t868, ptr %l45
  %t870 = load ptr, ptr %l1, !tbaa !29
  %t872 = getelementptr { i64, [3 x i64] }, ptr %t870, i32 0, i32 1
  %t873 = getelementptr { %"compiler/source:Span", ptr }, ptr %t872, i32 0, i32 1
  %t874 = load ptr, ptr %t873
  store ptr %t874, ptr %l46, !tbaa !29
  br label %bb182
bb181:
  br label %bb184
bb182:
  %t876 = load ptr, ptr %l0, !tbaa !29
  %t877 = load %"compiler/source:Span", ptr %l45
  %t878 = load ptr, ptr %l46, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2espawn(ptr %v0, ptr %v1, ptr %t876, %"compiler/source:Span" %t877, ptr %t878)
  br label %bb183
bb183:
  br label %bb192
bb184:
  %t882 = load ptr, ptr %l1, !tbaa !29
  store ptr %t882, ptr %l422, !tbaa !29
  store i1 false, ptr %l423, !tbaa !21
  %t883 = load ptr, ptr %l422, !tbaa !29
  %t884 = icmp ne ptr %t883, null
  br i1 %t884, label %bb185, label %bb186
bb185:
  %t886 = load ptr, ptr %l422, !tbaa !29
  %t887 = load i64, ptr %t886
  %t889 = icmp eq i64 %t887, 15
  store i1 %t889, ptr %l423, !tbaa !21
  br label %bb186
bb186:
  %t890 = load i1, ptr %l423, !tbaa !21
  br i1 %t890, label %bb187, label %bb188
bb187:
  %t891 = load ptr, ptr %l1, !tbaa !29
  %t893 = getelementptr { i64, [3 x i64] }, ptr %t891, i32 0, i32 1
  %t894 = getelementptr { %"compiler/source:Span", ptr }, ptr %t893, i32 0, i32 0
  %t895 = load %"compiler/source:Span", ptr %t894
  store %"compiler/source:Span" %t895, ptr %l47
  %t897 = load ptr, ptr %l1, !tbaa !29
  %t899 = getelementptr { i64, [3 x i64] }, ptr %t897, i32 0, i32 1
  %t900 = getelementptr { %"compiler/source:Span", ptr }, ptr %t899, i32 0, i32 1
  %t901 = load ptr, ptr %t900
  store ptr %t901, ptr %l48, !tbaa !29
  br label %bb189
bb188:
  br label %bb191
bb189:
  %t903 = load ptr, ptr %l0, !tbaa !29
  %t904 = load %"compiler/source:Span", ptr %l47
  %t905 = load ptr, ptr %l48, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eyield(ptr %v0, ptr %v1, ptr %t903, %"compiler/source:Span" %t904, ptr %t905)
  br label %bb190
bb190:
  br label %bb192
bb191:
  call void @__olang_check_failed(ptr @olang_loc_b7b09248cda006f_e3ce57a596777ddb)
  unreachable
bb192:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2estmtSpawnErrors(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i32
  %l10 = alloca i1
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca ptr
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca %"compiler/typed:Item"
  %l19 = alloca i1
  %l20 = alloca ptr
  %l21 = alloca i64
  %l22 = alloca { i64, ptr }
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i32
  %l26 = alloca ptr
  %l27 = alloca ptr
  %l28 = alloca ptr
  %l29 = alloca ptr
  %l32 = alloca ptr
  %l33 = alloca i1
  %l41 = alloca i32
  %l45 = alloca ptr
  %l48 = alloca i32
  %l49 = alloca { i64, ptr }
  %l56 = alloca { i64, ptr }
  %l67 = alloca { i64, ptr }
  %l80 = alloca { i64, ptr }
  %l85 = alloca i1
  %l86 = alloca ptr
  %l89 = alloca i32
  %l92 = alloca i32
  %l93 = alloca i1
  %l100 = alloca { i64, ptr }
  %l103 = alloca { i64, ptr }
  %l104 = alloca i32
  %l113 = alloca { i64, ptr }
  %l117 = alloca i1
  %l118 = alloca ptr
  %l121 = alloca i32
  %l124 = alloca i32
  %l125 = alloca i1
  %l133 = alloca ptr
  %l136 = alloca i32
  %l139 = alloca ptr
  %l140 = alloca i1
  %l149 = alloca ptr
  %l150 = alloca i1
  %l164 = alloca ptr
  %l165 = alloca i1
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s16 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t6 = load ptr, ptr %l1, !tbaa !29
  store ptr %t6, ptr %l32, !tbaa !29
  store i1 false, ptr %l33, !tbaa !21
  %t7 = load ptr, ptr %l32, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l32, !tbaa !29
  %t11 = load i64, ptr %t10
  %t13 = icmp eq i64 %t11, 14
  store i1 %t13, ptr %l33, !tbaa !21
  br label %bb2
bb2:
  %t14 = load i1, ptr %l33, !tbaa !21
  br i1 %t14, label %bb3, label %bb4
bb3:
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t17 = getelementptr { i64, [3 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { %"compiler/source:Span", ptr }, ptr %t17, i32 0, i32 1
  %t19 = load ptr, ptr %t18
  store ptr %t19, ptr %l4, !tbaa !29
  br label %bb5
bb4:
  br label %bb71
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load ptr, ptr %l4, !tbaa !29
  %t24 = getelementptr %"compiler/typed:Spawn", ptr %t22, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t28 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2etaskType(ptr %v0, ptr %v1, ptr %t21, ptr %t25)
  store i32 %t28, ptr %l41
  br label %bb6
bb6:
  %t29 = load i32, ptr %l41, !tbaa !23
  store i32 %t29, ptr %l5, !tbaa !23
  %t30 = load i32, ptr %l5, !tbaa !23
  %t31 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t34 = icmp eq i32 %t30, %t31
  br i1 %t34, label %bb7, label %bb8
bb7:
  br label %ret
bb8:
  br label %bb9
bb9:
  %t36 = load ptr, ptr %l3, !tbaa !29
  store ptr %t36, ptr %l45, !tbaa !29
  %t37 = load ptr, ptr %l3, !tbaa !29
  %t38 = load i32, ptr %l5, !tbaa !23
  %t41 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t37, i32 %t38)
  store i32 %t41, ptr %l48
  br label %bb10
bb10:
  %t42 = load ptr, ptr %l45, !tbaa !29
  %t43 = load i32, ptr %l48, !tbaa !23
  %t44 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t42, i32 %t43)
  store { i64, ptr } %t44, ptr %l49
  br label %bb11
bb11:
  %t45 = load { i64, ptr }, ptr %l49, !tbaa !27
  store { i64, ptr } %t45, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t46 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t48 = extractvalue { i64, ptr } %t46, 0
  store i64 %t48, ptr %l8, !tbaa !24
  br label %bb12
bb12:
  store %olang.scope zeroinitializer, ptr %s4
  %t50 = load i64, ptr %l7, !tbaa !24
  %t51 = load i64, ptr %l8, !tbaa !24
  %t54 = icmp slt i64 %t50, %t51
  %t56 = xor i1 %t54, true
  br i1 %t56, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s4)
  br label %bb70
bb14:
  br label %bb15
bb15:
  %t58 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t58, ptr %l56, !tbaa !27
  %t59 = load i64, ptr %l7, !tbaa !24
  %t61 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !27
  %t63 = getelementptr i32, ptr %t62, i64 %t59
  %t64 = load i32, ptr %t63, !tbaa !33
  store i32 %t64, ptr %l9, !tbaa !23
  store i1 false, ptr %l10, !tbaa !21
  %t66 = load ptr, ptr %l4, !tbaa !29
  %t68 = getelementptr %"compiler/typed:Spawn", ptr %t66, i32 0, i32 2
  %t69 = load { i64, ptr }, ptr %t68, !tbaa !27
  store { i64, ptr } %t69, ptr %l11, !tbaa !27
  store i64 0, ptr %l12, !tbaa !24
  %t71 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t73 = extractvalue { i64, ptr } %t71, 0
  store i64 %t73, ptr %l13, !tbaa !24
  br label %bb16
bb16:
  store %olang.scope zeroinitializer, ptr %s6
  %t75 = load i64, ptr %l12, !tbaa !24
  %t76 = load i64, ptr %l13, !tbaa !24
  %t79 = icmp slt i64 %t75, %t76
  %t81 = xor i1 %t79, true
  br i1 %t81, label %bb17, label %bb18
bb17:
  call void @__olang_scope_close(ptr %s6)
  br label %bb39
bb18:
  br label %bb19
bb19:
  %t83 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t83, ptr %l67, !tbaa !27
  %t84 = load i64, ptr %l12, !tbaa !24
  %t86 = getelementptr { i64, ptr }, ptr %l67, i32 0, i32 1
  %t87 = load ptr, ptr %t86, !tbaa !27
  %t88 = getelementptr ptr, ptr %t87, i64 %t84
  %t89 = load ptr, ptr %t88, !tbaa !39
  store ptr %t89, ptr %l14, !tbaa !29
  %t91 = load ptr, ptr %l14, !tbaa !29
  %t93 = getelementptr %"compiler/typed:TaskClause", ptr %t91, i32 0, i32 2
  %t94 = load i1, ptr %t93, !tbaa !21
  br i1 %t94, label %bb20, label %bb21
bb20:
  store i1 true, ptr %l10, !tbaa !21
  br label %bb22
bb21:
  br label %bb22
bb22:
  %t96 = load ptr, ptr %l14, !tbaa !29
  %t98 = getelementptr %"compiler/typed:TaskClause", ptr %t96, i32 0, i32 1
  %t99 = load { i64, ptr }, ptr %t98, !tbaa !27
  store { i64, ptr } %t99, ptr %l15, !tbaa !27
  store i64 0, ptr %l16, !tbaa !24
  %t101 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t103 = extractvalue { i64, ptr } %t101, 0
  store i64 %t103, ptr %l17, !tbaa !24
  br label %bb23
bb23:
  store %olang.scope zeroinitializer, ptr %s9
  %t105 = load i64, ptr %l16, !tbaa !24
  %t106 = load i64, ptr %l17, !tbaa !24
  %t109 = icmp slt i64 %t105, %t106
  %t111 = xor i1 %t109, true
  br i1 %t111, label %bb24, label %bb25
bb24:
  call void @__olang_scope_close(ptr %s9)
  br label %bb37
bb25:
  br label %bb26
bb26:
  %t113 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t113, ptr %l80, !tbaa !27
  %t114 = load i64, ptr %l16, !tbaa !24
  %t116 = getelementptr { i64, ptr }, ptr %l80, i32 0, i32 1
  %t117 = load ptr, ptr %t116, !tbaa !27
  %t118 = getelementptr %"compiler/typed:Item", ptr %t117, i64 %t114
  %t119 = load %"compiler/typed:Item", ptr %t118
  store %"compiler/typed:Item" %t119, ptr %l18
  %t121 = getelementptr %"compiler/typed:Item", ptr %l18, i32 0, i32 1
  %t122 = load i64, ptr %t121, !tbaa !24
  %t124 = icmp slt i64 %t122, 0
  br i1 %t124, label %bb27, label %bb28
bb27:
  %t126 = load ptr, ptr %l3, !tbaa !29
  store ptr %t126, ptr %l86, !tbaa !29
  %t127 = load ptr, ptr %l3, !tbaa !29
  %t128 = getelementptr %"compiler/typed:Item", ptr %l18, i32 0, i32 0
  %t129 = load i32, ptr %t128, !tbaa !23
  %t132 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t127, i32 %t129)
  store i32 %t132, ptr %l89
  br label %bb29
bb28:
  store i1 false, ptr %l85, !tbaa !21
  br label %bb32
bb29:
  %t133 = load ptr, ptr %l3, !tbaa !29
  %t134 = load i32, ptr %l9, !tbaa !23
  %t137 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t133, i32 %t134)
  store i32 %t137, ptr %l92
  br label %bb30
bb30:
  %t138 = load ptr, ptr %l86, !tbaa !29
  %t139 = load i32, ptr %l89, !tbaa !23
  %t140 = load i32, ptr %l92, !tbaa !23
  %t141 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t138, i32 %t139, i32 %t140)
  store i1 %t141, ptr %l93
  br label %bb31
bb31:
  %t142 = load i1, ptr %l93, !tbaa !21
  store i1 %t142, ptr %l85, !tbaa !21
  br label %bb32
bb32:
  %t143 = load i1, ptr %l85, !tbaa !21
  br i1 %t143, label %bb33, label %bb34
bb33:
  store i1 true, ptr %l10, !tbaa !21
  br label %bb35
bb34:
  br label %bb35
bb35:
  call void @__olang_scope_close(ptr %s9)
  br label %bb36
bb36:
  %t144 = load i64, ptr %l16, !tbaa !24
  %t146 = add i64 %t144, 1
  store i64 %t146, ptr %l16, !tbaa !24
  br label %bb23
bb37:
  call void @__olang_scope_close(ptr %s6)
  br label %bb38
bb38:
  %t148 = load i64, ptr %l12, !tbaa !24
  %t150 = add i64 %t148, 1
  store i64 %t150, ptr %l12, !tbaa !24
  br label %bb16
bb39:
  %t152 = load i1, ptr %l10, !tbaa !21
  br i1 %t152, label %bb40, label %bb41
bb40:
  call void @__olang_scope_close(ptr %s4)
  br label %bb69
bb41:
  br label %bb42
bb42:
  store i1 false, ptr %l19, !tbaa !21
  %t154 = load ptr, ptr %l2, !tbaa !29
  store ptr %t154, ptr %l20, !tbaa !29
  store i64 0, ptr %l21, !tbaa !24
  br label %bb43
bb43:
  store %olang.scope zeroinitializer, ptr %s15
  %t156 = load ptr, ptr %l20, !tbaa !29
  %t157 = load i64, ptr %l21, !tbaa !24
  %t160 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eRunF_H9c1707946c43ec840ffe1821bea89b1f(ptr %v2, ptr %t156, i64 %t157)
  %t161 = extractvalue { i32, { i64, ptr } } %t160, 1
  %t162 = extractvalue { i32, { i64, ptr } } %t160, 0
  store i32 %t162, ptr %l104
  %t163 = icmp ne i32 %t162, 0
  br i1 %t163, label %bb45, label %ok.164
ok.164:
  store { i64, ptr } %t161, ptr %l103
  br label %bb44
bb44:
  %t165 = load { i64, ptr }, ptr %l103, !tbaa !27
  store { i64, ptr } %t165, ptr %l100, !tbaa !27
  br label %bb49
bb45:
  %t166 = load i32, ptr %l104, !tbaa !23
  %t167 = ashr i32 %t166, 16
  %t169 = icmp eq i32 %t167, 1
  br i1 %t169, label %bb46, label %bb47
bb46:
  br label %bb48
bb47:
  call void @__olang_check_failed(ptr @olang_loc_7b1a9423057e34c5_261f06cd9be6d659)
  unreachable
bb48:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s15)
  br label %bb63
bb49:
  %t171 = load { i64, ptr }, ptr %l100, !tbaa !27
  store { i64, ptr } %t171, ptr %l22, !tbaa !27
  %t172 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t174 = extractvalue { i64, ptr } %t172, 0
  store i64 %t174, ptr %l23, !tbaa !24
  store i64 0, ptr %l24, !tbaa !24
  br label %bb50
bb50:
  store %olang.scope zeroinitializer, ptr %s16
  %t176 = load i64, ptr %l24, !tbaa !24
  %t177 = load i64, ptr %l23, !tbaa !24
  %t180 = icmp slt i64 %t176, %t177
  %t182 = xor i1 %t180, true
  br i1 %t182, label %bb51, label %bb52
bb51:
  call void @__olang_scope_close(ptr %s16)
  br label %bb61
bb52:
  br label %bb53
bb53:
  %t184 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t184, ptr %l113, !tbaa !27
  %t185 = load i64, ptr %l24, !tbaa !24
  %t187 = getelementptr { i64, ptr }, ptr %l113, i32 0, i32 1
  %t188 = load ptr, ptr %t187, !tbaa !27
  %t189 = getelementptr i32, ptr %t188, i64 %t185
  %t190 = load i32, ptr %t189, !tbaa !33
  store i32 %t190, ptr %l25, !tbaa !23
  %t192 = load i1, ptr %l19, !tbaa !21
  br i1 %t192, label %bb54, label %bb55
bb54:
  store i1 true, ptr %l117, !tbaa !21
  br label %bb59
bb55:
  %t194 = load ptr, ptr %l3, !tbaa !29
  store ptr %t194, ptr %l118, !tbaa !29
  %t195 = load ptr, ptr %l3, !tbaa !29
  %t196 = load i32, ptr %l25, !tbaa !23
  %t199 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t195, i32 %t196)
  store i32 %t199, ptr %l121
  br label %bb56
bb56:
  %t200 = load ptr, ptr %l3, !tbaa !29
  %t201 = load i32, ptr %l9, !tbaa !23
  %t204 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t200, i32 %t201)
  store i32 %t204, ptr %l124
  br label %bb57
bb57:
  %t205 = load ptr, ptr %l118, !tbaa !29
  %t206 = load i32, ptr %l121, !tbaa !23
  %t207 = load i32, ptr %l124, !tbaa !23
  %t208 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t205, i32 %t206, i32 %t207)
  store i1 %t208, ptr %l125
  br label %bb58
bb58:
  %t209 = load i1, ptr %l125, !tbaa !21
  store i1 %t209, ptr %l117, !tbaa !21
  br label %bb59
bb59:
  %t210 = load i1, ptr %l117, !tbaa !21
  store i1 %t210, ptr %l19, !tbaa !21
  call void @__olang_scope_close(ptr %s16)
  br label %bb60
bb60:
  %t211 = load i64, ptr %l24, !tbaa !24
  %t213 = add i64 %t211, 1
  store i64 %t213, ptr %l24, !tbaa !24
  br label %bb50
bb61:
  %t215 = load i64, ptr %l21, !tbaa !24
  %t216 = load i64, ptr %l23, !tbaa !24
  %t219 = add i64 %t215, %t216
  store i64 %t219, ptr %l21, !tbaa !24
  call void @__olang_scope_close(ptr %s15)
  br label %bb62
bb62:
  br label %bb43
bb63:
  %t221 = load i1, ptr %l19, !tbaa !21
  %t223 = xor i1 %t221, true
  br i1 %t223, label %bb64, label %bb65
bb64:
  %t225 = load ptr, ptr %l2, !tbaa !29
  store ptr %t225, ptr %l133, !tbaa !29
  %t226 = load ptr, ptr %l3, !tbaa !29
  %t227 = load i32, ptr %l9, !tbaa !23
  %t230 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t226, i32 %t227)
  store i32 %t230, ptr %l136
  br label %bb66
bb65:
  br label %bb68
bb66:
  %t231 = load ptr, ptr %l133, !tbaa !29
  %t232 = load i32, ptr %l136, !tbaa !23
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v2, ptr %t231, i32 %t232)
  br label %bb67
bb67:
  br label %bb68
bb68:
  call void @__olang_scope_close(ptr %s4)
  br label %bb69
bb69:
  %t233 = load i64, ptr %l7, !tbaa !24
  %t235 = add i64 %t233, 1
  store i64 %t235, ptr %l7, !tbaa !24
  br label %bb12
bb70:
  br label %bb99
bb71:
  %t237 = load ptr, ptr %l1, !tbaa !29
  store ptr %t237, ptr %l139, !tbaa !29
  store i1 false, ptr %l140, !tbaa !21
  %t238 = load ptr, ptr %l139, !tbaa !29
  %t239 = icmp ne ptr %t238, null
  br i1 %t239, label %bb72, label %bb73
bb72:
  %t241 = load ptr, ptr %l139, !tbaa !29
  %t242 = load i64, ptr %t241
  %t244 = icmp eq i64 %t242, 11
  store i1 %t244, ptr %l140, !tbaa !21
  br label %bb73
bb73:
  %t245 = load i1, ptr %l140, !tbaa !21
  br i1 %t245, label %bb74, label %bb75
bb74:
  %t246 = load ptr, ptr %l1, !tbaa !29
  %t248 = getelementptr { i64, [3 x i64] }, ptr %t246, i32 0, i32 1
  %t249 = getelementptr { %"compiler/source:Span", ptr }, ptr %t248, i32 0, i32 1
  %t250 = load ptr, ptr %t249
  store ptr %t250, ptr %l26, !tbaa !29
  br label %bb76
bb75:
  br label %bb78
bb76:
  %t252 = load ptr, ptr %l0, !tbaa !29
  %t253 = load ptr, ptr %l26, !tbaa !29
  %t255 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2espawnErrors(ptr %v0, ptr %v1, ptr %v2, ptr %t252, ptr %t253, ptr %t255)
  br label %bb77
bb77:
  br label %bb99
bb78:
  %t259 = load ptr, ptr %l1, !tbaa !29
  store ptr %t259, ptr %l149, !tbaa !29
  store i1 false, ptr %l150, !tbaa !21
  %t260 = load ptr, ptr %l149, !tbaa !29
  %t261 = icmp ne ptr %t260, null
  br i1 %t261, label %bb79, label %bb80
bb79:
  %t263 = load ptr, ptr %l149, !tbaa !29
  %t264 = load i64, ptr %t263
  %t266 = icmp eq i64 %t264, 3
  store i1 %t266, ptr %l150, !tbaa !21
  br label %bb80
bb80:
  %t267 = load i1, ptr %l150, !tbaa !21
  br i1 %t267, label %bb81, label %bb82
bb81:
  %t268 = load ptr, ptr %l1, !tbaa !29
  %t270 = getelementptr { i64, [3 x i64] }, ptr %t268, i32 0, i32 1
  %t271 = getelementptr { %"compiler/source:Span", ptr }, ptr %t270, i32 0, i32 1
  %t272 = load ptr, ptr %t271
  store ptr %t272, ptr %l27, !tbaa !29
  br label %bb83
bb82:
  br label %bb86
bb83:
  %t274 = load ptr, ptr %l0, !tbaa !29
  %t275 = load ptr, ptr %l27, !tbaa !29
  %t277 = getelementptr %"compiler/typed:If", ptr %t275, i32 0, i32 1
  %t278 = load ptr, ptr %t277, !tbaa !29
  %t280 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2espawnErrors(ptr %v0, ptr %v1, ptr %v2, ptr %t274, ptr %t278, ptr %t280)
  br label %bb84
bb84:
  %t284 = load ptr, ptr %l0, !tbaa !29
  %t285 = load ptr, ptr %l27, !tbaa !29
  %t287 = getelementptr %"compiler/typed:If", ptr %t285, i32 0, i32 2
  %t288 = load ptr, ptr %t287, !tbaa !29
  %t289 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2espawnErrors(ptr %v0, ptr %v1, ptr %v2, ptr %t284, ptr %t288, ptr %t289)
  br label %bb85
bb85:
  br label %bb99
bb86:
  %t293 = load ptr, ptr %l1, !tbaa !29
  store ptr %t293, ptr %l164, !tbaa !29
  store i1 false, ptr %l165, !tbaa !21
  %t294 = load ptr, ptr %l164, !tbaa !29
  %t295 = icmp ne ptr %t294, null
  br i1 %t295, label %bb87, label %bb88
bb87:
  %t297 = load ptr, ptr %l164, !tbaa !29
  %t298 = load i64, ptr %t297
  %t300 = icmp eq i64 %t298, 4
  store i1 %t300, ptr %l165, !tbaa !21
  br label %bb88
bb88:
  %t301 = load i1, ptr %l165, !tbaa !21
  br i1 %t301, label %bb89, label %bb90
bb89:
  %t302 = load ptr, ptr %l1, !tbaa !29
  %t304 = getelementptr { i64, [3 x i64] }, ptr %t302, i32 0, i32 1
  %t305 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t304, i32 0, i32 1
  %t306 = load ptr, ptr %t305
  store ptr %t306, ptr %l28, !tbaa !29
  %t308 = load ptr, ptr %l1, !tbaa !29
  %t310 = getelementptr { i64, [3 x i64] }, ptr %t308, i32 0, i32 1
  %t311 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t310, i32 0, i32 2
  %t312 = load ptr, ptr %t311
  store ptr %t312, ptr %l29, !tbaa !29
  br label %bb91
bb90:
  br label %bb94
bb91:
  %t314 = load ptr, ptr %l0, !tbaa !29
  %t315 = load ptr, ptr %l28, !tbaa !29
  %t317 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2espawnErrors(ptr %v0, ptr %v1, ptr %v2, ptr %t314, ptr %t315, ptr %t317)
  br label %bb92
bb92:
  %t321 = load ptr, ptr %l0, !tbaa !29
  %t322 = load ptr, ptr %l29, !tbaa !29
  %t323 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2espawnErrors(ptr %v0, ptr %v1, ptr %v2, ptr %t321, ptr %t322, ptr %t323)
  br label %bb93
bb93:
  br label %bb99
bb94:
  br i1 true, label %bb95, label %bb96
bb95:
  br label %bb97
bb96:
  br label %bb98
bb97:
  br label %bb99
bb98:
  call void @__olang_check_failed(ptr @olang_loc_4d2a900631880414_3719f57230f55c88)
  unreachable
bb99:
  br label %ret
ret:
  ret void
}

define dso_local { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2estorageOf(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca { i64, [1 x i64] }
  %l11 = alloca %"compiler/mir:Local"
  %l17 = alloca ptr
  %l23 = alloca %"compiler/typed:Local"
  %l26 = alloca { i64, [1 x i64] }
  %rv = alloca { i64, [1 x i64] }
  %t8 = alloca { i64, [1 x i64] }, align 8
  %t49 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 19
  %t4 = load i1, ptr %t3, !tbaa !21
  %t6 = xor i1 %t4, true
  br i1 %t6, label %bb1, label %bb2
bb1:
  store { i64, [1 x i64] } zeroinitializer, ptr %t8
  %t9 = getelementptr { i64, [1 x i64] }, ptr %t8, i32 0, i32 0
  store i64 2, ptr %t9
  %t10 = load { i64, [1 x i64] }, ptr %t8
  store { i64, [1 x i64] } %t10, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/lower:lowering", ptr %t12, i32 0, i32 3
  %t15 = getelementptr %"compiler/mir:Fn", ptr %t14, i32 0, i32 7
  %t16 = load i32, ptr %l1, !tbaa !23
  %t18 = sext i32 %t16 to i64
  %t21 = call %"compiler/mir:Local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aLocal_3e_2eAt_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %t15, i64 %t18)
  store %"compiler/mir:Local" %t21, ptr %l11
  br label %bb4
bb4:
  %t22 = getelementptr %"compiler/mir:Local", ptr %l11, i32 0, i32 4
  %t23 = load { i64, [1 x i64] }, ptr %t22
  store { i64, [1 x i64] } %t23, ptr %l2
  %t25 = load { i64, [1 x i64] }, ptr %l2
  %t27 = extractvalue { i64, [1 x i64] } %t25, 0
  %t28 = icmp eq i64 %t27, 3
  %t30 = xor i1 %t28, true
  br i1 %t30, label %bb5, label %bb6
bb5:
  %t32 = load { i64, [1 x i64] }, ptr %l2
  store { i64, [1 x i64] } %t32, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t34 = load ptr, ptr %l0, !tbaa !29
  store ptr %t34, ptr %l17, !tbaa !29
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/lower:lowering", ptr %t35, i32 0, i32 1
  %t38 = load ptr, ptr %t37, !tbaa !29
  %t40 = getelementptr %"compiler/typed:Body", ptr %t38, i32 0, i32 7
  %t41 = load i32, ptr %l1, !tbaa !23
  %t43 = sext i32 %t41 to i64
  %t46 = call %"compiler/typed:Local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t40, i64 %t43)
  store %"compiler/typed:Local" %t46, ptr %l23
  br label %bb8
bb8:
  %t47 = getelementptr %"compiler/typed:Local", ptr %l23, i32 0, i32 3
  %t48 = load i32, ptr %t47, !tbaa !23
  store { i64, [1 x i64] } zeroinitializer, ptr %t49
  %t50 = getelementptr { i64, [1 x i64] }, ptr %t49, i32 0, i32 0
  store i64 1, ptr %t50
  %t52 = insertvalue { i32 } undef, i32 %t48, 0
  %t53 = getelementptr { i64, [1 x i64] }, ptr %t49, i32 0, i32 1
  store { i32 } %t52, ptr %t53
  %t54 = load { i64, [1 x i64] }, ptr %t49
  %t55 = load ptr, ptr %l17, !tbaa !29
  %t57 = call { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2escopeRef(ptr %v0, ptr %t55, { i64, [1 x i64] } %t54)
  store { i64, [1 x i64] } %t57, ptr %l26
  br label %bb9
bb9:
  %t58 = load { i64, [1 x i64] }, ptr %l26
  store { i64, [1 x i64] } %t58, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [1 x i64] }, ptr %rv
  ret { i64, [1 x i64] } %rr
}

define dso_local i32 @compiler_2flower_2ecompiler_2flower_3alowering_2etemp(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %l7 = alloca i32
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/lower:lowering", ptr %a0, i32 0, i32 3
  %t9 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddTemp(ptr %v0, ptr %t3, i32 %a1, %"compiler/source:Span" %a2)
  store i32 %t9, ptr %l7
  br label %bb1
bb1:
  %t10 = load i32, ptr %l7, !tbaa !23
  store i32 %t10, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2etoClause(ptr %v0, ptr %v1, ptr %a0, %"compiler/lower:tryCtx" %a1, i64 %a2, { i64, [4 x i64] } %a3, i32 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/lower:tryCtx"
  %l2 = alloca i64
  %l5 = alloca ptr
  %l7 = alloca i1
  %l8 = alloca { i64, ptr }
  %l18 = alloca %"compiler/mir:Place"
  %l41 = alloca i32
  %l44 = alloca ptr
  %l45 = alloca i64
  %l48 = alloca i32
  %l49 = alloca ptr
  %l52 = alloca i32
  %s1 = alloca %olang.scope
  %t39 = alloca { i64, [15 x i64] }, align 8
  %t49 = alloca { i64, [21 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/lower:tryCtx" %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/lower:tryCtx", ptr %l1, i32 0, i32 1
  %t2 = load { i64, ptr }, ptr %t1, !tbaa !27
  store { i64, ptr } %t2, ptr %l8, !tbaa !27
  %t3 = load i64, ptr %l2, !tbaa !24
  %t5 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t6 = load ptr, ptr %t5, !tbaa !27
  %t7 = getelementptr ptr, ptr %t6, i64 %t3
  %t8 = load ptr, ptr %t7, !tbaa !39
  store ptr %t8, ptr %l5, !tbaa !29
  %t10 = load ptr, ptr %l5, !tbaa !29
  %t12 = getelementptr %"compiler/typed:Clause", ptr %t10, i32 0, i32 5
  %t13 = load i64, ptr %t12, !tbaa !24
  %t15 = icmp sge i64 %t13, 0
  br i1 %t15, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t17 = load ptr, ptr %l5, !tbaa !29
  %t19 = getelementptr %"compiler/typed:Clause", ptr %t17, i32 0, i32 5
  %t20 = load i64, ptr %t19, !tbaa !24
  %t22 = trunc i64 %t20 to i32
  %t25 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t22)
  store %"compiler/mir:Place" %t25, ptr %l18
  br label %bb3
bb2:
  br label %bb5
bb3:
  %t26 = load %"compiler/mir:Place", ptr %l18
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load ptr, ptr %l5, !tbaa !29
  %t30 = getelementptr %"compiler/typed:Clause", ptr %t28, i32 0, i32 0
  %t31 = load %"compiler/source:Span", ptr %t30
  %t35 = load ptr, ptr %l5, !tbaa !29
  %t37 = getelementptr %"compiler/typed:Clause", ptr %t35, i32 0, i32 6
  %t38 = load i32, ptr %t37, !tbaa !23
  store { i64, [15 x i64] } zeroinitializer, ptr %t39
  %t40 = getelementptr { i64, [15 x i64] }, ptr %t39, i32 0, i32 0
  store i64 11, ptr %t40
  %t42 = insertvalue { { i64, [4 x i64] }, i32, i32 } undef, { i64, [4 x i64] } %a3, 0
  %t44 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t42, i32 %a4, 1
  %t46 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t44, i32 %t38, 2
  %t47 = getelementptr { i64, [15 x i64] }, ptr %t39, i32 0, i32 1
  store { { i64, [4 x i64] }, i32, i32 } %t46, ptr %t47
  %t48 = load { i64, [15 x i64] }, ptr %t39
  store { i64, [21 x i64] } zeroinitializer, ptr %t49
  %t50 = getelementptr { i64, [21 x i64] }, ptr %t49, i32 0, i32 0
  store i64 0, ptr %t50
  %t52 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t31, 0
  %t54 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t52, %"compiler/mir:Place" %t26, 1
  %t56 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t54, { i64, [15 x i64] } %t48, 2
  %t57 = getelementptr { i64, [21 x i64] }, ptr %t49, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t56, ptr %t57
  %t58 = load { i64, [21 x i64] }, ptr %t49
  %t60 = call ptr @__olang_scope_alloc_a(ptr %s1, i64 176, i64 8)
  store { i64, [21 x i64] } %t58, ptr %t60
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s1, ptr %t27, ptr %t60)
  br label %bb4
bb4:
  call void @__olang_scope_close(ptr %s1)
  br label %bb5
bb5:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/lower:lowering", ptr %t63, i32 0, i32 18
  %t66 = load i1, ptr %t65, !tbaa !21
  store i1 %t66, ptr %l7, !tbaa !21
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/lower:lowering", ptr %t68, i32 0, i32 18
  store i1 true, ptr %t70, !tbaa !21
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/lower:tryCtx", ptr %l1, i32 0, i32 0
  %t73 = load i64, ptr %t72, !tbaa !24
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eleave(ptr %v0, ptr %t71, i64 %t73)
  br label %bb6
bb6:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t77 = load i1, ptr %l7, !tbaa !21
  %t80 = getelementptr %"compiler/lower:lowering", ptr %t76, i32 0, i32 18
  store i1 %t77, ptr %t80, !tbaa !21
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"compiler/lower:lowering", ptr %t81, i32 0, i32 7
  %t84 = load i1, ptr %t83, !tbaa !21
  br i1 %t84, label %bb7, label %bb8
bb7:
  br label %ret
bb8:
  br label %bb9
bb9:
  %t86 = getelementptr %"compiler/lower:tryCtx", ptr %l1, i32 0, i32 4
  %t87 = load i64, ptr %l2, !tbaa !24
  %t90 = call i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aBlockId_3e_2eAt_3ccompiler_2fmir_3aBlockId_3e(ptr %v1, ptr %t86, i64 %t87)
  store i32 %t90, ptr %l41
  br label %bb10
bb10:
  %t91 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t92 = load i32, ptr %l41, !tbaa !23
  %t94 = icmp eq i32 %t92, %t91
  br i1 %t94, label %bb11, label %bb12
bb11:
  %t96 = getelementptr %"compiler/lower:tryCtx", ptr %l1, i32 0, i32 4
  store ptr %t96, ptr %l44, !tbaa !29
  %t97 = load i64, ptr %l2, !tbaa !24
  store i64 %t97, ptr %l45, !tbaa !24
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t100 = getelementptr %"compiler/lower:lowering", ptr %t98, i32 0, i32 3
  %t102 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t100)
  store i32 %t102, ptr %l48
  br label %bb13
bb12:
  br label %bb15
bb13:
  %t103 = load ptr, ptr %l44, !tbaa !29
  %t104 = load i64, ptr %l45, !tbaa !24
  %t105 = load i32, ptr %l48, !tbaa !23
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aBlockId_3e_2eSetAt_3ccompiler_2fmir_3aBlockId_3e(ptr %v1, ptr %t103, i64 %t104, i32 %t105)
  br label %bb14
bb14:
  br label %bb15
bb15:
  %t106 = load ptr, ptr %l0, !tbaa !29
  store ptr %t106, ptr %l49, !tbaa !29
  %t107 = getelementptr %"compiler/lower:tryCtx", ptr %l1, i32 0, i32 4
  %t108 = load i64, ptr %l2, !tbaa !24
  %t111 = call i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aBlockId_3e_2eAt_3ccompiler_2fmir_3aBlockId_3e(ptr %v1, ptr %t107, i64 %t108)
  store i32 %t111, ptr %l52
  br label %bb16
bb16:
  %t112 = load ptr, ptr %l49, !tbaa !29
  %t113 = load i32, ptr %l52, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2egoto(ptr %v0, ptr %t112, i32 %t113)
  br label %bb17
bb17:
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2flower_2ecompiler_2flower_3alowering_2eunconvert(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca ptr
  %l5 = alloca i1
  %l14 = alloca i1
  %l18 = alloca i1
  %l19 = alloca ptr
  %l20 = alloca { i64, ptr }
  %l22 = alloca i32
  %l23 = alloca i1
  %l25 = alloca { i64, ptr }
  %l27 = alloca ptr
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 9
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t12, i32 0, i32 2
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t18, i32 0, i32 4
  %t20 = load { i64, ptr }, ptr %t19
  store { i64, ptr } %t20, ptr %l3, !tbaa !27
  br label %bb5
bb4:
  br label %bb18
bb5:
  %t22 = load i32, ptr %l2
  %t24 = trunc i64 20 to i32
  %t25 = icmp eq i32 %t22, %t24
  br i1 %t25, label %bb6, label %bb7
bb6:
  %t27 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t27, 0
  %t31 = icmp eq i64 %t29, 1
  store i1 %t31, ptr %l14, !tbaa !21
  br label %bb8
bb7:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb8
bb8:
  %t33 = load i1, ptr %l14, !tbaa !21
  br i1 %t33, label %bb9, label %bb10
bb9:
  %t34 = load ptr, ptr %l0, !tbaa !29
  store ptr %t34, ptr %l19, !tbaa !29
  %t35 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t35, ptr %l20, !tbaa !27
  %t36 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !27
  %t38 = getelementptr ptr, ptr %t37, i64 0
  %t39 = load ptr, ptr %t38, !tbaa !39
  %t41 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t39)
  store i32 %t41, ptr %l22
  br label %bb11
bb10:
  store i1 false, ptr %l18, !tbaa !21
  br label %bb13
bb11:
  %t42 = load ptr, ptr %l19, !tbaa !29
  %t43 = load i32, ptr %l22, !tbaa !23
  %t44 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2evalueArray(ptr %v0, ptr %t42, i32 %t43)
  store i1 %t44, ptr %l23
  br label %bb12
bb12:
  %t45 = load i1, ptr %l23, !tbaa !21
  store i1 %t45, ptr %l18, !tbaa !21
  br label %bb13
bb13:
  %t46 = load i1, ptr %l18, !tbaa !21
  br i1 %t46, label %bb14, label %bb15
bb14:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t48 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t48, ptr %l25, !tbaa !27
  %t49 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !27
  %t51 = getelementptr ptr, ptr %t50, i64 0
  %t52 = load ptr, ptr %t51, !tbaa !39
  %t55 = call ptr @compiler_2flower_2ecompiler_2flower_3alowering_2eunconvert(ptr %v0, ptr %v1, ptr %t47, ptr %t52)
  store ptr %t55, ptr %l27
  br label %bb16
bb15:
  br label %bb17
bb16:
  %t56 = load ptr, ptr %l27, !tbaa !29
  store ptr %t56, ptr %rv
  br label %ret
bb17:
  br label %bb23
bb18:
  br i1 true, label %bb19, label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb23
bb22:
  call void @__olang_check_failed(ptr @olang_loc_d8cada644e10ccc9_6a931382540e069d)
  unreachable
bb23:
  %t57 = load ptr, ptr %l1, !tbaa !29
  store ptr %t57, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local { i64, ptr } @compiler_2flower_2ecompiler_2flower_3alowering_2evals(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %lp2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l10 = alloca i64
  %l19 = alloca i64
  %l22 = alloca i64
  %l40 = alloca i64
  %l42 = alloca { i64, ptr }
  %l46 = alloca { i64, [4 x i64] }
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  store i64 %t3, ptr %l10, !tbaa !24
  %t4 = load i64, ptr %l10, !tbaa !24
  %t5 = icmp sge i64 %t4, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load i64, ptr %l10, !tbaa !24
  %t8 = icmp sle i64 %t7, 230584300921369395
  br i1 %t8, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_73384406ab4916da_7af5324ba56268d6)
  unreachable
bb3:
  %t10 = load i64, ptr %l10, !tbaa !24
  %t11 = mul i64 %t10, 40
  %t12 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t11)
  %t13 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  %t15 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 16, i64 8)
  store ptr %t15, ptr %lp2
  %t17 = load ptr, ptr %lp2
  store { i64, ptr } %t14, ptr %t17, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t18 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t20 = extractvalue { i64, ptr } %t18, 0
  store i64 %t20, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t22 = load i64, ptr %l4, !tbaa !24
  %t23 = load i64, ptr %l3, !tbaa !24
  %t26 = icmp sgt i64 %t22, %t23
  br i1 %t26, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_73384406ab4916da_7af5324ba56268d6)
  unreachable
bb5:
  %t28 = load i64, ptr %l5, !tbaa !24
  %t30 = icmp sgt i64 %t28, 0
  br i1 %t30, label %bb7, label %bb8
bb6:
  store i64 0, ptr %l19, !tbaa !24
  br label %bb10
bb7:
  %t32 = load i64, ptr %l4, !tbaa !24
  %t33 = load i64, ptr %l3, !tbaa !24
  %t36 = sub i64 %t32, %t33
  %t37 = load i64, ptr %l5, !tbaa !24
  %t40 = add i64 %t36, %t37
  %t42 = sub i64 %t40, 1
  %t43 = load i64, ptr %l5, !tbaa !24
  %t46 = sdiv i64 %t42, %t43
  store i64 %t46, ptr %l22, !tbaa !24
  br label %bb9
bb8:
  store i64 0, ptr %l22, !tbaa !24
  br label %bb9
bb9:
  %t48 = load i64, ptr %l22, !tbaa !24
  store i64 %t48, ptr %l19, !tbaa !24
  br label %bb10
bb10:
  %t49 = load i64, ptr %l19, !tbaa !24
  store i64 %t49, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb11
bb11:
  store %olang.scope zeroinitializer, ptr %s2
  %t50 = load i64, ptr %l7, !tbaa !24
  %t51 = load i64, ptr %l6, !tbaa !24
  %t54 = icmp slt i64 %t50, %t51
  %t56 = xor i1 %t54, true
  br i1 %t56, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s2)
  br label %bb17
bb13:
  br label %bb14
bb14:
  %t58 = load i64, ptr %l3, !tbaa !24
  %t59 = load i64, ptr %l7, !tbaa !24
  %t60 = load i64, ptr %l5, !tbaa !24
  %t63 = mul i64 %t59, %t60
  %t66 = add i64 %t58, %t63
  store i64 %t66, ptr %l8, !tbaa !24
  %t68 = load i64, ptr %l8, !tbaa !24
  store i64 %t68, ptr %l40, !tbaa !24
  %t70 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t70, ptr %l42, !tbaa !27
  %t71 = load i64, ptr %l8, !tbaa !24
  %t73 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t74 = load ptr, ptr %t73, !tbaa !27
  %t75 = getelementptr ptr, ptr %t74, i64 %t71
  %t76 = load ptr, ptr %t75, !tbaa !39
  %t80 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v1, ptr %a0, ptr %t76)
  store { i64, [4 x i64] } %t80, ptr %l46
  br label %bb15
bb15:
  %t81 = load { i64, [4 x i64] }, ptr %l46
  %t82 = load ptr, ptr %lp2
  %t83 = load i64, ptr %l40, !tbaa !24
  %t84 = getelementptr { i64, ptr }, ptr %t82, i32 0, i32 1
  %t85 = load ptr, ptr %t84, !tbaa !27
  %t86 = getelementptr { i64, [4 x i64] }, ptr %t85, i64 %t83
  store { i64, [4 x i64] } %t81, ptr %t86
  call void @__olang_scope_close(ptr %s2)
  br label %bb16
bb16:
  %t87 = load i64, ptr %l7, !tbaa !24
  %t89 = add i64 %t87, 1
  store i64 %t89, ptr %l7, !tbaa !24
  br label %bb11
bb17:
  %t91 = load ptr, ptr %lp2
  %t92 = load { i64, ptr }, ptr %t91, !tbaa !27
  store { i64, ptr } %t92, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3alowering_2evalueArray(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca i32
  %l8 = alloca i32
  %l11 = alloca i32
  %l14 = alloca i1
  %l17 = alloca i32
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/lower:lowering", ptr %a0, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t6, i32 %a1)
  store i32 %t10, ptr %l8
  br label %bb1
bb1:
  %t11 = load i32, ptr %l8, !tbaa !23
  store i32 %t11, ptr %l3, !tbaa !23
  %t12 = load ptr, ptr %l2, !tbaa !29
  %t13 = load i32, ptr %l3, !tbaa !23
  %t16 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t12, i32 %t13)
  store i32 %t16, ptr %l11
  br label %bb2
bb2:
  %t17 = load i32, ptr %l11
  %t19 = trunc i64 19 to i32
  %t20 = icmp eq i32 %t17, %t19
  br i1 %t20, label %bb3, label %bb4
bb3:
  %t22 = load ptr, ptr %l2, !tbaa !29
  %t23 = load i32, ptr %l3, !tbaa !23
  %t26 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t22, i32 %t23)
  store i32 %t26, ptr %l17
  br label %bb5
bb4:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb6
bb5:
  %t27 = load i32, ptr %l17, !tbaa !23
  %t28 = icmp eq i32 %t27, 0
  store i1 %t28, ptr %l14, !tbaa !21
  br label %bb6
bb6:
  %t30 = load i1, ptr %l14, !tbaa !21
  store i1 %t30, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2ewith(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/lower:pl" %a1, { i64, [1 x i64] } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/lower:pl"
  %lp3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l11 = alloca %"compiler/lower:pl"
  %l13 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l17 = alloca i32
  %l26 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca %"compiler/lower:pl"
  store ptr %a0, ptr %l0
  store %"compiler/lower:pl" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/lower:pl", ptr %l1, i32 0, i32 0
  %t2 = load { i64, [2 x i64] }, ptr %t1
  %t4 = call %"compiler/lower:pl" @compiler_2flower_3apl_2ector(ptr %v2, { i64, [2 x i64] } %t2)
  store %"compiler/lower:pl" %t4, ptr %l11
  br label %bb1
bb1:
  %t5 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 32, i64 8)
  store ptr %t5, ptr %lp3
  %t6 = load %"compiler/lower:pl", ptr %l11
  %t7 = load ptr, ptr %lp3
  store %"compiler/lower:pl" %t6, ptr %t7
  %t8 = getelementptr %"compiler/lower:pl", ptr %l1, i32 0, i32 1
  store ptr %t8, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t10 = load ptr, ptr %l4, !tbaa !29
  %t11 = load i64, ptr %l5, !tbaa !24
  %t14 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aProj_3e_2eRunFrom_3ccompiler_2fmir_3aProj_3e(ptr %v1, ptr %t10, i64 %t11)
  %t15 = extractvalue { i32, { i64, ptr } } %t14, 1
  %t16 = extractvalue { i32, { i64, ptr } } %t14, 0
  store i32 %t16, ptr %l17
  %t17 = icmp ne i32 %t16, 0
  br i1 %t17, label %bb4, label %ok.18
ok.18:
  store { i64, ptr } %t15, ptr %l16
  br label %bb3
bb3:
  %t19 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t19, ptr %l13, !tbaa !27
  br label %bb8
bb4:
  %t20 = load i32, ptr %l17, !tbaa !23
  %t21 = ashr i32 %t20, 16
  %t23 = icmp eq i32 %t21, 1
  br i1 %t23, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  call void @__olang_check_failed(ptr @olang_loc_e4cb0830a37b0e81_73b8c395fe92f955)
  unreachable
bb7:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s2)
  br label %bb17
bb8:
  %t25 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t25, ptr %l6, !tbaa !27
  %t26 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t28 = extractvalue { i64, ptr } %t26, 0
  store i64 %t28, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s3
  %t30 = load i64, ptr %l8, !tbaa !24
  %t31 = load i64, ptr %l7, !tbaa !24
  %t34 = icmp slt i64 %t30, %t31
  %t36 = xor i1 %t34, true
  br i1 %t36, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s3)
  br label %bb15
bb11:
  br label %bb12
bb12:
  %t38 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t38, ptr %l26, !tbaa !27
  %t39 = load i64, ptr %l8, !tbaa !24
  %t41 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !27
  %t43 = getelementptr { i64, [1 x i64] }, ptr %t42, i64 %t39
  %t44 = load { i64, [1 x i64] }, ptr %t43
  %t46 = load ptr, ptr %lp3
  %t47 = getelementptr %"compiler/lower:pl", ptr %t46, i32 0, i32 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aProj_3e_2ePush_3ccompiler_2fmir_3aProj_3e(ptr %v2, ptr %t47, { i64, [1 x i64] } %t44)
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s3)
  br label %bb14
bb14:
  %t51 = load i64, ptr %l8, !tbaa !24
  %t53 = add i64 %t51, 1
  store i64 %t53, ptr %l8, !tbaa !24
  br label %bb9
bb15:
  %t55 = load i64, ptr %l5, !tbaa !24
  %t56 = load i64, ptr %l7, !tbaa !24
  %t59 = add i64 %t55, %t56
  store i64 %t59, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb16
bb16:
  br label %bb2
bb17:
  %t61 = load ptr, ptr %lp3
  %t62 = getelementptr %"compiler/lower:pl", ptr %t61, i32 0, i32 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aProj_3e_2ePush_3ccompiler_2fmir_3aProj_3e(ptr %v2, ptr %t62, { i64, [1 x i64] } %a2)
  br label %bb18
bb18:
  %t66 = load ptr, ptr %lp3
  %t67 = load %"compiler/lower:pl", ptr %t66
  store %"compiler/lower:pl" %t67, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/lower:pl", ptr %rv
  ret %"compiler/lower:pl" %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2eword(ptr %v0, ptr %v1, ptr %a0, { i64, [1 x i64] } %a1, { i64, ptr } %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l12 = alloca i32
  %l15 = alloca i64
  %l23 = alloca i64
  %l26 = alloca i64
  %l45 = alloca { i64, ptr }
  %l53 = alloca i32
  %l55 = alloca ptr
  %l59 = alloca i32
  %l61 = alloca i32
  %l67 = alloca i32
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %t110 = alloca { i64, [2 x i64] }, align 8
  %t132 = alloca { i64, [4 x i64] }, align 8
  %t144 = alloca { i64, [21 x i64] }, align 8
  store ptr %a0, ptr %l0
  store { i64, ptr } %a2, ptr %l2
  store %"compiler/source:Span" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  store i64 %t3, ptr %l15, !tbaa !24
  %t4 = load i64, ptr %l15, !tbaa !24
  %t5 = icmp sge i64 %t4, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load i64, ptr %l15, !tbaa !24
  %t8 = mul i64 %t7, 1
  %t9 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t13 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  store i64 %t15, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t17 = load i64, ptr %l6, !tbaa !24
  %t18 = load i64, ptr %l5, !tbaa !24
  %t21 = icmp sgt i64 %t17, %t18
  br i1 %t21, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_683e5e170631bc0e_4d1425fdf2d9aa22)
  unreachable
bb3:
  %t23 = load i64, ptr %l7, !tbaa !24
  %t25 = icmp sgt i64 %t23, 0
  br i1 %t25, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l23, !tbaa !24
  br label %bb8
bb5:
  %t27 = load i64, ptr %l6, !tbaa !24
  %t28 = load i64, ptr %l5, !tbaa !24
  %t31 = sub i64 %t27, %t28
  %t32 = load i64, ptr %l7, !tbaa !24
  %t35 = add i64 %t31, %t32
  %t37 = sub i64 %t35, 1
  %t38 = load i64, ptr %l7, !tbaa !24
  %t41 = sdiv i64 %t37, %t38
  store i64 %t41, ptr %l26, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l26, !tbaa !24
  br label %bb7
bb7:
  %t43 = load i64, ptr %l26, !tbaa !24
  store i64 %t43, ptr %l23, !tbaa !24
  br label %bb8
bb8:
  %t44 = load i64, ptr %l23, !tbaa !24
  store i64 %t44, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t45 = load i64, ptr %l9, !tbaa !24
  %t46 = load i64, ptr %l8, !tbaa !24
  %t49 = icmp slt i64 %t45, %t46
  %t51 = xor i1 %t49, true
  br i1 %t51, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb14
bb11:
  br label %bb12
bb12:
  %t53 = load i64, ptr %l5, !tbaa !24
  %t54 = load i64, ptr %l9, !tbaa !24
  %t55 = load i64, ptr %l7, !tbaa !24
  %t58 = mul i64 %t54, %t55
  %t61 = add i64 %t53, %t58
  store i64 %t61, ptr %l10, !tbaa !24
  %t63 = load i64, ptr %l10, !tbaa !24
  %t64 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t64, ptr %l45, !tbaa !27
  %t65 = load i64, ptr %l10, !tbaa !24
  %t67 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t68 = load ptr, ptr %t67, !tbaa !27
  %t69 = getelementptr i8, ptr %t68, i64 %t65
  %t70 = load i8, ptr %t69, !tbaa !32
  %t74 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t75 = load ptr, ptr %t74, !tbaa !27
  %t76 = getelementptr i8, ptr %t75, i64 %t63
  store i8 %t70, ptr %t76, !tbaa !32
  call void @__olang_scope_close(ptr %s2)
  br label %bb13
bb13:
  %t77 = load i64, ptr %l9, !tbaa !24
  %t79 = add i64 %t77, 1
  store i64 %t79, ptr %l9, !tbaa !24
  br label %bb9
bb14:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"compiler/lower:lowering", ptr %t81, i32 0, i32 2
  %t84 = load ptr, ptr %t83, !tbaa !29
  %t86 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s0, ptr %t84, { i64, ptr } { i64 2, ptr @.d41 })
  store i32 %t86, ptr %l53
  br label %bb15
bb15:
  %t87 = load i32, ptr %l53, !tbaa !23
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t90 = getelementptr %"compiler/lower:lowering", ptr %t88, i32 0, i32 2
  %t91 = load ptr, ptr %t90, !tbaa !29
  store ptr %t91, ptr %l55, !tbaa !29
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"compiler/lower:lowering", ptr %t92, i32 0, i32 2
  %t95 = load ptr, ptr %t94, !tbaa !29
  %t99 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArray(ptr %v0, ptr %t95, i32 %t87, i32 0)
  store i32 %t99, ptr %l59
  br label %bb16
bb16:
  %t100 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t101 = load ptr, ptr %l55, !tbaa !29
  %t102 = load i32, ptr %l59, !tbaa !23
  %t104 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t101, i32 %t102, i64 %t100)
  store i32 %t104, ptr %l61
  br label %bb17
bb17:
  %t105 = load i32, ptr %l61, !tbaa !23
  store i32 %t105, ptr %l12, !tbaa !23
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t108 = getelementptr %"compiler/lower:lowering", ptr %t106, i32 0, i32 3
  %t109 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, [2 x i64] } zeroinitializer, ptr %t110
  %t111 = getelementptr { i64, [2 x i64] }, ptr %t110, i32 0, i32 0
  store i64 1, ptr %t111
  %t113 = insertvalue { { i64, ptr } } undef, { i64, ptr } %t109, 0
  %t114 = getelementptr { i64, [2 x i64] }, ptr %t110, i32 0, i32 1
  store { { i64, ptr } } %t113, ptr %t114
  %t115 = load { i64, [2 x i64] }, ptr %t110
  %t117 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 24, i64 8)
  store { i64, [2 x i64] } %t115, ptr %t117
  %t120 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddConst(ptr %v0, ptr %s0, ptr %t108, ptr %t117)
  store i32 %t120, ptr %l67
  br label %bb18
bb18:
  %t121 = load i32, ptr %l67, !tbaa !23
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t123 = load %"compiler/source:Span", ptr %l3
  %t125 = load i32, ptr %l12, !tbaa !23
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t129 = getelementptr %"compiler/lower:lowering", ptr %t127, i32 0, i32 4
  %t130 = load i64, ptr %t129, !tbaa !24
  %t131 = load %"compiler/source:Span", ptr %l3
  store { i64, [4 x i64] } zeroinitializer, ptr %t132
  %t133 = getelementptr { i64, [4 x i64] }, ptr %t132, i32 0, i32 0
  store i64 3, ptr %t133
  %t135 = insertvalue { i32, i32, i64, %"compiler/source:Span" } undef, i32 %t125, 0
  %t137 = insertvalue { i32, i32, i64, %"compiler/source:Span" } %t135, i32 %t121, 1
  %t139 = insertvalue { i32, i32, i64, %"compiler/source:Span" } %t137, i64 %t130, 2
  %t141 = insertvalue { i32, i32, i64, %"compiler/source:Span" } %t139, %"compiler/source:Span" %t131, 3
  %t142 = getelementptr { i64, [4 x i64] }, ptr %t132, i32 0, i32 1
  store { i32, i32, i64, %"compiler/source:Span" } %t141, ptr %t142
  %t143 = load { i64, [4 x i64] }, ptr %t132
  store { i64, [21 x i64] } zeroinitializer, ptr %t144
  %t145 = getelementptr { i64, [21 x i64] }, ptr %t144, i32 0, i32 0
  store i64 9, ptr %t145
  %t147 = insertvalue { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } undef, %"compiler/source:Span" %t123, 0
  %t149 = insertvalue { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } %t147, { i64, [1 x i64] } %a1, 1
  %t151 = insertvalue { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } %t149, i32 0, 2
  %t153 = insertvalue { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } %t151, { i64, [4 x i64] } %t143, 3
  %t154 = getelementptr { i64, [21 x i64] }, ptr %t144, i32 0, i32 1
  store { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } %t153, ptr %t154
  %t155 = load { i64, [21 x i64] }, ptr %t144
  %t157 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t155, ptr %t157
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s0, ptr %t122, ptr %t157)
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ezero(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca { i64, [7 x i64] }
  %l6 = alloca i32
  %l7 = alloca i32
  %l15 = alloca i32
  %l19 = alloca i32
  %l32 = alloca i32
  %l36 = alloca i32
  %l38 = alloca ptr
  %l39 = alloca { i64, [7 x i64] }
  %l40 = alloca %"compiler/mir:Range"
  %l41 = alloca ptr
  %l45 = alloca i64
  %l46 = alloca %"compiler/mir:Range"
  %l48 = alloca %"compiler/mir:Place"
  %l52 = alloca %"compiler/mir:Call"
  %l53 = alloca i32
  %l61 = alloca %"compiler/mir:Place"
  %s0 = alloca %olang.scope
  %rv = alloca { i64, [4 x i64] }
  %t24 = alloca { i64, [2 x i64] }, align 8
  %t33 = alloca { i64, [7 x i64] }, align 8
  %t47 = alloca { i64, [2 x i64] }, align 8
  %t108 = alloca { i64, [7 x i64] }, align 8
  %t125 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/lower:lowering", ptr %t6, i32 0, i32 0
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t10 = load i32, ptr %l1, !tbaa !23
  %t14 = call i32 @compiler_2flower_2ecompiler_2flower_3aLowerer_2ehelperTy(ptr %v0, ptr %t9, i32 3, i32 %t10)
  store i32 %t14, ptr %l15
  br label %bb1
bb1:
  %t15 = load i32, ptr %l15, !tbaa !23
  store i32 %t15, ptr %l1, !tbaa !23
  %t16 = load ptr, ptr %l3, !tbaa !29
  %t17 = load i32, ptr %l1, !tbaa !23
  %t21 = call i32 @compiler_2fmir_2eHelperType(ptr %v0, ptr %t16, i32 3, i32 %t17)
  store i32 %t21, ptr %l19
  br label %bb2
bb2:
  %t22 = load i32, ptr %l19, !tbaa !23
  store i32 %t22, ptr %l4, !tbaa !23
  %t23 = load i32, ptr %l1, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t24
  %t25 = getelementptr { i64, [2 x i64] }, ptr %t24, i32 0, i32 0
  store i64 2, ptr %t25
  %t27 = insertvalue { i32, i32 } undef, i32 3, 0
  %t29 = insertvalue { i32, i32 } %t27, i32 %t23, 1
  %t30 = getelementptr { i64, [2 x i64] }, ptr %t24, i32 0, i32 1
  store { i32, i32 } %t29, ptr %t30
  %t31 = load { i64, [2 x i64] }, ptr %t24
  %t32 = load i32, ptr %l4, !tbaa !23
  store { i64, [7 x i64] } zeroinitializer, ptr %t33
  %t34 = getelementptr { i64, [7 x i64] }, ptr %t33, i32 0, i32 0
  store i64 0, ptr %t34
  %t36 = insertvalue { { i64, [2 x i64] }, i32 } undef, { i64, [2 x i64] } %t31, 0
  %t38 = insertvalue { { i64, [2 x i64] }, i32 } %t36, i32 %t32, 1
  %t39 = getelementptr { i64, [7 x i64] }, ptr %t33, i32 0, i32 1
  store { { i64, [2 x i64] }, i32 } %t38, ptr %t39
  %t40 = load { i64, [7 x i64] }, ptr %t33
  store { i64, [7 x i64] } %t40, ptr %l5
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/lower:lowering", ptr %t42, i32 0, i32 0
  %t45 = load ptr, ptr %t44, !tbaa !29
  %t46 = load i32, ptr %l1, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t47
  %t48 = getelementptr { i64, [2 x i64] }, ptr %t47, i32 0, i32 0
  store i64 2, ptr %t48
  %t50 = insertvalue { i32, i32 } undef, i32 3, 0
  %t52 = insertvalue { i32, i32 } %t50, i32 %t46, 1
  %t53 = getelementptr { i64, [2 x i64] }, ptr %t47, i32 0, i32 1
  store { i32, i32 } %t52, ptr %t53
  %t54 = load { i64, [2 x i64] }, ptr %t47
  call void @compiler_2flower_2ecompiler_2flower_3aLowerer_2eWant(ptr %v0, ptr %t45, { i64, [2 x i64] } %t54)
  br label %bb3
bb3:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/lower:lowering", ptr %t57, i32 0, i32 3
  %t61 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t59)
  store i32 %t61, ptr %l32
  br label %bb4
bb4:
  %t62 = load i32, ptr %l32, !tbaa !23
  store i32 %t62, ptr %l6, !tbaa !23
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t64 = load i32, ptr %l1, !tbaa !23
  %t65 = load %"compiler/source:Span", ptr %l2
  %t69 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2etemp(ptr %v0, ptr %t63, i32 %t64, %"compiler/source:Span" %t65)
  store i32 %t69, ptr %l36
  br label %bb5
bb5:
  %t70 = load i32, ptr %l36, !tbaa !23
  store i32 %t70, ptr %l7, !tbaa !23
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/lower:lowering", ptr %t71, i32 0, i32 3
  store ptr %t73, ptr %l38, !tbaa !29
  %t74 = load { i64, [7 x i64] }, ptr %l5
  store { i64, [7 x i64] } %t74, ptr %l39
  %t75 = load %"compiler/mir:Range", ptr @G_2ecompiler_2fmir_2eEmpty
  store %"compiler/mir:Range" %t75, ptr %l40
  %t76 = load ptr, ptr %l0, !tbaa !29
  store ptr %t76, ptr %l41, !tbaa !29
  %t77 = load ptr, ptr %l3, !tbaa !29
  %t78 = load { i64, [7 x i64] }, ptr %l5
  %t79 = load i32, ptr %l4, !tbaa !23
  %t83 = call i64 @compiler_2fmir_2ePassedCount(ptr %v0, ptr %t77, { i64, [7 x i64] } %t78, i32 %t79)
  store i64 %t83, ptr %l45
  br label %bb6
bb6:
  %t84 = load ptr, ptr %l41, !tbaa !29
  %t85 = load i64, ptr %l45, !tbaa !24
  %t86 = call %"compiler/mir:Range" @compiler_2flower_2ecompiler_2flower_3alowering_2epassed(ptr %v0, ptr %t84, i64 %t85, i32 -1)
  store %"compiler/mir:Range" %t86, ptr %l46
  br label %bb7
bb7:
  %t87 = load i32, ptr %l7, !tbaa !23
  %t89 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t87)
  store %"compiler/mir:Place" %t89, ptr %l48
  br label %bb8
bb8:
  %t90 = load i32, ptr %l6, !tbaa !23
  %t91 = load i32, ptr @G_2ecompiler_2fmir_2eNoLocal, !tbaa !23
  %t92 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t93 = load { i64, [7 x i64] }, ptr %l39
  %t94 = load %"compiler/mir:Range", ptr %l40
  %t95 = load %"compiler/mir:Range", ptr %l46
  %t96 = load %"compiler/mir:Place", ptr %l48
  %t100 = call %"compiler/mir:Call" @compiler_2fmir_3aCall_2ector(ptr %s0, { i64, [7 x i64] } %t93, %"compiler/mir:Range" %t94, %"compiler/mir:Range" %t95, %"compiler/mir:Place" %t96, i1 true, i32 %t90, i32 %t91, i32 %t92)
  store %"compiler/mir:Call" %t100, ptr %l52
  br label %bb9
bb9:
  %t101 = load ptr, ptr %l38, !tbaa !29
  %t102 = load %"compiler/mir:Call", ptr %l52
  %t103 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddCall(ptr %v0, ptr %t101, %"compiler/mir:Call" %t102)
  store i32 %t103, ptr %l53
  br label %bb10
bb10:
  %t104 = load i32, ptr %l53, !tbaa !23
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t106 = load %"compiler/source:Span", ptr %l2
  store { i64, [7 x i64] } zeroinitializer, ptr %t108
  %t109 = getelementptr { i64, [7 x i64] }, ptr %t108, i32 0, i32 0
  store i64 4, ptr %t109
  %t111 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t106, 0
  %t113 = insertvalue { %"compiler/source:Span", i32 } %t111, i32 %t104, 1
  %t114 = getelementptr { i64, [7 x i64] }, ptr %t108, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t113, ptr %t114
  %t115 = load { i64, [7 x i64] }, ptr %t108
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t105, { i64, [7 x i64] } %t115)
  br label %bb11
bb11:
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t119 = load i32, ptr %l6, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t118, i32 %t119)
  br label %bb12
bb12:
  %t122 = load i32, ptr %l7, !tbaa !23
  %t124 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t122)
  store %"compiler/mir:Place" %t124, ptr %l61
  br label %bb13
bb13:
  store { i64, [4 x i64] } zeroinitializer, ptr %t125
  %t126 = getelementptr { i64, [4 x i64] }, ptr %t125, i32 0, i32 0
  store i64 1, ptr %t126
  %t127 = load %"compiler/mir:Place", ptr %l61
  %t128 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t127, 0
  %t129 = getelementptr { i64, [4 x i64] }, ptr %t125, i32 0, i32 1
  store { %"compiler/mir:Place" } %t128, ptr %t129
  %t130 = load { i64, [4 x i64] }, ptr %t125
  call void @__olang_scope_close(ptr %s0)
  store { i64, [4 x i64] } %t130, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local ptr @compiler_2flower_2ederefOf(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i1
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca i1
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb17
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  store ptr %t16, ptr %l11, !tbaa !29
  store i1 false, ptr %l12, !tbaa !21
  %t17 = load ptr, ptr %l11, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb6, label %bb7
bb6:
  %t20 = load ptr, ptr %l11, !tbaa !29
  %t21 = load i64, ptr %t20
  %t23 = icmp eq i64 %t21, 2
  store i1 %t23, ptr %l12, !tbaa !21
  br label %bb7
bb7:
  %t24 = load i1, ptr %l12, !tbaa !21
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr { i64, [4 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t27, i32 0, i32 2
  %t29 = load ptr, ptr %t28
  store ptr %t29, ptr %l2, !tbaa !29
  br label %bb10
bb9:
  br label %bb11
bb10:
  %t31 = load ptr, ptr %l2, !tbaa !29
  store ptr %t31, ptr %l10, !tbaa !29
  br label %bb16
bb11:
  br i1 true, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  store ptr null, ptr %l10, !tbaa !29
  br label %bb16
bb15:
  call void @__olang_check_failed(ptr @olang_loc_eebb62a013643219_b45f662b48cacfad)
  unreachable
bb16:
  %t34 = load ptr, ptr %l10, !tbaa !29
  store ptr %t34, ptr %l3, !tbaa !29
  br label %bb22
bb17:
  br i1 true, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb21
bb20:
  store ptr null, ptr %l3, !tbaa !29
  br label %bb22
bb21:
  call void @__olang_check_failed(ptr @olang_loc_18ba96ebd2acdd48_1f3e7581818ceffc)
  unreachable
bb22:
  %t35 = load ptr, ptr %l3, !tbaa !29
  store ptr %t35, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i64 @compiler_2flower_2eindexOf(ptr %v0, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %a0, i32 %a1) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l9 = alloca i64
  %l13 = alloca i64
  %l16 = alloca i64
  %l36 = alloca i32
  %s2 = alloca %olang.scope
  %rv = alloca i64
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l2, !tbaa !24
  %t2 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %l0)
  store i64 %t2, ptr %l9
  br label %bb1
bb1:
  %t3 = load i64, ptr %l9, !tbaa !24
  store i64 %t3, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t4 = load i64, ptr %l3, !tbaa !24
  %t5 = load i64, ptr %l2, !tbaa !24
  %t8 = icmp sgt i64 %t4, %t5
  br i1 %t8, label %bb2, label %bb3
bb2:
  %t10 = load i64, ptr %l4, !tbaa !24
  %t12 = icmp sgt i64 %t10, 0
  br i1 %t12, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l13, !tbaa !24
  br label %bb7
bb4:
  %t14 = load i64, ptr %l3, !tbaa !24
  %t15 = load i64, ptr %l2, !tbaa !24
  %t18 = sub i64 %t14, %t15
  %t19 = load i64, ptr %l4, !tbaa !24
  %t22 = add i64 %t18, %t19
  %t24 = sub i64 %t22, 1
  %t25 = load i64, ptr %l4, !tbaa !24
  %t28 = sdiv i64 %t24, %t25
  store i64 %t28, ptr %l16, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l16, !tbaa !24
  br label %bb6
bb6:
  %t30 = load i64, ptr %l16, !tbaa !24
  store i64 %t30, ptr %l13, !tbaa !24
  br label %bb7
bb7:
  %t31 = load i64, ptr %l13, !tbaa !24
  store i64 %t31, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t32 = load i64, ptr %l6, !tbaa !24
  %t33 = load i64, ptr %l5, !tbaa !24
  %t36 = icmp slt i64 %t32, %t33
  %t38 = xor i1 %t36, true
  br i1 %t38, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb17
bb10:
  br label %bb11
bb11:
  %t40 = load i64, ptr %l2, !tbaa !24
  %t41 = load i64, ptr %l6, !tbaa !24
  %t42 = load i64, ptr %l4, !tbaa !24
  %t45 = mul i64 %t41, %t42
  %t48 = add i64 %t40, %t45
  store i64 %t48, ptr %l7, !tbaa !24
  %t50 = load i64, ptr %l7, !tbaa !24
  %t53 = call i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %l0, i64 %t50)
  store i32 %t53, ptr %l36
  br label %bb12
bb12:
  %t55 = load i32, ptr %l36, !tbaa !23
  %t57 = icmp eq i32 %t55, %a1
  br i1 %t57, label %bb13, label %bb14
bb13:
  %t59 = load i64, ptr %l7, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  store i64 %t59, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s2)
  br label %bb16
bb16:
  %t61 = load i64, ptr %l6, !tbaa !24
  %t63 = add i64 %t61, 1
  store i64 %t63, ptr %l6, !tbaa !24
  br label %bb8
bb17:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2flower_2estandIn(ptr %out, ptr %v0, i32 %a0) #0 {
entry:
  %l1 = alloca { i64, [2 x i64] }
  %l2 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca %"compiler/typed:Body"
  %s0 = alloca %olang.scope
  %t1 = alloca { i64, [2 x i64] }, align 8
  %t8 = alloca %"compiler/typed:Body", align 8
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store { i64, [2 x i64] } zeroinitializer, ptr %t1
  %t2 = getelementptr { i64, [2 x i64] }, ptr %t1, i32 0, i32 0
  store i64 5, ptr %t2
  %t3 = insertvalue { i64 } undef, i64 -1, 0
  %t4 = getelementptr { i64, [2 x i64] }, ptr %t1, i32 0, i32 1
  store { i64 } %t3, ptr %t4
  %t5 = load { i64, [2 x i64] }, ptr %t1
  store { i64, [2 x i64] } %t5, ptr %l1
  store i32 %a0, ptr %l2, !tbaa !23
  %t7 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 0, i32 0)
  store %"compiler/source:Span" %t7, ptr %l3
  br label %bb1
bb1:
  %t9 = load { i64, [2 x i64] }, ptr %l1
  %t10 = load i32, ptr %l2, !tbaa !23
  %t11 = load %"compiler/source:Span", ptr %l3
  call void @compiler_2ftyped_3aBody_2ector(ptr %t8, ptr %v0, i32 -1, { i64, [2 x i64] } %t9, i32 %t10, i64 0, %"compiler/source:Span" %t11)
  call void @llvm.memmove.p0.p0.i64(ptr %l4, ptr %t8, i64 136, i1 false)
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l4, i64 136, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/lower:Gap" @compiler_2flower_3aGap_2ector(ptr %v0, ptr %v1, i64 %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2) #0 {
entry:
  %rv = alloca %"compiler/lower:Gap"
  br label %start
start:
  br label %bb0
bb0:
  %t8 = insertvalue %"compiler/lower:Gap" undef, i64 %a0, 0
  %t10 = insertvalue %"compiler/lower:Gap" %t8, %"compiler/source:Span" %a1, 1
  %t12 = insertvalue %"compiler/lower:Gap" %t10, { i64, ptr } %a2, 2
  store %"compiler/lower:Gap" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/lower:Gap", ptr %rv
  ret %"compiler/lower:Gap" %rr
}

define dso_local %"compiler/lower:Lowerer" @compiler_2flower_3aLowerer_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l4 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l5 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l6 = alloca i1
  %l7 = alloca i1
  %l8 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l9 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l10 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l11 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l12 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l13 = alloca i1
  %l14 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l20 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l21 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l22 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l23 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l24 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l25 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l26 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l27 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l28 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"compiler/lower:Lowerer"
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a0, ptr %l2, !tbaa !29
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %a1, ptr %l3
  %t5 = load ptr, ptr @__olang_prog_scope
  %t6 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlan_3e(ptr %t5)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t6, ptr %l20
  br label %bb1
bb1:
  %t7 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l20
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t7, ptr %l4
  %t8 = load ptr, ptr @__olang_prog_scope
  %t9 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3aGap_3e(ptr %t8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t9, ptr %l21
  br label %bb2
bb2:
  %t10 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l21
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t10, ptr %l5
  store i1 false, ptr %l6, !tbaa !21
  store i1 false, ptr %l7, !tbaa !21
  %t11 = load ptr, ptr @__olang_prog_scope
  %t12 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e(ptr %t11)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t12, ptr %l22
  br label %bb3
bb3:
  %t13 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l22
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t13, ptr %l8
  %t14 = load ptr, ptr @__olang_prog_scope
  %t15 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aFnKey_3e(ptr %t14)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t15, ptr %l23
  br label %bb4
bb4:
  %t16 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l23
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t16, ptr %l9
  %t17 = load ptr, ptr @__olang_prog_scope
  %t18 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20Bool_3e(ptr %t17)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t18, ptr %l24
  br label %bb5
bb5:
  %t19 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l24
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t19, ptr %l10
  %t20 = load ptr, ptr @__olang_prog_scope
  %t21 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e(ptr %t20)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t21, ptr %l25
  br label %bb6
bb6:
  %t22 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l25
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t22, ptr %l11
  %t23 = load ptr, ptr @__olang_prog_scope
  %t24 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e(ptr %t23)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t24, ptr %l26
  br label %bb7
bb7:
  %t25 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l26
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t25, ptr %l12
  store i1 false, ptr %l13, !tbaa !21
  %t26 = load ptr, ptr @__olang_prog_scope
  %t27 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e(ptr %t26)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t27, ptr %l27
  br label %bb8
bb8:
  %t28 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l27
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t28, ptr %l14
  %t29 = load ptr, ptr @__olang_prog_scope
  %t30 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t29)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t30, ptr %l28
  br label %bb9
bb9:
  %t31 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l28
  %t32 = load ptr, ptr %l2, !tbaa !29
  %t33 = insertvalue %"compiler/lower:Lowerer" undef, ptr %t32, 0
  %t34 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l3
  %t35 = insertvalue %"compiler/lower:Lowerer" %t33, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t34, 1
  %t36 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l4
  %t37 = insertvalue %"compiler/lower:Lowerer" %t35, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t36, 2
  %t38 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l5
  %t39 = insertvalue %"compiler/lower:Lowerer" %t37, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t38, 3
  %t40 = load i1, ptr %l6, !tbaa !21
  %t41 = insertvalue %"compiler/lower:Lowerer" %t39, i1 %t40, 4
  %t42 = load i1, ptr %l7, !tbaa !21
  %t43 = insertvalue %"compiler/lower:Lowerer" %t41, i1 %t42, 5
  %t44 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l8
  %t45 = insertvalue %"compiler/lower:Lowerer" %t43, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t44, 6
  %t46 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l9
  %t47 = insertvalue %"compiler/lower:Lowerer" %t45, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t46, 7
  %t48 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l10
  %t49 = insertvalue %"compiler/lower:Lowerer" %t47, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t48, 8
  %t50 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l11
  %t51 = insertvalue %"compiler/lower:Lowerer" %t49, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t50, 9
  %t52 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l12
  %t53 = insertvalue %"compiler/lower:Lowerer" %t51, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t52, 10
  %t54 = load i1, ptr %l13, !tbaa !21
  %t55 = insertvalue %"compiler/lower:Lowerer" %t53, i1 %t54, 11
  %t56 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l14
  %t57 = insertvalue %"compiler/lower:Lowerer" %t55, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t56, 12
  %t59 = insertvalue %"compiler/lower:Lowerer" %t57, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t31, 13
  %t61 = insertvalue %"compiler/lower:Lowerer" %t59, i32 -1, 14
  %t63 = insertvalue %"compiler/lower:Lowerer" %t61, i32 -1, 15
  store %"compiler/lower:Lowerer" %t63, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/lower:Lowerer", ptr %rv
  ret %"compiler/lower:Lowerer" %rr
}

define dso_local %"compiler/lower:level" @compiler_2flower_3alevel_2ector(ptr %v0, i32 %a0, i32 %a1, i32 %a2) #0 {
entry:
  %rv = alloca %"compiler/lower:level"
  br label %start
start:
  br label %bb0
bb0:
  %t8 = insertvalue %"compiler/lower:level" undef, i32 %a0, 0
  %t10 = insertvalue %"compiler/lower:level" %t8, i32 %a1, 1
  %t12 = insertvalue %"compiler/lower:level" %t10, i32 %a2, 2
  store %"compiler/lower:level" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/lower:level", ptr %rv
  ret %"compiler/lower:level" %rr
}

define dso_local %"compiler/lower:pl" @compiler_2flower_3apl_2ector(ptr %v0, { i64, [2 x i64] } %a0) #0 {
entry:
  %l1 = alloca { i64, [2 x i64] }
  %l4 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"compiler/lower:pl"
  br label %start
start:
  br label %bb0
bb0:
  store { i64, [2 x i64] } %a0, ptr %l1
  %t3 = load ptr, ptr @__olang_prog_scope
  %t4 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aProj_3e(ptr %t3)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t4, ptr %l4
  br label %bb1
bb1:
  %t5 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l4
  %t6 = load { i64, [2 x i64] }, ptr %l1
  %t7 = insertvalue %"compiler/lower:pl" undef, { i64, [2 x i64] } %t6, 0
  %t9 = insertvalue %"compiler/lower:pl" %t7, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t5, 1
  store %"compiler/lower:pl" %t9, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/lower:pl", ptr %rv
  ret %"compiler/lower:pl" %rr
}

define dso_local %"compiler/lower:tryCtx" @compiler_2flower_3atryCtx_2ector(ptr %v0, ptr %v1, i64 %a0, { i64, ptr } %a1, i1 %a2, i1 %a3) #0 {
entry:
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca i1
  %l7 = alloca i1
  %l13 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"compiler/lower:tryCtx"
  br label %start
start:
  br label %bb0
bb0:
  store i64 %a0, ptr %l4, !tbaa !24
  store { i64, ptr } %a1, ptr %l5, !tbaa !27
  store i1 %a2, ptr %l6, !tbaa !21
  store i1 %a3, ptr %l7, !tbaa !21
  %t9 = load ptr, ptr @__olang_prog_scope
  %t10 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aBlockId_3e(ptr %t9)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t10, ptr %l13
  br label %bb1
bb1:
  %t11 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l13
  %t12 = load i64, ptr %l4, !tbaa !24
  %t13 = insertvalue %"compiler/lower:tryCtx" undef, i64 %t12, 0
  %t14 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t15 = insertvalue %"compiler/lower:tryCtx" %t13, { i64, ptr } %t14, 1
  %t16 = load i1, ptr %l6, !tbaa !21
  %t17 = insertvalue %"compiler/lower:tryCtx" %t15, i1 %t16, 2
  %t18 = load i1, ptr %l7, !tbaa !21
  %t19 = insertvalue %"compiler/lower:tryCtx" %t17, i1 %t18, 3
  %t21 = insertvalue %"compiler/lower:tryCtx" %t19, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t11, 4
  store %"compiler/lower:tryCtx" %t21, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/lower:tryCtx", ptr %rv
  ret %"compiler/lower:tryCtx" %rr
}

define dso_local void @olang_2einit_2ecompiler_2flower() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  call void @compiler_2flower_2eOutOfBounds_2einit()
  br label %bb1
bb1:
  call void @compiler_2flower_2eOverflow_2einit()
  br label %bb2
bb2:
  call void @compiler_2flower_2eInvalid_2einit()
  br label %bb3
bb3:
  call void @compiler_2flower_2eWrongCase_2einit()
  br label %bb4
bb4:
  call void @compiler_2flower_2eContract_2einit()
  br label %bb5
bb5:
  call void @compiler_2flower_2eFailIds_2einit()
  br label %bb6
bb6:
  call void @compiler_2flower_2eFailTypes_2einit()
  br label %bb7
bb7:
  call void @compiler_2flower_2eFailWords_2einit()
  br label %bb8
bb8:
  br label %ret
ret:
  ret void
}

@.d0 = private constant [10 x i8] c"ArrayError"
@.d1 = private constant [11 x i8] c"NumberError"
@.d2 = private constant [11 x i8] c"NumberError"
@.d3 = private constant [9 x i8] c"CaseError"
@.d4 = private constant [13 x i8] c"ArgumentError"
@.d5 = private constant [12 x i8] c"OUT_OF_RANGE"
@.d6 = private constant [8 x i8] c"OVERFLOW"
@.d7 = private constant [7 x i8] c"INVALID"
@.d8 = private constant [10 x i8] c"WRONG_CASE"
@.d9 = private constant [7 x i8] c"INVALID"
declare void @__olang_check_failed(ptr)
@__olang_prog_scope = external thread_local(initialexec) global ptr
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

declare noalias ptr @__olang_scope_alloc_a(ptr, i64, i64)
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
chunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@.d10 = private constant [0 x i8] c""
@.d11 = private constant [0 x i8] c""
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
@.d12 = private constant [0 x i8] c""
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@.d13 = private constant [16 x i8] c"std/prelude/text"
@.d14 = private constant [6 x i8] c"String"
@.d15 = private constant [43 x i8] c"an array literal of a type that is no array"
@.d16 = private constant [41 x i8] c"a constructor of a type that is no struct"
@.d17 = private constant [15 x i8] c"unhandled error"
@.d18 = private constant [1 x i8] c"."
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
@.d19 = private constant [51 x i8] c"a comprehension of a type that is no run-time array"
declare void @__olang_ert_req_clear()
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aBlockId_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fmir_3aBlockId_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3alevel_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2flower_3alevel_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

@.d20 = private constant [38 x i8] c"a jump out of a loop not being lowered"
@.d21 = private constant [4 x i8] c"null"
@.d22 = private constant [3 x i8] c"..."
define linkonce_odr i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fmir_3aScopeRef(ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca i64
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %t1
  store i64 %t2, ptr %l3, !tbaa !24
  %t3 = load ptr, ptr %l1, !tbaa !29
  %t4 = load i64, ptr %t3
  %t5 = load i64, ptr %l3, !tbaa !24
  %t7 = icmp eq i64 %t5, %t4
  br i1 %t7, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb10
bb2:
  %t9 = load i64, ptr %l3, !tbaa !24
  switch i64 %t9, label %bb3 [ i64 0, label %bb4 i64 1, label %bb5 i64 4, label %bb6 ]
bb3:
  br label %bb10
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr { i64, [1 x i64] }, ptr %t10, i32 0, i32 1
  %t12 = getelementptr { i32 }, ptr %t11, i32 0, i32 0
  %t13 = load i32, ptr %t12
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t15 = getelementptr { i64, [1 x i64] }, ptr %t14, i32 0, i32 1
  %t16 = getelementptr { i32 }, ptr %t15, i32 0, i32 0
  %t17 = load i32, ptr %t16
  %t20 = icmp eq i32 %t13, %t17
  br i1 %t20, label %bb7, label %bb1
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr { i64, [1 x i64] }, ptr %t22, i32 0, i32 1
  %t24 = getelementptr { i64 }, ptr %t23, i32 0, i32 0
  %t25 = load i64, ptr %t24
  %t26 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr { i64, [1 x i64] }, ptr %t26, i32 0, i32 1
  %t28 = getelementptr { i64 }, ptr %t27, i32 0, i32 0
  %t29 = load i64, ptr %t28
  %t32 = icmp eq i64 %t25, %t29
  br i1 %t32, label %bb8, label %bb1
bb6:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr { i64, [1 x i64] }, ptr %t34, i32 0, i32 1
  %t36 = getelementptr { i32 }, ptr %t35, i32 0, i32 0
  %t37 = load i32, ptr %t36
  %t38 = load ptr, ptr %l1, !tbaa !29
  %t39 = getelementptr { i64, [1 x i64] }, ptr %t38, i32 0, i32 1
  %t40 = getelementptr { i32 }, ptr %t39, i32 0, i32 0
  %t41 = load i32, ptr %t40
  %t44 = icmp eq i32 %t37, %t41
  br i1 %t44, label %bb9, label %bb1
bb7:
  br label %bb3
bb8:
  br label %bb3
bb9:
  br label %bb3
bb10:
  %t46 = load i1, ptr %l2, !tbaa !21
  store i1 %t46, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d23 = private constant [2 x i8] c", "
@.d24 = private constant [4 x i8] c"mut "
@.d25 = private constant [0 x i8] c""
@.d26 = private constant [2 x i8] c"?&"
@.d27 = private constant [1 x i8] c"&"
@.d28 = private constant [4 x i8] c"any "
@.d29 = private constant [6 x i8] c"Array<"
@.d30 = private constant [1 x i8] c">"
declare i64 @__olang_fmt_i64(ptr, i64)
@.d31 = private constant [2 x i8] c", "
@.d32 = private constant [2 x i8] c"fn"
@.d33 = private constant [2 x i8] c", "
@.d34 = private constant [1 x i8] c" "
@.d35 = private constant [2 x i8] c", "
@.d36 = private constant [1 x i8] c" "
@.d37 = private constant [1 x i8] c" "
@.d38 = private constant [2 x i8] c" ?"
@.d39 = private constant [2 x i8] c", "
@.d40 = private constant [1 x i8] c" "
@.d41 = private constant [2 x i8] c"U8"
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlan_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlan_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3aGap_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2flower_3aGap_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e_2ector(ptr %t1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aFnKey_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fmir_3aFnKey_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20Bool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20Bool_3e_2ector(ptr %t1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e_2ector(ptr %t1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aProj_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fmir_3aProj_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
@G_2ecompiler_2flower_2eFailTypes = external constant <{ [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr }>
@G_2ecompiler_2flower_2eFailWords = external constant <{ [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr }>
@G_2ecompiler_2flower_2eInvalid = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2flower_2eWrongCase = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
declare ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_daa9f23a83841987_24921124063ad36b = external constant [0 x i8]
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_Ha6bcf4d517e3d7b46809e1dbf938da91(ptr %v0, ptr %a0)
declare i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eHas_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_e3721461a855ef35_c24433bc0ae5f641 = external constant [0 x i8]
declare void @compiler_2fmir_3aFn_2ector(ptr %out, ptr %v0, { i64, [2 x i64] } %a0, i32 %a1, i64 %a2, %"compiler/source:Span" %a3)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI32_3e_2eLen_3cI32_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI32_3e_2eAt_3cI32_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI32_3e_2ePush_3cI32_3e(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @compiler_2flower_3alowering_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, ptr %a2, ptr %a3)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlan_3e_2eLen_3ccompiler_2ftyped_3aPlan_3e(ptr %v0, ptr %a0)
declare %"compiler/typed:Plan" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlan_3e_2eAt_3ccompiler_2ftyped_3aPlan_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2erun(ptr %v0, ptr %a0)
declare void @compiler_2flower_2ecompiler_2flower_3aLowerer_2eLowerKey(ptr %out, ptr %v0, ptr %v1, ptr %a0, { i64, [2 x i64] } %a1)
declare { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3aFn_2eVerify(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3aFn_2eDump(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_4e4c17ebfaf5d7b6_624a73934957b6f2 = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i32 %a3, i32 %a4, i64 %a5)
declare void @compiler_2flower_2ecompiler_2flower_3aLowerer_2ebare(ptr %out, ptr %v0, ptr %v1, ptr %a0, { i64, [2 x i64] } %a1, i32 %a2)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2eadapterBody(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i32 %a3)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eUnnamed(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ePreludeType(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v0, ptr %a0)
declare { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2ftyped_2eAnyItemNew(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eArgs(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_95894c0b36292ffb_c517f6bdfd218a6f = external constant [0 x i8]
@olang_loc_e6eae32e21930b7a_6f5872ba2e210dae = external constant [0 x i8]
@G_2ecompiler_2fmir_2eNoLocal = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\FF\FF\FF\FF" }>, align 8
declare %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %a0)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3alevel_3e_2eLen_3ccompiler_2flower_3alevel_3e(ptr %v0, ptr %a0)
declare %"compiler/lower:level" @compiler_2flower_2ecompiler_2flower_3alowering_2etop(ptr %v0, ptr %a0)
@olang_loc_2262f7260befbeda_ad33d1a86099f68e = external constant [0 x i8]
@olang_loc_78466967dd42e061_bdc585e3e8213235 = external constant [0 x i8]
@olang_loc_6143a96035d3ceac_ef612191f7538720 = external constant [0 x i8]
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2eopenBlock(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, i32 %a3)
@olang_loc_9919e1798def049b_eb223155b689b93f = external constant [0 x i8]
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2ecloseBlock(ptr %v0, ptr %a0)
declare i32 @compiler_2flower_2ecompiler_2flower_3alowering_2elocal(ptr %v0, ptr %a0, { i64, [4 x i64] } %a1, i32 %a2, %"compiler/source:Span" %a3)
@G_2ecompiler_2fmir_2eI64T = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\06\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eUnknownT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
declare i64 @compiler_2flower_2ecompiler_2flower_3alowering_2efixedLen(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/mir:Place" @compiler_2fmir_2ecompiler_2fmir_3aFn_2ePlace(ptr %v0, ptr %v1, ptr %a0, { i64, [2 x i64] } %a1, { i64, ptr } %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eBoolT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
declare i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %a0)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %a0, { i64, [7 x i64] } %a1)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2egoto(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2eleave(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_b4f44bfc4c4e49f2_17d18a81dcc1f1de = external constant [0 x i8]
declare { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einstance(ptr %v0, ptr %a0)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDestructs(ptr %v0, ptr %a0, i32 %a1)
declare %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %v0, i64 %a0, i64 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2etextData(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, %"compiler/source:Span" %a2)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fmir_3aOperand_3e_2ector(ptr %v0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %a0, i32 %a1)
declare ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fload_2eErrQualifier(ptr %v0, ptr %v1, { i64, ptr } %a0, i1 %a1)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorWords(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2fmir_2eI32T = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\05\00\00\00" }>, align 8
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aOperand_3e_2ePush_3ccompiler_2fmir_3aOperand_3e(ptr %v0, ptr %a0, { i64, [4 x i64] } %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aOperand_3e_2eToArray_3ccompiler_2fmir_3aOperand_3e(ptr %v0, ptr %v1, ptr %a0)
declare { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2escopeRef(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1)
declare %"compiler/mir:Range" @compiler_2flower_2ecompiler_2flower_3alowering_2eargs(ptr %v0, ptr %v1, ptr %a0, ptr %a1, { i64, [7 x i64] } %a2, i32 %a3)
declare { i64, [4 x i64] } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aOperand_3e_2eAt_3ccompiler_2fmir_3aOperand_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_b0754b7649fd7859_91d9947d7b887e0d = external constant [0 x i8]
declare i64 @compiler_2fmir_2ePassedCount(ptr %v0, ptr %a0, { i64, [7 x i64] } %a1, i32 %a2)
@G_2ecompiler_2ftypes_2eVoidT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
@G_2ecompiler_2ftypes_2eNoreturnT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\11\00\00\00" }>, align 8
@G_2ecompiler_2fmir_2eNoBlock = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\FF\FF\FF\FF" }>, align 8
@G_2ecompiler_2fmir_2eNoPlace = available_externally constant <{ [32 x i8] }> <{ [32 x i8] c"\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00" }>, align 32
declare %"compiler/mir:Call" @compiler_2fmir_3aCall_2ector(ptr %v0, { i64, [7 x i64] } %a0, %"compiler/mir:Range" %a1, %"compiler/mir:Range" %a2, %"compiler/mir:Place" %a3, i1 %a4, i32 %a5, i32 %a6, i32 %a7)
declare i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddCall(ptr %v0, ptr %a0, %"compiler/mir:Call" %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %a0, i64 %a1)
declare { { i64, [7 x i64] }, i32 } @compiler_2flower_2ecompiler_2flower_3alowering_2evalueCallee(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_21e9da82ebd620c7_b6074e807b9f75fb = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeCases(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_3b8f4ce72bb8c828_c6f22e3cb9711da4 = external constant [0 x i8]
declare { i32, i64 } @compiler_2flower_2ecompiler_2flower_3aLowerer_2efailure(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList1(ptr %v0, ptr %a0, i32 %a1)
declare i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aBlockId_3e_2eAt_3ccompiler_2fmir_3aBlockId_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aBlockId_3e_2ePush_3ccompiler_2fmir_3aBlockId_3e(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_ed4966d7257d1cce_314b285230575e82 = external constant [0 x i8]
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2eblock(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_4fc14cddf040b63b_d4edc892d8598fd7 = external constant [0 x i8]
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2eleaveOpen(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeId_3e_2eAt_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeId_3e_2eSetAt_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aBlock_26_3e_2eAt_Hef81d01aee8891fe569e7a3039d88992(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArray(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
@G_2ecompiler_2ftypes_2eWritable = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
@olang_loc_162f2c5d450ff5be_60a02040feb29ca2 = external constant [0 x i8]
declare { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2easI64(ptr %v0, ptr %a0, { i64, [4 x i64] } %a1, i32 %a2, %"compiler/source:Span" %a3)
@G_2ecompiler_2flower_2eOutOfBounds = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare %"compiler/lower:collectCtx" @compiler_2flower_3acollectCtx_2ector(ptr %v0, i32 %a0, i32 %a1, i32 %a2, i32 %a3, { i64, [1 x i64] } %a4)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3acollectCtx_3e_2e_H653cfca5a0404061ead7e6ea50e2c820(ptr %v0, ptr %a0, %"compiler/lower:collectCtx" %a1)
declare { i32, %"compiler/lower:collectCtx" } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3acollectCtx_3e_2e_Hcb64b7cee1ab394e20e0c0dd5741806d(ptr %v0, ptr %a0)
declare i1 @compiler_2ftyped_2eScopedCall(ptr %v0, ptr %a0)
@olang_loc_755da8ec4c9a9682_903a5def85eef08e = external constant [0 x i8]
@olang_loc_429a5ad7d8f4c2a0_c1ea905c2e39baec = external constant [0 x i8]
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3atryCtx_3e_2eLen_3ccompiler_2flower_3atryCtx_3e(ptr %v0, ptr %a0)
declare %"compiler/lower:tryCtx" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3atryCtx_3e_2eAt_3ccompiler_2flower_3atryCtx_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
@olang_loc_c6e2ba3cedb073a3_23085f6ef83cda97 = external constant [0 x i8]
declare %"compiler/lower:level" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3alevel_3e_2eAt_3ccompiler_2flower_3alevel_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i32, %"compiler/lower:level" } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3alevel_3e_2ePop_3ccompiler_2flower_3alevel_3e(ptr %v0, ptr %a0)
@olang_loc_831aef8878f0c239_4d65f3dd2c1f4c9d = external constant [0 x i8]
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3alevel_3e_2ePush_3ccompiler_2flower_3alevel_3e(ptr %v0, ptr %a0, %"compiler/lower:level" %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aBlock_26_3e_2eLe_H8743fc75fe5cead0bda2da42e1adf3f3(ptr %v0, ptr %a0)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_53acd22e8270d268_dadfa79394a107ec = external constant [0 x i8]
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/typed:BlockInfo" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aBlockInfo_3e_2eA_Hdb91c1ab6f912bb6141763aa02d0b766(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_13daf6ec8e30e943_ad19332534c71267 = external constant [0 x i8]
@olang_loc_d7de50d0c280a1c2_f8c3e581c8870786 = external constant [0 x i8]
declare %"compiler/mir:ScopeInfo" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeInfo_3e_2eAt_3ccompiler_2fmir_3aScopeInfo_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2ejoinFailed(ptr %v0, ptr %a0, i64 %a1, i32 %a2, { i64, [4 x i64] } %a3, i32 %a4, %"compiler/source:Span" %a5)
declare { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2econstBool(ptr %v0, ptr %a0, i1 %a1, %"compiler/source:Span" %a2)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3aGap_3e_2ePush_3ccompiler_2flower_3aGap_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/lower:Gap" %a1)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2eprologue(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2eat(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eequalAt(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/lower:pl" %a1, %"compiler/lower:pl" %a2, i32 %a3, %"compiler/source:Span" %a4, i1 %a5)
declare { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ehashAt(ptr %v0, ptr %v1, ptr %a0, %"compiler/lower:pl" %a1, i32 %a2, %"compiler/source:Span" %a3, i1 %a4)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopeVarsOf(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ezeroOf(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2erenderAt(ptr %v0, ptr %v1, ptr %a0, %"compiler/lower:pl" %a1, i32 %a2, { i64, [1 x i64] } %a3, %"compiler/source:Span" %a4, i1 %a5)
@olang_loc_30767a805df234bd_503f920f410b6239 = external constant [0 x i8]
declare i32 @compiler_2fmir_2eHelperType(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare void @compiler_2flower_2ecompiler_2flower_3aLowerer_2eWant(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1)
declare %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eScopeRefs(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eisText(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2flower_2ecompiler_2flower_3alowering_2ehasStr(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2flower_2ecompiler_2flower_3aLowerer_2echar(ptr %v0, ptr %a0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_fe6f132f471090d8_e27fa787bcbe9484 = external constant [0 x i8]
declare i32 @compiler_2flower_2ecompiler_2flower_3alowering_2ejoinErrors(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3atryCtx_3e_2ePush_3ccompiler_2flower_3atryCtx_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/lower:tryCtx" %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeId_3e_2ePush_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %a0, i32 %a1)
declare { i32, %"compiler/lower:tryCtx" } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3atryCtx_3e_2ePop_3ccompiler_2flower_3atryCtx_3e(ptr %v0, ptr %v1, ptr %a0)
declare { i32, i32 } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeId_3e_2ePop_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3aloopCtx_3e_2eLen_3ccompiler_2flower_3aloopCtx_3e(ptr %v0, ptr %a0)
declare %"compiler/lower:loopCtx" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3aloopCtx_3e_2eAt_3ccompiler_2flower_3aloopCtx_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"compiler/lower:loopCtx" @compiler_2flower_3aloopCtx_2ector(ptr %v0, i32 %a0, i64 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3aloopCtx_3e_2ePus_Hecf1f3338ace0b99f129de91c7b21562(ptr %v0, ptr %v1, ptr %a0, %"compiler/lower:loopCtx" %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aBlockId_3e_2eLen_3ccompiler_2fmir_3aBlockId_3e(ptr %v0, ptr %a0)
declare { i32, %"compiler/lower:loopCtx" } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3aloopCtx_3e_2ePop_3ccompiler_2flower_3aloopCtx_3e(ptr %v0, ptr %v1, ptr %a0)
declare { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2efill(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3, i1 %a4, { i64, [1 x i64] } %a5)
@olang_loc_c00faf6434efe24b_96f261c8870620df = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aProj_3e_2eToArray_3ccompiler_2fmir_3aProj_3e(ptr %v0, ptr %v1, ptr %a0)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_He36936f29a17adf60cb2ecc49df5337f(ptr %v0, ptr %a0)
@olang_loc_279896acdd8c6bde_4c10668047ad718a = external constant [0 x i8]
declare { i64, [1 x i64] } @compiler_2ftyped_2ecompiler_2ftyped_3aPlan_2ePassed(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aBlockId_3e_2eRunFrom_3ccompiler_2fmir_3aBlockId_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_678a134ca8e67a35_be411b19d54605f9 = external constant [0 x i8]
declare void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eEnd(ptr %v0, ptr %a0, i32 %a1, { i64, [7 x i64] } %a2)
declare %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2eplace(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
@G_2ecompiler_2ftypes_2eReadOnly = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
@olang_loc_eff9370fb6cf39b1_ff4f9c232720af7d = external constant [0 x i8]
@olang_loc_4fc653f117519a1d_d526ff90513f5371 = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_f5162d6fd39a8c0b_7722e13858f6fdef = external constant [0 x i8]
@olang_loc_3c6cf9f7cb6c21ca_21635d3489f6812e = external constant [0 x i8]
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsAny(ptr %v0, ptr %a0, i32 %a1)
declare { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2edepth(ptr %v0, ptr %a0)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNullable(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_ddcb411f232bf43e_ce3417657830a5fa = external constant [0 x i8]
@olang_loc_ecde87765d07009c_52dfe83edba10a08 = external constant [0 x i8]
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3alevel_3e_2eRunFrom_3ccompiler_2flower_3alevel_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_2e0d72be7b5575d7_214712821f524de3 = external constant [0 x i8]
declare %"compiler/mir:Local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aLocal_3e_2eAt_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eresultScope(ptr %v0, ptr %a0)
@olang_loc_4b16c1f6667ae236_8522eea6e5c16fe2 = external constant [0 x i8]
@olang_loc_d0e8b819f5194451_9afcdf330b6f59b5 = external constant [0 x i8]
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNumber(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %a0, i32 %a1)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %a0, i8 %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
@G_2ecompiler_2ftypes_2eNullable = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAnyTrait(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstValue(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNamesOf(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare %"compiler/typed:Local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2efit(ptr %v0, ptr %v1, ptr %a0, { i64, [4 x i64] } %a1, ptr %a2, i32 %a3, %"compiler/source:Span" %a4)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3apl_3e_2ePush_3ccompiler_2flower_3apl_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/lower:pl" %a1)
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aPlace_2eType(ptr %v0, ptr %a0)
declare { i32, %"compiler/lower:pl" } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3apl_3e_2ePop_3ccompiler_2flower_3apl_3e(ptr %v0, ptr %v1, ptr %a0)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2eifStmt(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2eret(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare i64 @compiler_2fmir_2eErrorCode(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i64 %a3)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aBlock_26_3e_2ePu_H0a6921d1f6104d156ffed3729e33edeb(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2espawn(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2eyield(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
@olang_loc_b7b09248cda006f_e3ce57a596777ddb = external constant [0 x i8]
declare i32 @compiler_2flower_2ecompiler_2flower_3alowering_2etaskType(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eRunF_H9c1707946c43ec840ffe1821bea89b1f(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_7b1a9423057e34c5_261f06cd9be6d659 = external constant [0 x i8]
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_4d2a900631880414_3719f57230f55c88 = external constant [0 x i8]
declare i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddTemp(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aBlockId_3e_2eSetAt_3ccompiler_2fmir_3aBlockId_3e(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
@olang_loc_d8cada644e10ccc9_6a931382540e069d = external constant [0 x i8]
@olang_loc_73384406ab4916da_7af5324ba56268d6 = external constant [0 x i8]
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aProj_3e_2eRunFrom_3ccompiler_2fmir_3aProj_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_e4cb0830a37b0e81_73b8c395fe92f955 = external constant [0 x i8]
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aProj_3e_2ePush_3ccompiler_2fmir_3aProj_3e(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1)
@olang_loc_683e5e170631bc0e_4d1425fdf2d9aa22 = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddConst(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@G_2ecompiler_2fmir_2eEmpty = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
@olang_loc_eebb62a013643219_b45f662b48cacfad = external constant [0 x i8]
@olang_loc_18ba96ebd2acdd48_1f3e7581818ceffc = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %a0, i32 %a1)
declare void @compiler_2ftyped_3aBody_2ector(ptr %out, ptr %v0, i32 %a0, { i64, [2 x i64] } %a1, i32 %a2, i64 %a3, %"compiler/source:Span" %a4)
declare void @compiler_2flower_2eOutOfBounds_2einit()
declare void @compiler_2flower_2eOverflow_2einit()
declare void @compiler_2flower_2eContract_2einit()
declare void @compiler_2flower_2eFailIds_2einit()
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fmir_3aBlockId_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2flower_3alevel_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlan_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2flower_3aGap_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fmir_3aFnKey_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20Bool_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fmir_3aProj_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
