; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/typed:Seq" = type { { i64, ptr }, ptr, i1 }
%"compiler/lower:Lowerer" = type { ptr, ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i32, i32, i64, i64, i64, i64, i64, i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i64, i64 }
%"compiler/typed:Body" = type { i32, { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i32, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/mir:Fn" = type { { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/lower:lowering" = type { ptr, ptr, ptr, %"compiler/mir:Fn", i64, { i64, [4 x i64] }, i32, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, i1, { i64, [1 x i64] }, i32, { i64, [1 x i64] }, %"compiler/typed:Plan", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i32, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/typed:DropHolding", i1, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i32, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/typed:Plan" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/typed:DropHolding" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/generic:Program" = type { ptr, ptr, %"compiler/types:Table", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"compiler/generic:Origin", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/types:Table" = type { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/generic:Origin" = type { i64, %"compiler/source:Span", i64 }
%"compiler/typed:LocalUses" = type { ptr, ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i32 }
%"compiler/load:Loader" = type { { i64, ptr }, ptr, ptr, ptr, ptr, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/load:Module" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i64, i1, ptr, ptr, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr, ptr, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/typed:Make" = type { i32, i64, { i64, ptr }, ptr, i32, i32, i1 }
%"compiler/typed:Call" = type { ptr, { i64, ptr }, i32, i1, i1 }
%"compiler/mir:Range" = type { i32, i32 }
%"compiler/typed:Promote" = type { ptr, i32 }
%"compiler/mir:Lvalue" = type { { i64, [2 x i64] }, %"compiler/mir:Range" }
%"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" = type { i64, i64 }
%"compiler/lower:level" = type { i32, i32, i32 }
%"compiler/lower:pl" = type { { i64, [2 x i64] }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i32 }
%"compiler/typed:Item" = type { i32, i64 }
%"compiler/lower:tryCtx" = type { i64, { i64, ptr }, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/typed:Clause" = type { %"compiler/source:Span", { i64, ptr }, i1, ptr, { i64, ptr }, i64, i32 }
%"compiler/typed:BlockInfo" = type { i32, i32, %"compiler/source:Span" }
%"compiler/lower:Gap" = type { i64, %"compiler/source:Span", { i64, ptr } }
%"compiler/typed:Local" = type { i32, %"compiler/source:Span", i32, i32, i32, { i64, [1 x i64] }, i1 }
%"compiler/free:leaf" = type { { i64, ptr }, i64 }
%"compiler/lower:loopCtx" = type { i32, i64, i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/typed:Block" = type { i32, { i64, ptr } }
%"compiler/typed:Match" = type { { i64, ptr }, { i64, ptr }, ptr, i1 }
%"compiler/typed:Arm" = type { %"compiler/source:Span", { i64, ptr }, ptr, ptr, ptr }
%"compiler/typed:LastUses" = type { i64, { i64, ptr }, { i64, ptr }, i64, i64, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/typed:Elem" = type { ptr, ptr, i32 }
%"compiler/typed:Payload" = type { ptr, i64, i32 }
%"compiler/typed:Try" = type { ptr, { i64, ptr }, i1, i1, i1 }
%"compiler/typed:Slice" = type { ptr, ptr, ptr, i32 }
%"compiler/mir:Local" = type { i32, %"compiler/source:Span", i32, i32, { i64, [1 x i64] } }
%"compiler/mir:Call" = type { { i64, [7 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/mir:Lvalue", i1, i32, i32, i32 }
%"compiler/mir:BasicBlock" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, [8 x i64] } }
define dso_local ptr @compiler_2flower_2eborrowedPlace(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i1
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  store i1 false, ptr %l4, !tbaa !21
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 3
  store i1 %t8, ptr %l4, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l4, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  store ptr %t16, ptr %l2, !tbaa !29
  br label %bb11
bb6:
  br i1 true, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store ptr null, ptr %l2, !tbaa !29
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_76ec7e11cc604d77_65dfbe8f138a0f63)
  unreachable
bb11:
  %t19 = load ptr, ptr %l2, !tbaa !29
  store ptr %t19, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2flower_2ecollectOf(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i1
  %l12 = alloca ptr
  %l13 = alloca i1
  %l22 = alloca ptr
  %l28 = alloca ptr
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 8
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  store ptr %t16, ptr %l3, !tbaa !29
  br label %bb24
bb6:
  %t19 = load ptr, ptr %l0, !tbaa !29
  store ptr %t19, ptr %l12, !tbaa !29
  store i1 false, ptr %l13, !tbaa !21
  %t20 = load ptr, ptr %l12, !tbaa !29
  %t21 = icmp ne ptr %t20, null
  br i1 %t21, label %bb7, label %bb8
bb7:
  %t23 = load ptr, ptr %l12, !tbaa !29
  %t24 = load i64, ptr %t23, !range !{i64 0, i64 18}
  %t26 = icmp eq i64 %t24, 12
  store i1 %t26, ptr %l13, !tbaa !21
  br label %bb8
bb8:
  %t27 = load i1, ptr %l13, !tbaa !21
  br i1 %t27, label %bb9, label %bb10
bb9:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr { i64, [5 x i64] }, ptr %t28, i32 0, i32 1
  %t31 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t30, i32 0, i32 2
  %t32 = load ptr, ptr %t31
  store ptr %t32, ptr %l2, !tbaa !29
  br label %bb11
bb10:
  br label %bb19
bb11:
  %t34 = load ptr, ptr %l2, !tbaa !29
  %t36 = getelementptr %"compiler/typed:Seq", ptr %t34, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !29
  %t39 = icmp eq ptr %t37, null
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb12, label %bb13
bb12:
  %t43 = load ptr, ptr %l2, !tbaa !29
  %t45 = getelementptr %"compiler/typed:Seq", ptr %t43, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !29
  %t48 = icmp eq ptr %t46, null
  br i1 %t48, label %bb14, label %bb15
bb13:
  store ptr null, ptr %l22, !tbaa !29
  br label %bb18
bb14:
  call void @__olang_check_failed(ptr @olang_loc_b33a0661a011e178_dcd63aec50757664)
  unreachable
bb15:
  br label %bb16
bb16:
  %t50 = load ptr, ptr %l2, !tbaa !29
  %t52 = getelementptr %"compiler/typed:Seq", ptr %t50, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !29
  %t55 = call ptr @compiler_2flower_2ecollectOf(ptr %v0, ptr %v1, ptr %t53)
  store ptr %t55, ptr %l28
  br label %bb17
bb17:
  %t56 = load ptr, ptr %l28, !tbaa !29
  store ptr %t56, ptr %l22, !tbaa !29
  br label %bb18
bb18:
  %t57 = load ptr, ptr %l22, !tbaa !29
  store ptr %t57, ptr %l3, !tbaa !29
  br label %bb24
bb19:
  br i1 true, label %bb20, label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb23
bb22:
  store ptr null, ptr %l3, !tbaa !29
  br label %bb24
bb23:
  call void @__olang_check_failed(ptr @olang_loc_ad272ff31dc381ae_4a185251f7060aca)
  unreachable
bb24:
  %t58 = load ptr, ptr %l3, !tbaa !29
  store ptr %t58, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3aLowerer_2eHasCode(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l2 = alloca ptr
  %l7 = alloca ptr
  %l14 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/lower:Lowerer", ptr %a0, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t8 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t4, i64 %a1)
  store ptr %t8, ptr %l7
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l7, !tbaa !29
  store ptr %t9, ptr %l2, !tbaa !29
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t12 = getelementptr %"compiler/typed:Body", ptr %t10, i32 0, i32 11
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t15 = icmp eq ptr %t13, null
  br i1 %t15, label %bb2, label %bb3
bb2:
  store i1 false, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t18 = load ptr, ptr %l2, !tbaa !29
  %t20 = getelementptr %"compiler/typed:Body", ptr %t18, i32 0, i32 1
  %t21 = load { i64, [2 x i64] }, ptr %t20
  %t25 = extractvalue { i64, [2 x i64] } %t21, 0
  %t26 = icmp eq i64 %t25, 2
  br i1 %t26, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb8
bb7:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb13
bb8:
  br i1 true, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  store i1 true, ptr %l14, !tbaa !21
  br label %bb13
bb12:
  call void @__olang_check_failed(ptr @olang_loc_daa9f23a83841987_24921124063ad36b)
  unreachable
bb13:
  %t28 = load i1, ptr %l14, !tbaa !21
  store i1 %t28, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3aLowerer_2eLower(ptr %out, ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %lp3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i32
  %lp11 = alloca ptr
  %l15 = alloca ptr
  %l26 = alloca %"compiler/mir:Fn"
  %l29 = alloca i64
  %l33 = alloca i64
  %l36 = alloca i64
  %l54 = alloca ptr
  %l58 = alloca i32
  %l59 = alloca ptr
  %l63 = alloca { i64, ptr }
  %l70 = alloca i32
  %l76 = alloca ptr
  %l82 = alloca i32
  %l84 = alloca i64
  %l91 = alloca %"compiler/lower:lowering"
  %l93 = alloca %"compiler/lower:lowering"
  %l96 = alloca i64
  %l99 = alloca i64
  %l104 = alloca %"compiler/typed:Plan"
  %l106 = alloca %"compiler/typed:Plan"
  %l111 = alloca i1
  %l118 = alloca i1
  %l122 = alloca %"compiler/mir:Fn"
  %l124 = alloca %"compiler/mir:Fn"
  %s4 = alloca %olang.scope
  %t14 = alloca { i64, [2 x i64] }, align 8
  %t32 = alloca %"compiler/mir:Fn", align 8
  %t173 = alloca %"compiler/lower:lowering", align 8
  %t178 = alloca %"compiler/lower:lowering", align 8
  %t205 = alloca %"compiler/typed:Plan", align 8
  %t208 = alloca %"compiler/typed:Plan", align 8
  %t251 = alloca %"compiler/mir:Fn", align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:Lowerer", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i64, ptr %l1, !tbaa !24
  %t8 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v1, ptr %t4, i64 %t5)
  store ptr %t8, ptr %l15
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l15, !tbaa !29
  store ptr %t9, ptr %l2, !tbaa !29
  %t10 = load i64, ptr %l1, !tbaa !24
  %t12 = trunc i64 %t10 to i32
  store { i64, [2 x i64] } zeroinitializer, ptr %t14
  %t15 = getelementptr { i64, [2 x i64] }, ptr %t14, i32 0, i32 0
  store i64 0, ptr %t15
  %t17 = insertvalue { i32 } undef, i32 %t12, 0
  %t18 = getelementptr { i64, [2 x i64] }, ptr %t14, i32 0, i32 1
  store { i32 } %t17, ptr %t18
  %t19 = load { i64, [2 x i64] }, ptr %t14
  %t20 = load ptr, ptr %l2, !tbaa !29
  %t22 = getelementptr %"compiler/typed:Body", ptr %t20, i32 0, i32 2
  %t23 = load i32, ptr %t22, !tbaa !23
  %t24 = load ptr, ptr %l2, !tbaa !29
  %t26 = getelementptr %"compiler/typed:Body", ptr %t24, i32 0, i32 3
  %t27 = load i64, ptr %t26, !tbaa !24
  %t28 = load ptr, ptr %l2, !tbaa !29
  %t30 = getelementptr %"compiler/typed:Body", ptr %t28, i32 0, i32 4
  %t31 = load %"compiler/source:Span", ptr %t30
  call void @compiler_2fmir_3aFn_2ector(ptr %t32, ptr %v1, { i64, [2 x i64] } %t19, i32 %t23, i64 %t27, %"compiler/source:Span" %t31)
  call void @llvm.memmove.p0.p0.i64(ptr %l26, ptr %t32, i64 800, i1 false)
  br label %bb2
bb2:
  %t37 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 800, i64 8)
  store ptr %t37, ptr %lp3
  %t38 = load ptr, ptr %lp3
  call void @llvm.memmove.p0.p0.i64(ptr %t38, ptr %l26, i64 800, i1 false)
  store i64 0, ptr %l4, !tbaa !24
  %t39 = load ptr, ptr %l2, !tbaa !29
  %t41 = getelementptr %"compiler/typed:Body", ptr %t39, i32 0, i32 12
  %t43 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI32_3e_2eLen_3cI32_3e(ptr %v1, ptr %t41)
  store i64 %t43, ptr %l29
  br label %bb3
bb3:
  %t44 = load i64, ptr %l29, !tbaa !24
  store i64 %t44, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t45 = load i64, ptr %l5, !tbaa !24
  %t46 = load i64, ptr %l4, !tbaa !24
  %t49 = icmp sgt i64 %t45, %t46
  br i1 %t49, label %bb4, label %bb5
bb4:
  %t51 = load i64, ptr %l6, !tbaa !24
  %t53 = icmp sgt i64 %t51, 0
  br i1 %t53, label %bb6, label %bb7
bb5:
  store i64 0, ptr %l33, !tbaa !24
  br label %bb9
bb6:
  %t55 = load i64, ptr %l5, !tbaa !24
  %t56 = load i64, ptr %l4, !tbaa !24
  %t59 = sub i64 %t55, %t56
  %t60 = load i64, ptr %l6, !tbaa !24
  %t63 = add i64 %t59, %t60
  %t65 = sub i64 %t63, 1
  %t66 = load i64, ptr %l6, !tbaa !24
  %t69 = sdiv i64 %t65, %t66
  store i64 %t69, ptr %l36, !tbaa !24
  br label %bb8
bb7:
  store i64 0, ptr %l36, !tbaa !24
  br label %bb8
bb8:
  %t71 = load i64, ptr %l36, !tbaa !24
  store i64 %t71, ptr %l33, !tbaa !24
  br label %bb9
bb9:
  %t72 = load i64, ptr %l33, !tbaa !24
  store i64 %t72, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb10
bb10:
  %t73 = load i64, ptr %l8, !tbaa !24
  %t74 = load i64, ptr %l7, !tbaa !24
  %t77 = icmp slt i64 %t73, %t74
  %t79 = xor i1 %t77, true
  br i1 %t79, label %bb11, label %bb12
bb11:
  br label %bb19
bb12:
  br label %bb13
bb13:
  %t81 = load i64, ptr %l4, !tbaa !24
  %t82 = load i64, ptr %l8, !tbaa !24
  %t83 = load i64, ptr %l6, !tbaa !24
  %t86 = mul i64 %t82, %t83
  %t89 = add i64 %t81, %t86
  store i64 %t89, ptr %l9, !tbaa !24
  %t91 = load ptr, ptr %lp3
  %t92 = getelementptr %"compiler/mir:Fn", ptr %t91, i32 0, i32 23
  store ptr %t92, ptr %l54, !tbaa !29
  %t93 = load ptr, ptr %l2, !tbaa !29
  %t95 = getelementptr %"compiler/typed:Body", ptr %t93, i32 0, i32 12
  %t96 = load i64, ptr %l9, !tbaa !24
  %t99 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI32_3e_2eAt_3cI32_3e(ptr %v1, ptr %t95, i64 %t96)
  store i32 %t99, ptr %l58
  br label %bb14
bb14:
  %t100 = load ptr, ptr %l54, !tbaa !29
  %t101 = load i32, ptr %l58, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI32_3e_2ePush_3cI32_3e(ptr %v1, ptr %t100, i32 %t101)
  br label %bb15
bb15:
  %t102 = load ptr, ptr %lp3
  %t103 = getelementptr %"compiler/mir:Fn", ptr %t102, i32 0, i32 24
  store ptr %t103, ptr %l59, !tbaa !29
  %t104 = load ptr, ptr %l2, !tbaa !29
  %t106 = getelementptr %"compiler/typed:Body", ptr %t104, i32 0, i32 13
  %t107 = load i64, ptr %l9, !tbaa !24
  %t110 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v1, ptr %v1, ptr %t106, i64 %t107)
  store { i64, ptr } %t110, ptr %l63
  br label %bb16
bb16:
  %t111 = load ptr, ptr %l59, !tbaa !29
  %t112 = load { i64, ptr }, ptr %l63, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %t111, { i64, ptr } %t112)
  br label %bb17
bb17:
  br label %bb18
bb18:
  %t113 = load i64, ptr %l8, !tbaa !24
  %t115 = add i64 %t113, 1
  store i64 %t115, ptr %l8, !tbaa !24
  br label %bb10
bb19:
  %t117 = load ptr, ptr %l2, !tbaa !29
  %t119 = getelementptr %"compiler/typed:Body", ptr %t117, i32 0, i32 14
  %t120 = load i1, ptr %t119, !tbaa !21
  br i1 %t120, label %bb20, label %bb21
bb20:
  store %olang.scope zeroinitializer, ptr %s4
  %t122 = load ptr, ptr %lp3
  %t123 = getelementptr %"compiler/mir:Fn", ptr %t122, i32 0, i32 25
  store i1 true, ptr %t123, !tbaa !21
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t126 = getelementptr %"compiler/lower:Lowerer", ptr %t124, i32 0, i32 0
  %t127 = load ptr, ptr %t126, !tbaa !29
  %t129 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ePreludeType(ptr %v0, ptr %s4, ptr %s4, ptr %t127, { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d0, i32 0, i32 1) }, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d1, i32 0, i32 1) })
  store i32 %t129, ptr %l70
  br label %bb22
bb21:
  br label %bb28
bb22:
  %t130 = load i32, ptr %l70, !tbaa !23
  store i32 %t130, ptr %l10, !tbaa !23
  %t131 = load i32, ptr %l10, !tbaa !23
  %t132 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t135 = icmp ne i32 %t131, %t132
  br i1 %t135, label %bb23, label %bb24
bb23:
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t139 = getelementptr %"compiler/lower:Lowerer", ptr %t137, i32 0, i32 0
  %t140 = load ptr, ptr %t139, !tbaa !29
  %t142 = getelementptr %"compiler/generic:Program", ptr %t140, i32 0, i32 2
  store ptr %t142, ptr %l76, !tbaa !29
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t145 = getelementptr %"compiler/lower:Lowerer", ptr %t143, i32 0, i32 0
  %t146 = load ptr, ptr %t145, !tbaa !29
  %t148 = getelementptr %"compiler/generic:Program", ptr %t146, i32 0, i32 2
  %t149 = load ptr, ptr %l2, !tbaa !29
  %t151 = getelementptr %"compiler/typed:Body", ptr %t149, i32 0, i32 2
  %t152 = load i32, ptr %t151, !tbaa !23
  %t155 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t148, i32 %t152)
  store i32 %t155, ptr %l82
  br label %bb25
bb24:
  br label %bb27
bb25:
  %t156 = load i32, ptr %l10, !tbaa !23
  %t157 = load ptr, ptr %l76, !tbaa !29
  %t158 = load i32, ptr %l82, !tbaa !23
  %t160 = call i64 @compiler_2fmir_2eErrorCode(ptr %v0, ptr %t157, i32 %t158, i32 %t156, i64 0)
  store i64 %t160, ptr %l84
  br label %bb26
bb26:
  %t161 = load i64, ptr %l84, !tbaa !24
  %t162 = load ptr, ptr %lp3
  %t163 = getelementptr %"compiler/mir:Fn", ptr %t162, i32 0, i32 26
  store i64 %t161, ptr %t163, !tbaa !24
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s4)
  br label %bb28
bb28:
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t165 = load ptr, ptr %l2, !tbaa !29
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t168 = getelementptr %"compiler/lower:Lowerer", ptr %t166, i32 0, i32 0
  %t169 = load ptr, ptr %t168, !tbaa !29
  %t171 = getelementptr %"compiler/generic:Program", ptr %t169, i32 0, i32 2
  %t172 = load ptr, ptr %lp3
  call void @compiler_2flower_3alowering_2ector(ptr %t173, ptr %v0, ptr %v1, ptr %v0, ptr %v1, ptr %v1, ptr %t164, ptr %t165, ptr %t171, ptr %t172)
  call void @llvm.memmove.p0.p0.i64(ptr %l91, ptr %t173, i64 2400, i1 false)
  br label %bb29
bb29:
  call void @olang_2eHelperKind_2eCopy_2ecompiler_2flower_3alowering(ptr %t178, ptr %v1, ptr %l91)
  call void @llvm.memmove.p0.p0.i64(ptr %l93, ptr %t178, i64 2400, i1 false)
  br label %bb30
bb30:
  %t180 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 2400, i64 8)
  store ptr %t180, ptr %lp11
  %t181 = load ptr, ptr %lp11
  call void @llvm.memmove.p0.p0.i64(ptr %t181, ptr %l93, i64 2400, i1 false)
  %t182 = load ptr, ptr %l2, !tbaa !29
  %t184 = getelementptr %"compiler/typed:Body", ptr %t182, i32 0, i32 3
  %t185 = load i64, ptr %t184, !tbaa !24
  %t187 = load ptr, ptr %lp11
  %t188 = getelementptr %"compiler/lower:lowering", ptr %t187, i32 0, i32 4
  store i64 %t185, ptr %t188, !tbaa !24
  %t189 = load i64, ptr %l1, !tbaa !24
  store i64 %t189, ptr %l96, !tbaa !24
  %t190 = load ptr, ptr %l0, !tbaa !29
  %t192 = getelementptr %"compiler/lower:Lowerer", ptr %t190, i32 0, i32 2
  %t194 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlan_3e_2eLen_3ccompiler_2ftyped_3aPlan_3e(ptr %v0, ptr %t192)
  store i64 %t194, ptr %l99
  br label %bb31
bb31:
  %t195 = load i64, ptr %l96, !tbaa !24
  %t196 = load i64, ptr %l99, !tbaa !24
  %t197 = icmp slt i64 %t195, %t196
  br i1 %t197, label %bb32, label %bb33
bb32:
  %t199 = load ptr, ptr %lp11
  %t200 = getelementptr %"compiler/lower:lowering", ptr %t199, i32 0, i32 19
  store i1 true, ptr %t200, !tbaa !21
  %t201 = load ptr, ptr %l0, !tbaa !29
  %t203 = getelementptr %"compiler/lower:Lowerer", ptr %t201, i32 0, i32 2
  %t204 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlan_3e_2eAt_3ccompiler_2ftyped_3aPlan_3e(ptr %t205, ptr %v0, ptr %v1, ptr %t203, i64 %t204)
  call void @llvm.memmove.p0.p0.i64(ptr %l104, ptr %t205, i64 176, i1 false)
  br label %bb34
bb33:
  br label %bb36
bb34:
  call void @olang_2eHelperKind_2eCopy_2ecompiler_2ftyped_3aPlan(ptr %t208, ptr %v1, ptr %l104)
  call void @llvm.memmove.p0.p0.i64(ptr %l106, ptr %t208, i64 176, i1 false)
  br label %bb35
bb35:
  %t210 = load ptr, ptr %lp11
  %t211 = getelementptr %"compiler/lower:lowering", ptr %t210, i32 0, i32 24
  call void @llvm.memmove.p0.p0.i64(ptr %t211, ptr %l106, i64 176, i1 false)
  br label %bb36
bb36:
  %t212 = load ptr, ptr %l0, !tbaa !29
  %t214 = getelementptr %"compiler/lower:Lowerer", ptr %t212, i32 0, i32 3
  %t215 = load ptr, ptr %t214, !tbaa !29
  %t217 = icmp eq ptr %t215, null
  %t219 = xor i1 %t217, true
  br i1 %t219, label %bb37, label %bb38
bb37:
  %t221 = load ptr, ptr %l0, !tbaa !29
  %t223 = getelementptr %"compiler/lower:Lowerer", ptr %t221, i32 0, i32 3
  %t224 = load ptr, ptr %t223, !tbaa !29
  %t226 = icmp eq ptr %t224, null
  br i1 %t226, label %bb39, label %bb40
bb38:
  store i1 false, ptr %l111, !tbaa !21
  br label %bb43
bb39:
  call void @__olang_check_failed(ptr @olang_loc_f8b3706059fec8c0_d163f284ba6a3ccc)
  unreachable
bb40:
  br label %bb41
bb41:
  %t228 = load ptr, ptr %l0, !tbaa !29
  %t230 = getelementptr %"compiler/lower:Lowerer", ptr %t228, i32 0, i32 3
  %t231 = load ptr, ptr %t230, !tbaa !29
  %t232 = load i64, ptr %l1, !tbaa !24
  %t235 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eFrees(ptr %v0, ptr %t231, i64 %t232)
  store i1 %t235, ptr %l118
  br label %bb42
bb42:
  %t236 = load i1, ptr %l118, !tbaa !21
  store i1 %t236, ptr %l111, !tbaa !21
  br label %bb43
bb43:
  %t237 = load i1, ptr %l111, !tbaa !21
  %t238 = load ptr, ptr %lp11
  %t239 = getelementptr %"compiler/lower:lowering", ptr %t238, i32 0, i32 25
  store i1 %t237, ptr %t239, !tbaa !21
  %t240 = load ptr, ptr %lp11
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2erun(ptr %v1, ptr %t240)
  br label %bb44
bb44:
  %t242 = load ptr, ptr %l0, !tbaa !29
  %t243 = load ptr, ptr %lp11
  %t244 = getelementptr %"compiler/lower:lowering", ptr %t243, i32 0, i32 8
  %t245 = load i1, ptr %t244, !tbaa !21
  %t248 = getelementptr %"compiler/lower:Lowerer", ptr %t242, i32 0, i32 5
  store i1 %t245, ptr %t248, !tbaa !21
  %t249 = load ptr, ptr %lp11
  %t250 = getelementptr %"compiler/lower:lowering", ptr %t249, i32 0, i32 3
  call void @llvm.memmove.p0.p0.i64(ptr %l122, ptr %t250, i64 800, i1 false)
  call void @olang_2eHelperKind_2eCopy_2ecompiler_2fmir_3aFn(ptr %t251, ptr %v1, ptr %l122)
  call void @llvm.memmove.p0.p0.i64(ptr %l124, ptr %t251, i64 800, i1 false)
  br label %bb45
bb45:
  call void @llvm.memmove.p0.p0.i64(ptr %l122, ptr %l124, i64 800, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l122, i64 800, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3aLowerer_2eallFresh(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/typed:LocalUses"
  %l3 = alloca ptr
  %l4 = alloca i64
  %l9 = alloca i1
  %l11 = alloca ptr
  %l13 = alloca ptr
  %l16 = alloca i32
  %l17 = alloca i1
  %l24 = alloca %"compiler/typed:LocalUses"
  %l26 = alloca i64
  %l28 = alloca i64
  %l33 = alloca ptr
  %l38 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  %t36 = alloca %"compiler/typed:LocalUses", align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Body", ptr %t1, i32 0, i32 11
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = icmp eq ptr %t4, null
  br i1 %t6, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb7
bb2:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = call ptr @compiler_2flower_2ecompiler_2flower_3aLowerer_2eT(ptr %v0, ptr %v0, ptr %t8)
  store ptr %t10, ptr %l11
  br label %bb3
bb3:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = call ptr @compiler_2flower_2ecompiler_2flower_3aLowerer_2eT(ptr %v0, ptr %v0, ptr %t11)
  store ptr %t13, ptr %l13
  br label %bb4
bb4:
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t16 = getelementptr %"compiler/typed:Body", ptr %t14, i32 0, i32 2
  %t17 = load i32, ptr %t16, !tbaa !23
  %t18 = load ptr, ptr %l13, !tbaa !29
  %t20 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t18, i32 %t17)
  store i32 %t20, ptr %l16
  br label %bb5
bb5:
  %t21 = load ptr, ptr %l11, !tbaa !29
  %t22 = load i32, ptr %l16, !tbaa !23
  %t23 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t21, i32 %t22)
  store i1 %t23, ptr %l17
  br label %bb6
bb6:
  %t24 = load i1, ptr %l17, !tbaa !21
  %t25 = xor i1 %t24, true
  store i1 %t25, ptr %l9, !tbaa !21
  br label %bb7
bb7:
  %t27 = load i1, ptr %l9, !tbaa !21
  br i1 %t27, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/lower:Lowerer", ptr %t29, i32 0, i32 0
  %t32 = load ptr, ptr %t31, !tbaa !29
  %t34 = getelementptr %"compiler/generic:Program", ptr %t32, i32 0, i32 2
  %t35 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2ftyped_2eLocalUses_2eUses(ptr %t36, ptr %v0, ptr %v1, ptr %s0, ptr %t34, ptr %t35)
  call void @llvm.memmove.p0.p0.i64(ptr %l24, ptr %t36, i64 704, i1 false)
  br label %bb11
bb11:
  call void @llvm.memmove.p0.p0.i64(ptr %l2, ptr %l24, i64 704, i1 false)
  %t39 = getelementptr %"compiler/typed:LocalUses", ptr %l2, i32 0, i32 18
  store ptr %t39, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  br label %bb12
bb12:
  %t41 = load i64, ptr %l4, !tbaa !24
  store i64 %t41, ptr %l26, !tbaa !24
  %t42 = load ptr, ptr %l3, !tbaa !29
  %t44 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %s0, ptr %t42)
  store i64 %t44, ptr %l28
  br label %bb13
bb13:
  %t45 = load i64, ptr %l26, !tbaa !24
  %t46 = load i64, ptr %l28, !tbaa !24
  %t47 = icmp slt i64 %t45, %t46
  %t49 = xor i1 %t47, true
  br i1 %t49, label %bb14, label %bb15
bb14:
  br label %bb23
bb15:
  br label %bb16
bb16:
  %t51 = load ptr, ptr %l3, !tbaa !29
  %t52 = load i64, ptr %l4, !tbaa !24
  %t55 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %s0, ptr %s0, ptr %t51, i64 %t52)
  store ptr %t55, ptr %l33
  br label %bb17
bb17:
  %t56 = load ptr, ptr %l33, !tbaa !29
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t58 = load ptr, ptr %l1, !tbaa !29
  %t64 = call i1 @compiler_2flower_2ecompiler_2flower_3aLowerer_2efreshRet(ptr %v0, ptr %v1, ptr %s0, ptr %s0, ptr %t57, ptr %t58, ptr %l2, ptr %t56)
  store i1 %t64, ptr %l38
  br label %bb18
bb18:
  %t65 = load i1, ptr %l38, !tbaa !21
  %t66 = xor i1 %t65, true
  br i1 %t66, label %bb19, label %bb20
bb19:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  br label %bb22
bb22:
  %t69 = load i64, ptr %l4, !tbaa !24
  %t71 = add i64 %t69, 1
  store i64 %t71, ptr %l4, !tbaa !24
  br label %bb12
bb23:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2flower_2ecompiler_2flower_3aLowerer_2eerrQualifier(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l7 = alloca i64
  %l13 = alloca ptr
  %l22 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:Lowerer", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t10 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %t6, i32 %a1)
  store i64 %t10, ptr %l7
  br label %bb1
bb1:
  %t11 = load i64, ptr %l7, !tbaa !24
  store i64 %t11, ptr %l2, !tbaa !24
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/lower:Lowerer", ptr %t12, i32 0, i32 0
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t17 = getelementptr %"compiler/generic:Program", ptr %t15, i32 0, i32 0
  %t18 = load ptr, ptr %t17, !tbaa !29
  %t20 = getelementptr %"compiler/load:Loader", ptr %t18, i32 0, i32 10
  %t21 = load i64, ptr %l2, !tbaa !24
  %t24 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t20, i64 %t21)
  store ptr %t24, ptr %l13
  br label %bb2
bb2:
  %t25 = load ptr, ptr %l13, !tbaa !29
  %t27 = getelementptr %"compiler/load:Module", ptr %t25, i32 0, i32 2
  %t28 = load { i64, ptr }, ptr %t27, !tbaa !27
  %t29 = load i64, ptr %l2, !tbaa !24
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/lower:Lowerer", ptr %t30, i32 0, i32 0
  %t33 = load ptr, ptr %t32, !tbaa !29
  %t35 = getelementptr %"compiler/generic:Program", ptr %t33, i32 0, i32 0
  %t36 = load ptr, ptr %t35, !tbaa !29
  %t38 = getelementptr %"compiler/load:Loader", ptr %t36, i32 0, i32 12
  %t39 = load i64, ptr %t38, !tbaa !24
  %t42 = icmp eq i64 %t29, %t39
  %t45 = call { i64, ptr } @compiler_2fload_2eErrQualifier(ptr %v0, ptr %v1, { i64, ptr } %t28, i1 %t42)
  store { i64, ptr } %t45, ptr %l22
  br label %bb3
bb3:
  %t46 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t46, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3aLowerer_2efreshMade(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca { i64, ptr }
  %l7 = alloca ptr
  %l8 = alloca i1
  %l9 = alloca ptr
  %l10 = alloca i1
  %l19 = alloca ptr
  %l20 = alloca i1
  %l23 = alloca ptr
  %l24 = alloca i1
  %l27 = alloca ptr
  %l28 = alloca i1
  %l31 = alloca ptr
  %l32 = alloca i1
  %l40 = alloca ptr
  %l41 = alloca i1
  %l44 = alloca i1
  %l46 = alloca ptr
  %l48 = alloca i1
  %l50 = alloca ptr
  %l51 = alloca i1
  %l60 = alloca i1
  %l64 = alloca i1
  %l66 = alloca { i64, ptr }
  %l68 = alloca i1
  %l69 = alloca ptr
  %l70 = alloca i1
  %l77 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l9, !tbaa !29
  store i1 false, ptr %l10, !tbaa !21
  %t2 = load ptr, ptr %l9, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l9, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 7
  store i1 %t8, ptr %l10, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l10, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load ptr, ptr %l2, !tbaa !29
  %t18 = getelementptr %"compiler/typed:Make", ptr %t16, i32 0, i32 0
  %t19 = load i32, ptr %t18, !range !{i32 0, i32 5}
  %t21 = trunc i64 0 to i32
  %t22 = icmp eq i32 %t19, %t21
  %t24 = xor i1 %t22, true
  store i1 %t24, ptr %l8, !tbaa !21
  br label %bb58
bb6:
  %t26 = load ptr, ptr %l1, !tbaa !29
  store ptr %t26, ptr %l19, !tbaa !29
  store i1 false, ptr %l20, !tbaa !21
  %t27 = load ptr, ptr %l19, !tbaa !29
  %t28 = icmp ne ptr %t27, null
  br i1 %t28, label %bb7, label %bb8
bb7:
  %t30 = load ptr, ptr %l19, !tbaa !29
  %t31 = load i64, ptr %t30, !range !{i64 0, i64 18}
  %t33 = icmp eq i64 %t31, 8
  store i1 %t33, ptr %l20, !tbaa !21
  br label %bb8
bb8:
  %t34 = load i1, ptr %l20, !tbaa !21
  br i1 %t34, label %bb9, label %bb10
bb9:
  br label %bb19
bb10:
  %t35 = load ptr, ptr %l1, !tbaa !29
  store ptr %t35, ptr %l23, !tbaa !29
  store i1 false, ptr %l24, !tbaa !21
  %t36 = load ptr, ptr %l23, !tbaa !29
  %t37 = icmp ne ptr %t36, null
  br i1 %t37, label %bb11, label %bb12
bb11:
  %t39 = load ptr, ptr %l23, !tbaa !29
  %t40 = load i64, ptr %t39, !range !{i64 0, i64 18}
  %t42 = icmp eq i64 %t40, 16
  store i1 %t42, ptr %l24, !tbaa !21
  br label %bb12
bb12:
  %t43 = load i1, ptr %l24, !tbaa !21
  br i1 %t43, label %bb13, label %bb14
bb13:
  br label %bb19
bb14:
  %t44 = load ptr, ptr %l1, !tbaa !29
  store ptr %t44, ptr %l27, !tbaa !29
  store i1 false, ptr %l28, !tbaa !21
  %t45 = load ptr, ptr %l27, !tbaa !29
  %t46 = icmp ne ptr %t45, null
  br i1 %t46, label %bb15, label %bb16
bb15:
  %t48 = load ptr, ptr %l27, !tbaa !29
  %t49 = load i64, ptr %t48, !range !{i64 0, i64 18}
  %t51 = icmp eq i64 %t49, 0
  store i1 %t51, ptr %l28, !tbaa !21
  br label %bb16
bb16:
  %t52 = load i1, ptr %l28, !tbaa !21
  br i1 %t52, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb58
bb20:
  %t53 = load ptr, ptr %l1, !tbaa !29
  store ptr %t53, ptr %l31, !tbaa !29
  store i1 false, ptr %l32, !tbaa !21
  %t54 = load ptr, ptr %l31, !tbaa !29
  %t55 = icmp ne ptr %t54, null
  br i1 %t55, label %bb21, label %bb22
bb21:
  %t57 = load ptr, ptr %l31, !tbaa !29
  %t58 = load i64, ptr %t57, !range !{i64 0, i64 18}
  %t60 = icmp eq i64 %t58, 6
  store i1 %t60, ptr %l32, !tbaa !21
  br label %bb22
bb22:
  %t61 = load i1, ptr %l32, !tbaa !21
  br i1 %t61, label %bb23, label %bb24
bb23:
  %t62 = load ptr, ptr %l1, !tbaa !29
  %t64 = getelementptr { i64, [5 x i64] }, ptr %t62, i32 0, i32 1
  %t65 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t64, i32 0, i32 1
  %t66 = load i32, ptr %t65
  store i32 %t66, ptr %l3, !tbaa !23
  %t68 = load ptr, ptr %l1, !tbaa !29
  %t70 = getelementptr { i64, [5 x i64] }, ptr %t68, i32 0, i32 1
  %t71 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t70, i32 0, i32 2
  %t72 = load ptr, ptr %t71
  store ptr %t72, ptr %l4, !tbaa !29
  br label %bb25
bb24:
  br label %bb33
bb25:
  %t74 = load ptr, ptr %l4, !tbaa !29
  %t76 = getelementptr %"compiler/typed:Call", ptr %t74, i32 0, i32 0
  %t77 = load ptr, ptr %t76, !tbaa !29
  store ptr %t77, ptr %l40, !tbaa !29
  store i1 false, ptr %l41, !tbaa !21
  %t78 = load ptr, ptr %l40, !tbaa !29
  %t79 = icmp ne ptr %t78, null
  br i1 %t79, label %bb26, label %bb27
bb26:
  %t81 = load ptr, ptr %l40, !tbaa !29
  %t82 = load i64, ptr %t81, !range !{i64 0, i64 5}
  %t84 = icmp eq i64 %t82, 0
  store i1 %t84, ptr %l41, !tbaa !21
  br label %bb27
bb27:
  %t85 = load i1, ptr %l41, !tbaa !21
  br i1 %t85, label %bb28, label %bb29
bb28:
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t88 = call ptr @compiler_2flower_2ecompiler_2flower_3aLowerer_2eT(ptr %v0, ptr %v0, ptr %t86)
  store ptr %t88, ptr %l46
  br label %bb30
bb29:
  store i1 false, ptr %l44, !tbaa !21
  br label %bb32
bb30:
  %t89 = load i32, ptr %l3, !tbaa !23
  %t90 = load ptr, ptr %l46, !tbaa !29
  %t92 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t90, i32 %t89)
  store i1 %t92, ptr %l48
  br label %bb31
bb31:
  %t93 = load i1, ptr %l48, !tbaa !21
  %t94 = xor i1 %t93, true
  store i1 %t94, ptr %l44, !tbaa !21
  br label %bb32
bb32:
  %t96 = load i1, ptr %l44, !tbaa !21
  store i1 %t96, ptr %l8, !tbaa !21
  br label %bb58
bb33:
  %t97 = load ptr, ptr %l1, !tbaa !29
  store ptr %t97, ptr %l50, !tbaa !29
  store i1 false, ptr %l51, !tbaa !21
  %t98 = load ptr, ptr %l50, !tbaa !29
  %t99 = icmp ne ptr %t98, null
  br i1 %t99, label %bb34, label %bb35
bb34:
  %t101 = load ptr, ptr %l50, !tbaa !29
  %t102 = load i64, ptr %t101, !range !{i64 0, i64 18}
  %t104 = icmp eq i64 %t102, 9
  store i1 %t104, ptr %l51, !tbaa !21
  br label %bb35
bb35:
  %t105 = load i1, ptr %l51, !tbaa !21
  br i1 %t105, label %bb36, label %bb37
bb36:
  %t106 = load ptr, ptr %l1, !tbaa !29
  %t108 = getelementptr { i64, [5 x i64] }, ptr %t106, i32 0, i32 1
  %t109 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t108, i32 0, i32 2
  %t110 = load i32, ptr %t109, !range !{i32 0, i32 49}
  store i32 %t110, ptr %l5
  %t112 = load ptr, ptr %l1, !tbaa !29
  %t114 = getelementptr { i64, [5 x i64] }, ptr %t112, i32 0, i32 1
  %t115 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t114, i32 0, i32 4
  %t116 = load { i64, ptr }, ptr %t115
  store { i64, ptr } %t116, ptr %l6, !tbaa !27
  br label %bb38
bb37:
  br label %bb46
bb38:
  %t118 = load i32, ptr %l5, !range !{i32 0, i32 49}
  %t120 = trunc i64 20 to i32
  %t121 = icmp eq i32 %t118, %t120
  br i1 %t121, label %bb39, label %bb40
bb39:
  %t123 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t125 = extractvalue { i64, ptr } %t123, 0
  %t127 = icmp eq i64 %t125, 1
  store i1 %t127, ptr %l60, !tbaa !21
  br label %bb41
bb40:
  store i1 false, ptr %l60, !tbaa !21
  br label %bb41
bb41:
  %t129 = load i1, ptr %l60, !tbaa !21
  br i1 %t129, label %bb42, label %bb43
bb42:
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t131 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t131, ptr %l66, !tbaa !27
  %t132 = getelementptr { i64, ptr }, ptr %l66, i32 0, i32 1
  %t133 = load ptr, ptr %t132, !tbaa !27
  %t134 = getelementptr ptr, ptr %t133, i64 0
  %t135 = load ptr, ptr %t134, !tbaa !39
  %t138 = call i1 @compiler_2flower_2ecompiler_2flower_3aLowerer_2efreshMade(ptr %v0, ptr %v1, ptr %t130, ptr %t135)
  store i1 %t138, ptr %l68
  br label %bb44
bb43:
  store i1 false, ptr %l64, !tbaa !21
  br label %bb45
bb44:
  %t139 = load i1, ptr %l68, !tbaa !21
  store i1 %t139, ptr %l64, !tbaa !21
  br label %bb45
bb45:
  %t140 = load i1, ptr %l64, !tbaa !21
  store i1 %t140, ptr %l8, !tbaa !21
  br label %bb58
bb46:
  %t141 = load ptr, ptr %l1, !tbaa !29
  store ptr %t141, ptr %l69, !tbaa !29
  store i1 false, ptr %l70, !tbaa !21
  %t142 = load ptr, ptr %l69, !tbaa !29
  %t143 = icmp ne ptr %t142, null
  br i1 %t143, label %bb47, label %bb48
bb47:
  %t145 = load ptr, ptr %l69, !tbaa !29
  %t146 = load i64, ptr %t145, !range !{i64 0, i64 18}
  %t148 = icmp eq i64 %t146, 17
  store i1 %t148, ptr %l70, !tbaa !21
  br label %bb48
bb48:
  %t149 = load i1, ptr %l70, !tbaa !21
  br i1 %t149, label %bb49, label %bb50
bb49:
  %t150 = load ptr, ptr %l1, !tbaa !29
  %t152 = getelementptr { i64, [5 x i64] }, ptr %t150, i32 0, i32 1
  %t153 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t152, i32 0, i32 2
  %t154 = load ptr, ptr %t153
  store ptr %t154, ptr %l7, !tbaa !29
  br label %bb51
bb50:
  br label %bb53
bb51:
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t157 = load ptr, ptr %l7, !tbaa !29
  %t160 = call i1 @compiler_2flower_2ecompiler_2flower_3aLowerer_2efreshMade(ptr %v0, ptr %v1, ptr %t156, ptr %t157)
  store i1 %t160, ptr %l77
  br label %bb52
bb52:
  %t161 = load i1, ptr %l77, !tbaa !21
  store i1 %t161, ptr %l8, !tbaa !21
  br label %bb58
bb53:
  br i1 true, label %bb54, label %bb55
bb54:
  br label %bb56
bb55:
  br label %bb57
bb56:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb58
bb57:
  call void @__olang_check_failed(ptr @olang_loc_fdef55e2919415e3_7c40141ab4e8627)
  unreachable
bb58:
  %t162 = load i1, ptr %l8, !tbaa !21
  store i1 %t162, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3aLowerer_2efreshParam(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i1
  %l8 = alloca i1
  %l9 = alloca i64
  %l12 = alloca i64
  %l14 = alloca i1
  %l25 = alloca i1
  %l29 = alloca i1
  %l30 = alloca i32
  %l34 = alloca ptr
  %l38 = alloca ptr
  %l40 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb4
bb2:
  %t5 = load i64, ptr %l1, !tbaa !24
  store i64 %t5, ptr %l9, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/lower:Lowerer", ptr %t6, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t11 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %t9)
  store i64 %t11, ptr %l12
  br label %bb3
bb3:
  %t12 = load i64, ptr %l9, !tbaa !24
  %t13 = load i64, ptr %l12, !tbaa !24
  %t14 = icmp sge i64 %t12, %t13
  store i1 %t14, ptr %l8, !tbaa !21
  br label %bb4
bb4:
  %t16 = load i1, ptr %l8, !tbaa !21
  br i1 %t16, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l14, !tbaa !21
  br label %bb7
bb6:
  %t17 = load i64, ptr %l2, !tbaa !24
  %t19 = icmp sge i64 %t17, 64
  store i1 %t19, ptr %l14, !tbaa !21
  br label %bb7
bb7:
  %t21 = load i1, ptr %l14, !tbaa !21
  br i1 %t21, label %bb8, label %bb9
bb8:
  store i1 false, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t23 = shl i64 1, 40
  %t25 = sub i64 0, %t23
  %t26 = load i64, ptr %l1, !tbaa !24
  %t28 = mul i64 %t26, 64
  %t29 = load i64, ptr %l2, !tbaa !24
  %t32 = add i64 %t28, %t29
  %t35 = sub i64 %t25, %t32
  store i64 %t35, ptr %l3, !tbaa !24
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/lower:Lowerer", ptr %t37, i32 0, i32 27
  %t40 = load i64, ptr %l3, !tbaa !24
  %t43 = call { i32, i1 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eGet_3cI64_2c_20Bool_3e(ptr %v0, ptr %t39, i64 %t40)
  %t44 = extractvalue { i32, i1 } %t43, 1
  %t45 = extractvalue { i32, i1 } %t43, 0
  store i32 %t45, ptr %l30
  %t46 = icmp ne i32 %t45, 0
  br i1 %t46, label %bb12, label %ok.47, !prof !99
ok.47:
  store i1 %t44, ptr %l29
  br label %bb11
bb11:
  %t48 = load i1, ptr %l29, !tbaa !21
  store i1 %t48, ptr %l25, !tbaa !21
  br label %bb18
bb12:
  br label %bb13
bb13:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/lower:Lowerer", ptr %t49, i32 0, i32 27
  %t52 = load i64, ptr %l3, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t51, i64 %t52, i1 false)
  br label %bb14
bb14:
  %t55 = load ptr, ptr %l0, !tbaa !29
  store ptr %t55, ptr %l34, !tbaa !29
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/lower:Lowerer", ptr %t56, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !29
  %t60 = load i64, ptr %l1, !tbaa !24
  %t63 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t59, i64 %t60)
  store ptr %t63, ptr %l38
  br label %bb15
bb15:
  %t64 = load i64, ptr %l2, !tbaa !24
  %t65 = load ptr, ptr %l34, !tbaa !29
  %t66 = load ptr, ptr %l38, !tbaa !29
  %t68 = call i1 @compiler_2flower_2ecompiler_2flower_3aLowerer_2ekeepsNothing(ptr %v0, ptr %v0, ptr %t65, ptr %t66, i64 %t64)
  store i1 %t68, ptr %l40
  br label %bb16
bb16:
  %t69 = load i1, ptr %l40, !tbaa !21
  store i1 %t69, ptr %l4, !tbaa !21
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/lower:Lowerer", ptr %t70, i32 0, i32 27
  %t73 = load i64, ptr %l3, !tbaa !24
  %t74 = load i1, ptr %l4, !tbaa !21
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t72, i64 %t73, i1 %t74)
  br label %bb17
bb17:
  %t78 = load i1, ptr %l4, !tbaa !21
  store i1 %t78, ptr %rv
  br label %ret
bb18:
  %t80 = load i1, ptr %l25, !tbaa !21
  store i1 %t80, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3aLowerer_2efreshResult(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i1
  %l7 = alloca i1
  %l8 = alloca i64
  %l11 = alloca i64
  %l16 = alloca i1
  %l20 = alloca i1
  %l21 = alloca i32
  %l25 = alloca ptr
  %l29 = alloca ptr
  %l30 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb4
bb2:
  %t5 = load i64, ptr %l1, !tbaa !24
  store i64 %t5, ptr %l8, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/lower:Lowerer", ptr %t6, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t11 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %t9)
  store i64 %t11, ptr %l11
  br label %bb3
bb3:
  %t12 = load i64, ptr %l8, !tbaa !24
  %t13 = load i64, ptr %l11, !tbaa !24
  %t14 = icmp sge i64 %t12, %t13
  store i1 %t14, ptr %l7, !tbaa !21
  br label %bb4
bb4:
  %t16 = load i1, ptr %l7, !tbaa !21
  br i1 %t16, label %bb5, label %bb6
bb5:
  store i1 false, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t18 = load i64, ptr %l1, !tbaa !24
  %t20 = sub i64 -1, %t18
  store i64 %t20, ptr %l2, !tbaa !24
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/lower:Lowerer", ptr %t22, i32 0, i32 27
  %t25 = load i64, ptr %l2, !tbaa !24
  %t28 = call { i32, i1 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eGet_3cI64_2c_20Bool_3e(ptr %v0, ptr %t24, i64 %t25)
  %t29 = extractvalue { i32, i1 } %t28, 1
  %t30 = extractvalue { i32, i1 } %t28, 0
  store i32 %t30, ptr %l21
  %t31 = icmp ne i32 %t30, 0
  br i1 %t31, label %bb9, label %ok.32, !prof !99
ok.32:
  store i1 %t29, ptr %l20
  br label %bb8
bb8:
  %t33 = load i1, ptr %l20, !tbaa !21
  store i1 %t33, ptr %l16, !tbaa !21
  br label %bb15
bb9:
  br label %bb10
bb10:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/lower:Lowerer", ptr %t34, i32 0, i32 27
  %t37 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t36, i64 %t37, i1 false)
  br label %bb11
bb11:
  %t40 = load ptr, ptr %l0, !tbaa !29
  store ptr %t40, ptr %l25, !tbaa !29
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/lower:Lowerer", ptr %t41, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !29
  %t45 = load i64, ptr %l1, !tbaa !24
  %t48 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t44, i64 %t45)
  store ptr %t48, ptr %l29
  br label %bb12
bb12:
  %t49 = load ptr, ptr %l25, !tbaa !29
  %t50 = load ptr, ptr %l29, !tbaa !29
  %t51 = call i1 @compiler_2flower_2ecompiler_2flower_3aLowerer_2eallFresh(ptr %v0, ptr %v0, ptr %t49, ptr %t50)
  store i1 %t51, ptr %l30
  br label %bb13
bb13:
  %t52 = load i1, ptr %l30, !tbaa !21
  store i1 %t52, ptr %l3, !tbaa !21
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/lower:Lowerer", ptr %t53, i32 0, i32 27
  %t56 = load i64, ptr %l2, !tbaa !24
  %t57 = load i1, ptr %l3, !tbaa !21
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t55, i64 %t56, i1 %t57)
  br label %bb14
bb14:
  %t61 = load i1, ptr %l3, !tbaa !21
  store i1 %t61, ptr %rv
  br label %ret
bb15:
  %t63 = load i1, ptr %l16, !tbaa !21
  store i1 %t63, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3aLowerer_2epreserves(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i1
  %l8 = alloca i1
  %l9 = alloca i64
  %l12 = alloca i64
  %l14 = alloca i1
  %l22 = alloca i1
  %l26 = alloca i1
  %l27 = alloca i32
  %l31 = alloca ptr
  %l35 = alloca ptr
  %l37 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb4
bb2:
  %t5 = load i64, ptr %l1, !tbaa !24
  store i64 %t5, ptr %l9, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/lower:Lowerer", ptr %t6, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t11 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %t9)
  store i64 %t11, ptr %l12
  br label %bb3
bb3:
  %t12 = load i64, ptr %l9, !tbaa !24
  %t13 = load i64, ptr %l12, !tbaa !24
  %t14 = icmp sge i64 %t12, %t13
  store i1 %t14, ptr %l8, !tbaa !21
  br label %bb4
bb4:
  %t16 = load i1, ptr %l8, !tbaa !21
  br i1 %t16, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l14, !tbaa !21
  br label %bb7
bb6:
  %t17 = load i64, ptr %l2, !tbaa !24
  %t19 = icmp sge i64 %t17, 64
  store i1 %t19, ptr %l14, !tbaa !21
  br label %bb7
bb7:
  %t21 = load i1, ptr %l14, !tbaa !21
  br i1 %t21, label %bb8, label %bb9
bb8:
  store i1 false, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t23 = load i64, ptr %l1, !tbaa !24
  %t25 = mul i64 %t23, 64
  %t26 = load i64, ptr %l2, !tbaa !24
  %t29 = add i64 %t25, %t26
  store i64 %t29, ptr %l3, !tbaa !24
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/lower:Lowerer", ptr %t31, i32 0, i32 27
  %t34 = load i64, ptr %l3, !tbaa !24
  %t37 = call { i32, i1 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eGet_3cI64_2c_20Bool_3e(ptr %v0, ptr %t33, i64 %t34)
  %t38 = extractvalue { i32, i1 } %t37, 1
  %t39 = extractvalue { i32, i1 } %t37, 0
  store i32 %t39, ptr %l27
  %t40 = icmp ne i32 %t39, 0
  br i1 %t40, label %bb12, label %ok.41, !prof !99
ok.41:
  store i1 %t38, ptr %l26
  br label %bb11
bb11:
  %t42 = load i1, ptr %l26, !tbaa !21
  store i1 %t42, ptr %l22, !tbaa !21
  br label %bb18
bb12:
  br label %bb13
bb13:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/lower:Lowerer", ptr %t43, i32 0, i32 27
  %t46 = load i64, ptr %l3, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t45, i64 %t46, i1 false)
  br label %bb14
bb14:
  %t49 = load ptr, ptr %l0, !tbaa !29
  store ptr %t49, ptr %l31, !tbaa !29
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/lower:Lowerer", ptr %t50, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !29
  %t54 = load i64, ptr %l1, !tbaa !24
  %t57 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t53, i64 %t54)
  store ptr %t57, ptr %l35
  br label %bb15
bb15:
  %t58 = load i64, ptr %l2, !tbaa !24
  %t59 = load ptr, ptr %l31, !tbaa !29
  %t60 = load ptr, ptr %l35, !tbaa !29
  %t62 = call i1 @compiler_2flower_2ecompiler_2flower_3aLowerer_2ekeepsParts(ptr %v0, ptr %v0, ptr %t59, ptr %t60, i64 %t58)
  store i1 %t62, ptr %l37
  br label %bb16
bb16:
  %t63 = load i1, ptr %l37, !tbaa !21
  store i1 %t63, ptr %l4, !tbaa !21
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/lower:Lowerer", ptr %t64, i32 0, i32 27
  %t67 = load i64, ptr %l3, !tbaa !24
  %t68 = load i1, ptr %l4, !tbaa !21
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t66, i64 %t67, i1 %t68)
  br label %bb17
bb17:
  %t72 = load i1, ptr %l4, !tbaa !21
  store i1 %t72, ptr %rv
  br label %ret
bb18:
  %t74 = load i1, ptr %l22, !tbaa !21
  store i1 %t74, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eanyMake(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i32 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca ptr
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca i32
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca %"compiler/source:Span"
  %l11 = alloca i32
  %l13 = alloca %"compiler/source:Span"
  %l14 = alloca i32
  %l16 = alloca %"compiler/source:Span"
  %l17 = alloca i32
  %l19 = alloca %"compiler/source:Span"
  %l20 = alloca i32
  %l21 = alloca ptr
  %l22 = alloca { i64, [1 x i64] }
  %l23 = alloca ptr
  %l24 = alloca { i64, [4 x i64] }
  %l27 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  %l30 = alloca ptr
  %l31 = alloca i1
  %l43 = alloca ptr
  %l44 = alloca i1
  %l47 = alloca i1
  %l58 = alloca i1
  %l70 = alloca i1
  %l77 = alloca ptr
  %l80 = alloca { i64, ptr }
  %l82 = alloca i32
  %l83 = alloca i1
  %l93 = alloca { i64, [1 x i64] }
  %l96 = alloca { i64, ptr }
  %l101 = alloca { i64, [4 x i64] }
  %l109 = alloca i1
  %l111 = alloca ptr
  %l112 = alloca { i64, [4 x i64] }
  %l114 = alloca i32
  %l117 = alloca { i64, [4 x i64] }
  %l118 = alloca ptr
  %l119 = alloca i32
  %l120 = alloca i32
  %l124 = alloca { i64, ptr }
  %l125 = alloca %"compiler/mir:Range"
  %l128 = alloca { i64, [4 x i64] }
  %l136 = alloca { i64, [4 x i64] }
  %l137 = alloca ptr
  %l138 = alloca i32
  %l139 = alloca i32
  %l140 = alloca { i64, [4 x i64] }
  %l142 = alloca { i64, ptr }
  %l145 = alloca { i64, [4 x i64] }
  %l146 = alloca { i64, ptr }
  %l148 = alloca { i64, [4 x i64] }
  %l151 = alloca { i64, ptr }
  %l160 = alloca { i64, [4 x i64] }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i64, [4 x i64] }
  %t191 = alloca { i64, [4 x i64] }, align 8
  %t239 = alloca { i64, [15 x i64] }, align 8
  %t260 = alloca { i64, [15 x i64] }, align 8
  %t321 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store i32 %a2, ptr %l2
  store %"compiler/source:Span" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t1, ptr %l28, !tbaa !27
  %t2 = getelementptr { i64, ptr }, ptr %l28, i32 0, i32 1
  %t3 = load ptr, ptr %t2, !tbaa !27
  %t4 = getelementptr ptr, ptr %t3, i64 0
  %t5 = load ptr, ptr %t4, !tbaa !39
  store ptr %t5, ptr %l4, !tbaa !29
  %t7 = load ptr, ptr %l4, !tbaa !29
  store ptr %t7, ptr %l30, !tbaa !29
  store i1 false, ptr %l31, !tbaa !21
  %t8 = load ptr, ptr %l30, !tbaa !29
  %t9 = icmp ne ptr %t8, null
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = load ptr, ptr %l30, !tbaa !29
  %t12 = load i64, ptr %t11, !range !{i64 0, i64 18}
  %t14 = icmp eq i64 %t12, 5
  store i1 %t14, ptr %l31, !tbaa !21
  br label %bb2
bb2:
  %t15 = load i1, ptr %l31, !tbaa !21
  br i1 %t15, label %bb3, label %bb4
bb3:
  %t16 = load ptr, ptr %l4, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t18, i32 0, i32 0
  %t20 = load %"compiler/source:Span", ptr %t19
  store %"compiler/source:Span" %t20, ptr %l5
  %t22 = load ptr, ptr %l4, !tbaa !29
  %t24 = getelementptr { i64, [5 x i64] }, ptr %t22, i32 0, i32 1
  %t25 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t24, i32 0, i32 1
  %t26 = load i32, ptr %t25
  store i32 %t26, ptr %l6, !tbaa !23
  %t28 = load ptr, ptr %l4, !tbaa !29
  %t30 = getelementptr { i64, [5 x i64] }, ptr %t28, i32 0, i32 1
  %t31 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t30, i32 0, i32 2
  %t32 = load ptr, ptr %t31
  store ptr %t32, ptr %l8, !tbaa !29
  %t36 = load ptr, ptr %l8, !tbaa !29
  %t38 = getelementptr %"compiler/typed:Promote", ptr %t36, i32 0, i32 0
  %t39 = load ptr, ptr %t38, !tbaa !29
  store ptr %t39, ptr %l9, !tbaa !29
  %t41 = load ptr, ptr %l9, !tbaa !29
  store ptr %t41, ptr %l43, !tbaa !29
  store i1 false, ptr %l44, !tbaa !21
  %t42 = load ptr, ptr %l43, !tbaa !29
  %t43 = icmp ne ptr %t42, null
  br i1 %t43, label %bb5, label %bb6
bb4:
  br label %bb37
bb5:
  %t45 = load ptr, ptr %l43, !tbaa !29
  %t46 = load i64, ptr %t45, !range !{i64 0, i64 18}
  %t48 = icmp eq i64 %t46, 7
  store i1 %t48, ptr %l44, !tbaa !21
  br label %bb6
bb6:
  %t49 = load i1, ptr %l44, !tbaa !21
  br i1 %t49, label %bb7, label %bb8
bb7:
  %t50 = load ptr, ptr %l9, !tbaa !29
  %t52 = getelementptr { i64, [5 x i64] }, ptr %t50, i32 0, i32 1
  %t53 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t52, i32 0, i32 0
  %t54 = load %"compiler/source:Span", ptr %t53
  store %"compiler/source:Span" %t54, ptr %l10
  %t56 = load ptr, ptr %l9, !tbaa !29
  %t58 = getelementptr { i64, [5 x i64] }, ptr %t56, i32 0, i32 1
  %t59 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t58, i32 0, i32 1
  %t60 = load i32, ptr %t59
  store i32 %t60, ptr %l11, !tbaa !23
  %t62 = load ptr, ptr %l9, !tbaa !29
  %t64 = getelementptr { i64, [5 x i64] }, ptr %t62, i32 0, i32 1
  %t65 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t64, i32 0, i32 2
  %t66 = load ptr, ptr %t65
  %t71 = getelementptr %"compiler/typed:Make", ptr %t66, i32 0, i32 0
  %t72 = load i32, ptr %t71, !range !{i32 0, i32 5}
  %t74 = trunc i64 0 to i32
  %t75 = icmp eq i32 %t72, %t74
  store i1 %t75, ptr %l47, !tbaa !21
  br label %bb9
bb8:
  store i1 false, ptr %l47, !tbaa !21
  br label %bb9
bb9:
  %t77 = load i1, ptr %l47, !tbaa !21
  br i1 %t77, label %bb10, label %bb11
bb10:
  %t78 = load ptr, ptr %l9, !tbaa !29
  %t80 = getelementptr { i64, [5 x i64] }, ptr %t78, i32 0, i32 1
  %t81 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t80, i32 0, i32 0
  %t82 = load %"compiler/source:Span", ptr %t81
  store %"compiler/source:Span" %t82, ptr %l13
  %t84 = load ptr, ptr %l9, !tbaa !29
  %t86 = getelementptr { i64, [5 x i64] }, ptr %t84, i32 0, i32 1
  %t87 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t86, i32 0, i32 1
  %t88 = load i32, ptr %t87
  store i32 %t88, ptr %l14, !tbaa !23
  %t90 = load ptr, ptr %l9, !tbaa !29
  %t92 = getelementptr { i64, [5 x i64] }, ptr %t90, i32 0, i32 1
  %t93 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t92, i32 0, i32 2
  %t94 = load ptr, ptr %t93
  %t99 = getelementptr %"compiler/typed:Make", ptr %t94, i32 0, i32 2
  %t100 = load { i64, ptr }, ptr %t99, !tbaa !27
  %t102 = extractvalue { i64, ptr } %t100, 0
  %t104 = icmp eq i64 %t102, 1
  store i1 %t104, ptr %l58, !tbaa !21
  br label %bb12
bb11:
  store i1 false, ptr %l58, !tbaa !21
  br label %bb12
bb12:
  %t106 = load i1, ptr %l58, !tbaa !21
  br i1 %t106, label %bb13, label %bb14
bb13:
  %t107 = load ptr, ptr %l9, !tbaa !29
  %t109 = getelementptr { i64, [5 x i64] }, ptr %t107, i32 0, i32 1
  %t110 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t109, i32 0, i32 0
  %t111 = load %"compiler/source:Span", ptr %t110
  store %"compiler/source:Span" %t111, ptr %l16
  %t113 = load ptr, ptr %l9, !tbaa !29
  %t115 = getelementptr { i64, [5 x i64] }, ptr %t113, i32 0, i32 1
  %t116 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t115, i32 0, i32 1
  %t117 = load i32, ptr %t116
  store i32 %t117, ptr %l17, !tbaa !23
  %t119 = load ptr, ptr %l9, !tbaa !29
  %t121 = getelementptr { i64, [5 x i64] }, ptr %t119, i32 0, i32 1
  %t122 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t121, i32 0, i32 2
  %t123 = load ptr, ptr %t122
  %t125 = load ptr, ptr %l0, !tbaa !29
  store ptr %t125, ptr %l77, !tbaa !29
  %t129 = getelementptr %"compiler/typed:Make", ptr %t123, i32 0, i32 2
  %t130 = load { i64, ptr }, ptr %t129, !tbaa !27
  store { i64, ptr } %t130, ptr %l80, !tbaa !27
  %t131 = getelementptr { i64, ptr }, ptr %l80, i32 0, i32 1
  %t132 = load ptr, ptr %t131, !tbaa !27
  %t133 = getelementptr ptr, ptr %t132, i64 0
  %t134 = load ptr, ptr %t133, !tbaa !39
  %t136 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t134)
  store i32 %t136, ptr %l82
  br label %bb15
bb14:
  store i1 false, ptr %l70, !tbaa !21
  br label %bb17
bb15:
  %t137 = load ptr, ptr %l77, !tbaa !29
  %t138 = load i32, ptr %l82, !tbaa !23
  %t139 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2evalueArray(ptr %v0, ptr %t137, i32 %t138)
  store i1 %t139, ptr %l83
  br label %bb16
bb16:
  %t140 = load i1, ptr %l83, !tbaa !21
  store i1 %t140, ptr %l70, !tbaa !21
  br label %bb17
bb17:
  %t141 = load i1, ptr %l70, !tbaa !21
  br i1 %t141, label %bb18, label %bb19
bb18:
  store %olang.scope zeroinitializer, ptr %s2
  %t142 = load ptr, ptr %l9, !tbaa !29
  %t144 = getelementptr { i64, [5 x i64] }, ptr %t142, i32 0, i32 1
  %t145 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t144, i32 0, i32 0
  %t146 = load %"compiler/source:Span", ptr %t145
  store %"compiler/source:Span" %t146, ptr %l19
  %t148 = load ptr, ptr %l9, !tbaa !29
  %t150 = getelementptr { i64, [5 x i64] }, ptr %t148, i32 0, i32 1
  %t151 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t150, i32 0, i32 1
  %t152 = load i32, ptr %t151
  store i32 %t152, ptr %l20, !tbaa !23
  %t154 = load ptr, ptr %l9, !tbaa !29
  %t156 = getelementptr { i64, [5 x i64] }, ptr %t154, i32 0, i32 1
  %t157 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t156, i32 0, i32 2
  %t158 = load ptr, ptr %t157
  store ptr %t158, ptr %l21, !tbaa !29
  %t160 = load ptr, ptr %l0, !tbaa !29
  %t161 = load ptr, ptr %l8, !tbaa !29
  %t163 = getelementptr %"compiler/typed:Promote", ptr %t161, i32 0, i32 1
  %t164 = load i32, ptr %t163, !tbaa !23
  %t167 = call { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ebuilt(ptr %v0, ptr %t160, i32 %t164)
  store { i64, [1 x i64] } %t167, ptr %l93
  br label %bb20
bb19:
  br label %bb36
bb20:
  %t168 = load { i64, [1 x i64] }, ptr %l93
  store { i64, [1 x i64] } %t168, ptr %l22
  %t169 = load ptr, ptr %l21, !tbaa !29
  %t172 = getelementptr %"compiler/typed:Make", ptr %t169, i32 0, i32 2
  %t173 = load { i64, ptr }, ptr %t172, !tbaa !27
  store { i64, ptr } %t173, ptr %l96, !tbaa !27
  %t174 = getelementptr { i64, ptr }, ptr %l96, i32 0, i32 1
  %t175 = load ptr, ptr %t174, !tbaa !27
  %t176 = getelementptr ptr, ptr %t175, i64 0
  %t177 = load ptr, ptr %t176, !tbaa !39
  store ptr %t177, ptr %l23, !tbaa !29
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t180 = load ptr, ptr %l23, !tbaa !29
  %t184 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v1, ptr %t179, ptr %t180)
  store { i64, [4 x i64] } %t184, ptr %l101
  br label %bb21
bb21:
  %t185 = load { i64, [4 x i64] }, ptr %l101
  store { i64, [4 x i64] } %t185, ptr %l24
  %t186 = load ptr, ptr %l0, !tbaa !29
  %t188 = getelementptr %"compiler/lower:lowering", ptr %t186, i32 0, i32 7
  %t189 = load i1, ptr %t188, !tbaa !21
  br i1 %t189, label %bb22, label %bb23
bb22:
  store { i64, [4 x i64] } zeroinitializer, ptr %t191
  %t192 = getelementptr { i64, [4 x i64] }, ptr %t191, i32 0, i32 0
  store i64 0, ptr %t192
  %t193 = load { i64, [4 x i64] }, ptr %t191
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  store { i64, [4 x i64] } %t193, ptr %rv
  br label %ret
bb23:
  br label %bb24
bb24:
  %t195 = load ptr, ptr %l0, !tbaa !29
  %t197 = getelementptr %"compiler/lower:lowering", ptr %t195, i32 0, i32 2
  %t198 = load ptr, ptr %t197, !tbaa !29
  %t199 = load ptr, ptr %l23, !tbaa !29
  %t203 = call i1 @compiler_2ftyped_2eAnyItemNew(ptr %v0, ptr %v1, ptr %t198, ptr %t199)
  store i1 %t203, ptr %l109
  br label %bb25
bb25:
  %t204 = load i1, ptr %l109, !tbaa !21
  %t205 = xor i1 %t204, true
  br i1 %t205, label %bb26, label %bb27
bb26:
  %t207 = load ptr, ptr %l0, !tbaa !29
  store ptr %t207, ptr %l111, !tbaa !29
  %t208 = load { i64, [4 x i64] }, ptr %l24
  store { i64, [4 x i64] } %t208, ptr %l112
  %t209 = load ptr, ptr %l23, !tbaa !29
  %t211 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t209)
  store i32 %t211, ptr %l114
  br label %bb28
bb27:
  br label %bb30
bb28:
  %t212 = load %"compiler/source:Span", ptr %l3
  %t213 = load { i64, [1 x i64] }, ptr %l22
  %t214 = load ptr, ptr %l111, !tbaa !29
  %t215 = load { i64, [4 x i64] }, ptr %l112
  %t216 = load i32, ptr %l114, !tbaa !23
  %t219 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2earrayCopy(ptr %v0, ptr %t214, { i64, [4 x i64] } %t215, i32 %t216, %"compiler/source:Span" %t212, { i64, [1 x i64] } %t213, i1 false)
  store { i64, [4 x i64] } %t219, ptr %l117
  br label %bb29
bb29:
  %t220 = load { i64, [4 x i64] }, ptr %l117
  store { i64, [4 x i64] } %t220, ptr %l24
  br label %bb30
bb30:
  %t221 = load ptr, ptr %l0, !tbaa !29
  store ptr %t221, ptr %l118, !tbaa !29
  %t222 = load i32, ptr %l20, !tbaa !23
  store i32 %t222, ptr %l119, !tbaa !23
  %t223 = load i32, ptr %l20, !tbaa !23
  store i32 %t223, ptr %l120, !tbaa !23
  %t224 = load ptr, ptr %l0, !tbaa !29
  %t226 = getelementptr %"compiler/lower:lowering", ptr %t224, i32 0, i32 3
  %t227 = load { i64, [4 x i64] }, ptr %l24
  %t228 = mul i64 1, 40
  %t229 = call ptr @__olang_scope_alloc_zeroed(ptr %s2, i64 %t228)
  %t230 = insertvalue { i64, ptr } undef, i64 1, 0
  %t231 = insertvalue { i64, ptr } %t230, ptr %t229, 1
  store { i64, ptr } %t231, ptr %l124, !tbaa !27
  %t233 = getelementptr { i64, ptr }, ptr %l124, i32 0, i32 1
  %t234 = load ptr, ptr %t233, !tbaa !27
  %t235 = getelementptr { i64, [4 x i64] }, ptr %t234, i64 0
  store { i64, [4 x i64] } %t227, ptr %t235
  %t237 = load { i64, ptr }, ptr %l124, !tbaa !27
  %t238 = call %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eArgs(ptr %v0, ptr %s2, ptr %t226, { i64, ptr } %t237)
  store %"compiler/mir:Range" %t238, ptr %l125
  br label %bb31
bb31:
  store { i64, [15 x i64] } zeroinitializer, ptr %t239
  %t240 = getelementptr { i64, [15 x i64] }, ptr %t239, i32 0, i32 0
  store i64 6, ptr %t240
  %t241 = load i32, ptr %l120, !tbaa !23
  %t242 = insertvalue { i32, i64, %"compiler/mir:Range" } undef, i32 %t241, 0
  %t243 = insertvalue { i32, i64, %"compiler/mir:Range" } %t242, i64 0, 1
  %t244 = load %"compiler/mir:Range", ptr %l125
  %t245 = insertvalue { i32, i64, %"compiler/mir:Range" } %t243, %"compiler/mir:Range" %t244, 2
  %t246 = getelementptr { i64, [15 x i64] }, ptr %t239, i32 0, i32 1
  store { i32, i64, %"compiler/mir:Range" } %t245, ptr %t246
  %t247 = load { i64, [15 x i64] }, ptr %t239
  %t248 = load %"compiler/source:Span", ptr %l19
  %t249 = load ptr, ptr %l118, !tbaa !29
  %t250 = load i32, ptr %l119, !tbaa !23
  %t253 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %t249, i32 %t250, { i64, [15 x i64] } %t247, %"compiler/source:Span" %t248)
  store { i64, [4 x i64] } %t253, ptr %l128
  br label %bb32
bb32:
  %t254 = load { i64, [4 x i64] }, ptr %l128
  %t255 = load ptr, ptr %l0, !tbaa !29
  %t256 = load i32, ptr %l6, !tbaa !23
  %t257 = load { i64, [1 x i64] }, ptr %l22
  %t259 = load i32, ptr %l6, !tbaa !23
  store { i64, [15 x i64] } zeroinitializer, ptr %t260
  %t261 = getelementptr { i64, [15 x i64] }, ptr %t260, i32 0, i32 0
  store i64 7, ptr %t261
  %t263 = insertvalue { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 } undef, { i64, [1 x i64] } %t257, 0
  %t265 = insertvalue { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 } %t263, { i64, [4 x i64] } %t254, 1
  %t267 = insertvalue { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 } %t265, i32 %t259, 2
  %t268 = getelementptr { i64, [15 x i64] }, ptr %t260, i32 0, i32 1
  store { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 } %t267, ptr %t268
  %t269 = load { i64, [15 x i64] }, ptr %t260
  %t270 = load %"compiler/source:Span", ptr %l3
  %t275 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %t255, i32 %t256, { i64, [15 x i64] } %t269, %"compiler/source:Span" %t270)
  store { i64, [4 x i64] } %t275, ptr %l136
  br label %bb33
bb33:
  %t276 = load { i64, [4 x i64] }, ptr %l136
  %t277 = load ptr, ptr %l0, !tbaa !29
  store ptr %t277, ptr %l137, !tbaa !29
  store i32 43, ptr %l138
  %t278 = load i32, ptr %l2, !tbaa !23
  store i32 %t278, ptr %l139, !tbaa !23
  store { i64, [4 x i64] } %t276, ptr %l140
  %t280 = load ptr, ptr %l0, !tbaa !29
  %t281 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t281, ptr %l142, !tbaa !27
  %t282 = getelementptr { i64, ptr }, ptr %l142, i32 0, i32 1
  %t283 = load ptr, ptr %t282, !tbaa !27
  %t284 = getelementptr ptr, ptr %t283, i64 1
  %t285 = load ptr, ptr %t284, !tbaa !39
  %t289 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v1, ptr %t280, ptr %t285)
  store { i64, [4 x i64] } %t289, ptr %l145
  br label %bb34
bb34:
  %t290 = mul i64 2, 40
  %t291 = call ptr @__olang_scope_alloc_zeroed(ptr %s2, i64 %t290)
  %t292 = insertvalue { i64, ptr } undef, i64 2, 0
  %t293 = insertvalue { i64, ptr } %t292, ptr %t291, 1
  store { i64, ptr } %t293, ptr %l146, !tbaa !27
  %t294 = load { i64, [4 x i64] }, ptr %l140
  %t295 = getelementptr { i64, ptr }, ptr %l146, i32 0, i32 1
  %t296 = load ptr, ptr %t295, !tbaa !27
  %t297 = getelementptr { i64, [4 x i64] }, ptr %t296, i64 0
  store { i64, [4 x i64] } %t294, ptr %t297
  %t298 = load { i64, [4 x i64] }, ptr %l145
  %t299 = getelementptr { i64, ptr }, ptr %l146, i32 0, i32 1
  %t300 = load ptr, ptr %t299, !tbaa !27
  %t301 = getelementptr { i64, [4 x i64] }, ptr %t300, i64 1
  store { i64, [4 x i64] } %t298, ptr %t301
  %t302 = load %"compiler/source:Span", ptr %l3
  %t303 = load ptr, ptr %l137, !tbaa !29
  %t304 = load i32, ptr %l138, !range !{i32 0, i32 49}
  %t305 = load i32, ptr %l139, !tbaa !23
  %t306 = load { i64, ptr }, ptr %l146, !tbaa !27
  %t308 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s2, ptr %t303, i32 %t304, i32 %t305, { i64, ptr } %t306, %"compiler/source:Span" %t302)
  store { i64, [4 x i64] } %t308, ptr %l148
  br label %bb35
bb35:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t309 = load { i64, [4 x i64] }, ptr %l148
  store { i64, [4 x i64] } %t309, ptr %rv
  br label %ret
bb36:
  br label %bb37
bb37:
  %t310 = load ptr, ptr %l0, !tbaa !29
  %t311 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t314 = call { i64, ptr } @compiler_2flower_2ecompiler_2flower_3alowering_2evals(ptr %v0, ptr %v1, ptr %s0, ptr %t310, { i64, ptr } %t311)
  store { i64, ptr } %t314, ptr %l151
  br label %bb38
bb38:
  %t315 = load { i64, ptr }, ptr %l151, !tbaa !27
  store { i64, ptr } %t315, ptr %l27, !tbaa !27
  %t316 = load ptr, ptr %l0, !tbaa !29
  %t318 = getelementptr %"compiler/lower:lowering", ptr %t316, i32 0, i32 7
  %t319 = load i1, ptr %t318, !tbaa !21
  br i1 %t319, label %bb39, label %bb40
bb39:
  store { i64, [4 x i64] } zeroinitializer, ptr %t321
  %t322 = getelementptr { i64, [4 x i64] }, ptr %t321, i32 0, i32 0
  store i64 0, ptr %t322
  %t323 = load { i64, [4 x i64] }, ptr %t321
  call void @__olang_scope_close(ptr %s0)
  store { i64, [4 x i64] } %t323, ptr %rv
  br label %ret
bb40:
  br label %bb41
bb41:
  %t325 = load ptr, ptr %l0, !tbaa !29
  %t326 = load i32, ptr %l2, !tbaa !23
  %t327 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t328 = load %"compiler/source:Span", ptr %l3
  %t334 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s0, ptr %t325, i32 43, i32 %t326, { i64, ptr } %t327, %"compiler/source:Span" %t328)
  store { i64, [4 x i64] } %t334, ptr %l160
  br label %bb42
bb42:
  call void @__olang_scope_close(ptr %s0)
  %t335 = load { i64, [4 x i64] }, ptr %l160
  store { i64, [4 x i64] } %t335, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2earrayCopy(ptr %v0, ptr %a0, { i64, [4 x i64] } %a1, i32 %a2, %"compiler/source:Span" %a3, { i64, [1 x i64] } %a4, i1 %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [4 x i64] }
  %l2 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca { i64, [1 x i64] }
  %l6 = alloca i32
  %l7 = alloca { i64, [4 x i64] }
  %l8 = alloca i32
  %l12 = alloca i1
  %l19 = alloca { i64, [4 x i64] }
  %l24 = alloca i32
  %l25 = alloca ptr
  %l26 = alloca i32
  %l27 = alloca i32
  %l29 = alloca %"compiler/mir:Lvalue"
  %l31 = alloca { i64, ptr }
  %l33 = alloca { i64, [4 x i64] }
  %l37 = alloca i32
  %l38 = alloca ptr
  %l39 = alloca %"compiler/source:Span"
  %l41 = alloca %"compiler/mir:Lvalue"
  %l47 = alloca { i64, [21 x i64] }
  %l49 = alloca ptr
  %l50 = alloca %"compiler/source:Span"
  %l52 = alloca %"compiler/mir:Lvalue"
  %l54 = alloca %"compiler/mir:Lvalue"
  %l56 = alloca { i64, [21 x i64] }
  %l59 = alloca %"compiler/mir:Lvalue"
  %s0 = alloca %olang.scope
  %rv = alloca { i64, [4 x i64] }
  %t39 = alloca { i64, [4 x i64] }, align 8
  %t77 = alloca { i64, [4 x i64] }, align 8
  %t80 = alloca { i64, [15 x i64] }, align 8
  %t92 = alloca { i64, [21 x i64] }, align 8
  %t113 = alloca { i64, [21 x i64] }, align 8
  %t130 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store { i64, [4 x i64] } %a1, ptr %l1
  store i32 %a2, ptr %l2
  store %"compiler/source:Span" %a3, ptr %l3
  store { i64, [1 x i64] } %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i32, ptr %l2, !tbaa !23
  %t8 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOwnsParts(ptr %v0, ptr %t4, i32 %t5)
  store i1 %t8, ptr %l12
  br label %bb1
bb1:
  %t9 = load i1, ptr %l12, !tbaa !21
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = load { i64, [4 x i64] }, ptr %l1
  %t12 = load i32, ptr %l2, !tbaa !23
  %t13 = load { i64, [1 x i64] }, ptr %l4
  %t14 = load %"compiler/source:Span", ptr %l3
  %t22 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eownCopyOf(ptr %v0, ptr %t10, { i64, [4 x i64] } %t11, i32 %t12, { i64, [1 x i64] } %t13, %"compiler/source:Span" %t14, i1 %a5)
  store { i64, [4 x i64] } %t22, ptr %l19
  br label %bb4
bb3:
  br label %bb5
bb4:
  call void @__olang_scope_close(ptr %s0)
  %t23 = load { i64, [4 x i64] }, ptr %l19
  store { i64, [4 x i64] } %t23, ptr %rv
  br label %ret
bb5:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t25 = load { i64, [4 x i64] }, ptr %l1
  %t26 = load i32, ptr %l2, !tbaa !23
  %t27 = load %"compiler/source:Span", ptr %l3
  %t32 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2elocal(ptr %v0, ptr %t24, { i64, [4 x i64] } %t25, i32 %t26, %"compiler/source:Span" %t27)
  store i32 %t32, ptr %l24
  br label %bb6
bb6:
  %t33 = load i32, ptr %l24, !tbaa !23
  store i32 %t33, ptr %l6, !tbaa !23
  %t34 = load ptr, ptr %l0, !tbaa !29
  store ptr %t34, ptr %l25, !tbaa !29
  store i32 22, ptr %l26
  %t35 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  store i32 %t35, ptr %l27, !tbaa !23
  %t36 = load i32, ptr %l6, !tbaa !23
  %t38 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t36)
  store %"compiler/mir:Lvalue" %t38, ptr %l29
  br label %bb7
bb7:
  store { i64, [4 x i64] } zeroinitializer, ptr %t39
  %t40 = getelementptr { i64, [4 x i64] }, ptr %t39, i32 0, i32 0
  store i64 1, ptr %t40
  %t41 = load %"compiler/mir:Lvalue", ptr %l29
  %t42 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t41, 0
  %t43 = getelementptr { i64, [4 x i64] }, ptr %t39, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t42, ptr %t43
  %t44 = load { i64, [4 x i64] }, ptr %t39
  %t45 = mul i64 1, 40
  %t46 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t45)
  %t47 = insertvalue { i64, ptr } undef, i64 1, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t46, 1
  store { i64, ptr } %t48, ptr %l31, !tbaa !27
  %t50 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t51 = load ptr, ptr %t50, !tbaa !27
  %t52 = getelementptr { i64, [4 x i64] }, ptr %t51, i64 0
  store { i64, [4 x i64] } %t44, ptr %t52
  %t53 = load %"compiler/source:Span", ptr %l3
  %t54 = load ptr, ptr %l25, !tbaa !29
  %t55 = load i32, ptr %l26, !range !{i32 0, i32 49}
  %t56 = load i32, ptr %l27, !tbaa !23
  %t57 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t59 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s0, ptr %t54, i32 %t55, i32 %t56, { i64, ptr } %t57, %"compiler/source:Span" %t53)
  store { i64, [4 x i64] } %t59, ptr %l33
  br label %bb8
bb8:
  %t60 = load { i64, [4 x i64] }, ptr %l33
  store { i64, [4 x i64] } %t60, ptr %l7
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t62 = load i32, ptr %l2, !tbaa !23
  %t63 = load %"compiler/source:Span", ptr %l3
  %t67 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2etemp(ptr %v0, ptr %t61, i32 %t62, %"compiler/source:Span" %t63)
  store i32 %t67, ptr %l37
  br label %bb9
bb9:
  %t68 = load i32, ptr %l37, !tbaa !23
  store i32 %t68, ptr %l8, !tbaa !23
  %t69 = load ptr, ptr %l0, !tbaa !29
  store ptr %t69, ptr %l38, !tbaa !29
  %t70 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t70, ptr %l39
  %t71 = load i32, ptr %l8, !tbaa !23
  %t73 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t71)
  store %"compiler/mir:Lvalue" %t73, ptr %l41
  br label %bb10
bb10:
  %t74 = load { i64, [1 x i64] }, ptr %l4
  %t75 = load i32, ptr %l2, !tbaa !23
  %t76 = load { i64, [4 x i64] }, ptr %l7
  store { i64, [4 x i64] } zeroinitializer, ptr %t77
  %t78 = getelementptr { i64, [4 x i64] }, ptr %t77, i32 0, i32 0
  store i64 0, ptr %t78
  %t79 = load { i64, [4 x i64] }, ptr %t77
  store { i64, [15 x i64] } zeroinitializer, ptr %t80
  %t81 = getelementptr { i64, [15 x i64] }, ptr %t80, i32 0, i32 0
  store i64 8, ptr %t81
  %t83 = insertvalue { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } } undef, { i64, [1 x i64] } %t74, 0
  %t85 = insertvalue { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } } %t83, i32 %t75, 1
  %t87 = insertvalue { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } } %t85, { i64, [4 x i64] } %t76, 2
  %t89 = insertvalue { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } } %t87, { i64, [4 x i64] } %t79, 3
  %t90 = getelementptr { i64, [15 x i64] }, ptr %t80, i32 0, i32 1
  store { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } } %t89, ptr %t90
  %t91 = load { i64, [15 x i64] }, ptr %t80
  store { i64, [21 x i64] } zeroinitializer, ptr %t92
  %t93 = getelementptr { i64, [21 x i64] }, ptr %t92, i32 0, i32 0
  store i64 0, ptr %t93
  %t94 = load %"compiler/source:Span", ptr %l39
  %t95 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t94, 0
  %t96 = load %"compiler/mir:Lvalue", ptr %l41
  %t97 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t95, %"compiler/mir:Lvalue" %t96, 1
  %t99 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t97, { i64, [15 x i64] } %t91, 2
  %t100 = getelementptr { i64, [21 x i64] }, ptr %t92, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t99, ptr %t100
  %t101 = load { i64, [21 x i64] }, ptr %t92
  store { i64, [21 x i64] } %t101, ptr %l47
  %t102 = load ptr, ptr %l38, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s0, ptr %t102, ptr %l47)
  br label %bb11
bb11:
  %t104 = load ptr, ptr %l0, !tbaa !29
  store ptr %t104, ptr %l49, !tbaa !29
  %t105 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t105, ptr %l50
  %t106 = load i32, ptr %l8, !tbaa !23
  %t108 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t106)
  store %"compiler/mir:Lvalue" %t108, ptr %l52
  br label %bb12
bb12:
  %t109 = load i32, ptr %l6, !tbaa !23
  %t111 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t109)
  store %"compiler/mir:Lvalue" %t111, ptr %l54
  br label %bb13
bb13:
  %t112 = load { i64, [4 x i64] }, ptr %l7
  store { i64, [21 x i64] } zeroinitializer, ptr %t113
  %t114 = getelementptr { i64, [21 x i64] }, ptr %t113, i32 0, i32 0
  store i64 9, ptr %t114
  %t115 = load %"compiler/source:Span", ptr %l50
  %t116 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", %"compiler/mir:Lvalue", { i64, [4 x i64] } } undef, %"compiler/source:Span" %t115, 0
  %t117 = load %"compiler/mir:Lvalue", ptr %l52
  %t118 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", %"compiler/mir:Lvalue", { i64, [4 x i64] } } %t116, %"compiler/mir:Lvalue" %t117, 1
  %t119 = load %"compiler/mir:Lvalue", ptr %l54
  %t120 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", %"compiler/mir:Lvalue", { i64, [4 x i64] } } %t118, %"compiler/mir:Lvalue" %t119, 2
  %t122 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", %"compiler/mir:Lvalue", { i64, [4 x i64] } } %t120, { i64, [4 x i64] } %t112, 3
  %t123 = getelementptr { i64, [21 x i64] }, ptr %t113, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Lvalue", %"compiler/mir:Lvalue", { i64, [4 x i64] } } %t122, ptr %t123
  %t124 = load { i64, [21 x i64] }, ptr %t113
  store { i64, [21 x i64] } %t124, ptr %l56
  %t125 = load ptr, ptr %l49, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s0, ptr %t125, ptr %l56)
  br label %bb14
bb14:
  %t127 = load i32, ptr %l8, !tbaa !23
  %t129 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t127)
  store %"compiler/mir:Lvalue" %t129, ptr %l59
  br label %bb15
bb15:
  store { i64, [4 x i64] } zeroinitializer, ptr %t130
  %t131 = getelementptr { i64, [4 x i64] }, ptr %t130, i32 0, i32 0
  store i64 1, ptr %t131
  %t132 = load %"compiler/mir:Lvalue", ptr %l59
  %t133 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t132, 0
  %t134 = getelementptr { i64, [4 x i64] }, ptr %t130, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t133, ptr %t134
  %t135 = load { i64, [4 x i64] }, ptr %t130
  call void @__olang_scope_close(ptr %s0)
  store { i64, [4 x i64] } %t135, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2earrayLit(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3, i1 %a4, { i64, [1 x i64] } %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l6 = alloca ptr
  %l7 = alloca i32
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, [4 x i64] }
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca i1
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l24 = alloca i32
  %l34 = alloca { i64, ptr }
  %l40 = alloca i64
  %l42 = alloca ptr
  %l43 = alloca i32
  %l44 = alloca i32
  %l48 = alloca %"compiler/mir:Range"
  %l51 = alloca { i64, [4 x i64] }
  %l52 = alloca ptr
  %l55 = alloca i32
  %l56 = alloca i1
  %l59 = alloca ptr
  %l60 = alloca i32
  %l64 = alloca { i64, [1 x i64] }
  %l69 = alloca { i64, [4 x i64] }
  %l72 = alloca i32
  %l76 = alloca i32
  %l77 = alloca ptr
  %l78 = alloca %"compiler/source:Span"
  %l80 = alloca %"compiler/mir:Lvalue"
  %l82 = alloca { i64, [1 x i64] }
  %l87 = alloca { i64, [1 x i64] }
  %l88 = alloca i32
  %l92 = alloca { i64, [4 x i64] }
  %l96 = alloca { i64, [21 x i64] }
  %l98 = alloca ptr
  %l101 = alloca i32
  %l102 = alloca i1
  %l108 = alloca i64
  %l111 = alloca i64
  %l130 = alloca ptr
  %l132 = alloca { i64, [2 x i64] }
  %l134 = alloca { i64, ptr }
  %l138 = alloca { i64, ptr }
  %l141 = alloca { i64, ptr }
  %l142 = alloca %"compiler/mir:Lvalue"
  %l149 = alloca { i64, [21 x i64] }
  %l154 = alloca %"compiler/mir:Lvalue"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca { i64, [4 x i64] }
  %t22 = alloca { i64, [4 x i64] }, align 8
  %t40 = alloca { i64, [4 x i64] }, align 8
  %t62 = alloca { i64, [15 x i64] }, align 8
  %t104 = alloca { i64, [15 x i64] }, align 8
  %t162 = alloca { i64, [4 x i64] }, align 8
  %t169 = alloca { i64, [15 x i64] }, align 8
  %t181 = alloca { i64, [21 x i64] }, align 8
  %t257 = alloca { i64, [2 x i64] }, align 8
  %t265 = alloca { i64, [1 x i64] }, align 8
  %t269 = alloca { i64, [1 x i64] }, align 8
  %t289 = alloca { i64, [1 x i64] }, align 8
  %t318 = alloca { i64, [15 x i64] }, align 8
  %t324 = alloca { i64, [21 x i64] }, align 8
  %t343 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  store %"compiler/source:Span" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l6, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t7 = load i32, ptr %l2, !tbaa !23
  %t10 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2earrayOf(ptr %v0, ptr %t6, i32 %t7)
  store i32 %t10, ptr %l24
  br label %bb1
bb1:
  %t11 = load i32, ptr %l24, !tbaa !23
  store i32 %t11, ptr %l7, !tbaa !23
  %t12 = load i32, ptr %l7, !tbaa !23
  %t13 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t16 = icmp eq i32 %t12, %t13
  br i1 %t16, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t19 = load %"compiler/source:Span", ptr %l3
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2egap(ptr %v0, ptr %s1, ptr %t18, %"compiler/source:Span" %t19, { i64, ptr } { i64 43, ptr getelementptr inbounds (<{ i64, [43 x i8] }>, ptr @.d2, i32 0, i32 1) })
  br label %bb4
bb3:
  br label %bb5
bb4:
  store { i64, [4 x i64] } zeroinitializer, ptr %t22
  %t23 = getelementptr { i64, [4 x i64] }, ptr %t22, i32 0, i32 0
  store i64 0, ptr %t23
  %t24 = load { i64, [4 x i64] }, ptr %t22
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  store { i64, [4 x i64] } %t24, ptr %rv
  br label %ret
bb5:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t27 = load ptr, ptr %l1, !tbaa !29
  %t29 = getelementptr %"compiler/typed:Make", ptr %t27, i32 0, i32 2
  %t30 = load { i64, ptr }, ptr %t29, !tbaa !27
  %t33 = call { i64, ptr } @compiler_2flower_2ecompiler_2flower_3alowering_2evals(ptr %v0, ptr %v1, ptr %s0, ptr %t26, { i64, ptr } %t30)
  store { i64, ptr } %t33, ptr %l34
  br label %bb6
bb6:
  %t34 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t34, ptr %l8, !tbaa !27
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/lower:lowering", ptr %t35, i32 0, i32 7
  %t38 = load i1, ptr %t37, !tbaa !21
  br i1 %t38, label %bb7, label %bb8
bb7:
  store { i64, [4 x i64] } zeroinitializer, ptr %t40
  %t41 = getelementptr { i64, [4 x i64] }, ptr %t40, i32 0, i32 0
  store i64 0, ptr %t41
  %t42 = load { i64, [4 x i64] }, ptr %t40
  call void @__olang_scope_close(ptr %s0)
  store { i64, [4 x i64] } %t42, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t45 = load i32, ptr %l7, !tbaa !23
  %t48 = call i64 @compiler_2flower_2ecompiler_2flower_3alowering_2efixedLen(ptr %v0, ptr %t44, i32 %t45)
  store i64 %t48, ptr %l40
  br label %bb10
bb10:
  %t49 = load i64, ptr %l40, !tbaa !24
  %t50 = icmp sge i64 %t49, 0
  br i1 %t50, label %bb11, label %bb12
bb11:
  %t52 = load ptr, ptr %l0, !tbaa !29
  store ptr %t52, ptr %l42, !tbaa !29
  %t53 = load i32, ptr %l7, !tbaa !23
  store i32 %t53, ptr %l43, !tbaa !23
  %t54 = load i32, ptr %l7, !tbaa !23
  store i32 %t54, ptr %l44, !tbaa !23
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/lower:lowering", ptr %t55, i32 0, i32 3
  %t58 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t61 = call %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eArgs(ptr %v0, ptr %s0, ptr %t57, { i64, ptr } %t58)
  store %"compiler/mir:Range" %t61, ptr %l48
  br label %bb13
bb12:
  br label %bb22
bb13:
  store { i64, [15 x i64] } zeroinitializer, ptr %t62
  %t63 = getelementptr { i64, [15 x i64] }, ptr %t62, i32 0, i32 0
  store i64 6, ptr %t63
  %t64 = load i32, ptr %l44, !tbaa !23
  %t65 = insertvalue { i32, i64, %"compiler/mir:Range" } undef, i32 %t64, 0
  %t66 = insertvalue { i32, i64, %"compiler/mir:Range" } %t65, i64 0, 1
  %t67 = load %"compiler/mir:Range", ptr %l48
  %t68 = insertvalue { i32, i64, %"compiler/mir:Range" } %t66, %"compiler/mir:Range" %t67, 2
  %t69 = getelementptr { i64, [15 x i64] }, ptr %t62, i32 0, i32 1
  store { i32, i64, %"compiler/mir:Range" } %t68, ptr %t69
  %t70 = load { i64, [15 x i64] }, ptr %t62
  %t71 = load %"compiler/source:Span", ptr %l3
  %t72 = load ptr, ptr %l42, !tbaa !29
  %t73 = load i32, ptr %l43, !tbaa !23
  %t76 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %t72, i32 %t73, { i64, [15 x i64] } %t70, %"compiler/source:Span" %t71)
  store { i64, [4 x i64] } %t76, ptr %l51
  br label %bb14
bb14:
  %t77 = load { i64, [4 x i64] }, ptr %l51
  store { i64, [4 x i64] } %t77, ptr %l9
  %t78 = load ptr, ptr %l6, !tbaa !29
  store ptr %t78, ptr %l52, !tbaa !29
  %t79 = load ptr, ptr %l6, !tbaa !29
  %t80 = load i32, ptr %l2, !tbaa !23
  %t83 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t79, i32 %t80)
  store i32 %t83, ptr %l55
  br label %bb15
bb15:
  %t84 = load ptr, ptr %l52, !tbaa !29
  %t85 = load i32, ptr %l55, !tbaa !23
  %t86 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t84, i32 %t85)
  store i1 %t86, ptr %l56
  br label %bb16
bb16:
  %t87 = load i1, ptr %l56, !tbaa !21
  %t88 = xor i1 %t87, true
  br i1 %t88, label %bb17, label %bb18
bb17:
  %t90 = load { i64, [4 x i64] }, ptr %l9
  call void @__olang_scope_close(ptr %s0)
  store { i64, [4 x i64] } %t90, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  %t92 = load ptr, ptr %l0, !tbaa !29
  store ptr %t92, ptr %l59, !tbaa !29
  %t93 = load i32, ptr %l2, !tbaa !23
  store i32 %t93, ptr %l60, !tbaa !23
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t95 = load ptr, ptr %l1, !tbaa !29
  %t97 = getelementptr %"compiler/typed:Make", ptr %t95, i32 0, i32 4
  %t98 = load i32, ptr %t97, !tbaa !23
  %t101 = call { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ebuilt(ptr %v0, ptr %t94, i32 %t98)
  store { i64, [1 x i64] } %t101, ptr %l64
  br label %bb20
bb20:
  %t102 = load { i64, [4 x i64] }, ptr %l9
  %t103 = load i32, ptr %l2, !tbaa !23
  store { i64, [15 x i64] } zeroinitializer, ptr %t104
  %t105 = getelementptr { i64, [15 x i64] }, ptr %t104, i32 0, i32 0
  store i64 7, ptr %t105
  %t106 = load { i64, [1 x i64] }, ptr %l64
  %t107 = insertvalue { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 } undef, { i64, [1 x i64] } %t106, 0
  %t109 = insertvalue { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 } %t107, { i64, [4 x i64] } %t102, 1
  %t111 = insertvalue { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 } %t109, i32 %t103, 2
  %t112 = getelementptr { i64, [15 x i64] }, ptr %t104, i32 0, i32 1
  store { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 } %t111, ptr %t112
  %t113 = load { i64, [15 x i64] }, ptr %t104
  %t114 = load %"compiler/source:Span", ptr %l3
  %t115 = load ptr, ptr %l59, !tbaa !29
  %t116 = load i32, ptr %l60, !tbaa !23
  %t119 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %t115, i32 %t116, { i64, [15 x i64] } %t113, %"compiler/source:Span" %t114)
  store { i64, [4 x i64] } %t119, ptr %l69
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s0)
  %t120 = load { i64, [4 x i64] }, ptr %l69
  store { i64, [4 x i64] } %t120, ptr %rv
  br label %ret
bb22:
  %t121 = load ptr, ptr %l6, !tbaa !29
  %t122 = load i32, ptr %l7, !tbaa !23
  %t125 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t121, i32 %t122)
  store i32 %t125, ptr %l72
  br label %bb23
bb23:
  %t126 = load i32, ptr %l72, !tbaa !23
  store i32 %t126, ptr %l10, !tbaa !23
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t128 = load i32, ptr %l2, !tbaa !23
  %t129 = load %"compiler/source:Span", ptr %l3
  %t133 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2etemp(ptr %v0, ptr %t127, i32 %t128, %"compiler/source:Span" %t129)
  store i32 %t133, ptr %l76
  br label %bb24
bb24:
  %t134 = load i32, ptr %l76, !tbaa !23
  store i32 %t134, ptr %l11, !tbaa !23
  %t135 = load ptr, ptr %l0, !tbaa !29
  store ptr %t135, ptr %l77, !tbaa !29
  %t136 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t136, ptr %l78
  %t137 = load i32, ptr %l11, !tbaa !23
  %t139 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t137)
  store %"compiler/mir:Lvalue" %t139, ptr %l80
  br label %bb25
bb25:
  br i1 %a4, label %bb26, label %bb27
bb26:
  store { i64, [1 x i64] } %a5, ptr %l82
  br label %bb29
bb27:
  %t144 = load ptr, ptr %l0, !tbaa !29
  %t145 = load ptr, ptr %l1, !tbaa !29
  %t147 = getelementptr %"compiler/typed:Make", ptr %t145, i32 0, i32 4
  %t148 = load i32, ptr %t147, !tbaa !23
  %t151 = call { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2emadeAt(ptr %v0, ptr %t144, i32 %t148)
  store { i64, [1 x i64] } %t151, ptr %l87
  br label %bb28
bb28:
  %t152 = load { i64, [1 x i64] }, ptr %l87
  store { i64, [1 x i64] } %t152, ptr %l82
  br label %bb29
bb29:
  %t153 = load i32, ptr %l2, !tbaa !23
  store i32 %t153, ptr %l88, !tbaa !23
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t155 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t157 = extractvalue { i64, ptr } %t155, 0
  %t160 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2econstI64(ptr %v0, ptr %t154, i64 %t157)
  store { i64, [4 x i64] } %t160, ptr %l92
  br label %bb30
bb30:
  %t161 = load i32, ptr %l10, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t162
  %t163 = getelementptr { i64, [4 x i64] }, ptr %t162, i32 0, i32 0
  store i64 2, ptr %t163
  %t165 = insertvalue { i32, i64 } undef, i32 %t161, 0
  %t166 = insertvalue { i32, i64 } %t165, i64 0, 1
  %t167 = getelementptr { i64, [4 x i64] }, ptr %t162, i32 0, i32 1
  store { i32, i64 } %t166, ptr %t167
  %t168 = load { i64, [4 x i64] }, ptr %t162
  store { i64, [15 x i64] } zeroinitializer, ptr %t169
  %t170 = getelementptr { i64, [15 x i64] }, ptr %t169, i32 0, i32 0
  store i64 8, ptr %t170
  %t171 = load { i64, [1 x i64] }, ptr %l82
  %t172 = insertvalue { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } } undef, { i64, [1 x i64] } %t171, 0
  %t173 = load i32, ptr %l88, !tbaa !23
  %t174 = insertvalue { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } } %t172, i32 %t173, 1
  %t175 = load { i64, [4 x i64] }, ptr %l92
  %t176 = insertvalue { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } } %t174, { i64, [4 x i64] } %t175, 2
  %t178 = insertvalue { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } } %t176, { i64, [4 x i64] } %t168, 3
  %t179 = getelementptr { i64, [15 x i64] }, ptr %t169, i32 0, i32 1
  store { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } } %t178, ptr %t179
  %t180 = load { i64, [15 x i64] }, ptr %t169
  store { i64, [21 x i64] } zeroinitializer, ptr %t181
  %t182 = getelementptr { i64, [21 x i64] }, ptr %t181, i32 0, i32 0
  store i64 0, ptr %t182
  %t183 = load %"compiler/source:Span", ptr %l78
  %t184 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t183, 0
  %t185 = load %"compiler/mir:Lvalue", ptr %l80
  %t186 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t184, %"compiler/mir:Lvalue" %t185, 1
  %t188 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t186, { i64, [15 x i64] } %t180, 2
  %t189 = getelementptr { i64, [21 x i64] }, ptr %t181, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t188, ptr %t189
  %t190 = load { i64, [21 x i64] }, ptr %t181
  store { i64, [21 x i64] } %t190, ptr %l96
  %t191 = load ptr, ptr %l77, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s0, ptr %t191, ptr %l96)
  br label %bb31
bb31:
  %t193 = load ptr, ptr %l6, !tbaa !29
  store ptr %t193, ptr %l98, !tbaa !29
  %t194 = load ptr, ptr %l6, !tbaa !29
  %t195 = load i32, ptr %l2, !tbaa !23
  %t198 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t194, i32 %t195)
  store i32 %t198, ptr %l101
  br label %bb32
bb32:
  %t199 = load ptr, ptr %l98, !tbaa !29
  %t200 = load i32, ptr %l101, !tbaa !23
  %t201 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t199, i32 %t200)
  store i1 %t201, ptr %l102
  br label %bb33
bb33:
  %t202 = load i1, ptr %l102, !tbaa !21
  store i1 %t202, ptr %l12, !tbaa !21
  store i64 0, ptr %l13, !tbaa !24
  %t203 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t205 = extractvalue { i64, ptr } %t203, 0
  store i64 %t205, ptr %l14, !tbaa !24
  store i64 1, ptr %l15, !tbaa !24
  %t207 = load i64, ptr %l14, !tbaa !24
  %t208 = load i64, ptr %l13, !tbaa !24
  %t211 = icmp sgt i64 %t207, %t208
  br i1 %t211, label %bb34, label %bb35
bb34:
  %t213 = load i64, ptr %l15, !tbaa !24
  %t215 = icmp sgt i64 %t213, 0
  br i1 %t215, label %bb36, label %bb37
bb35:
  store i64 0, ptr %l108, !tbaa !24
  br label %bb39
bb36:
  %t217 = load i64, ptr %l14, !tbaa !24
  %t218 = load i64, ptr %l13, !tbaa !24
  %t221 = sub i64 %t217, %t218
  %t222 = load i64, ptr %l15, !tbaa !24
  %t225 = add i64 %t221, %t222
  %t227 = sub i64 %t225, 1
  %t228 = load i64, ptr %l15, !tbaa !24
  %t231 = sdiv i64 %t227, %t228
  store i64 %t231, ptr %l111, !tbaa !24
  br label %bb38
bb37:
  store i64 0, ptr %l111, !tbaa !24
  br label %bb38
bb38:
  %t233 = load i64, ptr %l111, !tbaa !24
  store i64 %t233, ptr %l108, !tbaa !24
  br label %bb39
bb39:
  %t234 = load i64, ptr %l108, !tbaa !24
  store i64 %t234, ptr %l16, !tbaa !24
  store i64 0, ptr %l17, !tbaa !24
  br label %bb40
bb40:
  store %olang.scope zeroinitializer, ptr %s6
  %t235 = load i64, ptr %l17, !tbaa !24
  %t236 = load i64, ptr %l16, !tbaa !24
  %t239 = icmp slt i64 %t235, %t236
  %t241 = xor i1 %t239, true
  br i1 %t241, label %bb41, label %bb42
bb41:
  call void @__olang_scope_close(ptr %s6)
  br label %bb50
bb42:
  br label %bb43
bb43:
  %t243 = load i64, ptr %l13, !tbaa !24
  %t244 = load i64, ptr %l17, !tbaa !24
  %t245 = load i64, ptr %l15, !tbaa !24
  %t248 = mul i64 %t244, %t245
  %t251 = add i64 %t243, %t248
  store i64 %t251, ptr %l18, !tbaa !24
  %t253 = load ptr, ptr %l0, !tbaa !29
  %t255 = getelementptr %"compiler/lower:lowering", ptr %t253, i32 0, i32 3
  store ptr %t255, ptr %l130, !tbaa !29
  %t256 = load i32, ptr %l11, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t257
  %t258 = getelementptr { i64, [2 x i64] }, ptr %t257, i32 0, i32 0
  store i64 1, ptr %t258
  %t260 = insertvalue { i32 } undef, i32 %t256, 0
  %t261 = getelementptr { i64, [2 x i64] }, ptr %t257, i32 0, i32 1
  store { i32 } %t260, ptr %t261
  %t262 = load { i64, [2 x i64] }, ptr %t257
  store { i64, [2 x i64] } %t262, ptr %l132
  %t263 = load i1, ptr %l12, !tbaa !21
  br i1 %t263, label %bb44, label %bb45
bb44:
  store { i64, [1 x i64] } zeroinitializer, ptr %t265
  %t266 = getelementptr { i64, [1 x i64] }, ptr %t265, i32 0, i32 0
  store i64 3, ptr %t266
  %t267 = load { i64, [1 x i64] }, ptr %t265
  %t268 = load i64, ptr %l18, !tbaa !24
  store { i64, [1 x i64] } zeroinitializer, ptr %t269
  %t270 = getelementptr { i64, [1 x i64] }, ptr %t269, i32 0, i32 0
  store i64 2, ptr %t270
  %t272 = insertvalue { i64 } undef, i64 %t268, 0
  %t273 = getelementptr { i64, [1 x i64] }, ptr %t269, i32 0, i32 1
  store { i64 } %t272, ptr %t273
  %t274 = load { i64, [1 x i64] }, ptr %t269
  %t275 = mul i64 2, 16
  %t276 = call ptr @__olang_scope_alloc_zeroed(ptr %s6, i64 %t275)
  %t277 = insertvalue { i64, ptr } undef, i64 2, 0
  %t278 = insertvalue { i64, ptr } %t277, ptr %t276, 1
  store { i64, ptr } %t278, ptr %l138, !tbaa !27
  %t280 = getelementptr { i64, ptr }, ptr %l138, i32 0, i32 1
  %t281 = load ptr, ptr %t280, !tbaa !27
  %t282 = getelementptr { i64, [1 x i64] }, ptr %t281, i64 0
  store { i64, [1 x i64] } %t267, ptr %t282
  %t284 = getelementptr { i64, ptr }, ptr %l138, i32 0, i32 1
  %t285 = load ptr, ptr %t284, !tbaa !27
  %t286 = getelementptr { i64, [1 x i64] }, ptr %t285, i64 1
  store { i64, [1 x i64] } %t274, ptr %t286
  %t287 = load { i64, ptr }, ptr %l138, !tbaa !27
  store { i64, ptr } %t287, ptr %l134, !tbaa !27
  br label %bb46
bb45:
  %t288 = load i64, ptr %l18, !tbaa !24
  store { i64, [1 x i64] } zeroinitializer, ptr %t289
  %t290 = getelementptr { i64, [1 x i64] }, ptr %t289, i32 0, i32 0
  store i64 2, ptr %t290
  %t292 = insertvalue { i64 } undef, i64 %t288, 0
  %t293 = getelementptr { i64, [1 x i64] }, ptr %t289, i32 0, i32 1
  store { i64 } %t292, ptr %t293
  %t294 = load { i64, [1 x i64] }, ptr %t289
  %t295 = mul i64 1, 16
  %t296 = call ptr @__olang_scope_alloc_zeroed(ptr %s6, i64 %t295)
  %t297 = insertvalue { i64, ptr } undef, i64 1, 0
  %t298 = insertvalue { i64, ptr } %t297, ptr %t296, 1
  store { i64, ptr } %t298, ptr %l141, !tbaa !27
  %t300 = getelementptr { i64, ptr }, ptr %l141, i32 0, i32 1
  %t301 = load ptr, ptr %t300, !tbaa !27
  %t302 = getelementptr { i64, [1 x i64] }, ptr %t301, i64 0
  store { i64, [1 x i64] } %t294, ptr %t302
  %t303 = load { i64, ptr }, ptr %l141, !tbaa !27
  store { i64, ptr } %t303, ptr %l134, !tbaa !27
  br label %bb46
bb46:
  %t304 = load ptr, ptr %l130, !tbaa !29
  %t305 = load { i64, [2 x i64] }, ptr %l132
  %t306 = load { i64, ptr }, ptr %l134, !tbaa !27
  %t307 = call %"compiler/mir:Lvalue" @compiler_2fmir_2ecompiler_2fmir_3aFn_2ePlace(ptr %v0, ptr %s6, ptr %t304, { i64, [2 x i64] } %t305, { i64, ptr } %t306)
  store %"compiler/mir:Lvalue" %t307, ptr %l142
  br label %bb47
bb47:
  %t308 = load %"compiler/mir:Lvalue", ptr %l142
  %t309 = load ptr, ptr %l0, !tbaa !29
  %t310 = load %"compiler/source:Span", ptr %l3
  %t312 = load i64, ptr %l18, !tbaa !24
  %t314 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t315 = load ptr, ptr %t314, !tbaa !27
  %t316 = getelementptr { i64, [4 x i64] }, ptr %t315, i64 %t312
  %t317 = load { i64, [4 x i64] }, ptr %t316
  store { i64, [15 x i64] } zeroinitializer, ptr %t318
  %t319 = getelementptr { i64, [15 x i64] }, ptr %t318, i32 0, i32 0
  store i64 0, ptr %t319
  %t321 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t317, 0
  %t322 = getelementptr { i64, [15 x i64] }, ptr %t318, i32 0, i32 1
  store { { i64, [4 x i64] } } %t321, ptr %t322
  %t323 = load { i64, [15 x i64] }, ptr %t318
  store { i64, [21 x i64] } zeroinitializer, ptr %t324
  %t325 = getelementptr { i64, [21 x i64] }, ptr %t324, i32 0, i32 0
  store i64 0, ptr %t325
  %t327 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t310, 0
  %t329 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t327, %"compiler/mir:Lvalue" %t308, 1
  %t331 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t329, { i64, [15 x i64] } %t323, 2
  %t332 = getelementptr { i64, [21 x i64] }, ptr %t324, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t331, ptr %t332
  %t333 = load { i64, [21 x i64] }, ptr %t324
  store { i64, [21 x i64] } %t333, ptr %l149
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s6, ptr %t309, ptr %l149)
  br label %bb48
bb48:
  call void @__olang_scope_close(ptr %s6)
  br label %bb49
bb49:
  %t336 = load i64, ptr %l17, !tbaa !24
  %t338 = add i64 %t336, 1
  store i64 %t338, ptr %l17, !tbaa !24
  br label %bb40
bb50:
  %t340 = load i32, ptr %l11, !tbaa !23
  %t342 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t340)
  store %"compiler/mir:Lvalue" %t342, ptr %l154
  br label %bb51
bb51:
  store { i64, [4 x i64] } zeroinitializer, ptr %t343
  %t344 = getelementptr { i64, [4 x i64] }, ptr %t343, i32 0, i32 0
  store i64 1, ptr %t344
  %t345 = load %"compiler/mir:Lvalue", ptr %l154
  %t346 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t345, 0
  %t347 = getelementptr { i64, [4 x i64] }, ptr %t343, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t346, ptr %t347
  %t348 = load { i64, [4 x i64] }, ptr %t343
  call void @__olang_scope_close(ptr %s0)
  store { i64, [4 x i64] } %t348, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local i32 @compiler_2flower_2ecompiler_2flower_3alowering_2earrayOf(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca i32
  %l8 = alloca i32
  %l11 = alloca i1
  %l12 = alloca ptr
  %l15 = alloca i32
  %l16 = alloca i32
  %l19 = alloca i32
  %l22 = alloca i32
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/lower:lowering", ptr %a0, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t6, i32 %a1)
  store i32 %t10, ptr %l8
  br label %bb1
bb1:
  %t11 = load i32, ptr %l8, !tbaa !23
  store i32 %t11, ptr %l3, !tbaa !23
  %t12 = load ptr, ptr %l2, !tbaa !29
  %t13 = load i32, ptr %l3, !tbaa !23
  %t16 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t12, i32 %t13)
  store i1 %t16, ptr %l11
  br label %bb2
bb2:
  %t17 = load i1, ptr %l11, !tbaa !21
  br i1 %t17, label %bb3, label %bb4
bb3:
  %t18 = load ptr, ptr %l2, !tbaa !29
  store ptr %t18, ptr %l12, !tbaa !29
  %t19 = load ptr, ptr %l2, !tbaa !29
  %t20 = load i32, ptr %l3, !tbaa !23
  %t23 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t19, i32 %t20)
  store i32 %t23, ptr %l15
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t24 = load ptr, ptr %l12, !tbaa !29
  %t25 = load i32, ptr %l15, !tbaa !23
  %t26 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t24, i32 %t25)
  store i32 %t26, ptr %l16
  br label %bb6
bb6:
  %t27 = load i32, ptr %l16, !tbaa !23
  store i32 %t27, ptr %l3, !tbaa !23
  br label %bb7
bb7:
  %t28 = load ptr, ptr %l2, !tbaa !29
  %t29 = load i32, ptr %l3, !tbaa !23
  %t32 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t28, i32 %t29)
  store i32 %t32, ptr %l19
  br label %bb8
bb8:
  %t33 = load i32, ptr %l19, !range !{i32 0, i32 33}
  %t35 = trunc i64 19 to i32
  %t36 = icmp eq i32 %t33, %t35
  br i1 %t36, label %bb9, label %bb10
bb9:
  %t38 = load i32, ptr %l3, !tbaa !23
  store i32 %t38, ptr %l22, !tbaa !23
  br label %bb11
bb10:
  %t40 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t40, ptr %l22, !tbaa !23
  br label %bb11
bb11:
  %t42 = load i32, ptr %l22, !tbaa !23
  store i32 %t42, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2earrayStore(ptr %v0, ptr %a0, %"compiler/mir:Lvalue" %a1, { i64, [4 x i64] } %a2, i32 %a3, i1 %a4, %"compiler/source:Span" %a5, { i64, [1 x i64] } %a6) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/mir:Lvalue"
  %l3 = alloca i32
  %l5 = alloca %"compiler/source:Span"
  %l7 = alloca i32
  %l8 = alloca { i64, [4 x i64] }
  %l9 = alloca { i64, [4 x i64] }
  %l10 = alloca { i64, [4 x i64] }
  %l11 = alloca i32
  %l12 = alloca i32
  %l13 = alloca i32
  %l19 = alloca i32
  %l25 = alloca { i64, ptr }
  %l27 = alloca { i64, [4 x i64] }
  %l28 = alloca ptr
  %l29 = alloca i32
  %l30 = alloca i32
  %l32 = alloca %"compiler/mir:Lvalue"
  %l34 = alloca { i64, ptr }
  %l36 = alloca { i64, [4 x i64] }
  %l42 = alloca { i64, ptr }
  %l44 = alloca { i64, [4 x i64] }
  %l47 = alloca i32
  %l50 = alloca i32
  %l53 = alloca i32
  %l61 = alloca ptr
  %l62 = alloca %"compiler/source:Span"
  %l63 = alloca %"compiler/mir:Lvalue"
  %l65 = alloca %"compiler/mir:Lvalue"
  %l67 = alloca { i64, [21 x i64] }
  %l74 = alloca { i64, [4 x i64] }
  %l75 = alloca ptr
  %l77 = alloca %"compiler/mir:Lvalue"
  %l82 = alloca { i64, [4 x i64] }
  %l84 = alloca %"compiler/mir:Lvalue"
  %l91 = alloca { i64, [21 x i64] }
  %s0 = alloca %olang.scope
  %t14 = alloca { i64, [4 x i64] }, align 8
  %t41 = alloca { i64, [4 x i64] }, align 8
  %t109 = alloca { i64, [8 x i64] }, align 8
  %t132 = alloca { i64, [21 x i64] }, align 8
  %t163 = alloca { i64, [4 x i64] }, align 8
  %t179 = alloca { i64, [4 x i64] }, align 8
  %t191 = alloca { i64, [15 x i64] }, align 8
  %t197 = alloca { i64, [21 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/mir:Lvalue" %a1, ptr %l1
  store i32 %a3, ptr %l3
  store %"compiler/source:Span" %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = load i32, ptr %l3, !tbaa !23
  %t4 = load %"compiler/source:Span", ptr %l5
  %t9 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2elocal(ptr %v0, ptr %t1, { i64, [4 x i64] } %a2, i32 %t3, %"compiler/source:Span" %t4)
  store i32 %t9, ptr %l19
  br label %bb1
bb1:
  %t10 = load i32, ptr %l19, !tbaa !23
  store i32 %t10, ptr %l7, !tbaa !23
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  %t13 = load %"compiler/mir:Lvalue", ptr %l1
  store { i64, [4 x i64] } zeroinitializer, ptr %t14
  %t15 = getelementptr { i64, [4 x i64] }, ptr %t14, i32 0, i32 0
  store i64 1, ptr %t15
  %t17 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t13, 0
  %t18 = getelementptr { i64, [4 x i64] }, ptr %t14, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t17, ptr %t18
  %t19 = load { i64, [4 x i64] }, ptr %t14
  %t20 = mul i64 1, 40
  %t21 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t20)
  %t22 = insertvalue { i64, ptr } undef, i64 1, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t21, 1
  store { i64, ptr } %t23, ptr %l25, !tbaa !27
  %t25 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr { i64, [4 x i64] }, ptr %t26, i64 0
  store { i64, [4 x i64] } %t19, ptr %t27
  %t28 = load %"compiler/source:Span", ptr %l5
  %t32 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t34 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s0, ptr %t11, i32 22, i32 %t12, { i64, ptr } %t32, %"compiler/source:Span" %t28)
  store { i64, [4 x i64] } %t34, ptr %l27
  br label %bb2
bb2:
  %t35 = load { i64, [4 x i64] }, ptr %l27
  store { i64, [4 x i64] } %t35, ptr %l8
  %t36 = load ptr, ptr %l0, !tbaa !29
  store ptr %t36, ptr %l28, !tbaa !29
  store i32 22, ptr %l29
  %t37 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  store i32 %t37, ptr %l30, !tbaa !23
  %t38 = load i32, ptr %l7, !tbaa !23
  %t40 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t38)
  store %"compiler/mir:Lvalue" %t40, ptr %l32
  br label %bb3
bb3:
  store { i64, [4 x i64] } zeroinitializer, ptr %t41
  %t42 = getelementptr { i64, [4 x i64] }, ptr %t41, i32 0, i32 0
  store i64 1, ptr %t42
  %t43 = load %"compiler/mir:Lvalue", ptr %l32
  %t44 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t43, 0
  %t45 = getelementptr { i64, [4 x i64] }, ptr %t41, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t44, ptr %t45
  %t46 = load { i64, [4 x i64] }, ptr %t41
  %t47 = mul i64 1, 40
  %t48 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t47)
  %t49 = insertvalue { i64, ptr } undef, i64 1, 0
  %t50 = insertvalue { i64, ptr } %t49, ptr %t48, 1
  store { i64, ptr } %t50, ptr %l34, !tbaa !27
  %t52 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !27
  %t54 = getelementptr { i64, [4 x i64] }, ptr %t53, i64 0
  store { i64, [4 x i64] } %t46, ptr %t54
  %t55 = load %"compiler/source:Span", ptr %l5
  %t56 = load ptr, ptr %l28, !tbaa !29
  %t57 = load i32, ptr %l29, !range !{i32 0, i32 49}
  %t58 = load i32, ptr %l30, !tbaa !23
  %t59 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t61 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s0, ptr %t56, i32 %t57, i32 %t58, { i64, ptr } %t59, %"compiler/source:Span" %t55)
  store { i64, [4 x i64] } %t61, ptr %l36
  br label %bb4
bb4:
  %t62 = load { i64, [4 x i64] }, ptr %l36
  store { i64, [4 x i64] } %t62, ptr %l9
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t64 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t65 = load { i64, [4 x i64] }, ptr %l8
  %t66 = load { i64, [4 x i64] }, ptr %l9
  %t67 = mul i64 2, 40
  %t68 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t67)
  %t69 = insertvalue { i64, ptr } undef, i64 2, 0
  %t70 = insertvalue { i64, ptr } %t69, ptr %t68, 1
  store { i64, ptr } %t70, ptr %l42, !tbaa !27
  %t72 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !27
  %t74 = getelementptr { i64, [4 x i64] }, ptr %t73, i64 0
  store { i64, [4 x i64] } %t65, ptr %t74
  %t76 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t77 = load ptr, ptr %t76, !tbaa !27
  %t78 = getelementptr { i64, [4 x i64] }, ptr %t77, i64 1
  store { i64, [4 x i64] } %t66, ptr %t78
  %t79 = load %"compiler/source:Span", ptr %l5
  %t83 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t85 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s0, ptr %t63, i32 13, i32 %t64, { i64, ptr } %t83, %"compiler/source:Span" %t79)
  store { i64, [4 x i64] } %t85, ptr %l44
  br label %bb5
bb5:
  %t86 = load { i64, [4 x i64] }, ptr %l44
  store { i64, [4 x i64] } %t86, ptr %l10
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr %"compiler/lower:lowering", ptr %t87, i32 0, i32 3
  %t91 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t89)
  store i32 %t91, ptr %l47
  br label %bb6
bb6:
  %t92 = load i32, ptr %l47, !tbaa !23
  store i32 %t92, ptr %l11, !tbaa !23
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/lower:lowering", ptr %t93, i32 0, i32 3
  %t97 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t95)
  store i32 %t97, ptr %l50
  br label %bb7
bb7:
  %t98 = load i32, ptr %l50, !tbaa !23
  store i32 %t98, ptr %l12, !tbaa !23
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = getelementptr %"compiler/lower:lowering", ptr %t99, i32 0, i32 3
  %t103 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t101)
  store i32 %t103, ptr %l53
  br label %bb8
bb8:
  %t104 = load i32, ptr %l53, !tbaa !23
  store i32 %t104, ptr %l13, !tbaa !23
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t106 = load { i64, [4 x i64] }, ptr %l10
  %t107 = load i32, ptr %l11, !tbaa !23
  %t108 = load i32, ptr %l12, !tbaa !23
  store { i64, [8 x i64] } zeroinitializer, ptr %t109
  %t110 = getelementptr { i64, [8 x i64] }, ptr %t109, i32 0, i32 0
  store i64 2, ptr %t110
  %t112 = insertvalue { { i64, [4 x i64] }, i32, i32 } undef, { i64, [4 x i64] } %t106, 0
  %t114 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t112, i32 %t107, 1
  %t116 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t114, i32 %t108, 2
  %t117 = getelementptr { i64, [8 x i64] }, ptr %t109, i32 0, i32 1
  store { { i64, [4 x i64] }, i32, i32 } %t116, ptr %t117
  %t118 = load { i64, [8 x i64] }, ptr %t109
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t105, { i64, [8 x i64] } %t118)
  br label %bb9
bb9:
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t122 = load i32, ptr %l11, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t121, i32 %t122)
  br label %bb10
bb10:
  %t125 = load ptr, ptr %l0, !tbaa !29
  store ptr %t125, ptr %l61, !tbaa !29
  %t126 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t126, ptr %l62
  %t127 = load %"compiler/mir:Lvalue", ptr %l1
  store %"compiler/mir:Lvalue" %t127, ptr %l63
  %t128 = load i32, ptr %l7, !tbaa !23
  %t130 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t128)
  store %"compiler/mir:Lvalue" %t130, ptr %l65
  br label %bb11
bb11:
  %t131 = load { i64, [4 x i64] }, ptr %l9
  store { i64, [21 x i64] } zeroinitializer, ptr %t132
  %t133 = getelementptr { i64, [21 x i64] }, ptr %t132, i32 0, i32 0
  store i64 9, ptr %t133
  %t134 = load %"compiler/source:Span", ptr %l62
  %t135 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", %"compiler/mir:Lvalue", { i64, [4 x i64] } } undef, %"compiler/source:Span" %t134, 0
  %t136 = load %"compiler/mir:Lvalue", ptr %l63
  %t137 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", %"compiler/mir:Lvalue", { i64, [4 x i64] } } %t135, %"compiler/mir:Lvalue" %t136, 1
  %t138 = load %"compiler/mir:Lvalue", ptr %l65
  %t139 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", %"compiler/mir:Lvalue", { i64, [4 x i64] } } %t137, %"compiler/mir:Lvalue" %t138, 2
  %t141 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", %"compiler/mir:Lvalue", { i64, [4 x i64] } } %t139, { i64, [4 x i64] } %t131, 3
  %t142 = getelementptr { i64, [21 x i64] }, ptr %t132, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Lvalue", %"compiler/mir:Lvalue", { i64, [4 x i64] } } %t141, ptr %t142
  %t143 = load { i64, [21 x i64] }, ptr %t132
  store { i64, [21 x i64] } %t143, ptr %l67
  %t144 = load ptr, ptr %l61, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s0, ptr %t144, ptr %l67)
  br label %bb12
bb12:
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t147 = load i32, ptr %l13, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2egoto(ptr %v0, ptr %t146, i32 %t147)
  br label %bb13
bb13:
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t151 = load i32, ptr %l12, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t150, i32 %t151)
  br label %bb14
bb14:
  br i1 %a4, label %bb15, label %bb16
bb15:
  %t156 = load ptr, ptr %l0, !tbaa !29
  store ptr %t156, ptr %l75, !tbaa !29
  %t157 = load i32, ptr %l7, !tbaa !23
  %t159 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t157)
  store %"compiler/mir:Lvalue" %t159, ptr %l77
  br label %bb17
bb16:
  %t160 = load i32, ptr %l7, !tbaa !23
  %t162 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t160)
  store %"compiler/mir:Lvalue" %t162, ptr %l84
  br label %bb19
bb17:
  store { i64, [4 x i64] } zeroinitializer, ptr %t163
  %t164 = getelementptr { i64, [4 x i64] }, ptr %t163, i32 0, i32 0
  store i64 1, ptr %t164
  %t165 = load %"compiler/mir:Lvalue", ptr %l77
  %t166 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t165, 0
  %t167 = getelementptr { i64, [4 x i64] }, ptr %t163, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t166, ptr %t167
  %t168 = load { i64, [4 x i64] }, ptr %t163
  %t169 = load i32, ptr %l3, !tbaa !23
  %t170 = load %"compiler/source:Span", ptr %l5
  %t172 = load ptr, ptr %l75, !tbaa !29
  %t177 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2earrayCopy(ptr %v0, ptr %t172, { i64, [4 x i64] } %t168, i32 %t169, %"compiler/source:Span" %t170, { i64, [1 x i64] } %a6, i1 false)
  store { i64, [4 x i64] } %t177, ptr %l82
  br label %bb18
bb18:
  %t178 = load { i64, [4 x i64] }, ptr %l82
  store { i64, [4 x i64] } %t178, ptr %l74
  br label %bb20
bb19:
  store { i64, [4 x i64] } zeroinitializer, ptr %t179
  %t180 = getelementptr { i64, [4 x i64] }, ptr %t179, i32 0, i32 0
  store i64 1, ptr %t180
  %t181 = load %"compiler/mir:Lvalue", ptr %l84
  %t182 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t181, 0
  %t183 = getelementptr { i64, [4 x i64] }, ptr %t179, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t182, ptr %t183
  %t184 = load { i64, [4 x i64] }, ptr %t179
  store { i64, [4 x i64] } %t184, ptr %l74
  br label %bb20
bb20:
  %t186 = load { i64, [4 x i64] }, ptr %l74
  %t187 = load ptr, ptr %l0, !tbaa !29
  %t188 = load %"compiler/source:Span", ptr %l5
  %t189 = load %"compiler/mir:Lvalue", ptr %l1
  store { i64, [15 x i64] } zeroinitializer, ptr %t191
  %t192 = getelementptr { i64, [15 x i64] }, ptr %t191, i32 0, i32 0
  store i64 0, ptr %t192
  %t194 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t186, 0
  %t195 = getelementptr { i64, [15 x i64] }, ptr %t191, i32 0, i32 1
  store { { i64, [4 x i64] } } %t194, ptr %t195
  %t196 = load { i64, [15 x i64] }, ptr %t191
  store { i64, [21 x i64] } zeroinitializer, ptr %t197
  %t198 = getelementptr { i64, [21 x i64] }, ptr %t197, i32 0, i32 0
  store i64 0, ptr %t198
  %t200 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t188, 0
  %t202 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t200, %"compiler/mir:Lvalue" %t189, 1
  %t204 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t202, { i64, [15 x i64] } %t196, 2
  %t205 = getelementptr { i64, [21 x i64] }, ptr %t197, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t204, ptr %t205
  %t206 = load { i64, [21 x i64] }, ptr %t197
  store { i64, [21 x i64] } %t206, ptr %l91
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s0, ptr %t187, ptr %l91)
  br label %bb21
bb21:
  %t209 = load ptr, ptr %l0, !tbaa !29
  %t210 = load i32, ptr %l13, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2egoto(ptr %v0, ptr %t209, i32 %t210)
  br label %bb22
bb22:
  %t213 = load ptr, ptr %l0, !tbaa !29
  %t214 = load i32, ptr %l13, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t213, i32 %t214)
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2eassert(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l3 = alloca ptr
  %l4 = alloca { i64, [4 x i64] }
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca { i64, [4 x i64] }
  %l10 = alloca ptr
  %l17 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l18 = alloca i1
  %l22 = alloca { i64, [4 x i64] }
  %l27 = alloca i32
  %l30 = alloca i32
  %l45 = alloca { i64, [4 x i64] }
  %s0 = alloca %olang.scope
  %t55 = alloca { i64, [8 x i64] }, align 8
  %t71 = alloca { i64, [4 x i64] }, align 8
  %t91 = alloca { i64, [8 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/lower:Lowerer", ptr %t4, i32 0, i32 8
  store ptr %t6, ptr %l10, !tbaa !29
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/lower:lowering", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/typed:Body", ptr %t10, i32 0, i32 0
  %t13 = load i32, ptr %t12, !tbaa !23
  %t15 = sext i32 %t13 to i64
  %t16 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t17 = load i32, ptr %t16, !tbaa !23
  %t19 = sext i32 %t17 to i64
  %t22 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s0, i64 %t15, i64 %t19)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t22, ptr %l17
  br label %bb1
bb1:
  %t23 = load ptr, ptr %l10, !tbaa !29
  %t24 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l17
  %t25 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %v0, ptr %t23, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t24)
  store i1 %t25, ptr %l18
  br label %bb2
bb2:
  %t26 = load i1, ptr %l18, !tbaa !21
  br i1 %t26, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb4:
  br label %bb5
bb5:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t32 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v1, ptr %t27, ptr %a2)
  store { i64, [4 x i64] } %t32, ptr %l22
  br label %bb6
bb6:
  %t33 = load { i64, [4 x i64] }, ptr %l22
  store { i64, [4 x i64] } %t33, ptr %l4
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/lower:lowering", ptr %t34, i32 0, i32 7
  %t37 = load i1, ptr %t36, !tbaa !21
  br i1 %t37, label %bb7, label %bb8
bb7:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb8:
  br label %bb9
bb9:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/lower:lowering", ptr %t39, i32 0, i32 3
  %t43 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t41)
  store i32 %t43, ptr %l27
  br label %bb10
bb10:
  %t44 = load i32, ptr %l27, !tbaa !23
  store i32 %t44, ptr %l5, !tbaa !23
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/lower:lowering", ptr %t45, i32 0, i32 3
  %t49 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t47)
  store i32 %t49, ptr %l30
  br label %bb11
bb11:
  %t50 = load i32, ptr %l30, !tbaa !23
  store i32 %t50, ptr %l6, !tbaa !23
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t52 = load { i64, [4 x i64] }, ptr %l4
  %t53 = load i32, ptr %l5, !tbaa !23
  %t54 = load i32, ptr %l6, !tbaa !23
  store { i64, [8 x i64] } zeroinitializer, ptr %t55
  %t56 = getelementptr { i64, [8 x i64] }, ptr %t55, i32 0, i32 0
  store i64 2, ptr %t56
  %t58 = insertvalue { { i64, [4 x i64] }, i32, i32 } undef, { i64, [4 x i64] } %t52, 0
  %t60 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t58, i32 %t53, 1
  %t62 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t60, i32 %t54, 2
  %t63 = getelementptr { i64, [8 x i64] }, ptr %t55, i32 0, i32 1
  store { { i64, [4 x i64] }, i32, i32 } %t62, ptr %t63
  %t64 = load { i64, [8 x i64] }, ptr %t55
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t51, { i64, [8 x i64] } %t64)
  br label %bb12
bb12:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t68 = load i32, ptr %l6, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t67, i32 %t68)
  br label %bb13
bb13:
  store { i64, [4 x i64] } zeroinitializer, ptr %t71
  %t72 = getelementptr { i64, [4 x i64] }, ptr %t71, i32 0, i32 0
  store i64 0, ptr %t72
  %t73 = load { i64, [4 x i64] }, ptr %t71
  store { i64, [4 x i64] } %t73, ptr %l7
  %t75 = load ptr, ptr %l3, !tbaa !29
  %t77 = icmp eq ptr %t75, null
  %t79 = xor i1 %t77, true
  br i1 %t79, label %bb14, label %bb15
bb14:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t82 = load ptr, ptr %l3, !tbaa !29
  %t86 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v2, ptr %t81, ptr %t82)
  store { i64, [4 x i64] } %t86, ptr %l45
  br label %bb16
bb15:
  br label %bb17
bb16:
  %t87 = load { i64, [4 x i64] }, ptr %l45
  store { i64, [4 x i64] } %t87, ptr %l7
  br label %bb17
bb17:
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t89 = load %"compiler/source:Span", ptr %l1
  %t90 = load { i64, [4 x i64] }, ptr %l7
  store { i64, [8 x i64] } zeroinitializer, ptr %t91
  %t92 = getelementptr { i64, [8 x i64] }, ptr %t91, i32 0, i32 0
  store i64 9, ptr %t92
  %t94 = insertvalue { %"compiler/source:Span", i32, { i64, [4 x i64] } } undef, %"compiler/source:Span" %t89, 0
  %t96 = insertvalue { %"compiler/source:Span", i32, { i64, [4 x i64] } } %t94, i32 7, 1
  %t98 = insertvalue { %"compiler/source:Span", i32, { i64, [4 x i64] } } %t96, { i64, [4 x i64] } %t90, 2
  %t99 = getelementptr { i64, [8 x i64] }, ptr %t91, i32 0, i32 1
  store { %"compiler/source:Span", i32, { i64, [4 x i64] } } %t98, ptr %t99
  %t100 = load { i64, [8 x i64] }, ptr %t91
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t88, { i64, [8 x i64] } %t100)
  br label %bb18
bb18:
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t104 = load i32, ptr %l5, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t103, i32 %t104)
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eaway(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i64
  %l12 = alloca { i64, [4 x i64] }
  %rv = alloca { i64, [4 x i64] }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 4
  %t4 = load i64, ptr %t3, !tbaa !24
  store i64 %t4, ptr %l3, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/lower:lowering", ptr %t6, i32 0, i32 4
  store i64 %a1, ptr %t10, !tbaa !24
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t16 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v1, ptr %t11, ptr %a2)
  store { i64, [4 x i64] } %t16, ptr %l12
  br label %bb1
bb1:
  %t17 = load { i64, [4 x i64] }, ptr %l12
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t19 = load i64, ptr %l3, !tbaa !24
  %t22 = getelementptr %"compiler/lower:lowering", ptr %t18, i32 0, i32 4
  store i64 %t19, ptr %t22, !tbaa !24
  store { i64, [4 x i64] } %t17, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2ebang(ptr %v0, ptr %a0, { i64, [4 x i64] } %a1, i32 %a2, %"compiler/source:Span" %a3, i32 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i32
  %l13 = alloca i32
  %l18 = alloca { i64, ptr }
  %l24 = alloca i64
  %l27 = alloca i64
  %l47 = alloca i32
  %l50 = alloca i32
  %l55 = alloca { i64, ptr }
  %l58 = alloca { i64, ptr }
  %l60 = alloca { i64, [4 x i64] }
  %l68 = alloca ptr
  %l69 = alloca %"compiler/source:Span"
  %l70 = alloca i32
  %l72 = alloca { i64, ptr }
  %l75 = alloca { i64, ptr }
  %l81 = alloca { i64, [4 x i64] }
  %l87 = alloca ptr
  %l88 = alloca %"compiler/source:Span"
  %l89 = alloca i32
  %l92 = alloca { i64, [4 x i64] }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %t105 = alloca { i64, [8 x i64] }, align 8
  %t149 = alloca { i64, [8 x i64] }, align 8
  %t177 = alloca { i64, [8 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  store %"compiler/source:Span" %a3, ptr %l3
  store i32 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l2, !tbaa !23
  %t3 = load %"compiler/source:Span", ptr %l3
  %t7 = call { i64, ptr } @compiler_2flower_2ecompiler_2flower_3alowering_2ebangNames(ptr %v0, ptr %s0, ptr %t1, i32 %t2, %"compiler/source:Span" %t3)
  store { i64, ptr } %t7, ptr %l18
  br label %bb1
bb1:
  %t8 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t8, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t9 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t9, 0
  store i64 %t11, ptr %l7, !tbaa !24
  store i64 2, ptr %l8, !tbaa !24
  %t13 = load i64, ptr %l7, !tbaa !24
  %t14 = load i64, ptr %l6, !tbaa !24
  %t17 = icmp sgt i64 %t13, %t14
  br i1 %t17, label %bb2, label %bb3
bb2:
  %t19 = load i64, ptr %l8, !tbaa !24
  %t21 = icmp sgt i64 %t19, 0
  br i1 %t21, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l24, !tbaa !24
  br label %bb7
bb4:
  %t23 = load i64, ptr %l7, !tbaa !24
  %t24 = load i64, ptr %l6, !tbaa !24
  %t27 = sub i64 %t23, %t24
  %t28 = load i64, ptr %l8, !tbaa !24
  %t31 = add i64 %t27, %t28
  %t33 = sub i64 %t31, 1
  %t34 = load i64, ptr %l8, !tbaa !24
  %t37 = sdiv i64 %t33, %t34
  store i64 %t37, ptr %l27, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l27, !tbaa !24
  br label %bb6
bb6:
  %t39 = load i64, ptr %l27, !tbaa !24
  store i64 %t39, ptr %l24, !tbaa !24
  br label %bb7
bb7:
  %t40 = load i64, ptr %l24, !tbaa !24
  store i64 %t40, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t41 = load i64, ptr %l10, !tbaa !24
  %t42 = load i64, ptr %l9, !tbaa !24
  %t45 = icmp slt i64 %t41, %t42
  %t47 = xor i1 %t45, true
  br i1 %t47, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb21
bb10:
  br label %bb11
bb11:
  %t49 = load i64, ptr %l6, !tbaa !24
  %t50 = load i64, ptr %l10, !tbaa !24
  %t51 = load i64, ptr %l8, !tbaa !24
  %t54 = mul i64 %t50, %t51
  %t57 = add i64 %t49, %t54
  store i64 %t57, ptr %l11, !tbaa !24
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/lower:lowering", ptr %t59, i32 0, i32 3
  %t63 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t61)
  store i32 %t63, ptr %l47
  br label %bb12
bb12:
  %t64 = load i32, ptr %l47, !tbaa !23
  store i32 %t64, ptr %l12, !tbaa !23
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/lower:lowering", ptr %t65, i32 0, i32 3
  %t69 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t67)
  store i32 %t69, ptr %l50
  br label %bb13
bb13:
  %t70 = load i32, ptr %l50, !tbaa !23
  store i32 %t70, ptr %l13, !tbaa !23
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t72 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t74 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t74, ptr %l55, !tbaa !27
  %t75 = load i64, ptr %l11, !tbaa !24
  %t77 = getelementptr { i64, ptr }, ptr %l55, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !27
  %t79 = getelementptr { i64, [4 x i64] }, ptr %t78, i64 %t75
  %t80 = load { i64, [4 x i64] }, ptr %t79
  %t81 = mul i64 2, 40
  %t82 = call ptr @__olang_scope_alloc_zeroed(ptr %s2, i64 %t81)
  %t83 = insertvalue { i64, ptr } undef, i64 2, 0
  %t84 = insertvalue { i64, ptr } %t83, ptr %t82, 1
  store { i64, ptr } %t84, ptr %l58, !tbaa !27
  %t86 = getelementptr { i64, ptr }, ptr %l58, i32 0, i32 1
  %t87 = load ptr, ptr %t86, !tbaa !27
  %t88 = getelementptr { i64, [4 x i64] }, ptr %t87, i64 0
  store { i64, [4 x i64] } %a1, ptr %t88
  %t90 = getelementptr { i64, ptr }, ptr %l58, i32 0, i32 1
  %t91 = load ptr, ptr %t90, !tbaa !27
  %t92 = getelementptr { i64, [4 x i64] }, ptr %t91, i64 1
  store { i64, [4 x i64] } %t80, ptr %t92
  %t93 = load %"compiler/source:Span", ptr %l3
  %t97 = load { i64, ptr }, ptr %l58, !tbaa !27
  %t99 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s2, ptr %t71, i32 13, i32 %t72, { i64, ptr } %t97, %"compiler/source:Span" %t93)
  store { i64, [4 x i64] } %t99, ptr %l60
  br label %bb14
bb14:
  %t100 = load { i64, [4 x i64] }, ptr %l60
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t103 = load i32, ptr %l12, !tbaa !23
  %t104 = load i32, ptr %l13, !tbaa !23
  store { i64, [8 x i64] } zeroinitializer, ptr %t105
  %t106 = getelementptr { i64, [8 x i64] }, ptr %t105, i32 0, i32 0
  store i64 2, ptr %t106
  %t108 = insertvalue { { i64, [4 x i64] }, i32, i32 } undef, { i64, [4 x i64] } %t100, 0
  %t110 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t108, i32 %t103, 1
  %t112 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t110, i32 %t104, 2
  %t113 = getelementptr { i64, [8 x i64] }, ptr %t105, i32 0, i32 1
  store { { i64, [4 x i64] }, i32, i32 } %t112, ptr %t113
  %t114 = load { i64, [8 x i64] }, ptr %t105
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t101, { i64, [8 x i64] } %t114)
  br label %bb15
bb15:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t118 = load i32, ptr %l12, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t117, i32 %t118)
  br label %bb16
bb16:
  %t121 = load ptr, ptr %l0, !tbaa !29
  store ptr %t121, ptr %l68, !tbaa !29
  %t122 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t122, ptr %l69
  %t123 = load i32, ptr %l4, !range !{i32 0, i32 16}
  store i32 %t123, ptr %l70
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t125 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t125, ptr %l72, !tbaa !27
  %t126 = load i64, ptr %l11, !tbaa !24
  %t128 = getelementptr { i64, ptr }, ptr %l72, i32 0, i32 1
  %t129 = load ptr, ptr %t128, !tbaa !27
  %t130 = getelementptr { i64, [4 x i64] }, ptr %t129, i64 %t126
  %t131 = load { i64, [4 x i64] }, ptr %t130
  %t132 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t132, ptr %l75, !tbaa !27
  %t133 = load i64, ptr %l11, !tbaa !24
  %t135 = add i64 %t133, 1
  %t137 = getelementptr { i64, ptr }, ptr %l75, i32 0, i32 1
  %t138 = load ptr, ptr %t137, !tbaa !27
  %t139 = getelementptr { i64, [4 x i64] }, ptr %t138, i64 %t135
  %t140 = load { i64, [4 x i64] }, ptr %t139
  %t141 = load i32, ptr %l2, !tbaa !23
  %t142 = load %"compiler/source:Span", ptr %l3
  %t148 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ewithPayload(ptr %v0, ptr %t124, { i64, [4 x i64] } %t131, { i64, [4 x i64] } %t140, i32 %t141, %"compiler/source:Span" %t142)
  store { i64, [4 x i64] } %t148, ptr %l81
  br label %bb17
bb17:
  store { i64, [8 x i64] } zeroinitializer, ptr %t149
  %t150 = getelementptr { i64, [8 x i64] }, ptr %t149, i32 0, i32 0
  store i64 9, ptr %t150
  %t151 = load %"compiler/source:Span", ptr %l69
  %t152 = insertvalue { %"compiler/source:Span", i32, { i64, [4 x i64] } } undef, %"compiler/source:Span" %t151, 0
  %t153 = load i32, ptr %l70, !range !{i32 0, i32 16}
  %t154 = insertvalue { %"compiler/source:Span", i32, { i64, [4 x i64] } } %t152, i32 %t153, 1
  %t155 = load { i64, [4 x i64] }, ptr %l81
  %t156 = insertvalue { %"compiler/source:Span", i32, { i64, [4 x i64] } } %t154, { i64, [4 x i64] } %t155, 2
  %t157 = getelementptr { i64, [8 x i64] }, ptr %t149, i32 0, i32 1
  store { %"compiler/source:Span", i32, { i64, [4 x i64] } } %t156, ptr %t157
  %t158 = load { i64, [8 x i64] }, ptr %t149
  %t159 = load ptr, ptr %l68, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t159, { i64, [8 x i64] } %t158)
  br label %bb18
bb18:
  %t161 = load ptr, ptr %l0, !tbaa !29
  %t162 = load i32, ptr %l13, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t161, i32 %t162)
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s2)
  br label %bb20
bb20:
  %t165 = load i64, ptr %l10, !tbaa !24
  %t167 = add i64 %t165, 1
  store i64 %t167, ptr %l10, !tbaa !24
  br label %bb8
bb21:
  %t169 = load ptr, ptr %l0, !tbaa !29
  store ptr %t169, ptr %l87, !tbaa !29
  %t170 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t170, ptr %l88
  %t171 = load i32, ptr %l4, !range !{i32 0, i32 16}
  store i32 %t171, ptr %l89
  %t172 = load ptr, ptr %l0, !tbaa !29
  %t173 = load %"compiler/source:Span", ptr %l3
  %t176 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2etextData(ptr %v0, ptr %s0, ptr %t172, { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d3, i32 0, i32 1) }, %"compiler/source:Span" %t173)
  store { i64, [4 x i64] } %t176, ptr %l92
  br label %bb22
bb22:
  store { i64, [8 x i64] } zeroinitializer, ptr %t177
  %t178 = getelementptr { i64, [8 x i64] }, ptr %t177, i32 0, i32 0
  store i64 9, ptr %t178
  %t179 = load %"compiler/source:Span", ptr %l88
  %t180 = insertvalue { %"compiler/source:Span", i32, { i64, [4 x i64] } } undef, %"compiler/source:Span" %t179, 0
  %t181 = load i32, ptr %l89, !range !{i32 0, i32 16}
  %t182 = insertvalue { %"compiler/source:Span", i32, { i64, [4 x i64] } } %t180, i32 %t181, 1
  %t183 = load { i64, [4 x i64] }, ptr %l92
  %t184 = insertvalue { %"compiler/source:Span", i32, { i64, [4 x i64] } } %t182, { i64, [4 x i64] } %t183, 2
  %t185 = getelementptr { i64, [8 x i64] }, ptr %t177, i32 0, i32 1
  store { %"compiler/source:Span", i32, { i64, [4 x i64] } } %t184, ptr %t185
  %t186 = load { i64, [8 x i64] }, ptr %t177
  %t187 = load ptr, ptr %l87, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t187, { i64, [8 x i64] } %t186)
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { { i64, [7 x i64] }, i32 } @compiler_2flower_2ecompiler_2flower_3alowering_2ebodyCallee(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l1 = alloca i32
  %l2 = alloca i32
  %l9 = alloca ptr
  %rv = alloca { { i64, [7 x i64] }, i32 }
  %t21 = alloca { i64, [2 x i64] }, align 8
  %t28 = alloca { i64, [7 x i64] }, align 8
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/lower:lowering", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/lower:Lowerer", ptr %t4, i32 0, i32 1
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = load i32, ptr %l1, !tbaa !23
  %t11 = sext i32 %t9 to i64
  %t14 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t7, i64 %t11)
  store ptr %t14, ptr %l9
  br label %bb1
bb1:
  %t15 = load ptr, ptr %l9, !tbaa !29
  %t17 = getelementptr %"compiler/typed:Body", ptr %t15, i32 0, i32 2
  %t18 = load i32, ptr %t17, !tbaa !23
  store i32 %t18, ptr %l2, !tbaa !23
  %t20 = load i32, ptr %l1, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t21
  %t22 = getelementptr { i64, [2 x i64] }, ptr %t21, i32 0, i32 0
  store i64 0, ptr %t22
  %t24 = insertvalue { i32 } undef, i32 %t20, 0
  %t25 = getelementptr { i64, [2 x i64] }, ptr %t21, i32 0, i32 1
  store { i32 } %t24, ptr %t25
  %t26 = load { i64, [2 x i64] }, ptr %t21
  %t27 = load i32, ptr %l2, !tbaa !23
  store { i64, [7 x i64] } zeroinitializer, ptr %t28
  %t29 = getelementptr { i64, [7 x i64] }, ptr %t28, i32 0, i32 0
  store i64 0, ptr %t29
  %t31 = insertvalue { { i64, [2 x i64] }, i32 } undef, { i64, [2 x i64] } %t26, 0
  %t33 = insertvalue { { i64, [2 x i64] }, i32 } %t31, i32 %t27, 1
  %t34 = getelementptr { i64, [7 x i64] }, ptr %t28, i32 0, i32 1
  store { { i64, [2 x i64] }, i32 } %t33, ptr %t34
  %t35 = load { i64, [7 x i64] }, ptr %t28
  %t36 = load i32, ptr %l2, !tbaa !23
  %t38 = insertvalue { { i64, [7 x i64] }, i32 } undef, { i64, [7 x i64] } %t35, 0
  %t40 = insertvalue { { i64, [7 x i64] }, i32 } %t38, i32 %t36, 1
  store { { i64, [7 x i64] }, i32 } %t40, ptr %rv
  br label %ret
ret:
  %rr = load { { i64, [7 x i64] }, i32 }, ptr %rv
  ret { { i64, [7 x i64] }, i32 } %rr
}

define dso_local { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ebuilt(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l5 = alloca i1
  %l8 = alloca i1
  %l18 = alloca { i64, ptr }
  %l22 = alloca { i64, [1 x i64] }
  %rv = alloca { i64, [1 x i64] }
  %t28 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 19
  %t4 = load i1, ptr %t3, !tbaa !21
  %t6 = xor i1 %t4, true
  br i1 %t6, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l5, !tbaa !21
  br label %bb3
bb2:
  %t8 = load i32, ptr %l1, !tbaa !23
  %t10 = icmp slt i32 %t8, 0
  store i1 %t10, ptr %l5, !tbaa !21
  br label %bb3
bb3:
  %t12 = load i1, ptr %l5, !tbaa !21
  br i1 %t12, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb6
bb5:
  %t13 = load i32, ptr %l1, !tbaa !23
  %t15 = sext i32 %t13 to i64
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/lower:lowering", ptr %t16, i32 0, i32 24
  %t19 = getelementptr %"compiler/typed:Plan", ptr %t18, i32 0, i32 0
  %t20 = load { i64, ptr }, ptr %t19, !tbaa !27
  %t22 = extractvalue { i64, ptr } %t20, 0
  %t25 = icmp sge i64 %t15, %t22
  store i1 %t25, ptr %l8, !tbaa !21
  br label %bb6
bb6:
  %t27 = load i1, ptr %l8, !tbaa !21
  br i1 %t27, label %bb7, label %bb8
bb7:
  store { i64, [1 x i64] } zeroinitializer, ptr %t28
  %t29 = getelementptr { i64, [1 x i64] }, ptr %t28, i32 0, i32 0
  store i64 2, ptr %t29
  %t30 = load { i64, [1 x i64] }, ptr %t28
  store { i64, [1 x i64] } %t30, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/lower:lowering", ptr %t33, i32 0, i32 24
  %t36 = getelementptr %"compiler/typed:Plan", ptr %t35, i32 0, i32 0
  %t37 = load { i64, ptr }, ptr %t36, !tbaa !27
  store { i64, ptr } %t37, ptr %l18, !tbaa !27
  %t38 = load i32, ptr %l1, !tbaa !23
  %t40 = sext i32 %t38 to i64
  %t42 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = getelementptr { i64, [1 x i64] }, ptr %t43, i64 %t40
  %t45 = load { i64, [1 x i64] }, ptr %t44
  %t48 = call { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2escopeRef(ptr %v0, ptr %t32, { i64, [1 x i64] } %t45)
  store { i64, [1 x i64] } %t48, ptr %l22
  br label %bb10
bb10:
  %t49 = load { i64, [1 x i64] }, ptr %l22
  store { i64, [1 x i64] } %t49, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [1 x i64] }, ptr %rv
  ret { i64, [1 x i64] } %rr
}

define dso_local { { i64, [7 x i64] }, i32 } @compiler_2flower_2ecompiler_2flower_3alowering_2ecallee(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca i32
  %l6 = alloca ptr
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca i64
  %l10 = alloca i32
  %l11 = alloca ptr
  %l12 = alloca i1
  %l19 = alloca { { i64, [7 x i64] }, i32 }
  %l20 = alloca ptr
  %l21 = alloca i1
  %l30 = alloca i32
  %l36 = alloca ptr
  %l37 = alloca i1
  %l44 = alloca { { i64, [7 x i64] }, i32 }
  %l45 = alloca ptr
  %l46 = alloca i1
  %l56 = alloca { { i64, [7 x i64] }, i32 }
  %l57 = alloca ptr
  %l58 = alloca i1
  %rv = alloca { { i64, [7 x i64] }, i32 }
  %t51 = alloca { i64, [7 x i64] }, align 8
  %t136 = alloca { i64, [4 x i64] }, align 8
  %t141 = alloca { i64, [7 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l11, !tbaa !29
  store i1 false, ptr %l12, !tbaa !21
  %t2 = load ptr, ptr %l11, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l11, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 5}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l12, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l12, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [3 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { i32 }, ptr %t12, i32 0, i32 0
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l3, !tbaa !23
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load i32, ptr %l3, !tbaa !23
  %t20 = call { { i64, [7 x i64] }, i32 } @compiler_2flower_2ecompiler_2flower_3alowering_2ebodyCallee(ptr %v0, ptr %t16, i32 %t17)
  store { { i64, [7 x i64] }, i32 } %t20, ptr %l19
  br label %bb6
bb6:
  %t21 = load { { i64, [7 x i64] }, i32 }, ptr %l19
  store { { i64, [7 x i64] }, i32 } %t21, ptr %rv
  br label %ret
bb7:
  %t22 = load ptr, ptr %l1, !tbaa !29
  store ptr %t22, ptr %l20, !tbaa !29
  store i1 false, ptr %l21, !tbaa !21
  %t23 = load ptr, ptr %l20, !tbaa !29
  %t24 = icmp ne ptr %t23, null
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t26 = load ptr, ptr %l20, !tbaa !29
  %t27 = load i64, ptr %t26, !range !{i64 0, i64 5}
  %t29 = icmp eq i64 %t27, 1
  store i1 %t29, ptr %l21, !tbaa !21
  br label %bb9
bb9:
  %t30 = load i1, ptr %l21, !tbaa !21
  br i1 %t30, label %bb10, label %bb11
bb10:
  %t31 = load ptr, ptr %l1, !tbaa !29
  %t33 = getelementptr { i64, [3 x i64] }, ptr %t31, i32 0, i32 1
  %t34 = getelementptr { i64 }, ptr %t33, i32 0, i32 0
  %t35 = load i64, ptr %t34
  store i64 %t35, ptr %l4, !tbaa !24
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/lower:lowering", ptr %t37, i32 0, i32 0
  %t40 = load ptr, ptr %t39, !tbaa !29
  %t42 = getelementptr %"compiler/lower:Lowerer", ptr %t40, i32 0, i32 0
  %t43 = load ptr, ptr %t42, !tbaa !29
  %t44 = load i64, ptr %l4, !tbaa !24
  %t47 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t43, i64 %t44)
  store i32 %t47, ptr %l30
  br label %bb13
bb13:
  %t48 = load i32, ptr %l30, !tbaa !23
  store i32 %t48, ptr %l5, !tbaa !23
  %t49 = load i64, ptr %l4, !tbaa !24
  %t50 = load i32, ptr %l5, !tbaa !23
  store { i64, [7 x i64] } zeroinitializer, ptr %t51
  %t52 = getelementptr { i64, [7 x i64] }, ptr %t51, i32 0, i32 0
  store i64 1, ptr %t52
  %t54 = insertvalue { i64, i32 } undef, i64 %t49, 0
  %t56 = insertvalue { i64, i32 } %t54, i32 %t50, 1
  %t57 = getelementptr { i64, [7 x i64] }, ptr %t51, i32 0, i32 1
  store { i64, i32 } %t56, ptr %t57
  %t58 = load { i64, [7 x i64] }, ptr %t51
  %t59 = load i32, ptr %l5, !tbaa !23
  %t61 = insertvalue { { i64, [7 x i64] }, i32 } undef, { i64, [7 x i64] } %t58, 0
  %t63 = insertvalue { { i64, [7 x i64] }, i32 } %t61, i32 %t59, 1
  store { { i64, [7 x i64] }, i32 } %t63, ptr %rv
  br label %ret
bb14:
  %t65 = load ptr, ptr %l1, !tbaa !29
  store ptr %t65, ptr %l36, !tbaa !29
  store i1 false, ptr %l37, !tbaa !21
  %t66 = load ptr, ptr %l36, !tbaa !29
  %t67 = icmp ne ptr %t66, null
  br i1 %t67, label %bb15, label %bb16
bb15:
  %t69 = load ptr, ptr %l36, !tbaa !29
  %t70 = load i64, ptr %t69, !range !{i64 0, i64 5}
  %t72 = icmp eq i64 %t70, 2
  store i1 %t72, ptr %l37, !tbaa !21
  br label %bb16
bb16:
  %t73 = load i1, ptr %l37, !tbaa !21
  br i1 %t73, label %bb17, label %bb18
bb17:
  %t74 = load ptr, ptr %l1, !tbaa !29
  %t76 = getelementptr { i64, [3 x i64] }, ptr %t74, i32 0, i32 1
  %t77 = getelementptr { ptr }, ptr %t76, i32 0, i32 0
  %t78 = load ptr, ptr %t77
  store ptr %t78, ptr %l6, !tbaa !29
  br label %bb19
bb18:
  br label %bb21
bb19:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t81 = load ptr, ptr %l6, !tbaa !29
  %t84 = call { { i64, [7 x i64] }, i32 } @compiler_2flower_2ecompiler_2flower_3alowering_2evalueCallee(ptr %v0, ptr %v1, ptr %t80, ptr %t81)
  store { { i64, [7 x i64] }, i32 } %t84, ptr %l44
  br label %bb20
bb20:
  %t85 = load { { i64, [7 x i64] }, i32 }, ptr %l44
  store { { i64, [7 x i64] }, i32 } %t85, ptr %rv
  br label %ret
bb21:
  %t86 = load ptr, ptr %l1, !tbaa !29
  store ptr %t86, ptr %l45, !tbaa !29
  store i1 false, ptr %l46, !tbaa !21
  %t87 = load ptr, ptr %l45, !tbaa !29
  %t88 = icmp ne ptr %t87, null
  br i1 %t88, label %bb22, label %bb23
bb22:
  %t90 = load ptr, ptr %l45, !tbaa !29
  %t91 = load i64, ptr %t90, !range !{i64 0, i64 5}
  %t93 = icmp eq i64 %t91, 4
  store i1 %t93, ptr %l46, !tbaa !21
  br label %bb23
bb23:
  %t94 = load i1, ptr %l46, !tbaa !21
  br i1 %t94, label %bb24, label %bb25
bb24:
  %t95 = load ptr, ptr %l1, !tbaa !29
  %t97 = getelementptr { i64, [3 x i64] }, ptr %t95, i32 0, i32 1
  %t98 = getelementptr { i32, i32 }, ptr %t97, i32 0, i32 0
  %t99 = load i32, ptr %t98, !range !{i32 0, i32 2}
  store i32 %t99, ptr %l7
  %t101 = load ptr, ptr %l1, !tbaa !29
  %t103 = getelementptr { i64, [3 x i64] }, ptr %t101, i32 0, i32 1
  %t104 = getelementptr { i32, i32 }, ptr %t103, i32 0, i32 1
  %t105 = load i32, ptr %t104
  store i32 %t105, ptr %l8, !tbaa !23
  br label %bb26
bb25:
  br label %bb28
bb26:
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t108 = load i32, ptr %l7, !range !{i32 0, i32 2}
  %t109 = load i32, ptr %l8, !tbaa !23
  %t113 = call { { i64, [7 x i64] }, i32 } @compiler_2flower_2ecompiler_2flower_3alowering_2ehelperCallee(ptr %v0, ptr %t107, i32 %t108, i32 %t109)
  store { { i64, [7 x i64] }, i32 } %t113, ptr %l56
  br label %bb27
bb27:
  %t114 = load { { i64, [7 x i64] }, i32 }, ptr %l56
  store { { i64, [7 x i64] }, i32 } %t114, ptr %rv
  br label %ret
bb28:
  %t115 = load ptr, ptr %l1, !tbaa !29
  store ptr %t115, ptr %l57, !tbaa !29
  store i1 false, ptr %l58, !tbaa !21
  %t116 = load ptr, ptr %l57, !tbaa !29
  %t117 = icmp ne ptr %t116, null
  br i1 %t117, label %bb29, label %bb30
bb29:
  %t119 = load ptr, ptr %l57, !tbaa !29
  %t120 = load i64, ptr %t119, !range !{i64 0, i64 5}
  %t122 = icmp eq i64 %t120, 3
  store i1 %t122, ptr %l58, !tbaa !21
  br label %bb30
bb30:
  %t123 = load i1, ptr %l58, !tbaa !21
  br i1 %t123, label %bb31, label %bb32
bb31:
  %t124 = load ptr, ptr %l1, !tbaa !29
  %t126 = getelementptr { i64, [3 x i64] }, ptr %t124, i32 0, i32 1
  %t127 = getelementptr { i32, i64, i32 }, ptr %t126, i32 0, i32 1
  %t128 = load i64, ptr %t127
  store i64 %t128, ptr %l9, !tbaa !24
  %t130 = load ptr, ptr %l1, !tbaa !29
  %t132 = getelementptr { i64, [3 x i64] }, ptr %t130, i32 0, i32 1
  %t133 = getelementptr { i32, i64, i32 }, ptr %t132, i32 0, i32 2
  %t134 = load i32, ptr %t133
  store i32 %t134, ptr %l10, !tbaa !23
  br label %bb33
bb32:
  br label %bb34
bb33:
  store { i64, [4 x i64] } zeroinitializer, ptr %t136
  %t137 = getelementptr { i64, [4 x i64] }, ptr %t136, i32 0, i32 0
  store i64 0, ptr %t137
  %t138 = load { i64, [4 x i64] }, ptr %t136
  %t139 = load i64, ptr %l9, !tbaa !24
  %t140 = load i32, ptr %l10, !tbaa !23
  store { i64, [7 x i64] } zeroinitializer, ptr %t141
  %t142 = getelementptr { i64, [7 x i64] }, ptr %t141, i32 0, i32 0
  store i64 3, ptr %t142
  %t144 = insertvalue { { i64, [4 x i64] }, i64, i32 } undef, { i64, [4 x i64] } %t138, 0
  %t146 = insertvalue { { i64, [4 x i64] }, i64, i32 } %t144, i64 %t139, 1
  %t148 = insertvalue { { i64, [4 x i64] }, i64, i32 } %t146, i32 %t140, 2
  %t149 = getelementptr { i64, [7 x i64] }, ptr %t141, i32 0, i32 1
  store { { i64, [4 x i64] }, i64, i32 } %t148, ptr %t149
  %t150 = load { i64, [7 x i64] }, ptr %t141
  %t151 = load i32, ptr %l10, !tbaa !23
  %t153 = insertvalue { { i64, [7 x i64] }, i32 } undef, { i64, [7 x i64] } %t150, 0
  %t155 = insertvalue { { i64, [7 x i64] }, i32 } %t153, i32 %t151, 1
  store { { i64, [7 x i64] }, i32 } %t155, ptr %rv
  br label %ret
bb34:
  call void @__olang_check_failed(ptr @olang_loc_21e9da82ebd620c7_b6074e807b9f75fb)
  unreachable
ret:
  %rr = load { { i64, [7 x i64] }, i32 }, ptr %rv
  ret { { i64, [7 x i64] }, i32 } %rr
}

define dso_local { i64, ptr } @compiler_2flower_2ecompiler_2flower_3alowering_2ecasesOf(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"compiler/lower:lowering", ptr %t2, i32 0, i32 2
  %t5 = load ptr, ptr %t4, !tbaa !29
  %t9 = call i32 @compiler_2fmir_2eCasesOf(ptr %v0, ptr %t5, i32 %a1)
  store i32 %t9, ptr %l6
  br label %bb1
bb1:
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t11 = load i32, ptr %l6, !tbaa !23
  %t12 = call { i64, ptr } @compiler_2flower_2ecompiler_2flower_3alowering_2eitems(ptr %v0, ptr %v1, ptr %t10, i32 %t11)
  store { i64, ptr } %t12, ptr %l7
  br label %bb2
bb2:
  %t13 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t13, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2echeck(ptr %v0, ptr %a0, { i64, [4 x i64] } %a1, i32 %a2, i32 %a3, i64 %a4, %"compiler/source:Span" %a5) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca { i32, i64 }
  %l13 = alloca i1
  %l18 = alloca i32
  %l21 = alloca i32
  %l39 = alloca { i32, i64 }
  %l42 = alloca ptr
  %l45 = alloca { i64, [4 x i64] }
  %l49 = alloca i32
  %t28 = alloca { i64, [8 x i64] }, align 8
  %t52 = alloca { i64, [4 x i64] }, align 8
  %t55 = alloca { i64, [8 x i64] }, align 8
  %t85 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  store %"compiler/source:Span" %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 7
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l13, !tbaa !21
  br label %bb3
bb2:
  %t6 = load i32, ptr %l2, !range !{i32 0, i32 3}
  %t8 = trunc i64 0 to i32
  %t9 = icmp eq i32 %t6, %t8
  store i1 %t9, ptr %l13, !tbaa !21
  br label %bb3
bb3:
  %t11 = load i1, ptr %l13, !tbaa !21
  br i1 %t11, label %bb4, label %bb5
bb4:
  br label %ret
bb5:
  br label %bb6
bb6:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/lower:lowering", ptr %t12, i32 0, i32 3
  %t16 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t14)
  store i32 %t16, ptr %l18
  br label %bb7
bb7:
  %t17 = load i32, ptr %l18, !tbaa !23
  store i32 %t17, ptr %l6, !tbaa !23
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/lower:lowering", ptr %t18, i32 0, i32 3
  %t22 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t20)
  store i32 %t22, ptr %l21
  br label %bb8
bb8:
  %t23 = load i32, ptr %l21, !tbaa !23
  store i32 %t23, ptr %l7, !tbaa !23
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = load i32, ptr %l6, !tbaa !23
  %t27 = load i32, ptr %l7, !tbaa !23
  store { i64, [8 x i64] } zeroinitializer, ptr %t28
  %t29 = getelementptr { i64, [8 x i64] }, ptr %t28, i32 0, i32 0
  store i64 2, ptr %t29
  %t31 = insertvalue { { i64, [4 x i64] }, i32, i32 } undef, { i64, [4 x i64] } %a1, 0
  %t33 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t31, i32 %t26, 1
  %t35 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t33, i32 %t27, 2
  %t36 = getelementptr { i64, [8 x i64] }, ptr %t28, i32 0, i32 1
  store { { i64, [4 x i64] }, i32, i32 } %t35, ptr %t36
  %t37 = load { i64, [8 x i64] }, ptr %t28
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t24, { i64, [8 x i64] } %t37)
  br label %bb9
bb9:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t41 = load i32, ptr %l7, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t40, i32 %t41)
  br label %bb10
bb10:
  %t44 = load i32, ptr %l2, !range !{i32 0, i32 3}
  %t46 = trunc i64 1 to i32
  %t47 = icmp eq i32 %t44, %t46
  br i1 %t47, label %bb11, label %bb12
bb11:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t50 = load %"compiler/source:Span", ptr %l5
  store { i64, [4 x i64] } zeroinitializer, ptr %t52
  %t53 = getelementptr { i64, [4 x i64] }, ptr %t52, i32 0, i32 0
  store i64 0, ptr %t53
  %t54 = load { i64, [4 x i64] }, ptr %t52
  store { i64, [8 x i64] } zeroinitializer, ptr %t55
  %t56 = getelementptr { i64, [8 x i64] }, ptr %t55, i32 0, i32 0
  store i64 9, ptr %t56
  %t58 = insertvalue { %"compiler/source:Span", i32, { i64, [4 x i64] } } undef, %"compiler/source:Span" %t50, 0
  %t60 = insertvalue { %"compiler/source:Span", i32, { i64, [4 x i64] } } %t58, i32 %a3, 1
  %t62 = insertvalue { %"compiler/source:Span", i32, { i64, [4 x i64] } } %t60, { i64, [4 x i64] } %t54, 2
  %t63 = getelementptr { i64, [8 x i64] }, ptr %t55, i32 0, i32 1
  store { %"compiler/source:Span", i32, { i64, [4 x i64] } } %t62, ptr %t63
  %t64 = load { i64, [8 x i64] }, ptr %t55
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t49, { i64, [8 x i64] } %t64)
  br label %bb13
bb12:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/lower:lowering", ptr %t67, i32 0, i32 0
  %t70 = load ptr, ptr %t69, !tbaa !29
  %t74 = call { i32, i64 } @compiler_2flower_2ecompiler_2flower_3aLowerer_2efailure(ptr %v0, ptr %t70, i64 %a4)
  store { i32, i64 } %t74, ptr %l39
  br label %bb14
bb13:
  br label %bb17
bb14:
  %t75 = load { i32, i64 }, ptr %l39
  store { i32, i64 } %t75, ptr %l8
  %t76 = getelementptr { i32, i64 }, ptr %l8, i32 0, i32 0
  %t77 = load i32, ptr %t76, !tbaa !23
  %t79 = getelementptr { i32, i64 }, ptr %l8, i32 0, i32 1
  %t80 = load i64, ptr %t79, !tbaa !24
  %t82 = load ptr, ptr %l0, !tbaa !29
  store ptr %t82, ptr %l42, !tbaa !29
  %t83 = load i32, ptr @G_2ecompiler_2fmir_2eI32T, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t85
  %t86 = getelementptr { i64, [4 x i64] }, ptr %t85, i32 0, i32 0
  store i64 2, ptr %t86
  %t88 = insertvalue { i32, i64 } undef, i32 %t83, 0
  %t90 = insertvalue { i32, i64 } %t88, i64 %t80, 1
  %t91 = getelementptr { i64, [4 x i64] }, ptr %t85, i32 0, i32 1
  store { i32, i64 } %t90, ptr %t91
  %t92 = load { i64, [4 x i64] }, ptr %t85
  store { i64, [4 x i64] } %t92, ptr %l45
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/lower:lowering", ptr %t93, i32 0, i32 2
  %t96 = load ptr, ptr %t95, !tbaa !29
  %t100 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList1(ptr %v0, ptr %t96, i32 %t77)
  store i32 %t100, ptr %l49
  br label %bb15
bb15:
  %t101 = load %"compiler/source:Span", ptr %l5
  %t102 = load ptr, ptr %l42, !tbaa !29
  %t103 = load { i64, [4 x i64] }, ptr %l45
  %t104 = load i32, ptr %l49, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2edispatch(ptr %v0, ptr %t102, { i64, [4 x i64] } %t103, i32 %t104, %"compiler/source:Span" %t101, i1 true)
  br label %bb16
bb16:
  br label %bb17
bb17:
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t107 = load i32, ptr %l6, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t106, i32 %t107)
  br label %bb18
bb18:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2ecleanup(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i64
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i32
  %l11 = alloca i32
  %l14 = alloca i32
  %l19 = alloca { i64, [21 x i64] }
  %l28 = alloca ptr
  %l32 = alloca ptr
  %s0 = alloca %olang.scope
  %t24 = alloca { i64, [21 x i64] }, align 8
  %t71 = alloca { i64, [8 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 7
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/lower:lowering", ptr %t6, i32 0, i32 11
  %t9 = load i64, ptr %l2, !tbaa !24
  %t12 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2eAt_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t8, i64 %t9)
  store i32 %t12, ptr %l11
  br label %bb4
bb4:
  %t13 = load i32, ptr %l11, !tbaa !23
  store i32 %t13, ptr %l3, !tbaa !23
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/lower:lowering", ptr %t14, i32 0, i32 3
  %t18 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t16)
  store i32 %t18, ptr %l14
  br label %bb5
bb5:
  %t19 = load i32, ptr %l14, !tbaa !23
  store i32 %t19, ptr %l4, !tbaa !23
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load %"compiler/source:Span", ptr %l1
  %t22 = load i32, ptr %l3, !tbaa !23
  %t23 = load i32, ptr %l4, !tbaa !23
  store { i64, [21 x i64] } zeroinitializer, ptr %t24
  %t25 = getelementptr { i64, [21 x i64] }, ptr %t24, i32 0, i32 0
  store i64 14, ptr %t25
  %t27 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %t21, 0
  %t29 = insertvalue { %"compiler/source:Span", i32, i32 } %t27, i32 %t22, 1
  %t31 = insertvalue { %"compiler/source:Span", i32, i32 } %t29, i32 %t23, 2
  %t32 = getelementptr { i64, [21 x i64] }, ptr %t24, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t31, ptr %t32
  %t33 = load { i64, [21 x i64] }, ptr %t24
  store { i64, [21 x i64] } %t33, ptr %l19
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s0, ptr %t20, ptr %l19)
  br label %bb6
bb6:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/lower:lowering", ptr %t36, i32 0, i32 6
  %t39 = load i32, ptr %t38, !tbaa !23
  store i32 %t39, ptr %l5, !tbaa !23
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t42 = load i32, ptr %l4, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t41, i32 %t42)
  br label %bb7
bb7:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/lower:lowering", ptr %t45, i32 0, i32 11
  %t48 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2eSetAt_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t47, i64 %t48, i32 -1)
  br label %bb8
bb8:
  %t51 = load ptr, ptr %l0, !tbaa !29
  store ptr %t51, ptr %l28, !tbaa !29
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/lower:lowering", ptr %t52, i32 0, i32 10
  %t55 = load i64, ptr %l2, !tbaa !24
  %t58 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlock_26_3e_2eAt_3ccompiler_2ftyped_3aBlock_26_3e(ptr %v0, ptr %v0, ptr %t54, i64 %t55)
  store ptr %t58, ptr %l32
  br label %bb9
bb9:
  %t59 = load ptr, ptr %l28, !tbaa !29
  %t60 = load ptr, ptr %l32, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eblock(ptr %v0, ptr %v0, ptr %t59, ptr %t60)
  br label %bb10
bb10:
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = getelementptr %"compiler/lower:lowering", ptr %t61, i32 0, i32 11
  %t64 = load i64, ptr %l2, !tbaa !24
  %t65 = load i32, ptr %l3, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2eSetAt_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t63, i64 %t64, i32 %t65)
  br label %bb11
bb11:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t70 = load %"compiler/source:Span", ptr %l1
  store { i64, [8 x i64] } zeroinitializer, ptr %t71
  %t72 = getelementptr { i64, [8 x i64] }, ptr %t71, i32 0, i32 0
  store i64 10, ptr %t72
  %t74 = insertvalue { %"compiler/source:Span" } undef, %"compiler/source:Span" %t70, 0
  %t75 = getelementptr { i64, [8 x i64] }, ptr %t71, i32 0, i32 1
  store { %"compiler/source:Span" } %t74, ptr %t75
  %t76 = load { i64, [8 x i64] }, ptr %t71
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t69, { i64, [8 x i64] } %t76)
  br label %bb12
bb12:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t80 = load i32, ptr %l5, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t79, i32 %t80)
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ecopyHome(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [1 x i64] }
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca %"compiler/lower:level"
  %l11 = alloca i64
  %l13 = alloca i64
  %l18 = alloca %"compiler/lower:level"
  %l26 = alloca { i64, [1 x i64] }
  %rv = alloca { i64, [1 x i64] }
  %t38 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  store { i64, [1 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [1 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [1 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 3
  %t6 = xor i1 %t4, true
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t8 = load { i64, [1 x i64] }, ptr %l1
  store { i64, [1 x i64] } %t8, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/lower:lowering", ptr %t10, i32 0, i32 9
  store ptr %t12, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb4
bb4:
  %t14 = load i64, ptr %l3, !tbaa !24
  store i64 %t14, ptr %l11, !tbaa !24
  %t15 = load ptr, ptr %l2, !tbaa !29
  %t17 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3alevel_3e_2eLen_3ccompiler_2flower_3alevel_3e(ptr %v0, ptr %t15)
  store i64 %t17, ptr %l13
  br label %bb5
bb5:
  %t18 = load i64, ptr %l11, !tbaa !24
  %t19 = load i64, ptr %l13, !tbaa !24
  %t20 = icmp slt i64 %t18, %t19
  %t22 = xor i1 %t20, true
  br i1 %t22, label %bb6, label %bb7
bb6:
  br label %bb14
bb7:
  br label %bb8
bb8:
  %t24 = load ptr, ptr %l2, !tbaa !29
  %t25 = load i64, ptr %l3, !tbaa !24
  %t28 = call %"compiler/lower:level" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3alevel_3e_2eAt_3ccompiler_2flower_3alevel_3e(ptr %v0, ptr %t24, i64 %t25)
  store %"compiler/lower:level" %t28, ptr %l18
  br label %bb9
bb9:
  %t29 = load %"compiler/lower:level", ptr %l18
  store %"compiler/lower:level" %t29, ptr %l4
  %t30 = getelementptr %"compiler/lower:level", ptr %l4, i32 0, i32 2
  %t31 = load i32, ptr %t30, !range !{i32 0, i32 7}
  %t33 = trunc i64 0 to i32
  %t34 = icmp eq i32 %t31, %t33
  br i1 %t34, label %bb10, label %bb11
bb10:
  %t36 = getelementptr %"compiler/lower:level", ptr %l4, i32 0, i32 0
  %t37 = load i32, ptr %t36, !tbaa !23
  store { i64, [1 x i64] } zeroinitializer, ptr %t38
  %t39 = getelementptr { i64, [1 x i64] }, ptr %t38, i32 0, i32 0
  store i64 0, ptr %t39
  %t41 = insertvalue { i32 } undef, i32 %t37, 0
  %t42 = getelementptr { i64, [1 x i64] }, ptr %t38, i32 0, i32 1
  store { i32 } %t41, ptr %t42
  %t43 = load { i64, [1 x i64] }, ptr %t38
  store { i64, [1 x i64] } %t43, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  br label %bb13
bb13:
  %t45 = load i64, ptr %l3, !tbaa !24
  %t47 = add i64 %t45, 1
  store i64 %t47, ptr %l3, !tbaa !24
  br label %bb4
bb14:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = call { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einnermost(ptr %v0, ptr %t49)
  store { i64, [1 x i64] } %t51, ptr %l26
  br label %bb15
bb15:
  %t52 = load { i64, [1 x i64] }, ptr %l26
  store { i64, [1 x i64] } %t52, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [1 x i64] }, ptr %rv
  ret { i64, [1 x i64] } %rr
}

define dso_local { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ecopyLocal(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca %"compiler/mir:Lvalue"
  %rv = alloca { i64, [4 x i64] }
  %t4 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %a1)
  store %"compiler/mir:Lvalue" %t3, ptr %l3
  br label %bb1
bb1:
  store { i64, [4 x i64] } zeroinitializer, ptr %t4
  %t5 = getelementptr { i64, [4 x i64] }, ptr %t4, i32 0, i32 0
  store i64 1, ptr %t5
  %t6 = load %"compiler/mir:Lvalue", ptr %l3
  %t7 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t6, 0
  %t8 = getelementptr { i64, [4 x i64] }, ptr %t4, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t7, ptr %t8
  %t9 = load { i64, [4 x i64] }, ptr %t4
  store { i64, [4 x i64] } %t9, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2ecoverAdd(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i32
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l18 = alloca i1
  %l23 = alloca i1
  %l30 = alloca i32
  %l37 = alloca i32
  %l40 = alloca ptr
  %l43 = alloca i32
  %l50 = alloca ptr
  %l53 = alloca i32
  %l54 = alloca { i64, ptr }
  %l61 = alloca { i64, ptr }
  %l76 = alloca { i64, ptr }
  %l84 = alloca { i64, ptr }
  %s9 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t6 = load i64, ptr %l2, !tbaa !24
  %t8 = icmp sgt i64 %t6, 16
  br i1 %t8, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l18, !tbaa !21
  br label %bb4
bb2:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/lower:lowering", ptr %t10, i32 0, i32 36
  %t13 = load i32, ptr %l1, !tbaa !23
  %t15 = sext i32 %t13 to i64
  %t18 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %t12, i64 %t15)
  store i1 %t18, ptr %l23
  br label %bb3
bb3:
  %t19 = load i1, ptr %l23, !tbaa !21
  store i1 %t19, ptr %l18, !tbaa !21
  br label %bb4
bb4:
  %t20 = load i1, ptr %l18, !tbaa !21
  br i1 %t20, label %bb5, label %bb6
bb5:
  br label %ret
bb6:
  br label %bb7
bb7:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/lower:lowering", ptr %t21, i32 0, i32 36
  %t24 = load i32, ptr %l1, !tbaa !23
  %t26 = sext i32 %t24 to i64
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t23, i64 %t26, i1 true)
  br label %bb8
bb8:
  %t29 = load ptr, ptr %l3, !tbaa !29
  %t30 = load i32, ptr %l1, !tbaa !23
  %t33 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t29, i32 %t30)
  store i32 %t33, ptr %l30
  br label %bb9
bb9:
  %t34 = load i32, ptr %l30, !tbaa !23
  store i32 %t34, ptr %l4, !tbaa !23
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/lower:lowering", ptr %t35, i32 0, i32 36
  %t38 = load i32, ptr %l4, !tbaa !23
  %t40 = sext i32 %t38 to i64
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t37, i64 %t40, i1 true)
  br label %bb10
bb10:
  %t43 = load ptr, ptr %l3, !tbaa !29
  %t44 = load i32, ptr %l4, !tbaa !23
  %t47 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t43, i32 %t44)
  store i32 %t47, ptr %l37
  br label %bb11
bb11:
  %t48 = load i32, ptr %l37, !range !{i32 0, i32 33}
  store i32 %t48, ptr %l5
  %t49 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t51 = trunc i64 19 to i32
  %t52 = icmp eq i32 %t49, %t51
  br i1 %t52, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb17
bb14:
  %t54 = load ptr, ptr %l0, !tbaa !29
  store ptr %t54, ptr %l40, !tbaa !29
  %t55 = load ptr, ptr %l3, !tbaa !29
  %t56 = load i32, ptr %l4, !tbaa !23
  %t59 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t55, i32 %t56)
  store i32 %t59, ptr %l43
  br label %bb15
bb15:
  %t60 = load i64, ptr %l2, !tbaa !24
  %t62 = add i64 %t60, 1
  %t63 = load ptr, ptr %l40, !tbaa !29
  %t64 = load i32, ptr %l43, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2ecoverAdd(ptr %v0, ptr %t63, i32 %t64, i64 %t62)
  br label %bb16
bb16:
  br label %bb52
bb17:
  %t66 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t68 = trunc i64 22 to i32
  %t69 = icmp eq i32 %t66, %t68
  br i1 %t69, label %bb18, label %bb19
bb18:
  br label %bb22
bb19:
  %t71 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t73 = trunc i64 23 to i32
  %t74 = icmp eq i32 %t71, %t73
  br i1 %t74, label %bb20, label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb35
bb22:
  %t76 = load ptr, ptr %l3, !tbaa !29
  store ptr %t76, ptr %l50, !tbaa !29
  %t77 = load ptr, ptr %l3, !tbaa !29
  %t78 = load i32, ptr %l4, !tbaa !23
  %t81 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t77, i32 %t78)
  store i32 %t81, ptr %l53
  br label %bb23
bb23:
  %t82 = load ptr, ptr %l50, !tbaa !29
  %t83 = load i32, ptr %l53, !tbaa !23
  %t84 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t82, i32 %t83)
  store { i64, ptr } %t84, ptr %l54
  br label %bb24
bb24:
  %t85 = load { i64, ptr }, ptr %l54, !tbaa !27
  store { i64, ptr } %t85, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t86 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t88 = extractvalue { i64, ptr } %t86, 0
  store i64 %t88, ptr %l8, !tbaa !24
  br label %bb25
bb25:
  %t90 = load i64, ptr %l7, !tbaa !24
  %t91 = load i64, ptr %l8, !tbaa !24
  %t94 = icmp slt i64 %t90, %t91
  %t96 = xor i1 %t94, true
  br i1 %t96, label %bb26, label %bb27
bb26:
  br label %bb34
bb27:
  br label %bb28
bb28:
  %t98 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t98, ptr %l61, !tbaa !27
  %t99 = load i64, ptr %l7, !tbaa !24
  %t101 = getelementptr { i64, ptr }, ptr %l61, i32 0, i32 1
  %t102 = load ptr, ptr %t101, !tbaa !27
  %t103 = getelementptr i32, ptr %t102, i64 %t99
  %t104 = load i32, ptr %t103, !tbaa !33
  store i32 %t104, ptr %l9, !tbaa !23
  %t106 = load i32, ptr %l9, !tbaa !23
  %t108 = icmp ne i32 %t106, 0
  br i1 %t108, label %bb29, label %bb30
bb29:
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t111 = load i32, ptr %l9, !tbaa !23
  %t112 = load i64, ptr %l2, !tbaa !24
  %t114 = add i64 %t112, 1
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2ecoverAdd(ptr %v0, ptr %t110, i32 %t111, i64 %t114)
  br label %bb31
bb30:
  br label %bb32
bb31:
  br label %bb32
bb32:
  br label %bb33
bb33:
  %t118 = load i64, ptr %l7, !tbaa !24
  %t120 = add i64 %t118, 1
  store i64 %t120, ptr %l7, !tbaa !24
  br label %bb25
bb34:
  br label %bb52
bb35:
  %t122 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t124 = trunc i64 18 to i32
  %t125 = icmp eq i32 %t122, %t124
  br i1 %t125, label %bb36, label %bb37
bb36:
  br label %bb38
bb37:
  br label %bb47
bb38:
  store %olang.scope zeroinitializer, ptr %s9
  %t127 = load ptr, ptr %l3, !tbaa !29
  %t128 = load i32, ptr %l4, !tbaa !23
  %t131 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eEmbedded(ptr %v0, ptr %s9, ptr %t127, i32 %t128)
  store { i64, ptr } %t131, ptr %l76
  br label %bb39
bb39:
  %t132 = load { i64, ptr }, ptr %l76, !tbaa !27
  %t133 = extractvalue { i64, ptr } %t132, 0
  %t134 = extractvalue { i64, ptr } %t132, 1
  %t135 = mul i64 %t133, 4
  %t136 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t135)
  call void @llvm.memcpy.p0.p0.i64(ptr %t136, ptr %t134, i64 %t135, i1 false)
  %t137 = insertvalue { i64, ptr } undef, i64 %t133, 0
  %t138 = insertvalue { i64, ptr } %t137, ptr %t136, 1
  store { i64, ptr } %t138, ptr %l10, !tbaa !27
  store i64 0, ptr %l11, !tbaa !24
  %t140 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t142 = extractvalue { i64, ptr } %t140, 0
  store i64 %t142, ptr %l12, !tbaa !24
  br label %bb40
bb40:
  %t144 = load i64, ptr %l11, !tbaa !24
  %t145 = load i64, ptr %l12, !tbaa !24
  %t148 = icmp slt i64 %t144, %t145
  %t150 = xor i1 %t148, true
  br i1 %t150, label %bb41, label %bb42
bb41:
  br label %bb46
bb42:
  br label %bb43
bb43:
  %t152 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t152, ptr %l84, !tbaa !27
  %t153 = load i64, ptr %l11, !tbaa !24
  %t155 = getelementptr { i64, ptr }, ptr %l84, i32 0, i32 1
  %t156 = load ptr, ptr %t155, !tbaa !27
  %t157 = getelementptr i32, ptr %t156, i64 %t153
  %t158 = load i32, ptr %t157, !tbaa !33
  %t160 = load ptr, ptr %l0, !tbaa !29
  %t162 = load i64, ptr %l2, !tbaa !24
  %t164 = add i64 %t162, 1
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2ecoverAdd(ptr %v0, ptr %t160, i32 %t158, i64 %t164)
  br label %bb44
bb44:
  br label %bb45
bb45:
  %t168 = load i64, ptr %l11, !tbaa !24
  %t170 = add i64 %t168, 1
  store i64 %t170, ptr %l11, !tbaa !24
  br label %bb40
bb46:
  call void @__olang_scope_close(ptr %s9)
  br label %bb52
bb47:
  br i1 true, label %bb48, label %bb49
bb48:
  br label %bb50
bb49:
  br label %bb51
bb50:
  br label %bb52
bb51:
  call void @__olang_check_failed(ptr @olang_loc_b57cc0c231802eb3_c3a9863fe509851f)
  unreachable
bb52:
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2ederef(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca { i64, [4 x i64] }
  %l8 = alloca { i64, [4 x i64] }
  %l12 = alloca %"compiler/lower:pl"
  %l13 = alloca ptr
  %l14 = alloca { i64, [4 x i64] }
  %l16 = alloca i32
  %l18 = alloca i32
  %l19 = alloca ptr
  %l22 = alloca %"compiler/lower:pl"
  %l24 = alloca %"compiler/lower:pl"
  %rv = alloca %"compiler/lower:pl"
  %t13 = alloca { i64, [2 x i64] }, align 8
  %t33 = alloca { i64, [2 x i64] }, align 8
  %t41 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t6 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v1, ptr %t1, ptr %t2)
  store { i64, [4 x i64] } %t6, ptr %l8
  br label %bb1
bb1:
  %t7 = load { i64, [4 x i64] }, ptr %l8
  store { i64, [4 x i64] } %t7, ptr %l3
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/lower:lowering", ptr %t8, i32 0, i32 7
  %t11 = load i1, ptr %t10, !tbaa !21
  br i1 %t11, label %bb2, label %bb3
bb2:
  store { i64, [2 x i64] } zeroinitializer, ptr %t13
  %t14 = getelementptr { i64, [2 x i64] }, ptr %t13, i32 0, i32 0
  store i64 0, ptr %t14
  %t15 = load { i64, [2 x i64] }, ptr %t13
  %t17 = call %"compiler/lower:pl" @compiler_2flower_3apl_2ector(ptr %v2, { i64, [2 x i64] } %t15)
  store %"compiler/lower:pl" %t17, ptr %l12
  br label %bb4
bb3:
  br label %bb5
bb4:
  %t18 = load %"compiler/lower:pl", ptr %l12
  store %"compiler/lower:pl" %t18, ptr %rv
  br label %ret
bb5:
  %t19 = load ptr, ptr %l0, !tbaa !29
  store ptr %t19, ptr %l13, !tbaa !29
  %t20 = load { i64, [4 x i64] }, ptr %l3
  store { i64, [4 x i64] } %t20, ptr %l14
  %t21 = load ptr, ptr %l1, !tbaa !29
  %t23 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t21)
  store i32 %t23, ptr %l16
  br label %bb6
bb6:
  %t25 = load ptr, ptr %l13, !tbaa !29
  %t26 = load { i64, [4 x i64] }, ptr %l14
  %t27 = load i32, ptr %l16, !tbaa !23
  %t29 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2elocal(ptr %v0, ptr %t25, { i64, [4 x i64] } %t26, i32 %t27, %"compiler/source:Span" %a2)
  store i32 %t29, ptr %l18
  br label %bb7
bb7:
  %t30 = load i32, ptr %l18, !tbaa !23
  %t31 = load ptr, ptr %l0, !tbaa !29
  store ptr %t31, ptr %l19, !tbaa !29
  store { i64, [2 x i64] } zeroinitializer, ptr %t33
  %t34 = getelementptr { i64, [2 x i64] }, ptr %t33, i32 0, i32 0
  store i64 1, ptr %t34
  %t36 = insertvalue { i32 } undef, i32 %t30, 0
  %t37 = getelementptr { i64, [2 x i64] }, ptr %t33, i32 0, i32 1
  store { i32 } %t36, ptr %t37
  %t38 = load { i64, [2 x i64] }, ptr %t33
  %t40 = call %"compiler/lower:pl" @compiler_2flower_3apl_2ector(ptr %v2, { i64, [2 x i64] } %t38)
  store %"compiler/lower:pl" %t40, ptr %l22
  br label %bb8
bb8:
  store { i64, [1 x i64] } zeroinitializer, ptr %t41
  %t42 = getelementptr { i64, [1 x i64] }, ptr %t41, i32 0, i32 0
  store i64 3, ptr %t42
  %t43 = load { i64, [1 x i64] }, ptr %t41
  %t44 = load ptr, ptr %l19, !tbaa !29
  %t45 = load %"compiler/lower:pl", ptr %l22
  %t47 = call %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2ewith(ptr %v0, ptr %v2, ptr %v2, ptr %t44, %"compiler/lower:pl" %t45, { i64, [1 x i64] } %t43)
  store %"compiler/lower:pl" %t47, ptr %l24
  br label %bb9
bb9:
  %t48 = load %"compiler/lower:pl", ptr %l24
  store %"compiler/lower:pl" %t48, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/lower:pl", ptr %rv
  ret %"compiler/lower:pl" %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2edispatch(ptr %v0, ptr %a0, { i64, [4 x i64] } %a1, i32 %a2, %"compiler/source:Span" %a3, i1 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [4 x i64] }
  %l2 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca ptr
  %l18 = alloca { i64, [4 x i64] }
  %l19 = alloca i1
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca %"compiler/typed:Item"
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca { i64, [4 x i64] }
  %l34 = alloca i32
  %l35 = alloca i32
  %l36 = alloca i32
  %l42 = alloca { i64, ptr }
  %l44 = alloca i64
  %l51 = alloca i64
  %l59 = alloca %"compiler/lower:tryCtx"
  %l66 = alloca i64
  %l69 = alloca i64
  %l89 = alloca { i64, ptr }
  %l103 = alloca { i64, ptr }
  %l112 = alloca i64
  %l115 = alloca i64
  %l135 = alloca i1
  %l136 = alloca ptr
  %l138 = alloca { i64, ptr }
  %l141 = alloca i32
  %l144 = alloca i32
  %l145 = alloca i1
  %l153 = alloca i1
  %l169 = alloca { i64, ptr }
  %l171 = alloca { i64, [4 x i64] }
  %l180 = alloca { i64, ptr }
  %l182 = alloca { i64, [4 x i64] }
  %l195 = alloca { i64, ptr }
  %l197 = alloca { i64, [4 x i64] }
  %l200 = alloca { i64, [4 x i64] }
  %l207 = alloca { i64, ptr }
  %l209 = alloca { i64, [4 x i64] }
  %l214 = alloca i1
  %l218 = alloca i1
  %l228 = alloca i32
  %l231 = alloca i32
  %l251 = alloca ptr
  %l257 = alloca { i64, [21 x i64] }
  %l267 = alloca ptr
  %l278 = alloca i32
  %l286 = alloca i64
  %l295 = alloca { i64, ptr }
  %l298 = alloca i1
  %l301 = alloca i64
  %l308 = alloca ptr
  %l309 = alloca %"compiler/source:Span"
  %l317 = alloca { i64, [4 x i64] }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %t115 = alloca { i64, [4 x i64] }, align 8
  %t263 = alloca { i64, [4 x i64] }, align 8
  %t276 = alloca { i64, [4 x i64] }, align 8
  %t313 = alloca { i64, [4 x i64] }, align 8
  %t353 = alloca { i64, [4 x i64] }, align 8
  %t461 = alloca { i64, [8 x i64] }, align 8
  %t511 = alloca { i64, [21 x i64] }, align 8
  %t612 = alloca { i64, [4 x i64] }, align 8
  %t615 = alloca { i64, [8 x i64] }, align 8
  %t634 = alloca { i64, [15 x i64] }, align 8
  store ptr %a0, ptr %l0
  store { i64, [4 x i64] } %a1, ptr %l1
  store i32 %a2, ptr %l2
  store %"compiler/source:Span" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l5, !tbaa !29
  %t6 = load ptr, ptr %l5, !tbaa !29
  %t7 = load i32, ptr %l2, !tbaa !23
  %t10 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t6, i32 %t7)
  store { i64, ptr } %t10, ptr %l42
  br label %bb1
bb1:
  %t11 = load { i64, ptr }, ptr %l42, !tbaa !27
  store { i64, ptr } %t11, ptr %l6, !tbaa !27
  %t12 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t14 = extractvalue { i64, ptr } %t12, 0
  store i64 %t14, ptr %l44, !tbaa !24
  %t15 = load i64, ptr %l44, !tbaa !24
  %t16 = icmp sge i64 %t15, 0
  br i1 %t16, label %bb2, label %bb3
bb2:
  %t18 = load i64, ptr %l44, !tbaa !24
  %t19 = mul i64 %t18, 1
  %t20 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t19)
  %t21 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  store { i64, ptr } %t22, ptr %l7, !tbaa !27
  %t24 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 0
  store i64 %t26, ptr %l8, !tbaa !24
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/lower:lowering", ptr %t28, i32 0, i32 13
  %t32 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3atryCtx_3e_2eLen_3ccompiler_2flower_3atryCtx_3e(ptr %v0, ptr %t30)
  store i64 %t32, ptr %l51
  br label %bb4
bb3:
  call void @__olang_check_failed(ptr @olang_loc_b0c77cc00353838c_f9addae603786cc8)
  unreachable
bb4:
  %t33 = load i64, ptr %l51, !tbaa !24
  %t34 = sub i64 %t33, 1
  store i64 %t34, ptr %l9, !tbaa !24
  br label %bb5
bb5:
  store %olang.scope zeroinitializer, ptr %s2
  %t36 = load i64, ptr %l9, !tbaa !24
  %t38 = icmp sge i64 %t36, 0
  %t40 = xor i1 %t38, true
  br i1 %t40, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s2)
  br label %bb107
bb7:
  br label %bb8
bb8:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/lower:lowering", ptr %t42, i32 0, i32 13
  %t45 = load i64, ptr %l9, !tbaa !24
  %t48 = call %"compiler/lower:tryCtx" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3atryCtx_3e_2eAt_3ccompiler_2flower_3atryCtx_3e(ptr %v0, ptr %v0, ptr %t44, i64 %t45)
  store %"compiler/lower:tryCtx" %t48, ptr %l59
  br label %bb9
bb9:
  %t49 = getelementptr %"compiler/lower:tryCtx", ptr %l59, i32 0, i32 1
  %t50 = load { i64, ptr }, ptr %t49, !tbaa !27
  store { i64, ptr } %t50, ptr %l10, !tbaa !27
  store i64 0, ptr %l11, !tbaa !24
  %t52 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t54 = extractvalue { i64, ptr } %t52, 0
  store i64 %t54, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t56 = load i64, ptr %l12, !tbaa !24
  %t57 = load i64, ptr %l11, !tbaa !24
  %t60 = icmp sgt i64 %t56, %t57
  br i1 %t60, label %bb10, label %bb11
bb10:
  %t62 = load i64, ptr %l13, !tbaa !24
  %t64 = icmp sgt i64 %t62, 0
  br i1 %t64, label %bb12, label %bb13
bb11:
  store i64 0, ptr %l66, !tbaa !24
  br label %bb15
bb12:
  %t66 = load i64, ptr %l12, !tbaa !24
  %t67 = load i64, ptr %l11, !tbaa !24
  %t70 = sub i64 %t66, %t67
  %t71 = load i64, ptr %l13, !tbaa !24
  %t74 = add i64 %t70, %t71
  %t76 = sub i64 %t74, 1
  %t77 = load i64, ptr %l13, !tbaa !24
  %t80 = sdiv i64 %t76, %t77
  store i64 %t80, ptr %l69, !tbaa !24
  br label %bb14
bb13:
  store i64 0, ptr %l69, !tbaa !24
  br label %bb14
bb14:
  %t82 = load i64, ptr %l69, !tbaa !24
  store i64 %t82, ptr %l66, !tbaa !24
  br label %bb15
bb15:
  %t83 = load i64, ptr %l66, !tbaa !24
  store i64 %t83, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb16
bb16:
  %t84 = load i64, ptr %l15, !tbaa !24
  %t85 = load i64, ptr %l14, !tbaa !24
  %t88 = icmp slt i64 %t84, %t85
  %t90 = xor i1 %t88, true
  br i1 %t90, label %bb17, label %bb18
bb17:
  br label %bb92
bb18:
  br label %bb19
bb19:
  %t92 = load i64, ptr %l11, !tbaa !24
  %t93 = load i64, ptr %l15, !tbaa !24
  %t94 = load i64, ptr %l13, !tbaa !24
  %t97 = mul i64 %t93, %t94
  %t100 = add i64 %t92, %t97
  store i64 %t100, ptr %l16, !tbaa !24
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = getelementptr %"compiler/lower:lowering", ptr %t102, i32 0, i32 7
  %t105 = load i1, ptr %t104, !tbaa !21
  br i1 %t105, label %bb20, label %bb21
bb20:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb21:
  br label %bb22
bb22:
  %t107 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t107, ptr %l89, !tbaa !27
  %t108 = load i64, ptr %l16, !tbaa !24
  %t110 = getelementptr { i64, ptr }, ptr %l89, i32 0, i32 1
  %t111 = load ptr, ptr %t110, !tbaa !27
  %t112 = getelementptr ptr, ptr %t111, i64 %t108
  %t113 = load ptr, ptr %t112, !tbaa !39
  store ptr %t113, ptr %l17, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t115
  %t116 = getelementptr { i64, [4 x i64] }, ptr %t115, i32 0, i32 0
  store i64 0, ptr %t116
  %t117 = load { i64, [4 x i64] }, ptr %t115
  store { i64, [4 x i64] } %t117, ptr %l18
  %t119 = load ptr, ptr %l17, !tbaa !29
  %t121 = getelementptr %"compiler/typed:Clause", ptr %t119, i32 0, i32 2
  %t122 = load i1, ptr %t121, !tbaa !21
  store i1 %t122, ptr %l19, !tbaa !21
  %t124 = load ptr, ptr %l17, !tbaa !29
  %t126 = getelementptr %"compiler/typed:Clause", ptr %t124, i32 0, i32 1
  %t127 = load { i64, ptr }, ptr %t126, !tbaa !27
  store { i64, ptr } %t127, ptr %l20, !tbaa !27
  store i64 0, ptr %l21, !tbaa !24
  %t129 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t131 = extractvalue { i64, ptr } %t129, 0
  store i64 %t131, ptr %l22, !tbaa !24
  br label %bb23
bb23:
  store %olang.scope zeroinitializer, ptr %s7
  %t133 = load i64, ptr %l21, !tbaa !24
  %t134 = load i64, ptr %l22, !tbaa !24
  %t137 = icmp slt i64 %t133, %t134
  %t139 = xor i1 %t137, true
  br i1 %t139, label %bb24, label %bb25
bb24:
  call void @__olang_scope_close(ptr %s7)
  br label %bb71
bb25:
  br label %bb26
bb26:
  %t141 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t141, ptr %l103, !tbaa !27
  %t142 = load i64, ptr %l21, !tbaa !24
  %t144 = getelementptr { i64, ptr }, ptr %l103, i32 0, i32 1
  %t145 = load ptr, ptr %t144, !tbaa !27
  %t146 = getelementptr %"compiler/typed:Item", ptr %t145, i64 %t142
  %t147 = load %"compiler/typed:Item", ptr %t146
  store %"compiler/typed:Item" %t147, ptr %l23
  %t149 = load i1, ptr %l19, !tbaa !21
  br i1 %t149, label %bb27, label %bb28
bb27:
  call void @__olang_scope_close(ptr %s7)
  br label %bb71
bb28:
  br label %bb29
bb29:
  store i64 -1, ptr %l24, !tbaa !24
  store i64 0, ptr %l25, !tbaa !24
  %t151 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t153 = extractvalue { i64, ptr } %t151, 0
  store i64 %t153, ptr %l26, !tbaa !24
  store i64 1, ptr %l27, !tbaa !24
  %t155 = load i64, ptr %l26, !tbaa !24
  %t156 = load i64, ptr %l25, !tbaa !24
  %t159 = icmp sgt i64 %t155, %t156
  br i1 %t159, label %bb30, label %bb31
bb30:
  %t161 = load i64, ptr %l27, !tbaa !24
  %t163 = icmp sgt i64 %t161, 0
  br i1 %t163, label %bb32, label %bb33
bb31:
  store i64 0, ptr %l112, !tbaa !24
  br label %bb35
bb32:
  %t165 = load i64, ptr %l26, !tbaa !24
  %t166 = load i64, ptr %l25, !tbaa !24
  %t169 = sub i64 %t165, %t166
  %t170 = load i64, ptr %l27, !tbaa !24
  %t173 = add i64 %t169, %t170
  %t175 = sub i64 %t173, 1
  %t176 = load i64, ptr %l27, !tbaa !24
  %t179 = sdiv i64 %t175, %t176
  store i64 %t179, ptr %l115, !tbaa !24
  br label %bb34
bb33:
  store i64 0, ptr %l115, !tbaa !24
  br label %bb34
bb34:
  %t181 = load i64, ptr %l115, !tbaa !24
  store i64 %t181, ptr %l112, !tbaa !24
  br label %bb35
bb35:
  %t182 = load i64, ptr %l112, !tbaa !24
  store i64 %t182, ptr %l28, !tbaa !24
  store i64 0, ptr %l29, !tbaa !24
  br label %bb36
bb36:
  %t183 = load i64, ptr %l29, !tbaa !24
  %t184 = load i64, ptr %l28, !tbaa !24
  %t187 = icmp slt i64 %t183, %t184
  %t189 = xor i1 %t187, true
  br i1 %t189, label %bb37, label %bb38
bb37:
  br label %bb50
bb38:
  br label %bb39
bb39:
  %t191 = load i64, ptr %l25, !tbaa !24
  %t192 = load i64, ptr %l29, !tbaa !24
  %t193 = load i64, ptr %l27, !tbaa !24
  %t196 = mul i64 %t192, %t193
  %t199 = add i64 %t191, %t196
  store i64 %t199, ptr %l30, !tbaa !24
  %t201 = load i64, ptr %l24, !tbaa !24
  %t203 = icmp slt i64 %t201, 0
  br i1 %t203, label %bb40, label %bb41
bb40:
  %t205 = load ptr, ptr %l5, !tbaa !29
  store ptr %t205, ptr %l136, !tbaa !29
  %t206 = load ptr, ptr %l5, !tbaa !29
  %t207 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t207, ptr %l138, !tbaa !27
  %t208 = load i64, ptr %l30, !tbaa !24
  %t210 = getelementptr { i64, ptr }, ptr %l138, i32 0, i32 1
  %t211 = load ptr, ptr %t210, !tbaa !27
  %t212 = getelementptr i32, ptr %t211, i64 %t208
  %t213 = load i32, ptr %t212, !tbaa !33
  %t216 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t206, i32 %t213)
  store i32 %t216, ptr %l141
  br label %bb42
bb41:
  store i1 false, ptr %l135, !tbaa !21
  br label %bb45
bb42:
  %t217 = load ptr, ptr %l5, !tbaa !29
  %t218 = getelementptr %"compiler/typed:Item", ptr %l23, i32 0, i32 0
  %t219 = load i32, ptr %t218, !tbaa !23
  %t222 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t217, i32 %t219)
  store i32 %t222, ptr %l144
  br label %bb43
bb43:
  %t223 = load ptr, ptr %l136, !tbaa !29
  %t224 = load i32, ptr %l141, !tbaa !23
  %t225 = load i32, ptr %l144, !tbaa !23
  %t226 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t223, i32 %t224, i32 %t225)
  store i1 %t226, ptr %l145
  br label %bb44
bb44:
  %t227 = load i1, ptr %l145, !tbaa !21
  store i1 %t227, ptr %l135, !tbaa !21
  br label %bb45
bb45:
  %t228 = load i1, ptr %l135, !tbaa !21
  br i1 %t228, label %bb46, label %bb47
bb46:
  %t229 = load i64, ptr %l30, !tbaa !24
  store i64 %t229, ptr %l24, !tbaa !24
  br label %bb48
bb47:
  br label %bb48
bb48:
  br label %bb49
bb49:
  %t231 = load i64, ptr %l29, !tbaa !24
  %t233 = add i64 %t231, 1
  store i64 %t233, ptr %l29, !tbaa !24
  br label %bb36
bb50:
  %t235 = load i64, ptr %l24, !tbaa !24
  %t237 = icmp slt i64 %t235, 0
  br i1 %t237, label %bb51, label %bb52
bb51:
  call void @__olang_scope_close(ptr %s7)
  br label %bb70
bb52:
  br label %bb53
bb53:
  %t239 = getelementptr %"compiler/typed:Item", ptr %l23, i32 0, i32 1
  %t240 = load i64, ptr %t239, !tbaa !24
  %t242 = icmp slt i64 %t240, 0
  br i1 %t242, label %bb54, label %bb55
bb54:
  %t244 = load i64, ptr %l24, !tbaa !24
  %t246 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t247 = load ptr, ptr %t246, !tbaa !27
  %t248 = getelementptr i1, ptr %t247, i64 %t244
  %t249 = load i1, ptr %t248, !tbaa !31
  %t251 = xor i1 %t249, true
  store i1 %t251, ptr %l153, !tbaa !21
  br label %bb56
bb55:
  store i1 false, ptr %l153, !tbaa !21
  br label %bb56
bb56:
  %t253 = load i1, ptr %l153, !tbaa !21
  br i1 %t253, label %bb57, label %bb58
bb57:
  %t254 = load i64, ptr %l24, !tbaa !24
  %t256 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t257 = load ptr, ptr %t256, !tbaa !27
  %t258 = getelementptr i1, ptr %t257, i64 %t254
  store i1 true, ptr %t258, !tbaa !31
  %t259 = load i64, ptr %l8, !tbaa !24
  %t261 = sub i64 %t259, 1
  store i64 %t261, ptr %l8, !tbaa !24
  br label %bb59
bb58:
  br label %bb59
bb59:
  store { i64, [4 x i64] } zeroinitializer, ptr %t263
  %t264 = getelementptr { i64, [4 x i64] }, ptr %t263, i32 0, i32 0
  store i64 0, ptr %t264
  %t265 = load { i64, [4 x i64] }, ptr %t263
  store { i64, [4 x i64] } %t265, ptr %l31
  %t267 = getelementptr %"compiler/typed:Item", ptr %l23, i32 0, i32 1
  %t268 = load i64, ptr %t267, !tbaa !24
  %t270 = icmp slt i64 %t268, 0
  br i1 %t270, label %bb60, label %bb61
bb60:
  store %olang.scope zeroinitializer, ptr %s15
  %t272 = load ptr, ptr %l0, !tbaa !29
  %t273 = load i32, ptr @G_2ecompiler_2fmir_2eI32T, !tbaa !23
  %t274 = load { i64, [4 x i64] }, ptr %l1
  %t275 = load i32, ptr @G_2ecompiler_2fmir_2eI32T, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t276
  %t277 = getelementptr { i64, [4 x i64] }, ptr %t276, i32 0, i32 0
  store i64 2, ptr %t277
  %t279 = insertvalue { i32, i64 } undef, i32 %t275, 0
  %t280 = insertvalue { i32, i64 } %t279, i64 16, 1
  %t281 = getelementptr { i64, [4 x i64] }, ptr %t276, i32 0, i32 1
  store { i32, i64 } %t280, ptr %t281
  %t282 = load { i64, [4 x i64] }, ptr %t276
  %t283 = mul i64 2, 40
  %t284 = call ptr @__olang_scope_alloc_zeroed(ptr %s15, i64 %t283)
  %t285 = insertvalue { i64, ptr } undef, i64 2, 0
  %t286 = insertvalue { i64, ptr } %t285, ptr %t284, 1
  store { i64, ptr } %t286, ptr %l169, !tbaa !27
  %t288 = getelementptr { i64, ptr }, ptr %l169, i32 0, i32 1
  %t289 = load ptr, ptr %t288, !tbaa !27
  %t290 = getelementptr { i64, [4 x i64] }, ptr %t289, i64 0
  store { i64, [4 x i64] } %t274, ptr %t290
  %t292 = getelementptr { i64, ptr }, ptr %l169, i32 0, i32 1
  %t293 = load ptr, ptr %t292, !tbaa !27
  %t294 = getelementptr { i64, [4 x i64] }, ptr %t293, i64 1
  store { i64, [4 x i64] } %t282, ptr %t294
  %t295 = load %"compiler/source:Span", ptr %l3
  %t299 = load { i64, ptr }, ptr %l169, !tbaa !27
  %t301 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s15, ptr %t272, i32 9, i32 %t273, { i64, ptr } %t299, %"compiler/source:Span" %t295)
  store { i64, [4 x i64] } %t301, ptr %l171
  br label %bb62
bb61:
  store %olang.scope zeroinitializer, ptr %s16
  %t302 = load i32, ptr @G_2ecompiler_2fmir_2eI32T, !tbaa !23
  %t303 = load i64, ptr %l24, !tbaa !24
  %t305 = add i64 %t303, 1
  %t307 = shl i64 %t305, 16
  %t308 = getelementptr %"compiler/typed:Item", ptr %l23, i32 0, i32 1
  %t309 = load i64, ptr %t308, !tbaa !24
  %t312 = or i64 %t307, %t309
  store { i64, [4 x i64] } zeroinitializer, ptr %t313
  %t314 = getelementptr { i64, [4 x i64] }, ptr %t313, i32 0, i32 0
  store i64 2, ptr %t314
  %t316 = insertvalue { i32, i64 } undef, i32 %t302, 0
  %t318 = insertvalue { i32, i64 } %t316, i64 %t312, 1
  %t319 = getelementptr { i64, [4 x i64] }, ptr %t313, i32 0, i32 1
  store { i32, i64 } %t318, ptr %t319
  %t320 = load { i64, [4 x i64] }, ptr %t313
  %t322 = load ptr, ptr %l0, !tbaa !29
  %t323 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t324 = load { i64, [4 x i64] }, ptr %l1
  %t326 = mul i64 2, 40
  %t327 = call ptr @__olang_scope_alloc_zeroed(ptr %s16, i64 %t326)
  %t328 = insertvalue { i64, ptr } undef, i64 2, 0
  %t329 = insertvalue { i64, ptr } %t328, ptr %t327, 1
  store { i64, ptr } %t329, ptr %l195, !tbaa !27
  %t331 = getelementptr { i64, ptr }, ptr %l195, i32 0, i32 1
  %t332 = load ptr, ptr %t331, !tbaa !27
  %t333 = getelementptr { i64, [4 x i64] }, ptr %t332, i64 0
  store { i64, [4 x i64] } %t324, ptr %t333
  %t335 = getelementptr { i64, ptr }, ptr %l195, i32 0, i32 1
  %t336 = load ptr, ptr %t335, !tbaa !27
  %t337 = getelementptr { i64, [4 x i64] }, ptr %t336, i64 1
  store { i64, [4 x i64] } %t320, ptr %t337
  %t338 = load %"compiler/source:Span", ptr %l3
  %t342 = load { i64, ptr }, ptr %l195, !tbaa !27
  %t344 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s16, ptr %t322, i32 13, i32 %t323, { i64, ptr } %t342, %"compiler/source:Span" %t338)
  store { i64, [4 x i64] } %t344, ptr %l197
  br label %bb64
bb62:
  %t345 = load { i64, [4 x i64] }, ptr %l171
  %t346 = load ptr, ptr %l0, !tbaa !29
  %t347 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t349 = load i32, ptr @G_2ecompiler_2fmir_2eI32T, !tbaa !23
  %t350 = load i64, ptr %l24, !tbaa !24
  %t352 = add i64 %t350, 1
  store { i64, [4 x i64] } zeroinitializer, ptr %t353
  %t354 = getelementptr { i64, [4 x i64] }, ptr %t353, i32 0, i32 0
  store i64 2, ptr %t354
  %t356 = insertvalue { i32, i64 } undef, i32 %t349, 0
  %t358 = insertvalue { i32, i64 } %t356, i64 %t352, 1
  %t359 = getelementptr { i64, [4 x i64] }, ptr %t353, i32 0, i32 1
  store { i32, i64 } %t358, ptr %t359
  %t360 = load { i64, [4 x i64] }, ptr %t353
  %t361 = mul i64 2, 40
  %t362 = call ptr @__olang_scope_alloc_zeroed(ptr %s15, i64 %t361)
  %t363 = insertvalue { i64, ptr } undef, i64 2, 0
  %t364 = insertvalue { i64, ptr } %t363, ptr %t362, 1
  store { i64, ptr } %t364, ptr %l180, !tbaa !27
  %t366 = getelementptr { i64, ptr }, ptr %l180, i32 0, i32 1
  %t367 = load ptr, ptr %t366, !tbaa !27
  %t368 = getelementptr { i64, [4 x i64] }, ptr %t367, i64 0
  store { i64, [4 x i64] } %t345, ptr %t368
  %t370 = getelementptr { i64, ptr }, ptr %l180, i32 0, i32 1
  %t371 = load ptr, ptr %t370, !tbaa !27
  %t372 = getelementptr { i64, [4 x i64] }, ptr %t371, i64 1
  store { i64, [4 x i64] } %t360, ptr %t372
  %t373 = load %"compiler/source:Span", ptr %l3
  %t377 = load { i64, ptr }, ptr %l180, !tbaa !27
  %t379 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s15, ptr %t346, i32 13, i32 %t347, { i64, ptr } %t377, %"compiler/source:Span" %t373)
  store { i64, [4 x i64] } %t379, ptr %l182
  br label %bb63
bb63:
  %t380 = load { i64, [4 x i64] }, ptr %l182
  store { i64, [4 x i64] } %t380, ptr %l31
  call void @__olang_scope_close(ptr %s15)
  br label %bb65
bb64:
  %t381 = load { i64, [4 x i64] }, ptr %l197
  store { i64, [4 x i64] } %t381, ptr %l31
  call void @__olang_scope_close(ptr %s16)
  br label %bb65
bb65:
  %t382 = load { i64, [4 x i64] }, ptr %l18
  %t384 = extractvalue { i64, [4 x i64] } %t382, 0
  %t385 = icmp eq i64 %t384, 0
  br i1 %t385, label %bb66, label %bb67
bb66:
  %t387 = load { i64, [4 x i64] }, ptr %l31
  store { i64, [4 x i64] } %t387, ptr %l200
  br label %bb69
bb67:
  %t389 = load ptr, ptr %l0, !tbaa !29
  %t390 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t391 = load { i64, [4 x i64] }, ptr %l18
  %t392 = load { i64, [4 x i64] }, ptr %l31
  %t393 = mul i64 2, 40
  %t394 = call ptr @__olang_scope_alloc_zeroed(ptr %s7, i64 %t393)
  %t395 = insertvalue { i64, ptr } undef, i64 2, 0
  %t396 = insertvalue { i64, ptr } %t395, ptr %t394, 1
  store { i64, ptr } %t396, ptr %l207, !tbaa !27
  %t398 = getelementptr { i64, ptr }, ptr %l207, i32 0, i32 1
  %t399 = load ptr, ptr %t398, !tbaa !27
  %t400 = getelementptr { i64, [4 x i64] }, ptr %t399, i64 0
  store { i64, [4 x i64] } %t391, ptr %t400
  %t402 = getelementptr { i64, ptr }, ptr %l207, i32 0, i32 1
  %t403 = load ptr, ptr %t402, !tbaa !27
  %t404 = getelementptr { i64, [4 x i64] }, ptr %t403, i64 1
  store { i64, [4 x i64] } %t392, ptr %t404
  %t405 = load %"compiler/source:Span", ptr %l3
  %t409 = load { i64, ptr }, ptr %l207, !tbaa !27
  %t411 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s7, ptr %t389, i32 11, i32 %t390, { i64, ptr } %t409, %"compiler/source:Span" %t405)
  store { i64, [4 x i64] } %t411, ptr %l209
  br label %bb68
bb68:
  %t412 = load { i64, [4 x i64] }, ptr %l209
  store { i64, [4 x i64] } %t412, ptr %l200
  br label %bb69
bb69:
  %t413 = load { i64, [4 x i64] }, ptr %l200
  store { i64, [4 x i64] } %t413, ptr %l18
  call void @__olang_scope_close(ptr %s7)
  br label %bb70
bb70:
  %t414 = load i64, ptr %l21, !tbaa !24
  %t416 = add i64 %t414, 1
  store i64 %t416, ptr %l21, !tbaa !24
  br label %bb23
bb71:
  %t418 = load i1, ptr %l19, !tbaa !21
  %t420 = xor i1 %t418, true
  br i1 %t420, label %bb72, label %bb73
bb72:
  %t422 = load { i64, [4 x i64] }, ptr %l18
  %t424 = extractvalue { i64, [4 x i64] } %t422, 0
  %t425 = icmp eq i64 %t424, 0
  store i1 %t425, ptr %l214, !tbaa !21
  br label %bb74
bb73:
  store i1 false, ptr %l214, !tbaa !21
  br label %bb74
bb74:
  %t427 = load i1, ptr %l214, !tbaa !21
  br i1 %t427, label %bb75, label %bb76
bb75:
  br label %bb91
bb76:
  br label %bb77
bb77:
  %t428 = load i1, ptr %l19, !tbaa !21
  br i1 %t428, label %bb78, label %bb79
bb78:
  store i1 true, ptr %l218, !tbaa !21
  br label %bb80
bb79:
  %t430 = load i64, ptr %l8, !tbaa !24
  %t432 = icmp eq i64 %t430, 0
  store i1 %t432, ptr %l218, !tbaa !21
  br label %bb80
bb80:
  %t434 = load i1, ptr %l218, !tbaa !21
  br i1 %t434, label %bb81, label %bb82
bb81:
  %t435 = load ptr, ptr %l0, !tbaa !29
  %t436 = load i64, ptr %l9, !tbaa !24
  %t437 = load i64, ptr %l16, !tbaa !24
  %t438 = load { i64, [4 x i64] }, ptr %l1
  %t439 = load i32, ptr %l2, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2etoClause(ptr %v0, ptr %t435, i64 %t436, i64 %t437, { i64, [4 x i64] } %t438, i32 %t439)
  br label %bb83
bb82:
  br label %bb84
bb83:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb84:
  %t445 = load ptr, ptr %l0, !tbaa !29
  %t447 = getelementptr %"compiler/lower:lowering", ptr %t445, i32 0, i32 3
  %t449 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t447)
  store i32 %t449, ptr %l228
  br label %bb85
bb85:
  %t450 = load i32, ptr %l228, !tbaa !23
  store i32 %t450, ptr %l34, !tbaa !23
  %t451 = load ptr, ptr %l0, !tbaa !29
  %t453 = getelementptr %"compiler/lower:lowering", ptr %t451, i32 0, i32 3
  %t455 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t453)
  store i32 %t455, ptr %l231
  br label %bb86
bb86:
  %t456 = load i32, ptr %l231, !tbaa !23
  store i32 %t456, ptr %l35, !tbaa !23
  %t457 = load ptr, ptr %l0, !tbaa !29
  %t458 = load { i64, [4 x i64] }, ptr %l18
  %t459 = load i32, ptr %l34, !tbaa !23
  %t460 = load i32, ptr %l35, !tbaa !23
  store { i64, [8 x i64] } zeroinitializer, ptr %t461
  %t462 = getelementptr { i64, [8 x i64] }, ptr %t461, i32 0, i32 0
  store i64 2, ptr %t462
  %t464 = insertvalue { { i64, [4 x i64] }, i32, i32 } undef, { i64, [4 x i64] } %t458, 0
  %t466 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t464, i32 %t459, 1
  %t468 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t466, i32 %t460, 2
  %t469 = getelementptr { i64, [8 x i64] }, ptr %t461, i32 0, i32 1
  store { { i64, [4 x i64] }, i32, i32 } %t468, ptr %t469
  %t470 = load { i64, [8 x i64] }, ptr %t461
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t457, { i64, [8 x i64] } %t470)
  br label %bb87
bb87:
  %t473 = load ptr, ptr %l0, !tbaa !29
  %t474 = load i32, ptr %l34, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t473, i32 %t474)
  br label %bb88
bb88:
  %t477 = load ptr, ptr %l0, !tbaa !29
  %t478 = load i64, ptr %l9, !tbaa !24
  %t479 = load i64, ptr %l16, !tbaa !24
  %t480 = load { i64, [4 x i64] }, ptr %l1
  %t481 = load i32, ptr %l2, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2etoClause(ptr %v0, ptr %t477, i64 %t478, i64 %t479, { i64, [4 x i64] } %t480, i32 %t481)
  br label %bb89
bb89:
  %t487 = load ptr, ptr %l0, !tbaa !29
  %t488 = load i32, ptr %l35, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t487, i32 %t488)
  br label %bb90
bb90:
  br label %bb91
bb91:
  %t491 = load i64, ptr %l15, !tbaa !24
  %t493 = add i64 %t491, 1
  store i64 %t493, ptr %l15, !tbaa !24
  br label %bb16
bb92:
  %t495 = load ptr, ptr %l0, !tbaa !29
  %t497 = getelementptr %"compiler/lower:lowering", ptr %t495, i32 0, i32 13
  %t498 = load i64, ptr %l9, !tbaa !24
  %t501 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3atryCtx_3e_2eRef_3ccompiler_2flower_3atryCtx_3e(ptr %v0, ptr %s2, ptr %t497, i64 %t498)
  store ptr %t501, ptr %l251
  br label %bb93
bb93:
  %t502 = load ptr, ptr %l251, !tbaa !29
  %t504 = getelementptr %"compiler/lower:tryCtx", ptr %t502, i32 0, i32 2
  %t505 = load i1, ptr %t504, !tbaa !21
  br i1 %t505, label %bb94, label %bb95
bb94:
  br i1 %a4, label %bb96, label %bb97
bb95:
  br label %bb101
bb96:
  store %olang.scope zeroinitializer, ptr %s22
  %t509 = load ptr, ptr %l0, !tbaa !29
  %t510 = load %"compiler/source:Span", ptr %l3
  store { i64, [21 x i64] } zeroinitializer, ptr %t511
  %t512 = getelementptr { i64, [21 x i64] }, ptr %t511, i32 0, i32 0
  store i64 11, ptr %t512
  %t514 = insertvalue { %"compiler/source:Span" } undef, %"compiler/source:Span" %t510, 0
  %t515 = getelementptr { i64, [21 x i64] }, ptr %t511, i32 0, i32 1
  store { %"compiler/source:Span" } %t514, ptr %t515
  %t516 = load { i64, [21 x i64] }, ptr %t511
  store { i64, [21 x i64] } %t516, ptr %l257
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s22, ptr %t509, ptr %l257)
  br label %bb98
bb97:
  br label %bb99
bb98:
  call void @__olang_scope_close(ptr %s22)
  br label %bb99
bb99:
  %t519 = load ptr, ptr %l0, !tbaa !29
  %t520 = load { i64, [4 x i64] }, ptr %l1
  %t521 = load i32, ptr %l2, !tbaa !23
  %t522 = load %"compiler/source:Span", ptr %l3
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2ebang(ptr %v0, ptr %t519, { i64, [4 x i64] } %t520, i32 %t521, %"compiler/source:Span" %t522, i32 14)
  br label %bb100
bb100:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb101:
  %t528 = load ptr, ptr %l0, !tbaa !29
  %t530 = getelementptr %"compiler/lower:lowering", ptr %t528, i32 0, i32 13
  %t531 = load i64, ptr %l9, !tbaa !24
  %t534 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3atryCtx_3e_2eRef_3ccompiler_2flower_3atryCtx_3e(ptr %v0, ptr %s2, ptr %t530, i64 %t531)
  store ptr %t534, ptr %l267
  br label %bb102
bb102:
  %t535 = load ptr, ptr %l267, !tbaa !29
  %t537 = getelementptr %"compiler/lower:tryCtx", ptr %t535, i32 0, i32 3
  %t538 = load i1, ptr %t537, !tbaa !21
  %t540 = xor i1 %t538, true
  br i1 %t540, label %bb103, label %bb104
bb103:
  call void @__olang_scope_close(ptr %s2)
  br label %bb107
bb104:
  br label %bb105
bb105:
  call void @__olang_scope_close(ptr %s2)
  br label %bb106
bb106:
  %t542 = load i64, ptr %l9, !tbaa !24
  %t544 = sub i64 %t542, 1
  store i64 %t544, ptr %l9, !tbaa !24
  br label %bb5
bb107:
  %t546 = load ptr, ptr %l0, !tbaa !29
  %t548 = getelementptr %"compiler/lower:lowering", ptr %t546, i32 0, i32 2
  %t549 = load ptr, ptr %t548, !tbaa !29
  %t550 = load ptr, ptr %l0, !tbaa !29
  %t552 = getelementptr %"compiler/lower:lowering", ptr %t550, i32 0, i32 1
  %t553 = load ptr, ptr %t552, !tbaa !29
  %t555 = getelementptr %"compiler/typed:Body", ptr %t553, i32 0, i32 2
  %t556 = load i32, ptr %t555, !tbaa !23
  %t559 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t549, i32 %t556)
  store i32 %t559, ptr %l278
  br label %bb108
bb108:
  %t560 = load i32, ptr %l278, !tbaa !23
  store i32 %t560, ptr %l36, !tbaa !23
  %t561 = load ptr, ptr %l0, !tbaa !29
  %t563 = getelementptr %"compiler/lower:lowering", ptr %t561, i32 0, i32 1
  %t564 = load ptr, ptr %t563, !tbaa !29
  %t566 = getelementptr %"compiler/typed:Body", ptr %t564, i32 0, i32 1
  %t567 = load { i64, [2 x i64] }, ptr %t566
  %t571 = extractvalue { i64, [2 x i64] } %t567, 0
  %t572 = icmp eq i64 %t571, 5
  br i1 %t572, label %bb109, label %bb110
bb109:
  br label %bb111
bb110:
  br label %bb117
bb111:
  %t574 = load ptr, ptr %l0, !tbaa !29
  %t576 = getelementptr %"compiler/lower:lowering", ptr %t574, i32 0, i32 13
  %t578 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3atryCtx_3e_2eLen_3ccompiler_2flower_3atryCtx_3e(ptr %v0, ptr %t576)
  store i64 %t578, ptr %l286
  br label %bb112
bb112:
  %t579 = load i64, ptr %l286, !tbaa !24
  %t580 = icmp sgt i64 %t579, 0
  br i1 %t580, label %bb113, label %bb114
bb113:
  %t582 = load ptr, ptr %l0, !tbaa !29
  %t583 = load { i64, [4 x i64] }, ptr %l1
  %t584 = load i32, ptr %l2, !tbaa !23
  %t585 = load %"compiler/source:Span", ptr %l3
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2ebang(ptr %v0, ptr %t582, { i64, [4 x i64] } %t583, i32 %t584, %"compiler/source:Span" %t585, i32 15)
  br label %bb115
bb114:
  br label %bb116
bb115:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb116:
  br label %bb122
bb117:
  br i1 true, label %bb118, label %bb119
bb118:
  br label %bb120
bb119:
  br label %bb121
bb120:
  br label %bb122
bb121:
  call void @__olang_check_failed(ptr @olang_loc_1378acbf535452a2_3a9100f5c9d7e1f6)
  unreachable
bb122:
  %t591 = load ptr, ptr %l5, !tbaa !29
  %t592 = load i32, ptr %l36, !tbaa !23
  %t595 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s0, ptr %t591, i32 %t592)
  store { i64, ptr } %t595, ptr %l295
  br label %bb123
bb123:
  %t596 = load { i64, ptr }, ptr %l295, !tbaa !27
  %t597 = extractvalue { i64, ptr } %t596, 0
  %t599 = icmp eq i64 %t597, 0
  br i1 %t599, label %bb124, label %bb125
bb124:
  store i1 true, ptr %l298, !tbaa !21
  br label %bb127
bb125:
  %t601 = load ptr, ptr %l0, !tbaa !29
  %t603 = getelementptr %"compiler/lower:lowering", ptr %t601, i32 0, i32 13
  %t605 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3atryCtx_3e_2eLen_3ccompiler_2flower_3atryCtx_3e(ptr %v0, ptr %t603)
  store i64 %t605, ptr %l301
  br label %bb126
bb126:
  %t606 = load i64, ptr %l301, !tbaa !24
  %t607 = icmp eq i64 %t606, 0
  store i1 %t607, ptr %l298, !tbaa !21
  br label %bb127
bb127:
  %t609 = load i1, ptr %l298, !tbaa !21
  br i1 %t609, label %bb128, label %bb129
bb128:
  %t610 = load ptr, ptr %l0, !tbaa !29
  %t611 = load %"compiler/source:Span", ptr %l3
  store { i64, [4 x i64] } zeroinitializer, ptr %t612
  %t613 = getelementptr { i64, [4 x i64] }, ptr %t612, i32 0, i32 0
  store i64 0, ptr %t613
  %t614 = load { i64, [4 x i64] }, ptr %t612
  store { i64, [8 x i64] } zeroinitializer, ptr %t615
  %t616 = getelementptr { i64, [8 x i64] }, ptr %t615, i32 0, i32 0
  store i64 9, ptr %t616
  %t618 = insertvalue { %"compiler/source:Span", i32, { i64, [4 x i64] } } undef, %"compiler/source:Span" %t611, 0
  %t620 = insertvalue { %"compiler/source:Span", i32, { i64, [4 x i64] } } %t618, i32 3, 1
  %t622 = insertvalue { %"compiler/source:Span", i32, { i64, [4 x i64] } } %t620, { i64, [4 x i64] } %t614, 2
  %t623 = getelementptr { i64, [8 x i64] }, ptr %t615, i32 0, i32 1
  store { %"compiler/source:Span", i32, { i64, [4 x i64] } } %t622, ptr %t623
  %t624 = load { i64, [8 x i64] }, ptr %t615
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t610, { i64, [8 x i64] } %t624)
  br label %bb130
bb129:
  br label %bb131
bb130:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb131:
  %t627 = load ptr, ptr %l0, !tbaa !29
  store ptr %t627, ptr %l308, !tbaa !29
  %t628 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t628, ptr %l309
  %t629 = load ptr, ptr %l0, !tbaa !29
  %t630 = load i32, ptr @G_2ecompiler_2fmir_2eI32T, !tbaa !23
  %t631 = load { i64, [4 x i64] }, ptr %l1
  %t632 = load i32, ptr %l2, !tbaa !23
  %t633 = load i32, ptr %l36, !tbaa !23
  store { i64, [15 x i64] } zeroinitializer, ptr %t634
  %t635 = getelementptr { i64, [15 x i64] }, ptr %t634, i32 0, i32 0
  store i64 11, ptr %t635
  %t637 = insertvalue { { i64, [4 x i64] }, i32, i32 } undef, { i64, [4 x i64] } %t631, 0
  %t639 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t637, i32 %t632, 1
  %t641 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t639, i32 %t633, 2
  %t642 = getelementptr { i64, [15 x i64] }, ptr %t634, i32 0, i32 1
  store { { i64, [4 x i64] }, i32, i32 } %t641, ptr %t642
  %t643 = load { i64, [15 x i64] }, ptr %t634
  %t644 = load %"compiler/source:Span", ptr %l3
  %t649 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %t629, i32 %t630, { i64, [15 x i64] } %t643, %"compiler/source:Span" %t644)
  store { i64, [4 x i64] } %t649, ptr %l317
  br label %bb132
bb132:
  %t650 = load ptr, ptr %l308, !tbaa !29
  %t651 = load %"compiler/source:Span", ptr %l309
  %t652 = load { i64, [4 x i64] }, ptr %l317
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eraise(ptr %v0, ptr %t650, %"compiler/source:Span" %t651, { i64, [4 x i64] } %t652)
  br label %bb133
bb133:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eencloses(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l14 = alloca i64
  %l19 = alloca i64
  %l22 = alloca i64
  %l47 = alloca i1
  %l49 = alloca i64
  %l53 = alloca i64
  %l61 = alloca %"compiler/typed:BlockInfo"
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i32 %a2, ptr %l3, !tbaa !23
  store i64 0, ptr %l4, !tbaa !24
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/lower:lowering", ptr %t3, i32 0, i32 1
  %t6 = load ptr, ptr %t5, !tbaa !29
  %t8 = getelementptr %"compiler/typed:Body", ptr %t6, i32 0, i32 8
  %t10 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockInfo_3e_2eLen__Hdc799a0fe091f8e84d50200d058b631d(ptr %v0, ptr %t8)
  store i64 %t10, ptr %l14
  br label %bb1
bb1:
  %t11 = load i64, ptr %l14, !tbaa !24
  %t12 = add i64 %t11, 1
  store i64 %t12, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t14 = load i64, ptr %l5, !tbaa !24
  %t15 = load i64, ptr %l4, !tbaa !24
  %t18 = icmp sgt i64 %t14, %t15
  br i1 %t18, label %bb2, label %bb3
bb2:
  %t20 = load i64, ptr %l6, !tbaa !24
  %t22 = icmp sgt i64 %t20, 0
  br i1 %t22, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l19, !tbaa !24
  br label %bb7
bb4:
  %t24 = load i64, ptr %l5, !tbaa !24
  %t25 = load i64, ptr %l4, !tbaa !24
  %t28 = sub i64 %t24, %t25
  %t29 = load i64, ptr %l6, !tbaa !24
  %t32 = add i64 %t28, %t29
  %t34 = sub i64 %t32, 1
  %t35 = load i64, ptr %l6, !tbaa !24
  %t38 = sdiv i64 %t34, %t35
  store i64 %t38, ptr %l22, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l22, !tbaa !24
  br label %bb6
bb6:
  %t40 = load i64, ptr %l22, !tbaa !24
  store i64 %t40, ptr %l19, !tbaa !24
  br label %bb7
bb7:
  %t41 = load i64, ptr %l19, !tbaa !24
  store i64 %t41, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb8
bb8:
  %t42 = load i64, ptr %l8, !tbaa !24
  %t43 = load i64, ptr %l7, !tbaa !24
  %t46 = icmp slt i64 %t42, %t43
  %t48 = xor i1 %t46, true
  br i1 %t48, label %bb9, label %bb10
bb9:
  br label %bb24
bb10:
  br label %bb11
bb11:
  %t50 = load i64, ptr %l4, !tbaa !24
  %t51 = load i64, ptr %l8, !tbaa !24
  %t52 = load i64, ptr %l6, !tbaa !24
  %t55 = mul i64 %t51, %t52
  %t58 = add i64 %t50, %t55
  store i64 %t58, ptr %l9, !tbaa !24
  %t60 = load i32, ptr %l3, !tbaa !23
  %t64 = icmp eq i32 %t60, %a1
  br i1 %t64, label %bb12, label %bb13
bb12:
  store i1 true, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  %t67 = load i32, ptr %l3, !tbaa !23
  %t69 = sext i32 %t67 to i64
  %t71 = icmp slt i64 %t69, 0
  br i1 %t71, label %bb15, label %bb16
bb15:
  store i1 true, ptr %l47, !tbaa !21
  br label %bb18
bb16:
  %t73 = load i32, ptr %l3, !tbaa !23
  %t75 = sext i32 %t73 to i64
  store i64 %t75, ptr %l49, !tbaa !24
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"compiler/lower:lowering", ptr %t76, i32 0, i32 1
  %t79 = load ptr, ptr %t78, !tbaa !29
  %t81 = getelementptr %"compiler/typed:Body", ptr %t79, i32 0, i32 8
  %t83 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockInfo_3e_2eLen__Hdc799a0fe091f8e84d50200d058b631d(ptr %v0, ptr %t81)
  store i64 %t83, ptr %l53
  br label %bb17
bb17:
  %t84 = load i64, ptr %l49, !tbaa !24
  %t85 = load i64, ptr %l53, !tbaa !24
  %t86 = icmp sge i64 %t84, %t85
  store i1 %t86, ptr %l47, !tbaa !21
  br label %bb18
bb18:
  %t88 = load i1, ptr %l47, !tbaa !21
  br i1 %t88, label %bb19, label %bb20
bb19:
  store i1 false, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t92 = getelementptr %"compiler/lower:lowering", ptr %t90, i32 0, i32 1
  %t93 = load ptr, ptr %t92, !tbaa !29
  %t95 = getelementptr %"compiler/typed:Body", ptr %t93, i32 0, i32 8
  %t96 = load i32, ptr %l3, !tbaa !23
  %t98 = sext i32 %t96 to i64
  %t101 = call %"compiler/typed:BlockInfo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockInfo_3e_2eAt_3ccompiler_2ftyped_3aBlockInfo_3e(ptr %v0, ptr %t95, i64 %t98)
  store %"compiler/typed:BlockInfo" %t101, ptr %l61
  br label %bb22
bb22:
  %t102 = getelementptr %"compiler/typed:BlockInfo", ptr %l61, i32 0, i32 0
  %t103 = load i32, ptr %t102, !tbaa !23
  store i32 %t103, ptr %l3, !tbaa !23
  br label %bb23
bb23:
  %t105 = load i64, ptr %l8, !tbaa !24
  %t107 = add i64 %t105, 1
  store i64 %t107, ptr %l8, !tbaa !24
  br label %bb8
bb24:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eerrConvert(ptr %v0, ptr %a0, { i64, [4 x i64] } %a1, i32 %a2, i32 %a3, %"compiler/source:Span" %a4) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca { i64, [4 x i64] }
  %l8 = alloca i32
  %l9 = alloca %"compiler/lower:pl"
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i32
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i32
  %l26 = alloca i32
  %l27 = alloca { i64, [4 x i64] }
  %l34 = alloca i32
  %l35 = alloca ptr
  %l36 = alloca i32
  %l40 = alloca { i64, [4 x i64] }
  %l43 = alloca i32
  %l46 = alloca i32
  %l49 = alloca { i64, [4 x i64] }
  %l52 = alloca i1
  %l58 = alloca i32
  %l59 = alloca ptr
  %l60 = alloca %"compiler/source:Span"
  %l62 = alloca %"compiler/mir:Lvalue"
  %l66 = alloca { i64, [21 x i64] }
  %l70 = alloca %"compiler/lower:pl"
  %l71 = alloca ptr
  %l72 = alloca %"compiler/source:Span"
  %l73 = alloca ptr
  %l74 = alloca ptr
  %l75 = alloca %"compiler/lower:pl"
  %l77 = alloca %"compiler/lower:pl"
  %l79 = alloca %"compiler/lower:pl"
  %l80 = alloca %"compiler/mir:Lvalue"
  %l83 = alloca { i64, [21 x i64] }
  %l87 = alloca i1
  %l90 = alloca %"compiler/mir:Lvalue"
  %l92 = alloca ptr
  %l95 = alloca i32
  %l96 = alloca { i64, ptr }
  %l97 = alloca ptr
  %l100 = alloca i32
  %l101 = alloca { i64, ptr }
  %l107 = alloca i64
  %l110 = alloca i64
  %l129 = alloca { i64, ptr }
  %l132 = alloca i32
  %l137 = alloca i32
  %l145 = alloca i64
  %l148 = alloca i64
  %l167 = alloca { i64, ptr }
  %l170 = alloca i32
  %l175 = alloca i32
  %l178 = alloca i32
  %l179 = alloca ptr
  %l184 = alloca { i64, [4 x i64] }
  %l190 = alloca ptr
  %l191 = alloca ptr
  %l194 = alloca %"compiler/lower:pl"
  %l200 = alloca i64
  %l202 = alloca %"compiler/lower:pl"
  %l203 = alloca %"compiler/mir:Lvalue"
  %l205 = alloca ptr
  %l206 = alloca %"compiler/source:Span"
  %l207 = alloca ptr
  %l208 = alloca ptr
  %l209 = alloca %"compiler/lower:pl"
  %l211 = alloca %"compiler/lower:pl"
  %l217 = alloca i64
  %l219 = alloca %"compiler/lower:pl"
  %l220 = alloca %"compiler/mir:Lvalue"
  %l223 = alloca { i64, [21 x i64] }
  %l234 = alloca %"compiler/mir:Lvalue"
  %s0 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %rv = alloca { i64, [4 x i64] }
  %t35 = alloca { i64, [15 x i64] }, align 8
  %t76 = alloca { i64, [4 x i64] }, align 8
  %t83 = alloca { i64, [15 x i64] }, align 8
  %t89 = alloca { i64, [21 x i64] }, align 8
  %t102 = alloca { i64, [2 x i64] }, align 8
  %t118 = alloca { i64, [1 x i64] }, align 8
  %t131 = alloca { i64, [15 x i64] }, align 8
  %t137 = alloca { i64, [21 x i64] }, align 8
  %t160 = alloca { i64, [4 x i64] }, align 8
  %t355 = alloca { i64, [8 x i64] }, align 8
  %t374 = alloca { i64, [2 x i64] }, align 8
  %t395 = alloca { i64, [1 x i64] }, align 8
  %t408 = alloca { i64, [4 x i64] }, align 8
  %t435 = alloca { i64, [1 x i64] }, align 8
  %t449 = alloca { i64, [15 x i64] }, align 8
  %t455 = alloca { i64, [21 x i64] }, align 8
  %t486 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  store i32 %a3, ptr %l3
  store %"compiler/source:Span" %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l5, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = load i32, ptr %l2, !tbaa !23
  %t9 = load %"compiler/source:Span", ptr %l4
  %t14 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2elocal(ptr %v0, ptr %t6, { i64, [4 x i64] } %a1, i32 %t8, %"compiler/source:Span" %t9)
  store i32 %t14, ptr %l34
  br label %bb1
bb1:
  %t15 = load i32, ptr %l34, !tbaa !23
  store i32 %t15, ptr %l6, !tbaa !23
  %t16 = load ptr, ptr %l0, !tbaa !29
  store ptr %t16, ptr %l35, !tbaa !29
  %t17 = load i32, ptr @G_2ecompiler_2fmir_2eI32T, !tbaa !23
  store i32 %t17, ptr %l36, !tbaa !23
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t19 = load i32, ptr %l6, !tbaa !23
  %t20 = load i32, ptr %l2, !tbaa !23
  %t24 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eerrCodeOf(ptr %v0, ptr %t18, i32 %t19, i32 %t20)
  store { i64, [4 x i64] } %t24, ptr %l40
  br label %bb2
bb2:
  %t25 = load ptr, ptr %l5, !tbaa !29
  %t26 = load i32, ptr %l2, !tbaa !23
  %t29 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrValItems(ptr %v0, ptr %t25, i32 %t26)
  store i32 %t29, ptr %l43
  br label %bb3
bb3:
  %t30 = load ptr, ptr %l5, !tbaa !29
  %t31 = load i32, ptr %l3, !tbaa !23
  %t34 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrValItems(ptr %v0, ptr %t30, i32 %t31)
  store i32 %t34, ptr %l46
  br label %bb4
bb4:
  store { i64, [15 x i64] } zeroinitializer, ptr %t35
  %t36 = getelementptr { i64, [15 x i64] }, ptr %t35, i32 0, i32 0
  store i64 11, ptr %t36
  %t37 = load { i64, [4 x i64] }, ptr %l40
  %t38 = insertvalue { { i64, [4 x i64] }, i32, i32 } undef, { i64, [4 x i64] } %t37, 0
  %t39 = load i32, ptr %l43, !tbaa !23
  %t40 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t38, i32 %t39, 1
  %t41 = load i32, ptr %l46, !tbaa !23
  %t42 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t40, i32 %t41, 2
  %t43 = getelementptr { i64, [15 x i64] }, ptr %t35, i32 0, i32 1
  store { { i64, [4 x i64] }, i32, i32 } %t42, ptr %t43
  %t44 = load { i64, [15 x i64] }, ptr %t35
  %t45 = load %"compiler/source:Span", ptr %l4
  %t46 = load ptr, ptr %l35, !tbaa !29
  %t47 = load i32, ptr %l36, !tbaa !23
  %t50 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %t46, i32 %t47, { i64, [15 x i64] } %t44, %"compiler/source:Span" %t45)
  store { i64, [4 x i64] } %t50, ptr %l49
  br label %bb5
bb5:
  %t51 = load { i64, [4 x i64] }, ptr %l49
  store { i64, [4 x i64] } %t51, ptr %l7
  %t52 = load ptr, ptr %l5, !tbaa !29
  %t53 = load i32, ptr %l3, !tbaa !23
  %t56 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrCarries(ptr %v0, ptr %t52, i32 %t53)
  store i1 %t56, ptr %l52
  br label %bb6
bb6:
  %t57 = load i1, ptr %l52, !tbaa !21
  %t58 = xor i1 %t57, true
  br i1 %t58, label %bb7, label %bb8
bb7:
  %t60 = load { i64, [4 x i64] }, ptr %l7
  call void @__olang_scope_close(ptr %s0)
  store { i64, [4 x i64] } %t60, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t63 = load i32, ptr %l3, !tbaa !23
  %t64 = load %"compiler/source:Span", ptr %l4
  %t68 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2etemp(ptr %v0, ptr %t62, i32 %t63, %"compiler/source:Span" %t64)
  store i32 %t68, ptr %l58
  br label %bb10
bb10:
  %t69 = load i32, ptr %l58, !tbaa !23
  store i32 %t69, ptr %l8, !tbaa !23
  %t70 = load ptr, ptr %l0, !tbaa !29
  store ptr %t70, ptr %l59, !tbaa !29
  %t71 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t71, ptr %l60
  %t72 = load i32, ptr %l8, !tbaa !23
  %t74 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t72)
  store %"compiler/mir:Lvalue" %t74, ptr %l62
  br label %bb11
bb11:
  %t75 = load i32, ptr %l3, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t76
  %t77 = getelementptr { i64, [4 x i64] }, ptr %t76, i32 0, i32 0
  store i64 2, ptr %t77
  %t79 = insertvalue { i32, i64 } undef, i32 %t75, 0
  %t80 = insertvalue { i32, i64 } %t79, i64 0, 1
  %t81 = getelementptr { i64, [4 x i64] }, ptr %t76, i32 0, i32 1
  store { i32, i64 } %t80, ptr %t81
  %t82 = load { i64, [4 x i64] }, ptr %t76
  store { i64, [15 x i64] } zeroinitializer, ptr %t83
  %t84 = getelementptr { i64, [15 x i64] }, ptr %t83, i32 0, i32 0
  store i64 0, ptr %t84
  %t86 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t82, 0
  %t87 = getelementptr { i64, [15 x i64] }, ptr %t83, i32 0, i32 1
  store { { i64, [4 x i64] } } %t86, ptr %t87
  %t88 = load { i64, [15 x i64] }, ptr %t83
  store { i64, [21 x i64] } zeroinitializer, ptr %t89
  %t90 = getelementptr { i64, [21 x i64] }, ptr %t89, i32 0, i32 0
  store i64 0, ptr %t90
  %t91 = load %"compiler/source:Span", ptr %l60
  %t92 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t91, 0
  %t93 = load %"compiler/mir:Lvalue", ptr %l62
  %t94 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t92, %"compiler/mir:Lvalue" %t93, 1
  %t96 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t94, { i64, [15 x i64] } %t88, 2
  %t97 = getelementptr { i64, [21 x i64] }, ptr %t89, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t96, ptr %t97
  %t98 = load { i64, [21 x i64] }, ptr %t89
  store { i64, [21 x i64] } %t98, ptr %l66
  %t99 = load ptr, ptr %l59, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s0, ptr %t99, ptr %l66)
  br label %bb12
bb12:
  %t101 = load i32, ptr %l8, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t102
  %t103 = getelementptr { i64, [2 x i64] }, ptr %t102, i32 0, i32 0
  store i64 1, ptr %t103
  %t105 = insertvalue { i32 } undef, i32 %t101, 0
  %t106 = getelementptr { i64, [2 x i64] }, ptr %t102, i32 0, i32 1
  store { i32 } %t105, ptr %t106
  %t107 = load { i64, [2 x i64] }, ptr %t102
  %t109 = call %"compiler/lower:pl" @compiler_2flower_3apl_2ector(ptr %s0, { i64, [2 x i64] } %t107)
  store %"compiler/lower:pl" %t109, ptr %l70
  br label %bb13
bb13:
  %t110 = load %"compiler/lower:pl", ptr %l70
  store %"compiler/lower:pl" %t110, ptr %l9
  %t111 = load ptr, ptr %l0, !tbaa !29
  store ptr %t111, ptr %l71, !tbaa !29
  %t112 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t112, ptr %l72
  %t113 = load ptr, ptr %l0, !tbaa !29
  store ptr %t113, ptr %l73, !tbaa !29
  %t114 = load ptr, ptr %l0, !tbaa !29
  store ptr %t114, ptr %l74, !tbaa !29
  %t115 = load %"compiler/lower:pl", ptr %l9
  store %"compiler/lower:pl" %t115, ptr %l75
  %t117 = call %"compiler/lower:pl" @olang_2eHelperKind_2eCopy_2ecompiler_2flower_3apl(ptr %s0, ptr %l75)
  store %"compiler/lower:pl" %t117, ptr %l77
  br label %bb14
bb14:
  store { i64, [1 x i64] } zeroinitializer, ptr %t118
  %t119 = getelementptr { i64, [1 x i64] }, ptr %t118, i32 0, i32 0
  store i64 0, ptr %t119
  %t120 = insertvalue { i64 } undef, i64 0, 0
  %t121 = getelementptr { i64, [1 x i64] }, ptr %t118, i32 0, i32 1
  store { i64 } %t120, ptr %t121
  %t122 = load { i64, [1 x i64] }, ptr %t118
  %t123 = load ptr, ptr %l74, !tbaa !29
  %t124 = load %"compiler/lower:pl", ptr %l77
  %t126 = call %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2ewith(ptr %v0, ptr %s0, ptr %s0, ptr %t123, %"compiler/lower:pl" %t124, { i64, [1 x i64] } %t122)
  store %"compiler/lower:pl" %t126, ptr %l79
  br label %bb15
bb15:
  %t127 = load ptr, ptr %l73, !tbaa !29
  %t128 = load %"compiler/lower:pl", ptr %l79
  %t129 = call %"compiler/mir:Lvalue" @compiler_2flower_2ecompiler_2flower_3alowering_2emk(ptr %v0, ptr %s0, ptr %t127, %"compiler/lower:pl" %t128)
  store %"compiler/mir:Lvalue" %t129, ptr %l80
  br label %bb16
bb16:
  %t130 = load { i64, [4 x i64] }, ptr %l7
  store { i64, [15 x i64] } zeroinitializer, ptr %t131
  %t132 = getelementptr { i64, [15 x i64] }, ptr %t131, i32 0, i32 0
  store i64 0, ptr %t132
  %t134 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t130, 0
  %t135 = getelementptr { i64, [15 x i64] }, ptr %t131, i32 0, i32 1
  store { { i64, [4 x i64] } } %t134, ptr %t135
  %t136 = load { i64, [15 x i64] }, ptr %t131
  store { i64, [21 x i64] } zeroinitializer, ptr %t137
  %t138 = getelementptr { i64, [21 x i64] }, ptr %t137, i32 0, i32 0
  store i64 0, ptr %t138
  %t139 = load %"compiler/source:Span", ptr %l72
  %t140 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t139, 0
  %t141 = load %"compiler/mir:Lvalue", ptr %l80
  %t142 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t140, %"compiler/mir:Lvalue" %t141, 1
  %t144 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t142, { i64, [15 x i64] } %t136, 2
  %t145 = getelementptr { i64, [21 x i64] }, ptr %t137, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t144, ptr %t145
  %t146 = load { i64, [21 x i64] }, ptr %t137
  store { i64, [21 x i64] } %t146, ptr %l83
  %t147 = load ptr, ptr %l71, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s0, ptr %t147, ptr %l83)
  br label %bb17
bb17:
  %t149 = load ptr, ptr %l5, !tbaa !29
  %t150 = load i32, ptr %l2, !tbaa !23
  %t153 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrCarries(ptr %v0, ptr %t149, i32 %t150)
  store i1 %t153, ptr %l87
  br label %bb18
bb18:
  %t154 = load i1, ptr %l87, !tbaa !21
  %t155 = xor i1 %t154, true
  br i1 %t155, label %bb19, label %bb20
bb19:
  %t157 = load i32, ptr %l8, !tbaa !23
  %t159 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t157)
  store %"compiler/mir:Lvalue" %t159, ptr %l90
  br label %bb21
bb20:
  br label %bb22
bb21:
  store { i64, [4 x i64] } zeroinitializer, ptr %t160
  %t161 = getelementptr { i64, [4 x i64] }, ptr %t160, i32 0, i32 0
  store i64 1, ptr %t161
  %t162 = load %"compiler/mir:Lvalue", ptr %l90
  %t163 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t162, 0
  %t164 = getelementptr { i64, [4 x i64] }, ptr %t160, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t163, ptr %t164
  %t165 = load { i64, [4 x i64] }, ptr %t160
  call void @__olang_scope_close(ptr %s0)
  store { i64, [4 x i64] } %t165, ptr %rv
  br label %ret
bb22:
  %t167 = load ptr, ptr %l5, !tbaa !29
  store ptr %t167, ptr %l92, !tbaa !29
  %t168 = load ptr, ptr %l5, !tbaa !29
  %t169 = load i32, ptr %l2, !tbaa !23
  %t172 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrValItems(ptr %v0, ptr %t168, i32 %t169)
  store i32 %t172, ptr %l95
  br label %bb23
bb23:
  %t173 = load ptr, ptr %l92, !tbaa !29
  %t174 = load i32, ptr %l95, !tbaa !23
  %t175 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t173, i32 %t174)
  store { i64, ptr } %t175, ptr %l96
  br label %bb24
bb24:
  %t176 = load { i64, ptr }, ptr %l96, !tbaa !27
  store { i64, ptr } %t176, ptr %l10, !tbaa !27
  %t177 = load ptr, ptr %l5, !tbaa !29
  store ptr %t177, ptr %l97, !tbaa !29
  %t178 = load ptr, ptr %l5, !tbaa !29
  %t179 = load i32, ptr %l3, !tbaa !23
  %t182 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrValItems(ptr %v0, ptr %t178, i32 %t179)
  store i32 %t182, ptr %l100
  br label %bb25
bb25:
  %t183 = load ptr, ptr %l97, !tbaa !29
  %t184 = load i32, ptr %l100, !tbaa !23
  %t185 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t183, i32 %t184)
  store { i64, ptr } %t185, ptr %l101
  br label %bb26
bb26:
  %t186 = load { i64, ptr }, ptr %l101, !tbaa !27
  store { i64, ptr } %t186, ptr %l11, !tbaa !27
  store i64 0, ptr %l12, !tbaa !24
  %t187 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t189 = extractvalue { i64, ptr } %t187, 0
  store i64 %t189, ptr %l13, !tbaa !24
  store i64 1, ptr %l14, !tbaa !24
  %t191 = load i64, ptr %l13, !tbaa !24
  %t192 = load i64, ptr %l12, !tbaa !24
  %t195 = icmp sgt i64 %t191, %t192
  br i1 %t195, label %bb27, label %bb28
bb27:
  %t197 = load i64, ptr %l14, !tbaa !24
  %t199 = icmp sgt i64 %t197, 0
  br i1 %t199, label %bb29, label %bb30
bb28:
  store i64 0, ptr %l107, !tbaa !24
  br label %bb32
bb29:
  %t201 = load i64, ptr %l13, !tbaa !24
  %t202 = load i64, ptr %l12, !tbaa !24
  %t205 = sub i64 %t201, %t202
  %t206 = load i64, ptr %l14, !tbaa !24
  %t209 = add i64 %t205, %t206
  %t211 = sub i64 %t209, 1
  %t212 = load i64, ptr %l14, !tbaa !24
  %t215 = sdiv i64 %t211, %t212
  store i64 %t215, ptr %l110, !tbaa !24
  br label %bb31
bb30:
  store i64 0, ptr %l110, !tbaa !24
  br label %bb31
bb31:
  %t217 = load i64, ptr %l110, !tbaa !24
  store i64 %t217, ptr %l107, !tbaa !24
  br label %bb32
bb32:
  %t218 = load i64, ptr %l107, !tbaa !24
  store i64 %t218, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  br label %bb33
bb33:
  %t219 = load i64, ptr %l16, !tbaa !24
  %t220 = load i64, ptr %l15, !tbaa !24
  %t223 = icmp slt i64 %t219, %t220
  %t225 = xor i1 %t223, true
  br i1 %t225, label %bb34, label %bb35
bb34:
  br label %bb75
bb35:
  br label %bb36
bb36:
  %t227 = load i64, ptr %l12, !tbaa !24
  %t228 = load i64, ptr %l16, !tbaa !24
  %t229 = load i64, ptr %l14, !tbaa !24
  %t232 = mul i64 %t228, %t229
  %t235 = add i64 %t227, %t232
  store i64 %t235, ptr %l17, !tbaa !24
  %t237 = load ptr, ptr %l5, !tbaa !29
  %t238 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t238, ptr %l129, !tbaa !27
  %t239 = load i64, ptr %l17, !tbaa !24
  %t241 = getelementptr { i64, ptr }, ptr %l129, i32 0, i32 1
  %t242 = load ptr, ptr %t241, !tbaa !27
  %t243 = getelementptr i32, ptr %t242, i64 %t239
  %t244 = load i32, ptr %t243, !tbaa !33
  %t247 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t237, i32 %t244)
  store i32 %t247, ptr %l132
  br label %bb37
bb37:
  %t248 = load i32, ptr %l132, !tbaa !23
  store i32 %t248, ptr %l18, !tbaa !23
  %t249 = load ptr, ptr %l0, !tbaa !29
  %t251 = getelementptr %"compiler/lower:lowering", ptr %t249, i32 0, i32 0
  %t252 = load ptr, ptr %t251, !tbaa !29
  %t254 = getelementptr %"compiler/lower:Lowerer", ptr %t252, i32 0, i32 0
  %t255 = load ptr, ptr %t254, !tbaa !29
  %t256 = load i32, ptr %l18, !tbaa !23
  %t259 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ePayloadOf(ptr %v0, ptr %t255, i32 %t256)
  store i32 %t259, ptr %l137
  br label %bb38
bb38:
  %t260 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t261 = load i32, ptr %l137, !tbaa !23
  %t263 = icmp eq i32 %t261, %t260
  br i1 %t263, label %bb39, label %bb40
bb39:
  br label %bb74
bb40:
  br label %bb41
bb41:
  store i64 0, ptr %l19, !tbaa !24
  %t265 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t267 = extractvalue { i64, ptr } %t265, 0
  store i64 %t267, ptr %l20, !tbaa !24
  store i64 1, ptr %l21, !tbaa !24
  %t269 = load i64, ptr %l20, !tbaa !24
  %t270 = load i64, ptr %l19, !tbaa !24
  %t273 = icmp sgt i64 %t269, %t270
  br i1 %t273, label %bb42, label %bb43
bb42:
  %t275 = load i64, ptr %l21, !tbaa !24
  %t277 = icmp sgt i64 %t275, 0
  br i1 %t277, label %bb44, label %bb45
bb43:
  store i64 0, ptr %l145, !tbaa !24
  br label %bb47
bb44:
  %t279 = load i64, ptr %l20, !tbaa !24
  %t280 = load i64, ptr %l19, !tbaa !24
  %t283 = sub i64 %t279, %t280
  %t284 = load i64, ptr %l21, !tbaa !24
  %t287 = add i64 %t283, %t284
  %t289 = sub i64 %t287, 1
  %t290 = load i64, ptr %l21, !tbaa !24
  %t293 = sdiv i64 %t289, %t290
  store i64 %t293, ptr %l148, !tbaa !24
  br label %bb46
bb45:
  store i64 0, ptr %l148, !tbaa !24
  br label %bb46
bb46:
  %t295 = load i64, ptr %l148, !tbaa !24
  store i64 %t295, ptr %l145, !tbaa !24
  br label %bb47
bb47:
  %t296 = load i64, ptr %l145, !tbaa !24
  store i64 %t296, ptr %l22, !tbaa !24
  store i64 0, ptr %l23, !tbaa !24
  br label %bb48
bb48:
  store %olang.scope zeroinitializer, ptr %s7
  %t297 = load i64, ptr %l23, !tbaa !24
  %t298 = load i64, ptr %l22, !tbaa !24
  %t301 = icmp slt i64 %t297, %t298
  %t303 = xor i1 %t301, true
  br i1 %t303, label %bb49, label %bb50
bb49:
  call void @__olang_scope_close(ptr %s7)
  br label %bb73
bb50:
  br label %bb51
bb51:
  %t305 = load i64, ptr %l19, !tbaa !24
  %t306 = load i64, ptr %l23, !tbaa !24
  %t307 = load i64, ptr %l21, !tbaa !24
  %t310 = mul i64 %t306, %t307
  %t313 = add i64 %t305, %t310
  store i64 %t313, ptr %l24, !tbaa !24
  %t315 = load ptr, ptr %l5, !tbaa !29
  %t316 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t316, ptr %l167, !tbaa !27
  %t317 = load i64, ptr %l24, !tbaa !24
  %t319 = getelementptr { i64, ptr }, ptr %l167, i32 0, i32 1
  %t320 = load ptr, ptr %t319, !tbaa !27
  %t321 = getelementptr i32, ptr %t320, i64 %t317
  %t322 = load i32, ptr %t321, !tbaa !33
  %t325 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t315, i32 %t322)
  store i32 %t325, ptr %l170
  br label %bb52
bb52:
  %t326 = load i32, ptr %l18, !tbaa !23
  %t327 = load i32, ptr %l170, !tbaa !23
  %t329 = icmp ne i32 %t327, %t326
  br i1 %t329, label %bb53, label %bb54
bb53:
  call void @__olang_scope_close(ptr %s7)
  br label %bb72
bb54:
  br label %bb55
bb55:
  %t331 = load ptr, ptr %l0, !tbaa !29
  %t333 = getelementptr %"compiler/lower:lowering", ptr %t331, i32 0, i32 3
  %t335 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t333)
  store i32 %t335, ptr %l175
  br label %bb56
bb56:
  %t336 = load i32, ptr %l175, !tbaa !23
  store i32 %t336, ptr %l25, !tbaa !23
  %t337 = load ptr, ptr %l0, !tbaa !29
  %t339 = getelementptr %"compiler/lower:lowering", ptr %t337, i32 0, i32 3
  %t341 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t339)
  store i32 %t341, ptr %l178
  br label %bb57
bb57:
  %t342 = load i32, ptr %l178, !tbaa !23
  store i32 %t342, ptr %l26, !tbaa !23
  %t343 = load ptr, ptr %l0, !tbaa !29
  store ptr %t343, ptr %l179, !tbaa !29
  %t344 = load ptr, ptr %l0, !tbaa !29
  %t345 = load { i64, [4 x i64] }, ptr %l7
  %t346 = load i64, ptr %l24, !tbaa !24
  %t347 = load %"compiler/source:Span", ptr %l4
  %t352 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2etypeIs(ptr %v0, ptr %t344, { i64, [4 x i64] } %t345, i64 %t346, %"compiler/source:Span" %t347)
  store { i64, [4 x i64] } %t352, ptr %l184
  br label %bb58
bb58:
  %t353 = load i32, ptr %l25, !tbaa !23
  %t354 = load i32, ptr %l26, !tbaa !23
  store { i64, [8 x i64] } zeroinitializer, ptr %t355
  %t356 = getelementptr { i64, [8 x i64] }, ptr %t355, i32 0, i32 0
  store i64 2, ptr %t356
  %t357 = load { i64, [4 x i64] }, ptr %l184
  %t358 = insertvalue { { i64, [4 x i64] }, i32, i32 } undef, { i64, [4 x i64] } %t357, 0
  %t360 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t358, i32 %t353, 1
  %t362 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t360, i32 %t354, 2
  %t363 = getelementptr { i64, [8 x i64] }, ptr %t355, i32 0, i32 1
  store { { i64, [4 x i64] }, i32, i32 } %t362, ptr %t363
  %t364 = load { i64, [8 x i64] }, ptr %t355
  %t365 = load ptr, ptr %l179, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t365, { i64, [8 x i64] } %t364)
  br label %bb59
bb59:
  %t367 = load ptr, ptr %l0, !tbaa !29
  %t368 = load i32, ptr %l25, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t367, i32 %t368)
  br label %bb60
bb60:
  %t371 = load ptr, ptr %l0, !tbaa !29
  store ptr %t371, ptr %l190, !tbaa !29
  %t372 = load ptr, ptr %l0, !tbaa !29
  store ptr %t372, ptr %l191, !tbaa !29
  %t373 = load i32, ptr %l6, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t374
  %t375 = getelementptr { i64, [2 x i64] }, ptr %t374, i32 0, i32 0
  store i64 1, ptr %t375
  %t377 = insertvalue { i32 } undef, i32 %t373, 0
  %t378 = getelementptr { i64, [2 x i64] }, ptr %t374, i32 0, i32 1
  store { i32 } %t377, ptr %t378
  %t379 = load { i64, [2 x i64] }, ptr %t374
  %t381 = call %"compiler/lower:pl" @compiler_2flower_3apl_2ector(ptr %s7, { i64, [2 x i64] } %t379)
  store %"compiler/lower:pl" %t381, ptr %l194
  br label %bb61
bb61:
  %t382 = load ptr, ptr %l0, !tbaa !29
  %t384 = getelementptr %"compiler/lower:lowering", ptr %t382, i32 0, i32 0
  %t385 = load ptr, ptr %t384, !tbaa !29
  %t387 = getelementptr %"compiler/lower:Lowerer", ptr %t385, i32 0, i32 0
  %t388 = load ptr, ptr %t387, !tbaa !29
  %t389 = load i32, ptr %l2, !tbaa !23
  %t390 = load i64, ptr %l17, !tbaa !24
  %t394 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ePayloadField(ptr %v0, ptr %t388, i32 %t389, i64 %t390)
  store i64 %t394, ptr %l200
  br label %bb62
bb62:
  store { i64, [1 x i64] } zeroinitializer, ptr %t395
  %t396 = getelementptr { i64, [1 x i64] }, ptr %t395, i32 0, i32 0
  store i64 0, ptr %t396
  %t397 = load i64, ptr %l200, !tbaa !24
  %t398 = insertvalue { i64 } undef, i64 %t397, 0
  %t399 = getelementptr { i64, [1 x i64] }, ptr %t395, i32 0, i32 1
  store { i64 } %t398, ptr %t399
  %t400 = load { i64, [1 x i64] }, ptr %t395
  %t401 = load ptr, ptr %l191, !tbaa !29
  %t402 = load %"compiler/lower:pl", ptr %l194
  %t404 = call %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2ewith(ptr %v0, ptr %s7, ptr %s7, ptr %t401, %"compiler/lower:pl" %t402, { i64, [1 x i64] } %t400)
  store %"compiler/lower:pl" %t404, ptr %l202
  br label %bb63
bb63:
  %t405 = load ptr, ptr %l190, !tbaa !29
  %t406 = load %"compiler/lower:pl", ptr %l202
  %t407 = call %"compiler/mir:Lvalue" @compiler_2flower_2ecompiler_2flower_3alowering_2emk(ptr %v0, ptr %s7, ptr %t405, %"compiler/lower:pl" %t406)
  store %"compiler/mir:Lvalue" %t407, ptr %l203
  br label %bb64
bb64:
  store { i64, [4 x i64] } zeroinitializer, ptr %t408
  %t409 = getelementptr { i64, [4 x i64] }, ptr %t408, i32 0, i32 0
  store i64 1, ptr %t409
  %t410 = load %"compiler/mir:Lvalue", ptr %l203
  %t411 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t410, 0
  %t412 = getelementptr { i64, [4 x i64] }, ptr %t408, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t411, ptr %t412
  %t413 = load { i64, [4 x i64] }, ptr %t408
  store { i64, [4 x i64] } %t413, ptr %l27
  %t415 = load ptr, ptr %l0, !tbaa !29
  store ptr %t415, ptr %l205, !tbaa !29
  %t416 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t416, ptr %l206
  %t417 = load ptr, ptr %l0, !tbaa !29
  store ptr %t417, ptr %l207, !tbaa !29
  %t418 = load ptr, ptr %l0, !tbaa !29
  store ptr %t418, ptr %l208, !tbaa !29
  %t419 = load %"compiler/lower:pl", ptr %l9
  store %"compiler/lower:pl" %t419, ptr %l209
  %t421 = call %"compiler/lower:pl" @olang_2eHelperKind_2eCopy_2ecompiler_2flower_3apl(ptr %s7, ptr %l209)
  store %"compiler/lower:pl" %t421, ptr %l211
  br label %bb65
bb65:
  %t422 = load ptr, ptr %l0, !tbaa !29
  %t424 = getelementptr %"compiler/lower:lowering", ptr %t422, i32 0, i32 0
  %t425 = load ptr, ptr %t424, !tbaa !29
  %t427 = getelementptr %"compiler/lower:Lowerer", ptr %t425, i32 0, i32 0
  %t428 = load ptr, ptr %t427, !tbaa !29
  %t429 = load i32, ptr %l3, !tbaa !23
  %t430 = load i64, ptr %l24, !tbaa !24
  %t434 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ePayloadField(ptr %v0, ptr %t428, i32 %t429, i64 %t430)
  store i64 %t434, ptr %l217
  br label %bb66
bb66:
  store { i64, [1 x i64] } zeroinitializer, ptr %t435
  %t436 = getelementptr { i64, [1 x i64] }, ptr %t435, i32 0, i32 0
  store i64 0, ptr %t436
  %t437 = load i64, ptr %l217, !tbaa !24
  %t438 = insertvalue { i64 } undef, i64 %t437, 0
  %t439 = getelementptr { i64, [1 x i64] }, ptr %t435, i32 0, i32 1
  store { i64 } %t438, ptr %t439
  %t440 = load { i64, [1 x i64] }, ptr %t435
  %t441 = load ptr, ptr %l208, !tbaa !29
  %t442 = load %"compiler/lower:pl", ptr %l211
  %t444 = call %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2ewith(ptr %v0, ptr %s7, ptr %s7, ptr %t441, %"compiler/lower:pl" %t442, { i64, [1 x i64] } %t440)
  store %"compiler/lower:pl" %t444, ptr %l219
  br label %bb67
bb67:
  %t445 = load ptr, ptr %l207, !tbaa !29
  %t446 = load %"compiler/lower:pl", ptr %l219
  %t447 = call %"compiler/mir:Lvalue" @compiler_2flower_2ecompiler_2flower_3alowering_2emk(ptr %v0, ptr %s7, ptr %t445, %"compiler/lower:pl" %t446)
  store %"compiler/mir:Lvalue" %t447, ptr %l220
  br label %bb68
bb68:
  %t448 = load { i64, [4 x i64] }, ptr %l27
  store { i64, [15 x i64] } zeroinitializer, ptr %t449
  %t450 = getelementptr { i64, [15 x i64] }, ptr %t449, i32 0, i32 0
  store i64 0, ptr %t450
  %t452 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t448, 0
  %t453 = getelementptr { i64, [15 x i64] }, ptr %t449, i32 0, i32 1
  store { { i64, [4 x i64] } } %t452, ptr %t453
  %t454 = load { i64, [15 x i64] }, ptr %t449
  store { i64, [21 x i64] } zeroinitializer, ptr %t455
  %t456 = getelementptr { i64, [21 x i64] }, ptr %t455, i32 0, i32 0
  store i64 0, ptr %t456
  %t457 = load %"compiler/source:Span", ptr %l206
  %t458 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t457, 0
  %t459 = load %"compiler/mir:Lvalue", ptr %l220
  %t460 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t458, %"compiler/mir:Lvalue" %t459, 1
  %t462 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t460, { i64, [15 x i64] } %t454, 2
  %t463 = getelementptr { i64, [21 x i64] }, ptr %t455, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t462, ptr %t463
  %t464 = load { i64, [21 x i64] }, ptr %t455
  store { i64, [21 x i64] } %t464, ptr %l223
  %t465 = load ptr, ptr %l205, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s7, ptr %t465, ptr %l223)
  br label %bb69
bb69:
  %t467 = load ptr, ptr %l0, !tbaa !29
  %t468 = load i32, ptr %l26, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2egoto(ptr %v0, ptr %t467, i32 %t468)
  br label %bb70
bb70:
  %t471 = load ptr, ptr %l0, !tbaa !29
  %t472 = load i32, ptr %l26, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t471, i32 %t472)
  br label %bb71
bb71:
  call void @__olang_scope_close(ptr %s7)
  br label %bb72
bb72:
  %t475 = load i64, ptr %l23, !tbaa !24
  %t477 = add i64 %t475, 1
  store i64 %t477, ptr %l23, !tbaa !24
  br label %bb48
bb73:
  br label %bb74
bb74:
  %t479 = load i64, ptr %l16, !tbaa !24
  %t481 = add i64 %t479, 1
  store i64 %t481, ptr %l16, !tbaa !24
  br label %bb33
bb75:
  %t483 = load i32, ptr %l8, !tbaa !23
  %t485 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t483)
  store %"compiler/mir:Lvalue" %t485, ptr %l234
  br label %bb76
bb76:
  store { i64, [4 x i64] } zeroinitializer, ptr %t486
  %t487 = getelementptr { i64, [4 x i64] }, ptr %t486, i32 0, i32 0
  store i64 1, ptr %t487
  %t488 = load %"compiler/mir:Lvalue", ptr %l234
  %t489 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t488, 0
  %t490 = getelementptr { i64, [4 x i64] }, ptr %t486, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t489, ptr %t490
  %t491 = load { i64, [4 x i64] }, ptr %t486
  call void @__olang_scope_close(ptr %s0)
  store { i64, [4 x i64] } %t491, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eescapes(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l12 = alloca i1
  %l16 = alloca i64
  %l20 = alloca i64
  %l23 = alloca i64
  %l44 = alloca i64
  %l47 = alloca i1
  %l49 = alloca ptr
  %l53 = alloca i64
  %l57 = alloca i64
  %l58 = alloca i1
  %rv = alloca i1
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/typed:LocalUses", ptr %t1, i32 0, i32 6
  %t4 = load i64, ptr %l2, !tbaa !24
  %t7 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v1, ptr %t3, i64 %t4)
  store i1 %t7, ptr %l12
  br label %bb1
bb1:
  %t8 = load i1, ptr %l12, !tbaa !21
  br i1 %t8, label %bb2, label %bb3
bb2:
  store i1 true, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  store i64 0, ptr %l3, !tbaa !24
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr %"compiler/typed:LocalUses", ptr %t10, i32 0, i32 15
  %t14 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t12)
  store i64 %t14, ptr %l16
  br label %bb5
bb5:
  %t15 = load i64, ptr %l16, !tbaa !24
  store i64 %t15, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t16 = load i64, ptr %l4, !tbaa !24
  %t17 = load i64, ptr %l3, !tbaa !24
  %t20 = icmp sgt i64 %t16, %t17
  br i1 %t20, label %bb6, label %bb7
bb6:
  %t22 = load i64, ptr %l5, !tbaa !24
  %t24 = icmp sgt i64 %t22, 0
  br i1 %t24, label %bb8, label %bb9
bb7:
  store i64 0, ptr %l20, !tbaa !24
  br label %bb11
bb8:
  %t26 = load i64, ptr %l4, !tbaa !24
  %t27 = load i64, ptr %l3, !tbaa !24
  %t30 = sub i64 %t26, %t27
  %t31 = load i64, ptr %l5, !tbaa !24
  %t34 = add i64 %t30, %t31
  %t36 = sub i64 %t34, 1
  %t37 = load i64, ptr %l5, !tbaa !24
  %t40 = sdiv i64 %t36, %t37
  store i64 %t40, ptr %l23, !tbaa !24
  br label %bb10
bb9:
  store i64 0, ptr %l23, !tbaa !24
  br label %bb10
bb10:
  %t42 = load i64, ptr %l23, !tbaa !24
  store i64 %t42, ptr %l20, !tbaa !24
  br label %bb11
bb11:
  %t43 = load i64, ptr %l20, !tbaa !24
  store i64 %t43, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb12
bb12:
  %t44 = load i64, ptr %l7, !tbaa !24
  %t45 = load i64, ptr %l6, !tbaa !24
  %t48 = icmp slt i64 %t44, %t45
  %t50 = xor i1 %t48, true
  br i1 %t50, label %bb13, label %bb14
bb13:
  br label %bb27
bb14:
  br label %bb15
bb15:
  %t52 = load i64, ptr %l3, !tbaa !24
  %t53 = load i64, ptr %l7, !tbaa !24
  %t54 = load i64, ptr %l5, !tbaa !24
  %t57 = mul i64 %t53, %t54
  %t60 = add i64 %t52, %t57
  store i64 %t60, ptr %l8, !tbaa !24
  %t62 = load ptr, ptr %l1, !tbaa !29
  %t64 = getelementptr %"compiler/typed:LocalUses", ptr %t62, i32 0, i32 15
  %t65 = load i64, ptr %l8, !tbaa !24
  %t68 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t64, i64 %t65)
  store i64 %t68, ptr %l44
  br label %bb16
bb16:
  %t69 = load i64, ptr %l2, !tbaa !24
  %t70 = load i64, ptr %l44, !tbaa !24
  %t72 = icmp eq i64 %t70, %t69
  br i1 %t72, label %bb17, label %bb18
bb17:
  %t76 = getelementptr %"compiler/lower:lowering", ptr %a0, i32 0, i32 0
  %t77 = load ptr, ptr %t76, !tbaa !29
  store ptr %t77, ptr %l49, !tbaa !29
  %t78 = load ptr, ptr %l1, !tbaa !29
  %t80 = getelementptr %"compiler/typed:LocalUses", ptr %t78, i32 0, i32 16
  %t81 = load i64, ptr %l8, !tbaa !24
  %t84 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t80, i64 %t81)
  store i64 %t84, ptr %l53
  br label %bb19
bb18:
  store i1 false, ptr %l47, !tbaa !21
  br label %bb22
bb19:
  %t85 = load ptr, ptr %l1, !tbaa !29
  %t87 = getelementptr %"compiler/typed:LocalUses", ptr %t85, i32 0, i32 17
  %t88 = load i64, ptr %l8, !tbaa !24
  %t91 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t87, i64 %t88)
  store i64 %t91, ptr %l57
  br label %bb20
bb20:
  %t92 = load ptr, ptr %l49, !tbaa !29
  %t93 = load i64, ptr %l53, !tbaa !24
  %t94 = load i64, ptr %l57, !tbaa !24
  %t95 = call i1 @compiler_2flower_2ecompiler_2flower_3aLowerer_2ekeepsNoRef(ptr %v0, ptr %t92, i64 %t93, i64 %t94)
  store i1 %t95, ptr %l58
  br label %bb21
bb21:
  %t96 = load i1, ptr %l58, !tbaa !21
  %t97 = xor i1 %t96, true
  store i1 %t97, ptr %l47, !tbaa !21
  br label %bb22
bb22:
  %t99 = load i1, ptr %l47, !tbaa !21
  br i1 %t99, label %bb23, label %bb24
bb23:
  store i1 true, ptr %rv
  br label %ret
bb24:
  br label %bb25
bb25:
  br label %bb26
bb26:
  %t101 = load i64, ptr %l7, !tbaa !24
  %t103 = add i64 %t101, 1
  store i64 %t103, ptr %l7, !tbaa !24
  br label %bb12
bb27:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2flower_2ecompiler_2flower_3alowering_2eflag(ptr %v0, ptr %a0, i1 %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l7 = alloca i32
  %l8 = alloca ptr
  %l9 = alloca %"compiler/source:Span"
  %l11 = alloca %"compiler/mir:Lvalue"
  %l15 = alloca { i64, [4 x i64] }
  %l17 = alloca { i64, [21 x i64] }
  %s0 = alloca %olang.scope
  %rv = alloca i32
  %t21 = alloca { i64, [15 x i64] }, align 8
  %t27 = alloca { i64, [21 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t3 = load %"compiler/source:Span", ptr %l2
  %t7 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2etemp(ptr %v0, ptr %t1, i32 %t2, %"compiler/source:Span" %t3)
  store i32 %t7, ptr %l7
  br label %bb1
bb1:
  %t8 = load i32, ptr %l7, !tbaa !23
  store i32 %t8, ptr %l3, !tbaa !23
  %t9 = load ptr, ptr %l0, !tbaa !29
  store ptr %t9, ptr %l8, !tbaa !29
  %t10 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t10, ptr %l9
  %t11 = load i32, ptr %l3, !tbaa !23
  %t13 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t11)
  store %"compiler/mir:Lvalue" %t13, ptr %l11
  br label %bb2
bb2:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = load %"compiler/source:Span", ptr %l2
  %t20 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2econstBool(ptr %v0, ptr %t14, i1 %a1, %"compiler/source:Span" %t16)
  store { i64, [4 x i64] } %t20, ptr %l15
  br label %bb3
bb3:
  store { i64, [15 x i64] } zeroinitializer, ptr %t21
  %t22 = getelementptr { i64, [15 x i64] }, ptr %t21, i32 0, i32 0
  store i64 0, ptr %t22
  %t23 = load { i64, [4 x i64] }, ptr %l15
  %t24 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t23, 0
  %t25 = getelementptr { i64, [15 x i64] }, ptr %t21, i32 0, i32 1
  store { { i64, [4 x i64] } } %t24, ptr %t25
  %t26 = load { i64, [15 x i64] }, ptr %t21
  store { i64, [21 x i64] } zeroinitializer, ptr %t27
  %t28 = getelementptr { i64, [21 x i64] }, ptr %t27, i32 0, i32 0
  store i64 0, ptr %t28
  %t29 = load %"compiler/source:Span", ptr %l9
  %t30 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t29, 0
  %t31 = load %"compiler/mir:Lvalue", ptr %l11
  %t32 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t30, %"compiler/mir:Lvalue" %t31, 1
  %t34 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t32, { i64, [15 x i64] } %t26, 2
  %t35 = getelementptr { i64, [21 x i64] }, ptr %t27, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t34, ptr %t35
  %t36 = load { i64, [21 x i64] }, ptr %t27
  store { i64, [21 x i64] } %t36, ptr %l17
  %t37 = load ptr, ptr %l8, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s0, ptr %t37, ptr %l17)
  br label %bb4
bb4:
  %t39 = load i32, ptr %l3, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t39, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3alowering_2efreshCall(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i32
  %l6 = alloca ptr
  %l12 = alloca i1
  %l13 = alloca ptr
  %l14 = alloca i1
  %l23 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call ptr @compiler_2flower_2eviewCallIn(ptr %v1, ptr %v1, ptr %a1)
  store ptr %t3, ptr %l6
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l6, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t7 = icmp eq ptr %t5, null
  br i1 %t7, label %bb2, label %bb3
bb2:
  store i1 false, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t12 = getelementptr %"compiler/typed:Call", ptr %t10, i32 0, i32 0
  %t13 = load ptr, ptr %t12, !tbaa !29
  store ptr %t13, ptr %l3, !tbaa !29
  %t15 = load ptr, ptr %l3, !tbaa !29
  store ptr %t15, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t16 = load ptr, ptr %l13, !tbaa !29
  %t17 = icmp ne ptr %t16, null
  br i1 %t17, label %bb5, label %bb6
bb5:
  %t19 = load ptr, ptr %l13, !tbaa !29
  %t20 = load i64, ptr %t19, !range !{i64 0, i64 5}
  %t22 = icmp eq i64 %t20, 0
  store i1 %t22, ptr %l14, !tbaa !21
  br label %bb6
bb6:
  %t23 = load i1, ptr %l14, !tbaa !21
  br i1 %t23, label %bb7, label %bb8
bb7:
  %t24 = load ptr, ptr %l3, !tbaa !29
  %t26 = getelementptr { i64, [3 x i64] }, ptr %t24, i32 0, i32 1
  %t27 = getelementptr { i32 }, ptr %t26, i32 0, i32 0
  %t28 = load i32, ptr %t27
  store i32 %t28, ptr %l4, !tbaa !23
  br label %bb9
bb8:
  br label %bb11
bb9:
  %t32 = getelementptr %"compiler/lower:lowering", ptr %a0, i32 0, i32 0
  %t33 = load ptr, ptr %t32, !tbaa !29
  %t34 = load i32, ptr %l4, !tbaa !23
  %t36 = sext i32 %t34 to i64
  %t39 = call i1 @compiler_2flower_2ecompiler_2flower_3aLowerer_2efreshResult(ptr %v0, ptr %t33, i64 %t36)
  store i1 %t39, ptr %l23
  br label %bb10
bb10:
  %t40 = load i1, ptr %l23, !tbaa !21
  store i1 %t40, ptr %l12, !tbaa !21
  br label %bb16
bb11:
  br i1 true, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  store i1 false, ptr %l12, !tbaa !21
  br label %bb16
bb15:
  call void @__olang_check_failed(ptr @olang_loc_c9ff4911a436500b_5835334d424a3697)
  unreachable
bb16:
  %t41 = load i1, ptr %l12, !tbaa !21
  store i1 %t41, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2egap(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l8 = alloca ptr
  %l15 = alloca %"compiler/lower:Gap"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 8
  %t4 = load i1, ptr %t3, !tbaa !21
  %t6 = xor i1 %t4, true
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/lower:lowering", ptr %t8, i32 0, i32 0
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t13 = getelementptr %"compiler/lower:Lowerer", ptr %t11, i32 0, i32 4
  store ptr %t13, ptr %l8, !tbaa !29
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/lower:lowering", ptr %t14, i32 0, i32 4
  %t17 = load i64, ptr %t16, !tbaa !24
  %t21 = extractvalue { i64, ptr } %a2, 1
  %t22 = extractvalue { i64, ptr } %a2, 0
  %t23 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t22)
  call void @olang_textcopy(ptr %t23, ptr %t21, i64 %t22)
  %t24 = insertvalue { i64, ptr } undef, i64 %t22, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t23, 1
  %t27 = extractvalue { i64, ptr } %t25, 0
  %t28 = extractvalue { i64, ptr } %t25, 1
  %t29 = mul i64 %t27, 1
  %t30 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t29)
  call void @llvm.memcpy.p0.p0.i64(ptr %t30, ptr %t28, i64 %t29, i1 false)
  %t31 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  %t36 = call %"compiler/lower:Gap" @compiler_2flower_3aGap_2ector(ptr %v0, ptr %v0, i64 %t17, %"compiler/source:Span" %a1, { i64, ptr } %t32)
  store %"compiler/lower:Gap" %t36, ptr %l15
  br label %bb3
bb2:
  br label %bb5
bb3:
  %t37 = load ptr, ptr %l8, !tbaa !29
  %t38 = load %"compiler/lower:Gap", ptr %l15
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3aGap_3e_2ePush_3ccompiler_2flower_3aGap_3e(ptr %v0, ptr %v0, ptr %t37, %"compiler/lower:Gap" %t38)
  br label %bb4
bb4:
  br label %bb5
bb5:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/lower:lowering", ptr %t39, i32 0, i32 8
  store i1 true, ptr %t41, !tbaa !21
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2flower_2ecompiler_2flower_3alowering_2ehandedOver(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca i1
  %l17 = alloca i1
  %l30 = alloca { i64, ptr }
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t2 = load ptr, ptr %l8, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l8, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 12
  store i1 %t8, ptr %l9, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l9, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l3, !tbaa !29
  br label %bb5
bb4:
  br label %bb22
bb5:
  %t16 = load ptr, ptr %l3, !tbaa !29
  %t18 = getelementptr %"compiler/typed:Seq", ptr %t16, i32 0, i32 2
  %t19 = load i1, ptr %t18, !tbaa !21
  %t21 = xor i1 %t19, true
  br i1 %t21, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l17, !tbaa !21
  br label %bb8
bb7:
  %t23 = load ptr, ptr %l3, !tbaa !29
  %t25 = getelementptr %"compiler/typed:Seq", ptr %t23, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !29
  %t28 = icmp eq ptr %t26, null
  store i1 %t28, ptr %l17, !tbaa !21
  br label %bb8
bb8:
  %t30 = load i1, ptr %l17, !tbaa !21
  br i1 %t30, label %bb9, label %bb10
bb9:
  %t31 = load ptr, ptr %l1, !tbaa !29
  store ptr %t31, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t33 = load ptr, ptr %l3, !tbaa !29
  %t35 = getelementptr %"compiler/typed:Seq", ptr %t33, i32 0, i32 0
  %t36 = load { i64, ptr }, ptr %t35, !tbaa !27
  store { i64, ptr } %t36, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t38 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t40 = extractvalue { i64, ptr } %t38, 0
  store i64 %t40, ptr %l6, !tbaa !24
  br label %bb12
bb12:
  %t42 = load i64, ptr %l5, !tbaa !24
  %t43 = load i64, ptr %l6, !tbaa !24
  %t46 = icmp slt i64 %t42, %t43
  %t48 = xor i1 %t46, true
  br i1 %t48, label %bb13, label %bb14
bb13:
  br label %bb18
bb14:
  br label %bb15
bb15:
  %t50 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t50, ptr %l30, !tbaa !27
  %t51 = load i64, ptr %l5, !tbaa !24
  %t53 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !27
  %t55 = getelementptr ptr, ptr %t54, i64 %t51
  %t56 = load ptr, ptr %t55, !tbaa !39
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2ePush_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v2, ptr %v1, ptr %a2, ptr %t56)
  br label %bb16
bb16:
  br label %bb17
bb17:
  %t62 = load i64, ptr %l5, !tbaa !24
  %t64 = add i64 %t62, 1
  store i64 %t64, ptr %l5, !tbaa !24
  br label %bb12
bb18:
  %t66 = load ptr, ptr %l3, !tbaa !29
  %t68 = getelementptr %"compiler/typed:Seq", ptr %t66, i32 0, i32 1
  %t69 = load ptr, ptr %t68, !tbaa !29
  %t71 = icmp eq ptr %t69, null
  br i1 %t71, label %bb19, label %bb20
bb19:
  call void @__olang_check_failed(ptr @olang_loc_58c3cf8c6fce78d4_23ae1924195b9e70)
  unreachable
bb20:
  br label %bb21
bb21:
  %t73 = load ptr, ptr %l3, !tbaa !29
  %t75 = getelementptr %"compiler/typed:Seq", ptr %t73, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !29
  store ptr %t76, ptr %rv
  br label %ret
bb22:
  br i1 true, label %bb23, label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb26
bb25:
  %t78 = load ptr, ptr %l1, !tbaa !29
  store ptr %t78, ptr %rv
  br label %ret
bb26:
  call void @__olang_check_failed(ptr @olang_loc_3f94e1722b42397a_72ec18aae06ab796)
  unreachable
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eheldUnchanged(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca %"compiler/typed:Local"
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l14 = alloca %"compiler/typed:Local"
  %l17 = alloca i1
  %l22 = alloca i1
  %l28 = alloca i1
  %l29 = alloca i1
  %l33 = alloca i1
  %l34 = alloca i1
  %l38 = alloca i1
  %l39 = alloca i1
  %l43 = alloca i1
  %l48 = alloca i64
  %l52 = alloca i64
  %l55 = alloca i64
  %l76 = alloca i64
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/typed:Body", ptr %t4, i32 0, i32 7
  %t7 = load i64, ptr %l2, !tbaa !24
  %t10 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t6, i64 %t7)
  store %"compiler/typed:Local" %t10, ptr %l14
  br label %bb1
bb1:
  %t11 = load %"compiler/typed:Local", ptr %l14
  store %"compiler/typed:Local" %t11, ptr %l3
  %t12 = getelementptr %"compiler/typed:Local", ptr %l3, i32 0, i32 4
  %t13 = load i32, ptr %t12, !range !{i32 0, i32 7}
  %t15 = trunc i64 5 to i32
  %t16 = icmp eq i32 %t13, %t15
  br i1 %t16, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l17, !tbaa !21
  br label %bb5
bb3:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/typed:Local", ptr %l3, i32 0, i32 3
  %t20 = load i32, ptr %t19, !tbaa !23
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/lower:lowering", ptr %t21, i32 0, i32 41
  %t24 = load i32, ptr %t23, !tbaa !23
  %t28 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eencloses(ptr %v0, ptr %t18, i32 %t20, i32 %t24)
  store i1 %t28, ptr %l22
  br label %bb4
bb4:
  %t29 = load i1, ptr %l22, !tbaa !21
  %t30 = xor i1 %t29, true
  store i1 %t30, ptr %l17, !tbaa !21
  br label %bb5
bb5:
  %t32 = load i1, ptr %l17, !tbaa !21
  br i1 %t32, label %bb6, label %bb7
bb6:
  store i1 false, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t34 = load ptr, ptr %l1, !tbaa !29
  %t36 = getelementptr %"compiler/typed:LocalUses", ptr %t34, i32 0, i32 2
  %t37 = load i64, ptr %l2, !tbaa !24
  %t40 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v1, ptr %t36, i64 %t37)
  store i1 %t40, ptr %l28
  br label %bb9
bb9:
  %t41 = load i1, ptr %l28, !tbaa !21
  br i1 %t41, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l29, !tbaa !21
  br label %bb13
bb11:
  %t42 = load ptr, ptr %l1, !tbaa !29
  %t44 = getelementptr %"compiler/typed:LocalUses", ptr %t42, i32 0, i32 4
  %t45 = load i64, ptr %l2, !tbaa !24
  %t48 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v1, ptr %t44, i64 %t45)
  store i1 %t48, ptr %l33
  br label %bb12
bb12:
  %t49 = load i1, ptr %l33, !tbaa !21
  store i1 %t49, ptr %l29, !tbaa !21
  br label %bb13
bb13:
  %t50 = load i1, ptr %l29, !tbaa !21
  br i1 %t50, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l34, !tbaa !21
  br label %bb17
bb15:
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t52 = load ptr, ptr %l1, !tbaa !29
  %t53 = load i64, ptr %l2, !tbaa !24
  %t57 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eescapes(ptr %v0, ptr %v1, ptr %t51, ptr %t52, i64 %t53)
  store i1 %t57, ptr %l38
  br label %bb16
bb16:
  %t58 = load i1, ptr %l38, !tbaa !21
  store i1 %t58, ptr %l34, !tbaa !21
  br label %bb17
bb17:
  %t59 = load i1, ptr %l34, !tbaa !21
  br i1 %t59, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l39, !tbaa !21
  br label %bb21
bb19:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t61 = load ptr, ptr %l1, !tbaa !29
  %t62 = load i64, ptr %l2, !tbaa !24
  %t66 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2elendsKeep(ptr %v0, ptr %v1, ptr %t60, ptr %t61, i64 %t62)
  store i1 %t66, ptr %l43
  br label %bb20
bb20:
  %t67 = load i1, ptr %l43, !tbaa !21
  %t68 = xor i1 %t67, true
  store i1 %t68, ptr %l39, !tbaa !21
  br label %bb21
bb21:
  %t70 = load i1, ptr %l39, !tbaa !21
  br i1 %t70, label %bb22, label %bb23
bb22:
  store i1 false, ptr %rv
  br label %ret
bb23:
  br label %bb24
bb24:
  store i64 0, ptr %l4, !tbaa !24
  %t72 = load ptr, ptr %l1, !tbaa !29
  %t74 = getelementptr %"compiler/typed:LocalUses", ptr %t72, i32 0, i32 10
  %t76 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t74)
  store i64 %t76, ptr %l48
  br label %bb25
bb25:
  %t77 = load i64, ptr %l48, !tbaa !24
  store i64 %t77, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t78 = load i64, ptr %l5, !tbaa !24
  %t79 = load i64, ptr %l4, !tbaa !24
  %t82 = icmp sgt i64 %t78, %t79
  br i1 %t82, label %bb26, label %bb27
bb26:
  %t84 = load i64, ptr %l6, !tbaa !24
  %t86 = icmp sgt i64 %t84, 0
  br i1 %t86, label %bb28, label %bb29
bb27:
  store i64 0, ptr %l52, !tbaa !24
  br label %bb31
bb28:
  %t88 = load i64, ptr %l5, !tbaa !24
  %t89 = load i64, ptr %l4, !tbaa !24
  %t92 = sub i64 %t88, %t89
  %t93 = load i64, ptr %l6, !tbaa !24
  %t96 = add i64 %t92, %t93
  %t98 = sub i64 %t96, 1
  %t99 = load i64, ptr %l6, !tbaa !24
  %t102 = sdiv i64 %t98, %t99
  store i64 %t102, ptr %l55, !tbaa !24
  br label %bb30
bb29:
  store i64 0, ptr %l55, !tbaa !24
  br label %bb30
bb30:
  %t104 = load i64, ptr %l55, !tbaa !24
  store i64 %t104, ptr %l52, !tbaa !24
  br label %bb31
bb31:
  %t105 = load i64, ptr %l52, !tbaa !24
  store i64 %t105, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb32
bb32:
  %t106 = load i64, ptr %l8, !tbaa !24
  %t107 = load i64, ptr %l7, !tbaa !24
  %t110 = icmp slt i64 %t106, %t107
  %t112 = xor i1 %t110, true
  br i1 %t112, label %bb33, label %bb34
bb33:
  br label %bb41
bb34:
  br label %bb35
bb35:
  %t114 = load i64, ptr %l4, !tbaa !24
  %t115 = load i64, ptr %l8, !tbaa !24
  %t116 = load i64, ptr %l6, !tbaa !24
  %t119 = mul i64 %t115, %t116
  %t122 = add i64 %t114, %t119
  %t124 = load ptr, ptr %l1, !tbaa !29
  %t126 = getelementptr %"compiler/typed:LocalUses", ptr %t124, i32 0, i32 10
  %t130 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t126, i64 %t122)
  store i64 %t130, ptr %l76
  br label %bb36
bb36:
  %t131 = load i64, ptr %l2, !tbaa !24
  %t132 = load i64, ptr %l76, !tbaa !24
  %t134 = icmp eq i64 %t132, %t131
  br i1 %t134, label %bb37, label %bb38
bb37:
  store i1 false, ptr %rv
  br label %ret
bb38:
  br label %bb39
bb39:
  br label %bb40
bb40:
  %t137 = load i64, ptr %l8, !tbaa !24
  %t139 = add i64 %t137, 1
  store i64 %t139, ptr %l8, !tbaa !24
  br label %bb32
bb41:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { { i64, [7 x i64] }, i32 } @compiler_2flower_2ecompiler_2flower_3alowering_2ehelperCallee(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca i32
  %l7 = alloca i32
  %l14 = alloca i32
  %l19 = alloca i32
  %rv = alloca { { i64, [7 x i64] }, i32 }
  %t37 = alloca { i64, [2 x i64] }, align 8
  %t49 = alloca { i64, [2 x i64] }, align 8
  %t58 = alloca { i64, [7 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t3 = trunc i64 0 to i32
  %t4 = icmp eq i32 %a1, %t3
  br i1 %t4, label %bb1, label %bb2
bb1:
  store i32 1, ptr %l7
  br label %bb3
bb2:
  store i32 2, ptr %l7
  br label %bb3
bb3:
  %t8 = load i32, ptr %l7, !range !{i32 0, i32 8}
  store i32 %t8, ptr %l3
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/lower:lowering", ptr %t9, i32 0, i32 0
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t13 = load i32, ptr %l3, !range !{i32 0, i32 8}
  %t14 = load i32, ptr %l2, !tbaa !23
  %t18 = call i32 @compiler_2flower_2ecompiler_2flower_3aLowerer_2ehelperTy(ptr %v0, ptr %t12, i32 %t13, i32 %t14)
  store i32 %t18, ptr %l14
  br label %bb4
bb4:
  %t19 = load i32, ptr %l14, !tbaa !23
  store i32 %t19, ptr %l2, !tbaa !23
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/lower:lowering", ptr %t20, i32 0, i32 2
  %t23 = load ptr, ptr %t22, !tbaa !29
  %t24 = load i32, ptr %l3, !range !{i32 0, i32 8}
  %t25 = load i32, ptr %l2, !tbaa !23
  %t29 = call i32 @compiler_2fmir_2eHelperType(ptr %v0, ptr %t23, i32 %t24, i32 %t25)
  store i32 %t29, ptr %l19
  br label %bb5
bb5:
  %t30 = load i32, ptr %l19, !tbaa !23
  store i32 %t30, ptr %l4, !tbaa !23
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/lower:lowering", ptr %t31, i32 0, i32 0
  %t34 = load ptr, ptr %t33, !tbaa !29
  %t35 = load i32, ptr %l3, !range !{i32 0, i32 8}
  %t36 = load i32, ptr %l2, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t37
  %t38 = getelementptr { i64, [2 x i64] }, ptr %t37, i32 0, i32 0
  store i64 3, ptr %t38
  %t40 = insertvalue { i32, i32 } undef, i32 %t35, 0
  %t42 = insertvalue { i32, i32 } %t40, i32 %t36, 1
  %t43 = getelementptr { i64, [2 x i64] }, ptr %t37, i32 0, i32 1
  store { i32, i32 } %t42, ptr %t43
  %t44 = load { i64, [2 x i64] }, ptr %t37
  call void @compiler_2flower_2ecompiler_2flower_3aLowerer_2eWant(ptr %v0, ptr %t34, { i64, [2 x i64] } %t44)
  br label %bb6
bb6:
  %t47 = load i32, ptr %l3, !range !{i32 0, i32 8}
  %t48 = load i32, ptr %l2, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t49
  %t50 = getelementptr { i64, [2 x i64] }, ptr %t49, i32 0, i32 0
  store i64 3, ptr %t50
  %t52 = insertvalue { i32, i32 } undef, i32 %t47, 0
  %t54 = insertvalue { i32, i32 } %t52, i32 %t48, 1
  %t55 = getelementptr { i64, [2 x i64] }, ptr %t49, i32 0, i32 1
  store { i32, i32 } %t54, ptr %t55
  %t56 = load { i64, [2 x i64] }, ptr %t49
  %t57 = load i32, ptr %l4, !tbaa !23
  store { i64, [7 x i64] } zeroinitializer, ptr %t58
  %t59 = getelementptr { i64, [7 x i64] }, ptr %t58, i32 0, i32 0
  store i64 0, ptr %t59
  %t61 = insertvalue { { i64, [2 x i64] }, i32 } undef, { i64, [2 x i64] } %t56, 0
  %t63 = insertvalue { { i64, [2 x i64] }, i32 } %t61, i32 %t57, 1
  %t64 = getelementptr { i64, [7 x i64] }, ptr %t58, i32 0, i32 1
  store { { i64, [2 x i64] }, i32 } %t63, ptr %t64
  %t65 = load { i64, [7 x i64] }, ptr %t58
  %t66 = load i32, ptr %l4, !tbaa !23
  %t68 = insertvalue { { i64, [7 x i64] }, i32 } undef, { i64, [7 x i64] } %t65, 0
  %t70 = insertvalue { { i64, [7 x i64] }, i32 } %t68, i32 %t66, 1
  store { { i64, [7 x i64] }, i32 } %t70, ptr %rv
  br label %ret
ret:
  %rr = load { { i64, [7 x i64] }, i32 }, ptr %rv
  ret { { i64, [7 x i64] }, i32 } %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2einner(ptr %v0, ptr %v1, ptr %a0, %"compiler/lower:pl" %a1, i32 %a2, { i64, [1 x i64] } %a3, %"compiler/source:Span" %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/lower:pl"
  %l2 = alloca i32
  %l3 = alloca { i64, [1 x i64] }
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca { i64, [4 x i64] }
  %l8 = alloca i32
  %l9 = alloca ptr
  %l10 = alloca %"compiler/lower:pl"
  %l12 = alloca %"compiler/lower:pl"
  %l15 = alloca %"compiler/lower:pl"
  %l17 = alloca %"compiler/lower:pl"
  %l22 = alloca i32
  %l25 = alloca i1
  %l26 = alloca ptr
  %l27 = alloca %"compiler/source:Span"
  %l28 = alloca { i64, [1 x i64] }
  %l29 = alloca i32
  %l30 = alloca ptr
  %l31 = alloca i32
  %l32 = alloca ptr
  %l33 = alloca %"compiler/lower:pl"
  %l35 = alloca %"compiler/lower:pl"
  %l36 = alloca %"compiler/mir:Lvalue"
  %l40 = alloca { i64, [4 x i64] }
  %l41 = alloca { i64, [21 x i64] }
  %l45 = alloca i1
  %l46 = alloca i1
  %l49 = alloca i1
  %l51 = alloca ptr
  %l52 = alloca i32
  %l53 = alloca ptr
  %l54 = alloca %"compiler/lower:pl"
  %l56 = alloca %"compiler/lower:pl"
  %l57 = alloca %"compiler/mir:Lvalue"
  %l61 = alloca { i64, [4 x i64] }
  %l64 = alloca i1
  %l65 = alloca i1
  %l68 = alloca i1
  %l80 = alloca { i64, [21 x i64] }
  %l84 = alloca i32
  %l87 = alloca ptr
  %l88 = alloca { i64, [1 x i64] }
  %l89 = alloca ptr
  %l90 = alloca %"compiler/lower:pl"
  %l92 = alloca %"compiler/lower:pl"
  %l93 = alloca %"compiler/mir:Lvalue"
  %l99 = alloca i1
  %l103 = alloca i1
  %l107 = alloca i1
  %l111 = alloca i1
  %l113 = alloca ptr
  %l114 = alloca %"compiler/source:Span"
  %l115 = alloca { i64, [1 x i64] }
  %l116 = alloca i32
  %l117 = alloca ptr
  %l118 = alloca i32
  %l119 = alloca ptr
  %l120 = alloca %"compiler/lower:pl"
  %l122 = alloca %"compiler/lower:pl"
  %l123 = alloca %"compiler/mir:Lvalue"
  %l127 = alloca { i64, [4 x i64] }
  %l128 = alloca { i64, [21 x i64] }
  %l130 = alloca ptr
  %l131 = alloca %"compiler/lower:pl"
  %l133 = alloca %"compiler/lower:pl"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %t44 = alloca { i64, [4 x i64] }, align 8
  %t50 = alloca { i64, [15 x i64] }, align 8
  %t62 = alloca { i64, [21 x i64] }, align 8
  %t100 = alloca { i64, [4 x i64] }, align 8
  %t106 = alloca { i64, [15 x i64] }, align 8
  %t147 = alloca { i64, [21 x i64] }, align 8
  %t180 = alloca { i64, [4 x i64] }, align 8
  %t234 = alloca { i64, [4 x i64] }, align 8
  %t240 = alloca { i64, [15 x i64] }, align 8
  %t252 = alloca { i64, [21 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/lower:pl" %a1, ptr %l1
  store i32 %a2, ptr %l2
  store { i64, [1 x i64] } %a3, ptr %l3
  store %"compiler/source:Span" %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l9, !tbaa !29
  %t2 = load %"compiler/lower:pl", ptr %l1
  store %"compiler/lower:pl" %t2, ptr %l10
  %t4 = call %"compiler/lower:pl" @olang_2eHelperKind_2eCopy_2ecompiler_2flower_3apl(ptr %v1, ptr %l10)
  store %"compiler/lower:pl" %t4, ptr %l12
  br label %bb1
bb1:
  %t5 = load i32, ptr %l2, !tbaa !23
  %t6 = load %"compiler/source:Span", ptr %l4
  %t7 = load ptr, ptr %l9, !tbaa !29
  %t8 = load %"compiler/lower:pl", ptr %l12
  %t11 = call %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2esolid(ptr %v0, ptr %v1, ptr %v1, ptr %t7, %"compiler/lower:pl" %t8, i32 %t5, %"compiler/source:Span" %t6)
  store %"compiler/lower:pl" %t11, ptr %l15
  br label %bb2
bb2:
  %t13 = call %"compiler/lower:pl" @olang_2eHelperKind_2eCopy_2ecompiler_2flower_3apl(ptr %v1, ptr %l15)
  store %"compiler/lower:pl" %t13, ptr %l17
  br label %bb3
bb3:
  %t14 = load %"compiler/lower:pl", ptr %l17
  store %"compiler/lower:pl" %t14, ptr %l1
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/lower:lowering", ptr %t15, i32 0, i32 2
  %t18 = load ptr, ptr %t17, !tbaa !29
  store ptr %t18, ptr %l5, !tbaa !29
  %t20 = load ptr, ptr %l5, !tbaa !29
  %t21 = load i32, ptr %l2, !tbaa !23
  %t24 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t20, i32 %t21)
  store i32 %t24, ptr %l22
  br label %bb4
bb4:
  %t25 = load i32, ptr %l22, !tbaa !23
  store i32 %t25, ptr %l6, !tbaa !23
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t27 = load i32, ptr %l2, !tbaa !23
  %t30 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eisChar(ptr %v0, ptr %t26, i32 %t27)
  store i1 %t30, ptr %l25
  br label %bb5
bb5:
  %t31 = load i1, ptr %l25, !tbaa !21
  br i1 %t31, label %bb6, label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s1
  %t32 = load ptr, ptr %l0, !tbaa !29
  store ptr %t32, ptr %l26, !tbaa !29
  %t33 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t33, ptr %l27
  %t34 = load { i64, [1 x i64] }, ptr %l3
  store { i64, [1 x i64] } %t34, ptr %l28
  store i32 3, ptr %l29
  %t35 = load ptr, ptr %l0, !tbaa !29
  store ptr %t35, ptr %l30, !tbaa !29
  %t36 = load i32, ptr %l2, !tbaa !23
  store i32 %t36, ptr %l31, !tbaa !23
  %t37 = load ptr, ptr %l0, !tbaa !29
  store ptr %t37, ptr %l32, !tbaa !29
  %t38 = load %"compiler/lower:pl", ptr %l1
  store %"compiler/lower:pl" %t38, ptr %l33
  %t40 = call %"compiler/lower:pl" @olang_2eHelperKind_2eCopy_2ecompiler_2flower_3apl(ptr %s1, ptr %l33)
  store %"compiler/lower:pl" %t40, ptr %l35
  br label %bb8
bb7:
  br label %bb12
bb8:
  %t41 = load ptr, ptr %l32, !tbaa !29
  %t42 = load %"compiler/lower:pl", ptr %l35
  %t43 = call %"compiler/mir:Lvalue" @compiler_2flower_2ecompiler_2flower_3alowering_2emk(ptr %v0, ptr %s1, ptr %t41, %"compiler/lower:pl" %t42)
  store %"compiler/mir:Lvalue" %t43, ptr %l36
  br label %bb9
bb9:
  store { i64, [4 x i64] } zeroinitializer, ptr %t44
  %t45 = getelementptr { i64, [4 x i64] }, ptr %t44, i32 0, i32 0
  store i64 1, ptr %t45
  %t46 = load %"compiler/mir:Lvalue", ptr %l36
  %t47 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t46, 0
  %t48 = getelementptr { i64, [4 x i64] }, ptr %t44, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t47, ptr %t48
  %t49 = load { i64, [4 x i64] }, ptr %t44
  store { i64, [15 x i64] } zeroinitializer, ptr %t50
  %t51 = getelementptr { i64, [15 x i64] }, ptr %t50, i32 0, i32 0
  store i64 0, ptr %t51
  %t53 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t49, 0
  %t54 = getelementptr { i64, [15 x i64] }, ptr %t50, i32 0, i32 1
  store { { i64, [4 x i64] } } %t53, ptr %t54
  %t55 = load { i64, [15 x i64] }, ptr %t50
  %t56 = load %"compiler/source:Span", ptr %l4
  %t57 = load ptr, ptr %l30, !tbaa !29
  %t58 = load i32, ptr %l31, !tbaa !23
  %t61 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %t57, i32 %t58, { i64, [15 x i64] } %t55, %"compiler/source:Span" %t56)
  store { i64, [4 x i64] } %t61, ptr %l40
  br label %bb10
bb10:
  store { i64, [21 x i64] } zeroinitializer, ptr %t62
  %t63 = getelementptr { i64, [21 x i64] }, ptr %t62, i32 0, i32 0
  store i64 8, ptr %t63
  %t64 = load %"compiler/source:Span", ptr %l27
  %t65 = insertvalue { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } undef, %"compiler/source:Span" %t64, 0
  %t66 = load { i64, [1 x i64] }, ptr %l28
  %t67 = insertvalue { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } %t65, { i64, [1 x i64] } %t66, 1
  %t68 = load i32, ptr %l29, !range !{i32 0, i32 8}
  %t69 = insertvalue { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } %t67, i32 %t68, 2
  %t70 = load { i64, [4 x i64] }, ptr %l40
  %t71 = insertvalue { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } %t69, { i64, [4 x i64] } %t70, 3
  %t72 = getelementptr { i64, [21 x i64] }, ptr %t62, i32 0, i32 1
  store { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } %t71, ptr %t72
  %t73 = load { i64, [21 x i64] }, ptr %t62
  store { i64, [21 x i64] } %t73, ptr %l41
  %t74 = load ptr, ptr %l26, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s1, ptr %t74, ptr %l41)
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb12:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t77 = load i32, ptr %l2, !tbaa !23
  %t80 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eisText(ptr %v0, ptr %t76, i32 %t77)
  store i1 %t80, ptr %l45
  br label %bb13
bb13:
  %t81 = load i1, ptr %l45, !tbaa !21
  br i1 %t81, label %bb14, label %bb15
bb14:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t83 = load i32, ptr %l2, !tbaa !23
  %t86 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2ehasStr(ptr %v0, ptr %t82, i32 %t83)
  store i1 %t86, ptr %l49
  br label %bb16
bb15:
  store i1 false, ptr %l46, !tbaa !21
  br label %bb17
bb16:
  %t87 = load i1, ptr %l49, !tbaa !21
  %t88 = xor i1 %t87, true
  store i1 %t88, ptr %l46, !tbaa !21
  br label %bb17
bb17:
  %t90 = load i1, ptr %l46, !tbaa !21
  br i1 %t90, label %bb18, label %bb19
bb18:
  store %olang.scope zeroinitializer, ptr %s2
  %t91 = load ptr, ptr %l0, !tbaa !29
  store ptr %t91, ptr %l51, !tbaa !29
  %t92 = load i32, ptr %l2, !tbaa !23
  store i32 %t92, ptr %l52, !tbaa !23
  %t93 = load ptr, ptr %l0, !tbaa !29
  store ptr %t93, ptr %l53, !tbaa !29
  %t94 = load %"compiler/lower:pl", ptr %l1
  store %"compiler/lower:pl" %t94, ptr %l54
  %t96 = call %"compiler/lower:pl" @olang_2eHelperKind_2eCopy_2ecompiler_2flower_3apl(ptr %s2, ptr %l54)
  store %"compiler/lower:pl" %t96, ptr %l56
  br label %bb20
bb19:
  br label %bb33
bb20:
  %t97 = load ptr, ptr %l53, !tbaa !29
  %t98 = load %"compiler/lower:pl", ptr %l56
  %t99 = call %"compiler/mir:Lvalue" @compiler_2flower_2ecompiler_2flower_3alowering_2emk(ptr %v0, ptr %s2, ptr %t97, %"compiler/lower:pl" %t98)
  store %"compiler/mir:Lvalue" %t99, ptr %l57
  br label %bb21
bb21:
  store { i64, [4 x i64] } zeroinitializer, ptr %t100
  %t101 = getelementptr { i64, [4 x i64] }, ptr %t100, i32 0, i32 0
  store i64 1, ptr %t101
  %t102 = load %"compiler/mir:Lvalue", ptr %l57
  %t103 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t102, 0
  %t104 = getelementptr { i64, [4 x i64] }, ptr %t100, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t103, ptr %t104
  %t105 = load { i64, [4 x i64] }, ptr %t100
  store { i64, [15 x i64] } zeroinitializer, ptr %t106
  %t107 = getelementptr { i64, [15 x i64] }, ptr %t106, i32 0, i32 0
  store i64 0, ptr %t107
  %t109 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t105, 0
  %t110 = getelementptr { i64, [15 x i64] }, ptr %t106, i32 0, i32 1
  store { { i64, [4 x i64] } } %t109, ptr %t110
  %t111 = load { i64, [15 x i64] }, ptr %t106
  %t112 = load %"compiler/source:Span", ptr %l4
  %t113 = load ptr, ptr %l51, !tbaa !29
  %t114 = load i32, ptr %l52, !tbaa !23
  %t117 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %t113, i32 %t114, { i64, [15 x i64] } %t111, %"compiler/source:Span" %t112)
  store { i64, [4 x i64] } %t117, ptr %l61
  br label %bb22
bb22:
  %t118 = load { i64, [4 x i64] }, ptr %l61
  store { i64, [4 x i64] } %t118, ptr %l7
  %t119 = load ptr, ptr %l5, !tbaa !29
  %t120 = load i32, ptr %l6, !tbaa !23
  %t123 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNullable(ptr %v0, ptr %t119, i32 %t120)
  store i1 %t123, ptr %l64
  br label %bb23
bb23:
  %t124 = load i1, ptr %l64, !tbaa !21
  br i1 %t124, label %bb24, label %bb25
bb24:
  %t125 = load ptr, ptr %l5, !tbaa !29
  %t126 = load i32, ptr %l6, !tbaa !23
  %t129 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArrayRef(ptr %v0, ptr %t125, i32 %t126)
  store i1 %t129, ptr %l68
  br label %bb26
bb25:
  store i1 false, ptr %l65, !tbaa !21
  br label %bb27
bb26:
  %t130 = load i1, ptr %l68, !tbaa !21
  store i1 %t130, ptr %l65, !tbaa !21
  br label %bb27
bb27:
  %t131 = load i1, ptr %l65, !tbaa !21
  br i1 %t131, label %bb28, label %bb29
bb28:
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t133 = load { i64, [1 x i64] }, ptr %l3
  %t134 = load { i64, [4 x i64] }, ptr %l7
  %t135 = load i32, ptr %l2, !tbaa !23
  %t136 = load %"compiler/source:Span", ptr %l4
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2erenderMaybeText(ptr %v0, ptr %t132, { i64, [1 x i64] } %t133, { i64, [4 x i64] } %t134, i32 %t135, %"compiler/source:Span" %t136, i32 1)
  br label %bb30
bb29:
  store %olang.scope zeroinitializer, ptr %s4
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t144 = load %"compiler/source:Span", ptr %l4
  %t145 = load { i64, [1 x i64] }, ptr %l3
  %t146 = load { i64, [4 x i64] }, ptr %l7
  store { i64, [21 x i64] } zeroinitializer, ptr %t147
  %t148 = getelementptr { i64, [21 x i64] }, ptr %t147, i32 0, i32 0
  store i64 8, ptr %t148
  %t150 = insertvalue { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } undef, %"compiler/source:Span" %t144, 0
  %t152 = insertvalue { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } %t150, { i64, [1 x i64] } %t145, 1
  %t154 = insertvalue { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } %t152, i32 1, 2
  %t156 = insertvalue { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } %t154, { i64, [4 x i64] } %t146, 3
  %t157 = getelementptr { i64, [21 x i64] }, ptr %t147, i32 0, i32 1
  store { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } %t156, ptr %t157
  %t158 = load { i64, [21 x i64] }, ptr %t147
  store { i64, [21 x i64] } %t158, ptr %l80
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s4, ptr %t143, ptr %l80)
  br label %bb31
bb30:
  br label %bb32
bb31:
  call void @__olang_scope_close(ptr %s4)
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb33:
  %t161 = load ptr, ptr %l5, !tbaa !29
  %t162 = load i32, ptr %l2, !tbaa !23
  %t165 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t161, i32 %t162)
  store i32 %t165, ptr %l84
  br label %bb34
bb34:
  %t166 = load i32, ptr %l84, !range !{i32 0, i32 33}
  %t168 = trunc i64 32 to i32
  %t169 = icmp eq i32 %t166, %t168
  br i1 %t169, label %bb35, label %bb36
bb35:
  store %olang.scope zeroinitializer, ptr %s5
  %t171 = load ptr, ptr %l0, !tbaa !29
  store ptr %t171, ptr %l87, !tbaa !29
  %t172 = load { i64, [1 x i64] }, ptr %l3
  store { i64, [1 x i64] } %t172, ptr %l88
  %t173 = load ptr, ptr %l0, !tbaa !29
  store ptr %t173, ptr %l89, !tbaa !29
  %t174 = load %"compiler/lower:pl", ptr %l1
  store %"compiler/lower:pl" %t174, ptr %l90
  %t176 = call %"compiler/lower:pl" @olang_2eHelperKind_2eCopy_2ecompiler_2flower_3apl(ptr %s5, ptr %l90)
  store %"compiler/lower:pl" %t176, ptr %l92
  br label %bb37
bb36:
  br label %bb40
bb37:
  %t177 = load ptr, ptr %l89, !tbaa !29
  %t178 = load %"compiler/lower:pl", ptr %l92
  %t179 = call %"compiler/mir:Lvalue" @compiler_2flower_2ecompiler_2flower_3alowering_2emk(ptr %v0, ptr %s5, ptr %t177, %"compiler/lower:pl" %t178)
  store %"compiler/mir:Lvalue" %t179, ptr %l93
  br label %bb38
bb38:
  store { i64, [4 x i64] } zeroinitializer, ptr %t180
  %t181 = getelementptr { i64, [4 x i64] }, ptr %t180, i32 0, i32 0
  store i64 1, ptr %t181
  %t182 = load %"compiler/mir:Lvalue", ptr %l93
  %t183 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t182, 0
  %t184 = getelementptr { i64, [4 x i64] }, ptr %t180, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t183, ptr %t184
  %t185 = load { i64, [4 x i64] }, ptr %t180
  %t186 = load i32, ptr %l2, !tbaa !23
  %t187 = load %"compiler/source:Span", ptr %l4
  %t188 = load ptr, ptr %l87, !tbaa !29
  %t189 = load { i64, [1 x i64] }, ptr %l88
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2erenderErr(ptr %v0, ptr %t188, { i64, [1 x i64] } %t189, { i64, [4 x i64] } %t185, i32 %t186, %"compiler/source:Span" %t187)
  br label %bb39
bb39:
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb40:
  %t193 = load ptr, ptr %l0, !tbaa !29
  %t194 = load i32, ptr %l2, !tbaa !23
  %t197 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2escalar(ptr %v0, ptr %t193, i32 %t194)
  store i1 %t197, ptr %l99
  br label %bb41
bb41:
  %t198 = load i1, ptr %l99, !tbaa !21
  br i1 %t198, label %bb42, label %bb43
bb42:
  store %olang.scope zeroinitializer, ptr %s6
  store i32 7, ptr %l8
  %t200 = load ptr, ptr %l5, !tbaa !29
  %t201 = load i32, ptr %l6, !tbaa !23
  %t204 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %t200, i32 %t201)
  store i1 %t204, ptr %l103
  br label %bb44
bb43:
  br label %bb60
bb44:
  %t205 = load i1, ptr %l103, !tbaa !21
  br i1 %t205, label %bb45, label %bb46
bb45:
  store i32 5, ptr %l8
  br label %bb55
bb46:
  %t207 = load ptr, ptr %l5, !tbaa !29
  %t208 = load i32, ptr %l6, !tbaa !23
  %t211 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %t207, i32 %t208)
  store i1 %t211, ptr %l107
  br label %bb47
bb47:
  %t212 = load i1, ptr %l107, !tbaa !21
  br i1 %t212, label %bb48, label %bb49
bb48:
  store i32 4, ptr %l8
  br label %bb54
bb49:
  %t214 = load ptr, ptr %l5, !tbaa !29
  %t215 = load i32, ptr %l6, !tbaa !23
  %t218 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %t214, i32 %t215)
  store i1 %t218, ptr %l111
  br label %bb50
bb50:
  %t219 = load i1, ptr %l111, !tbaa !21
  br i1 %t219, label %bb51, label %bb52
bb51:
  store i32 6, ptr %l8
  br label %bb53
bb52:
  br label %bb53
bb53:
  br label %bb54
bb54:
  br label %bb55
bb55:
  %t221 = load ptr, ptr %l0, !tbaa !29
  store ptr %t221, ptr %l113, !tbaa !29
  %t222 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t222, ptr %l114
  %t223 = load { i64, [1 x i64] }, ptr %l3
  store { i64, [1 x i64] } %t223, ptr %l115
  %t224 = load i32, ptr %l8, !range !{i32 0, i32 8}
  store i32 %t224, ptr %l116
  %t225 = load ptr, ptr %l0, !tbaa !29
  store ptr %t225, ptr %l117, !tbaa !29
  %t226 = load i32, ptr %l2, !tbaa !23
  store i32 %t226, ptr %l118, !tbaa !23
  %t227 = load ptr, ptr %l0, !tbaa !29
  store ptr %t227, ptr %l119, !tbaa !29
  %t228 = load %"compiler/lower:pl", ptr %l1
  store %"compiler/lower:pl" %t228, ptr %l120
  %t230 = call %"compiler/lower:pl" @olang_2eHelperKind_2eCopy_2ecompiler_2flower_3apl(ptr %s6, ptr %l120)
  store %"compiler/lower:pl" %t230, ptr %l122
  br label %bb56
bb56:
  %t231 = load ptr, ptr %l119, !tbaa !29
  %t232 = load %"compiler/lower:pl", ptr %l122
  %t233 = call %"compiler/mir:Lvalue" @compiler_2flower_2ecompiler_2flower_3alowering_2emk(ptr %v0, ptr %s6, ptr %t231, %"compiler/lower:pl" %t232)
  store %"compiler/mir:Lvalue" %t233, ptr %l123
  br label %bb57
bb57:
  store { i64, [4 x i64] } zeroinitializer, ptr %t234
  %t235 = getelementptr { i64, [4 x i64] }, ptr %t234, i32 0, i32 0
  store i64 1, ptr %t235
  %t236 = load %"compiler/mir:Lvalue", ptr %l123
  %t237 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t236, 0
  %t238 = getelementptr { i64, [4 x i64] }, ptr %t234, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t237, ptr %t238
  %t239 = load { i64, [4 x i64] }, ptr %t234
  store { i64, [15 x i64] } zeroinitializer, ptr %t240
  %t241 = getelementptr { i64, [15 x i64] }, ptr %t240, i32 0, i32 0
  store i64 0, ptr %t241
  %t243 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t239, 0
  %t244 = getelementptr { i64, [15 x i64] }, ptr %t240, i32 0, i32 1
  store { { i64, [4 x i64] } } %t243, ptr %t244
  %t245 = load { i64, [15 x i64] }, ptr %t240
  %t246 = load %"compiler/source:Span", ptr %l4
  %t247 = load ptr, ptr %l117, !tbaa !29
  %t248 = load i32, ptr %l118, !tbaa !23
  %t251 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %t247, i32 %t248, { i64, [15 x i64] } %t245, %"compiler/source:Span" %t246)
  store { i64, [4 x i64] } %t251, ptr %l127
  br label %bb58
bb58:
  store { i64, [21 x i64] } zeroinitializer, ptr %t252
  %t253 = getelementptr { i64, [21 x i64] }, ptr %t252, i32 0, i32 0
  store i64 8, ptr %t253
  %t254 = load %"compiler/source:Span", ptr %l114
  %t255 = insertvalue { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } undef, %"compiler/source:Span" %t254, 0
  %t256 = load { i64, [1 x i64] }, ptr %l115
  %t257 = insertvalue { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } %t255, { i64, [1 x i64] } %t256, 1
  %t258 = load i32, ptr %l116, !range !{i32 0, i32 8}
  %t259 = insertvalue { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } %t257, i32 %t258, 2
  %t260 = load { i64, [4 x i64] }, ptr %l127
  %t261 = insertvalue { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } %t259, { i64, [4 x i64] } %t260, 3
  %t262 = getelementptr { i64, [21 x i64] }, ptr %t252, i32 0, i32 1
  store { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } %t261, ptr %t262
  %t263 = load { i64, [21 x i64] }, ptr %t252
  store { i64, [21 x i64] } %t263, ptr %l128
  %t264 = load ptr, ptr %l113, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s6, ptr %t264, ptr %l128)
  br label %bb59
bb59:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb60:
  %t266 = load ptr, ptr %l0, !tbaa !29
  store ptr %t266, ptr %l130, !tbaa !29
  %t267 = load %"compiler/lower:pl", ptr %l1
  store %"compiler/lower:pl" %t267, ptr %l131
  %t269 = call %"compiler/lower:pl" @olang_2eHelperKind_2eCopy_2ecompiler_2flower_3apl(ptr %s0, ptr %l131)
  store %"compiler/lower:pl" %t269, ptr %l133
  br label %bb61
bb61:
  %t270 = load i32, ptr %l2, !tbaa !23
  %t271 = load { i64, [1 x i64] }, ptr %l3
  %t272 = load %"compiler/source:Span", ptr %l4
  %t273 = load ptr, ptr %l130, !tbaa !29
  %t274 = load %"compiler/lower:pl", ptr %l133
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2erenderAt(ptr %v0, ptr %s0, ptr %t273, %"compiler/lower:pl" %t274, i32 %t270, { i64, [1 x i64] } %t271, %"compiler/source:Span" %t272, i1 false)
  br label %bb62
bb62:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %a0, i32 %a1, { i64, [15 x i64] } %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca i32
  %l8 = alloca i32
  %l9 = alloca ptr
  %l10 = alloca %"compiler/source:Span"
  %l12 = alloca %"compiler/mir:Lvalue"
  %l14 = alloca { i64, [21 x i64] }
  %l17 = alloca %"compiler/mir:Lvalue"
  %s0 = alloca %olang.scope
  %rv = alloca { i64, [4 x i64] }
  %t15 = alloca { i64, [21 x i64] }, align 8
  %t30 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = load %"compiler/source:Span", ptr %l3
  %t7 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2etemp(ptr %v0, ptr %t1, i32 %a1, %"compiler/source:Span" %t3)
  store i32 %t7, ptr %l8
  br label %bb1
bb1:
  %t8 = load i32, ptr %l8, !tbaa !23
  store i32 %t8, ptr %l4, !tbaa !23
  %t9 = load ptr, ptr %l0, !tbaa !29
  store ptr %t9, ptr %l9, !tbaa !29
  %t10 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t10, ptr %l10
  %t11 = load i32, ptr %l4, !tbaa !23
  %t13 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t11)
  store %"compiler/mir:Lvalue" %t13, ptr %l12
  br label %bb2
bb2:
  store { i64, [21 x i64] } zeroinitializer, ptr %t15
  %t16 = getelementptr { i64, [21 x i64] }, ptr %t15, i32 0, i32 0
  store i64 0, ptr %t16
  %t17 = load %"compiler/source:Span", ptr %l10
  %t18 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t17, 0
  %t19 = load %"compiler/mir:Lvalue", ptr %l12
  %t20 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t18, %"compiler/mir:Lvalue" %t19, 1
  %t22 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t20, { i64, [15 x i64] } %a2, 2
  %t23 = getelementptr { i64, [21 x i64] }, ptr %t15, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t22, ptr %t23
  %t24 = load { i64, [21 x i64] }, ptr %t15
  store { i64, [21 x i64] } %t24, ptr %l14
  %t25 = load ptr, ptr %l9, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s0, ptr %t25, ptr %l14)
  br label %bb3
bb3:
  %t27 = load i32, ptr %l4, !tbaa !23
  %t29 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t27)
  store %"compiler/mir:Lvalue" %t29, ptr %l17
  br label %bb4
bb4:
  store { i64, [4 x i64] } zeroinitializer, ptr %t30
  %t31 = getelementptr { i64, [4 x i64] }, ptr %t30, i32 0, i32 0
  store i64 1, ptr %t31
  %t32 = load %"compiler/mir:Lvalue", ptr %l17
  %t33 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t32, 0
  %t34 = getelementptr { i64, [4 x i64] }, ptr %t30, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t33, ptr %t34
  %t35 = load { i64, [4 x i64] }, ptr %t30
  call void @__olang_scope_close(ptr %s0)
  store { i64, [4 x i64] } %t35, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local { i64, ptr } @compiler_2flower_2ecompiler_2flower_3alowering_2eitems(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %lp3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l13 = alloca { i64, ptr }
  %l15 = alloca i64
  %l24 = alloca i64
  %l27 = alloca i64
  %l46 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/lower:lowering", ptr %a0, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t8 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t4, i32 %a1)
  store { i64, ptr } %t8, ptr %l13
  br label %bb1
bb1:
  %t9 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t9, ptr %l2, !tbaa !27
  %t10 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l15, !tbaa !24
  %t13 = load i64, ptr %l15, !tbaa !24
  %t14 = icmp sge i64 %t13, 0
  br i1 %t14, label %bb2, label %bb3
bb2:
  %t16 = load i64, ptr %l15, !tbaa !24
  %t17 = icmp sle i64 %t16, 2305843009213693951
  br i1 %t17, label %bb4, label %bb5
bb3:
  call void @__olang_check_failed(ptr @olang_loc_fe6f132f471090d8_e27fa787bcbe9484)
  unreachable
bb4:
  %t19 = load i64, ptr %l15, !tbaa !24
  %t20 = mul i64 %t19, 4
  %t21 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t20)
  %t22 = insertvalue { i64, ptr } undef, i64 %t19, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t21, 1
  %t24 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t24, ptr %lp3
  %t26 = load ptr, ptr %lp3
  store { i64, ptr } %t23, ptr %t26, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t27 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t27, 0
  store i64 %t29, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t31 = load i64, ptr %l5, !tbaa !24
  %t32 = load i64, ptr %l4, !tbaa !24
  %t35 = icmp sgt i64 %t31, %t32
  br i1 %t35, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_fe6f132f471090d8_e27fa787bcbe9484)
  unreachable
bb6:
  %t37 = load i64, ptr %l6, !tbaa !24
  %t39 = icmp sgt i64 %t37, 0
  br i1 %t39, label %bb8, label %bb9
bb7:
  store i64 0, ptr %l24, !tbaa !24
  br label %bb11
bb8:
  %t41 = load i64, ptr %l5, !tbaa !24
  %t42 = load i64, ptr %l4, !tbaa !24
  %t45 = sub i64 %t41, %t42
  %t46 = load i64, ptr %l6, !tbaa !24
  %t49 = add i64 %t45, %t46
  %t51 = sub i64 %t49, 1
  %t52 = load i64, ptr %l6, !tbaa !24
  %t55 = sdiv i64 %t51, %t52
  store i64 %t55, ptr %l27, !tbaa !24
  br label %bb10
bb9:
  store i64 0, ptr %l27, !tbaa !24
  br label %bb10
bb10:
  %t57 = load i64, ptr %l27, !tbaa !24
  store i64 %t57, ptr %l24, !tbaa !24
  br label %bb11
bb11:
  %t58 = load i64, ptr %l24, !tbaa !24
  store i64 %t58, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb12
bb12:
  %t59 = load i64, ptr %l8, !tbaa !24
  %t60 = load i64, ptr %l7, !tbaa !24
  %t63 = icmp slt i64 %t59, %t60
  %t65 = xor i1 %t63, true
  br i1 %t65, label %bb13, label %bb14
bb13:
  br label %bb17
bb14:
  br label %bb15
bb15:
  %t67 = load i64, ptr %l4, !tbaa !24
  %t68 = load i64, ptr %l8, !tbaa !24
  %t69 = load i64, ptr %l6, !tbaa !24
  %t72 = mul i64 %t68, %t69
  %t75 = add i64 %t67, %t72
  store i64 %t75, ptr %l9, !tbaa !24
  %t77 = load i64, ptr %l9, !tbaa !24
  %t78 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t78, ptr %l46, !tbaa !27
  %t79 = load i64, ptr %l9, !tbaa !24
  %t81 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !27
  %t83 = getelementptr i32, ptr %t82, i64 %t79
  %t84 = load i32, ptr %t83, !tbaa !33
  %t86 = load ptr, ptr %lp3
  %t88 = getelementptr { i64, ptr }, ptr %t86, i32 0, i32 1
  %t89 = load ptr, ptr %t88, !tbaa !27
  %t90 = getelementptr i32, ptr %t89, i64 %t77
  store i32 %t84, ptr %t90, !tbaa !33
  br label %bb16
bb16:
  %t91 = load i64, ptr %l8, !tbaa !24
  %t93 = add i64 %t91, 1
  store i64 %t93, ptr %l8, !tbaa !24
  br label %bb12
bb17:
  %t95 = load ptr, ptr %lp3
  %t96 = load { i64, ptr }, ptr %t95, !tbaa !27
  store { i64, ptr } %t96, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3alowering_2elaidApart(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca i32
  %l10 = alloca i32
  %l13 = alloca i32
  %l16 = alloca i32
  %l19 = alloca i1
  %l22 = alloca i32
  %l25 = alloca i1
  %l28 = alloca i32
  %l30 = alloca i1
  %l33 = alloca i32
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/lower:lowering", ptr %a0, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t6 = load ptr, ptr %l3, !tbaa !29
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t6, i32 %a1)
  store i32 %t10, ptr %l10
  br label %bb1
bb1:
  %t11 = load i32, ptr %l10, !tbaa !23
  store i32 %t11, ptr %l4, !tbaa !23
  %t12 = load ptr, ptr %l3, !tbaa !29
  %t16 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t12, i32 %a2)
  store i32 %t16, ptr %l13
  br label %bb2
bb2:
  %t17 = load i32, ptr %l13, !tbaa !23
  store i32 %t17, ptr %l5, !tbaa !23
  %t18 = load ptr, ptr %l3, !tbaa !29
  %t19 = load i32, ptr %l4, !tbaa !23
  %t22 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t18, i32 %t19)
  store i32 %t22, ptr %l16
  br label %bb3
bb3:
  %t23 = load i32, ptr %l16, !range !{i32 0, i32 33}
  %t25 = trunc i64 19 to i32
  %t26 = icmp eq i32 %t23, %t25
  br i1 %t26, label %bb4, label %bb5
bb4:
  %t28 = load ptr, ptr %l3, !tbaa !29
  %t29 = load i32, ptr %l5, !tbaa !23
  %t32 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t28, i32 %t29)
  store i32 %t32, ptr %l22
  br label %bb6
bb5:
  store i1 false, ptr %l19, !tbaa !21
  br label %bb7
bb6:
  %t33 = load i32, ptr %l22, !range !{i32 0, i32 33}
  %t35 = trunc i64 19 to i32
  %t36 = icmp eq i32 %t33, %t35
  store i1 %t36, ptr %l19, !tbaa !21
  br label %bb7
bb7:
  %t38 = load i1, ptr %l19, !tbaa !21
  br i1 %t38, label %bb8, label %bb9
bb8:
  %t39 = load ptr, ptr %l3, !tbaa !29
  %t40 = load i32, ptr %l4, !tbaa !23
  %t43 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t39, i32 %t40)
  store i32 %t43, ptr %l28
  br label %bb10
bb9:
  store i1 false, ptr %l25, !tbaa !21
  br label %bb11
bb10:
  %t44 = load i32, ptr %l28, !tbaa !23
  %t45 = icmp ne i32 %t44, 0
  store i1 %t45, ptr %l25, !tbaa !21
  br label %bb11
bb11:
  %t47 = load i1, ptr %l25, !tbaa !21
  br i1 %t47, label %bb12, label %bb13
bb12:
  %t48 = load ptr, ptr %l3, !tbaa !29
  %t49 = load i32, ptr %l5, !tbaa !23
  %t52 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t48, i32 %t49)
  store i32 %t52, ptr %l33
  br label %bb14
bb13:
  store i1 false, ptr %l30, !tbaa !21
  br label %bb15
bb14:
  %t53 = load i32, ptr %l33, !tbaa !23
  %t54 = icmp eq i32 %t53, 0
  store i1 %t54, ptr %l30, !tbaa !21
  br label %bb15
bb15:
  %t56 = load i1, ptr %l30, !tbaa !21
  store i1 %t56, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2flower_2ecompiler_2flower_3alowering_2eleafPaths(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %lp2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca %"compiler/free:leaf"
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l24 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l26 = alloca i64
  %l28 = alloca i64
  %l33 = alloca %"compiler/free:leaf"
  %l35 = alloca %"compiler/free:leaf"
  %l38 = alloca i1
  %l44 = alloca i64
  %l53 = alloca i64
  %l56 = alloca i64
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l14
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 32, i64 8)
  store ptr %t2, ptr %lp2
  %t3 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l14
  %t4 = load ptr, ptr %lp2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %t4
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/lower:lowering", ptr %t5, i32 0, i32 0
  %t8 = load ptr, ptr %t7, !tbaa !29
  %t10 = getelementptr %"compiler/lower:Lowerer", ptr %t8, i32 0, i32 3
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t13 = icmp eq ptr %t11, null
  br i1 %t13, label %bb2, label %bb3
bb2:
  call void @__olang_check_failed(ptr @olang_loc_e5b6724f2c0e70f4_3544be27bc88d5e0)
  unreachable
bb3:
  br label %bb4
bb4:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/lower:lowering", ptr %t15, i32 0, i32 0
  %t18 = load ptr, ptr %t17, !tbaa !29
  %t20 = getelementptr %"compiler/lower:Lowerer", ptr %t18, i32 0, i32 3
  %t21 = load ptr, ptr %t20, !tbaa !29
  store ptr %t21, ptr %l3, !tbaa !29
  store %olang.scope zeroinitializer, ptr %s1
  %t23 = load ptr, ptr %l3, !tbaa !29
  %t27 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3aFree_2eSoleLeaves(ptr %v0, ptr %s1, ptr %t23, i32 %a1)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t27, ptr %l24
  br label %bb5
bb5:
  %t28 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l24
  %t29 = call ptr @__olang_scope_alloc_a(ptr %s1, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t28, ptr %t29
  store ptr %t29, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb6
bb6:
  store %olang.scope zeroinitializer, ptr %s2
  %t31 = load i64, ptr %l5, !tbaa !24
  store i64 %t31, ptr %l26, !tbaa !24
  %t32 = load ptr, ptr %l4, !tbaa !29
  %t34 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2eLen_3ccompiler_2ffree_3aleaf_3e(ptr %s1, ptr %t32)
  store i64 %t34, ptr %l28
  br label %bb7
bb7:
  %t35 = load i64, ptr %l26, !tbaa !24
  %t36 = load i64, ptr %l28, !tbaa !24
  %t37 = icmp slt i64 %t35, %t36
  %t39 = xor i1 %t37, true
  br i1 %t39, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb36
bb9:
  br label %bb10
bb10:
  %t41 = load ptr, ptr %l4, !tbaa !29
  %t42 = load i64, ptr %l5, !tbaa !24
  %t45 = call %"compiler/free:leaf" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2eAt_3ccompiler_2ffree_3aleaf_3e(ptr %s1, ptr %s1, ptr %t41, i64 %t42)
  store %"compiler/free:leaf" %t45, ptr %l33
  br label %bb11
bb11:
  %t47 = call %"compiler/free:leaf" @olang_2eHelperKind_2eCopy_2ecompiler_2ffree_3aleaf(ptr %s2, ptr %l33)
  store %"compiler/free:leaf" %t47, ptr %l35
  br label %bb12
bb12:
  %t48 = load %"compiler/free:leaf", ptr %l35
  store %"compiler/free:leaf" %t48, ptr %l6
  %t49 = load ptr, ptr %l3, !tbaa !29
  %t50 = getelementptr %"compiler/free:leaf", ptr %l6, i32 0, i32 1
  %t51 = load i64, ptr %t50, !tbaa !24
  %t54 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eIsHandle(ptr %v0, ptr %t49, i64 %t51)
  store i1 %t54, ptr %l38
  br label %bb13
bb13:
  %t55 = load i1, ptr %l38, !tbaa !21
  %t56 = xor i1 %t55, true
  br i1 %t56, label %bb14, label %bb15
bb14:
  %t58 = load ptr, ptr %lp2
  %t59 = getelementptr %"compiler/free:leaf", ptr %l6, i32 0, i32 0
  %t60 = load { i64, ptr }, ptr %t59, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_3e_2ePush_3cArray_3cI64_3e_3e(ptr %v1, ptr %t58, { i64, ptr } %t60)
  br label %bb16
bb15:
  br label %bb17
bb16:
  call void @__olang_scope_close(ptr %s2)
  br label %bb35
bb17:
  %t63 = getelementptr %"compiler/free:leaf", ptr %l6, i32 0, i32 0
  %t64 = load { i64, ptr }, ptr %t63, !tbaa !27
  %t66 = extractvalue { i64, ptr } %t64, 0
  %t68 = add i64 %t66, 1
  store i64 %t68, ptr %l44, !tbaa !24
  %t69 = load i64, ptr %l44, !tbaa !24
  %t70 = icmp sge i64 %t69, 0
  br i1 %t70, label %bb18, label %bb19
bb18:
  %t72 = load i64, ptr %l44, !tbaa !24
  %t73 = icmp sle i64 %t72, 1152921504606846975
  br i1 %t73, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @olang_loc_dc337209e99dc7c1_dc835b0b512a4145)
  unreachable
bb20:
  %t75 = load i64, ptr %l44, !tbaa !24
  %t76 = mul i64 %t75, 8
  %t77 = call ptr @__olang_scope_alloc_zeroed(ptr %s2, i64 %t76)
  %t78 = insertvalue { i64, ptr } undef, i64 %t75, 0
  %t79 = insertvalue { i64, ptr } %t78, ptr %t77, 1
  store { i64, ptr } %t79, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t81 = getelementptr %"compiler/free:leaf", ptr %l6, i32 0, i32 0
  %t82 = load { i64, ptr }, ptr %t81, !tbaa !27
  %t84 = extractvalue { i64, ptr } %t82, 0
  store i64 %t84, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t86 = load i64, ptr %l9, !tbaa !24
  %t87 = load i64, ptr %l8, !tbaa !24
  %t90 = icmp sgt i64 %t86, %t87
  br i1 %t90, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @olang_loc_dc337209e99dc7c1_dc835b0b512a4145)
  unreachable
bb22:
  %t92 = load i64, ptr %l10, !tbaa !24
  %t94 = icmp sgt i64 %t92, 0
  br i1 %t94, label %bb24, label %bb25
bb23:
  store i64 0, ptr %l53, !tbaa !24
  br label %bb27
bb24:
  %t96 = load i64, ptr %l9, !tbaa !24
  %t97 = load i64, ptr %l8, !tbaa !24
  %t100 = sub i64 %t96, %t97
  %t101 = load i64, ptr %l10, !tbaa !24
  %t104 = add i64 %t100, %t101
  %t106 = sub i64 %t104, 1
  %t107 = load i64, ptr %l10, !tbaa !24
  %t110 = sdiv i64 %t106, %t107
  store i64 %t110, ptr %l56, !tbaa !24
  br label %bb26
bb25:
  store i64 0, ptr %l56, !tbaa !24
  br label %bb26
bb26:
  %t112 = load i64, ptr %l56, !tbaa !24
  store i64 %t112, ptr %l53, !tbaa !24
  br label %bb27
bb27:
  %t113 = load i64, ptr %l53, !tbaa !24
  store i64 %t113, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb28
bb28:
  %t114 = load i64, ptr %l12, !tbaa !24
  %t115 = load i64, ptr %l11, !tbaa !24
  %t118 = icmp slt i64 %t114, %t115
  %t120 = xor i1 %t118, true
  br i1 %t120, label %bb29, label %bb30
bb29:
  br label %bb33
bb30:
  br label %bb31
bb31:
  %t122 = load i64, ptr %l8, !tbaa !24
  %t123 = load i64, ptr %l12, !tbaa !24
  %t124 = load i64, ptr %l10, !tbaa !24
  %t127 = mul i64 %t123, %t124
  %t130 = add i64 %t122, %t127
  store i64 %t130, ptr %l13, !tbaa !24
  %t132 = load i64, ptr %l13, !tbaa !24
  %t133 = load i64, ptr %l13, !tbaa !24
  %t134 = getelementptr %"compiler/free:leaf", ptr %l6, i32 0, i32 0
  %t136 = getelementptr { i64, ptr }, ptr %t134, i32 0, i32 1
  %t137 = load ptr, ptr %t136, !tbaa !27
  %t138 = getelementptr i64, ptr %t137, i64 %t133
  %t139 = load i64, ptr %t138, !tbaa !34
  %t142 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t143 = load ptr, ptr %t142, !tbaa !27
  %t144 = getelementptr i64, ptr %t143, i64 %t132
  store i64 %t139, ptr %t144, !tbaa !34
  br label %bb32
bb32:
  %t145 = load i64, ptr %l12, !tbaa !24
  %t147 = add i64 %t145, 1
  store i64 %t147, ptr %l12, !tbaa !24
  br label %bb28
bb33:
  %t149 = getelementptr %"compiler/free:leaf", ptr %l6, i32 0, i32 0
  %t150 = load { i64, ptr }, ptr %t149, !tbaa !27
  %t152 = extractvalue { i64, ptr } %t150, 0
  %t154 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t155 = load ptr, ptr %t154, !tbaa !27
  %t156 = getelementptr i64, ptr %t155, i64 %t152
  store i64 0, ptr %t156, !tbaa !34
  %t157 = load ptr, ptr %lp2
  %t158 = load { i64, ptr }, ptr %l7, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_3e_2ePush_3cArray_3cI64_3e_3e(ptr %v1, ptr %t157, { i64, ptr } %t158)
  br label %bb34
bb34:
  call void @__olang_scope_close(ptr %s2)
  br label %bb35
bb35:
  %t161 = load i64, ptr %l5, !tbaa !24
  %t163 = add i64 %t161, 1
  store i64 %t163, ptr %l5, !tbaa !24
  br label %bb6
bb36:
  call void @__olang_scope_close(ptr %s1)
  %t165 = load ptr, ptr %lp2
  %t166 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t165
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t166, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2eloop(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca %"compiler/lower:loopCtx"
  %l9 = alloca i32
  %l15 = alloca ptr
  %l17 = alloca i32
  %l20 = alloca i64
  %l21 = alloca %"compiler/lower:loopCtx"
  %l25 = alloca ptr
  %l28 = alloca i64
  %l30 = alloca ptr
  %l36 = alloca i64
  %l38 = alloca ptr
  %l40 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l42 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l50 = alloca %"compiler/lower:loopCtx"
  %l53 = alloca %"compiler/lower:loopCtx"
  %l54 = alloca i32
  %l55 = alloca ptr
  %l56 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l58 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 3
  %t5 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t3)
  store i32 %t5, ptr %l9
  br label %bb1
bb1:
  %t6 = load i32, ptr %l9, !tbaa !23
  store i32 %t6, ptr %l4, !tbaa !23
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load i32, ptr %l4, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2egoto(ptr %v0, ptr %t7, i32 %t8)
  br label %bb2
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load i32, ptr %l4, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t11, i32 %t12)
  br label %bb3
bb3:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/lower:lowering", ptr %t15, i32 0, i32 12
  store ptr %t17, ptr %l15, !tbaa !29
  %t18 = load ptr, ptr %l2, !tbaa !29
  %t20 = getelementptr %"compiler/typed:Block", ptr %t18, i32 0, i32 0
  %t21 = load i32, ptr %t20, !tbaa !23
  store i32 %t21, ptr %l17, !tbaa !23
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/lower:lowering", ptr %t22, i32 0, i32 9
  %t26 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3alevel_3e_2eLen_3ccompiler_2flower_3alevel_3e(ptr %v0, ptr %t24)
  store i64 %t26, ptr %l20
  br label %bb4
bb4:
  %t27 = load i32, ptr %l17, !tbaa !23
  %t28 = load i64, ptr %l20, !tbaa !24
  %t29 = call %"compiler/lower:loopCtx" @compiler_2flower_3aloopCtx_2ector(ptr %s0, i32 %t27, i64 %t28)
  store %"compiler/lower:loopCtx" %t29, ptr %l21
  br label %bb5
bb5:
  %t30 = load ptr, ptr %l15, !tbaa !29
  %t31 = load %"compiler/lower:loopCtx", ptr %l21
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3aloopCtx_3e_2ePush_3ccompiler_2flower_3aloopCtx_3e(ptr %v0, ptr %s0, ptr %t30, %"compiler/lower:loopCtx" %t31)
  br label %bb6
bb6:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t33 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eblock(ptr %v0, ptr %v1, ptr %t32, ptr %t33)
  br label %bb7
bb7:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/lower:lowering", ptr %t36, i32 0, i32 12
  store ptr %t38, ptr %l25, !tbaa !29
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/lower:lowering", ptr %t39, i32 0, i32 12
  %t43 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3aloopCtx_3e_2eLen_3ccompiler_2flower_3aloopCtx_3e(ptr %v0, ptr %t41)
  store i64 %t43, ptr %l28
  br label %bb8
bb8:
  %t44 = load i64, ptr %l28, !tbaa !24
  %t45 = sub i64 %t44, 1
  %t46 = load ptr, ptr %l25, !tbaa !29
  %t48 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3aloopCtx_3e_2eRefMut_3ccompiler_2flower_3aloopCtx_3e(ptr %v0, ptr %v0, ptr %t46, i64 %t45)
  store ptr %t48, ptr %l30
  br label %bb9
bb9:
  %t49 = load ptr, ptr %l30, !tbaa !29
  store ptr %t49, ptr %l5, !tbaa !29
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t51 = load ptr, ptr %l5, !tbaa !29
  %t53 = getelementptr %"compiler/lower:loopCtx", ptr %t51, i32 0, i32 4
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eleaveOpen(ptr %v0, ptr %v0, ptr %t50, ptr %t53)
  br label %bb10
bb10:
  %t56 = load ptr, ptr %l5, !tbaa !29
  %t58 = getelementptr %"compiler/lower:loopCtx", ptr %t56, i32 0, i32 4
  %t60 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBlockId_3e_2eLen_3ccompiler_2fmir_3aBlockId_3e(ptr %v0, ptr %t58)
  store i64 %t60, ptr %l36
  br label %bb11
bb11:
  %t61 = load i64, ptr %l36, !tbaa !24
  %t62 = icmp sgt i64 %t61, 0
  br i1 %t62, label %bb12, label %bb13
bb12:
  store %olang.scope zeroinitializer, ptr %s1
  %t64 = load ptr, ptr %l0, !tbaa !29
  store ptr %t64, ptr %l38, !tbaa !29
  %t65 = load ptr, ptr %l5, !tbaa !29
  %t67 = getelementptr %"compiler/lower:loopCtx", ptr %t65, i32 0, i32 4
  %t68 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t67
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t68, ptr %l40
  %t70 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBlockId_3e(ptr %s1, ptr %l40)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t70, ptr %l42
  br label %bb14
bb13:
  br label %bb21
bb14:
  %t71 = load ptr, ptr %l38, !tbaa !29
  %t72 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l42
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2epatch(ptr %v0, ptr %s1, ptr %t71, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t72)
  br label %bb15
bb15:
  %t73 = load ptr, ptr %l3, !tbaa !29
  %t75 = icmp eq ptr %t73, null
  %t77 = xor i1 %t75, true
  br i1 %t77, label %bb16, label %bb17
bb16:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t80 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eblock(ptr %v0, ptr %v2, ptr %t79, ptr %t80)
  br label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb19
bb19:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t84 = load i32, ptr %l4, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2egoto(ptr %v0, ptr %t83, i32 %t84)
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s1)
  br label %bb21
bb21:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr %"compiler/lower:lowering", ptr %t87, i32 0, i32 12
  %t91 = call { i32, %"compiler/lower:loopCtx" } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3aloopCtx_3e_2ePop_3ccompiler_2flower_3aloopCtx_3e(ptr %v0, ptr %v0, ptr %t89)
  %t92 = extractvalue { i32, %"compiler/lower:loopCtx" } %t91, 1
  %t93 = extractvalue { i32, %"compiler/lower:loopCtx" } %t91, 0
  store i32 %t93, ptr %l54
  %t94 = icmp ne i32 %t93, 0
  br i1 %t94, label %bb23, label %ok.95, !prof !99
ok.95:
  store %"compiler/lower:loopCtx" %t92, ptr %l53
  br label %bb22
bb22:
  %t96 = load %"compiler/lower:loopCtx", ptr %l53
  store %"compiler/lower:loopCtx" %t96, ptr %l50
  br label %bb25
bb23:
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb25:
  %t97 = load %"compiler/lower:loopCtx", ptr %l50
  store %"compiler/lower:loopCtx" %t97, ptr %l6
  %t98 = load ptr, ptr %l0, !tbaa !29
  store ptr %t98, ptr %l55, !tbaa !29
  %t99 = getelementptr %"compiler/lower:loopCtx", ptr %l6, i32 0, i32 3
  %t100 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t99
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t100, ptr %l56
  %t102 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBlockId_3e(ptr %s0, ptr %l56)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t102, ptr %l58
  br label %bb26
bb26:
  %t103 = load ptr, ptr %l55, !tbaa !29
  %t104 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l58
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2epatch(ptr %v0, ptr %s0, ptr %t103, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t104)
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2emainPayloads(ptr %v0, ptr %a0, { i64, [4 x i64] } %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca { i64, [4 x i64] }
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i32
  %l15 = alloca i32
  %l16 = alloca i32
  %l22 = alloca i32
  %l26 = alloca { i64, ptr }
  %l32 = alloca i64
  %l35 = alloca i64
  %l53 = alloca { i64, ptr }
  %l56 = alloca i64
  %l62 = alloca ptr
  %l66 = alloca { i64, ptr }
  %l67 = alloca { i64, ptr }
  %l72 = alloca i32
  %l77 = alloca i32
  %l80 = alloca i1
  %l83 = alloca ptr
  %l87 = alloca i32
  %l90 = alloca { i64, ptr }
  %l95 = alloca i32
  %l98 = alloca i32
  %l99 = alloca ptr
  %l104 = alloca { i64, ptr }
  %l107 = alloca { i64, ptr }
  %l109 = alloca { i64, [4 x i64] }
  %l117 = alloca { i64, [21 x i64] }
  %l119 = alloca ptr
  %l120 = alloca %"compiler/source:Span"
  %l121 = alloca i32
  %l123 = alloca { i64, ptr }
  %l126 = alloca { i64, ptr }
  %l132 = alloca { i64, [4 x i64] }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %t209 = alloca { i64, [8 x i64] }, align 8
  %t227 = alloca { i64, [21 x i64] }, align 8
  %t262 = alloca { i64, [8 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/lower:lowering", ptr %t5, i32 0, i32 1
  %t8 = load ptr, ptr %t7, !tbaa !29
  %t10 = getelementptr %"compiler/typed:Body", ptr %t8, i32 0, i32 2
  %t11 = load i32, ptr %t10, !tbaa !23
  %t14 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t4, i32 %t11)
  store i32 %t14, ptr %l22
  br label %bb1
bb1:
  %t15 = load i32, ptr %l22, !tbaa !23
  store i32 %t15, ptr %l3, !tbaa !23
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load i32, ptr %l3, !tbaa !23
  %t18 = load %"compiler/source:Span", ptr %l2
  %t22 = call { i64, ptr } @compiler_2flower_2ecompiler_2flower_3alowering_2ebangNames(ptr %v0, ptr %s0, ptr %t16, i32 %t17, %"compiler/source:Span" %t18)
  store { i64, ptr } %t22, ptr %l26
  br label %bb2
bb2:
  %t23 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t23, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t24 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 0
  store i64 %t26, ptr %l6, !tbaa !24
  store i64 2, ptr %l7, !tbaa !24
  %t28 = load i64, ptr %l6, !tbaa !24
  %t29 = load i64, ptr %l5, !tbaa !24
  %t32 = icmp sgt i64 %t28, %t29
  br i1 %t32, label %bb3, label %bb4
bb3:
  %t34 = load i64, ptr %l7, !tbaa !24
  %t36 = icmp sgt i64 %t34, 0
  br i1 %t36, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l32, !tbaa !24
  br label %bb8
bb5:
  %t38 = load i64, ptr %l6, !tbaa !24
  %t39 = load i64, ptr %l5, !tbaa !24
  %t42 = sub i64 %t38, %t39
  %t43 = load i64, ptr %l7, !tbaa !24
  %t46 = add i64 %t42, %t43
  %t48 = sub i64 %t46, 1
  %t49 = load i64, ptr %l7, !tbaa !24
  %t52 = sdiv i64 %t48, %t49
  store i64 %t52, ptr %l35, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l35, !tbaa !24
  br label %bb7
bb7:
  %t54 = load i64, ptr %l35, !tbaa !24
  store i64 %t54, ptr %l32, !tbaa !24
  br label %bb8
bb8:
  %t55 = load i64, ptr %l32, !tbaa !24
  store i64 %t55, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t56 = load i64, ptr %l9, !tbaa !24
  %t57 = load i64, ptr %l8, !tbaa !24
  %t60 = icmp slt i64 %t56, %t57
  %t62 = xor i1 %t60, true
  br i1 %t62, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb43
bb11:
  br label %bb12
bb12:
  %t64 = load i64, ptr %l5, !tbaa !24
  %t65 = load i64, ptr %l9, !tbaa !24
  %t66 = load i64, ptr %l7, !tbaa !24
  %t69 = mul i64 %t65, %t66
  %t72 = add i64 %t64, %t69
  store i64 %t72, ptr %l10, !tbaa !24
  %t74 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t74, ptr %l53, !tbaa !27
  %t75 = load i64, ptr %l10, !tbaa !24
  %t77 = getelementptr { i64, ptr }, ptr %l53, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !27
  %t79 = getelementptr { i64, [4 x i64] }, ptr %t78, i64 %t75
  %t80 = load { i64, [4 x i64] }, ptr %t79
  store { i64, [4 x i64] } %t80, ptr %l11
  %t82 = load { i64, [4 x i64] }, ptr %l11
  %t84 = extractvalue { i64, [4 x i64] } %t82, 0
  %t85 = icmp eq i64 %t84, 2
  br i1 %t85, label %bb13, label %bb14
bb13:
  %t87 = getelementptr { i64, [4 x i64] }, ptr %l11, i32 0, i32 1
  %t88 = getelementptr { i32, i64 }, ptr %t87, i32 0, i32 1
  %t89 = load i64, ptr %t88
  store i64 %t89, ptr %l12, !tbaa !24
  br label %bb15
bb14:
  br label %bb16
bb15:
  %t91 = load i64, ptr %l12, !tbaa !24
  store i64 %t91, ptr %l56, !tbaa !24
  br label %bb21
bb16:
  br i1 true, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  store i64 0, ptr %l56, !tbaa !24
  br label %bb21
bb20:
  call void @__olang_check_failed(ptr @olang_loc_5dc48dc64c6b10e3_ed2bb1ae700828ff)
  unreachable
bb21:
  %t93 = load i64, ptr %l56, !tbaa !24
  store i64 %t93, ptr %l13, !tbaa !24
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t96 = getelementptr %"compiler/lower:lowering", ptr %t94, i32 0, i32 2
  %t97 = load ptr, ptr %t96, !tbaa !29
  store ptr %t97, ptr %l62, !tbaa !29
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t100 = getelementptr %"compiler/lower:lowering", ptr %t98, i32 0, i32 2
  %t101 = load ptr, ptr %t100, !tbaa !29
  %t102 = load i32, ptr %l3, !tbaa !23
  %t105 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s2, ptr %t101, i32 %t102)
  store { i64, ptr } %t105, ptr %l66
  br label %bb22
bb22:
  %t106 = load { i64, ptr }, ptr %l66, !tbaa !27
  store { i64, ptr } %t106, ptr %l67, !tbaa !27
  %t107 = load i64, ptr %l13, !tbaa !24
  %t109 = ashr i64 %t107, 16
  %t111 = sub i64 %t109, 1
  %t113 = getelementptr { i64, ptr }, ptr %l67, i32 0, i32 1
  %t114 = load ptr, ptr %t113, !tbaa !27
  %t115 = getelementptr i32, ptr %t114, i64 %t111
  %t116 = load i32, ptr %t115, !tbaa !33
  %t117 = load ptr, ptr %l62, !tbaa !29
  %t119 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t117, i32 %t116)
  store i32 %t119, ptr %l72
  br label %bb23
bb23:
  %t120 = load i32, ptr %l72, !tbaa !23
  store i32 %t120, ptr %l14, !tbaa !23
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t123 = getelementptr %"compiler/lower:lowering", ptr %t121, i32 0, i32 0
  %t124 = load ptr, ptr %t123, !tbaa !29
  %t126 = getelementptr %"compiler/lower:Lowerer", ptr %t124, i32 0, i32 0
  %t127 = load ptr, ptr %t126, !tbaa !29
  %t128 = load i32, ptr %l14, !tbaa !23
  %t131 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ePayloadOf(ptr %v0, ptr %t127, i32 %t128)
  store i32 %t131, ptr %l77
  br label %bb24
bb24:
  %t132 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t133 = load i32, ptr %l77, !tbaa !23
  %t135 = icmp eq i32 %t133, %t132
  br i1 %t135, label %bb25, label %bb26
bb25:
  store i1 true, ptr %l80, !tbaa !21
  br label %bb29
bb26:
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t139 = getelementptr %"compiler/lower:lowering", ptr %t137, i32 0, i32 0
  %t140 = load ptr, ptr %t139, !tbaa !29
  %t142 = getelementptr %"compiler/lower:Lowerer", ptr %t140, i32 0, i32 0
  %t143 = load ptr, ptr %t142, !tbaa !29
  store ptr %t143, ptr %l83, !tbaa !29
  %t144 = load ptr, ptr %l0, !tbaa !29
  %t146 = getelementptr %"compiler/lower:lowering", ptr %t144, i32 0, i32 2
  %t147 = load ptr, ptr %t146, !tbaa !29
  %t148 = load i32, ptr %l14, !tbaa !23
  %t151 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t147, i32 %t148)
  store i32 %t151, ptr %l87
  br label %bb27
bb27:
  %t152 = load i64, ptr %l13, !tbaa !24
  %t154 = and i64 %t152, 65535
  %t155 = load ptr, ptr %l83, !tbaa !29
  %t156 = load i32, ptr %l87, !tbaa !23
  %t158 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eWordFields(ptr %v0, ptr %s2, ptr %t155, i32 %t156, i64 %t154)
  store { i64, ptr } %t158, ptr %l90
  br label %bb28
bb28:
  %t159 = load { i64, ptr }, ptr %l90, !tbaa !27
  %t160 = extractvalue { i64, ptr } %t159, 0
  %t162 = icmp eq i64 %t160, 0
  store i1 %t162, ptr %l80, !tbaa !21
  br label %bb29
bb29:
  %t164 = load i1, ptr %l80, !tbaa !21
  br i1 %t164, label %bb30, label %bb31
bb30:
  call void @__olang_scope_close(ptr %s2)
  br label %bb42
bb31:
  br label %bb32
bb32:
  %t165 = load ptr, ptr %l0, !tbaa !29
  %t167 = getelementptr %"compiler/lower:lowering", ptr %t165, i32 0, i32 3
  %t169 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t167)
  store i32 %t169, ptr %l95
  br label %bb33
bb33:
  %t170 = load i32, ptr %l95, !tbaa !23
  store i32 %t170, ptr %l15, !tbaa !23
  %t171 = load ptr, ptr %l0, !tbaa !29
  %t173 = getelementptr %"compiler/lower:lowering", ptr %t171, i32 0, i32 3
  %t175 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t173)
  store i32 %t175, ptr %l98
  br label %bb34
bb34:
  %t176 = load i32, ptr %l98, !tbaa !23
  store i32 %t176, ptr %l16, !tbaa !23
  %t177 = load ptr, ptr %l0, !tbaa !29
  store ptr %t177, ptr %l99, !tbaa !29
  %t178 = load ptr, ptr %l0, !tbaa !29
  %t179 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t181 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t181, ptr %l104, !tbaa !27
  %t182 = load i64, ptr %l10, !tbaa !24
  %t184 = getelementptr { i64, ptr }, ptr %l104, i32 0, i32 1
  %t185 = load ptr, ptr %t184, !tbaa !27
  %t186 = getelementptr { i64, [4 x i64] }, ptr %t185, i64 %t182
  %t187 = load { i64, [4 x i64] }, ptr %t186
  %t188 = mul i64 2, 40
  %t189 = call ptr @__olang_scope_alloc_zeroed(ptr %s2, i64 %t188)
  %t190 = insertvalue { i64, ptr } undef, i64 2, 0
  %t191 = insertvalue { i64, ptr } %t190, ptr %t189, 1
  store { i64, ptr } %t191, ptr %l107, !tbaa !27
  %t193 = getelementptr { i64, ptr }, ptr %l107, i32 0, i32 1
  %t194 = load ptr, ptr %t193, !tbaa !27
  %t195 = getelementptr { i64, [4 x i64] }, ptr %t194, i64 0
  store { i64, [4 x i64] } %a1, ptr %t195
  %t197 = getelementptr { i64, ptr }, ptr %l107, i32 0, i32 1
  %t198 = load ptr, ptr %t197, !tbaa !27
  %t199 = getelementptr { i64, [4 x i64] }, ptr %t198, i64 1
  store { i64, [4 x i64] } %t187, ptr %t199
  %t200 = load %"compiler/source:Span", ptr %l2
  %t204 = load { i64, ptr }, ptr %l107, !tbaa !27
  %t206 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s2, ptr %t178, i32 13, i32 %t179, { i64, ptr } %t204, %"compiler/source:Span" %t200)
  store { i64, [4 x i64] } %t206, ptr %l109
  br label %bb35
bb35:
  %t207 = load i32, ptr %l15, !tbaa !23
  %t208 = load i32, ptr %l16, !tbaa !23
  store { i64, [8 x i64] } zeroinitializer, ptr %t209
  %t210 = getelementptr { i64, [8 x i64] }, ptr %t209, i32 0, i32 0
  store i64 2, ptr %t210
  %t211 = load { i64, [4 x i64] }, ptr %l109
  %t212 = insertvalue { { i64, [4 x i64] }, i32, i32 } undef, { i64, [4 x i64] } %t211, 0
  %t214 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t212, i32 %t207, 1
  %t216 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t214, i32 %t208, 2
  %t217 = getelementptr { i64, [8 x i64] }, ptr %t209, i32 0, i32 1
  store { { i64, [4 x i64] }, i32, i32 } %t216, ptr %t217
  %t218 = load { i64, [8 x i64] }, ptr %t209
  %t219 = load ptr, ptr %l99, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t219, { i64, [8 x i64] } %t218)
  br label %bb36
bb36:
  %t221 = load ptr, ptr %l0, !tbaa !29
  %t222 = load i32, ptr %l15, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t221, i32 %t222)
  br label %bb37
bb37:
  %t225 = load ptr, ptr %l0, !tbaa !29
  %t226 = load %"compiler/source:Span", ptr %l2
  store { i64, [21 x i64] } zeroinitializer, ptr %t227
  %t228 = getelementptr { i64, [21 x i64] }, ptr %t227, i32 0, i32 0
  store i64 11, ptr %t228
  %t230 = insertvalue { %"compiler/source:Span" } undef, %"compiler/source:Span" %t226, 0
  %t231 = getelementptr { i64, [21 x i64] }, ptr %t227, i32 0, i32 1
  store { %"compiler/source:Span" } %t230, ptr %t231
  %t232 = load { i64, [21 x i64] }, ptr %t227
  store { i64, [21 x i64] } %t232, ptr %l117
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s2, ptr %t225, ptr %l117)
  br label %bb38
bb38:
  %t235 = load ptr, ptr %l0, !tbaa !29
  store ptr %t235, ptr %l119, !tbaa !29
  %t236 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t236, ptr %l120
  store i32 6, ptr %l121
  %t237 = load ptr, ptr %l0, !tbaa !29
  %t238 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t238, ptr %l123, !tbaa !27
  %t239 = load i64, ptr %l10, !tbaa !24
  %t241 = getelementptr { i64, ptr }, ptr %l123, i32 0, i32 1
  %t242 = load ptr, ptr %t241, !tbaa !27
  %t243 = getelementptr { i64, [4 x i64] }, ptr %t242, i64 %t239
  %t244 = load { i64, [4 x i64] }, ptr %t243
  %t245 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t245, ptr %l126, !tbaa !27
  %t246 = load i64, ptr %l10, !tbaa !24
  %t248 = add i64 %t246, 1
  %t250 = getelementptr { i64, ptr }, ptr %l126, i32 0, i32 1
  %t251 = load ptr, ptr %t250, !tbaa !27
  %t252 = getelementptr { i64, [4 x i64] }, ptr %t251, i64 %t248
  %t253 = load { i64, [4 x i64] }, ptr %t252
  %t254 = load i32, ptr %l3, !tbaa !23
  %t255 = load %"compiler/source:Span", ptr %l2
  %t261 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ewithPayload(ptr %v0, ptr %t237, { i64, [4 x i64] } %t244, { i64, [4 x i64] } %t253, i32 %t254, %"compiler/source:Span" %t255)
  store { i64, [4 x i64] } %t261, ptr %l132
  br label %bb39
bb39:
  store { i64, [8 x i64] } zeroinitializer, ptr %t262
  %t263 = getelementptr { i64, [8 x i64] }, ptr %t262, i32 0, i32 0
  store i64 9, ptr %t263
  %t264 = load %"compiler/source:Span", ptr %l120
  %t265 = insertvalue { %"compiler/source:Span", i32, { i64, [4 x i64] } } undef, %"compiler/source:Span" %t264, 0
  %t266 = load i32, ptr %l121, !range !{i32 0, i32 16}
  %t267 = insertvalue { %"compiler/source:Span", i32, { i64, [4 x i64] } } %t265, i32 %t266, 1
  %t268 = load { i64, [4 x i64] }, ptr %l132
  %t269 = insertvalue { %"compiler/source:Span", i32, { i64, [4 x i64] } } %t267, { i64, [4 x i64] } %t268, 2
  %t270 = getelementptr { i64, [8 x i64] }, ptr %t262, i32 0, i32 1
  store { %"compiler/source:Span", i32, { i64, [4 x i64] } } %t269, ptr %t270
  %t271 = load { i64, [8 x i64] }, ptr %t262
  %t272 = load ptr, ptr %l119, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t272, { i64, [8 x i64] } %t271)
  br label %bb40
bb40:
  %t274 = load ptr, ptr %l0, !tbaa !29
  %t275 = load i32, ptr %l16, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t274, i32 %t275)
  br label %bb41
bb41:
  call void @__olang_scope_close(ptr %s2)
  br label %bb42
bb42:
  %t278 = load i64, ptr %l9, !tbaa !24
  %t280 = add i64 %t278, 1
  store i64 %t280, ptr %l9, !tbaa !24
  br label %bb9
bb43:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2emake(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca { i64, ptr }
  %l7 = alloca i32
  %l8 = alloca { i64, [4 x i64] }
  %l9 = alloca ptr
  %l10 = alloca { i64, [4 x i64] }
  %l22 = alloca { i64, ptr }
  %l29 = alloca i1
  %l32 = alloca i1
  %l35 = alloca i32
  %l36 = alloca ptr
  %l37 = alloca i32
  %l38 = alloca i32
  %l40 = alloca i64
  %l44 = alloca %"compiler/mir:Range"
  %l47 = alloca { i64, [4 x i64] }
  %l48 = alloca ptr
  %l49 = alloca i32
  %l53 = alloca { i64, [1 x i64] }
  %l58 = alloca { i64, [4 x i64] }
  %l59 = alloca ptr
  %l60 = alloca i32
  %l61 = alloca i32
  %l63 = alloca i64
  %l67 = alloca %"compiler/mir:Range"
  %l70 = alloca { i64, [4 x i64] }
  %l78 = alloca { i64, [4 x i64] }
  %l86 = alloca { i64, [4 x i64] }
  %l90 = alloca { i64, ptr }
  %l95 = alloca { i64, [4 x i64] }
  %l99 = alloca ptr
  %l101 = alloca i32
  %l103 = alloca i1
  %l105 = alloca ptr
  %l106 = alloca { i64, [4 x i64] }
  %l108 = alloca i32
  %l109 = alloca i32
  %l113 = alloca { i64, [1 x i64] }
  %l115 = alloca { i64, [4 x i64] }
  %l121 = alloca i1
  %l122 = alloca i1
  %l125 = alloca i1
  %l128 = alloca ptr
  %l129 = alloca { i64, [4 x i64] }
  %l130 = alloca i32
  %l134 = alloca { i64, [1 x i64] }
  %l136 = alloca { i64, [4 x i64] }
  %s1 = alloca %olang.scope
  %rv = alloca { i64, [4 x i64] }
  %t35 = alloca { i64, [4 x i64] }, align 8
  %t73 = alloca { i64, [15 x i64] }, align 8
  %t102 = alloca { i64, [15 x i64] }, align 8
  %t133 = alloca { i64, [15 x i64] }, align 8
  %t159 = alloca { i64, [1 x i64] }, align 8
  %t178 = alloca { i64, [1 x i64] }, align 8
  %t214 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  store %"compiler/source:Span" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t6 = load ptr, ptr %l1, !tbaa !29
  %t8 = getelementptr %"compiler/typed:Make", ptr %t6, i32 0, i32 0
  %t9 = load i32, ptr %t8, !range !{i32 0, i32 5}
  store i32 %t9, ptr %l5
  %t11 = load i32, ptr %l5, !range !{i32 0, i32 5}
  %t13 = trunc i64 0 to i32
  %t14 = icmp eq i32 %t11, %t13
  br i1 %t14, label %bb1, label %bb2
bb1:
  br label %bb5
bb2:
  %t16 = load i32, ptr %l5, !range !{i32 0, i32 5}
  %t18 = trunc i64 1 to i32
  %t19 = icmp eq i32 %t16, %t18
  br i1 %t19, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb24
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t24 = getelementptr %"compiler/typed:Make", ptr %t22, i32 0, i32 2
  %t25 = load { i64, ptr }, ptr %t24, !tbaa !27
  %t28 = call { i64, ptr } @compiler_2flower_2ecompiler_2flower_3alowering_2evals(ptr %v0, ptr %v1, ptr %s1, ptr %t21, { i64, ptr } %t25)
  store { i64, ptr } %t28, ptr %l22
  br label %bb6
bb6:
  %t29 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t29, ptr %l6, !tbaa !27
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/lower:lowering", ptr %t30, i32 0, i32 7
  %t33 = load i1, ptr %t32, !tbaa !21
  br i1 %t33, label %bb7, label %bb8
bb7:
  store { i64, [4 x i64] } zeroinitializer, ptr %t35
  %t36 = getelementptr { i64, [4 x i64] }, ptr %t35, i32 0, i32 0
  store i64 0, ptr %t36
  %t37 = load { i64, [4 x i64] }, ptr %t35
  call void @__olang_scope_close(ptr %s1)
  store { i64, [4 x i64] } %t37, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t39 = load ptr, ptr %l1, !tbaa !29
  %t41 = getelementptr %"compiler/typed:Make", ptr %t39, i32 0, i32 4
  %t42 = load i32, ptr %t41, !tbaa !23
  %t44 = icmp sge i32 %t42, 0
  br i1 %t44, label %bb10, label %bb11
bb10:
  %t46 = load ptr, ptr %l4, !tbaa !29
  %t47 = load i32, ptr %l2, !tbaa !23
  %t50 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t46, i32 %t47)
  store i1 %t50, ptr %l32
  br label %bb12
bb11:
  store i1 false, ptr %l29, !tbaa !21
  br label %bb13
bb12:
  %t51 = load i1, ptr %l32, !tbaa !21
  store i1 %t51, ptr %l29, !tbaa !21
  br label %bb13
bb13:
  %t52 = load i1, ptr %l29, !tbaa !21
  br i1 %t52, label %bb14, label %bb15
bb14:
  %t53 = load ptr, ptr %l4, !tbaa !29
  %t54 = load i32, ptr %l2, !tbaa !23
  %t57 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t53, i32 %t54)
  store i32 %t57, ptr %l35
  br label %bb16
bb15:
  br label %bb21
bb16:
  %t58 = load i32, ptr %l35, !tbaa !23
  store i32 %t58, ptr %l7, !tbaa !23
  %t59 = load ptr, ptr %l0, !tbaa !29
  store ptr %t59, ptr %l36, !tbaa !29
  %t60 = load i32, ptr %l7, !tbaa !23
  store i32 %t60, ptr %l37, !tbaa !23
  %t61 = load i32, ptr %l7, !tbaa !23
  store i32 %t61, ptr %l38, !tbaa !23
  %t62 = load ptr, ptr %l1, !tbaa !29
  %t64 = getelementptr %"compiler/typed:Make", ptr %t62, i32 0, i32 1
  %t65 = load i64, ptr %t64, !tbaa !24
  store i64 %t65, ptr %l40, !tbaa !24
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"compiler/lower:lowering", ptr %t66, i32 0, i32 3
  %t69 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t72 = call %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eArgs(ptr %v0, ptr %s1, ptr %t68, { i64, ptr } %t69)
  store %"compiler/mir:Range" %t72, ptr %l44
  br label %bb17
bb17:
  store { i64, [15 x i64] } zeroinitializer, ptr %t73
  %t74 = getelementptr { i64, [15 x i64] }, ptr %t73, i32 0, i32 0
  store i64 6, ptr %t74
  %t75 = load i32, ptr %l38, !tbaa !23
  %t76 = insertvalue { i32, i64, %"compiler/mir:Range" } undef, i32 %t75, 0
  %t77 = load i64, ptr %l40, !tbaa !24
  %t78 = insertvalue { i32, i64, %"compiler/mir:Range" } %t76, i64 %t77, 1
  %t79 = load %"compiler/mir:Range", ptr %l44
  %t80 = insertvalue { i32, i64, %"compiler/mir:Range" } %t78, %"compiler/mir:Range" %t79, 2
  %t81 = getelementptr { i64, [15 x i64] }, ptr %t73, i32 0, i32 1
  store { i32, i64, %"compiler/mir:Range" } %t80, ptr %t81
  %t82 = load { i64, [15 x i64] }, ptr %t73
  %t83 = load %"compiler/source:Span", ptr %l3
  %t84 = load ptr, ptr %l36, !tbaa !29
  %t85 = load i32, ptr %l37, !tbaa !23
  %t88 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %t84, i32 %t85, { i64, [15 x i64] } %t82, %"compiler/source:Span" %t83)
  store { i64, [4 x i64] } %t88, ptr %l47
  br label %bb18
bb18:
  %t89 = load { i64, [4 x i64] }, ptr %l47
  store { i64, [4 x i64] } %t89, ptr %l8
  %t90 = load ptr, ptr %l0, !tbaa !29
  store ptr %t90, ptr %l48, !tbaa !29
  %t91 = load i32, ptr %l2, !tbaa !23
  store i32 %t91, ptr %l49, !tbaa !23
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t93 = load ptr, ptr %l1, !tbaa !29
  %t95 = getelementptr %"compiler/typed:Make", ptr %t93, i32 0, i32 4
  %t96 = load i32, ptr %t95, !tbaa !23
  %t99 = call { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ebuilt(ptr %v0, ptr %t92, i32 %t96)
  store { i64, [1 x i64] } %t99, ptr %l53
  br label %bb19
bb19:
  %t100 = load { i64, [4 x i64] }, ptr %l8
  %t101 = load i32, ptr %l2, !tbaa !23
  store { i64, [15 x i64] } zeroinitializer, ptr %t102
  %t103 = getelementptr { i64, [15 x i64] }, ptr %t102, i32 0, i32 0
  store i64 7, ptr %t103
  %t104 = load { i64, [1 x i64] }, ptr %l53
  %t105 = insertvalue { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 } undef, { i64, [1 x i64] } %t104, 0
  %t107 = insertvalue { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 } %t105, { i64, [4 x i64] } %t100, 1
  %t109 = insertvalue { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 } %t107, i32 %t101, 2
  %t110 = getelementptr { i64, [15 x i64] }, ptr %t102, i32 0, i32 1
  store { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 } %t109, ptr %t110
  %t111 = load { i64, [15 x i64] }, ptr %t102
  %t112 = load %"compiler/source:Span", ptr %l3
  %t113 = load ptr, ptr %l48, !tbaa !29
  %t114 = load i32, ptr %l49, !tbaa !23
  %t117 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %t113, i32 %t114, { i64, [15 x i64] } %t111, %"compiler/source:Span" %t112)
  store { i64, [4 x i64] } %t117, ptr %l58
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s1)
  %t118 = load { i64, [4 x i64] }, ptr %l58
  store { i64, [4 x i64] } %t118, ptr %rv
  br label %ret
bb21:
  %t119 = load ptr, ptr %l0, !tbaa !29
  store ptr %t119, ptr %l59, !tbaa !29
  %t120 = load i32, ptr %l2, !tbaa !23
  store i32 %t120, ptr %l60, !tbaa !23
  %t121 = load i32, ptr %l2, !tbaa !23
  store i32 %t121, ptr %l61, !tbaa !23
  %t122 = load ptr, ptr %l1, !tbaa !29
  %t124 = getelementptr %"compiler/typed:Make", ptr %t122, i32 0, i32 1
  %t125 = load i64, ptr %t124, !tbaa !24
  store i64 %t125, ptr %l63, !tbaa !24
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t128 = getelementptr %"compiler/lower:lowering", ptr %t126, i32 0, i32 3
  %t129 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t132 = call %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eArgs(ptr %v0, ptr %s1, ptr %t128, { i64, ptr } %t129)
  store %"compiler/mir:Range" %t132, ptr %l67
  br label %bb22
bb22:
  store { i64, [15 x i64] } zeroinitializer, ptr %t133
  %t134 = getelementptr { i64, [15 x i64] }, ptr %t133, i32 0, i32 0
  store i64 6, ptr %t134
  %t135 = load i32, ptr %l61, !tbaa !23
  %t136 = insertvalue { i32, i64, %"compiler/mir:Range" } undef, i32 %t135, 0
  %t137 = load i64, ptr %l63, !tbaa !24
  %t138 = insertvalue { i32, i64, %"compiler/mir:Range" } %t136, i64 %t137, 1
  %t139 = load %"compiler/mir:Range", ptr %l67
  %t140 = insertvalue { i32, i64, %"compiler/mir:Range" } %t138, %"compiler/mir:Range" %t139, 2
  %t141 = getelementptr { i64, [15 x i64] }, ptr %t133, i32 0, i32 1
  store { i32, i64, %"compiler/mir:Range" } %t140, ptr %t141
  %t142 = load { i64, [15 x i64] }, ptr %t133
  %t143 = load %"compiler/source:Span", ptr %l3
  %t144 = load ptr, ptr %l59, !tbaa !29
  %t145 = load i32, ptr %l60, !tbaa !23
  %t148 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %t144, i32 %t145, { i64, [15 x i64] } %t142, %"compiler/source:Span" %t143)
  store { i64, [4 x i64] } %t148, ptr %l70
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s1)
  %t149 = load { i64, [4 x i64] }, ptr %l70
  store { i64, [4 x i64] } %t149, ptr %rv
  br label %ret
bb24:
  %t150 = load i32, ptr %l5, !range !{i32 0, i32 5}
  %t152 = trunc i64 2 to i32
  %t153 = icmp eq i32 %t150, %t152
  br i1 %t153, label %bb25, label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb29
bb27:
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t156 = load ptr, ptr %l1, !tbaa !29
  %t157 = load i32, ptr %l2, !tbaa !23
  %t158 = load %"compiler/source:Span", ptr %l3
  store { i64, [1 x i64] } zeroinitializer, ptr %t159
  %t160 = getelementptr { i64, [1 x i64] }, ptr %t159, i32 0, i32 0
  store i64 2, ptr %t160
  %t161 = load { i64, [1 x i64] }, ptr %t159
  %t167 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2earrayLit(ptr %v0, ptr %v1, ptr %t155, ptr %t156, i32 %t157, %"compiler/source:Span" %t158, i1 false, { i64, [1 x i64] } %t161)
  store { i64, [4 x i64] } %t167, ptr %l78
  br label %bb28
bb28:
  %t168 = load { i64, [4 x i64] }, ptr %l78
  store { i64, [4 x i64] } %t168, ptr %rv
  br label %ret
bb29:
  %t169 = load i32, ptr %l5, !range !{i32 0, i32 5}
  %t171 = trunc i64 3 to i32
  %t172 = icmp eq i32 %t169, %t171
  br i1 %t172, label %bb30, label %bb31
bb30:
  br label %bb32
bb31:
  br label %bb34
bb32:
  %t174 = load ptr, ptr %l0, !tbaa !29
  %t175 = load ptr, ptr %l1, !tbaa !29
  %t176 = load i32, ptr %l2, !tbaa !23
  %t177 = load %"compiler/source:Span", ptr %l3
  store { i64, [1 x i64] } zeroinitializer, ptr %t178
  %t179 = getelementptr { i64, [1 x i64] }, ptr %t178, i32 0, i32 0
  store i64 2, ptr %t179
  %t180 = load { i64, [1 x i64] }, ptr %t178
  %t186 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2efill(ptr %v0, ptr %v1, ptr %t174, ptr %t175, i32 %t176, %"compiler/source:Span" %t177, i1 false, { i64, [1 x i64] } %t180)
  store { i64, [4 x i64] } %t186, ptr %l86
  br label %bb33
bb33:
  %t187 = load { i64, [4 x i64] }, ptr %l86
  store { i64, [4 x i64] } %t187, ptr %rv
  br label %ret
bb34:
  %t188 = load i32, ptr %l5, !range !{i32 0, i32 5}
  %t190 = trunc i64 4 to i32
  %t191 = icmp eq i32 %t188, %t190
  br i1 %t191, label %bb35, label %bb36
bb35:
  br label %bb37
bb36:
  br label %bb60
bb37:
  %t193 = load ptr, ptr %l1, !tbaa !29
  %t195 = getelementptr %"compiler/typed:Make", ptr %t193, i32 0, i32 2
  %t196 = load { i64, ptr }, ptr %t195, !tbaa !27
  store { i64, ptr } %t196, ptr %l90, !tbaa !27
  %t197 = getelementptr { i64, ptr }, ptr %l90, i32 0, i32 1
  %t198 = load ptr, ptr %t197, !tbaa !27
  %t199 = getelementptr ptr, ptr %t198, i64 0
  %t200 = load ptr, ptr %t199, !tbaa !39
  store ptr %t200, ptr %l9, !tbaa !29
  %t202 = load ptr, ptr %l0, !tbaa !29
  %t203 = load ptr, ptr %l9, !tbaa !29
  %t207 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v1, ptr %t202, ptr %t203)
  store { i64, [4 x i64] } %t207, ptr %l95
  br label %bb38
bb38:
  %t208 = load { i64, [4 x i64] }, ptr %l95
  store { i64, [4 x i64] } %t208, ptr %l10
  %t209 = load ptr, ptr %l0, !tbaa !29
  %t211 = getelementptr %"compiler/lower:lowering", ptr %t209, i32 0, i32 7
  %t212 = load i1, ptr %t211, !tbaa !21
  br i1 %t212, label %bb39, label %bb40
bb39:
  store { i64, [4 x i64] } zeroinitializer, ptr %t214
  %t215 = getelementptr { i64, [4 x i64] }, ptr %t214, i32 0, i32 0
  store i64 0, ptr %t215
  %t216 = load { i64, [4 x i64] }, ptr %t214
  store { i64, [4 x i64] } %t216, ptr %rv
  br label %ret
bb40:
  br label %bb41
bb41:
  %t218 = load ptr, ptr %l4, !tbaa !29
  store ptr %t218, ptr %l99, !tbaa !29
  %t219 = load ptr, ptr %l9, !tbaa !29
  %t221 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t219)
  store i32 %t221, ptr %l101
  br label %bb42
bb42:
  %t222 = load i32, ptr %l2, !tbaa !23
  %t223 = load ptr, ptr %l99, !tbaa !29
  %t224 = load i32, ptr %l101, !tbaa !23
  %t226 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t223, i32 %t224, i32 %t222)
  store i1 %t226, ptr %l103
  br label %bb43
bb43:
  %t227 = load i1, ptr %l103, !tbaa !21
  %t228 = xor i1 %t227, true
  br i1 %t228, label %bb44, label %bb45
bb44:
  %t230 = load ptr, ptr %l0, !tbaa !29
  store ptr %t230, ptr %l105, !tbaa !29
  %t231 = load { i64, [4 x i64] }, ptr %l10
  store { i64, [4 x i64] } %t231, ptr %l106
  %t232 = load ptr, ptr %l9, !tbaa !29
  %t234 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t232)
  store i32 %t234, ptr %l108
  br label %bb46
bb45:
  br label %bb49
bb46:
  %t235 = load i32, ptr %l2, !tbaa !23
  store i32 %t235, ptr %l109, !tbaa !23
  %t236 = load ptr, ptr %l0, !tbaa !29
  %t237 = load ptr, ptr %l1, !tbaa !29
  %t239 = getelementptr %"compiler/typed:Make", ptr %t237, i32 0, i32 4
  %t240 = load i32, ptr %t239, !tbaa !23
  %t243 = call { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2emadeAt(ptr %v0, ptr %t236, i32 %t240)
  store { i64, [1 x i64] } %t243, ptr %l113
  br label %bb47
bb47:
  %t244 = load %"compiler/source:Span", ptr %l3
  %t245 = load ptr, ptr %l105, !tbaa !29
  %t246 = load { i64, [4 x i64] }, ptr %l106
  %t247 = load i32, ptr %l108, !tbaa !23
  %t248 = load i32, ptr %l109, !tbaa !23
  %t249 = load { i64, [1 x i64] }, ptr %l113
  %t251 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ederefCopy(ptr %v0, ptr %t245, { i64, [4 x i64] } %t246, i32 %t247, i32 %t248, { i64, [1 x i64] } %t249, %"compiler/source:Span" %t244)
  store { i64, [4 x i64] } %t251, ptr %l115
  br label %bb48
bb48:
  %t252 = load { i64, [4 x i64] }, ptr %l115
  store { i64, [4 x i64] } %t252, ptr %rv
  br label %ret
bb49:
  %t253 = load ptr, ptr %l0, !tbaa !29
  %t255 = getelementptr %"compiler/lower:lowering", ptr %t253, i32 0, i32 35
  %t256 = load ptr, ptr %l1, !tbaa !29
  %t258 = getelementptr %"compiler/typed:Make", ptr %t256, i32 0, i32 4
  %t259 = load i32, ptr %t258, !tbaa !23
  %t261 = sext i32 %t259 to i64
  %t264 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %t255, i64 %t261)
  store i1 %t264, ptr %l121
  br label %bb50
bb50:
  %t265 = load i1, ptr %l121, !tbaa !21
  br i1 %t265, label %bb51, label %bb52
bb51:
  %t266 = load ptr, ptr %l4, !tbaa !29
  %t267 = load i32, ptr %l2, !tbaa !23
  %t270 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRunsCopy(ptr %v0, ptr %t266, i32 %t267)
  store i1 %t270, ptr %l125
  br label %bb53
bb52:
  store i1 false, ptr %l122, !tbaa !21
  br label %bb54
bb53:
  %t271 = load i1, ptr %l125, !tbaa !21
  %t272 = xor i1 %t271, true
  store i1 %t272, ptr %l122, !tbaa !21
  br label %bb54
bb54:
  %t274 = load i1, ptr %l122, !tbaa !21
  br i1 %t274, label %bb55, label %bb56
bb55:
  %t275 = load { i64, [4 x i64] }, ptr %l10
  store { i64, [4 x i64] } %t275, ptr %rv
  br label %ret
bb56:
  br label %bb57
bb57:
  %t277 = load ptr, ptr %l0, !tbaa !29
  store ptr %t277, ptr %l128, !tbaa !29
  %t278 = load { i64, [4 x i64] }, ptr %l10
  store { i64, [4 x i64] } %t278, ptr %l129
  %t279 = load i32, ptr %l2, !tbaa !23
  store i32 %t279, ptr %l130, !tbaa !23
  %t280 = load ptr, ptr %l0, !tbaa !29
  %t281 = load ptr, ptr %l1, !tbaa !29
  %t283 = getelementptr %"compiler/typed:Make", ptr %t281, i32 0, i32 4
  %t284 = load i32, ptr %t283, !tbaa !23
  %t287 = call { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2emadeAt(ptr %v0, ptr %t280, i32 %t284)
  store { i64, [1 x i64] } %t287, ptr %l134
  br label %bb58
bb58:
  %t288 = load %"compiler/source:Span", ptr %l3
  %t289 = load ptr, ptr %l128, !tbaa !29
  %t290 = load { i64, [4 x i64] }, ptr %l129
  %t291 = load i32, ptr %l130, !tbaa !23
  %t292 = load { i64, [1 x i64] }, ptr %l134
  %t294 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eownCopyOf(ptr %v0, ptr %t289, { i64, [4 x i64] } %t290, i32 %t291, { i64, [1 x i64] } %t292, %"compiler/source:Span" %t288, i1 false)
  store { i64, [4 x i64] } %t294, ptr %l136
  br label %bb59
bb59:
  %t295 = load { i64, [4 x i64] }, ptr %l136
  store { i64, [4 x i64] } %t295, ptr %rv
  br label %ret
bb60:
  call void @__olang_check_failed(ptr @olang_loc_c00faf6434efe24b_96f261c8870620df)
  unreachable
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3alowering_2ematchCopies(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l15 = alloca { i64, ptr }
  %l22 = alloca i1
  %l23 = alloca ptr
  %l29 = alloca i1
  %l37 = alloca i1
  %l47 = alloca i1
  %l48 = alloca ptr
  %l59 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Match", ptr %t1, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t6 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  store i64 %t8, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t10 = load i64, ptr %l3, !tbaa !24
  %t11 = load i64, ptr %l4, !tbaa !24
  %t14 = icmp slt i64 %t10, %t11
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb2, label %bb3
bb2:
  br label %bb16
bb3:
  br label %bb4
bb4:
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t18, ptr %l15, !tbaa !27
  %t19 = load i64, ptr %l3, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr ptr, ptr %t22, i64 %t19
  %t24 = load ptr, ptr %t23, !tbaa !39
  store ptr %t24, ptr %l5, !tbaa !29
  %t26 = load ptr, ptr %l5, !tbaa !29
  %t28 = getelementptr %"compiler/typed:Arm", ptr %t26, i32 0, i32 4
  %t29 = load ptr, ptr %t28, !tbaa !29
  %t31 = icmp eq ptr %t29, null
  %t33 = xor i1 %t31, true
  br i1 %t33, label %bb5, label %bb6
bb5:
  %t35 = load ptr, ptr %l0, !tbaa !29
  store ptr %t35, ptr %l23, !tbaa !29
  %t36 = load ptr, ptr %l5, !tbaa !29
  %t38 = getelementptr %"compiler/typed:Arm", ptr %t36, i32 0, i32 4
  %t39 = load ptr, ptr %t38, !tbaa !29
  %t41 = icmp eq ptr %t39, null
  br i1 %t41, label %bb7, label %bb8
bb6:
  store i1 false, ptr %l22, !tbaa !21
  br label %bb11
bb7:
  call void @__olang_check_failed(ptr @olang_loc_f71032533cd82c8_29b3308e7cd66624)
  unreachable
bb8:
  br label %bb9
bb9:
  %t43 = load ptr, ptr %l5, !tbaa !29
  %t45 = getelementptr %"compiler/typed:Arm", ptr %t43, i32 0, i32 4
  %t46 = load ptr, ptr %t45, !tbaa !29
  %t47 = load ptr, ptr %l23, !tbaa !29
  %t49 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2ecopiesValue(ptr %v0, ptr %v1, ptr %t47, ptr %t46)
  store i1 %t49, ptr %l29
  br label %bb10
bb10:
  %t50 = load i1, ptr %l29, !tbaa !21
  store i1 %t50, ptr %l22, !tbaa !21
  br label %bb11
bb11:
  %t51 = load i1, ptr %l22, !tbaa !21
  br i1 %t51, label %bb12, label %bb13
bb12:
  store i1 true, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  br label %bb15
bb15:
  %t53 = load i64, ptr %l3, !tbaa !24
  %t55 = add i64 %t53, 1
  store i64 %t55, ptr %l3, !tbaa !24
  br label %bb1
bb16:
  %t57 = load ptr, ptr %l1, !tbaa !29
  %t59 = getelementptr %"compiler/typed:Match", ptr %t57, i32 0, i32 2
  %t60 = load ptr, ptr %t59, !tbaa !29
  %t62 = icmp eq ptr %t60, null
  %t64 = xor i1 %t62, true
  br i1 %t64, label %bb17, label %bb18
bb17:
  %t66 = load ptr, ptr %l1, !tbaa !29
  %t68 = getelementptr %"compiler/typed:Match", ptr %t66, i32 0, i32 2
  %t69 = load ptr, ptr %t68, !tbaa !29
  %t71 = icmp eq ptr %t69, null
  br i1 %t71, label %bb19, label %bb20
bb18:
  store i1 false, ptr %l37, !tbaa !21
  br label %bb22
bb19:
  call void @__olang_check_failed(ptr @olang_loc_6cc454f6892da6e7_dc94ff52b1800ff3)
  unreachable
bb20:
  br label %bb21
bb21:
  %t73 = load ptr, ptr %l1, !tbaa !29
  %t75 = getelementptr %"compiler/typed:Match", ptr %t73, i32 0, i32 2
  %t76 = load ptr, ptr %t75, !tbaa !29
  %t79 = getelementptr %"compiler/typed:Arm", ptr %t76, i32 0, i32 4
  %t80 = load ptr, ptr %t79, !tbaa !29
  %t82 = icmp eq ptr %t80, null
  %t84 = xor i1 %t82, true
  store i1 %t84, ptr %l37, !tbaa !21
  br label %bb22
bb22:
  %t86 = load i1, ptr %l37, !tbaa !21
  br i1 %t86, label %bb23, label %bb24
bb23:
  %t87 = load ptr, ptr %l0, !tbaa !29
  store ptr %t87, ptr %l48, !tbaa !29
  %t88 = load ptr, ptr %l1, !tbaa !29
  %t90 = getelementptr %"compiler/typed:Match", ptr %t88, i32 0, i32 2
  %t91 = load ptr, ptr %t90, !tbaa !29
  %t93 = icmp eq ptr %t91, null
  br i1 %t93, label %bb25, label %bb26
bb24:
  store i1 false, ptr %l47, !tbaa !21
  br label %bb32
bb25:
  call void @__olang_check_failed(ptr @olang_loc_6cc454f6892da6e7_dc94ff52b1800ff3)
  unreachable
bb26:
  br label %bb27
bb27:
  %t95 = load ptr, ptr %l1, !tbaa !29
  %t97 = getelementptr %"compiler/typed:Match", ptr %t95, i32 0, i32 2
  %t98 = load ptr, ptr %t97, !tbaa !29
  %t101 = getelementptr %"compiler/typed:Arm", ptr %t98, i32 0, i32 4
  %t102 = load ptr, ptr %t101, !tbaa !29
  store ptr %t102, ptr %l6, !tbaa !29
  %t104 = load ptr, ptr %l6, !tbaa !29
  %t106 = icmp eq ptr %t104, null
  br i1 %t106, label %bb28, label %bb29
bb28:
  call void @__olang_check_failed(ptr @olang_loc_6cc454f6892da6e7_dc94ff52b1800ff3)
  unreachable
bb29:
  br label %bb30
bb30:
  %t108 = load ptr, ptr %l6, !tbaa !29
  %t109 = load ptr, ptr %l48, !tbaa !29
  %t111 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2ecopiesValue(ptr %v0, ptr %v1, ptr %t109, ptr %t108)
  store i1 %t111, ptr %l59
  br label %bb31
bb31:
  %t112 = load i1, ptr %l59, !tbaa !21
  store i1 %t112, ptr %l47, !tbaa !21
  br label %bb32
bb32:
  %t113 = load i1, ptr %l47, !tbaa !21
  store i1 %t113, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2emovesAtLastUse(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"compiler/typed:LastUses"
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l13 = alloca i1
  %l18 = alloca i1
  %l25 = alloca i64
  %l26 = alloca %"compiler/typed:LastUses"
  %l27 = alloca ptr
  %l37 = alloca i64
  %l41 = alloca i64
  %l44 = alloca i64
  %l64 = alloca i64
  %l67 = alloca i64
  %l69 = alloca i1
  %l70 = alloca { i64, ptr }
  %l72 = alloca i64
  %l75 = alloca i64
  %l77 = alloca i1
  %l78 = alloca ptr
  %l79 = alloca ptr
  %l80 = alloca i64
  %l83 = alloca i64
  %l84 = alloca i1
  %l87 = alloca ptr
  %l90 = alloca i64
  %l92 = alloca ptr
  %l95 = alloca i64
  %l98 = alloca ptr
  %l106 = alloca ptr
  %l111 = alloca ptr
  %l113 = alloca i64
  %l118 = alloca %"compiler/typed:Local"
  %l121 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %t36 = alloca %"compiler/typed:LastUses", align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 19
  %t4 = load i1, ptr %t3, !tbaa !21
  %t6 = xor i1 %t4, true
  br i1 %t6, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l13, !tbaa !21
  br label %bb3
bb2:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/lower:lowering", ptr %t8, i32 0, i32 1
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t13 = getelementptr %"compiler/typed:Body", ptr %t11, i32 0, i32 11
  %t14 = load ptr, ptr %t13, !tbaa !29
  %t16 = icmp eq ptr %t14, null
  store i1 %t16, ptr %l13, !tbaa !21
  br label %bb3
bb3:
  %t18 = load i1, ptr %l13, !tbaa !21
  br i1 %t18, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l18, !tbaa !21
  br label %bb6
bb5:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/lower:lowering", ptr %t19, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !29
  %t24 = getelementptr %"compiler/typed:Body", ptr %t22, i32 0, i32 14
  %t25 = load i1, ptr %t24, !tbaa !21
  store i1 %t25, ptr %l18, !tbaa !21
  br label %bb6
bb6:
  %t27 = load i1, ptr %l18, !tbaa !21
  br i1 %t27, label %bb7, label %bb8
bb7:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb8:
  br label %bb9
bb9:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/lower:lowering", ptr %t28, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !29
  %t33 = getelementptr %"compiler/typed:Body", ptr %t31, i32 0, i32 7
  %t35 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eLen_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t33)
  store i64 %t35, ptr %l25
  br label %bb10
bb10:
  %t37 = load i64, ptr %l25, !tbaa !24
  call void @compiler_2ftyped_3aLastUses_2ector(ptr %t36, ptr %s0, i64 %t37)
  call void @llvm.memmove.p0.p0.i64(ptr %l26, ptr %t36, i64 192, i1 false)
  br label %bb11
bb11:
  call void @llvm.memmove.p0.p0.i64(ptr %l2, ptr %l26, i64 192, i1 false)
  store ptr %l2, ptr %l27, !tbaa !29
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/lower:lowering", ptr %t38, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !29
  %t43 = getelementptr %"compiler/typed:Body", ptr %t41, i32 0, i32 11
  %t44 = load ptr, ptr %t43, !tbaa !29
  %t46 = icmp eq ptr %t44, null
  br i1 %t46, label %bb12, label %bb13
bb12:
  call void @__olang_check_failed(ptr @olang_loc_fb069b64d7548fb8_fd74029d8d87e6e4)
  unreachable
bb13:
  br label %bb14
bb14:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/lower:lowering", ptr %t48, i32 0, i32 1
  %t51 = load ptr, ptr %t50, !tbaa !29
  %t53 = getelementptr %"compiler/typed:Body", ptr %t51, i32 0, i32 11
  %t54 = load ptr, ptr %t53, !tbaa !29
  %t56 = load ptr, ptr %l27, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eBlock(ptr %s0, ptr %v0, ptr %t56, ptr %t54)
  br label %bb15
bb15:
  store i64 0, ptr %l3, !tbaa !24
  %t58 = getelementptr %"compiler/typed:LastUses", ptr %l2, i32 0, i32 6
  %t60 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t58)
  store i64 %t60, ptr %l37
  br label %bb16
bb16:
  %t61 = load i64, ptr %l37, !tbaa !24
  store i64 %t61, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t62 = load i64, ptr %l4, !tbaa !24
  %t63 = load i64, ptr %l3, !tbaa !24
  %t66 = icmp sgt i64 %t62, %t63
  br i1 %t66, label %bb17, label %bb18
bb17:
  %t68 = load i64, ptr %l5, !tbaa !24
  %t70 = icmp sgt i64 %t68, 0
  br i1 %t70, label %bb19, label %bb20
bb18:
  store i64 0, ptr %l41, !tbaa !24
  br label %bb22
bb19:
  %t72 = load i64, ptr %l4, !tbaa !24
  %t73 = load i64, ptr %l3, !tbaa !24
  %t76 = sub i64 %t72, %t73
  %t77 = load i64, ptr %l5, !tbaa !24
  %t80 = add i64 %t76, %t77
  %t82 = sub i64 %t80, 1
  %t83 = load i64, ptr %l5, !tbaa !24
  %t86 = sdiv i64 %t82, %t83
  store i64 %t86, ptr %l44, !tbaa !24
  br label %bb21
bb20:
  store i64 0, ptr %l44, !tbaa !24
  br label %bb21
bb21:
  %t88 = load i64, ptr %l44, !tbaa !24
  store i64 %t88, ptr %l41, !tbaa !24
  br label %bb22
bb22:
  %t89 = load i64, ptr %l41, !tbaa !24
  store i64 %t89, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb23
bb23:
  %t90 = load i64, ptr %l7, !tbaa !24
  %t91 = load i64, ptr %l6, !tbaa !24
  %t94 = icmp slt i64 %t90, %t91
  %t96 = xor i1 %t94, true
  br i1 %t96, label %bb24, label %bb25
bb24:
  br label %bb52
bb25:
  br label %bb26
bb26:
  %t98 = load i64, ptr %l3, !tbaa !24
  %t99 = load i64, ptr %l7, !tbaa !24
  %t100 = load i64, ptr %l5, !tbaa !24
  %t103 = mul i64 %t99, %t100
  %t106 = add i64 %t98, %t103
  store i64 %t106, ptr %l8, !tbaa !24
  %t108 = getelementptr %"compiler/typed:LastUses", ptr %l2, i32 0, i32 7
  %t109 = load i64, ptr %l8, !tbaa !24
  %t112 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t108, i64 %t109)
  store i64 %t112, ptr %l64
  br label %bb27
bb27:
  %t113 = load i64, ptr %l64, !tbaa !24
  store i64 %t113, ptr %l9, !tbaa !24
  %t114 = getelementptr %"compiler/typed:LastUses", ptr %l2, i32 0, i32 8
  %t115 = load i64, ptr %l8, !tbaa !24
  %t118 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t114, i64 %t115)
  store i64 %t118, ptr %l67
  br label %bb28
bb28:
  %t119 = load i64, ptr %l67, !tbaa !24
  %t120 = icmp slt i64 %t119, 0
  br i1 %t120, label %bb29, label %bb30
bb29:
  store i1 true, ptr %l69, !tbaa !21
  br label %bb32
bb30:
  %t122 = getelementptr %"compiler/typed:LastUses", ptr %l2, i32 0, i32 1
  %t123 = load { i64, ptr }, ptr %t122, !tbaa !27
  store { i64, ptr } %t123, ptr %l70, !tbaa !27
  %t124 = load i64, ptr %l9, !tbaa !24
  %t126 = getelementptr { i64, ptr }, ptr %l70, i32 0, i32 1
  %t127 = load ptr, ptr %t126, !tbaa !27
  %t128 = getelementptr i64, ptr %t127, i64 %t124
  %t129 = load i64, ptr %t128, !tbaa !34
  store i64 %t129, ptr %l72, !tbaa !24
  %t130 = getelementptr %"compiler/typed:LastUses", ptr %l2, i32 0, i32 8
  %t131 = load i64, ptr %l8, !tbaa !24
  %t134 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t130, i64 %t131)
  store i64 %t134, ptr %l75
  br label %bb31
bb31:
  %t135 = load i64, ptr %l72, !tbaa !24
  %t136 = load i64, ptr %l75, !tbaa !24
  %t137 = icmp ne i64 %t135, %t136
  store i1 %t137, ptr %l69, !tbaa !21
  br label %bb32
bb32:
  %t139 = load i1, ptr %l69, !tbaa !21
  br i1 %t139, label %bb33, label %bb34
bb33:
  store i1 true, ptr %l77, !tbaa !21
  br label %bb37
bb34:
  %t140 = load ptr, ptr %l0, !tbaa !29
  store ptr %t140, ptr %l78, !tbaa !29
  store ptr %a1, ptr %l79, !tbaa !29
  %t142 = load i64, ptr %l9, !tbaa !24
  store i64 %t142, ptr %l80, !tbaa !24
  %t143 = getelementptr %"compiler/typed:LastUses", ptr %l2, i32 0, i32 6
  %t144 = load i64, ptr %l8, !tbaa !24
  %t147 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t143, i64 %t144)
  store i64 %t147, ptr %l83
  br label %bb35
bb35:
  %t148 = load ptr, ptr %l78, !tbaa !29
  %t149 = load ptr, ptr %l79, !tbaa !29
  %t150 = load i64, ptr %l80, !tbaa !24
  %t151 = load i64, ptr %l83, !tbaa !24
  %t152 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2emovable(ptr %v0, ptr %v1, ptr %t148, ptr %t149, i64 %t150, i64 %t151)
  store i1 %t152, ptr %l84
  br label %bb36
bb36:
  %t153 = load i1, ptr %l84, !tbaa !21
  %t154 = xor i1 %t153, true
  store i1 %t154, ptr %l77, !tbaa !21
  br label %bb37
bb37:
  %t156 = load i1, ptr %l77, !tbaa !21
  br i1 %t156, label %bb38, label %bb39
bb38:
  br label %bb51
bb39:
  br label %bb40
bb40:
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t159 = getelementptr %"compiler/lower:lowering", ptr %t157, i32 0, i32 35
  store ptr %t159, ptr %l87, !tbaa !29
  %t160 = getelementptr %"compiler/typed:LastUses", ptr %l2, i32 0, i32 6
  %t161 = load i64, ptr %l8, !tbaa !24
  %t164 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t160, i64 %t161)
  store i64 %t164, ptr %l90
  br label %bb41
bb41:
  %t165 = load ptr, ptr %l87, !tbaa !29
  %t166 = load i64, ptr %l90, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t165, i64 %t166, i1 true)
  br label %bb42
bb42:
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t169 = getelementptr %"compiler/lower:lowering", ptr %t167, i32 0, i32 46
  store ptr %t169, ptr %l92, !tbaa !29
  %t170 = getelementptr %"compiler/typed:LastUses", ptr %l2, i32 0, i32 6
  %t171 = load i64, ptr %l8, !tbaa !24
  %t174 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t170, i64 %t171)
  store i64 %t174, ptr %l95
  br label %bb43
bb43:
  %t175 = load i64, ptr %l9, !tbaa !24
  %t176 = load ptr, ptr %l92, !tbaa !29
  %t177 = load i64, ptr %l95, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t176, i64 %t177, i64 %t175)
  br label %bb44
bb44:
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t181 = getelementptr %"compiler/lower:lowering", ptr %t179, i32 0, i32 0
  %t182 = load ptr, ptr %t181, !tbaa !29
  store ptr %t182, ptr %l98, !tbaa !29
  %t183 = load ptr, ptr %l98, !tbaa !29
  %t184 = getelementptr %"compiler/lower:Lowerer", ptr %t183, i32 0, i32 26
  %t185 = load i64, ptr %t184, !tbaa !24
  %t187 = add i64 %t185, 1
  %t189 = load ptr, ptr %l98, !tbaa !29
  %t190 = getelementptr %"compiler/lower:Lowerer", ptr %t189, i32 0, i32 26
  store i64 %t187, ptr %t190, !tbaa !24
  %t191 = load ptr, ptr %l0, !tbaa !29
  %t193 = getelementptr %"compiler/lower:lowering", ptr %t191, i32 0, i32 0
  %t194 = load ptr, ptr %t193, !tbaa !29
  %t196 = getelementptr %"compiler/lower:Lowerer", ptr %t194, i32 0, i32 30
  %t197 = load i1, ptr %t196, !tbaa !21
  br i1 %t197, label %bb45, label %bb46
bb45:
  store %olang.scope zeroinitializer, ptr %s5
  %t199 = load ptr, ptr %l0, !tbaa !29
  %t201 = getelementptr %"compiler/lower:lowering", ptr %t199, i32 0, i32 0
  %t202 = load ptr, ptr %t201, !tbaa !29
  %t204 = getelementptr %"compiler/lower:Lowerer", ptr %t202, i32 0, i32 31
  store ptr %t204, ptr %l106, !tbaa !29
  %t205 = load ptr, ptr %l0, !tbaa !29
  %t207 = getelementptr %"compiler/lower:lowering", ptr %t205, i32 0, i32 0
  %t208 = load ptr, ptr %t207, !tbaa !29
  %t210 = getelementptr %"compiler/lower:Lowerer", ptr %t208, i32 0, i32 0
  %t211 = load ptr, ptr %t210, !tbaa !29
  %t213 = getelementptr %"compiler/generic:Program", ptr %t211, i32 0, i32 0
  %t214 = load ptr, ptr %t213, !tbaa !29
  %t216 = getelementptr %"compiler/load:Loader", ptr %t214, i32 0, i32 4
  %t217 = load ptr, ptr %t216, !tbaa !29
  store ptr %t217, ptr %l111, !tbaa !29
  %t218 = load ptr, ptr %l0, !tbaa !29
  %t220 = getelementptr %"compiler/lower:lowering", ptr %t218, i32 0, i32 4
  %t221 = load i64, ptr %t220, !tbaa !24
  store i64 %t221, ptr %l113, !tbaa !24
  %t222 = load ptr, ptr %l0, !tbaa !29
  %t224 = getelementptr %"compiler/lower:lowering", ptr %t222, i32 0, i32 1
  %t225 = load ptr, ptr %t224, !tbaa !29
  %t227 = getelementptr %"compiler/typed:Body", ptr %t225, i32 0, i32 7
  %t228 = load i64, ptr %l9, !tbaa !24
  %t231 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t227, i64 %t228)
  store %"compiler/typed:Local" %t231, ptr %l118
  br label %bb47
bb46:
  br label %bb50
bb47:
  %t232 = getelementptr %"compiler/typed:Local", ptr %l118, i32 0, i32 1
  %t233 = getelementptr %"compiler/source:Span", ptr %t232, i32 0, i32 0
  %t234 = load i32, ptr %t233, !tbaa !23
  %t236 = sext i32 %t234 to i64
  %t237 = load ptr, ptr %l111, !tbaa !29
  %t238 = load i64, ptr %l113, !tbaa !24
  %t240 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLocate(ptr %v0, ptr %s5, ptr %t237, i64 %t238, i64 %t236)
  store { i64, ptr } %t240, ptr %l121
  br label %bb48
bb48:
  %t241 = load i64, ptr %l9, !tbaa !24
  %t242 = load { i64, ptr }, ptr %l121, !tbaa !27
  %t243 = extractvalue { i64, ptr } %t242, 1
  %t244 = extractvalue { i64, ptr } %t242, 0
  %t245 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d4, i32 0, i32 1) }, 1
  %t246 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d4, i32 0, i32 1) }, 0
  %t247 = add i64 %t244, %t246
  %t249 = call i64 @__olang_fmt_i64(ptr null, i64 %t241)
  %t250 = add i64 %t247, %t249
  %t251 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d5, i32 0, i32 1) }, 1
  %t252 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d5, i32 0, i32 1) }, 0
  %t253 = add i64 %t250, %t252
  %t254 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t253)
  call void @olang_textcopy(ptr %t254, ptr %t243, i64 %t244)
  %t255 = getelementptr i8, ptr %t254, i64 %t244
  call void @olang_textcopy(ptr %t255, ptr %t245, i64 %t246)
  %t256 = getelementptr i8, ptr %t255, i64 %t246
  %t257 = call i64 @__olang_fmt_i64(ptr %t256, i64 %t241)
  %t258 = getelementptr i8, ptr %t256, i64 %t249
  call void @olang_textcopy(ptr %t258, ptr %t251, i64 %t252)
  %t259 = insertvalue { i64, ptr } undef, i64 %t253, 0
  %t260 = insertvalue { i64, ptr } %t259, ptr %t254, 1
  %t262 = extractvalue { i64, ptr } %t260, 0
  %t263 = extractvalue { i64, ptr } %t260, 1
  %t264 = mul i64 %t262, 1
  %t265 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t264)
  call void @llvm.memcpy.p0.p0.i64(ptr %t265, ptr %t263, i64 %t264, i1 false)
  %t266 = insertvalue { i64, ptr } undef, i64 %t262, 0
  %t267 = insertvalue { i64, ptr } %t266, ptr %t265, 1
  %t268 = load ptr, ptr %l106, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v0, ptr %t268, { i64, ptr } %t267)
  br label %bb49
bb49:
  call void @__olang_scope_close(ptr %s5)
  br label %bb50
bb50:
  br label %bb51
bb51:
  %t270 = load i64, ptr %l7, !tbaa !24
  %t272 = add i64 %t270, 1
  store i64 %t272, ptr %l7, !tbaa !24
  br label %bb23
bb52:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2flower_2ecompiler_2flower_3alowering_2eneverNullPath(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i32
  %l12 = alloca { i64, ptr }
  %lp13 = alloca ptr
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l24 = alloca i1
  %l27 = alloca i1
  %l34 = alloca { i64, ptr }
  %l40 = alloca i64
  %l43 = alloca i64
  %l65 = alloca i1
  %l66 = alloca i1
  %l69 = alloca i1
  %l71 = alloca i1
  %l72 = alloca ptr
  %l75 = alloca i32
  %l76 = alloca i32
  %l80 = alloca [1 x i64]
  %l81 = alloca { i64, ptr }
  %l84 = alloca i1
  %l85 = alloca i1
  %l86 = alloca ptr
  %l89 = alloca i32
  %l90 = alloca i32
  %l97 = alloca { i64, ptr }
  %l103 = alloca i64
  %l113 = alloca i64
  %l116 = alloca i64
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t6 = load i64, ptr %l2, !tbaa !24
  %t8 = icmp sgt i64 %t6, 8
  br i1 %t8, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l24, !tbaa !21
  br label %bb4
bb2:
  %t10 = load ptr, ptr %l3, !tbaa !29
  %t11 = load i32, ptr %l1, !tbaa !23
  %t14 = call i1 @compiler_2fmir_2eHasFields(ptr %v0, ptr %t10, i32 %t11)
  store i1 %t14, ptr %l27
  br label %bb3
bb3:
  %t15 = load i1, ptr %l27, !tbaa !21
  %t16 = xor i1 %t15, true
  store i1 %t16, ptr %l24, !tbaa !21
  br label %bb4
bb4:
  %t18 = load i1, ptr %l24, !tbaa !21
  br i1 %t18, label %bb5, label %bb6
bb5:
  %t19 = icmp sge i64 0, 0
  br i1 %t19, label %bb7, label %bb8
bb6:
  br label %bb11
bb7:
  %t21 = icmp sle i64 0, 1152921504606846975
  br i1 %t21, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_f84e287748fb5e0c_a7fab5dda1d7c518)
  unreachable
bb9:
  %t23 = mul i64 0, 8
  %t24 = insertvalue { i64, ptr } undef, i64 0, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t25, ptr %rv
  br label %ret
bb10:
  call void @__olang_check_failed(ptr @olang_loc_f84e287748fb5e0c_a7fab5dda1d7c518)
  unreachable
bb11:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load i32, ptr %l1, !tbaa !23
  %t31 = call { i64, ptr } @compiler_2flower_2ecompiler_2flower_3alowering_2epartsOf(ptr %v0, ptr %s0, ptr %t27, i32 %t28)
  store { i64, ptr } %t31, ptr %l34
  br label %bb12
bb12:
  %t32 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t32, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t33 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t35 = extractvalue { i64, ptr } %t33, 0
  store i64 %t35, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t37 = load i64, ptr %l6, !tbaa !24
  %t38 = load i64, ptr %l5, !tbaa !24
  %t41 = icmp sgt i64 %t37, %t38
  br i1 %t41, label %bb13, label %bb14
bb13:
  %t43 = load i64, ptr %l7, !tbaa !24
  %t45 = icmp sgt i64 %t43, 0
  br i1 %t45, label %bb15, label %bb16
bb14:
  store i64 0, ptr %l40, !tbaa !24
  br label %bb18
bb15:
  %t47 = load i64, ptr %l6, !tbaa !24
  %t48 = load i64, ptr %l5, !tbaa !24
  %t51 = sub i64 %t47, %t48
  %t52 = load i64, ptr %l7, !tbaa !24
  %t55 = add i64 %t51, %t52
  %t57 = sub i64 %t55, 1
  %t58 = load i64, ptr %l7, !tbaa !24
  %t61 = sdiv i64 %t57, %t58
  store i64 %t61, ptr %l43, !tbaa !24
  br label %bb17
bb16:
  store i64 0, ptr %l43, !tbaa !24
  br label %bb17
bb17:
  %t63 = load i64, ptr %l43, !tbaa !24
  store i64 %t63, ptr %l40, !tbaa !24
  br label %bb18
bb18:
  %t64 = load i64, ptr %l40, !tbaa !24
  store i64 %t64, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb19
bb19:
  store %olang.scope zeroinitializer, ptr %s3
  %t65 = load i64, ptr %l9, !tbaa !24
  %t66 = load i64, ptr %l8, !tbaa !24
  %t69 = icmp slt i64 %t65, %t66
  %t71 = xor i1 %t69, true
  br i1 %t71, label %bb20, label %bb21
bb20:
  call void @__olang_scope_close(ptr %s3)
  br label %bb66
bb21:
  br label %bb22
bb22:
  %t73 = load i64, ptr %l5, !tbaa !24
  %t74 = load i64, ptr %l9, !tbaa !24
  %t75 = load i64, ptr %l7, !tbaa !24
  %t78 = mul i64 %t74, %t75
  %t81 = add i64 %t73, %t78
  store i64 %t81, ptr %l10, !tbaa !24
  %t83 = load i64, ptr %l10, !tbaa !24
  %t85 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t86 = load ptr, ptr %t85, !tbaa !27
  %t87 = getelementptr i32, ptr %t86, i64 %t83
  %t88 = load i32, ptr %t87, !tbaa !33
  store i32 %t88, ptr %l11, !tbaa !23
  %t90 = load ptr, ptr %l3, !tbaa !29
  %t91 = load i32, ptr %l11, !tbaa !23
  %t94 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t90, i32 %t91)
  store i1 %t94, ptr %l65
  br label %bb23
bb23:
  %t95 = load i1, ptr %l65, !tbaa !21
  br i1 %t95, label %bb24, label %bb25
bb24:
  %t96 = load ptr, ptr %l3, !tbaa !29
  %t97 = load i32, ptr %l11, !tbaa !23
  %t100 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNullable(ptr %v0, ptr %t96, i32 %t97)
  store i1 %t100, ptr %l69
  br label %bb26
bb25:
  store i1 false, ptr %l66, !tbaa !21
  br label %bb27
bb26:
  %t101 = load i1, ptr %l69, !tbaa !21
  %t102 = xor i1 %t101, true
  store i1 %t102, ptr %l66, !tbaa !21
  br label %bb27
bb27:
  %t104 = load i1, ptr %l66, !tbaa !21
  br i1 %t104, label %bb28, label %bb29
bb28:
  %t105 = load ptr, ptr %l0, !tbaa !29
  store ptr %t105, ptr %l72, !tbaa !29
  %t106 = load ptr, ptr %l3, !tbaa !29
  %t107 = load i32, ptr %l11, !tbaa !23
  %t110 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t106, i32 %t107)
  store i32 %t110, ptr %l75
  br label %bb30
bb29:
  store i1 false, ptr %l71, !tbaa !21
  br label %bb32
bb30:
  %t111 = load ptr, ptr %l72, !tbaa !29
  %t112 = load i32, ptr %l75, !tbaa !23
  %t113 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2earrayOf(ptr %v0, ptr %t111, i32 %t112)
  store i32 %t113, ptr %l76
  br label %bb31
bb31:
  %t114 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t115 = load i32, ptr %l76, !tbaa !23
  %t117 = icmp eq i32 %t115, %t114
  store i1 %t117, ptr %l71, !tbaa !21
  br label %bb32
bb32:
  %t119 = load i1, ptr %l71, !tbaa !21
  br i1 %t119, label %bb33, label %bb34
bb33:
  %t120 = load i64, ptr %l10, !tbaa !24
  %t122 = insertvalue [1 x i64] undef, i64 %t120, 0
  store [1 x i64] %t122, ptr %l80
  %t123 = mul i64 1, 8
  %t124 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t123)
  %t125 = insertvalue { i64, ptr } undef, i64 1, 0
  %t126 = insertvalue { i64, ptr } %t125, ptr %t124, 1
  store { i64, ptr } %t126, ptr %l81, !tbaa !27
  %t127 = getelementptr { i64, ptr }, ptr %l81, i32 0, i32 1
  %t128 = load ptr, ptr %t127, !tbaa !27
  %t129 = mul i64 1, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t128, ptr %l80, i64 %t129, i1 false)
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t130 = load { i64, ptr }, ptr %l81, !tbaa !27
  store { i64, ptr } %t130, ptr %rv
  br label %ret
bb34:
  br label %bb35
bb35:
  %t131 = load ptr, ptr %l3, !tbaa !29
  %t132 = load i32, ptr %l11, !tbaa !23
  %t135 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t131, i32 %t132)
  store i1 %t135, ptr %l84
  br label %bb36
bb36:
  %t136 = load i1, ptr %l84, !tbaa !21
  br i1 %t136, label %bb37, label %bb38
bb37:
  store i1 true, ptr %l85, !tbaa !21
  br label %bb41
bb38:
  %t137 = load ptr, ptr %l3, !tbaa !29
  store ptr %t137, ptr %l86, !tbaa !29
  %t138 = load ptr, ptr %l3, !tbaa !29
  %t139 = load i32, ptr %l11, !tbaa !23
  %t142 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t138, i32 %t139)
  store i32 %t142, ptr %l89
  br label %bb39
bb39:
  %t143 = load ptr, ptr %l86, !tbaa !29
  %t144 = load i32, ptr %l89, !tbaa !23
  %t145 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t143, i32 %t144)
  store i32 %t145, ptr %l90
  br label %bb40
bb40:
  %t146 = load i32, ptr %l90, !range !{i32 0, i32 33}
  %t148 = trunc i64 21 to i32
  %t149 = icmp eq i32 %t146, %t148
  store i1 %t149, ptr %l85, !tbaa !21
  br label %bb41
bb41:
  %t151 = load i1, ptr %l85, !tbaa !21
  br i1 %t151, label %bb42, label %bb43
bb42:
  call void @__olang_scope_close(ptr %s3)
  br label %bb65
bb43:
  br label %bb44
bb44:
  %t152 = load ptr, ptr %l0, !tbaa !29
  %t153 = load i32, ptr %l11, !tbaa !23
  %t154 = load i64, ptr %l2, !tbaa !24
  %t156 = add i64 %t154, 1
  %t160 = call { i64, ptr } @compiler_2flower_2ecompiler_2flower_3alowering_2eneverNullPath(ptr %v0, ptr %s3, ptr %t152, i32 %t153, i64 %t156)
  store { i64, ptr } %t160, ptr %l97
  br label %bb45
bb45:
  %t161 = load { i64, ptr }, ptr %l97, !tbaa !27
  store { i64, ptr } %t161, ptr %l12, !tbaa !27
  %t162 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t164 = extractvalue { i64, ptr } %t162, 0
  %t166 = icmp eq i64 %t164, 0
  br i1 %t166, label %bb46, label %bb47
bb46:
  call void @__olang_scope_close(ptr %s3)
  br label %bb65
bb47:
  br label %bb48
bb48:
  %t168 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t170 = extractvalue { i64, ptr } %t168, 0
  %t172 = add i64 %t170, 1
  store i64 %t172, ptr %l103, !tbaa !24
  %t173 = load i64, ptr %l103, !tbaa !24
  %t174 = icmp sge i64 %t173, 0
  br i1 %t174, label %bb49, label %bb50
bb49:
  %t176 = load i64, ptr %l103, !tbaa !24
  %t177 = icmp sle i64 %t176, 1152921504606846975
  br i1 %t177, label %bb51, label %bb52
bb50:
  call void @__olang_check_failed(ptr @olang_loc_3175700f57e01d19_45cf7091add0d985)
  unreachable
bb51:
  %t179 = load i64, ptr %l103, !tbaa !24
  %t180 = mul i64 %t179, 8
  %t181 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t180)
  %t182 = insertvalue { i64, ptr } undef, i64 %t179, 0
  %t183 = insertvalue { i64, ptr } %t182, ptr %t181, 1
  %t184 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t184, ptr %lp13
  %t186 = load ptr, ptr %lp13
  store { i64, ptr } %t183, ptr %t186, !tbaa !27
  %t187 = load i64, ptr %l10, !tbaa !24
  %t189 = load ptr, ptr %lp13
  %t190 = getelementptr { i64, ptr }, ptr %t189, i32 0, i32 1
  %t191 = load ptr, ptr %t190, !tbaa !27
  %t192 = getelementptr i64, ptr %t191, i64 0
  store i64 %t187, ptr %t192, !tbaa !34
  store i64 0, ptr %l14, !tbaa !24
  %t193 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t195 = extractvalue { i64, ptr } %t193, 0
  store i64 %t195, ptr %l15, !tbaa !24
  store i64 1, ptr %l16, !tbaa !24
  %t197 = load i64, ptr %l15, !tbaa !24
  %t198 = load i64, ptr %l14, !tbaa !24
  %t201 = icmp sgt i64 %t197, %t198
  br i1 %t201, label %bb53, label %bb54
bb52:
  call void @__olang_check_failed(ptr @olang_loc_3175700f57e01d19_45cf7091add0d985)
  unreachable
bb53:
  %t203 = load i64, ptr %l16, !tbaa !24
  %t205 = icmp sgt i64 %t203, 0
  br i1 %t205, label %bb55, label %bb56
bb54:
  store i64 0, ptr %l113, !tbaa !24
  br label %bb58
bb55:
  %t207 = load i64, ptr %l15, !tbaa !24
  %t208 = load i64, ptr %l14, !tbaa !24
  %t211 = sub i64 %t207, %t208
  %t212 = load i64, ptr %l16, !tbaa !24
  %t215 = add i64 %t211, %t212
  %t217 = sub i64 %t215, 1
  %t218 = load i64, ptr %l16, !tbaa !24
  %t221 = sdiv i64 %t217, %t218
  store i64 %t221, ptr %l116, !tbaa !24
  br label %bb57
bb56:
  store i64 0, ptr %l116, !tbaa !24
  br label %bb57
bb57:
  %t223 = load i64, ptr %l116, !tbaa !24
  store i64 %t223, ptr %l113, !tbaa !24
  br label %bb58
bb58:
  %t224 = load i64, ptr %l113, !tbaa !24
  store i64 %t224, ptr %l17, !tbaa !24
  store i64 0, ptr %l18, !tbaa !24
  br label %bb59
bb59:
  %t225 = load i64, ptr %l18, !tbaa !24
  %t226 = load i64, ptr %l17, !tbaa !24
  %t229 = icmp slt i64 %t225, %t226
  %t231 = xor i1 %t229, true
  br i1 %t231, label %bb60, label %bb61
bb60:
  br label %bb64
bb61:
  br label %bb62
bb62:
  %t233 = load i64, ptr %l14, !tbaa !24
  %t234 = load i64, ptr %l18, !tbaa !24
  %t235 = load i64, ptr %l16, !tbaa !24
  %t238 = mul i64 %t234, %t235
  %t241 = add i64 %t233, %t238
  store i64 %t241, ptr %l19, !tbaa !24
  %t243 = load i64, ptr %l19, !tbaa !24
  %t245 = add i64 %t243, 1
  %t246 = load i64, ptr %l19, !tbaa !24
  %t248 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t249 = load ptr, ptr %t248, !tbaa !27
  %t250 = getelementptr i64, ptr %t249, i64 %t246
  %t251 = load i64, ptr %t250, !tbaa !34
  %t253 = load ptr, ptr %lp13
  %t255 = getelementptr { i64, ptr }, ptr %t253, i32 0, i32 1
  %t256 = load ptr, ptr %t255, !tbaa !27
  %t257 = getelementptr i64, ptr %t256, i64 %t245
  store i64 %t251, ptr %t257, !tbaa !34
  br label %bb63
bb63:
  %t258 = load i64, ptr %l18, !tbaa !24
  %t260 = add i64 %t258, 1
  store i64 %t260, ptr %l18, !tbaa !24
  br label %bb59
bb64:
  %t262 = load ptr, ptr %lp13
  %t263 = load { i64, ptr }, ptr %t262, !tbaa !27
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t263, ptr %rv
  br label %ret
bb65:
  %t265 = load i64, ptr %l9, !tbaa !24
  %t267 = add i64 %t265, 1
  store i64 %t267, ptr %l9, !tbaa !24
  br label %bb19
bb66:
  %t269 = icmp sge i64 0, 0
  br i1 %t269, label %bb67, label %bb68
bb67:
  %t271 = icmp sle i64 0, 1152921504606846975
  br i1 %t271, label %bb69, label %bb70
bb68:
  call void @__olang_check_failed(ptr @olang_loc_579e7356b043c39a_4d305c4fde145a66)
  unreachable
bb69:
  %t273 = mul i64 0, 8
  %t274 = insertvalue { i64, ptr } undef, i64 0, 0
  %t275 = insertvalue { i64, ptr } %t274, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t275, ptr %rv
  br label %ret
bb70:
  call void @__olang_check_failed(ptr @olang_loc_579e7356b043c39a_4d305c4fde145a66)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @compiler_2flower_2ecompiler_2flower_3alowering_2eobjectOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca ptr
  %l9 = alloca i1
  %l15 = alloca ptr
  %l16 = alloca i1
  %l23 = alloca i32
  %l24 = alloca ptr
  %l25 = alloca i1
  %l33 = alloca i32
  %l34 = alloca ptr
  %l35 = alloca i1
  %l43 = alloca i32
  %l44 = alloca ptr
  %l45 = alloca i1
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t2 = load ptr, ptr %l8, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l8, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l9, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l9, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load i32, ptr %l2, !tbaa !23
  store i32 %t16, ptr %l7, !tbaa !23
  br label %bb38
bb6:
  %t18 = load ptr, ptr %l1, !tbaa !29
  store ptr %t18, ptr %l15, !tbaa !29
  store i1 false, ptr %l16, !tbaa !21
  %t19 = load ptr, ptr %l15, !tbaa !29
  %t20 = icmp ne ptr %t19, null
  br i1 %t20, label %bb7, label %bb8
bb7:
  %t22 = load ptr, ptr %l15, !tbaa !29
  %t23 = load i64, ptr %t22, !range !{i64 0, i64 8}
  %t25 = icmp eq i64 %t23, 3
  store i1 %t25, ptr %l16, !tbaa !21
  br label %bb8
bb8:
  %t26 = load i1, ptr %l16, !tbaa !21
  br i1 %t26, label %bb9, label %bb10
bb9:
  %t27 = load ptr, ptr %l1, !tbaa !29
  %t29 = getelementptr { i64, [4 x i64] }, ptr %t27, i32 0, i32 1
  %t30 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t29, i32 0, i32 2
  %t31 = load ptr, ptr %t30
  store ptr %t31, ptr %l3, !tbaa !29
  br label %bb11
bb10:
  br label %bb13
bb11:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t34 = load ptr, ptr %l3, !tbaa !29
  %t37 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2eobjectOf(ptr %v0, ptr %v1, ptr %t33, ptr %t34)
  store i32 %t37, ptr %l23
  br label %bb12
bb12:
  %t38 = load i32, ptr %l23, !tbaa !23
  store i32 %t38, ptr %l7, !tbaa !23
  br label %bb38
bb13:
  %t39 = load ptr, ptr %l1, !tbaa !29
  store ptr %t39, ptr %l24, !tbaa !29
  store i1 false, ptr %l25, !tbaa !21
  %t40 = load ptr, ptr %l24, !tbaa !29
  %t41 = icmp ne ptr %t40, null
  br i1 %t41, label %bb14, label %bb15
bb14:
  %t43 = load ptr, ptr %l24, !tbaa !29
  %t44 = load i64, ptr %t43, !range !{i64 0, i64 8}
  %t46 = icmp eq i64 %t44, 4
  store i1 %t46, ptr %l25, !tbaa !21
  br label %bb15
bb15:
  %t47 = load i1, ptr %l25, !tbaa !21
  br i1 %t47, label %bb16, label %bb17
bb16:
  %t48 = load ptr, ptr %l1, !tbaa !29
  %t50 = getelementptr { i64, [4 x i64] }, ptr %t48, i32 0, i32 1
  %t51 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t50, i32 0, i32 2
  %t52 = load ptr, ptr %t51
  store ptr %t52, ptr %l4, !tbaa !29
  br label %bb18
bb17:
  br label %bb20
bb18:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t55 = load ptr, ptr %l4, !tbaa !29
  %t57 = getelementptr %"compiler/typed:Elem", ptr %t55, i32 0, i32 0
  %t58 = load ptr, ptr %t57, !tbaa !29
  %t61 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2eobjectOf(ptr %v0, ptr %v1, ptr %t54, ptr %t58)
  store i32 %t61, ptr %l33
  br label %bb19
bb19:
  %t62 = load i32, ptr %l33, !tbaa !23
  store i32 %t62, ptr %l7, !tbaa !23
  br label %bb38
bb20:
  %t63 = load ptr, ptr %l1, !tbaa !29
  store ptr %t63, ptr %l34, !tbaa !29
  store i1 false, ptr %l35, !tbaa !21
  %t64 = load ptr, ptr %l34, !tbaa !29
  %t65 = icmp ne ptr %t64, null
  br i1 %t65, label %bb21, label %bb22
bb21:
  %t67 = load ptr, ptr %l34, !tbaa !29
  %t68 = load i64, ptr %t67, !range !{i64 0, i64 8}
  %t70 = icmp eq i64 %t68, 5
  store i1 %t70, ptr %l35, !tbaa !21
  br label %bb22
bb22:
  %t71 = load i1, ptr %l35, !tbaa !21
  br i1 %t71, label %bb23, label %bb24
bb23:
  %t72 = load ptr, ptr %l1, !tbaa !29
  %t74 = getelementptr { i64, [4 x i64] }, ptr %t72, i32 0, i32 1
  %t75 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t74, i32 0, i32 2
  %t76 = load ptr, ptr %t75
  store ptr %t76, ptr %l5, !tbaa !29
  br label %bb25
bb24:
  br label %bb27
bb25:
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t79 = load ptr, ptr %l5, !tbaa !29
  %t81 = getelementptr %"compiler/typed:Payload", ptr %t79, i32 0, i32 0
  %t82 = load ptr, ptr %t81, !tbaa !29
  %t85 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2eobjectOf(ptr %v0, ptr %v1, ptr %t78, ptr %t82)
  store i32 %t85, ptr %l43
  br label %bb26
bb26:
  %t86 = load i32, ptr %l43, !tbaa !23
  store i32 %t86, ptr %l7, !tbaa !23
  br label %bb38
bb27:
  %t87 = load ptr, ptr %l1, !tbaa !29
  store ptr %t87, ptr %l44, !tbaa !29
  store i1 false, ptr %l45, !tbaa !21
  %t88 = load ptr, ptr %l44, !tbaa !29
  %t89 = icmp ne ptr %t88, null
  br i1 %t89, label %bb28, label %bb29
bb28:
  %t91 = load ptr, ptr %l44, !tbaa !29
  %t92 = load i64, ptr %t91, !range !{i64 0, i64 8}
  %t94 = icmp eq i64 %t92, 2
  store i1 %t94, ptr %l45, !tbaa !21
  br label %bb29
bb29:
  %t95 = load i1, ptr %l45, !tbaa !21
  br i1 %t95, label %bb30, label %bb31
bb30:
  %t96 = load ptr, ptr %l1, !tbaa !29
  %t98 = getelementptr { i64, [4 x i64] }, ptr %t96, i32 0, i32 1
  %t99 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t98, i32 0, i32 1
  %t100 = load i32, ptr %t99
  store i32 %t100, ptr %l6, !tbaa !23
  br label %bb32
bb31:
  br label %bb33
bb32:
  %t102 = load i32, ptr %l6, !tbaa !23
  store i32 %t102, ptr %l7, !tbaa !23
  br label %bb38
bb33:
  br i1 true, label %bb34, label %bb35
bb34:
  br label %bb36
bb35:
  br label %bb37
bb36:
  %t104 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t104, ptr %l7, !tbaa !23
  br label %bb38
bb37:
  call void @__olang_check_failed(ptr @olang_loc_166f6c7f8536ecb_3daea1ccb6433847)
  unreachable
bb38:
  %t106 = load i32, ptr %l7, !tbaa !23
  store i32 %t106, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eownCopyOf(ptr %v0, ptr %a0, { i64, [4 x i64] } %a1, i32 %a2, { i64, [1 x i64] } %a3, %"compiler/source:Span" %a4, i1 %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [4 x i64] }
  %l2 = alloca i32
  %l3 = alloca { i64, [1 x i64] }
  %l4 = alloca %"compiler/source:Span"
  %l6 = alloca i32
  %l10 = alloca i1
  %l15 = alloca i1
  %l16 = alloca { i64, [4 x i64] }
  %l22 = alloca { i64, [4 x i64] }
  %l28 = alloca i32
  %l30 = alloca i1
  %l34 = alloca i1
  %l35 = alloca ptr
  %l36 = alloca i32
  %l37 = alloca i32
  %l38 = alloca ptr
  %l41 = alloca %"compiler/lower:pl"
  %l44 = alloca { i64, [4 x i64] }
  %l45 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l50 = alloca { i64, [4 x i64] }
  %l51 = alloca ptr
  %l52 = alloca i32
  %l53 = alloca i32
  %l54 = alloca ptr
  %l57 = alloca %"compiler/lower:pl"
  %l60 = alloca { i64, [4 x i64] }
  %l61 = alloca { i64, ptr }
  %l63 = alloca { i64, ptr }
  %l66 = alloca { i64, [4 x i64] }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i64, [4 x i64] }
  %t62 = alloca { i64, [2 x i64] }, align 8
  %t109 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store { i64, [4 x i64] } %a1, ptr %l1
  store i32 %a2, ptr %l2
  store { i64, [1 x i64] } %a3, ptr %l3
  store %"compiler/source:Span" %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i32, ptr %l2, !tbaa !23
  %t8 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOwnsParts(ptr %v0, ptr %t4, i32 %t5)
  store i1 %t8, ptr %l10
  br label %bb1
bb1:
  %t9 = load i1, ptr %l10, !tbaa !21
  %t10 = xor i1 %t9, true
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/lower:lowering", ptr %t12, i32 0, i32 2
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t16 = load i32, ptr %l2, !tbaa !23
  %t19 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOwnedPart(ptr %v0, ptr %t15, i32 %t16)
  store i1 %t19, ptr %l15
  br label %bb4
bb3:
  br label %bb9
bb4:
  %t20 = load i1, ptr %l15, !tbaa !21
  br i1 %t20, label %bb5, label %bb6
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load { i64, [4 x i64] }, ptr %l1
  %t23 = load i32, ptr %l2, !tbaa !23
  %t24 = load %"compiler/source:Span", ptr %l4
  %t25 = load { i64, [1 x i64] }, ptr %l3
  %t31 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2earrayCopy(ptr %v0, ptr %t21, { i64, [4 x i64] } %t22, i32 %t23, %"compiler/source:Span" %t24, { i64, [1 x i64] } %t25, i1 false)
  store { i64, [4 x i64] } %t31, ptr %l22
  br label %bb7
bb6:
  %t32 = load { i64, [4 x i64] }, ptr %l1
  store { i64, [4 x i64] } %t32, ptr %l16
  br label %bb8
bb7:
  %t34 = load { i64, [4 x i64] }, ptr %l22
  store { i64, [4 x i64] } %t34, ptr %l16
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s0)
  %t35 = load { i64, [4 x i64] }, ptr %l16
  store { i64, [4 x i64] } %t35, ptr %rv
  br label %ret
bb9:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t37 = load { i64, [4 x i64] }, ptr %l1
  %t38 = load i32, ptr %l2, !tbaa !23
  %t39 = load %"compiler/source:Span", ptr %l4
  %t44 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2elocal(ptr %v0, ptr %t36, { i64, [4 x i64] } %t37, i32 %t38, %"compiler/source:Span" %t39)
  store i32 %t44, ptr %l28
  br label %bb10
bb10:
  %t45 = load i32, ptr %l28, !tbaa !23
  store i32 %t45, ptr %l6, !tbaa !23
  br i1 %a5, label %bb11, label %bb12
bb11:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/lower:lowering", ptr %t48, i32 0, i32 2
  %t51 = load ptr, ptr %t50, !tbaa !29
  %t52 = load i32, ptr %l2, !tbaa !23
  %t55 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclaresCopy(ptr %v0, ptr %t51, i32 %t52)
  store i1 %t55, ptr %l34
  br label %bb13
bb12:
  store i1 false, ptr %l30, !tbaa !21
  br label %bb14
bb13:
  %t56 = load i1, ptr %l34, !tbaa !21
  store i1 %t56, ptr %l30, !tbaa !21
  br label %bb14
bb14:
  %t57 = load i1, ptr %l30, !tbaa !21
  br i1 %t57, label %bb15, label %bb16
bb15:
  store %olang.scope zeroinitializer, ptr %s2
  %t58 = load ptr, ptr %l0, !tbaa !29
  store ptr %t58, ptr %l35, !tbaa !29
  store i32 5, ptr %l36
  %t59 = load i32, ptr %l2, !tbaa !23
  store i32 %t59, ptr %l37, !tbaa !23
  %t60 = load ptr, ptr %l0, !tbaa !29
  store ptr %t60, ptr %l38, !tbaa !29
  %t61 = load i32, ptr %l6, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t62
  %t63 = getelementptr { i64, [2 x i64] }, ptr %t62, i32 0, i32 0
  store i64 1, ptr %t63
  %t65 = insertvalue { i32 } undef, i32 %t61, 0
  %t66 = getelementptr { i64, [2 x i64] }, ptr %t62, i32 0, i32 1
  store { i32 } %t65, ptr %t66
  %t67 = load { i64, [2 x i64] }, ptr %t62
  %t69 = call %"compiler/lower:pl" @compiler_2flower_3apl_2ector(ptr %s2, { i64, [2 x i64] } %t67)
  store %"compiler/lower:pl" %t69, ptr %l41
  br label %bb17
bb16:
  br label %bb20
bb17:
  %t70 = load i32, ptr %l2, !tbaa !23
  %t71 = load %"compiler/source:Span", ptr %l4
  %t72 = load ptr, ptr %l38, !tbaa !29
  %t73 = load %"compiler/lower:pl", ptr %l41
  %t76 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2erefTo(ptr %v0, ptr %s2, ptr %t72, %"compiler/lower:pl" %t73, i32 %t70, %"compiler/source:Span" %t71)
  store { i64, [4 x i64] } %t76, ptr %l44
  br label %bb18
bb18:
  %t77 = mul i64 1, 40
  %t78 = call ptr @__olang_scope_alloc_zeroed(ptr %s2, i64 %t77)
  %t79 = insertvalue { i64, ptr } undef, i64 1, 0
  %t80 = insertvalue { i64, ptr } %t79, ptr %t78, 1
  store { i64, ptr } %t80, ptr %l45, !tbaa !27
  %t81 = load { i64, [4 x i64] }, ptr %l44
  %t82 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t83 = load ptr, ptr %t82, !tbaa !27
  %t84 = getelementptr { i64, [4 x i64] }, ptr %t83, i64 0
  store { i64, [4 x i64] } %t81, ptr %t84
  %t85 = load { i64, [1 x i64] }, ptr %l3
  %t86 = mul i64 1, 16
  %t87 = call ptr @__olang_scope_alloc_zeroed(ptr %s2, i64 %t86)
  %t88 = insertvalue { i64, ptr } undef, i64 1, 0
  %t89 = insertvalue { i64, ptr } %t88, ptr %t87, 1
  store { i64, ptr } %t89, ptr %l47, !tbaa !27
  %t91 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t92 = load ptr, ptr %t91, !tbaa !27
  %t93 = getelementptr { i64, [1 x i64] }, ptr %t92, i64 0
  store { i64, [1 x i64] } %t85, ptr %t93
  %t94 = load i32, ptr %l2, !tbaa !23
  %t95 = load %"compiler/source:Span", ptr %l4
  %t96 = load ptr, ptr %l35, !tbaa !29
  %t97 = load i32, ptr %l36, !range !{i32 0, i32 8}
  %t98 = load i32, ptr %l37, !tbaa !23
  %t99 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t100 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t103 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ehelperCall(ptr %v0, ptr %s2, ptr %s2, ptr %t96, i32 %t97, i32 %t98, { i64, ptr } %t99, { i64, ptr } %t100, i32 %t94, %"compiler/source:Span" %t95)
  store { i64, [4 x i64] } %t103, ptr %l50
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t104 = load { i64, [4 x i64] }, ptr %l50
  store { i64, [4 x i64] } %t104, ptr %rv
  br label %ret
bb20:
  %t105 = load ptr, ptr %l0, !tbaa !29
  store ptr %t105, ptr %l51, !tbaa !29
  store i32 4, ptr %l52
  %t106 = load i32, ptr %l2, !tbaa !23
  store i32 %t106, ptr %l53, !tbaa !23
  %t107 = load ptr, ptr %l0, !tbaa !29
  store ptr %t107, ptr %l54, !tbaa !29
  %t108 = load i32, ptr %l6, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t109
  %t110 = getelementptr { i64, [2 x i64] }, ptr %t109, i32 0, i32 0
  store i64 1, ptr %t110
  %t112 = insertvalue { i32 } undef, i32 %t108, 0
  %t113 = getelementptr { i64, [2 x i64] }, ptr %t109, i32 0, i32 1
  store { i32 } %t112, ptr %t113
  %t114 = load { i64, [2 x i64] }, ptr %t109
  %t116 = call %"compiler/lower:pl" @compiler_2flower_3apl_2ector(ptr %s0, { i64, [2 x i64] } %t114)
  store %"compiler/lower:pl" %t116, ptr %l57
  br label %bb21
bb21:
  %t117 = load i32, ptr %l2, !tbaa !23
  %t118 = load %"compiler/source:Span", ptr %l4
  %t119 = load ptr, ptr %l54, !tbaa !29
  %t120 = load %"compiler/lower:pl", ptr %l57
  %t123 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2erefTo(ptr %v0, ptr %s0, ptr %t119, %"compiler/lower:pl" %t120, i32 %t117, %"compiler/source:Span" %t118)
  store { i64, [4 x i64] } %t123, ptr %l60
  br label %bb22
bb22:
  %t124 = mul i64 1, 40
  %t125 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t124)
  %t126 = insertvalue { i64, ptr } undef, i64 1, 0
  %t127 = insertvalue { i64, ptr } %t126, ptr %t125, 1
  store { i64, ptr } %t127, ptr %l61, !tbaa !27
  %t128 = load { i64, [4 x i64] }, ptr %l60
  %t129 = getelementptr { i64, ptr }, ptr %l61, i32 0, i32 1
  %t130 = load ptr, ptr %t129, !tbaa !27
  %t131 = getelementptr { i64, [4 x i64] }, ptr %t130, i64 0
  store { i64, [4 x i64] } %t128, ptr %t131
  %t132 = load { i64, [1 x i64] }, ptr %l3
  %t133 = mul i64 1, 16
  %t134 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t133)
  %t135 = insertvalue { i64, ptr } undef, i64 1, 0
  %t136 = insertvalue { i64, ptr } %t135, ptr %t134, 1
  store { i64, ptr } %t136, ptr %l63, !tbaa !27
  %t138 = getelementptr { i64, ptr }, ptr %l63, i32 0, i32 1
  %t139 = load ptr, ptr %t138, !tbaa !27
  %t140 = getelementptr { i64, [1 x i64] }, ptr %t139, i64 0
  store { i64, [1 x i64] } %t132, ptr %t140
  %t141 = load i32, ptr %l2, !tbaa !23
  %t142 = load %"compiler/source:Span", ptr %l4
  %t143 = load ptr, ptr %l51, !tbaa !29
  %t144 = load i32, ptr %l52, !range !{i32 0, i32 8}
  %t145 = load i32, ptr %l53, !tbaa !23
  %t146 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t147 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t150 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ehelperCall(ptr %v0, ptr %s0, ptr %s0, ptr %t143, i32 %t144, i32 %t145, { i64, ptr } %t146, { i64, ptr } %t147, i32 %t141, %"compiler/source:Span" %t142)
  store { i64, [4 x i64] } %t150, ptr %l66
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s0)
  %t151 = load { i64, [4 x i64] }, ptr %l66
  store { i64, [4 x i64] } %t151, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2epackedField(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/lower:pl" %a1, i32 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/lower:pl"
  %l2 = alloca i32
  %lp4 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca %"compiler/lower:pl"
  %l10 = alloca %"compiler/lower:pl"
  %l13 = alloca %"compiler/lower:pl"
  %l16 = alloca i1
  %l18 = alloca ptr
  %l22 = alloca i32
  %l23 = alloca i1
  %l25 = alloca i64
  %rv = alloca %"compiler/lower:pl"
  %t6 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/lower:pl" %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l7, !tbaa !29
  %t2 = load %"compiler/lower:pl", ptr %l1
  store %"compiler/lower:pl" %t2, ptr %l8
  %t4 = call %"compiler/lower:pl" @olang_2eHelperKind_2eCopy_2ecompiler_2flower_3apl(ptr %v2, ptr %l8)
  store %"compiler/lower:pl" %t4, ptr %l10
  br label %bb1
bb1:
  store { i64, [1 x i64] } zeroinitializer, ptr %t6
  %t7 = getelementptr { i64, [1 x i64] }, ptr %t6, i32 0, i32 0
  store i64 0, ptr %t7
  %t9 = insertvalue { i64 } undef, i64 %a3, 0
  %t10 = getelementptr { i64, [1 x i64] }, ptr %t6, i32 0, i32 1
  store { i64 } %t9, ptr %t10
  %t11 = load { i64, [1 x i64] }, ptr %t6
  %t12 = load ptr, ptr %l7, !tbaa !29
  %t13 = load %"compiler/lower:pl", ptr %l10
  %t15 = call %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2ewith(ptr %v0, ptr %v2, ptr %v2, ptr %t12, %"compiler/lower:pl" %t13, { i64, [1 x i64] } %t11)
  store %"compiler/lower:pl" %t15, ptr %l13
  br label %bb2
bb2:
  %t16 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 72, i64 8)
  store ptr %t16, ptr %lp4
  %t17 = load %"compiler/lower:pl", ptr %l13
  %t18 = load ptr, ptr %lp4
  store %"compiler/lower:pl" %t17, ptr %t18
  %t19 = load ptr, ptr %lp4
  %t20 = getelementptr %"compiler/lower:pl", ptr %t19, i32 0, i32 2
  %t21 = load i64, ptr %t20, !tbaa !24
  %t23 = icmp slt i64 %t21, 0
  br i1 %t23, label %bb3, label %bb4
bb3:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/lower:lowering", ptr %t25, i32 0, i32 2
  %t28 = load ptr, ptr %t27, !tbaa !29
  store ptr %t28, ptr %l18, !tbaa !29
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/lower:lowering", ptr %t29, i32 0, i32 2
  %t32 = load ptr, ptr %t31, !tbaa !29
  %t33 = load i32, ptr %l2, !tbaa !23
  %t36 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t32, i32 %t33)
  store i32 %t36, ptr %l22
  br label %bb5
bb4:
  store i1 false, ptr %l16, !tbaa !21
  br label %bb7
bb5:
  %t37 = load ptr, ptr %l18, !tbaa !29
  %t38 = load i32, ptr %l22, !tbaa !23
  %t39 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePacked(ptr %v0, ptr %t37, i32 %t38)
  store i1 %t39, ptr %l23
  br label %bb6
bb6:
  %t40 = load i1, ptr %l23, !tbaa !21
  store i1 %t40, ptr %l16, !tbaa !21
  br label %bb7
bb7:
  %t41 = load i1, ptr %l16, !tbaa !21
  br i1 %t41, label %bb8, label %bb9
bb8:
  %t42 = getelementptr %"compiler/lower:pl", ptr %l1, i32 0, i32 1
  %t44 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aProj_3e_2eLen_3ccompiler_2fmir_3aProj_3e(ptr %v1, ptr %t42)
  store i64 %t44, ptr %l25
  br label %bb10
bb9:
  br label %bb11
bb10:
  %t45 = load i64, ptr %l25, !tbaa !24
  %t46 = load i32, ptr %l2, !tbaa !23
  %t50 = load ptr, ptr %lp4
  %t51 = getelementptr %"compiler/lower:pl", ptr %t50, i32 0, i32 2
  store i64 %t45, ptr %t51, !tbaa !24
  %t54 = load ptr, ptr %lp4
  %t55 = getelementptr %"compiler/lower:pl", ptr %t54, i32 0, i32 3
  store i32 %t46, ptr %t55, !tbaa !23
  br label %bb11
bb11:
  %t56 = load ptr, ptr %lp4
  %t57 = load %"compiler/lower:pl", ptr %t56
  store %"compiler/lower:pl" %t57, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/lower:pl", ptr %rv
  ret %"compiler/lower:pl" %rr
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eparamElig(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l5 = alloca i64
  %l10 = alloca %"compiler/typed:Local"
  %l13 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l20 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/typed:Body", ptr %t4, i32 0, i32 3
  %t7 = load i64, ptr %t6, !tbaa !24
  store i64 %t7, ptr %l5, !tbaa !24
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/lower:lowering", ptr %t8, i32 0, i32 1
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t13 = getelementptr %"compiler/typed:Body", ptr %t11, i32 0, i32 7
  %t17 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t13, i64 %a1)
  store %"compiler/typed:Local" %t17, ptr %l10
  br label %bb1
bb1:
  %t18 = getelementptr %"compiler/typed:Local", ptr %l10, i32 0, i32 1
  %t19 = getelementptr %"compiler/source:Span", ptr %t18, i32 0, i32 0
  %t20 = load i32, ptr %t19, !tbaa !23
  %t22 = sext i32 %t20 to i64
  %t23 = load i64, ptr %l5, !tbaa !24
  %t25 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s0, i64 %t23, i64 %t22)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t25, ptr %l13
  br label %bb2
bb2:
  %t26 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l13
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/lower:lowering", ptr %t27, i32 0, i32 0
  %t30 = load ptr, ptr %t29, !tbaa !29
  %t32 = getelementptr %"compiler/lower:Lowerer", ptr %t30, i32 0, i32 0
  %t33 = load ptr, ptr %t32, !tbaa !29
  %t35 = getelementptr %"compiler/generic:Program", ptr %t33, i32 0, i32 0
  %t36 = load ptr, ptr %t35, !tbaa !29
  %t38 = getelementptr %"compiler/load:Loader", ptr %t36, i32 0, i32 5
  %t42 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %v0, ptr %t38, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t26)
  store i1 %t42, ptr %l20
  br label %bb3
bb3:
  %t43 = load i1, ptr %l20, !tbaa !21
  %t44 = xor i1 %t43, true
  call void @__olang_scope_close(ptr %s0)
  store i1 %t44, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2epopIf(ptr %v0, ptr %a0, { i64, [4 x i64] } %a1, i32 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca { i64, [4 x i64] }
  %l5 = alloca i32
  %l6 = alloca i32
  %l11 = alloca { i64, [4 x i64] }
  %l16 = alloca i32
  %l19 = alloca i32
  %l29 = alloca { i64, [21 x i64] }
  %s0 = alloca %olang.scope
  %t32 = alloca { i64, [8 x i64] }, align 8
  %t50 = alloca { i64, [21 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t4 = load %"compiler/source:Span", ptr %l3
  %t9 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ecarries(ptr %v0, ptr %t1, { i64, [4 x i64] } %a1, i32 %a2, %"compiler/source:Span" %t4)
  store { i64, [4 x i64] } %t9, ptr %l11
  br label %bb1
bb1:
  %t10 = load { i64, [4 x i64] }, ptr %l11
  store { i64, [4 x i64] } %t10, ptr %l4
  %t11 = load { i64, [4 x i64] }, ptr %l4
  %t13 = extractvalue { i64, [4 x i64] } %t11, 0
  %t14 = icmp eq i64 %t13, 0
  br i1 %t14, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb3:
  br label %bb4
bb4:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/lower:lowering", ptr %t16, i32 0, i32 3
  %t20 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t18)
  store i32 %t20, ptr %l16
  br label %bb5
bb5:
  %t21 = load i32, ptr %l16, !tbaa !23
  store i32 %t21, ptr %l5, !tbaa !23
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/lower:lowering", ptr %t22, i32 0, i32 3
  %t26 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t24)
  store i32 %t26, ptr %l19
  br label %bb6
bb6:
  %t27 = load i32, ptr %l19, !tbaa !23
  store i32 %t27, ptr %l6, !tbaa !23
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load { i64, [4 x i64] }, ptr %l4
  %t30 = load i32, ptr %l5, !tbaa !23
  %t31 = load i32, ptr %l6, !tbaa !23
  store { i64, [8 x i64] } zeroinitializer, ptr %t32
  %t33 = getelementptr { i64, [8 x i64] }, ptr %t32, i32 0, i32 0
  store i64 2, ptr %t33
  %t35 = insertvalue { { i64, [4 x i64] }, i32, i32 } undef, { i64, [4 x i64] } %t29, 0
  %t37 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t35, i32 %t30, 1
  %t39 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t37, i32 %t31, 2
  %t40 = getelementptr { i64, [8 x i64] }, ptr %t32, i32 0, i32 1
  store { { i64, [4 x i64] }, i32, i32 } %t39, ptr %t40
  %t41 = load { i64, [8 x i64] }, ptr %t32
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t28, { i64, [8 x i64] } %t41)
  br label %bb7
bb7:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t45 = load i32, ptr %l5, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t44, i32 %t45)
  br label %bb8
bb8:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t49 = load %"compiler/source:Span", ptr %l3
  store { i64, [21 x i64] } zeroinitializer, ptr %t50
  %t51 = getelementptr { i64, [21 x i64] }, ptr %t50, i32 0, i32 0
  store i64 13, ptr %t51
  %t53 = insertvalue { %"compiler/source:Span" } undef, %"compiler/source:Span" %t49, 0
  %t54 = getelementptr { i64, [21 x i64] }, ptr %t50, i32 0, i32 1
  store { %"compiler/source:Span" } %t53, ptr %t54
  %t55 = load { i64, [21 x i64] }, ptr %t50
  store { i64, [21 x i64] } %t55, ptr %l29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s0, ptr %t48, ptr %l29)
  br label %bb9
bb9:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = load i32, ptr %l6, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2egoto(ptr %v0, ptr %t58, i32 %t59)
  br label %bb10
bb10:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t63 = load i32, ptr %l6, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t62, i32 %t63)
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2epromote(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca ptr
  %l5 = alloca i32
  %l10 = alloca i32
  %l11 = alloca ptr
  %l14 = alloca i32
  %l15 = alloca i1
  %l16 = alloca i1
  %l20 = alloca i1
  %l23 = alloca i64
  %l25 = alloca { i64, [4 x i64] }
  %l31 = alloca { i64, [4 x i64] }
  %l32 = alloca i32
  %l34 = alloca i1
  %l39 = alloca { i64, [4 x i64] }
  %l44 = alloca { i64, [4 x i64] }
  %rv = alloca { i64, [4 x i64] }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  store %"compiler/source:Span" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t7 = load i32, ptr %l2, !tbaa !23
  %t10 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2earrayOf(ptr %v0, ptr %t6, i32 %t7)
  store i32 %t10, ptr %l10
  br label %bb1
bb1:
  %t11 = load i32, ptr %l10, !tbaa !23
  store i32 %t11, ptr %l5, !tbaa !23
  %t12 = load ptr, ptr %l4, !tbaa !29
  store ptr %t12, ptr %l11, !tbaa !29
  %t13 = load ptr, ptr %l4, !tbaa !29
  %t14 = load i32, ptr %l2, !tbaa !23
  %t17 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t13, i32 %t14)
  store i32 %t17, ptr %l14
  br label %bb2
bb2:
  %t18 = load ptr, ptr %l11, !tbaa !29
  %t19 = load i32, ptr %l14, !tbaa !23
  %t20 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t18, i32 %t19)
  store i1 %t20, ptr %l15
  br label %bb3
bb3:
  %t21 = load i1, ptr %l15, !tbaa !21
  br i1 %t21, label %bb4, label %bb5
bb4:
  %t22 = load i32, ptr %l5, !tbaa !23
  %t23 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t26 = icmp ne i32 %t22, %t23
  store i1 %t26, ptr %l16, !tbaa !21
  br label %bb6
bb5:
  store i1 false, ptr %l16, !tbaa !21
  br label %bb6
bb6:
  %t28 = load i1, ptr %l16, !tbaa !21
  br i1 %t28, label %bb7, label %bb8
bb7:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t30 = load i32, ptr %l5, !tbaa !23
  %t33 = call i64 @compiler_2flower_2ecompiler_2flower_3alowering_2efixedLen(ptr %v0, ptr %t29, i32 %t30)
  store i64 %t33, ptr %l23
  br label %bb9
bb8:
  store i1 false, ptr %l20, !tbaa !21
  br label %bb10
bb9:
  %t34 = load i64, ptr %l23, !tbaa !24
  %t35 = icmp slt i64 %t34, 0
  store i1 %t35, ptr %l20, !tbaa !21
  br label %bb10
bb10:
  %t37 = load i1, ptr %l20, !tbaa !21
  br i1 %t37, label %bb11, label %bb12
bb11:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t39 = load ptr, ptr %l1, !tbaa !29
  %t40 = load i32, ptr %l2, !tbaa !23
  %t41 = load %"compiler/source:Span", ptr %l3
  %t42 = load i32, ptr %l5, !tbaa !23
  %t48 = call { i32, { i64, [4 x i64] } } @compiler_2flower_2ecompiler_2flower_3alowering_2epromotedInPlace(ptr %v0, ptr %v1, ptr %t38, ptr %t39, i32 %t40, %"compiler/source:Span" %t41, i32 %t42)
  %t49 = extractvalue { i32, { i64, [4 x i64] } } %t48, 1
  %t50 = extractvalue { i32, { i64, [4 x i64] } } %t48, 0
  store i32 %t50, ptr %l32
  %t51 = icmp ne i32 %t50, 0
  br i1 %t51, label %bb14, label %ok.52, !prof !99
ok.52:
  store { i64, [4 x i64] } %t49, ptr %l31
  br label %bb13
bb12:
  br label %bb18
bb13:
  %t53 = load { i64, [4 x i64] }, ptr %l31
  store { i64, [4 x i64] } %t53, ptr %l25
  br label %bb17
bb14:
  %t54 = load i32, ptr %l32, !tbaa !23
  %t55 = ashr i32 %t54, 16
  %t57 = icmp eq i32 %t55, 1
  store i1 %t57, ptr %l34, !tbaa !21
  br label %bb15
bb15:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = load ptr, ptr %l1, !tbaa !29
  %t60 = load i32, ptr %l2, !tbaa !23
  %t61 = load %"compiler/source:Span", ptr %l3
  %t66 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2epromoteNew(ptr %v0, ptr %v1, ptr %t58, ptr %t59, i32 %t60, %"compiler/source:Span" %t61)
  store { i64, [4 x i64] } %t66, ptr %l39
  br label %bb16
bb16:
  %t67 = load { i64, [4 x i64] }, ptr %l39
  store { i64, [4 x i64] } %t67, ptr %l25
  br label %bb17
bb17:
  %t68 = load { i64, [4 x i64] }, ptr %l25
  store { i64, [4 x i64] } %t68, ptr %rv
  br label %ret
bb18:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t70 = load ptr, ptr %l1, !tbaa !29
  %t71 = load i32, ptr %l2, !tbaa !23
  %t72 = load %"compiler/source:Span", ptr %l3
  %t77 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2epromoteNew(ptr %v0, ptr %v1, ptr %t69, ptr %t70, i32 %t71, %"compiler/source:Span" %t72)
  store { i64, [4 x i64] } %t77, ptr %l44
  br label %bb19
bb19:
  %t78 = load { i64, [4 x i64] }, ptr %l44
  store { i64, [4 x i64] } %t78, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2epromoteNew(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca { i64, [4 x i64] }
  %l5 = alloca { i64, [1 x i64] }
  %l6 = alloca { i64, [4 x i64] }
  %l7 = alloca ptr
  %l12 = alloca { i64, [4 x i64] }
  %l19 = alloca { i64, [1 x i64] }
  %l27 = alloca { i64, [4 x i64] }
  %l32 = alloca i1
  %l33 = alloca i1
  %l34 = alloca ptr
  %l37 = alloca i32
  %l38 = alloca i1
  %l39 = alloca ptr
  %l40 = alloca %"compiler/source:Span"
  %l41 = alloca { i64, [1 x i64] }
  %l44 = alloca i32
  %l46 = alloca { i64, [21 x i64] }
  %s2 = alloca %olang.scope
  %rv = alloca { i64, [4 x i64] }
  %t16 = alloca { i64, [4 x i64] }, align 8
  %t34 = alloca { i64, [15 x i64] }, align 8
  %t82 = alloca { i64, [21 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  store %"compiler/source:Span" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t4 = getelementptr %"compiler/typed:Promote", ptr %t2, i32 0, i32 0
  %t5 = load ptr, ptr %t4, !tbaa !29
  %t9 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v1, ptr %t1, ptr %t5)
  store { i64, [4 x i64] } %t9, ptr %l12
  br label %bb1
bb1:
  %t10 = load { i64, [4 x i64] }, ptr %l12
  store { i64, [4 x i64] } %t10, ptr %l4
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/lower:lowering", ptr %t11, i32 0, i32 7
  %t14 = load i1, ptr %t13, !tbaa !21
  br i1 %t14, label %bb2, label %bb3
bb2:
  store { i64, [4 x i64] } zeroinitializer, ptr %t16
  %t17 = getelementptr { i64, [4 x i64] }, ptr %t16, i32 0, i32 0
  store i64 0, ptr %t17
  %t18 = load { i64, [4 x i64] }, ptr %t16
  store { i64, [4 x i64] } %t18, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load ptr, ptr %l1, !tbaa !29
  %t23 = getelementptr %"compiler/typed:Promote", ptr %t21, i32 0, i32 1
  %t24 = load i32, ptr %t23, !tbaa !23
  %t27 = call { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ebuilt(ptr %v0, ptr %t20, i32 %t24)
  store { i64, [1 x i64] } %t27, ptr %l19
  br label %bb5
bb5:
  %t28 = load { i64, [1 x i64] }, ptr %l19
  store { i64, [1 x i64] } %t28, ptr %l5
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t30 = load i32, ptr %l2, !tbaa !23
  %t31 = load { i64, [1 x i64] }, ptr %l5
  %t32 = load { i64, [4 x i64] }, ptr %l4
  %t33 = load i32, ptr %l2, !tbaa !23
  store { i64, [15 x i64] } zeroinitializer, ptr %t34
  %t35 = getelementptr { i64, [15 x i64] }, ptr %t34, i32 0, i32 0
  store i64 7, ptr %t35
  %t37 = insertvalue { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 } undef, { i64, [1 x i64] } %t31, 0
  %t39 = insertvalue { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 } %t37, { i64, [4 x i64] } %t32, 1
  %t41 = insertvalue { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 } %t39, i32 %t33, 2
  %t42 = getelementptr { i64, [15 x i64] }, ptr %t34, i32 0, i32 1
  store { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 } %t41, ptr %t42
  %t43 = load { i64, [15 x i64] }, ptr %t34
  %t44 = load %"compiler/source:Span", ptr %l3
  %t49 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %t29, i32 %t30, { i64, [15 x i64] } %t43, %"compiler/source:Span" %t44)
  store { i64, [4 x i64] } %t49, ptr %l27
  br label %bb6
bb6:
  %t50 = load { i64, [4 x i64] }, ptr %l27
  store { i64, [4 x i64] } %t50, ptr %l6
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = getelementptr %"compiler/lower:lowering", ptr %t51, i32 0, i32 2
  %t54 = load ptr, ptr %t53, !tbaa !29
  store ptr %t54, ptr %l7, !tbaa !29
  %t56 = load ptr, ptr %l7, !tbaa !29
  %t57 = load i32, ptr %l2, !tbaa !23
  %t60 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t56, i32 %t57)
  store i1 %t60, ptr %l32
  br label %bb7
bb7:
  %t61 = load i1, ptr %l32, !tbaa !21
  br i1 %t61, label %bb8, label %bb9
bb8:
  %t62 = load ptr, ptr %l7, !tbaa !29
  store ptr %t62, ptr %l34, !tbaa !29
  %t63 = load ptr, ptr %l7, !tbaa !29
  %t64 = load i32, ptr %l2, !tbaa !23
  %t67 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t63, i32 %t64)
  store i32 %t67, ptr %l37
  br label %bb10
bb9:
  store i1 false, ptr %l33, !tbaa !21
  br label %bb12
bb10:
  %t68 = load ptr, ptr %l34, !tbaa !29
  %t69 = load i32, ptr %l37, !tbaa !23
  %t70 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNeedsDrop(ptr %v0, ptr %t68, i32 %t69)
  store i1 %t70, ptr %l38
  br label %bb11
bb11:
  %t71 = load i1, ptr %l38, !tbaa !21
  store i1 %t71, ptr %l33, !tbaa !21
  br label %bb12
bb12:
  %t72 = load i1, ptr %l33, !tbaa !21
  br i1 %t72, label %bb13, label %bb14
bb13:
  store %olang.scope zeroinitializer, ptr %s2
  %t73 = load ptr, ptr %l0, !tbaa !29
  store ptr %t73, ptr %l39, !tbaa !29
  %t74 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t74, ptr %l40
  %t75 = load { i64, [1 x i64] }, ptr %l5
  store { i64, [1 x i64] } %t75, ptr %l41
  %t76 = load ptr, ptr %l7, !tbaa !29
  %t77 = load i32, ptr %l2, !tbaa !23
  %t80 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t76, i32 %t77)
  store i32 %t80, ptr %l44
  br label %bb15
bb14:
  br label %bb17
bb15:
  %t81 = load { i64, [4 x i64] }, ptr %l6
  store { i64, [21 x i64] } zeroinitializer, ptr %t82
  %t83 = getelementptr { i64, [21 x i64] }, ptr %t82, i32 0, i32 0
  store i64 5, ptr %t83
  %t84 = load %"compiler/source:Span", ptr %l40
  %t85 = insertvalue { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } undef, %"compiler/source:Span" %t84, 0
  %t86 = load { i64, [1 x i64] }, ptr %l41
  %t87 = insertvalue { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } %t85, { i64, [1 x i64] } %t86, 1
  %t88 = load i32, ptr %l44, !tbaa !23
  %t89 = insertvalue { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } %t87, i32 %t88, 2
  %t91 = insertvalue { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } %t89, { i64, [4 x i64] } %t81, 3
  %t92 = getelementptr { i64, [21 x i64] }, ptr %t82, i32 0, i32 1
  store { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } %t91, ptr %t92
  %t93 = load { i64, [21 x i64] }, ptr %t82
  store { i64, [21 x i64] } %t93, ptr %l46
  %t94 = load ptr, ptr %l39, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s2, ptr %t94, ptr %l46)
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s2)
  br label %bb17
bb17:
  %t96 = load { i64, [4 x i64] }, ptr %l6
  store { i64, [4 x i64] } %t96, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3alowering_2equiet(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l4 = alloca i64
  %l7 = alloca i1
  %l18 = alloca i64
  %l21 = alloca ptr
  %l23 = alloca i64
  %l24 = alloca ptr
  %l29 = alloca ptr
  %l30 = alloca i1
  %l31 = alloca i64
  %l36 = alloca i64
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 43
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i64, ptr %l4, !tbaa !24
  store i64 %t6, ptr %l1, !tbaa !24
  %t7 = load i64, ptr %l1, !tbaa !24
  %t9 = icmp eq i64 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb4
bb3:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/lower:lowering", ptr %t11, i32 0, i32 0
  %t14 = load ptr, ptr %t13, !tbaa !29
  %t16 = getelementptr %"compiler/lower:Lowerer", ptr %t14, i32 0, i32 0
  %t17 = load ptr, ptr %t16, !tbaa !29
  %t19 = getelementptr %"compiler/generic:Program", ptr %t17, i32 0, i32 0
  %t20 = load ptr, ptr %t19, !tbaa !29
  %t22 = getelementptr %"compiler/load:Loader", ptr %t20, i32 0, i32 8
  %t23 = load i1, ptr %t22, !tbaa !21
  store i1 %t23, ptr %l7, !tbaa !21
  br label %bb4
bb4:
  %t25 = load i1, ptr %l7, !tbaa !21
  br i1 %t25, label %bb5, label %bb6
bb5:
  store i1 false, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/lower:lowering", ptr %t27, i32 0, i32 43
  %t30 = load i64, ptr %l1, !tbaa !24
  %t32 = sub i64 %t30, 1
  %t35 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t29, i64 %t32)
  store i64 %t35, ptr %l18
  br label %bb8
bb8:
  %t36 = load i64, ptr %l18, !tbaa !24
  %t37 = icmp slt i64 %t36, 0
  br i1 %t37, label %bb9, label %bb10
bb9:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/lower:lowering", ptr %t39, i32 0, i32 43
  store ptr %t41, ptr %l21, !tbaa !29
  %t42 = load i64, ptr %l1, !tbaa !24
  %t44 = sub i64 %t42, 1
  store i64 %t44, ptr %l23, !tbaa !24
  %t45 = load ptr, ptr %l0, !tbaa !29
  store ptr %t45, ptr %l24, !tbaa !29
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/lower:lowering", ptr %t46, i32 0, i32 42
  %t49 = load i64, ptr %l1, !tbaa !24
  %t51 = sub i64 %t49, 1
  %t54 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eAt_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t48, i64 %t51)
  store ptr %t54, ptr %l29
  br label %bb11
bb10:
  br label %bb17
bb11:
  %t55 = load ptr, ptr %l24, !tbaa !29
  %t56 = load ptr, ptr %l29, !tbaa !29
  %t57 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2equietStmt(ptr %v0, ptr %v0, ptr %t55, ptr %t56)
  store i1 %t57, ptr %l30
  br label %bb12
bb12:
  %t58 = load i1, ptr %l30, !tbaa !21
  br i1 %t58, label %bb13, label %bb14
bb13:
  store i64 1, ptr %l31, !tbaa !24
  br label %bb15
bb14:
  store i64 0, ptr %l31, !tbaa !24
  br label %bb15
bb15:
  %t59 = load ptr, ptr %l21, !tbaa !29
  %t60 = load i64, ptr %l23, !tbaa !24
  %t61 = load i64, ptr %l31, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t59, i64 %t60, i64 %t61)
  br label %bb16
bb16:
  br label %bb17
bb17:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/lower:lowering", ptr %t62, i32 0, i32 43
  %t65 = load i64, ptr %l1, !tbaa !24
  %t67 = sub i64 %t65, 1
  %t70 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t64, i64 %t67)
  store i64 %t70, ptr %l36
  br label %bb18
bb18:
  %t71 = load i64, ptr %l36, !tbaa !24
  %t72 = icmp eq i64 %t71, 1
  store i1 %t72, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3alowering_2equietCall(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca i64
  %l6 = alloca i32
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i32
  %l15 = alloca i1
  %l20 = alloca i32
  %l21 = alloca ptr
  %l22 = alloca i1
  %l33 = alloca ptr
  %l36 = alloca ptr
  %l37 = alloca i1
  %l46 = alloca i32
  %l47 = alloca ptr
  %l48 = alloca i1
  %l58 = alloca { i64, ptr }
  %l59 = alloca ptr
  %l62 = alloca i32
  %l63 = alloca { i64, ptr }
  %l73 = alloca i64
  %l76 = alloca i64
  %l95 = alloca { i64, ptr }
  %l98 = alloca i32
  %l103 = alloca i1
  %l105 = alloca { i64, ptr }
  %l108 = alloca i1
  %l109 = alloca i1
  %l111 = alloca { i64, ptr }
  %l114 = alloca i64
  %l119 = alloca i1
  %l122 = alloca i64
  %l124 = alloca i1
  %l127 = alloca i1
  %l131 = alloca i1
  %l134 = alloca i64
  %l136 = alloca i1
  %l139 = alloca i1
  %l143 = alloca i1
  %l146 = alloca i64
  %l148 = alloca i1
  %l149 = alloca ptr
  %l152 = alloca i1
  %l153 = alloca i32
  %l156 = alloca i32
  %l158 = alloca i1
  %l162 = alloca i1
  %l163 = alloca i1
  %l166 = alloca { i64, ptr }
  %l170 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l1, !tbaa !29
  %t8 = getelementptr %"compiler/typed:Call", ptr %t6, i32 0, i32 0
  %t9 = load ptr, ptr %t8, !tbaa !29
  store ptr %t9, ptr %l3, !tbaa !29
  %t11 = load ptr, ptr %l3, !tbaa !29
  store ptr %t11, ptr %l21, !tbaa !29
  store i1 false, ptr %l22, !tbaa !21
  %t12 = load ptr, ptr %l21, !tbaa !29
  %t13 = icmp ne ptr %t12, null
  br i1 %t13, label %bb1, label %bb2
bb1:
  %t15 = load ptr, ptr %l21, !tbaa !29
  %t16 = load i64, ptr %t15, !range !{i64 0, i64 5}
  %t18 = icmp eq i64 %t16, 0
  store i1 %t18, ptr %l22, !tbaa !21
  br label %bb2
bb2:
  %t19 = load i1, ptr %l22, !tbaa !21
  br i1 %t19, label %bb3, label %bb4
bb3:
  %t20 = load ptr, ptr %l3, !tbaa !29
  %t22 = getelementptr { i64, [3 x i64] }, ptr %t20, i32 0, i32 1
  %t23 = getelementptr { i32 }, ptr %t22, i32 0, i32 0
  %t24 = load i32, ptr %t23
  store i32 %t24, ptr %l4, !tbaa !23
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/lower:lowering", ptr %t26, i32 0, i32 0
  %t29 = load ptr, ptr %t28, !tbaa !29
  %t31 = getelementptr %"compiler/lower:Lowerer", ptr %t29, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !29
  %t34 = load i32, ptr %l4, !tbaa !23
  %t36 = sext i32 %t34 to i64
  %t39 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t32, i64 %t36)
  store ptr %t39, ptr %l33
  br label %bb6
bb6:
  %t40 = load ptr, ptr %l33, !tbaa !29
  %t42 = getelementptr %"compiler/typed:Body", ptr %t40, i32 0, i32 2
  %t43 = load i32, ptr %t42, !tbaa !23
  store i32 %t43, ptr %l20, !tbaa !23
  br label %bb25
bb7:
  %t45 = load ptr, ptr %l3, !tbaa !29
  store ptr %t45, ptr %l36, !tbaa !29
  store i1 false, ptr %l37, !tbaa !21
  %t46 = load ptr, ptr %l36, !tbaa !29
  %t47 = icmp ne ptr %t46, null
  br i1 %t47, label %bb8, label %bb9
bb8:
  %t49 = load ptr, ptr %l36, !tbaa !29
  %t50 = load i64, ptr %t49, !range !{i64 0, i64 5}
  %t52 = icmp eq i64 %t50, 1
  store i1 %t52, ptr %l37, !tbaa !21
  br label %bb9
bb9:
  %t53 = load i1, ptr %l37, !tbaa !21
  br i1 %t53, label %bb10, label %bb11
bb10:
  %t54 = load ptr, ptr %l3, !tbaa !29
  %t56 = getelementptr { i64, [3 x i64] }, ptr %t54, i32 0, i32 1
  %t57 = getelementptr { i64 }, ptr %t56, i32 0, i32 0
  %t58 = load i64, ptr %t57
  store i64 %t58, ptr %l5, !tbaa !24
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/lower:lowering", ptr %t60, i32 0, i32 0
  %t63 = load ptr, ptr %t62, !tbaa !29
  %t65 = getelementptr %"compiler/lower:Lowerer", ptr %t63, i32 0, i32 0
  %t66 = load ptr, ptr %t65, !tbaa !29
  %t67 = load i64, ptr %l5, !tbaa !24
  %t70 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t66, i64 %t67)
  store i32 %t70, ptr %l46
  br label %bb13
bb13:
  %t71 = load i32, ptr %l46, !tbaa !23
  store i32 %t71, ptr %l20, !tbaa !23
  br label %bb25
bb14:
  %t72 = load ptr, ptr %l3, !tbaa !29
  store ptr %t72, ptr %l47, !tbaa !29
  store i1 false, ptr %l48, !tbaa !21
  %t73 = load ptr, ptr %l47, !tbaa !29
  %t74 = icmp ne ptr %t73, null
  br i1 %t74, label %bb15, label %bb16
bb15:
  %t76 = load ptr, ptr %l47, !tbaa !29
  %t77 = load i64, ptr %t76, !range !{i64 0, i64 5}
  %t79 = icmp eq i64 %t77, 4
  store i1 %t79, ptr %l48, !tbaa !21
  br label %bb16
bb16:
  %t80 = load i1, ptr %l48, !tbaa !21
  br i1 %t80, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  %t81 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t81, ptr %l20, !tbaa !23
  br label %bb25
bb20:
  br i1 true, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  store i32 -1, ptr %l20, !tbaa !23
  br label %bb25
bb24:
  call void @__olang_check_failed(ptr @olang_loc_79f527557a79a277_798dff7a83c0d4db)
  unreachable
bb25:
  %t83 = load i32, ptr %l20, !tbaa !23
  store i32 %t83, ptr %l6, !tbaa !23
  %t84 = load i32, ptr %l6, !tbaa !23
  %t86 = icmp eq i32 %t84, -1
  br i1 %t86, label %bb26, label %bb27
bb26:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb27:
  br label %bb28
bb28:
  %t89 = load i32, ptr %l6, !tbaa !23
  %t90 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t93 = icmp ne i32 %t89, %t90
  br i1 %t93, label %bb29, label %bb30
bb29:
  %t95 = load ptr, ptr %l2, !tbaa !29
  store ptr %t95, ptr %l59, !tbaa !29
  %t96 = load ptr, ptr %l2, !tbaa !29
  %t97 = load i32, ptr %l6, !tbaa !23
  %t100 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t96, i32 %t97)
  store i32 %t100, ptr %l62
  br label %bb31
bb30:
  %t101 = icmp sge i64 0, 0
  br i1 %t101, label %bb33, label %bb34
bb31:
  %t103 = load ptr, ptr %l59, !tbaa !29
  %t104 = load i32, ptr %l62, !tbaa !23
  %t105 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s0, ptr %t103, i32 %t104)
  store { i64, ptr } %t105, ptr %l63
  br label %bb32
bb32:
  %t106 = load { i64, ptr }, ptr %l63, !tbaa !27
  store { i64, ptr } %t106, ptr %l58, !tbaa !27
  br label %bb37
bb33:
  %t107 = icmp sle i64 0, 2305843009213693951
  br i1 %t107, label %bb35, label %bb36
bb34:
  call void @__olang_check_failed(ptr @olang_loc_2ec5e8672e3e2115_a2b323ecc8460901)
  unreachable
bb35:
  %t109 = mul i64 0, 4
  %t110 = insertvalue { i64, ptr } undef, i64 0, 0
  %t111 = insertvalue { i64, ptr } %t110, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t111, ptr %l58, !tbaa !27
  br label %bb37
bb36:
  call void @__olang_check_failed(ptr @olang_loc_2ec5e8672e3e2115_a2b323ecc8460901)
  unreachable
bb37:
  %t113 = load { i64, ptr }, ptr %l58, !tbaa !27
  store { i64, ptr } %t113, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t114 = load ptr, ptr %l1, !tbaa !29
  %t116 = getelementptr %"compiler/typed:Call", ptr %t114, i32 0, i32 1
  %t117 = load { i64, ptr }, ptr %t116, !tbaa !27
  %t119 = extractvalue { i64, ptr } %t117, 0
  store i64 %t119, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t121 = load i64, ptr %l9, !tbaa !24
  %t122 = load i64, ptr %l8, !tbaa !24
  %t125 = icmp sgt i64 %t121, %t122
  br i1 %t125, label %bb38, label %bb39
bb38:
  %t127 = load i64, ptr %l10, !tbaa !24
  %t129 = icmp sgt i64 %t127, 0
  br i1 %t129, label %bb40, label %bb41
bb39:
  store i64 0, ptr %l73, !tbaa !24
  br label %bb43
bb40:
  %t131 = load i64, ptr %l9, !tbaa !24
  %t132 = load i64, ptr %l8, !tbaa !24
  %t135 = sub i64 %t131, %t132
  %t136 = load i64, ptr %l10, !tbaa !24
  %t139 = add i64 %t135, %t136
  %t141 = sub i64 %t139, 1
  %t142 = load i64, ptr %l10, !tbaa !24
  %t145 = sdiv i64 %t141, %t142
  store i64 %t145, ptr %l76, !tbaa !24
  br label %bb42
bb41:
  store i64 0, ptr %l76, !tbaa !24
  br label %bb42
bb42:
  %t147 = load i64, ptr %l76, !tbaa !24
  store i64 %t147, ptr %l73, !tbaa !24
  br label %bb43
bb43:
  %t148 = load i64, ptr %l73, !tbaa !24
  store i64 %t148, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb44
bb44:
  %t149 = load i64, ptr %l12, !tbaa !24
  %t150 = load i64, ptr %l11, !tbaa !24
  %t153 = icmp slt i64 %t149, %t150
  %t155 = xor i1 %t153, true
  br i1 %t155, label %bb45, label %bb46
bb45:
  br label %bb104
bb46:
  br label %bb47
bb47:
  %t157 = load i64, ptr %l8, !tbaa !24
  %t158 = load i64, ptr %l12, !tbaa !24
  %t159 = load i64, ptr %l10, !tbaa !24
  %t162 = mul i64 %t158, %t159
  %t165 = add i64 %t157, %t162
  store i64 %t165, ptr %l13, !tbaa !24
  %t167 = load ptr, ptr %l1, !tbaa !29
  %t169 = getelementptr %"compiler/typed:Call", ptr %t167, i32 0, i32 1
  %t170 = load { i64, ptr }, ptr %t169, !tbaa !27
  store { i64, ptr } %t170, ptr %l95, !tbaa !27
  %t171 = load i64, ptr %l13, !tbaa !24
  %t173 = getelementptr { i64, ptr }, ptr %l95, i32 0, i32 1
  %t174 = load ptr, ptr %t173, !tbaa !27
  %t175 = getelementptr ptr, ptr %t174, i64 %t171
  %t176 = load ptr, ptr %t175, !tbaa !39
  %t178 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t176)
  store i32 %t178, ptr %l98
  br label %bb48
bb48:
  %t179 = load i32, ptr %l98, !tbaa !23
  store i32 %t179, ptr %l14, !tbaa !23
  %t180 = load i64, ptr %l13, !tbaa !24
  %t181 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t183 = extractvalue { i64, ptr } %t181, 0
  %t186 = icmp slt i64 %t180, %t183
  br i1 %t186, label %bb49, label %bb50
bb49:
  %t188 = load ptr, ptr %l2, !tbaa !29
  %t189 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t189, ptr %l105, !tbaa !27
  %t190 = load i64, ptr %l13, !tbaa !24
  %t192 = getelementptr { i64, ptr }, ptr %l105, i32 0, i32 1
  %t193 = load ptr, ptr %t192, !tbaa !27
  %t194 = getelementptr i32, ptr %t193, i64 %t190
  %t195 = load i32, ptr %t194, !tbaa !33
  %t198 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t188, i32 %t195)
  store i1 %t198, ptr %l108
  br label %bb51
bb50:
  store i1 false, ptr %l103, !tbaa !21
  br label %bb52
bb51:
  %t199 = load i1, ptr %l108, !tbaa !21
  store i1 %t199, ptr %l103, !tbaa !21
  br label %bb52
bb52:
  %t200 = load i1, ptr %l103, !tbaa !21
  br i1 %t200, label %bb53, label %bb54
bb53:
  %t201 = load ptr, ptr %l2, !tbaa !29
  %t202 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t202, ptr %l111, !tbaa !27
  %t203 = load i64, ptr %l13, !tbaa !24
  %t205 = getelementptr { i64, ptr }, ptr %l111, i32 0, i32 1
  %t206 = load ptr, ptr %t205, !tbaa !27
  %t207 = getelementptr i32, ptr %t206, i64 %t203
  %t208 = load i32, ptr %t207, !tbaa !33
  %t211 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t201, i32 %t208)
  store i64 %t211, ptr %l114
  br label %bb55
bb54:
  store i1 false, ptr %l109, !tbaa !21
  br label %bb56
bb55:
  %t212 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t213 = load i64, ptr %l114, !tbaa !24
  %t215 = and i64 %t213, %t212
  %t217 = icmp ne i64 %t215, 0
  store i1 %t217, ptr %l109, !tbaa !21
  br label %bb56
bb56:
  %t219 = load i1, ptr %l109, !tbaa !21
  store i1 %t219, ptr %l15, !tbaa !21
  %t220 = load i1, ptr %l15, !tbaa !21
  br i1 %t220, label %bb57, label %bb58
bb57:
  %t222 = load ptr, ptr %l0, !tbaa !29
  %t224 = getelementptr %"compiler/lower:lowering", ptr %t222, i32 0, i32 36
  %t226 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eLen_3cI64_2c_20Bool_3e(ptr %v0, ptr %t224)
  store i64 %t226, ptr %l122
  br label %bb59
bb58:
  store i1 false, ptr %l119, !tbaa !21
  br label %bb64
bb59:
  %t227 = load i64, ptr %l122, !tbaa !24
  %t228 = icmp eq i64 %t227, 0
  br i1 %t228, label %bb60, label %bb61
bb60:
  store i1 true, ptr %l124, !tbaa !21
  br label %bb63
bb61:
  %t230 = load ptr, ptr %l0, !tbaa !29
  %t231 = load i32, ptr %l14, !tbaa !23
  %t234 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2ewritesCover(ptr %v0, ptr %t230, i32 %t231, i64 0)
  store i1 %t234, ptr %l127
  br label %bb62
bb62:
  %t235 = load i1, ptr %l127, !tbaa !21
  store i1 %t235, ptr %l124, !tbaa !21
  br label %bb63
bb63:
  %t236 = load i1, ptr %l124, !tbaa !21
  store i1 %t236, ptr %l119, !tbaa !21
  br label %bb64
bb64:
  %t237 = load i1, ptr %l119, !tbaa !21
  br i1 %t237, label %bb65, label %bb66
bb65:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb66:
  br label %bb67
bb67:
  %t239 = load i1, ptr %l15, !tbaa !21
  %t241 = xor i1 %t239, true
  br i1 %t241, label %bb68, label %bb69
bb68:
  %t243 = load ptr, ptr %l0, !tbaa !29
  %t245 = getelementptr %"compiler/lower:lowering", ptr %t243, i32 0, i32 36
  %t247 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eLen_3cI64_2c_20Bool_3e(ptr %v0, ptr %t245)
  store i64 %t247, ptr %l134
  br label %bb70
bb69:
  store i1 false, ptr %l131, !tbaa !21
  br label %bb71
bb70:
  %t248 = load i64, ptr %l134, !tbaa !24
  %t249 = icmp eq i64 %t248, 0
  store i1 %t249, ptr %l131, !tbaa !21
  br label %bb71
bb71:
  %t251 = load i1, ptr %l131, !tbaa !21
  br i1 %t251, label %bb72, label %bb73
bb72:
  %t252 = load ptr, ptr %l2, !tbaa !29
  %t253 = load i32, ptr %l14, !tbaa !23
  %t256 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReachesWrite(ptr %v0, ptr %t252, i32 %t253)
  store i1 %t256, ptr %l139
  br label %bb74
bb73:
  store i1 false, ptr %l136, !tbaa !21
  br label %bb75
bb74:
  %t257 = load i1, ptr %l139, !tbaa !21
  store i1 %t257, ptr %l136, !tbaa !21
  br label %bb75
bb75:
  %t258 = load i1, ptr %l136, !tbaa !21
  br i1 %t258, label %bb76, label %bb77
bb76:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb77:
  br label %bb78
bb78:
  %t260 = load i1, ptr %l15, !tbaa !21
  %t262 = xor i1 %t260, true
  br i1 %t262, label %bb79, label %bb80
bb79:
  %t264 = load ptr, ptr %l0, !tbaa !29
  %t266 = getelementptr %"compiler/lower:lowering", ptr %t264, i32 0, i32 36
  %t268 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eLen_3cI64_2c_20Bool_3e(ptr %v0, ptr %t266)
  store i64 %t268, ptr %l146
  br label %bb81
bb80:
  store i1 false, ptr %l143, !tbaa !21
  br label %bb82
bb81:
  %t269 = load i64, ptr %l146, !tbaa !24
  %t270 = icmp sgt i64 %t269, 0
  store i1 %t270, ptr %l143, !tbaa !21
  br label %bb82
bb82:
  %t272 = load i1, ptr %l143, !tbaa !21
  br i1 %t272, label %bb83, label %bb84
bb83:
  %t273 = load ptr, ptr %l0, !tbaa !29
  store ptr %t273, ptr %l149, !tbaa !29
  %t274 = load ptr, ptr %l2, !tbaa !29
  %t275 = load i32, ptr %l14, !tbaa !23
  %t278 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t274, i32 %t275)
  store i1 %t278, ptr %l152
  br label %bb85
bb84:
  store i1 false, ptr %l148, !tbaa !21
  br label %bb91
bb85:
  %t279 = load i1, ptr %l152, !tbaa !21
  br i1 %t279, label %bb86, label %bb87
bb86:
  %t280 = load ptr, ptr %l2, !tbaa !29
  %t281 = load i32, ptr %l14, !tbaa !23
  %t284 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t280, i32 %t281)
  store i32 %t284, ptr %l156
  br label %bb88
bb87:
  %t285 = load i32, ptr %l14, !tbaa !23
  store i32 %t285, ptr %l153, !tbaa !23
  br label %bb89
bb88:
  %t287 = load i32, ptr %l156, !tbaa !23
  store i32 %t287, ptr %l153, !tbaa !23
  br label %bb89
bb89:
  %t288 = load ptr, ptr %l149, !tbaa !29
  %t289 = load i32, ptr %l153, !tbaa !23
  %t290 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2ewritesCover(ptr %v0, ptr %t288, i32 %t289, i64 0)
  store i1 %t290, ptr %l158
  br label %bb90
bb90:
  %t291 = load i1, ptr %l158, !tbaa !21
  store i1 %t291, ptr %l148, !tbaa !21
  br label %bb91
bb91:
  %t292 = load i1, ptr %l148, !tbaa !21
  br i1 %t292, label %bb92, label %bb93
bb92:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb93:
  br label %bb94
bb94:
  %t294 = load ptr, ptr %l2, !tbaa !29
  %t295 = load i32, ptr %l14, !tbaa !23
  %t298 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReachesCode(ptr %v0, ptr %t294, i32 %t295)
  store i1 %t298, ptr %l162
  br label %bb95
bb95:
  %t299 = load i1, ptr %l162, !tbaa !21
  br i1 %t299, label %bb96, label %bb97
bb96:
  store i1 true, ptr %l163, !tbaa !21
  br label %bb99
bb97:
  %t300 = load ptr, ptr %l0, !tbaa !29
  %t301 = load ptr, ptr %l1, !tbaa !29
  %t303 = getelementptr %"compiler/typed:Call", ptr %t301, i32 0, i32 1
  %t304 = load { i64, ptr }, ptr %t303, !tbaa !27
  store { i64, ptr } %t304, ptr %l166, !tbaa !27
  %t305 = load i64, ptr %l13, !tbaa !24
  %t307 = getelementptr { i64, ptr }, ptr %l166, i32 0, i32 1
  %t308 = load ptr, ptr %t307, !tbaa !27
  %t309 = getelementptr ptr, ptr %t308, i64 %t305
  %t310 = load ptr, ptr %t309, !tbaa !39
  %t314 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2equietX(ptr %v0, ptr %v1, ptr %t300, ptr %t310)
  store i1 %t314, ptr %l170
  br label %bb98
bb98:
  %t315 = load i1, ptr %l170, !tbaa !21
  %t316 = xor i1 %t315, true
  store i1 %t316, ptr %l163, !tbaa !21
  br label %bb99
bb99:
  %t318 = load i1, ptr %l163, !tbaa !21
  br i1 %t318, label %bb100, label %bb101
bb100:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb101:
  br label %bb102
bb102:
  br label %bb103
bb103:
  %t320 = load i64, ptr %l12, !tbaa !24
  %t322 = add i64 %t320, 1
  store i64 %t322, ptr %l12, !tbaa !24
  br label %bb44
bb104:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3alowering_2equietClauses(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l14 = alloca { i64, ptr }
  %l21 = alloca i1
  %l25 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/typed:Try", ptr %a1, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t6 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  store i64 %t8, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t10 = load i64, ptr %l3, !tbaa !24
  %t11 = load i64, ptr %l4, !tbaa !24
  %t14 = icmp slt i64 %t10, %t11
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb2, label %bb3
bb2:
  br label %bb13
bb3:
  br label %bb4
bb4:
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t18, ptr %l14, !tbaa !27
  %t19 = load i64, ptr %l3, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr ptr, ptr %t22, i64 %t19
  %t24 = load ptr, ptr %t23, !tbaa !39
  store ptr %t24, ptr %l5, !tbaa !29
  %t26 = load ptr, ptr %l5, !tbaa !29
  %t28 = getelementptr %"compiler/typed:Clause", ptr %t26, i32 0, i32 3
  %t29 = load ptr, ptr %t28, !tbaa !29
  %t31 = icmp eq ptr %t29, null
  %t33 = xor i1 %t31, true
  br i1 %t33, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l21, !tbaa !21
  br label %bb8
bb6:
  %t36 = load ptr, ptr %l5, !tbaa !29
  %t38 = getelementptr %"compiler/typed:Clause", ptr %t36, i32 0, i32 4
  %t39 = load { i64, ptr }, ptr %t38, !tbaa !27
  %t42 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2equietAll(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %t39)
  store i1 %t42, ptr %l25
  br label %bb7
bb7:
  %t43 = load i1, ptr %l25, !tbaa !21
  %t44 = xor i1 %t43, true
  store i1 %t44, ptr %l21, !tbaa !21
  br label %bb8
bb8:
  %t46 = load i1, ptr %l21, !tbaa !21
  br i1 %t46, label %bb9, label %bb10
bb9:
  store i1 false, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  br label %bb12
bb12:
  %t48 = load i64, ptr %l3, !tbaa !24
  %t50 = add i64 %t48, 1
  store i64 %t50, ptr %l3, !tbaa !24
  br label %bb1
bb13:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2eraise(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, { i64, [4 x i64] } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l4 = alloca i1
  %l6 = alloca ptr
  %l12 = alloca i32
  %l13 = alloca { i64, ptr }
  %l25 = alloca i32
  %l27 = alloca i1
  %l28 = alloca ptr
  %l30 = alloca %"compiler/mir:Lvalue"
  %l39 = alloca ptr
  %l40 = alloca %"compiler/source:Span"
  %l42 = alloca %"compiler/mir:Lvalue"
  %s0 = alloca %olang.scope
  %t29 = alloca { i64, [4 x i64] }, align 8
  %t32 = alloca { i64, [8 x i64] }, align 8
  %t62 = alloca { i64, [4 x i64] }, align 8
  %t92 = alloca { i64, [4 x i64] }, align 8
  %t98 = alloca { i64, [8 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l6, !tbaa !29
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/lower:lowering", ptr %t5, i32 0, i32 2
  %t8 = load ptr, ptr %t7, !tbaa !29
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/lower:lowering", ptr %t9, i32 0, i32 1
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t14 = getelementptr %"compiler/typed:Body", ptr %t12, i32 0, i32 2
  %t15 = load i32, ptr %t14, !tbaa !23
  %t18 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t8, i32 %t15)
  store i32 %t18, ptr %l12
  br label %bb1
bb1:
  %t19 = load ptr, ptr %l6, !tbaa !29
  %t20 = load i32, ptr %l12, !tbaa !23
  %t21 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s0, ptr %t19, i32 %t20)
  store { i64, ptr } %t21, ptr %l13
  br label %bb2
bb2:
  %t22 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t22, 0
  %t25 = icmp eq i64 %t23, 0
  br i1 %t25, label %bb3, label %bb4
bb3:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load %"compiler/source:Span", ptr %l1
  store { i64, [4 x i64] } zeroinitializer, ptr %t29
  %t30 = getelementptr { i64, [4 x i64] }, ptr %t29, i32 0, i32 0
  store i64 0, ptr %t30
  %t31 = load { i64, [4 x i64] }, ptr %t29
  store { i64, [8 x i64] } zeroinitializer, ptr %t32
  %t33 = getelementptr { i64, [8 x i64] }, ptr %t32, i32 0, i32 0
  store i64 9, ptr %t33
  %t35 = insertvalue { %"compiler/source:Span", i32, { i64, [4 x i64] } } undef, %"compiler/source:Span" %t28, 0
  %t37 = insertvalue { %"compiler/source:Span", i32, { i64, [4 x i64] } } %t35, i32 3, 1
  %t39 = insertvalue { %"compiler/source:Span", i32, { i64, [4 x i64] } } %t37, { i64, [4 x i64] } %t31, 2
  %t40 = getelementptr { i64, [8 x i64] }, ptr %t32, i32 0, i32 1
  store { %"compiler/source:Span", i32, { i64, [4 x i64] } } %t39, ptr %t40
  %t41 = load { i64, [8 x i64] }, ptr %t32
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t27, { i64, [8 x i64] } %t41)
  br label %bb5
bb4:
  br label %bb6
bb5:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb6:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = load i32, ptr @G_2ecompiler_2fmir_2eI32T, !tbaa !23
  %t47 = load %"compiler/source:Span", ptr %l1
  %t52 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2elocal(ptr %v0, ptr %t44, { i64, [4 x i64] } %a2, i32 %t46, %"compiler/source:Span" %t47)
  store i32 %t52, ptr %l25
  br label %bb7
bb7:
  %t53 = load i32, ptr %l25, !tbaa !23
  store i32 %t53, ptr %l3, !tbaa !23
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eisMain(ptr %v0, ptr %t54)
  store i1 %t56, ptr %l27
  br label %bb8
bb8:
  %t57 = load i1, ptr %l27, !tbaa !21
  br i1 %t57, label %bb9, label %bb10
bb9:
  %t58 = load ptr, ptr %l0, !tbaa !29
  store ptr %t58, ptr %l28, !tbaa !29
  %t59 = load i32, ptr %l3, !tbaa !23
  %t61 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t59)
  store %"compiler/mir:Lvalue" %t61, ptr %l30
  br label %bb11
bb10:
  br label %bb13
bb11:
  store { i64, [4 x i64] } zeroinitializer, ptr %t62
  %t63 = getelementptr { i64, [4 x i64] }, ptr %t62, i32 0, i32 0
  store i64 1, ptr %t63
  %t64 = load %"compiler/mir:Lvalue", ptr %l30
  %t65 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t64, 0
  %t66 = getelementptr { i64, [4 x i64] }, ptr %t62, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t65, ptr %t66
  %t67 = load { i64, [4 x i64] }, ptr %t62
  %t68 = load %"compiler/source:Span", ptr %l1
  %t69 = load ptr, ptr %l28, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2emainPayloads(ptr %v0, ptr %t69, { i64, [4 x i64] } %t67, %"compiler/source:Span" %t68)
  br label %bb12
bb12:
  br label %bb13
bb13:
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t74 = getelementptr %"compiler/lower:lowering", ptr %t72, i32 0, i32 18
  %t75 = load i1, ptr %t74, !tbaa !21
  store i1 %t75, ptr %l4, !tbaa !21
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/lower:lowering", ptr %t77, i32 0, i32 18
  store i1 true, ptr %t79, !tbaa !21
  %t80 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eleave(ptr %v0, ptr %t80, i64 0)
  br label %bb14
bb14:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t83 = load i1, ptr %l4, !tbaa !21
  %t86 = getelementptr %"compiler/lower:lowering", ptr %t82, i32 0, i32 18
  store i1 %t83, ptr %t86, !tbaa !21
  %t87 = load ptr, ptr %l0, !tbaa !29
  store ptr %t87, ptr %l39, !tbaa !29
  %t88 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t88, ptr %l40
  %t89 = load i32, ptr %l3, !tbaa !23
  %t91 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t89)
  store %"compiler/mir:Lvalue" %t91, ptr %l42
  br label %bb15
bb15:
  store { i64, [4 x i64] } zeroinitializer, ptr %t92
  %t93 = getelementptr { i64, [4 x i64] }, ptr %t92, i32 0, i32 0
  store i64 1, ptr %t93
  %t94 = load %"compiler/mir:Lvalue", ptr %l42
  %t95 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t94, 0
  %t96 = getelementptr { i64, [4 x i64] }, ptr %t92, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t95, ptr %t96
  %t97 = load { i64, [4 x i64] }, ptr %t92
  store { i64, [8 x i64] } zeroinitializer, ptr %t98
  %t99 = getelementptr { i64, [8 x i64] }, ptr %t98, i32 0, i32 0
  store i64 7, ptr %t99
  %t100 = load %"compiler/source:Span", ptr %l40
  %t101 = insertvalue { %"compiler/source:Span", { i64, [4 x i64] } } undef, %"compiler/source:Span" %t100, 0
  %t103 = insertvalue { %"compiler/source:Span", { i64, [4 x i64] } } %t101, { i64, [4 x i64] } %t97, 1
  %t104 = getelementptr { i64, [8 x i64] }, ptr %t98, i32 0, i32 1
  store { %"compiler/source:Span", { i64, [4 x i64] } } %t103, ptr %t104
  %t105 = load { i64, [8 x i64] }, ptr %t98
  %t106 = load ptr, ptr %l39, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t106, { i64, [8 x i64] } %t105)
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2ereadHere(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca { i64, ptr }
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca i1
  %l23 = alloca ptr
  %l26 = alloca i64
  %l30 = alloca i1
  %l34 = alloca i1
  %l39 = alloca i1
  %l40 = alloca ptr
  %l41 = alloca i1
  %l51 = alloca ptr
  %l52 = alloca i1
  %l61 = alloca i1
  %l66 = alloca { i64, ptr }
  %l70 = alloca ptr
  %l71 = alloca i1
  %l80 = alloca ptr
  %l81 = alloca i1
  %l90 = alloca i1
  %l95 = alloca ptr
  %l103 = alloca ptr
  %l104 = alloca i1
  %l109 = alloca ptr
  %l110 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l11, !tbaa !29
  store i1 false, ptr %l12, !tbaa !21
  %t2 = load ptr, ptr %l11, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l11, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 6
  store i1 %t8, ptr %l12, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l12, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l4, !tbaa !29
  br label %bb5
bb4:
  br label %bb15
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/lower:lowering", ptr %t16, i32 0, i32 29
  %t19 = load ptr, ptr %l4, !tbaa !29
  %t21 = getelementptr %"compiler/typed:Call", ptr %t19, i32 0, i32 2
  %t22 = load i32, ptr %t21, !tbaa !23
  %t24 = sext i32 %t22 to i64
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t18, i64 %t24, i1 true)
  br label %bb6
bb6:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/lower:lowering", ptr %t27, i32 0, i32 44
  store ptr %t29, ptr %l23, !tbaa !29
  %t30 = load ptr, ptr %l4, !tbaa !29
  %t32 = getelementptr %"compiler/typed:Call", ptr %t30, i32 0, i32 2
  %t33 = load i32, ptr %t32, !tbaa !23
  %t35 = sext i32 %t33 to i64
  store i64 %t35, ptr %l26, !tbaa !24
  %t36 = load ptr, ptr %l2, !tbaa !29
  %t38 = icmp eq ptr %t36, null
  %t40 = xor i1 %t38, true
  br i1 %t40, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l30, !tbaa !21
  br label %bb9
bb8:
  %t42 = load ptr, ptr %l3, !tbaa !29
  %t44 = icmp eq ptr %t42, null
  %t46 = xor i1 %t44, true
  store i1 %t46, ptr %l30, !tbaa !21
  br label %bb9
bb9:
  %t48 = load i1, ptr %l30, !tbaa !21
  br i1 %t48, label %bb10, label %bb11
bb10:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t50 = load ptr, ptr %l4, !tbaa !29
  %t51 = load ptr, ptr %l2, !tbaa !29
  %t52 = load ptr, ptr %l3, !tbaa !29
  %t57 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2ewindowQuiet(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t49, ptr %t50, ptr %t51, ptr %t52)
  store i1 %t57, ptr %l39
  br label %bb12
bb11:
  store i1 false, ptr %l34, !tbaa !21
  br label %bb13
bb12:
  %t58 = load i1, ptr %l39, !tbaa !21
  store i1 %t58, ptr %l34, !tbaa !21
  br label %bb13
bb13:
  %t59 = load ptr, ptr %l23, !tbaa !29
  %t60 = load i64, ptr %l26, !tbaa !24
  %t61 = load i1, ptr %l34, !tbaa !21
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t59, i64 %t60, i1 %t61)
  br label %bb14
bb14:
  br label %bb74
bb15:
  %t62 = load ptr, ptr %l1, !tbaa !29
  store ptr %t62, ptr %l40, !tbaa !29
  store i1 false, ptr %l41, !tbaa !21
  %t63 = load ptr, ptr %l40, !tbaa !29
  %t64 = icmp ne ptr %t63, null
  br i1 %t64, label %bb16, label %bb17
bb16:
  %t66 = load ptr, ptr %l40, !tbaa !29
  %t67 = load i64, ptr %t66, !range !{i64 0, i64 18}
  %t69 = icmp eq i64 %t67, 5
  store i1 %t69, ptr %l41, !tbaa !21
  br label %bb17
bb17:
  %t70 = load i1, ptr %l41, !tbaa !21
  br i1 %t70, label %bb18, label %bb19
bb18:
  %t71 = load ptr, ptr %l1, !tbaa !29
  %t73 = getelementptr { i64, [5 x i64] }, ptr %t71, i32 0, i32 1
  %t74 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t73, i32 0, i32 2
  %t75 = load ptr, ptr %t74
  store ptr %t75, ptr %l5, !tbaa !29
  br label %bb20
bb19:
  br label %bb22
bb20:
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t78 = load ptr, ptr %l5, !tbaa !29
  %t80 = getelementptr %"compiler/typed:Promote", ptr %t78, i32 0, i32 0
  %t81 = load ptr, ptr %t80, !tbaa !29
  %t82 = load ptr, ptr %l2, !tbaa !29
  %t83 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2ereadHere(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t77, ptr %t81, ptr %t82, ptr %t83)
  br label %bb21
bb21:
  br label %bb74
bb22:
  %t88 = load ptr, ptr %l1, !tbaa !29
  store ptr %t88, ptr %l51, !tbaa !29
  store i1 false, ptr %l52, !tbaa !21
  %t89 = load ptr, ptr %l51, !tbaa !29
  %t90 = icmp ne ptr %t89, null
  br i1 %t90, label %bb23, label %bb24
bb23:
  %t92 = load ptr, ptr %l51, !tbaa !29
  %t93 = load i64, ptr %t92, !range !{i64 0, i64 18}
  %t95 = icmp eq i64 %t93, 9
  store i1 %t95, ptr %l52, !tbaa !21
  br label %bb24
bb24:
  %t96 = load i1, ptr %l52, !tbaa !21
  br i1 %t96, label %bb25, label %bb26
bb25:
  %t97 = load ptr, ptr %l1, !tbaa !29
  %t99 = getelementptr { i64, [5 x i64] }, ptr %t97, i32 0, i32 1
  %t100 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t99, i32 0, i32 2
  %t101 = load i32, ptr %t100, !range !{i32 0, i32 49}
  store i32 %t101, ptr %l6
  %t103 = load ptr, ptr %l1, !tbaa !29
  %t105 = getelementptr { i64, [5 x i64] }, ptr %t103, i32 0, i32 1
  %t106 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t105, i32 0, i32 4
  %t107 = load { i64, ptr }, ptr %t106
  store { i64, ptr } %t107, ptr %l7, !tbaa !27
  br label %bb27
bb26:
  br label %bb35
bb27:
  %t109 = load i32, ptr %l6, !range !{i32 0, i32 49}
  %t111 = trunc i64 20 to i32
  %t112 = icmp eq i32 %t109, %t111
  br i1 %t112, label %bb28, label %bb29
bb28:
  %t114 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t116 = extractvalue { i64, ptr } %t114, 0
  %t118 = icmp eq i64 %t116, 1
  store i1 %t118, ptr %l61, !tbaa !21
  br label %bb30
bb29:
  store i1 false, ptr %l61, !tbaa !21
  br label %bb30
bb30:
  %t120 = load i1, ptr %l61, !tbaa !21
  br i1 %t120, label %bb31, label %bb32
bb31:
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t122 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t122, ptr %l66, !tbaa !27
  %t123 = getelementptr { i64, ptr }, ptr %l66, i32 0, i32 1
  %t124 = load ptr, ptr %t123, !tbaa !27
  %t125 = getelementptr ptr, ptr %t124, i64 0
  %t126 = load ptr, ptr %t125, !tbaa !39
  %t127 = load ptr, ptr %l2, !tbaa !29
  %t128 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2ereadHere(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t121, ptr %t126, ptr %t127, ptr %t128)
  br label %bb33
bb32:
  br label %bb34
bb33:
  br label %bb34
bb34:
  br label %bb74
bb35:
  %t133 = load ptr, ptr %l1, !tbaa !29
  store ptr %t133, ptr %l70, !tbaa !29
  store i1 false, ptr %l71, !tbaa !21
  %t134 = load ptr, ptr %l70, !tbaa !29
  %t135 = icmp ne ptr %t134, null
  br i1 %t135, label %bb36, label %bb37
bb36:
  %t137 = load ptr, ptr %l70, !tbaa !29
  %t138 = load i64, ptr %t137, !range !{i64 0, i64 18}
  %t140 = icmp eq i64 %t138, 17
  store i1 %t140, ptr %l71, !tbaa !21
  br label %bb37
bb37:
  %t141 = load i1, ptr %l71, !tbaa !21
  br i1 %t141, label %bb38, label %bb39
bb38:
  %t142 = load ptr, ptr %l1, !tbaa !29
  %t144 = getelementptr { i64, [5 x i64] }, ptr %t142, i32 0, i32 1
  %t145 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t144, i32 0, i32 2
  %t146 = load ptr, ptr %t145
  store ptr %t146, ptr %l8, !tbaa !29
  br label %bb40
bb39:
  br label %bb42
bb40:
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t149 = load ptr, ptr %l8, !tbaa !29
  %t150 = load ptr, ptr %l2, !tbaa !29
  %t151 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2ereadHere(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t148, ptr %t149, ptr %t150, ptr %t151)
  br label %bb41
bb41:
  br label %bb74
bb42:
  %t156 = load ptr, ptr %l1, !tbaa !29
  store ptr %t156, ptr %l80, !tbaa !29
  store i1 false, ptr %l81, !tbaa !21
  %t157 = load ptr, ptr %l80, !tbaa !29
  %t158 = icmp ne ptr %t157, null
  br i1 %t158, label %bb43, label %bb44
bb43:
  %t160 = load ptr, ptr %l80, !tbaa !29
  %t161 = load i64, ptr %t160, !range !{i64 0, i64 18}
  %t163 = icmp eq i64 %t161, 12
  store i1 %t163, ptr %l81, !tbaa !21
  br label %bb44
bb44:
  %t164 = load i1, ptr %l81, !tbaa !21
  br i1 %t164, label %bb45, label %bb46
bb45:
  %t165 = load ptr, ptr %l1, !tbaa !29
  %t167 = getelementptr { i64, [5 x i64] }, ptr %t165, i32 0, i32 1
  %t168 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t167, i32 0, i32 2
  %t169 = load ptr, ptr %t168
  store ptr %t169, ptr %l9, !tbaa !29
  br label %bb47
bb46:
  br label %bb58
bb47:
  %t171 = load ptr, ptr %l9, !tbaa !29
  %t173 = getelementptr %"compiler/typed:Seq", ptr %t171, i32 0, i32 1
  %t174 = load ptr, ptr %t173, !tbaa !29
  %t176 = icmp eq ptr %t174, null
  %t178 = xor i1 %t176, true
  br i1 %t178, label %bb48, label %bb49
bb48:
  %t180 = load ptr, ptr %l9, !tbaa !29
  %t182 = getelementptr %"compiler/typed:Seq", ptr %t180, i32 0, i32 0
  %t183 = load { i64, ptr }, ptr %t182, !tbaa !27
  %t185 = extractvalue { i64, ptr } %t183, 0
  %t187 = icmp eq i64 %t185, 0
  store i1 %t187, ptr %l90, !tbaa !21
  br label %bb50
bb49:
  store i1 false, ptr %l90, !tbaa !21
  br label %bb50
bb50:
  %t189 = load i1, ptr %l90, !tbaa !21
  br i1 %t189, label %bb51, label %bb52
bb51:
  %t190 = load ptr, ptr %l0, !tbaa !29
  store ptr %t190, ptr %l95, !tbaa !29
  %t191 = load ptr, ptr %l9, !tbaa !29
  %t193 = getelementptr %"compiler/typed:Seq", ptr %t191, i32 0, i32 1
  %t194 = load ptr, ptr %t193, !tbaa !29
  %t196 = icmp eq ptr %t194, null
  br i1 %t196, label %bb53, label %bb54
bb52:
  br label %bb57
bb53:
  call void @__olang_check_failed(ptr @olang_loc_763e3b2e421df924_4ff52ff107ec1ef8)
  unreachable
bb54:
  br label %bb55
bb55:
  %t198 = load ptr, ptr %l9, !tbaa !29
  %t200 = getelementptr %"compiler/typed:Seq", ptr %t198, i32 0, i32 1
  %t201 = load ptr, ptr %t200, !tbaa !29
  %t202 = load ptr, ptr %l2, !tbaa !29
  %t203 = load ptr, ptr %l3, !tbaa !29
  %t204 = load ptr, ptr %l95, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2ereadHere(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t204, ptr %t201, ptr %t202, ptr %t203)
  br label %bb56
bb56:
  br label %bb57
bb57:
  br label %bb74
bb58:
  %t208 = load ptr, ptr %l1, !tbaa !29
  store ptr %t208, ptr %l103, !tbaa !29
  store i1 false, ptr %l104, !tbaa !21
  %t209 = load ptr, ptr %l103, !tbaa !29
  %t210 = icmp ne ptr %t209, null
  br i1 %t210, label %bb59, label %bb60
bb59:
  %t212 = load ptr, ptr %l103, !tbaa !29
  %t213 = load i64, ptr %t212, !range !{i64 0, i64 18}
  %t215 = icmp eq i64 %t213, 2
  store i1 %t215, ptr %l104, !tbaa !21
  br label %bb60
bb60:
  %t216 = load i1, ptr %l104, !tbaa !21
  br i1 %t216, label %bb61, label %bb62
bb61:
  %t217 = load ptr, ptr %l1, !tbaa !29
  %t219 = getelementptr { i64, [5 x i64] }, ptr %t217, i32 0, i32 1
  %t220 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t219, i32 0, i32 2
  %t221 = load ptr, ptr %t220
  store ptr %t221, ptr %l10, !tbaa !29
  br label %bb67
bb62:
  %t223 = load ptr, ptr %l1, !tbaa !29
  store ptr %t223, ptr %l109, !tbaa !29
  store i1 false, ptr %l110, !tbaa !21
  %t224 = load ptr, ptr %l109, !tbaa !29
  %t225 = icmp ne ptr %t224, null
  br i1 %t225, label %bb63, label %bb64
bb63:
  %t227 = load ptr, ptr %l109, !tbaa !29
  %t228 = load i64, ptr %t227, !range !{i64 0, i64 18}
  %t230 = icmp eq i64 %t228, 3
  store i1 %t230, ptr %l110, !tbaa !21
  br label %bb64
bb64:
  %t231 = load i1, ptr %l110, !tbaa !21
  br i1 %t231, label %bb65, label %bb66
bb65:
  %t232 = load ptr, ptr %l1, !tbaa !29
  %t234 = getelementptr { i64, [5 x i64] }, ptr %t232, i32 0, i32 1
  %t235 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t234, i32 0, i32 2
  %t236 = load ptr, ptr %t235
  store ptr %t236, ptr %l10, !tbaa !29
  br label %bb67
bb66:
  br label %bb69
bb67:
  %t238 = load ptr, ptr %l0, !tbaa !29
  %t239 = load ptr, ptr %l10, !tbaa !29
  %t240 = load ptr, ptr %l2, !tbaa !29
  %t241 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2ereadPlace(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t238, ptr %t239, ptr %t240, ptr %t241)
  br label %bb68
bb68:
  br label %bb74
bb69:
  br i1 true, label %bb70, label %bb71
bb70:
  br label %bb72
bb71:
  br label %bb73
bb72:
  br label %bb74
bb73:
  call void @__olang_check_failed(ptr @olang_loc_92fd471d43b4bd8a_f49bae282c691e2e)
  unreachable
bb74:
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2flower_2ecompiler_2flower_3alowering_2ereadOnly(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l1 = alloca i32
  %l2 = alloca ptr
  %l7 = alloca i1
  %l8 = alloca ptr
  %l11 = alloca i32
  %l14 = alloca i64
  %l18 = alloca i32
  %rv = alloca i32
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/lower:lowering", ptr %a0, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t7 = load i32, ptr %l1, !tbaa !23
  %t10 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t6, i32 %t7)
  store i1 %t10, ptr %l7
  br label %bb1
bb1:
  %t11 = load i1, ptr %l7, !tbaa !21
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t12 = load ptr, ptr %l2, !tbaa !29
  store ptr %t12, ptr %l8, !tbaa !29
  %t13 = load ptr, ptr %l2, !tbaa !29
  %t14 = load i32, ptr %l1, !tbaa !23
  %t17 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t13, i32 %t14)
  store i32 %t17, ptr %l11
  br label %bb4
bb3:
  br label %bb7
bb4:
  %t18 = load ptr, ptr %l2, !tbaa !29
  %t19 = load i32, ptr %l1, !tbaa !23
  %t22 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t18, i32 %t19)
  store i64 %t22, ptr %l14
  br label %bb5
bb5:
  %t23 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t25 = sub i64 -1, %t23
  %t26 = load i64, ptr %l14, !tbaa !24
  %t28 = and i64 %t26, %t25
  %t29 = load ptr, ptr %l8, !tbaa !29
  %t30 = load i32, ptr %l11, !tbaa !23
  %t32 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t29, i32 %t30, i64 %t28)
  store i32 %t32, ptr %l18
  br label %bb6
bb6:
  %t33 = load i32, ptr %l18, !tbaa !23
  store i32 %t33, ptr %rv
  br label %ret
bb7:
  %t34 = load i32, ptr %l1, !tbaa !23
  store i32 %t34, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2ereadOut(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l6 = alloca i1
  %l9 = alloca i1
  %l10 = alloca ptr
  %l11 = alloca i1
  %l14 = alloca ptr
  %l15 = alloca i1
  %l18 = alloca ptr
  %l19 = alloca i1
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 19
  %t4 = load i1, ptr %t3, !tbaa !21
  %t6 = xor i1 %t4, true
  br i1 %t6, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb4
bb2:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t12 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eviewValue(ptr %v0, ptr %t8, i32 %a2)
  store i1 %t12, ptr %l9
  br label %bb3
bb3:
  %t13 = load i1, ptr %l9, !tbaa !21
  store i1 %t13, ptr %l6, !tbaa !21
  br label %bb4
bb4:
  %t14 = load i1, ptr %l6, !tbaa !21
  br i1 %t14, label %bb5, label %bb6
bb5:
  br label %ret
bb6:
  br label %bb7
bb7:
  %t15 = load ptr, ptr %l1, !tbaa !29
  store ptr %t15, ptr %l10, !tbaa !29
  store i1 false, ptr %l11, !tbaa !21
  %t16 = load ptr, ptr %l10, !tbaa !29
  %t17 = icmp ne ptr %t16, null
  br i1 %t17, label %bb8, label %bb9
bb8:
  %t19 = load ptr, ptr %l10, !tbaa !29
  %t20 = load i64, ptr %t19, !range !{i64 0, i64 8}
  %t22 = icmp eq i64 %t20, 3
  store i1 %t22, ptr %l11, !tbaa !21
  br label %bb9
bb9:
  %t23 = load i1, ptr %l11, !tbaa !21
  br i1 %t23, label %bb10, label %bb11
bb10:
  br label %bb20
bb11:
  %t24 = load ptr, ptr %l1, !tbaa !29
  store ptr %t24, ptr %l14, !tbaa !29
  store i1 false, ptr %l15, !tbaa !21
  %t25 = load ptr, ptr %l14, !tbaa !29
  %t26 = icmp ne ptr %t25, null
  br i1 %t26, label %bb12, label %bb13
bb12:
  %t28 = load ptr, ptr %l14, !tbaa !29
  %t29 = load i64, ptr %t28, !range !{i64 0, i64 8}
  %t31 = icmp eq i64 %t29, 5
  store i1 %t31, ptr %l15, !tbaa !21
  br label %bb13
bb13:
  %t32 = load i1, ptr %l15, !tbaa !21
  br i1 %t32, label %bb14, label %bb15
bb14:
  br label %bb20
bb15:
  %t33 = load ptr, ptr %l1, !tbaa !29
  store ptr %t33, ptr %l18, !tbaa !29
  store i1 false, ptr %l19, !tbaa !21
  %t34 = load ptr, ptr %l18, !tbaa !29
  %t35 = icmp ne ptr %t34, null
  br i1 %t35, label %bb16, label %bb17
bb16:
  %t37 = load ptr, ptr %l18, !tbaa !29
  %t38 = load i64, ptr %t37, !range !{i64 0, i64 8}
  %t40 = icmp eq i64 %t38, 4
  store i1 %t40, ptr %l19, !tbaa !21
  br label %bb17
bb17:
  %t41 = load i1, ptr %l19, !tbaa !21
  br i1 %t41, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb22
bb20:
  store %olang.scope zeroinitializer, ptr %s2
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t43 = load ptr, ptr %l1, !tbaa !29
  %t44 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2ereadPlace(ptr %v0, ptr %v1, ptr %s2, ptr %v1, ptr %t42, ptr %t43, ptr null, ptr %t44)
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s2)
  br label %bb27
bb22:
  br i1 true, label %bb23, label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb27
bb26:
  call void @__olang_check_failed(ptr @olang_loc_ed0da5981c7956e3_375966c562f70de7)
  unreachable
bb27:
  br label %ret
ret:
  ret void
}

define dso_local { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2erefTo(ptr %v0, ptr %v1, ptr %a0, %"compiler/lower:pl" %a1, i32 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca i32
  %l9 = alloca i32
  %l10 = alloca ptr
  %l11 = alloca i32
  %l12 = alloca ptr
  %l13 = alloca %"compiler/lower:pl"
  %l15 = alloca %"compiler/lower:pl"
  %l16 = alloca %"compiler/mir:Lvalue"
  %l20 = alloca { i64, [4 x i64] }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, [4 x i64] }
  %t22 = alloca { i64, [15 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t4, i32 %a2, i64 %t6)
  store i32 %t10, ptr %l9
  br label %bb1
bb1:
  %t11 = load i32, ptr %l9, !tbaa !23
  store i32 %t11, ptr %l4, !tbaa !23
  %t12 = load ptr, ptr %l0, !tbaa !29
  store ptr %t12, ptr %l10, !tbaa !29
  %t13 = load i32, ptr %l4, !tbaa !23
  store i32 %t13, ptr %l11, !tbaa !23
  %t14 = load ptr, ptr %l0, !tbaa !29
  store ptr %t14, ptr %l12, !tbaa !29
  store %"compiler/lower:pl" %a1, ptr %l13
  %t17 = call %"compiler/lower:pl" @olang_2eHelperKind_2eCopy_2ecompiler_2flower_3apl(ptr %s0, ptr %l13)
  store %"compiler/lower:pl" %t17, ptr %l15
  br label %bb2
bb2:
  %t18 = load ptr, ptr %l12, !tbaa !29
  %t19 = load %"compiler/lower:pl", ptr %l15
  %t20 = call %"compiler/mir:Lvalue" @compiler_2flower_2ecompiler_2flower_3alowering_2emk(ptr %v0, ptr %s0, ptr %t18, %"compiler/lower:pl" %t19)
  store %"compiler/mir:Lvalue" %t20, ptr %l16
  br label %bb3
bb3:
  %t21 = load i32, ptr %l4, !tbaa !23
  store { i64, [15 x i64] } zeroinitializer, ptr %t22
  %t23 = getelementptr { i64, [15 x i64] }, ptr %t22, i32 0, i32 0
  store i64 1, ptr %t23
  %t24 = load %"compiler/mir:Lvalue", ptr %l16
  %t25 = insertvalue { %"compiler/mir:Lvalue", i32 } undef, %"compiler/mir:Lvalue" %t24, 0
  %t27 = insertvalue { %"compiler/mir:Lvalue", i32 } %t25, i32 %t21, 1
  %t28 = getelementptr { i64, [15 x i64] }, ptr %t22, i32 0, i32 1
  store { %"compiler/mir:Lvalue", i32 } %t27, ptr %t28
  %t29 = load { i64, [15 x i64] }, ptr %t22
  %t31 = load ptr, ptr %l10, !tbaa !29
  %t32 = load i32, ptr %l11, !tbaa !23
  %t35 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %t31, i32 %t32, { i64, [15 x i64] } %t29, %"compiler/source:Span" %a3)
  store { i64, [4 x i64] } %t35, ptr %l20
  br label %bb4
bb4:
  call void @__olang_scope_close(ptr %s0)
  %t36 = load { i64, [4 x i64] }, ptr %l20
  store { i64, [4 x i64] } %t36, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2ereleaseAt(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"compiler/lower:pl"
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l13 = alloca i64
  %l15 = alloca i64
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca { i64, ptr }
  %l25 = alloca %"compiler/lower:pl"
  %l33 = alloca { i64, ptr }
  %l36 = alloca ptr
  %l37 = alloca %"compiler/lower:pl"
  %l39 = alloca %"compiler/lower:pl"
  %l42 = alloca %"compiler/lower:pl"
  %l45 = alloca ptr
  %l46 = alloca %"compiler/source:Span"
  %l47 = alloca ptr
  %l48 = alloca %"compiler/lower:pl"
  %l50 = alloca %"compiler/lower:pl"
  %l51 = alloca %"compiler/mir:Lvalue"
  %l52 = alloca { i64, [21 x i64] }
  %s2 = alloca %olang.scope
  %t33 = alloca { i64, [2 x i64] }, align 8
  %t69 = alloca { i64, [1 x i64] }, align 8
  %t93 = alloca { i64, [21 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a2, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t3 = load i64, ptr %l5, !tbaa !24
  store i64 %t3, ptr %l13, !tbaa !24
  %t4 = load ptr, ptr %l4, !tbaa !29
  %t6 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_3e_2eLen_3cArray_3cI64_3e_3e(ptr %v1, ptr %t4)
  store i64 %t6, ptr %l15
  br label %bb2
bb2:
  %t7 = load i64, ptr %l13, !tbaa !24
  %t8 = load i64, ptr %l15, !tbaa !24
  %t9 = icmp slt i64 %t7, %t8
  %t11 = xor i1 %t9, true
  br i1 %t11, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb20
bb4:
  br label %bb5
bb5:
  %t13 = load ptr, ptr %l4, !tbaa !29
  %t14 = load i64, ptr %l5, !tbaa !24
  %t17 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_3e_2eAt_3cArray_3cI64_3e_3e(ptr %v1, ptr %s2, ptr %t13, i64 %t14)
  store { i64, ptr } %t17, ptr %l20
  br label %bb6
bb6:
  %t18 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t19 = extractvalue { i64, ptr } %t18, 0
  store i64 %t19, ptr %l21, !tbaa !24
  %t20 = load i64, ptr %l21, !tbaa !24
  %t21 = mul i64 %t20, 8
  %t22 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t21)
  %t23 = insertvalue { i64, ptr } undef, i64 %t20, 0
  %t24 = insertvalue { i64, ptr } %t23, ptr %t22, 1
  store { i64, ptr } %t24, ptr %l22, !tbaa !27
  %t25 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !27
  %t29 = load i64, ptr %l21, !tbaa !24
  %t30 = mul i64 %t29, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t26, ptr %t28, i64 %t30, i1 false)
  %t31 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t31, ptr %l6, !tbaa !27
  store { i64, [2 x i64] } zeroinitializer, ptr %t33
  %t34 = getelementptr { i64, [2 x i64] }, ptr %t33, i32 0, i32 0
  store i64 1, ptr %t34
  %t36 = insertvalue { i32 } undef, i32 %a1, 0
  %t37 = getelementptr { i64, [2 x i64] }, ptr %t33, i32 0, i32 1
  store { i32 } %t36, ptr %t37
  %t38 = load { i64, [2 x i64] }, ptr %t33
  %t40 = call %"compiler/lower:pl" @compiler_2flower_3apl_2ector(ptr %s2, { i64, [2 x i64] } %t38)
  store %"compiler/lower:pl" %t40, ptr %l25
  br label %bb7
bb7:
  %t41 = load %"compiler/lower:pl", ptr %l25
  store %"compiler/lower:pl" %t41, ptr %l7
  %t42 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t42, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t44 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t46 = extractvalue { i64, ptr } %t44, 0
  store i64 %t46, ptr %l10, !tbaa !24
  br label %bb8
bb8:
  %t48 = load i64, ptr %l9, !tbaa !24
  %t49 = load i64, ptr %l10, !tbaa !24
  %t52 = icmp slt i64 %t48, %t49
  %t54 = xor i1 %t52, true
  br i1 %t54, label %bb9, label %bb10
bb9:
  br label %bb15
bb10:
  br label %bb11
bb11:
  %t56 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t56, ptr %l33, !tbaa !27
  %t57 = load i64, ptr %l9, !tbaa !24
  %t59 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !27
  %t61 = getelementptr i64, ptr %t60, i64 %t57
  %t62 = load i64, ptr %t61, !tbaa !34
  store i64 %t62, ptr %l11, !tbaa !24
  %t64 = load ptr, ptr %l0, !tbaa !29
  store ptr %t64, ptr %l36, !tbaa !29
  %t65 = load %"compiler/lower:pl", ptr %l7
  store %"compiler/lower:pl" %t65, ptr %l37
  %t67 = call %"compiler/lower:pl" @olang_2eHelperKind_2eCopy_2ecompiler_2flower_3apl(ptr %s2, ptr %l37)
  store %"compiler/lower:pl" %t67, ptr %l39
  br label %bb12
bb12:
  %t68 = load i64, ptr %l11, !tbaa !24
  store { i64, [1 x i64] } zeroinitializer, ptr %t69
  %t70 = getelementptr { i64, [1 x i64] }, ptr %t69, i32 0, i32 0
  store i64 0, ptr %t70
  %t72 = insertvalue { i64 } undef, i64 %t68, 0
  %t73 = getelementptr { i64, [1 x i64] }, ptr %t69, i32 0, i32 1
  store { i64 } %t72, ptr %t73
  %t74 = load { i64, [1 x i64] }, ptr %t69
  %t75 = load ptr, ptr %l36, !tbaa !29
  %t76 = load %"compiler/lower:pl", ptr %l39
  %t78 = call %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2ewith(ptr %v0, ptr %s2, ptr %s2, ptr %t75, %"compiler/lower:pl" %t76, { i64, [1 x i64] } %t74)
  store %"compiler/lower:pl" %t78, ptr %l42
  br label %bb13
bb13:
  %t79 = load %"compiler/lower:pl", ptr %l42
  store %"compiler/lower:pl" %t79, ptr %l7
  br label %bb14
bb14:
  %t80 = load i64, ptr %l9, !tbaa !24
  %t82 = add i64 %t80, 1
  store i64 %t82, ptr %l9, !tbaa !24
  br label %bb8
bb15:
  %t84 = load ptr, ptr %l0, !tbaa !29
  store ptr %t84, ptr %l45, !tbaa !29
  store %"compiler/source:Span" %a3, ptr %l46
  %t86 = load ptr, ptr %l0, !tbaa !29
  store ptr %t86, ptr %l47, !tbaa !29
  %t87 = load %"compiler/lower:pl", ptr %l7
  store %"compiler/lower:pl" %t87, ptr %l48
  %t89 = call %"compiler/lower:pl" @olang_2eHelperKind_2eCopy_2ecompiler_2flower_3apl(ptr %s2, ptr %l48)
  store %"compiler/lower:pl" %t89, ptr %l50
  br label %bb16
bb16:
  %t90 = load ptr, ptr %l47, !tbaa !29
  %t91 = load %"compiler/lower:pl", ptr %l50
  %t92 = call %"compiler/mir:Lvalue" @compiler_2flower_2ecompiler_2flower_3alowering_2emk(ptr %v0, ptr %s2, ptr %t90, %"compiler/lower:pl" %t91)
  store %"compiler/mir:Lvalue" %t92, ptr %l51
  br label %bb17
bb17:
  store { i64, [21 x i64] } zeroinitializer, ptr %t93
  %t94 = getelementptr { i64, [21 x i64] }, ptr %t93, i32 0, i32 0
  store i64 6, ptr %t94
  %t95 = load %"compiler/source:Span", ptr %l46
  %t96 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue" } undef, %"compiler/source:Span" %t95, 0
  %t97 = load %"compiler/mir:Lvalue", ptr %l51
  %t98 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue" } %t96, %"compiler/mir:Lvalue" %t97, 1
  %t99 = getelementptr { i64, [21 x i64] }, ptr %t93, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Lvalue" } %t98, ptr %t99
  %t100 = load { i64, [21 x i64] }, ptr %t93
  store { i64, [21 x i64] } %t100, ptr %l52
  %t101 = load ptr, ptr %l45, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s2, ptr %t101, ptr %l52)
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s2)
  br label %bb19
bb19:
  %t103 = load i64, ptr %l5, !tbaa !24
  %t105 = add i64 %t103, 1
  store i64 %t105, ptr %l5, !tbaa !24
  br label %bb1
bb20:
  br label %ret
ret:
  ret void
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2flower_2ecompiler_2flower_3alowering_2ereleases(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i1 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %lp3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca %"compiler/source:Span"
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca %"compiler/source:Span"
  %l10 = alloca i32
  %l12 = alloca ptr
  %l13 = alloca i64
  %l14 = alloca %"compiler/free:leaf"
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l28 = alloca ptr
  %l29 = alloca i1
  %l42 = alloca i64
  %l43 = alloca ptr
  %l44 = alloca i1
  %l47 = alloca i1
  %l68 = alloca i64
  %l71 = alloca ptr
  %l74 = alloca i1
  %l75 = alloca { i64, ptr }
  %l76 = alloca { i64, ptr }
  %l81 = alloca ptr
  %l83 = alloca i32
  %l84 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l86 = alloca i64
  %l88 = alloca i64
  %l93 = alloca %"compiler/free:leaf"
  %l95 = alloca %"compiler/free:leaf"
  %l98 = alloca i1
  %l101 = alloca i64
  %l110 = alloca i64
  %l113 = alloca i64
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i1 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l22
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 32, i64 8)
  store ptr %t2, ptr %lp3
  %t3 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l22
  %t4 = load ptr, ptr %lp3
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %t4
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/lower:lowering", ptr %t5, i32 0, i32 25
  %t8 = load i1, ptr %t7, !tbaa !21
  %t10 = xor i1 %t8, true
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = load ptr, ptr %lp3
  %t13 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t12
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t13, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t15 = load i1, ptr %l2, !tbaa !21
  br i1 %t15, label %bb5, label %bb6
bb5:
  %t17 = load ptr, ptr %l1, !tbaa !29
  store ptr %t17, ptr %l28, !tbaa !29
  store i1 false, ptr %l29, !tbaa !21
  %t18 = load ptr, ptr %l28, !tbaa !29
  %t19 = icmp ne ptr %t18, null
  br i1 %t19, label %bb7, label %bb8
bb6:
  br label %bb18
bb7:
  %t21 = load ptr, ptr %l28, !tbaa !29
  %t22 = load i64, ptr %t21, !range !{i64 0, i64 8}
  %t24 = icmp eq i64 %t22, 4
  store i1 %t24, ptr %l29, !tbaa !21
  br label %bb8
bb8:
  %t25 = load i1, ptr %l29, !tbaa !21
  br i1 %t25, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  %t26 = load ptr, ptr %lp3
  %t27 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t26
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t27, ptr %rv
  br label %ret
bb12:
  br i1 true, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb17
bb16:
  call void @__olang_check_failed(ptr @olang_loc_b05049138e3c9583_5b10da44a83c4f97)
  unreachable
bb17:
  br label %bb18
bb18:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/lower:lowering", ptr %t29, i32 0, i32 0
  %t32 = load ptr, ptr %t31, !tbaa !29
  %t34 = getelementptr %"compiler/lower:Lowerer", ptr %t32, i32 0, i32 3
  %t35 = load ptr, ptr %t34, !tbaa !29
  %t37 = icmp eq ptr %t35, null
  br i1 %t37, label %bb19, label %bb20
bb19:
  call void @__olang_check_failed(ptr @olang_loc_7978ceed25dd57db_b68e0a2baf6deaf)
  unreachable
bb20:
  br label %bb21
bb21:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/lower:lowering", ptr %t39, i32 0, i32 0
  %t42 = load ptr, ptr %t41, !tbaa !29
  %t44 = getelementptr %"compiler/lower:Lowerer", ptr %t42, i32 0, i32 3
  %t45 = load ptr, ptr %t44, !tbaa !29
  store ptr %t45, ptr %l4, !tbaa !29
  %t47 = load ptr, ptr %l4, !tbaa !29
  %t48 = load ptr, ptr %l1, !tbaa !29
  %t51 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eSolePlace(ptr %v0, ptr %v1, ptr %t47, ptr %t48)
  store i64 %t51, ptr %l42
  br label %bb22
bb22:
  %t52 = load i64, ptr %l42, !tbaa !24
  store i64 %t52, ptr %l5, !tbaa !24
  %t53 = load ptr, ptr %l1, !tbaa !29
  store ptr %t53, ptr %l43, !tbaa !29
  store i1 false, ptr %l44, !tbaa !21
  %t54 = load ptr, ptr %l43, !tbaa !29
  %t55 = icmp ne ptr %t54, null
  br i1 %t55, label %bb23, label %bb24
bb23:
  %t57 = load ptr, ptr %l43, !tbaa !29
  %t58 = load i64, ptr %t57, !range !{i64 0, i64 8}
  %t60 = icmp eq i64 %t58, 0
  store i1 %t60, ptr %l44, !tbaa !21
  br label %bb24
bb24:
  %t61 = load i1, ptr %l44, !tbaa !21
  br i1 %t61, label %bb25, label %bb26
bb25:
  %t62 = load ptr, ptr %l1, !tbaa !29
  %t64 = getelementptr { i64, [4 x i64] }, ptr %t62, i32 0, i32 1
  %t65 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t64, i32 0, i32 0
  %t66 = load %"compiler/source:Span", ptr %t65
  store %"compiler/source:Span" %t66, ptr %l6
  %t68 = load ptr, ptr %l1, !tbaa !29
  %t70 = getelementptr { i64, [4 x i64] }, ptr %t68, i32 0, i32 1
  %t71 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t70, i32 0, i32 1
  %t72 = load i32, ptr %t71
  store i32 %t72, ptr %l7, !tbaa !23
  %t74 = load ptr, ptr %l1, !tbaa !29
  %t76 = getelementptr { i64, [4 x i64] }, ptr %t74, i32 0, i32 1
  %t77 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t76, i32 0, i32 2
  %t78 = load i32, ptr %t77
  store i32 %t78, ptr %l8, !tbaa !23
  %t80 = load i1, ptr %l2, !tbaa !21
  store i1 %t80, ptr %l47, !tbaa !21
  br label %bb27
bb26:
  store i1 false, ptr %l47, !tbaa !21
  br label %bb27
bb27:
  %t82 = load i1, ptr %l47, !tbaa !21
  br i1 %t82, label %bb28, label %bb29
bb28:
  %t83 = load ptr, ptr %l1, !tbaa !29
  %t85 = getelementptr { i64, [4 x i64] }, ptr %t83, i32 0, i32 1
  %t86 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t85, i32 0, i32 0
  %t87 = load %"compiler/source:Span", ptr %t86
  store %"compiler/source:Span" %t87, ptr %l9
  %t89 = load ptr, ptr %l1, !tbaa !29
  %t91 = getelementptr { i64, [4 x i64] }, ptr %t89, i32 0, i32 1
  %t92 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t91, i32 0, i32 1
  %t93 = load i32, ptr %t92
  store i32 %t93, ptr %l10, !tbaa !23
  %t95 = load ptr, ptr %l1, !tbaa !29
  %t97 = getelementptr { i64, [4 x i64] }, ptr %t95, i32 0, i32 1
  %t98 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t97, i32 0, i32 2
  %t99 = load i32, ptr %t98
  %t101 = load ptr, ptr %l4, !tbaa !29
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = getelementptr %"compiler/lower:lowering", ptr %t102, i32 0, i32 1
  %t105 = load ptr, ptr %t104, !tbaa !29
  %t107 = getelementptr %"compiler/typed:Body", ptr %t105, i32 0, i32 0
  %t108 = load i32, ptr %t107, !tbaa !23
  %t110 = sext i32 %t108 to i64
  %t113 = sext i32 %t99 to i64
  %t117 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eSoleLocal(ptr %v0, ptr %t101, i64 %t110, i64 %t113)
  store i64 %t117, ptr %l68
  br label %bb30
bb29:
  br label %bb31
bb30:
  %t118 = load i64, ptr %l68, !tbaa !24
  store i64 %t118, ptr %l5, !tbaa !24
  br label %bb31
bb31:
  %t119 = load i64, ptr %l5, !tbaa !24
  %t121 = icmp sge i64 %t119, 0
  br i1 %t121, label %bb32, label %bb33
bb32:
  store %olang.scope zeroinitializer, ptr %s6
  %t123 = load ptr, ptr %lp3
  store ptr %t123, ptr %l71, !tbaa !29
  %t124 = load ptr, ptr %l4, !tbaa !29
  %t125 = load i64, ptr %l5, !tbaa !24
  %t128 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eIsHandle(ptr %v0, ptr %t124, i64 %t125)
  store i1 %t128, ptr %l74
  br label %bb34
bb33:
  br label %bb43
bb34:
  %t129 = load i1, ptr %l74, !tbaa !21
  br i1 %t129, label %bb35, label %bb36
bb35:
  %t130 = mul i64 1, 8
  %t131 = call ptr @__olang_scope_alloc_zeroed(ptr %s6, i64 %t130)
  %t132 = insertvalue { i64, ptr } undef, i64 1, 0
  %t133 = insertvalue { i64, ptr } %t132, ptr %t131, 1
  store { i64, ptr } %t133, ptr %l76, !tbaa !27
  %t134 = getelementptr { i64, ptr }, ptr %l76, i32 0, i32 1
  %t135 = load ptr, ptr %t134, !tbaa !27
  %t136 = getelementptr i64, ptr %t135, i64 0
  store i64 0, ptr %t136, !tbaa !34
  %t137 = load { i64, ptr }, ptr %l76, !tbaa !27
  store { i64, ptr } %t137, ptr %l75, !tbaa !27
  br label %bb41
bb36:
  %t138 = icmp sge i64 0, 0
  br i1 %t138, label %bb37, label %bb38
bb37:
  %t140 = icmp sle i64 0, 1152921504606846975
  br i1 %t140, label %bb39, label %bb40
bb38:
  call void @__olang_check_failed(ptr @olang_loc_6cf042e1e67efefa_11456615317dde16)
  unreachable
bb39:
  %t142 = mul i64 0, 8
  %t143 = insertvalue { i64, ptr } undef, i64 0, 0
  %t144 = insertvalue { i64, ptr } %t143, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t144, ptr %l75, !tbaa !27
  br label %bb41
bb40:
  call void @__olang_check_failed(ptr @olang_loc_6cf042e1e67efefa_11456615317dde16)
  unreachable
bb41:
  %t146 = load ptr, ptr %l71, !tbaa !29
  %t147 = load { i64, ptr }, ptr %l75, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_3e_2ePush_3cArray_3cI64_3e_3e(ptr %v2, ptr %t146, { i64, ptr } %t147)
  br label %bb42
bb42:
  %t148 = load ptr, ptr %lp3
  %t149 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t148
  call void @__olang_scope_close(ptr %s6)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t149, ptr %rv
  br label %ret
bb43:
  store %olang.scope zeroinitializer, ptr %s7
  %t151 = load ptr, ptr %l4, !tbaa !29
  store ptr %t151, ptr %l81, !tbaa !29
  %t152 = load ptr, ptr %l1, !tbaa !29
  %t154 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v1, ptr %t152)
  store i32 %t154, ptr %l83
  br label %bb44
bb44:
  %t155 = load ptr, ptr %l81, !tbaa !29
  %t156 = load i32, ptr %l83, !tbaa !23
  %t157 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3aFree_2eSoleLeaves(ptr %v0, ptr %s7, ptr %t155, i32 %t156)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t157, ptr %l84
  br label %bb45
bb45:
  %t158 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l84
  %t159 = call ptr @__olang_scope_alloc_a(ptr %s7, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t158, ptr %t159
  store ptr %t159, ptr %l12, !tbaa !29
  store i64 0, ptr %l13, !tbaa !24
  br label %bb46
bb46:
  store %olang.scope zeroinitializer, ptr %s8
  %t161 = load i64, ptr %l13, !tbaa !24
  store i64 %t161, ptr %l86, !tbaa !24
  %t162 = load ptr, ptr %l12, !tbaa !29
  %t164 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2eLen_3ccompiler_2ffree_3aleaf_3e(ptr %s7, ptr %t162)
  store i64 %t164, ptr %l88
  br label %bb47
bb47:
  %t165 = load i64, ptr %l86, !tbaa !24
  %t166 = load i64, ptr %l88, !tbaa !24
  %t167 = icmp slt i64 %t165, %t166
  %t169 = xor i1 %t167, true
  br i1 %t169, label %bb48, label %bb49
bb48:
  call void @__olang_scope_close(ptr %s8)
  br label %bb76
bb49:
  br label %bb50
bb50:
  %t171 = load ptr, ptr %l12, !tbaa !29
  %t172 = load i64, ptr %l13, !tbaa !24
  %t175 = call %"compiler/free:leaf" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2eAt_3ccompiler_2ffree_3aleaf_3e(ptr %s7, ptr %s7, ptr %t171, i64 %t172)
  store %"compiler/free:leaf" %t175, ptr %l93
  br label %bb51
bb51:
  %t177 = call %"compiler/free:leaf" @olang_2eHelperKind_2eCopy_2ecompiler_2ffree_3aleaf(ptr %s8, ptr %l93)
  store %"compiler/free:leaf" %t177, ptr %l95
  br label %bb52
bb52:
  %t178 = load %"compiler/free:leaf", ptr %l95
  store %"compiler/free:leaf" %t178, ptr %l14
  %t179 = load ptr, ptr %l4, !tbaa !29
  %t180 = getelementptr %"compiler/free:leaf", ptr %l14, i32 0, i32 1
  %t181 = load i64, ptr %t180, !tbaa !24
  %t184 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eIsHandle(ptr %v0, ptr %t179, i64 %t181)
  store i1 %t184, ptr %l98
  br label %bb53
bb53:
  %t185 = load i1, ptr %l98, !tbaa !21
  br i1 %t185, label %bb54, label %bb55
bb54:
  store %olang.scope zeroinitializer, ptr %s9
  %t186 = getelementptr %"compiler/free:leaf", ptr %l14, i32 0, i32 0
  %t187 = load { i64, ptr }, ptr %t186, !tbaa !27
  %t189 = extractvalue { i64, ptr } %t187, 0
  %t191 = add i64 %t189, 1
  store i64 %t191, ptr %l101, !tbaa !24
  %t192 = load i64, ptr %l101, !tbaa !24
  %t193 = icmp sge i64 %t192, 0
  br i1 %t193, label %bb56, label %bb57
bb55:
  %t195 = load ptr, ptr %lp3
  %t196 = getelementptr %"compiler/free:leaf", ptr %l14, i32 0, i32 0
  %t197 = load { i64, ptr }, ptr %t196, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_3e_2ePush_3cArray_3cI64_3e_3e(ptr %v2, ptr %t195, { i64, ptr } %t197)
  br label %bb73
bb56:
  %t200 = load i64, ptr %l101, !tbaa !24
  %t201 = icmp sle i64 %t200, 1152921504606846975
  br i1 %t201, label %bb58, label %bb59
bb57:
  call void @__olang_check_failed(ptr @olang_loc_16ea37ec2dd8d64f_b36c061d5e238e2b)
  unreachable
bb58:
  %t203 = load i64, ptr %l101, !tbaa !24
  %t204 = mul i64 %t203, 8
  %t205 = call ptr @__olang_scope_alloc_zeroed(ptr %s9, i64 %t204)
  %t206 = insertvalue { i64, ptr } undef, i64 %t203, 0
  %t207 = insertvalue { i64, ptr } %t206, ptr %t205, 1
  store { i64, ptr } %t207, ptr %l15, !tbaa !27
  store i64 0, ptr %l16, !tbaa !24
  %t209 = getelementptr %"compiler/free:leaf", ptr %l14, i32 0, i32 0
  %t210 = load { i64, ptr }, ptr %t209, !tbaa !27
  %t212 = extractvalue { i64, ptr } %t210, 0
  store i64 %t212, ptr %l17, !tbaa !24
  store i64 1, ptr %l18, !tbaa !24
  %t214 = load i64, ptr %l17, !tbaa !24
  %t215 = load i64, ptr %l16, !tbaa !24
  %t218 = icmp sgt i64 %t214, %t215
  br i1 %t218, label %bb60, label %bb61
bb59:
  call void @__olang_check_failed(ptr @olang_loc_16ea37ec2dd8d64f_b36c061d5e238e2b)
  unreachable
bb60:
  %t220 = load i64, ptr %l18, !tbaa !24
  %t222 = icmp sgt i64 %t220, 0
  br i1 %t222, label %bb62, label %bb63
bb61:
  store i64 0, ptr %l110, !tbaa !24
  br label %bb65
bb62:
  %t224 = load i64, ptr %l17, !tbaa !24
  %t225 = load i64, ptr %l16, !tbaa !24
  %t228 = sub i64 %t224, %t225
  %t229 = load i64, ptr %l18, !tbaa !24
  %t232 = add i64 %t228, %t229
  %t234 = sub i64 %t232, 1
  %t235 = load i64, ptr %l18, !tbaa !24
  %t238 = sdiv i64 %t234, %t235
  store i64 %t238, ptr %l113, !tbaa !24
  br label %bb64
bb63:
  store i64 0, ptr %l113, !tbaa !24
  br label %bb64
bb64:
  %t240 = load i64, ptr %l113, !tbaa !24
  store i64 %t240, ptr %l110, !tbaa !24
  br label %bb65
bb65:
  %t241 = load i64, ptr %l110, !tbaa !24
  store i64 %t241, ptr %l19, !tbaa !24
  store i64 0, ptr %l20, !tbaa !24
  br label %bb66
bb66:
  %t242 = load i64, ptr %l20, !tbaa !24
  %t243 = load i64, ptr %l19, !tbaa !24
  %t246 = icmp slt i64 %t242, %t243
  %t248 = xor i1 %t246, true
  br i1 %t248, label %bb67, label %bb68
bb67:
  br label %bb71
bb68:
  br label %bb69
bb69:
  %t250 = load i64, ptr %l16, !tbaa !24
  %t251 = load i64, ptr %l20, !tbaa !24
  %t252 = load i64, ptr %l18, !tbaa !24
  %t255 = mul i64 %t251, %t252
  %t258 = add i64 %t250, %t255
  store i64 %t258, ptr %l21, !tbaa !24
  %t260 = load i64, ptr %l21, !tbaa !24
  %t261 = load i64, ptr %l21, !tbaa !24
  %t262 = getelementptr %"compiler/free:leaf", ptr %l14, i32 0, i32 0
  %t264 = getelementptr { i64, ptr }, ptr %t262, i32 0, i32 1
  %t265 = load ptr, ptr %t264, !tbaa !27
  %t266 = getelementptr i64, ptr %t265, i64 %t261
  %t267 = load i64, ptr %t266, !tbaa !34
  %t270 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t271 = load ptr, ptr %t270, !tbaa !27
  %t272 = getelementptr i64, ptr %t271, i64 %t260
  store i64 %t267, ptr %t272, !tbaa !34
  br label %bb70
bb70:
  %t273 = load i64, ptr %l20, !tbaa !24
  %t275 = add i64 %t273, 1
  store i64 %t275, ptr %l20, !tbaa !24
  br label %bb66
bb71:
  %t277 = getelementptr %"compiler/free:leaf", ptr %l14, i32 0, i32 0
  %t278 = load { i64, ptr }, ptr %t277, !tbaa !27
  %t280 = extractvalue { i64, ptr } %t278, 0
  %t282 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t283 = load ptr, ptr %t282, !tbaa !27
  %t284 = getelementptr i64, ptr %t283, i64 %t280
  store i64 0, ptr %t284, !tbaa !34
  %t285 = load ptr, ptr %lp3
  %t286 = load { i64, ptr }, ptr %l15, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_3e_2ePush_3cArray_3cI64_3e_3e(ptr %v2, ptr %t285, { i64, ptr } %t286)
  br label %bb72
bb72:
  call void @__olang_scope_close(ptr %s9)
  br label %bb74
bb73:
  br label %bb74
bb74:
  call void @__olang_scope_close(ptr %s8)
  br label %bb75
bb75:
  %t289 = load i64, ptr %l13, !tbaa !24
  %t291 = add i64 %t289, 1
  store i64 %t291, ptr %l13, !tbaa !24
  br label %bb46
bb76:
  call void @__olang_scope_close(ptr %s7)
  %t293 = load ptr, ptr %lp3
  %t294 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t293
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t294, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2erunDefers(ptr %v0, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca %"compiler/lower:level"
  %l4 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l6 = alloca i1
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca i64
  %l16 = alloca ptr
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i1
  %l20 = alloca ptr
  %l21 = alloca i64
  %l26 = alloca %"compiler/lower:level"
  %l27 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l30 = alloca i64
  %l35 = alloca ptr
  %l36 = alloca %"compiler/lower:level"
  %l39 = alloca %"compiler/lower:level"
  %l40 = alloca i32
  %l41 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l46 = alloca i64
  %l50 = alloca i64
  %l53 = alloca i64
  %l74 = alloca i32
  %l77 = alloca i1
  %l82 = alloca i1
  %l88 = alloca i64
  %l90 = alloca i64
  %l95 = alloca i64
  %l103 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l105 = alloca i64
  %l107 = alloca i64
  %l112 = alloca i64
  %l116 = alloca i1
  %l119 = alloca i1
  %l121 = alloca ptr
  %l124 = alloca ptr
  %l128 = alloca ptr
  %l132 = alloca %"compiler/typed:BlockInfo"
  %l136 = alloca { i64, [21 x i64] }
  %l140 = alloca ptr
  %l143 = alloca i1
  %l144 = alloca ptr
  %l148 = alloca ptr
  %l154 = alloca i64
  %l156 = alloca i64
  %l161 = alloca i64
  %l169 = alloca i64
  %l173 = alloca ptr
  %l174 = alloca %"compiler/lower:level"
  %l176 = alloca %"compiler/lower:level"
  %l177 = alloca i32
  %s0 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %t223 = alloca { i64, [21 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 9
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call %"compiler/lower:level" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3alevel_3e_2eAt_3ccompiler_2flower_3alevel_3e(ptr %v0, ptr %t3, i64 %t4)
  store %"compiler/lower:level" %t7, ptr %l26
  br label %bb1
bb1:
  %t8 = load %"compiler/lower:level", ptr %l26
  store %"compiler/lower:level" %t8, ptr %l3
  %t9 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2flower_3alevel_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %l27
  br label %bb2
bb2:
  %t10 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l27
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t10, ptr %l4
  br label %bb3
bb3:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/lower:lowering", ptr %t11, i32 0, i32 9
  %t15 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3alevel_3e_2eLen_3ccompiler_2flower_3alevel_3e(ptr %v0, ptr %t13)
  store i64 %t15, ptr %l30
  br label %bb4
bb4:
  %t16 = load i64, ptr %l1, !tbaa !24
  %t18 = add i64 %t16, 1
  %t19 = load i64, ptr %l30, !tbaa !24
  %t21 = icmp sgt i64 %t19, %t18
  %t23 = xor i1 %t21, true
  br i1 %t23, label %bb5, label %bb6
bb5:
  br label %bb14
bb6:
  br label %bb7
bb7:
  store ptr %l4, ptr %l35, !tbaa !29
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/lower:lowering", ptr %t25, i32 0, i32 9
  %t29 = call { i32, %"compiler/lower:level" } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3alevel_3e_2ePop_3ccompiler_2flower_3alevel_3e(ptr %v0, ptr %t27)
  %t30 = extractvalue { i32, %"compiler/lower:level" } %t29, 1
  %t31 = extractvalue { i32, %"compiler/lower:level" } %t29, 0
  store i32 %t31, ptr %l40
  %t32 = icmp ne i32 %t31, 0
  br i1 %t32, label %bb9, label %ok.33, !prof !99
ok.33:
  store %"compiler/lower:level" %t30, ptr %l39
  br label %bb8
bb8:
  %t34 = load %"compiler/lower:level", ptr %l39
  store %"compiler/lower:level" %t34, ptr %l36
  br label %bb11
bb9:
  br label %bb10
bb10:
  call void @__olang_check_failed(ptr @olang_loc_3ef62952ecee62f3_777b4c56ce2caf3f)
  unreachable
bb11:
  %t35 = load ptr, ptr %l35, !tbaa !29
  %t36 = load %"compiler/lower:level", ptr %l36
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3alevel_3e_2ePush_3ccompiler_2flower_3alevel_3e(ptr %s0, ptr %t35, %"compiler/lower:level" %t36)
  br label %bb12
bb12:
  br label %bb13
bb13:
  br label %bb3
bb14:
  %t37 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t37, ptr %l41
  br label %bb15
bb15:
  %t38 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l41
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t38, ptr %l5
  %t39 = getelementptr %"compiler/lower:level", ptr %l3, i32 0, i32 2
  %t40 = load i32, ptr %t39, !range !{i32 0, i32 7}
  %t42 = trunc i64 3 to i32
  %t43 = icmp eq i32 %t40, %t42
  store i1 %t43, ptr %l6, !tbaa !21
  store i64 0, ptr %l7, !tbaa !24
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/lower:lowering", ptr %t45, i32 0, i32 10
  %t49 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlock_26_3e_2eLen_3ccompiler_2ftyped_3aBlock_26_3e(ptr %v0, ptr %t47)
  store i64 %t49, ptr %l46
  br label %bb16
bb16:
  %t50 = load i64, ptr %l46, !tbaa !24
  store i64 %t50, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t51 = load i64, ptr %l8, !tbaa !24
  %t52 = load i64, ptr %l7, !tbaa !24
  %t55 = icmp sgt i64 %t51, %t52
  br i1 %t55, label %bb17, label %bb18
bb17:
  %t57 = load i64, ptr %l9, !tbaa !24
  %t59 = icmp sgt i64 %t57, 0
  br i1 %t59, label %bb19, label %bb20
bb18:
  store i64 0, ptr %l50, !tbaa !24
  br label %bb22
bb19:
  %t61 = load i64, ptr %l8, !tbaa !24
  %t62 = load i64, ptr %l7, !tbaa !24
  %t65 = sub i64 %t61, %t62
  %t66 = load i64, ptr %l9, !tbaa !24
  %t69 = add i64 %t65, %t66
  %t71 = sub i64 %t69, 1
  %t72 = load i64, ptr %l9, !tbaa !24
  %t75 = sdiv i64 %t71, %t72
  store i64 %t75, ptr %l53, !tbaa !24
  br label %bb21
bb20:
  store i64 0, ptr %l53, !tbaa !24
  br label %bb21
bb21:
  %t77 = load i64, ptr %l53, !tbaa !24
  store i64 %t77, ptr %l50, !tbaa !24
  br label %bb22
bb22:
  %t78 = load i64, ptr %l50, !tbaa !24
  store i64 %t78, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb23
bb23:
  %t79 = load i64, ptr %l11, !tbaa !24
  %t80 = load i64, ptr %l10, !tbaa !24
  %t83 = icmp slt i64 %t79, %t80
  %t85 = xor i1 %t83, true
  br i1 %t85, label %bb24, label %bb25
bb24:
  br label %bb37
bb25:
  br label %bb26
bb26:
  %t87 = load i64, ptr %l7, !tbaa !24
  %t88 = load i64, ptr %l11, !tbaa !24
  %t89 = load i64, ptr %l9, !tbaa !24
  %t92 = mul i64 %t88, %t89
  %t95 = add i64 %t87, %t92
  store i64 %t95, ptr %l12, !tbaa !24
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = getelementptr %"compiler/lower:lowering", ptr %t97, i32 0, i32 11
  %t100 = load i64, ptr %l12, !tbaa !24
  %t103 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2eAt_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t99, i64 %t100)
  store i32 %t103, ptr %l74
  br label %bb27
bb27:
  %t104 = getelementptr %"compiler/lower:level", ptr %l3, i32 0, i32 0
  %t105 = load i32, ptr %t104, !tbaa !23
  %t106 = load i32, ptr %l74, !tbaa !23
  %t108 = icmp eq i32 %t106, %t105
  br i1 %t108, label %bb28, label %bb29
bb28:
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t111 = load i64, ptr %l12, !tbaa !24
  %t113 = load i1, ptr %l6, !tbaa !21
  %t118 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2erunsIn(ptr %v0, ptr %t110, i64 %t111, i32 %a2, i1 %t113)
  store i1 %t118, ptr %l82
  br label %bb30
bb29:
  store i1 false, ptr %l77, !tbaa !21
  br label %bb31
bb30:
  %t119 = load i1, ptr %l82, !tbaa !21
  store i1 %t119, ptr %l77, !tbaa !21
  br label %bb31
bb31:
  %t120 = load i1, ptr %l77, !tbaa !21
  br i1 %t120, label %bb32, label %bb33
bb32:
  %t121 = load i64, ptr %l12, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l5, i64 %t121)
  br label %bb34
bb33:
  br label %bb35
bb34:
  br label %bb35
bb35:
  br label %bb36
bb36:
  %t124 = load i64, ptr %l11, !tbaa !24
  %t126 = add i64 %t124, 1
  store i64 %t126, ptr %l11, !tbaa !24
  br label %bb23
bb37:
  store ptr %l5, ptr %l13, !tbaa !29
  store i64 0, ptr %l14, !tbaa !24
  br label %bb38
bb38:
  %t129 = load i64, ptr %l14, !tbaa !24
  store i64 %t129, ptr %l88, !tbaa !24
  %t130 = load ptr, ptr %l13, !tbaa !29
  %t132 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t130)
  store i64 %t132, ptr %l90
  br label %bb39
bb39:
  %t133 = load i64, ptr %l88, !tbaa !24
  %t134 = load i64, ptr %l90, !tbaa !24
  %t135 = icmp slt i64 %t133, %t134
  %t137 = xor i1 %t135, true
  br i1 %t137, label %bb40, label %bb41
bb40:
  br label %bb46
bb41:
  br label %bb42
bb42:
  %t139 = load ptr, ptr %l13, !tbaa !29
  %t140 = load i64, ptr %l14, !tbaa !24
  %t143 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t139, i64 %t140)
  store i64 %t143, ptr %l95
  br label %bb43
bb43:
  %t144 = load i64, ptr %l95, !tbaa !24
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t147 = getelementptr %"compiler/lower:lowering", ptr %t145, i32 0, i32 11
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2eSetAt_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t147, i64 %t144, i32 -1)
  br label %bb44
bb44:
  br label %bb45
bb45:
  %t151 = load i64, ptr %l14, !tbaa !24
  %t153 = add i64 %t151, 1
  store i64 %t153, ptr %l14, !tbaa !24
  br label %bb38
bb46:
  store %olang.scope zeroinitializer, ptr %s10
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t158 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2flower_2ecompiler_2flower_3alowering_2erunOrder(ptr %v0, ptr %s0, ptr %s10, ptr %t155, ptr %l5)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t158, ptr %l103
  br label %bb47
bb47:
  %t159 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l103
  %t160 = call ptr @__olang_scope_alloc_a(ptr %s10, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t159, ptr %t160
  store ptr %t160, ptr %l16, !tbaa !29
  store i64 0, ptr %l17, !tbaa !24
  br label %bb48
bb48:
  %t162 = load i64, ptr %l17, !tbaa !24
  store i64 %t162, ptr %l105, !tbaa !24
  %t163 = load ptr, ptr %l16, !tbaa !29
  %t165 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s10, ptr %t163)
  store i64 %t165, ptr %l107
  br label %bb49
bb49:
  %t166 = load i64, ptr %l105, !tbaa !24
  %t167 = load i64, ptr %l107, !tbaa !24
  %t168 = icmp slt i64 %t166, %t167
  %t170 = xor i1 %t168, true
  br i1 %t170, label %bb50, label %bb51
bb50:
  br label %bb68
bb51:
  br label %bb52
bb52:
  %t172 = load ptr, ptr %l16, !tbaa !29
  %t173 = load i64, ptr %l17, !tbaa !24
  %t176 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s10, ptr %t172, i64 %t173)
  store i64 %t176, ptr %l112
  br label %bb53
bb53:
  %t177 = load i64, ptr %l112, !tbaa !24
  store i64 %t177, ptr %l18, !tbaa !24
  %t178 = load ptr, ptr %l0, !tbaa !29
  %t180 = getelementptr %"compiler/lower:lowering", ptr %t178, i32 0, i32 0
  %t181 = load ptr, ptr %t180, !tbaa !29
  %t183 = getelementptr %"compiler/lower:Lowerer", ptr %t181, i32 0, i32 6
  %t184 = load i1, ptr %t183, !tbaa !21
  br i1 %t184, label %bb54, label %bb55
bb54:
  %t186 = load ptr, ptr %l0, !tbaa !29
  %t187 = load i64, ptr %l18, !tbaa !24
  %t190 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eonError(ptr %v0, ptr %t186, i64 %t187)
  store i1 %t190, ptr %l119
  br label %bb56
bb55:
  store i1 false, ptr %l116, !tbaa !21
  br label %bb57
bb56:
  %t191 = load i1, ptr %l119, !tbaa !21
  %t192 = xor i1 %t191, true
  store i1 %t192, ptr %l116, !tbaa !21
  br label %bb57
bb57:
  %t194 = load i1, ptr %l116, !tbaa !21
  br i1 %t194, label %bb58, label %bb59
bb58:
  store %olang.scope zeroinitializer, ptr %s12
  %t195 = load ptr, ptr %l0, !tbaa !29
  store ptr %t195, ptr %l121, !tbaa !29
  %t196 = load ptr, ptr %l0, !tbaa !29
  %t198 = getelementptr %"compiler/lower:lowering", ptr %t196, i32 0, i32 1
  %t199 = load ptr, ptr %t198, !tbaa !29
  %t201 = getelementptr %"compiler/typed:Body", ptr %t199, i32 0, i32 8
  store ptr %t201, ptr %l124, !tbaa !29
  %t202 = load ptr, ptr %l0, !tbaa !29
  %t204 = getelementptr %"compiler/lower:lowering", ptr %t202, i32 0, i32 10
  %t205 = load i64, ptr %l18, !tbaa !24
  %t208 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlock_26_3e_2eAt_3ccompiler_2ftyped_3aBlock_26_3e(ptr %v0, ptr %s12, ptr %t204, i64 %t205)
  store ptr %t208, ptr %l128
  br label %bb60
bb59:
  br label %bb63
bb60:
  %t209 = load ptr, ptr %l128, !tbaa !29
  %t211 = getelementptr %"compiler/typed:Block", ptr %t209, i32 0, i32 0
  %t212 = load i32, ptr %t211, !tbaa !23
  %t214 = sext i32 %t212 to i64
  %t215 = load ptr, ptr %l124, !tbaa !29
  %t217 = call %"compiler/typed:BlockInfo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockInfo_3e_2eAt_3ccompiler_2ftyped_3aBlockInfo_3e(ptr %v0, ptr %t215, i64 %t214)
  store %"compiler/typed:BlockInfo" %t217, ptr %l132
  br label %bb61
bb61:
  %t218 = getelementptr %"compiler/typed:BlockInfo", ptr %l132, i32 0, i32 2
  %t219 = load %"compiler/source:Span", ptr %t218
  %t220 = getelementptr %"compiler/lower:level", ptr %l3, i32 0, i32 0
  %t221 = load i32, ptr %t220, !tbaa !23
  %t222 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  store { i64, [21 x i64] } zeroinitializer, ptr %t223
  %t224 = getelementptr { i64, [21 x i64] }, ptr %t223, i32 0, i32 0
  store i64 14, ptr %t224
  %t226 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %t219, 0
  %t228 = insertvalue { %"compiler/source:Span", i32, i32 } %t226, i32 %t221, 1
  %t230 = insertvalue { %"compiler/source:Span", i32, i32 } %t228, i32 %t222, 2
  %t231 = getelementptr { i64, [21 x i64] }, ptr %t223, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t230, ptr %t231
  %t232 = load { i64, [21 x i64] }, ptr %t223
  store { i64, [21 x i64] } %t232, ptr %l136
  %t233 = load ptr, ptr %l121, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s12, ptr %t233, ptr %l136)
  br label %bb62
bb62:
  call void @__olang_scope_close(ptr %s12)
  br label %bb63
bb63:
  %t235 = load ptr, ptr %l0, !tbaa !29
  %t237 = getelementptr %"compiler/lower:lowering", ptr %t235, i32 0, i32 32
  %t238 = load i1, ptr %t237, !tbaa !21
  store i1 %t238, ptr %l19, !tbaa !21
  %t240 = load ptr, ptr %l0, !tbaa !29
  store ptr %t240, ptr %l140, !tbaa !29
  %t241 = load ptr, ptr %l0, !tbaa !29
  %t242 = load i64, ptr %l18, !tbaa !24
  %t245 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eisDrop(ptr %v0, ptr %t241, i64 %t242)
  store i1 %t245, ptr %l143
  br label %bb64
bb64:
  %t246 = load i1, ptr %l143, !tbaa !21
  %t247 = load ptr, ptr %l140, !tbaa !29
  %t248 = getelementptr %"compiler/lower:lowering", ptr %t247, i32 0, i32 32
  store i1 %t246, ptr %t248, !tbaa !21
  %t249 = load ptr, ptr %l0, !tbaa !29
  store ptr %t249, ptr %l144, !tbaa !29
  %t250 = load ptr, ptr %l0, !tbaa !29
  %t252 = getelementptr %"compiler/lower:lowering", ptr %t250, i32 0, i32 10
  %t253 = load i64, ptr %l18, !tbaa !24
  %t256 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlock_26_3e_2eAt_3ccompiler_2ftyped_3aBlock_26_3e(ptr %v0, ptr %v0, ptr %t252, i64 %t253)
  store ptr %t256, ptr %l148
  br label %bb65
bb65:
  %t257 = load ptr, ptr %l144, !tbaa !29
  %t258 = load ptr, ptr %l148, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eblock(ptr %v0, ptr %v0, ptr %t257, ptr %t258)
  br label %bb66
bb66:
  %t259 = load ptr, ptr %l0, !tbaa !29
  %t260 = load i1, ptr %l19, !tbaa !21
  %t263 = getelementptr %"compiler/lower:lowering", ptr %t259, i32 0, i32 32
  store i1 %t260, ptr %t263, !tbaa !21
  br label %bb67
bb67:
  %t264 = load i64, ptr %l17, !tbaa !24
  %t266 = add i64 %t264, 1
  store i64 %t266, ptr %l17, !tbaa !24
  br label %bb48
bb68:
  call void @__olang_scope_close(ptr %s10)
  store ptr %l5, ptr %l20, !tbaa !29
  store i64 0, ptr %l21, !tbaa !24
  br label %bb69
bb69:
  %t269 = load i64, ptr %l21, !tbaa !24
  store i64 %t269, ptr %l154, !tbaa !24
  %t270 = load ptr, ptr %l20, !tbaa !29
  %t272 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t270)
  store i64 %t272, ptr %l156
  br label %bb70
bb70:
  %t273 = load i64, ptr %l154, !tbaa !24
  %t274 = load i64, ptr %l156, !tbaa !24
  %t275 = icmp slt i64 %t273, %t274
  %t277 = xor i1 %t275, true
  br i1 %t277, label %bb71, label %bb72
bb71:
  br label %bb77
bb72:
  br label %bb73
bb73:
  %t279 = load ptr, ptr %l20, !tbaa !29
  %t280 = load i64, ptr %l21, !tbaa !24
  %t283 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t279, i64 %t280)
  store i64 %t283, ptr %l161
  br label %bb74
bb74:
  %t284 = load i64, ptr %l161, !tbaa !24
  %t285 = load ptr, ptr %l0, !tbaa !29
  %t287 = getelementptr %"compiler/lower:lowering", ptr %t285, i32 0, i32 11
  %t289 = getelementptr %"compiler/lower:level", ptr %l3, i32 0, i32 0
  %t290 = load i32, ptr %t289, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2eSetAt_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t287, i64 %t284, i32 %t290)
  br label %bb75
bb75:
  br label %bb76
bb76:
  %t294 = load i64, ptr %l21, !tbaa !24
  %t296 = add i64 %t294, 1
  store i64 %t296, ptr %l21, !tbaa !24
  br label %bb69
bb77:
  br label %bb78
bb78:
  %t299 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3alevel_3e_2eLen_3ccompiler_2flower_3alevel_3e(ptr %s0, ptr %l4)
  store i64 %t299, ptr %l169
  br label %bb79
bb79:
  %t300 = load i64, ptr %l169, !tbaa !24
  %t301 = icmp sgt i64 %t300, 0
  %t303 = xor i1 %t301, true
  br i1 %t303, label %bb80, label %bb81
bb80:
  br label %bb89
bb81:
  br label %bb82
bb82:
  %t305 = load ptr, ptr %l0, !tbaa !29
  %t307 = getelementptr %"compiler/lower:lowering", ptr %t305, i32 0, i32 9
  store ptr %t307, ptr %l173, !tbaa !29
  %t309 = call { i32, %"compiler/lower:level" } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3alevel_3e_2ePop_3ccompiler_2flower_3alevel_3e(ptr %s0, ptr %l4)
  %t310 = extractvalue { i32, %"compiler/lower:level" } %t309, 1
  %t311 = extractvalue { i32, %"compiler/lower:level" } %t309, 0
  store i32 %t311, ptr %l177
  %t312 = icmp ne i32 %t311, 0
  br i1 %t312, label %bb84, label %ok.313, !prof !99
ok.313:
  store %"compiler/lower:level" %t310, ptr %l176
  br label %bb83
bb83:
  %t314 = load %"compiler/lower:level", ptr %l176
  store %"compiler/lower:level" %t314, ptr %l174
  br label %bb86
bb84:
  br label %bb85
bb85:
  call void @__olang_check_failed(ptr @olang_loc_de8dc91cd31c6e72_d86f27d9b5b5bc3e)
  unreachable
bb86:
  %t315 = load ptr, ptr %l173, !tbaa !29
  %t316 = load %"compiler/lower:level", ptr %l174
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3alevel_3e_2ePush_3ccompiler_2flower_3alevel_3e(ptr %v0, ptr %t315, %"compiler/lower:level" %t316)
  br label %bb87
bb87:
  br label %bb88
bb88:
  br label %bb78
bb89:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2espawnErrors(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l1 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l17 = alloca { i64, ptr }
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t7 = getelementptr %"compiler/typed:Block", ptr %t5, i32 0, i32 1
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  store { i64, ptr } %t8, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l5, !tbaa !24
  br label %bb4
bb4:
  %t14 = load i64, ptr %l4, !tbaa !24
  %t15 = load i64, ptr %l5, !tbaa !24
  %t18 = icmp slt i64 %t14, %t15
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb5, label %bb6
bb5:
  br label %bb10
bb6:
  br label %bb7
bb7:
  %t22 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t22, ptr %l17, !tbaa !27
  %t23 = load i64, ptr %l4, !tbaa !24
  %t25 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr ptr, ptr %t26, i64 %t23
  %t28 = load ptr, ptr %t27, !tbaa !39
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estmtSpawnErrors(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %t28, ptr %a2)
  br label %bb8
bb8:
  br label %bb9
bb9:
  %t36 = load i64, ptr %l4, !tbaa !24
  %t38 = add i64 %t36, 1
  store i64 %t38, ptr %l4, !tbaa !24
  br label %bb4
bb10:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3alowering_2estableMade(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca i1
  %l7 = alloca ptr
  %l8 = alloca i1
  %l11 = alloca ptr
  %l12 = alloca i1
  %l15 = alloca ptr
  %l16 = alloca i1
  %l19 = alloca ptr
  %l20 = alloca i1
  %l23 = alloca ptr
  %l24 = alloca i1
  %l27 = alloca ptr
  %l28 = alloca i1
  %l35 = alloca i1
  %l36 = alloca ptr
  %l37 = alloca i1
  %l46 = alloca i1
  %l50 = alloca i1
  %l52 = alloca { i64, ptr }
  %l54 = alloca i1
  %l55 = alloca ptr
  %l56 = alloca i1
  %l63 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l7, !tbaa !29
  store i1 false, ptr %l8, !tbaa !21
  %t2 = load ptr, ptr %l7, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l7, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 7
  store i1 %t8, ptr %l8, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l8, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb17
bb4:
  %t10 = load ptr, ptr %l1, !tbaa !29
  store ptr %t10, ptr %l11, !tbaa !29
  store i1 false, ptr %l12, !tbaa !21
  %t11 = load ptr, ptr %l11, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb5, label %bb6
bb5:
  %t14 = load ptr, ptr %l11, !tbaa !29
  %t15 = load i64, ptr %t14, !range !{i64 0, i64 18}
  %t17 = icmp eq i64 %t15, 8
  store i1 %t17, ptr %l12, !tbaa !21
  br label %bb6
bb6:
  %t18 = load i1, ptr %l12, !tbaa !21
  br i1 %t18, label %bb7, label %bb8
bb7:
  br label %bb17
bb8:
  %t19 = load ptr, ptr %l1, !tbaa !29
  store ptr %t19, ptr %l15, !tbaa !29
  store i1 false, ptr %l16, !tbaa !21
  %t20 = load ptr, ptr %l15, !tbaa !29
  %t21 = icmp ne ptr %t20, null
  br i1 %t21, label %bb9, label %bb10
bb9:
  %t23 = load ptr, ptr %l15, !tbaa !29
  %t24 = load i64, ptr %t23, !range !{i64 0, i64 18}
  %t26 = icmp eq i64 %t24, 16
  store i1 %t26, ptr %l16, !tbaa !21
  br label %bb10
bb10:
  %t27 = load i1, ptr %l16, !tbaa !21
  br i1 %t27, label %bb11, label %bb12
bb11:
  br label %bb17
bb12:
  %t28 = load ptr, ptr %l1, !tbaa !29
  store ptr %t28, ptr %l19, !tbaa !29
  store i1 false, ptr %l20, !tbaa !21
  %t29 = load ptr, ptr %l19, !tbaa !29
  %t30 = icmp ne ptr %t29, null
  br i1 %t30, label %bb13, label %bb14
bb13:
  %t32 = load ptr, ptr %l19, !tbaa !29
  %t33 = load i64, ptr %t32, !range !{i64 0, i64 18}
  %t35 = icmp eq i64 %t33, 0
  store i1 %t35, ptr %l20, !tbaa !21
  br label %bb14
bb14:
  %t36 = load i1, ptr %l20, !tbaa !21
  br i1 %t36, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb18
bb17:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb56
bb18:
  %t37 = load ptr, ptr %l1, !tbaa !29
  store ptr %t37, ptr %l23, !tbaa !29
  store i1 false, ptr %l24, !tbaa !21
  %t38 = load ptr, ptr %l23, !tbaa !29
  %t39 = icmp ne ptr %t38, null
  br i1 %t39, label %bb19, label %bb20
bb19:
  %t41 = load ptr, ptr %l23, !tbaa !29
  %t42 = load i64, ptr %t41, !range !{i64 0, i64 18}
  %t44 = icmp eq i64 %t42, 6
  store i1 %t44, ptr %l24, !tbaa !21
  br label %bb20
bb20:
  %t45 = load i1, ptr %l24, !tbaa !21
  br i1 %t45, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb56
bb24:
  %t46 = load ptr, ptr %l1, !tbaa !29
  store ptr %t46, ptr %l27, !tbaa !29
  store i1 false, ptr %l28, !tbaa !21
  %t47 = load ptr, ptr %l27, !tbaa !29
  %t48 = icmp ne ptr %t47, null
  br i1 %t48, label %bb25, label %bb26
bb25:
  %t50 = load ptr, ptr %l27, !tbaa !29
  %t51 = load i64, ptr %t50, !range !{i64 0, i64 18}
  %t53 = icmp eq i64 %t51, 2
  store i1 %t53, ptr %l28, !tbaa !21
  br label %bb26
bb26:
  %t54 = load i1, ptr %l28, !tbaa !21
  br i1 %t54, label %bb27, label %bb28
bb27:
  %t55 = load ptr, ptr %l1, !tbaa !29
  %t57 = getelementptr { i64, [5 x i64] }, ptr %t55, i32 0, i32 1
  %t58 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t57, i32 0, i32 2
  %t59 = load ptr, ptr %t58
  store ptr %t59, ptr %l2, !tbaa !29
  br label %bb29
bb28:
  br label %bb31
bb29:
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t62 = load ptr, ptr %l2, !tbaa !29
  %t65 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2establePlace(ptr %v0, ptr %v1, ptr %t61, ptr %t62)
  store i1 %t65, ptr %l35
  br label %bb30
bb30:
  %t66 = load i1, ptr %l35, !tbaa !21
  store i1 %t66, ptr %l6, !tbaa !21
  br label %bb56
bb31:
  %t67 = load ptr, ptr %l1, !tbaa !29
  store ptr %t67, ptr %l36, !tbaa !29
  store i1 false, ptr %l37, !tbaa !21
  %t68 = load ptr, ptr %l36, !tbaa !29
  %t69 = icmp ne ptr %t68, null
  br i1 %t69, label %bb32, label %bb33
bb32:
  %t71 = load ptr, ptr %l36, !tbaa !29
  %t72 = load i64, ptr %t71, !range !{i64 0, i64 18}
  %t74 = icmp eq i64 %t72, 9
  store i1 %t74, ptr %l37, !tbaa !21
  br label %bb33
bb33:
  %t75 = load i1, ptr %l37, !tbaa !21
  br i1 %t75, label %bb34, label %bb35
bb34:
  %t76 = load ptr, ptr %l1, !tbaa !29
  %t78 = getelementptr { i64, [5 x i64] }, ptr %t76, i32 0, i32 1
  %t79 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t78, i32 0, i32 2
  %t80 = load i32, ptr %t79, !range !{i32 0, i32 49}
  store i32 %t80, ptr %l3
  %t82 = load ptr, ptr %l1, !tbaa !29
  %t84 = getelementptr { i64, [5 x i64] }, ptr %t82, i32 0, i32 1
  %t85 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t84, i32 0, i32 4
  %t86 = load { i64, ptr }, ptr %t85
  store { i64, ptr } %t86, ptr %l4, !tbaa !27
  br label %bb36
bb35:
  br label %bb44
bb36:
  %t88 = load i32, ptr %l3, !range !{i32 0, i32 49}
  %t90 = trunc i64 20 to i32
  %t91 = icmp eq i32 %t88, %t90
  br i1 %t91, label %bb37, label %bb38
bb37:
  %t93 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t95 = extractvalue { i64, ptr } %t93, 0
  %t97 = icmp eq i64 %t95, 1
  store i1 %t97, ptr %l46, !tbaa !21
  br label %bb39
bb38:
  store i1 false, ptr %l46, !tbaa !21
  br label %bb39
bb39:
  %t99 = load i1, ptr %l46, !tbaa !21
  br i1 %t99, label %bb40, label %bb41
bb40:
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t101 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t101, ptr %l52, !tbaa !27
  %t102 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t103 = load ptr, ptr %t102, !tbaa !27
  %t104 = getelementptr ptr, ptr %t103, i64 0
  %t105 = load ptr, ptr %t104, !tbaa !39
  %t108 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2estableMade(ptr %v0, ptr %v1, ptr %t100, ptr %t105)
  store i1 %t108, ptr %l54
  br label %bb42
bb41:
  store i1 false, ptr %l50, !tbaa !21
  br label %bb43
bb42:
  %t109 = load i1, ptr %l54, !tbaa !21
  store i1 %t109, ptr %l50, !tbaa !21
  br label %bb43
bb43:
  %t110 = load i1, ptr %l50, !tbaa !21
  store i1 %t110, ptr %l6, !tbaa !21
  br label %bb56
bb44:
  %t111 = load ptr, ptr %l1, !tbaa !29
  store ptr %t111, ptr %l55, !tbaa !29
  store i1 false, ptr %l56, !tbaa !21
  %t112 = load ptr, ptr %l55, !tbaa !29
  %t113 = icmp ne ptr %t112, null
  br i1 %t113, label %bb45, label %bb46
bb45:
  %t115 = load ptr, ptr %l55, !tbaa !29
  %t116 = load i64, ptr %t115, !range !{i64 0, i64 18}
  %t118 = icmp eq i64 %t116, 17
  store i1 %t118, ptr %l56, !tbaa !21
  br label %bb46
bb46:
  %t119 = load i1, ptr %l56, !tbaa !21
  br i1 %t119, label %bb47, label %bb48
bb47:
  %t120 = load ptr, ptr %l1, !tbaa !29
  %t122 = getelementptr { i64, [5 x i64] }, ptr %t120, i32 0, i32 1
  %t123 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t122, i32 0, i32 2
  %t124 = load ptr, ptr %t123
  store ptr %t124, ptr %l5, !tbaa !29
  br label %bb49
bb48:
  br label %bb51
bb49:
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t127 = load ptr, ptr %l5, !tbaa !29
  %t130 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2estableMade(ptr %v0, ptr %v1, ptr %t126, ptr %t127)
  store i1 %t130, ptr %l63
  br label %bb50
bb50:
  %t131 = load i1, ptr %l63, !tbaa !21
  store i1 %t131, ptr %l6, !tbaa !21
  br label %bb56
bb51:
  br i1 true, label %bb52, label %bb53
bb52:
  br label %bb54
bb53:
  br label %bb55
bb54:
  store i1 false, ptr %l6, !tbaa !21
  br label %bb56
bb55:
  call void @__olang_check_failed(ptr @olang_loc_a75b87f7fc6585db_9c37e910f1cfbc0f)
  unreachable
bb56:
  %t132 = load i1, ptr %l6, !tbaa !21
  store i1 %t132, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3alowering_2estableRef(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca { i64, ptr }
  %l8 = alloca ptr
  %l11 = alloca i1
  %l13 = alloca i1
  %l14 = alloca i1
  %l17 = alloca i1
  %l19 = alloca i1
  %l20 = alloca ptr
  %l21 = alloca i1
  %l28 = alloca i1
  %l29 = alloca ptr
  %l30 = alloca i1
  %l37 = alloca i1
  %l38 = alloca ptr
  %l39 = alloca i1
  %l47 = alloca i1
  %l48 = alloca ptr
  %l49 = alloca i1
  %l52 = alloca ptr
  %l53 = alloca i1
  %l61 = alloca i1
  %l62 = alloca ptr
  %l63 = alloca i1
  %l71 = alloca i1
  %l72 = alloca i1
  %l76 = alloca i1
  %l78 = alloca { i64, ptr }
  %l80 = alloca i1
  %l81 = alloca ptr
  %l82 = alloca i1
  %l89 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 45
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l11, !tbaa !21
  br label %bb4
bb2:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2equiet(ptr %v0, ptr %t6)
  store i1 %t8, ptr %l13
  br label %bb3
bb3:
  %t9 = load i1, ptr %l13, !tbaa !21
  store i1 %t9, ptr %l11, !tbaa !21
  br label %bb4
bb4:
  %t10 = load i1, ptr %l11, !tbaa !21
  br i1 %t10, label %bb5, label %bb6
bb5:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load ptr, ptr %l1, !tbaa !29
  %t15 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eplaceRooted(ptr %v0, ptr %v1, ptr %t11, ptr %t12)
  store i1 %t15, ptr %l17
  br label %bb7
bb6:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb8
bb7:
  %t16 = load i1, ptr %l17, !tbaa !21
  store i1 %t16, ptr %l14, !tbaa !21
  br label %bb8
bb8:
  %t17 = load i1, ptr %l14, !tbaa !21
  br i1 %t17, label %bb9, label %bb10
bb9:
  store i1 true, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t19 = load ptr, ptr %l1, !tbaa !29
  store ptr %t19, ptr %l20, !tbaa !29
  store i1 false, ptr %l21, !tbaa !21
  %t20 = load ptr, ptr %l20, !tbaa !29
  %t21 = icmp ne ptr %t20, null
  br i1 %t21, label %bb12, label %bb13
bb12:
  %t23 = load ptr, ptr %l20, !tbaa !29
  %t24 = load i64, ptr %t23, !range !{i64 0, i64 18}
  %t26 = icmp eq i64 %t24, 2
  store i1 %t26, ptr %l21, !tbaa !21
  br label %bb13
bb13:
  %t27 = load i1, ptr %l21, !tbaa !21
  br i1 %t27, label %bb14, label %bb15
bb14:
  %t28 = load ptr, ptr %l1, !tbaa !29
  %t30 = getelementptr { i64, [5 x i64] }, ptr %t28, i32 0, i32 1
  %t31 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t30, i32 0, i32 2
  %t32 = load ptr, ptr %t31
  store ptr %t32, ptr %l2, !tbaa !29
  br label %bb16
bb15:
  br label %bb18
bb16:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = load ptr, ptr %l2, !tbaa !29
  %t38 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2estableHolder(ptr %v0, ptr %v1, ptr %t34, ptr %t35)
  store i1 %t38, ptr %l28
  br label %bb17
bb17:
  %t39 = load i1, ptr %l28, !tbaa !21
  store i1 %t39, ptr %l19, !tbaa !21
  br label %bb71
bb18:
  %t40 = load ptr, ptr %l1, !tbaa !29
  store ptr %t40, ptr %l29, !tbaa !29
  store i1 false, ptr %l30, !tbaa !21
  %t41 = load ptr, ptr %l29, !tbaa !29
  %t42 = icmp ne ptr %t41, null
  br i1 %t42, label %bb19, label %bb20
bb19:
  %t44 = load ptr, ptr %l29, !tbaa !29
  %t45 = load i64, ptr %t44, !range !{i64 0, i64 18}
  %t47 = icmp eq i64 %t45, 3
  store i1 %t47, ptr %l30, !tbaa !21
  br label %bb20
bb20:
  %t48 = load i1, ptr %l30, !tbaa !21
  br i1 %t48, label %bb21, label %bb22
bb21:
  %t49 = load ptr, ptr %l1, !tbaa !29
  %t51 = getelementptr { i64, [5 x i64] }, ptr %t49, i32 0, i32 1
  %t52 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t51, i32 0, i32 2
  %t53 = load ptr, ptr %t52
  store ptr %t53, ptr %l3, !tbaa !29
  br label %bb23
bb22:
  br label %bb25
bb23:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t56 = load ptr, ptr %l3, !tbaa !29
  %t59 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2establePlace(ptr %v0, ptr %v1, ptr %t55, ptr %t56)
  store i1 %t59, ptr %l37
  br label %bb24
bb24:
  %t60 = load i1, ptr %l37, !tbaa !21
  store i1 %t60, ptr %l19, !tbaa !21
  br label %bb71
bb25:
  %t61 = load ptr, ptr %l1, !tbaa !29
  store ptr %t61, ptr %l38, !tbaa !29
  store i1 false, ptr %l39, !tbaa !21
  %t62 = load ptr, ptr %l38, !tbaa !29
  %t63 = icmp ne ptr %t62, null
  br i1 %t63, label %bb26, label %bb27
bb26:
  %t65 = load ptr, ptr %l38, !tbaa !29
  %t66 = load i64, ptr %t65, !range !{i64 0, i64 18}
  %t68 = icmp eq i64 %t66, 10
  store i1 %t68, ptr %l39, !tbaa !21
  br label %bb27
bb27:
  %t69 = load i1, ptr %l39, !tbaa !21
  br i1 %t69, label %bb28, label %bb29
bb28:
  %t70 = load ptr, ptr %l1, !tbaa !29
  %t72 = getelementptr { i64, [5 x i64] }, ptr %t70, i32 0, i32 1
  %t73 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t72, i32 0, i32 2
  %t74 = load ptr, ptr %t73
  store ptr %t74, ptr %l4, !tbaa !29
  br label %bb30
bb29:
  br label %bb32
bb30:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t77 = load ptr, ptr %l4, !tbaa !29
  %t79 = getelementptr %"compiler/typed:Slice", ptr %t77, i32 0, i32 0
  %t80 = load ptr, ptr %t79, !tbaa !29
  %t83 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2establePlace(ptr %v0, ptr %v1, ptr %t76, ptr %t80)
  store i1 %t83, ptr %l47
  br label %bb31
bb31:
  %t84 = load i1, ptr %l47, !tbaa !21
  store i1 %t84, ptr %l19, !tbaa !21
  br label %bb71
bb32:
  %t85 = load ptr, ptr %l1, !tbaa !29
  store ptr %t85, ptr %l48, !tbaa !29
  store i1 false, ptr %l49, !tbaa !21
  %t86 = load ptr, ptr %l48, !tbaa !29
  %t87 = icmp ne ptr %t86, null
  br i1 %t87, label %bb33, label %bb34
bb33:
  %t89 = load ptr, ptr %l48, !tbaa !29
  %t90 = load i64, ptr %t89, !range !{i64 0, i64 18}
  %t92 = icmp eq i64 %t90, 1
  store i1 %t92, ptr %l49, !tbaa !21
  br label %bb34
bb34:
  %t93 = load i1, ptr %l49, !tbaa !21
  br i1 %t93, label %bb35, label %bb36
bb35:
  br label %bb37
bb36:
  br label %bb38
bb37:
  store i1 true, ptr %l19, !tbaa !21
  br label %bb71
bb38:
  %t94 = load ptr, ptr %l1, !tbaa !29
  store ptr %t94, ptr %l52, !tbaa !29
  store i1 false, ptr %l53, !tbaa !21
  %t95 = load ptr, ptr %l52, !tbaa !29
  %t96 = icmp ne ptr %t95, null
  br i1 %t96, label %bb39, label %bb40
bb39:
  %t98 = load ptr, ptr %l52, !tbaa !29
  %t99 = load i64, ptr %t98, !range !{i64 0, i64 18}
  %t101 = icmp eq i64 %t99, 5
  store i1 %t101, ptr %l53, !tbaa !21
  br label %bb40
bb40:
  %t102 = load i1, ptr %l53, !tbaa !21
  br i1 %t102, label %bb41, label %bb42
bb41:
  %t103 = load ptr, ptr %l1, !tbaa !29
  %t105 = getelementptr { i64, [5 x i64] }, ptr %t103, i32 0, i32 1
  %t106 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t105, i32 0, i32 2
  %t107 = load ptr, ptr %t106
  store ptr %t107, ptr %l5, !tbaa !29
  br label %bb43
bb42:
  br label %bb45
bb43:
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t110 = load ptr, ptr %l5, !tbaa !29
  %t112 = getelementptr %"compiler/typed:Promote", ptr %t110, i32 0, i32 0
  %t113 = load ptr, ptr %t112, !tbaa !29
  %t116 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2estableMade(ptr %v0, ptr %v1, ptr %t109, ptr %t113)
  store i1 %t116, ptr %l61
  br label %bb44
bb44:
  %t117 = load i1, ptr %l61, !tbaa !21
  store i1 %t117, ptr %l19, !tbaa !21
  br label %bb71
bb45:
  %t118 = load ptr, ptr %l1, !tbaa !29
  store ptr %t118, ptr %l62, !tbaa !29
  store i1 false, ptr %l63, !tbaa !21
  %t119 = load ptr, ptr %l62, !tbaa !29
  %t120 = icmp ne ptr %t119, null
  br i1 %t120, label %bb46, label %bb47
bb46:
  %t122 = load ptr, ptr %l62, !tbaa !29
  %t123 = load i64, ptr %t122, !range !{i64 0, i64 18}
  %t125 = icmp eq i64 %t123, 9
  store i1 %t125, ptr %l63, !tbaa !21
  br label %bb47
bb47:
  %t126 = load i1, ptr %l63, !tbaa !21
  br i1 %t126, label %bb48, label %bb49
bb48:
  %t127 = load ptr, ptr %l1, !tbaa !29
  %t129 = getelementptr { i64, [5 x i64] }, ptr %t127, i32 0, i32 1
  %t130 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t129, i32 0, i32 2
  %t131 = load i32, ptr %t130, !range !{i32 0, i32 49}
  store i32 %t131, ptr %l6
  %t133 = load ptr, ptr %l1, !tbaa !29
  %t135 = getelementptr { i64, [5 x i64] }, ptr %t133, i32 0, i32 1
  %t136 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t135, i32 0, i32 4
  %t137 = load { i64, ptr }, ptr %t136
  store { i64, ptr } %t137, ptr %l7, !tbaa !27
  br label %bb50
bb49:
  br label %bb59
bb50:
  %t139 = load i32, ptr %l6, !range !{i32 0, i32 49}
  %t141 = call i1 @compiler_2ftyped_2ePassesRefs(i32 %t139)
  store i1 %t141, ptr %l71
  br label %bb51
bb51:
  %t142 = load i1, ptr %l71, !tbaa !21
  br i1 %t142, label %bb52, label %bb53
bb52:
  %t143 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t145 = extractvalue { i64, ptr } %t143, 0
  %t147 = icmp sgt i64 %t145, 0
  store i1 %t147, ptr %l72, !tbaa !21
  br label %bb54
bb53:
  store i1 false, ptr %l72, !tbaa !21
  br label %bb54
bb54:
  %t149 = load i1, ptr %l72, !tbaa !21
  br i1 %t149, label %bb55, label %bb56
bb55:
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t151 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t151, ptr %l78, !tbaa !27
  %t152 = getelementptr { i64, ptr }, ptr %l78, i32 0, i32 1
  %t153 = load ptr, ptr %t152, !tbaa !27
  %t154 = getelementptr ptr, ptr %t153, i64 0
  %t155 = load ptr, ptr %t154, !tbaa !39
  %t158 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2estableRef(ptr %v0, ptr %v1, ptr %t150, ptr %t155)
  store i1 %t158, ptr %l80
  br label %bb57
bb56:
  store i1 false, ptr %l76, !tbaa !21
  br label %bb58
bb57:
  %t159 = load i1, ptr %l80, !tbaa !21
  store i1 %t159, ptr %l76, !tbaa !21
  br label %bb58
bb58:
  %t160 = load i1, ptr %l76, !tbaa !21
  store i1 %t160, ptr %l19, !tbaa !21
  br label %bb71
bb59:
  %t161 = load ptr, ptr %l1, !tbaa !29
  store ptr %t161, ptr %l81, !tbaa !29
  store i1 false, ptr %l82, !tbaa !21
  %t162 = load ptr, ptr %l81, !tbaa !29
  %t163 = icmp ne ptr %t162, null
  br i1 %t163, label %bb60, label %bb61
bb60:
  %t165 = load ptr, ptr %l81, !tbaa !29
  %t166 = load i64, ptr %t165, !range !{i64 0, i64 18}
  %t168 = icmp eq i64 %t166, 17
  store i1 %t168, ptr %l82, !tbaa !21
  br label %bb61
bb61:
  %t169 = load i1, ptr %l82, !tbaa !21
  br i1 %t169, label %bb62, label %bb63
bb62:
  %t170 = load ptr, ptr %l1, !tbaa !29
  %t172 = getelementptr { i64, [5 x i64] }, ptr %t170, i32 0, i32 1
  %t173 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t172, i32 0, i32 2
  %t174 = load ptr, ptr %t173
  store ptr %t174, ptr %l8, !tbaa !29
  br label %bb64
bb63:
  br label %bb66
bb64:
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t177 = load ptr, ptr %l8, !tbaa !29
  %t180 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2estableRef(ptr %v0, ptr %v1, ptr %t176, ptr %t177)
  store i1 %t180, ptr %l89
  br label %bb65
bb65:
  %t181 = load i1, ptr %l89, !tbaa !21
  store i1 %t181, ptr %l19, !tbaa !21
  br label %bb71
bb66:
  br i1 true, label %bb67, label %bb68
bb67:
  br label %bb69
bb68:
  br label %bb70
bb69:
  store i1 false, ptr %l19, !tbaa !21
  br label %bb71
bb70:
  call void @__olang_check_failed(ptr @olang_loc_7e6d7b9279609ab3_447c445eeb868dc7)
  unreachable
bb71:
  %t182 = load i1, ptr %l19, !tbaa !21
  store i1 %t182, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 6
  store i32 %a1, ptr %t5, !tbaa !23
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/lower:lowering", ptr %t6, i32 0, i32 7
  store i1 false, ptr %t8, !tbaa !21
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l11 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca i32
  %l19 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i32
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 7
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/lower:lowering", ptr %t6, i32 0, i32 42
  %t9 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2ePush_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v1, ptr %t8, ptr %t9)
  br label %bb4
bb4:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/lower:lowering", ptr %t12, i32 0, i32 43
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t14, i64 -1)
  br label %bb5
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estmtIn(ptr %v0, ptr %v1, ptr %t16, ptr %t17)
  br label %bb6
bb6:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/lower:lowering", ptr %t20, i32 0, i32 42
  %t24 = call { i32, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2ePop_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %s0, ptr %t22)
  %t25 = extractvalue { i32, ptr } %t24, 1
  %t26 = extractvalue { i32, ptr } %t24, 0
  store i32 %t26, ptr %l15
  %t27 = icmp ne i32 %t26, 0
  br i1 %t27, label %bb8, label %ok.28, !prof !99
ok.28:
  store ptr %t25, ptr %l14
  br label %bb7
bb7:
  %t29 = load ptr, ptr %l14, !tbaa !29
  store ptr %t29, ptr %l11, !tbaa !29
  br label %bb15
bb8:
  %t30 = load i32, ptr %l15, !tbaa !23
  %t31 = icmp eq i32 %t30, 65536
  br i1 %t31, label %bb9, label %bb10
bb9:
  call void @__olang_bang_failed_plain(ptr @olang_loc_a5b1a763b9bba10_ba6ba978893df9a4)
  unreachable
bb10:
  %t33 = load i32, ptr %l15, !tbaa !23
  %t34 = icmp eq i32 %t33, 65537
  br i1 %t34, label %bb11, label %bb12
bb11:
  call void @__olang_bang_failed_plain(ptr @olang_loc_eb3797cfa5f64105_1f3db8e929f64739)
  unreachable
bb12:
  %t36 = load i32, ptr %l15, !tbaa !23
  %t37 = icmp eq i32 %t36, 65538
  br i1 %t37, label %bb13, label %bb14
bb13:
  call void @__olang_bang_failed_plain(ptr @olang_loc_d2f375e5ba968b65_383d0166caeed659)
  unreachable
bb14:
  call void @__olang_bang_failed_plain(ptr @olang_loc_e527201c6aa166ab_3a4acb23654914bf)
  unreachable
bb15:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/lower:lowering", ptr %t39, i32 0, i32 43
  %t43 = call { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %t41)
  %t44 = extractvalue { i32, i64 } %t43, 1
  %t45 = extractvalue { i32, i64 } %t43, 0
  store i32 %t45, ptr %l23
  %t46 = icmp ne i32 %t45, 0
  br i1 %t46, label %bb17, label %ok.47, !prof !99
ok.47:
  store i64 %t44, ptr %l22
  br label %bb16
bb16:
  %t48 = load i64, ptr %l22, !tbaa !24
  store i64 %t48, ptr %l19, !tbaa !24
  br label %bb24
bb17:
  %t49 = load i32, ptr %l23, !tbaa !23
  %t50 = icmp eq i32 %t49, 65536
  br i1 %t50, label %bb18, label %bb19
bb18:
  call void @__olang_bang_failed_plain(ptr @olang_loc_f20c72191c5bbaec_70ba5090fad608c8)
  unreachable
bb19:
  %t52 = load i32, ptr %l23, !tbaa !23
  %t53 = icmp eq i32 %t52, 65537
  br i1 %t53, label %bb20, label %bb21
bb20:
  call void @__olang_bang_failed_plain(ptr @olang_loc_9792dafd009dd231_d222868cd9c52d2d)
  unreachable
bb21:
  %t55 = load i32, ptr %l23, !tbaa !23
  %t56 = icmp eq i32 %t55, 65538
  br i1 %t56, label %bb22, label %bb23
bb22:
  call void @__olang_bang_failed_plain(ptr @olang_loc_5cf7683923427be1_eeed011b70fc7f3d)
  unreachable
bb23:
  call void @__olang_bang_failed_plain(ptr @olang_loc_35262608d5eaeb07_a04d120ff2489083)
  unreachable
bb24:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2flower_2ecompiler_2flower_3alowering_2estorageBlock(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, [1 x i64] }
  %l9 = alloca { i64, [1 x i64] }
  %l11 = alloca { i64, ptr }
  %l23 = alloca %"compiler/typed:Local"
  %rv = alloca i32
  %t25 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"compiler/lower:lowering", ptr %t2, i32 0, i32 24
  %t5 = getelementptr %"compiler/typed:Plan", ptr %t4, i32 0, i32 1
  %t6 = load { i64, ptr }, ptr %t5, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  %t11 = icmp slt i64 %t1, %t8
  br i1 %t11, label %bb1, label %bb2
bb1:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/lower:lowering", ptr %t13, i32 0, i32 24
  %t16 = getelementptr %"compiler/typed:Plan", ptr %t15, i32 0, i32 1
  %t17 = load { i64, ptr }, ptr %t16, !tbaa !27
  store { i64, ptr } %t17, ptr %l11, !tbaa !27
  %t18 = load i64, ptr %l1, !tbaa !24
  %t20 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = getelementptr { i64, [1 x i64] }, ptr %t21, i64 %t18
  %t23 = load { i64, [1 x i64] }, ptr %t22
  store { i64, [1 x i64] } %t23, ptr %l9
  br label %bb3
bb2:
  store { i64, [1 x i64] } zeroinitializer, ptr %t25
  %t26 = getelementptr { i64, [1 x i64] }, ptr %t25, i32 0, i32 0
  store i64 0, ptr %t26
  %t27 = load { i64, [1 x i64] }, ptr %t25
  store { i64, [1 x i64] } %t27, ptr %l9
  br label %bb3
bb3:
  %t29 = load { i64, [1 x i64] }, ptr %l9
  store { i64, [1 x i64] } %t29, ptr %l2
  %t30 = load { i64, [1 x i64] }, ptr %l2
  %t32 = extractvalue { i64, [1 x i64] } %t30, 0
  %t33 = icmp eq i64 %t32, 1
  br i1 %t33, label %bb4, label %bb5
bb4:
  %t35 = getelementptr { i64, [1 x i64] }, ptr %l2, i32 0, i32 1
  %t36 = getelementptr { i32 }, ptr %t35, i32 0, i32 0
  %t37 = load i32, ptr %t36
  store i32 %t37, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/lower:lowering", ptr %t41, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !29
  %t46 = getelementptr %"compiler/typed:Body", ptr %t44, i32 0, i32 7
  %t47 = load i64, ptr %l1, !tbaa !24
  %t50 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t46, i64 %t47)
  store %"compiler/typed:Local" %t50, ptr %l23
  br label %bb7
bb7:
  %t51 = getelementptr %"compiler/typed:Local", ptr %l23, i32 0, i32 3
  %t52 = load i32, ptr %t51, !tbaa !23
  store i32 %t52, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2estorageOf(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca { i64, [1 x i64] }
  %l3 = alloca { i64, [1 x i64] }
  %l4 = alloca i32
  %l13 = alloca %"compiler/mir:Local"
  %l26 = alloca { i64, ptr }
  %l36 = alloca { i64, [1 x i64] }
  %l37 = alloca ptr
  %l43 = alloca %"compiler/typed:Local"
  %l46 = alloca { i64, [1 x i64] }
  %rv = alloca { i64, [1 x i64] }
  %t8 = alloca { i64, [1 x i64] }, align 8
  %t73 = alloca { i64, [1 x i64] }, align 8
  %t98 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 19
  %t4 = load i1, ptr %t3, !tbaa !21
  %t6 = xor i1 %t4, true
  br i1 %t6, label %bb1, label %bb2
bb1:
  store { i64, [1 x i64] } zeroinitializer, ptr %t8
  %t9 = getelementptr { i64, [1 x i64] }, ptr %t8, i32 0, i32 0
  store i64 2, ptr %t9
  %t10 = load { i64, [1 x i64] }, ptr %t8
  store { i64, [1 x i64] } %t10, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/lower:lowering", ptr %t12, i32 0, i32 3
  %t15 = getelementptr %"compiler/mir:Fn", ptr %t14, i32 0, i32 7
  %t16 = load i32, ptr %l1, !tbaa !23
  %t18 = sext i32 %t16 to i64
  %t21 = call %"compiler/mir:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eAt_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %t15, i64 %t18)
  store %"compiler/mir:Local" %t21, ptr %l13
  br label %bb4
bb4:
  %t22 = getelementptr %"compiler/mir:Local", ptr %l13, i32 0, i32 4
  %t23 = load { i64, [1 x i64] }, ptr %t22
  store { i64, [1 x i64] } %t23, ptr %l2
  %t25 = load { i64, [1 x i64] }, ptr %l2
  %t27 = extractvalue { i64, [1 x i64] } %t25, 0
  %t28 = icmp eq i64 %t27, 3
  %t30 = xor i1 %t28, true
  br i1 %t30, label %bb5, label %bb6
bb5:
  %t32 = load { i64, [1 x i64] }, ptr %l2
  store { i64, [1 x i64] } %t32, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t34 = load i32, ptr %l1, !tbaa !23
  %t36 = sext i32 %t34 to i64
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/lower:lowering", ptr %t37, i32 0, i32 24
  %t40 = getelementptr %"compiler/typed:Plan", ptr %t39, i32 0, i32 1
  %t41 = load { i64, ptr }, ptr %t40, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t41, 0
  %t46 = icmp slt i64 %t36, %t43
  br i1 %t46, label %bb8, label %bb9
bb8:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/lower:lowering", ptr %t48, i32 0, i32 24
  %t51 = getelementptr %"compiler/typed:Plan", ptr %t50, i32 0, i32 1
  %t52 = load { i64, ptr }, ptr %t51, !tbaa !27
  store { i64, ptr } %t52, ptr %l26, !tbaa !27
  %t53 = load i32, ptr %l1, !tbaa !23
  %t55 = sext i32 %t53 to i64
  %t57 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t58 = load ptr, ptr %t57, !tbaa !27
  %t59 = getelementptr { i64, [1 x i64] }, ptr %t58, i64 %t55
  %t60 = load { i64, [1 x i64] }, ptr %t59
  store { i64, [1 x i64] } %t60, ptr %l3
  %t62 = load { i64, [1 x i64] }, ptr %l3
  %t64 = extractvalue { i64, [1 x i64] } %t62, 0
  %t65 = icmp eq i64 %t64, 1
  br i1 %t65, label %bb10, label %bb11
bb9:
  br label %bb20
bb10:
  %t67 = getelementptr { i64, [1 x i64] }, ptr %l3, i32 0, i32 1
  %t68 = getelementptr { i32 }, ptr %t67, i32 0, i32 0
  %t69 = load i32, ptr %t68
  store i32 %t69, ptr %l4, !tbaa !23
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t72 = load i32, ptr %l4, !tbaa !23
  store { i64, [1 x i64] } zeroinitializer, ptr %t73
  %t74 = getelementptr { i64, [1 x i64] }, ptr %t73, i32 0, i32 0
  store i64 1, ptr %t74
  %t76 = insertvalue { i32 } undef, i32 %t72, 0
  %t77 = getelementptr { i64, [1 x i64] }, ptr %t73, i32 0, i32 1
  store { i32 } %t76, ptr %t77
  %t78 = load { i64, [1 x i64] }, ptr %t73
  %t81 = call { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2escopeRef(ptr %v0, ptr %t71, { i64, [1 x i64] } %t78)
  store { i64, [1 x i64] } %t81, ptr %l36
  br label %bb13
bb13:
  %t82 = load { i64, [1 x i64] }, ptr %l36
  store { i64, [1 x i64] } %t82, ptr %rv
  br label %ret
bb14:
  br i1 true, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_7c44d6a11fe580a3_63a95cd13601e77f)
  unreachable
bb19:
  br label %bb20
bb20:
  %t83 = load ptr, ptr %l0, !tbaa !29
  store ptr %t83, ptr %l37, !tbaa !29
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr %"compiler/lower:lowering", ptr %t84, i32 0, i32 1
  %t87 = load ptr, ptr %t86, !tbaa !29
  %t89 = getelementptr %"compiler/typed:Body", ptr %t87, i32 0, i32 7
  %t90 = load i32, ptr %l1, !tbaa !23
  %t92 = sext i32 %t90 to i64
  %t95 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t89, i64 %t92)
  store %"compiler/typed:Local" %t95, ptr %l43
  br label %bb21
bb21:
  %t96 = getelementptr %"compiler/typed:Local", ptr %l43, i32 0, i32 3
  %t97 = load i32, ptr %t96, !tbaa !23
  store { i64, [1 x i64] } zeroinitializer, ptr %t98
  %t99 = getelementptr { i64, [1 x i64] }, ptr %t98, i32 0, i32 0
  store i64 1, ptr %t99
  %t101 = insertvalue { i32 } undef, i32 %t97, 0
  %t102 = getelementptr { i64, [1 x i64] }, ptr %t98, i32 0, i32 1
  store { i32 } %t101, ptr %t102
  %t103 = load { i64, [1 x i64] }, ptr %t98
  %t104 = load ptr, ptr %l37, !tbaa !29
  %t106 = call { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2escopeRef(ptr %v0, ptr %t104, { i64, [1 x i64] } %t103)
  store { i64, [1 x i64] } %t106, ptr %l46
  br label %bb22
bb22:
  %t107 = load { i64, [1 x i64] }, ptr %l46
  store { i64, [1 x i64] } %t107, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [1 x i64] }, ptr %rv
  ret { i64, [1 x i64] } %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2esuspend(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca { i64, [4 x i64] }
  %l5 = alloca i32
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i32
  %l19 = alloca i32
  %l20 = alloca ptr
  %l24 = alloca { i64, [4 x i64] }
  %l29 = alloca { i64, [4 x i64] }
  %l36 = alloca i32
  %l44 = alloca i64
  %l45 = alloca { i64, [1 x i64] }
  %l51 = alloca i64
  %l55 = alloca i64
  %l58 = alloca i64
  %l76 = alloca i64
  %l78 = alloca ptr
  %l81 = alloca i64
  %l85 = alloca %"compiler/lower:level"
  %l92 = alloca i32
  %l93 = alloca ptr
  %l94 = alloca %"compiler/source:Span"
  %l96 = alloca %"compiler/mir:Lvalue"
  %l97 = alloca { i64, [4 x i64] }
  %l98 = alloca i32
  %l102 = alloca %"compiler/mir:Range"
  %s0 = alloca %olang.scope
  %t64 = alloca { i64, [1 x i64] }, align 8
  %t77 = alloca i64
  %t160 = alloca { i64, [1 x i64] }, align 8
  %t186 = alloca { i64, [4 x i64] }, align 8
  %t200 = alloca { i64, [8 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/lower:lowering", ptr %t5, i32 0, i32 1
  %t8 = load ptr, ptr %t7, !tbaa !29
  %t10 = getelementptr %"compiler/typed:Body", ptr %t8, i32 0, i32 2
  %t11 = load i32, ptr %t10, !tbaa !23
  %t14 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t4, i32 %t11)
  store i32 %t14, ptr %l19
  br label %bb1
bb1:
  %t15 = load i32, ptr %l19, !tbaa !23
  store i32 %t15, ptr %l3, !tbaa !23
  %t16 = load ptr, ptr %l0, !tbaa !29
  store ptr %t16, ptr %l20, !tbaa !29
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t18 = load ptr, ptr %l2, !tbaa !29
  %t22 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v1, ptr %t17, ptr %t18)
  store { i64, [4 x i64] } %t22, ptr %l24
  br label %bb2
bb2:
  %t23 = load ptr, ptr %l2, !tbaa !29
  %t25 = load i32, ptr %l3, !tbaa !23
  %t26 = load %"compiler/source:Span", ptr %l1
  %t27 = load ptr, ptr %l20, !tbaa !29
  %t28 = load { i64, [4 x i64] }, ptr %l24
  %t32 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2efit(ptr %v0, ptr %v1, ptr %t27, { i64, [4 x i64] } %t28, ptr %t23, i32 %t25, %"compiler/source:Span" %t26)
  store { i64, [4 x i64] } %t32, ptr %l29
  br label %bb3
bb3:
  %t33 = load { i64, [4 x i64] }, ptr %l29
  store { i64, [4 x i64] } %t33, ptr %l4
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/lower:lowering", ptr %t34, i32 0, i32 7
  %t37 = load i1, ptr %t36, !tbaa !21
  br i1 %t37, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb5:
  br label %bb6
bb6:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t40 = load { i64, [4 x i64] }, ptr %l4
  %t41 = load i32, ptr %l3, !tbaa !23
  %t42 = load %"compiler/source:Span", ptr %l1
  %t47 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2elocal(ptr %v0, ptr %t39, { i64, [4 x i64] } %t40, i32 %t41, %"compiler/source:Span" %t42)
  store i32 %t47, ptr %l36
  br label %bb7
bb7:
  %t48 = load i32, ptr %l36, !tbaa !23
  store i32 %t48, ptr %l5, !tbaa !23
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t50 = load i32, ptr %l5, !tbaa !23
  %t51 = load i32, ptr %l3, !tbaa !23
  %t52 = load ptr, ptr %l2, !tbaa !29
  %t53 = load %"compiler/source:Span", ptr %l1
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eretArrays(ptr %v0, ptr %v1, ptr %t49, i32 %t50, i32 %t51, ptr %t52, %"compiler/source:Span" %t53)
  br label %bb8
bb8:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/lower:lowering", ptr %t59, i32 0, i32 9
  %t63 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3alevel_3e_2eLen_3ccompiler_2flower_3alevel_3e(ptr %v0, ptr %t61)
  store i64 %t63, ptr %l44
  br label %bb9
bb9:
  store { i64, [1 x i64] } zeroinitializer, ptr %t64
  %t65 = getelementptr { i64, [1 x i64] }, ptr %t64, i32 0, i32 0
  store i64 3, ptr %t65
  %t66 = load { i64, [1 x i64] }, ptr %t64
  store { i64, [1 x i64] } %t66, ptr %l45
  %t67 = load i64, ptr %l44, !tbaa !24
  %t68 = icmp sge i64 %t67, 0
  br i1 %t68, label %bb10, label %bb11
bb10:
  %t70 = load i64, ptr %l44, !tbaa !24
  %t71 = icmp sle i64 %t70, 576460752303423487
  br i1 %t71, label %bb12, label %bb13
bb11:
  call void @__olang_check_failed(ptr @olang_loc_c2ea6282af4907c_77e331cc54ab44a0)
  unreachable
bb12:
  %t73 = load i64, ptr %l44, !tbaa !24
  %t74 = mul i64 %t73, 16
  %t75 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t74)
  %t76 = load { i64, [1 x i64] }, ptr %l45
  store i64 0, ptr %t77
  br label %fill.78
fill.78:
  %t81 = load i64, ptr %t77
  %t82 = icmp slt i64 %t81, %t73
  br i1 %t82, label %fillb.79, label %filld.80
fillb.79:
  %t83 = getelementptr { i64, [1 x i64] }, ptr %t75, i64 %t81
  store { i64, [1 x i64] } %t76, ptr %t83
  %t84 = add i64 %t81, 1
  store i64 %t84, ptr %t77
  br label %fill.78
filld.80:
  %t85 = insertvalue { i64, ptr } undef, i64 %t73, 0
  %t86 = insertvalue { i64, ptr } %t85, ptr %t75, 1
  store { i64, ptr } %t86, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t90 = getelementptr %"compiler/lower:lowering", ptr %t88, i32 0, i32 9
  %t92 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3alevel_3e_2eLen_3ccompiler_2flower_3alevel_3e(ptr %v0, ptr %t90)
  store i64 %t92, ptr %l51
  br label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_c2ea6282af4907c_77e331cc54ab44a0)
  unreachable
bb14:
  %t93 = load i64, ptr %l51, !tbaa !24
  store i64 %t93, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t94 = load i64, ptr %l8, !tbaa !24
  %t95 = load i64, ptr %l7, !tbaa !24
  %t98 = icmp sgt i64 %t94, %t95
  br i1 %t98, label %bb15, label %bb16
bb15:
  %t100 = load i64, ptr %l9, !tbaa !24
  %t102 = icmp sgt i64 %t100, 0
  br i1 %t102, label %bb17, label %bb18
bb16:
  store i64 0, ptr %l55, !tbaa !24
  br label %bb20
bb17:
  %t104 = load i64, ptr %l8, !tbaa !24
  %t105 = load i64, ptr %l7, !tbaa !24
  %t108 = sub i64 %t104, %t105
  %t109 = load i64, ptr %l9, !tbaa !24
  %t112 = add i64 %t108, %t109
  %t114 = sub i64 %t112, 1
  %t115 = load i64, ptr %l9, !tbaa !24
  %t118 = sdiv i64 %t114, %t115
  store i64 %t118, ptr %l58, !tbaa !24
  br label %bb19
bb18:
  store i64 0, ptr %l58, !tbaa !24
  br label %bb19
bb19:
  %t120 = load i64, ptr %l58, !tbaa !24
  store i64 %t120, ptr %l55, !tbaa !24
  br label %bb20
bb20:
  %t121 = load i64, ptr %l55, !tbaa !24
  store i64 %t121, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb21
bb21:
  %t122 = load i64, ptr %l11, !tbaa !24
  %t123 = load i64, ptr %l10, !tbaa !24
  %t126 = icmp slt i64 %t122, %t123
  %t128 = xor i1 %t126, true
  br i1 %t128, label %bb22, label %bb23
bb22:
  br label %bb28
bb23:
  br label %bb24
bb24:
  %t130 = load i64, ptr %l7, !tbaa !24
  %t131 = load i64, ptr %l11, !tbaa !24
  %t132 = load i64, ptr %l9, !tbaa !24
  %t135 = mul i64 %t131, %t132
  %t138 = add i64 %t130, %t135
  store i64 %t138, ptr %l12, !tbaa !24
  %t140 = load i64, ptr %l12, !tbaa !24
  store i64 %t140, ptr %l76, !tbaa !24
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t143 = getelementptr %"compiler/lower:lowering", ptr %t141, i32 0, i32 9
  store ptr %t143, ptr %l78, !tbaa !29
  %t144 = load ptr, ptr %l0, !tbaa !29
  %t146 = getelementptr %"compiler/lower:lowering", ptr %t144, i32 0, i32 9
  %t148 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3alevel_3e_2eLen_3ccompiler_2flower_3alevel_3e(ptr %v0, ptr %t146)
  store i64 %t148, ptr %l81
  br label %bb25
bb25:
  %t149 = load i64, ptr %l81, !tbaa !24
  %t150 = sub i64 %t149, 1
  %t151 = load i64, ptr %l12, !tbaa !24
  %t154 = sub i64 %t150, %t151
  %t155 = load ptr, ptr %l78, !tbaa !29
  %t157 = call %"compiler/lower:level" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3alevel_3e_2eAt_3ccompiler_2flower_3alevel_3e(ptr %v0, ptr %t155, i64 %t154)
  store %"compiler/lower:level" %t157, ptr %l85
  br label %bb26
bb26:
  %t158 = getelementptr %"compiler/lower:level", ptr %l85, i32 0, i32 0
  %t159 = load i32, ptr %t158, !tbaa !23
  store { i64, [1 x i64] } zeroinitializer, ptr %t160
  %t161 = getelementptr { i64, [1 x i64] }, ptr %t160, i32 0, i32 0
  store i64 0, ptr %t161
  %t163 = insertvalue { i32 } undef, i32 %t159, 0
  %t164 = getelementptr { i64, [1 x i64] }, ptr %t160, i32 0, i32 1
  store { i32 } %t163, ptr %t164
  %t165 = load { i64, [1 x i64] }, ptr %t160
  %t167 = load i64, ptr %l76, !tbaa !24
  %t168 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t169 = load ptr, ptr %t168, !tbaa !27
  %t170 = getelementptr { i64, [1 x i64] }, ptr %t169, i64 %t167
  store { i64, [1 x i64] } %t165, ptr %t170
  br label %bb27
bb27:
  %t171 = load i64, ptr %l11, !tbaa !24
  %t173 = add i64 %t171, 1
  store i64 %t173, ptr %l11, !tbaa !24
  br label %bb21
bb28:
  %t175 = load ptr, ptr %l0, !tbaa !29
  %t177 = getelementptr %"compiler/lower:lowering", ptr %t175, i32 0, i32 3
  %t179 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t177)
  store i32 %t179, ptr %l92
  br label %bb29
bb29:
  %t180 = load i32, ptr %l92, !tbaa !23
  store i32 %t180, ptr %l13, !tbaa !23
  %t181 = load ptr, ptr %l0, !tbaa !29
  store ptr %t181, ptr %l93, !tbaa !29
  %t182 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t182, ptr %l94
  %t183 = load i32, ptr %l5, !tbaa !23
  %t185 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t183)
  store %"compiler/mir:Lvalue" %t185, ptr %l96
  br label %bb30
bb30:
  store { i64, [4 x i64] } zeroinitializer, ptr %t186
  %t187 = getelementptr { i64, [4 x i64] }, ptr %t186, i32 0, i32 0
  store i64 1, ptr %t187
  %t188 = load %"compiler/mir:Lvalue", ptr %l96
  %t189 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t188, 0
  %t190 = getelementptr { i64, [4 x i64] }, ptr %t186, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t189, ptr %t190
  %t191 = load { i64, [4 x i64] }, ptr %t186
  store { i64, [4 x i64] } %t191, ptr %l97
  %t192 = load i32, ptr %l13, !tbaa !23
  store i32 %t192, ptr %l98, !tbaa !23
  %t193 = load ptr, ptr %l0, !tbaa !29
  %t195 = getelementptr %"compiler/lower:lowering", ptr %t193, i32 0, i32 3
  %t196 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t199 = call %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eScopeRefs(ptr %v0, ptr %s0, ptr %t195, { i64, ptr } %t196)
  store %"compiler/mir:Range" %t199, ptr %l102
  br label %bb31
bb31:
  store { i64, [8 x i64] } zeroinitializer, ptr %t200
  %t201 = getelementptr { i64, [8 x i64] }, ptr %t200, i32 0, i32 0
  store i64 11, ptr %t201
  %t202 = load %"compiler/source:Span", ptr %l94
  %t203 = insertvalue { %"compiler/source:Span", { i64, [4 x i64] }, i32, %"compiler/mir:Range" } undef, %"compiler/source:Span" %t202, 0
  %t204 = load { i64, [4 x i64] }, ptr %l97
  %t205 = insertvalue { %"compiler/source:Span", { i64, [4 x i64] }, i32, %"compiler/mir:Range" } %t203, { i64, [4 x i64] } %t204, 1
  %t206 = load i32, ptr %l98, !tbaa !23
  %t207 = insertvalue { %"compiler/source:Span", { i64, [4 x i64] }, i32, %"compiler/mir:Range" } %t205, i32 %t206, 2
  %t208 = load %"compiler/mir:Range", ptr %l102
  %t209 = insertvalue { %"compiler/source:Span", { i64, [4 x i64] }, i32, %"compiler/mir:Range" } %t207, %"compiler/mir:Range" %t208, 3
  %t210 = getelementptr { i64, [8 x i64] }, ptr %t200, i32 0, i32 1
  store { %"compiler/source:Span", { i64, [4 x i64] }, i32, %"compiler/mir:Range" } %t209, ptr %t210
  %t211 = load { i64, [8 x i64] }, ptr %t200
  %t212 = load ptr, ptr %l93, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t212, { i64, [8 x i64] } %t211)
  br label %bb32
bb32:
  %t214 = load ptr, ptr %l0, !tbaa !29
  %t215 = load i32, ptr %l13, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t214, i32 %t215)
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2etail(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca { { i64, [7 x i64] }, i32 }
  %l6 = alloca { i64, [7 x i64] }
  %l7 = alloca i32
  %l8 = alloca %"compiler/mir:Range"
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca { i64, [4 x i64] }
  %l19 = alloca %"compiler/mir:Range"
  %l20 = alloca %"compiler/mir:Range"
  %l28 = alloca { { i64, [7 x i64] }, i32 }
  %l37 = alloca %"compiler/mir:Range"
  %l40 = alloca ptr
  %l43 = alloca i32
  %l44 = alloca { i64, ptr }
  %l47 = alloca i64
  %l55 = alloca i64
  %l58 = alloca i64
  %l82 = alloca { i64, [4 x i64] }
  %l83 = alloca i64
  %l88 = alloca { i64, [4 x i64] }
  %l90 = alloca { i64, ptr }
  %l96 = alloca { i64, [4 x i64] }
  %l103 = alloca %"compiler/mir:Range"
  %l104 = alloca ptr
  %l108 = alloca i64
  %l111 = alloca %"compiler/mir:Range"
  %l114 = alloca ptr
  %l122 = alloca %"compiler/mir:Call"
  %l123 = alloca i32
  %s0 = alloca %olang.scope
  %t153 = alloca { i64, [15 x i64] }, align 8
  %t229 = alloca { i64, [8 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t7 = load ptr, ptr %l2, !tbaa !29
  %t9 = getelementptr %"compiler/typed:Call", ptr %t7, i32 0, i32 0
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t11 = load %"compiler/source:Span", ptr %l1
  %t15 = call { { i64, [7 x i64] }, i32 } @compiler_2flower_2ecompiler_2flower_3alowering_2ecallee(ptr %v0, ptr %v1, ptr %t6, ptr %t10, %"compiler/source:Span" %t11)
  store { { i64, [7 x i64] }, i32 } %t15, ptr %l28
  br label %bb1
bb1:
  %t16 = load { { i64, [7 x i64] }, i32 }, ptr %l28
  store { { i64, [7 x i64] }, i32 } %t16, ptr %l5
  %t17 = getelementptr { { i64, [7 x i64] }, i32 }, ptr %l5, i32 0, i32 0
  %t18 = load { i64, [7 x i64] }, ptr %t17
  store { i64, [7 x i64] } %t18, ptr %l6
  %t20 = getelementptr { { i64, [7 x i64] }, i32 }, ptr %l5, i32 0, i32 1
  %t21 = load i32, ptr %t20, !tbaa !23
  store i32 %t21, ptr %l7, !tbaa !23
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/lower:lowering", ptr %t23, i32 0, i32 7
  %t26 = load i1, ptr %t25, !tbaa !21
  br i1 %t26, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb3:
  br label %bb4
bb4:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load ptr, ptr %l2, !tbaa !29
  %t30 = load { i64, [7 x i64] }, ptr %l6
  %t31 = load i32, ptr %l7, !tbaa !23
  %t36 = call %"compiler/mir:Range" @compiler_2flower_2ecompiler_2flower_3alowering_2eargs(ptr %v0, ptr %v1, ptr %t28, ptr %t29, { i64, [7 x i64] } %t30, i32 %t31)
  store %"compiler/mir:Range" %t36, ptr %l37
  br label %bb5
bb5:
  %t37 = load %"compiler/mir:Range", ptr %l37
  store %"compiler/mir:Range" %t37, ptr %l8
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/lower:lowering", ptr %t38, i32 0, i32 7
  %t41 = load i1, ptr %t40, !tbaa !21
  br i1 %t41, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb7:
  br label %bb8
bb8:
  %t43 = load ptr, ptr %l4, !tbaa !29
  store ptr %t43, ptr %l40, !tbaa !29
  %t44 = load ptr, ptr %l4, !tbaa !29
  %t45 = load i32, ptr %l7, !tbaa !23
  %t48 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t44, i32 %t45)
  store i32 %t48, ptr %l43
  br label %bb9
bb9:
  %t49 = load ptr, ptr %l40, !tbaa !29
  %t50 = load i32, ptr %l43, !tbaa !23
  %t51 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t49, i32 %t50)
  store { i64, ptr } %t51, ptr %l44
  br label %bb10
bb10:
  %t52 = load { i64, ptr }, ptr %l44, !tbaa !27
  store { i64, ptr } %t52, ptr %l9, !tbaa !27
  %t53 = getelementptr %"compiler/mir:Range", ptr %l8, i32 0, i32 1
  %t54 = load i32, ptr %t53, !tbaa !23
  %t56 = sext i32 %t54 to i64
  store i64 %t56, ptr %l10, !tbaa !24
  %t58 = load i64, ptr %l10, !tbaa !24
  store i64 %t58, ptr %l47, !tbaa !24
  %t59 = load i64, ptr %l47, !tbaa !24
  %t60 = icmp sge i64 %t59, 0
  br i1 %t60, label %bb11, label %bb12
bb11:
  %t62 = load i64, ptr %l47, !tbaa !24
  %t63 = icmp sle i64 %t62, 230584300921369395
  br i1 %t63, label %bb13, label %bb14
bb12:
  call void @__olang_check_failed(ptr @olang_loc_16ceb3f79d83ba4c_75eb4aa6518e3548)
  unreachable
bb13:
  %t65 = load i64, ptr %l47, !tbaa !24
  %t66 = mul i64 %t65, 40
  %t67 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t66)
  %t68 = insertvalue { i64, ptr } undef, i64 %t65, 0
  %t69 = insertvalue { i64, ptr } %t68, ptr %t67, 1
  store { i64, ptr } %t69, ptr %l11, !tbaa !27
  store i64 0, ptr %l12, !tbaa !24
  %t71 = load i64, ptr %l10, !tbaa !24
  store i64 %t71, ptr %l13, !tbaa !24
  store i64 1, ptr %l14, !tbaa !24
  %t73 = load i64, ptr %l13, !tbaa !24
  %t74 = load i64, ptr %l12, !tbaa !24
  %t77 = icmp sgt i64 %t73, %t74
  br i1 %t77, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_16ceb3f79d83ba4c_75eb4aa6518e3548)
  unreachable
bb15:
  %t79 = load i64, ptr %l14, !tbaa !24
  %t81 = icmp sgt i64 %t79, 0
  br i1 %t81, label %bb17, label %bb18
bb16:
  store i64 0, ptr %l55, !tbaa !24
  br label %bb20
bb17:
  %t83 = load i64, ptr %l13, !tbaa !24
  %t84 = load i64, ptr %l12, !tbaa !24
  %t87 = sub i64 %t83, %t84
  %t88 = load i64, ptr %l14, !tbaa !24
  %t91 = add i64 %t87, %t88
  %t93 = sub i64 %t91, 1
  %t94 = load i64, ptr %l14, !tbaa !24
  %t97 = sdiv i64 %t93, %t94
  store i64 %t97, ptr %l58, !tbaa !24
  br label %bb19
bb18:
  store i64 0, ptr %l58, !tbaa !24
  br label %bb19
bb19:
  %t99 = load i64, ptr %l58, !tbaa !24
  store i64 %t99, ptr %l55, !tbaa !24
  br label %bb20
bb20:
  %t100 = load i64, ptr %l55, !tbaa !24
  store i64 %t100, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  br label %bb21
bb21:
  %t101 = load i64, ptr %l16, !tbaa !24
  %t102 = load i64, ptr %l15, !tbaa !24
  %t105 = icmp slt i64 %t101, %t102
  %t107 = xor i1 %t105, true
  br i1 %t107, label %bb22, label %bb23
bb22:
  br label %bb31
bb23:
  br label %bb24
bb24:
  %t109 = load i64, ptr %l12, !tbaa !24
  %t110 = load i64, ptr %l16, !tbaa !24
  %t111 = load i64, ptr %l14, !tbaa !24
  %t114 = mul i64 %t110, %t111
  %t117 = add i64 %t109, %t114
  store i64 %t117, ptr %l17, !tbaa !24
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t121 = getelementptr %"compiler/lower:lowering", ptr %t119, i32 0, i32 3
  %t122 = getelementptr %"compiler/mir:Fn", ptr %t121, i32 0, i32 11
  %t123 = getelementptr %"compiler/mir:Range", ptr %l8, i32 0, i32 0
  %t124 = load i32, ptr %t123, !tbaa !23
  %t126 = sext i32 %t124 to i64
  %t127 = load i64, ptr %l17, !tbaa !24
  %t130 = add i64 %t126, %t127
  %t133 = call { i64, [4 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2eAt_3ccompiler_2fmir_3aOperand_3e(ptr %v0, ptr %t122, i64 %t130)
  store { i64, [4 x i64] } %t133, ptr %l82
  br label %bb25
bb25:
  %t134 = load { i64, [4 x i64] }, ptr %l82
  store { i64, [4 x i64] } %t134, ptr %l18
  %t135 = load i64, ptr %l17, !tbaa !24
  store i64 %t135, ptr %l83, !tbaa !24
  %t136 = load i64, ptr %l17, !tbaa !24
  %t137 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t139 = extractvalue { i64, ptr } %t137, 0
  %t142 = icmp slt i64 %t136, %t139
  br i1 %t142, label %bb26, label %bb27
bb26:
  %t144 = load ptr, ptr %l0, !tbaa !29
  %t145 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t145, ptr %l90, !tbaa !27
  %t146 = load i64, ptr %l17, !tbaa !24
  %t148 = getelementptr { i64, ptr }, ptr %l90, i32 0, i32 1
  %t149 = load ptr, ptr %t148, !tbaa !27
  %t150 = getelementptr i32, ptr %t149, i64 %t146
  %t151 = load i32, ptr %t150, !tbaa !33
  %t152 = load { i64, [4 x i64] }, ptr %l18
  store { i64, [15 x i64] } zeroinitializer, ptr %t153
  %t154 = getelementptr { i64, [15 x i64] }, ptr %t153, i32 0, i32 0
  store i64 0, ptr %t154
  %t156 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t152, 0
  %t157 = getelementptr { i64, [15 x i64] }, ptr %t153, i32 0, i32 1
  store { { i64, [4 x i64] } } %t156, ptr %t157
  %t158 = load { i64, [15 x i64] }, ptr %t153
  %t159 = load %"compiler/source:Span", ptr %l1
  %t164 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %t144, i32 %t151, { i64, [15 x i64] } %t158, %"compiler/source:Span" %t159)
  store { i64, [4 x i64] } %t164, ptr %l96
  br label %bb28
bb27:
  %t165 = load { i64, [4 x i64] }, ptr %l18
  store { i64, [4 x i64] } %t165, ptr %l88
  br label %bb29
bb28:
  %t167 = load { i64, [4 x i64] }, ptr %l96
  store { i64, [4 x i64] } %t167, ptr %l88
  br label %bb29
bb29:
  %t168 = load { i64, [4 x i64] }, ptr %l88
  %t169 = load i64, ptr %l83, !tbaa !24
  %t170 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t171 = load ptr, ptr %t170, !tbaa !27
  %t172 = getelementptr { i64, [4 x i64] }, ptr %t171, i64 %t169
  store { i64, [4 x i64] } %t168, ptr %t172
  br label %bb30
bb30:
  %t173 = load i64, ptr %l16, !tbaa !24
  %t175 = add i64 %t173, 1
  store i64 %t175, ptr %l16, !tbaa !24
  br label %bb21
bb31:
  %t177 = load ptr, ptr %l0, !tbaa !29
  %t179 = getelementptr %"compiler/lower:lowering", ptr %t177, i32 0, i32 3
  %t180 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t183 = call %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eArgs(ptr %v0, ptr %s0, ptr %t179, { i64, ptr } %t180)
  store %"compiler/mir:Range" %t183, ptr %l103
  br label %bb32
bb32:
  %t184 = load %"compiler/mir:Range", ptr %l103
  store %"compiler/mir:Range" %t184, ptr %l19
  %t185 = load ptr, ptr %l0, !tbaa !29
  store ptr %t185, ptr %l104, !tbaa !29
  %t186 = load ptr, ptr %l4, !tbaa !29
  %t187 = load { i64, [7 x i64] }, ptr %l6
  %t188 = load i32, ptr %l7, !tbaa !23
  %t192 = call i64 @compiler_2fmir_2ePassedCount(ptr %v0, ptr %t186, { i64, [7 x i64] } %t187, i32 %t188)
  store i64 %t192, ptr %l108
  br label %bb33
bb33:
  %t193 = load ptr, ptr %l2, !tbaa !29
  %t195 = getelementptr %"compiler/typed:Call", ptr %t193, i32 0, i32 2
  %t196 = load i32, ptr %t195, !tbaa !23
  %t197 = load ptr, ptr %l104, !tbaa !29
  %t198 = load i64, ptr %l108, !tbaa !24
  %t200 = call %"compiler/mir:Range" @compiler_2flower_2ecompiler_2flower_3alowering_2epassed(ptr %v0, ptr %t197, i64 %t198, i32 %t196)
  store %"compiler/mir:Range" %t200, ptr %l111
  br label %bb34
bb34:
  %t201 = load %"compiler/mir:Range", ptr %l111
  store %"compiler/mir:Range" %t201, ptr %l20
  %t202 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eleave(ptr %v0, ptr %t202, i64 0)
  br label %bb35
bb35:
  %t204 = load ptr, ptr %l0, !tbaa !29
  %t206 = getelementptr %"compiler/lower:lowering", ptr %t204, i32 0, i32 3
  store ptr %t206, ptr %l114, !tbaa !29
  %t207 = load { i64, [7 x i64] }, ptr %l6
  %t208 = load %"compiler/mir:Range", ptr %l19
  %t209 = load %"compiler/mir:Range", ptr %l20
  %t210 = load %"compiler/mir:Lvalue", ptr @G_2ecompiler_2fmir_2eNoPlace
  %t211 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t212 = load i32, ptr @G_2ecompiler_2fmir_2eNoLocal, !tbaa !23
  %t213 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t221 = call %"compiler/mir:Call" @compiler_2fmir_3aCall_2ector(ptr %s0, { i64, [7 x i64] } %t207, %"compiler/mir:Range" %t208, %"compiler/mir:Range" %t209, %"compiler/mir:Lvalue" %t210, i1 false, i32 %t211, i32 %t212, i32 %t213)
  store %"compiler/mir:Call" %t221, ptr %l122
  br label %bb36
bb36:
  %t222 = load ptr, ptr %l114, !tbaa !29
  %t223 = load %"compiler/mir:Call", ptr %l122
  %t224 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddCall(ptr %v0, ptr %t222, %"compiler/mir:Call" %t223)
  store i32 %t224, ptr %l123
  br label %bb37
bb37:
  %t225 = load i32, ptr %l123, !tbaa !23
  %t226 = load ptr, ptr %l0, !tbaa !29
  %t227 = load %"compiler/source:Span", ptr %l1
  store { i64, [8 x i64] } zeroinitializer, ptr %t229
  %t230 = getelementptr { i64, [8 x i64] }, ptr %t229, i32 0, i32 0
  store i64 6, ptr %t230
  %t232 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t227, 0
  %t234 = insertvalue { %"compiler/source:Span", i32 } %t232, i32 %t225, 1
  %t235 = getelementptr { i64, [8 x i64] }, ptr %t229, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t234, ptr %t235
  %t236 = load { i64, [8 x i64] }, ptr %t229
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t226, { i64, [8 x i64] } %t236)
  br label %bb38
bb38:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2flower_2ecompiler_2flower_3alowering_2etemp(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %l7 = alloca i32
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/lower:lowering", ptr %a0, i32 0, i32 3
  %t9 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddTemp(ptr %v0, ptr %t3, i32 %a1, %"compiler/source:Span" %a2)
  store i32 %t9, ptr %l7
  br label %bb1
bb1:
  %t10 = load i32, ptr %l7, !tbaa !23
  store i32 %t10, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3alowering_2etryCopies(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l14 = alloca i1
  %l15 = alloca ptr
  %l21 = alloca i1
  %l31 = alloca { i64, ptr }
  %l42 = alloca { i64, ptr }
  %l47 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Try", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = icmp eq ptr %t4, null
  %t8 = xor i1 %t6, true
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l15, !tbaa !29
  %t11 = load ptr, ptr %l1, !tbaa !29
  %t13 = getelementptr %"compiler/typed:Try", ptr %t11, i32 0, i32 0
  %t14 = load ptr, ptr %t13, !tbaa !29
  %t16 = icmp eq ptr %t14, null
  br i1 %t16, label %bb3, label %bb4
bb2:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb7
bb3:
  call void @__olang_check_failed(ptr @olang_loc_a3627063ced14f10_5c0b773917422a84)
  unreachable
bb4:
  br label %bb5
bb5:
  %t18 = load ptr, ptr %l1, !tbaa !29
  %t20 = getelementptr %"compiler/typed:Try", ptr %t18, i32 0, i32 0
  %t21 = load ptr, ptr %t20, !tbaa !29
  %t22 = load ptr, ptr %l15, !tbaa !29
  %t24 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2ecopiesValue(ptr %v0, ptr %v1, ptr %t22, ptr %t21)
  store i1 %t24, ptr %l21
  br label %bb6
bb6:
  %t25 = load i1, ptr %l21, !tbaa !21
  store i1 %t25, ptr %l14, !tbaa !21
  br label %bb7
bb7:
  %t26 = load i1, ptr %l14, !tbaa !21
  br i1 %t26, label %bb8, label %bb9
bb8:
  store i1 true, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t28 = load ptr, ptr %l1, !tbaa !29
  %t30 = getelementptr %"compiler/typed:Try", ptr %t28, i32 0, i32 1
  %t31 = load { i64, ptr }, ptr %t30, !tbaa !27
  store { i64, ptr } %t31, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t33 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t35 = extractvalue { i64, ptr } %t33, 0
  store i64 %t35, ptr %l4, !tbaa !24
  br label %bb11
bb11:
  %t37 = load i64, ptr %l3, !tbaa !24
  %t38 = load i64, ptr %l4, !tbaa !24
  %t41 = icmp slt i64 %t37, %t38
  %t43 = xor i1 %t41, true
  br i1 %t43, label %bb12, label %bb13
bb12:
  br label %bb26
bb13:
  br label %bb14
bb14:
  %t45 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t45, ptr %l31, !tbaa !27
  %t46 = load i64, ptr %l3, !tbaa !24
  %t48 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !27
  %t50 = getelementptr ptr, ptr %t49, i64 %t46
  %t51 = load ptr, ptr %t50, !tbaa !39
  %t55 = getelementptr %"compiler/typed:Clause", ptr %t51, i32 0, i32 4
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  store { i64, ptr } %t56, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t58 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t60 = extractvalue { i64, ptr } %t58, 0
  store i64 %t60, ptr %l8, !tbaa !24
  br label %bb15
bb15:
  %t62 = load i64, ptr %l7, !tbaa !24
  %t63 = load i64, ptr %l8, !tbaa !24
  %t66 = icmp slt i64 %t62, %t63
  %t68 = xor i1 %t66, true
  br i1 %t68, label %bb16, label %bb17
bb16:
  br label %bb24
bb17:
  br label %bb18
bb18:
  %t70 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t70, ptr %l42, !tbaa !27
  %t71 = load i64, ptr %l7, !tbaa !24
  %t73 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t74 = load ptr, ptr %t73, !tbaa !27
  %t75 = getelementptr ptr, ptr %t74, i64 %t71
  %t76 = load ptr, ptr %t75, !tbaa !39
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t82 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2ecopiesValue(ptr %v0, ptr %v1, ptr %t78, ptr %t76)
  store i1 %t82, ptr %l47
  br label %bb19
bb19:
  %t83 = load i1, ptr %l47, !tbaa !21
  br i1 %t83, label %bb20, label %bb21
bb20:
  store i1 true, ptr %rv
  br label %ret
bb21:
  br label %bb22
bb22:
  br label %bb23
bb23:
  %t85 = load i64, ptr %l7, !tbaa !24
  %t87 = add i64 %t85, 1
  store i64 %t87, ptr %l7, !tbaa !24
  br label %bb15
bb24:
  br label %bb25
bb25:
  %t89 = load i64, ptr %l3, !tbaa !24
  %t91 = add i64 %t89, 1
  store i64 %t91, ptr %l3, !tbaa !24
  br label %bb11
bb26:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3alowering_2evalueArray(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca i32
  %l8 = alloca i32
  %l11 = alloca i32
  %l14 = alloca i1
  %l17 = alloca i32
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/lower:lowering", ptr %a0, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t6, i32 %a1)
  store i32 %t10, ptr %l8
  br label %bb1
bb1:
  %t11 = load i32, ptr %l8, !tbaa !23
  store i32 %t11, ptr %l3, !tbaa !23
  %t12 = load ptr, ptr %l2, !tbaa !29
  %t13 = load i32, ptr %l3, !tbaa !23
  %t16 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t12, i32 %t13)
  store i32 %t16, ptr %l11
  br label %bb2
bb2:
  %t17 = load i32, ptr %l11, !range !{i32 0, i32 33}
  %t19 = trunc i64 19 to i32
  %t20 = icmp eq i32 %t17, %t19
  br i1 %t20, label %bb3, label %bb4
bb3:
  %t22 = load ptr, ptr %l2, !tbaa !29
  %t23 = load i32, ptr %l3, !tbaa !23
  %t26 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t22, i32 %t23)
  store i32 %t26, ptr %l17
  br label %bb5
bb4:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb6
bb5:
  %t27 = load i32, ptr %l17, !tbaa !23
  %t28 = icmp eq i32 %t27, 0
  store i1 %t28, ptr %l14, !tbaa !21
  br label %bb6
bb6:
  %t30 = load i1, ptr %l14, !tbaa !21
  store i1 %t30, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2eviewTemps(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i1
  %l9 = alloca ptr
  %l10 = alloca i1
  %l13 = alloca i64
  %l17 = alloca i64
  %l20 = alloca i64
  %l39 = alloca ptr
  %l43 = alloca i64
  %l47 = alloca i64
  %l48 = alloca i1
  %l52 = alloca ptr
  %l53 = alloca ptr
  %l56 = alloca ptr
  %l60 = alloca i32
  %l62 = alloca i1
  %l66 = alloca i1
  %l69 = alloca ptr
  %l77 = alloca ptr
  %l82 = alloca ptr
  %l84 = alloca i64
  %l88 = alloca ptr
  %l89 = alloca %"compiler/source:Span"
  %l92 = alloca { i64, ptr }
  %l94 = alloca { i64, ptr }
  %l96 = alloca { i64, ptr }
  %s5 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l2, !tbaa !24
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/typed:LocalUses", ptr %t1, i32 0, i32 19
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v1, ptr %t3)
  store i64 %t5, ptr %l13
  br label %bb1
bb1:
  %t6 = load i64, ptr %l13, !tbaa !24
  store i64 %t6, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = load i64, ptr %l2, !tbaa !24
  %t11 = icmp sgt i64 %t7, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load i64, ptr %l4, !tbaa !24
  %t15 = icmp sgt i64 %t13, 0
  br i1 %t15, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l17, !tbaa !24
  br label %bb7
bb4:
  %t17 = load i64, ptr %l3, !tbaa !24
  %t18 = load i64, ptr %l2, !tbaa !24
  %t21 = sub i64 %t17, %t18
  %t22 = load i64, ptr %l4, !tbaa !24
  %t25 = add i64 %t21, %t22
  %t27 = sub i64 %t25, 1
  %t28 = load i64, ptr %l4, !tbaa !24
  %t31 = sdiv i64 %t27, %t28
  store i64 %t31, ptr %l20, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l20, !tbaa !24
  br label %bb6
bb6:
  %t33 = load i64, ptr %l20, !tbaa !24
  store i64 %t33, ptr %l17, !tbaa !24
  br label %bb7
bb7:
  %t34 = load i64, ptr %l17, !tbaa !24
  store i64 %t34, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb8
bb8:
  %t35 = load i64, ptr %l6, !tbaa !24
  %t36 = load i64, ptr %l5, !tbaa !24
  %t39 = icmp slt i64 %t35, %t36
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb9, label %bb10
bb9:
  br label %bb42
bb10:
  br label %bb11
bb11:
  %t43 = load i64, ptr %l2, !tbaa !24
  %t44 = load i64, ptr %l6, !tbaa !24
  %t45 = load i64, ptr %l4, !tbaa !24
  %t48 = mul i64 %t44, %t45
  %t51 = add i64 %t43, %t48
  store i64 %t51, ptr %l7, !tbaa !24
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/lower:lowering", ptr %t53, i32 0, i32 0
  %t56 = load ptr, ptr %t55, !tbaa !29
  store ptr %t56, ptr %l39, !tbaa !29
  %t57 = load ptr, ptr %l1, !tbaa !29
  %t59 = getelementptr %"compiler/typed:LocalUses", ptr %t57, i32 0, i32 20
  %t60 = load i64, ptr %l7, !tbaa !24
  %t63 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t59, i64 %t60)
  store i64 %t63, ptr %l43
  br label %bb12
bb12:
  %t64 = load ptr, ptr %l1, !tbaa !29
  %t66 = getelementptr %"compiler/typed:LocalUses", ptr %t64, i32 0, i32 21
  %t67 = load i64, ptr %l7, !tbaa !24
  %t70 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t66, i64 %t67)
  store i64 %t70, ptr %l47
  br label %bb13
bb13:
  %t71 = load ptr, ptr %l39, !tbaa !29
  %t72 = load i64, ptr %l43, !tbaa !24
  %t73 = load i64, ptr %l47, !tbaa !24
  %t74 = call i1 @compiler_2flower_2ecompiler_2flower_3aLowerer_2epreserves(ptr %v0, ptr %t71, i64 %t72, i64 %t73)
  store i1 %t74, ptr %l48
  br label %bb14
bb14:
  %t75 = load i1, ptr %l48, !tbaa !21
  store i1 %t75, ptr %l8, !tbaa !21
  %t76 = load ptr, ptr %l1, !tbaa !29
  %t78 = getelementptr %"compiler/typed:LocalUses", ptr %t76, i32 0, i32 19
  %t79 = load i64, ptr %l7, !tbaa !24
  %t82 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v1, ptr %v1, ptr %t78, i64 %t79)
  store ptr %t82, ptr %l52
  br label %bb15
bb15:
  %t83 = load ptr, ptr %l52, !tbaa !29
  %t84 = call ptr @compiler_2flower_2eviewCallIn(ptr %v1, ptr %v1, ptr %t83)
  store ptr %t84, ptr %l53
  br label %bb16
bb16:
  %t85 = load ptr, ptr %l53, !tbaa !29
  store ptr %t85, ptr %l9, !tbaa !29
  %t86 = load ptr, ptr %l9, !tbaa !29
  %t88 = icmp eq ptr %t86, null
  br i1 %t88, label %bb17, label %bb18
bb17:
  br label %bb41
bb18:
  br label %bb19
bb19:
  %t90 = load ptr, ptr %l0, !tbaa !29
  store ptr %t90, ptr %l56, !tbaa !29
  %t91 = load ptr, ptr %l1, !tbaa !29
  %t93 = getelementptr %"compiler/typed:LocalUses", ptr %t91, i32 0, i32 22
  %t94 = load i64, ptr %l7, !tbaa !24
  %t97 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2eAt_3ccompiler_2ftyped_3aBlockId_3e(ptr %v1, ptr %t93, i64 %t94)
  store i32 %t97, ptr %l60
  br label %bb20
bb20:
  %t98 = load i32, ptr %l60, !tbaa !23
  %t99 = load ptr, ptr %l56, !tbaa !29
  %t100 = getelementptr %"compiler/lower:lowering", ptr %t99, i32 0, i32 41
  store i32 %t98, ptr %t100, !tbaa !23
  %t101 = load i1, ptr %l8, !tbaa !21
  br i1 %t101, label %bb21, label %bb22
bb21:
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t104 = load ptr, ptr %l1, !tbaa !29
  %t105 = load ptr, ptr %l9, !tbaa !29
  %t109 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eheldViews(ptr %v0, ptr %v1, ptr %v1, ptr %t103, ptr %t104, ptr %t105)
  store i1 %t109, ptr %l66
  br label %bb23
bb22:
  store i1 false, ptr %l62, !tbaa !21
  br label %bb24
bb23:
  %t110 = load i1, ptr %l66, !tbaa !21
  store i1 %t110, ptr %l62, !tbaa !21
  br label %bb24
bb24:
  %t111 = load i1, ptr %l62, !tbaa !21
  store i1 %t111, ptr %l10, !tbaa !21
  %t112 = load i1, ptr %l10, !tbaa !21
  br i1 %t112, label %bb25, label %bb26
bb25:
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t116 = getelementptr %"compiler/lower:lowering", ptr %t114, i32 0, i32 0
  %t117 = load ptr, ptr %t116, !tbaa !29
  store ptr %t117, ptr %l69, !tbaa !29
  %t118 = load ptr, ptr %l69, !tbaa !29
  %t119 = getelementptr %"compiler/lower:Lowerer", ptr %t118, i32 0, i32 24
  %t120 = load i64, ptr %t119, !tbaa !24
  %t122 = add i64 %t120, 1
  %t124 = load ptr, ptr %l69, !tbaa !29
  %t125 = getelementptr %"compiler/lower:Lowerer", ptr %t124, i32 0, i32 24
  store i64 %t122, ptr %t125, !tbaa !24
  br label %bb27
bb26:
  br label %bb27
bb27:
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t128 = getelementptr %"compiler/lower:lowering", ptr %t126, i32 0, i32 0
  %t129 = load ptr, ptr %t128, !tbaa !29
  %t131 = getelementptr %"compiler/lower:Lowerer", ptr %t129, i32 0, i32 30
  %t132 = load i1, ptr %t131, !tbaa !21
  br i1 %t132, label %bb28, label %bb29
bb28:
  store %olang.scope zeroinitializer, ptr %s5
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t136 = getelementptr %"compiler/lower:lowering", ptr %t134, i32 0, i32 0
  %t137 = load ptr, ptr %t136, !tbaa !29
  %t139 = getelementptr %"compiler/lower:Lowerer", ptr %t137, i32 0, i32 31
  store ptr %t139, ptr %l77, !tbaa !29
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t142 = getelementptr %"compiler/lower:lowering", ptr %t140, i32 0, i32 0
  %t143 = load ptr, ptr %t142, !tbaa !29
  %t145 = getelementptr %"compiler/lower:Lowerer", ptr %t143, i32 0, i32 0
  %t146 = load ptr, ptr %t145, !tbaa !29
  %t148 = getelementptr %"compiler/generic:Program", ptr %t146, i32 0, i32 0
  %t149 = load ptr, ptr %t148, !tbaa !29
  %t151 = getelementptr %"compiler/load:Loader", ptr %t149, i32 0, i32 4
  %t152 = load ptr, ptr %t151, !tbaa !29
  store ptr %t152, ptr %l82, !tbaa !29
  %t153 = load ptr, ptr %l0, !tbaa !29
  %t155 = getelementptr %"compiler/lower:lowering", ptr %t153, i32 0, i32 4
  %t156 = load i64, ptr %t155, !tbaa !24
  store i64 %t156, ptr %l84, !tbaa !24
  %t157 = load ptr, ptr %l1, !tbaa !29
  %t159 = getelementptr %"compiler/typed:LocalUses", ptr %t157, i32 0, i32 19
  %t160 = load i64, ptr %l7, !tbaa !24
  %t163 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v1, ptr %v1, ptr %t159, i64 %t160)
  store ptr %t163, ptr %l88
  br label %bb30
bb29:
  br label %bb40
bb30:
  %t164 = load ptr, ptr %l88, !tbaa !29
  %t165 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v1, ptr %t164)
  store %"compiler/source:Span" %t165, ptr %l89
  br label %bb31
bb31:
  %t166 = getelementptr %"compiler/source:Span", ptr %l89, i32 0, i32 0
  %t167 = load i32, ptr %t166, !tbaa !23
  %t169 = sext i32 %t167 to i64
  %t170 = load ptr, ptr %l82, !tbaa !29
  %t171 = load i64, ptr %l84, !tbaa !24
  %t173 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLocate(ptr %v0, ptr %s5, ptr %t170, i64 %t171, i64 %t169)
  store { i64, ptr } %t173, ptr %l92
  br label %bb32
bb32:
  %t174 = load i1, ptr %l10, !tbaa !21
  br i1 %t174, label %bb33, label %bb34
bb33:
  store { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d6, i32 0, i32 1) }, ptr %l94, !tbaa !27
  br label %bb38
bb34:
  %t176 = load i1, ptr %l8, !tbaa !21
  br i1 %t176, label %bb35, label %bb36
bb35:
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d7, i32 0, i32 1) }, ptr %l96, !tbaa !27
  br label %bb37
bb36:
  store { i64, ptr } { i64 49, ptr getelementptr inbounds (<{ i64, [49 x i8] }>, ptr @.d8, i32 0, i32 1) }, ptr %l96, !tbaa !27
  br label %bb37
bb37:
  %t178 = load { i64, ptr }, ptr %l96, !tbaa !27
  store { i64, ptr } %t178, ptr %l94, !tbaa !27
  br label %bb38
bb38:
  %t179 = load { i64, ptr }, ptr %l92, !tbaa !27
  %t180 = extractvalue { i64, ptr } %t179, 1
  %t181 = extractvalue { i64, ptr } %t179, 0
  %t182 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d9, i32 0, i32 1) }, 1
  %t183 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d9, i32 0, i32 1) }, 0
  %t184 = add i64 %t181, %t183
  %t185 = load { i64, ptr }, ptr %l94, !tbaa !27
  %t186 = extractvalue { i64, ptr } %t185, 1
  %t187 = extractvalue { i64, ptr } %t185, 0
  %t188 = add i64 %t184, %t187
  %t189 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t188)
  call void @olang_textcopy(ptr %t189, ptr %t180, i64 %t181)
  %t190 = getelementptr i8, ptr %t189, i64 %t181
  call void @olang_textcopy(ptr %t190, ptr %t182, i64 %t183)
  %t191 = getelementptr i8, ptr %t190, i64 %t183
  call void @olang_textcopy(ptr %t191, ptr %t186, i64 %t187)
  %t192 = insertvalue { i64, ptr } undef, i64 %t188, 0
  %t193 = insertvalue { i64, ptr } %t192, ptr %t189, 1
  %t195 = extractvalue { i64, ptr } %t193, 0
  %t196 = extractvalue { i64, ptr } %t193, 1
  %t197 = mul i64 %t195, 1
  %t198 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t197)
  call void @llvm.memcpy.p0.p0.i64(ptr %t198, ptr %t196, i64 %t197, i1 false)
  %t199 = insertvalue { i64, ptr } undef, i64 %t195, 0
  %t200 = insertvalue { i64, ptr } %t199, ptr %t198, 1
  %t201 = load ptr, ptr %l77, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v0, ptr %t201, { i64, ptr } %t200)
  br label %bb39
bb39:
  call void @__olang_scope_close(ptr %s5)
  br label %bb40
bb40:
  br label %bb41
bb41:
  %t203 = load i64, ptr %l6, !tbaa !24
  %t205 = add i64 %t203, 1
  store i64 %t205, ptr %l6, !tbaa !24
  br label %bb8
bb42:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3alowering_2ewindowQuiet(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i32
  %l13 = alloca ptr
  %l15 = alloca i64
  %l18 = alloca i64
  %l21 = alloca i1
  %l31 = alloca i64
  %l35 = alloca i64
  %l38 = alloca i64
  %l57 = alloca i64
  %l62 = alloca { i64, ptr }
  %l65 = alloca i32
  %l66 = alloca ptr
  %l70 = alloca i1
  %l71 = alloca i32
  %l75 = alloca i32
  %l79 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l13, !tbaa !29
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t7 = call i64 @compiler_2ftyped_2eCalleeBody(ptr %v1, ptr %t5)
  store i64 %t7, ptr %l15
  br label %bb1
bb1:
  %t8 = load i64, ptr %l15, !tbaa !24
  %t9 = trunc i64 %t8 to i32
  %t11 = load ptr, ptr %l13, !tbaa !29
  %t13 = call i64 @compiler_2flower_2ecompiler_2flower_3aLowerer_2eViewsOf(ptr %v0, ptr %t11, i32 %t9)
  store i64 %t13, ptr %l18
  br label %bb2
bb2:
  %t14 = load i64, ptr %l18, !tbaa !24
  store i64 %t14, ptr %l4, !tbaa !24
  %t15 = load i64, ptr %l4, !tbaa !24
  %t17 = icmp sle i64 %t15, 0
  br i1 %t17, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l21, !tbaa !21
  br label %bb5
bb4:
  %t19 = load i64, ptr %l4, !tbaa !24
  %t20 = load i64, ptr @G_2ecompiler_2ftyped_2eViewOther, !tbaa !24
  %t23 = and i64 %t19, %t20
  %t25 = icmp ne i64 %t23, 0
  store i1 %t25, ptr %l21, !tbaa !21
  br label %bb5
bb5:
  %t27 = load i1, ptr %l21, !tbaa !21
  br i1 %t27, label %bb6, label %bb7
bb6:
  store i1 false, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  store i64 0, ptr %l5, !tbaa !24
  %t29 = load ptr, ptr %l1, !tbaa !29
  %t31 = getelementptr %"compiler/typed:Call", ptr %t29, i32 0, i32 1
  %t32 = load { i64, ptr }, ptr %t31, !tbaa !27
  %t34 = extractvalue { i64, ptr } %t32, 0
  %t35 = load i64, ptr @G_2ecompiler_2ftyped_2eViewBits, !tbaa !24
  %t38 = call i64 @std_2fprelude_2fnumber_2eI64_2eMin_3cI64_3e(i64 %t34, i64 %t35)
  store i64 %t38, ptr %l31
  br label %bb9
bb9:
  %t39 = load i64, ptr %l31, !tbaa !24
  store i64 %t39, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t40 = load i64, ptr %l6, !tbaa !24
  %t41 = load i64, ptr %l5, !tbaa !24
  %t44 = icmp sgt i64 %t40, %t41
  br i1 %t44, label %bb10, label %bb11
bb10:
  %t46 = load i64, ptr %l7, !tbaa !24
  %t48 = icmp sgt i64 %t46, 0
  br i1 %t48, label %bb12, label %bb13
bb11:
  store i64 0, ptr %l35, !tbaa !24
  br label %bb15
bb12:
  %t50 = load i64, ptr %l6, !tbaa !24
  %t51 = load i64, ptr %l5, !tbaa !24
  %t54 = sub i64 %t50, %t51
  %t55 = load i64, ptr %l7, !tbaa !24
  %t58 = add i64 %t54, %t55
  %t60 = sub i64 %t58, 1
  %t61 = load i64, ptr %l7, !tbaa !24
  %t64 = sdiv i64 %t60, %t61
  store i64 %t64, ptr %l38, !tbaa !24
  br label %bb14
bb13:
  store i64 0, ptr %l38, !tbaa !24
  br label %bb14
bb14:
  %t66 = load i64, ptr %l38, !tbaa !24
  store i64 %t66, ptr %l35, !tbaa !24
  br label %bb15
bb15:
  %t67 = load i64, ptr %l35, !tbaa !24
  store i64 %t67, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb16
bb16:
  %t68 = load i64, ptr %l9, !tbaa !24
  %t69 = load i64, ptr %l8, !tbaa !24
  %t72 = icmp slt i64 %t68, %t69
  %t74 = xor i1 %t72, true
  br i1 %t74, label %bb17, label %bb18
bb17:
  br label %bb34
bb18:
  br label %bb19
bb19:
  %t76 = load i64, ptr %l5, !tbaa !24
  %t77 = load i64, ptr %l9, !tbaa !24
  %t78 = load i64, ptr %l7, !tbaa !24
  %t81 = mul i64 %t77, %t78
  %t84 = add i64 %t76, %t81
  store i64 %t84, ptr %l10, !tbaa !24
  %t86 = load i64, ptr %l4, !tbaa !24
  %t87 = load i64, ptr %l10, !tbaa !24
  store i64 %t87, ptr %l57, !tbaa !24
  %t88 = load i64, ptr %l57, !tbaa !24
  %t89 = load i64, ptr %l57, !tbaa !24
  %t90 = shl i64 1, %t89
  %t93 = and i64 %t86, %t90
  %t95 = icmp eq i64 %t93, 0
  br i1 %t95, label %bb20, label %bb21
bb20:
  br label %bb33
bb21:
  br label %bb22
bb22:
  %t97 = load ptr, ptr %l1, !tbaa !29
  %t99 = getelementptr %"compiler/typed:Call", ptr %t97, i32 0, i32 1
  %t100 = load { i64, ptr }, ptr %t99, !tbaa !27
  store { i64, ptr } %t100, ptr %l62, !tbaa !27
  %t101 = load i64, ptr %l10, !tbaa !24
  %t103 = getelementptr { i64, ptr }, ptr %l62, i32 0, i32 1
  %t104 = load ptr, ptr %t103, !tbaa !27
  %t105 = getelementptr ptr, ptr %t104, i64 %t101
  %t106 = load ptr, ptr %t105, !tbaa !39
  %t108 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t106)
  store i32 %t108, ptr %l65
  br label %bb23
bb23:
  %t109 = load i32, ptr %l65, !tbaa !23
  store i32 %t109, ptr %l11, !tbaa !23
  %t110 = load ptr, ptr %l0, !tbaa !29
  store ptr %t110, ptr %l66, !tbaa !29
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t113 = getelementptr %"compiler/lower:lowering", ptr %t111, i32 0, i32 2
  %t114 = load ptr, ptr %t113, !tbaa !29
  %t115 = load i32, ptr %l11, !tbaa !23
  %t118 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t114, i32 %t115)
  store i1 %t118, ptr %l70
  br label %bb24
bb24:
  %t119 = load i1, ptr %l70, !tbaa !21
  br i1 %t119, label %bb25, label %bb26
bb25:
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t122 = getelementptr %"compiler/lower:lowering", ptr %t120, i32 0, i32 2
  %t123 = load ptr, ptr %t122, !tbaa !29
  %t124 = load i32, ptr %l11, !tbaa !23
  %t127 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t123, i32 %t124)
  store i32 %t127, ptr %l75
  br label %bb27
bb26:
  %t128 = load i32, ptr %l11, !tbaa !23
  store i32 %t128, ptr %l71, !tbaa !23
  br label %bb28
bb27:
  %t130 = load i32, ptr %l75, !tbaa !23
  store i32 %t130, ptr %l71, !tbaa !23
  br label %bb28
bb28:
  %t133 = load ptr, ptr %l66, !tbaa !29
  %t134 = load i32, ptr %l71, !tbaa !23
  %t137 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2ewindowFor(ptr %v0, ptr %v2, ptr %v3, ptr %t133, i32 %t134, ptr %a2, ptr %a3)
  store i1 %t137, ptr %l79
  br label %bb29
bb29:
  %t138 = load i1, ptr %l79, !tbaa !21
  %t139 = xor i1 %t138, true
  br i1 %t139, label %bb30, label %bb31
bb30:
  store i1 false, ptr %rv
  br label %ret
bb31:
  br label %bb32
bb32:
  br label %bb33
bb33:
  %t142 = load i64, ptr %l9, !tbaa !24
  %t144 = add i64 %t142, 1
  store i64 %t144, ptr %l9, !tbaa !24
  br label %bb16
bb34:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ezero(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca %"compiler/source:Span"
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca { i64, [7 x i64] }
  %l7 = alloca i32
  %l8 = alloca i32
  %l16 = alloca i32
  %l20 = alloca i32
  %l33 = alloca i32
  %l37 = alloca i32
  %l39 = alloca ptr
  %l40 = alloca { i64, [7 x i64] }
  %l41 = alloca %"compiler/mir:Range"
  %l42 = alloca ptr
  %l46 = alloca i64
  %l48 = alloca %"compiler/mir:Range"
  %l50 = alloca %"compiler/mir:Lvalue"
  %l54 = alloca %"compiler/mir:Call"
  %l55 = alloca i32
  %l63 = alloca %"compiler/mir:Lvalue"
  %s0 = alloca %olang.scope
  %rv = alloca { i64, [4 x i64] }
  %t24 = alloca { i64, [2 x i64] }, align 8
  %t33 = alloca { i64, [7 x i64] }, align 8
  %t47 = alloca { i64, [2 x i64] }, align 8
  %t110 = alloca { i64, [8 x i64] }, align 8
  %t127 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/lower:lowering", ptr %t6, i32 0, i32 0
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t10 = load i32, ptr %l1, !tbaa !23
  %t14 = call i32 @compiler_2flower_2ecompiler_2flower_3aLowerer_2ehelperTy(ptr %v0, ptr %t9, i32 3, i32 %t10)
  store i32 %t14, ptr %l16
  br label %bb1
bb1:
  %t15 = load i32, ptr %l16, !tbaa !23
  store i32 %t15, ptr %l1, !tbaa !23
  %t16 = load ptr, ptr %l4, !tbaa !29
  %t17 = load i32, ptr %l1, !tbaa !23
  %t21 = call i32 @compiler_2fmir_2eHelperType(ptr %v0, ptr %t16, i32 3, i32 %t17)
  store i32 %t21, ptr %l20
  br label %bb2
bb2:
  %t22 = load i32, ptr %l20, !tbaa !23
  store i32 %t22, ptr %l5, !tbaa !23
  %t23 = load i32, ptr %l1, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t24
  %t25 = getelementptr { i64, [2 x i64] }, ptr %t24, i32 0, i32 0
  store i64 3, ptr %t25
  %t27 = insertvalue { i32, i32 } undef, i32 3, 0
  %t29 = insertvalue { i32, i32 } %t27, i32 %t23, 1
  %t30 = getelementptr { i64, [2 x i64] }, ptr %t24, i32 0, i32 1
  store { i32, i32 } %t29, ptr %t30
  %t31 = load { i64, [2 x i64] }, ptr %t24
  %t32 = load i32, ptr %l5, !tbaa !23
  store { i64, [7 x i64] } zeroinitializer, ptr %t33
  %t34 = getelementptr { i64, [7 x i64] }, ptr %t33, i32 0, i32 0
  store i64 0, ptr %t34
  %t36 = insertvalue { { i64, [2 x i64] }, i32 } undef, { i64, [2 x i64] } %t31, 0
  %t38 = insertvalue { { i64, [2 x i64] }, i32 } %t36, i32 %t32, 1
  %t39 = getelementptr { i64, [7 x i64] }, ptr %t33, i32 0, i32 1
  store { { i64, [2 x i64] }, i32 } %t38, ptr %t39
  %t40 = load { i64, [7 x i64] }, ptr %t33
  store { i64, [7 x i64] } %t40, ptr %l6
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/lower:lowering", ptr %t42, i32 0, i32 0
  %t45 = load ptr, ptr %t44, !tbaa !29
  %t46 = load i32, ptr %l1, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t47
  %t48 = getelementptr { i64, [2 x i64] }, ptr %t47, i32 0, i32 0
  store i64 3, ptr %t48
  %t50 = insertvalue { i32, i32 } undef, i32 3, 0
  %t52 = insertvalue { i32, i32 } %t50, i32 %t46, 1
  %t53 = getelementptr { i64, [2 x i64] }, ptr %t47, i32 0, i32 1
  store { i32, i32 } %t52, ptr %t53
  %t54 = load { i64, [2 x i64] }, ptr %t47
  call void @compiler_2flower_2ecompiler_2flower_3aLowerer_2eWant(ptr %v0, ptr %t45, { i64, [2 x i64] } %t54)
  br label %bb3
bb3:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/lower:lowering", ptr %t57, i32 0, i32 3
  %t61 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t59)
  store i32 %t61, ptr %l33
  br label %bb4
bb4:
  %t62 = load i32, ptr %l33, !tbaa !23
  store i32 %t62, ptr %l7, !tbaa !23
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t64 = load i32, ptr %l1, !tbaa !23
  %t65 = load %"compiler/source:Span", ptr %l2
  %t69 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2etemp(ptr %v0, ptr %t63, i32 %t64, %"compiler/source:Span" %t65)
  store i32 %t69, ptr %l37
  br label %bb5
bb5:
  %t70 = load i32, ptr %l37, !tbaa !23
  store i32 %t70, ptr %l8, !tbaa !23
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/lower:lowering", ptr %t71, i32 0, i32 3
  store ptr %t73, ptr %l39, !tbaa !29
  %t74 = load { i64, [7 x i64] }, ptr %l6
  store { i64, [7 x i64] } %t74, ptr %l40
  %t75 = load %"compiler/mir:Range", ptr @G_2ecompiler_2fmir_2eEmpty
  store %"compiler/mir:Range" %t75, ptr %l41
  %t76 = load ptr, ptr %l0, !tbaa !29
  store ptr %t76, ptr %l42, !tbaa !29
  %t77 = load ptr, ptr %l4, !tbaa !29
  %t78 = load { i64, [7 x i64] }, ptr %l6
  %t79 = load i32, ptr %l5, !tbaa !23
  %t83 = call i64 @compiler_2fmir_2ePassedCount(ptr %v0, ptr %t77, { i64, [7 x i64] } %t78, i32 %t79)
  store i64 %t83, ptr %l46
  br label %bb6
bb6:
  %t85 = load ptr, ptr %l42, !tbaa !29
  %t86 = load i64, ptr %l46, !tbaa !24
  %t88 = call %"compiler/mir:Range" @compiler_2flower_2ecompiler_2flower_3alowering_2epassed(ptr %v0, ptr %t85, i64 %t86, i32 %a3)
  store %"compiler/mir:Range" %t88, ptr %l48
  br label %bb7
bb7:
  %t89 = load i32, ptr %l8, !tbaa !23
  %t91 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t89)
  store %"compiler/mir:Lvalue" %t91, ptr %l50
  br label %bb8
bb8:
  %t92 = load i32, ptr %l7, !tbaa !23
  %t93 = load i32, ptr @G_2ecompiler_2fmir_2eNoLocal, !tbaa !23
  %t94 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t95 = load { i64, [7 x i64] }, ptr %l40
  %t96 = load %"compiler/mir:Range", ptr %l41
  %t97 = load %"compiler/mir:Range", ptr %l48
  %t98 = load %"compiler/mir:Lvalue", ptr %l50
  %t102 = call %"compiler/mir:Call" @compiler_2fmir_3aCall_2ector(ptr %s0, { i64, [7 x i64] } %t95, %"compiler/mir:Range" %t96, %"compiler/mir:Range" %t97, %"compiler/mir:Lvalue" %t98, i1 true, i32 %t92, i32 %t93, i32 %t94)
  store %"compiler/mir:Call" %t102, ptr %l54
  br label %bb9
bb9:
  %t103 = load ptr, ptr %l39, !tbaa !29
  %t104 = load %"compiler/mir:Call", ptr %l54
  %t105 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddCall(ptr %v0, ptr %t103, %"compiler/mir:Call" %t104)
  store i32 %t105, ptr %l55
  br label %bb10
bb10:
  %t106 = load i32, ptr %l55, !tbaa !23
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t108 = load %"compiler/source:Span", ptr %l2
  store { i64, [8 x i64] } zeroinitializer, ptr %t110
  %t111 = getelementptr { i64, [8 x i64] }, ptr %t110, i32 0, i32 0
  store i64 4, ptr %t111
  %t113 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t108, 0
  %t115 = insertvalue { %"compiler/source:Span", i32 } %t113, i32 %t106, 1
  %t116 = getelementptr { i64, [8 x i64] }, ptr %t110, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t115, ptr %t116
  %t117 = load { i64, [8 x i64] }, ptr %t110
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t107, { i64, [8 x i64] } %t117)
  br label %bb11
bb11:
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t121 = load i32, ptr %l7, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t120, i32 %t121)
  br label %bb12
bb12:
  %t124 = load i32, ptr %l8, !tbaa !23
  %t126 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t124)
  store %"compiler/mir:Lvalue" %t126, ptr %l63
  br label %bb13
bb13:
  store { i64, [4 x i64] } zeroinitializer, ptr %t127
  %t128 = getelementptr { i64, [4 x i64] }, ptr %t127, i32 0, i32 0
  store i64 1, ptr %t128
  %t129 = load %"compiler/mir:Lvalue", ptr %l63
  %t130 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t129, 0
  %t131 = getelementptr { i64, [4 x i64] }, ptr %t127, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t130, ptr %t131
  %t132 = load { i64, [4 x i64] }, ptr %t127
  call void @__olang_scope_close(ptr %s0)
  store { i64, [4 x i64] } %t132, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local void @compiler_2flower_2estandIn(ptr %out, ptr %v0, i32 %a0) #0 {
entry:
  %l1 = alloca { i64, [2 x i64] }
  %l2 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca %"compiler/typed:Body"
  %s0 = alloca %olang.scope
  %t1 = alloca { i64, [2 x i64] }, align 8
  %t8 = alloca %"compiler/typed:Body", align 8
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store { i64, [2 x i64] } zeroinitializer, ptr %t1
  %t2 = getelementptr { i64, [2 x i64] }, ptr %t1, i32 0, i32 0
  store i64 5, ptr %t2
  %t3 = insertvalue { i64 } undef, i64 -1, 0
  %t4 = getelementptr { i64, [2 x i64] }, ptr %t1, i32 0, i32 1
  store { i64 } %t3, ptr %t4
  %t5 = load { i64, [2 x i64] }, ptr %t1
  store { i64, [2 x i64] } %t5, ptr %l1
  store i32 %a0, ptr %l2, !tbaa !23
  %t7 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 0, i32 0)
  store %"compiler/source:Span" %t7, ptr %l3
  br label %bb1
bb1:
  %t9 = load { i64, [2 x i64] }, ptr %l1
  %t10 = load i32, ptr %l2, !tbaa !23
  %t11 = load %"compiler/source:Span", ptr %l3
  call void @compiler_2ftyped_3aBody_2ector(ptr %t8, ptr %v0, i32 -1, { i64, [2 x i64] } %t9, i32 %t10, i64 0, %"compiler/source:Span" %t11)
  call void @llvm.memmove.p0.p0.i64(ptr %l4, ptr %t8, i64 408, i1 false)
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l4, i64 408, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2flower_2etempViewCall(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i1
  %l10 = alloca ptr
  %l11 = alloca i1
  %l17 = alloca ptr
  %l18 = alloca ptr
  %l19 = alloca i1
  %l25 = alloca ptr
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 3
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb9
bb4:
  %t16 = load ptr, ptr %l0, !tbaa !29
  store ptr %t16, ptr %l10, !tbaa !29
  store i1 false, ptr %l11, !tbaa !21
  %t17 = load ptr, ptr %l10, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb5, label %bb6
bb5:
  %t20 = load ptr, ptr %l10, !tbaa !29
  %t21 = load i64, ptr %t20, !range !{i64 0, i64 18}
  %t23 = icmp eq i64 %t21, 2
  store i1 %t23, ptr %l11, !tbaa !21
  br label %bb6
bb6:
  %t24 = load i1, ptr %l11, !tbaa !21
  br i1 %t24, label %bb7, label %bb8
bb7:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr { i64, [5 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t27, i32 0, i32 2
  %t29 = load ptr, ptr %t28
  store ptr %t29, ptr %l1, !tbaa !29
  br label %bb9
bb8:
  br label %bb11
bb9:
  %t31 = load ptr, ptr %l1, !tbaa !29
  %t33 = call ptr @compiler_2flower_2etempRoot(ptr %v0, ptr %v1, ptr %t31)
  store ptr %t33, ptr %l17
  br label %bb10
bb10:
  %t34 = load ptr, ptr %l17, !tbaa !29
  store ptr %t34, ptr %l3, !tbaa !29
  br label %bb23
bb11:
  %t35 = load ptr, ptr %l0, !tbaa !29
  store ptr %t35, ptr %l18, !tbaa !29
  store i1 false, ptr %l19, !tbaa !21
  %t36 = load ptr, ptr %l18, !tbaa !29
  %t37 = icmp ne ptr %t36, null
  br i1 %t37, label %bb12, label %bb13
bb12:
  %t39 = load ptr, ptr %l18, !tbaa !29
  %t40 = load i64, ptr %t39, !range !{i64 0, i64 18}
  %t42 = icmp eq i64 %t40, 17
  store i1 %t42, ptr %l19, !tbaa !21
  br label %bb13
bb13:
  %t43 = load i1, ptr %l19, !tbaa !21
  br i1 %t43, label %bb14, label %bb15
bb14:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr { i64, [5 x i64] }, ptr %t44, i32 0, i32 1
  %t47 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t46, i32 0, i32 2
  %t48 = load ptr, ptr %t47
  store ptr %t48, ptr %l2, !tbaa !29
  br label %bb16
bb15:
  br label %bb18
bb16:
  %t50 = load ptr, ptr %l2, !tbaa !29
  %t52 = call ptr @compiler_2flower_2etempViewCall(ptr %v0, ptr %v1, ptr %t50)
  store ptr %t52, ptr %l25
  br label %bb17
bb17:
  %t53 = load ptr, ptr %l25, !tbaa !29
  store ptr %t53, ptr %l3, !tbaa !29
  br label %bb23
bb18:
  br i1 true, label %bb19, label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb22
bb21:
  store ptr null, ptr %l3, !tbaa !29
  br label %bb23
bb22:
  call void @__olang_check_failed(ptr @olang_loc_45fce2847dc3b097_fb8f06ed07981043)
  unreachable
bb23:
  %t54 = load ptr, ptr %l3, !tbaa !29
  store ptr %t54, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local %"compiler/lower:Gap" @compiler_2flower_3aGap_2ector(ptr %v0, ptr %v1, i64 %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2) #0 {
entry:
  %rv = alloca %"compiler/lower:Gap"
  br label %start
start:
  br label %bb0
bb0:
  %t8 = insertvalue %"compiler/lower:Gap" undef, i64 %a0, 0
  %t10 = insertvalue %"compiler/lower:Gap" %t8, %"compiler/source:Span" %a1, 1
  %t12 = insertvalue %"compiler/lower:Gap" %t10, { i64, ptr } %a2, 2
  store %"compiler/lower:Gap" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/lower:Gap", ptr %rv
  ret %"compiler/lower:Gap" %rr
}

define dso_local %"compiler/lower:tryCtx" @compiler_2flower_3atryCtx_2ector(ptr %v0, ptr %v1, i64 %a0, { i64, ptr } %a1, i1 %a2, i1 %a3) #0 {
entry:
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca i1
  %l7 = alloca i1
  %l13 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %rv = alloca %"compiler/lower:tryCtx"
  br label %start
start:
  br label %bb0
bb0:
  store i64 %a0, ptr %l4, !tbaa !24
  store { i64, ptr } %a1, ptr %l5, !tbaa !27
  store i1 %a2, ptr %l6, !tbaa !21
  store i1 %a3, ptr %l7, !tbaa !21
  %t9 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBlockId_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %l13
  br label %bb1
bb1:
  %t10 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l13
  %t11 = load i64, ptr %l4, !tbaa !24
  %t12 = insertvalue %"compiler/lower:tryCtx" undef, i64 %t11, 0
  %t13 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t14 = insertvalue %"compiler/lower:tryCtx" %t12, { i64, ptr } %t13, 1
  %t15 = load i1, ptr %l6, !tbaa !21
  %t16 = insertvalue %"compiler/lower:tryCtx" %t14, i1 %t15, 2
  %t17 = load i1, ptr %l7, !tbaa !21
  %t18 = insertvalue %"compiler/lower:tryCtx" %t16, i1 %t17, 3
  %t20 = insertvalue %"compiler/lower:tryCtx" %t18, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t10, 4
  store %"compiler/lower:tryCtx" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/lower:tryCtx", ptr %rv
  ret %"compiler/lower:tryCtx" %rr
}

declare void @__olang_check_failed(ptr) cold noreturn
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
@.d0 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"std/prelude/iterator" }>, align 8
@.d1 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"Exhausted" }>, align 8
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  call void @__olang_dtor_head(ptr %fd, ptr %pdp)
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %dhasnext = icmp ne ptr %dnext, null
  br i1 %dhasnext, label %dfixpp, label %drun
dfixpp:
  %dnpp = getelementptr %olang.dtornode, ptr %dnext, i32 0, i32 3
  store ptr %dheadptr, ptr %dnpp
  br label %drun
drun:
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  call void @__olang_dtor_head(ptr %wfd, ptr %dheadptr)
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
define linkonce_odr void @olang_2eHelperKind_2eCopy_2ecompiler_2flower_3alowering(ptr %out, ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"compiler/lower:lowering"
  %l3 = alloca %"compiler/mir:Fn"
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l9 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l11 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l13 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l15 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l17 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l19 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l21 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l23 = alloca %"compiler/typed:Plan"
  %l25 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l27 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l29 = alloca %"compiler/typed:DropHolding"
  %l31 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l33 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l35 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l37 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l39 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l41 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l43 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l45 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l47 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l49 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l51 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %t3 = alloca %"compiler/mir:Fn", align 8
  %t52 = alloca %"compiler/typed:Plan", align 8
  br label %start
start:
  br label %bb0
bb0:
  call void @llvm.memmove.p0.p0.i64(ptr %l1, ptr %a0, i64 2400, i1 false)
  %t2 = getelementptr %"compiler/lower:lowering", ptr %l1, i32 0, i32 3
  call void @olang_2eHelperKind_2eCopy_2ecompiler_2fmir_3aFn(ptr %t3, ptr %v0, ptr %t2)
  call void @llvm.memmove.p0.p0.i64(ptr %l3, ptr %t3, i64 800, i1 false)
  br label %bb1
bb1:
  %t5 = getelementptr %"compiler/lower:lowering", ptr %l1, i32 0, i32 3
  call void @llvm.memmove.p0.p0.i64(ptr %t5, ptr %l3, i64 800, i1 false)
  %t6 = getelementptr %"compiler/lower:lowering", ptr %l1, i32 0, i32 9
  %t8 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3alevel_3e(ptr %v0, ptr %t6)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t8, ptr %l5
  br label %bb2
bb2:
  %t9 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l5
  %t10 = getelementptr %"compiler/lower:lowering", ptr %l1, i32 0, i32 9
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %t10
  %t11 = getelementptr %"compiler/lower:lowering", ptr %l1, i32 0, i32 10
  %t13 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlock_26_3e(ptr %v0, ptr %t11)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t13, ptr %l7
  br label %bb3
bb3:
  %t14 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l7
  %t15 = getelementptr %"compiler/lower:lowering", ptr %l1, i32 0, i32 10
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t14, ptr %t15
  %t16 = getelementptr %"compiler/lower:lowering", ptr %l1, i32 0, i32 11
  %t18 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t16)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t18, ptr %l9
  br label %bb4
bb4:
  %t19 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l9
  %t20 = getelementptr %"compiler/lower:lowering", ptr %l1, i32 0, i32 11
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t19, ptr %t20
  %t21 = getelementptr %"compiler/lower:lowering", ptr %l1, i32 0, i32 12
  %t23 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3aloopCtx_3e(ptr %v0, ptr %t21)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t23, ptr %l11
  br label %bb5
bb5:
  %t24 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l11
  %t25 = getelementptr %"compiler/lower:lowering", ptr %l1, i32 0, i32 12
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t24, ptr %t25
  %t26 = getelementptr %"compiler/lower:lowering", ptr %l1, i32 0, i32 13
  %t28 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3atryCtx_3e(ptr %v0, ptr %t26)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t28, ptr %l13
  br label %bb6
bb6:
  %t29 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l13
  %t30 = getelementptr %"compiler/lower:lowering", ptr %l1, i32 0, i32 13
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t29, ptr %t30
  %t31 = getelementptr %"compiler/lower:lowering", ptr %l1, i32 0, i32 14
  %t33 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3acollectCtx_3e(ptr %v0, ptr %t31)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t33, ptr %l15
  br label %bb7
bb7:
  %t34 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l15
  %t35 = getelementptr %"compiler/lower:lowering", ptr %l1, i32 0, i32 14
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t34, ptr %t35
  %t36 = getelementptr %"compiler/lower:lowering", ptr %l1, i32 0, i32 15
  %t38 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3apl_3e(ptr %v0, ptr %t36)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t38, ptr %l17
  br label %bb8
bb8:
  %t39 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l17
  %t40 = getelementptr %"compiler/lower:lowering", ptr %l1, i32 0, i32 15
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t39, ptr %t40
  %t41 = getelementptr %"compiler/lower:lowering", ptr %l1, i32 0, i32 16
  %t43 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3atryCtx_3e(ptr %v0, ptr %t41)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t43, ptr %l19
  br label %bb9
bb9:
  %t44 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l19
  %t45 = getelementptr %"compiler/lower:lowering", ptr %l1, i32 0, i32 16
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t44, ptr %t45
  %t46 = getelementptr %"compiler/lower:lowering", ptr %l1, i32 0, i32 17
  %t48 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t46)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t48, ptr %l21
  br label %bb10
bb10:
  %t49 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l21
  %t50 = getelementptr %"compiler/lower:lowering", ptr %l1, i32 0, i32 17
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t49, ptr %t50
  %t51 = getelementptr %"compiler/lower:lowering", ptr %l1, i32 0, i32 24
  call void @olang_2eHelperKind_2eCopy_2ecompiler_2ftyped_3aPlan(ptr %t52, ptr %v0, ptr %t51)
  call void @llvm.memmove.p0.p0.i64(ptr %l23, ptr %t52, i64 176, i1 false)
  br label %bb11
bb11:
  %t54 = getelementptr %"compiler/lower:lowering", ptr %l1, i32 0, i32 24
  call void @llvm.memmove.p0.p0.i64(ptr %t54, ptr %l23, i64 176, i1 false)
  %t55 = getelementptr %"compiler/lower:lowering", ptr %l1, i32 0, i32 26
  %t57 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fmir_3aLocalId_3e(ptr %v0, ptr %t55)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t57, ptr %l25
  br label %bb12
bb12:
  %t58 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l25
  %t59 = getelementptr %"compiler/lower:lowering", ptr %l1, i32 0, i32 26
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t58, ptr %t59
  %t60 = getelementptr %"compiler/lower:lowering", ptr %l1, i32 0, i32 29
  %t62 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %v0, ptr %t60)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t62, ptr %l27
  br label %bb13
bb13:
  %t63 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l27
  %t64 = getelementptr %"compiler/lower:lowering", ptr %l1, i32 0, i32 29
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t63, ptr %t64
  %t65 = getelementptr %"compiler/lower:lowering", ptr %l1, i32 0, i32 30
  %t67 = call %"compiler/typed:DropHolding" @olang_2eHelperKind_2eCopy_2ecompiler_2ftyped_3aDropHolding(ptr %v0, ptr %t65)
  store %"compiler/typed:DropHolding" %t67, ptr %l29
  br label %bb14
bb14:
  %t68 = load %"compiler/typed:DropHolding", ptr %l29
  %t69 = getelementptr %"compiler/lower:lowering", ptr %l1, i32 0, i32 30
  store %"compiler/typed:DropHolding" %t68, ptr %t69
  %t70 = getelementptr %"compiler/lower:lowering", ptr %l1, i32 0, i32 33
  %t72 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %v0, ptr %t70)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t72, ptr %l31
  br label %bb15
bb15:
  %t73 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l31
  %t74 = getelementptr %"compiler/lower:lowering", ptr %l1, i32 0, i32 33
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t73, ptr %t74
  %t75 = getelementptr %"compiler/lower:lowering", ptr %l1, i32 0, i32 34
  %t77 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %v0, ptr %t75)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t77, ptr %l33
  br label %bb16
bb16:
  %t78 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l33
  %t79 = getelementptr %"compiler/lower:lowering", ptr %l1, i32 0, i32 34
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t78, ptr %t79
  %t80 = getelementptr %"compiler/lower:lowering", ptr %l1, i32 0, i32 35
  %t82 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %v0, ptr %t80)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t82, ptr %l35
  br label %bb17
bb17:
  %t83 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l35
  %t84 = getelementptr %"compiler/lower:lowering", ptr %l1, i32 0, i32 35
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t83, ptr %t84
  %t85 = getelementptr %"compiler/lower:lowering", ptr %l1, i32 0, i32 36
  %t87 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %v0, ptr %t85)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t87, ptr %l37
  br label %bb18
bb18:
  %t88 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l37
  %t89 = getelementptr %"compiler/lower:lowering", ptr %l1, i32 0, i32 36
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t88, ptr %t89
  %t90 = getelementptr %"compiler/lower:lowering", ptr %l1, i32 0, i32 38
  %t92 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %v0, ptr %t90)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t92, ptr %l39
  br label %bb19
bb19:
  %t93 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l39
  %t94 = getelementptr %"compiler/lower:lowering", ptr %l1, i32 0, i32 38
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t93, ptr %t94
  %t95 = getelementptr %"compiler/lower:lowering", ptr %l1, i32 0, i32 39
  %t97 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %v0, ptr %t95)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t97, ptr %l41
  br label %bb20
bb20:
  %t98 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l41
  %t99 = getelementptr %"compiler/lower:lowering", ptr %l1, i32 0, i32 39
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t98, ptr %t99
  %t100 = getelementptr %"compiler/lower:lowering", ptr %l1, i32 0, i32 40
  %t102 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %v0, ptr %t100)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t102, ptr %l43
  br label %bb21
bb21:
  %t103 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l43
  %t104 = getelementptr %"compiler/lower:lowering", ptr %l1, i32 0, i32 40
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t103, ptr %t104
  %t105 = getelementptr %"compiler/lower:lowering", ptr %l1, i32 0, i32 42
  %t107 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t105)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t107, ptr %l45
  br label %bb22
bb22:
  %t108 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l45
  %t109 = getelementptr %"compiler/lower:lowering", ptr %l1, i32 0, i32 42
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t108, ptr %t109
  %t110 = getelementptr %"compiler/lower:lowering", ptr %l1, i32 0, i32 43
  %t112 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %t110)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t112, ptr %l47
  br label %bb23
bb23:
  %t113 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l47
  %t114 = getelementptr %"compiler/lower:lowering", ptr %l1, i32 0, i32 43
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t113, ptr %t114
  %t115 = getelementptr %"compiler/lower:lowering", ptr %l1, i32 0, i32 44
  %t117 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %v0, ptr %t115)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t117, ptr %l49
  br label %bb24
bb24:
  %t118 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l49
  %t119 = getelementptr %"compiler/lower:lowering", ptr %l1, i32 0, i32 44
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t118, ptr %t119
  %t120 = getelementptr %"compiler/lower:lowering", ptr %l1, i32 0, i32 46
  %t122 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %v0, ptr %t120)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t122, ptr %l51
  br label %bb25
bb25:
  %t123 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l51
  %t124 = getelementptr %"compiler/lower:lowering", ptr %l1, i32 0, i32 46
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t123, ptr %t124
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l1, i64 2400, i1 false)
  br label %ret
ret:
  ret void
}

define linkonce_odr void @olang_2eHelperKind_2eCopy_2ecompiler_2ftyped_3aPlan(ptr %out, ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"compiler/typed:Plan"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  call void @llvm.memmove.p0.p0.i64(ptr %l1, ptr %a0, i64 176, i1 false)
  %t2 = getelementptr %"compiler/typed:Plan", ptr %l1, i32 0, i32 9
  %t4 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScope_3e(ptr %v0, ptr %t2)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t4, ptr %l3
  br label %bb1
bb1:
  %t5 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  %t6 = getelementptr %"compiler/typed:Plan", ptr %l1, i32 0, i32 9
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %t6
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l1, i64 176, i1 false)
  br label %ret
ret:
  ret void
}

define linkonce_odr void @olang_2eHelperKind_2eCopy_2ecompiler_2fmir_3aFn(ptr %out, ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"compiler/mir:Fn"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l9 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l11 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l13 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l15 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l17 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l19 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l21 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l23 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l25 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l27 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l29 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l31 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l33 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l35 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l37 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l39 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l41 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l43 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l45 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l47 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  call void @llvm.memmove.p0.p0.i64(ptr %l1, ptr %a0, i64 800, i1 false)
  %t2 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 4
  %t4 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e(ptr %v0, ptr %t2)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t4, ptr %l3
  br label %bb1
bb1:
  %t5 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  %t6 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 4
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %t6
  %t7 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 5
  %t9 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e(ptr %v0, ptr %t7)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %l5
  br label %bb2
bb2:
  %t10 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l5
  %t11 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 5
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t10, ptr %t11
  %t12 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 6
  %t14 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aVarKind_3e(ptr %v0, ptr %t12)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t14, ptr %l7
  br label %bb3
bb3:
  %t15 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l7
  %t16 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 6
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t15, ptr %t16
  %t17 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 7
  %t19 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %t17)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t19, ptr %l9
  br label %bb4
bb4:
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l9
  %t21 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 7
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %t21
  %t22 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 8
  %t24 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeInfo_3e(ptr %v0, ptr %t22)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t24, ptr %l11
  br label %bb5
bb5:
  %t25 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l11
  %t26 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 8
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t25, ptr %t26
  %t27 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 9
  %t29 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e(ptr %v0, ptr %t27)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t29, ptr %l13
  br label %bb6
bb6:
  %t30 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l13
  %t31 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 9
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t30, ptr %t31
  %t32 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 10
  %t34 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aProj_3e(ptr %v0, ptr %t32)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t34, ptr %l15
  br label %bb7
bb7:
  %t35 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l15
  %t36 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 10
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t35, ptr %t36
  %t37 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 11
  %t39 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e(ptr %v0, ptr %t37)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t39, ptr %l17
  br label %bb8
bb8:
  %t40 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l17
  %t41 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 11
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t40, ptr %t41
  %t42 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 12
  %t44 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeRef_3e(ptr %v0, ptr %t42)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t44, ptr %l19
  br label %bb9
bb9:
  %t45 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l19
  %t46 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 12
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t45, ptr %t46
  %t47 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 13
  %t49 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLvalue_3e(ptr %v0, ptr %t47)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t49, ptr %l21
  br label %bb10
bb10:
  %t50 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l21
  %t51 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 13
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t50, ptr %t51
  %t52 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 14
  %t54 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCall_3e(ptr %v0, ptr %t52)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t54, ptr %l23
  br label %bb11
bb11:
  %t55 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l23
  %t56 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 14
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t55, ptr %t56
  %t57 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 15
  %t59 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCase_3e(ptr %v0, ptr %t57)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t59, ptr %l25
  br label %bb12
bb12:
  %t60 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l25
  %t61 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 15
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t60, ptr %t61
  %t62 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 16
  %t64 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aTask_3e(ptr %v0, ptr %t62)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t64, ptr %l27
  br label %bb13
bb13:
  %t65 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l27
  %t66 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 16
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t65, ptr %t66
  %t67 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 17
  %t69 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aTaskClause_3e(ptr %v0, ptr %t67)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t69, ptr %l29
  br label %bb14
bb14:
  %t70 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l29
  %t71 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 17
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t70, ptr %t71
  %t72 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 18
  %t74 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aItem_3e(ptr %v0, ptr %t72)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t74, ptr %l31
  br label %bb15
bb15:
  %t75 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l31
  %t76 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 18
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t75, ptr %t76
  %t77 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 19
  %t79 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aConstNode_3e(ptr %v0, ptr %t77)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t79, ptr %l33
  br label %bb16
bb16:
  %t80 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l33
  %t81 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 19
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t80, ptr %t81
  %t82 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 20
  %t84 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI32_3e(ptr %v0, ptr %t82)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t84, ptr %l35
  br label %bb17
bb17:
  %t85 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l35
  %t86 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 20
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t85, ptr %t86
  %t87 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 21
  %t89 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cU8_3e(ptr %v0, ptr %t87)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t89, ptr %l37
  br label %bb18
bb18:
  %t90 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l37
  %t91 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 21
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t90, ptr %t91
  %t92 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 22
  %t94 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBlockId_3e(ptr %v0, ptr %t92)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t94, ptr %l39
  br label %bb19
bb19:
  %t95 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l39
  %t96 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 22
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t95, ptr %t96
  %t97 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 23
  %t99 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI32_3e(ptr %v0, ptr %t97)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t99, ptr %l41
  br label %bb20
bb20:
  %t100 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l41
  %t101 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 23
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t100, ptr %t101
  %t102 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 24
  %t104 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, ptr %t102)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t104, ptr %l43
  br label %bb21
bb21:
  %t105 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l43
  %t106 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 24
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t105, ptr %t106
  %t107 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 27
  %t109 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI32_3e(ptr %v0, ptr %t107)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t109, ptr %l45
  br label %bb22
bb22:
  %t110 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l45
  %t111 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 27
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t110, ptr %t111
  %t112 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 28
  %t114 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t112)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t114, ptr %l47
  br label %bb23
bb23:
  %t115 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l47
  %t116 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 28
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t115, ptr %t116
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l1, i64 800, i1 false)
  br label %ret
ret:
  ret void
}

declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
@.d2 = private constant <{ i64, [43 x i8] }> <{ i64 0, [43 x i8] c"an array literal of a type that is no array" }>, align 8
@.d3 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"unhandled error" }>, align 8
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
define linkonce_odr %"compiler/lower:pl" @olang_2eHelperKind_2eCopy_2ecompiler_2flower_3apl(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"compiler/lower:pl"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %rv = alloca %"compiler/lower:pl"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"compiler/lower:pl", ptr %a0
  store %"compiler/lower:pl" %t2, ptr %l1
  %t3 = getelementptr %"compiler/lower:pl", ptr %l1, i32 0, i32 1
  %t5 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aProj_3e(ptr %v0, ptr %t3)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %l3
  br label %bb1
bb1:
  %t6 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  %t7 = getelementptr %"compiler/lower:pl", ptr %l1, i32 0, i32 1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t6, ptr %t7
  %t8 = load %"compiler/lower:pl", ptr %l1
  store %"compiler/lower:pl" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/lower:pl", ptr %rv
  ret %"compiler/lower:pl" %rr
}

define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
define linkonce_odr %"compiler/free:leaf" @olang_2eHelperKind_2eCopy_2ecompiler_2ffree_3aleaf(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"compiler/free:leaf"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"compiler/free:leaf"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"compiler/free:leaf", ptr %a0
  store %"compiler/free:leaf" %t2, ptr %l1
  %t3 = getelementptr %"compiler/free:leaf", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 8
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"compiler/free:leaf", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"compiler/free:leaf", ptr %l1
  store %"compiler/free:leaf" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/free:leaf", ptr %rv
  ret %"compiler/free:leaf" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBlockId_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 4
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 4
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

@.d4 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c": local L" }>, align 8
declare i64 @__olang_fmt_i64(ptr, i64)
@.d5 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c" moved at its last use" }>, align 8
@__olang_empty_array = external constant [16 x i64]
declare void @__olang_bang_failed_plain(ptr) cold noreturn
@.d6 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"holds views" }>, align 8
@.d7 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"copies" }>, align 8
@.d8 = private constant <{ i64, [49 x i8] }> <{ i64 0, [49 x i8] c"copies (lent to a body that may change its parts)" }>, align 8
@.d9 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c": a temporary " }>, align 8
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
define available_externally void @__olang_dtor_head(ptr %node, ptr %at) alwaysinline {
entry:
  %has = icmp ne ptr %node, null
  br i1 %has, label %fix, label %done
fix:
  %ppp = getelementptr %olang.dtornode, ptr %node, i32 0, i32 3
  store ptr %at, ptr %ppp
  br label %done
done:
  ret void
}
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3alevel_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 12
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 12
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlock_26_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 8
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 4
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 4
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3aloopCtx_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = call { i64, ptr } @olang_2eHelperKind_2eCopy_2eArray_3ccompiler_2flower_3aloopCtx_3e(ptr %v0, { i64, ptr } %t4)
  store { i64, ptr } %t6, ptr %l3
  br label %bb1
bb1:
  %t7 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t8 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t7, ptr %t8, !tbaa !27
  %t9 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3atryCtx_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = call { i64, ptr } @olang_2eHelperKind_2eCopy_2eArray_3ccompiler_2flower_3atryCtx_3e(ptr %v0, { i64, ptr } %t4)
  store { i64, ptr } %t6, ptr %l3
  br label %bb1
bb1:
  %t7 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t8 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t7, ptr %t8, !tbaa !27
  %t9 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3acollectCtx_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 40
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 40
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3apl_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = call { i64, ptr } @olang_2eHelperKind_2eCopy_2eArray_3ccompiler_2flower_3apl_3e(ptr %v0, { i64, ptr } %t4)
  store { i64, ptr } %t6, ptr %l3
  br label %bb1
bb1:
  %t7 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t8 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t7, ptr %t8, !tbaa !27
  %t9 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fmir_3aLocalId_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %a0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 16
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 1
  %t21 = load { i64, ptr }, ptr %t20, !tbaa !27
  store { i64, ptr } %t21, ptr %l5, !tbaa !27
  %t22 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t22, 0
  store i64 %t23, ptr %l6, !tbaa !24
  %t24 = load i64, ptr %l6, !tbaa !24
  %t25 = mul i64 %t24, 8
  %t26 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t25)
  %t27 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  store { i64, ptr } %t28, ptr %l7, !tbaa !27
  %t29 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !27
  %t31 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = load i64, ptr %l6, !tbaa !24
  %t34 = mul i64 %t33, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t30, ptr %t32, i64 %t34, i1 false)
  %t35 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t36 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 1
  store { i64, ptr } %t35, ptr %t36, !tbaa !27
  %t37 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 2
  %t38 = load { i64, ptr }, ptr %t37, !tbaa !27
  store { i64, ptr } %t38, ptr %l8, !tbaa !27
  %t39 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t40 = extractvalue { i64, ptr } %t39, 0
  store i64 %t40, ptr %l9, !tbaa !24
  %t41 = load i64, ptr %l9, !tbaa !24
  %t42 = mul i64 %t41, 8
  %t43 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t42)
  %t44 = insertvalue { i64, ptr } undef, i64 %t41, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t43, 1
  store { i64, ptr } %t45, ptr %l10, !tbaa !27
  %t46 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !27
  %t48 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !27
  %t50 = load i64, ptr %l9, !tbaa !24
  %t51 = mul i64 %t50, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t47, ptr %t49, i64 %t51, i1 false)
  %t52 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t53 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 2
  store { i64, ptr } %t52, ptr %t53, !tbaa !27
  %t54 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t54, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %a0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 16
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 1
  %t21 = load { i64, ptr }, ptr %t20, !tbaa !27
  store { i64, ptr } %t21, ptr %l5, !tbaa !27
  %t22 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t22, 0
  store i64 %t23, ptr %l6, !tbaa !24
  %t24 = load i64, ptr %l6, !tbaa !24
  %t25 = mul i64 %t24, 8
  %t26 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t25)
  %t27 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  store { i64, ptr } %t28, ptr %l7, !tbaa !27
  %t29 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !27
  %t31 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = load i64, ptr %l6, !tbaa !24
  %t34 = mul i64 %t33, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t30, ptr %t32, i64 %t34, i1 false)
  %t35 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t36 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 1
  store { i64, ptr } %t35, ptr %t36, !tbaa !27
  %t37 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 2
  %t38 = load { i64, ptr }, ptr %t37, !tbaa !27
  store { i64, ptr } %t38, ptr %l8, !tbaa !27
  %t39 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t40 = extractvalue { i64, ptr } %t39, 0
  store i64 %t40, ptr %l9, !tbaa !24
  %t41 = load i64, ptr %l9, !tbaa !24
  %t42 = mul i64 %t41, 8
  %t43 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t42)
  %t44 = insertvalue { i64, ptr } undef, i64 %t41, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t43, 1
  store { i64, ptr } %t45, ptr %l10, !tbaa !27
  %t46 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !27
  %t48 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !27
  %t50 = load i64, ptr %l9, !tbaa !24
  %t51 = mul i64 %t50, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t47, ptr %t49, i64 %t51, i1 false)
  %t52 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t53 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 2
  store { i64, ptr } %t52, ptr %t53, !tbaa !27
  %t54 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t54, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

define linkonce_odr %"compiler/typed:DropHolding" @olang_2eHelperKind_2eCopy_2ecompiler_2ftyped_3aDropHolding(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"compiler/typed:DropHolding"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %rv = alloca %"compiler/typed:DropHolding"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"compiler/typed:DropHolding", ptr %a0
  store %"compiler/typed:DropHolding" %t2, ptr %l1
  %t3 = getelementptr %"compiler/typed:DropHolding", ptr %l1, i32 0, i32 0
  %t5 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %t3)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %l3
  br label %bb1
bb1:
  %t6 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  %t7 = getelementptr %"compiler/typed:DropHolding", ptr %l1, i32 0, i32 0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t6, ptr %t7
  %t8 = getelementptr %"compiler/typed:DropHolding", ptr %l1, i32 0, i32 1
  %t10 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %t8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t10, ptr %l5
  br label %bb2
bb2:
  %t11 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l5
  %t12 = getelementptr %"compiler/typed:DropHolding", ptr %l1, i32 0, i32 1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t11, ptr %t12
  %t13 = getelementptr %"compiler/typed:DropHolding", ptr %l1, i32 0, i32 2
  %t15 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e(ptr %v0, ptr %t13)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t15, ptr %l7
  br label %bb3
bb3:
  %t16 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l7
  %t17 = getelementptr %"compiler/typed:DropHolding", ptr %l1, i32 0, i32 2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t16, ptr %t17
  %t18 = load %"compiler/typed:DropHolding", ptr %l1
  store %"compiler/typed:DropHolding" %t18, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:DropHolding", ptr %rv
  ret %"compiler/typed:DropHolding" %rr
}

define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %a0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 16
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 1
  %t21 = load { i64, ptr }, ptr %t20, !tbaa !27
  store { i64, ptr } %t21, ptr %l5, !tbaa !27
  %t22 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t22, 0
  store i64 %t23, ptr %l6, !tbaa !24
  %t24 = load i64, ptr %l6, !tbaa !24
  %t25 = mul i64 %t24, 8
  %t26 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t25)
  %t27 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  store { i64, ptr } %t28, ptr %l7, !tbaa !27
  %t29 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !27
  %t31 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = load i64, ptr %l6, !tbaa !24
  %t34 = mul i64 %t33, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t30, ptr %t32, i64 %t34, i1 false)
  %t35 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t36 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 1
  store { i64, ptr } %t35, ptr %t36, !tbaa !27
  %t37 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 2
  %t38 = load { i64, ptr }, ptr %t37, !tbaa !27
  store { i64, ptr } %t38, ptr %l8, !tbaa !27
  %t39 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t40 = extractvalue { i64, ptr } %t39, 0
  store i64 %t40, ptr %l9, !tbaa !24
  %t41 = load i64, ptr %l9, !tbaa !24
  %t42 = mul i64 %t41, 8
  %t43 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t42)
  %t44 = insertvalue { i64, ptr } undef, i64 %t41, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t43, 1
  store { i64, ptr } %t45, ptr %l10, !tbaa !27
  %t46 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !27
  %t48 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !27
  %t50 = load i64, ptr %l9, !tbaa !24
  %t51 = mul i64 %t50, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t47, ptr %t49, i64 %t51, i1 false)
  %t52 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t53 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 2
  store { i64, ptr } %t52, ptr %t53, !tbaa !27
  %t54 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t54, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 8
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 8
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScope_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 16
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 4
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 4
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aVarKind_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 16
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 40
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 40
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeInfo_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 24
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 24
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = call { i64, ptr } @olang_2eHelperKind_2eCopy_2eArray_3ccompiler_2fmir_3aBasicBlock_3e(ptr %v0, { i64, ptr } %t4)
  store { i64, ptr } %t6, ptr %l3
  br label %bb1
bb1:
  %t7 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t8 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t7, ptr %t8, !tbaa !27
  %t9 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aProj_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 16
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 40
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 40
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeRef_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 16
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLvalue_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 32
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 32
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCall_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 128
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 128
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCase_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 16
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aTask_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 120
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 120
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aTaskClause_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 56
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 56
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aItem_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 16
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aConstNode_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 16
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI32_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 4
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 4
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cU8_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 1
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 16
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr { i64, ptr } @olang_2eHelperKind_2eCopy_2eArray_3ccompiler_2flower_3aloopCtx_3e(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l6 = alloca %"compiler/lower:loopCtx"
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t2 = extractvalue { i64, ptr } %t1, 0
  store i64 %t2, ptr %l1, !tbaa !24
  %t3 = load i64, ptr %l1, !tbaa !24
  %t4 = mul i64 %t3, 88
  %t5 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t4)
  %t6 = insertvalue { i64, ptr } undef, i64 %t3, 0
  %t7 = insertvalue { i64, ptr } %t6, ptr %t5, 1
  store { i64, ptr } %t7, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  %t8 = load i64, ptr %l3, !tbaa !24
  %t9 = load i64, ptr %l1, !tbaa !24
  %t10 = icmp slt i64 %t8, %t9
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = load i64, ptr %l3, !tbaa !24
  %t13 = getelementptr { i64, ptr }, ptr %l0, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !27
  %t15 = getelementptr %"compiler/lower:loopCtx", ptr %t14, i64 %t12
  %t17 = call %"compiler/lower:loopCtx" @olang_2eHelperKind_2eCopy_2ecompiler_2flower_3aloopCtx(ptr %v0, ptr %t15)
  store %"compiler/lower:loopCtx" %t17, ptr %l6
  br label %bb4
bb3:
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t18, ptr %rv
  br label %ret
bb4:
  %t19 = load %"compiler/lower:loopCtx", ptr %l6
  %t20 = load i64, ptr %l3, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr %"compiler/lower:loopCtx", ptr %t22, i64 %t20
  store %"compiler/lower:loopCtx" %t19, ptr %t23
  %t24 = load i64, ptr %l3, !tbaa !24
  %t25 = add i64 %t24, 1
  store i64 %t25, ptr %l3, !tbaa !24
  br label %bb1
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define linkonce_odr { i64, ptr } @olang_2eHelperKind_2eCopy_2eArray_3ccompiler_2flower_3atryCtx_3e(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l6 = alloca %"compiler/lower:tryCtx"
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t2 = extractvalue { i64, ptr } %t1, 0
  store i64 %t2, ptr %l1, !tbaa !24
  %t3 = load i64, ptr %l1, !tbaa !24
  %t4 = mul i64 %t3, 64
  %t5 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t4)
  %t6 = insertvalue { i64, ptr } undef, i64 %t3, 0
  %t7 = insertvalue { i64, ptr } %t6, ptr %t5, 1
  store { i64, ptr } %t7, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  %t8 = load i64, ptr %l3, !tbaa !24
  %t9 = load i64, ptr %l1, !tbaa !24
  %t10 = icmp slt i64 %t8, %t9
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = load i64, ptr %l3, !tbaa !24
  %t13 = getelementptr { i64, ptr }, ptr %l0, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !27
  %t15 = getelementptr %"compiler/lower:tryCtx", ptr %t14, i64 %t12
  %t17 = call %"compiler/lower:tryCtx" @olang_2eHelperKind_2eCopy_2ecompiler_2flower_3atryCtx(ptr %v0, ptr %t15)
  store %"compiler/lower:tryCtx" %t17, ptr %l6
  br label %bb4
bb3:
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t18, ptr %rv
  br label %ret
bb4:
  %t19 = load %"compiler/lower:tryCtx", ptr %l6
  %t20 = load i64, ptr %l3, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr %"compiler/lower:tryCtx", ptr %t22, i64 %t20
  store %"compiler/lower:tryCtx" %t19, ptr %t23
  %t24 = load i64, ptr %l3, !tbaa !24
  %t25 = add i64 %t24, 1
  store i64 %t25, ptr %l3, !tbaa !24
  br label %bb1
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define linkonce_odr { i64, ptr } @olang_2eHelperKind_2eCopy_2eArray_3ccompiler_2flower_3apl_3e(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l6 = alloca %"compiler/lower:pl"
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t2 = extractvalue { i64, ptr } %t1, 0
  store i64 %t2, ptr %l1, !tbaa !24
  %t3 = load i64, ptr %l1, !tbaa !24
  %t4 = mul i64 %t3, 72
  %t5 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t4)
  %t6 = insertvalue { i64, ptr } undef, i64 %t3, 0
  %t7 = insertvalue { i64, ptr } %t6, ptr %t5, 1
  store { i64, ptr } %t7, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  %t8 = load i64, ptr %l3, !tbaa !24
  %t9 = load i64, ptr %l1, !tbaa !24
  %t10 = icmp slt i64 %t8, %t9
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = load i64, ptr %l3, !tbaa !24
  %t13 = getelementptr { i64, ptr }, ptr %l0, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !27
  %t15 = getelementptr %"compiler/lower:pl", ptr %t14, i64 %t12
  %t17 = call %"compiler/lower:pl" @olang_2eHelperKind_2eCopy_2ecompiler_2flower_3apl(ptr %v0, ptr %t15)
  store %"compiler/lower:pl" %t17, ptr %l6
  br label %bb4
bb3:
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t18, ptr %rv
  br label %ret
bb4:
  %t19 = load %"compiler/lower:pl", ptr %l6
  %t20 = load i64, ptr %l3, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr %"compiler/lower:pl", ptr %t22, i64 %t20
  store %"compiler/lower:pl" %t19, ptr %t23
  %t24 = load i64, ptr %l3, !tbaa !24
  %t25 = add i64 %t24, 1
  store i64 %t25, ptr %l3, !tbaa !24
  br label %bb1
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 4
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 4
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = call { i64, ptr } @olang_2eHelperKind_2eCopy_2eArray_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e(ptr %v0, { i64, ptr } %t4)
  store { i64, ptr } %t6, ptr %l3
  br label %bb1
bb1:
  %t7 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t8 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t7, ptr %t8, !tbaa !27
  %t9 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr { i64, ptr } @olang_2eHelperKind_2eCopy_2eArray_3ccompiler_2fmir_3aBasicBlock_3e(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l6 = alloca %"compiler/mir:BasicBlock"
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t2 = extractvalue { i64, ptr } %t1, 0
  store i64 %t2, ptr %l1, !tbaa !24
  %t3 = load i64, ptr %l1, !tbaa !24
  %t4 = mul i64 %t3, 104
  %t5 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t4)
  %t6 = insertvalue { i64, ptr } undef, i64 %t3, 0
  %t7 = insertvalue { i64, ptr } %t6, ptr %t5, 1
  store { i64, ptr } %t7, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  %t8 = load i64, ptr %l3, !tbaa !24
  %t9 = load i64, ptr %l1, !tbaa !24
  %t10 = icmp slt i64 %t8, %t9
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = load i64, ptr %l3, !tbaa !24
  %t13 = getelementptr { i64, ptr }, ptr %l0, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !27
  %t15 = getelementptr %"compiler/mir:BasicBlock", ptr %t14, i64 %t12
  %t17 = call %"compiler/mir:BasicBlock" @olang_2eHelperKind_2eCopy_2ecompiler_2fmir_3aBasicBlock(ptr %v0, ptr %t15)
  store %"compiler/mir:BasicBlock" %t17, ptr %l6
  br label %bb4
bb3:
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t18, ptr %rv
  br label %ret
bb4:
  %t19 = load %"compiler/mir:BasicBlock", ptr %l6
  %t20 = load i64, ptr %l3, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr %"compiler/mir:BasicBlock", ptr %t22, i64 %t20
  store %"compiler/mir:BasicBlock" %t19, ptr %t23
  %t24 = load i64, ptr %l3, !tbaa !24
  %t25 = add i64 %t24, 1
  store i64 %t25, ptr %l3, !tbaa !24
  br label %bb1
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define linkonce_odr %"compiler/lower:loopCtx" @olang_2eHelperKind_2eCopy_2ecompiler_2flower_3aloopCtx(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"compiler/lower:loopCtx"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %rv = alloca %"compiler/lower:loopCtx"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"compiler/lower:loopCtx", ptr %a0
  store %"compiler/lower:loopCtx" %t2, ptr %l1
  %t3 = getelementptr %"compiler/lower:loopCtx", ptr %l1, i32 0, i32 3
  %t5 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBlockId_3e(ptr %v0, ptr %t3)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %l3
  br label %bb1
bb1:
  %t6 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  %t7 = getelementptr %"compiler/lower:loopCtx", ptr %l1, i32 0, i32 3
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t6, ptr %t7
  %t8 = getelementptr %"compiler/lower:loopCtx", ptr %l1, i32 0, i32 4
  %t10 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBlockId_3e(ptr %v0, ptr %t8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t10, ptr %l5
  br label %bb2
bb2:
  %t11 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l5
  %t12 = getelementptr %"compiler/lower:loopCtx", ptr %l1, i32 0, i32 4
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t11, ptr %t12
  %t13 = load %"compiler/lower:loopCtx", ptr %l1
  store %"compiler/lower:loopCtx" %t13, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/lower:loopCtx", ptr %rv
  ret %"compiler/lower:loopCtx" %rr
}

define linkonce_odr %"compiler/lower:tryCtx" @olang_2eHelperKind_2eCopy_2ecompiler_2flower_3atryCtx(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"compiler/lower:tryCtx"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %rv = alloca %"compiler/lower:tryCtx"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"compiler/lower:tryCtx", ptr %a0
  store %"compiler/lower:tryCtx" %t2, ptr %l1
  %t3 = getelementptr %"compiler/lower:tryCtx", ptr %l1, i32 0, i32 4
  %t5 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBlockId_3e(ptr %v0, ptr %t3)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %l3
  br label %bb1
bb1:
  %t6 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  %t7 = getelementptr %"compiler/lower:tryCtx", ptr %l1, i32 0, i32 4
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t6, ptr %t7
  %t8 = load %"compiler/lower:tryCtx", ptr %l1
  store %"compiler/lower:tryCtx" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/lower:tryCtx", ptr %rv
  ret %"compiler/lower:tryCtx" %rr
}

define linkonce_odr { i64, ptr } @olang_2eHelperKind_2eCopy_2eArray_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t2 = extractvalue { i64, ptr } %t1, 0
  store i64 %t2, ptr %l1, !tbaa !24
  %t3 = load i64, ptr %l1, !tbaa !24
  %t4 = mul i64 %t3, 32
  %t5 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t4)
  %t6 = insertvalue { i64, ptr } undef, i64 %t3, 0
  %t7 = insertvalue { i64, ptr } %t6, ptr %t5, 1
  store { i64, ptr } %t7, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  %t8 = load i64, ptr %l3, !tbaa !24
  %t9 = load i64, ptr %l1, !tbaa !24
  %t10 = icmp slt i64 %t8, %t9
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = load i64, ptr %l3, !tbaa !24
  %t13 = getelementptr { i64, ptr }, ptr %l0, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !27
  %t15 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t14, i64 %t12
  %t17 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %t15)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t17, ptr %l6
  br label %bb4
bb3:
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t18, ptr %rv
  br label %ret
bb4:
  %t19 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l6
  %t20 = load i64, ptr %l3, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t22, i64 %t20
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t19, ptr %t23
  %t24 = load i64, ptr %l3, !tbaa !24
  %t25 = add i64 %t24, 1
  store i64 %t25, ptr %l3, !tbaa !24
  br label %bb1
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define linkonce_odr %"compiler/mir:BasicBlock" @olang_2eHelperKind_2eCopy_2ecompiler_2fmir_3aBasicBlock(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"compiler/mir:BasicBlock"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %rv = alloca %"compiler/mir:BasicBlock"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"compiler/mir:BasicBlock", ptr %a0
  store %"compiler/mir:BasicBlock" %t2, ptr %l1
  %t3 = getelementptr %"compiler/mir:BasicBlock", ptr %l1, i32 0, i32 0
  %t5 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aStmt_3e(ptr %v0, ptr %t3)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %l3
  br label %bb1
bb1:
  %t6 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  %t7 = getelementptr %"compiler/mir:BasicBlock", ptr %l1, i32 0, i32 0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t6, ptr %t7
  %t8 = load %"compiler/mir:BasicBlock", ptr %l1
  store %"compiler/mir:BasicBlock" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/mir:BasicBlock", ptr %rv
  ret %"compiler/mir:BasicBlock" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aStmt_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 176
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 176
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

@olang_loc_76ec7e11cc604d77_65dfbe8f138a0f63 = external constant [0 x i8]
@olang_loc_b33a0661a011e178_dcd63aec50757664 = external constant [0 x i8]
@olang_loc_ad272ff31dc381ae_4a185251f7060aca = external constant [0 x i8]
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_daa9f23a83841987_24921124063ad36b = external constant [0 x i8]
declare void @compiler_2fmir_3aFn_2ector(ptr %out, ptr %v0, { i64, [2 x i64] } %a0, i32 %a1, i64 %a2, %"compiler/source:Span" %a3)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI32_3e_2eLen_3cI32_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI32_3e_2eAt_3cI32_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI32_3e_2ePush_3cI32_3e(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ePreludeType(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
@G_2ecompiler_2ftypes_2eUnknownT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fmir_2eErrorCode(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i64 %a3)
declare void @compiler_2flower_3alowering_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, ptr %a2, ptr %a3)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlan_3e_2eLen_3ccompiler_2ftyped_3aPlan_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlan_3e_2eAt_3ccompiler_2ftyped_3aPlan_3e(ptr %out, ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_f8b3706059fec8c0_d163f284ba6a3ccc = external constant [0 x i8]
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eFrees(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2erun(ptr %v0, ptr %a0)
declare ptr @compiler_2flower_2ecompiler_2flower_3aLowerer_2eT(ptr %v0, ptr %v1, ptr %a0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2ftyped_2eLocalUses_2eUses(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @compiler_2flower_2ecompiler_2flower_3aLowerer_2efreshRet(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, ptr %a3)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %a0, i32 %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fload_2eErrQualifier(ptr %v0, ptr %v1, { i64, ptr } %a0, i1 %a1)
@olang_loc_fdef55e2919415e3_7c40141ab4e8627 = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %a0)
declare { i32, i1 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eGet_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
declare i1 @compiler_2flower_2ecompiler_2flower_3aLowerer_2ekeepsNothing(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2)
declare i1 @compiler_2flower_2ecompiler_2flower_3aLowerer_2ekeepsParts(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2)
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v0, ptr %a0)
declare { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2ftyped_2eAnyItemNew(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eArgs(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2, { i64, ptr } %a3, %"compiler/source:Span" %a4)
declare { i64, ptr } @compiler_2flower_2ecompiler_2flower_3alowering_2evals(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOwnsParts(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2flower_2ecompiler_2flower_3alowering_2elocal(ptr %v0, ptr %a0, { i64, [4 x i64] } %a1, i32 %a2, %"compiler/source:Span" %a3)
@G_2ecompiler_2fmir_2eI64T = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\06\00\00\00" }>, align 8
declare %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %a0)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @compiler_2flower_2ecompiler_2flower_3alowering_2efixedLen(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %a0, i32 %a1)
declare { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2emadeAt(ptr %v0, ptr %a0, i32 %a1)
declare { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2econstI64(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/mir:Lvalue" @compiler_2fmir_2ecompiler_2fmir_3aFn_2ePlace(ptr %v0, ptr %v1, ptr %a0, { i64, [2 x i64] } %a1, { i64, ptr } %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eBoolT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
declare i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %a0)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %a0, { i64, [8 x i64] } %a1)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2egoto(ptr %v0, ptr %a0, i32 %a1)
declare %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %v0, i64 %a0, i64 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare { i64, ptr } @compiler_2flower_2ecompiler_2flower_3alowering_2ebangNames(ptr %v0, ptr %v1, ptr %a0, i32 %a1, %"compiler/source:Span" %a2)
declare { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ewithPayload(ptr %v0, ptr %a0, { i64, [4 x i64] } %a1, { i64, [4 x i64] } %a2, i32 %a3, %"compiler/source:Span" %a4)
declare { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2etextData(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, %"compiler/source:Span" %a2)
declare { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2escopeRef(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %a0, i64 %a1)
declare { { i64, [7 x i64] }, i32 } @compiler_2flower_2ecompiler_2flower_3alowering_2evalueCallee(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_21e9da82ebd620c7_b6074e807b9f75fb = external constant [0 x i8]
declare i32 @compiler_2fmir_2eCasesOf(ptr %v0, ptr %a0, i32 %a1)
declare { i32, i64 } @compiler_2flower_2ecompiler_2flower_3aLowerer_2efailure(ptr %v0, ptr %a0, i64 %a1)
@G_2ecompiler_2fmir_2eI32T = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\05\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList1(ptr %v0, ptr %a0, i32 %a1)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2eAt_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2eSetAt_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlock_26_3e_2eAt_3ccompiler_2ftyped_3aBlock_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2eblock(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3alevel_3e_2eLen_3ccompiler_2flower_3alevel_3e(ptr %v0, ptr %a0)
declare %"compiler/lower:level" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3alevel_3e_2eAt_3ccompiler_2flower_3alevel_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einnermost(ptr %v0, ptr %a0)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eEmbedded(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_b57cc0c231802eb3_c3a9863fe509851f = external constant [0 x i8]
declare %"compiler/lower:pl" @compiler_2flower_3apl_2ector(ptr %v0, { i64, [2 x i64] } %a0)
declare %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2ewith(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/lower:pl" %a1, { i64, [1 x i64] } %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3atryCtx_3e_2eLen_3ccompiler_2flower_3atryCtx_3e(ptr %v0, ptr %a0)
@olang_loc_b0c77cc00353838c_f9addae603786cc8 = external constant [0 x i8]
declare %"compiler/lower:tryCtx" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3atryCtx_3e_2eAt_3ccompiler_2flower_3atryCtx_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2etoClause(ptr %v0, ptr %a0, i64 %a1, i64 %a2, { i64, [4 x i64] } %a3, i32 %a4)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3atryCtx_3e_2eRef_3ccompiler_2flower_3atryCtx_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_1378acbf535452a2_3a9100f5c9d7e1f6 = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockInfo_3e_2eLen__Hdc799a0fe091f8e84d50200d058b631d(ptr %v0, ptr %a0)
declare %"compiler/typed:BlockInfo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockInfo_3e_2eAt_3ccompiler_2ftyped_3aBlockInfo_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eerrCodeOf(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrValItems(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrCarries(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/mir:Lvalue" @compiler_2flower_2ecompiler_2flower_3alowering_2emk(ptr %v0, ptr %v1, ptr %a0, %"compiler/lower:pl" %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ePayloadOf(ptr %v0, ptr %a0, i32 %a1)
declare { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2etypeIs(ptr %v0, ptr %a0, { i64, [4 x i64] } %a1, i64 %a2, %"compiler/source:Span" %a3)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ePayloadField(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2flower_2ecompiler_2flower_3aLowerer_2ekeepsNoRef(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2econstBool(ptr %v0, ptr %a0, i1 %a1, %"compiler/source:Span" %a2)
declare ptr @compiler_2flower_2eviewCallIn(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_c9ff4911a436500b_5835334d424a3697 = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3aGap_3e_2ePush_3ccompiler_2flower_3aGap_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/lower:Gap" %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2ePush_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_58c3cf8c6fce78d4_23ae1924195b9e70 = external constant [0 x i8]
@olang_loc_3f94e1722b42397a_72ec18aae06ab796 = external constant [0 x i8]
declare %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2flower_2ecompiler_2flower_3alowering_2elendsKeep(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2)
declare i32 @compiler_2flower_2ecompiler_2flower_3aLowerer_2ehelperTy(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i32 @compiler_2fmir_2eHelperType(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare void @compiler_2flower_2ecompiler_2flower_3aLowerer_2eWant(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1)
declare %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2esolid(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/lower:pl" %a1, i32 %a2, %"compiler/source:Span" %a3)
declare i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eisChar(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eisText(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2flower_2ecompiler_2flower_3alowering_2ehasStr(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNullable(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArrayRef(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2erenderMaybeText(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1, { i64, [4 x i64] } %a2, i32 %a3, %"compiler/source:Span" %a4, i32 %a5)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2erenderErr(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1, { i64, [4 x i64] } %a2, i32 %a3, %"compiler/source:Span" %a4)
declare i1 @compiler_2flower_2ecompiler_2flower_3alowering_2escalar(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2erenderAt(ptr %v0, ptr %v1, ptr %a0, %"compiler/lower:pl" %a1, i32 %a2, { i64, [1 x i64] } %a3, %"compiler/source:Span" %a4, i1 %a5)
@olang_loc_fe6f132f471090d8_e27fa787bcbe9484 = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %a0, i32 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_3e_2ector(ptr %v0, i64 %a0)
@olang_loc_e5b6724f2c0e70f4_3544be27bc88d5e0 = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3aFree_2eSoleLeaves(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2eLen_3ccompiler_2ffree_3aleaf_3e(ptr %v0, ptr %a0)
declare %"compiler/free:leaf" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2eAt_3ccompiler_2ffree_3aleaf_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eIsHandle(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_3e_2ePush_3cArray_3cI64_3e_3e(ptr %v0, ptr %a0, { i64, ptr } %a1)
@olang_loc_dc337209e99dc7c1_dc835b0b512a4145 = external constant [0 x i8]
declare %"compiler/lower:loopCtx" @compiler_2flower_3aloopCtx_2ector(ptr %v0, i32 %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3aloopCtx_3e_2ePush_3ccompiler_2flower_3aloopCtx_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/lower:loopCtx" %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3aloopCtx_3e_2eLen_3ccompiler_2flower_3aloopCtx_3e(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3aloopCtx_3e_2eRefMut_3ccompiler_2flower_3aloopCtx_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2eleaveOpen(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBlockId_3e_2eLen_3ccompiler_2fmir_3aBlockId_3e(ptr %v0, ptr %a0)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2epatch(ptr %v0, ptr %v1, ptr %a0, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a1)
declare { i32, %"compiler/lower:loopCtx" } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3aloopCtx_3e_2ePop_3ccompiler_2flower_3aloopCtx_3e(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_5dc48dc64c6b10e3_ed2bb1ae700828ff = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eWordFields(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i64 %a2)
declare { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2efill(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3, i1 %a4, { i64, [1 x i64] } %a5)
declare { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ederefCopy(ptr %v0, ptr %a0, { i64, [4 x i64] } %a1, i32 %a2, i32 %a3, { i64, [1 x i64] } %a4, %"compiler/source:Span" %a5)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRunsCopy(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_c00faf6434efe24b_96f261c8870620df = external constant [0 x i8]
@olang_loc_f71032533cd82c8_29b3308e7cd66624 = external constant [0 x i8]
declare i1 @compiler_2flower_2ecompiler_2flower_3alowering_2ecopiesValue(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_6cc454f6892da6e7_dc94ff52b1800ff3 = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eLen_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0)
declare void @compiler_2ftyped_3aLastUses_2ector(ptr %out, ptr %v0, i64 %a0)
@olang_loc_fb069b64d7548fb8_fd74029d8d87e6e4 = external constant [0 x i8]
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eBlock(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2flower_2ecompiler_2flower_3alowering_2emovable(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2, i64 %a3)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLocate(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2)
declare i1 @compiler_2fmir_2eHasFields(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_f84e287748fb5e0c_a7fab5dda1d7c518 = external constant [0 x i8]
declare { i64, ptr } @compiler_2flower_2ecompiler_2flower_3alowering_2epartsOf(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_3175700f57e01d19_45cf7091add0d985 = external constant [0 x i8]
@olang_loc_579e7356b043c39a_4d305c4fde145a66 = external constant [0 x i8]
@olang_loc_166f6c7f8536ecb_3daea1ccb6433847 = external constant [0 x i8]
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOwnedPart(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclaresCopy(ptr %v0, ptr %a0, i32 %a1)
declare { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ehelperCall(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, i32 %a2, { i64, ptr } %a3, { i64, ptr } %a4, i32 %a5, %"compiler/source:Span" %a6)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePacked(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aProj_3e_2eLen_3ccompiler_2fmir_3aProj_3e(ptr %v0, ptr %a0)
declare { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ecarries(ptr %v0, ptr %a0, { i64, [4 x i64] } %a1, i32 %a2, %"compiler/source:Span" %a3)
declare { i32, { i64, [4 x i64] } } @compiler_2flower_2ecompiler_2flower_3alowering_2epromotedInPlace(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3, i32 %a4)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNeedsDrop(ptr %v0, ptr %a0, i32 %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eAt_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @compiler_2flower_2ecompiler_2flower_3alowering_2equietStmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
@olang_loc_79f527557a79a277_798dff7a83c0d4db = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_2ec5e8672e3e2115_a2b323ecc8460901 = external constant [0 x i8]
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eWritable = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eLen_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0)
declare i1 @compiler_2flower_2ecompiler_2flower_3alowering_2ewritesCover(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReachesWrite(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReachesCode(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2flower_2ecompiler_2flower_3alowering_2equietX(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2flower_2ecompiler_2flower_3alowering_2equietAll(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eisMain(ptr %v0, ptr %a0)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2eleave(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_763e3b2e421df924_4ff52ff107ec1ef8 = external constant [0 x i8]
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2ereadPlace(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, ptr %a3)
@olang_loc_92fd471d43b4bd8a_f49bae282c691e2e = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eviewValue(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_ed0da5981c7956e3_375966c562f70de7 = external constant [0 x i8]
@G_2ecompiler_2ftypes_2eReadOnly = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_3e_2eLen_3cArray_3cI64_3e_3e(ptr %v0, ptr %a0)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_3e_2eAt_3cArray_3cI64_3e_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_b05049138e3c9583_5b10da44a83c4f97 = external constant [0 x i8]
@olang_loc_7978ceed25dd57db_b68e0a2baf6deaf = external constant [0 x i8]
declare i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eSolePlace(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eSoleLocal(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
@olang_loc_6cf042e1e67efefa_11456615317dde16 = external constant [0 x i8]
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v0, ptr %a0)
@olang_loc_16ea37ec2dd8d64f_b36c061d5e238e2b = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2flower_3alevel_3e_2ector(ptr %v0, i64 %a0)
declare { i32, %"compiler/lower:level" } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3alevel_3e_2ePop_3ccompiler_2flower_3alevel_3e(ptr %v0, ptr %a0)
@olang_loc_3ef62952ecee62f3_777b4c56ce2caf3f = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3alevel_3e_2ePush_3ccompiler_2flower_3alevel_3e(ptr %v0, ptr %a0, %"compiler/lower:level" %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlock_26_3e_2eLen_3ccompiler_2ftyped_3aBlock_26_3e(ptr %v0, ptr %a0)
declare i1 @compiler_2flower_2ecompiler_2flower_3alowering_2erunsIn(ptr %v0, ptr %a0, i64 %a1, i32 %a2, i1 %a3)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2flower_2ecompiler_2flower_3alowering_2erunOrder(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eonError(ptr %v0, ptr %a0, i64 %a1)
@G_2ecompiler_2fmir_2eNoBlock = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\FF\FF\FF\FF" }>, align 8
declare i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eisDrop(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_de8dc91cd31c6e72_d86f27d9b5b5bc3e = external constant [0 x i8]
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2estmtSpawnErrors(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare i1 @compiler_2flower_2ecompiler_2flower_3alowering_2establePlace(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_a75b87f7fc6585db_9c37e910f1cfbc0f = external constant [0 x i8]
declare i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eplaceRooted(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2flower_2ecompiler_2flower_3alowering_2estableHolder(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2ftyped_2ePassesRefs(i32 %a0)
@olang_loc_7e6d7b9279609ab3_447c445eeb868dc7 = external constant [0 x i8]
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2estmtIn(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i32, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2ePop_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_a5b1a763b9bba10_ba6ba978893df9a4 = external constant [0 x i8]
@olang_loc_eb3797cfa5f64105_1f3db8e929f64739 = external constant [0 x i8]
@olang_loc_d2f375e5ba968b65_383d0166caeed659 = external constant [0 x i8]
@olang_loc_e527201c6aa166ab_3a4acb23654914bf = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %a0)
@olang_loc_f20c72191c5bbaec_70ba5090fad608c8 = external constant [0 x i8]
@olang_loc_9792dafd009dd231_d222868cd9c52d2d = external constant [0 x i8]
@olang_loc_5cf7683923427be1_eeed011b70fc7f3d = external constant [0 x i8]
@olang_loc_35262608d5eaeb07_a04d120ff2489083 = external constant [0 x i8]
declare %"compiler/mir:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eAt_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_7c44d6a11fe580a3_63a95cd13601e77f = external constant [0 x i8]
declare { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2efit(ptr %v0, ptr %v1, ptr %a0, { i64, [4 x i64] } %a1, ptr %a2, i32 %a3, %"compiler/source:Span" %a4)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2eretArrays(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2, ptr %a3, %"compiler/source:Span" %a4)
@olang_loc_c2ea6282af4907c_77e331cc54ab44a0 = external constant [0 x i8]
declare %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eScopeRefs(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare %"compiler/mir:Range" @compiler_2flower_2ecompiler_2flower_3alowering_2eargs(ptr %v0, ptr %v1, ptr %a0, ptr %a1, { i64, [7 x i64] } %a2, i32 %a3)
@olang_loc_16ceb3f79d83ba4c_75eb4aa6518e3548 = external constant [0 x i8]
declare { i64, [4 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2eAt_3ccompiler_2fmir_3aOperand_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fmir_2ePassedCount(ptr %v0, ptr %a0, { i64, [7 x i64] } %a1, i32 %a2)
declare %"compiler/mir:Range" @compiler_2flower_2ecompiler_2flower_3alowering_2epassed(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
@G_2ecompiler_2fmir_2eNoPlace = available_externally constant <{ [32 x i8] }> <{ [32 x i8] c"\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00" }>, align 32
@G_2ecompiler_2fmir_2eNoLocal = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\FF\FF\FF\FF" }>, align 8
declare %"compiler/mir:Call" @compiler_2fmir_3aCall_2ector(ptr %v0, { i64, [7 x i64] } %a0, %"compiler/mir:Range" %a1, %"compiler/mir:Range" %a2, %"compiler/mir:Lvalue" %a3, i1 %a4, i32 %a5, i32 %a6, i32 %a7)
declare i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddCall(ptr %v0, ptr %a0, %"compiler/mir:Call" %a1)
declare i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddTemp(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2)
@olang_loc_a3627063ced14f10_5c0b773917422a84 = external constant [0 x i8]
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2eAt_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eheldViews(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v0, ptr %a0)
declare i64 @compiler_2ftyped_2eCalleeBody(ptr %v0, ptr %a0)
declare i64 @compiler_2flower_2ecompiler_2flower_3aLowerer_2eViewsOf(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftyped_2eViewOther = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\40" }>, align 8
@G_2ecompiler_2ftyped_2eViewBits = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\3E\00\00\00\00\00\00\00" }>, align 8
declare i64 @std_2fprelude_2fnumber_2eI64_2eMin_3cI64_3e(i64 %a0, i64 %a1)
declare i1 @compiler_2flower_2ecompiler_2flower_3alowering_2ewindowFor(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, ptr %a2, ptr %a3)
@G_2ecompiler_2fmir_2eEmpty = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %a0, i32 %a1)
declare void @compiler_2ftyped_3aBody_2ector(ptr %out, ptr %v0, i32 %a0, { i64, [2 x i64] } %a1, i32 %a2, i64 %a3, %"compiler/source:Span" %a4)
declare ptr @compiler_2flower_2etempRoot(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_45fce2847dc3b097_fb8f06ed07981043 = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBlockId_3e_2ector(ptr %v0, i64 %a0)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
