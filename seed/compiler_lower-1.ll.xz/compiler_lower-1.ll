; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/lower:Lowerer" = type { ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i32, i32, i32 }
%"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/typed:Body" = type { i32, { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/mir:Fn" = type { { i64, [1 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/lower:lowering" = type { ptr, ptr, ptr, %"compiler/mir:Fn", i64, { i64, [4 x i64] }, i32, i1, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i32, { i64, [1 x i64] }, %"compiler/typed:Plan" }
%"compiler/typed:Plan" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/generic:Program" = type { ptr, ptr, %"compiler/types:Table", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"compiler/generic:Origin", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/types:Table" = type { ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1 }
%"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/generic:Origin" = type { i64, %"compiler/source:Span", i64 }
%"compiler/mir:Place" = type { { i64, [2 x i64] }, %"compiler/mir:Range" }
%"compiler/mir:Range" = type { i32, i32 }
%"compiler/lower:level" = type { i32, i32, i32 }
%"compiler/typed:Arm" = type { %"compiler/source:Span", { i64, ptr }, ptr, ptr, ptr }
%"compiler/typed:Block" = type { i32, { i64, ptr } }
%"compiler/typed:Make" = type { i32, i64, { i64, ptr }, ptr, i32, i32 }
%"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" = type { i64, i64 }
%"compiler/load:Loader" = type { { i64, ptr }, ptr, ptr, ptr, ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, { i64, ptr } }
%"compiler/load:Module" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i64, i1, ptr, ptr, { i64, ptr }, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, ptr, ptr, i1, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/mir:Call" = type { { i64, [5 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/mir:Place", i1, i32, i32, i32 }
%"compiler/typed:Call" = type { ptr, { i64, ptr }, { i64, [2 x i64] }, i32, i1 }
%"compiler/lower:tryCtx" = type { i64, { i64, ptr }, i1, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/typed:Clause" = type { %"compiler/source:Span", { i64, ptr }, i1, ptr, { i64, ptr } }
%"compiler/lower:collectCtx" = type { i32, i32, i32, i32, { i64, [1 x i64] } }
%"compiler/typed:Collect" = type { ptr, ptr, i32, i32 }
%"compiler/typed:Cond" = type { ptr, ptr, ptr }
%"compiler/lower:pl" = type { { i64, [2 x i64] }, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/typed:Item" = type { i32, i64 }
%"compiler/typed:BlockInfo" = type { i32, i32, %"compiler/source:Span" }
%"compiler/mir:ScopeInfo" = type { i32, i32, i32, %"compiler/source:Span", i32 }
%"compiler/lower:Gap" = type { i64, %"compiler/source:Span", { i64, ptr } }
%"compiler/typed:Join" = type { ptr, i1, { i64, ptr } }
%"compiler/lower:loopCtx" = type { i32, i64, i32, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/typed:Payload" = type { ptr, i64, i32 }
%"compiler/typed:Promote" = type { ptr, i32 }
%"compiler/mir:Local" = type { i32, %"compiler/source:Span", i32, i32, { i64, [1 x i64] } }
%"compiler/typed:Match" = type { { i64, ptr }, { i64, ptr }, ptr, i1 }
%"compiler/typed:Try" = type { ptr, { i64, ptr }, i1, i1 }
%"compiler/typed:Seq" = type { { i64, ptr }, ptr }
%"compiler/typed:Slice" = type { ptr, ptr, ptr, i32 }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/typed:Local" = type { i32, %"compiler/source:Span", i32, i32, i32, { i64, [2 x i64] } }
%"compiler/typed:Spawn" = type { { i64, ptr }, ptr, { i64, ptr }, i32 }
%"compiler/typed:TaskClause" = type { %"compiler/source:Span", { i64, ptr }, i1, ptr }
%"compiler/typed:If" = type { ptr, ptr, ptr }
define dso_local void @compiler_2flower_2eInvalid_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 3, ptr @G_2ecompiler_2flower_2eInvalid, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flower_2eWrongCase_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 4, ptr @G_2ecompiler_2flower_2eWrongCase, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3aLowerer_2eHasCode(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l2 = alloca ptr
  %l7 = alloca ptr
  %l14 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/lower:Lowerer", ptr %a0, i32 0, i32 1
  %t7 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t3, i64 %a1)
  store ptr %t7, ptr %l7
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l7, !tbaa !29
  store ptr %t8, ptr %l2, !tbaa !29
  %t9 = load ptr, ptr %l2, !tbaa !29
  %t11 = getelementptr %"compiler/typed:Body", ptr %t9, i32 0, i32 11
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t14 = icmp eq ptr %t12, null
  br i1 %t14, label %bb2, label %bb3
bb2:
  store i1 false, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t17 = load ptr, ptr %l2, !tbaa !29
  %t19 = getelementptr %"compiler/typed:Body", ptr %t17, i32 0, i32 1
  %t20 = load { i64, [2 x i64] }, ptr %t19
  %t24 = extractvalue { i64, [2 x i64] } %t20, 0
  %t25 = icmp eq i64 %t24, 2
  br i1 %t25, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb8
bb7:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb13
bb8:
  br i1 true, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  store i1 true, ptr %l14, !tbaa !21
  br label %bb13
bb12:
  call void @__olang_check_failed(ptr @olang_loc_daa9f23a83841987_24921124063ad36b)
  unreachable
bb13:
  %t27 = load i1, ptr %l14, !tbaa !21
  store i1 %t27, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2flower_2ecompiler_2flower_3aLowerer_2eInitModules(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %lp1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l8 = alloca { i64, [2 x i64] }
  %l9 = alloca i64
  %l11 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l14 = alloca i64
  %l18 = alloca i64
  %l21 = alloca i64
  %l42 = alloca ptr
  %l51 = alloca i1
  %s2 = alloca %olang.scope
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l11
  br label %bb1
bb1:
  %t3 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 8, i64 8)
  store ptr %t3, ptr %lp1
  %t4 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l11
  %t5 = load ptr, ptr %lp1
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t4, ptr %t5
  store i64 0, ptr %l2, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/lower:Lowerer", ptr %t6, i32 0, i32 1
  %t10 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_Ha6bcf4d517e3d7b46809e1dbf938da91(ptr %v0, ptr %t8)
  store i64 %t10, ptr %l14
  br label %bb2
bb2:
  %t11 = load i64, ptr %l14, !tbaa !24
  store i64 %t11, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t12 = load i64, ptr %l3, !tbaa !24
  %t13 = load i64, ptr %l2, !tbaa !24
  %t16 = icmp sgt i64 %t12, %t13
  br i1 %t16, label %bb3, label %bb4
bb3:
  %t18 = load i64, ptr %l4, !tbaa !24
  %t20 = icmp sgt i64 %t18, 0
  br i1 %t20, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l18, !tbaa !24
  br label %bb8
bb5:
  %t22 = load i64, ptr %l3, !tbaa !24
  %t23 = load i64, ptr %l2, !tbaa !24
  %t26 = sub i64 %t22, %t23
  %t27 = load i64, ptr %l4, !tbaa !24
  %t30 = add i64 %t26, %t27
  %t32 = sub i64 %t30, 1
  %t33 = load i64, ptr %l4, !tbaa !24
  %t36 = sdiv i64 %t32, %t33
  store i64 %t36, ptr %l21, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l21, !tbaa !24
  br label %bb7
bb7:
  %t38 = load i64, ptr %l21, !tbaa !24
  store i64 %t38, ptr %l18, !tbaa !24
  br label %bb8
bb8:
  %t39 = load i64, ptr %l18, !tbaa !24
  store i64 %t39, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t40 = load i64, ptr %l6, !tbaa !24
  %t41 = load i64, ptr %l5, !tbaa !24
  %t44 = icmp slt i64 %t40, %t41
  %t46 = xor i1 %t44, true
  br i1 %t46, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb29
bb11:
  br label %bb12
bb12:
  %t48 = load i64, ptr %l2, !tbaa !24
  %t49 = load i64, ptr %l6, !tbaa !24
  %t50 = load i64, ptr %l4, !tbaa !24
  %t53 = mul i64 %t49, %t50
  %t56 = add i64 %t48, %t53
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/lower:Lowerer", ptr %t58, i32 0, i32 1
  %t64 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t60, i64 %t56)
  store ptr %t64, ptr %l42
  br label %bb13
bb13:
  %t65 = load ptr, ptr %l42, !tbaa !29
  %t67 = getelementptr %"compiler/typed:Body", ptr %t65, i32 0, i32 1
  %t68 = load { i64, [2 x i64] }, ptr %t67
  store { i64, [2 x i64] } %t68, ptr %l8
  %t70 = load { i64, [2 x i64] }, ptr %l8
  %t72 = extractvalue { i64, [2 x i64] } %t70, 0
  %t73 = icmp eq i64 %t72, 6
  br i1 %t73, label %bb14, label %bb15
bb14:
  %t75 = getelementptr { i64, [2 x i64] }, ptr %l8, i32 0, i32 1
  %t76 = getelementptr { i64, i32 }, ptr %t75, i32 0, i32 0
  %t77 = load i64, ptr %t76
  store i64 %t77, ptr %l9, !tbaa !24
  br label %bb16
bb15:
  br label %bb22
bb16:
  %t79 = load i64, ptr %l9, !tbaa !24
  %t81 = load ptr, ptr %lp1
  %t85 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eHas_3cI64_3e(ptr %v1, ptr %t81, i64 %t79)
  store i1 %t85, ptr %l51
  br label %bb17
bb17:
  %t86 = load i1, ptr %l51, !tbaa !21
  %t87 = xor i1 %t86, true
  br i1 %t87, label %bb18, label %bb19
bb18:
  %t89 = load ptr, ptr %lp1
  %t90 = load i64, ptr %l9, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t89, i64 %t90)
  br label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb21
bb21:
  br label %bb27
bb22:
  br i1 true, label %bb23, label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb27
bb26:
  call void @__olang_check_failed(ptr @olang_loc_e3721461a855ef35_c24433bc0ae5f641)
  unreachable
bb27:
  call void @__olang_scope_close(ptr %s2)
  br label %bb28
bb28:
  %t93 = load i64, ptr %l6, !tbaa !24
  %t95 = add i64 %t93, 1
  store i64 %t95, ptr %l6, !tbaa !24
  br label %bb9
bb29:
  %t97 = load ptr, ptr %lp1
  %t98 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t97
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t98, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3aLowerer_2eLower(ptr %out, ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %lp2 = alloca ptr
  %lp3 = alloca ptr
  %lp4 = alloca ptr
  %l8 = alloca ptr
  %l19 = alloca %"compiler/mir:Fn"
  %l26 = alloca %"compiler/lower:lowering"
  %l29 = alloca i64
  %l32 = alloca i64
  %l37 = alloca %"compiler/typed:Plan"
  %l41 = alloca %"compiler/mir:Fn"
  %t15 = alloca { i64, [1 x i64] }, align 8
  %t36 = alloca %"compiler/mir:Fn", align 8
  %t53 = alloca %"compiler/lower:lowering", align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:Lowerer", ptr %t1, i32 0, i32 1
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v1, ptr %t3, i64 %t4)
  store ptr %t7, ptr %l8
  br label %bb1
bb1:
  %t8 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 8, i64 8)
  store ptr %t8, ptr %lp2
  %t9 = load ptr, ptr %l8, !tbaa !29
  %t10 = load ptr, ptr %lp2
  store ptr %t9, ptr %t10, !tbaa !29
  %t11 = load i64, ptr %l1, !tbaa !24
  %t13 = trunc i64 %t11 to i32
  store { i64, [1 x i64] } zeroinitializer, ptr %t15
  %t16 = getelementptr { i64, [1 x i64] }, ptr %t15, i32 0, i32 0
  store i64 0, ptr %t16
  %t18 = insertvalue { i32 } undef, i32 %t13, 0
  %t19 = getelementptr { i64, [1 x i64] }, ptr %t15, i32 0, i32 1
  store { i32 } %t18, ptr %t19
  %t20 = load { i64, [1 x i64] }, ptr %t15
  %t21 = load ptr, ptr %lp2
  %t22 = load ptr, ptr %t21, !tbaa !29
  %t24 = getelementptr %"compiler/typed:Body", ptr %t22, i32 0, i32 2
  %t25 = load i32, ptr %t24, !tbaa !23
  %t26 = load ptr, ptr %lp2
  %t27 = load ptr, ptr %t26, !tbaa !29
  %t29 = getelementptr %"compiler/typed:Body", ptr %t27, i32 0, i32 3
  %t30 = load i64, ptr %t29, !tbaa !24
  %t31 = load ptr, ptr %lp2
  %t32 = load ptr, ptr %t31, !tbaa !29
  %t34 = getelementptr %"compiler/typed:Body", ptr %t32, i32 0, i32 4
  %t35 = load %"compiler/source:Span", ptr %t34
  call void @compiler_2fmir_3aFn_2ector(ptr %t36, ptr %v1, { i64, [1 x i64] } %t20, i32 %t25, i64 %t30, %"compiler/source:Span" %t35)
  call void @llvm.memmove.p0.p0.i64(ptr %l19, ptr %t36, i64 192, i1 false)
  br label %bb2
bb2:
  %t41 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 192, i64 8)
  store ptr %t41, ptr %lp3
  %t42 = load ptr, ptr %lp3
  call void @llvm.memmove.p0.p0.i64(ptr %t42, ptr %l19, i64 192, i1 false)
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t44 = load ptr, ptr %lp2
  %t45 = load ptr, ptr %t44, !tbaa !29
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/lower:Lowerer", ptr %t46, i32 0, i32 0
  %t49 = load ptr, ptr %t48, !tbaa !29
  %t51 = getelementptr %"compiler/generic:Program", ptr %t49, i32 0, i32 2
  %t52 = load ptr, ptr %lp3
  call void @compiler_2flower_3alowering_2ector(ptr %t53, ptr %v0, ptr %v1, ptr %v0, ptr %v1, ptr %v1, ptr %t43, ptr %t45, ptr %t51, ptr %t52)
  call void @llvm.memmove.p0.p0.i64(ptr %l26, ptr %t53, i64 456, i1 false)
  br label %bb3
bb3:
  %t58 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 456, i64 8)
  store ptr %t58, ptr %lp4
  %t59 = load ptr, ptr %lp4
  call void @llvm.memmove.p0.p0.i64(ptr %t59, ptr %l26, i64 456, i1 false)
  %t60 = load ptr, ptr %lp2
  %t61 = load ptr, ptr %t60, !tbaa !29
  %t63 = getelementptr %"compiler/typed:Body", ptr %t61, i32 0, i32 3
  %t64 = load i64, ptr %t63, !tbaa !24
  %t66 = load ptr, ptr %lp4
  %t67 = getelementptr %"compiler/lower:lowering", ptr %t66, i32 0, i32 4
  store i64 %t64, ptr %t67, !tbaa !24
  %t68 = load i64, ptr %l1, !tbaa !24
  store i64 %t68, ptr %l29, !tbaa !24
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/lower:Lowerer", ptr %t69, i32 0, i32 2
  %t73 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlan_3e_2eLen_3ccompiler_2ftyped_3aPlan_3e(ptr %v0, ptr %t71)
  store i64 %t73, ptr %l32
  br label %bb4
bb4:
  %t74 = load i64, ptr %l29, !tbaa !24
  %t75 = load i64, ptr %l32, !tbaa !24
  %t76 = icmp slt i64 %t74, %t75
  br i1 %t76, label %bb5, label %bb6
bb5:
  %t78 = load ptr, ptr %lp4
  %t79 = getelementptr %"compiler/lower:lowering", ptr %t78, i32 0, i32 19
  store i1 true, ptr %t79, !tbaa !21
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t82 = getelementptr %"compiler/lower:Lowerer", ptr %t80, i32 0, i32 2
  %t83 = load i64, ptr %l1, !tbaa !24
  %t86 = call %"compiler/typed:Plan" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlan_3e_2eAt_3ccompiler_2ftyped_3aPlan_3e(ptr %v0, ptr %v1, ptr %t82, i64 %t83)
  store %"compiler/typed:Plan" %t86, ptr %l37
  br label %bb7
bb6:
  br label %bb8
bb7:
  %t87 = load %"compiler/typed:Plan", ptr %l37
  %t88 = load ptr, ptr %lp4
  %t89 = getelementptr %"compiler/lower:lowering", ptr %t88, i32 0, i32 22
  store %"compiler/typed:Plan" %t87, ptr %t89
  br label %bb8
bb8:
  %t90 = load ptr, ptr %lp4
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2erun(ptr %v1, ptr %t90)
  br label %bb9
bb9:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t93 = load ptr, ptr %lp4
  %t94 = getelementptr %"compiler/lower:lowering", ptr %t93, i32 0, i32 8
  %t95 = load i1, ptr %t94, !tbaa !21
  %t98 = getelementptr %"compiler/lower:Lowerer", ptr %t92, i32 0, i32 4
  store i1 %t95, ptr %t98, !tbaa !21
  %t99 = load ptr, ptr %lp4
  %t100 = getelementptr %"compiler/lower:lowering", ptr %t99, i32 0, i32 3
  call void @llvm.memmove.p0.p0.i64(ptr %l41, ptr %t100, i64 192, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l41, i64 192, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local { i1, { i64, ptr }, { i64, ptr } } @compiler_2flower_2ecompiler_2flower_3aLowerer_2eVerifiedKey(ptr %v0, ptr %v1, ptr %a0, { i64, [1 x i64] } %a1, i1 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca ptr
  %lp4 = alloca ptr
  %l8 = alloca %"compiler/mir:Fn"
  %l12 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l16 = alloca { i1, { i64, ptr }, { i64, ptr } }
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l39 = alloca { i1, { i64, ptr }, { i64, ptr } }
  %l40 = alloca { i64, ptr }
  %l41 = alloca i64
  %l42 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i1, { i64, ptr }, { i64, ptr } }
  %t3 = alloca %"compiler/mir:Fn", align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3aLowerer_2eLowerKey(ptr %t3, ptr %v0, ptr %v0, ptr %t1, { i64, [1 x i64] } %a1)
  call void @llvm.memmove.p0.p0.i64(ptr %l8, ptr %t3, i64 192, i1 false)
  br label %bb1
bb1:
  %t6 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 192, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t6, ptr %l8, i64 192, i1 false)
  store ptr %t6, ptr %l3, !tbaa !29
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/lower:Lowerer", ptr %t8, i32 0, i32 4
  %t11 = load i1, ptr %t10, !tbaa !21
  br i1 %t11, label %bb2, label %bb3
bb2:
  store { i64, ptr } { i64 0, ptr @.d0 }, ptr %l12, !tbaa !27
  %t13 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } { i64 0, ptr @.d1 }, ptr %l14, !tbaa !27
  %t14 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t15 = insertvalue { i1, { i64, ptr }, { i64, ptr } } undef, i1 true, 0
  %t17 = insertvalue { i1, { i64, ptr }, { i64, ptr } } %t15, { i64, ptr } %t13, 1
  %t19 = insertvalue { i1, { i64, ptr }, { i64, ptr } } %t17, { i64, ptr } %t14, 2
  store { i1, { i64, ptr }, { i64, ptr } } %t19, ptr %l16
  %t20 = getelementptr { i1, { i64, ptr }, { i64, ptr } }, ptr %l16, i32 0, i32 1
  %t21 = load { i64, ptr }, ptr %t20, !tbaa !27
  store { i64, ptr } %t21, ptr %l17, !tbaa !27
  %t22 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t22, 0
  store i64 %t23, ptr %l18, !tbaa !24
  %t24 = load i64, ptr %l18, !tbaa !24
  %t25 = mul i64 %t24, 1
  %t26 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t25)
  %t27 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  store { i64, ptr } %t28, ptr %l19, !tbaa !27
  %t29 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !27
  %t31 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = load i64, ptr %l18, !tbaa !24
  %t34 = mul i64 %t33, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t30, ptr %t32, i64 %t34, i1 false)
  %t35 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t36 = getelementptr { i1, { i64, ptr }, { i64, ptr } }, ptr %l16, i32 0, i32 1
  store { i64, ptr } %t35, ptr %t36, !tbaa !27
  %t37 = getelementptr { i1, { i64, ptr }, { i64, ptr } }, ptr %l16, i32 0, i32 2
  %t38 = load { i64, ptr }, ptr %t37, !tbaa !27
  store { i64, ptr } %t38, ptr %l20, !tbaa !27
  %t39 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t40 = extractvalue { i64, ptr } %t39, 0
  store i64 %t40, ptr %l21, !tbaa !24
  %t41 = load i64, ptr %l21, !tbaa !24
  %t42 = mul i64 %t41, 1
  %t43 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t42)
  %t44 = insertvalue { i64, ptr } undef, i64 %t41, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t43, 1
  store { i64, ptr } %t45, ptr %l22, !tbaa !27
  %t46 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !27
  %t48 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !27
  %t50 = load i64, ptr %l21, !tbaa !24
  %t51 = mul i64 %t50, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t47, ptr %t49, i64 %t51, i1 false)
  %t52 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t53 = getelementptr { i1, { i64, ptr }, { i64, ptr } }, ptr %l16, i32 0, i32 2
  store { i64, ptr } %t52, ptr %t53, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t54 = load { i1, { i64, ptr }, { i64, ptr } }, ptr %l16
  store { i1, { i64, ptr }, { i64, ptr } } %t54, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t55 = load ptr, ptr %l3, !tbaa !29
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/lower:Lowerer", ptr %t56, i32 0, i32 0
  %t59 = load ptr, ptr %t58, !tbaa !29
  %t61 = getelementptr %"compiler/generic:Program", ptr %t59, i32 0, i32 2
  %t64 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3aFn_2eVerify(ptr %v0, ptr %v0, ptr %v1, ptr %t55, ptr %t61)
  store { i64, ptr } %t64, ptr %l27
  br label %bb5
bb5:
  %t65 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t65, ptr %lp4
  %t66 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t67 = load ptr, ptr %lp4
  store { i64, ptr } %t66, ptr %t67, !tbaa !27
  br i1 %a2, label %bb6, label %bb7
bb6:
  %t70 = load ptr, ptr %l3, !tbaa !29
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/lower:Lowerer", ptr %t71, i32 0, i32 0
  %t74 = load ptr, ptr %t73, !tbaa !29
  %t76 = getelementptr %"compiler/generic:Program", ptr %t74, i32 0, i32 2
  %t79 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3aFn_2eDump(ptr %v0, ptr %v0, ptr %s0, ptr %t70, ptr %t76)
  store { i64, ptr } %t79, ptr %l34
  br label %bb8
bb7:
  store { i64, ptr } { i64 0, ptr @.d2 }, ptr %l29, !tbaa !27
  br label %bb9
bb8:
  %t80 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t81 = extractvalue { i64, ptr } %t80, 0
  %t82 = extractvalue { i64, ptr } %t80, 1
  %t83 = mul i64 %t81, 1
  %t84 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t83)
  call void @llvm.memcpy.p0.p0.i64(ptr %t84, ptr %t82, i64 %t83, i1 false)
  %t85 = insertvalue { i64, ptr } undef, i64 %t81, 0
  %t86 = insertvalue { i64, ptr } %t85, ptr %t84, 1
  store { i64, ptr } %t86, ptr %l29, !tbaa !27
  br label %bb9
bb9:
  %t88 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t89 = load ptr, ptr %lp4
  %t90 = load { i64, ptr }, ptr %t89, !tbaa !27
  %t93 = insertvalue { i1, { i64, ptr }, { i64, ptr } } undef, i1 false, 0
  %t95 = insertvalue { i1, { i64, ptr }, { i64, ptr } } %t93, { i64, ptr } %t90, 1
  %t97 = insertvalue { i1, { i64, ptr }, { i64, ptr } } %t95, { i64, ptr } %t88, 2
  store { i1, { i64, ptr }, { i64, ptr } } %t97, ptr %l39
  %t98 = getelementptr { i1, { i64, ptr }, { i64, ptr } }, ptr %l39, i32 0, i32 2
  %t99 = load { i64, ptr }, ptr %t98, !tbaa !27
  store { i64, ptr } %t99, ptr %l40, !tbaa !27
  %t100 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t101 = extractvalue { i64, ptr } %t100, 0
  store i64 %t101, ptr %l41, !tbaa !24
  %t102 = load i64, ptr %l41, !tbaa !24
  %t103 = mul i64 %t102, 1
  %t104 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t103)
  %t105 = insertvalue { i64, ptr } undef, i64 %t102, 0
  %t106 = insertvalue { i64, ptr } %t105, ptr %t104, 1
  store { i64, ptr } %t106, ptr %l42, !tbaa !27
  %t107 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t108 = load ptr, ptr %t107, !tbaa !27
  %t109 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t110 = load ptr, ptr %t109, !tbaa !27
  %t111 = load i64, ptr %l41, !tbaa !24
  %t112 = mul i64 %t111, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t108, ptr %t110, i64 %t112, i1 false)
  %t113 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t114 = getelementptr { i1, { i64, ptr }, { i64, ptr } }, ptr %l39, i32 0, i32 2
  store { i64, ptr } %t113, ptr %t114, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t115 = load { i1, { i64, ptr }, { i64, ptr } }, ptr %l39
  store { i1, { i64, ptr }, { i64, ptr } } %t115, ptr %rv
  br label %ret
ret:
  %rr = load { i1, { i64, ptr }, { i64, ptr } }, ptr %rv
  ret { i1, { i64, ptr }, { i64, ptr } } %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3aLowerer_2eadapterFn(ptr %out, ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i32
  %lp12 = alloca ptr
  %lp13 = alloca ptr
  %l18 = alloca ptr
  %l23 = alloca ptr
  %l28 = alloca i32
  %l29 = alloca { i64, ptr }
  %l32 = alloca i64
  %l41 = alloca i64
  %l44 = alloca i64
  %l63 = alloca { i64, ptr }
  %l71 = alloca ptr
  %l76 = alloca i32
  %l81 = alloca i32
  %l86 = alloca i32
  %l87 = alloca i32
  %l89 = alloca %"compiler/typed:Body"
  %l90 = alloca ptr
  %l91 = alloca ptr
  %l94 = alloca ptr
  %l99 = alloca %"compiler/mir:Fn"
  %l101 = alloca %"compiler/lower:lowering"
  %l105 = alloca { i64, ptr }
  %l109 = alloca %"compiler/mir:Fn"
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %t179 = alloca { i64, [1 x i64] }, align 8
  %t186 = alloca %"compiler/mir:Fn", align 8
  %t191 = alloca %"compiler/lower:lowering", align 8
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:Lowerer", ptr %t1, i32 0, i32 1
  %t4 = load i32, ptr %l1, !tbaa !23
  %t6 = sext i32 %t4 to i64
  %t9 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t3, i64 %t6)
  store ptr %t9, ptr %l18
  br label %bb1
bb1:
  %t10 = load ptr, ptr %l18, !tbaa !29
  %t12 = getelementptr %"compiler/typed:Body", ptr %t10, i32 0, i32 2
  %t13 = load i32, ptr %t12, !tbaa !23
  store i32 %t13, ptr %l2, !tbaa !23
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/lower:Lowerer", ptr %t15, i32 0, i32 0
  %t18 = load ptr, ptr %t17, !tbaa !29
  %t20 = getelementptr %"compiler/generic:Program", ptr %t18, i32 0, i32 2
  store ptr %t20, ptr %l23, !tbaa !29
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/lower:Lowerer", ptr %t21, i32 0, i32 0
  %t24 = load ptr, ptr %t23, !tbaa !29
  %t26 = getelementptr %"compiler/generic:Program", ptr %t24, i32 0, i32 2
  %t27 = load i32, ptr %l2, !tbaa !23
  %t30 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t26, i32 %t27)
  store i32 %t30, ptr %l28
  br label %bb2
bb2:
  %t31 = load ptr, ptr %l23, !tbaa !29
  %t32 = load i32, ptr %l28, !tbaa !23
  %t33 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t31, i32 %t32)
  store { i64, ptr } %t33, ptr %l29
  br label %bb3
bb3:
  %t34 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t34, ptr %l3, !tbaa !27
  %t35 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t37 = extractvalue { i64, ptr } %t35, 0
  %t39 = sub i64 %t37, 1
  store i64 %t39, ptr %l32, !tbaa !24
  %t40 = load i64, ptr %l32, !tbaa !24
  %t41 = icmp sge i64 %t40, 0
  br i1 %t41, label %bb4, label %bb5
bb4:
  %t43 = load i64, ptr %l32, !tbaa !24
  %t44 = icmp sle i64 %t43, 2305843009213693951
  br i1 %t44, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_4e4c17ebfaf5d7b6_624a73934957b6f2)
  unreachable
bb6:
  %t46 = load i64, ptr %l32, !tbaa !24
  %t47 = mul i64 %t46, 4
  %t48 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t47)
  %t49 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t50 = insertvalue { i64, ptr } %t49, ptr %t48, 1
  store { i64, ptr } %t50, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t52 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t54 = extractvalue { i64, ptr } %t52, 0
  store i64 %t54, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t56 = load i64, ptr %l6, !tbaa !24
  %t57 = load i64, ptr %l5, !tbaa !24
  %t60 = icmp sgt i64 %t56, %t57
  br i1 %t60, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_4e4c17ebfaf5d7b6_624a73934957b6f2)
  unreachable
bb8:
  %t62 = load i64, ptr %l7, !tbaa !24
  %t64 = icmp sgt i64 %t62, 0
  br i1 %t64, label %bb10, label %bb11
bb9:
  store i64 0, ptr %l41, !tbaa !24
  br label %bb13
bb10:
  %t66 = load i64, ptr %l6, !tbaa !24
  %t67 = load i64, ptr %l5, !tbaa !24
  %t70 = sub i64 %t66, %t67
  %t71 = load i64, ptr %l7, !tbaa !24
  %t74 = add i64 %t70, %t71
  %t76 = sub i64 %t74, 1
  %t77 = load i64, ptr %l7, !tbaa !24
  %t80 = sdiv i64 %t76, %t77
  store i64 %t80, ptr %l44, !tbaa !24
  br label %bb12
bb11:
  store i64 0, ptr %l44, !tbaa !24
  br label %bb12
bb12:
  %t82 = load i64, ptr %l44, !tbaa !24
  store i64 %t82, ptr %l41, !tbaa !24
  br label %bb13
bb13:
  %t83 = load i64, ptr %l41, !tbaa !24
  store i64 %t83, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb14
bb14:
  store %olang.scope zeroinitializer, ptr %s2
  %t84 = load i64, ptr %l9, !tbaa !24
  %t85 = load i64, ptr %l8, !tbaa !24
  %t88 = icmp slt i64 %t84, %t85
  %t90 = xor i1 %t88, true
  br i1 %t90, label %bb15, label %bb16
bb15:
  call void @__olang_scope_close(ptr %s2)
  br label %bb19
bb16:
  br label %bb17
bb17:
  %t92 = load i64, ptr %l5, !tbaa !24
  %t93 = load i64, ptr %l9, !tbaa !24
  %t94 = load i64, ptr %l7, !tbaa !24
  %t97 = mul i64 %t93, %t94
  %t100 = add i64 %t92, %t97
  store i64 %t100, ptr %l10, !tbaa !24
  %t102 = load i64, ptr %l10, !tbaa !24
  %t103 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t103, ptr %l63, !tbaa !27
  %t104 = load i64, ptr %l10, !tbaa !24
  %t106 = add i64 %t104, 1
  %t108 = getelementptr { i64, ptr }, ptr %l63, i32 0, i32 1
  %t109 = load ptr, ptr %t108, !tbaa !27
  %t110 = getelementptr i32, ptr %t109, i64 %t106
  %t111 = load i32, ptr %t110, !tbaa !33
  %t114 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t115 = load ptr, ptr %t114, !tbaa !27
  %t116 = getelementptr i32, ptr %t115, i64 %t102
  store i32 %t111, ptr %t116, !tbaa !33
  call void @__olang_scope_close(ptr %s2)
  br label %bb18
bb18:
  %t117 = load i64, ptr %l9, !tbaa !24
  %t119 = add i64 %t117, 1
  store i64 %t119, ptr %l9, !tbaa !24
  br label %bb14
bb19:
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t123 = getelementptr %"compiler/lower:Lowerer", ptr %t121, i32 0, i32 0
  %t124 = load ptr, ptr %t123, !tbaa !29
  %t126 = getelementptr %"compiler/generic:Program", ptr %t124, i32 0, i32 2
  store ptr %t126, ptr %l71, !tbaa !29
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t129 = getelementptr %"compiler/lower:Lowerer", ptr %t127, i32 0, i32 0
  %t130 = load ptr, ptr %t129, !tbaa !29
  %t132 = getelementptr %"compiler/generic:Program", ptr %t130, i32 0, i32 2
  %t133 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t136 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s0, ptr %t132, { i64, ptr } %t133)
  store i32 %t136, ptr %l76
  br label %bb20
bb20:
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t139 = getelementptr %"compiler/lower:Lowerer", ptr %t137, i32 0, i32 0
  %t140 = load ptr, ptr %t139, !tbaa !29
  %t142 = getelementptr %"compiler/generic:Program", ptr %t140, i32 0, i32 2
  %t143 = load i32, ptr %l2, !tbaa !23
  %t146 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t142, i32 %t143)
  store i32 %t146, ptr %l81
  br label %bb21
bb21:
  %t147 = load ptr, ptr %l0, !tbaa !29
  %t149 = getelementptr %"compiler/lower:Lowerer", ptr %t147, i32 0, i32 0
  %t150 = load ptr, ptr %t149, !tbaa !29
  %t152 = getelementptr %"compiler/generic:Program", ptr %t150, i32 0, i32 2
  %t153 = load i32, ptr %l2, !tbaa !23
  %t156 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t152, i32 %t153)
  store i32 %t156, ptr %l86
  br label %bb22
bb22:
  %t157 = load ptr, ptr %l71, !tbaa !29
  %t158 = load i32, ptr %l76, !tbaa !23
  %t159 = load i32, ptr %l81, !tbaa !23
  %t160 = load i32, ptr %l86, !tbaa !23
  %t161 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t157, i32 %t158, i32 %t159, i32 %t160, i32 0, i64 0)
  store i32 %t161, ptr %l87
  br label %bb23
bb23:
  %t162 = load i32, ptr %l87, !tbaa !23
  store i32 %t162, ptr %l11, !tbaa !23
  %t163 = load i32, ptr %l11, !tbaa !23
  %t165 = call %"compiler/typed:Body" @compiler_2flower_2estandIn(ptr %v1, i32 %t163)
  store %"compiler/typed:Body" %t165, ptr %l89
  br label %bb24
bb24:
  %t166 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 112, i64 8)
  store ptr %t166, ptr %lp12
  %t167 = load %"compiler/typed:Body", ptr %l89
  %t168 = load ptr, ptr %lp12
  store %"compiler/typed:Body" %t167, ptr %t168
  %t169 = load ptr, ptr %l0, !tbaa !29
  store ptr %t169, ptr %l90, !tbaa !29
  %t170 = load ptr, ptr %lp12
  store ptr %t170, ptr %l91, !tbaa !29
  %t171 = load ptr, ptr %l0, !tbaa !29
  %t173 = getelementptr %"compiler/lower:Lowerer", ptr %t171, i32 0, i32 0
  %t174 = load ptr, ptr %t173, !tbaa !29
  %t176 = getelementptr %"compiler/generic:Program", ptr %t174, i32 0, i32 2
  store ptr %t176, ptr %l94, !tbaa !29
  %t177 = load ptr, ptr %l0, !tbaa !29
  %t178 = load i32, ptr %l1, !tbaa !23
  store { i64, [1 x i64] } zeroinitializer, ptr %t179
  %t180 = getelementptr { i64, [1 x i64] }, ptr %t179, i32 0, i32 0
  store i64 1, ptr %t180
  %t182 = insertvalue { i32 } undef, i32 %t178, 0
  %t183 = getelementptr { i64, [1 x i64] }, ptr %t179, i32 0, i32 1
  store { i32 } %t182, ptr %t183
  %t184 = load { i64, [1 x i64] }, ptr %t179
  %t185 = load i32, ptr %l11, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3aLowerer_2ebare(ptr %t186, ptr %v0, ptr %v1, ptr %t177, { i64, [1 x i64] } %t184, i32 %t185)
  call void @llvm.memmove.p0.p0.i64(ptr %l99, ptr %t186, i64 192, i1 false)
  br label %bb25
bb25:
  %t190 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 192, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t190, ptr %l99, i64 192, i1 false)
  %t192 = load ptr, ptr %l90, !tbaa !29
  %t193 = load ptr, ptr %l91, !tbaa !29
  %t194 = load ptr, ptr %l94, !tbaa !29
  call void @compiler_2flower_3alowering_2ector(ptr %t191, ptr %v0, ptr %v1, ptr %v0, ptr %v1, ptr %v1, ptr %t192, ptr %t193, ptr %t194, ptr %t190)
  call void @llvm.memmove.p0.p0.i64(ptr %l101, ptr %t191, i64 456, i1 false)
  br label %bb26
bb26:
  %t196 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 456, i64 8)
  store ptr %t196, ptr %lp13
  %t197 = load ptr, ptr %lp13
  call void @llvm.memmove.p0.p0.i64(ptr %t197, ptr %l101, i64 456, i1 false)
  %t198 = load ptr, ptr %lp13
  %t199 = load i32, ptr %l1, !tbaa !23
  %t200 = load i32, ptr %l2, !tbaa !23
  %t201 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t201, ptr %l105, !tbaa !27
  %t202 = getelementptr { i64, ptr }, ptr %l105, i32 0, i32 1
  %t203 = load ptr, ptr %t202, !tbaa !27
  %t204 = getelementptr i32, ptr %t203, i64 0
  %t205 = load i32, ptr %t204, !tbaa !33
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eadapterBody(ptr %v1, ptr %t198, i32 %t199, i32 %t200, i32 %t205)
  br label %bb27
bb27:
  %t210 = load ptr, ptr %l0, !tbaa !29
  %t211 = load ptr, ptr %lp13
  %t212 = getelementptr %"compiler/lower:lowering", ptr %t211, i32 0, i32 8
  %t213 = load i1, ptr %t212, !tbaa !21
  %t216 = getelementptr %"compiler/lower:Lowerer", ptr %t210, i32 0, i32 4
  store i1 %t213, ptr %t216, !tbaa !21
  %t217 = load ptr, ptr %lp13
  %t218 = getelementptr %"compiler/lower:lowering", ptr %t217, i32 0, i32 3
  call void @llvm.memmove.p0.p0.i64(ptr %l109, ptr %t218, i64 192, i1 false)
  call void @__olang_scope_close(ptr %s0)
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l109, i64 192, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2flower_2ecompiler_2flower_3aLowerer_2ebuiltin(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca ptr
  %l7 = alloca i32
  %s1 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:Lowerer", ptr %t1, i32 0, i32 12
  %t4 = load i32, ptr %t3, !tbaa !23
  %t6 = icmp slt i32 %t4, 0
  br i1 %t6, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t8 = load ptr, ptr %l0, !tbaa !29
  store ptr %t8, ptr %l4, !tbaa !29
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/lower:Lowerer", ptr %t9, i32 0, i32 0
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t14 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ePreludeType(ptr %v0, ptr %s1, ptr %s1, ptr %t12, { i64, ptr } { i64 19, ptr @.d3 }, { i64, ptr } { i64 12, ptr @.d4 })
  store i32 %t14, ptr %l7
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t15 = load i32, ptr %l7, !tbaa !23
  %t16 = load ptr, ptr %l4, !tbaa !29
  %t17 = getelementptr %"compiler/lower:Lowerer", ptr %t16, i32 0, i32 12
  store i32 %t15, ptr %t17, !tbaa !23
  call void @__olang_scope_close(ptr %s1)
  br label %bb4
bb4:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/lower:Lowerer", ptr %t18, i32 0, i32 12
  %t21 = load i32, ptr %t20, !tbaa !23
  store i32 %t21, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2flower_2ecompiler_2flower_3aLowerer_2ehelperTy(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l2 = alloca i32
  %l5 = alloca i32
  %l11 = alloca i32
  %rv = alloca i32
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t3 = trunc i64 0 to i32
  %t4 = icmp eq i32 %a1, %t3
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = load i32, ptr %l2, !tbaa !23
  store i32 %t6, ptr %l5, !tbaa !23
  br label %bb4
bb2:
  %t10 = getelementptr %"compiler/lower:Lowerer", ptr %a0, i32 0, i32 0
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t13 = getelementptr %"compiler/generic:Program", ptr %t11, i32 0, i32 2
  %t14 = load i32, ptr %l2, !tbaa !23
  %t17 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eUnnamed(ptr %v0, ptr %t13, i32 %t14)
  store i32 %t17, ptr %l11
  br label %bb3
bb3:
  %t18 = load i32, ptr %l11, !tbaa !23
  store i32 %t18, ptr %l5, !tbaa !23
  br label %bb4
bb4:
  %t19 = load i32, ptr %l5, !tbaa !23
  store i32 %t19, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2flower_2ecompiler_2flower_3aLowerer_2etext(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca ptr
  %l7 = alloca i32
  %s1 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:Lowerer", ptr %t1, i32 0, i32 14
  %t4 = load i32, ptr %t3, !tbaa !23
  %t6 = icmp slt i32 %t4, 0
  br i1 %t6, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t8 = load ptr, ptr %l0, !tbaa !29
  store ptr %t8, ptr %l4, !tbaa !29
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/lower:Lowerer", ptr %t9, i32 0, i32 0
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t14 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ePreludeType(ptr %v0, ptr %s1, ptr %s1, ptr %t12, { i64, ptr } { i64 16, ptr @.d5 }, { i64, ptr } { i64 6, ptr @.d6 })
  store i32 %t14, ptr %l7
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t15 = load i32, ptr %l7, !tbaa !23
  %t16 = load ptr, ptr %l4, !tbaa !29
  %t17 = getelementptr %"compiler/lower:Lowerer", ptr %t16, i32 0, i32 14
  store i32 %t15, ptr %t17, !tbaa !23
  call void @__olang_scope_close(ptr %s1)
  br label %bb4
bb4:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/lower:Lowerer", ptr %t18, i32 0, i32 14
  %t21 = load i32, ptr %t20, !tbaa !23
  store i32 %t21, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2earm(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca { i64, [4 x i64] }
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l8 = alloca { i64, [4 x i64] }
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l13 = alloca { i64, [4 x i64] }
  %l21 = alloca i1
  %l28 = alloca { i64, [4 x i64] }
  %l29 = alloca ptr
  %l31 = alloca %"compiler/source:Span"
  %l33 = alloca %"compiler/mir:Place"
  %l40 = alloca i64
  %l42 = alloca i1
  %l44 = alloca %"compiler/lower:level"
  %l45 = alloca i32
  %l67 = alloca { i64, ptr }
  %l78 = alloca i1
  %l85 = alloca { i64, [4 x i64] }
  %l86 = alloca ptr
  %l88 = alloca %"compiler/source:Span"
  %l90 = alloca %"compiler/mir:Place"
  %l95 = alloca ptr
  %l115 = alloca { i64, ptr }
  %l126 = alloca i1
  %l133 = alloca { i64, [4 x i64] }
  %l134 = alloca ptr
  %l136 = alloca %"compiler/source:Span"
  %l138 = alloca %"compiler/mir:Place"
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %t42 = alloca { i64, [15 x i64] }, align 8
  %t48 = alloca { i64, [21 x i64] }, align 8
  %t173 = alloca { i64, [15 x i64] }, align 8
  %t179 = alloca { i64, [21 x i64] }, align 8
  %t286 = alloca { i64, [15 x i64] }, align 8
  %t292 = alloca { i64, [21 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Arm", ptr %t1, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = icmp eq ptr %t4, null
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t8 = load ptr, ptr %l1, !tbaa !29
  %t10 = getelementptr %"compiler/typed:Arm", ptr %t8, i32 0, i32 4
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t13 = icmp eq ptr %t11, null
  %t15 = xor i1 %t13, true
  br i1 %t15, label %bb3, label %bb4
bb2:
  br label %bb12
bb3:
  %t17 = load i32, ptr %l2, !tbaa !23
  %t18 = load i32, ptr @G_2ecompiler_2fmir_2eNoLocal, !tbaa !23
  %t21 = icmp ne i32 %t17, %t18
  store i1 %t21, ptr %l21, !tbaa !21
  br label %bb5
bb4:
  store i1 false, ptr %l21, !tbaa !21
  br label %bb5
bb5:
  %t23 = load i1, ptr %l21, !tbaa !21
  br i1 %t23, label %bb6, label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s2
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr %"compiler/typed:Arm", ptr %t25, i32 0, i32 4
  %t28 = load ptr, ptr %t27, !tbaa !29
  %t31 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v1, ptr %t24, ptr %t28)
  store { i64, [4 x i64] } %t31, ptr %l28
  br label %bb8
bb7:
  br label %bb11
bb8:
  %t32 = load { i64, [4 x i64] }, ptr %l28
  store { i64, [4 x i64] } %t32, ptr %l3
  %t33 = load ptr, ptr %l0, !tbaa !29
  store ptr %t33, ptr %l29, !tbaa !29
  %t34 = load ptr, ptr %l1, !tbaa !29
  %t36 = getelementptr %"compiler/typed:Arm", ptr %t34, i32 0, i32 0
  %t37 = load %"compiler/source:Span", ptr %t36
  store %"compiler/source:Span" %t37, ptr %l31
  %t38 = load i32, ptr %l2, !tbaa !23
  %t40 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t38)
  store %"compiler/mir:Place" %t40, ptr %l33
  br label %bb9
bb9:
  %t41 = load { i64, [4 x i64] }, ptr %l3
  store { i64, [15 x i64] } zeroinitializer, ptr %t42
  %t43 = getelementptr { i64, [15 x i64] }, ptr %t42, i32 0, i32 0
  store i64 0, ptr %t43
  %t45 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t41, 0
  %t46 = getelementptr { i64, [15 x i64] }, ptr %t42, i32 0, i32 1
  store { { i64, [4 x i64] } } %t45, ptr %t46
  %t47 = load { i64, [15 x i64] }, ptr %t42
  store { i64, [21 x i64] } zeroinitializer, ptr %t48
  %t49 = getelementptr { i64, [21 x i64] }, ptr %t48, i32 0, i32 0
  store i64 0, ptr %t49
  %t50 = load %"compiler/source:Span", ptr %l31
  %t51 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t50, 0
  %t52 = load %"compiler/mir:Place", ptr %l33
  %t53 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t51, %"compiler/mir:Place" %t52, 1
  %t55 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t53, { i64, [15 x i64] } %t47, 2
  %t56 = getelementptr { i64, [21 x i64] }, ptr %t48, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t55, ptr %t56
  %t57 = load { i64, [21 x i64] }, ptr %t48
  %t59 = call ptr @__olang_scope_alloc_a(ptr %s2, i64 176, i64 8)
  store { i64, [21 x i64] } %t57, ptr %t59
  %t60 = load ptr, ptr %l29, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s2, ptr %t60, ptr %t59)
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb11
bb11:
  br label %ret
bb12:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/lower:lowering", ptr %t62, i32 0, i32 9
  %t66 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3alevel_3e_2eLen_3ccompiler_2flower_3alevel_3e(ptr %v0, ptr %t64)
  store i64 %t66, ptr %l40
  br label %bb13
bb13:
  %t67 = load i64, ptr %l40, !tbaa !24
  %t68 = icmp sgt i64 %t67, 0
  br i1 %t68, label %bb14, label %bb15
bb14:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = call %"compiler/lower:level" @compiler_2flower_2ecompiler_2flower_3alowering_2etop(ptr %v0, ptr %t70)
  store %"compiler/lower:level" %t72, ptr %l44
  br label %bb16
bb15:
  store i1 false, ptr %l42, !tbaa !21
  br label %bb20
bb16:
  %t73 = getelementptr %"compiler/lower:level", ptr %l44, i32 0, i32 1
  %t74 = load i32, ptr %t73, !tbaa !23
  store i32 %t74, ptr %l45, !tbaa !23
  %t75 = load ptr, ptr %l1, !tbaa !29
  %t77 = getelementptr %"compiler/typed:Arm", ptr %t75, i32 0, i32 3
  %t78 = load ptr, ptr %t77, !tbaa !29
  %t80 = icmp eq ptr %t78, null
  br i1 %t80, label %bb17, label %bb18
bb17:
  call void @__olang_check_failed(ptr @olang_loc_2262f7260befbeda_ad33d1a86099f68e)
  unreachable
bb18:
  br label %bb19
bb19:
  %t82 = load ptr, ptr %l1, !tbaa !29
  %t84 = getelementptr %"compiler/typed:Arm", ptr %t82, i32 0, i32 3
  %t85 = load ptr, ptr %t84, !tbaa !29
  %t88 = getelementptr %"compiler/typed:Block", ptr %t85, i32 0, i32 0
  %t89 = load i32, ptr %t88, !tbaa !23
  %t90 = load i32, ptr %l45, !tbaa !23
  %t92 = icmp eq i32 %t90, %t89
  store i1 %t92, ptr %l42, !tbaa !21
  br label %bb20
bb20:
  %t94 = load i1, ptr %l42, !tbaa !21
  br i1 %t94, label %bb21, label %bb22
bb21:
  %t95 = load ptr, ptr %l1, !tbaa !29
  %t97 = getelementptr %"compiler/typed:Arm", ptr %t95, i32 0, i32 3
  %t98 = load ptr, ptr %t97, !tbaa !29
  %t100 = icmp eq ptr %t98, null
  br i1 %t100, label %bb23, label %bb24
bb22:
  br label %bb42
bb23:
  call void @__olang_check_failed(ptr @olang_loc_78466967dd42e061_bdc585e3e8213235)
  unreachable
bb24:
  br label %bb25
bb25:
  %t102 = load ptr, ptr %l1, !tbaa !29
  %t104 = getelementptr %"compiler/typed:Arm", ptr %t102, i32 0, i32 3
  %t105 = load ptr, ptr %t104, !tbaa !29
  %t108 = getelementptr %"compiler/typed:Block", ptr %t105, i32 0, i32 1
  %t109 = load { i64, ptr }, ptr %t108, !tbaa !27
  store { i64, ptr } %t109, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t111 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t113 = extractvalue { i64, ptr } %t111, 0
  store i64 %t113, ptr %l6, !tbaa !24
  br label %bb26
bb26:
  store %olang.scope zeroinitializer, ptr %s5
  %t115 = load i64, ptr %l5, !tbaa !24
  %t116 = load i64, ptr %l6, !tbaa !24
  %t119 = icmp slt i64 %t115, %t116
  %t121 = xor i1 %t119, true
  br i1 %t121, label %bb27, label %bb28
bb27:
  call void @__olang_scope_close(ptr %s5)
  br label %bb32
bb28:
  br label %bb29
bb29:
  %t123 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t123, ptr %l67, !tbaa !27
  %t124 = load i64, ptr %l5, !tbaa !24
  %t126 = getelementptr { i64, ptr }, ptr %l67, i32 0, i32 1
  %t127 = load ptr, ptr %t126, !tbaa !27
  %t128 = getelementptr ptr, ptr %t127, i64 %t124
  %t129 = load ptr, ptr %t128, !tbaa !39
  %t131 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estmt(ptr %v0, ptr %v1, ptr %t131, ptr %t129)
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s5)
  br label %bb31
bb31:
  %t135 = load i64, ptr %l5, !tbaa !24
  %t137 = add i64 %t135, 1
  store i64 %t137, ptr %l5, !tbaa !24
  br label %bb26
bb32:
  %t139 = load ptr, ptr %l1, !tbaa !29
  %t141 = getelementptr %"compiler/typed:Arm", ptr %t139, i32 0, i32 4
  %t142 = load ptr, ptr %t141, !tbaa !29
  %t144 = icmp eq ptr %t142, null
  %t146 = xor i1 %t144, true
  br i1 %t146, label %bb33, label %bb34
bb33:
  %t148 = load i32, ptr %l2, !tbaa !23
  %t149 = load i32, ptr @G_2ecompiler_2fmir_2eNoLocal, !tbaa !23
  %t152 = icmp ne i32 %t148, %t149
  store i1 %t152, ptr %l78, !tbaa !21
  br label %bb35
bb34:
  store i1 false, ptr %l78, !tbaa !21
  br label %bb35
bb35:
  %t154 = load i1, ptr %l78, !tbaa !21
  br i1 %t154, label %bb36, label %bb37
bb36:
  store %olang.scope zeroinitializer, ptr %s7
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t156 = load ptr, ptr %l1, !tbaa !29
  %t158 = getelementptr %"compiler/typed:Arm", ptr %t156, i32 0, i32 4
  %t159 = load ptr, ptr %t158, !tbaa !29
  %t162 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v1, ptr %t155, ptr %t159)
  store { i64, [4 x i64] } %t162, ptr %l85
  br label %bb38
bb37:
  br label %bb41
bb38:
  %t163 = load { i64, [4 x i64] }, ptr %l85
  store { i64, [4 x i64] } %t163, ptr %l8
  %t164 = load ptr, ptr %l0, !tbaa !29
  store ptr %t164, ptr %l86, !tbaa !29
  %t165 = load ptr, ptr %l1, !tbaa !29
  %t167 = getelementptr %"compiler/typed:Arm", ptr %t165, i32 0, i32 0
  %t168 = load %"compiler/source:Span", ptr %t167
  store %"compiler/source:Span" %t168, ptr %l88
  %t169 = load i32, ptr %l2, !tbaa !23
  %t171 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t169)
  store %"compiler/mir:Place" %t171, ptr %l90
  br label %bb39
bb39:
  %t172 = load { i64, [4 x i64] }, ptr %l8
  store { i64, [15 x i64] } zeroinitializer, ptr %t173
  %t174 = getelementptr { i64, [15 x i64] }, ptr %t173, i32 0, i32 0
  store i64 0, ptr %t174
  %t176 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t172, 0
  %t177 = getelementptr { i64, [15 x i64] }, ptr %t173, i32 0, i32 1
  store { { i64, [4 x i64] } } %t176, ptr %t177
  %t178 = load { i64, [15 x i64] }, ptr %t173
  store { i64, [21 x i64] } zeroinitializer, ptr %t179
  %t180 = getelementptr { i64, [21 x i64] }, ptr %t179, i32 0, i32 0
  store i64 0, ptr %t180
  %t181 = load %"compiler/source:Span", ptr %l88
  %t182 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t181, 0
  %t183 = load %"compiler/mir:Place", ptr %l90
  %t184 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t182, %"compiler/mir:Place" %t183, 1
  %t186 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t184, { i64, [15 x i64] } %t178, 2
  %t187 = getelementptr { i64, [21 x i64] }, ptr %t179, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t186, ptr %t187
  %t188 = load { i64, [21 x i64] }, ptr %t179
  %t190 = call ptr @__olang_scope_alloc_a(ptr %s7, i64 176, i64 8)
  store { i64, [21 x i64] } %t188, ptr %t190
  %t191 = load ptr, ptr %l86, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s7, ptr %t191, ptr %t190)
  br label %bb40
bb40:
  call void @__olang_scope_close(ptr %s7)
  br label %bb41
bb41:
  br label %ret
bb42:
  %t193 = load ptr, ptr %l0, !tbaa !29
  store ptr %t193, ptr %l95, !tbaa !29
  %t194 = load ptr, ptr %l1, !tbaa !29
  %t196 = getelementptr %"compiler/typed:Arm", ptr %t194, i32 0, i32 3
  %t197 = load ptr, ptr %t196, !tbaa !29
  %t199 = icmp eq ptr %t197, null
  br i1 %t199, label %bb43, label %bb44
bb43:
  call void @__olang_check_failed(ptr @olang_loc_6143a96035d3ceac_ef612191f7538720)
  unreachable
bb44:
  br label %bb45
bb45:
  %t201 = load ptr, ptr %l1, !tbaa !29
  %t203 = getelementptr %"compiler/typed:Arm", ptr %t201, i32 0, i32 3
  %t204 = load ptr, ptr %t203, !tbaa !29
  %t205 = load ptr, ptr %l95, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eopenBlock(ptr %v0, ptr %v1, ptr %t205, ptr %t204, i32 1, i32 0)
  br label %bb46
bb46:
  %t208 = load ptr, ptr %l1, !tbaa !29
  %t210 = getelementptr %"compiler/typed:Arm", ptr %t208, i32 0, i32 3
  %t211 = load ptr, ptr %t210, !tbaa !29
  %t213 = icmp eq ptr %t211, null
  br i1 %t213, label %bb47, label %bb48
bb47:
  call void @__olang_check_failed(ptr @olang_loc_9919e1798def049b_eb223155b689b93f)
  unreachable
bb48:
  br label %bb49
bb49:
  %t215 = load ptr, ptr %l1, !tbaa !29
  %t217 = getelementptr %"compiler/typed:Arm", ptr %t215, i32 0, i32 3
  %t218 = load ptr, ptr %t217, !tbaa !29
  %t221 = getelementptr %"compiler/typed:Block", ptr %t218, i32 0, i32 1
  %t222 = load { i64, ptr }, ptr %t221, !tbaa !27
  store { i64, ptr } %t222, ptr %l9, !tbaa !27
  store i64 0, ptr %l10, !tbaa !24
  %t224 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t226 = extractvalue { i64, ptr } %t224, 0
  store i64 %t226, ptr %l11, !tbaa !24
  br label %bb50
bb50:
  store %olang.scope zeroinitializer, ptr %s9
  %t228 = load i64, ptr %l10, !tbaa !24
  %t229 = load i64, ptr %l11, !tbaa !24
  %t232 = icmp slt i64 %t228, %t229
  %t234 = xor i1 %t232, true
  br i1 %t234, label %bb51, label %bb52
bb51:
  call void @__olang_scope_close(ptr %s9)
  br label %bb56
bb52:
  br label %bb53
bb53:
  %t236 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t236, ptr %l115, !tbaa !27
  %t237 = load i64, ptr %l10, !tbaa !24
  %t239 = getelementptr { i64, ptr }, ptr %l115, i32 0, i32 1
  %t240 = load ptr, ptr %t239, !tbaa !27
  %t241 = getelementptr ptr, ptr %t240, i64 %t237
  %t242 = load ptr, ptr %t241, !tbaa !39
  %t244 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estmt(ptr %v0, ptr %v1, ptr %t244, ptr %t242)
  br label %bb54
bb54:
  call void @__olang_scope_close(ptr %s9)
  br label %bb55
bb55:
  %t248 = load i64, ptr %l10, !tbaa !24
  %t250 = add i64 %t248, 1
  store i64 %t250, ptr %l10, !tbaa !24
  br label %bb50
bb56:
  %t252 = load ptr, ptr %l1, !tbaa !29
  %t254 = getelementptr %"compiler/typed:Arm", ptr %t252, i32 0, i32 4
  %t255 = load ptr, ptr %t254, !tbaa !29
  %t257 = icmp eq ptr %t255, null
  %t259 = xor i1 %t257, true
  br i1 %t259, label %bb57, label %bb58
bb57:
  %t261 = load i32, ptr %l2, !tbaa !23
  %t262 = load i32, ptr @G_2ecompiler_2fmir_2eNoLocal, !tbaa !23
  %t265 = icmp ne i32 %t261, %t262
  store i1 %t265, ptr %l126, !tbaa !21
  br label %bb59
bb58:
  store i1 false, ptr %l126, !tbaa !21
  br label %bb59
bb59:
  %t267 = load i1, ptr %l126, !tbaa !21
  br i1 %t267, label %bb60, label %bb61
bb60:
  store %olang.scope zeroinitializer, ptr %s11
  %t268 = load ptr, ptr %l0, !tbaa !29
  %t269 = load ptr, ptr %l1, !tbaa !29
  %t271 = getelementptr %"compiler/typed:Arm", ptr %t269, i32 0, i32 4
  %t272 = load ptr, ptr %t271, !tbaa !29
  %t275 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v1, ptr %t268, ptr %t272)
  store { i64, [4 x i64] } %t275, ptr %l133
  br label %bb62
bb61:
  br label %bb65
bb62:
  %t276 = load { i64, [4 x i64] }, ptr %l133
  store { i64, [4 x i64] } %t276, ptr %l13
  %t277 = load ptr, ptr %l0, !tbaa !29
  store ptr %t277, ptr %l134, !tbaa !29
  %t278 = load ptr, ptr %l1, !tbaa !29
  %t280 = getelementptr %"compiler/typed:Arm", ptr %t278, i32 0, i32 0
  %t281 = load %"compiler/source:Span", ptr %t280
  store %"compiler/source:Span" %t281, ptr %l136
  %t282 = load i32, ptr %l2, !tbaa !23
  %t284 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t282)
  store %"compiler/mir:Place" %t284, ptr %l138
  br label %bb63
bb63:
  %t285 = load { i64, [4 x i64] }, ptr %l13
  store { i64, [15 x i64] } zeroinitializer, ptr %t286
  %t287 = getelementptr { i64, [15 x i64] }, ptr %t286, i32 0, i32 0
  store i64 0, ptr %t287
  %t289 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t285, 0
  %t290 = getelementptr { i64, [15 x i64] }, ptr %t286, i32 0, i32 1
  store { { i64, [4 x i64] } } %t289, ptr %t290
  %t291 = load { i64, [15 x i64] }, ptr %t286
  store { i64, [21 x i64] } zeroinitializer, ptr %t292
  %t293 = getelementptr { i64, [21 x i64] }, ptr %t292, i32 0, i32 0
  store i64 0, ptr %t293
  %t294 = load %"compiler/source:Span", ptr %l136
  %t295 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t294, 0
  %t296 = load %"compiler/mir:Place", ptr %l138
  %t297 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t295, %"compiler/mir:Place" %t296, 1
  %t299 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t297, { i64, [15 x i64] } %t291, 2
  %t300 = getelementptr { i64, [21 x i64] }, ptr %t292, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t299, ptr %t300
  %t301 = load { i64, [21 x i64] }, ptr %t292
  %t303 = call ptr @__olang_scope_alloc_a(ptr %s11, i64 176, i64 8)
  store { i64, [21 x i64] } %t301, ptr %t303
  %t304 = load ptr, ptr %l134, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s11, ptr %t304, ptr %t303)
  br label %bb64
bb64:
  call void @__olang_scope_close(ptr %s11)
  br label %bb65
bb65:
  %t306 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2ecloseBlock(ptr %v0, ptr %t306)
  br label %bb66
bb66:
  br label %ret
ret:
  ret void
}

define dso_local { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2earrayCopy(ptr %v0, ptr %a0, { i64, [4 x i64] } %a1, i32 %a2, %"compiler/source:Span" %a3, { i64, [1 x i64] } %a4) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca { i64, [4 x i64] }
  %l8 = alloca i32
  %l9 = alloca i32
  %l16 = alloca i32
  %l17 = alloca ptr
  %l18 = alloca i32
  %l19 = alloca i32
  %l21 = alloca %"compiler/mir:Place"
  %l27 = alloca { i64, [4 x i64] }
  %l31 = alloca i32
  %l32 = alloca ptr
  %l35 = alloca i32
  %l36 = alloca i32
  %l37 = alloca ptr
  %l38 = alloca %"compiler/source:Span"
  %l40 = alloca %"compiler/mir:Place"
  %l49 = alloca ptr
  %l50 = alloca %"compiler/source:Span"
  %l52 = alloca %"compiler/mir:Place"
  %l54 = alloca %"compiler/mir:Place"
  %l59 = alloca %"compiler/mir:Place"
  %s0 = alloca %olang.scope
  %rv = alloca { i64, [4 x i64] }
  %t21 = alloca { i64, [4 x i64] }, align 8
  %t76 = alloca { i64, [4 x i64] }, align 8
  %t83 = alloca { i64, [15 x i64] }, align 8
  %t95 = alloca { i64, [21 x i64] }, align 8
  %t118 = alloca { i64, [21 x i64] }, align 8
  %t137 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  store %"compiler/source:Span" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l5, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = load i32, ptr %l2, !tbaa !23
  %t9 = load %"compiler/source:Span", ptr %l3
  %t14 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2elocal(ptr %v0, ptr %t6, { i64, [4 x i64] } %a1, i32 %t8, %"compiler/source:Span" %t9)
  store i32 %t14, ptr %l16
  br label %bb1
bb1:
  %t15 = load i32, ptr %l16, !tbaa !23
  store i32 %t15, ptr %l6, !tbaa !23
  %t16 = load ptr, ptr %l0, !tbaa !29
  store ptr %t16, ptr %l17, !tbaa !29
  store i32 22, ptr %l18
  %t17 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  store i32 %t17, ptr %l19, !tbaa !23
  %t18 = load i32, ptr %l6, !tbaa !23
  %t20 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t18)
  store %"compiler/mir:Place" %t20, ptr %l21
  br label %bb2
bb2:
  store { i64, [4 x i64] } zeroinitializer, ptr %t21
  %t22 = getelementptr { i64, [4 x i64] }, ptr %t21, i32 0, i32 0
  store i64 1, ptr %t22
  %t23 = load %"compiler/mir:Place", ptr %l21
  %t24 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t23, 0
  %t25 = getelementptr { i64, [4 x i64] }, ptr %t21, i32 0, i32 1
  store { %"compiler/mir:Place" } %t24, ptr %t25
  %t26 = load { i64, [4 x i64] }, ptr %t21
  %t28 = insertvalue [1 x { i64, [4 x i64] }] undef, { i64, [4 x i64] } %t26, 0
  %t30 = load ptr, ptr @__olang_prog_scope
  %t31 = call ptr @__olang_scope_alloc(ptr %t30, i64 40)
  store [1 x { i64, [4 x i64] }] %t28, ptr %t31
  %t32 = insertvalue { i64, ptr } undef, i64 1, 0
  %t33 = insertvalue { i64, ptr } %t32, ptr %t31, 1
  %t35 = extractvalue { i64, ptr } %t33, 0
  %t36 = extractvalue { i64, ptr } %t33, 1
  %t37 = mul i64 %t35, 40
  %t38 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t37)
  call void @llvm.memcpy.p0.p0.i64(ptr %t38, ptr %t36, i64 %t37, i1 false)
  %t39 = insertvalue { i64, ptr } undef, i64 %t35, 0
  %t40 = insertvalue { i64, ptr } %t39, ptr %t38, 1
  %t41 = load %"compiler/source:Span", ptr %l3
  %t42 = load ptr, ptr %l17, !tbaa !29
  %t43 = load i32, ptr %l18
  %t44 = load i32, ptr %l19, !tbaa !23
  %t47 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s0, ptr %t42, i32 %t43, i32 %t44, { i64, ptr } %t40, %"compiler/source:Span" %t41)
  store { i64, [4 x i64] } %t47, ptr %l27
  br label %bb3
bb3:
  %t48 = load { i64, [4 x i64] }, ptr %l27
  store { i64, [4 x i64] } %t48, ptr %l7
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t50 = load i32, ptr %l2, !tbaa !23
  %t51 = load %"compiler/source:Span", ptr %l3
  %t55 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2etemp(ptr %v0, ptr %t49, i32 %t50, %"compiler/source:Span" %t51)
  store i32 %t55, ptr %l31
  br label %bb4
bb4:
  %t56 = load i32, ptr %l31, !tbaa !23
  store i32 %t56, ptr %l8, !tbaa !23
  %t57 = load ptr, ptr %l5, !tbaa !29
  store ptr %t57, ptr %l32, !tbaa !29
  %t58 = load ptr, ptr %l5, !tbaa !29
  %t59 = load i32, ptr %l2, !tbaa !23
  %t62 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t58, i32 %t59)
  store i32 %t62, ptr %l35
  br label %bb5
bb5:
  %t63 = load ptr, ptr %l32, !tbaa !29
  %t64 = load i32, ptr %l35, !tbaa !23
  %t65 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t63, i32 %t64)
  store i32 %t65, ptr %l36
  br label %bb6
bb6:
  %t66 = load i32, ptr %l36, !tbaa !23
  store i32 %t66, ptr %l9, !tbaa !23
  %t67 = load ptr, ptr %l0, !tbaa !29
  store ptr %t67, ptr %l37, !tbaa !29
  %t68 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t68, ptr %l38
  %t69 = load i32, ptr %l8, !tbaa !23
  %t71 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t69)
  store %"compiler/mir:Place" %t71, ptr %l40
  br label %bb7
bb7:
  %t73 = load i32, ptr %l2, !tbaa !23
  %t74 = load { i64, [4 x i64] }, ptr %l7
  %t75 = load i32, ptr %l9, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t76
  %t77 = getelementptr { i64, [4 x i64] }, ptr %t76, i32 0, i32 0
  store i64 2, ptr %t77
  %t79 = insertvalue { i32, i64 } undef, i32 %t75, 0
  %t80 = insertvalue { i32, i64 } %t79, i64 0, 1
  %t81 = getelementptr { i64, [4 x i64] }, ptr %t76, i32 0, i32 1
  store { i32, i64 } %t80, ptr %t81
  %t82 = load { i64, [4 x i64] }, ptr %t76
  store { i64, [15 x i64] } zeroinitializer, ptr %t83
  %t84 = getelementptr { i64, [15 x i64] }, ptr %t83, i32 0, i32 0
  store i64 8, ptr %t84
  %t86 = insertvalue { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } } undef, { i64, [1 x i64] } %a4, 0
  %t88 = insertvalue { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } } %t86, i32 %t73, 1
  %t90 = insertvalue { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } } %t88, { i64, [4 x i64] } %t74, 2
  %t92 = insertvalue { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } } %t90, { i64, [4 x i64] } %t82, 3
  %t93 = getelementptr { i64, [15 x i64] }, ptr %t83, i32 0, i32 1
  store { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } } %t92, ptr %t93
  %t94 = load { i64, [15 x i64] }, ptr %t83
  store { i64, [21 x i64] } zeroinitializer, ptr %t95
  %t96 = getelementptr { i64, [21 x i64] }, ptr %t95, i32 0, i32 0
  store i64 0, ptr %t96
  %t97 = load %"compiler/source:Span", ptr %l38
  %t98 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t97, 0
  %t99 = load %"compiler/mir:Place", ptr %l40
  %t100 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t98, %"compiler/mir:Place" %t99, 1
  %t102 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t100, { i64, [15 x i64] } %t94, 2
  %t103 = getelementptr { i64, [21 x i64] }, ptr %t95, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t102, ptr %t103
  %t104 = load { i64, [21 x i64] }, ptr %t95
  %t106 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t104, ptr %t106
  %t107 = load ptr, ptr %l37, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s0, ptr %t107, ptr %t106)
  br label %bb8
bb8:
  %t109 = load ptr, ptr %l0, !tbaa !29
  store ptr %t109, ptr %l49, !tbaa !29
  %t110 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t110, ptr %l50
  %t111 = load i32, ptr %l8, !tbaa !23
  %t113 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t111)
  store %"compiler/mir:Place" %t113, ptr %l52
  br label %bb9
bb9:
  %t114 = load i32, ptr %l6, !tbaa !23
  %t116 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t114)
  store %"compiler/mir:Place" %t116, ptr %l54
  br label %bb10
bb10:
  %t117 = load { i64, [4 x i64] }, ptr %l7
  store { i64, [21 x i64] } zeroinitializer, ptr %t118
  %t119 = getelementptr { i64, [21 x i64] }, ptr %t118, i32 0, i32 0
  store i64 10, ptr %t119
  %t120 = load %"compiler/source:Span", ptr %l50
  %t121 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", %"compiler/mir:Place", { i64, [4 x i64] } } undef, %"compiler/source:Span" %t120, 0
  %t122 = load %"compiler/mir:Place", ptr %l52
  %t123 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", %"compiler/mir:Place", { i64, [4 x i64] } } %t121, %"compiler/mir:Place" %t122, 1
  %t124 = load %"compiler/mir:Place", ptr %l54
  %t125 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", %"compiler/mir:Place", { i64, [4 x i64] } } %t123, %"compiler/mir:Place" %t124, 2
  %t127 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", %"compiler/mir:Place", { i64, [4 x i64] } } %t125, { i64, [4 x i64] } %t117, 3
  %t128 = getelementptr { i64, [21 x i64] }, ptr %t118, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Place", %"compiler/mir:Place", { i64, [4 x i64] } } %t127, ptr %t128
  %t129 = load { i64, [21 x i64] }, ptr %t118
  %t131 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t129, ptr %t131
  %t132 = load ptr, ptr %l49, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s0, ptr %t132, ptr %t131)
  br label %bb11
bb11:
  %t134 = load i32, ptr %l8, !tbaa !23
  %t136 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t134)
  store %"compiler/mir:Place" %t136, ptr %l59
  br label %bb12
bb12:
  store { i64, [4 x i64] } zeroinitializer, ptr %t137
  %t138 = getelementptr { i64, [4 x i64] }, ptr %t137, i32 0, i32 0
  store i64 1, ptr %t138
  %t139 = load %"compiler/mir:Place", ptr %l59
  %t140 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t139, 0
  %t141 = getelementptr { i64, [4 x i64] }, ptr %t137, i32 0, i32 1
  store { %"compiler/mir:Place" } %t140, ptr %t141
  %t142 = load { i64, [4 x i64] }, ptr %t137
  call void @__olang_scope_close(ptr %s0)
  store { i64, [4 x i64] } %t142, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2earrayLit(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, [4 x i64] }
  %l8 = alloca i32
  %l9 = alloca i32
  %l10 = alloca i1
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l22 = alloca i32
  %l32 = alloca { i64, ptr }
  %l38 = alloca i64
  %l40 = alloca ptr
  %l41 = alloca i32
  %l42 = alloca i32
  %l46 = alloca %"compiler/mir:Range"
  %l49 = alloca { i64, [4 x i64] }
  %l50 = alloca ptr
  %l53 = alloca i32
  %l54 = alloca i1
  %l57 = alloca ptr
  %l58 = alloca i32
  %l62 = alloca { i64, [1 x i64] }
  %l67 = alloca { i64, [4 x i64] }
  %l70 = alloca i32
  %l74 = alloca i32
  %l75 = alloca ptr
  %l76 = alloca %"compiler/source:Span"
  %l78 = alloca %"compiler/mir:Place"
  %l82 = alloca { i64, [1 x i64] }
  %l83 = alloca i32
  %l87 = alloca { i64, [4 x i64] }
  %l93 = alloca ptr
  %l96 = alloca i32
  %l97 = alloca i1
  %l103 = alloca i64
  %l106 = alloca i64
  %l125 = alloca ptr
  %l127 = alloca { i64, [2 x i64] }
  %l129 = alloca { i64, ptr }
  %l141 = alloca %"compiler/mir:Place"
  %l153 = alloca %"compiler/mir:Place"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca { i64, [4 x i64] }
  %t22 = alloca { i64, [4 x i64] }, align 8
  %t40 = alloca { i64, [4 x i64] }, align 8
  %t62 = alloca { i64, [15 x i64] }, align 8
  %t104 = alloca { i64, [15 x i64] }, align 8
  %t157 = alloca { i64, [4 x i64] }, align 8
  %t164 = alloca { i64, [15 x i64] }, align 8
  %t176 = alloca { i64, [21 x i64] }, align 8
  %t254 = alloca { i64, [2 x i64] }, align 8
  %t262 = alloca { i64, [1 x i64] }, align 8
  %t266 = alloca { i64, [1 x i64] }, align 8
  %t290 = alloca { i64, [1 x i64] }, align 8
  %t325 = alloca { i64, [15 x i64] }, align 8
  %t331 = alloca { i64, [21 x i64] }, align 8
  %t352 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  store %"compiler/source:Span" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t7 = load i32, ptr %l2, !tbaa !23
  %t10 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2earrayOf(ptr %v0, ptr %t6, i32 %t7)
  store i32 %t10, ptr %l22
  br label %bb1
bb1:
  %t11 = load i32, ptr %l22, !tbaa !23
  store i32 %t11, ptr %l5, !tbaa !23
  %t12 = load i32, ptr %l5, !tbaa !23
  %t13 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t16 = icmp eq i32 %t12, %t13
  br i1 %t16, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t19 = load %"compiler/source:Span", ptr %l3
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2egap(ptr %v0, ptr %s1, ptr %t18, %"compiler/source:Span" %t19, { i64, ptr } { i64 43, ptr @.d7 })
  br label %bb4
bb3:
  br label %bb5
bb4:
  store { i64, [4 x i64] } zeroinitializer, ptr %t22
  %t23 = getelementptr { i64, [4 x i64] }, ptr %t22, i32 0, i32 0
  store i64 0, ptr %t23
  %t24 = load { i64, [4 x i64] }, ptr %t22
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  store { i64, [4 x i64] } %t24, ptr %rv
  br label %ret
bb5:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t27 = load ptr, ptr %l1, !tbaa !29
  %t29 = getelementptr %"compiler/typed:Make", ptr %t27, i32 0, i32 2
  %t30 = load { i64, ptr }, ptr %t29, !tbaa !27
  %t33 = call { i64, ptr } @compiler_2flower_2ecompiler_2flower_3alowering_2evals(ptr %v0, ptr %v1, ptr %s0, ptr %t26, { i64, ptr } %t30)
  store { i64, ptr } %t33, ptr %l32
  br label %bb6
bb6:
  %t34 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t34, ptr %l6, !tbaa !27
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/lower:lowering", ptr %t35, i32 0, i32 7
  %t38 = load i1, ptr %t37, !tbaa !21
  br i1 %t38, label %bb7, label %bb8
bb7:
  store { i64, [4 x i64] } zeroinitializer, ptr %t40
  %t41 = getelementptr { i64, [4 x i64] }, ptr %t40, i32 0, i32 0
  store i64 0, ptr %t41
  %t42 = load { i64, [4 x i64] }, ptr %t40
  call void @__olang_scope_close(ptr %s0)
  store { i64, [4 x i64] } %t42, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t45 = load i32, ptr %l5, !tbaa !23
  %t48 = call i64 @compiler_2flower_2ecompiler_2flower_3alowering_2efixedLen(ptr %v0, ptr %t44, i32 %t45)
  store i64 %t48, ptr %l38
  br label %bb10
bb10:
  %t49 = load i64, ptr %l38, !tbaa !24
  %t50 = icmp sge i64 %t49, 0
  br i1 %t50, label %bb11, label %bb12
bb11:
  %t52 = load ptr, ptr %l0, !tbaa !29
  store ptr %t52, ptr %l40, !tbaa !29
  %t53 = load i32, ptr %l5, !tbaa !23
  store i32 %t53, ptr %l41, !tbaa !23
  %t54 = load i32, ptr %l5, !tbaa !23
  store i32 %t54, ptr %l42, !tbaa !23
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/lower:lowering", ptr %t55, i32 0, i32 3
  %t58 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t61 = call %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eArgs(ptr %v0, ptr %s0, ptr %t57, { i64, ptr } %t58)
  store %"compiler/mir:Range" %t61, ptr %l46
  br label %bb13
bb12:
  br label %bb22
bb13:
  store { i64, [15 x i64] } zeroinitializer, ptr %t62
  %t63 = getelementptr { i64, [15 x i64] }, ptr %t62, i32 0, i32 0
  store i64 6, ptr %t63
  %t64 = load i32, ptr %l42, !tbaa !23
  %t65 = insertvalue { i32, i64, %"compiler/mir:Range" } undef, i32 %t64, 0
  %t66 = insertvalue { i32, i64, %"compiler/mir:Range" } %t65, i64 0, 1
  %t67 = load %"compiler/mir:Range", ptr %l46
  %t68 = insertvalue { i32, i64, %"compiler/mir:Range" } %t66, %"compiler/mir:Range" %t67, 2
  %t69 = getelementptr { i64, [15 x i64] }, ptr %t62, i32 0, i32 1
  store { i32, i64, %"compiler/mir:Range" } %t68, ptr %t69
  %t70 = load { i64, [15 x i64] }, ptr %t62
  %t71 = load %"compiler/source:Span", ptr %l3
  %t72 = load ptr, ptr %l40, !tbaa !29
  %t73 = load i32, ptr %l41, !tbaa !23
  %t76 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %t72, i32 %t73, { i64, [15 x i64] } %t70, %"compiler/source:Span" %t71)
  store { i64, [4 x i64] } %t76, ptr %l49
  br label %bb14
bb14:
  %t77 = load { i64, [4 x i64] }, ptr %l49
  store { i64, [4 x i64] } %t77, ptr %l7
  %t78 = load ptr, ptr %l4, !tbaa !29
  store ptr %t78, ptr %l50, !tbaa !29
  %t79 = load ptr, ptr %l4, !tbaa !29
  %t80 = load i32, ptr %l2, !tbaa !23
  %t83 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t79, i32 %t80)
  store i32 %t83, ptr %l53
  br label %bb15
bb15:
  %t84 = load ptr, ptr %l50, !tbaa !29
  %t85 = load i32, ptr %l53, !tbaa !23
  %t86 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t84, i32 %t85)
  store i1 %t86, ptr %l54
  br label %bb16
bb16:
  %t87 = load i1, ptr %l54, !tbaa !21
  %t88 = xor i1 %t87, true
  br i1 %t88, label %bb17, label %bb18
bb17:
  %t90 = load { i64, [4 x i64] }, ptr %l7
  call void @__olang_scope_close(ptr %s0)
  store { i64, [4 x i64] } %t90, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  %t92 = load ptr, ptr %l0, !tbaa !29
  store ptr %t92, ptr %l57, !tbaa !29
  %t93 = load i32, ptr %l2, !tbaa !23
  store i32 %t93, ptr %l58, !tbaa !23
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t95 = load ptr, ptr %l1, !tbaa !29
  %t97 = getelementptr %"compiler/typed:Make", ptr %t95, i32 0, i32 4
  %t98 = load i32, ptr %t97, !tbaa !23
  %t101 = call { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ebuilt(ptr %v0, ptr %t94, i32 %t98)
  store { i64, [1 x i64] } %t101, ptr %l62
  br label %bb20
bb20:
  %t102 = load { i64, [4 x i64] }, ptr %l7
  %t103 = load i32, ptr %l2, !tbaa !23
  store { i64, [15 x i64] } zeroinitializer, ptr %t104
  %t105 = getelementptr { i64, [15 x i64] }, ptr %t104, i32 0, i32 0
  store i64 7, ptr %t105
  %t106 = load { i64, [1 x i64] }, ptr %l62
  %t107 = insertvalue { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 } undef, { i64, [1 x i64] } %t106, 0
  %t109 = insertvalue { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 } %t107, { i64, [4 x i64] } %t102, 1
  %t111 = insertvalue { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 } %t109, i32 %t103, 2
  %t112 = getelementptr { i64, [15 x i64] }, ptr %t104, i32 0, i32 1
  store { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 } %t111, ptr %t112
  %t113 = load { i64, [15 x i64] }, ptr %t104
  %t114 = load %"compiler/source:Span", ptr %l3
  %t115 = load ptr, ptr %l57, !tbaa !29
  %t116 = load i32, ptr %l58, !tbaa !23
  %t119 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %t115, i32 %t116, { i64, [15 x i64] } %t113, %"compiler/source:Span" %t114)
  store { i64, [4 x i64] } %t119, ptr %l67
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s0)
  %t120 = load { i64, [4 x i64] }, ptr %l67
  store { i64, [4 x i64] } %t120, ptr %rv
  br label %ret
bb22:
  %t121 = load ptr, ptr %l4, !tbaa !29
  %t122 = load i32, ptr %l5, !tbaa !23
  %t125 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t121, i32 %t122)
  store i32 %t125, ptr %l70
  br label %bb23
bb23:
  %t126 = load i32, ptr %l70, !tbaa !23
  store i32 %t126, ptr %l8, !tbaa !23
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t128 = load i32, ptr %l2, !tbaa !23
  %t129 = load %"compiler/source:Span", ptr %l3
  %t133 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2etemp(ptr %v0, ptr %t127, i32 %t128, %"compiler/source:Span" %t129)
  store i32 %t133, ptr %l74
  br label %bb24
bb24:
  %t134 = load i32, ptr %l74, !tbaa !23
  store i32 %t134, ptr %l9, !tbaa !23
  %t135 = load ptr, ptr %l0, !tbaa !29
  store ptr %t135, ptr %l75, !tbaa !29
  %t136 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t136, ptr %l76
  %t137 = load i32, ptr %l9, !tbaa !23
  %t139 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t137)
  store %"compiler/mir:Place" %t139, ptr %l78
  br label %bb25
bb25:
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t141 = load ptr, ptr %l1, !tbaa !29
  %t143 = getelementptr %"compiler/typed:Make", ptr %t141, i32 0, i32 4
  %t144 = load i32, ptr %t143, !tbaa !23
  %t147 = call { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2emadeAt(ptr %v0, ptr %t140, i32 %t144)
  store { i64, [1 x i64] } %t147, ptr %l82
  br label %bb26
bb26:
  %t148 = load i32, ptr %l2, !tbaa !23
  store i32 %t148, ptr %l83, !tbaa !23
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t150 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t152 = extractvalue { i64, ptr } %t150, 0
  %t155 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2econstI64(ptr %v0, ptr %t149, i64 %t152)
  store { i64, [4 x i64] } %t155, ptr %l87
  br label %bb27
bb27:
  %t156 = load i32, ptr %l8, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t157
  %t158 = getelementptr { i64, [4 x i64] }, ptr %t157, i32 0, i32 0
  store i64 2, ptr %t158
  %t160 = insertvalue { i32, i64 } undef, i32 %t156, 0
  %t161 = insertvalue { i32, i64 } %t160, i64 0, 1
  %t162 = getelementptr { i64, [4 x i64] }, ptr %t157, i32 0, i32 1
  store { i32, i64 } %t161, ptr %t162
  %t163 = load { i64, [4 x i64] }, ptr %t157
  store { i64, [15 x i64] } zeroinitializer, ptr %t164
  %t165 = getelementptr { i64, [15 x i64] }, ptr %t164, i32 0, i32 0
  store i64 8, ptr %t165
  %t166 = load { i64, [1 x i64] }, ptr %l82
  %t167 = insertvalue { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } } undef, { i64, [1 x i64] } %t166, 0
  %t168 = load i32, ptr %l83, !tbaa !23
  %t169 = insertvalue { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } } %t167, i32 %t168, 1
  %t170 = load { i64, [4 x i64] }, ptr %l87
  %t171 = insertvalue { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } } %t169, { i64, [4 x i64] } %t170, 2
  %t173 = insertvalue { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } } %t171, { i64, [4 x i64] } %t163, 3
  %t174 = getelementptr { i64, [15 x i64] }, ptr %t164, i32 0, i32 1
  store { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } } %t173, ptr %t174
  %t175 = load { i64, [15 x i64] }, ptr %t164
  store { i64, [21 x i64] } zeroinitializer, ptr %t176
  %t177 = getelementptr { i64, [21 x i64] }, ptr %t176, i32 0, i32 0
  store i64 0, ptr %t177
  %t178 = load %"compiler/source:Span", ptr %l76
  %t179 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t178, 0
  %t180 = load %"compiler/mir:Place", ptr %l78
  %t181 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t179, %"compiler/mir:Place" %t180, 1
  %t183 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t181, { i64, [15 x i64] } %t175, 2
  %t184 = getelementptr { i64, [21 x i64] }, ptr %t176, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t183, ptr %t184
  %t185 = load { i64, [21 x i64] }, ptr %t176
  %t187 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t185, ptr %t187
  %t188 = load ptr, ptr %l75, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s0, ptr %t188, ptr %t187)
  br label %bb28
bb28:
  %t190 = load ptr, ptr %l4, !tbaa !29
  store ptr %t190, ptr %l93, !tbaa !29
  %t191 = load ptr, ptr %l4, !tbaa !29
  %t192 = load i32, ptr %l2, !tbaa !23
  %t195 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t191, i32 %t192)
  store i32 %t195, ptr %l96
  br label %bb29
bb29:
  %t196 = load ptr, ptr %l93, !tbaa !29
  %t197 = load i32, ptr %l96, !tbaa !23
  %t198 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t196, i32 %t197)
  store i1 %t198, ptr %l97
  br label %bb30
bb30:
  %t199 = load i1, ptr %l97, !tbaa !21
  store i1 %t199, ptr %l10, !tbaa !21
  store i64 0, ptr %l11, !tbaa !24
  %t200 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t202 = extractvalue { i64, ptr } %t200, 0
  store i64 %t202, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t204 = load i64, ptr %l12, !tbaa !24
  %t205 = load i64, ptr %l11, !tbaa !24
  %t208 = icmp sgt i64 %t204, %t205
  br i1 %t208, label %bb31, label %bb32
bb31:
  %t210 = load i64, ptr %l13, !tbaa !24
  %t212 = icmp sgt i64 %t210, 0
  br i1 %t212, label %bb33, label %bb34
bb32:
  store i64 0, ptr %l103, !tbaa !24
  br label %bb36
bb33:
  %t214 = load i64, ptr %l12, !tbaa !24
  %t215 = load i64, ptr %l11, !tbaa !24
  %t218 = sub i64 %t214, %t215
  %t219 = load i64, ptr %l13, !tbaa !24
  %t222 = add i64 %t218, %t219
  %t224 = sub i64 %t222, 1
  %t225 = load i64, ptr %l13, !tbaa !24
  %t228 = sdiv i64 %t224, %t225
  store i64 %t228, ptr %l106, !tbaa !24
  br label %bb35
bb34:
  store i64 0, ptr %l106, !tbaa !24
  br label %bb35
bb35:
  %t230 = load i64, ptr %l106, !tbaa !24
  store i64 %t230, ptr %l103, !tbaa !24
  br label %bb36
bb36:
  %t231 = load i64, ptr %l103, !tbaa !24
  store i64 %t231, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb37
bb37:
  store %olang.scope zeroinitializer, ptr %s6
  %t232 = load i64, ptr %l15, !tbaa !24
  %t233 = load i64, ptr %l14, !tbaa !24
  %t236 = icmp slt i64 %t232, %t233
  %t238 = xor i1 %t236, true
  br i1 %t238, label %bb38, label %bb39
bb38:
  call void @__olang_scope_close(ptr %s6)
  br label %bb47
bb39:
  br label %bb40
bb40:
  %t240 = load i64, ptr %l11, !tbaa !24
  %t241 = load i64, ptr %l15, !tbaa !24
  %t242 = load i64, ptr %l13, !tbaa !24
  %t245 = mul i64 %t241, %t242
  %t248 = add i64 %t240, %t245
  store i64 %t248, ptr %l16, !tbaa !24
  %t250 = load ptr, ptr %l0, !tbaa !29
  %t252 = getelementptr %"compiler/lower:lowering", ptr %t250, i32 0, i32 3
  store ptr %t252, ptr %l125, !tbaa !29
  %t253 = load i32, ptr %l9, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t254
  %t255 = getelementptr { i64, [2 x i64] }, ptr %t254, i32 0, i32 0
  store i64 1, ptr %t255
  %t257 = insertvalue { i32 } undef, i32 %t253, 0
  %t258 = getelementptr { i64, [2 x i64] }, ptr %t254, i32 0, i32 1
  store { i32 } %t257, ptr %t258
  %t259 = load { i64, [2 x i64] }, ptr %t254
  store { i64, [2 x i64] } %t259, ptr %l127
  %t260 = load i1, ptr %l10, !tbaa !21
  br i1 %t260, label %bb41, label %bb42
bb41:
  store { i64, [1 x i64] } zeroinitializer, ptr %t262
  %t263 = getelementptr { i64, [1 x i64] }, ptr %t262, i32 0, i32 0
  store i64 3, ptr %t263
  %t264 = load { i64, [1 x i64] }, ptr %t262
  %t265 = load i64, ptr %l16, !tbaa !24
  store { i64, [1 x i64] } zeroinitializer, ptr %t266
  %t267 = getelementptr { i64, [1 x i64] }, ptr %t266, i32 0, i32 0
  store i64 2, ptr %t267
  %t269 = insertvalue { i64 } undef, i64 %t265, 0
  %t270 = getelementptr { i64, [1 x i64] }, ptr %t266, i32 0, i32 1
  store { i64 } %t269, ptr %t270
  %t271 = load { i64, [1 x i64] }, ptr %t266
  %t273 = insertvalue [2 x { i64, [1 x i64] }] undef, { i64, [1 x i64] } %t264, 0
  %t275 = insertvalue [2 x { i64, [1 x i64] }] %t273, { i64, [1 x i64] } %t271, 1
  %t277 = load ptr, ptr @__olang_prog_scope
  %t278 = call ptr @__olang_scope_alloc(ptr %t277, i64 32)
  store [2 x { i64, [1 x i64] }] %t275, ptr %t278
  %t279 = insertvalue { i64, ptr } undef, i64 2, 0
  %t280 = insertvalue { i64, ptr } %t279, ptr %t278, 1
  %t282 = extractvalue { i64, ptr } %t280, 0
  %t283 = extractvalue { i64, ptr } %t280, 1
  %t284 = mul i64 %t282, 16
  %t285 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t284)
  call void @llvm.memcpy.p0.p0.i64(ptr %t285, ptr %t283, i64 %t284, i1 false)
  %t286 = insertvalue { i64, ptr } undef, i64 %t282, 0
  %t287 = insertvalue { i64, ptr } %t286, ptr %t285, 1
  store { i64, ptr } %t287, ptr %l129, !tbaa !27
  br label %bb43
bb42:
  %t289 = load i64, ptr %l16, !tbaa !24
  store { i64, [1 x i64] } zeroinitializer, ptr %t290
  %t291 = getelementptr { i64, [1 x i64] }, ptr %t290, i32 0, i32 0
  store i64 2, ptr %t291
  %t293 = insertvalue { i64 } undef, i64 %t289, 0
  %t294 = getelementptr { i64, [1 x i64] }, ptr %t290, i32 0, i32 1
  store { i64 } %t293, ptr %t294
  %t295 = load { i64, [1 x i64] }, ptr %t290
  %t297 = insertvalue [1 x { i64, [1 x i64] }] undef, { i64, [1 x i64] } %t295, 0
  %t299 = load ptr, ptr @__olang_prog_scope
  %t300 = call ptr @__olang_scope_alloc(ptr %t299, i64 16)
  store [1 x { i64, [1 x i64] }] %t297, ptr %t300
  %t301 = insertvalue { i64, ptr } undef, i64 1, 0
  %t302 = insertvalue { i64, ptr } %t301, ptr %t300, 1
  %t304 = extractvalue { i64, ptr } %t302, 0
  %t305 = extractvalue { i64, ptr } %t302, 1
  %t306 = mul i64 %t304, 16
  %t307 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t306)
  call void @llvm.memcpy.p0.p0.i64(ptr %t307, ptr %t305, i64 %t306, i1 false)
  %t308 = insertvalue { i64, ptr } undef, i64 %t304, 0
  %t309 = insertvalue { i64, ptr } %t308, ptr %t307, 1
  store { i64, ptr } %t309, ptr %l129, !tbaa !27
  br label %bb43
bb43:
  %t311 = load ptr, ptr %l125, !tbaa !29
  %t312 = load { i64, [2 x i64] }, ptr %l127
  %t313 = load { i64, ptr }, ptr %l129, !tbaa !27
  %t314 = call %"compiler/mir:Place" @compiler_2fmir_2ecompiler_2fmir_3aFn_2ePlace(ptr %v0, ptr %s6, ptr %t311, { i64, [2 x i64] } %t312, { i64, ptr } %t313)
  store %"compiler/mir:Place" %t314, ptr %l141
  br label %bb44
bb44:
  %t315 = load %"compiler/mir:Place", ptr %l141
  %t316 = load ptr, ptr %l0, !tbaa !29
  %t317 = load %"compiler/source:Span", ptr %l3
  %t319 = load i64, ptr %l16, !tbaa !24
  %t321 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t322 = load ptr, ptr %t321, !tbaa !27
  %t323 = getelementptr { i64, [4 x i64] }, ptr %t322, i64 %t319
  %t324 = load { i64, [4 x i64] }, ptr %t323
  store { i64, [15 x i64] } zeroinitializer, ptr %t325
  %t326 = getelementptr { i64, [15 x i64] }, ptr %t325, i32 0, i32 0
  store i64 0, ptr %t326
  %t328 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t324, 0
  %t329 = getelementptr { i64, [15 x i64] }, ptr %t325, i32 0, i32 1
  store { { i64, [4 x i64] } } %t328, ptr %t329
  %t330 = load { i64, [15 x i64] }, ptr %t325
  store { i64, [21 x i64] } zeroinitializer, ptr %t331
  %t332 = getelementptr { i64, [21 x i64] }, ptr %t331, i32 0, i32 0
  store i64 0, ptr %t332
  %t334 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t317, 0
  %t336 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t334, %"compiler/mir:Place" %t315, 1
  %t338 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t336, { i64, [15 x i64] } %t330, 2
  %t339 = getelementptr { i64, [21 x i64] }, ptr %t331, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t338, ptr %t339
  %t340 = load { i64, [21 x i64] }, ptr %t331
  %t342 = call ptr @__olang_scope_alloc_a(ptr %s6, i64 176, i64 8)
  store { i64, [21 x i64] } %t340, ptr %t342
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s6, ptr %t316, ptr %t342)
  br label %bb45
bb45:
  call void @__olang_scope_close(ptr %s6)
  br label %bb46
bb46:
  %t345 = load i64, ptr %l15, !tbaa !24
  %t347 = add i64 %t345, 1
  store i64 %t347, ptr %l15, !tbaa !24
  br label %bb37
bb47:
  %t349 = load i32, ptr %l9, !tbaa !23
  %t351 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t349)
  store %"compiler/mir:Place" %t351, ptr %l153
  br label %bb48
bb48:
  store { i64, [4 x i64] } zeroinitializer, ptr %t352
  %t353 = getelementptr { i64, [4 x i64] }, ptr %t352, i32 0, i32 0
  store i64 1, ptr %t353
  %t354 = load %"compiler/mir:Place", ptr %l153
  %t355 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t354, 0
  %t356 = getelementptr { i64, [4 x i64] }, ptr %t352, i32 0, i32 1
  store { %"compiler/mir:Place" } %t355, ptr %t356
  %t357 = load { i64, [4 x i64] }, ptr %t352
  call void @__olang_scope_close(ptr %s0)
  store { i64, [4 x i64] } %t357, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local i32 @compiler_2flower_2ecompiler_2flower_3alowering_2earrayOf(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca i32
  %l8 = alloca i32
  %l11 = alloca i1
  %l12 = alloca ptr
  %l15 = alloca i32
  %l16 = alloca i32
  %l19 = alloca i32
  %l22 = alloca i32
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/lower:lowering", ptr %a0, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t6, i32 %a1)
  store i32 %t10, ptr %l8
  br label %bb1
bb1:
  %t11 = load i32, ptr %l8, !tbaa !23
  store i32 %t11, ptr %l3, !tbaa !23
  %t12 = load ptr, ptr %l2, !tbaa !29
  %t13 = load i32, ptr %l3, !tbaa !23
  %t16 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t12, i32 %t13)
  store i1 %t16, ptr %l11
  br label %bb2
bb2:
  %t17 = load i1, ptr %l11, !tbaa !21
  br i1 %t17, label %bb3, label %bb4
bb3:
  %t18 = load ptr, ptr %l2, !tbaa !29
  store ptr %t18, ptr %l12, !tbaa !29
  %t19 = load ptr, ptr %l2, !tbaa !29
  %t20 = load i32, ptr %l3, !tbaa !23
  %t23 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t19, i32 %t20)
  store i32 %t23, ptr %l15
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t24 = load ptr, ptr %l12, !tbaa !29
  %t25 = load i32, ptr %l15, !tbaa !23
  %t26 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t24, i32 %t25)
  store i32 %t26, ptr %l16
  br label %bb6
bb6:
  %t27 = load i32, ptr %l16, !tbaa !23
  store i32 %t27, ptr %l3, !tbaa !23
  br label %bb7
bb7:
  %t28 = load ptr, ptr %l2, !tbaa !29
  %t29 = load i32, ptr %l3, !tbaa !23
  %t32 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t28, i32 %t29)
  store i32 %t32, ptr %l19
  br label %bb8
bb8:
  %t33 = load i32, ptr %l19
  %t35 = trunc i64 19 to i32
  %t36 = icmp eq i32 %t33, %t35
  br i1 %t36, label %bb9, label %bb10
bb9:
  %t38 = load i32, ptr %l3, !tbaa !23
  store i32 %t38, ptr %l22, !tbaa !23
  br label %bb11
bb10:
  %t40 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t40, ptr %l22, !tbaa !23
  br label %bb11
bb11:
  %t42 = load i32, ptr %l22, !tbaa !23
  store i32 %t42, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2earrayStore(ptr %v0, ptr %a0, %"compiler/mir:Place" %a1, { i64, [4 x i64] } %a2, i32 %a3, i1 %a4, %"compiler/source:Span" %a5, { i64, [1 x i64] } %a6) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/mir:Place"
  %l3 = alloca i32
  %l5 = alloca %"compiler/source:Span"
  %l7 = alloca i32
  %l8 = alloca { i64, [4 x i64] }
  %l9 = alloca { i64, [4 x i64] }
  %l10 = alloca { i64, [4 x i64] }
  %l11 = alloca i32
  %l12 = alloca i32
  %l13 = alloca i32
  %l19 = alloca i32
  %l29 = alloca { i64, [4 x i64] }
  %l30 = alloca ptr
  %l31 = alloca i32
  %l32 = alloca i32
  %l34 = alloca %"compiler/mir:Place"
  %l40 = alloca { i64, [4 x i64] }
  %l50 = alloca { i64, [4 x i64] }
  %l53 = alloca i32
  %l56 = alloca i32
  %l59 = alloca i32
  %l67 = alloca ptr
  %l68 = alloca %"compiler/source:Span"
  %l69 = alloca %"compiler/mir:Place"
  %l71 = alloca %"compiler/mir:Place"
  %l80 = alloca { i64, [4 x i64] }
  %l81 = alloca ptr
  %l83 = alloca %"compiler/mir:Place"
  %l88 = alloca { i64, [4 x i64] }
  %l90 = alloca %"compiler/mir:Place"
  %s0 = alloca %olang.scope
  %t14 = alloca { i64, [4 x i64] }, align 8
  %t47 = alloca { i64, [4 x i64] }, align 8
  %t125 = alloca { i64, [7 x i64] }, align 8
  %t148 = alloca { i64, [21 x i64] }, align 8
  %t181 = alloca { i64, [4 x i64] }, align 8
  %t197 = alloca { i64, [4 x i64] }, align 8
  %t209 = alloca { i64, [15 x i64] }, align 8
  %t215 = alloca { i64, [21 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/mir:Place" %a1, ptr %l1
  store i32 %a3, ptr %l3
  store %"compiler/source:Span" %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = load i32, ptr %l3, !tbaa !23
  %t4 = load %"compiler/source:Span", ptr %l5
  %t9 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2elocal(ptr %v0, ptr %t1, { i64, [4 x i64] } %a2, i32 %t3, %"compiler/source:Span" %t4)
  store i32 %t9, ptr %l19
  br label %bb1
bb1:
  %t10 = load i32, ptr %l19, !tbaa !23
  store i32 %t10, ptr %l7, !tbaa !23
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  %t13 = load %"compiler/mir:Place", ptr %l1
  store { i64, [4 x i64] } zeroinitializer, ptr %t14
  %t15 = getelementptr { i64, [4 x i64] }, ptr %t14, i32 0, i32 0
  store i64 1, ptr %t15
  %t17 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t13, 0
  %t18 = getelementptr { i64, [4 x i64] }, ptr %t14, i32 0, i32 1
  store { %"compiler/mir:Place" } %t17, ptr %t18
  %t19 = load { i64, [4 x i64] }, ptr %t14
  %t21 = insertvalue [1 x { i64, [4 x i64] }] undef, { i64, [4 x i64] } %t19, 0
  %t23 = load ptr, ptr @__olang_prog_scope
  %t24 = call ptr @__olang_scope_alloc(ptr %t23, i64 40)
  store [1 x { i64, [4 x i64] }] %t21, ptr %t24
  %t25 = insertvalue { i64, ptr } undef, i64 1, 0
  %t26 = insertvalue { i64, ptr } %t25, ptr %t24, 1
  %t28 = extractvalue { i64, ptr } %t26, 0
  %t29 = extractvalue { i64, ptr } %t26, 1
  %t30 = mul i64 %t28, 40
  %t31 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t30)
  call void @llvm.memcpy.p0.p0.i64(ptr %t31, ptr %t29, i64 %t30, i1 false)
  %t32 = insertvalue { i64, ptr } undef, i64 %t28, 0
  %t33 = insertvalue { i64, ptr } %t32, ptr %t31, 1
  %t34 = load %"compiler/source:Span", ptr %l5
  %t40 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s0, ptr %t11, i32 22, i32 %t12, { i64, ptr } %t33, %"compiler/source:Span" %t34)
  store { i64, [4 x i64] } %t40, ptr %l29
  br label %bb2
bb2:
  %t41 = load { i64, [4 x i64] }, ptr %l29
  store { i64, [4 x i64] } %t41, ptr %l8
  %t42 = load ptr, ptr %l0, !tbaa !29
  store ptr %t42, ptr %l30, !tbaa !29
  store i32 22, ptr %l31
  %t43 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  store i32 %t43, ptr %l32, !tbaa !23
  %t44 = load i32, ptr %l7, !tbaa !23
  %t46 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t44)
  store %"compiler/mir:Place" %t46, ptr %l34
  br label %bb3
bb3:
  store { i64, [4 x i64] } zeroinitializer, ptr %t47
  %t48 = getelementptr { i64, [4 x i64] }, ptr %t47, i32 0, i32 0
  store i64 1, ptr %t48
  %t49 = load %"compiler/mir:Place", ptr %l34
  %t50 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t49, 0
  %t51 = getelementptr { i64, [4 x i64] }, ptr %t47, i32 0, i32 1
  store { %"compiler/mir:Place" } %t50, ptr %t51
  %t52 = load { i64, [4 x i64] }, ptr %t47
  %t54 = insertvalue [1 x { i64, [4 x i64] }] undef, { i64, [4 x i64] } %t52, 0
  %t56 = load ptr, ptr @__olang_prog_scope
  %t57 = call ptr @__olang_scope_alloc(ptr %t56, i64 40)
  store [1 x { i64, [4 x i64] }] %t54, ptr %t57
  %t58 = insertvalue { i64, ptr } undef, i64 1, 0
  %t59 = insertvalue { i64, ptr } %t58, ptr %t57, 1
  %t61 = extractvalue { i64, ptr } %t59, 0
  %t62 = extractvalue { i64, ptr } %t59, 1
  %t63 = mul i64 %t61, 40
  %t64 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t63)
  call void @llvm.memcpy.p0.p0.i64(ptr %t64, ptr %t62, i64 %t63, i1 false)
  %t65 = insertvalue { i64, ptr } undef, i64 %t61, 0
  %t66 = insertvalue { i64, ptr } %t65, ptr %t64, 1
  %t67 = load %"compiler/source:Span", ptr %l5
  %t68 = load ptr, ptr %l30, !tbaa !29
  %t69 = load i32, ptr %l31
  %t70 = load i32, ptr %l32, !tbaa !23
  %t73 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s0, ptr %t68, i32 %t69, i32 %t70, { i64, ptr } %t66, %"compiler/source:Span" %t67)
  store { i64, [4 x i64] } %t73, ptr %l40
  br label %bb4
bb4:
  %t74 = load { i64, [4 x i64] }, ptr %l40
  store { i64, [4 x i64] } %t74, ptr %l9
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t76 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t77 = load { i64, [4 x i64] }, ptr %l8
  %t78 = load { i64, [4 x i64] }, ptr %l9
  %t80 = insertvalue [2 x { i64, [4 x i64] }] undef, { i64, [4 x i64] } %t77, 0
  %t82 = insertvalue [2 x { i64, [4 x i64] }] %t80, { i64, [4 x i64] } %t78, 1
  %t84 = load ptr, ptr @__olang_prog_scope
  %t85 = call ptr @__olang_scope_alloc(ptr %t84, i64 80)
  store [2 x { i64, [4 x i64] }] %t82, ptr %t85
  %t86 = insertvalue { i64, ptr } undef, i64 2, 0
  %t87 = insertvalue { i64, ptr } %t86, ptr %t85, 1
  %t89 = extractvalue { i64, ptr } %t87, 0
  %t90 = extractvalue { i64, ptr } %t87, 1
  %t91 = mul i64 %t89, 40
  %t92 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t91)
  call void @llvm.memcpy.p0.p0.i64(ptr %t92, ptr %t90, i64 %t91, i1 false)
  %t93 = insertvalue { i64, ptr } undef, i64 %t89, 0
  %t94 = insertvalue { i64, ptr } %t93, ptr %t92, 1
  %t95 = load %"compiler/source:Span", ptr %l5
  %t101 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s0, ptr %t75, i32 13, i32 %t76, { i64, ptr } %t94, %"compiler/source:Span" %t95)
  store { i64, [4 x i64] } %t101, ptr %l50
  br label %bb5
bb5:
  %t102 = load { i64, [4 x i64] }, ptr %l50
  store { i64, [4 x i64] } %t102, ptr %l10
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t105 = getelementptr %"compiler/lower:lowering", ptr %t103, i32 0, i32 3
  %t107 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t105)
  store i32 %t107, ptr %l53
  br label %bb6
bb6:
  %t108 = load i32, ptr %l53, !tbaa !23
  store i32 %t108, ptr %l11, !tbaa !23
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t111 = getelementptr %"compiler/lower:lowering", ptr %t109, i32 0, i32 3
  %t113 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t111)
  store i32 %t113, ptr %l56
  br label %bb7
bb7:
  %t114 = load i32, ptr %l56, !tbaa !23
  store i32 %t114, ptr %l12, !tbaa !23
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t117 = getelementptr %"compiler/lower:lowering", ptr %t115, i32 0, i32 3
  %t119 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t117)
  store i32 %t119, ptr %l59
  br label %bb8
bb8:
  %t120 = load i32, ptr %l59, !tbaa !23
  store i32 %t120, ptr %l13, !tbaa !23
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t122 = load { i64, [4 x i64] }, ptr %l10
  %t123 = load i32, ptr %l11, !tbaa !23
  %t124 = load i32, ptr %l12, !tbaa !23
  store { i64, [7 x i64] } zeroinitializer, ptr %t125
  %t126 = getelementptr { i64, [7 x i64] }, ptr %t125, i32 0, i32 0
  store i64 2, ptr %t126
  %t128 = insertvalue { { i64, [4 x i64] }, i32, i32 } undef, { i64, [4 x i64] } %t122, 0
  %t130 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t128, i32 %t123, 1
  %t132 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t130, i32 %t124, 2
  %t133 = getelementptr { i64, [7 x i64] }, ptr %t125, i32 0, i32 1
  store { { i64, [4 x i64] }, i32, i32 } %t132, ptr %t133
  %t134 = load { i64, [7 x i64] }, ptr %t125
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t121, { i64, [7 x i64] } %t134)
  br label %bb9
bb9:
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t138 = load i32, ptr %l11, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t137, i32 %t138)
  br label %bb10
bb10:
  %t141 = load ptr, ptr %l0, !tbaa !29
  store ptr %t141, ptr %l67, !tbaa !29
  %t142 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t142, ptr %l68
  %t143 = load %"compiler/mir:Place", ptr %l1
  store %"compiler/mir:Place" %t143, ptr %l69
  %t144 = load i32, ptr %l7, !tbaa !23
  %t146 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t144)
  store %"compiler/mir:Place" %t146, ptr %l71
  br label %bb11
bb11:
  %t147 = load { i64, [4 x i64] }, ptr %l9
  store { i64, [21 x i64] } zeroinitializer, ptr %t148
  %t149 = getelementptr { i64, [21 x i64] }, ptr %t148, i32 0, i32 0
  store i64 10, ptr %t149
  %t150 = load %"compiler/source:Span", ptr %l68
  %t151 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", %"compiler/mir:Place", { i64, [4 x i64] } } undef, %"compiler/source:Span" %t150, 0
  %t152 = load %"compiler/mir:Place", ptr %l69
  %t153 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", %"compiler/mir:Place", { i64, [4 x i64] } } %t151, %"compiler/mir:Place" %t152, 1
  %t154 = load %"compiler/mir:Place", ptr %l71
  %t155 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", %"compiler/mir:Place", { i64, [4 x i64] } } %t153, %"compiler/mir:Place" %t154, 2
  %t157 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", %"compiler/mir:Place", { i64, [4 x i64] } } %t155, { i64, [4 x i64] } %t147, 3
  %t158 = getelementptr { i64, [21 x i64] }, ptr %t148, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Place", %"compiler/mir:Place", { i64, [4 x i64] } } %t157, ptr %t158
  %t159 = load { i64, [21 x i64] }, ptr %t148
  %t161 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t159, ptr %t161
  %t162 = load ptr, ptr %l67, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s0, ptr %t162, ptr %t161)
  br label %bb12
bb12:
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t165 = load i32, ptr %l13, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2egoto(ptr %v0, ptr %t164, i32 %t165)
  br label %bb13
bb13:
  %t168 = load ptr, ptr %l0, !tbaa !29
  %t169 = load i32, ptr %l12, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t168, i32 %t169)
  br label %bb14
bb14:
  br i1 %a4, label %bb15, label %bb16
bb15:
  %t174 = load ptr, ptr %l0, !tbaa !29
  store ptr %t174, ptr %l81, !tbaa !29
  %t175 = load i32, ptr %l7, !tbaa !23
  %t177 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t175)
  store %"compiler/mir:Place" %t177, ptr %l83
  br label %bb17
bb16:
  %t178 = load i32, ptr %l7, !tbaa !23
  %t180 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t178)
  store %"compiler/mir:Place" %t180, ptr %l90
  br label %bb19
bb17:
  store { i64, [4 x i64] } zeroinitializer, ptr %t181
  %t182 = getelementptr { i64, [4 x i64] }, ptr %t181, i32 0, i32 0
  store i64 1, ptr %t182
  %t183 = load %"compiler/mir:Place", ptr %l83
  %t184 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t183, 0
  %t185 = getelementptr { i64, [4 x i64] }, ptr %t181, i32 0, i32 1
  store { %"compiler/mir:Place" } %t184, ptr %t185
  %t186 = load { i64, [4 x i64] }, ptr %t181
  %t187 = load i32, ptr %l3, !tbaa !23
  %t188 = load %"compiler/source:Span", ptr %l5
  %t190 = load ptr, ptr %l81, !tbaa !29
  %t195 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2earrayCopy(ptr %v0, ptr %t190, { i64, [4 x i64] } %t186, i32 %t187, %"compiler/source:Span" %t188, { i64, [1 x i64] } %a6)
  store { i64, [4 x i64] } %t195, ptr %l88
  br label %bb18
bb18:
  %t196 = load { i64, [4 x i64] }, ptr %l88
  store { i64, [4 x i64] } %t196, ptr %l80
  br label %bb20
bb19:
  store { i64, [4 x i64] } zeroinitializer, ptr %t197
  %t198 = getelementptr { i64, [4 x i64] }, ptr %t197, i32 0, i32 0
  store i64 1, ptr %t198
  %t199 = load %"compiler/mir:Place", ptr %l90
  %t200 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t199, 0
  %t201 = getelementptr { i64, [4 x i64] }, ptr %t197, i32 0, i32 1
  store { %"compiler/mir:Place" } %t200, ptr %t201
  %t202 = load { i64, [4 x i64] }, ptr %t197
  store { i64, [4 x i64] } %t202, ptr %l80
  br label %bb20
bb20:
  %t204 = load { i64, [4 x i64] }, ptr %l80
  %t205 = load ptr, ptr %l0, !tbaa !29
  %t206 = load %"compiler/source:Span", ptr %l5
  %t207 = load %"compiler/mir:Place", ptr %l1
  store { i64, [15 x i64] } zeroinitializer, ptr %t209
  %t210 = getelementptr { i64, [15 x i64] }, ptr %t209, i32 0, i32 0
  store i64 0, ptr %t210
  %t212 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t204, 0
  %t213 = getelementptr { i64, [15 x i64] }, ptr %t209, i32 0, i32 1
  store { { i64, [4 x i64] } } %t212, ptr %t213
  %t214 = load { i64, [15 x i64] }, ptr %t209
  store { i64, [21 x i64] } zeroinitializer, ptr %t215
  %t216 = getelementptr { i64, [21 x i64] }, ptr %t215, i32 0, i32 0
  store i64 0, ptr %t216
  %t218 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t206, 0
  %t220 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t218, %"compiler/mir:Place" %t207, 1
  %t222 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t220, { i64, [15 x i64] } %t214, 2
  %t223 = getelementptr { i64, [21 x i64] }, ptr %t215, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t222, ptr %t223
  %t224 = load { i64, [21 x i64] }, ptr %t215
  %t226 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t224, ptr %t226
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s0, ptr %t205, ptr %t226)
  br label %bb21
bb21:
  %t229 = load ptr, ptr %l0, !tbaa !29
  %t230 = load i32, ptr %l13, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2egoto(ptr %v0, ptr %t229, i32 %t230)
  br label %bb22
bb22:
  %t233 = load ptr, ptr %l0, !tbaa !29
  %t234 = load i32, ptr %l13, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t233, i32 %t234)
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2eassemble(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca i32
  %l7 = alloca { i64, [4 x i64] }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca { i64, [4 x i64] }
  %l16 = alloca { i64, [1 x i64] }
  %l23 = alloca i1
  %l24 = alloca i32
  %l27 = alloca i32
  %l31 = alloca i32
  %l34 = alloca i32
  %l37 = alloca i1
  %l38 = alloca ptr
  %l41 = alloca i32
  %l42 = alloca i32
  %l49 = alloca i64
  %l51 = alloca i1
  %l58 = alloca ptr
  %l61 = alloca i32
  %l64 = alloca { i64, [4 x i64] }
  %l73 = alloca i64
  %l79 = alloca i64
  %l83 = alloca i64
  %l86 = alloca i64
  %l104 = alloca i64
  %l108 = alloca i32
  %l111 = alloca %"compiler/mir:Place"
  %l115 = alloca ptr
  %l116 = alloca i32
  %l117 = alloca i32
  %l121 = alloca %"compiler/mir:Range"
  %l125 = alloca { i64, [4 x i64] }
  %l130 = alloca { i64, [1 x i64] }
  %l139 = alloca { i64, [4 x i64] }
  %l142 = alloca i32
  %l145 = alloca i1
  %l148 = alloca i1
  %l149 = alloca i1
  %l152 = alloca i1
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %t103 = alloca { i64, [7 x i64] }, align 8
  %t194 = alloca { i64, [4 x i64] }, align 8
  %t219 = alloca { i64, [15 x i64] }, align 8
  %t253 = alloca { i64, [15 x i64] }, align 8
  %t305 = alloca { i64, [21 x i64] }, align 8
  %t329 = alloca { i64, [7 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/lower:lowering", ptr %t6, i32 0, i32 2
  %t9 = load ptr, ptr %t8, !tbaa !29
  store ptr %t9, ptr %l3, !tbaa !29
  %t11 = load ptr, ptr %l3, !tbaa !29
  %t12 = load i32, ptr %l1, !tbaa !23
  %t15 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t11, i32 %t12)
  store i1 %t15, ptr %l23
  br label %bb1
bb1:
  %t16 = load i1, ptr %l23, !tbaa !21
  br i1 %t16, label %bb2, label %bb3
bb2:
  %t17 = load ptr, ptr %l3, !tbaa !29
  %t18 = load i32, ptr %l1, !tbaa !23
  %t21 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t17, i32 %t18)
  store i32 %t21, ptr %l27
  br label %bb4
bb3:
  %t22 = load i32, ptr %l1, !tbaa !23
  store i32 %t22, ptr %l24, !tbaa !23
  br label %bb5
bb4:
  %t24 = load i32, ptr %l27, !tbaa !23
  store i32 %t24, ptr %l24, !tbaa !23
  br label %bb5
bb5:
  %t25 = load i32, ptr %l24, !tbaa !23
  store i32 %t25, ptr %l4, !tbaa !23
  %t26 = load ptr, ptr %l3, !tbaa !29
  %t27 = load i32, ptr %l4, !tbaa !23
  %t30 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t26, i32 %t27)
  store i32 %t30, ptr %l31
  br label %bb6
bb6:
  %t31 = load i32, ptr %l31, !tbaa !23
  store i32 %t31, ptr %l5, !tbaa !23
  %t32 = load ptr, ptr %l3, !tbaa !29
  %t33 = load i32, ptr %l5, !tbaa !23
  %t36 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t32, i32 %t33)
  store i32 %t36, ptr %l34
  br label %bb7
bb7:
  %t37 = load i32, ptr %l34
  %t39 = trunc i64 18 to i32
  %t40 = icmp eq i32 %t37, %t39
  br i1 %t40, label %bb8, label %bb9
bb8:
  %t42 = load ptr, ptr %l3, !tbaa !29
  store ptr %t42, ptr %l38, !tbaa !29
  %t43 = load ptr, ptr %l3, !tbaa !29
  %t44 = load i32, ptr %l5, !tbaa !23
  %t47 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t43, i32 %t44)
  store i32 %t47, ptr %l41
  br label %bb10
bb9:
  store i1 false, ptr %l37, !tbaa !21
  br label %bb12
bb10:
  %t48 = load ptr, ptr %l38, !tbaa !29
  %t49 = load i32, ptr %l41, !tbaa !23
  %t50 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t48, i32 %t49)
  store i32 %t50, ptr %l42
  br label %bb11
bb11:
  %t51 = load i32, ptr %l42
  %t53 = trunc i64 0 to i32
  %t54 = icmp eq i32 %t51, %t53
  store i1 %t54, ptr %l37, !tbaa !21
  br label %bb12
bb12:
  %t56 = load i1, ptr %l37, !tbaa !21
  %t59 = xor i1 %t56, true
  br i1 %t59, label %bb13, label %bb14
bb13:
  %t61 = load ptr, ptr %l2, !tbaa !29
  %t63 = getelementptr %"compiler/typed:Body", ptr %t61, i32 0, i32 10
  %t65 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t63)
  store i64 %t65, ptr %l49
  br label %bb15
bb14:
  br label %bb27
bb15:
  %t66 = load i64, ptr %l49, !tbaa !24
  %t67 = icmp ne i64 %t66, 1
  br i1 %t67, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l51, !tbaa !21
  br label %bb18
bb17:
  %t69 = load i32, ptr %l4, !tbaa !23
  %t70 = load i32, ptr %l1, !tbaa !23
  %t73 = icmp ne i32 %t69, %t70
  store i1 %t73, ptr %l51, !tbaa !21
  br label %bb18
bb18:
  %t75 = load i1, ptr %l51, !tbaa !21
  br i1 %t75, label %bb19, label %bb20
bb19:
  store %olang.scope zeroinitializer, ptr %s2
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t77 = load ptr, ptr %l2, !tbaa !29
  %t79 = getelementptr %"compiler/typed:Body", ptr %t77, i32 0, i32 4
  %t80 = load %"compiler/source:Span", ptr %t79
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2egap(ptr %v0, ptr %s2, ptr %t76, %"compiler/source:Span" %t80, { i64, ptr } { i64 41, ptr @.d8 })
  br label %bb21
bb20:
  br label %bb22
bb21:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb22:
  %t83 = load ptr, ptr %l0, !tbaa !29
  store ptr %t83, ptr %l58, !tbaa !29
  %t84 = load ptr, ptr %l2, !tbaa !29
  %t86 = getelementptr %"compiler/typed:Body", ptr %t84, i32 0, i32 10
  %t88 = call i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t86, i64 0)
  store i32 %t88, ptr %l61
  br label %bb23
bb23:
  %t89 = load i32, ptr %l61, !tbaa !23
  %t91 = load ptr, ptr %l58, !tbaa !29
  %t93 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ecopyLocal(ptr %v0, ptr %t91, i32 %t89)
  store { i64, [4 x i64] } %t93, ptr %l64
  br label %bb24
bb24:
  %t94 = load { i64, [4 x i64] }, ptr %l64
  store { i64, [4 x i64] } %t94, ptr %l7
  %t95 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eleave(ptr %v0, ptr %t95, i64 0)
  br label %bb25
bb25:
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t98 = load ptr, ptr %l2, !tbaa !29
  %t100 = getelementptr %"compiler/typed:Body", ptr %t98, i32 0, i32 4
  %t101 = load %"compiler/source:Span", ptr %t100
  %t102 = load { i64, [4 x i64] }, ptr %l7
  store { i64, [7 x i64] } zeroinitializer, ptr %t103
  %t104 = getelementptr { i64, [7 x i64] }, ptr %t103, i32 0, i32 0
  store i64 5, ptr %t104
  %t106 = insertvalue { %"compiler/source:Span", { i64, [4 x i64] } } undef, %"compiler/source:Span" %t101, 0
  %t108 = insertvalue { %"compiler/source:Span", { i64, [4 x i64] } } %t106, { i64, [4 x i64] } %t102, 1
  %t109 = getelementptr { i64, [7 x i64] }, ptr %t103, i32 0, i32 1
  store { %"compiler/source:Span", { i64, [4 x i64] } } %t108, ptr %t109
  %t110 = load { i64, [7 x i64] }, ptr %t103
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t97, { i64, [7 x i64] } %t110)
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb27:
  %t113 = load ptr, ptr %l2, !tbaa !29
  %t115 = getelementptr %"compiler/typed:Body", ptr %t113, i32 0, i32 10
  %t117 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t115)
  store i64 %t117, ptr %l73
  br label %bb28
bb28:
  %t118 = load i64, ptr %l73, !tbaa !24
  %t119 = icmp sge i64 %t118, 0
  br i1 %t119, label %bb29, label %bb30
bb29:
  %t121 = load i64, ptr %l73, !tbaa !24
  %t122 = icmp sle i64 %t121, 230584300921369395
  br i1 %t122, label %bb31, label %bb32
bb30:
  call void @__olang_check_failed(ptr @olang_loc_b4f44bfc4c4e49f2_17d18a81dcc1f1de)
  unreachable
bb31:
  %t124 = load i64, ptr %l73, !tbaa !24
  %t125 = mul i64 %t124, 40
  %t126 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t125)
  %t127 = insertvalue { i64, ptr } undef, i64 %t124, 0
  %t128 = insertvalue { i64, ptr } %t127, ptr %t126, 1
  store { i64, ptr } %t128, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t130 = load ptr, ptr %l2, !tbaa !29
  %t132 = getelementptr %"compiler/typed:Body", ptr %t130, i32 0, i32 10
  %t134 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t132)
  store i64 %t134, ptr %l79
  br label %bb33
bb32:
  call void @__olang_check_failed(ptr @olang_loc_b4f44bfc4c4e49f2_17d18a81dcc1f1de)
  unreachable
bb33:
  %t135 = load i64, ptr %l79, !tbaa !24
  store i64 %t135, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t136 = load i64, ptr %l10, !tbaa !24
  %t137 = load i64, ptr %l9, !tbaa !24
  %t140 = icmp sgt i64 %t136, %t137
  br i1 %t140, label %bb34, label %bb35
bb34:
  %t142 = load i64, ptr %l11, !tbaa !24
  %t144 = icmp sgt i64 %t142, 0
  br i1 %t144, label %bb36, label %bb37
bb35:
  store i64 0, ptr %l83, !tbaa !24
  br label %bb39
bb36:
  %t146 = load i64, ptr %l10, !tbaa !24
  %t147 = load i64, ptr %l9, !tbaa !24
  %t150 = sub i64 %t146, %t147
  %t151 = load i64, ptr %l11, !tbaa !24
  %t154 = add i64 %t150, %t151
  %t156 = sub i64 %t154, 1
  %t157 = load i64, ptr %l11, !tbaa !24
  %t160 = sdiv i64 %t156, %t157
  store i64 %t160, ptr %l86, !tbaa !24
  br label %bb38
bb37:
  store i64 0, ptr %l86, !tbaa !24
  br label %bb38
bb38:
  %t162 = load i64, ptr %l86, !tbaa !24
  store i64 %t162, ptr %l83, !tbaa !24
  br label %bb39
bb39:
  %t163 = load i64, ptr %l83, !tbaa !24
  store i64 %t163, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb40
bb40:
  store %olang.scope zeroinitializer, ptr %s4
  %t164 = load i64, ptr %l13, !tbaa !24
  %t165 = load i64, ptr %l12, !tbaa !24
  %t168 = icmp slt i64 %t164, %t165
  %t170 = xor i1 %t168, true
  br i1 %t170, label %bb41, label %bb42
bb41:
  call void @__olang_scope_close(ptr %s4)
  br label %bb47
bb42:
  br label %bb43
bb43:
  %t172 = load i64, ptr %l9, !tbaa !24
  %t173 = load i64, ptr %l13, !tbaa !24
  %t174 = load i64, ptr %l11, !tbaa !24
  %t177 = mul i64 %t173, %t174
  %t180 = add i64 %t172, %t177
  store i64 %t180, ptr %l14, !tbaa !24
  %t182 = load i64, ptr %l14, !tbaa !24
  store i64 %t182, ptr %l104, !tbaa !24
  %t183 = load ptr, ptr %l2, !tbaa !29
  %t185 = getelementptr %"compiler/typed:Body", ptr %t183, i32 0, i32 10
  %t186 = load i64, ptr %l14, !tbaa !24
  %t189 = call i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t185, i64 %t186)
  store i32 %t189, ptr %l108
  br label %bb44
bb44:
  %t190 = load i32, ptr %l108, !tbaa !23
  %t193 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t190)
  store %"compiler/mir:Place" %t193, ptr %l111
  br label %bb45
bb45:
  store { i64, [4 x i64] } zeroinitializer, ptr %t194
  %t195 = getelementptr { i64, [4 x i64] }, ptr %t194, i32 0, i32 0
  store i64 1, ptr %t195
  %t196 = load %"compiler/mir:Place", ptr %l111
  %t197 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t196, 0
  %t198 = getelementptr { i64, [4 x i64] }, ptr %t194, i32 0, i32 1
  store { %"compiler/mir:Place" } %t197, ptr %t198
  %t199 = load { i64, [4 x i64] }, ptr %t194
  %t201 = load i64, ptr %l104, !tbaa !24
  %t202 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t203 = load ptr, ptr %t202, !tbaa !27
  %t204 = getelementptr { i64, [4 x i64] }, ptr %t203, i64 %t201
  store { i64, [4 x i64] } %t199, ptr %t204
  call void @__olang_scope_close(ptr %s4)
  br label %bb46
bb46:
  %t205 = load i64, ptr %l13, !tbaa !24
  %t207 = add i64 %t205, 1
  store i64 %t207, ptr %l13, !tbaa !24
  br label %bb40
bb47:
  %t209 = load ptr, ptr %l0, !tbaa !29
  store ptr %t209, ptr %l115, !tbaa !29
  %t210 = load i32, ptr %l4, !tbaa !23
  store i32 %t210, ptr %l116, !tbaa !23
  %t211 = load i32, ptr %l4, !tbaa !23
  store i32 %t211, ptr %l117, !tbaa !23
  %t212 = load ptr, ptr %l0, !tbaa !29
  %t214 = getelementptr %"compiler/lower:lowering", ptr %t212, i32 0, i32 3
  %t215 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t218 = call %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eArgs(ptr %v0, ptr %s0, ptr %t214, { i64, ptr } %t215)
  store %"compiler/mir:Range" %t218, ptr %l121
  br label %bb48
bb48:
  store { i64, [15 x i64] } zeroinitializer, ptr %t219
  %t220 = getelementptr { i64, [15 x i64] }, ptr %t219, i32 0, i32 0
  store i64 6, ptr %t220
  %t221 = load i32, ptr %l117, !tbaa !23
  %t222 = insertvalue { i32, i64, %"compiler/mir:Range" } undef, i32 %t221, 0
  %t223 = insertvalue { i32, i64, %"compiler/mir:Range" } %t222, i64 0, 1
  %t224 = load %"compiler/mir:Range", ptr %l121
  %t225 = insertvalue { i32, i64, %"compiler/mir:Range" } %t223, %"compiler/mir:Range" %t224, 2
  %t226 = getelementptr { i64, [15 x i64] }, ptr %t219, i32 0, i32 1
  store { i32, i64, %"compiler/mir:Range" } %t225, ptr %t226
  %t227 = load { i64, [15 x i64] }, ptr %t219
  %t228 = load ptr, ptr %l2, !tbaa !29
  %t230 = getelementptr %"compiler/typed:Body", ptr %t228, i32 0, i32 4
  %t231 = load %"compiler/source:Span", ptr %t230
  %t232 = load ptr, ptr %l115, !tbaa !29
  %t233 = load i32, ptr %l116, !tbaa !23
  %t236 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %t232, i32 %t233, { i64, [15 x i64] } %t227, %"compiler/source:Span" %t231)
  store { i64, [4 x i64] } %t236, ptr %l125
  br label %bb49
bb49:
  %t237 = load { i64, [4 x i64] }, ptr %l125
  store { i64, [4 x i64] } %t237, ptr %l15
  %t238 = load i32, ptr %l4, !tbaa !23
  %t239 = load i32, ptr %l1, !tbaa !23
  %t242 = icmp ne i32 %t238, %t239
  br i1 %t242, label %bb50, label %bb51
bb50:
  %t244 = load ptr, ptr %l0, !tbaa !29
  %t246 = call { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einstance(ptr %v0, ptr %t244)
  store { i64, [1 x i64] } %t246, ptr %l130
  br label %bb52
bb51:
  br label %bb67
bb52:
  %t247 = load { i64, [1 x i64] }, ptr %l130
  store { i64, [1 x i64] } %t247, ptr %l16
  %t248 = load ptr, ptr %l0, !tbaa !29
  %t249 = load i32, ptr %l1, !tbaa !23
  %t250 = load { i64, [1 x i64] }, ptr %l16
  %t251 = load { i64, [4 x i64] }, ptr %l15
  %t252 = load i32, ptr %l1, !tbaa !23
  store { i64, [15 x i64] } zeroinitializer, ptr %t253
  %t254 = getelementptr { i64, [15 x i64] }, ptr %t253, i32 0, i32 0
  store i64 7, ptr %t254
  %t256 = insertvalue { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 } undef, { i64, [1 x i64] } %t250, 0
  %t258 = insertvalue { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 } %t256, { i64, [4 x i64] } %t251, 1
  %t260 = insertvalue { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 } %t258, i32 %t252, 2
  %t261 = getelementptr { i64, [15 x i64] }, ptr %t253, i32 0, i32 1
  store { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 } %t260, ptr %t261
  %t262 = load { i64, [15 x i64] }, ptr %t253
  %t263 = load ptr, ptr %l2, !tbaa !29
  %t265 = getelementptr %"compiler/typed:Body", ptr %t263, i32 0, i32 4
  %t266 = load %"compiler/source:Span", ptr %t265
  %t271 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %t248, i32 %t249, { i64, [15 x i64] } %t262, %"compiler/source:Span" %t266)
  store { i64, [4 x i64] } %t271, ptr %l139
  br label %bb53
bb53:
  %t272 = load { i64, [4 x i64] }, ptr %l139
  store { i64, [4 x i64] } %t272, ptr %l15
  %t273 = load ptr, ptr %l3, !tbaa !29
  %t274 = load i32, ptr %l5, !tbaa !23
  %t277 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t273, i32 %t274)
  store i32 %t277, ptr %l142
  br label %bb54
bb54:
  %t278 = load i32, ptr %l142
  %t280 = trunc i64 18 to i32
  %t281 = icmp eq i32 %t278, %t280
  br i1 %t281, label %bb55, label %bb56
bb55:
  %t283 = load ptr, ptr %l3, !tbaa !29
  %t284 = load i32, ptr %l5, !tbaa !23
  %t287 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %t283, i32 %t284)
  store i1 %t287, ptr %l148
  br label %bb57
bb56:
  store i1 false, ptr %l145, !tbaa !21
  br label %bb58
bb57:
  %t288 = load i1, ptr %l148, !tbaa !21
  store i1 %t288, ptr %l145, !tbaa !21
  br label %bb58
bb58:
  %t289 = load i1, ptr %l145, !tbaa !21
  br i1 %t289, label %bb59, label %bb60
bb59:
  %t290 = load ptr, ptr %l3, !tbaa !29
  %t291 = load i32, ptr %l5, !tbaa !23
  %t294 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDestructs(ptr %v0, ptr %t290, i32 %t291)
  store i1 %t294, ptr %l152
  br label %bb61
bb60:
  store i1 false, ptr %l149, !tbaa !21
  br label %bb62
bb61:
  %t295 = load i1, ptr %l152, !tbaa !21
  store i1 %t295, ptr %l149, !tbaa !21
  br label %bb62
bb62:
  %t296 = load i1, ptr %l149, !tbaa !21
  br i1 %t296, label %bb63, label %bb64
bb63:
  store %olang.scope zeroinitializer, ptr %s7
  %t297 = load ptr, ptr %l0, !tbaa !29
  %t298 = load ptr, ptr %l2, !tbaa !29
  %t300 = getelementptr %"compiler/typed:Body", ptr %t298, i32 0, i32 4
  %t301 = load %"compiler/source:Span", ptr %t300
  %t302 = load { i64, [1 x i64] }, ptr %l16
  %t303 = load i32, ptr %l4, !tbaa !23
  %t304 = load { i64, [4 x i64] }, ptr %l15
  store { i64, [21 x i64] } zeroinitializer, ptr %t305
  %t306 = getelementptr { i64, [21 x i64] }, ptr %t305, i32 0, i32 0
  store i64 6, ptr %t306
  %t308 = insertvalue { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } undef, %"compiler/source:Span" %t301, 0
  %t310 = insertvalue { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } %t308, { i64, [1 x i64] } %t302, 1
  %t312 = insertvalue { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } %t310, i32 %t303, 2
  %t314 = insertvalue { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } %t312, { i64, [4 x i64] } %t304, 3
  %t315 = getelementptr { i64, [21 x i64] }, ptr %t305, i32 0, i32 1
  store { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } %t314, ptr %t315
  %t316 = load { i64, [21 x i64] }, ptr %t305
  %t318 = call ptr @__olang_scope_alloc_a(ptr %s7, i64 176, i64 8)
  store { i64, [21 x i64] } %t316, ptr %t318
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s7, ptr %t297, ptr %t318)
  br label %bb65
bb64:
  br label %bb66
bb65:
  call void @__olang_scope_close(ptr %s7)
  br label %bb66
bb66:
  br label %bb67
bb67:
  %t321 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eleave(ptr %v0, ptr %t321, i64 0)
  br label %bb68
bb68:
  %t323 = load ptr, ptr %l0, !tbaa !29
  %t324 = load ptr, ptr %l2, !tbaa !29
  %t326 = getelementptr %"compiler/typed:Body", ptr %t324, i32 0, i32 4
  %t327 = load %"compiler/source:Span", ptr %t326
  %t328 = load { i64, [4 x i64] }, ptr %l15
  store { i64, [7 x i64] } zeroinitializer, ptr %t329
  %t330 = getelementptr { i64, [7 x i64] }, ptr %t329, i32 0, i32 0
  store i64 5, ptr %t330
  %t332 = insertvalue { %"compiler/source:Span", { i64, [4 x i64] } } undef, %"compiler/source:Span" %t327, 0
  %t334 = insertvalue { %"compiler/source:Span", { i64, [4 x i64] } } %t332, { i64, [4 x i64] } %t328, 1
  %t335 = getelementptr { i64, [7 x i64] }, ptr %t329, i32 0, i32 1
  store { %"compiler/source:Span", { i64, [4 x i64] } } %t334, ptr %t335
  %t336 = load { i64, [7 x i64] }, ptr %t329
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t323, { i64, [7 x i64] } %t336)
  br label %bb69
bb69:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2eassert(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l3 = alloca ptr
  %l4 = alloca { i64, [4 x i64] }
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca { i64, [4 x i64] }
  %l10 = alloca ptr
  %l17 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l18 = alloca i1
  %l22 = alloca { i64, [4 x i64] }
  %l27 = alloca i32
  %l30 = alloca i32
  %l45 = alloca { i64, [4 x i64] }
  %s0 = alloca %olang.scope
  %t55 = alloca { i64, [7 x i64] }, align 8
  %t71 = alloca { i64, [4 x i64] }, align 8
  %t91 = alloca { i64, [7 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/lower:Lowerer", ptr %t4, i32 0, i32 6
  store ptr %t6, ptr %l10, !tbaa !29
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/lower:lowering", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/typed:Body", ptr %t10, i32 0, i32 0
  %t13 = load i32, ptr %t12, !tbaa !23
  %t15 = sext i32 %t13 to i64
  %t16 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t17 = load i32, ptr %t16, !tbaa !23
  %t19 = sext i32 %t17 to i64
  %t22 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s0, i64 %t15, i64 %t19)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t22, ptr %l17
  br label %bb1
bb1:
  %t23 = load ptr, ptr %l10, !tbaa !29
  %t24 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l17
  %t25 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %v0, ptr %t23, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t24)
  store i1 %t25, ptr %l18
  br label %bb2
bb2:
  %t26 = load i1, ptr %l18, !tbaa !21
  br i1 %t26, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb4:
  br label %bb5
bb5:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t32 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v1, ptr %t27, ptr %a2)
  store { i64, [4 x i64] } %t32, ptr %l22
  br label %bb6
bb6:
  %t33 = load { i64, [4 x i64] }, ptr %l22
  store { i64, [4 x i64] } %t33, ptr %l4
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/lower:lowering", ptr %t34, i32 0, i32 7
  %t37 = load i1, ptr %t36, !tbaa !21
  br i1 %t37, label %bb7, label %bb8
bb7:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb8:
  br label %bb9
bb9:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/lower:lowering", ptr %t39, i32 0, i32 3
  %t43 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t41)
  store i32 %t43, ptr %l27
  br label %bb10
bb10:
  %t44 = load i32, ptr %l27, !tbaa !23
  store i32 %t44, ptr %l5, !tbaa !23
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/lower:lowering", ptr %t45, i32 0, i32 3
  %t49 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t47)
  store i32 %t49, ptr %l30
  br label %bb11
bb11:
  %t50 = load i32, ptr %l30, !tbaa !23
  store i32 %t50, ptr %l6, !tbaa !23
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t52 = load { i64, [4 x i64] }, ptr %l4
  %t53 = load i32, ptr %l5, !tbaa !23
  %t54 = load i32, ptr %l6, !tbaa !23
  store { i64, [7 x i64] } zeroinitializer, ptr %t55
  %t56 = getelementptr { i64, [7 x i64] }, ptr %t55, i32 0, i32 0
  store i64 2, ptr %t56
  %t58 = insertvalue { { i64, [4 x i64] }, i32, i32 } undef, { i64, [4 x i64] } %t52, 0
  %t60 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t58, i32 %t53, 1
  %t62 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t60, i32 %t54, 2
  %t63 = getelementptr { i64, [7 x i64] }, ptr %t55, i32 0, i32 1
  store { { i64, [4 x i64] }, i32, i32 } %t62, ptr %t63
  %t64 = load { i64, [7 x i64] }, ptr %t55
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t51, { i64, [7 x i64] } %t64)
  br label %bb12
bb12:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t68 = load i32, ptr %l6, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t67, i32 %t68)
  br label %bb13
bb13:
  store { i64, [4 x i64] } zeroinitializer, ptr %t71
  %t72 = getelementptr { i64, [4 x i64] }, ptr %t71, i32 0, i32 0
  store i64 0, ptr %t72
  %t73 = load { i64, [4 x i64] }, ptr %t71
  store { i64, [4 x i64] } %t73, ptr %l7
  %t75 = load ptr, ptr %l3, !tbaa !29
  %t77 = icmp eq ptr %t75, null
  %t79 = xor i1 %t77, true
  br i1 %t79, label %bb14, label %bb15
bb14:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t82 = load ptr, ptr %l3, !tbaa !29
  %t86 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v2, ptr %t81, ptr %t82)
  store { i64, [4 x i64] } %t86, ptr %l45
  br label %bb16
bb15:
  br label %bb17
bb16:
  %t87 = load { i64, [4 x i64] }, ptr %l45
  store { i64, [4 x i64] } %t87, ptr %l7
  br label %bb17
bb17:
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t89 = load %"compiler/source:Span", ptr %l1
  %t90 = load { i64, [4 x i64] }, ptr %l7
  store { i64, [7 x i64] } zeroinitializer, ptr %t91
  %t92 = getelementptr { i64, [7 x i64] }, ptr %t91, i32 0, i32 0
  store i64 8, ptr %t92
  %t94 = insertvalue { %"compiler/source:Span", i32, { i64, [4 x i64] } } undef, %"compiler/source:Span" %t89, 0
  %t96 = insertvalue { %"compiler/source:Span", i32, { i64, [4 x i64] } } %t94, i32 5, 1
  %t98 = insertvalue { %"compiler/source:Span", i32, { i64, [4 x i64] } } %t96, { i64, [4 x i64] } %t90, 2
  %t99 = getelementptr { i64, [7 x i64] }, ptr %t91, i32 0, i32 1
  store { %"compiler/source:Span", i32, { i64, [4 x i64] } } %t98, ptr %t99
  %t100 = load { i64, [7 x i64] }, ptr %t91
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t88, { i64, [7 x i64] } %t100)
  br label %bb18
bb18:
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t104 = load i32, ptr %l5, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t103, i32 %t104)
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eaway(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i64
  %l12 = alloca { i64, [4 x i64] }
  %rv = alloca { i64, [4 x i64] }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 4
  %t4 = load i64, ptr %t3, !tbaa !24
  store i64 %t4, ptr %l3, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/lower:lowering", ptr %t6, i32 0, i32 4
  store i64 %a1, ptr %t10, !tbaa !24
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t16 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v1, ptr %t11, ptr %a2)
  store { i64, [4 x i64] } %t16, ptr %l12
  br label %bb1
bb1:
  %t17 = load { i64, [4 x i64] }, ptr %l12
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t19 = load i64, ptr %l3, !tbaa !24
  %t22 = getelementptr %"compiler/lower:lowering", ptr %t18, i32 0, i32 4
  store i64 %t19, ptr %t22, !tbaa !24
  store { i64, [4 x i64] } %t17, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2ebang(ptr %v0, ptr %a0, { i64, [4 x i64] } %a1, i32 %a2, %"compiler/source:Span" %a3, i32 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i32
  %l13 = alloca i32
  %l18 = alloca { i64, ptr }
  %l24 = alloca i64
  %l27 = alloca i64
  %l47 = alloca i32
  %l50 = alloca i32
  %l55 = alloca { i64, ptr }
  %l62 = alloca { i64, [4 x i64] }
  %l73 = alloca { i64, ptr }
  %l82 = alloca ptr
  %l83 = alloca %"compiler/source:Span"
  %l84 = alloca i32
  %l87 = alloca { i64, [4 x i64] }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %t109 = alloca { i64, [7 x i64] }, align 8
  %t137 = alloca { i64, [7 x i64] }, align 8
  %t165 = alloca { i64, [7 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a3, ptr %l3
  store i32 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = load %"compiler/source:Span", ptr %l3
  %t7 = call { i64, ptr } @compiler_2flower_2ecompiler_2flower_3alowering_2ebangNames(ptr %v0, ptr %s0, ptr %t1, i32 %a2, %"compiler/source:Span" %t3)
  store { i64, ptr } %t7, ptr %l18
  br label %bb1
bb1:
  %t8 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t8, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t9 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t9, 0
  store i64 %t11, ptr %l7, !tbaa !24
  store i64 2, ptr %l8, !tbaa !24
  %t13 = load i64, ptr %l7, !tbaa !24
  %t14 = load i64, ptr %l6, !tbaa !24
  %t17 = icmp sgt i64 %t13, %t14
  br i1 %t17, label %bb2, label %bb3
bb2:
  %t19 = load i64, ptr %l8, !tbaa !24
  %t21 = icmp sgt i64 %t19, 0
  br i1 %t21, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l24, !tbaa !24
  br label %bb7
bb4:
  %t23 = load i64, ptr %l7, !tbaa !24
  %t24 = load i64, ptr %l6, !tbaa !24
  %t27 = sub i64 %t23, %t24
  %t28 = load i64, ptr %l8, !tbaa !24
  %t31 = add i64 %t27, %t28
  %t33 = sub i64 %t31, 1
  %t34 = load i64, ptr %l8, !tbaa !24
  %t37 = sdiv i64 %t33, %t34
  store i64 %t37, ptr %l27, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l27, !tbaa !24
  br label %bb6
bb6:
  %t39 = load i64, ptr %l27, !tbaa !24
  store i64 %t39, ptr %l24, !tbaa !24
  br label %bb7
bb7:
  %t40 = load i64, ptr %l24, !tbaa !24
  store i64 %t40, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t41 = load i64, ptr %l10, !tbaa !24
  %t42 = load i64, ptr %l9, !tbaa !24
  %t45 = icmp slt i64 %t41, %t42
  %t47 = xor i1 %t45, true
  br i1 %t47, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb20
bb10:
  br label %bb11
bb11:
  %t49 = load i64, ptr %l6, !tbaa !24
  %t50 = load i64, ptr %l10, !tbaa !24
  %t51 = load i64, ptr %l8, !tbaa !24
  %t54 = mul i64 %t50, %t51
  %t57 = add i64 %t49, %t54
  store i64 %t57, ptr %l11, !tbaa !24
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/lower:lowering", ptr %t59, i32 0, i32 3
  %t63 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t61)
  store i32 %t63, ptr %l47
  br label %bb12
bb12:
  %t64 = load i32, ptr %l47, !tbaa !23
  store i32 %t64, ptr %l12, !tbaa !23
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/lower:lowering", ptr %t65, i32 0, i32 3
  %t69 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t67)
  store i32 %t69, ptr %l50
  br label %bb13
bb13:
  %t70 = load i32, ptr %l50, !tbaa !23
  store i32 %t70, ptr %l13, !tbaa !23
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t72 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t74 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t74, ptr %l55, !tbaa !27
  %t75 = load i64, ptr %l11, !tbaa !24
  %t77 = getelementptr { i64, ptr }, ptr %l55, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !27
  %t79 = getelementptr { i64, [4 x i64] }, ptr %t78, i64 %t75
  %t80 = load { i64, [4 x i64] }, ptr %t79
  %t82 = insertvalue [2 x { i64, [4 x i64] }] undef, { i64, [4 x i64] } %a1, 0
  %t84 = insertvalue [2 x { i64, [4 x i64] }] %t82, { i64, [4 x i64] } %t80, 1
  %t86 = load ptr, ptr @__olang_prog_scope
  %t87 = call ptr @__olang_scope_alloc(ptr %t86, i64 80)
  store [2 x { i64, [4 x i64] }] %t84, ptr %t87
  %t88 = insertvalue { i64, ptr } undef, i64 2, 0
  %t89 = insertvalue { i64, ptr } %t88, ptr %t87, 1
  %t91 = extractvalue { i64, ptr } %t89, 0
  %t92 = extractvalue { i64, ptr } %t89, 1
  %t93 = mul i64 %t91, 40
  %t94 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t93)
  call void @llvm.memcpy.p0.p0.i64(ptr %t94, ptr %t92, i64 %t93, i1 false)
  %t95 = insertvalue { i64, ptr } undef, i64 %t91, 0
  %t96 = insertvalue { i64, ptr } %t95, ptr %t94, 1
  %t97 = load %"compiler/source:Span", ptr %l3
  %t103 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s2, ptr %t71, i32 13, i32 %t72, { i64, ptr } %t96, %"compiler/source:Span" %t97)
  store { i64, [4 x i64] } %t103, ptr %l62
  br label %bb14
bb14:
  %t104 = load { i64, [4 x i64] }, ptr %l62
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t107 = load i32, ptr %l12, !tbaa !23
  %t108 = load i32, ptr %l13, !tbaa !23
  store { i64, [7 x i64] } zeroinitializer, ptr %t109
  %t110 = getelementptr { i64, [7 x i64] }, ptr %t109, i32 0, i32 0
  store i64 2, ptr %t110
  %t112 = insertvalue { { i64, [4 x i64] }, i32, i32 } undef, { i64, [4 x i64] } %t104, 0
  %t114 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t112, i32 %t107, 1
  %t116 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t114, i32 %t108, 2
  %t117 = getelementptr { i64, [7 x i64] }, ptr %t109, i32 0, i32 1
  store { { i64, [4 x i64] }, i32, i32 } %t116, ptr %t117
  %t118 = load { i64, [7 x i64] }, ptr %t109
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t105, { i64, [7 x i64] } %t118)
  br label %bb15
bb15:
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t122 = load i32, ptr %l12, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t121, i32 %t122)
  br label %bb16
bb16:
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t126 = load %"compiler/source:Span", ptr %l3
  %t127 = load i32, ptr %l4
  %t128 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t128, ptr %l73, !tbaa !27
  %t129 = load i64, ptr %l11, !tbaa !24
  %t131 = add i64 %t129, 1
  %t133 = getelementptr { i64, ptr }, ptr %l73, i32 0, i32 1
  %t134 = load ptr, ptr %t133, !tbaa !27
  %t135 = getelementptr { i64, [4 x i64] }, ptr %t134, i64 %t131
  %t136 = load { i64, [4 x i64] }, ptr %t135
  store { i64, [7 x i64] } zeroinitializer, ptr %t137
  %t138 = getelementptr { i64, [7 x i64] }, ptr %t137, i32 0, i32 0
  store i64 8, ptr %t138
  %t140 = insertvalue { %"compiler/source:Span", i32, { i64, [4 x i64] } } undef, %"compiler/source:Span" %t126, 0
  %t142 = insertvalue { %"compiler/source:Span", i32, { i64, [4 x i64] } } %t140, i32 %t127, 1
  %t144 = insertvalue { %"compiler/source:Span", i32, { i64, [4 x i64] } } %t142, { i64, [4 x i64] } %t136, 2
  %t145 = getelementptr { i64, [7 x i64] }, ptr %t137, i32 0, i32 1
  store { %"compiler/source:Span", i32, { i64, [4 x i64] } } %t144, ptr %t145
  %t146 = load { i64, [7 x i64] }, ptr %t137
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t125, { i64, [7 x i64] } %t146)
  br label %bb17
bb17:
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t150 = load i32, ptr %l13, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t149, i32 %t150)
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s2)
  br label %bb19
bb19:
  %t153 = load i64, ptr %l10, !tbaa !24
  %t155 = add i64 %t153, 1
  store i64 %t155, ptr %l10, !tbaa !24
  br label %bb8
bb20:
  %t157 = load ptr, ptr %l0, !tbaa !29
  store ptr %t157, ptr %l82, !tbaa !29
  %t158 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t158, ptr %l83
  %t159 = load i32, ptr %l4
  store i32 %t159, ptr %l84
  %t160 = load ptr, ptr %l0, !tbaa !29
  %t161 = load %"compiler/source:Span", ptr %l3
  %t164 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2etextData(ptr %v0, ptr %s0, ptr %t160, { i64, ptr } { i64 15, ptr @.d9 }, %"compiler/source:Span" %t161)
  store { i64, [4 x i64] } %t164, ptr %l87
  br label %bb21
bb21:
  store { i64, [7 x i64] } zeroinitializer, ptr %t165
  %t166 = getelementptr { i64, [7 x i64] }, ptr %t165, i32 0, i32 0
  store i64 8, ptr %t166
  %t167 = load %"compiler/source:Span", ptr %l83
  %t168 = insertvalue { %"compiler/source:Span", i32, { i64, [4 x i64] } } undef, %"compiler/source:Span" %t167, 0
  %t169 = load i32, ptr %l84
  %t170 = insertvalue { %"compiler/source:Span", i32, { i64, [4 x i64] } } %t168, i32 %t169, 1
  %t171 = load { i64, [4 x i64] }, ptr %l87
  %t172 = insertvalue { %"compiler/source:Span", i32, { i64, [4 x i64] } } %t170, { i64, [4 x i64] } %t171, 2
  %t173 = getelementptr { i64, [7 x i64] }, ptr %t165, i32 0, i32 1
  store { %"compiler/source:Span", i32, { i64, [4 x i64] } } %t172, ptr %t173
  %t174 = load { i64, [7 x i64] }, ptr %t165
  %t175 = load ptr, ptr %l82, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t175, { i64, [7 x i64] } %t174)
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2flower_2ecompiler_2flower_3alowering_2ebangNames(ptr %v0, ptr %v1, ptr %a0, i32 %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i32
  %l13 = alloca i32
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l29 = alloca { i64, ptr }
  %l30 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l37 = alloca i64
  %l40 = alloca i64
  %l59 = alloca { i64, ptr }
  %l62 = alloca i32
  %l65 = alloca i32
  %l71 = alloca i32
  %l72 = alloca { i64, ptr }
  %l73 = alloca { i64, ptr }
  %l74 = alloca i64
  %l75 = alloca { i64, ptr }
  %l78 = alloca i64
  %l85 = alloca ptr
  %l89 = alloca i1
  %l91 = alloca i1
  %l92 = alloca i64
  %l94 = alloca i64
  %l96 = alloca i64
  %l98 = alloca i64
  %l99 = alloca i32
  %l100 = alloca { i64, ptr }
  %l102 = alloca i64
  %l105 = alloca i64
  %l106 = alloca i64
  %l111 = alloca { i64, ptr }
  %l113 = alloca i64
  %l119 = alloca { i64, ptr }
  %l125 = alloca i64
  %l128 = alloca i64
  %l154 = alloca ptr
  %l155 = alloca ptr
  %l156 = alloca { i64, ptr }
  %l158 = alloca ptr
  %l161 = alloca i32
  %l162 = alloca { i64, ptr }
  %l165 = alloca { i64, ptr }
  %l168 = alloca { i64, ptr }
  %l172 = alloca { i64, [4 x i64] }
  %l178 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  %t289 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t6 = load ptr, ptr %l3, !tbaa !29
  %t10 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t6, i32 %a1)
  store { i64, ptr } %t10, ptr %l29
  br label %bb1
bb1:
  %t11 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fmir_3aOperand_3e_2ector(ptr %s0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t12, ptr %l30
  br label %bb2
bb2:
  %t13 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l30
  %t14 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t13, ptr %t14
  store ptr %t14, ptr %l5, !tbaa !29
  store i64 0, ptr %l6, !tbaa !24
  %t16 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t18 = extractvalue { i64, ptr } %t16, 0
  store i64 %t18, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t20 = load i64, ptr %l7, !tbaa !24
  %t21 = load i64, ptr %l6, !tbaa !24
  %t24 = icmp sgt i64 %t20, %t21
  br i1 %t24, label %bb3, label %bb4
bb3:
  %t26 = load i64, ptr %l8, !tbaa !24
  %t28 = icmp sgt i64 %t26, 0
  br i1 %t28, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l37, !tbaa !24
  br label %bb8
bb5:
  %t30 = load i64, ptr %l7, !tbaa !24
  %t31 = load i64, ptr %l6, !tbaa !24
  %t34 = sub i64 %t30, %t31
  %t35 = load i64, ptr %l8, !tbaa !24
  %t38 = add i64 %t34, %t35
  %t40 = sub i64 %t38, 1
  %t41 = load i64, ptr %l8, !tbaa !24
  %t44 = sdiv i64 %t40, %t41
  store i64 %t44, ptr %l40, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l40, !tbaa !24
  br label %bb7
bb7:
  %t46 = load i64, ptr %l40, !tbaa !24
  store i64 %t46, ptr %l37, !tbaa !24
  br label %bb8
bb8:
  %t47 = load i64, ptr %l37, !tbaa !24
  store i64 %t47, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t48 = load i64, ptr %l10, !tbaa !24
  %t49 = load i64, ptr %l9, !tbaa !24
  %t52 = icmp slt i64 %t48, %t49
  %t54 = xor i1 %t52, true
  br i1 %t54, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb62
bb11:
  br label %bb12
bb12:
  %t56 = load i64, ptr %l6, !tbaa !24
  %t57 = load i64, ptr %l10, !tbaa !24
  %t58 = load i64, ptr %l8, !tbaa !24
  %t61 = mul i64 %t57, %t58
  %t64 = add i64 %t56, %t61
  store i64 %t64, ptr %l11, !tbaa !24
  %t66 = load ptr, ptr %l3, !tbaa !29
  %t67 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t67, ptr %l59, !tbaa !27
  %t68 = load i64, ptr %l11, !tbaa !24
  %t70 = getelementptr { i64, ptr }, ptr %l59, i32 0, i32 1
  %t71 = load ptr, ptr %t70, !tbaa !27
  %t72 = getelementptr i32, ptr %t71, i64 %t68
  %t73 = load i32, ptr %t72, !tbaa !33
  %t76 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t66, i32 %t73)
  store i32 %t76, ptr %l62
  br label %bb13
bb13:
  %t77 = load i32, ptr %l62, !tbaa !23
  store i32 %t77, ptr %l12, !tbaa !23
  %t78 = load ptr, ptr %l3, !tbaa !29
  %t79 = load i32, ptr %l12, !tbaa !23
  %t82 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t78, i32 %t79)
  store i32 %t82, ptr %l65
  br label %bb14
bb14:
  %t83 = load i32, ptr %l65
  %t85 = trunc i64 18 to i32
  %t86 = icmp eq i32 %t83, %t85
  %t88 = xor i1 %t86, true
  br i1 %t88, label %bb15, label %bb16
bb15:
  call void @__olang_scope_close(ptr %s2)
  br label %bb61
bb16:
  br label %bb17
bb17:
  %t90 = load ptr, ptr %l3, !tbaa !29
  %t91 = load i32, ptr %l12, !tbaa !23
  %t94 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t90, i32 %t91)
  store i32 %t94, ptr %l71
  br label %bb18
bb18:
  %t95 = load i32, ptr %l71, !tbaa !23
  store i32 %t95, ptr %l13, !tbaa !23
  store { i64, ptr } { i64 0, ptr @.d10 }, ptr %l72, !tbaa !27
  %t96 = load { i64, ptr }, ptr %l72, !tbaa !27
  store { i64, ptr } %t96, ptr %l73, !tbaa !27
  %t97 = load { i64, ptr }, ptr %l73, !tbaa !27
  %t98 = extractvalue { i64, ptr } %t97, 0
  store i64 %t98, ptr %l74, !tbaa !24
  %t99 = load i64, ptr %l74, !tbaa !24
  %t100 = mul i64 %t99, 1
  %t101 = call ptr @__olang_scope_alloc_zeroed(ptr %s2, i64 %t100)
  %t102 = insertvalue { i64, ptr } undef, i64 %t99, 0
  %t103 = insertvalue { i64, ptr } %t102, ptr %t101, 1
  store { i64, ptr } %t103, ptr %l75, !tbaa !27
  %t104 = getelementptr { i64, ptr }, ptr %l75, i32 0, i32 1
  %t105 = load ptr, ptr %t104, !tbaa !27
  %t106 = getelementptr { i64, ptr }, ptr %l73, i32 0, i32 1
  %t107 = load ptr, ptr %t106, !tbaa !27
  %t108 = load i64, ptr %l74, !tbaa !24
  %t109 = mul i64 %t108, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t105, ptr %t107, i64 %t109, i1 false)
  %t110 = load { i64, ptr }, ptr %l75, !tbaa !27
  store { i64, ptr } %t110, ptr %l14, !tbaa !27
  %t111 = load ptr, ptr %l3, !tbaa !29
  %t112 = load i32, ptr %l13, !tbaa !23
  %t115 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %t111, i32 %t112)
  store i64 %t115, ptr %l78
  br label %bb19
bb19:
  %t116 = load i64, ptr %l78, !tbaa !24
  store i64 %t116, ptr %l15, !tbaa !24
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr %"compiler/lower:lowering", ptr %t117, i32 0, i32 0
  %t120 = load ptr, ptr %t119, !tbaa !29
  %t122 = getelementptr %"compiler/lower:Lowerer", ptr %t120, i32 0, i32 0
  %t123 = load ptr, ptr %t122, !tbaa !29
  %t125 = getelementptr %"compiler/generic:Program", ptr %t123, i32 0, i32 0
  %t126 = load ptr, ptr %t125, !tbaa !29
  %t128 = getelementptr %"compiler/load:Loader", ptr %t126, i32 0, i32 5
  %t129 = load i64, ptr %l15, !tbaa !24
  %t132 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t128, i64 %t129)
  store ptr %t132, ptr %l85
  br label %bb20
bb20:
  %t133 = load ptr, ptr %l85, !tbaa !29
  %t135 = getelementptr %"compiler/load:Module", ptr %t133, i32 0, i32 2
  %t136 = load { i64, ptr }, ptr %t135, !tbaa !27
  store { i64, ptr } %t136, ptr %l16, !tbaa !27
  %t138 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t140 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s2, { i64, ptr } %t138, { i64, ptr } { i64 11, ptr @.d11 })
  store i1 %t140, ptr %l89
  br label %bb21
bb21:
  %t141 = load i1, ptr %l89, !tbaa !21
  %t142 = xor i1 %t141, true
  br i1 %t142, label %bb22, label %bb23
bb22:
  %t144 = load i64, ptr %l15, !tbaa !24
  store i64 %t144, ptr %l92, !tbaa !24
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t147 = call i64 @compiler_2flower_2ecompiler_2flower_3alowering_2emodule(ptr %v0, ptr %t145)
  store i64 %t147, ptr %l94
  br label %bb24
bb23:
  store i1 false, ptr %l91, !tbaa !21
  br label %bb25
bb24:
  %t148 = load i64, ptr %l92, !tbaa !24
  %t149 = load i64, ptr %l94, !tbaa !24
  %t150 = icmp ne i64 %t148, %t149
  store i1 %t150, ptr %l91, !tbaa !21
  br label %bb25
bb25:
  %t152 = load i1, ptr %l91, !tbaa !21
  br i1 %t152, label %bb26, label %bb27
bb26:
  store %olang.scope zeroinitializer, ptr %s4
  %t153 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t155 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindLast(ptr %v0, ptr %s4, { i64, ptr } %t153, { i64, ptr } { i64 1, ptr @.d12 })
  %t156 = extractvalue { i32, i64 } %t155, 1
  %t157 = extractvalue { i32, i64 } %t155, 0
  store i32 %t157, ptr %l99
  %t158 = icmp ne i32 %t157, 0
  br i1 %t158, label %bb29, label %ok.159
ok.159:
  store i64 %t156, ptr %l98
  br label %bb28
bb27:
  br label %bb41
bb28:
  %t160 = load i64, ptr %l98, !tbaa !24
  store i64 %t160, ptr %l96, !tbaa !24
  br label %bb31
bb29:
  br label %bb30
bb30:
  store i64 -1, ptr %l96, !tbaa !24
  br label %bb31
bb31:
  %t161 = load i64, ptr %l96, !tbaa !24
  %t162 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t162, ptr %l100, !tbaa !27
  %t165 = add i64 %t161, 1
  store i64 %t165, ptr %l102, !tbaa !24
  %t166 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t169 = extractvalue { i64, ptr } %t166, 0
  store i64 %t169, ptr %l105, !tbaa !24
  %t170 = load { i64, ptr }, ptr %l100, !tbaa !27
  %t171 = extractvalue { i64, ptr } %t170, 0
  store i64 %t171, ptr %l106, !tbaa !24
  %t172 = load i64, ptr %l102, !tbaa !24
  %t173 = icmp sge i64 %t172, 0
  br i1 %t173, label %bb32, label %bb33
bb32:
  %t175 = load i64, ptr %l102, !tbaa !24
  %t176 = load i64, ptr %l105, !tbaa !24
  %t177 = icmp sle i64 %t175, %t176
  br i1 %t177, label %bb34, label %bb35
bb33:
  call void @__olang_check_failed(ptr @olang_loc_1b3f3d8cac740dce_641dfb8cea384ff2)
  unreachable
bb34:
  %t179 = load i64, ptr %l105, !tbaa !24
  %t180 = load i64, ptr %l106, !tbaa !24
  %t181 = icmp sle i64 %t179, %t180
  br i1 %t181, label %bb36, label %bb37
bb35:
  call void @__olang_check_failed(ptr @olang_loc_1b3f3d8cac740dce_641dfb8cea384ff2)
  unreachable
bb36:
  %t183 = getelementptr { i64, ptr }, ptr %l100, i32 0, i32 1
  %t184 = load ptr, ptr %t183, !tbaa !27
  %t185 = load i64, ptr %l102, !tbaa !24
  %t186 = load i64, ptr %l105, !tbaa !24
  %t187 = getelementptr i8, ptr %t184, i64 %t185
  %t188 = sub i64 %t186, %t185
  %t189 = insertvalue { i64, ptr } undef, i64 %t188, 0
  %t190 = insertvalue { i64, ptr } %t189, ptr %t187, 1
  %t192 = extractvalue { i64, ptr } %t190, 1
  %t193 = extractvalue { i64, ptr } %t190, 0
  %t194 = extractvalue { i64, ptr } { i64 1, ptr @.d13 }, 1
  %t195 = extractvalue { i64, ptr } { i64 1, ptr @.d13 }, 0
  %t196 = add i64 %t193, %t195
  %t197 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t196)
  call void @olang_textcopy(ptr %t197, ptr %t192, i64 %t193)
  %t198 = getelementptr i8, ptr %t197, i64 %t193
  call void @olang_textcopy(ptr %t198, ptr %t194, i64 %t195)
  %t199 = insertvalue { i64, ptr } undef, i64 %t196, 0
  %t200 = insertvalue { i64, ptr } %t199, ptr %t197, 1
  store { i64, ptr } %t200, ptr %l111, !tbaa !27
  %t201 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t202 = extractvalue { i64, ptr } %t201, 0
  %t203 = load { i64, ptr }, ptr %l111, !tbaa !27
  %t204 = extractvalue { i64, ptr } %t203, 0
  store i64 %t204, ptr %l113, !tbaa !24
  %t206 = load i64, ptr %l113, !tbaa !24
  %t207 = icmp eq i64 %t202, %t206
  br i1 %t207, label %bb38, label %bb39
bb37:
  call void @__olang_check_failed(ptr @olang_loc_1b3f3d8cac740dce_641dfb8cea384ff2)
  unreachable
bb38:
  %t209 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t210 = load ptr, ptr %t209, !tbaa !27
  %t211 = getelementptr { i64, ptr }, ptr %l111, i32 0, i32 1
  %t212 = load ptr, ptr %t211, !tbaa !27
  %t213 = load i64, ptr %l113, !tbaa !24
  %t214 = mul i64 %t213, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t210, ptr %t212, i64 %t214, i1 false)
  br label %bb40
bb39:
  %t215 = load { i64, ptr }, ptr %l111, !tbaa !27
  store { i64, ptr } %t215, ptr %l14, !tbaa !27
  br label %bb40
bb40:
  call void @__olang_scope_close(ptr %s4)
  br label %bb41
bb41:
  %t216 = load ptr, ptr %l0, !tbaa !29
  %t218 = getelementptr %"compiler/lower:lowering", ptr %t216, i32 0, i32 0
  %t219 = load ptr, ptr %t218, !tbaa !29
  %t221 = getelementptr %"compiler/lower:Lowerer", ptr %t219, i32 0, i32 0
  %t222 = load ptr, ptr %t221, !tbaa !29
  %t223 = load i32, ptr %l13, !tbaa !23
  %t226 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorWords(ptr %v0, ptr %t222, i32 %t223)
  store { i64, ptr } %t226, ptr %l119
  br label %bb42
bb42:
  %t227 = load { i64, ptr }, ptr %l119, !tbaa !27
  store { i64, ptr } %t227, ptr %l18, !tbaa !27
  store i64 0, ptr %l19, !tbaa !24
  %t228 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t230 = extractvalue { i64, ptr } %t228, 0
  store i64 %t230, ptr %l20, !tbaa !24
  store i64 1, ptr %l21, !tbaa !24
  %t232 = load i64, ptr %l20, !tbaa !24
  %t233 = load i64, ptr %l19, !tbaa !24
  %t236 = icmp sgt i64 %t232, %t233
  br i1 %t236, label %bb43, label %bb44
bb43:
  %t238 = load i64, ptr %l21, !tbaa !24
  %t240 = icmp sgt i64 %t238, 0
  br i1 %t240, label %bb45, label %bb46
bb44:
  store i64 0, ptr %l125, !tbaa !24
  br label %bb48
bb45:
  %t242 = load i64, ptr %l20, !tbaa !24
  %t243 = load i64, ptr %l19, !tbaa !24
  %t246 = sub i64 %t242, %t243
  %t247 = load i64, ptr %l21, !tbaa !24
  %t250 = add i64 %t246, %t247
  %t252 = sub i64 %t250, 1
  %t253 = load i64, ptr %l21, !tbaa !24
  %t256 = sdiv i64 %t252, %t253
  store i64 %t256, ptr %l128, !tbaa !24
  br label %bb47
bb46:
  store i64 0, ptr %l128, !tbaa !24
  br label %bb47
bb47:
  %t258 = load i64, ptr %l128, !tbaa !24
  store i64 %t258, ptr %l125, !tbaa !24
  br label %bb48
bb48:
  %t259 = load i64, ptr %l125, !tbaa !24
  store i64 %t259, ptr %l22, !tbaa !24
  store i64 0, ptr %l23, !tbaa !24
  br label %bb49
bb49:
  store %olang.scope zeroinitializer, ptr %s7
  %t260 = load i64, ptr %l23, !tbaa !24
  %t261 = load i64, ptr %l22, !tbaa !24
  %t264 = icmp slt i64 %t260, %t261
  %t266 = xor i1 %t264, true
  br i1 %t266, label %bb50, label %bb51
bb50:
  call void @__olang_scope_close(ptr %s7)
  br label %bb60
bb51:
  br label %bb52
bb52:
  %t268 = load i64, ptr %l19, !tbaa !24
  %t269 = load i64, ptr %l23, !tbaa !24
  %t270 = load i64, ptr %l21, !tbaa !24
  %t273 = mul i64 %t269, %t270
  %t276 = add i64 %t268, %t273
  store i64 %t276, ptr %l24, !tbaa !24
  %t278 = load ptr, ptr %l5, !tbaa !29
  %t279 = load i32, ptr @G_2ecompiler_2fmir_2eI32T, !tbaa !23
  %t280 = load i64, ptr %l11, !tbaa !24
  %t282 = add i64 %t280, 1
  %t284 = shl i64 %t282, 16
  %t285 = load i64, ptr %l24, !tbaa !24
  %t288 = or i64 %t284, %t285
  store { i64, [4 x i64] } zeroinitializer, ptr %t289
  %t290 = getelementptr { i64, [4 x i64] }, ptr %t289, i32 0, i32 0
  store i64 2, ptr %t290
  %t292 = insertvalue { i32, i64 } undef, i32 %t279, 0
  %t294 = insertvalue { i32, i64 } %t292, i64 %t288, 1
  %t295 = getelementptr { i64, [4 x i64] }, ptr %t289, i32 0, i32 1
  store { i32, i64 } %t294, ptr %t295
  %t296 = load { i64, [4 x i64] }, ptr %t289
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aOperand_3e_2ePush_3ccompiler_2fmir_3aOperand_3e(ptr %s0, ptr %t278, { i64, [4 x i64] } %t296)
  br label %bb53
bb53:
  %t299 = load ptr, ptr %l5, !tbaa !29
  store ptr %t299, ptr %l154, !tbaa !29
  %t300 = load ptr, ptr %l0, !tbaa !29
  store ptr %t300, ptr %l155, !tbaa !29
  %t301 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t301, ptr %l156, !tbaa !27
  %t302 = load ptr, ptr %l3, !tbaa !29
  %t304 = getelementptr %"compiler/types:Table", ptr %t302, i32 0, i32 0
  %t305 = load ptr, ptr %t304, !tbaa !29
  store ptr %t305, ptr %l158, !tbaa !29
  %t306 = load ptr, ptr %l3, !tbaa !29
  %t307 = load i32, ptr %l13, !tbaa !23
  %t310 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %t306, i32 %t307)
  store i32 %t310, ptr %l161
  br label %bb54
bb54:
  %t311 = load ptr, ptr %l158, !tbaa !29
  %t312 = load i32, ptr %l161, !tbaa !23
  %t313 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t311, i32 %t312)
  store { i64, ptr } %t313, ptr %l162
  br label %bb55
bb55:
  %t314 = load ptr, ptr %l3, !tbaa !29
  %t316 = getelementptr %"compiler/types:Table", ptr %t314, i32 0, i32 0
  %t317 = load ptr, ptr %t316, !tbaa !29
  %t318 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t318, ptr %l165, !tbaa !27
  %t319 = load i64, ptr %l24, !tbaa !24
  %t321 = getelementptr { i64, ptr }, ptr %l165, i32 0, i32 1
  %t322 = load ptr, ptr %t321, !tbaa !27
  %t323 = getelementptr i32, ptr %t322, i64 %t319
  %t324 = load i32, ptr %t323, !tbaa !33
  %t327 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t317, i32 %t324)
  store { i64, ptr } %t327, ptr %l168
  br label %bb56
bb56:
  %t328 = load { i64, ptr }, ptr %l156, !tbaa !27
  %t329 = extractvalue { i64, ptr } %t328, 1
  %t330 = extractvalue { i64, ptr } %t328, 0
  %t331 = load { i64, ptr }, ptr %l162, !tbaa !27
  %t332 = extractvalue { i64, ptr } %t331, 1
  %t333 = extractvalue { i64, ptr } %t331, 0
  %t334 = add i64 %t330, %t333
  %t335 = extractvalue { i64, ptr } { i64 1, ptr @.d14 }, 1
  %t336 = extractvalue { i64, ptr } { i64 1, ptr @.d14 }, 0
  %t337 = add i64 %t334, %t336
  %t338 = load { i64, ptr }, ptr %l168, !tbaa !27
  %t339 = extractvalue { i64, ptr } %t338, 1
  %t340 = extractvalue { i64, ptr } %t338, 0
  %t341 = add i64 %t337, %t340
  %t342 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t341)
  call void @olang_textcopy(ptr %t342, ptr %t329, i64 %t330)
  %t343 = getelementptr i8, ptr %t342, i64 %t330
  call void @olang_textcopy(ptr %t343, ptr %t332, i64 %t333)
  %t344 = getelementptr i8, ptr %t343, i64 %t333
  call void @olang_textcopy(ptr %t344, ptr %t335, i64 %t336)
  %t345 = getelementptr i8, ptr %t344, i64 %t336
  call void @olang_textcopy(ptr %t345, ptr %t339, i64 %t340)
  %t346 = insertvalue { i64, ptr } undef, i64 %t341, 0
  %t347 = insertvalue { i64, ptr } %t346, ptr %t342, 1
  %t349 = extractvalue { i64, ptr } %t347, 0
  %t350 = extractvalue { i64, ptr } %t347, 1
  %t351 = mul i64 %t349, 1
  %t352 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t351)
  call void @llvm.memcpy.p0.p0.i64(ptr %t352, ptr %t350, i64 %t351, i1 false)
  %t353 = insertvalue { i64, ptr } undef, i64 %t349, 0
  %t354 = insertvalue { i64, ptr } %t353, ptr %t352, 1
  %t356 = load ptr, ptr %l155, !tbaa !29
  %t359 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2etextData(ptr %v0, ptr %s7, ptr %t356, { i64, ptr } %t354, %"compiler/source:Span" %a2)
  store { i64, [4 x i64] } %t359, ptr %l172
  br label %bb57
bb57:
  %t360 = load ptr, ptr %l154, !tbaa !29
  %t361 = load { i64, [4 x i64] }, ptr %l172
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aOperand_3e_2ePush_3ccompiler_2fmir_3aOperand_3e(ptr %s0, ptr %t360, { i64, [4 x i64] } %t361)
  br label %bb58
bb58:
  call void @__olang_scope_close(ptr %s7)
  br label %bb59
bb59:
  %t362 = load i64, ptr %l23, !tbaa !24
  %t364 = add i64 %t362, 1
  store i64 %t364, ptr %l23, !tbaa !24
  br label %bb49
bb60:
  call void @__olang_scope_close(ptr %s2)
  br label %bb61
bb61:
  %t366 = load i64, ptr %l10, !tbaa !24
  %t368 = add i64 %t366, 1
  store i64 %t368, ptr %l10, !tbaa !24
  br label %bb9
bb62:
  %t370 = load ptr, ptr %l5, !tbaa !29
  %t372 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aOperand_3e_2eToArray_3ccompiler_2fmir_3aOperand_3e(ptr %s0, ptr %v1, ptr %t370)
  store { i64, ptr } %t372, ptr %l178
  br label %bb63
bb63:
  call void @__olang_scope_close(ptr %s0)
  %t373 = load { i64, ptr }, ptr %l178, !tbaa !27
  store { i64, ptr } %t373, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { { i64, [5 x i64] }, i32 } @compiler_2flower_2ecompiler_2flower_3alowering_2ebodyCallee(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l1 = alloca i32
  %l2 = alloca i32
  %l8 = alloca ptr
  %rv = alloca { { i64, [5 x i64] }, i32 }
  %t19 = alloca { i64, [1 x i64] }, align 8
  %t26 = alloca { i64, [5 x i64] }, align 8
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/lower:lowering", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/lower:Lowerer", ptr %t4, i32 0, i32 1
  %t7 = load i32, ptr %l1, !tbaa !23
  %t9 = sext i32 %t7 to i64
  %t12 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t6, i64 %t9)
  store ptr %t12, ptr %l8
  br label %bb1
bb1:
  %t13 = load ptr, ptr %l8, !tbaa !29
  %t15 = getelementptr %"compiler/typed:Body", ptr %t13, i32 0, i32 2
  %t16 = load i32, ptr %t15, !tbaa !23
  store i32 %t16, ptr %l2, !tbaa !23
  %t18 = load i32, ptr %l1, !tbaa !23
  store { i64, [1 x i64] } zeroinitializer, ptr %t19
  %t20 = getelementptr { i64, [1 x i64] }, ptr %t19, i32 0, i32 0
  store i64 0, ptr %t20
  %t22 = insertvalue { i32 } undef, i32 %t18, 0
  %t23 = getelementptr { i64, [1 x i64] }, ptr %t19, i32 0, i32 1
  store { i32 } %t22, ptr %t23
  %t24 = load { i64, [1 x i64] }, ptr %t19
  %t25 = load i32, ptr %l2, !tbaa !23
  store { i64, [5 x i64] } zeroinitializer, ptr %t26
  %t27 = getelementptr { i64, [5 x i64] }, ptr %t26, i32 0, i32 0
  store i64 0, ptr %t27
  %t29 = insertvalue { { i64, [1 x i64] }, i32 } undef, { i64, [1 x i64] } %t24, 0
  %t31 = insertvalue { { i64, [1 x i64] }, i32 } %t29, i32 %t25, 1
  %t32 = getelementptr { i64, [5 x i64] }, ptr %t26, i32 0, i32 1
  store { { i64, [1 x i64] }, i32 } %t31, ptr %t32
  %t33 = load { i64, [5 x i64] }, ptr %t26
  %t34 = load i32, ptr %l2, !tbaa !23
  %t36 = insertvalue { { i64, [5 x i64] }, i32 } undef, { i64, [5 x i64] } %t33, 0
  %t38 = insertvalue { { i64, [5 x i64] }, i32 } %t36, i32 %t34, 1
  store { { i64, [5 x i64] }, i32 } %t38, ptr %rv
  br label %ret
ret:
  %rr = load { { i64, [5 x i64] }, i32 }, ptr %rv
  ret { { i64, [5 x i64] }, i32 } %rr
}

define dso_local { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ebuilt(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l5 = alloca i1
  %l8 = alloca i1
  %l18 = alloca { i64, ptr }
  %l22 = alloca { i64, [1 x i64] }
  %rv = alloca { i64, [1 x i64] }
  %t28 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 19
  %t4 = load i1, ptr %t3, !tbaa !21
  %t6 = xor i1 %t4, true
  br i1 %t6, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l5, !tbaa !21
  br label %bb3
bb2:
  %t8 = load i32, ptr %l1, !tbaa !23
  %t10 = icmp slt i32 %t8, 0
  store i1 %t10, ptr %l5, !tbaa !21
  br label %bb3
bb3:
  %t12 = load i1, ptr %l5, !tbaa !21
  br i1 %t12, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb6
bb5:
  %t13 = load i32, ptr %l1, !tbaa !23
  %t15 = sext i32 %t13 to i64
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/lower:lowering", ptr %t16, i32 0, i32 22
  %t19 = getelementptr %"compiler/typed:Plan", ptr %t18, i32 0, i32 0
  %t20 = load { i64, ptr }, ptr %t19, !tbaa !27
  %t22 = extractvalue { i64, ptr } %t20, 0
  %t25 = icmp sge i64 %t15, %t22
  store i1 %t25, ptr %l8, !tbaa !21
  br label %bb6
bb6:
  %t27 = load i1, ptr %l8, !tbaa !21
  br i1 %t27, label %bb7, label %bb8
bb7:
  store { i64, [1 x i64] } zeroinitializer, ptr %t28
  %t29 = getelementptr { i64, [1 x i64] }, ptr %t28, i32 0, i32 0
  store i64 2, ptr %t29
  %t30 = load { i64, [1 x i64] }, ptr %t28
  store { i64, [1 x i64] } %t30, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/lower:lowering", ptr %t33, i32 0, i32 22
  %t36 = getelementptr %"compiler/typed:Plan", ptr %t35, i32 0, i32 0
  %t37 = load { i64, ptr }, ptr %t36, !tbaa !27
  store { i64, ptr } %t37, ptr %l18, !tbaa !27
  %t38 = load i32, ptr %l1, !tbaa !23
  %t40 = sext i32 %t38 to i64
  %t42 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = getelementptr { i64, [1 x i64] }, ptr %t43, i64 %t40
  %t45 = load { i64, [1 x i64] }, ptr %t44
  %t48 = call { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2escopeRef(ptr %v0, ptr %t32, { i64, [1 x i64] } %t45)
  store { i64, [1 x i64] } %t48, ptr %l22
  br label %bb10
bb10:
  %t49 = load { i64, [1 x i64] }, ptr %l22
  store { i64, [1 x i64] } %t49, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [1 x i64] }, ptr %rv
  ret { i64, [1 x i64] } %rr
}

define dso_local { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ecall(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca ptr
  %l5 = alloca { { i64, [5 x i64] }, i32 }
  %l6 = alloca { i64, [5 x i64] }
  %l7 = alloca i32
  %l8 = alloca %"compiler/mir:Range"
  %l9 = alloca i32
  %l10 = alloca %"compiler/mir:Range"
  %l11 = alloca i32
  %l12 = alloca i32
  %l13 = alloca i32
  %l14 = alloca i32
  %l15 = alloca i32
  %l21 = alloca i1
  %l29 = alloca { i64, [4 x i64] }
  %l34 = alloca { { i64, [5 x i64] }, i32 }
  %l44 = alloca %"compiler/mir:Range"
  %l50 = alloca i32
  %l51 = alloca ptr
  %l55 = alloca i64
  %l58 = alloca %"compiler/mir:Range"
  %l61 = alloca i32
  %l66 = alloca i1
  %l70 = alloca ptr
  %l74 = alloca i32
  %l78 = alloca i32
  %l81 = alloca i32
  %l86 = alloca { i64, ptr }
  %l92 = alloca i32
  %l95 = alloca i32
  %l97 = alloca ptr
  %l98 = alloca { i64, [5 x i64] }
  %l99 = alloca %"compiler/mir:Range"
  %l100 = alloca %"compiler/mir:Range"
  %l104 = alloca %"compiler/mir:Place"
  %l106 = alloca %"compiler/mir:Place"
  %l114 = alloca %"compiler/mir:Call"
  %l115 = alloca i32
  %l125 = alloca ptr
  %l127 = alloca %"compiler/mir:Place"
  %l147 = alloca %"compiler/mir:Place"
  %s0 = alloca %olang.scope
  %rv = alloca { i64, [4 x i64] }
  %t51 = alloca { i64, [4 x i64] }, align 8
  %t70 = alloca { i64, [4 x i64] }, align 8
  %t211 = alloca { i64, [7 x i64] }, align 8
  %t235 = alloca { i64, [4 x i64] }, align 8
  %t259 = alloca { i64, [4 x i64] }, align 8
  %t262 = alloca { i64, [7 x i64] }, align 8
  %t274 = alloca { i64, [4 x i64] }, align 8
  %t284 = alloca { i64, [4 x i64] }, align 8
  %t291 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  store %"compiler/source:Span" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t6 = load ptr, ptr %l1, !tbaa !29
  %t8 = getelementptr %"compiler/typed:Call", ptr %t6, i32 0, i32 4
  %t9 = load i1, ptr %t8, !tbaa !21
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = load ptr, ptr %l1, !tbaa !29
  %t13 = getelementptr %"compiler/typed:Call", ptr %t11, i32 0, i32 1
  %t14 = load { i64, ptr }, ptr %t13, !tbaa !27
  %t16 = extractvalue { i64, ptr } %t14, 0
  %t18 = icmp eq i64 %t16, 0
  store i1 %t18, ptr %l21, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l21, !tbaa !21
  br label %bb3
bb3:
  %t20 = load i1, ptr %l21, !tbaa !21
  br i1 %t20, label %bb4, label %bb5
bb4:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load i32, ptr %l2, !tbaa !23
  %t23 = load %"compiler/source:Span", ptr %l3
  %t27 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ezero(ptr %v0, ptr %t21, i32 %t22, %"compiler/source:Span" %t23)
  store { i64, [4 x i64] } %t27, ptr %l29
  br label %bb6
bb5:
  br label %bb7
bb6:
  call void @__olang_scope_close(ptr %s0)
  %t28 = load { i64, [4 x i64] }, ptr %l29
  store { i64, [4 x i64] } %t28, ptr %rv
  br label %ret
bb7:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t30 = load ptr, ptr %l1, !tbaa !29
  %t32 = getelementptr %"compiler/typed:Call", ptr %t30, i32 0, i32 0
  %t33 = load ptr, ptr %t32, !tbaa !29
  %t34 = load %"compiler/source:Span", ptr %l3
  %t38 = call { { i64, [5 x i64] }, i32 } @compiler_2flower_2ecompiler_2flower_3alowering_2ecallee(ptr %v0, ptr %v1, ptr %t29, ptr %t33, %"compiler/source:Span" %t34)
  store { { i64, [5 x i64] }, i32 } %t38, ptr %l34
  br label %bb8
bb8:
  %t39 = load { { i64, [5 x i64] }, i32 }, ptr %l34
  store { { i64, [5 x i64] }, i32 } %t39, ptr %l5
  %t40 = getelementptr { { i64, [5 x i64] }, i32 }, ptr %l5, i32 0, i32 0
  %t41 = load { i64, [5 x i64] }, ptr %t40
  store { i64, [5 x i64] } %t41, ptr %l6
  %t43 = getelementptr { { i64, [5 x i64] }, i32 }, ptr %l5, i32 0, i32 1
  %t44 = load i32, ptr %t43, !tbaa !23
  store i32 %t44, ptr %l7, !tbaa !23
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/lower:lowering", ptr %t46, i32 0, i32 7
  %t49 = load i1, ptr %t48, !tbaa !21
  br i1 %t49, label %bb9, label %bb10
bb9:
  store { i64, [4 x i64] } zeroinitializer, ptr %t51
  %t52 = getelementptr { i64, [4 x i64] }, ptr %t51, i32 0, i32 0
  store i64 0, ptr %t52
  %t53 = load { i64, [4 x i64] }, ptr %t51
  call void @__olang_scope_close(ptr %s0)
  store { i64, [4 x i64] } %t53, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t56 = load ptr, ptr %l1, !tbaa !29
  %t57 = load { i64, [5 x i64] }, ptr %l6
  %t58 = load i32, ptr %l7, !tbaa !23
  %t63 = call %"compiler/mir:Range" @compiler_2flower_2ecompiler_2flower_3alowering_2eargs(ptr %v0, ptr %v1, ptr %t55, ptr %t56, { i64, [5 x i64] } %t57, i32 %t58)
  store %"compiler/mir:Range" %t63, ptr %l44
  br label %bb12
bb12:
  %t64 = load %"compiler/mir:Range", ptr %l44
  store %"compiler/mir:Range" %t64, ptr %l8
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/lower:lowering", ptr %t65, i32 0, i32 7
  %t68 = load i1, ptr %t67, !tbaa !21
  br i1 %t68, label %bb13, label %bb14
bb13:
  store { i64, [4 x i64] } zeroinitializer, ptr %t70
  %t71 = getelementptr { i64, [4 x i64] }, ptr %t70, i32 0, i32 0
  store i64 0, ptr %t71
  %t72 = load { i64, [4 x i64] }, ptr %t70
  call void @__olang_scope_close(ptr %s0)
  store { i64, [4 x i64] } %t72, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  %t74 = load ptr, ptr %l4, !tbaa !29
  %t75 = load i32, ptr %l7, !tbaa !23
  %t78 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t74, i32 %t75)
  store i32 %t78, ptr %l50
  br label %bb16
bb16:
  %t79 = load i32, ptr %l50, !tbaa !23
  store i32 %t79, ptr %l9, !tbaa !23
  %t80 = load ptr, ptr %l0, !tbaa !29
  store ptr %t80, ptr %l51, !tbaa !29
  %t81 = load ptr, ptr %l4, !tbaa !29
  %t82 = load { i64, [5 x i64] }, ptr %l6
  %t83 = load i32, ptr %l7, !tbaa !23
  %t87 = call i64 @compiler_2fmir_2ePassedCount(ptr %v0, ptr %t81, { i64, [5 x i64] } %t82, i32 %t83)
  store i64 %t87, ptr %l55
  br label %bb17
bb17:
  %t88 = load ptr, ptr %l1, !tbaa !29
  %t90 = getelementptr %"compiler/typed:Call", ptr %t88, i32 0, i32 3
  %t91 = load i32, ptr %t90, !tbaa !23
  %t92 = load ptr, ptr %l51, !tbaa !29
  %t93 = load i64, ptr %l55, !tbaa !24
  %t95 = call %"compiler/mir:Range" @compiler_2flower_2ecompiler_2flower_3alowering_2epassed(ptr %v0, ptr %t92, i64 %t93, i32 %t91)
  store %"compiler/mir:Range" %t95, ptr %l58
  br label %bb18
bb18:
  %t96 = load %"compiler/mir:Range", ptr %l58
  store %"compiler/mir:Range" %t96, ptr %l10
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = getelementptr %"compiler/lower:lowering", ptr %t97, i32 0, i32 3
  %t101 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t99)
  store i32 %t101, ptr %l61
  br label %bb19
bb19:
  %t102 = load i32, ptr %l61, !tbaa !23
  store i32 %t102, ptr %l11, !tbaa !23
  %t103 = load i32, ptr @G_2ecompiler_2fmir_2eNoLocal, !tbaa !23
  store i32 %t103, ptr %l12, !tbaa !23
  %t105 = load i32, ptr %l9, !tbaa !23
  %t106 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t109 = icmp ne i32 %t105, %t106
  br i1 %t109, label %bb20, label %bb21
bb20:
  %t111 = load i32, ptr %l9, !tbaa !23
  %t112 = load i32, ptr @G_2ecompiler_2ftypes_2eNoreturnT, !tbaa !23
  %t115 = icmp ne i32 %t111, %t112
  store i1 %t115, ptr %l66, !tbaa !21
  br label %bb22
bb21:
  store i1 false, ptr %l66, !tbaa !21
  br label %bb22
bb22:
  %t117 = load i1, ptr %l66, !tbaa !21
  br i1 %t117, label %bb23, label %bb24
bb23:
  %t118 = load ptr, ptr %l0, !tbaa !29
  store ptr %t118, ptr %l70, !tbaa !29
  %t119 = load i32, ptr %l2, !tbaa !23
  %t120 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t123 = icmp ne i32 %t119, %t120
  br i1 %t123, label %bb25, label %bb26
bb24:
  br label %bb29
bb25:
  %t125 = load i32, ptr %l2, !tbaa !23
  store i32 %t125, ptr %l74, !tbaa !23
  br label %bb27
bb26:
  %t127 = load i32, ptr %l9, !tbaa !23
  store i32 %t127, ptr %l74, !tbaa !23
  br label %bb27
bb27:
  %t129 = load %"compiler/source:Span", ptr %l3
  %t130 = load ptr, ptr %l70, !tbaa !29
  %t131 = load i32, ptr %l74, !tbaa !23
  %t133 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2etemp(ptr %v0, ptr %t130, i32 %t131, %"compiler/source:Span" %t129)
  store i32 %t133, ptr %l78
  br label %bb28
bb28:
  %t134 = load i32, ptr %l78, !tbaa !23
  store i32 %t134, ptr %l12, !tbaa !23
  br label %bb29
bb29:
  %t135 = load ptr, ptr %l4, !tbaa !29
  %t136 = load i32, ptr %l7, !tbaa !23
  %t139 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t135, i32 %t136)
  store i32 %t139, ptr %l81
  br label %bb30
bb30:
  %t140 = load i32, ptr %l81, !tbaa !23
  store i32 %t140, ptr %l13, !tbaa !23
  %t141 = load i32, ptr @G_2ecompiler_2fmir_2eNoLocal, !tbaa !23
  store i32 %t141, ptr %l14, !tbaa !23
  %t143 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  store i32 %t143, ptr %l15, !tbaa !23
  %t145 = load ptr, ptr %l4, !tbaa !29
  %t146 = load i32, ptr %l13, !tbaa !23
  %t149 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t145, i32 %t146)
  store { i64, ptr } %t149, ptr %l86
  br label %bb31
bb31:
  %t150 = load { i64, ptr }, ptr %l86, !tbaa !27
  %t151 = extractvalue { i64, ptr } %t150, 0
  %t153 = icmp sgt i64 %t151, 0
  br i1 %t153, label %bb32, label %bb33
bb32:
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t156 = load i32, ptr @G_2ecompiler_2fmir_2eI32T, !tbaa !23
  %t157 = load %"compiler/source:Span", ptr %l3
  %t161 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2etemp(ptr %v0, ptr %t155, i32 %t156, %"compiler/source:Span" %t157)
  store i32 %t161, ptr %l92
  br label %bb34
bb33:
  br label %bb36
bb34:
  %t162 = load i32, ptr %l92, !tbaa !23
  store i32 %t162, ptr %l14, !tbaa !23
  %t163 = load ptr, ptr %l0, !tbaa !29
  %t165 = getelementptr %"compiler/lower:lowering", ptr %t163, i32 0, i32 3
  %t167 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t165)
  store i32 %t167, ptr %l95
  br label %bb35
bb35:
  %t168 = load i32, ptr %l95, !tbaa !23
  store i32 %t168, ptr %l15, !tbaa !23
  br label %bb36
bb36:
  %t169 = load ptr, ptr %l0, !tbaa !29
  %t171 = getelementptr %"compiler/lower:lowering", ptr %t169, i32 0, i32 3
  store ptr %t171, ptr %l97, !tbaa !29
  %t172 = load { i64, [5 x i64] }, ptr %l6
  store { i64, [5 x i64] } %t172, ptr %l98
  %t173 = load %"compiler/mir:Range", ptr %l8
  store %"compiler/mir:Range" %t173, ptr %l99
  %t174 = load %"compiler/mir:Range", ptr %l10
  store %"compiler/mir:Range" %t174, ptr %l100
  %t175 = load i32, ptr %l12, !tbaa !23
  %t176 = load i32, ptr @G_2ecompiler_2fmir_2eNoLocal, !tbaa !23
  %t179 = icmp ne i32 %t175, %t176
  br i1 %t179, label %bb37, label %bb38
bb37:
  %t181 = load i32, ptr %l12, !tbaa !23
  %t183 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t181)
  store %"compiler/mir:Place" %t183, ptr %l106
  br label %bb39
bb38:
  %t184 = load %"compiler/mir:Place", ptr @G_2ecompiler_2fmir_2eNoPlace
  store %"compiler/mir:Place" %t184, ptr %l104
  br label %bb40
bb39:
  %t186 = load %"compiler/mir:Place", ptr %l106
  store %"compiler/mir:Place" %t186, ptr %l104
  br label %bb40
bb40:
  %t187 = load i32, ptr %l12, !tbaa !23
  %t188 = load i32, ptr @G_2ecompiler_2fmir_2eNoLocal, !tbaa !23
  %t191 = icmp ne i32 %t187, %t188
  %t192 = load i32, ptr %l11, !tbaa !23
  %t193 = load i32, ptr %l14, !tbaa !23
  %t194 = load i32, ptr %l15, !tbaa !23
  %t195 = load { i64, [5 x i64] }, ptr %l98
  %t196 = load %"compiler/mir:Range", ptr %l99
  %t197 = load %"compiler/mir:Range", ptr %l100
  %t198 = load %"compiler/mir:Place", ptr %l104
  %t203 = call %"compiler/mir:Call" @compiler_2fmir_3aCall_2ector(ptr %s0, { i64, [5 x i64] } %t195, %"compiler/mir:Range" %t196, %"compiler/mir:Range" %t197, %"compiler/mir:Place" %t198, i1 %t191, i32 %t192, i32 %t193, i32 %t194)
  store %"compiler/mir:Call" %t203, ptr %l114
  br label %bb41
bb41:
  %t204 = load ptr, ptr %l97, !tbaa !29
  %t205 = load %"compiler/mir:Call", ptr %l114
  %t206 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddCall(ptr %v0, ptr %t204, %"compiler/mir:Call" %t205)
  store i32 %t206, ptr %l115
  br label %bb42
bb42:
  %t207 = load i32, ptr %l115, !tbaa !23
  %t208 = load ptr, ptr %l0, !tbaa !29
  %t209 = load %"compiler/source:Span", ptr %l3
  store { i64, [7 x i64] } zeroinitializer, ptr %t211
  %t212 = getelementptr { i64, [7 x i64] }, ptr %t211, i32 0, i32 0
  store i64 4, ptr %t212
  %t214 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t209, 0
  %t216 = insertvalue { %"compiler/source:Span", i32 } %t214, i32 %t207, 1
  %t217 = getelementptr { i64, [7 x i64] }, ptr %t211, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t216, ptr %t217
  %t218 = load { i64, [7 x i64] }, ptr %t211
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t208, { i64, [7 x i64] } %t218)
  br label %bb43
bb43:
  %t221 = load i32, ptr %l15, !tbaa !23
  %t222 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t225 = icmp ne i32 %t221, %t222
  br i1 %t225, label %bb44, label %bb45
bb44:
  %t227 = load ptr, ptr %l0, !tbaa !29
  %t228 = load i32, ptr %l15, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t227, i32 %t228)
  br label %bb46
bb45:
  br label %bb49
bb46:
  %t231 = load ptr, ptr %l0, !tbaa !29
  store ptr %t231, ptr %l125, !tbaa !29
  %t232 = load i32, ptr %l14, !tbaa !23
  %t234 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t232)
  store %"compiler/mir:Place" %t234, ptr %l127
  br label %bb47
bb47:
  store { i64, [4 x i64] } zeroinitializer, ptr %t235
  %t236 = getelementptr { i64, [4 x i64] }, ptr %t235, i32 0, i32 0
  store i64 1, ptr %t236
  %t237 = load %"compiler/mir:Place", ptr %l127
  %t238 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t237, 0
  %t239 = getelementptr { i64, [4 x i64] }, ptr %t235, i32 0, i32 1
  store { %"compiler/mir:Place" } %t238, ptr %t239
  %t240 = load { i64, [4 x i64] }, ptr %t235
  %t241 = load i32, ptr %l13, !tbaa !23
  %t242 = load %"compiler/source:Span", ptr %l3
  %t243 = load ptr, ptr %l125, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2edispatch(ptr %v0, ptr %t243, { i64, [4 x i64] } %t240, i32 %t241, %"compiler/source:Span" %t242, i1 false)
  br label %bb48
bb48:
  br label %bb49
bb49:
  %t247 = load ptr, ptr %l0, !tbaa !29
  %t248 = load i32, ptr %l11, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t247, i32 %t248)
  br label %bb50
bb50:
  %t251 = load i32, ptr %l9, !tbaa !23
  %t252 = load i32, ptr @G_2ecompiler_2ftypes_2eNoreturnT, !tbaa !23
  %t255 = icmp eq i32 %t251, %t252
  br i1 %t255, label %bb51, label %bb52
bb51:
  %t257 = load ptr, ptr %l0, !tbaa !29
  %t258 = load %"compiler/source:Span", ptr %l3
  store { i64, [4 x i64] } zeroinitializer, ptr %t259
  %t260 = getelementptr { i64, [4 x i64] }, ptr %t259, i32 0, i32 0
  store i64 0, ptr %t260
  %t261 = load { i64, [4 x i64] }, ptr %t259
  store { i64, [7 x i64] } zeroinitializer, ptr %t262
  %t263 = getelementptr { i64, [7 x i64] }, ptr %t262, i32 0, i32 0
  store i64 8, ptr %t263
  %t265 = insertvalue { %"compiler/source:Span", i32, { i64, [4 x i64] } } undef, %"compiler/source:Span" %t258, 0
  %t267 = insertvalue { %"compiler/source:Span", i32, { i64, [4 x i64] } } %t265, i32 3, 1
  %t269 = insertvalue { %"compiler/source:Span", i32, { i64, [4 x i64] } } %t267, { i64, [4 x i64] } %t261, 2
  %t270 = getelementptr { i64, [7 x i64] }, ptr %t262, i32 0, i32 1
  store { %"compiler/source:Span", i32, { i64, [4 x i64] } } %t269, ptr %t270
  %t271 = load { i64, [7 x i64] }, ptr %t262
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t257, { i64, [7 x i64] } %t271)
  br label %bb53
bb52:
  br label %bb54
bb53:
  store { i64, [4 x i64] } zeroinitializer, ptr %t274
  %t275 = getelementptr { i64, [4 x i64] }, ptr %t274, i32 0, i32 0
  store i64 0, ptr %t275
  %t276 = load { i64, [4 x i64] }, ptr %t274
  call void @__olang_scope_close(ptr %s0)
  store { i64, [4 x i64] } %t276, ptr %rv
  br label %ret
bb54:
  %t278 = load i32, ptr %l12, !tbaa !23
  %t279 = load i32, ptr @G_2ecompiler_2fmir_2eNoLocal, !tbaa !23
  %t282 = icmp eq i32 %t278, %t279
  br i1 %t282, label %bb55, label %bb56
bb55:
  store { i64, [4 x i64] } zeroinitializer, ptr %t284
  %t285 = getelementptr { i64, [4 x i64] }, ptr %t284, i32 0, i32 0
  store i64 0, ptr %t285
  %t286 = load { i64, [4 x i64] }, ptr %t284
  call void @__olang_scope_close(ptr %s0)
  store { i64, [4 x i64] } %t286, ptr %rv
  br label %ret
bb56:
  br label %bb57
bb57:
  %t288 = load i32, ptr %l12, !tbaa !23
  %t290 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t288)
  store %"compiler/mir:Place" %t290, ptr %l147
  br label %bb58
bb58:
  store { i64, [4 x i64] } zeroinitializer, ptr %t291
  %t292 = getelementptr { i64, [4 x i64] }, ptr %t291, i32 0, i32 0
  store i64 1, ptr %t292
  %t293 = load %"compiler/mir:Place", ptr %l147
  %t294 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t293, 0
  %t295 = getelementptr { i64, [4 x i64] }, ptr %t291, i32 0, i32 1
  store { %"compiler/mir:Place" } %t294, ptr %t295
  %t296 = load { i64, [4 x i64] }, ptr %t291
  call void @__olang_scope_close(ptr %s0)
  store { i64, [4 x i64] } %t296, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local { { i64, [5 x i64] }, i32 } @compiler_2flower_2ecompiler_2flower_3alowering_2ecallee(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca i32
  %l6 = alloca ptr
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca ptr
  %l10 = alloca i1
  %l17 = alloca { { i64, [5 x i64] }, i32 }
  %l18 = alloca ptr
  %l19 = alloca i1
  %l28 = alloca i32
  %l34 = alloca ptr
  %l35 = alloca i1
  %l42 = alloca { { i64, [5 x i64] }, i32 }
  %l43 = alloca ptr
  %l44 = alloca i1
  %l54 = alloca { { i64, [5 x i64] }, i32 }
  %rv = alloca { { i64, [5 x i64] }, i32 }
  %t51 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l9, !tbaa !29
  store i1 false, ptr %l10, !tbaa !21
  %t2 = load ptr, ptr %l9, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l9, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l10, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l10, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [1 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { i32 }, ptr %t12, i32 0, i32 0
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l3, !tbaa !23
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load i32, ptr %l3, !tbaa !23
  %t20 = call { { i64, [5 x i64] }, i32 } @compiler_2flower_2ecompiler_2flower_3alowering_2ebodyCallee(ptr %v0, ptr %t16, i32 %t17)
  store { { i64, [5 x i64] }, i32 } %t20, ptr %l17
  br label %bb6
bb6:
  %t21 = load { { i64, [5 x i64] }, i32 }, ptr %l17
  store { { i64, [5 x i64] }, i32 } %t21, ptr %rv
  br label %ret
bb7:
  %t22 = load ptr, ptr %l1, !tbaa !29
  store ptr %t22, ptr %l18, !tbaa !29
  store i1 false, ptr %l19, !tbaa !21
  %t23 = load ptr, ptr %l18, !tbaa !29
  %t24 = icmp ne ptr %t23, null
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t26 = load ptr, ptr %l18, !tbaa !29
  %t27 = load i64, ptr %t26
  %t29 = icmp eq i64 %t27, 1
  store i1 %t29, ptr %l19, !tbaa !21
  br label %bb9
bb9:
  %t30 = load i1, ptr %l19, !tbaa !21
  br i1 %t30, label %bb10, label %bb11
bb10:
  %t31 = load ptr, ptr %l1, !tbaa !29
  %t33 = getelementptr { i64, [1 x i64] }, ptr %t31, i32 0, i32 1
  %t34 = getelementptr { i64 }, ptr %t33, i32 0, i32 0
  %t35 = load i64, ptr %t34
  store i64 %t35, ptr %l4, !tbaa !24
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/lower:lowering", ptr %t37, i32 0, i32 0
  %t40 = load ptr, ptr %t39, !tbaa !29
  %t42 = getelementptr %"compiler/lower:Lowerer", ptr %t40, i32 0, i32 0
  %t43 = load ptr, ptr %t42, !tbaa !29
  %t44 = load i64, ptr %l4, !tbaa !24
  %t47 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t43, i64 %t44)
  store i32 %t47, ptr %l28
  br label %bb13
bb13:
  %t48 = load i32, ptr %l28, !tbaa !23
  store i32 %t48, ptr %l5, !tbaa !23
  %t49 = load i64, ptr %l4, !tbaa !24
  %t50 = load i32, ptr %l5, !tbaa !23
  store { i64, [5 x i64] } zeroinitializer, ptr %t51
  %t52 = getelementptr { i64, [5 x i64] }, ptr %t51, i32 0, i32 0
  store i64 1, ptr %t52
  %t54 = insertvalue { i64, i32 } undef, i64 %t49, 0
  %t56 = insertvalue { i64, i32 } %t54, i32 %t50, 1
  %t57 = getelementptr { i64, [5 x i64] }, ptr %t51, i32 0, i32 1
  store { i64, i32 } %t56, ptr %t57
  %t58 = load { i64, [5 x i64] }, ptr %t51
  %t59 = load i32, ptr %l5, !tbaa !23
  %t61 = insertvalue { { i64, [5 x i64] }, i32 } undef, { i64, [5 x i64] } %t58, 0
  %t63 = insertvalue { { i64, [5 x i64] }, i32 } %t61, i32 %t59, 1
  store { { i64, [5 x i64] }, i32 } %t63, ptr %rv
  br label %ret
bb14:
  %t65 = load ptr, ptr %l1, !tbaa !29
  store ptr %t65, ptr %l34, !tbaa !29
  store i1 false, ptr %l35, !tbaa !21
  %t66 = load ptr, ptr %l34, !tbaa !29
  %t67 = icmp ne ptr %t66, null
  br i1 %t67, label %bb15, label %bb16
bb15:
  %t69 = load ptr, ptr %l34, !tbaa !29
  %t70 = load i64, ptr %t69
  %t72 = icmp eq i64 %t70, 2
  store i1 %t72, ptr %l35, !tbaa !21
  br label %bb16
bb16:
  %t73 = load i1, ptr %l35, !tbaa !21
  br i1 %t73, label %bb17, label %bb18
bb17:
  %t74 = load ptr, ptr %l1, !tbaa !29
  %t76 = getelementptr { i64, [1 x i64] }, ptr %t74, i32 0, i32 1
  %t77 = getelementptr { ptr }, ptr %t76, i32 0, i32 0
  %t78 = load ptr, ptr %t77
  store ptr %t78, ptr %l6, !tbaa !29
  br label %bb19
bb18:
  br label %bb21
bb19:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t81 = load ptr, ptr %l6, !tbaa !29
  %t84 = call { { i64, [5 x i64] }, i32 } @compiler_2flower_2ecompiler_2flower_3alowering_2evalueCallee(ptr %v0, ptr %v1, ptr %t80, ptr %t81)
  store { { i64, [5 x i64] }, i32 } %t84, ptr %l42
  br label %bb20
bb20:
  %t85 = load { { i64, [5 x i64] }, i32 }, ptr %l42
  store { { i64, [5 x i64] }, i32 } %t85, ptr %rv
  br label %ret
bb21:
  %t86 = load ptr, ptr %l1, !tbaa !29
  store ptr %t86, ptr %l43, !tbaa !29
  store i1 false, ptr %l44, !tbaa !21
  %t87 = load ptr, ptr %l43, !tbaa !29
  %t88 = icmp ne ptr %t87, null
  br i1 %t88, label %bb22, label %bb23
bb22:
  %t90 = load ptr, ptr %l43, !tbaa !29
  %t91 = load i64, ptr %t90
  %t93 = icmp eq i64 %t91, 3
  store i1 %t93, ptr %l44, !tbaa !21
  br label %bb23
bb23:
  %t94 = load i1, ptr %l44, !tbaa !21
  br i1 %t94, label %bb24, label %bb25
bb24:
  %t95 = load ptr, ptr %l1, !tbaa !29
  %t97 = getelementptr { i64, [1 x i64] }, ptr %t95, i32 0, i32 1
  %t98 = getelementptr { i32, i32 }, ptr %t97, i32 0, i32 0
  %t99 = load i32, ptr %t98
  store i32 %t99, ptr %l7
  %t101 = load ptr, ptr %l1, !tbaa !29
  %t103 = getelementptr { i64, [1 x i64] }, ptr %t101, i32 0, i32 1
  %t104 = getelementptr { i32, i32 }, ptr %t103, i32 0, i32 1
  %t105 = load i32, ptr %t104
  store i32 %t105, ptr %l8, !tbaa !23
  br label %bb26
bb25:
  br label %bb28
bb26:
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t108 = load i32, ptr %l7
  %t109 = load i32, ptr %l8, !tbaa !23
  %t113 = call { { i64, [5 x i64] }, i32 } @compiler_2flower_2ecompiler_2flower_3alowering_2ehelperCallee(ptr %v0, ptr %t107, i32 %t108, i32 %t109)
  store { { i64, [5 x i64] }, i32 } %t113, ptr %l54
  br label %bb27
bb27:
  %t114 = load { { i64, [5 x i64] }, i32 }, ptr %l54
  store { { i64, [5 x i64] }, i32 } %t114, ptr %rv
  br label %ret
bb28:
  call void @__olang_check_failed(ptr @olang_loc_21e9da82ebd620c7_b6074e807b9f75fb)
  unreachable
ret:
  %rr = load { { i64, [5 x i64] }, i32 }, ptr %rv
  ret { { i64, [5 x i64] }, i32 } %rr
}

define dso_local { { i64, ptr }, i1 } @compiler_2flower_2ecompiler_2flower_3alowering_2ecasesOf(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l8 = alloca i32
  %l11 = alloca i32
  %l14 = alloca ptr
  %l17 = alloca i32
  %l18 = alloca { i64, ptr }
  %l22 = alloca i32
  %l25 = alloca i1
  %l26 = alloca ptr
  %l29 = alloca i32
  %l30 = alloca i32
  %l33 = alloca i1
  %l36 = alloca i1
  %l37 = alloca ptr
  %l40 = alloca i32
  %l41 = alloca { i64, ptr }
  %rv = alloca { { i64, ptr }, i1 }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t6, i32 %a1)
  store i32 %t10, ptr %l8
  br label %bb1
bb1:
  %t11 = load i32, ptr %l8, !tbaa !23
  store i32 %t11, ptr %l3, !tbaa !23
  %t12 = load ptr, ptr %l2, !tbaa !29
  %t13 = load i32, ptr %l3, !tbaa !23
  %t16 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t12, i32 %t13)
  store i32 %t16, ptr %l11
  br label %bb2
bb2:
  %t17 = load i32, ptr %l11
  %t19 = trunc i64 24 to i32
  %t20 = icmp eq i32 %t17, %t19
  br i1 %t20, label %bb3, label %bb4
bb3:
  %t22 = load ptr, ptr %l0, !tbaa !29
  store ptr %t22, ptr %l14, !tbaa !29
  %t23 = load ptr, ptr %l2, !tbaa !29
  %t24 = load i32, ptr %l3, !tbaa !23
  %t27 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeCases(ptr %v0, ptr %t23, i32 %t24)
  store i32 %t27, ptr %l17
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t28 = load ptr, ptr %l14, !tbaa !29
  %t29 = load i32, ptr %l17, !tbaa !23
  %t30 = call { i64, ptr } @compiler_2flower_2ecompiler_2flower_3alowering_2eitems(ptr %v0, ptr %v1, ptr %t28, i32 %t29)
  store { i64, ptr } %t30, ptr %l18
  br label %bb6
bb6:
  %t31 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t32 = insertvalue { { i64, ptr }, i1 } undef, { i64, ptr } %t31, 0
  %t33 = insertvalue { { i64, ptr }, i1 } %t32, i1 true, 1
  store { { i64, ptr }, i1 } %t33, ptr %rv
  br label %ret
bb7:
  %t35 = load ptr, ptr %l2, !tbaa !29
  %t36 = load i32, ptr %l3, !tbaa !23
  %t39 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t35, i32 %t36)
  store i32 %t39, ptr %l22
  br label %bb8
bb8:
  %t40 = load i32, ptr %l22
  %t42 = trunc i64 18 to i32
  %t43 = icmp eq i32 %t40, %t42
  br i1 %t43, label %bb9, label %bb10
bb9:
  %t45 = load ptr, ptr %l2, !tbaa !29
  store ptr %t45, ptr %l26, !tbaa !29
  %t46 = load ptr, ptr %l2, !tbaa !29
  %t47 = load i32, ptr %l3, !tbaa !23
  %t50 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t46, i32 %t47)
  store i32 %t50, ptr %l29
  br label %bb11
bb10:
  store i1 false, ptr %l25, !tbaa !21
  br label %bb13
bb11:
  %t51 = load ptr, ptr %l26, !tbaa !29
  %t52 = load i32, ptr %l29, !tbaa !23
  %t53 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t51, i32 %t52)
  store i32 %t53, ptr %l30
  br label %bb12
bb12:
  %t54 = load i32, ptr %l30
  %t56 = trunc i64 1 to i32
  %t57 = icmp eq i32 %t54, %t56
  store i1 %t57, ptr %l25, !tbaa !21
  br label %bb13
bb13:
  %t59 = load i1, ptr %l25, !tbaa !21
  br i1 %t59, label %bb14, label %bb15
bb14:
  %t60 = load ptr, ptr %l2, !tbaa !29
  %t61 = load i32, ptr %l3, !tbaa !23
  %t64 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %t60, i32 %t61)
  store i1 %t64, ptr %l36
  br label %bb16
bb15:
  store i1 false, ptr %l33, !tbaa !21
  br label %bb17
bb16:
  %t65 = load i1, ptr %l36, !tbaa !21
  store i1 %t65, ptr %l33, !tbaa !21
  br label %bb17
bb17:
  %t66 = load i1, ptr %l33, !tbaa !21
  br i1 %t66, label %bb18, label %bb19
bb18:
  %t67 = load ptr, ptr %l0, !tbaa !29
  store ptr %t67, ptr %l37, !tbaa !29
  %t68 = load ptr, ptr %l2, !tbaa !29
  %t69 = load i32, ptr %l3, !tbaa !23
  %t72 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %t68, i32 %t69)
  store i32 %t72, ptr %l40
  br label %bb20
bb19:
  br label %bb22
bb20:
  %t73 = load ptr, ptr %l37, !tbaa !29
  %t74 = load i32, ptr %l40, !tbaa !23
  %t75 = call { i64, ptr } @compiler_2flower_2ecompiler_2flower_3alowering_2eitems(ptr %v0, ptr %v1, ptr %t73, i32 %t74)
  store { i64, ptr } %t75, ptr %l41
  br label %bb21
bb21:
  %t76 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t77 = insertvalue { { i64, ptr }, i1 } undef, { i64, ptr } %t76, 0
  %t78 = insertvalue { { i64, ptr }, i1 } %t77, i1 true, 1
  store { { i64, ptr }, i1 } %t78, ptr %rv
  br label %ret
bb22:
  %t80 = icmp sge i64 0, 0
  br i1 %t80, label %bb23, label %bb24
bb23:
  %t82 = icmp sle i64 0, 2305843009213693951
  br i1 %t82, label %bb25, label %bb26
bb24:
  call void @__olang_check_failed(ptr @olang_loc_3b8f4ce72bb8c828_c6f22e3cb9711da4)
  unreachable
bb25:
  %t84 = mul i64 0, 4
  %t85 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t84)
  %t86 = insertvalue { i64, ptr } undef, i64 0, 0
  %t87 = insertvalue { i64, ptr } %t86, ptr %t85, 1
  %t89 = insertvalue { { i64, ptr }, i1 } undef, { i64, ptr } %t87, 0
  %t90 = insertvalue { { i64, ptr }, i1 } %t89, i1 false, 1
  store { { i64, ptr }, i1 } %t90, ptr %rv
  br label %ret
bb26:
  call void @__olang_check_failed(ptr @olang_loc_3b8f4ce72bb8c828_c6f22e3cb9711da4)
  unreachable
ret:
  %rr = load { { i64, ptr }, i1 }, ptr %rv
  ret { { i64, ptr }, i1 } %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2echeck(ptr %v0, ptr %a0, { i64, [4 x i64] } %a1, i32 %a2, i32 %a3, i64 %a4, %"compiler/source:Span" %a5) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca i32
  %l7 = alloca i32
  %l10 = alloca i1
  %l15 = alloca i32
  %l18 = alloca i32
  %l33 = alloca ptr
  %l37 = alloca { i64, [4 x i64] }
  %l39 = alloca ptr
  %l42 = alloca i32
  %l43 = alloca i32
  %t28 = alloca { i64, [7 x i64] }, align 8
  %t52 = alloca { i64, [4 x i64] }, align 8
  %t55 = alloca { i64, [7 x i64] }, align 8
  %t72 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  store %"compiler/source:Span" %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 7
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l10, !tbaa !21
  br label %bb3
bb2:
  %t6 = load i32, ptr %l2
  %t8 = trunc i64 0 to i32
  %t9 = icmp eq i32 %t6, %t8
  store i1 %t9, ptr %l10, !tbaa !21
  br label %bb3
bb3:
  %t11 = load i1, ptr %l10, !tbaa !21
  br i1 %t11, label %bb4, label %bb5
bb4:
  br label %ret
bb5:
  br label %bb6
bb6:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/lower:lowering", ptr %t12, i32 0, i32 3
  %t16 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t14)
  store i32 %t16, ptr %l15
  br label %bb7
bb7:
  %t17 = load i32, ptr %l15, !tbaa !23
  store i32 %t17, ptr %l6, !tbaa !23
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/lower:lowering", ptr %t18, i32 0, i32 3
  %t22 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t20)
  store i32 %t22, ptr %l18
  br label %bb8
bb8:
  %t23 = load i32, ptr %l18, !tbaa !23
  store i32 %t23, ptr %l7, !tbaa !23
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = load i32, ptr %l6, !tbaa !23
  %t27 = load i32, ptr %l7, !tbaa !23
  store { i64, [7 x i64] } zeroinitializer, ptr %t28
  %t29 = getelementptr { i64, [7 x i64] }, ptr %t28, i32 0, i32 0
  store i64 2, ptr %t29
  %t31 = insertvalue { { i64, [4 x i64] }, i32, i32 } undef, { i64, [4 x i64] } %a1, 0
  %t33 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t31, i32 %t26, 1
  %t35 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t33, i32 %t27, 2
  %t36 = getelementptr { i64, [7 x i64] }, ptr %t28, i32 0, i32 1
  store { { i64, [4 x i64] }, i32, i32 } %t35, ptr %t36
  %t37 = load { i64, [7 x i64] }, ptr %t28
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t24, { i64, [7 x i64] } %t37)
  br label %bb9
bb9:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t41 = load i32, ptr %l7, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t40, i32 %t41)
  br label %bb10
bb10:
  %t44 = load i32, ptr %l2
  %t46 = trunc i64 1 to i32
  %t47 = icmp eq i32 %t44, %t46
  br i1 %t47, label %bb11, label %bb12
bb11:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t50 = load %"compiler/source:Span", ptr %l5
  store { i64, [4 x i64] } zeroinitializer, ptr %t52
  %t53 = getelementptr { i64, [4 x i64] }, ptr %t52, i32 0, i32 0
  store i64 0, ptr %t53
  %t54 = load { i64, [4 x i64] }, ptr %t52
  store { i64, [7 x i64] } zeroinitializer, ptr %t55
  %t56 = getelementptr { i64, [7 x i64] }, ptr %t55, i32 0, i32 0
  store i64 8, ptr %t56
  %t58 = insertvalue { %"compiler/source:Span", i32, { i64, [4 x i64] } } undef, %"compiler/source:Span" %t50, 0
  %t60 = insertvalue { %"compiler/source:Span", i32, { i64, [4 x i64] } } %t58, i32 %a3, 1
  %t62 = insertvalue { %"compiler/source:Span", i32, { i64, [4 x i64] } } %t60, { i64, [4 x i64] } %t54, 2
  %t63 = getelementptr { i64, [7 x i64] }, ptr %t55, i32 0, i32 1
  store { %"compiler/source:Span", i32, { i64, [4 x i64] } } %t62, ptr %t63
  %t64 = load { i64, [7 x i64] }, ptr %t55
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t49, { i64, [7 x i64] } %t64)
  br label %bb13
bb12:
  %t67 = load ptr, ptr %l0, !tbaa !29
  store ptr %t67, ptr %l33, !tbaa !29
  %t68 = load i32, ptr @G_2ecompiler_2fmir_2eI32T, !tbaa !23
  %t71 = or i64 65536, %a4
  store { i64, [4 x i64] } zeroinitializer, ptr %t72
  %t73 = getelementptr { i64, [4 x i64] }, ptr %t72, i32 0, i32 0
  store i64 2, ptr %t73
  %t75 = insertvalue { i32, i64 } undef, i32 %t68, 0
  %t77 = insertvalue { i32, i64 } %t75, i64 %t71, 1
  %t78 = getelementptr { i64, [4 x i64] }, ptr %t72, i32 0, i32 1
  store { i32, i64 } %t77, ptr %t78
  %t79 = load { i64, [4 x i64] }, ptr %t72
  store { i64, [4 x i64] } %t79, ptr %l37
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t82 = getelementptr %"compiler/lower:lowering", ptr %t80, i32 0, i32 2
  %t83 = load ptr, ptr %t82, !tbaa !29
  store ptr %t83, ptr %l39, !tbaa !29
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr %"compiler/lower:lowering", ptr %t84, i32 0, i32 0
  %t87 = load ptr, ptr %t86, !tbaa !29
  %t89 = call i32 @compiler_2flower_2ecompiler_2flower_3aLowerer_2ebuiltin(ptr %v0, ptr %t87)
  store i32 %t89, ptr %l42
  br label %bb14
bb13:
  br label %bb17
bb14:
  %t90 = load ptr, ptr %l39, !tbaa !29
  %t91 = load i32, ptr %l42, !tbaa !23
  %t92 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList1(ptr %v0, ptr %t90, i32 %t91)
  store i32 %t92, ptr %l43
  br label %bb15
bb15:
  %t93 = load %"compiler/source:Span", ptr %l5
  %t94 = load ptr, ptr %l33, !tbaa !29
  %t95 = load { i64, [4 x i64] }, ptr %l37
  %t96 = load i32, ptr %l43, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2edispatch(ptr %v0, ptr %t94, { i64, [4 x i64] } %t95, i32 %t96, %"compiler/source:Span" %t93, i1 true)
  br label %bb16
bb16:
  br label %bb17
bb17:
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t99 = load i32, ptr %l6, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t98, i32 %t99)
  br label %bb18
bb18:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2eclauses(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/lower:tryCtx" %a1, { i64, ptr } %a2, i32 %a3, i32 %a4, ptr %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/lower:tryCtx"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i32
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca ptr
  %l13 = alloca { i64, [4 x i64] }
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l26 = alloca i64
  %l29 = alloca i64
  %l49 = alloca i32
  %l52 = alloca { i64, ptr }
  %l55 = alloca ptr
  %l58 = alloca i32
  %l60 = alloca ptr
  %l63 = alloca i32
  %l68 = alloca ptr
  %l77 = alloca i1
  %l81 = alloca i1
  %l92 = alloca { i64, ptr }
  %l95 = alloca { i64, [4 x i64] }
  %l96 = alloca ptr
  %l98 = alloca %"compiler/source:Span"
  %l100 = alloca %"compiler/mir:Place"
  %l107 = alloca i64
  %l117 = alloca i64
  %l120 = alloca i64
  %l138 = alloca i64
  %l141 = alloca { i64, ptr }
  %l145 = alloca { i64, [4 x i64] }
  %l148 = alloca ptr
  %l150 = alloca %"compiler/source:Span"
  %l152 = alloca %"compiler/mir:Place"
  %l153 = alloca i32
  %l157 = alloca %"compiler/mir:Range"
  %s2 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %t176 = alloca { i64, [15 x i64] }, align 8
  %t182 = alloca { i64, [21 x i64] }, align 8
  %t299 = alloca { i64, [15 x i64] }, align 8
  %t308 = alloca { i64, [21 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/lower:tryCtx" %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l6, !tbaa !24
  %t1 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  store i64 %t3, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t5 = load i64, ptr %l7, !tbaa !24
  %t6 = load i64, ptr %l6, !tbaa !24
  %t9 = icmp sgt i64 %t5, %t6
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = load i64, ptr %l8, !tbaa !24
  %t13 = icmp sgt i64 %t11, 0
  br i1 %t13, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l26, !tbaa !24
  br label %bb6
bb3:
  %t15 = load i64, ptr %l7, !tbaa !24
  %t16 = load i64, ptr %l6, !tbaa !24
  %t19 = sub i64 %t15, %t16
  %t20 = load i64, ptr %l8, !tbaa !24
  %t23 = add i64 %t19, %t20
  %t25 = sub i64 %t23, 1
  %t26 = load i64, ptr %l8, !tbaa !24
  %t29 = sdiv i64 %t25, %t26
  store i64 %t29, ptr %l29, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l29, !tbaa !24
  br label %bb5
bb5:
  %t31 = load i64, ptr %l29, !tbaa !24
  store i64 %t31, ptr %l26, !tbaa !24
  br label %bb6
bb6:
  %t32 = load i64, ptr %l26, !tbaa !24
  store i64 %t32, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t33 = load i64, ptr %l10, !tbaa !24
  %t34 = load i64, ptr %l9, !tbaa !24
  %t37 = icmp slt i64 %t33, %t34
  %t39 = xor i1 %t37, true
  br i1 %t39, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb63
bb9:
  br label %bb10
bb10:
  %t41 = load i64, ptr %l6, !tbaa !24
  %t42 = load i64, ptr %l10, !tbaa !24
  %t43 = load i64, ptr %l8, !tbaa !24
  %t46 = mul i64 %t42, %t43
  %t49 = add i64 %t41, %t46
  store i64 %t49, ptr %l11, !tbaa !24
  %t51 = getelementptr %"compiler/lower:tryCtx", ptr %l1, i32 0, i32 4
  %t52 = load i64, ptr %l11, !tbaa !24
  %t55 = call i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aBlockId_3e_2eAt_3ccompiler_2fmir_3aBlockId_3e(ptr %v1, ptr %t51, i64 %t52)
  store i32 %t55, ptr %l49
  br label %bb11
bb11:
  %t56 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t57 = load i32, ptr %l49, !tbaa !23
  %t59 = icmp eq i32 %t57, %t56
  br i1 %t59, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s2)
  br label %bb62
bb13:
  br label %bb14
bb14:
  %t61 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t61, ptr %l52, !tbaa !27
  %t62 = load i64, ptr %l11, !tbaa !24
  %t64 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t65 = load ptr, ptr %t64, !tbaa !27
  %t66 = getelementptr ptr, ptr %t65, i64 %t62
  %t67 = load ptr, ptr %t66, !tbaa !39
  store ptr %t67, ptr %l12, !tbaa !29
  %t69 = load ptr, ptr %l0, !tbaa !29
  store ptr %t69, ptr %l55, !tbaa !29
  %t70 = getelementptr %"compiler/lower:tryCtx", ptr %l1, i32 0, i32 4
  %t71 = load i64, ptr %l11, !tbaa !24
  %t74 = call i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aBlockId_3e_2eAt_3ccompiler_2fmir_3aBlockId_3e(ptr %v1, ptr %t70, i64 %t71)
  store i32 %t74, ptr %l58
  br label %bb15
bb15:
  %t75 = load ptr, ptr %l55, !tbaa !29
  %t76 = load i32, ptr %l58, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t75, i32 %t76)
  br label %bb16
bb16:
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/lower:lowering", ptr %t77, i32 0, i32 3
  %t80 = getelementptr %"compiler/mir:Fn", ptr %t79, i32 0, i32 22
  store ptr %t80, ptr %l60, !tbaa !29
  %t81 = getelementptr %"compiler/lower:tryCtx", ptr %l1, i32 0, i32 4
  %t82 = load i64, ptr %l11, !tbaa !24
  %t85 = call i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aBlockId_3e_2eAt_3ccompiler_2fmir_3aBlockId_3e(ptr %v1, ptr %t81, i64 %t82)
  store i32 %t85, ptr %l63
  br label %bb17
bb17:
  %t86 = load ptr, ptr %l60, !tbaa !29
  %t87 = load i32, ptr %l63, !tbaa !23
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aBlockId_3e_2ePush_3ccompiler_2fmir_3aBlockId_3e(ptr %v0, ptr %t86, i32 %t87)
  br label %bb18
bb18:
  %t88 = load ptr, ptr %l12, !tbaa !29
  %t90 = getelementptr %"compiler/typed:Clause", ptr %t88, i32 0, i32 3
  %t91 = load ptr, ptr %t90, !tbaa !29
  %t93 = icmp eq ptr %t91, null
  %t95 = xor i1 %t93, true
  br i1 %t95, label %bb19, label %bb20
bb19:
  %t97 = load ptr, ptr %l0, !tbaa !29
  store ptr %t97, ptr %l68, !tbaa !29
  %t98 = load ptr, ptr %l12, !tbaa !29
  %t100 = getelementptr %"compiler/typed:Clause", ptr %t98, i32 0, i32 3
  %t101 = load ptr, ptr %t100, !tbaa !29
  %t103 = icmp eq ptr %t101, null
  br i1 %t103, label %bb21, label %bb22
bb20:
  br label %bb25
bb21:
  call void @__olang_check_failed(ptr @olang_loc_ed4966d7257d1cce_314b285230575e82)
  unreachable
bb22:
  br label %bb23
bb23:
  %t105 = load ptr, ptr %l12, !tbaa !29
  %t107 = getelementptr %"compiler/typed:Clause", ptr %t105, i32 0, i32 3
  %t108 = load ptr, ptr %t107, !tbaa !29
  %t109 = load ptr, ptr %l68, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eblock(ptr %v0, ptr %v2, ptr %t109, ptr %t108)
  br label %bb24
bb24:
  br label %bb25
bb25:
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t113 = getelementptr %"compiler/lower:lowering", ptr %t111, i32 0, i32 7
  %t114 = load i1, ptr %t113, !tbaa !21
  %t116 = xor i1 %t114, true
  br i1 %t116, label %bb26, label %bb27
bb26:
  %t118 = load i32, ptr %l3, !tbaa !23
  %t119 = load i32, ptr @G_2ecompiler_2fmir_2eNoLocal, !tbaa !23
  %t122 = icmp ne i32 %t118, %t119
  store i1 %t122, ptr %l77, !tbaa !21
  br label %bb28
bb27:
  store i1 false, ptr %l77, !tbaa !21
  br label %bb28
bb28:
  %t124 = load i1, ptr %l77, !tbaa !21
  br i1 %t124, label %bb29, label %bb30
bb29:
  %t125 = load ptr, ptr %l12, !tbaa !29
  %t127 = getelementptr %"compiler/typed:Clause", ptr %t125, i32 0, i32 4
  %t128 = load { i64, ptr }, ptr %t127, !tbaa !27
  %t130 = extractvalue { i64, ptr } %t128, 0
  %t132 = icmp sgt i64 %t130, 0
  store i1 %t132, ptr %l81, !tbaa !21
  br label %bb31
bb30:
  store i1 false, ptr %l81, !tbaa !21
  br label %bb31
bb31:
  %t134 = load i1, ptr %l81, !tbaa !21
  br i1 %t134, label %bb32, label %bb33
bb32:
  %t135 = load ptr, ptr %l12, !tbaa !29
  %t137 = getelementptr %"compiler/typed:Clause", ptr %t135, i32 0, i32 4
  %t138 = load { i64, ptr }, ptr %t137, !tbaa !27
  %t140 = extractvalue { i64, ptr } %t138, 0
  %t142 = icmp eq i64 %t140, 1
  br i1 %t142, label %bb34, label %bb35
bb33:
  br label %bb60
bb34:
  store %olang.scope zeroinitializer, ptr %s6
  %t144 = load ptr, ptr %l0, !tbaa !29
  %t145 = load ptr, ptr %l12, !tbaa !29
  %t147 = getelementptr %"compiler/typed:Clause", ptr %t145, i32 0, i32 4
  %t148 = load { i64, ptr }, ptr %t147, !tbaa !27
  store { i64, ptr } %t148, ptr %l92, !tbaa !27
  %t149 = getelementptr { i64, ptr }, ptr %l92, i32 0, i32 1
  %t150 = load ptr, ptr %t149, !tbaa !27
  %t151 = getelementptr ptr, ptr %t150, i64 0
  %t152 = load ptr, ptr %t151, !tbaa !39
  %t156 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v2, ptr %t144, ptr %t152)
  store { i64, [4 x i64] } %t156, ptr %l95
  br label %bb36
bb35:
  store %olang.scope zeroinitializer, ptr %s7
  %t157 = load ptr, ptr %l12, !tbaa !29
  %t159 = getelementptr %"compiler/typed:Clause", ptr %t157, i32 0, i32 4
  %t160 = load { i64, ptr }, ptr %t159, !tbaa !27
  %t162 = extractvalue { i64, ptr } %t160, 0
  store i64 %t162, ptr %l107, !tbaa !24
  %t163 = load i64, ptr %l107, !tbaa !24
  %t164 = icmp sge i64 %t163, 0
  br i1 %t164, label %bb39, label %bb40
bb36:
  %t166 = load { i64, [4 x i64] }, ptr %l95
  store { i64, [4 x i64] } %t166, ptr %l13
  %t167 = load ptr, ptr %l0, !tbaa !29
  store ptr %t167, ptr %l96, !tbaa !29
  %t168 = load ptr, ptr %l12, !tbaa !29
  %t170 = getelementptr %"compiler/typed:Clause", ptr %t168, i32 0, i32 0
  %t171 = load %"compiler/source:Span", ptr %t170
  store %"compiler/source:Span" %t171, ptr %l98
  %t172 = load i32, ptr %l3, !tbaa !23
  %t174 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t172)
  store %"compiler/mir:Place" %t174, ptr %l100
  br label %bb37
bb37:
  %t175 = load { i64, [4 x i64] }, ptr %l13
  store { i64, [15 x i64] } zeroinitializer, ptr %t176
  %t177 = getelementptr { i64, [15 x i64] }, ptr %t176, i32 0, i32 0
  store i64 0, ptr %t177
  %t179 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t175, 0
  %t180 = getelementptr { i64, [15 x i64] }, ptr %t176, i32 0, i32 1
  store { { i64, [4 x i64] } } %t179, ptr %t180
  %t181 = load { i64, [15 x i64] }, ptr %t176
  store { i64, [21 x i64] } zeroinitializer, ptr %t182
  %t183 = getelementptr { i64, [21 x i64] }, ptr %t182, i32 0, i32 0
  store i64 0, ptr %t183
  %t184 = load %"compiler/source:Span", ptr %l98
  %t185 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t184, 0
  %t186 = load %"compiler/mir:Place", ptr %l100
  %t187 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t185, %"compiler/mir:Place" %t186, 1
  %t189 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t187, { i64, [15 x i64] } %t181, 2
  %t190 = getelementptr { i64, [21 x i64] }, ptr %t182, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t189, ptr %t190
  %t191 = load { i64, [21 x i64] }, ptr %t182
  %t193 = call ptr @__olang_scope_alloc_a(ptr %s6, i64 176, i64 8)
  store { i64, [21 x i64] } %t191, ptr %t193
  %t194 = load ptr, ptr %l96, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s6, ptr %t194, ptr %t193)
  br label %bb38
bb38:
  call void @__olang_scope_close(ptr %s6)
  br label %bb59
bb39:
  %t196 = load i64, ptr %l107, !tbaa !24
  %t197 = icmp sle i64 %t196, 230584300921369395
  br i1 %t197, label %bb41, label %bb42
bb40:
  call void @__olang_check_failed(ptr @olang_loc_4fc14cddf040b63b_d4edc892d8598fd7)
  unreachable
bb41:
  %t199 = load i64, ptr %l107, !tbaa !24
  %t200 = mul i64 %t199, 40
  %t201 = call ptr @__olang_scope_alloc_zeroed(ptr %s7, i64 %t200)
  %t202 = insertvalue { i64, ptr } undef, i64 %t199, 0
  %t203 = insertvalue { i64, ptr } %t202, ptr %t201, 1
  store { i64, ptr } %t203, ptr %l14, !tbaa !27
  store i64 0, ptr %l15, !tbaa !24
  %t205 = load ptr, ptr %l12, !tbaa !29
  %t207 = getelementptr %"compiler/typed:Clause", ptr %t205, i32 0, i32 4
  %t208 = load { i64, ptr }, ptr %t207, !tbaa !27
  %t210 = extractvalue { i64, ptr } %t208, 0
  store i64 %t210, ptr %l16, !tbaa !24
  store i64 1, ptr %l17, !tbaa !24
  %t212 = load i64, ptr %l16, !tbaa !24
  %t213 = load i64, ptr %l15, !tbaa !24
  %t216 = icmp sgt i64 %t212, %t213
  br i1 %t216, label %bb43, label %bb44
bb42:
  call void @__olang_check_failed(ptr @olang_loc_4fc14cddf040b63b_d4edc892d8598fd7)
  unreachable
bb43:
  %t218 = load i64, ptr %l17, !tbaa !24
  %t220 = icmp sgt i64 %t218, 0
  br i1 %t220, label %bb45, label %bb46
bb44:
  store i64 0, ptr %l117, !tbaa !24
  br label %bb48
bb45:
  %t222 = load i64, ptr %l16, !tbaa !24
  %t223 = load i64, ptr %l15, !tbaa !24
  %t226 = sub i64 %t222, %t223
  %t227 = load i64, ptr %l17, !tbaa !24
  %t230 = add i64 %t226, %t227
  %t232 = sub i64 %t230, 1
  %t233 = load i64, ptr %l17, !tbaa !24
  %t236 = sdiv i64 %t232, %t233
  store i64 %t236, ptr %l120, !tbaa !24
  br label %bb47
bb46:
  store i64 0, ptr %l120, !tbaa !24
  br label %bb47
bb47:
  %t238 = load i64, ptr %l120, !tbaa !24
  store i64 %t238, ptr %l117, !tbaa !24
  br label %bb48
bb48:
  %t239 = load i64, ptr %l117, !tbaa !24
  store i64 %t239, ptr %l18, !tbaa !24
  store i64 0, ptr %l19, !tbaa !24
  br label %bb49
bb49:
  store %olang.scope zeroinitializer, ptr %s9
  %t240 = load i64, ptr %l19, !tbaa !24
  %t241 = load i64, ptr %l18, !tbaa !24
  %t244 = icmp slt i64 %t240, %t241
  %t246 = xor i1 %t244, true
  br i1 %t246, label %bb50, label %bb51
bb50:
  call void @__olang_scope_close(ptr %s9)
  br label %bb55
bb51:
  br label %bb52
bb52:
  %t248 = load i64, ptr %l15, !tbaa !24
  %t249 = load i64, ptr %l19, !tbaa !24
  %t250 = load i64, ptr %l17, !tbaa !24
  %t253 = mul i64 %t249, %t250
  %t256 = add i64 %t248, %t253
  store i64 %t256, ptr %l20, !tbaa !24
  %t258 = load i64, ptr %l20, !tbaa !24
  store i64 %t258, ptr %l138, !tbaa !24
  %t259 = load ptr, ptr %l0, !tbaa !29
  %t260 = load ptr, ptr %l12, !tbaa !29
  %t262 = getelementptr %"compiler/typed:Clause", ptr %t260, i32 0, i32 4
  %t263 = load { i64, ptr }, ptr %t262, !tbaa !27
  store { i64, ptr } %t263, ptr %l141, !tbaa !27
  %t264 = load i64, ptr %l20, !tbaa !24
  %t266 = getelementptr { i64, ptr }, ptr %l141, i32 0, i32 1
  %t267 = load ptr, ptr %t266, !tbaa !27
  %t268 = getelementptr ptr, ptr %t267, i64 %t264
  %t269 = load ptr, ptr %t268, !tbaa !39
  %t273 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v2, ptr %t259, ptr %t269)
  store { i64, [4 x i64] } %t273, ptr %l145
  br label %bb53
bb53:
  %t274 = load { i64, [4 x i64] }, ptr %l145
  %t275 = load i64, ptr %l138, !tbaa !24
  %t276 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t277 = load ptr, ptr %t276, !tbaa !27
  %t278 = getelementptr { i64, [4 x i64] }, ptr %t277, i64 %t275
  store { i64, [4 x i64] } %t274, ptr %t278
  call void @__olang_scope_close(ptr %s9)
  br label %bb54
bb54:
  %t279 = load i64, ptr %l19, !tbaa !24
  %t281 = add i64 %t279, 1
  store i64 %t281, ptr %l19, !tbaa !24
  br label %bb49
bb55:
  %t283 = load ptr, ptr %l0, !tbaa !29
  store ptr %t283, ptr %l148, !tbaa !29
  %t284 = load ptr, ptr %l12, !tbaa !29
  %t286 = getelementptr %"compiler/typed:Clause", ptr %t284, i32 0, i32 0
  %t287 = load %"compiler/source:Span", ptr %t286
  store %"compiler/source:Span" %t287, ptr %l150
  %t288 = load i32, ptr %l3, !tbaa !23
  %t290 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t288)
  store %"compiler/mir:Place" %t290, ptr %l152
  br label %bb56
bb56:
  store i32 %a4, ptr %l153, !tbaa !23
  %t292 = load ptr, ptr %l0, !tbaa !29
  %t294 = getelementptr %"compiler/lower:lowering", ptr %t292, i32 0, i32 3
  %t295 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t298 = call %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eArgs(ptr %v0, ptr %s7, ptr %t294, { i64, ptr } %t295)
  store %"compiler/mir:Range" %t298, ptr %l157
  br label %bb57
bb57:
  store { i64, [15 x i64] } zeroinitializer, ptr %t299
  %t300 = getelementptr { i64, [15 x i64] }, ptr %t299, i32 0, i32 0
  store i64 6, ptr %t300
  %t301 = load i32, ptr %l153, !tbaa !23
  %t302 = insertvalue { i32, i64, %"compiler/mir:Range" } undef, i32 %t301, 0
  %t303 = insertvalue { i32, i64, %"compiler/mir:Range" } %t302, i64 0, 1
  %t304 = load %"compiler/mir:Range", ptr %l157
  %t305 = insertvalue { i32, i64, %"compiler/mir:Range" } %t303, %"compiler/mir:Range" %t304, 2
  %t306 = getelementptr { i64, [15 x i64] }, ptr %t299, i32 0, i32 1
  store { i32, i64, %"compiler/mir:Range" } %t305, ptr %t306
  %t307 = load { i64, [15 x i64] }, ptr %t299
  store { i64, [21 x i64] } zeroinitializer, ptr %t308
  %t309 = getelementptr { i64, [21 x i64] }, ptr %t308, i32 0, i32 0
  store i64 0, ptr %t309
  %t310 = load %"compiler/source:Span", ptr %l150
  %t311 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t310, 0
  %t312 = load %"compiler/mir:Place", ptr %l152
  %t313 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t311, %"compiler/mir:Place" %t312, 1
  %t315 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t313, { i64, [15 x i64] } %t307, 2
  %t316 = getelementptr { i64, [21 x i64] }, ptr %t308, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t315, ptr %t316
  %t317 = load { i64, [21 x i64] }, ptr %t308
  %t319 = call ptr @__olang_scope_alloc_a(ptr %s7, i64 176, i64 8)
  store { i64, [21 x i64] } %t317, ptr %t319
  %t320 = load ptr, ptr %l148, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s7, ptr %t320, ptr %t319)
  br label %bb58
bb58:
  call void @__olang_scope_close(ptr %s7)
  br label %bb59
bb59:
  br label %bb60
bb60:
  %t322 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eleaveOpen(ptr %v0, ptr %v3, ptr %t322, ptr %a5)
  br label %bb61
bb61:
  call void @__olang_scope_close(ptr %s2)
  br label %bb62
bb62:
  %t326 = load i64, ptr %l10, !tbaa !24
  %t328 = add i64 %t326, 1
  store i64 %t328, ptr %l10, !tbaa !24
  br label %bb7
bb63:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2ecleanup(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i64
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i32
  %l11 = alloca i32
  %l14 = alloca i32
  %l28 = alloca ptr
  %l32 = alloca ptr
  %s0 = alloca %olang.scope
  %t24 = alloca { i64, [21 x i64] }, align 8
  %t73 = alloca { i64, [7 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 7
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/lower:lowering", ptr %t6, i32 0, i32 11
  %t9 = load i64, ptr %l2, !tbaa !24
  %t12 = call i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeId_3e_2eAt_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t8, i64 %t9)
  store i32 %t12, ptr %l11
  br label %bb4
bb4:
  %t13 = load i32, ptr %l11, !tbaa !23
  store i32 %t13, ptr %l3, !tbaa !23
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/lower:lowering", ptr %t14, i32 0, i32 3
  %t18 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t16)
  store i32 %t18, ptr %l14
  br label %bb5
bb5:
  %t19 = load i32, ptr %l14, !tbaa !23
  store i32 %t19, ptr %l4, !tbaa !23
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load %"compiler/source:Span", ptr %l1
  %t22 = load i32, ptr %l3, !tbaa !23
  %t23 = load i32, ptr %l4, !tbaa !23
  store { i64, [21 x i64] } zeroinitializer, ptr %t24
  %t25 = getelementptr { i64, [21 x i64] }, ptr %t24, i32 0, i32 0
  store i64 13, ptr %t25
  %t27 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %t21, 0
  %t29 = insertvalue { %"compiler/source:Span", i32, i32 } %t27, i32 %t22, 1
  %t31 = insertvalue { %"compiler/source:Span", i32, i32 } %t29, i32 %t23, 2
  %t32 = getelementptr { i64, [21 x i64] }, ptr %t24, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t31, ptr %t32
  %t33 = load { i64, [21 x i64] }, ptr %t24
  %t35 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t33, ptr %t35
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s0, ptr %t20, ptr %t35)
  br label %bb6
bb6:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/lower:lowering", ptr %t38, i32 0, i32 6
  %t41 = load i32, ptr %t40, !tbaa !23
  store i32 %t41, ptr %l5, !tbaa !23
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t44 = load i32, ptr %l4, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t43, i32 %t44)
  br label %bb7
bb7:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/lower:lowering", ptr %t47, i32 0, i32 11
  %t50 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeId_3e_2eSetAt_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t49, i64 %t50, i32 -1)
  br label %bb8
bb8:
  %t53 = load ptr, ptr %l0, !tbaa !29
  store ptr %t53, ptr %l28, !tbaa !29
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/lower:lowering", ptr %t54, i32 0, i32 10
  %t57 = load i64, ptr %l2, !tbaa !24
  %t60 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aBlock_26_3e_2eAt_Hef81d01aee8891fe569e7a3039d88992(ptr %v0, ptr %v0, ptr %t56, i64 %t57)
  store ptr %t60, ptr %l32
  br label %bb9
bb9:
  %t61 = load ptr, ptr %l28, !tbaa !29
  %t62 = load ptr, ptr %l32, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eblock(ptr %v0, ptr %v0, ptr %t61, ptr %t62)
  br label %bb10
bb10:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/lower:lowering", ptr %t63, i32 0, i32 11
  %t66 = load i64, ptr %l2, !tbaa !24
  %t67 = load i32, ptr %l3, !tbaa !23
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeId_3e_2eSetAt_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t65, i64 %t66, i32 %t67)
  br label %bb11
bb11:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t72 = load %"compiler/source:Span", ptr %l1
  store { i64, [7 x i64] } zeroinitializer, ptr %t73
  %t74 = getelementptr { i64, [7 x i64] }, ptr %t73, i32 0, i32 0
  store i64 9, ptr %t74
  %t76 = insertvalue { %"compiler/source:Span" } undef, %"compiler/source:Span" %t72, 0
  %t77 = getelementptr { i64, [7 x i64] }, ptr %t73, i32 0, i32 1
  store { %"compiler/source:Span" } %t76, ptr %t77
  %t78 = load { i64, [7 x i64] }, ptr %t73
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t71, { i64, [7 x i64] } %t78)
  br label %bb12
bb12:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t82 = load i32, ptr %l5, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t81, i32 %t82)
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ecollect(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca { i64, [4 x i64] }
  %l11 = alloca i32
  %l12 = alloca { i64, [1 x i64] }
  %l13 = alloca i32
  %l14 = alloca i32
  %l20 = alloca i32
  %l24 = alloca i1
  %l27 = alloca i64
  %l34 = alloca i32
  %l35 = alloca ptr
  %l38 = alloca i32
  %l40 = alloca i32
  %l42 = alloca { i64, [4 x i64] }
  %l50 = alloca { i64, [4 x i64] }
  %l51 = alloca ptr
  %l52 = alloca { i64, [4 x i64] }
  %l58 = alloca i32
  %l60 = alloca { i64, [4 x i64] }
  %l65 = alloca ptr
  %l66 = alloca i32
  %l67 = alloca i32
  %l68 = alloca { i64, [4 x i64] }
  %l70 = alloca { i64, [4 x i64] }
  %l75 = alloca { i64, [4 x i64] }
  %l89 = alloca i32
  %l93 = alloca { i64, [1 x i64] }
  %l94 = alloca ptr
  %l95 = alloca %"compiler/source:Span"
  %l97 = alloca %"compiler/mir:Place"
  %l109 = alloca i32
  %l110 = alloca ptr
  %l111 = alloca %"compiler/source:Span"
  %l113 = alloca %"compiler/mir:Place"
  %l115 = alloca { i64, [4 x i64] }
  %l120 = alloca ptr
  %l126 = alloca %"compiler/lower:collectCtx"
  %l130 = alloca %"compiler/lower:collectCtx"
  %l133 = alloca %"compiler/lower:collectCtx"
  %l134 = alloca i32
  %l141 = alloca i32
  %l142 = alloca ptr
  %l143 = alloca %"compiler/source:Span"
  %l145 = alloca %"compiler/mir:Place"
  %l146 = alloca { i64, [1 x i64] }
  %l147 = alloca i32
  %l149 = alloca %"compiler/mir:Place"
  %l157 = alloca ptr
  %l159 = alloca { i64, [2 x i64] }
  %l160 = alloca ptr
  %l163 = alloca i32
  %l164 = alloca i1
  %l165 = alloca { i64, ptr }
  %l173 = alloca %"compiler/mir:Place"
  %l174 = alloca ptr
  %l175 = alloca %"compiler/source:Span"
  %l176 = alloca %"compiler/mir:Place"
  %l185 = alloca %"compiler/mir:Place"
  %l187 = alloca %"compiler/mir:Place"
  %l192 = alloca %"compiler/mir:Place"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca { i64, [4 x i64] }
  %t31 = alloca { i64, [4 x i64] }, align 8
  %t156 = alloca { i64, [4 x i64] }, align 8
  %t186 = alloca { i64, [4 x i64] }, align 8
  %t193 = alloca { i64, [15 x i64] }, align 8
  %t205 = alloca { i64, [21 x i64] }, align 8
  %t235 = alloca { i64, [15 x i64] }, align 8
  %t241 = alloca { i64, [21 x i64] }, align 8
  %t293 = alloca { i64, [4 x i64] }, align 8
  %t315 = alloca { i64, [4 x i64] }, align 8
  %t322 = alloca { i64, [4 x i64] }, align 8
  %t329 = alloca { i64, [15 x i64] }, align 8
  %t341 = alloca { i64, [21 x i64] }, align 8
  %t359 = alloca { i64, [2 x i64] }, align 8
  %t375 = alloca { i64, [1 x i64] }, align 8
  %t418 = alloca { i64, [2 x i64] }, align 8
  %t424 = alloca { i64, [1 x i64] }, align 8
  %t448 = alloca { i64, [4 x i64] }, align 8
  %t454 = alloca { i64, [21 x i64] }, align 8
  %t473 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  store %"compiler/source:Span" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t7 = load i32, ptr %l2, !tbaa !23
  %t10 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2earrayOf(ptr %v0, ptr %t6, i32 %t7)
  store i32 %t10, ptr %l20
  br label %bb1
bb1:
  %t11 = load i32, ptr %l20, !tbaa !23
  store i32 %t11, ptr %l5, !tbaa !23
  %t12 = load i32, ptr %l5, !tbaa !23
  %t13 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t16 = icmp eq i32 %t12, %t13
  br i1 %t16, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l24, !tbaa !21
  br label %bb5
bb3:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t19 = load i32, ptr %l5, !tbaa !23
  %t22 = call i64 @compiler_2flower_2ecompiler_2flower_3alowering_2efixedLen(ptr %v0, ptr %t18, i32 %t19)
  store i64 %t22, ptr %l27
  br label %bb4
bb4:
  %t23 = load i64, ptr %l27, !tbaa !24
  %t24 = icmp sge i64 %t23, 0
  store i1 %t24, ptr %l24, !tbaa !21
  br label %bb5
bb5:
  %t26 = load i1, ptr %l24, !tbaa !21
  br i1 %t26, label %bb6, label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s1
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load %"compiler/source:Span", ptr %l3
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2egap(ptr %v0, ptr %s1, ptr %t27, %"compiler/source:Span" %t28, { i64, ptr } { i64 51, ptr @.d15 })
  br label %bb8
bb7:
  br label %bb9
bb8:
  store { i64, [4 x i64] } zeroinitializer, ptr %t31
  %t32 = getelementptr { i64, [4 x i64] }, ptr %t31, i32 0, i32 0
  store i64 0, ptr %t32
  %t33 = load { i64, [4 x i64] }, ptr %t31
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  store { i64, [4 x i64] } %t33, ptr %rv
  br label %ret
bb9:
  %t35 = load ptr, ptr %l4, !tbaa !29
  %t36 = load i32, ptr %l5, !tbaa !23
  %t39 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t35, i32 %t36)
  store i32 %t39, ptr %l34
  br label %bb10
bb10:
  %t40 = load i32, ptr %l34, !tbaa !23
  store i32 %t40, ptr %l6, !tbaa !23
  %t41 = load ptr, ptr %l4, !tbaa !29
  store ptr %t41, ptr %l35, !tbaa !29
  %t42 = load ptr, ptr %l4, !tbaa !29
  %t43 = load i32, ptr %l6, !tbaa !23
  %t46 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArray(ptr %v0, ptr %t42, i32 %t43, i32 0)
  store i32 %t46, ptr %l38
  br label %bb11
bb11:
  %t47 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t48 = load ptr, ptr %l35, !tbaa !29
  %t49 = load i32, ptr %l38, !tbaa !23
  %t51 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t48, i32 %t49, i64 %t47)
  store i32 %t51, ptr %l40
  br label %bb12
bb12:
  %t52 = load i32, ptr %l40, !tbaa !23
  store i32 %t52, ptr %l7, !tbaa !23
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2econstI64(ptr %v0, ptr %t53, i64 100)
  store { i64, [4 x i64] } %t55, ptr %l42
  br label %bb13
bb13:
  %t56 = load { i64, [4 x i64] }, ptr %l42
  store { i64, [4 x i64] } %t56, ptr %l8
  %t57 = load ptr, ptr %l1, !tbaa !29
  %t59 = getelementptr %"compiler/typed:Collect", ptr %t57, i32 0, i32 0
  %t60 = load ptr, ptr %t59, !tbaa !29
  %t62 = icmp eq ptr %t60, null
  %t64 = xor i1 %t62, true
  br i1 %t64, label %bb14, label %bb15
bb14:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t67 = load ptr, ptr %l1, !tbaa !29
  %t69 = getelementptr %"compiler/typed:Collect", ptr %t67, i32 0, i32 0
  %t70 = load ptr, ptr %t69, !tbaa !29
  %t73 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v1, ptr %t66, ptr %t70)
  store { i64, [4 x i64] } %t73, ptr %l50
  br label %bb16
bb15:
  br label %bb28
bb16:
  %t74 = load { i64, [4 x i64] }, ptr %l50
  %t75 = load ptr, ptr %l0, !tbaa !29
  store ptr %t75, ptr %l51, !tbaa !29
  store { i64, [4 x i64] } %t74, ptr %l52
  %t77 = load ptr, ptr %l1, !tbaa !29
  %t79 = getelementptr %"compiler/typed:Collect", ptr %t77, i32 0, i32 0
  %t80 = load ptr, ptr %t79, !tbaa !29
  %t82 = icmp eq ptr %t80, null
  br i1 %t82, label %bb17, label %bb18
bb17:
  call void @__olang_check_failed(ptr @olang_loc_162f2c5d450ff5be_60a02040feb29ca2)
  unreachable
bb18:
  br label %bb19
bb19:
  %t84 = load ptr, ptr %l1, !tbaa !29
  %t86 = getelementptr %"compiler/typed:Collect", ptr %t84, i32 0, i32 0
  %t87 = load ptr, ptr %t86, !tbaa !29
  %t89 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t87)
  store i32 %t89, ptr %l58
  br label %bb20
bb20:
  %t90 = load %"compiler/source:Span", ptr %l3
  %t91 = load ptr, ptr %l51, !tbaa !29
  %t92 = load { i64, [4 x i64] }, ptr %l52
  %t93 = load i32, ptr %l58, !tbaa !23
  %t95 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2easI64(ptr %v0, ptr %t91, { i64, [4 x i64] } %t92, i32 %t93, %"compiler/source:Span" %t90)
  store { i64, [4 x i64] } %t95, ptr %l60
  br label %bb21
bb21:
  %t96 = load { i64, [4 x i64] }, ptr %l60
  store { i64, [4 x i64] } %t96, ptr %l8
  %t97 = load ptr, ptr %l1, !tbaa !29
  %t99 = getelementptr %"compiler/typed:Collect", ptr %t97, i32 0, i32 3
  %t100 = load i32, ptr %t99
  %t102 = trunc i64 0 to i32
  %t103 = icmp eq i32 %t100, %t102
  %t105 = xor i1 %t103, true
  br i1 %t105, label %bb22, label %bb23
bb22:
  store %olang.scope zeroinitializer, ptr %s3
  %t107 = load ptr, ptr %l0, !tbaa !29
  store ptr %t107, ptr %l65, !tbaa !29
  store i32 18, ptr %l66
  %t108 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t108, ptr %l67, !tbaa !23
  %t109 = load { i64, [4 x i64] }, ptr %l8
  store { i64, [4 x i64] } %t109, ptr %l68
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t112 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2econstI64(ptr %v0, ptr %t110, i64 0)
  store { i64, [4 x i64] } %t112, ptr %l70
  br label %bb24
bb23:
  br label %bb27
bb24:
  %t113 = load { i64, [4 x i64] }, ptr %l68
  %t114 = insertvalue [2 x { i64, [4 x i64] }] undef, { i64, [4 x i64] } %t113, 0
  %t115 = load { i64, [4 x i64] }, ptr %l70
  %t116 = insertvalue [2 x { i64, [4 x i64] }] %t114, { i64, [4 x i64] } %t115, 1
  %t118 = load ptr, ptr @__olang_prog_scope
  %t119 = call ptr @__olang_scope_alloc(ptr %t118, i64 80)
  store [2 x { i64, [4 x i64] }] %t116, ptr %t119
  %t120 = insertvalue { i64, ptr } undef, i64 2, 0
  %t121 = insertvalue { i64, ptr } %t120, ptr %t119, 1
  %t123 = extractvalue { i64, ptr } %t121, 0
  %t124 = extractvalue { i64, ptr } %t121, 1
  %t125 = mul i64 %t123, 40
  %t126 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t125)
  call void @llvm.memcpy.p0.p0.i64(ptr %t126, ptr %t124, i64 %t125, i1 false)
  %t127 = insertvalue { i64, ptr } undef, i64 %t123, 0
  %t128 = insertvalue { i64, ptr } %t127, ptr %t126, 1
  %t129 = load %"compiler/source:Span", ptr %l3
  %t130 = load ptr, ptr %l65, !tbaa !29
  %t131 = load i32, ptr %l66
  %t132 = load i32, ptr %l67, !tbaa !23
  %t135 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s3, ptr %t130, i32 %t131, i32 %t132, { i64, ptr } %t128, %"compiler/source:Span" %t129)
  store { i64, [4 x i64] } %t135, ptr %l75
  br label %bb25
bb25:
  %t136 = load { i64, [4 x i64] }, ptr %l75
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t139 = load ptr, ptr %l1, !tbaa !29
  %t141 = getelementptr %"compiler/typed:Collect", ptr %t139, i32 0, i32 3
  %t142 = load i32, ptr %t141
  %t143 = load i64, ptr @G_2ecompiler_2flower_2eOutOfBounds, !tbaa !24
  %t144 = load %"compiler/source:Span", ptr %l3
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2echeck(ptr %v0, ptr %t137, { i64, [4 x i64] } %t136, i32 %t142, i32 7, i64 %t143, %"compiler/source:Span" %t144)
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s3)
  br label %bb27
bb27:
  br label %bb28
bb28:
  %t151 = load ptr, ptr %l0, !tbaa !29
  %t153 = getelementptr %"compiler/lower:lowering", ptr %t151, i32 0, i32 7
  %t154 = load i1, ptr %t153, !tbaa !21
  br i1 %t154, label %bb29, label %bb30
bb29:
  store { i64, [4 x i64] } zeroinitializer, ptr %t156
  %t157 = getelementptr { i64, [4 x i64] }, ptr %t156, i32 0, i32 0
  store i64 0, ptr %t157
  %t158 = load { i64, [4 x i64] }, ptr %t156
  call void @__olang_scope_close(ptr %s0)
  store { i64, [4 x i64] } %t158, ptr %rv
  br label %ret
bb30:
  br label %bb31
bb31:
  %t160 = load ptr, ptr %l0, !tbaa !29
  %t161 = load i32, ptr %l7, !tbaa !23
  %t162 = load %"compiler/source:Span", ptr %l3
  %t166 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2etemp(ptr %v0, ptr %t160, i32 %t161, %"compiler/source:Span" %t162)
  store i32 %t166, ptr %l89
  br label %bb32
bb32:
  %t167 = load i32, ptr %l89, !tbaa !23
  store i32 %t167, ptr %l11, !tbaa !23
  %t168 = load ptr, ptr %l0, !tbaa !29
  %t169 = load ptr, ptr %l1, !tbaa !29
  %t171 = getelementptr %"compiler/typed:Collect", ptr %t169, i32 0, i32 2
  %t172 = load i32, ptr %t171, !tbaa !23
  %t175 = call { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ebuilt(ptr %v0, ptr %t168, i32 %t172)
  store { i64, [1 x i64] } %t175, ptr %l93
  br label %bb33
bb33:
  %t176 = load { i64, [1 x i64] }, ptr %l93
  store { i64, [1 x i64] } %t176, ptr %l12
  %t177 = load ptr, ptr %l0, !tbaa !29
  store ptr %t177, ptr %l94, !tbaa !29
  %t178 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t178, ptr %l95
  %t179 = load i32, ptr %l11, !tbaa !23
  %t181 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t179)
  store %"compiler/mir:Place" %t181, ptr %l97
  br label %bb34
bb34:
  %t182 = load { i64, [1 x i64] }, ptr %l12
  %t183 = load i32, ptr %l7, !tbaa !23
  %t184 = load { i64, [4 x i64] }, ptr %l8
  %t185 = load i32, ptr %l6, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t186
  %t187 = getelementptr { i64, [4 x i64] }, ptr %t186, i32 0, i32 0
  store i64 2, ptr %t187
  %t189 = insertvalue { i32, i64 } undef, i32 %t185, 0
  %t190 = insertvalue { i32, i64 } %t189, i64 0, 1
  %t191 = getelementptr { i64, [4 x i64] }, ptr %t186, i32 0, i32 1
  store { i32, i64 } %t190, ptr %t191
  %t192 = load { i64, [4 x i64] }, ptr %t186
  store { i64, [15 x i64] } zeroinitializer, ptr %t193
  %t194 = getelementptr { i64, [15 x i64] }, ptr %t193, i32 0, i32 0
  store i64 8, ptr %t194
  %t196 = insertvalue { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } } undef, { i64, [1 x i64] } %t182, 0
  %t198 = insertvalue { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } } %t196, i32 %t183, 1
  %t200 = insertvalue { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } } %t198, { i64, [4 x i64] } %t184, 2
  %t202 = insertvalue { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } } %t200, { i64, [4 x i64] } %t192, 3
  %t203 = getelementptr { i64, [15 x i64] }, ptr %t193, i32 0, i32 1
  store { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } } %t202, ptr %t203
  %t204 = load { i64, [15 x i64] }, ptr %t193
  store { i64, [21 x i64] } zeroinitializer, ptr %t205
  %t206 = getelementptr { i64, [21 x i64] }, ptr %t205, i32 0, i32 0
  store i64 0, ptr %t206
  %t207 = load %"compiler/source:Span", ptr %l95
  %t208 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t207, 0
  %t209 = load %"compiler/mir:Place", ptr %l97
  %t210 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t208, %"compiler/mir:Place" %t209, 1
  %t212 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t210, { i64, [15 x i64] } %t204, 2
  %t213 = getelementptr { i64, [21 x i64] }, ptr %t205, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t212, ptr %t213
  %t214 = load { i64, [21 x i64] }, ptr %t205
  %t216 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t214, ptr %t216
  %t217 = load ptr, ptr %l94, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s0, ptr %t217, ptr %t216)
  br label %bb35
bb35:
  %t219 = load ptr, ptr %l0, !tbaa !29
  %t220 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  %t221 = load %"compiler/source:Span", ptr %l3
  %t225 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2etemp(ptr %v0, ptr %t219, i32 %t220, %"compiler/source:Span" %t221)
  store i32 %t225, ptr %l109
  br label %bb36
bb36:
  %t226 = load i32, ptr %l109, !tbaa !23
  store i32 %t226, ptr %l13, !tbaa !23
  %t227 = load ptr, ptr %l0, !tbaa !29
  store ptr %t227, ptr %l110, !tbaa !29
  %t228 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t228, ptr %l111
  %t229 = load i32, ptr %l13, !tbaa !23
  %t231 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t229)
  store %"compiler/mir:Place" %t231, ptr %l113
  br label %bb37
bb37:
  %t232 = load ptr, ptr %l0, !tbaa !29
  %t234 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2econstI64(ptr %v0, ptr %t232, i64 0)
  store { i64, [4 x i64] } %t234, ptr %l115
  br label %bb38
bb38:
  store { i64, [15 x i64] } zeroinitializer, ptr %t235
  %t236 = getelementptr { i64, [15 x i64] }, ptr %t235, i32 0, i32 0
  store i64 0, ptr %t236
  %t237 = load { i64, [4 x i64] }, ptr %l115
  %t238 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t237, 0
  %t239 = getelementptr { i64, [15 x i64] }, ptr %t235, i32 0, i32 1
  store { { i64, [4 x i64] } } %t238, ptr %t239
  %t240 = load { i64, [15 x i64] }, ptr %t235
  store { i64, [21 x i64] } zeroinitializer, ptr %t241
  %t242 = getelementptr { i64, [21 x i64] }, ptr %t241, i32 0, i32 0
  store i64 0, ptr %t242
  %t243 = load %"compiler/source:Span", ptr %l111
  %t244 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t243, 0
  %t245 = load %"compiler/mir:Place", ptr %l113
  %t246 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t244, %"compiler/mir:Place" %t245, 1
  %t248 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t246, { i64, [15 x i64] } %t240, 2
  %t249 = getelementptr { i64, [21 x i64] }, ptr %t241, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t248, ptr %t249
  %t250 = load { i64, [21 x i64] }, ptr %t241
  %t252 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t250, ptr %t252
  %t253 = load ptr, ptr %l110, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s0, ptr %t253, ptr %t252)
  br label %bb39
bb39:
  %t255 = load ptr, ptr %l0, !tbaa !29
  %t257 = getelementptr %"compiler/lower:lowering", ptr %t255, i32 0, i32 14
  store ptr %t257, ptr %l120, !tbaa !29
  %t258 = load i32, ptr %l11, !tbaa !23
  %t259 = load i32, ptr %l13, !tbaa !23
  %t260 = load i32, ptr %l6, !tbaa !23
  %t261 = load i32, ptr %l7, !tbaa !23
  %t262 = load { i64, [1 x i64] }, ptr %l12
  %t268 = call %"compiler/lower:collectCtx" @compiler_2flower_3acollectCtx_2ector(ptr %s0, i32 %t258, i32 %t259, i32 %t260, i32 %t261, { i64, [1 x i64] } %t262)
  store %"compiler/lower:collectCtx" %t268, ptr %l126
  br label %bb40
bb40:
  %t269 = load ptr, ptr %l120, !tbaa !29
  %t270 = load %"compiler/lower:collectCtx", ptr %l126
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3acollectCtx_3e_2e_H653cfca5a0404061ead7e6ea50e2c820(ptr %v0, ptr %t269, %"compiler/lower:collectCtx" %t270)
  br label %bb41
bb41:
  %t271 = load ptr, ptr %l0, !tbaa !29
  %t272 = load ptr, ptr %l1, !tbaa !29
  %t274 = getelementptr %"compiler/typed:Collect", ptr %t272, i32 0, i32 1
  %t275 = load ptr, ptr %t274, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eblock(ptr %v0, ptr %v1, ptr %t271, ptr %t275)
  br label %bb42
bb42:
  %t278 = load ptr, ptr %l0, !tbaa !29
  %t280 = getelementptr %"compiler/lower:lowering", ptr %t278, i32 0, i32 14
  %t282 = call { i32, %"compiler/lower:collectCtx" } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3acollectCtx_3e_2e_Hcb64b7cee1ab394e20e0c0dd5741806d(ptr %v0, ptr %t280)
  %t283 = extractvalue { i32, %"compiler/lower:collectCtx" } %t282, 1
  %t284 = extractvalue { i32, %"compiler/lower:collectCtx" } %t282, 0
  store i32 %t284, ptr %l134
  %t285 = icmp ne i32 %t284, 0
  br i1 %t285, label %bb44, label %ok.286
ok.286:
  store %"compiler/lower:collectCtx" %t283, ptr %l133
  br label %bb43
bb43:
  %t287 = load %"compiler/lower:collectCtx", ptr %l133
  store %"compiler/lower:collectCtx" %t287, ptr %l130
  br label %bb46
bb44:
  br label %bb45
bb45:
  br label %bb46
bb46:
  %t288 = load ptr, ptr %l0, !tbaa !29
  %t290 = getelementptr %"compiler/lower:lowering", ptr %t288, i32 0, i32 7
  %t291 = load i1, ptr %t290, !tbaa !21
  br i1 %t291, label %bb47, label %bb48
bb47:
  store { i64, [4 x i64] } zeroinitializer, ptr %t293
  %t294 = getelementptr { i64, [4 x i64] }, ptr %t293, i32 0, i32 0
  store i64 0, ptr %t294
  %t295 = load { i64, [4 x i64] }, ptr %t293
  call void @__olang_scope_close(ptr %s0)
  store { i64, [4 x i64] } %t295, ptr %rv
  br label %ret
bb48:
  br label %bb49
bb49:
  %t297 = load ptr, ptr %l0, !tbaa !29
  %t298 = load i32, ptr %l2, !tbaa !23
  %t299 = load %"compiler/source:Span", ptr %l3
  %t303 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2etemp(ptr %v0, ptr %t297, i32 %t298, %"compiler/source:Span" %t299)
  store i32 %t303, ptr %l141
  br label %bb50
bb50:
  %t304 = load i32, ptr %l141, !tbaa !23
  store i32 %t304, ptr %l14, !tbaa !23
  %t305 = load ptr, ptr %l0, !tbaa !29
  store ptr %t305, ptr %l142, !tbaa !29
  %t306 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t306, ptr %l143
  %t307 = load i32, ptr %l14, !tbaa !23
  %t309 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t307)
  store %"compiler/mir:Place" %t309, ptr %l145
  br label %bb51
bb51:
  %t310 = load { i64, [1 x i64] }, ptr %l12
  store { i64, [1 x i64] } %t310, ptr %l146
  %t311 = load i32, ptr %l2, !tbaa !23
  store i32 %t311, ptr %l147, !tbaa !23
  %t312 = load i32, ptr %l13, !tbaa !23
  %t314 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t312)
  store %"compiler/mir:Place" %t314, ptr %l149
  br label %bb52
bb52:
  store { i64, [4 x i64] } zeroinitializer, ptr %t315
  %t316 = getelementptr { i64, [4 x i64] }, ptr %t315, i32 0, i32 0
  store i64 1, ptr %t316
  %t317 = load %"compiler/mir:Place", ptr %l149
  %t318 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t317, 0
  %t319 = getelementptr { i64, [4 x i64] }, ptr %t315, i32 0, i32 1
  store { %"compiler/mir:Place" } %t318, ptr %t319
  %t320 = load { i64, [4 x i64] }, ptr %t315
  %t321 = load i32, ptr %l6, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t322
  %t323 = getelementptr { i64, [4 x i64] }, ptr %t322, i32 0, i32 0
  store i64 2, ptr %t323
  %t325 = insertvalue { i32, i64 } undef, i32 %t321, 0
  %t326 = insertvalue { i32, i64 } %t325, i64 0, 1
  %t327 = getelementptr { i64, [4 x i64] }, ptr %t322, i32 0, i32 1
  store { i32, i64 } %t326, ptr %t327
  %t328 = load { i64, [4 x i64] }, ptr %t322
  store { i64, [15 x i64] } zeroinitializer, ptr %t329
  %t330 = getelementptr { i64, [15 x i64] }, ptr %t329, i32 0, i32 0
  store i64 8, ptr %t330
  %t331 = load { i64, [1 x i64] }, ptr %l146
  %t332 = insertvalue { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } } undef, { i64, [1 x i64] } %t331, 0
  %t333 = load i32, ptr %l147, !tbaa !23
  %t334 = insertvalue { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } } %t332, i32 %t333, 1
  %t336 = insertvalue { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } } %t334, { i64, [4 x i64] } %t320, 2
  %t338 = insertvalue { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } } %t336, { i64, [4 x i64] } %t328, 3
  %t339 = getelementptr { i64, [15 x i64] }, ptr %t329, i32 0, i32 1
  store { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } } %t338, ptr %t339
  %t340 = load { i64, [15 x i64] }, ptr %t329
  store { i64, [21 x i64] } zeroinitializer, ptr %t341
  %t342 = getelementptr { i64, [21 x i64] }, ptr %t341, i32 0, i32 0
  store i64 0, ptr %t342
  %t343 = load %"compiler/source:Span", ptr %l143
  %t344 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t343, 0
  %t345 = load %"compiler/mir:Place", ptr %l145
  %t346 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t344, %"compiler/mir:Place" %t345, 1
  %t348 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t346, { i64, [15 x i64] } %t340, 2
  %t349 = getelementptr { i64, [21 x i64] }, ptr %t341, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t348, ptr %t349
  %t350 = load { i64, [21 x i64] }, ptr %t341
  %t352 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t350, ptr %t352
  %t353 = load ptr, ptr %l142, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s0, ptr %t353, ptr %t352)
  br label %bb53
bb53:
  %t355 = load ptr, ptr %l0, !tbaa !29
  %t357 = getelementptr %"compiler/lower:lowering", ptr %t355, i32 0, i32 3
  store ptr %t357, ptr %l157, !tbaa !29
  %t358 = load i32, ptr %l14, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t359
  %t360 = getelementptr { i64, [2 x i64] }, ptr %t359, i32 0, i32 0
  store i64 1, ptr %t360
  %t362 = insertvalue { i32 } undef, i32 %t358, 0
  %t363 = getelementptr { i64, [2 x i64] }, ptr %t359, i32 0, i32 1
  store { i32 } %t362, ptr %t363
  %t364 = load { i64, [2 x i64] }, ptr %t359
  store { i64, [2 x i64] } %t364, ptr %l159
  %t365 = load ptr, ptr %l4, !tbaa !29
  store ptr %t365, ptr %l160, !tbaa !29
  %t366 = load ptr, ptr %l4, !tbaa !29
  %t367 = load i32, ptr %l2, !tbaa !23
  %t370 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t366, i32 %t367)
  store i32 %t370, ptr %l163
  br label %bb54
bb54:
  %t371 = load ptr, ptr %l160, !tbaa !29
  %t372 = load i32, ptr %l163, !tbaa !23
  %t373 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t371, i32 %t372)
  store i1 %t373, ptr %l164
  br label %bb55
bb55:
  %t374 = load i1, ptr %l164, !tbaa !21
  br i1 %t374, label %bb56, label %bb57
bb56:
  store { i64, [1 x i64] } zeroinitializer, ptr %t375
  %t376 = getelementptr { i64, [1 x i64] }, ptr %t375, i32 0, i32 0
  store i64 3, ptr %t376
  %t377 = load { i64, [1 x i64] }, ptr %t375
  %t379 = insertvalue [1 x { i64, [1 x i64] }] undef, { i64, [1 x i64] } %t377, 0
  %t381 = load ptr, ptr @__olang_prog_scope
  %t382 = call ptr @__olang_scope_alloc(ptr %t381, i64 16)
  store [1 x { i64, [1 x i64] }] %t379, ptr %t382
  %t383 = insertvalue { i64, ptr } undef, i64 1, 0
  %t384 = insertvalue { i64, ptr } %t383, ptr %t382, 1
  %t386 = extractvalue { i64, ptr } %t384, 0
  %t387 = extractvalue { i64, ptr } %t384, 1
  %t388 = mul i64 %t386, 16
  %t389 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t388)
  call void @llvm.memcpy.p0.p0.i64(ptr %t389, ptr %t387, i64 %t388, i1 false)
  %t390 = insertvalue { i64, ptr } undef, i64 %t386, 0
  %t391 = insertvalue { i64, ptr } %t390, ptr %t389, 1
  store { i64, ptr } %t391, ptr %l165, !tbaa !27
  br label %bb58
bb57:
  %t394 = load ptr, ptr @__olang_prog_scope
  %t395 = call ptr @__olang_scope_alloc(ptr %t394, i64 0)
  store [0 x { i64, [1 x i64] }] zeroinitializer, ptr %t395
  %t396 = insertvalue { i64, ptr } undef, i64 0, 0
  %t397 = insertvalue { i64, ptr } %t396, ptr %t395, 1
  %t399 = extractvalue { i64, ptr } %t397, 0
  %t400 = extractvalue { i64, ptr } %t397, 1
  %t401 = mul i64 %t399, 16
  %t402 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t401)
  call void @llvm.memcpy.p0.p0.i64(ptr %t402, ptr %t400, i64 %t401, i1 false)
  %t403 = insertvalue { i64, ptr } undef, i64 %t399, 0
  %t404 = insertvalue { i64, ptr } %t403, ptr %t402, 1
  store { i64, ptr } %t404, ptr %l165, !tbaa !27
  br label %bb58
bb58:
  %t406 = load ptr, ptr %l157, !tbaa !29
  %t407 = load { i64, [2 x i64] }, ptr %l159
  %t408 = load { i64, ptr }, ptr %l165, !tbaa !27
  %t409 = call %"compiler/mir:Place" @compiler_2fmir_2ecompiler_2fmir_3aFn_2ePlace(ptr %v0, ptr %s0, ptr %t406, { i64, [2 x i64] } %t407, { i64, ptr } %t408)
  store %"compiler/mir:Place" %t409, ptr %l173
  br label %bb59
bb59:
  %t410 = load %"compiler/mir:Place", ptr %l173
  %t411 = load ptr, ptr %l0, !tbaa !29
  store ptr %t411, ptr %l174, !tbaa !29
  %t412 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t412, ptr %l175
  store %"compiler/mir:Place" %t410, ptr %l176
  %t414 = load ptr, ptr %l0, !tbaa !29
  %t416 = getelementptr %"compiler/lower:lowering", ptr %t414, i32 0, i32 3
  %t417 = load i32, ptr %l11, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t418
  %t419 = getelementptr { i64, [2 x i64] }, ptr %t418, i32 0, i32 0
  store i64 1, ptr %t419
  %t421 = insertvalue { i32 } undef, i32 %t417, 0
  %t422 = getelementptr { i64, [2 x i64] }, ptr %t418, i32 0, i32 1
  store { i32 } %t421, ptr %t422
  %t423 = load { i64, [2 x i64] }, ptr %t418
  store { i64, [1 x i64] } zeroinitializer, ptr %t424
  %t425 = getelementptr { i64, [1 x i64] }, ptr %t424, i32 0, i32 0
  store i64 3, ptr %t425
  %t426 = load { i64, [1 x i64] }, ptr %t424
  %t428 = insertvalue [1 x { i64, [1 x i64] }] undef, { i64, [1 x i64] } %t426, 0
  %t430 = load ptr, ptr @__olang_prog_scope
  %t431 = call ptr @__olang_scope_alloc(ptr %t430, i64 16)
  store [1 x { i64, [1 x i64] }] %t428, ptr %t431
  %t432 = insertvalue { i64, ptr } undef, i64 1, 0
  %t433 = insertvalue { i64, ptr } %t432, ptr %t431, 1
  %t435 = extractvalue { i64, ptr } %t433, 0
  %t436 = extractvalue { i64, ptr } %t433, 1
  %t437 = mul i64 %t435, 16
  %t438 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t437)
  call void @llvm.memcpy.p0.p0.i64(ptr %t438, ptr %t436, i64 %t437, i1 false)
  %t439 = insertvalue { i64, ptr } undef, i64 %t435, 0
  %t440 = insertvalue { i64, ptr } %t439, ptr %t438, 1
  %t444 = call %"compiler/mir:Place" @compiler_2fmir_2ecompiler_2fmir_3aFn_2ePlace(ptr %v0, ptr %s0, ptr %t416, { i64, [2 x i64] } %t423, { i64, ptr } %t440)
  store %"compiler/mir:Place" %t444, ptr %l185
  br label %bb60
bb60:
  %t445 = load i32, ptr %l13, !tbaa !23
  %t447 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t445)
  store %"compiler/mir:Place" %t447, ptr %l187
  br label %bb61
bb61:
  store { i64, [4 x i64] } zeroinitializer, ptr %t448
  %t449 = getelementptr { i64, [4 x i64] }, ptr %t448, i32 0, i32 0
  store i64 1, ptr %t449
  %t450 = load %"compiler/mir:Place", ptr %l187
  %t451 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t450, 0
  %t452 = getelementptr { i64, [4 x i64] }, ptr %t448, i32 0, i32 1
  store { %"compiler/mir:Place" } %t451, ptr %t452
  %t453 = load { i64, [4 x i64] }, ptr %t448
  store { i64, [21 x i64] } zeroinitializer, ptr %t454
  %t455 = getelementptr { i64, [21 x i64] }, ptr %t454, i32 0, i32 0
  store i64 10, ptr %t455
  %t456 = load %"compiler/source:Span", ptr %l175
  %t457 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", %"compiler/mir:Place", { i64, [4 x i64] } } undef, %"compiler/source:Span" %t456, 0
  %t458 = load %"compiler/mir:Place", ptr %l176
  %t459 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", %"compiler/mir:Place", { i64, [4 x i64] } } %t457, %"compiler/mir:Place" %t458, 1
  %t460 = load %"compiler/mir:Place", ptr %l185
  %t461 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", %"compiler/mir:Place", { i64, [4 x i64] } } %t459, %"compiler/mir:Place" %t460, 2
  %t463 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", %"compiler/mir:Place", { i64, [4 x i64] } } %t461, { i64, [4 x i64] } %t453, 3
  %t464 = getelementptr { i64, [21 x i64] }, ptr %t454, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Place", %"compiler/mir:Place", { i64, [4 x i64] } } %t463, ptr %t464
  %t465 = load { i64, [21 x i64] }, ptr %t454
  %t467 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t465, ptr %t467
  %t468 = load ptr, ptr %l174, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s0, ptr %t468, ptr %t467)
  br label %bb62
bb62:
  %t470 = load i32, ptr %l14, !tbaa !23
  %t472 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t470)
  store %"compiler/mir:Place" %t472, ptr %l192
  br label %bb63
bb63:
  store { i64, [4 x i64] } zeroinitializer, ptr %t473
  %t474 = getelementptr { i64, [4 x i64] }, ptr %t473, i32 0, i32 0
  store i64 1, ptr %t474
  %t475 = load %"compiler/mir:Place", ptr %l192
  %t476 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t475, 0
  %t477 = getelementptr { i64, [4 x i64] }, ptr %t473, i32 0, i32 1
  store { %"compiler/mir:Place" } %t476, ptr %t477
  %t478 = load { i64, [4 x i64] }, ptr %t473
  call void @__olang_scope_close(ptr %s0)
  store { i64, [4 x i64] } %t478, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2econd(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca { i64, [4 x i64] }
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l9 = alloca { i64, [4 x i64] }
  %l10 = alloca { i64, [4 x i64] }
  %l15 = alloca { i64, [4 x i64] }
  %l22 = alloca i32
  %l25 = alloca i32
  %l28 = alloca i32
  %l34 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l40 = alloca { i64, [4 x i64] }
  %l41 = alloca ptr
  %l42 = alloca %"compiler/source:Span"
  %l44 = alloca %"compiler/mir:Place"
  %l57 = alloca { i64, [4 x i64] }
  %l58 = alloca ptr
  %l59 = alloca %"compiler/source:Span"
  %l61 = alloca %"compiler/mir:Place"
  %l71 = alloca %"compiler/mir:Place"
  %s0 = alloca %olang.scope
  %rv = alloca { i64, [4 x i64] }
  %t16 = alloca { i64, [4 x i64] }, align 8
  %t44 = alloca { i64, [7 x i64] }, align 8
  %t78 = alloca { i64, [15 x i64] }, align 8
  %t84 = alloca { i64, [21 x i64] }, align 8
  %t121 = alloca { i64, [15 x i64] }, align 8
  %t127 = alloca { i64, [21 x i64] }, align 8
  %t151 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store %"compiler/source:Span" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t4 = getelementptr %"compiler/typed:Cond", ptr %t2, i32 0, i32 0
  %t5 = load ptr, ptr %t4, !tbaa !29
  %t9 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v1, ptr %t1, ptr %t5)
  store { i64, [4 x i64] } %t9, ptr %l15
  br label %bb1
bb1:
  %t10 = load { i64, [4 x i64] }, ptr %l15
  store { i64, [4 x i64] } %t10, ptr %l4
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/lower:lowering", ptr %t11, i32 0, i32 7
  %t14 = load i1, ptr %t13, !tbaa !21
  br i1 %t14, label %bb2, label %bb3
bb2:
  store { i64, [4 x i64] } zeroinitializer, ptr %t16
  %t17 = getelementptr { i64, [4 x i64] }, ptr %t16, i32 0, i32 0
  store i64 0, ptr %t17
  %t18 = load { i64, [4 x i64] }, ptr %t16
  call void @__olang_scope_close(ptr %s0)
  store { i64, [4 x i64] } %t18, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = load %"compiler/source:Span", ptr %l3
  %t26 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2etemp(ptr %v0, ptr %t20, i32 %a2, %"compiler/source:Span" %t22)
  store i32 %t26, ptr %l22
  br label %bb5
bb5:
  %t27 = load i32, ptr %l22, !tbaa !23
  store i32 %t27, ptr %l5, !tbaa !23
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/lower:lowering", ptr %t28, i32 0, i32 3
  %t32 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t30)
  store i32 %t32, ptr %l25
  br label %bb6
bb6:
  %t33 = load i32, ptr %l25, !tbaa !23
  store i32 %t33, ptr %l6, !tbaa !23
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/lower:lowering", ptr %t34, i32 0, i32 3
  %t38 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t36)
  store i32 %t38, ptr %l28
  br label %bb7
bb7:
  %t39 = load i32, ptr %l28, !tbaa !23
  store i32 %t39, ptr %l7, !tbaa !23
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t41 = load { i64, [4 x i64] }, ptr %l4
  %t42 = load i32, ptr %l6, !tbaa !23
  %t43 = load i32, ptr %l7, !tbaa !23
  store { i64, [7 x i64] } zeroinitializer, ptr %t44
  %t45 = getelementptr { i64, [7 x i64] }, ptr %t44, i32 0, i32 0
  store i64 2, ptr %t45
  %t47 = insertvalue { { i64, [4 x i64] }, i32, i32 } undef, { i64, [4 x i64] } %t41, 0
  %t49 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t47, i32 %t42, 1
  %t51 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t49, i32 %t43, 2
  %t52 = getelementptr { i64, [7 x i64] }, ptr %t44, i32 0, i32 1
  store { { i64, [4 x i64] }, i32, i32 } %t51, ptr %t52
  %t53 = load { i64, [7 x i64] }, ptr %t44
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t40, { i64, [7 x i64] } %t53)
  br label %bb8
bb8:
  %t56 = load ptr, ptr @__olang_prog_scope
  %t57 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aBlockId_3e(ptr %t56)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t57, ptr %l34
  br label %bb9
bb9:
  %t58 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l34
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t58, ptr %l8
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t60 = load i32, ptr %l6, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t59, i32 %t60)
  br label %bb10
bb10:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t64 = load ptr, ptr %l1, !tbaa !29
  %t66 = getelementptr %"compiler/typed:Cond", ptr %t64, i32 0, i32 1
  %t67 = load ptr, ptr %t66, !tbaa !29
  %t70 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v1, ptr %t63, ptr %t67)
  store { i64, [4 x i64] } %t70, ptr %l40
  br label %bb11
bb11:
  %t71 = load { i64, [4 x i64] }, ptr %l40
  store { i64, [4 x i64] } %t71, ptr %l9
  %t72 = load ptr, ptr %l0, !tbaa !29
  store ptr %t72, ptr %l41, !tbaa !29
  %t73 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t73, ptr %l42
  %t74 = load i32, ptr %l5, !tbaa !23
  %t76 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t74)
  store %"compiler/mir:Place" %t76, ptr %l44
  br label %bb12
bb12:
  %t77 = load { i64, [4 x i64] }, ptr %l9
  store { i64, [15 x i64] } zeroinitializer, ptr %t78
  %t79 = getelementptr { i64, [15 x i64] }, ptr %t78, i32 0, i32 0
  store i64 0, ptr %t79
  %t81 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t77, 0
  %t82 = getelementptr { i64, [15 x i64] }, ptr %t78, i32 0, i32 1
  store { { i64, [4 x i64] } } %t81, ptr %t82
  %t83 = load { i64, [15 x i64] }, ptr %t78
  store { i64, [21 x i64] } zeroinitializer, ptr %t84
  %t85 = getelementptr { i64, [21 x i64] }, ptr %t84, i32 0, i32 0
  store i64 0, ptr %t85
  %t86 = load %"compiler/source:Span", ptr %l42
  %t87 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t86, 0
  %t88 = load %"compiler/mir:Place", ptr %l44
  %t89 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t87, %"compiler/mir:Place" %t88, 1
  %t91 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t89, { i64, [15 x i64] } %t83, 2
  %t92 = getelementptr { i64, [21 x i64] }, ptr %t84, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t91, ptr %t92
  %t93 = load { i64, [21 x i64] }, ptr %t84
  %t95 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t93, ptr %t95
  %t96 = load ptr, ptr %l41, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s0, ptr %t96, ptr %t95)
  br label %bb13
bb13:
  %t98 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eleaveOpen(ptr %v0, ptr %s0, ptr %t98, ptr %l8)
  br label %bb14
bb14:
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t102 = load i32, ptr %l7, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t101, i32 %t102)
  br label %bb15
bb15:
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t106 = load ptr, ptr %l1, !tbaa !29
  %t108 = getelementptr %"compiler/typed:Cond", ptr %t106, i32 0, i32 2
  %t109 = load ptr, ptr %t108, !tbaa !29
  %t113 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v1, ptr %t105, ptr %t109)
  store { i64, [4 x i64] } %t113, ptr %l57
  br label %bb16
bb16:
  %t114 = load { i64, [4 x i64] }, ptr %l57
  store { i64, [4 x i64] } %t114, ptr %l10
  %t115 = load ptr, ptr %l0, !tbaa !29
  store ptr %t115, ptr %l58, !tbaa !29
  %t116 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t116, ptr %l59
  %t117 = load i32, ptr %l5, !tbaa !23
  %t119 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t117)
  store %"compiler/mir:Place" %t119, ptr %l61
  br label %bb17
bb17:
  %t120 = load { i64, [4 x i64] }, ptr %l10
  store { i64, [15 x i64] } zeroinitializer, ptr %t121
  %t122 = getelementptr { i64, [15 x i64] }, ptr %t121, i32 0, i32 0
  store i64 0, ptr %t122
  %t124 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t120, 0
  %t125 = getelementptr { i64, [15 x i64] }, ptr %t121, i32 0, i32 1
  store { { i64, [4 x i64] } } %t124, ptr %t125
  %t126 = load { i64, [15 x i64] }, ptr %t121
  store { i64, [21 x i64] } zeroinitializer, ptr %t127
  %t128 = getelementptr { i64, [21 x i64] }, ptr %t127, i32 0, i32 0
  store i64 0, ptr %t128
  %t129 = load %"compiler/source:Span", ptr %l59
  %t130 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t129, 0
  %t131 = load %"compiler/mir:Place", ptr %l61
  %t132 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t130, %"compiler/mir:Place" %t131, 1
  %t134 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t132, { i64, [15 x i64] } %t126, 2
  %t135 = getelementptr { i64, [21 x i64] }, ptr %t127, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t134, ptr %t135
  %t136 = load { i64, [21 x i64] }, ptr %t127
  %t138 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t136, ptr %t138
  %t139 = load ptr, ptr %l58, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s0, ptr %t139, ptr %t138)
  br label %bb18
bb18:
  %t141 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eleaveOpen(ptr %v0, ptr %s0, ptr %t141, ptr %l8)
  br label %bb19
bb19:
  %t144 = load ptr, ptr %l0, !tbaa !29
  %t145 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l8
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2epatch(ptr %v0, ptr %s0, ptr %t144, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t145)
  br label %bb20
bb20:
  %t148 = load i32, ptr %l5, !tbaa !23
  %t150 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t148)
  store %"compiler/mir:Place" %t150, ptr %l71
  br label %bb21
bb21:
  store { i64, [4 x i64] } zeroinitializer, ptr %t151
  %t152 = getelementptr { i64, [4 x i64] }, ptr %t151, i32 0, i32 0
  store i64 1, ptr %t152
  %t153 = load %"compiler/mir:Place", ptr %l71
  %t154 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t153, 0
  %t155 = getelementptr { i64, [4 x i64] }, ptr %t151, i32 0, i32 1
  store { %"compiler/mir:Place" } %t154, ptr %t155
  %t156 = load { i64, [4 x i64] }, ptr %t151
  call void @__olang_scope_close(ptr %s0)
  store { i64, [4 x i64] } %t156, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2econstI64(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %rv = alloca { i64, [4 x i64] }
  %t3 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t3
  %t4 = getelementptr { i64, [4 x i64] }, ptr %t3, i32 0, i32 0
  store i64 2, ptr %t4
  %t6 = insertvalue { i32, i64 } undef, i32 %t1, 0
  %t8 = insertvalue { i32, i64 } %t6, i64 %a1, 1
  %t9 = getelementptr { i64, [4 x i64] }, ptr %t3, i32 0, i32 1
  store { i32, i64 } %t8, ptr %t9
  %t10 = load { i64, [4 x i64] }, ptr %t3
  store { i64, [4 x i64] } %t10, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3alowering_2ecopiesArray(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l1 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l7 = alloca i1
  %l10 = alloca i1
  %l11 = alloca ptr
  %l12 = alloca i1
  %l15 = alloca ptr
  %l16 = alloca i1
  %l25 = alloca i1
  %l29 = alloca i1
  %l30 = alloca { i64, ptr }
  %l32 = alloca ptr
  %rv = alloca i1
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2evalueArray(ptr %v0, ptr %a0, i32 %a2)
  store i1 %t5, ptr %l7
  br label %bb1
bb1:
  %t6 = load i1, ptr %l7, !tbaa !21
  %t7 = xor i1 %t6, true
  br i1 %t7, label %bb2, label %bb3
bb2:
  store i1 false, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t10 = load ptr, ptr %l1, !tbaa !29
  store ptr %t10, ptr %l11, !tbaa !29
  store i1 false, ptr %l12, !tbaa !21
  %t11 = load ptr, ptr %l11, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb5, label %bb6
bb5:
  %t14 = load ptr, ptr %l11, !tbaa !29
  %t15 = load i64, ptr %t14
  %t17 = icmp eq i64 %t15, 2
  store i1 %t17, ptr %l12, !tbaa !21
  br label %bb6
bb6:
  %t18 = load i1, ptr %l12, !tbaa !21
  br i1 %t18, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store i1 true, ptr %l10, !tbaa !21
  br label %bb28
bb10:
  %t19 = load ptr, ptr %l1, !tbaa !29
  store ptr %t19, ptr %l15, !tbaa !29
  store i1 false, ptr %l16, !tbaa !21
  %t20 = load ptr, ptr %l15, !tbaa !29
  %t21 = icmp ne ptr %t20, null
  br i1 %t21, label %bb11, label %bb12
bb11:
  %t23 = load ptr, ptr %l15, !tbaa !29
  %t24 = load i64, ptr %t23
  %t26 = icmp eq i64 %t24, 9
  store i1 %t26, ptr %l16, !tbaa !21
  br label %bb12
bb12:
  %t27 = load i1, ptr %l16, !tbaa !21
  br i1 %t27, label %bb13, label %bb14
bb13:
  %t28 = load ptr, ptr %l1, !tbaa !29
  %t30 = getelementptr { i64, [5 x i64] }, ptr %t28, i32 0, i32 1
  %t31 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t30, i32 0, i32 2
  %t32 = load i32, ptr %t31
  store i32 %t32, ptr %l3
  %t34 = load ptr, ptr %l1, !tbaa !29
  %t36 = getelementptr { i64, [5 x i64] }, ptr %t34, i32 0, i32 1
  %t37 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t36, i32 0, i32 4
  %t38 = load { i64, ptr }, ptr %t37
  store { i64, ptr } %t38, ptr %l4, !tbaa !27
  br label %bb15
bb14:
  br label %bb23
bb15:
  %t40 = load i32, ptr %l3
  %t42 = trunc i64 20 to i32
  %t43 = icmp eq i32 %t40, %t42
  br i1 %t43, label %bb16, label %bb17
bb16:
  %t45 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t47 = extractvalue { i64, ptr } %t45, 0
  %t49 = icmp eq i64 %t47, 1
  store i1 %t49, ptr %l25, !tbaa !21
  br label %bb18
bb17:
  store i1 false, ptr %l25, !tbaa !21
  br label %bb18
bb18:
  %t51 = load i1, ptr %l25, !tbaa !21
  br i1 %t51, label %bb19, label %bb20
bb19:
  %t52 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t52, ptr %l30, !tbaa !27
  %t53 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !27
  %t55 = getelementptr ptr, ptr %t54, i64 0
  %t56 = load ptr, ptr %t55, !tbaa !39
  %t58 = call ptr @compiler_2flower_2ederefOf(ptr %v1, ptr %t56)
  store ptr %t58, ptr %l32
  br label %bb21
bb20:
  store i1 false, ptr %l29, !tbaa !21
  br label %bb22
bb21:
  %t59 = load ptr, ptr %l32, !tbaa !29
  %t60 = icmp eq ptr %t59, null
  %t62 = xor i1 %t60, true
  store i1 %t62, ptr %l29, !tbaa !21
  br label %bb22
bb22:
  %t64 = load i1, ptr %l29, !tbaa !21
  store i1 %t64, ptr %l10, !tbaa !21
  br label %bb28
bb23:
  br i1 true, label %bb24, label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb27
bb26:
  store i1 false, ptr %l10, !tbaa !21
  br label %bb28
bb27:
  call void @__olang_check_failed(ptr @olang_loc_1b831ae1fe8ac0a9_779ca48b185ae2e5)
  unreachable
bb28:
  %t65 = load i1, ptr %l10, !tbaa !21
  store i1 %t65, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ecopyLocal(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca %"compiler/mir:Place"
  %rv = alloca { i64, [4 x i64] }
  %t4 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %a1)
  store %"compiler/mir:Place" %t3, ptr %l3
  br label %bb1
bb1:
  store { i64, [4 x i64] } zeroinitializer, ptr %t4
  %t5 = getelementptr { i64, [4 x i64] }, ptr %t4, i32 0, i32 0
  store i64 1, ptr %t5
  %t6 = load %"compiler/mir:Place", ptr %l3
  %t7 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t6, 0
  %t8 = getelementptr { i64, [4 x i64] }, ptr %t4, i32 0, i32 1
  store { %"compiler/mir:Place" } %t7, ptr %t8
  %t9 = load { i64, [4 x i64] }, ptr %t4
  store { i64, [4 x i64] } %t9, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2ederef(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca { i64, [4 x i64] }
  %l8 = alloca { i64, [4 x i64] }
  %l12 = alloca %"compiler/lower:pl"
  %l13 = alloca ptr
  %l14 = alloca { i64, [4 x i64] }
  %l16 = alloca i32
  %l18 = alloca i32
  %l19 = alloca ptr
  %l22 = alloca %"compiler/lower:pl"
  %l24 = alloca %"compiler/lower:pl"
  %rv = alloca %"compiler/lower:pl"
  %t13 = alloca { i64, [2 x i64] }, align 8
  %t33 = alloca { i64, [2 x i64] }, align 8
  %t41 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t6 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v1, ptr %t1, ptr %t2)
  store { i64, [4 x i64] } %t6, ptr %l8
  br label %bb1
bb1:
  %t7 = load { i64, [4 x i64] }, ptr %l8
  store { i64, [4 x i64] } %t7, ptr %l3
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/lower:lowering", ptr %t8, i32 0, i32 7
  %t11 = load i1, ptr %t10, !tbaa !21
  br i1 %t11, label %bb2, label %bb3
bb2:
  store { i64, [2 x i64] } zeroinitializer, ptr %t13
  %t14 = getelementptr { i64, [2 x i64] }, ptr %t13, i32 0, i32 0
  store i64 0, ptr %t14
  %t15 = load { i64, [2 x i64] }, ptr %t13
  %t17 = call %"compiler/lower:pl" @compiler_2flower_3apl_2ector(ptr %v2, { i64, [2 x i64] } %t15)
  store %"compiler/lower:pl" %t17, ptr %l12
  br label %bb4
bb3:
  br label %bb5
bb4:
  %t18 = load %"compiler/lower:pl", ptr %l12
  store %"compiler/lower:pl" %t18, ptr %rv
  br label %ret
bb5:
  %t19 = load ptr, ptr %l0, !tbaa !29
  store ptr %t19, ptr %l13, !tbaa !29
  %t20 = load { i64, [4 x i64] }, ptr %l3
  store { i64, [4 x i64] } %t20, ptr %l14
  %t21 = load ptr, ptr %l1, !tbaa !29
  %t23 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t21)
  store i32 %t23, ptr %l16
  br label %bb6
bb6:
  %t25 = load ptr, ptr %l13, !tbaa !29
  %t26 = load { i64, [4 x i64] }, ptr %l14
  %t27 = load i32, ptr %l16, !tbaa !23
  %t29 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2elocal(ptr %v0, ptr %t25, { i64, [4 x i64] } %t26, i32 %t27, %"compiler/source:Span" %a2)
  store i32 %t29, ptr %l18
  br label %bb7
bb7:
  %t30 = load i32, ptr %l18, !tbaa !23
  %t31 = load ptr, ptr %l0, !tbaa !29
  store ptr %t31, ptr %l19, !tbaa !29
  store { i64, [2 x i64] } zeroinitializer, ptr %t33
  %t34 = getelementptr { i64, [2 x i64] }, ptr %t33, i32 0, i32 0
  store i64 1, ptr %t34
  %t36 = insertvalue { i32 } undef, i32 %t30, 0
  %t37 = getelementptr { i64, [2 x i64] }, ptr %t33, i32 0, i32 1
  store { i32 } %t36, ptr %t37
  %t38 = load { i64, [2 x i64] }, ptr %t33
  %t40 = call %"compiler/lower:pl" @compiler_2flower_3apl_2ector(ptr %v2, { i64, [2 x i64] } %t38)
  store %"compiler/lower:pl" %t40, ptr %l22
  br label %bb8
bb8:
  store { i64, [1 x i64] } zeroinitializer, ptr %t41
  %t42 = getelementptr { i64, [1 x i64] }, ptr %t41, i32 0, i32 0
  store i64 3, ptr %t42
  %t43 = load { i64, [1 x i64] }, ptr %t41
  %t44 = load ptr, ptr %l19, !tbaa !29
  %t45 = load %"compiler/lower:pl", ptr %l22
  %t47 = call %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2ewith(ptr %v0, ptr %v2, ptr %v2, ptr %t44, %"compiler/lower:pl" %t45, { i64, [1 x i64] } %t43)
  store %"compiler/lower:pl" %t47, ptr %l24
  br label %bb9
bb9:
  %t48 = load %"compiler/lower:pl", ptr %l24
  store %"compiler/lower:pl" %t48, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/lower:pl", ptr %rv
  ret %"compiler/lower:pl" %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2edispatch(ptr %v0, ptr %a0, { i64, [4 x i64] } %a1, i32 %a2, %"compiler/source:Span" %a3, i1 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [4 x i64] }
  %l2 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca %"compiler/lower:tryCtx"
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca ptr
  %l16 = alloca { i64, [4 x i64] }
  %l17 = alloca i1
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca %"compiler/typed:Item"
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca { i64, [4 x i64] }
  %l32 = alloca i32
  %l33 = alloca i32
  %l34 = alloca i32
  %l40 = alloca { i64, ptr }
  %l43 = alloca i64
  %l51 = alloca %"compiler/lower:tryCtx"
  %l57 = alloca i64
  %l60 = alloca i64
  %l80 = alloca { i64, ptr }
  %l94 = alloca { i64, ptr }
  %l103 = alloca i64
  %l106 = alloca i64
  %l126 = alloca i1
  %l127 = alloca ptr
  %l129 = alloca { i64, ptr }
  %l132 = alloca i32
  %l135 = alloca i32
  %l136 = alloca i1
  %l155 = alloca { i64, [4 x i64] }
  %l168 = alloca { i64, [4 x i64] }
  %l185 = alloca { i64, [4 x i64] }
  %l188 = alloca { i64, [4 x i64] }
  %l199 = alloca { i64, [4 x i64] }
  %l204 = alloca i1
  %l213 = alloca i32
  %l216 = alloca i32
  %l251 = alloca i32
  %l259 = alloca i64
  %l268 = alloca { i64, ptr }
  %l271 = alloca i1
  %l274 = alloca i64
  %l281 = alloca ptr
  %l282 = alloca %"compiler/source:Span"
  %l290 = alloca { i64, [4 x i64] }
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %t99 = alloca { i64, [4 x i64] }, align 8
  %t223 = alloca { i64, [4 x i64] }, align 8
  %t236 = alloca { i64, [4 x i64] }, align 8
  %t277 = alloca { i64, [4 x i64] }, align 8
  %t321 = alloca { i64, [4 x i64] }, align 8
  %t428 = alloca { i64, [7 x i64] }, align 8
  %t465 = alloca { i64, [21 x i64] }, align 8
  %t559 = alloca { i64, [4 x i64] }, align 8
  %t562 = alloca { i64, [7 x i64] }, align 8
  %t581 = alloca { i64, [15 x i64] }, align 8
  store ptr %a0, ptr %l0
  store { i64, [4 x i64] } %a1, ptr %l1
  store i32 %a2, ptr %l2
  store %"compiler/source:Span" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l5, !tbaa !29
  %t6 = load ptr, ptr %l5, !tbaa !29
  %t7 = load i32, ptr %l2, !tbaa !23
  %t10 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t6, i32 %t7)
  store { i64, ptr } %t10, ptr %l40
  br label %bb1
bb1:
  %t11 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t11, ptr %l6, !tbaa !27
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/lower:lowering", ptr %t12, i32 0, i32 13
  %t16 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3atryCtx_3e_2eLen_3ccompiler_2flower_3atryCtx_3e(ptr %v0, ptr %t14)
  store i64 %t16, ptr %l43
  br label %bb2
bb2:
  %t17 = load i64, ptr %l43, !tbaa !24
  %t18 = sub i64 %t17, 1
  store i64 %t18, ptr %l7, !tbaa !24
  br label %bb3
bb3:
  store %olang.scope zeroinitializer, ptr %s2
  %t20 = load i64, ptr %l7, !tbaa !24
  %t22 = icmp sge i64 %t20, 0
  %t24 = xor i1 %t22, true
  br i1 %t24, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s2)
  br label %bb94
bb5:
  br label %bb6
bb6:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/lower:lowering", ptr %t26, i32 0, i32 13
  %t29 = load i64, ptr %l7, !tbaa !24
  %t32 = call %"compiler/lower:tryCtx" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3atryCtx_3e_2eAt_3ccompiler_2flower_3atryCtx_3e(ptr %v0, ptr %v0, ptr %t28, i64 %t29)
  store %"compiler/lower:tryCtx" %t32, ptr %l51
  br label %bb7
bb7:
  %t33 = load %"compiler/lower:tryCtx", ptr %l51
  store %"compiler/lower:tryCtx" %t33, ptr %l8
  store i64 0, ptr %l9, !tbaa !24
  %t34 = getelementptr %"compiler/lower:tryCtx", ptr %l8, i32 0, i32 1
  %t35 = load { i64, ptr }, ptr %t34, !tbaa !27
  %t37 = extractvalue { i64, ptr } %t35, 0
  store i64 %t37, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t39 = load i64, ptr %l10, !tbaa !24
  %t40 = load i64, ptr %l9, !tbaa !24
  %t43 = icmp sgt i64 %t39, %t40
  br i1 %t43, label %bb8, label %bb9
bb8:
  %t45 = load i64, ptr %l11, !tbaa !24
  %t47 = icmp sgt i64 %t45, 0
  br i1 %t47, label %bb10, label %bb11
bb9:
  store i64 0, ptr %l57, !tbaa !24
  br label %bb13
bb10:
  %t49 = load i64, ptr %l10, !tbaa !24
  %t50 = load i64, ptr %l9, !tbaa !24
  %t53 = sub i64 %t49, %t50
  %t54 = load i64, ptr %l11, !tbaa !24
  %t57 = add i64 %t53, %t54
  %t59 = sub i64 %t57, 1
  %t60 = load i64, ptr %l11, !tbaa !24
  %t63 = sdiv i64 %t59, %t60
  store i64 %t63, ptr %l60, !tbaa !24
  br label %bb12
bb11:
  store i64 0, ptr %l60, !tbaa !24
  br label %bb12
bb12:
  %t65 = load i64, ptr %l60, !tbaa !24
  store i64 %t65, ptr %l57, !tbaa !24
  br label %bb13
bb13:
  %t66 = load i64, ptr %l57, !tbaa !24
  store i64 %t66, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb14
bb14:
  store %olang.scope zeroinitializer, ptr %s4
  %t67 = load i64, ptr %l13, !tbaa !24
  %t68 = load i64, ptr %l12, !tbaa !24
  %t71 = icmp slt i64 %t67, %t68
  %t73 = xor i1 %t71, true
  br i1 %t73, label %bb15, label %bb16
bb15:
  call void @__olang_scope_close(ptr %s4)
  br label %bb81
bb16:
  br label %bb17
bb17:
  %t75 = load i64, ptr %l9, !tbaa !24
  %t76 = load i64, ptr %l13, !tbaa !24
  %t77 = load i64, ptr %l11, !tbaa !24
  %t80 = mul i64 %t76, %t77
  %t83 = add i64 %t75, %t80
  store i64 %t83, ptr %l14, !tbaa !24
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"compiler/lower:lowering", ptr %t85, i32 0, i32 7
  %t88 = load i1, ptr %t87, !tbaa !21
  br i1 %t88, label %bb18, label %bb19
bb18:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s2)
  br label %ret
bb19:
  br label %bb20
bb20:
  %t90 = getelementptr %"compiler/lower:tryCtx", ptr %l8, i32 0, i32 1
  %t91 = load { i64, ptr }, ptr %t90, !tbaa !27
  store { i64, ptr } %t91, ptr %l80, !tbaa !27
  %t92 = load i64, ptr %l14, !tbaa !24
  %t94 = getelementptr { i64, ptr }, ptr %l80, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !27
  %t96 = getelementptr ptr, ptr %t95, i64 %t92
  %t97 = load ptr, ptr %t96, !tbaa !39
  store ptr %t97, ptr %l15, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t99
  %t100 = getelementptr { i64, [4 x i64] }, ptr %t99, i32 0, i32 0
  store i64 0, ptr %t100
  %t101 = load { i64, [4 x i64] }, ptr %t99
  store { i64, [4 x i64] } %t101, ptr %l16
  %t103 = load ptr, ptr %l15, !tbaa !29
  %t105 = getelementptr %"compiler/typed:Clause", ptr %t103, i32 0, i32 2
  %t106 = load i1, ptr %t105, !tbaa !21
  store i1 %t106, ptr %l17, !tbaa !21
  %t108 = load ptr, ptr %l15, !tbaa !29
  %t110 = getelementptr %"compiler/typed:Clause", ptr %t108, i32 0, i32 1
  %t111 = load { i64, ptr }, ptr %t110, !tbaa !27
  store { i64, ptr } %t111, ptr %l18, !tbaa !27
  store i64 0, ptr %l19, !tbaa !24
  %t113 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t115 = extractvalue { i64, ptr } %t113, 0
  store i64 %t115, ptr %l20, !tbaa !24
  br label %bb21
bb21:
  store %olang.scope zeroinitializer, ptr %s7
  %t117 = load i64, ptr %l19, !tbaa !24
  %t118 = load i64, ptr %l20, !tbaa !24
  %t121 = icmp slt i64 %t117, %t118
  %t123 = xor i1 %t121, true
  br i1 %t123, label %bb22, label %bb23
bb22:
  call void @__olang_scope_close(ptr %s7)
  br label %bb63
bb23:
  br label %bb24
bb24:
  %t125 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t125, ptr %l94, !tbaa !27
  %t126 = load i64, ptr %l19, !tbaa !24
  %t128 = getelementptr { i64, ptr }, ptr %l94, i32 0, i32 1
  %t129 = load ptr, ptr %t128, !tbaa !27
  %t130 = getelementptr %"compiler/typed:Item", ptr %t129, i64 %t126
  %t131 = load %"compiler/typed:Item", ptr %t130
  store %"compiler/typed:Item" %t131, ptr %l21
  %t133 = load i1, ptr %l17, !tbaa !21
  br i1 %t133, label %bb25, label %bb26
bb25:
  call void @__olang_scope_close(ptr %s7)
  br label %bb63
bb26:
  br label %bb27
bb27:
  store i64 -1, ptr %l22, !tbaa !24
  store i64 0, ptr %l23, !tbaa !24
  %t135 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t137 = extractvalue { i64, ptr } %t135, 0
  store i64 %t137, ptr %l24, !tbaa !24
  store i64 1, ptr %l25, !tbaa !24
  %t139 = load i64, ptr %l24, !tbaa !24
  %t140 = load i64, ptr %l23, !tbaa !24
  %t143 = icmp sgt i64 %t139, %t140
  br i1 %t143, label %bb28, label %bb29
bb28:
  %t145 = load i64, ptr %l25, !tbaa !24
  %t147 = icmp sgt i64 %t145, 0
  br i1 %t147, label %bb30, label %bb31
bb29:
  store i64 0, ptr %l103, !tbaa !24
  br label %bb33
bb30:
  %t149 = load i64, ptr %l24, !tbaa !24
  %t150 = load i64, ptr %l23, !tbaa !24
  %t153 = sub i64 %t149, %t150
  %t154 = load i64, ptr %l25, !tbaa !24
  %t157 = add i64 %t153, %t154
  %t159 = sub i64 %t157, 1
  %t160 = load i64, ptr %l25, !tbaa !24
  %t163 = sdiv i64 %t159, %t160
  store i64 %t163, ptr %l106, !tbaa !24
  br label %bb32
bb31:
  store i64 0, ptr %l106, !tbaa !24
  br label %bb32
bb32:
  %t165 = load i64, ptr %l106, !tbaa !24
  store i64 %t165, ptr %l103, !tbaa !24
  br label %bb33
bb33:
  %t166 = load i64, ptr %l103, !tbaa !24
  store i64 %t166, ptr %l26, !tbaa !24
  store i64 0, ptr %l27, !tbaa !24
  br label %bb34
bb34:
  store %olang.scope zeroinitializer, ptr %s10
  %t167 = load i64, ptr %l27, !tbaa !24
  %t168 = load i64, ptr %l26, !tbaa !24
  %t171 = icmp slt i64 %t167, %t168
  %t173 = xor i1 %t171, true
  br i1 %t173, label %bb35, label %bb36
bb35:
  call void @__olang_scope_close(ptr %s10)
  br label %bb48
bb36:
  br label %bb37
bb37:
  %t175 = load i64, ptr %l23, !tbaa !24
  %t176 = load i64, ptr %l27, !tbaa !24
  %t177 = load i64, ptr %l25, !tbaa !24
  %t180 = mul i64 %t176, %t177
  %t183 = add i64 %t175, %t180
  store i64 %t183, ptr %l28, !tbaa !24
  %t185 = load i64, ptr %l22, !tbaa !24
  %t187 = icmp slt i64 %t185, 0
  br i1 %t187, label %bb38, label %bb39
bb38:
  %t189 = load ptr, ptr %l5, !tbaa !29
  store ptr %t189, ptr %l127, !tbaa !29
  %t190 = load ptr, ptr %l5, !tbaa !29
  %t191 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t191, ptr %l129, !tbaa !27
  %t192 = load i64, ptr %l28, !tbaa !24
  %t194 = getelementptr { i64, ptr }, ptr %l129, i32 0, i32 1
  %t195 = load ptr, ptr %t194, !tbaa !27
  %t196 = getelementptr i32, ptr %t195, i64 %t192
  %t197 = load i32, ptr %t196, !tbaa !33
  %t200 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t190, i32 %t197)
  store i32 %t200, ptr %l132
  br label %bb40
bb39:
  store i1 false, ptr %l126, !tbaa !21
  br label %bb43
bb40:
  %t201 = load ptr, ptr %l5, !tbaa !29
  %t202 = getelementptr %"compiler/typed:Item", ptr %l21, i32 0, i32 0
  %t203 = load i32, ptr %t202, !tbaa !23
  %t206 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t201, i32 %t203)
  store i32 %t206, ptr %l135
  br label %bb41
bb41:
  %t207 = load ptr, ptr %l127, !tbaa !29
  %t208 = load i32, ptr %l132, !tbaa !23
  %t209 = load i32, ptr %l135, !tbaa !23
  %t210 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t207, i32 %t208, i32 %t209)
  store i1 %t210, ptr %l136
  br label %bb42
bb42:
  %t211 = load i1, ptr %l136, !tbaa !21
  store i1 %t211, ptr %l126, !tbaa !21
  br label %bb43
bb43:
  %t212 = load i1, ptr %l126, !tbaa !21
  br i1 %t212, label %bb44, label %bb45
bb44:
  %t213 = load i64, ptr %l28, !tbaa !24
  store i64 %t213, ptr %l22, !tbaa !24
  br label %bb46
bb45:
  br label %bb46
bb46:
  call void @__olang_scope_close(ptr %s10)
  br label %bb47
bb47:
  %t215 = load i64, ptr %l27, !tbaa !24
  %t217 = add i64 %t215, 1
  store i64 %t217, ptr %l27, !tbaa !24
  br label %bb34
bb48:
  %t219 = load i64, ptr %l22, !tbaa !24
  %t221 = icmp slt i64 %t219, 0
  br i1 %t221, label %bb49, label %bb50
bb49:
  call void @__olang_scope_close(ptr %s7)
  br label %bb62
bb50:
  br label %bb51
bb51:
  store { i64, [4 x i64] } zeroinitializer, ptr %t223
  %t224 = getelementptr { i64, [4 x i64] }, ptr %t223, i32 0, i32 0
  store i64 0, ptr %t224
  %t225 = load { i64, [4 x i64] }, ptr %t223
  store { i64, [4 x i64] } %t225, ptr %l29
  %t227 = getelementptr %"compiler/typed:Item", ptr %l21, i32 0, i32 1
  %t228 = load i64, ptr %t227, !tbaa !24
  %t230 = icmp slt i64 %t228, 0
  br i1 %t230, label %bb52, label %bb53
bb52:
  store %olang.scope zeroinitializer, ptr %s14
  %t232 = load ptr, ptr %l0, !tbaa !29
  %t233 = load i32, ptr @G_2ecompiler_2fmir_2eI32T, !tbaa !23
  %t234 = load { i64, [4 x i64] }, ptr %l1
  %t235 = load i32, ptr @G_2ecompiler_2fmir_2eI32T, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t236
  %t237 = getelementptr { i64, [4 x i64] }, ptr %t236, i32 0, i32 0
  store i64 2, ptr %t237
  %t239 = insertvalue { i32, i64 } undef, i32 %t235, 0
  %t240 = insertvalue { i32, i64 } %t239, i64 16, 1
  %t241 = getelementptr { i64, [4 x i64] }, ptr %t236, i32 0, i32 1
  store { i32, i64 } %t240, ptr %t241
  %t242 = load { i64, [4 x i64] }, ptr %t236
  %t244 = insertvalue [2 x { i64, [4 x i64] }] undef, { i64, [4 x i64] } %t234, 0
  %t246 = insertvalue [2 x { i64, [4 x i64] }] %t244, { i64, [4 x i64] } %t242, 1
  %t248 = load ptr, ptr @__olang_prog_scope
  %t249 = call ptr @__olang_scope_alloc(ptr %t248, i64 80)
  store [2 x { i64, [4 x i64] }] %t246, ptr %t249
  %t250 = insertvalue { i64, ptr } undef, i64 2, 0
  %t251 = insertvalue { i64, ptr } %t250, ptr %t249, 1
  %t253 = extractvalue { i64, ptr } %t251, 0
  %t254 = extractvalue { i64, ptr } %t251, 1
  %t255 = mul i64 %t253, 40
  %t256 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t255)
  call void @llvm.memcpy.p0.p0.i64(ptr %t256, ptr %t254, i64 %t255, i1 false)
  %t257 = insertvalue { i64, ptr } undef, i64 %t253, 0
  %t258 = insertvalue { i64, ptr } %t257, ptr %t256, 1
  %t259 = load %"compiler/source:Span", ptr %l3
  %t265 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s14, ptr %t232, i32 9, i32 %t233, { i64, ptr } %t258, %"compiler/source:Span" %t259)
  store { i64, [4 x i64] } %t265, ptr %l155
  br label %bb54
bb53:
  store %olang.scope zeroinitializer, ptr %s15
  %t266 = load i32, ptr @G_2ecompiler_2fmir_2eI32T, !tbaa !23
  %t267 = load i64, ptr %l22, !tbaa !24
  %t269 = add i64 %t267, 1
  %t271 = shl i64 %t269, 16
  %t272 = getelementptr %"compiler/typed:Item", ptr %l21, i32 0, i32 1
  %t273 = load i64, ptr %t272, !tbaa !24
  %t276 = or i64 %t271, %t273
  store { i64, [4 x i64] } zeroinitializer, ptr %t277
  %t278 = getelementptr { i64, [4 x i64] }, ptr %t277, i32 0, i32 0
  store i64 2, ptr %t278
  %t280 = insertvalue { i32, i64 } undef, i32 %t266, 0
  %t282 = insertvalue { i32, i64 } %t280, i64 %t276, 1
  %t283 = getelementptr { i64, [4 x i64] }, ptr %t277, i32 0, i32 1
  store { i32, i64 } %t282, ptr %t283
  %t284 = load { i64, [4 x i64] }, ptr %t277
  %t286 = load ptr, ptr %l0, !tbaa !29
  %t287 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t288 = load { i64, [4 x i64] }, ptr %l1
  %t291 = insertvalue [2 x { i64, [4 x i64] }] undef, { i64, [4 x i64] } %t288, 0
  %t293 = insertvalue [2 x { i64, [4 x i64] }] %t291, { i64, [4 x i64] } %t284, 1
  %t295 = load ptr, ptr @__olang_prog_scope
  %t296 = call ptr @__olang_scope_alloc(ptr %t295, i64 80)
  store [2 x { i64, [4 x i64] }] %t293, ptr %t296
  %t297 = insertvalue { i64, ptr } undef, i64 2, 0
  %t298 = insertvalue { i64, ptr } %t297, ptr %t296, 1
  %t300 = extractvalue { i64, ptr } %t298, 0
  %t301 = extractvalue { i64, ptr } %t298, 1
  %t302 = mul i64 %t300, 40
  %t303 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t302)
  call void @llvm.memcpy.p0.p0.i64(ptr %t303, ptr %t301, i64 %t302, i1 false)
  %t304 = insertvalue { i64, ptr } undef, i64 %t300, 0
  %t305 = insertvalue { i64, ptr } %t304, ptr %t303, 1
  %t306 = load %"compiler/source:Span", ptr %l3
  %t312 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s15, ptr %t286, i32 13, i32 %t287, { i64, ptr } %t305, %"compiler/source:Span" %t306)
  store { i64, [4 x i64] } %t312, ptr %l185
  br label %bb56
bb54:
  %t313 = load { i64, [4 x i64] }, ptr %l155
  %t314 = load ptr, ptr %l0, !tbaa !29
  %t315 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t317 = load i32, ptr @G_2ecompiler_2fmir_2eI32T, !tbaa !23
  %t318 = load i64, ptr %l22, !tbaa !24
  %t320 = add i64 %t318, 1
  store { i64, [4 x i64] } zeroinitializer, ptr %t321
  %t322 = getelementptr { i64, [4 x i64] }, ptr %t321, i32 0, i32 0
  store i64 2, ptr %t322
  %t324 = insertvalue { i32, i64 } undef, i32 %t317, 0
  %t326 = insertvalue { i32, i64 } %t324, i64 %t320, 1
  %t327 = getelementptr { i64, [4 x i64] }, ptr %t321, i32 0, i32 1
  store { i32, i64 } %t326, ptr %t327
  %t328 = load { i64, [4 x i64] }, ptr %t321
  %t330 = insertvalue [2 x { i64, [4 x i64] }] undef, { i64, [4 x i64] } %t313, 0
  %t332 = insertvalue [2 x { i64, [4 x i64] }] %t330, { i64, [4 x i64] } %t328, 1
  %t334 = load ptr, ptr @__olang_prog_scope
  %t335 = call ptr @__olang_scope_alloc(ptr %t334, i64 80)
  store [2 x { i64, [4 x i64] }] %t332, ptr %t335
  %t336 = insertvalue { i64, ptr } undef, i64 2, 0
  %t337 = insertvalue { i64, ptr } %t336, ptr %t335, 1
  %t339 = extractvalue { i64, ptr } %t337, 0
  %t340 = extractvalue { i64, ptr } %t337, 1
  %t341 = mul i64 %t339, 40
  %t342 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t341)
  call void @llvm.memcpy.p0.p0.i64(ptr %t342, ptr %t340, i64 %t341, i1 false)
  %t343 = insertvalue { i64, ptr } undef, i64 %t339, 0
  %t344 = insertvalue { i64, ptr } %t343, ptr %t342, 1
  %t345 = load %"compiler/source:Span", ptr %l3
  %t351 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s14, ptr %t314, i32 13, i32 %t315, { i64, ptr } %t344, %"compiler/source:Span" %t345)
  store { i64, [4 x i64] } %t351, ptr %l168
  br label %bb55
bb55:
  %t352 = load { i64, [4 x i64] }, ptr %l168
  store { i64, [4 x i64] } %t352, ptr %l29
  call void @__olang_scope_close(ptr %s14)
  br label %bb57
bb56:
  %t353 = load { i64, [4 x i64] }, ptr %l185
  store { i64, [4 x i64] } %t353, ptr %l29
  call void @__olang_scope_close(ptr %s15)
  br label %bb57
bb57:
  %t354 = load { i64, [4 x i64] }, ptr %l16
  %t356 = extractvalue { i64, [4 x i64] } %t354, 0
  %t357 = icmp eq i64 %t356, 0
  br i1 %t357, label %bb58, label %bb59
bb58:
  %t359 = load { i64, [4 x i64] }, ptr %l29
  store { i64, [4 x i64] } %t359, ptr %l188
  br label %bb61
bb59:
  %t361 = load ptr, ptr %l0, !tbaa !29
  %t362 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t363 = load { i64, [4 x i64] }, ptr %l16
  %t364 = load { i64, [4 x i64] }, ptr %l29
  %t366 = insertvalue [2 x { i64, [4 x i64] }] undef, { i64, [4 x i64] } %t363, 0
  %t368 = insertvalue [2 x { i64, [4 x i64] }] %t366, { i64, [4 x i64] } %t364, 1
  %t370 = load ptr, ptr @__olang_prog_scope
  %t371 = call ptr @__olang_scope_alloc(ptr %t370, i64 80)
  store [2 x { i64, [4 x i64] }] %t368, ptr %t371
  %t372 = insertvalue { i64, ptr } undef, i64 2, 0
  %t373 = insertvalue { i64, ptr } %t372, ptr %t371, 1
  %t375 = extractvalue { i64, ptr } %t373, 0
  %t376 = extractvalue { i64, ptr } %t373, 1
  %t377 = mul i64 %t375, 40
  %t378 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t377)
  call void @llvm.memcpy.p0.p0.i64(ptr %t378, ptr %t376, i64 %t377, i1 false)
  %t379 = insertvalue { i64, ptr } undef, i64 %t375, 0
  %t380 = insertvalue { i64, ptr } %t379, ptr %t378, 1
  %t381 = load %"compiler/source:Span", ptr %l3
  %t387 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s7, ptr %t361, i32 11, i32 %t362, { i64, ptr } %t380, %"compiler/source:Span" %t381)
  store { i64, [4 x i64] } %t387, ptr %l199
  br label %bb60
bb60:
  %t388 = load { i64, [4 x i64] }, ptr %l199
  store { i64, [4 x i64] } %t388, ptr %l188
  br label %bb61
bb61:
  %t389 = load { i64, [4 x i64] }, ptr %l188
  store { i64, [4 x i64] } %t389, ptr %l16
  call void @__olang_scope_close(ptr %s7)
  br label %bb62
bb62:
  %t390 = load i64, ptr %l19, !tbaa !24
  %t392 = add i64 %t390, 1
  store i64 %t392, ptr %l19, !tbaa !24
  br label %bb21
bb63:
  %t394 = load i1, ptr %l17, !tbaa !21
  %t396 = xor i1 %t394, true
  br i1 %t396, label %bb64, label %bb65
bb64:
  %t398 = load { i64, [4 x i64] }, ptr %l16
  %t400 = extractvalue { i64, [4 x i64] } %t398, 0
  %t401 = icmp eq i64 %t400, 0
  store i1 %t401, ptr %l204, !tbaa !21
  br label %bb66
bb65:
  store i1 false, ptr %l204, !tbaa !21
  br label %bb66
bb66:
  %t403 = load i1, ptr %l204, !tbaa !21
  br i1 %t403, label %bb67, label %bb68
bb67:
  call void @__olang_scope_close(ptr %s4)
  br label %bb80
bb68:
  br label %bb69
bb69:
  %t404 = load i1, ptr %l17, !tbaa !21
  br i1 %t404, label %bb70, label %bb71
bb70:
  %t406 = load ptr, ptr %l0, !tbaa !29
  %t407 = load %"compiler/lower:tryCtx", ptr %l8
  %t408 = load i64, ptr %l14, !tbaa !24
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2etoClause(ptr %v0, ptr %v0, ptr %t406, %"compiler/lower:tryCtx" %t407, i64 %t408)
  br label %bb72
bb71:
  br label %bb73
bb72:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s2)
  br label %ret
bb73:
  %t412 = load ptr, ptr %l0, !tbaa !29
  %t414 = getelementptr %"compiler/lower:lowering", ptr %t412, i32 0, i32 3
  %t416 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t414)
  store i32 %t416, ptr %l213
  br label %bb74
bb74:
  %t417 = load i32, ptr %l213, !tbaa !23
  store i32 %t417, ptr %l32, !tbaa !23
  %t418 = load ptr, ptr %l0, !tbaa !29
  %t420 = getelementptr %"compiler/lower:lowering", ptr %t418, i32 0, i32 3
  %t422 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t420)
  store i32 %t422, ptr %l216
  br label %bb75
bb75:
  %t423 = load i32, ptr %l216, !tbaa !23
  store i32 %t423, ptr %l33, !tbaa !23
  %t424 = load ptr, ptr %l0, !tbaa !29
  %t425 = load { i64, [4 x i64] }, ptr %l16
  %t426 = load i32, ptr %l32, !tbaa !23
  %t427 = load i32, ptr %l33, !tbaa !23
  store { i64, [7 x i64] } zeroinitializer, ptr %t428
  %t429 = getelementptr { i64, [7 x i64] }, ptr %t428, i32 0, i32 0
  store i64 2, ptr %t429
  %t431 = insertvalue { { i64, [4 x i64] }, i32, i32 } undef, { i64, [4 x i64] } %t425, 0
  %t433 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t431, i32 %t426, 1
  %t435 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t433, i32 %t427, 2
  %t436 = getelementptr { i64, [7 x i64] }, ptr %t428, i32 0, i32 1
  store { { i64, [4 x i64] }, i32, i32 } %t435, ptr %t436
  %t437 = load { i64, [7 x i64] }, ptr %t428
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t424, { i64, [7 x i64] } %t437)
  br label %bb76
bb76:
  %t440 = load ptr, ptr %l0, !tbaa !29
  %t441 = load i32, ptr %l32, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t440, i32 %t441)
  br label %bb77
bb77:
  %t444 = load ptr, ptr %l0, !tbaa !29
  %t445 = load %"compiler/lower:tryCtx", ptr %l8
  %t446 = load i64, ptr %l14, !tbaa !24
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2etoClause(ptr %v0, ptr %v0, ptr %t444, %"compiler/lower:tryCtx" %t445, i64 %t446)
  br label %bb78
bb78:
  %t450 = load ptr, ptr %l0, !tbaa !29
  %t451 = load i32, ptr %l33, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t450, i32 %t451)
  br label %bb79
bb79:
  call void @__olang_scope_close(ptr %s4)
  br label %bb80
bb80:
  %t454 = load i64, ptr %l13, !tbaa !24
  %t456 = add i64 %t454, 1
  store i64 %t456, ptr %l13, !tbaa !24
  br label %bb14
bb81:
  %t458 = getelementptr %"compiler/lower:tryCtx", ptr %l8, i32 0, i32 2
  %t459 = load i1, ptr %t458, !tbaa !21
  br i1 %t459, label %bb82, label %bb83
bb82:
  br i1 %a4, label %bb84, label %bb85
bb83:
  br label %bb89
bb84:
  store %olang.scope zeroinitializer, ptr %s21
  %t463 = load ptr, ptr %l0, !tbaa !29
  %t464 = load %"compiler/source:Span", ptr %l3
  store { i64, [21 x i64] } zeroinitializer, ptr %t465
  %t466 = getelementptr { i64, [21 x i64] }, ptr %t465, i32 0, i32 0
  store i64 12, ptr %t466
  %t468 = insertvalue { %"compiler/source:Span" } undef, %"compiler/source:Span" %t464, 0
  %t469 = getelementptr { i64, [21 x i64] }, ptr %t465, i32 0, i32 1
  store { %"compiler/source:Span" } %t468, ptr %t469
  %t470 = load { i64, [21 x i64] }, ptr %t465
  %t472 = call ptr @__olang_scope_alloc_a(ptr %s21, i64 176, i64 8)
  store { i64, [21 x i64] } %t470, ptr %t472
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s21, ptr %t463, ptr %t472)
  br label %bb86
bb85:
  br label %bb87
bb86:
  call void @__olang_scope_close(ptr %s21)
  br label %bb87
bb87:
  %t475 = load ptr, ptr %l0, !tbaa !29
  %t476 = load { i64, [4 x i64] }, ptr %l1
  %t477 = load i32, ptr %l2, !tbaa !23
  %t478 = load %"compiler/source:Span", ptr %l3
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2ebang(ptr %v0, ptr %t475, { i64, [4 x i64] } %t476, i32 %t477, %"compiler/source:Span" %t478, i32 10)
  br label %bb88
bb88:
  call void @__olang_scope_close(ptr %s2)
  br label %ret
bb89:
  %t484 = getelementptr %"compiler/lower:tryCtx", ptr %l8, i32 0, i32 3
  %t485 = load i1, ptr %t484, !tbaa !21
  %t487 = xor i1 %t485, true
  br i1 %t487, label %bb90, label %bb91
bb90:
  call void @__olang_scope_close(ptr %s2)
  br label %bb94
bb91:
  br label %bb92
bb92:
  call void @__olang_scope_close(ptr %s2)
  br label %bb93
bb93:
  %t489 = load i64, ptr %l7, !tbaa !24
  %t491 = sub i64 %t489, 1
  store i64 %t491, ptr %l7, !tbaa !24
  br label %bb3
bb94:
  %t493 = load ptr, ptr %l0, !tbaa !29
  %t495 = getelementptr %"compiler/lower:lowering", ptr %t493, i32 0, i32 2
  %t496 = load ptr, ptr %t495, !tbaa !29
  %t497 = load ptr, ptr %l0, !tbaa !29
  %t499 = getelementptr %"compiler/lower:lowering", ptr %t497, i32 0, i32 1
  %t500 = load ptr, ptr %t499, !tbaa !29
  %t502 = getelementptr %"compiler/typed:Body", ptr %t500, i32 0, i32 2
  %t503 = load i32, ptr %t502, !tbaa !23
  %t506 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t496, i32 %t503)
  store i32 %t506, ptr %l251
  br label %bb95
bb95:
  %t507 = load i32, ptr %l251, !tbaa !23
  store i32 %t507, ptr %l34, !tbaa !23
  %t508 = load ptr, ptr %l0, !tbaa !29
  %t510 = getelementptr %"compiler/lower:lowering", ptr %t508, i32 0, i32 1
  %t511 = load ptr, ptr %t510, !tbaa !29
  %t513 = getelementptr %"compiler/typed:Body", ptr %t511, i32 0, i32 1
  %t514 = load { i64, [2 x i64] }, ptr %t513
  %t518 = extractvalue { i64, [2 x i64] } %t514, 0
  %t519 = icmp eq i64 %t518, 5
  br i1 %t519, label %bb96, label %bb97
bb96:
  br label %bb98
bb97:
  br label %bb104
bb98:
  %t521 = load ptr, ptr %l0, !tbaa !29
  %t523 = getelementptr %"compiler/lower:lowering", ptr %t521, i32 0, i32 13
  %t525 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3atryCtx_3e_2eLen_3ccompiler_2flower_3atryCtx_3e(ptr %v0, ptr %t523)
  store i64 %t525, ptr %l259
  br label %bb99
bb99:
  %t526 = load i64, ptr %l259, !tbaa !24
  %t527 = icmp sgt i64 %t526, 0
  br i1 %t527, label %bb100, label %bb101
bb100:
  %t529 = load ptr, ptr %l0, !tbaa !29
  %t530 = load { i64, [4 x i64] }, ptr %l1
  %t531 = load i32, ptr %l2, !tbaa !23
  %t532 = load %"compiler/source:Span", ptr %l3
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2ebang(ptr %v0, ptr %t529, { i64, [4 x i64] } %t530, i32 %t531, %"compiler/source:Span" %t532, i32 11)
  br label %bb102
bb101:
  br label %bb103
bb102:
  br label %ret
bb103:
  br label %bb109
bb104:
  br i1 true, label %bb105, label %bb106
bb105:
  br label %bb107
bb106:
  br label %bb108
bb107:
  br label %bb109
bb108:
  call void @__olang_check_failed(ptr @olang_loc_c6e2ba3cedb073a3_23085f6ef83cda97)
  unreachable
bb109:
  %t538 = load ptr, ptr %l5, !tbaa !29
  %t539 = load i32, ptr %l34, !tbaa !23
  %t542 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t538, i32 %t539)
  store { i64, ptr } %t542, ptr %l268
  br label %bb110
bb110:
  %t543 = load { i64, ptr }, ptr %l268, !tbaa !27
  %t544 = extractvalue { i64, ptr } %t543, 0
  %t546 = icmp eq i64 %t544, 0
  br i1 %t546, label %bb111, label %bb112
bb111:
  store i1 true, ptr %l271, !tbaa !21
  br label %bb114
bb112:
  %t548 = load ptr, ptr %l0, !tbaa !29
  %t550 = getelementptr %"compiler/lower:lowering", ptr %t548, i32 0, i32 13
  %t552 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3atryCtx_3e_2eLen_3ccompiler_2flower_3atryCtx_3e(ptr %v0, ptr %t550)
  store i64 %t552, ptr %l274
  br label %bb113
bb113:
  %t553 = load i64, ptr %l274, !tbaa !24
  %t554 = icmp eq i64 %t553, 0
  store i1 %t554, ptr %l271, !tbaa !21
  br label %bb114
bb114:
  %t556 = load i1, ptr %l271, !tbaa !21
  br i1 %t556, label %bb115, label %bb116
bb115:
  %t557 = load ptr, ptr %l0, !tbaa !29
  %t558 = load %"compiler/source:Span", ptr %l3
  store { i64, [4 x i64] } zeroinitializer, ptr %t559
  %t560 = getelementptr { i64, [4 x i64] }, ptr %t559, i32 0, i32 0
  store i64 0, ptr %t560
  %t561 = load { i64, [4 x i64] }, ptr %t559
  store { i64, [7 x i64] } zeroinitializer, ptr %t562
  %t563 = getelementptr { i64, [7 x i64] }, ptr %t562, i32 0, i32 0
  store i64 8, ptr %t563
  %t565 = insertvalue { %"compiler/source:Span", i32, { i64, [4 x i64] } } undef, %"compiler/source:Span" %t558, 0
  %t567 = insertvalue { %"compiler/source:Span", i32, { i64, [4 x i64] } } %t565, i32 3, 1
  %t569 = insertvalue { %"compiler/source:Span", i32, { i64, [4 x i64] } } %t567, { i64, [4 x i64] } %t561, 2
  %t570 = getelementptr { i64, [7 x i64] }, ptr %t562, i32 0, i32 1
  store { %"compiler/source:Span", i32, { i64, [4 x i64] } } %t569, ptr %t570
  %t571 = load { i64, [7 x i64] }, ptr %t562
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t557, { i64, [7 x i64] } %t571)
  br label %bb117
bb116:
  br label %bb118
bb117:
  br label %ret
bb118:
  %t574 = load ptr, ptr %l0, !tbaa !29
  store ptr %t574, ptr %l281, !tbaa !29
  %t575 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t575, ptr %l282
  %t576 = load ptr, ptr %l0, !tbaa !29
  %t577 = load i32, ptr @G_2ecompiler_2fmir_2eI32T, !tbaa !23
  %t578 = load { i64, [4 x i64] }, ptr %l1
  %t579 = load i32, ptr %l2, !tbaa !23
  %t580 = load i32, ptr %l34, !tbaa !23
  store { i64, [15 x i64] } zeroinitializer, ptr %t581
  %t582 = getelementptr { i64, [15 x i64] }, ptr %t581, i32 0, i32 0
  store i64 11, ptr %t582
  %t584 = insertvalue { { i64, [4 x i64] }, i32, i32 } undef, { i64, [4 x i64] } %t578, 0
  %t586 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t584, i32 %t579, 1
  %t588 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t586, i32 %t580, 2
  %t589 = getelementptr { i64, [15 x i64] }, ptr %t581, i32 0, i32 1
  store { { i64, [4 x i64] }, i32, i32 } %t588, ptr %t589
  %t590 = load { i64, [15 x i64] }, ptr %t581
  %t591 = load %"compiler/source:Span", ptr %l3
  %t596 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %t576, i32 %t577, { i64, [15 x i64] } %t590, %"compiler/source:Span" %t591)
  store { i64, [4 x i64] } %t596, ptr %l290
  br label %bb119
bb119:
  %t597 = load ptr, ptr %l281, !tbaa !29
  %t598 = load %"compiler/source:Span", ptr %l282
  %t599 = load { i64, [4 x i64] }, ptr %l290
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eraise(ptr %v0, ptr %t597, %"compiler/source:Span" %t598, { i64, [4 x i64] } %t599)
  br label %bb120
bb120:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2eepilogue(ptr %v0, ptr %a0, { i64, [4 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %t12 = alloca { i64, [7 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eleave(ptr %v0, ptr %t1, i64 0)
  br label %bb1
bb1:
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t6 = getelementptr %"compiler/lower:lowering", ptr %t4, i32 0, i32 1
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/typed:Body", ptr %t7, i32 0, i32 4
  %t10 = load %"compiler/source:Span", ptr %t9
  store { i64, [7 x i64] } zeroinitializer, ptr %t12
  %t13 = getelementptr { i64, [7 x i64] }, ptr %t12, i32 0, i32 0
  store i64 5, ptr %t13
  %t15 = insertvalue { %"compiler/source:Span", { i64, [4 x i64] } } undef, %"compiler/source:Span" %t10, 0
  %t17 = insertvalue { %"compiler/source:Span", { i64, [4 x i64] } } %t15, { i64, [4 x i64] } %a1, 1
  %t18 = getelementptr { i64, [7 x i64] }, ptr %t12, i32 0, i32 1
  store { %"compiler/source:Span", { i64, [4 x i64] } } %t17, ptr %t18
  %t19 = load { i64, [7 x i64] }, ptr %t12
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t3, { i64, [7 x i64] } %t19)
  br label %bb2
bb2:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2eexitLevel(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca %"compiler/lower:level"
  %l3 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l4 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l17 = alloca i64
  %l18 = alloca ptr
  %l19 = alloca i64
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca i64
  %l24 = alloca %"compiler/source:Span"
  %l25 = alloca i32
  %l26 = alloca i32
  %l28 = alloca i32
  %l29 = alloca i32
  %l35 = alloca %"compiler/lower:level"
  %l36 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l39 = alloca i64
  %l44 = alloca ptr
  %l45 = alloca %"compiler/lower:level"
  %l48 = alloca %"compiler/lower:level"
  %l49 = alloca i32
  %l50 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l53 = alloca i64
  %l57 = alloca i64
  %l60 = alloca i64
  %l81 = alloca i32
  %l89 = alloca { i64, ptr }
  %l92 = alloca { i64, ptr }
  %l93 = alloca i32
  %l102 = alloca { i64, ptr }
  %l114 = alloca i64
  %l122 = alloca ptr
  %l125 = alloca ptr
  %l127 = alloca ptr
  %l130 = alloca i64
  %l131 = alloca ptr
  %l135 = alloca %"compiler/typed:BlockInfo"
  %l141 = alloca ptr
  %l143 = alloca ptr
  %l146 = alloca i64
  %l147 = alloca ptr
  %l151 = alloca { i64, ptr }
  %l154 = alloca { i64, ptr }
  %l155 = alloca i32
  %l164 = alloca { i64, ptr }
  %l177 = alloca i64
  %l181 = alloca ptr
  %l182 = alloca %"compiler/lower:level"
  %l184 = alloca %"compiler/lower:level"
  %l185 = alloca i32
  %l190 = alloca %"compiler/source:Span"
  %l196 = alloca %"compiler/typed:BlockInfo"
  %l207 = alloca %"compiler/mir:ScopeInfo"
  %l211 = alloca i32
  %l215 = alloca { i64, ptr }
  %l230 = alloca i32
  %l241 = alloca i32
  %l244 = alloca i32
  %l259 = alloca ptr
  %l260 = alloca i64
  %l261 = alloca i32
  %l263 = alloca %"compiler/mir:Place"
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s27 = alloca %olang.scope
  %t221 = alloca { i64, [21 x i64] }, align 8
  %t408 = alloca { i64, [7 x i64] }, align 8
  %t451 = alloca { i64, [7 x i64] }, align 8
  %t481 = alloca { i64, [7 x i64] }, align 8
  %t505 = alloca { i64, [21 x i64] }, align 8
  %t524 = alloca { i64, [4 x i64] }, align 8
  %t546 = alloca { i64, [21 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 7
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/lower:lowering", ptr %t6, i32 0, i32 9
  %t9 = load i64, ptr %l1, !tbaa !24
  %t12 = call %"compiler/lower:level" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3alevel_3e_2eAt_3ccompiler_2flower_3alevel_3e(ptr %v0, ptr %t8, i64 %t9)
  store %"compiler/lower:level" %t12, ptr %l35
  br label %bb4
bb4:
  %t13 = load %"compiler/lower:level", ptr %l35
  store %"compiler/lower:level" %t13, ptr %l2
  %t14 = load ptr, ptr @__olang_prog_scope
  %t15 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3alevel_3e(ptr %t14)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t15, ptr %l36
  br label %bb5
bb5:
  %t16 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l36
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t16, ptr %l3
  br label %bb6
bb6:
  store %olang.scope zeroinitializer, ptr %s2
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/lower:lowering", ptr %t17, i32 0, i32 9
  %t21 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3alevel_3e_2eLen_3ccompiler_2flower_3alevel_3e(ptr %v0, ptr %t19)
  store i64 %t21, ptr %l39
  br label %bb7
bb7:
  %t22 = load i64, ptr %l1, !tbaa !24
  %t24 = add i64 %t22, 1
  %t25 = load i64, ptr %l39, !tbaa !24
  %t27 = icmp sgt i64 %t25, %t24
  %t29 = xor i1 %t27, true
  br i1 %t29, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb17
bb9:
  br label %bb10
bb10:
  store ptr %l3, ptr %l44, !tbaa !29
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/lower:lowering", ptr %t31, i32 0, i32 9
  %t35 = call { i32, %"compiler/lower:level" } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3alevel_3e_2ePop_3ccompiler_2flower_3alevel_3e(ptr %v0, ptr %t33)
  %t36 = extractvalue { i32, %"compiler/lower:level" } %t35, 1
  %t37 = extractvalue { i32, %"compiler/lower:level" } %t35, 0
  store i32 %t37, ptr %l49
  %t38 = icmp ne i32 %t37, 0
  br i1 %t38, label %bb12, label %ok.39
ok.39:
  store %"compiler/lower:level" %t36, ptr %l48
  br label %bb11
bb11:
  %t40 = load %"compiler/lower:level", ptr %l48
  store %"compiler/lower:level" %t40, ptr %l45
  br label %bb14
bb12:
  br label %bb13
bb13:
  call void @__olang_check_failed(ptr @olang_loc_831aef8878f0c239_4d65f3dd2c1f4c9d)
  unreachable
bb14:
  %t41 = load ptr, ptr %l44, !tbaa !29
  %t42 = load %"compiler/lower:level", ptr %l45
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3alevel_3e_2ePush_3ccompiler_2flower_3alevel_3e(ptr %s0, ptr %t41, %"compiler/lower:level" %t42)
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s2)
  br label %bb16
bb16:
  br label %bb6
bb17:
  %t43 = load ptr, ptr @__olang_prog_scope
  %t44 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t43)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t44, ptr %l50
  br label %bb18
bb18:
  %t45 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l50
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t45, ptr %l4
  store i64 0, ptr %l5, !tbaa !24
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/lower:lowering", ptr %t46, i32 0, i32 10
  %t50 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aBlock_26_3e_2eLe_H8743fc75fe5cead0bda2da42e1adf3f3(ptr %v0, ptr %t48)
  store i64 %t50, ptr %l53
  br label %bb19
bb19:
  %t51 = load i64, ptr %l53, !tbaa !24
  store i64 %t51, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t52 = load i64, ptr %l6, !tbaa !24
  %t53 = load i64, ptr %l5, !tbaa !24
  %t56 = icmp sgt i64 %t52, %t53
  br i1 %t56, label %bb20, label %bb21
bb20:
  %t58 = load i64, ptr %l7, !tbaa !24
  %t60 = icmp sgt i64 %t58, 0
  br i1 %t60, label %bb22, label %bb23
bb21:
  store i64 0, ptr %l57, !tbaa !24
  br label %bb25
bb22:
  %t62 = load i64, ptr %l6, !tbaa !24
  %t63 = load i64, ptr %l5, !tbaa !24
  %t66 = sub i64 %t62, %t63
  %t67 = load i64, ptr %l7, !tbaa !24
  %t70 = add i64 %t66, %t67
  %t72 = sub i64 %t70, 1
  %t73 = load i64, ptr %l7, !tbaa !24
  %t76 = sdiv i64 %t72, %t73
  store i64 %t76, ptr %l60, !tbaa !24
  br label %bb24
bb23:
  store i64 0, ptr %l60, !tbaa !24
  br label %bb24
bb24:
  %t78 = load i64, ptr %l60, !tbaa !24
  store i64 %t78, ptr %l57, !tbaa !24
  br label %bb25
bb25:
  %t79 = load i64, ptr %l57, !tbaa !24
  store i64 %t79, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb26
bb26:
  store %olang.scope zeroinitializer, ptr %s5
  %t80 = load i64, ptr %l9, !tbaa !24
  %t81 = load i64, ptr %l8, !tbaa !24
  %t84 = icmp slt i64 %t80, %t81
  %t86 = xor i1 %t84, true
  br i1 %t86, label %bb27, label %bb28
bb27:
  call void @__olang_scope_close(ptr %s5)
  br label %bb36
bb28:
  br label %bb29
bb29:
  %t88 = load i64, ptr %l5, !tbaa !24
  %t89 = load i64, ptr %l9, !tbaa !24
  %t90 = load i64, ptr %l7, !tbaa !24
  %t93 = mul i64 %t89, %t90
  %t96 = add i64 %t88, %t93
  store i64 %t96, ptr %l10, !tbaa !24
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t100 = getelementptr %"compiler/lower:lowering", ptr %t98, i32 0, i32 11
  %t101 = load i64, ptr %l10, !tbaa !24
  %t104 = call i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeId_3e_2eAt_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t100, i64 %t101)
  store i32 %t104, ptr %l81
  br label %bb30
bb30:
  %t105 = getelementptr %"compiler/lower:level", ptr %l2, i32 0, i32 0
  %t106 = load i32, ptr %t105, !tbaa !23
  %t107 = load i32, ptr %l81, !tbaa !23
  %t109 = icmp eq i32 %t107, %t106
  br i1 %t109, label %bb31, label %bb32
bb31:
  %t111 = load i64, ptr %l10, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l4, i64 %t111)
  br label %bb33
bb32:
  br label %bb34
bb33:
  br label %bb34
bb34:
  call void @__olang_scope_close(ptr %s5)
  br label %bb35
bb35:
  %t114 = load i64, ptr %l9, !tbaa !24
  %t116 = add i64 %t114, 1
  store i64 %t116, ptr %l9, !tbaa !24
  br label %bb26
bb36:
  store ptr %l4, ptr %l11, !tbaa !29
  store i64 0, ptr %l12, !tbaa !24
  br label %bb37
bb37:
  store %olang.scope zeroinitializer, ptr %s9
  %t119 = load ptr, ptr %l11, !tbaa !29
  %t120 = load i64, ptr %l12, !tbaa !24
  %t123 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %s0, ptr %t119, i64 %t120)
  %t124 = extractvalue { i32, { i64, ptr } } %t123, 1
  %t125 = extractvalue { i32, { i64, ptr } } %t123, 0
  store i32 %t125, ptr %l93
  %t126 = icmp ne i32 %t125, 0
  br i1 %t126, label %bb39, label %ok.127
ok.127:
  store { i64, ptr } %t124, ptr %l92
  br label %bb38
bb38:
  %t128 = load { i64, ptr }, ptr %l92, !tbaa !27
  store { i64, ptr } %t128, ptr %l89, !tbaa !27
  br label %bb43
bb39:
  %t129 = load i32, ptr %l93, !tbaa !23
  %t130 = ashr i32 %t129, 16
  %t132 = icmp eq i32 %t130, 1
  br i1 %t132, label %bb40, label %bb41
bb40:
  br label %bb42
bb41:
  call void @__olang_check_failed(ptr @olang_loc_53acd22e8270d268_dadfa79394a107ec)
  unreachable
bb42:
  call void @__olang_scope_close(ptr %s9)
  br label %bb52
bb43:
  %t134 = load { i64, ptr }, ptr %l89, !tbaa !27
  store { i64, ptr } %t134, ptr %l13, !tbaa !27
  %t135 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t137 = extractvalue { i64, ptr } %t135, 0
  store i64 %t137, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb44
bb44:
  store %olang.scope zeroinitializer, ptr %s10
  %t139 = load i64, ptr %l15, !tbaa !24
  %t140 = load i64, ptr %l14, !tbaa !24
  %t143 = icmp slt i64 %t139, %t140
  %t145 = xor i1 %t143, true
  br i1 %t145, label %bb45, label %bb46
bb45:
  call void @__olang_scope_close(ptr %s10)
  br label %bb50
bb46:
  br label %bb47
bb47:
  %t147 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t147, ptr %l102, !tbaa !27
  %t148 = load i64, ptr %l15, !tbaa !24
  %t150 = getelementptr { i64, ptr }, ptr %l102, i32 0, i32 1
  %t151 = load ptr, ptr %t150, !tbaa !27
  %t152 = getelementptr i64, ptr %t151, i64 %t148
  %t153 = load i64, ptr %t152, !tbaa !34
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t157 = getelementptr %"compiler/lower:lowering", ptr %t155, i32 0, i32 11
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeId_3e_2eSetAt_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t157, i64 %t153, i32 -1)
  br label %bb48
bb48:
  call void @__olang_scope_close(ptr %s10)
  br label %bb49
bb49:
  %t161 = load i64, ptr %l15, !tbaa !24
  %t163 = add i64 %t161, 1
  store i64 %t163, ptr %l15, !tbaa !24
  br label %bb44
bb50:
  %t165 = load i64, ptr %l12, !tbaa !24
  %t166 = load i64, ptr %l14, !tbaa !24
  %t169 = add i64 %t165, %t166
  store i64 %t169, ptr %l12, !tbaa !24
  call void @__olang_scope_close(ptr %s9)
  br label %bb51
bb51:
  br label %bb37
bb52:
  %t172 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l4)
  store i64 %t172, ptr %l114
  br label %bb53
bb53:
  %t173 = load i64, ptr %l114, !tbaa !24
  %t174 = sub i64 %t173, 1
  store i64 %t174, ptr %l17, !tbaa !24
  br label %bb54
bb54:
  store %olang.scope zeroinitializer, ptr %s13
  %t176 = load i64, ptr %l17, !tbaa !24
  %t178 = icmp sge i64 %t176, 0
  %t180 = xor i1 %t178, true
  br i1 %t180, label %bb55, label %bb56
bb55:
  call void @__olang_scope_close(ptr %s13)
  br label %bb69
bb56:
  br label %bb57
bb57:
  %t182 = load ptr, ptr %l0, !tbaa !29
  %t184 = getelementptr %"compiler/lower:lowering", ptr %t182, i32 0, i32 0
  %t185 = load ptr, ptr %t184, !tbaa !29
  %t187 = getelementptr %"compiler/lower:Lowerer", ptr %t185, i32 0, i32 5
  %t188 = load i1, ptr %t187, !tbaa !21
  br i1 %t188, label %bb58, label %bb59
bb58:
  store %olang.scope zeroinitializer, ptr %s14
  %t190 = load ptr, ptr %l0, !tbaa !29
  store ptr %t190, ptr %l122, !tbaa !29
  %t191 = load ptr, ptr %l0, !tbaa !29
  %t193 = getelementptr %"compiler/lower:lowering", ptr %t191, i32 0, i32 1
  %t194 = load ptr, ptr %t193, !tbaa !29
  %t196 = getelementptr %"compiler/typed:Body", ptr %t194, i32 0, i32 8
  store ptr %t196, ptr %l125, !tbaa !29
  %t197 = load ptr, ptr %l0, !tbaa !29
  %t199 = getelementptr %"compiler/lower:lowering", ptr %t197, i32 0, i32 10
  store ptr %t199, ptr %l127, !tbaa !29
  %t200 = load i64, ptr %l17, !tbaa !24
  %t203 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l4, i64 %t200)
  store i64 %t203, ptr %l130
  br label %bb60
bb59:
  br label %bb64
bb60:
  %t204 = load ptr, ptr %l127, !tbaa !29
  %t205 = load i64, ptr %l130, !tbaa !24
  %t206 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aBlock_26_3e_2eAt_Hef81d01aee8891fe569e7a3039d88992(ptr %v0, ptr %s14, ptr %t204, i64 %t205)
  store ptr %t206, ptr %l131
  br label %bb61
bb61:
  %t207 = load ptr, ptr %l131, !tbaa !29
  %t209 = getelementptr %"compiler/typed:Block", ptr %t207, i32 0, i32 0
  %t210 = load i32, ptr %t209, !tbaa !23
  %t212 = sext i32 %t210 to i64
  %t213 = load ptr, ptr %l125, !tbaa !29
  %t215 = call %"compiler/typed:BlockInfo" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aBlockInfo_3e_2eA_Hdb91c1ab6f912bb6141763aa02d0b766(ptr %v0, ptr %t213, i64 %t212)
  store %"compiler/typed:BlockInfo" %t215, ptr %l135
  br label %bb62
bb62:
  %t216 = getelementptr %"compiler/typed:BlockInfo", ptr %l135, i32 0, i32 2
  %t217 = load %"compiler/source:Span", ptr %t216
  %t218 = getelementptr %"compiler/lower:level", ptr %l2, i32 0, i32 0
  %t219 = load i32, ptr %t218, !tbaa !23
  %t220 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  store { i64, [21 x i64] } zeroinitializer, ptr %t221
  %t222 = getelementptr { i64, [21 x i64] }, ptr %t221, i32 0, i32 0
  store i64 13, ptr %t222
  %t224 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %t217, 0
  %t226 = insertvalue { %"compiler/source:Span", i32, i32 } %t224, i32 %t219, 1
  %t228 = insertvalue { %"compiler/source:Span", i32, i32 } %t226, i32 %t220, 2
  %t229 = getelementptr { i64, [21 x i64] }, ptr %t221, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t228, ptr %t229
  %t230 = load { i64, [21 x i64] }, ptr %t221
  %t232 = call ptr @__olang_scope_alloc_a(ptr %s14, i64 176, i64 8)
  store { i64, [21 x i64] } %t230, ptr %t232
  %t233 = load ptr, ptr %l122, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s14, ptr %t233, ptr %t232)
  br label %bb63
bb63:
  call void @__olang_scope_close(ptr %s14)
  br label %bb64
bb64:
  %t235 = load ptr, ptr %l0, !tbaa !29
  store ptr %t235, ptr %l141, !tbaa !29
  %t236 = load ptr, ptr %l0, !tbaa !29
  %t238 = getelementptr %"compiler/lower:lowering", ptr %t236, i32 0, i32 10
  store ptr %t238, ptr %l143, !tbaa !29
  %t239 = load i64, ptr %l17, !tbaa !24
  %t242 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l4, i64 %t239)
  store i64 %t242, ptr %l146
  br label %bb65
bb65:
  %t243 = load ptr, ptr %l143, !tbaa !29
  %t244 = load i64, ptr %l146, !tbaa !24
  %t245 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aBlock_26_3e_2eAt_Hef81d01aee8891fe569e7a3039d88992(ptr %v0, ptr %v0, ptr %t243, i64 %t244)
  store ptr %t245, ptr %l147
  br label %bb66
bb66:
  %t246 = load ptr, ptr %l141, !tbaa !29
  %t247 = load ptr, ptr %l147, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eblock(ptr %v0, ptr %v0, ptr %t246, ptr %t247)
  br label %bb67
bb67:
  call void @__olang_scope_close(ptr %s13)
  br label %bb68
bb68:
  %t248 = load i64, ptr %l17, !tbaa !24
  %t250 = sub i64 %t248, 1
  store i64 %t250, ptr %l17, !tbaa !24
  br label %bb54
bb69:
  store ptr %l4, ptr %l18, !tbaa !29
  store i64 0, ptr %l19, !tbaa !24
  br label %bb70
bb70:
  store %olang.scope zeroinitializer, ptr %s17
  %t253 = load ptr, ptr %l18, !tbaa !29
  %t254 = load i64, ptr %l19, !tbaa !24
  %t257 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %s0, ptr %t253, i64 %t254)
  %t258 = extractvalue { i32, { i64, ptr } } %t257, 1
  %t259 = extractvalue { i32, { i64, ptr } } %t257, 0
  store i32 %t259, ptr %l155
  %t260 = icmp ne i32 %t259, 0
  br i1 %t260, label %bb72, label %ok.261
ok.261:
  store { i64, ptr } %t258, ptr %l154
  br label %bb71
bb71:
  %t262 = load { i64, ptr }, ptr %l154, !tbaa !27
  store { i64, ptr } %t262, ptr %l151, !tbaa !27
  br label %bb76
bb72:
  %t263 = load i32, ptr %l155, !tbaa !23
  %t264 = ashr i32 %t263, 16
  %t266 = icmp eq i32 %t264, 1
  br i1 %t266, label %bb73, label %bb74
bb73:
  br label %bb75
bb74:
  call void @__olang_check_failed(ptr @olang_loc_13daf6ec8e30e943_ad19332534c71267)
  unreachable
bb75:
  call void @__olang_scope_close(ptr %s17)
  br label %bb85
bb76:
  %t268 = load { i64, ptr }, ptr %l151, !tbaa !27
  store { i64, ptr } %t268, ptr %l20, !tbaa !27
  %t269 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t271 = extractvalue { i64, ptr } %t269, 0
  store i64 %t271, ptr %l21, !tbaa !24
  store i64 0, ptr %l22, !tbaa !24
  br label %bb77
bb77:
  store %olang.scope zeroinitializer, ptr %s18
  %t273 = load i64, ptr %l22, !tbaa !24
  %t274 = load i64, ptr %l21, !tbaa !24
  %t277 = icmp slt i64 %t273, %t274
  %t279 = xor i1 %t277, true
  br i1 %t279, label %bb78, label %bb79
bb78:
  call void @__olang_scope_close(ptr %s18)
  br label %bb83
bb79:
  br label %bb80
bb80:
  %t281 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t281, ptr %l164, !tbaa !27
  %t282 = load i64, ptr %l22, !tbaa !24
  %t284 = getelementptr { i64, ptr }, ptr %l164, i32 0, i32 1
  %t285 = load ptr, ptr %t284, !tbaa !27
  %t286 = getelementptr i64, ptr %t285, i64 %t282
  %t287 = load i64, ptr %t286, !tbaa !34
  %t289 = load ptr, ptr %l0, !tbaa !29
  %t291 = getelementptr %"compiler/lower:lowering", ptr %t289, i32 0, i32 11
  %t293 = getelementptr %"compiler/lower:level", ptr %l2, i32 0, i32 0
  %t294 = load i32, ptr %t293, !tbaa !23
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeId_3e_2eSetAt_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t291, i64 %t287, i32 %t294)
  br label %bb81
bb81:
  call void @__olang_scope_close(ptr %s18)
  br label %bb82
bb82:
  %t298 = load i64, ptr %l22, !tbaa !24
  %t300 = add i64 %t298, 1
  store i64 %t300, ptr %l22, !tbaa !24
  br label %bb77
bb83:
  %t302 = load i64, ptr %l19, !tbaa !24
  %t303 = load i64, ptr %l21, !tbaa !24
  %t306 = add i64 %t302, %t303
  store i64 %t306, ptr %l19, !tbaa !24
  call void @__olang_scope_close(ptr %s17)
  br label %bb84
bb84:
  br label %bb70
bb85:
  br label %bb86
bb86:
  store %olang.scope zeroinitializer, ptr %s20
  %t309 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3alevel_3e_2eLen_3ccompiler_2flower_3alevel_3e(ptr %s0, ptr %l3)
  store i64 %t309, ptr %l177
  br label %bb87
bb87:
  %t310 = load i64, ptr %l177, !tbaa !24
  %t311 = icmp sgt i64 %t310, 0
  %t313 = xor i1 %t311, true
  br i1 %t313, label %bb88, label %bb89
bb88:
  call void @__olang_scope_close(ptr %s20)
  br label %bb97
bb89:
  br label %bb90
bb90:
  %t315 = load ptr, ptr %l0, !tbaa !29
  %t317 = getelementptr %"compiler/lower:lowering", ptr %t315, i32 0, i32 9
  store ptr %t317, ptr %l181, !tbaa !29
  %t319 = call { i32, %"compiler/lower:level" } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3alevel_3e_2ePop_3ccompiler_2flower_3alevel_3e(ptr %s0, ptr %l3)
  %t320 = extractvalue { i32, %"compiler/lower:level" } %t319, 1
  %t321 = extractvalue { i32, %"compiler/lower:level" } %t319, 0
  store i32 %t321, ptr %l185
  %t322 = icmp ne i32 %t321, 0
  br i1 %t322, label %bb92, label %ok.323
ok.323:
  store %"compiler/lower:level" %t320, ptr %l184
  br label %bb91
bb91:
  %t324 = load %"compiler/lower:level", ptr %l184
  store %"compiler/lower:level" %t324, ptr %l182
  br label %bb94
bb92:
  br label %bb93
bb93:
  call void @__olang_check_failed(ptr @olang_loc_d7de50d0c280a1c2_f8c3e581c8870786)
  unreachable
bb94:
  %t325 = load ptr, ptr %l181, !tbaa !29
  %t326 = load %"compiler/lower:level", ptr %l182
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3alevel_3e_2ePush_3ccompiler_2flower_3alevel_3e(ptr %v0, ptr %t325, %"compiler/lower:level" %t326)
  br label %bb95
bb95:
  call void @__olang_scope_close(ptr %s20)
  br label %bb96
bb96:
  br label %bb86
bb97:
  %t327 = load ptr, ptr %l0, !tbaa !29
  %t329 = getelementptr %"compiler/lower:lowering", ptr %t327, i32 0, i32 7
  %t330 = load i1, ptr %t329, !tbaa !21
  br i1 %t330, label %bb98, label %bb99
bb98:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb99:
  br label %bb100
bb100:
  %t332 = getelementptr %"compiler/lower:level", ptr %l2, i32 0, i32 1
  %t333 = load i32, ptr %t332, !tbaa !23
  %t335 = icmp sge i32 %t333, 0
  br i1 %t335, label %bb101, label %bb102
bb101:
  %t337 = load ptr, ptr %l0, !tbaa !29
  %t339 = getelementptr %"compiler/lower:lowering", ptr %t337, i32 0, i32 1
  %t340 = load ptr, ptr %t339, !tbaa !29
  %t342 = getelementptr %"compiler/typed:Body", ptr %t340, i32 0, i32 8
  %t343 = getelementptr %"compiler/lower:level", ptr %l2, i32 0, i32 1
  %t344 = load i32, ptr %t343, !tbaa !23
  %t346 = sext i32 %t344 to i64
  %t349 = call %"compiler/typed:BlockInfo" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aBlockInfo_3e_2eA_Hdb91c1ab6f912bb6141763aa02d0b766(ptr %v0, ptr %t342, i64 %t346)
  store %"compiler/typed:BlockInfo" %t349, ptr %l196
  br label %bb103
bb102:
  %t350 = load ptr, ptr %l0, !tbaa !29
  %t352 = getelementptr %"compiler/lower:lowering", ptr %t350, i32 0, i32 1
  %t353 = load ptr, ptr %t352, !tbaa !29
  %t355 = getelementptr %"compiler/typed:Body", ptr %t353, i32 0, i32 4
  %t356 = load %"compiler/source:Span", ptr %t355
  store %"compiler/source:Span" %t356, ptr %l190
  br label %bb104
bb103:
  %t358 = getelementptr %"compiler/typed:BlockInfo", ptr %l196, i32 0, i32 2
  %t359 = load %"compiler/source:Span", ptr %t358
  store %"compiler/source:Span" %t359, ptr %l190
  br label %bb104
bb104:
  %t361 = load %"compiler/source:Span", ptr %l190
  store %"compiler/source:Span" %t361, ptr %l24
  %t362 = getelementptr %"compiler/lower:level", ptr %l2, i32 0, i32 2
  %t363 = load i32, ptr %t362
  %t365 = trunc i64 3 to i32
  %t366 = icmp eq i32 %t363, %t365
  br i1 %t366, label %bb105, label %bb106
bb105:
  %t368 = load ptr, ptr %l0, !tbaa !29
  %t370 = getelementptr %"compiler/lower:lowering", ptr %t368, i32 0, i32 3
  %t371 = getelementptr %"compiler/mir:Fn", ptr %t370, i32 0, i32 8
  %t372 = getelementptr %"compiler/lower:level", ptr %l2, i32 0, i32 0
  %t373 = load i32, ptr %t372, !tbaa !23
  %t375 = sext i32 %t373 to i64
  %t378 = call %"compiler/mir:ScopeInfo" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeInfo_3e_2eAt_3ccompiler_2fmir_3aScopeInfo_3e(ptr %v0, ptr %t371, i64 %t375)
  store %"compiler/mir:ScopeInfo" %t378, ptr %l207
  br label %bb107
bb106:
  br label %bb127
bb107:
  %t379 = getelementptr %"compiler/mir:ScopeInfo", ptr %l207, i32 0, i32 4
  %t380 = load i32, ptr %t379, !tbaa !23
  store i32 %t380, ptr %l25, !tbaa !23
  %t382 = load ptr, ptr %l0, !tbaa !29
  %t384 = getelementptr %"compiler/lower:lowering", ptr %t382, i32 0, i32 3
  %t386 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t384)
  store i32 %t386, ptr %l211
  br label %bb108
bb108:
  %t387 = load i32, ptr %l211, !tbaa !23
  store i32 %t387, ptr %l26, !tbaa !23
  %t388 = load ptr, ptr %l0, !tbaa !29
  %t390 = getelementptr %"compiler/lower:lowering", ptr %t388, i32 0, i32 2
  %t391 = load ptr, ptr %t390, !tbaa !29
  %t392 = load i32, ptr %l25, !tbaa !23
  %t395 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t391, i32 %t392)
  store { i64, ptr } %t395, ptr %l215
  br label %bb109
bb109:
  %t396 = load { i64, ptr }, ptr %l215, !tbaa !27
  %t397 = extractvalue { i64, ptr } %t396, 0
  %t399 = icmp eq i64 %t397, 0
  br i1 %t399, label %bb110, label %bb111
bb110:
  %t401 = load ptr, ptr %l0, !tbaa !29
  %t402 = load %"compiler/source:Span", ptr %l24
  %t403 = getelementptr %"compiler/lower:level", ptr %l2, i32 0, i32 0
  %t404 = load i32, ptr %t403, !tbaa !23
  %t405 = load i32, ptr %l26, !tbaa !23
  %t406 = load i32, ptr @G_2ecompiler_2fmir_2eNoLocal, !tbaa !23
  %t407 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  store { i64, [7 x i64] } zeroinitializer, ptr %t408
  %t409 = getelementptr { i64, [7 x i64] }, ptr %t408, i32 0, i32 0
  store i64 7, ptr %t409
  %t411 = insertvalue { %"compiler/source:Span", i32, i32, i32, i32 } undef, %"compiler/source:Span" %t402, 0
  %t413 = insertvalue { %"compiler/source:Span", i32, i32, i32, i32 } %t411, i32 %t404, 1
  %t415 = insertvalue { %"compiler/source:Span", i32, i32, i32, i32 } %t413, i32 %t405, 2
  %t417 = insertvalue { %"compiler/source:Span", i32, i32, i32, i32 } %t415, i32 %t406, 3
  %t419 = insertvalue { %"compiler/source:Span", i32, i32, i32, i32 } %t417, i32 %t407, 4
  %t420 = getelementptr { i64, [7 x i64] }, ptr %t408, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32, i32, i32 } %t419, ptr %t420
  %t421 = load { i64, [7 x i64] }, ptr %t408
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t401, { i64, [7 x i64] } %t421)
  br label %bb112
bb111:
  %t424 = load ptr, ptr %l0, !tbaa !29
  %t426 = getelementptr %"compiler/lower:lowering", ptr %t424, i32 0, i32 18
  %t427 = load i1, ptr %t426, !tbaa !21
  br i1 %t427, label %bb113, label %bb114
bb112:
  br label %bb125
bb113:
  %t429 = load ptr, ptr %l0, !tbaa !29
  %t430 = load i32, ptr @G_2ecompiler_2fmir_2eI32T, !tbaa !23
  %t431 = load %"compiler/source:Span", ptr %l24
  %t435 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2etemp(ptr %v0, ptr %t429, i32 %t430, %"compiler/source:Span" %t431)
  store i32 %t435, ptr %l230
  br label %bb115
bb114:
  store %olang.scope zeroinitializer, ptr %s27
  %t436 = load ptr, ptr %l0, !tbaa !29
  %t437 = load i32, ptr @G_2ecompiler_2fmir_2eI32T, !tbaa !23
  %t438 = load %"compiler/source:Span", ptr %l24
  %t442 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2etemp(ptr %v0, ptr %t436, i32 %t437, %"compiler/source:Span" %t438)
  store i32 %t442, ptr %l241
  br label %bb117
bb115:
  %t443 = load i32, ptr %l230, !tbaa !23
  %t444 = load ptr, ptr %l0, !tbaa !29
  %t445 = load %"compiler/source:Span", ptr %l24
  %t446 = getelementptr %"compiler/lower:level", ptr %l2, i32 0, i32 0
  %t447 = load i32, ptr %t446, !tbaa !23
  %t448 = load i32, ptr %l26, !tbaa !23
  %t450 = load i32, ptr %l26, !tbaa !23
  store { i64, [7 x i64] } zeroinitializer, ptr %t451
  %t452 = getelementptr { i64, [7 x i64] }, ptr %t451, i32 0, i32 0
  store i64 7, ptr %t452
  %t454 = insertvalue { %"compiler/source:Span", i32, i32, i32, i32 } undef, %"compiler/source:Span" %t445, 0
  %t456 = insertvalue { %"compiler/source:Span", i32, i32, i32, i32 } %t454, i32 %t447, 1
  %t458 = insertvalue { %"compiler/source:Span", i32, i32, i32, i32 } %t456, i32 %t448, 2
  %t460 = insertvalue { %"compiler/source:Span", i32, i32, i32, i32 } %t458, i32 %t443, 3
  %t462 = insertvalue { %"compiler/source:Span", i32, i32, i32, i32 } %t460, i32 %t450, 4
  %t463 = getelementptr { i64, [7 x i64] }, ptr %t451, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32, i32, i32 } %t462, ptr %t463
  %t464 = load { i64, [7 x i64] }, ptr %t451
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t444, { i64, [7 x i64] } %t464)
  br label %bb116
bb116:
  br label %bb124
bb117:
  %t467 = load i32, ptr %l241, !tbaa !23
  store i32 %t467, ptr %l28, !tbaa !23
  %t468 = load ptr, ptr %l0, !tbaa !29
  %t470 = getelementptr %"compiler/lower:lowering", ptr %t468, i32 0, i32 3
  %t472 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t470)
  store i32 %t472, ptr %l244
  br label %bb118
bb118:
  %t473 = load i32, ptr %l244, !tbaa !23
  store i32 %t473, ptr %l29, !tbaa !23
  %t474 = load ptr, ptr %l0, !tbaa !29
  %t475 = load %"compiler/source:Span", ptr %l24
  %t476 = getelementptr %"compiler/lower:level", ptr %l2, i32 0, i32 0
  %t477 = load i32, ptr %t476, !tbaa !23
  %t478 = load i32, ptr %l26, !tbaa !23
  %t479 = load i32, ptr %l28, !tbaa !23
  %t480 = load i32, ptr %l29, !tbaa !23
  store { i64, [7 x i64] } zeroinitializer, ptr %t481
  %t482 = getelementptr { i64, [7 x i64] }, ptr %t481, i32 0, i32 0
  store i64 7, ptr %t482
  %t484 = insertvalue { %"compiler/source:Span", i32, i32, i32, i32 } undef, %"compiler/source:Span" %t475, 0
  %t486 = insertvalue { %"compiler/source:Span", i32, i32, i32, i32 } %t484, i32 %t477, 1
  %t488 = insertvalue { %"compiler/source:Span", i32, i32, i32, i32 } %t486, i32 %t478, 2
  %t490 = insertvalue { %"compiler/source:Span", i32, i32, i32, i32 } %t488, i32 %t479, 3
  %t492 = insertvalue { %"compiler/source:Span", i32, i32, i32, i32 } %t490, i32 %t480, 4
  %t493 = getelementptr { i64, [7 x i64] }, ptr %t481, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32, i32, i32 } %t492, ptr %t493
  %t494 = load { i64, [7 x i64] }, ptr %t481
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t474, { i64, [7 x i64] } %t494)
  br label %bb119
bb119:
  %t497 = load ptr, ptr %l0, !tbaa !29
  %t498 = load i32, ptr %l29, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t497, i32 %t498)
  br label %bb120
bb120:
  %t501 = load ptr, ptr %l0, !tbaa !29
  %t502 = load %"compiler/source:Span", ptr %l24
  %t503 = getelementptr %"compiler/lower:level", ptr %l2, i32 0, i32 0
  %t504 = load i32, ptr %t503, !tbaa !23
  store { i64, [21 x i64] } zeroinitializer, ptr %t505
  %t506 = getelementptr { i64, [21 x i64] }, ptr %t505, i32 0, i32 0
  store i64 4, ptr %t506
  %t508 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t502, 0
  %t510 = insertvalue { %"compiler/source:Span", i32 } %t508, i32 %t504, 1
  %t511 = getelementptr { i64, [21 x i64] }, ptr %t505, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t510, ptr %t511
  %t512 = load { i64, [21 x i64] }, ptr %t505
  %t514 = call ptr @__olang_scope_alloc_a(ptr %s27, i64 176, i64 8)
  store { i64, [21 x i64] } %t512, ptr %t514
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s27, ptr %t501, ptr %t514)
  br label %bb121
bb121:
  %t517 = load ptr, ptr %l0, !tbaa !29
  store ptr %t517, ptr %l259, !tbaa !29
  %t518 = load i64, ptr %l1, !tbaa !24
  store i64 %t518, ptr %l260, !tbaa !24
  %t519 = getelementptr %"compiler/lower:level", ptr %l2, i32 0, i32 0
  %t520 = load i32, ptr %t519, !tbaa !23
  store i32 %t520, ptr %l261, !tbaa !23
  %t521 = load i32, ptr %l28, !tbaa !23
  %t523 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t521)
  store %"compiler/mir:Place" %t523, ptr %l263
  br label %bb122
bb122:
  store { i64, [4 x i64] } zeroinitializer, ptr %t524
  %t525 = getelementptr { i64, [4 x i64] }, ptr %t524, i32 0, i32 0
  store i64 1, ptr %t525
  %t526 = load %"compiler/mir:Place", ptr %l263
  %t527 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t526, 0
  %t528 = getelementptr { i64, [4 x i64] }, ptr %t524, i32 0, i32 1
  store { %"compiler/mir:Place" } %t527, ptr %t528
  %t529 = load { i64, [4 x i64] }, ptr %t524
  %t530 = load i32, ptr %l25, !tbaa !23
  %t531 = load %"compiler/source:Span", ptr %l24
  %t532 = load ptr, ptr %l259, !tbaa !29
  %t533 = load i64, ptr %l260, !tbaa !24
  %t534 = load i32, ptr %l261, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2ejoinFailed(ptr %v0, ptr %t532, i64 %t533, i32 %t534, { i64, [4 x i64] } %t529, i32 %t530, %"compiler/source:Span" %t531)
  br label %bb123
bb123:
  call void @__olang_scope_close(ptr %s27)
  br label %bb124
bb124:
  br label %bb125
bb125:
  %t538 = load ptr, ptr %l0, !tbaa !29
  %t539 = load i32, ptr %l26, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t538, i32 %t539)
  br label %bb126
bb126:
  br label %bb127
bb127:
  %t542 = load ptr, ptr %l0, !tbaa !29
  %t543 = load %"compiler/source:Span", ptr %l24
  %t544 = getelementptr %"compiler/lower:level", ptr %l2, i32 0, i32 0
  %t545 = load i32, ptr %t544, !tbaa !23
  store { i64, [21 x i64] } zeroinitializer, ptr %t546
  %t547 = getelementptr { i64, [21 x i64] }, ptr %t546, i32 0, i32 0
  store i64 4, ptr %t547
  %t549 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t543, 0
  %t551 = insertvalue { %"compiler/source:Span", i32 } %t549, i32 %t545, 1
  %t552 = getelementptr { i64, [21 x i64] }, ptr %t546, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t551, ptr %t552
  %t553 = load { i64, [21 x i64] }, ptr %t546
  %t555 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t553, ptr %t555
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s0, ptr %t542, ptr %t555)
  br label %bb128
bb128:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2flower_2ecompiler_2flower_3alowering_2eflag(ptr %v0, ptr %a0, i1 %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l7 = alloca i32
  %l8 = alloca ptr
  %l9 = alloca %"compiler/source:Span"
  %l11 = alloca %"compiler/mir:Place"
  %l15 = alloca { i64, [4 x i64] }
  %s0 = alloca %olang.scope
  %rv = alloca i32
  %t21 = alloca { i64, [15 x i64] }, align 8
  %t27 = alloca { i64, [21 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t3 = load %"compiler/source:Span", ptr %l2
  %t7 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2etemp(ptr %v0, ptr %t1, i32 %t2, %"compiler/source:Span" %t3)
  store i32 %t7, ptr %l7
  br label %bb1
bb1:
  %t8 = load i32, ptr %l7, !tbaa !23
  store i32 %t8, ptr %l3, !tbaa !23
  %t9 = load ptr, ptr %l0, !tbaa !29
  store ptr %t9, ptr %l8, !tbaa !29
  %t10 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t10, ptr %l9
  %t11 = load i32, ptr %l3, !tbaa !23
  %t13 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t11)
  store %"compiler/mir:Place" %t13, ptr %l11
  br label %bb2
bb2:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = load %"compiler/source:Span", ptr %l2
  %t20 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2econstBool(ptr %v0, ptr %t14, i1 %a1, %"compiler/source:Span" %t16)
  store { i64, [4 x i64] } %t20, ptr %l15
  br label %bb3
bb3:
  store { i64, [15 x i64] } zeroinitializer, ptr %t21
  %t22 = getelementptr { i64, [15 x i64] }, ptr %t21, i32 0, i32 0
  store i64 0, ptr %t22
  %t23 = load { i64, [4 x i64] }, ptr %l15
  %t24 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t23, 0
  %t25 = getelementptr { i64, [15 x i64] }, ptr %t21, i32 0, i32 1
  store { { i64, [4 x i64] } } %t24, ptr %t25
  %t26 = load { i64, [15 x i64] }, ptr %t21
  store { i64, [21 x i64] } zeroinitializer, ptr %t27
  %t28 = getelementptr { i64, [21 x i64] }, ptr %t27, i32 0, i32 0
  store i64 0, ptr %t28
  %t29 = load %"compiler/source:Span", ptr %l9
  %t30 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t29, 0
  %t31 = load %"compiler/mir:Place", ptr %l11
  %t32 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t30, %"compiler/mir:Place" %t31, 1
  %t34 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t32, { i64, [15 x i64] } %t26, 2
  %t35 = getelementptr { i64, [21 x i64] }, ptr %t27, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t34, ptr %t35
  %t36 = load { i64, [21 x i64] }, ptr %t27
  %t38 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t36, ptr %t38
  %t39 = load ptr, ptr %l8, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s0, ptr %t39, ptr %t38)
  br label %bb4
bb4:
  %t41 = load i32, ptr %l3, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t41, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2egap(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l8 = alloca ptr
  %l15 = alloca %"compiler/lower:Gap"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 8
  %t4 = load i1, ptr %t3, !tbaa !21
  %t6 = xor i1 %t4, true
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/lower:lowering", ptr %t8, i32 0, i32 0
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t13 = getelementptr %"compiler/lower:Lowerer", ptr %t11, i32 0, i32 3
  store ptr %t13, ptr %l8, !tbaa !29
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/lower:lowering", ptr %t14, i32 0, i32 4
  %t17 = load i64, ptr %t16, !tbaa !24
  %t21 = extractvalue { i64, ptr } %a2, 1
  %t22 = extractvalue { i64, ptr } %a2, 0
  %t23 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t22)
  call void @olang_textcopy(ptr %t23, ptr %t21, i64 %t22)
  %t24 = insertvalue { i64, ptr } undef, i64 %t22, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t23, 1
  %t27 = extractvalue { i64, ptr } %t25, 0
  %t28 = extractvalue { i64, ptr } %t25, 1
  %t29 = mul i64 %t27, 1
  %t30 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t29)
  call void @llvm.memcpy.p0.p0.i64(ptr %t30, ptr %t28, i64 %t29, i1 false)
  %t31 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  %t36 = call %"compiler/lower:Gap" @compiler_2flower_3aGap_2ector(ptr %v0, ptr %v0, i64 %t17, %"compiler/source:Span" %a1, { i64, ptr } %t32)
  store %"compiler/lower:Gap" %t36, ptr %l15
  br label %bb3
bb2:
  br label %bb5
bb3:
  %t37 = load ptr, ptr %l8, !tbaa !29
  %t38 = load %"compiler/lower:Gap", ptr %l15
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3aGap_3e_2ePush_3ccompiler_2flower_3aGap_3e(ptr %v0, ptr %v0, ptr %t37, %"compiler/lower:Gap" %t38)
  br label %bb4
bb4:
  br label %bb5
bb5:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/lower:lowering", ptr %t39, i32 0, i32 8
  store i1 true, ptr %t41, !tbaa !21
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2ehelper(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca %"compiler/lower:pl"
  %l20 = alloca %"compiler/lower:pl"
  %l22 = alloca %"compiler/lower:pl"
  %l23 = alloca ptr
  %l29 = alloca { i64, [4 x i64] }
  %l36 = alloca ptr
  %l37 = alloca ptr
  %l39 = alloca %"compiler/lower:pl"
  %l42 = alloca { i64, [4 x i64] }
  %l48 = alloca { i64, ptr }
  %l49 = alloca ptr
  %l53 = alloca { i64, ptr }
  %l61 = alloca ptr
  %l65 = alloca { i64, [4 x i64] }
  %l73 = alloca ptr
  %l74 = alloca %"compiler/mir:Place"
  %l76 = alloca ptr
  %l78 = alloca %"compiler/lower:pl"
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %t112 = alloca { i64, [1 x i64] }, align 8
  %t161 = alloca { i64, [1 x i64] }, align 8
  %t182 = alloca { i64, [4 x i64] }, align 8
  %t196 = alloca { i64, [1 x i64] }, align 8
  %t208 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/lower:lowering", ptr %t6, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t11 = getelementptr %"compiler/typed:Body", ptr %t9, i32 0, i32 4
  %t12 = load %"compiler/source:Span", ptr %t11
  store %"compiler/source:Span" %t12, ptr %l4
  %t14 = load i32, ptr %l1
  %t16 = trunc i64 1 to i32
  %t17 = icmp eq i32 %t14, %t16
  br i1 %t17, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb9
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = load ptr, ptr @__olang_prog_scope
  %t22 = call ptr @__olang_scope_alloc(ptr %t21, i64 0)
  store [0 x { i64, [1 x i64] }] zeroinitializer, ptr %t22
  %t23 = insertvalue { i64, ptr } undef, i64 0, 0
  %t24 = insertvalue { i64, ptr } %t23, ptr %t22, 1
  %t26 = extractvalue { i64, ptr } %t24, 0
  %t27 = extractvalue { i64, ptr } %t24, 1
  %t28 = mul i64 %t26, 16
  %t29 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t28)
  call void @llvm.memcpy.p0.p0.i64(ptr %t29, ptr %t27, i64 %t28, i1 false)
  %t30 = insertvalue { i64, ptr } undef, i64 %t26, 0
  %t31 = insertvalue { i64, ptr } %t30, ptr %t29, 1
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eprologue(ptr %v0, ptr %s1, ptr %t19, { i64, ptr } %t31)
  br label %bb4
bb4:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = call %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2eat(ptr %v0, ptr %s1, ptr %t34, i32 0)
  store %"compiler/lower:pl" %t36, ptr %l20
  br label %bb5
bb5:
  %t37 = load %"compiler/lower:pl", ptr %l20
  store %"compiler/lower:pl" %t37, ptr %l5
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = call %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2eat(ptr %v0, ptr %s1, ptr %t38, i32 1)
  store %"compiler/lower:pl" %t40, ptr %l22
  br label %bb6
bb6:
  %t41 = load %"compiler/lower:pl", ptr %l22
  %t42 = load ptr, ptr %l0, !tbaa !29
  store ptr %t42, ptr %l23, !tbaa !29
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t44 = load %"compiler/lower:pl", ptr %l5
  %t46 = load i32, ptr %l2, !tbaa !23
  %t47 = load %"compiler/source:Span", ptr %l4
  %t53 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eequalAt(ptr %v0, ptr %s1, ptr %s1, ptr %t43, %"compiler/lower:pl" %t44, %"compiler/lower:pl" %t41, i32 %t46, %"compiler/source:Span" %t47, i1 true)
  store { i64, [4 x i64] } %t53, ptr %l29
  br label %bb7
bb7:
  %t54 = load ptr, ptr %l23, !tbaa !29
  %t55 = load { i64, [4 x i64] }, ptr %l29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eepilogue(ptr %v0, ptr %t54, { i64, [4 x i64] } %t55)
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s1)
  br label %bb38
bb9:
  %t56 = load i32, ptr %l1
  %t58 = trunc i64 2 to i32
  %t59 = icmp eq i32 %t56, %t58
  br i1 %t59, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb17
bb12:
  store %olang.scope zeroinitializer, ptr %s2
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = load ptr, ptr @__olang_prog_scope
  %t64 = call ptr @__olang_scope_alloc(ptr %t63, i64 0)
  store [0 x { i64, [1 x i64] }] zeroinitializer, ptr %t64
  %t65 = insertvalue { i64, ptr } undef, i64 0, 0
  %t66 = insertvalue { i64, ptr } %t65, ptr %t64, 1
  %t68 = extractvalue { i64, ptr } %t66, 0
  %t69 = extractvalue { i64, ptr } %t66, 1
  %t70 = mul i64 %t68, 16
  %t71 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t70)
  call void @llvm.memcpy.p0.p0.i64(ptr %t71, ptr %t69, i64 %t70, i1 false)
  %t72 = insertvalue { i64, ptr } undef, i64 %t68, 0
  %t73 = insertvalue { i64, ptr } %t72, ptr %t71, 1
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eprologue(ptr %v0, ptr %s2, ptr %t61, { i64, ptr } %t73)
  br label %bb13
bb13:
  %t76 = load ptr, ptr %l0, !tbaa !29
  store ptr %t76, ptr %l36, !tbaa !29
  %t77 = load ptr, ptr %l0, !tbaa !29
  store ptr %t77, ptr %l37, !tbaa !29
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t80 = call %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2eat(ptr %v0, ptr %s2, ptr %t78, i32 0)
  store %"compiler/lower:pl" %t80, ptr %l39
  br label %bb14
bb14:
  %t81 = load i32, ptr %l2, !tbaa !23
  %t82 = load %"compiler/source:Span", ptr %l4
  %t83 = load ptr, ptr %l37, !tbaa !29
  %t84 = load %"compiler/lower:pl", ptr %l39
  %t87 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ehashAt(ptr %v0, ptr %s2, ptr %t83, %"compiler/lower:pl" %t84, i32 %t81, %"compiler/source:Span" %t82, i1 true)
  store { i64, [4 x i64] } %t87, ptr %l42
  br label %bb15
bb15:
  %t88 = load ptr, ptr %l36, !tbaa !29
  %t89 = load { i64, [4 x i64] }, ptr %l42
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eepilogue(ptr %v0, ptr %t88, { i64, [4 x i64] } %t89)
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s2)
  br label %bb38
bb17:
  %t90 = load i32, ptr %l1
  %t92 = trunc i64 3 to i32
  %t93 = icmp eq i32 %t90, %t92
  br i1 %t93, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb28
bb20:
  store %olang.scope zeroinitializer, ptr %s3
  %t95 = load ptr, ptr %l3, !tbaa !29
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"compiler/lower:lowering", ptr %t96, i32 0, i32 3
  %t99 = getelementptr %"compiler/mir:Fn", ptr %t98, i32 0, i32 1
  %t100 = load i32, ptr %t99, !tbaa !23
  %t103 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopeVarsOf(ptr %v0, ptr %s3, ptr %t95, i32 %t100)
  store { i64, ptr } %t103, ptr %l48
  br label %bb21
bb21:
  %t104 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t105 = load ptr, ptr %l0, !tbaa !29
  store ptr %t105, ptr %l49, !tbaa !29
  %t108 = extractvalue { i64, ptr } %t104, 0
  %t110 = icmp sgt i64 %t108, 0
  br i1 %t110, label %bb22, label %bb23
bb22:
  store { i64, [1 x i64] } zeroinitializer, ptr %t112
  %t113 = getelementptr { i64, [1 x i64] }, ptr %t112, i32 0, i32 0
  store i64 1, ptr %t113
  %t114 = load { i64, [1 x i64] }, ptr %t112
  %t116 = insertvalue [1 x { i64, [1 x i64] }] undef, { i64, [1 x i64] } %t114, 0
  %t118 = load ptr, ptr @__olang_prog_scope
  %t119 = call ptr @__olang_scope_alloc(ptr %t118, i64 16)
  store [1 x { i64, [1 x i64] }] %t116, ptr %t119
  %t120 = insertvalue { i64, ptr } undef, i64 1, 0
  %t121 = insertvalue { i64, ptr } %t120, ptr %t119, 1
  %t123 = extractvalue { i64, ptr } %t121, 0
  %t124 = extractvalue { i64, ptr } %t121, 1
  %t125 = mul i64 %t123, 16
  %t126 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t125)
  call void @llvm.memcpy.p0.p0.i64(ptr %t126, ptr %t124, i64 %t125, i1 false)
  %t127 = insertvalue { i64, ptr } undef, i64 %t123, 0
  %t128 = insertvalue { i64, ptr } %t127, ptr %t126, 1
  store { i64, ptr } %t128, ptr %l53, !tbaa !27
  br label %bb24
bb23:
  %t131 = load ptr, ptr @__olang_prog_scope
  %t132 = call ptr @__olang_scope_alloc(ptr %t131, i64 0)
  store [0 x { i64, [1 x i64] }] zeroinitializer, ptr %t132
  %t133 = insertvalue { i64, ptr } undef, i64 0, 0
  %t134 = insertvalue { i64, ptr } %t133, ptr %t132, 1
  %t136 = extractvalue { i64, ptr } %t134, 0
  %t137 = extractvalue { i64, ptr } %t134, 1
  %t138 = mul i64 %t136, 16
  %t139 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t138)
  call void @llvm.memcpy.p0.p0.i64(ptr %t139, ptr %t137, i64 %t138, i1 false)
  %t140 = insertvalue { i64, ptr } undef, i64 %t136, 0
  %t141 = insertvalue { i64, ptr } %t140, ptr %t139, 1
  store { i64, ptr } %t141, ptr %l53, !tbaa !27
  br label %bb24
bb24:
  %t143 = load ptr, ptr %l49, !tbaa !29
  %t144 = load { i64, ptr }, ptr %l53, !tbaa !27
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eprologue(ptr %v0, ptr %s3, ptr %t143, { i64, ptr } %t144)
  br label %bb25
bb25:
  %t145 = load ptr, ptr %l0, !tbaa !29
  store ptr %t145, ptr %l61, !tbaa !29
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t147 = load i32, ptr %l2, !tbaa !23
  %t148 = load %"compiler/source:Span", ptr %l4
  %t152 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ezeroOf(ptr %v0, ptr %t146, i32 %t147, %"compiler/source:Span" %t148)
  store { i64, [4 x i64] } %t152, ptr %l65
  br label %bb26
bb26:
  %t153 = load ptr, ptr %l61, !tbaa !29
  %t154 = load { i64, [4 x i64] }, ptr %l65
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eepilogue(ptr %v0, ptr %t153, { i64, [4 x i64] } %t154)
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s3)
  br label %bb38
bb28:
  %t155 = load i32, ptr %l1
  %t157 = trunc i64 0 to i32
  %t158 = icmp eq i32 %t155, %t157
  br i1 %t158, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb37
bb31:
  store %olang.scope zeroinitializer, ptr %s4
  %t160 = load ptr, ptr %l0, !tbaa !29
  store { i64, [1 x i64] } zeroinitializer, ptr %t161
  %t162 = getelementptr { i64, [1 x i64] }, ptr %t161, i32 0, i32 0
  store i64 5, ptr %t162
  %t163 = load { i64, [1 x i64] }, ptr %t161
  %t165 = insertvalue [1 x { i64, [1 x i64] }] undef, { i64, [1 x i64] } %t163, 0
  %t167 = load ptr, ptr @__olang_prog_scope
  %t168 = call ptr @__olang_scope_alloc(ptr %t167, i64 16)
  store [1 x { i64, [1 x i64] }] %t165, ptr %t168
  %t169 = insertvalue { i64, ptr } undef, i64 1, 0
  %t170 = insertvalue { i64, ptr } %t169, ptr %t168, 1
  %t172 = extractvalue { i64, ptr } %t170, 0
  %t173 = extractvalue { i64, ptr } %t170, 1
  %t174 = mul i64 %t172, 16
  %t175 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t174)
  call void @llvm.memcpy.p0.p0.i64(ptr %t175, ptr %t173, i64 %t174, i1 false)
  %t176 = insertvalue { i64, ptr } undef, i64 %t172, 0
  %t177 = insertvalue { i64, ptr } %t176, ptr %t175, 1
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eprologue(ptr %v0, ptr %s4, ptr %t160, { i64, ptr } %t177)
  br label %bb32
bb32:
  %t180 = load ptr, ptr %l0, !tbaa !29
  store ptr %t180, ptr %l73, !tbaa !29
  %t181 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 1)
  store %"compiler/mir:Place" %t181, ptr %l74
  br label %bb33
bb33:
  store { i64, [4 x i64] } zeroinitializer, ptr %t182
  %t183 = getelementptr { i64, [4 x i64] }, ptr %t182, i32 0, i32 0
  store i64 1, ptr %t183
  %t184 = load %"compiler/mir:Place", ptr %l74
  %t185 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t184, 0
  %t186 = getelementptr { i64, [4 x i64] }, ptr %t182, i32 0, i32 1
  store { %"compiler/mir:Place" } %t185, ptr %t186
  %t187 = load { i64, [4 x i64] }, ptr %t182
  %t189 = load ptr, ptr %l73, !tbaa !29
  %t190 = getelementptr %"compiler/lower:lowering", ptr %t189, i32 0, i32 5
  store { i64, [4 x i64] } %t187, ptr %t190
  %t191 = load ptr, ptr %l0, !tbaa !29
  store ptr %t191, ptr %l76, !tbaa !29
  %t192 = load ptr, ptr %l0, !tbaa !29
  %t194 = call %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2eat(ptr %v0, ptr %s4, ptr %t192, i32 0)
  store %"compiler/lower:pl" %t194, ptr %l78
  br label %bb34
bb34:
  %t195 = load i32, ptr %l2, !tbaa !23
  store { i64, [1 x i64] } zeroinitializer, ptr %t196
  %t197 = getelementptr { i64, [1 x i64] }, ptr %t196, i32 0, i32 0
  store i64 1, ptr %t197
  %t198 = insertvalue { i64 } undef, i64 0, 0
  %t199 = getelementptr { i64, [1 x i64] }, ptr %t196, i32 0, i32 1
  store { i64 } %t198, ptr %t199
  %t200 = load { i64, [1 x i64] }, ptr %t196
  %t201 = load %"compiler/source:Span", ptr %l4
  %t202 = load ptr, ptr %l76, !tbaa !29
  %t203 = load %"compiler/lower:pl", ptr %l78
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2erenderAt(ptr %v0, ptr %s4, ptr %t202, %"compiler/lower:pl" %t203, i32 %t195, { i64, [1 x i64] } %t200, %"compiler/source:Span" %t201, i1 true)
  br label %bb35
bb35:
  %t207 = load ptr, ptr %l0, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t208
  %t209 = getelementptr { i64, [4 x i64] }, ptr %t208, i32 0, i32 0
  store i64 0, ptr %t209
  %t210 = load { i64, [4 x i64] }, ptr %t208
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eepilogue(ptr %v0, ptr %t207, { i64, [4 x i64] } %t210)
  br label %bb36
bb36:
  call void @__olang_scope_close(ptr %s4)
  br label %bb38
bb37:
  call void @__olang_check_failed(ptr @olang_loc_30767a805df234bd_503f920f410b6239)
  unreachable
bb38:
  br label %ret
ret:
  ret void
}

define dso_local { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ehelperCall(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, i32 %a2, { i64, ptr } %a3, { i64, ptr } %a4, i32 %a5, %"compiler/source:Span" %a6) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l5 = alloca i32
  %l6 = alloca %"compiler/source:Span"
  %l7 = alloca i32
  %l8 = alloca { i64, [1 x i64] }
  %l9 = alloca i32
  %l10 = alloca i32
  %l16 = alloca i32
  %l21 = alloca i32
  %l30 = alloca i32
  %l38 = alloca i32
  %l40 = alloca ptr
  %l43 = alloca { i64, [5 x i64] }
  %l47 = alloca %"compiler/mir:Range"
  %l51 = alloca %"compiler/mir:Range"
  %l55 = alloca %"compiler/mir:Place"
  %l57 = alloca %"compiler/mir:Place"
  %l65 = alloca %"compiler/mir:Call"
  %l66 = alloca i32
  %l76 = alloca { i64, [4 x i64] }
  %l79 = alloca %"compiler/mir:Place"
  %s0 = alloca %olang.scope
  %rv = alloca { i64, [4 x i64] }
  %t25 = alloca { i64, [1 x i64] }, align 8
  %t68 = alloca { i64, [5 x i64] }, align 8
  %t126 = alloca { i64, [7 x i64] }, align 8
  %t146 = alloca { i64, [4 x i64] }, align 8
  %t153 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  store i32 %a5, ptr %l5
  store %"compiler/source:Span" %a6, ptr %l6
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i32, ptr %l1
  %t6 = load i32, ptr %l2, !tbaa !23
  %t10 = call i32 @compiler_2flower_2ecompiler_2flower_3aLowerer_2ehelperTy(ptr %v0, ptr %t4, i32 %t5, i32 %t6)
  store i32 %t10, ptr %l16
  br label %bb1
bb1:
  %t11 = load i32, ptr %l16, !tbaa !23
  store i32 %t11, ptr %l2, !tbaa !23
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/lower:lowering", ptr %t12, i32 0, i32 2
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t16 = load i32, ptr %l1
  %t17 = load i32, ptr %l2, !tbaa !23
  %t21 = call i32 @compiler_2fmir_2eHelperType(ptr %v0, ptr %t15, i32 %t16, i32 %t17)
  store i32 %t21, ptr %l21
  br label %bb2
bb2:
  %t22 = load i32, ptr %l21, !tbaa !23
  store i32 %t22, ptr %l7, !tbaa !23
  %t23 = load i32, ptr %l1
  %t24 = load i32, ptr %l2, !tbaa !23
  store { i64, [1 x i64] } zeroinitializer, ptr %t25
  %t26 = getelementptr { i64, [1 x i64] }, ptr %t25, i32 0, i32 0
  store i64 2, ptr %t26
  %t28 = insertvalue { i32, i32 } undef, i32 %t23, 0
  %t30 = insertvalue { i32, i32 } %t28, i32 %t24, 1
  %t31 = getelementptr { i64, [1 x i64] }, ptr %t25, i32 0, i32 1
  store { i32, i32 } %t30, ptr %t31
  %t32 = load { i64, [1 x i64] }, ptr %t25
  store { i64, [1 x i64] } %t32, ptr %l8
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/lower:lowering", ptr %t34, i32 0, i32 0
  %t37 = load ptr, ptr %t36, !tbaa !29
  %t38 = load { i64, [1 x i64] }, ptr %l8
  call void @compiler_2flower_2ecompiler_2flower_3aLowerer_2eWant(ptr %v0, ptr %t37, { i64, [1 x i64] } %t38)
  br label %bb3
bb3:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/lower:lowering", ptr %t41, i32 0, i32 3
  %t45 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t43)
  store i32 %t45, ptr %l30
  br label %bb4
bb4:
  %t46 = load i32, ptr %l30, !tbaa !23
  store i32 %t46, ptr %l9, !tbaa !23
  %t47 = load i32, ptr @G_2ecompiler_2fmir_2eNoLocal, !tbaa !23
  store i32 %t47, ptr %l10, !tbaa !23
  %t49 = load i32, ptr %l5, !tbaa !23
  %t50 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t53 = icmp ne i32 %t49, %t50
  br i1 %t53, label %bb5, label %bb6
bb5:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t56 = load i32, ptr %l5, !tbaa !23
  %t57 = load %"compiler/source:Span", ptr %l6
  %t61 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2etemp(ptr %v0, ptr %t55, i32 %t56, %"compiler/source:Span" %t57)
  store i32 %t61, ptr %l38
  br label %bb7
bb6:
  br label %bb8
bb7:
  %t62 = load i32, ptr %l38, !tbaa !23
  store i32 %t62, ptr %l10, !tbaa !23
  br label %bb8
bb8:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/lower:lowering", ptr %t63, i32 0, i32 3
  store ptr %t65, ptr %l40, !tbaa !29
  %t66 = load { i64, [1 x i64] }, ptr %l8
  %t67 = load i32, ptr %l7, !tbaa !23
  store { i64, [5 x i64] } zeroinitializer, ptr %t68
  %t69 = getelementptr { i64, [5 x i64] }, ptr %t68, i32 0, i32 0
  store i64 0, ptr %t69
  %t71 = insertvalue { { i64, [1 x i64] }, i32 } undef, { i64, [1 x i64] } %t66, 0
  %t73 = insertvalue { { i64, [1 x i64] }, i32 } %t71, i32 %t67, 1
  %t74 = getelementptr { i64, [5 x i64] }, ptr %t68, i32 0, i32 1
  store { { i64, [1 x i64] }, i32 } %t73, ptr %t74
  %t75 = load { i64, [5 x i64] }, ptr %t68
  store { i64, [5 x i64] } %t75, ptr %l43
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"compiler/lower:lowering", ptr %t76, i32 0, i32 3
  %t82 = call %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eArgs(ptr %v0, ptr %v1, ptr %t78, { i64, ptr } %a3)
  store %"compiler/mir:Range" %t82, ptr %l47
  br label %bb9
bb9:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr %"compiler/lower:lowering", ptr %t83, i32 0, i32 3
  %t89 = call %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eScopeRefs(ptr %v0, ptr %v2, ptr %t85, { i64, ptr } %a4)
  store %"compiler/mir:Range" %t89, ptr %l51
  br label %bb10
bb10:
  %t90 = load i32, ptr %l10, !tbaa !23
  %t91 = load i32, ptr @G_2ecompiler_2fmir_2eNoLocal, !tbaa !23
  %t94 = icmp ne i32 %t90, %t91
  br i1 %t94, label %bb11, label %bb12
bb11:
  %t96 = load i32, ptr %l10, !tbaa !23
  %t98 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t96)
  store %"compiler/mir:Place" %t98, ptr %l57
  br label %bb13
bb12:
  %t99 = load %"compiler/mir:Place", ptr @G_2ecompiler_2fmir_2eNoPlace
  store %"compiler/mir:Place" %t99, ptr %l55
  br label %bb14
bb13:
  %t101 = load %"compiler/mir:Place", ptr %l57
  store %"compiler/mir:Place" %t101, ptr %l55
  br label %bb14
bb14:
  %t102 = load i32, ptr %l10, !tbaa !23
  %t103 = load i32, ptr @G_2ecompiler_2fmir_2eNoLocal, !tbaa !23
  %t106 = icmp ne i32 %t102, %t103
  %t107 = load i32, ptr %l9, !tbaa !23
  %t108 = load i32, ptr @G_2ecompiler_2fmir_2eNoLocal, !tbaa !23
  %t109 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t110 = load { i64, [5 x i64] }, ptr %l43
  %t111 = load %"compiler/mir:Range", ptr %l47
  %t112 = load %"compiler/mir:Range", ptr %l51
  %t113 = load %"compiler/mir:Place", ptr %l55
  %t118 = call %"compiler/mir:Call" @compiler_2fmir_3aCall_2ector(ptr %s0, { i64, [5 x i64] } %t110, %"compiler/mir:Range" %t111, %"compiler/mir:Range" %t112, %"compiler/mir:Place" %t113, i1 %t106, i32 %t107, i32 %t108, i32 %t109)
  store %"compiler/mir:Call" %t118, ptr %l65
  br label %bb15
bb15:
  %t119 = load ptr, ptr %l40, !tbaa !29
  %t120 = load %"compiler/mir:Call", ptr %l65
  %t121 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddCall(ptr %v0, ptr %t119, %"compiler/mir:Call" %t120)
  store i32 %t121, ptr %l66
  br label %bb16
bb16:
  %t122 = load i32, ptr %l66, !tbaa !23
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t124 = load %"compiler/source:Span", ptr %l6
  store { i64, [7 x i64] } zeroinitializer, ptr %t126
  %t127 = getelementptr { i64, [7 x i64] }, ptr %t126, i32 0, i32 0
  store i64 4, ptr %t127
  %t129 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t124, 0
  %t131 = insertvalue { %"compiler/source:Span", i32 } %t129, i32 %t122, 1
  %t132 = getelementptr { i64, [7 x i64] }, ptr %t126, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t131, ptr %t132
  %t133 = load { i64, [7 x i64] }, ptr %t126
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t123, { i64, [7 x i64] } %t133)
  br label %bb17
bb17:
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t137 = load i32, ptr %l9, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t136, i32 %t137)
  br label %bb18
bb18:
  %t140 = load i32, ptr %l10, !tbaa !23
  %t141 = load i32, ptr @G_2ecompiler_2fmir_2eNoLocal, !tbaa !23
  %t144 = icmp eq i32 %t140, %t141
  br i1 %t144, label %bb19, label %bb20
bb19:
  store { i64, [4 x i64] } zeroinitializer, ptr %t146
  %t147 = getelementptr { i64, [4 x i64] }, ptr %t146, i32 0, i32 0
  store i64 0, ptr %t147
  %t148 = load { i64, [4 x i64] }, ptr %t146
  store { i64, [4 x i64] } %t148, ptr %l76
  br label %bb22
bb20:
  %t150 = load i32, ptr %l10, !tbaa !23
  %t152 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t150)
  store %"compiler/mir:Place" %t152, ptr %l79
  br label %bb21
bb21:
  store { i64, [4 x i64] } zeroinitializer, ptr %t153
  %t154 = getelementptr { i64, [4 x i64] }, ptr %t153, i32 0, i32 0
  store i64 1, ptr %t154
  %t155 = load %"compiler/mir:Place", ptr %l79
  %t156 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t155, 0
  %t157 = getelementptr { i64, [4 x i64] }, ptr %t153, i32 0, i32 1
  store { %"compiler/mir:Place" } %t156, ptr %t157
  %t158 = load { i64, [4 x i64] }, ptr %t153
  store { i64, [4 x i64] } %t158, ptr %l76
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s0)
  %t160 = load { i64, [4 x i64] }, ptr %l76
  store { i64, [4 x i64] } %t160, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local { { i64, [5 x i64] }, i32 } @compiler_2flower_2ecompiler_2flower_3alowering_2ehelperCallee(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca i32
  %l7 = alloca i32
  %l14 = alloca i32
  %l19 = alloca i32
  %rv = alloca { { i64, [5 x i64] }, i32 }
  %t37 = alloca { i64, [1 x i64] }, align 8
  %t49 = alloca { i64, [1 x i64] }, align 8
  %t58 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t3 = trunc i64 0 to i32
  %t4 = icmp eq i32 %a1, %t3
  br i1 %t4, label %bb1, label %bb2
bb1:
  store i32 1, ptr %l7
  br label %bb3
bb2:
  store i32 2, ptr %l7
  br label %bb3
bb3:
  %t8 = load i32, ptr %l7
  store i32 %t8, ptr %l3
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/lower:lowering", ptr %t9, i32 0, i32 0
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t13 = load i32, ptr %l3
  %t14 = load i32, ptr %l2, !tbaa !23
  %t18 = call i32 @compiler_2flower_2ecompiler_2flower_3aLowerer_2ehelperTy(ptr %v0, ptr %t12, i32 %t13, i32 %t14)
  store i32 %t18, ptr %l14
  br label %bb4
bb4:
  %t19 = load i32, ptr %l14, !tbaa !23
  store i32 %t19, ptr %l2, !tbaa !23
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/lower:lowering", ptr %t20, i32 0, i32 2
  %t23 = load ptr, ptr %t22, !tbaa !29
  %t24 = load i32, ptr %l3
  %t25 = load i32, ptr %l2, !tbaa !23
  %t29 = call i32 @compiler_2fmir_2eHelperType(ptr %v0, ptr %t23, i32 %t24, i32 %t25)
  store i32 %t29, ptr %l19
  br label %bb5
bb5:
  %t30 = load i32, ptr %l19, !tbaa !23
  store i32 %t30, ptr %l4, !tbaa !23
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/lower:lowering", ptr %t31, i32 0, i32 0
  %t34 = load ptr, ptr %t33, !tbaa !29
  %t35 = load i32, ptr %l3
  %t36 = load i32, ptr %l2, !tbaa !23
  store { i64, [1 x i64] } zeroinitializer, ptr %t37
  %t38 = getelementptr { i64, [1 x i64] }, ptr %t37, i32 0, i32 0
  store i64 2, ptr %t38
  %t40 = insertvalue { i32, i32 } undef, i32 %t35, 0
  %t42 = insertvalue { i32, i32 } %t40, i32 %t36, 1
  %t43 = getelementptr { i64, [1 x i64] }, ptr %t37, i32 0, i32 1
  store { i32, i32 } %t42, ptr %t43
  %t44 = load { i64, [1 x i64] }, ptr %t37
  call void @compiler_2flower_2ecompiler_2flower_3aLowerer_2eWant(ptr %v0, ptr %t34, { i64, [1 x i64] } %t44)
  br label %bb6
bb6:
  %t47 = load i32, ptr %l3
  %t48 = load i32, ptr %l2, !tbaa !23
  store { i64, [1 x i64] } zeroinitializer, ptr %t49
  %t50 = getelementptr { i64, [1 x i64] }, ptr %t49, i32 0, i32 0
  store i64 2, ptr %t50
  %t52 = insertvalue { i32, i32 } undef, i32 %t47, 0
  %t54 = insertvalue { i32, i32 } %t52, i32 %t48, 1
  %t55 = getelementptr { i64, [1 x i64] }, ptr %t49, i32 0, i32 1
  store { i32, i32 } %t54, ptr %t55
  %t56 = load { i64, [1 x i64] }, ptr %t49
  %t57 = load i32, ptr %l4, !tbaa !23
  store { i64, [5 x i64] } zeroinitializer, ptr %t58
  %t59 = getelementptr { i64, [5 x i64] }, ptr %t58, i32 0, i32 0
  store i64 0, ptr %t59
  %t61 = insertvalue { { i64, [1 x i64] }, i32 } undef, { i64, [1 x i64] } %t56, 0
  %t63 = insertvalue { { i64, [1 x i64] }, i32 } %t61, i32 %t57, 1
  %t64 = getelementptr { i64, [5 x i64] }, ptr %t58, i32 0, i32 1
  store { { i64, [1 x i64] }, i32 } %t63, ptr %t64
  %t65 = load { i64, [5 x i64] }, ptr %t58
  %t66 = load i32, ptr %l4, !tbaa !23
  %t68 = insertvalue { { i64, [5 x i64] }, i32 } undef, { i64, [5 x i64] } %t65, 0
  %t70 = insertvalue { { i64, [5 x i64] }, i32 } %t68, i32 %t66, 1
  store { { i64, [5 x i64] }, i32 } %t70, ptr %rv
  br label %ret
ret:
  %rr = load { { i64, [5 x i64] }, i32 }, ptr %rv
  ret { { i64, [5 x i64] }, i32 } %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2einner(ptr %v0, ptr %v1, ptr %a0, %"compiler/lower:pl" %a1, i32 %a2, { i64, [1 x i64] } %a3, %"compiler/source:Span" %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/lower:pl"
  %l2 = alloca i32
  %l3 = alloca { i64, [1 x i64] }
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca i32
  %l12 = alloca i32
  %l15 = alloca i1
  %l16 = alloca ptr
  %l17 = alloca %"compiler/source:Span"
  %l18 = alloca { i64, [1 x i64] }
  %l19 = alloca i32
  %l20 = alloca ptr
  %l21 = alloca i32
  %l24 = alloca %"compiler/mir:Place"
  %l28 = alloca { i64, [4 x i64] }
  %l33 = alloca i1
  %l34 = alloca i1
  %l37 = alloca i1
  %l39 = alloca ptr
  %l40 = alloca %"compiler/source:Span"
  %l41 = alloca { i64, [1 x i64] }
  %l42 = alloca i32
  %l43 = alloca ptr
  %l44 = alloca i32
  %l47 = alloca %"compiler/mir:Place"
  %l51 = alloca { i64, [4 x i64] }
  %l56 = alloca i1
  %l60 = alloca i1
  %l64 = alloca i1
  %l68 = alloca i1
  %l70 = alloca ptr
  %l71 = alloca %"compiler/source:Span"
  %l72 = alloca { i64, [1 x i64] }
  %l73 = alloca i32
  %l74 = alloca ptr
  %l75 = alloca i32
  %l78 = alloca %"compiler/mir:Place"
  %l82 = alloca { i64, [4 x i64] }
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %t28 = alloca { i64, [4 x i64] }, align 8
  %t34 = alloca { i64, [15 x i64] }, align 8
  %t46 = alloca { i64, [21 x i64] }, align 8
  %t87 = alloca { i64, [4 x i64] }, align 8
  %t93 = alloca { i64, [15 x i64] }, align 8
  %t105 = alloca { i64, [21 x i64] }, align 8
  %t160 = alloca { i64, [4 x i64] }, align 8
  %t166 = alloca { i64, [15 x i64] }, align 8
  %t178 = alloca { i64, [21 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/lower:pl" %a1, ptr %l1
  store i32 %a2, ptr %l2
  store { i64, [1 x i64] } %a3, ptr %l3
  store %"compiler/source:Span" %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l5, !tbaa !29
  %t6 = load ptr, ptr %l5, !tbaa !29
  %t7 = load i32, ptr %l2, !tbaa !23
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t6, i32 %t7)
  store i32 %t10, ptr %l12
  br label %bb1
bb1:
  %t11 = load i32, ptr %l12, !tbaa !23
  store i32 %t11, ptr %l6, !tbaa !23
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load i32, ptr %l2, !tbaa !23
  %t16 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eisChar(ptr %v0, ptr %t12, i32 %t13)
  store i1 %t16, ptr %l15
  br label %bb2
bb2:
  %t17 = load i1, ptr %l15, !tbaa !21
  br i1 %t17, label %bb3, label %bb4
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t18 = load ptr, ptr %l0, !tbaa !29
  store ptr %t18, ptr %l16, !tbaa !29
  %t19 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t19, ptr %l17
  %t20 = load { i64, [1 x i64] }, ptr %l3
  store { i64, [1 x i64] } %t20, ptr %l18
  store i32 3, ptr %l19
  %t21 = load ptr, ptr %l0, !tbaa !29
  store ptr %t21, ptr %l20, !tbaa !29
  %t22 = load i32, ptr %l2, !tbaa !23
  store i32 %t22, ptr %l21, !tbaa !23
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load %"compiler/lower:pl", ptr %l1
  %t27 = call %"compiler/mir:Place" @compiler_2flower_2ecompiler_2flower_3alowering_2emk(ptr %v0, ptr %v1, ptr %t23, %"compiler/lower:pl" %t24)
  store %"compiler/mir:Place" %t27, ptr %l24
  br label %bb5
bb4:
  br label %bb8
bb5:
  store { i64, [4 x i64] } zeroinitializer, ptr %t28
  %t29 = getelementptr { i64, [4 x i64] }, ptr %t28, i32 0, i32 0
  store i64 1, ptr %t29
  %t30 = load %"compiler/mir:Place", ptr %l24
  %t31 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t30, 0
  %t32 = getelementptr { i64, [4 x i64] }, ptr %t28, i32 0, i32 1
  store { %"compiler/mir:Place" } %t31, ptr %t32
  %t33 = load { i64, [4 x i64] }, ptr %t28
  store { i64, [15 x i64] } zeroinitializer, ptr %t34
  %t35 = getelementptr { i64, [15 x i64] }, ptr %t34, i32 0, i32 0
  store i64 0, ptr %t35
  %t37 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t33, 0
  %t38 = getelementptr { i64, [15 x i64] }, ptr %t34, i32 0, i32 1
  store { { i64, [4 x i64] } } %t37, ptr %t38
  %t39 = load { i64, [15 x i64] }, ptr %t34
  %t40 = load %"compiler/source:Span", ptr %l4
  %t41 = load ptr, ptr %l20, !tbaa !29
  %t42 = load i32, ptr %l21, !tbaa !23
  %t45 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %t41, i32 %t42, { i64, [15 x i64] } %t39, %"compiler/source:Span" %t40)
  store { i64, [4 x i64] } %t45, ptr %l28
  br label %bb6
bb6:
  store { i64, [21 x i64] } zeroinitializer, ptr %t46
  %t47 = getelementptr { i64, [21 x i64] }, ptr %t46, i32 0, i32 0
  store i64 9, ptr %t47
  %t48 = load %"compiler/source:Span", ptr %l17
  %t49 = insertvalue { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } undef, %"compiler/source:Span" %t48, 0
  %t50 = load { i64, [1 x i64] }, ptr %l18
  %t51 = insertvalue { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } %t49, { i64, [1 x i64] } %t50, 1
  %t52 = load i32, ptr %l19
  %t53 = insertvalue { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } %t51, i32 %t52, 2
  %t54 = load { i64, [4 x i64] }, ptr %l28
  %t55 = insertvalue { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } %t53, { i64, [4 x i64] } %t54, 3
  %t56 = getelementptr { i64, [21 x i64] }, ptr %t46, i32 0, i32 1
  store { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } %t55, ptr %t56
  %t57 = load { i64, [21 x i64] }, ptr %t46
  %t59 = call ptr @__olang_scope_alloc_a(ptr %s1, i64 176, i64 8)
  store { i64, [21 x i64] } %t57, ptr %t59
  %t60 = load ptr, ptr %l16, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s1, ptr %t60, ptr %t59)
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s1)
  br label %ret
bb8:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t63 = load i32, ptr %l2, !tbaa !23
  %t66 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eisText(ptr %v0, ptr %t62, i32 %t63)
  store i1 %t66, ptr %l33
  br label %bb9
bb9:
  %t67 = load i1, ptr %l33, !tbaa !21
  br i1 %t67, label %bb10, label %bb11
bb10:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t69 = load i32, ptr %l2, !tbaa !23
  %t72 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2ehasStr(ptr %v0, ptr %t68, i32 %t69)
  store i1 %t72, ptr %l37
  br label %bb12
bb11:
  store i1 false, ptr %l34, !tbaa !21
  br label %bb13
bb12:
  %t73 = load i1, ptr %l37, !tbaa !21
  %t74 = xor i1 %t73, true
  store i1 %t74, ptr %l34, !tbaa !21
  br label %bb13
bb13:
  %t76 = load i1, ptr %l34, !tbaa !21
  br i1 %t76, label %bb14, label %bb15
bb14:
  store %olang.scope zeroinitializer, ptr %s2
  %t77 = load ptr, ptr %l0, !tbaa !29
  store ptr %t77, ptr %l39, !tbaa !29
  %t78 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t78, ptr %l40
  %t79 = load { i64, [1 x i64] }, ptr %l3
  store { i64, [1 x i64] } %t79, ptr %l41
  store i32 1, ptr %l42
  %t80 = load ptr, ptr %l0, !tbaa !29
  store ptr %t80, ptr %l43, !tbaa !29
  %t81 = load i32, ptr %l2, !tbaa !23
  store i32 %t81, ptr %l44, !tbaa !23
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t83 = load %"compiler/lower:pl", ptr %l1
  %t86 = call %"compiler/mir:Place" @compiler_2flower_2ecompiler_2flower_3alowering_2emk(ptr %v0, ptr %v1, ptr %t82, %"compiler/lower:pl" %t83)
  store %"compiler/mir:Place" %t86, ptr %l47
  br label %bb16
bb15:
  br label %bb19
bb16:
  store { i64, [4 x i64] } zeroinitializer, ptr %t87
  %t88 = getelementptr { i64, [4 x i64] }, ptr %t87, i32 0, i32 0
  store i64 1, ptr %t88
  %t89 = load %"compiler/mir:Place", ptr %l47
  %t90 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t89, 0
  %t91 = getelementptr { i64, [4 x i64] }, ptr %t87, i32 0, i32 1
  store { %"compiler/mir:Place" } %t90, ptr %t91
  %t92 = load { i64, [4 x i64] }, ptr %t87
  store { i64, [15 x i64] } zeroinitializer, ptr %t93
  %t94 = getelementptr { i64, [15 x i64] }, ptr %t93, i32 0, i32 0
  store i64 0, ptr %t94
  %t96 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t92, 0
  %t97 = getelementptr { i64, [15 x i64] }, ptr %t93, i32 0, i32 1
  store { { i64, [4 x i64] } } %t96, ptr %t97
  %t98 = load { i64, [15 x i64] }, ptr %t93
  %t99 = load %"compiler/source:Span", ptr %l4
  %t100 = load ptr, ptr %l43, !tbaa !29
  %t101 = load i32, ptr %l44, !tbaa !23
  %t104 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %t100, i32 %t101, { i64, [15 x i64] } %t98, %"compiler/source:Span" %t99)
  store { i64, [4 x i64] } %t104, ptr %l51
  br label %bb17
bb17:
  store { i64, [21 x i64] } zeroinitializer, ptr %t105
  %t106 = getelementptr { i64, [21 x i64] }, ptr %t105, i32 0, i32 0
  store i64 9, ptr %t106
  %t107 = load %"compiler/source:Span", ptr %l40
  %t108 = insertvalue { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } undef, %"compiler/source:Span" %t107, 0
  %t109 = load { i64, [1 x i64] }, ptr %l41
  %t110 = insertvalue { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } %t108, { i64, [1 x i64] } %t109, 1
  %t111 = load i32, ptr %l42
  %t112 = insertvalue { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } %t110, i32 %t111, 2
  %t113 = load { i64, [4 x i64] }, ptr %l51
  %t114 = insertvalue { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } %t112, { i64, [4 x i64] } %t113, 3
  %t115 = getelementptr { i64, [21 x i64] }, ptr %t105, i32 0, i32 1
  store { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } %t114, ptr %t115
  %t116 = load { i64, [21 x i64] }, ptr %t105
  %t118 = call ptr @__olang_scope_alloc_a(ptr %s2, i64 176, i64 8)
  store { i64, [21 x i64] } %t116, ptr %t118
  %t119 = load ptr, ptr %l39, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s2, ptr %t119, ptr %t118)
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s2)
  br label %ret
bb19:
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t122 = load i32, ptr %l2, !tbaa !23
  %t125 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2escalar(ptr %v0, ptr %t121, i32 %t122)
  store i1 %t125, ptr %l56
  br label %bb20
bb20:
  %t126 = load i1, ptr %l56, !tbaa !21
  br i1 %t126, label %bb21, label %bb22
bb21:
  store %olang.scope zeroinitializer, ptr %s3
  store i32 7, ptr %l7
  %t128 = load ptr, ptr %l5, !tbaa !29
  %t129 = load i32, ptr %l6, !tbaa !23
  %t132 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %t128, i32 %t129)
  store i1 %t132, ptr %l60
  br label %bb23
bb22:
  br label %bb38
bb23:
  %t133 = load i1, ptr %l60, !tbaa !21
  br i1 %t133, label %bb24, label %bb25
bb24:
  store i32 5, ptr %l7
  br label %bb34
bb25:
  %t135 = load ptr, ptr %l5, !tbaa !29
  %t136 = load i32, ptr %l6, !tbaa !23
  %t139 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %t135, i32 %t136)
  store i1 %t139, ptr %l64
  br label %bb26
bb26:
  %t140 = load i1, ptr %l64, !tbaa !21
  br i1 %t140, label %bb27, label %bb28
bb27:
  store i32 4, ptr %l7
  br label %bb33
bb28:
  %t142 = load ptr, ptr %l5, !tbaa !29
  %t143 = load i32, ptr %l6, !tbaa !23
  %t146 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %t142, i32 %t143)
  store i1 %t146, ptr %l68
  br label %bb29
bb29:
  %t147 = load i1, ptr %l68, !tbaa !21
  br i1 %t147, label %bb30, label %bb31
bb30:
  store i32 6, ptr %l7
  br label %bb32
bb31:
  br label %bb32
bb32:
  br label %bb33
bb33:
  br label %bb34
bb34:
  %t149 = load ptr, ptr %l0, !tbaa !29
  store ptr %t149, ptr %l70, !tbaa !29
  %t150 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t150, ptr %l71
  %t151 = load { i64, [1 x i64] }, ptr %l3
  store { i64, [1 x i64] } %t151, ptr %l72
  %t152 = load i32, ptr %l7
  store i32 %t152, ptr %l73
  %t153 = load ptr, ptr %l0, !tbaa !29
  store ptr %t153, ptr %l74, !tbaa !29
  %t154 = load i32, ptr %l2, !tbaa !23
  store i32 %t154, ptr %l75, !tbaa !23
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t156 = load %"compiler/lower:pl", ptr %l1
  %t159 = call %"compiler/mir:Place" @compiler_2flower_2ecompiler_2flower_3alowering_2emk(ptr %v0, ptr %v1, ptr %t155, %"compiler/lower:pl" %t156)
  store %"compiler/mir:Place" %t159, ptr %l78
  br label %bb35
bb35:
  store { i64, [4 x i64] } zeroinitializer, ptr %t160
  %t161 = getelementptr { i64, [4 x i64] }, ptr %t160, i32 0, i32 0
  store i64 1, ptr %t161
  %t162 = load %"compiler/mir:Place", ptr %l78
  %t163 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t162, 0
  %t164 = getelementptr { i64, [4 x i64] }, ptr %t160, i32 0, i32 1
  store { %"compiler/mir:Place" } %t163, ptr %t164
  %t165 = load { i64, [4 x i64] }, ptr %t160
  store { i64, [15 x i64] } zeroinitializer, ptr %t166
  %t167 = getelementptr { i64, [15 x i64] }, ptr %t166, i32 0, i32 0
  store i64 0, ptr %t167
  %t169 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t165, 0
  %t170 = getelementptr { i64, [15 x i64] }, ptr %t166, i32 0, i32 1
  store { { i64, [4 x i64] } } %t169, ptr %t170
  %t171 = load { i64, [15 x i64] }, ptr %t166
  %t172 = load %"compiler/source:Span", ptr %l4
  %t173 = load ptr, ptr %l74, !tbaa !29
  %t174 = load i32, ptr %l75, !tbaa !23
  %t177 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %t173, i32 %t174, { i64, [15 x i64] } %t171, %"compiler/source:Span" %t172)
  store { i64, [4 x i64] } %t177, ptr %l82
  br label %bb36
bb36:
  store { i64, [21 x i64] } zeroinitializer, ptr %t178
  %t179 = getelementptr { i64, [21 x i64] }, ptr %t178, i32 0, i32 0
  store i64 9, ptr %t179
  %t180 = load %"compiler/source:Span", ptr %l71
  %t181 = insertvalue { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } undef, %"compiler/source:Span" %t180, 0
  %t182 = load { i64, [1 x i64] }, ptr %l72
  %t183 = insertvalue { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } %t181, { i64, [1 x i64] } %t182, 1
  %t184 = load i32, ptr %l73
  %t185 = insertvalue { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } %t183, i32 %t184, 2
  %t186 = load { i64, [4 x i64] }, ptr %l82
  %t187 = insertvalue { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } %t185, { i64, [4 x i64] } %t186, 3
  %t188 = getelementptr { i64, [21 x i64] }, ptr %t178, i32 0, i32 1
  store { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } %t187, ptr %t188
  %t189 = load { i64, [21 x i64] }, ptr %t178
  %t191 = call ptr @__olang_scope_alloc_a(ptr %s3, i64 176, i64 8)
  store { i64, [21 x i64] } %t189, ptr %t191
  %t192 = load ptr, ptr %l70, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s3, ptr %t192, ptr %t191)
  br label %bb37
bb37:
  call void @__olang_scope_close(ptr %s3)
  br label %ret
bb38:
  %t194 = load ptr, ptr %l0, !tbaa !29
  %t195 = load %"compiler/lower:pl", ptr %l1
  %t196 = load i32, ptr %l2, !tbaa !23
  %t197 = load { i64, [1 x i64] }, ptr %l3
  %t198 = load %"compiler/source:Span", ptr %l4
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2erenderAt(ptr %v0, ptr %v1, ptr %t194, %"compiler/lower:pl" %t195, i32 %t196, { i64, [1 x i64] } %t197, %"compiler/source:Span" %t198, i1 false)
  br label %bb39
bb39:
  br label %ret
ret:
  ret void
}

define dso_local { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %a0, i32 %a1, { i64, [15 x i64] } %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca i32
  %l8 = alloca i32
  %l9 = alloca ptr
  %l10 = alloca %"compiler/source:Span"
  %l12 = alloca %"compiler/mir:Place"
  %l17 = alloca %"compiler/mir:Place"
  %s0 = alloca %olang.scope
  %rv = alloca { i64, [4 x i64] }
  %t15 = alloca { i64, [21 x i64] }, align 8
  %t32 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = load %"compiler/source:Span", ptr %l3
  %t7 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2etemp(ptr %v0, ptr %t1, i32 %a1, %"compiler/source:Span" %t3)
  store i32 %t7, ptr %l8
  br label %bb1
bb1:
  %t8 = load i32, ptr %l8, !tbaa !23
  store i32 %t8, ptr %l4, !tbaa !23
  %t9 = load ptr, ptr %l0, !tbaa !29
  store ptr %t9, ptr %l9, !tbaa !29
  %t10 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t10, ptr %l10
  %t11 = load i32, ptr %l4, !tbaa !23
  %t13 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t11)
  store %"compiler/mir:Place" %t13, ptr %l12
  br label %bb2
bb2:
  store { i64, [21 x i64] } zeroinitializer, ptr %t15
  %t16 = getelementptr { i64, [21 x i64] }, ptr %t15, i32 0, i32 0
  store i64 0, ptr %t16
  %t17 = load %"compiler/source:Span", ptr %l10
  %t18 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t17, 0
  %t19 = load %"compiler/mir:Place", ptr %l12
  %t20 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t18, %"compiler/mir:Place" %t19, 1
  %t22 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t20, { i64, [15 x i64] } %a2, 2
  %t23 = getelementptr { i64, [21 x i64] }, ptr %t15, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t22, ptr %t23
  %t24 = load { i64, [21 x i64] }, ptr %t15
  %t26 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t24, ptr %t26
  %t27 = load ptr, ptr %l9, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s0, ptr %t27, ptr %t26)
  br label %bb3
bb3:
  %t29 = load i32, ptr %l4, !tbaa !23
  %t31 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t29)
  store %"compiler/mir:Place" %t31, ptr %l17
  br label %bb4
bb4:
  store { i64, [4 x i64] } zeroinitializer, ptr %t32
  %t33 = getelementptr { i64, [4 x i64] }, ptr %t32, i32 0, i32 0
  store i64 1, ptr %t33
  %t34 = load %"compiler/mir:Place", ptr %l17
  %t35 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t34, 0
  %t36 = getelementptr { i64, [4 x i64] }, ptr %t32, i32 0, i32 1
  store { %"compiler/mir:Place" } %t35, ptr %t36
  %t37 = load { i64, [4 x i64] }, ptr %t32
  call void @__olang_scope_close(ptr %s0)
  store { i64, [4 x i64] } %t37, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eisChar(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l16 = alloca i64
  %l19 = alloca i64
  %l37 = alloca ptr
  %l38 = alloca i32
  %l41 = alloca i32
  %l42 = alloca i1
  %l46 = alloca i32
  %l49 = alloca i1
  %l50 = alloca ptr
  %l53 = alloca i32
  %l54 = alloca i32
  %l57 = alloca i1
  %l60 = alloca i1
  %l65 = alloca i32
  %s2 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  store i32 %a1, ptr %l3, !tbaa !23
  store i64 0, ptr %l4, !tbaa !24
  store i64 16, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t8 = load i64, ptr %l5, !tbaa !24
  %t9 = load i64, ptr %l4, !tbaa !24
  %t12 = icmp sgt i64 %t8, %t9
  br i1 %t12, label %bb1, label %bb2
bb1:
  %t14 = load i64, ptr %l6, !tbaa !24
  %t16 = icmp sgt i64 %t14, 0
  br i1 %t16, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l16, !tbaa !24
  br label %bb6
bb3:
  %t18 = load i64, ptr %l5, !tbaa !24
  %t19 = load i64, ptr %l4, !tbaa !24
  %t22 = sub i64 %t18, %t19
  %t23 = load i64, ptr %l6, !tbaa !24
  %t26 = add i64 %t22, %t23
  %t28 = sub i64 %t26, 1
  %t29 = load i64, ptr %l6, !tbaa !24
  %t32 = sdiv i64 %t28, %t29
  store i64 %t32, ptr %l19, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l19, !tbaa !24
  br label %bb5
bb5:
  %t34 = load i64, ptr %l19, !tbaa !24
  store i64 %t34, ptr %l16, !tbaa !24
  br label %bb6
bb6:
  %t35 = load i64, ptr %l16, !tbaa !24
  store i64 %t35, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t36 = load i64, ptr %l8, !tbaa !24
  %t37 = load i64, ptr %l7, !tbaa !24
  %t40 = icmp slt i64 %t36, %t37
  %t42 = xor i1 %t40, true
  br i1 %t42, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb31
bb9:
  br label %bb10
bb10:
  %t44 = load i64, ptr %l4, !tbaa !24
  %t45 = load i64, ptr %l8, !tbaa !24
  %t46 = load i64, ptr %l6, !tbaa !24
  %t49 = mul i64 %t45, %t46
  %t52 = add i64 %t44, %t49
  store i64 %t52, ptr %l9, !tbaa !24
  %t54 = load ptr, ptr %l2, !tbaa !29
  store ptr %t54, ptr %l37, !tbaa !29
  %t55 = load i32, ptr %l3, !tbaa !23
  store i32 %t55, ptr %l38, !tbaa !23
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/lower:lowering", ptr %t56, i32 0, i32 0
  %t59 = load ptr, ptr %t58, !tbaa !29
  %t61 = call i32 @compiler_2flower_2ecompiler_2flower_3aLowerer_2echar(ptr %v0, ptr %t59)
  store i32 %t61, ptr %l41
  br label %bb11
bb11:
  %t62 = load ptr, ptr %l37, !tbaa !29
  %t63 = load i32, ptr %l38, !tbaa !23
  %t64 = load i32, ptr %l41, !tbaa !23
  %t65 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t62, i32 %t63, i32 %t64)
  store i1 %t65, ptr %l42
  br label %bb12
bb12:
  %t66 = load i1, ptr %l42, !tbaa !21
  br i1 %t66, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s2)
  store i1 true, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  %t68 = load ptr, ptr %l2, !tbaa !29
  %t69 = load i32, ptr %l3, !tbaa !23
  %t72 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t68, i32 %t69)
  store i32 %t72, ptr %l46
  br label %bb16
bb16:
  %t73 = load i32, ptr %l46
  %t75 = trunc i64 18 to i32
  %t76 = icmp eq i32 %t73, %t75
  br i1 %t76, label %bb17, label %bb18
bb17:
  %t78 = load ptr, ptr %l2, !tbaa !29
  store ptr %t78, ptr %l50, !tbaa !29
  %t79 = load ptr, ptr %l2, !tbaa !29
  %t80 = load i32, ptr %l3, !tbaa !23
  %t83 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t79, i32 %t80)
  store i32 %t83, ptr %l53
  br label %bb19
bb18:
  store i1 false, ptr %l49, !tbaa !21
  br label %bb21
bb19:
  %t84 = load ptr, ptr %l50, !tbaa !29
  %t85 = load i32, ptr %l53, !tbaa !23
  %t86 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t84, i32 %t85)
  store i32 %t86, ptr %l54
  br label %bb20
bb20:
  %t87 = load i32, ptr %l54
  %t89 = trunc i64 4 to i32
  %t90 = icmp eq i32 %t87, %t89
  store i1 %t90, ptr %l49, !tbaa !21
  br label %bb21
bb21:
  %t92 = load i1, ptr %l49, !tbaa !21
  br i1 %t92, label %bb22, label %bb23
bb22:
  %t93 = load ptr, ptr %l2, !tbaa !29
  %t94 = load i32, ptr %l3, !tbaa !23
  %t97 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %t93, i32 %t94)
  store i1 %t97, ptr %l60
  br label %bb24
bb23:
  store i1 false, ptr %l57, !tbaa !21
  br label %bb25
bb24:
  %t98 = load i1, ptr %l60, !tbaa !21
  store i1 %t98, ptr %l57, !tbaa !21
  br label %bb25
bb25:
  %t99 = load i1, ptr %l57, !tbaa !21
  %t100 = xor i1 %t99, true
  br i1 %t100, label %bb26, label %bb27
bb26:
  call void @__olang_scope_close(ptr %s2)
  store i1 false, ptr %rv
  br label %ret
bb27:
  br label %bb28
bb28:
  %t103 = load ptr, ptr %l2, !tbaa !29
  %t104 = load i32, ptr %l3, !tbaa !23
  %t107 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %t103, i32 %t104)
  store i32 %t107, ptr %l65
  br label %bb29
bb29:
  %t108 = load i32, ptr %l65, !tbaa !23
  store i32 %t108, ptr %l3, !tbaa !23
  call void @__olang_scope_close(ptr %s2)
  br label %bb30
bb30:
  %t109 = load i64, ptr %l8, !tbaa !24
  %t111 = add i64 %t109, 1
  store i64 %t111, ptr %l8, !tbaa !24
  br label %bb7
bb31:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2flower_2ecompiler_2flower_3alowering_2eitems(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %lp3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l13 = alloca { i64, ptr }
  %l15 = alloca i64
  %l24 = alloca i64
  %l27 = alloca i64
  %l46 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/lower:lowering", ptr %a0, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t8 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t4, i32 %a1)
  store { i64, ptr } %t8, ptr %l13
  br label %bb1
bb1:
  %t9 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t9, ptr %l2, !tbaa !27
  %t10 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l15, !tbaa !24
  %t13 = load i64, ptr %l15, !tbaa !24
  %t14 = icmp sge i64 %t13, 0
  br i1 %t14, label %bb2, label %bb3
bb2:
  %t16 = load i64, ptr %l15, !tbaa !24
  %t17 = icmp sle i64 %t16, 2305843009213693951
  br i1 %t17, label %bb4, label %bb5
bb3:
  call void @__olang_check_failed(ptr @olang_loc_fe6f132f471090d8_e27fa787bcbe9484)
  unreachable
bb4:
  %t19 = load i64, ptr %l15, !tbaa !24
  %t20 = mul i64 %t19, 4
  %t21 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t20)
  %t22 = insertvalue { i64, ptr } undef, i64 %t19, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t21, 1
  %t24 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t24, ptr %lp3
  %t26 = load ptr, ptr %lp3
  store { i64, ptr } %t23, ptr %t26, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t27 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t27, 0
  store i64 %t29, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t31 = load i64, ptr %l5, !tbaa !24
  %t32 = load i64, ptr %l4, !tbaa !24
  %t35 = icmp sgt i64 %t31, %t32
  br i1 %t35, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_fe6f132f471090d8_e27fa787bcbe9484)
  unreachable
bb6:
  %t37 = load i64, ptr %l6, !tbaa !24
  %t39 = icmp sgt i64 %t37, 0
  br i1 %t39, label %bb8, label %bb9
bb7:
  store i64 0, ptr %l24, !tbaa !24
  br label %bb11
bb8:
  %t41 = load i64, ptr %l5, !tbaa !24
  %t42 = load i64, ptr %l4, !tbaa !24
  %t45 = sub i64 %t41, %t42
  %t46 = load i64, ptr %l6, !tbaa !24
  %t49 = add i64 %t45, %t46
  %t51 = sub i64 %t49, 1
  %t52 = load i64, ptr %l6, !tbaa !24
  %t55 = sdiv i64 %t51, %t52
  store i64 %t55, ptr %l27, !tbaa !24
  br label %bb10
bb9:
  store i64 0, ptr %l27, !tbaa !24
  br label %bb10
bb10:
  %t57 = load i64, ptr %l27, !tbaa !24
  store i64 %t57, ptr %l24, !tbaa !24
  br label %bb11
bb11:
  %t58 = load i64, ptr %l24, !tbaa !24
  store i64 %t58, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb12
bb12:
  store %olang.scope zeroinitializer, ptr %s2
  %t59 = load i64, ptr %l8, !tbaa !24
  %t60 = load i64, ptr %l7, !tbaa !24
  %t63 = icmp slt i64 %t59, %t60
  %t65 = xor i1 %t63, true
  br i1 %t65, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s2)
  br label %bb17
bb14:
  br label %bb15
bb15:
  %t67 = load i64, ptr %l4, !tbaa !24
  %t68 = load i64, ptr %l8, !tbaa !24
  %t69 = load i64, ptr %l6, !tbaa !24
  %t72 = mul i64 %t68, %t69
  %t75 = add i64 %t67, %t72
  store i64 %t75, ptr %l9, !tbaa !24
  %t77 = load i64, ptr %l9, !tbaa !24
  %t78 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t78, ptr %l46, !tbaa !27
  %t79 = load i64, ptr %l9, !tbaa !24
  %t81 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !27
  %t83 = getelementptr i32, ptr %t82, i64 %t79
  %t84 = load i32, ptr %t83, !tbaa !33
  %t86 = load ptr, ptr %lp3
  %t88 = getelementptr { i64, ptr }, ptr %t86, i32 0, i32 1
  %t89 = load ptr, ptr %t88, !tbaa !27
  %t90 = getelementptr i32, ptr %t89, i64 %t77
  store i32 %t84, ptr %t90, !tbaa !33
  call void @__olang_scope_close(ptr %s2)
  br label %bb16
bb16:
  %t91 = load i64, ptr %l8, !tbaa !24
  %t93 = add i64 %t91, 1
  store i64 %t93, ptr %l8, !tbaa !24
  br label %bb12
bb17:
  %t95 = load ptr, ptr %lp3
  %t96 = load { i64, ptr }, ptr %t95, !tbaa !27
  store { i64, ptr } %t96, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2ejoin(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l13 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l17 = alloca i32
  %l20 = alloca i64
  %l23 = alloca %"compiler/lower:tryCtx"
  %l33 = alloca { i64, ptr }
  %l51 = alloca ptr
  %l53 = alloca %"compiler/lower:level"
  %l64 = alloca { i64, ptr }
  %l72 = alloca %"compiler/lower:tryCtx"
  %l75 = alloca %"compiler/lower:tryCtx"
  %l76 = alloca i32
  %l77 = alloca i32
  %l80 = alloca i32
  %l81 = alloca i32
  %l82 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t4 = getelementptr %"compiler/typed:Join", ptr %t2, i32 0, i32 0
  %t5 = load ptr, ptr %t4, !tbaa !29
  %t8 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2ejoinErrors(ptr %v0, ptr %v1, ptr %t1, ptr %t5)
  store i32 %t8, ptr %l17
  br label %bb1
bb1:
  %t9 = load i32, ptr %l17, !tbaa !23
  store i32 %t9, ptr %l3, !tbaa !23
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/lower:lowering", ptr %t10, i32 0, i32 9
  %t14 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3alevel_3e_2eLen_3ccompiler_2flower_3alevel_3e(ptr %v0, ptr %t12)
  store i64 %t14, ptr %l20
  br label %bb2
bb2:
  %t15 = load ptr, ptr %l2, !tbaa !29
  %t17 = getelementptr %"compiler/typed:Join", ptr %t15, i32 0, i32 2
  %t18 = load { i64, ptr }, ptr %t17, !tbaa !27
  %t19 = load i64, ptr %l20, !tbaa !24
  %t21 = call %"compiler/lower:tryCtx" @compiler_2flower_3atryCtx_2ector(ptr %v1, ptr %v0, i64 %t19, { i64, ptr } %t18, i1 false, i1 false)
  store %"compiler/lower:tryCtx" %t21, ptr %l23
  br label %bb3
bb3:
  %t22 = load %"compiler/lower:tryCtx", ptr %l23
  %t23 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store %"compiler/lower:tryCtx" %t22, ptr %t23
  store ptr %t23, ptr %l4, !tbaa !29
  %t25 = load ptr, ptr %l2, !tbaa !29
  %t27 = getelementptr %"compiler/typed:Join", ptr %t25, i32 0, i32 2
  %t28 = load { i64, ptr }, ptr %t27, !tbaa !27
  store { i64, ptr } %t28, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t30 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t30, 0
  store i64 %t32, ptr %l7, !tbaa !24
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s2
  %t34 = load i64, ptr %l6, !tbaa !24
  %t35 = load i64, ptr %l7, !tbaa !24
  %t38 = icmp slt i64 %t34, %t35
  %t40 = xor i1 %t38, true
  br i1 %t40, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s2)
  br label %bb10
bb6:
  br label %bb7
bb7:
  %t42 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t42, ptr %l33, !tbaa !27
  %t43 = load i64, ptr %l6, !tbaa !24
  %t45 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !27
  %t47 = getelementptr ptr, ptr %t46, i64 %t43
  %t48 = load ptr, ptr %t47, !tbaa !39
  store ptr %t48, ptr %l8, !tbaa !29
  %t50 = load ptr, ptr %l4, !tbaa !29
  %t52 = getelementptr %"compiler/lower:tryCtx", ptr %t50, i32 0, i32 4
  %t53 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aBlockId_3e_2ePush_3ccompiler_2fmir_3aBlockId_3e(ptr %v0, ptr %t52, i32 %t53)
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb9
bb9:
  %t56 = load i64, ptr %l6, !tbaa !24
  %t58 = add i64 %t56, 1
  store i64 %t58, ptr %l6, !tbaa !24
  br label %bb4
bb10:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t61 = load ptr, ptr %l2, !tbaa !29
  %t63 = getelementptr %"compiler/typed:Join", ptr %t61, i32 0, i32 0
  %t64 = load ptr, ptr %t63, !tbaa !29
  %t65 = load i32, ptr %l3, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eopenBlock(ptr %v0, ptr %v1, ptr %t60, ptr %t64, i32 3, i32 %t65)
  br label %bb11
bb11:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/lower:lowering", ptr %t70, i32 0, i32 16
  %t73 = load ptr, ptr %l4, !tbaa !29
  %t75 = load %"compiler/lower:tryCtx", ptr %t73
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3atryCtx_3e_2ePush_3ccompiler_2flower_3atryCtx_3e(ptr %v0, ptr %v0, ptr %t72, %"compiler/lower:tryCtx" %t75)
  br label %bb12
bb12:
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t80 = getelementptr %"compiler/lower:lowering", ptr %t78, i32 0, i32 17
  store ptr %t80, ptr %l51, !tbaa !29
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = call %"compiler/lower:level" @compiler_2flower_2ecompiler_2flower_3alowering_2etop(ptr %v0, ptr %t81)
  store %"compiler/lower:level" %t83, ptr %l53
  br label %bb13
bb13:
  %t84 = getelementptr %"compiler/lower:level", ptr %l53, i32 0, i32 0
  %t85 = load i32, ptr %t84, !tbaa !23
  %t86 = load ptr, ptr %l51, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeId_3e_2ePush_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t86, i32 %t85)
  br label %bb14
bb14:
  %t88 = load ptr, ptr %l2, !tbaa !29
  %t90 = getelementptr %"compiler/typed:Join", ptr %t88, i32 0, i32 0
  %t91 = load ptr, ptr %t90, !tbaa !29
  %t93 = getelementptr %"compiler/typed:Block", ptr %t91, i32 0, i32 1
  %t94 = load { i64, ptr }, ptr %t93, !tbaa !27
  store { i64, ptr } %t94, ptr %l9, !tbaa !27
  store i64 0, ptr %l10, !tbaa !24
  %t96 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t98 = extractvalue { i64, ptr } %t96, 0
  store i64 %t98, ptr %l11, !tbaa !24
  br label %bb15
bb15:
  store %olang.scope zeroinitializer, ptr %s5
  %t100 = load i64, ptr %l10, !tbaa !24
  %t101 = load i64, ptr %l11, !tbaa !24
  %t104 = icmp slt i64 %t100, %t101
  %t106 = xor i1 %t104, true
  br i1 %t106, label %bb16, label %bb17
bb16:
  call void @__olang_scope_close(ptr %s5)
  br label %bb21
bb17:
  br label %bb18
bb18:
  %t108 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t108, ptr %l64, !tbaa !27
  %t109 = load i64, ptr %l10, !tbaa !24
  %t111 = getelementptr { i64, ptr }, ptr %l64, i32 0, i32 1
  %t112 = load ptr, ptr %t111, !tbaa !27
  %t113 = getelementptr ptr, ptr %t112, i64 %t109
  %t114 = load ptr, ptr %t113, !tbaa !39
  %t116 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estmt(ptr %v0, ptr %v1, ptr %t116, ptr %t114)
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s5)
  br label %bb20
bb20:
  %t120 = load i64, ptr %l10, !tbaa !24
  %t122 = add i64 %t120, 1
  store i64 %t122, ptr %l10, !tbaa !24
  br label %bb15
bb21:
  %t124 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2ecloseBlock(ptr %v0, ptr %t124)
  br label %bb22
bb22:
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t128 = getelementptr %"compiler/lower:lowering", ptr %t126, i32 0, i32 16
  %t130 = call { i32, %"compiler/lower:tryCtx" } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3atryCtx_3e_2ePop_3ccompiler_2flower_3atryCtx_3e(ptr %v0, ptr %v0, ptr %t128)
  %t131 = extractvalue { i32, %"compiler/lower:tryCtx" } %t130, 1
  %t132 = extractvalue { i32, %"compiler/lower:tryCtx" } %t130, 0
  store i32 %t132, ptr %l76
  %t133 = icmp ne i32 %t132, 0
  br i1 %t133, label %bb24, label %ok.134
ok.134:
  store %"compiler/lower:tryCtx" %t131, ptr %l75
  br label %bb23
bb23:
  %t135 = load %"compiler/lower:tryCtx", ptr %l75
  store %"compiler/lower:tryCtx" %t135, ptr %l72
  br label %bb26
bb24:
  br label %bb25
bb25:
  br label %bb26
bb26:
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t138 = getelementptr %"compiler/lower:lowering", ptr %t136, i32 0, i32 17
  %t140 = call { i32, i32 } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeId_3e_2ePop_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t138)
  %t141 = extractvalue { i32, i32 } %t140, 1
  %t142 = extractvalue { i32, i32 } %t140, 0
  store i32 %t142, ptr %l81
  %t143 = icmp ne i32 %t142, 0
  br i1 %t143, label %bb28, label %ok.144
ok.144:
  store i32 %t141, ptr %l80
  br label %bb27
bb27:
  %t145 = load i32, ptr %l80, !tbaa !23
  store i32 %t145, ptr %l77, !tbaa !23
  br label %bb30
bb28:
  br label %bb29
bb29:
  br label %bb30
bb30:
  %t146 = load ptr, ptr @__olang_prog_scope
  %t147 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aBlockId_3e(ptr %t146)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t147, ptr %l82
  br label %bb31
bb31:
  %t148 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l82
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t148, ptr %l13
  %t149 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eleaveOpen(ptr %v0, ptr %s0, ptr %t149, ptr %l13)
  br label %bb32
bb32:
  %t152 = load ptr, ptr %l0, !tbaa !29
  %t153 = load ptr, ptr %l4, !tbaa !29
  %t155 = load %"compiler/lower:tryCtx", ptr %t153
  %t156 = load ptr, ptr %l2, !tbaa !29
  %t158 = getelementptr %"compiler/typed:Join", ptr %t156, i32 0, i32 2
  %t159 = load { i64, ptr }, ptr %t158, !tbaa !27
  %t160 = load i32, ptr @G_2ecompiler_2fmir_2eNoLocal, !tbaa !23
  %t161 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eclauses(ptr %v0, ptr %v0, ptr %v1, ptr %s0, ptr %t152, %"compiler/lower:tryCtx" %t155, { i64, ptr } %t159, i32 %t160, i32 %t161, ptr %l13)
  br label %bb33
bb33:
  %t168 = load ptr, ptr %l0, !tbaa !29
  %t169 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l13
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2epatch(ptr %v0, ptr %s0, ptr %t168, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t169)
  br label %bb34
bb34:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2ejump(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca %"compiler/lower:loopCtx"
  %l8 = alloca i64
  %l16 = alloca %"compiler/lower:loopCtx"
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 12
  %t5 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3aloopCtx_3e_2eLen_3ccompiler_2flower_3aloopCtx_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l8
  br label %bb1
bb1:
  %t6 = load i64, ptr %l8, !tbaa !24
  %t7 = sub i64 %t6, 1
  store i64 %t7, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t9 = load i64, ptr %l4, !tbaa !24
  %t11 = icmp sge i64 %t9, 0
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb17
bb4:
  br label %bb5
bb5:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/lower:lowering", ptr %t15, i32 0, i32 12
  %t18 = load i64, ptr %l4, !tbaa !24
  %t21 = call %"compiler/lower:loopCtx" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3aloopCtx_3e_2eAt_3ccompiler_2flower_3aloopCtx_3e(ptr %v0, ptr %v0, ptr %t17, i64 %t18)
  store %"compiler/lower:loopCtx" %t21, ptr %l16
  br label %bb6
bb6:
  %t22 = load %"compiler/lower:loopCtx", ptr %l16
  store %"compiler/lower:loopCtx" %t22, ptr %l5
  %t23 = getelementptr %"compiler/lower:loopCtx", ptr %l5, i32 0, i32 0
  %t24 = load i32, ptr %t23, !tbaa !23
  %t28 = icmp eq i32 %t24, %a3
  br i1 %t28, label %bb7, label %bb8
bb7:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/lower:loopCtx", ptr %l5, i32 0, i32 1
  %t32 = load i64, ptr %t31, !tbaa !24
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eleave(ptr %v0, ptr %t30, i64 %t32)
  br label %bb9
bb8:
  br label %bb15
bb9:
  %t37 = trunc i64 0 to i32
  %t38 = icmp eq i32 %a2, %t37
  br i1 %t38, label %bb10, label %bb11
bb10:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/lower:loopCtx", ptr %l5, i32 0, i32 3
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eleaveOpen(ptr %v0, ptr %v0, ptr %t40, ptr %t41)
  br label %bb12
bb11:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/lower:loopCtx", ptr %l5, i32 0, i32 4
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eleaveOpen(ptr %v0, ptr %v0, ptr %t44, ptr %t45)
  br label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb15:
  call void @__olang_scope_close(ptr %s2)
  br label %bb16
bb16:
  %t48 = load i64, ptr %l4, !tbaa !24
  %t50 = sub i64 %t48, 1
  store i64 %t50, ptr %l4, !tbaa !24
  br label %bb2
bb17:
  %t52 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2egap(ptr %v0, ptr %s0, ptr %t52, %"compiler/source:Span" %a1, { i64, ptr } { i64 38, ptr @.d16 })
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2eloop(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca %"compiler/lower:loopCtx"
  %l8 = alloca i32
  %l14 = alloca ptr
  %l16 = alloca i32
  %l19 = alloca i64
  %l20 = alloca %"compiler/lower:loopCtx"
  %l24 = alloca ptr
  %l27 = alloca i64
  %l29 = alloca %"compiler/lower:loopCtx"
  %l33 = alloca i64
  %l44 = alloca %"compiler/lower:loopCtx"
  %l47 = alloca %"compiler/lower:loopCtx"
  %l48 = alloca i32
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 3
  %t5 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t3)
  store i32 %t5, ptr %l8
  br label %bb1
bb1:
  %t6 = load i32, ptr %l8, !tbaa !23
  store i32 %t6, ptr %l4, !tbaa !23
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load i32, ptr %l4, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2egoto(ptr %v0, ptr %t7, i32 %t8)
  br label %bb2
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load i32, ptr %l4, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t11, i32 %t12)
  br label %bb3
bb3:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/lower:lowering", ptr %t15, i32 0, i32 12
  store ptr %t17, ptr %l14, !tbaa !29
  %t18 = load ptr, ptr %l2, !tbaa !29
  %t20 = getelementptr %"compiler/typed:Block", ptr %t18, i32 0, i32 0
  %t21 = load i32, ptr %t20, !tbaa !23
  store i32 %t21, ptr %l16, !tbaa !23
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/lower:lowering", ptr %t22, i32 0, i32 9
  %t26 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3alevel_3e_2eLen_3ccompiler_2flower_3alevel_3e(ptr %v0, ptr %t24)
  store i64 %t26, ptr %l19
  br label %bb4
bb4:
  %t27 = load i32, ptr %l16, !tbaa !23
  %t28 = load i64, ptr %l19, !tbaa !24
  %t29 = call %"compiler/lower:loopCtx" @compiler_2flower_3aloopCtx_2ector(ptr %v0, i32 %t27, i64 %t28)
  store %"compiler/lower:loopCtx" %t29, ptr %l20
  br label %bb5
bb5:
  %t30 = load ptr, ptr %l14, !tbaa !29
  %t31 = load %"compiler/lower:loopCtx", ptr %l20
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3aloopCtx_3e_2ePus_Hecf1f3338ace0b99f129de91c7b21562(ptr %v0, ptr %v0, ptr %t30, %"compiler/lower:loopCtx" %t31)
  br label %bb6
bb6:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t33 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eblock(ptr %v0, ptr %v1, ptr %t32, ptr %t33)
  br label %bb7
bb7:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/lower:lowering", ptr %t36, i32 0, i32 12
  store ptr %t38, ptr %l24, !tbaa !29
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/lower:lowering", ptr %t39, i32 0, i32 12
  %t43 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3aloopCtx_3e_2eLen_3ccompiler_2flower_3aloopCtx_3e(ptr %v0, ptr %t41)
  store i64 %t43, ptr %l27
  br label %bb8
bb8:
  %t44 = load i64, ptr %l27, !tbaa !24
  %t45 = sub i64 %t44, 1
  %t46 = load ptr, ptr %l24, !tbaa !29
  %t48 = call %"compiler/lower:loopCtx" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3aloopCtx_3e_2eAt_3ccompiler_2flower_3aloopCtx_3e(ptr %v0, ptr %v0, ptr %t46, i64 %t45)
  store %"compiler/lower:loopCtx" %t48, ptr %l29
  br label %bb9
bb9:
  %t49 = load %"compiler/lower:loopCtx", ptr %l29
  store %"compiler/lower:loopCtx" %t49, ptr %l5
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/lower:loopCtx", ptr %l5, i32 0, i32 4
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eleaveOpen(ptr %v0, ptr %v0, ptr %t50, ptr %t51)
  br label %bb10
bb10:
  %t54 = getelementptr %"compiler/lower:loopCtx", ptr %l5, i32 0, i32 4
  %t56 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aBlockId_3e_2eLen_3ccompiler_2fmir_3aBlockId_3e(ptr %v0, ptr %t54)
  store i64 %t56, ptr %l33
  br label %bb11
bb11:
  %t57 = load i64, ptr %l33, !tbaa !24
  %t58 = icmp sgt i64 %t57, 0
  br i1 %t58, label %bb12, label %bb13
bb12:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/lower:loopCtx", ptr %l5, i32 0, i32 4
  %t62 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t61
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2epatch(ptr %v0, ptr %v0, ptr %t60, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t62)
  br label %bb14
bb13:
  br label %bb20
bb14:
  %t65 = load ptr, ptr %l3, !tbaa !29
  %t67 = icmp eq ptr %t65, null
  %t69 = xor i1 %t67, true
  br i1 %t69, label %bb15, label %bb16
bb15:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t72 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eblock(ptr %v0, ptr %v2, ptr %t71, ptr %t72)
  br label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb18
bb18:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t76 = load i32, ptr %l4, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2egoto(ptr %v0, ptr %t75, i32 %t76)
  br label %bb19
bb19:
  br label %bb20
bb20:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/lower:lowering", ptr %t79, i32 0, i32 12
  %t83 = call { i32, %"compiler/lower:loopCtx" } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3aloopCtx_3e_2ePop_3ccompiler_2flower_3aloopCtx_3e(ptr %v0, ptr %v0, ptr %t81)
  %t84 = extractvalue { i32, %"compiler/lower:loopCtx" } %t83, 1
  %t85 = extractvalue { i32, %"compiler/lower:loopCtx" } %t83, 0
  store i32 %t85, ptr %l48
  %t86 = icmp ne i32 %t85, 0
  br i1 %t86, label %bb22, label %ok.87
ok.87:
  store %"compiler/lower:loopCtx" %t84, ptr %l47
  br label %bb21
bb21:
  %t88 = load %"compiler/lower:loopCtx", ptr %l47
  store %"compiler/lower:loopCtx" %t88, ptr %l44
  br label %bb24
bb22:
  br label %bb23
bb23:
  br label %bb24
bb24:
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t90 = getelementptr %"compiler/lower:loopCtx", ptr %l5, i32 0, i32 3
  %t91 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t90
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2epatch(ptr %v0, ptr %v0, ptr %t89, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t91)
  br label %bb25
bb25:
  br label %ret
ret:
  ret void
}

define dso_local { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2emadeAt(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l6 = alloca i1
  %l13 = alloca { i64, [1 x i64] }
  %rv = alloca { i64, [1 x i64] }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l1, !tbaa !23
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"compiler/lower:lowering", ptr %t2, i32 0, i32 20
  %t5 = load i32, ptr %t4, !tbaa !23
  %t8 = icmp eq i32 %t1, %t5
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load i32, ptr %l1, !tbaa !23
  %t12 = icmp sge i32 %t10, 0
  store i1 %t12, ptr %l6, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l6, !tbaa !21
  br label %bb3
bb3:
  %t14 = load i1, ptr %l6, !tbaa !21
  br i1 %t14, label %bb4, label %bb5
bb4:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/lower:lowering", ptr %t15, i32 0, i32 21
  %t18 = load { i64, [1 x i64] }, ptr %t17
  store { i64, [1 x i64] } %t18, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load i32, ptr %l1, !tbaa !23
  %t24 = call { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ebuilt(ptr %v0, ptr %t20, i32 %t21)
  store { i64, [1 x i64] } %t24, ptr %l13
  br label %bb7
bb7:
  %t25 = load { i64, [1 x i64] }, ptr %l13
  store { i64, [1 x i64] } %t25, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [1 x i64] }, ptr %rv
  ret { i64, [1 x i64] } %rr
}

define dso_local { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2emake(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca { i64, ptr }
  %l7 = alloca i32
  %l8 = alloca { i64, [4 x i64] }
  %l20 = alloca { i64, ptr }
  %l27 = alloca i1
  %l30 = alloca i1
  %l33 = alloca i32
  %l34 = alloca ptr
  %l35 = alloca i32
  %l36 = alloca i32
  %l38 = alloca i64
  %l42 = alloca %"compiler/mir:Range"
  %l45 = alloca { i64, [4 x i64] }
  %l46 = alloca ptr
  %l47 = alloca i32
  %l51 = alloca { i64, [1 x i64] }
  %l56 = alloca { i64, [4 x i64] }
  %l57 = alloca ptr
  %l58 = alloca i32
  %l59 = alloca i32
  %l61 = alloca i64
  %l65 = alloca %"compiler/mir:Range"
  %l68 = alloca { i64, [4 x i64] }
  %l75 = alloca { i64, [4 x i64] }
  %l82 = alloca { i64, [4 x i64] }
  %s1 = alloca %olang.scope
  %rv = alloca { i64, [4 x i64] }
  %t35 = alloca { i64, [4 x i64] }, align 8
  %t73 = alloca { i64, [15 x i64] }, align 8
  %t102 = alloca { i64, [15 x i64] }, align 8
  %t133 = alloca { i64, [15 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  store %"compiler/source:Span" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t6 = load ptr, ptr %l1, !tbaa !29
  %t8 = getelementptr %"compiler/typed:Make", ptr %t6, i32 0, i32 0
  %t9 = load i32, ptr %t8
  store i32 %t9, ptr %l5
  %t11 = load i32, ptr %l5
  %t13 = trunc i64 0 to i32
  %t14 = icmp eq i32 %t11, %t13
  br i1 %t14, label %bb1, label %bb2
bb1:
  br label %bb5
bb2:
  %t16 = load i32, ptr %l5
  %t18 = trunc i64 1 to i32
  %t19 = icmp eq i32 %t16, %t18
  br i1 %t19, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb24
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t24 = getelementptr %"compiler/typed:Make", ptr %t22, i32 0, i32 2
  %t25 = load { i64, ptr }, ptr %t24, !tbaa !27
  %t28 = call { i64, ptr } @compiler_2flower_2ecompiler_2flower_3alowering_2evals(ptr %v0, ptr %v1, ptr %s1, ptr %t21, { i64, ptr } %t25)
  store { i64, ptr } %t28, ptr %l20
  br label %bb6
bb6:
  %t29 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t29, ptr %l6, !tbaa !27
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/lower:lowering", ptr %t30, i32 0, i32 7
  %t33 = load i1, ptr %t32, !tbaa !21
  br i1 %t33, label %bb7, label %bb8
bb7:
  store { i64, [4 x i64] } zeroinitializer, ptr %t35
  %t36 = getelementptr { i64, [4 x i64] }, ptr %t35, i32 0, i32 0
  store i64 0, ptr %t36
  %t37 = load { i64, [4 x i64] }, ptr %t35
  call void @__olang_scope_close(ptr %s1)
  store { i64, [4 x i64] } %t37, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t39 = load ptr, ptr %l1, !tbaa !29
  %t41 = getelementptr %"compiler/typed:Make", ptr %t39, i32 0, i32 4
  %t42 = load i32, ptr %t41, !tbaa !23
  %t44 = icmp sge i32 %t42, 0
  br i1 %t44, label %bb10, label %bb11
bb10:
  %t46 = load ptr, ptr %l4, !tbaa !29
  %t47 = load i32, ptr %l2, !tbaa !23
  %t50 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t46, i32 %t47)
  store i1 %t50, ptr %l30
  br label %bb12
bb11:
  store i1 false, ptr %l27, !tbaa !21
  br label %bb13
bb12:
  %t51 = load i1, ptr %l30, !tbaa !21
  store i1 %t51, ptr %l27, !tbaa !21
  br label %bb13
bb13:
  %t52 = load i1, ptr %l27, !tbaa !21
  br i1 %t52, label %bb14, label %bb15
bb14:
  %t53 = load ptr, ptr %l4, !tbaa !29
  %t54 = load i32, ptr %l2, !tbaa !23
  %t57 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t53, i32 %t54)
  store i32 %t57, ptr %l33
  br label %bb16
bb15:
  br label %bb21
bb16:
  %t58 = load i32, ptr %l33, !tbaa !23
  store i32 %t58, ptr %l7, !tbaa !23
  %t59 = load ptr, ptr %l0, !tbaa !29
  store ptr %t59, ptr %l34, !tbaa !29
  %t60 = load i32, ptr %l7, !tbaa !23
  store i32 %t60, ptr %l35, !tbaa !23
  %t61 = load i32, ptr %l7, !tbaa !23
  store i32 %t61, ptr %l36, !tbaa !23
  %t62 = load ptr, ptr %l1, !tbaa !29
  %t64 = getelementptr %"compiler/typed:Make", ptr %t62, i32 0, i32 1
  %t65 = load i64, ptr %t64, !tbaa !24
  store i64 %t65, ptr %l38, !tbaa !24
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"compiler/lower:lowering", ptr %t66, i32 0, i32 3
  %t69 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t72 = call %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eArgs(ptr %v0, ptr %s1, ptr %t68, { i64, ptr } %t69)
  store %"compiler/mir:Range" %t72, ptr %l42
  br label %bb17
bb17:
  store { i64, [15 x i64] } zeroinitializer, ptr %t73
  %t74 = getelementptr { i64, [15 x i64] }, ptr %t73, i32 0, i32 0
  store i64 6, ptr %t74
  %t75 = load i32, ptr %l36, !tbaa !23
  %t76 = insertvalue { i32, i64, %"compiler/mir:Range" } undef, i32 %t75, 0
  %t77 = load i64, ptr %l38, !tbaa !24
  %t78 = insertvalue { i32, i64, %"compiler/mir:Range" } %t76, i64 %t77, 1
  %t79 = load %"compiler/mir:Range", ptr %l42
  %t80 = insertvalue { i32, i64, %"compiler/mir:Range" } %t78, %"compiler/mir:Range" %t79, 2
  %t81 = getelementptr { i64, [15 x i64] }, ptr %t73, i32 0, i32 1
  store { i32, i64, %"compiler/mir:Range" } %t80, ptr %t81
  %t82 = load { i64, [15 x i64] }, ptr %t73
  %t83 = load %"compiler/source:Span", ptr %l3
  %t84 = load ptr, ptr %l34, !tbaa !29
  %t85 = load i32, ptr %l35, !tbaa !23
  %t88 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %t84, i32 %t85, { i64, [15 x i64] } %t82, %"compiler/source:Span" %t83)
  store { i64, [4 x i64] } %t88, ptr %l45
  br label %bb18
bb18:
  %t89 = load { i64, [4 x i64] }, ptr %l45
  store { i64, [4 x i64] } %t89, ptr %l8
  %t90 = load ptr, ptr %l0, !tbaa !29
  store ptr %t90, ptr %l46, !tbaa !29
  %t91 = load i32, ptr %l2, !tbaa !23
  store i32 %t91, ptr %l47, !tbaa !23
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t93 = load ptr, ptr %l1, !tbaa !29
  %t95 = getelementptr %"compiler/typed:Make", ptr %t93, i32 0, i32 4
  %t96 = load i32, ptr %t95, !tbaa !23
  %t99 = call { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ebuilt(ptr %v0, ptr %t92, i32 %t96)
  store { i64, [1 x i64] } %t99, ptr %l51
  br label %bb19
bb19:
  %t100 = load { i64, [4 x i64] }, ptr %l8
  %t101 = load i32, ptr %l2, !tbaa !23
  store { i64, [15 x i64] } zeroinitializer, ptr %t102
  %t103 = getelementptr { i64, [15 x i64] }, ptr %t102, i32 0, i32 0
  store i64 7, ptr %t103
  %t104 = load { i64, [1 x i64] }, ptr %l51
  %t105 = insertvalue { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 } undef, { i64, [1 x i64] } %t104, 0
  %t107 = insertvalue { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 } %t105, { i64, [4 x i64] } %t100, 1
  %t109 = insertvalue { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 } %t107, i32 %t101, 2
  %t110 = getelementptr { i64, [15 x i64] }, ptr %t102, i32 0, i32 1
  store { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 } %t109, ptr %t110
  %t111 = load { i64, [15 x i64] }, ptr %t102
  %t112 = load %"compiler/source:Span", ptr %l3
  %t113 = load ptr, ptr %l46, !tbaa !29
  %t114 = load i32, ptr %l47, !tbaa !23
  %t117 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %t113, i32 %t114, { i64, [15 x i64] } %t111, %"compiler/source:Span" %t112)
  store { i64, [4 x i64] } %t117, ptr %l56
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s1)
  %t118 = load { i64, [4 x i64] }, ptr %l56
  store { i64, [4 x i64] } %t118, ptr %rv
  br label %ret
bb21:
  %t119 = load ptr, ptr %l0, !tbaa !29
  store ptr %t119, ptr %l57, !tbaa !29
  %t120 = load i32, ptr %l2, !tbaa !23
  store i32 %t120, ptr %l58, !tbaa !23
  %t121 = load i32, ptr %l2, !tbaa !23
  store i32 %t121, ptr %l59, !tbaa !23
  %t122 = load ptr, ptr %l1, !tbaa !29
  %t124 = getelementptr %"compiler/typed:Make", ptr %t122, i32 0, i32 1
  %t125 = load i64, ptr %t124, !tbaa !24
  store i64 %t125, ptr %l61, !tbaa !24
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t128 = getelementptr %"compiler/lower:lowering", ptr %t126, i32 0, i32 3
  %t129 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t132 = call %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eArgs(ptr %v0, ptr %s1, ptr %t128, { i64, ptr } %t129)
  store %"compiler/mir:Range" %t132, ptr %l65
  br label %bb22
bb22:
  store { i64, [15 x i64] } zeroinitializer, ptr %t133
  %t134 = getelementptr { i64, [15 x i64] }, ptr %t133, i32 0, i32 0
  store i64 6, ptr %t134
  %t135 = load i32, ptr %l59, !tbaa !23
  %t136 = insertvalue { i32, i64, %"compiler/mir:Range" } undef, i32 %t135, 0
  %t137 = load i64, ptr %l61, !tbaa !24
  %t138 = insertvalue { i32, i64, %"compiler/mir:Range" } %t136, i64 %t137, 1
  %t139 = load %"compiler/mir:Range", ptr %l65
  %t140 = insertvalue { i32, i64, %"compiler/mir:Range" } %t138, %"compiler/mir:Range" %t139, 2
  %t141 = getelementptr { i64, [15 x i64] }, ptr %t133, i32 0, i32 1
  store { i32, i64, %"compiler/mir:Range" } %t140, ptr %t141
  %t142 = load { i64, [15 x i64] }, ptr %t133
  %t143 = load %"compiler/source:Span", ptr %l3
  %t144 = load ptr, ptr %l57, !tbaa !29
  %t145 = load i32, ptr %l58, !tbaa !23
  %t148 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %t144, i32 %t145, { i64, [15 x i64] } %t142, %"compiler/source:Span" %t143)
  store { i64, [4 x i64] } %t148, ptr %l68
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s1)
  %t149 = load { i64, [4 x i64] }, ptr %l68
  store { i64, [4 x i64] } %t149, ptr %rv
  br label %ret
bb24:
  %t150 = load i32, ptr %l5
  %t152 = trunc i64 2 to i32
  %t153 = icmp eq i32 %t150, %t152
  br i1 %t153, label %bb25, label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb29
bb27:
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t156 = load ptr, ptr %l1, !tbaa !29
  %t157 = load i32, ptr %l2, !tbaa !23
  %t158 = load %"compiler/source:Span", ptr %l3
  %t163 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2earrayLit(ptr %v0, ptr %v1, ptr %t155, ptr %t156, i32 %t157, %"compiler/source:Span" %t158)
  store { i64, [4 x i64] } %t163, ptr %l75
  br label %bb28
bb28:
  %t164 = load { i64, [4 x i64] }, ptr %l75
  store { i64, [4 x i64] } %t164, ptr %rv
  br label %ret
bb29:
  %t165 = load i32, ptr %l5
  %t167 = trunc i64 3 to i32
  %t168 = icmp eq i32 %t165, %t167
  br i1 %t168, label %bb30, label %bb31
bb30:
  br label %bb32
bb31:
  br label %bb34
bb32:
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t171 = load ptr, ptr %l1, !tbaa !29
  %t172 = load i32, ptr %l2, !tbaa !23
  %t173 = load %"compiler/source:Span", ptr %l3
  %t178 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2efill(ptr %v0, ptr %v1, ptr %t170, ptr %t171, i32 %t172, %"compiler/source:Span" %t173)
  store { i64, [4 x i64] } %t178, ptr %l82
  br label %bb33
bb33:
  %t179 = load { i64, [4 x i64] }, ptr %l82
  store { i64, [4 x i64] } %t179, ptr %rv
  br label %ret
bb34:
  call void @__olang_check_failed(ptr @olang_loc_c00faf6434efe24b_96f261c8870620df)
  unreachable
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2emix(ptr %v0, ptr %a0, { i64, [4 x i64] } %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca { i64, [4 x i64] }
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca { i64, [4 x i64] }
  %l9 = alloca { i64, [4 x i64] }
  %l14 = alloca { i64, [4 x i64] }
  %l15 = alloca ptr
  %l16 = alloca i32
  %l17 = alloca i32
  %l18 = alloca { i64, [4 x i64] }
  %l19 = alloca ptr
  %l20 = alloca i32
  %l21 = alloca i32
  %l22 = alloca { i64, [4 x i64] }
  %l24 = alloca { i64, [4 x i64] }
  %l29 = alloca { i64, [4 x i64] }
  %l34 = alloca { i64, [4 x i64] }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, [4 x i64] }
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i32 5, ptr %l5
  %t2 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  store i32 %t2, ptr %l6, !tbaa !23
  store { i64, [4 x i64] } %a1, ptr %l7
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t6 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2econstI64(ptr %v0, ptr %t4, i64 -7046029254386353131)
  store { i64, [4 x i64] } %t6, ptr %l9
  br label %bb1
bb1:
  %t7 = load { i64, [4 x i64] }, ptr %l7
  %t8 = insertvalue [2 x { i64, [4 x i64] }] undef, { i64, [4 x i64] } %t7, 0
  %t9 = load { i64, [4 x i64] }, ptr %l9
  %t10 = insertvalue [2 x { i64, [4 x i64] }] %t8, { i64, [4 x i64] } %t9, 1
  %t12 = load ptr, ptr @__olang_prog_scope
  %t13 = call ptr @__olang_scope_alloc(ptr %t12, i64 80)
  store [2 x { i64, [4 x i64] }] %t10, ptr %t13
  %t14 = insertvalue { i64, ptr } undef, i64 2, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t13, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 40
  %t20 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t23 = load %"compiler/source:Span", ptr %l2
  %t24 = load ptr, ptr %l4, !tbaa !29
  %t25 = load i32, ptr %l5
  %t26 = load i32, ptr %l6, !tbaa !23
  %t29 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s0, ptr %t24, i32 %t25, i32 %t26, { i64, ptr } %t22, %"compiler/source:Span" %t23)
  store { i64, [4 x i64] } %t29, ptr %l14
  br label %bb2
bb2:
  %t30 = load { i64, [4 x i64] }, ptr %l14
  store { i64, [4 x i64] } %t30, ptr %l3
  %t31 = load ptr, ptr %l0, !tbaa !29
  store ptr %t31, ptr %l15, !tbaa !29
  store i32 12, ptr %l16
  %t32 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  store i32 %t32, ptr %l17, !tbaa !23
  %t33 = load { i64, [4 x i64] }, ptr %l3
  store { i64, [4 x i64] } %t33, ptr %l18
  %t34 = load ptr, ptr %l0, !tbaa !29
  store ptr %t34, ptr %l19, !tbaa !29
  store i32 9, ptr %l20
  %t35 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  store i32 %t35, ptr %l21, !tbaa !23
  %t36 = load { i64, [4 x i64] }, ptr %l3
  store { i64, [4 x i64] } %t36, ptr %l22
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2econstI64(ptr %v0, ptr %t37, i64 29)
  store { i64, [4 x i64] } %t39, ptr %l24
  br label %bb3
bb3:
  %t40 = load { i64, [4 x i64] }, ptr %l22
  %t41 = insertvalue [2 x { i64, [4 x i64] }] undef, { i64, [4 x i64] } %t40, 0
  %t42 = load { i64, [4 x i64] }, ptr %l24
  %t43 = insertvalue [2 x { i64, [4 x i64] }] %t41, { i64, [4 x i64] } %t42, 1
  %t45 = load ptr, ptr @__olang_prog_scope
  %t46 = call ptr @__olang_scope_alloc(ptr %t45, i64 80)
  store [2 x { i64, [4 x i64] }] %t43, ptr %t46
  %t47 = insertvalue { i64, ptr } undef, i64 2, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t46, 1
  %t50 = extractvalue { i64, ptr } %t48, 0
  %t51 = extractvalue { i64, ptr } %t48, 1
  %t52 = mul i64 %t50, 40
  %t53 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t52)
  call void @llvm.memcpy.p0.p0.i64(ptr %t53, ptr %t51, i64 %t52, i1 false)
  %t54 = insertvalue { i64, ptr } undef, i64 %t50, 0
  %t55 = insertvalue { i64, ptr } %t54, ptr %t53, 1
  %t56 = load %"compiler/source:Span", ptr %l2
  %t57 = load ptr, ptr %l19, !tbaa !29
  %t58 = load i32, ptr %l20
  %t59 = load i32, ptr %l21, !tbaa !23
  %t62 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s0, ptr %t57, i32 %t58, i32 %t59, { i64, ptr } %t55, %"compiler/source:Span" %t56)
  store { i64, [4 x i64] } %t62, ptr %l29
  br label %bb4
bb4:
  %t63 = load { i64, [4 x i64] }, ptr %l18
  %t64 = insertvalue [2 x { i64, [4 x i64] }] undef, { i64, [4 x i64] } %t63, 0
  %t65 = load { i64, [4 x i64] }, ptr %l29
  %t66 = insertvalue [2 x { i64, [4 x i64] }] %t64, { i64, [4 x i64] } %t65, 1
  %t68 = load ptr, ptr @__olang_prog_scope
  %t69 = call ptr @__olang_scope_alloc(ptr %t68, i64 80)
  store [2 x { i64, [4 x i64] }] %t66, ptr %t69
  %t70 = insertvalue { i64, ptr } undef, i64 2, 0
  %t71 = insertvalue { i64, ptr } %t70, ptr %t69, 1
  %t73 = extractvalue { i64, ptr } %t71, 0
  %t74 = extractvalue { i64, ptr } %t71, 1
  %t75 = mul i64 %t73, 40
  %t76 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t75)
  call void @llvm.memcpy.p0.p0.i64(ptr %t76, ptr %t74, i64 %t75, i1 false)
  %t77 = insertvalue { i64, ptr } undef, i64 %t73, 0
  %t78 = insertvalue { i64, ptr } %t77, ptr %t76, 1
  %t79 = load %"compiler/source:Span", ptr %l2
  %t80 = load ptr, ptr %l15, !tbaa !29
  %t81 = load i32, ptr %l16
  %t82 = load i32, ptr %l17, !tbaa !23
  %t85 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s0, ptr %t80, i32 %t81, i32 %t82, { i64, ptr } %t78, %"compiler/source:Span" %t79)
  store { i64, [4 x i64] } %t85, ptr %l34
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s0)
  %t86 = load { i64, [4 x i64] }, ptr %l34
  store { i64, [4 x i64] } %t86, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local %"compiler/mir:Place" @compiler_2flower_2ecompiler_2flower_3alowering_2emk(ptr %v0, ptr %v1, ptr %a0, %"compiler/lower:pl" %a1) #0 {
entry:
  %l1 = alloca %"compiler/lower:pl"
  %l3 = alloca ptr
  %l4 = alloca { i64, [2 x i64] }
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"compiler/mir:Place"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/mir:Place"
  store %"compiler/lower:pl" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = getelementptr %"compiler/lower:lowering", ptr %a0, i32 0, i32 3
  store ptr %t3, ptr %l3, !tbaa !29
  %t4 = getelementptr %"compiler/lower:pl", ptr %l1, i32 0, i32 0
  %t5 = load { i64, [2 x i64] }, ptr %t4
  store { i64, [2 x i64] } %t5, ptr %l4
  %t6 = getelementptr %"compiler/lower:pl", ptr %l1, i32 0, i32 1
  %t8 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aProj_3e_2eToArray_3ccompiler_2fmir_3aProj_3e(ptr %v1, ptr %s0, ptr %t6)
  store { i64, ptr } %t8, ptr %l6
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l3, !tbaa !29
  %t10 = load { i64, [2 x i64] }, ptr %l4
  %t11 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t12 = call %"compiler/mir:Place" @compiler_2fmir_2ecompiler_2fmir_3aFn_2ePlace(ptr %v0, ptr %s0, ptr %t9, { i64, [2 x i64] } %t10, { i64, ptr } %t11)
  store %"compiler/mir:Place" %t12, ptr %l7
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  %t13 = load %"compiler/mir:Place", ptr %l7
  store %"compiler/mir:Place" %t13, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/mir:Place", ptr %rv
  ret %"compiler/mir:Place" %rr
}

define dso_local i64 @compiler_2flower_2ecompiler_2flower_3alowering_2emodule(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l12 = alloca i64
  %l16 = alloca i64
  %l19 = alloca i64
  %l43 = alloca ptr
  %s2 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l1, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/lower:Lowerer", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/generic:Program", ptr %t7, i32 0, i32 0
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/load:Loader", ptr %t10, i32 0, i32 5
  %t14 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_He36936f29a17adf60cb2ecc49df5337f(ptr %v0, ptr %t12)
  store i64 %t14, ptr %l12
  br label %bb1
bb1:
  %t15 = load i64, ptr %l12, !tbaa !24
  store i64 %t15, ptr %l2, !tbaa !24
  store i64 1, ptr %l3, !tbaa !24
  %t16 = load i64, ptr %l2, !tbaa !24
  %t17 = load i64, ptr %l1, !tbaa !24
  %t20 = icmp sgt i64 %t16, %t17
  br i1 %t20, label %bb2, label %bb3
bb2:
  %t22 = load i64, ptr %l3, !tbaa !24
  %t24 = icmp sgt i64 %t22, 0
  br i1 %t24, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l16, !tbaa !24
  br label %bb7
bb4:
  %t26 = load i64, ptr %l2, !tbaa !24
  %t27 = load i64, ptr %l1, !tbaa !24
  %t30 = sub i64 %t26, %t27
  %t31 = load i64, ptr %l3, !tbaa !24
  %t34 = add i64 %t30, %t31
  %t36 = sub i64 %t34, 1
  %t37 = load i64, ptr %l3, !tbaa !24
  %t40 = sdiv i64 %t36, %t37
  store i64 %t40, ptr %l19, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l19, !tbaa !24
  br label %bb6
bb6:
  %t42 = load i64, ptr %l19, !tbaa !24
  store i64 %t42, ptr %l16, !tbaa !24
  br label %bb7
bb7:
  %t43 = load i64, ptr %l16, !tbaa !24
  store i64 %t43, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t44 = load i64, ptr %l5, !tbaa !24
  %t45 = load i64, ptr %l4, !tbaa !24
  %t48 = icmp slt i64 %t44, %t45
  %t50 = xor i1 %t48, true
  br i1 %t50, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb17
bb10:
  br label %bb11
bb11:
  %t52 = load i64, ptr %l1, !tbaa !24
  %t53 = load i64, ptr %l5, !tbaa !24
  %t54 = load i64, ptr %l3, !tbaa !24
  %t57 = mul i64 %t53, %t54
  %t60 = add i64 %t52, %t57
  store i64 %t60, ptr %l6, !tbaa !24
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/lower:lowering", ptr %t62, i32 0, i32 0
  %t65 = load ptr, ptr %t64, !tbaa !29
  %t67 = getelementptr %"compiler/lower:Lowerer", ptr %t65, i32 0, i32 0
  %t68 = load ptr, ptr %t67, !tbaa !29
  %t70 = getelementptr %"compiler/generic:Program", ptr %t68, i32 0, i32 0
  %t71 = load ptr, ptr %t70, !tbaa !29
  %t73 = getelementptr %"compiler/load:Loader", ptr %t71, i32 0, i32 5
  %t74 = load i64, ptr %l6, !tbaa !24
  %t77 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t73, i64 %t74)
  store ptr %t77, ptr %l43
  br label %bb12
bb12:
  %t78 = load ptr, ptr %l43, !tbaa !29
  %t80 = getelementptr %"compiler/load:Module", ptr %t78, i32 0, i32 4
  %t81 = load i64, ptr %t80, !tbaa !24
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/lower:lowering", ptr %t82, i32 0, i32 4
  %t85 = load i64, ptr %t84, !tbaa !24
  %t88 = icmp eq i64 %t81, %t85
  br i1 %t88, label %bb13, label %bb14
bb13:
  %t90 = load i64, ptr %l6, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  store i64 %t90, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s2)
  br label %bb16
bb16:
  %t92 = load i64, ptr %l5, !tbaa !24
  %t94 = add i64 %t92, 1
  store i64 %t94, ptr %l5, !tbaa !24
  br label %bb8
bb17:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local %"compiler/mir:Range" @compiler_2flower_2ecompiler_2flower_3alowering_2epassed(ptr %v0, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l18 = alloca i64
  %l21 = alloca i64
  %l43 = alloca i1
  %l46 = alloca i1
  %l53 = alloca i64
  %l54 = alloca ptr
  %l59 = alloca { i64, [1 x i64] }
  %l60 = alloca { i64, [1 x i64] }
  %l66 = alloca %"compiler/mir:Range"
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca %"compiler/mir:Range"
  %t63 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l1, !tbaa !24
  store i64 %t1, ptr %l10, !tbaa !24
  %t2 = load i64, ptr %l10, !tbaa !24
  %t3 = icmp sge i64 %t2, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load i64, ptr %l10, !tbaa !24
  %t6 = icmp sle i64 %t5, 576460752303423487
  br i1 %t6, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_279896acdd8c6bde_4c10668047ad718a)
  unreachable
bb3:
  %t8 = load i64, ptr %l10, !tbaa !24
  %t9 = mul i64 %t8, 16
  %t10 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t9)
  %t11 = insertvalue { i64, ptr } undef, i64 %t8, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t14 = load i64, ptr %l1, !tbaa !24
  store i64 %t14, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t16 = load i64, ptr %l5, !tbaa !24
  %t17 = load i64, ptr %l4, !tbaa !24
  %t20 = icmp sgt i64 %t16, %t17
  br i1 %t20, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_279896acdd8c6bde_4c10668047ad718a)
  unreachable
bb5:
  %t22 = load i64, ptr %l6, !tbaa !24
  %t24 = icmp sgt i64 %t22, 0
  br i1 %t24, label %bb7, label %bb8
bb6:
  store i64 0, ptr %l18, !tbaa !24
  br label %bb10
bb7:
  %t26 = load i64, ptr %l5, !tbaa !24
  %t27 = load i64, ptr %l4, !tbaa !24
  %t30 = sub i64 %t26, %t27
  %t31 = load i64, ptr %l6, !tbaa !24
  %t34 = add i64 %t30, %t31
  %t36 = sub i64 %t34, 1
  %t37 = load i64, ptr %l6, !tbaa !24
  %t40 = sdiv i64 %t36, %t37
  store i64 %t40, ptr %l21, !tbaa !24
  br label %bb9
bb8:
  store i64 0, ptr %l21, !tbaa !24
  br label %bb9
bb9:
  %t42 = load i64, ptr %l21, !tbaa !24
  store i64 %t42, ptr %l18, !tbaa !24
  br label %bb10
bb10:
  %t43 = load i64, ptr %l18, !tbaa !24
  store i64 %t43, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb11
bb11:
  store %olang.scope zeroinitializer, ptr %s2
  %t44 = load i64, ptr %l8, !tbaa !24
  %t45 = load i64, ptr %l7, !tbaa !24
  %t48 = icmp slt i64 %t44, %t45
  %t50 = xor i1 %t48, true
  br i1 %t50, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s2)
  br label %bb27
bb13:
  br label %bb14
bb14:
  %t52 = load i64, ptr %l4, !tbaa !24
  %t53 = load i64, ptr %l8, !tbaa !24
  %t54 = load i64, ptr %l6, !tbaa !24
  %t57 = mul i64 %t53, %t54
  %t60 = add i64 %t52, %t57
  store i64 %t60, ptr %l9, !tbaa !24
  %t62 = load i64, ptr %l9, !tbaa !24
  store { i64, [1 x i64] } zeroinitializer, ptr %t63
  %t64 = getelementptr { i64, [1 x i64] }, ptr %t63, i32 0, i32 0
  store i64 2, ptr %t64
  %t65 = load { i64, [1 x i64] }, ptr %t63
  %t68 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t69 = load ptr, ptr %t68, !tbaa !27
  %t70 = getelementptr { i64, [1 x i64] }, ptr %t69, i64 %t62
  store { i64, [1 x i64] } %t65, ptr %t70
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/lower:lowering", ptr %t71, i32 0, i32 19
  %t74 = load i1, ptr %t73, !tbaa !21
  br i1 %t74, label %bb15, label %bb16
bb15:
  %t76 = load i32, ptr %l2, !tbaa !23
  %t78 = icmp sge i32 %t76, 0
  store i1 %t78, ptr %l43, !tbaa !21
  br label %bb17
bb16:
  store i1 false, ptr %l43, !tbaa !21
  br label %bb17
bb17:
  %t80 = load i1, ptr %l43, !tbaa !21
  br i1 %t80, label %bb18, label %bb19
bb18:
  %t81 = load i32, ptr %l2, !tbaa !23
  %t83 = sext i32 %t81 to i64
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr %"compiler/lower:lowering", ptr %t84, i32 0, i32 22
  %t87 = getelementptr %"compiler/typed:Plan", ptr %t86, i32 0, i32 0
  %t88 = load { i64, ptr }, ptr %t87, !tbaa !27
  %t90 = extractvalue { i64, ptr } %t88, 0
  %t93 = icmp slt i64 %t83, %t90
  store i1 %t93, ptr %l46, !tbaa !21
  br label %bb20
bb19:
  store i1 false, ptr %l46, !tbaa !21
  br label %bb20
bb20:
  %t95 = load i1, ptr %l46, !tbaa !21
  br i1 %t95, label %bb21, label %bb22
bb21:
  %t96 = load i64, ptr %l9, !tbaa !24
  store i64 %t96, ptr %l53, !tbaa !24
  %t97 = load ptr, ptr %l0, !tbaa !29
  store ptr %t97, ptr %l54, !tbaa !29
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t100 = getelementptr %"compiler/lower:lowering", ptr %t98, i32 0, i32 22
  %t101 = load i32, ptr %l2, !tbaa !23
  %t102 = load i64, ptr %l9, !tbaa !24
  %t106 = call { i64, [1 x i64] } @compiler_2ftyped_2ecompiler_2ftyped_3aPlan_2ePassed(ptr %v0, ptr %t100, i32 %t101, i64 %t102)
  store { i64, [1 x i64] } %t106, ptr %l59
  br label %bb23
bb22:
  br label %bb25
bb23:
  %t107 = load ptr, ptr %l54, !tbaa !29
  %t108 = load { i64, [1 x i64] }, ptr %l59
  %t109 = call { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2escopeRef(ptr %v0, ptr %t107, { i64, [1 x i64] } %t108)
  store { i64, [1 x i64] } %t109, ptr %l60
  br label %bb24
bb24:
  %t110 = load { i64, [1 x i64] }, ptr %l60
  %t111 = load i64, ptr %l53, !tbaa !24
  %t112 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t113 = load ptr, ptr %t112, !tbaa !27
  %t114 = getelementptr { i64, [1 x i64] }, ptr %t113, i64 %t111
  store { i64, [1 x i64] } %t110, ptr %t114
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s2)
  br label %bb26
bb26:
  %t115 = load i64, ptr %l8, !tbaa !24
  %t117 = add i64 %t115, 1
  store i64 %t117, ptr %l8, !tbaa !24
  br label %bb11
bb27:
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t121 = getelementptr %"compiler/lower:lowering", ptr %t119, i32 0, i32 3
  %t122 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t125 = call %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eScopeRefs(ptr %v0, ptr %s0, ptr %t121, { i64, ptr } %t122)
  store %"compiler/mir:Range" %t125, ptr %l66
  br label %bb28
bb28:
  call void @__olang_scope_close(ptr %s0)
  %t126 = load %"compiler/mir:Range", ptr %l66
  store %"compiler/mir:Range" %t126, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/mir:Range", ptr %rv
  ret %"compiler/mir:Range" %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2epatch(ptr %v0, ptr %v1, ptr %a0, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l10 = alloca i64
  %l15 = alloca i32
  %l17 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l21 = alloca i32
  %l30 = alloca { i64, ptr }
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %t57 = alloca { i64, [7 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aBlockId_3e_2eLen_3ccompiler_2fmir_3aBlockId_3e(ptr %v1, ptr %l1)
  store i64 %t2, ptr %l10
  br label %bb1
bb1:
  %t3 = load i64, ptr %l10, !tbaa !24
  %t4 = icmp eq i64 %t3, 0
  br i1 %t4, label %bb2, label %bb3
bb2:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/lower:lowering", ptr %t6, i32 0, i32 7
  store i1 true, ptr %t8, !tbaa !21
  br label %ret
bb3:
  br label %bb4
bb4:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/lower:lowering", ptr %t9, i32 0, i32 3
  %t13 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t11)
  store i32 %t13, ptr %l15
  br label %bb5
bb5:
  %t14 = load i32, ptr %l15, !tbaa !23
  store i32 %t14, ptr %l2, !tbaa !23
  store ptr %l1, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  br label %bb6
bb6:
  store %olang.scope zeroinitializer, ptr %s3
  %t16 = load ptr, ptr %l3, !tbaa !29
  %t17 = load i64, ptr %l4, !tbaa !24
  %t20 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aBlockId_3e_2eRunFrom_3ccompiler_2fmir_3aBlockId_3e(ptr %v1, ptr %t16, i64 %t17)
  %t21 = extractvalue { i32, { i64, ptr } } %t20, 1
  %t22 = extractvalue { i32, { i64, ptr } } %t20, 0
  store i32 %t22, ptr %l21
  %t23 = icmp ne i32 %t22, 0
  br i1 %t23, label %bb8, label %ok.24
ok.24:
  store { i64, ptr } %t21, ptr %l20
  br label %bb7
bb7:
  %t25 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t25, ptr %l17, !tbaa !27
  br label %bb12
bb8:
  %t26 = load i32, ptr %l21, !tbaa !23
  %t27 = ashr i32 %t26, 16
  %t29 = icmp eq i32 %t27, 1
  br i1 %t29, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_678a134ca8e67a35_be411b19d54605f9)
  unreachable
bb11:
  call void @__olang_scope_close(ptr %s3)
  br label %bb21
bb12:
  %t31 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t31, ptr %l5, !tbaa !27
  %t32 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t34 = extractvalue { i64, ptr } %t32, 0
  store i64 %t34, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb13
bb13:
  store %olang.scope zeroinitializer, ptr %s4
  %t36 = load i64, ptr %l7, !tbaa !24
  %t37 = load i64, ptr %l6, !tbaa !24
  %t40 = icmp slt i64 %t36, %t37
  %t42 = xor i1 %t40, true
  br i1 %t42, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s4)
  br label %bb19
bb15:
  br label %bb16
bb16:
  %t44 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t44, ptr %l30, !tbaa !27
  %t45 = load i64, ptr %l7, !tbaa !24
  %t47 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t48 = load ptr, ptr %t47, !tbaa !27
  %t49 = getelementptr i32, ptr %t48, i64 %t45
  %t50 = load i32, ptr %t49, !tbaa !33
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/lower:lowering", ptr %t52, i32 0, i32 3
  %t56 = load i32, ptr %l2, !tbaa !23
  store { i64, [7 x i64] } zeroinitializer, ptr %t57
  %t58 = getelementptr { i64, [7 x i64] }, ptr %t57, i32 0, i32 0
  store i64 1, ptr %t58
  %t60 = insertvalue { i32 } undef, i32 %t56, 0
  %t61 = getelementptr { i64, [7 x i64] }, ptr %t57, i32 0, i32 1
  store { i32 } %t60, ptr %t61
  %t62 = load { i64, [7 x i64] }, ptr %t57
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eEnd(ptr %v0, ptr %t54, i32 %t50, { i64, [7 x i64] } %t62)
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s4)
  br label %bb18
bb18:
  %t66 = load i64, ptr %l7, !tbaa !24
  %t68 = add i64 %t66, 1
  store i64 %t68, ptr %l7, !tbaa !24
  br label %bb13
bb19:
  %t70 = load i64, ptr %l4, !tbaa !24
  %t71 = load i64, ptr %l6, !tbaa !24
  %t74 = add i64 %t70, %t71
  store i64 %t74, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb20
bb20:
  br label %bb6
bb21:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t77 = load i32, ptr %l2, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t76, i32 %t77)
  br label %bb22
bb22:
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2epayload(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %lp3 = alloca ptr
  %l10 = alloca %"compiler/lower:pl"
  %l18 = alloca ptr
  %l19 = alloca i32
  %l22 = alloca %"compiler/mir:Place"
  %l25 = alloca { i64, [4 x i64] }
  %l26 = alloca ptr
  %l27 = alloca i32
  %l28 = alloca i32
  %l29 = alloca { i64, [4 x i64] }
  %l33 = alloca { i64, [4 x i64] }
  %l38 = alloca { i64, [4 x i64] }
  %l51 = alloca %"compiler/lower:pl"
  %s2 = alloca %olang.scope
  %rv = alloca %"compiler/lower:pl"
  %t39 = alloca { i64, [15 x i64] }, align 8
  %t108 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t4 = getelementptr %"compiler/typed:Payload", ptr %t2, i32 0, i32 0
  %t5 = load ptr, ptr %t4, !tbaa !29
  %t9 = call %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2eplace(ptr %v0, ptr %v1, ptr %v2, ptr %t1, ptr %t5)
  store %"compiler/lower:pl" %t9, ptr %l10
  br label %bb1
bb1:
  %t10 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 32, i64 8)
  store ptr %t10, ptr %lp3
  %t11 = load %"compiler/lower:pl", ptr %l10
  %t12 = load ptr, ptr %lp3
  store %"compiler/lower:pl" %t11, ptr %t12
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/lower:lowering", ptr %t13, i32 0, i32 7
  %t16 = load i1, ptr %t15, !tbaa !21
  br i1 %t16, label %bb2, label %bb3
bb2:
  %t18 = load ptr, ptr %lp3
  %t19 = load %"compiler/lower:pl", ptr %t18
  store %"compiler/lower:pl" %t19, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t21 = load ptr, ptr %l1, !tbaa !29
  %t23 = getelementptr %"compiler/typed:Payload", ptr %t21, i32 0, i32 2
  %t24 = load i32, ptr %t23
  %t26 = trunc i64 0 to i32
  %t27 = icmp eq i32 %t24, %t26
  %t29 = xor i1 %t27, true
  br i1 %t29, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s2
  %t31 = load ptr, ptr %l0, !tbaa !29
  store ptr %t31, ptr %l18, !tbaa !29
  %t32 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  store i32 %t32, ptr %l19, !tbaa !23
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t34 = load ptr, ptr %lp3
  %t35 = load %"compiler/lower:pl", ptr %t34
  %t38 = call %"compiler/mir:Place" @compiler_2flower_2ecompiler_2flower_3alowering_2emk(ptr %v0, ptr %v2, ptr %t33, %"compiler/lower:pl" %t35)
  store %"compiler/mir:Place" %t38, ptr %l22
  br label %bb7
bb6:
  br label %bb12
bb7:
  store { i64, [15 x i64] } zeroinitializer, ptr %t39
  %t40 = getelementptr { i64, [15 x i64] }, ptr %t39, i32 0, i32 0
  store i64 5, ptr %t40
  %t41 = load %"compiler/mir:Place", ptr %l22
  %t42 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t41, 0
  %t43 = getelementptr { i64, [15 x i64] }, ptr %t39, i32 0, i32 1
  store { %"compiler/mir:Place" } %t42, ptr %t43
  %t44 = load { i64, [15 x i64] }, ptr %t39
  %t45 = load %"compiler/source:Span", ptr %l2
  %t46 = load ptr, ptr %l18, !tbaa !29
  %t47 = load i32, ptr %l19, !tbaa !23
  %t50 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %t46, i32 %t47, { i64, [15 x i64] } %t44, %"compiler/source:Span" %t45)
  store { i64, [4 x i64] } %t50, ptr %l25
  br label %bb8
bb8:
  %t51 = load { i64, [4 x i64] }, ptr %l25
  %t52 = load ptr, ptr %l0, !tbaa !29
  store ptr %t52, ptr %l26, !tbaa !29
  store i32 13, ptr %l27
  %t53 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t53, ptr %l28, !tbaa !23
  store { i64, [4 x i64] } %t51, ptr %l29
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t56 = load ptr, ptr %l1, !tbaa !29
  %t58 = getelementptr %"compiler/typed:Payload", ptr %t56, i32 0, i32 1
  %t59 = load i64, ptr %t58, !tbaa !24
  %t62 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2econstI64(ptr %v0, ptr %t55, i64 %t59)
  store { i64, [4 x i64] } %t62, ptr %l33
  br label %bb9
bb9:
  %t63 = load { i64, [4 x i64] }, ptr %l29
  %t64 = insertvalue [2 x { i64, [4 x i64] }] undef, { i64, [4 x i64] } %t63, 0
  %t65 = load { i64, [4 x i64] }, ptr %l33
  %t66 = insertvalue [2 x { i64, [4 x i64] }] %t64, { i64, [4 x i64] } %t65, 1
  %t68 = load ptr, ptr @__olang_prog_scope
  %t69 = call ptr @__olang_scope_alloc(ptr %t68, i64 80)
  store [2 x { i64, [4 x i64] }] %t66, ptr %t69
  %t70 = insertvalue { i64, ptr } undef, i64 2, 0
  %t71 = insertvalue { i64, ptr } %t70, ptr %t69, 1
  %t73 = extractvalue { i64, ptr } %t71, 0
  %t74 = extractvalue { i64, ptr } %t71, 1
  %t75 = mul i64 %t73, 40
  %t76 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t75)
  call void @llvm.memcpy.p0.p0.i64(ptr %t76, ptr %t74, i64 %t75, i1 false)
  %t77 = insertvalue { i64, ptr } undef, i64 %t73, 0
  %t78 = insertvalue { i64, ptr } %t77, ptr %t76, 1
  %t79 = load %"compiler/source:Span", ptr %l2
  %t80 = load ptr, ptr %l26, !tbaa !29
  %t81 = load i32, ptr %l27
  %t82 = load i32, ptr %l28, !tbaa !23
  %t85 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s2, ptr %t80, i32 %t81, i32 %t82, { i64, ptr } %t78, %"compiler/source:Span" %t79)
  store { i64, [4 x i64] } %t85, ptr %l38
  br label %bb10
bb10:
  %t86 = load { i64, [4 x i64] }, ptr %l38
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = load ptr, ptr %l1, !tbaa !29
  %t91 = getelementptr %"compiler/typed:Payload", ptr %t89, i32 0, i32 2
  %t92 = load i32, ptr %t91
  %t93 = load i64, ptr @G_2ecompiler_2flower_2eWrongCase, !tbaa !24
  %t94 = load %"compiler/source:Span", ptr %l2
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2echeck(ptr %v0, ptr %t87, { i64, [4 x i64] } %t86, i32 %t92, i32 8, i64 %t93, %"compiler/source:Span" %t94)
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s2)
  br label %bb12
bb12:
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t102 = load ptr, ptr %lp3
  %t103 = load %"compiler/lower:pl", ptr %t102
  %t104 = load ptr, ptr %l1, !tbaa !29
  %t106 = getelementptr %"compiler/typed:Payload", ptr %t104, i32 0, i32 1
  %t107 = load i64, ptr %t106, !tbaa !24
  store { i64, [1 x i64] } zeroinitializer, ptr %t108
  %t109 = getelementptr { i64, [1 x i64] }, ptr %t108, i32 0, i32 0
  store i64 4, ptr %t109
  %t111 = insertvalue { i64 } undef, i64 %t107, 0
  %t112 = getelementptr { i64, [1 x i64] }, ptr %t108, i32 0, i32 1
  store { i64 } %t111, ptr %t112
  %t113 = load { i64, [1 x i64] }, ptr %t108
  %t117 = call %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2ewith(ptr %v0, ptr %v2, ptr %v2, ptr %t101, %"compiler/lower:pl" %t103, { i64, [1 x i64] } %t113)
  store %"compiler/lower:pl" %t117, ptr %l51
  br label %bb13
bb13:
  %t118 = load %"compiler/lower:pl", ptr %l51
  store %"compiler/lower:pl" %t118, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/lower:pl", ptr %rv
  ret %"compiler/lower:pl" %rr
}

define dso_local { { i64, [4 x i64] }, i32 } @compiler_2flower_2ecompiler_2flower_3alowering_2epiece(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca ptr
  %l7 = alloca %"compiler/lower:pl"
  %l8 = alloca i32
  %l12 = alloca i32
  %l15 = alloca i32
  %l16 = alloca ptr
  %l19 = alloca i32
  %l20 = alloca i1
  %l22 = alloca i1
  %l26 = alloca i1
  %l29 = alloca i64
  %l31 = alloca ptr
  %l32 = alloca i1
  %l40 = alloca %"compiler/lower:pl"
  %l49 = alloca i32
  %l50 = alloca ptr
  %l51 = alloca i32
  %l54 = alloca %"compiler/mir:Place"
  %l58 = alloca { i64, [4 x i64] }
  %l64 = alloca { i64, [4 x i64] }
  %rv = alloca { { i64, [4 x i64] }, i32 }
  %t71 = alloca { i64, [4 x i64] }, align 8
  %t96 = alloca { i64, [15 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t6 = load ptr, ptr %l1, !tbaa !29
  %t8 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t6)
  store i32 %t8, ptr %l12
  br label %bb1
bb1:
  %t9 = load i32, ptr %l12, !tbaa !23
  store i32 %t9, ptr %l4, !tbaa !23
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = load i32, ptr %l4, !tbaa !23
  %t14 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2earrayOf(ptr %v0, ptr %t10, i32 %t11)
  store i32 %t14, ptr %l15
  br label %bb2
bb2:
  %t15 = load i32, ptr %l15, !tbaa !23
  store i32 %t15, ptr %l5, !tbaa !23
  %t16 = load ptr, ptr %l3, !tbaa !29
  store ptr %t16, ptr %l16, !tbaa !29
  %t17 = load ptr, ptr %l3, !tbaa !29
  %t18 = load i32, ptr %l4, !tbaa !23
  %t21 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t17, i32 %t18)
  store i32 %t21, ptr %l19
  br label %bb3
bb3:
  %t22 = load ptr, ptr %l16, !tbaa !29
  %t23 = load i32, ptr %l19, !tbaa !23
  %t24 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t22, i32 %t23)
  store i1 %t24, ptr %l20
  br label %bb4
bb4:
  %t25 = load i1, ptr %l20, !tbaa !21
  %t26 = xor i1 %t25, true
  br i1 %t26, label %bb5, label %bb6
bb5:
  %t28 = load i32, ptr %l5, !tbaa !23
  %t29 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t32 = icmp ne i32 %t28, %t29
  store i1 %t32, ptr %l22, !tbaa !21
  br label %bb7
bb6:
  store i1 false, ptr %l22, !tbaa !21
  br label %bb7
bb7:
  %t34 = load i1, ptr %l22, !tbaa !21
  br i1 %t34, label %bb8, label %bb9
bb8:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load i32, ptr %l5, !tbaa !23
  %t39 = call i64 @compiler_2flower_2ecompiler_2flower_3alowering_2efixedLen(ptr %v0, ptr %t35, i32 %t36)
  store i64 %t39, ptr %l29
  br label %bb10
bb9:
  store i1 false, ptr %l26, !tbaa !21
  br label %bb11
bb10:
  %t40 = load i64, ptr %l29, !tbaa !24
  %t41 = icmp sge i64 %t40, 0
  store i1 %t41, ptr %l26, !tbaa !21
  br label %bb11
bb11:
  %t43 = load i1, ptr %l26, !tbaa !21
  br i1 %t43, label %bb12, label %bb13
bb12:
  %t44 = load ptr, ptr %l1, !tbaa !29
  store ptr %t44, ptr %l31, !tbaa !29
  store i1 false, ptr %l32, !tbaa !21
  %t45 = load ptr, ptr %l31, !tbaa !29
  %t46 = icmp ne ptr %t45, null
  br i1 %t46, label %bb14, label %bb15
bb13:
  br label %bb32
bb14:
  %t48 = load ptr, ptr %l31, !tbaa !29
  %t49 = load i64, ptr %t48
  %t51 = icmp eq i64 %t49, 2
  store i1 %t51, ptr %l32, !tbaa !21
  br label %bb15
bb15:
  %t52 = load i1, ptr %l32, !tbaa !21
  br i1 %t52, label %bb16, label %bb17
bb16:
  %t53 = load ptr, ptr %l1, !tbaa !29
  %t55 = getelementptr { i64, [5 x i64] }, ptr %t53, i32 0, i32 1
  %t56 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t55, i32 0, i32 2
  %t57 = load ptr, ptr %t56
  store ptr %t57, ptr %l6, !tbaa !29
  br label %bb18
bb17:
  br label %bb26
bb18:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t60 = load ptr, ptr %l6, !tbaa !29
  %t64 = call %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2eplace(ptr %v0, ptr %v1, ptr %v0, ptr %t59, ptr %t60)
  store %"compiler/lower:pl" %t64, ptr %l40
  br label %bb19
bb19:
  %t65 = load %"compiler/lower:pl", ptr %l40
  store %"compiler/lower:pl" %t65, ptr %l7
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"compiler/lower:lowering", ptr %t66, i32 0, i32 7
  %t69 = load i1, ptr %t68, !tbaa !21
  br i1 %t69, label %bb20, label %bb21
bb20:
  store { i64, [4 x i64] } zeroinitializer, ptr %t71
  %t72 = getelementptr { i64, [4 x i64] }, ptr %t71, i32 0, i32 0
  store i64 0, ptr %t72
  %t73 = load { i64, [4 x i64] }, ptr %t71
  %t74 = load i32, ptr %l4, !tbaa !23
  %t76 = insertvalue { { i64, [4 x i64] }, i32 } undef, { i64, [4 x i64] } %t73, 0
  %t78 = insertvalue { { i64, [4 x i64] }, i32 } %t76, i32 %t74, 1
  store { { i64, [4 x i64] }, i32 } %t78, ptr %rv
  br label %ret
bb21:
  br label %bb22
bb22:
  %t80 = load ptr, ptr %l3, !tbaa !29
  %t81 = load i32, ptr %l4, !tbaa !23
  %t82 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t86 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t80, i32 %t81, i64 %t82)
  store i32 %t86, ptr %l49
  br label %bb23
bb23:
  %t87 = load i32, ptr %l49, !tbaa !23
  store i32 %t87, ptr %l8, !tbaa !23
  %t88 = load ptr, ptr %l0, !tbaa !29
  store ptr %t88, ptr %l50, !tbaa !29
  %t89 = load i32, ptr %l8, !tbaa !23
  store i32 %t89, ptr %l51, !tbaa !23
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t91 = load %"compiler/lower:pl", ptr %l7
  %t94 = call %"compiler/mir:Place" @compiler_2flower_2ecompiler_2flower_3alowering_2emk(ptr %v0, ptr %v0, ptr %t90, %"compiler/lower:pl" %t91)
  store %"compiler/mir:Place" %t94, ptr %l54
  br label %bb24
bb24:
  %t95 = load i32, ptr %l8, !tbaa !23
  store { i64, [15 x i64] } zeroinitializer, ptr %t96
  %t97 = getelementptr { i64, [15 x i64] }, ptr %t96, i32 0, i32 0
  store i64 1, ptr %t97
  %t98 = load %"compiler/mir:Place", ptr %l54
  %t99 = insertvalue { %"compiler/mir:Place", i32 } undef, %"compiler/mir:Place" %t98, 0
  %t101 = insertvalue { %"compiler/mir:Place", i32 } %t99, i32 %t95, 1
  %t102 = getelementptr { i64, [15 x i64] }, ptr %t96, i32 0, i32 1
  store { %"compiler/mir:Place", i32 } %t101, ptr %t102
  %t103 = load { i64, [15 x i64] }, ptr %t96
  %t105 = load ptr, ptr %l50, !tbaa !29
  %t106 = load i32, ptr %l51, !tbaa !23
  %t109 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %t105, i32 %t106, { i64, [15 x i64] } %t103, %"compiler/source:Span" %a2)
  store { i64, [4 x i64] } %t109, ptr %l58
  br label %bb25
bb25:
  %t110 = load i32, ptr %l8, !tbaa !23
  %t111 = load { i64, [4 x i64] }, ptr %l58
  %t112 = insertvalue { { i64, [4 x i64] }, i32 } undef, { i64, [4 x i64] } %t111, 0
  %t114 = insertvalue { { i64, [4 x i64] }, i32 } %t112, i32 %t110, 1
  store { { i64, [4 x i64] }, i32 } %t114, ptr %rv
  br label %ret
bb26:
  br i1 true, label %bb27, label %bb28
bb27:
  br label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb31
bb30:
  call void @__olang_check_failed(ptr @olang_loc_eff9370fb6cf39b1_ff4f9c232720af7d)
  unreachable
bb31:
  br label %bb32
bb32:
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t117 = load ptr, ptr %l1, !tbaa !29
  %t121 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v1, ptr %t116, ptr %t117)
  store { i64, [4 x i64] } %t121, ptr %l64
  br label %bb33
bb33:
  %t122 = load i32, ptr %l4, !tbaa !23
  %t123 = load { i64, [4 x i64] }, ptr %l64
  %t124 = insertvalue { { i64, [4 x i64] }, i32 } undef, { i64, [4 x i64] } %t123, 0
  %t126 = insertvalue { { i64, [4 x i64] }, i32 } %t124, i32 %t122, 1
  store { { i64, [4 x i64] }, i32 } %t126, ptr %rv
  br label %ret
ret:
  %rr = load { { i64, [4 x i64] }, i32 }, ptr %rv
  ret { { i64, [4 x i64] }, i32 } %rr
}

define dso_local { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eplaceStorage(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca { i64, [1 x i64] }
  %l4 = alloca ptr
  %l5 = alloca i1
  %l12 = alloca { i64, [1 x i64] }
  %rv = alloca { i64, [1 x i64] }
  %t22 = alloca { i64, [1 x i64] }, align 8
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t17 = load i32, ptr %l2, !tbaa !23
  %t20 = call { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2estorageOf(ptr %v0, ptr %a0, i32 %t17)
  store { i64, [1 x i64] } %t20, ptr %l12
  br label %bb6
bb6:
  %t21 = load { i64, [1 x i64] }, ptr %l12
  store { i64, [1 x i64] } %t21, ptr %l3
  br label %bb12
bb7:
  br i1 true, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb11
bb10:
  store { i64, [1 x i64] } zeroinitializer, ptr %t22
  %t23 = getelementptr { i64, [1 x i64] }, ptr %t22, i32 0, i32 0
  store i64 2, ptr %t23
  %t24 = load { i64, [1 x i64] }, ptr %t22
  store { i64, [1 x i64] } %t24, ptr %l3
  br label %bb12
bb11:
  call void @__olang_check_failed(ptr @olang_loc_4fc653f117519a1d_d526ff90513f5371)
  unreachable
bb12:
  %t26 = load { i64, [1 x i64] }, ptr %l3
  store { i64, [1 x i64] } %t26, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [1 x i64] }, ptr %rv
  ret { i64, [1 x i64] } %rr
}

define dso_local { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2, { i64, ptr } %a3, %"compiler/source:Span" %a4) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i32
  %l12 = alloca %"compiler/mir:Range"
  %l15 = alloca { i64, [4 x i64] }
  %rv = alloca { i64, [4 x i64] }
  %t12 = alloca { i64, [15 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  %t2 = load i32, ptr %l2, !tbaa !23
  store i32 %t2, ptr %l6, !tbaa !23
  store i32 %a1, ptr %l7
  %t4 = load i32, ptr %l2, !tbaa !23
  store i32 %t4, ptr %l8, !tbaa !23
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/lower:lowering", ptr %t5, i32 0, i32 3
  %t11 = call %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eArgs(ptr %v0, ptr %v1, ptr %t7, { i64, ptr } %a3)
  store %"compiler/mir:Range" %t11, ptr %l12
  br label %bb1
bb1:
  store { i64, [15 x i64] } zeroinitializer, ptr %t12
  %t13 = getelementptr { i64, [15 x i64] }, ptr %t12, i32 0, i32 0
  store i64 3, ptr %t13
  %t14 = load i32, ptr %l7
  %t15 = insertvalue { i32, i32, %"compiler/mir:Range" } undef, i32 %t14, 0
  %t16 = load i32, ptr %l8, !tbaa !23
  %t17 = insertvalue { i32, i32, %"compiler/mir:Range" } %t15, i32 %t16, 1
  %t18 = load %"compiler/mir:Range", ptr %l12
  %t19 = insertvalue { i32, i32, %"compiler/mir:Range" } %t17, %"compiler/mir:Range" %t18, 2
  %t20 = getelementptr { i64, [15 x i64] }, ptr %t12, i32 0, i32 1
  store { i32, i32, %"compiler/mir:Range" } %t19, ptr %t20
  %t21 = load { i64, [15 x i64] }, ptr %t12
  %t23 = load ptr, ptr %l5, !tbaa !29
  %t24 = load i32, ptr %l6, !tbaa !23
  %t27 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %t23, i32 %t24, { i64, [15 x i64] } %t21, %"compiler/source:Span" %a4)
  store { i64, [4 x i64] } %t27, ptr %l15
  br label %bb2
bb2:
  %t28 = load { i64, [4 x i64] }, ptr %l15
  store { i64, [4 x i64] } %t28, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2epromote(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i32
  %l9 = alloca { i64, [1 x i64] }
  %l13 = alloca { i64, [4 x i64] }
  %l14 = alloca { i64, [1 x i64] }
  %l15 = alloca { i64, [4 x i64] }
  %l16 = alloca ptr
  %l21 = alloca i32
  %l22 = alloca ptr
  %l25 = alloca i32
  %l26 = alloca i1
  %l27 = alloca i1
  %l31 = alloca i1
  %l34 = alloca i64
  %l38 = alloca ptr
  %l39 = alloca i1
  %l47 = alloca i1
  %l51 = alloca i1
  %l62 = alloca ptr
  %l66 = alloca { i64, [1 x i64] }
  %l70 = alloca { i64, [4 x i64] }
  %l75 = alloca { i64, [4 x i64] }
  %l80 = alloca { i64, [4 x i64] }
  %l92 = alloca { i64, [4 x i64] }
  %l99 = alloca { i64, [1 x i64] }
  %l107 = alloca { i64, [4 x i64] }
  %l112 = alloca i1
  %l113 = alloca i1
  %l114 = alloca ptr
  %l117 = alloca i32
  %l118 = alloca i32
  %l121 = alloca i1
  %l122 = alloca ptr
  %l125 = alloca i32
  %l126 = alloca i1
  %l127 = alloca i1
  %l128 = alloca ptr
  %l131 = alloca i32
  %l132 = alloca i1
  %l133 = alloca ptr
  %l134 = alloca %"compiler/source:Span"
  %l135 = alloca { i64, [1 x i64] }
  %l138 = alloca i32
  %s6 = alloca %olang.scope
  %rv = alloca { i64, [4 x i64] }
  %t173 = alloca { i64, [4 x i64] }, align 8
  %t191 = alloca { i64, [15 x i64] }, align 8
  %t265 = alloca { i64, [21 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  store %"compiler/source:Span" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t7 = load i32, ptr %l2, !tbaa !23
  %t10 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2earrayOf(ptr %v0, ptr %t6, i32 %t7)
  store i32 %t10, ptr %l21
  br label %bb1
bb1:
  %t11 = load i32, ptr %l21, !tbaa !23
  store i32 %t11, ptr %l5, !tbaa !23
  %t12 = load ptr, ptr %l4, !tbaa !29
  store ptr %t12, ptr %l22, !tbaa !29
  %t13 = load ptr, ptr %l4, !tbaa !29
  %t14 = load i32, ptr %l2, !tbaa !23
  %t17 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t13, i32 %t14)
  store i32 %t17, ptr %l25
  br label %bb2
bb2:
  %t18 = load ptr, ptr %l22, !tbaa !29
  %t19 = load i32, ptr %l25, !tbaa !23
  %t20 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t18, i32 %t19)
  store i1 %t20, ptr %l26
  br label %bb3
bb3:
  %t21 = load i1, ptr %l26, !tbaa !21
  br i1 %t21, label %bb4, label %bb5
bb4:
  %t22 = load i32, ptr %l5, !tbaa !23
  %t23 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t26 = icmp ne i32 %t22, %t23
  store i1 %t26, ptr %l27, !tbaa !21
  br label %bb6
bb5:
  store i1 false, ptr %l27, !tbaa !21
  br label %bb6
bb6:
  %t28 = load i1, ptr %l27, !tbaa !21
  br i1 %t28, label %bb7, label %bb8
bb7:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t30 = load i32, ptr %l5, !tbaa !23
  %t33 = call i64 @compiler_2flower_2ecompiler_2flower_3alowering_2efixedLen(ptr %v0, ptr %t29, i32 %t30)
  store i64 %t33, ptr %l34
  br label %bb9
bb8:
  store i1 false, ptr %l31, !tbaa !21
  br label %bb10
bb9:
  %t34 = load i64, ptr %l34, !tbaa !24
  %t35 = icmp slt i64 %t34, 0
  store i1 %t35, ptr %l31, !tbaa !21
  br label %bb10
bb10:
  %t37 = load i1, ptr %l31, !tbaa !21
  br i1 %t37, label %bb11, label %bb12
bb11:
  %t38 = load ptr, ptr %l1, !tbaa !29
  %t40 = getelementptr %"compiler/typed:Promote", ptr %t38, i32 0, i32 0
  %t41 = load ptr, ptr %t40, !tbaa !29
  store ptr %t41, ptr %l6, !tbaa !29
  %t43 = load ptr, ptr %l6, !tbaa !29
  store ptr %t43, ptr %l38, !tbaa !29
  store i1 false, ptr %l39, !tbaa !21
  %t44 = load ptr, ptr %l38, !tbaa !29
  %t45 = icmp ne ptr %t44, null
  br i1 %t45, label %bb13, label %bb14
bb12:
  br label %bb39
bb13:
  %t47 = load ptr, ptr %l38, !tbaa !29
  %t48 = load i64, ptr %t47
  %t50 = icmp eq i64 %t48, 7
  store i1 %t50, ptr %l39, !tbaa !21
  br label %bb14
bb14:
  %t51 = load i1, ptr %l39, !tbaa !21
  br i1 %t51, label %bb15, label %bb16
bb15:
  %t52 = load ptr, ptr %l6, !tbaa !29
  %t54 = getelementptr { i64, [5 x i64] }, ptr %t52, i32 0, i32 1
  %t55 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t54, i32 0, i32 2
  %t56 = load ptr, ptr %t55
  store ptr %t56, ptr %l7, !tbaa !29
  br label %bb17
bb16:
  br label %bb33
bb17:
  %t58 = load ptr, ptr %l7, !tbaa !29
  %t60 = getelementptr %"compiler/typed:Make", ptr %t58, i32 0, i32 0
  %t61 = load i32, ptr %t60
  %t63 = trunc i64 3 to i32
  %t64 = icmp eq i32 %t61, %t63
  br i1 %t64, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l47, !tbaa !21
  br label %bb20
bb19:
  %t66 = load ptr, ptr %l7, !tbaa !29
  %t68 = getelementptr %"compiler/typed:Make", ptr %t66, i32 0, i32 0
  %t69 = load i32, ptr %t68
  %t71 = trunc i64 2 to i32
  %t72 = icmp eq i32 %t69, %t71
  store i1 %t72, ptr %l47, !tbaa !21
  br label %bb20
bb20:
  %t74 = load i1, ptr %l47, !tbaa !21
  br i1 %t74, label %bb21, label %bb22
bb21:
  %t75 = load ptr, ptr %l7, !tbaa !29
  %t77 = getelementptr %"compiler/typed:Make", ptr %t75, i32 0, i32 4
  %t78 = load i32, ptr %t77, !tbaa !23
  %t80 = icmp sge i32 %t78, 0
  store i1 %t80, ptr %l51, !tbaa !21
  br label %bb23
bb22:
  store i1 false, ptr %l51, !tbaa !21
  br label %bb23
bb23:
  %t82 = load i1, ptr %l51, !tbaa !21
  br i1 %t82, label %bb24, label %bb25
bb24:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr %"compiler/lower:lowering", ptr %t83, i32 0, i32 20
  %t86 = load i32, ptr %t85, !tbaa !23
  store i32 %t86, ptr %l8, !tbaa !23
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t90 = getelementptr %"compiler/lower:lowering", ptr %t88, i32 0, i32 21
  %t91 = load { i64, [1 x i64] }, ptr %t90
  store { i64, [1 x i64] } %t91, ptr %l9
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t94 = load ptr, ptr %l7, !tbaa !29
  %t96 = getelementptr %"compiler/typed:Make", ptr %t94, i32 0, i32 4
  %t97 = load i32, ptr %t96, !tbaa !23
  %t100 = getelementptr %"compiler/lower:lowering", ptr %t93, i32 0, i32 20
  store i32 %t97, ptr %t100, !tbaa !23
  %t101 = load ptr, ptr %l0, !tbaa !29
  store ptr %t101, ptr %l62, !tbaa !29
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t103 = load ptr, ptr %l1, !tbaa !29
  %t105 = getelementptr %"compiler/typed:Promote", ptr %t103, i32 0, i32 1
  %t106 = load i32, ptr %t105, !tbaa !23
  %t109 = call { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ebuilt(ptr %v0, ptr %t102, i32 %t106)
  store { i64, [1 x i64] } %t109, ptr %l66
  br label %bb26
bb25:
  br label %bb32
bb26:
  %t110 = load { i64, [1 x i64] }, ptr %l66
  %t111 = load ptr, ptr %l62, !tbaa !29
  %t112 = getelementptr %"compiler/lower:lowering", ptr %t111, i32 0, i32 21
  store { i64, [1 x i64] } %t110, ptr %t112
  %t113 = load ptr, ptr %l7, !tbaa !29
  %t115 = getelementptr %"compiler/typed:Make", ptr %t113, i32 0, i32 0
  %t116 = load i32, ptr %t115
  %t118 = trunc i64 3 to i32
  %t119 = icmp eq i32 %t116, %t118
  br i1 %t119, label %bb27, label %bb28
bb27:
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t122 = load ptr, ptr %l7, !tbaa !29
  %t123 = load i32, ptr %l2, !tbaa !23
  %t124 = load %"compiler/source:Span", ptr %l3
  %t129 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2efill(ptr %v0, ptr %v1, ptr %t121, ptr %t122, i32 %t123, %"compiler/source:Span" %t124)
  store { i64, [4 x i64] } %t129, ptr %l75
  br label %bb29
bb28:
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t131 = load ptr, ptr %l7, !tbaa !29
  %t132 = load i32, ptr %l2, !tbaa !23
  %t133 = load %"compiler/source:Span", ptr %l3
  %t138 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2earrayLit(ptr %v0, ptr %v1, ptr %t130, ptr %t131, i32 %t132, %"compiler/source:Span" %t133)
  store { i64, [4 x i64] } %t138, ptr %l80
  br label %bb30
bb29:
  %t139 = load { i64, [4 x i64] }, ptr %l75
  store { i64, [4 x i64] } %t139, ptr %l70
  br label %bb31
bb30:
  %t140 = load { i64, [4 x i64] }, ptr %l80
  store { i64, [4 x i64] } %t140, ptr %l70
  br label %bb31
bb31:
  %t141 = load { i64, [4 x i64] }, ptr %l70
  %t142 = load i32, ptr %l8, !tbaa !23
  %t144 = load { i64, [1 x i64] }, ptr %l9
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t150 = getelementptr %"compiler/lower:lowering", ptr %t146, i32 0, i32 20
  store i32 %t142, ptr %t150, !tbaa !23
  %t151 = load ptr, ptr %l0, !tbaa !29
  %t155 = getelementptr %"compiler/lower:lowering", ptr %t151, i32 0, i32 21
  store { i64, [1 x i64] } %t144, ptr %t155
  store { i64, [4 x i64] } %t141, ptr %rv
  br label %ret
bb32:
  br label %bb38
bb33:
  br i1 true, label %bb34, label %bb35
bb34:
  br label %bb36
bb35:
  br label %bb37
bb36:
  br label %bb38
bb37:
  call void @__olang_check_failed(ptr @olang_loc_f5162d6fd39a8c0b_7722e13858f6fdef)
  unreachable
bb38:
  br label %bb39
bb39:
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t159 = load ptr, ptr %l1, !tbaa !29
  %t161 = getelementptr %"compiler/typed:Promote", ptr %t159, i32 0, i32 0
  %t162 = load ptr, ptr %t161, !tbaa !29
  %t166 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v1, ptr %t158, ptr %t162)
  store { i64, [4 x i64] } %t166, ptr %l92
  br label %bb40
bb40:
  %t167 = load { i64, [4 x i64] }, ptr %l92
  store { i64, [4 x i64] } %t167, ptr %l13
  %t168 = load ptr, ptr %l0, !tbaa !29
  %t170 = getelementptr %"compiler/lower:lowering", ptr %t168, i32 0, i32 7
  %t171 = load i1, ptr %t170, !tbaa !21
  br i1 %t171, label %bb41, label %bb42
bb41:
  store { i64, [4 x i64] } zeroinitializer, ptr %t173
  %t174 = getelementptr { i64, [4 x i64] }, ptr %t173, i32 0, i32 0
  store i64 0, ptr %t174
  %t175 = load { i64, [4 x i64] }, ptr %t173
  store { i64, [4 x i64] } %t175, ptr %rv
  br label %ret
bb42:
  br label %bb43
bb43:
  %t177 = load ptr, ptr %l0, !tbaa !29
  %t178 = load ptr, ptr %l1, !tbaa !29
  %t180 = getelementptr %"compiler/typed:Promote", ptr %t178, i32 0, i32 1
  %t181 = load i32, ptr %t180, !tbaa !23
  %t184 = call { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ebuilt(ptr %v0, ptr %t177, i32 %t181)
  store { i64, [1 x i64] } %t184, ptr %l99
  br label %bb44
bb44:
  %t185 = load { i64, [1 x i64] }, ptr %l99
  store { i64, [1 x i64] } %t185, ptr %l14
  %t186 = load ptr, ptr %l0, !tbaa !29
  %t187 = load i32, ptr %l2, !tbaa !23
  %t188 = load { i64, [1 x i64] }, ptr %l14
  %t189 = load { i64, [4 x i64] }, ptr %l13
  %t190 = load i32, ptr %l2, !tbaa !23
  store { i64, [15 x i64] } zeroinitializer, ptr %t191
  %t192 = getelementptr { i64, [15 x i64] }, ptr %t191, i32 0, i32 0
  store i64 7, ptr %t192
  %t194 = insertvalue { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 } undef, { i64, [1 x i64] } %t188, 0
  %t196 = insertvalue { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 } %t194, { i64, [4 x i64] } %t189, 1
  %t198 = insertvalue { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 } %t196, i32 %t190, 2
  %t199 = getelementptr { i64, [15 x i64] }, ptr %t191, i32 0, i32 1
  store { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 } %t198, ptr %t199
  %t200 = load { i64, [15 x i64] }, ptr %t191
  %t201 = load %"compiler/source:Span", ptr %l3
  %t206 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %t186, i32 %t187, { i64, [15 x i64] } %t200, %"compiler/source:Span" %t201)
  store { i64, [4 x i64] } %t206, ptr %l107
  br label %bb45
bb45:
  %t207 = load { i64, [4 x i64] }, ptr %l107
  store { i64, [4 x i64] } %t207, ptr %l15
  %t208 = load ptr, ptr %l0, !tbaa !29
  %t210 = getelementptr %"compiler/lower:lowering", ptr %t208, i32 0, i32 2
  %t211 = load ptr, ptr %t210, !tbaa !29
  store ptr %t211, ptr %l16, !tbaa !29
  %t213 = load ptr, ptr %l16, !tbaa !29
  %t214 = load i32, ptr %l2, !tbaa !23
  %t217 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t213, i32 %t214)
  store i1 %t217, ptr %l112
  br label %bb46
bb46:
  %t218 = load i1, ptr %l112, !tbaa !21
  br i1 %t218, label %bb47, label %bb48
bb47:
  %t219 = load ptr, ptr %l16, !tbaa !29
  store ptr %t219, ptr %l114, !tbaa !29
  %t220 = load ptr, ptr %l16, !tbaa !29
  %t221 = load i32, ptr %l2, !tbaa !23
  %t224 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t220, i32 %t221)
  store i32 %t224, ptr %l117
  br label %bb49
bb48:
  store i1 false, ptr %l113, !tbaa !21
  br label %bb51
bb49:
  %t225 = load ptr, ptr %l114, !tbaa !29
  %t226 = load i32, ptr %l117, !tbaa !23
  %t227 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t225, i32 %t226)
  store i32 %t227, ptr %l118
  br label %bb50
bb50:
  %t228 = load i32, ptr %l118
  %t230 = trunc i64 18 to i32
  %t231 = icmp eq i32 %t228, %t230
  store i1 %t231, ptr %l113, !tbaa !21
  br label %bb51
bb51:
  %t233 = load i1, ptr %l113, !tbaa !21
  br i1 %t233, label %bb52, label %bb53
bb52:
  %t234 = load ptr, ptr %l16, !tbaa !29
  store ptr %t234, ptr %l122, !tbaa !29
  %t235 = load ptr, ptr %l16, !tbaa !29
  %t236 = load i32, ptr %l2, !tbaa !23
  %t239 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t235, i32 %t236)
  store i32 %t239, ptr %l125
  br label %bb54
bb53:
  store i1 false, ptr %l121, !tbaa !21
  br label %bb56
bb54:
  %t240 = load ptr, ptr %l122, !tbaa !29
  %t241 = load i32, ptr %l125, !tbaa !23
  %t242 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %t240, i32 %t241)
  store i1 %t242, ptr %l126
  br label %bb55
bb55:
  %t243 = load i1, ptr %l126, !tbaa !21
  store i1 %t243, ptr %l121, !tbaa !21
  br label %bb56
bb56:
  %t244 = load i1, ptr %l121, !tbaa !21
  br i1 %t244, label %bb57, label %bb58
bb57:
  %t245 = load ptr, ptr %l16, !tbaa !29
  store ptr %t245, ptr %l128, !tbaa !29
  %t246 = load ptr, ptr %l16, !tbaa !29
  %t247 = load i32, ptr %l2, !tbaa !23
  %t250 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t246, i32 %t247)
  store i32 %t250, ptr %l131
  br label %bb59
bb58:
  store i1 false, ptr %l127, !tbaa !21
  br label %bb61
bb59:
  %t251 = load ptr, ptr %l128, !tbaa !29
  %t252 = load i32, ptr %l131, !tbaa !23
  %t253 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDestructs(ptr %v0, ptr %t251, i32 %t252)
  store i1 %t253, ptr %l132
  br label %bb60
bb60:
  %t254 = load i1, ptr %l132, !tbaa !21
  store i1 %t254, ptr %l127, !tbaa !21
  br label %bb61
bb61:
  %t255 = load i1, ptr %l127, !tbaa !21
  br i1 %t255, label %bb62, label %bb63
bb62:
  store %olang.scope zeroinitializer, ptr %s6
  %t256 = load ptr, ptr %l0, !tbaa !29
  store ptr %t256, ptr %l133, !tbaa !29
  %t257 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t257, ptr %l134
  %t258 = load { i64, [1 x i64] }, ptr %l14
  store { i64, [1 x i64] } %t258, ptr %l135
  %t259 = load ptr, ptr %l16, !tbaa !29
  %t260 = load i32, ptr %l2, !tbaa !23
  %t263 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t259, i32 %t260)
  store i32 %t263, ptr %l138
  br label %bb64
bb63:
  br label %bb66
bb64:
  %t264 = load { i64, [4 x i64] }, ptr %l15
  store { i64, [21 x i64] } zeroinitializer, ptr %t265
  %t266 = getelementptr { i64, [21 x i64] }, ptr %t265, i32 0, i32 0
  store i64 6, ptr %t266
  %t267 = load %"compiler/source:Span", ptr %l134
  %t268 = insertvalue { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } undef, %"compiler/source:Span" %t267, 0
  %t269 = load { i64, [1 x i64] }, ptr %l135
  %t270 = insertvalue { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } %t268, { i64, [1 x i64] } %t269, 1
  %t271 = load i32, ptr %l138, !tbaa !23
  %t272 = insertvalue { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } %t270, i32 %t271, 2
  %t274 = insertvalue { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } %t272, { i64, [4 x i64] } %t264, 3
  %t275 = getelementptr { i64, [21 x i64] }, ptr %t265, i32 0, i32 1
  store { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } %t274, ptr %t275
  %t276 = load { i64, [21 x i64] }, ptr %t265
  %t278 = call ptr @__olang_scope_alloc_a(ptr %s6, i64 176, i64 8)
  store { i64, [21 x i64] } %t276, ptr %t278
  %t279 = load ptr, ptr %l133, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s6, ptr %t279, ptr %t278)
  br label %bb65
bb65:
  call void @__olang_scope_close(ptr %s6)
  br label %bb66
bb66:
  %t281 = load { i64, [4 x i64] }, ptr %l15
  store { i64, [4 x i64] } %t281, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2eraise(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, { i64, [4 x i64] } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l4 = alloca i1
  %l6 = alloca ptr
  %l12 = alloca i32
  %l13 = alloca { i64, ptr }
  %l25 = alloca i32
  %l32 = alloca ptr
  %l33 = alloca %"compiler/source:Span"
  %l35 = alloca %"compiler/mir:Place"
  %t29 = alloca { i64, [4 x i64] }, align 8
  %t32 = alloca { i64, [7 x i64] }, align 8
  %t74 = alloca { i64, [4 x i64] }, align 8
  %t80 = alloca { i64, [7 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l6, !tbaa !29
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/lower:lowering", ptr %t5, i32 0, i32 2
  %t8 = load ptr, ptr %t7, !tbaa !29
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/lower:lowering", ptr %t9, i32 0, i32 1
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t14 = getelementptr %"compiler/typed:Body", ptr %t12, i32 0, i32 2
  %t15 = load i32, ptr %t14, !tbaa !23
  %t18 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t8, i32 %t15)
  store i32 %t18, ptr %l12
  br label %bb1
bb1:
  %t19 = load ptr, ptr %l6, !tbaa !29
  %t20 = load i32, ptr %l12, !tbaa !23
  %t21 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t19, i32 %t20)
  store { i64, ptr } %t21, ptr %l13
  br label %bb2
bb2:
  %t22 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t22, 0
  %t25 = icmp eq i64 %t23, 0
  br i1 %t25, label %bb3, label %bb4
bb3:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load %"compiler/source:Span", ptr %l1
  store { i64, [4 x i64] } zeroinitializer, ptr %t29
  %t30 = getelementptr { i64, [4 x i64] }, ptr %t29, i32 0, i32 0
  store i64 0, ptr %t30
  %t31 = load { i64, [4 x i64] }, ptr %t29
  store { i64, [7 x i64] } zeroinitializer, ptr %t32
  %t33 = getelementptr { i64, [7 x i64] }, ptr %t32, i32 0, i32 0
  store i64 8, ptr %t33
  %t35 = insertvalue { %"compiler/source:Span", i32, { i64, [4 x i64] } } undef, %"compiler/source:Span" %t28, 0
  %t37 = insertvalue { %"compiler/source:Span", i32, { i64, [4 x i64] } } %t35, i32 3, 1
  %t39 = insertvalue { %"compiler/source:Span", i32, { i64, [4 x i64] } } %t37, { i64, [4 x i64] } %t31, 2
  %t40 = getelementptr { i64, [7 x i64] }, ptr %t32, i32 0, i32 1
  store { %"compiler/source:Span", i32, { i64, [4 x i64] } } %t39, ptr %t40
  %t41 = load { i64, [7 x i64] }, ptr %t32
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t27, { i64, [7 x i64] } %t41)
  br label %bb5
bb4:
  br label %bb6
bb5:
  br label %ret
bb6:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = load i32, ptr @G_2ecompiler_2fmir_2eI32T, !tbaa !23
  %t47 = load %"compiler/source:Span", ptr %l1
  %t52 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2elocal(ptr %v0, ptr %t44, { i64, [4 x i64] } %a2, i32 %t46, %"compiler/source:Span" %t47)
  store i32 %t52, ptr %l25
  br label %bb7
bb7:
  %t53 = load i32, ptr %l25, !tbaa !23
  store i32 %t53, ptr %l3, !tbaa !23
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/lower:lowering", ptr %t54, i32 0, i32 18
  %t57 = load i1, ptr %t56, !tbaa !21
  store i1 %t57, ptr %l4, !tbaa !21
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/lower:lowering", ptr %t59, i32 0, i32 18
  store i1 true, ptr %t61, !tbaa !21
  %t62 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eleave(ptr %v0, ptr %t62, i64 0)
  br label %bb8
bb8:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t65 = load i1, ptr %l4, !tbaa !21
  %t68 = getelementptr %"compiler/lower:lowering", ptr %t64, i32 0, i32 18
  store i1 %t65, ptr %t68, !tbaa !21
  %t69 = load ptr, ptr %l0, !tbaa !29
  store ptr %t69, ptr %l32, !tbaa !29
  %t70 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t70, ptr %l33
  %t71 = load i32, ptr %l3, !tbaa !23
  %t73 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t71)
  store %"compiler/mir:Place" %t73, ptr %l35
  br label %bb9
bb9:
  store { i64, [4 x i64] } zeroinitializer, ptr %t74
  %t75 = getelementptr { i64, [4 x i64] }, ptr %t74, i32 0, i32 0
  store i64 1, ptr %t75
  %t76 = load %"compiler/mir:Place", ptr %l35
  %t77 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t76, 0
  %t78 = getelementptr { i64, [4 x i64] }, ptr %t74, i32 0, i32 1
  store { %"compiler/mir:Place" } %t77, ptr %t78
  %t79 = load { i64, [4 x i64] }, ptr %t74
  store { i64, [7 x i64] } zeroinitializer, ptr %t80
  %t81 = getelementptr { i64, [7 x i64] }, ptr %t80, i32 0, i32 0
  store i64 6, ptr %t81
  %t82 = load %"compiler/source:Span", ptr %l33
  %t83 = insertvalue { %"compiler/source:Span", { i64, [4 x i64] } } undef, %"compiler/source:Span" %t82, 0
  %t85 = insertvalue { %"compiler/source:Span", { i64, [4 x i64] } } %t83, { i64, [4 x i64] } %t79, 1
  %t86 = getelementptr { i64, [7 x i64] }, ptr %t80, i32 0, i32 1
  store { %"compiler/source:Span", { i64, [4 x i64] } } %t85, ptr %t86
  %t87 = load { i64, [7 x i64] }, ptr %t80
  %t88 = load ptr, ptr %l32, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t88, { i64, [7 x i64] } %t87)
  br label %bb10
bb10:
  br label %ret
ret:
  ret void
}

define dso_local { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eread(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca %"compiler/lower:pl"
  %l8 = alloca %"compiler/lower:pl"
  %l12 = alloca ptr
  %l13 = alloca i32
  %l16 = alloca %"compiler/mir:Place"
  %l20 = alloca { i64, [4 x i64] }
  %rv = alloca { i64, [4 x i64] }
  %t13 = alloca { i64, [4 x i64] }, align 8
  %t24 = alloca { i64, [4 x i64] }, align 8
  %t30 = alloca { i64, [15 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t6 = call %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2eplace(ptr %v0, ptr %v1, ptr %v0, ptr %t1, ptr %a1)
  store %"compiler/lower:pl" %t6, ptr %l8
  br label %bb1
bb1:
  %t7 = load %"compiler/lower:pl", ptr %l8
  store %"compiler/lower:pl" %t7, ptr %l4
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/lower:lowering", ptr %t8, i32 0, i32 7
  %t11 = load i1, ptr %t10, !tbaa !21
  br i1 %t11, label %bb2, label %bb3
bb2:
  store { i64, [4 x i64] } zeroinitializer, ptr %t13
  %t14 = getelementptr { i64, [4 x i64] }, ptr %t13, i32 0, i32 0
  store i64 0, ptr %t14
  %t15 = load { i64, [4 x i64] }, ptr %t13
  store { i64, [4 x i64] } %t15, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t17 = load ptr, ptr %l0, !tbaa !29
  store ptr %t17, ptr %l12, !tbaa !29
  store i32 %a2, ptr %l13, !tbaa !23
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t20 = load %"compiler/lower:pl", ptr %l4
  %t23 = call %"compiler/mir:Place" @compiler_2flower_2ecompiler_2flower_3alowering_2emk(ptr %v0, ptr %v0, ptr %t19, %"compiler/lower:pl" %t20)
  store %"compiler/mir:Place" %t23, ptr %l16
  br label %bb5
bb5:
  store { i64, [4 x i64] } zeroinitializer, ptr %t24
  %t25 = getelementptr { i64, [4 x i64] }, ptr %t24, i32 0, i32 0
  store i64 1, ptr %t25
  %t26 = load %"compiler/mir:Place", ptr %l16
  %t27 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t26, 0
  %t28 = getelementptr { i64, [4 x i64] }, ptr %t24, i32 0, i32 1
  store { %"compiler/mir:Place" } %t27, ptr %t28
  %t29 = load { i64, [4 x i64] }, ptr %t24
  store { i64, [15 x i64] } zeroinitializer, ptr %t30
  %t31 = getelementptr { i64, [15 x i64] }, ptr %t30, i32 0, i32 0
  store i64 0, ptr %t31
  %t33 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t29, 0
  %t34 = getelementptr { i64, [15 x i64] }, ptr %t30, i32 0, i32 1
  store { { i64, [4 x i64] } } %t33, ptr %t34
  %t35 = load { i64, [15 x i64] }, ptr %t30
  %t37 = load ptr, ptr %l12, !tbaa !29
  %t38 = load i32, ptr %l13, !tbaa !23
  %t41 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %t37, i32 %t38, { i64, [15 x i64] } %t35, %"compiler/source:Span" %a3)
  store { i64, [4 x i64] } %t41, ptr %l20
  br label %bb6
bb6:
  %t42 = load { i64, [4 x i64] }, ptr %l20
  store { i64, [4 x i64] } %t42, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local i32 @compiler_2flower_2ecompiler_2flower_3alowering_2ereadOnly(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l1 = alloca i32
  %l2 = alloca ptr
  %l7 = alloca i1
  %l8 = alloca ptr
  %l11 = alloca i32
  %l14 = alloca i64
  %l18 = alloca i32
  %rv = alloca i32
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/lower:lowering", ptr %a0, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t7 = load i32, ptr %l1, !tbaa !23
  %t10 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t6, i32 %t7)
  store i1 %t10, ptr %l7
  br label %bb1
bb1:
  %t11 = load i1, ptr %l7, !tbaa !21
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t12 = load ptr, ptr %l2, !tbaa !29
  store ptr %t12, ptr %l8, !tbaa !29
  %t13 = load ptr, ptr %l2, !tbaa !29
  %t14 = load i32, ptr %l1, !tbaa !23
  %t17 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t13, i32 %t14)
  store i32 %t17, ptr %l11
  br label %bb4
bb3:
  br label %bb7
bb4:
  %t18 = load ptr, ptr %l2, !tbaa !29
  %t19 = load i32, ptr %l1, !tbaa !23
  %t22 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t18, i32 %t19)
  store i64 %t22, ptr %l14
  br label %bb5
bb5:
  %t23 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t25 = sub i64 -1, %t23
  %t26 = load i64, ptr %l14, !tbaa !24
  %t28 = and i64 %t26, %t25
  %t29 = load ptr, ptr %l8, !tbaa !29
  %t30 = load i32, ptr %l11, !tbaa !23
  %t32 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t29, i32 %t30, i64 %t28)
  store i32 %t32, ptr %l18
  br label %bb6
bb6:
  %t33 = load i32, ptr %l18, !tbaa !23
  store i32 %t33, ptr %rv
  br label %ret
bb7:
  %t34 = load i32, ptr %l1, !tbaa !23
  store i32 %t34, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2erefTo(ptr %v0, ptr %v1, ptr %a0, %"compiler/lower:pl" %a1, i32 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca i32
  %l9 = alloca i32
  %l10 = alloca ptr
  %l11 = alloca i32
  %l14 = alloca %"compiler/mir:Place"
  %l18 = alloca { i64, [4 x i64] }
  %rv = alloca { i64, [4 x i64] }
  %t20 = alloca { i64, [15 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t4, i32 %a2, i64 %t6)
  store i32 %t10, ptr %l9
  br label %bb1
bb1:
  %t11 = load i32, ptr %l9, !tbaa !23
  store i32 %t11, ptr %l4, !tbaa !23
  %t12 = load ptr, ptr %l0, !tbaa !29
  store ptr %t12, ptr %l10, !tbaa !29
  %t13 = load i32, ptr %l4, !tbaa !23
  store i32 %t13, ptr %l11, !tbaa !23
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t18 = call %"compiler/mir:Place" @compiler_2flower_2ecompiler_2flower_3alowering_2emk(ptr %v0, ptr %v1, ptr %t14, %"compiler/lower:pl" %a1)
  store %"compiler/mir:Place" %t18, ptr %l14
  br label %bb2
bb2:
  %t19 = load i32, ptr %l4, !tbaa !23
  store { i64, [15 x i64] } zeroinitializer, ptr %t20
  %t21 = getelementptr { i64, [15 x i64] }, ptr %t20, i32 0, i32 0
  store i64 1, ptr %t21
  %t22 = load %"compiler/mir:Place", ptr %l14
  %t23 = insertvalue { %"compiler/mir:Place", i32 } undef, %"compiler/mir:Place" %t22, 0
  %t25 = insertvalue { %"compiler/mir:Place", i32 } %t23, i32 %t19, 1
  %t26 = getelementptr { i64, [15 x i64] }, ptr %t20, i32 0, i32 1
  store { %"compiler/mir:Place", i32 } %t25, ptr %t26
  %t27 = load { i64, [15 x i64] }, ptr %t20
  %t29 = load ptr, ptr %l10, !tbaa !29
  %t30 = load i32, ptr %l11, !tbaa !23
  %t33 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %t29, i32 %t30, { i64, [15 x i64] } %t27, %"compiler/source:Span" %a3)
  store { i64, [4 x i64] } %t33, ptr %l18
  br label %bb3
bb3:
  %t34 = load { i64, [4 x i64] }, ptr %l18
  store { i64, [4 x i64] } %t34, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2erender(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1, { i64, [4 x i64] } %a2, i32 %a3, %"compiler/source:Span" %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [1 x i64] }
  %l2 = alloca { i64, [4 x i64] }
  %l3 = alloca i32
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i1
  %l9 = alloca i32
  %l10 = alloca { i64, [4 x i64] }
  %l11 = alloca { i64, [5 x i64] }
  %l12 = alloca i32
  %l19 = alloca i1
  %l24 = alloca i32
  %l28 = alloca i1
  %l31 = alloca i1
  %l39 = alloca i1
  %l43 = alloca i1
  %l47 = alloca i1
  %l51 = alloca i1
  %l65 = alloca i32
  %l69 = alloca i32
  %l70 = alloca ptr
  %l71 = alloca ptr
  %l74 = alloca i32
  %l75 = alloca { i64, ptr }
  %l76 = alloca { i64, ptr }
  %l77 = alloca i32
  %l82 = alloca i32
  %l83 = alloca %"compiler/mir:Place"
  %l84 = alloca ptr
  %l87 = alloca i32
  %l88 = alloca { i64, ptr }
  %l89 = alloca { i64, ptr }
  %l93 = alloca { i64, [4 x i64] }
  %l106 = alloca i32
  %l108 = alloca ptr
  %l109 = alloca { i64, [5 x i64] }
  %l111 = alloca ptr
  %l112 = alloca { i64, [4 x i64] }
  %l114 = alloca { i64, [4 x i64] }
  %l118 = alloca %"compiler/mir:Range"
  %l125 = alloca %"compiler/mir:Range"
  %l130 = alloca %"compiler/mir:Call"
  %l131 = alloca i32
  %s0 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %t80 = alloca { i64, [21 x i64] }, align 8
  %t153 = alloca { i64, [15 x i64] }, align 8
  %t169 = alloca { i64, [1 x i64] }, align 8
  %t178 = alloca { i64, [5 x i64] }, align 8
  %t192 = alloca { i64, [1 x i64] }, align 8
  %t278 = alloca { i64, [7 x i64] }, align 8
  store ptr %a0, ptr %l0
  store { i64, [1 x i64] } %a1, ptr %l1
  store { i64, [4 x i64] } %a2, ptr %l2
  store i32 %a3, ptr %l3
  store %"compiler/source:Span" %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l5, !tbaa !29
  %t6 = load i32, ptr %l3, !tbaa !23
  %t7 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t10 = icmp eq i32 %t6, %t7
  br i1 %t10, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l19, !tbaa !21
  br label %bb3
bb2:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/lower:lowering", ptr %t12, i32 0, i32 8
  %t15 = load i1, ptr %t14, !tbaa !21
  store i1 %t15, ptr %l19, !tbaa !21
  br label %bb3
bb3:
  %t17 = load i1, ptr %l19, !tbaa !21
  br i1 %t17, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb5:
  br label %bb6
bb6:
  %t18 = load ptr, ptr %l5, !tbaa !29
  %t19 = load i32, ptr %l3, !tbaa !23
  %t22 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t18, i32 %t19)
  store i32 %t22, ptr %l24
  br label %bb7
bb7:
  %t23 = load i32, ptr %l24, !tbaa !23
  store i32 %t23, ptr %l6, !tbaa !23
  store i32 7, ptr %l7
  store i1 true, ptr %l8, !tbaa !21
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t26 = load i32, ptr %l3, !tbaa !23
  %t29 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2ehasStr(ptr %v0, ptr %t25, i32 %t26)
  store i1 %t29, ptr %l28
  br label %bb8
bb8:
  %t30 = load i1, ptr %l28, !tbaa !21
  br i1 %t30, label %bb9, label %bb10
bb9:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb34
bb10:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load i32, ptr %l3, !tbaa !23
  %t35 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eisChar(ptr %v0, ptr %t31, i32 %t32)
  store i1 %t35, ptr %l31
  br label %bb11
bb11:
  %t36 = load i1, ptr %l31, !tbaa !21
  br i1 %t36, label %bb12, label %bb13
bb12:
  store i32 2, ptr %l7
  br label %bb33
bb13:
  %t38 = load i32, ptr %l6, !tbaa !23
  %t39 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t42 = icmp eq i32 %t38, %t39
  br i1 %t42, label %bb14, label %bb15
bb14:
  store i32 7, ptr %l7
  br label %bb32
bb15:
  %t45 = load ptr, ptr %l5, !tbaa !29
  %t46 = load i32, ptr %l6, !tbaa !23
  %t49 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %t45, i32 %t46)
  store i1 %t49, ptr %l39
  br label %bb16
bb16:
  %t50 = load i1, ptr %l39, !tbaa !21
  br i1 %t50, label %bb17, label %bb18
bb17:
  store i32 5, ptr %l7
  br label %bb31
bb18:
  %t52 = load ptr, ptr %l5, !tbaa !29
  %t53 = load i32, ptr %l6, !tbaa !23
  %t56 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %t52, i32 %t53)
  store i1 %t56, ptr %l43
  br label %bb19
bb19:
  %t57 = load i1, ptr %l43, !tbaa !21
  br i1 %t57, label %bb20, label %bb21
bb20:
  store i32 4, ptr %l7
  br label %bb30
bb21:
  %t59 = load ptr, ptr %l5, !tbaa !29
  %t60 = load i32, ptr %l6, !tbaa !23
  %t63 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %t59, i32 %t60)
  store i1 %t63, ptr %l47
  br label %bb22
bb22:
  %t64 = load i1, ptr %l47, !tbaa !21
  br i1 %t64, label %bb23, label %bb24
bb23:
  store i32 6, ptr %l7
  br label %bb29
bb24:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t67 = load i32, ptr %l3, !tbaa !23
  %t70 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eisText(ptr %v0, ptr %t66, i32 %t67)
  store i1 %t70, ptr %l51
  br label %bb25
bb25:
  %t71 = load i1, ptr %l51, !tbaa !21
  br i1 %t71, label %bb26, label %bb27
bb26:
  store i32 0, ptr %l7
  br label %bb28
bb27:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb28
bb28:
  br label %bb29
bb29:
  br label %bb30
bb30:
  br label %bb31
bb31:
  br label %bb32
bb32:
  br label %bb33
bb33:
  br label %bb34
bb34:
  %t73 = load i1, ptr %l8, !tbaa !21
  br i1 %t73, label %bb35, label %bb36
bb35:
  store %olang.scope zeroinitializer, ptr %s16
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t76 = load %"compiler/source:Span", ptr %l4
  %t77 = load { i64, [1 x i64] }, ptr %l1
  %t78 = load i32, ptr %l7
  %t79 = load { i64, [4 x i64] }, ptr %l2
  store { i64, [21 x i64] } zeroinitializer, ptr %t80
  %t81 = getelementptr { i64, [21 x i64] }, ptr %t80, i32 0, i32 0
  store i64 9, ptr %t81
  %t83 = insertvalue { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } undef, %"compiler/source:Span" %t76, 0
  %t85 = insertvalue { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } %t83, { i64, [1 x i64] } %t77, 1
  %t87 = insertvalue { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } %t85, i32 %t78, 2
  %t89 = insertvalue { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } %t87, { i64, [4 x i64] } %t79, 3
  %t90 = getelementptr { i64, [21 x i64] }, ptr %t80, i32 0, i32 1
  store { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } %t89, ptr %t90
  %t91 = load { i64, [21 x i64] }, ptr %t80
  %t93 = call ptr @__olang_scope_alloc_a(ptr %s16, i64 176, i64 8)
  store { i64, [21 x i64] } %t91, ptr %t93
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s16, ptr %t75, ptr %t93)
  br label %bb37
bb36:
  br label %bb38
bb37:
  call void @__olang_scope_close(ptr %s16)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb38:
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"compiler/lower:lowering", ptr %t96, i32 0, i32 0
  %t99 = load ptr, ptr %t98, !tbaa !29
  %t100 = load i32, ptr %l3, !tbaa !23
  %t104 = call i32 @compiler_2flower_2ecompiler_2flower_3aLowerer_2ehelperTy(ptr %v0, ptr %t99, i32 0, i32 %t100)
  store i32 %t104, ptr %l65
  br label %bb39
bb39:
  %t105 = load i32, ptr %l65, !tbaa !23
  store i32 %t105, ptr %l3, !tbaa !23
  %t106 = load ptr, ptr %l5, !tbaa !29
  %t107 = load i32, ptr %l3, !tbaa !23
  %t111 = call i32 @compiler_2fmir_2eHelperType(ptr %v0, ptr %t106, i32 0, i32 %t107)
  store i32 %t111, ptr %l69
  br label %bb40
bb40:
  %t112 = load i32, ptr %l69, !tbaa !23
  store i32 %t112, ptr %l9, !tbaa !23
  %t113 = load ptr, ptr %l0, !tbaa !29
  store ptr %t113, ptr %l70, !tbaa !29
  %t114 = load ptr, ptr %l5, !tbaa !29
  store ptr %t114, ptr %l71, !tbaa !29
  %t115 = load ptr, ptr %l5, !tbaa !29
  %t116 = load i32, ptr %l9, !tbaa !23
  %t119 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t115, i32 %t116)
  store i32 %t119, ptr %l74
  br label %bb41
bb41:
  %t120 = load ptr, ptr %l71, !tbaa !29
  %t121 = load i32, ptr %l74, !tbaa !23
  %t122 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t120, i32 %t121)
  store { i64, ptr } %t122, ptr %l75
  br label %bb42
bb42:
  %t123 = load { i64, ptr }, ptr %l75, !tbaa !27
  store { i64, ptr } %t123, ptr %l76, !tbaa !27
  %t124 = getelementptr { i64, ptr }, ptr %l76, i32 0, i32 1
  %t125 = load ptr, ptr %t124, !tbaa !27
  %t126 = getelementptr i32, ptr %t125, i64 0
  %t127 = load i32, ptr %t126, !tbaa !33
  store i32 %t127, ptr %l77, !tbaa !23
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t129 = load { i64, [4 x i64] }, ptr %l2
  %t130 = load i32, ptr %l3, !tbaa !23
  %t131 = load %"compiler/source:Span", ptr %l4
  %t136 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2elocal(ptr %v0, ptr %t128, { i64, [4 x i64] } %t129, i32 %t130, %"compiler/source:Span" %t131)
  store i32 %t136, ptr %l82
  br label %bb43
bb43:
  %t137 = load i32, ptr %l82, !tbaa !23
  %t138 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t137)
  store %"compiler/mir:Place" %t138, ptr %l83
  br label %bb44
bb44:
  %t139 = load ptr, ptr %l5, !tbaa !29
  store ptr %t139, ptr %l84, !tbaa !29
  %t140 = load ptr, ptr %l5, !tbaa !29
  %t141 = load i32, ptr %l9, !tbaa !23
  %t144 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t140, i32 %t141)
  store i32 %t144, ptr %l87
  br label %bb45
bb45:
  %t145 = load ptr, ptr %l84, !tbaa !29
  %t146 = load i32, ptr %l87, !tbaa !23
  %t147 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t145, i32 %t146)
  store { i64, ptr } %t147, ptr %l88
  br label %bb46
bb46:
  %t148 = load { i64, ptr }, ptr %l88, !tbaa !27
  store { i64, ptr } %t148, ptr %l89, !tbaa !27
  %t149 = getelementptr { i64, ptr }, ptr %l89, i32 0, i32 1
  %t150 = load ptr, ptr %t149, !tbaa !27
  %t151 = getelementptr i32, ptr %t150, i64 0
  %t152 = load i32, ptr %t151, !tbaa !33
  store { i64, [15 x i64] } zeroinitializer, ptr %t153
  %t154 = getelementptr { i64, [15 x i64] }, ptr %t153, i32 0, i32 0
  store i64 1, ptr %t154
  %t155 = load %"compiler/mir:Place", ptr %l83
  %t156 = insertvalue { %"compiler/mir:Place", i32 } undef, %"compiler/mir:Place" %t155, 0
  %t158 = insertvalue { %"compiler/mir:Place", i32 } %t156, i32 %t152, 1
  %t159 = getelementptr { i64, [15 x i64] }, ptr %t153, i32 0, i32 1
  store { %"compiler/mir:Place", i32 } %t158, ptr %t159
  %t160 = load { i64, [15 x i64] }, ptr %t153
  %t161 = load %"compiler/source:Span", ptr %l4
  %t162 = load ptr, ptr %l70, !tbaa !29
  %t163 = load i32, ptr %l77, !tbaa !23
  %t166 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %t162, i32 %t163, { i64, [15 x i64] } %t160, %"compiler/source:Span" %t161)
  store { i64, [4 x i64] } %t166, ptr %l93
  br label %bb47
bb47:
  %t167 = load { i64, [4 x i64] }, ptr %l93
  store { i64, [4 x i64] } %t167, ptr %l10
  %t168 = load i32, ptr %l3, !tbaa !23
  store { i64, [1 x i64] } zeroinitializer, ptr %t169
  %t170 = getelementptr { i64, [1 x i64] }, ptr %t169, i32 0, i32 0
  store i64 2, ptr %t170
  %t172 = insertvalue { i32, i32 } undef, i32 0, 0
  %t174 = insertvalue { i32, i32 } %t172, i32 %t168, 1
  %t175 = getelementptr { i64, [1 x i64] }, ptr %t169, i32 0, i32 1
  store { i32, i32 } %t174, ptr %t175
  %t176 = load { i64, [1 x i64] }, ptr %t169
  %t177 = load i32, ptr %l9, !tbaa !23
  store { i64, [5 x i64] } zeroinitializer, ptr %t178
  %t179 = getelementptr { i64, [5 x i64] }, ptr %t178, i32 0, i32 0
  store i64 0, ptr %t179
  %t181 = insertvalue { { i64, [1 x i64] }, i32 } undef, { i64, [1 x i64] } %t176, 0
  %t183 = insertvalue { { i64, [1 x i64] }, i32 } %t181, i32 %t177, 1
  %t184 = getelementptr { i64, [5 x i64] }, ptr %t178, i32 0, i32 1
  store { { i64, [1 x i64] }, i32 } %t183, ptr %t184
  %t185 = load { i64, [5 x i64] }, ptr %t178
  store { i64, [5 x i64] } %t185, ptr %l11
  %t187 = load ptr, ptr %l0, !tbaa !29
  %t189 = getelementptr %"compiler/lower:lowering", ptr %t187, i32 0, i32 0
  %t190 = load ptr, ptr %t189, !tbaa !29
  %t191 = load i32, ptr %l3, !tbaa !23
  store { i64, [1 x i64] } zeroinitializer, ptr %t192
  %t193 = getelementptr { i64, [1 x i64] }, ptr %t192, i32 0, i32 0
  store i64 2, ptr %t193
  %t195 = insertvalue { i32, i32 } undef, i32 0, 0
  %t197 = insertvalue { i32, i32 } %t195, i32 %t191, 1
  %t198 = getelementptr { i64, [1 x i64] }, ptr %t192, i32 0, i32 1
  store { i32, i32 } %t197, ptr %t198
  %t199 = load { i64, [1 x i64] }, ptr %t192
  call void @compiler_2flower_2ecompiler_2flower_3aLowerer_2eWant(ptr %v0, ptr %t190, { i64, [1 x i64] } %t199)
  br label %bb48
bb48:
  %t202 = load ptr, ptr %l0, !tbaa !29
  %t204 = getelementptr %"compiler/lower:lowering", ptr %t202, i32 0, i32 3
  %t206 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t204)
  store i32 %t206, ptr %l106
  br label %bb49
bb49:
  %t207 = load i32, ptr %l106, !tbaa !23
  store i32 %t207, ptr %l12, !tbaa !23
  %t208 = load ptr, ptr %l0, !tbaa !29
  %t210 = getelementptr %"compiler/lower:lowering", ptr %t208, i32 0, i32 3
  store ptr %t210, ptr %l108, !tbaa !29
  %t211 = load { i64, [5 x i64] }, ptr %l11
  store { i64, [5 x i64] } %t211, ptr %l109
  %t212 = load ptr, ptr %l0, !tbaa !29
  %t214 = getelementptr %"compiler/lower:lowering", ptr %t212, i32 0, i32 3
  store ptr %t214, ptr %l111, !tbaa !29
  %t215 = load { i64, [4 x i64] }, ptr %l10
  store { i64, [4 x i64] } %t215, ptr %l112
  %t216 = load ptr, ptr %l0, !tbaa !29
  %t218 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2edepth(ptr %v0, ptr %t216)
  store { i64, [4 x i64] } %t218, ptr %l114
  br label %bb50
bb50:
  %t219 = load { i64, [4 x i64] }, ptr %l112
  %t220 = insertvalue [2 x { i64, [4 x i64] }] undef, { i64, [4 x i64] } %t219, 0
  %t221 = load { i64, [4 x i64] }, ptr %l114
  %t222 = insertvalue [2 x { i64, [4 x i64] }] %t220, { i64, [4 x i64] } %t221, 1
  %t224 = load ptr, ptr @__olang_prog_scope
  %t225 = call ptr @__olang_scope_alloc(ptr %t224, i64 80)
  store [2 x { i64, [4 x i64] }] %t222, ptr %t225
  %t226 = insertvalue { i64, ptr } undef, i64 2, 0
  %t227 = insertvalue { i64, ptr } %t226, ptr %t225, 1
  %t229 = extractvalue { i64, ptr } %t227, 0
  %t230 = extractvalue { i64, ptr } %t227, 1
  %t231 = mul i64 %t229, 40
  %t232 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t231)
  call void @llvm.memcpy.p0.p0.i64(ptr %t232, ptr %t230, i64 %t231, i1 false)
  %t233 = insertvalue { i64, ptr } undef, i64 %t229, 0
  %t234 = insertvalue { i64, ptr } %t233, ptr %t232, 1
  %t235 = load ptr, ptr %l111, !tbaa !29
  %t237 = call %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eArgs(ptr %v0, ptr %s0, ptr %t235, { i64, ptr } %t234)
  store %"compiler/mir:Range" %t237, ptr %l118
  br label %bb51
bb51:
  %t238 = load ptr, ptr %l0, !tbaa !29
  %t240 = getelementptr %"compiler/lower:lowering", ptr %t238, i32 0, i32 3
  %t241 = load { i64, [1 x i64] }, ptr %l1
  %t243 = insertvalue [1 x { i64, [1 x i64] }] undef, { i64, [1 x i64] } %t241, 0
  %t245 = load ptr, ptr @__olang_prog_scope
  %t246 = call ptr @__olang_scope_alloc(ptr %t245, i64 16)
  store [1 x { i64, [1 x i64] }] %t243, ptr %t246
  %t247 = insertvalue { i64, ptr } undef, i64 1, 0
  %t248 = insertvalue { i64, ptr } %t247, ptr %t246, 1
  %t250 = extractvalue { i64, ptr } %t248, 0
  %t251 = extractvalue { i64, ptr } %t248, 1
  %t252 = mul i64 %t250, 16
  %t253 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t252)
  call void @llvm.memcpy.p0.p0.i64(ptr %t253, ptr %t251, i64 %t252, i1 false)
  %t254 = insertvalue { i64, ptr } undef, i64 %t250, 0
  %t255 = insertvalue { i64, ptr } %t254, ptr %t253, 1
  %t258 = call %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eScopeRefs(ptr %v0, ptr %s0, ptr %t240, { i64, ptr } %t255)
  store %"compiler/mir:Range" %t258, ptr %l125
  br label %bb52
bb52:
  %t259 = load %"compiler/mir:Place", ptr @G_2ecompiler_2fmir_2eNoPlace
  %t260 = load i32, ptr %l12, !tbaa !23
  %t261 = load i32, ptr @G_2ecompiler_2fmir_2eNoLocal, !tbaa !23
  %t262 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t263 = load { i64, [5 x i64] }, ptr %l109
  %t264 = load %"compiler/mir:Range", ptr %l118
  %t265 = load %"compiler/mir:Range", ptr %l125
  %t270 = call %"compiler/mir:Call" @compiler_2fmir_3aCall_2ector(ptr %s0, { i64, [5 x i64] } %t263, %"compiler/mir:Range" %t264, %"compiler/mir:Range" %t265, %"compiler/mir:Place" %t259, i1 false, i32 %t260, i32 %t261, i32 %t262)
  store %"compiler/mir:Call" %t270, ptr %l130
  br label %bb53
bb53:
  %t271 = load ptr, ptr %l108, !tbaa !29
  %t272 = load %"compiler/mir:Call", ptr %l130
  %t273 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddCall(ptr %v0, ptr %t271, %"compiler/mir:Call" %t272)
  store i32 %t273, ptr %l131
  br label %bb54
bb54:
  %t274 = load i32, ptr %l131, !tbaa !23
  %t275 = load ptr, ptr %l0, !tbaa !29
  %t276 = load %"compiler/source:Span", ptr %l4
  store { i64, [7 x i64] } zeroinitializer, ptr %t278
  %t279 = getelementptr { i64, [7 x i64] }, ptr %t278, i32 0, i32 0
  store i64 4, ptr %t279
  %t281 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t276, 0
  %t283 = insertvalue { %"compiler/source:Span", i32 } %t281, i32 %t274, 1
  %t284 = getelementptr { i64, [7 x i64] }, ptr %t278, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t283, ptr %t284
  %t285 = load { i64, [7 x i64] }, ptr %t278
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t275, { i64, [7 x i64] } %t285)
  br label %bb55
bb55:
  %t288 = load ptr, ptr %l0, !tbaa !29
  %t289 = load i32, ptr %l12, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t288, i32 %t289)
  br label %bb56
bb56:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eretCopies(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca i64
  %l18 = alloca ptr
  %l19 = alloca ptr
  %l20 = alloca i64
  %l21 = alloca { i64, ptr }
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca %"compiler/lower:level"
  %l25 = alloca ptr
  %l26 = alloca i32
  %l32 = alloca i1
  %l33 = alloca ptr
  %l34 = alloca i1
  %l43 = alloca i1
  %l44 = alloca i1
  %l50 = alloca i1
  %l51 = alloca ptr
  %l52 = alloca i1
  %l65 = alloca { i64, ptr }
  %l72 = alloca i1
  %l80 = alloca i1
  %l81 = alloca ptr
  %l90 = alloca i1
  %l91 = alloca ptr
  %l92 = alloca i1
  %l101 = alloca i1
  %l111 = alloca { i64, ptr }
  %l122 = alloca { i64, ptr }
  %l129 = alloca i1
  %l136 = alloca ptr
  %l137 = alloca i1
  %l146 = alloca i1
  %l150 = alloca i1
  %l155 = alloca i64
  %l160 = alloca { i64, ptr }
  %l163 = alloca { i64, ptr }
  %l164 = alloca i32
  %l173 = alloca { i64, ptr }
  %l184 = alloca ptr
  %l185 = alloca i1
  %l190 = alloca ptr
  %l191 = alloca i1
  %l200 = alloca %"compiler/mir:Local"
  %l201 = alloca { i64, [1 x i64] }
  %l202 = alloca ptr
  %l204 = alloca { i64, [1 x i64] }
  %l206 = alloca i1
  %s6 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %s24 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t7 = load i32, ptr %l2, !tbaa !23
  %t10 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2evalueArray(ptr %v0, ptr %t6, i32 %t7)
  store i1 %t10, ptr %l32
  br label %bb4
bb4:
  %t11 = load i1, ptr %l32, !tbaa !21
  br i1 %t11, label %bb5, label %bb6
bb5:
  %t12 = load ptr, ptr %l1, !tbaa !29
  store ptr %t12, ptr %l33, !tbaa !29
  store i1 false, ptr %l34, !tbaa !21
  %t13 = load ptr, ptr %l33, !tbaa !29
  %t14 = icmp ne ptr %t13, null
  br i1 %t14, label %bb7, label %bb8
bb6:
  br label %bb79
bb7:
  %t16 = load ptr, ptr %l33, !tbaa !29
  %t17 = load i64, ptr %t16
  %t19 = icmp eq i64 %t17, 11
  store i1 %t19, ptr %l34, !tbaa !21
  br label %bb8
bb8:
  %t20 = load i1, ptr %l34, !tbaa !21
  br i1 %t20, label %bb9, label %bb10
bb9:
  %t21 = load ptr, ptr %l1, !tbaa !29
  %t23 = getelementptr { i64, [5 x i64] }, ptr %t21, i32 0, i32 1
  %t24 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t23, i32 0, i32 2
  %t25 = load ptr, ptr %t24
  store ptr %t25, ptr %l3, !tbaa !29
  br label %bb11
bb10:
  br label %bb17
bb11:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load ptr, ptr %l3, !tbaa !29
  %t30 = getelementptr %"compiler/typed:Cond", ptr %t28, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !29
  %t32 = load i32, ptr %l2, !tbaa !23
  %t36 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eretCopies(ptr %v0, ptr %v1, ptr %t27, ptr %t31, i32 %t32)
  store i1 %t36, ptr %l43
  br label %bb12
bb12:
  %t37 = load i1, ptr %l43, !tbaa !21
  br i1 %t37, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l44, !tbaa !21
  br label %bb16
bb14:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t39 = load ptr, ptr %l3, !tbaa !29
  %t41 = getelementptr %"compiler/typed:Cond", ptr %t39, i32 0, i32 2
  %t42 = load ptr, ptr %t41, !tbaa !29
  %t44 = load i32, ptr %l2, !tbaa !23
  %t48 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eretCopies(ptr %v0, ptr %v1, ptr %t38, ptr %t42, i32 %t44)
  store i1 %t48, ptr %l50
  br label %bb15
bb15:
  %t49 = load i1, ptr %l50, !tbaa !21
  store i1 %t49, ptr %l44, !tbaa !21
  br label %bb16
bb16:
  %t50 = load i1, ptr %l44, !tbaa !21
  store i1 %t50, ptr %rv
  br label %ret
bb17:
  %t51 = load ptr, ptr %l1, !tbaa !29
  store ptr %t51, ptr %l51, !tbaa !29
  store i1 false, ptr %l52, !tbaa !21
  %t52 = load ptr, ptr %l51, !tbaa !29
  %t53 = icmp ne ptr %t52, null
  br i1 %t53, label %bb18, label %bb19
bb18:
  %t55 = load ptr, ptr %l51, !tbaa !29
  %t56 = load i64, ptr %t55
  %t58 = icmp eq i64 %t56, 13
  store i1 %t58, ptr %l52, !tbaa !21
  br label %bb19
bb19:
  %t59 = load i1, ptr %l52, !tbaa !21
  br i1 %t59, label %bb20, label %bb21
bb20:
  %t60 = load ptr, ptr %l1, !tbaa !29
  %t62 = getelementptr { i64, [5 x i64] }, ptr %t60, i32 0, i32 1
  %t63 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t62, i32 0, i32 2
  %t64 = load ptr, ptr %t63
  store ptr %t64, ptr %l4, !tbaa !29
  br label %bb22
bb21:
  br label %bb40
bb22:
  %t66 = load ptr, ptr %l4, !tbaa !29
  %t68 = getelementptr %"compiler/typed:Match", ptr %t66, i32 0, i32 1
  %t69 = load { i64, ptr }, ptr %t68, !tbaa !27
  store { i64, ptr } %t69, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t71 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t73 = extractvalue { i64, ptr } %t71, 0
  store i64 %t73, ptr %l7, !tbaa !24
  br label %bb23
bb23:
  store %olang.scope zeroinitializer, ptr %s6
  %t75 = load i64, ptr %l6, !tbaa !24
  %t76 = load i64, ptr %l7, !tbaa !24
  %t79 = icmp slt i64 %t75, %t76
  %t81 = xor i1 %t79, true
  br i1 %t81, label %bb24, label %bb25
bb24:
  call void @__olang_scope_close(ptr %s6)
  br label %bb32
bb25:
  br label %bb26
bb26:
  %t83 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t83, ptr %l65, !tbaa !27
  %t84 = load i64, ptr %l6, !tbaa !24
  %t86 = getelementptr { i64, ptr }, ptr %l65, i32 0, i32 1
  %t87 = load ptr, ptr %t86, !tbaa !27
  %t88 = getelementptr ptr, ptr %t87, i64 %t84
  %t89 = load ptr, ptr %t88, !tbaa !39
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"compiler/typed:Arm", ptr %t89, i32 0, i32 4
  %t95 = load ptr, ptr %t94, !tbaa !29
  %t96 = load i32, ptr %l2, !tbaa !23
  %t100 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eretCopies(ptr %v0, ptr %v1, ptr %t91, ptr %t95, i32 %t96)
  store i1 %t100, ptr %l72
  br label %bb27
bb27:
  %t101 = load i1, ptr %l72, !tbaa !21
  br i1 %t101, label %bb28, label %bb29
bb28:
  call void @__olang_scope_close(ptr %s6)
  store i1 true, ptr %rv
  br label %ret
bb29:
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s6)
  br label %bb31
bb31:
  %t103 = load i64, ptr %l6, !tbaa !24
  %t105 = add i64 %t103, 1
  store i64 %t105, ptr %l6, !tbaa !24
  br label %bb23
bb32:
  %t107 = load ptr, ptr %l4, !tbaa !29
  %t109 = getelementptr %"compiler/typed:Match", ptr %t107, i32 0, i32 2
  %t110 = load ptr, ptr %t109, !tbaa !29
  %t112 = icmp eq ptr %t110, null
  %t114 = xor i1 %t112, true
  br i1 %t114, label %bb33, label %bb34
bb33:
  %t116 = load ptr, ptr %l0, !tbaa !29
  store ptr %t116, ptr %l81, !tbaa !29
  %t117 = load ptr, ptr %l4, !tbaa !29
  %t119 = getelementptr %"compiler/typed:Match", ptr %t117, i32 0, i32 2
  %t120 = load ptr, ptr %t119, !tbaa !29
  %t122 = icmp eq ptr %t120, null
  br i1 %t122, label %bb35, label %bb36
bb34:
  store i1 false, ptr %l80, !tbaa !21
  br label %bb39
bb35:
  call void @__olang_check_failed(ptr @olang_loc_ddcb411f232bf43e_ce3417657830a5fa)
  unreachable
bb36:
  br label %bb37
bb37:
  %t124 = load ptr, ptr %l4, !tbaa !29
  %t126 = getelementptr %"compiler/typed:Match", ptr %t124, i32 0, i32 2
  %t127 = load ptr, ptr %t126, !tbaa !29
  %t130 = getelementptr %"compiler/typed:Arm", ptr %t127, i32 0, i32 4
  %t131 = load ptr, ptr %t130, !tbaa !29
  %t132 = load i32, ptr %l2, !tbaa !23
  %t133 = load ptr, ptr %l81, !tbaa !29
  %t136 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eretCopies(ptr %v0, ptr %v1, ptr %t133, ptr %t131, i32 %t132)
  store i1 %t136, ptr %l90
  br label %bb38
bb38:
  %t137 = load i1, ptr %l90, !tbaa !21
  store i1 %t137, ptr %l80, !tbaa !21
  br label %bb39
bb39:
  %t138 = load i1, ptr %l80, !tbaa !21
  store i1 %t138, ptr %rv
  br label %ret
bb40:
  %t139 = load ptr, ptr %l1, !tbaa !29
  store ptr %t139, ptr %l91, !tbaa !29
  store i1 false, ptr %l92, !tbaa !21
  %t140 = load ptr, ptr %l91, !tbaa !29
  %t141 = icmp ne ptr %t140, null
  br i1 %t141, label %bb41, label %bb42
bb41:
  %t143 = load ptr, ptr %l91, !tbaa !29
  %t144 = load i64, ptr %t143
  %t146 = icmp eq i64 %t144, 14
  store i1 %t146, ptr %l92, !tbaa !21
  br label %bb42
bb42:
  %t147 = load i1, ptr %l92, !tbaa !21
  br i1 %t147, label %bb43, label %bb44
bb43:
  %t148 = load ptr, ptr %l1, !tbaa !29
  %t150 = getelementptr { i64, [5 x i64] }, ptr %t148, i32 0, i32 1
  %t151 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t150, i32 0, i32 2
  %t152 = load ptr, ptr %t151
  store ptr %t152, ptr %l9, !tbaa !29
  br label %bb45
bb44:
  br label %bb66
bb45:
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t155 = load ptr, ptr %l9, !tbaa !29
  %t157 = getelementptr %"compiler/typed:Try", ptr %t155, i32 0, i32 0
  %t158 = load ptr, ptr %t157, !tbaa !29
  %t159 = load i32, ptr %l2, !tbaa !23
  %t163 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eretCopies(ptr %v0, ptr %v1, ptr %t154, ptr %t158, i32 %t159)
  store i1 %t163, ptr %l101
  br label %bb46
bb46:
  %t164 = load i1, ptr %l101, !tbaa !21
  br i1 %t164, label %bb47, label %bb48
bb47:
  store i1 true, ptr %rv
  br label %ret
bb48:
  br label %bb49
bb49:
  %t166 = load ptr, ptr %l9, !tbaa !29
  %t168 = getelementptr %"compiler/typed:Try", ptr %t166, i32 0, i32 1
  %t169 = load { i64, ptr }, ptr %t168, !tbaa !27
  store { i64, ptr } %t169, ptr %l10, !tbaa !27
  store i64 0, ptr %l11, !tbaa !24
  %t171 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t173 = extractvalue { i64, ptr } %t171, 0
  store i64 %t173, ptr %l12, !tbaa !24
  br label %bb50
bb50:
  store %olang.scope zeroinitializer, ptr %s12
  %t175 = load i64, ptr %l11, !tbaa !24
  %t176 = load i64, ptr %l12, !tbaa !24
  %t179 = icmp slt i64 %t175, %t176
  %t181 = xor i1 %t179, true
  br i1 %t181, label %bb51, label %bb52
bb51:
  call void @__olang_scope_close(ptr %s12)
  br label %bb65
bb52:
  br label %bb53
bb53:
  %t183 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t183, ptr %l111, !tbaa !27
  %t184 = load i64, ptr %l11, !tbaa !24
  %t186 = getelementptr { i64, ptr }, ptr %l111, i32 0, i32 1
  %t187 = load ptr, ptr %t186, !tbaa !27
  %t188 = getelementptr ptr, ptr %t187, i64 %t184
  %t189 = load ptr, ptr %t188, !tbaa !39
  %t193 = getelementptr %"compiler/typed:Clause", ptr %t189, i32 0, i32 4
  %t194 = load { i64, ptr }, ptr %t193, !tbaa !27
  store { i64, ptr } %t194, ptr %l14, !tbaa !27
  store i64 0, ptr %l15, !tbaa !24
  %t196 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t198 = extractvalue { i64, ptr } %t196, 0
  store i64 %t198, ptr %l16, !tbaa !24
  br label %bb54
bb54:
  store %olang.scope zeroinitializer, ptr %s14
  %t200 = load i64, ptr %l15, !tbaa !24
  %t201 = load i64, ptr %l16, !tbaa !24
  %t204 = icmp slt i64 %t200, %t201
  %t206 = xor i1 %t204, true
  br i1 %t206, label %bb55, label %bb56
bb55:
  call void @__olang_scope_close(ptr %s14)
  br label %bb63
bb56:
  br label %bb57
bb57:
  %t208 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t208, ptr %l122, !tbaa !27
  %t209 = load i64, ptr %l15, !tbaa !24
  %t211 = getelementptr { i64, ptr }, ptr %l122, i32 0, i32 1
  %t212 = load ptr, ptr %t211, !tbaa !27
  %t213 = getelementptr ptr, ptr %t212, i64 %t209
  %t214 = load ptr, ptr %t213, !tbaa !39
  %t216 = load ptr, ptr %l0, !tbaa !29
  %t219 = load i32, ptr %l2, !tbaa !23
  %t223 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eretCopies(ptr %v0, ptr %v1, ptr %t216, ptr %t214, i32 %t219)
  store i1 %t223, ptr %l129
  br label %bb58
bb58:
  %t224 = load i1, ptr %l129, !tbaa !21
  br i1 %t224, label %bb59, label %bb60
bb59:
  call void @__olang_scope_close(ptr %s14)
  call void @__olang_scope_close(ptr %s12)
  store i1 true, ptr %rv
  br label %ret
bb60:
  br label %bb61
bb61:
  call void @__olang_scope_close(ptr %s14)
  br label %bb62
bb62:
  %t226 = load i64, ptr %l15, !tbaa !24
  %t228 = add i64 %t226, 1
  store i64 %t228, ptr %l15, !tbaa !24
  br label %bb54
bb63:
  call void @__olang_scope_close(ptr %s12)
  br label %bb64
bb64:
  %t230 = load i64, ptr %l11, !tbaa !24
  %t232 = add i64 %t230, 1
  store i64 %t232, ptr %l11, !tbaa !24
  br label %bb50
bb65:
  store i1 false, ptr %rv
  br label %ret
bb66:
  %t235 = load ptr, ptr %l1, !tbaa !29
  store ptr %t235, ptr %l136, !tbaa !29
  store i1 false, ptr %l137, !tbaa !21
  %t236 = load ptr, ptr %l136, !tbaa !29
  %t237 = icmp ne ptr %t236, null
  br i1 %t237, label %bb67, label %bb68
bb67:
  %t239 = load ptr, ptr %l136, !tbaa !29
  %t240 = load i64, ptr %t239
  %t242 = icmp eq i64 %t240, 12
  store i1 %t242, ptr %l137, !tbaa !21
  br label %bb68
bb68:
  %t243 = load i1, ptr %l137, !tbaa !21
  br i1 %t243, label %bb69, label %bb70
bb69:
  %t244 = load ptr, ptr %l1, !tbaa !29
  %t246 = getelementptr { i64, [5 x i64] }, ptr %t244, i32 0, i32 1
  %t247 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t246, i32 0, i32 2
  %t248 = load ptr, ptr %t247
  store ptr %t248, ptr %l18, !tbaa !29
  br label %bb71
bb70:
  br label %bb73
bb71:
  %t250 = load ptr, ptr %l0, !tbaa !29
  %t251 = load ptr, ptr %l18, !tbaa !29
  %t253 = getelementptr %"compiler/typed:Seq", ptr %t251, i32 0, i32 1
  %t254 = load ptr, ptr %t253, !tbaa !29
  %t255 = load i32, ptr %l2, !tbaa !23
  %t259 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eretCopies(ptr %v0, ptr %v1, ptr %t250, ptr %t254, i32 %t255)
  store i1 %t259, ptr %l146
  br label %bb72
bb72:
  %t260 = load i1, ptr %l146, !tbaa !21
  store i1 %t260, ptr %rv
  br label %ret
bb73:
  br i1 true, label %bb74, label %bb75
bb74:
  br label %bb76
bb75:
  br label %bb77
bb76:
  br label %bb78
bb77:
  call void @__olang_check_failed(ptr @olang_loc_ecde87765d07009c_52dfe83edba10a08)
  unreachable
bb78:
  br label %bb79
bb79:
  %t261 = load ptr, ptr %l0, !tbaa !29
  %t262 = load ptr, ptr %l1, !tbaa !29
  %t263 = load i32, ptr %l2, !tbaa !23
  %t267 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2ecopiesArray(ptr %v0, ptr %v1, ptr %t261, ptr %t262, i32 %t263)
  store i1 %t267, ptr %l150
  br label %bb80
bb80:
  %t268 = load i1, ptr %l150, !tbaa !21
  %t269 = xor i1 %t268, true
  br i1 %t269, label %bb81, label %bb82
bb81:
  store i1 false, ptr %rv
  br label %ret
bb82:
  br label %bb83
bb83:
  %t272 = load ptr, ptr %l0, !tbaa !29
  %t274 = getelementptr %"compiler/lower:lowering", ptr %t272, i32 0, i32 10
  %t276 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aBlock_26_3e_2eLe_H8743fc75fe5cead0bda2da42e1adf3f3(ptr %v0, ptr %t274)
  store i64 %t276, ptr %l155
  br label %bb84
bb84:
  %t277 = load i64, ptr %l155, !tbaa !24
  %t278 = icmp sgt i64 %t277, 0
  br i1 %t278, label %bb85, label %bb86
bb85:
  store i1 true, ptr %rv
  br label %ret
bb86:
  br label %bb87
bb87:
  %t281 = load ptr, ptr %l0, !tbaa !29
  %t283 = getelementptr %"compiler/lower:lowering", ptr %t281, i32 0, i32 9
  store ptr %t283, ptr %l19, !tbaa !29
  store i64 0, ptr %l20, !tbaa !24
  br label %bb88
bb88:
  store %olang.scope zeroinitializer, ptr %s23
  %t285 = load ptr, ptr %l19, !tbaa !29
  %t286 = load i64, ptr %l20, !tbaa !24
  %t289 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3alevel_3e_2eRunFrom_3ccompiler_2flower_3alevel_3e(ptr %v0, ptr %t285, i64 %t286)
  %t290 = extractvalue { i32, { i64, ptr } } %t289, 1
  %t291 = extractvalue { i32, { i64, ptr } } %t289, 0
  store i32 %t291, ptr %l164
  %t292 = icmp ne i32 %t291, 0
  br i1 %t292, label %bb90, label %ok.293
ok.293:
  store { i64, ptr } %t290, ptr %l163
  br label %bb89
bb89:
  %t294 = load { i64, ptr }, ptr %l163, !tbaa !27
  store { i64, ptr } %t294, ptr %l160, !tbaa !27
  br label %bb94
bb90:
  %t295 = load i32, ptr %l164, !tbaa !23
  %t296 = ashr i32 %t295, 16
  %t298 = icmp eq i32 %t296, 1
  br i1 %t298, label %bb91, label %bb92
bb91:
  br label %bb93
bb92:
  call void @__olang_check_failed(ptr @olang_loc_2e0d72be7b5575d7_214712821f524de3)
  unreachable
bb93:
  call void @__olang_scope_close(ptr %s23)
  br label %bb105
bb94:
  %t300 = load { i64, ptr }, ptr %l160, !tbaa !27
  store { i64, ptr } %t300, ptr %l21, !tbaa !27
  %t301 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t303 = extractvalue { i64, ptr } %t301, 0
  store i64 %t303, ptr %l22, !tbaa !24
  store i64 0, ptr %l23, !tbaa !24
  br label %bb95
bb95:
  store %olang.scope zeroinitializer, ptr %s24
  %t305 = load i64, ptr %l23, !tbaa !24
  %t306 = load i64, ptr %l22, !tbaa !24
  %t309 = icmp slt i64 %t305, %t306
  %t311 = xor i1 %t309, true
  br i1 %t311, label %bb96, label %bb97
bb96:
  call void @__olang_scope_close(ptr %s24)
  br label %bb103
bb97:
  br label %bb98
bb98:
  %t313 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t313, ptr %l173, !tbaa !27
  %t314 = load i64, ptr %l23, !tbaa !24
  %t316 = getelementptr { i64, ptr }, ptr %l173, i32 0, i32 1
  %t317 = load ptr, ptr %t316, !tbaa !27
  %t318 = getelementptr %"compiler/lower:level", ptr %t317, i64 %t314
  %t319 = load %"compiler/lower:level", ptr %t318
  store %"compiler/lower:level" %t319, ptr %l24
  %t321 = getelementptr %"compiler/lower:level", ptr %l24, i32 0, i32 2
  %t322 = load i32, ptr %t321
  %t324 = trunc i64 3 to i32
  %t325 = icmp eq i32 %t322, %t324
  br i1 %t325, label %bb99, label %bb100
bb99:
  call void @__olang_scope_close(ptr %s24)
  call void @__olang_scope_close(ptr %s23)
  store i1 true, ptr %rv
  br label %ret
bb100:
  br label %bb101
bb101:
  call void @__olang_scope_close(ptr %s24)
  br label %bb102
bb102:
  %t328 = load i64, ptr %l23, !tbaa !24
  %t330 = add i64 %t328, 1
  store i64 %t330, ptr %l23, !tbaa !24
  br label %bb95
bb103:
  %t332 = load i64, ptr %l20, !tbaa !24
  %t333 = load i64, ptr %l22, !tbaa !24
  %t336 = add i64 %t332, %t333
  store i64 %t336, ptr %l20, !tbaa !24
  call void @__olang_scope_close(ptr %s23)
  br label %bb104
bb104:
  br label %bb88
bb105:
  %t338 = load ptr, ptr %l1, !tbaa !29
  store ptr %t338, ptr %l184, !tbaa !29
  store i1 false, ptr %l185, !tbaa !21
  %t339 = load ptr, ptr %l184, !tbaa !29
  %t340 = icmp ne ptr %t339, null
  br i1 %t340, label %bb106, label %bb107
bb106:
  %t342 = load ptr, ptr %l184, !tbaa !29
  %t343 = load i64, ptr %t342
  %t345 = icmp eq i64 %t343, 2
  store i1 %t345, ptr %l185, !tbaa !21
  br label %bb107
bb107:
  %t346 = load i1, ptr %l185, !tbaa !21
  br i1 %t346, label %bb108, label %bb109
bb108:
  %t347 = load ptr, ptr %l1, !tbaa !29
  %t349 = getelementptr { i64, [5 x i64] }, ptr %t347, i32 0, i32 1
  %t350 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t349, i32 0, i32 2
  %t351 = load ptr, ptr %t350
  store ptr %t351, ptr %l25, !tbaa !29
  br label %bb110
bb109:
  br label %bb125
bb110:
  %t353 = load ptr, ptr %l25, !tbaa !29
  store ptr %t353, ptr %l190, !tbaa !29
  store i1 false, ptr %l191, !tbaa !21
  %t354 = load ptr, ptr %l190, !tbaa !29
  %t355 = icmp ne ptr %t354, null
  br i1 %t355, label %bb111, label %bb112
bb111:
  %t357 = load ptr, ptr %l190, !tbaa !29
  %t358 = load i64, ptr %t357
  %t360 = icmp eq i64 %t358, 0
  store i1 %t360, ptr %l191, !tbaa !21
  br label %bb112
bb112:
  %t361 = load i1, ptr %l191, !tbaa !21
  br i1 %t361, label %bb113, label %bb114
bb113:
  %t362 = load ptr, ptr %l25, !tbaa !29
  %t364 = getelementptr { i64, [4 x i64] }, ptr %t362, i32 0, i32 1
  %t365 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t364, i32 0, i32 2
  %t366 = load i32, ptr %t365
  store i32 %t366, ptr %l26, !tbaa !23
  br label %bb115
bb114:
  br label %bb119
bb115:
  %t368 = load ptr, ptr %l0, !tbaa !29
  %t370 = getelementptr %"compiler/lower:lowering", ptr %t368, i32 0, i32 3
  %t371 = getelementptr %"compiler/mir:Fn", ptr %t370, i32 0, i32 7
  %t372 = load i32, ptr %l26, !tbaa !23
  %t374 = sext i32 %t372 to i64
  %t377 = call %"compiler/mir:Local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aLocal_3e_2eAt_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %t371, i64 %t374)
  store %"compiler/mir:Local" %t377, ptr %l200
  br label %bb116
bb116:
  %t378 = getelementptr %"compiler/mir:Local", ptr %l200, i32 0, i32 4
  %t379 = load { i64, [1 x i64] }, ptr %t378
  store { i64, [1 x i64] } %t379, ptr %l201
  store ptr %l201, ptr %l202, !tbaa !29
  %t380 = load ptr, ptr %l0, !tbaa !29
  %t382 = call { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eresultScope(ptr %v0, ptr %t380)
  store { i64, [1 x i64] } %t382, ptr %l204
  br label %bb117
bb117:
  %t383 = load ptr, ptr %l202, !tbaa !29
  %t385 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fmir_3aScopeRef(ptr %t383, ptr %l204)
  store i1 %t385, ptr %l206
  br label %bb118
bb118:
  %t386 = load i1, ptr %l206, !tbaa !21
  %t387 = xor i1 %t386, true
  store i1 %t387, ptr %rv
  br label %ret
bb119:
  br i1 true, label %bb120, label %bb121
bb120:
  br label %bb122
bb121:
  br label %bb123
bb122:
  br label %bb124
bb123:
  call void @__olang_check_failed(ptr @olang_loc_4b16c1f6667ae236_8522eea6e5c16fe2)
  unreachable
bb124:
  br label %bb130
bb125:
  br i1 true, label %bb126, label %bb127
bb126:
  br label %bb128
bb127:
  br label %bb129
bb128:
  br label %bb130
bb129:
  call void @__olang_check_failed(ptr @olang_loc_d0e8b819f5194451_9afcdf330b6f59b5)
  unreachable
bb130:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3alowering_2escalar(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l6 = alloca i32
  %l10 = alloca i1
  %l14 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t8 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t4, i32 %a1)
  store i32 %t8, ptr %l6
  br label %bb1
bb1:
  %t9 = load i32, ptr %l6, !tbaa !23
  store i32 %t9, ptr %l2, !tbaa !23
  %t10 = load i32, ptr %l2, !tbaa !23
  %t11 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t14 = icmp eq i32 %t10, %t11
  br i1 %t14, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l10, !tbaa !21
  br label %bb5
bb3:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/lower:lowering", ptr %t16, i32 0, i32 2
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t20 = load i32, ptr %l2, !tbaa !23
  %t23 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNumber(ptr %v0, ptr %t19, i32 %t20)
  store i1 %t23, ptr %l14
  br label %bb4
bb4:
  %t24 = load i1, ptr %l14, !tbaa !21
  store i1 %t24, ptr %l10, !tbaa !21
  br label %bb5
bb5:
  %t25 = load i1, ptr %l10, !tbaa !21
  store i1 %t25, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eslice(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca %"compiler/lower:pl"
  %l5 = alloca { i64, [4 x i64] }
  %l6 = alloca { i64, [4 x i64] }
  %l7 = alloca { i64, [4 x i64] }
  %l8 = alloca { i64, [4 x i64] }
  %l9 = alloca { i64, [4 x i64] }
  %l17 = alloca %"compiler/lower:pl"
  %l22 = alloca { i64, [4 x i64] }
  %l27 = alloca { i64, [4 x i64] }
  %l31 = alloca ptr
  %l32 = alloca { i64, [4 x i64] }
  %l35 = alloca i32
  %l37 = alloca { i64, [4 x i64] }
  %l38 = alloca ptr
  %l39 = alloca { i64, [4 x i64] }
  %l42 = alloca i32
  %l44 = alloca { i64, [4 x i64] }
  %l49 = alloca ptr
  %l50 = alloca i32
  %l51 = alloca i32
  %l54 = alloca %"compiler/mir:Place"
  %l60 = alloca { i64, [4 x i64] }
  %l61 = alloca ptr
  %l62 = alloca i32
  %l63 = alloca i32
  %l64 = alloca { i64, [4 x i64] }
  %l66 = alloca { i64, [4 x i64] }
  %l71 = alloca { i64, [4 x i64] }
  %l88 = alloca { i64, [4 x i64] }
  %l105 = alloca { i64, [4 x i64] }
  %l113 = alloca ptr
  %l114 = alloca i32
  %l117 = alloca %"compiler/mir:Place"
  %l123 = alloca { i64, [4 x i64] }
  %s2 = alloca %olang.scope
  %rv = alloca { i64, [4 x i64] }
  %t36 = alloca { i64, [4 x i64] }, align 8
  %t87 = alloca { i64, [4 x i64] }, align 8
  %t253 = alloca { i64, [15 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  store %"compiler/source:Span" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t4 = getelementptr %"compiler/typed:Slice", ptr %t2, i32 0, i32 0
  %t5 = load ptr, ptr %t4, !tbaa !29
  %t9 = call %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2eplace(ptr %v0, ptr %v1, ptr %v0, ptr %t1, ptr %t5)
  store %"compiler/lower:pl" %t9, ptr %l17
  br label %bb1
bb1:
  %t10 = load %"compiler/lower:pl", ptr %l17
  store %"compiler/lower:pl" %t10, ptr %l4
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load ptr, ptr %l1, !tbaa !29
  %t14 = getelementptr %"compiler/typed:Slice", ptr %t12, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t19 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v1, ptr %t11, ptr %t15)
  store { i64, [4 x i64] } %t19, ptr %l22
  br label %bb2
bb2:
  %t20 = load { i64, [4 x i64] }, ptr %l22
  store { i64, [4 x i64] } %t20, ptr %l5
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t24 = getelementptr %"compiler/typed:Slice", ptr %t22, i32 0, i32 2
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t29 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v1, ptr %t21, ptr %t25)
  store { i64, [4 x i64] } %t29, ptr %l27
  br label %bb3
bb3:
  %t30 = load { i64, [4 x i64] }, ptr %l27
  store { i64, [4 x i64] } %t30, ptr %l6
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/lower:lowering", ptr %t31, i32 0, i32 7
  %t34 = load i1, ptr %t33, !tbaa !21
  br i1 %t34, label %bb4, label %bb5
bb4:
  store { i64, [4 x i64] } zeroinitializer, ptr %t36
  %t37 = getelementptr { i64, [4 x i64] }, ptr %t36, i32 0, i32 0
  store i64 0, ptr %t37
  %t38 = load { i64, [4 x i64] }, ptr %t36
  store { i64, [4 x i64] } %t38, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t40 = load ptr, ptr %l0, !tbaa !29
  store ptr %t40, ptr %l31, !tbaa !29
  %t41 = load { i64, [4 x i64] }, ptr %l5
  store { i64, [4 x i64] } %t41, ptr %l32
  %t42 = load ptr, ptr %l1, !tbaa !29
  %t44 = getelementptr %"compiler/typed:Slice", ptr %t42, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !29
  %t47 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t45)
  store i32 %t47, ptr %l35
  br label %bb7
bb7:
  %t48 = load %"compiler/source:Span", ptr %l3
  %t49 = load ptr, ptr %l31, !tbaa !29
  %t50 = load { i64, [4 x i64] }, ptr %l32
  %t51 = load i32, ptr %l35, !tbaa !23
  %t53 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2easI64(ptr %v0, ptr %t49, { i64, [4 x i64] } %t50, i32 %t51, %"compiler/source:Span" %t48)
  store { i64, [4 x i64] } %t53, ptr %l37
  br label %bb8
bb8:
  %t54 = load { i64, [4 x i64] }, ptr %l37
  store { i64, [4 x i64] } %t54, ptr %l7
  %t55 = load ptr, ptr %l0, !tbaa !29
  store ptr %t55, ptr %l38, !tbaa !29
  %t56 = load { i64, [4 x i64] }, ptr %l6
  store { i64, [4 x i64] } %t56, ptr %l39
  %t57 = load ptr, ptr %l1, !tbaa !29
  %t59 = getelementptr %"compiler/typed:Slice", ptr %t57, i32 0, i32 2
  %t60 = load ptr, ptr %t59, !tbaa !29
  %t62 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t60)
  store i32 %t62, ptr %l42
  br label %bb9
bb9:
  %t63 = load %"compiler/source:Span", ptr %l3
  %t64 = load ptr, ptr %l38, !tbaa !29
  %t65 = load { i64, [4 x i64] }, ptr %l39
  %t66 = load i32, ptr %l42, !tbaa !23
  %t68 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2easI64(ptr %v0, ptr %t64, { i64, [4 x i64] } %t65, i32 %t66, %"compiler/source:Span" %t63)
  store { i64, [4 x i64] } %t68, ptr %l44
  br label %bb10
bb10:
  %t69 = load { i64, [4 x i64] }, ptr %l44
  store { i64, [4 x i64] } %t69, ptr %l8
  %t70 = load ptr, ptr %l1, !tbaa !29
  %t72 = getelementptr %"compiler/typed:Slice", ptr %t70, i32 0, i32 3
  %t73 = load i32, ptr %t72
  %t75 = trunc i64 0 to i32
  %t76 = icmp eq i32 %t73, %t75
  %t78 = xor i1 %t76, true
  br i1 %t78, label %bb11, label %bb12
bb11:
  store %olang.scope zeroinitializer, ptr %s2
  %t80 = load ptr, ptr %l0, !tbaa !29
  store ptr %t80, ptr %l49, !tbaa !29
  store i32 22, ptr %l50
  %t81 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  store i32 %t81, ptr %l51, !tbaa !23
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t83 = load %"compiler/lower:pl", ptr %l4
  %t86 = call %"compiler/mir:Place" @compiler_2flower_2ecompiler_2flower_3alowering_2emk(ptr %v0, ptr %v0, ptr %t82, %"compiler/lower:pl" %t83)
  store %"compiler/mir:Place" %t86, ptr %l54
  br label %bb13
bb12:
  br label %bb22
bb13:
  store { i64, [4 x i64] } zeroinitializer, ptr %t87
  %t88 = getelementptr { i64, [4 x i64] }, ptr %t87, i32 0, i32 0
  store i64 1, ptr %t88
  %t89 = load %"compiler/mir:Place", ptr %l54
  %t90 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t89, 0
  %t91 = getelementptr { i64, [4 x i64] }, ptr %t87, i32 0, i32 1
  store { %"compiler/mir:Place" } %t90, ptr %t91
  %t92 = load { i64, [4 x i64] }, ptr %t87
  %t94 = insertvalue [1 x { i64, [4 x i64] }] undef, { i64, [4 x i64] } %t92, 0
  %t96 = load ptr, ptr @__olang_prog_scope
  %t97 = call ptr @__olang_scope_alloc(ptr %t96, i64 40)
  store [1 x { i64, [4 x i64] }] %t94, ptr %t97
  %t98 = insertvalue { i64, ptr } undef, i64 1, 0
  %t99 = insertvalue { i64, ptr } %t98, ptr %t97, 1
  %t101 = extractvalue { i64, ptr } %t99, 0
  %t102 = extractvalue { i64, ptr } %t99, 1
  %t103 = mul i64 %t101, 40
  %t104 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t103)
  call void @llvm.memcpy.p0.p0.i64(ptr %t104, ptr %t102, i64 %t103, i1 false)
  %t105 = insertvalue { i64, ptr } undef, i64 %t101, 0
  %t106 = insertvalue { i64, ptr } %t105, ptr %t104, 1
  %t107 = load %"compiler/source:Span", ptr %l3
  %t108 = load ptr, ptr %l49, !tbaa !29
  %t109 = load i32, ptr %l50
  %t110 = load i32, ptr %l51, !tbaa !23
  %t113 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s2, ptr %t108, i32 %t109, i32 %t110, { i64, ptr } %t106, %"compiler/source:Span" %t107)
  store { i64, [4 x i64] } %t113, ptr %l60
  br label %bb14
bb14:
  %t114 = load { i64, [4 x i64] }, ptr %l60
  store { i64, [4 x i64] } %t114, ptr %l9
  %t115 = load ptr, ptr %l0, !tbaa !29
  store ptr %t115, ptr %l61, !tbaa !29
  store i32 18, ptr %l62
  %t116 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t116, ptr %l63, !tbaa !23
  %t117 = load { i64, [4 x i64] }, ptr %l7
  store { i64, [4 x i64] } %t117, ptr %l64
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t120 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2econstI64(ptr %v0, ptr %t118, i64 0)
  store { i64, [4 x i64] } %t120, ptr %l66
  br label %bb15
bb15:
  %t121 = load { i64, [4 x i64] }, ptr %l64
  %t122 = insertvalue [2 x { i64, [4 x i64] }] undef, { i64, [4 x i64] } %t121, 0
  %t123 = load { i64, [4 x i64] }, ptr %l66
  %t124 = insertvalue [2 x { i64, [4 x i64] }] %t122, { i64, [4 x i64] } %t123, 1
  %t126 = load ptr, ptr @__olang_prog_scope
  %t127 = call ptr @__olang_scope_alloc(ptr %t126, i64 80)
  store [2 x { i64, [4 x i64] }] %t124, ptr %t127
  %t128 = insertvalue { i64, ptr } undef, i64 2, 0
  %t129 = insertvalue { i64, ptr } %t128, ptr %t127, 1
  %t131 = extractvalue { i64, ptr } %t129, 0
  %t132 = extractvalue { i64, ptr } %t129, 1
  %t133 = mul i64 %t131, 40
  %t134 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t133)
  call void @llvm.memcpy.p0.p0.i64(ptr %t134, ptr %t132, i64 %t133, i1 false)
  %t135 = insertvalue { i64, ptr } undef, i64 %t131, 0
  %t136 = insertvalue { i64, ptr } %t135, ptr %t134, 1
  %t137 = load %"compiler/source:Span", ptr %l3
  %t138 = load ptr, ptr %l61, !tbaa !29
  %t139 = load i32, ptr %l62
  %t140 = load i32, ptr %l63, !tbaa !23
  %t143 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s2, ptr %t138, i32 %t139, i32 %t140, { i64, ptr } %t136, %"compiler/source:Span" %t137)
  store { i64, [4 x i64] } %t143, ptr %l71
  br label %bb16
bb16:
  %t144 = load { i64, [4 x i64] }, ptr %l71
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t147 = load ptr, ptr %l1, !tbaa !29
  %t149 = getelementptr %"compiler/typed:Slice", ptr %t147, i32 0, i32 3
  %t150 = load i32, ptr %t149
  %t151 = load i64, ptr @G_2ecompiler_2flower_2eOutOfBounds, !tbaa !24
  %t152 = load %"compiler/source:Span", ptr %l3
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2echeck(ptr %v0, ptr %t145, { i64, [4 x i64] } %t144, i32 %t150, i32 6, i64 %t151, %"compiler/source:Span" %t152)
  br label %bb17
bb17:
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t160 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t161 = load { i64, [4 x i64] }, ptr %l7
  %t162 = load { i64, [4 x i64] }, ptr %l8
  %t164 = insertvalue [2 x { i64, [4 x i64] }] undef, { i64, [4 x i64] } %t161, 0
  %t166 = insertvalue [2 x { i64, [4 x i64] }] %t164, { i64, [4 x i64] } %t162, 1
  %t168 = load ptr, ptr @__olang_prog_scope
  %t169 = call ptr @__olang_scope_alloc(ptr %t168, i64 80)
  store [2 x { i64, [4 x i64] }] %t166, ptr %t169
  %t170 = insertvalue { i64, ptr } undef, i64 2, 0
  %t171 = insertvalue { i64, ptr } %t170, ptr %t169, 1
  %t173 = extractvalue { i64, ptr } %t171, 0
  %t174 = extractvalue { i64, ptr } %t171, 1
  %t175 = mul i64 %t173, 40
  %t176 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t175)
  call void @llvm.memcpy.p0.p0.i64(ptr %t176, ptr %t174, i64 %t175, i1 false)
  %t177 = insertvalue { i64, ptr } undef, i64 %t173, 0
  %t178 = insertvalue { i64, ptr } %t177, ptr %t176, 1
  %t179 = load %"compiler/source:Span", ptr %l3
  %t185 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s2, ptr %t159, i32 16, i32 %t160, { i64, ptr } %t178, %"compiler/source:Span" %t179)
  store { i64, [4 x i64] } %t185, ptr %l88
  br label %bb18
bb18:
  %t186 = load { i64, [4 x i64] }, ptr %l88
  %t187 = load ptr, ptr %l0, !tbaa !29
  %t189 = load ptr, ptr %l1, !tbaa !29
  %t191 = getelementptr %"compiler/typed:Slice", ptr %t189, i32 0, i32 3
  %t192 = load i32, ptr %t191
  %t193 = load i64, ptr @G_2ecompiler_2flower_2eOutOfBounds, !tbaa !24
  %t194 = load %"compiler/source:Span", ptr %l3
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2echeck(ptr %v0, ptr %t187, { i64, [4 x i64] } %t186, i32 %t192, i32 6, i64 %t193, %"compiler/source:Span" %t194)
  br label %bb19
bb19:
  %t201 = load ptr, ptr %l0, !tbaa !29
  %t202 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t203 = load { i64, [4 x i64] }, ptr %l8
  %t204 = load { i64, [4 x i64] }, ptr %l9
  %t206 = insertvalue [2 x { i64, [4 x i64] }] undef, { i64, [4 x i64] } %t203, 0
  %t208 = insertvalue [2 x { i64, [4 x i64] }] %t206, { i64, [4 x i64] } %t204, 1
  %t210 = load ptr, ptr @__olang_prog_scope
  %t211 = call ptr @__olang_scope_alloc(ptr %t210, i64 80)
  store [2 x { i64, [4 x i64] }] %t208, ptr %t211
  %t212 = insertvalue { i64, ptr } undef, i64 2, 0
  %t213 = insertvalue { i64, ptr } %t212, ptr %t211, 1
  %t215 = extractvalue { i64, ptr } %t213, 0
  %t216 = extractvalue { i64, ptr } %t213, 1
  %t217 = mul i64 %t215, 40
  %t218 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t217)
  call void @llvm.memcpy.p0.p0.i64(ptr %t218, ptr %t216, i64 %t217, i1 false)
  %t219 = insertvalue { i64, ptr } undef, i64 %t215, 0
  %t220 = insertvalue { i64, ptr } %t219, ptr %t218, 1
  %t221 = load %"compiler/source:Span", ptr %l3
  %t227 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s2, ptr %t201, i32 16, i32 %t202, { i64, ptr } %t220, %"compiler/source:Span" %t221)
  store { i64, [4 x i64] } %t227, ptr %l105
  br label %bb20
bb20:
  %t228 = load { i64, [4 x i64] }, ptr %l105
  %t229 = load ptr, ptr %l0, !tbaa !29
  %t231 = load ptr, ptr %l1, !tbaa !29
  %t233 = getelementptr %"compiler/typed:Slice", ptr %t231, i32 0, i32 3
  %t234 = load i32, ptr %t233
  %t235 = load i64, ptr @G_2ecompiler_2flower_2eOutOfBounds, !tbaa !24
  %t236 = load %"compiler/source:Span", ptr %l3
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2echeck(ptr %v0, ptr %t229, { i64, [4 x i64] } %t228, i32 %t234, i32 6, i64 %t235, %"compiler/source:Span" %t236)
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s2)
  br label %bb22
bb22:
  %t243 = load ptr, ptr %l0, !tbaa !29
  store ptr %t243, ptr %l113, !tbaa !29
  %t244 = load i32, ptr %l2, !tbaa !23
  store i32 %t244, ptr %l114, !tbaa !23
  %t245 = load ptr, ptr %l0, !tbaa !29
  %t246 = load %"compiler/lower:pl", ptr %l4
  %t249 = call %"compiler/mir:Place" @compiler_2flower_2ecompiler_2flower_3alowering_2emk(ptr %v0, ptr %v0, ptr %t245, %"compiler/lower:pl" %t246)
  store %"compiler/mir:Place" %t249, ptr %l117
  br label %bb23
bb23:
  %t250 = load { i64, [4 x i64] }, ptr %l7
  %t251 = load { i64, [4 x i64] }, ptr %l8
  %t252 = load i32, ptr %l2, !tbaa !23
  store { i64, [15 x i64] } zeroinitializer, ptr %t253
  %t254 = getelementptr { i64, [15 x i64] }, ptr %t253, i32 0, i32 0
  store i64 9, ptr %t254
  %t255 = load %"compiler/mir:Place", ptr %l117
  %t256 = insertvalue { %"compiler/mir:Place", { i64, [4 x i64] }, { i64, [4 x i64] }, i32 } undef, %"compiler/mir:Place" %t255, 0
  %t258 = insertvalue { %"compiler/mir:Place", { i64, [4 x i64] }, { i64, [4 x i64] }, i32 } %t256, { i64, [4 x i64] } %t250, 1
  %t260 = insertvalue { %"compiler/mir:Place", { i64, [4 x i64] }, { i64, [4 x i64] }, i32 } %t258, { i64, [4 x i64] } %t251, 2
  %t262 = insertvalue { %"compiler/mir:Place", { i64, [4 x i64] }, { i64, [4 x i64] }, i32 } %t260, i32 %t252, 3
  %t263 = getelementptr { i64, [15 x i64] }, ptr %t253, i32 0, i32 1
  store { %"compiler/mir:Place", { i64, [4 x i64] }, { i64, [4 x i64] }, i32 } %t262, ptr %t263
  %t264 = load { i64, [15 x i64] }, ptr %t253
  %t265 = load %"compiler/source:Span", ptr %l3
  %t266 = load ptr, ptr %l113, !tbaa !29
  %t267 = load i32, ptr %l114, !tbaa !23
  %t270 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %t266, i32 %t267, { i64, [15 x i64] } %t264, %"compiler/source:Span" %t265)
  store { i64, [4 x i64] } %t270, ptr %l123
  br label %bb24
bb24:
  %t271 = load { i64, [4 x i64] }, ptr %l123
  store { i64, [4 x i64] } %t271, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2espawnErrors(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l1 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l17 = alloca { i64, ptr }
  %s3 = alloca %olang.scope
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t7 = getelementptr %"compiler/typed:Block", ptr %t5, i32 0, i32 1
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  store { i64, ptr } %t8, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l5, !tbaa !24
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s3
  %t14 = load i64, ptr %l4, !tbaa !24
  %t15 = load i64, ptr %l5, !tbaa !24
  %t18 = icmp slt i64 %t14, %t15
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s3)
  br label %bb10
bb6:
  br label %bb7
bb7:
  %t22 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t22, ptr %l17, !tbaa !27
  %t23 = load i64, ptr %l4, !tbaa !24
  %t25 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr ptr, ptr %t26, i64 %t23
  %t28 = load ptr, ptr %t27, !tbaa !39
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estmtSpawnErrors(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %t28, ptr %a2)
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s3)
  br label %bb9
bb9:
  %t36 = load i64, ptr %l4, !tbaa !24
  %t38 = add i64 %t36, 1
  store i64 %t38, ptr %l4, !tbaa !24
  br label %bb4
bb10:
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2flower_2ecompiler_2flower_3alowering_2espell(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i1 %a2, i1 %a3, i1 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i1
  %l3 = alloca i1
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca %"std/prelude/text:StringBuilder"
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l17 = alloca %"std/prelude/text:StringBuilder"
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca %"std/prelude/text:StringBuilder"
  %l26 = alloca i32
  %l27 = alloca { i64, ptr }
  %l28 = alloca i1
  %l29 = alloca i1
  %l30 = alloca { i64, ptr }
  %l31 = alloca { i64, ptr }
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca { i64, ptr }
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i64
  %l46 = alloca i64
  %l47 = alloca i64
  %l48 = alloca i64
  %l49 = alloca i64
  %l50 = alloca i64
  %l51 = alloca i64
  %l56 = alloca i32
  %l61 = alloca ptr
  %l62 = alloca ptr
  %l65 = alloca i32
  %l66 = alloca i32
  %l67 = alloca { i64, ptr }
  %l68 = alloca ptr
  %l71 = alloca i32
  %l72 = alloca { i64, ptr }
  %l78 = alloca %"std/prelude/text:StringBuilder"
  %l87 = alloca i64
  %l90 = alloca i64
  %l111 = alloca ptr
  %l113 = alloca { i64, ptr }
  %l116 = alloca { i64, ptr }
  %l122 = alloca { i64, ptr }
  %l123 = alloca { i64, ptr }
  %l124 = alloca i64
  %l125 = alloca { i64, ptr }
  %l130 = alloca i64
  %l134 = alloca { i64, ptr }
  %l135 = alloca { i64, ptr }
  %l136 = alloca ptr
  %l139 = alloca i32
  %l141 = alloca { i64, ptr }
  %l145 = alloca ptr
  %l148 = alloca i32
  %l149 = alloca { i64, ptr }
  %l155 = alloca i64
  %l159 = alloca %"std/prelude/text:StringBuilder"
  %l160 = alloca ptr
  %l163 = alloca i32
  %l164 = alloca { i64, ptr }
  %l171 = alloca i64
  %l174 = alloca i64
  %l195 = alloca ptr
  %l197 = alloca { i64, ptr }
  %l200 = alloca { i64, ptr }
  %l206 = alloca { i64, ptr }
  %l207 = alloca { i64, ptr }
  %l208 = alloca i64
  %l209 = alloca { i64, ptr }
  %l212 = alloca %"std/prelude/text:StringBuilder"
  %l215 = alloca i32
  %l216 = alloca ptr
  %l219 = alloca i32
  %l220 = alloca { i64, ptr }
  %l223 = alloca i32
  %l226 = alloca i1
  %l227 = alloca ptr
  %l230 = alloca i32
  %l231 = alloca { i64, ptr }
  %l234 = alloca i1
  %l239 = alloca i1
  %l241 = alloca i1
  %l243 = alloca i1
  %l250 = alloca ptr
  %l253 = alloca i32
  %l254 = alloca { i64, ptr }
  %l257 = alloca { i64, ptr }
  %l263 = alloca i64
  %l266 = alloca i64
  %l292 = alloca ptr
  %l295 = alloca { i64, ptr }
  %l300 = alloca { i64, ptr }
  %l303 = alloca ptr
  %l305 = alloca { i64, ptr }
  %l308 = alloca { i64, ptr }
  %l315 = alloca i32
  %l318 = alloca ptr
  %l321 = alloca i32
  %l322 = alloca { i64, ptr }
  %l328 = alloca i64
  %l331 = alloca i64
  %l349 = alloca ptr
  %l352 = alloca { i64, ptr }
  %l354 = alloca { i64, ptr }
  %l357 = alloca { i64, ptr }
  %l368 = alloca i1
  %l371 = alloca i32
  %l374 = alloca i1
  %l375 = alloca ptr
  %l378 = alloca i32
  %l379 = alloca { i64, ptr }
  %l382 = alloca ptr
  %l386 = alloca { i64, ptr }
  %l398 = alloca i64
  %l401 = alloca i64
  %l419 = alloca ptr
  %l422 = alloca { i64, ptr }
  %l423 = alloca ptr
  %l425 = alloca { i64, ptr }
  %l428 = alloca i32
  %l429 = alloca { i64, ptr }
  %l437 = alloca { i64, ptr }
  %l438 = alloca { i64, ptr }
  %l439 = alloca i64
  %l440 = alloca { i64, ptr }
  %l443 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %s24 = alloca %olang.scope
  %s25 = alloca %olang.scope
  %s30 = alloca %olang.scope
  %s34 = alloca %olang.scope
  %s36 = alloca %olang.scope
  %s38 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i1 %a2, ptr %l2
  store i1 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l5, !tbaa !29
  %t6 = load ptr, ptr %l5, !tbaa !29
  %t7 = load i32, ptr %l1, !tbaa !23
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t6, i32 %t7)
  store i32 %t10, ptr %l56
  br label %bb1
bb1:
  %t11 = load i32, ptr %l56
  store i32 %t11, ptr %l6
  %t12 = load i32, ptr %l6
  %t14 = trunc i64 18 to i32
  %t15 = icmp eq i32 %t12, %t14
  br i1 %t15, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/lower:lowering", ptr %t17, i32 0, i32 2
  %t20 = load ptr, ptr %t19, !tbaa !29
  %t22 = getelementptr %"compiler/types:Table", ptr %t20, i32 0, i32 0
  %t23 = load ptr, ptr %t22, !tbaa !29
  store ptr %t23, ptr %l61, !tbaa !29
  %t24 = load ptr, ptr %l5, !tbaa !29
  store ptr %t24, ptr %l62, !tbaa !29
  %t25 = load ptr, ptr %l5, !tbaa !29
  %t26 = load i32, ptr %l1, !tbaa !23
  %t29 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t25, i32 %t26)
  store i32 %t29, ptr %l65
  br label %bb4
bb3:
  br label %bb35
bb4:
  %t30 = load ptr, ptr %l62, !tbaa !29
  %t31 = load i32, ptr %l65, !tbaa !23
  %t32 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %t30, i32 %t31)
  store i32 %t32, ptr %l66
  br label %bb5
bb5:
  %t33 = load ptr, ptr %l61, !tbaa !29
  %t34 = load i32, ptr %l66, !tbaa !23
  %t35 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t33, i32 %t34)
  store { i64, ptr } %t35, ptr %l67
  br label %bb6
bb6:
  %t36 = load { i64, ptr }, ptr %l67, !tbaa !27
  store { i64, ptr } %t36, ptr %l7, !tbaa !27
  %t37 = load ptr, ptr %l5, !tbaa !29
  store ptr %t37, ptr %l68, !tbaa !29
  %t38 = load ptr, ptr %l5, !tbaa !29
  %t39 = load i32, ptr %l1, !tbaa !23
  %t42 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %t38, i32 %t39)
  store i32 %t42, ptr %l71
  br label %bb7
bb7:
  %t43 = load ptr, ptr %l68, !tbaa !29
  %t44 = load i32, ptr %l71, !tbaa !23
  %t45 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t43, i32 %t44)
  store { i64, ptr } %t45, ptr %l72
  br label %bb8
bb8:
  %t46 = load { i64, ptr }, ptr %l72, !tbaa !27
  store { i64, ptr } %t46, ptr %l8, !tbaa !27
  %t47 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t49 = extractvalue { i64, ptr } %t47, 0
  %t51 = icmp eq i64 %t49, 0
  br i1 %t51, label %bb9, label %bb10
bb9:
  %t53 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t55 = extractvalue { i64, ptr } %t53, 1
  %t56 = extractvalue { i64, ptr } %t53, 0
  %t57 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t56)
  call void @olang_textcopy(ptr %t57, ptr %t55, i64 %t56)
  %t58 = insertvalue { i64, ptr } undef, i64 %t56, 0
  %t59 = insertvalue { i64, ptr } %t58, ptr %t57, 1
  call void @__olang_scope_close(ptr %s1)
  store { i64, ptr } %t59, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t61 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s1)
  store %"std/prelude/text:StringBuilder" %t61, ptr %l78
  br label %bb12
bb12:
  %t62 = load %"std/prelude/text:StringBuilder", ptr %l78
  store %"std/prelude/text:StringBuilder" %t62, ptr %l9
  %t63 = load { i64, ptr }, ptr %l7, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s1, ptr %v0, ptr %l9, { i64, ptr } %t63)
  br label %bb13
bb13:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s1, ptr %l9, i8 60)
  br label %bb14
bb14:
  store i64 0, ptr %l10, !tbaa !24
  %t67 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t69 = extractvalue { i64, ptr } %t67, 0
  store i64 %t69, ptr %l11, !tbaa !24
  store i64 1, ptr %l12, !tbaa !24
  %t71 = load i64, ptr %l11, !tbaa !24
  %t72 = load i64, ptr %l10, !tbaa !24
  %t75 = icmp sgt i64 %t71, %t72
  br i1 %t75, label %bb15, label %bb16
bb15:
  %t77 = load i64, ptr %l12, !tbaa !24
  %t79 = icmp sgt i64 %t77, 0
  br i1 %t79, label %bb17, label %bb18
bb16:
  store i64 0, ptr %l87, !tbaa !24
  br label %bb20
bb17:
  %t81 = load i64, ptr %l11, !tbaa !24
  %t82 = load i64, ptr %l10, !tbaa !24
  %t85 = sub i64 %t81, %t82
  %t86 = load i64, ptr %l12, !tbaa !24
  %t89 = add i64 %t85, %t86
  %t91 = sub i64 %t89, 1
  %t92 = load i64, ptr %l12, !tbaa !24
  %t95 = sdiv i64 %t91, %t92
  store i64 %t95, ptr %l90, !tbaa !24
  br label %bb19
bb18:
  store i64 0, ptr %l90, !tbaa !24
  br label %bb19
bb19:
  %t97 = load i64, ptr %l90, !tbaa !24
  store i64 %t97, ptr %l87, !tbaa !24
  br label %bb20
bb20:
  %t98 = load i64, ptr %l87, !tbaa !24
  store i64 %t98, ptr %l13, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  br label %bb21
bb21:
  store %olang.scope zeroinitializer, ptr %s5
  %t99 = load i64, ptr %l14, !tbaa !24
  %t100 = load i64, ptr %l13, !tbaa !24
  %t103 = icmp slt i64 %t99, %t100
  %t105 = xor i1 %t103, true
  br i1 %t105, label %bb22, label %bb23
bb22:
  call void @__olang_scope_close(ptr %s5)
  br label %bb32
bb23:
  br label %bb24
bb24:
  %t107 = load i64, ptr %l10, !tbaa !24
  %t108 = load i64, ptr %l14, !tbaa !24
  %t109 = load i64, ptr %l12, !tbaa !24
  %t112 = mul i64 %t108, %t109
  %t115 = add i64 %t107, %t112
  store i64 %t115, ptr %l15, !tbaa !24
  %t117 = load i64, ptr %l15, !tbaa !24
  %t119 = icmp sgt i64 %t117, 0
  br i1 %t119, label %bb25, label %bb26
bb25:
  store %olang.scope zeroinitializer, ptr %s6
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s1, ptr %s6, ptr %l9, { i64, ptr } { i64 2, ptr @.d17 })
  br label %bb27
bb26:
  br label %bb28
bb27:
  call void @__olang_scope_close(ptr %s6)
  br label %bb28
bb28:
  store ptr %l9, ptr %l111, !tbaa !29
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t123 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t123, ptr %l113, !tbaa !27
  %t124 = load i64, ptr %l15, !tbaa !24
  %t126 = getelementptr { i64, ptr }, ptr %l113, i32 0, i32 1
  %t127 = load ptr, ptr %t126, !tbaa !27
  %t128 = getelementptr i32, ptr %t127, i64 %t124
  %t129 = load i32, ptr %t128, !tbaa !33
  %t132 = call { i64, ptr } @compiler_2flower_2ecompiler_2flower_3alowering_2espell(ptr %v0, ptr %s5, ptr %t122, i32 %t129, i1 true, i1 true, i1 false)
  store { i64, ptr } %t132, ptr %l116
  br label %bb29
bb29:
  %t133 = load { i64, ptr }, ptr %l116, !tbaa !27
  %t134 = extractvalue { i64, ptr } %t133, 0
  %t135 = extractvalue { i64, ptr } %t133, 1
  %t136 = mul i64 %t134, 1
  %t137 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t136)
  call void @llvm.memcpy.p0.p0.i64(ptr %t137, ptr %t135, i64 %t136, i1 false)
  %t138 = insertvalue { i64, ptr } undef, i64 %t134, 0
  %t139 = insertvalue { i64, ptr } %t138, ptr %t137, 1
  %t140 = load ptr, ptr %l111, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s1, ptr %s5, ptr %t140, { i64, ptr } %t139)
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s5)
  br label %bb31
bb31:
  %t142 = load i64, ptr %l14, !tbaa !24
  %t144 = add i64 %t142, 1
  store i64 %t144, ptr %l14, !tbaa !24
  br label %bb21
bb32:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s1, ptr %l9, i8 62)
  br label %bb33
bb33:
  %t148 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s1, ptr %v1, ptr %l9)
  store { i64, ptr } %t148, ptr %l122
  br label %bb34
bb34:
  %t149 = load { i64, ptr }, ptr %l122, !tbaa !27
  store { i64, ptr } %t149, ptr %l123, !tbaa !27
  %t150 = load { i64, ptr }, ptr %l123, !tbaa !27
  %t151 = extractvalue { i64, ptr } %t150, 0
  store i64 %t151, ptr %l124, !tbaa !24
  %t152 = load i64, ptr %l124, !tbaa !24
  %t153 = mul i64 %t152, 1
  %t154 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t153)
  %t155 = insertvalue { i64, ptr } undef, i64 %t152, 0
  %t156 = insertvalue { i64, ptr } %t155, ptr %t154, 1
  store { i64, ptr } %t156, ptr %l125, !tbaa !27
  %t157 = getelementptr { i64, ptr }, ptr %l125, i32 0, i32 1
  %t158 = load ptr, ptr %t157, !tbaa !27
  %t159 = getelementptr { i64, ptr }, ptr %l123, i32 0, i32 1
  %t160 = load ptr, ptr %t159, !tbaa !27
  %t161 = load i64, ptr %l124, !tbaa !24
  %t162 = mul i64 %t161, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t158, ptr %t160, i64 %t162, i1 false)
  %t163 = load { i64, ptr }, ptr %l125, !tbaa !27
  store { i64, ptr } %t163, ptr %l123, !tbaa !27
  call void @__olang_scope_close(ptr %s1)
  %t164 = load { i64, ptr }, ptr %l123, !tbaa !27
  store { i64, ptr } %t164, ptr %rv
  br label %ret
bb35:
  %t165 = load i32, ptr %l6
  %t167 = trunc i64 20 to i32
  %t168 = icmp eq i32 %t165, %t167
  br i1 %t168, label %bb36, label %bb37
bb36:
  store %olang.scope zeroinitializer, ptr %s8
  %t170 = load ptr, ptr %l5, !tbaa !29
  %t171 = load i32, ptr %l1, !tbaa !23
  %t174 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t170, i32 %t171)
  store i64 %t174, ptr %l130
  br label %bb38
bb37:
  br label %bb44
bb38:
  %t175 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t176 = load i64, ptr %l130, !tbaa !24
  %t178 = and i64 %t176, %t175
  %t180 = icmp ne i64 %t178, 0
  br i1 %t180, label %bb39, label %bb40
bb39:
  store { i64, ptr } { i64 4, ptr @.d18 }, ptr %l134, !tbaa !27
  br label %bb41
bb40:
  store { i64, ptr } { i64 0, ptr @.d19 }, ptr %l134, !tbaa !27
  br label %bb41
bb41:
  %t182 = load { i64, ptr }, ptr %l134, !tbaa !27
  store { i64, ptr } %t182, ptr %l135, !tbaa !27
  %t184 = load ptr, ptr %l0, !tbaa !29
  store ptr %t184, ptr %l136, !tbaa !29
  %t185 = load ptr, ptr %l5, !tbaa !29
  %t186 = load i32, ptr %l1, !tbaa !23
  %t189 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t185, i32 %t186)
  store i32 %t189, ptr %l139
  br label %bb42
bb42:
  %t190 = load i1, ptr %l3, !tbaa !21
  %t191 = load ptr, ptr %l136, !tbaa !29
  %t192 = load i32, ptr %l139, !tbaa !23
  %t194 = call { i64, ptr } @compiler_2flower_2ecompiler_2flower_3alowering_2espell(ptr %v0, ptr %s8, ptr %t191, i32 %t192, i1 true, i1 %t190, i1 false)
  store { i64, ptr } %t194, ptr %l141
  br label %bb43
bb43:
  %t195 = load { i64, ptr }, ptr %l135, !tbaa !27
  %t196 = extractvalue { i64, ptr } %t195, 1
  %t197 = extractvalue { i64, ptr } %t195, 0
  %t198 = load { i64, ptr }, ptr %l141, !tbaa !27
  %t199 = extractvalue { i64, ptr } %t198, 1
  %t200 = extractvalue { i64, ptr } %t198, 0
  %t201 = add i64 %t197, %t200
  %t202 = extractvalue { i64, ptr } { i64 1, ptr @.d20 }, 1
  %t203 = extractvalue { i64, ptr } { i64 1, ptr @.d20 }, 0
  %t204 = add i64 %t201, %t203
  %t205 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t204)
  call void @olang_textcopy(ptr %t205, ptr %t196, i64 %t197)
  %t206 = getelementptr i8, ptr %t205, i64 %t197
  call void @olang_textcopy(ptr %t206, ptr %t199, i64 %t200)
  %t207 = getelementptr i8, ptr %t206, i64 %t200
  call void @olang_textcopy(ptr %t207, ptr %t202, i64 %t203)
  %t208 = insertvalue { i64, ptr } undef, i64 %t204, 0
  %t209 = insertvalue { i64, ptr } %t208, ptr %t205, 1
  call void @__olang_scope_close(ptr %s8)
  store { i64, ptr } %t209, ptr %rv
  br label %ret
bb44:
  %t211 = load i32, ptr %l6
  %t213 = trunc i64 19 to i32
  %t214 = icmp eq i32 %t211, %t213
  br i1 %t214, label %bb45, label %bb46
bb45:
  store %olang.scope zeroinitializer, ptr %s10
  %t216 = load ptr, ptr %l0, !tbaa !29
  store ptr %t216, ptr %l145, !tbaa !29
  %t217 = load ptr, ptr %l5, !tbaa !29
  %t218 = load i32, ptr %l1, !tbaa !23
  %t221 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t217, i32 %t218)
  store i32 %t221, ptr %l148
  br label %bb47
bb46:
  br label %bb49
bb47:
  %t222 = load ptr, ptr %l145, !tbaa !29
  %t223 = load i32, ptr %l148, !tbaa !23
  %t224 = call { i64, ptr } @compiler_2flower_2ecompiler_2flower_3alowering_2espell(ptr %v0, ptr %s10, ptr %t222, i32 %t223, i1 true, i1 true, i1 false)
  store { i64, ptr } %t224, ptr %l149
  br label %bb48
bb48:
  %t225 = extractvalue { i64, ptr } { i64 6, ptr @.d21 }, 1
  %t226 = extractvalue { i64, ptr } { i64 6, ptr @.d21 }, 0
  %t227 = load { i64, ptr }, ptr %l149, !tbaa !27
  %t228 = extractvalue { i64, ptr } %t227, 1
  %t229 = extractvalue { i64, ptr } %t227, 0
  %t230 = add i64 %t226, %t229
  %t231 = extractvalue { i64, ptr } { i64 1, ptr @.d22 }, 1
  %t232 = extractvalue { i64, ptr } { i64 1, ptr @.d22 }, 0
  %t233 = add i64 %t230, %t232
  %t234 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t233)
  call void @olang_textcopy(ptr %t234, ptr %t225, i64 %t226)
  %t235 = getelementptr i8, ptr %t234, i64 %t226
  call void @olang_textcopy(ptr %t235, ptr %t228, i64 %t229)
  %t236 = getelementptr i8, ptr %t235, i64 %t229
  call void @olang_textcopy(ptr %t236, ptr %t231, i64 %t232)
  %t237 = insertvalue { i64, ptr } undef, i64 %t233, 0
  %t238 = insertvalue { i64, ptr } %t237, ptr %t234, 1
  call void @__olang_scope_close(ptr %s10)
  store { i64, ptr } %t238, ptr %rv
  br label %ret
bb49:
  %t240 = load i32, ptr %l6
  %t242 = trunc i64 26 to i32
  %t243 = icmp eq i32 %t240, %t242
  br i1 %t243, label %bb50, label %bb51
bb50:
  %t245 = load ptr, ptr %l5, !tbaa !29
  %t246 = load i32, ptr %l1, !tbaa !23
  %t249 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstValue(ptr %v0, ptr %t245, i32 %t246)
  store i64 %t249, ptr %l155
  br label %bb52
bb51:
  br label %bb53
bb52:
  %t250 = load i64, ptr %l155, !tbaa !24
  %t251 = call i64 @__olang_fmt_i64(ptr null, i64 %t250)
  %t252 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t251)
  %t253 = call i64 @__olang_fmt_i64(ptr %t252, i64 %t250)
  %t254 = insertvalue { i64, ptr } undef, i64 %t251, 0
  %t255 = insertvalue { i64, ptr } %t254, ptr %t252, 1
  store { i64, ptr } %t255, ptr %rv
  br label %ret
bb53:
  %t257 = load i32, ptr %l6
  %t259 = trunc i64 22 to i32
  %t260 = icmp eq i32 %t257, %t259
  br i1 %t260, label %bb54, label %bb55
bb54:
  store %olang.scope zeroinitializer, ptr %s14
  %t262 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s14)
  store %"std/prelude/text:StringBuilder" %t262, ptr %l159
  br label %bb56
bb55:
  br label %bb80
bb56:
  %t263 = load %"std/prelude/text:StringBuilder", ptr %l159
  store %"std/prelude/text:StringBuilder" %t263, ptr %l17
  %t264 = load ptr, ptr %l5, !tbaa !29
  store ptr %t264, ptr %l160, !tbaa !29
  %t265 = load ptr, ptr %l5, !tbaa !29
  %t266 = load i32, ptr %l1, !tbaa !23
  %t269 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t265, i32 %t266)
  store i32 %t269, ptr %l163
  br label %bb57
bb57:
  %t270 = load ptr, ptr %l160, !tbaa !29
  %t271 = load i32, ptr %l163, !tbaa !23
  %t272 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t270, i32 %t271)
  store { i64, ptr } %t272, ptr %l164
  br label %bb58
bb58:
  %t273 = load { i64, ptr }, ptr %l164, !tbaa !27
  store { i64, ptr } %t273, ptr %l18, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s14, ptr %l17, i8 40)
  br label %bb59
bb59:
  store i64 0, ptr %l19, !tbaa !24
  %t275 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t277 = extractvalue { i64, ptr } %t275, 0
  store i64 %t277, ptr %l20, !tbaa !24
  store i64 1, ptr %l21, !tbaa !24
  %t279 = load i64, ptr %l20, !tbaa !24
  %t280 = load i64, ptr %l19, !tbaa !24
  %t283 = icmp sgt i64 %t279, %t280
  br i1 %t283, label %bb60, label %bb61
bb60:
  %t285 = load i64, ptr %l21, !tbaa !24
  %t287 = icmp sgt i64 %t285, 0
  br i1 %t287, label %bb62, label %bb63
bb61:
  store i64 0, ptr %l171, !tbaa !24
  br label %bb65
bb62:
  %t289 = load i64, ptr %l20, !tbaa !24
  %t290 = load i64, ptr %l19, !tbaa !24
  %t293 = sub i64 %t289, %t290
  %t294 = load i64, ptr %l21, !tbaa !24
  %t297 = add i64 %t293, %t294
  %t299 = sub i64 %t297, 1
  %t300 = load i64, ptr %l21, !tbaa !24
  %t303 = sdiv i64 %t299, %t300
  store i64 %t303, ptr %l174, !tbaa !24
  br label %bb64
bb63:
  store i64 0, ptr %l174, !tbaa !24
  br label %bb64
bb64:
  %t305 = load i64, ptr %l174, !tbaa !24
  store i64 %t305, ptr %l171, !tbaa !24
  br label %bb65
bb65:
  %t306 = load i64, ptr %l171, !tbaa !24
  store i64 %t306, ptr %l22, !tbaa !24
  store i64 0, ptr %l23, !tbaa !24
  br label %bb66
bb66:
  store %olang.scope zeroinitializer, ptr %s16
  %t307 = load i64, ptr %l23, !tbaa !24
  %t308 = load i64, ptr %l22, !tbaa !24
  %t311 = icmp slt i64 %t307, %t308
  %t313 = xor i1 %t311, true
  br i1 %t313, label %bb67, label %bb68
bb67:
  call void @__olang_scope_close(ptr %s16)
  br label %bb77
bb68:
  br label %bb69
bb69:
  %t315 = load i64, ptr %l19, !tbaa !24
  %t316 = load i64, ptr %l23, !tbaa !24
  %t317 = load i64, ptr %l21, !tbaa !24
  %t320 = mul i64 %t316, %t317
  %t323 = add i64 %t315, %t320
  store i64 %t323, ptr %l24, !tbaa !24
  %t325 = load i64, ptr %l24, !tbaa !24
  %t327 = icmp sgt i64 %t325, 0
  br i1 %t327, label %bb70, label %bb71
bb70:
  store %olang.scope zeroinitializer, ptr %s17
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s14, ptr %s17, ptr %l17, { i64, ptr } { i64 2, ptr @.d23 })
  br label %bb72
bb71:
  br label %bb73
bb72:
  call void @__olang_scope_close(ptr %s17)
  br label %bb73
bb73:
  store ptr %l17, ptr %l195, !tbaa !29
  %t330 = load ptr, ptr %l0, !tbaa !29
  %t331 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t331, ptr %l197, !tbaa !27
  %t332 = load i64, ptr %l24, !tbaa !24
  %t334 = getelementptr { i64, ptr }, ptr %l197, i32 0, i32 1
  %t335 = load ptr, ptr %t334, !tbaa !27
  %t336 = getelementptr i32, ptr %t335, i64 %t332
  %t337 = load i32, ptr %t336, !tbaa !33
  %t340 = call { i64, ptr } @compiler_2flower_2ecompiler_2flower_3alowering_2espell(ptr %v0, ptr %s16, ptr %t330, i32 %t337, i1 true, i1 true, i1 false)
  store { i64, ptr } %t340, ptr %l200
  br label %bb74
bb74:
  %t341 = load { i64, ptr }, ptr %l200, !tbaa !27
  %t342 = extractvalue { i64, ptr } %t341, 0
  %t343 = extractvalue { i64, ptr } %t341, 1
  %t344 = mul i64 %t342, 1
  %t345 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t344)
  call void @llvm.memcpy.p0.p0.i64(ptr %t345, ptr %t343, i64 %t344, i1 false)
  %t346 = insertvalue { i64, ptr } undef, i64 %t342, 0
  %t347 = insertvalue { i64, ptr } %t346, ptr %t345, 1
  %t348 = load ptr, ptr %l195, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s14, ptr %s16, ptr %t348, { i64, ptr } %t347)
  br label %bb75
bb75:
  call void @__olang_scope_close(ptr %s16)
  br label %bb76
bb76:
  %t350 = load i64, ptr %l23, !tbaa !24
  %t352 = add i64 %t350, 1
  store i64 %t352, ptr %l23, !tbaa !24
  br label %bb66
bb77:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s14, ptr %l17, i8 41)
  br label %bb78
bb78:
  %t356 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s14, ptr %v1, ptr %l17)
  store { i64, ptr } %t356, ptr %l206
  br label %bb79
bb79:
  %t357 = load { i64, ptr }, ptr %l206, !tbaa !27
  store { i64, ptr } %t357, ptr %l207, !tbaa !27
  %t358 = load { i64, ptr }, ptr %l207, !tbaa !27
  %t359 = extractvalue { i64, ptr } %t358, 0
  store i64 %t359, ptr %l208, !tbaa !24
  %t360 = load i64, ptr %l208, !tbaa !24
  %t361 = mul i64 %t360, 1
  %t362 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t361)
  %t363 = insertvalue { i64, ptr } undef, i64 %t360, 0
  %t364 = insertvalue { i64, ptr } %t363, ptr %t362, 1
  store { i64, ptr } %t364, ptr %l209, !tbaa !27
  %t365 = getelementptr { i64, ptr }, ptr %l209, i32 0, i32 1
  %t366 = load ptr, ptr %t365, !tbaa !27
  %t367 = getelementptr { i64, ptr }, ptr %l207, i32 0, i32 1
  %t368 = load ptr, ptr %t367, !tbaa !27
  %t369 = load i64, ptr %l208, !tbaa !24
  %t370 = mul i64 %t369, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t366, ptr %t368, i64 %t370, i1 false)
  %t371 = load { i64, ptr }, ptr %l209, !tbaa !27
  store { i64, ptr } %t371, ptr %l207, !tbaa !27
  call void @__olang_scope_close(ptr %s14)
  %t372 = load { i64, ptr }, ptr %l207, !tbaa !27
  store { i64, ptr } %t372, ptr %rv
  br label %ret
bb80:
  %t373 = load i32, ptr %l6
  %t375 = trunc i64 21 to i32
  %t376 = icmp eq i32 %t373, %t375
  br i1 %t376, label %bb81, label %bb82
bb81:
  store %olang.scope zeroinitializer, ptr %s19
  %t378 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s19)
  store %"std/prelude/text:StringBuilder" %t378, ptr %l212
  br label %bb83
bb82:
  br label %bb205
bb83:
  %t379 = load %"std/prelude/text:StringBuilder", ptr %l212
  store %"std/prelude/text:StringBuilder" %t379, ptr %l25
  %t380 = load ptr, ptr %l5, !tbaa !29
  %t381 = load i32, ptr %l1, !tbaa !23
  %t384 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t380, i32 %t381)
  store i32 %t384, ptr %l215
  br label %bb84
bb84:
  %t385 = load i32, ptr %l215, !tbaa !23
  store i32 %t385, ptr %l26, !tbaa !23
  %t386 = load ptr, ptr %l5, !tbaa !29
  store ptr %t386, ptr %l216, !tbaa !29
  %t387 = load ptr, ptr %l5, !tbaa !29
  %t388 = load i32, ptr %l1, !tbaa !23
  %t391 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t387, i32 %t388)
  store i32 %t391, ptr %l219
  br label %bb85
bb85:
  %t392 = load ptr, ptr %l216, !tbaa !29
  %t393 = load i32, ptr %l219, !tbaa !23
  %t394 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t392, i32 %t393)
  store { i64, ptr } %t394, ptr %l220
  br label %bb86
bb86:
  %t395 = load { i64, ptr }, ptr %l220, !tbaa !27
  store { i64, ptr } %t395, ptr %l27, !tbaa !27
  %t396 = load ptr, ptr %l5, !tbaa !29
  %t397 = load i32, ptr %l26, !tbaa !23
  %t400 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t396, i32 %t397)
  store i32 %t400, ptr %l223
  br label %bb87
bb87:
  %t401 = load i32, ptr %l223
  %t403 = trunc i64 22 to i32
  %t404 = icmp eq i32 %t401, %t403
  br i1 %t404, label %bb88, label %bb89
bb88:
  %t406 = load ptr, ptr %l5, !tbaa !29
  store ptr %t406, ptr %l227, !tbaa !29
  %t407 = load ptr, ptr %l5, !tbaa !29
  %t408 = load i32, ptr %l26, !tbaa !23
  %t411 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t407, i32 %t408)
  store i32 %t411, ptr %l230
  br label %bb90
bb89:
  store i1 false, ptr %l226, !tbaa !21
  br label %bb92
bb90:
  %t412 = load ptr, ptr %l227, !tbaa !29
  %t413 = load i32, ptr %l230, !tbaa !23
  %t414 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t412, i32 %t413)
  store { i64, ptr } %t414, ptr %l231
  br label %bb91
bb91:
  %t415 = load { i64, ptr }, ptr %l231, !tbaa !27
  %t416 = extractvalue { i64, ptr } %t415, 0
  %t418 = icmp sgt i64 %t416, 1
  store i1 %t418, ptr %l226, !tbaa !21
  br label %bb92
bb92:
  %t420 = load i1, ptr %l226, !tbaa !21
  br i1 %t420, label %bb93, label %bb94
bb93:
  store i1 true, ptr %l234, !tbaa !21
  br label %bb95
bb94:
  %t421 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t423 = extractvalue { i64, ptr } %t421, 0
  %t425 = icmp sgt i64 %t423, 1
  store i1 %t425, ptr %l234, !tbaa !21
  br label %bb95
bb95:
  %t427 = load i1, ptr %l234, !tbaa !21
  store i1 %t427, ptr %l28, !tbaa !21
  %t428 = load i1, ptr %l2, !tbaa !21
  br i1 %t428, label %bb96, label %bb97
bb96:
  br i1 %a4, label %bb98, label %bb99
bb97:
  store i1 false, ptr %l239, !tbaa !21
  br label %bb104
bb98:
  store i1 true, ptr %l241, !tbaa !21
  br label %bb103
bb99:
  %t432 = load i1, ptr %l3, !tbaa !21
  br i1 %t432, label %bb100, label %bb101
bb100:
  %t434 = load i1, ptr %l28, !tbaa !21
  store i1 %t434, ptr %l243, !tbaa !21
  br label %bb102
bb101:
  store i1 false, ptr %l243, !tbaa !21
  br label %bb102
bb102:
  %t436 = load i1, ptr %l243, !tbaa !21
  store i1 %t436, ptr %l241, !tbaa !21
  br label %bb103
bb103:
  %t437 = load i1, ptr %l241, !tbaa !21
  store i1 %t437, ptr %l239, !tbaa !21
  br label %bb104
bb104:
  %t438 = load i1, ptr %l239, !tbaa !21
  store i1 %t438, ptr %l29, !tbaa !21
  %t439 = load i1, ptr %l29, !tbaa !21
  br i1 %t439, label %bb105, label %bb106
bb105:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s19, ptr %l25, i8 40)
  br label %bb107
bb106:
  br label %bb108
bb107:
  br label %bb108
bb108:
  %t442 = load i1, ptr %l2, !tbaa !21
  br i1 %t442, label %bb109, label %bb110
bb109:
  store %olang.scope zeroinitializer, ptr %s21
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s19, ptr %s21, ptr %l25, { i64, ptr } { i64 2, ptr @.d24 })
  br label %bb111
bb110:
  br label %bb112
bb111:
  call void @__olang_scope_close(ptr %s21)
  br label %bb112
bb112:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s19, ptr %l25, i8 40)
  br label %bb113
bb113:
  %t446 = load ptr, ptr %l5, !tbaa !29
  store ptr %t446, ptr %l250, !tbaa !29
  %t447 = load ptr, ptr %l5, !tbaa !29
  %t448 = load i32, ptr %l1, !tbaa !23
  %t451 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t447, i32 %t448)
  store i32 %t451, ptr %l253
  br label %bb114
bb114:
  %t452 = load ptr, ptr %l250, !tbaa !29
  %t453 = load i32, ptr %l253, !tbaa !23
  %t454 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t452, i32 %t453)
  store { i64, ptr } %t454, ptr %l254
  br label %bb115
bb115:
  %t455 = load { i64, ptr }, ptr %l254, !tbaa !27
  store { i64, ptr } %t455, ptr %l30, !tbaa !27
  %t456 = load ptr, ptr %l5, !tbaa !29
  %t457 = load i32, ptr %l1, !tbaa !23
  %t460 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNamesOf(ptr %v0, ptr %t456, i32 %t457)
  store { i64, ptr } %t460, ptr %l257
  br label %bb116
bb116:
  %t461 = load { i64, ptr }, ptr %l257, !tbaa !27
  store { i64, ptr } %t461, ptr %l31, !tbaa !27
  store i64 0, ptr %l32, !tbaa !24
  %t462 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t464 = extractvalue { i64, ptr } %t462, 0
  store i64 %t464, ptr %l33, !tbaa !24
  store i64 1, ptr %l34, !tbaa !24
  %t466 = load i64, ptr %l33, !tbaa !24
  %t467 = load i64, ptr %l32, !tbaa !24
  %t470 = icmp sgt i64 %t466, %t467
  br i1 %t470, label %bb117, label %bb118
bb117:
  %t472 = load i64, ptr %l34, !tbaa !24
  %t474 = icmp sgt i64 %t472, 0
  br i1 %t474, label %bb119, label %bb120
bb118:
  store i64 0, ptr %l263, !tbaa !24
  br label %bb122
bb119:
  %t476 = load i64, ptr %l33, !tbaa !24
  %t477 = load i64, ptr %l32, !tbaa !24
  %t480 = sub i64 %t476, %t477
  %t481 = load i64, ptr %l34, !tbaa !24
  %t484 = add i64 %t480, %t481
  %t486 = sub i64 %t484, 1
  %t487 = load i64, ptr %l34, !tbaa !24
  %t490 = sdiv i64 %t486, %t487
  store i64 %t490, ptr %l266, !tbaa !24
  br label %bb121
bb120:
  store i64 0, ptr %l266, !tbaa !24
  br label %bb121
bb121:
  %t492 = load i64, ptr %l266, !tbaa !24
  store i64 %t492, ptr %l263, !tbaa !24
  br label %bb122
bb122:
  %t493 = load i64, ptr %l263, !tbaa !24
  store i64 %t493, ptr %l35, !tbaa !24
  store i64 0, ptr %l36, !tbaa !24
  br label %bb123
bb123:
  store %olang.scope zeroinitializer, ptr %s23
  %t494 = load i64, ptr %l36, !tbaa !24
  %t495 = load i64, ptr %l35, !tbaa !24
  %t498 = icmp slt i64 %t494, %t495
  %t500 = xor i1 %t498, true
  br i1 %t500, label %bb124, label %bb125
bb124:
  call void @__olang_scope_close(ptr %s23)
  br label %bb139
bb125:
  br label %bb126
bb126:
  %t502 = load i64, ptr %l32, !tbaa !24
  %t503 = load i64, ptr %l36, !tbaa !24
  %t504 = load i64, ptr %l34, !tbaa !24
  %t507 = mul i64 %t503, %t504
  %t510 = add i64 %t502, %t507
  store i64 %t510, ptr %l37, !tbaa !24
  %t512 = load i64, ptr %l37, !tbaa !24
  %t514 = icmp sgt i64 %t512, 0
  br i1 %t514, label %bb127, label %bb128
bb127:
  store %olang.scope zeroinitializer, ptr %s24
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s19, ptr %s24, ptr %l25, { i64, ptr } { i64 2, ptr @.d25 })
  br label %bb129
bb128:
  br label %bb130
bb129:
  call void @__olang_scope_close(ptr %s24)
  br label %bb130
bb130:
  %t517 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t519 = extractvalue { i64, ptr } %t517, 0
  %t520 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t522 = extractvalue { i64, ptr } %t520, 0
  %t525 = icmp eq i64 %t519, %t522
  br i1 %t525, label %bb131, label %bb132
bb131:
  store %olang.scope zeroinitializer, ptr %s25
  store ptr %l25, ptr %l292, !tbaa !29
  %t527 = load ptr, ptr %l5, !tbaa !29
  %t529 = getelementptr %"compiler/types:Table", ptr %t527, i32 0, i32 0
  %t530 = load ptr, ptr %t529, !tbaa !29
  %t531 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t531, ptr %l295, !tbaa !27
  %t532 = load i64, ptr %l37, !tbaa !24
  %t534 = getelementptr { i64, ptr }, ptr %l295, i32 0, i32 1
  %t535 = load ptr, ptr %t534, !tbaa !27
  %t536 = getelementptr i64, ptr %t535, i64 %t532
  %t537 = load i64, ptr %t536, !tbaa !34
  %t539 = trunc i64 %t537 to i32
  %t543 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t530, i32 %t539)
  store { i64, ptr } %t543, ptr %l300
  br label %bb133
bb132:
  br label %bb135
bb133:
  %t544 = load { i64, ptr }, ptr %l300, !tbaa !27
  %t545 = extractvalue { i64, ptr } %t544, 1
  %t546 = extractvalue { i64, ptr } %t544, 0
  %t547 = extractvalue { i64, ptr } { i64 1, ptr @.d26 }, 1
  %t548 = extractvalue { i64, ptr } { i64 1, ptr @.d26 }, 0
  %t549 = add i64 %t546, %t548
  %t550 = call ptr @__olang_scope_alloc(ptr %s25, i64 %t549)
  call void @olang_textcopy(ptr %t550, ptr %t545, i64 %t546)
  %t551 = getelementptr i8, ptr %t550, i64 %t546
  call void @olang_textcopy(ptr %t551, ptr %t547, i64 %t548)
  %t552 = insertvalue { i64, ptr } undef, i64 %t549, 0
  %t553 = insertvalue { i64, ptr } %t552, ptr %t550, 1
  %t555 = extractvalue { i64, ptr } %t553, 0
  %t556 = extractvalue { i64, ptr } %t553, 1
  %t557 = mul i64 %t555, 1
  %t558 = call ptr @__olang_scope_alloc(ptr %s25, i64 %t557)
  call void @llvm.memcpy.p0.p0.i64(ptr %t558, ptr %t556, i64 %t557, i1 false)
  %t559 = insertvalue { i64, ptr } undef, i64 %t555, 0
  %t560 = insertvalue { i64, ptr } %t559, ptr %t558, 1
  %t561 = load ptr, ptr %l292, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s19, ptr %s25, ptr %t561, { i64, ptr } %t560)
  br label %bb134
bb134:
  call void @__olang_scope_close(ptr %s25)
  br label %bb135
bb135:
  store ptr %l25, ptr %l303, !tbaa !29
  %t563 = load ptr, ptr %l0, !tbaa !29
  %t564 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t564, ptr %l305, !tbaa !27
  %t565 = load i64, ptr %l37, !tbaa !24
  %t567 = getelementptr { i64, ptr }, ptr %l305, i32 0, i32 1
  %t568 = load ptr, ptr %t567, !tbaa !27
  %t569 = getelementptr i32, ptr %t568, i64 %t565
  %t570 = load i32, ptr %t569, !tbaa !33
  %t573 = call { i64, ptr } @compiler_2flower_2ecompiler_2flower_3alowering_2espell(ptr %v0, ptr %s23, ptr %t563, i32 %t570, i1 true, i1 true, i1 false)
  store { i64, ptr } %t573, ptr %l308
  br label %bb136
bb136:
  %t574 = load { i64, ptr }, ptr %l308, !tbaa !27
  %t575 = extractvalue { i64, ptr } %t574, 0
  %t576 = extractvalue { i64, ptr } %t574, 1
  %t577 = mul i64 %t575, 1
  %t578 = call ptr @__olang_scope_alloc(ptr %s23, i64 %t577)
  call void @llvm.memcpy.p0.p0.i64(ptr %t578, ptr %t576, i64 %t577, i1 false)
  %t579 = insertvalue { i64, ptr } undef, i64 %t575, 0
  %t580 = insertvalue { i64, ptr } %t579, ptr %t578, 1
  %t581 = load ptr, ptr %l303, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s19, ptr %s23, ptr %t581, { i64, ptr } %t580)
  br label %bb137
bb137:
  call void @__olang_scope_close(ptr %s23)
  br label %bb138
bb138:
  %t583 = load i64, ptr %l36, !tbaa !24
  %t585 = add i64 %t583, 1
  store i64 %t585, ptr %l36, !tbaa !24
  br label %bb123
bb139:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s19, ptr %l25, i8 41)
  br label %bb140
bb140:
  %t588 = load ptr, ptr %l5, !tbaa !29
  %t589 = load i32, ptr %l26, !tbaa !23
  %t592 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t588, i32 %t589)
  store i32 %t592, ptr %l315
  br label %bb141
bb141:
  %t593 = load i32, ptr %l315
  %t595 = trunc i64 22 to i32
  %t596 = icmp eq i32 %t593, %t595
  br i1 %t596, label %bb142, label %bb143
bb142:
  %t598 = load ptr, ptr %l5, !tbaa !29
  store ptr %t598, ptr %l318, !tbaa !29
  %t599 = load ptr, ptr %l5, !tbaa !29
  %t600 = load i32, ptr %l26, !tbaa !23
  %t603 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t599, i32 %t600)
  store i32 %t603, ptr %l321
  br label %bb144
bb143:
  %t604 = load i32, ptr %l26, !tbaa !23
  %t605 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t608 = icmp ne i32 %t604, %t605
  br i1 %t608, label %bb163, label %bb164
bb144:
  %t610 = load ptr, ptr %l318, !tbaa !29
  %t611 = load i32, ptr %l321, !tbaa !23
  %t612 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t610, i32 %t611)
  store { i64, ptr } %t612, ptr %l322
  br label %bb145
bb145:
  %t613 = load { i64, ptr }, ptr %l322, !tbaa !27
  store { i64, ptr } %t613, ptr %l38, !tbaa !27
  store i64 0, ptr %l39, !tbaa !24
  %t614 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t616 = extractvalue { i64, ptr } %t614, 0
  store i64 %t616, ptr %l40, !tbaa !24
  store i64 1, ptr %l41, !tbaa !24
  %t618 = load i64, ptr %l40, !tbaa !24
  %t619 = load i64, ptr %l39, !tbaa !24
  %t622 = icmp sgt i64 %t618, %t619
  br i1 %t622, label %bb146, label %bb147
bb146:
  %t624 = load i64, ptr %l41, !tbaa !24
  %t626 = icmp sgt i64 %t624, 0
  br i1 %t626, label %bb148, label %bb149
bb147:
  store i64 0, ptr %l328, !tbaa !24
  br label %bb151
bb148:
  %t628 = load i64, ptr %l40, !tbaa !24
  %t629 = load i64, ptr %l39, !tbaa !24
  %t632 = sub i64 %t628, %t629
  %t633 = load i64, ptr %l41, !tbaa !24
  %t636 = add i64 %t632, %t633
  %t638 = sub i64 %t636, 1
  %t639 = load i64, ptr %l41, !tbaa !24
  %t642 = sdiv i64 %t638, %t639
  store i64 %t642, ptr %l331, !tbaa !24
  br label %bb150
bb149:
  store i64 0, ptr %l331, !tbaa !24
  br label %bb150
bb150:
  %t644 = load i64, ptr %l331, !tbaa !24
  store i64 %t644, ptr %l328, !tbaa !24
  br label %bb151
bb151:
  %t645 = load i64, ptr %l328, !tbaa !24
  store i64 %t645, ptr %l42, !tbaa !24
  store i64 0, ptr %l43, !tbaa !24
  br label %bb152
bb152:
  store %olang.scope zeroinitializer, ptr %s30
  %t646 = load i64, ptr %l43, !tbaa !24
  %t647 = load i64, ptr %l42, !tbaa !24
  %t650 = icmp slt i64 %t646, %t647
  %t652 = xor i1 %t650, true
  br i1 %t652, label %bb153, label %bb154
bb153:
  call void @__olang_scope_close(ptr %s30)
  br label %bb162
bb154:
  br label %bb155
bb155:
  %t654 = load i64, ptr %l39, !tbaa !24
  %t655 = load i64, ptr %l43, !tbaa !24
  %t656 = load i64, ptr %l41, !tbaa !24
  %t659 = mul i64 %t655, %t656
  %t662 = add i64 %t654, %t659
  store i64 %t662, ptr %l44, !tbaa !24
  store ptr %l25, ptr %l349, !tbaa !29
  %t664 = load i64, ptr %l44, !tbaa !24
  %t666 = icmp sgt i64 %t664, 0
  br i1 %t666, label %bb156, label %bb157
bb156:
  store { i64, ptr } { i64 2, ptr @.d27 }, ptr %l352, !tbaa !27
  br label %bb158
bb157:
  store { i64, ptr } { i64 1, ptr @.d28 }, ptr %l352, !tbaa !27
  br label %bb158
bb158:
  %t668 = load ptr, ptr %l0, !tbaa !29
  %t669 = load { i64, ptr }, ptr %l38, !tbaa !27
  store { i64, ptr } %t669, ptr %l354, !tbaa !27
  %t670 = load i64, ptr %l44, !tbaa !24
  %t672 = getelementptr { i64, ptr }, ptr %l354, i32 0, i32 1
  %t673 = load ptr, ptr %t672, !tbaa !27
  %t674 = getelementptr i32, ptr %t673, i64 %t670
  %t675 = load i32, ptr %t674, !tbaa !33
  %t678 = call { i64, ptr } @compiler_2flower_2ecompiler_2flower_3alowering_2espell(ptr %v0, ptr %s30, ptr %t668, i32 %t675, i1 true, i1 true, i1 false)
  store { i64, ptr } %t678, ptr %l357
  br label %bb159
bb159:
  %t679 = load { i64, ptr }, ptr %l352, !tbaa !27
  %t680 = extractvalue { i64, ptr } %t679, 1
  %t681 = extractvalue { i64, ptr } %t679, 0
  %t682 = load { i64, ptr }, ptr %l357, !tbaa !27
  %t683 = extractvalue { i64, ptr } %t682, 1
  %t684 = extractvalue { i64, ptr } %t682, 0
  %t685 = add i64 %t681, %t684
  %t686 = call ptr @__olang_scope_alloc(ptr %s30, i64 %t685)
  call void @olang_textcopy(ptr %t686, ptr %t680, i64 %t681)
  %t687 = getelementptr i8, ptr %t686, i64 %t681
  call void @olang_textcopy(ptr %t687, ptr %t683, i64 %t684)
  %t688 = insertvalue { i64, ptr } undef, i64 %t685, 0
  %t689 = insertvalue { i64, ptr } %t688, ptr %t686, 1
  %t691 = extractvalue { i64, ptr } %t689, 0
  %t692 = extractvalue { i64, ptr } %t689, 1
  %t693 = mul i64 %t691, 1
  %t694 = call ptr @__olang_scope_alloc(ptr %s30, i64 %t693)
  call void @llvm.memcpy.p0.p0.i64(ptr %t694, ptr %t692, i64 %t693, i1 false)
  %t695 = insertvalue { i64, ptr } undef, i64 %t691, 0
  %t696 = insertvalue { i64, ptr } %t695, ptr %t694, 1
  %t697 = load ptr, ptr %l349, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s19, ptr %s30, ptr %t697, { i64, ptr } %t696)
  br label %bb160
bb160:
  call void @__olang_scope_close(ptr %s30)
  br label %bb161
bb161:
  %t699 = load i64, ptr %l43, !tbaa !24
  %t701 = add i64 %t699, 1
  store i64 %t701, ptr %l43, !tbaa !24
  br label %bb152
bb162:
  br label %bb177
bb163:
  store %olang.scope zeroinitializer, ptr %s34
  %t703 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t705 = extractvalue { i64, ptr } %t703, 0
  %t707 = icmp sgt i64 %t705, 0
  br i1 %t707, label %bb165, label %bb166
bb164:
  br label %bb176
bb165:
  %t709 = load ptr, ptr %l5, !tbaa !29
  %t710 = load i32, ptr %l26, !tbaa !23
  %t713 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t709, i32 %t710)
  store i32 %t713, ptr %l371
  br label %bb167
bb166:
  store i1 false, ptr %l368, !tbaa !21
  br label %bb168
bb167:
  %t714 = load i32, ptr %l371
  %t716 = trunc i64 21 to i32
  %t717 = icmp eq i32 %t714, %t716
  store i1 %t717, ptr %l368, !tbaa !21
  br label %bb168
bb168:
  %t719 = load i1, ptr %l368, !tbaa !21
  br i1 %t719, label %bb169, label %bb170
bb169:
  %t720 = load ptr, ptr %l5, !tbaa !29
  store ptr %t720, ptr %l375, !tbaa !29
  %t721 = load ptr, ptr %l5, !tbaa !29
  %t722 = load i32, ptr %l26, !tbaa !23
  %t725 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t721, i32 %t722)
  store i32 %t725, ptr %l378
  br label %bb171
bb170:
  store i1 false, ptr %l374, !tbaa !21
  br label %bb173
bb171:
  %t726 = load ptr, ptr %l375, !tbaa !29
  %t727 = load i32, ptr %l378, !tbaa !23
  %t728 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t726, i32 %t727)
  store { i64, ptr } %t728, ptr %l379
  br label %bb172
bb172:
  %t729 = load { i64, ptr }, ptr %l379, !tbaa !27
  %t730 = extractvalue { i64, ptr } %t729, 0
  %t732 = icmp eq i64 %t730, 0
  store i1 %t732, ptr %l374, !tbaa !21
  br label %bb173
bb173:
  %t734 = load i1, ptr %l374, !tbaa !21
  store ptr %l25, ptr %l382, !tbaa !29
  %t735 = load ptr, ptr %l0, !tbaa !29
  %t736 = load i32, ptr %l26, !tbaa !23
  %t741 = call { i64, ptr } @compiler_2flower_2ecompiler_2flower_3alowering_2espell(ptr %v0, ptr %s34, ptr %t735, i32 %t736, i1 true, i1 true, i1 %t734)
  store { i64, ptr } %t741, ptr %l386
  br label %bb174
bb174:
  %t742 = extractvalue { i64, ptr } { i64 1, ptr @.d29 }, 1
  %t743 = extractvalue { i64, ptr } { i64 1, ptr @.d29 }, 0
  %t744 = load { i64, ptr }, ptr %l386, !tbaa !27
  %t745 = extractvalue { i64, ptr } %t744, 1
  %t746 = extractvalue { i64, ptr } %t744, 0
  %t747 = add i64 %t743, %t746
  %t748 = call ptr @__olang_scope_alloc(ptr %s34, i64 %t747)
  call void @olang_textcopy(ptr %t748, ptr %t742, i64 %t743)
  %t749 = getelementptr i8, ptr %t748, i64 %t743
  call void @olang_textcopy(ptr %t749, ptr %t745, i64 %t746)
  %t750 = insertvalue { i64, ptr } undef, i64 %t747, 0
  %t751 = insertvalue { i64, ptr } %t750, ptr %t748, 1
  %t753 = extractvalue { i64, ptr } %t751, 0
  %t754 = extractvalue { i64, ptr } %t751, 1
  %t755 = mul i64 %t753, 1
  %t756 = call ptr @__olang_scope_alloc(ptr %s34, i64 %t755)
  call void @llvm.memcpy.p0.p0.i64(ptr %t756, ptr %t754, i64 %t755, i1 false)
  %t757 = insertvalue { i64, ptr } undef, i64 %t753, 0
  %t758 = insertvalue { i64, ptr } %t757, ptr %t756, 1
  %t759 = load ptr, ptr %l382, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s19, ptr %s34, ptr %t759, { i64, ptr } %t758)
  br label %bb175
bb175:
  call void @__olang_scope_close(ptr %s34)
  br label %bb176
bb176:
  br label %bb177
bb177:
  %t761 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t763 = extractvalue { i64, ptr } %t761, 0
  %t765 = icmp sgt i64 %t763, 0
  br i1 %t765, label %bb178, label %bb179
bb178:
  store %olang.scope zeroinitializer, ptr %s36
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s19, ptr %s36, ptr %l25, { i64, ptr } { i64 2, ptr @.d30 })
  br label %bb180
bb179:
  br label %bb199
bb180:
  store i64 0, ptr %l46, !tbaa !24
  %t768 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t770 = extractvalue { i64, ptr } %t768, 0
  store i64 %t770, ptr %l47, !tbaa !24
  store i64 1, ptr %l48, !tbaa !24
  %t772 = load i64, ptr %l47, !tbaa !24
  %t773 = load i64, ptr %l46, !tbaa !24
  %t776 = icmp sgt i64 %t772, %t773
  br i1 %t776, label %bb181, label %bb182
bb181:
  %t778 = load i64, ptr %l48, !tbaa !24
  %t780 = icmp sgt i64 %t778, 0
  br i1 %t780, label %bb183, label %bb184
bb182:
  store i64 0, ptr %l398, !tbaa !24
  br label %bb186
bb183:
  %t782 = load i64, ptr %l47, !tbaa !24
  %t783 = load i64, ptr %l46, !tbaa !24
  %t786 = sub i64 %t782, %t783
  %t787 = load i64, ptr %l48, !tbaa !24
  %t790 = add i64 %t786, %t787
  %t792 = sub i64 %t790, 1
  %t793 = load i64, ptr %l48, !tbaa !24
  %t796 = sdiv i64 %t792, %t793
  store i64 %t796, ptr %l401, !tbaa !24
  br label %bb185
bb184:
  store i64 0, ptr %l401, !tbaa !24
  br label %bb185
bb185:
  %t798 = load i64, ptr %l401, !tbaa !24
  store i64 %t798, ptr %l398, !tbaa !24
  br label %bb186
bb186:
  %t799 = load i64, ptr %l398, !tbaa !24
  store i64 %t799, ptr %l49, !tbaa !24
  store i64 0, ptr %l50, !tbaa !24
  br label %bb187
bb187:
  store %olang.scope zeroinitializer, ptr %s38
  %t800 = load i64, ptr %l50, !tbaa !24
  %t801 = load i64, ptr %l49, !tbaa !24
  %t804 = icmp slt i64 %t800, %t801
  %t806 = xor i1 %t804, true
  br i1 %t806, label %bb188, label %bb189
bb188:
  call void @__olang_scope_close(ptr %s38)
  br label %bb198
bb189:
  br label %bb190
bb190:
  %t808 = load i64, ptr %l46, !tbaa !24
  %t809 = load i64, ptr %l50, !tbaa !24
  %t810 = load i64, ptr %l48, !tbaa !24
  %t813 = mul i64 %t809, %t810
  %t816 = add i64 %t808, %t813
  store i64 %t816, ptr %l51, !tbaa !24
  store ptr %l25, ptr %l419, !tbaa !29
  %t818 = load i64, ptr %l51, !tbaa !24
  %t820 = icmp sgt i64 %t818, 0
  br i1 %t820, label %bb191, label %bb192
bb191:
  store { i64, ptr } { i64 2, ptr @.d31 }, ptr %l422, !tbaa !27
  br label %bb193
bb192:
  store { i64, ptr } { i64 1, ptr @.d32 }, ptr %l422, !tbaa !27
  br label %bb193
bb193:
  %t822 = load ptr, ptr %l0, !tbaa !29
  store ptr %t822, ptr %l423, !tbaa !29
  %t823 = load ptr, ptr %l5, !tbaa !29
  %t824 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t824, ptr %l425, !tbaa !27
  %t825 = load i64, ptr %l51, !tbaa !24
  %t827 = getelementptr { i64, ptr }, ptr %l425, i32 0, i32 1
  %t828 = load ptr, ptr %t827, !tbaa !27
  %t829 = getelementptr i32, ptr %t828, i64 %t825
  %t830 = load i32, ptr %t829, !tbaa !33
  %t833 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t823, i32 %t830)
  store i32 %t833, ptr %l428
  br label %bb194
bb194:
  %t834 = load ptr, ptr %l423, !tbaa !29
  %t835 = load i32, ptr %l428, !tbaa !23
  %t836 = call { i64, ptr } @compiler_2flower_2ecompiler_2flower_3alowering_2espell(ptr %v0, ptr %s38, ptr %t834, i32 %t835, i1 true, i1 false, i1 false)
  store { i64, ptr } %t836, ptr %l429
  br label %bb195
bb195:
  %t837 = load { i64, ptr }, ptr %l422, !tbaa !27
  %t838 = extractvalue { i64, ptr } %t837, 1
  %t839 = extractvalue { i64, ptr } %t837, 0
  %t840 = load { i64, ptr }, ptr %l429, !tbaa !27
  %t841 = extractvalue { i64, ptr } %t840, 1
  %t842 = extractvalue { i64, ptr } %t840, 0
  %t843 = add i64 %t839, %t842
  %t844 = call ptr @__olang_scope_alloc(ptr %s38, i64 %t843)
  call void @olang_textcopy(ptr %t844, ptr %t838, i64 %t839)
  %t845 = getelementptr i8, ptr %t844, i64 %t839
  call void @olang_textcopy(ptr %t845, ptr %t841, i64 %t842)
  %t846 = insertvalue { i64, ptr } undef, i64 %t843, 0
  %t847 = insertvalue { i64, ptr } %t846, ptr %t844, 1
  %t849 = extractvalue { i64, ptr } %t847, 0
  %t850 = extractvalue { i64, ptr } %t847, 1
  %t851 = mul i64 %t849, 1
  %t852 = call ptr @__olang_scope_alloc(ptr %s38, i64 %t851)
  call void @llvm.memcpy.p0.p0.i64(ptr %t852, ptr %t850, i64 %t851, i1 false)
  %t853 = insertvalue { i64, ptr } undef, i64 %t849, 0
  %t854 = insertvalue { i64, ptr } %t853, ptr %t852, 1
  %t855 = load ptr, ptr %l419, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s19, ptr %s38, ptr %t855, { i64, ptr } %t854)
  br label %bb196
bb196:
  call void @__olang_scope_close(ptr %s38)
  br label %bb197
bb197:
  %t857 = load i64, ptr %l50, !tbaa !24
  %t859 = add i64 %t857, 1
  store i64 %t859, ptr %l50, !tbaa !24
  br label %bb187
bb198:
  call void @__olang_scope_close(ptr %s36)
  br label %bb199
bb199:
  %t861 = load i1, ptr %l29, !tbaa !21
  br i1 %t861, label %bb200, label %bb201
bb200:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s19, ptr %l25, i8 41)
  br label %bb202
bb201:
  br label %bb203
bb202:
  br label %bb203
bb203:
  %t865 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s19, ptr %v1, ptr %l25)
  store { i64, ptr } %t865, ptr %l437
  br label %bb204
bb204:
  %t866 = load { i64, ptr }, ptr %l437, !tbaa !27
  store { i64, ptr } %t866, ptr %l438, !tbaa !27
  %t867 = load { i64, ptr }, ptr %l438, !tbaa !27
  %t868 = extractvalue { i64, ptr } %t867, 0
  store i64 %t868, ptr %l439, !tbaa !24
  %t869 = load i64, ptr %l439, !tbaa !24
  %t870 = mul i64 %t869, 1
  %t871 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t870)
  %t872 = insertvalue { i64, ptr } undef, i64 %t869, 0
  %t873 = insertvalue { i64, ptr } %t872, ptr %t871, 1
  store { i64, ptr } %t873, ptr %l440, !tbaa !27
  %t874 = getelementptr { i64, ptr }, ptr %l440, i32 0, i32 1
  %t875 = load ptr, ptr %t874, !tbaa !27
  %t876 = getelementptr { i64, ptr }, ptr %l438, i32 0, i32 1
  %t877 = load ptr, ptr %t876, !tbaa !27
  %t878 = load i64, ptr %l439, !tbaa !24
  %t879 = mul i64 %t878, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t875, ptr %t877, i64 %t879, i1 false)
  %t880 = load { i64, ptr }, ptr %l440, !tbaa !27
  store { i64, ptr } %t880, ptr %l438, !tbaa !27
  call void @__olang_scope_close(ptr %s19)
  %t881 = load { i64, ptr }, ptr %l438, !tbaa !27
  store { i64, ptr } %t881, ptr %rv
  br label %ret
bb205:
  %t882 = load ptr, ptr %l5, !tbaa !29
  %t883 = load i32, ptr %l1, !tbaa !23
  %t886 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %v1, ptr %t882, i32 %t883)
  store { i64, ptr } %t886, ptr %l443
  br label %bb206
bb206:
  %t887 = load { i64, ptr }, ptr %l443, !tbaa !27
  store { i64, ptr } %t887, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 6
  store i32 %a1, ptr %t5, !tbaa !23
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/lower:lowering", ptr %t6, i32 0, i32 7
  store i1 false, ptr %t8, !tbaa !21
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca { i64, [4 x i64] }
  %l7 = alloca %"compiler/source:Span"
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca %"compiler/lower:pl"
  %l11 = alloca { i64, [4 x i64] }
  %l12 = alloca i1
  %l13 = alloca ptr
  %l14 = alloca %"compiler/source:Span"
  %l15 = alloca ptr
  %l16 = alloca %"compiler/source:Span"
  %l17 = alloca ptr
  %l18 = alloca ptr
  %l19 = alloca %"compiler/source:Span"
  %l20 = alloca i32
  %l21 = alloca i32
  %l22 = alloca %"compiler/source:Span"
  %l23 = alloca ptr
  %l24 = alloca %"compiler/source:Span"
  %l25 = alloca i32
  %l26 = alloca i64
  %l28 = alloca %"compiler/source:Span"
  %l29 = alloca i32
  %l30 = alloca ptr
  %l31 = alloca { i64, [4 x i64] }
  %l32 = alloca i32
  %l33 = alloca %"compiler/source:Span"
  %l34 = alloca ptr
  %l35 = alloca ptr
  %l36 = alloca ptr
  %l37 = alloca %"compiler/source:Span"
  %l38 = alloca ptr
  %l39 = alloca %"compiler/source:Span"
  %l40 = alloca ptr
  %l41 = alloca %"compiler/source:Span"
  %l42 = alloca ptr
  %l43 = alloca %"compiler/source:Span"
  %l44 = alloca ptr
  %l47 = alloca ptr
  %l48 = alloca i1
  %l62 = alloca %"compiler/typed:Local"
  %l64 = alloca ptr
  %l68 = alloca { i64, [4 x i64] }
  %l73 = alloca { i64, [4 x i64] }
  %l77 = alloca i1
  %l78 = alloca i1
  %l82 = alloca ptr
  %l83 = alloca { i64, [4 x i64] }
  %l84 = alloca i32
  %l85 = alloca %"compiler/source:Span"
  %l88 = alloca { i64, [1 x i64] }
  %l89 = alloca { i64, [4 x i64] }
  %l94 = alloca %"compiler/mir:Local"
  %l105 = alloca ptr
  %l106 = alloca %"compiler/source:Span"
  %l110 = alloca %"compiler/mir:Place"
  %l115 = alloca ptr
  %l116 = alloca i1
  %l128 = alloca %"compiler/lower:pl"
  %l132 = alloca ptr
  %l136 = alloca { i64, [4 x i64] }
  %l138 = alloca ptr
  %l140 = alloca i32
  %l142 = alloca { i64, [4 x i64] }
  %l143 = alloca %"compiler/lower:pl"
  %l146 = alloca %"compiler/lower:pl"
  %l147 = alloca i32
  %l148 = alloca ptr
  %l150 = alloca i32
  %l151 = alloca i1
  %l152 = alloca i1
  %l156 = alloca ptr
  %l157 = alloca ptr
  %l159 = alloca i32
  %l160 = alloca i1
  %l161 = alloca ptr
  %l164 = alloca %"compiler/mir:Place"
  %l165 = alloca { i64, [4 x i64] }
  %l167 = alloca i32
  %l168 = alloca i1
  %l169 = alloca %"compiler/source:Span"
  %l172 = alloca { i64, [1 x i64] }
  %l173 = alloca ptr
  %l174 = alloca %"compiler/source:Span"
  %l177 = alloca %"compiler/mir:Place"
  %l182 = alloca ptr
  %l183 = alloca i1
  %l191 = alloca { i64, [4 x i64] }
  %l192 = alloca ptr
  %l193 = alloca i1
  %l203 = alloca ptr
  %l204 = alloca i1
  %l217 = alloca ptr
  %l218 = alloca i1
  %l231 = alloca ptr
  %l232 = alloca i1
  %l242 = alloca ptr
  %l243 = alloca i1
  %l253 = alloca ptr
  %l259 = alloca i32
  %l262 = alloca i64
  %l268 = alloca ptr
  %l269 = alloca i1
  %l285 = alloca { i64, [4 x i64] }
  %l288 = alloca i32
  %l299 = alloca ptr
  %l300 = alloca i1
  %l313 = alloca ptr
  %l314 = alloca i1
  %l321 = alloca ptr
  %l322 = alloca i1
  %l333 = alloca ptr
  %l335 = alloca %"compiler/lower:level"
  %l340 = alloca ptr
  %l341 = alloca %"compiler/source:Span"
  %l344 = alloca i64
  %l346 = alloca ptr
  %l347 = alloca i1
  %l357 = alloca ptr
  %l358 = alloca i1
  %l368 = alloca ptr
  %l369 = alloca i1
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %t121 = alloca { i64, [21 x i64] }, align 8
  %t141 = alloca { i64, [15 x i64] }, align 8
  %t147 = alloca { i64, [21 x i64] }, align 8
  %t289 = alloca { i64, [15 x i64] }, align 8
  %t295 = alloca { i64, [21 x i64] }, align 8
  %t511 = alloca { i64, [4 x i64] }, align 8
  %t549 = alloca { i64, [4 x i64] }, align 8
  %t585 = alloca { i64, [7 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 7
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l1, !tbaa !29
  store ptr %t6, ptr %l47, !tbaa !29
  store i1 false, ptr %l48, !tbaa !21
  %t7 = load ptr, ptr %l47, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb4, label %bb5
bb4:
  %t10 = load ptr, ptr %l47, !tbaa !29
  %t11 = load i64, ptr %t10
  %t13 = icmp eq i64 %t11, 0
  store i1 %t13, ptr %l48, !tbaa !21
  br label %bb5
bb5:
  %t14 = load i1, ptr %l48, !tbaa !21
  br i1 %t14, label %bb6, label %bb7
bb6:
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t17 = getelementptr { i64, [3 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t17, i32 0, i32 0
  %t19 = load %"compiler/source:Span", ptr %t18
  store %"compiler/source:Span" %t19, ptr %l2
  %t21 = load ptr, ptr %l1, !tbaa !29
  %t23 = getelementptr { i64, [3 x i64] }, ptr %t21, i32 0, i32 1
  %t24 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t23, i32 0, i32 1
  %t25 = load i32, ptr %t24
  store i32 %t25, ptr %l3, !tbaa !23
  %t27 = load ptr, ptr %l1, !tbaa !29
  %t29 = getelementptr { i64, [3 x i64] }, ptr %t27, i32 0, i32 1
  %t30 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t29, i32 0, i32 2
  %t31 = load ptr, ptr %t30
  store ptr %t31, ptr %l4, !tbaa !29
  br label %bb8
bb7:
  br label %bb28
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/lower:lowering", ptr %t33, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !29
  %t38 = getelementptr %"compiler/typed:Body", ptr %t36, i32 0, i32 7
  %t39 = load i32, ptr %l3, !tbaa !23
  %t41 = sext i32 %t39 to i64
  %t44 = call %"compiler/typed:Local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t38, i64 %t41)
  store %"compiler/typed:Local" %t44, ptr %l62
  br label %bb9
bb9:
  %t45 = getelementptr %"compiler/typed:Local", ptr %l62, i32 0, i32 2
  %t46 = load i32, ptr %t45, !tbaa !23
  store i32 %t46, ptr %l5, !tbaa !23
  %t48 = load ptr, ptr %l0, !tbaa !29
  store ptr %t48, ptr %l64, !tbaa !29
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t50 = load ptr, ptr %l4, !tbaa !29
  %t54 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v1, ptr %t49, ptr %t50)
  store { i64, [4 x i64] } %t54, ptr %l68
  br label %bb10
bb10:
  %t55 = load ptr, ptr %l4, !tbaa !29
  %t57 = load i32, ptr %l5, !tbaa !23
  %t58 = load %"compiler/source:Span", ptr %l2
  %t59 = load ptr, ptr %l64, !tbaa !29
  %t60 = load { i64, [4 x i64] }, ptr %l68
  %t64 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2efit(ptr %v0, ptr %v1, ptr %t59, { i64, [4 x i64] } %t60, ptr %t55, i32 %t57, %"compiler/source:Span" %t58)
  store { i64, [4 x i64] } %t64, ptr %l73
  br label %bb11
bb11:
  %t65 = load { i64, [4 x i64] }, ptr %l73
  store { i64, [4 x i64] } %t65, ptr %l6
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t67 = load ptr, ptr %l4, !tbaa !29
  %t68 = load i32, ptr %l5, !tbaa !23
  %t72 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2ecopiesArray(ptr %v0, ptr %v1, ptr %t66, ptr %t67, i32 %t68)
  store i1 %t72, ptr %l77
  br label %bb12
bb12:
  %t73 = load i1, ptr %l77, !tbaa !21
  br i1 %t73, label %bb13, label %bb14
bb13:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr %"compiler/lower:lowering", ptr %t74, i32 0, i32 7
  %t77 = load i1, ptr %t76, !tbaa !21
  %t79 = xor i1 %t77, true
  store i1 %t79, ptr %l78, !tbaa !21
  br label %bb15
bb14:
  store i1 false, ptr %l78, !tbaa !21
  br label %bb15
bb15:
  %t81 = load i1, ptr %l78, !tbaa !21
  br i1 %t81, label %bb16, label %bb17
bb16:
  %t82 = load ptr, ptr %l0, !tbaa !29
  store ptr %t82, ptr %l82, !tbaa !29
  %t83 = load { i64, [4 x i64] }, ptr %l6
  store { i64, [4 x i64] } %t83, ptr %l83
  %t84 = load i32, ptr %l5, !tbaa !23
  store i32 %t84, ptr %l84, !tbaa !23
  %t85 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t85, ptr %l85
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t87 = load i32, ptr %l3, !tbaa !23
  %t90 = call { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2estorageOf(ptr %v0, ptr %t86, i32 %t87)
  store { i64, [1 x i64] } %t90, ptr %l88
  br label %bb18
bb17:
  br label %bb20
bb18:
  %t91 = load ptr, ptr %l82, !tbaa !29
  %t92 = load { i64, [4 x i64] }, ptr %l83
  %t93 = load i32, ptr %l84, !tbaa !23
  %t94 = load %"compiler/source:Span", ptr %l85
  %t95 = load { i64, [1 x i64] }, ptr %l88
  %t96 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2earrayCopy(ptr %v0, ptr %t91, { i64, [4 x i64] } %t92, i32 %t93, %"compiler/source:Span" %t94, { i64, [1 x i64] } %t95)
  store { i64, [4 x i64] } %t96, ptr %l89
  br label %bb19
bb19:
  %t97 = load { i64, [4 x i64] }, ptr %l89
  store { i64, [4 x i64] } %t97, ptr %l6
  br label %bb20
bb20:
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t100 = getelementptr %"compiler/lower:lowering", ptr %t98, i32 0, i32 3
  %t101 = getelementptr %"compiler/mir:Fn", ptr %t100, i32 0, i32 7
  %t102 = load i32, ptr %l3, !tbaa !23
  %t104 = sext i32 %t102 to i64
  %t107 = call %"compiler/mir:Local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aLocal_3e_2eAt_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %t101, i64 %t104)
  store %"compiler/mir:Local" %t107, ptr %l94
  br label %bb21
bb21:
  %t108 = getelementptr %"compiler/mir:Local", ptr %l94, i32 0, i32 4
  %t109 = load { i64, [1 x i64] }, ptr %t108
  %t111 = extractvalue { i64, [1 x i64] } %t109, 0
  %t112 = icmp eq i64 %t111, 3
  %t114 = xor i1 %t112, true
  br i1 %t114, label %bb22, label %bb23
bb22:
  store %olang.scope zeroinitializer, ptr %s4
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t117 = load %"compiler/source:Span", ptr %l2
  %t118 = load i32, ptr %l3, !tbaa !23
  store { i64, [21 x i64] } zeroinitializer, ptr %t121
  %t122 = getelementptr { i64, [21 x i64] }, ptr %t121, i32 0, i32 0
  store i64 1, ptr %t122
  %t124 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t117, 0
  %t126 = insertvalue { %"compiler/source:Span", i32 } %t124, i32 %t118, 1
  %t127 = getelementptr { i64, [21 x i64] }, ptr %t121, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t126, ptr %t127
  %t128 = load { i64, [21 x i64] }, ptr %t121
  %t130 = call ptr @__olang_scope_alloc_a(ptr %s4, i64 176, i64 8)
  store { i64, [21 x i64] } %t128, ptr %t130
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s4, ptr %t116, ptr %t130)
  br label %bb24
bb23:
  br label %bb25
bb24:
  call void @__olang_scope_close(ptr %s4)
  br label %bb25
bb25:
  %t133 = load ptr, ptr %l0, !tbaa !29
  store ptr %t133, ptr %l105, !tbaa !29
  %t134 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t134, ptr %l106
  %t135 = load i32, ptr %l3, !tbaa !23
  %t139 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t135)
  store %"compiler/mir:Place" %t139, ptr %l110
  br label %bb26
bb26:
  %t140 = load { i64, [4 x i64] }, ptr %l6
  store { i64, [15 x i64] } zeroinitializer, ptr %t141
  %t142 = getelementptr { i64, [15 x i64] }, ptr %t141, i32 0, i32 0
  store i64 0, ptr %t142
  %t144 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t140, 0
  %t145 = getelementptr { i64, [15 x i64] }, ptr %t141, i32 0, i32 1
  store { { i64, [4 x i64] } } %t144, ptr %t145
  %t146 = load { i64, [15 x i64] }, ptr %t141
  store { i64, [21 x i64] } zeroinitializer, ptr %t147
  %t148 = getelementptr { i64, [21 x i64] }, ptr %t147, i32 0, i32 0
  store i64 0, ptr %t148
  %t149 = load %"compiler/source:Span", ptr %l106
  %t150 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t149, 0
  %t151 = load %"compiler/mir:Place", ptr %l110
  %t152 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t150, %"compiler/mir:Place" %t151, 1
  %t154 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t152, { i64, [15 x i64] } %t146, 2
  %t155 = getelementptr { i64, [21 x i64] }, ptr %t147, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t154, ptr %t155
  %t156 = load { i64, [21 x i64] }, ptr %t147
  %t158 = call ptr @__olang_scope_alloc_a(ptr %s2, i64 176, i64 8)
  store { i64, [21 x i64] } %t156, ptr %t158
  %t159 = load ptr, ptr %l105, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s2, ptr %t159, ptr %t158)
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s2)
  br label %bb170
bb28:
  %t161 = load ptr, ptr %l1, !tbaa !29
  store ptr %t161, ptr %l115, !tbaa !29
  store i1 false, ptr %l116, !tbaa !21
  %t162 = load ptr, ptr %l115, !tbaa !29
  %t163 = icmp ne ptr %t162, null
  br i1 %t163, label %bb29, label %bb30
bb29:
  %t165 = load ptr, ptr %l115, !tbaa !29
  %t166 = load i64, ptr %t165
  %t168 = icmp eq i64 %t166, 1
  store i1 %t168, ptr %l116, !tbaa !21
  br label %bb30
bb30:
  %t169 = load i1, ptr %l116, !tbaa !21
  br i1 %t169, label %bb31, label %bb32
bb31:
  %t170 = load ptr, ptr %l1, !tbaa !29
  %t172 = getelementptr { i64, [3 x i64] }, ptr %t170, i32 0, i32 1
  %t173 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t172, i32 0, i32 0
  %t174 = load %"compiler/source:Span", ptr %t173
  store %"compiler/source:Span" %t174, ptr %l7
  %t176 = load ptr, ptr %l1, !tbaa !29
  %t178 = getelementptr { i64, [3 x i64] }, ptr %t176, i32 0, i32 1
  %t179 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t178, i32 0, i32 1
  %t180 = load ptr, ptr %t179
  store ptr %t180, ptr %l8, !tbaa !29
  %t182 = load ptr, ptr %l1, !tbaa !29
  %t184 = getelementptr { i64, [3 x i64] }, ptr %t182, i32 0, i32 1
  %t185 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t184, i32 0, i32 2
  %t186 = load ptr, ptr %t185
  store ptr %t186, ptr %l9, !tbaa !29
  br label %bb33
bb32:
  br label %bb59
bb33:
  %t188 = load ptr, ptr %l0, !tbaa !29
  %t189 = load ptr, ptr %l8, !tbaa !29
  %t193 = call %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2eplace(ptr %v0, ptr %v1, ptr %v0, ptr %t188, ptr %t189)
  store %"compiler/lower:pl" %t193, ptr %l128
  br label %bb34
bb34:
  %t194 = load %"compiler/lower:pl", ptr %l128
  store %"compiler/lower:pl" %t194, ptr %l10
  %t195 = load ptr, ptr %l0, !tbaa !29
  %t197 = getelementptr %"compiler/lower:lowering", ptr %t195, i32 0, i32 15
  %t198 = load %"compiler/lower:pl", ptr %l10
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3apl_3e_2ePush_3ccompiler_2flower_3apl_3e(ptr %v0, ptr %v0, ptr %t197, %"compiler/lower:pl" %t198)
  br label %bb35
bb35:
  %t201 = load ptr, ptr %l0, !tbaa !29
  store ptr %t201, ptr %l132, !tbaa !29
  %t202 = load ptr, ptr %l0, !tbaa !29
  %t203 = load ptr, ptr %l9, !tbaa !29
  %t207 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v1, ptr %t202, ptr %t203)
  store { i64, [4 x i64] } %t207, ptr %l136
  br label %bb36
bb36:
  %t208 = load ptr, ptr %l9, !tbaa !29
  store ptr %t208, ptr %l138, !tbaa !29
  %t210 = load ptr, ptr %l8, !tbaa !29
  %t212 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aPlace_2eType(ptr %v1, ptr %t210)
  store i32 %t212, ptr %l140
  br label %bb37
bb37:
  %t213 = load %"compiler/source:Span", ptr %l7
  %t214 = load ptr, ptr %l132, !tbaa !29
  %t215 = load { i64, [4 x i64] }, ptr %l136
  %t216 = load ptr, ptr %l138, !tbaa !29
  %t217 = load i32, ptr %l140, !tbaa !23
  %t219 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2efit(ptr %v0, ptr %v1, ptr %t214, { i64, [4 x i64] } %t215, ptr %t216, i32 %t217, %"compiler/source:Span" %t213)
  store { i64, [4 x i64] } %t219, ptr %l142
  br label %bb38
bb38:
  %t220 = load { i64, [4 x i64] }, ptr %l142
  store { i64, [4 x i64] } %t220, ptr %l11
  %t221 = load ptr, ptr %l0, !tbaa !29
  %t223 = getelementptr %"compiler/lower:lowering", ptr %t221, i32 0, i32 15
  %t225 = call { i32, %"compiler/lower:pl" } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3apl_3e_2ePop_3ccompiler_2flower_3apl_3e(ptr %v0, ptr %v0, ptr %t223)
  %t226 = extractvalue { i32, %"compiler/lower:pl" } %t225, 1
  %t227 = extractvalue { i32, %"compiler/lower:pl" } %t225, 0
  store i32 %t227, ptr %l147
  %t228 = icmp ne i32 %t227, 0
  br i1 %t228, label %bb40, label %ok.229
ok.229:
  store %"compiler/lower:pl" %t226, ptr %l146
  br label %bb39
bb39:
  %t230 = load %"compiler/lower:pl", ptr %l146
  store %"compiler/lower:pl" %t230, ptr %l143
  br label %bb42
bb40:
  br label %bb41
bb41:
  br label %bb42
bb42:
  %t231 = load ptr, ptr %l0, !tbaa !29
  store ptr %t231, ptr %l148, !tbaa !29
  %t232 = load ptr, ptr %l8, !tbaa !29
  %t234 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aPlace_2eType(ptr %v1, ptr %t232)
  store i32 %t234, ptr %l150
  br label %bb43
bb43:
  %t235 = load ptr, ptr %l148, !tbaa !29
  %t236 = load i32, ptr %l150, !tbaa !23
  %t237 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2evalueArray(ptr %v0, ptr %t235, i32 %t236)
  store i1 %t237, ptr %l151
  br label %bb44
bb44:
  %t238 = load i1, ptr %l151, !tbaa !21
  br i1 %t238, label %bb45, label %bb46
bb45:
  %t239 = load ptr, ptr %l0, !tbaa !29
  %t241 = getelementptr %"compiler/lower:lowering", ptr %t239, i32 0, i32 7
  %t242 = load i1, ptr %t241, !tbaa !21
  %t244 = xor i1 %t242, true
  store i1 %t244, ptr %l152, !tbaa !21
  br label %bb47
bb46:
  store i1 false, ptr %l152, !tbaa !21
  br label %bb47
bb47:
  %t246 = load i1, ptr %l152, !tbaa !21
  br i1 %t246, label %bb48, label %bb49
bb48:
  %t247 = load ptr, ptr %l0, !tbaa !29
  store ptr %t247, ptr %l156, !tbaa !29
  %t248 = load ptr, ptr %l9, !tbaa !29
  store ptr %t248, ptr %l157, !tbaa !29
  %t249 = load ptr, ptr %l8, !tbaa !29
  %t251 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aPlace_2eType(ptr %v1, ptr %t249)
  store i32 %t251, ptr %l159
  br label %bb50
bb49:
  store %olang.scope zeroinitializer, ptr %s8
  %t252 = load ptr, ptr %l0, !tbaa !29
  store ptr %t252, ptr %l173, !tbaa !29
  %t253 = load %"compiler/source:Span", ptr %l7
  store %"compiler/source:Span" %t253, ptr %l174
  %t254 = load ptr, ptr %l0, !tbaa !29
  %t255 = load %"compiler/lower:pl", ptr %l10
  %t258 = call %"compiler/mir:Place" @compiler_2flower_2ecompiler_2flower_3alowering_2emk(ptr %v0, ptr %v0, ptr %t254, %"compiler/lower:pl" %t255)
  store %"compiler/mir:Place" %t258, ptr %l177
  br label %bb56
bb50:
  %t259 = load ptr, ptr %l156, !tbaa !29
  %t260 = load ptr, ptr %l157, !tbaa !29
  %t261 = load i32, ptr %l159, !tbaa !23
  %t262 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2ecopiesArray(ptr %v0, ptr %v1, ptr %t259, ptr %t260, i32 %t261)
  store i1 %t262, ptr %l160
  br label %bb51
bb51:
  %t263 = load i1, ptr %l160, !tbaa !21
  store i1 %t263, ptr %l12, !tbaa !21
  %t264 = load ptr, ptr %l0, !tbaa !29
  store ptr %t264, ptr %l161, !tbaa !29
  %t265 = load ptr, ptr %l0, !tbaa !29
  %t266 = load %"compiler/lower:pl", ptr %l10
  %t269 = call %"compiler/mir:Place" @compiler_2flower_2ecompiler_2flower_3alowering_2emk(ptr %v0, ptr %v0, ptr %t265, %"compiler/lower:pl" %t266)
  store %"compiler/mir:Place" %t269, ptr %l164
  br label %bb52
bb52:
  %t270 = load { i64, [4 x i64] }, ptr %l11
  store { i64, [4 x i64] } %t270, ptr %l165
  %t271 = load ptr, ptr %l8, !tbaa !29
  %t273 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aPlace_2eType(ptr %v1, ptr %t271)
  store i32 %t273, ptr %l167
  br label %bb53
bb53:
  %t274 = load i1, ptr %l12, !tbaa !21
  store i1 %t274, ptr %l168, !tbaa !21
  %t275 = load %"compiler/source:Span", ptr %l7
  store %"compiler/source:Span" %t275, ptr %l169
  %t276 = load ptr, ptr %l0, !tbaa !29
  %t277 = load ptr, ptr %l8, !tbaa !29
  %t280 = call { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eplaceStorage(ptr %v0, ptr %v1, ptr %t276, ptr %t277)
  store { i64, [1 x i64] } %t280, ptr %l172
  br label %bb54
bb54:
  %t281 = load ptr, ptr %l161, !tbaa !29
  %t282 = load %"compiler/mir:Place", ptr %l164
  %t283 = load { i64, [4 x i64] }, ptr %l165
  %t284 = load i32, ptr %l167, !tbaa !23
  %t285 = load i1, ptr %l168, !tbaa !21
  %t286 = load %"compiler/source:Span", ptr %l169
  %t287 = load { i64, [1 x i64] }, ptr %l172
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2earrayStore(ptr %v0, ptr %t281, %"compiler/mir:Place" %t282, { i64, [4 x i64] } %t283, i32 %t284, i1 %t285, %"compiler/source:Span" %t286, { i64, [1 x i64] } %t287)
  br label %bb55
bb55:
  br label %bb58
bb56:
  %t288 = load { i64, [4 x i64] }, ptr %l11
  store { i64, [15 x i64] } zeroinitializer, ptr %t289
  %t290 = getelementptr { i64, [15 x i64] }, ptr %t289, i32 0, i32 0
  store i64 0, ptr %t290
  %t292 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t288, 0
  %t293 = getelementptr { i64, [15 x i64] }, ptr %t289, i32 0, i32 1
  store { { i64, [4 x i64] } } %t292, ptr %t293
  %t294 = load { i64, [15 x i64] }, ptr %t289
  store { i64, [21 x i64] } zeroinitializer, ptr %t295
  %t296 = getelementptr { i64, [21 x i64] }, ptr %t295, i32 0, i32 0
  store i64 0, ptr %t296
  %t297 = load %"compiler/source:Span", ptr %l174
  %t298 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t297, 0
  %t299 = load %"compiler/mir:Place", ptr %l177
  %t300 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t298, %"compiler/mir:Place" %t299, 1
  %t302 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t300, { i64, [15 x i64] } %t294, 2
  %t303 = getelementptr { i64, [21 x i64] }, ptr %t295, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t302, ptr %t303
  %t304 = load { i64, [21 x i64] }, ptr %t295
  %t306 = call ptr @__olang_scope_alloc_a(ptr %s8, i64 176, i64 8)
  store { i64, [21 x i64] } %t304, ptr %t306
  %t307 = load ptr, ptr %l173, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s8, ptr %t307, ptr %t306)
  br label %bb57
bb57:
  call void @__olang_scope_close(ptr %s8)
  br label %bb58
bb58:
  br label %bb170
bb59:
  %t309 = load ptr, ptr %l1, !tbaa !29
  store ptr %t309, ptr %l182, !tbaa !29
  store i1 false, ptr %l183, !tbaa !21
  %t310 = load ptr, ptr %l182, !tbaa !29
  %t311 = icmp ne ptr %t310, null
  br i1 %t311, label %bb60, label %bb61
bb60:
  %t313 = load ptr, ptr %l182, !tbaa !29
  %t314 = load i64, ptr %t313
  %t316 = icmp eq i64 %t314, 2
  store i1 %t316, ptr %l183, !tbaa !21
  br label %bb61
bb61:
  %t317 = load i1, ptr %l183, !tbaa !21
  br i1 %t317, label %bb62, label %bb63
bb62:
  %t318 = load ptr, ptr %l1, !tbaa !29
  %t320 = getelementptr { i64, [3 x i64] }, ptr %t318, i32 0, i32 1
  %t321 = getelementptr { %"compiler/source:Span", ptr }, ptr %t320, i32 0, i32 1
  %t322 = load ptr, ptr %t321
  store ptr %t322, ptr %l13, !tbaa !29
  br label %bb64
bb63:
  br label %bb66
bb64:
  %t324 = load ptr, ptr %l0, !tbaa !29
  %t325 = load ptr, ptr %l13, !tbaa !29
  %t329 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v1, ptr %t324, ptr %t325)
  store { i64, [4 x i64] } %t329, ptr %l191
  br label %bb65
bb65:
  br label %bb170
bb66:
  %t330 = load ptr, ptr %l1, !tbaa !29
  store ptr %t330, ptr %l192, !tbaa !29
  store i1 false, ptr %l193, !tbaa !21
  %t331 = load ptr, ptr %l192, !tbaa !29
  %t332 = icmp ne ptr %t331, null
  br i1 %t332, label %bb67, label %bb68
bb67:
  %t334 = load ptr, ptr %l192, !tbaa !29
  %t335 = load i64, ptr %t334
  %t337 = icmp eq i64 %t335, 3
  store i1 %t337, ptr %l193, !tbaa !21
  br label %bb68
bb68:
  %t338 = load i1, ptr %l193, !tbaa !21
  br i1 %t338, label %bb69, label %bb70
bb69:
  %t339 = load ptr, ptr %l1, !tbaa !29
  %t341 = getelementptr { i64, [3 x i64] }, ptr %t339, i32 0, i32 1
  %t342 = getelementptr { %"compiler/source:Span", ptr }, ptr %t341, i32 0, i32 0
  %t343 = load %"compiler/source:Span", ptr %t342
  store %"compiler/source:Span" %t343, ptr %l14
  %t345 = load ptr, ptr %l1, !tbaa !29
  %t347 = getelementptr { i64, [3 x i64] }, ptr %t345, i32 0, i32 1
  %t348 = getelementptr { %"compiler/source:Span", ptr }, ptr %t347, i32 0, i32 1
  %t349 = load ptr, ptr %t348
  store ptr %t349, ptr %l15, !tbaa !29
  br label %bb71
bb70:
  br label %bb73
bb71:
  %t351 = load ptr, ptr %l0, !tbaa !29
  %t352 = load %"compiler/source:Span", ptr %l14
  %t353 = load ptr, ptr %l15, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eifStmt(ptr %v0, ptr %v1, ptr %t351, %"compiler/source:Span" %t352, ptr %t353)
  br label %bb72
bb72:
  br label %bb170
bb73:
  %t357 = load ptr, ptr %l1, !tbaa !29
  store ptr %t357, ptr %l203, !tbaa !29
  store i1 false, ptr %l204, !tbaa !21
  %t358 = load ptr, ptr %l203, !tbaa !29
  %t359 = icmp ne ptr %t358, null
  br i1 %t359, label %bb74, label %bb75
bb74:
  %t361 = load ptr, ptr %l203, !tbaa !29
  %t362 = load i64, ptr %t361
  %t364 = icmp eq i64 %t362, 4
  store i1 %t364, ptr %l204, !tbaa !21
  br label %bb75
bb75:
  %t365 = load i1, ptr %l204, !tbaa !21
  br i1 %t365, label %bb76, label %bb77
bb76:
  %t366 = load ptr, ptr %l1, !tbaa !29
  %t368 = getelementptr { i64, [3 x i64] }, ptr %t366, i32 0, i32 1
  %t369 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t368, i32 0, i32 0
  %t370 = load %"compiler/source:Span", ptr %t369
  store %"compiler/source:Span" %t370, ptr %l16
  %t372 = load ptr, ptr %l1, !tbaa !29
  %t374 = getelementptr { i64, [3 x i64] }, ptr %t372, i32 0, i32 1
  %t375 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t374, i32 0, i32 1
  %t376 = load ptr, ptr %t375
  store ptr %t376, ptr %l17, !tbaa !29
  %t378 = load ptr, ptr %l1, !tbaa !29
  %t380 = getelementptr { i64, [3 x i64] }, ptr %t378, i32 0, i32 1
  %t381 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t380, i32 0, i32 2
  %t382 = load ptr, ptr %t381
  store ptr %t382, ptr %l18, !tbaa !29
  br label %bb78
bb77:
  br label %bb80
bb78:
  %t384 = load ptr, ptr %l0, !tbaa !29
  %t385 = load %"compiler/source:Span", ptr %l16
  %t386 = load ptr, ptr %l17, !tbaa !29
  %t387 = load ptr, ptr %l18, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eloop(ptr %v0, ptr %v1, ptr %v1, ptr %t384, %"compiler/source:Span" %t385, ptr %t386, ptr %t387)
  br label %bb79
bb79:
  br label %bb170
bb80:
  %t392 = load ptr, ptr %l1, !tbaa !29
  store ptr %t392, ptr %l217, !tbaa !29
  store i1 false, ptr %l218, !tbaa !21
  %t393 = load ptr, ptr %l217, !tbaa !29
  %t394 = icmp ne ptr %t393, null
  br i1 %t394, label %bb81, label %bb82
bb81:
  %t396 = load ptr, ptr %l217, !tbaa !29
  %t397 = load i64, ptr %t396
  %t399 = icmp eq i64 %t397, 5
  store i1 %t399, ptr %l218, !tbaa !21
  br label %bb82
bb82:
  %t400 = load i1, ptr %l218, !tbaa !21
  br i1 %t400, label %bb83, label %bb84
bb83:
  %t401 = load ptr, ptr %l1, !tbaa !29
  %t403 = getelementptr { i64, [3 x i64] }, ptr %t401, i32 0, i32 1
  %t404 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t403, i32 0, i32 0
  %t405 = load %"compiler/source:Span", ptr %t404
  store %"compiler/source:Span" %t405, ptr %l19
  %t407 = load ptr, ptr %l1, !tbaa !29
  %t409 = getelementptr { i64, [3 x i64] }, ptr %t407, i32 0, i32 1
  %t410 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t409, i32 0, i32 1
  %t411 = load i32, ptr %t410
  store i32 %t411, ptr %l20
  %t413 = load ptr, ptr %l1, !tbaa !29
  %t415 = getelementptr { i64, [3 x i64] }, ptr %t413, i32 0, i32 1
  %t416 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t415, i32 0, i32 2
  %t417 = load i32, ptr %t416
  store i32 %t417, ptr %l21, !tbaa !23
  br label %bb85
bb84:
  br label %bb87
bb85:
  %t419 = load ptr, ptr %l0, !tbaa !29
  %t420 = load %"compiler/source:Span", ptr %l19
  %t421 = load i32, ptr %l20
  %t422 = load i32, ptr %l21, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2ejump(ptr %v0, ptr %t419, %"compiler/source:Span" %t420, i32 %t421, i32 %t422)
  br label %bb86
bb86:
  br label %bb170
bb87:
  %t427 = load ptr, ptr %l1, !tbaa !29
  store ptr %t427, ptr %l231, !tbaa !29
  store i1 false, ptr %l232, !tbaa !21
  %t428 = load ptr, ptr %l231, !tbaa !29
  %t429 = icmp ne ptr %t428, null
  br i1 %t429, label %bb88, label %bb89
bb88:
  %t431 = load ptr, ptr %l231, !tbaa !29
  %t432 = load i64, ptr %t431
  %t434 = icmp eq i64 %t432, 6
  store i1 %t434, ptr %l232, !tbaa !21
  br label %bb89
bb89:
  %t435 = load i1, ptr %l232, !tbaa !21
  br i1 %t435, label %bb90, label %bb91
bb90:
  %t436 = load ptr, ptr %l1, !tbaa !29
  %t438 = getelementptr { i64, [3 x i64] }, ptr %t436, i32 0, i32 1
  %t439 = getelementptr { %"compiler/source:Span", ptr }, ptr %t438, i32 0, i32 0
  %t440 = load %"compiler/source:Span", ptr %t439
  store %"compiler/source:Span" %t440, ptr %l22
  %t442 = load ptr, ptr %l1, !tbaa !29
  %t444 = getelementptr { i64, [3 x i64] }, ptr %t442, i32 0, i32 1
  %t445 = getelementptr { %"compiler/source:Span", ptr }, ptr %t444, i32 0, i32 1
  %t446 = load ptr, ptr %t445
  store ptr %t446, ptr %l23, !tbaa !29
  br label %bb92
bb91:
  br label %bb94
bb92:
  %t448 = load ptr, ptr %l0, !tbaa !29
  %t449 = load %"compiler/source:Span", ptr %l22
  %t450 = load ptr, ptr %l23, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eret(ptr %v0, ptr %v1, ptr %t448, %"compiler/source:Span" %t449, ptr %t450)
  br label %bb93
bb93:
  br label %bb170
bb94:
  %t454 = load ptr, ptr %l1, !tbaa !29
  store ptr %t454, ptr %l242, !tbaa !29
  store i1 false, ptr %l243, !tbaa !21
  %t455 = load ptr, ptr %l242, !tbaa !29
  %t456 = icmp ne ptr %t455, null
  br i1 %t456, label %bb95, label %bb96
bb95:
  %t458 = load ptr, ptr %l242, !tbaa !29
  %t459 = load i64, ptr %t458
  %t461 = icmp eq i64 %t459, 7
  store i1 %t461, ptr %l243, !tbaa !21
  br label %bb96
bb96:
  %t462 = load i1, ptr %l243, !tbaa !21
  br i1 %t462, label %bb97, label %bb98
bb97:
  %t463 = load ptr, ptr %l1, !tbaa !29
  %t465 = getelementptr { i64, [3 x i64] }, ptr %t463, i32 0, i32 1
  %t466 = getelementptr { %"compiler/source:Span", i32, i64 }, ptr %t465, i32 0, i32 0
  %t467 = load %"compiler/source:Span", ptr %t466
  store %"compiler/source:Span" %t467, ptr %l24
  %t469 = load ptr, ptr %l1, !tbaa !29
  %t471 = getelementptr { i64, [3 x i64] }, ptr %t469, i32 0, i32 1
  %t472 = getelementptr { %"compiler/source:Span", i32, i64 }, ptr %t471, i32 0, i32 1
  %t473 = load i32, ptr %t472
  store i32 %t473, ptr %l25, !tbaa !23
  %t475 = load ptr, ptr %l1, !tbaa !29
  %t477 = getelementptr { i64, [3 x i64] }, ptr %t475, i32 0, i32 1
  %t478 = getelementptr { %"compiler/source:Span", i32, i64 }, ptr %t477, i32 0, i32 2
  %t479 = load i64, ptr %t478
  store i64 %t479, ptr %l26, !tbaa !24
  br label %bb99
bb98:
  br label %bb103
bb99:
  %t481 = load ptr, ptr %l0, !tbaa !29
  %t483 = getelementptr %"compiler/lower:lowering", ptr %t481, i32 0, i32 2
  %t484 = load ptr, ptr %t483, !tbaa !29
  store ptr %t484, ptr %l253, !tbaa !29
  %t485 = load ptr, ptr %l0, !tbaa !29
  %t487 = getelementptr %"compiler/lower:lowering", ptr %t485, i32 0, i32 2
  %t488 = load ptr, ptr %t487, !tbaa !29
  %t489 = load ptr, ptr %l0, !tbaa !29
  %t491 = getelementptr %"compiler/lower:lowering", ptr %t489, i32 0, i32 1
  %t492 = load ptr, ptr %t491, !tbaa !29
  %t494 = getelementptr %"compiler/typed:Body", ptr %t492, i32 0, i32 2
  %t495 = load i32, ptr %t494, !tbaa !23
  %t498 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t488, i32 %t495)
  store i32 %t498, ptr %l259
  br label %bb100
bb100:
  %t499 = load i32, ptr %l25, !tbaa !23
  %t500 = load i64, ptr %l26, !tbaa !24
  %t501 = load ptr, ptr %l253, !tbaa !29
  %t502 = load i32, ptr %l259, !tbaa !23
  %t505 = call i64 @compiler_2fmir_2eErrorCode(ptr %v0, ptr %t501, i32 %t502, i32 %t499, i64 %t500)
  store i64 %t505, ptr %l262
  br label %bb101
bb101:
  %t506 = load i64, ptr %l262, !tbaa !24
  %t507 = load ptr, ptr %l0, !tbaa !29
  %t508 = load %"compiler/source:Span", ptr %l24
  %t509 = load i32, ptr @G_2ecompiler_2fmir_2eI32T, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t511
  %t512 = getelementptr { i64, [4 x i64] }, ptr %t511, i32 0, i32 0
  store i64 2, ptr %t512
  %t514 = insertvalue { i32, i64 } undef, i32 %t509, 0
  %t516 = insertvalue { i32, i64 } %t514, i64 %t506, 1
  %t517 = getelementptr { i64, [4 x i64] }, ptr %t511, i32 0, i32 1
  store { i32, i64 } %t516, ptr %t517
  %t518 = load { i64, [4 x i64] }, ptr %t511
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eraise(ptr %v0, ptr %t507, %"compiler/source:Span" %t508, { i64, [4 x i64] } %t518)
  br label %bb102
bb102:
  br label %bb170
bb103:
  %t522 = load ptr, ptr %l1, !tbaa !29
  store ptr %t522, ptr %l268, !tbaa !29
  store i1 false, ptr %l269, !tbaa !21
  %t523 = load ptr, ptr %l268, !tbaa !29
  %t524 = icmp ne ptr %t523, null
  br i1 %t524, label %bb104, label %bb105
bb104:
  %t526 = load ptr, ptr %l268, !tbaa !29
  %t527 = load i64, ptr %t526
  %t529 = icmp eq i64 %t527, 8
  store i1 %t529, ptr %l269, !tbaa !21
  br label %bb105
bb105:
  %t530 = load i1, ptr %l269, !tbaa !21
  br i1 %t530, label %bb106, label %bb107
bb106:
  %t531 = load ptr, ptr %l1, !tbaa !29
  %t533 = getelementptr { i64, [3 x i64] }, ptr %t531, i32 0, i32 1
  %t534 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t533, i32 0, i32 0
  %t535 = load %"compiler/source:Span", ptr %t534
  store %"compiler/source:Span" %t535, ptr %l28
  %t537 = load ptr, ptr %l1, !tbaa !29
  %t539 = getelementptr { i64, [3 x i64] }, ptr %t537, i32 0, i32 1
  %t540 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t539, i32 0, i32 1
  %t541 = load i32, ptr %t540
  store i32 %t541, ptr %l29
  %t543 = load ptr, ptr %l1, !tbaa !29
  %t545 = getelementptr { i64, [3 x i64] }, ptr %t543, i32 0, i32 1
  %t546 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t545, i32 0, i32 2
  %t547 = load ptr, ptr %t546
  store ptr %t547, ptr %l30, !tbaa !29
  br label %bb108
bb107:
  br label %bb120
bb108:
  store { i64, [4 x i64] } zeroinitializer, ptr %t549
  %t550 = getelementptr { i64, [4 x i64] }, ptr %t549, i32 0, i32 0
  store i64 0, ptr %t550
  %t551 = load { i64, [4 x i64] }, ptr %t549
  store { i64, [4 x i64] } %t551, ptr %l31
  %t553 = load ptr, ptr %l30, !tbaa !29
  %t555 = icmp eq ptr %t553, null
  %t557 = xor i1 %t555, true
  br i1 %t557, label %bb109, label %bb110
bb109:
  %t559 = load ptr, ptr %l0, !tbaa !29
  %t560 = load ptr, ptr %l30, !tbaa !29
  %t564 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v1, ptr %t559, ptr %t560)
  store { i64, [4 x i64] } %t564, ptr %l285
  br label %bb111
bb110:
  br label %bb112
bb111:
  %t565 = load { i64, [4 x i64] }, ptr %l285
  store { i64, [4 x i64] } %t565, ptr %l31
  br label %bb112
bb112:
  %t566 = load i32, ptr %l29
  %t568 = trunc i64 1 to i32
  %t569 = icmp eq i32 %t566, %t568
  br i1 %t569, label %bb113, label %bb114
bb113:
  store i32 4, ptr %l288
  br label %bb115
bb114:
  store i32 3, ptr %l288
  br label %bb115
bb115:
  %t573 = load i32, ptr %l288
  store i32 %t573, ptr %l32
  %t574 = load ptr, ptr %l0, !tbaa !29
  %t576 = getelementptr %"compiler/lower:lowering", ptr %t574, i32 0, i32 7
  %t577 = load i1, ptr %t576, !tbaa !21
  %t579 = xor i1 %t577, true
  br i1 %t579, label %bb116, label %bb117
bb116:
  %t581 = load ptr, ptr %l0, !tbaa !29
  %t582 = load %"compiler/source:Span", ptr %l28
  %t583 = load i32, ptr %l32
  %t584 = load { i64, [4 x i64] }, ptr %l31
  store { i64, [7 x i64] } zeroinitializer, ptr %t585
  %t586 = getelementptr { i64, [7 x i64] }, ptr %t585, i32 0, i32 0
  store i64 8, ptr %t586
  %t588 = insertvalue { %"compiler/source:Span", i32, { i64, [4 x i64] } } undef, %"compiler/source:Span" %t582, 0
  %t590 = insertvalue { %"compiler/source:Span", i32, { i64, [4 x i64] } } %t588, i32 %t583, 1
  %t592 = insertvalue { %"compiler/source:Span", i32, { i64, [4 x i64] } } %t590, { i64, [4 x i64] } %t584, 2
  %t593 = getelementptr { i64, [7 x i64] }, ptr %t585, i32 0, i32 1
  store { %"compiler/source:Span", i32, { i64, [4 x i64] } } %t592, ptr %t593
  %t594 = load { i64, [7 x i64] }, ptr %t585
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t581, { i64, [7 x i64] } %t594)
  br label %bb118
bb117:
  br label %bb119
bb118:
  br label %bb119
bb119:
  br label %bb170
bb120:
  %t597 = load ptr, ptr %l1, !tbaa !29
  store ptr %t597, ptr %l299, !tbaa !29
  store i1 false, ptr %l300, !tbaa !21
  %t598 = load ptr, ptr %l299, !tbaa !29
  %t599 = icmp ne ptr %t598, null
  br i1 %t599, label %bb121, label %bb122
bb121:
  %t601 = load ptr, ptr %l299, !tbaa !29
  %t602 = load i64, ptr %t601
  %t604 = icmp eq i64 %t602, 9
  store i1 %t604, ptr %l300, !tbaa !21
  br label %bb122
bb122:
  %t605 = load i1, ptr %l300, !tbaa !21
  br i1 %t605, label %bb123, label %bb124
bb123:
  %t606 = load ptr, ptr %l1, !tbaa !29
  %t608 = getelementptr { i64, [3 x i64] }, ptr %t606, i32 0, i32 1
  %t609 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t608, i32 0, i32 0
  %t610 = load %"compiler/source:Span", ptr %t609
  store %"compiler/source:Span" %t610, ptr %l33
  %t612 = load ptr, ptr %l1, !tbaa !29
  %t614 = getelementptr { i64, [3 x i64] }, ptr %t612, i32 0, i32 1
  %t615 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t614, i32 0, i32 1
  %t616 = load ptr, ptr %t615
  store ptr %t616, ptr %l34, !tbaa !29
  %t618 = load ptr, ptr %l1, !tbaa !29
  %t620 = getelementptr { i64, [3 x i64] }, ptr %t618, i32 0, i32 1
  %t621 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t620, i32 0, i32 2
  %t622 = load ptr, ptr %t621
  store ptr %t622, ptr %l35, !tbaa !29
  br label %bb125
bb124:
  br label %bb127
bb125:
  %t624 = load ptr, ptr %l0, !tbaa !29
  %t625 = load %"compiler/source:Span", ptr %l33
  %t626 = load ptr, ptr %l34, !tbaa !29
  %t627 = load ptr, ptr %l35, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eassert(ptr %v0, ptr %v1, ptr %v1, ptr %t624, %"compiler/source:Span" %t625, ptr %t626, ptr %t627)
  br label %bb126
bb126:
  br label %bb170
bb127:
  %t632 = load ptr, ptr %l1, !tbaa !29
  store ptr %t632, ptr %l313, !tbaa !29
  store i1 false, ptr %l314, !tbaa !21
  %t633 = load ptr, ptr %l313, !tbaa !29
  %t634 = icmp ne ptr %t633, null
  br i1 %t634, label %bb128, label %bb129
bb128:
  %t636 = load ptr, ptr %l313, !tbaa !29
  %t637 = load i64, ptr %t636
  %t639 = icmp eq i64 %t637, 10
  store i1 %t639, ptr %l314, !tbaa !21
  br label %bb129
bb129:
  %t640 = load i1, ptr %l314, !tbaa !21
  br i1 %t640, label %bb130, label %bb131
bb130:
  %t641 = load ptr, ptr %l1, !tbaa !29
  %t643 = getelementptr { i64, [3 x i64] }, ptr %t641, i32 0, i32 1
  %t644 = getelementptr { %"compiler/source:Span", ptr }, ptr %t643, i32 0, i32 1
  %t645 = load ptr, ptr %t644
  store ptr %t645, ptr %l36, !tbaa !29
  br label %bb132
bb131:
  br label %bb134
bb132:
  %t647 = load ptr, ptr %l0, !tbaa !29
  %t648 = load ptr, ptr %l36, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eblock(ptr %v0, ptr %v1, ptr %t647, ptr %t648)
  br label %bb133
bb133:
  br label %bb170
bb134:
  %t651 = load ptr, ptr %l1, !tbaa !29
  store ptr %t651, ptr %l321, !tbaa !29
  store i1 false, ptr %l322, !tbaa !21
  %t652 = load ptr, ptr %l321, !tbaa !29
  %t653 = icmp ne ptr %t652, null
  br i1 %t653, label %bb135, label %bb136
bb135:
  %t655 = load ptr, ptr %l321, !tbaa !29
  %t656 = load i64, ptr %t655
  %t658 = icmp eq i64 %t656, 11
  store i1 %t658, ptr %l322, !tbaa !21
  br label %bb136
bb136:
  %t659 = load i1, ptr %l322, !tbaa !21
  br i1 %t659, label %bb137, label %bb138
bb137:
  %t660 = load ptr, ptr %l1, !tbaa !29
  %t662 = getelementptr { i64, [3 x i64] }, ptr %t660, i32 0, i32 1
  %t663 = getelementptr { %"compiler/source:Span", ptr }, ptr %t662, i32 0, i32 0
  %t664 = load %"compiler/source:Span", ptr %t663
  store %"compiler/source:Span" %t664, ptr %l37
  %t666 = load ptr, ptr %l1, !tbaa !29
  %t668 = getelementptr { i64, [3 x i64] }, ptr %t666, i32 0, i32 1
  %t669 = getelementptr { %"compiler/source:Span", ptr }, ptr %t668, i32 0, i32 1
  %t670 = load ptr, ptr %t669
  store ptr %t670, ptr %l38, !tbaa !29
  br label %bb139
bb138:
  br label %bb148
bb139:
  %t672 = load ptr, ptr %l0, !tbaa !29
  %t674 = getelementptr %"compiler/lower:lowering", ptr %t672, i32 0, i32 10
  %t675 = load ptr, ptr %l38, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aBlock_26_3e_2ePu_H0a6921d1f6104d156ffed3729e33edeb(ptr %v0, ptr %v1, ptr %t674, ptr %t675)
  br label %bb140
bb140:
  %t678 = load ptr, ptr %l0, !tbaa !29
  %t680 = getelementptr %"compiler/lower:lowering", ptr %t678, i32 0, i32 11
  store ptr %t680, ptr %l333, !tbaa !29
  %t681 = load ptr, ptr %l0, !tbaa !29
  %t683 = call %"compiler/lower:level" @compiler_2flower_2ecompiler_2flower_3alowering_2etop(ptr %v0, ptr %t681)
  store %"compiler/lower:level" %t683, ptr %l335
  br label %bb141
bb141:
  %t684 = getelementptr %"compiler/lower:level", ptr %l335, i32 0, i32 0
  %t685 = load i32, ptr %t684, !tbaa !23
  %t686 = load ptr, ptr %l333, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeId_3e_2ePush_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t686, i32 %t685)
  br label %bb142
bb142:
  %t688 = load ptr, ptr %l0, !tbaa !29
  %t690 = getelementptr %"compiler/lower:lowering", ptr %t688, i32 0, i32 0
  %t691 = load ptr, ptr %t690, !tbaa !29
  %t693 = getelementptr %"compiler/lower:Lowerer", ptr %t691, i32 0, i32 5
  %t694 = load i1, ptr %t693, !tbaa !21
  br i1 %t694, label %bb143, label %bb144
bb143:
  %t696 = load ptr, ptr %l0, !tbaa !29
  store ptr %t696, ptr %l340, !tbaa !29
  %t697 = load %"compiler/source:Span", ptr %l37
  store %"compiler/source:Span" %t697, ptr %l341
  %t698 = load ptr, ptr %l0, !tbaa !29
  %t700 = getelementptr %"compiler/lower:lowering", ptr %t698, i32 0, i32 10
  %t702 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aBlock_26_3e_2eLe_H8743fc75fe5cead0bda2da42e1adf3f3(ptr %v0, ptr %t700)
  store i64 %t702, ptr %l344
  br label %bb145
bb144:
  br label %bb147
bb145:
  %t703 = load i64, ptr %l344, !tbaa !24
  %t704 = sub i64 %t703, 1
  %t705 = load ptr, ptr %l340, !tbaa !29
  %t706 = load %"compiler/source:Span", ptr %l341
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2ecleanup(ptr %v0, ptr %t705, %"compiler/source:Span" %t706, i64 %t704)
  br label %bb146
bb146:
  br label %bb147
bb147:
  br label %bb170
bb148:
  %t708 = load ptr, ptr %l1, !tbaa !29
  store ptr %t708, ptr %l346, !tbaa !29
  store i1 false, ptr %l347, !tbaa !21
  %t709 = load ptr, ptr %l346, !tbaa !29
  %t710 = icmp ne ptr %t709, null
  br i1 %t710, label %bb149, label %bb150
bb149:
  %t712 = load ptr, ptr %l346, !tbaa !29
  %t713 = load i64, ptr %t712
  %t715 = icmp eq i64 %t713, 12
  store i1 %t715, ptr %l347, !tbaa !21
  br label %bb150
bb150:
  %t716 = load i1, ptr %l347, !tbaa !21
  br i1 %t716, label %bb151, label %bb152
bb151:
  %t717 = load ptr, ptr %l1, !tbaa !29
  %t719 = getelementptr { i64, [3 x i64] }, ptr %t717, i32 0, i32 1
  %t720 = getelementptr { %"compiler/source:Span", ptr }, ptr %t719, i32 0, i32 0
  %t721 = load %"compiler/source:Span", ptr %t720
  store %"compiler/source:Span" %t721, ptr %l39
  %t723 = load ptr, ptr %l1, !tbaa !29
  %t725 = getelementptr { i64, [3 x i64] }, ptr %t723, i32 0, i32 1
  %t726 = getelementptr { %"compiler/source:Span", ptr }, ptr %t725, i32 0, i32 1
  %t727 = load ptr, ptr %t726
  store ptr %t727, ptr %l40, !tbaa !29
  br label %bb153
bb152:
  br label %bb155
bb153:
  %t729 = load ptr, ptr %l0, !tbaa !29
  %t730 = load %"compiler/source:Span", ptr %l39
  %t731 = load ptr, ptr %l40, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2ejoin(ptr %v0, ptr %v1, ptr %t729, %"compiler/source:Span" %t730, ptr %t731)
  br label %bb154
bb154:
  br label %bb170
bb155:
  %t735 = load ptr, ptr %l1, !tbaa !29
  store ptr %t735, ptr %l357, !tbaa !29
  store i1 false, ptr %l358, !tbaa !21
  %t736 = load ptr, ptr %l357, !tbaa !29
  %t737 = icmp ne ptr %t736, null
  br i1 %t737, label %bb156, label %bb157
bb156:
  %t739 = load ptr, ptr %l357, !tbaa !29
  %t740 = load i64, ptr %t739
  %t742 = icmp eq i64 %t740, 13
  store i1 %t742, ptr %l358, !tbaa !21
  br label %bb157
bb157:
  %t743 = load i1, ptr %l358, !tbaa !21
  br i1 %t743, label %bb158, label %bb159
bb158:
  %t744 = load ptr, ptr %l1, !tbaa !29
  %t746 = getelementptr { i64, [3 x i64] }, ptr %t744, i32 0, i32 1
  %t747 = getelementptr { %"compiler/source:Span", ptr }, ptr %t746, i32 0, i32 0
  %t748 = load %"compiler/source:Span", ptr %t747
  store %"compiler/source:Span" %t748, ptr %l41
  %t750 = load ptr, ptr %l1, !tbaa !29
  %t752 = getelementptr { i64, [3 x i64] }, ptr %t750, i32 0, i32 1
  %t753 = getelementptr { %"compiler/source:Span", ptr }, ptr %t752, i32 0, i32 1
  %t754 = load ptr, ptr %t753
  store ptr %t754, ptr %l42, !tbaa !29
  br label %bb160
bb159:
  br label %bb162
bb160:
  %t756 = load ptr, ptr %l0, !tbaa !29
  %t757 = load %"compiler/source:Span", ptr %l41
  %t758 = load ptr, ptr %l42, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2espawn(ptr %v0, ptr %v1, ptr %t756, %"compiler/source:Span" %t757, ptr %t758)
  br label %bb161
bb161:
  br label %bb170
bb162:
  %t762 = load ptr, ptr %l1, !tbaa !29
  store ptr %t762, ptr %l368, !tbaa !29
  store i1 false, ptr %l369, !tbaa !21
  %t763 = load ptr, ptr %l368, !tbaa !29
  %t764 = icmp ne ptr %t763, null
  br i1 %t764, label %bb163, label %bb164
bb163:
  %t766 = load ptr, ptr %l368, !tbaa !29
  %t767 = load i64, ptr %t766
  %t769 = icmp eq i64 %t767, 14
  store i1 %t769, ptr %l369, !tbaa !21
  br label %bb164
bb164:
  %t770 = load i1, ptr %l369, !tbaa !21
  br i1 %t770, label %bb165, label %bb166
bb165:
  %t771 = load ptr, ptr %l1, !tbaa !29
  %t773 = getelementptr { i64, [3 x i64] }, ptr %t771, i32 0, i32 1
  %t774 = getelementptr { %"compiler/source:Span", ptr }, ptr %t773, i32 0, i32 0
  %t775 = load %"compiler/source:Span", ptr %t774
  store %"compiler/source:Span" %t775, ptr %l43
  %t777 = load ptr, ptr %l1, !tbaa !29
  %t779 = getelementptr { i64, [3 x i64] }, ptr %t777, i32 0, i32 1
  %t780 = getelementptr { %"compiler/source:Span", ptr }, ptr %t779, i32 0, i32 1
  %t781 = load ptr, ptr %t780
  store ptr %t781, ptr %l44, !tbaa !29
  br label %bb167
bb166:
  br label %bb169
bb167:
  %t783 = load ptr, ptr %l0, !tbaa !29
  %t784 = load %"compiler/source:Span", ptr %l43
  %t785 = load ptr, ptr %l44, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eyield(ptr %v0, ptr %v1, ptr %t783, %"compiler/source:Span" %t784, ptr %t785)
  br label %bb168
bb168:
  br label %bb170
bb169:
  call void @__olang_check_failed(ptr @olang_loc_b7b09248cda006f_e3ce57a596777ddb)
  unreachable
bb170:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2estmtSpawnErrors(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i32
  %l10 = alloca i1
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca ptr
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca %"compiler/typed:Item"
  %l19 = alloca i1
  %l20 = alloca ptr
  %l21 = alloca i64
  %l22 = alloca { i64, ptr }
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i32
  %l26 = alloca ptr
  %l27 = alloca ptr
  %l28 = alloca ptr
  %l29 = alloca ptr
  %l32 = alloca ptr
  %l33 = alloca i1
  %l41 = alloca i32
  %l45 = alloca ptr
  %l48 = alloca i32
  %l49 = alloca { i64, ptr }
  %l56 = alloca { i64, ptr }
  %l67 = alloca { i64, ptr }
  %l80 = alloca { i64, ptr }
  %l85 = alloca i1
  %l86 = alloca ptr
  %l89 = alloca i32
  %l92 = alloca i32
  %l93 = alloca i1
  %l100 = alloca { i64, ptr }
  %l103 = alloca { i64, ptr }
  %l104 = alloca i32
  %l113 = alloca { i64, ptr }
  %l117 = alloca i1
  %l118 = alloca ptr
  %l121 = alloca i32
  %l124 = alloca i32
  %l125 = alloca i1
  %l133 = alloca ptr
  %l136 = alloca i32
  %l139 = alloca ptr
  %l140 = alloca i1
  %l149 = alloca ptr
  %l150 = alloca i1
  %l164 = alloca ptr
  %l165 = alloca i1
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s16 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t6 = load ptr, ptr %l1, !tbaa !29
  store ptr %t6, ptr %l32, !tbaa !29
  store i1 false, ptr %l33, !tbaa !21
  %t7 = load ptr, ptr %l32, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l32, !tbaa !29
  %t11 = load i64, ptr %t10
  %t13 = icmp eq i64 %t11, 13
  store i1 %t13, ptr %l33, !tbaa !21
  br label %bb2
bb2:
  %t14 = load i1, ptr %l33, !tbaa !21
  br i1 %t14, label %bb3, label %bb4
bb3:
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t17 = getelementptr { i64, [3 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { %"compiler/source:Span", ptr }, ptr %t17, i32 0, i32 1
  %t19 = load ptr, ptr %t18
  store ptr %t19, ptr %l4, !tbaa !29
  br label %bb5
bb4:
  br label %bb71
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load ptr, ptr %l4, !tbaa !29
  %t24 = getelementptr %"compiler/typed:Spawn", ptr %t22, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t28 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2etaskType(ptr %v0, ptr %v1, ptr %t21, ptr %t25)
  store i32 %t28, ptr %l41
  br label %bb6
bb6:
  %t29 = load i32, ptr %l41, !tbaa !23
  store i32 %t29, ptr %l5, !tbaa !23
  %t30 = load i32, ptr %l5, !tbaa !23
  %t31 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t34 = icmp eq i32 %t30, %t31
  br i1 %t34, label %bb7, label %bb8
bb7:
  br label %ret
bb8:
  br label %bb9
bb9:
  %t36 = load ptr, ptr %l3, !tbaa !29
  store ptr %t36, ptr %l45, !tbaa !29
  %t37 = load ptr, ptr %l3, !tbaa !29
  %t38 = load i32, ptr %l5, !tbaa !23
  %t41 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t37, i32 %t38)
  store i32 %t41, ptr %l48
  br label %bb10
bb10:
  %t42 = load ptr, ptr %l45, !tbaa !29
  %t43 = load i32, ptr %l48, !tbaa !23
  %t44 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t42, i32 %t43)
  store { i64, ptr } %t44, ptr %l49
  br label %bb11
bb11:
  %t45 = load { i64, ptr }, ptr %l49, !tbaa !27
  store { i64, ptr } %t45, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t46 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t48 = extractvalue { i64, ptr } %t46, 0
  store i64 %t48, ptr %l8, !tbaa !24
  br label %bb12
bb12:
  store %olang.scope zeroinitializer, ptr %s4
  %t50 = load i64, ptr %l7, !tbaa !24
  %t51 = load i64, ptr %l8, !tbaa !24
  %t54 = icmp slt i64 %t50, %t51
  %t56 = xor i1 %t54, true
  br i1 %t56, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s4)
  br label %bb70
bb14:
  br label %bb15
bb15:
  %t58 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t58, ptr %l56, !tbaa !27
  %t59 = load i64, ptr %l7, !tbaa !24
  %t61 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !27
  %t63 = getelementptr i32, ptr %t62, i64 %t59
  %t64 = load i32, ptr %t63, !tbaa !33
  store i32 %t64, ptr %l9, !tbaa !23
  store i1 false, ptr %l10, !tbaa !21
  %t66 = load ptr, ptr %l4, !tbaa !29
  %t68 = getelementptr %"compiler/typed:Spawn", ptr %t66, i32 0, i32 2
  %t69 = load { i64, ptr }, ptr %t68, !tbaa !27
  store { i64, ptr } %t69, ptr %l11, !tbaa !27
  store i64 0, ptr %l12, !tbaa !24
  %t71 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t73 = extractvalue { i64, ptr } %t71, 0
  store i64 %t73, ptr %l13, !tbaa !24
  br label %bb16
bb16:
  store %olang.scope zeroinitializer, ptr %s6
  %t75 = load i64, ptr %l12, !tbaa !24
  %t76 = load i64, ptr %l13, !tbaa !24
  %t79 = icmp slt i64 %t75, %t76
  %t81 = xor i1 %t79, true
  br i1 %t81, label %bb17, label %bb18
bb17:
  call void @__olang_scope_close(ptr %s6)
  br label %bb39
bb18:
  br label %bb19
bb19:
  %t83 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t83, ptr %l67, !tbaa !27
  %t84 = load i64, ptr %l12, !tbaa !24
  %t86 = getelementptr { i64, ptr }, ptr %l67, i32 0, i32 1
  %t87 = load ptr, ptr %t86, !tbaa !27
  %t88 = getelementptr ptr, ptr %t87, i64 %t84
  %t89 = load ptr, ptr %t88, !tbaa !39
  store ptr %t89, ptr %l14, !tbaa !29
  %t91 = load ptr, ptr %l14, !tbaa !29
  %t93 = getelementptr %"compiler/typed:TaskClause", ptr %t91, i32 0, i32 2
  %t94 = load i1, ptr %t93, !tbaa !21
  br i1 %t94, label %bb20, label %bb21
bb20:
  store i1 true, ptr %l10, !tbaa !21
  br label %bb22
bb21:
  br label %bb22
bb22:
  %t96 = load ptr, ptr %l14, !tbaa !29
  %t98 = getelementptr %"compiler/typed:TaskClause", ptr %t96, i32 0, i32 1
  %t99 = load { i64, ptr }, ptr %t98, !tbaa !27
  store { i64, ptr } %t99, ptr %l15, !tbaa !27
  store i64 0, ptr %l16, !tbaa !24
  %t101 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t103 = extractvalue { i64, ptr } %t101, 0
  store i64 %t103, ptr %l17, !tbaa !24
  br label %bb23
bb23:
  store %olang.scope zeroinitializer, ptr %s9
  %t105 = load i64, ptr %l16, !tbaa !24
  %t106 = load i64, ptr %l17, !tbaa !24
  %t109 = icmp slt i64 %t105, %t106
  %t111 = xor i1 %t109, true
  br i1 %t111, label %bb24, label %bb25
bb24:
  call void @__olang_scope_close(ptr %s9)
  br label %bb37
bb25:
  br label %bb26
bb26:
  %t113 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t113, ptr %l80, !tbaa !27
  %t114 = load i64, ptr %l16, !tbaa !24
  %t116 = getelementptr { i64, ptr }, ptr %l80, i32 0, i32 1
  %t117 = load ptr, ptr %t116, !tbaa !27
  %t118 = getelementptr %"compiler/typed:Item", ptr %t117, i64 %t114
  %t119 = load %"compiler/typed:Item", ptr %t118
  store %"compiler/typed:Item" %t119, ptr %l18
  %t121 = getelementptr %"compiler/typed:Item", ptr %l18, i32 0, i32 1
  %t122 = load i64, ptr %t121, !tbaa !24
  %t124 = icmp slt i64 %t122, 0
  br i1 %t124, label %bb27, label %bb28
bb27:
  %t126 = load ptr, ptr %l3, !tbaa !29
  store ptr %t126, ptr %l86, !tbaa !29
  %t127 = load ptr, ptr %l3, !tbaa !29
  %t128 = getelementptr %"compiler/typed:Item", ptr %l18, i32 0, i32 0
  %t129 = load i32, ptr %t128, !tbaa !23
  %t132 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t127, i32 %t129)
  store i32 %t132, ptr %l89
  br label %bb29
bb28:
  store i1 false, ptr %l85, !tbaa !21
  br label %bb32
bb29:
  %t133 = load ptr, ptr %l3, !tbaa !29
  %t134 = load i32, ptr %l9, !tbaa !23
  %t137 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t133, i32 %t134)
  store i32 %t137, ptr %l92
  br label %bb30
bb30:
  %t138 = load ptr, ptr %l86, !tbaa !29
  %t139 = load i32, ptr %l89, !tbaa !23
  %t140 = load i32, ptr %l92, !tbaa !23
  %t141 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t138, i32 %t139, i32 %t140)
  store i1 %t141, ptr %l93
  br label %bb31
bb31:
  %t142 = load i1, ptr %l93, !tbaa !21
  store i1 %t142, ptr %l85, !tbaa !21
  br label %bb32
bb32:
  %t143 = load i1, ptr %l85, !tbaa !21
  br i1 %t143, label %bb33, label %bb34
bb33:
  store i1 true, ptr %l10, !tbaa !21
  br label %bb35
bb34:
  br label %bb35
bb35:
  call void @__olang_scope_close(ptr %s9)
  br label %bb36
bb36:
  %t144 = load i64, ptr %l16, !tbaa !24
  %t146 = add i64 %t144, 1
  store i64 %t146, ptr %l16, !tbaa !24
  br label %bb23
bb37:
  call void @__olang_scope_close(ptr %s6)
  br label %bb38
bb38:
  %t148 = load i64, ptr %l12, !tbaa !24
  %t150 = add i64 %t148, 1
  store i64 %t150, ptr %l12, !tbaa !24
  br label %bb16
bb39:
  %t152 = load i1, ptr %l10, !tbaa !21
  br i1 %t152, label %bb40, label %bb41
bb40:
  call void @__olang_scope_close(ptr %s4)
  br label %bb69
bb41:
  br label %bb42
bb42:
  store i1 false, ptr %l19, !tbaa !21
  %t154 = load ptr, ptr %l2, !tbaa !29
  store ptr %t154, ptr %l20, !tbaa !29
  store i64 0, ptr %l21, !tbaa !24
  br label %bb43
bb43:
  store %olang.scope zeroinitializer, ptr %s15
  %t156 = load ptr, ptr %l20, !tbaa !29
  %t157 = load i64, ptr %l21, !tbaa !24
  %t160 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eRunF_H9c1707946c43ec840ffe1821bea89b1f(ptr %v2, ptr %t156, i64 %t157)
  %t161 = extractvalue { i32, { i64, ptr } } %t160, 1
  %t162 = extractvalue { i32, { i64, ptr } } %t160, 0
  store i32 %t162, ptr %l104
  %t163 = icmp ne i32 %t162, 0
  br i1 %t163, label %bb45, label %ok.164
ok.164:
  store { i64, ptr } %t161, ptr %l103
  br label %bb44
bb44:
  %t165 = load { i64, ptr }, ptr %l103, !tbaa !27
  store { i64, ptr } %t165, ptr %l100, !tbaa !27
  br label %bb49
bb45:
  %t166 = load i32, ptr %l104, !tbaa !23
  %t167 = ashr i32 %t166, 16
  %t169 = icmp eq i32 %t167, 1
  br i1 %t169, label %bb46, label %bb47
bb46:
  br label %bb48
bb47:
  call void @__olang_check_failed(ptr @olang_loc_7b1a9423057e34c5_261f06cd9be6d659)
  unreachable
bb48:
  call void @__olang_scope_close(ptr %s15)
  br label %bb63
bb49:
  %t171 = load { i64, ptr }, ptr %l100, !tbaa !27
  store { i64, ptr } %t171, ptr %l22, !tbaa !27
  %t172 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t174 = extractvalue { i64, ptr } %t172, 0
  store i64 %t174, ptr %l23, !tbaa !24
  store i64 0, ptr %l24, !tbaa !24
  br label %bb50
bb50:
  store %olang.scope zeroinitializer, ptr %s16
  %t176 = load i64, ptr %l24, !tbaa !24
  %t177 = load i64, ptr %l23, !tbaa !24
  %t180 = icmp slt i64 %t176, %t177
  %t182 = xor i1 %t180, true
  br i1 %t182, label %bb51, label %bb52
bb51:
  call void @__olang_scope_close(ptr %s16)
  br label %bb61
bb52:
  br label %bb53
bb53:
  %t184 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t184, ptr %l113, !tbaa !27
  %t185 = load i64, ptr %l24, !tbaa !24
  %t187 = getelementptr { i64, ptr }, ptr %l113, i32 0, i32 1
  %t188 = load ptr, ptr %t187, !tbaa !27
  %t189 = getelementptr i32, ptr %t188, i64 %t185
  %t190 = load i32, ptr %t189, !tbaa !33
  store i32 %t190, ptr %l25, !tbaa !23
  %t192 = load i1, ptr %l19, !tbaa !21
  br i1 %t192, label %bb54, label %bb55
bb54:
  store i1 true, ptr %l117, !tbaa !21
  br label %bb59
bb55:
  %t194 = load ptr, ptr %l3, !tbaa !29
  store ptr %t194, ptr %l118, !tbaa !29
  %t195 = load ptr, ptr %l3, !tbaa !29
  %t196 = load i32, ptr %l25, !tbaa !23
  %t199 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t195, i32 %t196)
  store i32 %t199, ptr %l121
  br label %bb56
bb56:
  %t200 = load ptr, ptr %l3, !tbaa !29
  %t201 = load i32, ptr %l9, !tbaa !23
  %t204 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t200, i32 %t201)
  store i32 %t204, ptr %l124
  br label %bb57
bb57:
  %t205 = load ptr, ptr %l118, !tbaa !29
  %t206 = load i32, ptr %l121, !tbaa !23
  %t207 = load i32, ptr %l124, !tbaa !23
  %t208 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t205, i32 %t206, i32 %t207)
  store i1 %t208, ptr %l125
  br label %bb58
bb58:
  %t209 = load i1, ptr %l125, !tbaa !21
  store i1 %t209, ptr %l117, !tbaa !21
  br label %bb59
bb59:
  %t210 = load i1, ptr %l117, !tbaa !21
  store i1 %t210, ptr %l19, !tbaa !21
  call void @__olang_scope_close(ptr %s16)
  br label %bb60
bb60:
  %t211 = load i64, ptr %l24, !tbaa !24
  %t213 = add i64 %t211, 1
  store i64 %t213, ptr %l24, !tbaa !24
  br label %bb50
bb61:
  %t215 = load i64, ptr %l21, !tbaa !24
  %t216 = load i64, ptr %l23, !tbaa !24
  %t219 = add i64 %t215, %t216
  store i64 %t219, ptr %l21, !tbaa !24
  call void @__olang_scope_close(ptr %s15)
  br label %bb62
bb62:
  br label %bb43
bb63:
  %t221 = load i1, ptr %l19, !tbaa !21
  %t223 = xor i1 %t221, true
  br i1 %t223, label %bb64, label %bb65
bb64:
  %t225 = load ptr, ptr %l2, !tbaa !29
  store ptr %t225, ptr %l133, !tbaa !29
  %t226 = load ptr, ptr %l3, !tbaa !29
  %t227 = load i32, ptr %l9, !tbaa !23
  %t230 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t226, i32 %t227)
  store i32 %t230, ptr %l136
  br label %bb66
bb65:
  br label %bb68
bb66:
  %t231 = load ptr, ptr %l133, !tbaa !29
  %t232 = load i32, ptr %l136, !tbaa !23
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v2, ptr %t231, i32 %t232)
  br label %bb67
bb67:
  br label %bb68
bb68:
  call void @__olang_scope_close(ptr %s4)
  br label %bb69
bb69:
  %t233 = load i64, ptr %l7, !tbaa !24
  %t235 = add i64 %t233, 1
  store i64 %t235, ptr %l7, !tbaa !24
  br label %bb12
bb70:
  br label %bb99
bb71:
  %t237 = load ptr, ptr %l1, !tbaa !29
  store ptr %t237, ptr %l139, !tbaa !29
  store i1 false, ptr %l140, !tbaa !21
  %t238 = load ptr, ptr %l139, !tbaa !29
  %t239 = icmp ne ptr %t238, null
  br i1 %t239, label %bb72, label %bb73
bb72:
  %t241 = load ptr, ptr %l139, !tbaa !29
  %t242 = load i64, ptr %t241
  %t244 = icmp eq i64 %t242, 10
  store i1 %t244, ptr %l140, !tbaa !21
  br label %bb73
bb73:
  %t245 = load i1, ptr %l140, !tbaa !21
  br i1 %t245, label %bb74, label %bb75
bb74:
  %t246 = load ptr, ptr %l1, !tbaa !29
  %t248 = getelementptr { i64, [3 x i64] }, ptr %t246, i32 0, i32 1
  %t249 = getelementptr { %"compiler/source:Span", ptr }, ptr %t248, i32 0, i32 1
  %t250 = load ptr, ptr %t249
  store ptr %t250, ptr %l26, !tbaa !29
  br label %bb76
bb75:
  br label %bb78
bb76:
  %t252 = load ptr, ptr %l0, !tbaa !29
  %t253 = load ptr, ptr %l26, !tbaa !29
  %t255 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2espawnErrors(ptr %v0, ptr %v1, ptr %v2, ptr %t252, ptr %t253, ptr %t255)
  br label %bb77
bb77:
  br label %bb99
bb78:
  %t259 = load ptr, ptr %l1, !tbaa !29
  store ptr %t259, ptr %l149, !tbaa !29
  store i1 false, ptr %l150, !tbaa !21
  %t260 = load ptr, ptr %l149, !tbaa !29
  %t261 = icmp ne ptr %t260, null
  br i1 %t261, label %bb79, label %bb80
bb79:
  %t263 = load ptr, ptr %l149, !tbaa !29
  %t264 = load i64, ptr %t263
  %t266 = icmp eq i64 %t264, 3
  store i1 %t266, ptr %l150, !tbaa !21
  br label %bb80
bb80:
  %t267 = load i1, ptr %l150, !tbaa !21
  br i1 %t267, label %bb81, label %bb82
bb81:
  %t268 = load ptr, ptr %l1, !tbaa !29
  %t270 = getelementptr { i64, [3 x i64] }, ptr %t268, i32 0, i32 1
  %t271 = getelementptr { %"compiler/source:Span", ptr }, ptr %t270, i32 0, i32 1
  %t272 = load ptr, ptr %t271
  store ptr %t272, ptr %l27, !tbaa !29
  br label %bb83
bb82:
  br label %bb86
bb83:
  %t274 = load ptr, ptr %l0, !tbaa !29
  %t275 = load ptr, ptr %l27, !tbaa !29
  %t277 = getelementptr %"compiler/typed:If", ptr %t275, i32 0, i32 1
  %t278 = load ptr, ptr %t277, !tbaa !29
  %t280 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2espawnErrors(ptr %v0, ptr %v1, ptr %v2, ptr %t274, ptr %t278, ptr %t280)
  br label %bb84
bb84:
  %t284 = load ptr, ptr %l0, !tbaa !29
  %t285 = load ptr, ptr %l27, !tbaa !29
  %t287 = getelementptr %"compiler/typed:If", ptr %t285, i32 0, i32 2
  %t288 = load ptr, ptr %t287, !tbaa !29
  %t289 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2espawnErrors(ptr %v0, ptr %v1, ptr %v2, ptr %t284, ptr %t288, ptr %t289)
  br label %bb85
bb85:
  br label %bb99
bb86:
  %t293 = load ptr, ptr %l1, !tbaa !29
  store ptr %t293, ptr %l164, !tbaa !29
  store i1 false, ptr %l165, !tbaa !21
  %t294 = load ptr, ptr %l164, !tbaa !29
  %t295 = icmp ne ptr %t294, null
  br i1 %t295, label %bb87, label %bb88
bb87:
  %t297 = load ptr, ptr %l164, !tbaa !29
  %t298 = load i64, ptr %t297
  %t300 = icmp eq i64 %t298, 4
  store i1 %t300, ptr %l165, !tbaa !21
  br label %bb88
bb88:
  %t301 = load i1, ptr %l165, !tbaa !21
  br i1 %t301, label %bb89, label %bb90
bb89:
  %t302 = load ptr, ptr %l1, !tbaa !29
  %t304 = getelementptr { i64, [3 x i64] }, ptr %t302, i32 0, i32 1
  %t305 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t304, i32 0, i32 1
  %t306 = load ptr, ptr %t305
  store ptr %t306, ptr %l28, !tbaa !29
  %t308 = load ptr, ptr %l1, !tbaa !29
  %t310 = getelementptr { i64, [3 x i64] }, ptr %t308, i32 0, i32 1
  %t311 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t310, i32 0, i32 2
  %t312 = load ptr, ptr %t311
  store ptr %t312, ptr %l29, !tbaa !29
  br label %bb91
bb90:
  br label %bb94
bb91:
  %t314 = load ptr, ptr %l0, !tbaa !29
  %t315 = load ptr, ptr %l28, !tbaa !29
  %t317 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2espawnErrors(ptr %v0, ptr %v1, ptr %v2, ptr %t314, ptr %t315, ptr %t317)
  br label %bb92
bb92:
  %t321 = load ptr, ptr %l0, !tbaa !29
  %t322 = load ptr, ptr %l29, !tbaa !29
  %t323 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2espawnErrors(ptr %v0, ptr %v1, ptr %v2, ptr %t321, ptr %t322, ptr %t323)
  br label %bb93
bb93:
  br label %bb99
bb94:
  br i1 true, label %bb95, label %bb96
bb95:
  br label %bb97
bb96:
  br label %bb98
bb97:
  br label %bb99
bb98:
  call void @__olang_check_failed(ptr @olang_loc_4d2a900631880414_3719f57230f55c88)
  unreachable
bb99:
  br label %ret
ret:
  ret void
}

define dso_local { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2estorageOf(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca { i64, [1 x i64] }
  %l11 = alloca %"compiler/mir:Local"
  %l17 = alloca ptr
  %l23 = alloca %"compiler/typed:Local"
  %l26 = alloca { i64, [1 x i64] }
  %rv = alloca { i64, [1 x i64] }
  %t8 = alloca { i64, [1 x i64] }, align 8
  %t49 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 19
  %t4 = load i1, ptr %t3, !tbaa !21
  %t6 = xor i1 %t4, true
  br i1 %t6, label %bb1, label %bb2
bb1:
  store { i64, [1 x i64] } zeroinitializer, ptr %t8
  %t9 = getelementptr { i64, [1 x i64] }, ptr %t8, i32 0, i32 0
  store i64 2, ptr %t9
  %t10 = load { i64, [1 x i64] }, ptr %t8
  store { i64, [1 x i64] } %t10, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/lower:lowering", ptr %t12, i32 0, i32 3
  %t15 = getelementptr %"compiler/mir:Fn", ptr %t14, i32 0, i32 7
  %t16 = load i32, ptr %l1, !tbaa !23
  %t18 = sext i32 %t16 to i64
  %t21 = call %"compiler/mir:Local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aLocal_3e_2eAt_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %t15, i64 %t18)
  store %"compiler/mir:Local" %t21, ptr %l11
  br label %bb4
bb4:
  %t22 = getelementptr %"compiler/mir:Local", ptr %l11, i32 0, i32 4
  %t23 = load { i64, [1 x i64] }, ptr %t22
  store { i64, [1 x i64] } %t23, ptr %l2
  %t25 = load { i64, [1 x i64] }, ptr %l2
  %t27 = extractvalue { i64, [1 x i64] } %t25, 0
  %t28 = icmp eq i64 %t27, 3
  %t30 = xor i1 %t28, true
  br i1 %t30, label %bb5, label %bb6
bb5:
  %t32 = load { i64, [1 x i64] }, ptr %l2
  store { i64, [1 x i64] } %t32, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t34 = load ptr, ptr %l0, !tbaa !29
  store ptr %t34, ptr %l17, !tbaa !29
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/lower:lowering", ptr %t35, i32 0, i32 1
  %t38 = load ptr, ptr %t37, !tbaa !29
  %t40 = getelementptr %"compiler/typed:Body", ptr %t38, i32 0, i32 7
  %t41 = load i32, ptr %l1, !tbaa !23
  %t43 = sext i32 %t41 to i64
  %t46 = call %"compiler/typed:Local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t40, i64 %t43)
  store %"compiler/typed:Local" %t46, ptr %l23
  br label %bb8
bb8:
  %t47 = getelementptr %"compiler/typed:Local", ptr %l23, i32 0, i32 3
  %t48 = load i32, ptr %t47, !tbaa !23
  store { i64, [1 x i64] } zeroinitializer, ptr %t49
  %t50 = getelementptr { i64, [1 x i64] }, ptr %t49, i32 0, i32 0
  store i64 1, ptr %t50
  %t52 = insertvalue { i32 } undef, i32 %t48, 0
  %t53 = getelementptr { i64, [1 x i64] }, ptr %t49, i32 0, i32 1
  store { i32 } %t52, ptr %t53
  %t54 = load { i64, [1 x i64] }, ptr %t49
  %t55 = load ptr, ptr %l17, !tbaa !29
  %t57 = call { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2escopeRef(ptr %v0, ptr %t55, { i64, [1 x i64] } %t54)
  store { i64, [1 x i64] } %t57, ptr %l26
  br label %bb9
bb9:
  %t58 = load { i64, [1 x i64] }, ptr %l26
  store { i64, [1 x i64] } %t58, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [1 x i64] }, ptr %rv
  ret { i64, [1 x i64] } %rr
}

define dso_local i32 @compiler_2flower_2ecompiler_2flower_3alowering_2etemp(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %l7 = alloca i32
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/lower:lowering", ptr %a0, i32 0, i32 3
  %t9 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddTemp(ptr %v0, ptr %t3, i32 %a1, %"compiler/source:Span" %a2)
  store i32 %t9, ptr %l7
  br label %bb1
bb1:
  %t10 = load i32, ptr %l7, !tbaa !23
  store i32 %t10, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2etoClause(ptr %v0, ptr %v1, ptr %a0, %"compiler/lower:tryCtx" %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/lower:tryCtx"
  %l2 = alloca i64
  %l3 = alloca i1
  %l15 = alloca i32
  %l18 = alloca ptr
  %l19 = alloca i64
  %l22 = alloca i32
  %l23 = alloca ptr
  %l26 = alloca i32
  store ptr %a0, ptr %l0
  store %"compiler/lower:tryCtx" %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 18
  %t4 = load i1, ptr %t3, !tbaa !21
  store i1 %t4, ptr %l3, !tbaa !21
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/lower:lowering", ptr %t6, i32 0, i32 18
  store i1 true, ptr %t8, !tbaa !21
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/lower:tryCtx", ptr %l1, i32 0, i32 0
  %t11 = load i64, ptr %t10, !tbaa !24
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eleave(ptr %v0, ptr %t9, i64 %t11)
  br label %bb1
bb1:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t15 = load i1, ptr %l3, !tbaa !21
  %t18 = getelementptr %"compiler/lower:lowering", ptr %t14, i32 0, i32 18
  store i1 %t15, ptr %t18, !tbaa !21
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/lower:lowering", ptr %t19, i32 0, i32 7
  %t22 = load i1, ptr %t21, !tbaa !21
  br i1 %t22, label %bb2, label %bb3
bb2:
  br label %ret
bb3:
  br label %bb4
bb4:
  %t24 = getelementptr %"compiler/lower:tryCtx", ptr %l1, i32 0, i32 4
  %t25 = load i64, ptr %l2, !tbaa !24
  %t28 = call i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aBlockId_3e_2eAt_3ccompiler_2fmir_3aBlockId_3e(ptr %v1, ptr %t24, i64 %t25)
  store i32 %t28, ptr %l15
  br label %bb5
bb5:
  %t29 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t30 = load i32, ptr %l15, !tbaa !23
  %t32 = icmp eq i32 %t30, %t29
  br i1 %t32, label %bb6, label %bb7
bb6:
  %t34 = getelementptr %"compiler/lower:tryCtx", ptr %l1, i32 0, i32 4
  store ptr %t34, ptr %l18, !tbaa !29
  %t35 = load i64, ptr %l2, !tbaa !24
  store i64 %t35, ptr %l19, !tbaa !24
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/lower:lowering", ptr %t36, i32 0, i32 3
  %t40 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t38)
  store i32 %t40, ptr %l22
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t41 = load ptr, ptr %l18, !tbaa !29
  %t42 = load i64, ptr %l19, !tbaa !24
  %t43 = load i32, ptr %l22, !tbaa !23
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aBlockId_3e_2eSetAt_3ccompiler_2fmir_3aBlockId_3e(ptr %v1, ptr %t41, i64 %t42, i32 %t43)
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t44 = load ptr, ptr %l0, !tbaa !29
  store ptr %t44, ptr %l23, !tbaa !29
  %t45 = getelementptr %"compiler/lower:tryCtx", ptr %l1, i32 0, i32 4
  %t46 = load i64, ptr %l2, !tbaa !24
  %t49 = call i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aBlockId_3e_2eAt_3ccompiler_2fmir_3aBlockId_3e(ptr %v1, ptr %t45, i64 %t46)
  store i32 %t49, ptr %l26
  br label %bb11
bb11:
  %t50 = load ptr, ptr %l23, !tbaa !29
  %t51 = load i32, ptr %l26, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2egoto(ptr %v0, ptr %t50, i32 %t51)
  br label %bb12
bb12:
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2flower_2ecompiler_2flower_3alowering_2evals(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %lp2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l10 = alloca i64
  %l19 = alloca i64
  %l22 = alloca i64
  %l40 = alloca i64
  %l42 = alloca { i64, ptr }
  %l46 = alloca { i64, [4 x i64] }
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  store i64 %t3, ptr %l10, !tbaa !24
  %t4 = load i64, ptr %l10, !tbaa !24
  %t5 = icmp sge i64 %t4, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load i64, ptr %l10, !tbaa !24
  %t8 = icmp sle i64 %t7, 230584300921369395
  br i1 %t8, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_73384406ab4916da_7af5324ba56268d6)
  unreachable
bb3:
  %t10 = load i64, ptr %l10, !tbaa !24
  %t11 = mul i64 %t10, 40
  %t12 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t11)
  %t13 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  %t15 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 16, i64 8)
  store ptr %t15, ptr %lp2
  %t17 = load ptr, ptr %lp2
  store { i64, ptr } %t14, ptr %t17, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t18 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t20 = extractvalue { i64, ptr } %t18, 0
  store i64 %t20, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t22 = load i64, ptr %l4, !tbaa !24
  %t23 = load i64, ptr %l3, !tbaa !24
  %t26 = icmp sgt i64 %t22, %t23
  br i1 %t26, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_73384406ab4916da_7af5324ba56268d6)
  unreachable
bb5:
  %t28 = load i64, ptr %l5, !tbaa !24
  %t30 = icmp sgt i64 %t28, 0
  br i1 %t30, label %bb7, label %bb8
bb6:
  store i64 0, ptr %l19, !tbaa !24
  br label %bb10
bb7:
  %t32 = load i64, ptr %l4, !tbaa !24
  %t33 = load i64, ptr %l3, !tbaa !24
  %t36 = sub i64 %t32, %t33
  %t37 = load i64, ptr %l5, !tbaa !24
  %t40 = add i64 %t36, %t37
  %t42 = sub i64 %t40, 1
  %t43 = load i64, ptr %l5, !tbaa !24
  %t46 = sdiv i64 %t42, %t43
  store i64 %t46, ptr %l22, !tbaa !24
  br label %bb9
bb8:
  store i64 0, ptr %l22, !tbaa !24
  br label %bb9
bb9:
  %t48 = load i64, ptr %l22, !tbaa !24
  store i64 %t48, ptr %l19, !tbaa !24
  br label %bb10
bb10:
  %t49 = load i64, ptr %l19, !tbaa !24
  store i64 %t49, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb11
bb11:
  store %olang.scope zeroinitializer, ptr %s2
  %t50 = load i64, ptr %l7, !tbaa !24
  %t51 = load i64, ptr %l6, !tbaa !24
  %t54 = icmp slt i64 %t50, %t51
  %t56 = xor i1 %t54, true
  br i1 %t56, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s2)
  br label %bb17
bb13:
  br label %bb14
bb14:
  %t58 = load i64, ptr %l3, !tbaa !24
  %t59 = load i64, ptr %l7, !tbaa !24
  %t60 = load i64, ptr %l5, !tbaa !24
  %t63 = mul i64 %t59, %t60
  %t66 = add i64 %t58, %t63
  store i64 %t66, ptr %l8, !tbaa !24
  %t68 = load i64, ptr %l8, !tbaa !24
  store i64 %t68, ptr %l40, !tbaa !24
  %t70 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t70, ptr %l42, !tbaa !27
  %t71 = load i64, ptr %l8, !tbaa !24
  %t73 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t74 = load ptr, ptr %t73, !tbaa !27
  %t75 = getelementptr ptr, ptr %t74, i64 %t71
  %t76 = load ptr, ptr %t75, !tbaa !39
  %t80 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v1, ptr %a0, ptr %t76)
  store { i64, [4 x i64] } %t80, ptr %l46
  br label %bb15
bb15:
  %t81 = load { i64, [4 x i64] }, ptr %l46
  %t82 = load ptr, ptr %lp2
  %t83 = load i64, ptr %l40, !tbaa !24
  %t84 = getelementptr { i64, ptr }, ptr %t82, i32 0, i32 1
  %t85 = load ptr, ptr %t84, !tbaa !27
  %t86 = getelementptr { i64, [4 x i64] }, ptr %t85, i64 %t83
  store { i64, [4 x i64] } %t81, ptr %t86
  call void @__olang_scope_close(ptr %s2)
  br label %bb16
bb16:
  %t87 = load i64, ptr %l7, !tbaa !24
  %t89 = add i64 %t87, 1
  store i64 %t89, ptr %l7, !tbaa !24
  br label %bb11
bb17:
  %t91 = load ptr, ptr %lp2
  %t92 = load { i64, ptr }, ptr %t91, !tbaa !27
  store { i64, ptr } %t92, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3alowering_2evalueArray(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca i32
  %l8 = alloca i32
  %l11 = alloca i32
  %l14 = alloca i1
  %l17 = alloca i32
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/lower:lowering", ptr %a0, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t6, i32 %a1)
  store i32 %t10, ptr %l8
  br label %bb1
bb1:
  %t11 = load i32, ptr %l8, !tbaa !23
  store i32 %t11, ptr %l3, !tbaa !23
  %t12 = load ptr, ptr %l2, !tbaa !29
  %t13 = load i32, ptr %l3, !tbaa !23
  %t16 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t12, i32 %t13)
  store i32 %t16, ptr %l11
  br label %bb2
bb2:
  %t17 = load i32, ptr %l11
  %t19 = trunc i64 19 to i32
  %t20 = icmp eq i32 %t17, %t19
  br i1 %t20, label %bb3, label %bb4
bb3:
  %t22 = load ptr, ptr %l2, !tbaa !29
  %t23 = load i32, ptr %l3, !tbaa !23
  %t26 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t22, i32 %t23)
  store i32 %t26, ptr %l17
  br label %bb5
bb4:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb6
bb5:
  %t27 = load i32, ptr %l17, !tbaa !23
  %t28 = icmp eq i32 %t27, 0
  store i1 %t28, ptr %l14, !tbaa !21
  br label %bb6
bb6:
  %t30 = load i1, ptr %l14, !tbaa !21
  store i1 %t30, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2ewith(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/lower:pl" %a1, { i64, [1 x i64] } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/lower:pl"
  %lp3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l11 = alloca %"compiler/lower:pl"
  %l13 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l17 = alloca i32
  %l26 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca %"compiler/lower:pl"
  store ptr %a0, ptr %l0
  store %"compiler/lower:pl" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/lower:pl", ptr %l1, i32 0, i32 0
  %t2 = load { i64, [2 x i64] }, ptr %t1
  %t4 = call %"compiler/lower:pl" @compiler_2flower_3apl_2ector(ptr %v2, { i64, [2 x i64] } %t2)
  store %"compiler/lower:pl" %t4, ptr %l11
  br label %bb1
bb1:
  %t5 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 32, i64 8)
  store ptr %t5, ptr %lp3
  %t6 = load %"compiler/lower:pl", ptr %l11
  %t7 = load ptr, ptr %lp3
  store %"compiler/lower:pl" %t6, ptr %t7
  %t8 = getelementptr %"compiler/lower:pl", ptr %l1, i32 0, i32 1
  store ptr %t8, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t10 = load ptr, ptr %l4, !tbaa !29
  %t11 = load i64, ptr %l5, !tbaa !24
  %t14 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aProj_3e_2eRunFrom_3ccompiler_2fmir_3aProj_3e(ptr %v1, ptr %t10, i64 %t11)
  %t15 = extractvalue { i32, { i64, ptr } } %t14, 1
  %t16 = extractvalue { i32, { i64, ptr } } %t14, 0
  store i32 %t16, ptr %l17
  %t17 = icmp ne i32 %t16, 0
  br i1 %t17, label %bb4, label %ok.18
ok.18:
  store { i64, ptr } %t15, ptr %l16
  br label %bb3
bb3:
  %t19 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t19, ptr %l13, !tbaa !27
  br label %bb8
bb4:
  %t20 = load i32, ptr %l17, !tbaa !23
  %t21 = ashr i32 %t20, 16
  %t23 = icmp eq i32 %t21, 1
  br i1 %t23, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  call void @__olang_check_failed(ptr @olang_loc_e4cb0830a37b0e81_73b8c395fe92f955)
  unreachable
bb7:
  call void @__olang_scope_close(ptr %s2)
  br label %bb17
bb8:
  %t25 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t25, ptr %l6, !tbaa !27
  %t26 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t28 = extractvalue { i64, ptr } %t26, 0
  store i64 %t28, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s3
  %t30 = load i64, ptr %l8, !tbaa !24
  %t31 = load i64, ptr %l7, !tbaa !24
  %t34 = icmp slt i64 %t30, %t31
  %t36 = xor i1 %t34, true
  br i1 %t36, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s3)
  br label %bb15
bb11:
  br label %bb12
bb12:
  %t38 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t38, ptr %l26, !tbaa !27
  %t39 = load i64, ptr %l8, !tbaa !24
  %t41 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !27
  %t43 = getelementptr { i64, [1 x i64] }, ptr %t42, i64 %t39
  %t44 = load { i64, [1 x i64] }, ptr %t43
  %t46 = load ptr, ptr %lp3
  %t47 = getelementptr %"compiler/lower:pl", ptr %t46, i32 0, i32 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aProj_3e_2ePush_3ccompiler_2fmir_3aProj_3e(ptr %v2, ptr %t47, { i64, [1 x i64] } %t44)
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s3)
  br label %bb14
bb14:
  %t51 = load i64, ptr %l8, !tbaa !24
  %t53 = add i64 %t51, 1
  store i64 %t53, ptr %l8, !tbaa !24
  br label %bb9
bb15:
  %t55 = load i64, ptr %l5, !tbaa !24
  %t56 = load i64, ptr %l7, !tbaa !24
  %t59 = add i64 %t55, %t56
  store i64 %t59, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb16
bb16:
  br label %bb2
bb17:
  %t61 = load ptr, ptr %lp3
  %t62 = getelementptr %"compiler/lower:pl", ptr %t61, i32 0, i32 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aProj_3e_2ePush_3ccompiler_2fmir_3aProj_3e(ptr %v2, ptr %t62, { i64, [1 x i64] } %a2)
  br label %bb18
bb18:
  %t66 = load ptr, ptr %lp3
  %t67 = load %"compiler/lower:pl", ptr %t66
  store %"compiler/lower:pl" %t67, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/lower:pl", ptr %rv
  ret %"compiler/lower:pl" %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2eword(ptr %v0, ptr %v1, ptr %a0, { i64, [1 x i64] } %a1, { i64, ptr } %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l12 = alloca i32
  %l15 = alloca i64
  %l23 = alloca i64
  %l26 = alloca i64
  %l45 = alloca { i64, ptr }
  %l53 = alloca i32
  %l55 = alloca ptr
  %l59 = alloca i32
  %l61 = alloca i32
  %l67 = alloca i32
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %t110 = alloca { i64, [2 x i64] }, align 8
  %t132 = alloca { i64, [4 x i64] }, align 8
  %t144 = alloca { i64, [21 x i64] }, align 8
  store ptr %a0, ptr %l0
  store { i64, ptr } %a2, ptr %l2
  store %"compiler/source:Span" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  store i64 %t3, ptr %l15, !tbaa !24
  %t4 = load i64, ptr %l15, !tbaa !24
  %t5 = icmp sge i64 %t4, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load i64, ptr %l15, !tbaa !24
  %t8 = mul i64 %t7, 1
  %t9 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t13 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  store i64 %t15, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t17 = load i64, ptr %l6, !tbaa !24
  %t18 = load i64, ptr %l5, !tbaa !24
  %t21 = icmp sgt i64 %t17, %t18
  br i1 %t21, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_683e5e170631bc0e_4d1425fdf2d9aa22)
  unreachable
bb3:
  %t23 = load i64, ptr %l7, !tbaa !24
  %t25 = icmp sgt i64 %t23, 0
  br i1 %t25, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l23, !tbaa !24
  br label %bb8
bb5:
  %t27 = load i64, ptr %l6, !tbaa !24
  %t28 = load i64, ptr %l5, !tbaa !24
  %t31 = sub i64 %t27, %t28
  %t32 = load i64, ptr %l7, !tbaa !24
  %t35 = add i64 %t31, %t32
  %t37 = sub i64 %t35, 1
  %t38 = load i64, ptr %l7, !tbaa !24
  %t41 = sdiv i64 %t37, %t38
  store i64 %t41, ptr %l26, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l26, !tbaa !24
  br label %bb7
bb7:
  %t43 = load i64, ptr %l26, !tbaa !24
  store i64 %t43, ptr %l23, !tbaa !24
  br label %bb8
bb8:
  %t44 = load i64, ptr %l23, !tbaa !24
  store i64 %t44, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t45 = load i64, ptr %l9, !tbaa !24
  %t46 = load i64, ptr %l8, !tbaa !24
  %t49 = icmp slt i64 %t45, %t46
  %t51 = xor i1 %t49, true
  br i1 %t51, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb14
bb11:
  br label %bb12
bb12:
  %t53 = load i64, ptr %l5, !tbaa !24
  %t54 = load i64, ptr %l9, !tbaa !24
  %t55 = load i64, ptr %l7, !tbaa !24
  %t58 = mul i64 %t54, %t55
  %t61 = add i64 %t53, %t58
  store i64 %t61, ptr %l10, !tbaa !24
  %t63 = load i64, ptr %l10, !tbaa !24
  %t64 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t64, ptr %l45, !tbaa !27
  %t65 = load i64, ptr %l10, !tbaa !24
  %t67 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t68 = load ptr, ptr %t67, !tbaa !27
  %t69 = getelementptr i8, ptr %t68, i64 %t65
  %t70 = load i8, ptr %t69, !tbaa !32
  %t74 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t75 = load ptr, ptr %t74, !tbaa !27
  %t76 = getelementptr i8, ptr %t75, i64 %t63
  store i8 %t70, ptr %t76, !tbaa !32
  call void @__olang_scope_close(ptr %s2)
  br label %bb13
bb13:
  %t77 = load i64, ptr %l9, !tbaa !24
  %t79 = add i64 %t77, 1
  store i64 %t79, ptr %l9, !tbaa !24
  br label %bb9
bb14:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"compiler/lower:lowering", ptr %t81, i32 0, i32 2
  %t84 = load ptr, ptr %t83, !tbaa !29
  %t86 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s0, ptr %t84, { i64, ptr } { i64 2, ptr @.d33 })
  store i32 %t86, ptr %l53
  br label %bb15
bb15:
  %t87 = load i32, ptr %l53, !tbaa !23
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t90 = getelementptr %"compiler/lower:lowering", ptr %t88, i32 0, i32 2
  %t91 = load ptr, ptr %t90, !tbaa !29
  store ptr %t91, ptr %l55, !tbaa !29
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"compiler/lower:lowering", ptr %t92, i32 0, i32 2
  %t95 = load ptr, ptr %t94, !tbaa !29
  %t99 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArray(ptr %v0, ptr %t95, i32 %t87, i32 0)
  store i32 %t99, ptr %l59
  br label %bb16
bb16:
  %t100 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t101 = load ptr, ptr %l55, !tbaa !29
  %t102 = load i32, ptr %l59, !tbaa !23
  %t104 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t101, i32 %t102, i64 %t100)
  store i32 %t104, ptr %l61
  br label %bb17
bb17:
  %t105 = load i32, ptr %l61, !tbaa !23
  store i32 %t105, ptr %l12, !tbaa !23
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t108 = getelementptr %"compiler/lower:lowering", ptr %t106, i32 0, i32 3
  %t109 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, [2 x i64] } zeroinitializer, ptr %t110
  %t111 = getelementptr { i64, [2 x i64] }, ptr %t110, i32 0, i32 0
  store i64 1, ptr %t111
  %t113 = insertvalue { { i64, ptr } } undef, { i64, ptr } %t109, 0
  %t114 = getelementptr { i64, [2 x i64] }, ptr %t110, i32 0, i32 1
  store { { i64, ptr } } %t113, ptr %t114
  %t115 = load { i64, [2 x i64] }, ptr %t110
  %t117 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 24, i64 8)
  store { i64, [2 x i64] } %t115, ptr %t117
  %t120 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddConst(ptr %v0, ptr %s0, ptr %t108, ptr %t117)
  store i32 %t120, ptr %l67
  br label %bb18
bb18:
  %t121 = load i32, ptr %l67, !tbaa !23
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t123 = load %"compiler/source:Span", ptr %l3
  %t125 = load i32, ptr %l12, !tbaa !23
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t129 = getelementptr %"compiler/lower:lowering", ptr %t127, i32 0, i32 4
  %t130 = load i64, ptr %t129, !tbaa !24
  %t131 = load %"compiler/source:Span", ptr %l3
  store { i64, [4 x i64] } zeroinitializer, ptr %t132
  %t133 = getelementptr { i64, [4 x i64] }, ptr %t132, i32 0, i32 0
  store i64 3, ptr %t133
  %t135 = insertvalue { i32, i32, i64, %"compiler/source:Span" } undef, i32 %t125, 0
  %t137 = insertvalue { i32, i32, i64, %"compiler/source:Span" } %t135, i32 %t121, 1
  %t139 = insertvalue { i32, i32, i64, %"compiler/source:Span" } %t137, i64 %t130, 2
  %t141 = insertvalue { i32, i32, i64, %"compiler/source:Span" } %t139, %"compiler/source:Span" %t131, 3
  %t142 = getelementptr { i64, [4 x i64] }, ptr %t132, i32 0, i32 1
  store { i32, i32, i64, %"compiler/source:Span" } %t141, ptr %t142
  %t143 = load { i64, [4 x i64] }, ptr %t132
  store { i64, [21 x i64] } zeroinitializer, ptr %t144
  %t145 = getelementptr { i64, [21 x i64] }, ptr %t144, i32 0, i32 0
  store i64 9, ptr %t145
  %t147 = insertvalue { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } undef, %"compiler/source:Span" %t123, 0
  %t149 = insertvalue { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } %t147, { i64, [1 x i64] } %a1, 1
  %t151 = insertvalue { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } %t149, i32 0, 2
  %t153 = insertvalue { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } %t151, { i64, [4 x i64] } %t143, 3
  %t154 = getelementptr { i64, [21 x i64] }, ptr %t144, i32 0, i32 1
  store { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } %t153, ptr %t154
  %t155 = load { i64, [21 x i64] }, ptr %t144
  %t157 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t155, ptr %t157
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s0, ptr %t122, ptr %t157)
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ezero(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca { i64, [5 x i64] }
  %l6 = alloca i32
  %l7 = alloca i32
  %l15 = alloca i32
  %l19 = alloca i32
  %l32 = alloca i32
  %l36 = alloca i32
  %l38 = alloca ptr
  %l39 = alloca { i64, [5 x i64] }
  %l40 = alloca %"compiler/mir:Range"
  %l41 = alloca ptr
  %l45 = alloca i64
  %l46 = alloca %"compiler/mir:Range"
  %l48 = alloca %"compiler/mir:Place"
  %l52 = alloca %"compiler/mir:Call"
  %l53 = alloca i32
  %l61 = alloca %"compiler/mir:Place"
  %s0 = alloca %olang.scope
  %rv = alloca { i64, [4 x i64] }
  %t24 = alloca { i64, [1 x i64] }, align 8
  %t33 = alloca { i64, [5 x i64] }, align 8
  %t47 = alloca { i64, [1 x i64] }, align 8
  %t108 = alloca { i64, [7 x i64] }, align 8
  %t125 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/lower:lowering", ptr %t6, i32 0, i32 0
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t10 = load i32, ptr %l1, !tbaa !23
  %t14 = call i32 @compiler_2flower_2ecompiler_2flower_3aLowerer_2ehelperTy(ptr %v0, ptr %t9, i32 3, i32 %t10)
  store i32 %t14, ptr %l15
  br label %bb1
bb1:
  %t15 = load i32, ptr %l15, !tbaa !23
  store i32 %t15, ptr %l1, !tbaa !23
  %t16 = load ptr, ptr %l3, !tbaa !29
  %t17 = load i32, ptr %l1, !tbaa !23
  %t21 = call i32 @compiler_2fmir_2eHelperType(ptr %v0, ptr %t16, i32 3, i32 %t17)
  store i32 %t21, ptr %l19
  br label %bb2
bb2:
  %t22 = load i32, ptr %l19, !tbaa !23
  store i32 %t22, ptr %l4, !tbaa !23
  %t23 = load i32, ptr %l1, !tbaa !23
  store { i64, [1 x i64] } zeroinitializer, ptr %t24
  %t25 = getelementptr { i64, [1 x i64] }, ptr %t24, i32 0, i32 0
  store i64 2, ptr %t25
  %t27 = insertvalue { i32, i32 } undef, i32 3, 0
  %t29 = insertvalue { i32, i32 } %t27, i32 %t23, 1
  %t30 = getelementptr { i64, [1 x i64] }, ptr %t24, i32 0, i32 1
  store { i32, i32 } %t29, ptr %t30
  %t31 = load { i64, [1 x i64] }, ptr %t24
  %t32 = load i32, ptr %l4, !tbaa !23
  store { i64, [5 x i64] } zeroinitializer, ptr %t33
  %t34 = getelementptr { i64, [5 x i64] }, ptr %t33, i32 0, i32 0
  store i64 0, ptr %t34
  %t36 = insertvalue { { i64, [1 x i64] }, i32 } undef, { i64, [1 x i64] } %t31, 0
  %t38 = insertvalue { { i64, [1 x i64] }, i32 } %t36, i32 %t32, 1
  %t39 = getelementptr { i64, [5 x i64] }, ptr %t33, i32 0, i32 1
  store { { i64, [1 x i64] }, i32 } %t38, ptr %t39
  %t40 = load { i64, [5 x i64] }, ptr %t33
  store { i64, [5 x i64] } %t40, ptr %l5
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/lower:lowering", ptr %t42, i32 0, i32 0
  %t45 = load ptr, ptr %t44, !tbaa !29
  %t46 = load i32, ptr %l1, !tbaa !23
  store { i64, [1 x i64] } zeroinitializer, ptr %t47
  %t48 = getelementptr { i64, [1 x i64] }, ptr %t47, i32 0, i32 0
  store i64 2, ptr %t48
  %t50 = insertvalue { i32, i32 } undef, i32 3, 0
  %t52 = insertvalue { i32, i32 } %t50, i32 %t46, 1
  %t53 = getelementptr { i64, [1 x i64] }, ptr %t47, i32 0, i32 1
  store { i32, i32 } %t52, ptr %t53
  %t54 = load { i64, [1 x i64] }, ptr %t47
  call void @compiler_2flower_2ecompiler_2flower_3aLowerer_2eWant(ptr %v0, ptr %t45, { i64, [1 x i64] } %t54)
  br label %bb3
bb3:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/lower:lowering", ptr %t57, i32 0, i32 3
  %t61 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t59)
  store i32 %t61, ptr %l32
  br label %bb4
bb4:
  %t62 = load i32, ptr %l32, !tbaa !23
  store i32 %t62, ptr %l6, !tbaa !23
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t64 = load i32, ptr %l1, !tbaa !23
  %t65 = load %"compiler/source:Span", ptr %l2
  %t69 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2etemp(ptr %v0, ptr %t63, i32 %t64, %"compiler/source:Span" %t65)
  store i32 %t69, ptr %l36
  br label %bb5
bb5:
  %t70 = load i32, ptr %l36, !tbaa !23
  store i32 %t70, ptr %l7, !tbaa !23
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/lower:lowering", ptr %t71, i32 0, i32 3
  store ptr %t73, ptr %l38, !tbaa !29
  %t74 = load { i64, [5 x i64] }, ptr %l5
  store { i64, [5 x i64] } %t74, ptr %l39
  %t75 = load %"compiler/mir:Range", ptr @G_2ecompiler_2fmir_2eEmpty
  store %"compiler/mir:Range" %t75, ptr %l40
  %t76 = load ptr, ptr %l0, !tbaa !29
  store ptr %t76, ptr %l41, !tbaa !29
  %t77 = load ptr, ptr %l3, !tbaa !29
  %t78 = load { i64, [5 x i64] }, ptr %l5
  %t79 = load i32, ptr %l4, !tbaa !23
  %t83 = call i64 @compiler_2fmir_2ePassedCount(ptr %v0, ptr %t77, { i64, [5 x i64] } %t78, i32 %t79)
  store i64 %t83, ptr %l45
  br label %bb6
bb6:
  %t84 = load ptr, ptr %l41, !tbaa !29
  %t85 = load i64, ptr %l45, !tbaa !24
  %t86 = call %"compiler/mir:Range" @compiler_2flower_2ecompiler_2flower_3alowering_2epassed(ptr %v0, ptr %t84, i64 %t85, i32 -1)
  store %"compiler/mir:Range" %t86, ptr %l46
  br label %bb7
bb7:
  %t87 = load i32, ptr %l7, !tbaa !23
  %t89 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t87)
  store %"compiler/mir:Place" %t89, ptr %l48
  br label %bb8
bb8:
  %t90 = load i32, ptr %l6, !tbaa !23
  %t91 = load i32, ptr @G_2ecompiler_2fmir_2eNoLocal, !tbaa !23
  %t92 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t93 = load { i64, [5 x i64] }, ptr %l39
  %t94 = load %"compiler/mir:Range", ptr %l40
  %t95 = load %"compiler/mir:Range", ptr %l46
  %t96 = load %"compiler/mir:Place", ptr %l48
  %t100 = call %"compiler/mir:Call" @compiler_2fmir_3aCall_2ector(ptr %s0, { i64, [5 x i64] } %t93, %"compiler/mir:Range" %t94, %"compiler/mir:Range" %t95, %"compiler/mir:Place" %t96, i1 true, i32 %t90, i32 %t91, i32 %t92)
  store %"compiler/mir:Call" %t100, ptr %l52
  br label %bb9
bb9:
  %t101 = load ptr, ptr %l38, !tbaa !29
  %t102 = load %"compiler/mir:Call", ptr %l52
  %t103 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddCall(ptr %v0, ptr %t101, %"compiler/mir:Call" %t102)
  store i32 %t103, ptr %l53
  br label %bb10
bb10:
  %t104 = load i32, ptr %l53, !tbaa !23
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t106 = load %"compiler/source:Span", ptr %l2
  store { i64, [7 x i64] } zeroinitializer, ptr %t108
  %t109 = getelementptr { i64, [7 x i64] }, ptr %t108, i32 0, i32 0
  store i64 4, ptr %t109
  %t111 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t106, 0
  %t113 = insertvalue { %"compiler/source:Span", i32 } %t111, i32 %t104, 1
  %t114 = getelementptr { i64, [7 x i64] }, ptr %t108, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t113, ptr %t114
  %t115 = load { i64, [7 x i64] }, ptr %t108
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t105, { i64, [7 x i64] } %t115)
  br label %bb11
bb11:
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t119 = load i32, ptr %l6, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t118, i32 %t119)
  br label %bb12
bb12:
  %t122 = load i32, ptr %l7, !tbaa !23
  %t124 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t122)
  store %"compiler/mir:Place" %t124, ptr %l61
  br label %bb13
bb13:
  store { i64, [4 x i64] } zeroinitializer, ptr %t125
  %t126 = getelementptr { i64, [4 x i64] }, ptr %t125, i32 0, i32 0
  store i64 1, ptr %t126
  %t127 = load %"compiler/mir:Place", ptr %l61
  %t128 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t127, 0
  %t129 = getelementptr { i64, [4 x i64] }, ptr %t125, i32 0, i32 1
  store { %"compiler/mir:Place" } %t128, ptr %t129
  %t130 = load { i64, [4 x i64] }, ptr %t125
  call void @__olang_scope_close(ptr %s0)
  store { i64, [4 x i64] } %t130, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local ptr @compiler_2flower_2ederefOf(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i1
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca i1
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb17
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  store ptr %t16, ptr %l11, !tbaa !29
  store i1 false, ptr %l12, !tbaa !21
  %t17 = load ptr, ptr %l11, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb6, label %bb7
bb6:
  %t20 = load ptr, ptr %l11, !tbaa !29
  %t21 = load i64, ptr %t20
  %t23 = icmp eq i64 %t21, 2
  store i1 %t23, ptr %l12, !tbaa !21
  br label %bb7
bb7:
  %t24 = load i1, ptr %l12, !tbaa !21
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr { i64, [4 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t27, i32 0, i32 2
  %t29 = load ptr, ptr %t28
  store ptr %t29, ptr %l2, !tbaa !29
  br label %bb10
bb9:
  br label %bb11
bb10:
  %t31 = load ptr, ptr %l2, !tbaa !29
  store ptr %t31, ptr %l10, !tbaa !29
  br label %bb16
bb11:
  br i1 true, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  store ptr null, ptr %l10, !tbaa !29
  br label %bb16
bb15:
  call void @__olang_check_failed(ptr @olang_loc_eebb62a013643219_b45f662b48cacfad)
  unreachable
bb16:
  %t34 = load ptr, ptr %l10, !tbaa !29
  store ptr %t34, ptr %l3, !tbaa !29
  br label %bb22
bb17:
  br i1 true, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb21
bb20:
  store ptr null, ptr %l3, !tbaa !29
  br label %bb22
bb21:
  call void @__olang_check_failed(ptr @olang_loc_18ba96ebd2acdd48_1f3e7581818ceffc)
  unreachable
bb22:
  %t35 = load ptr, ptr %l3, !tbaa !29
  store ptr %t35, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i64 @compiler_2flower_2eindexOf(ptr %v0, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %a0, i32 %a1) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l9 = alloca i64
  %l13 = alloca i64
  %l16 = alloca i64
  %l36 = alloca i32
  %s2 = alloca %olang.scope
  %rv = alloca i64
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l2, !tbaa !24
  %t2 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %l0)
  store i64 %t2, ptr %l9
  br label %bb1
bb1:
  %t3 = load i64, ptr %l9, !tbaa !24
  store i64 %t3, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t4 = load i64, ptr %l3, !tbaa !24
  %t5 = load i64, ptr %l2, !tbaa !24
  %t8 = icmp sgt i64 %t4, %t5
  br i1 %t8, label %bb2, label %bb3
bb2:
  %t10 = load i64, ptr %l4, !tbaa !24
  %t12 = icmp sgt i64 %t10, 0
  br i1 %t12, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l13, !tbaa !24
  br label %bb7
bb4:
  %t14 = load i64, ptr %l3, !tbaa !24
  %t15 = load i64, ptr %l2, !tbaa !24
  %t18 = sub i64 %t14, %t15
  %t19 = load i64, ptr %l4, !tbaa !24
  %t22 = add i64 %t18, %t19
  %t24 = sub i64 %t22, 1
  %t25 = load i64, ptr %l4, !tbaa !24
  %t28 = sdiv i64 %t24, %t25
  store i64 %t28, ptr %l16, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l16, !tbaa !24
  br label %bb6
bb6:
  %t30 = load i64, ptr %l16, !tbaa !24
  store i64 %t30, ptr %l13, !tbaa !24
  br label %bb7
bb7:
  %t31 = load i64, ptr %l13, !tbaa !24
  store i64 %t31, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t32 = load i64, ptr %l6, !tbaa !24
  %t33 = load i64, ptr %l5, !tbaa !24
  %t36 = icmp slt i64 %t32, %t33
  %t38 = xor i1 %t36, true
  br i1 %t38, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb17
bb10:
  br label %bb11
bb11:
  %t40 = load i64, ptr %l2, !tbaa !24
  %t41 = load i64, ptr %l6, !tbaa !24
  %t42 = load i64, ptr %l4, !tbaa !24
  %t45 = mul i64 %t41, %t42
  %t48 = add i64 %t40, %t45
  store i64 %t48, ptr %l7, !tbaa !24
  %t50 = load i64, ptr %l7, !tbaa !24
  %t53 = call i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %l0, i64 %t50)
  store i32 %t53, ptr %l36
  br label %bb12
bb12:
  %t55 = load i32, ptr %l36, !tbaa !23
  %t57 = icmp eq i32 %t55, %a1
  br i1 %t57, label %bb13, label %bb14
bb13:
  %t59 = load i64, ptr %l7, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  store i64 %t59, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s2)
  br label %bb16
bb16:
  %t61 = load i64, ptr %l6, !tbaa !24
  %t63 = add i64 %t61, 1
  store i64 %t63, ptr %l6, !tbaa !24
  br label %bb8
bb17:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2flower_2eownLocalRead(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca ptr
  %l4 = alloca i1
  %l9 = alloca i1
  %l10 = alloca ptr
  %l11 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  store i1 false, ptr %l4, !tbaa !21
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l4, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l4, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb17
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  store ptr %t16, ptr %l10, !tbaa !29
  store i1 false, ptr %l11, !tbaa !21
  %t17 = load ptr, ptr %l10, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb6, label %bb7
bb6:
  %t20 = load ptr, ptr %l10, !tbaa !29
  %t21 = load i64, ptr %t20
  %t23 = icmp eq i64 %t21, 0
  store i1 %t23, ptr %l11, !tbaa !21
  br label %bb7
bb7:
  %t24 = load i1, ptr %l11, !tbaa !21
  br i1 %t24, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb11
bb10:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb16
bb11:
  br i1 true, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  store i1 false, ptr %l9, !tbaa !21
  br label %bb16
bb15:
  call void @__olang_check_failed(ptr @olang_loc_86d93a57d84efb3_c0ff465f65ac9e4f)
  unreachable
bb16:
  %t25 = load i1, ptr %l9, !tbaa !21
  store i1 %t25, ptr %l2, !tbaa !21
  br label %bb22
bb17:
  br i1 true, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb21
bb20:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb22
bb21:
  call void @__olang_check_failed(ptr @olang_loc_38cf040ca8694632_8fe136724d766e0e)
  unreachable
bb22:
  %t26 = load i1, ptr %l2, !tbaa !21
  store i1 %t26, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/typed:Body" @compiler_2flower_2estandIn(ptr %v0, i32 %a0) #0 {
entry:
  %l1 = alloca { i64, [2 x i64] }
  %l2 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca %"compiler/typed:Body"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/typed:Body"
  %t1 = alloca { i64, [2 x i64] }, align 8
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store { i64, [2 x i64] } zeroinitializer, ptr %t1
  %t2 = getelementptr { i64, [2 x i64] }, ptr %t1, i32 0, i32 0
  store i64 5, ptr %t2
  %t3 = insertvalue { i64 } undef, i64 -1, 0
  %t4 = getelementptr { i64, [2 x i64] }, ptr %t1, i32 0, i32 1
  store { i64 } %t3, ptr %t4
  %t5 = load { i64, [2 x i64] }, ptr %t1
  store { i64, [2 x i64] } %t5, ptr %l1
  store i32 %a0, ptr %l2, !tbaa !23
  %t7 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 0, i32 0)
  store %"compiler/source:Span" %t7, ptr %l3
  br label %bb1
bb1:
  %t8 = load { i64, [2 x i64] }, ptr %l1
  %t9 = load i32, ptr %l2, !tbaa !23
  %t10 = load %"compiler/source:Span", ptr %l3
  %t11 = call %"compiler/typed:Body" @compiler_2ftyped_3aBody_2ector(ptr %v0, i32 -1, { i64, [2 x i64] } %t8, i32 %t9, i64 0, %"compiler/source:Span" %t10)
  store %"compiler/typed:Body" %t11, ptr %l4
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  %t12 = load %"compiler/typed:Body", ptr %l4
  store %"compiler/typed:Body" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Body", ptr %rv
  ret %"compiler/typed:Body" %rr
}

define dso_local %"compiler/lower:Gap" @compiler_2flower_3aGap_2ector(ptr %v0, ptr %v1, i64 %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2) #0 {
entry:
  %rv = alloca %"compiler/lower:Gap"
  br label %start
start:
  br label %bb0
bb0:
  %t8 = insertvalue %"compiler/lower:Gap" undef, i64 %a0, 0
  %t10 = insertvalue %"compiler/lower:Gap" %t8, %"compiler/source:Span" %a1, 1
  %t12 = insertvalue %"compiler/lower:Gap" %t10, { i64, ptr } %a2, 2
  store %"compiler/lower:Gap" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/lower:Gap", ptr %rv
  ret %"compiler/lower:Gap" %rr
}

define dso_local %"compiler/lower:Lowerer" @compiler_2flower_3aLowerer_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l4 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l5 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l6 = alloca i1
  %l7 = alloca i1
  %l8 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l9 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l10 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l11 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l19 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l20 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l21 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l22 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l23 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l24 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l25 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"compiler/lower:Lowerer"
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a0, ptr %l2, !tbaa !29
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %a1, ptr %l3
  %t5 = load ptr, ptr @__olang_prog_scope
  %t6 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlan_3e(ptr %t5)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t6, ptr %l19
  br label %bb1
bb1:
  %t7 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l19
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t7, ptr %l4
  %t8 = load ptr, ptr @__olang_prog_scope
  %t9 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3aGap_3e(ptr %t8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t9, ptr %l20
  br label %bb2
bb2:
  %t10 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l20
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t10, ptr %l5
  store i1 false, ptr %l6, !tbaa !21
  store i1 false, ptr %l7, !tbaa !21
  %t11 = load ptr, ptr @__olang_prog_scope
  %t12 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e(ptr %t11)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t12, ptr %l21
  br label %bb3
bb3:
  %t13 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l21
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t13, ptr %l8
  %t14 = load ptr, ptr @__olang_prog_scope
  %t15 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aFnKey_3e(ptr %t14)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t15, ptr %l22
  br label %bb4
bb4:
  %t16 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l22
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t16, ptr %l9
  %t17 = load ptr, ptr @__olang_prog_scope
  %t18 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20Bool_3e(ptr %t17)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t18, ptr %l23
  br label %bb5
bb5:
  %t19 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l23
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t19, ptr %l10
  %t20 = load ptr, ptr @__olang_prog_scope
  %t21 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e(ptr %t20)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t21, ptr %l24
  br label %bb6
bb6:
  %t22 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l24
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t22, ptr %l11
  %t23 = load ptr, ptr @__olang_prog_scope
  %t24 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e(ptr %t23)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t24, ptr %l25
  br label %bb7
bb7:
  %t25 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l25
  %t26 = load ptr, ptr %l2, !tbaa !29
  %t27 = insertvalue %"compiler/lower:Lowerer" undef, ptr %t26, 0
  %t28 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l3
  %t29 = insertvalue %"compiler/lower:Lowerer" %t27, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t28, 1
  %t30 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l4
  %t31 = insertvalue %"compiler/lower:Lowerer" %t29, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t30, 2
  %t32 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l5
  %t33 = insertvalue %"compiler/lower:Lowerer" %t31, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t32, 3
  %t34 = load i1, ptr %l6, !tbaa !21
  %t35 = insertvalue %"compiler/lower:Lowerer" %t33, i1 %t34, 4
  %t36 = load i1, ptr %l7, !tbaa !21
  %t37 = insertvalue %"compiler/lower:Lowerer" %t35, i1 %t36, 5
  %t38 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l8
  %t39 = insertvalue %"compiler/lower:Lowerer" %t37, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t38, 6
  %t40 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l9
  %t41 = insertvalue %"compiler/lower:Lowerer" %t39, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t40, 7
  %t42 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l10
  %t43 = insertvalue %"compiler/lower:Lowerer" %t41, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t42, 8
  %t44 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l11
  %t45 = insertvalue %"compiler/lower:Lowerer" %t43, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t44, 9
  %t47 = insertvalue %"compiler/lower:Lowerer" %t45, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t25, 10
  %t49 = insertvalue %"compiler/lower:Lowerer" %t47, i1 false, 11
  %t51 = insertvalue %"compiler/lower:Lowerer" %t49, i32 -1, 12
  %t53 = insertvalue %"compiler/lower:Lowerer" %t51, i32 -1, 13
  %t55 = insertvalue %"compiler/lower:Lowerer" %t53, i32 -1, 14
  store %"compiler/lower:Lowerer" %t55, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/lower:Lowerer", ptr %rv
  ret %"compiler/lower:Lowerer" %rr
}

define dso_local %"compiler/lower:level" @compiler_2flower_3alevel_2ector(ptr %v0, i32 %a0, i32 %a1, i32 %a2) #0 {
entry:
  %rv = alloca %"compiler/lower:level"
  br label %start
start:
  br label %bb0
bb0:
  %t8 = insertvalue %"compiler/lower:level" undef, i32 %a0, 0
  %t10 = insertvalue %"compiler/lower:level" %t8, i32 %a1, 1
  %t12 = insertvalue %"compiler/lower:level" %t10, i32 %a2, 2
  store %"compiler/lower:level" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/lower:level", ptr %rv
  ret %"compiler/lower:level" %rr
}

define dso_local %"compiler/lower:pl" @compiler_2flower_3apl_2ector(ptr %v0, { i64, [2 x i64] } %a0) #0 {
entry:
  %l1 = alloca { i64, [2 x i64] }
  %l4 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"compiler/lower:pl"
  br label %start
start:
  br label %bb0
bb0:
  store { i64, [2 x i64] } %a0, ptr %l1
  %t3 = load ptr, ptr @__olang_prog_scope
  %t4 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aProj_3e(ptr %t3)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t4, ptr %l4
  br label %bb1
bb1:
  %t5 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l4
  %t6 = load { i64, [2 x i64] }, ptr %l1
  %t7 = insertvalue %"compiler/lower:pl" undef, { i64, [2 x i64] } %t6, 0
  %t9 = insertvalue %"compiler/lower:pl" %t7, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t5, 1
  store %"compiler/lower:pl" %t9, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/lower:pl", ptr %rv
  ret %"compiler/lower:pl" %rr
}

define dso_local %"compiler/lower:tryCtx" @compiler_2flower_3atryCtx_2ector(ptr %v0, ptr %v1, i64 %a0, { i64, ptr } %a1, i1 %a2, i1 %a3) #0 {
entry:
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca i1
  %l7 = alloca i1
  %l13 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"compiler/lower:tryCtx"
  br label %start
start:
  br label %bb0
bb0:
  store i64 %a0, ptr %l4, !tbaa !24
  store { i64, ptr } %a1, ptr %l5, !tbaa !27
  store i1 %a2, ptr %l6, !tbaa !21
  store i1 %a3, ptr %l7, !tbaa !21
  %t9 = load ptr, ptr @__olang_prog_scope
  %t10 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aBlockId_3e(ptr %t9)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t10, ptr %l13
  br label %bb1
bb1:
  %t11 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l13
  %t12 = load i64, ptr %l4, !tbaa !24
  %t13 = insertvalue %"compiler/lower:tryCtx" undef, i64 %t12, 0
  %t14 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t15 = insertvalue %"compiler/lower:tryCtx" %t13, { i64, ptr } %t14, 1
  %t16 = load i1, ptr %l6, !tbaa !21
  %t17 = insertvalue %"compiler/lower:tryCtx" %t15, i1 %t16, 2
  %t18 = load i1, ptr %l7, !tbaa !21
  %t19 = insertvalue %"compiler/lower:tryCtx" %t17, i1 %t18, 3
  %t21 = insertvalue %"compiler/lower:tryCtx" %t19, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t11, 4
  store %"compiler/lower:tryCtx" %t21, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/lower:tryCtx", ptr %rv
  ret %"compiler/lower:tryCtx" %rr
}

define dso_local void @olang_2einit_2ecompiler_2flower() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  call void @compiler_2flower_2eOutOfBounds_2einit()
  br label %bb1
bb1:
  call void @compiler_2flower_2eDivideByZero_2einit()
  br label %bb2
bb2:
  call void @compiler_2flower_2eOverflow_2einit()
  br label %bb3
bb3:
  call void @compiler_2flower_2eInvalid_2einit()
  br label %bb4
bb4:
  call void @compiler_2flower_2eWrongCase_2einit()
  br label %bb5
bb5:
  br label %ret
ret:
  ret void
}

declare void @__olang_check_failed(ptr)
@__olang_prog_scope = external thread_local(initialexec) global ptr
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

declare noalias ptr @__olang_scope_alloc_a(ptr, i64, i64)
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
chunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@.d0 = private constant [0 x i8] c""
@.d1 = private constant [0 x i8] c""
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
@.d2 = private constant [0 x i8] c""
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@.d3 = private constant [19 x i8] c"std/prelude/builtin"
@.d4 = private constant [12 x i8] c"BuiltinError"
@.d5 = private constant [16 x i8] c"std/prelude/text"
@.d6 = private constant [6 x i8] c"String"
@.d7 = private constant [43 x i8] c"an array literal of a type that is no array"
@.d8 = private constant [41 x i8] c"a constructor of a type that is no struct"
@.d9 = private constant [15 x i8] c"unhandled error"
@.d10 = private constant [0 x i8] c""
@.d11 = private constant [11 x i8] c"std/prelude"
@.d12 = private constant [1 x i8] c"/"
@.d13 = private constant [1 x i8] c"."
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
@.d14 = private constant [1 x i8] c"."
@.d15 = private constant [51 x i8] c"a comprehension of a type that is no run-time array"
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aBlockId_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fmir_3aBlockId_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3alevel_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2flower_3alevel_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

@.d16 = private constant [38 x i8] c"a jump out of a loop not being lowered"
define linkonce_odr i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fmir_3aScopeRef(ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca i64
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %t1
  store i64 %t2, ptr %l3, !tbaa !24
  %t3 = load ptr, ptr %l1, !tbaa !29
  %t4 = load i64, ptr %t3
  %t5 = load i64, ptr %l3, !tbaa !24
  %t7 = icmp eq i64 %t5, %t4
  br i1 %t7, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb10
bb2:
  %t9 = load i64, ptr %l3, !tbaa !24
  switch i64 %t9, label %bb3 [ i64 0, label %bb4 i64 1, label %bb5 i64 4, label %bb6 ]
bb3:
  br label %bb10
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr { i64, [1 x i64] }, ptr %t10, i32 0, i32 1
  %t12 = getelementptr { i32 }, ptr %t11, i32 0, i32 0
  %t13 = load i32, ptr %t12
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t15 = getelementptr { i64, [1 x i64] }, ptr %t14, i32 0, i32 1
  %t16 = getelementptr { i32 }, ptr %t15, i32 0, i32 0
  %t17 = load i32, ptr %t16
  %t20 = icmp eq i32 %t13, %t17
  br i1 %t20, label %bb7, label %bb1
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr { i64, [1 x i64] }, ptr %t22, i32 0, i32 1
  %t24 = getelementptr { i64 }, ptr %t23, i32 0, i32 0
  %t25 = load i64, ptr %t24
  %t26 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr { i64, [1 x i64] }, ptr %t26, i32 0, i32 1
  %t28 = getelementptr { i64 }, ptr %t27, i32 0, i32 0
  %t29 = load i64, ptr %t28
  %t32 = icmp eq i64 %t25, %t29
  br i1 %t32, label %bb8, label %bb1
bb6:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr { i64, [1 x i64] }, ptr %t34, i32 0, i32 1
  %t36 = getelementptr { i32 }, ptr %t35, i32 0, i32 0
  %t37 = load i32, ptr %t36
  %t38 = load ptr, ptr %l1, !tbaa !29
  %t39 = getelementptr { i64, [1 x i64] }, ptr %t38, i32 0, i32 1
  %t40 = getelementptr { i32 }, ptr %t39, i32 0, i32 0
  %t41 = load i32, ptr %t40
  %t44 = icmp eq i32 %t37, %t41
  br i1 %t44, label %bb9, label %bb1
bb7:
  br label %bb3
bb8:
  br label %bb3
bb9:
  br label %bb3
bb10:
  %t46 = load i1, ptr %l2, !tbaa !21
  store i1 %t46, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d17 = private constant [2 x i8] c", "
@.d18 = private constant [4 x i8] c"mut "
@.d19 = private constant [0 x i8] c""
@.d20 = private constant [1 x i8] c"&"
@.d21 = private constant [6 x i8] c"Array<"
@.d22 = private constant [1 x i8] c">"
declare i64 @__olang_fmt_i64(ptr, i64)
@.d23 = private constant [2 x i8] c", "
@.d24 = private constant [2 x i8] c"fn"
@.d25 = private constant [2 x i8] c", "
@.d26 = private constant [1 x i8] c" "
@.d27 = private constant [2 x i8] c", "
@.d28 = private constant [1 x i8] c" "
@.d29 = private constant [1 x i8] c" "
@.d30 = private constant [2 x i8] c" ?"
@.d31 = private constant [2 x i8] c", "
@.d32 = private constant [1 x i8] c" "
@.d33 = private constant [2 x i8] c"U8"
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlan_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlan_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3aGap_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2flower_3aGap_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e_2ector(ptr %t1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aFnKey_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fmir_3aFnKey_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20Bool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20Bool_3e_2ector(ptr %t1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e_2ector(ptr %t1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aProj_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fmir_3aProj_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
@G_2ecompiler_2flower_2eInvalid = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2flower_2eWrongCase = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00" }>, align 8
declare ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_daa9f23a83841987_24921124063ad36b = external constant [0 x i8]
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_Ha6bcf4d517e3d7b46809e1dbf938da91(ptr %v0, ptr %a0)
declare i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eHas_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_e3721461a855ef35_c24433bc0ae5f641 = external constant [0 x i8]
declare void @compiler_2fmir_3aFn_2ector(ptr %out, ptr %v0, { i64, [1 x i64] } %a0, i32 %a1, i64 %a2, %"compiler/source:Span" %a3)
declare void @compiler_2flower_3alowering_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, ptr %a2, ptr %a3)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlan_3e_2eLen_3ccompiler_2ftyped_3aPlan_3e(ptr %v0, ptr %a0)
declare %"compiler/typed:Plan" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlan_3e_2eAt_3ccompiler_2ftyped_3aPlan_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2erun(ptr %v0, ptr %a0)
declare void @compiler_2flower_2ecompiler_2flower_3aLowerer_2eLowerKey(ptr %out, ptr %v0, ptr %v1, ptr %a0, { i64, [1 x i64] } %a1)
declare { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3aFn_2eVerify(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3aFn_2eDump(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_4e4c17ebfaf5d7b6_624a73934957b6f2 = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i32 %a3, i32 %a4, i64 %a5)
declare void @compiler_2flower_2ecompiler_2flower_3aLowerer_2ebare(ptr %out, ptr %v0, ptr %v1, ptr %a0, { i64, [1 x i64] } %a1, i32 %a2)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2eadapterBody(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i32 %a3)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ePreludeType(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eUnnamed(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2fmir_2eNoLocal = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\FF\FF\FF\FF" }>, align 8
declare { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %a0)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3alevel_3e_2eLen_3ccompiler_2flower_3alevel_3e(ptr %v0, ptr %a0)
declare %"compiler/lower:level" @compiler_2flower_2ecompiler_2flower_3alowering_2etop(ptr %v0, ptr %a0)
@olang_loc_2262f7260befbeda_ad33d1a86099f68e = external constant [0 x i8]
@olang_loc_78466967dd42e061_bdc585e3e8213235 = external constant [0 x i8]
@olang_loc_6143a96035d3ceac_ef612191f7538720 = external constant [0 x i8]
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2eopenBlock(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, i32 %a3)
@olang_loc_9919e1798def049b_eb223155b689b93f = external constant [0 x i8]
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2ecloseBlock(ptr %v0, ptr %a0)
declare i32 @compiler_2flower_2ecompiler_2flower_3alowering_2elocal(ptr %v0, ptr %a0, { i64, [4 x i64] } %a1, i32 %a2, %"compiler/source:Span" %a3)
@G_2ecompiler_2fmir_2eI64T = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\06\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eUnknownT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
declare i64 @compiler_2flower_2ecompiler_2flower_3alowering_2efixedLen(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eArgs(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/mir:Place" @compiler_2fmir_2ecompiler_2fmir_3aFn_2ePlace(ptr %v0, ptr %v1, ptr %a0, { i64, [2 x i64] } %a1, { i64, ptr } %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eBoolT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
declare i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %a0)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %a0, { i64, [7 x i64] } %a1)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2egoto(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2eleave(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_b4f44bfc4c4e49f2_17d18a81dcc1f1de = external constant [0 x i8]
declare { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einstance(ptr %v0, ptr %a0)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDestructs(ptr %v0, ptr %a0, i32 %a1)
declare %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %v0, i64 %a0, i64 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2etextData(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, %"compiler/source:Span" %a2)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fmir_3aOperand_3e_2ector(ptr %v0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %a0, i32 %a1)
declare ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindLast(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_1b3f3d8cac740dce_641dfb8cea384ff2 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorWords(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2fmir_2eI32T = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\05\00\00\00" }>, align 8
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aOperand_3e_2ePush_3ccompiler_2fmir_3aOperand_3e(ptr %v0, ptr %a0, { i64, [4 x i64] } %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aOperand_3e_2eToArray_3ccompiler_2fmir_3aOperand_3e(ptr %v0, ptr %v1, ptr %a0)
declare { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2escopeRef(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1)
declare %"compiler/mir:Range" @compiler_2flower_2ecompiler_2flower_3alowering_2eargs(ptr %v0, ptr %v1, ptr %a0, ptr %a1, { i64, [5 x i64] } %a2, i32 %a3)
declare i64 @compiler_2fmir_2ePassedCount(ptr %v0, ptr %a0, { i64, [5 x i64] } %a1, i32 %a2)
@G_2ecompiler_2ftypes_2eVoidT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
@G_2ecompiler_2ftypes_2eNoreturnT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\11\00\00\00" }>, align 8
@G_2ecompiler_2fmir_2eNoBlock = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\FF\FF\FF\FF" }>, align 8
@G_2ecompiler_2fmir_2eNoPlace = available_externally constant <{ [32 x i8] }> <{ [32 x i8] c"\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00" }>, align 32
declare %"compiler/mir:Call" @compiler_2fmir_3aCall_2ector(ptr %v0, { i64, [5 x i64] } %a0, %"compiler/mir:Range" %a1, %"compiler/mir:Range" %a2, %"compiler/mir:Place" %a3, i1 %a4, i32 %a5, i32 %a6, i32 %a7)
declare i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddCall(ptr %v0, ptr %a0, %"compiler/mir:Call" %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %a0, i64 %a1)
declare { { i64, [5 x i64] }, i32 } @compiler_2flower_2ecompiler_2flower_3alowering_2evalueCallee(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_21e9da82ebd620c7_b6074e807b9f75fb = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeCases(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_3b8f4ce72bb8c828_c6f22e3cb9711da4 = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList1(ptr %v0, ptr %a0, i32 %a1)
declare i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aBlockId_3e_2eAt_3ccompiler_2fmir_3aBlockId_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aBlockId_3e_2ePush_3ccompiler_2fmir_3aBlockId_3e(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_ed4966d7257d1cce_314b285230575e82 = external constant [0 x i8]
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2eblock(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_4fc14cddf040b63b_d4edc892d8598fd7 = external constant [0 x i8]
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2eleaveOpen(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeId_3e_2eAt_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeId_3e_2eSetAt_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aBlock_26_3e_2eAt_Hef81d01aee8891fe569e7a3039d88992(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArray(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
@G_2ecompiler_2ftypes_2eWritable = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
@olang_loc_162f2c5d450ff5be_60a02040feb29ca2 = external constant [0 x i8]
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v0, ptr %a0)
declare { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2easI64(ptr %v0, ptr %a0, { i64, [4 x i64] } %a1, i32 %a2, %"compiler/source:Span" %a3)
@G_2ecompiler_2flower_2eOutOfBounds = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare %"compiler/lower:collectCtx" @compiler_2flower_3acollectCtx_2ector(ptr %v0, i32 %a0, i32 %a1, i32 %a2, i32 %a3, { i64, [1 x i64] } %a4)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3acollectCtx_3e_2e_H653cfca5a0404061ead7e6ea50e2c820(ptr %v0, ptr %a0, %"compiler/lower:collectCtx" %a1)
declare { i32, %"compiler/lower:collectCtx" } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3acollectCtx_3e_2e_Hcb64b7cee1ab394e20e0c0dd5741806d(ptr %v0, ptr %a0)
@olang_loc_1b831ae1fe8ac0a9_779ca48b185ae2e5 = external constant [0 x i8]
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3atryCtx_3e_2eLen_3ccompiler_2flower_3atryCtx_3e(ptr %v0, ptr %a0)
declare %"compiler/lower:tryCtx" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3atryCtx_3e_2eAt_3ccompiler_2flower_3atryCtx_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
@olang_loc_c6e2ba3cedb073a3_23085f6ef83cda97 = external constant [0 x i8]
declare %"compiler/lower:level" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3alevel_3e_2eAt_3ccompiler_2flower_3alevel_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i32, %"compiler/lower:level" } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3alevel_3e_2ePop_3ccompiler_2flower_3alevel_3e(ptr %v0, ptr %a0)
@olang_loc_831aef8878f0c239_4d65f3dd2c1f4c9d = external constant [0 x i8]
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3alevel_3e_2ePush_3ccompiler_2flower_3alevel_3e(ptr %v0, ptr %a0, %"compiler/lower:level" %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aBlock_26_3e_2eLe_H8743fc75fe5cead0bda2da42e1adf3f3(ptr %v0, ptr %a0)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_53acd22e8270d268_dadfa79394a107ec = external constant [0 x i8]
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/typed:BlockInfo" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aBlockInfo_3e_2eA_Hdb91c1ab6f912bb6141763aa02d0b766(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_13daf6ec8e30e943_ad19332534c71267 = external constant [0 x i8]
@olang_loc_d7de50d0c280a1c2_f8c3e581c8870786 = external constant [0 x i8]
declare %"compiler/mir:ScopeInfo" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeInfo_3e_2eAt_3ccompiler_2fmir_3aScopeInfo_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2ejoinFailed(ptr %v0, ptr %a0, i64 %a1, i32 %a2, { i64, [4 x i64] } %a3, i32 %a4, %"compiler/source:Span" %a5)
declare { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2econstBool(ptr %v0, ptr %a0, i1 %a1, %"compiler/source:Span" %a2)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3aGap_3e_2ePush_3ccompiler_2flower_3aGap_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/lower:Gap" %a1)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2eprologue(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2eat(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eequalAt(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/lower:pl" %a1, %"compiler/lower:pl" %a2, i32 %a3, %"compiler/source:Span" %a4, i1 %a5)
declare { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ehashAt(ptr %v0, ptr %v1, ptr %a0, %"compiler/lower:pl" %a1, i32 %a2, %"compiler/source:Span" %a3, i1 %a4)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopeVarsOf(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ezeroOf(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2erenderAt(ptr %v0, ptr %v1, ptr %a0, %"compiler/lower:pl" %a1, i32 %a2, { i64, [1 x i64] } %a3, %"compiler/source:Span" %a4, i1 %a5)
@olang_loc_30767a805df234bd_503f920f410b6239 = external constant [0 x i8]
declare i32 @compiler_2fmir_2eHelperType(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare void @compiler_2flower_2ecompiler_2flower_3aLowerer_2eWant(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1)
declare %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eScopeRefs(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eisText(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2flower_2ecompiler_2flower_3alowering_2ehasStr(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2flower_2ecompiler_2flower_3aLowerer_2echar(ptr %v0, ptr %a0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_fe6f132f471090d8_e27fa787bcbe9484 = external constant [0 x i8]
declare i32 @compiler_2flower_2ecompiler_2flower_3alowering_2ejoinErrors(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3atryCtx_3e_2ePush_3ccompiler_2flower_3atryCtx_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/lower:tryCtx" %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeId_3e_2ePush_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %a0, i32 %a1)
declare { i32, %"compiler/lower:tryCtx" } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3atryCtx_3e_2ePop_3ccompiler_2flower_3atryCtx_3e(ptr %v0, ptr %v1, ptr %a0)
declare { i32, i32 } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeId_3e_2ePop_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3aloopCtx_3e_2eLen_3ccompiler_2flower_3aloopCtx_3e(ptr %v0, ptr %a0)
declare %"compiler/lower:loopCtx" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3aloopCtx_3e_2eAt_3ccompiler_2flower_3aloopCtx_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"compiler/lower:loopCtx" @compiler_2flower_3aloopCtx_2ector(ptr %v0, i32 %a0, i64 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3aloopCtx_3e_2ePus_Hecf1f3338ace0b99f129de91c7b21562(ptr %v0, ptr %v1, ptr %a0, %"compiler/lower:loopCtx" %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aBlockId_3e_2eLen_3ccompiler_2fmir_3aBlockId_3e(ptr %v0, ptr %a0)
declare { i32, %"compiler/lower:loopCtx" } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3aloopCtx_3e_2ePop_3ccompiler_2flower_3aloopCtx_3e(ptr %v0, ptr %v1, ptr %a0)
declare { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2efill(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3)
@olang_loc_c00faf6434efe24b_96f261c8870620df = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aProj_3e_2eToArray_3ccompiler_2fmir_3aProj_3e(ptr %v0, ptr %v1, ptr %a0)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_He36936f29a17adf60cb2ecc49df5337f(ptr %v0, ptr %a0)
@olang_loc_279896acdd8c6bde_4c10668047ad718a = external constant [0 x i8]
declare { i64, [1 x i64] } @compiler_2ftyped_2ecompiler_2ftyped_3aPlan_2ePassed(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aBlockId_3e_2eRunFrom_3ccompiler_2fmir_3aBlockId_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_678a134ca8e67a35_be411b19d54605f9 = external constant [0 x i8]
declare void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eEnd(ptr %v0, ptr %a0, i32 %a1, { i64, [7 x i64] } %a2)
declare %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2eplace(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
@G_2ecompiler_2ftypes_2eReadOnly = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
@olang_loc_eff9370fb6cf39b1_ff4f9c232720af7d = external constant [0 x i8]
@olang_loc_4fc653f117519a1d_d526ff90513f5371 = external constant [0 x i8]
@olang_loc_f5162d6fd39a8c0b_7722e13858f6fdef = external constant [0 x i8]
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %a0, i32 %a1)
declare { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2edepth(ptr %v0, ptr %a0)
@olang_loc_ddcb411f232bf43e_ce3417657830a5fa = external constant [0 x i8]
@olang_loc_ecde87765d07009c_52dfe83edba10a08 = external constant [0 x i8]
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3alevel_3e_2eRunFrom_3ccompiler_2flower_3alevel_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_2e0d72be7b5575d7_214712821f524de3 = external constant [0 x i8]
declare %"compiler/mir:Local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aLocal_3e_2eAt_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eresultScope(ptr %v0, ptr %a0)
@olang_loc_4b16c1f6667ae236_8522eea6e5c16fe2 = external constant [0 x i8]
@olang_loc_d0e8b819f5194451_9afcdf330b6f59b5 = external constant [0 x i8]
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNumber(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %a0, i32 %a1)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %a0, i8 %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstValue(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNamesOf(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare %"compiler/typed:Local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2efit(ptr %v0, ptr %v1, ptr %a0, { i64, [4 x i64] } %a1, ptr %a2, i32 %a3, %"compiler/source:Span" %a4)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3apl_3e_2ePush_3ccompiler_2flower_3apl_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/lower:pl" %a1)
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aPlace_2eType(ptr %v0, ptr %a0)
declare { i32, %"compiler/lower:pl" } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3apl_3e_2ePop_3ccompiler_2flower_3apl_3e(ptr %v0, ptr %v1, ptr %a0)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2eifStmt(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2eret(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare i64 @compiler_2fmir_2eErrorCode(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i64 %a3)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aBlock_26_3e_2ePu_H0a6921d1f6104d156ffed3729e33edeb(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2espawn(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2eyield(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
@olang_loc_b7b09248cda006f_e3ce57a596777ddb = external constant [0 x i8]
declare i32 @compiler_2flower_2ecompiler_2flower_3alowering_2etaskType(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eRunF_H9c1707946c43ec840ffe1821bea89b1f(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_7b1a9423057e34c5_261f06cd9be6d659 = external constant [0 x i8]
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_4d2a900631880414_3719f57230f55c88 = external constant [0 x i8]
declare i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddTemp(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aBlockId_3e_2eSetAt_3ccompiler_2fmir_3aBlockId_3e(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
@olang_loc_73384406ab4916da_7af5324ba56268d6 = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %a0, i32 %a1)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aProj_3e_2eRunFrom_3ccompiler_2fmir_3aProj_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_e4cb0830a37b0e81_73b8c395fe92f955 = external constant [0 x i8]
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aProj_3e_2ePush_3ccompiler_2fmir_3aProj_3e(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1)
@olang_loc_683e5e170631bc0e_4d1425fdf2d9aa22 = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddConst(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@G_2ecompiler_2fmir_2eEmpty = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
@olang_loc_eebb62a013643219_b45f662b48cacfad = external constant [0 x i8]
@olang_loc_18ba96ebd2acdd48_1f3e7581818ceffc = external constant [0 x i8]
@olang_loc_86d93a57d84efb3_c0ff465f65ac9e4f = external constant [0 x i8]
@olang_loc_38cf040ca8694632_8fe136724d766e0e = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %a0, i32 %a1)
declare %"compiler/typed:Body" @compiler_2ftyped_3aBody_2ector(ptr %v0, i32 %a0, { i64, [2 x i64] } %a1, i32 %a2, i64 %a3, %"compiler/source:Span" %a4)
declare void @compiler_2flower_2eOutOfBounds_2einit()
declare void @compiler_2flower_2eDivideByZero_2einit()
declare void @compiler_2flower_2eOverflow_2einit()
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fmir_3aBlockId_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2flower_3alevel_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlan_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2flower_3aGap_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fmir_3aFnKey_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20Bool_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fmir_3aProj_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
