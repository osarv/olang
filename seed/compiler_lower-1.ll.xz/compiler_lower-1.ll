; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr, i64, ptr }
%olang.home = type { ptr, ptr }
%olang.slotscope = type { %olang.scope, i64, [8 x ptr] }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/lower:Lowerer" = type { ptr, ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"compiler/typed:Plan", ptr, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, i1, i1, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i32, i32, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i64, i64, i64, i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/typed:RefsKept", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"compiler/mir:GenInfo", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64 }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"compiler/typed:Plan" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i64, i64 }
%"compiler/typed:RefsKept" = type { %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/mir:GenInfo" = type { %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/generic:Program" = type { ptr, ptr, %"compiler/types:Table", %"compiler/facts:Table", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"compiler/generic:Origin", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/types:Table" = type { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/facts:Table" = type { %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i64 }
%"compiler/generic:Origin" = type { i64, %"compiler/source:Span", i64, i32 }
%"compiler/typed:Body" = type { i32, { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i32, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/load:Loader" = type { { i64, ptr }, ptr, ptr, ptr, ptr, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/typed:LocalUses" = type { ptr, ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i64, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i32, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i64, i64, i64, i32, i1, i1 }
%"compiler/load:Module" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i64, i1, ptr, ptr, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr, i1, i64, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr, ptr, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/typed:Make" = type { i32, i64, { i64, ptr }, ptr, i32, i32, i1 }
%"compiler/typed:Call" = type { ptr, { i64, ptr }, i32, i1, i1 }
%"compiler/typed:Promote" = type { ptr, i32 }
%"compiler/typed:Local" = type { i32, %"compiler/source:Span", i32, i32, i32, { i64, [1 x i64] }, i1, i1 }
%"compiler/typed:Cond" = type { ptr, ptr, ptr }
%"compiler/typed:Seq" = type { { i64, ptr }, ptr, i1 }
%"compiler/typed:Block" = type { i32, { i64, ptr } }
%"compiler/lower:handWalk" = type { ptr, ptr, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i64 }
%"compiler/typed:Elem" = type { ptr, ptr, i32 }
%"compiler/typed:Payload" = type { ptr, i64, i32 }
%"compiler/mir:Lvalue" = type { { i64, [2 x i64] }, %"compiler/mir:Range" }
%"compiler/mir:Range" = type { i32, i32 }
%"compiler/lower:lowering" = type { ptr, ptr, ptr, %"compiler/mir:Fn", i32, i32, i32, i64, i64, %"compiler/source:Span", { i64, [4 x i64] }, i32, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, i1, i1, i64, i64, i64, i32, i32, { i64, [1 x i64] }, ptr, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i32, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/typed:DropHolding", i1, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i32, i64, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/mir:Fn" = type { { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i64, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/typed:DropHolding" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/lower:pl" = type { { i64, [2 x i64] }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i32 }
%"compiler/free:Free" = type { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, i64, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { ptr, ptr }, { ptr, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/typed:RefsKept", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"compiler/mir:GenInfo", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i1, i1, i64, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/typed:BlockInfo" = type { i32, i32, %"compiler/source:Span" }
%"compiler/lower:Gap" = type { i64, %"compiler/source:Span", { i64, ptr } }
%"compiler/mir:Call" = type { { i64, [7 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/mir:Lvalue", i1, i32, i32, i32 }
%"compiler/lower:hoistWalk" = type { i64, i1, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, [4 x i64] }, { i64, [4 x i64] }, { i64, [4 x i64] } }
%"compiler/mir:BasicBlock" = type { %"compiler/mir:StmtList", { i64, [8 x i64] } }
%"compiler/mir:StmtList" = type { { i64, ptr }, i64 }
%"compiler/lower:liveness" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i64, { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/typed:Match" = type { { i64, ptr }, { i64, ptr }, ptr, i1 }
%"compiler/typed:Arm" = type { %"compiler/source:Span", { i64, ptr }, ptr, ptr, ptr }
%"compiler/lower:level" = type { i32, i32, i32 }
%"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" = type { i64, i64 }
%"compiler/typed:Try" = type { ptr, { i64, ptr }, i1, i1, i1 }
%"compiler/typed:Clause" = type { %"compiler/source:Span", { i64, ptr }, i1, ptr, { i64, ptr }, i64, i32 }
%"compiler/typed:If" = type { ptr, ptr, ptr }
%"compiler/typed:Slice" = type { ptr, ptr, ptr, i32 }
%"compiler/mir:Local" = type { i32, %"compiler/source:Span", i32, i32, { i64, [1 x i64] } }
%"compiler/lower:CloneSite" = type { { i64, [2 x i64] }, i64, { i64, [2 x i64] }, i32 }
%"compiler/lower:affineSum" = type { { i64, [4 x i64] }, { i64, [4 x i64] }, i1 }
%"compiler/lower:relPath" = type { i64, { i64, ptr }, i1, i1, i64, i64, i32, i64 }
%"compiler/lower:tryCtx" = type { i64, { i64, ptr }, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
define dso_local ptr @compiler_2flower_2eawayless(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i1
  %l10 = alloca ptr
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  store i1 false, ptr %l4, !tbaa !21
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 17
  store i1 %t8, ptr %l4, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l4, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = call ptr @compiler_2flower_2eawayless(ptr %v0, ptr %v0, ptr %t16)
  store ptr %t18, ptr %l10
  br label %bb6
bb6:
  %t19 = load ptr, ptr %l10, !tbaa !29
  store ptr %t19, ptr %l2, !tbaa !29
  br label %bb12
bb7:
  br i1 true, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb11
bb10:
  %t20 = load ptr, ptr %l0, !tbaa !29
  store ptr %t20, ptr %l2, !tbaa !29
  br label %bb12
bb11:
  call void @__olang_check_failed(ptr @olang_loc_6ad7887f3088cd5b_7cbfc32661adbb3f)
  unreachable
bb12:
  %t22 = load ptr, ptr %l2, !tbaa !29
  store ptr %t22, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3aLowerer_2eDecideBuilds(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca i64
  %l6 = alloca i64
  %l8 = alloca i64
  %l13 = alloca i64
  %l16 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a1, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t3 = load i64, ptr %l3, !tbaa !24
  store i64 %t3, ptr %l6, !tbaa !24
  %t4 = load ptr, ptr %l2, !tbaa !29
  %t6 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t4)
  store i64 %t6, ptr %l8
  br label %bb2
bb2:
  %t7 = load i64, ptr %l6, !tbaa !24
  %t8 = load i64, ptr %l8, !tbaa !24
  %t9 = icmp slt i64 %t7, %t8
  %t11 = xor i1 %t9, true
  br i1 %t11, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb9
bb4:
  br label %bb5
bb5:
  %t13 = load ptr, ptr %l2, !tbaa !29
  %t14 = load i64, ptr %l3, !tbaa !24
  %t17 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t13, i64 %t14)
  store i64 %t17, ptr %l13
  br label %bb6
bb6:
  %t18 = load i64, ptr %l13, !tbaa !24
  %t23 = call { i64, ptr } @compiler_2flower_2ecompiler_2flower_3aLowerer_2ebuildsFact(ptr %v0, ptr %s2, ptr %a0, i64 %t18)
  store { i64, ptr } %t23, ptr %l16
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s2)
  br label %bb8
bb8:
  %t24 = load i64, ptr %l3, !tbaa !24
  %t27 = add i64 %t24, 1
  store i64 %t27, ptr %l3, !tbaa !24
  br label %bb1
bb9:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3aLowerer_2eDecideDerived(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l10 = alloca i64
  %l14 = alloca i64
  %l17 = alloca i64
  %l37 = alloca { i64, ptr }
  %l39 = alloca i1
  %l43 = alloca ptr
  %l44 = alloca { i64, ptr }
  %l48 = alloca ptr
  %l51 = alloca i64
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l1, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:Lowerer", ptr %t1, i32 0, i32 2
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlan_3e_2eLen_3ccompiler_2ftyped_3aPlan_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l10
  br label %bb1
bb1:
  %t6 = load i64, ptr %l10, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  store i64 1, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l2, !tbaa !24
  %t8 = load i64, ptr %l1, !tbaa !24
  %t11 = icmp sgt i64 %t7, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load i64, ptr %l3, !tbaa !24
  %t15 = icmp sgt i64 %t13, 0
  br i1 %t15, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l14, !tbaa !24
  br label %bb7
bb4:
  %t17 = load i64, ptr %l2, !tbaa !24
  %t18 = load i64, ptr %l1, !tbaa !24
  %t21 = sub i64 %t17, %t18
  %t22 = load i64, ptr %l3, !tbaa !24
  %t25 = add i64 %t21, %t22
  %t27 = sub i64 %t25, 1
  %t28 = load i64, ptr %l3, !tbaa !24
  %t31 = sdiv i64 %t27, %t28
  store i64 %t31, ptr %l17, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l17, !tbaa !24
  br label %bb6
bb6:
  %t33 = load i64, ptr %l17, !tbaa !24
  store i64 %t33, ptr %l14, !tbaa !24
  br label %bb7
bb7:
  %t34 = load i64, ptr %l14, !tbaa !24
  store i64 %t34, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t35 = load i64, ptr %l5, !tbaa !24
  %t36 = load i64, ptr %l4, !tbaa !24
  %t39 = icmp slt i64 %t35, %t36
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb21
bb10:
  br label %bb11
bb11:
  %t43 = load i64, ptr %l1, !tbaa !24
  %t44 = load i64, ptr %l5, !tbaa !24
  %t45 = load i64, ptr %l3, !tbaa !24
  %t48 = mul i64 %t44, %t45
  %t51 = add i64 %t43, %t48
  store i64 %t51, ptr %l6, !tbaa !24
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t54 = load i64, ptr %l6, !tbaa !24
  %t57 = call { i64, ptr } @compiler_2flower_2ecompiler_2flower_3aLowerer_2ederivedFact(ptr %v0, ptr %s2, ptr %t53, i64 %t54)
  store { i64, ptr } %t57, ptr %l37
  br label %bb12
bb12:
  %t58 = load { i64, ptr }, ptr %l37, !tbaa !27
  store { i64, ptr } %t58, ptr %l7, !tbaa !27
  %t59 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t61 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s2, ptr %s2, { i64, ptr } %t59, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d0, i32 0, i32 1) })
  store i1 %t61, ptr %l39
  br label %bb13
bb13:
  %t62 = load i1, ptr %l39, !tbaa !21
  %t63 = xor i1 %t62, true
  br i1 %t63, label %bb14, label %bb15
bb14:
  store %olang.scope zeroinitializer, ptr %s3
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/lower:Lowerer", ptr %t65, i32 0, i32 0
  %t68 = load ptr, ptr %t67, !tbaa !29
  %t70 = getelementptr %"compiler/generic:Program", ptr %t68, i32 0, i32 3
  store ptr %t70, ptr %l43, !tbaa !29
  %t71 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t71, ptr %l44, !tbaa !27
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t74 = getelementptr %"compiler/lower:Lowerer", ptr %t72, i32 0, i32 2
  %t75 = load i64, ptr %l6, !tbaa !24
  %t78 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlan_3e_2eRef_3ccompiler_2ftyped_3aPlan_3e(ptr %v0, ptr %v0, ptr %t74, i64 %t75)
  store ptr %t78, ptr %l48
  br label %bb16
bb15:
  br label %bb19
bb16:
  %t79 = load ptr, ptr %l48, !tbaa !29
  %t81 = getelementptr %"compiler/typed:Plan", ptr %t79, i32 0, i32 17
  %t83 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t81)
  store i64 %t83, ptr %l51
  br label %bb17
bb17:
  %t84 = load i64, ptr %l51, !tbaa !24
  %t85 = call i64 @__olang_fmt_i64(ptr null, i64 %t84)
  %t86 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t85)
  %t87 = call i64 @__olang_fmt_i64(ptr %t86, i64 %t84)
  %t88 = insertvalue { i64, ptr } undef, i64 %t85, 0
  %t89 = insertvalue { i64, ptr } %t88, ptr %t86, 1
  %t91 = load ptr, ptr %l43, !tbaa !29
  %t92 = load { i64, ptr }, ptr %l44, !tbaa !27
  call void @compiler_2ffacts_2ecompiler_2ffacts_3aTable_2eDecide(ptr %v0, ptr %s2, ptr %s3, ptr %t91, { i64, ptr } %t92, { i64, ptr } %t89, i1 false)
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s3)
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s2)
  br label %bb20
bb20:
  %t94 = load i64, ptr %l5, !tbaa !24
  %t97 = add i64 %t94, 1
  store i64 %t97, ptr %l5, !tbaa !24
  br label %bb8
bb21:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2flower_2ecompiler_2flower_3aLowerer_2eDerivedN(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [2 x i64] }
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca i64
  %l9 = alloca i64
  %l12 = alloca i64
  %l14 = alloca i64
  %l19 = alloca ptr
  %l22 = alloca i64
  %l26 = alloca i64
  %l29 = alloca i64
  %l31 = alloca i64
  %l35 = alloca ptr
  %l38 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store { i64, [2 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [2 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [2 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { i32 }, ptr %t6, i32 0, i32 0
  %t8 = load i32, ptr %t7
  store i32 %t8, ptr %l2, !tbaa !23
  br label %bb3
bb2:
  br label %bb10
bb3:
  %t10 = load i32, ptr %l2, !tbaa !23
  %t12 = sext i32 %t10 to i64
  store i64 %t12, ptr %l9, !tbaa !24
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/lower:Lowerer", ptr %t13, i32 0, i32 2
  %t17 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlan_3e_2eLen_3ccompiler_2ftyped_3aPlan_3e(ptr %v0, ptr %t15)
  store i64 %t17, ptr %l12
  br label %bb4
bb4:
  %t18 = load i64, ptr %l9, !tbaa !24
  %t19 = load i64, ptr %l12, !tbaa !24
  %t20 = icmp slt i64 %t18, %t19
  br i1 %t20, label %bb5, label %bb6
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/lower:Lowerer", ptr %t22, i32 0, i32 2
  %t25 = load i32, ptr %l2, !tbaa !23
  %t27 = sext i32 %t25 to i64
  %t30 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlan_3e_2eRef_3ccompiler_2ftyped_3aPlan_3e(ptr %v0, ptr %v0, ptr %t24, i64 %t27)
  store ptr %t30, ptr %l19
  br label %bb7
bb6:
  store i64 0, ptr %l14, !tbaa !24
  br label %bb9
bb7:
  %t31 = load ptr, ptr %l19, !tbaa !29
  %t33 = getelementptr %"compiler/typed:Plan", ptr %t31, i32 0, i32 17
  %t35 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t33)
  store i64 %t35, ptr %l22
  br label %bb8
bb8:
  %t36 = load i64, ptr %l22, !tbaa !24
  store i64 %t36, ptr %l14, !tbaa !24
  br label %bb9
bb9:
  %t37 = load i64, ptr %l14, !tbaa !24
  store i64 %t37, ptr %l4, !tbaa !24
  br label %bb25
bb10:
  %t38 = load { i64, [2 x i64] }, ptr %l1
  %t40 = extractvalue { i64, [2 x i64] } %t38, 0
  %t41 = icmp eq i64 %t40, 6
  br i1 %t41, label %bb11, label %bb12
bb11:
  %t43 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t44 = getelementptr { i32, i64 }, ptr %t43, i32 0, i32 1
  %t45 = load i64, ptr %t44
  store i64 %t45, ptr %l3, !tbaa !24
  br label %bb13
bb12:
  br label %bb20
bb13:
  %t47 = load i64, ptr %l3, !tbaa !24
  store i64 %t47, ptr %l26, !tbaa !24
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/lower:Lowerer", ptr %t48, i32 0, i32 8
  %t52 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlan_3e_2eLen_3ccompiler_2ftyped_3aPlan_3e(ptr %v0, ptr %t50)
  store i64 %t52, ptr %l29
  br label %bb14
bb14:
  %t53 = load i64, ptr %l26, !tbaa !24
  %t54 = load i64, ptr %l29, !tbaa !24
  %t55 = icmp slt i64 %t53, %t54
  br i1 %t55, label %bb15, label %bb16
bb15:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/lower:Lowerer", ptr %t57, i32 0, i32 8
  %t60 = load i64, ptr %l3, !tbaa !24
  %t63 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlan_3e_2eRef_3ccompiler_2ftyped_3aPlan_3e(ptr %v0, ptr %v0, ptr %t59, i64 %t60)
  store ptr %t63, ptr %l35
  br label %bb17
bb16:
  store i64 0, ptr %l31, !tbaa !24
  br label %bb19
bb17:
  %t64 = load ptr, ptr %l35, !tbaa !29
  %t66 = getelementptr %"compiler/typed:Plan", ptr %t64, i32 0, i32 17
  %t68 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t66)
  store i64 %t68, ptr %l38
  br label %bb18
bb18:
  %t69 = load i64, ptr %l38, !tbaa !24
  store i64 %t69, ptr %l31, !tbaa !24
  br label %bb19
bb19:
  %t70 = load i64, ptr %l31, !tbaa !24
  store i64 %t70, ptr %l4, !tbaa !24
  br label %bb25
bb20:
  br i1 true, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  store i64 0, ptr %l4, !tbaa !24
  br label %bb25
bb24:
  call void @__olang_check_failed(ptr @olang_loc_caf8701635663f27_e992a5ba8ea146fb)
  unreachable
bb25:
  %t71 = load i64, ptr %l4, !tbaa !24
  store i64 %t71, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3aLowerer_2eHasCode(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l2 = alloca ptr
  %l7 = alloca ptr
  %l14 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/lower:Lowerer", ptr %a0, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t8 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t4, i64 %a1)
  store ptr %t8, ptr %l7
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l7, !tbaa !29
  store ptr %t9, ptr %l2, !tbaa !29
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t12 = getelementptr %"compiler/typed:Body", ptr %t10, i32 0, i32 11
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t15 = icmp eq ptr %t13, null
  br i1 %t15, label %bb2, label %bb3
bb2:
  store i1 false, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t18 = load ptr, ptr %l2, !tbaa !29
  %t20 = getelementptr %"compiler/typed:Body", ptr %t18, i32 0, i32 1
  %t21 = load { i64, [2 x i64] }, ptr %t20
  %t25 = extractvalue { i64, [2 x i64] } %t21, 0
  %t26 = icmp eq i64 %t25, 2
  br i1 %t26, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb8
bb7:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb13
bb8:
  br i1 true, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  store i1 true, ptr %l14, !tbaa !21
  br label %bb13
bb12:
  call void @__olang_check_failed(ptr @olang_loc_daa9f23a83841987_24921124063ad36b)
  unreachable
bb13:
  %t28 = load i1, ptr %l14, !tbaa !21
  store i1 %t28, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2flower_2ecompiler_2flower_3aLowerer_2eInitModules(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l8 = alloca { i64, [2 x i64] }
  %l9 = alloca i64
  %l11 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l14 = alloca i64
  %l18 = alloca i64
  %l21 = alloca i64
  %l43 = alloca ptr
  %l52 = alloca i1
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l11
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l11
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  store i64 0, ptr %l2, !tbaa !24
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/lower:Lowerer", ptr %t3, i32 0, i32 1
  %t6 = load ptr, ptr %t5, !tbaa !29
  %t8 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %t6)
  store i64 %t8, ptr %l14
  br label %bb2
bb2:
  %t9 = load i64, ptr %l14, !tbaa !24
  store i64 %t9, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t10 = load i64, ptr %l3, !tbaa !24
  %t11 = load i64, ptr %l2, !tbaa !24
  %t14 = icmp sgt i64 %t10, %t11
  br i1 %t14, label %bb3, label %bb4
bb3:
  %t16 = load i64, ptr %l4, !tbaa !24
  %t18 = icmp sgt i64 %t16, 0
  br i1 %t18, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l18, !tbaa !24
  br label %bb8
bb5:
  %t20 = load i64, ptr %l3, !tbaa !24
  %t21 = load i64, ptr %l2, !tbaa !24
  %t24 = sub i64 %t20, %t21
  %t25 = load i64, ptr %l4, !tbaa !24
  %t28 = add i64 %t24, %t25
  %t30 = sub i64 %t28, 1
  %t31 = load i64, ptr %l4, !tbaa !24
  %t34 = sdiv i64 %t30, %t31
  store i64 %t34, ptr %l21, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l21, !tbaa !24
  br label %bb7
bb7:
  %t36 = load i64, ptr %l21, !tbaa !24
  store i64 %t36, ptr %l18, !tbaa !24
  br label %bb8
bb8:
  %t37 = load i64, ptr %l18, !tbaa !24
  store i64 %t37, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb9
bb9:
  %t38 = load i64, ptr %l6, !tbaa !24
  %t39 = load i64, ptr %l5, !tbaa !24
  %t42 = icmp slt i64 %t38, %t39
  %t44 = xor i1 %t42, true
  br i1 %t44, label %bb10, label %bb11
bb10:
  br label %bb29
bb11:
  br label %bb12
bb12:
  %t46 = load i64, ptr %l2, !tbaa !24
  %t47 = load i64, ptr %l6, !tbaa !24
  %t48 = load i64, ptr %l4, !tbaa !24
  %t51 = mul i64 %t47, %t48
  %t54 = add i64 %t46, %t51
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/lower:Lowerer", ptr %t56, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !29
  %t64 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t59, i64 %t54)
  store ptr %t64, ptr %l43
  br label %bb13
bb13:
  %t65 = load ptr, ptr %l43, !tbaa !29
  %t67 = getelementptr %"compiler/typed:Body", ptr %t65, i32 0, i32 1
  %t68 = load { i64, [2 x i64] }, ptr %t67
  store { i64, [2 x i64] } %t68, ptr %l8
  %t70 = load { i64, [2 x i64] }, ptr %l8
  %t72 = extractvalue { i64, [2 x i64] } %t70, 0
  %t73 = icmp eq i64 %t72, 6
  br i1 %t73, label %bb14, label %bb15
bb14:
  %t75 = getelementptr { i64, [2 x i64] }, ptr %l8, i32 0, i32 1
  %t76 = getelementptr { i64, i32 }, ptr %t75, i32 0, i32 0
  %t77 = load i64, ptr %t76
  store i64 %t77, ptr %l9, !tbaa !24
  br label %bb16
bb15:
  br label %bb22
bb16:
  %t79 = load i64, ptr %l9, !tbaa !24
  %t84 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eHas_3cI64_3e(ptr %v1, ptr %l1, i64 %t79)
  store i1 %t84, ptr %l52
  br label %bb17
bb17:
  %t85 = load i1, ptr %l52, !tbaa !21
  %t86 = xor i1 %t85, true
  br i1 %t86, label %bb18, label %bb19
bb18:
  %t88 = load i64, ptr %l9, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %l1, i64 %t88)
  br label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb21
bb21:
  br label %bb27
bb22:
  br i1 true, label %bb23, label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb27
bb26:
  call void @__olang_check_failed(ptr @olang_loc_e3721461a855ef35_c24433bc0ae5f641)
  unreachable
bb27:
  br label %bb28
bb28:
  %t91 = load i64, ptr %l6, !tbaa !24
  %t94 = add i64 %t91, 1
  store i64 %t94, ptr %l6, !tbaa !24
  br label %bb9
bb29:
  %t96 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t96, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local ptr @compiler_2flower_2ecompiler_2flower_3aLowerer_2eLower(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l4 = alloca ptr
  %rv = alloca ptr
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call ptr @compiler_2flower_2ecompiler_2flower_3aLowerer_2elowerAs(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 -1)
  store ptr %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load ptr, ptr %l4, !tbaa !29
  store ptr %t6, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3aLowerer_2ePreserves(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l6 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t7 = call i1 @compiler_2flower_2ecompiler_2flower_3aLowerer_2epreserves(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
  store i1 %t7, ptr %l6
  br label %bb1
bb1:
  %t8 = load i1, ptr %l6, !tbaa !21
  store i1 %t8, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3aLowerer_2eReadDerived(ptr %v0, ptr %a0, i64 %a1, { i64, [2 x i64] } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, [2 x i64] }
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l17 = alloca i1
  %l18 = alloca i64
  %l21 = alloca i64
  %l23 = alloca i1
  %l28 = alloca { i64, ptr }
  %l30 = alloca i1
  %l37 = alloca i32
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store { i64, [2 x i64] } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, [2 x i64] }, ptr %l2
  %t3 = extractvalue { i64, [2 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t7 = getelementptr { i32 }, ptr %t6, i32 0, i32 0
  %t8 = load i32, ptr %t7
  store i32 %t8, ptr %l3, !tbaa !23
  br label %bb5
bb2:
  %t10 = load { i64, [2 x i64] }, ptr %l2
  %t12 = extractvalue { i64, [2 x i64] } %t10, 0
  %t13 = icmp eq i64 %t12, 2
  br i1 %t13, label %bb3, label %bb4
bb3:
  %t15 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t16 = getelementptr { i32 }, ptr %t15, i32 0, i32 0
  %t17 = load i32, ptr %t16
  store i32 %t17, ptr %l3, !tbaa !23
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t19 = load i32, ptr %l3, !tbaa !23
  %t21 = sext i32 %t19 to i64
  store i64 %t21, ptr %l6, !tbaa !24
  br label %bb11
bb6:
  br i1 true, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store i64 -1, ptr %l6, !tbaa !24
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_64c38670143ed62f_66b5484a55823b73)
  unreachable
bb11:
  %t23 = load i64, ptr %l6, !tbaa !24
  store i64 %t23, ptr %l4, !tbaa !24
  %t24 = load i64, ptr %l4, !tbaa !24
  %t26 = icmp slt i64 %t24, 0
  br i1 %t26, label %bb12, label %bb13
bb12:
  store i1 true, ptr %l17, !tbaa !21
  br label %bb15
bb13:
  %t28 = load i64, ptr %l4, !tbaa !24
  store i64 %t28, ptr %l18, !tbaa !24
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/lower:Lowerer", ptr %t29, i32 0, i32 2
  %t33 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlan_3e_2eLen_3ccompiler_2ftyped_3aPlan_3e(ptr %v0, ptr %t31)
  store i64 %t33, ptr %l21
  br label %bb14
bb14:
  %t34 = load i64, ptr %l18, !tbaa !24
  %t35 = load i64, ptr %l21, !tbaa !24
  %t36 = icmp sge i64 %t34, %t35
  store i1 %t36, ptr %l17, !tbaa !21
  br label %bb15
bb15:
  %t38 = load i1, ptr %l17, !tbaa !21
  br i1 %t38, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l23, !tbaa !21
  br label %bb18
bb17:
  %t39 = load i64, ptr %l1, !tbaa !24
  %t41 = icmp slt i64 %t39, 0
  store i1 %t41, ptr %l23, !tbaa !21
  br label %bb18
bb18:
  %t43 = load i1, ptr %l23, !tbaa !21
  br i1 %t43, label %bb19, label %bb20
bb19:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb20:
  br label %bb21
bb21:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t45 = load i64, ptr %l4, !tbaa !24
  %t48 = call { i64, ptr } @compiler_2flower_2ecompiler_2flower_3aLowerer_2ederivedFact(ptr %v0, ptr %s0, ptr %t44, i64 %t45)
  store { i64, ptr } %t48, ptr %l28
  br label %bb22
bb22:
  %t49 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t49, ptr %l5, !tbaa !27
  %t50 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t52 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t50, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d1, i32 0, i32 1) })
  store i1 %t52, ptr %l30
  br label %bb23
bb23:
  %t53 = load i1, ptr %l30, !tbaa !21
  %t54 = xor i1 %t53, true
  br i1 %t54, label %bb24, label %bb25
bb24:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/lower:Lowerer", ptr %t56, i32 0, i32 0
  %t59 = load ptr, ptr %t58, !tbaa !29
  %t61 = getelementptr %"compiler/generic:Program", ptr %t59, i32 0, i32 3
  %t62 = load i64, ptr %l1, !tbaa !24
  %t63 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t67 = call i32 @compiler_2ffacts_2ecompiler_2ffacts_3aTable_2eNote(ptr %v0, ptr %s0, ptr %t61, i64 %t62, { i64, ptr } %t63)
  store i32 %t67, ptr %l37
  %t68 = icmp ne i32 %t67, 0
  br i1 %t68, label %bb27, label %ok.69, !prof !99
ok.69:
  br label %bb26
bb25:
  br label %bb30
bb26:
  br label %bb29
bb27:
  br label %bb28
bb28:
  br label %bb29
bb29:
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2flower_2ecompiler_2flower_3aLowerer_2eViewsOf(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca { i64, [2 x i64] }
  %l3 = alloca i64
  %l4 = alloca i32
  %l5 = alloca i32
  %l9 = alloca i1
  %l11 = alloca i64
  %l14 = alloca i64
  %l16 = alloca i1
  %l18 = alloca i64
  %l21 = alloca i64
  %l29 = alloca ptr
  %l32 = alloca i64
  %l36 = alloca i64
  %l42 = alloca i64
  %l43 = alloca i32
  %l50 = alloca i64
  %l51 = alloca i64
  %l58 = alloca i64
  %l59 = alloca i32
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l1, !tbaa !23
  %t3 = sext i32 %t1 to i64
  %t5 = icmp slt i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb4
bb2:
  %t7 = load i32, ptr %l1, !tbaa !23
  %t9 = sext i32 %t7 to i64
  store i64 %t9, ptr %l11, !tbaa !24
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/lower:Lowerer", ptr %t10, i32 0, i32 2
  %t14 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlan_3e_2eLen_3ccompiler_2ftyped_3aPlan_3e(ptr %v0, ptr %t12)
  store i64 %t14, ptr %l14
  br label %bb3
bb3:
  %t15 = load i64, ptr %l11, !tbaa !24
  %t16 = load i64, ptr %l14, !tbaa !24
  %t17 = icmp sge i64 %t15, %t16
  store i1 %t17, ptr %l9, !tbaa !21
  br label %bb4
bb4:
  %t19 = load i1, ptr %l9, !tbaa !21
  br i1 %t19, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l16, !tbaa !21
  br label %bb8
bb6:
  %t20 = load i32, ptr %l1, !tbaa !23
  %t22 = sext i32 %t20 to i64
  store i64 %t22, ptr %l18, !tbaa !24
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/lower:Lowerer", ptr %t23, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !29
  %t28 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %t26)
  store i64 %t28, ptr %l21
  br label %bb7
bb7:
  %t29 = load i64, ptr %l18, !tbaa !24
  %t30 = load i64, ptr %l21, !tbaa !24
  %t31 = icmp sge i64 %t29, %t30
  store i1 %t31, ptr %l16, !tbaa !21
  br label %bb8
bb8:
  %t33 = load i1, ptr %l16, !tbaa !21
  br i1 %t33, label %bb9, label %bb10
bb9:
  store i64 0, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/lower:Lowerer", ptr %t35, i32 0, i32 1
  %t38 = load ptr, ptr %t37, !tbaa !29
  %t40 = load i32, ptr %l1, !tbaa !23
  %t42 = sext i32 %t40 to i64
  %t45 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t38, i64 %t42)
  store ptr %t45, ptr %l29
  br label %bb12
bb12:
  %t46 = load ptr, ptr %l29, !tbaa !29
  %t48 = getelementptr %"compiler/typed:Body", ptr %t46, i32 0, i32 1
  %t49 = load { i64, [2 x i64] }, ptr %t48
  store { i64, [2 x i64] } %t49, ptr %l2
  %t51 = load { i64, [2 x i64] }, ptr %l2
  %t53 = extractvalue { i64, [2 x i64] } %t51, 0
  %t54 = icmp eq i64 %t53, 0
  br i1 %t54, label %bb13, label %bb14
bb13:
  %t56 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t57 = getelementptr { i64 }, ptr %t56, i32 0, i32 0
  %t58 = load i64, ptr %t57
  store i64 %t58, ptr %l3, !tbaa !24
  br label %bb15
bb14:
  br label %bb20
bb15:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/lower:Lowerer", ptr %t60, i32 0, i32 0
  %t63 = load ptr, ptr %t62, !tbaa !29
  %t65 = getelementptr %"compiler/generic:Program", ptr %t63, i32 0, i32 0
  %t66 = load ptr, ptr %t65, !tbaa !29
  %t68 = getelementptr %"compiler/load:Loader", ptr %t66, i32 0, i32 6
  %t69 = load i64, ptr %l3, !tbaa !24
  %t72 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t68, i64 %t69)
  %t73 = extractvalue { i32, i64 } %t72, 1
  %t74 = extractvalue { i32, i64 } %t72, 0
  store i32 %t74, ptr %l43
  %t75 = icmp ne i32 %t74, 0
  br i1 %t75, label %bb17, label %ok.76, !prof !99
ok.76:
  store i64 %t73, ptr %l42
  br label %bb16
bb16:
  %t77 = load i64, ptr %l42, !tbaa !24
  store i64 %t77, ptr %l36, !tbaa !24
  br label %bb19
bb17:
  br label %bb18
bb18:
  store i64 0, ptr %l36, !tbaa !24
  br label %bb19
bb19:
  %t78 = load i64, ptr %l36, !tbaa !24
  store i64 %t78, ptr %l32, !tbaa !24
  br label %bb36
bb20:
  %t79 = load { i64, [2 x i64] }, ptr %l2
  %t81 = extractvalue { i64, [2 x i64] } %t79, 0
  %t82 = icmp eq i64 %t81, 1
  br i1 %t82, label %bb21, label %bb22
bb21:
  %t84 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t85 = getelementptr { i32, i32 }, ptr %t84, i32 0, i32 0
  %t86 = load i32, ptr %t85
  store i32 %t86, ptr %l4, !tbaa !23
  %t88 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t89 = getelementptr { i32, i32 }, ptr %t88, i32 0, i32 1
  %t90 = load i32, ptr %t89
  store i32 %t90, ptr %l5, !tbaa !23
  br label %bb23
bb22:
  br label %bb31
bb23:
  %t92 = load i32, ptr %l5, !tbaa !23
  %t94 = icmp eq i32 %t92, 0
  br i1 %t94, label %bb24, label %bb25
bb24:
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"compiler/lower:Lowerer", ptr %t96, i32 0, i32 0
  %t99 = load ptr, ptr %t98, !tbaa !29
  %t101 = getelementptr %"compiler/generic:Program", ptr %t99, i32 0, i32 0
  %t102 = load ptr, ptr %t101, !tbaa !29
  %t104 = getelementptr %"compiler/load:Loader", ptr %t102, i32 0, i32 7
  %t105 = load i32, ptr %l4, !tbaa !23
  %t107 = sext i32 %t105 to i64
  %t110 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t104, i64 %t107)
  %t111 = extractvalue { i32, i64 } %t110, 1
  %t112 = extractvalue { i32, i64 } %t110, 0
  store i32 %t112, ptr %l59
  %t113 = icmp ne i32 %t112, 0
  br i1 %t113, label %bb27, label %ok.114, !prof !99
ok.114:
  store i64 %t111, ptr %l58
  br label %bb26
bb25:
  store i64 0, ptr %l50, !tbaa !24
  br label %bb30
bb26:
  %t115 = load i64, ptr %l58, !tbaa !24
  store i64 %t115, ptr %l51, !tbaa !24
  br label %bb29
bb27:
  br label %bb28
bb28:
  store i64 0, ptr %l51, !tbaa !24
  br label %bb29
bb29:
  %t116 = load i64, ptr %l51, !tbaa !24
  store i64 %t116, ptr %l50, !tbaa !24
  br label %bb30
bb30:
  %t117 = load i64, ptr %l50, !tbaa !24
  store i64 %t117, ptr %l32, !tbaa !24
  br label %bb36
bb31:
  br i1 true, label %bb32, label %bb33
bb32:
  br label %bb34
bb33:
  br label %bb35
bb34:
  store i64 0, ptr %l32, !tbaa !24
  br label %bb36
bb35:
  call void @__olang_check_failed(ptr @olang_loc_585470ea6701dfed_8ee4dec4923e1081)
  unreachable
bb36:
  %t118 = load i64, ptr %l32, !tbaa !24
  store i64 %t118, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3aLowerer_2eallFresh(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/typed:LocalUses"
  %l3 = alloca ptr
  %l4 = alloca i64
  %l9 = alloca i1
  %l11 = alloca ptr
  %l13 = alloca ptr
  %l16 = alloca i32
  %l17 = alloca i1
  %l24 = alloca %"compiler/typed:LocalUses"
  %l26 = alloca i64
  %l28 = alloca i64
  %l33 = alloca ptr
  %l38 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  %t36 = alloca %"compiler/typed:LocalUses", align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Body", ptr %t1, i32 0, i32 11
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = icmp eq ptr %t4, null
  br i1 %t6, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb7
bb2:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = call ptr @compiler_2flower_2ecompiler_2flower_3aLowerer_2eT(ptr %v0, ptr %v0, ptr %t8)
  store ptr %t10, ptr %l11
  br label %bb3
bb3:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = call ptr @compiler_2flower_2ecompiler_2flower_3aLowerer_2eT(ptr %v0, ptr %v0, ptr %t11)
  store ptr %t13, ptr %l13
  br label %bb4
bb4:
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t16 = getelementptr %"compiler/typed:Body", ptr %t14, i32 0, i32 2
  %t17 = load i32, ptr %t16, !tbaa !23
  %t18 = load ptr, ptr %l13, !tbaa !29
  %t20 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t18, i32 %t17)
  store i32 %t20, ptr %l16
  br label %bb5
bb5:
  %t21 = load ptr, ptr %l11, !tbaa !29
  %t22 = load i32, ptr %l16, !tbaa !23
  %t23 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t21, i32 %t22)
  store i1 %t23, ptr %l17
  br label %bb6
bb6:
  %t24 = load i1, ptr %l17, !tbaa !21
  %t25 = xor i1 %t24, true
  store i1 %t25, ptr %l9, !tbaa !21
  br label %bb7
bb7:
  %t27 = load i1, ptr %l9, !tbaa !21
  br i1 %t27, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/lower:Lowerer", ptr %t29, i32 0, i32 0
  %t32 = load ptr, ptr %t31, !tbaa !29
  %t34 = getelementptr %"compiler/generic:Program", ptr %t32, i32 0, i32 2
  %t35 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2ftyped_2eLocalUses_2eUses(ptr %t36, ptr %v0, ptr %v1, ptr %s0, ptr %t34, ptr %t35)
  call void @llvm.memmove.p0.p0.i64(ptr %l24, ptr %t36, i64 1640, i1 false)
  br label %bb11
bb11:
  call void @llvm.memmove.p0.p0.i64(ptr %l2, ptr %l24, i64 1640, i1 false)
  %t39 = getelementptr %"compiler/typed:LocalUses", ptr %l2, i32 0, i32 31
  store ptr %t39, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  br label %bb12
bb12:
  %t41 = load i64, ptr %l4, !tbaa !24
  store i64 %t41, ptr %l26, !tbaa !24
  %t42 = load ptr, ptr %l3, !tbaa !29
  %t44 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %s0, ptr %t42)
  store i64 %t44, ptr %l28
  br label %bb13
bb13:
  %t45 = load i64, ptr %l26, !tbaa !24
  %t46 = load i64, ptr %l28, !tbaa !24
  %t47 = icmp slt i64 %t45, %t46
  %t49 = xor i1 %t47, true
  br i1 %t49, label %bb14, label %bb15
bb14:
  br label %bb23
bb15:
  br label %bb16
bb16:
  %t51 = load ptr, ptr %l3, !tbaa !29
  %t52 = load i64, ptr %l4, !tbaa !24
  %t55 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %s0, ptr %s0, ptr %t51, i64 %t52)
  store ptr %t55, ptr %l33
  br label %bb17
bb17:
  %t56 = load ptr, ptr %l33, !tbaa !29
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t58 = load ptr, ptr %l1, !tbaa !29
  %t64 = call i1 @compiler_2flower_2ecompiler_2flower_3aLowerer_2efreshRet(ptr %v0, ptr %v1, ptr %s0, ptr %s0, ptr %t57, ptr %t58, ptr %l2, ptr %t56)
  store i1 %t64, ptr %l38
  br label %bb18
bb18:
  %t65 = load i1, ptr %l38, !tbaa !21
  %t66 = xor i1 %t65, true
  br i1 %t66, label %bb19, label %bb20
bb19:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  br label %bb22
bb22:
  %t69 = load i64, ptr %l4, !tbaa !24
  %t72 = add i64 %t69, 1
  store i64 %t72, ptr %l4, !tbaa !24
  br label %bb12
bb23:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2flower_2ecompiler_2flower_3aLowerer_2edeclName(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l10 = alloca i64
  %l13 = alloca i1
  %l14 = alloca i64
  %l19 = alloca i64
  %l21 = alloca { i64, ptr }
  %l27 = alloca ptr
  %l30 = alloca { i64, ptr }
  %l33 = alloca ptr
  %l40 = alloca i32
  %l42 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:Lowerer", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t7 = load i64, ptr %l1, !tbaa !24
  %t9 = trunc i64 %t7 to i32
  %t13 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %t6, i32 %t9)
  store i64 %t13, ptr %l10
  br label %bb1
bb1:
  %t14 = load i64, ptr %l10, !tbaa !24
  store i64 %t14, ptr %l2, !tbaa !24
  %t15 = load i64, ptr %l2, !tbaa !24
  %t17 = icmp sge i64 %t15, 0
  br i1 %t17, label %bb2, label %bb3
bb2:
  %t19 = load i64, ptr %l2, !tbaa !24
  store i64 %t19, ptr %l14, !tbaa !24
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/lower:Lowerer", ptr %t20, i32 0, i32 0
  %t23 = load ptr, ptr %t22, !tbaa !29
  %t25 = getelementptr %"compiler/generic:Program", ptr %t23, i32 0, i32 0
  %t26 = load ptr, ptr %t25, !tbaa !29
  %t28 = getelementptr %"compiler/load:Loader", ptr %t26, i32 0, i32 10
  %t30 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %t28)
  store i64 %t30, ptr %l19
  br label %bb4
bb3:
  store i1 false, ptr %l13, !tbaa !21
  br label %bb5
bb4:
  %t31 = load i64, ptr %l14, !tbaa !24
  %t32 = load i64, ptr %l19, !tbaa !24
  %t33 = icmp slt i64 %t31, %t32
  store i1 %t33, ptr %l13, !tbaa !21
  br label %bb5
bb5:
  %t35 = load i1, ptr %l13, !tbaa !21
  br i1 %t35, label %bb6, label %bb7
bb6:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/lower:Lowerer", ptr %t36, i32 0, i32 0
  %t39 = load ptr, ptr %t38, !tbaa !29
  %t41 = getelementptr %"compiler/generic:Program", ptr %t39, i32 0, i32 0
  %t42 = load ptr, ptr %t41, !tbaa !29
  %t44 = getelementptr %"compiler/load:Loader", ptr %t42, i32 0, i32 10
  %t45 = load i64, ptr %l2, !tbaa !24
  %t48 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t44, i64 %t45)
  store ptr %t48, ptr %l27
  br label %bb8
bb7:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d2, i32 0, i32 1) }, ptr %l21, !tbaa !27
  br label %bb9
bb8:
  %t49 = load ptr, ptr %l27, !tbaa !29
  %t51 = getelementptr %"compiler/load:Module", ptr %t49, i32 0, i32 2
  %t52 = load { i64, ptr }, ptr %t51, !tbaa !27
  store { i64, ptr } %t52, ptr %l21, !tbaa !27
  br label %bb9
bb9:
  %t54 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t54, ptr %l30, !tbaa !27
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/lower:Lowerer", ptr %t56, i32 0, i32 0
  %t59 = load ptr, ptr %t58, !tbaa !29
  %t61 = getelementptr %"compiler/generic:Program", ptr %t59, i32 0, i32 2
  %t62 = getelementptr %"compiler/types:Table", ptr %t61, i32 0, i32 0
  %t63 = load ptr, ptr %t62, !tbaa !29
  store ptr %t63, ptr %l33, !tbaa !29
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/lower:Lowerer", ptr %t64, i32 0, i32 0
  %t67 = load ptr, ptr %t66, !tbaa !29
  %t69 = getelementptr %"compiler/generic:Program", ptr %t67, i32 0, i32 2
  %t70 = load i64, ptr %l1, !tbaa !24
  %t72 = trunc i64 %t70 to i32
  %t76 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %t69, i32 %t72)
  store i32 %t76, ptr %l40
  br label %bb10
bb10:
  %t77 = load ptr, ptr %l33, !tbaa !29
  %t78 = call ptr @__olang_scope_of(ptr %t77, ptr null)
  %t79 = call ptr @__olang_scope_hold(ptr %t78)
  %t80 = ptrtoint ptr %t79 to i64
  %t82 = inttoptr i64 %t80 to ptr
  %t83 = load ptr, ptr %l33, !tbaa !29
  %t84 = load i32, ptr %l40, !tbaa !23
  %t85 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %t82, ptr %s0, ptr %t83, i32 %t84)
  store { i64, ptr } %t85, ptr %l42
  br label %bb11
bb11:
  %t86 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t87 = extractvalue { i64, ptr } %t86, 1
  %t88 = extractvalue { i64, ptr } %t86, 0
  %t89 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d3, i32 0, i32 1) }, 1
  %t90 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d3, i32 0, i32 1) }, 0
  %t91 = add i64 %t88, %t90
  %t92 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t93 = extractvalue { i64, ptr } %t92, 1
  %t94 = extractvalue { i64, ptr } %t92, 0
  %t95 = add i64 %t91, %t94
  %t96 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t95)
  call void @olang_textcopy(ptr %t96, ptr %t87, i64 %t88)
  %t97 = getelementptr i8, ptr %t96, i64 %t88
  call void @olang_textcopy(ptr %t97, ptr %t89, i64 %t90)
  %t98 = getelementptr i8, ptr %t97, i64 %t90
  call void @olang_textcopy(ptr %t98, ptr %t93, i64 %t94)
  %t99 = insertvalue { i64, ptr } undef, i64 %t95, 0
  %t100 = insertvalue { i64, ptr } %t99, ptr %t96, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t100, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2flower_2ecompiler_2flower_3aLowerer_2ederivedFact(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, [2 x i64] }
  %l3 = alloca i64
  %l4 = alloca i32
  %l9 = alloca ptr
  %l12 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l31 = alloca { i64, ptr }
  %l33 = alloca i64
  %l34 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:Lowerer", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t9 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t4, i64 %a1)
  store ptr %t9, ptr %l9
  br label %bb1
bb1:
  %t10 = load ptr, ptr %l9, !tbaa !29
  %t12 = getelementptr %"compiler/typed:Body", ptr %t10, i32 0, i32 1
  %t13 = load { i64, [2 x i64] }, ptr %t12
  store { i64, [2 x i64] } %t13, ptr %l2
  %t15 = load { i64, [2 x i64] }, ptr %l2
  %t17 = extractvalue { i64, [2 x i64] } %t15, 0
  %t18 = icmp eq i64 %t17, 0
  br i1 %t18, label %bb2, label %bb3
bb2:
  %t20 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t21 = getelementptr { i64 }, ptr %t20, i32 0, i32 0
  %t22 = load i64, ptr %t21
  store i64 %t22, ptr %l3, !tbaa !24
  br label %bb4
bb3:
  br label %bb6
bb4:
  store %olang.scope zeroinitializer, ptr %s1
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/lower:Lowerer", ptr %t24, i32 0, i32 0
  %t27 = load ptr, ptr %t26, !tbaa !29
  %t28 = load i64, ptr %l3, !tbaa !24
  %t31 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceName(ptr %v0, ptr %s1, ptr %t27, i64 %t28)
  store { i64, ptr } %t31, ptr %l19
  br label %bb5
bb5:
  %t32 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d4, i32 0, i32 1) }, 1
  %t33 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d4, i32 0, i32 1) }, 0
  %t34 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t35 = extractvalue { i64, ptr } %t34, 1
  %t36 = extractvalue { i64, ptr } %t34, 0
  %t37 = add i64 %t33, %t36
  %t38 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t37)
  call void @olang_textcopy(ptr %t38, ptr %t32, i64 %t33)
  %t39 = getelementptr i8, ptr %t38, i64 %t33
  call void @olang_textcopy(ptr %t39, ptr %t35, i64 %t36)
  %t40 = insertvalue { i64, ptr } undef, i64 %t37, 0
  %t41 = insertvalue { i64, ptr } %t40, ptr %t38, 1
  store { i64, ptr } %t41, ptr %l12, !tbaa !27
  call void @__olang_scope_close(ptr %s1)
  br label %bb16
bb6:
  %t43 = load { i64, [2 x i64] }, ptr %l2
  %t45 = extractvalue { i64, [2 x i64] } %t43, 0
  %t46 = icmp eq i64 %t45, 3
  br i1 %t46, label %bb7, label %bb8
bb7:
  %t48 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t49 = getelementptr { i32 }, ptr %t48, i32 0, i32 0
  %t50 = load i32, ptr %t49
  store i32 %t50, ptr %l4, !tbaa !23
  br label %bb9
bb8:
  br label %bb11
bb9:
  store %olang.scope zeroinitializer, ptr %s3
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/lower:Lowerer", ptr %t52, i32 0, i32 0
  %t55 = load ptr, ptr %t54, !tbaa !29
  %t57 = getelementptr %"compiler/generic:Program", ptr %t55, i32 0, i32 2
  %t58 = load i32, ptr %l4, !tbaa !23
  %t60 = inttoptr i64 0 to ptr
  %t63 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %s3, ptr %t60, ptr %t57, i32 %t58)
  store { i64, ptr } %t63, ptr %l29
  br label %bb10
bb10:
  %t64 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d5, i32 0, i32 1) }, 1
  %t65 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d5, i32 0, i32 1) }, 0
  %t66 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t67 = extractvalue { i64, ptr } %t66, 1
  %t68 = extractvalue { i64, ptr } %t66, 0
  %t69 = add i64 %t65, %t68
  %t70 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t69)
  call void @olang_textcopy(ptr %t70, ptr %t64, i64 %t65)
  %t71 = getelementptr i8, ptr %t70, i64 %t65
  call void @olang_textcopy(ptr %t71, ptr %t67, i64 %t68)
  %t72 = insertvalue { i64, ptr } undef, i64 %t69, 0
  %t73 = insertvalue { i64, ptr } %t72, ptr %t70, 1
  store { i64, ptr } %t73, ptr %l12, !tbaa !27
  call void @__olang_scope_close(ptr %s3)
  br label %bb16
bb11:
  br i1 true, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d6, i32 0, i32 1) }, ptr %l31, !tbaa !27
  %t75 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t75, ptr %l12, !tbaa !27
  br label %bb16
bb15:
  call void @__olang_check_failed(ptr @olang_loc_66e2991888adf299_d5a5a9b8966d006d)
  unreachable
bb16:
  %t77 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t78 = extractvalue { i64, ptr } %t77, 0
  store i64 %t78, ptr %l33, !tbaa !24
  %t79 = load i64, ptr %l33, !tbaa !24
  %t80 = mul i64 %t79, 1
  %t81 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t80)
  %t82 = insertvalue { i64, ptr } undef, i64 %t79, 0
  %t83 = insertvalue { i64, ptr } %t82, ptr %t81, 1
  store { i64, ptr } %t83, ptr %l34, !tbaa !27
  %t84 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t85 = load ptr, ptr %t84, !tbaa !27
  %t86 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t87 = load ptr, ptr %t86, !tbaa !27
  %t88 = load i64, ptr %l33, !tbaa !24
  %t89 = mul i64 %t88, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t85, ptr %t87, i64 %t89, i1 false)
  %t90 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t90, ptr %l12, !tbaa !27
  %t91 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t91, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2flower_2ecompiler_2flower_3aLowerer_2eerrQualifier(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l7 = alloca i64
  %l13 = alloca ptr
  %l22 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:Lowerer", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t10 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %t6, i32 %a1)
  store i64 %t10, ptr %l7
  br label %bb1
bb1:
  %t11 = load i64, ptr %l7, !tbaa !24
  store i64 %t11, ptr %l2, !tbaa !24
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/lower:Lowerer", ptr %t12, i32 0, i32 0
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t17 = getelementptr %"compiler/generic:Program", ptr %t15, i32 0, i32 0
  %t18 = load ptr, ptr %t17, !tbaa !29
  %t20 = getelementptr %"compiler/load:Loader", ptr %t18, i32 0, i32 10
  %t21 = load i64, ptr %l2, !tbaa !24
  %t24 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t20, i64 %t21)
  store ptr %t24, ptr %l13
  br label %bb2
bb2:
  %t25 = load ptr, ptr %l13, !tbaa !29
  %t27 = getelementptr %"compiler/load:Module", ptr %t25, i32 0, i32 2
  %t28 = load { i64, ptr }, ptr %t27, !tbaa !27
  %t29 = load i64, ptr %l2, !tbaa !24
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/lower:Lowerer", ptr %t30, i32 0, i32 0
  %t33 = load ptr, ptr %t32, !tbaa !29
  %t35 = getelementptr %"compiler/generic:Program", ptr %t33, i32 0, i32 0
  %t36 = load ptr, ptr %t35, !tbaa !29
  %t38 = getelementptr %"compiler/load:Loader", ptr %t36, i32 0, i32 12
  %t39 = load i64, ptr %t38, !tbaa !24
  %t42 = icmp eq i64 %t29, %t39
  %t45 = call { i64, ptr } @compiler_2fload_2eErrQualifier(ptr %v0, ptr %v1, { i64, ptr } %t28, i1 %t42)
  store { i64, ptr } %t45, ptr %l22
  br label %bb3
bb3:
  %t46 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t46, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3aLowerer_2efreshMade(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca { i64, ptr }
  %l8 = alloca ptr
  %l9 = alloca i1
  %l10 = alloca ptr
  %l11 = alloca i1
  %l20 = alloca ptr
  %l21 = alloca i1
  %l24 = alloca ptr
  %l25 = alloca i1
  %l28 = alloca ptr
  %l29 = alloca i1
  %l32 = alloca ptr
  %l33 = alloca i1
  %l41 = alloca ptr
  %l42 = alloca i1
  %l45 = alloca i1
  %l50 = alloca ptr
  %l52 = alloca i1
  %l54 = alloca ptr
  %l55 = alloca i1
  %l64 = alloca i1
  %l68 = alloca i1
  %l70 = alloca { i64, ptr }
  %l72 = alloca i1
  %l73 = alloca ptr
  %l74 = alloca i1
  %l81 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l10, !tbaa !29
  store i1 false, ptr %l11, !tbaa !21
  %t2 = load ptr, ptr %l10, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l10, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 7
  store i1 %t8, ptr %l11, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l11, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load ptr, ptr %l2, !tbaa !29
  %t18 = getelementptr %"compiler/typed:Make", ptr %t16, i32 0, i32 0
  %t19 = load i32, ptr %t18, !range !{i32 0, i32 5}
  %t21 = trunc i64 0 to i32
  %t22 = icmp eq i32 %t19, %t21
  %t24 = xor i1 %t22, true
  store i1 %t24, ptr %l9, !tbaa !21
  br label %bb58
bb6:
  %t26 = load ptr, ptr %l1, !tbaa !29
  store ptr %t26, ptr %l20, !tbaa !29
  store i1 false, ptr %l21, !tbaa !21
  %t27 = load ptr, ptr %l20, !tbaa !29
  %t28 = icmp ne ptr %t27, null
  br i1 %t28, label %bb7, label %bb8
bb7:
  %t30 = load ptr, ptr %l20, !tbaa !29
  %t31 = load i64, ptr %t30, !range !{i64 0, i64 18}
  %t33 = icmp eq i64 %t31, 8
  store i1 %t33, ptr %l21, !tbaa !21
  br label %bb8
bb8:
  %t34 = load i1, ptr %l21, !tbaa !21
  br i1 %t34, label %bb9, label %bb10
bb9:
  br label %bb19
bb10:
  %t35 = load ptr, ptr %l1, !tbaa !29
  store ptr %t35, ptr %l24, !tbaa !29
  store i1 false, ptr %l25, !tbaa !21
  %t36 = load ptr, ptr %l24, !tbaa !29
  %t37 = icmp ne ptr %t36, null
  br i1 %t37, label %bb11, label %bb12
bb11:
  %t39 = load ptr, ptr %l24, !tbaa !29
  %t40 = load i64, ptr %t39, !range !{i64 0, i64 18}
  %t42 = icmp eq i64 %t40, 16
  store i1 %t42, ptr %l25, !tbaa !21
  br label %bb12
bb12:
  %t43 = load i1, ptr %l25, !tbaa !21
  br i1 %t43, label %bb13, label %bb14
bb13:
  br label %bb19
bb14:
  %t44 = load ptr, ptr %l1, !tbaa !29
  store ptr %t44, ptr %l28, !tbaa !29
  store i1 false, ptr %l29, !tbaa !21
  %t45 = load ptr, ptr %l28, !tbaa !29
  %t46 = icmp ne ptr %t45, null
  br i1 %t46, label %bb15, label %bb16
bb15:
  %t48 = load ptr, ptr %l28, !tbaa !29
  %t49 = load i64, ptr %t48, !range !{i64 0, i64 18}
  %t51 = icmp eq i64 %t49, 0
  store i1 %t51, ptr %l29, !tbaa !21
  br label %bb16
bb16:
  %t52 = load i1, ptr %l29, !tbaa !21
  br i1 %t52, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb58
bb20:
  %t53 = load ptr, ptr %l1, !tbaa !29
  store ptr %t53, ptr %l32, !tbaa !29
  store i1 false, ptr %l33, !tbaa !21
  %t54 = load ptr, ptr %l32, !tbaa !29
  %t55 = icmp ne ptr %t54, null
  br i1 %t55, label %bb21, label %bb22
bb21:
  %t57 = load ptr, ptr %l32, !tbaa !29
  %t58 = load i64, ptr %t57, !range !{i64 0, i64 18}
  %t60 = icmp eq i64 %t58, 6
  store i1 %t60, ptr %l33, !tbaa !21
  br label %bb22
bb22:
  %t61 = load i1, ptr %l33, !tbaa !21
  br i1 %t61, label %bb23, label %bb24
bb23:
  %t62 = load ptr, ptr %l1, !tbaa !29
  %t64 = getelementptr { i64, [5 x i64] }, ptr %t62, i32 0, i32 1
  %t65 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t64, i32 0, i32 1
  %t66 = load i32, ptr %t65
  store i32 %t66, ptr %l3, !tbaa !23
  %t68 = load ptr, ptr %l1, !tbaa !29
  %t70 = getelementptr { i64, [5 x i64] }, ptr %t68, i32 0, i32 1
  %t71 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t70, i32 0, i32 2
  %t72 = load ptr, ptr %t71
  store ptr %t72, ptr %l4, !tbaa !29
  br label %bb25
bb24:
  br label %bb33
bb25:
  %t74 = load ptr, ptr %l4, !tbaa !29
  %t76 = getelementptr %"compiler/typed:Call", ptr %t74, i32 0, i32 0
  %t77 = load ptr, ptr %t76, !tbaa !29
  store ptr %t77, ptr %l41, !tbaa !29
  store i1 false, ptr %l42, !tbaa !21
  %t78 = load ptr, ptr %l41, !tbaa !29
  %t79 = icmp ne ptr %t78, null
  br i1 %t79, label %bb26, label %bb27
bb26:
  %t81 = load ptr, ptr %l41, !tbaa !29
  %t82 = load i64, ptr %t81, !range !{i64 0, i64 5}
  %t84 = icmp eq i64 %t82, 0
  store i1 %t84, ptr %l42, !tbaa !21
  br label %bb27
bb27:
  %t85 = load i1, ptr %l42, !tbaa !21
  br i1 %t85, label %bb28, label %bb29
bb28:
  %t86 = load ptr, ptr %l4, !tbaa !29
  %t88 = getelementptr %"compiler/typed:Call", ptr %t86, i32 0, i32 0
  %t89 = load ptr, ptr %t88, !tbaa !29
  %t91 = getelementptr { i64, [3 x i64] }, ptr %t89, i32 0, i32 1
  %t92 = getelementptr { i32 }, ptr %t91, i32 0, i32 0
  %t93 = load i32, ptr %t92
  store i32 %t93, ptr %l5, !tbaa !23
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t97 = call ptr @compiler_2flower_2ecompiler_2flower_3aLowerer_2eT(ptr %v0, ptr %v0, ptr %t95)
  store ptr %t97, ptr %l50
  br label %bb30
bb29:
  store i1 false, ptr %l45, !tbaa !21
  br label %bb32
bb30:
  %t98 = load i32, ptr %l3, !tbaa !23
  %t99 = load ptr, ptr %l50, !tbaa !29
  %t101 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t99, i32 %t98)
  store i1 %t101, ptr %l52
  br label %bb31
bb31:
  %t102 = load i1, ptr %l52, !tbaa !21
  %t103 = xor i1 %t102, true
  store i1 %t103, ptr %l45, !tbaa !21
  br label %bb32
bb32:
  %t105 = load i1, ptr %l45, !tbaa !21
  store i1 %t105, ptr %l9, !tbaa !21
  br label %bb58
bb33:
  %t106 = load ptr, ptr %l1, !tbaa !29
  store ptr %t106, ptr %l54, !tbaa !29
  store i1 false, ptr %l55, !tbaa !21
  %t107 = load ptr, ptr %l54, !tbaa !29
  %t108 = icmp ne ptr %t107, null
  br i1 %t108, label %bb34, label %bb35
bb34:
  %t110 = load ptr, ptr %l54, !tbaa !29
  %t111 = load i64, ptr %t110, !range !{i64 0, i64 18}
  %t113 = icmp eq i64 %t111, 9
  store i1 %t113, ptr %l55, !tbaa !21
  br label %bb35
bb35:
  %t114 = load i1, ptr %l55, !tbaa !21
  br i1 %t114, label %bb36, label %bb37
bb36:
  %t115 = load ptr, ptr %l1, !tbaa !29
  %t117 = getelementptr { i64, [5 x i64] }, ptr %t115, i32 0, i32 1
  %t118 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t117, i32 0, i32 2
  %t119 = load i32, ptr %t118, !range !{i32 0, i32 54}
  store i32 %t119, ptr %l6
  %t121 = load ptr, ptr %l1, !tbaa !29
  %t123 = getelementptr { i64, [5 x i64] }, ptr %t121, i32 0, i32 1
  %t124 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t123, i32 0, i32 4
  %t125 = load { i64, ptr }, ptr %t124
  store { i64, ptr } %t125, ptr %l7, !tbaa !27
  br label %bb38
bb37:
  br label %bb46
bb38:
  %t127 = load i32, ptr %l6, !range !{i32 0, i32 54}
  %t129 = trunc i64 20 to i32
  %t130 = icmp eq i32 %t127, %t129
  br i1 %t130, label %bb39, label %bb40
bb39:
  %t132 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t134 = extractvalue { i64, ptr } %t132, 0
  %t136 = icmp eq i64 %t134, 1
  store i1 %t136, ptr %l64, !tbaa !21
  br label %bb41
bb40:
  store i1 false, ptr %l64, !tbaa !21
  br label %bb41
bb41:
  %t138 = load i1, ptr %l64, !tbaa !21
  br i1 %t138, label %bb42, label %bb43
bb42:
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t140 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t140, ptr %l70, !tbaa !27
  %t141 = getelementptr { i64, ptr }, ptr %l70, i32 0, i32 1
  %t142 = load ptr, ptr %t141, !tbaa !27
  %t143 = getelementptr ptr, ptr %t142, i64 0
  %t144 = load ptr, ptr %t143, !tbaa !39
  %t147 = call i1 @compiler_2flower_2ecompiler_2flower_3aLowerer_2efreshMade(ptr %v0, ptr %v1, ptr %t139, ptr %t144)
  store i1 %t147, ptr %l72
  br label %bb44
bb43:
  store i1 false, ptr %l68, !tbaa !21
  br label %bb45
bb44:
  %t148 = load i1, ptr %l72, !tbaa !21
  store i1 %t148, ptr %l68, !tbaa !21
  br label %bb45
bb45:
  %t149 = load i1, ptr %l68, !tbaa !21
  store i1 %t149, ptr %l9, !tbaa !21
  br label %bb58
bb46:
  %t150 = load ptr, ptr %l1, !tbaa !29
  store ptr %t150, ptr %l73, !tbaa !29
  store i1 false, ptr %l74, !tbaa !21
  %t151 = load ptr, ptr %l73, !tbaa !29
  %t152 = icmp ne ptr %t151, null
  br i1 %t152, label %bb47, label %bb48
bb47:
  %t154 = load ptr, ptr %l73, !tbaa !29
  %t155 = load i64, ptr %t154, !range !{i64 0, i64 18}
  %t157 = icmp eq i64 %t155, 17
  store i1 %t157, ptr %l74, !tbaa !21
  br label %bb48
bb48:
  %t158 = load i1, ptr %l74, !tbaa !21
  br i1 %t158, label %bb49, label %bb50
bb49:
  %t159 = load ptr, ptr %l1, !tbaa !29
  %t161 = getelementptr { i64, [5 x i64] }, ptr %t159, i32 0, i32 1
  %t162 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t161, i32 0, i32 2
  %t163 = load ptr, ptr %t162
  store ptr %t163, ptr %l8, !tbaa !29
  br label %bb51
bb50:
  br label %bb53
bb51:
  %t165 = load ptr, ptr %l0, !tbaa !29
  %t166 = load ptr, ptr %l8, !tbaa !29
  %t169 = call i1 @compiler_2flower_2ecompiler_2flower_3aLowerer_2efreshMade(ptr %v0, ptr %v1, ptr %t165, ptr %t166)
  store i1 %t169, ptr %l81
  br label %bb52
bb52:
  %t170 = load i1, ptr %l81, !tbaa !21
  store i1 %t170, ptr %l9, !tbaa !21
  br label %bb58
bb53:
  br i1 true, label %bb54, label %bb55
bb54:
  br label %bb56
bb55:
  br label %bb57
bb56:
  store i1 false, ptr %l9, !tbaa !21
  br label %bb58
bb57:
  call void @__olang_check_failed(ptr @olang_loc_fdef55e2919415e3_7c40141ab4e8627)
  unreachable
bb58:
  %t171 = load i1, ptr %l9, !tbaa !21
  store i1 %t171, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3aLowerer_2efreshParam(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i1
  %l8 = alloca i1
  %l9 = alloca i64
  %l12 = alloca i64
  %l14 = alloca i1
  %l25 = alloca i1
  %l29 = alloca i1
  %l30 = alloca i32
  %l34 = alloca ptr
  %l38 = alloca ptr
  %l40 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb4
bb2:
  %t5 = load i64, ptr %l1, !tbaa !24
  store i64 %t5, ptr %l9, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/lower:Lowerer", ptr %t6, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t11 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %t9)
  store i64 %t11, ptr %l12
  br label %bb3
bb3:
  %t12 = load i64, ptr %l9, !tbaa !24
  %t13 = load i64, ptr %l12, !tbaa !24
  %t14 = icmp sge i64 %t12, %t13
  store i1 %t14, ptr %l8, !tbaa !21
  br label %bb4
bb4:
  %t16 = load i1, ptr %l8, !tbaa !21
  br i1 %t16, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l14, !tbaa !21
  br label %bb7
bb6:
  %t17 = load i64, ptr %l2, !tbaa !24
  %t19 = icmp sge i64 %t17, 64
  store i1 %t19, ptr %l14, !tbaa !21
  br label %bb7
bb7:
  %t21 = load i1, ptr %l14, !tbaa !21
  br i1 %t21, label %bb8, label %bb9
bb8:
  store i1 false, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t23 = shl i64 1, 40
  %t25 = sub i64 0, %t23
  %t26 = load i64, ptr %l1, !tbaa !24
  %t28 = mul i64 %t26, 64
  %t29 = load i64, ptr %l2, !tbaa !24
  %t32 = add i64 %t28, %t29
  %t35 = sub i64 %t25, %t32
  store i64 %t35, ptr %l3, !tbaa !24
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/lower:Lowerer", ptr %t37, i32 0, i32 40
  %t40 = load i64, ptr %l3, !tbaa !24
  %t43 = call { i32, i1 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eGet_3cI64_2c_20Bool_3e(ptr %v0, ptr %t39, i64 %t40)
  %t44 = extractvalue { i32, i1 } %t43, 1
  %t45 = extractvalue { i32, i1 } %t43, 0
  store i32 %t45, ptr %l30
  %t46 = icmp ne i32 %t45, 0
  br i1 %t46, label %bb12, label %ok.47, !prof !99
ok.47:
  store i1 %t44, ptr %l29
  br label %bb11
bb11:
  %t48 = load i1, ptr %l29, !tbaa !21
  store i1 %t48, ptr %l25, !tbaa !21
  br label %bb18
bb12:
  br label %bb13
bb13:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/lower:Lowerer", ptr %t49, i32 0, i32 40
  %t52 = load i64, ptr %l3, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t51, i64 %t52, i1 false)
  br label %bb14
bb14:
  %t55 = load ptr, ptr %l0, !tbaa !29
  store ptr %t55, ptr %l34, !tbaa !29
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/lower:Lowerer", ptr %t56, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !29
  %t60 = load i64, ptr %l1, !tbaa !24
  %t63 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t59, i64 %t60)
  store ptr %t63, ptr %l38
  br label %bb15
bb15:
  %t64 = load i64, ptr %l2, !tbaa !24
  %t65 = load ptr, ptr %l34, !tbaa !29
  %t66 = load ptr, ptr %l38, !tbaa !29
  %t68 = call i1 @compiler_2flower_2ecompiler_2flower_3aLowerer_2ekeepsNothing(ptr %v0, ptr %v0, ptr %t65, ptr %t66, i64 %t64)
  store i1 %t68, ptr %l40
  br label %bb16
bb16:
  %t69 = load i1, ptr %l40, !tbaa !21
  store i1 %t69, ptr %l4, !tbaa !21
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/lower:Lowerer", ptr %t70, i32 0, i32 40
  %t73 = load i64, ptr %l3, !tbaa !24
  %t74 = load i1, ptr %l4, !tbaa !21
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t72, i64 %t73, i1 %t74)
  br label %bb17
bb17:
  %t78 = load i1, ptr %l4, !tbaa !21
  store i1 %t78, ptr %rv
  br label %ret
bb18:
  %t80 = load i1, ptr %l25, !tbaa !21
  store i1 %t80, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3aLowerer_2efreshResult(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i1
  %l7 = alloca i1
  %l8 = alloca i64
  %l11 = alloca i64
  %l16 = alloca i1
  %l20 = alloca i1
  %l21 = alloca i32
  %l25 = alloca ptr
  %l29 = alloca ptr
  %l30 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb4
bb2:
  %t5 = load i64, ptr %l1, !tbaa !24
  store i64 %t5, ptr %l8, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/lower:Lowerer", ptr %t6, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t11 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %t9)
  store i64 %t11, ptr %l11
  br label %bb3
bb3:
  %t12 = load i64, ptr %l8, !tbaa !24
  %t13 = load i64, ptr %l11, !tbaa !24
  %t14 = icmp sge i64 %t12, %t13
  store i1 %t14, ptr %l7, !tbaa !21
  br label %bb4
bb4:
  %t16 = load i1, ptr %l7, !tbaa !21
  br i1 %t16, label %bb5, label %bb6
bb5:
  store i1 false, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t18 = load i64, ptr %l1, !tbaa !24
  %t20 = sub i64 -1, %t18
  store i64 %t20, ptr %l2, !tbaa !24
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/lower:Lowerer", ptr %t22, i32 0, i32 40
  %t25 = load i64, ptr %l2, !tbaa !24
  %t28 = call { i32, i1 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eGet_3cI64_2c_20Bool_3e(ptr %v0, ptr %t24, i64 %t25)
  %t29 = extractvalue { i32, i1 } %t28, 1
  %t30 = extractvalue { i32, i1 } %t28, 0
  store i32 %t30, ptr %l21
  %t31 = icmp ne i32 %t30, 0
  br i1 %t31, label %bb9, label %ok.32, !prof !99
ok.32:
  store i1 %t29, ptr %l20
  br label %bb8
bb8:
  %t33 = load i1, ptr %l20, !tbaa !21
  store i1 %t33, ptr %l16, !tbaa !21
  br label %bb15
bb9:
  br label %bb10
bb10:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/lower:Lowerer", ptr %t34, i32 0, i32 40
  %t37 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t36, i64 %t37, i1 false)
  br label %bb11
bb11:
  %t40 = load ptr, ptr %l0, !tbaa !29
  store ptr %t40, ptr %l25, !tbaa !29
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/lower:Lowerer", ptr %t41, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !29
  %t45 = load i64, ptr %l1, !tbaa !24
  %t48 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t44, i64 %t45)
  store ptr %t48, ptr %l29
  br label %bb12
bb12:
  %t49 = load ptr, ptr %l25, !tbaa !29
  %t50 = load ptr, ptr %l29, !tbaa !29
  %t51 = call i1 @compiler_2flower_2ecompiler_2flower_3aLowerer_2eallFresh(ptr %v0, ptr %v0, ptr %t49, ptr %t50)
  store i1 %t51, ptr %l30
  br label %bb13
bb13:
  %t52 = load i1, ptr %l30, !tbaa !21
  store i1 %t52, ptr %l3, !tbaa !21
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/lower:Lowerer", ptr %t53, i32 0, i32 40
  %t56 = load i64, ptr %l2, !tbaa !24
  %t57 = load i1, ptr %l3, !tbaa !21
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t55, i64 %t56, i1 %t57)
  br label %bb14
bb14:
  %t61 = load i1, ptr %l3, !tbaa !21
  store i1 %t61, ptr %rv
  br label %ret
bb15:
  %t63 = load i1, ptr %l16, !tbaa !21
  store i1 %t63, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3aLowerer_2efreshRet(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca { i64, ptr }
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca i32
  %l10 = alloca ptr
  %l11 = alloca i32
  %l12 = alloca i1
  %l13 = alloca ptr
  %l14 = alloca i1
  %l22 = alloca i1
  %l23 = alloca ptr
  %l24 = alloca i1
  %l33 = alloca i1
  %l37 = alloca i1
  %l41 = alloca { i64, ptr }
  %l43 = alloca i1
  %l44 = alloca ptr
  %l45 = alloca i1
  %l54 = alloca i1
  %l55 = alloca ptr
  %l56 = alloca i1
  %l62 = alloca ptr
  %l63 = alloca i1
  %l66 = alloca i1
  %l70 = alloca ptr
  %l72 = alloca i64
  %l73 = alloca i1
  %l74 = alloca ptr
  %l75 = alloca i1
  %l80 = alloca i1
  %l81 = alloca ptr
  %l82 = alloca i1
  %l92 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l3, !tbaa !29
  store ptr %t1, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t2 = load ptr, ptr %l13, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l13, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 5
  store i1 %t8, ptr %l14, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l14, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l3, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l4, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load ptr, ptr %l4, !tbaa !29
  %t19 = getelementptr %"compiler/typed:Promote", ptr %t17, i32 0, i32 0
  %t20 = load ptr, ptr %t19, !tbaa !29
  %t23 = call i1 @compiler_2flower_2ecompiler_2flower_3aLowerer_2efreshMade(ptr %v0, ptr %v3, ptr %t16, ptr %t20)
  store i1 %t23, ptr %l22
  br label %bb6
bb6:
  %t24 = load i1, ptr %l22, !tbaa !21
  store i1 %t24, ptr %l12, !tbaa !21
  br label %bb63
bb7:
  %t25 = load ptr, ptr %l3, !tbaa !29
  store ptr %t25, ptr %l23, !tbaa !29
  store i1 false, ptr %l24, !tbaa !21
  %t26 = load ptr, ptr %l23, !tbaa !29
  %t27 = icmp ne ptr %t26, null
  br i1 %t27, label %bb8, label %bb9
bb8:
  %t29 = load ptr, ptr %l23, !tbaa !29
  %t30 = load i64, ptr %t29, !range !{i64 0, i64 18}
  %t32 = icmp eq i64 %t30, 9
  store i1 %t32, ptr %l24, !tbaa !21
  br label %bb9
bb9:
  %t33 = load i1, ptr %l24, !tbaa !21
  br i1 %t33, label %bb10, label %bb11
bb10:
  %t34 = load ptr, ptr %l3, !tbaa !29
  %t36 = getelementptr { i64, [5 x i64] }, ptr %t34, i32 0, i32 1
  %t37 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t36, i32 0, i32 2
  %t38 = load i32, ptr %t37, !range !{i32 0, i32 54}
  store i32 %t38, ptr %l5
  %t40 = load ptr, ptr %l3, !tbaa !29
  %t42 = getelementptr { i64, [5 x i64] }, ptr %t40, i32 0, i32 1
  %t43 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t42, i32 0, i32 4
  %t44 = load { i64, ptr }, ptr %t43
  store { i64, ptr } %t44, ptr %l6, !tbaa !27
  br label %bb12
bb11:
  br label %bb20
bb12:
  %t46 = load i32, ptr %l5, !range !{i32 0, i32 54}
  %t48 = trunc i64 20 to i32
  %t49 = icmp eq i32 %t46, %t48
  br i1 %t49, label %bb13, label %bb14
bb13:
  %t51 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t53 = extractvalue { i64, ptr } %t51, 0
  %t55 = icmp eq i64 %t53, 1
  store i1 %t55, ptr %l33, !tbaa !21
  br label %bb15
bb14:
  store i1 false, ptr %l33, !tbaa !21
  br label %bb15
bb15:
  %t57 = load i1, ptr %l33, !tbaa !21
  br i1 %t57, label %bb16, label %bb17
bb16:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = load ptr, ptr %l1, !tbaa !29
  %t60 = load ptr, ptr %l2, !tbaa !29
  %t61 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t61, ptr %l41, !tbaa !27
  %t62 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !27
  %t64 = getelementptr ptr, ptr %t63, i64 0
  %t65 = load ptr, ptr %t64, !tbaa !39
  %t70 = call i1 @compiler_2flower_2ecompiler_2flower_3aLowerer_2efreshRet(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t58, ptr %t59, ptr %t60, ptr %t65)
  store i1 %t70, ptr %l43
  br label %bb18
bb17:
  store i1 false, ptr %l37, !tbaa !21
  br label %bb19
bb18:
  %t71 = load i1, ptr %l43, !tbaa !21
  store i1 %t71, ptr %l37, !tbaa !21
  br label %bb19
bb19:
  %t72 = load i1, ptr %l37, !tbaa !21
  store i1 %t72, ptr %l12, !tbaa !21
  br label %bb63
bb20:
  %t73 = load ptr, ptr %l3, !tbaa !29
  store ptr %t73, ptr %l44, !tbaa !29
  store i1 false, ptr %l45, !tbaa !21
  %t74 = load ptr, ptr %l44, !tbaa !29
  %t75 = icmp ne ptr %t74, null
  br i1 %t75, label %bb21, label %bb22
bb21:
  %t77 = load ptr, ptr %l44, !tbaa !29
  %t78 = load i64, ptr %t77, !range !{i64 0, i64 18}
  %t80 = icmp eq i64 %t78, 17
  store i1 %t80, ptr %l45, !tbaa !21
  br label %bb22
bb22:
  %t81 = load i1, ptr %l45, !tbaa !21
  br i1 %t81, label %bb23, label %bb24
bb23:
  %t82 = load ptr, ptr %l3, !tbaa !29
  %t84 = getelementptr { i64, [5 x i64] }, ptr %t82, i32 0, i32 1
  %t85 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t84, i32 0, i32 2
  %t86 = load ptr, ptr %t85
  store ptr %t86, ptr %l7, !tbaa !29
  br label %bb25
bb24:
  br label %bb27
bb25:
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t89 = load ptr, ptr %l1, !tbaa !29
  %t90 = load ptr, ptr %l2, !tbaa !29
  %t91 = load ptr, ptr %l7, !tbaa !29
  %t96 = call i1 @compiler_2flower_2ecompiler_2flower_3aLowerer_2efreshRet(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t88, ptr %t89, ptr %t90, ptr %t91)
  store i1 %t96, ptr %l54
  br label %bb26
bb26:
  %t97 = load i1, ptr %l54, !tbaa !21
  store i1 %t97, ptr %l12, !tbaa !21
  br label %bb63
bb27:
  %t98 = load ptr, ptr %l3, !tbaa !29
  store ptr %t98, ptr %l55, !tbaa !29
  store i1 false, ptr %l56, !tbaa !21
  %t99 = load ptr, ptr %l55, !tbaa !29
  %t100 = icmp ne ptr %t99, null
  br i1 %t100, label %bb28, label %bb29
bb28:
  %t102 = load ptr, ptr %l55, !tbaa !29
  %t103 = load i64, ptr %t102, !range !{i64 0, i64 18}
  %t105 = icmp eq i64 %t103, 6
  store i1 %t105, ptr %l56, !tbaa !21
  br label %bb29
bb29:
  %t106 = load i1, ptr %l56, !tbaa !21
  br i1 %t106, label %bb30, label %bb31
bb30:
  %t107 = load ptr, ptr %l3, !tbaa !29
  %t109 = getelementptr { i64, [5 x i64] }, ptr %t107, i32 0, i32 1
  %t110 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t109, i32 0, i32 2
  %t111 = load ptr, ptr %t110
  store ptr %t111, ptr %l8, !tbaa !29
  br label %bb32
bb31:
  br label %bb40
bb32:
  %t113 = load ptr, ptr %l8, !tbaa !29
  %t115 = getelementptr %"compiler/typed:Call", ptr %t113, i32 0, i32 0
  %t116 = load ptr, ptr %t115, !tbaa !29
  store ptr %t116, ptr %l62, !tbaa !29
  store i1 false, ptr %l63, !tbaa !21
  %t117 = load ptr, ptr %l62, !tbaa !29
  %t118 = icmp ne ptr %t117, null
  br i1 %t118, label %bb33, label %bb34
bb33:
  %t120 = load ptr, ptr %l62, !tbaa !29
  %t121 = load i64, ptr %t120, !range !{i64 0, i64 5}
  %t123 = icmp eq i64 %t121, 0
  store i1 %t123, ptr %l63, !tbaa !21
  br label %bb34
bb34:
  %t124 = load i1, ptr %l63, !tbaa !21
  br i1 %t124, label %bb35, label %bb36
bb35:
  %t125 = load ptr, ptr %l8, !tbaa !29
  %t127 = getelementptr %"compiler/typed:Call", ptr %t125, i32 0, i32 0
  %t128 = load ptr, ptr %t127, !tbaa !29
  %t130 = getelementptr { i64, [3 x i64] }, ptr %t128, i32 0, i32 1
  %t131 = getelementptr { i32 }, ptr %t130, i32 0, i32 0
  %t132 = load i32, ptr %t131
  store i32 %t132, ptr %l9, !tbaa !23
  %t134 = load ptr, ptr %l0, !tbaa !29
  store ptr %t134, ptr %l70, !tbaa !29
  %t135 = load ptr, ptr %l8, !tbaa !29
  %t137 = call i64 @compiler_2ftyped_2eCalleeBody(ptr %v3, ptr %t135)
  store i64 %t137, ptr %l72
  br label %bb37
bb36:
  store i1 false, ptr %l66, !tbaa !21
  br label %bb39
bb37:
  %t138 = load ptr, ptr %l70, !tbaa !29
  %t139 = load i64, ptr %l72, !tbaa !24
  %t140 = call i1 @compiler_2flower_2ecompiler_2flower_3aLowerer_2efreshResult(ptr %v0, ptr %t138, i64 %t139)
  store i1 %t140, ptr %l73
  br label %bb38
bb38:
  %t141 = load i1, ptr %l73, !tbaa !21
  store i1 %t141, ptr %l66, !tbaa !21
  br label %bb39
bb39:
  %t142 = load i1, ptr %l66, !tbaa !21
  store i1 %t142, ptr %l12, !tbaa !21
  br label %bb63
bb40:
  %t143 = load ptr, ptr %l3, !tbaa !29
  store ptr %t143, ptr %l74, !tbaa !29
  store i1 false, ptr %l75, !tbaa !21
  %t144 = load ptr, ptr %l74, !tbaa !29
  %t145 = icmp ne ptr %t144, null
  br i1 %t145, label %bb41, label %bb42
bb41:
  %t147 = load ptr, ptr %l74, !tbaa !29
  %t148 = load i64, ptr %t147, !range !{i64 0, i64 18}
  %t150 = icmp eq i64 %t148, 2
  store i1 %t150, ptr %l75, !tbaa !21
  br label %bb42
bb42:
  %t151 = load i1, ptr %l75, !tbaa !21
  br i1 %t151, label %bb43, label %bb44
bb43:
  %t152 = load ptr, ptr %l3, !tbaa !29
  %t154 = getelementptr { i64, [5 x i64] }, ptr %t152, i32 0, i32 1
  %t155 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t154, i32 0, i32 2
  %t156 = load ptr, ptr %t155
  store ptr %t156, ptr %l10, !tbaa !29
  br label %bb45
bb44:
  br label %bb58
bb45:
  %t158 = load ptr, ptr %l10, !tbaa !29
  store ptr %t158, ptr %l81, !tbaa !29
  store i1 false, ptr %l82, !tbaa !21
  %t159 = load ptr, ptr %l81, !tbaa !29
  %t160 = icmp ne ptr %t159, null
  br i1 %t160, label %bb46, label %bb47
bb46:
  %t162 = load ptr, ptr %l81, !tbaa !29
  %t163 = load i64, ptr %t162, !range !{i64 0, i64 8}
  %t165 = icmp eq i64 %t163, 0
  store i1 %t165, ptr %l82, !tbaa !21
  br label %bb47
bb47:
  %t166 = load i1, ptr %l82, !tbaa !21
  br i1 %t166, label %bb48, label %bb49
bb48:
  %t167 = load ptr, ptr %l10, !tbaa !29
  %t169 = getelementptr { i64, [4 x i64] }, ptr %t167, i32 0, i32 1
  %t170 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t169, i32 0, i32 2
  %t171 = load i32, ptr %t170
  store i32 %t171, ptr %l11, !tbaa !23
  br label %bb50
bb49:
  br label %bb52
bb50:
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t174 = load ptr, ptr %l1, !tbaa !29
  %t175 = load ptr, ptr %l2, !tbaa !29
  %t176 = load i32, ptr %l11, !tbaa !23
  %t178 = sext i32 %t176 to i64
  %t183 = call i1 @compiler_2flower_2ecompiler_2flower_3aLowerer_2efreshLocal(ptr %v0, ptr %v1, ptr %v2, ptr %t173, ptr %t174, ptr %t175, i64 %t178)
  store i1 %t183, ptr %l92
  br label %bb51
bb51:
  %t184 = load i1, ptr %l92, !tbaa !21
  store i1 %t184, ptr %l80, !tbaa !21
  br label %bb57
bb52:
  br i1 true, label %bb53, label %bb54
bb53:
  br label %bb55
bb54:
  br label %bb56
bb55:
  store i1 false, ptr %l80, !tbaa !21
  br label %bb57
bb56:
  call void @__olang_check_failed(ptr @olang_loc_7e98ebbcfc7ae681_fbeaec9fd6de6485)
  unreachable
bb57:
  %t185 = load i1, ptr %l80, !tbaa !21
  store i1 %t185, ptr %l12, !tbaa !21
  br label %bb63
bb58:
  br i1 true, label %bb59, label %bb60
bb59:
  br label %bb61
bb60:
  br label %bb62
bb61:
  store i1 false, ptr %l12, !tbaa !21
  br label %bb63
bb62:
  call void @__olang_check_failed(ptr @olang_loc_80862e2151cf42f0_7c300e18841fcdd4)
  unreachable
bb63:
  %t186 = load i1, ptr %l12, !tbaa !21
  store i1 %t186, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2flower_2ecompiler_2flower_3aLowerer_2ehelperTy(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l5 = alloca i1
  %l8 = alloca i1
  %l13 = alloca i1
  %l17 = alloca i32
  %l23 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l1, !range !{i32 0, i32 10}
  %t3 = trunc i64 4 to i32
  %t4 = icmp eq i32 %t1, %t3
  br i1 %t4, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l5, !tbaa !21
  br label %bb3
bb2:
  %t6 = load i32, ptr %l1, !range !{i32 0, i32 10}
  %t8 = trunc i64 5 to i32
  %t9 = icmp eq i32 %t6, %t8
  store i1 %t9, ptr %l5, !tbaa !21
  br label %bb3
bb3:
  %t11 = load i1, ptr %l5, !tbaa !21
  br i1 %t11, label %bb4, label %bb5
bb4:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/lower:Lowerer", ptr %t12, i32 0, i32 0
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t17 = getelementptr %"compiler/generic:Program", ptr %t15, i32 0, i32 2
  %t18 = load i32, ptr %l2, !tbaa !23
  %t21 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclaresCopy(ptr %v0, ptr %t17, i32 %t18)
  store i1 %t21, ptr %l13
  br label %bb6
bb5:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb7
bb6:
  %t22 = load i1, ptr %l13, !tbaa !21
  store i1 %t22, ptr %l8, !tbaa !21
  br label %bb7
bb7:
  %t23 = load i1, ptr %l8, !tbaa !21
  br i1 %t23, label %bb8, label %bb9
bb8:
  %t24 = load i32, ptr %l2, !tbaa !23
  store i32 %t24, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t26 = load i32, ptr %l1, !range !{i32 0, i32 10}
  %t28 = trunc i64 0 to i32
  %t29 = icmp eq i32 %t26, %t28
  br i1 %t29, label %bb11, label %bb12
bb11:
  %t31 = load i32, ptr %l2, !tbaa !23
  store i32 %t31, ptr %l17, !tbaa !23
  br label %bb14
bb12:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/lower:Lowerer", ptr %t33, i32 0, i32 0
  %t36 = load ptr, ptr %t35, !tbaa !29
  %t38 = getelementptr %"compiler/generic:Program", ptr %t36, i32 0, i32 2
  %t39 = load i32, ptr %l2, !tbaa !23
  %t42 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eUnnamed(ptr %v0, ptr %t38, i32 %t39)
  store i32 %t42, ptr %l23
  br label %bb13
bb13:
  %t43 = load i32, ptr %l23, !tbaa !23
  store i32 %t43, ptr %l17, !tbaa !23
  br label %bb14
bb14:
  %t44 = load i32, ptr %l17, !tbaa !23
  store i32 %t44, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3aLowerer_2epreserves(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i1
  %l8 = alloca i1
  %l9 = alloca i64
  %l12 = alloca i64
  %l14 = alloca i1
  %l22 = alloca i1
  %l26 = alloca i1
  %l27 = alloca i32
  %l31 = alloca ptr
  %l35 = alloca ptr
  %l37 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb4
bb2:
  %t5 = load i64, ptr %l1, !tbaa !24
  store i64 %t5, ptr %l9, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/lower:Lowerer", ptr %t6, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t11 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %t9)
  store i64 %t11, ptr %l12
  br label %bb3
bb3:
  %t12 = load i64, ptr %l9, !tbaa !24
  %t13 = load i64, ptr %l12, !tbaa !24
  %t14 = icmp sge i64 %t12, %t13
  store i1 %t14, ptr %l8, !tbaa !21
  br label %bb4
bb4:
  %t16 = load i1, ptr %l8, !tbaa !21
  br i1 %t16, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l14, !tbaa !21
  br label %bb7
bb6:
  %t17 = load i64, ptr %l2, !tbaa !24
  %t19 = icmp sge i64 %t17, 64
  store i1 %t19, ptr %l14, !tbaa !21
  br label %bb7
bb7:
  %t21 = load i1, ptr %l14, !tbaa !21
  br i1 %t21, label %bb8, label %bb9
bb8:
  store i1 false, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t23 = load i64, ptr %l1, !tbaa !24
  %t25 = mul i64 %t23, 64
  %t26 = load i64, ptr %l2, !tbaa !24
  %t29 = add i64 %t25, %t26
  store i64 %t29, ptr %l3, !tbaa !24
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/lower:Lowerer", ptr %t31, i32 0, i32 40
  %t34 = load i64, ptr %l3, !tbaa !24
  %t37 = call { i32, i1 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eGet_3cI64_2c_20Bool_3e(ptr %v0, ptr %t33, i64 %t34)
  %t38 = extractvalue { i32, i1 } %t37, 1
  %t39 = extractvalue { i32, i1 } %t37, 0
  store i32 %t39, ptr %l27
  %t40 = icmp ne i32 %t39, 0
  br i1 %t40, label %bb12, label %ok.41, !prof !99
ok.41:
  store i1 %t38, ptr %l26
  br label %bb11
bb11:
  %t42 = load i1, ptr %l26, !tbaa !21
  store i1 %t42, ptr %l22, !tbaa !21
  br label %bb18
bb12:
  br label %bb13
bb13:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/lower:Lowerer", ptr %t43, i32 0, i32 40
  %t46 = load i64, ptr %l3, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t45, i64 %t46, i1 false)
  br label %bb14
bb14:
  %t49 = load ptr, ptr %l0, !tbaa !29
  store ptr %t49, ptr %l31, !tbaa !29
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/lower:Lowerer", ptr %t50, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !29
  %t54 = load i64, ptr %l1, !tbaa !24
  %t57 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t53, i64 %t54)
  store ptr %t57, ptr %l35
  br label %bb15
bb15:
  %t58 = load i64, ptr %l2, !tbaa !24
  %t59 = load ptr, ptr %l31, !tbaa !29
  %t60 = load ptr, ptr %l35, !tbaa !29
  %t62 = call i1 @compiler_2flower_2ecompiler_2flower_3aLowerer_2ekeepsParts(ptr %v0, ptr %v0, ptr %t59, ptr %t60, i64 %t58)
  store i1 %t62, ptr %l37
  br label %bb16
bb16:
  %t63 = load i1, ptr %l37, !tbaa !21
  store i1 %t63, ptr %l4, !tbaa !21
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/lower:Lowerer", ptr %t64, i32 0, i32 40
  %t67 = load i64, ptr %l3, !tbaa !24
  %t68 = load i1, ptr %l4, !tbaa !21
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t66, i64 %t67, i1 %t68)
  br label %bb17
bb17:
  %t72 = load i1, ptr %l4, !tbaa !21
  store i1 %t72, ptr %rv
  br label %ret
bb18:
  %t74 = load i1, ptr %l22, !tbaa !21
  store i1 %t74, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3aLowerer_2estartLocal(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca %"compiler/typed:Local"
  %l4 = alloca ptr
  %l7 = alloca ptr
  %l10 = alloca %"compiler/typed:Local"
  %l14 = alloca i1
  %l19 = alloca i1
  %l20 = alloca i1
  %l24 = alloca i1
  %l25 = alloca i1
  %l29 = alloca ptr
  %l32 = alloca ptr
  %l33 = alloca ptr
  %l37 = alloca ptr
  %l41 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/typed:LocalUses", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/typed:Body", ptr %t4, i32 0, i32 7
  store ptr %t6, ptr %l7, !tbaa !29
  %t7 = load i64, ptr %l2, !tbaa !24
  %t8 = load ptr, ptr %l7, !tbaa !29
  %t9 = call ptr @__olang_scope_or(ptr %v2, ptr %t8)
  %t10 = call ptr @__olang_scope_hold(ptr %t9)
  %t11 = ptrtoint ptr %t10 to i64
  %t13 = inttoptr i64 %t11 to ptr
  %t14 = load ptr, ptr %l7, !tbaa !29
  %t16 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %t13, ptr %t14, i64 %t7)
  store %"compiler/typed:Local" %t16, ptr %l10
  br label %bb1
bb1:
  %t17 = load %"compiler/typed:Local", ptr %l10
  store %"compiler/typed:Local" %t17, ptr %l3
  %t18 = getelementptr %"compiler/typed:Local", ptr %l3, i32 0, i32 4
  %t19 = load i32, ptr %t18, !range !{i32 0, i32 7}
  %t21 = trunc i64 1 to i32
  %t22 = icmp eq i32 %t19, %t21
  %t24 = xor i1 %t22, true
  br i1 %t24, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l14, !tbaa !21
  br label %bb5
bb3:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/lower:Lowerer", ptr %t26, i32 0, i32 0
  %t29 = load ptr, ptr %t28, !tbaa !29
  %t31 = getelementptr %"compiler/generic:Program", ptr %t29, i32 0, i32 2
  %t32 = getelementptr %"compiler/typed:Local", ptr %l3, i32 0, i32 2
  %t33 = load i32, ptr %t32, !tbaa !23
  %t36 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t31, i32 %t33)
  store i1 %t36, ptr %l19
  br label %bb4
bb4:
  %t37 = load i1, ptr %l19, !tbaa !21
  store i1 %t37, ptr %l14, !tbaa !21
  br label %bb5
bb5:
  %t38 = load i1, ptr %l14, !tbaa !21
  br i1 %t38, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l20, !tbaa !21
  br label %bb9
bb7:
  %t39 = load ptr, ptr %l1, !tbaa !29
  %t41 = getelementptr %"compiler/typed:LocalUses", ptr %t39, i32 0, i32 4
  %t42 = load i64, ptr %l2, !tbaa !24
  %t45 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v1, ptr %t41, i64 %t42)
  store i1 %t45, ptr %l24
  br label %bb8
bb8:
  %t46 = load i1, ptr %l24, !tbaa !21
  store i1 %t46, ptr %l20, !tbaa !21
  br label %bb9
bb9:
  %t47 = load i1, ptr %l20, !tbaa !21
  br i1 %t47, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l25, !tbaa !21
  br label %bb13
bb11:
  %t48 = load ptr, ptr %l1, !tbaa !29
  %t50 = getelementptr %"compiler/typed:LocalUses", ptr %t48, i32 0, i32 20
  %t51 = load i64, ptr %l2, !tbaa !24
  %t54 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_3f_26_3e_2eAt__H2e4a6474e10b73ca754517844b8d7700(ptr %v1, ptr %s0, ptr %t50, i64 %t51)
  store ptr %t54, ptr %l29
  br label %bb12
bb12:
  %t55 = load ptr, ptr %l29, !tbaa !29
  %t56 = icmp eq ptr %t55, null
  store i1 %t56, ptr %l25, !tbaa !21
  br label %bb13
bb13:
  %t58 = load i1, ptr %l25, !tbaa !21
  br i1 %t58, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  %t60 = load ptr, ptr %l0, !tbaa !29
  store ptr %t60, ptr %l32, !tbaa !29
  %t61 = load ptr, ptr %l1, !tbaa !29
  store ptr %t61, ptr %l33, !tbaa !29
  %t62 = load ptr, ptr %l1, !tbaa !29
  %t64 = getelementptr %"compiler/typed:LocalUses", ptr %t62, i32 0, i32 20
  %t65 = load i64, ptr %l2, !tbaa !24
  %t68 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_3f_26_3e_2eAt__H2e4a6474e10b73ca754517844b8d7700(ptr %v1, ptr %v1, ptr %t64, i64 %t65)
  store ptr %t68, ptr %l37
  br label %bb17
bb17:
  %t69 = load ptr, ptr %l37, !tbaa !29
  store ptr %t69, ptr %l4, !tbaa !29
  %t70 = load ptr, ptr %l4, !tbaa !29
  %t72 = icmp eq ptr %t70, null
  br i1 %t72, label %bb18, label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_298df02769e60406_e8c7ebf3f84a062)
  unreachable
bb19:
  br label %bb20
bb20:
  %t74 = load ptr, ptr %l4, !tbaa !29
  %t75 = load ptr, ptr %l32, !tbaa !29
  %t76 = load ptr, ptr %l33, !tbaa !29
  %t78 = call i1 @compiler_2flower_2ecompiler_2flower_3aLowerer_2estartOf(ptr %v0, ptr %v1, ptr %v1, ptr %v2, ptr %t75, ptr %t76, ptr %t74)
  store i1 %t78, ptr %l41
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s0)
  %t79 = load i1, ptr %l41, !tbaa !21
  store i1 %t79, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3aLowerer_2estartMade(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l2 = alloca ptr
  %l14 = alloca i1
  %l18 = alloca { i64, ptr }
  %l20 = alloca i1
  %l24 = alloca i1
  %rv = alloca i1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Make", ptr %t1, i32 0, i32 4
  %t4 = load i32, ptr %t3, !tbaa !23
  %t6 = icmp slt i32 %t4, 0
  br i1 %t6, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t9 = load ptr, ptr %l2, !tbaa !29
  %t11 = getelementptr %"compiler/typed:Make", ptr %t9, i32 0, i32 0
  %t12 = load i32, ptr %t11, !range !{i32 0, i32 5}
  %t14 = trunc i64 4 to i32
  %t15 = icmp eq i32 %t12, %t14
  br i1 %t15, label %bb4, label %bb5
bb4:
  %t17 = load ptr, ptr %l2, !tbaa !29
  %t19 = getelementptr %"compiler/typed:Make", ptr %t17, i32 0, i32 2
  %t20 = load { i64, ptr }, ptr %t19, !tbaa !27
  %t22 = extractvalue { i64, ptr } %t20, 0
  %t24 = icmp eq i64 %t22, 1
  br i1 %t24, label %bb6, label %bb7
bb5:
  br label %bb10
bb6:
  %t28 = load ptr, ptr %l2, !tbaa !29
  %t30 = getelementptr %"compiler/typed:Make", ptr %t28, i32 0, i32 2
  %t31 = load { i64, ptr }, ptr %t30, !tbaa !27
  store { i64, ptr } %t31, ptr %l18, !tbaa !27
  %t32 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !27
  %t34 = getelementptr ptr, ptr %t33, i64 0
  %t35 = load ptr, ptr %t34, !tbaa !39
  %t39 = call i1 @compiler_2flower_2ecompiler_2flower_3aLowerer_2estartOf(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %t35)
  store i1 %t39, ptr %l20
  br label %bb8
bb7:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb9
bb8:
  %t40 = load i1, ptr %l20, !tbaa !21
  store i1 %t40, ptr %l14, !tbaa !21
  br label %bb9
bb9:
  %t41 = load i1, ptr %l14, !tbaa !21
  store i1 %t41, ptr %rv
  br label %ret
bb10:
  %t42 = load ptr, ptr %l2, !tbaa !29
  %t44 = getelementptr %"compiler/typed:Make", ptr %t42, i32 0, i32 0
  %t45 = load i32, ptr %t44, !range !{i32 0, i32 5}
  %t47 = trunc i64 2 to i32
  %t48 = icmp eq i32 %t45, %t47
  br i1 %t48, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l24, !tbaa !21
  br label %bb13
bb12:
  %t50 = load ptr, ptr %l2, !tbaa !29
  %t52 = getelementptr %"compiler/typed:Make", ptr %t50, i32 0, i32 0
  %t53 = load i32, ptr %t52, !range !{i32 0, i32 5}
  %t55 = trunc i64 3 to i32
  %t56 = icmp eq i32 %t53, %t55
  store i1 %t56, ptr %l24, !tbaa !21
  br label %bb13
bb13:
  %t58 = load i1, ptr %l24, !tbaa !21
  store i1 %t58, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3aLowerer_2estartOf(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l6 = alloca i32
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i1
  %l11 = alloca ptr
  %l12 = alloca i1
  %l15 = alloca ptr
  %l16 = alloca i1
  %l24 = alloca i1
  %l25 = alloca ptr
  %l26 = alloca i1
  %l35 = alloca i1
  %l39 = alloca i1
  %l42 = alloca { i64, ptr }
  %l44 = alloca i1
  %l45 = alloca ptr
  %l46 = alloca i1
  %l49 = alloca i1
  %l51 = alloca ptr
  %l52 = alloca i1
  %l62 = alloca i1
  %l63 = alloca ptr
  %l64 = alloca i1
  %l73 = alloca i1
  %l74 = alloca ptr
  %l75 = alloca ptr
  %l81 = alloca i1
  %l82 = alloca i1
  %l87 = alloca i1
  %l88 = alloca ptr
  %l89 = alloca i1
  %l98 = alloca i1
  %l99 = alloca ptr
  %l100 = alloca ptr
  %l106 = alloca i1
  %l107 = alloca ptr
  %l108 = alloca i1
  %l116 = alloca i1
  %l117 = alloca ptr
  %l119 = alloca ptr
  %l120 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  store ptr %t1, ptr %l11, !tbaa !29
  store i1 false, ptr %l12, !tbaa !21
  %t2 = load ptr, ptr %l11, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l11, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 16
  store i1 %t8, ptr %l12, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l12, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb6
bb5:
  store i1 true, ptr %l10, !tbaa !21
  br label %bb82
bb6:
  %t10 = load ptr, ptr %l2, !tbaa !29
  store ptr %t10, ptr %l15, !tbaa !29
  store i1 false, ptr %l16, !tbaa !21
  %t11 = load ptr, ptr %l15, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb7, label %bb8
bb7:
  %t14 = load ptr, ptr %l15, !tbaa !29
  %t15 = load i64, ptr %t14, !range !{i64 0, i64 18}
  %t17 = icmp eq i64 %t15, 7
  store i1 %t17, ptr %l16, !tbaa !21
  br label %bb8
bb8:
  %t18 = load i1, ptr %l16, !tbaa !21
  br i1 %t18, label %bb9, label %bb10
bb9:
  %t19 = load ptr, ptr %l2, !tbaa !29
  %t21 = getelementptr { i64, [5 x i64] }, ptr %t19, i32 0, i32 1
  %t22 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t21, i32 0, i32 2
  %t23 = load ptr, ptr %t22
  store ptr %t23, ptr %l3, !tbaa !29
  br label %bb11
bb10:
  br label %bb13
bb11:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t26 = load ptr, ptr %l1, !tbaa !29
  %t27 = load ptr, ptr %l3, !tbaa !29
  %t31 = call i1 @compiler_2flower_2ecompiler_2flower_3aLowerer_2estartMade(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t25, ptr %t26, ptr %t27)
  store i1 %t31, ptr %l24
  br label %bb12
bb12:
  %t32 = load i1, ptr %l24, !tbaa !21
  store i1 %t32, ptr %l10, !tbaa !21
  br label %bb82
bb13:
  %t33 = load ptr, ptr %l2, !tbaa !29
  store ptr %t33, ptr %l25, !tbaa !29
  store i1 false, ptr %l26, !tbaa !21
  %t34 = load ptr, ptr %l25, !tbaa !29
  %t35 = icmp ne ptr %t34, null
  br i1 %t35, label %bb14, label %bb15
bb14:
  %t37 = load ptr, ptr %l25, !tbaa !29
  %t38 = load i64, ptr %t37, !range !{i64 0, i64 18}
  %t40 = icmp eq i64 %t38, 9
  store i1 %t40, ptr %l26, !tbaa !21
  br label %bb15
bb15:
  %t41 = load i1, ptr %l26, !tbaa !21
  br i1 %t41, label %bb16, label %bb17
bb16:
  %t42 = load ptr, ptr %l2, !tbaa !29
  %t44 = getelementptr { i64, [5 x i64] }, ptr %t42, i32 0, i32 1
  %t45 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t44, i32 0, i32 2
  %t46 = load i32, ptr %t45, !range !{i32 0, i32 54}
  store i32 %t46, ptr %l4
  %t48 = load ptr, ptr %l2, !tbaa !29
  %t50 = getelementptr { i64, [5 x i64] }, ptr %t48, i32 0, i32 1
  %t51 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t50, i32 0, i32 4
  %t52 = load { i64, ptr }, ptr %t51
  store { i64, ptr } %t52, ptr %l5, !tbaa !27
  br label %bb18
bb17:
  br label %bb26
bb18:
  %t54 = load i32, ptr %l4, !range !{i32 0, i32 54}
  %t56 = trunc i64 20 to i32
  %t57 = icmp eq i32 %t54, %t56
  br i1 %t57, label %bb19, label %bb20
bb19:
  %t59 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t61 = extractvalue { i64, ptr } %t59, 0
  %t63 = icmp eq i64 %t61, 1
  store i1 %t63, ptr %l35, !tbaa !21
  br label %bb21
bb20:
  store i1 false, ptr %l35, !tbaa !21
  br label %bb21
bb21:
  %t65 = load i1, ptr %l35, !tbaa !21
  br i1 %t65, label %bb22, label %bb23
bb22:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t67 = load ptr, ptr %l1, !tbaa !29
  %t68 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t68, ptr %l42, !tbaa !27
  %t69 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !27
  %t71 = getelementptr ptr, ptr %t70, i64 0
  %t72 = load ptr, ptr %t71, !tbaa !39
  %t76 = call i1 @compiler_2flower_2ecompiler_2flower_3aLowerer_2estartOf(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t66, ptr %t67, ptr %t72)
  store i1 %t76, ptr %l44
  br label %bb24
bb23:
  store i1 false, ptr %l39, !tbaa !21
  br label %bb25
bb24:
  %t77 = load i1, ptr %l44, !tbaa !21
  store i1 %t77, ptr %l39, !tbaa !21
  br label %bb25
bb25:
  %t78 = load i1, ptr %l39, !tbaa !21
  store i1 %t78, ptr %l10, !tbaa !21
  br label %bb82
bb26:
  %t79 = load ptr, ptr %l2, !tbaa !29
  store ptr %t79, ptr %l45, !tbaa !29
  store i1 false, ptr %l46, !tbaa !21
  %t80 = load ptr, ptr %l45, !tbaa !29
  %t81 = icmp ne ptr %t80, null
  br i1 %t81, label %bb27, label %bb28
bb27:
  %t83 = load ptr, ptr %l45, !tbaa !29
  %t84 = load i64, ptr %t83, !range !{i64 0, i64 18}
  %t86 = icmp eq i64 %t84, 2
  store i1 %t86, ptr %l46, !tbaa !21
  br label %bb28
bb28:
  %t87 = load i1, ptr %l46, !tbaa !21
  br i1 %t87, label %bb29, label %bb30
bb29:
  %t88 = load ptr, ptr %l2, !tbaa !29
  %t90 = getelementptr { i64, [5 x i64] }, ptr %t88, i32 0, i32 1
  %t91 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t90, i32 0, i32 2
  %t92 = load ptr, ptr %t91
  store ptr %t92, ptr %l51, !tbaa !29
  store i1 false, ptr %l52, !tbaa !21
  %t93 = load ptr, ptr %l51, !tbaa !29
  %t94 = icmp ne ptr %t93, null
  br i1 %t94, label %bb31, label %bb32
bb30:
  store i1 false, ptr %l49, !tbaa !21
  br label %bb33
bb31:
  %t96 = load ptr, ptr %l51, !tbaa !29
  %t97 = load i64, ptr %t96, !range !{i64 0, i64 8}
  %t99 = icmp eq i64 %t97, 0
  store i1 %t99, ptr %l52, !tbaa !21
  br label %bb32
bb32:
  %t100 = load i1, ptr %l52, !tbaa !21
  store i1 %t100, ptr %l49, !tbaa !21
  br label %bb33
bb33:
  %t101 = load i1, ptr %l49, !tbaa !21
  br i1 %t101, label %bb34, label %bb35
bb34:
  %t102 = load ptr, ptr %l2, !tbaa !29
  %t104 = getelementptr { i64, [5 x i64] }, ptr %t102, i32 0, i32 1
  %t105 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t104, i32 0, i32 2
  %t106 = load ptr, ptr %t105
  %t108 = getelementptr { i64, [4 x i64] }, ptr %t106, i32 0, i32 1
  %t109 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t108, i32 0, i32 2
  %t110 = load i32, ptr %t109
  store i32 %t110, ptr %l6, !tbaa !23
  br label %bb36
bb35:
  br label %bb38
bb36:
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t113 = load ptr, ptr %l1, !tbaa !29
  %t114 = load i32, ptr %l6, !tbaa !23
  %t116 = sext i32 %t114 to i64
  %t120 = call i1 @compiler_2flower_2ecompiler_2flower_3aLowerer_2estartLocal(ptr %v0, ptr %v1, ptr %v3, ptr %t112, ptr %t113, i64 %t116)
  store i1 %t120, ptr %l62
  br label %bb37
bb37:
  %t121 = load i1, ptr %l62, !tbaa !21
  store i1 %t121, ptr %l10, !tbaa !21
  br label %bb82
bb38:
  %t122 = load ptr, ptr %l2, !tbaa !29
  store ptr %t122, ptr %l63, !tbaa !29
  store i1 false, ptr %l64, !tbaa !21
  %t123 = load ptr, ptr %l63, !tbaa !29
  %t124 = icmp ne ptr %t123, null
  br i1 %t124, label %bb39, label %bb40
bb39:
  %t126 = load ptr, ptr %l63, !tbaa !29
  %t127 = load i64, ptr %t126, !range !{i64 0, i64 18}
  %t129 = icmp eq i64 %t127, 11
  store i1 %t129, ptr %l64, !tbaa !21
  br label %bb40
bb40:
  %t130 = load i1, ptr %l64, !tbaa !21
  br i1 %t130, label %bb41, label %bb42
bb41:
  %t131 = load ptr, ptr %l2, !tbaa !29
  %t133 = getelementptr { i64, [5 x i64] }, ptr %t131, i32 0, i32 1
  %t134 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t133, i32 0, i32 2
  %t135 = load ptr, ptr %t134
  store ptr %t135, ptr %l7, !tbaa !29
  br label %bb43
bb42:
  br label %bb55
bb43:
  %t137 = load ptr, ptr %l7, !tbaa !29
  %t139 = getelementptr %"compiler/typed:Cond", ptr %t137, i32 0, i32 1
  %t140 = load ptr, ptr %t139, !tbaa !29
  %t142 = icmp eq ptr %t140, null
  %t144 = xor i1 %t142, true
  br i1 %t144, label %bb44, label %bb45
bb44:
  %t146 = load ptr, ptr %l0, !tbaa !29
  store ptr %t146, ptr %l74, !tbaa !29
  %t147 = load ptr, ptr %l1, !tbaa !29
  store ptr %t147, ptr %l75, !tbaa !29
  %t148 = load ptr, ptr %l7, !tbaa !29
  %t150 = getelementptr %"compiler/typed:Cond", ptr %t148, i32 0, i32 1
  %t151 = load ptr, ptr %t150, !tbaa !29
  %t153 = icmp eq ptr %t151, null
  br i1 %t153, label %bb46, label %bb47
bb45:
  store i1 false, ptr %l73, !tbaa !21
  br label %bb50
bb46:
  call void @__olang_check_failed(ptr @olang_loc_83dfbaab25479658_1c809850a1eedc14)
  unreachable
bb47:
  br label %bb48
bb48:
  %t155 = load ptr, ptr %l7, !tbaa !29
  %t157 = getelementptr %"compiler/typed:Cond", ptr %t155, i32 0, i32 1
  %t158 = load ptr, ptr %t157, !tbaa !29
  %t159 = load ptr, ptr %l74, !tbaa !29
  %t160 = load ptr, ptr %l75, !tbaa !29
  %t162 = call i1 @compiler_2flower_2ecompiler_2flower_3aLowerer_2estartOf(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t159, ptr %t160, ptr %t158)
  store i1 %t162, ptr %l81
  br label %bb49
bb49:
  %t163 = load i1, ptr %l81, !tbaa !21
  store i1 %t163, ptr %l73, !tbaa !21
  br label %bb50
bb50:
  %t164 = load i1, ptr %l73, !tbaa !21
  br i1 %t164, label %bb51, label %bb52
bb51:
  %t165 = load ptr, ptr %l0, !tbaa !29
  %t166 = load ptr, ptr %l1, !tbaa !29
  %t167 = load ptr, ptr %l7, !tbaa !29
  %t169 = getelementptr %"compiler/typed:Cond", ptr %t167, i32 0, i32 2
  %t170 = load ptr, ptr %t169, !tbaa !29
  %t174 = call i1 @compiler_2flower_2ecompiler_2flower_3aLowerer_2estartOf(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t165, ptr %t166, ptr %t170)
  store i1 %t174, ptr %l87
  br label %bb53
bb52:
  store i1 false, ptr %l82, !tbaa !21
  br label %bb54
bb53:
  %t175 = load i1, ptr %l87, !tbaa !21
  store i1 %t175, ptr %l82, !tbaa !21
  br label %bb54
bb54:
  %t176 = load i1, ptr %l82, !tbaa !21
  store i1 %t176, ptr %l10, !tbaa !21
  br label %bb82
bb55:
  %t177 = load ptr, ptr %l2, !tbaa !29
  store ptr %t177, ptr %l88, !tbaa !29
  store i1 false, ptr %l89, !tbaa !21
  %t178 = load ptr, ptr %l88, !tbaa !29
  %t179 = icmp ne ptr %t178, null
  br i1 %t179, label %bb56, label %bb57
bb56:
  %t181 = load ptr, ptr %l88, !tbaa !29
  %t182 = load i64, ptr %t181, !range !{i64 0, i64 18}
  %t184 = icmp eq i64 %t182, 12
  store i1 %t184, ptr %l89, !tbaa !21
  br label %bb57
bb57:
  %t185 = load i1, ptr %l89, !tbaa !21
  br i1 %t185, label %bb58, label %bb59
bb58:
  %t186 = load ptr, ptr %l2, !tbaa !29
  %t188 = getelementptr { i64, [5 x i64] }, ptr %t186, i32 0, i32 1
  %t189 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t188, i32 0, i32 2
  %t190 = load ptr, ptr %t189
  store ptr %t190, ptr %l8, !tbaa !29
  br label %bb60
bb59:
  br label %bb68
bb60:
  %t192 = load ptr, ptr %l8, !tbaa !29
  %t194 = getelementptr %"compiler/typed:Seq", ptr %t192, i32 0, i32 1
  %t195 = load ptr, ptr %t194, !tbaa !29
  %t197 = icmp eq ptr %t195, null
  %t199 = xor i1 %t197, true
  br i1 %t199, label %bb61, label %bb62
bb61:
  %t201 = load ptr, ptr %l0, !tbaa !29
  store ptr %t201, ptr %l99, !tbaa !29
  %t202 = load ptr, ptr %l1, !tbaa !29
  store ptr %t202, ptr %l100, !tbaa !29
  %t203 = load ptr, ptr %l8, !tbaa !29
  %t205 = getelementptr %"compiler/typed:Seq", ptr %t203, i32 0, i32 1
  %t206 = load ptr, ptr %t205, !tbaa !29
  %t208 = icmp eq ptr %t206, null
  br i1 %t208, label %bb63, label %bb64
bb62:
  store i1 false, ptr %l98, !tbaa !21
  br label %bb67
bb63:
  call void @__olang_check_failed(ptr @olang_loc_435acf52bbb8e677_d8766f4885972723)
  unreachable
bb64:
  br label %bb65
bb65:
  %t210 = load ptr, ptr %l8, !tbaa !29
  %t212 = getelementptr %"compiler/typed:Seq", ptr %t210, i32 0, i32 1
  %t213 = load ptr, ptr %t212, !tbaa !29
  %t214 = load ptr, ptr %l99, !tbaa !29
  %t215 = load ptr, ptr %l100, !tbaa !29
  %t217 = call i1 @compiler_2flower_2ecompiler_2flower_3aLowerer_2estartOf(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t214, ptr %t215, ptr %t213)
  store i1 %t217, ptr %l106
  br label %bb66
bb66:
  %t218 = load i1, ptr %l106, !tbaa !21
  store i1 %t218, ptr %l98, !tbaa !21
  br label %bb67
bb67:
  %t219 = load i1, ptr %l98, !tbaa !21
  store i1 %t219, ptr %l10, !tbaa !21
  br label %bb82
bb68:
  %t220 = load ptr, ptr %l2, !tbaa !29
  store ptr %t220, ptr %l107, !tbaa !29
  store i1 false, ptr %l108, !tbaa !21
  %t221 = load ptr, ptr %l107, !tbaa !29
  %t222 = icmp ne ptr %t221, null
  br i1 %t222, label %bb69, label %bb70
bb69:
  %t224 = load ptr, ptr %l107, !tbaa !29
  %t225 = load i64, ptr %t224, !range !{i64 0, i64 18}
  %t227 = icmp eq i64 %t225, 17
  store i1 %t227, ptr %l108, !tbaa !21
  br label %bb70
bb70:
  %t228 = load i1, ptr %l108, !tbaa !21
  br i1 %t228, label %bb71, label %bb72
bb71:
  %t229 = load ptr, ptr %l2, !tbaa !29
  %t231 = getelementptr { i64, [5 x i64] }, ptr %t229, i32 0, i32 1
  %t232 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t231, i32 0, i32 2
  %t233 = load ptr, ptr %t232
  store ptr %t233, ptr %l9, !tbaa !29
  br label %bb73
bb72:
  br label %bb75
bb73:
  %t235 = load ptr, ptr %l0, !tbaa !29
  %t236 = load ptr, ptr %l1, !tbaa !29
  %t237 = load ptr, ptr %l9, !tbaa !29
  %t241 = call i1 @compiler_2flower_2ecompiler_2flower_3aLowerer_2estartOf(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t235, ptr %t236, ptr %t237)
  store i1 %t241, ptr %l116
  br label %bb74
bb74:
  %t242 = load i1, ptr %l116, !tbaa !21
  store i1 %t242, ptr %l10, !tbaa !21
  br label %bb82
bb75:
  br i1 true, label %bb76, label %bb77
bb76:
  br label %bb78
bb77:
  br label %bb81
bb78:
  %t243 = load ptr, ptr %l0, !tbaa !29
  store ptr %t243, ptr %l117, !tbaa !29
  %t244 = load ptr, ptr %l2, !tbaa !29
  %t246 = call ptr @compiler_2flower_2efreshCall(ptr %v2, ptr %v2, ptr %t244)
  store ptr %t246, ptr %l119
  br label %bb79
bb79:
  %t247 = load ptr, ptr %l117, !tbaa !29
  %t248 = load ptr, ptr %l119, !tbaa !29
  %t249 = call i1 @compiler_2flower_2ecompiler_2flower_3aLowerer_2estartCall(ptr %v0, ptr %v2, ptr %t247, ptr %t248)
  store i1 %t249, ptr %l120
  br label %bb80
bb80:
  %t250 = load i1, ptr %l120, !tbaa !21
  store i1 %t250, ptr %l10, !tbaa !21
  br label %bb82
bb81:
  call void @__olang_check_failed(ptr @olang_loc_50f71fc20ce5d5c5_1a87e46ae2942751)
  unreachable
bb82:
  %t251 = load i1, ptr %l10, !tbaa !21
  store i1 %t251, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2flower_2ecompiler_2flower_3aLowerer_2etext(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca ptr
  %l7 = alloca i32
  %s1 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:Lowerer", ptr %t1, i32 0, i32 31
  %t4 = load i32, ptr %t3, !tbaa !23
  %t6 = icmp slt i32 %t4, 0
  br i1 %t6, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t8 = load ptr, ptr %l0, !tbaa !29
  store ptr %t8, ptr %l4, !tbaa !29
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/lower:Lowerer", ptr %t9, i32 0, i32 0
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t14 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ePreludeType(ptr %v0, ptr %s1, ptr %s1, ptr %t12, { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d7, i32 0, i32 1) }, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d8, i32 0, i32 1) })
  store i32 %t14, ptr %l7
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t15 = load i32, ptr %l7, !tbaa !23
  %t16 = load ptr, ptr %l4, !tbaa !29
  %t17 = getelementptr %"compiler/lower:Lowerer", ptr %t16, i32 0, i32 31
  store i32 %t15, ptr %t17, !tbaa !23
  call void @__olang_scope_close(ptr %s1)
  br label %bb4
bb4:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/lower:Lowerer", ptr %t18, i32 0, i32 31
  %t21 = load i32, ptr %t20, !tbaa !23
  store i32 %t21, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3ahandWalk_2eblock(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l16 = alloca { i64, ptr }
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t7 = getelementptr %"compiler/typed:Block", ptr %t5, i32 0, i32 1
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  store { i64, ptr } %t8, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  %t14 = load i64, ptr %l3, !tbaa !24
  %t15 = load i64, ptr %l4, !tbaa !24
  %t18 = icmp slt i64 %t14, %t15
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb5, label %bb6
bb5:
  br label %bb10
bb6:
  br label %bb7
bb7:
  %t22 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t22, ptr %l16, !tbaa !27
  %t23 = load i64, ptr %l3, !tbaa !24
  %t25 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr ptr, ptr %t26, i64 %t23
  %t28 = load ptr, ptr %t27, !tbaa !39
  call void @compiler_2flower_2ecompiler_2flower_3ahandWalk_2estmt(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %t28)
  br label %bb8
bb8:
  br label %bb9
bb9:
  %t34 = load i64, ptr %l3, !tbaa !24
  %t37 = add i64 %t34, 1
  store i64 %t37, ptr %l3, !tbaa !24
  br label %bb4
bb10:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3ahandWalk_2eplace(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca i1
  %l19 = alloca ptr
  %l21 = alloca i64
  %l22 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i32
  %l30 = alloca ptr
  %l31 = alloca i1
  %l34 = alloca ptr
  %l35 = alloca i1
  %l43 = alloca ptr
  %l44 = alloca i1
  %l51 = alloca ptr
  %l52 = alloca i1
  %l64 = alloca ptr
  %l65 = alloca i1
  %l73 = alloca ptr
  %l74 = alloca i1
  %l82 = alloca ptr
  %l83 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t2 = load ptr, ptr %l8, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l8, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l9, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l9, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  br label %bb5
bb4:
  br label %bb12
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/lower:handWalk", ptr %t16, i32 0, i32 2
  %t19 = load i32, ptr %l2, !tbaa !23
  %t21 = sext i32 %t19 to i64
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t18, i64 %t21, i1 true)
  br label %bb6
bb6:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/lower:handWalk", ptr %t24, i32 0, i32 8
  store ptr %t26, ptr %l19, !tbaa !29
  %t27 = load i32, ptr %l2, !tbaa !23
  %t29 = sext i32 %t27 to i64
  store i64 %t29, ptr %l21, !tbaa !24
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/lower:handWalk", ptr %t30, i32 0, i32 8
  %t33 = load i32, ptr %l2, !tbaa !23
  %t35 = sext i32 %t33 to i64
  %t38 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t32, i64 %t35)
  %t39 = extractvalue { i32, i64 } %t38, 1
  %t40 = extractvalue { i32, i64 } %t38, 0
  store i32 %t40, ptr %l28
  %t41 = icmp ne i32 %t40, 0
  br i1 %t41, label %bb8, label %ok.42, !prof !99
ok.42:
  store i64 %t39, ptr %l27
  br label %bb7
bb7:
  %t43 = load i64, ptr %l27, !tbaa !24
  store i64 %t43, ptr %l22, !tbaa !24
  br label %bb10
bb8:
  br label %bb9
bb9:
  store i64 0, ptr %l22, !tbaa !24
  br label %bb10
bb10:
  %t44 = load i64, ptr %l22, !tbaa !24
  %t45 = add i64 %t44, 1
  %t46 = load ptr, ptr %l19, !tbaa !29
  %t47 = load i64, ptr %l21, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t46, i64 %t47, i64 %t45)
  br label %bb11
bb11:
  br label %bb65
bb12:
  %t49 = load ptr, ptr %l1, !tbaa !29
  store ptr %t49, ptr %l30, !tbaa !29
  store i1 false, ptr %l31, !tbaa !21
  %t50 = load ptr, ptr %l30, !tbaa !29
  %t51 = icmp ne ptr %t50, null
  br i1 %t51, label %bb13, label %bb14
bb13:
  %t53 = load ptr, ptr %l30, !tbaa !29
  %t54 = load i64, ptr %t53, !range !{i64 0, i64 8}
  %t56 = icmp eq i64 %t54, 1
  store i1 %t56, ptr %l31, !tbaa !21
  br label %bb14
bb14:
  %t57 = load i1, ptr %l31, !tbaa !21
  br i1 %t57, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb65
bb18:
  %t58 = load ptr, ptr %l1, !tbaa !29
  store ptr %t58, ptr %l34, !tbaa !29
  store i1 false, ptr %l35, !tbaa !21
  %t59 = load ptr, ptr %l34, !tbaa !29
  %t60 = icmp ne ptr %t59, null
  br i1 %t60, label %bb19, label %bb20
bb19:
  %t62 = load ptr, ptr %l34, !tbaa !29
  %t63 = load i64, ptr %t62, !range !{i64 0, i64 8}
  %t65 = icmp eq i64 %t63, 2
  store i1 %t65, ptr %l35, !tbaa !21
  br label %bb20
bb20:
  %t66 = load i1, ptr %l35, !tbaa !21
  br i1 %t66, label %bb21, label %bb22
bb21:
  %t67 = load ptr, ptr %l1, !tbaa !29
  %t69 = getelementptr { i64, [4 x i64] }, ptr %t67, i32 0, i32 1
  %t70 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t69, i32 0, i32 2
  %t71 = load ptr, ptr %t70
  store ptr %t71, ptr %l3, !tbaa !29
  br label %bb23
bb22:
  br label %bb25
bb23:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t74 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3ahandWalk_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t73, ptr %t74)
  br label %bb24
bb24:
  br label %bb65
bb25:
  %t78 = load ptr, ptr %l1, !tbaa !29
  store ptr %t78, ptr %l43, !tbaa !29
  store i1 false, ptr %l44, !tbaa !21
  %t79 = load ptr, ptr %l43, !tbaa !29
  %t80 = icmp ne ptr %t79, null
  br i1 %t80, label %bb26, label %bb27
bb26:
  %t82 = load ptr, ptr %l43, !tbaa !29
  %t83 = load i64, ptr %t82, !range !{i64 0, i64 8}
  %t85 = icmp eq i64 %t83, 3
  store i1 %t85, ptr %l44, !tbaa !21
  br label %bb27
bb27:
  %t86 = load i1, ptr %l44, !tbaa !21
  br i1 %t86, label %bb28, label %bb29
bb28:
  %t87 = load ptr, ptr %l1, !tbaa !29
  %t89 = getelementptr { i64, [4 x i64] }, ptr %t87, i32 0, i32 1
  %t90 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t89, i32 0, i32 2
  %t91 = load ptr, ptr %t90
  store ptr %t91, ptr %l4, !tbaa !29
  br label %bb30
bb29:
  br label %bb32
bb30:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t94 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3ahandWalk_2eplace(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t93, ptr %t94)
  br label %bb31
bb31:
  br label %bb65
bb32:
  %t97 = load ptr, ptr %l1, !tbaa !29
  store ptr %t97, ptr %l51, !tbaa !29
  store i1 false, ptr %l52, !tbaa !21
  %t98 = load ptr, ptr %l51, !tbaa !29
  %t99 = icmp ne ptr %t98, null
  br i1 %t99, label %bb33, label %bb34
bb33:
  %t101 = load ptr, ptr %l51, !tbaa !29
  %t102 = load i64, ptr %t101, !range !{i64 0, i64 8}
  %t104 = icmp eq i64 %t102, 4
  store i1 %t104, ptr %l52, !tbaa !21
  br label %bb34
bb34:
  %t105 = load i1, ptr %l52, !tbaa !21
  br i1 %t105, label %bb35, label %bb36
bb35:
  %t106 = load ptr, ptr %l1, !tbaa !29
  %t108 = getelementptr { i64, [4 x i64] }, ptr %t106, i32 0, i32 1
  %t109 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t108, i32 0, i32 2
  %t110 = load ptr, ptr %t109
  store ptr %t110, ptr %l5, !tbaa !29
  br label %bb37
bb36:
  br label %bb40
bb37:
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t113 = load ptr, ptr %l5, !tbaa !29
  %t115 = getelementptr %"compiler/typed:Elem", ptr %t113, i32 0, i32 0
  %t116 = load ptr, ptr %t115, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3ahandWalk_2eplace(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t112, ptr %t116)
  br label %bb38
bb38:
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t120 = load ptr, ptr %l5, !tbaa !29
  %t122 = getelementptr %"compiler/typed:Elem", ptr %t120, i32 0, i32 1
  %t123 = load ptr, ptr %t122, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3ahandWalk_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t119, ptr %t123)
  br label %bb39
bb39:
  br label %bb65
bb40:
  %t127 = load ptr, ptr %l1, !tbaa !29
  store ptr %t127, ptr %l64, !tbaa !29
  store i1 false, ptr %l65, !tbaa !21
  %t128 = load ptr, ptr %l64, !tbaa !29
  %t129 = icmp ne ptr %t128, null
  br i1 %t129, label %bb41, label %bb42
bb41:
  %t131 = load ptr, ptr %l64, !tbaa !29
  %t132 = load i64, ptr %t131, !range !{i64 0, i64 8}
  %t134 = icmp eq i64 %t132, 5
  store i1 %t134, ptr %l65, !tbaa !21
  br label %bb42
bb42:
  %t135 = load i1, ptr %l65, !tbaa !21
  br i1 %t135, label %bb43, label %bb44
bb43:
  %t136 = load ptr, ptr %l1, !tbaa !29
  %t138 = getelementptr { i64, [4 x i64] }, ptr %t136, i32 0, i32 1
  %t139 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t138, i32 0, i32 2
  %t140 = load ptr, ptr %t139
  store ptr %t140, ptr %l6, !tbaa !29
  br label %bb45
bb44:
  br label %bb47
bb45:
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t143 = load ptr, ptr %l6, !tbaa !29
  %t145 = getelementptr %"compiler/typed:Payload", ptr %t143, i32 0, i32 0
  %t146 = load ptr, ptr %t145, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3ahandWalk_2eplace(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t142, ptr %t146)
  br label %bb46
bb46:
  br label %bb65
bb47:
  %t149 = load ptr, ptr %l1, !tbaa !29
  store ptr %t149, ptr %l73, !tbaa !29
  store i1 false, ptr %l74, !tbaa !21
  %t150 = load ptr, ptr %l73, !tbaa !29
  %t151 = icmp ne ptr %t150, null
  br i1 %t151, label %bb48, label %bb49
bb48:
  %t153 = load ptr, ptr %l73, !tbaa !29
  %t154 = load i64, ptr %t153, !range !{i64 0, i64 8}
  %t156 = icmp eq i64 %t154, 6
  store i1 %t156, ptr %l74, !tbaa !21
  br label %bb49
bb49:
  %t157 = load i1, ptr %l74, !tbaa !21
  br i1 %t157, label %bb50, label %bb51
bb50:
  %t158 = load ptr, ptr %l1, !tbaa !29
  %t160 = getelementptr { i64, [4 x i64] }, ptr %t158, i32 0, i32 1
  %t161 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t160, i32 0, i32 2
  %t162 = load ptr, ptr %t161
  store ptr %t162, ptr %l7, !tbaa !29
  br label %bb52
bb51:
  br label %bb54
bb52:
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t165 = load ptr, ptr %l7, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3ahandWalk_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t164, ptr %t165)
  br label %bb53
bb53:
  br label %bb65
bb54:
  %t169 = load ptr, ptr %l1, !tbaa !29
  store ptr %t169, ptr %l82, !tbaa !29
  store i1 false, ptr %l83, !tbaa !21
  %t170 = load ptr, ptr %l82, !tbaa !29
  %t171 = icmp ne ptr %t170, null
  br i1 %t171, label %bb55, label %bb56
bb55:
  %t173 = load ptr, ptr %l82, !tbaa !29
  %t174 = load i64, ptr %t173, !range !{i64 0, i64 8}
  %t176 = icmp eq i64 %t174, 7
  store i1 %t176, ptr %l83, !tbaa !21
  br label %bb56
bb56:
  %t177 = load i1, ptr %l83, !tbaa !21
  br i1 %t177, label %bb57, label %bb58
bb57:
  br label %bb59
bb58:
  br label %bb64
bb59:
  %t178 = load ptr, ptr %l0, !tbaa !29
  %t180 = getelementptr %"compiler/lower:handWalk", ptr %t178, i32 0, i32 10
  %t181 = load i64, ptr %t180, !tbaa !24
  %t183 = icmp sge i64 %t181, 0
  br i1 %t183, label %bb60, label %bb61
bb60:
  %t185 = load ptr, ptr %l0, !tbaa !29
  %t187 = getelementptr %"compiler/lower:handWalk", ptr %t185, i32 0, i32 2
  %t188 = load ptr, ptr %l0, !tbaa !29
  %t190 = getelementptr %"compiler/lower:handWalk", ptr %t188, i32 0, i32 10
  %t191 = load i64, ptr %t190, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t187, i64 %t191, i1 true)
  br label %bb62
bb61:
  br label %bb63
bb62:
  br label %bb63
bb63:
  br label %bb65
bb64:
  call void @__olang_check_failed(ptr @olang_loc_9a464a2bb6204b77_4682d2f86e8713a3)
  unreachable
bb65:
  br label %ret
ret:
  ret void
}

define dso_local { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2earrayCopy(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, [4 x i64] } %a1, i32 %a2, %"compiler/source:Span" %a3, { i64, [1 x i64] } %a4, i1 %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [4 x i64] }
  %l2 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca { i64, [1 x i64] }
  %l6 = alloca i32
  %l7 = alloca { i64, [4 x i64] }
  %l8 = alloca i32
  %l10 = alloca ptr
  %l13 = alloca i1
  %l20 = alloca { i64, [4 x i64] }
  %l25 = alloca i32
  %l26 = alloca ptr
  %l27 = alloca i32
  %l28 = alloca i32
  %l30 = alloca %"compiler/mir:Lvalue"
  %l32 = alloca { i64, ptr }
  %l34 = alloca { i64, [4 x i64] }
  %l38 = alloca i32
  %l39 = alloca ptr
  %l40 = alloca %"compiler/source:Span"
  %l42 = alloca %"compiler/mir:Lvalue"
  %l50 = alloca ptr
  %l51 = alloca %"compiler/source:Span"
  %l53 = alloca %"compiler/mir:Lvalue"
  %l55 = alloca %"compiler/mir:Lvalue"
  %l60 = alloca %"compiler/mir:Lvalue"
  %s0 = alloca %olang.scope
  %rv = alloca { i64, [4 x i64] }
  %t45 = alloca { i64, [4 x i64] }, align 8
  %t83 = alloca { i64, [4 x i64] }, align 8
  %t86 = alloca { i64, [15 x i64] }, align 8
  %t98 = alloca { i64, [21 x i64] }, align 8
  %t121 = alloca { i64, [21 x i64] }, align 8
  %t140 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store { i64, [4 x i64] } %a1, ptr %l1
  store i32 %a2, ptr %l2
  store %"compiler/source:Span" %a3, ptr %l3
  store { i64, [1 x i64] } %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l10, !tbaa !29
  %t5 = load i32, ptr %l2, !tbaa !23
  %t6 = load ptr, ptr %l10, !tbaa !29
  %t7 = call ptr @__olang_scope_or(ptr %v1, ptr %t6)
  %t8 = call ptr @__olang_scope_hold(ptr %t7)
  %t9 = ptrtoint ptr %t8 to i64
  %t11 = inttoptr i64 %t9 to ptr
  %t12 = load ptr, ptr %l10, !tbaa !29
  %t14 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOwnsParts(ptr %t11, ptr %t12, i32 %t5)
  store i1 %t14, ptr %l13
  br label %bb1
bb1:
  %t15 = load i1, ptr %l13, !tbaa !21
  br i1 %t15, label %bb2, label %bb3
bb2:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load { i64, [4 x i64] }, ptr %l1
  %t18 = load i32, ptr %l2, !tbaa !23
  %t19 = load { i64, [1 x i64] }, ptr %l4
  %t20 = load %"compiler/source:Span", ptr %l3
  %t28 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eownCopyOf(ptr %v0, ptr %v1, ptr %v2, ptr %t16, { i64, [4 x i64] } %t17, i32 %t18, { i64, [1 x i64] } %t19, %"compiler/source:Span" %t20, i1 %a5)
  store { i64, [4 x i64] } %t28, ptr %l20
  br label %bb4
bb3:
  br label %bb5
bb4:
  call void @__olang_scope_close(ptr %s0)
  %t29 = load { i64, [4 x i64] }, ptr %l20
  store { i64, [4 x i64] } %t29, ptr %rv
  br label %ret
bb5:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t31 = load { i64, [4 x i64] }, ptr %l1
  %t32 = load i32, ptr %l2, !tbaa !23
  %t33 = load %"compiler/source:Span", ptr %l3
  %t38 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2elocal(ptr %v0, ptr %v1, ptr %v2, ptr %t30, { i64, [4 x i64] } %t31, i32 %t32, %"compiler/source:Span" %t33)
  store i32 %t38, ptr %l25
  br label %bb6
bb6:
  %t39 = load i32, ptr %l25, !tbaa !23
  store i32 %t39, ptr %l6, !tbaa !23
  %t40 = load ptr, ptr %l0, !tbaa !29
  store ptr %t40, ptr %l26, !tbaa !29
  store i32 22, ptr %l27
  %t41 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  store i32 %t41, ptr %l28, !tbaa !23
  %t42 = load i32, ptr %l6, !tbaa !23
  %t44 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t42)
  store %"compiler/mir:Lvalue" %t44, ptr %l30
  br label %bb7
bb7:
  store { i64, [4 x i64] } zeroinitializer, ptr %t45
  %t46 = getelementptr { i64, [4 x i64] }, ptr %t45, i32 0, i32 0
  store i64 1, ptr %t46
  %t47 = load %"compiler/mir:Lvalue", ptr %l30
  %t48 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t47, 0
  %t49 = getelementptr { i64, [4 x i64] }, ptr %t45, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t48, ptr %t49
  %t50 = load { i64, [4 x i64] }, ptr %t45
  %t51 = mul i64 1, 40
  %t52 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t51)
  %t53 = insertvalue { i64, ptr } undef, i64 1, 0
  %t54 = insertvalue { i64, ptr } %t53, ptr %t52, 1
  store { i64, ptr } %t54, ptr %l32, !tbaa !27
  %t56 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t57 = load ptr, ptr %t56, !tbaa !27
  %t58 = getelementptr { i64, [4 x i64] }, ptr %t57, i64 0
  store { i64, [4 x i64] } %t50, ptr %t58
  %t59 = load %"compiler/source:Span", ptr %l3
  %t60 = load ptr, ptr %l26, !tbaa !29
  %t61 = load i32, ptr %l27, !range !{i32 0, i32 54}
  %t62 = load i32, ptr %l28, !tbaa !23
  %t63 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t65 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s0, ptr %v1, ptr %v2, ptr %t60, i32 %t61, i32 %t62, { i64, ptr } %t63, %"compiler/source:Span" %t59)
  store { i64, [4 x i64] } %t65, ptr %l34
  br label %bb8
bb8:
  %t66 = load { i64, [4 x i64] }, ptr %l34
  store { i64, [4 x i64] } %t66, ptr %l7
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t68 = load i32, ptr %l2, !tbaa !23
  %t69 = load %"compiler/source:Span", ptr %l3
  %t73 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2etemp(ptr %v0, ptr %t67, i32 %t68, %"compiler/source:Span" %t69)
  store i32 %t73, ptr %l38
  br label %bb9
bb9:
  %t74 = load i32, ptr %l38, !tbaa !23
  store i32 %t74, ptr %l8, !tbaa !23
  %t75 = load ptr, ptr %l0, !tbaa !29
  store ptr %t75, ptr %l39, !tbaa !29
  %t76 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t76, ptr %l40
  %t77 = load i32, ptr %l8, !tbaa !23
  %t79 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t77)
  store %"compiler/mir:Lvalue" %t79, ptr %l42
  br label %bb10
bb10:
  %t80 = load { i64, [1 x i64] }, ptr %l4
  %t81 = load i32, ptr %l2, !tbaa !23
  %t82 = load { i64, [4 x i64] }, ptr %l7
  store { i64, [4 x i64] } zeroinitializer, ptr %t83
  %t84 = getelementptr { i64, [4 x i64] }, ptr %t83, i32 0, i32 0
  store i64 0, ptr %t84
  %t85 = load { i64, [4 x i64] }, ptr %t83
  store { i64, [15 x i64] } zeroinitializer, ptr %t86
  %t87 = getelementptr { i64, [15 x i64] }, ptr %t86, i32 0, i32 0
  store i64 8, ptr %t87
  %t89 = insertvalue { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } } undef, { i64, [1 x i64] } %t80, 0
  %t91 = insertvalue { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } } %t89, i32 %t81, 1
  %t93 = insertvalue { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } } %t91, { i64, [4 x i64] } %t82, 2
  %t95 = insertvalue { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } } %t93, { i64, [4 x i64] } %t85, 3
  %t96 = getelementptr { i64, [15 x i64] }, ptr %t86, i32 0, i32 1
  store { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } } %t95, ptr %t96
  %t97 = load { i64, [15 x i64] }, ptr %t86
  store { i64, [21 x i64] } zeroinitializer, ptr %t98
  %t99 = getelementptr { i64, [21 x i64] }, ptr %t98, i32 0, i32 0
  store i64 0, ptr %t99
  %t100 = load %"compiler/source:Span", ptr %l40
  %t101 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t100, 0
  %t102 = load %"compiler/mir:Lvalue", ptr %l42
  %t103 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t101, %"compiler/mir:Lvalue" %t102, 1
  %t105 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t103, { i64, [15 x i64] } %t97, 2
  %t106 = getelementptr { i64, [21 x i64] }, ptr %t98, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t105, ptr %t106
  %t107 = load { i64, [21 x i64] }, ptr %t98
  %t109 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t107, ptr %t109
  %t110 = load ptr, ptr %l39, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s0, ptr %v1, ptr %v2, ptr %t110, ptr %t109)
  br label %bb11
bb11:
  %t112 = load ptr, ptr %l0, !tbaa !29
  store ptr %t112, ptr %l50, !tbaa !29
  %t113 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t113, ptr %l51
  %t114 = load i32, ptr %l8, !tbaa !23
  %t116 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t114)
  store %"compiler/mir:Lvalue" %t116, ptr %l53
  br label %bb12
bb12:
  %t117 = load i32, ptr %l6, !tbaa !23
  %t119 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t117)
  store %"compiler/mir:Lvalue" %t119, ptr %l55
  br label %bb13
bb13:
  %t120 = load { i64, [4 x i64] }, ptr %l7
  store { i64, [21 x i64] } zeroinitializer, ptr %t121
  %t122 = getelementptr { i64, [21 x i64] }, ptr %t121, i32 0, i32 0
  store i64 12, ptr %t122
  %t123 = load %"compiler/source:Span", ptr %l51
  %t124 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", %"compiler/mir:Lvalue", { i64, [4 x i64] } } undef, %"compiler/source:Span" %t123, 0
  %t125 = load %"compiler/mir:Lvalue", ptr %l53
  %t126 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", %"compiler/mir:Lvalue", { i64, [4 x i64] } } %t124, %"compiler/mir:Lvalue" %t125, 1
  %t127 = load %"compiler/mir:Lvalue", ptr %l55
  %t128 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", %"compiler/mir:Lvalue", { i64, [4 x i64] } } %t126, %"compiler/mir:Lvalue" %t127, 2
  %t130 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", %"compiler/mir:Lvalue", { i64, [4 x i64] } } %t128, { i64, [4 x i64] } %t120, 3
  %t131 = getelementptr { i64, [21 x i64] }, ptr %t121, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Lvalue", %"compiler/mir:Lvalue", { i64, [4 x i64] } } %t130, ptr %t131
  %t132 = load { i64, [21 x i64] }, ptr %t121
  %t134 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t132, ptr %t134
  %t135 = load ptr, ptr %l50, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s0, ptr %v1, ptr %v2, ptr %t135, ptr %t134)
  br label %bb14
bb14:
  %t137 = load i32, ptr %l8, !tbaa !23
  %t139 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t137)
  store %"compiler/mir:Lvalue" %t139, ptr %l60
  br label %bb15
bb15:
  store { i64, [4 x i64] } zeroinitializer, ptr %t140
  %t141 = getelementptr { i64, [4 x i64] }, ptr %t140, i32 0, i32 0
  store i64 1, ptr %t141
  %t142 = load %"compiler/mir:Lvalue", ptr %l60
  %t143 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t142, 0
  %t144 = getelementptr { i64, [4 x i64] }, ptr %t140, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t143, ptr %t144
  %t145 = load { i64, [4 x i64] }, ptr %t140
  call void @__olang_scope_close(ptr %s0)
  store { i64, [4 x i64] } %t145, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local i32 @compiler_2flower_2ecompiler_2flower_3alowering_2earrayOf(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca i32
  %l6 = alloca ptr
  %l9 = alloca i32
  %l10 = alloca ptr
  %l13 = alloca i1
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l18 = alloca i32
  %l20 = alloca i32
  %l21 = alloca ptr
  %l24 = alloca i32
  %l27 = alloca i32
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/lower:lowering", ptr %a0, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  store ptr %t6, ptr %l6, !tbaa !29
  %t8 = load ptr, ptr %l6, !tbaa !29
  %t9 = call ptr @__olang_scope_or(ptr %v1, ptr %t8)
  %t10 = call ptr @__olang_scope_hold(ptr %t9)
  %t11 = ptrtoint ptr %t10 to i64
  %t13 = inttoptr i64 %t11 to ptr
  %t14 = load ptr, ptr %l6, !tbaa !29
  %t16 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %t13, ptr %t14, i32 %a1)
  store i32 %t16, ptr %l9
  br label %bb1
bb1:
  %t17 = load i32, ptr %l9, !tbaa !23
  store i32 %t17, ptr %l3, !tbaa !23
  %t18 = load ptr, ptr %l2, !tbaa !29
  store ptr %t18, ptr %l10, !tbaa !29
  %t19 = load i32, ptr %l3, !tbaa !23
  %t20 = load ptr, ptr %l10, !tbaa !29
  %t21 = call ptr @__olang_scope_or(ptr %v1, ptr %t20)
  %t22 = call ptr @__olang_scope_hold(ptr %t21)
  %t23 = ptrtoint ptr %t22 to i64
  %t25 = inttoptr i64 %t23 to ptr
  %t26 = load ptr, ptr %l10, !tbaa !29
  %t28 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %t25, ptr %t26, i32 %t19)
  store i1 %t28, ptr %l13
  br label %bb2
bb2:
  %t29 = load i1, ptr %l13, !tbaa !21
  br i1 %t29, label %bb3, label %bb4
bb3:
  %t30 = load ptr, ptr %l2, !tbaa !29
  store ptr %t30, ptr %l14, !tbaa !29
  %t31 = load ptr, ptr %l2, !tbaa !29
  store ptr %t31, ptr %l15, !tbaa !29
  %t32 = load i32, ptr %l3, !tbaa !23
  %t33 = load ptr, ptr %l15, !tbaa !29
  %t34 = call ptr @__olang_scope_or(ptr %v1, ptr %t33)
  %t35 = call ptr @__olang_scope_hold(ptr %t34)
  %t36 = ptrtoint ptr %t35 to i64
  %t38 = inttoptr i64 %t36 to ptr
  %t39 = load ptr, ptr %l15, !tbaa !29
  %t41 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %t38, ptr %t39, i32 %t32)
  store i32 %t41, ptr %l18
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t42 = load ptr, ptr %l14, !tbaa !29
  %t43 = call ptr @__olang_scope_or(ptr %v1, ptr %t42)
  %t44 = call ptr @__olang_scope_hold(ptr %t43)
  %t45 = ptrtoint ptr %t44 to i64
  %t47 = inttoptr i64 %t45 to ptr
  %t48 = load ptr, ptr %l14, !tbaa !29
  %t49 = load i32, ptr %l18, !tbaa !23
  %t50 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %t47, ptr %t48, i32 %t49)
  store i32 %t50, ptr %l20
  br label %bb6
bb6:
  %t51 = load i32, ptr %l20, !tbaa !23
  store i32 %t51, ptr %l3, !tbaa !23
  br label %bb7
bb7:
  %t52 = load ptr, ptr %l2, !tbaa !29
  store ptr %t52, ptr %l21, !tbaa !29
  %t53 = load i32, ptr %l3, !tbaa !23
  %t54 = load ptr, ptr %l21, !tbaa !29
  %t55 = call ptr @__olang_scope_or(ptr %v1, ptr %t54)
  %t56 = call ptr @__olang_scope_hold(ptr %t55)
  %t57 = ptrtoint ptr %t56 to i64
  %t59 = inttoptr i64 %t57 to ptr
  %t60 = load ptr, ptr %l21, !tbaa !29
  %t62 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %t59, ptr %t60, i32 %t53)
  store i32 %t62, ptr %l24
  br label %bb8
bb8:
  %t63 = load i32, ptr %l24, !range !{i32 0, i32 33}
  %t65 = trunc i64 19 to i32
  %t66 = icmp eq i32 %t63, %t65
  br i1 %t66, label %bb9, label %bb10
bb9:
  %t68 = load i32, ptr %l3, !tbaa !23
  store i32 %t68, ptr %l27, !tbaa !23
  br label %bb11
bb10:
  %t70 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t70, ptr %l27, !tbaa !23
  br label %bb11
bb11:
  %t72 = load i32, ptr %l27, !tbaa !23
  store i32 %t72, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { { i64, [7 x i64] }, i32 } @compiler_2flower_2ecompiler_2flower_3alowering_2ebodyCallee(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l6 = alloca ptr
  %l13 = alloca ptr
  %rv = alloca { { i64, [7 x i64] }, i32 }
  %t37 = alloca { i64, [2 x i64] }, align 8
  %t44 = alloca { i64, [7 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/lower:Lowerer", ptr %t4, i32 0, i32 1
  %t7 = load ptr, ptr %t6, !tbaa !29
  store ptr %t7, ptr %l6, !tbaa !29
  %t9 = load i32, ptr %l1, !tbaa !23
  %t11 = sext i32 %t9 to i64
  %t12 = load ptr, ptr %l6, !tbaa !29
  %t13 = call ptr @__olang_scope_or(ptr %v1, ptr %t12)
  %t14 = call ptr @__olang_scope_hold(ptr %t13)
  %t15 = ptrtoint ptr %t14 to i64
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/lower:lowering", ptr %t16, i32 0, i32 0
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t21 = call ptr @__olang_scope_or(ptr %v1, ptr %t19)
  %t22 = call ptr @__olang_scope_hold(ptr %t21)
  %t23 = ptrtoint ptr %t22 to i64
  %t25 = inttoptr i64 %t15 to ptr
  %t27 = inttoptr i64 %t23 to ptr
  %t28 = load ptr, ptr %l6, !tbaa !29
  %t30 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %t25, ptr %t27, ptr %t28, i64 %t11)
  store ptr %t30, ptr %l13
  br label %bb1
bb1:
  %t31 = load ptr, ptr %l13, !tbaa !29
  %t33 = getelementptr %"compiler/typed:Body", ptr %t31, i32 0, i32 2
  %t34 = load i32, ptr %t33, !tbaa !23
  store i32 %t34, ptr %l2, !tbaa !23
  %t36 = load i32, ptr %l1, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t37
  %t38 = getelementptr { i64, [2 x i64] }, ptr %t37, i32 0, i32 0
  store i64 0, ptr %t38
  %t40 = insertvalue { i32 } undef, i32 %t36, 0
  %t41 = getelementptr { i64, [2 x i64] }, ptr %t37, i32 0, i32 1
  store { i32 } %t40, ptr %t41
  %t42 = load { i64, [2 x i64] }, ptr %t37
  %t43 = load i32, ptr %l2, !tbaa !23
  store { i64, [7 x i64] } zeroinitializer, ptr %t44
  %t45 = getelementptr { i64, [7 x i64] }, ptr %t44, i32 0, i32 0
  store i64 0, ptr %t45
  %t47 = insertvalue { { i64, [2 x i64] }, i32 } undef, { i64, [2 x i64] } %t42, 0
  %t49 = insertvalue { { i64, [2 x i64] }, i32 } %t47, i32 %t43, 1
  %t50 = getelementptr { i64, [7 x i64] }, ptr %t44, i32 0, i32 1
  store { { i64, [2 x i64] }, i32 } %t49, ptr %t50
  %t51 = load { i64, [7 x i64] }, ptr %t44
  %t52 = load i32, ptr %l2, !tbaa !23
  %t54 = insertvalue { { i64, [7 x i64] }, i32 } undef, { i64, [7 x i64] } %t51, 0
  %t56 = insertvalue { { i64, [7 x i64] }, i32 } %t54, i32 %t52, 1
  store { { i64, [7 x i64] }, i32 } %t56, ptr %rv
  br label %ret
ret:
  %rr = load { { i64, [7 x i64] }, i32 }, ptr %rv
  ret { { i64, [7 x i64] }, i32 } %rr
}

define dso_local { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ebuilt(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l5 = alloca i1
  %l8 = alloca i1
  %l20 = alloca { i64, ptr }
  %l24 = alloca { i64, [1 x i64] }
  %rv = alloca { i64, [1 x i64] }
  %t30 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 29
  %t4 = load i1, ptr %t3, !tbaa !21
  %t6 = xor i1 %t4, true
  br i1 %t6, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l5, !tbaa !21
  br label %bb3
bb2:
  %t8 = load i32, ptr %l1, !tbaa !23
  %t10 = icmp slt i32 %t8, 0
  store i1 %t10, ptr %l5, !tbaa !21
  br label %bb3
bb3:
  %t12 = load i1, ptr %l5, !tbaa !21
  br i1 %t12, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb6
bb5:
  %t13 = load i32, ptr %l1, !tbaa !23
  %t15 = sext i32 %t13 to i64
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/lower:lowering", ptr %t16, i32 0, i32 38
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t21 = getelementptr %"compiler/typed:Plan", ptr %t19, i32 0, i32 0
  %t22 = load { i64, ptr }, ptr %t21, !tbaa !27
  %t24 = extractvalue { i64, ptr } %t22, 0
  %t27 = icmp sge i64 %t15, %t24
  store i1 %t27, ptr %l8, !tbaa !21
  br label %bb6
bb6:
  %t29 = load i1, ptr %l8, !tbaa !21
  br i1 %t29, label %bb7, label %bb8
bb7:
  store { i64, [1 x i64] } zeroinitializer, ptr %t30
  %t31 = getelementptr { i64, [1 x i64] }, ptr %t30, i32 0, i32 0
  store i64 2, ptr %t31
  %t32 = load { i64, [1 x i64] }, ptr %t30
  store { i64, [1 x i64] } %t32, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/lower:lowering", ptr %t35, i32 0, i32 38
  %t38 = load ptr, ptr %t37, !tbaa !29
  %t40 = getelementptr %"compiler/typed:Plan", ptr %t38, i32 0, i32 0
  %t41 = load { i64, ptr }, ptr %t40, !tbaa !27
  store { i64, ptr } %t41, ptr %l20, !tbaa !27
  %t42 = load i32, ptr %l1, !tbaa !23
  %t44 = sext i32 %t42 to i64
  %t46 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !27
  %t48 = getelementptr { i64, [2 x i64] }, ptr %t47, i64 %t44
  %t49 = load { i64, [2 x i64] }, ptr %t48
  %t52 = call { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2escopeRef(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %t34, { i64, [2 x i64] } %t49)
  store { i64, [1 x i64] } %t52, ptr %l24
  br label %bb10
bb10:
  %t53 = load { i64, [1 x i64] }, ptr %l24
  store { i64, [1 x i64] } %t53, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [1 x i64] }, ptr %rv
  ret { i64, [1 x i64] } %rr
}

define dso_local { i64, ptr } @compiler_2flower_2ecompiler_2flower_3alowering_2ecasesOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l4 = alloca ptr
  %l7 = alloca i32
  %l8 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"compiler/lower:lowering", ptr %t2, i32 0, i32 2
  %t5 = load ptr, ptr %t4, !tbaa !29
  store ptr %t5, ptr %l4, !tbaa !29
  %t7 = load ptr, ptr %l4, !tbaa !29
  %t8 = call ptr @__olang_scope_or(ptr %v2, ptr %t7)
  %t9 = call ptr @__olang_scope_hold(ptr %t8)
  %t10 = ptrtoint ptr %t9 to i64
  %t12 = inttoptr i64 %t10 to ptr
  %t13 = load ptr, ptr %l4, !tbaa !29
  %t15 = call i32 @compiler_2fmir_2eCasesOf(ptr %t12, ptr %t13, i32 %a1)
  store i32 %t15, ptr %l7
  br label %bb1
bb1:
  %t16 = load ptr, ptr %l2, !tbaa !29
  %t17 = load i32, ptr %l7, !tbaa !23
  %t18 = call { i64, ptr } @compiler_2flower_2ecompiler_2flower_3alowering_2eitems(ptr %v0, ptr %v1, ptr %v2, ptr %t16, i32 %t17)
  store { i64, ptr } %t18, ptr %l8
  br label %bb2
bb2:
  %t19 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t19, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2echeck(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, [4 x i64] } %a1, i32 %a2, i32 %a3, i64 %a4, %"compiler/source:Span" %a5) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca { i32, i64 }
  %l13 = alloca i1
  %l18 = alloca i32
  %l21 = alloca i32
  %l37 = alloca ptr
  %l40 = alloca { i32, i64 }
  %l43 = alloca ptr
  %l46 = alloca { i64, [4 x i64] }
  %l48 = alloca ptr
  %l51 = alloca i32
  %t28 = alloca { i64, [8 x i64] }, align 8
  %t52 = alloca { i64, [4 x i64] }, align 8
  %t55 = alloca { i64, [8 x i64] }, align 8
  %t91 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  store %"compiler/source:Span" %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 12
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l13, !tbaa !21
  br label %bb3
bb2:
  %t6 = load i32, ptr %l2, !range !{i32 0, i32 4}
  %t8 = trunc i64 0 to i32
  %t9 = icmp eq i32 %t6, %t8
  store i1 %t9, ptr %l13, !tbaa !21
  br label %bb3
bb3:
  %t11 = load i1, ptr %l13, !tbaa !21
  br i1 %t11, label %bb4, label %bb5
bb4:
  br label %ret
bb5:
  br label %bb6
bb6:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/lower:lowering", ptr %t12, i32 0, i32 3
  %t16 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t14)
  store i32 %t16, ptr %l18
  br label %bb7
bb7:
  %t17 = load i32, ptr %l18, !tbaa !23
  store i32 %t17, ptr %l6, !tbaa !23
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/lower:lowering", ptr %t18, i32 0, i32 3
  %t22 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t20)
  store i32 %t22, ptr %l21
  br label %bb8
bb8:
  %t23 = load i32, ptr %l21, !tbaa !23
  store i32 %t23, ptr %l7, !tbaa !23
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = load i32, ptr %l6, !tbaa !23
  %t27 = load i32, ptr %l7, !tbaa !23
  store { i64, [8 x i64] } zeroinitializer, ptr %t28
  %t29 = getelementptr { i64, [8 x i64] }, ptr %t28, i32 0, i32 0
  store i64 2, ptr %t29
  %t31 = insertvalue { { i64, [4 x i64] }, i32, i32 } undef, { i64, [4 x i64] } %a1, 0
  %t33 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t31, i32 %t26, 1
  %t35 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t33, i32 %t27, 2
  %t36 = getelementptr { i64, [8 x i64] }, ptr %t28, i32 0, i32 1
  store { { i64, [4 x i64] }, i32, i32 } %t35, ptr %t36
  %t37 = load { i64, [8 x i64] }, ptr %t28
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %v1, ptr %v2, ptr %t24, { i64, [8 x i64] } %t37)
  br label %bb9
bb9:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t41 = load i32, ptr %l7, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t40, i32 %t41)
  br label %bb10
bb10:
  %t44 = load i32, ptr %l2, !range !{i32 0, i32 4}
  %t46 = trunc i64 1 to i32
  %t47 = icmp eq i32 %t44, %t46
  br i1 %t47, label %bb11, label %bb12
bb11:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t50 = load %"compiler/source:Span", ptr %l5
  store { i64, [4 x i64] } zeroinitializer, ptr %t52
  %t53 = getelementptr { i64, [4 x i64] }, ptr %t52, i32 0, i32 0
  store i64 0, ptr %t53
  %t54 = load { i64, [4 x i64] }, ptr %t52
  store { i64, [8 x i64] } zeroinitializer, ptr %t55
  %t56 = getelementptr { i64, [8 x i64] }, ptr %t55, i32 0, i32 0
  store i64 9, ptr %t56
  %t58 = insertvalue { %"compiler/source:Span", i32, { i64, [4 x i64] } } undef, %"compiler/source:Span" %t50, 0
  %t60 = insertvalue { %"compiler/source:Span", i32, { i64, [4 x i64] } } %t58, i32 %a3, 1
  %t62 = insertvalue { %"compiler/source:Span", i32, { i64, [4 x i64] } } %t60, { i64, [4 x i64] } %t54, 2
  %t63 = getelementptr { i64, [8 x i64] }, ptr %t55, i32 0, i32 1
  store { %"compiler/source:Span", i32, { i64, [4 x i64] } } %t62, ptr %t63
  %t64 = load { i64, [8 x i64] }, ptr %t55
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %v1, ptr %v2, ptr %t49, { i64, [8 x i64] } %t64)
  br label %bb13
bb12:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/lower:lowering", ptr %t67, i32 0, i32 0
  %t70 = load ptr, ptr %t69, !tbaa !29
  store ptr %t70, ptr %l37, !tbaa !29
  %t72 = load ptr, ptr %l37, !tbaa !29
  %t73 = call ptr @__olang_scope_or(ptr %v1, ptr %t72)
  %t74 = call ptr @__olang_scope_hold(ptr %t73)
  %t75 = ptrtoint ptr %t74 to i64
  %t77 = inttoptr i64 %t75 to ptr
  %t78 = load ptr, ptr %l37, !tbaa !29
  %t80 = call { i32, i64 } @compiler_2flower_2ecompiler_2flower_3aLowerer_2efailure(ptr %t77, ptr %t78, i64 %a4)
  store { i32, i64 } %t80, ptr %l40
  br label %bb14
bb13:
  br label %bb17
bb14:
  %t81 = load { i32, i64 }, ptr %l40
  store { i32, i64 } %t81, ptr %l8
  %t82 = getelementptr { i32, i64 }, ptr %l8, i32 0, i32 0
  %t83 = load i32, ptr %t82, !tbaa !23
  %t85 = getelementptr { i32, i64 }, ptr %l8, i32 0, i32 1
  %t86 = load i64, ptr %t85, !tbaa !24
  %t88 = load ptr, ptr %l0, !tbaa !29
  store ptr %t88, ptr %l43, !tbaa !29
  %t89 = load i32, ptr @G_2ecompiler_2fmir_2eI32T, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t91
  %t92 = getelementptr { i64, [4 x i64] }, ptr %t91, i32 0, i32 0
  store i64 2, ptr %t92
  %t94 = insertvalue { i32, i64 } undef, i32 %t89, 0
  %t96 = insertvalue { i32, i64 } %t94, i64 %t86, 1
  %t97 = getelementptr { i64, [4 x i64] }, ptr %t91, i32 0, i32 1
  store { i32, i64 } %t96, ptr %t97
  %t98 = load { i64, [4 x i64] }, ptr %t91
  store { i64, [4 x i64] } %t98, ptr %l46
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = getelementptr %"compiler/lower:lowering", ptr %t99, i32 0, i32 2
  %t102 = load ptr, ptr %t101, !tbaa !29
  store ptr %t102, ptr %l48, !tbaa !29
  %t104 = load ptr, ptr %l48, !tbaa !29
  %t105 = call ptr @__olang_scope_or(ptr %v2, ptr %t104)
  %t106 = call ptr @__olang_scope_hold(ptr %t105)
  %t107 = ptrtoint ptr %t106 to i64
  %t109 = inttoptr i64 %t107 to ptr
  %t110 = load ptr, ptr %l48, !tbaa !29
  %t112 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList1(ptr %t109, ptr %t110, i32 %t83)
  store i32 %t112, ptr %l51
  br label %bb15
bb15:
  %t113 = load %"compiler/source:Span", ptr %l5
  %t114 = load ptr, ptr %l43, !tbaa !29
  %t115 = load { i64, [4 x i64] }, ptr %l46
  %t116 = load i32, ptr %l51, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2edispatch(ptr %v0, ptr %v2, ptr %v1, ptr %v3, ptr %v4, ptr %t114, { i64, [4 x i64] } %t115, i32 %t116, %"compiler/source:Span" %t113, i1 true)
  br label %bb16
bb16:
  br label %bb17
bb17:
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t119 = load i32, ptr %l6, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t118, i32 %t119)
  br label %bb18
bb18:
  br label %ret
ret:
  ret void
}

define dso_local { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2econstI64(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %rv = alloca { i64, [4 x i64] }
  %t3 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t3
  %t4 = getelementptr { i64, [4 x i64] }, ptr %t3, i32 0, i32 0
  store i64 2, ptr %t4
  %t6 = insertvalue { i32, i64 } undef, i32 %t1, 0
  %t8 = insertvalue { i32, i64 } %t6, i64 %a1, 1
  %t9 = getelementptr { i64, [4 x i64] }, ptr %t3, i32 0, i32 1
  store { i32, i64 } %t8, ptr %t9
  %t10 = load { i64, [4 x i64] }, ptr %t3
  store { i64, [4 x i64] } %t10, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3alowering_2econvertsApart(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i32
  %l7 = alloca i32
  %l10 = alloca i32
  %l14 = alloca i1
  %l18 = alloca i1
  %l19 = alloca ptr
  %l21 = alloca ptr
  %l24 = alloca i32
  %l26 = alloca ptr
  %l29 = alloca i32
  %l30 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2earrayOf(ptr %v0, ptr %v1, ptr %t1, i32 %a1)
  store i32 %t5, ptr %l7
  br label %bb1
bb1:
  %t6 = load i32, ptr %l7, !tbaa !23
  store i32 %t6, ptr %l3, !tbaa !23
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t11 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2earrayOf(ptr %v0, ptr %v1, ptr %t7, i32 %a2)
  store i32 %t11, ptr %l10
  br label %bb2
bb2:
  %t12 = load i32, ptr %l10, !tbaa !23
  store i32 %t12, ptr %l4, !tbaa !23
  %t13 = load i32, ptr %l3, !tbaa !23
  %t14 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t17 = icmp ne i32 %t13, %t14
  br i1 %t17, label %bb3, label %bb4
bb3:
  %t19 = load i32, ptr %l4, !tbaa !23
  %t20 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t23 = icmp ne i32 %t19, %t20
  store i1 %t23, ptr %l14, !tbaa !21
  br label %bb5
bb4:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb5
bb5:
  %t25 = load i1, ptr %l14, !tbaa !21
  br i1 %t25, label %bb6, label %bb7
bb6:
  %t26 = load ptr, ptr %l0, !tbaa !29
  store ptr %t26, ptr %l19, !tbaa !29
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/lower:lowering", ptr %t27, i32 0, i32 2
  %t30 = load ptr, ptr %t29, !tbaa !29
  store ptr %t30, ptr %l21, !tbaa !29
  %t31 = load i32, ptr %l3, !tbaa !23
  %t32 = load ptr, ptr %l21, !tbaa !29
  %t33 = call ptr @__olang_scope_or(ptr %v1, ptr %t32)
  %t34 = call ptr @__olang_scope_hold(ptr %t33)
  %t35 = ptrtoint ptr %t34 to i64
  %t37 = inttoptr i64 %t35 to ptr
  %t38 = load ptr, ptr %l21, !tbaa !29
  %t40 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %t37, ptr %t38, i32 %t31)
  store i32 %t40, ptr %l24
  br label %bb8
bb7:
  store i1 false, ptr %l18, !tbaa !21
  br label %bb11
bb8:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/lower:lowering", ptr %t41, i32 0, i32 2
  %t44 = load ptr, ptr %t43, !tbaa !29
  store ptr %t44, ptr %l26, !tbaa !29
  %t45 = load i32, ptr %l4, !tbaa !23
  %t46 = load ptr, ptr %l26, !tbaa !29
  %t47 = call ptr @__olang_scope_or(ptr %v1, ptr %t46)
  %t48 = call ptr @__olang_scope_hold(ptr %t47)
  %t49 = ptrtoint ptr %t48 to i64
  %t51 = inttoptr i64 %t49 to ptr
  %t52 = load ptr, ptr %l26, !tbaa !29
  %t54 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %t51, ptr %t52, i32 %t45)
  store i32 %t54, ptr %l29
  br label %bb9
bb9:
  %t55 = load ptr, ptr %l19, !tbaa !29
  %t56 = load i32, ptr %l24, !tbaa !23
  %t57 = load i32, ptr %l29, !tbaa !23
  %t58 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2elaidApart(ptr %v0, ptr %v1, ptr %t55, i32 %t56, i32 %t57)
  store i1 %t58, ptr %l30
  br label %bb10
bb10:
  %t59 = load i1, ptr %l30, !tbaa !21
  store i1 %t59, ptr %l18, !tbaa !21
  br label %bb11
bb11:
  %t60 = load i1, ptr %l18, !tbaa !21
  store i1 %t60, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3alowering_2ecopiesArray(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l5 = alloca i1
  %l10 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2evalueArray(ptr %v0, ptr %v2, ptr %t1, i32 %a2)
  store i1 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i1, ptr %l5, !tbaa !21
  %t7 = xor i1 %t6, true
  br i1 %t7, label %bb2, label %bb3
bb2:
  store i1 false, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t14 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2ecopiesValue(ptr %v0, ptr %v1, ptr %v2, ptr %t10, ptr %a1)
  store i1 %t14, ptr %l10
  br label %bb5
bb5:
  %t15 = load i1, ptr %l10, !tbaa !21
  store i1 %t15, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3alowering_2ecopiesValue(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i1
  %l11 = alloca ptr
  %l12 = alloca i1
  %l15 = alloca ptr
  %l16 = alloca i1
  %l27 = alloca i1
  %l31 = alloca i1
  %l32 = alloca { i64, ptr }
  %l34 = alloca ptr
  %l37 = alloca i1
  %l38 = alloca ptr
  %l39 = alloca { i64, ptr }
  %l41 = alloca i32
  %l42 = alloca i1
  %l43 = alloca i1
  %l45 = alloca { i64, ptr }
  %l47 = alloca i1
  %l48 = alloca i1
  %l53 = alloca i1
  %l54 = alloca i1
  %l56 = alloca { i64, ptr }
  %l58 = alloca i1
  %l60 = alloca ptr
  %l61 = alloca i1
  %l68 = alloca i1
  %l69 = alloca ptr
  %l70 = alloca i1
  %l79 = alloca i1
  %l80 = alloca ptr
  %l86 = alloca i1
  %l87 = alloca ptr
  %l88 = alloca i1
  %l97 = alloca i1
  %l98 = alloca ptr
  %l104 = alloca i1
  %l105 = alloca i1
  %l109 = alloca i1
  %l110 = alloca ptr
  %l111 = alloca i1
  %l118 = alloca i1
  %l119 = alloca ptr
  %l120 = alloca i1
  %l127 = alloca i1
  %s2 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l11, !tbaa !29
  store i1 false, ptr %l12, !tbaa !21
  %t2 = load ptr, ptr %l11, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l11, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l12, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l12, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb6
bb5:
  store i1 true, ptr %l10, !tbaa !21
  br label %bb92
bb6:
  %t10 = load ptr, ptr %l1, !tbaa !29
  store ptr %t10, ptr %l15, !tbaa !29
  store i1 false, ptr %l16, !tbaa !21
  %t11 = load ptr, ptr %l15, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb7, label %bb8
bb7:
  %t14 = load ptr, ptr %l15, !tbaa !29
  %t15 = load i64, ptr %t14, !range !{i64 0, i64 18}
  %t17 = icmp eq i64 %t15, 9
  store i1 %t17, ptr %l16, !tbaa !21
  br label %bb8
bb8:
  %t18 = load i1, ptr %l16, !tbaa !21
  br i1 %t18, label %bb9, label %bb10
bb9:
  %t19 = load ptr, ptr %l1, !tbaa !29
  %t21 = getelementptr { i64, [5 x i64] }, ptr %t19, i32 0, i32 1
  %t22 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t21, i32 0, i32 1
  %t23 = load i32, ptr %t22
  store i32 %t23, ptr %l2, !tbaa !23
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr { i64, [5 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t27, i32 0, i32 2
  %t29 = load i32, ptr %t28, !range !{i32 0, i32 54}
  store i32 %t29, ptr %l3
  %t31 = load ptr, ptr %l1, !tbaa !29
  %t33 = getelementptr { i64, [5 x i64] }, ptr %t31, i32 0, i32 1
  %t34 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t33, i32 0, i32 4
  %t35 = load { i64, ptr }, ptr %t34
  store { i64, ptr } %t35, ptr %l4, !tbaa !27
  br label %bb11
bb10:
  br label %bb36
bb11:
  store %olang.scope zeroinitializer, ptr %s2
  %t37 = load i32, ptr %l3, !range !{i32 0, i32 54}
  %t39 = trunc i64 20 to i32
  %t40 = icmp eq i32 %t37, %t39
  br i1 %t40, label %bb12, label %bb13
bb12:
  %t42 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t44 = extractvalue { i64, ptr } %t42, 0
  %t46 = icmp eq i64 %t44, 1
  store i1 %t46, ptr %l27, !tbaa !21
  br label %bb14
bb13:
  store i1 false, ptr %l27, !tbaa !21
  br label %bb14
bb14:
  %t48 = load i1, ptr %l27, !tbaa !21
  br i1 %t48, label %bb15, label %bb16
bb15:
  %t49 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t49, ptr %l32, !tbaa !27
  %t50 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t51 = load ptr, ptr %t50, !tbaa !27
  %t52 = getelementptr ptr, ptr %t51, i64 0
  %t53 = load ptr, ptr %t52, !tbaa !39
  %t55 = call ptr @compiler_2flower_2ederefOf(ptr %v1, ptr %s2, ptr %t53)
  store ptr %t55, ptr %l34
  br label %bb17
bb16:
  store i1 false, ptr %l31, !tbaa !21
  br label %bb35
bb17:
  %t56 = load ptr, ptr %l34, !tbaa !29
  %t57 = icmp eq ptr %t56, null
  %t59 = xor i1 %t57, true
  br i1 %t59, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l37, !tbaa !21
  br label %bb26
bb19:
  %t61 = load ptr, ptr %l0, !tbaa !29
  store ptr %t61, ptr %l38, !tbaa !29
  %t62 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t62, ptr %l39, !tbaa !27
  %t63 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t64 = load ptr, ptr %t63, !tbaa !27
  %t65 = getelementptr ptr, ptr %t64, i64 0
  %t66 = load ptr, ptr %t65, !tbaa !39
  %t68 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t66)
  store i32 %t68, ptr %l41
  br label %bb20
bb20:
  %t69 = load ptr, ptr %l38, !tbaa !29
  %t70 = load i32, ptr %l41, !tbaa !23
  %t71 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2evalueArray(ptr %v0, ptr %v2, ptr %t69, i32 %t70)
  store i1 %t71, ptr %l42
  br label %bb21
bb21:
  %t72 = load i1, ptr %l42, !tbaa !21
  br i1 %t72, label %bb22, label %bb23
bb22:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t74 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t74, ptr %l45, !tbaa !27
  %t75 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = getelementptr ptr, ptr %t76, i64 0
  %t78 = load ptr, ptr %t77, !tbaa !39
  %t81 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2ecopiesValue(ptr %v0, ptr %v1, ptr %v2, ptr %t73, ptr %t78)
  store i1 %t81, ptr %l47
  br label %bb24
bb23:
  store i1 false, ptr %l43, !tbaa !21
  br label %bb25
bb24:
  %t82 = load i1, ptr %l47, !tbaa !21
  store i1 %t82, ptr %l43, !tbaa !21
  br label %bb25
bb25:
  %t83 = load i1, ptr %l43, !tbaa !21
  store i1 %t83, ptr %l37, !tbaa !21
  br label %bb26
bb26:
  %t84 = load i1, ptr %l37, !tbaa !21
  br i1 %t84, label %bb27, label %bb28
bb27:
  store i1 true, ptr %l48, !tbaa !21
  br label %bb34
bb28:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t86 = load i32, ptr %l3, !range !{i32 0, i32 54}
  %t87 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t88 = load i32, ptr %l2, !tbaa !23
  %t93 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2ewidening(ptr %v0, ptr %v1, ptr %v2, ptr %t85, i32 %t86, { i64, ptr } %t87, i32 %t88)
  store i1 %t93, ptr %l53
  br label %bb29
bb29:
  %t94 = load i1, ptr %l53, !tbaa !21
  br i1 %t94, label %bb30, label %bb31
bb30:
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t96 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t96, ptr %l56, !tbaa !27
  %t97 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t98 = load ptr, ptr %t97, !tbaa !27
  %t99 = getelementptr ptr, ptr %t98, i64 0
  %t100 = load ptr, ptr %t99, !tbaa !39
  %t103 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eregionMade(ptr %v0, ptr %v1, ptr %t95, ptr %t100)
  store i1 %t103, ptr %l58
  br label %bb32
bb31:
  store i1 false, ptr %l54, !tbaa !21
  br label %bb33
bb32:
  %t104 = load i1, ptr %l58, !tbaa !21
  %t105 = xor i1 %t104, true
  store i1 %t105, ptr %l54, !tbaa !21
  br label %bb33
bb33:
  %t107 = load i1, ptr %l54, !tbaa !21
  store i1 %t107, ptr %l48, !tbaa !21
  br label %bb34
bb34:
  %t108 = load i1, ptr %l48, !tbaa !21
  store i1 %t108, ptr %l31, !tbaa !21
  br label %bb35
bb35:
  %t109 = load i1, ptr %l31, !tbaa !21
  store i1 %t109, ptr %l10, !tbaa !21
  call void @__olang_scope_close(ptr %s2)
  br label %bb92
bb36:
  %t110 = load ptr, ptr %l1, !tbaa !29
  store ptr %t110, ptr %l60, !tbaa !29
  store i1 false, ptr %l61, !tbaa !21
  %t111 = load ptr, ptr %l60, !tbaa !29
  %t112 = icmp ne ptr %t111, null
  br i1 %t112, label %bb37, label %bb38
bb37:
  %t114 = load ptr, ptr %l60, !tbaa !29
  %t115 = load i64, ptr %t114, !range !{i64 0, i64 18}
  %t117 = icmp eq i64 %t115, 17
  store i1 %t117, ptr %l61, !tbaa !21
  br label %bb38
bb38:
  %t118 = load i1, ptr %l61, !tbaa !21
  br i1 %t118, label %bb39, label %bb40
bb39:
  %t119 = load ptr, ptr %l1, !tbaa !29
  %t121 = getelementptr { i64, [5 x i64] }, ptr %t119, i32 0, i32 1
  %t122 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t121, i32 0, i32 2
  %t123 = load ptr, ptr %t122
  store ptr %t123, ptr %l5, !tbaa !29
  br label %bb41
bb40:
  br label %bb43
bb41:
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t126 = load ptr, ptr %l5, !tbaa !29
  %t129 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2ecopiesValue(ptr %v0, ptr %v1, ptr %v2, ptr %t125, ptr %t126)
  store i1 %t129, ptr %l68
  br label %bb42
bb42:
  %t130 = load i1, ptr %l68, !tbaa !21
  store i1 %t130, ptr %l10, !tbaa !21
  br label %bb92
bb43:
  %t131 = load ptr, ptr %l1, !tbaa !29
  store ptr %t131, ptr %l69, !tbaa !29
  store i1 false, ptr %l70, !tbaa !21
  %t132 = load ptr, ptr %l69, !tbaa !29
  %t133 = icmp ne ptr %t132, null
  br i1 %t133, label %bb44, label %bb45
bb44:
  %t135 = load ptr, ptr %l69, !tbaa !29
  %t136 = load i64, ptr %t135, !range !{i64 0, i64 18}
  %t138 = icmp eq i64 %t136, 12
  store i1 %t138, ptr %l70, !tbaa !21
  br label %bb45
bb45:
  %t139 = load i1, ptr %l70, !tbaa !21
  br i1 %t139, label %bb46, label %bb47
bb46:
  %t140 = load ptr, ptr %l1, !tbaa !29
  %t142 = getelementptr { i64, [5 x i64] }, ptr %t140, i32 0, i32 1
  %t143 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t142, i32 0, i32 2
  %t144 = load ptr, ptr %t143
  store ptr %t144, ptr %l6, !tbaa !29
  br label %bb48
bb47:
  br label %bb56
bb48:
  %t146 = load ptr, ptr %l6, !tbaa !29
  %t148 = getelementptr %"compiler/typed:Seq", ptr %t146, i32 0, i32 1
  %t149 = load ptr, ptr %t148, !tbaa !29
  %t151 = icmp eq ptr %t149, null
  %t153 = xor i1 %t151, true
  br i1 %t153, label %bb49, label %bb50
bb49:
  %t155 = load ptr, ptr %l0, !tbaa !29
  store ptr %t155, ptr %l80, !tbaa !29
  %t156 = load ptr, ptr %l6, !tbaa !29
  %t158 = getelementptr %"compiler/typed:Seq", ptr %t156, i32 0, i32 1
  %t159 = load ptr, ptr %t158, !tbaa !29
  %t161 = icmp eq ptr %t159, null
  br i1 %t161, label %bb51, label %bb52
bb50:
  store i1 false, ptr %l79, !tbaa !21
  br label %bb55
bb51:
  call void @__olang_check_failed(ptr @olang_loc_755da8ec4c9a9682_903a5def85eef08e)
  unreachable
bb52:
  br label %bb53
bb53:
  %t163 = load ptr, ptr %l6, !tbaa !29
  %t165 = getelementptr %"compiler/typed:Seq", ptr %t163, i32 0, i32 1
  %t166 = load ptr, ptr %t165, !tbaa !29
  %t167 = load ptr, ptr %l80, !tbaa !29
  %t169 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2ecopiesValue(ptr %v0, ptr %v1, ptr %v2, ptr %t167, ptr %t166)
  store i1 %t169, ptr %l86
  br label %bb54
bb54:
  %t170 = load i1, ptr %l86, !tbaa !21
  store i1 %t170, ptr %l79, !tbaa !21
  br label %bb55
bb55:
  %t171 = load i1, ptr %l79, !tbaa !21
  store i1 %t171, ptr %l10, !tbaa !21
  br label %bb92
bb56:
  %t172 = load ptr, ptr %l1, !tbaa !29
  store ptr %t172, ptr %l87, !tbaa !29
  store i1 false, ptr %l88, !tbaa !21
  %t173 = load ptr, ptr %l87, !tbaa !29
  %t174 = icmp ne ptr %t173, null
  br i1 %t174, label %bb57, label %bb58
bb57:
  %t176 = load ptr, ptr %l87, !tbaa !29
  %t177 = load i64, ptr %t176, !range !{i64 0, i64 18}
  %t179 = icmp eq i64 %t177, 11
  store i1 %t179, ptr %l88, !tbaa !21
  br label %bb58
bb58:
  %t180 = load i1, ptr %l88, !tbaa !21
  br i1 %t180, label %bb59, label %bb60
bb59:
  %t181 = load ptr, ptr %l1, !tbaa !29
  %t183 = getelementptr { i64, [5 x i64] }, ptr %t181, i32 0, i32 1
  %t184 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t183, i32 0, i32 2
  %t185 = load ptr, ptr %t184
  store ptr %t185, ptr %l7, !tbaa !29
  br label %bb61
bb60:
  br label %bb73
bb61:
  %t187 = load ptr, ptr %l7, !tbaa !29
  %t189 = getelementptr %"compiler/typed:Cond", ptr %t187, i32 0, i32 1
  %t190 = load ptr, ptr %t189, !tbaa !29
  %t192 = icmp eq ptr %t190, null
  %t194 = xor i1 %t192, true
  br i1 %t194, label %bb62, label %bb63
bb62:
  %t196 = load ptr, ptr %l0, !tbaa !29
  store ptr %t196, ptr %l98, !tbaa !29
  %t197 = load ptr, ptr %l7, !tbaa !29
  %t199 = getelementptr %"compiler/typed:Cond", ptr %t197, i32 0, i32 1
  %t200 = load ptr, ptr %t199, !tbaa !29
  %t202 = icmp eq ptr %t200, null
  br i1 %t202, label %bb64, label %bb65
bb63:
  store i1 false, ptr %l97, !tbaa !21
  br label %bb68
bb64:
  call void @__olang_check_failed(ptr @olang_loc_cd5f024afedc1d69_a0cc122b0d762c35)
  unreachable
bb65:
  br label %bb66
bb66:
  %t204 = load ptr, ptr %l7, !tbaa !29
  %t206 = getelementptr %"compiler/typed:Cond", ptr %t204, i32 0, i32 1
  %t207 = load ptr, ptr %t206, !tbaa !29
  %t208 = load ptr, ptr %l98, !tbaa !29
  %t210 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2ecopiesValue(ptr %v0, ptr %v1, ptr %v2, ptr %t208, ptr %t207)
  store i1 %t210, ptr %l104
  br label %bb67
bb67:
  %t211 = load i1, ptr %l104, !tbaa !21
  store i1 %t211, ptr %l97, !tbaa !21
  br label %bb68
bb68:
  %t212 = load i1, ptr %l97, !tbaa !21
  br i1 %t212, label %bb69, label %bb70
bb69:
  store i1 true, ptr %l105, !tbaa !21
  br label %bb72
bb70:
  %t213 = load ptr, ptr %l0, !tbaa !29
  %t214 = load ptr, ptr %l7, !tbaa !29
  %t216 = getelementptr %"compiler/typed:Cond", ptr %t214, i32 0, i32 2
  %t217 = load ptr, ptr %t216, !tbaa !29
  %t220 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2ecopiesValue(ptr %v0, ptr %v1, ptr %v2, ptr %t213, ptr %t217)
  store i1 %t220, ptr %l109
  br label %bb71
bb71:
  %t221 = load i1, ptr %l109, !tbaa !21
  store i1 %t221, ptr %l105, !tbaa !21
  br label %bb72
bb72:
  %t222 = load i1, ptr %l105, !tbaa !21
  store i1 %t222, ptr %l10, !tbaa !21
  br label %bb92
bb73:
  %t223 = load ptr, ptr %l1, !tbaa !29
  store ptr %t223, ptr %l110, !tbaa !29
  store i1 false, ptr %l111, !tbaa !21
  %t224 = load ptr, ptr %l110, !tbaa !29
  %t225 = icmp ne ptr %t224, null
  br i1 %t225, label %bb74, label %bb75
bb74:
  %t227 = load ptr, ptr %l110, !tbaa !29
  %t228 = load i64, ptr %t227, !range !{i64 0, i64 18}
  %t230 = icmp eq i64 %t228, 13
  store i1 %t230, ptr %l111, !tbaa !21
  br label %bb75
bb75:
  %t231 = load i1, ptr %l111, !tbaa !21
  br i1 %t231, label %bb76, label %bb77
bb76:
  %t232 = load ptr, ptr %l1, !tbaa !29
  %t234 = getelementptr { i64, [5 x i64] }, ptr %t232, i32 0, i32 1
  %t235 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t234, i32 0, i32 2
  %t236 = load ptr, ptr %t235
  store ptr %t236, ptr %l8, !tbaa !29
  br label %bb78
bb77:
  br label %bb80
bb78:
  %t238 = load ptr, ptr %l0, !tbaa !29
  %t239 = load ptr, ptr %l8, !tbaa !29
  %t242 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2ematchCopies(ptr %v0, ptr %v1, ptr %v2, ptr %t238, ptr %t239)
  store i1 %t242, ptr %l118
  br label %bb79
bb79:
  %t243 = load i1, ptr %l118, !tbaa !21
  store i1 %t243, ptr %l10, !tbaa !21
  br label %bb92
bb80:
  %t244 = load ptr, ptr %l1, !tbaa !29
  store ptr %t244, ptr %l119, !tbaa !29
  store i1 false, ptr %l120, !tbaa !21
  %t245 = load ptr, ptr %l119, !tbaa !29
  %t246 = icmp ne ptr %t245, null
  br i1 %t246, label %bb81, label %bb82
bb81:
  %t248 = load ptr, ptr %l119, !tbaa !29
  %t249 = load i64, ptr %t248, !range !{i64 0, i64 18}
  %t251 = icmp eq i64 %t249, 14
  store i1 %t251, ptr %l120, !tbaa !21
  br label %bb82
bb82:
  %t252 = load i1, ptr %l120, !tbaa !21
  br i1 %t252, label %bb83, label %bb84
bb83:
  %t253 = load ptr, ptr %l1, !tbaa !29
  %t255 = getelementptr { i64, [5 x i64] }, ptr %t253, i32 0, i32 1
  %t256 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t255, i32 0, i32 2
  %t257 = load ptr, ptr %t256
  store ptr %t257, ptr %l9, !tbaa !29
  br label %bb85
bb84:
  br label %bb87
bb85:
  %t259 = load ptr, ptr %l0, !tbaa !29
  %t260 = load ptr, ptr %l9, !tbaa !29
  %t263 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2etryCopies(ptr %v0, ptr %v1, ptr %v2, ptr %t259, ptr %t260)
  store i1 %t263, ptr %l127
  br label %bb86
bb86:
  %t264 = load i1, ptr %l127, !tbaa !21
  store i1 %t264, ptr %l10, !tbaa !21
  br label %bb92
bb87:
  br i1 true, label %bb88, label %bb89
bb88:
  br label %bb90
bb89:
  br label %bb91
bb90:
  store i1 false, ptr %l10, !tbaa !21
  br label %bb92
bb91:
  call void @__olang_check_failed(ptr @olang_loc_9d7bd0ecfcbf809b_94241bedce5fc567)
  unreachable
bb92:
  %t265 = load i1, ptr %l10, !tbaa !21
  store i1 %t265, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ecopyLocal(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca %"compiler/mir:Lvalue"
  %rv = alloca { i64, [4 x i64] }
  %t4 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %a1)
  store %"compiler/mir:Lvalue" %t3, ptr %l3
  br label %bb1
bb1:
  store { i64, [4 x i64] } zeroinitializer, ptr %t4
  %t5 = getelementptr { i64, [4 x i64] }, ptr %t4, i32 0, i32 0
  store i64 1, ptr %t5
  %t6 = load %"compiler/mir:Lvalue", ptr %l3
  %t7 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t6, 0
  %t8 = getelementptr { i64, [4 x i64] }, ptr %t4, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t7, ptr %t8
  %t9 = load { i64, [4 x i64] }, ptr %t4
  store { i64, [4 x i64] } %t9, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2ecopyPart(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/lower:pl" %a1, i32 %a2, { i64, [1 x i64] } %a3, %"compiler/source:Span" %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/lower:pl"
  %l2 = alloca i32
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca { i64, [4 x i64] }
  %l8 = alloca i1
  %l10 = alloca ptr
  %l11 = alloca %"compiler/lower:pl"
  %l13 = alloca %"compiler/lower:pl"
  %l17 = alloca { i64, [4 x i64] }
  %l18 = alloca ptr
  %l19 = alloca %"compiler/source:Span"
  %l20 = alloca ptr
  %l21 = alloca %"compiler/lower:pl"
  %l23 = alloca %"compiler/lower:pl"
  %l24 = alloca %"compiler/mir:Lvalue"
  %s0 = alloca %olang.scope
  %t33 = alloca { i64, [15 x i64] }, align 8
  %t39 = alloca { i64, [21 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/lower:pl" %a1, ptr %l1
  store i32 %a2, ptr %l2
  store %"compiler/source:Span" %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l2, !tbaa !23
  %t5 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eownsStorage(ptr %v0, ptr %v2, ptr %t1, i32 %t2)
  store i1 %t5, ptr %l8
  br label %bb1
bb1:
  %t6 = load i1, ptr %l8, !tbaa !21
  %t7 = xor i1 %t6, true
  br i1 %t7, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb3:
  br label %bb4
bb4:
  %t9 = load ptr, ptr %l0, !tbaa !29
  store ptr %t9, ptr %l10, !tbaa !29
  %t10 = load %"compiler/lower:pl", ptr %l1
  store %"compiler/lower:pl" %t10, ptr %l11
  %t12 = call %"compiler/lower:pl" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2flower_3apl(ptr %s0, ptr %l11)
  store %"compiler/lower:pl" %t12, ptr %l13
  br label %bb5
bb5:
  %t13 = load i32, ptr %l2, !tbaa !23
  %t15 = load %"compiler/source:Span", ptr %l4
  %t16 = load ptr, ptr %l10, !tbaa !29
  %t17 = load %"compiler/lower:pl", ptr %l13
  %t21 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ecopyAt(ptr %v0, ptr %s0, ptr %v2, ptr %v3, ptr %t16, %"compiler/lower:pl" %t17, i32 %t13, { i64, [1 x i64] } %a3, %"compiler/source:Span" %t15, i1 false, i1 false)
  store { i64, [4 x i64] } %t21, ptr %l17
  br label %bb6
bb6:
  %t22 = load { i64, [4 x i64] }, ptr %l17
  store { i64, [4 x i64] } %t22, ptr %l5
  %t23 = load ptr, ptr %l0, !tbaa !29
  store ptr %t23, ptr %l18, !tbaa !29
  %t24 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t24, ptr %l19
  %t25 = load ptr, ptr %l0, !tbaa !29
  store ptr %t25, ptr %l20, !tbaa !29
  %t26 = load %"compiler/lower:pl", ptr %l1
  store %"compiler/lower:pl" %t26, ptr %l21
  %t28 = call %"compiler/lower:pl" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2flower_3apl(ptr %s0, ptr %l21)
  store %"compiler/lower:pl" %t28, ptr %l23
  br label %bb7
bb7:
  %t29 = load ptr, ptr %l20, !tbaa !29
  %t30 = load %"compiler/lower:pl", ptr %l23
  %t31 = call %"compiler/mir:Lvalue" @compiler_2flower_2ecompiler_2flower_3alowering_2emk(ptr %v0, ptr %s0, ptr %v3, ptr %t29, %"compiler/lower:pl" %t30)
  store %"compiler/mir:Lvalue" %t31, ptr %l24
  br label %bb8
bb8:
  %t32 = load { i64, [4 x i64] }, ptr %l5
  store { i64, [15 x i64] } zeroinitializer, ptr %t33
  %t34 = getelementptr { i64, [15 x i64] }, ptr %t33, i32 0, i32 0
  store i64 0, ptr %t34
  %t36 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t32, 0
  %t37 = getelementptr { i64, [15 x i64] }, ptr %t33, i32 0, i32 1
  store { { i64, [4 x i64] } } %t36, ptr %t37
  %t38 = load { i64, [15 x i64] }, ptr %t33
  store { i64, [21 x i64] } zeroinitializer, ptr %t39
  %t40 = getelementptr { i64, [21 x i64] }, ptr %t39, i32 0, i32 0
  store i64 0, ptr %t40
  %t41 = load %"compiler/source:Span", ptr %l19
  %t42 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t41, 0
  %t43 = load %"compiler/mir:Lvalue", ptr %l24
  %t44 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t42, %"compiler/mir:Lvalue" %t43, 1
  %t46 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t44, { i64, [15 x i64] } %t38, 2
  %t47 = getelementptr { i64, [21 x i64] }, ptr %t39, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t46, ptr %t47
  %t48 = load { i64, [21 x i64] }, ptr %t39
  %t50 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t48, ptr %t50
  %t51 = load ptr, ptr %l18, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s0, ptr %v2, ptr %v3, ptr %t51, ptr %t50)
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2flower_2ecompiler_2flower_3alowering_2ecopySlots(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca i64
  %l9 = alloca i1
  %l30 = alloca i64
  %l31 = alloca ptr
  %l34 = alloca i64
  %l35 = alloca ptr
  %l39 = alloca i64
  %l40 = alloca ptr
  %l43 = alloca i1
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/lower:Lowerer", ptr %t4, i32 0, i32 12
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = icmp eq ptr %t7, null
  br i1 %t9, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb6
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/lower:lowering", ptr %t11, i32 0, i32 0
  %t14 = load ptr, ptr %t13, !tbaa !29
  %t16 = getelementptr %"compiler/lower:Lowerer", ptr %t14, i32 0, i32 12
  %t17 = load ptr, ptr %t16, !tbaa !29
  %t19 = icmp eq ptr %t17, null
  br i1 %t19, label %bb3, label %bb4
bb3:
  call void @__olang_check_failed(ptr @olang_loc_9734ff52b1aa485e_990a10ecf234c10a)
  unreachable
bb4:
  br label %bb5
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/lower:lowering", ptr %t21, i32 0, i32 0
  %t24 = load ptr, ptr %t23, !tbaa !29
  %t26 = getelementptr %"compiler/lower:Lowerer", ptr %t24, i32 0, i32 12
  %t27 = load ptr, ptr %t26, !tbaa !29
  %t30 = getelementptr %"compiler/free:Free", ptr %t27, i32 0, i32 179
  %t31 = load i1, ptr %t30, !tbaa !21
  %t33 = xor i1 %t31, true
  store i1 %t33, ptr %l9, !tbaa !21
  br label %bb6
bb6:
  %t35 = load i1, ptr %l9, !tbaa !21
  br i1 %t35, label %bb7, label %bb8
bb7:
  store i64 -1, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/lower:lowering", ptr %t37, i32 0, i32 0
  %t40 = load ptr, ptr %t39, !tbaa !29
  %t42 = getelementptr %"compiler/lower:Lowerer", ptr %t40, i32 0, i32 12
  %t43 = load ptr, ptr %t42, !tbaa !29
  %t45 = icmp eq ptr %t43, null
  br i1 %t45, label %bb10, label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_ae9d9b0e355a2005_a6ba10fc82c4da11)
  unreachable
bb11:
  br label %bb12
bb12:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/lower:lowering", ptr %t47, i32 0, i32 0
  %t50 = load ptr, ptr %t49, !tbaa !29
  %t52 = getelementptr %"compiler/lower:Lowerer", ptr %t50, i32 0, i32 12
  %t53 = load ptr, ptr %t52, !tbaa !29
  store ptr %t53, ptr %l3, !tbaa !29
  %t55 = load i64, ptr %l2, !tbaa !24
  %t57 = icmp slt i64 %t55, 0
  br i1 %t57, label %bb13, label %bb14
bb13:
  %t59 = load ptr, ptr %l3, !tbaa !29
  store ptr %t59, ptr %l31, !tbaa !29
  %t60 = load i32, ptr %l1, !tbaa !23
  %t61 = load ptr, ptr %l31, !tbaa !29
  %t62 = call ptr @__olang_scope_or(ptr %v1, ptr %t61)
  %t63 = call ptr @__olang_scope_hold(ptr %t62)
  %t64 = ptrtoint ptr %t63 to i64
  %t66 = inttoptr i64 %t64 to ptr
  %t67 = load ptr, ptr %l31, !tbaa !29
  %t69 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eElemPlace(ptr %t66, ptr %t67, i32 %t60)
  store i64 %t69, ptr %l34
  br label %bb15
bb14:
  %t70 = load ptr, ptr %l3, !tbaa !29
  store ptr %t70, ptr %l35, !tbaa !29
  %t71 = load i32, ptr %l1, !tbaa !23
  %t72 = load i64, ptr %l2, !tbaa !24
  %t73 = load ptr, ptr %l35, !tbaa !29
  %t74 = call ptr @__olang_scope_or(ptr %v1, ptr %t73)
  %t75 = call ptr @__olang_scope_hold(ptr %t74)
  %t76 = ptrtoint ptr %t75 to i64
  %t78 = inttoptr i64 %t76 to ptr
  %t79 = load ptr, ptr %l35, !tbaa !29
  %t82 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eFieldPlace(ptr %t78, ptr %t79, i32 %t71, i64 %t72)
  store i64 %t82, ptr %l39
  br label %bb16
bb15:
  %t83 = load i64, ptr %l34, !tbaa !24
  store i64 %t83, ptr %l30, !tbaa !24
  br label %bb17
bb16:
  %t84 = load i64, ptr %l39, !tbaa !24
  store i64 %t84, ptr %l30, !tbaa !24
  br label %bb17
bb17:
  %t85 = load i64, ptr %l30, !tbaa !24
  store i64 %t85, ptr %l4, !tbaa !24
  %t86 = load ptr, ptr %l3, !tbaa !29
  store ptr %t86, ptr %l40, !tbaa !29
  %t87 = load i64, ptr %l4, !tbaa !24
  %t88 = load ptr, ptr %l40, !tbaa !29
  %t89 = call ptr @__olang_scope_or(ptr %v1, ptr %t88)
  %t90 = call ptr @__olang_scope_hold(ptr %t89)
  %t91 = ptrtoint ptr %t90 to i64
  %t93 = inttoptr i64 %t91 to ptr
  %t94 = load ptr, ptr %l40, !tbaa !29
  %t96 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eSlotPlace(ptr %t93, ptr %t94, i64 %t87)
  store i1 %t96, ptr %l43
  br label %bb18
bb18:
  %t97 = load i1, ptr %l43, !tbaa !21
  %t98 = xor i1 %t97, true
  br i1 %t98, label %bb19, label %bb20
bb19:
  store i64 -1, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  %t101 = load i64, ptr %l4, !tbaa !24
  store i64 %t101, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3alowering_2ecounts(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l4 = alloca ptr
  %l7 = alloca i32
  %l9 = alloca ptr
  %l12 = alloca i32
  %l15 = alloca i1
  %l17 = alloca ptr
  %l20 = alloca i32
  %l24 = alloca ptr
  %l29 = alloca ptr
  %l31 = alloca ptr
  %l35 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t5 = load i32, ptr %l1, !tbaa !23
  %t6 = load ptr, ptr %l4, !tbaa !29
  %t7 = call ptr @__olang_scope_or(ptr %v1, ptr %t6)
  %t8 = call ptr @__olang_scope_hold(ptr %t7)
  %t9 = ptrtoint ptr %t8 to i64
  %t11 = inttoptr i64 %t9 to ptr
  %t12 = load ptr, ptr %l4, !tbaa !29
  %t14 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %t11, ptr %t12, i32 %t5)
  store i32 %t14, ptr %l7
  br label %bb1
bb1:
  %t15 = load i32, ptr %l7, !tbaa !23
  store i32 %t15, ptr %l2, !tbaa !23
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/lower:lowering", ptr %t16, i32 0, i32 2
  %t19 = load ptr, ptr %t18, !tbaa !29
  store ptr %t19, ptr %l9, !tbaa !29
  %t20 = load i32, ptr %l2, !tbaa !23
  %t21 = load ptr, ptr %l9, !tbaa !29
  %t22 = call ptr @__olang_scope_or(ptr %v1, ptr %t21)
  %t23 = call ptr @__olang_scope_hold(ptr %t22)
  %t24 = ptrtoint ptr %t23 to i64
  %t26 = inttoptr i64 %t24 to ptr
  %t27 = load ptr, ptr %l9, !tbaa !29
  %t29 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %t26, ptr %t27, i32 %t20)
  store i32 %t29, ptr %l12
  br label %bb2
bb2:
  %t30 = load i32, ptr %l12, !range !{i32 0, i32 33}
  %t32 = trunc i64 19 to i32
  %t33 = icmp eq i32 %t30, %t32
  br i1 %t33, label %bb3, label %bb4
bb3:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/lower:lowering", ptr %t35, i32 0, i32 2
  %t38 = load ptr, ptr %t37, !tbaa !29
  store ptr %t38, ptr %l17, !tbaa !29
  %t39 = load i32, ptr %l2, !tbaa !23
  %t40 = load ptr, ptr %l17, !tbaa !29
  %t41 = call ptr @__olang_scope_or(ptr %v1, ptr %t40)
  %t42 = call ptr @__olang_scope_hold(ptr %t41)
  %t43 = ptrtoint ptr %t42 to i64
  %t45 = inttoptr i64 %t43 to ptr
  %t46 = load ptr, ptr %l17, !tbaa !29
  %t48 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %t45, ptr %t46, i32 %t39)
  store i32 %t48, ptr %l20
  br label %bb5
bb4:
  store i1 false, ptr %l15, !tbaa !21
  br label %bb6
bb5:
  %t49 = load i32, ptr %l20, !tbaa !23
  %t50 = icmp eq i32 %t49, 0
  store i1 %t50, ptr %l15, !tbaa !21
  br label %bb6
bb6:
  %t52 = load i1, ptr %l15, !tbaa !21
  br i1 %t52, label %bb7, label %bb8
bb7:
  store i1 false, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/lower:lowering", ptr %t54, i32 0, i32 0
  %t57 = load ptr, ptr %t56, !tbaa !29
  store ptr %t57, ptr %l24, !tbaa !29
  %t58 = load ptr, ptr %l24, !tbaa !29
  %t59 = call ptr @__olang_scope_or(ptr %v2, ptr %t58)
  %t60 = call ptr @__olang_scope_hold(ptr %t59)
  %t61 = ptrtoint ptr %t60 to i64
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/lower:lowering", ptr %t62, i32 0, i32 0
  %t65 = load ptr, ptr %t64, !tbaa !29
  %t67 = call ptr @__olang_scope_or(ptr %v2, ptr %t65)
  %t68 = call ptr @__olang_scope_hold(ptr %t67)
  %t69 = ptrtoint ptr %t68 to i64
  %t71 = inttoptr i64 %t61 to ptr
  %t73 = inttoptr i64 %t69 to ptr
  %t74 = load ptr, ptr %l24, !tbaa !29
  %t75 = call ptr @compiler_2flower_2ecompiler_2flower_3aLowerer_2eGen(ptr %t71, ptr %t73, ptr %t74)
  store ptr %t75, ptr %l29
  br label %bb10
bb10:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"compiler/lower:lowering", ptr %t76, i32 0, i32 2
  %t79 = load ptr, ptr %t78, !tbaa !29
  store ptr %t79, ptr %l31, !tbaa !29
  %t80 = load i32, ptr %l1, !tbaa !23
  %t81 = load ptr, ptr %l29, !tbaa !29
  %t82 = call ptr @__olang_scope_or(ptr %v2, ptr %t81)
  %t83 = call ptr @__olang_scope_hold(ptr %t82)
  %t84 = ptrtoint ptr %t83 to i64
  %t85 = load ptr, ptr %l31, !tbaa !29
  %t86 = call ptr @__olang_scope_or(ptr %v1, ptr %t85)
  %t87 = call ptr @__olang_scope_hold(ptr %t86)
  %t88 = ptrtoint ptr %t87 to i64
  %t90 = inttoptr i64 %t84 to ptr
  %t92 = inttoptr i64 %t88 to ptr
  %t93 = load ptr, ptr %l29, !tbaa !29
  %t94 = load ptr, ptr %l31, !tbaa !29
  %t96 = call i1 @compiler_2fmir_2ecompiler_2fmir_3aGenInfo_2eHoldsGen(ptr %t90, ptr %t92, ptr %t93, ptr %t94, i32 %t80)
  store i1 %t96, ptr %l35
  br label %bb11
bb11:
  %t97 = load i1, ptr %l35, !tbaa !21
  store i1 %t97, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2ederef(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %v6, ptr %a0, ptr %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca { i64, [4 x i64] }
  %l8 = alloca { i64, [4 x i64] }
  %l12 = alloca %"compiler/lower:pl"
  %l13 = alloca ptr
  %l14 = alloca { i64, [4 x i64] }
  %l16 = alloca i32
  %l18 = alloca i32
  %l19 = alloca ptr
  %l22 = alloca %"compiler/lower:pl"
  %l24 = alloca %"compiler/lower:pl"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/lower:pl"
  %t13 = alloca { i64, [2 x i64] }, align 8
  %t33 = alloca { i64, [2 x i64] }, align 8
  %t41 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t6 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v1, ptr %v3, ptr %v4, ptr %v5, ptr %v6, ptr %t1, ptr %t2)
  store { i64, [4 x i64] } %t6, ptr %l8
  br label %bb1
bb1:
  %t7 = load { i64, [4 x i64] }, ptr %l8
  store { i64, [4 x i64] } %t7, ptr %l3
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/lower:lowering", ptr %t8, i32 0, i32 12
  %t11 = load i1, ptr %t10, !tbaa !21
  br i1 %t11, label %bb2, label %bb3
bb2:
  store { i64, [2 x i64] } zeroinitializer, ptr %t13
  %t14 = getelementptr { i64, [2 x i64] }, ptr %t13, i32 0, i32 0
  store i64 0, ptr %t14
  %t15 = load { i64, [2 x i64] }, ptr %t13
  %t17 = call %"compiler/lower:pl" @compiler_2flower_3apl_2ector(ptr %v2, { i64, [2 x i64] } %t15)
  store %"compiler/lower:pl" %t17, ptr %l12
  br label %bb4
bb3:
  br label %bb5
bb4:
  call void @__olang_scope_close(ptr %s0)
  %t18 = load %"compiler/lower:pl", ptr %l12
  store %"compiler/lower:pl" %t18, ptr %rv
  br label %ret
bb5:
  %t19 = load ptr, ptr %l0, !tbaa !29
  store ptr %t19, ptr %l13, !tbaa !29
  %t20 = load { i64, [4 x i64] }, ptr %l3
  store { i64, [4 x i64] } %t20, ptr %l14
  %t21 = load ptr, ptr %l1, !tbaa !29
  %t23 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t21)
  store i32 %t23, ptr %l16
  br label %bb6
bb6:
  %t25 = load ptr, ptr %l13, !tbaa !29
  %t26 = load { i64, [4 x i64] }, ptr %l14
  %t27 = load i32, ptr %l16, !tbaa !23
  %t29 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2elocal(ptr %v0, ptr %v4, ptr %v3, ptr %t25, { i64, [4 x i64] } %t26, i32 %t27, %"compiler/source:Span" %a2)
  store i32 %t29, ptr %l18
  br label %bb7
bb7:
  %t30 = load i32, ptr %l18, !tbaa !23
  %t31 = load ptr, ptr %l0, !tbaa !29
  store ptr %t31, ptr %l19, !tbaa !29
  store { i64, [2 x i64] } zeroinitializer, ptr %t33
  %t34 = getelementptr { i64, [2 x i64] }, ptr %t33, i32 0, i32 0
  store i64 1, ptr %t34
  %t36 = insertvalue { i32 } undef, i32 %t30, 0
  %t37 = getelementptr { i64, [2 x i64] }, ptr %t33, i32 0, i32 1
  store { i32 } %t36, ptr %t37
  %t38 = load { i64, [2 x i64] }, ptr %t33
  %t40 = call %"compiler/lower:pl" @compiler_2flower_3apl_2ector(ptr %s0, { i64, [2 x i64] } %t38)
  store %"compiler/lower:pl" %t40, ptr %l22
  br label %bb8
bb8:
  store { i64, [1 x i64] } zeroinitializer, ptr %t41
  %t42 = getelementptr { i64, [1 x i64] }, ptr %t41, i32 0, i32 0
  store i64 3, ptr %t42
  %t43 = load { i64, [1 x i64] }, ptr %t41
  %t44 = load ptr, ptr %l19, !tbaa !29
  %t45 = load %"compiler/lower:pl", ptr %l22
  %t47 = call %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2ewith(ptr %v0, ptr %s0, ptr %v2, ptr %t44, %"compiler/lower:pl" %t45, { i64, [1 x i64] } %t43)
  store %"compiler/lower:pl" %t47, ptr %l24
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s0)
  %t48 = load %"compiler/lower:pl", ptr %l24
  store %"compiler/lower:pl" %t48, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/lower:pl", ptr %rv
  ret %"compiler/lower:pl" %rr
}

define dso_local { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ederivedRef(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, [2 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [2 x i64] }
  %l2 = alloca i64
  %l3 = alloca { i64, [1 x i64] }
  %l9 = alloca ptr
  %l11 = alloca i64
  %l25 = alloca { i64, [1 x i64] }
  %l27 = alloca { i64, [1 x i64] }
  %rv = alloca { i64, [1 x i64] }
  %t28 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  store { i64, [2 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [2 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [2 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 8
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { i64, i64 }, ptr %t6, i32 0, i32 0
  %t8 = load i64, ptr %t7
  store i64 %t8, ptr %l2, !tbaa !24
  br label %bb3
bb2:
  br label %bb5
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/lower:lowering", ptr %t10, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t15 = getelementptr %"compiler/typed:Body", ptr %t13, i32 0, i32 6
  store ptr %t15, ptr %l9, !tbaa !29
  %t16 = load ptr, ptr %l9, !tbaa !29
  %t17 = call ptr @__olang_scope_or(ptr %v1, ptr %t16)
  %t18 = call ptr @__olang_scope_hold(ptr %t17)
  %t19 = ptrtoint ptr %t18 to i64
  %t21 = inttoptr i64 %t19 to ptr
  %t22 = load ptr, ptr %l9, !tbaa !29
  %t23 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScopeVar_3e_2eLen_3ccompiler_2ftyped_3aScopeVar_3e(ptr %t21, ptr %t22)
  store i64 %t23, ptr %l11
  br label %bb4
bb4:
  %t24 = load i64, ptr %l2, !tbaa !24
  %t25 = load i64, ptr %l11, !tbaa !24
  %t27 = add i64 %t25, %t24
  store { i64, [1 x i64] } zeroinitializer, ptr %t28
  %t29 = getelementptr { i64, [1 x i64] }, ptr %t28, i32 0, i32 0
  store i64 1, ptr %t29
  %t31 = insertvalue { i64 } undef, i64 %t27, 0
  %t32 = getelementptr { i64, [1 x i64] }, ptr %t28, i32 0, i32 1
  store { i64 } %t31, ptr %t32
  %t33 = load { i64, [1 x i64] }, ptr %t28
  store { i64, [1 x i64] } %t33, ptr %l3
  br label %bb22
bb5:
  %t35 = load { i64, [2 x i64] }, ptr %l1
  %t37 = extractvalue { i64, [2 x i64] } %t35, 0
  %t38 = icmp eq i64 %t37, 1
  br i1 %t38, label %bb6, label %bb7
bb6:
  br label %bb14
bb7:
  %t40 = load { i64, [2 x i64] }, ptr %l1
  %t42 = extractvalue { i64, [2 x i64] } %t40, 0
  %t43 = icmp eq i64 %t42, 2
  br i1 %t43, label %bb8, label %bb9
bb8:
  br label %bb14
bb9:
  %t45 = load { i64, [2 x i64] }, ptr %l1
  %t47 = extractvalue { i64, [2 x i64] } %t45, 0
  %t48 = icmp eq i64 %t47, 3
  br i1 %t48, label %bb10, label %bb11
bb10:
  br label %bb14
bb11:
  %t50 = load { i64, [2 x i64] }, ptr %l1
  %t52 = extractvalue { i64, [2 x i64] } %t50, 0
  %t53 = icmp eq i64 %t52, 7
  br i1 %t53, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb16
bb14:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t56 = load { i64, [2 x i64] }, ptr %l1
  %t59 = call { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2escopeRef(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %t55, { i64, [2 x i64] } %t56)
  store { i64, [1 x i64] } %t59, ptr %l25
  br label %bb15
bb15:
  %t60 = load { i64, [1 x i64] }, ptr %l25
  store { i64, [1 x i64] } %t60, ptr %l3
  br label %bb22
bb16:
  br i1 true, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb21
bb19:
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = call { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2enullScope(ptr %v0, ptr %v3, ptr %v4, ptr %t61)
  store { i64, [1 x i64] } %t63, ptr %l27
  br label %bb20
bb20:
  %t64 = load { i64, [1 x i64] }, ptr %l27
  store { i64, [1 x i64] } %t64, ptr %l3
  br label %bb22
bb21:
  call void @__olang_check_failed(ptr @olang_loc_3a66230741c412ef_cf9b39cad1abd5db)
  unreachable
bb22:
  %t65 = load { i64, [1 x i64] }, ptr %l3
  store { i64, [1 x i64] } %t65, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [1 x i64] }, ptr %rv
  ret { i64, [1 x i64] } %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2eelemRelease(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, %"compiler/lower:pl" %a1, i32 %a2, ptr %a3, %"compiler/source:Span" %a4, i1 %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/lower:pl"
  %l2 = alloca i32
  %l4 = alloca %"compiler/source:Span"
  %l8 = alloca i1
  %l15 = alloca ptr
  %l18 = alloca i1
  %l19 = alloca ptr
  %l20 = alloca i32
  %l21 = alloca %"compiler/lower:pl"
  %l23 = alloca %"compiler/lower:pl"
  %l24 = alloca i32
  %l29 = alloca ptr
  %l30 = alloca %"compiler/lower:pl"
  %l32 = alloca %"compiler/lower:pl"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store %"compiler/lower:pl" %a1, ptr %l1
  store i32 %a2, ptr %l2
  store %"compiler/source:Span" %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = xor i1 %a5, true
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/lower:lowering", ptr %t5, i32 0, i32 0
  %t8 = load ptr, ptr %t7, !tbaa !29
  %t10 = getelementptr %"compiler/lower:Lowerer", ptr %t8, i32 0, i32 12
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t13 = icmp eq ptr %t11, null
  br i1 %t13, label %bb3, label %bb4
bb2:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb7
bb3:
  call void @__olang_check_failed(ptr @olang_loc_9340bfd168f92e90_dfeb1d6426189a2c)
  unreachable
bb4:
  br label %bb5
bb5:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/lower:lowering", ptr %t15, i32 0, i32 0
  %t18 = load ptr, ptr %t17, !tbaa !29
  %t20 = getelementptr %"compiler/lower:Lowerer", ptr %t18, i32 0, i32 12
  %t21 = load ptr, ptr %t20, !tbaa !29
  store ptr %t21, ptr %l15, !tbaa !29
  %t22 = load i32, ptr %l2, !tbaa !23
  %t23 = load ptr, ptr %l15, !tbaa !29
  %t24 = call ptr @__olang_scope_or(ptr %v3, ptr %t23)
  %t25 = call ptr @__olang_scope_hold(ptr %t24)
  %t26 = ptrtoint ptr %t25 to i64
  %t28 = inttoptr i64 %t26 to ptr
  %t29 = load ptr, ptr %l15, !tbaa !29
  %t31 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eSelfHolding(ptr %t28, ptr %t29, i32 %t22)
  store i1 %t31, ptr %l18
  br label %bb6
bb6:
  %t32 = load i1, ptr %l18, !tbaa !21
  store i1 %t32, ptr %l8, !tbaa !21
  br label %bb7
bb7:
  %t33 = load i1, ptr %l8, !tbaa !21
  br i1 %t33, label %bb8, label %bb9
bb8:
  store %olang.scope zeroinitializer, ptr %s1
  %t34 = load ptr, ptr %l0, !tbaa !29
  store ptr %t34, ptr %l19, !tbaa !29
  store i32 9, ptr %l20
  %t35 = load %"compiler/lower:pl", ptr %l1
  store %"compiler/lower:pl" %t35, ptr %l21
  %t37 = call %"compiler/lower:pl" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2flower_3apl(ptr %s1, ptr %l21)
  store %"compiler/lower:pl" %t37, ptr %l23
  br label %bb10
bb9:
  br label %bb16
bb10:
  %t38 = load i32, ptr %l2, !tbaa !23
  store i32 %t38, ptr %l24, !tbaa !23
  %t39 = icmp sge i64 0, 0
  br i1 %t39, label %bb11, label %bb12
bb11:
  %t41 = icmp sle i64 0, 576460752303423487
  br i1 %t41, label %bb13, label %bb14
bb12:
  call void @__olang_check_failed(ptr @olang_loc_6150b85b9eb427f5_1eae8daae523ab39)
  unreachable
bb13:
  %t43 = mul i64 0, 16
  %t44 = insertvalue { i64, ptr } undef, i64 0, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t46 = load %"compiler/source:Span", ptr %l4
  %t47 = load ptr, ptr %l19, !tbaa !29
  %t48 = load i32, ptr %l20, !range !{i32 0, i32 10}
  %t49 = load %"compiler/lower:pl", ptr %l23
  %t50 = load i32, ptr %l24, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eselfHelper(ptr %v0, ptr %s1, ptr %s1, ptr %v4, ptr %v3, ptr %t47, i32 %t48, %"compiler/lower:pl" %t49, i32 %t50, { i64, ptr } %t45, %"compiler/source:Span" %t46)
  br label %bb15
bb14:
  call void @__olang_check_failed(ptr @olang_loc_6150b85b9eb427f5_1eae8daae523ab39)
  unreachable
bb15:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb16:
  %t53 = load ptr, ptr %l0, !tbaa !29
  store ptr %t53, ptr %l29, !tbaa !29
  %t54 = load %"compiler/lower:pl", ptr %l1
  store %"compiler/lower:pl" %t54, ptr %l30
  %t56 = call %"compiler/lower:pl" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2flower_3apl(ptr %s0, ptr %l30)
  store %"compiler/lower:pl" %t56, ptr %l32
  br label %bb17
bb17:
  %t58 = load %"compiler/source:Span", ptr %l4
  %t59 = load ptr, ptr %l29, !tbaa !29
  %t60 = load %"compiler/lower:pl", ptr %l32
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2ereleaseOn(ptr %v0, ptr %s0, ptr %v2, ptr %v4, ptr %v3, ptr %t59, %"compiler/lower:pl" %t60, ptr %a3, %"compiler/source:Span" %t58)
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eencloses(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l13 = alloca ptr
  %l15 = alloca i64
  %l20 = alloca i64
  %l23 = alloca i64
  %l48 = alloca i1
  %l50 = alloca i64
  %l53 = alloca ptr
  %l55 = alloca i64
  %l60 = alloca ptr
  %l64 = alloca %"compiler/typed:BlockInfo"
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i32 %a2, ptr %l3, !tbaa !23
  store i64 0, ptr %l4, !tbaa !24
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/lower:lowering", ptr %t3, i32 0, i32 1
  %t6 = load ptr, ptr %t5, !tbaa !29
  %t8 = getelementptr %"compiler/typed:Body", ptr %t6, i32 0, i32 8
  store ptr %t8, ptr %l13, !tbaa !29
  %t9 = load ptr, ptr %l13, !tbaa !29
  %t10 = call ptr @__olang_scope_or(ptr %v1, ptr %t9)
  %t11 = call ptr @__olang_scope_hold(ptr %t10)
  %t12 = ptrtoint ptr %t11 to i64
  %t14 = inttoptr i64 %t12 to ptr
  %t15 = load ptr, ptr %l13, !tbaa !29
  %t16 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockInfo_3e_2eLen__Hdc799a0fe091f8e84d50200d058b631d(ptr %t14, ptr %t15)
  store i64 %t16, ptr %l15
  br label %bb1
bb1:
  %t17 = load i64, ptr %l15, !tbaa !24
  %t18 = add i64 %t17, 1
  store i64 %t18, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t20 = load i64, ptr %l5, !tbaa !24
  %t21 = load i64, ptr %l4, !tbaa !24
  %t24 = icmp sgt i64 %t20, %t21
  br i1 %t24, label %bb2, label %bb3
bb2:
  %t26 = load i64, ptr %l6, !tbaa !24
  %t28 = icmp sgt i64 %t26, 0
  br i1 %t28, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l20, !tbaa !24
  br label %bb7
bb4:
  %t30 = load i64, ptr %l5, !tbaa !24
  %t31 = load i64, ptr %l4, !tbaa !24
  %t34 = sub i64 %t30, %t31
  %t35 = load i64, ptr %l6, !tbaa !24
  %t38 = add i64 %t34, %t35
  %t40 = sub i64 %t38, 1
  %t41 = load i64, ptr %l6, !tbaa !24
  %t44 = sdiv i64 %t40, %t41
  store i64 %t44, ptr %l23, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l23, !tbaa !24
  br label %bb6
bb6:
  %t46 = load i64, ptr %l23, !tbaa !24
  store i64 %t46, ptr %l20, !tbaa !24
  br label %bb7
bb7:
  %t47 = load i64, ptr %l20, !tbaa !24
  store i64 %t47, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb8
bb8:
  %t48 = load i64, ptr %l8, !tbaa !24
  %t49 = load i64, ptr %l7, !tbaa !24
  %t52 = icmp slt i64 %t48, %t49
  %t54 = xor i1 %t52, true
  br i1 %t54, label %bb9, label %bb10
bb9:
  br label %bb24
bb10:
  br label %bb11
bb11:
  %t56 = load i64, ptr %l4, !tbaa !24
  %t57 = load i64, ptr %l8, !tbaa !24
  %t58 = load i64, ptr %l6, !tbaa !24
  %t61 = mul i64 %t57, %t58
  %t64 = add i64 %t56, %t61
  store i64 %t64, ptr %l9, !tbaa !24
  %t66 = load i32, ptr %l3, !tbaa !23
  %t70 = icmp eq i32 %t66, %a1
  br i1 %t70, label %bb12, label %bb13
bb12:
  store i1 true, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  %t73 = load i32, ptr %l3, !tbaa !23
  %t75 = sext i32 %t73 to i64
  %t77 = icmp slt i64 %t75, 0
  br i1 %t77, label %bb15, label %bb16
bb15:
  store i1 true, ptr %l48, !tbaa !21
  br label %bb18
bb16:
  %t79 = load i32, ptr %l3, !tbaa !23
  %t81 = sext i32 %t79 to i64
  store i64 %t81, ptr %l50, !tbaa !24
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/lower:lowering", ptr %t82, i32 0, i32 1
  %t85 = load ptr, ptr %t84, !tbaa !29
  %t87 = getelementptr %"compiler/typed:Body", ptr %t85, i32 0, i32 8
  store ptr %t87, ptr %l53, !tbaa !29
  %t88 = load ptr, ptr %l53, !tbaa !29
  %t89 = call ptr @__olang_scope_or(ptr %v1, ptr %t88)
  %t90 = call ptr @__olang_scope_hold(ptr %t89)
  %t91 = ptrtoint ptr %t90 to i64
  %t93 = inttoptr i64 %t91 to ptr
  %t94 = load ptr, ptr %l53, !tbaa !29
  %t95 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockInfo_3e_2eLen__Hdc799a0fe091f8e84d50200d058b631d(ptr %t93, ptr %t94)
  store i64 %t95, ptr %l55
  br label %bb17
bb17:
  %t96 = load i64, ptr %l50, !tbaa !24
  %t97 = load i64, ptr %l55, !tbaa !24
  %t98 = icmp sge i64 %t96, %t97
  store i1 %t98, ptr %l48, !tbaa !21
  br label %bb18
bb18:
  %t100 = load i1, ptr %l48, !tbaa !21
  br i1 %t100, label %bb19, label %bb20
bb19:
  store i1 false, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = getelementptr %"compiler/lower:lowering", ptr %t102, i32 0, i32 1
  %t105 = load ptr, ptr %t104, !tbaa !29
  %t107 = getelementptr %"compiler/typed:Body", ptr %t105, i32 0, i32 8
  store ptr %t107, ptr %l60, !tbaa !29
  %t108 = load i32, ptr %l3, !tbaa !23
  %t110 = sext i32 %t108 to i64
  %t111 = load ptr, ptr %l60, !tbaa !29
  %t112 = call ptr @__olang_scope_or(ptr %v1, ptr %t111)
  %t113 = call ptr @__olang_scope_hold(ptr %t112)
  %t114 = ptrtoint ptr %t113 to i64
  %t116 = inttoptr i64 %t114 to ptr
  %t117 = load ptr, ptr %l60, !tbaa !29
  %t119 = call %"compiler/typed:BlockInfo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockInfo_3e_2eAt_3ccompiler_2ftyped_3aBlockInfo_3e(ptr %t116, ptr %t117, i64 %t110)
  store %"compiler/typed:BlockInfo" %t119, ptr %l64
  br label %bb22
bb22:
  %t120 = getelementptr %"compiler/typed:BlockInfo", ptr %l64, i32 0, i32 0
  %t121 = load i32, ptr %t120, !tbaa !23
  store i32 %t121, ptr %l3, !tbaa !23
  br label %bb23
bb23:
  %t123 = load i64, ptr %l8, !tbaa !24
  %t126 = add i64 %t123, 1
  store i64 %t126, ptr %l8, !tbaa !24
  br label %bb8
bb24:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2eendMoved(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca %"compiler/typed:Local"
  %l6 = alloca i64
  %l10 = alloca i1
  %l19 = alloca ptr
  %l28 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l30 = alloca i64
  %l32 = alloca i64
  %l37 = alloca i64
  %l40 = alloca i1
  %l43 = alloca ptr
  %l46 = alloca %"compiler/typed:Local"
  %l53 = alloca ptr
  %l60 = alloca i64
  %l61 = alloca ptr
  %l64 = alloca i32
  %l67 = alloca ptr
  %l70 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l74 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 39
  %t4 = load i1, ptr %t3, !tbaa !21
  %t6 = xor i1 %t4, true
  br i1 %t6, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l10, !tbaa !21
  br label %bb3
bb2:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/lower:lowering", ptr %t8, i32 0, i32 12
  %t11 = load i1, ptr %t10, !tbaa !21
  store i1 %t11, ptr %l10, !tbaa !21
  br label %bb3
bb3:
  %t13 = load i1, ptr %l10, !tbaa !21
  br i1 %t13, label %bb4, label %bb5
bb4:
  br label %ret
bb5:
  br label %bb6
bb6:
  store %olang.scope zeroinitializer, ptr %s2
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/lower:lowering", ptr %t14, i32 0, i32 0
  %t17 = load ptr, ptr %t16, !tbaa !29
  %t19 = getelementptr %"compiler/lower:Lowerer", ptr %t17, i32 0, i32 12
  %t20 = load ptr, ptr %t19, !tbaa !29
  %t22 = icmp eq ptr %t20, null
  br i1 %t22, label %bb7, label %bb8
bb7:
  call void @__olang_check_failed(ptr @olang_loc_57a53f0c70226722_53d3c67d5b30d4c6)
  unreachable
bb8:
  br label %bb9
bb9:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/lower:lowering", ptr %t24, i32 0, i32 0
  %t27 = load ptr, ptr %t26, !tbaa !29
  %t29 = getelementptr %"compiler/lower:Lowerer", ptr %t27, i32 0, i32 12
  %t30 = load ptr, ptr %t29, !tbaa !29
  store ptr %t30, ptr %l19, !tbaa !29
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/lower:lowering", ptr %t31, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !29
  %t36 = getelementptr %"compiler/typed:Body", ptr %t34, i32 0, i32 0
  %t37 = load i32, ptr %t36, !tbaa !23
  %t39 = sext i32 %t37 to i64
  %t42 = getelementptr %"compiler/typed:Block", ptr %a1, i32 0, i32 0
  %t43 = load i32, ptr %t42, !tbaa !23
  %t45 = sext i32 %t43 to i64
  %t46 = load ptr, ptr %l19, !tbaa !29
  %t47 = call ptr @__olang_scope_or(ptr %v2, ptr %t46)
  %t48 = call ptr @__olang_scope_hold(ptr %t47)
  %t49 = ptrtoint ptr %t48 to i64
  %t51 = inttoptr i64 %t49 to ptr
  %t52 = load ptr, ptr %l19, !tbaa !29
  %t55 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3aFree_2eEndsMoved(ptr %t51, ptr %s2, ptr %t52, i64 %t39, i64 %t45, i1 true)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t55, ptr %l28
  br label %bb10
bb10:
  %t56 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l28
  %t57 = call ptr @__olang_scope_alloc_a(ptr %s2, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t56, ptr %t57
  store ptr %t57, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb11
bb11:
  store %olang.scope zeroinitializer, ptr %s3
  %t59 = load i64, ptr %l3, !tbaa !24
  store i64 %t59, ptr %l30, !tbaa !24
  %t60 = load ptr, ptr %l2, !tbaa !29
  %t62 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s2, ptr %t60)
  store i64 %t62, ptr %l32
  br label %bb12
bb12:
  %t63 = load i64, ptr %l30, !tbaa !24
  %t64 = load i64, ptr %l32, !tbaa !24
  %t65 = icmp slt i64 %t63, %t64
  %t67 = xor i1 %t65, true
  br i1 %t67, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s3)
  br label %bb33
bb14:
  br label %bb15
bb15:
  %t69 = load ptr, ptr %l2, !tbaa !29
  %t70 = load i64, ptr %l3, !tbaa !24
  %t73 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s2, ptr %t69, i64 %t70)
  store i64 %t73, ptr %l37
  br label %bb16
bb16:
  %t74 = load i64, ptr %l37, !tbaa !24
  store i64 %t74, ptr %l4, !tbaa !24
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t76 = load i64, ptr %l4, !tbaa !24
  %t79 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2emovedAway(ptr %v0, ptr %t75, i64 %t76)
  store i1 %t79, ptr %l40
  br label %bb17
bb17:
  %t80 = load i1, ptr %l40, !tbaa !21
  br i1 %t80, label %bb18, label %bb19
bb18:
  call void @__olang_scope_close(ptr %s3)
  br label %bb32
bb19:
  br label %bb20
bb20:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"compiler/lower:lowering", ptr %t81, i32 0, i32 1
  %t84 = load ptr, ptr %t83, !tbaa !29
  %t86 = getelementptr %"compiler/typed:Body", ptr %t84, i32 0, i32 7
  store ptr %t86, ptr %l43, !tbaa !29
  %t87 = load i64, ptr %l4, !tbaa !24
  %t88 = load ptr, ptr %l43, !tbaa !29
  %t89 = call ptr @__olang_scope_or(ptr %v3, ptr %t88)
  %t90 = call ptr @__olang_scope_hold(ptr %t89)
  %t91 = ptrtoint ptr %t90 to i64
  %t93 = inttoptr i64 %t91 to ptr
  %t94 = load ptr, ptr %l43, !tbaa !29
  %t96 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %t93, ptr %t94, i64 %t87)
  store %"compiler/typed:Local" %t96, ptr %l46
  br label %bb21
bb21:
  %t97 = load %"compiler/typed:Local", ptr %l46
  store %"compiler/typed:Local" %t97, ptr %l5
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t100 = getelementptr %"compiler/lower:lowering", ptr %t98, i32 0, i32 0
  %t101 = load ptr, ptr %t100, !tbaa !29
  %t103 = getelementptr %"compiler/lower:Lowerer", ptr %t101, i32 0, i32 12
  %t104 = load ptr, ptr %t103, !tbaa !29
  %t106 = icmp eq ptr %t104, null
  br i1 %t106, label %bb22, label %bb23
bb22:
  call void @__olang_check_failed(ptr @olang_loc_9e09bad51f2e7189_a86eb6e03c65edad)
  unreachable
bb23:
  br label %bb24
bb24:
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = getelementptr %"compiler/lower:lowering", ptr %t108, i32 0, i32 0
  %t111 = load ptr, ptr %t110, !tbaa !29
  %t113 = getelementptr %"compiler/lower:Lowerer", ptr %t111, i32 0, i32 12
  %t114 = load ptr, ptr %t113, !tbaa !29
  store ptr %t114, ptr %l53, !tbaa !29
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t117 = getelementptr %"compiler/lower:lowering", ptr %t115, i32 0, i32 1
  %t118 = load ptr, ptr %t117, !tbaa !29
  %t120 = getelementptr %"compiler/typed:Body", ptr %t118, i32 0, i32 0
  %t121 = load i32, ptr %t120, !tbaa !23
  %t123 = sext i32 %t121 to i64
  %t124 = load i64, ptr %l4, !tbaa !24
  %t125 = load ptr, ptr %l53, !tbaa !29
  %t126 = call ptr @__olang_scope_or(ptr %v2, ptr %t125)
  %t127 = call ptr @__olang_scope_hold(ptr %t126)
  %t128 = ptrtoint ptr %t127 to i64
  %t130 = inttoptr i64 %t128 to ptr
  %t131 = load ptr, ptr %l53, !tbaa !29
  %t134 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eEndPlace(ptr %t130, ptr %t131, i64 %t123, i64 %t124)
  store i64 %t134, ptr %l60
  br label %bb25
bb25:
  %t135 = load i64, ptr %l60, !tbaa !24
  store i64 %t135, ptr %l6, !tbaa !24
  %t136 = load ptr, ptr %l0, !tbaa !29
  store ptr %t136, ptr %l61, !tbaa !29
  %t137 = load i64, ptr %l4, !tbaa !24
  %t139 = trunc i64 %t137 to i32
  store i32 %t139, ptr %l64, !tbaa !23
  %t141 = load i64, ptr %l6, !tbaa !24
  %t143 = icmp sge i64 %t141, 0
  br i1 %t143, label %bb26, label %bb27
bb26:
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t146 = load i64, ptr %l6, !tbaa !24
  %t149 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2flower_2ecompiler_2flower_3alowering_2emovedPath(ptr %v0, ptr %s3, ptr %v2, ptr %t145, i64 %t146)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t149, ptr %l70
  br label %bb28
bb27:
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t151 = getelementptr %"compiler/typed:Local", ptr %l5, i32 0, i32 2
  %t152 = load i32, ptr %t151, !tbaa !23
  %t155 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2flower_2ecompiler_2flower_3alowering_2eleafPaths(ptr %v0, ptr %s3, ptr %v2, ptr %v4, ptr %t150, i32 %t152)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t155, ptr %l74
  br label %bb29
bb28:
  %t156 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l70
  %t157 = call ptr @__olang_scope_alloc_a(ptr %s3, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t156, ptr %t157
  store ptr %t157, ptr %l67, !tbaa !29
  br label %bb30
bb29:
  %t159 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l74
  %t160 = call ptr @__olang_scope_alloc_a(ptr %s3, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t159, ptr %t160
  store ptr %t160, ptr %l67, !tbaa !29
  br label %bb30
bb30:
  %t162 = getelementptr %"compiler/typed:Local", ptr %l5, i32 0, i32 1
  %t163 = load %"compiler/source:Span", ptr %t162
  %t164 = load ptr, ptr %l61, !tbaa !29
  %t165 = load i32, ptr %l64, !tbaa !23
  %t166 = load ptr, ptr %l67, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2ereleaseAt(ptr %v0, ptr %s3, ptr %v4, ptr %v2, ptr %t164, i32 %t165, ptr %t166, %"compiler/source:Span" %t163)
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s3)
  br label %bb32
bb32:
  %t168 = load i64, ptr %l3, !tbaa !24
  %t171 = add i64 %t168, 1
  store i64 %t171, ptr %l3, !tbaa !24
  br label %bb11
bb33:
  call void @__olang_scope_close(ptr %s2)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2eepilogue(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, [4 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %t12 = alloca { i64, [8 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eleave(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %t1, i64 0)
  br label %bb1
bb1:
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t6 = getelementptr %"compiler/lower:lowering", ptr %t4, i32 0, i32 1
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/typed:Body", ptr %t7, i32 0, i32 4
  %t10 = load %"compiler/source:Span", ptr %t9
  store { i64, [8 x i64] } zeroinitializer, ptr %t12
  %t13 = getelementptr { i64, [8 x i64] }, ptr %t12, i32 0, i32 0
  store i64 5, ptr %t13
  %t15 = insertvalue { %"compiler/source:Span", { i64, [4 x i64] } } undef, %"compiler/source:Span" %t10, 0
  %t17 = insertvalue { %"compiler/source:Span", { i64, [4 x i64] } } %t15, { i64, [4 x i64] } %a1, 1
  %t18 = getelementptr { i64, [8 x i64] }, ptr %t12, i32 0, i32 1
  store { %"compiler/source:Span", { i64, [4 x i64] } } %t17, ptr %t18
  %t19 = load { i64, [8 x i64] }, ptr %t12
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %v3, ptr %v2, ptr %t3, { i64, [8 x i64] } %t19)
  br label %bb2
bb2:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eescapes(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l12 = alloca i1
  %l16 = alloca i64
  %l20 = alloca i64
  %l23 = alloca i64
  %l44 = alloca i64
  %l47 = alloca i1
  %l49 = alloca ptr
  %l53 = alloca i64
  %l57 = alloca i64
  %l59 = alloca i1
  %rv = alloca i1
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/typed:LocalUses", ptr %t1, i32 0, i32 8
  %t4 = load i64, ptr %l2, !tbaa !24
  %t7 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v1, ptr %t3, i64 %t4)
  store i1 %t7, ptr %l12
  br label %bb1
bb1:
  %t8 = load i1, ptr %l12, !tbaa !21
  br i1 %t8, label %bb2, label %bb3
bb2:
  store i1 true, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  store i64 0, ptr %l3, !tbaa !24
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr %"compiler/typed:LocalUses", ptr %t10, i32 0, i32 27
  %t14 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t12)
  store i64 %t14, ptr %l16
  br label %bb5
bb5:
  %t15 = load i64, ptr %l16, !tbaa !24
  store i64 %t15, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t16 = load i64, ptr %l4, !tbaa !24
  %t17 = load i64, ptr %l3, !tbaa !24
  %t20 = icmp sgt i64 %t16, %t17
  br i1 %t20, label %bb6, label %bb7
bb6:
  %t22 = load i64, ptr %l5, !tbaa !24
  %t24 = icmp sgt i64 %t22, 0
  br i1 %t24, label %bb8, label %bb9
bb7:
  store i64 0, ptr %l20, !tbaa !24
  br label %bb11
bb8:
  %t26 = load i64, ptr %l4, !tbaa !24
  %t27 = load i64, ptr %l3, !tbaa !24
  %t30 = sub i64 %t26, %t27
  %t31 = load i64, ptr %l5, !tbaa !24
  %t34 = add i64 %t30, %t31
  %t36 = sub i64 %t34, 1
  %t37 = load i64, ptr %l5, !tbaa !24
  %t40 = sdiv i64 %t36, %t37
  store i64 %t40, ptr %l23, !tbaa !24
  br label %bb10
bb9:
  store i64 0, ptr %l23, !tbaa !24
  br label %bb10
bb10:
  %t42 = load i64, ptr %l23, !tbaa !24
  store i64 %t42, ptr %l20, !tbaa !24
  br label %bb11
bb11:
  %t43 = load i64, ptr %l20, !tbaa !24
  store i64 %t43, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb12
bb12:
  %t44 = load i64, ptr %l7, !tbaa !24
  %t45 = load i64, ptr %l6, !tbaa !24
  %t48 = icmp slt i64 %t44, %t45
  %t50 = xor i1 %t48, true
  br i1 %t50, label %bb13, label %bb14
bb13:
  br label %bb27
bb14:
  br label %bb15
bb15:
  %t52 = load i64, ptr %l3, !tbaa !24
  %t53 = load i64, ptr %l7, !tbaa !24
  %t54 = load i64, ptr %l5, !tbaa !24
  %t57 = mul i64 %t53, %t54
  %t60 = add i64 %t52, %t57
  store i64 %t60, ptr %l8, !tbaa !24
  %t62 = load ptr, ptr %l1, !tbaa !29
  %t64 = getelementptr %"compiler/typed:LocalUses", ptr %t62, i32 0, i32 27
  %t65 = load i64, ptr %l8, !tbaa !24
  %t68 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t64, i64 %t65)
  store i64 %t68, ptr %l44
  br label %bb16
bb16:
  %t69 = load i64, ptr %l2, !tbaa !24
  %t70 = load i64, ptr %l44, !tbaa !24
  %t72 = icmp eq i64 %t70, %t69
  br i1 %t72, label %bb17, label %bb18
bb17:
  %t76 = getelementptr %"compiler/lower:lowering", ptr %a0, i32 0, i32 0
  %t77 = load ptr, ptr %t76, !tbaa !29
  store ptr %t77, ptr %l49, !tbaa !29
  %t78 = load ptr, ptr %l1, !tbaa !29
  %t80 = getelementptr %"compiler/typed:LocalUses", ptr %t78, i32 0, i32 28
  %t81 = load i64, ptr %l8, !tbaa !24
  %t84 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t80, i64 %t81)
  store i64 %t84, ptr %l53
  br label %bb19
bb18:
  store i1 false, ptr %l47, !tbaa !21
  br label %bb22
bb19:
  %t85 = load ptr, ptr %l1, !tbaa !29
  %t87 = getelementptr %"compiler/typed:LocalUses", ptr %t85, i32 0, i32 29
  %t88 = load i64, ptr %l8, !tbaa !24
  %t91 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t87, i64 %t88)
  store i64 %t91, ptr %l57
  br label %bb20
bb20:
  %t92 = load ptr, ptr %l49, !tbaa !29
  %t93 = call ptr @__olang_scope_or(ptr %v2, ptr %t92)
  %t94 = call ptr @__olang_scope_hold(ptr %t93)
  %t95 = ptrtoint ptr %t94 to i64
  %t97 = inttoptr i64 %t95 to ptr
  %t98 = load ptr, ptr %l49, !tbaa !29
  %t99 = load i64, ptr %l53, !tbaa !24
  %t100 = load i64, ptr %l57, !tbaa !24
  %t101 = call i1 @compiler_2flower_2ecompiler_2flower_3aLowerer_2ekeepsNoRef(ptr %t97, ptr %t98, i64 %t99, i64 %t100)
  store i1 %t101, ptr %l59
  br label %bb21
bb21:
  %t102 = load i1, ptr %l59, !tbaa !21
  %t103 = xor i1 %t102, true
  store i1 %t103, ptr %l47, !tbaa !21
  br label %bb22
bb22:
  %t105 = load i1, ptr %l47, !tbaa !21
  br i1 %t105, label %bb23, label %bb24
bb23:
  store i1 true, ptr %rv
  br label %ret
bb24:
  br label %bb25
bb25:
  br label %bb26
bb26:
  %t107 = load i64, ptr %l7, !tbaa !24
  %t110 = add i64 %t107, 1
  store i64 %t110, ptr %l7, !tbaa !24
  br label %bb12
bb27:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2efitAt(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3, { i64, [1 x i64] } %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca { i64, [1 x i64] }
  %l5 = alloca ptr
  %l6 = alloca { i64, [4 x i64] }
  %l7 = alloca { i64, [4 x i64] }
  %l11 = alloca i1
  %l13 = alloca ptr
  %l17 = alloca { i64, [4 x i64] }
  %l21 = alloca ptr
  %l22 = alloca { i64, [4 x i64] }
  %l24 = alloca i32
  %l25 = alloca i32
  %l26 = alloca %"compiler/source:Span"
  %l30 = alloca { i64, [1 x i64] }
  %l31 = alloca { i64, [4 x i64] }
  %l35 = alloca { i64, [4 x i64] }
  %l38 = alloca i1
  %l43 = alloca i1
  %l46 = alloca ptr
  %l47 = alloca { i64, [4 x i64] }
  %l49 = alloca i32
  %l53 = alloca { i64, [4 x i64] }
  %rv = alloca { i64, [4 x i64] }
  %t25 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  store %"compiler/source:Span" %a3, ptr %l3
  store { i64, [1 x i64] } %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t3 = load i32, ptr %l2, !tbaa !23
  %t7 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2ewidens(ptr %v0, ptr %v1, ptr %v2, ptr %t1, ptr %t2, i32 %t3)
  store i1 %t7, ptr %l11
  br label %bb1
bb1:
  %t8 = load i1, ptr %l11, !tbaa !21
  br i1 %t8, label %bb2, label %bb3
bb2:
  %t9 = load ptr, ptr %l1, !tbaa !29
  %t11 = call ptr @compiler_2flower_2econvertArg(ptr %v1, ptr %v1, ptr %t9)
  store ptr %t11, ptr %l13
  br label %bb4
bb3:
  br label %bb12
bb4:
  %t12 = load ptr, ptr %l13, !tbaa !29
  store ptr %t12, ptr %l5, !tbaa !29
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t14 = load ptr, ptr %l5, !tbaa !29
  %t18 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v1, ptr %v3, ptr %v2, ptr %v4, ptr %v5, ptr %t13, ptr %t14)
  store { i64, [4 x i64] } %t18, ptr %l17
  br label %bb5
bb5:
  %t19 = load { i64, [4 x i64] }, ptr %l17
  store { i64, [4 x i64] } %t19, ptr %l6
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/lower:lowering", ptr %t20, i32 0, i32 12
  %t23 = load i1, ptr %t22, !tbaa !21
  br i1 %t23, label %bb6, label %bb7
bb6:
  store { i64, [4 x i64] } zeroinitializer, ptr %t25
  %t26 = getelementptr { i64, [4 x i64] }, ptr %t25, i32 0, i32 0
  store i64 0, ptr %t26
  %t27 = load { i64, [4 x i64] }, ptr %t25
  store { i64, [4 x i64] } %t27, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t29 = load ptr, ptr %l0, !tbaa !29
  store ptr %t29, ptr %l21, !tbaa !29
  %t30 = load { i64, [4 x i64] }, ptr %l6
  store { i64, [4 x i64] } %t30, ptr %l22
  %t31 = load ptr, ptr %l5, !tbaa !29
  %t33 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t31)
  store i32 %t33, ptr %l24
  br label %bb9
bb9:
  %t34 = load i32, ptr %l2, !tbaa !23
  store i32 %t34, ptr %l25, !tbaa !23
  %t35 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t35, ptr %l26
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t37 = load ptr, ptr %l5, !tbaa !29
  %t38 = load { i64, [1 x i64] }, ptr %l4
  %t42 = call { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ewidenAt(ptr %v0, ptr %v1, ptr %v4, ptr %v5, ptr %v2, ptr %v3, ptr %t36, ptr %t37, { i64, [1 x i64] } %t38)
  store { i64, [1 x i64] } %t42, ptr %l30
  br label %bb10
bb10:
  %t43 = load ptr, ptr %l21, !tbaa !29
  %t44 = load { i64, [4 x i64] }, ptr %l22
  %t45 = load i32, ptr %l24, !tbaa !23
  %t46 = load i32, ptr %l25, !tbaa !23
  %t47 = load %"compiler/source:Span", ptr %l26
  %t48 = load { i64, [1 x i64] }, ptr %l30
  %t49 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ewiden(ptr %v0, ptr %v2, ptr %v3, ptr %t43, { i64, [4 x i64] } %t44, i32 %t45, i32 %t46, %"compiler/source:Span" %t47, { i64, [1 x i64] } %t48)
  store { i64, [4 x i64] } %t49, ptr %l31
  br label %bb11
bb11:
  %t50 = load { i64, [4 x i64] }, ptr %l31
  store { i64, [4 x i64] } %t50, ptr %rv
  br label %ret
bb12:
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t52 = load ptr, ptr %l1, !tbaa !29
  %t56 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v1, ptr %v3, ptr %v2, ptr %v4, ptr %v5, ptr %t51, ptr %t52)
  store { i64, [4 x i64] } %t56, ptr %l35
  br label %bb13
bb13:
  %t57 = load { i64, [4 x i64] }, ptr %l35
  store { i64, [4 x i64] } %t57, ptr %l7
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/lower:lowering", ptr %t58, i32 0, i32 12
  %t61 = load i1, ptr %t60, !tbaa !21
  br i1 %t61, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l38, !tbaa !21
  br label %bb17
bb15:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t64 = load ptr, ptr %l1, !tbaa !29
  %t66 = load i32, ptr %l2, !tbaa !23
  %t70 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2efits(ptr %v0, ptr %v1, ptr %v2, ptr %t63, ptr %t64, i32 %t66)
  store i1 %t70, ptr %l43
  br label %bb16
bb16:
  %t71 = load i1, ptr %l43, !tbaa !21
  %t72 = xor i1 %t71, true
  store i1 %t72, ptr %l38, !tbaa !21
  br label %bb17
bb17:
  %t74 = load i1, ptr %l38, !tbaa !21
  br i1 %t74, label %bb18, label %bb19
bb18:
  %t75 = load { i64, [4 x i64] }, ptr %l7
  store { i64, [4 x i64] } %t75, ptr %rv
  br label %ret
bb19:
  br label %bb20
bb20:
  %t77 = load ptr, ptr %l0, !tbaa !29
  store ptr %t77, ptr %l46, !tbaa !29
  %t78 = load { i64, [4 x i64] }, ptr %l7
  store { i64, [4 x i64] } %t78, ptr %l47
  %t79 = load ptr, ptr %l1, !tbaa !29
  %t81 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t79)
  store i32 %t81, ptr %l49
  br label %bb21
bb21:
  %t82 = load i32, ptr %l2, !tbaa !23
  %t83 = load %"compiler/source:Span", ptr %l3
  %t84 = load { i64, [1 x i64] }, ptr %l4
  %t85 = load ptr, ptr %l46, !tbaa !29
  %t86 = load { i64, [4 x i64] }, ptr %l47
  %t87 = load i32, ptr %l49, !tbaa !23
  %t91 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ewiden(ptr %v0, ptr %v2, ptr %v3, ptr %t85, { i64, [4 x i64] } %t86, i32 %t87, i32 %t82, %"compiler/source:Span" %t83, { i64, [1 x i64] } %t84)
  store { i64, [4 x i64] } %t91, ptr %l53
  br label %bb22
bb22:
  %t92 = load { i64, [4 x i64] }, ptr %l53
  store { i64, [4 x i64] } %t92, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3alowering_2efreshCall(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i32
  %l6 = alloca ptr
  %l12 = alloca i1
  %l13 = alloca ptr
  %l14 = alloca i1
  %l20 = alloca ptr
  %l24 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call ptr @compiler_2flower_2eviewCallIn(ptr %v1, ptr %v1, ptr %a1)
  store ptr %t3, ptr %l6
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l6, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t7 = icmp eq ptr %t5, null
  br i1 %t7, label %bb2, label %bb3
bb2:
  store i1 false, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t12 = getelementptr %"compiler/typed:Call", ptr %t10, i32 0, i32 0
  %t13 = load ptr, ptr %t12, !tbaa !29
  store ptr %t13, ptr %l3, !tbaa !29
  %t15 = load ptr, ptr %l3, !tbaa !29
  store ptr %t15, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t16 = load ptr, ptr %l13, !tbaa !29
  %t17 = icmp ne ptr %t16, null
  br i1 %t17, label %bb5, label %bb6
bb5:
  %t19 = load ptr, ptr %l13, !tbaa !29
  %t20 = load i64, ptr %t19, !range !{i64 0, i64 5}
  %t22 = icmp eq i64 %t20, 0
  store i1 %t22, ptr %l14, !tbaa !21
  br label %bb6
bb6:
  %t23 = load i1, ptr %l14, !tbaa !21
  br i1 %t23, label %bb7, label %bb8
bb7:
  %t24 = load ptr, ptr %l3, !tbaa !29
  %t26 = getelementptr { i64, [3 x i64] }, ptr %t24, i32 0, i32 1
  %t27 = getelementptr { i32 }, ptr %t26, i32 0, i32 0
  %t28 = load i32, ptr %t27
  store i32 %t28, ptr %l4, !tbaa !23
  br label %bb9
bb8:
  br label %bb11
bb9:
  %t32 = getelementptr %"compiler/lower:lowering", ptr %a0, i32 0, i32 0
  %t33 = load ptr, ptr %t32, !tbaa !29
  store ptr %t33, ptr %l20, !tbaa !29
  %t34 = load i32, ptr %l4, !tbaa !23
  %t36 = sext i32 %t34 to i64
  %t37 = load ptr, ptr %l20, !tbaa !29
  %t38 = call ptr @__olang_scope_or(ptr %v2, ptr %t37)
  %t39 = call ptr @__olang_scope_hold(ptr %t38)
  %t40 = ptrtoint ptr %t39 to i64
  %t42 = inttoptr i64 %t40 to ptr
  %t43 = load ptr, ptr %l20, !tbaa !29
  %t45 = call i1 @compiler_2flower_2ecompiler_2flower_3aLowerer_2efreshResult(ptr %t42, ptr %t43, i64 %t36)
  store i1 %t45, ptr %l24
  br label %bb10
bb10:
  %t46 = load i1, ptr %l24, !tbaa !21
  store i1 %t46, ptr %l12, !tbaa !21
  br label %bb16
bb11:
  br i1 true, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  store i1 false, ptr %l12, !tbaa !21
  br label %bb16
bb15:
  call void @__olang_check_failed(ptr @olang_loc_c9ff4911a436500b_5835334d424a3697)
  unreachable
bb16:
  %t47 = load i1, ptr %l12, !tbaa !21
  store i1 %t47, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2egap(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l8 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca %"compiler/source:Span"
  %l12 = alloca i64
  %l17 = alloca %"compiler/lower:Gap"
  %s1 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 13
  %t4 = load i1, ptr %t3, !tbaa !21
  %t6 = xor i1 %t4, true
  br i1 %t6, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/lower:lowering", ptr %t8, i32 0, i32 0
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t13 = getelementptr %"compiler/lower:Lowerer", ptr %t11, i32 0, i32 13
  store ptr %t13, ptr %l8, !tbaa !29
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/lower:lowering", ptr %t14, i32 0, i32 7
  %t17 = load i64, ptr %t16, !tbaa !24
  store i64 %t17, ptr %l10, !tbaa !24
  store %"compiler/source:Span" %a1, ptr %l11
  %t19 = call ptr @__olang_scope_hold(ptr %s1)
  %t20 = ptrtoint ptr %t19 to i64
  store i64 %t20, ptr %l12, !tbaa !24
  %t21 = load i1, ptr @olang_2esole_2ecompiler_2flower_3aGap_2e2
  br i1 %t21, label %bb3, label %bb4
bb2:
  br label %bb7
bb3:
  %t23 = call ptr @__olang_region_make(ptr %s1)
  %t24 = ptrtoint ptr %t23 to i64
  store i64 %t24, ptr %l12, !tbaa !24
  br label %bb4
bb4:
  %t27 = extractvalue { i64, ptr } %a2, 1
  %t28 = extractvalue { i64, ptr } %a2, 0
  %t29 = load i64, ptr %l12
  %t30 = inttoptr i64 %t29 to ptr
  %t31 = call ptr @__olang_held_alloc(ptr %t30, i64 %t28)
  call void @olang_textcopy(ptr %t31, ptr %t27, i64 %t28)
  %t32 = insertvalue { i64, ptr } undef, i64 %t28, 0
  %t33 = insertvalue { i64, ptr } %t32, ptr %t31, 1
  %t35 = load i64, ptr %l10, !tbaa !24
  %t36 = load %"compiler/source:Span", ptr %l11
  %t38 = call %"compiler/lower:Gap" @compiler_2flower_3aGap_2ector(ptr %s1, ptr %s1, i64 %t35, %"compiler/source:Span" %t36, { i64, ptr } %t33)
  store %"compiler/lower:Gap" %t38, ptr %l17
  br label %bb5
bb5:
  %t39 = load ptr, ptr %l8, !tbaa !29
  %t40 = call ptr @__olang_scope_or(ptr %v2, ptr %t39)
  %t41 = call ptr @__olang_scope_hold(ptr %t40)
  %t42 = ptrtoint ptr %t41 to i64
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/lower:lowering", ptr %t43, i32 0, i32 0
  %t46 = load ptr, ptr %t45, !tbaa !29
  %t48 = call ptr @__olang_scope_or(ptr %v2, ptr %t46)
  %t49 = call ptr @__olang_scope_hold(ptr %t48)
  %t50 = ptrtoint ptr %t49 to i64
  %t52 = inttoptr i64 %t42 to ptr
  %t54 = inttoptr i64 %t50 to ptr
  %t55 = load ptr, ptr %l8, !tbaa !29
  %t56 = load %"compiler/lower:Gap", ptr %l17
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3aGap_3e_2ePush_3ccompiler_2flower_3aGap_3e(ptr %t52, ptr %t54, ptr %t55, %"compiler/lower:Gap" %t56)
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s1)
  br label %bb7
bb7:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/lower:lowering", ptr %t57, i32 0, i32 13
  store i1 true, ptr %t59, !tbaa !21
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2eguarded(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, i64 %a2, { i64, [15 x i64] } %a3, { i64, [1 x i64] } %a4, %"compiler/source:Span" %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca { i64, [15 x i64] }
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca i32
  %l9 = alloca ptr
  %l10 = alloca %"compiler/source:Span"
  %l12 = alloca %"compiler/mir:Lvalue"
  %l16 = alloca ptr
  %l17 = alloca %"compiler/source:Span"
  %l19 = alloca %"compiler/mir:Lvalue"
  %l27 = alloca i32
  %l28 = alloca ptr
  %l29 = alloca %"compiler/source:Span"
  %l31 = alloca %"compiler/mir:Lvalue"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %t11 = alloca { i64, [21 x i64] }, align 8
  %t31 = alloca { i64, [15 x i64] }, align 8
  %t37 = alloca { i64, [21 x i64] }, align 8
  %t65 = alloca { i64, [21 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i64 %a2, ptr %l2
  store { i64, [15 x i64] } %a3, ptr %l3
  store %"compiler/source:Span" %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l2, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t5 = load ptr, ptr %l0, !tbaa !29
  store ptr %t5, ptr %l9, !tbaa !29
  %t6 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t6, ptr %l10
  %t7 = load i32, ptr %l1, !tbaa !23
  %t9 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t7)
  store %"compiler/mir:Lvalue" %t9, ptr %l12
  br label %bb3
bb2:
  br label %bb5
bb3:
  %t10 = load { i64, [15 x i64] }, ptr %l3
  store { i64, [21 x i64] } zeroinitializer, ptr %t11
  %t12 = getelementptr { i64, [21 x i64] }, ptr %t11, i32 0, i32 0
  store i64 0, ptr %t12
  %t13 = load %"compiler/source:Span", ptr %l10
  %t14 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t13, 0
  %t15 = load %"compiler/mir:Lvalue", ptr %l12
  %t16 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t14, %"compiler/mir:Lvalue" %t15, 1
  %t18 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t16, { i64, [15 x i64] } %t10, 2
  %t19 = getelementptr { i64, [21 x i64] }, ptr %t11, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t18, ptr %t19
  %t20 = load { i64, [21 x i64] }, ptr %t11
  %t22 = call ptr @__olang_scope_alloc_a(ptr %s1, i64 176, i64 8)
  store { i64, [21 x i64] } %t20, ptr %t22
  %t23 = load ptr, ptr %l9, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s1, ptr %v1, ptr %v2, ptr %t23, ptr %t22)
  br label %bb4
bb4:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb5:
  %t25 = load ptr, ptr %l0, !tbaa !29
  store ptr %t25, ptr %l16, !tbaa !29
  %t26 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t26, ptr %l17
  %t27 = load i32, ptr %l1, !tbaa !23
  %t29 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t27)
  store %"compiler/mir:Lvalue" %t29, ptr %l19
  br label %bb6
bb6:
  store { i64, [15 x i64] } zeroinitializer, ptr %t31
  %t32 = getelementptr { i64, [15 x i64] }, ptr %t31, i32 0, i32 0
  store i64 20, ptr %t32
  %t34 = insertvalue { { i64, [1 x i64] } } undef, { i64, [1 x i64] } %a4, 0
  %t35 = getelementptr { i64, [15 x i64] }, ptr %t31, i32 0, i32 1
  store { { i64, [1 x i64] } } %t34, ptr %t35
  %t36 = load { i64, [15 x i64] }, ptr %t31
  store { i64, [21 x i64] } zeroinitializer, ptr %t37
  %t38 = getelementptr { i64, [21 x i64] }, ptr %t37, i32 0, i32 0
  store i64 0, ptr %t38
  %t39 = load %"compiler/source:Span", ptr %l17
  %t40 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t39, 0
  %t41 = load %"compiler/mir:Lvalue", ptr %l19
  %t42 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t40, %"compiler/mir:Lvalue" %t41, 1
  %t44 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t42, { i64, [15 x i64] } %t36, 2
  %t45 = getelementptr { i64, [21 x i64] }, ptr %t37, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t44, ptr %t45
  %t46 = load { i64, [21 x i64] }, ptr %t37
  %t48 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t46, ptr %t48
  %t49 = load ptr, ptr %l16, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s0, ptr %v1, ptr %v2, ptr %t49, ptr %t48)
  br label %bb7
bb7:
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t52 = load i64, ptr %l2, !tbaa !24
  %t53 = load %"compiler/source:Span", ptr %l5
  %t57 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2ewhenSole(ptr %v0, ptr %v1, ptr %v2, ptr %t51, i64 %t52, i1 true, %"compiler/source:Span" %t53)
  store i32 %t57, ptr %l27
  br label %bb8
bb8:
  %t58 = load i32, ptr %l27, !tbaa !23
  store i32 %t58, ptr %l6, !tbaa !23
  %t59 = load ptr, ptr %l0, !tbaa !29
  store ptr %t59, ptr %l28, !tbaa !29
  %t60 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t60, ptr %l29
  %t61 = load i32, ptr %l1, !tbaa !23
  %t63 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t61)
  store %"compiler/mir:Lvalue" %t63, ptr %l31
  br label %bb9
bb9:
  %t64 = load { i64, [15 x i64] }, ptr %l3
  store { i64, [21 x i64] } zeroinitializer, ptr %t65
  %t66 = getelementptr { i64, [21 x i64] }, ptr %t65, i32 0, i32 0
  store i64 0, ptr %t66
  %t67 = load %"compiler/source:Span", ptr %l29
  %t68 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t67, 0
  %t69 = load %"compiler/mir:Lvalue", ptr %l31
  %t70 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t68, %"compiler/mir:Lvalue" %t69, 1
  %t72 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t70, { i64, [15 x i64] } %t64, 2
  %t73 = getelementptr { i64, [21 x i64] }, ptr %t65, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t72, ptr %t73
  %t74 = load { i64, [21 x i64] }, ptr %t65
  %t76 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t74, ptr %t76
  %t77 = load ptr, ptr %l28, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s0, ptr %v1, ptr %v2, ptr %t77, ptr %t76)
  br label %bb10
bb10:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t80 = load i32, ptr %l6, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2ejoinAt(ptr %v0, ptr %v2, ptr %v1, ptr %t79, i32 %t80)
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eheldLocal(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca %"compiler/typed:Local"
  %l4 = alloca i64
  %l7 = alloca ptr
  %l10 = alloca %"compiler/typed:Local"
  %l12 = alloca ptr
  %l15 = alloca i1
  %l20 = alloca ptr
  %l23 = alloca i1
  %l25 = alloca i1
  %l28 = alloca i1
  %l29 = alloca i1
  %l31 = alloca ptr
  %l34 = alloca i1
  %l39 = alloca i1
  %l45 = alloca i64
  %l48 = alloca i1
  %l52 = alloca i1
  %l57 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/typed:Body", ptr %t4, i32 0, i32 7
  store ptr %t6, ptr %l7, !tbaa !29
  %t7 = load i64, ptr %l2, !tbaa !24
  %t8 = load ptr, ptr %l7, !tbaa !29
  %t9 = call ptr @__olang_scope_or(ptr %v2, ptr %t8)
  %t10 = call ptr @__olang_scope_hold(ptr %t9)
  %t11 = ptrtoint ptr %t10 to i64
  %t13 = inttoptr i64 %t11 to ptr
  %t14 = load ptr, ptr %l7, !tbaa !29
  %t16 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %t13, ptr %t14, i64 %t7)
  store %"compiler/typed:Local" %t16, ptr %l10
  br label %bb1
bb1:
  %t17 = load %"compiler/typed:Local", ptr %l10
  store %"compiler/typed:Local" %t17, ptr %l3
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/lower:lowering", ptr %t18, i32 0, i32 2
  %t21 = load ptr, ptr %t20, !tbaa !29
  store ptr %t21, ptr %l12, !tbaa !29
  %t22 = getelementptr %"compiler/typed:Local", ptr %l3, i32 0, i32 2
  %t23 = load i32, ptr %t22, !tbaa !23
  %t24 = load ptr, ptr %l12, !tbaa !29
  %t25 = call ptr @__olang_scope_or(ptr %v3, ptr %t24)
  %t26 = call ptr @__olang_scope_hold(ptr %t25)
  %t27 = ptrtoint ptr %t26 to i64
  %t29 = inttoptr i64 %t27 to ptr
  %t30 = load ptr, ptr %l12, !tbaa !29
  %t32 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSharesRefs(ptr %t29, ptr %t30, i32 %t23)
  store i1 %t32, ptr %l15
  br label %bb2
bb2:
  %t33 = load i1, ptr %l15, !tbaa !21
  br i1 %t33, label %bb3, label %bb4
bb3:
  store i1 false, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t35 = getelementptr %"compiler/typed:Local", ptr %l3, i32 0, i32 4
  %t36 = load i32, ptr %t35, !range !{i32 0, i32 7}
  %t38 = trunc i64 0 to i32
  %t39 = icmp eq i32 %t36, %t38
  br i1 %t39, label %bb6, label %bb7
bb6:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/lower:lowering", ptr %t41, i32 0, i32 2
  %t44 = load ptr, ptr %t43, !tbaa !29
  store ptr %t44, ptr %l20, !tbaa !29
  %t45 = getelementptr %"compiler/typed:Local", ptr %l3, i32 0, i32 2
  %t46 = load i32, ptr %t45, !tbaa !23
  %t47 = load ptr, ptr %l20, !tbaa !29
  %t48 = call ptr @__olang_scope_or(ptr %v3, ptr %t47)
  %t49 = call ptr @__olang_scope_hold(ptr %t48)
  %t50 = ptrtoint ptr %t49 to i64
  %t52 = inttoptr i64 %t50 to ptr
  %t53 = load ptr, ptr %l20, !tbaa !29
  %t55 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %t52, ptr %t53, i32 %t46)
  store i1 %t55, ptr %l23
  br label %bb8
bb7:
  br label %bb17
bb8:
  %t56 = load i1, ptr %l23, !tbaa !21
  %t57 = xor i1 %t56, true
  br i1 %t57, label %bb9, label %bb10
bb9:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t60 = load i64, ptr %l2, !tbaa !24
  %t63 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eparamElig(ptr %v0, ptr %v2, ptr %v4, ptr %t59, i64 %t60)
  store i1 %t63, ptr %l28
  br label %bb11
bb10:
  store i1 false, ptr %l25, !tbaa !21
  br label %bb12
bb11:
  %t64 = load i1, ptr %l28, !tbaa !21
  store i1 %t64, ptr %l25, !tbaa !21
  br label %bb12
bb12:
  %t65 = load i1, ptr %l25, !tbaa !21
  br i1 %t65, label %bb13, label %bb14
bb13:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"compiler/lower:lowering", ptr %t66, i32 0, i32 2
  %t69 = load ptr, ptr %t68, !tbaa !29
  store ptr %t69, ptr %l31, !tbaa !29
  %t70 = getelementptr %"compiler/typed:Local", ptr %l3, i32 0, i32 2
  %t71 = load i32, ptr %t70, !tbaa !23
  %t72 = load ptr, ptr %l31, !tbaa !29
  %t73 = call ptr @__olang_scope_or(ptr %v3, ptr %t72)
  %t74 = call ptr @__olang_scope_hold(ptr %t73)
  %t75 = ptrtoint ptr %t74 to i64
  %t77 = inttoptr i64 %t75 to ptr
  %t78 = load ptr, ptr %l31, !tbaa !29
  %t80 = call i1 @compiler_2flower_2erunArray(ptr %t77, ptr %t78, i32 %t71)
  store i1 %t80, ptr %l34
  br label %bb15
bb14:
  store i1 false, ptr %l29, !tbaa !21
  br label %bb16
bb15:
  %t81 = load i1, ptr %l34, !tbaa !21
  %t82 = xor i1 %t81, true
  store i1 %t82, ptr %l29, !tbaa !21
  br label %bb16
bb16:
  %t84 = load i1, ptr %l29, !tbaa !21
  store i1 %t84, ptr %rv
  br label %ret
bb17:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t86 = load ptr, ptr %l1, !tbaa !29
  %t87 = load i64, ptr %l2, !tbaa !24
  %t91 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eheldUnchanged(ptr %v0, ptr %v1, ptr %v2, ptr %v4, ptr %t85, ptr %t86, i64 %t87)
  store i1 %t91, ptr %l39
  br label %bb18
bb18:
  %t92 = load i1, ptr %l39, !tbaa !21
  %t93 = xor i1 %t92, true
  br i1 %t93, label %bb19, label %bb20
bb19:
  store i1 false, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  %t96 = load ptr, ptr %l1, !tbaa !29
  %t98 = getelementptr %"compiler/typed:LocalUses", ptr %t96, i32 0, i32 19
  %t99 = load i64, ptr %l2, !tbaa !24
  %t102 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t98, i64 %t99)
  store i64 %t102, ptr %l45
  br label %bb22
bb22:
  %t103 = load i64, ptr %l45, !tbaa !24
  store i64 %t103, ptr %l4, !tbaa !24
  %t104 = load i64, ptr %l4, !tbaa !24
  %t106 = icmp sge i64 %t104, 0
  br i1 %t106, label %bb23, label %bb24
bb23:
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = getelementptr %"compiler/lower:lowering", ptr %t108, i32 0, i32 68
  %t111 = load i64, ptr %l2, !tbaa !24
  %t114 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %t110, i64 %t111)
  store i1 %t114, ptr %l52
  br label %bb25
bb24:
  store i1 false, ptr %l48, !tbaa !21
  br label %bb26
bb25:
  %t115 = load i1, ptr %l52, !tbaa !21
  %t116 = xor i1 %t115, true
  store i1 %t116, ptr %l48, !tbaa !21
  br label %bb26
bb26:
  %t118 = load i1, ptr %l48, !tbaa !21
  br i1 %t118, label %bb27, label %bb28
bb27:
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t120 = load ptr, ptr %l1, !tbaa !29
  %t121 = load i64, ptr %l4, !tbaa !24
  %t125 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eheldLocal(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %t119, ptr %t120, i64 %t121)
  store i1 %t125, ptr %l57
  br label %bb29
bb28:
  br label %bb30
bb29:
  %t126 = load i1, ptr %l57, !tbaa !21
  store i1 %t126, ptr %rv
  br label %ret
bb30:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eheldPlace(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca i32
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i1
  %l11 = alloca ptr
  %l12 = alloca i1
  %l21 = alloca i1
  %l22 = alloca ptr
  %l23 = alloca i1
  %l33 = alloca i1
  %l34 = alloca ptr
  %l35 = alloca i1
  %l43 = alloca i1
  %l44 = alloca ptr
  %l45 = alloca i1
  %l54 = alloca i1
  %l55 = alloca ptr
  %l56 = alloca i1
  %l65 = alloca i1
  %l66 = alloca ptr
  %l67 = alloca i1
  %l75 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  store ptr %t1, ptr %l11, !tbaa !29
  store i1 false, ptr %l12, !tbaa !21
  %t2 = load ptr, ptr %l11, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l11, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l12, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l12, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l3, !tbaa !23
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load ptr, ptr %l1, !tbaa !29
  %t18 = load i32, ptr %l3, !tbaa !23
  %t20 = sext i32 %t18 to i64
  %t24 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eheldLocal(ptr %v0, ptr %v1, ptr %v3, ptr %v4, ptr %v5, ptr %t16, ptr %t17, i64 %t20)
  store i1 %t24, ptr %l21
  br label %bb6
bb6:
  %t25 = load i1, ptr %l21, !tbaa !21
  store i1 %t25, ptr %l10, !tbaa !21
  br label %bb47
bb7:
  %t26 = load ptr, ptr %l2, !tbaa !29
  store ptr %t26, ptr %l22, !tbaa !29
  store i1 false, ptr %l23, !tbaa !21
  %t27 = load ptr, ptr %l22, !tbaa !29
  %t28 = icmp ne ptr %t27, null
  br i1 %t28, label %bb8, label %bb9
bb8:
  %t30 = load ptr, ptr %l22, !tbaa !29
  %t31 = load i64, ptr %t30, !range !{i64 0, i64 8}
  %t33 = icmp eq i64 %t31, 1
  store i1 %t33, ptr %l23, !tbaa !21
  br label %bb9
bb9:
  %t34 = load i1, ptr %l23, !tbaa !21
  br i1 %t34, label %bb10, label %bb11
bb10:
  %t35 = load ptr, ptr %l2, !tbaa !29
  %t37 = getelementptr { i64, [4 x i64] }, ptr %t35, i32 0, i32 1
  %t38 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t37, i32 0, i32 2
  %t39 = load i64, ptr %t38
  store i64 %t39, ptr %l4, !tbaa !24
  %t41 = load ptr, ptr %l2, !tbaa !29
  %t43 = getelementptr { i64, [4 x i64] }, ptr %t41, i32 0, i32 1
  %t44 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t43, i32 0, i32 3
  %t45 = load i32, ptr %t44
  store i32 %t45, ptr %l5, !tbaa !23
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t48 = load i64, ptr %l4, !tbaa !24
  %t49 = load i32, ptr %l5, !tbaa !23
  %t53 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eimmutableGlobal(ptr %v0, ptr %v5, ptr %t47, i64 %t48, i32 %t49)
  store i1 %t53, ptr %l33
  br label %bb13
bb13:
  %t54 = load i1, ptr %l33, !tbaa !21
  store i1 %t54, ptr %l10, !tbaa !21
  br label %bb47
bb14:
  %t55 = load ptr, ptr %l2, !tbaa !29
  store ptr %t55, ptr %l34, !tbaa !29
  store i1 false, ptr %l35, !tbaa !21
  %t56 = load ptr, ptr %l34, !tbaa !29
  %t57 = icmp ne ptr %t56, null
  br i1 %t57, label %bb15, label %bb16
bb15:
  %t59 = load ptr, ptr %l34, !tbaa !29
  %t60 = load i64, ptr %t59, !range !{i64 0, i64 8}
  %t62 = icmp eq i64 %t60, 3
  store i1 %t62, ptr %l35, !tbaa !21
  br label %bb16
bb16:
  %t63 = load i1, ptr %l35, !tbaa !21
  br i1 %t63, label %bb17, label %bb18
bb17:
  %t64 = load ptr, ptr %l2, !tbaa !29
  %t66 = getelementptr { i64, [4 x i64] }, ptr %t64, i32 0, i32 1
  %t67 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t66, i32 0, i32 2
  %t68 = load ptr, ptr %t67
  store ptr %t68, ptr %l6, !tbaa !29
  br label %bb19
bb18:
  br label %bb21
bb19:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t71 = load ptr, ptr %l1, !tbaa !29
  %t72 = load ptr, ptr %l6, !tbaa !29
  %t76 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eheldPlace(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %t70, ptr %t71, ptr %t72)
  store i1 %t76, ptr %l43
  br label %bb20
bb20:
  %t77 = load i1, ptr %l43, !tbaa !21
  store i1 %t77, ptr %l10, !tbaa !21
  br label %bb47
bb21:
  %t78 = load ptr, ptr %l2, !tbaa !29
  store ptr %t78, ptr %l44, !tbaa !29
  store i1 false, ptr %l45, !tbaa !21
  %t79 = load ptr, ptr %l44, !tbaa !29
  %t80 = icmp ne ptr %t79, null
  br i1 %t80, label %bb22, label %bb23
bb22:
  %t82 = load ptr, ptr %l44, !tbaa !29
  %t83 = load i64, ptr %t82, !range !{i64 0, i64 8}
  %t85 = icmp eq i64 %t83, 4
  store i1 %t85, ptr %l45, !tbaa !21
  br label %bb23
bb23:
  %t86 = load i1, ptr %l45, !tbaa !21
  br i1 %t86, label %bb24, label %bb25
bb24:
  %t87 = load ptr, ptr %l2, !tbaa !29
  %t89 = getelementptr { i64, [4 x i64] }, ptr %t87, i32 0, i32 1
  %t90 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t89, i32 0, i32 2
  %t91 = load ptr, ptr %t90
  store ptr %t91, ptr %l7, !tbaa !29
  br label %bb26
bb25:
  br label %bb28
bb26:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t94 = load ptr, ptr %l1, !tbaa !29
  %t95 = load ptr, ptr %l7, !tbaa !29
  %t97 = getelementptr %"compiler/typed:Elem", ptr %t95, i32 0, i32 0
  %t98 = load ptr, ptr %t97, !tbaa !29
  %t102 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eheldPlace(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %t93, ptr %t94, ptr %t98)
  store i1 %t102, ptr %l54
  br label %bb27
bb27:
  %t103 = load i1, ptr %l54, !tbaa !21
  store i1 %t103, ptr %l10, !tbaa !21
  br label %bb47
bb28:
  %t104 = load ptr, ptr %l2, !tbaa !29
  store ptr %t104, ptr %l55, !tbaa !29
  store i1 false, ptr %l56, !tbaa !21
  %t105 = load ptr, ptr %l55, !tbaa !29
  %t106 = icmp ne ptr %t105, null
  br i1 %t106, label %bb29, label %bb30
bb29:
  %t108 = load ptr, ptr %l55, !tbaa !29
  %t109 = load i64, ptr %t108, !range !{i64 0, i64 8}
  %t111 = icmp eq i64 %t109, 5
  store i1 %t111, ptr %l56, !tbaa !21
  br label %bb30
bb30:
  %t112 = load i1, ptr %l56, !tbaa !21
  br i1 %t112, label %bb31, label %bb32
bb31:
  %t113 = load ptr, ptr %l2, !tbaa !29
  %t115 = getelementptr { i64, [4 x i64] }, ptr %t113, i32 0, i32 1
  %t116 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t115, i32 0, i32 2
  %t117 = load ptr, ptr %t116
  store ptr %t117, ptr %l8, !tbaa !29
  br label %bb33
bb32:
  br label %bb35
bb33:
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t120 = load ptr, ptr %l1, !tbaa !29
  %t121 = load ptr, ptr %l8, !tbaa !29
  %t123 = getelementptr %"compiler/typed:Payload", ptr %t121, i32 0, i32 0
  %t124 = load ptr, ptr %t123, !tbaa !29
  %t128 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eheldPlace(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %t119, ptr %t120, ptr %t124)
  store i1 %t128, ptr %l65
  br label %bb34
bb34:
  %t129 = load i1, ptr %l65, !tbaa !21
  store i1 %t129, ptr %l10, !tbaa !21
  br label %bb47
bb35:
  %t130 = load ptr, ptr %l2, !tbaa !29
  store ptr %t130, ptr %l66, !tbaa !29
  store i1 false, ptr %l67, !tbaa !21
  %t131 = load ptr, ptr %l66, !tbaa !29
  %t132 = icmp ne ptr %t131, null
  br i1 %t132, label %bb36, label %bb37
bb36:
  %t134 = load ptr, ptr %l66, !tbaa !29
  %t135 = load i64, ptr %t134, !range !{i64 0, i64 8}
  %t137 = icmp eq i64 %t135, 2
  store i1 %t137, ptr %l67, !tbaa !21
  br label %bb37
bb37:
  %t138 = load i1, ptr %l67, !tbaa !21
  br i1 %t138, label %bb38, label %bb39
bb38:
  %t139 = load ptr, ptr %l2, !tbaa !29
  %t141 = getelementptr { i64, [4 x i64] }, ptr %t139, i32 0, i32 1
  %t142 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t141, i32 0, i32 2
  %t143 = load ptr, ptr %t142
  store ptr %t143, ptr %l9, !tbaa !29
  br label %bb40
bb39:
  br label %bb42
bb40:
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t146 = load ptr, ptr %l1, !tbaa !29
  %t147 = load ptr, ptr %l9, !tbaa !29
  %t151 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eheldSrc(ptr %v0, ptr %v1, ptr %v2, ptr %v4, ptr %v3, ptr %v5, ptr %t145, ptr %t146, ptr %t147)
  store i1 %t151, ptr %l75
  br label %bb41
bb41:
  %t152 = load i1, ptr %l75, !tbaa !21
  store i1 %t152, ptr %l10, !tbaa !21
  br label %bb47
bb42:
  br i1 true, label %bb43, label %bb44
bb43:
  br label %bb45
bb44:
  br label %bb46
bb45:
  store i1 false, ptr %l10, !tbaa !21
  br label %bb47
bb46:
  call void @__olang_check_failed(ptr @olang_loc_bfe20f6aa057d6f5_318d2eb3f782ecf9)
  unreachable
bb47:
  %t153 = load i1, ptr %l10, !tbaa !21
  store i1 %t153, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eheldReferent(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca %"compiler/typed:Local"
  %l4 = alloca ptr
  %l7 = alloca ptr
  %l10 = alloca %"compiler/typed:Local"
  %l12 = alloca ptr
  %l14 = alloca ptr
  %l17 = alloca i32
  %l19 = alloca i1
  %l21 = alloca i1
  %l28 = alloca i1
  %l33 = alloca ptr
  %l37 = alloca i1
  %l40 = alloca i1
  %l41 = alloca i1
  %l45 = alloca i1
  %l50 = alloca i1
  %l52 = alloca i1
  %l56 = alloca i1
  %l58 = alloca i1
  %l59 = alloca ptr
  %l61 = alloca ptr
  %l64 = alloca i32
  %l65 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/typed:Body", ptr %t4, i32 0, i32 7
  store ptr %t6, ptr %l7, !tbaa !29
  %t7 = load i64, ptr %l2, !tbaa !24
  %t8 = load ptr, ptr %l7, !tbaa !29
  %t9 = call ptr @__olang_scope_or(ptr %v2, ptr %t8)
  %t10 = call ptr @__olang_scope_hold(ptr %t9)
  %t11 = ptrtoint ptr %t10 to i64
  %t13 = inttoptr i64 %t11 to ptr
  %t14 = load ptr, ptr %l7, !tbaa !29
  %t16 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %t13, ptr %t14, i64 %t7)
  store %"compiler/typed:Local" %t16, ptr %l10
  br label %bb1
bb1:
  %t17 = load %"compiler/typed:Local", ptr %l10
  store %"compiler/typed:Local" %t17, ptr %l3
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/lower:lowering", ptr %t18, i32 0, i32 2
  %t21 = load ptr, ptr %t20, !tbaa !29
  store ptr %t21, ptr %l12, !tbaa !29
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/lower:lowering", ptr %t22, i32 0, i32 2
  %t25 = load ptr, ptr %t24, !tbaa !29
  store ptr %t25, ptr %l14, !tbaa !29
  %t26 = getelementptr %"compiler/typed:Local", ptr %l3, i32 0, i32 2
  %t27 = load i32, ptr %t26, !tbaa !23
  %t28 = load ptr, ptr %l14, !tbaa !29
  %t29 = call ptr @__olang_scope_or(ptr %v3, ptr %t28)
  %t30 = call ptr @__olang_scope_hold(ptr %t29)
  %t31 = ptrtoint ptr %t30 to i64
  %t33 = inttoptr i64 %t31 to ptr
  %t34 = load ptr, ptr %l14, !tbaa !29
  %t36 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %t33, ptr %t34, i32 %t27)
  store i32 %t36, ptr %l17
  br label %bb2
bb2:
  %t37 = load ptr, ptr %l12, !tbaa !29
  %t38 = call ptr @__olang_scope_or(ptr %v3, ptr %t37)
  %t39 = call ptr @__olang_scope_hold(ptr %t38)
  %t40 = ptrtoint ptr %t39 to i64
  %t42 = inttoptr i64 %t40 to ptr
  %t43 = load ptr, ptr %l12, !tbaa !29
  %t44 = load i32, ptr %l17, !tbaa !23
  %t45 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSharesRefs(ptr %t42, ptr %t43, i32 %t44)
  store i1 %t45, ptr %l19
  br label %bb3
bb3:
  %t46 = load i1, ptr %l19, !tbaa !21
  %t47 = xor i1 %t46, true
  br i1 %t47, label %bb4, label %bb5
bb4:
  %t49 = getelementptr %"compiler/typed:Local", ptr %l3, i32 0, i32 4
  %t50 = load i32, ptr %t49, !range !{i32 0, i32 7}
  %t52 = trunc i64 0 to i32
  %t53 = icmp eq i32 %t50, %t52
  %t55 = xor i1 %t53, true
  store i1 %t55, ptr %l21, !tbaa !21
  br label %bb6
bb5:
  store i1 false, ptr %l21, !tbaa !21
  br label %bb6
bb6:
  %t57 = load i1, ptr %l21, !tbaa !21
  br i1 %t57, label %bb7, label %bb8
bb7:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/lower:lowering", ptr %t58, i32 0, i32 68
  %t61 = load i64, ptr %l2, !tbaa !24
  %t64 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %t60, i64 %t61)
  store i1 %t64, ptr %l28
  br label %bb9
bb8:
  br label %bb25
bb9:
  %t65 = load i1, ptr %l28, !tbaa !21
  br i1 %t65, label %bb10, label %bb11
bb10:
  store i1 true, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t67 = load ptr, ptr %l1, !tbaa !29
  %t69 = getelementptr %"compiler/typed:LocalUses", ptr %t67, i32 0, i32 20
  %t70 = load i64, ptr %l2, !tbaa !24
  %t73 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_3f_26_3e_2eAt__H2e4a6474e10b73ca754517844b8d7700(ptr %v1, ptr %v1, ptr %t69, i64 %t70)
  store ptr %t73, ptr %l33
  br label %bb13
bb13:
  %t74 = load ptr, ptr %l33, !tbaa !29
  store ptr %t74, ptr %l4, !tbaa !29
  %t75 = load ptr, ptr %l4, !tbaa !29
  %t77 = icmp eq ptr %t75, null
  %t79 = xor i1 %t77, true
  br i1 %t79, label %bb14, label %bb15
bb14:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t82 = load ptr, ptr %l4, !tbaa !29
  %t85 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2efreshCall(ptr %v0, ptr %v1, ptr %v4, ptr %t81, ptr %t82)
  store i1 %t85, ptr %l40
  br label %bb16
bb15:
  store i1 false, ptr %l37, !tbaa !21
  br label %bb17
bb16:
  %t86 = load i1, ptr %l40, !tbaa !21
  store i1 %t86, ptr %l37, !tbaa !21
  br label %bb17
bb17:
  %t87 = load i1, ptr %l37, !tbaa !21
  br i1 %t87, label %bb18, label %bb19
bb18:
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t89 = load ptr, ptr %l1, !tbaa !29
  %t90 = load i64, ptr %l2, !tbaa !24
  %t94 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eheldUnchanged(ptr %v0, ptr %v1, ptr %v2, ptr %v4, ptr %t88, ptr %t89, i64 %t90)
  store i1 %t94, ptr %l45
  br label %bb20
bb19:
  store i1 false, ptr %l41, !tbaa !21
  br label %bb21
bb20:
  %t95 = load i1, ptr %l45, !tbaa !21
  store i1 %t95, ptr %l41, !tbaa !21
  br label %bb21
bb21:
  %t96 = load i1, ptr %l41, !tbaa !21
  br i1 %t96, label %bb22, label %bb23
bb22:
  store i1 true, ptr %rv
  br label %ret
bb23:
  br label %bb24
bb24:
  br label %bb25
bb25:
  %t98 = load ptr, ptr %l1, !tbaa !29
  %t100 = getelementptr %"compiler/typed:LocalUses", ptr %t98, i32 0, i32 4
  %t101 = load i64, ptr %l2, !tbaa !24
  %t104 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v1, ptr %t100, i64 %t101)
  store i1 %t104, ptr %l50
  br label %bb26
bb26:
  %t105 = load i1, ptr %l50, !tbaa !21
  %t106 = xor i1 %t105, true
  br i1 %t106, label %bb27, label %bb28
bb27:
  %t108 = load ptr, ptr %l1, !tbaa !29
  %t110 = getelementptr %"compiler/typed:LocalUses", ptr %t108, i32 0, i32 2
  %t111 = load i64, ptr %l2, !tbaa !24
  %t114 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v1, ptr %t110, i64 %t111)
  store i1 %t114, ptr %l56
  br label %bb29
bb28:
  store i1 false, ptr %l52, !tbaa !21
  br label %bb30
bb29:
  %t115 = load i1, ptr %l56, !tbaa !21
  %t116 = xor i1 %t115, true
  store i1 %t116, ptr %l52, !tbaa !21
  br label %bb30
bb30:
  %t118 = load i1, ptr %l52, !tbaa !21
  br i1 %t118, label %bb31, label %bb32
bb31:
  %t119 = load ptr, ptr %l0, !tbaa !29
  store ptr %t119, ptr %l59, !tbaa !29
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t122 = getelementptr %"compiler/lower:lowering", ptr %t120, i32 0, i32 2
  %t123 = load ptr, ptr %t122, !tbaa !29
  store ptr %t123, ptr %l61, !tbaa !29
  %t124 = getelementptr %"compiler/typed:Local", ptr %l3, i32 0, i32 2
  %t125 = load i32, ptr %t124, !tbaa !23
  %t126 = load ptr, ptr %l61, !tbaa !29
  %t127 = call ptr @__olang_scope_or(ptr %v3, ptr %t126)
  %t128 = call ptr @__olang_scope_hold(ptr %t127)
  %t129 = ptrtoint ptr %t128 to i64
  %t131 = inttoptr i64 %t129 to ptr
  %t132 = load ptr, ptr %l61, !tbaa !29
  %t134 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %t131, ptr %t132, i32 %t125)
  store i32 %t134, ptr %l64
  br label %bb33
bb32:
  store i1 false, ptr %l58, !tbaa !21
  br label %bb35
bb33:
  %t135 = load ptr, ptr %l59, !tbaa !29
  %t136 = load i32, ptr %l64, !tbaa !23
  %t137 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2equietLife(ptr %v0, ptr %v2, ptr %v3, ptr %v4, ptr %t135, i32 %t136)
  store i1 %t137, ptr %l65
  br label %bb34
bb34:
  %t138 = load i1, ptr %l65, !tbaa !21
  store i1 %t138, ptr %l58, !tbaa !21
  br label %bb35
bb35:
  %t139 = load i1, ptr %l58, !tbaa !21
  store i1 %t139, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eheldUnchanged(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca %"compiler/typed:Local"
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l12 = alloca ptr
  %l15 = alloca %"compiler/typed:Local"
  %l18 = alloca i1
  %l23 = alloca i1
  %l29 = alloca i1
  %l30 = alloca i1
  %l34 = alloca i1
  %l35 = alloca i1
  %l39 = alloca i1
  %l40 = alloca i1
  %l44 = alloca i1
  %l49 = alloca i64
  %l53 = alloca i64
  %l56 = alloca i64
  %l77 = alloca i64
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/typed:Body", ptr %t4, i32 0, i32 7
  store ptr %t6, ptr %l12, !tbaa !29
  %t7 = load i64, ptr %l2, !tbaa !24
  %t8 = load ptr, ptr %l12, !tbaa !29
  %t9 = call ptr @__olang_scope_or(ptr %v2, ptr %t8)
  %t10 = call ptr @__olang_scope_hold(ptr %t9)
  %t11 = ptrtoint ptr %t10 to i64
  %t13 = inttoptr i64 %t11 to ptr
  %t14 = load ptr, ptr %l12, !tbaa !29
  %t16 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %t13, ptr %t14, i64 %t7)
  store %"compiler/typed:Local" %t16, ptr %l15
  br label %bb1
bb1:
  %t17 = load %"compiler/typed:Local", ptr %l15
  store %"compiler/typed:Local" %t17, ptr %l3
  %t18 = getelementptr %"compiler/typed:Local", ptr %l3, i32 0, i32 4
  %t19 = load i32, ptr %t18, !range !{i32 0, i32 7}
  %t21 = trunc i64 5 to i32
  %t22 = icmp eq i32 %t19, %t21
  br i1 %t22, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l18, !tbaa !21
  br label %bb5
bb3:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/typed:Local", ptr %l3, i32 0, i32 3
  %t26 = load i32, ptr %t25, !tbaa !23
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/lower:lowering", ptr %t27, i32 0, i32 79
  %t30 = load i32, ptr %t29, !tbaa !23
  %t34 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eencloses(ptr %v0, ptr %v2, ptr %t24, i32 %t26, i32 %t30)
  store i1 %t34, ptr %l23
  br label %bb4
bb4:
  %t35 = load i1, ptr %l23, !tbaa !21
  %t36 = xor i1 %t35, true
  store i1 %t36, ptr %l18, !tbaa !21
  br label %bb5
bb5:
  %t38 = load i1, ptr %l18, !tbaa !21
  br i1 %t38, label %bb6, label %bb7
bb6:
  store i1 false, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t40 = load ptr, ptr %l1, !tbaa !29
  %t42 = getelementptr %"compiler/typed:LocalUses", ptr %t40, i32 0, i32 2
  %t43 = load i64, ptr %l2, !tbaa !24
  %t46 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v1, ptr %t42, i64 %t43)
  store i1 %t46, ptr %l29
  br label %bb9
bb9:
  %t47 = load i1, ptr %l29, !tbaa !21
  br i1 %t47, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l30, !tbaa !21
  br label %bb13
bb11:
  %t48 = load ptr, ptr %l1, !tbaa !29
  %t50 = getelementptr %"compiler/typed:LocalUses", ptr %t48, i32 0, i32 4
  %t51 = load i64, ptr %l2, !tbaa !24
  %t54 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v1, ptr %t50, i64 %t51)
  store i1 %t54, ptr %l34
  br label %bb12
bb12:
  %t55 = load i1, ptr %l34, !tbaa !21
  store i1 %t55, ptr %l30, !tbaa !21
  br label %bb13
bb13:
  %t56 = load i1, ptr %l30, !tbaa !21
  br i1 %t56, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l35, !tbaa !21
  br label %bb17
bb15:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t58 = load ptr, ptr %l1, !tbaa !29
  %t59 = load i64, ptr %l2, !tbaa !24
  %t63 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eescapes(ptr %v0, ptr %v1, ptr %v3, ptr %t57, ptr %t58, i64 %t59)
  store i1 %t63, ptr %l39
  br label %bb16
bb16:
  %t64 = load i1, ptr %l39, !tbaa !21
  store i1 %t64, ptr %l35, !tbaa !21
  br label %bb17
bb17:
  %t65 = load i1, ptr %l35, !tbaa !21
  br i1 %t65, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l40, !tbaa !21
  br label %bb21
bb19:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t67 = load ptr, ptr %l1, !tbaa !29
  %t68 = load i64, ptr %l2, !tbaa !24
  %t72 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2elendsKeep(ptr %v0, ptr %v1, ptr %v3, ptr %t66, ptr %t67, i64 %t68)
  store i1 %t72, ptr %l44
  br label %bb20
bb20:
  %t73 = load i1, ptr %l44, !tbaa !21
  %t74 = xor i1 %t73, true
  store i1 %t74, ptr %l40, !tbaa !21
  br label %bb21
bb21:
  %t76 = load i1, ptr %l40, !tbaa !21
  br i1 %t76, label %bb22, label %bb23
bb22:
  store i1 false, ptr %rv
  br label %ret
bb23:
  br label %bb24
bb24:
  store i64 0, ptr %l4, !tbaa !24
  %t78 = load ptr, ptr %l1, !tbaa !29
  %t80 = getelementptr %"compiler/typed:LocalUses", ptr %t78, i32 0, i32 22
  %t82 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t80)
  store i64 %t82, ptr %l49
  br label %bb25
bb25:
  %t83 = load i64, ptr %l49, !tbaa !24
  store i64 %t83, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t84 = load i64, ptr %l5, !tbaa !24
  %t85 = load i64, ptr %l4, !tbaa !24
  %t88 = icmp sgt i64 %t84, %t85
  br i1 %t88, label %bb26, label %bb27
bb26:
  %t90 = load i64, ptr %l6, !tbaa !24
  %t92 = icmp sgt i64 %t90, 0
  br i1 %t92, label %bb28, label %bb29
bb27:
  store i64 0, ptr %l53, !tbaa !24
  br label %bb31
bb28:
  %t94 = load i64, ptr %l5, !tbaa !24
  %t95 = load i64, ptr %l4, !tbaa !24
  %t98 = sub i64 %t94, %t95
  %t99 = load i64, ptr %l6, !tbaa !24
  %t102 = add i64 %t98, %t99
  %t104 = sub i64 %t102, 1
  %t105 = load i64, ptr %l6, !tbaa !24
  %t108 = sdiv i64 %t104, %t105
  store i64 %t108, ptr %l56, !tbaa !24
  br label %bb30
bb29:
  store i64 0, ptr %l56, !tbaa !24
  br label %bb30
bb30:
  %t110 = load i64, ptr %l56, !tbaa !24
  store i64 %t110, ptr %l53, !tbaa !24
  br label %bb31
bb31:
  %t111 = load i64, ptr %l53, !tbaa !24
  store i64 %t111, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb32
bb32:
  %t112 = load i64, ptr %l8, !tbaa !24
  %t113 = load i64, ptr %l7, !tbaa !24
  %t116 = icmp slt i64 %t112, %t113
  %t118 = xor i1 %t116, true
  br i1 %t118, label %bb33, label %bb34
bb33:
  br label %bb41
bb34:
  br label %bb35
bb35:
  %t120 = load i64, ptr %l4, !tbaa !24
  %t121 = load i64, ptr %l8, !tbaa !24
  %t122 = load i64, ptr %l6, !tbaa !24
  %t125 = mul i64 %t121, %t122
  %t128 = add i64 %t120, %t125
  %t130 = load ptr, ptr %l1, !tbaa !29
  %t132 = getelementptr %"compiler/typed:LocalUses", ptr %t130, i32 0, i32 22
  %t136 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t132, i64 %t128)
  store i64 %t136, ptr %l77
  br label %bb36
bb36:
  %t137 = load i64, ptr %l2, !tbaa !24
  %t138 = load i64, ptr %l77, !tbaa !24
  %t140 = icmp eq i64 %t138, %t137
  br i1 %t140, label %bb37, label %bb38
bb37:
  store i1 false, ptr %rv
  br label %ret
bb38:
  br label %bb39
bb39:
  br label %bb40
bb40:
  %t143 = load i64, ptr %l8, !tbaa !24
  %t146 = add i64 %t143, 1
  store i64 %t146, ptr %l8, !tbaa !24
  br label %bb32
bb41:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ehelperCall(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, i32 %a1, i32 %a2, { i64, ptr } %a3, { i64, ptr } %a4, i32 %a5, %"compiler/source:Span" %a6) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l5 = alloca i32
  %l6 = alloca %"compiler/source:Span"
  %l7 = alloca i32
  %l8 = alloca { i64, [2 x i64] }
  %l9 = alloca i32
  %l10 = alloca i32
  %l13 = alloca ptr
  %l17 = alloca i32
  %l19 = alloca ptr
  %l23 = alloca i32
  %l28 = alloca ptr
  %l33 = alloca i32
  %l41 = alloca i32
  %l43 = alloca ptr
  %l46 = alloca { i64, [7 x i64] }
  %l50 = alloca %"compiler/mir:Range"
  %l54 = alloca %"compiler/mir:Range"
  %l58 = alloca %"compiler/mir:Lvalue"
  %l60 = alloca %"compiler/mir:Lvalue"
  %l68 = alloca %"compiler/mir:Call"
  %l69 = alloca i32
  %l79 = alloca { i64, [4 x i64] }
  %l82 = alloca %"compiler/mir:Lvalue"
  %s0 = alloca %olang.scope
  %rv = alloca { i64, [4 x i64] }
  %t37 = alloca { i64, [2 x i64] }, align 8
  %t86 = alloca { i64, [7 x i64] }, align 8
  %t144 = alloca { i64, [8 x i64] }, align 8
  %t164 = alloca { i64, [4 x i64] }, align 8
  %t171 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  store i32 %a5, ptr %l5
  store %"compiler/source:Span" %a6, ptr %l6
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l13, !tbaa !29
  %t5 = load i32, ptr %l1, !range !{i32 0, i32 10}
  %t6 = load i32, ptr %l2, !tbaa !23
  %t7 = load ptr, ptr %l13, !tbaa !29
  %t8 = call ptr @__olang_scope_or(ptr %v3, ptr %t7)
  %t9 = call ptr @__olang_scope_hold(ptr %t8)
  %t10 = ptrtoint ptr %t9 to i64
  %t12 = inttoptr i64 %t10 to ptr
  %t13 = load ptr, ptr %l13, !tbaa !29
  %t16 = call i32 @compiler_2flower_2ecompiler_2flower_3aLowerer_2ehelperTy(ptr %t12, ptr %t13, i32 %t5, i32 %t6)
  store i32 %t16, ptr %l17
  br label %bb1
bb1:
  %t17 = load i32, ptr %l17, !tbaa !23
  store i32 %t17, ptr %l2, !tbaa !23
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/lower:lowering", ptr %t18, i32 0, i32 2
  %t21 = load ptr, ptr %t20, !tbaa !29
  store ptr %t21, ptr %l19, !tbaa !29
  %t22 = load i32, ptr %l1, !range !{i32 0, i32 10}
  %t23 = load i32, ptr %l2, !tbaa !23
  %t24 = load ptr, ptr %l19, !tbaa !29
  %t25 = call ptr @__olang_scope_or(ptr %v4, ptr %t24)
  %t26 = call ptr @__olang_scope_hold(ptr %t25)
  %t27 = ptrtoint ptr %t26 to i64
  %t29 = inttoptr i64 %t27 to ptr
  %t30 = load ptr, ptr %l19, !tbaa !29
  %t33 = call i32 @compiler_2fmir_2eHelperType(ptr %t29, ptr %t30, i32 %t22, i32 %t23)
  store i32 %t33, ptr %l23
  br label %bb2
bb2:
  %t34 = load i32, ptr %l23, !tbaa !23
  store i32 %t34, ptr %l7, !tbaa !23
  %t35 = load i32, ptr %l1, !range !{i32 0, i32 10}
  %t36 = load i32, ptr %l2, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t37
  %t38 = getelementptr { i64, [2 x i64] }, ptr %t37, i32 0, i32 0
  store i64 3, ptr %t38
  %t40 = insertvalue { i32, i32 } undef, i32 %t35, 0
  %t42 = insertvalue { i32, i32 } %t40, i32 %t36, 1
  %t43 = getelementptr { i64, [2 x i64] }, ptr %t37, i32 0, i32 1
  store { i32, i32 } %t42, ptr %t43
  %t44 = load { i64, [2 x i64] }, ptr %t37
  store { i64, [2 x i64] } %t44, ptr %l8
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/lower:lowering", ptr %t46, i32 0, i32 0
  %t49 = load ptr, ptr %t48, !tbaa !29
  store ptr %t49, ptr %l28, !tbaa !29
  %t50 = load { i64, [2 x i64] }, ptr %l8
  %t51 = load ptr, ptr %l28, !tbaa !29
  %t52 = call ptr @__olang_scope_or(ptr %v3, ptr %t51)
  %t53 = call ptr @__olang_scope_hold(ptr %t52)
  %t54 = ptrtoint ptr %t53 to i64
  %t56 = inttoptr i64 %t54 to ptr
  %t57 = load ptr, ptr %l28, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3aLowerer_2eWant(ptr %t56, ptr %t57, { i64, [2 x i64] } %t50)
  br label %bb3
bb3:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/lower:lowering", ptr %t59, i32 0, i32 3
  %t63 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t61)
  store i32 %t63, ptr %l33
  br label %bb4
bb4:
  %t64 = load i32, ptr %l33, !tbaa !23
  store i32 %t64, ptr %l9, !tbaa !23
  %t65 = load i32, ptr @G_2ecompiler_2fmir_2eNoLocal, !tbaa !23
  store i32 %t65, ptr %l10, !tbaa !23
  %t67 = load i32, ptr %l5, !tbaa !23
  %t68 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t71 = icmp ne i32 %t67, %t68
  br i1 %t71, label %bb5, label %bb6
bb5:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t74 = load i32, ptr %l5, !tbaa !23
  %t75 = load %"compiler/source:Span", ptr %l6
  %t79 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2etemp(ptr %v0, ptr %t73, i32 %t74, %"compiler/source:Span" %t75)
  store i32 %t79, ptr %l41
  br label %bb7
bb6:
  br label %bb8
bb7:
  %t80 = load i32, ptr %l41, !tbaa !23
  store i32 %t80, ptr %l10, !tbaa !23
  br label %bb8
bb8:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"compiler/lower:lowering", ptr %t81, i32 0, i32 3
  store ptr %t83, ptr %l43, !tbaa !29
  %t84 = load { i64, [2 x i64] }, ptr %l8
  %t85 = load i32, ptr %l7, !tbaa !23
  store { i64, [7 x i64] } zeroinitializer, ptr %t86
  %t87 = getelementptr { i64, [7 x i64] }, ptr %t86, i32 0, i32 0
  store i64 0, ptr %t87
  %t89 = insertvalue { { i64, [2 x i64] }, i32 } undef, { i64, [2 x i64] } %t84, 0
  %t91 = insertvalue { { i64, [2 x i64] }, i32 } %t89, i32 %t85, 1
  %t92 = getelementptr { i64, [7 x i64] }, ptr %t86, i32 0, i32 1
  store { { i64, [2 x i64] }, i32 } %t91, ptr %t92
  %t93 = load { i64, [7 x i64] }, ptr %t86
  store { i64, [7 x i64] } %t93, ptr %l46
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t96 = getelementptr %"compiler/lower:lowering", ptr %t94, i32 0, i32 3
  %t100 = call %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eArgs(ptr %v0, ptr %v1, ptr %t96, { i64, ptr } %a3)
  store %"compiler/mir:Range" %t100, ptr %l50
  br label %bb9
bb9:
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t103 = getelementptr %"compiler/lower:lowering", ptr %t101, i32 0, i32 3
  %t107 = call %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eScopeRefs(ptr %v0, ptr %v2, ptr %t103, { i64, ptr } %a4)
  store %"compiler/mir:Range" %t107, ptr %l54
  br label %bb10
bb10:
  %t108 = load i32, ptr %l10, !tbaa !23
  %t109 = load i32, ptr @G_2ecompiler_2fmir_2eNoLocal, !tbaa !23
  %t112 = icmp ne i32 %t108, %t109
  br i1 %t112, label %bb11, label %bb12
bb11:
  %t114 = load i32, ptr %l10, !tbaa !23
  %t116 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t114)
  store %"compiler/mir:Lvalue" %t116, ptr %l60
  br label %bb13
bb12:
  %t117 = load %"compiler/mir:Lvalue", ptr @G_2ecompiler_2fmir_2eNoPlace
  store %"compiler/mir:Lvalue" %t117, ptr %l58
  br label %bb14
bb13:
  %t119 = load %"compiler/mir:Lvalue", ptr %l60
  store %"compiler/mir:Lvalue" %t119, ptr %l58
  br label %bb14
bb14:
  %t120 = load i32, ptr %l10, !tbaa !23
  %t121 = load i32, ptr @G_2ecompiler_2fmir_2eNoLocal, !tbaa !23
  %t124 = icmp ne i32 %t120, %t121
  %t125 = load i32, ptr %l9, !tbaa !23
  %t126 = load i32, ptr @G_2ecompiler_2fmir_2eNoLocal, !tbaa !23
  %t127 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t128 = load { i64, [7 x i64] }, ptr %l46
  %t129 = load %"compiler/mir:Range", ptr %l50
  %t130 = load %"compiler/mir:Range", ptr %l54
  %t131 = load %"compiler/mir:Lvalue", ptr %l58
  %t136 = call %"compiler/mir:Call" @compiler_2fmir_3aCall_2ector(ptr %s0, { i64, [7 x i64] } %t128, %"compiler/mir:Range" %t129, %"compiler/mir:Range" %t130, %"compiler/mir:Lvalue" %t131, i1 %t124, i32 %t125, i32 %t126, i32 %t127)
  store %"compiler/mir:Call" %t136, ptr %l68
  br label %bb15
bb15:
  %t137 = load ptr, ptr %l43, !tbaa !29
  %t138 = load %"compiler/mir:Call", ptr %l68
  %t139 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddCall(ptr %v0, ptr %t137, %"compiler/mir:Call" %t138)
  store i32 %t139, ptr %l69
  br label %bb16
bb16:
  %t140 = load i32, ptr %l69, !tbaa !23
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t142 = load %"compiler/source:Span", ptr %l6
  store { i64, [8 x i64] } zeroinitializer, ptr %t144
  %t145 = getelementptr { i64, [8 x i64] }, ptr %t144, i32 0, i32 0
  store i64 4, ptr %t145
  %t147 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t142, 0
  %t149 = insertvalue { %"compiler/source:Span", i32 } %t147, i32 %t140, 1
  %t150 = getelementptr { i64, [8 x i64] }, ptr %t144, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t149, ptr %t150
  %t151 = load { i64, [8 x i64] }, ptr %t144
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %v3, ptr %v4, ptr %t141, { i64, [8 x i64] } %t151)
  br label %bb17
bb17:
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t155 = load i32, ptr %l9, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t154, i32 %t155)
  br label %bb18
bb18:
  %t158 = load i32, ptr %l10, !tbaa !23
  %t159 = load i32, ptr @G_2ecompiler_2fmir_2eNoLocal, !tbaa !23
  %t162 = icmp eq i32 %t158, %t159
  br i1 %t162, label %bb19, label %bb20
bb19:
  store { i64, [4 x i64] } zeroinitializer, ptr %t164
  %t165 = getelementptr { i64, [4 x i64] }, ptr %t164, i32 0, i32 0
  store i64 0, ptr %t165
  %t166 = load { i64, [4 x i64] }, ptr %t164
  store { i64, [4 x i64] } %t166, ptr %l79
  br label %bb22
bb20:
  %t168 = load i32, ptr %l10, !tbaa !23
  %t170 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t168)
  store %"compiler/mir:Lvalue" %t170, ptr %l82
  br label %bb21
bb21:
  store { i64, [4 x i64] } zeroinitializer, ptr %t171
  %t172 = getelementptr { i64, [4 x i64] }, ptr %t171, i32 0, i32 0
  store i64 1, ptr %t172
  %t173 = load %"compiler/mir:Lvalue", ptr %l82
  %t174 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t173, 0
  %t175 = getelementptr { i64, [4 x i64] }, ptr %t171, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t174, ptr %t175
  %t176 = load { i64, [4 x i64] }, ptr %t171
  store { i64, [4 x i64] } %t176, ptr %l79
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s0)
  %t178 = load { i64, [4 x i64] }, ptr %l79
  store { i64, [4 x i64] } %t178, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local { { i64, [7 x i64] }, i32 } @compiler_2flower_2ecompiler_2flower_3alowering_2ehelperCallee(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca i32
  %l7 = alloca i32
  %l11 = alloca ptr
  %l15 = alloca i32
  %l17 = alloca ptr
  %l21 = alloca i32
  %l23 = alloca ptr
  %rv = alloca { { i64, [7 x i64] }, i32 }
  %t49 = alloca { i64, [2 x i64] }, align 8
  %t67 = alloca { i64, [2 x i64] }, align 8
  %t76 = alloca { i64, [7 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t3 = trunc i64 0 to i32
  %t4 = icmp eq i32 %a1, %t3
  br i1 %t4, label %bb1, label %bb2
bb1:
  store i32 1, ptr %l7
  br label %bb3
bb2:
  store i32 2, ptr %l7
  br label %bb3
bb3:
  %t8 = load i32, ptr %l7, !range !{i32 0, i32 10}
  store i32 %t8, ptr %l3
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/lower:lowering", ptr %t9, i32 0, i32 0
  %t12 = load ptr, ptr %t11, !tbaa !29
  store ptr %t12, ptr %l11, !tbaa !29
  %t13 = load i32, ptr %l3, !range !{i32 0, i32 10}
  %t14 = load i32, ptr %l2, !tbaa !23
  %t15 = load ptr, ptr %l11, !tbaa !29
  %t16 = call ptr @__olang_scope_or(ptr %v1, ptr %t15)
  %t17 = call ptr @__olang_scope_hold(ptr %t16)
  %t18 = ptrtoint ptr %t17 to i64
  %t20 = inttoptr i64 %t18 to ptr
  %t21 = load ptr, ptr %l11, !tbaa !29
  %t24 = call i32 @compiler_2flower_2ecompiler_2flower_3aLowerer_2ehelperTy(ptr %t20, ptr %t21, i32 %t13, i32 %t14)
  store i32 %t24, ptr %l15
  br label %bb4
bb4:
  %t25 = load i32, ptr %l15, !tbaa !23
  store i32 %t25, ptr %l2, !tbaa !23
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/lower:lowering", ptr %t26, i32 0, i32 2
  %t29 = load ptr, ptr %t28, !tbaa !29
  store ptr %t29, ptr %l17, !tbaa !29
  %t30 = load i32, ptr %l3, !range !{i32 0, i32 10}
  %t31 = load i32, ptr %l2, !tbaa !23
  %t32 = load ptr, ptr %l17, !tbaa !29
  %t33 = call ptr @__olang_scope_or(ptr %v2, ptr %t32)
  %t34 = call ptr @__olang_scope_hold(ptr %t33)
  %t35 = ptrtoint ptr %t34 to i64
  %t37 = inttoptr i64 %t35 to ptr
  %t38 = load ptr, ptr %l17, !tbaa !29
  %t41 = call i32 @compiler_2fmir_2eHelperType(ptr %t37, ptr %t38, i32 %t30, i32 %t31)
  store i32 %t41, ptr %l21
  br label %bb5
bb5:
  %t42 = load i32, ptr %l21, !tbaa !23
  store i32 %t42, ptr %l4, !tbaa !23
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/lower:lowering", ptr %t43, i32 0, i32 0
  %t46 = load ptr, ptr %t45, !tbaa !29
  store ptr %t46, ptr %l23, !tbaa !29
  %t47 = load i32, ptr %l3, !range !{i32 0, i32 10}
  %t48 = load i32, ptr %l2, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t49
  %t50 = getelementptr { i64, [2 x i64] }, ptr %t49, i32 0, i32 0
  store i64 3, ptr %t50
  %t52 = insertvalue { i32, i32 } undef, i32 %t47, 0
  %t54 = insertvalue { i32, i32 } %t52, i32 %t48, 1
  %t55 = getelementptr { i64, [2 x i64] }, ptr %t49, i32 0, i32 1
  store { i32, i32 } %t54, ptr %t55
  %t56 = load { i64, [2 x i64] }, ptr %t49
  %t57 = load ptr, ptr %l23, !tbaa !29
  %t58 = call ptr @__olang_scope_or(ptr %v1, ptr %t57)
  %t59 = call ptr @__olang_scope_hold(ptr %t58)
  %t60 = ptrtoint ptr %t59 to i64
  %t62 = inttoptr i64 %t60 to ptr
  %t63 = load ptr, ptr %l23, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3aLowerer_2eWant(ptr %t62, ptr %t63, { i64, [2 x i64] } %t56)
  br label %bb6
bb6:
  %t65 = load i32, ptr %l3, !range !{i32 0, i32 10}
  %t66 = load i32, ptr %l2, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t67
  %t68 = getelementptr { i64, [2 x i64] }, ptr %t67, i32 0, i32 0
  store i64 3, ptr %t68
  %t70 = insertvalue { i32, i32 } undef, i32 %t65, 0
  %t72 = insertvalue { i32, i32 } %t70, i32 %t66, 1
  %t73 = getelementptr { i64, [2 x i64] }, ptr %t67, i32 0, i32 1
  store { i32, i32 } %t72, ptr %t73
  %t74 = load { i64, [2 x i64] }, ptr %t67
  %t75 = load i32, ptr %l4, !tbaa !23
  store { i64, [7 x i64] } zeroinitializer, ptr %t76
  %t77 = getelementptr { i64, [7 x i64] }, ptr %t76, i32 0, i32 0
  store i64 0, ptr %t77
  %t79 = insertvalue { { i64, [2 x i64] }, i32 } undef, { i64, [2 x i64] } %t74, 0
  %t81 = insertvalue { { i64, [2 x i64] }, i32 } %t79, i32 %t75, 1
  %t82 = getelementptr { i64, [7 x i64] }, ptr %t76, i32 0, i32 1
  store { { i64, [2 x i64] }, i32 } %t81, ptr %t82
  %t83 = load { i64, [7 x i64] }, ptr %t76
  %t84 = load i32, ptr %l4, !tbaa !23
  %t86 = insertvalue { { i64, [7 x i64] }, i32 } undef, { i64, [7 x i64] } %t83, 0
  %t88 = insertvalue { { i64, [7 x i64] }, i32 } %t86, i32 %t84, 1
  store { { i64, [7 x i64] }, i32 } %t88, ptr %rv
  br label %ret
ret:
  %rr = load { { i64, [7 x i64] }, i32 }, ptr %rv
  ret { { i64, [7 x i64] }, i32 } %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2ehoistAll(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, { i64, [4 x i64] } %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l1 = alloca ptr
  %l4 = alloca ptr
  %l11 = alloca { i64, ptr }
  %l13 = alloca { i64, [4 x i64] }
  %s0 = alloca %olang.scope
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  %t3 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t4 = load ptr, ptr %l1, !tbaa !29
  %t6 = getelementptr %"compiler/lower:hoistWalk", ptr %t4, i32 0, i32 7
  %t7 = load { i64, [4 x i64] }, ptr %t6
  %t9 = mul i64 2, 40
  %t10 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t9)
  %t11 = insertvalue { i64, ptr } undef, i64 2, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l11, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = getelementptr { i64, [4 x i64] }, ptr %t15, i64 0
  store { i64, [4 x i64] } %t7, ptr %t16
  %t18 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr { i64, [4 x i64] }, ptr %t19, i64 1
  store { i64, [4 x i64] } %a2, ptr %t20
  %t25 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t27 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s0, ptr %v2, ptr %v3, ptr %a0, i32 10, i32 %t3, { i64, ptr } %t25, %"compiler/source:Span" %a3)
  store { i64, [4 x i64] } %t27, ptr %l13
  br label %bb1
bb1:
  %t28 = load { i64, [4 x i64] }, ptr %l13
  %t29 = load ptr, ptr %l4, !tbaa !29
  %t30 = getelementptr %"compiler/lower:hoistWalk", ptr %t29, i32 0, i32 7
  store { i64, [4 x i64] } %t28, ptr %t30
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2ehoistPlace(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %v6, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i1
  %l11 = alloca ptr
  %l12 = alloca i1
  %l15 = alloca ptr
  %l16 = alloca i1
  %l19 = alloca ptr
  %l20 = alloca i1
  %l28 = alloca ptr
  %l29 = alloca i1
  %l37 = alloca ptr
  %l38 = alloca i1
  %l46 = alloca ptr
  %l47 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  store ptr %t1, ptr %l7, !tbaa !29
  store i1 false, ptr %l8, !tbaa !21
  %t2 = load ptr, ptr %l7, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l7, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l8, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l8, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb13
bb4:
  %t10 = load ptr, ptr %l2, !tbaa !29
  store ptr %t10, ptr %l11, !tbaa !29
  store i1 false, ptr %l12, !tbaa !21
  %t11 = load ptr, ptr %l11, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb5, label %bb6
bb5:
  %t14 = load ptr, ptr %l11, !tbaa !29
  %t15 = load i64, ptr %t14, !range !{i64 0, i64 8}
  %t17 = icmp eq i64 %t15, 1
  store i1 %t17, ptr %l12, !tbaa !21
  br label %bb6
bb6:
  %t18 = load i1, ptr %l12, !tbaa !21
  br i1 %t18, label %bb7, label %bb8
bb7:
  br label %bb13
bb8:
  %t19 = load ptr, ptr %l2, !tbaa !29
  store ptr %t19, ptr %l15, !tbaa !29
  store i1 false, ptr %l16, !tbaa !21
  %t20 = load ptr, ptr %l15, !tbaa !29
  %t21 = icmp ne ptr %t20, null
  br i1 %t21, label %bb9, label %bb10
bb9:
  %t23 = load ptr, ptr %l15, !tbaa !29
  %t24 = load i64, ptr %t23, !range !{i64 0, i64 8}
  %t26 = icmp eq i64 %t24, 7
  store i1 %t26, ptr %l16, !tbaa !21
  br label %bb10
bb10:
  %t27 = load i1, ptr %l16, !tbaa !21
  br i1 %t27, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb48
bb14:
  %t28 = load ptr, ptr %l2, !tbaa !29
  store ptr %t28, ptr %l19, !tbaa !29
  store i1 false, ptr %l20, !tbaa !21
  %t29 = load ptr, ptr %l19, !tbaa !29
  %t30 = icmp ne ptr %t29, null
  br i1 %t30, label %bb15, label %bb16
bb15:
  %t32 = load ptr, ptr %l19, !tbaa !29
  %t33 = load i64, ptr %t32, !range !{i64 0, i64 8}
  %t35 = icmp eq i64 %t33, 2
  store i1 %t35, ptr %l20, !tbaa !21
  br label %bb16
bb16:
  %t36 = load i1, ptr %l20, !tbaa !21
  br i1 %t36, label %bb17, label %bb18
bb17:
  %t37 = load ptr, ptr %l2, !tbaa !29
  %t39 = getelementptr { i64, [4 x i64] }, ptr %t37, i32 0, i32 1
  %t40 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t39, i32 0, i32 2
  %t41 = load ptr, ptr %t40
  store ptr %t41, ptr %l3, !tbaa !29
  br label %bb19
bb18:
  br label %bb21
bb19:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t44 = load ptr, ptr %l1, !tbaa !29
  %t45 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2ehoistExpr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %v6, ptr %t43, ptr %t44, ptr %t45)
  br label %bb20
bb20:
  br label %bb48
bb21:
  %t49 = load ptr, ptr %l2, !tbaa !29
  store ptr %t49, ptr %l28, !tbaa !29
  store i1 false, ptr %l29, !tbaa !21
  %t50 = load ptr, ptr %l28, !tbaa !29
  %t51 = icmp ne ptr %t50, null
  br i1 %t51, label %bb22, label %bb23
bb22:
  %t53 = load ptr, ptr %l28, !tbaa !29
  %t54 = load i64, ptr %t53, !range !{i64 0, i64 8}
  %t56 = icmp eq i64 %t54, 3
  store i1 %t56, ptr %l29, !tbaa !21
  br label %bb23
bb23:
  %t57 = load i1, ptr %l29, !tbaa !21
  br i1 %t57, label %bb24, label %bb25
bb24:
  %t58 = load ptr, ptr %l2, !tbaa !29
  %t60 = getelementptr { i64, [4 x i64] }, ptr %t58, i32 0, i32 1
  %t61 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t60, i32 0, i32 2
  %t62 = load ptr, ptr %t61
  store ptr %t62, ptr %l4, !tbaa !29
  br label %bb26
bb25:
  br label %bb28
bb26:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t65 = load ptr, ptr %l1, !tbaa !29
  %t66 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2ehoistPlace(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %v6, ptr %t64, ptr %t65, ptr %t66)
  br label %bb27
bb27:
  br label %bb48
bb28:
  %t70 = load ptr, ptr %l2, !tbaa !29
  store ptr %t70, ptr %l37, !tbaa !29
  store i1 false, ptr %l38, !tbaa !21
  %t71 = load ptr, ptr %l37, !tbaa !29
  %t72 = icmp ne ptr %t71, null
  br i1 %t72, label %bb29, label %bb30
bb29:
  %t74 = load ptr, ptr %l37, !tbaa !29
  %t75 = load i64, ptr %t74, !range !{i64 0, i64 8}
  %t77 = icmp eq i64 %t75, 6
  store i1 %t77, ptr %l38, !tbaa !21
  br label %bb30
bb30:
  %t78 = load i1, ptr %l38, !tbaa !21
  br i1 %t78, label %bb31, label %bb32
bb31:
  %t79 = load ptr, ptr %l2, !tbaa !29
  %t81 = getelementptr { i64, [4 x i64] }, ptr %t79, i32 0, i32 1
  %t82 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t81, i32 0, i32 2
  %t83 = load ptr, ptr %t82
  store ptr %t83, ptr %l5, !tbaa !29
  br label %bb33
bb32:
  br label %bb35
bb33:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t86 = load ptr, ptr %l1, !tbaa !29
  %t87 = load ptr, ptr %l5, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2ehoistExpr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %v6, ptr %t85, ptr %t86, ptr %t87)
  br label %bb34
bb34:
  br label %bb48
bb35:
  %t91 = load ptr, ptr %l2, !tbaa !29
  store ptr %t91, ptr %l46, !tbaa !29
  store i1 false, ptr %l47, !tbaa !21
  %t92 = load ptr, ptr %l46, !tbaa !29
  %t93 = icmp ne ptr %t92, null
  br i1 %t93, label %bb36, label %bb37
bb36:
  %t95 = load ptr, ptr %l46, !tbaa !29
  %t96 = load i64, ptr %t95, !range !{i64 0, i64 8}
  %t98 = icmp eq i64 %t96, 4
  store i1 %t98, ptr %l47, !tbaa !21
  br label %bb37
bb37:
  %t99 = load i1, ptr %l47, !tbaa !21
  br i1 %t99, label %bb38, label %bb39
bb38:
  %t100 = load ptr, ptr %l2, !tbaa !29
  %t102 = getelementptr { i64, [4 x i64] }, ptr %t100, i32 0, i32 1
  %t103 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t102, i32 0, i32 2
  %t104 = load ptr, ptr %t103
  store ptr %t104, ptr %l6, !tbaa !29
  br label %bb40
bb39:
  br label %bb43
bb40:
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t107 = load ptr, ptr %l1, !tbaa !29
  %t108 = load ptr, ptr %l6, !tbaa !29
  %t110 = getelementptr %"compiler/typed:Elem", ptr %t108, i32 0, i32 0
  %t111 = load ptr, ptr %t110, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2ehoistPlace(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %v6, ptr %t106, ptr %t107, ptr %t111)
  br label %bb41
bb41:
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t116 = load ptr, ptr %l1, !tbaa !29
  %t117 = load ptr, ptr %l6, !tbaa !29
  %t119 = getelementptr %"compiler/typed:Elem", ptr %t117, i32 0, i32 1
  %t120 = load ptr, ptr %t119, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2ehoistExpr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %v6, ptr %t115, ptr %t116, ptr %t120)
  br label %bb42
bb42:
  br label %bb48
bb43:
  br i1 true, label %bb44, label %bb45
bb44:
  br label %bb46
bb45:
  br label %bb47
bb46:
  %t124 = load ptr, ptr %l1, !tbaa !29
  %t126 = getelementptr %"compiler/lower:hoistWalk", ptr %t124, i32 0, i32 2
  store i1 false, ptr %t126, !tbaa !21
  br label %bb48
bb47:
  call void @__olang_check_failed(ptr @olang_loc_4a3d2c0d7af401cb_af9e757c5227be3f)
  unreachable
bb48:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2ehoistStmts(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %v6, ptr %a0, ptr %a1, { i64, ptr } %a2) #0 {
entry:
  %l1 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca ptr
  %l14 = alloca { i64, ptr }
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a2, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l5, !tbaa !24
  br label %bb1
bb1:
  %t7 = load i64, ptr %l4, !tbaa !24
  %t8 = load i64, ptr %l5, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  br label %bb10
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t15, ptr %l14, !tbaa !27
  %t16 = load i64, ptr %l4, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr ptr, ptr %t19, i64 %t16
  %t21 = load ptr, ptr %t20, !tbaa !39
  store ptr %t21, ptr %l6, !tbaa !29
  %t23 = load ptr, ptr %l1, !tbaa !29
  %t25 = getelementptr %"compiler/lower:hoistWalk", ptr %t23, i32 0, i32 2
  %t26 = load i1, ptr %t25, !tbaa !21
  %t28 = xor i1 %t26, true
  br i1 %t28, label %bb5, label %bb6
bb5:
  br label %ret
bb6:
  br label %bb7
bb7:
  %t31 = load ptr, ptr %l1, !tbaa !29
  %t32 = load ptr, ptr %l6, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2ehoistStmt(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %v6, ptr %a0, ptr %t31, ptr %t32)
  br label %bb8
bb8:
  br label %bb9
bb9:
  %t36 = load i64, ptr %l4, !tbaa !24
  %t39 = add i64 %t36, 1
  store i64 %t39, ptr %l4, !tbaa !24
  br label %bb1
bb10:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2ehoistTarget(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %v6, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca i1
  %l10 = alloca ptr
  %l11 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t4 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v2, ptr %t2)
  store i32 %t4, ptr %l6
  br label %bb1
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i32, ptr %l6, !tbaa !23
  %t7 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eisScalar(ptr %v0, ptr %v3, ptr %t5, i32 %t6)
  store i1 %t7, ptr %l7
  br label %bb2
bb2:
  %t8 = load i1, ptr %l7, !tbaa !21
  %t9 = xor i1 %t8, true
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t11 = load ptr, ptr %l1, !tbaa !29
  %t13 = getelementptr %"compiler/lower:hoistWalk", ptr %t11, i32 0, i32 2
  store i1 false, ptr %t13, !tbaa !21
  br label %ret
bb4:
  br label %bb5
bb5:
  %t14 = load ptr, ptr %l2, !tbaa !29
  store ptr %t14, ptr %l10, !tbaa !29
  store i1 false, ptr %l11, !tbaa !21
  %t15 = load ptr, ptr %l10, !tbaa !29
  %t16 = icmp ne ptr %t15, null
  br i1 %t16, label %bb6, label %bb7
bb6:
  %t18 = load ptr, ptr %l10, !tbaa !29
  %t19 = load i64, ptr %t18, !range !{i64 0, i64 8}
  %t21 = icmp eq i64 %t19, 0
  store i1 %t21, ptr %l11, !tbaa !21
  br label %bb7
bb7:
  %t22 = load i1, ptr %l11, !tbaa !21
  br i1 %t22, label %bb8, label %bb9
bb8:
  %t23 = load ptr, ptr %l2, !tbaa !29
  %t25 = getelementptr { i64, [4 x i64] }, ptr %t23, i32 0, i32 1
  %t26 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t25, i32 0, i32 2
  %t27 = load i32, ptr %t26
  store i32 %t27, ptr %l3, !tbaa !23
  br label %bb10
bb9:
  br label %bb12
bb10:
  %t29 = load ptr, ptr %l1, !tbaa !29
  %t31 = getelementptr %"compiler/lower:hoistWalk", ptr %t29, i32 0, i32 3
  %t32 = load i32, ptr %l3, !tbaa !23
  %t34 = sext i32 %t32 to i64
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v1, ptr %t31, i64 %t34, i1 true)
  br label %bb11
bb11:
  br label %bb18
bb12:
  br i1 true, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb17
bb15:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load ptr, ptr %l1, !tbaa !29
  %t39 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2ehoistPlace(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %v6, ptr %t37, ptr %t38, ptr %t39)
  br label %bb16
bb16:
  br label %bb18
bb17:
  call void @__olang_check_failed(ptr @olang_loc_da93e14155b6d1b5_224c74a94b128e51)
  unreachable
bb18:
  br label %ret
ret:
  ret void
}

define dso_local { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, { i64, [15 x i64] } %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca i32
  %l8 = alloca i32
  %l9 = alloca ptr
  %l10 = alloca %"compiler/source:Span"
  %l12 = alloca %"compiler/mir:Lvalue"
  %l17 = alloca %"compiler/mir:Lvalue"
  %s0 = alloca %olang.scope
  %rv = alloca { i64, [4 x i64] }
  %t15 = alloca { i64, [21 x i64] }, align 8
  %t32 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = load %"compiler/source:Span", ptr %l3
  %t7 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2etemp(ptr %v0, ptr %t1, i32 %a1, %"compiler/source:Span" %t3)
  store i32 %t7, ptr %l8
  br label %bb1
bb1:
  %t8 = load i32, ptr %l8, !tbaa !23
  store i32 %t8, ptr %l4, !tbaa !23
  %t9 = load ptr, ptr %l0, !tbaa !29
  store ptr %t9, ptr %l9, !tbaa !29
  %t10 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t10, ptr %l10
  %t11 = load i32, ptr %l4, !tbaa !23
  %t13 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t11)
  store %"compiler/mir:Lvalue" %t13, ptr %l12
  br label %bb2
bb2:
  store { i64, [21 x i64] } zeroinitializer, ptr %t15
  %t16 = getelementptr { i64, [21 x i64] }, ptr %t15, i32 0, i32 0
  store i64 0, ptr %t16
  %t17 = load %"compiler/source:Span", ptr %l10
  %t18 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t17, 0
  %t19 = load %"compiler/mir:Lvalue", ptr %l12
  %t20 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t18, %"compiler/mir:Lvalue" %t19, 1
  %t22 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t20, { i64, [15 x i64] } %a2, 2
  %t23 = getelementptr { i64, [21 x i64] }, ptr %t15, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t22, ptr %t23
  %t24 = load { i64, [21 x i64] }, ptr %t15
  %t26 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t24, ptr %t26
  %t27 = load ptr, ptr %l9, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s0, ptr %v1, ptr %v2, ptr %t27, ptr %t26)
  br label %bb3
bb3:
  %t29 = load i32, ptr %l4, !tbaa !23
  %t31 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t29)
  store %"compiler/mir:Lvalue" %t31, ptr %l17
  br label %bb4
bb4:
  store { i64, [4 x i64] } zeroinitializer, ptr %t32
  %t33 = getelementptr { i64, [4 x i64] }, ptr %t32, i32 0, i32 0
  store i64 1, ptr %t33
  %t34 = load %"compiler/mir:Lvalue", ptr %l17
  %t35 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t34, 0
  %t36 = getelementptr { i64, [4 x i64] }, ptr %t32, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t35, ptr %t36
  %t37 = load { i64, [4 x i64] }, ptr %t32
  call void @__olang_scope_close(ptr %s0)
  store { i64, [4 x i64] } %t37, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eisScalar(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l4 = alloca ptr
  %l6 = alloca ptr
  %l9 = alloca i32
  %l11 = alloca i32
  %l12 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/lower:lowering", ptr %t5, i32 0, i32 2
  %t8 = load ptr, ptr %t7, !tbaa !29
  store ptr %t8, ptr %l6, !tbaa !29
  %t10 = load ptr, ptr %l6, !tbaa !29
  %t11 = call ptr @__olang_scope_or(ptr %v1, ptr %t10)
  %t12 = call ptr @__olang_scope_hold(ptr %t11)
  %t13 = ptrtoint ptr %t12 to i64
  %t15 = inttoptr i64 %t13 to ptr
  %t16 = load ptr, ptr %l6, !tbaa !29
  %t18 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %t15, ptr %t16, i32 %a1)
  store i32 %t18, ptr %l9
  br label %bb1
bb1:
  %t19 = load ptr, ptr %l4, !tbaa !29
  %t20 = call ptr @__olang_scope_or(ptr %v1, ptr %t19)
  %t21 = call ptr @__olang_scope_hold(ptr %t20)
  %t22 = ptrtoint ptr %t21 to i64
  %t24 = inttoptr i64 %t22 to ptr
  %t25 = load ptr, ptr %l4, !tbaa !29
  %t26 = load i32, ptr %l9, !tbaa !23
  %t27 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %t24, ptr %t25, i32 %t26)
  store i32 %t27, ptr %l11
  br label %bb2
bb2:
  %t28 = load i32, ptr %l11, !range !{i32 0, i32 33}
  store i32 %t28, ptr %l2
  %t29 = load i32, ptr %l2, !range !{i32 0, i32 33}
  %t31 = trunc i64 2 to i32
  %t32 = icmp eq i32 %t29, %t31
  br i1 %t32, label %bb3, label %bb4
bb3:
  br label %bb17
bb4:
  %t34 = load i32, ptr %l2, !range !{i32 0, i32 33}
  %t36 = trunc i64 3 to i32
  %t37 = icmp eq i32 %t34, %t36
  br i1 %t37, label %bb5, label %bb6
bb5:
  br label %bb17
bb6:
  %t39 = load i32, ptr %l2, !range !{i32 0, i32 33}
  %t41 = trunc i64 4 to i32
  %t42 = icmp eq i32 %t39, %t41
  br i1 %t42, label %bb7, label %bb8
bb7:
  br label %bb17
bb8:
  %t44 = load i32, ptr %l2, !range !{i32 0, i32 33}
  %t46 = trunc i64 5 to i32
  %t47 = icmp eq i32 %t44, %t46
  br i1 %t47, label %bb9, label %bb10
bb9:
  br label %bb17
bb10:
  %t49 = load i32, ptr %l2, !range !{i32 0, i32 33}
  %t51 = trunc i64 6 to i32
  %t52 = icmp eq i32 %t49, %t51
  br i1 %t52, label %bb11, label %bb12
bb11:
  br label %bb17
bb12:
  %t54 = load i32, ptr %l2, !range !{i32 0, i32 33}
  %t56 = trunc i64 7 to i32
  %t57 = icmp eq i32 %t54, %t56
  br i1 %t57, label %bb13, label %bb14
bb13:
  br label %bb17
bb14:
  %t59 = load i32, ptr %l2, !range !{i32 0, i32 33}
  %t61 = trunc i64 8 to i32
  %t62 = icmp eq i32 %t59, %t61
  br i1 %t62, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb18
bb17:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb37
bb18:
  %t64 = load i32, ptr %l2, !range !{i32 0, i32 33}
  %t66 = trunc i64 9 to i32
  %t67 = icmp eq i32 %t64, %t66
  br i1 %t67, label %bb19, label %bb20
bb19:
  br label %bb31
bb20:
  %t69 = load i32, ptr %l2, !range !{i32 0, i32 33}
  %t71 = trunc i64 10 to i32
  %t72 = icmp eq i32 %t69, %t71
  br i1 %t72, label %bb21, label %bb22
bb21:
  br label %bb31
bb22:
  %t74 = load i32, ptr %l2, !range !{i32 0, i32 33}
  %t76 = trunc i64 11 to i32
  %t77 = icmp eq i32 %t74, %t76
  br i1 %t77, label %bb23, label %bb24
bb23:
  br label %bb31
bb24:
  %t79 = load i32, ptr %l2, !range !{i32 0, i32 33}
  %t81 = trunc i64 12 to i32
  %t82 = icmp eq i32 %t79, %t81
  br i1 %t82, label %bb25, label %bb26
bb25:
  br label %bb31
bb26:
  %t84 = load i32, ptr %l2, !range !{i32 0, i32 33}
  %t86 = trunc i64 13 to i32
  %t87 = icmp eq i32 %t84, %t86
  br i1 %t87, label %bb27, label %bb28
bb27:
  br label %bb31
bb28:
  %t89 = load i32, ptr %l2, !range !{i32 0, i32 33}
  %t91 = trunc i64 14 to i32
  %t92 = icmp eq i32 %t89, %t91
  br i1 %t92, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb32
bb31:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb37
bb32:
  br i1 true, label %bb33, label %bb34
bb33:
  br label %bb35
bb34:
  br label %bb36
bb35:
  store i1 false, ptr %l12, !tbaa !21
  br label %bb37
bb36:
  call void @__olang_check_failed(ptr @olang_loc_bf8241b95bfd56f9_9ba7c89c1dae0c65)
  unreachable
bb37:
  %t94 = load i1, ptr %l12, !tbaa !21
  store i1 %t94, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2flower_2ecompiler_2flower_3alowering_2eitems(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l11 = alloca ptr
  %l17 = alloca { i64, ptr }
  %l19 = alloca i64
  %l28 = alloca i64
  %l31 = alloca i64
  %l40 = alloca i64
  %l43 = alloca i1
  %l54 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l11, !tbaa !29
  %t6 = load ptr, ptr %l11, !tbaa !29
  %t7 = call ptr @__olang_scope_or(ptr %v2, ptr %t6)
  %t8 = call ptr @__olang_scope_hold(ptr %t7)
  %t9 = ptrtoint ptr %t8 to i64
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/lower:lowering", ptr %t10, i32 0, i32 2
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t15 = call ptr @__olang_scope_or(ptr %v2, ptr %t13)
  %t16 = call ptr @__olang_scope_hold(ptr %t15)
  %t17 = ptrtoint ptr %t16 to i64
  %t19 = inttoptr i64 %t9 to ptr
  %t21 = inttoptr i64 %t17 to ptr
  %t22 = load ptr, ptr %l11, !tbaa !29
  %t24 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %t19, ptr %t21, ptr %t22, i32 %a1)
  store { i64, ptr } %t24, ptr %l17
  br label %bb1
bb1:
  %t25 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t25, ptr %l2, !tbaa !27
  %t26 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t28 = extractvalue { i64, ptr } %t26, 0
  store i64 %t28, ptr %l19, !tbaa !24
  %t29 = load i64, ptr %l19, !tbaa !24
  %t30 = icmp sge i64 %t29, 0
  br i1 %t30, label %bb2, label %bb3
bb2:
  %t32 = load i64, ptr %l19, !tbaa !24
  %t33 = icmp sle i64 %t32, 2305843009213693951
  br i1 %t33, label %bb4, label %bb5
bb3:
  call void @__olang_check_failed(ptr @olang_loc_fe6f132f471090d8_e27fa787bcbe9484)
  unreachable
bb4:
  %t35 = load i64, ptr %l19, !tbaa !24
  %t36 = mul i64 %t35, 4
  %t37 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t36)
  %t38 = insertvalue { i64, ptr } undef, i64 %t35, 0
  %t39 = insertvalue { i64, ptr } %t38, ptr %t37, 1
  store { i64, ptr } %t39, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t41 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t41, 0
  store i64 %t43, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t45 = load i64, ptr %l5, !tbaa !24
  %t46 = load i64, ptr %l4, !tbaa !24
  %t49 = icmp sgt i64 %t45, %t46
  br i1 %t49, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_fe6f132f471090d8_e27fa787bcbe9484)
  unreachable
bb6:
  %t51 = load i64, ptr %l6, !tbaa !24
  %t53 = icmp sgt i64 %t51, 0
  br i1 %t53, label %bb8, label %bb9
bb7:
  store i64 0, ptr %l28, !tbaa !24
  br label %bb11
bb8:
  %t55 = load i64, ptr %l5, !tbaa !24
  %t56 = load i64, ptr %l4, !tbaa !24
  %t59 = sub i64 %t55, %t56
  %t60 = load i64, ptr %l6, !tbaa !24
  %t63 = add i64 %t59, %t60
  %t65 = sub i64 %t63, 1
  %t66 = load i64, ptr %l6, !tbaa !24
  %t69 = sdiv i64 %t65, %t66
  store i64 %t69, ptr %l31, !tbaa !24
  br label %bb10
bb9:
  store i64 0, ptr %l31, !tbaa !24
  br label %bb10
bb10:
  %t71 = load i64, ptr %l31, !tbaa !24
  store i64 %t71, ptr %l28, !tbaa !24
  br label %bb11
bb11:
  %t72 = load i64, ptr %l28, !tbaa !24
  store i64 %t72, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  %t73 = load i64, ptr %l7, !tbaa !24
  %t74 = sub i64 %t73, 1
  store i64 %t74, ptr %l40, !tbaa !24
  %t75 = load i64, ptr %l7, !tbaa !24
  %t76 = icmp slt i64 %t75, 2147483648
  %t77 = load i64, ptr %l8, !tbaa !24
  %t78 = icmp sge i64 %t77, 0
  %t81 = and i1 %t76, %t78
  store i1 %t81, ptr %l43, !tbaa !21
  br label %bb12
bb12:
  %t82 = load i64, ptr %l8, !tbaa !24
  %t83 = load i64, ptr %l7, !tbaa !24
  %t86 = icmp slt i64 %t82, %t83
  %t88 = xor i1 %t86, true
  br i1 %t88, label %bb13, label %bb14
bb13:
  br label %bb17
bb14:
  br label %bb15
bb15:
  %t90 = load i64, ptr %l4, !tbaa !24
  %t91 = load i64, ptr %l8, !tbaa !24
  %t92 = load i64, ptr %l6, !tbaa !24
  %t95 = mul i64 %t91, %t92
  %t98 = add i64 %t90, %t95
  store i64 %t98, ptr %l9, !tbaa !24
  %t100 = load i64, ptr %l9, !tbaa !24
  %t101 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t101, ptr %l54, !tbaa !27
  %t102 = load i64, ptr %l9, !tbaa !24
  %t104 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t105 = load ptr, ptr %t104, !tbaa !27
  %t106 = getelementptr i32, ptr %t105, i64 %t102
  %t107 = load i32, ptr %t106, !tbaa !33
  %t110 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t111 = load ptr, ptr %t110, !tbaa !27
  %t112 = getelementptr i32, ptr %t111, i64 %t100
  store i32 %t107, ptr %t112, !tbaa !33
  br label %bb16
bb16:
  %t113 = load i64, ptr %l8, !tbaa !24
  %t116 = add i64 %t113, 1
  store i64 %t116, ptr %l8, !tbaa !24
  br label %bb12
bb17:
  %t118 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t118, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3alowering_2elaidApart(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca i32
  %l8 = alloca ptr
  %l11 = alloca i32
  %l12 = alloca ptr
  %l15 = alloca i32
  %l16 = alloca ptr
  %l19 = alloca i32
  %l22 = alloca i1
  %l23 = alloca ptr
  %l26 = alloca i32
  %l29 = alloca i1
  %l30 = alloca ptr
  %l33 = alloca i32
  %l35 = alloca i1
  %l36 = alloca ptr
  %l39 = alloca i32
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/lower:lowering", ptr %a0, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t6 = load ptr, ptr %l3, !tbaa !29
  store ptr %t6, ptr %l8, !tbaa !29
  %t8 = load ptr, ptr %l8, !tbaa !29
  %t9 = call ptr @__olang_scope_or(ptr %v1, ptr %t8)
  %t10 = call ptr @__olang_scope_hold(ptr %t9)
  %t11 = ptrtoint ptr %t10 to i64
  %t13 = inttoptr i64 %t11 to ptr
  %t14 = load ptr, ptr %l8, !tbaa !29
  %t16 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %t13, ptr %t14, i32 %a1)
  store i32 %t16, ptr %l11
  br label %bb1
bb1:
  %t17 = load i32, ptr %l11, !tbaa !23
  store i32 %t17, ptr %l4, !tbaa !23
  %t18 = load ptr, ptr %l3, !tbaa !29
  store ptr %t18, ptr %l12, !tbaa !29
  %t20 = load ptr, ptr %l12, !tbaa !29
  %t21 = call ptr @__olang_scope_or(ptr %v1, ptr %t20)
  %t22 = call ptr @__olang_scope_hold(ptr %t21)
  %t23 = ptrtoint ptr %t22 to i64
  %t25 = inttoptr i64 %t23 to ptr
  %t26 = load ptr, ptr %l12, !tbaa !29
  %t28 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %t25, ptr %t26, i32 %a2)
  store i32 %t28, ptr %l15
  br label %bb2
bb2:
  %t29 = load i32, ptr %l15, !tbaa !23
  store i32 %t29, ptr %l5, !tbaa !23
  %t30 = load ptr, ptr %l3, !tbaa !29
  store ptr %t30, ptr %l16, !tbaa !29
  %t31 = load i32, ptr %l4, !tbaa !23
  %t32 = load ptr, ptr %l16, !tbaa !29
  %t33 = call ptr @__olang_scope_or(ptr %v1, ptr %t32)
  %t34 = call ptr @__olang_scope_hold(ptr %t33)
  %t35 = ptrtoint ptr %t34 to i64
  %t37 = inttoptr i64 %t35 to ptr
  %t38 = load ptr, ptr %l16, !tbaa !29
  %t40 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %t37, ptr %t38, i32 %t31)
  store i32 %t40, ptr %l19
  br label %bb3
bb3:
  %t41 = load i32, ptr %l19, !range !{i32 0, i32 33}
  %t43 = trunc i64 19 to i32
  %t44 = icmp eq i32 %t41, %t43
  br i1 %t44, label %bb4, label %bb5
bb4:
  %t46 = load ptr, ptr %l3, !tbaa !29
  store ptr %t46, ptr %l23, !tbaa !29
  %t47 = load i32, ptr %l5, !tbaa !23
  %t48 = load ptr, ptr %l23, !tbaa !29
  %t49 = call ptr @__olang_scope_or(ptr %v1, ptr %t48)
  %t50 = call ptr @__olang_scope_hold(ptr %t49)
  %t51 = ptrtoint ptr %t50 to i64
  %t53 = inttoptr i64 %t51 to ptr
  %t54 = load ptr, ptr %l23, !tbaa !29
  %t56 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %t53, ptr %t54, i32 %t47)
  store i32 %t56, ptr %l26
  br label %bb6
bb5:
  store i1 false, ptr %l22, !tbaa !21
  br label %bb7
bb6:
  %t57 = load i32, ptr %l26, !range !{i32 0, i32 33}
  %t59 = trunc i64 19 to i32
  %t60 = icmp eq i32 %t57, %t59
  store i1 %t60, ptr %l22, !tbaa !21
  br label %bb7
bb7:
  %t62 = load i1, ptr %l22, !tbaa !21
  br i1 %t62, label %bb8, label %bb9
bb8:
  %t63 = load ptr, ptr %l3, !tbaa !29
  store ptr %t63, ptr %l30, !tbaa !29
  %t64 = load i32, ptr %l4, !tbaa !23
  %t65 = load ptr, ptr %l30, !tbaa !29
  %t66 = call ptr @__olang_scope_or(ptr %v1, ptr %t65)
  %t67 = call ptr @__olang_scope_hold(ptr %t66)
  %t68 = ptrtoint ptr %t67 to i64
  %t70 = inttoptr i64 %t68 to ptr
  %t71 = load ptr, ptr %l30, !tbaa !29
  %t73 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %t70, ptr %t71, i32 %t64)
  store i32 %t73, ptr %l33
  br label %bb10
bb9:
  store i1 false, ptr %l29, !tbaa !21
  br label %bb11
bb10:
  %t74 = load i32, ptr %l33, !tbaa !23
  %t75 = icmp ne i32 %t74, 0
  store i1 %t75, ptr %l29, !tbaa !21
  br label %bb11
bb11:
  %t77 = load i1, ptr %l29, !tbaa !21
  br i1 %t77, label %bb12, label %bb13
bb12:
  %t78 = load ptr, ptr %l3, !tbaa !29
  store ptr %t78, ptr %l36, !tbaa !29
  %t79 = load i32, ptr %l5, !tbaa !23
  %t80 = load ptr, ptr %l36, !tbaa !29
  %t81 = call ptr @__olang_scope_or(ptr %v1, ptr %t80)
  %t82 = call ptr @__olang_scope_hold(ptr %t81)
  %t83 = ptrtoint ptr %t82 to i64
  %t85 = inttoptr i64 %t83 to ptr
  %t86 = load ptr, ptr %l36, !tbaa !29
  %t88 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %t85, ptr %t86, i32 %t79)
  store i32 %t88, ptr %l39
  br label %bb14
bb13:
  store i1 false, ptr %l35, !tbaa !21
  br label %bb15
bb14:
  %t89 = load i32, ptr %l39, !tbaa !23
  %t90 = icmp eq i32 %t89, 0
  store i1 %t90, ptr %l35, !tbaa !21
  br label %bb15
bb15:
  %t92 = load i1, ptr %l35, !tbaa !21
  store i1 %t92, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2flower_2ecompiler_2flower_3alowering_2eletGoOf(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l3 = alloca { i64, [21 x i64] }
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca { i64, [4 x i64] }
  %l6 = alloca { i64, [4 x i64] }
  %l7 = alloca %"compiler/source:Span"
  %l9 = alloca { i64, [4 x i64] }
  %l10 = alloca i32
  %l11 = alloca i64
  %l15 = alloca %"compiler/mir:BasicBlock"
  %l18 = alloca { i64, [21 x i64] }
  %l19 = alloca { i64, [21 x i64] }
  %l22 = alloca i1
  %l28 = alloca i1
  %l32 = alloca i1
  %l40 = alloca { i64, [4 x i64] }
  %l42 = alloca { i64, [4 x i64] }
  %l45 = alloca i64
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/lower:lowering", ptr %a0, i32 0, i32 3
  %t4 = getelementptr %"compiler/mir:Fn", ptr %t3, i32 0, i32 9
  %t8 = call %"compiler/mir:BasicBlock" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2eAt_3ccompiler_2fmir_3aBasicBlock_3e(ptr %v0, ptr %v0, ptr %t4, i64 %a1)
  store %"compiler/mir:BasicBlock" %t8, ptr %l15
  br label %bb1
bb1:
  %t9 = getelementptr %"compiler/mir:BasicBlock", ptr %l15, i32 0, i32 0
  %t13 = call { i64, [21 x i64] } @compiler_2fmir_2ecompiler_2fmir_3aStmtList_2eAt(ptr %v0, ptr %t9, i64 %a2)
  store { i64, [21 x i64] } %t13, ptr %l18
  br label %bb2
bb2:
  call void @llvm.memmove.p0.p0.i64(ptr %l3, ptr %l18, i64 176, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %l19, ptr %l3, i64 176, i1 false)
  %t14 = load { i64, [21 x i64] }, ptr %l19
  %t15 = extractvalue { i64, [21 x i64] } %t14, 0
  %t16 = icmp eq i64 %t15, 17
  %t18 = xor i1 %t16, true
  br i1 %t18, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l22, !tbaa !21
  br label %bb11
bb4:
  %t20 = getelementptr { i64, [21 x i64] }, ptr %l3, i32 0, i32 1
  %t21 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] }, { i64, [4 x i64] } }, ptr %t20, i32 0, i32 0
  %t22 = load %"compiler/source:Span", ptr %t21
  store %"compiler/source:Span" %t22, ptr %l4
  %t24 = getelementptr { i64, [21 x i64] }, ptr %l3, i32 0, i32 1
  %t25 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] }, { i64, [4 x i64] } }, ptr %t24, i32 0, i32 1
  %t26 = load { i64, [4 x i64] }, ptr %t25
  store { i64, [4 x i64] } %t26, ptr %l5
  %t28 = getelementptr { i64, [21 x i64] }, ptr %l3, i32 0, i32 1
  %t29 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] }, { i64, [4 x i64] } }, ptr %t28, i32 0, i32 2
  %t30 = load { i64, [4 x i64] }, ptr %t29
  store { i64, [4 x i64] } %t30, ptr %l6
  %t32 = load { i64, [4 x i64] }, ptr %l6
  %t34 = extractvalue { i64, [4 x i64] } %t32, 0
  %t35 = icmp eq i64 %t34, 2
  br i1 %t35, label %bb5, label %bb6
bb5:
  %t37 = getelementptr { i64, [4 x i64] }, ptr %l6, i32 0, i32 1
  %t38 = getelementptr { i32, i64 }, ptr %t37, i32 0, i32 0
  %t39 = load i32, ptr %t38
  %t40 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  %t43 = icmp eq i32 %t39, %t40
  store i1 %t43, ptr %l28, !tbaa !21
  br label %bb7
bb6:
  store i1 false, ptr %l28, !tbaa !21
  br label %bb7
bb7:
  %t45 = load i1, ptr %l28, !tbaa !21
  br i1 %t45, label %bb8, label %bb9
bb8:
  %t46 = getelementptr { i64, [4 x i64] }, ptr %l6, i32 0, i32 1
  %t47 = getelementptr { i32, i64 }, ptr %t46, i32 0, i32 1
  %t48 = load i64, ptr %t47
  %t50 = icmp eq i64 %t48, -1
  store i1 %t50, ptr %l32, !tbaa !21
  br label %bb10
bb9:
  store i1 false, ptr %l32, !tbaa !21
  br label %bb10
bb10:
  %t52 = load i1, ptr %l32, !tbaa !21
  %t53 = xor i1 %t52, true
  store i1 %t53, ptr %l22, !tbaa !21
  br label %bb11
bb11:
  %t55 = load i1, ptr %l22, !tbaa !21
  br i1 %t55, label %bb12, label %bb13
bb12:
  store i64 -1, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  %t57 = getelementptr { i64, [21 x i64] }, ptr %l3, i32 0, i32 1
  %t58 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] }, { i64, [4 x i64] } }, ptr %t57, i32 0, i32 0
  %t59 = load %"compiler/source:Span", ptr %t58
  store %"compiler/source:Span" %t59, ptr %l7
  %t61 = getelementptr { i64, [21 x i64] }, ptr %l3, i32 0, i32 1
  %t62 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] }, { i64, [4 x i64] } }, ptr %t61, i32 0, i32 1
  %t63 = load { i64, [4 x i64] }, ptr %t62
  %t65 = getelementptr { i64, [21 x i64] }, ptr %l3, i32 0, i32 1
  %t66 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] }, { i64, [4 x i64] } }, ptr %t65, i32 0, i32 2
  %t67 = load { i64, [4 x i64] }, ptr %t66
  store { i64, [4 x i64] } %t67, ptr %l9
  %t69 = load { i64, [4 x i64] }, ptr %l9
  store { i64, [4 x i64] } %t69, ptr %l40
  %t70 = getelementptr { i64, [4 x i64] }, ptr %l40, i32 0, i32 1
  %t71 = getelementptr { i32, i64 }, ptr %t70, i32 0, i32 0
  %t72 = load i32, ptr %t71
  store i32 %t72, ptr %l10, !tbaa !23
  %t74 = load { i64, [4 x i64] }, ptr %l9
  store { i64, [4 x i64] } %t74, ptr %l42
  %t75 = getelementptr { i64, [4 x i64] }, ptr %l42, i32 0, i32 1
  %t76 = getelementptr { i32, i64 }, ptr %t75, i32 0, i32 1
  %t77 = load i64, ptr %t76
  store i64 %t77, ptr %l11, !tbaa !24
  %t81 = call i64 @compiler_2flower_2ewholeLocal({ i64, [4 x i64] } %t63)
  store i64 %t81, ptr %l45
  br label %bb15
bb15:
  %t82 = load i64, ptr %l45, !tbaa !24
  store i64 %t82, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2eliveStep(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2, i64 %a3) #0 {
entry:
  %l1 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i64
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca i64
  %l11 = alloca i64
  %l18 = alloca i64
  %l20 = alloca i64
  %l25 = alloca i32
  %l30 = alloca i64
  %l34 = alloca { i64, ptr }
  %l41 = alloca i64
  %l43 = alloca i64
  %l48 = alloca i32
  %l53 = alloca i64
  %l57 = alloca { i64, ptr }
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2ementions(ptr %v0, ptr %v1, ptr %a0, ptr %t2, i64 %a2, i64 %a3)
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l1, !tbaa !29
  %t11 = getelementptr %"compiler/lower:liveness", ptr %t9, i32 0, i32 9
  store ptr %t11, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  %t13 = load i64, ptr %l5, !tbaa !24
  store i64 %t13, ptr %l18, !tbaa !24
  %t14 = load ptr, ptr %l4, !tbaa !29
  %t16 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2eLen_3ccompiler_2fmir_3aLocalId_3e(ptr %v1, ptr %t14)
  store i64 %t16, ptr %l20
  br label %bb3
bb3:
  %t17 = load i64, ptr %l18, !tbaa !24
  %t18 = load i64, ptr %l20, !tbaa !24
  %t19 = icmp slt i64 %t17, %t18
  %t21 = xor i1 %t19, true
  br i1 %t21, label %bb4, label %bb5
bb4:
  br label %bb13
bb5:
  br label %bb6
bb6:
  %t23 = load ptr, ptr %l4, !tbaa !29
  %t24 = load i64, ptr %l5, !tbaa !24
  %t27 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2eAt_3ccompiler_2fmir_3aLocalId_3e(ptr %v1, ptr %t23, i64 %t24)
  store i32 %t27, ptr %l25
  br label %bb7
bb7:
  %t28 = load i32, ptr %l25, !tbaa !23
  %t29 = load ptr, ptr %l1, !tbaa !29
  %t31 = getelementptr %"compiler/lower:liveness", ptr %t29, i32 0, i32 0
  %t34 = sext i32 %t28 to i64
  %t37 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t31, i64 %t34)
  store i64 %t37, ptr %l30
  br label %bb8
bb8:
  %t38 = load i64, ptr %l30, !tbaa !24
  store i64 %t38, ptr %l7, !tbaa !24
  %t39 = load i64, ptr %l7, !tbaa !24
  %t41 = icmp sge i64 %t39, 0
  br i1 %t41, label %bb9, label %bb10
bb9:
  %t43 = load ptr, ptr %l1, !tbaa !29
  %t45 = getelementptr %"compiler/lower:liveness", ptr %t43, i32 0, i32 7
  %t46 = load { i64, ptr }, ptr %t45, !tbaa !27
  store { i64, ptr } %t46, ptr %l34, !tbaa !27
  %t47 = load i64, ptr %l7, !tbaa !24
  %t49 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !27
  %t51 = getelementptr i1, ptr %t50, i64 %t47
  store i1 false, ptr %t51, !tbaa !31
  br label %bb11
bb10:
  br label %bb11
bb11:
  br label %bb12
bb12:
  %t52 = load i64, ptr %l5, !tbaa !24
  %t55 = add i64 %t52, 1
  store i64 %t55, ptr %l5, !tbaa !24
  br label %bb2
bb13:
  %t57 = load ptr, ptr %l1, !tbaa !29
  %t59 = getelementptr %"compiler/lower:liveness", ptr %t57, i32 0, i32 8
  store ptr %t59, ptr %l8, !tbaa !29
  store i64 0, ptr %l9, !tbaa !24
  br label %bb14
bb14:
  %t61 = load i64, ptr %l9, !tbaa !24
  store i64 %t61, ptr %l41, !tbaa !24
  %t62 = load ptr, ptr %l8, !tbaa !29
  %t64 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2eLen_3ccompiler_2fmir_3aLocalId_3e(ptr %v1, ptr %t62)
  store i64 %t64, ptr %l43
  br label %bb15
bb15:
  %t65 = load i64, ptr %l41, !tbaa !24
  %t66 = load i64, ptr %l43, !tbaa !24
  %t67 = icmp slt i64 %t65, %t66
  %t69 = xor i1 %t67, true
  br i1 %t69, label %bb16, label %bb17
bb16:
  br label %bb25
bb17:
  br label %bb18
bb18:
  %t71 = load ptr, ptr %l8, !tbaa !29
  %t72 = load i64, ptr %l9, !tbaa !24
  %t75 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2eAt_3ccompiler_2fmir_3aLocalId_3e(ptr %v1, ptr %t71, i64 %t72)
  store i32 %t75, ptr %l48
  br label %bb19
bb19:
  %t76 = load i32, ptr %l48, !tbaa !23
  %t77 = load ptr, ptr %l1, !tbaa !29
  %t79 = getelementptr %"compiler/lower:liveness", ptr %t77, i32 0, i32 0
  %t82 = sext i32 %t76 to i64
  %t85 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t79, i64 %t82)
  store i64 %t85, ptr %l53
  br label %bb20
bb20:
  %t86 = load i64, ptr %l53, !tbaa !24
  store i64 %t86, ptr %l11, !tbaa !24
  %t87 = load i64, ptr %l11, !tbaa !24
  %t89 = icmp sge i64 %t87, 0
  br i1 %t89, label %bb21, label %bb22
bb21:
  %t91 = load ptr, ptr %l1, !tbaa !29
  %t93 = getelementptr %"compiler/lower:liveness", ptr %t91, i32 0, i32 7
  %t94 = load { i64, ptr }, ptr %t93, !tbaa !27
  store { i64, ptr } %t94, ptr %l57, !tbaa !27
  %t95 = load i64, ptr %l11, !tbaa !24
  %t97 = getelementptr { i64, ptr }, ptr %l57, i32 0, i32 1
  %t98 = load ptr, ptr %t97, !tbaa !27
  %t99 = getelementptr i1, ptr %t98, i64 %t95
  store i1 true, ptr %t99, !tbaa !31
  br label %bb23
bb22:
  br label %bb23
bb23:
  br label %bb24
bb24:
  %t100 = load i64, ptr %l9, !tbaa !24
  %t103 = add i64 %t100, 1
  store i64 %t103, ptr %l9, !tbaa !24
  br label %bb14
bb25:
  br label %ret
ret:
  ret void
}

define dso_local { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2emadeAt(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l6 = alloca i1
  %l13 = alloca { i64, [1 x i64] }
  %rv = alloca { i64, [1 x i64] }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l1, !tbaa !23
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"compiler/lower:lowering", ptr %t2, i32 0, i32 36
  %t5 = load i32, ptr %t4, !tbaa !23
  %t8 = icmp eq i32 %t1, %t5
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load i32, ptr %l1, !tbaa !23
  %t12 = icmp sge i32 %t10, 0
  store i1 %t12, ptr %l6, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l6, !tbaa !21
  br label %bb3
bb3:
  %t14 = load i1, ptr %l6, !tbaa !21
  br i1 %t14, label %bb4, label %bb5
bb4:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/lower:lowering", ptr %t15, i32 0, i32 37
  %t18 = load { i64, [1 x i64] }, ptr %t17
  store { i64, [1 x i64] } %t18, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load i32, ptr %l1, !tbaa !23
  %t24 = call { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ebuilt(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %t20, i32 %t21)
  store { i64, [1 x i64] } %t24, ptr %l13
  br label %bb7
bb7:
  %t25 = load { i64, [1 x i64] }, ptr %l13
  store { i64, [1 x i64] } %t25, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [1 x i64] }, ptr %rv
  ret { i64, [1 x i64] } %rr
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3alowering_2ematchCopies(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l15 = alloca { i64, ptr }
  %l22 = alloca i1
  %l23 = alloca ptr
  %l29 = alloca i1
  %l38 = alloca i1
  %l48 = alloca i1
  %l49 = alloca ptr
  %l60 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Match", ptr %t1, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t6 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  store i64 %t8, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t10 = load i64, ptr %l3, !tbaa !24
  %t11 = load i64, ptr %l4, !tbaa !24
  %t14 = icmp slt i64 %t10, %t11
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb2, label %bb3
bb2:
  br label %bb16
bb3:
  br label %bb4
bb4:
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t18, ptr %l15, !tbaa !27
  %t19 = load i64, ptr %l3, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr ptr, ptr %t22, i64 %t19
  %t24 = load ptr, ptr %t23, !tbaa !39
  store ptr %t24, ptr %l5, !tbaa !29
  %t26 = load ptr, ptr %l5, !tbaa !29
  %t28 = getelementptr %"compiler/typed:Arm", ptr %t26, i32 0, i32 4
  %t29 = load ptr, ptr %t28, !tbaa !29
  %t31 = icmp eq ptr %t29, null
  %t33 = xor i1 %t31, true
  br i1 %t33, label %bb5, label %bb6
bb5:
  %t35 = load ptr, ptr %l0, !tbaa !29
  store ptr %t35, ptr %l23, !tbaa !29
  %t36 = load ptr, ptr %l5, !tbaa !29
  %t38 = getelementptr %"compiler/typed:Arm", ptr %t36, i32 0, i32 4
  %t39 = load ptr, ptr %t38, !tbaa !29
  %t41 = icmp eq ptr %t39, null
  br i1 %t41, label %bb7, label %bb8
bb6:
  store i1 false, ptr %l22, !tbaa !21
  br label %bb11
bb7:
  call void @__olang_check_failed(ptr @olang_loc_f71032533cd82c8_29b3308e7cd66624)
  unreachable
bb8:
  br label %bb9
bb9:
  %t43 = load ptr, ptr %l5, !tbaa !29
  %t45 = getelementptr %"compiler/typed:Arm", ptr %t43, i32 0, i32 4
  %t46 = load ptr, ptr %t45, !tbaa !29
  %t47 = load ptr, ptr %l23, !tbaa !29
  %t49 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2ecopiesValue(ptr %v0, ptr %v1, ptr %v2, ptr %t47, ptr %t46)
  store i1 %t49, ptr %l29
  br label %bb10
bb10:
  %t50 = load i1, ptr %l29, !tbaa !21
  store i1 %t50, ptr %l22, !tbaa !21
  br label %bb11
bb11:
  %t51 = load i1, ptr %l22, !tbaa !21
  br i1 %t51, label %bb12, label %bb13
bb12:
  store i1 true, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  br label %bb15
bb15:
  %t53 = load i64, ptr %l3, !tbaa !24
  %t56 = add i64 %t53, 1
  store i64 %t56, ptr %l3, !tbaa !24
  br label %bb1
bb16:
  %t58 = load ptr, ptr %l1, !tbaa !29
  %t60 = getelementptr %"compiler/typed:Match", ptr %t58, i32 0, i32 2
  %t61 = load ptr, ptr %t60, !tbaa !29
  %t63 = icmp eq ptr %t61, null
  %t65 = xor i1 %t63, true
  br i1 %t65, label %bb17, label %bb18
bb17:
  %t67 = load ptr, ptr %l1, !tbaa !29
  %t69 = getelementptr %"compiler/typed:Match", ptr %t67, i32 0, i32 2
  %t70 = load ptr, ptr %t69, !tbaa !29
  %t72 = icmp eq ptr %t70, null
  br i1 %t72, label %bb19, label %bb20
bb18:
  store i1 false, ptr %l38, !tbaa !21
  br label %bb22
bb19:
  call void @__olang_check_failed(ptr @olang_loc_6cc454f6892da6e7_dc94ff52b1800ff3)
  unreachable
bb20:
  br label %bb21
bb21:
  %t74 = load ptr, ptr %l1, !tbaa !29
  %t76 = getelementptr %"compiler/typed:Match", ptr %t74, i32 0, i32 2
  %t77 = load ptr, ptr %t76, !tbaa !29
  %t80 = getelementptr %"compiler/typed:Arm", ptr %t77, i32 0, i32 4
  %t81 = load ptr, ptr %t80, !tbaa !29
  %t83 = icmp eq ptr %t81, null
  %t85 = xor i1 %t83, true
  store i1 %t85, ptr %l38, !tbaa !21
  br label %bb22
bb22:
  %t87 = load i1, ptr %l38, !tbaa !21
  br i1 %t87, label %bb23, label %bb24
bb23:
  %t88 = load ptr, ptr %l0, !tbaa !29
  store ptr %t88, ptr %l49, !tbaa !29
  %t89 = load ptr, ptr %l1, !tbaa !29
  %t91 = getelementptr %"compiler/typed:Match", ptr %t89, i32 0, i32 2
  %t92 = load ptr, ptr %t91, !tbaa !29
  %t94 = icmp eq ptr %t92, null
  br i1 %t94, label %bb25, label %bb26
bb24:
  store i1 false, ptr %l48, !tbaa !21
  br label %bb32
bb25:
  call void @__olang_check_failed(ptr @olang_loc_6cc454f6892da6e7_dc94ff52b1800ff3)
  unreachable
bb26:
  br label %bb27
bb27:
  %t96 = load ptr, ptr %l1, !tbaa !29
  %t98 = getelementptr %"compiler/typed:Match", ptr %t96, i32 0, i32 2
  %t99 = load ptr, ptr %t98, !tbaa !29
  %t102 = getelementptr %"compiler/typed:Arm", ptr %t99, i32 0, i32 4
  %t103 = load ptr, ptr %t102, !tbaa !29
  store ptr %t103, ptr %l6, !tbaa !29
  %t105 = load ptr, ptr %l6, !tbaa !29
  %t107 = icmp eq ptr %t105, null
  br i1 %t107, label %bb28, label %bb29
bb28:
  call void @__olang_check_failed(ptr @olang_loc_6cc454f6892da6e7_dc94ff52b1800ff3)
  unreachable
bb29:
  br label %bb30
bb30:
  %t109 = load ptr, ptr %l6, !tbaa !29
  %t110 = load ptr, ptr %l49, !tbaa !29
  %t112 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2ecopiesValue(ptr %v0, ptr %v1, ptr %v2, ptr %t110, ptr %t109)
  store i1 %t112, ptr %l60
  br label %bb31
bb31:
  %t113 = load i1, ptr %l60, !tbaa !21
  store i1 %t113, ptr %l48, !tbaa !21
  br label %bb32
bb32:
  %t114 = load i1, ptr %l48, !tbaa !21
  store i1 %t114, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2emix(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, [4 x i64] } %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca { i64, [4 x i64] }
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca { i64, [4 x i64] }
  %l9 = alloca { i64, [4 x i64] }
  %l10 = alloca { i64, ptr }
  %l12 = alloca { i64, [4 x i64] }
  %l13 = alloca ptr
  %l14 = alloca i32
  %l15 = alloca i32
  %l16 = alloca { i64, [4 x i64] }
  %l17 = alloca ptr
  %l18 = alloca i32
  %l19 = alloca i32
  %l20 = alloca { i64, [4 x i64] }
  %l22 = alloca { i64, [4 x i64] }
  %l23 = alloca { i64, ptr }
  %l25 = alloca { i64, [4 x i64] }
  %l26 = alloca { i64, ptr }
  %l28 = alloca { i64, [4 x i64] }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, [4 x i64] }
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i32 5, ptr %l5
  %t2 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  store i32 %t2, ptr %l6, !tbaa !23
  store { i64, [4 x i64] } %a1, ptr %l7
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t6 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2econstI64(ptr %v0, ptr %t4, i64 -7046029254386353131)
  store { i64, [4 x i64] } %t6, ptr %l9
  br label %bb1
bb1:
  %t7 = mul i64 2, 40
  %t8 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t7)
  %t9 = insertvalue { i64, ptr } undef, i64 2, 0
  %t10 = insertvalue { i64, ptr } %t9, ptr %t8, 1
  store { i64, ptr } %t10, ptr %l10, !tbaa !27
  %t11 = load { i64, [4 x i64] }, ptr %l7
  %t12 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, [4 x i64] }, ptr %t13, i64 0
  store { i64, [4 x i64] } %t11, ptr %t14
  %t15 = load { i64, [4 x i64] }, ptr %l9
  %t16 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = getelementptr { i64, [4 x i64] }, ptr %t17, i64 1
  store { i64, [4 x i64] } %t15, ptr %t18
  %t19 = load %"compiler/source:Span", ptr %l2
  %t20 = load ptr, ptr %l4, !tbaa !29
  %t21 = load i32, ptr %l5, !range !{i32 0, i32 54}
  %t22 = load i32, ptr %l6, !tbaa !23
  %t23 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t25 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s0, ptr %v1, ptr %v2, ptr %t20, i32 %t21, i32 %t22, { i64, ptr } %t23, %"compiler/source:Span" %t19)
  store { i64, [4 x i64] } %t25, ptr %l12
  br label %bb2
bb2:
  %t26 = load { i64, [4 x i64] }, ptr %l12
  store { i64, [4 x i64] } %t26, ptr %l3
  %t27 = load ptr, ptr %l0, !tbaa !29
  store ptr %t27, ptr %l13, !tbaa !29
  store i32 12, ptr %l14
  %t28 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  store i32 %t28, ptr %l15, !tbaa !23
  %t29 = load { i64, [4 x i64] }, ptr %l3
  store { i64, [4 x i64] } %t29, ptr %l16
  %t30 = load ptr, ptr %l0, !tbaa !29
  store ptr %t30, ptr %l17, !tbaa !29
  store i32 9, ptr %l18
  %t31 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  store i32 %t31, ptr %l19, !tbaa !23
  %t32 = load { i64, [4 x i64] }, ptr %l3
  store { i64, [4 x i64] } %t32, ptr %l20
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2econstI64(ptr %v0, ptr %t33, i64 29)
  store { i64, [4 x i64] } %t35, ptr %l22
  br label %bb3
bb3:
  %t36 = mul i64 2, 40
  %t37 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t36)
  %t38 = insertvalue { i64, ptr } undef, i64 2, 0
  %t39 = insertvalue { i64, ptr } %t38, ptr %t37, 1
  store { i64, ptr } %t39, ptr %l23, !tbaa !27
  %t40 = load { i64, [4 x i64] }, ptr %l20
  %t41 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !27
  %t43 = getelementptr { i64, [4 x i64] }, ptr %t42, i64 0
  store { i64, [4 x i64] } %t40, ptr %t43
  %t44 = load { i64, [4 x i64] }, ptr %l22
  %t45 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !27
  %t47 = getelementptr { i64, [4 x i64] }, ptr %t46, i64 1
  store { i64, [4 x i64] } %t44, ptr %t47
  %t48 = load %"compiler/source:Span", ptr %l2
  %t49 = load ptr, ptr %l17, !tbaa !29
  %t50 = load i32, ptr %l18, !range !{i32 0, i32 54}
  %t51 = load i32, ptr %l19, !tbaa !23
  %t52 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t54 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s0, ptr %v1, ptr %v2, ptr %t49, i32 %t50, i32 %t51, { i64, ptr } %t52, %"compiler/source:Span" %t48)
  store { i64, [4 x i64] } %t54, ptr %l25
  br label %bb4
bb4:
  %t55 = mul i64 2, 40
  %t56 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t55)
  %t57 = insertvalue { i64, ptr } undef, i64 2, 0
  %t58 = insertvalue { i64, ptr } %t57, ptr %t56, 1
  store { i64, ptr } %t58, ptr %l26, !tbaa !27
  %t59 = load { i64, [4 x i64] }, ptr %l16
  %t60 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !27
  %t62 = getelementptr { i64, [4 x i64] }, ptr %t61, i64 0
  store { i64, [4 x i64] } %t59, ptr %t62
  %t63 = load { i64, [4 x i64] }, ptr %l25
  %t64 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t65 = load ptr, ptr %t64, !tbaa !27
  %t66 = getelementptr { i64, [4 x i64] }, ptr %t65, i64 1
  store { i64, [4 x i64] } %t63, ptr %t66
  %t67 = load %"compiler/source:Span", ptr %l2
  %t68 = load ptr, ptr %l13, !tbaa !29
  %t69 = load i32, ptr %l14, !range !{i32 0, i32 54}
  %t70 = load i32, ptr %l15, !tbaa !23
  %t71 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t73 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s0, ptr %v1, ptr %v2, ptr %t68, i32 %t69, i32 %t70, { i64, ptr } %t71, %"compiler/source:Span" %t67)
  store { i64, [4 x i64] } %t73, ptr %l28
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s0)
  %t74 = load { i64, [4 x i64] }, ptr %l28
  store { i64, [4 x i64] } %t74, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local %"compiler/mir:Lvalue" @compiler_2flower_2ecompiler_2flower_3alowering_2emk(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/lower:pl" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/lower:pl"
  %l9 = alloca ptr
  %l10 = alloca { i64, [2 x i64] }
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l20 = alloca %"compiler/mir:Lvalue"
  %l22 = alloca ptr
  %l23 = alloca { i64, [2 x i64] }
  %l25 = alloca { i64, ptr }
  %l26 = alloca %"compiler/mir:Lvalue"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca %"compiler/mir:Lvalue"
  store ptr %a0, ptr %l0
  store %"compiler/lower:pl" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = getelementptr %"compiler/lower:pl", ptr %l1, i32 0, i32 2
  %t2 = load i64, ptr %t1, !tbaa !24
  %t4 = icmp sge i64 %t2, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/lower:lowering", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/typed:Body", ptr %t10, i32 0, i32 4
  %t13 = load %"compiler/source:Span", ptr %t12
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2egap(ptr %v0, ptr %s1, ptr %v2, ptr %t6, %"compiler/source:Span" %t13, { i64, ptr } { i64 43, ptr getelementptr inbounds (<{ i64, [43 x i8] }>, ptr @.d9, i32 0, i32 1) })
  br label %bb3
bb2:
  br label %bb12
bb3:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/lower:lowering", ptr %t16, i32 0, i32 3
  store ptr %t18, ptr %l9, !tbaa !29
  %t19 = getelementptr %"compiler/lower:pl", ptr %l1, i32 0, i32 0
  %t20 = load { i64, [2 x i64] }, ptr %t19
  store { i64, [2 x i64] } %t20, ptr %l10
  %t21 = getelementptr %"compiler/lower:pl", ptr %l1, i32 0, i32 1
  %t23 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aProj_3e_2eView_3ccompiler_2fmir_3aProj_3e(ptr %s0, ptr %s0, ptr %t21)
  store { i64, ptr } %t23, ptr %l12
  br label %bb4
bb4:
  %t24 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t24, ptr %l13, !tbaa !27
  %t25 = getelementptr %"compiler/lower:pl", ptr %l1, i32 0, i32 2
  %t26 = load i64, ptr %t25, !tbaa !24
  store i64 %t26, ptr %l14, !tbaa !24
  %t27 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t28 = extractvalue { i64, ptr } %t27, 0
  store i64 %t28, ptr %l15, !tbaa !24
  %t29 = icmp sge i64 0, 0
  br i1 %t29, label %bb5, label %bb6
bb5:
  %t31 = load i64, ptr %l14, !tbaa !24
  %t32 = icmp sle i64 0, %t31
  br i1 %t32, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_42d43bd34810722a_688b4686d67d3836)
  unreachable
bb7:
  %t34 = load i64, ptr %l14, !tbaa !24
  %t35 = load i64, ptr %l15, !tbaa !24
  %t36 = icmp sle i64 %t34, %t35
  br i1 %t36, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_42d43bd34810722a_688b4686d67d3836)
  unreachable
bb9:
  %t38 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t39 = load ptr, ptr %t38, !tbaa !27
  %t40 = load i64, ptr %l14, !tbaa !24
  %t41 = getelementptr { i64, [1 x i64] }, ptr %t39, i64 0
  %t42 = sub i64 %t40, 0
  %t43 = insertvalue { i64, ptr } undef, i64 %t42, 0
  %t44 = insertvalue { i64, ptr } %t43, ptr %t41, 1
  %t45 = load ptr, ptr %l9, !tbaa !29
  %t46 = load { i64, [2 x i64] }, ptr %l10
  %t48 = call %"compiler/mir:Lvalue" @compiler_2fmir_2ecompiler_2fmir_3aFn_2ePlace(ptr %v0, ptr %s0, ptr %t45, { i64, [2 x i64] } %t46, { i64, ptr } %t44)
  store %"compiler/mir:Lvalue" %t48, ptr %l20
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_42d43bd34810722a_688b4686d67d3836)
  unreachable
bb11:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t49 = load %"compiler/mir:Lvalue", ptr %l20
  store %"compiler/mir:Lvalue" %t49, ptr %rv
  br label %ret
bb12:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/lower:lowering", ptr %t50, i32 0, i32 3
  store ptr %t52, ptr %l22, !tbaa !29
  %t53 = getelementptr %"compiler/lower:pl", ptr %l1, i32 0, i32 0
  %t54 = load { i64, [2 x i64] }, ptr %t53
  store { i64, [2 x i64] } %t54, ptr %l23
  %t55 = getelementptr %"compiler/lower:pl", ptr %l1, i32 0, i32 1
  %t57 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aProj_3e_2eToArray_3ccompiler_2fmir_3aProj_3e(ptr %v1, ptr %s0, ptr %t55)
  store { i64, ptr } %t57, ptr %l25
  br label %bb13
bb13:
  %t58 = load ptr, ptr %l22, !tbaa !29
  %t59 = load { i64, [2 x i64] }, ptr %l23
  %t60 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t61 = call %"compiler/mir:Lvalue" @compiler_2fmir_2ecompiler_2fmir_3aFn_2ePlace(ptr %v0, ptr %s0, ptr %t58, { i64, [2 x i64] } %t59, { i64, ptr } %t60)
  store %"compiler/mir:Lvalue" %t61, ptr %l26
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s0)
  %t62 = load %"compiler/mir:Lvalue", ptr %l26
  store %"compiler/mir:Lvalue" %t62, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/mir:Lvalue", ptr %rv
  ret %"compiler/mir:Lvalue" %rr
}

define dso_local i64 @compiler_2flower_2ecompiler_2flower_3alowering_2emodule(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l11 = alloca ptr
  %l13 = alloca i64
  %l17 = alloca i64
  %l20 = alloca i64
  %l42 = alloca ptr
  %l48 = alloca ptr
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l1, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/lower:Lowerer", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/generic:Program", ptr %t7, i32 0, i32 0
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/load:Loader", ptr %t10, i32 0, i32 10
  store ptr %t12, ptr %l11, !tbaa !29
  %t13 = load ptr, ptr %l11, !tbaa !29
  %t14 = call ptr @__olang_scope_or(ptr %v1, ptr %t13)
  %t15 = call ptr @__olang_scope_hold(ptr %t14)
  %t16 = ptrtoint ptr %t15 to i64
  %t18 = inttoptr i64 %t16 to ptr
  %t19 = load ptr, ptr %l11, !tbaa !29
  %t20 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %t18, ptr %t19)
  store i64 %t20, ptr %l13
  br label %bb1
bb1:
  %t21 = load i64, ptr %l13, !tbaa !24
  store i64 %t21, ptr %l2, !tbaa !24
  store i64 1, ptr %l3, !tbaa !24
  %t22 = load i64, ptr %l2, !tbaa !24
  %t23 = load i64, ptr %l1, !tbaa !24
  %t26 = icmp sgt i64 %t22, %t23
  br i1 %t26, label %bb2, label %bb3
bb2:
  %t28 = load i64, ptr %l3, !tbaa !24
  %t30 = icmp sgt i64 %t28, 0
  br i1 %t30, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l17, !tbaa !24
  br label %bb7
bb4:
  %t32 = load i64, ptr %l2, !tbaa !24
  %t33 = load i64, ptr %l1, !tbaa !24
  %t36 = sub i64 %t32, %t33
  %t37 = load i64, ptr %l3, !tbaa !24
  %t40 = add i64 %t36, %t37
  %t42 = sub i64 %t40, 1
  %t43 = load i64, ptr %l3, !tbaa !24
  %t46 = sdiv i64 %t42, %t43
  store i64 %t46, ptr %l20, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l20, !tbaa !24
  br label %bb6
bb6:
  %t48 = load i64, ptr %l20, !tbaa !24
  store i64 %t48, ptr %l17, !tbaa !24
  br label %bb7
bb7:
  %t49 = load i64, ptr %l17, !tbaa !24
  store i64 %t49, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb8
bb8:
  %t50 = load i64, ptr %l5, !tbaa !24
  %t51 = load i64, ptr %l4, !tbaa !24
  %t54 = icmp slt i64 %t50, %t51
  %t56 = xor i1 %t54, true
  br i1 %t56, label %bb9, label %bb10
bb9:
  br label %bb17
bb10:
  br label %bb11
bb11:
  %t58 = load i64, ptr %l1, !tbaa !24
  %t59 = load i64, ptr %l5, !tbaa !24
  %t60 = load i64, ptr %l3, !tbaa !24
  %t63 = mul i64 %t59, %t60
  %t66 = add i64 %t58, %t63
  store i64 %t66, ptr %l6, !tbaa !24
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/lower:lowering", ptr %t68, i32 0, i32 0
  %t71 = load ptr, ptr %t70, !tbaa !29
  %t73 = getelementptr %"compiler/lower:Lowerer", ptr %t71, i32 0, i32 0
  %t74 = load ptr, ptr %t73, !tbaa !29
  %t76 = getelementptr %"compiler/generic:Program", ptr %t74, i32 0, i32 0
  %t77 = load ptr, ptr %t76, !tbaa !29
  %t79 = getelementptr %"compiler/load:Loader", ptr %t77, i32 0, i32 10
  store ptr %t79, ptr %l42, !tbaa !29
  %t80 = load i64, ptr %l6, !tbaa !24
  %t81 = load ptr, ptr %l42, !tbaa !29
  %t82 = call ptr @__olang_scope_or(ptr %v1, ptr %t81)
  %t83 = call ptr @__olang_scope_hold(ptr %t82)
  %t84 = ptrtoint ptr %t83 to i64
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"compiler/lower:lowering", ptr %t85, i32 0, i32 0
  %t88 = load ptr, ptr %t87, !tbaa !29
  %t90 = call ptr @__olang_scope_or(ptr %v1, ptr %t88)
  %t91 = call ptr @__olang_scope_hold(ptr %t90)
  %t92 = ptrtoint ptr %t91 to i64
  %t94 = inttoptr i64 %t84 to ptr
  %t96 = inttoptr i64 %t92 to ptr
  %t97 = load ptr, ptr %l42, !tbaa !29
  %t99 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %t94, ptr %t96, ptr %t97, i64 %t80)
  store ptr %t99, ptr %l48
  br label %bb12
bb12:
  %t100 = load ptr, ptr %l48, !tbaa !29
  %t102 = getelementptr %"compiler/load:Module", ptr %t100, i32 0, i32 4
  %t103 = load i64, ptr %t102, !tbaa !24
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t106 = getelementptr %"compiler/lower:lowering", ptr %t104, i32 0, i32 7
  %t107 = load i64, ptr %t106, !tbaa !24
  %t110 = icmp eq i64 %t103, %t107
  br i1 %t110, label %bb13, label %bb14
bb13:
  %t112 = load i64, ptr %l6, !tbaa !24
  store i64 %t112, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  br label %bb16
bb16:
  %t114 = load i64, ptr %l5, !tbaa !24
  %t117 = add i64 %t114, 1
  store i64 %t117, ptr %l5, !tbaa !24
  br label %bb8
bb17:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local ptr @compiler_2flower_2ecompiler_2flower_3alowering_2emutGlobals(ptr %v0, ptr %v1, ptr %v2, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca ptr
  %l10 = alloca i32
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/lower:Lowerer", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/generic:Program", ptr %t7, i32 0, i32 3
  store ptr %t9, ptr %l4, !tbaa !29
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/lower:lowering", ptr %t10, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t15 = getelementptr %"compiler/typed:Body", ptr %t13, i32 0, i32 3
  %t16 = load i64, ptr %t15, !tbaa !24
  %t17 = load { i64, ptr }, ptr @G_2ecompiler_2ftyped_2eMutGlobalsFact, !tbaa !27
  %t18 = load ptr, ptr %l4, !tbaa !29
  %t19 = call ptr @__olang_scope_or(ptr %v2, ptr %t18)
  %t20 = call ptr @__olang_scope_hold(ptr %t19)
  %t21 = ptrtoint ptr %t20 to i64
  %t23 = inttoptr i64 %t21 to ptr
  %t24 = load ptr, ptr @__olang_prog_scope
  %t25 = load ptr, ptr %l4, !tbaa !29
  %t28 = call i32 @compiler_2ffacts_2ecompiler_2ffacts_3aTable_2eNote(ptr %t23, ptr %t24, ptr %t25, i64 %t16, { i64, ptr } %t17)
  store i32 %t28, ptr %l10
  %t29 = icmp ne i32 %t28, 0
  br i1 %t29, label %bb2, label %ok.30, !prof !99
ok.30:
  br label %bb1
bb1:
  br label %bb4
bb2:
  br label %bb3
bb3:
  br label %bb4
bb4:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/lower:lowering", ptr %t31, i32 0, i32 0
  %t34 = load ptr, ptr %t33, !tbaa !29
  %t36 = getelementptr %"compiler/lower:Lowerer", ptr %t34, i32 0, i32 0
  %t37 = load ptr, ptr %t36, !tbaa !29
  %t39 = getelementptr %"compiler/generic:Program", ptr %t37, i32 0, i32 0
  %t40 = load ptr, ptr %t39, !tbaa !29
  %t42 = getelementptr %"compiler/load:Loader", ptr %t40, i32 0, i32 9
  store ptr %t42, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i32 @compiler_2flower_2ecompiler_2flower_3alowering_2eobjectOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca ptr
  %l9 = alloca i1
  %l15 = alloca ptr
  %l16 = alloca i1
  %l23 = alloca i32
  %l24 = alloca ptr
  %l25 = alloca i1
  %l33 = alloca i32
  %l34 = alloca ptr
  %l35 = alloca i1
  %l43 = alloca i32
  %l44 = alloca ptr
  %l45 = alloca i1
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t2 = load ptr, ptr %l8, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l8, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l9, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l9, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load i32, ptr %l2, !tbaa !23
  store i32 %t16, ptr %l7, !tbaa !23
  br label %bb38
bb6:
  %t18 = load ptr, ptr %l1, !tbaa !29
  store ptr %t18, ptr %l15, !tbaa !29
  store i1 false, ptr %l16, !tbaa !21
  %t19 = load ptr, ptr %l15, !tbaa !29
  %t20 = icmp ne ptr %t19, null
  br i1 %t20, label %bb7, label %bb8
bb7:
  %t22 = load ptr, ptr %l15, !tbaa !29
  %t23 = load i64, ptr %t22, !range !{i64 0, i64 8}
  %t25 = icmp eq i64 %t23, 3
  store i1 %t25, ptr %l16, !tbaa !21
  br label %bb8
bb8:
  %t26 = load i1, ptr %l16, !tbaa !21
  br i1 %t26, label %bb9, label %bb10
bb9:
  %t27 = load ptr, ptr %l1, !tbaa !29
  %t29 = getelementptr { i64, [4 x i64] }, ptr %t27, i32 0, i32 1
  %t30 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t29, i32 0, i32 2
  %t31 = load ptr, ptr %t30
  store ptr %t31, ptr %l3, !tbaa !29
  br label %bb11
bb10:
  br label %bb13
bb11:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t34 = load ptr, ptr %l3, !tbaa !29
  %t37 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2eobjectOf(ptr %v0, ptr %v1, ptr %t33, ptr %t34)
  store i32 %t37, ptr %l23
  br label %bb12
bb12:
  %t38 = load i32, ptr %l23, !tbaa !23
  store i32 %t38, ptr %l7, !tbaa !23
  br label %bb38
bb13:
  %t39 = load ptr, ptr %l1, !tbaa !29
  store ptr %t39, ptr %l24, !tbaa !29
  store i1 false, ptr %l25, !tbaa !21
  %t40 = load ptr, ptr %l24, !tbaa !29
  %t41 = icmp ne ptr %t40, null
  br i1 %t41, label %bb14, label %bb15
bb14:
  %t43 = load ptr, ptr %l24, !tbaa !29
  %t44 = load i64, ptr %t43, !range !{i64 0, i64 8}
  %t46 = icmp eq i64 %t44, 4
  store i1 %t46, ptr %l25, !tbaa !21
  br label %bb15
bb15:
  %t47 = load i1, ptr %l25, !tbaa !21
  br i1 %t47, label %bb16, label %bb17
bb16:
  %t48 = load ptr, ptr %l1, !tbaa !29
  %t50 = getelementptr { i64, [4 x i64] }, ptr %t48, i32 0, i32 1
  %t51 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t50, i32 0, i32 2
  %t52 = load ptr, ptr %t51
  store ptr %t52, ptr %l4, !tbaa !29
  br label %bb18
bb17:
  br label %bb20
bb18:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t55 = load ptr, ptr %l4, !tbaa !29
  %t57 = getelementptr %"compiler/typed:Elem", ptr %t55, i32 0, i32 0
  %t58 = load ptr, ptr %t57, !tbaa !29
  %t61 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2eobjectOf(ptr %v0, ptr %v1, ptr %t54, ptr %t58)
  store i32 %t61, ptr %l33
  br label %bb19
bb19:
  %t62 = load i32, ptr %l33, !tbaa !23
  store i32 %t62, ptr %l7, !tbaa !23
  br label %bb38
bb20:
  %t63 = load ptr, ptr %l1, !tbaa !29
  store ptr %t63, ptr %l34, !tbaa !29
  store i1 false, ptr %l35, !tbaa !21
  %t64 = load ptr, ptr %l34, !tbaa !29
  %t65 = icmp ne ptr %t64, null
  br i1 %t65, label %bb21, label %bb22
bb21:
  %t67 = load ptr, ptr %l34, !tbaa !29
  %t68 = load i64, ptr %t67, !range !{i64 0, i64 8}
  %t70 = icmp eq i64 %t68, 5
  store i1 %t70, ptr %l35, !tbaa !21
  br label %bb22
bb22:
  %t71 = load i1, ptr %l35, !tbaa !21
  br i1 %t71, label %bb23, label %bb24
bb23:
  %t72 = load ptr, ptr %l1, !tbaa !29
  %t74 = getelementptr { i64, [4 x i64] }, ptr %t72, i32 0, i32 1
  %t75 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t74, i32 0, i32 2
  %t76 = load ptr, ptr %t75
  store ptr %t76, ptr %l5, !tbaa !29
  br label %bb25
bb24:
  br label %bb27
bb25:
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t79 = load ptr, ptr %l5, !tbaa !29
  %t81 = getelementptr %"compiler/typed:Payload", ptr %t79, i32 0, i32 0
  %t82 = load ptr, ptr %t81, !tbaa !29
  %t85 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2eobjectOf(ptr %v0, ptr %v1, ptr %t78, ptr %t82)
  store i32 %t85, ptr %l43
  br label %bb26
bb26:
  %t86 = load i32, ptr %l43, !tbaa !23
  store i32 %t86, ptr %l7, !tbaa !23
  br label %bb38
bb27:
  %t87 = load ptr, ptr %l1, !tbaa !29
  store ptr %t87, ptr %l44, !tbaa !29
  store i1 false, ptr %l45, !tbaa !21
  %t88 = load ptr, ptr %l44, !tbaa !29
  %t89 = icmp ne ptr %t88, null
  br i1 %t89, label %bb28, label %bb29
bb28:
  %t91 = load ptr, ptr %l44, !tbaa !29
  %t92 = load i64, ptr %t91, !range !{i64 0, i64 8}
  %t94 = icmp eq i64 %t92, 2
  store i1 %t94, ptr %l45, !tbaa !21
  br label %bb29
bb29:
  %t95 = load i1, ptr %l45, !tbaa !21
  br i1 %t95, label %bb30, label %bb31
bb30:
  %t96 = load ptr, ptr %l1, !tbaa !29
  %t98 = getelementptr { i64, [4 x i64] }, ptr %t96, i32 0, i32 1
  %t99 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t98, i32 0, i32 1
  %t100 = load i32, ptr %t99
  store i32 %t100, ptr %l6, !tbaa !23
  br label %bb32
bb31:
  br label %bb33
bb32:
  %t102 = load i32, ptr %l6, !tbaa !23
  store i32 %t102, ptr %l7, !tbaa !23
  br label %bb38
bb33:
  br i1 true, label %bb34, label %bb35
bb34:
  br label %bb36
bb35:
  br label %bb37
bb36:
  %t104 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t104, ptr %l7, !tbaa !23
  br label %bb38
bb37:
  call void @__olang_check_failed(ptr @olang_loc_166f6c7f8536ecb_3daea1ccb6433847)
  unreachable
bb38:
  %t106 = load i32, ptr %l7, !tbaa !23
  store i32 %t106, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eoutsideTurn(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [1 x i64] }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i32
  %l12 = alloca i64
  %l16 = alloca i64
  %l19 = alloca i64
  %l40 = alloca %"compiler/lower:level"
  %l50 = alloca i1
  %l58 = alloca i64
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store { i64, [1 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i64 -1, ptr %l2, !tbaa !24
  store i64 0, ptr %l3, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 14
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3alevel_3e_2eLen_3ccompiler_2flower_3alevel_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l12
  br label %bb1
bb1:
  %t6 = load i64, ptr %l12, !tbaa !24
  store i64 %t6, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t7 = load i64, ptr %l4, !tbaa !24
  %t8 = load i64, ptr %l3, !tbaa !24
  %t11 = icmp sgt i64 %t7, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load i64, ptr %l5, !tbaa !24
  %t15 = icmp sgt i64 %t13, 0
  br i1 %t15, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l16, !tbaa !24
  br label %bb7
bb4:
  %t17 = load i64, ptr %l4, !tbaa !24
  %t18 = load i64, ptr %l3, !tbaa !24
  %t21 = sub i64 %t17, %t18
  %t22 = load i64, ptr %l5, !tbaa !24
  %t25 = add i64 %t21, %t22
  %t27 = sub i64 %t25, 1
  %t28 = load i64, ptr %l5, !tbaa !24
  %t31 = sdiv i64 %t27, %t28
  store i64 %t31, ptr %l19, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l19, !tbaa !24
  br label %bb6
bb6:
  %t33 = load i64, ptr %l19, !tbaa !24
  store i64 %t33, ptr %l16, !tbaa !24
  br label %bb7
bb7:
  %t34 = load i64, ptr %l16, !tbaa !24
  store i64 %t34, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb8
bb8:
  %t35 = load i64, ptr %l7, !tbaa !24
  %t36 = load i64, ptr %l6, !tbaa !24
  %t39 = icmp slt i64 %t35, %t36
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb9, label %bb10
bb9:
  br label %bb17
bb10:
  br label %bb11
bb11:
  %t43 = load i64, ptr %l3, !tbaa !24
  %t44 = load i64, ptr %l7, !tbaa !24
  %t45 = load i64, ptr %l5, !tbaa !24
  %t48 = mul i64 %t44, %t45
  %t51 = add i64 %t43, %t48
  store i64 %t51, ptr %l8, !tbaa !24
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/lower:lowering", ptr %t53, i32 0, i32 14
  %t56 = load i64, ptr %l8, !tbaa !24
  %t59 = call %"compiler/lower:level" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3alevel_3e_2eAt_3ccompiler_2flower_3alevel_3e(ptr %v0, ptr %t55, i64 %t56)
  store %"compiler/lower:level" %t59, ptr %l40
  br label %bb12
bb12:
  %t60 = getelementptr %"compiler/lower:level", ptr %l40, i32 0, i32 2
  %t61 = load i32, ptr %t60, !range !{i32 0, i32 7}
  %t63 = trunc i64 2 to i32
  %t64 = icmp eq i32 %t61, %t63
  br i1 %t64, label %bb13, label %bb14
bb13:
  %t66 = load i64, ptr %l8, !tbaa !24
  store i64 %t66, ptr %l2, !tbaa !24
  br label %bb15
bb14:
  br label %bb15
bb15:
  br label %bb16
bb16:
  %t68 = load i64, ptr %l7, !tbaa !24
  %t71 = add i64 %t68, 1
  store i64 %t71, ptr %l7, !tbaa !24
  br label %bb8
bb17:
  %t73 = load i64, ptr %l2, !tbaa !24
  %t75 = icmp slt i64 %t73, 0
  br i1 %t75, label %bb18, label %bb19
bb18:
  store i1 false, ptr %rv
  br label %ret
bb19:
  br label %bb20
bb20:
  %t78 = load { i64, [1 x i64] }, ptr %l1
  %t80 = extractvalue { i64, [1 x i64] } %t78, 0
  %t81 = icmp eq i64 %t80, 4
  br i1 %t81, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  store i1 false, ptr %l50, !tbaa !21
  br label %bb34
bb24:
  %t83 = load { i64, [1 x i64] }, ptr %l1
  %t85 = extractvalue { i64, [1 x i64] } %t83, 0
  %t86 = icmp eq i64 %t85, 0
  br i1 %t86, label %bb25, label %bb26
bb25:
  %t88 = getelementptr { i64, [1 x i64] }, ptr %l1, i32 0, i32 1
  %t89 = getelementptr { i32 }, ptr %t88, i32 0, i32 0
  %t90 = load i32, ptr %t89
  store i32 %t90, ptr %l9, !tbaa !23
  br label %bb27
bb26:
  br label %bb29
bb27:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t93 = load i32, ptr %l9, !tbaa !23
  %t96 = call i64 @compiler_2flower_2ecompiler_2flower_3alowering_2elevelOf(ptr %v0, ptr %t92, i32 %t93)
  store i64 %t96, ptr %l58
  br label %bb28
bb28:
  %t97 = load i64, ptr %l2, !tbaa !24
  %t98 = load i64, ptr %l58, !tbaa !24
  %t100 = icmp slt i64 %t98, %t97
  store i1 %t100, ptr %l50, !tbaa !21
  br label %bb34
bb29:
  br i1 true, label %bb30, label %bb31
bb30:
  br label %bb32
bb31:
  br label %bb33
bb32:
  store i1 true, ptr %l50, !tbaa !21
  br label %bb34
bb33:
  call void @__olang_check_failed(ptr @olang_loc_26f97a2e9212578f_59dde7bfe76d04db)
  unreachable
bb34:
  %t102 = load i1, ptr %l50, !tbaa !21
  store i1 %t102, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eownerCopy(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, { i64, [4 x i64] } %a2, i32 %a3, { i64, [1 x i64] } %a4, %"compiler/source:Span" %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca i32
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca ptr
  %l7 = alloca i32
  %l11 = alloca i1
  %l22 = alloca ptr
  %l29 = alloca i64
  %l31 = alloca i1
  %l32 = alloca ptr
  %l35 = alloca i1
  %l37 = alloca i1
  %l39 = alloca ptr
  %l42 = alloca i1
  %l44 = alloca ptr
  %l50 = alloca { i64, [4 x i64] }
  %l53 = alloca i32
  %l54 = alloca ptr
  %l57 = alloca %"compiler/lower:pl"
  %l62 = alloca %"compiler/mir:Lvalue"
  %s0 = alloca %olang.scope
  %rv = alloca { i64, [4 x i64] }
  %t13 = alloca { i64, [4 x i64] }, align 8
  %t90 = alloca { i64, [4 x i64] }, align 8
  %t98 = alloca { i64, [15 x i64] }, align 8
  %t120 = alloca { i64, [2 x i64] }, align 8
  %t139 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i32 %a3, ptr %l3
  store %"compiler/source:Span" %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 39
  %t4 = load i1, ptr %t3, !tbaa !21
  %t6 = xor i1 %t4, true
  br i1 %t6, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l11, !tbaa !21
  br label %bb3
bb2:
  %t8 = load i64, ptr %l1, !tbaa !24
  %t10 = icmp slt i64 %t8, 0
  store i1 %t10, ptr %l11, !tbaa !21
  br label %bb3
bb3:
  %t12 = load i1, ptr %l11, !tbaa !21
  br i1 %t12, label %bb4, label %bb5
bb4:
  store { i64, [4 x i64] } zeroinitializer, ptr %t13
  %t14 = getelementptr { i64, [4 x i64] }, ptr %t13, i32 0, i32 0
  store i64 0, ptr %t14
  %t15 = load { i64, [4 x i64] }, ptr %t13
  call void @__olang_scope_close(ptr %s0)
  store { i64, [4 x i64] } %t15, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/lower:lowering", ptr %t17, i32 0, i32 0
  %t20 = load ptr, ptr %t19, !tbaa !29
  %t22 = getelementptr %"compiler/lower:Lowerer", ptr %t20, i32 0, i32 12
  %t23 = load ptr, ptr %t22, !tbaa !29
  %t25 = icmp eq ptr %t23, null
  br i1 %t25, label %bb7, label %bb8
bb7:
  call void @__olang_check_failed(ptr @olang_loc_a1428f65c21f01d2_d86d747ff6972196)
  unreachable
bb8:
  br label %bb9
bb9:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/lower:lowering", ptr %t27, i32 0, i32 0
  %t30 = load ptr, ptr %t29, !tbaa !29
  %t32 = getelementptr %"compiler/lower:Lowerer", ptr %t30, i32 0, i32 12
  %t33 = load ptr, ptr %t32, !tbaa !29
  store ptr %t33, ptr %l6, !tbaa !29
  %t35 = load ptr, ptr %l6, !tbaa !29
  store ptr %t35, ptr %l22, !tbaa !29
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/lower:lowering", ptr %t36, i32 0, i32 1
  %t39 = load ptr, ptr %t38, !tbaa !29
  %t41 = getelementptr %"compiler/typed:Body", ptr %t39, i32 0, i32 0
  %t42 = load i32, ptr %t41, !tbaa !23
  %t44 = sext i32 %t42 to i64
  %t45 = load i64, ptr %l1, !tbaa !24
  %t46 = load ptr, ptr %l22, !tbaa !29
  %t47 = call ptr @__olang_scope_or(ptr %v1, ptr %t46)
  %t48 = call ptr @__olang_scope_hold(ptr %t47)
  %t49 = ptrtoint ptr %t48 to i64
  %t51 = inttoptr i64 %t49 to ptr
  %t52 = load ptr, ptr %l22, !tbaa !29
  %t55 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eOwnerSite(ptr %t51, ptr %t52, i64 %t44, i64 %t45)
  store i64 %t55, ptr %l29
  br label %bb10
bb10:
  %t56 = load i64, ptr %l29, !tbaa !24
  %t57 = icmp slt i64 %t56, 0
  br i1 %t57, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l31, !tbaa !21
  br label %bb14
bb12:
  %t59 = load ptr, ptr %l6, !tbaa !29
  store ptr %t59, ptr %l32, !tbaa !29
  %t60 = load i32, ptr %l3, !tbaa !23
  %t61 = load ptr, ptr %l32, !tbaa !29
  %t62 = call ptr @__olang_scope_or(ptr %v1, ptr %t61)
  %t63 = call ptr @__olang_scope_hold(ptr %t62)
  %t64 = ptrtoint ptr %t63 to i64
  %t66 = inttoptr i64 %t64 to ptr
  %t67 = load ptr, ptr %l32, !tbaa !29
  %t69 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ePartsOnly(ptr %t66, ptr %t67, i32 %t60)
  store i1 %t69, ptr %l35
  br label %bb13
bb13:
  %t70 = load i1, ptr %l35, !tbaa !21
  %t71 = xor i1 %t70, true
  store i1 %t71, ptr %l31, !tbaa !21
  br label %bb14
bb14:
  %t73 = load i1, ptr %l31, !tbaa !21
  br i1 %t73, label %bb15, label %bb16
bb15:
  store i1 true, ptr %l37, !tbaa !21
  br label %bb18
bb16:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr %"compiler/lower:lowering", ptr %t74, i32 0, i32 2
  %t77 = load ptr, ptr %t76, !tbaa !29
  store ptr %t77, ptr %l39, !tbaa !29
  %t78 = load i32, ptr %l3, !tbaa !23
  %t79 = load ptr, ptr %l39, !tbaa !29
  %t80 = call ptr @__olang_scope_or(ptr %v2, ptr %t79)
  %t81 = call ptr @__olang_scope_hold(ptr %t80)
  %t82 = ptrtoint ptr %t81 to i64
  %t84 = inttoptr i64 %t82 to ptr
  %t85 = load ptr, ptr %l39, !tbaa !29
  %t87 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRunsCopy(ptr %t84, ptr %t85, i32 %t78)
  store i1 %t87, ptr %l42
  br label %bb17
bb17:
  %t88 = load i1, ptr %l42, !tbaa !21
  store i1 %t88, ptr %l37, !tbaa !21
  br label %bb18
bb18:
  %t89 = load i1, ptr %l37, !tbaa !21
  br i1 %t89, label %bb19, label %bb20
bb19:
  store { i64, [4 x i64] } zeroinitializer, ptr %t90
  %t91 = getelementptr { i64, [4 x i64] }, ptr %t90, i32 0, i32 0
  store i64 0, ptr %t91
  %t92 = load { i64, [4 x i64] }, ptr %t90
  call void @__olang_scope_close(ptr %s0)
  store { i64, [4 x i64] } %t92, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  %t94 = load ptr, ptr %l0, !tbaa !29
  store ptr %t94, ptr %l44, !tbaa !29
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t96 = load i32, ptr %l3, !tbaa !23
  store { i64, [15 x i64] } zeroinitializer, ptr %t98
  %t99 = getelementptr { i64, [15 x i64] }, ptr %t98, i32 0, i32 0
  store i64 0, ptr %t99
  %t101 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %a2, 0
  %t102 = getelementptr { i64, [15 x i64] }, ptr %t98, i32 0, i32 1
  store { { i64, [4 x i64] } } %t101, ptr %t102
  %t103 = load { i64, [15 x i64] }, ptr %t98
  %t104 = load %"compiler/source:Span", ptr %l5
  %t109 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %v2, ptr %v1, ptr %t95, i32 %t96, { i64, [15 x i64] } %t103, %"compiler/source:Span" %t104)
  store { i64, [4 x i64] } %t109, ptr %l50
  br label %bb22
bb22:
  %t110 = load i32, ptr %l3, !tbaa !23
  %t111 = load %"compiler/source:Span", ptr %l5
  %t112 = load ptr, ptr %l44, !tbaa !29
  %t113 = load { i64, [4 x i64] }, ptr %l50
  %t116 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2elocal(ptr %v0, ptr %v2, ptr %v1, ptr %t112, { i64, [4 x i64] } %t113, i32 %t110, %"compiler/source:Span" %t111)
  store i32 %t116, ptr %l53
  br label %bb23
bb23:
  %t117 = load i32, ptr %l53, !tbaa !23
  store i32 %t117, ptr %l7, !tbaa !23
  %t118 = load ptr, ptr %l0, !tbaa !29
  store ptr %t118, ptr %l54, !tbaa !29
  %t119 = load i32, ptr %l7, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t120
  %t121 = getelementptr { i64, [2 x i64] }, ptr %t120, i32 0, i32 0
  store i64 1, ptr %t121
  %t123 = insertvalue { i32 } undef, i32 %t119, 0
  %t124 = getelementptr { i64, [2 x i64] }, ptr %t120, i32 0, i32 1
  store { i32 } %t123, ptr %t124
  %t125 = load { i64, [2 x i64] }, ptr %t120
  %t127 = call %"compiler/lower:pl" @compiler_2flower_3apl_2ector(ptr %s0, { i64, [2 x i64] } %t125)
  store %"compiler/lower:pl" %t127, ptr %l57
  br label %bb24
bb24:
  %t128 = load i32, ptr %l3, !tbaa !23
  %t130 = load %"compiler/source:Span", ptr %l5
  %t131 = load ptr, ptr %l54, !tbaa !29
  %t132 = load %"compiler/lower:pl", ptr %l57
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2epartsCopied(ptr %v0, ptr %s0, ptr %v2, ptr %v1, ptr %t131, %"compiler/lower:pl" %t132, i32 %t128, { i64, [1 x i64] } %a4, %"compiler/source:Span" %t130)
  br label %bb25
bb25:
  %t136 = load i32, ptr %l7, !tbaa !23
  %t138 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t136)
  store %"compiler/mir:Lvalue" %t138, ptr %l62
  br label %bb26
bb26:
  store { i64, [4 x i64] } zeroinitializer, ptr %t139
  %t140 = getelementptr { i64, [4 x i64] }, ptr %t139, i32 0, i32 0
  store i64 1, ptr %t140
  %t141 = load %"compiler/mir:Lvalue", ptr %l62
  %t142 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t141, 0
  %t143 = getelementptr { i64, [4 x i64] }, ptr %t139, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t142, ptr %t143
  %t144 = load { i64, [4 x i64] }, ptr %t139
  call void @__olang_scope_close(ptr %s0)
  store { i64, [4 x i64] } %t144, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eownsStorage(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l3 = alloca ptr
  %l6 = alloca i1
  %l7 = alloca i1
  %l9 = alloca ptr
  %l12 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t5 = load i32, ptr %l1, !tbaa !23
  %t6 = load ptr, ptr %l3, !tbaa !29
  %t7 = call ptr @__olang_scope_or(ptr %v1, ptr %t6)
  %t8 = call ptr @__olang_scope_hold(ptr %t7)
  %t9 = ptrtoint ptr %t8 to i64
  %t11 = inttoptr i64 %t9 to ptr
  %t12 = load ptr, ptr %l3, !tbaa !29
  %t14 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOwnedPart(ptr %t11, ptr %t12, i32 %t5)
  store i1 %t14, ptr %l6
  br label %bb1
bb1:
  %t15 = load i1, ptr %l6, !tbaa !21
  br i1 %t15, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb5
bb3:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/lower:lowering", ptr %t16, i32 0, i32 2
  %t19 = load ptr, ptr %t18, !tbaa !29
  store ptr %t19, ptr %l9, !tbaa !29
  %t20 = load i32, ptr %l1, !tbaa !23
  %t21 = load ptr, ptr %l9, !tbaa !29
  %t22 = call ptr @__olang_scope_or(ptr %v1, ptr %t21)
  %t23 = call ptr @__olang_scope_hold(ptr %t22)
  %t24 = ptrtoint ptr %t23 to i64
  %t26 = inttoptr i64 %t24 to ptr
  %t27 = load ptr, ptr %l9, !tbaa !29
  %t29 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOwnsParts(ptr %t26, ptr %t27, i32 %t20)
  store i1 %t29, ptr %l12
  br label %bb4
bb4:
  %t30 = load i1, ptr %l12, !tbaa !21
  store i1 %t30, ptr %l7, !tbaa !21
  br label %bb5
bb5:
  %t31 = load i1, ptr %l7, !tbaa !21
  store i1 %t31, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2epackedField(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/lower:pl" %a1, i32 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/lower:pl"
  %l2 = alloca i32
  %l4 = alloca %"compiler/lower:pl"
  %l7 = alloca ptr
  %l8 = alloca %"compiler/lower:pl"
  %l10 = alloca %"compiler/lower:pl"
  %l13 = alloca %"compiler/lower:pl"
  %l16 = alloca i1
  %l18 = alloca ptr
  %l20 = alloca ptr
  %l23 = alloca i32
  %l25 = alloca i1
  %l27 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/lower:pl"
  %t6 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/lower:pl" %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l7, !tbaa !29
  %t2 = load %"compiler/lower:pl", ptr %l1
  store %"compiler/lower:pl" %t2, ptr %l8
  %t4 = call %"compiler/lower:pl" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2flower_3apl(ptr %s0, ptr %l8)
  store %"compiler/lower:pl" %t4, ptr %l10
  br label %bb1
bb1:
  store { i64, [1 x i64] } zeroinitializer, ptr %t6
  %t7 = getelementptr { i64, [1 x i64] }, ptr %t6, i32 0, i32 0
  store i64 0, ptr %t7
  %t9 = insertvalue { i64 } undef, i64 %a3, 0
  %t10 = getelementptr { i64, [1 x i64] }, ptr %t6, i32 0, i32 1
  store { i64 } %t9, ptr %t10
  %t11 = load { i64, [1 x i64] }, ptr %t6
  %t12 = load ptr, ptr %l7, !tbaa !29
  %t13 = load %"compiler/lower:pl", ptr %l10
  %t15 = call %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2ewith(ptr %v0, ptr %s0, ptr %v2, ptr %t12, %"compiler/lower:pl" %t13, { i64, [1 x i64] } %t11)
  store %"compiler/lower:pl" %t15, ptr %l13
  br label %bb2
bb2:
  %t16 = load %"compiler/lower:pl", ptr %l13
  store %"compiler/lower:pl" %t16, ptr %l4
  %t17 = getelementptr %"compiler/lower:pl", ptr %l4, i32 0, i32 2
  %t18 = load i64, ptr %t17, !tbaa !24
  %t20 = icmp slt i64 %t18, 0
  br i1 %t20, label %bb3, label %bb4
bb3:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/lower:lowering", ptr %t22, i32 0, i32 2
  %t25 = load ptr, ptr %t24, !tbaa !29
  store ptr %t25, ptr %l18, !tbaa !29
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/lower:lowering", ptr %t26, i32 0, i32 2
  %t29 = load ptr, ptr %t28, !tbaa !29
  store ptr %t29, ptr %l20, !tbaa !29
  %t30 = load i32, ptr %l2, !tbaa !23
  %t31 = load ptr, ptr %l20, !tbaa !29
  %t32 = call ptr @__olang_scope_or(ptr %v3, ptr %t31)
  %t33 = call ptr @__olang_scope_hold(ptr %t32)
  %t34 = ptrtoint ptr %t33 to i64
  %t36 = inttoptr i64 %t34 to ptr
  %t37 = load ptr, ptr %l20, !tbaa !29
  %t39 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %t36, ptr %t37, i32 %t30)
  store i32 %t39, ptr %l23
  br label %bb5
bb4:
  store i1 false, ptr %l16, !tbaa !21
  br label %bb7
bb5:
  %t40 = load ptr, ptr %l18, !tbaa !29
  %t41 = call ptr @__olang_scope_or(ptr %v3, ptr %t40)
  %t42 = call ptr @__olang_scope_hold(ptr %t41)
  %t43 = ptrtoint ptr %t42 to i64
  %t45 = inttoptr i64 %t43 to ptr
  %t46 = load ptr, ptr %l18, !tbaa !29
  %t47 = load i32, ptr %l23, !tbaa !23
  %t48 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePacked(ptr %t45, ptr %t46, i32 %t47)
  store i1 %t48, ptr %l25
  br label %bb6
bb6:
  %t49 = load i1, ptr %l25, !tbaa !21
  store i1 %t49, ptr %l16, !tbaa !21
  br label %bb7
bb7:
  %t50 = load i1, ptr %l16, !tbaa !21
  br i1 %t50, label %bb8, label %bb9
bb8:
  %t51 = getelementptr %"compiler/lower:pl", ptr %l1, i32 0, i32 1
  %t53 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aProj_3e_2eLen_3ccompiler_2fmir_3aProj_3e(ptr %v1, ptr %t51)
  store i64 %t53, ptr %l27
  br label %bb10
bb9:
  br label %bb11
bb10:
  %t54 = load i64, ptr %l27, !tbaa !24
  %t55 = load i32, ptr %l2, !tbaa !23
  %t59 = getelementptr %"compiler/lower:pl", ptr %l4, i32 0, i32 2
  store i64 %t54, ptr %t59, !tbaa !24
  %t62 = getelementptr %"compiler/lower:pl", ptr %l4, i32 0, i32 3
  store i32 %t55, ptr %t62, !tbaa !23
  br label %bb11
bb11:
  %t63 = load %"compiler/lower:pl", ptr %l4
  call void @__olang_scope_close(ptr %s0)
  store %"compiler/lower:pl" %t63, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/lower:pl", ptr %rv
  ret %"compiler/lower:pl" %rr
}

define dso_local { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2epackedRead(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/lower:pl" %a1, i32 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca %"compiler/lower:pl"
  %l8 = alloca %"compiler/lower:pl"
  %l10 = alloca { i64, ptr }
  %l19 = alloca { i64, [4 x i64] }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, [4 x i64] }
  %t23 = alloca { i64, [15 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store %"compiler/lower:pl" %a1, ptr %l6
  %t4 = call %"compiler/lower:pl" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2flower_3apl(ptr %s0, ptr %l6)
  store %"compiler/lower:pl" %t4, ptr %l8
  br label %bb1
bb1:
  %t5 = load %"compiler/source:Span", ptr %l3
  %t6 = load ptr, ptr %l5, !tbaa !29
  %t7 = load %"compiler/lower:pl", ptr %l8
  %t9 = call { i64, ptr } @compiler_2flower_2ecompiler_2flower_3alowering_2epackedChain(ptr %v0, ptr %s0, ptr %s0, ptr %v2, ptr %v3, ptr %t6, %"compiler/lower:pl" %t7, %"compiler/source:Span" %t5)
  store { i64, ptr } %t9, ptr %l10
  br label %bb2
bb2:
  %t10 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t10, ptr %l4, !tbaa !27
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  %t17 = sub i64 %t15, 1
  %t19 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !27
  %t21 = getelementptr { i64, [4 x i64] }, ptr %t20, i64 %t17
  %t22 = load { i64, [4 x i64] }, ptr %t21
  store { i64, [15 x i64] } zeroinitializer, ptr %t23
  %t24 = getelementptr { i64, [15 x i64] }, ptr %t23, i32 0, i32 0
  store i64 0, ptr %t24
  %t26 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t22, 0
  %t27 = getelementptr { i64, [15 x i64] }, ptr %t23, i32 0, i32 1
  store { { i64, [4 x i64] } } %t26, ptr %t27
  %t28 = load { i64, [15 x i64] }, ptr %t23
  %t29 = load %"compiler/source:Span", ptr %l3
  %t34 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %v2, ptr %v3, ptr %t11, i32 %a2, { i64, [15 x i64] } %t28, %"compiler/source:Span" %t29)
  store { i64, [4 x i64] } %t34, ptr %l19
  br label %bb3
bb3:
  call void @__olang_scope_close(ptr %s0)
  %t35 = load { i64, [4 x i64] }, ptr %l19
  store { i64, [4 x i64] } %t35, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eparamElig(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l5 = alloca i64
  %l8 = alloca ptr
  %l11 = alloca %"compiler/typed:Local"
  %l14 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l19 = alloca ptr
  %l22 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/typed:Body", ptr %t4, i32 0, i32 3
  %t7 = load i64, ptr %t6, !tbaa !24
  store i64 %t7, ptr %l5, !tbaa !24
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/lower:lowering", ptr %t8, i32 0, i32 1
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t13 = getelementptr %"compiler/typed:Body", ptr %t11, i32 0, i32 7
  store ptr %t13, ptr %l8, !tbaa !29
  %t15 = load ptr, ptr %l8, !tbaa !29
  %t16 = call ptr @__olang_scope_or(ptr %v1, ptr %t15)
  %t17 = call ptr @__olang_scope_hold(ptr %t16)
  %t18 = ptrtoint ptr %t17 to i64
  %t20 = inttoptr i64 %t18 to ptr
  %t21 = load ptr, ptr %l8, !tbaa !29
  %t23 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %t20, ptr %t21, i64 %a1)
  store %"compiler/typed:Local" %t23, ptr %l11
  br label %bb1
bb1:
  %t24 = getelementptr %"compiler/typed:Local", ptr %l11, i32 0, i32 1
  %t25 = getelementptr %"compiler/source:Span", ptr %t24, i32 0, i32 0
  %t26 = load i32, ptr %t25, !tbaa !23
  %t28 = sext i32 %t26 to i64
  %t29 = load i64, ptr %l5, !tbaa !24
  %t31 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s0, i64 %t29, i64 %t28)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t31, ptr %l14
  br label %bb2
bb2:
  %t32 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l14
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/lower:lowering", ptr %t33, i32 0, i32 0
  %t36 = load ptr, ptr %t35, !tbaa !29
  %t38 = getelementptr %"compiler/lower:Lowerer", ptr %t36, i32 0, i32 0
  %t39 = load ptr, ptr %t38, !tbaa !29
  %t41 = getelementptr %"compiler/generic:Program", ptr %t39, i32 0, i32 0
  %t42 = load ptr, ptr %t41, !tbaa !29
  %t44 = getelementptr %"compiler/load:Loader", ptr %t42, i32 0, i32 5
  store ptr %t44, ptr %l19, !tbaa !29
  %t46 = load ptr, ptr %l19, !tbaa !29
  %t47 = call ptr @__olang_scope_or(ptr %v2, ptr %t46)
  %t48 = call ptr @__olang_scope_hold(ptr %t47)
  %t49 = ptrtoint ptr %t48 to i64
  %t51 = inttoptr i64 %t49 to ptr
  %t52 = load ptr, ptr %l19, !tbaa !29
  %t54 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %t51, ptr %t52, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t32)
  store i1 %t54, ptr %l22
  br label %bb3
bb3:
  %t55 = load i1, ptr %l22, !tbaa !21
  %t56 = xor i1 %t55, true
  call void @__olang_scope_close(ptr %s0)
  store i1 %t56, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2epartAt(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, %"compiler/lower:pl" %a1, i32 %a2, i64 %a3, %"compiler/source:Span" %a4) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca %"compiler/lower:pl"
  %l6 = alloca i32
  %l7 = alloca ptr
  %l8 = alloca %"compiler/lower:pl"
  %l10 = alloca %"compiler/lower:pl"
  %l13 = alloca %"compiler/lower:pl"
  %l15 = alloca ptr
  %l20 = alloca ptr
  %l22 = alloca ptr
  %l27 = alloca i1
  %l32 = alloca { i64, ptr }
  %l35 = alloca ptr
  %l36 = alloca ptr
  %l37 = alloca i32
  %l40 = alloca %"compiler/mir:Lvalue"
  %l44 = alloca { i64, [4 x i64] }
  %l47 = alloca i32
  %l49 = alloca %"compiler/lower:pl"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/lower:pl"
  %t84 = alloca { i64, [15 x i64] }, align 8
  %t105 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  store i64 %a3, ptr %l3
  store %"compiler/source:Span" %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l7, !tbaa !29
  store %"compiler/lower:pl" %a1, ptr %l8
  %t4 = call %"compiler/lower:pl" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2flower_3apl(ptr %s0, ptr %l8)
  store %"compiler/lower:pl" %t4, ptr %l10
  br label %bb1
bb1:
  %t5 = load i32, ptr %l2, !tbaa !23
  %t6 = load i64, ptr %l3, !tbaa !24
  %t7 = load ptr, ptr %l7, !tbaa !29
  %t8 = load %"compiler/lower:pl", ptr %l10
  %t11 = call %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2epackedField(ptr %v0, ptr %s0, ptr %v2, ptr %v3, ptr %t7, %"compiler/lower:pl" %t8, i32 %t5, i64 %t6)
  store %"compiler/lower:pl" %t11, ptr %l13
  br label %bb2
bb2:
  %t12 = load %"compiler/lower:pl", ptr %l13
  store %"compiler/lower:pl" %t12, ptr %l5
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/lower:lowering", ptr %t13, i32 0, i32 0
  %t16 = load ptr, ptr %t15, !tbaa !29
  store ptr %t16, ptr %l15, !tbaa !29
  %t17 = load ptr, ptr %l15, !tbaa !29
  %t18 = call ptr @__olang_scope_or(ptr %v4, ptr %t17)
  %t19 = call ptr @__olang_scope_hold(ptr %t18)
  %t20 = ptrtoint ptr %t19 to i64
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/lower:lowering", ptr %t21, i32 0, i32 0
  %t24 = load ptr, ptr %t23, !tbaa !29
  %t26 = call ptr @__olang_scope_or(ptr %v4, ptr %t24)
  %t27 = call ptr @__olang_scope_hold(ptr %t26)
  %t28 = ptrtoint ptr %t27 to i64
  %t30 = inttoptr i64 %t20 to ptr
  %t32 = inttoptr i64 %t28 to ptr
  %t33 = load ptr, ptr %l15, !tbaa !29
  %t34 = call ptr @compiler_2flower_2ecompiler_2flower_3aLowerer_2eGen(ptr %t30, ptr %t32, ptr %t33)
  store ptr %t34, ptr %l20
  br label %bb3
bb3:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/lower:lowering", ptr %t35, i32 0, i32 2
  %t38 = load ptr, ptr %t37, !tbaa !29
  store ptr %t38, ptr %l22, !tbaa !29
  %t39 = load i32, ptr %l2, !tbaa !23
  %t40 = load i64, ptr %l3, !tbaa !24
  %t41 = load ptr, ptr %l20, !tbaa !29
  %t42 = call ptr @__olang_scope_or(ptr %v4, ptr %t41)
  %t43 = call ptr @__olang_scope_hold(ptr %t42)
  %t44 = ptrtoint ptr %t43 to i64
  %t45 = load ptr, ptr %l22, !tbaa !29
  %t46 = call ptr @__olang_scope_or(ptr %v3, ptr %t45)
  %t47 = call ptr @__olang_scope_hold(ptr %t46)
  %t48 = ptrtoint ptr %t47 to i64
  %t50 = inttoptr i64 %t44 to ptr
  %t52 = inttoptr i64 %t48 to ptr
  %t53 = load ptr, ptr %l20, !tbaa !29
  %t54 = load ptr, ptr %l22, !tbaa !29
  %t57 = call i1 @compiler_2fmir_2ecompiler_2fmir_3aGenInfo_2eWeakField(ptr %t50, ptr %t52, ptr %t53, ptr %t54, i32 %t39, i64 %t40)
  store i1 %t57, ptr %l27
  br label %bb4
bb4:
  %t58 = load i1, ptr %l27, !tbaa !21
  %t59 = xor i1 %t58, true
  br i1 %t59, label %bb5, label %bb6
bb5:
  %t61 = load %"compiler/lower:pl", ptr %l5
  call void @__olang_scope_close(ptr %s0)
  store %"compiler/lower:pl" %t61, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t64 = load i32, ptr %l2, !tbaa !23
  %t67 = call { i64, ptr } @compiler_2flower_2ecompiler_2flower_3alowering_2epartsOf(ptr %v0, ptr %s0, ptr %v3, ptr %t63, i32 %t64)
  store { i64, ptr } %t67, ptr %l32
  br label %bb8
bb8:
  %t68 = load i64, ptr %l3, !tbaa !24
  %t70 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t71 = load ptr, ptr %t70, !tbaa !27
  %t72 = getelementptr i32, ptr %t71, i64 %t68
  %t73 = load i32, ptr %t72, !tbaa !33
  store i32 %t73, ptr %l6, !tbaa !23
  %t75 = load ptr, ptr %l0, !tbaa !29
  store ptr %t75, ptr %l35, !tbaa !29
  %t76 = load ptr, ptr %l0, !tbaa !29
  store ptr %t76, ptr %l36, !tbaa !29
  %t77 = load i32, ptr %l6, !tbaa !23
  store i32 %t77, ptr %l37, !tbaa !23
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t79 = load %"compiler/lower:pl", ptr %l5
  %t82 = call %"compiler/mir:Lvalue" @compiler_2flower_2ecompiler_2flower_3alowering_2emk(ptr %v0, ptr %s0, ptr %v4, ptr %t78, %"compiler/lower:pl" %t79)
  store %"compiler/mir:Lvalue" %t82, ptr %l40
  br label %bb9
bb9:
  %t83 = load i32, ptr %l6, !tbaa !23
  store { i64, [15 x i64] } zeroinitializer, ptr %t84
  %t85 = getelementptr { i64, [15 x i64] }, ptr %t84, i32 0, i32 0
  store i64 23, ptr %t85
  %t86 = load %"compiler/mir:Lvalue", ptr %l40
  %t87 = insertvalue { %"compiler/mir:Lvalue", i32 } undef, %"compiler/mir:Lvalue" %t86, 0
  %t89 = insertvalue { %"compiler/mir:Lvalue", i32 } %t87, i32 %t83, 1
  %t90 = getelementptr { i64, [15 x i64] }, ptr %t84, i32 0, i32 1
  store { %"compiler/mir:Lvalue", i32 } %t89, ptr %t90
  %t91 = load { i64, [15 x i64] }, ptr %t84
  %t92 = load %"compiler/source:Span", ptr %l4
  %t93 = load ptr, ptr %l36, !tbaa !29
  %t94 = load i32, ptr %l37, !tbaa !23
  %t97 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %v3, ptr %v4, ptr %t93, i32 %t94, { i64, [15 x i64] } %t91, %"compiler/source:Span" %t92)
  store { i64, [4 x i64] } %t97, ptr %l44
  br label %bb10
bb10:
  %t98 = load i32, ptr %l6, !tbaa !23
  %t99 = load %"compiler/source:Span", ptr %l4
  %t100 = load ptr, ptr %l35, !tbaa !29
  %t101 = load { i64, [4 x i64] }, ptr %l44
  %t104 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2elocal(ptr %v0, ptr %v3, ptr %v4, ptr %t100, { i64, [4 x i64] } %t101, i32 %t98, %"compiler/source:Span" %t99)
  store i32 %t104, ptr %l47
  br label %bb11
bb11:
  store { i64, [2 x i64] } zeroinitializer, ptr %t105
  %t106 = getelementptr { i64, [2 x i64] }, ptr %t105, i32 0, i32 0
  store i64 1, ptr %t106
  %t107 = load i32, ptr %l47, !tbaa !23
  %t108 = insertvalue { i32 } undef, i32 %t107, 0
  %t109 = getelementptr { i64, [2 x i64] }, ptr %t105, i32 0, i32 1
  store { i32 } %t108, ptr %t109
  %t110 = load { i64, [2 x i64] }, ptr %t105
  %t112 = call %"compiler/lower:pl" @compiler_2flower_3apl_2ector(ptr %v2, { i64, [2 x i64] } %t110)
  store %"compiler/lower:pl" %t112, ptr %l49
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s0)
  %t113 = load %"compiler/lower:pl", ptr %l49
  store %"compiler/lower:pl" %t113, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/lower:pl", ptr %rv
  ret %"compiler/lower:pl" %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2epartsCopied(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/lower:pl" %a1, i32 %a2, { i64, [1 x i64] } %a3, %"compiler/source:Span" %a4) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l13 = alloca { i64, ptr }
  %l18 = alloca i64
  %l21 = alloca i64
  %l39 = alloca ptr
  %l40 = alloca %"compiler/lower:pl"
  %l42 = alloca %"compiler/lower:pl"
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s1
  store i64 0, ptr %l5, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l2, !tbaa !23
  %t5 = call { i64, ptr } @compiler_2flower_2ecompiler_2flower_3alowering_2epartsOf(ptr %v0, ptr %s1, ptr %v2, ptr %t1, i32 %t2)
  store { i64, ptr } %t5, ptr %l13
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t6, 0
  store i64 %t7, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t9 = load i64, ptr %l6, !tbaa !24
  %t10 = load i64, ptr %l5, !tbaa !24
  %t13 = icmp sgt i64 %t9, %t10
  br i1 %t13, label %bb2, label %bb3
bb2:
  %t15 = load i64, ptr %l7, !tbaa !24
  %t17 = icmp sgt i64 %t15, 0
  br i1 %t17, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l18, !tbaa !24
  br label %bb7
bb4:
  %t19 = load i64, ptr %l6, !tbaa !24
  %t20 = load i64, ptr %l5, !tbaa !24
  %t23 = sub i64 %t19, %t20
  %t24 = load i64, ptr %l7, !tbaa !24
  %t27 = add i64 %t23, %t24
  %t29 = sub i64 %t27, 1
  %t30 = load i64, ptr %l7, !tbaa !24
  %t33 = sdiv i64 %t29, %t30
  store i64 %t33, ptr %l21, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l21, !tbaa !24
  br label %bb6
bb6:
  %t35 = load i64, ptr %l21, !tbaa !24
  store i64 %t35, ptr %l18, !tbaa !24
  br label %bb7
bb7:
  %t36 = load i64, ptr %l18, !tbaa !24
  store i64 %t36, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t37 = load i64, ptr %l9, !tbaa !24
  %t38 = load i64, ptr %l8, !tbaa !24
  %t41 = icmp slt i64 %t37, %t38
  %t43 = xor i1 %t41, true
  br i1 %t43, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb15
bb10:
  br label %bb11
bb11:
  %t45 = load i64, ptr %l5, !tbaa !24
  %t46 = load i64, ptr %l9, !tbaa !24
  %t47 = load i64, ptr %l7, !tbaa !24
  %t50 = mul i64 %t46, %t47
  %t53 = add i64 %t45, %t50
  store i64 %t53, ptr %l10, !tbaa !24
  %t55 = load ptr, ptr %l0, !tbaa !29
  store ptr %t55, ptr %l39, !tbaa !29
  store %"compiler/lower:pl" %a1, ptr %l40
  %t58 = call %"compiler/lower:pl" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2flower_3apl(ptr %s2, ptr %l40)
  store %"compiler/lower:pl" %t58, ptr %l42
  br label %bb12
bb12:
  %t59 = load i32, ptr %l2, !tbaa !23
  %t60 = load i64, ptr %l10, !tbaa !24
  %t63 = load ptr, ptr %l39, !tbaa !29
  %t64 = load %"compiler/lower:pl", ptr %l42
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2epartOf(ptr %v0, ptr %s2, ptr %v2, ptr %v3, ptr %t63, %"compiler/lower:pl" %t64, i32 %t59, i64 %t60, { i64, [1 x i64] } %a3, %"compiler/source:Span" %a4)
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s2)
  br label %bb14
bb14:
  %t69 = load i64, ptr %l9, !tbaa !24
  %t72 = add i64 %t69, 1
  store i64 %t72, ptr %l9, !tbaa !24
  br label %bb8
bb15:
  call void @__olang_scope_close(ptr %s1)
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/mir:Range" @compiler_2flower_2ecompiler_2flower_3alowering_2epassed(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l18 = alloca i64
  %l21 = alloca i64
  %l43 = alloca i1
  %l46 = alloca i1
  %l54 = alloca i64
  %l55 = alloca ptr
  %l57 = alloca ptr
  %l61 = alloca { i64, [2 x i64] }
  %l62 = alloca { i64, [1 x i64] }
  %l69 = alloca %"compiler/mir:Range"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/mir:Range"
  %t63 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l1, !tbaa !24
  store i64 %t1, ptr %l10, !tbaa !24
  %t2 = load i64, ptr %l10, !tbaa !24
  %t3 = icmp sge i64 %t2, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load i64, ptr %l10, !tbaa !24
  %t6 = icmp sle i64 %t5, 576460752303423487
  br i1 %t6, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_279896acdd8c6bde_4c10668047ad718a)
  unreachable
bb3:
  %t8 = load i64, ptr %l10, !tbaa !24
  %t9 = mul i64 %t8, 16
  %t10 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t9)
  %t11 = insertvalue { i64, ptr } undef, i64 %t8, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t14 = load i64, ptr %l1, !tbaa !24
  store i64 %t14, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t16 = load i64, ptr %l5, !tbaa !24
  %t17 = load i64, ptr %l4, !tbaa !24
  %t20 = icmp sgt i64 %t16, %t17
  br i1 %t20, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_279896acdd8c6bde_4c10668047ad718a)
  unreachable
bb5:
  %t22 = load i64, ptr %l6, !tbaa !24
  %t24 = icmp sgt i64 %t22, 0
  br i1 %t24, label %bb7, label %bb8
bb6:
  store i64 0, ptr %l18, !tbaa !24
  br label %bb10
bb7:
  %t26 = load i64, ptr %l5, !tbaa !24
  %t27 = load i64, ptr %l4, !tbaa !24
  %t30 = sub i64 %t26, %t27
  %t31 = load i64, ptr %l6, !tbaa !24
  %t34 = add i64 %t30, %t31
  %t36 = sub i64 %t34, 1
  %t37 = load i64, ptr %l6, !tbaa !24
  %t40 = sdiv i64 %t36, %t37
  store i64 %t40, ptr %l21, !tbaa !24
  br label %bb9
bb8:
  store i64 0, ptr %l21, !tbaa !24
  br label %bb9
bb9:
  %t42 = load i64, ptr %l21, !tbaa !24
  store i64 %t42, ptr %l18, !tbaa !24
  br label %bb10
bb10:
  %t43 = load i64, ptr %l18, !tbaa !24
  store i64 %t43, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb11
bb11:
  %t44 = load i64, ptr %l8, !tbaa !24
  %t45 = load i64, ptr %l7, !tbaa !24
  %t48 = icmp slt i64 %t44, %t45
  %t50 = xor i1 %t48, true
  br i1 %t50, label %bb12, label %bb13
bb12:
  br label %bb27
bb13:
  br label %bb14
bb14:
  %t52 = load i64, ptr %l4, !tbaa !24
  %t53 = load i64, ptr %l8, !tbaa !24
  %t54 = load i64, ptr %l6, !tbaa !24
  %t57 = mul i64 %t53, %t54
  %t60 = add i64 %t52, %t57
  store i64 %t60, ptr %l9, !tbaa !24
  %t62 = load i64, ptr %l9, !tbaa !24
  store { i64, [1 x i64] } zeroinitializer, ptr %t63
  %t64 = getelementptr { i64, [1 x i64] }, ptr %t63, i32 0, i32 0
  store i64 2, ptr %t64
  %t65 = load { i64, [1 x i64] }, ptr %t63
  %t68 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t69 = load ptr, ptr %t68, !tbaa !27
  %t70 = getelementptr { i64, [1 x i64] }, ptr %t69, i64 %t62
  store { i64, [1 x i64] } %t65, ptr %t70
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/lower:lowering", ptr %t71, i32 0, i32 29
  %t74 = load i1, ptr %t73, !tbaa !21
  br i1 %t74, label %bb15, label %bb16
bb15:
  %t76 = load i32, ptr %l2, !tbaa !23
  %t78 = icmp sge i32 %t76, 0
  store i1 %t78, ptr %l43, !tbaa !21
  br label %bb17
bb16:
  store i1 false, ptr %l43, !tbaa !21
  br label %bb17
bb17:
  %t80 = load i1, ptr %l43, !tbaa !21
  br i1 %t80, label %bb18, label %bb19
bb18:
  %t81 = load i32, ptr %l2, !tbaa !23
  %t83 = sext i32 %t81 to i64
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr %"compiler/lower:lowering", ptr %t84, i32 0, i32 38
  %t87 = load ptr, ptr %t86, !tbaa !29
  %t89 = getelementptr %"compiler/typed:Plan", ptr %t87, i32 0, i32 0
  %t90 = load { i64, ptr }, ptr %t89, !tbaa !27
  %t92 = extractvalue { i64, ptr } %t90, 0
  %t95 = icmp slt i64 %t83, %t92
  store i1 %t95, ptr %l46, !tbaa !21
  br label %bb20
bb19:
  store i1 false, ptr %l46, !tbaa !21
  br label %bb20
bb20:
  %t97 = load i1, ptr %l46, !tbaa !21
  br i1 %t97, label %bb21, label %bb22
bb21:
  %t98 = load i64, ptr %l9, !tbaa !24
  store i64 %t98, ptr %l54, !tbaa !24
  %t99 = load ptr, ptr %l0, !tbaa !29
  store ptr %t99, ptr %l55, !tbaa !29
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t102 = getelementptr %"compiler/lower:lowering", ptr %t100, i32 0, i32 38
  %t103 = load ptr, ptr %t102, !tbaa !29
  store ptr %t103, ptr %l57, !tbaa !29
  %t104 = load i32, ptr %l2, !tbaa !23
  %t105 = load i64, ptr %l9, !tbaa !24
  %t106 = load ptr, ptr %l57, !tbaa !29
  %t107 = call ptr @__olang_scope_or(ptr %v1, ptr %t106)
  %t108 = call ptr @__olang_scope_hold(ptr %t107)
  %t109 = ptrtoint ptr %t108 to i64
  %t111 = inttoptr i64 %t109 to ptr
  %t112 = load ptr, ptr %l57, !tbaa !29
  %t115 = call { i64, [2 x i64] } @compiler_2ftyped_2ecompiler_2ftyped_3aPlan_2ePassed(ptr %t111, ptr %t112, i32 %t104, i64 %t105)
  store { i64, [2 x i64] } %t115, ptr %l61
  br label %bb23
bb22:
  br label %bb25
bb23:
  %t116 = load ptr, ptr %l55, !tbaa !29
  %t117 = load { i64, [2 x i64] }, ptr %l61
  %t118 = call { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2escopeRef(ptr %v0, ptr %v2, ptr %v1, ptr %v3, ptr %v4, ptr %t116, { i64, [2 x i64] } %t117)
  store { i64, [1 x i64] } %t118, ptr %l62
  br label %bb24
bb24:
  %t119 = load { i64, [1 x i64] }, ptr %l62
  %t120 = load i64, ptr %l54, !tbaa !24
  %t121 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t122 = load ptr, ptr %t121, !tbaa !27
  %t123 = getelementptr { i64, [1 x i64] }, ptr %t122, i64 %t120
  store { i64, [1 x i64] } %t119, ptr %t123
  br label %bb25
bb25:
  br label %bb26
bb26:
  %t124 = load i64, ptr %l8, !tbaa !24
  %t127 = add i64 %t124, 1
  store i64 %t127, ptr %l8, !tbaa !24
  br label %bb11
bb27:
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t131 = getelementptr %"compiler/lower:lowering", ptr %t129, i32 0, i32 3
  %t132 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t135 = call %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eScopeRefs(ptr %v0, ptr %s0, ptr %t131, { i64, ptr } %t132)
  store %"compiler/mir:Range" %t135, ptr %l69
  br label %bb28
bb28:
  call void @__olang_scope_close(ptr %s0)
  %t136 = load %"compiler/mir:Range", ptr %l69
  store %"compiler/mir:Range" %t136, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/mir:Range", ptr %rv
  ret %"compiler/mir:Range" %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2epatch(ptr %v0, ptr %v1, ptr %a0, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca i64
  %l7 = alloca i64
  %l12 = alloca i32
  %l14 = alloca i64
  %l16 = alloca i64
  %l21 = alloca i32
  %s0 = alloca %olang.scope
  %t37 = alloca { i64, [8 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t2 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBlockId_3e_2eLen_3ccompiler_2fmir_3aBlockId_3e(ptr %v1, ptr %l1)
  store i64 %t2, ptr %l7
  br label %bb1
bb1:
  %t3 = load i64, ptr %l7, !tbaa !24
  %t4 = icmp eq i64 %t3, 0
  br i1 %t4, label %bb2, label %bb3
bb2:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/lower:lowering", ptr %t6, i32 0, i32 12
  store i1 true, ptr %t8, !tbaa !21
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb3:
  br label %bb4
bb4:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/lower:lowering", ptr %t9, i32 0, i32 3
  %t13 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t11)
  store i32 %t13, ptr %l12
  br label %bb5
bb5:
  %t14 = load i32, ptr %l12, !tbaa !23
  store i32 %t14, ptr %l2, !tbaa !23
  store ptr %l1, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  br label %bb6
bb6:
  %t16 = load i64, ptr %l4, !tbaa !24
  store i64 %t16, ptr %l14, !tbaa !24
  %t17 = load ptr, ptr %l3, !tbaa !29
  %t19 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBlockId_3e_2eLen_3ccompiler_2fmir_3aBlockId_3e(ptr %s0, ptr %t17)
  store i64 %t19, ptr %l16
  br label %bb7
bb7:
  %t20 = load i64, ptr %l14, !tbaa !24
  %t21 = load i64, ptr %l16, !tbaa !24
  %t22 = icmp slt i64 %t20, %t21
  %t24 = xor i1 %t22, true
  br i1 %t24, label %bb8, label %bb9
bb8:
  br label %bb14
bb9:
  br label %bb10
bb10:
  %t26 = load ptr, ptr %l3, !tbaa !29
  %t27 = load i64, ptr %l4, !tbaa !24
  %t30 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBlockId_3e_2eAt_3ccompiler_2fmir_3aBlockId_3e(ptr %s0, ptr %t26, i64 %t27)
  store i32 %t30, ptr %l21
  br label %bb11
bb11:
  %t31 = load i32, ptr %l21, !tbaa !23
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/lower:lowering", ptr %t32, i32 0, i32 3
  %t36 = load i32, ptr %l2, !tbaa !23
  store { i64, [8 x i64] } zeroinitializer, ptr %t37
  %t38 = getelementptr { i64, [8 x i64] }, ptr %t37, i32 0, i32 0
  store i64 1, ptr %t38
  %t40 = insertvalue { i32 } undef, i32 %t36, 0
  %t41 = getelementptr { i64, [8 x i64] }, ptr %t37, i32 0, i32 1
  store { i32 } %t40, ptr %t41
  %t42 = load { i64, [8 x i64] }, ptr %t37
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eEnd(ptr %v0, ptr %t34, i32 %t31, { i64, [8 x i64] } %t42)
  br label %bb12
bb12:
  br label %bb13
bb13:
  %t46 = load i64, ptr %l4, !tbaa !24
  %t49 = add i64 %t46, 1
  store i64 %t49, ptr %l4, !tbaa !24
  br label %bb6
bb14:
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t52 = load i32, ptr %l2, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t51, i32 %t52)
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2epayload(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %v6, ptr %a0, ptr %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca %"compiler/lower:pl"
  %l10 = alloca %"compiler/lower:pl"
  %l18 = alloca ptr
  %l19 = alloca i32
  %l20 = alloca ptr
  %l21 = alloca %"compiler/lower:pl"
  %l23 = alloca %"compiler/lower:pl"
  %l24 = alloca %"compiler/mir:Lvalue"
  %l27 = alloca { i64, [4 x i64] }
  %l28 = alloca ptr
  %l29 = alloca i32
  %l30 = alloca i32
  %l31 = alloca { i64, [4 x i64] }
  %l35 = alloca { i64, [4 x i64] }
  %l36 = alloca { i64, ptr }
  %l38 = alloca { i64, [4 x i64] }
  %l51 = alloca %"compiler/lower:pl"
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca %"compiler/lower:pl"
  %t37 = alloca { i64, [15 x i64] }, align 8
  %t101 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t4 = getelementptr %"compiler/typed:Payload", ptr %t2, i32 0, i32 0
  %t5 = load ptr, ptr %t4, !tbaa !29
  %t9 = call %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2eplace(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %v6, ptr %t1, ptr %t5)
  store %"compiler/lower:pl" %t9, ptr %l10
  br label %bb1
bb1:
  %t10 = load %"compiler/lower:pl", ptr %l10
  store %"compiler/lower:pl" %t10, ptr %l3
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/lower:lowering", ptr %t11, i32 0, i32 12
  %t14 = load i1, ptr %t13, !tbaa !21
  br i1 %t14, label %bb2, label %bb3
bb2:
  %t16 = load %"compiler/lower:pl", ptr %l3
  call void @__olang_scope_close(ptr %s0)
  store %"compiler/lower:pl" %t16, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t18 = load ptr, ptr %l1, !tbaa !29
  %t20 = getelementptr %"compiler/typed:Payload", ptr %t18, i32 0, i32 2
  %t21 = load i32, ptr %t20, !range !{i32 0, i32 4}
  %t23 = trunc i64 0 to i32
  %t24 = icmp eq i32 %t21, %t23
  %t26 = xor i1 %t24, true
  br i1 %t26, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s2
  %t28 = load ptr, ptr %l0, !tbaa !29
  store ptr %t28, ptr %l18, !tbaa !29
  %t29 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  store i32 %t29, ptr %l19, !tbaa !23
  %t30 = load ptr, ptr %l0, !tbaa !29
  store ptr %t30, ptr %l20, !tbaa !29
  %t31 = load %"compiler/lower:pl", ptr %l3
  store %"compiler/lower:pl" %t31, ptr %l21
  %t33 = call %"compiler/lower:pl" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2flower_3apl(ptr %s2, ptr %l21)
  store %"compiler/lower:pl" %t33, ptr %l23
  br label %bb7
bb6:
  br label %bb13
bb7:
  %t34 = load ptr, ptr %l20, !tbaa !29
  %t35 = load %"compiler/lower:pl", ptr %l23
  %t36 = call %"compiler/mir:Lvalue" @compiler_2flower_2ecompiler_2flower_3alowering_2emk(ptr %v0, ptr %s2, ptr %v3, ptr %t34, %"compiler/lower:pl" %t35)
  store %"compiler/mir:Lvalue" %t36, ptr %l24
  br label %bb8
bb8:
  store { i64, [15 x i64] } zeroinitializer, ptr %t37
  %t38 = getelementptr { i64, [15 x i64] }, ptr %t37, i32 0, i32 0
  store i64 5, ptr %t38
  %t39 = load %"compiler/mir:Lvalue", ptr %l24
  %t40 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t39, 0
  %t41 = getelementptr { i64, [15 x i64] }, ptr %t37, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t40, ptr %t41
  %t42 = load { i64, [15 x i64] }, ptr %t37
  %t43 = load %"compiler/source:Span", ptr %l2
  %t44 = load ptr, ptr %l18, !tbaa !29
  %t45 = load i32, ptr %l19, !tbaa !23
  %t48 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %v4, ptr %v3, ptr %t44, i32 %t45, { i64, [15 x i64] } %t42, %"compiler/source:Span" %t43)
  store { i64, [4 x i64] } %t48, ptr %l27
  br label %bb9
bb9:
  %t49 = load { i64, [4 x i64] }, ptr %l27
  %t50 = load ptr, ptr %l0, !tbaa !29
  store ptr %t50, ptr %l28, !tbaa !29
  store i32 13, ptr %l29
  %t51 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t51, ptr %l30, !tbaa !23
  store { i64, [4 x i64] } %t49, ptr %l31
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t54 = load ptr, ptr %l1, !tbaa !29
  %t56 = getelementptr %"compiler/typed:Payload", ptr %t54, i32 0, i32 1
  %t57 = load i64, ptr %t56, !tbaa !24
  %t60 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2econstI64(ptr %v0, ptr %t53, i64 %t57)
  store { i64, [4 x i64] } %t60, ptr %l35
  br label %bb10
bb10:
  %t61 = mul i64 2, 40
  %t62 = call ptr @__olang_scope_alloc_zeroed(ptr %s2, i64 %t61)
  %t63 = insertvalue { i64, ptr } undef, i64 2, 0
  %t64 = insertvalue { i64, ptr } %t63, ptr %t62, 1
  store { i64, ptr } %t64, ptr %l36, !tbaa !27
  %t65 = load { i64, [4 x i64] }, ptr %l31
  %t66 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t67 = load ptr, ptr %t66, !tbaa !27
  %t68 = getelementptr { i64, [4 x i64] }, ptr %t67, i64 0
  store { i64, [4 x i64] } %t65, ptr %t68
  %t69 = load { i64, [4 x i64] }, ptr %l35
  %t70 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t71 = load ptr, ptr %t70, !tbaa !27
  %t72 = getelementptr { i64, [4 x i64] }, ptr %t71, i64 1
  store { i64, [4 x i64] } %t69, ptr %t72
  %t73 = load %"compiler/source:Span", ptr %l2
  %t74 = load ptr, ptr %l28, !tbaa !29
  %t75 = load i32, ptr %l29, !range !{i32 0, i32 54}
  %t76 = load i32, ptr %l30, !tbaa !23
  %t77 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t79 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s2, ptr %v4, ptr %v3, ptr %t74, i32 %t75, i32 %t76, { i64, ptr } %t77, %"compiler/source:Span" %t73)
  store { i64, [4 x i64] } %t79, ptr %l38
  br label %bb11
bb11:
  %t80 = load { i64, [4 x i64] }, ptr %l38
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = load ptr, ptr %l1, !tbaa !29
  %t85 = getelementptr %"compiler/typed:Payload", ptr %t83, i32 0, i32 2
  %t86 = load i32, ptr %t85, !range !{i32 0, i32 4}
  %t87 = load i64, ptr @G_2ecompiler_2flower_2eWrongCase, !tbaa !24
  %t88 = load %"compiler/source:Span", ptr %l2
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2echeck(ptr %v0, ptr %v3, ptr %v4, ptr %v5, ptr %v6, ptr %t81, { i64, [4 x i64] } %t80, i32 %t86, i32 10, i64 %t87, %"compiler/source:Span" %t88)
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s2)
  br label %bb13
bb13:
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t96 = load %"compiler/lower:pl", ptr %l3
  %t97 = load ptr, ptr %l1, !tbaa !29
  %t99 = getelementptr %"compiler/typed:Payload", ptr %t97, i32 0, i32 1
  %t100 = load i64, ptr %t99, !tbaa !24
  store { i64, [1 x i64] } zeroinitializer, ptr %t101
  %t102 = getelementptr { i64, [1 x i64] }, ptr %t101, i32 0, i32 0
  store i64 4, ptr %t102
  %t104 = insertvalue { i64 } undef, i64 %t100, 0
  %t105 = getelementptr { i64, [1 x i64] }, ptr %t101, i32 0, i32 1
  store { i64 } %t104, ptr %t105
  %t106 = load { i64, [1 x i64] }, ptr %t101
  %t110 = call %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2ewith(ptr %v0, ptr %s0, ptr %v2, ptr %t95, %"compiler/lower:pl" %t96, { i64, [1 x i64] } %t106)
  store %"compiler/lower:pl" %t110, ptr %l51
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s0)
  %t111 = load %"compiler/lower:pl", ptr %l51
  store %"compiler/lower:pl" %t111, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/lower:pl", ptr %rv
  ret %"compiler/lower:pl" %rr
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eplaceRooted(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call i1 @compiler_2ftyped_2ePlaceRooted(ptr %v1, ptr %a1)
  store i1 %t3, ptr %l3
  br label %bb1
bb1:
  %t4 = load i1, ptr %l3, !tbaa !21
  store i1 %t4, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eplaceStorage(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca { i64, [1 x i64] }
  %l4 = alloca ptr
  %l5 = alloca i1
  %l12 = alloca { i64, [1 x i64] }
  %rv = alloca { i64, [1 x i64] }
  %t22 = alloca { i64, [1 x i64] }, align 8
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t17 = load i32, ptr %l2, !tbaa !23
  %t20 = call { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2estorageOf(ptr %v0, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, i32 %t17)
  store { i64, [1 x i64] } %t20, ptr %l12
  br label %bb6
bb6:
  %t21 = load { i64, [1 x i64] }, ptr %l12
  store { i64, [1 x i64] } %t21, ptr %l3
  br label %bb12
bb7:
  br i1 true, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb11
bb10:
  store { i64, [1 x i64] } zeroinitializer, ptr %t22
  %t23 = getelementptr { i64, [1 x i64] }, ptr %t22, i32 0, i32 0
  store i64 2, ptr %t23
  %t24 = load { i64, [1 x i64] }, ptr %t22
  store { i64, [1 x i64] } %t24, ptr %l3
  br label %bb12
bb11:
  call void @__olang_check_failed(ptr @olang_loc_4fc653f117519a1d_d526ff90513f5371)
  unreachable
bb12:
  %t26 = load { i64, [1 x i64] }, ptr %l3
  store { i64, [1 x i64] } %t26, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [1 x i64] }, ptr %rv
  ret { i64, [1 x i64] } %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2epopIf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, [4 x i64] } %a1, i32 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca { i64, [4 x i64] }
  %l5 = alloca i32
  %l6 = alloca i32
  %l11 = alloca { i64, [4 x i64] }
  %l16 = alloca i32
  %l19 = alloca i32
  %s0 = alloca %olang.scope
  %t32 = alloca { i64, [8 x i64] }, align 8
  %t50 = alloca { i64, [21 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t4 = load %"compiler/source:Span", ptr %l3
  %t9 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ecarries(ptr %v0, ptr %v1, ptr %v2, ptr %t1, { i64, [4 x i64] } %a1, i32 %a2, %"compiler/source:Span" %t4)
  store { i64, [4 x i64] } %t9, ptr %l11
  br label %bb1
bb1:
  %t10 = load { i64, [4 x i64] }, ptr %l11
  store { i64, [4 x i64] } %t10, ptr %l4
  %t11 = load { i64, [4 x i64] }, ptr %l4
  %t13 = extractvalue { i64, [4 x i64] } %t11, 0
  %t14 = icmp eq i64 %t13, 0
  br i1 %t14, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb3:
  br label %bb4
bb4:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/lower:lowering", ptr %t16, i32 0, i32 3
  %t20 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t18)
  store i32 %t20, ptr %l16
  br label %bb5
bb5:
  %t21 = load i32, ptr %l16, !tbaa !23
  store i32 %t21, ptr %l5, !tbaa !23
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/lower:lowering", ptr %t22, i32 0, i32 3
  %t26 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t24)
  store i32 %t26, ptr %l19
  br label %bb6
bb6:
  %t27 = load i32, ptr %l19, !tbaa !23
  store i32 %t27, ptr %l6, !tbaa !23
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load { i64, [4 x i64] }, ptr %l4
  %t30 = load i32, ptr %l5, !tbaa !23
  %t31 = load i32, ptr %l6, !tbaa !23
  store { i64, [8 x i64] } zeroinitializer, ptr %t32
  %t33 = getelementptr { i64, [8 x i64] }, ptr %t32, i32 0, i32 0
  store i64 2, ptr %t33
  %t35 = insertvalue { { i64, [4 x i64] }, i32, i32 } undef, { i64, [4 x i64] } %t29, 0
  %t37 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t35, i32 %t30, 1
  %t39 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t37, i32 %t31, 2
  %t40 = getelementptr { i64, [8 x i64] }, ptr %t32, i32 0, i32 1
  store { { i64, [4 x i64] }, i32, i32 } %t39, ptr %t40
  %t41 = load { i64, [8 x i64] }, ptr %t32
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %v2, ptr %v1, ptr %t28, { i64, [8 x i64] } %t41)
  br label %bb7
bb7:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t45 = load i32, ptr %l5, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t44, i32 %t45)
  br label %bb8
bb8:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t49 = load %"compiler/source:Span", ptr %l3
  store { i64, [21 x i64] } zeroinitializer, ptr %t50
  %t51 = getelementptr { i64, [21 x i64] }, ptr %t50, i32 0, i32 0
  store i64 16, ptr %t51
  %t53 = insertvalue { %"compiler/source:Span" } undef, %"compiler/source:Span" %t49, 0
  %t54 = getelementptr { i64, [21 x i64] }, ptr %t50, i32 0, i32 1
  store { %"compiler/source:Span" } %t53, ptr %t54
  %t55 = load { i64, [21 x i64] }, ptr %t50
  %t57 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t55, ptr %t57
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s0, ptr %v1, ptr %v2, ptr %t48, ptr %t57)
  br label %bb9
bb9:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t61 = load i32, ptr %l6, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2egoto(ptr %v0, ptr %v2, ptr %v1, ptr %t60, i32 %t61)
  br label %bb10
bb10:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t65 = load i32, ptr %l6, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t64, i32 %t65)
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, i32 %a1, i32 %a2, { i64, ptr } %a3, %"compiler/source:Span" %a4) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i32
  %l12 = alloca %"compiler/mir:Range"
  %l15 = alloca { i64, [4 x i64] }
  %rv = alloca { i64, [4 x i64] }
  %t12 = alloca { i64, [15 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  %t2 = load i32, ptr %l2, !tbaa !23
  store i32 %t2, ptr %l6, !tbaa !23
  store i32 %a1, ptr %l7
  %t4 = load i32, ptr %l2, !tbaa !23
  store i32 %t4, ptr %l8, !tbaa !23
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/lower:lowering", ptr %t5, i32 0, i32 3
  %t11 = call %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eArgs(ptr %v0, ptr %v1, ptr %t7, { i64, ptr } %a3)
  store %"compiler/mir:Range" %t11, ptr %l12
  br label %bb1
bb1:
  store { i64, [15 x i64] } zeroinitializer, ptr %t12
  %t13 = getelementptr { i64, [15 x i64] }, ptr %t12, i32 0, i32 0
  store i64 3, ptr %t13
  %t14 = load i32, ptr %l7, !range !{i32 0, i32 54}
  %t15 = insertvalue { i32, i32, %"compiler/mir:Range" } undef, i32 %t14, 0
  %t16 = load i32, ptr %l8, !tbaa !23
  %t17 = insertvalue { i32, i32, %"compiler/mir:Range" } %t15, i32 %t16, 1
  %t18 = load %"compiler/mir:Range", ptr %l12
  %t19 = insertvalue { i32, i32, %"compiler/mir:Range" } %t17, %"compiler/mir:Range" %t18, 2
  %t20 = getelementptr { i64, [15 x i64] }, ptr %t12, i32 0, i32 1
  store { i32, i32, %"compiler/mir:Range" } %t19, ptr %t20
  %t21 = load { i64, [15 x i64] }, ptr %t12
  %t23 = load ptr, ptr %l5, !tbaa !29
  %t24 = load i32, ptr %l6, !tbaa !23
  %t27 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %v2, ptr %v3, ptr %t23, i32 %t24, { i64, [15 x i64] } %t21, %"compiler/source:Span" %a4)
  store { i64, [4 x i64] } %t27, ptr %l15
  br label %bb2
bb2:
  %t28 = load { i64, [4 x i64] }, ptr %l15
  store { i64, [4 x i64] } %t28, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2epromote(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l12 = alloca i32
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l17 = alloca i32
  %l19 = alloca i1
  %l20 = alloca i1
  %l24 = alloca i1
  %l27 = alloca i64
  %l31 = alloca ptr
  %l41 = alloca { i64, [4 x i64] }
  %l44 = alloca ptr
  %l48 = alloca i1
  %l51 = alloca i64
  %l59 = alloca { i64, [4 x i64] }
  %l60 = alloca { i64, [4 x i64] }
  %l66 = alloca { i64, [4 x i64] }
  %l67 = alloca i32
  %l69 = alloca i1
  %l74 = alloca { i64, [4 x i64] }
  %l79 = alloca { i64, [4 x i64] }
  %rv = alloca { i64, [4 x i64] }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  store %"compiler/source:Span" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t7 = load i32, ptr %l2, !tbaa !23
  %t10 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2earrayOf(ptr %v0, ptr %v2, ptr %t6, i32 %t7)
  store i32 %t10, ptr %l12
  br label %bb1
bb1:
  %t11 = load i32, ptr %l12, !tbaa !23
  store i32 %t11, ptr %l5, !tbaa !23
  %t12 = load ptr, ptr %l4, !tbaa !29
  store ptr %t12, ptr %l13, !tbaa !29
  %t13 = load ptr, ptr %l4, !tbaa !29
  store ptr %t13, ptr %l14, !tbaa !29
  %t14 = load i32, ptr %l2, !tbaa !23
  %t15 = load ptr, ptr %l14, !tbaa !29
  %t16 = call ptr @__olang_scope_or(ptr %v2, ptr %t15)
  %t17 = call ptr @__olang_scope_hold(ptr %t16)
  %t18 = ptrtoint ptr %t17 to i64
  %t20 = inttoptr i64 %t18 to ptr
  %t21 = load ptr, ptr %l14, !tbaa !29
  %t23 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %t20, ptr %t21, i32 %t14)
  store i32 %t23, ptr %l17
  br label %bb2
bb2:
  %t24 = load ptr, ptr %l13, !tbaa !29
  %t25 = call ptr @__olang_scope_or(ptr %v2, ptr %t24)
  %t26 = call ptr @__olang_scope_hold(ptr %t25)
  %t27 = ptrtoint ptr %t26 to i64
  %t29 = inttoptr i64 %t27 to ptr
  %t30 = load ptr, ptr %l13, !tbaa !29
  %t31 = load i32, ptr %l17, !tbaa !23
  %t32 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %t29, ptr %t30, i32 %t31)
  store i1 %t32, ptr %l19
  br label %bb3
bb3:
  %t33 = load i1, ptr %l19, !tbaa !21
  br i1 %t33, label %bb4, label %bb5
bb4:
  %t34 = load i32, ptr %l5, !tbaa !23
  %t35 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t38 = icmp ne i32 %t34, %t35
  store i1 %t38, ptr %l20, !tbaa !21
  br label %bb6
bb5:
  store i1 false, ptr %l20, !tbaa !21
  br label %bb6
bb6:
  %t40 = load i1, ptr %l20, !tbaa !21
  br i1 %t40, label %bb7, label %bb8
bb7:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t42 = load i32, ptr %l5, !tbaa !23
  %t45 = call i64 @compiler_2flower_2ecompiler_2flower_3alowering_2efixedLen(ptr %v0, ptr %v2, ptr %t41, i32 %t42)
  store i64 %t45, ptr %l27
  br label %bb9
bb8:
  store i1 false, ptr %l24, !tbaa !21
  br label %bb10
bb9:
  %t46 = load i64, ptr %l27, !tbaa !24
  %t47 = icmp slt i64 %t46, 0
  store i1 %t47, ptr %l24, !tbaa !21
  br label %bb10
bb10:
  %t49 = load i1, ptr %l24, !tbaa !21
  br i1 %t49, label %bb11, label %bb12
bb11:
  %t50 = load ptr, ptr %l1, !tbaa !29
  %t52 = getelementptr %"compiler/typed:Promote", ptr %t50, i32 0, i32 0
  %t53 = load ptr, ptr %t52, !tbaa !29
  %t55 = call ptr @compiler_2flower_2econdOf(ptr %v1, ptr %v1, ptr %t53)
  store ptr %t55, ptr %l31
  br label %bb13
bb12:
  br label %bb32
bb13:
  %t56 = load ptr, ptr %l31, !tbaa !29
  store ptr %t56, ptr %l6, !tbaa !29
  %t57 = load ptr, ptr %l6, !tbaa !29
  %t59 = icmp eq ptr %t57, null
  %t61 = xor i1 %t59, true
  br i1 %t61, label %bb14, label %bb15
bb14:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t64 = load ptr, ptr %l6, !tbaa !29
  %t65 = load ptr, ptr %l1, !tbaa !29
  %t67 = getelementptr %"compiler/typed:Promote", ptr %t65, i32 0, i32 1
  %t68 = load i32, ptr %t67, !tbaa !23
  %t69 = load i32, ptr %l2, !tbaa !23
  %t70 = load %"compiler/source:Span", ptr %l3
  %t76 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2epromotedCond(ptr %v0, ptr %v1, ptr %v3, ptr %v2, ptr %v4, ptr %v5, ptr %t63, ptr %t64, i32 %t68, i32 %t69, %"compiler/source:Span" %t70)
  store { i64, [4 x i64] } %t76, ptr %l41
  br label %bb16
bb15:
  br label %bb17
bb16:
  %t77 = load { i64, [4 x i64] }, ptr %l41
  store { i64, [4 x i64] } %t77, ptr %rv
  br label %ret
bb17:
  %t78 = load ptr, ptr %l1, !tbaa !29
  %t80 = getelementptr %"compiler/typed:Promote", ptr %t78, i32 0, i32 0
  %t81 = load ptr, ptr %t80, !tbaa !29
  %t83 = call ptr @compiler_2flower_2edefaultTry(ptr %v1, ptr %v1, ptr %t81)
  store ptr %t83, ptr %l44
  br label %bb18
bb18:
  %t84 = load ptr, ptr %l44, !tbaa !29
  store ptr %t84, ptr %l7, !tbaa !29
  %t85 = load ptr, ptr %l7, !tbaa !29
  %t87 = icmp eq ptr %t85, null
  %t89 = xor i1 %t87, true
  br i1 %t89, label %bb19, label %bb20
bb19:
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t93 = getelementptr %"compiler/lower:lowering", ptr %t91, i32 0, i32 59
  %t95 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3arelPath_3e_2eLen_3ccompiler_2flower_3arelPath_3e(ptr %v0, ptr %t93)
  store i64 %t95, ptr %l51
  br label %bb21
bb20:
  store i1 false, ptr %l48, !tbaa !21
  br label %bb22
bb21:
  %t96 = load i64, ptr %l51, !tbaa !24
  %t97 = icmp eq i64 %t96, 0
  store i1 %t97, ptr %l48, !tbaa !21
  br label %bb22
bb22:
  %t99 = load i1, ptr %l48, !tbaa !21
  br i1 %t99, label %bb23, label %bb24
bb23:
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t101 = load ptr, ptr %l7, !tbaa !29
  %t102 = load i32, ptr %l2, !tbaa !23
  %t103 = load %"compiler/source:Span", ptr %l3
  %t104 = load ptr, ptr %l1, !tbaa !29
  %t106 = getelementptr %"compiler/typed:Promote", ptr %t104, i32 0, i32 1
  %t107 = load i32, ptr %t106, !tbaa !23
  %t113 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2etryAt(ptr %v0, ptr %v1, ptr %v3, ptr %v2, ptr %v4, ptr %v5, ptr %t100, ptr %t101, i32 %t102, %"compiler/source:Span" %t103, i32 %t107)
  store { i64, [4 x i64] } %t113, ptr %l59
  br label %bb25
bb24:
  br label %bb26
bb25:
  %t114 = load { i64, [4 x i64] }, ptr %l59
  store { i64, [4 x i64] } %t114, ptr %rv
  br label %ret
bb26:
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t116 = load ptr, ptr %l1, !tbaa !29
  %t117 = load i32, ptr %l2, !tbaa !23
  %t118 = load %"compiler/source:Span", ptr %l3
  %t119 = load i32, ptr %l5, !tbaa !23
  %t125 = call { i32, { i64, [4 x i64] } } @compiler_2flower_2ecompiler_2flower_3alowering_2epromotedInPlace(ptr %v0, ptr %v1, ptr %v4, ptr %v3, ptr %v2, ptr %v5, ptr %t115, ptr %t116, i32 %t117, %"compiler/source:Span" %t118, i32 %t119)
  %t126 = extractvalue { i32, { i64, [4 x i64] } } %t125, 1
  %t127 = extractvalue { i32, { i64, [4 x i64] } } %t125, 0
  store i32 %t127, ptr %l67
  %t128 = icmp ne i32 %t127, 0
  br i1 %t128, label %bb28, label %ok.129, !prof !99
ok.129:
  store { i64, [4 x i64] } %t126, ptr %l66
  br label %bb27
bb27:
  %t130 = load { i64, [4 x i64] }, ptr %l66
  store { i64, [4 x i64] } %t130, ptr %l60
  br label %bb31
bb28:
  %t131 = load i32, ptr %l67, !tbaa !23
  %t132 = ashr i32 %t131, 16
  %t134 = icmp eq i32 %t132, 1
  store i1 %t134, ptr %l69, !tbaa !21
  br label %bb29
bb29:
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t136 = load ptr, ptr %l1, !tbaa !29
  %t137 = load i32, ptr %l2, !tbaa !23
  %t138 = load %"compiler/source:Span", ptr %l3
  %t143 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2epromoteNew(ptr %v0, ptr %v1, ptr %v3, ptr %v2, ptr %v4, ptr %v5, ptr %t135, ptr %t136, i32 %t137, %"compiler/source:Span" %t138)
  store { i64, [4 x i64] } %t143, ptr %l74
  br label %bb30
bb30:
  %t144 = load { i64, [4 x i64] }, ptr %l74
  store { i64, [4 x i64] } %t144, ptr %l60
  br label %bb31
bb31:
  %t145 = load { i64, [4 x i64] }, ptr %l60
  store { i64, [4 x i64] } %t145, ptr %rv
  br label %ret
bb32:
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t147 = load ptr, ptr %l1, !tbaa !29
  %t148 = load i32, ptr %l2, !tbaa !23
  %t149 = load %"compiler/source:Span", ptr %l3
  %t154 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2epromoteNew(ptr %v0, ptr %v1, ptr %v3, ptr %v2, ptr %v4, ptr %v5, ptr %t146, ptr %t147, i32 %t148, %"compiler/source:Span" %t149)
  store { i64, [4 x i64] } %t154, ptr %l79
  br label %bb33
bb33:
  %t155 = load { i64, [4 x i64] }, ptr %l79
  store { i64, [4 x i64] } %t155, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2epromoteNew(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca { i64, [4 x i64] }
  %l5 = alloca { i64, [1 x i64] }
  %l6 = alloca { i64, [4 x i64] }
  %l7 = alloca ptr
  %l12 = alloca { i64, [4 x i64] }
  %l19 = alloca { i64, [1 x i64] }
  %l27 = alloca { i64, [4 x i64] }
  %l30 = alloca ptr
  %l33 = alloca i1
  %l34 = alloca i1
  %l35 = alloca ptr
  %l36 = alloca ptr
  %l39 = alloca i32
  %l41 = alloca i1
  %l42 = alloca ptr
  %l43 = alloca %"compiler/source:Span"
  %l44 = alloca { i64, [1 x i64] }
  %l45 = alloca ptr
  %l48 = alloca i32
  %s2 = alloca %olang.scope
  %rv = alloca { i64, [4 x i64] }
  %t16 = alloca { i64, [4 x i64] }, align 8
  %t34 = alloca { i64, [15 x i64] }, align 8
  %t106 = alloca { i64, [21 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  store %"compiler/source:Span" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t4 = getelementptr %"compiler/typed:Promote", ptr %t2, i32 0, i32 0
  %t5 = load ptr, ptr %t4, !tbaa !29
  %t9 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %t1, ptr %t5)
  store { i64, [4 x i64] } %t9, ptr %l12
  br label %bb1
bb1:
  %t10 = load { i64, [4 x i64] }, ptr %l12
  store { i64, [4 x i64] } %t10, ptr %l4
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/lower:lowering", ptr %t11, i32 0, i32 12
  %t14 = load i1, ptr %t13, !tbaa !21
  br i1 %t14, label %bb2, label %bb3
bb2:
  store { i64, [4 x i64] } zeroinitializer, ptr %t16
  %t17 = getelementptr { i64, [4 x i64] }, ptr %t16, i32 0, i32 0
  store i64 0, ptr %t17
  %t18 = load { i64, [4 x i64] }, ptr %t16
  store { i64, [4 x i64] } %t18, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load ptr, ptr %l1, !tbaa !29
  %t23 = getelementptr %"compiler/typed:Promote", ptr %t21, i32 0, i32 1
  %t24 = load i32, ptr %t23, !tbaa !23
  %t27 = call { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ebuilt(ptr %v0, ptr %v4, ptr %v5, ptr %v3, ptr %v2, ptr %t20, i32 %t24)
  store { i64, [1 x i64] } %t27, ptr %l19
  br label %bb5
bb5:
  %t28 = load { i64, [1 x i64] }, ptr %l19
  store { i64, [1 x i64] } %t28, ptr %l5
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t30 = load i32, ptr %l2, !tbaa !23
  %t31 = load { i64, [1 x i64] }, ptr %l5
  %t32 = load { i64, [4 x i64] }, ptr %l4
  %t33 = load i32, ptr %l2, !tbaa !23
  store { i64, [15 x i64] } zeroinitializer, ptr %t34
  %t35 = getelementptr { i64, [15 x i64] }, ptr %t34, i32 0, i32 0
  store i64 7, ptr %t35
  %t37 = insertvalue { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 } undef, { i64, [1 x i64] } %t31, 0
  %t39 = insertvalue { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 } %t37, { i64, [4 x i64] } %t32, 1
  %t41 = insertvalue { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 } %t39, i32 %t33, 2
  %t42 = getelementptr { i64, [15 x i64] }, ptr %t34, i32 0, i32 1
  store { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 } %t41, ptr %t42
  %t43 = load { i64, [15 x i64] }, ptr %t34
  %t44 = load %"compiler/source:Span", ptr %l3
  %t49 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %v3, ptr %v2, ptr %t29, i32 %t30, { i64, [15 x i64] } %t43, %"compiler/source:Span" %t44)
  store { i64, [4 x i64] } %t49, ptr %l27
  br label %bb6
bb6:
  %t50 = load { i64, [4 x i64] }, ptr %l27
  store { i64, [4 x i64] } %t50, ptr %l6
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = getelementptr %"compiler/lower:lowering", ptr %t51, i32 0, i32 2
  %t54 = load ptr, ptr %t53, !tbaa !29
  store ptr %t54, ptr %l7, !tbaa !29
  %t56 = load ptr, ptr %l7, !tbaa !29
  store ptr %t56, ptr %l30, !tbaa !29
  %t57 = load i32, ptr %l2, !tbaa !23
  %t58 = load ptr, ptr %l30, !tbaa !29
  %t59 = call ptr @__olang_scope_or(ptr %v3, ptr %t58)
  %t60 = call ptr @__olang_scope_hold(ptr %t59)
  %t61 = ptrtoint ptr %t60 to i64
  %t63 = inttoptr i64 %t61 to ptr
  %t64 = load ptr, ptr %l30, !tbaa !29
  %t66 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %t63, ptr %t64, i32 %t57)
  store i1 %t66, ptr %l33
  br label %bb7
bb7:
  %t67 = load i1, ptr %l33, !tbaa !21
  br i1 %t67, label %bb8, label %bb9
bb8:
  %t68 = load ptr, ptr %l7, !tbaa !29
  store ptr %t68, ptr %l35, !tbaa !29
  %t69 = load ptr, ptr %l7, !tbaa !29
  store ptr %t69, ptr %l36, !tbaa !29
  %t70 = load i32, ptr %l2, !tbaa !23
  %t71 = load ptr, ptr %l36, !tbaa !29
  %t72 = call ptr @__olang_scope_or(ptr %v3, ptr %t71)
  %t73 = call ptr @__olang_scope_hold(ptr %t72)
  %t74 = ptrtoint ptr %t73 to i64
  %t76 = inttoptr i64 %t74 to ptr
  %t77 = load ptr, ptr %l36, !tbaa !29
  %t79 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %t76, ptr %t77, i32 %t70)
  store i32 %t79, ptr %l39
  br label %bb10
bb9:
  store i1 false, ptr %l34, !tbaa !21
  br label %bb12
bb10:
  %t80 = load ptr, ptr %l35, !tbaa !29
  %t81 = call ptr @__olang_scope_or(ptr %v3, ptr %t80)
  %t82 = call ptr @__olang_scope_hold(ptr %t81)
  %t83 = ptrtoint ptr %t82 to i64
  %t85 = inttoptr i64 %t83 to ptr
  %t86 = load ptr, ptr %l35, !tbaa !29
  %t87 = load i32, ptr %l39, !tbaa !23
  %t88 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNeedsDrop(ptr %t85, ptr %t86, i32 %t87)
  store i1 %t88, ptr %l41
  br label %bb11
bb11:
  %t89 = load i1, ptr %l41, !tbaa !21
  store i1 %t89, ptr %l34, !tbaa !21
  br label %bb12
bb12:
  %t90 = load i1, ptr %l34, !tbaa !21
  br i1 %t90, label %bb13, label %bb14
bb13:
  store %olang.scope zeroinitializer, ptr %s2
  %t91 = load ptr, ptr %l0, !tbaa !29
  store ptr %t91, ptr %l42, !tbaa !29
  %t92 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t92, ptr %l43
  %t93 = load { i64, [1 x i64] }, ptr %l5
  store { i64, [1 x i64] } %t93, ptr %l44
  %t94 = load ptr, ptr %l7, !tbaa !29
  store ptr %t94, ptr %l45, !tbaa !29
  %t95 = load i32, ptr %l2, !tbaa !23
  %t96 = load ptr, ptr %l45, !tbaa !29
  %t97 = call ptr @__olang_scope_or(ptr %v3, ptr %t96)
  %t98 = call ptr @__olang_scope_hold(ptr %t97)
  %t99 = ptrtoint ptr %t98 to i64
  %t101 = inttoptr i64 %t99 to ptr
  %t102 = load ptr, ptr %l45, !tbaa !29
  %t104 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %t101, ptr %t102, i32 %t95)
  store i32 %t104, ptr %l48
  br label %bb15
bb14:
  br label %bb17
bb15:
  %t105 = load { i64, [4 x i64] }, ptr %l6
  store { i64, [21 x i64] } zeroinitializer, ptr %t106
  %t107 = getelementptr { i64, [21 x i64] }, ptr %t106, i32 0, i32 0
  store i64 5, ptr %t107
  %t108 = load %"compiler/source:Span", ptr %l43
  %t109 = insertvalue { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } undef, %"compiler/source:Span" %t108, 0
  %t110 = load { i64, [1 x i64] }, ptr %l44
  %t111 = insertvalue { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } %t109, { i64, [1 x i64] } %t110, 1
  %t112 = load i32, ptr %l48, !tbaa !23
  %t113 = insertvalue { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } %t111, i32 %t112, 2
  %t115 = insertvalue { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } %t113, { i64, [4 x i64] } %t105, 3
  %t116 = getelementptr { i64, [21 x i64] }, ptr %t106, i32 0, i32 1
  store { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } %t115, ptr %t116
  %t117 = load { i64, [21 x i64] }, ptr %t106
  %t119 = call ptr @__olang_scope_alloc_a(ptr %s2, i64 176, i64 8)
  store { i64, [21 x i64] } %t117, ptr %t119
  %t120 = load ptr, ptr %l42, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s2, ptr %v3, ptr %v2, ptr %t120, ptr %t119)
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s2)
  br label %bb17
bb17:
  %t122 = load { i64, [4 x i64] }, ptr %l6
  store { i64, [4 x i64] } %t122, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3alowering_2equiet(ptr %v0, ptr %v1, ptr %v2, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l4 = alloca i64
  %l7 = alloca i1
  %l9 = alloca i1
  %l15 = alloca i64
  %l18 = alloca ptr
  %l20 = alloca i64
  %l21 = alloca ptr
  %l26 = alloca ptr
  %l27 = alloca i1
  %l28 = alloca i64
  %l33 = alloca i64
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 81
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i64, ptr %l4, !tbaa !24
  store i64 %t6, ptr %l1, !tbaa !24
  %t7 = load i64, ptr %l1, !tbaa !24
  %t9 = icmp eq i64 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb5
bb3:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2emutStorage(ptr %v0, ptr %v1, ptr %t11)
  store i1 %t13, ptr %l9
  br label %bb4
bb4:
  %t14 = load i1, ptr %l9, !tbaa !21
  store i1 %t14, ptr %l7, !tbaa !21
  br label %bb5
bb5:
  %t15 = load i1, ptr %l7, !tbaa !21
  br i1 %t15, label %bb6, label %bb7
bb6:
  store i1 false, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/lower:lowering", ptr %t17, i32 0, i32 81
  %t20 = load i64, ptr %l1, !tbaa !24
  %t22 = sub i64 %t20, 1
  %t25 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t19, i64 %t22)
  store i64 %t25, ptr %l15
  br label %bb9
bb9:
  %t26 = load i64, ptr %l15, !tbaa !24
  %t27 = icmp slt i64 %t26, 0
  br i1 %t27, label %bb10, label %bb11
bb10:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/lower:lowering", ptr %t29, i32 0, i32 81
  store ptr %t31, ptr %l18, !tbaa !29
  %t32 = load i64, ptr %l1, !tbaa !24
  %t34 = sub i64 %t32, 1
  store i64 %t34, ptr %l20, !tbaa !24
  %t35 = load ptr, ptr %l0, !tbaa !29
  store ptr %t35, ptr %l21, !tbaa !29
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/lower:lowering", ptr %t36, i32 0, i32 80
  %t39 = load i64, ptr %l1, !tbaa !24
  %t41 = sub i64 %t39, 1
  %t44 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eAt_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t38, i64 %t41)
  store ptr %t44, ptr %l26
  br label %bb12
bb11:
  br label %bb18
bb12:
  %t45 = load ptr, ptr %l21, !tbaa !29
  %t46 = load ptr, ptr %l26, !tbaa !29
  %t47 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2equietStmt(ptr %v0, ptr %v0, ptr %v1, ptr %v2, ptr %t45, ptr %t46)
  store i1 %t47, ptr %l27
  br label %bb13
bb13:
  %t48 = load i1, ptr %l27, !tbaa !21
  br i1 %t48, label %bb14, label %bb15
bb14:
  store i64 1, ptr %l28, !tbaa !24
  br label %bb16
bb15:
  store i64 0, ptr %l28, !tbaa !24
  br label %bb16
bb16:
  %t49 = load ptr, ptr %l18, !tbaa !29
  %t50 = load i64, ptr %l20, !tbaa !24
  %t51 = load i64, ptr %l28, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t49, i64 %t50, i64 %t51)
  br label %bb17
bb17:
  br label %bb18
bb18:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/lower:lowering", ptr %t52, i32 0, i32 81
  %t55 = load i64, ptr %l1, !tbaa !24
  %t57 = sub i64 %t55, 1
  %t60 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t54, i64 %t57)
  store i64 %t60, ptr %l33
  br label %bb19
bb19:
  %t61 = load i64, ptr %l33, !tbaa !24
  %t62 = icmp eq i64 %t61, 1
  store i1 %t62, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3alowering_2equietClauses(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l14 = alloca { i64, ptr }
  %l21 = alloca i1
  %l25 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/typed:Try", ptr %a1, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t6 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  store i64 %t8, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t10 = load i64, ptr %l3, !tbaa !24
  %t11 = load i64, ptr %l4, !tbaa !24
  %t14 = icmp slt i64 %t10, %t11
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb2, label %bb3
bb2:
  br label %bb13
bb3:
  br label %bb4
bb4:
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t18, ptr %l14, !tbaa !27
  %t19 = load i64, ptr %l3, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr ptr, ptr %t22, i64 %t19
  %t24 = load ptr, ptr %t23, !tbaa !39
  store ptr %t24, ptr %l5, !tbaa !29
  %t26 = load ptr, ptr %l5, !tbaa !29
  %t28 = getelementptr %"compiler/typed:Clause", ptr %t26, i32 0, i32 3
  %t29 = load ptr, ptr %t28, !tbaa !29
  %t31 = icmp eq ptr %t29, null
  %t33 = xor i1 %t31, true
  br i1 %t33, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l21, !tbaa !21
  br label %bb8
bb6:
  %t36 = load ptr, ptr %l5, !tbaa !29
  %t38 = getelementptr %"compiler/typed:Clause", ptr %t36, i32 0, i32 4
  %t39 = load { i64, ptr }, ptr %t38, !tbaa !27
  %t42 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2equietAll(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %t39)
  store i1 %t42, ptr %l25
  br label %bb7
bb7:
  %t43 = load i1, ptr %l25, !tbaa !21
  %t44 = xor i1 %t43, true
  store i1 %t44, ptr %l21, !tbaa !21
  br label %bb8
bb8:
  %t46 = load i1, ptr %l21, !tbaa !21
  br i1 %t46, label %bb9, label %bb10
bb9:
  store i1 false, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  br label %bb12
bb12:
  %t48 = load i64, ptr %l3, !tbaa !24
  %t51 = add i64 %t48, 1
  store i64 %t51, ptr %l3, !tbaa !24
  br label %bb1
bb13:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3alowering_2equietLife(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca i1
  %l15 = alloca ptr
  %l22 = alloca ptr
  %l34 = alloca ptr
  %l36 = alloca i1
  %l38 = alloca ptr
  %l40 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/typed:Body", ptr %t4, i32 0, i32 11
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = icmp eq ptr %t7, null
  br i1 %t9, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/lower:lowering", ptr %t12, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t17 = getelementptr %"compiler/typed:Body", ptr %t15, i32 0, i32 11
  %t18 = load ptr, ptr %t17, !tbaa !29
  %t20 = icmp eq ptr %t18, null
  br i1 %t20, label %bb4, label %bb5
bb4:
  call void @__olang_check_failed(ptr @olang_loc_80847d650e26c632_64a1946959062bee)
  unreachable
bb5:
  br label %bb6
bb6:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/lower:lowering", ptr %t22, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t27 = getelementptr %"compiler/typed:Body", ptr %t25, i32 0, i32 11
  %t28 = load ptr, ptr %t27, !tbaa !29
  store ptr %t28, ptr %l15, !tbaa !29
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/lower:lowering", ptr %t29, i32 0, i32 79
  %t32 = load i32, ptr %t31, !tbaa !23
  %t33 = load ptr, ptr %l15, !tbaa !29
  %t34 = call ptr @__olang_scope_or(ptr %v1, ptr %t33)
  %t35 = call ptr @__olang_scope_hold(ptr %t34)
  %t36 = ptrtoint ptr %t35 to i64
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/lower:lowering", ptr %t37, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !29
  %t42 = call ptr @__olang_scope_or(ptr %v1, ptr %t40)
  %t43 = call ptr @__olang_scope_hold(ptr %t42)
  %t44 = ptrtoint ptr %t43 to i64
  %t46 = inttoptr i64 %t36 to ptr
  %t48 = inttoptr i64 %t44 to ptr
  %t49 = load ptr, ptr %l15, !tbaa !29
  %t51 = call ptr @compiler_2flower_2efindBlock(ptr %t46, ptr %t48, ptr %t49, i32 %t32)
  store ptr %t51, ptr %l22
  br label %bb7
bb7:
  %t52 = load ptr, ptr %l22, !tbaa !29
  store ptr %t52, ptr %l2, !tbaa !29
  %t53 = load ptr, ptr %l2, !tbaa !29
  %t55 = icmp eq ptr %t53, null
  br i1 %t55, label %bb8, label %bb9
bb8:
  store i1 false, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/lower:lowering", ptr %t58, i32 0, i32 71
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eClear_3cI64_2c_20Bool_3e(ptr %v0, ptr %t60)
  br label %bb11
bb11:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/lower:lowering", ptr %t62, i32 0, i32 75
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eClear_3cI64_2c_20Bool_3e(ptr %v0, ptr %t64)
  br label %bb12
bb12:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t67 = load i32, ptr %l1, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2ecoverAdd(ptr %v0, ptr %v2, ptr %t66, i32 %t67, i64 0)
  br label %bb13
bb13:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t71 = load i32, ptr %l1, !tbaa !23
  %t74 = getelementptr %"compiler/lower:lowering", ptr %t70, i32 0, i32 72
  store i32 %t71, ptr %t74, !tbaa !23
  %t75 = load ptr, ptr %l0, !tbaa !29
  store ptr %t75, ptr %l34, !tbaa !29
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eglobalHits(ptr %v0, ptr %v3, ptr %v2, ptr %t76)
  store i1 %t78, ptr %l36
  br label %bb14
bb14:
  %t79 = load i1, ptr %l36, !tbaa !21
  %t80 = load ptr, ptr %l34, !tbaa !29
  %t81 = getelementptr %"compiler/lower:lowering", ptr %t80, i32 0, i32 74
  store i1 %t79, ptr %t81, !tbaa !21
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t83 = load ptr, ptr %l2, !tbaa !29
  store ptr %t83, ptr %l38, !tbaa !29
  %t84 = load ptr, ptr %l38, !tbaa !29
  %t85 = call ptr @__olang_scope_or(ptr %v1, ptr %t84)
  %t86 = call ptr @__olang_scope_hold(ptr %t85)
  %t87 = ptrtoint ptr %t86 to i64
  %t89 = inttoptr i64 %t87 to ptr
  %t91 = load ptr, ptr %l38, !tbaa !29
  %t92 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2equietBlock(ptr %v0, ptr %t89, ptr %v3, ptr %v2, ptr %v1, ptr %t82, ptr %t91)
  store i1 %t92, ptr %l40
  br label %bb15
bb15:
  %t93 = load i1, ptr %l40, !tbaa !21
  store i1 %t93, ptr %l3, !tbaa !21
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t96 = getelementptr %"compiler/lower:lowering", ptr %t94, i32 0, i32 71
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eClear_3cI64_2c_20Bool_3e(ptr %v0, ptr %t96)
  br label %bb16
bb16:
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t100 = getelementptr %"compiler/lower:lowering", ptr %t98, i32 0, i32 75
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eClear_3cI64_2c_20Bool_3e(ptr %v0, ptr %t100)
  br label %bb17
bb17:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = getelementptr %"compiler/lower:lowering", ptr %t102, i32 0, i32 74
  store i1 false, ptr %t104, !tbaa !21
  %t105 = load i1, ptr %l3, !tbaa !21
  store i1 %t105, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3alowering_2equietStmt(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i1
  %l9 = alloca ptr
  %l10 = alloca i1
  %l15 = alloca ptr
  %l16 = alloca i1
  %l24 = alloca i1
  %l25 = alloca ptr
  %l26 = alloca i1
  %l35 = alloca i1
  %l36 = alloca i1
  %l40 = alloca i1
  %l41 = alloca ptr
  %l42 = alloca i1
  %l51 = alloca i1
  %l52 = alloca ptr
  %l53 = alloca i1
  %l60 = alloca i1
  %l61 = alloca ptr
  %l62 = alloca i1
  %l70 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l9, !tbaa !29
  store i1 false, ptr %l10, !tbaa !21
  %t2 = load ptr, ptr %l9, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l9, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 17}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l10, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l10, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [3 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb9
bb4:
  %t16 = load ptr, ptr %l1, !tbaa !29
  store ptr %t16, ptr %l15, !tbaa !29
  store i1 false, ptr %l16, !tbaa !21
  %t17 = load ptr, ptr %l15, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb5, label %bb6
bb5:
  %t20 = load ptr, ptr %l15, !tbaa !29
  %t21 = load i64, ptr %t20, !range !{i64 0, i64 17}
  %t23 = icmp eq i64 %t21, 2
  store i1 %t23, ptr %l16, !tbaa !21
  br label %bb6
bb6:
  %t24 = load i1, ptr %l16, !tbaa !21
  br i1 %t24, label %bb7, label %bb8
bb7:
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr { i64, [3 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", ptr }, ptr %t27, i32 0, i32 1
  %t29 = load ptr, ptr %t28
  store ptr %t29, ptr %l2, !tbaa !29
  br label %bb9
bb8:
  br label %bb11
bb9:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load ptr, ptr %l2, !tbaa !29
  %t36 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2equietX(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t31, ptr %t32)
  store i1 %t36, ptr %l24
  br label %bb10
bb10:
  %t37 = load i1, ptr %l24, !tbaa !21
  store i1 %t37, ptr %l8, !tbaa !21
  br label %bb48
bb11:
  %t38 = load ptr, ptr %l1, !tbaa !29
  store ptr %t38, ptr %l25, !tbaa !29
  store i1 false, ptr %l26, !tbaa !21
  %t39 = load ptr, ptr %l25, !tbaa !29
  %t40 = icmp ne ptr %t39, null
  br i1 %t40, label %bb12, label %bb13
bb12:
  %t42 = load ptr, ptr %l25, !tbaa !29
  %t43 = load i64, ptr %t42, !range !{i64 0, i64 17}
  %t45 = icmp eq i64 %t43, 1
  store i1 %t45, ptr %l26, !tbaa !21
  br label %bb13
bb13:
  %t46 = load i1, ptr %l26, !tbaa !21
  br i1 %t46, label %bb14, label %bb15
bb14:
  %t47 = load ptr, ptr %l1, !tbaa !29
  %t49 = getelementptr { i64, [3 x i64] }, ptr %t47, i32 0, i32 1
  %t50 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t49, i32 0, i32 1
  %t51 = load ptr, ptr %t50
  store ptr %t51, ptr %l3, !tbaa !29
  %t53 = load ptr, ptr %l1, !tbaa !29
  %t55 = getelementptr { i64, [3 x i64] }, ptr %t53, i32 0, i32 1
  %t56 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t55, i32 0, i32 2
  %t57 = load ptr, ptr %t56
  store ptr %t57, ptr %l4, !tbaa !29
  br label %bb16
bb15:
  br label %bb22
bb16:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t60 = load ptr, ptr %l3, !tbaa !29
  %t63 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2equietPlace(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t59, ptr %t60)
  store i1 %t63, ptr %l35
  br label %bb17
bb17:
  %t64 = load i1, ptr %l35, !tbaa !21
  br i1 %t64, label %bb18, label %bb19
bb18:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t66 = load ptr, ptr %l4, !tbaa !29
  %t70 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2equietX(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t65, ptr %t66)
  store i1 %t70, ptr %l40
  br label %bb20
bb19:
  store i1 false, ptr %l36, !tbaa !21
  br label %bb21
bb20:
  %t71 = load i1, ptr %l40, !tbaa !21
  store i1 %t71, ptr %l36, !tbaa !21
  br label %bb21
bb21:
  %t72 = load i1, ptr %l36, !tbaa !21
  store i1 %t72, ptr %l8, !tbaa !21
  br label %bb48
bb22:
  %t73 = load ptr, ptr %l1, !tbaa !29
  store ptr %t73, ptr %l41, !tbaa !29
  store i1 false, ptr %l42, !tbaa !21
  %t74 = load ptr, ptr %l41, !tbaa !29
  %t75 = icmp ne ptr %t74, null
  br i1 %t75, label %bb23, label %bb24
bb23:
  %t77 = load ptr, ptr %l41, !tbaa !29
  %t78 = load i64, ptr %t77, !range !{i64 0, i64 17}
  %t80 = icmp eq i64 %t78, 3
  store i1 %t80, ptr %l42, !tbaa !21
  br label %bb24
bb24:
  %t81 = load i1, ptr %l42, !tbaa !21
  br i1 %t81, label %bb25, label %bb26
bb25:
  %t82 = load ptr, ptr %l1, !tbaa !29
  %t84 = getelementptr { i64, [3 x i64] }, ptr %t82, i32 0, i32 1
  %t85 = getelementptr { %"compiler/source:Span", ptr }, ptr %t84, i32 0, i32 1
  %t86 = load ptr, ptr %t85
  store ptr %t86, ptr %l5, !tbaa !29
  br label %bb27
bb26:
  br label %bb29
bb27:
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t89 = load ptr, ptr %l5, !tbaa !29
  %t91 = getelementptr %"compiler/typed:If", ptr %t89, i32 0, i32 0
  %t92 = load ptr, ptr %t91, !tbaa !29
  %t96 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2equietX(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t88, ptr %t92)
  store i1 %t96, ptr %l51
  br label %bb28
bb28:
  %t97 = load i1, ptr %l51, !tbaa !21
  store i1 %t97, ptr %l8, !tbaa !21
  br label %bb48
bb29:
  %t98 = load ptr, ptr %l1, !tbaa !29
  store ptr %t98, ptr %l52, !tbaa !29
  store i1 false, ptr %l53, !tbaa !21
  %t99 = load ptr, ptr %l52, !tbaa !29
  %t100 = icmp ne ptr %t99, null
  br i1 %t100, label %bb30, label %bb31
bb30:
  %t102 = load ptr, ptr %l52, !tbaa !29
  %t103 = load i64, ptr %t102, !range !{i64 0, i64 17}
  %t105 = icmp eq i64 %t103, 6
  store i1 %t105, ptr %l53, !tbaa !21
  br label %bb31
bb31:
  %t106 = load i1, ptr %l53, !tbaa !21
  br i1 %t106, label %bb32, label %bb33
bb32:
  %t107 = load ptr, ptr %l1, !tbaa !29
  %t109 = getelementptr { i64, [3 x i64] }, ptr %t107, i32 0, i32 1
  %t110 = getelementptr { %"compiler/source:Span", ptr }, ptr %t109, i32 0, i32 1
  %t111 = load ptr, ptr %t110
  store ptr %t111, ptr %l6, !tbaa !29
  br label %bb34
bb33:
  br label %bb36
bb34:
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t114 = load ptr, ptr %l6, !tbaa !29
  %t117 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2equietX(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t113, ptr %t114)
  store i1 %t117, ptr %l60
  br label %bb35
bb35:
  %t118 = load i1, ptr %l60, !tbaa !21
  store i1 %t118, ptr %l8, !tbaa !21
  br label %bb48
bb36:
  %t119 = load ptr, ptr %l1, !tbaa !29
  store ptr %t119, ptr %l61, !tbaa !29
  store i1 false, ptr %l62, !tbaa !21
  %t120 = load ptr, ptr %l61, !tbaa !29
  %t121 = icmp ne ptr %t120, null
  br i1 %t121, label %bb37, label %bb38
bb37:
  %t123 = load ptr, ptr %l61, !tbaa !29
  %t124 = load i64, ptr %t123, !range !{i64 0, i64 17}
  %t126 = icmp eq i64 %t124, 10
  store i1 %t126, ptr %l62, !tbaa !21
  br label %bb38
bb38:
  %t127 = load i1, ptr %l62, !tbaa !21
  br i1 %t127, label %bb39, label %bb40
bb39:
  %t128 = load ptr, ptr %l1, !tbaa !29
  %t130 = getelementptr { i64, [3 x i64] }, ptr %t128, i32 0, i32 1
  %t131 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t130, i32 0, i32 1
  %t132 = load ptr, ptr %t131
  store ptr %t132, ptr %l7, !tbaa !29
  br label %bb41
bb40:
  br label %bb43
bb41:
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t135 = load ptr, ptr %l7, !tbaa !29
  %t139 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2equietX(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t134, ptr %t135)
  store i1 %t139, ptr %l70
  br label %bb42
bb42:
  %t140 = load i1, ptr %l70, !tbaa !21
  store i1 %t140, ptr %l8, !tbaa !21
  br label %bb48
bb43:
  br i1 true, label %bb44, label %bb45
bb44:
  br label %bb46
bb45:
  br label %bb47
bb46:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb48
bb47:
  call void @__olang_check_failed(ptr @olang_loc_28287f1f33def765_74d32538b56dd6f1)
  unreachable
bb48:
  %t141 = load i1, ptr %l8, !tbaa !21
  store i1 %t141, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3alowering_2equietX(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca { i64, ptr }
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l17 = alloca i1
  %l18 = alloca ptr
  %l19 = alloca i1
  %l22 = alloca ptr
  %l23 = alloca i1
  %l26 = alloca ptr
  %l27 = alloca i1
  %l32 = alloca ptr
  %l33 = alloca i1
  %l40 = alloca i1
  %l41 = alloca ptr
  %l42 = alloca i1
  %l51 = alloca i1
  %l52 = alloca ptr
  %l53 = alloca i1
  %l60 = alloca i1
  %l61 = alloca ptr
  %l62 = alloca i1
  %l70 = alloca i1
  %l71 = alloca i1
  %l75 = alloca i1
  %l76 = alloca ptr
  %l77 = alloca i1
  %l86 = alloca i1
  %l87 = alloca i1
  %l90 = alloca i1
  %l92 = alloca i1
  %l94 = alloca ptr
  %l95 = alloca i1
  %l103 = alloca i1
  %l104 = alloca i1
  %l109 = alloca i1
  %l110 = alloca i1
  %l115 = alloca i1
  %l116 = alloca ptr
  %l117 = alloca i1
  %l126 = alloca i1
  %l127 = alloca i1
  %l131 = alloca i1
  %l132 = alloca i1
  %l137 = alloca i1
  %l138 = alloca ptr
  %l139 = alloca i1
  %l148 = alloca i1
  %l152 = alloca i1
  %l153 = alloca ptr
  %l154 = alloca i1
  %l162 = alloca i1
  %l163 = alloca i1
  %l166 = alloca i1
  %l167 = alloca i1
  %l170 = alloca i1
  %l171 = alloca ptr
  %l172 = alloca i1
  %l179 = alloca i1
  %l180 = alloca ptr
  %l181 = alloca i1
  %l189 = alloca i1
  %l190 = alloca ptr
  %l191 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l1, !tbaa !29
  store ptr %t6, ptr %l18, !tbaa !29
  store i1 false, ptr %l19, !tbaa !21
  %t7 = load ptr, ptr %l18, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb4, label %bb5
bb4:
  %t10 = load ptr, ptr %l18, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 18}
  %t13 = icmp eq i64 %t11, 0
  store i1 %t13, ptr %l19, !tbaa !21
  br label %bb5
bb5:
  %t14 = load i1, ptr %l19, !tbaa !21
  br i1 %t14, label %bb6, label %bb7
bb6:
  br label %bb12
bb7:
  %t15 = load ptr, ptr %l1, !tbaa !29
  store ptr %t15, ptr %l22, !tbaa !29
  store i1 false, ptr %l23, !tbaa !21
  %t16 = load ptr, ptr %l22, !tbaa !29
  %t17 = icmp ne ptr %t16, null
  br i1 %t17, label %bb8, label %bb9
bb8:
  %t19 = load ptr, ptr %l22, !tbaa !29
  %t20 = load i64, ptr %t19, !range !{i64 0, i64 18}
  %t22 = icmp eq i64 %t20, 1
  store i1 %t22, ptr %l23, !tbaa !21
  br label %bb9
bb9:
  %t23 = load i1, ptr %l23, !tbaa !21
  br i1 %t23, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb13
bb12:
  store i1 true, ptr %l17, !tbaa !21
  br label %bb143
bb13:
  %t24 = load ptr, ptr %l1, !tbaa !29
  store ptr %t24, ptr %l26, !tbaa !29
  store i1 false, ptr %l27, !tbaa !21
  %t25 = load ptr, ptr %l26, !tbaa !29
  %t26 = icmp ne ptr %t25, null
  br i1 %t26, label %bb14, label %bb15
bb14:
  %t28 = load ptr, ptr %l26, !tbaa !29
  %t29 = load i64, ptr %t28, !range !{i64 0, i64 18}
  %t31 = icmp eq i64 %t29, 2
  store i1 %t31, ptr %l27, !tbaa !21
  br label %bb15
bb15:
  %t32 = load i1, ptr %l27, !tbaa !21
  br i1 %t32, label %bb16, label %bb17
bb16:
  %t33 = load ptr, ptr %l1, !tbaa !29
  %t35 = getelementptr { i64, [5 x i64] }, ptr %t33, i32 0, i32 1
  %t36 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t35, i32 0, i32 2
  %t37 = load ptr, ptr %t36
  store ptr %t37, ptr %l2, !tbaa !29
  br label %bb22
bb17:
  %t39 = load ptr, ptr %l1, !tbaa !29
  store ptr %t39, ptr %l32, !tbaa !29
  store i1 false, ptr %l33, !tbaa !21
  %t40 = load ptr, ptr %l32, !tbaa !29
  %t41 = icmp ne ptr %t40, null
  br i1 %t41, label %bb18, label %bb19
bb18:
  %t43 = load ptr, ptr %l32, !tbaa !29
  %t44 = load i64, ptr %t43, !range !{i64 0, i64 18}
  %t46 = icmp eq i64 %t44, 3
  store i1 %t46, ptr %l33, !tbaa !21
  br label %bb19
bb19:
  %t47 = load i1, ptr %l33, !tbaa !21
  br i1 %t47, label %bb20, label %bb21
bb20:
  %t48 = load ptr, ptr %l1, !tbaa !29
  %t50 = getelementptr { i64, [5 x i64] }, ptr %t48, i32 0, i32 1
  %t51 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t50, i32 0, i32 2
  %t52 = load ptr, ptr %t51
  store ptr %t52, ptr %l2, !tbaa !29
  br label %bb22
bb21:
  br label %bb24
bb22:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t55 = load ptr, ptr %l2, !tbaa !29
  %t58 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2equietPlace(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t54, ptr %t55)
  store i1 %t58, ptr %l40
  br label %bb23
bb23:
  %t59 = load i1, ptr %l40, !tbaa !21
  store i1 %t59, ptr %l17, !tbaa !21
  br label %bb143
bb24:
  %t60 = load ptr, ptr %l1, !tbaa !29
  store ptr %t60, ptr %l41, !tbaa !29
  store i1 false, ptr %l42, !tbaa !21
  %t61 = load ptr, ptr %l41, !tbaa !29
  %t62 = icmp ne ptr %t61, null
  br i1 %t62, label %bb25, label %bb26
bb25:
  %t64 = load ptr, ptr %l41, !tbaa !29
  %t65 = load i64, ptr %t64, !range !{i64 0, i64 18}
  %t67 = icmp eq i64 %t65, 5
  store i1 %t67, ptr %l42, !tbaa !21
  br label %bb26
bb26:
  %t68 = load i1, ptr %l42, !tbaa !21
  br i1 %t68, label %bb27, label %bb28
bb27:
  %t69 = load ptr, ptr %l1, !tbaa !29
  %t71 = getelementptr { i64, [5 x i64] }, ptr %t69, i32 0, i32 1
  %t72 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t71, i32 0, i32 2
  %t73 = load ptr, ptr %t72
  store ptr %t73, ptr %l3, !tbaa !29
  br label %bb29
bb28:
  br label %bb31
bb29:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t76 = load ptr, ptr %l3, !tbaa !29
  %t78 = getelementptr %"compiler/typed:Promote", ptr %t76, i32 0, i32 0
  %t79 = load ptr, ptr %t78, !tbaa !29
  %t83 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2equietX(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t75, ptr %t79)
  store i1 %t83, ptr %l51
  br label %bb30
bb30:
  %t84 = load i1, ptr %l51, !tbaa !21
  store i1 %t84, ptr %l17, !tbaa !21
  br label %bb143
bb31:
  %t85 = load ptr, ptr %l1, !tbaa !29
  store ptr %t85, ptr %l52, !tbaa !29
  store i1 false, ptr %l53, !tbaa !21
  %t86 = load ptr, ptr %l52, !tbaa !29
  %t87 = icmp ne ptr %t86, null
  br i1 %t87, label %bb32, label %bb33
bb32:
  %t89 = load ptr, ptr %l52, !tbaa !29
  %t90 = load i64, ptr %t89, !range !{i64 0, i64 18}
  %t92 = icmp eq i64 %t90, 6
  store i1 %t92, ptr %l53, !tbaa !21
  br label %bb33
bb33:
  %t93 = load i1, ptr %l53, !tbaa !21
  br i1 %t93, label %bb34, label %bb35
bb34:
  %t94 = load ptr, ptr %l1, !tbaa !29
  %t96 = getelementptr { i64, [5 x i64] }, ptr %t94, i32 0, i32 1
  %t97 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t96, i32 0, i32 2
  %t98 = load ptr, ptr %t97
  store ptr %t98, ptr %l4, !tbaa !29
  br label %bb36
bb35:
  br label %bb38
bb36:
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t101 = load ptr, ptr %l4, !tbaa !29
  %t104 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2equietCall(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t100, ptr %t101)
  store i1 %t104, ptr %l60
  br label %bb37
bb37:
  %t105 = load i1, ptr %l60, !tbaa !21
  store i1 %t105, ptr %l17, !tbaa !21
  br label %bb143
bb38:
  %t106 = load ptr, ptr %l1, !tbaa !29
  store ptr %t106, ptr %l61, !tbaa !29
  store i1 false, ptr %l62, !tbaa !21
  %t107 = load ptr, ptr %l61, !tbaa !29
  %t108 = icmp ne ptr %t107, null
  br i1 %t108, label %bb39, label %bb40
bb39:
  %t110 = load ptr, ptr %l61, !tbaa !29
  %t111 = load i64, ptr %t110, !range !{i64 0, i64 18}
  %t113 = icmp eq i64 %t111, 7
  store i1 %t113, ptr %l62, !tbaa !21
  br label %bb40
bb40:
  %t114 = load i1, ptr %l62, !tbaa !21
  br i1 %t114, label %bb41, label %bb42
bb41:
  %t115 = load ptr, ptr %l1, !tbaa !29
  %t117 = getelementptr { i64, [5 x i64] }, ptr %t115, i32 0, i32 1
  %t118 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t117, i32 0, i32 2
  %t119 = load ptr, ptr %t118
  store ptr %t119, ptr %l5, !tbaa !29
  br label %bb43
bb42:
  br label %bb49
bb43:
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t122 = load ptr, ptr %l5, !tbaa !29
  %t124 = getelementptr %"compiler/typed:Make", ptr %t122, i32 0, i32 2
  %t125 = load { i64, ptr }, ptr %t124, !tbaa !27
  %t128 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2equietAll(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t121, { i64, ptr } %t125)
  store i1 %t128, ptr %l70
  br label %bb44
bb44:
  %t129 = load i1, ptr %l70, !tbaa !21
  br i1 %t129, label %bb45, label %bb46
bb45:
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t131 = load ptr, ptr %l5, !tbaa !29
  %t133 = getelementptr %"compiler/typed:Make", ptr %t131, i32 0, i32 3
  %t134 = load ptr, ptr %t133, !tbaa !29
  %t137 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2equietX(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t130, ptr %t134)
  store i1 %t137, ptr %l75
  br label %bb47
bb46:
  store i1 false, ptr %l71, !tbaa !21
  br label %bb48
bb47:
  %t138 = load i1, ptr %l75, !tbaa !21
  store i1 %t138, ptr %l71, !tbaa !21
  br label %bb48
bb48:
  %t139 = load i1, ptr %l71, !tbaa !21
  store i1 %t139, ptr %l17, !tbaa !21
  br label %bb143
bb49:
  %t140 = load ptr, ptr %l1, !tbaa !29
  store ptr %t140, ptr %l76, !tbaa !29
  store i1 false, ptr %l77, !tbaa !21
  %t141 = load ptr, ptr %l76, !tbaa !29
  %t142 = icmp ne ptr %t141, null
  br i1 %t142, label %bb50, label %bb51
bb50:
  %t144 = load ptr, ptr %l76, !tbaa !29
  %t145 = load i64, ptr %t144, !range !{i64 0, i64 18}
  %t147 = icmp eq i64 %t145, 9
  store i1 %t147, ptr %l77, !tbaa !21
  br label %bb51
bb51:
  %t148 = load i1, ptr %l77, !tbaa !21
  br i1 %t148, label %bb52, label %bb53
bb52:
  %t149 = load ptr, ptr %l1, !tbaa !29
  %t151 = getelementptr { i64, [5 x i64] }, ptr %t149, i32 0, i32 1
  %t152 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t151, i32 0, i32 2
  %t153 = load i32, ptr %t152, !range !{i32 0, i32 54}
  store i32 %t153, ptr %l6
  %t155 = load ptr, ptr %l1, !tbaa !29
  %t157 = getelementptr { i64, [5 x i64] }, ptr %t155, i32 0, i32 1
  %t158 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t157, i32 0, i32 4
  %t159 = load { i64, ptr }, ptr %t158
  store { i64, ptr } %t159, ptr %l7, !tbaa !27
  br label %bb54
bb53:
  br label %bb63
bb54:
  %t161 = load ptr, ptr %l0, !tbaa !29
  %t162 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t165 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2equietAll(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t161, { i64, ptr } %t162)
  store i1 %t165, ptr %l86
  br label %bb55
bb55:
  %t166 = load i1, ptr %l86, !tbaa !21
  br i1 %t166, label %bb56, label %bb57
bb56:
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t169 = getelementptr %"compiler/lower:lowering", ptr %t167, i32 0, i32 74
  %t170 = load i1, ptr %t169, !tbaa !21
  br i1 %t170, label %bb58, label %bb59
bb57:
  store i1 false, ptr %l87, !tbaa !21
  br label %bb62
bb58:
  %t172 = load i32, ptr %l6, !range !{i32 0, i32 54}
  %t174 = call i1 @compiler_2flower_2eglobalWrite(i32 %t172)
  store i1 %t174, ptr %l92
  br label %bb60
bb59:
  store i1 false, ptr %l90, !tbaa !21
  br label %bb61
bb60:
  %t175 = load i1, ptr %l92, !tbaa !21
  store i1 %t175, ptr %l90, !tbaa !21
  br label %bb61
bb61:
  %t176 = load i1, ptr %l90, !tbaa !21
  %t177 = xor i1 %t176, true
  store i1 %t177, ptr %l87, !tbaa !21
  br label %bb62
bb62:
  %t179 = load i1, ptr %l87, !tbaa !21
  store i1 %t179, ptr %l17, !tbaa !21
  br label %bb143
bb63:
  %t180 = load ptr, ptr %l1, !tbaa !29
  store ptr %t180, ptr %l94, !tbaa !29
  store i1 false, ptr %l95, !tbaa !21
  %t181 = load ptr, ptr %l94, !tbaa !29
  %t182 = icmp ne ptr %t181, null
  br i1 %t182, label %bb64, label %bb65
bb64:
  %t184 = load ptr, ptr %l94, !tbaa !29
  %t185 = load i64, ptr %t184, !range !{i64 0, i64 18}
  %t187 = icmp eq i64 %t185, 10
  store i1 %t187, ptr %l95, !tbaa !21
  br label %bb65
bb65:
  %t188 = load i1, ptr %l95, !tbaa !21
  br i1 %t188, label %bb66, label %bb67
bb66:
  %t189 = load ptr, ptr %l1, !tbaa !29
  %t191 = getelementptr { i64, [5 x i64] }, ptr %t189, i32 0, i32 1
  %t192 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t191, i32 0, i32 2
  %t193 = load ptr, ptr %t192
  store ptr %t193, ptr %l8, !tbaa !29
  br label %bb68
bb67:
  br label %bb78
bb68:
  %t195 = load ptr, ptr %l0, !tbaa !29
  %t196 = load ptr, ptr %l8, !tbaa !29
  %t198 = getelementptr %"compiler/typed:Slice", ptr %t196, i32 0, i32 0
  %t199 = load ptr, ptr %t198, !tbaa !29
  %t202 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2equietPlace(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t195, ptr %t199)
  store i1 %t202, ptr %l103
  br label %bb69
bb69:
  %t203 = load i1, ptr %l103, !tbaa !21
  br i1 %t203, label %bb70, label %bb71
bb70:
  %t204 = load ptr, ptr %l0, !tbaa !29
  %t205 = load ptr, ptr %l8, !tbaa !29
  %t207 = getelementptr %"compiler/typed:Slice", ptr %t205, i32 0, i32 1
  %t208 = load ptr, ptr %t207, !tbaa !29
  %t212 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2equietX(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t204, ptr %t208)
  store i1 %t212, ptr %l109
  br label %bb72
bb71:
  store i1 false, ptr %l104, !tbaa !21
  br label %bb73
bb72:
  %t213 = load i1, ptr %l109, !tbaa !21
  store i1 %t213, ptr %l104, !tbaa !21
  br label %bb73
bb73:
  %t214 = load i1, ptr %l104, !tbaa !21
  br i1 %t214, label %bb74, label %bb75
bb74:
  %t215 = load ptr, ptr %l0, !tbaa !29
  %t216 = load ptr, ptr %l8, !tbaa !29
  %t218 = getelementptr %"compiler/typed:Slice", ptr %t216, i32 0, i32 2
  %t219 = load ptr, ptr %t218, !tbaa !29
  %t223 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2equietX(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t215, ptr %t219)
  store i1 %t223, ptr %l115
  br label %bb76
bb75:
  store i1 false, ptr %l110, !tbaa !21
  br label %bb77
bb76:
  %t224 = load i1, ptr %l115, !tbaa !21
  store i1 %t224, ptr %l110, !tbaa !21
  br label %bb77
bb77:
  %t225 = load i1, ptr %l110, !tbaa !21
  store i1 %t225, ptr %l17, !tbaa !21
  br label %bb143
bb78:
  %t226 = load ptr, ptr %l1, !tbaa !29
  store ptr %t226, ptr %l116, !tbaa !29
  store i1 false, ptr %l117, !tbaa !21
  %t227 = load ptr, ptr %l116, !tbaa !29
  %t228 = icmp ne ptr %t227, null
  br i1 %t228, label %bb79, label %bb80
bb79:
  %t230 = load ptr, ptr %l116, !tbaa !29
  %t231 = load i64, ptr %t230, !range !{i64 0, i64 18}
  %t233 = icmp eq i64 %t231, 11
  store i1 %t233, ptr %l117, !tbaa !21
  br label %bb80
bb80:
  %t234 = load i1, ptr %l117, !tbaa !21
  br i1 %t234, label %bb81, label %bb82
bb81:
  %t235 = load ptr, ptr %l1, !tbaa !29
  %t237 = getelementptr { i64, [5 x i64] }, ptr %t235, i32 0, i32 1
  %t238 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t237, i32 0, i32 2
  %t239 = load ptr, ptr %t238
  store ptr %t239, ptr %l9, !tbaa !29
  br label %bb83
bb82:
  br label %bb93
bb83:
  %t241 = load ptr, ptr %l0, !tbaa !29
  %t242 = load ptr, ptr %l9, !tbaa !29
  %t244 = getelementptr %"compiler/typed:Cond", ptr %t242, i32 0, i32 0
  %t245 = load ptr, ptr %t244, !tbaa !29
  %t249 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2equietX(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t241, ptr %t245)
  store i1 %t249, ptr %l126
  br label %bb84
bb84:
  %t250 = load i1, ptr %l126, !tbaa !21
  br i1 %t250, label %bb85, label %bb86
bb85:
  %t251 = load ptr, ptr %l0, !tbaa !29
  %t252 = load ptr, ptr %l9, !tbaa !29
  %t254 = getelementptr %"compiler/typed:Cond", ptr %t252, i32 0, i32 1
  %t255 = load ptr, ptr %t254, !tbaa !29
  %t258 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2equietX(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t251, ptr %t255)
  store i1 %t258, ptr %l131
  br label %bb87
bb86:
  store i1 false, ptr %l127, !tbaa !21
  br label %bb88
bb87:
  %t259 = load i1, ptr %l131, !tbaa !21
  store i1 %t259, ptr %l127, !tbaa !21
  br label %bb88
bb88:
  %t260 = load i1, ptr %l127, !tbaa !21
  br i1 %t260, label %bb89, label %bb90
bb89:
  %t261 = load ptr, ptr %l0, !tbaa !29
  %t262 = load ptr, ptr %l9, !tbaa !29
  %t264 = getelementptr %"compiler/typed:Cond", ptr %t262, i32 0, i32 2
  %t265 = load ptr, ptr %t264, !tbaa !29
  %t269 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2equietX(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t261, ptr %t265)
  store i1 %t269, ptr %l137
  br label %bb91
bb90:
  store i1 false, ptr %l132, !tbaa !21
  br label %bb92
bb91:
  %t270 = load i1, ptr %l137, !tbaa !21
  store i1 %t270, ptr %l132, !tbaa !21
  br label %bb92
bb92:
  %t271 = load i1, ptr %l132, !tbaa !21
  store i1 %t271, ptr %l17, !tbaa !21
  br label %bb143
bb93:
  %t272 = load ptr, ptr %l1, !tbaa !29
  store ptr %t272, ptr %l138, !tbaa !29
  store i1 false, ptr %l139, !tbaa !21
  %t273 = load ptr, ptr %l138, !tbaa !29
  %t274 = icmp ne ptr %t273, null
  br i1 %t274, label %bb94, label %bb95
bb94:
  %t276 = load ptr, ptr %l138, !tbaa !29
  %t277 = load i64, ptr %t276, !range !{i64 0, i64 18}
  %t279 = icmp eq i64 %t277, 12
  store i1 %t279, ptr %l139, !tbaa !21
  br label %bb95
bb95:
  %t280 = load i1, ptr %l139, !tbaa !21
  br i1 %t280, label %bb96, label %bb97
bb96:
  %t281 = load ptr, ptr %l1, !tbaa !29
  %t283 = getelementptr { i64, [5 x i64] }, ptr %t281, i32 0, i32 1
  %t284 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t283, i32 0, i32 2
  %t285 = load ptr, ptr %t284
  store ptr %t285, ptr %l10, !tbaa !29
  br label %bb98
bb97:
  br label %bb103
bb98:
  %t287 = load ptr, ptr %l10, !tbaa !29
  %t289 = getelementptr %"compiler/typed:Seq", ptr %t287, i32 0, i32 0
  %t290 = load { i64, ptr }, ptr %t289, !tbaa !27
  %t292 = extractvalue { i64, ptr } %t290, 0
  %t294 = icmp eq i64 %t292, 0
  br i1 %t294, label %bb99, label %bb100
bb99:
  %t296 = load ptr, ptr %l0, !tbaa !29
  %t297 = load ptr, ptr %l10, !tbaa !29
  %t299 = getelementptr %"compiler/typed:Seq", ptr %t297, i32 0, i32 1
  %t300 = load ptr, ptr %t299, !tbaa !29
  %t303 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2equietX(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t296, ptr %t300)
  store i1 %t303, ptr %l152
  br label %bb101
bb100:
  store i1 false, ptr %l148, !tbaa !21
  br label %bb102
bb101:
  %t304 = load i1, ptr %l152, !tbaa !21
  store i1 %t304, ptr %l148, !tbaa !21
  br label %bb102
bb102:
  %t305 = load i1, ptr %l148, !tbaa !21
  store i1 %t305, ptr %l17, !tbaa !21
  br label %bb143
bb103:
  %t306 = load ptr, ptr %l1, !tbaa !29
  store ptr %t306, ptr %l153, !tbaa !29
  store i1 false, ptr %l154, !tbaa !21
  %t307 = load ptr, ptr %l153, !tbaa !29
  %t308 = icmp ne ptr %t307, null
  br i1 %t308, label %bb104, label %bb105
bb104:
  %t310 = load ptr, ptr %l153, !tbaa !29
  %t311 = load i64, ptr %t310, !range !{i64 0, i64 18}
  %t313 = icmp eq i64 %t311, 14
  store i1 %t313, ptr %l154, !tbaa !21
  br label %bb105
bb105:
  %t314 = load i1, ptr %l154, !tbaa !21
  br i1 %t314, label %bb106, label %bb107
bb106:
  %t315 = load ptr, ptr %l1, !tbaa !29
  %t317 = getelementptr { i64, [5 x i64] }, ptr %t315, i32 0, i32 1
  %t318 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t317, i32 0, i32 2
  %t319 = load ptr, ptr %t318
  store ptr %t319, ptr %l11, !tbaa !29
  br label %bb108
bb107:
  br label %bb118
bb108:
  %t321 = load ptr, ptr %l0, !tbaa !29
  %t322 = load ptr, ptr %l11, !tbaa !29
  %t324 = getelementptr %"compiler/typed:Try", ptr %t322, i32 0, i32 0
  %t325 = load ptr, ptr %t324, !tbaa !29
  %t328 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2equietX(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t321, ptr %t325)
  store i1 %t328, ptr %l162
  br label %bb109
bb109:
  %t329 = load i1, ptr %l162, !tbaa !21
  br i1 %t329, label %bb110, label %bb111
bb110:
  %t330 = load ptr, ptr %l0, !tbaa !29
  %t331 = load ptr, ptr %l11, !tbaa !29
  %t334 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eselfTry(ptr %v0, ptr %v1, ptr %t330, ptr %t331)
  store i1 %t334, ptr %l166
  br label %bb112
bb111:
  store i1 false, ptr %l163, !tbaa !21
  br label %bb117
bb112:
  %t335 = load i1, ptr %l166, !tbaa !21
  br i1 %t335, label %bb113, label %bb114
bb113:
  store i1 true, ptr %l167, !tbaa !21
  br label %bb116
bb114:
  %t336 = load ptr, ptr %l0, !tbaa !29
  %t337 = load ptr, ptr %l11, !tbaa !29
  %t340 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2equietClauses(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t336, ptr %t337)
  store i1 %t340, ptr %l170
  br label %bb115
bb115:
  %t341 = load i1, ptr %l170, !tbaa !21
  store i1 %t341, ptr %l167, !tbaa !21
  br label %bb116
bb116:
  %t342 = load i1, ptr %l167, !tbaa !21
  store i1 %t342, ptr %l163, !tbaa !21
  br label %bb117
bb117:
  %t343 = load i1, ptr %l163, !tbaa !21
  store i1 %t343, ptr %l17, !tbaa !21
  br label %bb143
bb118:
  %t344 = load ptr, ptr %l1, !tbaa !29
  store ptr %t344, ptr %l171, !tbaa !29
  store i1 false, ptr %l172, !tbaa !21
  %t345 = load ptr, ptr %l171, !tbaa !29
  %t346 = icmp ne ptr %t345, null
  br i1 %t346, label %bb119, label %bb120
bb119:
  %t348 = load ptr, ptr %l171, !tbaa !29
  %t349 = load i64, ptr %t348, !range !{i64 0, i64 18}
  %t351 = icmp eq i64 %t349, 16
  store i1 %t351, ptr %l172, !tbaa !21
  br label %bb120
bb120:
  %t352 = load i1, ptr %l172, !tbaa !21
  br i1 %t352, label %bb121, label %bb122
bb121:
  %t353 = load ptr, ptr %l1, !tbaa !29
  %t355 = getelementptr { i64, [5 x i64] }, ptr %t353, i32 0, i32 1
  %t356 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t355, i32 0, i32 2
  %t357 = load ptr, ptr %t356
  store ptr %t357, ptr %l12, !tbaa !29
  br label %bb123
bb122:
  br label %bb125
bb123:
  %t359 = load ptr, ptr %l0, !tbaa !29
  %t360 = load ptr, ptr %l12, !tbaa !29
  %t363 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2equietPieces(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t359, ptr %t360)
  store i1 %t363, ptr %l179
  br label %bb124
bb124:
  %t364 = load i1, ptr %l179, !tbaa !21
  store i1 %t364, ptr %l17, !tbaa !21
  br label %bb143
bb125:
  %t365 = load ptr, ptr %l1, !tbaa !29
  store ptr %t365, ptr %l180, !tbaa !29
  store i1 false, ptr %l181, !tbaa !21
  %t366 = load ptr, ptr %l180, !tbaa !29
  %t367 = icmp ne ptr %t366, null
  br i1 %t367, label %bb126, label %bb127
bb126:
  %t369 = load ptr, ptr %l180, !tbaa !29
  %t370 = load i64, ptr %t369, !range !{i64 0, i64 18}
  %t372 = icmp eq i64 %t370, 17
  store i1 %t372, ptr %l181, !tbaa !21
  br label %bb127
bb127:
  %t373 = load i1, ptr %l181, !tbaa !21
  br i1 %t373, label %bb128, label %bb129
bb128:
  %t374 = load ptr, ptr %l1, !tbaa !29
  %t376 = getelementptr { i64, [5 x i64] }, ptr %t374, i32 0, i32 1
  %t377 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t376, i32 0, i32 2
  %t378 = load ptr, ptr %t377
  store ptr %t378, ptr %l13, !tbaa !29
  br label %bb130
bb129:
  br label %bb132
bb130:
  %t380 = load ptr, ptr %l0, !tbaa !29
  %t381 = load ptr, ptr %l13, !tbaa !29
  %t385 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2equietX(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t380, ptr %t381)
  store i1 %t385, ptr %l189
  br label %bb131
bb131:
  %t386 = load i1, ptr %l189, !tbaa !21
  store i1 %t386, ptr %l17, !tbaa !21
  br label %bb143
bb132:
  %t387 = load ptr, ptr %l1, !tbaa !29
  store ptr %t387, ptr %l190, !tbaa !29
  store i1 false, ptr %l191, !tbaa !21
  %t388 = load ptr, ptr %l190, !tbaa !29
  %t389 = icmp ne ptr %t388, null
  br i1 %t389, label %bb133, label %bb134
bb133:
  %t391 = load ptr, ptr %l190, !tbaa !29
  %t392 = load i64, ptr %t391, !range !{i64 0, i64 18}
  %t394 = icmp eq i64 %t392, 15
  store i1 %t394, ptr %l191, !tbaa !21
  br label %bb134
bb134:
  %t395 = load i1, ptr %l191, !tbaa !21
  br i1 %t395, label %bb135, label %bb136
bb135:
  br label %bb137
bb136:
  br label %bb138
bb137:
  store i1 true, ptr %l17, !tbaa !21
  br label %bb143
bb138:
  br i1 true, label %bb139, label %bb140
bb139:
  br label %bb141
bb140:
  br label %bb142
bb141:
  store i1 false, ptr %l17, !tbaa !21
  br label %bb143
bb142:
  call void @__olang_check_failed(ptr @olang_loc_3bbf6907cdc90559_48ef26e69e7376e5)
  unreachable
bb143:
  %t396 = load i1, ptr %l17, !tbaa !21
  store i1 %t396, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2eraise(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, %"compiler/source:Span" %a1, { i64, [4 x i64] } %a2, i1 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l4 = alloca i32
  %l5 = alloca i1
  %l7 = alloca ptr
  %l9 = alloca ptr
  %l14 = alloca i32
  %l16 = alloca { i64, ptr }
  %l28 = alloca i32
  %l37 = alloca i1
  %l38 = alloca i1
  %l42 = alloca ptr
  %l44 = alloca %"compiler/mir:Lvalue"
  %l47 = alloca ptr
  %l48 = alloca %"compiler/source:Span"
  %l50 = alloca %"compiler/mir:Lvalue"
  %s0 = alloca %olang.scope
  %t41 = alloca { i64, [4 x i64] }, align 8
  %t44 = alloca { i64, [8 x i64] }, align 8
  %t99 = alloca { i64, [4 x i64] }, align 8
  %t114 = alloca { i64, [4 x i64] }, align 8
  %t120 = alloca { i64, [8 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l7, !tbaa !29
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/lower:lowering", ptr %t5, i32 0, i32 2
  %t8 = load ptr, ptr %t7, !tbaa !29
  store ptr %t8, ptr %l9, !tbaa !29
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/lower:lowering", ptr %t9, i32 0, i32 1
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t14 = getelementptr %"compiler/typed:Body", ptr %t12, i32 0, i32 2
  %t15 = load i32, ptr %t14, !tbaa !23
  %t16 = load ptr, ptr %l9, !tbaa !29
  %t17 = call ptr @__olang_scope_or(ptr %v1, ptr %t16)
  %t18 = call ptr @__olang_scope_hold(ptr %t17)
  %t19 = ptrtoint ptr %t18 to i64
  %t21 = inttoptr i64 %t19 to ptr
  %t22 = load ptr, ptr %l9, !tbaa !29
  %t24 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %t21, ptr %t22, i32 %t15)
  store i32 %t24, ptr %l14
  br label %bb1
bb1:
  %t25 = load ptr, ptr %l7, !tbaa !29
  %t26 = call ptr @__olang_scope_or(ptr %v1, ptr %t25)
  %t27 = call ptr @__olang_scope_hold(ptr %t26)
  %t28 = ptrtoint ptr %t27 to i64
  %t30 = inttoptr i64 %t28 to ptr
  %t31 = load ptr, ptr %l7, !tbaa !29
  %t32 = load i32, ptr %l14, !tbaa !23
  %t33 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %t30, ptr %s0, ptr %t31, i32 %t32)
  store { i64, ptr } %t33, ptr %l16
  br label %bb2
bb2:
  %t34 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t35 = extractvalue { i64, ptr } %t34, 0
  %t37 = icmp eq i64 %t35, 0
  br i1 %t37, label %bb3, label %bb4
bb3:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t40 = load %"compiler/source:Span", ptr %l1
  store { i64, [4 x i64] } zeroinitializer, ptr %t41
  %t42 = getelementptr { i64, [4 x i64] }, ptr %t41, i32 0, i32 0
  store i64 0, ptr %t42
  %t43 = load { i64, [4 x i64] }, ptr %t41
  store { i64, [8 x i64] } zeroinitializer, ptr %t44
  %t45 = getelementptr { i64, [8 x i64] }, ptr %t44, i32 0, i32 0
  store i64 9, ptr %t45
  %t47 = insertvalue { %"compiler/source:Span", i32, { i64, [4 x i64] } } undef, %"compiler/source:Span" %t40, 0
  %t49 = insertvalue { %"compiler/source:Span", i32, { i64, [4 x i64] } } %t47, i32 3, 1
  %t51 = insertvalue { %"compiler/source:Span", i32, { i64, [4 x i64] } } %t49, { i64, [4 x i64] } %t43, 2
  %t52 = getelementptr { i64, [8 x i64] }, ptr %t44, i32 0, i32 1
  store { %"compiler/source:Span", i32, { i64, [4 x i64] } } %t51, ptr %t52
  %t53 = load { i64, [8 x i64] }, ptr %t44
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %v2, ptr %v1, ptr %t39, { i64, [8 x i64] } %t53)
  br label %bb5
bb4:
  br label %bb6
bb5:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb6:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = load i32, ptr @G_2ecompiler_2fmir_2eI32T, !tbaa !23
  %t59 = load %"compiler/source:Span", ptr %l1
  %t64 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2elocal(ptr %v0, ptr %v1, ptr %v2, ptr %t56, { i64, [4 x i64] } %a2, i32 %t58, %"compiler/source:Span" %t59)
  store i32 %t64, ptr %l28
  br label %bb7
bb7:
  %t65 = load i32, ptr %l28, !tbaa !23
  store i32 %t65, ptr %l4, !tbaa !23
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"compiler/lower:lowering", ptr %t66, i32 0, i32 28
  %t69 = load i1, ptr %t68, !tbaa !21
  store i1 %t69, ptr %l5, !tbaa !21
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/lower:lowering", ptr %t71, i32 0, i32 28
  store i1 %a3, ptr %t75, !tbaa !21
  %t76 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eleave(ptr %v0, ptr %v3, ptr %v1, ptr %v2, ptr %v4, ptr %t76, i64 0)
  br label %bb8
bb8:
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t79 = load i1, ptr %l5, !tbaa !21
  %t82 = getelementptr %"compiler/lower:lowering", ptr %t78, i32 0, i32 28
  store i1 %t79, ptr %t82, !tbaa !21
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eisMain(ptr %v0, ptr %v2, ptr %t83)
  store i1 %t85, ptr %l37
  br label %bb9
bb9:
  %t86 = load i1, ptr %l37, !tbaa !21
  br i1 %t86, label %bb10, label %bb11
bb10:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr %"compiler/lower:lowering", ptr %t87, i32 0, i32 12
  %t90 = load i1, ptr %t89, !tbaa !21
  %t92 = xor i1 %t90, true
  store i1 %t92, ptr %l38, !tbaa !21
  br label %bb12
bb11:
  store i1 false, ptr %l38, !tbaa !21
  br label %bb12
bb12:
  %t94 = load i1, ptr %l38, !tbaa !21
  br i1 %t94, label %bb13, label %bb14
bb13:
  %t95 = load ptr, ptr %l0, !tbaa !29
  store ptr %t95, ptr %l42, !tbaa !29
  %t96 = load i32, ptr %l4, !tbaa !23
  %t98 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t96)
  store %"compiler/mir:Lvalue" %t98, ptr %l44
  br label %bb15
bb14:
  br label %bb17
bb15:
  store { i64, [4 x i64] } zeroinitializer, ptr %t99
  %t100 = getelementptr { i64, [4 x i64] }, ptr %t99, i32 0, i32 0
  store i64 1, ptr %t100
  %t101 = load %"compiler/mir:Lvalue", ptr %l44
  %t102 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t101, 0
  %t103 = getelementptr { i64, [4 x i64] }, ptr %t99, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t102, ptr %t103
  %t104 = load { i64, [4 x i64] }, ptr %t99
  %t105 = load %"compiler/source:Span", ptr %l1
  %t106 = load ptr, ptr %l42, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2emainPayloads(ptr %v0, ptr %v1, ptr %v2, ptr %t106, { i64, [4 x i64] } %t104, %"compiler/source:Span" %t105)
  br label %bb16
bb16:
  br label %bb17
bb17:
  %t109 = load ptr, ptr %l0, !tbaa !29
  store ptr %t109, ptr %l47, !tbaa !29
  %t110 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t110, ptr %l48
  %t111 = load i32, ptr %l4, !tbaa !23
  %t113 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t111)
  store %"compiler/mir:Lvalue" %t113, ptr %l50
  br label %bb18
bb18:
  store { i64, [4 x i64] } zeroinitializer, ptr %t114
  %t115 = getelementptr { i64, [4 x i64] }, ptr %t114, i32 0, i32 0
  store i64 1, ptr %t115
  %t116 = load %"compiler/mir:Lvalue", ptr %l50
  %t117 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t116, 0
  %t118 = getelementptr { i64, [4 x i64] }, ptr %t114, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t117, ptr %t118
  %t119 = load { i64, [4 x i64] }, ptr %t114
  store { i64, [8 x i64] } zeroinitializer, ptr %t120
  %t121 = getelementptr { i64, [8 x i64] }, ptr %t120, i32 0, i32 0
  store i64 7, ptr %t121
  %t122 = load %"compiler/source:Span", ptr %l48
  %t123 = insertvalue { %"compiler/source:Span", { i64, [4 x i64] } } undef, %"compiler/source:Span" %t122, 0
  %t125 = insertvalue { %"compiler/source:Span", { i64, [4 x i64] } } %t123, { i64, [4 x i64] } %t119, 1
  %t126 = getelementptr { i64, [8 x i64] }, ptr %t120, i32 0, i32 1
  store { %"compiler/source:Span", { i64, [4 x i64] } } %t125, ptr %t126
  %t127 = load { i64, [8 x i64] }, ptr %t120
  %t128 = load ptr, ptr %l47, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %v2, ptr %v1, ptr %t128, { i64, [8 x i64] } %t127)
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2ereadHere(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, ptr %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca { i64, ptr }
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca i1
  %l25 = alloca ptr
  %l28 = alloca i64
  %l32 = alloca i1
  %l36 = alloca i1
  %l41 = alloca i1
  %l42 = alloca ptr
  %l43 = alloca i1
  %l53 = alloca ptr
  %l54 = alloca i1
  %l63 = alloca i1
  %l66 = alloca i1
  %l71 = alloca { i64, ptr }
  %l75 = alloca ptr
  %l76 = alloca i1
  %l84 = alloca ptr
  %l85 = alloca i1
  %l94 = alloca ptr
  %l95 = alloca i1
  %l104 = alloca i1
  %l109 = alloca ptr
  %l117 = alloca ptr
  %l118 = alloca i1
  %l127 = alloca ptr
  %l135 = alloca ptr
  %l136 = alloca i1
  %l141 = alloca ptr
  %l142 = alloca i1
  %s5 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t2 = load ptr, ptr %l13, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l13, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 6
  store i1 %t8, ptr %l14, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l14, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l4, !tbaa !29
  br label %bb5
bb4:
  br label %bb15
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/lower:lowering", ptr %t16, i32 0, i32 63
  %t19 = load ptr, ptr %l4, !tbaa !29
  %t21 = getelementptr %"compiler/typed:Call", ptr %t19, i32 0, i32 2
  %t22 = load i32, ptr %t21, !tbaa !23
  %t24 = sext i32 %t22 to i64
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t18, i64 %t24, i1 true)
  br label %bb6
bb6:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/lower:lowering", ptr %t27, i32 0, i32 82
  store ptr %t29, ptr %l25, !tbaa !29
  %t30 = load ptr, ptr %l4, !tbaa !29
  %t32 = getelementptr %"compiler/typed:Call", ptr %t30, i32 0, i32 2
  %t33 = load i32, ptr %t32, !tbaa !23
  %t35 = sext i32 %t33 to i64
  store i64 %t35, ptr %l28, !tbaa !24
  %t36 = load ptr, ptr %l2, !tbaa !29
  %t38 = icmp eq ptr %t36, null
  %t40 = xor i1 %t38, true
  br i1 %t40, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l32, !tbaa !21
  br label %bb9
bb8:
  %t42 = load ptr, ptr %l3, !tbaa !29
  %t44 = icmp eq ptr %t42, null
  %t46 = xor i1 %t44, true
  store i1 %t46, ptr %l32, !tbaa !21
  br label %bb9
bb9:
  %t48 = load i1, ptr %l32, !tbaa !21
  br i1 %t48, label %bb10, label %bb11
bb10:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t50 = load ptr, ptr %l4, !tbaa !29
  %t51 = load ptr, ptr %l2, !tbaa !29
  %t52 = load ptr, ptr %l3, !tbaa !29
  %t57 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2ewindowQuiet(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %t49, ptr %t50, ptr %t51, ptr %t52)
  store i1 %t57, ptr %l41
  br label %bb12
bb11:
  store i1 false, ptr %l36, !tbaa !21
  br label %bb13
bb12:
  %t58 = load i1, ptr %l41, !tbaa !21
  store i1 %t58, ptr %l36, !tbaa !21
  br label %bb13
bb13:
  %t59 = load ptr, ptr %l25, !tbaa !29
  %t60 = load i64, ptr %l28, !tbaa !24
  %t61 = load i1, ptr %l36, !tbaa !21
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t59, i64 %t60, i1 %t61)
  br label %bb14
bb14:
  br label %bb97
bb15:
  %t62 = load ptr, ptr %l1, !tbaa !29
  store ptr %t62, ptr %l42, !tbaa !29
  store i1 false, ptr %l43, !tbaa !21
  %t63 = load ptr, ptr %l42, !tbaa !29
  %t64 = icmp ne ptr %t63, null
  br i1 %t64, label %bb16, label %bb17
bb16:
  %t66 = load ptr, ptr %l42, !tbaa !29
  %t67 = load i64, ptr %t66, !range !{i64 0, i64 18}
  %t69 = icmp eq i64 %t67, 5
  store i1 %t69, ptr %l43, !tbaa !21
  br label %bb17
bb17:
  %t70 = load i1, ptr %l43, !tbaa !21
  br i1 %t70, label %bb18, label %bb19
bb18:
  %t71 = load ptr, ptr %l1, !tbaa !29
  %t73 = getelementptr { i64, [5 x i64] }, ptr %t71, i32 0, i32 1
  %t74 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t73, i32 0, i32 2
  %t75 = load ptr, ptr %t74
  store ptr %t75, ptr %l5, !tbaa !29
  br label %bb20
bb19:
  br label %bb22
bb20:
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t78 = load ptr, ptr %l5, !tbaa !29
  %t80 = getelementptr %"compiler/typed:Promote", ptr %t78, i32 0, i32 0
  %t81 = load ptr, ptr %t80, !tbaa !29
  %t82 = load ptr, ptr %l2, !tbaa !29
  %t83 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2ereadHere(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %t77, ptr %t81, ptr %t82, ptr %t83)
  br label %bb21
bb21:
  br label %bb97
bb22:
  %t88 = load ptr, ptr %l1, !tbaa !29
  store ptr %t88, ptr %l53, !tbaa !29
  store i1 false, ptr %l54, !tbaa !21
  %t89 = load ptr, ptr %l53, !tbaa !29
  %t90 = icmp ne ptr %t89, null
  br i1 %t90, label %bb23, label %bb24
bb23:
  %t92 = load ptr, ptr %l53, !tbaa !29
  %t93 = load i64, ptr %t92, !range !{i64 0, i64 18}
  %t95 = icmp eq i64 %t93, 9
  store i1 %t95, ptr %l54, !tbaa !21
  br label %bb24
bb24:
  %t96 = load i1, ptr %l54, !tbaa !21
  br i1 %t96, label %bb25, label %bb26
bb25:
  %t97 = load ptr, ptr %l1, !tbaa !29
  %t99 = getelementptr { i64, [5 x i64] }, ptr %t97, i32 0, i32 1
  %t100 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t99, i32 0, i32 2
  %t101 = load i32, ptr %t100, !range !{i32 0, i32 54}
  store i32 %t101, ptr %l6
  %t103 = load ptr, ptr %l1, !tbaa !29
  %t105 = getelementptr { i64, [5 x i64] }, ptr %t103, i32 0, i32 1
  %t106 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t105, i32 0, i32 4
  %t107 = load { i64, ptr }, ptr %t106
  store { i64, ptr } %t107, ptr %l7, !tbaa !27
  br label %bb27
bb26:
  br label %bb38
bb27:
  %t109 = load i32, ptr %l6, !range !{i32 0, i32 54}
  %t111 = trunc i64 20 to i32
  %t112 = icmp eq i32 %t109, %t111
  br i1 %t112, label %bb28, label %bb29
bb28:
  store i1 true, ptr %l63, !tbaa !21
  br label %bb30
bb29:
  %t114 = load i32, ptr %l6, !range !{i32 0, i32 54}
  %t116 = trunc i64 22 to i32
  %t117 = icmp eq i32 %t114, %t116
  store i1 %t117, ptr %l63, !tbaa !21
  br label %bb30
bb30:
  %t119 = load i1, ptr %l63, !tbaa !21
  br i1 %t119, label %bb31, label %bb32
bb31:
  %t120 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t122 = extractvalue { i64, ptr } %t120, 0
  %t124 = icmp eq i64 %t122, 1
  store i1 %t124, ptr %l66, !tbaa !21
  br label %bb33
bb32:
  store i1 false, ptr %l66, !tbaa !21
  br label %bb33
bb33:
  %t126 = load i1, ptr %l66, !tbaa !21
  br i1 %t126, label %bb34, label %bb35
bb34:
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t128 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t128, ptr %l71, !tbaa !27
  %t129 = getelementptr { i64, ptr }, ptr %l71, i32 0, i32 1
  %t130 = load ptr, ptr %t129, !tbaa !27
  %t131 = getelementptr ptr, ptr %t130, i64 0
  %t132 = load ptr, ptr %t131, !tbaa !39
  %t133 = load ptr, ptr %l2, !tbaa !29
  %t134 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2ereadHere(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %t127, ptr %t132, ptr %t133, ptr %t134)
  br label %bb36
bb35:
  br label %bb37
bb36:
  br label %bb37
bb37:
  br label %bb97
bb38:
  %t139 = load ptr, ptr %l1, !tbaa !29
  store ptr %t139, ptr %l75, !tbaa !29
  store i1 false, ptr %l76, !tbaa !21
  %t140 = load ptr, ptr %l75, !tbaa !29
  %t141 = icmp ne ptr %t140, null
  br i1 %t141, label %bb39, label %bb40
bb39:
  %t143 = load ptr, ptr %l75, !tbaa !29
  %t144 = load i64, ptr %t143, !range !{i64 0, i64 18}
  %t146 = icmp eq i64 %t144, 10
  store i1 %t146, ptr %l76, !tbaa !21
  br label %bb40
bb40:
  %t147 = load i1, ptr %l76, !tbaa !21
  br i1 %t147, label %bb41, label %bb42
bb41:
  %t148 = load ptr, ptr %l1, !tbaa !29
  %t150 = getelementptr { i64, [5 x i64] }, ptr %t148, i32 0, i32 1
  %t151 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t150, i32 0, i32 2
  %t152 = load ptr, ptr %t151
  store ptr %t152, ptr %l8, !tbaa !29
  br label %bb43
bb42:
  br label %bb45
bb43:
  store %olang.scope zeroinitializer, ptr %s5
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t155 = load ptr, ptr %l8, !tbaa !29
  %t157 = getelementptr %"compiler/typed:Slice", ptr %t155, i32 0, i32 0
  %t158 = load ptr, ptr %t157, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2ereadPlace(ptr %v0, ptr %v1, ptr %s5, ptr %s5, ptr %v4, ptr %v5, ptr %t154, ptr %t158, ptr null, ptr null)
  br label %bb44
bb44:
  call void @__olang_scope_close(ptr %s5)
  br label %bb97
bb45:
  %t161 = load ptr, ptr %l1, !tbaa !29
  store ptr %t161, ptr %l84, !tbaa !29
  store i1 false, ptr %l85, !tbaa !21
  %t162 = load ptr, ptr %l84, !tbaa !29
  %t163 = icmp ne ptr %t162, null
  br i1 %t163, label %bb46, label %bb47
bb46:
  %t165 = load ptr, ptr %l84, !tbaa !29
  %t166 = load i64, ptr %t165, !range !{i64 0, i64 18}
  %t168 = icmp eq i64 %t166, 17
  store i1 %t168, ptr %l85, !tbaa !21
  br label %bb47
bb47:
  %t169 = load i1, ptr %l85, !tbaa !21
  br i1 %t169, label %bb48, label %bb49
bb48:
  %t170 = load ptr, ptr %l1, !tbaa !29
  %t172 = getelementptr { i64, [5 x i64] }, ptr %t170, i32 0, i32 1
  %t173 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t172, i32 0, i32 2
  %t174 = load ptr, ptr %t173
  store ptr %t174, ptr %l9, !tbaa !29
  br label %bb50
bb49:
  br label %bb52
bb50:
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t177 = load ptr, ptr %l9, !tbaa !29
  %t178 = load ptr, ptr %l2, !tbaa !29
  %t179 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2ereadHere(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %t176, ptr %t177, ptr %t178, ptr %t179)
  br label %bb51
bb51:
  br label %bb97
bb52:
  %t184 = load ptr, ptr %l1, !tbaa !29
  store ptr %t184, ptr %l94, !tbaa !29
  store i1 false, ptr %l95, !tbaa !21
  %t185 = load ptr, ptr %l94, !tbaa !29
  %t186 = icmp ne ptr %t185, null
  br i1 %t186, label %bb53, label %bb54
bb53:
  %t188 = load ptr, ptr %l94, !tbaa !29
  %t189 = load i64, ptr %t188, !range !{i64 0, i64 18}
  %t191 = icmp eq i64 %t189, 12
  store i1 %t191, ptr %l95, !tbaa !21
  br label %bb54
bb54:
  %t192 = load i1, ptr %l95, !tbaa !21
  br i1 %t192, label %bb55, label %bb56
bb55:
  %t193 = load ptr, ptr %l1, !tbaa !29
  %t195 = getelementptr { i64, [5 x i64] }, ptr %t193, i32 0, i32 1
  %t196 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t195, i32 0, i32 2
  %t197 = load ptr, ptr %t196
  store ptr %t197, ptr %l10, !tbaa !29
  br label %bb57
bb56:
  br label %bb68
bb57:
  %t199 = load ptr, ptr %l10, !tbaa !29
  %t201 = getelementptr %"compiler/typed:Seq", ptr %t199, i32 0, i32 1
  %t202 = load ptr, ptr %t201, !tbaa !29
  %t204 = icmp eq ptr %t202, null
  %t206 = xor i1 %t204, true
  br i1 %t206, label %bb58, label %bb59
bb58:
  %t208 = load ptr, ptr %l10, !tbaa !29
  %t210 = getelementptr %"compiler/typed:Seq", ptr %t208, i32 0, i32 0
  %t211 = load { i64, ptr }, ptr %t210, !tbaa !27
  %t213 = extractvalue { i64, ptr } %t211, 0
  %t215 = icmp eq i64 %t213, 0
  store i1 %t215, ptr %l104, !tbaa !21
  br label %bb60
bb59:
  store i1 false, ptr %l104, !tbaa !21
  br label %bb60
bb60:
  %t217 = load i1, ptr %l104, !tbaa !21
  br i1 %t217, label %bb61, label %bb62
bb61:
  %t218 = load ptr, ptr %l0, !tbaa !29
  store ptr %t218, ptr %l109, !tbaa !29
  %t219 = load ptr, ptr %l10, !tbaa !29
  %t221 = getelementptr %"compiler/typed:Seq", ptr %t219, i32 0, i32 1
  %t222 = load ptr, ptr %t221, !tbaa !29
  %t224 = icmp eq ptr %t222, null
  br i1 %t224, label %bb63, label %bb64
bb62:
  br label %bb67
bb63:
  call void @__olang_check_failed(ptr @olang_loc_763e3b2e421df924_4ff52ff107ec1ef8)
  unreachable
bb64:
  br label %bb65
bb65:
  %t226 = load ptr, ptr %l10, !tbaa !29
  %t228 = getelementptr %"compiler/typed:Seq", ptr %t226, i32 0, i32 1
  %t229 = load ptr, ptr %t228, !tbaa !29
  %t230 = load ptr, ptr %l2, !tbaa !29
  %t231 = load ptr, ptr %l3, !tbaa !29
  %t232 = load ptr, ptr %l109, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2ereadHere(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %t232, ptr %t229, ptr %t230, ptr %t231)
  br label %bb66
bb66:
  br label %bb67
bb67:
  br label %bb97
bb68:
  %t236 = load ptr, ptr %l1, !tbaa !29
  store ptr %t236, ptr %l117, !tbaa !29
  store i1 false, ptr %l118, !tbaa !21
  %t237 = load ptr, ptr %l117, !tbaa !29
  %t238 = icmp ne ptr %t237, null
  br i1 %t238, label %bb69, label %bb70
bb69:
  %t240 = load ptr, ptr %l117, !tbaa !29
  %t241 = load i64, ptr %t240, !range !{i64 0, i64 18}
  %t243 = icmp eq i64 %t241, 14
  store i1 %t243, ptr %l118, !tbaa !21
  br label %bb70
bb70:
  %t244 = load i1, ptr %l118, !tbaa !21
  br i1 %t244, label %bb71, label %bb72
bb71:
  %t245 = load ptr, ptr %l1, !tbaa !29
  %t247 = getelementptr { i64, [5 x i64] }, ptr %t245, i32 0, i32 1
  %t248 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t247, i32 0, i32 2
  %t249 = load ptr, ptr %t248
  store ptr %t249, ptr %l11, !tbaa !29
  br label %bb73
bb72:
  br label %bb81
bb73:
  %t251 = load ptr, ptr %l11, !tbaa !29
  %t253 = getelementptr %"compiler/typed:Try", ptr %t251, i32 0, i32 0
  %t254 = load ptr, ptr %t253, !tbaa !29
  %t256 = icmp eq ptr %t254, null
  %t258 = xor i1 %t256, true
  br i1 %t258, label %bb74, label %bb75
bb74:
  %t260 = load ptr, ptr %l0, !tbaa !29
  store ptr %t260, ptr %l127, !tbaa !29
  %t261 = load ptr, ptr %l11, !tbaa !29
  %t263 = getelementptr %"compiler/typed:Try", ptr %t261, i32 0, i32 0
  %t264 = load ptr, ptr %t263, !tbaa !29
  %t266 = icmp eq ptr %t264, null
  br i1 %t266, label %bb76, label %bb77
bb75:
  br label %bb80
bb76:
  call void @__olang_check_failed(ptr @olang_loc_292009f276c7a2f3_194bd9ce8dfbeb17)
  unreachable
bb77:
  br label %bb78
bb78:
  %t268 = load ptr, ptr %l11, !tbaa !29
  %t270 = getelementptr %"compiler/typed:Try", ptr %t268, i32 0, i32 0
  %t271 = load ptr, ptr %t270, !tbaa !29
  %t272 = load ptr, ptr %l2, !tbaa !29
  %t273 = load ptr, ptr %l3, !tbaa !29
  %t274 = load ptr, ptr %l127, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2ereadHere(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %t274, ptr %t271, ptr %t272, ptr %t273)
  br label %bb79
bb79:
  br label %bb80
bb80:
  br label %bb97
bb81:
  %t278 = load ptr, ptr %l1, !tbaa !29
  store ptr %t278, ptr %l135, !tbaa !29
  store i1 false, ptr %l136, !tbaa !21
  %t279 = load ptr, ptr %l135, !tbaa !29
  %t280 = icmp ne ptr %t279, null
  br i1 %t280, label %bb82, label %bb83
bb82:
  %t282 = load ptr, ptr %l135, !tbaa !29
  %t283 = load i64, ptr %t282, !range !{i64 0, i64 18}
  %t285 = icmp eq i64 %t283, 2
  store i1 %t285, ptr %l136, !tbaa !21
  br label %bb83
bb83:
  %t286 = load i1, ptr %l136, !tbaa !21
  br i1 %t286, label %bb84, label %bb85
bb84:
  %t287 = load ptr, ptr %l1, !tbaa !29
  %t289 = getelementptr { i64, [5 x i64] }, ptr %t287, i32 0, i32 1
  %t290 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t289, i32 0, i32 2
  %t291 = load ptr, ptr %t290
  store ptr %t291, ptr %l12, !tbaa !29
  br label %bb90
bb85:
  %t293 = load ptr, ptr %l1, !tbaa !29
  store ptr %t293, ptr %l141, !tbaa !29
  store i1 false, ptr %l142, !tbaa !21
  %t294 = load ptr, ptr %l141, !tbaa !29
  %t295 = icmp ne ptr %t294, null
  br i1 %t295, label %bb86, label %bb87
bb86:
  %t297 = load ptr, ptr %l141, !tbaa !29
  %t298 = load i64, ptr %t297, !range !{i64 0, i64 18}
  %t300 = icmp eq i64 %t298, 3
  store i1 %t300, ptr %l142, !tbaa !21
  br label %bb87
bb87:
  %t301 = load i1, ptr %l142, !tbaa !21
  br i1 %t301, label %bb88, label %bb89
bb88:
  %t302 = load ptr, ptr %l1, !tbaa !29
  %t304 = getelementptr { i64, [5 x i64] }, ptr %t302, i32 0, i32 1
  %t305 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t304, i32 0, i32 2
  %t306 = load ptr, ptr %t305
  store ptr %t306, ptr %l12, !tbaa !29
  br label %bb90
bb89:
  br label %bb92
bb90:
  %t308 = load ptr, ptr %l0, !tbaa !29
  %t309 = load ptr, ptr %l12, !tbaa !29
  %t310 = load ptr, ptr %l2, !tbaa !29
  %t311 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2ereadPlace(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %t308, ptr %t309, ptr %t310, ptr %t311)
  br label %bb91
bb91:
  br label %bb97
bb92:
  br i1 true, label %bb93, label %bb94
bb93:
  br label %bb95
bb94:
  br label %bb96
bb95:
  br label %bb97
bb96:
  call void @__olang_check_failed(ptr @olang_loc_a9234ad2dabfd921_4df0c0618daabfe5)
  unreachable
bb97:
  br label %ret
ret:
  ret void
}

define dso_local { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2erefTo(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/lower:pl" %a1, i32 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca i32
  %l6 = alloca ptr
  %l10 = alloca i32
  %l11 = alloca ptr
  %l12 = alloca i32
  %l13 = alloca ptr
  %l14 = alloca %"compiler/lower:pl"
  %l16 = alloca %"compiler/lower:pl"
  %l17 = alloca %"compiler/mir:Lvalue"
  %l21 = alloca { i64, [4 x i64] }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, [4 x i64] }
  %t28 = alloca { i64, [15 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l6, !tbaa !29
  %t6 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t7 = load ptr, ptr %l6, !tbaa !29
  %t8 = call ptr @__olang_scope_or(ptr %v2, ptr %t7)
  %t9 = call ptr @__olang_scope_hold(ptr %t8)
  %t10 = ptrtoint ptr %t9 to i64
  %t12 = inttoptr i64 %t10 to ptr
  %t13 = load ptr, ptr %l6, !tbaa !29
  %t16 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %t12, ptr %t13, i32 %a2, i64 %t6)
  store i32 %t16, ptr %l10
  br label %bb1
bb1:
  %t17 = load i32, ptr %l10, !tbaa !23
  store i32 %t17, ptr %l4, !tbaa !23
  %t18 = load ptr, ptr %l0, !tbaa !29
  store ptr %t18, ptr %l11, !tbaa !29
  %t19 = load i32, ptr %l4, !tbaa !23
  store i32 %t19, ptr %l12, !tbaa !23
  %t20 = load ptr, ptr %l0, !tbaa !29
  store ptr %t20, ptr %l13, !tbaa !29
  store %"compiler/lower:pl" %a1, ptr %l14
  %t23 = call %"compiler/lower:pl" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2flower_3apl(ptr %s0, ptr %l14)
  store %"compiler/lower:pl" %t23, ptr %l16
  br label %bb2
bb2:
  %t24 = load ptr, ptr %l13, !tbaa !29
  %t25 = load %"compiler/lower:pl", ptr %l16
  %t26 = call %"compiler/mir:Lvalue" @compiler_2flower_2ecompiler_2flower_3alowering_2emk(ptr %v0, ptr %s0, ptr %v3, ptr %t24, %"compiler/lower:pl" %t25)
  store %"compiler/mir:Lvalue" %t26, ptr %l17
  br label %bb3
bb3:
  %t27 = load i32, ptr %l4, !tbaa !23
  store { i64, [15 x i64] } zeroinitializer, ptr %t28
  %t29 = getelementptr { i64, [15 x i64] }, ptr %t28, i32 0, i32 0
  store i64 1, ptr %t29
  %t30 = load %"compiler/mir:Lvalue", ptr %l17
  %t31 = insertvalue { %"compiler/mir:Lvalue", i32 } undef, %"compiler/mir:Lvalue" %t30, 0
  %t33 = insertvalue { %"compiler/mir:Lvalue", i32 } %t31, i32 %t27, 1
  %t34 = getelementptr { i64, [15 x i64] }, ptr %t28, i32 0, i32 1
  store { %"compiler/mir:Lvalue", i32 } %t33, ptr %t34
  %t35 = load { i64, [15 x i64] }, ptr %t28
  %t37 = load ptr, ptr %l11, !tbaa !29
  %t38 = load i32, ptr %l12, !tbaa !23
  %t41 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %v2, ptr %v3, ptr %t37, i32 %t38, { i64, [15 x i64] } %t35, %"compiler/source:Span" %a3)
  store { i64, [4 x i64] } %t41, ptr %l21
  br label %bb4
bb4:
  call void @__olang_scope_close(ptr %s0)
  %t42 = load { i64, [4 x i64] }, ptr %l21
  store { i64, [4 x i64] } %t42, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2ereleaseAt(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, i32 %a1, ptr %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l4 = alloca ptr
  %l7 = alloca %"compiler/lower:pl"
  %s0 = alloca %olang.scope
  %t3 = alloca { i64, [2 x i64] }, align 8
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store ptr %a0, ptr %l4, !tbaa !29
  store { i64, [2 x i64] } zeroinitializer, ptr %t3
  %t4 = getelementptr { i64, [2 x i64] }, ptr %t3, i32 0, i32 0
  store i64 1, ptr %t4
  %t6 = insertvalue { i32 } undef, i32 %a1, 0
  %t7 = getelementptr { i64, [2 x i64] }, ptr %t3, i32 0, i32 1
  store { i32 } %t6, ptr %t7
  %t8 = load { i64, [2 x i64] }, ptr %t3
  %t10 = call %"compiler/lower:pl" @compiler_2flower_3apl_2ector(ptr %s0, { i64, [2 x i64] } %t8)
  store %"compiler/lower:pl" %t10, ptr %l7
  br label %bb1
bb1:
  %t13 = load ptr, ptr %l4, !tbaa !29
  %t14 = load %"compiler/lower:pl", ptr %l7
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2ereleaseOn(ptr %v0, ptr %s0, ptr %v1, ptr %v2, ptr %v3, ptr %t13, %"compiler/lower:pl" %t14, ptr %a2, %"compiler/source:Span" %a3)
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2erenderPayload(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/lower:pl" %a1, i64 %a2, i32 %a3, { i64, [1 x i64] } %a4, %"compiler/source:Span" %a5) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca { i64, [1 x i64] }
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca ptr
  %l15 = alloca ptr
  %l18 = alloca i32
  %l19 = alloca { i64, ptr }
  %l31 = alloca i64
  %l34 = alloca i64
  %l57 = alloca ptr
  %l58 = alloca ptr
  %l59 = alloca ptr
  %l60 = alloca %"compiler/lower:pl"
  %l62 = alloca %"compiler/lower:pl"
  %l65 = alloca %"compiler/lower:pl"
  %l68 = alloca %"compiler/lower:pl"
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %t99 = alloca { i64, [1 x i64] }, align 8
  %t110 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  store { i64, [1 x i64] } %a4, ptr %l4
  store %"compiler/source:Span" %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l13, !tbaa !29
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"compiler/lower:lowering", ptr %t2, i32 0, i32 2
  %t5 = load ptr, ptr %t4, !tbaa !29
  store ptr %t5, ptr %l15, !tbaa !29
  %t7 = load ptr, ptr %l15, !tbaa !29
  %t8 = call ptr @__olang_scope_or(ptr %v2, ptr %t7)
  %t9 = call ptr @__olang_scope_hold(ptr %t8)
  %t10 = ptrtoint ptr %t9 to i64
  %t12 = inttoptr i64 %t10 to ptr
  %t13 = load ptr, ptr %l15, !tbaa !29
  %t15 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %t12, ptr %t13, i32 %a3)
  store i32 %t15, ptr %l18
  br label %bb1
bb1:
  %t16 = load ptr, ptr %l13, !tbaa !29
  %t17 = load i32, ptr %l18, !tbaa !23
  %t18 = call { i64, ptr } @compiler_2flower_2ecompiler_2flower_3alowering_2eitems(ptr %v0, ptr %s0, ptr %v2, ptr %t16, i32 %t17)
  store { i64, ptr } %t18, ptr %l19
  br label %bb2
bb2:
  %t19 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t19, ptr %l6, !tbaa !27
  %t20 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t22 = extractvalue { i64, ptr } %t20, 0
  %t24 = icmp eq i64 %t22, 0
  br i1 %t24, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb4:
  br label %bb5
bb5:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t27 = load { i64, [1 x i64] }, ptr %l4
  %t28 = load %"compiler/source:Span", ptr %l5
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eword(ptr %v0, ptr %s0, ptr %v2, ptr %v3, ptr %t26, { i64, [1 x i64] } %t27, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d10, i32 0, i32 1) }, %"compiler/source:Span" %t28)
  br label %bb6
bb6:
  store i64 0, ptr %l7, !tbaa !24
  %t32 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t34 = extractvalue { i64, ptr } %t32, 0
  store i64 %t34, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t36 = load i64, ptr %l8, !tbaa !24
  %t37 = load i64, ptr %l7, !tbaa !24
  %t40 = icmp sgt i64 %t36, %t37
  br i1 %t40, label %bb7, label %bb8
bb7:
  %t42 = load i64, ptr %l9, !tbaa !24
  %t44 = icmp sgt i64 %t42, 0
  br i1 %t44, label %bb9, label %bb10
bb8:
  store i64 0, ptr %l31, !tbaa !24
  br label %bb12
bb9:
  %t46 = load i64, ptr %l8, !tbaa !24
  %t47 = load i64, ptr %l7, !tbaa !24
  %t50 = sub i64 %t46, %t47
  %t51 = load i64, ptr %l9, !tbaa !24
  %t54 = add i64 %t50, %t51
  %t56 = sub i64 %t54, 1
  %t57 = load i64, ptr %l9, !tbaa !24
  %t60 = sdiv i64 %t56, %t57
  store i64 %t60, ptr %l34, !tbaa !24
  br label %bb11
bb10:
  store i64 0, ptr %l34, !tbaa !24
  br label %bb11
bb11:
  %t62 = load i64, ptr %l34, !tbaa !24
  store i64 %t62, ptr %l31, !tbaa !24
  br label %bb12
bb12:
  %t63 = load i64, ptr %l31, !tbaa !24
  store i64 %t63, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb13
bb13:
  store %olang.scope zeroinitializer, ptr %s3
  %t64 = load i64, ptr %l11, !tbaa !24
  %t65 = load i64, ptr %l10, !tbaa !24
  %t68 = icmp slt i64 %t64, %t65
  %t70 = xor i1 %t68, true
  br i1 %t70, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s3)
  br label %bb26
bb15:
  br label %bb16
bb16:
  %t72 = load i64, ptr %l7, !tbaa !24
  %t73 = load i64, ptr %l11, !tbaa !24
  %t74 = load i64, ptr %l9, !tbaa !24
  %t77 = mul i64 %t73, %t74
  %t80 = add i64 %t72, %t77
  store i64 %t80, ptr %l12, !tbaa !24
  %t82 = load i64, ptr %l12, !tbaa !24
  %t84 = icmp sgt i64 %t82, 0
  br i1 %t84, label %bb17, label %bb18
bb17:
  store %olang.scope zeroinitializer, ptr %s4
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t87 = load { i64, [1 x i64] }, ptr %l4
  %t88 = load %"compiler/source:Span", ptr %l5
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eword(ptr %v0, ptr %s4, ptr %v2, ptr %v3, ptr %t86, { i64, [1 x i64] } %t87, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d11, i32 0, i32 1) }, %"compiler/source:Span" %t88)
  br label %bb19
bb18:
  br label %bb20
bb19:
  call void @__olang_scope_close(ptr %s4)
  br label %bb20
bb20:
  %t92 = load ptr, ptr %l0, !tbaa !29
  store ptr %t92, ptr %l57, !tbaa !29
  %t93 = load ptr, ptr %l0, !tbaa !29
  store ptr %t93, ptr %l58, !tbaa !29
  %t94 = load ptr, ptr %l0, !tbaa !29
  store ptr %t94, ptr %l59, !tbaa !29
  store %"compiler/lower:pl" %a1, ptr %l60
  %t97 = call %"compiler/lower:pl" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2flower_3apl(ptr %s3, ptr %l60)
  store %"compiler/lower:pl" %t97, ptr %l62
  br label %bb21
bb21:
  store { i64, [1 x i64] } zeroinitializer, ptr %t99
  %t100 = getelementptr { i64, [1 x i64] }, ptr %t99, i32 0, i32 0
  store i64 4, ptr %t100
  %t102 = insertvalue { i64 } undef, i64 %a2, 0
  %t103 = getelementptr { i64, [1 x i64] }, ptr %t99, i32 0, i32 1
  store { i64 } %t102, ptr %t103
  %t104 = load { i64, [1 x i64] }, ptr %t99
  %t105 = load ptr, ptr %l59, !tbaa !29
  %t106 = load %"compiler/lower:pl", ptr %l62
  %t108 = call %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2ewith(ptr %v0, ptr %s3, ptr %s3, ptr %t105, %"compiler/lower:pl" %t106, { i64, [1 x i64] } %t104)
  store %"compiler/lower:pl" %t108, ptr %l65
  br label %bb22
bb22:
  %t109 = load i64, ptr %l12, !tbaa !24
  store { i64, [1 x i64] } zeroinitializer, ptr %t110
  %t111 = getelementptr { i64, [1 x i64] }, ptr %t110, i32 0, i32 0
  store i64 0, ptr %t111
  %t113 = insertvalue { i64 } undef, i64 %t109, 0
  %t114 = getelementptr { i64, [1 x i64] }, ptr %t110, i32 0, i32 1
  store { i64 } %t113, ptr %t114
  %t115 = load { i64, [1 x i64] }, ptr %t110
  %t116 = load ptr, ptr %l58, !tbaa !29
  %t117 = load %"compiler/lower:pl", ptr %l65
  %t119 = call %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2ewith(ptr %v0, ptr %s3, ptr %s3, ptr %t116, %"compiler/lower:pl" %t117, { i64, [1 x i64] } %t115)
  store %"compiler/lower:pl" %t119, ptr %l68
  br label %bb23
bb23:
  %t120 = load i64, ptr %l12, !tbaa !24
  %t122 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t123 = load ptr, ptr %t122, !tbaa !27
  %t124 = getelementptr i32, ptr %t123, i64 %t120
  %t125 = load i32, ptr %t124, !tbaa !33
  %t126 = load { i64, [1 x i64] }, ptr %l4
  %t127 = load %"compiler/source:Span", ptr %l5
  %t128 = load ptr, ptr %l57, !tbaa !29
  %t129 = load %"compiler/lower:pl", ptr %l68
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2einner(ptr %v0, ptr %s3, ptr %v2, ptr %v3, ptr %t128, %"compiler/lower:pl" %t129, i32 %t125, { i64, [1 x i64] } %t126, %"compiler/source:Span" %t127)
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s3)
  br label %bb25
bb25:
  %t133 = load i64, ptr %l11, !tbaa !24
  %t136 = add i64 %t133, 1
  store i64 %t136, ptr %l11, !tbaa !24
  br label %bb13
bb26:
  %t138 = load ptr, ptr %l0, !tbaa !29
  %t139 = load { i64, [1 x i64] }, ptr %l4
  %t140 = load %"compiler/source:Span", ptr %l5
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eword(ptr %v0, ptr %s0, ptr %v2, ptr %v3, ptr %t138, { i64, [1 x i64] } %t139, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d12, i32 0, i32 1) }, %"compiler/source:Span" %t140)
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, [2 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eresultScopeAt(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l11 = alloca ptr
  %l15 = alloca ptr
  %l21 = alloca ptr
  %l25 = alloca { i64, ptr }
  %l31 = alloca i64
  %l34 = alloca i64
  %l57 = alloca ptr
  %l62 = alloca { i64, [2 x i64] }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, [2 x i64] }
  %t133 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l11, !tbaa !29
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/lower:lowering", ptr %t5, i32 0, i32 0
  %t8 = load ptr, ptr %t7, !tbaa !29
  %t10 = getelementptr %"compiler/lower:Lowerer", ptr %t8, i32 0, i32 1
  %t11 = load ptr, ptr %t10, !tbaa !29
  store ptr %t11, ptr %l15, !tbaa !29
  %t14 = load ptr, ptr %l15, !tbaa !29
  %t15 = call ptr @__olang_scope_or(ptr %v2, ptr %t14)
  %t16 = call ptr @__olang_scope_hold(ptr %t15)
  %t17 = ptrtoint ptr %t16 to i64
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/lower:lowering", ptr %t18, i32 0, i32 0
  %t21 = load ptr, ptr %t20, !tbaa !29
  %t23 = call ptr @__olang_scope_or(ptr %v2, ptr %t21)
  %t24 = call ptr @__olang_scope_hold(ptr %t23)
  %t25 = ptrtoint ptr %t24 to i64
  %t27 = inttoptr i64 %t17 to ptr
  %t29 = inttoptr i64 %t25 to ptr
  %t30 = load ptr, ptr %l15, !tbaa !29
  %t32 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %t27, ptr %t29, ptr %t30, i64 %a2)
  store ptr %t32, ptr %l21
  br label %bb1
bb1:
  %t33 = load ptr, ptr %l21, !tbaa !29
  %t35 = getelementptr %"compiler/typed:Body", ptr %t33, i32 0, i32 2
  %t36 = load i32, ptr %t35, !tbaa !23
  %t37 = load ptr, ptr %l11, !tbaa !29
  %t38 = call ptr @__olang_scope_or(ptr %v3, ptr %t37)
  %t39 = call ptr @__olang_scope_hold(ptr %t38)
  %t40 = ptrtoint ptr %t39 to i64
  %t42 = inttoptr i64 %t40 to ptr
  %t43 = load ptr, ptr %l11, !tbaa !29
  %t45 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopeVarsOf(ptr %t42, ptr %s0, ptr %t43, i32 %t36)
  store { i64, ptr } %t45, ptr %l25
  br label %bb2
bb2:
  %t46 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t46, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t47 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t49 = extractvalue { i64, ptr } %t47, 0
  store i64 %t49, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t51 = load i64, ptr %l5, !tbaa !24
  %t52 = load i64, ptr %l4, !tbaa !24
  %t55 = icmp sgt i64 %t51, %t52
  br i1 %t55, label %bb3, label %bb4
bb3:
  %t57 = load i64, ptr %l6, !tbaa !24
  %t59 = icmp sgt i64 %t57, 0
  br i1 %t59, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l31, !tbaa !24
  br label %bb8
bb5:
  %t61 = load i64, ptr %l5, !tbaa !24
  %t62 = load i64, ptr %l4, !tbaa !24
  %t65 = sub i64 %t61, %t62
  %t66 = load i64, ptr %l6, !tbaa !24
  %t69 = add i64 %t65, %t66
  %t71 = sub i64 %t69, 1
  %t72 = load i64, ptr %l6, !tbaa !24
  %t75 = sdiv i64 %t71, %t72
  store i64 %t75, ptr %l34, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l34, !tbaa !24
  br label %bb7
bb7:
  %t77 = load i64, ptr %l34, !tbaa !24
  store i64 %t77, ptr %l31, !tbaa !24
  br label %bb8
bb8:
  %t78 = load i64, ptr %l31, !tbaa !24
  store i64 %t78, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb9
bb9:
  %t79 = load i64, ptr %l8, !tbaa !24
  %t80 = load i64, ptr %l7, !tbaa !24
  %t83 = icmp slt i64 %t79, %t80
  %t85 = xor i1 %t83, true
  br i1 %t85, label %bb10, label %bb11
bb10:
  br label %bb18
bb11:
  br label %bb12
bb12:
  %t87 = load i64, ptr %l4, !tbaa !24
  %t88 = load i64, ptr %l8, !tbaa !24
  %t89 = load i64, ptr %l6, !tbaa !24
  %t92 = mul i64 %t88, %t89
  %t95 = add i64 %t87, %t92
  store i64 %t95, ptr %l9, !tbaa !24
  %t97 = load i64, ptr %l9, !tbaa !24
  %t99 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t100 = load ptr, ptr %t99, !tbaa !27
  %t101 = getelementptr i64, ptr %t100, i64 %t97
  %t102 = load i64, ptr %t101, !tbaa !34
  %t103 = load i64, ptr @G_2ecompiler_2ftypes_2eResultVar, !tbaa !24
  %t106 = icmp eq i64 %t102, %t103
  br i1 %t106, label %bb13, label %bb14
bb13:
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = getelementptr %"compiler/lower:lowering", ptr %t108, i32 0, i32 38
  %t111 = load ptr, ptr %t110, !tbaa !29
  store ptr %t111, ptr %l57, !tbaa !29
  %t114 = getelementptr %"compiler/typed:Call", ptr %a1, i32 0, i32 2
  %t115 = load i32, ptr %t114, !tbaa !23
  %t116 = load i64, ptr %l9, !tbaa !24
  %t117 = load ptr, ptr %l57, !tbaa !29
  %t118 = call ptr @__olang_scope_or(ptr %v4, ptr %t117)
  %t119 = call ptr @__olang_scope_hold(ptr %t118)
  %t120 = ptrtoint ptr %t119 to i64
  %t122 = inttoptr i64 %t120 to ptr
  %t123 = load ptr, ptr %l57, !tbaa !29
  %t126 = call { i64, [2 x i64] } @compiler_2ftyped_2ecompiler_2ftyped_3aPlan_2ePassed(ptr %t122, ptr %t123, i32 %t115, i64 %t116)
  store { i64, [2 x i64] } %t126, ptr %l62
  br label %bb15
bb14:
  br label %bb16
bb15:
  call void @__olang_scope_close(ptr %s0)
  %t127 = load { i64, [2 x i64] }, ptr %l62
  store { i64, [2 x i64] } %t127, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  %t128 = load i64, ptr %l8, !tbaa !24
  %t131 = add i64 %t128, 1
  store i64 %t131, ptr %l8, !tbaa !24
  br label %bb9
bb18:
  store { i64, [2 x i64] } zeroinitializer, ptr %t133
  %t134 = getelementptr { i64, [2 x i64] }, ptr %t133, i32 0, i32 0
  store i64 0, ptr %t134
  %t135 = load { i64, [2 x i64] }, ptr %t133
  call void @__olang_scope_close(ptr %s0)
  store { i64, [2 x i64] } %t135, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [2 x i64] }, ptr %rv
  ret { i64, [2 x i64] } %rr
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eretCopies(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca %"compiler/lower:level"
  %l7 = alloca ptr
  %l8 = alloca %"compiler/source:Span"
  %l9 = alloca i32
  %l11 = alloca i32
  %l12 = alloca ptr
  %l13 = alloca %"compiler/source:Span"
  %l14 = alloca i32
  %l16 = alloca i64
  %l20 = alloca ptr
  %l21 = alloca i1
  %l24 = alloca i1
  %l25 = alloca ptr
  %l26 = alloca i1
  %l29 = alloca i1
  %l30 = alloca ptr
  %l31 = alloca i1
  %l34 = alloca i1
  %l35 = alloca ptr
  %l36 = alloca i1
  %l40 = alloca i1
  %l43 = alloca i1
  %l47 = alloca i1
  %l51 = alloca i1
  %l53 = alloca i1
  %l56 = alloca i1
  %l57 = alloca i1
  %l60 = alloca i1
  %l64 = alloca i1
  %l72 = alloca i64
  %l77 = alloca i64
  %l79 = alloca i64
  %l84 = alloca %"compiler/lower:level"
  %l93 = alloca ptr
  %l94 = alloca ptr
  %l95 = alloca i1
  %l109 = alloca ptr
  %l110 = alloca i1
  %l126 = alloca i1
  %l130 = alloca { i64, [1 x i64] }
  %l131 = alloca ptr
  %l133 = alloca { i64, [1 x i64] }
  %l135 = alloca i1
  %l137 = alloca i1
  %l140 = alloca i1
  %l141 = alloca i1
  %l144 = alloca { i64, ptr }
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l1, !tbaa !29
  store ptr %t6, ptr %l20, !tbaa !29
  store i1 false, ptr %l21, !tbaa !21
  %t7 = load ptr, ptr %l20, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb4, label %bb5
bb4:
  %t10 = load ptr, ptr %l20, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 18}
  %t13 = icmp eq i64 %t11, 11
  store i1 %t13, ptr %l21, !tbaa !21
  br label %bb5
bb5:
  %t14 = load i1, ptr %l21, !tbaa !21
  br i1 %t14, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l24, !tbaa !21
  br label %bb10
bb7:
  %t15 = load ptr, ptr %l1, !tbaa !29
  store ptr %t15, ptr %l25, !tbaa !29
  store i1 false, ptr %l26, !tbaa !21
  %t16 = load ptr, ptr %l25, !tbaa !29
  %t17 = icmp ne ptr %t16, null
  br i1 %t17, label %bb8, label %bb9
bb8:
  %t19 = load ptr, ptr %l25, !tbaa !29
  %t20 = load i64, ptr %t19, !range !{i64 0, i64 18}
  %t22 = icmp eq i64 %t20, 13
  store i1 %t22, ptr %l26, !tbaa !21
  br label %bb9
bb9:
  %t23 = load i1, ptr %l26, !tbaa !21
  store i1 %t23, ptr %l24, !tbaa !21
  br label %bb10
bb10:
  %t24 = load i1, ptr %l24, !tbaa !21
  br i1 %t24, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l29, !tbaa !21
  br label %bb15
bb12:
  %t25 = load ptr, ptr %l1, !tbaa !29
  store ptr %t25, ptr %l30, !tbaa !29
  store i1 false, ptr %l31, !tbaa !21
  %t26 = load ptr, ptr %l30, !tbaa !29
  %t27 = icmp ne ptr %t26, null
  br i1 %t27, label %bb13, label %bb14
bb13:
  %t29 = load ptr, ptr %l30, !tbaa !29
  %t30 = load i64, ptr %t29, !range !{i64 0, i64 18}
  %t32 = icmp eq i64 %t30, 14
  store i1 %t32, ptr %l31, !tbaa !21
  br label %bb14
bb14:
  %t33 = load i1, ptr %l31, !tbaa !21
  store i1 %t33, ptr %l29, !tbaa !21
  br label %bb15
bb15:
  %t34 = load i1, ptr %l29, !tbaa !21
  br i1 %t34, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l34, !tbaa !21
  br label %bb20
bb17:
  %t35 = load ptr, ptr %l1, !tbaa !29
  store ptr %t35, ptr %l35, !tbaa !29
  store i1 false, ptr %l36, !tbaa !21
  %t36 = load ptr, ptr %l35, !tbaa !29
  %t37 = icmp ne ptr %t36, null
  br i1 %t37, label %bb18, label %bb19
bb18:
  %t39 = load ptr, ptr %l35, !tbaa !29
  %t40 = load i64, ptr %t39, !range !{i64 0, i64 18}
  %t42 = icmp eq i64 %t40, 12
  store i1 %t42, ptr %l36, !tbaa !21
  br label %bb19
bb19:
  %t43 = load i1, ptr %l36, !tbaa !21
  store i1 %t43, ptr %l34, !tbaa !21
  br label %bb20
bb20:
  %t44 = load i1, ptr %l34, !tbaa !21
  br i1 %t44, label %bb21, label %bb22
bb21:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t48 = load i32, ptr %l2, !tbaa !23
  %t51 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2evalueArray(ptr %v0, ptr %v2, ptr %t47, i32 %t48)
  store i1 %t51, ptr %l43
  br label %bb23
bb22:
  store i1 false, ptr %l40, !tbaa !21
  br label %bb24
bb23:
  %t52 = load i1, ptr %l43, !tbaa !21
  store i1 %t52, ptr %l40, !tbaa !21
  br label %bb24
bb24:
  %t53 = load i1, ptr %l40, !tbaa !21
  br i1 %t53, label %bb25, label %bb26
bb25:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t55 = load ptr, ptr %l1, !tbaa !29
  %t56 = load i32, ptr %l2, !tbaa !23
  %t60 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2ebranchesCopy(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %t54, ptr %t55, i32 %t56)
  store i1 %t60, ptr %l47
  br label %bb27
bb26:
  br label %bb28
bb27:
  %t61 = load i1, ptr %l47, !tbaa !21
  store i1 %t61, ptr %rv
  br label %ret
bb28:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t63 = load ptr, ptr %l1, !tbaa !29
  %t64 = load i32, ptr %l2, !tbaa !23
  %t68 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2ecopiesArray(ptr %v0, ptr %v1, ptr %v2, ptr %t62, ptr %t63, i32 %t64)
  store i1 %t68, ptr %l51
  br label %bb29
bb29:
  %t69 = load i1, ptr %l51, !tbaa !21
  %t70 = xor i1 %t69, true
  br i1 %t70, label %bb30, label %bb31
bb30:
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t73 = load i32, ptr %l2, !tbaa !23
  %t76 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eretOwns(ptr %v0, ptr %v2, ptr %v3, ptr %t72, i32 %t73)
  store i1 %t76, ptr %l56
  br label %bb32
bb31:
  store i1 false, ptr %l53, !tbaa !21
  br label %bb37
bb32:
  %t77 = load i1, ptr %l56, !tbaa !21
  br i1 %t77, label %bb33, label %bb34
bb33:
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t79 = load ptr, ptr %l1, !tbaa !29
  %t82 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2ecopiesValue(ptr %v0, ptr %v1, ptr %v2, ptr %t78, ptr %t79)
  store i1 %t82, ptr %l60
  br label %bb35
bb34:
  store i1 false, ptr %l57, !tbaa !21
  br label %bb36
bb35:
  %t83 = load i1, ptr %l60, !tbaa !21
  store i1 %t83, ptr %l57, !tbaa !21
  br label %bb36
bb36:
  %t84 = load i1, ptr %l57, !tbaa !21
  %t85 = xor i1 %t84, true
  store i1 %t85, ptr %l53, !tbaa !21
  br label %bb37
bb37:
  %t87 = load i1, ptr %l53, !tbaa !21
  br i1 %t87, label %bb38, label %bb39
bb38:
  store i1 false, ptr %rv
  br label %ret
bb39:
  br label %bb40
bb40:
  %t89 = load ptr, ptr %l1, !tbaa !29
  %t91 = call i1 @compiler_2ftyped_2eFreshTemp(ptr %v1, ptr %t89)
  store i1 %t91, ptr %l64
  br label %bb41
bb41:
  %t92 = load i1, ptr %l64, !tbaa !21
  br i1 %t92, label %bb42, label %bb43
bb42:
  store i1 false, ptr %rv
  br label %ret
bb43:
  br label %bb44
bb44:
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t96 = getelementptr %"compiler/lower:lowering", ptr %t94, i32 0, i32 29
  %t97 = load i1, ptr %t96, !tbaa !21
  %t99 = xor i1 %t97, true
  br i1 %t99, label %bb45, label %bb46
bb45:
  store i1 true, ptr %rv
  br label %ret
bb46:
  br label %bb47
bb47:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = getelementptr %"compiler/lower:lowering", ptr %t102, i32 0, i32 18
  %t106 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlock_26_3e_2eLen_3ccompiler_2ftyped_3aBlock_26_3e(ptr %v0, ptr %t104)
  store i64 %t106, ptr %l72
  br label %bb48
bb48:
  %t107 = load i64, ptr %l72, !tbaa !24
  %t108 = icmp sgt i64 %t107, 0
  br i1 %t108, label %bb49, label %bb50
bb49:
  store i1 true, ptr %rv
  br label %ret
bb50:
  br label %bb51
bb51:
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t113 = getelementptr %"compiler/lower:lowering", ptr %t111, i32 0, i32 14
  store ptr %t113, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb52
bb52:
  %t115 = load i64, ptr %l5, !tbaa !24
  store i64 %t115, ptr %l77, !tbaa !24
  %t116 = load ptr, ptr %l4, !tbaa !29
  %t118 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3alevel_3e_2eLen_3ccompiler_2flower_3alevel_3e(ptr %v0, ptr %t116)
  store i64 %t118, ptr %l79
  br label %bb53
bb53:
  %t119 = load i64, ptr %l77, !tbaa !24
  %t120 = load i64, ptr %l79, !tbaa !24
  %t121 = icmp slt i64 %t119, %t120
  %t123 = xor i1 %t121, true
  br i1 %t123, label %bb54, label %bb55
bb54:
  br label %bb62
bb55:
  br label %bb56
bb56:
  %t125 = load ptr, ptr %l4, !tbaa !29
  %t126 = load i64, ptr %l5, !tbaa !24
  %t129 = call %"compiler/lower:level" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3alevel_3e_2eAt_3ccompiler_2flower_3alevel_3e(ptr %v0, ptr %t125, i64 %t126)
  store %"compiler/lower:level" %t129, ptr %l84
  br label %bb57
bb57:
  %t130 = load %"compiler/lower:level", ptr %l84
  store %"compiler/lower:level" %t130, ptr %l6
  %t131 = getelementptr %"compiler/lower:level", ptr %l6, i32 0, i32 2
  %t132 = load i32, ptr %t131, !range !{i32 0, i32 7}
  %t134 = trunc i64 3 to i32
  %t135 = icmp eq i32 %t132, %t134
  br i1 %t135, label %bb58, label %bb59
bb58:
  store i1 true, ptr %rv
  br label %ret
bb59:
  br label %bb60
bb60:
  br label %bb61
bb61:
  %t138 = load i64, ptr %l5, !tbaa !24
  %t141 = add i64 %t138, 1
  store i64 %t141, ptr %l5, !tbaa !24
  br label %bb52
bb62:
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t144 = load ptr, ptr %l1, !tbaa !29
  %t147 = call ptr @compiler_2flower_2ecompiler_2flower_3alowering_2eunconvert(ptr %v0, ptr %v1, ptr %v1, ptr %v2, ptr %t143, ptr %t144)
  store ptr %t147, ptr %l93
  br label %bb63
bb63:
  %t148 = load ptr, ptr %l93, !tbaa !29
  store ptr %t148, ptr %l7, !tbaa !29
  %t149 = load ptr, ptr %l7, !tbaa !29
  store ptr %t149, ptr %l94, !tbaa !29
  store i1 false, ptr %l95, !tbaa !21
  %t150 = load ptr, ptr %l94, !tbaa !29
  %t151 = icmp ne ptr %t150, null
  br i1 %t151, label %bb64, label %bb65
bb64:
  %t153 = load ptr, ptr %l94, !tbaa !29
  %t154 = load i64, ptr %t153, !range !{i64 0, i64 18}
  %t156 = icmp eq i64 %t154, 2
  store i1 %t156, ptr %l95, !tbaa !21
  br label %bb65
bb65:
  %t157 = load i1, ptr %l95, !tbaa !21
  %t158 = xor i1 %t157, true
  br i1 %t158, label %bb66, label %bb67
bb66:
  store i1 true, ptr %rv
  br label %ret
bb67:
  br label %bb68
bb68:
  %t161 = load ptr, ptr %l7, !tbaa !29
  %t163 = getelementptr { i64, [5 x i64] }, ptr %t161, i32 0, i32 1
  %t164 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t163, i32 0, i32 0
  %t165 = load %"compiler/source:Span", ptr %t164
  store %"compiler/source:Span" %t165, ptr %l8
  %t167 = load ptr, ptr %l7, !tbaa !29
  %t169 = getelementptr { i64, [5 x i64] }, ptr %t167, i32 0, i32 1
  %t170 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t169, i32 0, i32 1
  %t171 = load i32, ptr %t170
  store i32 %t171, ptr %l9, !tbaa !23
  %t173 = load ptr, ptr %l7, !tbaa !29
  %t175 = getelementptr { i64, [5 x i64] }, ptr %t173, i32 0, i32 1
  %t176 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t175, i32 0, i32 2
  %t177 = load ptr, ptr %t176
  %t179 = load ptr, ptr %l7, !tbaa !29
  %t181 = getelementptr { i64, [5 x i64] }, ptr %t179, i32 0, i32 1
  %t182 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t181, i32 0, i32 3
  %t183 = load i32, ptr %t182
  store i32 %t183, ptr %l11, !tbaa !23
  store ptr %t177, ptr %l12, !tbaa !29
  %t187 = load ptr, ptr %l12, !tbaa !29
  store ptr %t187, ptr %l109, !tbaa !29
  store i1 false, ptr %l110, !tbaa !21
  %t188 = load ptr, ptr %l109, !tbaa !29
  %t189 = icmp ne ptr %t188, null
  br i1 %t189, label %bb69, label %bb70
bb69:
  %t191 = load ptr, ptr %l109, !tbaa !29
  %t192 = load i64, ptr %t191, !range !{i64 0, i64 8}
  %t194 = icmp eq i64 %t192, 0
  store i1 %t194, ptr %l110, !tbaa !21
  br label %bb70
bb70:
  %t195 = load i1, ptr %l110, !tbaa !21
  %t196 = xor i1 %t195, true
  br i1 %t196, label %bb71, label %bb72
bb71:
  store i1 true, ptr %rv
  br label %ret
bb72:
  br label %bb73
bb73:
  %t199 = load ptr, ptr %l12, !tbaa !29
  %t201 = getelementptr { i64, [4 x i64] }, ptr %t199, i32 0, i32 1
  %t202 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t201, i32 0, i32 0
  %t203 = load %"compiler/source:Span", ptr %t202
  store %"compiler/source:Span" %t203, ptr %l13
  %t205 = load ptr, ptr %l12, !tbaa !29
  %t207 = getelementptr { i64, [4 x i64] }, ptr %t205, i32 0, i32 1
  %t208 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t207, i32 0, i32 1
  %t209 = load i32, ptr %t208
  store i32 %t209, ptr %l14, !tbaa !23
  %t211 = load ptr, ptr %l12, !tbaa !29
  %t213 = getelementptr { i64, [4 x i64] }, ptr %t211, i32 0, i32 1
  %t214 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t213, i32 0, i32 2
  %t215 = load i32, ptr %t214
  %t219 = sext i32 %t215 to i64
  store i64 %t219, ptr %l16, !tbaa !24
  %t221 = load ptr, ptr %l0, !tbaa !29
  %t223 = getelementptr %"compiler/lower:lowering", ptr %t221, i32 0, i32 85
  %t224 = load i64, ptr %l16, !tbaa !24
  %t227 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %t223, i64 %t224)
  store i1 %t227, ptr %l126
  br label %bb74
bb74:
  %t228 = load i1, ptr %l126, !tbaa !21
  br i1 %t228, label %bb75, label %bb76
bb75:
  store i1 false, ptr %rv
  br label %ret
bb76:
  br label %bb77
bb77:
  %t230 = load ptr, ptr %l0, !tbaa !29
  %t231 = load i64, ptr %l16, !tbaa !24
  %t234 = call { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eretHome(ptr %v0, ptr %v4, ptr %t230, i64 %t231)
  store { i64, [1 x i64] } %t234, ptr %l130
  br label %bb78
bb78:
  store ptr %l130, ptr %l131, !tbaa !29
  %t235 = load ptr, ptr %l0, !tbaa !29
  %t237 = call { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eresultScope(ptr %v0, ptr %v4, ptr %t235)
  store { i64, [1 x i64] } %t237, ptr %l133
  br label %bb79
bb79:
  %t238 = load ptr, ptr %l131, !tbaa !29
  %t240 = call i1 @olang_2emir_2eHelperKind_2eEqual_2ecompiler_2fmir_3aScopeRef(ptr %t238, ptr %l133)
  store i1 %t240, ptr %l135
  br label %bb80
bb80:
  %t241 = load i1, ptr %l135, !tbaa !21
  %t242 = xor i1 %t241, true
  br i1 %t242, label %bb81, label %bb82
bb81:
  store i1 true, ptr %l137, !tbaa !21
  br label %bb87
bb82:
  %t244 = load ptr, ptr %l0, !tbaa !29
  %t245 = load i32, ptr %l2, !tbaa !23
  %t248 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2evalueArray(ptr %v0, ptr %v2, ptr %t244, i32 %t245)
  store i1 %t248, ptr %l140
  br label %bb83
bb83:
  %t249 = load i1, ptr %l140, !tbaa !21
  br i1 %t249, label %bb84, label %bb85
bb84:
  %t250 = load ptr, ptr %l0, !tbaa !29
  %t252 = getelementptr %"compiler/lower:lowering", ptr %t250, i32 0, i32 38
  %t253 = load ptr, ptr %t252, !tbaa !29
  %t255 = getelementptr %"compiler/typed:Plan", ptr %t253, i32 0, i32 3
  %t256 = load { i64, ptr }, ptr %t255, !tbaa !27
  store { i64, ptr } %t256, ptr %l144, !tbaa !27
  %t257 = load i64, ptr %l16, !tbaa !24
  %t259 = getelementptr { i64, ptr }, ptr %l144, i32 0, i32 1
  %t260 = load ptr, ptr %t259, !tbaa !27
  %t261 = getelementptr i1, ptr %t260, i64 %t257
  %t262 = load i1, ptr %t261, !tbaa !31
  %t264 = xor i1 %t262, true
  store i1 %t264, ptr %l141, !tbaa !21
  br label %bb86
bb85:
  store i1 false, ptr %l141, !tbaa !21
  br label %bb86
bb86:
  %t266 = load i1, ptr %l141, !tbaa !21
  store i1 %t266, ptr %l137, !tbaa !21
  br label %bb87
bb87:
  %t267 = load i1, ptr %l137, !tbaa !21
  store i1 %t267, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eretFrame(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca %"compiler/typed:Local"
  %l6 = alloca ptr
  %l9 = alloca %"compiler/typed:Local"
  %l13 = alloca i1
  %l15 = alloca ptr
  %l18 = alloca i1
  %l19 = alloca i1
  %l21 = alloca ptr
  %l24 = alloca i1
  %l25 = alloca i1
  %l28 = alloca i32
  %l31 = alloca i1
  %l34 = alloca i1
  %l38 = alloca ptr
  %l40 = alloca ptr
  %l45 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/typed:Body", ptr %t4, i32 0, i32 7
  store ptr %t6, ptr %l6, !tbaa !29
  %t7 = load i64, ptr %l2, !tbaa !24
  %t8 = load ptr, ptr %l6, !tbaa !29
  %t9 = call ptr @__olang_scope_or(ptr %v2, ptr %t8)
  %t10 = call ptr @__olang_scope_hold(ptr %t9)
  %t11 = ptrtoint ptr %t10 to i64
  %t13 = inttoptr i64 %t11 to ptr
  %t14 = load ptr, ptr %l6, !tbaa !29
  %t16 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %t13, ptr %t14, i64 %t7)
  store %"compiler/typed:Local" %t16, ptr %l9
  br label %bb1
bb1:
  %t17 = load %"compiler/typed:Local", ptr %l9
  store %"compiler/typed:Local" %t17, ptr %l3
  %t18 = getelementptr %"compiler/typed:Local", ptr %l3, i32 0, i32 4
  %t19 = load i32, ptr %t18, !range !{i32 0, i32 7}
  %t21 = trunc i64 1 to i32
  %t22 = icmp eq i32 %t19, %t21
  %t24 = xor i1 %t22, true
  br i1 %t24, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l13, !tbaa !21
  br label %bb5
bb3:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/lower:lowering", ptr %t26, i32 0, i32 2
  %t29 = load ptr, ptr %t28, !tbaa !29
  store ptr %t29, ptr %l15, !tbaa !29
  %t30 = getelementptr %"compiler/typed:Local", ptr %l3, i32 0, i32 2
  %t31 = load i32, ptr %t30, !tbaa !23
  %t32 = load ptr, ptr %l15, !tbaa !29
  %t33 = call ptr @__olang_scope_or(ptr %v3, ptr %t32)
  %t34 = call ptr @__olang_scope_hold(ptr %t33)
  %t35 = ptrtoint ptr %t34 to i64
  %t37 = inttoptr i64 %t35 to ptr
  %t38 = load ptr, ptr %l15, !tbaa !29
  %t40 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %t37, ptr %t38, i32 %t31)
  store i1 %t40, ptr %l18
  br label %bb4
bb4:
  %t41 = load i1, ptr %l18, !tbaa !21
  store i1 %t41, ptr %l13, !tbaa !21
  br label %bb5
bb5:
  %t42 = load i1, ptr %l13, !tbaa !21
  br i1 %t42, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l19, !tbaa !21
  br label %bb9
bb7:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/lower:lowering", ptr %t43, i32 0, i32 2
  %t46 = load ptr, ptr %t45, !tbaa !29
  store ptr %t46, ptr %l21, !tbaa !29
  %t47 = getelementptr %"compiler/typed:Local", ptr %l3, i32 0, i32 2
  %t48 = load i32, ptr %t47, !tbaa !23
  %t49 = load ptr, ptr %l21, !tbaa !29
  %t50 = call ptr @__olang_scope_or(ptr %v3, ptr %t49)
  %t51 = call ptr @__olang_scope_hold(ptr %t50)
  %t52 = ptrtoint ptr %t51 to i64
  %t54 = inttoptr i64 %t52 to ptr
  %t55 = load ptr, ptr %l21, !tbaa !29
  %t57 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNeedsDrop(ptr %t54, ptr %t55, i32 %t48)
  store i1 %t57, ptr %l24
  br label %bb8
bb8:
  %t58 = load i1, ptr %l24, !tbaa !21
  store i1 %t58, ptr %l19, !tbaa !21
  br label %bb9
bb9:
  %t59 = load i1, ptr %l19, !tbaa !21
  br i1 %t59, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l25, !tbaa !21
  br label %bb17
bb11:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/typed:Local", ptr %l3, i32 0, i32 2
  %t62 = load i32, ptr %t61, !tbaa !23
  %t65 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2earrayOf(ptr %v0, ptr %v3, ptr %t60, i32 %t62)
  store i32 %t65, ptr %l28
  br label %bb12
bb12:
  %t66 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t67 = load i32, ptr %l28, !tbaa !23
  %t69 = icmp ne i32 %t67, %t66
  br i1 %t69, label %bb13, label %bb14
bb13:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/typed:Local", ptr %l3, i32 0, i32 2
  %t73 = load i32, ptr %t72, !tbaa !23
  %t76 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2erunArrayLocal(ptr %v0, ptr %v3, ptr %t71, i32 %t73)
  store i1 %t76, ptr %l34
  br label %bb15
bb14:
  store i1 false, ptr %l31, !tbaa !21
  br label %bb16
bb15:
  %t77 = load i1, ptr %l34, !tbaa !21
  %t78 = xor i1 %t77, true
  store i1 %t78, ptr %l31, !tbaa !21
  br label %bb16
bb16:
  %t80 = load i1, ptr %l31, !tbaa !21
  store i1 %t80, ptr %l25, !tbaa !21
  br label %bb17
bb17:
  %t81 = load i1, ptr %l25, !tbaa !21
  br i1 %t81, label %bb18, label %bb19
bb18:
  store i1 false, ptr %rv
  br label %ret
bb19:
  br label %bb20
bb20:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr %"compiler/lower:lowering", ptr %t83, i32 0, i32 0
  %t86 = load ptr, ptr %t85, !tbaa !29
  store ptr %t86, ptr %l38, !tbaa !29
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr %"compiler/lower:lowering", ptr %t87, i32 0, i32 1
  %t90 = load ptr, ptr %t89, !tbaa !29
  store ptr %t90, ptr %l40, !tbaa !29
  %t92 = load i64, ptr %l2, !tbaa !24
  %t93 = load ptr, ptr %l38, !tbaa !29
  %t94 = call ptr @__olang_scope_or(ptr %v4, ptr %t93)
  %t95 = call ptr @__olang_scope_hold(ptr %t94)
  %t96 = ptrtoint ptr %t95 to i64
  %t97 = load ptr, ptr %l40, !tbaa !29
  %t98 = call ptr @__olang_scope_or(ptr %v2, ptr %t97)
  %t99 = call ptr @__olang_scope_hold(ptr %t98)
  %t100 = ptrtoint ptr %t99 to i64
  %t102 = inttoptr i64 %t96 to ptr
  %t104 = inttoptr i64 %t100 to ptr
  %t105 = load ptr, ptr %l38, !tbaa !29
  %t106 = load ptr, ptr %l40, !tbaa !29
  %t109 = call i1 @compiler_2flower_2ecompiler_2flower_3aLowerer_2enamesKept(ptr %t102, ptr %t104, ptr %v1, ptr %t105, ptr %t106, ptr %a1, i64 %t92)
  store i1 %t109, ptr %l45
  br label %bb21
bb21:
  %t110 = load i1, ptr %l45, !tbaa !21
  %t111 = xor i1 %t110, true
  store i1 %t111, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eretHome(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l5 = alloca i1
  %l7 = alloca { i64, [1 x i64] }
  %l11 = alloca %"compiler/mir:Local"
  %rv = alloca { i64, [1 x i64] }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 16
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %t3, i64 %t4)
  store i1 %t7, ptr %l5
  br label %bb1
bb1:
  %t8 = load i1, ptr %l5, !tbaa !21
  br i1 %t8, label %bb2, label %bb3
bb2:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = call { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eresultScope(ptr %v0, ptr %v1, ptr %t9)
  store { i64, [1 x i64] } %t11, ptr %l7
  br label %bb4
bb3:
  br label %bb5
bb4:
  %t12 = load { i64, [1 x i64] }, ptr %l7
  store { i64, [1 x i64] } %t12, ptr %rv
  br label %ret
bb5:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/lower:lowering", ptr %t13, i32 0, i32 3
  %t16 = getelementptr %"compiler/mir:Fn", ptr %t15, i32 0, i32 7
  %t17 = load i64, ptr %l1, !tbaa !24
  %t20 = call %"compiler/mir:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eAt_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %t16, i64 %t17)
  store %"compiler/mir:Local" %t20, ptr %l11
  br label %bb6
bb6:
  %t21 = getelementptr %"compiler/mir:Local", ptr %l11, i32 0, i32 4
  %t22 = load { i64, [1 x i64] }, ptr %t21
  store { i64, [1 x i64] } %t22, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [1 x i64] }, ptr %rv
  ret { i64, [1 x i64] } %rr
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eretOwns(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l4 = alloca i1
  %l6 = alloca i1
  %l8 = alloca ptr
  %l11 = alloca i1
  %l13 = alloca i1
  %l15 = alloca ptr
  %l18 = alloca i1
  %l19 = alloca i1
  %l21 = alloca ptr
  %l26 = alloca i64
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2evalueArray(ptr %v0, ptr %v1, ptr %t1, i32 %t2)
  store i1 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i1, ptr %l4, !tbaa !21
  %t7 = xor i1 %t6, true
  br i1 %t7, label %bb2, label %bb3
bb2:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/lower:lowering", ptr %t9, i32 0, i32 2
  %t12 = load ptr, ptr %t11, !tbaa !29
  store ptr %t12, ptr %l8, !tbaa !29
  %t13 = load i32, ptr %l1, !tbaa !23
  %t14 = load ptr, ptr %l8, !tbaa !29
  %t15 = call ptr @__olang_scope_or(ptr %v1, ptr %t14)
  %t16 = call ptr @__olang_scope_hold(ptr %t15)
  %t17 = ptrtoint ptr %t16 to i64
  %t19 = inttoptr i64 %t17 to ptr
  %t20 = load ptr, ptr %l8, !tbaa !29
  %t22 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %t19, ptr %t20, i32 %t13)
  store i1 %t22, ptr %l11
  br label %bb4
bb3:
  store i1 false, ptr %l6, !tbaa !21
  br label %bb5
bb4:
  %t23 = load i1, ptr %l11, !tbaa !21
  %t24 = xor i1 %t23, true
  store i1 %t24, ptr %l6, !tbaa !21
  br label %bb5
bb5:
  %t26 = load i1, ptr %l6, !tbaa !21
  br i1 %t26, label %bb6, label %bb7
bb6:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/lower:lowering", ptr %t27, i32 0, i32 2
  %t30 = load ptr, ptr %t29, !tbaa !29
  store ptr %t30, ptr %l15, !tbaa !29
  %t31 = load i32, ptr %l1, !tbaa !23
  %t32 = load ptr, ptr %l15, !tbaa !29
  %t33 = call ptr @__olang_scope_or(ptr %v1, ptr %t32)
  %t34 = call ptr @__olang_scope_hold(ptr %t33)
  %t35 = ptrtoint ptr %t34 to i64
  %t37 = inttoptr i64 %t35 to ptr
  %t38 = load ptr, ptr %l15, !tbaa !29
  %t40 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOwnsParts(ptr %t37, ptr %t38, i32 %t31)
  store i1 %t40, ptr %l18
  br label %bb8
bb7:
  store i1 false, ptr %l13, !tbaa !21
  br label %bb9
bb8:
  %t41 = load i1, ptr %l18, !tbaa !21
  store i1 %t41, ptr %l13, !tbaa !21
  br label %bb9
bb9:
  %t42 = load i1, ptr %l13, !tbaa !21
  br i1 %t42, label %bb10, label %bb11
bb10:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/lower:lowering", ptr %t43, i32 0, i32 0
  %t46 = load ptr, ptr %t45, !tbaa !29
  store ptr %t46, ptr %l21, !tbaa !29
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/lower:lowering", ptr %t47, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !29
  %t52 = getelementptr %"compiler/typed:Body", ptr %t50, i32 0, i32 0
  %t53 = load i32, ptr %t52, !tbaa !23
  %t54 = load ptr, ptr %l21, !tbaa !29
  %t55 = call ptr @__olang_scope_or(ptr %v2, ptr %t54)
  %t56 = call ptr @__olang_scope_hold(ptr %t55)
  %t57 = ptrtoint ptr %t56 to i64
  %t59 = inttoptr i64 %t57 to ptr
  %t60 = load ptr, ptr %l21, !tbaa !29
  %t62 = call i64 @compiler_2flower_2ecompiler_2flower_3aLowerer_2eViewsOf(ptr %t59, ptr %t60, i32 %t53)
  store i64 %t62, ptr %l26
  br label %bb12
bb11:
  store i1 false, ptr %l19, !tbaa !21
  br label %bb13
bb12:
  %t63 = load i64, ptr %l26, !tbaa !24
  %t64 = icmp sle i64 %t63, 0
  store i1 %t64, ptr %l19, !tbaa !21
  br label %bb13
bb13:
  %t66 = load i1, ptr %l19, !tbaa !21
  store i1 %t66, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3alowering_2escalar(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l4 = alloca ptr
  %l7 = alloca i32
  %l11 = alloca i1
  %l13 = alloca ptr
  %l16 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t6 = load ptr, ptr %l4, !tbaa !29
  %t7 = call ptr @__olang_scope_or(ptr %v1, ptr %t6)
  %t8 = call ptr @__olang_scope_hold(ptr %t7)
  %t9 = ptrtoint ptr %t8 to i64
  %t11 = inttoptr i64 %t9 to ptr
  %t12 = load ptr, ptr %l4, !tbaa !29
  %t14 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %t11, ptr %t12, i32 %a1)
  store i32 %t14, ptr %l7
  br label %bb1
bb1:
  %t15 = load i32, ptr %l7, !tbaa !23
  store i32 %t15, ptr %l2, !tbaa !23
  %t16 = load i32, ptr %l2, !tbaa !23
  %t17 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t20 = icmp eq i32 %t16, %t17
  br i1 %t20, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l11, !tbaa !21
  br label %bb5
bb3:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/lower:lowering", ptr %t22, i32 0, i32 2
  %t25 = load ptr, ptr %t24, !tbaa !29
  store ptr %t25, ptr %l13, !tbaa !29
  %t26 = load i32, ptr %l2, !tbaa !23
  %t27 = load ptr, ptr %l13, !tbaa !29
  %t28 = call ptr @__olang_scope_or(ptr %v1, ptr %t27)
  %t29 = call ptr @__olang_scope_hold(ptr %t28)
  %t30 = ptrtoint ptr %t29 to i64
  %t32 = inttoptr i64 %t30 to ptr
  %t33 = load ptr, ptr %l13, !tbaa !29
  %t35 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNumber(ptr %t32, ptr %t33, i32 %t26)
  store i1 %t35, ptr %l16
  br label %bb4
bb4:
  %t36 = load i1, ptr %l16, !tbaa !21
  store i1 %t36, ptr %l11, !tbaa !21
  br label %bb5
bb5:
  %t37 = load i1, ptr %l11, !tbaa !21
  store i1 %t37, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2eselfHelper(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, i32 %a1, %"compiler/lower:pl" %a2, i32 %a3, { i64, ptr } %a4, %"compiler/source:Span" %a5) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i32
  %l5 = alloca %"compiler/source:Span"
  %l7 = alloca ptr
  %l9 = alloca ptr
  %l13 = alloca i32
  %l14 = alloca ptr
  %l15 = alloca %"compiler/lower:pl"
  %l17 = alloca %"compiler/lower:pl"
  %l18 = alloca %"compiler/mir:Lvalue"
  %l20 = alloca ptr
  %l24 = alloca i32
  %l27 = alloca { i64, [4 x i64] }
  %l32 = alloca { i64, ptr }
  %l36 = alloca { i64, [4 x i64] }
  %s0 = alloca %olang.scope
  %t41 = alloca { i64, [15 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a3, ptr %l3
  store %"compiler/source:Span" %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l7, !tbaa !29
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"compiler/lower:lowering", ptr %t2, i32 0, i32 2
  %t5 = load ptr, ptr %t4, !tbaa !29
  store ptr %t5, ptr %l9, !tbaa !29
  %t6 = load i32, ptr %l3, !tbaa !23
  %t7 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t8 = load ptr, ptr %l9, !tbaa !29
  %t9 = call ptr @__olang_scope_or(ptr %v3, ptr %t8)
  %t10 = call ptr @__olang_scope_hold(ptr %t9)
  %t11 = ptrtoint ptr %t10 to i64
  %t13 = inttoptr i64 %t11 to ptr
  %t14 = load ptr, ptr %l9, !tbaa !29
  %t17 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %t13, ptr %t14, i32 %t6, i64 %t7)
  store i32 %t17, ptr %l13
  br label %bb1
bb1:
  %t18 = load ptr, ptr %l0, !tbaa !29
  store ptr %t18, ptr %l14, !tbaa !29
  store %"compiler/lower:pl" %a2, ptr %l15
  %t21 = call %"compiler/lower:pl" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2flower_3apl(ptr %s0, ptr %l15)
  store %"compiler/lower:pl" %t21, ptr %l17
  br label %bb2
bb2:
  %t22 = load ptr, ptr %l14, !tbaa !29
  %t23 = load %"compiler/lower:pl", ptr %l17
  %t24 = call %"compiler/mir:Lvalue" @compiler_2flower_2ecompiler_2flower_3alowering_2emk(ptr %v0, ptr %s0, ptr %v4, ptr %t22, %"compiler/lower:pl" %t23)
  store %"compiler/mir:Lvalue" %t24, ptr %l18
  br label %bb3
bb3:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/lower:lowering", ptr %t25, i32 0, i32 2
  %t28 = load ptr, ptr %t27, !tbaa !29
  store ptr %t28, ptr %l20, !tbaa !29
  %t29 = load i32, ptr %l3, !tbaa !23
  %t30 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t31 = load ptr, ptr %l20, !tbaa !29
  %t32 = call ptr @__olang_scope_or(ptr %v3, ptr %t31)
  %t33 = call ptr @__olang_scope_hold(ptr %t32)
  %t34 = ptrtoint ptr %t33 to i64
  %t36 = inttoptr i64 %t34 to ptr
  %t37 = load ptr, ptr %l20, !tbaa !29
  %t40 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %t36, ptr %t37, i32 %t29, i64 %t30)
  store i32 %t40, ptr %l24
  br label %bb4
bb4:
  store { i64, [15 x i64] } zeroinitializer, ptr %t41
  %t42 = getelementptr { i64, [15 x i64] }, ptr %t41, i32 0, i32 0
  store i64 1, ptr %t42
  %t43 = load %"compiler/mir:Lvalue", ptr %l18
  %t44 = insertvalue { %"compiler/mir:Lvalue", i32 } undef, %"compiler/mir:Lvalue" %t43, 0
  %t45 = load i32, ptr %l24, !tbaa !23
  %t46 = insertvalue { %"compiler/mir:Lvalue", i32 } %t44, i32 %t45, 1
  %t47 = getelementptr { i64, [15 x i64] }, ptr %t41, i32 0, i32 1
  store { %"compiler/mir:Lvalue", i32 } %t46, ptr %t47
  %t48 = load { i64, [15 x i64] }, ptr %t41
  %t49 = load %"compiler/source:Span", ptr %l5
  %t50 = load ptr, ptr %l7, !tbaa !29
  %t51 = load i32, ptr %l13, !tbaa !23
  %t54 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %v3, ptr %v4, ptr %t50, i32 %t51, { i64, [15 x i64] } %t48, %"compiler/source:Span" %t49)
  store { i64, [4 x i64] } %t54, ptr %l27
  br label %bb5
bb5:
  %t55 = load { i64, [4 x i64] }, ptr %l27
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = load i32, ptr %l3, !tbaa !23
  %t60 = mul i64 1, 40
  %t61 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t60)
  %t62 = insertvalue { i64, ptr } undef, i64 1, 0
  %t63 = insertvalue { i64, ptr } %t62, ptr %t61, 1
  store { i64, ptr } %t63, ptr %l32, !tbaa !27
  %t65 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !27
  %t67 = getelementptr { i64, [4 x i64] }, ptr %t66, i64 0
  store { i64, [4 x i64] } %t55, ptr %t67
  %t69 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t70 = load %"compiler/source:Span", ptr %l5
  %t74 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t78 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ehelperCall(ptr %v0, ptr %s0, ptr %v2, ptr %v4, ptr %v3, ptr %t56, i32 %a1, i32 %t58, { i64, ptr } %t74, { i64, ptr } %a4, i32 %t69, %"compiler/source:Span" %t70)
  store { i64, [4 x i64] } %t78, ptr %l36
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eslotsOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, { i64, [1 x i64] } %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, [1 x i64] }
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca i64
  %l5 = alloca i32
  %l8 = alloca i64
  %l16 = alloca i32
  %rv = alloca { i64, [1 x i64] }
  %t27 = alloca { i64, [15 x i64] }, align 8
  %t42 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  store { i64, [1 x i64] } %a2, ptr %l2
  store %"compiler/source:Span" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i64 @compiler_2flower_2ecompiler_2flower_3alowering_2eguardOf(ptr %v0, ptr %v1, ptr %v2, ptr %t1, i64 %a1)
  store i64 %t5, ptr %l8
  br label %bb1
bb1:
  %t6 = load i64, ptr %l8, !tbaa !24
  store i64 %t6, ptr %l4, !tbaa !24
  %t7 = load i64, ptr %l4, !tbaa !24
  %t8 = load i64, ptr @G_2ecompiler_2ffree_2eNotSole, !tbaa !24
  %t11 = icmp eq i64 %t7, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load { i64, [1 x i64] }, ptr %l2
  store { i64, [1 x i64] } %t13, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  %t17 = load %"compiler/source:Span", ptr %l3
  %t21 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2etemp(ptr %v0, ptr %t15, i32 %t16, %"compiler/source:Span" %t17)
  store i32 %t21, ptr %l16
  br label %bb5
bb5:
  %t22 = load i32, ptr %l16, !tbaa !23
  store i32 %t22, ptr %l5, !tbaa !23
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load i32, ptr %l5, !tbaa !23
  %t25 = load i64, ptr %l4, !tbaa !24
  %t26 = load { i64, [1 x i64] }, ptr %l2
  store { i64, [15 x i64] } zeroinitializer, ptr %t27
  %t28 = getelementptr { i64, [15 x i64] }, ptr %t27, i32 0, i32 0
  store i64 15, ptr %t28
  %t30 = insertvalue { { i64, [1 x i64] } } undef, { i64, [1 x i64] } %t26, 0
  %t31 = getelementptr { i64, [15 x i64] }, ptr %t27, i32 0, i32 1
  store { { i64, [1 x i64] } } %t30, ptr %t31
  %t32 = load { i64, [15 x i64] }, ptr %t27
  %t33 = load { i64, [1 x i64] }, ptr %l2
  %t34 = load %"compiler/source:Span", ptr %l3
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eguarded(ptr %v0, ptr %v2, ptr %v1, ptr %t23, i32 %t24, i64 %t25, { i64, [15 x i64] } %t32, { i64, [1 x i64] } %t33, %"compiler/source:Span" %t34)
  br label %bb6
bb6:
  %t41 = load i32, ptr %l5, !tbaa !23
  store { i64, [1 x i64] } zeroinitializer, ptr %t42
  %t43 = getelementptr { i64, [1 x i64] }, ptr %t42, i32 0, i32 0
  store i64 4, ptr %t43
  %t45 = insertvalue { i32 } undef, i32 %t41, 0
  %t46 = getelementptr { i64, [1 x i64] }, ptr %t42, i32 0, i32 1
  store { i32 } %t45, ptr %t46
  %t47 = load { i64, [1 x i64] }, ptr %t42
  store { i64, [1 x i64] } %t47, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [1 x i64] }, ptr %rv
  ret { i64, [1 x i64] } %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2espawnErrors(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l1 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l17 = alloca { i64, ptr }
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t7 = getelementptr %"compiler/typed:Block", ptr %t5, i32 0, i32 1
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  store { i64, ptr } %t8, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l5, !tbaa !24
  br label %bb4
bb4:
  %t14 = load i64, ptr %l4, !tbaa !24
  %t15 = load i64, ptr %l5, !tbaa !24
  %t18 = icmp slt i64 %t14, %t15
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb5, label %bb6
bb5:
  br label %bb10
bb6:
  br label %bb7
bb7:
  %t22 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t22, ptr %l17, !tbaa !27
  %t23 = load i64, ptr %l4, !tbaa !24
  %t25 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr ptr, ptr %t26, i64 %t23
  %t28 = load ptr, ptr %t27, !tbaa !39
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estmtSpawnErrors(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %t28, ptr %a2)
  br label %bb8
bb8:
  br label %bb9
bb9:
  %t36 = load i64, ptr %l4, !tbaa !24
  %t39 = add i64 %t36, 1
  store i64 %t39, ptr %l4, !tbaa !24
  br label %bb4
bb10:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3alowering_2estableMade(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca i1
  %l7 = alloca ptr
  %l8 = alloca i1
  %l11 = alloca ptr
  %l12 = alloca i1
  %l15 = alloca ptr
  %l16 = alloca i1
  %l19 = alloca ptr
  %l20 = alloca i1
  %l23 = alloca ptr
  %l24 = alloca i1
  %l27 = alloca ptr
  %l28 = alloca i1
  %l35 = alloca i1
  %l36 = alloca ptr
  %l37 = alloca i1
  %l46 = alloca i1
  %l50 = alloca i1
  %l52 = alloca { i64, ptr }
  %l54 = alloca i1
  %l55 = alloca ptr
  %l56 = alloca i1
  %l63 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l7, !tbaa !29
  store i1 false, ptr %l8, !tbaa !21
  %t2 = load ptr, ptr %l7, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l7, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 7
  store i1 %t8, ptr %l8, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l8, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb17
bb4:
  %t10 = load ptr, ptr %l1, !tbaa !29
  store ptr %t10, ptr %l11, !tbaa !29
  store i1 false, ptr %l12, !tbaa !21
  %t11 = load ptr, ptr %l11, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb5, label %bb6
bb5:
  %t14 = load ptr, ptr %l11, !tbaa !29
  %t15 = load i64, ptr %t14, !range !{i64 0, i64 18}
  %t17 = icmp eq i64 %t15, 8
  store i1 %t17, ptr %l12, !tbaa !21
  br label %bb6
bb6:
  %t18 = load i1, ptr %l12, !tbaa !21
  br i1 %t18, label %bb7, label %bb8
bb7:
  br label %bb17
bb8:
  %t19 = load ptr, ptr %l1, !tbaa !29
  store ptr %t19, ptr %l15, !tbaa !29
  store i1 false, ptr %l16, !tbaa !21
  %t20 = load ptr, ptr %l15, !tbaa !29
  %t21 = icmp ne ptr %t20, null
  br i1 %t21, label %bb9, label %bb10
bb9:
  %t23 = load ptr, ptr %l15, !tbaa !29
  %t24 = load i64, ptr %t23, !range !{i64 0, i64 18}
  %t26 = icmp eq i64 %t24, 16
  store i1 %t26, ptr %l16, !tbaa !21
  br label %bb10
bb10:
  %t27 = load i1, ptr %l16, !tbaa !21
  br i1 %t27, label %bb11, label %bb12
bb11:
  br label %bb17
bb12:
  %t28 = load ptr, ptr %l1, !tbaa !29
  store ptr %t28, ptr %l19, !tbaa !29
  store i1 false, ptr %l20, !tbaa !21
  %t29 = load ptr, ptr %l19, !tbaa !29
  %t30 = icmp ne ptr %t29, null
  br i1 %t30, label %bb13, label %bb14
bb13:
  %t32 = load ptr, ptr %l19, !tbaa !29
  %t33 = load i64, ptr %t32, !range !{i64 0, i64 18}
  %t35 = icmp eq i64 %t33, 0
  store i1 %t35, ptr %l20, !tbaa !21
  br label %bb14
bb14:
  %t36 = load i1, ptr %l20, !tbaa !21
  br i1 %t36, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb18
bb17:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb56
bb18:
  %t37 = load ptr, ptr %l1, !tbaa !29
  store ptr %t37, ptr %l23, !tbaa !29
  store i1 false, ptr %l24, !tbaa !21
  %t38 = load ptr, ptr %l23, !tbaa !29
  %t39 = icmp ne ptr %t38, null
  br i1 %t39, label %bb19, label %bb20
bb19:
  %t41 = load ptr, ptr %l23, !tbaa !29
  %t42 = load i64, ptr %t41, !range !{i64 0, i64 18}
  %t44 = icmp eq i64 %t42, 6
  store i1 %t44, ptr %l24, !tbaa !21
  br label %bb20
bb20:
  %t45 = load i1, ptr %l24, !tbaa !21
  br i1 %t45, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb56
bb24:
  %t46 = load ptr, ptr %l1, !tbaa !29
  store ptr %t46, ptr %l27, !tbaa !29
  store i1 false, ptr %l28, !tbaa !21
  %t47 = load ptr, ptr %l27, !tbaa !29
  %t48 = icmp ne ptr %t47, null
  br i1 %t48, label %bb25, label %bb26
bb25:
  %t50 = load ptr, ptr %l27, !tbaa !29
  %t51 = load i64, ptr %t50, !range !{i64 0, i64 18}
  %t53 = icmp eq i64 %t51, 2
  store i1 %t53, ptr %l28, !tbaa !21
  br label %bb26
bb26:
  %t54 = load i1, ptr %l28, !tbaa !21
  br i1 %t54, label %bb27, label %bb28
bb27:
  %t55 = load ptr, ptr %l1, !tbaa !29
  %t57 = getelementptr { i64, [5 x i64] }, ptr %t55, i32 0, i32 1
  %t58 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t57, i32 0, i32 2
  %t59 = load ptr, ptr %t58
  store ptr %t59, ptr %l2, !tbaa !29
  br label %bb29
bb28:
  br label %bb31
bb29:
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t62 = load ptr, ptr %l2, !tbaa !29
  %t65 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2establePlace(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t61, ptr %t62)
  store i1 %t65, ptr %l35
  br label %bb30
bb30:
  %t66 = load i1, ptr %l35, !tbaa !21
  store i1 %t66, ptr %l6, !tbaa !21
  br label %bb56
bb31:
  %t67 = load ptr, ptr %l1, !tbaa !29
  store ptr %t67, ptr %l36, !tbaa !29
  store i1 false, ptr %l37, !tbaa !21
  %t68 = load ptr, ptr %l36, !tbaa !29
  %t69 = icmp ne ptr %t68, null
  br i1 %t69, label %bb32, label %bb33
bb32:
  %t71 = load ptr, ptr %l36, !tbaa !29
  %t72 = load i64, ptr %t71, !range !{i64 0, i64 18}
  %t74 = icmp eq i64 %t72, 9
  store i1 %t74, ptr %l37, !tbaa !21
  br label %bb33
bb33:
  %t75 = load i1, ptr %l37, !tbaa !21
  br i1 %t75, label %bb34, label %bb35
bb34:
  %t76 = load ptr, ptr %l1, !tbaa !29
  %t78 = getelementptr { i64, [5 x i64] }, ptr %t76, i32 0, i32 1
  %t79 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t78, i32 0, i32 2
  %t80 = load i32, ptr %t79, !range !{i32 0, i32 54}
  store i32 %t80, ptr %l3
  %t82 = load ptr, ptr %l1, !tbaa !29
  %t84 = getelementptr { i64, [5 x i64] }, ptr %t82, i32 0, i32 1
  %t85 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t84, i32 0, i32 4
  %t86 = load { i64, ptr }, ptr %t85
  store { i64, ptr } %t86, ptr %l4, !tbaa !27
  br label %bb36
bb35:
  br label %bb44
bb36:
  %t88 = load i32, ptr %l3, !range !{i32 0, i32 54}
  %t90 = trunc i64 20 to i32
  %t91 = icmp eq i32 %t88, %t90
  br i1 %t91, label %bb37, label %bb38
bb37:
  %t93 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t95 = extractvalue { i64, ptr } %t93, 0
  %t97 = icmp eq i64 %t95, 1
  store i1 %t97, ptr %l46, !tbaa !21
  br label %bb39
bb38:
  store i1 false, ptr %l46, !tbaa !21
  br label %bb39
bb39:
  %t99 = load i1, ptr %l46, !tbaa !21
  br i1 %t99, label %bb40, label %bb41
bb40:
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t101 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t101, ptr %l52, !tbaa !27
  %t102 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t103 = load ptr, ptr %t102, !tbaa !27
  %t104 = getelementptr ptr, ptr %t103, i64 0
  %t105 = load ptr, ptr %t104, !tbaa !39
  %t108 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2estableMade(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t100, ptr %t105)
  store i1 %t108, ptr %l54
  br label %bb42
bb41:
  store i1 false, ptr %l50, !tbaa !21
  br label %bb43
bb42:
  %t109 = load i1, ptr %l54, !tbaa !21
  store i1 %t109, ptr %l50, !tbaa !21
  br label %bb43
bb43:
  %t110 = load i1, ptr %l50, !tbaa !21
  store i1 %t110, ptr %l6, !tbaa !21
  br label %bb56
bb44:
  %t111 = load ptr, ptr %l1, !tbaa !29
  store ptr %t111, ptr %l55, !tbaa !29
  store i1 false, ptr %l56, !tbaa !21
  %t112 = load ptr, ptr %l55, !tbaa !29
  %t113 = icmp ne ptr %t112, null
  br i1 %t113, label %bb45, label %bb46
bb45:
  %t115 = load ptr, ptr %l55, !tbaa !29
  %t116 = load i64, ptr %t115, !range !{i64 0, i64 18}
  %t118 = icmp eq i64 %t116, 17
  store i1 %t118, ptr %l56, !tbaa !21
  br label %bb46
bb46:
  %t119 = load i1, ptr %l56, !tbaa !21
  br i1 %t119, label %bb47, label %bb48
bb47:
  %t120 = load ptr, ptr %l1, !tbaa !29
  %t122 = getelementptr { i64, [5 x i64] }, ptr %t120, i32 0, i32 1
  %t123 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t122, i32 0, i32 2
  %t124 = load ptr, ptr %t123
  store ptr %t124, ptr %l5, !tbaa !29
  br label %bb49
bb48:
  br label %bb51
bb49:
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t127 = load ptr, ptr %l5, !tbaa !29
  %t130 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2estableMade(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t126, ptr %t127)
  store i1 %t130, ptr %l63
  br label %bb50
bb50:
  %t131 = load i1, ptr %l63, !tbaa !21
  store i1 %t131, ptr %l6, !tbaa !21
  br label %bb56
bb51:
  br i1 true, label %bb52, label %bb53
bb52:
  br label %bb54
bb53:
  br label %bb55
bb54:
  store i1 false, ptr %l6, !tbaa !21
  br label %bb56
bb55:
  call void @__olang_check_failed(ptr @olang_loc_a75b87f7fc6585db_9c37e910f1cfbc0f)
  unreachable
bb56:
  %t132 = load i1, ptr %l6, !tbaa !21
  store i1 %t132, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3alowering_2establePlace(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i1
  %l8 = alloca ptr
  %l9 = alloca i1
  %l16 = alloca i1
  %l17 = alloca ptr
  %l18 = alloca i1
  %l25 = alloca i1
  %l26 = alloca ptr
  %l27 = alloca i1
  %l35 = alloca i1
  %l36 = alloca ptr
  %l37 = alloca i1
  %l45 = alloca i1
  %l46 = alloca ptr
  %l47 = alloca i1
  %l54 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t2 = load ptr, ptr %l8, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l8, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l9, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l9, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load ptr, ptr %l2, !tbaa !29
  %t20 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2estableRef(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t16, ptr %t17)
  store i1 %t20, ptr %l16
  br label %bb6
bb6:
  %t21 = load i1, ptr %l16, !tbaa !21
  store i1 %t21, ptr %l7, !tbaa !21
  br label %bb40
bb7:
  %t22 = load ptr, ptr %l1, !tbaa !29
  store ptr %t22, ptr %l17, !tbaa !29
  store i1 false, ptr %l18, !tbaa !21
  %t23 = load ptr, ptr %l17, !tbaa !29
  %t24 = icmp ne ptr %t23, null
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t26 = load ptr, ptr %l17, !tbaa !29
  %t27 = load i64, ptr %t26, !range !{i64 0, i64 8}
  %t29 = icmp eq i64 %t27, 3
  store i1 %t29, ptr %l18, !tbaa !21
  br label %bb9
bb9:
  %t30 = load i1, ptr %l18, !tbaa !21
  br i1 %t30, label %bb10, label %bb11
bb10:
  %t31 = load ptr, ptr %l1, !tbaa !29
  %t33 = getelementptr { i64, [4 x i64] }, ptr %t31, i32 0, i32 1
  %t34 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t33, i32 0, i32 2
  %t35 = load ptr, ptr %t34
  store ptr %t35, ptr %l3, !tbaa !29
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load ptr, ptr %l3, !tbaa !29
  %t41 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2establePlace(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t37, ptr %t38)
  store i1 %t41, ptr %l25
  br label %bb13
bb13:
  %t42 = load i1, ptr %l25, !tbaa !21
  store i1 %t42, ptr %l7, !tbaa !21
  br label %bb40
bb14:
  %t43 = load ptr, ptr %l1, !tbaa !29
  store ptr %t43, ptr %l26, !tbaa !29
  store i1 false, ptr %l27, !tbaa !21
  %t44 = load ptr, ptr %l26, !tbaa !29
  %t45 = icmp ne ptr %t44, null
  br i1 %t45, label %bb15, label %bb16
bb15:
  %t47 = load ptr, ptr %l26, !tbaa !29
  %t48 = load i64, ptr %t47, !range !{i64 0, i64 8}
  %t50 = icmp eq i64 %t48, 4
  store i1 %t50, ptr %l27, !tbaa !21
  br label %bb16
bb16:
  %t51 = load i1, ptr %l27, !tbaa !21
  br i1 %t51, label %bb17, label %bb18
bb17:
  %t52 = load ptr, ptr %l1, !tbaa !29
  %t54 = getelementptr { i64, [4 x i64] }, ptr %t52, i32 0, i32 1
  %t55 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t54, i32 0, i32 2
  %t56 = load ptr, ptr %t55
  store ptr %t56, ptr %l4, !tbaa !29
  br label %bb19
bb18:
  br label %bb21
bb19:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = load ptr, ptr %l4, !tbaa !29
  %t61 = getelementptr %"compiler/typed:Elem", ptr %t59, i32 0, i32 0
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t65 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2establePlace(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t58, ptr %t62)
  store i1 %t65, ptr %l35
  br label %bb20
bb20:
  %t66 = load i1, ptr %l35, !tbaa !21
  store i1 %t66, ptr %l7, !tbaa !21
  br label %bb40
bb21:
  %t67 = load ptr, ptr %l1, !tbaa !29
  store ptr %t67, ptr %l36, !tbaa !29
  store i1 false, ptr %l37, !tbaa !21
  %t68 = load ptr, ptr %l36, !tbaa !29
  %t69 = icmp ne ptr %t68, null
  br i1 %t69, label %bb22, label %bb23
bb22:
  %t71 = load ptr, ptr %l36, !tbaa !29
  %t72 = load i64, ptr %t71, !range !{i64 0, i64 8}
  %t74 = icmp eq i64 %t72, 5
  store i1 %t74, ptr %l37, !tbaa !21
  br label %bb23
bb23:
  %t75 = load i1, ptr %l37, !tbaa !21
  br i1 %t75, label %bb24, label %bb25
bb24:
  %t76 = load ptr, ptr %l1, !tbaa !29
  %t78 = getelementptr { i64, [4 x i64] }, ptr %t76, i32 0, i32 1
  %t79 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t78, i32 0, i32 2
  %t80 = load ptr, ptr %t79
  store ptr %t80, ptr %l5, !tbaa !29
  br label %bb26
bb25:
  br label %bb28
bb26:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t83 = load ptr, ptr %l5, !tbaa !29
  %t85 = getelementptr %"compiler/typed:Payload", ptr %t83, i32 0, i32 0
  %t86 = load ptr, ptr %t85, !tbaa !29
  %t89 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2establePlace(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t82, ptr %t86)
  store i1 %t89, ptr %l45
  br label %bb27
bb27:
  %t90 = load i1, ptr %l45, !tbaa !21
  store i1 %t90, ptr %l7, !tbaa !21
  br label %bb40
bb28:
  %t91 = load ptr, ptr %l1, !tbaa !29
  store ptr %t91, ptr %l46, !tbaa !29
  store i1 false, ptr %l47, !tbaa !21
  %t92 = load ptr, ptr %l46, !tbaa !29
  %t93 = icmp ne ptr %t92, null
  br i1 %t93, label %bb29, label %bb30
bb29:
  %t95 = load ptr, ptr %l46, !tbaa !29
  %t96 = load i64, ptr %t95, !range !{i64 0, i64 8}
  %t98 = icmp eq i64 %t96, 6
  store i1 %t98, ptr %l47, !tbaa !21
  br label %bb30
bb30:
  %t99 = load i1, ptr %l47, !tbaa !21
  br i1 %t99, label %bb31, label %bb32
bb31:
  %t100 = load ptr, ptr %l1, !tbaa !29
  %t102 = getelementptr { i64, [4 x i64] }, ptr %t100, i32 0, i32 1
  %t103 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t102, i32 0, i32 2
  %t104 = load ptr, ptr %t103
  store ptr %t104, ptr %l6, !tbaa !29
  br label %bb33
bb32:
  br label %bb35
bb33:
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t107 = load ptr, ptr %l6, !tbaa !29
  %t110 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2estableMade(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t106, ptr %t107)
  store i1 %t110, ptr %l54
  br label %bb34
bb34:
  %t111 = load i1, ptr %l54, !tbaa !21
  store i1 %t111, ptr %l7, !tbaa !21
  br label %bb40
bb35:
  br i1 true, label %bb36, label %bb37
bb36:
  br label %bb38
bb37:
  br label %bb39
bb38:
  store i1 false, ptr %l7, !tbaa !21
  br label %bb40
bb39:
  call void @__olang_check_failed(ptr @olang_loc_31e744114bee3e3d_92a3ba9b31ef9be1)
  unreachable
bb40:
  %t112 = load i1, ptr %l7, !tbaa !21
  store i1 %t112, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3alowering_2estableRef(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca { i64, ptr }
  %l8 = alloca ptr
  %l11 = alloca i1
  %l13 = alloca i1
  %l14 = alloca i1
  %l17 = alloca i1
  %l19 = alloca i1
  %l20 = alloca ptr
  %l21 = alloca i1
  %l28 = alloca i1
  %l29 = alloca ptr
  %l30 = alloca i1
  %l37 = alloca i1
  %l38 = alloca ptr
  %l39 = alloca i1
  %l47 = alloca i1
  %l48 = alloca ptr
  %l49 = alloca i1
  %l52 = alloca ptr
  %l53 = alloca i1
  %l61 = alloca i1
  %l62 = alloca ptr
  %l63 = alloca i1
  %l71 = alloca i1
  %l72 = alloca i1
  %l76 = alloca i1
  %l78 = alloca { i64, ptr }
  %l80 = alloca i1
  %l81 = alloca ptr
  %l82 = alloca i1
  %l89 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 83
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l11, !tbaa !21
  br label %bb4
bb2:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2equiet(ptr %v0, ptr %v2, ptr %v3, ptr %t6)
  store i1 %t8, ptr %l13
  br label %bb3
bb3:
  %t9 = load i1, ptr %l13, !tbaa !21
  store i1 %t9, ptr %l11, !tbaa !21
  br label %bb4
bb4:
  %t10 = load i1, ptr %l11, !tbaa !21
  br i1 %t10, label %bb5, label %bb6
bb5:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load ptr, ptr %l1, !tbaa !29
  %t15 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eplaceRooted(ptr %v0, ptr %v1, ptr %t11, ptr %t12)
  store i1 %t15, ptr %l17
  br label %bb7
bb6:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb8
bb7:
  %t16 = load i1, ptr %l17, !tbaa !21
  store i1 %t16, ptr %l14, !tbaa !21
  br label %bb8
bb8:
  %t17 = load i1, ptr %l14, !tbaa !21
  br i1 %t17, label %bb9, label %bb10
bb9:
  store i1 true, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t19 = load ptr, ptr %l1, !tbaa !29
  store ptr %t19, ptr %l20, !tbaa !29
  store i1 false, ptr %l21, !tbaa !21
  %t20 = load ptr, ptr %l20, !tbaa !29
  %t21 = icmp ne ptr %t20, null
  br i1 %t21, label %bb12, label %bb13
bb12:
  %t23 = load ptr, ptr %l20, !tbaa !29
  %t24 = load i64, ptr %t23, !range !{i64 0, i64 18}
  %t26 = icmp eq i64 %t24, 2
  store i1 %t26, ptr %l21, !tbaa !21
  br label %bb13
bb13:
  %t27 = load i1, ptr %l21, !tbaa !21
  br i1 %t27, label %bb14, label %bb15
bb14:
  %t28 = load ptr, ptr %l1, !tbaa !29
  %t30 = getelementptr { i64, [5 x i64] }, ptr %t28, i32 0, i32 1
  %t31 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t30, i32 0, i32 2
  %t32 = load ptr, ptr %t31
  store ptr %t32, ptr %l2, !tbaa !29
  br label %bb16
bb15:
  br label %bb18
bb16:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = load ptr, ptr %l2, !tbaa !29
  %t38 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2estableHolder(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t34, ptr %t35)
  store i1 %t38, ptr %l28
  br label %bb17
bb17:
  %t39 = load i1, ptr %l28, !tbaa !21
  store i1 %t39, ptr %l19, !tbaa !21
  br label %bb71
bb18:
  %t40 = load ptr, ptr %l1, !tbaa !29
  store ptr %t40, ptr %l29, !tbaa !29
  store i1 false, ptr %l30, !tbaa !21
  %t41 = load ptr, ptr %l29, !tbaa !29
  %t42 = icmp ne ptr %t41, null
  br i1 %t42, label %bb19, label %bb20
bb19:
  %t44 = load ptr, ptr %l29, !tbaa !29
  %t45 = load i64, ptr %t44, !range !{i64 0, i64 18}
  %t47 = icmp eq i64 %t45, 3
  store i1 %t47, ptr %l30, !tbaa !21
  br label %bb20
bb20:
  %t48 = load i1, ptr %l30, !tbaa !21
  br i1 %t48, label %bb21, label %bb22
bb21:
  %t49 = load ptr, ptr %l1, !tbaa !29
  %t51 = getelementptr { i64, [5 x i64] }, ptr %t49, i32 0, i32 1
  %t52 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t51, i32 0, i32 2
  %t53 = load ptr, ptr %t52
  store ptr %t53, ptr %l3, !tbaa !29
  br label %bb23
bb22:
  br label %bb25
bb23:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t56 = load ptr, ptr %l3, !tbaa !29
  %t59 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2establePlace(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t55, ptr %t56)
  store i1 %t59, ptr %l37
  br label %bb24
bb24:
  %t60 = load i1, ptr %l37, !tbaa !21
  store i1 %t60, ptr %l19, !tbaa !21
  br label %bb71
bb25:
  %t61 = load ptr, ptr %l1, !tbaa !29
  store ptr %t61, ptr %l38, !tbaa !29
  store i1 false, ptr %l39, !tbaa !21
  %t62 = load ptr, ptr %l38, !tbaa !29
  %t63 = icmp ne ptr %t62, null
  br i1 %t63, label %bb26, label %bb27
bb26:
  %t65 = load ptr, ptr %l38, !tbaa !29
  %t66 = load i64, ptr %t65, !range !{i64 0, i64 18}
  %t68 = icmp eq i64 %t66, 10
  store i1 %t68, ptr %l39, !tbaa !21
  br label %bb27
bb27:
  %t69 = load i1, ptr %l39, !tbaa !21
  br i1 %t69, label %bb28, label %bb29
bb28:
  %t70 = load ptr, ptr %l1, !tbaa !29
  %t72 = getelementptr { i64, [5 x i64] }, ptr %t70, i32 0, i32 1
  %t73 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t72, i32 0, i32 2
  %t74 = load ptr, ptr %t73
  store ptr %t74, ptr %l4, !tbaa !29
  br label %bb30
bb29:
  br label %bb32
bb30:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t77 = load ptr, ptr %l4, !tbaa !29
  %t79 = getelementptr %"compiler/typed:Slice", ptr %t77, i32 0, i32 0
  %t80 = load ptr, ptr %t79, !tbaa !29
  %t83 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2establePlace(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t76, ptr %t80)
  store i1 %t83, ptr %l47
  br label %bb31
bb31:
  %t84 = load i1, ptr %l47, !tbaa !21
  store i1 %t84, ptr %l19, !tbaa !21
  br label %bb71
bb32:
  %t85 = load ptr, ptr %l1, !tbaa !29
  store ptr %t85, ptr %l48, !tbaa !29
  store i1 false, ptr %l49, !tbaa !21
  %t86 = load ptr, ptr %l48, !tbaa !29
  %t87 = icmp ne ptr %t86, null
  br i1 %t87, label %bb33, label %bb34
bb33:
  %t89 = load ptr, ptr %l48, !tbaa !29
  %t90 = load i64, ptr %t89, !range !{i64 0, i64 18}
  %t92 = icmp eq i64 %t90, 1
  store i1 %t92, ptr %l49, !tbaa !21
  br label %bb34
bb34:
  %t93 = load i1, ptr %l49, !tbaa !21
  br i1 %t93, label %bb35, label %bb36
bb35:
  br label %bb37
bb36:
  br label %bb38
bb37:
  store i1 true, ptr %l19, !tbaa !21
  br label %bb71
bb38:
  %t94 = load ptr, ptr %l1, !tbaa !29
  store ptr %t94, ptr %l52, !tbaa !29
  store i1 false, ptr %l53, !tbaa !21
  %t95 = load ptr, ptr %l52, !tbaa !29
  %t96 = icmp ne ptr %t95, null
  br i1 %t96, label %bb39, label %bb40
bb39:
  %t98 = load ptr, ptr %l52, !tbaa !29
  %t99 = load i64, ptr %t98, !range !{i64 0, i64 18}
  %t101 = icmp eq i64 %t99, 5
  store i1 %t101, ptr %l53, !tbaa !21
  br label %bb40
bb40:
  %t102 = load i1, ptr %l53, !tbaa !21
  br i1 %t102, label %bb41, label %bb42
bb41:
  %t103 = load ptr, ptr %l1, !tbaa !29
  %t105 = getelementptr { i64, [5 x i64] }, ptr %t103, i32 0, i32 1
  %t106 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t105, i32 0, i32 2
  %t107 = load ptr, ptr %t106
  store ptr %t107, ptr %l5, !tbaa !29
  br label %bb43
bb42:
  br label %bb45
bb43:
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t110 = load ptr, ptr %l5, !tbaa !29
  %t112 = getelementptr %"compiler/typed:Promote", ptr %t110, i32 0, i32 0
  %t113 = load ptr, ptr %t112, !tbaa !29
  %t116 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2estableMade(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t109, ptr %t113)
  store i1 %t116, ptr %l61
  br label %bb44
bb44:
  %t117 = load i1, ptr %l61, !tbaa !21
  store i1 %t117, ptr %l19, !tbaa !21
  br label %bb71
bb45:
  %t118 = load ptr, ptr %l1, !tbaa !29
  store ptr %t118, ptr %l62, !tbaa !29
  store i1 false, ptr %l63, !tbaa !21
  %t119 = load ptr, ptr %l62, !tbaa !29
  %t120 = icmp ne ptr %t119, null
  br i1 %t120, label %bb46, label %bb47
bb46:
  %t122 = load ptr, ptr %l62, !tbaa !29
  %t123 = load i64, ptr %t122, !range !{i64 0, i64 18}
  %t125 = icmp eq i64 %t123, 9
  store i1 %t125, ptr %l63, !tbaa !21
  br label %bb47
bb47:
  %t126 = load i1, ptr %l63, !tbaa !21
  br i1 %t126, label %bb48, label %bb49
bb48:
  %t127 = load ptr, ptr %l1, !tbaa !29
  %t129 = getelementptr { i64, [5 x i64] }, ptr %t127, i32 0, i32 1
  %t130 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t129, i32 0, i32 2
  %t131 = load i32, ptr %t130, !range !{i32 0, i32 54}
  store i32 %t131, ptr %l6
  %t133 = load ptr, ptr %l1, !tbaa !29
  %t135 = getelementptr { i64, [5 x i64] }, ptr %t133, i32 0, i32 1
  %t136 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t135, i32 0, i32 4
  %t137 = load { i64, ptr }, ptr %t136
  store { i64, ptr } %t137, ptr %l7, !tbaa !27
  br label %bb50
bb49:
  br label %bb59
bb50:
  %t139 = load i32, ptr %l6, !range !{i32 0, i32 54}
  %t141 = call i1 @compiler_2ftyped_2ePassesRefs(i32 %t139)
  store i1 %t141, ptr %l71
  br label %bb51
bb51:
  %t142 = load i1, ptr %l71, !tbaa !21
  br i1 %t142, label %bb52, label %bb53
bb52:
  %t143 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t145 = extractvalue { i64, ptr } %t143, 0
  %t147 = icmp sgt i64 %t145, 0
  store i1 %t147, ptr %l72, !tbaa !21
  br label %bb54
bb53:
  store i1 false, ptr %l72, !tbaa !21
  br label %bb54
bb54:
  %t149 = load i1, ptr %l72, !tbaa !21
  br i1 %t149, label %bb55, label %bb56
bb55:
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t151 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t151, ptr %l78, !tbaa !27
  %t152 = getelementptr { i64, ptr }, ptr %l78, i32 0, i32 1
  %t153 = load ptr, ptr %t152, !tbaa !27
  %t154 = getelementptr ptr, ptr %t153, i64 0
  %t155 = load ptr, ptr %t154, !tbaa !39
  %t158 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2estableRef(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t150, ptr %t155)
  store i1 %t158, ptr %l80
  br label %bb57
bb56:
  store i1 false, ptr %l76, !tbaa !21
  br label %bb58
bb57:
  %t159 = load i1, ptr %l80, !tbaa !21
  store i1 %t159, ptr %l76, !tbaa !21
  br label %bb58
bb58:
  %t160 = load i1, ptr %l76, !tbaa !21
  store i1 %t160, ptr %l19, !tbaa !21
  br label %bb71
bb59:
  %t161 = load ptr, ptr %l1, !tbaa !29
  store ptr %t161, ptr %l81, !tbaa !29
  store i1 false, ptr %l82, !tbaa !21
  %t162 = load ptr, ptr %l81, !tbaa !29
  %t163 = icmp ne ptr %t162, null
  br i1 %t163, label %bb60, label %bb61
bb60:
  %t165 = load ptr, ptr %l81, !tbaa !29
  %t166 = load i64, ptr %t165, !range !{i64 0, i64 18}
  %t168 = icmp eq i64 %t166, 17
  store i1 %t168, ptr %l82, !tbaa !21
  br label %bb61
bb61:
  %t169 = load i1, ptr %l82, !tbaa !21
  br i1 %t169, label %bb62, label %bb63
bb62:
  %t170 = load ptr, ptr %l1, !tbaa !29
  %t172 = getelementptr { i64, [5 x i64] }, ptr %t170, i32 0, i32 1
  %t173 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t172, i32 0, i32 2
  %t174 = load ptr, ptr %t173
  store ptr %t174, ptr %l8, !tbaa !29
  br label %bb64
bb63:
  br label %bb66
bb64:
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t177 = load ptr, ptr %l8, !tbaa !29
  %t180 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2estableRef(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t176, ptr %t177)
  store i1 %t180, ptr %l89
  br label %bb65
bb65:
  %t181 = load i1, ptr %l89, !tbaa !21
  store i1 %t181, ptr %l19, !tbaa !21
  br label %bb71
bb66:
  br i1 true, label %bb67, label %bb68
bb67:
  br label %bb69
bb68:
  br label %bb70
bb69:
  store i1 false, ptr %l19, !tbaa !21
  br label %bb71
bb70:
  call void @__olang_check_failed(ptr @olang_loc_7e6d7b9279609ab3_447c445eeb868dc7)
  unreachable
bb71:
  %t182 = load i1, ptr %l19, !tbaa !21
  store i1 %t182, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l11 = alloca ptr
  %l14 = alloca %"compiler/mir:Lvalue"
  %l18 = alloca ptr
  %l21 = alloca %"compiler/mir:Lvalue"
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 11
  store i32 %t2, ptr %t5, !tbaa !23
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/lower:lowering", ptr %t6, i32 0, i32 12
  store i1 false, ptr %t8, !tbaa !21
  %t9 = load i32, ptr %l1, !tbaa !23
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/lower:lowering", ptr %t10, i32 0, i32 4
  %t13 = load i32, ptr %t12, !tbaa !23
  %t16 = icmp ne i32 %t9, %t13
  br i1 %t16, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t19 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t22 = getelementptr %"compiler/lower:lowering", ptr %t18, i32 0, i32 4
  store i32 %t19, ptr %t22, !tbaa !23
  %t23 = load ptr, ptr %l0, !tbaa !29
  store ptr %t23, ptr %l11, !tbaa !29
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/lower:lowering", ptr %t24, i32 0, i32 5
  %t27 = load i32, ptr %t26, !tbaa !23
  %t29 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t27)
  store %"compiler/mir:Lvalue" %t29, ptr %l14
  br label %bb4
bb4:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/lower:lowering", ptr %t30, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !29
  %t35 = getelementptr %"compiler/typed:Body", ptr %t33, i32 0, i32 4
  %t36 = load %"compiler/source:Span", ptr %t35
  %t37 = load ptr, ptr %l11, !tbaa !29
  %t38 = load %"compiler/mir:Lvalue", ptr %l14
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eholders(ptr %v0, ptr %t37, %"compiler/mir:Lvalue" %t38, i64 1, %"compiler/source:Span" %t36)
  br label %bb5
bb5:
  %t40 = load ptr, ptr %l0, !tbaa !29
  store ptr %t40, ptr %l18, !tbaa !29
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/lower:lowering", ptr %t41, i32 0, i32 6
  %t44 = load i32, ptr %t43, !tbaa !23
  %t46 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t44)
  store %"compiler/mir:Lvalue" %t46, ptr %l21
  br label %bb6
bb6:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/lower:lowering", ptr %t47, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !29
  %t52 = getelementptr %"compiler/typed:Body", ptr %t50, i32 0, i32 4
  %t53 = load %"compiler/source:Span", ptr %t52
  %t54 = load ptr, ptr %l18, !tbaa !29
  %t55 = load %"compiler/mir:Lvalue", ptr %l21
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eholders(ptr %v0, ptr %t54, %"compiler/mir:Lvalue" %t55, i64 -1, %"compiler/source:Span" %t53)
  br label %bb7
bb7:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2estmt(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l11 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca i32
  %l19 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i32
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 12
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/lower:lowering", ptr %t6, i32 0, i32 80
  %t9 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2ePush_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v1, ptr %t8, ptr %t9)
  br label %bb4
bb4:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/lower:lowering", ptr %t12, i32 0, i32 81
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t14, i64 -1)
  br label %bb5
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estmtIn(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %t16, ptr %t17)
  br label %bb6
bb6:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/lower:lowering", ptr %t20, i32 0, i32 80
  %t24 = call { i32, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2ePop_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %s0, ptr %t22)
  %t25 = extractvalue { i32, ptr } %t24, 1
  %t26 = extractvalue { i32, ptr } %t24, 0
  store i32 %t26, ptr %l15
  %t27 = icmp ne i32 %t26, 0
  br i1 %t27, label %bb8, label %ok.28, !prof !99
ok.28:
  store ptr %t25, ptr %l14
  br label %bb7
bb7:
  %t29 = load ptr, ptr %l14, !tbaa !29
  store ptr %t29, ptr %l11, !tbaa !29
  br label %bb15
bb8:
  %t30 = load i32, ptr %l15, !tbaa !23
  %t31 = icmp eq i32 %t30, 65536
  br i1 %t31, label %bb9, label %bb10
bb9:
  call void @__olang_bang_failed_plain(ptr @olang_loc_a5b1a763b9bba10_ba6ba978893df9a4)
  unreachable
bb10:
  %t33 = load i32, ptr %l15, !tbaa !23
  %t34 = icmp eq i32 %t33, 65537
  br i1 %t34, label %bb11, label %bb12
bb11:
  call void @__olang_bang_failed_plain(ptr @olang_loc_eb3797cfa5f64105_1f3db8e929f64739)
  unreachable
bb12:
  %t36 = load i32, ptr %l15, !tbaa !23
  %t37 = icmp eq i32 %t36, 65538
  br i1 %t37, label %bb13, label %bb14
bb13:
  call void @__olang_bang_failed_plain(ptr @olang_loc_d2f375e5ba968b65_383d0166caeed659)
  unreachable
bb14:
  call void @__olang_bang_failed_plain(ptr @olang_loc_e527201c6aa166ab_3a4acb23654914bf)
  unreachable
bb15:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/lower:lowering", ptr %t39, i32 0, i32 81
  %t43 = call { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %t41)
  %t44 = extractvalue { i32, i64 } %t43, 1
  %t45 = extractvalue { i32, i64 } %t43, 0
  store i32 %t45, ptr %l23
  %t46 = icmp ne i32 %t45, 0
  br i1 %t46, label %bb17, label %ok.47, !prof !99
ok.47:
  store i64 %t44, ptr %l22
  br label %bb16
bb16:
  %t48 = load i64, ptr %l22, !tbaa !24
  store i64 %t48, ptr %l19, !tbaa !24
  br label %bb24
bb17:
  %t49 = load i32, ptr %l23, !tbaa !23
  %t50 = icmp eq i32 %t49, 65536
  br i1 %t50, label %bb18, label %bb19
bb18:
  call void @__olang_bang_failed_plain(ptr @olang_loc_f20c72191c5bbaec_70ba5090fad608c8)
  unreachable
bb19:
  %t52 = load i32, ptr %l23, !tbaa !23
  %t53 = icmp eq i32 %t52, 65537
  br i1 %t53, label %bb20, label %bb21
bb20:
  call void @__olang_bang_failed_plain(ptr @olang_loc_9792dafd009dd231_d222868cd9c52d2d)
  unreachable
bb21:
  %t55 = load i32, ptr %l23, !tbaa !23
  %t56 = icmp eq i32 %t55, 65538
  br i1 %t56, label %bb22, label %bb23
bb22:
  call void @__olang_bang_failed_plain(ptr @olang_loc_5cf7683923427be1_eeed011b70fc7f3d)
  unreachable
bb23:
  call void @__olang_bang_failed_plain(ptr @olang_loc_35262608d5eaeb07_a04d120ff2489083)
  unreachable
bb24:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2flower_2ecompiler_2flower_3alowering_2estorageBlock(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, [2 x i64] }
  %l10 = alloca { i64, [2 x i64] }
  %l13 = alloca { i64, ptr }
  %l23 = alloca ptr
  %l26 = alloca %"compiler/typed:Local"
  %rv = alloca i32
  %t29 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"compiler/lower:lowering", ptr %t2, i32 0, i32 38
  %t5 = load ptr, ptr %t4, !tbaa !29
  %t7 = getelementptr %"compiler/typed:Plan", ptr %t5, i32 0, i32 1
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t8, 0
  %t13 = icmp slt i64 %t1, %t10
  br i1 %t13, label %bb1, label %bb2
bb1:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/lower:lowering", ptr %t15, i32 0, i32 38
  %t18 = load ptr, ptr %t17, !tbaa !29
  %t20 = getelementptr %"compiler/typed:Plan", ptr %t18, i32 0, i32 1
  %t21 = load { i64, ptr }, ptr %t20, !tbaa !27
  store { i64, ptr } %t21, ptr %l13, !tbaa !27
  %t22 = load i64, ptr %l1, !tbaa !24
  %t24 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = getelementptr { i64, [2 x i64] }, ptr %t25, i64 %t22
  %t27 = load { i64, [2 x i64] }, ptr %t26
  store { i64, [2 x i64] } %t27, ptr %l10
  br label %bb3
bb2:
  store { i64, [2 x i64] } zeroinitializer, ptr %t29
  %t30 = getelementptr { i64, [2 x i64] }, ptr %t29, i32 0, i32 0
  store i64 0, ptr %t30
  %t31 = load { i64, [2 x i64] }, ptr %t29
  store { i64, [2 x i64] } %t31, ptr %l10
  br label %bb3
bb3:
  %t33 = load { i64, [2 x i64] }, ptr %l10
  store { i64, [2 x i64] } %t33, ptr %l2
  %t34 = load { i64, [2 x i64] }, ptr %l2
  %t36 = extractvalue { i64, [2 x i64] } %t34, 0
  %t37 = icmp eq i64 %t36, 1
  br i1 %t37, label %bb4, label %bb5
bb4:
  %t39 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t40 = getelementptr { i32 }, ptr %t39, i32 0, i32 0
  %t41 = load i32, ptr %t40
  store i32 %t41, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/lower:lowering", ptr %t45, i32 0, i32 1
  %t48 = load ptr, ptr %t47, !tbaa !29
  %t50 = getelementptr %"compiler/typed:Body", ptr %t48, i32 0, i32 7
  store ptr %t50, ptr %l23, !tbaa !29
  %t51 = load i64, ptr %l1, !tbaa !24
  %t52 = load ptr, ptr %l23, !tbaa !29
  %t53 = call ptr @__olang_scope_or(ptr %v1, ptr %t52)
  %t54 = call ptr @__olang_scope_hold(ptr %t53)
  %t55 = ptrtoint ptr %t54 to i64
  %t57 = inttoptr i64 %t55 to ptr
  %t58 = load ptr, ptr %l23, !tbaa !29
  %t60 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %t57, ptr %t58, i64 %t51)
  store %"compiler/typed:Local" %t60, ptr %l26
  br label %bb7
bb7:
  %t61 = getelementptr %"compiler/typed:Local", ptr %l26, i32 0, i32 3
  %t62 = load i32, ptr %t61, !tbaa !23
  store i32 %t62, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2estorageOf(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca { i64, [1 x i64] }
  %l3 = alloca { i64, [2 x i64] }
  %l4 = alloca i32
  %l13 = alloca %"compiler/mir:Local"
  %l23 = alloca i1
  %l24 = alloca { i64, [1 x i64] }
  %l29 = alloca { i64, [1 x i64] }
  %l30 = alloca i32
  %l41 = alloca { i64, ptr }
  %l51 = alloca { i64, [1 x i64] }
  %l52 = alloca ptr
  %l55 = alloca ptr
  %l59 = alloca %"compiler/typed:Local"
  %l62 = alloca { i64, [1 x i64] }
  %rv = alloca { i64, [1 x i64] }
  %t8 = alloca { i64, [1 x i64] }, align 8
  %t104 = alloca { i64, [2 x i64] }, align 8
  %t135 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 29
  %t4 = load i1, ptr %t3, !tbaa !21
  %t6 = xor i1 %t4, true
  br i1 %t6, label %bb1, label %bb2
bb1:
  store { i64, [1 x i64] } zeroinitializer, ptr %t8
  %t9 = getelementptr { i64, [1 x i64] }, ptr %t8, i32 0, i32 0
  store i64 2, ptr %t9
  %t10 = load { i64, [1 x i64] }, ptr %t8
  store { i64, [1 x i64] } %t10, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/lower:lowering", ptr %t12, i32 0, i32 3
  %t15 = getelementptr %"compiler/mir:Fn", ptr %t14, i32 0, i32 7
  %t16 = load i32, ptr %l1, !tbaa !23
  %t18 = sext i32 %t16 to i64
  %t21 = call %"compiler/mir:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eAt_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %t15, i64 %t18)
  store %"compiler/mir:Local" %t21, ptr %l13
  br label %bb4
bb4:
  %t22 = getelementptr %"compiler/mir:Local", ptr %l13, i32 0, i32 4
  %t23 = load { i64, [1 x i64] }, ptr %t22
  store { i64, [1 x i64] } %t23, ptr %l2
  %t25 = load { i64, [1 x i64] }, ptr %l2
  %t27 = extractvalue { i64, [1 x i64] } %t25, 0
  %t28 = icmp eq i64 %t27, 3
  %t30 = xor i1 %t28, true
  br i1 %t30, label %bb5, label %bb6
bb5:
  %t32 = load { i64, [1 x i64] }, ptr %l2
  store { i64, [1 x i64] } %t32, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/lower:lowering", ptr %t34, i32 0, i32 15
  %t37 = load i32, ptr %l1, !tbaa !23
  %t39 = sext i32 %t37 to i64
  %t42 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fmir_3aScopeRef_3e__H989114ff406840d3a5cfe99ba734fa56(ptr %v0, ptr %t36, i64 %t39)
  store i1 %t42, ptr %l23
  br label %bb8
bb8:
  %t43 = load i1, ptr %l23, !tbaa !21
  br i1 %t43, label %bb9, label %bb10
bb9:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/lower:lowering", ptr %t44, i32 0, i32 15
  %t47 = load i32, ptr %l1, !tbaa !23
  %t49 = sext i32 %t47 to i64
  %t52 = call { i32, { i64, [1 x i64] } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fmir_3aScopeRef_3e__H593d82357dc98d1f15fac9dd5b09c001(ptr %v0, ptr %t46, i64 %t49)
  %t53 = extractvalue { i32, { i64, [1 x i64] } } %t52, 1
  %t54 = extractvalue { i32, { i64, [1 x i64] } } %t52, 0
  store i32 %t54, ptr %l30
  %t55 = icmp ne i32 %t54, 0
  br i1 %t55, label %bb12, label %ok.56, !prof !99
ok.56:
  store { i64, [1 x i64] } %t53, ptr %l29
  br label %bb11
bb10:
  br label %bb15
bb11:
  %t57 = load { i64, [1 x i64] }, ptr %l29
  store { i64, [1 x i64] } %t57, ptr %l24
  br label %bb14
bb12:
  br label %bb13
bb13:
  %t58 = load { i64, [1 x i64] }, ptr %l2
  store { i64, [1 x i64] } %t58, ptr %l24
  br label %bb14
bb14:
  %t60 = load { i64, [1 x i64] }, ptr %l24
  store { i64, [1 x i64] } %t60, ptr %rv
  br label %ret
bb15:
  %t61 = load i32, ptr %l1, !tbaa !23
  %t63 = sext i32 %t61 to i64
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/lower:lowering", ptr %t64, i32 0, i32 38
  %t67 = load ptr, ptr %t66, !tbaa !29
  %t69 = getelementptr %"compiler/typed:Plan", ptr %t67, i32 0, i32 1
  %t70 = load { i64, ptr }, ptr %t69, !tbaa !27
  %t72 = extractvalue { i64, ptr } %t70, 0
  %t75 = icmp slt i64 %t63, %t72
  br i1 %t75, label %bb16, label %bb17
bb16:
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/lower:lowering", ptr %t77, i32 0, i32 38
  %t80 = load ptr, ptr %t79, !tbaa !29
  %t82 = getelementptr %"compiler/typed:Plan", ptr %t80, i32 0, i32 1
  %t83 = load { i64, ptr }, ptr %t82, !tbaa !27
  store { i64, ptr } %t83, ptr %l41, !tbaa !27
  %t84 = load i32, ptr %l1, !tbaa !23
  %t86 = sext i32 %t84 to i64
  %t88 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t89 = load ptr, ptr %t88, !tbaa !27
  %t90 = getelementptr { i64, [2 x i64] }, ptr %t89, i64 %t86
  %t91 = load { i64, [2 x i64] }, ptr %t90
  store { i64, [2 x i64] } %t91, ptr %l3
  %t93 = load { i64, [2 x i64] }, ptr %l3
  %t95 = extractvalue { i64, [2 x i64] } %t93, 0
  %t96 = icmp eq i64 %t95, 1
  br i1 %t96, label %bb18, label %bb19
bb17:
  br label %bb28
bb18:
  %t98 = getelementptr { i64, [2 x i64] }, ptr %l3, i32 0, i32 1
  %t99 = getelementptr { i32 }, ptr %t98, i32 0, i32 0
  %t100 = load i32, ptr %t99
  store i32 %t100, ptr %l4, !tbaa !23
  br label %bb20
bb19:
  br label %bb22
bb20:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t103 = load i32, ptr %l4, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t104
  %t105 = getelementptr { i64, [2 x i64] }, ptr %t104, i32 0, i32 0
  store i64 1, ptr %t105
  %t107 = insertvalue { i32 } undef, i32 %t103, 0
  %t108 = getelementptr { i64, [2 x i64] }, ptr %t104, i32 0, i32 1
  store { i32 } %t107, ptr %t108
  %t109 = load { i64, [2 x i64] }, ptr %t104
  %t112 = call { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2escopeRef(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %t102, { i64, [2 x i64] } %t109)
  store { i64, [1 x i64] } %t112, ptr %l51
  br label %bb21
bb21:
  %t113 = load { i64, [1 x i64] }, ptr %l51
  store { i64, [1 x i64] } %t113, ptr %rv
  br label %ret
bb22:
  br i1 true, label %bb23, label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb27
bb26:
  call void @__olang_check_failed(ptr @olang_loc_7c44d6a11fe580a3_63a95cd13601e77f)
  unreachable
bb27:
  br label %bb28
bb28:
  %t114 = load ptr, ptr %l0, !tbaa !29
  store ptr %t114, ptr %l52, !tbaa !29
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t117 = getelementptr %"compiler/lower:lowering", ptr %t115, i32 0, i32 1
  %t118 = load ptr, ptr %t117, !tbaa !29
  %t120 = getelementptr %"compiler/typed:Body", ptr %t118, i32 0, i32 7
  store ptr %t120, ptr %l55, !tbaa !29
  %t121 = load i32, ptr %l1, !tbaa !23
  %t123 = sext i32 %t121 to i64
  %t124 = load ptr, ptr %l55, !tbaa !29
  %t125 = call ptr @__olang_scope_or(ptr %v1, ptr %t124)
  %t126 = call ptr @__olang_scope_hold(ptr %t125)
  %t127 = ptrtoint ptr %t126 to i64
  %t129 = inttoptr i64 %t127 to ptr
  %t130 = load ptr, ptr %l55, !tbaa !29
  %t132 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %t129, ptr %t130, i64 %t123)
  store %"compiler/typed:Local" %t132, ptr %l59
  br label %bb29
bb29:
  %t133 = getelementptr %"compiler/typed:Local", ptr %l59, i32 0, i32 3
  %t134 = load i32, ptr %t133, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t135
  %t136 = getelementptr { i64, [2 x i64] }, ptr %t135, i32 0, i32 0
  store i64 1, ptr %t136
  %t138 = insertvalue { i32 } undef, i32 %t134, 0
  %t139 = getelementptr { i64, [2 x i64] }, ptr %t135, i32 0, i32 1
  store { i32 } %t138, ptr %t139
  %t140 = load { i64, [2 x i64] }, ptr %t135
  %t141 = load ptr, ptr %l52, !tbaa !29
  %t143 = call { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2escopeRef(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %t141, { i64, [2 x i64] } %t140)
  store { i64, [1 x i64] } %t143, ptr %l62
  br label %bb30
bb30:
  %t144 = load { i64, [1 x i64] }, ptr %l62
  store { i64, [1 x i64] } %t144, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [1 x i64] }, ptr %rv
  ret { i64, [1 x i64] } %rr
}

define dso_local { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2estoreHome(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %v6, ptr %a0, ptr %a1, ptr %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca i64
  %l5 = alloca i32
  %l6 = alloca i64
  %l7 = alloca i32
  %l8 = alloca %"compiler/source:Span"
  %l9 = alloca i32
  %l10 = alloca i64
  %l11 = alloca i32
  %l12 = alloca %"compiler/source:Span"
  %l13 = alloca i32
  %l14 = alloca i64
  %l15 = alloca i32
  %l16 = alloca i32
  %l20 = alloca i1
  %l26 = alloca i1
  %l33 = alloca ptr
  %l34 = alloca i1
  %l38 = alloca i1
  %l53 = alloca ptr
  %l54 = alloca ptr
  %l56 = alloca i32
  %l57 = alloca i1
  %l61 = alloca { i64, [1 x i64] }
  %l73 = alloca i32
  %l74 = alloca ptr
  %l75 = alloca %"compiler/source:Span"
  %l77 = alloca %"compiler/mir:Lvalue"
  %s0 = alloca %olang.scope
  %rv = alloca { i64, [1 x i64] }
  %t154 = alloca { i64, [1 x i64] }, align 8
  %t157 = alloca { i64, [15 x i64] }, align 8
  %t163 = alloca { i64, [21 x i64] }, align 8
  %t178 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store %"compiler/source:Span" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 39
  %t4 = load i1, ptr %t3, !tbaa !21
  %t6 = xor i1 %t4, true
  br i1 %t6, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l20, !tbaa !21
  br label %bb3
bb2:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/lower:lowering", ptr %t8, i32 0, i32 1
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t13 = getelementptr %"compiler/typed:Body", ptr %t11, i32 0, i32 1
  %t14 = load { i64, [2 x i64] }, ptr %t13
  %t16 = extractvalue { i64, [2 x i64] } %t14, 0
  %t17 = icmp eq i64 %t16, 6
  %t19 = xor i1 %t17, true
  store i1 %t19, ptr %l20, !tbaa !21
  br label %bb3
bb3:
  %t21 = load i1, ptr %l20, !tbaa !21
  br i1 %t21, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l26, !tbaa !21
  br label %bb8
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/lower:lowering", ptr %t22, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t27 = getelementptr %"compiler/typed:Body", ptr %t25, i32 0, i32 1
  %t28 = getelementptr { i64, [2 x i64] }, ptr %t27, i32 0, i32 1
  %t29 = getelementptr { i64, i32 }, ptr %t28, i32 0, i32 0
  %t30 = load i64, ptr %t29
  store i64 %t30, ptr %l4, !tbaa !24
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/lower:lowering", ptr %t32, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !29
  %t37 = getelementptr %"compiler/typed:Body", ptr %t35, i32 0, i32 1
  %t38 = getelementptr { i64, [2 x i64] }, ptr %t37, i32 0, i32 1
  %t39 = getelementptr { i64, i32 }, ptr %t38, i32 0, i32 1
  %t40 = load i32, ptr %t39
  store i32 %t40, ptr %l5, !tbaa !23
  %t42 = load ptr, ptr %l1, !tbaa !29
  store ptr %t42, ptr %l33, !tbaa !29
  store i1 false, ptr %l34, !tbaa !21
  %t43 = load ptr, ptr %l33, !tbaa !29
  %t44 = icmp ne ptr %t43, null
  br i1 %t44, label %bb6, label %bb7
bb6:
  %t46 = load ptr, ptr %l33, !tbaa !29
  %t47 = load i64, ptr %t46, !range !{i64 0, i64 8}
  %t49 = icmp eq i64 %t47, 1
  store i1 %t49, ptr %l34, !tbaa !21
  br label %bb7
bb7:
  %t50 = load i1, ptr %l34, !tbaa !21
  %t51 = xor i1 %t50, true
  store i1 %t51, ptr %l26, !tbaa !21
  br label %bb8
bb8:
  %t53 = load i1, ptr %l26, !tbaa !21
  br i1 %t53, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l38, !tbaa !21
  br label %bb13
bb10:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/lower:lowering", ptr %t54, i32 0, i32 1
  %t57 = load ptr, ptr %t56, !tbaa !29
  %t59 = getelementptr %"compiler/typed:Body", ptr %t57, i32 0, i32 1
  %t60 = getelementptr { i64, [2 x i64] }, ptr %t59, i32 0, i32 1
  %t61 = getelementptr { i64, i32 }, ptr %t60, i32 0, i32 0
  %t62 = load i64, ptr %t61
  store i64 %t62, ptr %l6, !tbaa !24
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/lower:lowering", ptr %t64, i32 0, i32 1
  %t67 = load ptr, ptr %t66, !tbaa !29
  %t69 = getelementptr %"compiler/typed:Body", ptr %t67, i32 0, i32 1
  %t70 = getelementptr { i64, [2 x i64] }, ptr %t69, i32 0, i32 1
  %t71 = getelementptr { i64, i32 }, ptr %t70, i32 0, i32 1
  %t72 = load i32, ptr %t71
  store i32 %t72, ptr %l7, !tbaa !23
  %t74 = load ptr, ptr %l1, !tbaa !29
  %t76 = getelementptr { i64, [4 x i64] }, ptr %t74, i32 0, i32 1
  %t77 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t76, i32 0, i32 0
  %t78 = load %"compiler/source:Span", ptr %t77
  store %"compiler/source:Span" %t78, ptr %l8
  %t80 = load ptr, ptr %l1, !tbaa !29
  %t82 = getelementptr { i64, [4 x i64] }, ptr %t80, i32 0, i32 1
  %t83 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t82, i32 0, i32 1
  %t84 = load i32, ptr %t83
  store i32 %t84, ptr %l9, !tbaa !23
  %t86 = load ptr, ptr %l1, !tbaa !29
  %t88 = getelementptr { i64, [4 x i64] }, ptr %t86, i32 0, i32 1
  %t89 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t88, i32 0, i32 2
  %t90 = load i64, ptr %t89
  store i64 %t90, ptr %l10, !tbaa !24
  %t92 = load ptr, ptr %l1, !tbaa !29
  %t94 = getelementptr { i64, [4 x i64] }, ptr %t92, i32 0, i32 1
  %t95 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t94, i32 0, i32 3
  %t96 = load i32, ptr %t95
  store i32 %t96, ptr %l11, !tbaa !23
  %t98 = load ptr, ptr %l0, !tbaa !29
  store ptr %t98, ptr %l53, !tbaa !29
  store ptr %a2, ptr %l54, !tbaa !29
  %t100 = load ptr, ptr %l1, !tbaa !29
  %t102 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v1, ptr %t100)
  store i32 %t102, ptr %l56
  br label %bb11
bb11:
  %t103 = load ptr, ptr %l53, !tbaa !29
  %t104 = load ptr, ptr %l54, !tbaa !29
  %t105 = load i32, ptr %l56, !tbaa !23
  %t106 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2ewidens(ptr %v0, ptr %v2, ptr %v3, ptr %t103, ptr %t104, i32 %t105)
  store i1 %t106, ptr %l57
  br label %bb12
bb12:
  %t107 = load i1, ptr %l57, !tbaa !21
  %t108 = xor i1 %t107, true
  store i1 %t108, ptr %l38, !tbaa !21
  br label %bb13
bb13:
  %t110 = load i1, ptr %l38, !tbaa !21
  br i1 %t110, label %bb14, label %bb15
bb14:
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t112 = load ptr, ptr %l1, !tbaa !29
  %t115 = call { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eplaceStorage(ptr %v0, ptr %v1, ptr %v4, ptr %v5, ptr %v3, ptr %v6, ptr %t111, ptr %t112)
  store { i64, [1 x i64] } %t115, ptr %l61
  br label %bb16
bb15:
  br label %bb17
bb16:
  call void @__olang_scope_close(ptr %s0)
  %t116 = load { i64, [1 x i64] }, ptr %l61
  store { i64, [1 x i64] } %t116, ptr %rv
  br label %ret
bb17:
  %t117 = load ptr, ptr %l1, !tbaa !29
  %t119 = getelementptr { i64, [4 x i64] }, ptr %t117, i32 0, i32 1
  %t120 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t119, i32 0, i32 0
  %t121 = load %"compiler/source:Span", ptr %t120
  store %"compiler/source:Span" %t121, ptr %l12
  %t123 = load ptr, ptr %l1, !tbaa !29
  %t125 = getelementptr { i64, [4 x i64] }, ptr %t123, i32 0, i32 1
  %t126 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t125, i32 0, i32 1
  %t127 = load i32, ptr %t126
  store i32 %t127, ptr %l13, !tbaa !23
  %t129 = load ptr, ptr %l1, !tbaa !29
  %t131 = getelementptr { i64, [4 x i64] }, ptr %t129, i32 0, i32 1
  %t132 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t131, i32 0, i32 2
  %t133 = load i64, ptr %t132
  store i64 %t133, ptr %l14, !tbaa !24
  %t135 = load ptr, ptr %l1, !tbaa !29
  %t137 = getelementptr { i64, [4 x i64] }, ptr %t135, i32 0, i32 1
  %t138 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t137, i32 0, i32 3
  %t139 = load i32, ptr %t138
  store i32 %t139, ptr %l15, !tbaa !23
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t142 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  %t143 = load %"compiler/source:Span", ptr %l3
  %t147 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2etemp(ptr %v0, ptr %t141, i32 %t142, %"compiler/source:Span" %t143)
  store i32 %t147, ptr %l73
  br label %bb18
bb18:
  %t148 = load i32, ptr %l73, !tbaa !23
  store i32 %t148, ptr %l16, !tbaa !23
  %t149 = load ptr, ptr %l0, !tbaa !29
  store ptr %t149, ptr %l74, !tbaa !29
  %t150 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t150, ptr %l75
  %t151 = load i32, ptr %l16, !tbaa !23
  %t153 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t151)
  store %"compiler/mir:Lvalue" %t153, ptr %l77
  br label %bb19
bb19:
  store { i64, [1 x i64] } zeroinitializer, ptr %t154
  %t155 = getelementptr { i64, [1 x i64] }, ptr %t154, i32 0, i32 0
  store i64 2, ptr %t155
  %t156 = load { i64, [1 x i64] }, ptr %t154
  store { i64, [15 x i64] } zeroinitializer, ptr %t157
  %t158 = getelementptr { i64, [15 x i64] }, ptr %t157, i32 0, i32 0
  store i64 13, ptr %t158
  %t160 = insertvalue { { i64, [1 x i64] } } undef, { i64, [1 x i64] } %t156, 0
  %t161 = getelementptr { i64, [15 x i64] }, ptr %t157, i32 0, i32 1
  store { { i64, [1 x i64] } } %t160, ptr %t161
  %t162 = load { i64, [15 x i64] }, ptr %t157
  store { i64, [21 x i64] } zeroinitializer, ptr %t163
  %t164 = getelementptr { i64, [21 x i64] }, ptr %t163, i32 0, i32 0
  store i64 0, ptr %t164
  %t165 = load %"compiler/source:Span", ptr %l75
  %t166 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t165, 0
  %t167 = load %"compiler/mir:Lvalue", ptr %l77
  %t168 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t166, %"compiler/mir:Lvalue" %t167, 1
  %t170 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t168, { i64, [15 x i64] } %t162, 2
  %t171 = getelementptr { i64, [21 x i64] }, ptr %t163, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t170, ptr %t171
  %t172 = load { i64, [21 x i64] }, ptr %t163
  %t174 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t172, ptr %t174
  %t175 = load ptr, ptr %l74, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s0, ptr %v3, ptr %v6, ptr %t175, ptr %t174)
  br label %bb20
bb20:
  %t177 = load i32, ptr %l16, !tbaa !23
  store { i64, [1 x i64] } zeroinitializer, ptr %t178
  %t179 = getelementptr { i64, [1 x i64] }, ptr %t178, i32 0, i32 0
  store i64 4, ptr %t179
  %t181 = insertvalue { i32 } undef, i32 %t177, 0
  %t182 = getelementptr { i64, [1 x i64] }, ptr %t178, i32 0, i32 1
  store { i32 } %t181, ptr %t182
  %t183 = load { i64, [1 x i64] }, ptr %t178
  call void @__olang_scope_close(ptr %s0)
  store { i64, [1 x i64] } %t183, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [1 x i64] }, ptr %rv
  ret { i64, [1 x i64] } %rr
}

define dso_local i32 @compiler_2flower_2ecompiler_2flower_3alowering_2etemp(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %l7 = alloca i32
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/lower:lowering", ptr %a0, i32 0, i32 3
  %t9 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddTemp(ptr %v0, ptr %t3, i32 %a1, %"compiler/source:Span" %a2)
  store i32 %t9, ptr %l7
  br label %bb1
bb1:
  %t10 = load i32, ptr %l7, !tbaa !23
  store i32 %t10, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2etextSlotCopy(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/lower:pl" %a1, i32 %a2, i64 %a3, { i64, [1 x i64] } %a4, %"compiler/source:Span" %a5) #0 {
entry:
  %l0 = alloca ptr
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca ptr
  %l7 = alloca %"compiler/lower:pl"
  %l9 = alloca %"compiler/lower:pl"
  %l10 = alloca i32
  %l15 = alloca { i64, [1 x i64] }
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l6, !tbaa !29
  store %"compiler/lower:pl" %a1, ptr %l7
  %t4 = call %"compiler/lower:pl" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2flower_3apl(ptr %s0, ptr %l7)
  store %"compiler/lower:pl" %t4, ptr %l9
  br label %bb1
bb1:
  store i32 %a2, ptr %l10, !tbaa !23
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t9 = load %"compiler/source:Span", ptr %l5
  %t14 = call { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eslotsOf(ptr %v0, ptr %v2, ptr %v3, ptr %t6, i64 %a3, { i64, [1 x i64] } %a4, %"compiler/source:Span" %t9)
  store { i64, [1 x i64] } %t14, ptr %l15
  br label %bb2
bb2:
  %t15 = load %"compiler/source:Span", ptr %l5
  %t16 = load ptr, ptr %l6, !tbaa !29
  %t17 = load %"compiler/lower:pl", ptr %l9
  %t18 = load i32, ptr %l10, !tbaa !23
  %t19 = load { i64, [1 x i64] }, ptr %l15
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2etextInto(ptr %v0, ptr %s0, ptr %v2, ptr %v3, ptr %t16, %"compiler/lower:pl" %t17, i32 %t18, { i64, [1 x i64] } %t19, %"compiler/source:Span" %t15)
  br label %bb3
bb3:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3alowering_2etryCopies(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l14 = alloca i1
  %l15 = alloca ptr
  %l21 = alloca i1
  %l31 = alloca { i64, ptr }
  %l42 = alloca { i64, ptr }
  %l47 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Try", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = icmp eq ptr %t4, null
  %t8 = xor i1 %t6, true
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l15, !tbaa !29
  %t11 = load ptr, ptr %l1, !tbaa !29
  %t13 = getelementptr %"compiler/typed:Try", ptr %t11, i32 0, i32 0
  %t14 = load ptr, ptr %t13, !tbaa !29
  %t16 = icmp eq ptr %t14, null
  br i1 %t16, label %bb3, label %bb4
bb2:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb7
bb3:
  call void @__olang_check_failed(ptr @olang_loc_a3627063ced14f10_5c0b773917422a84)
  unreachable
bb4:
  br label %bb5
bb5:
  %t18 = load ptr, ptr %l1, !tbaa !29
  %t20 = getelementptr %"compiler/typed:Try", ptr %t18, i32 0, i32 0
  %t21 = load ptr, ptr %t20, !tbaa !29
  %t22 = load ptr, ptr %l15, !tbaa !29
  %t24 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2ecopiesValue(ptr %v0, ptr %v1, ptr %v2, ptr %t22, ptr %t21)
  store i1 %t24, ptr %l21
  br label %bb6
bb6:
  %t25 = load i1, ptr %l21, !tbaa !21
  store i1 %t25, ptr %l14, !tbaa !21
  br label %bb7
bb7:
  %t26 = load i1, ptr %l14, !tbaa !21
  br i1 %t26, label %bb8, label %bb9
bb8:
  store i1 true, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t28 = load ptr, ptr %l1, !tbaa !29
  %t30 = getelementptr %"compiler/typed:Try", ptr %t28, i32 0, i32 1
  %t31 = load { i64, ptr }, ptr %t30, !tbaa !27
  store { i64, ptr } %t31, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t33 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t35 = extractvalue { i64, ptr } %t33, 0
  store i64 %t35, ptr %l4, !tbaa !24
  br label %bb11
bb11:
  %t37 = load i64, ptr %l3, !tbaa !24
  %t38 = load i64, ptr %l4, !tbaa !24
  %t41 = icmp slt i64 %t37, %t38
  %t43 = xor i1 %t41, true
  br i1 %t43, label %bb12, label %bb13
bb12:
  br label %bb26
bb13:
  br label %bb14
bb14:
  %t45 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t45, ptr %l31, !tbaa !27
  %t46 = load i64, ptr %l3, !tbaa !24
  %t48 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !27
  %t50 = getelementptr ptr, ptr %t49, i64 %t46
  %t51 = load ptr, ptr %t50, !tbaa !39
  %t55 = getelementptr %"compiler/typed:Clause", ptr %t51, i32 0, i32 4
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  store { i64, ptr } %t56, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t58 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t60 = extractvalue { i64, ptr } %t58, 0
  store i64 %t60, ptr %l8, !tbaa !24
  br label %bb15
bb15:
  %t62 = load i64, ptr %l7, !tbaa !24
  %t63 = load i64, ptr %l8, !tbaa !24
  %t66 = icmp slt i64 %t62, %t63
  %t68 = xor i1 %t66, true
  br i1 %t68, label %bb16, label %bb17
bb16:
  br label %bb24
bb17:
  br label %bb18
bb18:
  %t70 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t70, ptr %l42, !tbaa !27
  %t71 = load i64, ptr %l7, !tbaa !24
  %t73 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t74 = load ptr, ptr %t73, !tbaa !27
  %t75 = getelementptr ptr, ptr %t74, i64 %t71
  %t76 = load ptr, ptr %t75, !tbaa !39
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t82 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2ecopiesValue(ptr %v0, ptr %v1, ptr %v2, ptr %t78, ptr %t76)
  store i1 %t82, ptr %l47
  br label %bb19
bb19:
  %t83 = load i1, ptr %l47, !tbaa !21
  br i1 %t83, label %bb20, label %bb21
bb20:
  store i1 true, ptr %rv
  br label %ret
bb21:
  br label %bb22
bb22:
  br label %bb23
bb23:
  %t85 = load i64, ptr %l7, !tbaa !24
  %t88 = add i64 %t85, 1
  store i64 %t88, ptr %l7, !tbaa !24
  br label %bb15
bb24:
  br label %bb25
bb25:
  %t90 = load i64, ptr %l3, !tbaa !24
  %t93 = add i64 %t90, 1
  store i64 %t93, ptr %l3, !tbaa !24
  br label %bb11
bb26:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2etypeIs(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, [4 x i64] } %a1, i64 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca %"compiler/source:Span"
  %l11 = alloca { i64, ptr }
  %l13 = alloca { i64, [4 x i64] }
  %l22 = alloca { i64, ptr }
  %l24 = alloca { i64, [4 x i64] }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, [4 x i64] }
  %t5 = alloca { i64, [4 x i64] }, align 8
  %t39 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr @G_2ecompiler_2fmir_2eI32T, !tbaa !23
  %t4 = load i32, ptr @G_2ecompiler_2fmir_2eI32T, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t5
  %t6 = getelementptr { i64, [4 x i64] }, ptr %t5, i32 0, i32 0
  store i64 2, ptr %t6
  %t8 = insertvalue { i32, i64 } undef, i32 %t4, 0
  %t9 = insertvalue { i32, i64 } %t8, i64 16, 1
  %t10 = getelementptr { i64, [4 x i64] }, ptr %t5, i32 0, i32 1
  store { i32, i64 } %t9, ptr %t10
  %t11 = load { i64, [4 x i64] }, ptr %t5
  %t12 = mul i64 2, 40
  %t13 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t12)
  %t14 = insertvalue { i64, ptr } undef, i64 2, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t13, 1
  store { i64, ptr } %t15, ptr %l11, !tbaa !27
  %t17 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t18 = load ptr, ptr %t17, !tbaa !27
  %t19 = getelementptr { i64, [4 x i64] }, ptr %t18, i64 0
  store { i64, [4 x i64] } %a1, ptr %t19
  %t21 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr { i64, [4 x i64] }, ptr %t22, i64 1
  store { i64, [4 x i64] } %t11, ptr %t23
  %t24 = load %"compiler/source:Span", ptr %l3
  %t28 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t30 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s0, ptr %v1, ptr %v2, ptr %t1, i32 9, i32 %t2, { i64, ptr } %t28, %"compiler/source:Span" %t24)
  store { i64, [4 x i64] } %t30, ptr %l13
  br label %bb1
bb1:
  %t31 = load { i64, [4 x i64] }, ptr %l13
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t33 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t35 = load i32, ptr @G_2ecompiler_2fmir_2eI32T, !tbaa !23
  %t38 = add i64 %a2, 1
  store { i64, [4 x i64] } zeroinitializer, ptr %t39
  %t40 = getelementptr { i64, [4 x i64] }, ptr %t39, i32 0, i32 0
  store i64 2, ptr %t40
  %t42 = insertvalue { i32, i64 } undef, i32 %t35, 0
  %t44 = insertvalue { i32, i64 } %t42, i64 %t38, 1
  %t45 = getelementptr { i64, [4 x i64] }, ptr %t39, i32 0, i32 1
  store { i32, i64 } %t44, ptr %t45
  %t46 = load { i64, [4 x i64] }, ptr %t39
  %t47 = mul i64 2, 40
  %t48 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t47)
  %t49 = insertvalue { i64, ptr } undef, i64 2, 0
  %t50 = insertvalue { i64, ptr } %t49, ptr %t48, 1
  store { i64, ptr } %t50, ptr %l22, !tbaa !27
  %t52 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !27
  %t54 = getelementptr { i64, [4 x i64] }, ptr %t53, i64 0
  store { i64, [4 x i64] } %t31, ptr %t54
  %t56 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t57 = load ptr, ptr %t56, !tbaa !27
  %t58 = getelementptr { i64, [4 x i64] }, ptr %t57, i64 1
  store { i64, [4 x i64] } %t46, ptr %t58
  %t59 = load %"compiler/source:Span", ptr %l3
  %t63 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t65 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s0, ptr %v1, ptr %v2, ptr %t32, i32 13, i32 %t33, { i64, ptr } %t63, %"compiler/source:Span" %t59)
  store { i64, [4 x i64] } %t65, ptr %l24
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  %t66 = load { i64, [4 x i64] }, ptr %l24
  store { i64, [4 x i64] } %t66, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local ptr @compiler_2flower_2ecompiler_2flower_3alowering_2eunconvert(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca ptr
  %l5 = alloca i1
  %l14 = alloca i1
  %l18 = alloca i1
  %l19 = alloca ptr
  %l20 = alloca { i64, ptr }
  %l22 = alloca i32
  %l23 = alloca i1
  %l25 = alloca { i64, ptr }
  %l27 = alloca ptr
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 9
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t12, i32 0, i32 2
  %t14 = load i32, ptr %t13, !range !{i32 0, i32 54}
  store i32 %t14, ptr %l2
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t18, i32 0, i32 4
  %t20 = load { i64, ptr }, ptr %t19
  store { i64, ptr } %t20, ptr %l3, !tbaa !27
  br label %bb5
bb4:
  br label %bb18
bb5:
  %t22 = load i32, ptr %l2, !range !{i32 0, i32 54}
  %t24 = trunc i64 20 to i32
  %t25 = icmp eq i32 %t22, %t24
  br i1 %t25, label %bb6, label %bb7
bb6:
  %t27 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t27, 0
  %t31 = icmp eq i64 %t29, 1
  store i1 %t31, ptr %l14, !tbaa !21
  br label %bb8
bb7:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb8
bb8:
  %t33 = load i1, ptr %l14, !tbaa !21
  br i1 %t33, label %bb9, label %bb10
bb9:
  %t34 = load ptr, ptr %l0, !tbaa !29
  store ptr %t34, ptr %l19, !tbaa !29
  %t35 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t35, ptr %l20, !tbaa !27
  %t36 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !27
  %t38 = getelementptr ptr, ptr %t37, i64 0
  %t39 = load ptr, ptr %t38, !tbaa !39
  %t41 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t39)
  store i32 %t41, ptr %l22
  br label %bb11
bb10:
  store i1 false, ptr %l18, !tbaa !21
  br label %bb13
bb11:
  %t42 = load ptr, ptr %l19, !tbaa !29
  %t43 = load i32, ptr %l22, !tbaa !23
  %t44 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2evalueArray(ptr %v0, ptr %v3, ptr %t42, i32 %t43)
  store i1 %t44, ptr %l23
  br label %bb12
bb12:
  %t45 = load i1, ptr %l23, !tbaa !21
  store i1 %t45, ptr %l18, !tbaa !21
  br label %bb13
bb13:
  %t46 = load i1, ptr %l18, !tbaa !21
  br i1 %t46, label %bb14, label %bb15
bb14:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t48 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t48, ptr %l25, !tbaa !27
  %t49 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !27
  %t51 = getelementptr ptr, ptr %t50, i64 0
  %t52 = load ptr, ptr %t51, !tbaa !39
  %t55 = call ptr @compiler_2flower_2ecompiler_2flower_3alowering_2eunconvert(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t47, ptr %t52)
  store ptr %t55, ptr %l27
  br label %bb16
bb15:
  br label %bb17
bb16:
  %t56 = load ptr, ptr %l27, !tbaa !29
  store ptr %t56, ptr %rv
  br label %ret
bb17:
  br label %bb23
bb18:
  br i1 true, label %bb19, label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb23
bb22:
  call void @__olang_check_failed(ptr @olang_loc_d8cada644e10ccc9_6a931382540e069d)
  unreachable
bb23:
  %t57 = load ptr, ptr %l1, !tbaa !29
  store ptr %t57, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local { i64, ptr } @compiler_2flower_2ecompiler_2flower_3alowering_2evals(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %v6, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l10 = alloca i64
  %l19 = alloca i64
  %l22 = alloca i64
  %l40 = alloca i64
  %l42 = alloca { i64, ptr }
  %l46 = alloca { i64, [4 x i64] }
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  store i64 %t3, ptr %l10, !tbaa !24
  %t4 = load i64, ptr %l10, !tbaa !24
  %t5 = icmp sge i64 %t4, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load i64, ptr %l10, !tbaa !24
  %t8 = icmp sle i64 %t7, 230584300921369395
  br i1 %t8, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_73384406ab4916da_7af5324ba56268d6)
  unreachable
bb3:
  %t10 = load i64, ptr %l10, !tbaa !24
  %t11 = mul i64 %t10, 40
  %t12 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t11)
  %t13 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t16 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t18 = extractvalue { i64, ptr } %t16, 0
  store i64 %t18, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t20 = load i64, ptr %l4, !tbaa !24
  %t21 = load i64, ptr %l3, !tbaa !24
  %t24 = icmp sgt i64 %t20, %t21
  br i1 %t24, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_73384406ab4916da_7af5324ba56268d6)
  unreachable
bb5:
  %t26 = load i64, ptr %l5, !tbaa !24
  %t28 = icmp sgt i64 %t26, 0
  br i1 %t28, label %bb7, label %bb8
bb6:
  store i64 0, ptr %l19, !tbaa !24
  br label %bb10
bb7:
  %t30 = load i64, ptr %l4, !tbaa !24
  %t31 = load i64, ptr %l3, !tbaa !24
  %t34 = sub i64 %t30, %t31
  %t35 = load i64, ptr %l5, !tbaa !24
  %t38 = add i64 %t34, %t35
  %t40 = sub i64 %t38, 1
  %t41 = load i64, ptr %l5, !tbaa !24
  %t44 = sdiv i64 %t40, %t41
  store i64 %t44, ptr %l22, !tbaa !24
  br label %bb9
bb8:
  store i64 0, ptr %l22, !tbaa !24
  br label %bb9
bb9:
  %t46 = load i64, ptr %l22, !tbaa !24
  store i64 %t46, ptr %l19, !tbaa !24
  br label %bb10
bb10:
  %t47 = load i64, ptr %l19, !tbaa !24
  store i64 %t47, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb11
bb11:
  %t48 = load i64, ptr %l7, !tbaa !24
  %t49 = load i64, ptr %l6, !tbaa !24
  %t52 = icmp slt i64 %t48, %t49
  %t54 = xor i1 %t52, true
  br i1 %t54, label %bb12, label %bb13
bb12:
  br label %bb17
bb13:
  br label %bb14
bb14:
  %t56 = load i64, ptr %l3, !tbaa !24
  %t57 = load i64, ptr %l7, !tbaa !24
  %t58 = load i64, ptr %l5, !tbaa !24
  %t61 = mul i64 %t57, %t58
  %t64 = add i64 %t56, %t61
  store i64 %t64, ptr %l8, !tbaa !24
  %t66 = load i64, ptr %l8, !tbaa !24
  store i64 %t66, ptr %l40, !tbaa !24
  %t68 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t68, ptr %l42, !tbaa !27
  %t69 = load i64, ptr %l8, !tbaa !24
  %t71 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t72 = load ptr, ptr %t71, !tbaa !27
  %t73 = getelementptr ptr, ptr %t72, i64 %t69
  %t74 = load ptr, ptr %t73, !tbaa !39
  %t78 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v1, ptr %v3, ptr %v4, ptr %v5, ptr %v6, ptr %a0, ptr %t74)
  store { i64, [4 x i64] } %t78, ptr %l46
  br label %bb15
bb15:
  %t79 = load { i64, [4 x i64] }, ptr %l46
  %t80 = load i64, ptr %l40, !tbaa !24
  %t81 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !27
  %t83 = getelementptr { i64, [4 x i64] }, ptr %t82, i64 %t80
  store { i64, [4 x i64] } %t79, ptr %t83
  br label %bb16
bb16:
  %t84 = load i64, ptr %l7, !tbaa !24
  %t87 = add i64 %t84, 1
  store i64 %t87, ptr %l7, !tbaa !24
  br label %bb11
bb17:
  %t89 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t89, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3alowering_2evalueArray(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca i32
  %l6 = alloca ptr
  %l9 = alloca i32
  %l10 = alloca ptr
  %l13 = alloca i32
  %l16 = alloca i1
  %l17 = alloca ptr
  %l20 = alloca i32
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/lower:lowering", ptr %a0, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  store ptr %t6, ptr %l6, !tbaa !29
  %t8 = load ptr, ptr %l6, !tbaa !29
  %t9 = call ptr @__olang_scope_or(ptr %v1, ptr %t8)
  %t10 = call ptr @__olang_scope_hold(ptr %t9)
  %t11 = ptrtoint ptr %t10 to i64
  %t13 = inttoptr i64 %t11 to ptr
  %t14 = load ptr, ptr %l6, !tbaa !29
  %t16 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %t13, ptr %t14, i32 %a1)
  store i32 %t16, ptr %l9
  br label %bb1
bb1:
  %t17 = load i32, ptr %l9, !tbaa !23
  store i32 %t17, ptr %l3, !tbaa !23
  %t18 = load ptr, ptr %l2, !tbaa !29
  store ptr %t18, ptr %l10, !tbaa !29
  %t19 = load i32, ptr %l3, !tbaa !23
  %t20 = load ptr, ptr %l10, !tbaa !29
  %t21 = call ptr @__olang_scope_or(ptr %v1, ptr %t20)
  %t22 = call ptr @__olang_scope_hold(ptr %t21)
  %t23 = ptrtoint ptr %t22 to i64
  %t25 = inttoptr i64 %t23 to ptr
  %t26 = load ptr, ptr %l10, !tbaa !29
  %t28 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %t25, ptr %t26, i32 %t19)
  store i32 %t28, ptr %l13
  br label %bb2
bb2:
  %t29 = load i32, ptr %l13, !range !{i32 0, i32 33}
  %t31 = trunc i64 19 to i32
  %t32 = icmp eq i32 %t29, %t31
  br i1 %t32, label %bb3, label %bb4
bb3:
  %t34 = load ptr, ptr %l2, !tbaa !29
  store ptr %t34, ptr %l17, !tbaa !29
  %t35 = load i32, ptr %l3, !tbaa !23
  %t36 = load ptr, ptr %l17, !tbaa !29
  %t37 = call ptr @__olang_scope_or(ptr %v1, ptr %t36)
  %t38 = call ptr @__olang_scope_hold(ptr %t37)
  %t39 = ptrtoint ptr %t38 to i64
  %t41 = inttoptr i64 %t39 to ptr
  %t42 = load ptr, ptr %l17, !tbaa !29
  %t44 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %t41, ptr %t42, i32 %t35)
  store i32 %t44, ptr %l20
  br label %bb5
bb4:
  store i1 false, ptr %l16, !tbaa !21
  br label %bb6
bb5:
  %t45 = load i32, ptr %l20, !tbaa !23
  %t46 = icmp eq i32 %t45, 0
  store i1 %t46, ptr %l16, !tbaa !21
  br label %bb6
bb6:
  %t48 = load i1, ptr %l16, !tbaa !21
  store i1 %t48, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eviewValue(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l3 = alloca ptr
  %l6 = alloca i1
  %l8 = alloca i1
  %l10 = alloca ptr
  %l13 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t5 = load i32, ptr %l1, !tbaa !23
  %t6 = load ptr, ptr %l3, !tbaa !29
  %t7 = call ptr @__olang_scope_or(ptr %v1, ptr %t6)
  %t8 = call ptr @__olang_scope_hold(ptr %t7)
  %t9 = ptrtoint ptr %t8 to i64
  %t11 = inttoptr i64 %t9 to ptr
  %t12 = load ptr, ptr %l3, !tbaa !29
  %t14 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %t11, ptr %t12, i32 %t5)
  store i1 %t14, ptr %l6
  br label %bb1
bb1:
  %t15 = load i1, ptr %l6, !tbaa !21
  %t16 = xor i1 %t15, true
  br i1 %t16, label %bb2, label %bb3
bb2:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/lower:lowering", ptr %t18, i32 0, i32 2
  %t21 = load ptr, ptr %t20, !tbaa !29
  store ptr %t21, ptr %l10, !tbaa !29
  %t22 = load i32, ptr %l1, !tbaa !23
  %t23 = load ptr, ptr %l10, !tbaa !29
  %t24 = call ptr @__olang_scope_or(ptr %v1, ptr %t23)
  %t25 = call ptr @__olang_scope_hold(ptr %t24)
  %t26 = ptrtoint ptr %t25 to i64
  %t28 = inttoptr i64 %t26 to ptr
  %t29 = load ptr, ptr %l10, !tbaa !29
  %t31 = call i1 @compiler_2ftyped_2eHoldsOwned(ptr %t28, ptr %t29, i32 %t22)
  store i1 %t31, ptr %l13
  br label %bb4
bb3:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb5
bb4:
  %t32 = load i1, ptr %l13, !tbaa !21
  store i1 %t32, ptr %l8, !tbaa !21
  br label %bb5
bb5:
  %t33 = load i1, ptr %l8, !tbaa !21
  store i1 %t33, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3alowering_2ewaits(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, i64 %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l11 = alloca i64
  %l16 = alloca i64
  %l18 = alloca i64
  %l23 = alloca i64
  %l27 = alloca i1
  %l30 = alloca i1
  %l33 = alloca i64
  %l36 = alloca i1
  %l38 = alloca ptr
  %l41 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  %t5 = call i64 @compiler_2flower_2ecompiler_2flower_3alowering_2eholderOf(ptr %v0, ptr %v3, ptr %t1, i64 %t2)
  store i64 %t5, ptr %l11
  br label %bb1
bb1:
  %t6 = load i64, ptr %l11, !tbaa !24
  store i64 %t6, ptr %l4, !tbaa !24
  %t7 = load i64, ptr %l4, !tbaa !24
  %t9 = icmp slt i64 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  store i1 false, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  store ptr %a2, ptr %l5, !tbaa !29
  store i64 0, ptr %l6, !tbaa !24
  br label %bb5
bb5:
  %t14 = load i64, ptr %l6, !tbaa !24
  store i64 %t14, ptr %l16, !tbaa !24
  %t15 = load ptr, ptr %l5, !tbaa !29
  %t17 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t15)
  store i64 %t17, ptr %l18
  br label %bb6
bb6:
  %t18 = load i64, ptr %l16, !tbaa !24
  %t19 = load i64, ptr %l18, !tbaa !24
  %t20 = icmp slt i64 %t18, %t19
  %t22 = xor i1 %t20, true
  br i1 %t22, label %bb7, label %bb8
bb7:
  br label %bb28
bb8:
  br label %bb9
bb9:
  %t24 = load ptr, ptr %l5, !tbaa !29
  %t25 = load i64, ptr %l6, !tbaa !24
  %t28 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t24, i64 %t25)
  store i64 %t28, ptr %l23
  br label %bb10
bb10:
  %t29 = load i64, ptr %l23, !tbaa !24
  store i64 %t29, ptr %l7, !tbaa !24
  %t30 = load i64, ptr %l7, !tbaa !24
  %t31 = load i64, ptr %l1, !tbaa !24
  %t34 = icmp eq i64 %t30, %t31
  br i1 %t34, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l27, !tbaa !21
  br label %bb14
bb12:
  %t37 = load i64, ptr %l7, !tbaa !24
  %t40 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eHas_3cI64_3e(ptr %v2, ptr %a3, i64 %t37)
  store i1 %t40, ptr %l30
  br label %bb13
bb13:
  %t41 = load i1, ptr %l30, !tbaa !21
  store i1 %t41, ptr %l27, !tbaa !21
  br label %bb14
bb14:
  %t42 = load i1, ptr %l27, !tbaa !21
  br i1 %t42, label %bb15, label %bb16
bb15:
  br label %bb27
bb16:
  br label %bb17
bb17:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t44 = load i64, ptr %l7, !tbaa !24
  %t47 = call i64 @compiler_2flower_2ecompiler_2flower_3alowering_2eholderOf(ptr %v0, ptr %v3, ptr %t43, i64 %t44)
  store i64 %t47, ptr %l33
  br label %bb18
bb18:
  %t48 = load i64, ptr %l33, !tbaa !24
  store i64 %t48, ptr %l8, !tbaa !24
  %t49 = load i64, ptr %l8, !tbaa !24
  %t51 = icmp sge i64 %t49, 0
  br i1 %t51, label %bb19, label %bb20
bb19:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = call ptr @compiler_2flower_2ecompiler_2flower_3alowering_2eholds(ptr %v0, ptr %v0, ptr %v4, ptr %v3, ptr %t53)
  store ptr %t55, ptr %l38
  br label %bb21
bb20:
  store i1 false, ptr %l36, !tbaa !21
  br label %bb23
bb21:
  %t56 = load i64, ptr %l8, !tbaa !24
  %t57 = load i64, ptr %l4, !tbaa !24
  %t58 = load ptr, ptr %l38, !tbaa !29
  %t61 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aDropHolding_2eHolds(ptr %v0, ptr %t58, i64 %t56, i64 %t57)
  store i1 %t61, ptr %l41
  br label %bb22
bb22:
  %t62 = load i1, ptr %l41, !tbaa !21
  store i1 %t62, ptr %l36, !tbaa !21
  br label %bb23
bb23:
  %t63 = load i1, ptr %l36, !tbaa !21
  br i1 %t63, label %bb24, label %bb25
bb24:
  store i1 true, ptr %rv
  br label %ret
bb25:
  br label %bb26
bb26:
  br label %bb27
bb27:
  %t65 = load i64, ptr %l6, !tbaa !24
  %t68 = add i64 %t65, 1
  store i64 %t68, ptr %l6, !tbaa !24
  br label %bb5
bb28:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ewidenAt(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, ptr %a1, { i64, [1 x i64] } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, [1 x i64] }
  %l3 = alloca ptr
  %l4 = alloca i64
  %l9 = alloca i1
  %l14 = alloca i64
  %l15 = alloca ptr
  %l16 = alloca i1
  %l26 = alloca i1
  %l36 = alloca { i64, ptr }
  %l39 = alloca { i64, [1 x i64] }
  %l46 = alloca { i64, [1 x i64] }
  %rv = alloca { i64, [1 x i64] }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store { i64, [1 x i64] } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 39
  %t4 = load i1, ptr %t3, !tbaa !21
  %t6 = xor i1 %t4, true
  br i1 %t6, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb3
bb2:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/lower:lowering", ptr %t8, i32 0, i32 29
  %t11 = load i1, ptr %t10, !tbaa !21
  %t13 = xor i1 %t11, true
  store i1 %t13, ptr %l9, !tbaa !21
  br label %bb3
bb3:
  %t15 = load i1, ptr %l9, !tbaa !21
  br i1 %t15, label %bb4, label %bb5
bb4:
  %t16 = load { i64, [1 x i64] }, ptr %l2
  store { i64, [1 x i64] } %t16, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t18 = load ptr, ptr %l1, !tbaa !29
  store ptr %t18, ptr %l15, !tbaa !29
  store i1 false, ptr %l16, !tbaa !21
  %t19 = load ptr, ptr %l15, !tbaa !29
  %t20 = icmp ne ptr %t19, null
  br i1 %t20, label %bb7, label %bb8
bb7:
  %t22 = load ptr, ptr %l15, !tbaa !29
  %t23 = load i64, ptr %t22, !range !{i64 0, i64 18}
  %t25 = icmp eq i64 %t23, 7
  store i1 %t25, ptr %l16, !tbaa !21
  br label %bb8
bb8:
  %t26 = load i1, ptr %l16, !tbaa !21
  br i1 %t26, label %bb9, label %bb10
bb9:
  %t27 = load ptr, ptr %l1, !tbaa !29
  %t29 = getelementptr { i64, [5 x i64] }, ptr %t27, i32 0, i32 1
  %t30 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t29, i32 0, i32 2
  %t31 = load ptr, ptr %t30
  store ptr %t31, ptr %l3, !tbaa !29
  br label %bb11
bb10:
  br label %bb12
bb11:
  %t33 = load ptr, ptr %l3, !tbaa !29
  %t35 = getelementptr %"compiler/typed:Make", ptr %t33, i32 0, i32 4
  %t36 = load i32, ptr %t35, !tbaa !23
  %t38 = sext i32 %t36 to i64
  store i64 %t38, ptr %l14, !tbaa !24
  br label %bb17
bb12:
  br i1 true, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  store i64 -1, ptr %l14, !tbaa !24
  br label %bb17
bb16:
  call void @__olang_check_failed(ptr @olang_loc_a2056f25c62d9699_4e0d363d21cfeded)
  unreachable
bb17:
  %t40 = load i64, ptr %l14, !tbaa !24
  store i64 %t40, ptr %l4, !tbaa !24
  %t41 = load i64, ptr %l4, !tbaa !24
  %t43 = icmp slt i64 %t41, 0
  br i1 %t43, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l26, !tbaa !21
  br label %bb20
bb19:
  %t45 = load i64, ptr %l4, !tbaa !24
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/lower:lowering", ptr %t46, i32 0, i32 38
  %t49 = load ptr, ptr %t48, !tbaa !29
  %t51 = getelementptr %"compiler/typed:Plan", ptr %t49, i32 0, i32 0
  %t52 = load { i64, ptr }, ptr %t51, !tbaa !27
  %t54 = extractvalue { i64, ptr } %t52, 0
  %t57 = icmp sge i64 %t45, %t54
  store i1 %t57, ptr %l26, !tbaa !21
  br label %bb20
bb20:
  %t59 = load i1, ptr %l26, !tbaa !21
  br i1 %t59, label %bb21, label %bb22
bb21:
  %t60 = load { i64, [1 x i64] }, ptr %l2
  store { i64, [1 x i64] } %t60, ptr %rv
  br label %ret
bb22:
  br label %bb23
bb23:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/lower:lowering", ptr %t62, i32 0, i32 38
  %t65 = load ptr, ptr %t64, !tbaa !29
  %t67 = getelementptr %"compiler/typed:Plan", ptr %t65, i32 0, i32 0
  %t68 = load { i64, ptr }, ptr %t67, !tbaa !27
  store { i64, ptr } %t68, ptr %l36, !tbaa !27
  %t69 = load i64, ptr %l4, !tbaa !24
  %t71 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t72 = load ptr, ptr %t71, !tbaa !27
  %t73 = getelementptr { i64, [2 x i64] }, ptr %t72, i64 %t69
  %t74 = load { i64, [2 x i64] }, ptr %t73
  %t78 = extractvalue { i64, [2 x i64] } %t74, 0
  %t79 = icmp eq i64 %t78, 4
  br i1 %t79, label %bb24, label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb28
bb26:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t82 = load i64, ptr %l4, !tbaa !24
  %t84 = trunc i64 %t82 to i32
  %t88 = call { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2emadeAt(ptr %v0, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %t81, i32 %t84)
  store { i64, [1 x i64] } %t88, ptr %l46
  br label %bb27
bb27:
  %t89 = load { i64, [1 x i64] }, ptr %l46
  store { i64, [1 x i64] } %t89, ptr %l39
  br label %bb33
bb28:
  br i1 true, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb32
bb31:
  %t90 = load { i64, [1 x i64] }, ptr %l2
  store { i64, [1 x i64] } %t90, ptr %l39
  br label %bb33
bb32:
  call void @__olang_check_failed(ptr @olang_loc_cc04a371857641c8_2543c621c9fde23c)
  unreachable
bb33:
  %t92 = load { i64, [1 x i64] }, ptr %l39
  store { i64, [1 x i64] } %t92, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [1 x i64] }, ptr %rv
  ret { i64, [1 x i64] } %rr
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3alowering_2ewidens(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l6 = alloca i1
  %l7 = alloca ptr
  %l8 = alloca i1
  %l21 = alloca i1
  %l22 = alloca ptr
  %l23 = alloca i1
  %rv = alloca i1
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l7, !tbaa !29
  store i1 false, ptr %l8, !tbaa !21
  %t2 = load ptr, ptr %l7, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l7, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 9
  store i1 %t8, ptr %l8, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l8, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l3, !tbaa !23
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t18, i32 0, i32 2
  %t20 = load i32, ptr %t19, !range !{i32 0, i32 54}
  store i32 %t20, ptr %l4
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t24 = getelementptr { i64, [5 x i64] }, ptr %t22, i32 0, i32 1
  %t25 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t24, i32 0, i32 4
  %t26 = load { i64, ptr }, ptr %t25
  store { i64, ptr } %t26, ptr %l5, !tbaa !27
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t29 = load i32, ptr %l4, !range !{i32 0, i32 54}
  %t30 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t31 = load i32, ptr %l3, !tbaa !23
  %t36 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2ewidening(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %t29, { i64, ptr } %t30, i32 %t31)
  store i1 %t36, ptr %l21
  br label %bb6
bb6:
  %t37 = load i1, ptr %l21, !tbaa !21
  store i1 %t37, ptr %l6, !tbaa !21
  br label %bb18
bb7:
  %t38 = load ptr, ptr %l1, !tbaa !29
  store ptr %t38, ptr %l22, !tbaa !29
  store i1 false, ptr %l23, !tbaa !21
  %t39 = load ptr, ptr %l22, !tbaa !29
  %t40 = icmp ne ptr %t39, null
  br i1 %t40, label %bb8, label %bb9
bb8:
  %t42 = load ptr, ptr %l22, !tbaa !29
  %t43 = load i64, ptr %t42, !range !{i64 0, i64 18}
  %t45 = icmp eq i64 %t43, 17
  store i1 %t45, ptr %l23, !tbaa !21
  br label %bb9
bb9:
  %t46 = load i1, ptr %l23, !tbaa !21
  br i1 %t46, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb13
bb12:
  store i1 false, ptr %l6, !tbaa !21
  br label %bb18
bb13:
  br i1 true, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb17
bb16:
  store i1 false, ptr %l6, !tbaa !21
  br label %bb18
bb17:
  call void @__olang_check_failed(ptr @olang_loc_d2f9ab61c66bb7bd_ba20d4faed7cd6b1)
  unreachable
bb18:
  %t47 = load i1, ptr %l6, !tbaa !21
  store i1 %t47, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2ewith(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/lower:pl" %a1, { i64, [1 x i64] } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/lower:pl"
  %lp3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i64
  %l10 = alloca %"compiler/lower:pl"
  %l12 = alloca i64
  %l14 = alloca i64
  %l19 = alloca { i64, [1 x i64] }
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/lower:pl"
  store ptr %a0, ptr %l0
  store %"compiler/lower:pl" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = getelementptr %"compiler/lower:pl", ptr %l1, i32 0, i32 0
  %t2 = load { i64, [2 x i64] }, ptr %t1
  %t4 = call %"compiler/lower:pl" @compiler_2flower_3apl_2ector(ptr %v2, { i64, [2 x i64] } %t2)
  store %"compiler/lower:pl" %t4, ptr %l10
  br label %bb1
bb1:
  %t5 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 72, i64 8)
  store ptr %t5, ptr %lp3
  %t6 = load %"compiler/lower:pl", ptr %l10
  %t7 = load ptr, ptr %lp3
  store %"compiler/lower:pl" %t6, ptr %t7
  %t8 = getelementptr %"compiler/lower:pl", ptr %l1, i32 0, i32 1
  store ptr %t8, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  %t10 = load i64, ptr %l5, !tbaa !24
  store i64 %t10, ptr %l12, !tbaa !24
  %t11 = load ptr, ptr %l4, !tbaa !29
  %t13 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aProj_3e_2eLen_3ccompiler_2fmir_3aProj_3e(ptr %s0, ptr %t11)
  store i64 %t13, ptr %l14
  br label %bb3
bb3:
  %t14 = load i64, ptr %l12, !tbaa !24
  %t15 = load i64, ptr %l14, !tbaa !24
  %t16 = icmp slt i64 %t14, %t15
  %t18 = xor i1 %t16, true
  br i1 %t18, label %bb4, label %bb5
bb4:
  br label %bb10
bb5:
  br label %bb6
bb6:
  %t20 = load ptr, ptr %l4, !tbaa !29
  %t21 = load i64, ptr %l5, !tbaa !24
  %t24 = call { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aProj_3e_2eAt_3ccompiler_2fmir_3aProj_3e(ptr %s0, ptr %t20, i64 %t21)
  store { i64, [1 x i64] } %t24, ptr %l19
  br label %bb7
bb7:
  %t25 = load { i64, [1 x i64] }, ptr %l19
  %t26 = load ptr, ptr %lp3
  %t27 = getelementptr %"compiler/lower:pl", ptr %t26, i32 0, i32 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aProj_3e_2ePush_3ccompiler_2fmir_3aProj_3e(ptr %v2, ptr %t27, { i64, [1 x i64] } %t25)
  br label %bb8
bb8:
  br label %bb9
bb9:
  %t31 = load i64, ptr %l5, !tbaa !24
  %t34 = add i64 %t31, 1
  store i64 %t34, ptr %l5, !tbaa !24
  br label %bb2
bb10:
  %t36 = load ptr, ptr %lp3
  %t37 = getelementptr %"compiler/lower:pl", ptr %t36, i32 0, i32 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aProj_3e_2ePush_3ccompiler_2fmir_3aProj_3e(ptr %v2, ptr %t37, { i64, [1 x i64] } %a2)
  br label %bb11
bb11:
  %t41 = getelementptr %"compiler/lower:pl", ptr %l1, i32 0, i32 2
  %t42 = load i64, ptr %t41, !tbaa !24
  %t44 = getelementptr %"compiler/lower:pl", ptr %l1, i32 0, i32 3
  %t45 = load i32, ptr %t44, !tbaa !23
  %t49 = load ptr, ptr %lp3
  %t50 = getelementptr %"compiler/lower:pl", ptr %t49, i32 0, i32 2
  store i64 %t42, ptr %t50, !tbaa !24
  %t53 = load ptr, ptr %lp3
  %t54 = getelementptr %"compiler/lower:pl", ptr %t53, i32 0, i32 3
  store i32 %t45, ptr %t54, !tbaa !23
  %t55 = load ptr, ptr %lp3
  %t56 = load %"compiler/lower:pl", ptr %t55
  call void @__olang_scope_close(ptr %s0)
  store %"compiler/lower:pl" %t56, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/lower:pl", ptr %rv
  ret %"compiler/lower:pl" %rr
}

define dso_local ptr @compiler_2flower_2econdOf(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i1
  %l13 = alloca ptr
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  store i1 false, ptr %l4, !tbaa !21
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 11
  store i1 %t8, ptr %l4, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l4, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb9
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr %"compiler/typed:Cond", ptr %t16, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t21 = icmp eq ptr %t19, null
  %t23 = xor i1 %t21, true
  br i1 %t23, label %bb6, label %bb7
bb6:
  %t25 = load ptr, ptr %l1, !tbaa !29
  store ptr %t25, ptr %l13, !tbaa !29
  br label %bb8
bb7:
  store ptr null, ptr %l13, !tbaa !29
  br label %bb8
bb8:
  %t28 = load ptr, ptr %l13, !tbaa !29
  store ptr %t28, ptr %l2, !tbaa !29
  br label %bb14
bb9:
  br i1 true, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb13
bb12:
  store ptr null, ptr %l2, !tbaa !29
  br label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_675153e339d777fd_a8094ea479968611)
  unreachable
bb14:
  %t29 = load ptr, ptr %l2, !tbaa !29
  store ptr %t29, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2flower_2econvertArg(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i1
  %l9 = alloca { i64, ptr }
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  store i1 false, ptr %l4, !tbaa !21
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 9
  store i1 %t8, ptr %l4, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l4, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t12, i32 0, i32 4
  %t14 = load { i64, ptr }, ptr %t13
  store { i64, ptr } %t14, ptr %l1, !tbaa !27
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t16, ptr %l9, !tbaa !27
  %t17 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t18 = load ptr, ptr %t17, !tbaa !27
  %t19 = getelementptr ptr, ptr %t18, i64 0
  %t20 = load ptr, ptr %t19, !tbaa !39
  store ptr %t20, ptr %l2, !tbaa !29
  br label %bb11
bb6:
  br i1 true, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  %t22 = load ptr, ptr %l0, !tbaa !29
  store ptr %t22, ptr %l2, !tbaa !29
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_e6acc166178563a1_2a0e2f77fd7658ed)
  unreachable
bb11:
  %t24 = load ptr, ptr %l2, !tbaa !29
  store ptr %t24, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2flower_2ederefOf(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i1
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca i1
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb17
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  store ptr %t16, ptr %l11, !tbaa !29
  store i1 false, ptr %l12, !tbaa !21
  %t17 = load ptr, ptr %l11, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb6, label %bb7
bb6:
  %t20 = load ptr, ptr %l11, !tbaa !29
  %t21 = load i64, ptr %t20, !range !{i64 0, i64 8}
  %t23 = icmp eq i64 %t21, 2
  store i1 %t23, ptr %l12, !tbaa !21
  br label %bb7
bb7:
  %t24 = load i1, ptr %l12, !tbaa !21
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr { i64, [4 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t27, i32 0, i32 2
  %t29 = load ptr, ptr %t28
  store ptr %t29, ptr %l2, !tbaa !29
  br label %bb10
bb9:
  br label %bb11
bb10:
  %t31 = load ptr, ptr %l2, !tbaa !29
  store ptr %t31, ptr %l10, !tbaa !29
  br label %bb16
bb11:
  br i1 true, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  store ptr null, ptr %l10, !tbaa !29
  br label %bb16
bb15:
  call void @__olang_check_failed(ptr @olang_loc_eebb62a013643219_b45f662b48cacfad)
  unreachable
bb16:
  %t34 = load ptr, ptr %l10, !tbaa !29
  store ptr %t34, ptr %l3, !tbaa !29
  br label %bb22
bb17:
  br i1 true, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb21
bb20:
  store ptr null, ptr %l3, !tbaa !29
  br label %bb22
bb21:
  call void @__olang_check_failed(ptr @olang_loc_18ba96ebd2acdd48_1f3e7581818ceffc)
  unreachable
bb22:
  %t35 = load ptr, ptr %l3, !tbaa !29
  store ptr %t35, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i64 @compiler_2flower_2eindexOf(ptr %v0, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a0, i32 %a1) #0 {
entry:
  %l0 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l9 = alloca i64
  %l13 = alloca i64
  %l16 = alloca i64
  %l36 = alloca i32
  %rv = alloca i64
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l2, !tbaa !24
  %t2 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %l0)
  store i64 %t2, ptr %l9
  br label %bb1
bb1:
  %t3 = load i64, ptr %l9, !tbaa !24
  store i64 %t3, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t4 = load i64, ptr %l3, !tbaa !24
  %t5 = load i64, ptr %l2, !tbaa !24
  %t8 = icmp sgt i64 %t4, %t5
  br i1 %t8, label %bb2, label %bb3
bb2:
  %t10 = load i64, ptr %l4, !tbaa !24
  %t12 = icmp sgt i64 %t10, 0
  br i1 %t12, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l13, !tbaa !24
  br label %bb7
bb4:
  %t14 = load i64, ptr %l3, !tbaa !24
  %t15 = load i64, ptr %l2, !tbaa !24
  %t18 = sub i64 %t14, %t15
  %t19 = load i64, ptr %l4, !tbaa !24
  %t22 = add i64 %t18, %t19
  %t24 = sub i64 %t22, 1
  %t25 = load i64, ptr %l4, !tbaa !24
  %t28 = sdiv i64 %t24, %t25
  store i64 %t28, ptr %l16, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l16, !tbaa !24
  br label %bb6
bb6:
  %t30 = load i64, ptr %l16, !tbaa !24
  store i64 %t30, ptr %l13, !tbaa !24
  br label %bb7
bb7:
  %t31 = load i64, ptr %l13, !tbaa !24
  store i64 %t31, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb8
bb8:
  %t32 = load i64, ptr %l6, !tbaa !24
  %t33 = load i64, ptr %l5, !tbaa !24
  %t36 = icmp slt i64 %t32, %t33
  %t38 = xor i1 %t36, true
  br i1 %t38, label %bb9, label %bb10
bb9:
  br label %bb17
bb10:
  br label %bb11
bb11:
  %t40 = load i64, ptr %l2, !tbaa !24
  %t41 = load i64, ptr %l6, !tbaa !24
  %t42 = load i64, ptr %l4, !tbaa !24
  %t45 = mul i64 %t41, %t42
  %t48 = add i64 %t40, %t45
  store i64 %t48, ptr %l7, !tbaa !24
  %t50 = load i64, ptr %l7, !tbaa !24
  %t53 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %l0, i64 %t50)
  store i32 %t53, ptr %l36
  br label %bb12
bb12:
  %t55 = load i32, ptr %l36, !tbaa !23
  %t57 = icmp eq i32 %t55, %a1
  br i1 %t57, label %bb13, label %bb14
bb13:
  %t59 = load i64, ptr %l7, !tbaa !24
  store i64 %t59, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  br label %bb16
bb16:
  %t61 = load i64, ptr %l6, !tbaa !24
  %t64 = add i64 %t61, 1
  store i64 %t64, ptr %l6, !tbaa !24
  br label %bb8
bb17:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2flower_2eplainAll(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l12 = alloca { i64, ptr }
  %l17 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a0, ptr %l1, !tbaa !27
  store i64 0, ptr %l2, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  %t7 = load i64, ptr %l2, !tbaa !24
  %t8 = load i64, ptr %l3, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  br label %bb10
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t15, ptr %l12, !tbaa !27
  %t16 = load i64, ptr %l2, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr ptr, ptr %t19, i64 %t16
  %t21 = load ptr, ptr %t20, !tbaa !39
  %t26 = call i1 @compiler_2flower_2eplainValue(ptr %v0, ptr %t21)
  store i1 %t26, ptr %l17
  br label %bb5
bb5:
  %t27 = load i1, ptr %l17, !tbaa !21
  %t28 = xor i1 %t27, true
  br i1 %t28, label %bb6, label %bb7
bb6:
  store i1 false, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  br label %bb9
bb9:
  %t31 = load i64, ptr %l2, !tbaa !24
  %t34 = add i64 %t31, 1
  store i64 %t34, ptr %l2, !tbaa !24
  br label %bb1
bb10:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2flower_2eplainPlace(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i1
  %l5 = alloca ptr
  %l6 = alloca i1
  %l9 = alloca ptr
  %l10 = alloca i1
  %l13 = alloca ptr
  %l14 = alloca i1
  %l17 = alloca ptr
  %l18 = alloca i1
  %l25 = alloca i1
  %l26 = alloca ptr
  %l27 = alloca i1
  %l33 = alloca i1
  %l34 = alloca ptr
  %l35 = alloca i1
  %l44 = alloca i1
  %l47 = alloca i1
  %l48 = alloca i1
  %l52 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb13
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l9, !tbaa !29
  store i1 false, ptr %l10, !tbaa !21
  %t11 = load ptr, ptr %l9, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb5, label %bb6
bb5:
  %t14 = load ptr, ptr %l9, !tbaa !29
  %t15 = load i64, ptr %t14, !range !{i64 0, i64 8}
  %t17 = icmp eq i64 %t15, 1
  store i1 %t17, ptr %l10, !tbaa !21
  br label %bb6
bb6:
  %t18 = load i1, ptr %l10, !tbaa !21
  br i1 %t18, label %bb7, label %bb8
bb7:
  br label %bb13
bb8:
  %t19 = load ptr, ptr %l0, !tbaa !29
  store ptr %t19, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t20 = load ptr, ptr %l13, !tbaa !29
  %t21 = icmp ne ptr %t20, null
  br i1 %t21, label %bb9, label %bb10
bb9:
  %t23 = load ptr, ptr %l13, !tbaa !29
  %t24 = load i64, ptr %t23, !range !{i64 0, i64 8}
  %t26 = icmp eq i64 %t24, 7
  store i1 %t26, ptr %l14, !tbaa !21
  br label %bb10
bb10:
  %t27 = load i1, ptr %l14, !tbaa !21
  br i1 %t27, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb14
bb13:
  store i1 true, ptr %l4, !tbaa !21
  br label %bb47
bb14:
  %t28 = load ptr, ptr %l0, !tbaa !29
  store ptr %t28, ptr %l17, !tbaa !29
  store i1 false, ptr %l18, !tbaa !21
  %t29 = load ptr, ptr %l17, !tbaa !29
  %t30 = icmp ne ptr %t29, null
  br i1 %t30, label %bb15, label %bb16
bb15:
  %t32 = load ptr, ptr %l17, !tbaa !29
  %t33 = load i64, ptr %t32, !range !{i64 0, i64 8}
  %t35 = icmp eq i64 %t33, 2
  store i1 %t35, ptr %l18, !tbaa !21
  br label %bb16
bb16:
  %t36 = load i1, ptr %l18, !tbaa !21
  br i1 %t36, label %bb17, label %bb18
bb17:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr { i64, [4 x i64] }, ptr %t37, i32 0, i32 1
  %t40 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t39, i32 0, i32 2
  %t41 = load ptr, ptr %t40
  store ptr %t41, ptr %l1, !tbaa !29
  br label %bb19
bb18:
  br label %bb21
bb19:
  %t43 = load ptr, ptr %l1, !tbaa !29
  %t46 = call i1 @compiler_2flower_2eplainValue(ptr %v0, ptr %t43)
  store i1 %t46, ptr %l25
  br label %bb20
bb20:
  %t47 = load i1, ptr %l25, !tbaa !21
  store i1 %t47, ptr %l4, !tbaa !21
  br label %bb47
bb21:
  %t48 = load ptr, ptr %l0, !tbaa !29
  store ptr %t48, ptr %l26, !tbaa !29
  store i1 false, ptr %l27, !tbaa !21
  %t49 = load ptr, ptr %l26, !tbaa !29
  %t50 = icmp ne ptr %t49, null
  br i1 %t50, label %bb22, label %bb23
bb22:
  %t52 = load ptr, ptr %l26, !tbaa !29
  %t53 = load i64, ptr %t52, !range !{i64 0, i64 8}
  %t55 = icmp eq i64 %t53, 3
  store i1 %t55, ptr %l27, !tbaa !21
  br label %bb23
bb23:
  %t56 = load i1, ptr %l27, !tbaa !21
  br i1 %t56, label %bb24, label %bb25
bb24:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr { i64, [4 x i64] }, ptr %t57, i32 0, i32 1
  %t60 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t59, i32 0, i32 2
  %t61 = load ptr, ptr %t60
  store ptr %t61, ptr %l2, !tbaa !29
  br label %bb26
bb25:
  br label %bb28
bb26:
  %t63 = load ptr, ptr %l2, !tbaa !29
  %t65 = call i1 @compiler_2flower_2eplainPlace(ptr %v0, ptr %t63)
  store i1 %t65, ptr %l33
  br label %bb27
bb27:
  %t66 = load i1, ptr %l33, !tbaa !21
  store i1 %t66, ptr %l4, !tbaa !21
  br label %bb47
bb28:
  %t67 = load ptr, ptr %l0, !tbaa !29
  store ptr %t67, ptr %l34, !tbaa !29
  store i1 false, ptr %l35, !tbaa !21
  %t68 = load ptr, ptr %l34, !tbaa !29
  %t69 = icmp ne ptr %t68, null
  br i1 %t69, label %bb29, label %bb30
bb29:
  %t71 = load ptr, ptr %l34, !tbaa !29
  %t72 = load i64, ptr %t71, !range !{i64 0, i64 8}
  %t74 = icmp eq i64 %t72, 4
  store i1 %t74, ptr %l35, !tbaa !21
  br label %bb30
bb30:
  %t75 = load i1, ptr %l35, !tbaa !21
  br i1 %t75, label %bb31, label %bb32
bb31:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr { i64, [4 x i64] }, ptr %t76, i32 0, i32 1
  %t79 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t78, i32 0, i32 2
  %t80 = load ptr, ptr %t79
  store ptr %t80, ptr %l3, !tbaa !29
  br label %bb33
bb32:
  br label %bb42
bb33:
  %t82 = load ptr, ptr %l3, !tbaa !29
  %t84 = getelementptr %"compiler/typed:Elem", ptr %t82, i32 0, i32 2
  %t85 = load i32, ptr %t84, !range !{i32 0, i32 4}
  %t87 = trunc i64 2 to i32
  %t88 = icmp eq i32 %t85, %t87
  %t90 = xor i1 %t88, true
  br i1 %t90, label %bb34, label %bb35
bb34:
  %t92 = load ptr, ptr %l3, !tbaa !29
  %t94 = getelementptr %"compiler/typed:Elem", ptr %t92, i32 0, i32 0
  %t95 = load ptr, ptr %t94, !tbaa !29
  %t97 = call i1 @compiler_2flower_2eplainPlace(ptr %v0, ptr %t95)
  store i1 %t97, ptr %l47
  br label %bb36
bb35:
  store i1 false, ptr %l44, !tbaa !21
  br label %bb37
bb36:
  %t98 = load i1, ptr %l47, !tbaa !21
  store i1 %t98, ptr %l44, !tbaa !21
  br label %bb37
bb37:
  %t99 = load i1, ptr %l44, !tbaa !21
  br i1 %t99, label %bb38, label %bb39
bb38:
  %t100 = load ptr, ptr %l3, !tbaa !29
  %t102 = getelementptr %"compiler/typed:Elem", ptr %t100, i32 0, i32 1
  %t103 = load ptr, ptr %t102, !tbaa !29
  %t106 = call i1 @compiler_2flower_2eplainValue(ptr %v0, ptr %t103)
  store i1 %t106, ptr %l52
  br label %bb40
bb39:
  store i1 false, ptr %l48, !tbaa !21
  br label %bb41
bb40:
  %t107 = load i1, ptr %l52, !tbaa !21
  store i1 %t107, ptr %l48, !tbaa !21
  br label %bb41
bb41:
  %t108 = load i1, ptr %l48, !tbaa !21
  store i1 %t108, ptr %l4, !tbaa !21
  br label %bb47
bb42:
  br i1 true, label %bb43, label %bb44
bb43:
  br label %bb45
bb44:
  br label %bb46
bb45:
  store i1 false, ptr %l4, !tbaa !21
  br label %bb47
bb46:
  call void @__olang_check_failed(ptr @olang_loc_bb766f14be0b137b_665f548b94f1b77)
  unreachable
bb47:
  %t109 = load i1, ptr %l4, !tbaa !21
  store i1 %t109, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2flower_2eplainValue(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l9 = alloca i1
  %l10 = alloca ptr
  %l11 = alloca i1
  %l14 = alloca ptr
  %l15 = alloca i1
  %l21 = alloca i1
  %l22 = alloca ptr
  %l23 = alloca i1
  %l35 = alloca i1
  %l37 = alloca i1
  %l38 = alloca i1
  %l40 = alloca i1
  %l41 = alloca ptr
  %l42 = alloca i1
  %l50 = alloca i1
  %l51 = alloca i1
  %l54 = alloca i1
  %l55 = alloca i1
  %l59 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  store ptr %t6, ptr %l10, !tbaa !29
  store i1 false, ptr %l11, !tbaa !21
  %t7 = load ptr, ptr %l10, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb4, label %bb5
bb4:
  %t10 = load ptr, ptr %l10, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 18}
  %t13 = icmp eq i64 %t11, 0
  store i1 %t13, ptr %l11, !tbaa !21
  br label %bb5
bb5:
  %t14 = load i1, ptr %l11, !tbaa !21
  br i1 %t14, label %bb6, label %bb7
bb6:
  br label %bb8
bb7:
  br label %bb9
bb8:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb50
bb9:
  %t15 = load ptr, ptr %l0, !tbaa !29
  store ptr %t15, ptr %l14, !tbaa !29
  store i1 false, ptr %l15, !tbaa !21
  %t16 = load ptr, ptr %l14, !tbaa !29
  %t17 = icmp ne ptr %t16, null
  br i1 %t17, label %bb10, label %bb11
bb10:
  %t19 = load ptr, ptr %l14, !tbaa !29
  %t20 = load i64, ptr %t19, !range !{i64 0, i64 18}
  %t22 = icmp eq i64 %t20, 2
  store i1 %t22, ptr %l15, !tbaa !21
  br label %bb11
bb11:
  %t23 = load i1, ptr %l15, !tbaa !21
  br i1 %t23, label %bb12, label %bb13
bb12:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr { i64, [5 x i64] }, ptr %t24, i32 0, i32 1
  %t27 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t26, i32 0, i32 2
  %t28 = load ptr, ptr %t27
  store ptr %t28, ptr %l1, !tbaa !29
  br label %bb14
bb13:
  br label %bb16
bb14:
  %t30 = load ptr, ptr %l1, !tbaa !29
  %t32 = call i1 @compiler_2flower_2eplainPlace(ptr %v0, ptr %t30)
  store i1 %t32, ptr %l21
  br label %bb15
bb15:
  %t33 = load i1, ptr %l21, !tbaa !21
  store i1 %t33, ptr %l9, !tbaa !21
  br label %bb50
bb16:
  %t34 = load ptr, ptr %l0, !tbaa !29
  store ptr %t34, ptr %l22, !tbaa !29
  store i1 false, ptr %l23, !tbaa !21
  %t35 = load ptr, ptr %l22, !tbaa !29
  %t36 = icmp ne ptr %t35, null
  br i1 %t36, label %bb17, label %bb18
bb17:
  %t38 = load ptr, ptr %l22, !tbaa !29
  %t39 = load i64, ptr %t38, !range !{i64 0, i64 18}
  %t41 = icmp eq i64 %t39, 9
  store i1 %t41, ptr %l23, !tbaa !21
  br label %bb18
bb18:
  %t42 = load i1, ptr %l23, !tbaa !21
  br i1 %t42, label %bb19, label %bb20
bb19:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr { i64, [5 x i64] }, ptr %t43, i32 0, i32 1
  %t46 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t45, i32 0, i32 2
  %t47 = load i32, ptr %t46, !range !{i32 0, i32 54}
  store i32 %t47, ptr %l2
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr { i64, [5 x i64] }, ptr %t49, i32 0, i32 1
  %t52 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t51, i32 0, i32 3
  %t53 = load i32, ptr %t52, !range !{i32 0, i32 4}
  store i32 %t53, ptr %l3
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr { i64, [5 x i64] }, ptr %t55, i32 0, i32 1
  %t58 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t57, i32 0, i32 4
  %t59 = load { i64, ptr }, ptr %t58
  store { i64, ptr } %t59, ptr %l4, !tbaa !27
  br label %bb21
bb20:
  br label %bb30
bb21:
  %t61 = load i32, ptr %l3, !range !{i32 0, i32 4}
  %t63 = trunc i64 2 to i32
  %t64 = icmp eq i32 %t61, %t63
  %t66 = xor i1 %t64, true
  br i1 %t66, label %bb22, label %bb23
bb22:
  %t68 = load i32, ptr %l2, !range !{i32 0, i32 54}
  %t70 = call i1 @compiler_2flower_2eplainOp(i32 %t68)
  store i1 %t70, ptr %l37
  br label %bb24
bb23:
  store i1 false, ptr %l35, !tbaa !21
  br label %bb25
bb24:
  %t71 = load i1, ptr %l37, !tbaa !21
  store i1 %t71, ptr %l35, !tbaa !21
  br label %bb25
bb25:
  %t72 = load i1, ptr %l35, !tbaa !21
  br i1 %t72, label %bb26, label %bb27
bb26:
  %t73 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t75 = call i1 @compiler_2flower_2eplainAll(ptr %v0, { i64, ptr } %t73)
  store i1 %t75, ptr %l40
  br label %bb28
bb27:
  store i1 false, ptr %l38, !tbaa !21
  br label %bb29
bb28:
  %t76 = load i1, ptr %l40, !tbaa !21
  store i1 %t76, ptr %l38, !tbaa !21
  br label %bb29
bb29:
  %t77 = load i1, ptr %l38, !tbaa !21
  store i1 %t77, ptr %l9, !tbaa !21
  br label %bb50
bb30:
  %t78 = load ptr, ptr %l0, !tbaa !29
  store ptr %t78, ptr %l41, !tbaa !29
  store i1 false, ptr %l42, !tbaa !21
  %t79 = load ptr, ptr %l41, !tbaa !29
  %t80 = icmp ne ptr %t79, null
  br i1 %t80, label %bb31, label %bb32
bb31:
  %t82 = load ptr, ptr %l41, !tbaa !29
  %t83 = load i64, ptr %t82, !range !{i64 0, i64 18}
  %t85 = icmp eq i64 %t83, 11
  store i1 %t85, ptr %l42, !tbaa !21
  br label %bb32
bb32:
  %t86 = load i1, ptr %l42, !tbaa !21
  br i1 %t86, label %bb33, label %bb34
bb33:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr { i64, [5 x i64] }, ptr %t87, i32 0, i32 1
  %t90 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t89, i32 0, i32 2
  %t91 = load ptr, ptr %t90
  store ptr %t91, ptr %l5, !tbaa !29
  br label %bb35
bb34:
  br label %bb45
bb35:
  %t93 = load ptr, ptr %l5, !tbaa !29
  %t95 = getelementptr %"compiler/typed:Cond", ptr %t93, i32 0, i32 0
  %t96 = load ptr, ptr %t95, !tbaa !29
  %t99 = call i1 @compiler_2flower_2eplainValue(ptr %v0, ptr %t96)
  store i1 %t99, ptr %l50
  br label %bb36
bb36:
  %t100 = load i1, ptr %l50, !tbaa !21
  br i1 %t100, label %bb37, label %bb38
bb37:
  %t101 = load ptr, ptr %l5, !tbaa !29
  %t103 = getelementptr %"compiler/typed:Cond", ptr %t101, i32 0, i32 1
  %t104 = load ptr, ptr %t103, !tbaa !29
  %t106 = call i1 @compiler_2flower_2eplainValue(ptr %v0, ptr %t104)
  store i1 %t106, ptr %l54
  br label %bb39
bb38:
  store i1 false, ptr %l51, !tbaa !21
  br label %bb40
bb39:
  %t107 = load i1, ptr %l54, !tbaa !21
  store i1 %t107, ptr %l51, !tbaa !21
  br label %bb40
bb40:
  %t108 = load i1, ptr %l51, !tbaa !21
  br i1 %t108, label %bb41, label %bb42
bb41:
  %t109 = load ptr, ptr %l5, !tbaa !29
  %t111 = getelementptr %"compiler/typed:Cond", ptr %t109, i32 0, i32 2
  %t112 = load ptr, ptr %t111, !tbaa !29
  %t115 = call i1 @compiler_2flower_2eplainValue(ptr %v0, ptr %t112)
  store i1 %t115, ptr %l59
  br label %bb43
bb42:
  store i1 false, ptr %l55, !tbaa !21
  br label %bb44
bb43:
  %t116 = load i1, ptr %l59, !tbaa !21
  store i1 %t116, ptr %l55, !tbaa !21
  br label %bb44
bb44:
  %t117 = load i1, ptr %l55, !tbaa !21
  store i1 %t117, ptr %l9, !tbaa !21
  br label %bb50
bb45:
  br i1 true, label %bb46, label %bb47
bb46:
  br label %bb48
bb47:
  br label %bb49
bb48:
  store i1 false, ptr %l9, !tbaa !21
  br label %bb50
bb49:
  call void @__olang_check_failed(ptr @olang_loc_2e98307d074351d_b88ce24c70947f99)
  unreachable
bb50:
  %t118 = load i1, ptr %l9, !tbaa !21
  store i1 %t118, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2flower_2ereadLocal(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca i1
  %l11 = alloca i1
  %l13 = alloca ptr
  %l14 = alloca i1
  %l22 = alloca ptr
  %l23 = alloca i1
  %l31 = alloca i1
  %l36 = alloca i64
  %l38 = alloca { i64, ptr }
  %l40 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = call ptr @compiler_2flower_2eawayless(ptr %v0, ptr %s0, ptr %a0)
  store ptr %t3, ptr %l5
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l5, !tbaa !29
  store ptr %t4, ptr %l1, !tbaa !29
  %t5 = load ptr, ptr %l1, !tbaa !29
  store ptr %t5, ptr %l7, !tbaa !29
  store i1 false, ptr %l8, !tbaa !21
  %t6 = load ptr, ptr %l7, !tbaa !29
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %bb2, label %bb3
bb2:
  %t9 = load ptr, ptr %l7, !tbaa !29
  %t10 = load i64, ptr %t9, !range !{i64 0, i64 18}
  %t12 = icmp eq i64 %t10, 2
  store i1 %t12, ptr %l8, !tbaa !21
  br label %bb3
bb3:
  %t13 = load i1, ptr %l8, !tbaa !21
  br i1 %t13, label %bb4, label %bb5
bb4:
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t16 = getelementptr { i64, [5 x i64] }, ptr %t14, i32 0, i32 1
  %t17 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t16, i32 0, i32 2
  %t18 = load ptr, ptr %t17
  store ptr %t18, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t19 = load ptr, ptr %l13, !tbaa !29
  %t20 = icmp ne ptr %t19, null
  br i1 %t20, label %bb6, label %bb7
bb5:
  store i1 false, ptr %l11, !tbaa !21
  br label %bb8
bb6:
  %t22 = load ptr, ptr %l13, !tbaa !29
  %t23 = load i64, ptr %t22, !range !{i64 0, i64 8}
  %t25 = icmp eq i64 %t23, 0
  store i1 %t25, ptr %l14, !tbaa !21
  br label %bb7
bb7:
  %t26 = load i1, ptr %l14, !tbaa !21
  store i1 %t26, ptr %l11, !tbaa !21
  br label %bb8
bb8:
  %t27 = load i1, ptr %l11, !tbaa !21
  br i1 %t27, label %bb9, label %bb10
bb9:
  %t28 = load ptr, ptr %l1, !tbaa !29
  %t30 = getelementptr { i64, [5 x i64] }, ptr %t28, i32 0, i32 1
  %t31 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t30, i32 0, i32 2
  %t32 = load ptr, ptr %t31
  %t34 = getelementptr { i64, [4 x i64] }, ptr %t32, i32 0, i32 1
  %t35 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t34, i32 0, i32 2
  %t36 = load i32, ptr %t35
  store i32 %t36, ptr %l2, !tbaa !23
  br label %bb11
bb10:
  br label %bb12
bb11:
  %t38 = load i32, ptr %l2, !tbaa !23
  %t40 = sext i32 %t38 to i64
  store i64 %t40, ptr %l6, !tbaa !24
  br label %bb30
bb12:
  %t42 = load ptr, ptr %l1, !tbaa !29
  store ptr %t42, ptr %l22, !tbaa !29
  store i1 false, ptr %l23, !tbaa !21
  %t43 = load ptr, ptr %l22, !tbaa !29
  %t44 = icmp ne ptr %t43, null
  br i1 %t44, label %bb13, label %bb14
bb13:
  %t46 = load ptr, ptr %l22, !tbaa !29
  %t47 = load i64, ptr %t46, !range !{i64 0, i64 18}
  %t49 = icmp eq i64 %t47, 7
  store i1 %t49, ptr %l23, !tbaa !21
  br label %bb14
bb14:
  %t50 = load i1, ptr %l23, !tbaa !21
  br i1 %t50, label %bb15, label %bb16
bb15:
  %t51 = load ptr, ptr %l1, !tbaa !29
  %t53 = getelementptr { i64, [5 x i64] }, ptr %t51, i32 0, i32 1
  %t54 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t53, i32 0, i32 2
  %t55 = load ptr, ptr %t54
  store ptr %t55, ptr %l3, !tbaa !29
  br label %bb17
bb16:
  br label %bb25
bb17:
  %t57 = load ptr, ptr %l3, !tbaa !29
  %t59 = getelementptr %"compiler/typed:Make", ptr %t57, i32 0, i32 0
  %t60 = load i32, ptr %t59, !range !{i32 0, i32 5}
  %t62 = trunc i64 4 to i32
  %t63 = icmp eq i32 %t60, %t62
  br i1 %t63, label %bb18, label %bb19
bb18:
  %t65 = load ptr, ptr %l3, !tbaa !29
  %t67 = getelementptr %"compiler/typed:Make", ptr %t65, i32 0, i32 2
  %t68 = load { i64, ptr }, ptr %t67, !tbaa !27
  %t70 = extractvalue { i64, ptr } %t68, 0
  %t72 = icmp eq i64 %t70, 1
  store i1 %t72, ptr %l31, !tbaa !21
  br label %bb20
bb19:
  store i1 false, ptr %l31, !tbaa !21
  br label %bb20
bb20:
  %t74 = load i1, ptr %l31, !tbaa !21
  br i1 %t74, label %bb21, label %bb22
bb21:
  %t75 = load ptr, ptr %l3, !tbaa !29
  %t77 = getelementptr %"compiler/typed:Make", ptr %t75, i32 0, i32 2
  %t78 = load { i64, ptr }, ptr %t77, !tbaa !27
  store { i64, ptr } %t78, ptr %l38, !tbaa !27
  %t79 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !27
  %t81 = getelementptr ptr, ptr %t80, i64 0
  %t82 = load ptr, ptr %t81, !tbaa !39
  %t84 = call i64 @compiler_2flower_2ereadLocal(ptr %s0, ptr %t82)
  store i64 %t84, ptr %l40
  br label %bb23
bb22:
  store i64 -1, ptr %l36, !tbaa !24
  br label %bb24
bb23:
  %t85 = load i64, ptr %l40, !tbaa !24
  store i64 %t85, ptr %l36, !tbaa !24
  br label %bb24
bb24:
  %t86 = load i64, ptr %l36, !tbaa !24
  store i64 %t86, ptr %l6, !tbaa !24
  br label %bb30
bb25:
  br i1 true, label %bb26, label %bb27
bb26:
  br label %bb28
bb27:
  br label %bb29
bb28:
  store i64 -1, ptr %l6, !tbaa !24
  br label %bb30
bb29:
  call void @__olang_check_failed(ptr @olang_loc_54e0eac7d28a4e33_3ccdd5ae0a31662f)
  unreachable
bb30:
  call void @__olang_scope_close(ptr %s0)
  %t87 = load i64, ptr %l6, !tbaa !24
  store i64 %t87, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2flower_2ereadsAny(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l13 = alloca { i64, ptr }
  %l19 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a0, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = load i64, ptr %l4, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  br label %bb10
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t15, ptr %l13, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr ptr, ptr %t19, i64 %t16
  %t21 = load ptr, ptr %t20, !tbaa !39
  %t28 = call i1 @compiler_2flower_2ereadsPlace(ptr %v0, ptr %v1, ptr %t21, ptr %a1)
  store i1 %t28, ptr %l19
  br label %bb5
bb5:
  %t29 = load i1, ptr %l19, !tbaa !21
  br i1 %t29, label %bb6, label %bb7
bb6:
  store i1 true, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  br label %bb9
bb9:
  %t31 = load i64, ptr %l3, !tbaa !24
  %t34 = add i64 %t31, 1
  store i64 %t34, ptr %l3, !tbaa !24
  br label %bb1
bb10:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2flower_2esameLocal(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca i32
  %l7 = alloca %"compiler/source:Span"
  %l9 = alloca i64
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca %"compiler/source:Span"
  %l14 = alloca ptr
  %l15 = alloca i32
  %l16 = alloca %"compiler/source:Span"
  %l17 = alloca i32
  %l19 = alloca i32
  %l20 = alloca %"compiler/source:Span"
  %l21 = alloca i32
  %l22 = alloca ptr
  %l23 = alloca i32
  %l24 = alloca %"compiler/source:Span"
  %l25 = alloca i32
  %l27 = alloca i1
  %l28 = alloca ptr
  %l29 = alloca i1
  %l36 = alloca ptr
  %l37 = alloca i1
  %l40 = alloca i1
  %l50 = alloca i1
  %l60 = alloca ptr
  %l61 = alloca i1
  %l64 = alloca i1
  %l66 = alloca ptr
  %l67 = alloca i1
  %l75 = alloca ptr
  %l76 = alloca i1
  %l79 = alloca i1
  %l91 = alloca i1
  %l100 = alloca ptr
  %l101 = alloca i1
  %l104 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l28, !tbaa !29
  store i1 false, ptr %l29, !tbaa !21
  %t2 = load ptr, ptr %l28, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l28, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l29, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l29, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i64 }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, i64 }, ptr %t18, i32 0, i32 2
  %t20 = load i64, ptr %t19
  store i64 %t20, ptr %l3, !tbaa !24
  br label %bb5
bb4:
  br label %bb14
bb5:
  %t22 = load ptr, ptr %l1, !tbaa !29
  store ptr %t22, ptr %l36, !tbaa !29
  store i1 false, ptr %l37, !tbaa !21
  %t23 = load ptr, ptr %l36, !tbaa !29
  %t24 = icmp ne ptr %t23, null
  br i1 %t24, label %bb6, label %bb7
bb6:
  %t26 = load ptr, ptr %l36, !tbaa !29
  %t27 = load i64, ptr %t26, !range !{i64 0, i64 18}
  %t29 = icmp eq i64 %t27, 0
  store i1 %t29, ptr %l37, !tbaa !21
  br label %bb7
bb7:
  %t30 = load i1, ptr %l37, !tbaa !21
  br i1 %t30, label %bb8, label %bb9
bb8:
  %t31 = load ptr, ptr %l1, !tbaa !29
  %t33 = getelementptr { i64, [5 x i64] }, ptr %t31, i32 0, i32 1
  %t34 = getelementptr { %"compiler/source:Span", i32, i64 }, ptr %t33, i32 0, i32 0
  %t35 = load %"compiler/source:Span", ptr %t34
  store %"compiler/source:Span" %t35, ptr %l4
  %t37 = load ptr, ptr %l1, !tbaa !29
  %t39 = getelementptr { i64, [5 x i64] }, ptr %t37, i32 0, i32 1
  %t40 = getelementptr { %"compiler/source:Span", i32, i64 }, ptr %t39, i32 0, i32 1
  %t41 = load i32, ptr %t40
  store i32 %t41, ptr %l5, !tbaa !23
  %t43 = load ptr, ptr %l1, !tbaa !29
  %t45 = getelementptr { i64, [5 x i64] }, ptr %t43, i32 0, i32 1
  %t46 = getelementptr { %"compiler/source:Span", i32, i64 }, ptr %t45, i32 0, i32 2
  %t47 = load i64, ptr %t46
  %t50 = load i64, ptr %l3, !tbaa !24
  %t53 = icmp eq i64 %t47, %t50
  store i1 %t53, ptr %l40, !tbaa !21
  br label %bb10
bb9:
  store i1 false, ptr %l40, !tbaa !21
  br label %bb10
bb10:
  %t55 = load i1, ptr %l40, !tbaa !21
  br i1 %t55, label %bb11, label %bb12
bb11:
  %t56 = load ptr, ptr %l1, !tbaa !29
  %t58 = getelementptr { i64, [5 x i64] }, ptr %t56, i32 0, i32 1
  %t59 = getelementptr { %"compiler/source:Span", i32, i64 }, ptr %t58, i32 0, i32 0
  %t60 = load %"compiler/source:Span", ptr %t59
  store %"compiler/source:Span" %t60, ptr %l7
  %t62 = load ptr, ptr %l1, !tbaa !29
  %t64 = getelementptr { i64, [5 x i64] }, ptr %t62, i32 0, i32 1
  %t65 = getelementptr { %"compiler/source:Span", i32, i64 }, ptr %t64, i32 0, i32 1
  %t66 = load i32, ptr %t65
  %t68 = load ptr, ptr %l1, !tbaa !29
  %t70 = getelementptr { i64, [5 x i64] }, ptr %t68, i32 0, i32 1
  %t71 = getelementptr { %"compiler/source:Span", i32, i64 }, ptr %t70, i32 0, i32 2
  %t72 = load i64, ptr %t71
  store i64 %t72, ptr %l9, !tbaa !24
  %t75 = load i32, ptr %l2, !tbaa !23
  %t78 = icmp eq i32 %t66, %t75
  store i1 %t78, ptr %l50, !tbaa !21
  br label %bb13
bb12:
  store i1 false, ptr %l50, !tbaa !21
  br label %bb13
bb13:
  %t80 = load i1, ptr %l50, !tbaa !21
  store i1 %t80, ptr %l27, !tbaa !21
  br label %bb43
bb14:
  %t81 = load ptr, ptr %l0, !tbaa !29
  store ptr %t81, ptr %l60, !tbaa !29
  store i1 false, ptr %l61, !tbaa !21
  %t82 = load ptr, ptr %l60, !tbaa !29
  %t83 = icmp ne ptr %t82, null
  br i1 %t83, label %bb15, label %bb16
bb15:
  %t85 = load ptr, ptr %l60, !tbaa !29
  %t86 = load i64, ptr %t85, !range !{i64 0, i64 18}
  %t88 = icmp eq i64 %t86, 2
  store i1 %t88, ptr %l61, !tbaa !21
  br label %bb16
bb16:
  %t89 = load i1, ptr %l61, !tbaa !21
  br i1 %t89, label %bb17, label %bb18
bb17:
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t92 = getelementptr { i64, [5 x i64] }, ptr %t90, i32 0, i32 1
  %t93 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t92, i32 0, i32 2
  %t94 = load ptr, ptr %t93
  store ptr %t94, ptr %l66, !tbaa !29
  store i1 false, ptr %l67, !tbaa !21
  %t95 = load ptr, ptr %l66, !tbaa !29
  %t96 = icmp ne ptr %t95, null
  br i1 %t96, label %bb19, label %bb20
bb18:
  store i1 false, ptr %l64, !tbaa !21
  br label %bb21
bb19:
  %t98 = load ptr, ptr %l66, !tbaa !29
  %t99 = load i64, ptr %t98, !range !{i64 0, i64 8}
  %t101 = icmp eq i64 %t99, 0
  store i1 %t101, ptr %l67, !tbaa !21
  br label %bb20
bb20:
  %t102 = load i1, ptr %l67, !tbaa !21
  store i1 %t102, ptr %l64, !tbaa !21
  br label %bb21
bb21:
  %t103 = load i1, ptr %l64, !tbaa !21
  br i1 %t103, label %bb22, label %bb23
bb22:
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t106 = getelementptr { i64, [5 x i64] }, ptr %t104, i32 0, i32 1
  %t107 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t106, i32 0, i32 1
  %t108 = load i32, ptr %t107
  store i32 %t108, ptr %l10, !tbaa !23
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t112 = getelementptr { i64, [5 x i64] }, ptr %t110, i32 0, i32 1
  %t113 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t112, i32 0, i32 2
  %t114 = load ptr, ptr %t113
  %t116 = getelementptr { i64, [4 x i64] }, ptr %t114, i32 0, i32 1
  %t117 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t116, i32 0, i32 2
  %t118 = load i32, ptr %t117
  store i32 %t118, ptr %l11, !tbaa !23
  br label %bb24
bb23:
  br label %bb38
bb24:
  %t120 = load ptr, ptr %l1, !tbaa !29
  store ptr %t120, ptr %l75, !tbaa !29
  store i1 false, ptr %l76, !tbaa !21
  %t121 = load ptr, ptr %l75, !tbaa !29
  %t122 = icmp ne ptr %t121, null
  br i1 %t122, label %bb25, label %bb26
bb25:
  %t124 = load ptr, ptr %l75, !tbaa !29
  %t125 = load i64, ptr %t124, !range !{i64 0, i64 18}
  %t127 = icmp eq i64 %t125, 2
  store i1 %t127, ptr %l76, !tbaa !21
  br label %bb26
bb26:
  %t128 = load i1, ptr %l76, !tbaa !21
  br i1 %t128, label %bb27, label %bb28
bb27:
  %t129 = load ptr, ptr %l1, !tbaa !29
  %t131 = getelementptr { i64, [5 x i64] }, ptr %t129, i32 0, i32 1
  %t132 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t131, i32 0, i32 0
  %t133 = load %"compiler/source:Span", ptr %t132
  store %"compiler/source:Span" %t133, ptr %l12
  %t135 = load ptr, ptr %l1, !tbaa !29
  %t137 = getelementptr { i64, [5 x i64] }, ptr %t135, i32 0, i32 1
  %t138 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t137, i32 0, i32 1
  %t139 = load i32, ptr %t138
  %t141 = load ptr, ptr %l1, !tbaa !29
  %t143 = getelementptr { i64, [5 x i64] }, ptr %t141, i32 0, i32 1
  %t144 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t143, i32 0, i32 2
  %t145 = load ptr, ptr %t144
  store ptr %t145, ptr %l14, !tbaa !29
  %t147 = load ptr, ptr %l1, !tbaa !29
  %t149 = getelementptr { i64, [5 x i64] }, ptr %t147, i32 0, i32 1
  %t150 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t149, i32 0, i32 3
  %t151 = load i32, ptr %t150
  store i32 %t151, ptr %l15, !tbaa !23
  %t154 = load i32, ptr %l10, !tbaa !23
  %t157 = icmp eq i32 %t139, %t154
  store i1 %t157, ptr %l79, !tbaa !21
  br label %bb29
bb28:
  store i1 false, ptr %l79, !tbaa !21
  br label %bb29
bb29:
  %t159 = load i1, ptr %l79, !tbaa !21
  br i1 %t159, label %bb30, label %bb31
bb30:
  %t160 = load ptr, ptr %l1, !tbaa !29
  %t162 = getelementptr { i64, [5 x i64] }, ptr %t160, i32 0, i32 1
  %t163 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t162, i32 0, i32 0
  %t164 = load %"compiler/source:Span", ptr %t163
  store %"compiler/source:Span" %t164, ptr %l16
  %t166 = load ptr, ptr %l1, !tbaa !29
  %t168 = getelementptr { i64, [5 x i64] }, ptr %t166, i32 0, i32 1
  %t169 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t168, i32 0, i32 1
  %t170 = load i32, ptr %t169
  store i32 %t170, ptr %l17, !tbaa !23
  %t172 = load ptr, ptr %l1, !tbaa !29
  %t174 = getelementptr { i64, [5 x i64] }, ptr %t172, i32 0, i32 1
  %t175 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t174, i32 0, i32 2
  %t176 = load ptr, ptr %t175
  %t178 = load ptr, ptr %l1, !tbaa !29
  %t180 = getelementptr { i64, [5 x i64] }, ptr %t178, i32 0, i32 1
  %t181 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t180, i32 0, i32 3
  %t182 = load i32, ptr %t181
  store i32 %t182, ptr %l19, !tbaa !23
  store ptr %t176, ptr %l100, !tbaa !29
  store i1 false, ptr %l101, !tbaa !21
  %t185 = load ptr, ptr %l100, !tbaa !29
  %t186 = icmp ne ptr %t185, null
  br i1 %t186, label %bb32, label %bb33
bb31:
  store i1 false, ptr %l91, !tbaa !21
  br label %bb34
bb32:
  %t188 = load ptr, ptr %l100, !tbaa !29
  %t189 = load i64, ptr %t188, !range !{i64 0, i64 8}
  %t191 = icmp eq i64 %t189, 0
  store i1 %t191, ptr %l101, !tbaa !21
  br label %bb33
bb33:
  %t192 = load i1, ptr %l101, !tbaa !21
  store i1 %t192, ptr %l91, !tbaa !21
  br label %bb34
bb34:
  %t193 = load i1, ptr %l91, !tbaa !21
  br i1 %t193, label %bb35, label %bb36
bb35:
  %t194 = load ptr, ptr %l1, !tbaa !29
  %t196 = getelementptr { i64, [5 x i64] }, ptr %t194, i32 0, i32 1
  %t197 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t196, i32 0, i32 0
  %t198 = load %"compiler/source:Span", ptr %t197
  store %"compiler/source:Span" %t198, ptr %l20
  %t200 = load ptr, ptr %l1, !tbaa !29
  %t202 = getelementptr { i64, [5 x i64] }, ptr %t200, i32 0, i32 1
  %t203 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t202, i32 0, i32 1
  %t204 = load i32, ptr %t203
  store i32 %t204, ptr %l21, !tbaa !23
  %t206 = load ptr, ptr %l1, !tbaa !29
  %t208 = getelementptr { i64, [5 x i64] }, ptr %t206, i32 0, i32 1
  %t209 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t208, i32 0, i32 2
  %t210 = load ptr, ptr %t209
  store ptr %t210, ptr %l22, !tbaa !29
  %t212 = load ptr, ptr %l1, !tbaa !29
  %t214 = getelementptr { i64, [5 x i64] }, ptr %t212, i32 0, i32 1
  %t215 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t214, i32 0, i32 3
  %t216 = load i32, ptr %t215
  store i32 %t216, ptr %l23, !tbaa !23
  %t218 = load ptr, ptr %l22, !tbaa !29
  %t221 = getelementptr { i64, [4 x i64] }, ptr %t218, i32 0, i32 1
  %t222 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t221, i32 0, i32 0
  %t223 = load %"compiler/source:Span", ptr %t222
  store %"compiler/source:Span" %t223, ptr %l24
  %t225 = load ptr, ptr %l22, !tbaa !29
  %t228 = getelementptr { i64, [4 x i64] }, ptr %t225, i32 0, i32 1
  %t229 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t228, i32 0, i32 1
  %t230 = load i32, ptr %t229
  store i32 %t230, ptr %l25, !tbaa !23
  %t232 = load ptr, ptr %l22, !tbaa !29
  %t235 = getelementptr { i64, [4 x i64] }, ptr %t232, i32 0, i32 1
  %t236 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t235, i32 0, i32 2
  %t237 = load i32, ptr %t236
  %t240 = load i32, ptr %l11, !tbaa !23
  %t243 = icmp eq i32 %t237, %t240
  store i1 %t243, ptr %l104, !tbaa !21
  br label %bb37
bb36:
  store i1 false, ptr %l104, !tbaa !21
  br label %bb37
bb37:
  %t245 = load i1, ptr %l104, !tbaa !21
  store i1 %t245, ptr %l27, !tbaa !21
  br label %bb43
bb38:
  br i1 true, label %bb39, label %bb40
bb39:
  br label %bb41
bb40:
  br label %bb42
bb41:
  store i1 false, ptr %l27, !tbaa !21
  br label %bb43
bb42:
  call void @__olang_check_failed(ptr @olang_loc_dbe121105db3360d_c470698bff9d24c9)
  unreachable
bb43:
  %t246 = load i1, ptr %l27, !tbaa !21
  store i1 %t246, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2flower_2esamePlace(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca %"compiler/source:Span"
  %l7 = alloca i32
  %l9 = alloca %"compiler/source:Span"
  %l11 = alloca i32
  %l12 = alloca i32
  %l13 = alloca i64
  %l14 = alloca i32
  %l15 = alloca %"compiler/source:Span"
  %l16 = alloca i32
  %l18 = alloca i32
  %l19 = alloca %"compiler/source:Span"
  %l20 = alloca i32
  %l21 = alloca i64
  %l23 = alloca %"compiler/source:Span"
  %l25 = alloca i64
  %l26 = alloca i32
  %l27 = alloca i32
  %l28 = alloca ptr
  %l29 = alloca %"compiler/source:Span"
  %l31 = alloca ptr
  %l32 = alloca %"compiler/source:Span"
  %l33 = alloca i32
  %l35 = alloca i32
  %l36 = alloca ptr
  %l37 = alloca i64
  %l38 = alloca %"compiler/source:Span"
  %l39 = alloca i32
  %l40 = alloca ptr
  %l42 = alloca %"compiler/source:Span"
  %l44 = alloca ptr
  %l45 = alloca i64
  %l46 = alloca %"compiler/source:Span"
  %l47 = alloca i32
  %l49 = alloca i64
  %l50 = alloca i32
  %l51 = alloca ptr
  %l52 = alloca %"compiler/source:Span"
  %l54 = alloca ptr
  %l55 = alloca %"compiler/source:Span"
  %l56 = alloca i32
  %l58 = alloca %"compiler/source:Span"
  %l59 = alloca i32
  %l61 = alloca ptr
  %l62 = alloca i1
  %l70 = alloca i1
  %l71 = alloca ptr
  %l72 = alloca i1
  %l79 = alloca ptr
  %l80 = alloca i1
  %l83 = alloca i1
  %l93 = alloca i1
  %l103 = alloca ptr
  %l104 = alloca i1
  %l113 = alloca ptr
  %l114 = alloca i1
  %l117 = alloca i1
  %l129 = alloca i1
  %l141 = alloca i1
  %l153 = alloca ptr
  %l154 = alloca i1
  %l161 = alloca ptr
  %l162 = alloca i1
  %l165 = alloca i1
  %l175 = alloca i1
  %l184 = alloca i1
  %l185 = alloca ptr
  %l186 = alloca i1
  %l195 = alloca ptr
  %l196 = alloca i1
  %l199 = alloca i1
  %l211 = alloca i1
  %l223 = alloca i1
  %l234 = alloca i1
  %l235 = alloca ptr
  %l236 = alloca i1
  %l243 = alloca ptr
  %l244 = alloca i1
  %l247 = alloca i1
  %l257 = alloca i1
  %l269 = alloca i1
  %l270 = alloca i1
  %l282 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l61, !tbaa !29
  store i1 false, ptr %l62, !tbaa !21
  %t2 = load ptr, ptr %l61, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l61, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 7
  store i1 %t8, ptr %l62, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l62, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32 }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l2
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr { i64, [4 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32 }, ptr %t18, i32 0, i32 1
  %t20 = load i32, ptr %t19
  store i32 %t20, ptr %l3, !tbaa !23
  store i1 true, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t23 = load ptr, ptr %l0, !tbaa !29
  store ptr %t23, ptr %l71, !tbaa !29
  store i1 false, ptr %l72, !tbaa !21
  %t24 = load ptr, ptr %l71, !tbaa !29
  %t25 = icmp ne ptr %t24, null
  br i1 %t25, label %bb6, label %bb7
bb6:
  %t27 = load ptr, ptr %l71, !tbaa !29
  %t28 = load i64, ptr %t27, !range !{i64 0, i64 8}
  %t30 = icmp eq i64 %t28, 0
  store i1 %t30, ptr %l72, !tbaa !21
  br label %bb7
bb7:
  %t31 = load i1, ptr %l72, !tbaa !21
  br i1 %t31, label %bb8, label %bb9
bb8:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr { i64, [4 x i64] }, ptr %t32, i32 0, i32 1
  %t35 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t34, i32 0, i32 1
  %t36 = load i32, ptr %t35
  store i32 %t36, ptr %l4, !tbaa !23
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr { i64, [4 x i64] }, ptr %t38, i32 0, i32 1
  %t41 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t40, i32 0, i32 2
  %t42 = load i32, ptr %t41
  store i32 %t42, ptr %l5, !tbaa !23
  br label %bb10
bb9:
  br label %bb19
bb10:
  %t44 = load ptr, ptr %l1, !tbaa !29
  store ptr %t44, ptr %l79, !tbaa !29
  store i1 false, ptr %l80, !tbaa !21
  %t45 = load ptr, ptr %l79, !tbaa !29
  %t46 = icmp ne ptr %t45, null
  br i1 %t46, label %bb11, label %bb12
bb11:
  %t48 = load ptr, ptr %l79, !tbaa !29
  %t49 = load i64, ptr %t48, !range !{i64 0, i64 8}
  %t51 = icmp eq i64 %t49, 0
  store i1 %t51, ptr %l80, !tbaa !21
  br label %bb12
bb12:
  %t52 = load i1, ptr %l80, !tbaa !21
  br i1 %t52, label %bb13, label %bb14
bb13:
  %t53 = load ptr, ptr %l1, !tbaa !29
  %t55 = getelementptr { i64, [4 x i64] }, ptr %t53, i32 0, i32 1
  %t56 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t55, i32 0, i32 0
  %t57 = load %"compiler/source:Span", ptr %t56
  store %"compiler/source:Span" %t57, ptr %l6
  %t59 = load ptr, ptr %l1, !tbaa !29
  %t61 = getelementptr { i64, [4 x i64] }, ptr %t59, i32 0, i32 1
  %t62 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t61, i32 0, i32 1
  %t63 = load i32, ptr %t62
  store i32 %t63, ptr %l7, !tbaa !23
  %t65 = load ptr, ptr %l1, !tbaa !29
  %t67 = getelementptr { i64, [4 x i64] }, ptr %t65, i32 0, i32 1
  %t68 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t67, i32 0, i32 2
  %t69 = load i32, ptr %t68
  %t72 = load i32, ptr %l5, !tbaa !23
  %t75 = icmp eq i32 %t69, %t72
  store i1 %t75, ptr %l83, !tbaa !21
  br label %bb15
bb14:
  store i1 false, ptr %l83, !tbaa !21
  br label %bb15
bb15:
  %t77 = load i1, ptr %l83, !tbaa !21
  br i1 %t77, label %bb16, label %bb17
bb16:
  %t78 = load ptr, ptr %l1, !tbaa !29
  %t80 = getelementptr { i64, [4 x i64] }, ptr %t78, i32 0, i32 1
  %t81 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t80, i32 0, i32 0
  %t82 = load %"compiler/source:Span", ptr %t81
  store %"compiler/source:Span" %t82, ptr %l9
  %t84 = load ptr, ptr %l1, !tbaa !29
  %t86 = getelementptr { i64, [4 x i64] }, ptr %t84, i32 0, i32 1
  %t87 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t86, i32 0, i32 1
  %t88 = load i32, ptr %t87
  %t90 = load ptr, ptr %l1, !tbaa !29
  %t92 = getelementptr { i64, [4 x i64] }, ptr %t90, i32 0, i32 1
  %t93 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t92, i32 0, i32 2
  %t94 = load i32, ptr %t93
  store i32 %t94, ptr %l11, !tbaa !23
  %t97 = load i32, ptr %l4, !tbaa !23
  %t100 = icmp eq i32 %t88, %t97
  store i1 %t100, ptr %l93, !tbaa !21
  br label %bb18
bb17:
  store i1 false, ptr %l93, !tbaa !21
  br label %bb18
bb18:
  %t102 = load i1, ptr %l93, !tbaa !21
  store i1 %t102, ptr %l70, !tbaa !21
  br label %bb93
bb19:
  %t103 = load ptr, ptr %l0, !tbaa !29
  store ptr %t103, ptr %l103, !tbaa !29
  store i1 false, ptr %l104, !tbaa !21
  %t104 = load ptr, ptr %l103, !tbaa !29
  %t105 = icmp ne ptr %t104, null
  br i1 %t105, label %bb20, label %bb21
bb20:
  %t107 = load ptr, ptr %l103, !tbaa !29
  %t108 = load i64, ptr %t107, !range !{i64 0, i64 8}
  %t110 = icmp eq i64 %t108, 1
  store i1 %t110, ptr %l104, !tbaa !21
  br label %bb21
bb21:
  %t111 = load i1, ptr %l104, !tbaa !21
  br i1 %t111, label %bb22, label %bb23
bb22:
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t114 = getelementptr { i64, [4 x i64] }, ptr %t112, i32 0, i32 1
  %t115 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t114, i32 0, i32 1
  %t116 = load i32, ptr %t115
  store i32 %t116, ptr %l12, !tbaa !23
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t120 = getelementptr { i64, [4 x i64] }, ptr %t118, i32 0, i32 1
  %t121 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t120, i32 0, i32 2
  %t122 = load i64, ptr %t121
  store i64 %t122, ptr %l13, !tbaa !24
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t126 = getelementptr { i64, [4 x i64] }, ptr %t124, i32 0, i32 1
  %t127 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t126, i32 0, i32 3
  %t128 = load i32, ptr %t127
  store i32 %t128, ptr %l14, !tbaa !23
  br label %bb24
bb23:
  br label %bb36
bb24:
  %t130 = load ptr, ptr %l1, !tbaa !29
  store ptr %t130, ptr %l113, !tbaa !29
  store i1 false, ptr %l114, !tbaa !21
  %t131 = load ptr, ptr %l113, !tbaa !29
  %t132 = icmp ne ptr %t131, null
  br i1 %t132, label %bb25, label %bb26
bb25:
  %t134 = load ptr, ptr %l113, !tbaa !29
  %t135 = load i64, ptr %t134, !range !{i64 0, i64 8}
  %t137 = icmp eq i64 %t135, 1
  store i1 %t137, ptr %l114, !tbaa !21
  br label %bb26
bb26:
  %t138 = load i1, ptr %l114, !tbaa !21
  br i1 %t138, label %bb27, label %bb28
bb27:
  %t139 = load ptr, ptr %l1, !tbaa !29
  %t141 = getelementptr { i64, [4 x i64] }, ptr %t139, i32 0, i32 1
  %t142 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t141, i32 0, i32 0
  %t143 = load %"compiler/source:Span", ptr %t142
  store %"compiler/source:Span" %t143, ptr %l15
  %t145 = load ptr, ptr %l1, !tbaa !29
  %t147 = getelementptr { i64, [4 x i64] }, ptr %t145, i32 0, i32 1
  %t148 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t147, i32 0, i32 1
  %t149 = load i32, ptr %t148
  store i32 %t149, ptr %l16, !tbaa !23
  %t151 = load ptr, ptr %l1, !tbaa !29
  %t153 = getelementptr { i64, [4 x i64] }, ptr %t151, i32 0, i32 1
  %t154 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t153, i32 0, i32 2
  %t155 = load i64, ptr %t154
  %t157 = load ptr, ptr %l1, !tbaa !29
  %t159 = getelementptr { i64, [4 x i64] }, ptr %t157, i32 0, i32 1
  %t160 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t159, i32 0, i32 3
  %t161 = load i32, ptr %t160
  store i32 %t161, ptr %l18, !tbaa !23
  %t164 = load i64, ptr %l13, !tbaa !24
  %t167 = icmp eq i64 %t155, %t164
  store i1 %t167, ptr %l117, !tbaa !21
  br label %bb29
bb28:
  store i1 false, ptr %l117, !tbaa !21
  br label %bb29
bb29:
  %t169 = load i1, ptr %l117, !tbaa !21
  br i1 %t169, label %bb30, label %bb31
bb30:
  %t170 = load ptr, ptr %l1, !tbaa !29
  %t172 = getelementptr { i64, [4 x i64] }, ptr %t170, i32 0, i32 1
  %t173 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t172, i32 0, i32 0
  %t174 = load %"compiler/source:Span", ptr %t173
  store %"compiler/source:Span" %t174, ptr %l19
  %t176 = load ptr, ptr %l1, !tbaa !29
  %t178 = getelementptr { i64, [4 x i64] }, ptr %t176, i32 0, i32 1
  %t179 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t178, i32 0, i32 1
  %t180 = load i32, ptr %t179
  store i32 %t180, ptr %l20, !tbaa !23
  %t182 = load ptr, ptr %l1, !tbaa !29
  %t184 = getelementptr { i64, [4 x i64] }, ptr %t182, i32 0, i32 1
  %t185 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t184, i32 0, i32 2
  %t186 = load i64, ptr %t185
  store i64 %t186, ptr %l21, !tbaa !24
  %t188 = load ptr, ptr %l1, !tbaa !29
  %t190 = getelementptr { i64, [4 x i64] }, ptr %t188, i32 0, i32 1
  %t191 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t190, i32 0, i32 3
  %t192 = load i32, ptr %t191
  %t195 = load i32, ptr %l14, !tbaa !23
  %t198 = icmp eq i32 %t192, %t195
  store i1 %t198, ptr %l129, !tbaa !21
  br label %bb32
bb31:
  store i1 false, ptr %l129, !tbaa !21
  br label %bb32
bb32:
  %t200 = load i1, ptr %l129, !tbaa !21
  br i1 %t200, label %bb33, label %bb34
bb33:
  %t201 = load ptr, ptr %l1, !tbaa !29
  %t203 = getelementptr { i64, [4 x i64] }, ptr %t201, i32 0, i32 1
  %t204 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t203, i32 0, i32 0
  %t205 = load %"compiler/source:Span", ptr %t204
  store %"compiler/source:Span" %t205, ptr %l23
  %t207 = load ptr, ptr %l1, !tbaa !29
  %t209 = getelementptr { i64, [4 x i64] }, ptr %t207, i32 0, i32 1
  %t210 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t209, i32 0, i32 1
  %t211 = load i32, ptr %t210
  %t213 = load ptr, ptr %l1, !tbaa !29
  %t215 = getelementptr { i64, [4 x i64] }, ptr %t213, i32 0, i32 1
  %t216 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t215, i32 0, i32 2
  %t217 = load i64, ptr %t216
  store i64 %t217, ptr %l25, !tbaa !24
  %t219 = load ptr, ptr %l1, !tbaa !29
  %t221 = getelementptr { i64, [4 x i64] }, ptr %t219, i32 0, i32 1
  %t222 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t221, i32 0, i32 3
  %t223 = load i32, ptr %t222
  store i32 %t223, ptr %l26, !tbaa !23
  %t226 = load i32, ptr %l12, !tbaa !23
  %t229 = icmp eq i32 %t211, %t226
  store i1 %t229, ptr %l141, !tbaa !21
  br label %bb35
bb34:
  store i1 false, ptr %l141, !tbaa !21
  br label %bb35
bb35:
  %t231 = load i1, ptr %l141, !tbaa !21
  store i1 %t231, ptr %l70, !tbaa !21
  br label %bb93
bb36:
  %t232 = load ptr, ptr %l0, !tbaa !29
  store ptr %t232, ptr %l153, !tbaa !29
  store i1 false, ptr %l154, !tbaa !21
  %t233 = load ptr, ptr %l153, !tbaa !29
  %t234 = icmp ne ptr %t233, null
  br i1 %t234, label %bb37, label %bb38
bb37:
  %t236 = load ptr, ptr %l153, !tbaa !29
  %t237 = load i64, ptr %t236, !range !{i64 0, i64 8}
  %t239 = icmp eq i64 %t237, 2
  store i1 %t239, ptr %l154, !tbaa !21
  br label %bb38
bb38:
  %t240 = load i1, ptr %l154, !tbaa !21
  br i1 %t240, label %bb39, label %bb40
bb39:
  %t241 = load ptr, ptr %l0, !tbaa !29
  %t243 = getelementptr { i64, [4 x i64] }, ptr %t241, i32 0, i32 1
  %t244 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t243, i32 0, i32 1
  %t245 = load i32, ptr %t244
  store i32 %t245, ptr %l27, !tbaa !23
  %t247 = load ptr, ptr %l0, !tbaa !29
  %t249 = getelementptr { i64, [4 x i64] }, ptr %t247, i32 0, i32 1
  %t250 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t249, i32 0, i32 2
  %t251 = load ptr, ptr %t250
  store ptr %t251, ptr %l28, !tbaa !29
  br label %bb41
bb40:
  br label %bb51
bb41:
  %t253 = load ptr, ptr %l1, !tbaa !29
  store ptr %t253, ptr %l161, !tbaa !29
  store i1 false, ptr %l162, !tbaa !21
  %t254 = load ptr, ptr %l161, !tbaa !29
  %t255 = icmp ne ptr %t254, null
  br i1 %t255, label %bb42, label %bb43
bb42:
  %t257 = load ptr, ptr %l161, !tbaa !29
  %t258 = load i64, ptr %t257, !range !{i64 0, i64 8}
  %t260 = icmp eq i64 %t258, 2
  store i1 %t260, ptr %l162, !tbaa !21
  br label %bb43
bb43:
  %t261 = load i1, ptr %l162, !tbaa !21
  br i1 %t261, label %bb44, label %bb45
bb44:
  %t262 = load ptr, ptr %l1, !tbaa !29
  %t264 = getelementptr { i64, [4 x i64] }, ptr %t262, i32 0, i32 1
  %t265 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t264, i32 0, i32 0
  %t266 = load %"compiler/source:Span", ptr %t265
  store %"compiler/source:Span" %t266, ptr %l29
  %t268 = load ptr, ptr %l1, !tbaa !29
  %t270 = getelementptr { i64, [4 x i64] }, ptr %t268, i32 0, i32 1
  %t271 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t270, i32 0, i32 1
  %t272 = load i32, ptr %t271
  %t274 = load ptr, ptr %l1, !tbaa !29
  %t276 = getelementptr { i64, [4 x i64] }, ptr %t274, i32 0, i32 1
  %t277 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t276, i32 0, i32 2
  %t278 = load ptr, ptr %t277
  store ptr %t278, ptr %l31, !tbaa !29
  %t281 = load i32, ptr %l27, !tbaa !23
  %t284 = icmp eq i32 %t272, %t281
  store i1 %t284, ptr %l165, !tbaa !21
  br label %bb46
bb45:
  store i1 false, ptr %l165, !tbaa !21
  br label %bb46
bb46:
  %t286 = load i1, ptr %l165, !tbaa !21
  br i1 %t286, label %bb47, label %bb48
bb47:
  %t287 = load ptr, ptr %l1, !tbaa !29
  %t289 = getelementptr { i64, [4 x i64] }, ptr %t287, i32 0, i32 1
  %t290 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t289, i32 0, i32 0
  %t291 = load %"compiler/source:Span", ptr %t290
  store %"compiler/source:Span" %t291, ptr %l32
  %t293 = load ptr, ptr %l1, !tbaa !29
  %t295 = getelementptr { i64, [4 x i64] }, ptr %t293, i32 0, i32 1
  %t296 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t295, i32 0, i32 1
  %t297 = load i32, ptr %t296
  store i32 %t297, ptr %l33, !tbaa !23
  %t299 = load ptr, ptr %l1, !tbaa !29
  %t301 = getelementptr { i64, [4 x i64] }, ptr %t299, i32 0, i32 1
  %t302 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t301, i32 0, i32 2
  %t303 = load ptr, ptr %t302
  %t305 = load ptr, ptr %l28, !tbaa !29
  %t309 = call i1 @compiler_2flower_2esameLocal(ptr %v0, ptr %v1, ptr %t305, ptr %t303)
  store i1 %t309, ptr %l184
  br label %bb49
bb48:
  store i1 false, ptr %l175, !tbaa !21
  br label %bb50
bb49:
  %t310 = load i1, ptr %l184, !tbaa !21
  store i1 %t310, ptr %l175, !tbaa !21
  br label %bb50
bb50:
  %t311 = load i1, ptr %l175, !tbaa !21
  store i1 %t311, ptr %l70, !tbaa !21
  br label %bb93
bb51:
  %t312 = load ptr, ptr %l0, !tbaa !29
  store ptr %t312, ptr %l185, !tbaa !29
  store i1 false, ptr %l186, !tbaa !21
  %t313 = load ptr, ptr %l185, !tbaa !29
  %t314 = icmp ne ptr %t313, null
  br i1 %t314, label %bb52, label %bb53
bb52:
  %t316 = load ptr, ptr %l185, !tbaa !29
  %t317 = load i64, ptr %t316, !range !{i64 0, i64 8}
  %t319 = icmp eq i64 %t317, 3
  store i1 %t319, ptr %l186, !tbaa !21
  br label %bb53
bb53:
  %t320 = load i1, ptr %l186, !tbaa !21
  br i1 %t320, label %bb54, label %bb55
bb54:
  %t321 = load ptr, ptr %l0, !tbaa !29
  %t323 = getelementptr { i64, [4 x i64] }, ptr %t321, i32 0, i32 1
  %t324 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t323, i32 0, i32 1
  %t325 = load i32, ptr %t324
  store i32 %t325, ptr %l35, !tbaa !23
  %t327 = load ptr, ptr %l0, !tbaa !29
  %t329 = getelementptr { i64, [4 x i64] }, ptr %t327, i32 0, i32 1
  %t330 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t329, i32 0, i32 2
  %t331 = load ptr, ptr %t330
  store ptr %t331, ptr %l36, !tbaa !29
  %t333 = load ptr, ptr %l0, !tbaa !29
  %t335 = getelementptr { i64, [4 x i64] }, ptr %t333, i32 0, i32 1
  %t336 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t335, i32 0, i32 3
  %t337 = load i64, ptr %t336
  store i64 %t337, ptr %l37, !tbaa !24
  br label %bb56
bb55:
  br label %bb69
bb56:
  %t339 = load ptr, ptr %l1, !tbaa !29
  store ptr %t339, ptr %l195, !tbaa !29
  store i1 false, ptr %l196, !tbaa !21
  %t340 = load ptr, ptr %l195, !tbaa !29
  %t341 = icmp ne ptr %t340, null
  br i1 %t341, label %bb57, label %bb58
bb57:
  %t343 = load ptr, ptr %l195, !tbaa !29
  %t344 = load i64, ptr %t343, !range !{i64 0, i64 8}
  %t346 = icmp eq i64 %t344, 3
  store i1 %t346, ptr %l196, !tbaa !21
  br label %bb58
bb58:
  %t347 = load i1, ptr %l196, !tbaa !21
  br i1 %t347, label %bb59, label %bb60
bb59:
  %t348 = load ptr, ptr %l1, !tbaa !29
  %t350 = getelementptr { i64, [4 x i64] }, ptr %t348, i32 0, i32 1
  %t351 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t350, i32 0, i32 0
  %t352 = load %"compiler/source:Span", ptr %t351
  store %"compiler/source:Span" %t352, ptr %l38
  %t354 = load ptr, ptr %l1, !tbaa !29
  %t356 = getelementptr { i64, [4 x i64] }, ptr %t354, i32 0, i32 1
  %t357 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t356, i32 0, i32 1
  %t358 = load i32, ptr %t357
  store i32 %t358, ptr %l39, !tbaa !23
  %t360 = load ptr, ptr %l1, !tbaa !29
  %t362 = getelementptr { i64, [4 x i64] }, ptr %t360, i32 0, i32 1
  %t363 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t362, i32 0, i32 2
  %t364 = load ptr, ptr %t363
  store ptr %t364, ptr %l40, !tbaa !29
  %t366 = load ptr, ptr %l1, !tbaa !29
  %t368 = getelementptr { i64, [4 x i64] }, ptr %t366, i32 0, i32 1
  %t369 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t368, i32 0, i32 3
  %t370 = load i64, ptr %t369
  %t373 = load i64, ptr %l37, !tbaa !24
  %t376 = icmp eq i64 %t370, %t373
  store i1 %t376, ptr %l199, !tbaa !21
  br label %bb61
bb60:
  store i1 false, ptr %l199, !tbaa !21
  br label %bb61
bb61:
  %t378 = load i1, ptr %l199, !tbaa !21
  br i1 %t378, label %bb62, label %bb63
bb62:
  %t379 = load ptr, ptr %l1, !tbaa !29
  %t381 = getelementptr { i64, [4 x i64] }, ptr %t379, i32 0, i32 1
  %t382 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t381, i32 0, i32 0
  %t383 = load %"compiler/source:Span", ptr %t382
  store %"compiler/source:Span" %t383, ptr %l42
  %t385 = load ptr, ptr %l1, !tbaa !29
  %t387 = getelementptr { i64, [4 x i64] }, ptr %t385, i32 0, i32 1
  %t388 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t387, i32 0, i32 1
  %t389 = load i32, ptr %t388
  %t391 = load ptr, ptr %l1, !tbaa !29
  %t393 = getelementptr { i64, [4 x i64] }, ptr %t391, i32 0, i32 1
  %t394 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t393, i32 0, i32 2
  %t395 = load ptr, ptr %t394
  store ptr %t395, ptr %l44, !tbaa !29
  %t397 = load ptr, ptr %l1, !tbaa !29
  %t399 = getelementptr { i64, [4 x i64] }, ptr %t397, i32 0, i32 1
  %t400 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t399, i32 0, i32 3
  %t401 = load i64, ptr %t400
  store i64 %t401, ptr %l45, !tbaa !24
  %t404 = load i32, ptr %l35, !tbaa !23
  %t407 = icmp eq i32 %t389, %t404
  store i1 %t407, ptr %l211, !tbaa !21
  br label %bb64
bb63:
  store i1 false, ptr %l211, !tbaa !21
  br label %bb64
bb64:
  %t409 = load i1, ptr %l211, !tbaa !21
  br i1 %t409, label %bb65, label %bb66
bb65:
  %t410 = load ptr, ptr %l1, !tbaa !29
  %t412 = getelementptr { i64, [4 x i64] }, ptr %t410, i32 0, i32 1
  %t413 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t412, i32 0, i32 0
  %t414 = load %"compiler/source:Span", ptr %t413
  store %"compiler/source:Span" %t414, ptr %l46
  %t416 = load ptr, ptr %l1, !tbaa !29
  %t418 = getelementptr { i64, [4 x i64] }, ptr %t416, i32 0, i32 1
  %t419 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t418, i32 0, i32 1
  %t420 = load i32, ptr %t419
  store i32 %t420, ptr %l47, !tbaa !23
  %t422 = load ptr, ptr %l1, !tbaa !29
  %t424 = getelementptr { i64, [4 x i64] }, ptr %t422, i32 0, i32 1
  %t425 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t424, i32 0, i32 2
  %t426 = load ptr, ptr %t425
  %t428 = load ptr, ptr %l1, !tbaa !29
  %t430 = getelementptr { i64, [4 x i64] }, ptr %t428, i32 0, i32 1
  %t431 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t430, i32 0, i32 3
  %t432 = load i64, ptr %t431
  store i64 %t432, ptr %l49, !tbaa !24
  %t434 = load ptr, ptr %l36, !tbaa !29
  %t438 = call i1 @compiler_2flower_2esamePlace(ptr %v0, ptr %v1, ptr %t434, ptr %t426)
  store i1 %t438, ptr %l234
  br label %bb67
bb66:
  store i1 false, ptr %l223, !tbaa !21
  br label %bb68
bb67:
  %t439 = load i1, ptr %l234, !tbaa !21
  store i1 %t439, ptr %l223, !tbaa !21
  br label %bb68
bb68:
  %t440 = load i1, ptr %l223, !tbaa !21
  store i1 %t440, ptr %l70, !tbaa !21
  br label %bb93
bb69:
  %t441 = load ptr, ptr %l0, !tbaa !29
  store ptr %t441, ptr %l235, !tbaa !29
  store i1 false, ptr %l236, !tbaa !21
  %t442 = load ptr, ptr %l235, !tbaa !29
  %t443 = icmp ne ptr %t442, null
  br i1 %t443, label %bb70, label %bb71
bb70:
  %t445 = load ptr, ptr %l235, !tbaa !29
  %t446 = load i64, ptr %t445, !range !{i64 0, i64 8}
  %t448 = icmp eq i64 %t446, 4
  store i1 %t448, ptr %l236, !tbaa !21
  br label %bb71
bb71:
  %t449 = load i1, ptr %l236, !tbaa !21
  br i1 %t449, label %bb72, label %bb73
bb72:
  %t450 = load ptr, ptr %l0, !tbaa !29
  %t452 = getelementptr { i64, [4 x i64] }, ptr %t450, i32 0, i32 1
  %t453 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t452, i32 0, i32 1
  %t454 = load i32, ptr %t453
  store i32 %t454, ptr %l50, !tbaa !23
  %t456 = load ptr, ptr %l0, !tbaa !29
  %t458 = getelementptr { i64, [4 x i64] }, ptr %t456, i32 0, i32 1
  %t459 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t458, i32 0, i32 2
  %t460 = load ptr, ptr %t459
  store ptr %t460, ptr %l51, !tbaa !29
  br label %bb74
bb73:
  br label %bb88
bb74:
  %t462 = load ptr, ptr %l1, !tbaa !29
  store ptr %t462, ptr %l243, !tbaa !29
  store i1 false, ptr %l244, !tbaa !21
  %t463 = load ptr, ptr %l243, !tbaa !29
  %t464 = icmp ne ptr %t463, null
  br i1 %t464, label %bb75, label %bb76
bb75:
  %t466 = load ptr, ptr %l243, !tbaa !29
  %t467 = load i64, ptr %t466, !range !{i64 0, i64 8}
  %t469 = icmp eq i64 %t467, 4
  store i1 %t469, ptr %l244, !tbaa !21
  br label %bb76
bb76:
  %t470 = load i1, ptr %l244, !tbaa !21
  br i1 %t470, label %bb77, label %bb78
bb77:
  %t471 = load ptr, ptr %l1, !tbaa !29
  %t473 = getelementptr { i64, [4 x i64] }, ptr %t471, i32 0, i32 1
  %t474 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t473, i32 0, i32 0
  %t475 = load %"compiler/source:Span", ptr %t474
  store %"compiler/source:Span" %t475, ptr %l52
  %t477 = load ptr, ptr %l1, !tbaa !29
  %t479 = getelementptr { i64, [4 x i64] }, ptr %t477, i32 0, i32 1
  %t480 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t479, i32 0, i32 1
  %t481 = load i32, ptr %t480
  %t483 = load ptr, ptr %l1, !tbaa !29
  %t485 = getelementptr { i64, [4 x i64] }, ptr %t483, i32 0, i32 1
  %t486 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t485, i32 0, i32 2
  %t487 = load ptr, ptr %t486
  store ptr %t487, ptr %l54, !tbaa !29
  %t490 = load i32, ptr %l50, !tbaa !23
  %t493 = icmp eq i32 %t481, %t490
  store i1 %t493, ptr %l247, !tbaa !21
  br label %bb79
bb78:
  store i1 false, ptr %l247, !tbaa !21
  br label %bb79
bb79:
  %t495 = load i1, ptr %l247, !tbaa !21
  br i1 %t495, label %bb80, label %bb81
bb80:
  %t496 = load ptr, ptr %l1, !tbaa !29
  %t498 = getelementptr { i64, [4 x i64] }, ptr %t496, i32 0, i32 1
  %t499 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t498, i32 0, i32 0
  %t500 = load %"compiler/source:Span", ptr %t499
  store %"compiler/source:Span" %t500, ptr %l55
  %t502 = load ptr, ptr %l1, !tbaa !29
  %t504 = getelementptr { i64, [4 x i64] }, ptr %t502, i32 0, i32 1
  %t505 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t504, i32 0, i32 1
  %t506 = load i32, ptr %t505
  store i32 %t506, ptr %l56, !tbaa !23
  %t508 = load ptr, ptr %l1, !tbaa !29
  %t510 = getelementptr { i64, [4 x i64] }, ptr %t508, i32 0, i32 1
  %t511 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t510, i32 0, i32 2
  %t512 = load ptr, ptr %t511
  %t514 = load ptr, ptr %l51, !tbaa !29
  %t516 = getelementptr %"compiler/typed:Elem", ptr %t514, i32 0, i32 1
  %t517 = load ptr, ptr %t516, !tbaa !29
  %t521 = getelementptr %"compiler/typed:Elem", ptr %t512, i32 0, i32 1
  %t522 = load ptr, ptr %t521, !tbaa !29
  %t525 = call i1 @compiler_2flower_2esameLocal(ptr %v0, ptr %v1, ptr %t517, ptr %t522)
  store i1 %t525, ptr %l269
  br label %bb82
bb81:
  store i1 false, ptr %l257, !tbaa !21
  br label %bb83
bb82:
  %t526 = load i1, ptr %l269, !tbaa !21
  store i1 %t526, ptr %l257, !tbaa !21
  br label %bb83
bb83:
  %t527 = load i1, ptr %l257, !tbaa !21
  br i1 %t527, label %bb84, label %bb85
bb84:
  %t528 = load ptr, ptr %l1, !tbaa !29
  %t530 = getelementptr { i64, [4 x i64] }, ptr %t528, i32 0, i32 1
  %t531 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t530, i32 0, i32 0
  %t532 = load %"compiler/source:Span", ptr %t531
  store %"compiler/source:Span" %t532, ptr %l58
  %t534 = load ptr, ptr %l1, !tbaa !29
  %t536 = getelementptr { i64, [4 x i64] }, ptr %t534, i32 0, i32 1
  %t537 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t536, i32 0, i32 1
  %t538 = load i32, ptr %t537
  store i32 %t538, ptr %l59, !tbaa !23
  %t540 = load ptr, ptr %l1, !tbaa !29
  %t542 = getelementptr { i64, [4 x i64] }, ptr %t540, i32 0, i32 1
  %t543 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t542, i32 0, i32 2
  %t544 = load ptr, ptr %t543
  %t546 = load ptr, ptr %l51, !tbaa !29
  %t548 = getelementptr %"compiler/typed:Elem", ptr %t546, i32 0, i32 0
  %t549 = load ptr, ptr %t548, !tbaa !29
  %t553 = getelementptr %"compiler/typed:Elem", ptr %t544, i32 0, i32 0
  %t554 = load ptr, ptr %t553, !tbaa !29
  %t557 = call i1 @compiler_2flower_2esamePlace(ptr %v0, ptr %v1, ptr %t549, ptr %t554)
  store i1 %t557, ptr %l282
  br label %bb86
bb85:
  store i1 false, ptr %l270, !tbaa !21
  br label %bb87
bb86:
  %t558 = load i1, ptr %l282, !tbaa !21
  store i1 %t558, ptr %l270, !tbaa !21
  br label %bb87
bb87:
  %t559 = load i1, ptr %l270, !tbaa !21
  store i1 %t559, ptr %l70, !tbaa !21
  br label %bb93
bb88:
  br i1 true, label %bb89, label %bb90
bb89:
  br label %bb91
bb90:
  br label %bb92
bb91:
  store i1 false, ptr %l70, !tbaa !21
  br label %bb93
bb92:
  call void @__olang_check_failed(ptr @olang_loc_337d65ed03186f15_b822a9c09cc6a119)
  unreachable
bb93:
  %t560 = load i1, ptr %l70, !tbaa !21
  store i1 %t560, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2flower_2espanKey(%"compiler/source:Span" %a0) #0 {
entry:
  %l0 = alloca %"compiler/source:Span"
  %rv = alloca i64
  store %"compiler/source:Span" %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/source:Span", ptr %l0, i32 0, i32 0
  %t2 = load i32, ptr %t1, !tbaa !23
  %t4 = sext i32 %t2 to i64
  %t6 = shl i64 %t4, 32
  %t7 = getelementptr %"compiler/source:Span", ptr %l0, i32 0, i32 1
  %t8 = load i32, ptr %t7, !tbaa !23
  %t10 = sext i32 %t8 to i64
  %t13 = or i64 %t6, %t10
  store i64 %t13, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2flower_2estandIn(ptr %out, ptr %v0, i32 %a0) #0 {
entry:
  %l1 = alloca { i64, [2 x i64] }
  %l2 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca %"compiler/typed:Body"
  %s0 = alloca %olang.scope
  %t1 = alloca { i64, [2 x i64] }, align 8
  %t8 = alloca %"compiler/typed:Body", align 8
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store { i64, [2 x i64] } zeroinitializer, ptr %t1
  %t2 = getelementptr { i64, [2 x i64] }, ptr %t1, i32 0, i32 0
  store i64 5, ptr %t2
  %t3 = insertvalue { i64 } undef, i64 -1, 0
  %t4 = getelementptr { i64, [2 x i64] }, ptr %t1, i32 0, i32 1
  store { i64 } %t3, ptr %t4
  %t5 = load { i64, [2 x i64] }, ptr %t1
  store { i64, [2 x i64] } %t5, ptr %l1
  store i32 %a0, ptr %l2, !tbaa !23
  %t7 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 0, i32 0)
  store %"compiler/source:Span" %t7, ptr %l3
  br label %bb1
bb1:
  %t9 = load { i64, [2 x i64] }, ptr %l1
  %t10 = load i32, ptr %l2, !tbaa !23
  %t11 = load %"compiler/source:Span", ptr %l3
  call void @compiler_2ftyped_3aBody_2ector(ptr %t8, ptr %v0, i32 -1, { i64, [2 x i64] } %t9, i32 %t10, i64 0, %"compiler/source:Span" %t11)
  call void @llvm.memmove.p0.p0.i64(ptr %l4, ptr %t8, i64 440, i1 false)
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l4, i64 440, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/lower:CloneSite" @compiler_2flower_3aCloneSite_2ector(ptr %v0, { i64, [2 x i64] } %a0, i64 %a1, { i64, [2 x i64] } %a2, i32 %a3) #0 {
entry:
  %rv = alloca %"compiler/lower:CloneSite"
  br label %start
start:
  br label %bb0
bb0:
  %t10 = insertvalue %"compiler/lower:CloneSite" undef, { i64, [2 x i64] } %a0, 0
  %t12 = insertvalue %"compiler/lower:CloneSite" %t10, i64 %a1, 1
  %t14 = insertvalue %"compiler/lower:CloneSite" %t12, { i64, [2 x i64] } %a2, 2
  %t16 = insertvalue %"compiler/lower:CloneSite" %t14, i32 %a3, 3
  store %"compiler/lower:CloneSite" %t16, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/lower:CloneSite", ptr %rv
  ret %"compiler/lower:CloneSite" %rr
}

define dso_local %"compiler/lower:Gap" @compiler_2flower_3aGap_2ector(ptr %v0, ptr %v1, i64 %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2) #0 {
entry:
  %rv = alloca %"compiler/lower:Gap"
  br label %start
start:
  br label %bb0
bb0:
  %t8 = insertvalue %"compiler/lower:Gap" undef, i64 %a0, 0
  %t10 = insertvalue %"compiler/lower:Gap" %t8, %"compiler/source:Span" %a1, 1
  %t12 = insertvalue %"compiler/lower:Gap" %t10, { i64, ptr } %a2, 2
  store %"compiler/lower:Gap" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/lower:Gap", ptr %rv
  ret %"compiler/lower:Gap" %rr
}

define dso_local %"compiler/lower:affineSum" @compiler_2flower_3aaffineSum_2ector(ptr %v0, { i64, [4 x i64] } %a0, { i64, [4 x i64] } %a1, i1 %a2) #0 {
entry:
  %rv = alloca %"compiler/lower:affineSum"
  br label %start
start:
  br label %bb0
bb0:
  %t8 = insertvalue %"compiler/lower:affineSum" undef, { i64, [4 x i64] } %a0, 0
  %t10 = insertvalue %"compiler/lower:affineSum" %t8, { i64, [4 x i64] } %a1, 1
  %t12 = insertvalue %"compiler/lower:affineSum" %t10, i1 %a2, 2
  store %"compiler/lower:affineSum" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/lower:affineSum", ptr %rv
  ret %"compiler/lower:affineSum" %rr
}

define dso_local %"compiler/lower:level" @compiler_2flower_3alevel_2ector(ptr %v0, i32 %a0, i32 %a1, i32 %a2) #0 {
entry:
  %rv = alloca %"compiler/lower:level"
  br label %start
start:
  br label %bb0
bb0:
  %t8 = insertvalue %"compiler/lower:level" undef, i32 %a0, 0
  %t10 = insertvalue %"compiler/lower:level" %t8, i32 %a1, 1
  %t12 = insertvalue %"compiler/lower:level" %t10, i32 %a2, 2
  store %"compiler/lower:level" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/lower:level", ptr %rv
  ret %"compiler/lower:level" %rr
}

define dso_local %"compiler/lower:pl" @compiler_2flower_3apl_2ector(ptr %v0, { i64, [2 x i64] } %a0) #0 {
entry:
  %l1 = alloca { i64, [2 x i64] }
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %rv = alloca %"compiler/lower:pl"
  br label %start
start:
  br label %bb0
bb0:
  store { i64, [2 x i64] } %a0, ptr %l1
  %t3 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aProj_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %l6
  br label %bb1
bb1:
  %t4 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l6
  %t5 = load { i64, [2 x i64] }, ptr %l1
  %t6 = insertvalue %"compiler/lower:pl" undef, { i64, [2 x i64] } %t5, 0
  %t8 = insertvalue %"compiler/lower:pl" %t6, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t4, 1
  %t10 = insertvalue %"compiler/lower:pl" %t8, i64 -1, 2
  %t12 = insertvalue %"compiler/lower:pl" %t10, i32 0, 3
  store %"compiler/lower:pl" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/lower:pl", ptr %rv
  ret %"compiler/lower:pl" %rr
}

define dso_local %"compiler/lower:relPath" @compiler_2flower_3arelPath_2ector(ptr %v0, i64 %a0, { i64, ptr } %a1, i1 %a2, i1 %a3, i64 %a4, i64 %a5, i32 %a6, i64 %a7) #0 {
entry:
  %rv = alloca %"compiler/lower:relPath"
  br label %start
start:
  br label %bb0
bb0:
  %t18 = insertvalue %"compiler/lower:relPath" undef, i64 %a0, 0
  %t20 = insertvalue %"compiler/lower:relPath" %t18, { i64, ptr } %a1, 1
  %t22 = insertvalue %"compiler/lower:relPath" %t20, i1 %a2, 2
  %t24 = insertvalue %"compiler/lower:relPath" %t22, i1 %a3, 3
  %t26 = insertvalue %"compiler/lower:relPath" %t24, i64 %a4, 4
  %t28 = insertvalue %"compiler/lower:relPath" %t26, i64 %a5, 5
  %t30 = insertvalue %"compiler/lower:relPath" %t28, i32 %a6, 6
  %t32 = insertvalue %"compiler/lower:relPath" %t30, i64 %a7, 7
  store %"compiler/lower:relPath" %t32, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/lower:relPath", ptr %rv
  ret %"compiler/lower:relPath" %rr
}

define dso_local %"compiler/lower:tryCtx" @compiler_2flower_3atryCtx_2ector(ptr %v0, ptr %v1, i64 %a0, { i64, ptr } %a1, i1 %a2, i1 %a3) #0 {
entry:
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca i1
  %l7 = alloca i1
  %l13 = alloca i64
  %l15 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %rv = alloca %"compiler/lower:tryCtx"
  br label %start
start:
  br label %bb0
bb0:
  store i64 %a0, ptr %l4, !tbaa !24
  store { i64, ptr } %a1, ptr %l5, !tbaa !27
  store i1 %a2, ptr %l6, !tbaa !21
  store i1 %a3, ptr %l7, !tbaa !21
  %t9 = call ptr @__olang_scope_hold(ptr %v1)
  %t10 = ptrtoint ptr %t9 to i64
  store i64 %t10, ptr %l13, !tbaa !24
  %t11 = load i1, ptr @olang_2esole_2ecompiler_2flower_3atryCtx_2e4
  br i1 %t11, label %bb1, label %bb2
bb1:
  %t13 = call ptr @__olang_region_make(ptr %v1)
  %t14 = ptrtoint ptr %t13 to i64
  store i64 %t14, ptr %l13, !tbaa !24
  br label %bb2
bb2:
  %t15 = load i64, ptr %l13
  %t16 = inttoptr i64 %t15 to ptr
  %t17 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBlockId_3e_2ector(ptr %t16, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t17, ptr %l15
  br label %bb3
bb3:
  %t18 = load i1, ptr @olang_2esole_2ecompiler_2flower_3atryCtx_2e4
  br i1 %t18, label %bb4, label %bb5
bb4:
  %t20 = load i64, ptr %l13
  %t21 = inttoptr i64 %t20 to ptr
  %t22 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l15, i32 0, i32 0
  %t23 = load { i64, ptr }, ptr %t22
  %t24 = extractvalue { i64, ptr } %t23, 1
  %t25 = call ptr @__olang_region_or(ptr %t24, ptr null)
  %t26 = call ptr @__olang_region_home(ptr %t25)
  %t27 = icmp ne ptr %t26, null
  %t28 = select i1 %t27, ptr %t26, ptr null
  call void @__olang_region_settle_in(ptr %t21, ptr %t28)
  br label %bb5
bb5:
  %t29 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l15
  %t30 = load i64, ptr %l4, !tbaa !24
  %t31 = insertvalue %"compiler/lower:tryCtx" undef, i64 %t30, 0
  %t32 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t33 = insertvalue %"compiler/lower:tryCtx" %t31, { i64, ptr } %t32, 1
  %t34 = load i1, ptr %l6, !tbaa !21
  %t35 = insertvalue %"compiler/lower:tryCtx" %t33, i1 %t34, 2
  %t36 = load i1, ptr %l7, !tbaa !21
  %t37 = insertvalue %"compiler/lower:tryCtx" %t35, i1 %t36, 3
  %t39 = insertvalue %"compiler/lower:tryCtx" %t37, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t29, 4
  store %"compiler/lower:tryCtx" %t39, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/lower:tryCtx", ptr %rv
  ret %"compiler/lower:tryCtx" %rr
}

declare void @__olang_check_failed(ptr) cold noreturn
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %dh = load ptr, ptr %dheadptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  %hasd = icmp ne ptr %dh, null
  %owns = or i1 %hasf, %hasd
  br i1 %owns, label %owned, label %chunks
owned:
  call void @__olang_scope_close_owned(ptr %scope)
  br label %chunks
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
@.d0 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare i64 @__olang_fmt_i64(ptr, i64)
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
@.d1 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@.d2 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"?" }>, align 8
declare ptr @__olang_scope_of(ptr, ptr) noinline
define available_externally ptr @__olang_scope_hold(ptr %s) alwaysinline {
entry:
  %none = icmp eq ptr %s, null
  br i1 %none, label %plain, label %look
look:
  ; atomic: on a scope that is no stand-in this word is its parts list, which other threads push onto (__olang_scope_part)
  %mp = getelementptr %olang.scope, ptr %s, i32 0, i32 4
  %m = load atomic ptr, ptr %mp monotonic, align 8
  %fresh = icmp eq ptr %m, @__olang_standin_mark
  br i1 %fresh, label %make, label %kept
kept:
  %mi = ptrtoint ptr %m to i64
  %bit = and i64 %mi, 1
  %has = icmp ne i64 %bit, 0
  br i1 %has, label %keeper, label %plain
keeper:
  %ki = and i64 %mi, -2
  %k = inttoptr i64 %ki to ptr
  ret ptr %k
make:
  %f = call ptr @__olang_standin_keeper(ptr %s)
  ret ptr %f
plain:
  ret ptr %s
}
@.d3 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
@.d4 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"O23a " }>, align 8
@.d5 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"O23a dtor " }>, align 8
@.d6 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare ptr @__olang_scope_or(ptr, ptr)
@.d7 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"std/prelude/text" }>, align 8
@.d8 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"String" }>, align 8
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ; B19b: a benchmark build counts what this thread allocates - here and at the slow path's own bump, so each
  ; allocation is counted once wherever it is made (a region's and a forwarded scope's come back through here)
; @bench %bna = load i64, ptr @__olang_bench_allocs
; @bench %bna1 = add i64 %bna, 1
; @bench store i64 %bna1, ptr @__olang_bench_allocs
; @bench %bnb = load i64, ptr @__olang_bench_bytes
; @bench %bnb1 = add i64 %bnb, %size
; @bench store i64 %bnb1, ptr @__olang_bench_bytes
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
define linkonce_odr %"compiler/lower:pl" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2flower_3apl(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"compiler/lower:pl"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %rv = alloca %"compiler/lower:pl"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"compiler/lower:pl", ptr %a0
  store %"compiler/lower:pl" %t2, ptr %l1
  %t3 = getelementptr %"compiler/lower:pl", ptr %l1, i32 0, i32 1
  %t5 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aProj_3e(ptr %v0, ptr %t3)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %l3
  br label %bb1
bb1:
  %t6 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  %t7 = getelementptr %"compiler/lower:pl", ptr %l1, i32 0, i32 1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t6, ptr %t7
  %t8 = load %"compiler/lower:pl", ptr %l1
  store %"compiler/lower:pl" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/lower:pl", ptr %rv
  ret %"compiler/lower:pl" %rr
}

@__olang_empty_array = external constant [16 x i64]
@olang_2esole_2ecompiler_2flower_3aGap_2e2 = weak hidden constant i1 false
declare ptr @__olang_region_make(ptr) noinline
define available_externally noalias ptr @__olang_held_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
@.d9 = private constant <{ i64, [43 x i8] }> <{ i64 0, [43 x i8] c"a field of a packed struct taken as a place" }>, align 8
@__olang_prog_scope = external thread_local(initialexec) global ptr
@.d10 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d11 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d12 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
define linkonce_odr i1 @olang_2emir_2eHelperKind_2eEqual_2ecompiler_2fmir_3aScopeRef(ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca i64
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %t1, !range !{i64 0, i64 5}
  store i64 %t2, ptr %l3, !tbaa !24
  %t3 = load ptr, ptr %l1, !tbaa !29
  %t4 = load i64, ptr %t3, !range !{i64 0, i64 5}
  %t5 = load i64, ptr %l3, !tbaa !24
  %t7 = icmp eq i64 %t5, %t4
  br i1 %t7, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb10
bb2:
  %t9 = load i64, ptr %l3, !tbaa !24
  switch i64 %t9, label %bb3 [ i64 0, label %bb4 i64 1, label %bb5 i64 4, label %bb6 ]
bb3:
  br label %bb10
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr { i64, [1 x i64] }, ptr %t10, i32 0, i32 1
  %t12 = getelementptr { i32 }, ptr %t11, i32 0, i32 0
  %t13 = load i32, ptr %t12
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t15 = getelementptr { i64, [1 x i64] }, ptr %t14, i32 0, i32 1
  %t16 = getelementptr { i32 }, ptr %t15, i32 0, i32 0
  %t17 = load i32, ptr %t16
  %t20 = icmp eq i32 %t13, %t17
  br i1 %t20, label %bb7, label %bb1
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr { i64, [1 x i64] }, ptr %t22, i32 0, i32 1
  %t24 = getelementptr { i64 }, ptr %t23, i32 0, i32 0
  %t25 = load i64, ptr %t24
  %t26 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr { i64, [1 x i64] }, ptr %t26, i32 0, i32 1
  %t28 = getelementptr { i64 }, ptr %t27, i32 0, i32 0
  %t29 = load i64, ptr %t28
  %t32 = icmp eq i64 %t25, %t29
  br i1 %t32, label %bb8, label %bb1
bb6:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr { i64, [1 x i64] }, ptr %t34, i32 0, i32 1
  %t36 = getelementptr { i32 }, ptr %t35, i32 0, i32 0
  %t37 = load i32, ptr %t36
  %t38 = load ptr, ptr %l1, !tbaa !29
  %t39 = getelementptr { i64, [1 x i64] }, ptr %t38, i32 0, i32 1
  %t40 = getelementptr { i32 }, ptr %t39, i32 0, i32 0
  %t41 = load i32, ptr %t40
  %t44 = icmp eq i32 %t37, %t41
  br i1 %t44, label %bb9, label %bb1
bb7:
  br label %bb3
bb8:
  br label %bb3
bb9:
  br label %bb3
bb10:
  %t46 = load i1, ptr %l2, !tbaa !21
  store i1 %t46, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

declare void @__olang_bang_failed_plain(ptr) cold noreturn
@olang_2esole_2ecompiler_2flower_3atryCtx_2e4 = weak hidden constant i1 false
declare ptr @__olang_region_or(ptr, ptr)
declare ptr @__olang_region_home(ptr)
declare void @__olang_region_settle_in(ptr, ptr)
declare void @__olang_scope_close_owned(ptr) noinline
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
@__olang_standin_mark = external global i64
declare ptr @__olang_standin_keeper(ptr) noinline
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aProj_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 16
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define available_externally noalias ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  %head = load ptr, ptr %scope, !tbaa !59
  %isslot = icmp eq ptr %head, @__olang_slot_chunk
  br i1 %isslot, label %slot, label %plain
slot:
  %s = call ptr @__olang_slot_alloc(ptr %scope, i64 %rawsize)
  ret ptr %s
plain:
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
@__olang_slot_chunk = external global %olang.chunk
declare noalias ptr @__olang_slot_alloc(ptr, i64) noinline
@olang_loc_6ad7887f3088cd5b_7cbfc32661adbb3f = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2flower_2ecompiler_2flower_3aLowerer_2ebuildsFact(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlan_3e_2eLen_3ccompiler_2ftyped_3aPlan_3e(ptr %v0, ptr %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlan_3e_2eRef_3ccompiler_2ftyped_3aPlan_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @compiler_2ffacts_2ecompiler_2ffacts_3aTable_2eDecide(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, i1 %a3)
@olang_loc_caf8701635663f27_e992a5ba8ea146fb = external constant [0 x i8]
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_daa9f23a83841987_24921124063ad36b = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %a0)
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eHas_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_e3721461a855ef35_c24433bc0ae5f641 = external constant [0 x i8]
declare ptr @compiler_2flower_2ecompiler_2flower_3aLowerer_2elowerAs(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2)
@olang_loc_64c38670143ed62f_66b5484a55823b73 = external constant [0 x i8]
declare i32 @compiler_2ffacts_2ecompiler_2ffacts_3aTable_2eNote(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_585470ea6701dfed_8ee4dec4923e1081 = external constant [0 x i8]
declare ptr @compiler_2flower_2ecompiler_2flower_3aLowerer_2eT(ptr %v0, ptr %v1, ptr %a0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2ftyped_2eLocalUses_2eUses(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceName(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1)
@olang_loc_66e2991888adf299_d5a5a9b8966d006d = external constant [0 x i8]
declare { i64, ptr } @compiler_2fload_2eErrQualifier(ptr %v0, ptr %v1, { i64, ptr } %a0, i1 %a1)
@olang_loc_fdef55e2919415e3_7c40141ab4e8627 = external constant [0 x i8]
declare { i32, i1 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eGet_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
declare i1 @compiler_2flower_2ecompiler_2flower_3aLowerer_2ekeepsNothing(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2)
declare i64 @compiler_2ftyped_2eCalleeBody(ptr %v0, ptr %a0)
declare i1 @compiler_2flower_2ecompiler_2flower_3aLowerer_2efreshLocal(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, i64 %a3)
@olang_loc_7e98ebbcfc7ae681_fbeaec9fd6de6485 = external constant [0 x i8]
@olang_loc_80862e2151cf42f0_7c300e18841fcdd4 = external constant [0 x i8]
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclaresCopy(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eUnnamed(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2flower_2ecompiler_2flower_3aLowerer_2ekeepsParts(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2)
declare %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %a0, i64 %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_3f_26_3e_2eAt__H2e4a6474e10b73ca754517844b8d7700(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_298df02769e60406_e8c7ebf3f84a062 = external constant [0 x i8]
@olang_loc_83dfbaab25479658_1c809850a1eedc14 = external constant [0 x i8]
@olang_loc_435acf52bbb8e677_d8766f4885972723 = external constant [0 x i8]
declare ptr @compiler_2flower_2efreshCall(ptr %v0, ptr %v1, ptr %a0)
declare i1 @compiler_2flower_2ecompiler_2flower_3aLowerer_2estartCall(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_50f71fc20ce5d5c5_1a87e46ae2942751 = external constant [0 x i8]
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ePreludeType(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare void @compiler_2flower_2ecompiler_2flower_3ahandWalk_2estmt(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare void @compiler_2flower_2ecompiler_2flower_3ahandWalk_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1)
@olang_loc_9a464a2bb6204b77_4682d2f86e8713a3 = external constant [0 x i8]
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOwnsParts(ptr %v0, ptr %a0, i32 %a1)
declare { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eownCopyOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, [4 x i64] } %a1, i32 %a2, { i64, [1 x i64] } %a3, %"compiler/source:Span" %a4, i1 %a5)
declare i32 @compiler_2flower_2ecompiler_2flower_3alowering_2elocal(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, [4 x i64] } %a1, i32 %a2, %"compiler/source:Span" %a3)
@G_2ecompiler_2fmir_2eI64T = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\06\00\00\00" }>, align 8
declare %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %a0)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eUnknownT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
declare { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2escopeRef(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, [2 x i64] } %a1)
declare i32 @compiler_2fmir_2eCasesOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %a0)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, [8 x i64] } %a1)
declare { i32, i64 } @compiler_2flower_2ecompiler_2flower_3aLowerer_2efailure(ptr %v0, ptr %a0, i64 %a1)
@G_2ecompiler_2fmir_2eI32T = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\05\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList1(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2edispatch(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, [4 x i64] } %a1, i32 %a2, %"compiler/source:Span" %a3, i1 %a4)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v0, ptr %a0)
declare i1 @compiler_2flower_2ecompiler_2flower_3alowering_2ewidening(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, { i64, ptr } %a2, i32 %a3)
declare i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eregionMade(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_755da8ec4c9a9682_903a5def85eef08e = external constant [0 x i8]
@olang_loc_cd5f024afedc1d69_a0cc122b0d762c35 = external constant [0 x i8]
@olang_loc_9d7bd0ecfcbf809b_94241bedce5fc567 = external constant [0 x i8]
declare { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ecopyAt(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/lower:pl" %a1, i32 %a2, { i64, [1 x i64] } %a3, %"compiler/source:Span" %a4, i1 %a5, i1 %a6)
@olang_loc_9734ff52b1aa485e_990a10ecf234c10a = external constant [0 x i8]
@olang_loc_ae9d9b0e355a2005_a6ba10fc82c4da11 = external constant [0 x i8]
declare i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eElemPlace(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eFieldPlace(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eSlotPlace(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2flower_2ecompiler_2flower_3aLowerer_2eGen(ptr %v0, ptr %v1, ptr %a0)
declare i1 @compiler_2fmir_2ecompiler_2fmir_3aGenInfo_2eHoldsGen(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
declare { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, ptr %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScopeVar_3e_2eLen_3ccompiler_2ftyped_3aScopeVar_3e(ptr %v0, ptr %a0)
declare { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2enullScope(ptr %v0, ptr %v1, ptr %v2, ptr %a0)
@olang_loc_3a66230741c412ef_cf9b39cad1abd5db = external constant [0 x i8]
@olang_loc_9340bfd168f92e90_dfeb1d6426189a2c = external constant [0 x i8]
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eSelfHolding(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_6150b85b9eb427f5_1eae8daae523ab39 = external constant [0 x i8]
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2ereleaseOn(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, %"compiler/lower:pl" %a1, ptr %a2, %"compiler/source:Span" %a3)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockInfo_3e_2eLen__Hdc799a0fe091f8e84d50200d058b631d(ptr %v0, ptr %a0)
declare %"compiler/typed:BlockInfo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockInfo_3e_2eAt_3ccompiler_2ftyped_3aBlockInfo_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_57a53f0c70226722_53d3c67d5b30d4c6 = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3aFree_2eEndsMoved(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, i1 %a3)
declare i1 @compiler_2flower_2ecompiler_2flower_3alowering_2emovedAway(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_9e09bad51f2e7189_a86eb6e03c65edad = external constant [0 x i8]
declare i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eEndPlace(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2flower_2ecompiler_2flower_3alowering_2emovedPath(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2flower_2ecompiler_2flower_3alowering_2eleafPaths(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, i32 %a1)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2eleave(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, i64 %a1)
declare i1 @compiler_2flower_2ecompiler_2flower_3aLowerer_2ekeepsNoRef(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ewiden(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, [4 x i64] } %a1, i32 %a2, i32 %a3, %"compiler/source:Span" %a4, { i64, [1 x i64] } %a5)
declare i1 @compiler_2flower_2ecompiler_2flower_3alowering_2efits(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2)
declare ptr @compiler_2flower_2eviewCallIn(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_c9ff4911a436500b_5835334d424a3697 = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3aGap_3e_2ePush_3ccompiler_2flower_3aGap_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/lower:Gap" %a1)
declare i32 @compiler_2flower_2ecompiler_2flower_3alowering_2ewhenSole(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, i1 %a2, %"compiler/source:Span" %a3)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2ejoinAt(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSharesRefs(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2flower_2erunArray(ptr %v0, ptr %a0, i32 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eimmutableGlobal(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2)
declare i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eheldSrc(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, ptr %a1, ptr %a2)
@olang_loc_bfe20f6aa057d6f5_318d2eb3f782ecf9 = external constant [0 x i8]
declare i1 @compiler_2flower_2ecompiler_2flower_3alowering_2elendsKeep(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i64 %a2)
declare i32 @compiler_2fmir_2eHelperType(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare void @compiler_2flower_2ecompiler_2flower_3aLowerer_2eWant(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1)
@G_2ecompiler_2fmir_2eNoLocal = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\FF\FF\FF\FF" }>, align 8
@G_2ecompiler_2ftypes_2eVoidT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
declare %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eArgs(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eScopeRefs(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@G_2ecompiler_2fmir_2eNoPlace = available_externally constant <{ [32 x i8] }> <{ [32 x i8] c"\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00" }>, align 32
@G_2ecompiler_2fmir_2eNoBlock = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\FF\FF\FF\FF" }>, align 8
declare %"compiler/mir:Call" @compiler_2fmir_3aCall_2ector(ptr %v0, { i64, [7 x i64] } %a0, %"compiler/mir:Range" %a1, %"compiler/mir:Range" %a2, %"compiler/mir:Lvalue" %a3, i1 %a4, i32 %a5, i32 %a6, i32 %a7)
declare i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddCall(ptr %v0, ptr %a0, %"compiler/mir:Call" %a1)
@G_2ecompiler_2ftypes_2eBoolT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2ehoistExpr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %v6, ptr %a0, ptr %a1, ptr %a2)
@olang_loc_4a3d2c0d7af401cb_af9e757c5227be3f = external constant [0 x i8]
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2ehoistStmt(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %v6, ptr %a0, ptr %a1, ptr %a2)
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v0, ptr %a0)
@olang_loc_da93e14155b6d1b5_224c74a94b128e51 = external constant [0 x i8]
@olang_loc_bf8241b95bfd56f9_9ba7c89c1dae0c65 = external constant [0 x i8]
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_fe6f132f471090d8_e27fa787bcbe9484 = external constant [0 x i8]
declare %"compiler/mir:BasicBlock" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2eAt_3ccompiler_2fmir_3aBasicBlock_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, [21 x i64] } @compiler_2fmir_2ecompiler_2fmir_3aStmtList_2eAt(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2flower_2ewholeLocal({ i64, [4 x i64] } %a0)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2ementions(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2, i64 %a3)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2eLen_3ccompiler_2fmir_3aLocalId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2eAt_3ccompiler_2fmir_3aLocalId_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_f71032533cd82c8_29b3308e7cd66624 = external constant [0 x i8]
@olang_loc_6cc454f6892da6e7_dc94ff52b1800ff3 = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aProj_3e_2eView_3ccompiler_2fmir_3aProj_3e(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_42d43bd34810722a_688b4686d67d3836 = external constant [0 x i8]
declare %"compiler/mir:Lvalue" @compiler_2fmir_2ecompiler_2fmir_3aFn_2ePlace(ptr %v0, ptr %v1, ptr %a0, { i64, [2 x i64] } %a1, { i64, ptr } %a2)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aProj_3e_2eToArray_3ccompiler_2fmir_3aProj_3e(ptr %v0, ptr %v1, ptr %a0)
@G_2ecompiler_2ftyped_2eMutGlobalsFact = external constant <{ [8 x i8], ptr }>
@olang_loc_166f6c7f8536ecb_3daea1ccb6433847 = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3alevel_3e_2eLen_3ccompiler_2flower_3alevel_3e(ptr %v0, ptr %a0)
declare %"compiler/lower:level" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3alevel_3e_2eAt_3ccompiler_2flower_3alevel_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2flower_2ecompiler_2flower_3alowering_2elevelOf(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_26f97a2e9212578f_59dde7bfe76d04db = external constant [0 x i8]
@olang_loc_a1428f65c21f01d2_d86d747ff6972196 = external constant [0 x i8]
declare i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eOwnerSite(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ePartsOnly(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRunsCopy(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOwnedPart(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePacked(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aProj_3e_2eLen_3ccompiler_2fmir_3aProj_3e(ptr %v0, ptr %a0)
declare { i64, ptr } @compiler_2flower_2ecompiler_2flower_3alowering_2epackedChain(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, %"compiler/lower:pl" %a1, %"compiler/source:Span" %a2)
declare %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %v0, i64 %a0, i64 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare i1 @compiler_2fmir_2ecompiler_2fmir_3aGenInfo_2eWeakField(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, i64 %a3)
declare { i64, ptr } @compiler_2flower_2ecompiler_2flower_3alowering_2epartsOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2epartOf(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/lower:pl" %a1, i32 %a2, i64 %a3, { i64, [1 x i64] } %a4, %"compiler/source:Span" %a5)
@olang_loc_279896acdd8c6bde_4c10668047ad718a = external constant [0 x i8]
declare { i64, [2 x i64] } @compiler_2ftyped_2ecompiler_2ftyped_3aPlan_2ePassed(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBlockId_3e_2eLen_3ccompiler_2fmir_3aBlockId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBlockId_3e_2eAt_3ccompiler_2fmir_3aBlockId_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eEnd(ptr %v0, ptr %a0, i32 %a1, { i64, [8 x i64] } %a2)
declare %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2eplace(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %v6, ptr %a0, ptr %a1)
@G_2ecompiler_2flower_2eWrongCase = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
declare i1 @compiler_2ftyped_2ePlaceRooted(ptr %v0, ptr %a0)
@olang_loc_4fc653f117519a1d_d526ff90513f5371 = external constant [0 x i8]
declare { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ecarries(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, [4 x i64] } %a1, i32 %a2, %"compiler/source:Span" %a3)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2egoto(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1)
declare i64 @compiler_2flower_2ecompiler_2flower_3alowering_2efixedLen(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2epromotedCond(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, ptr %a1, i32 %a2, i32 %a3, %"compiler/source:Span" %a4)
declare ptr @compiler_2flower_2edefaultTry(ptr %v0, ptr %v1, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3arelPath_3e_2eLen_3ccompiler_2flower_3arelPath_3e(ptr %v0, ptr %a0)
declare { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2etryAt(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3, i32 %a4)
declare { i32, { i64, [4 x i64] } } @compiler_2flower_2ecompiler_2flower_3alowering_2epromotedInPlace(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3, i32 %a4)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNeedsDrop(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2flower_2ecompiler_2flower_3alowering_2emutStorage(ptr %v0, ptr %v1, ptr %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eAt_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i1 @compiler_2flower_2ecompiler_2flower_3alowering_2equietAll(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1)
@olang_loc_80847d650e26c632_64a1946959062bee = external constant [0 x i8]
declare ptr @compiler_2flower_2efindBlock(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eClear_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2ecoverAdd(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i64 %a2)
declare i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eglobalHits(ptr %v0, ptr %v1, ptr %v2, ptr %a0)
declare i1 @compiler_2flower_2ecompiler_2flower_3alowering_2equietBlock(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1)
declare i1 @compiler_2flower_2ecompiler_2flower_3alowering_2equietPlace(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1)
@olang_loc_28287f1f33def765_74d32538b56dd6f1 = external constant [0 x i8]
declare i1 @compiler_2flower_2ecompiler_2flower_3alowering_2equietCall(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1)
declare i1 @compiler_2flower_2eglobalWrite(i32 %a0)
declare i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eselfTry(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2flower_2ecompiler_2flower_3alowering_2equietPieces(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1)
@olang_loc_3bbf6907cdc90559_48ef26e69e7376e5 = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eisMain(ptr %v0, ptr %v1, ptr %a0)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2emainPayloads(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, [4 x i64] } %a1, %"compiler/source:Span" %a2)
declare i1 @compiler_2flower_2ecompiler_2flower_3alowering_2ewindowQuiet(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, ptr %a1, ptr %a2, ptr %a3)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2ereadPlace(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, ptr %a1, ptr %a2, ptr %a3)
@olang_loc_763e3b2e421df924_4ff52ff107ec1ef8 = external constant [0 x i8]
@olang_loc_292009f276c7a2f3_194bd9ce8dfbeb17 = external constant [0 x i8]
@olang_loc_a9234ad2dabfd921_4df0c0618daabfe5 = external constant [0 x i8]
@G_2ecompiler_2ftypes_2eReadOnly = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2eword(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, [1 x i64] } %a1, { i64, ptr } %a2, %"compiler/source:Span" %a3)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2einner(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/lower:pl" %a1, i32 %a2, { i64, [1 x i64] } %a3, %"compiler/source:Span" %a4)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopeVarsOf(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eResultVar = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FF\FF\FF\FF\FF\FF\FF\FF" }>, align 8
declare i1 @compiler_2flower_2ecompiler_2flower_3alowering_2ebranchesCopy(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, i32 %a2)
declare i1 @compiler_2ftyped_2eFreshTemp(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlock_26_3e_2eLen_3ccompiler_2ftyped_3aBlock_26_3e(ptr %v0, ptr %a0)
declare { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eresultScope(ptr %v0, ptr %v1, ptr %a0)
declare i1 @compiler_2flower_2ecompiler_2flower_3alowering_2erunArrayLocal(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i1 @compiler_2flower_2ecompiler_2flower_3aLowerer_2enamesKept(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, i64 %a3)
declare %"compiler/mir:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eAt_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNumber(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eWritable = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare i64 @compiler_2flower_2ecompiler_2flower_3alowering_2eguardOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1)
@G_2ecompiler_2ffree_2eNotSole = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FE\FF\FF\FF\FF\FF\FF\FF" }>, align 8
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2estmtSpawnErrors(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, ptr %a2)
@olang_loc_a75b87f7fc6585db_9c37e910f1cfbc0f = external constant [0 x i8]
@olang_loc_31e744114bee3e3d_92a3ba9b31ef9be1 = external constant [0 x i8]
declare i1 @compiler_2flower_2ecompiler_2flower_3alowering_2estableHolder(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1)
declare i1 @compiler_2ftyped_2ePassesRefs(i32 %a0)
@olang_loc_7e6d7b9279609ab3_447c445eeb868dc7 = external constant [0 x i8]
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2eholders(ptr %v0, ptr %a0, %"compiler/mir:Lvalue" %a1, i64 %a2, %"compiler/source:Span" %a3)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2ePush_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2estmtIn(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, ptr %a1)
declare { i32, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2ePop_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_a5b1a763b9bba10_ba6ba978893df9a4 = external constant [0 x i8]
@olang_loc_eb3797cfa5f64105_1f3db8e929f64739 = external constant [0 x i8]
@olang_loc_d2f375e5ba968b65_383d0166caeed659 = external constant [0 x i8]
@olang_loc_e527201c6aa166ab_3a4acb23654914bf = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %a0)
@olang_loc_f20c72191c5bbaec_70ba5090fad608c8 = external constant [0 x i8]
@olang_loc_9792dafd009dd231_d222868cd9c52d2d = external constant [0 x i8]
@olang_loc_5cf7683923427be1_eeed011b70fc7f3d = external constant [0 x i8]
@olang_loc_35262608d5eaeb07_a04d120ff2489083 = external constant [0 x i8]
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fmir_3aScopeRef_3e__H989114ff406840d3a5cfe99ba734fa56(ptr %v0, ptr %a0, i64 %a1)
declare { i32, { i64, [1 x i64] } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fmir_3aScopeRef_3e__H593d82357dc98d1f15fac9dd5b09c001(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_7c44d6a11fe580a3_63a95cd13601e77f = external constant [0 x i8]
declare i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddTemp(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2etextInto(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/lower:pl" %a1, i32 %a2, { i64, [1 x i64] } %a3, %"compiler/source:Span" %a4)
@olang_loc_a3627063ced14f10_5c0b773917422a84 = external constant [0 x i8]
@olang_loc_d8cada644e10ccc9_6a931382540e069d = external constant [0 x i8]
@olang_loc_73384406ab4916da_7af5324ba56268d6 = external constant [0 x i8]
declare i1 @compiler_2ftyped_2eHoldsOwned(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2flower_2ecompiler_2flower_3alowering_2eholderOf(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare ptr @compiler_2flower_2ecompiler_2flower_3alowering_2eholds(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0)
declare i1 @compiler_2ftyped_2ecompiler_2ftyped_3aDropHolding_2eHolds(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
@olang_loc_a2056f25c62d9699_4e0d363d21cfeded = external constant [0 x i8]
@olang_loc_cc04a371857641c8_2543c621c9fde23c = external constant [0 x i8]
@olang_loc_d2f9ab61c66bb7bd_ba20d4faed7cd6b1 = external constant [0 x i8]
declare { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aProj_3e_2eAt_3ccompiler_2fmir_3aProj_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aProj_3e_2ePush_3ccompiler_2fmir_3aProj_3e(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1)
@olang_loc_675153e339d777fd_a8094ea479968611 = external constant [0 x i8]
@olang_loc_e6acc166178563a1_2a0e2f77fd7658ed = external constant [0 x i8]
@olang_loc_eebb62a013643219_b45f662b48cacfad = external constant [0 x i8]
@olang_loc_18ba96ebd2acdd48_1f3e7581818ceffc = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_bb766f14be0b137b_665f548b94f1b77 = external constant [0 x i8]
declare i1 @compiler_2flower_2eplainOp(i32 %a0)
@olang_loc_2e98307d074351d_b88ce24c70947f99 = external constant [0 x i8]
@olang_loc_54e0eac7d28a4e33_3ccdd5ae0a31662f = external constant [0 x i8]
declare i1 @compiler_2flower_2ereadsPlace(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_dbe121105db3360d_c470698bff9d24c9 = external constant [0 x i8]
@olang_loc_337d65ed03186f15_b822a9c09cc6a119 = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %a0, i32 %a1)
declare void @compiler_2ftyped_3aBody_2ector(ptr %out, ptr %v0, i32 %a0, { i64, [2 x i64] } %a1, i32 %a2, i64 %a3, %"compiler/source:Span" %a4)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aProj_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBlockId_3e_2ector(ptr %v0, i64 %a0)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
