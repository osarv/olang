; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/typed:Try" = type { ptr, { i64, ptr }, i1, i1 }
%"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/lower:Lowerer" = type { ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i32, i32 }
%"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/typed:Body" = type { i32, { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1 }
%"compiler/mir:Fn" = type { { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i64 }
%"compiler/generic:Program" = type { ptr, ptr, %"compiler/types:Table", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"compiler/generic:Origin", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/types:Table" = type { ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/generic:Origin" = type { i64, %"compiler/source:Span", i64 }
%"compiler/lower:lowering" = type { ptr, ptr, ptr, %"compiler/mir:Fn", i64, { i64, [4 x i64] }, i32, i1, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i32, { i64, [1 x i64] }, %"compiler/typed:Plan", i1, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64 }
%"compiler/typed:Plan" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/mir:Range" = type { i32, i32 }
%"compiler/mir:Place" = type { { i64, [2 x i64] }, %"compiler/mir:Range" }
%"compiler/lower:level" = type { i32, i32, i32 }
%"compiler/typed:Arm" = type { %"compiler/source:Span", { i64, ptr }, ptr, ptr, ptr }
%"compiler/typed:Block" = type { i32, { i64, ptr } }
%"compiler/typed:Seq" = type { { i64, ptr }, ptr }
%"compiler/lower:tryCtx" = type { i64, { i64, ptr }, i1, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/typed:Item" = type { i32, i64 }
%"compiler/typed:Clause" = type { %"compiler/source:Span", { i64, ptr }, i1, ptr, { i64, ptr }, i64, i32 }
%"compiler/lower:pl" = type { { i64, [2 x i64] }, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/lower:Gap" = type { i64, %"compiler/source:Span", { i64, ptr } }
%"compiler/mir:Call" = type { { i64, [7 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/mir:Place", i1, i32, i32, i32 }
%"compiler/lower:loopCtx" = type { i32, i64, i32, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/typed:Match" = type { { i64, ptr }, { i64, ptr }, ptr, i1 }
%"compiler/typed:Alt" = type { ptr, { i64, ptr } }
%"compiler/typed:Bind" = type { i32, ptr }
%"compiler/typed:BlockInfo" = type { i32, i32, %"compiler/source:Span" }
%"compiler/typed:Payload" = type { ptr, i64, i32 }
%"compiler/mir:Case" = type { i64, i32 }
%"compiler/mir:Local" = type { i32, %"compiler/source:Span", i32, i32, { i64, [1 x i64] } }
%"compiler/typed:Cond" = type { ptr, ptr, ptr }
%"compiler/typed:Local" = type { i32, %"compiler/source:Span", i32, i32, i32, { i64, [2 x i64] } }
%"compiler/typed:Spawn" = type { { i64, ptr }, ptr, { i64, ptr }, i32 }
%"compiler/typed:TaskClause" = type { %"compiler/source:Span", { i64, ptr }, i1, ptr }
%"compiler/typed:If" = type { ptr, ptr, ptr }
%"compiler/typed:Text" = type { { i64, ptr }, i32 }
%"compiler/cond:Consts" = type { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/load:Loader" = type { { i64, ptr }, ptr, ptr, ptr, ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/names:Resolver" = type { ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/check:Checker" = type { ptr, ptr, i1, i1, i1, i1, i64, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, { i64, [3 x i64] }, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i32, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"compiler/source:Span", i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i32, i1, i1, %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", { i64, ptr }, i32, i32, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/fetch:Fetcher" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i1, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/source:Names" = type { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/diag:Diagnostics" = type { i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, i1, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, [3 x i64] }, { i64, ptr }, { i64, ptr }, i1 }
%"compiler/load:Module" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i64, i1, ptr, ptr, { i64, ptr }, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, ptr, ptr, i1, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/ast:Func" = type { %"compiler/source:Span", ptr, i32, ptr, { i64, ptr }, { i64, ptr }, i1, i1 }
%"compiler/typed:Make" = type { i32, i64, { i64, ptr }, ptr, i32, i32 }
%"compiler/lower:collectCtx" = type { i32, i32, i32, i32, { i64, [1 x i64] }, i1, i1 }
define dso_local void @compiler_2flower_2eInvalid_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 2, ptr @G_2ecompiler_2flower_2eInvalid, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flower_2eOutOfBounds_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr @G_2ecompiler_2flower_2eOutOfBounds, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2flower_2eclausedTry(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca ptr
  %l4 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  store i1 false, ptr %l4, !tbaa !21
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 14
  store i1 %t8, ptr %l4, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l4, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr %"compiler/typed:Try", ptr %t16, i32 0, i32 1
  %t19 = load { i64, ptr }, ptr %t18, !tbaa !27
  %t21 = extractvalue { i64, ptr } %t19, 0
  %t23 = icmp sgt i64 %t21, 0
  store i1 %t23, ptr %l2, !tbaa !21
  br label %bb11
bb6:
  br i1 true, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_fb323a156c70c4fe_3d15b87c8f91a072)
  unreachable
bb11:
  %t25 = load i1, ptr %l2, !tbaa !21
  store i1 %t25, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2flower_2ecompiler_2flower_3aLowerer_2eInitModules(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %lp1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l8 = alloca { i64, [2 x i64] }
  %l9 = alloca i64
  %l11 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l14 = alloca i64
  %l18 = alloca i64
  %l21 = alloca i64
  %l42 = alloca ptr
  %l51 = alloca i1
  %s2 = alloca %olang.scope
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %v1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l11
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 8, i64 8)
  store ptr %t2, ptr %lp1
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l11
  %t4 = load ptr, ptr %lp1
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %t4
  store i64 0, ptr %l2, !tbaa !24
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/lower:Lowerer", ptr %t5, i32 0, i32 1
  %t9 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_Ha6bcf4d517e3d7b46809e1dbf938da91(ptr %v0, ptr %t7)
  store i64 %t9, ptr %l14
  br label %bb2
bb2:
  %t10 = load i64, ptr %l14, !tbaa !24
  store i64 %t10, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t11 = load i64, ptr %l3, !tbaa !24
  %t12 = load i64, ptr %l2, !tbaa !24
  %t15 = icmp sgt i64 %t11, %t12
  br i1 %t15, label %bb3, label %bb4
bb3:
  %t17 = load i64, ptr %l4, !tbaa !24
  %t19 = icmp sgt i64 %t17, 0
  br i1 %t19, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l18, !tbaa !24
  br label %bb8
bb5:
  %t21 = load i64, ptr %l3, !tbaa !24
  %t22 = load i64, ptr %l2, !tbaa !24
  %t25 = sub i64 %t21, %t22
  %t26 = load i64, ptr %l4, !tbaa !24
  %t29 = add i64 %t25, %t26
  %t31 = sub i64 %t29, 1
  %t32 = load i64, ptr %l4, !tbaa !24
  %t35 = sdiv i64 %t31, %t32
  store i64 %t35, ptr %l21, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l21, !tbaa !24
  br label %bb7
bb7:
  %t37 = load i64, ptr %l21, !tbaa !24
  store i64 %t37, ptr %l18, !tbaa !24
  br label %bb8
bb8:
  %t38 = load i64, ptr %l18, !tbaa !24
  store i64 %t38, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t39 = load i64, ptr %l6, !tbaa !24
  %t40 = load i64, ptr %l5, !tbaa !24
  %t43 = icmp slt i64 %t39, %t40
  %t45 = xor i1 %t43, true
  br i1 %t45, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb29
bb11:
  br label %bb12
bb12:
  %t47 = load i64, ptr %l2, !tbaa !24
  %t48 = load i64, ptr %l6, !tbaa !24
  %t49 = load i64, ptr %l4, !tbaa !24
  %t52 = mul i64 %t48, %t49
  %t55 = add i64 %t47, %t52
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/lower:Lowerer", ptr %t57, i32 0, i32 1
  %t63 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t59, i64 %t55)
  store ptr %t63, ptr %l42
  br label %bb13
bb13:
  %t64 = load ptr, ptr %l42, !tbaa !29
  %t66 = getelementptr %"compiler/typed:Body", ptr %t64, i32 0, i32 1
  %t67 = load { i64, [2 x i64] }, ptr %t66
  store { i64, [2 x i64] } %t67, ptr %l8
  %t69 = load { i64, [2 x i64] }, ptr %l8
  %t71 = extractvalue { i64, [2 x i64] } %t69, 0
  %t72 = icmp eq i64 %t71, 6
  br i1 %t72, label %bb14, label %bb15
bb14:
  %t74 = getelementptr { i64, [2 x i64] }, ptr %l8, i32 0, i32 1
  %t75 = getelementptr { i64, i32 }, ptr %t74, i32 0, i32 0
  %t76 = load i64, ptr %t75
  store i64 %t76, ptr %l9, !tbaa !24
  br label %bb16
bb15:
  br label %bb22
bb16:
  %t78 = load i64, ptr %l9, !tbaa !24
  %t80 = load ptr, ptr %lp1
  %t84 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eHas_3cI64_3e(ptr %v1, ptr %t80, i64 %t78)
  store i1 %t84, ptr %l51
  br label %bb17
bb17:
  %t85 = load i1, ptr %l51, !tbaa !21
  %t86 = xor i1 %t85, true
  br i1 %t86, label %bb18, label %bb19
bb18:
  %t88 = load ptr, ptr %lp1
  %t89 = load i64, ptr %l9, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t88, i64 %t89)
  br label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb21
bb21:
  br label %bb27
bb22:
  br i1 true, label %bb23, label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb27
bb26:
  call void @__olang_check_failed(ptr @olang_loc_e3721461a855ef35_c24433bc0ae5f641)
  unreachable
bb27:
  call void @__olang_scope_close(ptr %s2)
  br label %bb28
bb28:
  %t92 = load i64, ptr %l6, !tbaa !24
  %t94 = add i64 %t92, 1
  store i64 %t94, ptr %l6, !tbaa !24
  br label %bb9
bb29:
  %t96 = load ptr, ptr %lp1
  %t97 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t96
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t97, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define dso_local { i1, { i64, ptr }, { i64, ptr } } @compiler_2flower_2ecompiler_2flower_3aLowerer_2eVerified(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i1 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca ptr
  %lp4 = alloca ptr
  %l8 = alloca %"compiler/mir:Fn"
  %l12 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l16 = alloca { i1, { i64, ptr }, { i64, ptr } }
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l39 = alloca { i1, { i64, ptr }, { i64, ptr } }
  %l40 = alloca { i64, ptr }
  %l41 = alloca i64
  %l42 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i1, { i64, ptr }, { i64, ptr } }
  %t3 = alloca %"compiler/mir:Fn", align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3aLowerer_2eLower(ptr %t3, ptr %v0, ptr %v0, ptr %t1, i64 %a1)
  call void @llvm.memmove.p0.p0.i64(ptr %l8, ptr %t3, i64 232, i1 false)
  br label %bb1
bb1:
  %t6 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 232, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t6, ptr %l8, i64 232, i1 false)
  store ptr %t6, ptr %l3, !tbaa !29
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/lower:Lowerer", ptr %t8, i32 0, i32 5
  %t11 = load i1, ptr %t10, !tbaa !21
  br i1 %t11, label %bb2, label %bb3
bb2:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d0, i32 0, i32 1) }, ptr %l12, !tbaa !27
  %t13 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d1, i32 0, i32 1) }, ptr %l14, !tbaa !27
  %t14 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t15 = insertvalue { i1, { i64, ptr }, { i64, ptr } } undef, i1 true, 0
  %t17 = insertvalue { i1, { i64, ptr }, { i64, ptr } } %t15, { i64, ptr } %t13, 1
  %t19 = insertvalue { i1, { i64, ptr }, { i64, ptr } } %t17, { i64, ptr } %t14, 2
  store { i1, { i64, ptr }, { i64, ptr } } %t19, ptr %l16
  %t20 = getelementptr { i1, { i64, ptr }, { i64, ptr } }, ptr %l16, i32 0, i32 1
  %t21 = load { i64, ptr }, ptr %t20, !tbaa !27
  store { i64, ptr } %t21, ptr %l17, !tbaa !27
  %t22 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t22, 0
  store i64 %t23, ptr %l18, !tbaa !24
  %t24 = load i64, ptr %l18, !tbaa !24
  %t25 = mul i64 %t24, 1
  %t26 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t25)
  %t27 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  store { i64, ptr } %t28, ptr %l19, !tbaa !27
  %t29 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !27
  %t31 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = load i64, ptr %l18, !tbaa !24
  %t34 = mul i64 %t33, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t30, ptr %t32, i64 %t34, i1 false)
  %t35 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t36 = getelementptr { i1, { i64, ptr }, { i64, ptr } }, ptr %l16, i32 0, i32 1
  store { i64, ptr } %t35, ptr %t36, !tbaa !27
  %t37 = getelementptr { i1, { i64, ptr }, { i64, ptr } }, ptr %l16, i32 0, i32 2
  %t38 = load { i64, ptr }, ptr %t37, !tbaa !27
  store { i64, ptr } %t38, ptr %l20, !tbaa !27
  %t39 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t40 = extractvalue { i64, ptr } %t39, 0
  store i64 %t40, ptr %l21, !tbaa !24
  %t41 = load i64, ptr %l21, !tbaa !24
  %t42 = mul i64 %t41, 1
  %t43 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t42)
  %t44 = insertvalue { i64, ptr } undef, i64 %t41, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t43, 1
  store { i64, ptr } %t45, ptr %l22, !tbaa !27
  %t46 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !27
  %t48 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !27
  %t50 = load i64, ptr %l21, !tbaa !24
  %t51 = mul i64 %t50, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t47, ptr %t49, i64 %t51, i1 false)
  %t52 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t53 = getelementptr { i1, { i64, ptr }, { i64, ptr } }, ptr %l16, i32 0, i32 2
  store { i64, ptr } %t52, ptr %t53, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t54 = load { i1, { i64, ptr }, { i64, ptr } }, ptr %l16
  store { i1, { i64, ptr }, { i64, ptr } } %t54, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t55 = load ptr, ptr %l3, !tbaa !29
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/lower:Lowerer", ptr %t56, i32 0, i32 0
  %t59 = load ptr, ptr %t58, !tbaa !29
  %t61 = getelementptr %"compiler/generic:Program", ptr %t59, i32 0, i32 2
  %t64 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3aFn_2eVerify(ptr %v0, ptr %v0, ptr %v1, ptr %t55, ptr %t61)
  store { i64, ptr } %t64, ptr %l27
  br label %bb5
bb5:
  %t65 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t65, ptr %lp4
  %t66 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t67 = load ptr, ptr %lp4
  store { i64, ptr } %t66, ptr %t67, !tbaa !27
  br i1 %a2, label %bb6, label %bb7
bb6:
  %t70 = load ptr, ptr %l3, !tbaa !29
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/lower:Lowerer", ptr %t71, i32 0, i32 0
  %t74 = load ptr, ptr %t73, !tbaa !29
  %t76 = getelementptr %"compiler/generic:Program", ptr %t74, i32 0, i32 2
  %t79 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3aFn_2eDump(ptr %v0, ptr %v0, ptr %s0, ptr %t70, ptr %t76)
  store { i64, ptr } %t79, ptr %l34
  br label %bb8
bb7:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d2, i32 0, i32 1) }, ptr %l29, !tbaa !27
  br label %bb9
bb8:
  %t80 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t81 = extractvalue { i64, ptr } %t80, 0
  %t82 = extractvalue { i64, ptr } %t80, 1
  %t83 = mul i64 %t81, 1
  %t84 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t83)
  call void @llvm.memcpy.p0.p0.i64(ptr %t84, ptr %t82, i64 %t83, i1 false)
  %t85 = insertvalue { i64, ptr } undef, i64 %t81, 0
  %t86 = insertvalue { i64, ptr } %t85, ptr %t84, 1
  store { i64, ptr } %t86, ptr %l29, !tbaa !27
  br label %bb9
bb9:
  %t88 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t89 = load ptr, ptr %lp4
  %t90 = load { i64, ptr }, ptr %t89, !tbaa !27
  %t93 = insertvalue { i1, { i64, ptr }, { i64, ptr } } undef, i1 false, 0
  %t95 = insertvalue { i1, { i64, ptr }, { i64, ptr } } %t93, { i64, ptr } %t90, 1
  %t97 = insertvalue { i1, { i64, ptr }, { i64, ptr } } %t95, { i64, ptr } %t88, 2
  store { i1, { i64, ptr }, { i64, ptr } } %t97, ptr %l39
  %t98 = getelementptr { i1, { i64, ptr }, { i64, ptr } }, ptr %l39, i32 0, i32 2
  %t99 = load { i64, ptr }, ptr %t98, !tbaa !27
  store { i64, ptr } %t99, ptr %l40, !tbaa !27
  %t100 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t101 = extractvalue { i64, ptr } %t100, 0
  store i64 %t101, ptr %l41, !tbaa !24
  %t102 = load i64, ptr %l41, !tbaa !24
  %t103 = mul i64 %t102, 1
  %t104 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t103)
  %t105 = insertvalue { i64, ptr } undef, i64 %t102, 0
  %t106 = insertvalue { i64, ptr } %t105, ptr %t104, 1
  store { i64, ptr } %t106, ptr %l42, !tbaa !27
  %t107 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t108 = load ptr, ptr %t107, !tbaa !27
  %t109 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t110 = load ptr, ptr %t109, !tbaa !27
  %t111 = load i64, ptr %l41, !tbaa !24
  %t112 = mul i64 %t111, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t108, ptr %t110, i64 %t112, i1 false)
  %t113 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t114 = getelementptr { i1, { i64, ptr }, { i64, ptr } }, ptr %l39, i32 0, i32 2
  store { i64, ptr } %t113, ptr %t114, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t115 = load { i1, { i64, ptr }, { i64, ptr } }, ptr %l39
  store { i1, { i64, ptr }, { i64, ptr } } %t115, ptr %rv
  br label %ret
ret:
  %rr = load { i1, { i64, ptr }, { i64, ptr } }, ptr %rv
  ret { i1, { i64, ptr }, { i64, ptr } } %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3aLowerer_2eadapterFn(ptr %out, ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i32
  %lp12 = alloca ptr
  %lp13 = alloca ptr
  %l18 = alloca ptr
  %l23 = alloca ptr
  %l28 = alloca i32
  %l29 = alloca { i64, ptr }
  %l32 = alloca i64
  %l41 = alloca i64
  %l44 = alloca i64
  %l63 = alloca { i64, ptr }
  %l71 = alloca ptr
  %l76 = alloca i32
  %l81 = alloca i32
  %l86 = alloca i32
  %l87 = alloca i32
  %l89 = alloca %"compiler/typed:Body"
  %l90 = alloca ptr
  %l91 = alloca ptr
  %l94 = alloca ptr
  %l99 = alloca %"compiler/mir:Fn"
  %l101 = alloca %"compiler/lower:lowering"
  %l105 = alloca { i64, ptr }
  %l109 = alloca %"compiler/mir:Fn"
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %t164 = alloca %"compiler/typed:Body", align 8
  %t178 = alloca { i64, [2 x i64] }, align 8
  %t185 = alloca %"compiler/mir:Fn", align 8
  %t190 = alloca %"compiler/lower:lowering", align 8
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:Lowerer", ptr %t1, i32 0, i32 1
  %t4 = load i32, ptr %l1, !tbaa !23
  %t6 = sext i32 %t4 to i64
  %t9 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t3, i64 %t6)
  store ptr %t9, ptr %l18
  br label %bb1
bb1:
  %t10 = load ptr, ptr %l18, !tbaa !29
  %t12 = getelementptr %"compiler/typed:Body", ptr %t10, i32 0, i32 2
  %t13 = load i32, ptr %t12, !tbaa !23
  store i32 %t13, ptr %l2, !tbaa !23
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/lower:Lowerer", ptr %t15, i32 0, i32 0
  %t18 = load ptr, ptr %t17, !tbaa !29
  %t20 = getelementptr %"compiler/generic:Program", ptr %t18, i32 0, i32 2
  store ptr %t20, ptr %l23, !tbaa !29
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/lower:Lowerer", ptr %t21, i32 0, i32 0
  %t24 = load ptr, ptr %t23, !tbaa !29
  %t26 = getelementptr %"compiler/generic:Program", ptr %t24, i32 0, i32 2
  %t27 = load i32, ptr %l2, !tbaa !23
  %t30 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t26, i32 %t27)
  store i32 %t30, ptr %l28
  br label %bb2
bb2:
  %t31 = load ptr, ptr %l23, !tbaa !29
  %t32 = load i32, ptr %l28, !tbaa !23
  %t33 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t31, i32 %t32)
  store { i64, ptr } %t33, ptr %l29
  br label %bb3
bb3:
  %t34 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t34, ptr %l3, !tbaa !27
  %t35 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t37 = extractvalue { i64, ptr } %t35, 0
  %t39 = sub i64 %t37, 1
  store i64 %t39, ptr %l32, !tbaa !24
  %t40 = load i64, ptr %l32, !tbaa !24
  %t41 = icmp sge i64 %t40, 0
  br i1 %t41, label %bb4, label %bb5
bb4:
  %t43 = load i64, ptr %l32, !tbaa !24
  %t44 = icmp sle i64 %t43, 2305843009213693951
  br i1 %t44, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_4e4c17ebfaf5d7b6_624a73934957b6f2)
  unreachable
bb6:
  %t46 = load i64, ptr %l32, !tbaa !24
  %t47 = mul i64 %t46, 4
  %t48 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t47)
  %t49 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t50 = insertvalue { i64, ptr } %t49, ptr %t48, 1
  store { i64, ptr } %t50, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t52 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t54 = extractvalue { i64, ptr } %t52, 0
  store i64 %t54, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t56 = load i64, ptr %l6, !tbaa !24
  %t57 = load i64, ptr %l5, !tbaa !24
  %t60 = icmp sgt i64 %t56, %t57
  br i1 %t60, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_4e4c17ebfaf5d7b6_624a73934957b6f2)
  unreachable
bb8:
  %t62 = load i64, ptr %l7, !tbaa !24
  %t64 = icmp sgt i64 %t62, 0
  br i1 %t64, label %bb10, label %bb11
bb9:
  store i64 0, ptr %l41, !tbaa !24
  br label %bb13
bb10:
  %t66 = load i64, ptr %l6, !tbaa !24
  %t67 = load i64, ptr %l5, !tbaa !24
  %t70 = sub i64 %t66, %t67
  %t71 = load i64, ptr %l7, !tbaa !24
  %t74 = add i64 %t70, %t71
  %t76 = sub i64 %t74, 1
  %t77 = load i64, ptr %l7, !tbaa !24
  %t80 = sdiv i64 %t76, %t77
  store i64 %t80, ptr %l44, !tbaa !24
  br label %bb12
bb11:
  store i64 0, ptr %l44, !tbaa !24
  br label %bb12
bb12:
  %t82 = load i64, ptr %l44, !tbaa !24
  store i64 %t82, ptr %l41, !tbaa !24
  br label %bb13
bb13:
  %t83 = load i64, ptr %l41, !tbaa !24
  store i64 %t83, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb14
bb14:
  store %olang.scope zeroinitializer, ptr %s2
  %t84 = load i64, ptr %l9, !tbaa !24
  %t85 = load i64, ptr %l8, !tbaa !24
  %t88 = icmp slt i64 %t84, %t85
  %t90 = xor i1 %t88, true
  br i1 %t90, label %bb15, label %bb16
bb15:
  call void @__olang_scope_close(ptr %s2)
  br label %bb19
bb16:
  br label %bb17
bb17:
  %t92 = load i64, ptr %l5, !tbaa !24
  %t93 = load i64, ptr %l9, !tbaa !24
  %t94 = load i64, ptr %l7, !tbaa !24
  %t97 = mul i64 %t93, %t94
  %t100 = add i64 %t92, %t97
  store i64 %t100, ptr %l10, !tbaa !24
  %t102 = load i64, ptr %l10, !tbaa !24
  %t103 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t103, ptr %l63, !tbaa !27
  %t104 = load i64, ptr %l10, !tbaa !24
  %t106 = add i64 %t104, 1
  %t108 = getelementptr { i64, ptr }, ptr %l63, i32 0, i32 1
  %t109 = load ptr, ptr %t108, !tbaa !27
  %t110 = getelementptr i32, ptr %t109, i64 %t106
  %t111 = load i32, ptr %t110, !tbaa !33
  %t114 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t115 = load ptr, ptr %t114, !tbaa !27
  %t116 = getelementptr i32, ptr %t115, i64 %t102
  store i32 %t111, ptr %t116, !tbaa !33
  call void @__olang_scope_close(ptr %s2)
  br label %bb18
bb18:
  %t117 = load i64, ptr %l9, !tbaa !24
  %t119 = add i64 %t117, 1
  store i64 %t119, ptr %l9, !tbaa !24
  br label %bb14
bb19:
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t123 = getelementptr %"compiler/lower:Lowerer", ptr %t121, i32 0, i32 0
  %t124 = load ptr, ptr %t123, !tbaa !29
  %t126 = getelementptr %"compiler/generic:Program", ptr %t124, i32 0, i32 2
  store ptr %t126, ptr %l71, !tbaa !29
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t129 = getelementptr %"compiler/lower:Lowerer", ptr %t127, i32 0, i32 0
  %t130 = load ptr, ptr %t129, !tbaa !29
  %t132 = getelementptr %"compiler/generic:Program", ptr %t130, i32 0, i32 2
  %t133 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t136 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s0, ptr %t132, { i64, ptr } %t133)
  store i32 %t136, ptr %l76
  br label %bb20
bb20:
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t139 = getelementptr %"compiler/lower:Lowerer", ptr %t137, i32 0, i32 0
  %t140 = load ptr, ptr %t139, !tbaa !29
  %t142 = getelementptr %"compiler/generic:Program", ptr %t140, i32 0, i32 2
  %t143 = load i32, ptr %l2, !tbaa !23
  %t146 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t142, i32 %t143)
  store i32 %t146, ptr %l81
  br label %bb21
bb21:
  %t147 = load ptr, ptr %l0, !tbaa !29
  %t149 = getelementptr %"compiler/lower:Lowerer", ptr %t147, i32 0, i32 0
  %t150 = load ptr, ptr %t149, !tbaa !29
  %t152 = getelementptr %"compiler/generic:Program", ptr %t150, i32 0, i32 2
  %t153 = load i32, ptr %l2, !tbaa !23
  %t156 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t152, i32 %t153)
  store i32 %t156, ptr %l86
  br label %bb22
bb22:
  %t157 = load ptr, ptr %l71, !tbaa !29
  %t158 = load i32, ptr %l76, !tbaa !23
  %t159 = load i32, ptr %l81, !tbaa !23
  %t160 = load i32, ptr %l86, !tbaa !23
  %t161 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t157, i32 %t158, i32 %t159, i32 %t160, i32 0, i64 0)
  store i32 %t161, ptr %l87
  br label %bb23
bb23:
  %t162 = load i32, ptr %l87, !tbaa !23
  store i32 %t162, ptr %l11, !tbaa !23
  %t163 = load i32, ptr %l11, !tbaa !23
  call void @compiler_2flower_2estandIn(ptr %t164, ptr %v1, i32 %t163)
  call void @llvm.memmove.p0.p0.i64(ptr %l89, ptr %t164, i64 144, i1 false)
  br label %bb24
bb24:
  %t166 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 144, i64 8)
  store ptr %t166, ptr %lp12
  %t167 = load ptr, ptr %lp12
  call void @llvm.memmove.p0.p0.i64(ptr %t167, ptr %l89, i64 144, i1 false)
  %t168 = load ptr, ptr %l0, !tbaa !29
  store ptr %t168, ptr %l90, !tbaa !29
  %t169 = load ptr, ptr %lp12
  store ptr %t169, ptr %l91, !tbaa !29
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t172 = getelementptr %"compiler/lower:Lowerer", ptr %t170, i32 0, i32 0
  %t173 = load ptr, ptr %t172, !tbaa !29
  %t175 = getelementptr %"compiler/generic:Program", ptr %t173, i32 0, i32 2
  store ptr %t175, ptr %l94, !tbaa !29
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t177 = load i32, ptr %l1, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t178
  %t179 = getelementptr { i64, [2 x i64] }, ptr %t178, i32 0, i32 0
  store i64 1, ptr %t179
  %t181 = insertvalue { i32 } undef, i32 %t177, 0
  %t182 = getelementptr { i64, [2 x i64] }, ptr %t178, i32 0, i32 1
  store { i32 } %t181, ptr %t182
  %t183 = load { i64, [2 x i64] }, ptr %t178
  %t184 = load i32, ptr %l11, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3aLowerer_2ebare(ptr %t185, ptr %v0, ptr %v1, ptr %t176, { i64, [2 x i64] } %t183, i32 %t184)
  call void @llvm.memmove.p0.p0.i64(ptr %l99, ptr %t185, i64 232, i1 false)
  br label %bb25
bb25:
  %t189 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 232, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t189, ptr %l99, i64 232, i1 false)
  %t191 = load ptr, ptr %l90, !tbaa !29
  %t192 = load ptr, ptr %l91, !tbaa !29
  %t193 = load ptr, ptr %l94, !tbaa !29
  call void @compiler_2flower_3alowering_2ector(ptr %t190, ptr %v0, ptr %v1, ptr %v0, ptr %v1, ptr %v1, ptr %t191, ptr %t192, ptr %t193, ptr %t189)
  call void @llvm.memmove.p0.p0.i64(ptr %l101, ptr %t190, i64 584, i1 false)
  br label %bb26
bb26:
  %t195 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 584, i64 8)
  store ptr %t195, ptr %lp13
  %t196 = load ptr, ptr %lp13
  call void @llvm.memmove.p0.p0.i64(ptr %t196, ptr %l101, i64 584, i1 false)
  %t197 = load ptr, ptr %lp13
  %t198 = load i32, ptr %l1, !tbaa !23
  %t199 = load i32, ptr %l2, !tbaa !23
  %t200 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t200, ptr %l105, !tbaa !27
  %t201 = getelementptr { i64, ptr }, ptr %l105, i32 0, i32 1
  %t202 = load ptr, ptr %t201, !tbaa !27
  %t203 = getelementptr i32, ptr %t202, i64 0
  %t204 = load i32, ptr %t203, !tbaa !33
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eadapterBody(ptr %v1, ptr %t197, i32 %t198, i32 %t199, i32 %t204)
  br label %bb27
bb27:
  %t209 = load ptr, ptr %l0, !tbaa !29
  %t210 = load ptr, ptr %lp13
  %t211 = getelementptr %"compiler/lower:lowering", ptr %t210, i32 0, i32 8
  %t212 = load i1, ptr %t211, !tbaa !21
  %t215 = getelementptr %"compiler/lower:Lowerer", ptr %t209, i32 0, i32 5
  store i1 %t212, ptr %t215, !tbaa !21
  %t216 = load ptr, ptr %lp13
  %t217 = getelementptr %"compiler/lower:lowering", ptr %t216, i32 0, i32 3
  call void @llvm.memmove.p0.p0.i64(ptr %l109, ptr %t217, i64 232, i1 false)
  call void @__olang_scope_close(ptr %s0)
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l109, i64 232, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2flower_2ecompiler_2flower_3aLowerer_2echar(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca ptr
  %l7 = alloca i32
  %s1 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:Lowerer", ptr %t1, i32 0, i32 15
  %t4 = load i32, ptr %t3, !tbaa !23
  %t6 = icmp slt i32 %t4, 0
  br i1 %t6, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t8 = load ptr, ptr %l0, !tbaa !29
  store ptr %t8, ptr %l4, !tbaa !29
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/lower:Lowerer", ptr %t9, i32 0, i32 0
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t14 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ePreludeType(ptr %v0, ptr %s1, ptr %s1, ptr %t12, { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d3, i32 0, i32 1) }, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d4, i32 0, i32 1) })
  store i32 %t14, ptr %l7
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t15 = load i32, ptr %l7, !tbaa !23
  %t16 = load ptr, ptr %l4, !tbaa !29
  %t17 = getelementptr %"compiler/lower:Lowerer", ptr %t16, i32 0, i32 15
  store i32 %t15, ptr %t17, !tbaa !23
  call void @__olang_scope_close(ptr %s1)
  br label %bb4
bb4:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/lower:Lowerer", ptr %t18, i32 0, i32 15
  %t21 = load i32, ptr %t20, !tbaa !23
  store i32 %t21, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i32, i64 } @compiler_2flower_2ecompiler_2flower_3aLowerer_2efailure(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca i32
  %l12 = alloca i64
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l22 = alloca i64
  %l29 = alloca i64
  %l32 = alloca i64
  %l60 = alloca i32
  %l65 = alloca ptr
  %l70 = alloca i32
  %l71 = alloca { i64, ptr }
  %l77 = alloca i64
  %l80 = alloca i64
  %l101 = alloca { i64, ptr }
  %l104 = alloca { i64, ptr }
  %l106 = alloca i1
  %l122 = alloca i32
  %l126 = alloca i64
  %s3 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca { i32, i64 }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:Lowerer", ptr %t1, i32 0, i32 13
  %t5 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l22
  br label %bb1
bb1:
  %t6 = load i64, ptr %l22, !tbaa !24
  %t7 = icmp eq i64 %t6, 0
  br i1 %t7, label %bb2, label %bb3
bb2:
  store i64 0, ptr %l2, !tbaa !24
  %t9 = load [6 x { i64, ptr }], ptr @G_2ecompiler_2flower_2eFailIds
  store i64 6, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t12 = load i64, ptr %l3, !tbaa !24
  %t13 = load i64, ptr %l2, !tbaa !24
  %t16 = icmp sgt i64 %t12, %t13
  br i1 %t16, label %bb4, label %bb5
bb3:
  br label %bb41
bb4:
  %t18 = load i64, ptr %l4, !tbaa !24
  %t20 = icmp sgt i64 %t18, 0
  br i1 %t20, label %bb6, label %bb7
bb5:
  store i64 0, ptr %l29, !tbaa !24
  br label %bb9
bb6:
  %t22 = load i64, ptr %l3, !tbaa !24
  %t23 = load i64, ptr %l2, !tbaa !24
  %t26 = sub i64 %t22, %t23
  %t27 = load i64, ptr %l4, !tbaa !24
  %t30 = add i64 %t26, %t27
  %t32 = sub i64 %t30, 1
  %t33 = load i64, ptr %l4, !tbaa !24
  %t36 = sdiv i64 %t32, %t33
  store i64 %t36, ptr %l32, !tbaa !24
  br label %bb8
bb7:
  store i64 0, ptr %l32, !tbaa !24
  br label %bb8
bb8:
  %t38 = load i64, ptr %l32, !tbaa !24
  store i64 %t38, ptr %l29, !tbaa !24
  br label %bb9
bb9:
  %t39 = load i64, ptr %l29, !tbaa !24
  store i64 %t39, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s3
  %t40 = load i64, ptr %l6, !tbaa !24
  %t41 = load i64, ptr %l5, !tbaa !24
  %t44 = icmp slt i64 %t40, %t41
  %t46 = xor i1 %t44, true
  br i1 %t46, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s3)
  br label %bb40
bb12:
  br label %bb13
bb13:
  %t48 = load i64, ptr %l2, !tbaa !24
  %t49 = load i64, ptr %l6, !tbaa !24
  %t50 = load i64, ptr %l4, !tbaa !24
  %t53 = mul i64 %t49, %t50
  %t56 = add i64 %t48, %t53
  store i64 %t56, ptr %l7, !tbaa !24
  %t58 = load i64, ptr %l7, !tbaa !24
  %t60 = getelementptr [6 x { i64, ptr }], ptr @G_2ecompiler_2flower_2eFailIds, i64 0, i64 %t58
  %t61 = load { i64, ptr }, ptr %t60, !tbaa !37
  %t63 = load i64, ptr %l7, !tbaa !24
  %t65 = getelementptr [6 x { i64, ptr }], ptr @G_2ecompiler_2flower_2eFailTypes, i64 0, i64 %t63
  %t66 = load { i64, ptr }, ptr %t65, !tbaa !37
  %t68 = load i64, ptr %l7, !tbaa !24
  %t70 = getelementptr [6 x { i64, ptr }], ptr @G_2ecompiler_2flower_2eFailWords, i64 0, i64 %t68
  %t71 = load { i64, ptr }, ptr %t70, !tbaa !37
  store { i64, ptr } %t71, ptr %l10, !tbaa !27
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/lower:Lowerer", ptr %t73, i32 0, i32 0
  %t76 = load ptr, ptr %t75, !tbaa !29
  %t79 = load ptr, ptr @__olang_prog_scope
  %t80 = load ptr, ptr @__olang_prog_scope
  %t84 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ePreludeType(ptr %v0, ptr %t79, ptr %t80, ptr %t76, { i64, ptr } %t61, { i64, ptr } %t66)
  store i32 %t84, ptr %l60
  br label %bb14
bb14:
  %t85 = load i32, ptr %l60, !tbaa !23
  store i32 %t85, ptr %l11, !tbaa !23
  store i64 65536, ptr %l12, !tbaa !24
  %t86 = load i32, ptr %l11, !tbaa !23
  %t87 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t90 = icmp ne i32 %t86, %t87
  br i1 %t90, label %bb15, label %bb16
bb15:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"compiler/lower:Lowerer", ptr %t92, i32 0, i32 0
  %t95 = load ptr, ptr %t94, !tbaa !29
  store ptr %t95, ptr %l65, !tbaa !29
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"compiler/lower:Lowerer", ptr %t96, i32 0, i32 0
  %t99 = load ptr, ptr %t98, !tbaa !29
  %t101 = getelementptr %"compiler/generic:Program", ptr %t99, i32 0, i32 2
  %t102 = load i32, ptr %l11, !tbaa !23
  %t105 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t101, i32 %t102)
  store i32 %t105, ptr %l70
  br label %bb17
bb16:
  br label %bb36
bb17:
  %t106 = load ptr, ptr %l65, !tbaa !29
  %t107 = load i32, ptr %l70, !tbaa !23
  %t108 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorWords(ptr %v0, ptr %t106, i32 %t107)
  store { i64, ptr } %t108, ptr %l71
  br label %bb18
bb18:
  %t109 = load { i64, ptr }, ptr %l71, !tbaa !27
  store { i64, ptr } %t109, ptr %l13, !tbaa !27
  store i64 0, ptr %l14, !tbaa !24
  %t110 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t112 = extractvalue { i64, ptr } %t110, 0
  store i64 %t112, ptr %l15, !tbaa !24
  store i64 1, ptr %l16, !tbaa !24
  %t114 = load i64, ptr %l15, !tbaa !24
  %t115 = load i64, ptr %l14, !tbaa !24
  %t118 = icmp sgt i64 %t114, %t115
  br i1 %t118, label %bb19, label %bb20
bb19:
  %t120 = load i64, ptr %l16, !tbaa !24
  %t122 = icmp sgt i64 %t120, 0
  br i1 %t122, label %bb21, label %bb22
bb20:
  store i64 0, ptr %l77, !tbaa !24
  br label %bb24
bb21:
  %t124 = load i64, ptr %l15, !tbaa !24
  %t125 = load i64, ptr %l14, !tbaa !24
  %t128 = sub i64 %t124, %t125
  %t129 = load i64, ptr %l16, !tbaa !24
  %t132 = add i64 %t128, %t129
  %t134 = sub i64 %t132, 1
  %t135 = load i64, ptr %l16, !tbaa !24
  %t138 = sdiv i64 %t134, %t135
  store i64 %t138, ptr %l80, !tbaa !24
  br label %bb23
bb22:
  store i64 0, ptr %l80, !tbaa !24
  br label %bb23
bb23:
  %t140 = load i64, ptr %l80, !tbaa !24
  store i64 %t140, ptr %l77, !tbaa !24
  br label %bb24
bb24:
  %t141 = load i64, ptr %l77, !tbaa !24
  store i64 %t141, ptr %l17, !tbaa !24
  store i64 0, ptr %l18, !tbaa !24
  br label %bb25
bb25:
  store %olang.scope zeroinitializer, ptr %s6
  %t142 = load i64, ptr %l18, !tbaa !24
  %t143 = load i64, ptr %l17, !tbaa !24
  %t146 = icmp slt i64 %t142, %t143
  %t148 = xor i1 %t146, true
  br i1 %t148, label %bb26, label %bb27
bb26:
  call void @__olang_scope_close(ptr %s6)
  br label %bb35
bb27:
  br label %bb28
bb28:
  %t150 = load i64, ptr %l14, !tbaa !24
  %t151 = load i64, ptr %l18, !tbaa !24
  %t152 = load i64, ptr %l16, !tbaa !24
  %t155 = mul i64 %t151, %t152
  %t158 = add i64 %t150, %t155
  store i64 %t158, ptr %l19, !tbaa !24
  %t160 = load ptr, ptr %l0, !tbaa !29
  %t162 = getelementptr %"compiler/lower:Lowerer", ptr %t160, i32 0, i32 0
  %t163 = load ptr, ptr %t162, !tbaa !29
  %t165 = getelementptr %"compiler/generic:Program", ptr %t163, i32 0, i32 2
  %t166 = getelementptr %"compiler/types:Table", ptr %t165, i32 0, i32 0
  %t167 = load ptr, ptr %t166, !tbaa !29
  %t168 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t168, ptr %l101, !tbaa !27
  %t169 = load i64, ptr %l19, !tbaa !24
  %t171 = getelementptr { i64, ptr }, ptr %l101, i32 0, i32 1
  %t172 = load ptr, ptr %t171, !tbaa !27
  %t173 = getelementptr i32, ptr %t172, i64 %t169
  %t174 = load i32, ptr %t173, !tbaa !33
  %t177 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t167, i32 %t174)
  store { i64, ptr } %t177, ptr %l104
  br label %bb29
bb29:
  %t178 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t179 = load ptr, ptr @__olang_prog_scope
  %t180 = load { i64, ptr }, ptr %l104, !tbaa !27
  %t182 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %t179, { i64, ptr } %t180, { i64, ptr } %t178)
  store i1 %t182, ptr %l106
  br label %bb30
bb30:
  %t183 = load i1, ptr %l106, !tbaa !21
  br i1 %t183, label %bb31, label %bb32
bb31:
  %t184 = load i64, ptr %l19, !tbaa !24
  %t186 = or i64 65536, %t184
  store i64 %t186, ptr %l12, !tbaa !24
  br label %bb33
bb32:
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s6)
  br label %bb34
bb34:
  %t188 = load i64, ptr %l18, !tbaa !24
  %t190 = add i64 %t188, 1
  store i64 %t190, ptr %l18, !tbaa !24
  br label %bb25
bb35:
  br label %bb36
bb36:
  %t192 = load ptr, ptr %l0, !tbaa !29
  %t194 = getelementptr %"compiler/lower:Lowerer", ptr %t192, i32 0, i32 13
  %t195 = load i32, ptr %l11, !tbaa !23
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t194, i32 %t195)
  br label %bb37
bb37:
  %t198 = load ptr, ptr %l0, !tbaa !29
  %t200 = getelementptr %"compiler/lower:Lowerer", ptr %t198, i32 0, i32 14
  %t201 = load i64, ptr %l12, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t200, i64 %t201)
  br label %bb38
bb38:
  call void @__olang_scope_close(ptr %s3)
  br label %bb39
bb39:
  %t204 = load i64, ptr %l6, !tbaa !24
  %t206 = add i64 %t204, 1
  store i64 %t206, ptr %l6, !tbaa !24
  br label %bb10
bb40:
  br label %bb41
bb41:
  %t208 = load ptr, ptr %l0, !tbaa !29
  %t210 = getelementptr %"compiler/lower:Lowerer", ptr %t208, i32 0, i32 13
  %t211 = load i64, ptr %l1, !tbaa !24
  %t214 = call i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t210, i64 %t211)
  store i32 %t214, ptr %l122
  br label %bb42
bb42:
  %t215 = load ptr, ptr %l0, !tbaa !29
  %t217 = getelementptr %"compiler/lower:Lowerer", ptr %t215, i32 0, i32 14
  %t218 = load i64, ptr %l1, !tbaa !24
  %t221 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t217, i64 %t218)
  store i64 %t221, ptr %l126
  br label %bb43
bb43:
  %t222 = load i32, ptr %l122, !tbaa !23
  %t223 = insertvalue { i32, i64 } undef, i32 %t222, 0
  %t224 = load i64, ptr %l126, !tbaa !24
  %t225 = insertvalue { i32, i64 } %t223, i64 %t224, 1
  store { i32, i64 } %t225, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i64 }, ptr %rv
  ret { i32, i64 } %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3aLowerer_2eindex(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca { i64, [2 x i64] }
  %l8 = alloca i32
  %l9 = alloca i32
  %l15 = alloca i64
  %l19 = alloca i64
  %l22 = alloca i64
  %l43 = alloca ptr
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:Lowerer", ptr %t1, i32 0, i32 12
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/lower:Lowerer", ptr %t6, i32 0, i32 12
  store i1 true, ptr %t8, !tbaa !21
  store i64 0, ptr %l1, !tbaa !24
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/lower:Lowerer", ptr %t9, i32 0, i32 1
  %t13 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_Ha6bcf4d517e3d7b46809e1dbf938da91(ptr %v0, ptr %t11)
  store i64 %t13, ptr %l15
  br label %bb4
bb4:
  %t14 = load i64, ptr %l15, !tbaa !24
  store i64 %t14, ptr %l2, !tbaa !24
  store i64 1, ptr %l3, !tbaa !24
  %t15 = load i64, ptr %l2, !tbaa !24
  %t16 = load i64, ptr %l1, !tbaa !24
  %t19 = icmp sgt i64 %t15, %t16
  br i1 %t19, label %bb5, label %bb6
bb5:
  %t21 = load i64, ptr %l3, !tbaa !24
  %t23 = icmp sgt i64 %t21, 0
  br i1 %t23, label %bb7, label %bb8
bb6:
  store i64 0, ptr %l19, !tbaa !24
  br label %bb10
bb7:
  %t25 = load i64, ptr %l2, !tbaa !24
  %t26 = load i64, ptr %l1, !tbaa !24
  %t29 = sub i64 %t25, %t26
  %t30 = load i64, ptr %l3, !tbaa !24
  %t33 = add i64 %t29, %t30
  %t35 = sub i64 %t33, 1
  %t36 = load i64, ptr %l3, !tbaa !24
  %t39 = sdiv i64 %t35, %t36
  store i64 %t39, ptr %l22, !tbaa !24
  br label %bb9
bb8:
  store i64 0, ptr %l22, !tbaa !24
  br label %bb9
bb9:
  %t41 = load i64, ptr %l22, !tbaa !24
  store i64 %t41, ptr %l19, !tbaa !24
  br label %bb10
bb10:
  %t42 = load i64, ptr %l19, !tbaa !24
  store i64 %t42, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb11
bb11:
  store %olang.scope zeroinitializer, ptr %s3
  %t43 = load i64, ptr %l5, !tbaa !24
  %t44 = load i64, ptr %l4, !tbaa !24
  %t47 = icmp slt i64 %t43, %t44
  %t49 = xor i1 %t47, true
  br i1 %t49, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s3)
  br label %bb30
bb13:
  br label %bb14
bb14:
  %t51 = load i64, ptr %l1, !tbaa !24
  %t52 = load i64, ptr %l5, !tbaa !24
  %t53 = load i64, ptr %l3, !tbaa !24
  %t56 = mul i64 %t52, %t53
  %t59 = add i64 %t51, %t56
  store i64 %t59, ptr %l6, !tbaa !24
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = getelementptr %"compiler/lower:Lowerer", ptr %t61, i32 0, i32 1
  %t64 = load i64, ptr %l6, !tbaa !24
  %t67 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t63, i64 %t64)
  store ptr %t67, ptr %l43
  br label %bb15
bb15:
  %t68 = load ptr, ptr %l43, !tbaa !29
  %t70 = getelementptr %"compiler/typed:Body", ptr %t68, i32 0, i32 1
  %t71 = load { i64, [2 x i64] }, ptr %t70
  store { i64, [2 x i64] } %t71, ptr %l7
  %t73 = load { i64, [2 x i64] }, ptr %l7
  %t75 = extractvalue { i64, [2 x i64] } %t73, 0
  %t76 = icmp eq i64 %t75, 1
  br i1 %t76, label %bb16, label %bb17
bb16:
  %t78 = getelementptr { i64, [2 x i64] }, ptr %l7, i32 0, i32 1
  %t79 = getelementptr { i32, i32 }, ptr %t78, i32 0, i32 0
  %t80 = load i32, ptr %t79
  store i32 %t80, ptr %l8, !tbaa !23
  %t82 = getelementptr { i64, [2 x i64] }, ptr %l7, i32 0, i32 1
  %t83 = getelementptr { i32, i32 }, ptr %t82, i32 0, i32 1
  %t84 = load i32, ptr %t83
  store i32 %t84, ptr %l9, !tbaa !23
  br label %bb18
bb17:
  br label %bb23
bb18:
  %t86 = load i32, ptr %l9, !tbaa !23
  %t88 = icmp eq i32 %t86, 0
  br i1 %t88, label %bb19, label %bb20
bb19:
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t92 = getelementptr %"compiler/lower:Lowerer", ptr %t90, i32 0, i32 10
  %t93 = load i32, ptr %l8, !tbaa !23
  %t94 = load i64, ptr %l6, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e__Hccd9659a44f570da1fa06b019882a84d(ptr %v0, ptr %t92, i32 %t93, i64 %t94)
  br label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb22
bb22:
  br label %bb28
bb23:
  br i1 true, label %bb24, label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb28
bb27:
  call void @__olang_check_failed(ptr @olang_loc_3aca88f8a70b165c_61af268fc3dc2410)
  unreachable
bb28:
  call void @__olang_scope_close(ptr %s3)
  br label %bb29
bb29:
  %t98 = load i64, ptr %l5, !tbaa !24
  %t100 = add i64 %t98, 1
  store i64 %t100, ptr %l5, !tbaa !24
  br label %bb11
bb30:
  br label %ret
ret:
  ret void
}

define dso_local { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eadapter(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2, i32 %a3, i32 %a4, %"compiler/source:Span" %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l3 = alloca i32
  %l4 = alloca i32
  %l6 = alloca { i64, [4 x i64] }
  %l10 = alloca { i64, [4 x i64] }
  %l18 = alloca ptr
  %l19 = alloca i32
  %l21 = alloca { i64, [2 x i64] }
  %l22 = alloca i32
  %l25 = alloca { i64, [1 x i64] }
  %l29 = alloca { i64, ptr }
  %l30 = alloca %"compiler/mir:Range"
  %l33 = alloca %"compiler/mir:Range"
  %l36 = alloca { i64, [4 x i64] }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, [4 x i64] }
  %t13 = alloca { i64, [4 x i64] }, align 8
  %t22 = alloca { i64, [2 x i64] }, align 8
  %t33 = alloca { i64, [2 x i64] }, align 8
  %t65 = alloca { i64, [15 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a3, ptr %l3
  store i32 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t6 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v1, ptr %t1, ptr %a2)
  store { i64, [4 x i64] } %t6, ptr %l10
  br label %bb1
bb1:
  %t7 = load { i64, [4 x i64] }, ptr %l10
  store { i64, [4 x i64] } %t7, ptr %l6
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/lower:lowering", ptr %t8, i32 0, i32 7
  %t11 = load i1, ptr %t10, !tbaa !21
  br i1 %t11, label %bb2, label %bb3
bb2:
  store { i64, [4 x i64] } zeroinitializer, ptr %t13
  %t14 = getelementptr { i64, [4 x i64] }, ptr %t13, i32 0, i32 0
  store i64 0, ptr %t14
  %t15 = load { i64, [4 x i64] }, ptr %t13
  call void @__olang_scope_close(ptr %s0)
  store { i64, [4 x i64] } %t15, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/lower:lowering", ptr %t17, i32 0, i32 0
  %t20 = load ptr, ptr %t19, !tbaa !29
  %t21 = load i32, ptr %l1, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t22
  %t23 = getelementptr { i64, [2 x i64] }, ptr %t22, i32 0, i32 0
  store i64 1, ptr %t23
  %t25 = insertvalue { i32 } undef, i32 %t21, 0
  %t26 = getelementptr { i64, [2 x i64] }, ptr %t22, i32 0, i32 1
  store { i32 } %t25, ptr %t26
  %t27 = load { i64, [2 x i64] }, ptr %t22
  call void @compiler_2flower_2ecompiler_2flower_3aLowerer_2eWant(ptr %v0, ptr %t20, { i64, [2 x i64] } %t27)
  br label %bb5
bb5:
  %t30 = load ptr, ptr %l0, !tbaa !29
  store ptr %t30, ptr %l18, !tbaa !29
  %t31 = load i32, ptr %l4, !tbaa !23
  store i32 %t31, ptr %l19, !tbaa !23
  %t32 = load i32, ptr %l1, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t33
  %t34 = getelementptr { i64, [2 x i64] }, ptr %t33, i32 0, i32 0
  store i64 1, ptr %t34
  %t36 = insertvalue { i32 } undef, i32 %t32, 0
  %t37 = getelementptr { i64, [2 x i64] }, ptr %t33, i32 0, i32 1
  store { i32 } %t36, ptr %t37
  %t38 = load { i64, [2 x i64] }, ptr %t33
  store { i64, [2 x i64] } %t38, ptr %l21
  %t39 = load i32, ptr %l4, !tbaa !23
  store i32 %t39, ptr %l22, !tbaa !23
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t41 = load i32, ptr %l3, !tbaa !23
  %t44 = call { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ebuilt(ptr %v0, ptr %t40, i32 %t41)
  store { i64, [1 x i64] } %t44, ptr %l25
  br label %bb6
bb6:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/lower:lowering", ptr %t45, i32 0, i32 3
  %t48 = load { i64, [4 x i64] }, ptr %l6
  %t49 = mul i64 1, 40
  %t50 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t49)
  %t51 = insertvalue { i64, ptr } undef, i64 1, 0
  %t52 = insertvalue { i64, ptr } %t51, ptr %t50, 1
  store { i64, ptr } %t52, ptr %l29, !tbaa !27
  %t54 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !27
  %t56 = getelementptr { i64, [4 x i64] }, ptr %t55, i64 0
  store { i64, [4 x i64] } %t48, ptr %t56
  %t58 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t59 = call %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eArgs(ptr %v0, ptr %s0, ptr %t47, { i64, ptr } %t58)
  store %"compiler/mir:Range" %t59, ptr %l30
  br label %bb7
bb7:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t61 = load i32, ptr %l3, !tbaa !23
  %t64 = call %"compiler/mir:Range" @compiler_2flower_2ecompiler_2flower_3alowering_2ecapScopes(ptr %v0, ptr %t60, i32 %t61)
  store %"compiler/mir:Range" %t64, ptr %l33
  br label %bb8
bb8:
  store { i64, [15 x i64] } zeroinitializer, ptr %t65
  %t66 = getelementptr { i64, [15 x i64] }, ptr %t65, i32 0, i32 0
  store i64 10, ptr %t66
  %t67 = load { i64, [2 x i64] }, ptr %l21
  %t68 = insertvalue { { i64, [2 x i64] }, i32, { i64, [1 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range" } undef, { i64, [2 x i64] } %t67, 0
  %t69 = load i32, ptr %l22, !tbaa !23
  %t70 = insertvalue { { i64, [2 x i64] }, i32, { i64, [1 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range" } %t68, i32 %t69, 1
  %t71 = load { i64, [1 x i64] }, ptr %l25
  %t72 = insertvalue { { i64, [2 x i64] }, i32, { i64, [1 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range" } %t70, { i64, [1 x i64] } %t71, 2
  %t73 = load %"compiler/mir:Range", ptr %l30
  %t74 = insertvalue { { i64, [2 x i64] }, i32, { i64, [1 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range" } %t72, %"compiler/mir:Range" %t73, 3
  %t75 = load %"compiler/mir:Range", ptr %l33
  %t76 = insertvalue { { i64, [2 x i64] }, i32, { i64, [1 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range" } %t74, %"compiler/mir:Range" %t75, 4
  %t77 = getelementptr { i64, [15 x i64] }, ptr %t65, i32 0, i32 1
  store { { i64, [2 x i64] }, i32, { i64, [1 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range" } %t76, ptr %t77
  %t78 = load { i64, [15 x i64] }, ptr %t65
  %t80 = load ptr, ptr %l18, !tbaa !29
  %t81 = load i32, ptr %l19, !tbaa !23
  %t84 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %t80, i32 %t81, { i64, [15 x i64] } %t78, %"compiler/source:Span" %a5)
  store { i64, [4 x i64] } %t84, ptr %l36
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s0)
  %t85 = load { i64, [4 x i64] }, ptr %l36
  store { i64, [4 x i64] } %t85, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2earm(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca { i64, [4 x i64] }
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l8 = alloca { i64, [4 x i64] }
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l13 = alloca { i64, [4 x i64] }
  %l21 = alloca i1
  %l28 = alloca { i64, [4 x i64] }
  %l29 = alloca ptr
  %l31 = alloca %"compiler/source:Span"
  %l33 = alloca %"compiler/mir:Place"
  %l40 = alloca i64
  %l42 = alloca i1
  %l44 = alloca %"compiler/lower:level"
  %l45 = alloca i32
  %l67 = alloca { i64, ptr }
  %l78 = alloca i1
  %l85 = alloca { i64, [4 x i64] }
  %l86 = alloca ptr
  %l88 = alloca %"compiler/source:Span"
  %l90 = alloca %"compiler/mir:Place"
  %l95 = alloca ptr
  %l115 = alloca { i64, ptr }
  %l126 = alloca i1
  %l133 = alloca { i64, [4 x i64] }
  %l134 = alloca ptr
  %l136 = alloca %"compiler/source:Span"
  %l138 = alloca %"compiler/mir:Place"
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %t42 = alloca { i64, [15 x i64] }, align 8
  %t48 = alloca { i64, [21 x i64] }, align 8
  %t173 = alloca { i64, [15 x i64] }, align 8
  %t179 = alloca { i64, [21 x i64] }, align 8
  %t286 = alloca { i64, [15 x i64] }, align 8
  %t292 = alloca { i64, [21 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Arm", ptr %t1, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = icmp eq ptr %t4, null
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t8 = load ptr, ptr %l1, !tbaa !29
  %t10 = getelementptr %"compiler/typed:Arm", ptr %t8, i32 0, i32 4
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t13 = icmp eq ptr %t11, null
  %t15 = xor i1 %t13, true
  br i1 %t15, label %bb3, label %bb4
bb2:
  br label %bb12
bb3:
  %t17 = load i32, ptr %l2, !tbaa !23
  %t18 = load i32, ptr @G_2ecompiler_2fmir_2eNoLocal, !tbaa !23
  %t21 = icmp ne i32 %t17, %t18
  store i1 %t21, ptr %l21, !tbaa !21
  br label %bb5
bb4:
  store i1 false, ptr %l21, !tbaa !21
  br label %bb5
bb5:
  %t23 = load i1, ptr %l21, !tbaa !21
  br i1 %t23, label %bb6, label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s2
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr %"compiler/typed:Arm", ptr %t25, i32 0, i32 4
  %t28 = load ptr, ptr %t27, !tbaa !29
  %t31 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v1, ptr %t24, ptr %t28)
  store { i64, [4 x i64] } %t31, ptr %l28
  br label %bb8
bb7:
  br label %bb11
bb8:
  %t32 = load { i64, [4 x i64] }, ptr %l28
  store { i64, [4 x i64] } %t32, ptr %l3
  %t33 = load ptr, ptr %l0, !tbaa !29
  store ptr %t33, ptr %l29, !tbaa !29
  %t34 = load ptr, ptr %l1, !tbaa !29
  %t36 = getelementptr %"compiler/typed:Arm", ptr %t34, i32 0, i32 0
  %t37 = load %"compiler/source:Span", ptr %t36
  store %"compiler/source:Span" %t37, ptr %l31
  %t38 = load i32, ptr %l2, !tbaa !23
  %t40 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t38)
  store %"compiler/mir:Place" %t40, ptr %l33
  br label %bb9
bb9:
  %t41 = load { i64, [4 x i64] }, ptr %l3
  store { i64, [15 x i64] } zeroinitializer, ptr %t42
  %t43 = getelementptr { i64, [15 x i64] }, ptr %t42, i32 0, i32 0
  store i64 0, ptr %t43
  %t45 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t41, 0
  %t46 = getelementptr { i64, [15 x i64] }, ptr %t42, i32 0, i32 1
  store { { i64, [4 x i64] } } %t45, ptr %t46
  %t47 = load { i64, [15 x i64] }, ptr %t42
  store { i64, [21 x i64] } zeroinitializer, ptr %t48
  %t49 = getelementptr { i64, [21 x i64] }, ptr %t48, i32 0, i32 0
  store i64 0, ptr %t49
  %t50 = load %"compiler/source:Span", ptr %l31
  %t51 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t50, 0
  %t52 = load %"compiler/mir:Place", ptr %l33
  %t53 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t51, %"compiler/mir:Place" %t52, 1
  %t55 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t53, { i64, [15 x i64] } %t47, 2
  %t56 = getelementptr { i64, [21 x i64] }, ptr %t48, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t55, ptr %t56
  %t57 = load { i64, [21 x i64] }, ptr %t48
  %t59 = call ptr @__olang_scope_alloc_a(ptr %s2, i64 176, i64 8)
  store { i64, [21 x i64] } %t57, ptr %t59
  %t60 = load ptr, ptr %l29, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s2, ptr %t60, ptr %t59)
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb11
bb11:
  br label %ret
bb12:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/lower:lowering", ptr %t62, i32 0, i32 9
  %t66 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3alevel_3e_2eLen_3ccompiler_2flower_3alevel_3e(ptr %v0, ptr %t64)
  store i64 %t66, ptr %l40
  br label %bb13
bb13:
  %t67 = load i64, ptr %l40, !tbaa !24
  %t68 = icmp sgt i64 %t67, 0
  br i1 %t68, label %bb14, label %bb15
bb14:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = call %"compiler/lower:level" @compiler_2flower_2ecompiler_2flower_3alowering_2etop(ptr %v0, ptr %t70)
  store %"compiler/lower:level" %t72, ptr %l44
  br label %bb16
bb15:
  store i1 false, ptr %l42, !tbaa !21
  br label %bb20
bb16:
  %t73 = getelementptr %"compiler/lower:level", ptr %l44, i32 0, i32 1
  %t74 = load i32, ptr %t73, !tbaa !23
  store i32 %t74, ptr %l45, !tbaa !23
  %t75 = load ptr, ptr %l1, !tbaa !29
  %t77 = getelementptr %"compiler/typed:Arm", ptr %t75, i32 0, i32 3
  %t78 = load ptr, ptr %t77, !tbaa !29
  %t80 = icmp eq ptr %t78, null
  br i1 %t80, label %bb17, label %bb18
bb17:
  call void @__olang_check_failed(ptr @olang_loc_2262f7260befbeda_ad33d1a86099f68e)
  unreachable
bb18:
  br label %bb19
bb19:
  %t82 = load ptr, ptr %l1, !tbaa !29
  %t84 = getelementptr %"compiler/typed:Arm", ptr %t82, i32 0, i32 3
  %t85 = load ptr, ptr %t84, !tbaa !29
  %t88 = getelementptr %"compiler/typed:Block", ptr %t85, i32 0, i32 0
  %t89 = load i32, ptr %t88, !tbaa !23
  %t90 = load i32, ptr %l45, !tbaa !23
  %t92 = icmp eq i32 %t90, %t89
  store i1 %t92, ptr %l42, !tbaa !21
  br label %bb20
bb20:
  %t94 = load i1, ptr %l42, !tbaa !21
  br i1 %t94, label %bb21, label %bb22
bb21:
  %t95 = load ptr, ptr %l1, !tbaa !29
  %t97 = getelementptr %"compiler/typed:Arm", ptr %t95, i32 0, i32 3
  %t98 = load ptr, ptr %t97, !tbaa !29
  %t100 = icmp eq ptr %t98, null
  br i1 %t100, label %bb23, label %bb24
bb22:
  br label %bb42
bb23:
  call void @__olang_check_failed(ptr @olang_loc_78466967dd42e061_bdc585e3e8213235)
  unreachable
bb24:
  br label %bb25
bb25:
  %t102 = load ptr, ptr %l1, !tbaa !29
  %t104 = getelementptr %"compiler/typed:Arm", ptr %t102, i32 0, i32 3
  %t105 = load ptr, ptr %t104, !tbaa !29
  %t108 = getelementptr %"compiler/typed:Block", ptr %t105, i32 0, i32 1
  %t109 = load { i64, ptr }, ptr %t108, !tbaa !27
  store { i64, ptr } %t109, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t111 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t113 = extractvalue { i64, ptr } %t111, 0
  store i64 %t113, ptr %l6, !tbaa !24
  br label %bb26
bb26:
  store %olang.scope zeroinitializer, ptr %s5
  %t115 = load i64, ptr %l5, !tbaa !24
  %t116 = load i64, ptr %l6, !tbaa !24
  %t119 = icmp slt i64 %t115, %t116
  %t121 = xor i1 %t119, true
  br i1 %t121, label %bb27, label %bb28
bb27:
  call void @__olang_scope_close(ptr %s5)
  br label %bb32
bb28:
  br label %bb29
bb29:
  %t123 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t123, ptr %l67, !tbaa !27
  %t124 = load i64, ptr %l5, !tbaa !24
  %t126 = getelementptr { i64, ptr }, ptr %l67, i32 0, i32 1
  %t127 = load ptr, ptr %t126, !tbaa !27
  %t128 = getelementptr ptr, ptr %t127, i64 %t124
  %t129 = load ptr, ptr %t128, !tbaa !39
  %t131 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estmt(ptr %v0, ptr %v1, ptr %t131, ptr %t129)
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s5)
  br label %bb31
bb31:
  %t135 = load i64, ptr %l5, !tbaa !24
  %t137 = add i64 %t135, 1
  store i64 %t137, ptr %l5, !tbaa !24
  br label %bb26
bb32:
  %t139 = load ptr, ptr %l1, !tbaa !29
  %t141 = getelementptr %"compiler/typed:Arm", ptr %t139, i32 0, i32 4
  %t142 = load ptr, ptr %t141, !tbaa !29
  %t144 = icmp eq ptr %t142, null
  %t146 = xor i1 %t144, true
  br i1 %t146, label %bb33, label %bb34
bb33:
  %t148 = load i32, ptr %l2, !tbaa !23
  %t149 = load i32, ptr @G_2ecompiler_2fmir_2eNoLocal, !tbaa !23
  %t152 = icmp ne i32 %t148, %t149
  store i1 %t152, ptr %l78, !tbaa !21
  br label %bb35
bb34:
  store i1 false, ptr %l78, !tbaa !21
  br label %bb35
bb35:
  %t154 = load i1, ptr %l78, !tbaa !21
  br i1 %t154, label %bb36, label %bb37
bb36:
  store %olang.scope zeroinitializer, ptr %s7
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t156 = load ptr, ptr %l1, !tbaa !29
  %t158 = getelementptr %"compiler/typed:Arm", ptr %t156, i32 0, i32 4
  %t159 = load ptr, ptr %t158, !tbaa !29
  %t162 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v1, ptr %t155, ptr %t159)
  store { i64, [4 x i64] } %t162, ptr %l85
  br label %bb38
bb37:
  br label %bb41
bb38:
  %t163 = load { i64, [4 x i64] }, ptr %l85
  store { i64, [4 x i64] } %t163, ptr %l8
  %t164 = load ptr, ptr %l0, !tbaa !29
  store ptr %t164, ptr %l86, !tbaa !29
  %t165 = load ptr, ptr %l1, !tbaa !29
  %t167 = getelementptr %"compiler/typed:Arm", ptr %t165, i32 0, i32 0
  %t168 = load %"compiler/source:Span", ptr %t167
  store %"compiler/source:Span" %t168, ptr %l88
  %t169 = load i32, ptr %l2, !tbaa !23
  %t171 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t169)
  store %"compiler/mir:Place" %t171, ptr %l90
  br label %bb39
bb39:
  %t172 = load { i64, [4 x i64] }, ptr %l8
  store { i64, [15 x i64] } zeroinitializer, ptr %t173
  %t174 = getelementptr { i64, [15 x i64] }, ptr %t173, i32 0, i32 0
  store i64 0, ptr %t174
  %t176 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t172, 0
  %t177 = getelementptr { i64, [15 x i64] }, ptr %t173, i32 0, i32 1
  store { { i64, [4 x i64] } } %t176, ptr %t177
  %t178 = load { i64, [15 x i64] }, ptr %t173
  store { i64, [21 x i64] } zeroinitializer, ptr %t179
  %t180 = getelementptr { i64, [21 x i64] }, ptr %t179, i32 0, i32 0
  store i64 0, ptr %t180
  %t181 = load %"compiler/source:Span", ptr %l88
  %t182 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t181, 0
  %t183 = load %"compiler/mir:Place", ptr %l90
  %t184 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t182, %"compiler/mir:Place" %t183, 1
  %t186 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t184, { i64, [15 x i64] } %t178, 2
  %t187 = getelementptr { i64, [21 x i64] }, ptr %t179, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t186, ptr %t187
  %t188 = load { i64, [21 x i64] }, ptr %t179
  %t190 = call ptr @__olang_scope_alloc_a(ptr %s7, i64 176, i64 8)
  store { i64, [21 x i64] } %t188, ptr %t190
  %t191 = load ptr, ptr %l86, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s7, ptr %t191, ptr %t190)
  br label %bb40
bb40:
  call void @__olang_scope_close(ptr %s7)
  br label %bb41
bb41:
  br label %ret
bb42:
  %t193 = load ptr, ptr %l0, !tbaa !29
  store ptr %t193, ptr %l95, !tbaa !29
  %t194 = load ptr, ptr %l1, !tbaa !29
  %t196 = getelementptr %"compiler/typed:Arm", ptr %t194, i32 0, i32 3
  %t197 = load ptr, ptr %t196, !tbaa !29
  %t199 = icmp eq ptr %t197, null
  br i1 %t199, label %bb43, label %bb44
bb43:
  call void @__olang_check_failed(ptr @olang_loc_6143a96035d3ceac_ef612191f7538720)
  unreachable
bb44:
  br label %bb45
bb45:
  %t201 = load ptr, ptr %l1, !tbaa !29
  %t203 = getelementptr %"compiler/typed:Arm", ptr %t201, i32 0, i32 3
  %t204 = load ptr, ptr %t203, !tbaa !29
  %t205 = load ptr, ptr %l95, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eopenBlock(ptr %v0, ptr %v1, ptr %t205, ptr %t204, i32 1, i32 0)
  br label %bb46
bb46:
  %t208 = load ptr, ptr %l1, !tbaa !29
  %t210 = getelementptr %"compiler/typed:Arm", ptr %t208, i32 0, i32 3
  %t211 = load ptr, ptr %t210, !tbaa !29
  %t213 = icmp eq ptr %t211, null
  br i1 %t213, label %bb47, label %bb48
bb47:
  call void @__olang_check_failed(ptr @olang_loc_9919e1798def049b_eb223155b689b93f)
  unreachable
bb48:
  br label %bb49
bb49:
  %t215 = load ptr, ptr %l1, !tbaa !29
  %t217 = getelementptr %"compiler/typed:Arm", ptr %t215, i32 0, i32 3
  %t218 = load ptr, ptr %t217, !tbaa !29
  %t221 = getelementptr %"compiler/typed:Block", ptr %t218, i32 0, i32 1
  %t222 = load { i64, ptr }, ptr %t221, !tbaa !27
  store { i64, ptr } %t222, ptr %l9, !tbaa !27
  store i64 0, ptr %l10, !tbaa !24
  %t224 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t226 = extractvalue { i64, ptr } %t224, 0
  store i64 %t226, ptr %l11, !tbaa !24
  br label %bb50
bb50:
  store %olang.scope zeroinitializer, ptr %s9
  %t228 = load i64, ptr %l10, !tbaa !24
  %t229 = load i64, ptr %l11, !tbaa !24
  %t232 = icmp slt i64 %t228, %t229
  %t234 = xor i1 %t232, true
  br i1 %t234, label %bb51, label %bb52
bb51:
  call void @__olang_scope_close(ptr %s9)
  br label %bb56
bb52:
  br label %bb53
bb53:
  %t236 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t236, ptr %l115, !tbaa !27
  %t237 = load i64, ptr %l10, !tbaa !24
  %t239 = getelementptr { i64, ptr }, ptr %l115, i32 0, i32 1
  %t240 = load ptr, ptr %t239, !tbaa !27
  %t241 = getelementptr ptr, ptr %t240, i64 %t237
  %t242 = load ptr, ptr %t241, !tbaa !39
  %t244 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estmt(ptr %v0, ptr %v1, ptr %t244, ptr %t242)
  br label %bb54
bb54:
  call void @__olang_scope_close(ptr %s9)
  br label %bb55
bb55:
  %t248 = load i64, ptr %l10, !tbaa !24
  %t250 = add i64 %t248, 1
  store i64 %t250, ptr %l10, !tbaa !24
  br label %bb50
bb56:
  %t252 = load ptr, ptr %l1, !tbaa !29
  %t254 = getelementptr %"compiler/typed:Arm", ptr %t252, i32 0, i32 4
  %t255 = load ptr, ptr %t254, !tbaa !29
  %t257 = icmp eq ptr %t255, null
  %t259 = xor i1 %t257, true
  br i1 %t259, label %bb57, label %bb58
bb57:
  %t261 = load i32, ptr %l2, !tbaa !23
  %t262 = load i32, ptr @G_2ecompiler_2fmir_2eNoLocal, !tbaa !23
  %t265 = icmp ne i32 %t261, %t262
  store i1 %t265, ptr %l126, !tbaa !21
  br label %bb59
bb58:
  store i1 false, ptr %l126, !tbaa !21
  br label %bb59
bb59:
  %t267 = load i1, ptr %l126, !tbaa !21
  br i1 %t267, label %bb60, label %bb61
bb60:
  store %olang.scope zeroinitializer, ptr %s11
  %t268 = load ptr, ptr %l0, !tbaa !29
  %t269 = load ptr, ptr %l1, !tbaa !29
  %t271 = getelementptr %"compiler/typed:Arm", ptr %t269, i32 0, i32 4
  %t272 = load ptr, ptr %t271, !tbaa !29
  %t275 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v1, ptr %t268, ptr %t272)
  store { i64, [4 x i64] } %t275, ptr %l133
  br label %bb62
bb61:
  br label %bb65
bb62:
  %t276 = load { i64, [4 x i64] }, ptr %l133
  store { i64, [4 x i64] } %t276, ptr %l13
  %t277 = load ptr, ptr %l0, !tbaa !29
  store ptr %t277, ptr %l134, !tbaa !29
  %t278 = load ptr, ptr %l1, !tbaa !29
  %t280 = getelementptr %"compiler/typed:Arm", ptr %t278, i32 0, i32 0
  %t281 = load %"compiler/source:Span", ptr %t280
  store %"compiler/source:Span" %t281, ptr %l136
  %t282 = load i32, ptr %l2, !tbaa !23
  %t284 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t282)
  store %"compiler/mir:Place" %t284, ptr %l138
  br label %bb63
bb63:
  %t285 = load { i64, [4 x i64] }, ptr %l13
  store { i64, [15 x i64] } zeroinitializer, ptr %t286
  %t287 = getelementptr { i64, [15 x i64] }, ptr %t286, i32 0, i32 0
  store i64 0, ptr %t287
  %t289 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t285, 0
  %t290 = getelementptr { i64, [15 x i64] }, ptr %t286, i32 0, i32 1
  store { { i64, [4 x i64] } } %t289, ptr %t290
  %t291 = load { i64, [15 x i64] }, ptr %t286
  store { i64, [21 x i64] } zeroinitializer, ptr %t292
  %t293 = getelementptr { i64, [21 x i64] }, ptr %t292, i32 0, i32 0
  store i64 0, ptr %t293
  %t294 = load %"compiler/source:Span", ptr %l136
  %t295 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t294, 0
  %t296 = load %"compiler/mir:Place", ptr %l138
  %t297 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t295, %"compiler/mir:Place" %t296, 1
  %t299 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t297, { i64, [15 x i64] } %t291, 2
  %t300 = getelementptr { i64, [21 x i64] }, ptr %t292, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t299, ptr %t300
  %t301 = load { i64, [21 x i64] }, ptr %t292
  %t303 = call ptr @__olang_scope_alloc_a(ptr %s11, i64 176, i64 8)
  store { i64, [21 x i64] } %t301, ptr %t303
  %t304 = load ptr, ptr %l134, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s11, ptr %t304, ptr %t303)
  br label %bb64
bb64:
  call void @__olang_scope_close(ptr %s11)
  br label %bb65
bb65:
  %t306 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2ecloseBlock(ptr %v0, ptr %t306)
  br label %bb66
bb66:
  br label %ret
ret:
  ret void
}

define dso_local { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2easI64(ptr %v0, ptr %a0, { i64, [4 x i64] } %a1, i32 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [4 x i64] }
  %l7 = alloca i32
  %l15 = alloca { i64, ptr }
  %l17 = alloca { i64, [4 x i64] }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, [4 x i64] }
  store ptr %a0, ptr %l0
  store { i64, [4 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t8 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t4, i32 %a2)
  store i32 %t8, ptr %l7
  br label %bb1
bb1:
  %t9 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  %t10 = load i32, ptr %l7, !tbaa !23
  %t12 = icmp eq i32 %t10, %t9
  br i1 %t12, label %bb2, label %bb3
bb2:
  %t14 = load { i64, [4 x i64] }, ptr %l1
  call void @__olang_scope_close(ptr %s0)
  store { i64, [4 x i64] } %t14, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  %t18 = load { i64, [4 x i64] }, ptr %l1
  %t19 = mul i64 1, 40
  %t20 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t19)
  %t21 = insertvalue { i64, ptr } undef, i64 1, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  store { i64, ptr } %t22, ptr %l15, !tbaa !27
  %t24 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = getelementptr { i64, [4 x i64] }, ptr %t25, i64 0
  store { i64, [4 x i64] } %t18, ptr %t26
  %t31 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t33 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s0, ptr %t16, i32 20, i32 %t17, { i64, ptr } %t31, %"compiler/source:Span" %a3)
  store { i64, [4 x i64] } %t33, ptr %l17
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s0)
  %t34 = load { i64, [4 x i64] }, ptr %l17
  store { i64, [4 x i64] } %t34, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2eassemble(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca i32
  %l7 = alloca { i64, [4 x i64] }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca { i64, [4 x i64] }
  %l16 = alloca { i64, [1 x i64] }
  %l23 = alloca i1
  %l24 = alloca i32
  %l27 = alloca i32
  %l31 = alloca i32
  %l34 = alloca i32
  %l37 = alloca i1
  %l38 = alloca ptr
  %l41 = alloca i32
  %l42 = alloca i32
  %l49 = alloca i64
  %l51 = alloca i1
  %l58 = alloca ptr
  %l61 = alloca i32
  %l64 = alloca { i64, [4 x i64] }
  %l73 = alloca i64
  %l79 = alloca i64
  %l83 = alloca i64
  %l86 = alloca i64
  %l104 = alloca i64
  %l108 = alloca i32
  %l111 = alloca %"compiler/mir:Place"
  %l115 = alloca ptr
  %l116 = alloca i32
  %l117 = alloca i32
  %l121 = alloca %"compiler/mir:Range"
  %l125 = alloca { i64, [4 x i64] }
  %l130 = alloca { i64, [1 x i64] }
  %l139 = alloca { i64, [4 x i64] }
  %l142 = alloca i32
  %l145 = alloca i1
  %l148 = alloca i1
  %l149 = alloca i1
  %l152 = alloca i1
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %t103 = alloca { i64, [8 x i64] }, align 8
  %t194 = alloca { i64, [4 x i64] }, align 8
  %t219 = alloca { i64, [15 x i64] }, align 8
  %t253 = alloca { i64, [15 x i64] }, align 8
  %t305 = alloca { i64, [21 x i64] }, align 8
  %t329 = alloca { i64, [8 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/lower:lowering", ptr %t6, i32 0, i32 2
  %t9 = load ptr, ptr %t8, !tbaa !29
  store ptr %t9, ptr %l3, !tbaa !29
  %t11 = load ptr, ptr %l3, !tbaa !29
  %t12 = load i32, ptr %l1, !tbaa !23
  %t15 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t11, i32 %t12)
  store i1 %t15, ptr %l23
  br label %bb1
bb1:
  %t16 = load i1, ptr %l23, !tbaa !21
  br i1 %t16, label %bb2, label %bb3
bb2:
  %t17 = load ptr, ptr %l3, !tbaa !29
  %t18 = load i32, ptr %l1, !tbaa !23
  %t21 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t17, i32 %t18)
  store i32 %t21, ptr %l27
  br label %bb4
bb3:
  %t22 = load i32, ptr %l1, !tbaa !23
  store i32 %t22, ptr %l24, !tbaa !23
  br label %bb5
bb4:
  %t24 = load i32, ptr %l27, !tbaa !23
  store i32 %t24, ptr %l24, !tbaa !23
  br label %bb5
bb5:
  %t25 = load i32, ptr %l24, !tbaa !23
  store i32 %t25, ptr %l4, !tbaa !23
  %t26 = load ptr, ptr %l3, !tbaa !29
  %t27 = load i32, ptr %l4, !tbaa !23
  %t30 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t26, i32 %t27)
  store i32 %t30, ptr %l31
  br label %bb6
bb6:
  %t31 = load i32, ptr %l31, !tbaa !23
  store i32 %t31, ptr %l5, !tbaa !23
  %t32 = load ptr, ptr %l3, !tbaa !29
  %t33 = load i32, ptr %l5, !tbaa !23
  %t36 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t32, i32 %t33)
  store i32 %t36, ptr %l34
  br label %bb7
bb7:
  %t37 = load i32, ptr %l34
  %t39 = trunc i64 18 to i32
  %t40 = icmp eq i32 %t37, %t39
  br i1 %t40, label %bb8, label %bb9
bb8:
  %t42 = load ptr, ptr %l3, !tbaa !29
  store ptr %t42, ptr %l38, !tbaa !29
  %t43 = load ptr, ptr %l3, !tbaa !29
  %t44 = load i32, ptr %l5, !tbaa !23
  %t47 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t43, i32 %t44)
  store i32 %t47, ptr %l41
  br label %bb10
bb9:
  store i1 false, ptr %l37, !tbaa !21
  br label %bb12
bb10:
  %t48 = load ptr, ptr %l38, !tbaa !29
  %t49 = load i32, ptr %l41, !tbaa !23
  %t50 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t48, i32 %t49)
  store i32 %t50, ptr %l42
  br label %bb11
bb11:
  %t51 = load i32, ptr %l42
  %t53 = trunc i64 0 to i32
  %t54 = icmp eq i32 %t51, %t53
  store i1 %t54, ptr %l37, !tbaa !21
  br label %bb12
bb12:
  %t56 = load i1, ptr %l37, !tbaa !21
  %t59 = xor i1 %t56, true
  br i1 %t59, label %bb13, label %bb14
bb13:
  %t61 = load ptr, ptr %l2, !tbaa !29
  %t63 = getelementptr %"compiler/typed:Body", ptr %t61, i32 0, i32 10
  %t65 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t63)
  store i64 %t65, ptr %l49
  br label %bb15
bb14:
  br label %bb27
bb15:
  %t66 = load i64, ptr %l49, !tbaa !24
  %t67 = icmp ne i64 %t66, 1
  br i1 %t67, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l51, !tbaa !21
  br label %bb18
bb17:
  %t69 = load i32, ptr %l4, !tbaa !23
  %t70 = load i32, ptr %l1, !tbaa !23
  %t73 = icmp ne i32 %t69, %t70
  store i1 %t73, ptr %l51, !tbaa !21
  br label %bb18
bb18:
  %t75 = load i1, ptr %l51, !tbaa !21
  br i1 %t75, label %bb19, label %bb20
bb19:
  store %olang.scope zeroinitializer, ptr %s2
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t77 = load ptr, ptr %l2, !tbaa !29
  %t79 = getelementptr %"compiler/typed:Body", ptr %t77, i32 0, i32 4
  %t80 = load %"compiler/source:Span", ptr %t79
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2egap(ptr %v0, ptr %s2, ptr %t76, %"compiler/source:Span" %t80, { i64, ptr } { i64 41, ptr getelementptr inbounds (<{ i64, [41 x i8] }>, ptr @.d5, i32 0, i32 1) })
  br label %bb21
bb20:
  br label %bb22
bb21:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb22:
  %t83 = load ptr, ptr %l0, !tbaa !29
  store ptr %t83, ptr %l58, !tbaa !29
  %t84 = load ptr, ptr %l2, !tbaa !29
  %t86 = getelementptr %"compiler/typed:Body", ptr %t84, i32 0, i32 10
  %t88 = call i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t86, i64 0)
  store i32 %t88, ptr %l61
  br label %bb23
bb23:
  %t89 = load i32, ptr %l61, !tbaa !23
  %t91 = load ptr, ptr %l58, !tbaa !29
  %t93 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ecopyLocal(ptr %v0, ptr %t91, i32 %t89)
  store { i64, [4 x i64] } %t93, ptr %l64
  br label %bb24
bb24:
  %t94 = load { i64, [4 x i64] }, ptr %l64
  store { i64, [4 x i64] } %t94, ptr %l7
  %t95 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eleave(ptr %v0, ptr %t95, i64 0)
  br label %bb25
bb25:
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t98 = load ptr, ptr %l2, !tbaa !29
  %t100 = getelementptr %"compiler/typed:Body", ptr %t98, i32 0, i32 4
  %t101 = load %"compiler/source:Span", ptr %t100
  %t102 = load { i64, [4 x i64] }, ptr %l7
  store { i64, [8 x i64] } zeroinitializer, ptr %t103
  %t104 = getelementptr { i64, [8 x i64] }, ptr %t103, i32 0, i32 0
  store i64 5, ptr %t104
  %t106 = insertvalue { %"compiler/source:Span", { i64, [4 x i64] } } undef, %"compiler/source:Span" %t101, 0
  %t108 = insertvalue { %"compiler/source:Span", { i64, [4 x i64] } } %t106, { i64, [4 x i64] } %t102, 1
  %t109 = getelementptr { i64, [8 x i64] }, ptr %t103, i32 0, i32 1
  store { %"compiler/source:Span", { i64, [4 x i64] } } %t108, ptr %t109
  %t110 = load { i64, [8 x i64] }, ptr %t103
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t97, { i64, [8 x i64] } %t110)
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb27:
  %t113 = load ptr, ptr %l2, !tbaa !29
  %t115 = getelementptr %"compiler/typed:Body", ptr %t113, i32 0, i32 10
  %t117 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t115)
  store i64 %t117, ptr %l73
  br label %bb28
bb28:
  %t118 = load i64, ptr %l73, !tbaa !24
  %t119 = icmp sge i64 %t118, 0
  br i1 %t119, label %bb29, label %bb30
bb29:
  %t121 = load i64, ptr %l73, !tbaa !24
  %t122 = icmp sle i64 %t121, 230584300921369395
  br i1 %t122, label %bb31, label %bb32
bb30:
  call void @__olang_check_failed(ptr @olang_loc_b4f44bfc4c4e49f2_17d18a81dcc1f1de)
  unreachable
bb31:
  %t124 = load i64, ptr %l73, !tbaa !24
  %t125 = mul i64 %t124, 40
  %t126 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t125)
  %t127 = insertvalue { i64, ptr } undef, i64 %t124, 0
  %t128 = insertvalue { i64, ptr } %t127, ptr %t126, 1
  store { i64, ptr } %t128, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t130 = load ptr, ptr %l2, !tbaa !29
  %t132 = getelementptr %"compiler/typed:Body", ptr %t130, i32 0, i32 10
  %t134 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t132)
  store i64 %t134, ptr %l79
  br label %bb33
bb32:
  call void @__olang_check_failed(ptr @olang_loc_b4f44bfc4c4e49f2_17d18a81dcc1f1de)
  unreachable
bb33:
  %t135 = load i64, ptr %l79, !tbaa !24
  store i64 %t135, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t136 = load i64, ptr %l10, !tbaa !24
  %t137 = load i64, ptr %l9, !tbaa !24
  %t140 = icmp sgt i64 %t136, %t137
  br i1 %t140, label %bb34, label %bb35
bb34:
  %t142 = load i64, ptr %l11, !tbaa !24
  %t144 = icmp sgt i64 %t142, 0
  br i1 %t144, label %bb36, label %bb37
bb35:
  store i64 0, ptr %l83, !tbaa !24
  br label %bb39
bb36:
  %t146 = load i64, ptr %l10, !tbaa !24
  %t147 = load i64, ptr %l9, !tbaa !24
  %t150 = sub i64 %t146, %t147
  %t151 = load i64, ptr %l11, !tbaa !24
  %t154 = add i64 %t150, %t151
  %t156 = sub i64 %t154, 1
  %t157 = load i64, ptr %l11, !tbaa !24
  %t160 = sdiv i64 %t156, %t157
  store i64 %t160, ptr %l86, !tbaa !24
  br label %bb38
bb37:
  store i64 0, ptr %l86, !tbaa !24
  br label %bb38
bb38:
  %t162 = load i64, ptr %l86, !tbaa !24
  store i64 %t162, ptr %l83, !tbaa !24
  br label %bb39
bb39:
  %t163 = load i64, ptr %l83, !tbaa !24
  store i64 %t163, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb40
bb40:
  store %olang.scope zeroinitializer, ptr %s4
  %t164 = load i64, ptr %l13, !tbaa !24
  %t165 = load i64, ptr %l12, !tbaa !24
  %t168 = icmp slt i64 %t164, %t165
  %t170 = xor i1 %t168, true
  br i1 %t170, label %bb41, label %bb42
bb41:
  call void @__olang_scope_close(ptr %s4)
  br label %bb47
bb42:
  br label %bb43
bb43:
  %t172 = load i64, ptr %l9, !tbaa !24
  %t173 = load i64, ptr %l13, !tbaa !24
  %t174 = load i64, ptr %l11, !tbaa !24
  %t177 = mul i64 %t173, %t174
  %t180 = add i64 %t172, %t177
  store i64 %t180, ptr %l14, !tbaa !24
  %t182 = load i64, ptr %l14, !tbaa !24
  store i64 %t182, ptr %l104, !tbaa !24
  %t183 = load ptr, ptr %l2, !tbaa !29
  %t185 = getelementptr %"compiler/typed:Body", ptr %t183, i32 0, i32 10
  %t186 = load i64, ptr %l14, !tbaa !24
  %t189 = call i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t185, i64 %t186)
  store i32 %t189, ptr %l108
  br label %bb44
bb44:
  %t190 = load i32, ptr %l108, !tbaa !23
  %t193 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t190)
  store %"compiler/mir:Place" %t193, ptr %l111
  br label %bb45
bb45:
  store { i64, [4 x i64] } zeroinitializer, ptr %t194
  %t195 = getelementptr { i64, [4 x i64] }, ptr %t194, i32 0, i32 0
  store i64 1, ptr %t195
  %t196 = load %"compiler/mir:Place", ptr %l111
  %t197 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t196, 0
  %t198 = getelementptr { i64, [4 x i64] }, ptr %t194, i32 0, i32 1
  store { %"compiler/mir:Place" } %t197, ptr %t198
  %t199 = load { i64, [4 x i64] }, ptr %t194
  %t201 = load i64, ptr %l104, !tbaa !24
  %t202 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t203 = load ptr, ptr %t202, !tbaa !27
  %t204 = getelementptr { i64, [4 x i64] }, ptr %t203, i64 %t201
  store { i64, [4 x i64] } %t199, ptr %t204
  call void @__olang_scope_close(ptr %s4)
  br label %bb46
bb46:
  %t205 = load i64, ptr %l13, !tbaa !24
  %t207 = add i64 %t205, 1
  store i64 %t207, ptr %l13, !tbaa !24
  br label %bb40
bb47:
  %t209 = load ptr, ptr %l0, !tbaa !29
  store ptr %t209, ptr %l115, !tbaa !29
  %t210 = load i32, ptr %l4, !tbaa !23
  store i32 %t210, ptr %l116, !tbaa !23
  %t211 = load i32, ptr %l4, !tbaa !23
  store i32 %t211, ptr %l117, !tbaa !23
  %t212 = load ptr, ptr %l0, !tbaa !29
  %t214 = getelementptr %"compiler/lower:lowering", ptr %t212, i32 0, i32 3
  %t215 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t218 = call %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eArgs(ptr %v0, ptr %s0, ptr %t214, { i64, ptr } %t215)
  store %"compiler/mir:Range" %t218, ptr %l121
  br label %bb48
bb48:
  store { i64, [15 x i64] } zeroinitializer, ptr %t219
  %t220 = getelementptr { i64, [15 x i64] }, ptr %t219, i32 0, i32 0
  store i64 6, ptr %t220
  %t221 = load i32, ptr %l117, !tbaa !23
  %t222 = insertvalue { i32, i64, %"compiler/mir:Range" } undef, i32 %t221, 0
  %t223 = insertvalue { i32, i64, %"compiler/mir:Range" } %t222, i64 0, 1
  %t224 = load %"compiler/mir:Range", ptr %l121
  %t225 = insertvalue { i32, i64, %"compiler/mir:Range" } %t223, %"compiler/mir:Range" %t224, 2
  %t226 = getelementptr { i64, [15 x i64] }, ptr %t219, i32 0, i32 1
  store { i32, i64, %"compiler/mir:Range" } %t225, ptr %t226
  %t227 = load { i64, [15 x i64] }, ptr %t219
  %t228 = load ptr, ptr %l2, !tbaa !29
  %t230 = getelementptr %"compiler/typed:Body", ptr %t228, i32 0, i32 4
  %t231 = load %"compiler/source:Span", ptr %t230
  %t232 = load ptr, ptr %l115, !tbaa !29
  %t233 = load i32, ptr %l116, !tbaa !23
  %t236 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %t232, i32 %t233, { i64, [15 x i64] } %t227, %"compiler/source:Span" %t231)
  store { i64, [4 x i64] } %t236, ptr %l125
  br label %bb49
bb49:
  %t237 = load { i64, [4 x i64] }, ptr %l125
  store { i64, [4 x i64] } %t237, ptr %l15
  %t238 = load i32, ptr %l4, !tbaa !23
  %t239 = load i32, ptr %l1, !tbaa !23
  %t242 = icmp ne i32 %t238, %t239
  br i1 %t242, label %bb50, label %bb51
bb50:
  %t244 = load ptr, ptr %l0, !tbaa !29
  %t246 = call { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einstance(ptr %v0, ptr %t244)
  store { i64, [1 x i64] } %t246, ptr %l130
  br label %bb52
bb51:
  br label %bb67
bb52:
  %t247 = load { i64, [1 x i64] }, ptr %l130
  store { i64, [1 x i64] } %t247, ptr %l16
  %t248 = load ptr, ptr %l0, !tbaa !29
  %t249 = load i32, ptr %l1, !tbaa !23
  %t250 = load { i64, [1 x i64] }, ptr %l16
  %t251 = load { i64, [4 x i64] }, ptr %l15
  %t252 = load i32, ptr %l1, !tbaa !23
  store { i64, [15 x i64] } zeroinitializer, ptr %t253
  %t254 = getelementptr { i64, [15 x i64] }, ptr %t253, i32 0, i32 0
  store i64 7, ptr %t254
  %t256 = insertvalue { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 } undef, { i64, [1 x i64] } %t250, 0
  %t258 = insertvalue { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 } %t256, { i64, [4 x i64] } %t251, 1
  %t260 = insertvalue { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 } %t258, i32 %t252, 2
  %t261 = getelementptr { i64, [15 x i64] }, ptr %t253, i32 0, i32 1
  store { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 } %t260, ptr %t261
  %t262 = load { i64, [15 x i64] }, ptr %t253
  %t263 = load ptr, ptr %l2, !tbaa !29
  %t265 = getelementptr %"compiler/typed:Body", ptr %t263, i32 0, i32 4
  %t266 = load %"compiler/source:Span", ptr %t265
  %t271 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %t248, i32 %t249, { i64, [15 x i64] } %t262, %"compiler/source:Span" %t266)
  store { i64, [4 x i64] } %t271, ptr %l139
  br label %bb53
bb53:
  %t272 = load { i64, [4 x i64] }, ptr %l139
  store { i64, [4 x i64] } %t272, ptr %l15
  %t273 = load ptr, ptr %l3, !tbaa !29
  %t274 = load i32, ptr %l5, !tbaa !23
  %t277 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t273, i32 %t274)
  store i32 %t277, ptr %l142
  br label %bb54
bb54:
  %t278 = load i32, ptr %l142
  %t280 = trunc i64 18 to i32
  %t281 = icmp eq i32 %t278, %t280
  br i1 %t281, label %bb55, label %bb56
bb55:
  %t283 = load ptr, ptr %l3, !tbaa !29
  %t284 = load i32, ptr %l5, !tbaa !23
  %t287 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %t283, i32 %t284)
  store i1 %t287, ptr %l148
  br label %bb57
bb56:
  store i1 false, ptr %l145, !tbaa !21
  br label %bb58
bb57:
  %t288 = load i1, ptr %l148, !tbaa !21
  store i1 %t288, ptr %l145, !tbaa !21
  br label %bb58
bb58:
  %t289 = load i1, ptr %l145, !tbaa !21
  br i1 %t289, label %bb59, label %bb60
bb59:
  %t290 = load ptr, ptr %l3, !tbaa !29
  %t291 = load i32, ptr %l5, !tbaa !23
  %t294 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDestructs(ptr %v0, ptr %t290, i32 %t291)
  store i1 %t294, ptr %l152
  br label %bb61
bb60:
  store i1 false, ptr %l149, !tbaa !21
  br label %bb62
bb61:
  %t295 = load i1, ptr %l152, !tbaa !21
  store i1 %t295, ptr %l149, !tbaa !21
  br label %bb62
bb62:
  %t296 = load i1, ptr %l149, !tbaa !21
  br i1 %t296, label %bb63, label %bb64
bb63:
  store %olang.scope zeroinitializer, ptr %s7
  %t297 = load ptr, ptr %l0, !tbaa !29
  %t298 = load ptr, ptr %l2, !tbaa !29
  %t300 = getelementptr %"compiler/typed:Body", ptr %t298, i32 0, i32 4
  %t301 = load %"compiler/source:Span", ptr %t300
  %t302 = load { i64, [1 x i64] }, ptr %l16
  %t303 = load i32, ptr %l4, !tbaa !23
  %t304 = load { i64, [4 x i64] }, ptr %l15
  store { i64, [21 x i64] } zeroinitializer, ptr %t305
  %t306 = getelementptr { i64, [21 x i64] }, ptr %t305, i32 0, i32 0
  store i64 6, ptr %t306
  %t308 = insertvalue { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } undef, %"compiler/source:Span" %t301, 0
  %t310 = insertvalue { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } %t308, { i64, [1 x i64] } %t302, 1
  %t312 = insertvalue { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } %t310, i32 %t303, 2
  %t314 = insertvalue { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } %t312, { i64, [4 x i64] } %t304, 3
  %t315 = getelementptr { i64, [21 x i64] }, ptr %t305, i32 0, i32 1
  store { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } %t314, ptr %t315
  %t316 = load { i64, [21 x i64] }, ptr %t305
  %t318 = call ptr @__olang_scope_alloc_a(ptr %s7, i64 176, i64 8)
  store { i64, [21 x i64] } %t316, ptr %t318
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s7, ptr %t297, ptr %t318)
  br label %bb65
bb64:
  br label %bb66
bb65:
  call void @__olang_scope_close(ptr %s7)
  br label %bb66
bb66:
  br label %bb67
bb67:
  %t321 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eleave(ptr %v0, ptr %t321, i64 0)
  br label %bb68
bb68:
  %t323 = load ptr, ptr %l0, !tbaa !29
  %t324 = load ptr, ptr %l2, !tbaa !29
  %t326 = getelementptr %"compiler/typed:Body", ptr %t324, i32 0, i32 4
  %t327 = load %"compiler/source:Span", ptr %t326
  %t328 = load { i64, [4 x i64] }, ptr %l15
  store { i64, [8 x i64] } zeroinitializer, ptr %t329
  %t330 = getelementptr { i64, [8 x i64] }, ptr %t329, i32 0, i32 0
  store i64 5, ptr %t330
  %t332 = insertvalue { %"compiler/source:Span", { i64, [4 x i64] } } undef, %"compiler/source:Span" %t327, 0
  %t334 = insertvalue { %"compiler/source:Span", { i64, [4 x i64] } } %t332, { i64, [4 x i64] } %t328, 1
  %t335 = getelementptr { i64, [8 x i64] }, ptr %t329, i32 0, i32 1
  store { %"compiler/source:Span", { i64, [4 x i64] } } %t334, ptr %t335
  %t336 = load { i64, [8 x i64] }, ptr %t329
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t323, { i64, [8 x i64] } %t336)
  br label %bb69
bb69:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eaway(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i64
  %l12 = alloca { i64, [4 x i64] }
  %rv = alloca { i64, [4 x i64] }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 4
  %t4 = load i64, ptr %t3, !tbaa !24
  store i64 %t4, ptr %l3, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/lower:lowering", ptr %t6, i32 0, i32 4
  store i64 %a1, ptr %t10, !tbaa !24
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t16 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v1, ptr %t11, ptr %a2)
  store { i64, [4 x i64] } %t16, ptr %l12
  br label %bb1
bb1:
  %t17 = load { i64, [4 x i64] }, ptr %l12
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t19 = load i64, ptr %l3, !tbaa !24
  %t22 = getelementptr %"compiler/lower:lowering", ptr %t18, i32 0, i32 4
  store i64 %t19, ptr %t22, !tbaa !24
  store { i64, [4 x i64] } %t17, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local { { i64, [7 x i64] }, i32 } @compiler_2flower_2ecompiler_2flower_3alowering_2ebodyCallee(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l1 = alloca i32
  %l2 = alloca i32
  %l8 = alloca ptr
  %rv = alloca { { i64, [7 x i64] }, i32 }
  %t19 = alloca { i64, [2 x i64] }, align 8
  %t26 = alloca { i64, [7 x i64] }, align 8
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/lower:lowering", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/lower:Lowerer", ptr %t4, i32 0, i32 1
  %t7 = load i32, ptr %l1, !tbaa !23
  %t9 = sext i32 %t7 to i64
  %t12 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t6, i64 %t9)
  store ptr %t12, ptr %l8
  br label %bb1
bb1:
  %t13 = load ptr, ptr %l8, !tbaa !29
  %t15 = getelementptr %"compiler/typed:Body", ptr %t13, i32 0, i32 2
  %t16 = load i32, ptr %t15, !tbaa !23
  store i32 %t16, ptr %l2, !tbaa !23
  %t18 = load i32, ptr %l1, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t19
  %t20 = getelementptr { i64, [2 x i64] }, ptr %t19, i32 0, i32 0
  store i64 0, ptr %t20
  %t22 = insertvalue { i32 } undef, i32 %t18, 0
  %t23 = getelementptr { i64, [2 x i64] }, ptr %t19, i32 0, i32 1
  store { i32 } %t22, ptr %t23
  %t24 = load { i64, [2 x i64] }, ptr %t19
  %t25 = load i32, ptr %l2, !tbaa !23
  store { i64, [7 x i64] } zeroinitializer, ptr %t26
  %t27 = getelementptr { i64, [7 x i64] }, ptr %t26, i32 0, i32 0
  store i64 0, ptr %t27
  %t29 = insertvalue { { i64, [2 x i64] }, i32 } undef, { i64, [2 x i64] } %t24, 0
  %t31 = insertvalue { { i64, [2 x i64] }, i32 } %t29, i32 %t25, 1
  %t32 = getelementptr { i64, [7 x i64] }, ptr %t26, i32 0, i32 1
  store { { i64, [2 x i64] }, i32 } %t31, ptr %t32
  %t33 = load { i64, [7 x i64] }, ptr %t26
  %t34 = load i32, ptr %l2, !tbaa !23
  %t36 = insertvalue { { i64, [7 x i64] }, i32 } undef, { i64, [7 x i64] } %t33, 0
  %t38 = insertvalue { { i64, [7 x i64] }, i32 } %t36, i32 %t34, 1
  store { { i64, [7 x i64] }, i32 } %t38, ptr %rv
  br label %ret
ret:
  %rr = load { { i64, [7 x i64] }, i32 }, ptr %rv
  ret { { i64, [7 x i64] }, i32 } %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2ebounds(ptr %v0, ptr %a0, { i64, [4 x i64] } %a1, { i64, [4 x i64] } %a2, i1 %a3, i32 %a4, i32 %a5, %"compiler/source:Span" %a6) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [4 x i64] }
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca %"compiler/source:Span"
  %l9 = alloca ptr
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca { i64, [4 x i64] }
  %l14 = alloca { i64, [4 x i64] }
  %l15 = alloca { i64, ptr }
  %l17 = alloca { i64, [4 x i64] }
  %l24 = alloca ptr
  %l26 = alloca i32
  %l32 = alloca { i64, ptr }
  %l34 = alloca { i64, [4 x i64] }
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, [4 x i64] } %a1, ptr %l1
  store i32 %a4, ptr %l4
  store i32 %a5, ptr %l5
  store %"compiler/source:Span" %a6, ptr %l6
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l9, !tbaa !29
  store i32 18, ptr %l10
  %t2 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t2, ptr %l11, !tbaa !23
  %t3 = load { i64, [4 x i64] }, ptr %l1
  store { i64, [4 x i64] } %t3, ptr %l12
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t6 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2econstI64(ptr %v0, ptr %t4, i64 0)
  store { i64, [4 x i64] } %t6, ptr %l14
  br label %bb1
bb1:
  %t7 = mul i64 2, 40
  %t8 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t7)
  %t9 = insertvalue { i64, ptr } undef, i64 2, 0
  %t10 = insertvalue { i64, ptr } %t9, ptr %t8, 1
  store { i64, ptr } %t10, ptr %l15, !tbaa !27
  %t11 = load { i64, [4 x i64] }, ptr %l12
  %t12 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, [4 x i64] }, ptr %t13, i64 0
  store { i64, [4 x i64] } %t11, ptr %t14
  %t15 = load { i64, [4 x i64] }, ptr %l14
  %t16 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = getelementptr { i64, [4 x i64] }, ptr %t17, i64 1
  store { i64, [4 x i64] } %t15, ptr %t18
  %t19 = load %"compiler/source:Span", ptr %l6
  %t20 = load ptr, ptr %l9, !tbaa !29
  %t21 = load i32, ptr %l10
  %t22 = load i32, ptr %l11, !tbaa !23
  %t23 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t25 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s0, ptr %t20, i32 %t21, i32 %t22, { i64, ptr } %t23, %"compiler/source:Span" %t19)
  store { i64, [4 x i64] } %t25, ptr %l17
  br label %bb2
bb2:
  %t26 = load { i64, [4 x i64] }, ptr %l17
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = load i32, ptr %l4
  %t30 = load i32, ptr %l5
  %t31 = load i64, ptr @G_2ecompiler_2flower_2eOutOfBounds, !tbaa !24
  %t32 = load %"compiler/source:Span", ptr %l6
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2echeck(ptr %v0, ptr %t27, { i64, [4 x i64] } %t26, i32 %t29, i32 %t30, i64 %t31, %"compiler/source:Span" %t32)
  br label %bb3
bb3:
  %t39 = load ptr, ptr %l0, !tbaa !29
  store ptr %t39, ptr %l24, !tbaa !29
  br i1 %a3, label %bb4, label %bb5
bb4:
  store i32 16, ptr %l26
  br label %bb6
bb5:
  store i32 15, ptr %l26
  br label %bb6
bb6:
  %t44 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t45 = load { i64, [4 x i64] }, ptr %l1
  %t47 = mul i64 2, 40
  %t48 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t47)
  %t49 = insertvalue { i64, ptr } undef, i64 2, 0
  %t50 = insertvalue { i64, ptr } %t49, ptr %t48, 1
  store { i64, ptr } %t50, ptr %l32, !tbaa !27
  %t52 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !27
  %t54 = getelementptr { i64, [4 x i64] }, ptr %t53, i64 0
  store { i64, [4 x i64] } %t45, ptr %t54
  %t56 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t57 = load ptr, ptr %t56, !tbaa !27
  %t58 = getelementptr { i64, [4 x i64] }, ptr %t57, i64 1
  store { i64, [4 x i64] } %a2, ptr %t58
  %t59 = load %"compiler/source:Span", ptr %l6
  %t60 = load ptr, ptr %l24, !tbaa !29
  %t61 = load i32, ptr %l26
  %t63 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t65 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s0, ptr %t60, i32 %t61, i32 %t44, { i64, ptr } %t63, %"compiler/source:Span" %t59)
  store { i64, [4 x i64] } %t65, ptr %l34
  br label %bb7
bb7:
  %t66 = load { i64, [4 x i64] }, ptr %l34
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = load i32, ptr %l4
  %t70 = load i32, ptr %l5
  %t71 = load i64, ptr @G_2ecompiler_2flower_2eOutOfBounds, !tbaa !24
  %t72 = load %"compiler/source:Span", ptr %l6
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2echeck(ptr %v0, ptr %t67, { i64, [4 x i64] } %t66, i32 %t69, i32 %t70, i64 %t71, %"compiler/source:Span" %t72)
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3alowering_2ecopiesValue(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i1
  %l9 = alloca ptr
  %l10 = alloca i1
  %l13 = alloca ptr
  %l14 = alloca i1
  %l25 = alloca i1
  %l29 = alloca i1
  %l30 = alloca { i64, ptr }
  %l32 = alloca ptr
  %l35 = alloca i1
  %l36 = alloca ptr
  %l37 = alloca { i64, ptr }
  %l39 = alloca i32
  %l40 = alloca i1
  %l41 = alloca i1
  %l43 = alloca { i64, ptr }
  %l45 = alloca i1
  %l46 = alloca i1
  %l51 = alloca i1
  %l52 = alloca ptr
  %l53 = alloca i1
  %l59 = alloca i1
  %l60 = alloca ptr
  %l61 = alloca i1
  %l68 = alloca i1
  %l69 = alloca ptr
  %l70 = alloca i1
  %l79 = alloca i1
  %l80 = alloca ptr
  %l86 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l9, !tbaa !29
  store i1 false, ptr %l10, !tbaa !21
  %t2 = load ptr, ptr %l9, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l9, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l10, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l10, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb6
bb5:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb64
bb6:
  %t10 = load ptr, ptr %l1, !tbaa !29
  store ptr %t10, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t11 = load ptr, ptr %l13, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb7, label %bb8
bb7:
  %t14 = load ptr, ptr %l13, !tbaa !29
  %t15 = load i64, ptr %t14
  %t17 = icmp eq i64 %t15, 9
  store i1 %t17, ptr %l14, !tbaa !21
  br label %bb8
bb8:
  %t18 = load i1, ptr %l14, !tbaa !21
  br i1 %t18, label %bb9, label %bb10
bb9:
  %t19 = load ptr, ptr %l1, !tbaa !29
  %t21 = getelementptr { i64, [5 x i64] }, ptr %t19, i32 0, i32 1
  %t22 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t21, i32 0, i32 1
  %t23 = load i32, ptr %t22
  store i32 %t23, ptr %l2, !tbaa !23
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr { i64, [5 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t27, i32 0, i32 2
  %t29 = load i32, ptr %t28
  store i32 %t29, ptr %l3
  %t31 = load ptr, ptr %l1, !tbaa !29
  %t33 = getelementptr { i64, [5 x i64] }, ptr %t31, i32 0, i32 1
  %t34 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t33, i32 0, i32 4
  %t35 = load { i64, ptr }, ptr %t34
  store { i64, ptr } %t35, ptr %l4, !tbaa !27
  br label %bb11
bb10:
  br label %bb32
bb11:
  %t37 = load i32, ptr %l3
  %t39 = trunc i64 20 to i32
  %t40 = icmp eq i32 %t37, %t39
  br i1 %t40, label %bb12, label %bb13
bb12:
  %t42 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t44 = extractvalue { i64, ptr } %t42, 0
  %t46 = icmp eq i64 %t44, 1
  store i1 %t46, ptr %l25, !tbaa !21
  br label %bb14
bb13:
  store i1 false, ptr %l25, !tbaa !21
  br label %bb14
bb14:
  %t48 = load i1, ptr %l25, !tbaa !21
  br i1 %t48, label %bb15, label %bb16
bb15:
  %t49 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t49, ptr %l30, !tbaa !27
  %t50 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t51 = load ptr, ptr %t50, !tbaa !27
  %t52 = getelementptr ptr, ptr %t51, i64 0
  %t53 = load ptr, ptr %t52, !tbaa !39
  %t55 = call ptr @compiler_2flower_2ederefOf(ptr %v1, ptr %t53)
  store ptr %t55, ptr %l32
  br label %bb17
bb16:
  store i1 false, ptr %l29, !tbaa !21
  br label %bb31
bb17:
  %t56 = load ptr, ptr %l32, !tbaa !29
  %t57 = icmp eq ptr %t56, null
  %t59 = xor i1 %t57, true
  br i1 %t59, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l35, !tbaa !21
  br label %bb26
bb19:
  %t61 = load ptr, ptr %l0, !tbaa !29
  store ptr %t61, ptr %l36, !tbaa !29
  %t62 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t62, ptr %l37, !tbaa !27
  %t63 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t64 = load ptr, ptr %t63, !tbaa !27
  %t65 = getelementptr ptr, ptr %t64, i64 0
  %t66 = load ptr, ptr %t65, !tbaa !39
  %t68 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t66)
  store i32 %t68, ptr %l39
  br label %bb20
bb20:
  %t69 = load ptr, ptr %l36, !tbaa !29
  %t70 = load i32, ptr %l39, !tbaa !23
  %t71 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2evalueArray(ptr %v0, ptr %t69, i32 %t70)
  store i1 %t71, ptr %l40
  br label %bb21
bb21:
  %t72 = load i1, ptr %l40, !tbaa !21
  br i1 %t72, label %bb22, label %bb23
bb22:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t74 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t74, ptr %l43, !tbaa !27
  %t75 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = getelementptr ptr, ptr %t76, i64 0
  %t78 = load ptr, ptr %t77, !tbaa !39
  %t81 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2ecopiesValue(ptr %v0, ptr %v1, ptr %t73, ptr %t78)
  store i1 %t81, ptr %l45
  br label %bb24
bb23:
  store i1 false, ptr %l41, !tbaa !21
  br label %bb25
bb24:
  %t82 = load i1, ptr %l45, !tbaa !21
  store i1 %t82, ptr %l41, !tbaa !21
  br label %bb25
bb25:
  %t83 = load i1, ptr %l41, !tbaa !21
  store i1 %t83, ptr %l35, !tbaa !21
  br label %bb26
bb26:
  %t84 = load i1, ptr %l35, !tbaa !21
  br i1 %t84, label %bb27, label %bb28
bb27:
  store i1 true, ptr %l46, !tbaa !21
  br label %bb30
bb28:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t86 = load i32, ptr %l3
  %t87 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t88 = load i32, ptr %l2, !tbaa !23
  %t93 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2ewidening(ptr %v0, ptr %v1, ptr %t85, i32 %t86, { i64, ptr } %t87, i32 %t88)
  store i1 %t93, ptr %l51
  br label %bb29
bb29:
  %t94 = load i1, ptr %l51, !tbaa !21
  store i1 %t94, ptr %l46, !tbaa !21
  br label %bb30
bb30:
  %t95 = load i1, ptr %l46, !tbaa !21
  store i1 %t95, ptr %l29, !tbaa !21
  br label %bb31
bb31:
  %t96 = load i1, ptr %l29, !tbaa !21
  store i1 %t96, ptr %l8, !tbaa !21
  br label %bb64
bb32:
  %t97 = load ptr, ptr %l1, !tbaa !29
  store ptr %t97, ptr %l52, !tbaa !29
  store i1 false, ptr %l53, !tbaa !21
  %t98 = load ptr, ptr %l52, !tbaa !29
  %t99 = icmp ne ptr %t98, null
  br i1 %t99, label %bb33, label %bb34
bb33:
  %t101 = load ptr, ptr %l52, !tbaa !29
  %t102 = load i64, ptr %t101
  %t104 = icmp eq i64 %t102, 6
  store i1 %t104, ptr %l53, !tbaa !21
  br label %bb34
bb34:
  %t105 = load i1, ptr %l53, !tbaa !21
  br i1 %t105, label %bb35, label %bb36
bb35:
  %t106 = load ptr, ptr %l1, !tbaa !29
  %t108 = getelementptr { i64, [5 x i64] }, ptr %t106, i32 0, i32 1
  %t109 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t108, i32 0, i32 2
  %t110 = load ptr, ptr %t109
  store ptr %t110, ptr %l5, !tbaa !29
  br label %bb37
bb36:
  br label %bb39
bb37:
  %t112 = load ptr, ptr %l5, !tbaa !29
  %t114 = call i1 @compiler_2ftyped_2eScopedCall(ptr %v1, ptr %t112)
  store i1 %t114, ptr %l59
  br label %bb38
bb38:
  %t115 = load i1, ptr %l59, !tbaa !21
  store i1 %t115, ptr %l8, !tbaa !21
  br label %bb64
bb39:
  %t116 = load ptr, ptr %l1, !tbaa !29
  store ptr %t116, ptr %l60, !tbaa !29
  store i1 false, ptr %l61, !tbaa !21
  %t117 = load ptr, ptr %l60, !tbaa !29
  %t118 = icmp ne ptr %t117, null
  br i1 %t118, label %bb40, label %bb41
bb40:
  %t120 = load ptr, ptr %l60, !tbaa !29
  %t121 = load i64, ptr %t120
  %t123 = icmp eq i64 %t121, 17
  store i1 %t123, ptr %l61, !tbaa !21
  br label %bb41
bb41:
  %t124 = load i1, ptr %l61, !tbaa !21
  br i1 %t124, label %bb42, label %bb43
bb42:
  %t125 = load ptr, ptr %l1, !tbaa !29
  %t127 = getelementptr { i64, [5 x i64] }, ptr %t125, i32 0, i32 1
  %t128 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t127, i32 0, i32 2
  %t129 = load ptr, ptr %t128
  store ptr %t129, ptr %l6, !tbaa !29
  br label %bb44
bb43:
  br label %bb46
bb44:
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t132 = load ptr, ptr %l6, !tbaa !29
  %t135 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2ecopiesValue(ptr %v0, ptr %v1, ptr %t131, ptr %t132)
  store i1 %t135, ptr %l68
  br label %bb45
bb45:
  %t136 = load i1, ptr %l68, !tbaa !21
  store i1 %t136, ptr %l8, !tbaa !21
  br label %bb64
bb46:
  %t137 = load ptr, ptr %l1, !tbaa !29
  store ptr %t137, ptr %l69, !tbaa !29
  store i1 false, ptr %l70, !tbaa !21
  %t138 = load ptr, ptr %l69, !tbaa !29
  %t139 = icmp ne ptr %t138, null
  br i1 %t139, label %bb47, label %bb48
bb47:
  %t141 = load ptr, ptr %l69, !tbaa !29
  %t142 = load i64, ptr %t141
  %t144 = icmp eq i64 %t142, 12
  store i1 %t144, ptr %l70, !tbaa !21
  br label %bb48
bb48:
  %t145 = load i1, ptr %l70, !tbaa !21
  br i1 %t145, label %bb49, label %bb50
bb49:
  %t146 = load ptr, ptr %l1, !tbaa !29
  %t148 = getelementptr { i64, [5 x i64] }, ptr %t146, i32 0, i32 1
  %t149 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t148, i32 0, i32 2
  %t150 = load ptr, ptr %t149
  store ptr %t150, ptr %l7, !tbaa !29
  br label %bb51
bb50:
  br label %bb59
bb51:
  %t152 = load ptr, ptr %l7, !tbaa !29
  %t154 = getelementptr %"compiler/typed:Seq", ptr %t152, i32 0, i32 1
  %t155 = load ptr, ptr %t154, !tbaa !29
  %t157 = icmp eq ptr %t155, null
  %t159 = xor i1 %t157, true
  br i1 %t159, label %bb52, label %bb53
bb52:
  %t161 = load ptr, ptr %l0, !tbaa !29
  store ptr %t161, ptr %l80, !tbaa !29
  %t162 = load ptr, ptr %l7, !tbaa !29
  %t164 = getelementptr %"compiler/typed:Seq", ptr %t162, i32 0, i32 1
  %t165 = load ptr, ptr %t164, !tbaa !29
  %t167 = icmp eq ptr %t165, null
  br i1 %t167, label %bb54, label %bb55
bb53:
  store i1 false, ptr %l79, !tbaa !21
  br label %bb58
bb54:
  call void @__olang_check_failed(ptr @olang_loc_755da8ec4c9a9682_903a5def85eef08e)
  unreachable
bb55:
  br label %bb56
bb56:
  %t169 = load ptr, ptr %l7, !tbaa !29
  %t171 = getelementptr %"compiler/typed:Seq", ptr %t169, i32 0, i32 1
  %t172 = load ptr, ptr %t171, !tbaa !29
  %t173 = load ptr, ptr %l80, !tbaa !29
  %t175 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2ecopiesValue(ptr %v0, ptr %v1, ptr %t173, ptr %t172)
  store i1 %t175, ptr %l86
  br label %bb57
bb57:
  %t176 = load i1, ptr %l86, !tbaa !21
  store i1 %t176, ptr %l79, !tbaa !21
  br label %bb58
bb58:
  %t177 = load i1, ptr %l79, !tbaa !21
  store i1 %t177, ptr %l8, !tbaa !21
  br label %bb64
bb59:
  br i1 true, label %bb60, label %bb61
bb60:
  br label %bb62
bb61:
  br label %bb63
bb62:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb64
bb63:
  call void @__olang_check_failed(ptr @olang_loc_429a5ad7d8f4c2a0_c1ea905c2e39baec)
  unreachable
bb64:
  %t178 = load i1, ptr %l8, !tbaa !21
  store i1 %t178, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ecopyLocal(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca %"compiler/mir:Place"
  %rv = alloca { i64, [4 x i64] }
  %t4 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %a1)
  store %"compiler/mir:Place" %t3, ptr %l3
  br label %bb1
bb1:
  store { i64, [4 x i64] } zeroinitializer, ptr %t4
  %t5 = getelementptr { i64, [4 x i64] }, ptr %t4, i32 0, i32 0
  store i64 1, ptr %t5
  %t6 = load %"compiler/mir:Place", ptr %l3
  %t7 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t6, 0
  %t8 = getelementptr { i64, [4 x i64] }, ptr %t4, i32 0, i32 1
  store { %"compiler/mir:Place" } %t7, ptr %t8
  %t9 = load { i64, [4 x i64] }, ptr %t4
  store { i64, [4 x i64] } %t9, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2edispatch(ptr %v0, ptr %a0, { i64, [4 x i64] } %a1, i32 %a2, %"compiler/source:Span" %a3, i1 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [4 x i64] }
  %l2 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca %"compiler/lower:tryCtx"
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca ptr
  %l16 = alloca { i64, [4 x i64] }
  %l17 = alloca i1
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca %"compiler/typed:Item"
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca { i64, [4 x i64] }
  %l32 = alloca i32
  %l33 = alloca i32
  %l34 = alloca i32
  %l40 = alloca { i64, ptr }
  %l43 = alloca i64
  %l51 = alloca %"compiler/lower:tryCtx"
  %l57 = alloca i64
  %l60 = alloca i64
  %l80 = alloca { i64, ptr }
  %l94 = alloca { i64, ptr }
  %l103 = alloca i64
  %l106 = alloca i64
  %l126 = alloca i1
  %l127 = alloca ptr
  %l129 = alloca { i64, ptr }
  %l132 = alloca i32
  %l135 = alloca i32
  %l136 = alloca i1
  %l151 = alloca { i64, ptr }
  %l153 = alloca { i64, [4 x i64] }
  %l162 = alloca { i64, ptr }
  %l164 = alloca { i64, [4 x i64] }
  %l177 = alloca { i64, ptr }
  %l179 = alloca { i64, [4 x i64] }
  %l182 = alloca { i64, [4 x i64] }
  %l189 = alloca { i64, ptr }
  %l191 = alloca { i64, [4 x i64] }
  %l196 = alloca i1
  %l207 = alloca i32
  %l210 = alloca i32
  %l247 = alloca i32
  %l255 = alloca i64
  %l264 = alloca { i64, ptr }
  %l267 = alloca i1
  %l270 = alloca i64
  %l277 = alloca ptr
  %l278 = alloca %"compiler/source:Span"
  %l286 = alloca { i64, [4 x i64] }
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %t99 = alloca { i64, [4 x i64] }, align 8
  %t223 = alloca { i64, [4 x i64] }, align 8
  %t236 = alloca { i64, [4 x i64] }, align 8
  %t273 = alloca { i64, [4 x i64] }, align 8
  %t313 = alloca { i64, [4 x i64] }, align 8
  %t416 = alloca { i64, [8 x i64] }, align 8
  %t457 = alloca { i64, [21 x i64] }, align 8
  %t551 = alloca { i64, [4 x i64] }, align 8
  %t554 = alloca { i64, [8 x i64] }, align 8
  %t573 = alloca { i64, [15 x i64] }, align 8
  store ptr %a0, ptr %l0
  store { i64, [4 x i64] } %a1, ptr %l1
  store i32 %a2, ptr %l2
  store %"compiler/source:Span" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l5, !tbaa !29
  %t6 = load ptr, ptr %l5, !tbaa !29
  %t7 = load i32, ptr %l2, !tbaa !23
  %t10 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t6, i32 %t7)
  store { i64, ptr } %t10, ptr %l40
  br label %bb1
bb1:
  %t11 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t11, ptr %l6, !tbaa !27
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/lower:lowering", ptr %t12, i32 0, i32 13
  %t16 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3atryCtx_3e_2eLen_3ccompiler_2flower_3atryCtx_3e(ptr %v0, ptr %t14)
  store i64 %t16, ptr %l43
  br label %bb2
bb2:
  %t17 = load i64, ptr %l43, !tbaa !24
  %t18 = sub i64 %t17, 1
  store i64 %t18, ptr %l7, !tbaa !24
  br label %bb3
bb3:
  store %olang.scope zeroinitializer, ptr %s2
  %t20 = load i64, ptr %l7, !tbaa !24
  %t22 = icmp sge i64 %t20, 0
  %t24 = xor i1 %t22, true
  br i1 %t24, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s2)
  br label %bb94
bb5:
  br label %bb6
bb6:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/lower:lowering", ptr %t26, i32 0, i32 13
  %t29 = load i64, ptr %l7, !tbaa !24
  %t32 = call %"compiler/lower:tryCtx" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3atryCtx_3e_2eAt_3ccompiler_2flower_3atryCtx_3e(ptr %v0, ptr %v0, ptr %t28, i64 %t29)
  store %"compiler/lower:tryCtx" %t32, ptr %l51
  br label %bb7
bb7:
  %t33 = load %"compiler/lower:tryCtx", ptr %l51
  store %"compiler/lower:tryCtx" %t33, ptr %l8
  store i64 0, ptr %l9, !tbaa !24
  %t34 = getelementptr %"compiler/lower:tryCtx", ptr %l8, i32 0, i32 1
  %t35 = load { i64, ptr }, ptr %t34, !tbaa !27
  %t37 = extractvalue { i64, ptr } %t35, 0
  store i64 %t37, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t39 = load i64, ptr %l10, !tbaa !24
  %t40 = load i64, ptr %l9, !tbaa !24
  %t43 = icmp sgt i64 %t39, %t40
  br i1 %t43, label %bb8, label %bb9
bb8:
  %t45 = load i64, ptr %l11, !tbaa !24
  %t47 = icmp sgt i64 %t45, 0
  br i1 %t47, label %bb10, label %bb11
bb9:
  store i64 0, ptr %l57, !tbaa !24
  br label %bb13
bb10:
  %t49 = load i64, ptr %l10, !tbaa !24
  %t50 = load i64, ptr %l9, !tbaa !24
  %t53 = sub i64 %t49, %t50
  %t54 = load i64, ptr %l11, !tbaa !24
  %t57 = add i64 %t53, %t54
  %t59 = sub i64 %t57, 1
  %t60 = load i64, ptr %l11, !tbaa !24
  %t63 = sdiv i64 %t59, %t60
  store i64 %t63, ptr %l60, !tbaa !24
  br label %bb12
bb11:
  store i64 0, ptr %l60, !tbaa !24
  br label %bb12
bb12:
  %t65 = load i64, ptr %l60, !tbaa !24
  store i64 %t65, ptr %l57, !tbaa !24
  br label %bb13
bb13:
  %t66 = load i64, ptr %l57, !tbaa !24
  store i64 %t66, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb14
bb14:
  store %olang.scope zeroinitializer, ptr %s4
  %t67 = load i64, ptr %l13, !tbaa !24
  %t68 = load i64, ptr %l12, !tbaa !24
  %t71 = icmp slt i64 %t67, %t68
  %t73 = xor i1 %t71, true
  br i1 %t73, label %bb15, label %bb16
bb15:
  call void @__olang_scope_close(ptr %s4)
  br label %bb81
bb16:
  br label %bb17
bb17:
  %t75 = load i64, ptr %l9, !tbaa !24
  %t76 = load i64, ptr %l13, !tbaa !24
  %t77 = load i64, ptr %l11, !tbaa !24
  %t80 = mul i64 %t76, %t77
  %t83 = add i64 %t75, %t80
  store i64 %t83, ptr %l14, !tbaa !24
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"compiler/lower:lowering", ptr %t85, i32 0, i32 7
  %t88 = load i1, ptr %t87, !tbaa !21
  br i1 %t88, label %bb18, label %bb19
bb18:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s2)
  br label %ret
bb19:
  br label %bb20
bb20:
  %t90 = getelementptr %"compiler/lower:tryCtx", ptr %l8, i32 0, i32 1
  %t91 = load { i64, ptr }, ptr %t90, !tbaa !27
  store { i64, ptr } %t91, ptr %l80, !tbaa !27
  %t92 = load i64, ptr %l14, !tbaa !24
  %t94 = getelementptr { i64, ptr }, ptr %l80, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !27
  %t96 = getelementptr ptr, ptr %t95, i64 %t92
  %t97 = load ptr, ptr %t96, !tbaa !39
  store ptr %t97, ptr %l15, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t99
  %t100 = getelementptr { i64, [4 x i64] }, ptr %t99, i32 0, i32 0
  store i64 0, ptr %t100
  %t101 = load { i64, [4 x i64] }, ptr %t99
  store { i64, [4 x i64] } %t101, ptr %l16
  %t103 = load ptr, ptr %l15, !tbaa !29
  %t105 = getelementptr %"compiler/typed:Clause", ptr %t103, i32 0, i32 2
  %t106 = load i1, ptr %t105, !tbaa !21
  store i1 %t106, ptr %l17, !tbaa !21
  %t108 = load ptr, ptr %l15, !tbaa !29
  %t110 = getelementptr %"compiler/typed:Clause", ptr %t108, i32 0, i32 1
  %t111 = load { i64, ptr }, ptr %t110, !tbaa !27
  store { i64, ptr } %t111, ptr %l18, !tbaa !27
  store i64 0, ptr %l19, !tbaa !24
  %t113 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t115 = extractvalue { i64, ptr } %t113, 0
  store i64 %t115, ptr %l20, !tbaa !24
  br label %bb21
bb21:
  store %olang.scope zeroinitializer, ptr %s7
  %t117 = load i64, ptr %l19, !tbaa !24
  %t118 = load i64, ptr %l20, !tbaa !24
  %t121 = icmp slt i64 %t117, %t118
  %t123 = xor i1 %t121, true
  br i1 %t123, label %bb22, label %bb23
bb22:
  call void @__olang_scope_close(ptr %s7)
  br label %bb63
bb23:
  br label %bb24
bb24:
  %t125 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t125, ptr %l94, !tbaa !27
  %t126 = load i64, ptr %l19, !tbaa !24
  %t128 = getelementptr { i64, ptr }, ptr %l94, i32 0, i32 1
  %t129 = load ptr, ptr %t128, !tbaa !27
  %t130 = getelementptr %"compiler/typed:Item", ptr %t129, i64 %t126
  %t131 = load %"compiler/typed:Item", ptr %t130
  store %"compiler/typed:Item" %t131, ptr %l21
  %t133 = load i1, ptr %l17, !tbaa !21
  br i1 %t133, label %bb25, label %bb26
bb25:
  call void @__olang_scope_close(ptr %s7)
  br label %bb63
bb26:
  br label %bb27
bb27:
  store i64 -1, ptr %l22, !tbaa !24
  store i64 0, ptr %l23, !tbaa !24
  %t135 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t137 = extractvalue { i64, ptr } %t135, 0
  store i64 %t137, ptr %l24, !tbaa !24
  store i64 1, ptr %l25, !tbaa !24
  %t139 = load i64, ptr %l24, !tbaa !24
  %t140 = load i64, ptr %l23, !tbaa !24
  %t143 = icmp sgt i64 %t139, %t140
  br i1 %t143, label %bb28, label %bb29
bb28:
  %t145 = load i64, ptr %l25, !tbaa !24
  %t147 = icmp sgt i64 %t145, 0
  br i1 %t147, label %bb30, label %bb31
bb29:
  store i64 0, ptr %l103, !tbaa !24
  br label %bb33
bb30:
  %t149 = load i64, ptr %l24, !tbaa !24
  %t150 = load i64, ptr %l23, !tbaa !24
  %t153 = sub i64 %t149, %t150
  %t154 = load i64, ptr %l25, !tbaa !24
  %t157 = add i64 %t153, %t154
  %t159 = sub i64 %t157, 1
  %t160 = load i64, ptr %l25, !tbaa !24
  %t163 = sdiv i64 %t159, %t160
  store i64 %t163, ptr %l106, !tbaa !24
  br label %bb32
bb31:
  store i64 0, ptr %l106, !tbaa !24
  br label %bb32
bb32:
  %t165 = load i64, ptr %l106, !tbaa !24
  store i64 %t165, ptr %l103, !tbaa !24
  br label %bb33
bb33:
  %t166 = load i64, ptr %l103, !tbaa !24
  store i64 %t166, ptr %l26, !tbaa !24
  store i64 0, ptr %l27, !tbaa !24
  br label %bb34
bb34:
  store %olang.scope zeroinitializer, ptr %s10
  %t167 = load i64, ptr %l27, !tbaa !24
  %t168 = load i64, ptr %l26, !tbaa !24
  %t171 = icmp slt i64 %t167, %t168
  %t173 = xor i1 %t171, true
  br i1 %t173, label %bb35, label %bb36
bb35:
  call void @__olang_scope_close(ptr %s10)
  br label %bb48
bb36:
  br label %bb37
bb37:
  %t175 = load i64, ptr %l23, !tbaa !24
  %t176 = load i64, ptr %l27, !tbaa !24
  %t177 = load i64, ptr %l25, !tbaa !24
  %t180 = mul i64 %t176, %t177
  %t183 = add i64 %t175, %t180
  store i64 %t183, ptr %l28, !tbaa !24
  %t185 = load i64, ptr %l22, !tbaa !24
  %t187 = icmp slt i64 %t185, 0
  br i1 %t187, label %bb38, label %bb39
bb38:
  %t189 = load ptr, ptr %l5, !tbaa !29
  store ptr %t189, ptr %l127, !tbaa !29
  %t190 = load ptr, ptr %l5, !tbaa !29
  %t191 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t191, ptr %l129, !tbaa !27
  %t192 = load i64, ptr %l28, !tbaa !24
  %t194 = getelementptr { i64, ptr }, ptr %l129, i32 0, i32 1
  %t195 = load ptr, ptr %t194, !tbaa !27
  %t196 = getelementptr i32, ptr %t195, i64 %t192
  %t197 = load i32, ptr %t196, !tbaa !33
  %t200 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t190, i32 %t197)
  store i32 %t200, ptr %l132
  br label %bb40
bb39:
  store i1 false, ptr %l126, !tbaa !21
  br label %bb43
bb40:
  %t201 = load ptr, ptr %l5, !tbaa !29
  %t202 = getelementptr %"compiler/typed:Item", ptr %l21, i32 0, i32 0
  %t203 = load i32, ptr %t202, !tbaa !23
  %t206 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t201, i32 %t203)
  store i32 %t206, ptr %l135
  br label %bb41
bb41:
  %t207 = load ptr, ptr %l127, !tbaa !29
  %t208 = load i32, ptr %l132, !tbaa !23
  %t209 = load i32, ptr %l135, !tbaa !23
  %t210 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t207, i32 %t208, i32 %t209)
  store i1 %t210, ptr %l136
  br label %bb42
bb42:
  %t211 = load i1, ptr %l136, !tbaa !21
  store i1 %t211, ptr %l126, !tbaa !21
  br label %bb43
bb43:
  %t212 = load i1, ptr %l126, !tbaa !21
  br i1 %t212, label %bb44, label %bb45
bb44:
  %t213 = load i64, ptr %l28, !tbaa !24
  store i64 %t213, ptr %l22, !tbaa !24
  br label %bb46
bb45:
  br label %bb46
bb46:
  call void @__olang_scope_close(ptr %s10)
  br label %bb47
bb47:
  %t215 = load i64, ptr %l27, !tbaa !24
  %t217 = add i64 %t215, 1
  store i64 %t217, ptr %l27, !tbaa !24
  br label %bb34
bb48:
  %t219 = load i64, ptr %l22, !tbaa !24
  %t221 = icmp slt i64 %t219, 0
  br i1 %t221, label %bb49, label %bb50
bb49:
  call void @__olang_scope_close(ptr %s7)
  br label %bb62
bb50:
  br label %bb51
bb51:
  store { i64, [4 x i64] } zeroinitializer, ptr %t223
  %t224 = getelementptr { i64, [4 x i64] }, ptr %t223, i32 0, i32 0
  store i64 0, ptr %t224
  %t225 = load { i64, [4 x i64] }, ptr %t223
  store { i64, [4 x i64] } %t225, ptr %l29
  %t227 = getelementptr %"compiler/typed:Item", ptr %l21, i32 0, i32 1
  %t228 = load i64, ptr %t227, !tbaa !24
  %t230 = icmp slt i64 %t228, 0
  br i1 %t230, label %bb52, label %bb53
bb52:
  store %olang.scope zeroinitializer, ptr %s14
  %t232 = load ptr, ptr %l0, !tbaa !29
  %t233 = load i32, ptr @G_2ecompiler_2fmir_2eI32T, !tbaa !23
  %t234 = load { i64, [4 x i64] }, ptr %l1
  %t235 = load i32, ptr @G_2ecompiler_2fmir_2eI32T, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t236
  %t237 = getelementptr { i64, [4 x i64] }, ptr %t236, i32 0, i32 0
  store i64 2, ptr %t237
  %t239 = insertvalue { i32, i64 } undef, i32 %t235, 0
  %t240 = insertvalue { i32, i64 } %t239, i64 16, 1
  %t241 = getelementptr { i64, [4 x i64] }, ptr %t236, i32 0, i32 1
  store { i32, i64 } %t240, ptr %t241
  %t242 = load { i64, [4 x i64] }, ptr %t236
  %t243 = mul i64 2, 40
  %t244 = call ptr @__olang_scope_alloc_zeroed(ptr %s14, i64 %t243)
  %t245 = insertvalue { i64, ptr } undef, i64 2, 0
  %t246 = insertvalue { i64, ptr } %t245, ptr %t244, 1
  store { i64, ptr } %t246, ptr %l151, !tbaa !27
  %t248 = getelementptr { i64, ptr }, ptr %l151, i32 0, i32 1
  %t249 = load ptr, ptr %t248, !tbaa !27
  %t250 = getelementptr { i64, [4 x i64] }, ptr %t249, i64 0
  store { i64, [4 x i64] } %t234, ptr %t250
  %t252 = getelementptr { i64, ptr }, ptr %l151, i32 0, i32 1
  %t253 = load ptr, ptr %t252, !tbaa !27
  %t254 = getelementptr { i64, [4 x i64] }, ptr %t253, i64 1
  store { i64, [4 x i64] } %t242, ptr %t254
  %t255 = load %"compiler/source:Span", ptr %l3
  %t259 = load { i64, ptr }, ptr %l151, !tbaa !27
  %t261 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s14, ptr %t232, i32 9, i32 %t233, { i64, ptr } %t259, %"compiler/source:Span" %t255)
  store { i64, [4 x i64] } %t261, ptr %l153
  br label %bb54
bb53:
  store %olang.scope zeroinitializer, ptr %s15
  %t262 = load i32, ptr @G_2ecompiler_2fmir_2eI32T, !tbaa !23
  %t263 = load i64, ptr %l22, !tbaa !24
  %t265 = add i64 %t263, 1
  %t267 = shl i64 %t265, 16
  %t268 = getelementptr %"compiler/typed:Item", ptr %l21, i32 0, i32 1
  %t269 = load i64, ptr %t268, !tbaa !24
  %t272 = or i64 %t267, %t269
  store { i64, [4 x i64] } zeroinitializer, ptr %t273
  %t274 = getelementptr { i64, [4 x i64] }, ptr %t273, i32 0, i32 0
  store i64 2, ptr %t274
  %t276 = insertvalue { i32, i64 } undef, i32 %t262, 0
  %t278 = insertvalue { i32, i64 } %t276, i64 %t272, 1
  %t279 = getelementptr { i64, [4 x i64] }, ptr %t273, i32 0, i32 1
  store { i32, i64 } %t278, ptr %t279
  %t280 = load { i64, [4 x i64] }, ptr %t273
  %t282 = load ptr, ptr %l0, !tbaa !29
  %t283 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t284 = load { i64, [4 x i64] }, ptr %l1
  %t286 = mul i64 2, 40
  %t287 = call ptr @__olang_scope_alloc_zeroed(ptr %s15, i64 %t286)
  %t288 = insertvalue { i64, ptr } undef, i64 2, 0
  %t289 = insertvalue { i64, ptr } %t288, ptr %t287, 1
  store { i64, ptr } %t289, ptr %l177, !tbaa !27
  %t291 = getelementptr { i64, ptr }, ptr %l177, i32 0, i32 1
  %t292 = load ptr, ptr %t291, !tbaa !27
  %t293 = getelementptr { i64, [4 x i64] }, ptr %t292, i64 0
  store { i64, [4 x i64] } %t284, ptr %t293
  %t295 = getelementptr { i64, ptr }, ptr %l177, i32 0, i32 1
  %t296 = load ptr, ptr %t295, !tbaa !27
  %t297 = getelementptr { i64, [4 x i64] }, ptr %t296, i64 1
  store { i64, [4 x i64] } %t280, ptr %t297
  %t298 = load %"compiler/source:Span", ptr %l3
  %t302 = load { i64, ptr }, ptr %l177, !tbaa !27
  %t304 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s15, ptr %t282, i32 13, i32 %t283, { i64, ptr } %t302, %"compiler/source:Span" %t298)
  store { i64, [4 x i64] } %t304, ptr %l179
  br label %bb56
bb54:
  %t305 = load { i64, [4 x i64] }, ptr %l153
  %t306 = load ptr, ptr %l0, !tbaa !29
  %t307 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t309 = load i32, ptr @G_2ecompiler_2fmir_2eI32T, !tbaa !23
  %t310 = load i64, ptr %l22, !tbaa !24
  %t312 = add i64 %t310, 1
  store { i64, [4 x i64] } zeroinitializer, ptr %t313
  %t314 = getelementptr { i64, [4 x i64] }, ptr %t313, i32 0, i32 0
  store i64 2, ptr %t314
  %t316 = insertvalue { i32, i64 } undef, i32 %t309, 0
  %t318 = insertvalue { i32, i64 } %t316, i64 %t312, 1
  %t319 = getelementptr { i64, [4 x i64] }, ptr %t313, i32 0, i32 1
  store { i32, i64 } %t318, ptr %t319
  %t320 = load { i64, [4 x i64] }, ptr %t313
  %t321 = mul i64 2, 40
  %t322 = call ptr @__olang_scope_alloc_zeroed(ptr %s14, i64 %t321)
  %t323 = insertvalue { i64, ptr } undef, i64 2, 0
  %t324 = insertvalue { i64, ptr } %t323, ptr %t322, 1
  store { i64, ptr } %t324, ptr %l162, !tbaa !27
  %t326 = getelementptr { i64, ptr }, ptr %l162, i32 0, i32 1
  %t327 = load ptr, ptr %t326, !tbaa !27
  %t328 = getelementptr { i64, [4 x i64] }, ptr %t327, i64 0
  store { i64, [4 x i64] } %t305, ptr %t328
  %t330 = getelementptr { i64, ptr }, ptr %l162, i32 0, i32 1
  %t331 = load ptr, ptr %t330, !tbaa !27
  %t332 = getelementptr { i64, [4 x i64] }, ptr %t331, i64 1
  store { i64, [4 x i64] } %t320, ptr %t332
  %t333 = load %"compiler/source:Span", ptr %l3
  %t337 = load { i64, ptr }, ptr %l162, !tbaa !27
  %t339 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s14, ptr %t306, i32 13, i32 %t307, { i64, ptr } %t337, %"compiler/source:Span" %t333)
  store { i64, [4 x i64] } %t339, ptr %l164
  br label %bb55
bb55:
  %t340 = load { i64, [4 x i64] }, ptr %l164
  store { i64, [4 x i64] } %t340, ptr %l29
  call void @__olang_scope_close(ptr %s14)
  br label %bb57
bb56:
  %t341 = load { i64, [4 x i64] }, ptr %l179
  store { i64, [4 x i64] } %t341, ptr %l29
  call void @__olang_scope_close(ptr %s15)
  br label %bb57
bb57:
  %t342 = load { i64, [4 x i64] }, ptr %l16
  %t344 = extractvalue { i64, [4 x i64] } %t342, 0
  %t345 = icmp eq i64 %t344, 0
  br i1 %t345, label %bb58, label %bb59
bb58:
  %t347 = load { i64, [4 x i64] }, ptr %l29
  store { i64, [4 x i64] } %t347, ptr %l182
  br label %bb61
bb59:
  %t349 = load ptr, ptr %l0, !tbaa !29
  %t350 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t351 = load { i64, [4 x i64] }, ptr %l16
  %t352 = load { i64, [4 x i64] }, ptr %l29
  %t353 = mul i64 2, 40
  %t354 = call ptr @__olang_scope_alloc_zeroed(ptr %s7, i64 %t353)
  %t355 = insertvalue { i64, ptr } undef, i64 2, 0
  %t356 = insertvalue { i64, ptr } %t355, ptr %t354, 1
  store { i64, ptr } %t356, ptr %l189, !tbaa !27
  %t358 = getelementptr { i64, ptr }, ptr %l189, i32 0, i32 1
  %t359 = load ptr, ptr %t358, !tbaa !27
  %t360 = getelementptr { i64, [4 x i64] }, ptr %t359, i64 0
  store { i64, [4 x i64] } %t351, ptr %t360
  %t362 = getelementptr { i64, ptr }, ptr %l189, i32 0, i32 1
  %t363 = load ptr, ptr %t362, !tbaa !27
  %t364 = getelementptr { i64, [4 x i64] }, ptr %t363, i64 1
  store { i64, [4 x i64] } %t352, ptr %t364
  %t365 = load %"compiler/source:Span", ptr %l3
  %t369 = load { i64, ptr }, ptr %l189, !tbaa !27
  %t371 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s7, ptr %t349, i32 11, i32 %t350, { i64, ptr } %t369, %"compiler/source:Span" %t365)
  store { i64, [4 x i64] } %t371, ptr %l191
  br label %bb60
bb60:
  %t372 = load { i64, [4 x i64] }, ptr %l191
  store { i64, [4 x i64] } %t372, ptr %l182
  br label %bb61
bb61:
  %t373 = load { i64, [4 x i64] }, ptr %l182
  store { i64, [4 x i64] } %t373, ptr %l16
  call void @__olang_scope_close(ptr %s7)
  br label %bb62
bb62:
  %t374 = load i64, ptr %l19, !tbaa !24
  %t376 = add i64 %t374, 1
  store i64 %t376, ptr %l19, !tbaa !24
  br label %bb21
bb63:
  %t378 = load i1, ptr %l17, !tbaa !21
  %t380 = xor i1 %t378, true
  br i1 %t380, label %bb64, label %bb65
bb64:
  %t382 = load { i64, [4 x i64] }, ptr %l16
  %t384 = extractvalue { i64, [4 x i64] } %t382, 0
  %t385 = icmp eq i64 %t384, 0
  store i1 %t385, ptr %l196, !tbaa !21
  br label %bb66
bb65:
  store i1 false, ptr %l196, !tbaa !21
  br label %bb66
bb66:
  %t387 = load i1, ptr %l196, !tbaa !21
  br i1 %t387, label %bb67, label %bb68
bb67:
  call void @__olang_scope_close(ptr %s4)
  br label %bb80
bb68:
  br label %bb69
bb69:
  %t388 = load i1, ptr %l17, !tbaa !21
  br i1 %t388, label %bb70, label %bb71
bb70:
  %t390 = load ptr, ptr %l0, !tbaa !29
  %t391 = load %"compiler/lower:tryCtx", ptr %l8
  %t392 = load i64, ptr %l14, !tbaa !24
  %t393 = load { i64, [4 x i64] }, ptr %l1
  %t394 = load i32, ptr %l2, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2etoClause(ptr %v0, ptr %v0, ptr %t390, %"compiler/lower:tryCtx" %t391, i64 %t392, { i64, [4 x i64] } %t393, i32 %t394)
  br label %bb72
bb71:
  br label %bb73
bb72:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s2)
  br label %ret
bb73:
  %t400 = load ptr, ptr %l0, !tbaa !29
  %t402 = getelementptr %"compiler/lower:lowering", ptr %t400, i32 0, i32 3
  %t404 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t402)
  store i32 %t404, ptr %l207
  br label %bb74
bb74:
  %t405 = load i32, ptr %l207, !tbaa !23
  store i32 %t405, ptr %l32, !tbaa !23
  %t406 = load ptr, ptr %l0, !tbaa !29
  %t408 = getelementptr %"compiler/lower:lowering", ptr %t406, i32 0, i32 3
  %t410 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t408)
  store i32 %t410, ptr %l210
  br label %bb75
bb75:
  %t411 = load i32, ptr %l210, !tbaa !23
  store i32 %t411, ptr %l33, !tbaa !23
  %t412 = load ptr, ptr %l0, !tbaa !29
  %t413 = load { i64, [4 x i64] }, ptr %l16
  %t414 = load i32, ptr %l32, !tbaa !23
  %t415 = load i32, ptr %l33, !tbaa !23
  store { i64, [8 x i64] } zeroinitializer, ptr %t416
  %t417 = getelementptr { i64, [8 x i64] }, ptr %t416, i32 0, i32 0
  store i64 2, ptr %t417
  %t419 = insertvalue { { i64, [4 x i64] }, i32, i32 } undef, { i64, [4 x i64] } %t413, 0
  %t421 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t419, i32 %t414, 1
  %t423 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t421, i32 %t415, 2
  %t424 = getelementptr { i64, [8 x i64] }, ptr %t416, i32 0, i32 1
  store { { i64, [4 x i64] }, i32, i32 } %t423, ptr %t424
  %t425 = load { i64, [8 x i64] }, ptr %t416
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t412, { i64, [8 x i64] } %t425)
  br label %bb76
bb76:
  %t428 = load ptr, ptr %l0, !tbaa !29
  %t429 = load i32, ptr %l32, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t428, i32 %t429)
  br label %bb77
bb77:
  %t432 = load ptr, ptr %l0, !tbaa !29
  %t433 = load %"compiler/lower:tryCtx", ptr %l8
  %t434 = load i64, ptr %l14, !tbaa !24
  %t435 = load { i64, [4 x i64] }, ptr %l1
  %t436 = load i32, ptr %l2, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2etoClause(ptr %v0, ptr %v0, ptr %t432, %"compiler/lower:tryCtx" %t433, i64 %t434, { i64, [4 x i64] } %t435, i32 %t436)
  br label %bb78
bb78:
  %t442 = load ptr, ptr %l0, !tbaa !29
  %t443 = load i32, ptr %l33, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t442, i32 %t443)
  br label %bb79
bb79:
  call void @__olang_scope_close(ptr %s4)
  br label %bb80
bb80:
  %t446 = load i64, ptr %l13, !tbaa !24
  %t448 = add i64 %t446, 1
  store i64 %t448, ptr %l13, !tbaa !24
  br label %bb14
bb81:
  %t450 = getelementptr %"compiler/lower:tryCtx", ptr %l8, i32 0, i32 2
  %t451 = load i1, ptr %t450, !tbaa !21
  br i1 %t451, label %bb82, label %bb83
bb82:
  br i1 %a4, label %bb84, label %bb85
bb83:
  br label %bb89
bb84:
  store %olang.scope zeroinitializer, ptr %s21
  %t455 = load ptr, ptr %l0, !tbaa !29
  %t456 = load %"compiler/source:Span", ptr %l3
  store { i64, [21 x i64] } zeroinitializer, ptr %t457
  %t458 = getelementptr { i64, [21 x i64] }, ptr %t457, i32 0, i32 0
  store i64 12, ptr %t458
  %t460 = insertvalue { %"compiler/source:Span" } undef, %"compiler/source:Span" %t456, 0
  %t461 = getelementptr { i64, [21 x i64] }, ptr %t457, i32 0, i32 1
  store { %"compiler/source:Span" } %t460, ptr %t461
  %t462 = load { i64, [21 x i64] }, ptr %t457
  %t464 = call ptr @__olang_scope_alloc_a(ptr %s21, i64 176, i64 8)
  store { i64, [21 x i64] } %t462, ptr %t464
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s21, ptr %t455, ptr %t464)
  br label %bb86
bb85:
  br label %bb87
bb86:
  call void @__olang_scope_close(ptr %s21)
  br label %bb87
bb87:
  %t467 = load ptr, ptr %l0, !tbaa !29
  %t468 = load { i64, [4 x i64] }, ptr %l1
  %t469 = load i32, ptr %l2, !tbaa !23
  %t470 = load %"compiler/source:Span", ptr %l3
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2ebang(ptr %v0, ptr %t467, { i64, [4 x i64] } %t468, i32 %t469, %"compiler/source:Span" %t470, i32 12)
  br label %bb88
bb88:
  call void @__olang_scope_close(ptr %s2)
  br label %ret
bb89:
  %t476 = getelementptr %"compiler/lower:tryCtx", ptr %l8, i32 0, i32 3
  %t477 = load i1, ptr %t476, !tbaa !21
  %t479 = xor i1 %t477, true
  br i1 %t479, label %bb90, label %bb91
bb90:
  call void @__olang_scope_close(ptr %s2)
  br label %bb94
bb91:
  br label %bb92
bb92:
  call void @__olang_scope_close(ptr %s2)
  br label %bb93
bb93:
  %t481 = load i64, ptr %l7, !tbaa !24
  %t483 = sub i64 %t481, 1
  store i64 %t483, ptr %l7, !tbaa !24
  br label %bb3
bb94:
  %t485 = load ptr, ptr %l0, !tbaa !29
  %t487 = getelementptr %"compiler/lower:lowering", ptr %t485, i32 0, i32 2
  %t488 = load ptr, ptr %t487, !tbaa !29
  %t489 = load ptr, ptr %l0, !tbaa !29
  %t491 = getelementptr %"compiler/lower:lowering", ptr %t489, i32 0, i32 1
  %t492 = load ptr, ptr %t491, !tbaa !29
  %t494 = getelementptr %"compiler/typed:Body", ptr %t492, i32 0, i32 2
  %t495 = load i32, ptr %t494, !tbaa !23
  %t498 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t488, i32 %t495)
  store i32 %t498, ptr %l247
  br label %bb95
bb95:
  %t499 = load i32, ptr %l247, !tbaa !23
  store i32 %t499, ptr %l34, !tbaa !23
  %t500 = load ptr, ptr %l0, !tbaa !29
  %t502 = getelementptr %"compiler/lower:lowering", ptr %t500, i32 0, i32 1
  %t503 = load ptr, ptr %t502, !tbaa !29
  %t505 = getelementptr %"compiler/typed:Body", ptr %t503, i32 0, i32 1
  %t506 = load { i64, [2 x i64] }, ptr %t505
  %t510 = extractvalue { i64, [2 x i64] } %t506, 0
  %t511 = icmp eq i64 %t510, 5
  br i1 %t511, label %bb96, label %bb97
bb96:
  br label %bb98
bb97:
  br label %bb104
bb98:
  %t513 = load ptr, ptr %l0, !tbaa !29
  %t515 = getelementptr %"compiler/lower:lowering", ptr %t513, i32 0, i32 13
  %t517 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3atryCtx_3e_2eLen_3ccompiler_2flower_3atryCtx_3e(ptr %v0, ptr %t515)
  store i64 %t517, ptr %l255
  br label %bb99
bb99:
  %t518 = load i64, ptr %l255, !tbaa !24
  %t519 = icmp sgt i64 %t518, 0
  br i1 %t519, label %bb100, label %bb101
bb100:
  %t521 = load ptr, ptr %l0, !tbaa !29
  %t522 = load { i64, [4 x i64] }, ptr %l1
  %t523 = load i32, ptr %l2, !tbaa !23
  %t524 = load %"compiler/source:Span", ptr %l3
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2ebang(ptr %v0, ptr %t521, { i64, [4 x i64] } %t522, i32 %t523, %"compiler/source:Span" %t524, i32 13)
  br label %bb102
bb101:
  br label %bb103
bb102:
  br label %ret
bb103:
  br label %bb109
bb104:
  br i1 true, label %bb105, label %bb106
bb105:
  br label %bb107
bb106:
  br label %bb108
bb107:
  br label %bb109
bb108:
  call void @__olang_check_failed(ptr @olang_loc_c6e2ba3cedb073a3_23085f6ef83cda97)
  unreachable
bb109:
  %t530 = load ptr, ptr %l5, !tbaa !29
  %t531 = load i32, ptr %l34, !tbaa !23
  %t534 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t530, i32 %t531)
  store { i64, ptr } %t534, ptr %l264
  br label %bb110
bb110:
  %t535 = load { i64, ptr }, ptr %l264, !tbaa !27
  %t536 = extractvalue { i64, ptr } %t535, 0
  %t538 = icmp eq i64 %t536, 0
  br i1 %t538, label %bb111, label %bb112
bb111:
  store i1 true, ptr %l267, !tbaa !21
  br label %bb114
bb112:
  %t540 = load ptr, ptr %l0, !tbaa !29
  %t542 = getelementptr %"compiler/lower:lowering", ptr %t540, i32 0, i32 13
  %t544 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3atryCtx_3e_2eLen_3ccompiler_2flower_3atryCtx_3e(ptr %v0, ptr %t542)
  store i64 %t544, ptr %l270
  br label %bb113
bb113:
  %t545 = load i64, ptr %l270, !tbaa !24
  %t546 = icmp eq i64 %t545, 0
  store i1 %t546, ptr %l267, !tbaa !21
  br label %bb114
bb114:
  %t548 = load i1, ptr %l267, !tbaa !21
  br i1 %t548, label %bb115, label %bb116
bb115:
  %t549 = load ptr, ptr %l0, !tbaa !29
  %t550 = load %"compiler/source:Span", ptr %l3
  store { i64, [4 x i64] } zeroinitializer, ptr %t551
  %t552 = getelementptr { i64, [4 x i64] }, ptr %t551, i32 0, i32 0
  store i64 0, ptr %t552
  %t553 = load { i64, [4 x i64] }, ptr %t551
  store { i64, [8 x i64] } zeroinitializer, ptr %t554
  %t555 = getelementptr { i64, [8 x i64] }, ptr %t554, i32 0, i32 0
  store i64 8, ptr %t555
  %t557 = insertvalue { %"compiler/source:Span", i32, { i64, [4 x i64] } } undef, %"compiler/source:Span" %t550, 0
  %t559 = insertvalue { %"compiler/source:Span", i32, { i64, [4 x i64] } } %t557, i32 3, 1
  %t561 = insertvalue { %"compiler/source:Span", i32, { i64, [4 x i64] } } %t559, { i64, [4 x i64] } %t553, 2
  %t562 = getelementptr { i64, [8 x i64] }, ptr %t554, i32 0, i32 1
  store { %"compiler/source:Span", i32, { i64, [4 x i64] } } %t561, ptr %t562
  %t563 = load { i64, [8 x i64] }, ptr %t554
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t549, { i64, [8 x i64] } %t563)
  br label %bb117
bb116:
  br label %bb118
bb117:
  br label %ret
bb118:
  %t566 = load ptr, ptr %l0, !tbaa !29
  store ptr %t566, ptr %l277, !tbaa !29
  %t567 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t567, ptr %l278
  %t568 = load ptr, ptr %l0, !tbaa !29
  %t569 = load i32, ptr @G_2ecompiler_2fmir_2eI32T, !tbaa !23
  %t570 = load { i64, [4 x i64] }, ptr %l1
  %t571 = load i32, ptr %l2, !tbaa !23
  %t572 = load i32, ptr %l34, !tbaa !23
  store { i64, [15 x i64] } zeroinitializer, ptr %t573
  %t574 = getelementptr { i64, [15 x i64] }, ptr %t573, i32 0, i32 0
  store i64 11, ptr %t574
  %t576 = insertvalue { { i64, [4 x i64] }, i32, i32 } undef, { i64, [4 x i64] } %t570, 0
  %t578 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t576, i32 %t571, 1
  %t580 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t578, i32 %t572, 2
  %t581 = getelementptr { i64, [15 x i64] }, ptr %t573, i32 0, i32 1
  store { { i64, [4 x i64] }, i32, i32 } %t580, ptr %t581
  %t582 = load { i64, [15 x i64] }, ptr %t573
  %t583 = load %"compiler/source:Span", ptr %l3
  %t588 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %t568, i32 %t569, { i64, [15 x i64] } %t582, %"compiler/source:Span" %t583)
  store { i64, [4 x i64] } %t588, ptr %l286
  br label %bb119
bb119:
  %t589 = load ptr, ptr %l277, !tbaa !29
  %t590 = load %"compiler/source:Span", ptr %l278
  %t591 = load { i64, [4 x i64] }, ptr %l286
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eraise(ptr %v0, ptr %t589, %"compiler/source:Span" %t590, { i64, [4 x i64] } %t591)
  br label %bb120
bb120:
  br label %ret
ret:
  ret void
}

define dso_local { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eequalAt(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/lower:pl" %a1, %"compiler/lower:pl" %a2, i32 %a3, %"compiler/source:Span" %a4, i1 %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/lower:pl"
  %l2 = alloca %"compiler/lower:pl"
  %l3 = alloca i32
  %l4 = alloca %"compiler/source:Span"
  %l6 = alloca ptr
  %l7 = alloca i32
  %l8 = alloca { i64, [4 x i64] }
  %l10 = alloca { i64, [4 x i64] }
  %l12 = alloca i32
  %l13 = alloca i32
  %l14 = alloca i32
  %l15 = alloca { i64, [4 x i64] }
  %l16 = alloca { i64, [4 x i64] }
  %l17 = alloca { i64, [4 x i64] }
  %l18 = alloca { i64, [4 x i64] }
  %l19 = alloca i32
  %l20 = alloca i32
  %l21 = alloca i32
  %l22 = alloca i32
  %l23 = alloca { i64, [4 x i64] }
  %l24 = alloca i32
  %l25 = alloca i32
  %l26 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l27 = alloca { { i64, ptr }, i1 }
  %l28 = alloca { i64, ptr }
  %l29 = alloca i1
  %l30 = alloca { { i64, ptr }, i1 }
  %l31 = alloca { i64, ptr }
  %l32 = alloca i1
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca { i64, [4 x i64] }
  %l40 = alloca i32
  %l41 = alloca { i64, [4 x i64] }
  %l43 = alloca { i64, [4 x i64] }
  %l44 = alloca i32
  %l45 = alloca i32
  %l46 = alloca { i64, [4 x i64] }
  %l48 = alloca { i64, [4 x i64] }
  %l49 = alloca i32
  %l54 = alloca i32
  %l57 = alloca i1
  %l58 = alloca ptr
  %l59 = alloca i32
  %l62 = alloca %"compiler/mir:Place"
  %l66 = alloca { i64, [4 x i64] }
  %l67 = alloca ptr
  %l68 = alloca i32
  %l71 = alloca %"compiler/mir:Place"
  %l75 = alloca { i64, [4 x i64] }
  %l81 = alloca { i64, ptr }
  %l83 = alloca { i64, [4 x i64] }
  %l86 = alloca i32
  %l89 = alloca i1
  %l92 = alloca i1
  %l93 = alloca i1
  %l94 = alloca ptr
  %l97 = alloca i32
  %l98 = alloca i32
  %l101 = alloca ptr
  %l102 = alloca i32
  %l105 = alloca %"compiler/mir:Place"
  %l109 = alloca { i64, [4 x i64] }
  %l110 = alloca ptr
  %l111 = alloca i32
  %l114 = alloca %"compiler/mir:Place"
  %l118 = alloca { i64, [4 x i64] }
  %l124 = alloca { i64, ptr }
  %l126 = alloca { i64, [4 x i64] }
  %l129 = alloca i1
  %l130 = alloca ptr
  %l133 = alloca %"compiler/mir:Place"
  %l137 = alloca i32
  %l138 = alloca ptr
  %l141 = alloca %"compiler/mir:Place"
  %l145 = alloca i32
  %l148 = alloca i32
  %l149 = alloca ptr
  %l150 = alloca i32
  %l151 = alloca i32
  %l153 = alloca %"compiler/mir:Place"
  %l157 = alloca { i64, ptr }
  %l159 = alloca { i64, [4 x i64] }
  %l160 = alloca ptr
  %l161 = alloca i32
  %l162 = alloca i32
  %l164 = alloca %"compiler/mir:Place"
  %l168 = alloca { i64, ptr }
  %l170 = alloca { i64, [4 x i64] }
  %l176 = alloca { i64, ptr }
  %l178 = alloca { i64, [4 x i64] }
  %l184 = alloca { i64, ptr }
  %l186 = alloca { i64, [4 x i64] }
  %l189 = alloca i32
  %l192 = alloca i32
  %l195 = alloca i32
  %l198 = alloca i32
  %l206 = alloca ptr
  %l207 = alloca %"compiler/source:Span"
  %l209 = alloca %"compiler/mir:Place"
  %l212 = alloca { i64, [4 x i64] }
  %l227 = alloca ptr
  %l230 = alloca %"compiler/lower:pl"
  %l233 = alloca %"compiler/lower:pl"
  %l236 = alloca i32
  %l238 = alloca { i64, [4 x i64] }
  %l239 = alloca ptr
  %l240 = alloca %"compiler/source:Span"
  %l242 = alloca %"compiler/mir:Place"
  %l252 = alloca %"compiler/mir:Place"
  %l256 = alloca ptr
  %l257 = alloca i32
  %l258 = alloca i32
  %l263 = alloca { i64, [4 x i64] }
  %l268 = alloca { i64, [4 x i64] }
  %l269 = alloca { i64, ptr }
  %l273 = alloca { i64, [4 x i64] }
  %l276 = alloca i32
  %l279 = alloca i32
  %l280 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l283 = alloca { { i64, ptr }, i1 }
  %l284 = alloca { i64, ptr }
  %l285 = alloca i64
  %l286 = alloca { i64, ptr }
  %l290 = alloca { { i64, ptr }, i1 }
  %l291 = alloca { i64, ptr }
  %l292 = alloca i64
  %l293 = alloca { i64, ptr }
  %l301 = alloca i64
  %l304 = alloca i64
  %l322 = alloca ptr
  %l327 = alloca %"compiler/lower:pl"
  %l332 = alloca %"compiler/lower:pl"
  %l336 = alloca { i64, [4 x i64] }
  %l339 = alloca i32
  %l350 = alloca ptr
  %l351 = alloca i32
  %l354 = alloca %"compiler/mir:Place"
  %l357 = alloca { i64, [4 x i64] }
  %l358 = alloca ptr
  %l359 = alloca i32
  %l362 = alloca %"compiler/mir:Place"
  %l365 = alloca { i64, [4 x i64] }
  %l371 = alloca { i64, ptr }
  %l373 = alloca { i64, [4 x i64] }
  %l376 = alloca i32
  %l396 = alloca i32
  %l399 = alloca ptr
  %l402 = alloca i32
  %l403 = alloca i32
  %l404 = alloca ptr
  %l405 = alloca i32
  %l406 = alloca i32
  %l409 = alloca %"compiler/mir:Place"
  %l411 = alloca { i64, ptr }
  %l413 = alloca { i64, [4 x i64] }
  %l414 = alloca ptr
  %l415 = alloca i32
  %l416 = alloca i32
  %l419 = alloca %"compiler/mir:Place"
  %l421 = alloca { i64, ptr }
  %l423 = alloca { i64, [4 x i64] }
  %l429 = alloca { i64, ptr }
  %l431 = alloca { i64, [4 x i64] }
  %l434 = alloca i32
  %l458 = alloca ptr
  %l459 = alloca %"compiler/source:Span"
  %l461 = alloca %"compiler/mir:Place"
  %l464 = alloca { i64, [4 x i64] }
  %l473 = alloca %"compiler/mir:Place"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %rv = alloca { i64, [4 x i64] }
  %t25 = alloca { i64, [4 x i64] }, align 8
  %t31 = alloca { i64, [15 x i64] }, align 8
  %t51 = alloca { i64, [4 x i64] }, align 8
  %t57 = alloca { i64, [15 x i64] }, align 8
  %t133 = alloca { i64, [4 x i64] }, align 8
  %t139 = alloca { i64, [15 x i64] }, align 8
  %t159 = alloca { i64, [4 x i64] }, align 8
  %t165 = alloca { i64, [15 x i64] }, align 8
  %t214 = alloca { i64, [4 x i64] }, align 8
  %t234 = alloca { i64, [4 x i64] }, align 8
  %t259 = alloca { i64, [4 x i64] }, align 8
  %t266 = alloca { i64, [4 x i64] }, align 8
  %t298 = alloca { i64, [4 x i64] }, align 8
  %t305 = alloca { i64, [4 x i64] }, align 8
  %t408 = alloca { i64, [8 x i64] }, align 8
  %t434 = alloca { i64, [15 x i64] }, align 8
  %t440 = alloca { i64, [21 x i64] }, align 8
  %t466 = alloca { i64, [8 x i64] }, align 8
  %t512 = alloca { i64, [15 x i64] }, align 8
  %t518 = alloca { i64, [21 x i64] }, align 8
  %t543 = alloca { i64, [4 x i64] }, align 8
  %t723 = alloca { i64, [1 x i64] }, align 8
  %t736 = alloca { i64, [1 x i64] }, align 8
  %t770 = alloca { i64, [8 x i64] }, align 8
  %t802 = alloca { i64, [15 x i64] }, align 8
  %t822 = alloca { i64, [15 x i64] }, align 8
  %t869 = alloca { i64, [8 x i64] }, align 8
  %t896 = alloca { ptr, %"compiler/lower:pl", %"compiler/lower:pl", %"compiler/source:Span", i32, ptr, ptr, ptr }, align 8
  %t945 = alloca { i64, [4 x i64] }, align 8
  %t974 = alloca { i64, [4 x i64] }, align 8
  %t1030 = alloca { i64, [8 x i64] }, align 8
  %t1057 = alloca { ptr, %"compiler/lower:pl", %"compiler/lower:pl", i32, %"compiler/source:Span", i32, ptr, ptr, ptr }, align 8
  %t1098 = alloca { i64, [15 x i64] }, align 8
  %t1104 = alloca { i64, [21 x i64] }, align 8
  %t1128 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/lower:pl" %a1, ptr %l1
  store %"compiler/lower:pl" %a2, ptr %l2
  store i32 %a3, ptr %l3
  store %"compiler/source:Span" %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l6, !tbaa !29
  %t6 = load ptr, ptr %l6, !tbaa !29
  %t7 = load i32, ptr %l3, !tbaa !23
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t6, i32 %t7)
  store i32 %t10, ptr %l54
  br label %bb1
bb1:
  %t11 = load i32, ptr %l54, !tbaa !23
  store i32 %t11, ptr %l7, !tbaa !23
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load i32, ptr %l3, !tbaa !23
  %t16 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2escalar(ptr %v0, ptr %t12, i32 %t13)
  store i1 %t16, ptr %l57
  br label %bb2
bb2:
  %t17 = load i1, ptr %l57, !tbaa !21
  br i1 %t17, label %bb3, label %bb4
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t18 = load ptr, ptr %l0, !tbaa !29
  store ptr %t18, ptr %l58, !tbaa !29
  %t19 = load i32, ptr %l3, !tbaa !23
  store i32 %t19, ptr %l59, !tbaa !23
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load %"compiler/lower:pl", ptr %l1
  %t24 = call %"compiler/mir:Place" @compiler_2flower_2ecompiler_2flower_3alowering_2emk(ptr %v0, ptr %v1, ptr %t20, %"compiler/lower:pl" %t21)
  store %"compiler/mir:Place" %t24, ptr %l62
  br label %bb5
bb4:
  br label %bb10
bb5:
  store { i64, [4 x i64] } zeroinitializer, ptr %t25
  %t26 = getelementptr { i64, [4 x i64] }, ptr %t25, i32 0, i32 0
  store i64 1, ptr %t26
  %t27 = load %"compiler/mir:Place", ptr %l62
  %t28 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t27, 0
  %t29 = getelementptr { i64, [4 x i64] }, ptr %t25, i32 0, i32 1
  store { %"compiler/mir:Place" } %t28, ptr %t29
  %t30 = load { i64, [4 x i64] }, ptr %t25
  store { i64, [15 x i64] } zeroinitializer, ptr %t31
  %t32 = getelementptr { i64, [15 x i64] }, ptr %t31, i32 0, i32 0
  store i64 0, ptr %t32
  %t34 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t30, 0
  %t35 = getelementptr { i64, [15 x i64] }, ptr %t31, i32 0, i32 1
  store { { i64, [4 x i64] } } %t34, ptr %t35
  %t36 = load { i64, [15 x i64] }, ptr %t31
  %t37 = load %"compiler/source:Span", ptr %l4
  %t38 = load ptr, ptr %l58, !tbaa !29
  %t39 = load i32, ptr %l59, !tbaa !23
  %t42 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %t38, i32 %t39, { i64, [15 x i64] } %t36, %"compiler/source:Span" %t37)
  store { i64, [4 x i64] } %t42, ptr %l66
  br label %bb6
bb6:
  %t43 = load { i64, [4 x i64] }, ptr %l66
  store { i64, [4 x i64] } %t43, ptr %l8
  %t44 = load ptr, ptr %l0, !tbaa !29
  store ptr %t44, ptr %l67, !tbaa !29
  %t45 = load i32, ptr %l3, !tbaa !23
  store i32 %t45, ptr %l68, !tbaa !23
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = load %"compiler/lower:pl", ptr %l2
  %t50 = call %"compiler/mir:Place" @compiler_2flower_2ecompiler_2flower_3alowering_2emk(ptr %v0, ptr %v2, ptr %t46, %"compiler/lower:pl" %t47)
  store %"compiler/mir:Place" %t50, ptr %l71
  br label %bb7
bb7:
  store { i64, [4 x i64] } zeroinitializer, ptr %t51
  %t52 = getelementptr { i64, [4 x i64] }, ptr %t51, i32 0, i32 0
  store i64 1, ptr %t52
  %t53 = load %"compiler/mir:Place", ptr %l71
  %t54 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t53, 0
  %t55 = getelementptr { i64, [4 x i64] }, ptr %t51, i32 0, i32 1
  store { %"compiler/mir:Place" } %t54, ptr %t55
  %t56 = load { i64, [4 x i64] }, ptr %t51
  store { i64, [15 x i64] } zeroinitializer, ptr %t57
  %t58 = getelementptr { i64, [15 x i64] }, ptr %t57, i32 0, i32 0
  store i64 0, ptr %t58
  %t60 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t56, 0
  %t61 = getelementptr { i64, [15 x i64] }, ptr %t57, i32 0, i32 1
  store { { i64, [4 x i64] } } %t60, ptr %t61
  %t62 = load { i64, [15 x i64] }, ptr %t57
  %t63 = load %"compiler/source:Span", ptr %l4
  %t64 = load ptr, ptr %l67, !tbaa !29
  %t65 = load i32, ptr %l68, !tbaa !23
  %t68 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %t64, i32 %t65, { i64, [15 x i64] } %t62, %"compiler/source:Span" %t63)
  store { i64, [4 x i64] } %t68, ptr %l75
  br label %bb8
bb8:
  %t69 = load { i64, [4 x i64] }, ptr %l75
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t71 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t72 = load { i64, [4 x i64] }, ptr %l8
  %t74 = mul i64 2, 40
  %t75 = call ptr @__olang_scope_alloc_zeroed(ptr %s1, i64 %t74)
  %t76 = insertvalue { i64, ptr } undef, i64 2, 0
  %t77 = insertvalue { i64, ptr } %t76, ptr %t75, 1
  store { i64, ptr } %t77, ptr %l81, !tbaa !27
  %t79 = getelementptr { i64, ptr }, ptr %l81, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !27
  %t81 = getelementptr { i64, [4 x i64] }, ptr %t80, i64 0
  store { i64, [4 x i64] } %t72, ptr %t81
  %t83 = getelementptr { i64, ptr }, ptr %l81, i32 0, i32 1
  %t84 = load ptr, ptr %t83, !tbaa !27
  %t85 = getelementptr { i64, [4 x i64] }, ptr %t84, i64 1
  store { i64, [4 x i64] } %t69, ptr %t85
  %t86 = load %"compiler/source:Span", ptr %l4
  %t90 = load { i64, ptr }, ptr %l81, !tbaa !27
  %t92 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s1, ptr %t70, i32 13, i32 %t71, { i64, ptr } %t90, %"compiler/source:Span" %t86)
  store { i64, [4 x i64] } %t92, ptr %l83
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t93 = load { i64, [4 x i64] }, ptr %l83
  store { i64, [4 x i64] } %t93, ptr %rv
  br label %ret
bb10:
  %t94 = load ptr, ptr %l6, !tbaa !29
  %t95 = load i32, ptr %l7, !tbaa !23
  %t98 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t94, i32 %t95)
  store i32 %t98, ptr %l86
  br label %bb11
bb11:
  %t99 = load i32, ptr %l86
  %t101 = trunc i64 21 to i32
  %t102 = icmp eq i32 %t99, %t101
  br i1 %t102, label %bb12, label %bb13
bb12:
  store i1 true, ptr %l89, !tbaa !21
  br label %bb20
bb13:
  %t104 = load ptr, ptr %l6, !tbaa !29
  %t105 = load i32, ptr %l7, !tbaa !23
  %t108 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t104, i32 %t105)
  store i1 %t108, ptr %l92
  br label %bb14
bb14:
  %t109 = load i1, ptr %l92, !tbaa !21
  br i1 %t109, label %bb15, label %bb16
bb15:
  %t110 = load ptr, ptr %l0, !tbaa !29
  store ptr %t110, ptr %l94, !tbaa !29
  %t111 = load ptr, ptr %l6, !tbaa !29
  %t112 = load i32, ptr %l7, !tbaa !23
  %t115 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t111, i32 %t112)
  store i32 %t115, ptr %l97
  br label %bb17
bb16:
  store i1 false, ptr %l93, !tbaa !21
  br label %bb19
bb17:
  %t116 = load ptr, ptr %l94, !tbaa !29
  %t117 = load i32, ptr %l97, !tbaa !23
  %t118 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2earrayOf(ptr %v0, ptr %t116, i32 %t117)
  store i32 %t118, ptr %l98
  br label %bb18
bb18:
  %t119 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t120 = load i32, ptr %l98, !tbaa !23
  %t122 = icmp eq i32 %t120, %t119
  store i1 %t122, ptr %l93, !tbaa !21
  br label %bb19
bb19:
  %t124 = load i1, ptr %l93, !tbaa !21
  store i1 %t124, ptr %l89, !tbaa !21
  br label %bb20
bb20:
  %t125 = load i1, ptr %l89, !tbaa !21
  br i1 %t125, label %bb21, label %bb22
bb21:
  store %olang.scope zeroinitializer, ptr %s2
  %t126 = load ptr, ptr %l0, !tbaa !29
  store ptr %t126, ptr %l101, !tbaa !29
  %t127 = load i32, ptr %l3, !tbaa !23
  store i32 %t127, ptr %l102, !tbaa !23
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t129 = load %"compiler/lower:pl", ptr %l1
  %t132 = call %"compiler/mir:Place" @compiler_2flower_2ecompiler_2flower_3alowering_2emk(ptr %v0, ptr %v1, ptr %t128, %"compiler/lower:pl" %t129)
  store %"compiler/mir:Place" %t132, ptr %l105
  br label %bb23
bb22:
  br label %bb28
bb23:
  store { i64, [4 x i64] } zeroinitializer, ptr %t133
  %t134 = getelementptr { i64, [4 x i64] }, ptr %t133, i32 0, i32 0
  store i64 1, ptr %t134
  %t135 = load %"compiler/mir:Place", ptr %l105
  %t136 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t135, 0
  %t137 = getelementptr { i64, [4 x i64] }, ptr %t133, i32 0, i32 1
  store { %"compiler/mir:Place" } %t136, ptr %t137
  %t138 = load { i64, [4 x i64] }, ptr %t133
  store { i64, [15 x i64] } zeroinitializer, ptr %t139
  %t140 = getelementptr { i64, [15 x i64] }, ptr %t139, i32 0, i32 0
  store i64 0, ptr %t140
  %t142 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t138, 0
  %t143 = getelementptr { i64, [15 x i64] }, ptr %t139, i32 0, i32 1
  store { { i64, [4 x i64] } } %t142, ptr %t143
  %t144 = load { i64, [15 x i64] }, ptr %t139
  %t145 = load %"compiler/source:Span", ptr %l4
  %t146 = load ptr, ptr %l101, !tbaa !29
  %t147 = load i32, ptr %l102, !tbaa !23
  %t150 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %t146, i32 %t147, { i64, [15 x i64] } %t144, %"compiler/source:Span" %t145)
  store { i64, [4 x i64] } %t150, ptr %l109
  br label %bb24
bb24:
  %t151 = load { i64, [4 x i64] }, ptr %l109
  store { i64, [4 x i64] } %t151, ptr %l10
  %t152 = load ptr, ptr %l0, !tbaa !29
  store ptr %t152, ptr %l110, !tbaa !29
  %t153 = load i32, ptr %l3, !tbaa !23
  store i32 %t153, ptr %l111, !tbaa !23
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t155 = load %"compiler/lower:pl", ptr %l2
  %t158 = call %"compiler/mir:Place" @compiler_2flower_2ecompiler_2flower_3alowering_2emk(ptr %v0, ptr %v2, ptr %t154, %"compiler/lower:pl" %t155)
  store %"compiler/mir:Place" %t158, ptr %l114
  br label %bb25
bb25:
  store { i64, [4 x i64] } zeroinitializer, ptr %t159
  %t160 = getelementptr { i64, [4 x i64] }, ptr %t159, i32 0, i32 0
  store i64 1, ptr %t160
  %t161 = load %"compiler/mir:Place", ptr %l114
  %t162 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t161, 0
  %t163 = getelementptr { i64, [4 x i64] }, ptr %t159, i32 0, i32 1
  store { %"compiler/mir:Place" } %t162, ptr %t163
  %t164 = load { i64, [4 x i64] }, ptr %t159
  store { i64, [15 x i64] } zeroinitializer, ptr %t165
  %t166 = getelementptr { i64, [15 x i64] }, ptr %t165, i32 0, i32 0
  store i64 0, ptr %t166
  %t168 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t164, 0
  %t169 = getelementptr { i64, [15 x i64] }, ptr %t165, i32 0, i32 1
  store { { i64, [4 x i64] } } %t168, ptr %t169
  %t170 = load { i64, [15 x i64] }, ptr %t165
  %t171 = load %"compiler/source:Span", ptr %l4
  %t172 = load ptr, ptr %l110, !tbaa !29
  %t173 = load i32, ptr %l111, !tbaa !23
  %t176 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %t172, i32 %t173, { i64, [15 x i64] } %t170, %"compiler/source:Span" %t171)
  store { i64, [4 x i64] } %t176, ptr %l118
  br label %bb26
bb26:
  %t177 = load { i64, [4 x i64] }, ptr %l118
  %t178 = load ptr, ptr %l0, !tbaa !29
  %t179 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t180 = load { i64, [4 x i64] }, ptr %l10
  %t182 = mul i64 2, 40
  %t183 = call ptr @__olang_scope_alloc_zeroed(ptr %s2, i64 %t182)
  %t184 = insertvalue { i64, ptr } undef, i64 2, 0
  %t185 = insertvalue { i64, ptr } %t184, ptr %t183, 1
  store { i64, ptr } %t185, ptr %l124, !tbaa !27
  %t187 = getelementptr { i64, ptr }, ptr %l124, i32 0, i32 1
  %t188 = load ptr, ptr %t187, !tbaa !27
  %t189 = getelementptr { i64, [4 x i64] }, ptr %t188, i64 0
  store { i64, [4 x i64] } %t180, ptr %t189
  %t191 = getelementptr { i64, ptr }, ptr %l124, i32 0, i32 1
  %t192 = load ptr, ptr %t191, !tbaa !27
  %t193 = getelementptr { i64, [4 x i64] }, ptr %t192, i64 1
  store { i64, [4 x i64] } %t177, ptr %t193
  %t194 = load %"compiler/source:Span", ptr %l4
  %t198 = load { i64, ptr }, ptr %l124, !tbaa !27
  %t200 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s2, ptr %t178, i32 19, i32 %t179, { i64, ptr } %t198, %"compiler/source:Span" %t194)
  store { i64, [4 x i64] } %t200, ptr %l126
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t201 = load { i64, [4 x i64] }, ptr %l126
  store { i64, [4 x i64] } %t201, ptr %rv
  br label %ret
bb28:
  %t202 = load ptr, ptr %l6, !tbaa !29
  %t203 = load i32, ptr %l7, !tbaa !23
  %t206 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t202, i32 %t203)
  store i1 %t206, ptr %l129
  br label %bb29
bb29:
  %t207 = load i1, ptr %l129, !tbaa !21
  br i1 %t207, label %bb30, label %bb31
bb30:
  store %olang.scope zeroinitializer, ptr %s3
  %t208 = load ptr, ptr %l0, !tbaa !29
  store ptr %t208, ptr %l130, !tbaa !29
  %t209 = load ptr, ptr %l0, !tbaa !29
  %t210 = load %"compiler/lower:pl", ptr %l1
  %t213 = call %"compiler/mir:Place" @compiler_2flower_2ecompiler_2flower_3alowering_2emk(ptr %v0, ptr %v1, ptr %t209, %"compiler/lower:pl" %t210)
  store %"compiler/mir:Place" %t213, ptr %l133
  br label %bb32
bb31:
  br label %bb65
bb32:
  store { i64, [4 x i64] } zeroinitializer, ptr %t214
  %t215 = getelementptr { i64, [4 x i64] }, ptr %t214, i32 0, i32 0
  store i64 1, ptr %t215
  %t216 = load %"compiler/mir:Place", ptr %l133
  %t217 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t216, 0
  %t218 = getelementptr { i64, [4 x i64] }, ptr %t214, i32 0, i32 1
  store { %"compiler/mir:Place" } %t217, ptr %t218
  %t219 = load { i64, [4 x i64] }, ptr %t214
  %t220 = load i32, ptr %l3, !tbaa !23
  %t221 = load %"compiler/source:Span", ptr %l4
  %t222 = load ptr, ptr %l130, !tbaa !29
  %t226 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2elocal(ptr %v0, ptr %t222, { i64, [4 x i64] } %t219, i32 %t220, %"compiler/source:Span" %t221)
  store i32 %t226, ptr %l137
  br label %bb33
bb33:
  %t227 = load i32, ptr %l137, !tbaa !23
  store i32 %t227, ptr %l12, !tbaa !23
  %t228 = load ptr, ptr %l0, !tbaa !29
  store ptr %t228, ptr %l138, !tbaa !29
  %t229 = load ptr, ptr %l0, !tbaa !29
  %t230 = load %"compiler/lower:pl", ptr %l2
  %t233 = call %"compiler/mir:Place" @compiler_2flower_2ecompiler_2flower_3alowering_2emk(ptr %v0, ptr %v2, ptr %t229, %"compiler/lower:pl" %t230)
  store %"compiler/mir:Place" %t233, ptr %l141
  br label %bb34
bb34:
  store { i64, [4 x i64] } zeroinitializer, ptr %t234
  %t235 = getelementptr { i64, [4 x i64] }, ptr %t234, i32 0, i32 0
  store i64 1, ptr %t235
  %t236 = load %"compiler/mir:Place", ptr %l141
  %t237 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t236, 0
  %t238 = getelementptr { i64, [4 x i64] }, ptr %t234, i32 0, i32 1
  store { %"compiler/mir:Place" } %t237, ptr %t238
  %t239 = load { i64, [4 x i64] }, ptr %t234
  %t240 = load i32, ptr %l3, !tbaa !23
  %t241 = load %"compiler/source:Span", ptr %l4
  %t242 = load ptr, ptr %l138, !tbaa !29
  %t246 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2elocal(ptr %v0, ptr %t242, { i64, [4 x i64] } %t239, i32 %t240, %"compiler/source:Span" %t241)
  store i32 %t246, ptr %l145
  br label %bb35
bb35:
  %t247 = load i32, ptr %l145, !tbaa !23
  store i32 %t247, ptr %l13, !tbaa !23
  %t248 = load ptr, ptr %l0, !tbaa !29
  %t249 = load %"compiler/source:Span", ptr %l4
  %t252 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2eflag(ptr %v0, ptr %t248, i1 false, %"compiler/source:Span" %t249)
  store i32 %t252, ptr %l148
  br label %bb36
bb36:
  %t253 = load i32, ptr %l148, !tbaa !23
  store i32 %t253, ptr %l14, !tbaa !23
  %t254 = load ptr, ptr %l0, !tbaa !29
  store ptr %t254, ptr %l149, !tbaa !29
  store i32 13, ptr %l150
  %t255 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t255, ptr %l151, !tbaa !23
  %t256 = load i32, ptr %l12, !tbaa !23
  %t258 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t256)
  store %"compiler/mir:Place" %t258, ptr %l153
  br label %bb37
bb37:
  store { i64, [4 x i64] } zeroinitializer, ptr %t259
  %t260 = getelementptr { i64, [4 x i64] }, ptr %t259, i32 0, i32 0
  store i64 1, ptr %t260
  %t261 = load %"compiler/mir:Place", ptr %l153
  %t262 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t261, 0
  %t263 = getelementptr { i64, [4 x i64] }, ptr %t259, i32 0, i32 1
  store { %"compiler/mir:Place" } %t262, ptr %t263
  %t264 = load { i64, [4 x i64] }, ptr %t259
  %t265 = load i32, ptr %l3, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t266
  %t267 = getelementptr { i64, [4 x i64] }, ptr %t266, i32 0, i32 0
  store i64 2, ptr %t267
  %t269 = insertvalue { i32, i64 } undef, i32 %t265, 0
  %t270 = insertvalue { i32, i64 } %t269, i64 0, 1
  %t271 = getelementptr { i64, [4 x i64] }, ptr %t266, i32 0, i32 1
  store { i32, i64 } %t270, ptr %t271
  %t272 = load { i64, [4 x i64] }, ptr %t266
  %t273 = mul i64 2, 40
  %t274 = call ptr @__olang_scope_alloc_zeroed(ptr %s3, i64 %t273)
  %t275 = insertvalue { i64, ptr } undef, i64 2, 0
  %t276 = insertvalue { i64, ptr } %t275, ptr %t274, 1
  store { i64, ptr } %t276, ptr %l157, !tbaa !27
  %t278 = getelementptr { i64, ptr }, ptr %l157, i32 0, i32 1
  %t279 = load ptr, ptr %t278, !tbaa !27
  %t280 = getelementptr { i64, [4 x i64] }, ptr %t279, i64 0
  store { i64, [4 x i64] } %t264, ptr %t280
  %t282 = getelementptr { i64, ptr }, ptr %l157, i32 0, i32 1
  %t283 = load ptr, ptr %t282, !tbaa !27
  %t284 = getelementptr { i64, [4 x i64] }, ptr %t283, i64 1
  store { i64, [4 x i64] } %t272, ptr %t284
  %t285 = load %"compiler/source:Span", ptr %l4
  %t286 = load ptr, ptr %l149, !tbaa !29
  %t287 = load i32, ptr %l150
  %t288 = load i32, ptr %l151, !tbaa !23
  %t289 = load { i64, ptr }, ptr %l157, !tbaa !27
  %t291 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s3, ptr %t286, i32 %t287, i32 %t288, { i64, ptr } %t289, %"compiler/source:Span" %t285)
  store { i64, [4 x i64] } %t291, ptr %l159
  br label %bb38
bb38:
  %t292 = load { i64, [4 x i64] }, ptr %l159
  store { i64, [4 x i64] } %t292, ptr %l15
  %t293 = load ptr, ptr %l0, !tbaa !29
  store ptr %t293, ptr %l160, !tbaa !29
  store i32 13, ptr %l161
  %t294 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t294, ptr %l162, !tbaa !23
  %t295 = load i32, ptr %l13, !tbaa !23
  %t297 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t295)
  store %"compiler/mir:Place" %t297, ptr %l164
  br label %bb39
bb39:
  store { i64, [4 x i64] } zeroinitializer, ptr %t298
  %t299 = getelementptr { i64, [4 x i64] }, ptr %t298, i32 0, i32 0
  store i64 1, ptr %t299
  %t300 = load %"compiler/mir:Place", ptr %l164
  %t301 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t300, 0
  %t302 = getelementptr { i64, [4 x i64] }, ptr %t298, i32 0, i32 1
  store { %"compiler/mir:Place" } %t301, ptr %t302
  %t303 = load { i64, [4 x i64] }, ptr %t298
  %t304 = load i32, ptr %l3, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t305
  %t306 = getelementptr { i64, [4 x i64] }, ptr %t305, i32 0, i32 0
  store i64 2, ptr %t306
  %t308 = insertvalue { i32, i64 } undef, i32 %t304, 0
  %t309 = insertvalue { i32, i64 } %t308, i64 0, 1
  %t310 = getelementptr { i64, [4 x i64] }, ptr %t305, i32 0, i32 1
  store { i32, i64 } %t309, ptr %t310
  %t311 = load { i64, [4 x i64] }, ptr %t305
  %t312 = mul i64 2, 40
  %t313 = call ptr @__olang_scope_alloc_zeroed(ptr %s3, i64 %t312)
  %t314 = insertvalue { i64, ptr } undef, i64 2, 0
  %t315 = insertvalue { i64, ptr } %t314, ptr %t313, 1
  store { i64, ptr } %t315, ptr %l168, !tbaa !27
  %t317 = getelementptr { i64, ptr }, ptr %l168, i32 0, i32 1
  %t318 = load ptr, ptr %t317, !tbaa !27
  %t319 = getelementptr { i64, [4 x i64] }, ptr %t318, i64 0
  store { i64, [4 x i64] } %t303, ptr %t319
  %t321 = getelementptr { i64, ptr }, ptr %l168, i32 0, i32 1
  %t322 = load ptr, ptr %t321, !tbaa !27
  %t323 = getelementptr { i64, [4 x i64] }, ptr %t322, i64 1
  store { i64, [4 x i64] } %t311, ptr %t323
  %t324 = load %"compiler/source:Span", ptr %l4
  %t325 = load ptr, ptr %l160, !tbaa !29
  %t326 = load i32, ptr %l161
  %t327 = load i32, ptr %l162, !tbaa !23
  %t328 = load { i64, ptr }, ptr %l168, !tbaa !27
  %t330 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s3, ptr %t325, i32 %t326, i32 %t327, { i64, ptr } %t328, %"compiler/source:Span" %t324)
  store { i64, [4 x i64] } %t330, ptr %l170
  br label %bb40
bb40:
  %t331 = load { i64, [4 x i64] }, ptr %l170
  store { i64, [4 x i64] } %t331, ptr %l16
  %t332 = load ptr, ptr %l0, !tbaa !29
  %t333 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t334 = load { i64, [4 x i64] }, ptr %l15
  %t335 = load { i64, [4 x i64] }, ptr %l16
  %t336 = mul i64 2, 40
  %t337 = call ptr @__olang_scope_alloc_zeroed(ptr %s3, i64 %t336)
  %t338 = insertvalue { i64, ptr } undef, i64 2, 0
  %t339 = insertvalue { i64, ptr } %t338, ptr %t337, 1
  store { i64, ptr } %t339, ptr %l176, !tbaa !27
  %t341 = getelementptr { i64, ptr }, ptr %l176, i32 0, i32 1
  %t342 = load ptr, ptr %t341, !tbaa !27
  %t343 = getelementptr { i64, [4 x i64] }, ptr %t342, i64 0
  store { i64, [4 x i64] } %t334, ptr %t343
  %t345 = getelementptr { i64, ptr }, ptr %l176, i32 0, i32 1
  %t346 = load ptr, ptr %t345, !tbaa !27
  %t347 = getelementptr { i64, [4 x i64] }, ptr %t346, i64 1
  store { i64, [4 x i64] } %t335, ptr %t347
  %t348 = load %"compiler/source:Span", ptr %l4
  %t352 = load { i64, ptr }, ptr %l176, !tbaa !27
  %t354 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s3, ptr %t332, i32 10, i32 %t333, { i64, ptr } %t352, %"compiler/source:Span" %t348)
  store { i64, [4 x i64] } %t354, ptr %l178
  br label %bb41
bb41:
  %t355 = load { i64, [4 x i64] }, ptr %l178
  store { i64, [4 x i64] } %t355, ptr %l17
  %t356 = load ptr, ptr %l0, !tbaa !29
  %t357 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t358 = load { i64, [4 x i64] }, ptr %l15
  %t359 = load { i64, [4 x i64] }, ptr %l16
  %t360 = mul i64 2, 40
  %t361 = call ptr @__olang_scope_alloc_zeroed(ptr %s3, i64 %t360)
  %t362 = insertvalue { i64, ptr } undef, i64 2, 0
  %t363 = insertvalue { i64, ptr } %t362, ptr %t361, 1
  store { i64, ptr } %t363, ptr %l184, !tbaa !27
  %t365 = getelementptr { i64, ptr }, ptr %l184, i32 0, i32 1
  %t366 = load ptr, ptr %t365, !tbaa !27
  %t367 = getelementptr { i64, [4 x i64] }, ptr %t366, i64 0
  store { i64, [4 x i64] } %t358, ptr %t367
  %t369 = getelementptr { i64, ptr }, ptr %l184, i32 0, i32 1
  %t370 = load ptr, ptr %t369, !tbaa !27
  %t371 = getelementptr { i64, [4 x i64] }, ptr %t370, i64 1
  store { i64, [4 x i64] } %t359, ptr %t371
  %t372 = load %"compiler/source:Span", ptr %l4
  %t376 = load { i64, ptr }, ptr %l184, !tbaa !27
  %t378 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s3, ptr %t356, i32 11, i32 %t357, { i64, ptr } %t376, %"compiler/source:Span" %t372)
  store { i64, [4 x i64] } %t378, ptr %l186
  br label %bb42
bb42:
  %t379 = load { i64, [4 x i64] }, ptr %l186
  store { i64, [4 x i64] } %t379, ptr %l18
  %t380 = load ptr, ptr %l0, !tbaa !29
  %t382 = getelementptr %"compiler/lower:lowering", ptr %t380, i32 0, i32 3
  %t384 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t382)
  store i32 %t384, ptr %l189
  br label %bb43
bb43:
  %t385 = load i32, ptr %l189, !tbaa !23
  store i32 %t385, ptr %l19, !tbaa !23
  %t386 = load ptr, ptr %l0, !tbaa !29
  %t388 = getelementptr %"compiler/lower:lowering", ptr %t386, i32 0, i32 3
  %t390 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t388)
  store i32 %t390, ptr %l192
  br label %bb44
bb44:
  %t391 = load i32, ptr %l192, !tbaa !23
  store i32 %t391, ptr %l20, !tbaa !23
  %t392 = load ptr, ptr %l0, !tbaa !29
  %t394 = getelementptr %"compiler/lower:lowering", ptr %t392, i32 0, i32 3
  %t396 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t394)
  store i32 %t396, ptr %l195
  br label %bb45
bb45:
  %t397 = load i32, ptr %l195, !tbaa !23
  store i32 %t397, ptr %l21, !tbaa !23
  %t398 = load ptr, ptr %l0, !tbaa !29
  %t400 = getelementptr %"compiler/lower:lowering", ptr %t398, i32 0, i32 3
  %t402 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t400)
  store i32 %t402, ptr %l198
  br label %bb46
bb46:
  %t403 = load i32, ptr %l198, !tbaa !23
  store i32 %t403, ptr %l22, !tbaa !23
  %t404 = load ptr, ptr %l0, !tbaa !29
  %t405 = load { i64, [4 x i64] }, ptr %l17
  %t406 = load i32, ptr %l19, !tbaa !23
  %t407 = load i32, ptr %l20, !tbaa !23
  store { i64, [8 x i64] } zeroinitializer, ptr %t408
  %t409 = getelementptr { i64, [8 x i64] }, ptr %t408, i32 0, i32 0
  store i64 2, ptr %t409
  %t411 = insertvalue { { i64, [4 x i64] }, i32, i32 } undef, { i64, [4 x i64] } %t405, 0
  %t413 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t411, i32 %t406, 1
  %t415 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t413, i32 %t407, 2
  %t416 = getelementptr { i64, [8 x i64] }, ptr %t408, i32 0, i32 1
  store { { i64, [4 x i64] }, i32, i32 } %t415, ptr %t416
  %t417 = load { i64, [8 x i64] }, ptr %t408
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t404, { i64, [8 x i64] } %t417)
  br label %bb47
bb47:
  %t420 = load ptr, ptr %l0, !tbaa !29
  %t421 = load i32, ptr %l19, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t420, i32 %t421)
  br label %bb48
bb48:
  %t424 = load ptr, ptr %l0, !tbaa !29
  store ptr %t424, ptr %l206, !tbaa !29
  %t425 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t425, ptr %l207
  %t426 = load i32, ptr %l14, !tbaa !23
  %t428 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t426)
  store %"compiler/mir:Place" %t428, ptr %l209
  br label %bb49
bb49:
  %t429 = load ptr, ptr %l0, !tbaa !29
  %t430 = load %"compiler/source:Span", ptr %l4
  %t433 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2econstBool(ptr %v0, ptr %t429, i1 true, %"compiler/source:Span" %t430)
  store { i64, [4 x i64] } %t433, ptr %l212
  br label %bb50
bb50:
  store { i64, [15 x i64] } zeroinitializer, ptr %t434
  %t435 = getelementptr { i64, [15 x i64] }, ptr %t434, i32 0, i32 0
  store i64 0, ptr %t435
  %t436 = load { i64, [4 x i64] }, ptr %l212
  %t437 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t436, 0
  %t438 = getelementptr { i64, [15 x i64] }, ptr %t434, i32 0, i32 1
  store { { i64, [4 x i64] } } %t437, ptr %t438
  %t439 = load { i64, [15 x i64] }, ptr %t434
  store { i64, [21 x i64] } zeroinitializer, ptr %t440
  %t441 = getelementptr { i64, [21 x i64] }, ptr %t440, i32 0, i32 0
  store i64 0, ptr %t441
  %t442 = load %"compiler/source:Span", ptr %l207
  %t443 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t442, 0
  %t444 = load %"compiler/mir:Place", ptr %l209
  %t445 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t443, %"compiler/mir:Place" %t444, 1
  %t447 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t445, { i64, [15 x i64] } %t439, 2
  %t448 = getelementptr { i64, [21 x i64] }, ptr %t440, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t447, ptr %t448
  %t449 = load { i64, [21 x i64] }, ptr %t440
  %t451 = call ptr @__olang_scope_alloc_a(ptr %s3, i64 176, i64 8)
  store { i64, [21 x i64] } %t449, ptr %t451
  %t452 = load ptr, ptr %l206, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s3, ptr %t452, ptr %t451)
  br label %bb51
bb51:
  %t454 = load ptr, ptr %l0, !tbaa !29
  %t455 = load i32, ptr %l22, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2egoto(ptr %v0, ptr %t454, i32 %t455)
  br label %bb52
bb52:
  %t458 = load ptr, ptr %l0, !tbaa !29
  %t459 = load i32, ptr %l20, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t458, i32 %t459)
  br label %bb53
bb53:
  %t462 = load ptr, ptr %l0, !tbaa !29
  %t463 = load { i64, [4 x i64] }, ptr %l18
  %t464 = load i32, ptr %l22, !tbaa !23
  %t465 = load i32, ptr %l21, !tbaa !23
  store { i64, [8 x i64] } zeroinitializer, ptr %t466
  %t467 = getelementptr { i64, [8 x i64] }, ptr %t466, i32 0, i32 0
  store i64 2, ptr %t467
  %t469 = insertvalue { { i64, [4 x i64] }, i32, i32 } undef, { i64, [4 x i64] } %t463, 0
  %t471 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t469, i32 %t464, 1
  %t473 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t471, i32 %t465, 2
  %t474 = getelementptr { i64, [8 x i64] }, ptr %t466, i32 0, i32 1
  store { { i64, [4 x i64] }, i32, i32 } %t473, ptr %t474
  %t475 = load { i64, [8 x i64] }, ptr %t466
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t462, { i64, [8 x i64] } %t475)
  br label %bb54
bb54:
  %t478 = load ptr, ptr %l0, !tbaa !29
  %t479 = load i32, ptr %l21, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t478, i32 %t479)
  br label %bb55
bb55:
  %t482 = load ptr, ptr %l0, !tbaa !29
  store ptr %t482, ptr %l227, !tbaa !29
  %t483 = load ptr, ptr %l0, !tbaa !29
  %t484 = load i32, ptr %l12, !tbaa !23
  %t487 = call %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2eat(ptr %v0, ptr %s3, ptr %t483, i32 %t484)
  store %"compiler/lower:pl" %t487, ptr %l230
  br label %bb56
bb56:
  %t488 = load ptr, ptr %l0, !tbaa !29
  %t489 = load i32, ptr %l13, !tbaa !23
  %t492 = call %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2eat(ptr %v0, ptr %s3, ptr %t488, i32 %t489)
  store %"compiler/lower:pl" %t492, ptr %l233
  br label %bb57
bb57:
  %t493 = load ptr, ptr %l6, !tbaa !29
  %t494 = load i32, ptr %l7, !tbaa !23
  %t497 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t493, i32 %t494)
  store i32 %t497, ptr %l236
  br label %bb58
bb58:
  %t498 = load %"compiler/source:Span", ptr %l4
  %t499 = load ptr, ptr %l227, !tbaa !29
  %t500 = load %"compiler/lower:pl", ptr %l230
  %t501 = load %"compiler/lower:pl", ptr %l233
  %t502 = load i32, ptr %l236, !tbaa !23
  %t504 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eequalAt(ptr %v0, ptr %s3, ptr %s3, ptr %t499, %"compiler/lower:pl" %t500, %"compiler/lower:pl" %t501, i32 %t502, %"compiler/source:Span" %t498, i1 false)
  store { i64, [4 x i64] } %t504, ptr %l238
  br label %bb59
bb59:
  %t505 = load { i64, [4 x i64] }, ptr %l238
  store { i64, [4 x i64] } %t505, ptr %l23
  %t506 = load ptr, ptr %l0, !tbaa !29
  store ptr %t506, ptr %l239, !tbaa !29
  %t507 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t507, ptr %l240
  %t508 = load i32, ptr %l14, !tbaa !23
  %t510 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t508)
  store %"compiler/mir:Place" %t510, ptr %l242
  br label %bb60
bb60:
  %t511 = load { i64, [4 x i64] }, ptr %l23
  store { i64, [15 x i64] } zeroinitializer, ptr %t512
  %t513 = getelementptr { i64, [15 x i64] }, ptr %t512, i32 0, i32 0
  store i64 0, ptr %t513
  %t515 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t511, 0
  %t516 = getelementptr { i64, [15 x i64] }, ptr %t512, i32 0, i32 1
  store { { i64, [4 x i64] } } %t515, ptr %t516
  %t517 = load { i64, [15 x i64] }, ptr %t512
  store { i64, [21 x i64] } zeroinitializer, ptr %t518
  %t519 = getelementptr { i64, [21 x i64] }, ptr %t518, i32 0, i32 0
  store i64 0, ptr %t519
  %t520 = load %"compiler/source:Span", ptr %l240
  %t521 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t520, 0
  %t522 = load %"compiler/mir:Place", ptr %l242
  %t523 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t521, %"compiler/mir:Place" %t522, 1
  %t525 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t523, { i64, [15 x i64] } %t517, 2
  %t526 = getelementptr { i64, [21 x i64] }, ptr %t518, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t525, ptr %t526
  %t527 = load { i64, [21 x i64] }, ptr %t518
  %t529 = call ptr @__olang_scope_alloc_a(ptr %s3, i64 176, i64 8)
  store { i64, [21 x i64] } %t527, ptr %t529
  %t530 = load ptr, ptr %l239, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s3, ptr %t530, ptr %t529)
  br label %bb61
bb61:
  %t532 = load ptr, ptr %l0, !tbaa !29
  %t533 = load i32, ptr %l22, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2egoto(ptr %v0, ptr %t532, i32 %t533)
  br label %bb62
bb62:
  %t536 = load ptr, ptr %l0, !tbaa !29
  %t537 = load i32, ptr %l22, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t536, i32 %t537)
  br label %bb63
bb63:
  %t540 = load i32, ptr %l14, !tbaa !23
  %t542 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t540)
  store %"compiler/mir:Place" %t542, ptr %l252
  br label %bb64
bb64:
  store { i64, [4 x i64] } zeroinitializer, ptr %t543
  %t544 = getelementptr { i64, [4 x i64] }, ptr %t543, i32 0, i32 0
  store i64 1, ptr %t544
  %t545 = load %"compiler/mir:Place", ptr %l252
  %t546 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t545, 0
  %t547 = getelementptr { i64, [4 x i64] }, ptr %t543, i32 0, i32 1
  store { %"compiler/mir:Place" } %t546, ptr %t547
  %t548 = load { i64, [4 x i64] }, ptr %t543
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  store { i64, [4 x i64] } %t548, ptr %rv
  br label %ret
bb65:
  %t552 = xor i1 %a5, true
  br i1 %t552, label %bb66, label %bb67
bb66:
  store %olang.scope zeroinitializer, ptr %s4
  %t554 = load ptr, ptr %l0, !tbaa !29
  store ptr %t554, ptr %l256, !tbaa !29
  store i32 1, ptr %l257
  %t555 = load i32, ptr %l3, !tbaa !23
  store i32 %t555, ptr %l258, !tbaa !23
  %t556 = load ptr, ptr %l0, !tbaa !29
  %t557 = load %"compiler/lower:pl", ptr %l1
  %t558 = load i32, ptr %l3, !tbaa !23
  %t559 = load %"compiler/source:Span", ptr %l4
  %t564 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2erefTo(ptr %v0, ptr %v1, ptr %t556, %"compiler/lower:pl" %t557, i32 %t558, %"compiler/source:Span" %t559)
  store { i64, [4 x i64] } %t564, ptr %l263
  br label %bb68
bb67:
  br label %bb71
bb68:
  %t565 = load ptr, ptr %l0, !tbaa !29
  %t566 = load %"compiler/lower:pl", ptr %l2
  %t567 = load i32, ptr %l3, !tbaa !23
  %t568 = load %"compiler/source:Span", ptr %l4
  %t573 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2erefTo(ptr %v0, ptr %v2, ptr %t565, %"compiler/lower:pl" %t566, i32 %t567, %"compiler/source:Span" %t568)
  store { i64, [4 x i64] } %t573, ptr %l268
  br label %bb69
bb69:
  %t574 = mul i64 2, 40
  %t575 = call ptr @__olang_scope_alloc_zeroed(ptr %s4, i64 %t574)
  %t576 = insertvalue { i64, ptr } undef, i64 2, 0
  %t577 = insertvalue { i64, ptr } %t576, ptr %t575, 1
  store { i64, ptr } %t577, ptr %l269, !tbaa !27
  %t578 = load { i64, [4 x i64] }, ptr %l263
  %t579 = getelementptr { i64, ptr }, ptr %l269, i32 0, i32 1
  %t580 = load ptr, ptr %t579, !tbaa !27
  %t581 = getelementptr { i64, [4 x i64] }, ptr %t580, i64 0
  store { i64, [4 x i64] } %t578, ptr %t581
  %t582 = load { i64, [4 x i64] }, ptr %l268
  %t583 = getelementptr { i64, ptr }, ptr %l269, i32 0, i32 1
  %t584 = load ptr, ptr %t583, !tbaa !27
  %t585 = getelementptr { i64, [4 x i64] }, ptr %t584, i64 1
  store { i64, [4 x i64] } %t582, ptr %t585
  %t586 = mul i64 0, 16
  %t587 = call ptr @__olang_scope_alloc_zeroed(ptr %s4, i64 %t586)
  %t588 = insertvalue { i64, ptr } undef, i64 0, 0
  %t589 = insertvalue { i64, ptr } %t588, ptr %t587, 1
  %t590 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t591 = load %"compiler/source:Span", ptr %l4
  %t592 = load ptr, ptr %l256, !tbaa !29
  %t593 = load i32, ptr %l257
  %t594 = load i32, ptr %l258, !tbaa !23
  %t595 = load { i64, ptr }, ptr %l269, !tbaa !27
  %t599 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ehelperCall(ptr %v0, ptr %s4, ptr %s4, ptr %t592, i32 %t593, i32 %t594, { i64, ptr } %t595, { i64, ptr } %t589, i32 %t590, %"compiler/source:Span" %t591)
  store { i64, [4 x i64] } %t599, ptr %l273
  br label %bb70
bb70:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t600 = load { i64, [4 x i64] }, ptr %l273
  store { i64, [4 x i64] } %t600, ptr %rv
  br label %ret
bb71:
  %t601 = load ptr, ptr %l0, !tbaa !29
  %t602 = load %"compiler/source:Span", ptr %l4
  %t605 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2eflag(ptr %v0, ptr %t601, i1 true, %"compiler/source:Span" %t602)
  store i32 %t605, ptr %l276
  br label %bb72
bb72:
  %t606 = load i32, ptr %l276, !tbaa !23
  store i32 %t606, ptr %l24, !tbaa !23
  %t607 = load ptr, ptr %l0, !tbaa !29
  %t609 = getelementptr %"compiler/lower:lowering", ptr %t607, i32 0, i32 3
  %t611 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t609)
  store i32 %t611, ptr %l279
  br label %bb73
bb73:
  %t612 = load i32, ptr %l279, !tbaa !23
  store i32 %t612, ptr %l25, !tbaa !23
  %t613 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aBlockId_3e(ptr %s0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t613, ptr %l280
  br label %bb74
bb74:
  %t614 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l280
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t614, ptr %l26
  %t615 = load ptr, ptr %l0, !tbaa !29
  %t616 = load i32, ptr %l3, !tbaa !23
  %t619 = call { { i64, ptr }, i1 } @compiler_2flower_2ecompiler_2flower_3alowering_2epartsOf(ptr %v0, ptr %s0, ptr %t615, i32 %t616)
  store { { i64, ptr }, i1 } %t619, ptr %l283
  br label %bb75
bb75:
  %t620 = load { { i64, ptr }, i1 }, ptr %l283
  store { { i64, ptr }, i1 } %t620, ptr %l27
  %t621 = getelementptr { { i64, ptr }, i1 }, ptr %l27, i32 0, i32 0
  %t622 = load { i64, ptr }, ptr %t621, !tbaa !27
  store { i64, ptr } %t622, ptr %l284, !tbaa !27
  %t623 = load { i64, ptr }, ptr %l284, !tbaa !27
  %t624 = extractvalue { i64, ptr } %t623, 0
  store i64 %t624, ptr %l285, !tbaa !24
  %t625 = load i64, ptr %l285, !tbaa !24
  %t626 = mul i64 %t625, 4
  %t627 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t626)
  %t628 = insertvalue { i64, ptr } undef, i64 %t625, 0
  %t629 = insertvalue { i64, ptr } %t628, ptr %t627, 1
  store { i64, ptr } %t629, ptr %l286, !tbaa !27
  %t630 = getelementptr { i64, ptr }, ptr %l286, i32 0, i32 1
  %t631 = load ptr, ptr %t630, !tbaa !27
  %t632 = getelementptr { i64, ptr }, ptr %l284, i32 0, i32 1
  %t633 = load ptr, ptr %t632, !tbaa !27
  %t634 = load i64, ptr %l285, !tbaa !24
  %t635 = mul i64 %t634, 4
  call void @llvm.memmove.p0.p0.i64(ptr %t631, ptr %t633, i64 %t635, i1 false)
  %t636 = load { i64, ptr }, ptr %l286, !tbaa !27
  store { i64, ptr } %t636, ptr %l28, !tbaa !27
  %t637 = getelementptr { { i64, ptr }, i1 }, ptr %l27, i32 0, i32 1
  %t638 = load i1, ptr %t637, !tbaa !21
  store i1 %t638, ptr %l29, !tbaa !21
  %t640 = load ptr, ptr %l0, !tbaa !29
  %t641 = load i32, ptr %l3, !tbaa !23
  %t644 = call { { i64, ptr }, i1 } @compiler_2flower_2ecompiler_2flower_3alowering_2ecasesOf(ptr %v0, ptr %s0, ptr %t640, i32 %t641)
  store { { i64, ptr }, i1 } %t644, ptr %l290
  br label %bb76
bb76:
  %t645 = load { { i64, ptr }, i1 }, ptr %l290
  store { { i64, ptr }, i1 } %t645, ptr %l30
  %t646 = getelementptr { { i64, ptr }, i1 }, ptr %l30, i32 0, i32 0
  %t647 = load { i64, ptr }, ptr %t646, !tbaa !27
  store { i64, ptr } %t647, ptr %l291, !tbaa !27
  %t648 = load { i64, ptr }, ptr %l291, !tbaa !27
  %t649 = extractvalue { i64, ptr } %t648, 0
  store i64 %t649, ptr %l292, !tbaa !24
  %t650 = load i64, ptr %l292, !tbaa !24
  %t651 = mul i64 %t650, 4
  %t652 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t651)
  %t653 = insertvalue { i64, ptr } undef, i64 %t650, 0
  %t654 = insertvalue { i64, ptr } %t653, ptr %t652, 1
  store { i64, ptr } %t654, ptr %l293, !tbaa !27
  %t655 = getelementptr { i64, ptr }, ptr %l293, i32 0, i32 1
  %t656 = load ptr, ptr %t655, !tbaa !27
  %t657 = getelementptr { i64, ptr }, ptr %l291, i32 0, i32 1
  %t658 = load ptr, ptr %t657, !tbaa !27
  %t659 = load i64, ptr %l292, !tbaa !24
  %t660 = mul i64 %t659, 4
  call void @llvm.memmove.p0.p0.i64(ptr %t656, ptr %t658, i64 %t660, i1 false)
  %t661 = load { i64, ptr }, ptr %l293, !tbaa !27
  store { i64, ptr } %t661, ptr %l31, !tbaa !27
  %t662 = getelementptr { { i64, ptr }, i1 }, ptr %l30, i32 0, i32 1
  %t663 = load i1, ptr %t662, !tbaa !21
  store i1 %t663, ptr %l32, !tbaa !21
  %t665 = load i1, ptr %l29, !tbaa !21
  br i1 %t665, label %bb77, label %bb78
bb77:
  store i64 0, ptr %l33, !tbaa !24
  %t667 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t669 = extractvalue { i64, ptr } %t667, 0
  store i64 %t669, ptr %l34, !tbaa !24
  store i64 1, ptr %l35, !tbaa !24
  %t671 = load i64, ptr %l34, !tbaa !24
  %t672 = load i64, ptr %l33, !tbaa !24
  %t675 = icmp sgt i64 %t671, %t672
  br i1 %t675, label %bb79, label %bb80
bb78:
  %t677 = load i1, ptr %l32, !tbaa !21
  br i1 %t677, label %bb97, label %bb98
bb79:
  %t679 = load i64, ptr %l35, !tbaa !24
  %t681 = icmp sgt i64 %t679, 0
  br i1 %t681, label %bb81, label %bb82
bb80:
  store i64 0, ptr %l301, !tbaa !24
  br label %bb84
bb81:
  %t683 = load i64, ptr %l34, !tbaa !24
  %t684 = load i64, ptr %l33, !tbaa !24
  %t687 = sub i64 %t683, %t684
  %t688 = load i64, ptr %l35, !tbaa !24
  %t691 = add i64 %t687, %t688
  %t693 = sub i64 %t691, 1
  %t694 = load i64, ptr %l35, !tbaa !24
  %t697 = sdiv i64 %t693, %t694
  store i64 %t697, ptr %l304, !tbaa !24
  br label %bb83
bb82:
  store i64 0, ptr %l304, !tbaa !24
  br label %bb83
bb83:
  %t699 = load i64, ptr %l304, !tbaa !24
  store i64 %t699, ptr %l301, !tbaa !24
  br label %bb84
bb84:
  %t700 = load i64, ptr %l301, !tbaa !24
  store i64 %t700, ptr %l36, !tbaa !24
  store i64 0, ptr %l37, !tbaa !24
  br label %bb85
bb85:
  store %olang.scope zeroinitializer, ptr %s7
  %t701 = load i64, ptr %l37, !tbaa !24
  %t702 = load i64, ptr %l36, !tbaa !24
  %t705 = icmp slt i64 %t701, %t702
  %t707 = xor i1 %t705, true
  br i1 %t707, label %bb86, label %bb87
bb86:
  call void @__olang_scope_close(ptr %s7)
  br label %bb96
bb87:
  br label %bb88
bb88:
  %t709 = load i64, ptr %l33, !tbaa !24
  %t710 = load i64, ptr %l37, !tbaa !24
  %t711 = load i64, ptr %l35, !tbaa !24
  %t714 = mul i64 %t710, %t711
  %t717 = add i64 %t709, %t714
  store i64 %t717, ptr %l38, !tbaa !24
  %t719 = load ptr, ptr %l0, !tbaa !29
  store ptr %t719, ptr %l322, !tbaa !29
  %t720 = load ptr, ptr %l0, !tbaa !29
  %t721 = load %"compiler/lower:pl", ptr %l1
  %t722 = load i64, ptr %l38, !tbaa !24
  store { i64, [1 x i64] } zeroinitializer, ptr %t723
  %t724 = getelementptr { i64, [1 x i64] }, ptr %t723, i32 0, i32 0
  store i64 0, ptr %t724
  %t726 = insertvalue { i64 } undef, i64 %t722, 0
  %t727 = getelementptr { i64, [1 x i64] }, ptr %t723, i32 0, i32 1
  store { i64 } %t726, ptr %t727
  %t728 = load { i64, [1 x i64] }, ptr %t723
  %t732 = call %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2ewith(ptr %v0, ptr %v1, ptr %s7, ptr %t720, %"compiler/lower:pl" %t721, { i64, [1 x i64] } %t728)
  store %"compiler/lower:pl" %t732, ptr %l327
  br label %bb89
bb89:
  %t733 = load ptr, ptr %l0, !tbaa !29
  %t734 = load %"compiler/lower:pl", ptr %l2
  %t735 = load i64, ptr %l38, !tbaa !24
  store { i64, [1 x i64] } zeroinitializer, ptr %t736
  %t737 = getelementptr { i64, [1 x i64] }, ptr %t736, i32 0, i32 0
  store i64 0, ptr %t737
  %t739 = insertvalue { i64 } undef, i64 %t735, 0
  %t740 = getelementptr { i64, [1 x i64] }, ptr %t736, i32 0, i32 1
  store { i64 } %t739, ptr %t740
  %t741 = load { i64, [1 x i64] }, ptr %t736
  %t745 = call %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2ewith(ptr %v0, ptr %v2, ptr %s7, ptr %t733, %"compiler/lower:pl" %t734, { i64, [1 x i64] } %t741)
  store %"compiler/lower:pl" %t745, ptr %l332
  br label %bb90
bb90:
  %t746 = load i64, ptr %l38, !tbaa !24
  %t748 = getelementptr { i64, ptr }, ptr %l28, i32 0, i32 1
  %t749 = load ptr, ptr %t748, !tbaa !27
  %t750 = getelementptr i32, ptr %t749, i64 %t746
  %t751 = load i32, ptr %t750, !tbaa !33
  %t752 = load %"compiler/source:Span", ptr %l4
  %t753 = load ptr, ptr %l322, !tbaa !29
  %t754 = load %"compiler/lower:pl", ptr %l327
  %t755 = load %"compiler/lower:pl", ptr %l332
  %t758 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eequalAt(ptr %v0, ptr %s7, ptr %s7, ptr %t753, %"compiler/lower:pl" %t754, %"compiler/lower:pl" %t755, i32 %t751, %"compiler/source:Span" %t752, i1 false)
  store { i64, [4 x i64] } %t758, ptr %l336
  br label %bb91
bb91:
  %t759 = load { i64, [4 x i64] }, ptr %l336
  store { i64, [4 x i64] } %t759, ptr %l39
  %t760 = load ptr, ptr %l0, !tbaa !29
  %t762 = getelementptr %"compiler/lower:lowering", ptr %t760, i32 0, i32 3
  %t764 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t762)
  store i32 %t764, ptr %l339
  br label %bb92
bb92:
  %t765 = load i32, ptr %l339, !tbaa !23
  store i32 %t765, ptr %l40, !tbaa !23
  %t766 = load ptr, ptr %l0, !tbaa !29
  %t767 = load { i64, [4 x i64] }, ptr %l39
  %t768 = load i32, ptr %l40, !tbaa !23
  %t769 = load i32, ptr %l25, !tbaa !23
  store { i64, [8 x i64] } zeroinitializer, ptr %t770
  %t771 = getelementptr { i64, [8 x i64] }, ptr %t770, i32 0, i32 0
  store i64 2, ptr %t771
  %t773 = insertvalue { { i64, [4 x i64] }, i32, i32 } undef, { i64, [4 x i64] } %t767, 0
  %t775 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t773, i32 %t768, 1
  %t777 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t775, i32 %t769, 2
  %t778 = getelementptr { i64, [8 x i64] }, ptr %t770, i32 0, i32 1
  store { { i64, [4 x i64] }, i32, i32 } %t777, ptr %t778
  %t779 = load { i64, [8 x i64] }, ptr %t770
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t766, { i64, [8 x i64] } %t779)
  br label %bb93
bb93:
  %t782 = load ptr, ptr %l0, !tbaa !29
  %t783 = load i32, ptr %l40, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t782, i32 %t783)
  br label %bb94
bb94:
  call void @__olang_scope_close(ptr %s7)
  br label %bb95
bb95:
  %t786 = load i64, ptr %l37, !tbaa !24
  %t788 = add i64 %t786, 1
  store i64 %t788, ptr %l37, !tbaa !24
  br label %bb85
bb96:
  br label %bb125
bb97:
  store %olang.scope zeroinitializer, ptr %s10
  %t790 = load ptr, ptr %l0, !tbaa !29
  store ptr %t790, ptr %l350, !tbaa !29
  %t791 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  store i32 %t791, ptr %l351, !tbaa !23
  %t792 = load ptr, ptr %l0, !tbaa !29
  %t793 = load %"compiler/lower:pl", ptr %l1
  %t796 = call %"compiler/mir:Place" @compiler_2flower_2ecompiler_2flower_3alowering_2emk(ptr %v0, ptr %v1, ptr %t792, %"compiler/lower:pl" %t793)
  store %"compiler/mir:Place" %t796, ptr %l354
  br label %bb99
bb98:
  %t797 = load ptr, ptr %l0, !tbaa !29
  %t798 = load i32, ptr %l3, !tbaa !23
  %t801 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2earrayOf(ptr %v0, ptr %t797, i32 %t798)
  store i32 %t801, ptr %l396
  br label %bb108
bb99:
  store { i64, [15 x i64] } zeroinitializer, ptr %t802
  %t803 = getelementptr { i64, [15 x i64] }, ptr %t802, i32 0, i32 0
  store i64 5, ptr %t803
  %t804 = load %"compiler/mir:Place", ptr %l354
  %t805 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t804, 0
  %t806 = getelementptr { i64, [15 x i64] }, ptr %t802, i32 0, i32 1
  store { %"compiler/mir:Place" } %t805, ptr %t806
  %t807 = load { i64, [15 x i64] }, ptr %t802
  %t808 = load %"compiler/source:Span", ptr %l4
  %t809 = load ptr, ptr %l350, !tbaa !29
  %t810 = load i32, ptr %l351, !tbaa !23
  %t813 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %t809, i32 %t810, { i64, [15 x i64] } %t807, %"compiler/source:Span" %t808)
  store { i64, [4 x i64] } %t813, ptr %l357
  br label %bb100
bb100:
  %t814 = load { i64, [4 x i64] }, ptr %l357
  store { i64, [4 x i64] } %t814, ptr %l41
  %t815 = load ptr, ptr %l0, !tbaa !29
  store ptr %t815, ptr %l358, !tbaa !29
  %t816 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  store i32 %t816, ptr %l359, !tbaa !23
  %t817 = load ptr, ptr %l0, !tbaa !29
  %t818 = load %"compiler/lower:pl", ptr %l2
  %t821 = call %"compiler/mir:Place" @compiler_2flower_2ecompiler_2flower_3alowering_2emk(ptr %v0, ptr %v2, ptr %t817, %"compiler/lower:pl" %t818)
  store %"compiler/mir:Place" %t821, ptr %l362
  br label %bb101
bb101:
  store { i64, [15 x i64] } zeroinitializer, ptr %t822
  %t823 = getelementptr { i64, [15 x i64] }, ptr %t822, i32 0, i32 0
  store i64 5, ptr %t823
  %t824 = load %"compiler/mir:Place", ptr %l362
  %t825 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t824, 0
  %t826 = getelementptr { i64, [15 x i64] }, ptr %t822, i32 0, i32 1
  store { %"compiler/mir:Place" } %t825, ptr %t826
  %t827 = load { i64, [15 x i64] }, ptr %t822
  %t828 = load %"compiler/source:Span", ptr %l4
  %t829 = load ptr, ptr %l358, !tbaa !29
  %t830 = load i32, ptr %l359, !tbaa !23
  %t833 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %t829, i32 %t830, { i64, [15 x i64] } %t827, %"compiler/source:Span" %t828)
  store { i64, [4 x i64] } %t833, ptr %l365
  br label %bb102
bb102:
  %t834 = load { i64, [4 x i64] }, ptr %l365
  %t835 = load ptr, ptr %l0, !tbaa !29
  %t836 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t837 = load { i64, [4 x i64] }, ptr %l41
  %t839 = mul i64 2, 40
  %t840 = call ptr @__olang_scope_alloc_zeroed(ptr %s10, i64 %t839)
  %t841 = insertvalue { i64, ptr } undef, i64 2, 0
  %t842 = insertvalue { i64, ptr } %t841, ptr %t840, 1
  store { i64, ptr } %t842, ptr %l371, !tbaa !27
  %t844 = getelementptr { i64, ptr }, ptr %l371, i32 0, i32 1
  %t845 = load ptr, ptr %t844, !tbaa !27
  %t846 = getelementptr { i64, [4 x i64] }, ptr %t845, i64 0
  store { i64, [4 x i64] } %t837, ptr %t846
  %t848 = getelementptr { i64, ptr }, ptr %l371, i32 0, i32 1
  %t849 = load ptr, ptr %t848, !tbaa !27
  %t850 = getelementptr { i64, [4 x i64] }, ptr %t849, i64 1
  store { i64, [4 x i64] } %t834, ptr %t850
  %t851 = load %"compiler/source:Span", ptr %l4
  %t855 = load { i64, ptr }, ptr %l371, !tbaa !27
  %t857 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s10, ptr %t835, i32 13, i32 %t836, { i64, ptr } %t855, %"compiler/source:Span" %t851)
  store { i64, [4 x i64] } %t857, ptr %l373
  br label %bb103
bb103:
  %t858 = load { i64, [4 x i64] }, ptr %l373
  store { i64, [4 x i64] } %t858, ptr %l43
  %t859 = load ptr, ptr %l0, !tbaa !29
  %t861 = getelementptr %"compiler/lower:lowering", ptr %t859, i32 0, i32 3
  %t863 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t861)
  store i32 %t863, ptr %l376
  br label %bb104
bb104:
  %t864 = load i32, ptr %l376, !tbaa !23
  store i32 %t864, ptr %l44, !tbaa !23
  %t865 = load ptr, ptr %l0, !tbaa !29
  %t866 = load { i64, [4 x i64] }, ptr %l43
  %t867 = load i32, ptr %l44, !tbaa !23
  %t868 = load i32, ptr %l25, !tbaa !23
  store { i64, [8 x i64] } zeroinitializer, ptr %t869
  %t870 = getelementptr { i64, [8 x i64] }, ptr %t869, i32 0, i32 0
  store i64 2, ptr %t870
  %t872 = insertvalue { { i64, [4 x i64] }, i32, i32 } undef, { i64, [4 x i64] } %t866, 0
  %t874 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t872, i32 %t867, 1
  %t876 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t874, i32 %t868, 2
  %t877 = getelementptr { i64, [8 x i64] }, ptr %t869, i32 0, i32 1
  store { { i64, [4 x i64] }, i32, i32 } %t876, ptr %t877
  %t878 = load { i64, [8 x i64] }, ptr %t869
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t865, { i64, [8 x i64] } %t878)
  br label %bb105
bb105:
  %t881 = load ptr, ptr %l0, !tbaa !29
  %t882 = load i32, ptr %l44, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t881, i32 %t882)
  br label %bb106
bb106:
  %t885 = load ptr, ptr %l0, !tbaa !29
  %t886 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t887 = load { i64, [4 x i64] }, ptr %l41
  %t888 = load %"compiler/source:Span", ptr %l4
  %t889 = load ptr, ptr %l0, !tbaa !29
  %t890 = load %"compiler/lower:pl", ptr %l1
  %t891 = load %"compiler/lower:pl", ptr %l2
  %t892 = load %"compiler/source:Span", ptr %l4
  %t893 = load i32, ptr %l25, !tbaa !23
  %t894 = getelementptr { ptr, %"compiler/lower:pl", %"compiler/lower:pl", %"compiler/source:Span", i32, ptr, ptr, ptr }, ptr null, i32 1
  %t895 = ptrtoint ptr %t894 to i64
  %t897 = getelementptr { ptr, %"compiler/lower:pl", %"compiler/lower:pl", %"compiler/source:Span", i32, ptr, ptr, ptr }, ptr %t896, i32 0, i32 0
  store ptr %t889, ptr %t897, !tbaa !28
  %t899 = getelementptr { ptr, %"compiler/lower:pl", %"compiler/lower:pl", %"compiler/source:Span", i32, ptr, ptr, ptr }, ptr %t896, i32 0, i32 1
  store %"compiler/lower:pl" %t890, ptr %t899, !tbaa !28
  %t901 = getelementptr { ptr, %"compiler/lower:pl", %"compiler/lower:pl", %"compiler/source:Span", i32, ptr, ptr, ptr }, ptr %t896, i32 0, i32 2
  store %"compiler/lower:pl" %t891, ptr %t901, !tbaa !28
  %t903 = getelementptr { ptr, %"compiler/lower:pl", %"compiler/lower:pl", %"compiler/source:Span", i32, ptr, ptr, ptr }, ptr %t896, i32 0, i32 3
  store %"compiler/source:Span" %t892, ptr %t903, !tbaa !28
  %t905 = getelementptr { ptr, %"compiler/lower:pl", %"compiler/lower:pl", %"compiler/source:Span", i32, ptr, ptr, ptr }, ptr %t896, i32 0, i32 4
  store i32 %t893, ptr %t905, !tbaa !28
  call void @__olang_scope_escape(ptr %v0)
  %t907 = getelementptr { ptr, %"compiler/lower:pl", %"compiler/lower:pl", %"compiler/source:Span", i32, ptr, ptr, ptr }, ptr %t896, i32 0, i32 5
  store ptr %v0, ptr %t907, !tbaa !28
  call void @__olang_scope_escape(ptr %v1)
  %t908 = getelementptr { ptr, %"compiler/lower:pl", %"compiler/lower:pl", %"compiler/source:Span", i32, ptr, ptr, ptr }, ptr %t896, i32 0, i32 6
  store ptr %v1, ptr %t908, !tbaa !28
  call void @__olang_scope_escape(ptr %v2)
  %t909 = getelementptr { ptr, %"compiler/lower:pl", %"compiler/lower:pl", %"compiler/source:Span", i32, ptr, ptr, ptr }, ptr %t896, i32 0, i32 7
  store ptr %v2, ptr %t909, !tbaa !28
  %t910 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_6, 0
  %t911 = insertvalue { ptr, ptr } %t910, ptr %t896, 1
  %t917 = extractvalue { ptr, ptr } %t911, 0
  %t918 = extractvalue { ptr, ptr } %t911, 1
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2epayloads(ptr %v0, ptr %s0, ptr %s10, ptr %t885, { i64, ptr } %t886, { i64, [4 x i64] } %t887, %"compiler/source:Span" %t888, ptr %t917, ptr %t918)
  br label %bb107
bb107:
  call void @__olang_scope_close(ptr %s10)
  br label %bb124
bb108:
  %t919 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t920 = load i32, ptr %l396, !tbaa !23
  %t922 = icmp ne i32 %t920, %t919
  br i1 %t922, label %bb109, label %bb110
bb109:
  store %olang.scope zeroinitializer, ptr %s12
  %t924 = load ptr, ptr %l6, !tbaa !29
  store ptr %t924, ptr %l399, !tbaa !29
  %t925 = load ptr, ptr %l0, !tbaa !29
  %t926 = load i32, ptr %l3, !tbaa !23
  %t929 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2earrayOf(ptr %v0, ptr %t925, i32 %t926)
  store i32 %t929, ptr %l402
  br label %bb111
bb110:
  store %olang.scope zeroinitializer, ptr %s13
  %t930 = load ptr, ptr %l0, !tbaa !29
  %t931 = load %"compiler/source:Span", ptr %l4
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2egap(ptr %v0, ptr %s13, ptr %t930, %"compiler/source:Span" %t931, { i64, ptr } { i64 40, ptr getelementptr inbounds (<{ i64, [40 x i8] }>, ptr @.d7, i32 0, i32 1) })
  br label %bb122
bb111:
  %t934 = load ptr, ptr %l399, !tbaa !29
  %t935 = load i32, ptr %l402, !tbaa !23
  %t936 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t934, i32 %t935)
  store i32 %t936, ptr %l403
  br label %bb112
bb112:
  %t937 = load i32, ptr %l403, !tbaa !23
  store i32 %t937, ptr %l45, !tbaa !23
  %t938 = load ptr, ptr %l0, !tbaa !29
  store ptr %t938, ptr %l404, !tbaa !29
  store i32 22, ptr %l405
  %t939 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  store i32 %t939, ptr %l406, !tbaa !23
  %t940 = load ptr, ptr %l0, !tbaa !29
  %t941 = load %"compiler/lower:pl", ptr %l1
  %t944 = call %"compiler/mir:Place" @compiler_2flower_2ecompiler_2flower_3alowering_2emk(ptr %v0, ptr %v1, ptr %t940, %"compiler/lower:pl" %t941)
  store %"compiler/mir:Place" %t944, ptr %l409
  br label %bb113
bb113:
  store { i64, [4 x i64] } zeroinitializer, ptr %t945
  %t946 = getelementptr { i64, [4 x i64] }, ptr %t945, i32 0, i32 0
  store i64 1, ptr %t946
  %t947 = load %"compiler/mir:Place", ptr %l409
  %t948 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t947, 0
  %t949 = getelementptr { i64, [4 x i64] }, ptr %t945, i32 0, i32 1
  store { %"compiler/mir:Place" } %t948, ptr %t949
  %t950 = load { i64, [4 x i64] }, ptr %t945
  %t951 = mul i64 1, 40
  %t952 = call ptr @__olang_scope_alloc_zeroed(ptr %s12, i64 %t951)
  %t953 = insertvalue { i64, ptr } undef, i64 1, 0
  %t954 = insertvalue { i64, ptr } %t953, ptr %t952, 1
  store { i64, ptr } %t954, ptr %l411, !tbaa !27
  %t956 = getelementptr { i64, ptr }, ptr %l411, i32 0, i32 1
  %t957 = load ptr, ptr %t956, !tbaa !27
  %t958 = getelementptr { i64, [4 x i64] }, ptr %t957, i64 0
  store { i64, [4 x i64] } %t950, ptr %t958
  %t959 = load %"compiler/source:Span", ptr %l4
  %t960 = load ptr, ptr %l404, !tbaa !29
  %t961 = load i32, ptr %l405
  %t962 = load i32, ptr %l406, !tbaa !23
  %t963 = load { i64, ptr }, ptr %l411, !tbaa !27
  %t965 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s12, ptr %t960, i32 %t961, i32 %t962, { i64, ptr } %t963, %"compiler/source:Span" %t959)
  store { i64, [4 x i64] } %t965, ptr %l413
  br label %bb114
bb114:
  %t966 = load { i64, [4 x i64] }, ptr %l413
  store { i64, [4 x i64] } %t966, ptr %l46
  %t967 = load ptr, ptr %l0, !tbaa !29
  store ptr %t967, ptr %l414, !tbaa !29
  store i32 22, ptr %l415
  %t968 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  store i32 %t968, ptr %l416, !tbaa !23
  %t969 = load ptr, ptr %l0, !tbaa !29
  %t970 = load %"compiler/lower:pl", ptr %l2
  %t973 = call %"compiler/mir:Place" @compiler_2flower_2ecompiler_2flower_3alowering_2emk(ptr %v0, ptr %v2, ptr %t969, %"compiler/lower:pl" %t970)
  store %"compiler/mir:Place" %t973, ptr %l419
  br label %bb115
bb115:
  store { i64, [4 x i64] } zeroinitializer, ptr %t974
  %t975 = getelementptr { i64, [4 x i64] }, ptr %t974, i32 0, i32 0
  store i64 1, ptr %t975
  %t976 = load %"compiler/mir:Place", ptr %l419
  %t977 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t976, 0
  %t978 = getelementptr { i64, [4 x i64] }, ptr %t974, i32 0, i32 1
  store { %"compiler/mir:Place" } %t977, ptr %t978
  %t979 = load { i64, [4 x i64] }, ptr %t974
  %t980 = mul i64 1, 40
  %t981 = call ptr @__olang_scope_alloc_zeroed(ptr %s12, i64 %t980)
  %t982 = insertvalue { i64, ptr } undef, i64 1, 0
  %t983 = insertvalue { i64, ptr } %t982, ptr %t981, 1
  store { i64, ptr } %t983, ptr %l421, !tbaa !27
  %t985 = getelementptr { i64, ptr }, ptr %l421, i32 0, i32 1
  %t986 = load ptr, ptr %t985, !tbaa !27
  %t987 = getelementptr { i64, [4 x i64] }, ptr %t986, i64 0
  store { i64, [4 x i64] } %t979, ptr %t987
  %t988 = load %"compiler/source:Span", ptr %l4
  %t989 = load ptr, ptr %l414, !tbaa !29
  %t990 = load i32, ptr %l415
  %t991 = load i32, ptr %l416, !tbaa !23
  %t992 = load { i64, ptr }, ptr %l421, !tbaa !27
  %t994 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s12, ptr %t989, i32 %t990, i32 %t991, { i64, ptr } %t992, %"compiler/source:Span" %t988)
  store { i64, [4 x i64] } %t994, ptr %l423
  br label %bb116
bb116:
  %t995 = load { i64, [4 x i64] }, ptr %l423
  %t996 = load ptr, ptr %l0, !tbaa !29
  %t997 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t998 = load { i64, [4 x i64] }, ptr %l46
  %t1000 = mul i64 2, 40
  %t1001 = call ptr @__olang_scope_alloc_zeroed(ptr %s12, i64 %t1000)
  %t1002 = insertvalue { i64, ptr } undef, i64 2, 0
  %t1003 = insertvalue { i64, ptr } %t1002, ptr %t1001, 1
  store { i64, ptr } %t1003, ptr %l429, !tbaa !27
  %t1005 = getelementptr { i64, ptr }, ptr %l429, i32 0, i32 1
  %t1006 = load ptr, ptr %t1005, !tbaa !27
  %t1007 = getelementptr { i64, [4 x i64] }, ptr %t1006, i64 0
  store { i64, [4 x i64] } %t998, ptr %t1007
  %t1009 = getelementptr { i64, ptr }, ptr %l429, i32 0, i32 1
  %t1010 = load ptr, ptr %t1009, !tbaa !27
  %t1011 = getelementptr { i64, [4 x i64] }, ptr %t1010, i64 1
  store { i64, [4 x i64] } %t995, ptr %t1011
  %t1012 = load %"compiler/source:Span", ptr %l4
  %t1016 = load { i64, ptr }, ptr %l429, !tbaa !27
  %t1018 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s12, ptr %t996, i32 13, i32 %t997, { i64, ptr } %t1016, %"compiler/source:Span" %t1012)
  store { i64, [4 x i64] } %t1018, ptr %l431
  br label %bb117
bb117:
  %t1019 = load { i64, [4 x i64] }, ptr %l431
  store { i64, [4 x i64] } %t1019, ptr %l48
  %t1020 = load ptr, ptr %l0, !tbaa !29
  %t1022 = getelementptr %"compiler/lower:lowering", ptr %t1020, i32 0, i32 3
  %t1024 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t1022)
  store i32 %t1024, ptr %l434
  br label %bb118
bb118:
  %t1025 = load i32, ptr %l434, !tbaa !23
  store i32 %t1025, ptr %l49, !tbaa !23
  %t1026 = load ptr, ptr %l0, !tbaa !29
  %t1027 = load { i64, [4 x i64] }, ptr %l48
  %t1028 = load i32, ptr %l49, !tbaa !23
  %t1029 = load i32, ptr %l25, !tbaa !23
  store { i64, [8 x i64] } zeroinitializer, ptr %t1030
  %t1031 = getelementptr { i64, [8 x i64] }, ptr %t1030, i32 0, i32 0
  store i64 2, ptr %t1031
  %t1033 = insertvalue { { i64, [4 x i64] }, i32, i32 } undef, { i64, [4 x i64] } %t1027, 0
  %t1035 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t1033, i32 %t1028, 1
  %t1037 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t1035, i32 %t1029, 2
  %t1038 = getelementptr { i64, [8 x i64] }, ptr %t1030, i32 0, i32 1
  store { { i64, [4 x i64] }, i32, i32 } %t1037, ptr %t1038
  %t1039 = load { i64, [8 x i64] }, ptr %t1030
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t1026, { i64, [8 x i64] } %t1039)
  br label %bb119
bb119:
  %t1042 = load ptr, ptr %l0, !tbaa !29
  %t1043 = load i32, ptr %l49, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t1042, i32 %t1043)
  br label %bb120
bb120:
  %t1046 = load ptr, ptr %l0, !tbaa !29
  %t1047 = load { i64, [4 x i64] }, ptr %l46
  %t1048 = load %"compiler/source:Span", ptr %l4
  %t1049 = load ptr, ptr %l0, !tbaa !29
  %t1050 = load %"compiler/lower:pl", ptr %l1
  %t1051 = load %"compiler/lower:pl", ptr %l2
  %t1052 = load i32, ptr %l45, !tbaa !23
  %t1053 = load %"compiler/source:Span", ptr %l4
  %t1054 = load i32, ptr %l25, !tbaa !23
  %t1055 = getelementptr { ptr, %"compiler/lower:pl", %"compiler/lower:pl", i32, %"compiler/source:Span", i32, ptr, ptr, ptr }, ptr null, i32 1
  %t1056 = ptrtoint ptr %t1055 to i64
  %t1058 = getelementptr { ptr, %"compiler/lower:pl", %"compiler/lower:pl", i32, %"compiler/source:Span", i32, ptr, ptr, ptr }, ptr %t1057, i32 0, i32 0
  store ptr %t1049, ptr %t1058, !tbaa !28
  %t1060 = getelementptr { ptr, %"compiler/lower:pl", %"compiler/lower:pl", i32, %"compiler/source:Span", i32, ptr, ptr, ptr }, ptr %t1057, i32 0, i32 1
  store %"compiler/lower:pl" %t1050, ptr %t1060, !tbaa !28
  %t1062 = getelementptr { ptr, %"compiler/lower:pl", %"compiler/lower:pl", i32, %"compiler/source:Span", i32, ptr, ptr, ptr }, ptr %t1057, i32 0, i32 2
  store %"compiler/lower:pl" %t1051, ptr %t1062, !tbaa !28
  %t1064 = getelementptr { ptr, %"compiler/lower:pl", %"compiler/lower:pl", i32, %"compiler/source:Span", i32, ptr, ptr, ptr }, ptr %t1057, i32 0, i32 3
  store i32 %t1052, ptr %t1064, !tbaa !28
  %t1066 = getelementptr { ptr, %"compiler/lower:pl", %"compiler/lower:pl", i32, %"compiler/source:Span", i32, ptr, ptr, ptr }, ptr %t1057, i32 0, i32 4
  store %"compiler/source:Span" %t1053, ptr %t1066, !tbaa !28
  %t1068 = getelementptr { ptr, %"compiler/lower:pl", %"compiler/lower:pl", i32, %"compiler/source:Span", i32, ptr, ptr, ptr }, ptr %t1057, i32 0, i32 5
  store i32 %t1054, ptr %t1068, !tbaa !28
  call void @__olang_scope_escape(ptr %v0)
  %t1070 = getelementptr { ptr, %"compiler/lower:pl", %"compiler/lower:pl", i32, %"compiler/source:Span", i32, ptr, ptr, ptr }, ptr %t1057, i32 0, i32 6
  store ptr %v0, ptr %t1070, !tbaa !28
  call void @__olang_scope_escape(ptr %v1)
  %t1071 = getelementptr { ptr, %"compiler/lower:pl", %"compiler/lower:pl", i32, %"compiler/source:Span", i32, ptr, ptr, ptr }, ptr %t1057, i32 0, i32 7
  store ptr %v1, ptr %t1071, !tbaa !28
  call void @__olang_scope_escape(ptr %v2)
  %t1072 = getelementptr { ptr, %"compiler/lower:pl", %"compiler/lower:pl", i32, %"compiler/source:Span", i32, ptr, ptr, ptr }, ptr %t1057, i32 0, i32 8
  store ptr %v2, ptr %t1072, !tbaa !28
  %t1073 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_8, 0
  %t1074 = insertvalue { ptr, ptr } %t1073, ptr %t1057, 1
  %t1079 = extractvalue { ptr, ptr } %t1074, 0
  %t1080 = extractvalue { ptr, ptr } %t1074, 1
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eeachIndex(ptr %v0, ptr %s12, ptr %t1046, { i64, [4 x i64] } %t1047, %"compiler/source:Span" %t1048, ptr %t1079, ptr %t1080)
  br label %bb121
bb121:
  call void @__olang_scope_close(ptr %s12)
  br label %bb123
bb122:
  call void @__olang_scope_close(ptr %s13)
  br label %bb123
bb123:
  br label %bb124
bb124:
  br label %bb125
bb125:
  %t1081 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eleaveOpen(ptr %v0, ptr %s0, ptr %t1081, ptr %l26)
  br label %bb126
bb126:
  %t1084 = load ptr, ptr %l0, !tbaa !29
  %t1085 = load i32, ptr %l25, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t1084, i32 %t1085)
  br label %bb127
bb127:
  %t1088 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1088, ptr %l458, !tbaa !29
  %t1089 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t1089, ptr %l459
  %t1090 = load i32, ptr %l24, !tbaa !23
  %t1092 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t1090)
  store %"compiler/mir:Place" %t1092, ptr %l461
  br label %bb128
bb128:
  %t1093 = load ptr, ptr %l0, !tbaa !29
  %t1094 = load %"compiler/source:Span", ptr %l4
  %t1097 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2econstBool(ptr %v0, ptr %t1093, i1 false, %"compiler/source:Span" %t1094)
  store { i64, [4 x i64] } %t1097, ptr %l464
  br label %bb129
bb129:
  store { i64, [15 x i64] } zeroinitializer, ptr %t1098
  %t1099 = getelementptr { i64, [15 x i64] }, ptr %t1098, i32 0, i32 0
  store i64 0, ptr %t1099
  %t1100 = load { i64, [4 x i64] }, ptr %l464
  %t1101 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t1100, 0
  %t1102 = getelementptr { i64, [15 x i64] }, ptr %t1098, i32 0, i32 1
  store { { i64, [4 x i64] } } %t1101, ptr %t1102
  %t1103 = load { i64, [15 x i64] }, ptr %t1098
  store { i64, [21 x i64] } zeroinitializer, ptr %t1104
  %t1105 = getelementptr { i64, [21 x i64] }, ptr %t1104, i32 0, i32 0
  store i64 0, ptr %t1105
  %t1106 = load %"compiler/source:Span", ptr %l459
  %t1107 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t1106, 0
  %t1108 = load %"compiler/mir:Place", ptr %l461
  %t1109 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t1107, %"compiler/mir:Place" %t1108, 1
  %t1111 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t1109, { i64, [15 x i64] } %t1103, 2
  %t1112 = getelementptr { i64, [21 x i64] }, ptr %t1104, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t1111, ptr %t1112
  %t1113 = load { i64, [21 x i64] }, ptr %t1104
  %t1115 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t1113, ptr %t1115
  %t1116 = load ptr, ptr %l458, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s0, ptr %t1116, ptr %t1115)
  br label %bb130
bb130:
  %t1118 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eleaveOpen(ptr %v0, ptr %s0, ptr %t1118, ptr %l26)
  br label %bb131
bb131:
  %t1121 = load ptr, ptr %l0, !tbaa !29
  %t1122 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l26
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2epatch(ptr %v0, ptr %s0, ptr %t1121, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1122)
  br label %bb132
bb132:
  %t1125 = load i32, ptr %l24, !tbaa !23
  %t1127 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t1125)
  store %"compiler/mir:Place" %t1127, ptr %l473
  br label %bb133
bb133:
  store { i64, [4 x i64] } zeroinitializer, ptr %t1128
  %t1129 = getelementptr { i64, [4 x i64] }, ptr %t1128, i32 0, i32 0
  store i64 1, ptr %t1129
  %t1130 = load %"compiler/mir:Place", ptr %l473
  %t1131 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t1130, 0
  %t1132 = getelementptr { i64, [4 x i64] }, ptr %t1128, i32 0, i32 1
  store { %"compiler/mir:Place" } %t1131, ptr %t1132
  %t1133 = load { i64, [4 x i64] }, ptr %t1128
  call void @__olang_scope_close(ptr %s0)
  store { i64, [4 x i64] } %t1133, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2efails(ptr %v0, ptr %a0, { i64, [4 x i64] } %a1, i32 %a2, i32 %a3, i64 %a4, %"compiler/source:Span" %a5) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l5 = alloca %"compiler/source:Span"
  %l9 = alloca i1
  %l16 = alloca { i64, ptr }
  %l18 = alloca { i64, [4 x i64] }
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  store %"compiler/source:Span" %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 7
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb3
bb2:
  %t6 = load i32, ptr %l2
  %t8 = trunc i64 0 to i32
  %t9 = icmp eq i32 %t6, %t8
  store i1 %t9, ptr %l9, !tbaa !21
  br label %bb3
bb3:
  %t11 = load i1, ptr %l9, !tbaa !21
  br i1 %t11, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb5:
  br label %bb6
bb6:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t15 = mul i64 1, 40
  %t16 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t15)
  %t17 = insertvalue { i64, ptr } undef, i64 1, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  store { i64, ptr } %t18, ptr %l16, !tbaa !27
  %t20 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = getelementptr { i64, [4 x i64] }, ptr %t21, i64 0
  store { i64, [4 x i64] } %a1, ptr %t22
  %t23 = load %"compiler/source:Span", ptr %l5
  %t27 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t29 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s0, ptr %t12, i32 2, i32 %t13, { i64, ptr } %t27, %"compiler/source:Span" %t23)
  store { i64, [4 x i64] } %t29, ptr %l18
  br label %bb7
bb7:
  %t30 = load { i64, [4 x i64] }, ptr %l18
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = load i32, ptr %l2
  %t36 = load %"compiler/source:Span", ptr %l5
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2echeck(ptr %v0, ptr %t31, { i64, [4 x i64] } %t30, i32 %t33, i32 %a3, i64 %a4, %"compiler/source:Span" %t36)
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2flower_2ecompiler_2flower_3alowering_2efixedLen(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l6 = alloca i32
  %l9 = alloca i1
  %l13 = alloca i32
  %l21 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t8 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t4, i32 %a1)
  store i32 %t8, ptr %l6
  br label %bb1
bb1:
  %t9 = load i32, ptr %l6, !tbaa !23
  store i32 %t9, ptr %l2, !tbaa !23
  %t10 = load i32, ptr %l2, !tbaa !23
  %t12 = icmp eq i32 %t10, 0
  br i1 %t12, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb5
bb3:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/lower:lowering", ptr %t14, i32 0, i32 2
  %t17 = load ptr, ptr %t16, !tbaa !29
  %t18 = load i32, ptr %l2, !tbaa !23
  %t21 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t17, i32 %t18)
  store i32 %t21, ptr %l13
  br label %bb4
bb4:
  %t22 = load i32, ptr %l13
  %t24 = trunc i64 26 to i32
  %t25 = icmp eq i32 %t22, %t24
  %t27 = xor i1 %t25, true
  store i1 %t27, ptr %l9, !tbaa !21
  br label %bb5
bb5:
  %t29 = load i1, ptr %l9, !tbaa !21
  br i1 %t29, label %bb6, label %bb7
bb6:
  store i64 -1, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/lower:lowering", ptr %t31, i32 0, i32 2
  %t34 = load ptr, ptr %t33, !tbaa !29
  %t35 = load i32, ptr %l2, !tbaa !23
  %t38 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstValue(ptr %v0, ptr %t34, i32 %t35)
  store i64 %t38, ptr %l21
  br label %bb9
bb9:
  %t39 = load i64, ptr %l21, !tbaa !24
  store i64 %t39, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2egap(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l8 = alloca ptr
  %l15 = alloca %"compiler/lower:Gap"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 8
  %t4 = load i1, ptr %t3, !tbaa !21
  %t6 = xor i1 %t4, true
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/lower:lowering", ptr %t8, i32 0, i32 0
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t13 = getelementptr %"compiler/lower:Lowerer", ptr %t11, i32 0, i32 4
  store ptr %t13, ptr %l8, !tbaa !29
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/lower:lowering", ptr %t14, i32 0, i32 4
  %t17 = load i64, ptr %t16, !tbaa !24
  %t21 = extractvalue { i64, ptr } %a2, 1
  %t22 = extractvalue { i64, ptr } %a2, 0
  %t23 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t22)
  call void @olang_textcopy(ptr %t23, ptr %t21, i64 %t22)
  %t24 = insertvalue { i64, ptr } undef, i64 %t22, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t23, 1
  %t27 = extractvalue { i64, ptr } %t25, 0
  %t28 = extractvalue { i64, ptr } %t25, 1
  %t29 = mul i64 %t27, 1
  %t30 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t29)
  call void @llvm.memcpy.p0.p0.i64(ptr %t30, ptr %t28, i64 %t29, i1 false)
  %t31 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  %t36 = call %"compiler/lower:Gap" @compiler_2flower_3aGap_2ector(ptr %v0, ptr %v0, i64 %t17, %"compiler/source:Span" %a1, { i64, ptr } %t32)
  store %"compiler/lower:Gap" %t36, ptr %l15
  br label %bb3
bb2:
  br label %bb5
bb3:
  %t37 = load ptr, ptr %l8, !tbaa !29
  %t38 = load %"compiler/lower:Gap", ptr %l15
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3aGap_3e_2ePush_3ccompiler_2flower_3aGap_3e(ptr %v0, ptr %v0, ptr %t37, %"compiler/lower:Gap" %t38)
  br label %bb4
bb4:
  br label %bb5
bb5:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/lower:lowering", ptr %t39, i32 0, i32 8
  store i1 true, ptr %t41, !tbaa !21
  br label %ret
ret:
  ret void
}

define dso_local { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ehashAt(ptr %v0, ptr %v1, ptr %a0, %"compiler/lower:pl" %a1, i32 %a2, %"compiler/source:Span" %a3, i1 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/lower:pl"
  %l2 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca i1
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca i64
  %l8 = alloca { { i64, [7 x i64] }, i32 }
  %l9 = alloca { i64, [7 x i64] }
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca { i64, [4 x i64] }
  %l13 = alloca i32
  %l14 = alloca i32
  %l16 = alloca { i64, [4 x i64] }
  %l17 = alloca { i64, [4 x i64] }
  %l19 = alloca i32
  %l20 = alloca i32
  %l21 = alloca { i64, [4 x i64] }
  %l22 = alloca i32
  %l23 = alloca i32
  %l24 = alloca { i64, [4 x i64] }
  %l25 = alloca i32
  %l26 = alloca { { i64, ptr }, i1 }
  %l27 = alloca { i64, ptr }
  %l28 = alloca i1
  %l29 = alloca { { i64, ptr }, i1 }
  %l30 = alloca { i64, ptr }
  %l31 = alloca i1
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca { i64, [4 x i64] }
  %l39 = alloca i32
  %l45 = alloca i32
  %l47 = alloca i64
  %l50 = alloca i64
  %l57 = alloca { { i64, [7 x i64] }, i32 }
  %l60 = alloca ptr
  %l63 = alloca i32
  %l64 = alloca { i64, ptr }
  %l65 = alloca { i64, ptr }
  %l69 = alloca i1
  %l70 = alloca { i64, [4 x i64] }
  %l71 = alloca ptr
  %l72 = alloca i32
  %l75 = alloca %"compiler/mir:Place"
  %l79 = alloca { i64, [4 x i64] }
  %l80 = alloca ptr
  %l81 = alloca i32
  %l84 = alloca %"compiler/mir:Place"
  %l88 = alloca { i64, [4 x i64] }
  %l91 = alloca i32
  %l95 = alloca i32
  %l97 = alloca ptr
  %l98 = alloca { i64, [7 x i64] }
  %l102 = alloca { i64, ptr }
  %l103 = alloca %"compiler/mir:Range"
  %l104 = alloca ptr
  %l108 = alloca i64
  %l109 = alloca %"compiler/mir:Range"
  %l111 = alloca %"compiler/mir:Place"
  %l115 = alloca %"compiler/mir:Call"
  %l116 = alloca i32
  %l124 = alloca %"compiler/mir:Place"
  %l128 = alloca i1
  %l129 = alloca ptr
  %l130 = alloca i32
  %l133 = alloca %"compiler/mir:Place"
  %l137 = alloca { i64, [4 x i64] }
  %l140 = alloca i1
  %l141 = alloca i1
  %l144 = alloca i64
  %l146 = alloca ptr
  %l147 = alloca i32
  %l148 = alloca i32
  %l149 = alloca { i64, [4 x i64] }
  %l151 = alloca { i64, [4 x i64] }
  %l152 = alloca { i64, ptr }
  %l154 = alloca { i64, [4 x i64] }
  %l159 = alloca { i64, [4 x i64] }
  %l160 = alloca ptr
  %l161 = alloca ptr
  %l162 = alloca i32
  %l163 = alloca i32
  %l164 = alloca { i64, [4 x i64] }
  %l165 = alloca ptr
  %l170 = alloca { i64, [4 x i64] }
  %l172 = alloca { i64, [4 x i64] }
  %l173 = alloca { i64, ptr }
  %l175 = alloca { i64, [4 x i64] }
  %l177 = alloca { i64, [4 x i64] }
  %l178 = alloca ptr
  %l183 = alloca { i64, [4 x i64] }
  %l185 = alloca { i64, [4 x i64] }
  %l188 = alloca i1
  %l189 = alloca ptr
  %l192 = alloca %"compiler/mir:Place"
  %l196 = alloca i32
  %l200 = alloca i32
  %l201 = alloca ptr
  %l202 = alloca %"compiler/source:Span"
  %l204 = alloca %"compiler/mir:Place"
  %l206 = alloca { i64, [4 x i64] }
  %l210 = alloca ptr
  %l211 = alloca i32
  %l212 = alloca i32
  %l214 = alloca %"compiler/mir:Place"
  %l218 = alloca { i64, ptr }
  %l220 = alloca { i64, [4 x i64] }
  %l223 = alloca i32
  %l226 = alloca i32
  %l234 = alloca ptr
  %l237 = alloca %"compiler/lower:pl"
  %l240 = alloca i32
  %l242 = alloca { i64, [4 x i64] }
  %l243 = alloca ptr
  %l244 = alloca %"compiler/source:Span"
  %l246 = alloca %"compiler/mir:Place"
  %l256 = alloca %"compiler/mir:Place"
  %l260 = alloca ptr
  %l261 = alloca i32
  %l262 = alloca i32
  %l267 = alloca { i64, [4 x i64] }
  %l268 = alloca { i64, ptr }
  %l272 = alloca { i64, [4 x i64] }
  %l276 = alloca i32
  %l277 = alloca ptr
  %l278 = alloca %"compiler/source:Span"
  %l280 = alloca %"compiler/mir:Place"
  %l282 = alloca { i64, [4 x i64] }
  %l288 = alloca { { i64, ptr }, i1 }
  %l289 = alloca { i64, ptr }
  %l290 = alloca i64
  %l291 = alloca { i64, ptr }
  %l295 = alloca { { i64, ptr }, i1 }
  %l296 = alloca { i64, ptr }
  %l297 = alloca i64
  %l298 = alloca { i64, ptr }
  %l306 = alloca i64
  %l309 = alloca i64
  %l327 = alloca ptr
  %l328 = alloca i32
  %l329 = alloca ptr
  %l334 = alloca %"compiler/lower:pl"
  %l338 = alloca { i64, [4 x i64] }
  %l343 = alloca ptr
  %l344 = alloca i32
  %l347 = alloca %"compiler/mir:Place"
  %l350 = alloca { i64, [4 x i64] }
  %l351 = alloca ptr
  %l352 = alloca i32
  %l356 = alloca { i64, [4 x i64] }
  %l369 = alloca i32
  %l372 = alloca ptr
  %l375 = alloca i32
  %l376 = alloca i32
  %l377 = alloca ptr
  %l378 = alloca i32
  %l379 = alloca i32
  %l382 = alloca %"compiler/mir:Place"
  %l384 = alloca { i64, ptr }
  %l386 = alloca { i64, [4 x i64] }
  %l399 = alloca %"compiler/mir:Place"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %rv = alloca { i64, [4 x i64] }
  %t76 = alloca { i64, [15 x i64] }, align 8
  %t91 = alloca { i64, [4 x i64] }, align 8
  %t97 = alloca { i64, [15 x i64] }, align 8
  %t176 = alloca { i64, [8 x i64] }, align 8
  %t193 = alloca { i64, [4 x i64] }, align 8
  %t213 = alloca { i64, [4 x i64] }, align 8
  %t219 = alloca { i64, [15 x i64] }, align 8
  %t355 = alloca { i64, [4 x i64] }, align 8
  %t385 = alloca { i64, [15 x i64] }, align 8
  %t391 = alloca { i64, [21 x i64] }, align 8
  %t410 = alloca { i64, [4 x i64] }, align 8
  %t417 = alloca { i64, [4 x i64] }, align 8
  %t460 = alloca { i64, [8 x i64] }, align 8
  %t500 = alloca { i64, [15 x i64] }, align 8
  %t506 = alloca { i64, [21 x i64] }, align 8
  %t531 = alloca { i64, [4 x i64] }, align 8
  %t592 = alloca { i64, [15 x i64] }, align 8
  %t598 = alloca { i64, [21 x i64] }, align 8
  %t722 = alloca { i64, [1 x i64] }, align 8
  %t765 = alloca { i64, [15 x i64] }, align 8
  %t802 = alloca { ptr, i32, %"compiler/lower:pl", %"compiler/source:Span", ptr, ptr }, align 8
  %t848 = alloca { i64, [4 x i64] }, align 8
  %t880 = alloca { ptr, i32, %"compiler/lower:pl", i32, %"compiler/source:Span", ptr, ptr }, align 8
  %t904 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/lower:pl" %a1, ptr %l1
  store i32 %a2, ptr %l2
  store %"compiler/source:Span" %a3, ptr %l3
  store i1 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l5, !tbaa !29
  %t6 = load ptr, ptr %l5, !tbaa !29
  %t7 = load i32, ptr %l2, !tbaa !23
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t6, i32 %t7)
  store i32 %t10, ptr %l45
  br label %bb1
bb1:
  %t11 = load i32, ptr %l45, !tbaa !23
  store i32 %t11, ptr %l6, !tbaa !23
  %t12 = load i1, ptr %l4, !tbaa !21
  br i1 %t12, label %bb2, label %bb3
bb2:
  store i64 -1, ptr %l47, !tbaa !24
  br label %bb5
bb3:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t15 = load i32, ptr %l2, !tbaa !23
  %t18 = call i64 @compiler_2flower_2ecompiler_2flower_3alowering_2emethodBody(ptr %v0, ptr %s0, ptr %s0, ptr %t14, i32 %t15, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d9, i32 0, i32 1) }, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d10, i32 0, i32 1) })
  store i64 %t18, ptr %l50
  br label %bb4
bb4:
  %t19 = load i64, ptr %l50, !tbaa !24
  store i64 %t19, ptr %l47, !tbaa !24
  br label %bb5
bb5:
  %t20 = load i64, ptr %l47, !tbaa !24
  store i64 %t20, ptr %l7, !tbaa !24
  %t21 = load i64, ptr %l7, !tbaa !24
  %t23 = icmp sge i64 %t21, 0
  br i1 %t23, label %bb6, label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s1
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t26 = load i64, ptr %l7, !tbaa !24
  %t28 = trunc i64 %t26 to i32
  %t32 = call { { i64, [7 x i64] }, i32 } @compiler_2flower_2ecompiler_2flower_3alowering_2ebodyCallee(ptr %v0, ptr %t25, i32 %t28)
  store { { i64, [7 x i64] }, i32 } %t32, ptr %l57
  br label %bb8
bb7:
  br label %bb30
bb8:
  %t33 = load { { i64, [7 x i64] }, i32 }, ptr %l57
  store { { i64, [7 x i64] }, i32 } %t33, ptr %l8
  %t34 = getelementptr { { i64, [7 x i64] }, i32 }, ptr %l8, i32 0, i32 0
  %t35 = load { i64, [7 x i64] }, ptr %t34
  store { i64, [7 x i64] } %t35, ptr %l9
  %t37 = getelementptr { { i64, [7 x i64] }, i32 }, ptr %l8, i32 0, i32 1
  %t38 = load i32, ptr %t37, !tbaa !23
  store i32 %t38, ptr %l10, !tbaa !23
  %t40 = load ptr, ptr %l5, !tbaa !29
  store ptr %t40, ptr %l60, !tbaa !29
  %t41 = load ptr, ptr %l5, !tbaa !29
  %t42 = load i32, ptr %l10, !tbaa !23
  %t45 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t41, i32 %t42)
  store i32 %t45, ptr %l63
  br label %bb9
bb9:
  %t46 = load ptr, ptr %l60, !tbaa !29
  %t47 = load i32, ptr %l63, !tbaa !23
  %t48 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t46, i32 %t47)
  store { i64, ptr } %t48, ptr %l64
  br label %bb10
bb10:
  %t49 = load { i64, ptr }, ptr %l64, !tbaa !27
  store { i64, ptr } %t49, ptr %l65, !tbaa !27
  %t50 = getelementptr { i64, ptr }, ptr %l65, i32 0, i32 1
  %t51 = load ptr, ptr %t50, !tbaa !27
  %t52 = getelementptr i32, ptr %t51, i64 0
  %t53 = load i32, ptr %t52, !tbaa !33
  store i32 %t53, ptr %l11, !tbaa !23
  %t55 = load ptr, ptr %l5, !tbaa !29
  %t56 = load i32, ptr %l11, !tbaa !23
  %t59 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t55, i32 %t56)
  store i1 %t59, ptr %l69
  br label %bb11
bb11:
  %t60 = load i1, ptr %l69, !tbaa !21
  br i1 %t60, label %bb12, label %bb13
bb12:
  %t61 = load ptr, ptr %l0, !tbaa !29
  store ptr %t61, ptr %l71, !tbaa !29
  %t62 = load i32, ptr %l11, !tbaa !23
  store i32 %t62, ptr %l72, !tbaa !23
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t64 = load %"compiler/lower:pl", ptr %l1
  %t67 = call %"compiler/mir:Place" @compiler_2flower_2ecompiler_2flower_3alowering_2emk(ptr %v0, ptr %v1, ptr %t63, %"compiler/lower:pl" %t64)
  store %"compiler/mir:Place" %t67, ptr %l75
  br label %bb14
bb13:
  %t68 = load ptr, ptr %l0, !tbaa !29
  store ptr %t68, ptr %l80, !tbaa !29
  %t69 = load i32, ptr %l11, !tbaa !23
  store i32 %t69, ptr %l81, !tbaa !23
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t71 = load %"compiler/lower:pl", ptr %l1
  %t74 = call %"compiler/mir:Place" @compiler_2flower_2ecompiler_2flower_3alowering_2emk(ptr %v0, ptr %v1, ptr %t70, %"compiler/lower:pl" %t71)
  store %"compiler/mir:Place" %t74, ptr %l84
  br label %bb16
bb14:
  %t75 = load i32, ptr %l11, !tbaa !23
  store { i64, [15 x i64] } zeroinitializer, ptr %t76
  %t77 = getelementptr { i64, [15 x i64] }, ptr %t76, i32 0, i32 0
  store i64 1, ptr %t77
  %t78 = load %"compiler/mir:Place", ptr %l75
  %t79 = insertvalue { %"compiler/mir:Place", i32 } undef, %"compiler/mir:Place" %t78, 0
  %t81 = insertvalue { %"compiler/mir:Place", i32 } %t79, i32 %t75, 1
  %t82 = getelementptr { i64, [15 x i64] }, ptr %t76, i32 0, i32 1
  store { %"compiler/mir:Place", i32 } %t81, ptr %t82
  %t83 = load { i64, [15 x i64] }, ptr %t76
  %t84 = load %"compiler/source:Span", ptr %l3
  %t85 = load ptr, ptr %l71, !tbaa !29
  %t86 = load i32, ptr %l72, !tbaa !23
  %t89 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %t85, i32 %t86, { i64, [15 x i64] } %t83, %"compiler/source:Span" %t84)
  store { i64, [4 x i64] } %t89, ptr %l79
  br label %bb15
bb15:
  %t90 = load { i64, [4 x i64] }, ptr %l79
  store { i64, [4 x i64] } %t90, ptr %l70
  br label %bb18
bb16:
  store { i64, [4 x i64] } zeroinitializer, ptr %t91
  %t92 = getelementptr { i64, [4 x i64] }, ptr %t91, i32 0, i32 0
  store i64 1, ptr %t92
  %t93 = load %"compiler/mir:Place", ptr %l84
  %t94 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t93, 0
  %t95 = getelementptr { i64, [4 x i64] }, ptr %t91, i32 0, i32 1
  store { %"compiler/mir:Place" } %t94, ptr %t95
  %t96 = load { i64, [4 x i64] }, ptr %t91
  store { i64, [15 x i64] } zeroinitializer, ptr %t97
  %t98 = getelementptr { i64, [15 x i64] }, ptr %t97, i32 0, i32 0
  store i64 0, ptr %t98
  %t100 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t96, 0
  %t101 = getelementptr { i64, [15 x i64] }, ptr %t97, i32 0, i32 1
  store { { i64, [4 x i64] } } %t100, ptr %t101
  %t102 = load { i64, [15 x i64] }, ptr %t97
  %t103 = load %"compiler/source:Span", ptr %l3
  %t104 = load ptr, ptr %l80, !tbaa !29
  %t105 = load i32, ptr %l81, !tbaa !23
  %t108 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %t104, i32 %t105, { i64, [15 x i64] } %t102, %"compiler/source:Span" %t103)
  store { i64, [4 x i64] } %t108, ptr %l88
  br label %bb17
bb17:
  %t109 = load { i64, [4 x i64] }, ptr %l88
  store { i64, [4 x i64] } %t109, ptr %l70
  br label %bb18
bb18:
  %t110 = load { i64, [4 x i64] }, ptr %l70
  store { i64, [4 x i64] } %t110, ptr %l12
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t113 = getelementptr %"compiler/lower:lowering", ptr %t111, i32 0, i32 3
  %t115 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t113)
  store i32 %t115, ptr %l91
  br label %bb19
bb19:
  %t116 = load i32, ptr %l91, !tbaa !23
  store i32 %t116, ptr %l13, !tbaa !23
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t118 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  %t119 = load %"compiler/source:Span", ptr %l3
  %t123 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2etemp(ptr %v0, ptr %t117, i32 %t118, %"compiler/source:Span" %t119)
  store i32 %t123, ptr %l95
  br label %bb20
bb20:
  %t124 = load i32, ptr %l95, !tbaa !23
  store i32 %t124, ptr %l14, !tbaa !23
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t127 = getelementptr %"compiler/lower:lowering", ptr %t125, i32 0, i32 3
  store ptr %t127, ptr %l97, !tbaa !29
  %t128 = load { i64, [7 x i64] }, ptr %l9
  store { i64, [7 x i64] } %t128, ptr %l98
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t131 = getelementptr %"compiler/lower:lowering", ptr %t129, i32 0, i32 3
  %t132 = load { i64, [4 x i64] }, ptr %l12
  %t133 = mul i64 1, 40
  %t134 = call ptr @__olang_scope_alloc_zeroed(ptr %s1, i64 %t133)
  %t135 = insertvalue { i64, ptr } undef, i64 1, 0
  %t136 = insertvalue { i64, ptr } %t135, ptr %t134, 1
  store { i64, ptr } %t136, ptr %l102, !tbaa !27
  %t138 = getelementptr { i64, ptr }, ptr %l102, i32 0, i32 1
  %t139 = load ptr, ptr %t138, !tbaa !27
  %t140 = getelementptr { i64, [4 x i64] }, ptr %t139, i64 0
  store { i64, [4 x i64] } %t132, ptr %t140
  %t142 = load { i64, ptr }, ptr %l102, !tbaa !27
  %t143 = call %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eArgs(ptr %v0, ptr %s1, ptr %t131, { i64, ptr } %t142)
  store %"compiler/mir:Range" %t143, ptr %l103
  br label %bb21
bb21:
  %t144 = load ptr, ptr %l0, !tbaa !29
  store ptr %t144, ptr %l104, !tbaa !29
  %t145 = load ptr, ptr %l5, !tbaa !29
  %t146 = load { i64, [7 x i64] }, ptr %l9
  %t147 = load i32, ptr %l10, !tbaa !23
  %t151 = call i64 @compiler_2fmir_2ePassedCount(ptr %v0, ptr %t145, { i64, [7 x i64] } %t146, i32 %t147)
  store i64 %t151, ptr %l108
  br label %bb22
bb22:
  %t152 = load ptr, ptr %l104, !tbaa !29
  %t153 = load i64, ptr %l108, !tbaa !24
  %t154 = call %"compiler/mir:Range" @compiler_2flower_2ecompiler_2flower_3alowering_2epassed(ptr %v0, ptr %t152, i64 %t153, i32 -1)
  store %"compiler/mir:Range" %t154, ptr %l109
  br label %bb23
bb23:
  %t155 = load i32, ptr %l14, !tbaa !23
  %t157 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t155)
  store %"compiler/mir:Place" %t157, ptr %l111
  br label %bb24
bb24:
  %t158 = load i32, ptr %l13, !tbaa !23
  %t159 = load i32, ptr @G_2ecompiler_2fmir_2eNoLocal, !tbaa !23
  %t160 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t161 = load { i64, [7 x i64] }, ptr %l98
  %t162 = load %"compiler/mir:Range", ptr %l103
  %t163 = load %"compiler/mir:Range", ptr %l109
  %t164 = load %"compiler/mir:Place", ptr %l111
  %t168 = call %"compiler/mir:Call" @compiler_2fmir_3aCall_2ector(ptr %s1, { i64, [7 x i64] } %t161, %"compiler/mir:Range" %t162, %"compiler/mir:Range" %t163, %"compiler/mir:Place" %t164, i1 true, i32 %t158, i32 %t159, i32 %t160)
  store %"compiler/mir:Call" %t168, ptr %l115
  br label %bb25
bb25:
  %t169 = load ptr, ptr %l97, !tbaa !29
  %t170 = load %"compiler/mir:Call", ptr %l115
  %t171 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddCall(ptr %v0, ptr %t169, %"compiler/mir:Call" %t170)
  store i32 %t171, ptr %l116
  br label %bb26
bb26:
  %t172 = load i32, ptr %l116, !tbaa !23
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t174 = load %"compiler/source:Span", ptr %l3
  store { i64, [8 x i64] } zeroinitializer, ptr %t176
  %t177 = getelementptr { i64, [8 x i64] }, ptr %t176, i32 0, i32 0
  store i64 4, ptr %t177
  %t179 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t174, 0
  %t181 = insertvalue { %"compiler/source:Span", i32 } %t179, i32 %t172, 1
  %t182 = getelementptr { i64, [8 x i64] }, ptr %t176, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t181, ptr %t182
  %t183 = load { i64, [8 x i64] }, ptr %t176
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t173, { i64, [8 x i64] } %t183)
  br label %bb27
bb27:
  %t186 = load ptr, ptr %l0, !tbaa !29
  %t187 = load i32, ptr %l13, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t186, i32 %t187)
  br label %bb28
bb28:
  %t190 = load i32, ptr %l14, !tbaa !23
  %t192 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t190)
  store %"compiler/mir:Place" %t192, ptr %l124
  br label %bb29
bb29:
  store { i64, [4 x i64] } zeroinitializer, ptr %t193
  %t194 = getelementptr { i64, [4 x i64] }, ptr %t193, i32 0, i32 0
  store i64 1, ptr %t194
  %t195 = load %"compiler/mir:Place", ptr %l124
  %t196 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t195, 0
  %t197 = getelementptr { i64, [4 x i64] }, ptr %t193, i32 0, i32 1
  store { %"compiler/mir:Place" } %t196, ptr %t197
  %t198 = load { i64, [4 x i64] }, ptr %t193
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  store { i64, [4 x i64] } %t198, ptr %rv
  br label %ret
bb30:
  %t200 = load ptr, ptr %l0, !tbaa !29
  %t201 = load i32, ptr %l2, !tbaa !23
  %t204 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2escalar(ptr %v0, ptr %t200, i32 %t201)
  store i1 %t204, ptr %l128
  br label %bb31
bb31:
  %t205 = load i1, ptr %l128, !tbaa !21
  br i1 %t205, label %bb32, label %bb33
bb32:
  %t206 = load ptr, ptr %l0, !tbaa !29
  store ptr %t206, ptr %l129, !tbaa !29
  %t207 = load i32, ptr %l2, !tbaa !23
  store i32 %t207, ptr %l130, !tbaa !23
  %t208 = load ptr, ptr %l0, !tbaa !29
  %t209 = load %"compiler/lower:pl", ptr %l1
  %t212 = call %"compiler/mir:Place" @compiler_2flower_2ecompiler_2flower_3alowering_2emk(ptr %v0, ptr %v1, ptr %t208, %"compiler/lower:pl" %t209)
  store %"compiler/mir:Place" %t212, ptr %l133
  br label %bb34
bb33:
  br label %bb53
bb34:
  store { i64, [4 x i64] } zeroinitializer, ptr %t213
  %t214 = getelementptr { i64, [4 x i64] }, ptr %t213, i32 0, i32 0
  store i64 1, ptr %t214
  %t215 = load %"compiler/mir:Place", ptr %l133
  %t216 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t215, 0
  %t217 = getelementptr { i64, [4 x i64] }, ptr %t213, i32 0, i32 1
  store { %"compiler/mir:Place" } %t216, ptr %t217
  %t218 = load { i64, [4 x i64] }, ptr %t213
  store { i64, [15 x i64] } zeroinitializer, ptr %t219
  %t220 = getelementptr { i64, [15 x i64] }, ptr %t219, i32 0, i32 0
  store i64 0, ptr %t220
  %t222 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t218, 0
  %t223 = getelementptr { i64, [15 x i64] }, ptr %t219, i32 0, i32 1
  store { { i64, [4 x i64] } } %t222, ptr %t223
  %t224 = load { i64, [15 x i64] }, ptr %t219
  %t225 = load %"compiler/source:Span", ptr %l3
  %t226 = load ptr, ptr %l129, !tbaa !29
  %t227 = load i32, ptr %l130, !tbaa !23
  %t230 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %t226, i32 %t227, { i64, [15 x i64] } %t224, %"compiler/source:Span" %t225)
  store { i64, [4 x i64] } %t230, ptr %l137
  br label %bb35
bb35:
  %t231 = load { i64, [4 x i64] }, ptr %l137
  store { i64, [4 x i64] } %t231, ptr %l16
  %t232 = load ptr, ptr %l5, !tbaa !29
  %t233 = load i32, ptr %l6, !tbaa !23
  %t236 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %t232, i32 %t233)
  store i1 %t236, ptr %l140
  br label %bb36
bb36:
  %t237 = load i1, ptr %l140, !tbaa !21
  br i1 %t237, label %bb37, label %bb38
bb37:
  %t238 = load ptr, ptr %l5, !tbaa !29
  %t239 = load i32, ptr %l6, !tbaa !23
  %t242 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %t238, i32 %t239)
  store i64 %t242, ptr %l144
  br label %bb39
bb38:
  store i1 false, ptr %l141, !tbaa !21
  br label %bb40
bb39:
  %t243 = load i64, ptr %l144, !tbaa !24
  %t244 = icmp sgt i64 %t243, 64
  store i1 %t244, ptr %l141, !tbaa !21
  br label %bb40
bb40:
  %t246 = load i1, ptr %l141, !tbaa !21
  br i1 %t246, label %bb41, label %bb42
bb41:
  store %olang.scope zeroinitializer, ptr %s3
  %t247 = load ptr, ptr %l0, !tbaa !29
  store ptr %t247, ptr %l146, !tbaa !29
  store i32 9, ptr %l147
  %t248 = load i32, ptr %l2, !tbaa !23
  store i32 %t248, ptr %l148, !tbaa !23
  %t249 = load { i64, [4 x i64] }, ptr %l16
  store { i64, [4 x i64] } %t249, ptr %l149
  %t250 = load ptr, ptr %l0, !tbaa !29
  %t252 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2econstI64(ptr %v0, ptr %t250, i64 64)
  store { i64, [4 x i64] } %t252, ptr %l151
  br label %bb43
bb42:
  br label %bb50
bb43:
  %t253 = mul i64 2, 40
  %t254 = call ptr @__olang_scope_alloc_zeroed(ptr %s3, i64 %t253)
  %t255 = insertvalue { i64, ptr } undef, i64 2, 0
  %t256 = insertvalue { i64, ptr } %t255, ptr %t254, 1
  store { i64, ptr } %t256, ptr %l152, !tbaa !27
  %t257 = load { i64, [4 x i64] }, ptr %l149
  %t258 = getelementptr { i64, ptr }, ptr %l152, i32 0, i32 1
  %t259 = load ptr, ptr %t258, !tbaa !27
  %t260 = getelementptr { i64, [4 x i64] }, ptr %t259, i64 0
  store { i64, [4 x i64] } %t257, ptr %t260
  %t261 = load { i64, [4 x i64] }, ptr %l151
  %t262 = getelementptr { i64, ptr }, ptr %l152, i32 0, i32 1
  %t263 = load ptr, ptr %t262, !tbaa !27
  %t264 = getelementptr { i64, [4 x i64] }, ptr %t263, i64 1
  store { i64, [4 x i64] } %t261, ptr %t264
  %t265 = load %"compiler/source:Span", ptr %l3
  %t266 = load ptr, ptr %l146, !tbaa !29
  %t267 = load i32, ptr %l147
  %t268 = load i32, ptr %l148, !tbaa !23
  %t269 = load { i64, ptr }, ptr %l152, !tbaa !27
  %t271 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s3, ptr %t266, i32 %t267, i32 %t268, { i64, ptr } %t269, %"compiler/source:Span" %t265)
  store { i64, [4 x i64] } %t271, ptr %l154
  br label %bb44
bb44:
  %t272 = load { i64, [4 x i64] }, ptr %l154
  store { i64, [4 x i64] } %t272, ptr %l17
  %t273 = load ptr, ptr %l0, !tbaa !29
  %t274 = load { i64, [4 x i64] }, ptr %l16
  %t275 = load i32, ptr %l2, !tbaa !23
  %t276 = load %"compiler/source:Span", ptr %l3
  %t281 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2easI64(ptr %v0, ptr %t273, { i64, [4 x i64] } %t274, i32 %t275, %"compiler/source:Span" %t276)
  store { i64, [4 x i64] } %t281, ptr %l159
  br label %bb45
bb45:
  %t282 = load { i64, [4 x i64] }, ptr %l159
  %t283 = load ptr, ptr %l0, !tbaa !29
  store ptr %t283, ptr %l160, !tbaa !29
  %t284 = load ptr, ptr %l0, !tbaa !29
  store ptr %t284, ptr %l161, !tbaa !29
  store i32 12, ptr %l162
  %t285 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  store i32 %t285, ptr %l163, !tbaa !23
  store { i64, [4 x i64] } %t282, ptr %l164
  %t287 = load ptr, ptr %l0, !tbaa !29
  store ptr %t287, ptr %l165, !tbaa !29
  %t288 = load ptr, ptr %l0, !tbaa !29
  %t289 = load { i64, [4 x i64] }, ptr %l17
  %t290 = load i32, ptr %l2, !tbaa !23
  %t291 = load %"compiler/source:Span", ptr %l3
  %t296 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2easI64(ptr %v0, ptr %t288, { i64, [4 x i64] } %t289, i32 %t290, %"compiler/source:Span" %t291)
  store { i64, [4 x i64] } %t296, ptr %l170
  br label %bb46
bb46:
  %t297 = load %"compiler/source:Span", ptr %l3
  %t298 = load ptr, ptr %l165, !tbaa !29
  %t299 = load { i64, [4 x i64] }, ptr %l170
  %t301 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2emix(ptr %v0, ptr %t298, { i64, [4 x i64] } %t299, %"compiler/source:Span" %t297)
  store { i64, [4 x i64] } %t301, ptr %l172
  br label %bb47
bb47:
  %t302 = mul i64 2, 40
  %t303 = call ptr @__olang_scope_alloc_zeroed(ptr %s3, i64 %t302)
  %t304 = insertvalue { i64, ptr } undef, i64 2, 0
  %t305 = insertvalue { i64, ptr } %t304, ptr %t303, 1
  store { i64, ptr } %t305, ptr %l173, !tbaa !27
  %t306 = load { i64, [4 x i64] }, ptr %l164
  %t307 = getelementptr { i64, ptr }, ptr %l173, i32 0, i32 1
  %t308 = load ptr, ptr %t307, !tbaa !27
  %t309 = getelementptr { i64, [4 x i64] }, ptr %t308, i64 0
  store { i64, [4 x i64] } %t306, ptr %t309
  %t310 = load { i64, [4 x i64] }, ptr %l172
  %t311 = getelementptr { i64, ptr }, ptr %l173, i32 0, i32 1
  %t312 = load ptr, ptr %t311, !tbaa !27
  %t313 = getelementptr { i64, [4 x i64] }, ptr %t312, i64 1
  store { i64, [4 x i64] } %t310, ptr %t313
  %t314 = load %"compiler/source:Span", ptr %l3
  %t315 = load ptr, ptr %l161, !tbaa !29
  %t316 = load i32, ptr %l162
  %t317 = load i32, ptr %l163, !tbaa !23
  %t318 = load { i64, ptr }, ptr %l173, !tbaa !27
  %t320 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s3, ptr %t315, i32 %t316, i32 %t317, { i64, ptr } %t318, %"compiler/source:Span" %t314)
  store { i64, [4 x i64] } %t320, ptr %l175
  br label %bb48
bb48:
  %t321 = load %"compiler/source:Span", ptr %l3
  %t322 = load ptr, ptr %l160, !tbaa !29
  %t323 = load { i64, [4 x i64] }, ptr %l175
  %t325 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2emix(ptr %v0, ptr %t322, { i64, [4 x i64] } %t323, %"compiler/source:Span" %t321)
  store { i64, [4 x i64] } %t325, ptr %l177
  br label %bb49
bb49:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t326 = load { i64, [4 x i64] }, ptr %l177
  store { i64, [4 x i64] } %t326, ptr %rv
  br label %ret
bb50:
  %t327 = load ptr, ptr %l0, !tbaa !29
  store ptr %t327, ptr %l178, !tbaa !29
  %t328 = load ptr, ptr %l0, !tbaa !29
  %t329 = load { i64, [4 x i64] }, ptr %l16
  %t330 = load i32, ptr %l2, !tbaa !23
  %t331 = load %"compiler/source:Span", ptr %l3
  %t336 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2easI64(ptr %v0, ptr %t328, { i64, [4 x i64] } %t329, i32 %t330, %"compiler/source:Span" %t331)
  store { i64, [4 x i64] } %t336, ptr %l183
  br label %bb51
bb51:
  %t337 = load %"compiler/source:Span", ptr %l3
  %t338 = load ptr, ptr %l178, !tbaa !29
  %t339 = load { i64, [4 x i64] }, ptr %l183
  %t341 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2emix(ptr %v0, ptr %t338, { i64, [4 x i64] } %t339, %"compiler/source:Span" %t337)
  store { i64, [4 x i64] } %t341, ptr %l185
  br label %bb52
bb52:
  call void @__olang_scope_close(ptr %s0)
  %t342 = load { i64, [4 x i64] }, ptr %l185
  store { i64, [4 x i64] } %t342, ptr %rv
  br label %ret
bb53:
  %t343 = load ptr, ptr %l5, !tbaa !29
  %t344 = load i32, ptr %l6, !tbaa !23
  %t347 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t343, i32 %t344)
  store i1 %t347, ptr %l188
  br label %bb54
bb54:
  %t348 = load i1, ptr %l188, !tbaa !21
  br i1 %t348, label %bb55, label %bb56
bb55:
  store %olang.scope zeroinitializer, ptr %s4
  %t349 = load ptr, ptr %l0, !tbaa !29
  store ptr %t349, ptr %l189, !tbaa !29
  %t350 = load ptr, ptr %l0, !tbaa !29
  %t351 = load %"compiler/lower:pl", ptr %l1
  %t354 = call %"compiler/mir:Place" @compiler_2flower_2ecompiler_2flower_3alowering_2emk(ptr %v0, ptr %v1, ptr %t350, %"compiler/lower:pl" %t351)
  store %"compiler/mir:Place" %t354, ptr %l192
  br label %bb57
bb56:
  br label %bb77
bb57:
  store { i64, [4 x i64] } zeroinitializer, ptr %t355
  %t356 = getelementptr { i64, [4 x i64] }, ptr %t355, i32 0, i32 0
  store i64 1, ptr %t356
  %t357 = load %"compiler/mir:Place", ptr %l192
  %t358 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t357, 0
  %t359 = getelementptr { i64, [4 x i64] }, ptr %t355, i32 0, i32 1
  store { %"compiler/mir:Place" } %t358, ptr %t359
  %t360 = load { i64, [4 x i64] }, ptr %t355
  %t361 = load i32, ptr %l2, !tbaa !23
  %t362 = load %"compiler/source:Span", ptr %l3
  %t363 = load ptr, ptr %l189, !tbaa !29
  %t367 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2elocal(ptr %v0, ptr %t363, { i64, [4 x i64] } %t360, i32 %t361, %"compiler/source:Span" %t362)
  store i32 %t367, ptr %l196
  br label %bb58
bb58:
  %t368 = load i32, ptr %l196, !tbaa !23
  store i32 %t368, ptr %l19, !tbaa !23
  %t369 = load ptr, ptr %l0, !tbaa !29
  %t370 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  %t371 = load %"compiler/source:Span", ptr %l3
  %t375 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2etemp(ptr %v0, ptr %t369, i32 %t370, %"compiler/source:Span" %t371)
  store i32 %t375, ptr %l200
  br label %bb59
bb59:
  %t376 = load i32, ptr %l200, !tbaa !23
  store i32 %t376, ptr %l20, !tbaa !23
  %t377 = load ptr, ptr %l0, !tbaa !29
  store ptr %t377, ptr %l201, !tbaa !29
  %t378 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t378, ptr %l202
  %t379 = load i32, ptr %l20, !tbaa !23
  %t381 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t379)
  store %"compiler/mir:Place" %t381, ptr %l204
  br label %bb60
bb60:
  %t382 = load ptr, ptr %l0, !tbaa !29
  %t384 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2econstI64(ptr %v0, ptr %t382, i64 0)
  store { i64, [4 x i64] } %t384, ptr %l206
  br label %bb61
bb61:
  store { i64, [15 x i64] } zeroinitializer, ptr %t385
  %t386 = getelementptr { i64, [15 x i64] }, ptr %t385, i32 0, i32 0
  store i64 0, ptr %t386
  %t387 = load { i64, [4 x i64] }, ptr %l206
  %t388 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t387, 0
  %t389 = getelementptr { i64, [15 x i64] }, ptr %t385, i32 0, i32 1
  store { { i64, [4 x i64] } } %t388, ptr %t389
  %t390 = load { i64, [15 x i64] }, ptr %t385
  store { i64, [21 x i64] } zeroinitializer, ptr %t391
  %t392 = getelementptr { i64, [21 x i64] }, ptr %t391, i32 0, i32 0
  store i64 0, ptr %t392
  %t393 = load %"compiler/source:Span", ptr %l202
  %t394 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t393, 0
  %t395 = load %"compiler/mir:Place", ptr %l204
  %t396 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t394, %"compiler/mir:Place" %t395, 1
  %t398 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t396, { i64, [15 x i64] } %t390, 2
  %t399 = getelementptr { i64, [21 x i64] }, ptr %t391, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t398, ptr %t399
  %t400 = load { i64, [21 x i64] }, ptr %t391
  %t402 = call ptr @__olang_scope_alloc_a(ptr %s4, i64 176, i64 8)
  store { i64, [21 x i64] } %t400, ptr %t402
  %t403 = load ptr, ptr %l201, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s4, ptr %t403, ptr %t402)
  br label %bb62
bb62:
  %t405 = load ptr, ptr %l0, !tbaa !29
  store ptr %t405, ptr %l210, !tbaa !29
  store i32 14, ptr %l211
  %t406 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t406, ptr %l212, !tbaa !23
  %t407 = load i32, ptr %l19, !tbaa !23
  %t409 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t407)
  store %"compiler/mir:Place" %t409, ptr %l214
  br label %bb63
bb63:
  store { i64, [4 x i64] } zeroinitializer, ptr %t410
  %t411 = getelementptr { i64, [4 x i64] }, ptr %t410, i32 0, i32 0
  store i64 1, ptr %t411
  %t412 = load %"compiler/mir:Place", ptr %l214
  %t413 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t412, 0
  %t414 = getelementptr { i64, [4 x i64] }, ptr %t410, i32 0, i32 1
  store { %"compiler/mir:Place" } %t413, ptr %t414
  %t415 = load { i64, [4 x i64] }, ptr %t410
  %t416 = load i32, ptr %l2, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t417
  %t418 = getelementptr { i64, [4 x i64] }, ptr %t417, i32 0, i32 0
  store i64 2, ptr %t418
  %t420 = insertvalue { i32, i64 } undef, i32 %t416, 0
  %t421 = insertvalue { i32, i64 } %t420, i64 0, 1
  %t422 = getelementptr { i64, [4 x i64] }, ptr %t417, i32 0, i32 1
  store { i32, i64 } %t421, ptr %t422
  %t423 = load { i64, [4 x i64] }, ptr %t417
  %t424 = mul i64 2, 40
  %t425 = call ptr @__olang_scope_alloc_zeroed(ptr %s4, i64 %t424)
  %t426 = insertvalue { i64, ptr } undef, i64 2, 0
  %t427 = insertvalue { i64, ptr } %t426, ptr %t425, 1
  store { i64, ptr } %t427, ptr %l218, !tbaa !27
  %t429 = getelementptr { i64, ptr }, ptr %l218, i32 0, i32 1
  %t430 = load ptr, ptr %t429, !tbaa !27
  %t431 = getelementptr { i64, [4 x i64] }, ptr %t430, i64 0
  store { i64, [4 x i64] } %t415, ptr %t431
  %t433 = getelementptr { i64, ptr }, ptr %l218, i32 0, i32 1
  %t434 = load ptr, ptr %t433, !tbaa !27
  %t435 = getelementptr { i64, [4 x i64] }, ptr %t434, i64 1
  store { i64, [4 x i64] } %t423, ptr %t435
  %t436 = load %"compiler/source:Span", ptr %l3
  %t437 = load ptr, ptr %l210, !tbaa !29
  %t438 = load i32, ptr %l211
  %t439 = load i32, ptr %l212, !tbaa !23
  %t440 = load { i64, ptr }, ptr %l218, !tbaa !27
  %t442 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s4, ptr %t437, i32 %t438, i32 %t439, { i64, ptr } %t440, %"compiler/source:Span" %t436)
  store { i64, [4 x i64] } %t442, ptr %l220
  br label %bb64
bb64:
  %t443 = load { i64, [4 x i64] }, ptr %l220
  store { i64, [4 x i64] } %t443, ptr %l21
  %t444 = load ptr, ptr %l0, !tbaa !29
  %t446 = getelementptr %"compiler/lower:lowering", ptr %t444, i32 0, i32 3
  %t448 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t446)
  store i32 %t448, ptr %l223
  br label %bb65
bb65:
  %t449 = load i32, ptr %l223, !tbaa !23
  store i32 %t449, ptr %l22, !tbaa !23
  %t450 = load ptr, ptr %l0, !tbaa !29
  %t452 = getelementptr %"compiler/lower:lowering", ptr %t450, i32 0, i32 3
  %t454 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t452)
  store i32 %t454, ptr %l226
  br label %bb66
bb66:
  %t455 = load i32, ptr %l226, !tbaa !23
  store i32 %t455, ptr %l23, !tbaa !23
  %t456 = load ptr, ptr %l0, !tbaa !29
  %t457 = load { i64, [4 x i64] }, ptr %l21
  %t458 = load i32, ptr %l22, !tbaa !23
  %t459 = load i32, ptr %l23, !tbaa !23
  store { i64, [8 x i64] } zeroinitializer, ptr %t460
  %t461 = getelementptr { i64, [8 x i64] }, ptr %t460, i32 0, i32 0
  store i64 2, ptr %t461
  %t463 = insertvalue { { i64, [4 x i64] }, i32, i32 } undef, { i64, [4 x i64] } %t457, 0
  %t465 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t463, i32 %t458, 1
  %t467 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t465, i32 %t459, 2
  %t468 = getelementptr { i64, [8 x i64] }, ptr %t460, i32 0, i32 1
  store { { i64, [4 x i64] }, i32, i32 } %t467, ptr %t468
  %t469 = load { i64, [8 x i64] }, ptr %t460
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t456, { i64, [8 x i64] } %t469)
  br label %bb67
bb67:
  %t472 = load ptr, ptr %l0, !tbaa !29
  %t473 = load i32, ptr %l22, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t472, i32 %t473)
  br label %bb68
bb68:
  %t476 = load ptr, ptr %l0, !tbaa !29
  store ptr %t476, ptr %l234, !tbaa !29
  %t477 = load ptr, ptr %l0, !tbaa !29
  %t478 = load i32, ptr %l19, !tbaa !23
  %t481 = call %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2eat(ptr %v0, ptr %s4, ptr %t477, i32 %t478)
  store %"compiler/lower:pl" %t481, ptr %l237
  br label %bb69
bb69:
  %t482 = load ptr, ptr %l5, !tbaa !29
  %t483 = load i32, ptr %l6, !tbaa !23
  %t486 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t482, i32 %t483)
  store i32 %t486, ptr %l240
  br label %bb70
bb70:
  %t487 = load %"compiler/source:Span", ptr %l3
  %t488 = load ptr, ptr %l234, !tbaa !29
  %t489 = load %"compiler/lower:pl", ptr %l237
  %t490 = load i32, ptr %l240, !tbaa !23
  %t492 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ehashAt(ptr %v0, ptr %s4, ptr %t488, %"compiler/lower:pl" %t489, i32 %t490, %"compiler/source:Span" %t487, i1 false)
  store { i64, [4 x i64] } %t492, ptr %l242
  br label %bb71
bb71:
  %t493 = load { i64, [4 x i64] }, ptr %l242
  store { i64, [4 x i64] } %t493, ptr %l24
  %t494 = load ptr, ptr %l0, !tbaa !29
  store ptr %t494, ptr %l243, !tbaa !29
  %t495 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t495, ptr %l244
  %t496 = load i32, ptr %l20, !tbaa !23
  %t498 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t496)
  store %"compiler/mir:Place" %t498, ptr %l246
  br label %bb72
bb72:
  %t499 = load { i64, [4 x i64] }, ptr %l24
  store { i64, [15 x i64] } zeroinitializer, ptr %t500
  %t501 = getelementptr { i64, [15 x i64] }, ptr %t500, i32 0, i32 0
  store i64 0, ptr %t501
  %t503 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t499, 0
  %t504 = getelementptr { i64, [15 x i64] }, ptr %t500, i32 0, i32 1
  store { { i64, [4 x i64] } } %t503, ptr %t504
  %t505 = load { i64, [15 x i64] }, ptr %t500
  store { i64, [21 x i64] } zeroinitializer, ptr %t506
  %t507 = getelementptr { i64, [21 x i64] }, ptr %t506, i32 0, i32 0
  store i64 0, ptr %t507
  %t508 = load %"compiler/source:Span", ptr %l244
  %t509 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t508, 0
  %t510 = load %"compiler/mir:Place", ptr %l246
  %t511 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t509, %"compiler/mir:Place" %t510, 1
  %t513 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t511, { i64, [15 x i64] } %t505, 2
  %t514 = getelementptr { i64, [21 x i64] }, ptr %t506, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t513, ptr %t514
  %t515 = load { i64, [21 x i64] }, ptr %t506
  %t517 = call ptr @__olang_scope_alloc_a(ptr %s4, i64 176, i64 8)
  store { i64, [21 x i64] } %t515, ptr %t517
  %t518 = load ptr, ptr %l243, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s4, ptr %t518, ptr %t517)
  br label %bb73
bb73:
  %t520 = load ptr, ptr %l0, !tbaa !29
  %t521 = load i32, ptr %l23, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2egoto(ptr %v0, ptr %t520, i32 %t521)
  br label %bb74
bb74:
  %t524 = load ptr, ptr %l0, !tbaa !29
  %t525 = load i32, ptr %l23, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t524, i32 %t525)
  br label %bb75
bb75:
  %t528 = load i32, ptr %l20, !tbaa !23
  %t530 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t528)
  store %"compiler/mir:Place" %t530, ptr %l256
  br label %bb76
bb76:
  store { i64, [4 x i64] } zeroinitializer, ptr %t531
  %t532 = getelementptr { i64, [4 x i64] }, ptr %t531, i32 0, i32 0
  store i64 1, ptr %t532
  %t533 = load %"compiler/mir:Place", ptr %l256
  %t534 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t533, 0
  %t535 = getelementptr { i64, [4 x i64] }, ptr %t531, i32 0, i32 1
  store { %"compiler/mir:Place" } %t534, ptr %t535
  %t536 = load { i64, [4 x i64] }, ptr %t531
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  store { i64, [4 x i64] } %t536, ptr %rv
  br label %ret
bb77:
  %t538 = load i1, ptr %l4, !tbaa !21
  %t540 = xor i1 %t538, true
  br i1 %t540, label %bb78, label %bb79
bb78:
  store %olang.scope zeroinitializer, ptr %s5
  %t542 = load ptr, ptr %l0, !tbaa !29
  store ptr %t542, ptr %l260, !tbaa !29
  store i32 2, ptr %l261
  %t543 = load i32, ptr %l2, !tbaa !23
  store i32 %t543, ptr %l262, !tbaa !23
  %t544 = load ptr, ptr %l0, !tbaa !29
  %t545 = load %"compiler/lower:pl", ptr %l1
  %t546 = load i32, ptr %l2, !tbaa !23
  %t547 = load %"compiler/source:Span", ptr %l3
  %t552 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2erefTo(ptr %v0, ptr %v1, ptr %t544, %"compiler/lower:pl" %t545, i32 %t546, %"compiler/source:Span" %t547)
  store { i64, [4 x i64] } %t552, ptr %l267
  br label %bb80
bb79:
  br label %bb82
bb80:
  %t553 = mul i64 1, 40
  %t554 = call ptr @__olang_scope_alloc_zeroed(ptr %s5, i64 %t553)
  %t555 = insertvalue { i64, ptr } undef, i64 1, 0
  %t556 = insertvalue { i64, ptr } %t555, ptr %t554, 1
  store { i64, ptr } %t556, ptr %l268, !tbaa !27
  %t557 = load { i64, [4 x i64] }, ptr %l267
  %t558 = getelementptr { i64, ptr }, ptr %l268, i32 0, i32 1
  %t559 = load ptr, ptr %t558, !tbaa !27
  %t560 = getelementptr { i64, [4 x i64] }, ptr %t559, i64 0
  store { i64, [4 x i64] } %t557, ptr %t560
  %t561 = mul i64 0, 16
  %t562 = call ptr @__olang_scope_alloc_zeroed(ptr %s5, i64 %t561)
  %t563 = insertvalue { i64, ptr } undef, i64 0, 0
  %t564 = insertvalue { i64, ptr } %t563, ptr %t562, 1
  %t565 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  %t566 = load %"compiler/source:Span", ptr %l3
  %t567 = load ptr, ptr %l260, !tbaa !29
  %t568 = load i32, ptr %l261
  %t569 = load i32, ptr %l262, !tbaa !23
  %t570 = load { i64, ptr }, ptr %l268, !tbaa !27
  %t574 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ehelperCall(ptr %v0, ptr %s5, ptr %s5, ptr %t567, i32 %t568, i32 %t569, { i64, ptr } %t570, { i64, ptr } %t564, i32 %t565, %"compiler/source:Span" %t566)
  store { i64, [4 x i64] } %t574, ptr %l272
  br label %bb81
bb81:
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  %t575 = load { i64, [4 x i64] }, ptr %l272
  store { i64, [4 x i64] } %t575, ptr %rv
  br label %ret
bb82:
  %t576 = load ptr, ptr %l0, !tbaa !29
  %t577 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  %t578 = load %"compiler/source:Span", ptr %l3
  %t582 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2etemp(ptr %v0, ptr %t576, i32 %t577, %"compiler/source:Span" %t578)
  store i32 %t582, ptr %l276
  br label %bb83
bb83:
  %t583 = load i32, ptr %l276, !tbaa !23
  store i32 %t583, ptr %l25, !tbaa !23
  %t584 = load ptr, ptr %l0, !tbaa !29
  store ptr %t584, ptr %l277, !tbaa !29
  %t585 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t585, ptr %l278
  %t586 = load i32, ptr %l25, !tbaa !23
  %t588 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t586)
  store %"compiler/mir:Place" %t588, ptr %l280
  br label %bb84
bb84:
  %t589 = load ptr, ptr %l0, !tbaa !29
  %t591 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2econstI64(ptr %v0, ptr %t589, i64 0)
  store { i64, [4 x i64] } %t591, ptr %l282
  br label %bb85
bb85:
  store { i64, [15 x i64] } zeroinitializer, ptr %t592
  %t593 = getelementptr { i64, [15 x i64] }, ptr %t592, i32 0, i32 0
  store i64 0, ptr %t593
  %t594 = load { i64, [4 x i64] }, ptr %l282
  %t595 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t594, 0
  %t596 = getelementptr { i64, [15 x i64] }, ptr %t592, i32 0, i32 1
  store { { i64, [4 x i64] } } %t595, ptr %t596
  %t597 = load { i64, [15 x i64] }, ptr %t592
  store { i64, [21 x i64] } zeroinitializer, ptr %t598
  %t599 = getelementptr { i64, [21 x i64] }, ptr %t598, i32 0, i32 0
  store i64 0, ptr %t599
  %t600 = load %"compiler/source:Span", ptr %l278
  %t601 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t600, 0
  %t602 = load %"compiler/mir:Place", ptr %l280
  %t603 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t601, %"compiler/mir:Place" %t602, 1
  %t605 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t603, { i64, [15 x i64] } %t597, 2
  %t606 = getelementptr { i64, [21 x i64] }, ptr %t598, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t605, ptr %t606
  %t607 = load { i64, [21 x i64] }, ptr %t598
  %t609 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t607, ptr %t609
  %t610 = load ptr, ptr %l277, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s0, ptr %t610, ptr %t609)
  br label %bb86
bb86:
  %t612 = load ptr, ptr %l0, !tbaa !29
  %t613 = load i32, ptr %l2, !tbaa !23
  %t616 = call { { i64, ptr }, i1 } @compiler_2flower_2ecompiler_2flower_3alowering_2epartsOf(ptr %v0, ptr %s0, ptr %t612, i32 %t613)
  store { { i64, ptr }, i1 } %t616, ptr %l288
  br label %bb87
bb87:
  %t617 = load { { i64, ptr }, i1 }, ptr %l288
  store { { i64, ptr }, i1 } %t617, ptr %l26
  %t618 = getelementptr { { i64, ptr }, i1 }, ptr %l26, i32 0, i32 0
  %t619 = load { i64, ptr }, ptr %t618, !tbaa !27
  store { i64, ptr } %t619, ptr %l289, !tbaa !27
  %t620 = load { i64, ptr }, ptr %l289, !tbaa !27
  %t621 = extractvalue { i64, ptr } %t620, 0
  store i64 %t621, ptr %l290, !tbaa !24
  %t622 = load i64, ptr %l290, !tbaa !24
  %t623 = mul i64 %t622, 4
  %t624 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t623)
  %t625 = insertvalue { i64, ptr } undef, i64 %t622, 0
  %t626 = insertvalue { i64, ptr } %t625, ptr %t624, 1
  store { i64, ptr } %t626, ptr %l291, !tbaa !27
  %t627 = getelementptr { i64, ptr }, ptr %l291, i32 0, i32 1
  %t628 = load ptr, ptr %t627, !tbaa !27
  %t629 = getelementptr { i64, ptr }, ptr %l289, i32 0, i32 1
  %t630 = load ptr, ptr %t629, !tbaa !27
  %t631 = load i64, ptr %l290, !tbaa !24
  %t632 = mul i64 %t631, 4
  call void @llvm.memmove.p0.p0.i64(ptr %t628, ptr %t630, i64 %t632, i1 false)
  %t633 = load { i64, ptr }, ptr %l291, !tbaa !27
  store { i64, ptr } %t633, ptr %l27, !tbaa !27
  %t634 = getelementptr { { i64, ptr }, i1 }, ptr %l26, i32 0, i32 1
  %t635 = load i1, ptr %t634, !tbaa !21
  store i1 %t635, ptr %l28, !tbaa !21
  %t637 = load ptr, ptr %l0, !tbaa !29
  %t638 = load i32, ptr %l2, !tbaa !23
  %t641 = call { { i64, ptr }, i1 } @compiler_2flower_2ecompiler_2flower_3alowering_2ecasesOf(ptr %v0, ptr %s0, ptr %t637, i32 %t638)
  store { { i64, ptr }, i1 } %t641, ptr %l295
  br label %bb88
bb88:
  %t642 = load { { i64, ptr }, i1 }, ptr %l295
  store { { i64, ptr }, i1 } %t642, ptr %l29
  %t643 = getelementptr { { i64, ptr }, i1 }, ptr %l29, i32 0, i32 0
  %t644 = load { i64, ptr }, ptr %t643, !tbaa !27
  store { i64, ptr } %t644, ptr %l296, !tbaa !27
  %t645 = load { i64, ptr }, ptr %l296, !tbaa !27
  %t646 = extractvalue { i64, ptr } %t645, 0
  store i64 %t646, ptr %l297, !tbaa !24
  %t647 = load i64, ptr %l297, !tbaa !24
  %t648 = mul i64 %t647, 4
  %t649 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t648)
  %t650 = insertvalue { i64, ptr } undef, i64 %t647, 0
  %t651 = insertvalue { i64, ptr } %t650, ptr %t649, 1
  store { i64, ptr } %t651, ptr %l298, !tbaa !27
  %t652 = getelementptr { i64, ptr }, ptr %l298, i32 0, i32 1
  %t653 = load ptr, ptr %t652, !tbaa !27
  %t654 = getelementptr { i64, ptr }, ptr %l296, i32 0, i32 1
  %t655 = load ptr, ptr %t654, !tbaa !27
  %t656 = load i64, ptr %l297, !tbaa !24
  %t657 = mul i64 %t656, 4
  call void @llvm.memmove.p0.p0.i64(ptr %t653, ptr %t655, i64 %t657, i1 false)
  %t658 = load { i64, ptr }, ptr %l298, !tbaa !27
  store { i64, ptr } %t658, ptr %l30, !tbaa !27
  %t659 = getelementptr { { i64, ptr }, i1 }, ptr %l29, i32 0, i32 1
  %t660 = load i1, ptr %t659, !tbaa !21
  store i1 %t660, ptr %l31, !tbaa !21
  %t662 = load i1, ptr %l28, !tbaa !21
  br i1 %t662, label %bb89, label %bb90
bb89:
  store i64 0, ptr %l32, !tbaa !24
  %t664 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t666 = extractvalue { i64, ptr } %t664, 0
  store i64 %t666, ptr %l33, !tbaa !24
  store i64 1, ptr %l34, !tbaa !24
  %t668 = load i64, ptr %l33, !tbaa !24
  %t669 = load i64, ptr %l32, !tbaa !24
  %t672 = icmp sgt i64 %t668, %t669
  br i1 %t672, label %bb91, label %bb92
bb90:
  %t674 = load i1, ptr %l31, !tbaa !21
  br i1 %t674, label %bb106, label %bb107
bb91:
  %t676 = load i64, ptr %l34, !tbaa !24
  %t678 = icmp sgt i64 %t676, 0
  br i1 %t678, label %bb93, label %bb94
bb92:
  store i64 0, ptr %l306, !tbaa !24
  br label %bb96
bb93:
  %t680 = load i64, ptr %l33, !tbaa !24
  %t681 = load i64, ptr %l32, !tbaa !24
  %t684 = sub i64 %t680, %t681
  %t685 = load i64, ptr %l34, !tbaa !24
  %t688 = add i64 %t684, %t685
  %t690 = sub i64 %t688, 1
  %t691 = load i64, ptr %l34, !tbaa !24
  %t694 = sdiv i64 %t690, %t691
  store i64 %t694, ptr %l309, !tbaa !24
  br label %bb95
bb94:
  store i64 0, ptr %l309, !tbaa !24
  br label %bb95
bb95:
  %t696 = load i64, ptr %l309, !tbaa !24
  store i64 %t696, ptr %l306, !tbaa !24
  br label %bb96
bb96:
  %t697 = load i64, ptr %l306, !tbaa !24
  store i64 %t697, ptr %l35, !tbaa !24
  store i64 0, ptr %l36, !tbaa !24
  br label %bb97
bb97:
  store %olang.scope zeroinitializer, ptr %s8
  %t698 = load i64, ptr %l36, !tbaa !24
  %t699 = load i64, ptr %l35, !tbaa !24
  %t702 = icmp slt i64 %t698, %t699
  %t704 = xor i1 %t702, true
  br i1 %t704, label %bb98, label %bb99
bb98:
  call void @__olang_scope_close(ptr %s8)
  br label %bb105
bb99:
  br label %bb100
bb100:
  %t706 = load i64, ptr %l32, !tbaa !24
  %t707 = load i64, ptr %l36, !tbaa !24
  %t708 = load i64, ptr %l34, !tbaa !24
  %t711 = mul i64 %t707, %t708
  %t714 = add i64 %t706, %t711
  store i64 %t714, ptr %l37, !tbaa !24
  %t716 = load ptr, ptr %l0, !tbaa !29
  store ptr %t716, ptr %l327, !tbaa !29
  %t717 = load i32, ptr %l25, !tbaa !23
  store i32 %t717, ptr %l328, !tbaa !23
  %t718 = load ptr, ptr %l0, !tbaa !29
  store ptr %t718, ptr %l329, !tbaa !29
  %t719 = load ptr, ptr %l0, !tbaa !29
  %t720 = load %"compiler/lower:pl", ptr %l1
  %t721 = load i64, ptr %l37, !tbaa !24
  store { i64, [1 x i64] } zeroinitializer, ptr %t722
  %t723 = getelementptr { i64, [1 x i64] }, ptr %t722, i32 0, i32 0
  store i64 0, ptr %t723
  %t725 = insertvalue { i64 } undef, i64 %t721, 0
  %t726 = getelementptr { i64, [1 x i64] }, ptr %t722, i32 0, i32 1
  store { i64 } %t725, ptr %t726
  %t727 = load { i64, [1 x i64] }, ptr %t722
  %t731 = call %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2ewith(ptr %v0, ptr %v1, ptr %s8, ptr %t719, %"compiler/lower:pl" %t720, { i64, [1 x i64] } %t727)
  store %"compiler/lower:pl" %t731, ptr %l334
  br label %bb101
bb101:
  %t732 = load i64, ptr %l37, !tbaa !24
  %t734 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t735 = load ptr, ptr %t734, !tbaa !27
  %t736 = getelementptr i32, ptr %t735, i64 %t732
  %t737 = load i32, ptr %t736, !tbaa !33
  %t738 = load %"compiler/source:Span", ptr %l3
  %t739 = load ptr, ptr %l329, !tbaa !29
  %t740 = load %"compiler/lower:pl", ptr %l334
  %t743 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ehashAt(ptr %v0, ptr %s8, ptr %t739, %"compiler/lower:pl" %t740, i32 %t737, %"compiler/source:Span" %t738, i1 false)
  store { i64, [4 x i64] } %t743, ptr %l338
  br label %bb102
bb102:
  %t744 = load %"compiler/source:Span", ptr %l3
  %t745 = load ptr, ptr %l327, !tbaa !29
  %t746 = load i32, ptr %l328, !tbaa !23
  %t747 = load { i64, [4 x i64] }, ptr %l338
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2ecombine(ptr %v0, ptr %t745, i32 %t746, { i64, [4 x i64] } %t747, %"compiler/source:Span" %t744)
  br label %bb103
bb103:
  call void @__olang_scope_close(ptr %s8)
  br label %bb104
bb104:
  %t749 = load i64, ptr %l36, !tbaa !24
  %t751 = add i64 %t749, 1
  store i64 %t751, ptr %l36, !tbaa !24
  br label %bb97
bb105:
  br label %bb124
bb106:
  store %olang.scope zeroinitializer, ptr %s11
  %t753 = load ptr, ptr %l0, !tbaa !29
  store ptr %t753, ptr %l343, !tbaa !29
  %t754 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  store i32 %t754, ptr %l344, !tbaa !23
  %t755 = load ptr, ptr %l0, !tbaa !29
  %t756 = load %"compiler/lower:pl", ptr %l1
  %t759 = call %"compiler/mir:Place" @compiler_2flower_2ecompiler_2flower_3alowering_2emk(ptr %v0, ptr %v1, ptr %t755, %"compiler/lower:pl" %t756)
  store %"compiler/mir:Place" %t759, ptr %l347
  br label %bb108
bb107:
  %t760 = load ptr, ptr %l0, !tbaa !29
  %t761 = load i32, ptr %l2, !tbaa !23
  %t764 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2earrayOf(ptr %v0, ptr %t760, i32 %t761)
  store i32 %t764, ptr %l369
  br label %bb113
bb108:
  store { i64, [15 x i64] } zeroinitializer, ptr %t765
  %t766 = getelementptr { i64, [15 x i64] }, ptr %t765, i32 0, i32 0
  store i64 5, ptr %t766
  %t767 = load %"compiler/mir:Place", ptr %l347
  %t768 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t767, 0
  %t769 = getelementptr { i64, [15 x i64] }, ptr %t765, i32 0, i32 1
  store { %"compiler/mir:Place" } %t768, ptr %t769
  %t770 = load { i64, [15 x i64] }, ptr %t765
  %t771 = load %"compiler/source:Span", ptr %l3
  %t772 = load ptr, ptr %l343, !tbaa !29
  %t773 = load i32, ptr %l344, !tbaa !23
  %t776 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %t772, i32 %t773, { i64, [15 x i64] } %t770, %"compiler/source:Span" %t771)
  store { i64, [4 x i64] } %t776, ptr %l350
  br label %bb109
bb109:
  %t777 = load { i64, [4 x i64] }, ptr %l350
  store { i64, [4 x i64] } %t777, ptr %l38
  %t778 = load ptr, ptr %l0, !tbaa !29
  store ptr %t778, ptr %l351, !tbaa !29
  %t779 = load i32, ptr %l25, !tbaa !23
  store i32 %t779, ptr %l352, !tbaa !23
  %t780 = load ptr, ptr %l0, !tbaa !29
  %t781 = load { i64, [4 x i64] }, ptr %l38
  %t782 = load %"compiler/source:Span", ptr %l3
  %t786 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2emix(ptr %v0, ptr %t780, { i64, [4 x i64] } %t781, %"compiler/source:Span" %t782)
  store { i64, [4 x i64] } %t786, ptr %l356
  br label %bb110
bb110:
  %t787 = load %"compiler/source:Span", ptr %l3
  %t788 = load ptr, ptr %l351, !tbaa !29
  %t789 = load i32, ptr %l352, !tbaa !23
  %t790 = load { i64, [4 x i64] }, ptr %l356
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2ecombine(ptr %v0, ptr %t788, i32 %t789, { i64, [4 x i64] } %t790, %"compiler/source:Span" %t787)
  br label %bb111
bb111:
  %t792 = load ptr, ptr %l0, !tbaa !29
  %t793 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t794 = load { i64, [4 x i64] }, ptr %l38
  %t795 = load %"compiler/source:Span", ptr %l3
  %t796 = load ptr, ptr %l0, !tbaa !29
  %t797 = load i32, ptr %l25, !tbaa !23
  %t798 = load %"compiler/lower:pl", ptr %l1
  %t799 = load %"compiler/source:Span", ptr %l3
  %t800 = getelementptr { ptr, i32, %"compiler/lower:pl", %"compiler/source:Span", ptr, ptr }, ptr null, i32 1
  %t801 = ptrtoint ptr %t800 to i64
  %t803 = getelementptr { ptr, i32, %"compiler/lower:pl", %"compiler/source:Span", ptr, ptr }, ptr %t802, i32 0, i32 0
  store ptr %t796, ptr %t803, !tbaa !28
  %t805 = getelementptr { ptr, i32, %"compiler/lower:pl", %"compiler/source:Span", ptr, ptr }, ptr %t802, i32 0, i32 1
  store i32 %t797, ptr %t805, !tbaa !28
  %t807 = getelementptr { ptr, i32, %"compiler/lower:pl", %"compiler/source:Span", ptr, ptr }, ptr %t802, i32 0, i32 2
  store %"compiler/lower:pl" %t798, ptr %t807, !tbaa !28
  %t809 = getelementptr { ptr, i32, %"compiler/lower:pl", %"compiler/source:Span", ptr, ptr }, ptr %t802, i32 0, i32 3
  store %"compiler/source:Span" %t799, ptr %t809, !tbaa !28
  call void @__olang_scope_escape(ptr %v0)
  %t811 = getelementptr { ptr, i32, %"compiler/lower:pl", %"compiler/source:Span", ptr, ptr }, ptr %t802, i32 0, i32 4
  store ptr %v0, ptr %t811, !tbaa !28
  call void @__olang_scope_escape(ptr %v1)
  %t812 = getelementptr { ptr, i32, %"compiler/lower:pl", %"compiler/source:Span", ptr, ptr }, ptr %t802, i32 0, i32 5
  store ptr %v1, ptr %t812, !tbaa !28
  %t813 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_11, 0
  %t814 = insertvalue { ptr, ptr } %t813, ptr %t802, 1
  %t820 = extractvalue { ptr, ptr } %t814, 0
  %t821 = extractvalue { ptr, ptr } %t814, 1
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2epayloads(ptr %v0, ptr %s0, ptr %s11, ptr %t792, { i64, ptr } %t793, { i64, [4 x i64] } %t794, %"compiler/source:Span" %t795, ptr %t820, ptr %t821)
  br label %bb112
bb112:
  call void @__olang_scope_close(ptr %s11)
  br label %bb123
bb113:
  %t822 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t823 = load i32, ptr %l369, !tbaa !23
  %t825 = icmp ne i32 %t823, %t822
  br i1 %t825, label %bb114, label %bb115
bb114:
  store %olang.scope zeroinitializer, ptr %s13
  %t827 = load ptr, ptr %l5, !tbaa !29
  store ptr %t827, ptr %l372, !tbaa !29
  %t828 = load ptr, ptr %l0, !tbaa !29
  %t829 = load i32, ptr %l2, !tbaa !23
  %t832 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2earrayOf(ptr %v0, ptr %t828, i32 %t829)
  store i32 %t832, ptr %l375
  br label %bb116
bb115:
  store %olang.scope zeroinitializer, ptr %s14
  %t833 = load ptr, ptr %l0, !tbaa !29
  %t834 = load %"compiler/source:Span", ptr %l3
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2egap(ptr %v0, ptr %s14, ptr %t833, %"compiler/source:Span" %t834, { i64, ptr } { i64 38, ptr getelementptr inbounds (<{ i64, [38 x i8] }>, ptr @.d12, i32 0, i32 1) })
  br label %bb121
bb116:
  %t837 = load ptr, ptr %l372, !tbaa !29
  %t838 = load i32, ptr %l375, !tbaa !23
  %t839 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t837, i32 %t838)
  store i32 %t839, ptr %l376
  br label %bb117
bb117:
  %t840 = load i32, ptr %l376, !tbaa !23
  store i32 %t840, ptr %l39, !tbaa !23
  %t841 = load ptr, ptr %l0, !tbaa !29
  store ptr %t841, ptr %l377, !tbaa !29
  store i32 22, ptr %l378
  %t842 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  store i32 %t842, ptr %l379, !tbaa !23
  %t843 = load ptr, ptr %l0, !tbaa !29
  %t844 = load %"compiler/lower:pl", ptr %l1
  %t847 = call %"compiler/mir:Place" @compiler_2flower_2ecompiler_2flower_3alowering_2emk(ptr %v0, ptr %v1, ptr %t843, %"compiler/lower:pl" %t844)
  store %"compiler/mir:Place" %t847, ptr %l382
  br label %bb118
bb118:
  store { i64, [4 x i64] } zeroinitializer, ptr %t848
  %t849 = getelementptr { i64, [4 x i64] }, ptr %t848, i32 0, i32 0
  store i64 1, ptr %t849
  %t850 = load %"compiler/mir:Place", ptr %l382
  %t851 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t850, 0
  %t852 = getelementptr { i64, [4 x i64] }, ptr %t848, i32 0, i32 1
  store { %"compiler/mir:Place" } %t851, ptr %t852
  %t853 = load { i64, [4 x i64] }, ptr %t848
  %t854 = mul i64 1, 40
  %t855 = call ptr @__olang_scope_alloc_zeroed(ptr %s13, i64 %t854)
  %t856 = insertvalue { i64, ptr } undef, i64 1, 0
  %t857 = insertvalue { i64, ptr } %t856, ptr %t855, 1
  store { i64, ptr } %t857, ptr %l384, !tbaa !27
  %t859 = getelementptr { i64, ptr }, ptr %l384, i32 0, i32 1
  %t860 = load ptr, ptr %t859, !tbaa !27
  %t861 = getelementptr { i64, [4 x i64] }, ptr %t860, i64 0
  store { i64, [4 x i64] } %t853, ptr %t861
  %t862 = load %"compiler/source:Span", ptr %l3
  %t863 = load ptr, ptr %l377, !tbaa !29
  %t864 = load i32, ptr %l378
  %t865 = load i32, ptr %l379, !tbaa !23
  %t866 = load { i64, ptr }, ptr %l384, !tbaa !27
  %t868 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s13, ptr %t863, i32 %t864, i32 %t865, { i64, ptr } %t866, %"compiler/source:Span" %t862)
  store { i64, [4 x i64] } %t868, ptr %l386
  br label %bb119
bb119:
  %t869 = load { i64, [4 x i64] }, ptr %l386
  %t870 = load ptr, ptr %l0, !tbaa !29
  %t872 = load %"compiler/source:Span", ptr %l3
  %t873 = load ptr, ptr %l0, !tbaa !29
  %t874 = load i32, ptr %l25, !tbaa !23
  %t875 = load %"compiler/lower:pl", ptr %l1
  %t876 = load i32, ptr %l39, !tbaa !23
  %t877 = load %"compiler/source:Span", ptr %l3
  %t878 = getelementptr { ptr, i32, %"compiler/lower:pl", i32, %"compiler/source:Span", ptr, ptr }, ptr null, i32 1
  %t879 = ptrtoint ptr %t878 to i64
  %t881 = getelementptr { ptr, i32, %"compiler/lower:pl", i32, %"compiler/source:Span", ptr, ptr }, ptr %t880, i32 0, i32 0
  store ptr %t873, ptr %t881, !tbaa !28
  %t883 = getelementptr { ptr, i32, %"compiler/lower:pl", i32, %"compiler/source:Span", ptr, ptr }, ptr %t880, i32 0, i32 1
  store i32 %t874, ptr %t883, !tbaa !28
  %t885 = getelementptr { ptr, i32, %"compiler/lower:pl", i32, %"compiler/source:Span", ptr, ptr }, ptr %t880, i32 0, i32 2
  store %"compiler/lower:pl" %t875, ptr %t885, !tbaa !28
  %t887 = getelementptr { ptr, i32, %"compiler/lower:pl", i32, %"compiler/source:Span", ptr, ptr }, ptr %t880, i32 0, i32 3
  store i32 %t876, ptr %t887, !tbaa !28
  %t889 = getelementptr { ptr, i32, %"compiler/lower:pl", i32, %"compiler/source:Span", ptr, ptr }, ptr %t880, i32 0, i32 4
  store %"compiler/source:Span" %t877, ptr %t889, !tbaa !28
  call void @__olang_scope_escape(ptr %v0)
  %t891 = getelementptr { ptr, i32, %"compiler/lower:pl", i32, %"compiler/source:Span", ptr, ptr }, ptr %t880, i32 0, i32 5
  store ptr %v0, ptr %t891, !tbaa !28
  call void @__olang_scope_escape(ptr %v1)
  %t892 = getelementptr { ptr, i32, %"compiler/lower:pl", i32, %"compiler/source:Span", ptr, ptr }, ptr %t880, i32 0, i32 6
  store ptr %v1, ptr %t892, !tbaa !28
  %t893 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_13, 0
  %t894 = insertvalue { ptr, ptr } %t893, ptr %t880, 1
  %t899 = extractvalue { ptr, ptr } %t894, 0
  %t900 = extractvalue { ptr, ptr } %t894, 1
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eeachIndex(ptr %v0, ptr %s13, ptr %t870, { i64, [4 x i64] } %t869, %"compiler/source:Span" %t872, ptr %t899, ptr %t900)
  br label %bb120
bb120:
  call void @__olang_scope_close(ptr %s13)
  br label %bb122
bb121:
  call void @__olang_scope_close(ptr %s14)
  br label %bb122
bb122:
  br label %bb123
bb123:
  br label %bb124
bb124:
  %t901 = load i32, ptr %l25, !tbaa !23
  %t903 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t901)
  store %"compiler/mir:Place" %t903, ptr %l399
  br label %bb125
bb125:
  store { i64, [4 x i64] } zeroinitializer, ptr %t904
  %t905 = getelementptr { i64, [4 x i64] }, ptr %t904, i32 0, i32 0
  store i64 1, ptr %t905
  %t906 = load %"compiler/mir:Place", ptr %l399
  %t907 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t906, 0
  %t908 = getelementptr { i64, [4 x i64] }, ptr %t904, i32 0, i32 1
  store { %"compiler/mir:Place" } %t907, ptr %t908
  %t909 = load { i64, [4 x i64] }, ptr %t904
  call void @__olang_scope_close(ptr %s0)
  store { i64, [4 x i64] } %t909, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local i32 @compiler_2flower_2ecompiler_2flower_3alowering_2ei64(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  store i32 %t1, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eisChar(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l16 = alloca i64
  %l19 = alloca i64
  %l37 = alloca ptr
  %l38 = alloca i32
  %l41 = alloca i32
  %l42 = alloca i1
  %l46 = alloca i32
  %l49 = alloca i1
  %l50 = alloca ptr
  %l53 = alloca i32
  %l54 = alloca i32
  %l57 = alloca i1
  %l60 = alloca i1
  %l65 = alloca i32
  %s2 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  store i32 %a1, ptr %l3, !tbaa !23
  store i64 0, ptr %l4, !tbaa !24
  store i64 16, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t8 = load i64, ptr %l5, !tbaa !24
  %t9 = load i64, ptr %l4, !tbaa !24
  %t12 = icmp sgt i64 %t8, %t9
  br i1 %t12, label %bb1, label %bb2
bb1:
  %t14 = load i64, ptr %l6, !tbaa !24
  %t16 = icmp sgt i64 %t14, 0
  br i1 %t16, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l16, !tbaa !24
  br label %bb6
bb3:
  %t18 = load i64, ptr %l5, !tbaa !24
  %t19 = load i64, ptr %l4, !tbaa !24
  %t22 = sub i64 %t18, %t19
  %t23 = load i64, ptr %l6, !tbaa !24
  %t26 = add i64 %t22, %t23
  %t28 = sub i64 %t26, 1
  %t29 = load i64, ptr %l6, !tbaa !24
  %t32 = sdiv i64 %t28, %t29
  store i64 %t32, ptr %l19, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l19, !tbaa !24
  br label %bb5
bb5:
  %t34 = load i64, ptr %l19, !tbaa !24
  store i64 %t34, ptr %l16, !tbaa !24
  br label %bb6
bb6:
  %t35 = load i64, ptr %l16, !tbaa !24
  store i64 %t35, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t36 = load i64, ptr %l8, !tbaa !24
  %t37 = load i64, ptr %l7, !tbaa !24
  %t40 = icmp slt i64 %t36, %t37
  %t42 = xor i1 %t40, true
  br i1 %t42, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb31
bb9:
  br label %bb10
bb10:
  %t44 = load i64, ptr %l4, !tbaa !24
  %t45 = load i64, ptr %l8, !tbaa !24
  %t46 = load i64, ptr %l6, !tbaa !24
  %t49 = mul i64 %t45, %t46
  %t52 = add i64 %t44, %t49
  store i64 %t52, ptr %l9, !tbaa !24
  %t54 = load ptr, ptr %l2, !tbaa !29
  store ptr %t54, ptr %l37, !tbaa !29
  %t55 = load i32, ptr %l3, !tbaa !23
  store i32 %t55, ptr %l38, !tbaa !23
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/lower:lowering", ptr %t56, i32 0, i32 0
  %t59 = load ptr, ptr %t58, !tbaa !29
  %t61 = call i32 @compiler_2flower_2ecompiler_2flower_3aLowerer_2echar(ptr %v0, ptr %t59)
  store i32 %t61, ptr %l41
  br label %bb11
bb11:
  %t62 = load ptr, ptr %l37, !tbaa !29
  %t63 = load i32, ptr %l38, !tbaa !23
  %t64 = load i32, ptr %l41, !tbaa !23
  %t65 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t62, i32 %t63, i32 %t64)
  store i1 %t65, ptr %l42
  br label %bb12
bb12:
  %t66 = load i1, ptr %l42, !tbaa !21
  br i1 %t66, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s2)
  store i1 true, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  %t68 = load ptr, ptr %l2, !tbaa !29
  %t69 = load i32, ptr %l3, !tbaa !23
  %t72 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t68, i32 %t69)
  store i32 %t72, ptr %l46
  br label %bb16
bb16:
  %t73 = load i32, ptr %l46
  %t75 = trunc i64 18 to i32
  %t76 = icmp eq i32 %t73, %t75
  br i1 %t76, label %bb17, label %bb18
bb17:
  %t78 = load ptr, ptr %l2, !tbaa !29
  store ptr %t78, ptr %l50, !tbaa !29
  %t79 = load ptr, ptr %l2, !tbaa !29
  %t80 = load i32, ptr %l3, !tbaa !23
  %t83 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t79, i32 %t80)
  store i32 %t83, ptr %l53
  br label %bb19
bb18:
  store i1 false, ptr %l49, !tbaa !21
  br label %bb21
bb19:
  %t84 = load ptr, ptr %l50, !tbaa !29
  %t85 = load i32, ptr %l53, !tbaa !23
  %t86 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t84, i32 %t85)
  store i32 %t86, ptr %l54
  br label %bb20
bb20:
  %t87 = load i32, ptr %l54
  %t89 = trunc i64 4 to i32
  %t90 = icmp eq i32 %t87, %t89
  store i1 %t90, ptr %l49, !tbaa !21
  br label %bb21
bb21:
  %t92 = load i1, ptr %l49, !tbaa !21
  br i1 %t92, label %bb22, label %bb23
bb22:
  %t93 = load ptr, ptr %l2, !tbaa !29
  %t94 = load i32, ptr %l3, !tbaa !23
  %t97 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %t93, i32 %t94)
  store i1 %t97, ptr %l60
  br label %bb24
bb23:
  store i1 false, ptr %l57, !tbaa !21
  br label %bb25
bb24:
  %t98 = load i1, ptr %l60, !tbaa !21
  store i1 %t98, ptr %l57, !tbaa !21
  br label %bb25
bb25:
  %t99 = load i1, ptr %l57, !tbaa !21
  %t100 = xor i1 %t99, true
  br i1 %t100, label %bb26, label %bb27
bb26:
  call void @__olang_scope_close(ptr %s2)
  store i1 false, ptr %rv
  br label %ret
bb27:
  br label %bb28
bb28:
  %t103 = load ptr, ptr %l2, !tbaa !29
  %t104 = load i32, ptr %l3, !tbaa !23
  %t107 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %t103, i32 %t104)
  store i32 %t107, ptr %l65
  br label %bb29
bb29:
  %t108 = load i32, ptr %l65, !tbaa !23
  store i32 %t108, ptr %l3, !tbaa !23
  call void @__olang_scope_close(ptr %s2)
  br label %bb30
bb30:
  %t109 = load i64, ptr %l8, !tbaa !24
  %t111 = add i64 %t109, 1
  store i64 %t111, ptr %l8, !tbaa !24
  br label %bb7
bb31:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eisText(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l8 = alloca i32
  %l11 = alloca i1
  %l12 = alloca ptr
  %l15 = alloca i32
  %l16 = alloca i32
  %l19 = alloca i32
  %l24 = alloca ptr
  %l27 = alloca i32
  %l30 = alloca i32
  %l31 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t6, i32 %a1)
  store i32 %t10, ptr %l8
  br label %bb1
bb1:
  %t11 = load i32, ptr %l8, !tbaa !23
  store i32 %t11, ptr %l3, !tbaa !23
  %t12 = load ptr, ptr %l2, !tbaa !29
  %t13 = load i32, ptr %l3, !tbaa !23
  %t16 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t12, i32 %t13)
  store i1 %t16, ptr %l11
  br label %bb2
bb2:
  %t17 = load i1, ptr %l11, !tbaa !21
  br i1 %t17, label %bb3, label %bb4
bb3:
  %t18 = load ptr, ptr %l2, !tbaa !29
  store ptr %t18, ptr %l12, !tbaa !29
  %t19 = load ptr, ptr %l2, !tbaa !29
  %t20 = load i32, ptr %l3, !tbaa !23
  %t23 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t19, i32 %t20)
  store i32 %t23, ptr %l15
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t24 = load ptr, ptr %l12, !tbaa !29
  %t25 = load i32, ptr %l15, !tbaa !23
  %t26 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t24, i32 %t25)
  store i32 %t26, ptr %l16
  br label %bb6
bb6:
  %t27 = load i32, ptr %l16, !tbaa !23
  store i32 %t27, ptr %l3, !tbaa !23
  br label %bb7
bb7:
  %t28 = load ptr, ptr %l2, !tbaa !29
  %t29 = load i32, ptr %l3, !tbaa !23
  %t32 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t28, i32 %t29)
  store i32 %t32, ptr %l19
  br label %bb8
bb8:
  %t33 = load i32, ptr %l19
  %t35 = trunc i64 19 to i32
  %t36 = icmp eq i32 %t33, %t35
  %t38 = xor i1 %t36, true
  br i1 %t38, label %bb9, label %bb10
bb9:
  store i1 false, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t41 = load ptr, ptr %l2, !tbaa !29
  store ptr %t41, ptr %l24, !tbaa !29
  %t42 = load ptr, ptr %l2, !tbaa !29
  %t43 = load i32, ptr %l3, !tbaa !23
  %t46 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t42, i32 %t43)
  store i32 %t46, ptr %l27
  br label %bb12
bb12:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/lower:lowering", ptr %t47, i32 0, i32 0
  %t50 = load ptr, ptr %t49, !tbaa !29
  %t52 = call i32 @compiler_2flower_2ecompiler_2flower_3aLowerer_2echar(ptr %v0, ptr %t50)
  store i32 %t52, ptr %l30
  br label %bb13
bb13:
  %t53 = load ptr, ptr %l24, !tbaa !29
  %t54 = load i32, ptr %l27, !tbaa !23
  %t55 = load i32, ptr %l30, !tbaa !23
  %t56 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t53, i32 %t54, i32 %t55)
  store i1 %t56, ptr %l31
  br label %bb14
bb14:
  %t57 = load i1, ptr %l31, !tbaa !21
  store i1 %t57, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2flower_2ecompiler_2flower_3alowering_2eitems(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %lp3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l13 = alloca { i64, ptr }
  %l15 = alloca i64
  %l24 = alloca i64
  %l27 = alloca i64
  %l46 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/lower:lowering", ptr %a0, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t8 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t4, i32 %a1)
  store { i64, ptr } %t8, ptr %l13
  br label %bb1
bb1:
  %t9 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t9, ptr %l2, !tbaa !27
  %t10 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l15, !tbaa !24
  %t13 = load i64, ptr %l15, !tbaa !24
  %t14 = icmp sge i64 %t13, 0
  br i1 %t14, label %bb2, label %bb3
bb2:
  %t16 = load i64, ptr %l15, !tbaa !24
  %t17 = icmp sle i64 %t16, 2305843009213693951
  br i1 %t17, label %bb4, label %bb5
bb3:
  call void @__olang_check_failed(ptr @olang_loc_fe6f132f471090d8_e27fa787bcbe9484)
  unreachable
bb4:
  %t19 = load i64, ptr %l15, !tbaa !24
  %t20 = mul i64 %t19, 4
  %t21 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t20)
  %t22 = insertvalue { i64, ptr } undef, i64 %t19, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t21, 1
  %t24 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t24, ptr %lp3
  %t26 = load ptr, ptr %lp3
  store { i64, ptr } %t23, ptr %t26, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t27 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t27, 0
  store i64 %t29, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t31 = load i64, ptr %l5, !tbaa !24
  %t32 = load i64, ptr %l4, !tbaa !24
  %t35 = icmp sgt i64 %t31, %t32
  br i1 %t35, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_fe6f132f471090d8_e27fa787bcbe9484)
  unreachable
bb6:
  %t37 = load i64, ptr %l6, !tbaa !24
  %t39 = icmp sgt i64 %t37, 0
  br i1 %t39, label %bb8, label %bb9
bb7:
  store i64 0, ptr %l24, !tbaa !24
  br label %bb11
bb8:
  %t41 = load i64, ptr %l5, !tbaa !24
  %t42 = load i64, ptr %l4, !tbaa !24
  %t45 = sub i64 %t41, %t42
  %t46 = load i64, ptr %l6, !tbaa !24
  %t49 = add i64 %t45, %t46
  %t51 = sub i64 %t49, 1
  %t52 = load i64, ptr %l6, !tbaa !24
  %t55 = sdiv i64 %t51, %t52
  store i64 %t55, ptr %l27, !tbaa !24
  br label %bb10
bb9:
  store i64 0, ptr %l27, !tbaa !24
  br label %bb10
bb10:
  %t57 = load i64, ptr %l27, !tbaa !24
  store i64 %t57, ptr %l24, !tbaa !24
  br label %bb11
bb11:
  %t58 = load i64, ptr %l24, !tbaa !24
  store i64 %t58, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb12
bb12:
  store %olang.scope zeroinitializer, ptr %s2
  %t59 = load i64, ptr %l8, !tbaa !24
  %t60 = load i64, ptr %l7, !tbaa !24
  %t63 = icmp slt i64 %t59, %t60
  %t65 = xor i1 %t63, true
  br i1 %t65, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s2)
  br label %bb17
bb14:
  br label %bb15
bb15:
  %t67 = load i64, ptr %l4, !tbaa !24
  %t68 = load i64, ptr %l8, !tbaa !24
  %t69 = load i64, ptr %l6, !tbaa !24
  %t72 = mul i64 %t68, %t69
  %t75 = add i64 %t67, %t72
  store i64 %t75, ptr %l9, !tbaa !24
  %t77 = load i64, ptr %l9, !tbaa !24
  %t78 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t78, ptr %l46, !tbaa !27
  %t79 = load i64, ptr %l9, !tbaa !24
  %t81 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !27
  %t83 = getelementptr i32, ptr %t82, i64 %t79
  %t84 = load i32, ptr %t83, !tbaa !33
  %t86 = load ptr, ptr %lp3
  %t88 = getelementptr { i64, ptr }, ptr %t86, i32 0, i32 1
  %t89 = load ptr, ptr %t88, !tbaa !27
  %t90 = getelementptr i32, ptr %t89, i64 %t77
  store i32 %t84, ptr %t90, !tbaa !33
  call void @__olang_scope_close(ptr %s2)
  br label %bb16
bb16:
  %t91 = load i64, ptr %l8, !tbaa !24
  %t93 = add i64 %t91, 1
  store i64 %t93, ptr %l8, !tbaa !24
  br label %bb12
bb17:
  %t95 = load ptr, ptr %lp3
  %t96 = load { i64, ptr }, ptr %t95, !tbaa !27
  store { i64, ptr } %t96, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @compiler_2flower_2ecompiler_2flower_3alowering_2ejoinErrors(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l3 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l9 = alloca ptr
  %l11 = alloca { i64, ptr }
  %l12 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l3
  br label %bb1
bb1:
  %t2 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l3
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l2
  %t3 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2espawnErrors(ptr %v0, ptr %v1, ptr %s0, ptr %t3, ptr %a1, ptr %l2)
  br label %bb2
bb2:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/lower:lowering", ptr %t9, i32 0, i32 2
  %t12 = load ptr, ptr %t11, !tbaa !29
  store ptr %t12, ptr %l9, !tbaa !29
  %t14 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eToAr_H9d0f958437b2bc29fe1d416dfb9901d7(ptr %s0, ptr %s0, ptr %l2)
  store { i64, ptr } %t14, ptr %l11
  br label %bb3
bb3:
  %t15 = load ptr, ptr %l9, !tbaa !29
  %t16 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t17 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s0, ptr %t15, { i64, ptr } %t16)
  store i32 %t17, ptr %l12
  br label %bb4
bb4:
  call void @__olang_scope_close(ptr %s0)
  %t18 = load i32, ptr %l12, !tbaa !23
  store i32 %t18, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2ejoinFailed(ptr %v0, ptr %a0, i64 %a1, i32 %a2, { i64, [4 x i64] } %a3, i32 %a4, %"compiler/source:Span" %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l6 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l7 = alloca ptr
  %l8 = alloca i1
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l18 = alloca i64
  %l22 = alloca ptr
  %l23 = alloca %"compiler/lower:level"
  %l26 = alloca %"compiler/lower:level"
  %l27 = alloca i32
  %l28 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l32 = alloca i64
  %l34 = alloca i1
  %l36 = alloca ptr
  %l39 = alloca i64
  %l41 = alloca %"compiler/lower:tryCtx"
  %l46 = alloca ptr
  %l47 = alloca %"compiler/lower:tryCtx"
  %l50 = alloca %"compiler/lower:tryCtx"
  %l51 = alloca i32
  %l54 = alloca i64
  %l58 = alloca i64
  %l61 = alloca i64
  %l82 = alloca i32
  %l86 = alloca ptr
  %l90 = alloca %"compiler/lower:tryCtx"
  %l98 = alloca %"compiler/lower:tryCtx"
  %l101 = alloca %"compiler/lower:tryCtx"
  %l102 = alloca i32
  %l104 = alloca i64
  %l108 = alloca ptr
  %l109 = alloca %"compiler/lower:tryCtx"
  %l111 = alloca %"compiler/lower:tryCtx"
  %l112 = alloca i32
  %l114 = alloca i64
  %l118 = alloca ptr
  %l119 = alloca %"compiler/lower:level"
  %l121 = alloca %"compiler/lower:level"
  %l122 = alloca i32
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s13 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3alevel_3e(ptr %s0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l15
  br label %bb1
bb1:
  %t2 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l15
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l6
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/lower:lowering", ptr %t3, i32 0, i32 9
  %t7 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3alevel_3e_2eLen_3ccompiler_2flower_3alevel_3e(ptr %v0, ptr %t5)
  store i64 %t7, ptr %l18
  br label %bb3
bb3:
  %t8 = load i64, ptr %l1, !tbaa !24
  %t9 = load i64, ptr %l18, !tbaa !24
  %t11 = icmp sgt i64 %t9, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s1)
  br label %bb13
bb5:
  br label %bb6
bb6:
  store ptr %l6, ptr %l22, !tbaa !29
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/lower:lowering", ptr %t15, i32 0, i32 9
  %t19 = call { i32, %"compiler/lower:level" } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3alevel_3e_2ePop_3ccompiler_2flower_3alevel_3e(ptr %v0, ptr %t17)
  %t20 = extractvalue { i32, %"compiler/lower:level" } %t19, 1
  %t21 = extractvalue { i32, %"compiler/lower:level" } %t19, 0
  store i32 %t21, ptr %l27
  %t22 = icmp ne i32 %t21, 0
  br i1 %t22, label %bb8, label %ok.23
ok.23:
  store %"compiler/lower:level" %t20, ptr %l26
  br label %bb7
bb7:
  %t24 = load %"compiler/lower:level", ptr %l26
  store %"compiler/lower:level" %t24, ptr %l23
  br label %bb10
bb8:
  br label %bb9
bb9:
  call void @__olang_ert_req_clear()
  call void @__olang_check_failed(ptr @olang_loc_ef20f52c973b68a_c1ac21606c61e00e)
  unreachable
bb10:
  %t25 = load ptr, ptr %l22, !tbaa !29
  %t26 = load %"compiler/lower:level", ptr %l23
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3alevel_3e_2ePush_3ccompiler_2flower_3alevel_3e(ptr %s0, ptr %t25, %"compiler/lower:level" %t26)
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s1)
  br label %bb12
bb12:
  br label %bb2
bb13:
  %t27 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2flower_3atryCtx_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t27, ptr %l28
  br label %bb14
bb14:
  %t28 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l28
  %t29 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t28, ptr %t29
  store ptr %t29, ptr %l7, !tbaa !29
  br label %bb15
bb15:
  store %olang.scope zeroinitializer, ptr %s3
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/lower:lowering", ptr %t31, i32 0, i32 13
  %t35 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3atryCtx_3e_2eLen_3ccompiler_2flower_3atryCtx_3e(ptr %v0, ptr %t33)
  store i64 %t35, ptr %l32
  br label %bb16
bb16:
  %t36 = load i64, ptr %l32, !tbaa !24
  %t37 = icmp sgt i64 %t36, 0
  br i1 %t37, label %bb17, label %bb18
bb17:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/lower:lowering", ptr %t39, i32 0, i32 13
  store ptr %t41, ptr %l36, !tbaa !29
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/lower:lowering", ptr %t42, i32 0, i32 13
  %t46 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3atryCtx_3e_2eLen_3ccompiler_2flower_3atryCtx_3e(ptr %v0, ptr %t44)
  store i64 %t46, ptr %l39
  br label %bb19
bb18:
  store i1 false, ptr %l34, !tbaa !21
  br label %bb21
bb19:
  %t47 = load i64, ptr %l39, !tbaa !24
  %t48 = sub i64 %t47, 1
  %t49 = load ptr, ptr %l36, !tbaa !29
  %t51 = call %"compiler/lower:tryCtx" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3atryCtx_3e_2eAt_3ccompiler_2flower_3atryCtx_3e(ptr %v0, ptr %v0, ptr %t49, i64 %t48)
  store %"compiler/lower:tryCtx" %t51, ptr %l41
  br label %bb20
bb20:
  %t52 = getelementptr %"compiler/lower:tryCtx", ptr %l41, i32 0, i32 0
  %t53 = load i64, ptr %t52, !tbaa !24
  %t54 = load i64, ptr %l1, !tbaa !24
  %t57 = icmp sgt i64 %t53, %t54
  store i1 %t57, ptr %l34, !tbaa !21
  br label %bb21
bb21:
  %t59 = load i1, ptr %l34, !tbaa !21
  %t60 = xor i1 %t59, true
  br i1 %t60, label %bb22, label %bb23
bb22:
  call void @__olang_scope_close(ptr %s3)
  br label %bb31
bb23:
  br label %bb24
bb24:
  %t62 = load ptr, ptr %l7, !tbaa !29
  store ptr %t62, ptr %l46, !tbaa !29
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/lower:lowering", ptr %t63, i32 0, i32 13
  %t67 = call { i32, %"compiler/lower:tryCtx" } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3atryCtx_3e_2ePop_3ccompiler_2flower_3atryCtx_3e(ptr %v0, ptr %v0, ptr %t65)
  %t68 = extractvalue { i32, %"compiler/lower:tryCtx" } %t67, 1
  %t69 = extractvalue { i32, %"compiler/lower:tryCtx" } %t67, 0
  store i32 %t69, ptr %l51
  %t70 = icmp ne i32 %t69, 0
  br i1 %t70, label %bb26, label %ok.71
ok.71:
  store %"compiler/lower:tryCtx" %t68, ptr %l50
  br label %bb25
bb25:
  %t72 = load %"compiler/lower:tryCtx", ptr %l50
  store %"compiler/lower:tryCtx" %t72, ptr %l47
  br label %bb28
bb26:
  br label %bb27
bb27:
  call void @__olang_ert_req_clear()
  call void @__olang_check_failed(ptr @olang_loc_4cb37aee5d59facb_f2ca314d8498104f)
  unreachable
bb28:
  %t73 = load ptr, ptr %l46, !tbaa !29
  %t74 = load %"compiler/lower:tryCtx", ptr %l47
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3atryCtx_3e_2ePush_3ccompiler_2flower_3atryCtx_3e(ptr %v0, ptr %v0, ptr %t73, %"compiler/lower:tryCtx" %t74)
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s3)
  br label %bb30
bb30:
  br label %bb15
bb31:
  store i1 false, ptr %l8, !tbaa !21
  store i64 0, ptr %l9, !tbaa !24
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = getelementptr %"compiler/lower:lowering", ptr %t75, i32 0, i32 17
  %t79 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeId_3e_2eLen_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t77)
  store i64 %t79, ptr %l54
  br label %bb32
bb32:
  %t80 = load i64, ptr %l54, !tbaa !24
  store i64 %t80, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t81 = load i64, ptr %l10, !tbaa !24
  %t82 = load i64, ptr %l9, !tbaa !24
  %t85 = icmp sgt i64 %t81, %t82
  br i1 %t85, label %bb33, label %bb34
bb33:
  %t87 = load i64, ptr %l11, !tbaa !24
  %t89 = icmp sgt i64 %t87, 0
  br i1 %t89, label %bb35, label %bb36
bb34:
  store i64 0, ptr %l58, !tbaa !24
  br label %bb38
bb35:
  %t91 = load i64, ptr %l10, !tbaa !24
  %t92 = load i64, ptr %l9, !tbaa !24
  %t95 = sub i64 %t91, %t92
  %t96 = load i64, ptr %l11, !tbaa !24
  %t99 = add i64 %t95, %t96
  %t101 = sub i64 %t99, 1
  %t102 = load i64, ptr %l11, !tbaa !24
  %t105 = sdiv i64 %t101, %t102
  store i64 %t105, ptr %l61, !tbaa !24
  br label %bb37
bb36:
  store i64 0, ptr %l61, !tbaa !24
  br label %bb37
bb37:
  %t107 = load i64, ptr %l61, !tbaa !24
  store i64 %t107, ptr %l58, !tbaa !24
  br label %bb38
bb38:
  %t108 = load i64, ptr %l58, !tbaa !24
  store i64 %t108, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb39
bb39:
  store %olang.scope zeroinitializer, ptr %s6
  %t109 = load i64, ptr %l13, !tbaa !24
  %t110 = load i64, ptr %l12, !tbaa !24
  %t113 = icmp slt i64 %t109, %t110
  %t115 = xor i1 %t113, true
  br i1 %t115, label %bb40, label %bb41
bb40:
  call void @__olang_scope_close(ptr %s6)
  br label %bb50
bb41:
  br label %bb42
bb42:
  %t117 = load i64, ptr %l9, !tbaa !24
  %t118 = load i64, ptr %l13, !tbaa !24
  %t119 = load i64, ptr %l11, !tbaa !24
  %t122 = mul i64 %t118, %t119
  %t125 = add i64 %t117, %t122
  store i64 %t125, ptr %l14, !tbaa !24
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t129 = getelementptr %"compiler/lower:lowering", ptr %t127, i32 0, i32 17
  %t130 = load i64, ptr %l14, !tbaa !24
  %t133 = call i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeId_3e_2eAt_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t129, i64 %t130)
  store i32 %t133, ptr %l82
  br label %bb43
bb43:
  %t135 = load i32, ptr %l82, !tbaa !23
  %t137 = icmp eq i32 %t135, %a2
  br i1 %t137, label %bb44, label %bb45
bb44:
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t141 = getelementptr %"compiler/lower:lowering", ptr %t139, i32 0, i32 13
  store ptr %t141, ptr %l86, !tbaa !29
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t144 = getelementptr %"compiler/lower:lowering", ptr %t142, i32 0, i32 16
  %t145 = load i64, ptr %l14, !tbaa !24
  %t148 = call %"compiler/lower:tryCtx" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3atryCtx_3e_2eAt_3ccompiler_2flower_3atryCtx_3e(ptr %v0, ptr %v0, ptr %t144, i64 %t145)
  store %"compiler/lower:tryCtx" %t148, ptr %l90
  br label %bb46
bb45:
  br label %bb48
bb46:
  %t149 = load ptr, ptr %l86, !tbaa !29
  %t150 = load %"compiler/lower:tryCtx", ptr %l90
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3atryCtx_3e_2ePush_3ccompiler_2flower_3atryCtx_3e(ptr %v0, ptr %v0, ptr %t149, %"compiler/lower:tryCtx" %t150)
  br label %bb47
bb47:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb48
bb48:
  call void @__olang_scope_close(ptr %s6)
  br label %bb49
bb49:
  %t151 = load i64, ptr %l13, !tbaa !24
  %t153 = add i64 %t151, 1
  store i64 %t153, ptr %l13, !tbaa !24
  br label %bb39
bb50:
  %t155 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2edispatch(ptr %v0, ptr %t155, { i64, [4 x i64] } %a3, i32 %a4, %"compiler/source:Span" %a5, i1 false)
  br label %bb51
bb51:
  %t163 = load i1, ptr %l8, !tbaa !21
  br i1 %t163, label %bb52, label %bb53
bb52:
  %t165 = load ptr, ptr %l0, !tbaa !29
  %t167 = getelementptr %"compiler/lower:lowering", ptr %t165, i32 0, i32 13
  %t169 = call { i32, %"compiler/lower:tryCtx" } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3atryCtx_3e_2ePop_3ccompiler_2flower_3atryCtx_3e(ptr %v0, ptr %v0, ptr %t167)
  %t170 = extractvalue { i32, %"compiler/lower:tryCtx" } %t169, 1
  %t171 = extractvalue { i32, %"compiler/lower:tryCtx" } %t169, 0
  store i32 %t171, ptr %l102
  %t172 = icmp ne i32 %t171, 0
  br i1 %t172, label %bb55, label %ok.173
ok.173:
  store %"compiler/lower:tryCtx" %t170, ptr %l101
  br label %bb54
bb53:
  br label %bb58
bb54:
  %t174 = load %"compiler/lower:tryCtx", ptr %l101
  store %"compiler/lower:tryCtx" %t174, ptr %l98
  br label %bb57
bb55:
  br label %bb56
bb56:
  call void @__olang_ert_req_clear()
  br label %bb57
bb57:
  br label %bb58
bb58:
  br label %bb59
bb59:
  store %olang.scope zeroinitializer, ptr %s11
  %t175 = load ptr, ptr %l7, !tbaa !29
  %t177 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3atryCtx_3e_2eLen_3ccompiler_2flower_3atryCtx_3e(ptr %v0, ptr %t175)
  store i64 %t177, ptr %l104
  br label %bb60
bb60:
  %t178 = load i64, ptr %l104, !tbaa !24
  %t179 = icmp sgt i64 %t178, 0
  %t181 = xor i1 %t179, true
  br i1 %t181, label %bb61, label %bb62
bb61:
  call void @__olang_scope_close(ptr %s11)
  br label %bb70
bb62:
  br label %bb63
bb63:
  %t183 = load ptr, ptr %l0, !tbaa !29
  %t185 = getelementptr %"compiler/lower:lowering", ptr %t183, i32 0, i32 13
  store ptr %t185, ptr %l108, !tbaa !29
  %t186 = load ptr, ptr %l7, !tbaa !29
  %t188 = call { i32, %"compiler/lower:tryCtx" } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3atryCtx_3e_2ePop_3ccompiler_2flower_3atryCtx_3e(ptr %v0, ptr %v0, ptr %t186)
  %t189 = extractvalue { i32, %"compiler/lower:tryCtx" } %t188, 1
  %t190 = extractvalue { i32, %"compiler/lower:tryCtx" } %t188, 0
  store i32 %t190, ptr %l112
  %t191 = icmp ne i32 %t190, 0
  br i1 %t191, label %bb65, label %ok.192
ok.192:
  store %"compiler/lower:tryCtx" %t189, ptr %l111
  br label %bb64
bb64:
  %t193 = load %"compiler/lower:tryCtx", ptr %l111
  store %"compiler/lower:tryCtx" %t193, ptr %l109
  br label %bb67
bb65:
  br label %bb66
bb66:
  call void @__olang_ert_req_clear()
  call void @__olang_check_failed(ptr @olang_loc_d999208a3f1ad790_f453fe23535d6e14)
  unreachable
bb67:
  %t194 = load ptr, ptr %l108, !tbaa !29
  %t195 = load %"compiler/lower:tryCtx", ptr %l109
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3atryCtx_3e_2ePush_3ccompiler_2flower_3atryCtx_3e(ptr %v0, ptr %v0, ptr %t194, %"compiler/lower:tryCtx" %t195)
  br label %bb68
bb68:
  call void @__olang_scope_close(ptr %s11)
  br label %bb69
bb69:
  br label %bb59
bb70:
  br label %bb71
bb71:
  store %olang.scope zeroinitializer, ptr %s13
  %t197 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3alevel_3e_2eLen_3ccompiler_2flower_3alevel_3e(ptr %s0, ptr %l6)
  store i64 %t197, ptr %l114
  br label %bb72
bb72:
  %t198 = load i64, ptr %l114, !tbaa !24
  %t199 = icmp sgt i64 %t198, 0
  %t201 = xor i1 %t199, true
  br i1 %t201, label %bb73, label %bb74
bb73:
  call void @__olang_scope_close(ptr %s13)
  br label %bb82
bb74:
  br label %bb75
bb75:
  %t203 = load ptr, ptr %l0, !tbaa !29
  %t205 = getelementptr %"compiler/lower:lowering", ptr %t203, i32 0, i32 9
  store ptr %t205, ptr %l118, !tbaa !29
  %t207 = call { i32, %"compiler/lower:level" } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3alevel_3e_2ePop_3ccompiler_2flower_3alevel_3e(ptr %s0, ptr %l6)
  %t208 = extractvalue { i32, %"compiler/lower:level" } %t207, 1
  %t209 = extractvalue { i32, %"compiler/lower:level" } %t207, 0
  store i32 %t209, ptr %l122
  %t210 = icmp ne i32 %t209, 0
  br i1 %t210, label %bb77, label %ok.211
ok.211:
  store %"compiler/lower:level" %t208, ptr %l121
  br label %bb76
bb76:
  %t212 = load %"compiler/lower:level", ptr %l121
  store %"compiler/lower:level" %t212, ptr %l119
  br label %bb79
bb77:
  br label %bb78
bb78:
  call void @__olang_ert_req_clear()
  call void @__olang_check_failed(ptr @olang_loc_25181308607ed221_2244024027539ec5)
  unreachable
bb79:
  %t213 = load ptr, ptr %l118, !tbaa !29
  %t214 = load %"compiler/lower:level", ptr %l119
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3alevel_3e_2ePush_3ccompiler_2flower_3alevel_3e(ptr %v0, ptr %t213, %"compiler/lower:level" %t214)
  br label %bb80
bb80:
  call void @__olang_scope_close(ptr %s13)
  br label %bb81
bb81:
  br label %bb71
bb82:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2ejump(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca %"compiler/lower:loopCtx"
  %l8 = alloca i64
  %l16 = alloca %"compiler/lower:loopCtx"
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 12
  %t5 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3aloopCtx_3e_2eLen_3ccompiler_2flower_3aloopCtx_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l8
  br label %bb1
bb1:
  %t6 = load i64, ptr %l8, !tbaa !24
  %t7 = sub i64 %t6, 1
  store i64 %t7, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t9 = load i64, ptr %l4, !tbaa !24
  %t11 = icmp sge i64 %t9, 0
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb17
bb4:
  br label %bb5
bb5:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/lower:lowering", ptr %t15, i32 0, i32 12
  %t18 = load i64, ptr %l4, !tbaa !24
  %t21 = call %"compiler/lower:loopCtx" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3aloopCtx_3e_2eAt_3ccompiler_2flower_3aloopCtx_3e(ptr %v0, ptr %v0, ptr %t17, i64 %t18)
  store %"compiler/lower:loopCtx" %t21, ptr %l16
  br label %bb6
bb6:
  %t22 = load %"compiler/lower:loopCtx", ptr %l16
  store %"compiler/lower:loopCtx" %t22, ptr %l5
  %t23 = getelementptr %"compiler/lower:loopCtx", ptr %l5, i32 0, i32 0
  %t24 = load i32, ptr %t23, !tbaa !23
  %t28 = icmp eq i32 %t24, %a3
  br i1 %t28, label %bb7, label %bb8
bb7:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/lower:loopCtx", ptr %l5, i32 0, i32 1
  %t32 = load i64, ptr %t31, !tbaa !24
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eleave(ptr %v0, ptr %t30, i64 %t32)
  br label %bb9
bb8:
  br label %bb15
bb9:
  %t37 = trunc i64 0 to i32
  %t38 = icmp eq i32 %a2, %t37
  br i1 %t38, label %bb10, label %bb11
bb10:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/lower:loopCtx", ptr %l5, i32 0, i32 3
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eleaveOpen(ptr %v0, ptr %v0, ptr %t40, ptr %t41)
  br label %bb12
bb11:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/lower:loopCtx", ptr %l5, i32 0, i32 4
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eleaveOpen(ptr %v0, ptr %v0, ptr %t44, ptr %t45)
  br label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb15:
  call void @__olang_scope_close(ptr %s2)
  br label %bb16
bb16:
  %t48 = load i64, ptr %l4, !tbaa !24
  %t50 = sub i64 %t48, 1
  store i64 %t50, ptr %l4, !tbaa !24
  br label %bb2
bb17:
  %t52 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2egap(ptr %v0, ptr %s0, ptr %t52, %"compiler/source:Span" %a1, { i64, ptr } { i64 38, ptr getelementptr inbounds (<{ i64, [38 x i8] }>, ptr @.d14, i32 0, i32 1) })
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2eleave(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l5 = alloca i64
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 9
  %t5 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3alevel_3e_2eLen_3ccompiler_2flower_3alevel_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i64, ptr %l5, !tbaa !24
  %t7 = sub i64 %t6, 1
  store i64 %t7, ptr %l2, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t9 = load i64, ptr %l2, !tbaa !24
  %t13 = icmp sge i64 %t9, %a1
  %t15 = xor i1 %t13, true
  br i1 %t15, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb8
bb4:
  br label %bb5
bb5:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t18 = load i64, ptr %l2, !tbaa !24
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eexitLevel(ptr %v0, ptr %t17, i64 %t18)
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s2)
  br label %bb7
bb7:
  %t21 = load i64, ptr %l2, !tbaa !24
  %t23 = sub i64 %t21, 1
  store i64 %t23, ptr %l2, !tbaa !24
  br label %bb2
bb8:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2eleaveOpen(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 7
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/lower:lowering", ptr %t7, i32 0, i32 6
  %t10 = load i32, ptr %t9, !tbaa !23
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aBlockId_3e_2ePush_3ccompiler_2fmir_3aBlockId_3e(ptr %v1, ptr %a1, i32 %t10)
  br label %bb4
bb4:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/lower:lowering", ptr %t13, i32 0, i32 7
  store i1 true, ptr %t15, !tbaa !21
  br label %ret
ret:
  ret void
}

define dso_local { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2emadeAt(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l6 = alloca i1
  %l13 = alloca { i64, [1 x i64] }
  %rv = alloca { i64, [1 x i64] }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l1, !tbaa !23
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"compiler/lower:lowering", ptr %t2, i32 0, i32 20
  %t5 = load i32, ptr %t4, !tbaa !23
  %t8 = icmp eq i32 %t1, %t5
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load i32, ptr %l1, !tbaa !23
  %t12 = icmp sge i32 %t10, 0
  store i1 %t12, ptr %l6, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l6, !tbaa !21
  br label %bb3
bb3:
  %t14 = load i1, ptr %l6, !tbaa !21
  br i1 %t14, label %bb4, label %bb5
bb4:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/lower:lowering", ptr %t15, i32 0, i32 21
  %t18 = load { i64, [1 x i64] }, ptr %t17
  store { i64, [1 x i64] } %t18, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load i32, ptr %l1, !tbaa !23
  %t24 = call { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ebuilt(ptr %v0, ptr %t20, i32 %t21)
  store { i64, [1 x i64] } %t24, ptr %l13
  br label %bb7
bb7:
  %t25 = load { i64, [1 x i64] }, ptr %l13
  store { i64, [1 x i64] } %t25, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [1 x i64] }, ptr %rv
  ret { i64, [1 x i64] } %rr
}

define dso_local { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ematch(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l8 = alloca i32
  %l9 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l15 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca ptr
  %l23 = alloca { i64, [4 x i64] }
  %l24 = alloca i32
  %l25 = alloca i32
  %l26 = alloca { i64, ptr }
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca ptr
  %l30 = alloca { i64, [4 x i64] }
  %l31 = alloca { i64, [4 x i64] }
  %l32 = alloca i32
  %l33 = alloca i32
  %l42 = alloca { i64, ptr }
  %l55 = alloca i1
  %l59 = alloca i1
  %l66 = alloca i32
  %l67 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l76 = alloca { i64, ptr }
  %l81 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l82 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l89 = alloca i64
  %l92 = alloca i64
  %l113 = alloca { i64, ptr }
  %l120 = alloca { i64, [4 x i64] }
  %l125 = alloca i32
  %l128 = alloca i32
  %l144 = alloca { i64, ptr }
  %l151 = alloca { i64, [4 x i64] }
  %l152 = alloca ptr
  %l154 = alloca %"compiler/source:Span"
  %l159 = alloca %"compiler/mir:Place"
  %l187 = alloca { i64, [4 x i64] }
  %l193 = alloca i32
  %l196 = alloca i32
  %l220 = alloca ptr
  %l236 = alloca %"compiler/mir:Place"
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %rv = alloca { i64, [4 x i64] }
  %t39 = alloca { i64, [4 x i64] }, align 8
  %t208 = alloca { i64, [8 x i64] }, align 8
  %t273 = alloca { i64, [15 x i64] }, align 8
  %t279 = alloca { i64, [21 x i64] }, align 8
  %t365 = alloca { i64, [8 x i64] }, align 8
  %t441 = alloca { i64, [4 x i64] }, align 8
  %t448 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Match", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t6 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  store i64 %t8, ptr %l6, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t10 = load i64, ptr %l5, !tbaa !24
  %t11 = load i64, ptr %l6, !tbaa !24
  %t14 = icmp slt i64 %t10, %t11
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s2)
  br label %bb7
bb3:
  br label %bb4
bb4:
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t18, ptr %l42, !tbaa !27
  %t19 = load i64, ptr %l5, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr ptr, ptr %t22, i64 %t19
  %t24 = load ptr, ptr %t23, !tbaa !39
  %t26 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estmt(ptr %v0, ptr %v1, ptr %t26, ptr %t24)
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s2)
  br label %bb6
bb6:
  %t30 = load i64, ptr %l5, !tbaa !24
  %t32 = add i64 %t30, 1
  store i64 %t32, ptr %l5, !tbaa !24
  br label %bb1
bb7:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/lower:lowering", ptr %t34, i32 0, i32 7
  %t37 = load i1, ptr %t36, !tbaa !21
  br i1 %t37, label %bb8, label %bb9
bb8:
  store { i64, [4 x i64] } zeroinitializer, ptr %t39
  %t40 = getelementptr { i64, [4 x i64] }, ptr %t39, i32 0, i32 0
  store i64 0, ptr %t40
  %t41 = load { i64, [4 x i64] }, ptr %t39
  call void @__olang_scope_close(ptr %s0)
  store { i64, [4 x i64] } %t41, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t43 = load i32, ptr @G_2ecompiler_2fmir_2eNoLocal, !tbaa !23
  store i32 %t43, ptr %l8, !tbaa !23
  %t45 = load ptr, ptr %l1, !tbaa !29
  %t47 = getelementptr %"compiler/typed:Match", ptr %t45, i32 0, i32 3
  %t48 = load i1, ptr %t47, !tbaa !21
  br i1 %t48, label %bb11, label %bb12
bb11:
  %t50 = load i32, ptr %l2, !tbaa !23
  %t51 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t54 = icmp ne i32 %t50, %t51
  store i1 %t54, ptr %l55, !tbaa !21
  br label %bb13
bb12:
  store i1 false, ptr %l55, !tbaa !21
  br label %bb13
bb13:
  %t56 = load i1, ptr %l55, !tbaa !21
  br i1 %t56, label %bb14, label %bb15
bb14:
  %t57 = load i32, ptr %l2, !tbaa !23
  %t58 = load i32, ptr @G_2ecompiler_2ftypes_2eNoreturnT, !tbaa !23
  %t61 = icmp ne i32 %t57, %t58
  store i1 %t61, ptr %l59, !tbaa !21
  br label %bb16
bb15:
  store i1 false, ptr %l59, !tbaa !21
  br label %bb16
bb16:
  %t63 = load i1, ptr %l59, !tbaa !21
  br i1 %t63, label %bb17, label %bb18
bb17:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t65 = load i32, ptr %l2, !tbaa !23
  %t70 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2etemp(ptr %v0, ptr %t64, i32 %t65, %"compiler/source:Span" %a3)
  store i32 %t70, ptr %l66
  br label %bb19
bb18:
  br label %bb20
bb19:
  %t71 = load i32, ptr %l66, !tbaa !23
  store i32 %t71, ptr %l8, !tbaa !23
  br label %bb20
bb20:
  %t72 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aBlockId_3e(ptr %s0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t72, ptr %l67
  br label %bb21
bb21:
  %t73 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l67
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t73, ptr %l9
  %t74 = load ptr, ptr %l1, !tbaa !29
  %t76 = getelementptr %"compiler/typed:Match", ptr %t74, i32 0, i32 1
  %t77 = load { i64, ptr }, ptr %t76, !tbaa !27
  store { i64, ptr } %t77, ptr %l10, !tbaa !27
  store i64 0, ptr %l11, !tbaa !24
  %t79 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t81 = extractvalue { i64, ptr } %t79, 0
  store i64 %t81, ptr %l12, !tbaa !24
  br label %bb22
bb22:
  store %olang.scope zeroinitializer, ptr %s7
  %t83 = load i64, ptr %l11, !tbaa !24
  %t84 = load i64, ptr %l12, !tbaa !24
  %t87 = icmp slt i64 %t83, %t84
  %t89 = xor i1 %t87, true
  br i1 %t89, label %bb23, label %bb24
bb23:
  call void @__olang_scope_close(ptr %s7)
  br label %bb88
bb24:
  br label %bb25
bb25:
  %t91 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t91, ptr %l76, !tbaa !27
  %t92 = load i64, ptr %l11, !tbaa !24
  %t94 = getelementptr { i64, ptr }, ptr %l76, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !27
  %t96 = getelementptr ptr, ptr %t95, i64 %t92
  %t97 = load ptr, ptr %t96, !tbaa !39
  store ptr %t97, ptr %l13, !tbaa !29
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = getelementptr %"compiler/lower:lowering", ptr %t99, i32 0, i32 7
  %t102 = load i1, ptr %t101, !tbaa !21
  br i1 %t102, label %bb26, label %bb27
bb26:
  call void @__olang_scope_close(ptr %s7)
  br label %bb88
bb27:
  br label %bb28
bb28:
  %t104 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aBlockId_3e(ptr %s7)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t104, ptr %l81
  br label %bb29
bb29:
  %t105 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l81
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t105, ptr %l14
  %t106 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aBlockId_3e(ptr %s7)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t106, ptr %l82
  br label %bb30
bb30:
  %t107 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l82
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t107, ptr %l15
  store i64 0, ptr %l16, !tbaa !24
  %t108 = load ptr, ptr %l13, !tbaa !29
  %t110 = getelementptr %"compiler/typed:Arm", ptr %t108, i32 0, i32 1
  %t111 = load { i64, ptr }, ptr %t110, !tbaa !27
  %t113 = extractvalue { i64, ptr } %t111, 0
  store i64 %t113, ptr %l17, !tbaa !24
  store i64 1, ptr %l18, !tbaa !24
  %t115 = load i64, ptr %l17, !tbaa !24
  %t116 = load i64, ptr %l16, !tbaa !24
  %t119 = icmp sgt i64 %t115, %t116
  br i1 %t119, label %bb31, label %bb32
bb31:
  %t121 = load i64, ptr %l18, !tbaa !24
  %t123 = icmp sgt i64 %t121, 0
  br i1 %t123, label %bb33, label %bb34
bb32:
  store i64 0, ptr %l89, !tbaa !24
  br label %bb36
bb33:
  %t125 = load i64, ptr %l17, !tbaa !24
  %t126 = load i64, ptr %l16, !tbaa !24
  %t129 = sub i64 %t125, %t126
  %t130 = load i64, ptr %l18, !tbaa !24
  %t133 = add i64 %t129, %t130
  %t135 = sub i64 %t133, 1
  %t136 = load i64, ptr %l18, !tbaa !24
  %t139 = sdiv i64 %t135, %t136
  store i64 %t139, ptr %l92, !tbaa !24
  br label %bb35
bb34:
  store i64 0, ptr %l92, !tbaa !24
  br label %bb35
bb35:
  %t141 = load i64, ptr %l92, !tbaa !24
  store i64 %t141, ptr %l89, !tbaa !24
  br label %bb36
bb36:
  %t142 = load i64, ptr %l89, !tbaa !24
  store i64 %t142, ptr %l19, !tbaa !24
  store i64 0, ptr %l20, !tbaa !24
  br label %bb37
bb37:
  store %olang.scope zeroinitializer, ptr %s10
  %t143 = load i64, ptr %l20, !tbaa !24
  %t144 = load i64, ptr %l19, !tbaa !24
  %t147 = icmp slt i64 %t143, %t144
  %t149 = xor i1 %t147, true
  br i1 %t149, label %bb38, label %bb39
bb38:
  call void @__olang_scope_close(ptr %s10)
  br label %bb64
bb39:
  br label %bb40
bb40:
  %t151 = load i64, ptr %l16, !tbaa !24
  %t152 = load i64, ptr %l20, !tbaa !24
  %t153 = load i64, ptr %l18, !tbaa !24
  %t156 = mul i64 %t152, %t153
  %t159 = add i64 %t151, %t156
  store i64 %t159, ptr %l21, !tbaa !24
  %t161 = load ptr, ptr %l0, !tbaa !29
  %t163 = getelementptr %"compiler/lower:lowering", ptr %t161, i32 0, i32 7
  %t164 = load i1, ptr %t163, !tbaa !21
  br i1 %t164, label %bb41, label %bb42
bb41:
  call void @__olang_scope_close(ptr %s10)
  br label %bb64
bb42:
  br label %bb43
bb43:
  %t166 = load ptr, ptr %l13, !tbaa !29
  %t168 = getelementptr %"compiler/typed:Arm", ptr %t166, i32 0, i32 1
  %t169 = load { i64, ptr }, ptr %t168, !tbaa !27
  store { i64, ptr } %t169, ptr %l113, !tbaa !27
  %t170 = load i64, ptr %l21, !tbaa !24
  %t172 = getelementptr { i64, ptr }, ptr %l113, i32 0, i32 1
  %t173 = load ptr, ptr %t172, !tbaa !27
  %t174 = getelementptr ptr, ptr %t173, i64 %t170
  %t175 = load ptr, ptr %t174, !tbaa !39
  store ptr %t175, ptr %l22, !tbaa !29
  %t177 = load ptr, ptr %l0, !tbaa !29
  %t178 = load ptr, ptr %l22, !tbaa !29
  %t180 = getelementptr %"compiler/typed:Alt", ptr %t178, i32 0, i32 0
  %t181 = load ptr, ptr %t180, !tbaa !29
  %t185 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v1, ptr %t177, ptr %t181)
  store { i64, [4 x i64] } %t185, ptr %l120
  br label %bb44
bb44:
  %t186 = load { i64, [4 x i64] }, ptr %l120
  store { i64, [4 x i64] } %t186, ptr %l23
  %t187 = load ptr, ptr %l0, !tbaa !29
  %t189 = getelementptr %"compiler/lower:lowering", ptr %t187, i32 0, i32 7
  %t190 = load i1, ptr %t189, !tbaa !21
  br i1 %t190, label %bb45, label %bb46
bb45:
  call void @__olang_scope_close(ptr %s10)
  br label %bb64
bb46:
  br label %bb47
bb47:
  %t192 = load ptr, ptr %l0, !tbaa !29
  %t194 = getelementptr %"compiler/lower:lowering", ptr %t192, i32 0, i32 3
  %t196 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t194)
  store i32 %t196, ptr %l125
  br label %bb48
bb48:
  %t197 = load i32, ptr %l125, !tbaa !23
  store i32 %t197, ptr %l24, !tbaa !23
  %t198 = load ptr, ptr %l0, !tbaa !29
  %t200 = getelementptr %"compiler/lower:lowering", ptr %t198, i32 0, i32 3
  %t202 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t200)
  store i32 %t202, ptr %l128
  br label %bb49
bb49:
  %t203 = load i32, ptr %l128, !tbaa !23
  store i32 %t203, ptr %l25, !tbaa !23
  %t204 = load ptr, ptr %l0, !tbaa !29
  %t205 = load { i64, [4 x i64] }, ptr %l23
  %t206 = load i32, ptr %l24, !tbaa !23
  %t207 = load i32, ptr %l25, !tbaa !23
  store { i64, [8 x i64] } zeroinitializer, ptr %t208
  %t209 = getelementptr { i64, [8 x i64] }, ptr %t208, i32 0, i32 0
  store i64 2, ptr %t209
  %t211 = insertvalue { { i64, [4 x i64] }, i32, i32 } undef, { i64, [4 x i64] } %t205, 0
  %t213 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t211, i32 %t206, 1
  %t215 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t213, i32 %t207, 2
  %t216 = getelementptr { i64, [8 x i64] }, ptr %t208, i32 0, i32 1
  store { { i64, [4 x i64] }, i32, i32 } %t215, ptr %t216
  %t217 = load { i64, [8 x i64] }, ptr %t208
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t204, { i64, [8 x i64] } %t217)
  br label %bb50
bb50:
  %t220 = load ptr, ptr %l0, !tbaa !29
  %t221 = load i32, ptr %l24, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t220, i32 %t221)
  br label %bb51
bb51:
  %t224 = load ptr, ptr %l22, !tbaa !29
  %t226 = getelementptr %"compiler/typed:Alt", ptr %t224, i32 0, i32 1
  %t227 = load { i64, ptr }, ptr %t226, !tbaa !27
  store { i64, ptr } %t227, ptr %l26, !tbaa !27
  store i64 0, ptr %l27, !tbaa !24
  %t229 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t231 = extractvalue { i64, ptr } %t229, 0
  store i64 %t231, ptr %l28, !tbaa !24
  br label %bb52
bb52:
  store %olang.scope zeroinitializer, ptr %s14
  %t233 = load i64, ptr %l27, !tbaa !24
  %t234 = load i64, ptr %l28, !tbaa !24
  %t237 = icmp slt i64 %t233, %t234
  %t239 = xor i1 %t237, true
  br i1 %t239, label %bb53, label %bb54
bb53:
  call void @__olang_scope_close(ptr %s14)
  br label %bb60
bb54:
  br label %bb55
bb55:
  %t241 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t241, ptr %l144, !tbaa !27
  %t242 = load i64, ptr %l27, !tbaa !24
  %t244 = getelementptr { i64, ptr }, ptr %l144, i32 0, i32 1
  %t245 = load ptr, ptr %t244, !tbaa !27
  %t246 = getelementptr ptr, ptr %t245, i64 %t242
  %t247 = load ptr, ptr %t246, !tbaa !39
  store ptr %t247, ptr %l29, !tbaa !29
  %t249 = load ptr, ptr %l0, !tbaa !29
  %t250 = load ptr, ptr %l29, !tbaa !29
  %t252 = getelementptr %"compiler/typed:Bind", ptr %t250, i32 0, i32 1
  %t253 = load ptr, ptr %t252, !tbaa !29
  %t257 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v1, ptr %t249, ptr %t253)
  store { i64, [4 x i64] } %t257, ptr %l151
  br label %bb56
bb56:
  %t258 = load { i64, [4 x i64] }, ptr %l151
  store { i64, [4 x i64] } %t258, ptr %l30
  %t259 = load ptr, ptr %l0, !tbaa !29
  store ptr %t259, ptr %l152, !tbaa !29
  %t260 = load ptr, ptr %l13, !tbaa !29
  %t262 = getelementptr %"compiler/typed:Arm", ptr %t260, i32 0, i32 0
  %t263 = load %"compiler/source:Span", ptr %t262
  store %"compiler/source:Span" %t263, ptr %l154
  %t264 = load ptr, ptr %l29, !tbaa !29
  %t266 = getelementptr %"compiler/typed:Bind", ptr %t264, i32 0, i32 0
  %t267 = load i32, ptr %t266, !tbaa !23
  %t271 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t267)
  store %"compiler/mir:Place" %t271, ptr %l159
  br label %bb57
bb57:
  %t272 = load { i64, [4 x i64] }, ptr %l30
  store { i64, [15 x i64] } zeroinitializer, ptr %t273
  %t274 = getelementptr { i64, [15 x i64] }, ptr %t273, i32 0, i32 0
  store i64 0, ptr %t274
  %t276 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t272, 0
  %t277 = getelementptr { i64, [15 x i64] }, ptr %t273, i32 0, i32 1
  store { { i64, [4 x i64] } } %t276, ptr %t277
  %t278 = load { i64, [15 x i64] }, ptr %t273
  store { i64, [21 x i64] } zeroinitializer, ptr %t279
  %t280 = getelementptr { i64, [21 x i64] }, ptr %t279, i32 0, i32 0
  store i64 0, ptr %t280
  %t281 = load %"compiler/source:Span", ptr %l154
  %t282 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t281, 0
  %t283 = load %"compiler/mir:Place", ptr %l159
  %t284 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t282, %"compiler/mir:Place" %t283, 1
  %t286 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t284, { i64, [15 x i64] } %t278, 2
  %t287 = getelementptr { i64, [21 x i64] }, ptr %t279, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t286, ptr %t287
  %t288 = load { i64, [21 x i64] }, ptr %t279
  %t290 = call ptr @__olang_scope_alloc_a(ptr %s14, i64 176, i64 8)
  store { i64, [21 x i64] } %t288, ptr %t290
  %t291 = load ptr, ptr %l152, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s14, ptr %t291, ptr %t290)
  br label %bb58
bb58:
  call void @__olang_scope_close(ptr %s14)
  br label %bb59
bb59:
  %t293 = load i64, ptr %l27, !tbaa !24
  %t295 = add i64 %t293, 1
  store i64 %t295, ptr %l27, !tbaa !24
  br label %bb52
bb60:
  %t297 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eleaveOpen(ptr %v0, ptr %s7, ptr %t297, ptr %l15)
  br label %bb61
bb61:
  %t300 = load ptr, ptr %l0, !tbaa !29
  %t301 = load i32, ptr %l25, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t300, i32 %t301)
  br label %bb62
bb62:
  call void @__olang_scope_close(ptr %s10)
  br label %bb63
bb63:
  %t304 = load i64, ptr %l20, !tbaa !24
  %t306 = add i64 %t304, 1
  store i64 %t306, ptr %l20, !tbaa !24
  br label %bb37
bb64:
  %t308 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eleaveOpen(ptr %v0, ptr %s7, ptr %t308, ptr %l14)
  br label %bb65
bb65:
  %t311 = load ptr, ptr %l0, !tbaa !29
  %t312 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l15
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2epatch(ptr %v0, ptr %s7, ptr %t311, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t312)
  br label %bb66
bb66:
  %t315 = load ptr, ptr %l0, !tbaa !29
  %t317 = getelementptr %"compiler/lower:lowering", ptr %t315, i32 0, i32 7
  %t318 = load i1, ptr %t317, !tbaa !21
  br i1 %t318, label %bb67, label %bb68
bb67:
  %t320 = load ptr, ptr %l0, !tbaa !29
  %t321 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l14
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2epatch(ptr %v0, ptr %s7, ptr %t320, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t321)
  br label %bb69
bb68:
  br label %bb70
bb69:
  call void @__olang_scope_close(ptr %s7)
  br label %bb87
bb70:
  %t324 = load ptr, ptr %l13, !tbaa !29
  %t326 = getelementptr %"compiler/typed:Arm", ptr %t324, i32 0, i32 2
  %t327 = load ptr, ptr %t326, !tbaa !29
  %t329 = icmp eq ptr %t327, null
  %t331 = xor i1 %t329, true
  br i1 %t331, label %bb71, label %bb72
bb71:
  %t333 = load ptr, ptr %l0, !tbaa !29
  %t334 = load ptr, ptr %l13, !tbaa !29
  %t336 = getelementptr %"compiler/typed:Arm", ptr %t334, i32 0, i32 2
  %t337 = load ptr, ptr %t336, !tbaa !29
  %t340 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v1, ptr %t333, ptr %t337)
  store { i64, [4 x i64] } %t340, ptr %l187
  br label %bb73
bb72:
  br label %bb83
bb73:
  %t341 = load { i64, [4 x i64] }, ptr %l187
  store { i64, [4 x i64] } %t341, ptr %l31
  %t342 = load ptr, ptr %l0, !tbaa !29
  %t344 = getelementptr %"compiler/lower:lowering", ptr %t342, i32 0, i32 7
  %t345 = load i1, ptr %t344, !tbaa !21
  %t347 = xor i1 %t345, true
  br i1 %t347, label %bb74, label %bb75
bb74:
  %t349 = load ptr, ptr %l0, !tbaa !29
  %t351 = getelementptr %"compiler/lower:lowering", ptr %t349, i32 0, i32 3
  %t353 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t351)
  store i32 %t353, ptr %l193
  br label %bb76
bb75:
  br label %bb82
bb76:
  %t354 = load i32, ptr %l193, !tbaa !23
  store i32 %t354, ptr %l32, !tbaa !23
  %t355 = load ptr, ptr %l0, !tbaa !29
  %t357 = getelementptr %"compiler/lower:lowering", ptr %t355, i32 0, i32 3
  %t359 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t357)
  store i32 %t359, ptr %l196
  br label %bb77
bb77:
  %t360 = load i32, ptr %l196, !tbaa !23
  store i32 %t360, ptr %l33, !tbaa !23
  %t361 = load ptr, ptr %l0, !tbaa !29
  %t362 = load { i64, [4 x i64] }, ptr %l31
  %t363 = load i32, ptr %l32, !tbaa !23
  %t364 = load i32, ptr %l33, !tbaa !23
  store { i64, [8 x i64] } zeroinitializer, ptr %t365
  %t366 = getelementptr { i64, [8 x i64] }, ptr %t365, i32 0, i32 0
  store i64 2, ptr %t366
  %t368 = insertvalue { { i64, [4 x i64] }, i32, i32 } undef, { i64, [4 x i64] } %t362, 0
  %t370 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t368, i32 %t363, 1
  %t372 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t370, i32 %t364, 2
  %t373 = getelementptr { i64, [8 x i64] }, ptr %t365, i32 0, i32 1
  store { { i64, [4 x i64] }, i32, i32 } %t372, ptr %t373
  %t374 = load { i64, [8 x i64] }, ptr %t365
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t361, { i64, [8 x i64] } %t374)
  br label %bb78
bb78:
  %t377 = load ptr, ptr %l0, !tbaa !29
  %t378 = load i32, ptr %l33, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t377, i32 %t378)
  br label %bb79
bb79:
  %t381 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eleaveOpen(ptr %v0, ptr %s7, ptr %t381, ptr %l14)
  br label %bb80
bb80:
  %t384 = load ptr, ptr %l0, !tbaa !29
  %t385 = load i32, ptr %l32, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t384, i32 %t385)
  br label %bb81
bb81:
  br label %bb82
bb82:
  br label %bb83
bb83:
  %t388 = load ptr, ptr %l0, !tbaa !29
  %t389 = load ptr, ptr %l13, !tbaa !29
  %t390 = load i32, ptr %l8, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2earm(ptr %v0, ptr %v1, ptr %t388, ptr %t389, i32 %t390)
  br label %bb84
bb84:
  %t394 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eleaveOpen(ptr %v0, ptr %s0, ptr %t394, ptr %l9)
  br label %bb85
bb85:
  %t397 = load ptr, ptr %l0, !tbaa !29
  %t398 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l14
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2epatch(ptr %v0, ptr %s7, ptr %t397, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t398)
  br label %bb86
bb86:
  call void @__olang_scope_close(ptr %s7)
  br label %bb87
bb87:
  %t401 = load i64, ptr %l11, !tbaa !24
  %t403 = add i64 %t401, 1
  store i64 %t403, ptr %l11, !tbaa !24
  br label %bb22
bb88:
  %t405 = load ptr, ptr %l0, !tbaa !29
  %t407 = getelementptr %"compiler/lower:lowering", ptr %t405, i32 0, i32 7
  %t408 = load i1, ptr %t407, !tbaa !21
  %t410 = xor i1 %t408, true
  br i1 %t410, label %bb89, label %bb90
bb89:
  %t412 = load ptr, ptr %l0, !tbaa !29
  store ptr %t412, ptr %l220, !tbaa !29
  %t413 = load ptr, ptr %l1, !tbaa !29
  %t415 = getelementptr %"compiler/typed:Match", ptr %t413, i32 0, i32 2
  %t416 = load ptr, ptr %t415, !tbaa !29
  %t418 = icmp eq ptr %t416, null
  br i1 %t418, label %bb91, label %bb92
bb90:
  br label %bb96
bb91:
  call void @__olang_check_failed(ptr @olang_loc_820fb920c7f3fc9d_41590fa82c6def29)
  unreachable
bb92:
  br label %bb93
bb93:
  %t420 = load ptr, ptr %l1, !tbaa !29
  %t422 = getelementptr %"compiler/typed:Match", ptr %t420, i32 0, i32 2
  %t423 = load ptr, ptr %t422, !tbaa !29
  %t424 = load i32, ptr %l8, !tbaa !23
  %t425 = load ptr, ptr %l220, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2earm(ptr %v0, ptr %v1, ptr %t425, ptr %t423, i32 %t424)
  br label %bb94
bb94:
  %t428 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eleaveOpen(ptr %v0, ptr %s0, ptr %t428, ptr %l9)
  br label %bb95
bb95:
  br label %bb96
bb96:
  %t431 = load ptr, ptr %l0, !tbaa !29
  %t432 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l9
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2epatch(ptr %v0, ptr %s0, ptr %t431, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t432)
  br label %bb97
bb97:
  %t435 = load i32, ptr %l8, !tbaa !23
  %t436 = load i32, ptr @G_2ecompiler_2fmir_2eNoLocal, !tbaa !23
  %t439 = icmp eq i32 %t435, %t436
  br i1 %t439, label %bb98, label %bb99
bb98:
  store { i64, [4 x i64] } zeroinitializer, ptr %t441
  %t442 = getelementptr { i64, [4 x i64] }, ptr %t441, i32 0, i32 0
  store i64 0, ptr %t442
  %t443 = load { i64, [4 x i64] }, ptr %t441
  call void @__olang_scope_close(ptr %s0)
  store { i64, [4 x i64] } %t443, ptr %rv
  br label %ret
bb99:
  br label %bb100
bb100:
  %t445 = load i32, ptr %l8, !tbaa !23
  %t447 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t445)
  store %"compiler/mir:Place" %t447, ptr %l236
  br label %bb101
bb101:
  store { i64, [4 x i64] } zeroinitializer, ptr %t448
  %t449 = getelementptr { i64, [4 x i64] }, ptr %t448, i32 0, i32 0
  store i64 1, ptr %t449
  %t450 = load %"compiler/mir:Place", ptr %l236
  %t451 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t450, 0
  %t452 = getelementptr { i64, [4 x i64] }, ptr %t448, i32 0, i32 1
  store { %"compiler/mir:Place" } %t451, ptr %t452
  %t453 = load { i64, [4 x i64] }, ptr %t448
  call void @__olang_scope_close(ptr %s0)
  store { i64, [4 x i64] } %t453, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eonError(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca ptr
  %l8 = alloca ptr
  %l12 = alloca %"compiler/typed:BlockInfo"
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/typed:Body", ptr %t4, i32 0, i32 8
  store ptr %t6, ptr %l4, !tbaa !29
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/lower:lowering", ptr %t7, i32 0, i32 10
  %t13 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aBlock_26_3e_2eAt_Hef81d01aee8891fe569e7a3039d88992(ptr %v0, ptr %s0, ptr %t9, i64 %a1)
  store ptr %t13, ptr %l8
  br label %bb1
bb1:
  %t14 = load ptr, ptr %l8, !tbaa !29
  %t16 = getelementptr %"compiler/typed:Block", ptr %t14, i32 0, i32 0
  %t17 = load i32, ptr %t16, !tbaa !23
  %t19 = sext i32 %t17 to i64
  %t20 = load ptr, ptr %l4, !tbaa !29
  %t22 = call %"compiler/typed:BlockInfo" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aBlockInfo_3e_2eA_Hdb91c1ab6f912bb6141763aa02d0b766(ptr %v0, ptr %t20, i64 %t19)
  store %"compiler/typed:BlockInfo" %t22, ptr %l12
  br label %bb2
bb2:
  %t23 = getelementptr %"compiler/typed:BlockInfo", ptr %l12, i32 0, i32 1
  %t24 = load i32, ptr %t23
  %t26 = trunc i64 7 to i32
  %t27 = icmp eq i32 %t24, %t26
  call void @__olang_scope_close(ptr %s0)
  store i1 %t27, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { { i64, ptr }, i1 } @compiler_2flower_2ecompiler_2flower_3alowering_2epartsOf(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i32
  %l9 = alloca i32
  %l12 = alloca i32
  %l15 = alloca i1
  %l18 = alloca ptr
  %l21 = alloca i32
  %l22 = alloca { i64, ptr }
  %l26 = alloca i1
  %l27 = alloca ptr
  %l30 = alloca i32
  %l31 = alloca i32
  %l34 = alloca i1
  %l37 = alloca i1
  %l38 = alloca ptr
  %l41 = alloca i32
  %l42 = alloca { i64, ptr }
  %rv = alloca { { i64, ptr }, i1 }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t6, i32 %a1)
  store i32 %t10, ptr %l9
  br label %bb1
bb1:
  %t11 = load i32, ptr %l9, !tbaa !23
  store i32 %t11, ptr %l3, !tbaa !23
  %t12 = load ptr, ptr %l2, !tbaa !29
  %t13 = load i32, ptr %l3, !tbaa !23
  %t16 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t12, i32 %t13)
  store i32 %t16, ptr %l12
  br label %bb2
bb2:
  %t17 = load i32, ptr %l12
  store i32 %t17, ptr %l4
  %t18 = load i32, ptr %l4
  %t20 = trunc i64 22 to i32
  %t21 = icmp eq i32 %t18, %t20
  br i1 %t21, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb5
bb4:
  %t23 = load i32, ptr %l4
  %t25 = trunc i64 23 to i32
  %t26 = icmp eq i32 %t23, %t25
  store i1 %t26, ptr %l15, !tbaa !21
  br label %bb5
bb5:
  %t28 = load i1, ptr %l15, !tbaa !21
  br i1 %t28, label %bb6, label %bb7
bb6:
  %t29 = load ptr, ptr %l0, !tbaa !29
  store ptr %t29, ptr %l18, !tbaa !29
  %t30 = load ptr, ptr %l2, !tbaa !29
  %t31 = load i32, ptr %l3, !tbaa !23
  %t34 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t30, i32 %t31)
  store i32 %t34, ptr %l21
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t35 = load ptr, ptr %l18, !tbaa !29
  %t36 = load i32, ptr %l21, !tbaa !23
  %t37 = call { i64, ptr } @compiler_2flower_2ecompiler_2flower_3alowering_2eitems(ptr %v0, ptr %v1, ptr %t35, i32 %t36)
  store { i64, ptr } %t37, ptr %l22
  br label %bb9
bb9:
  %t38 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t39 = insertvalue { { i64, ptr }, i1 } undef, { i64, ptr } %t38, 0
  %t40 = insertvalue { { i64, ptr }, i1 } %t39, i1 true, 1
  store { { i64, ptr }, i1 } %t40, ptr %rv
  br label %ret
bb10:
  %t42 = load i32, ptr %l4
  %t44 = trunc i64 18 to i32
  %t45 = icmp eq i32 %t42, %t44
  br i1 %t45, label %bb11, label %bb12
bb11:
  %t47 = load ptr, ptr %l2, !tbaa !29
  store ptr %t47, ptr %l27, !tbaa !29
  %t48 = load ptr, ptr %l2, !tbaa !29
  %t49 = load i32, ptr %l3, !tbaa !23
  %t52 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t48, i32 %t49)
  store i32 %t52, ptr %l30
  br label %bb13
bb12:
  store i1 false, ptr %l26, !tbaa !21
  br label %bb15
bb13:
  %t53 = load ptr, ptr %l27, !tbaa !29
  %t54 = load i32, ptr %l30, !tbaa !23
  %t55 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t53, i32 %t54)
  store i32 %t55, ptr %l31
  br label %bb14
bb14:
  %t56 = load i32, ptr %l31
  %t58 = trunc i64 0 to i32
  %t59 = icmp eq i32 %t56, %t58
  store i1 %t59, ptr %l26, !tbaa !21
  br label %bb15
bb15:
  %t61 = load i1, ptr %l26, !tbaa !21
  br i1 %t61, label %bb16, label %bb17
bb16:
  %t62 = load ptr, ptr %l2, !tbaa !29
  %t63 = load i32, ptr %l3, !tbaa !23
  %t66 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %t62, i32 %t63)
  store i1 %t66, ptr %l37
  br label %bb18
bb17:
  store i1 false, ptr %l34, !tbaa !21
  br label %bb19
bb18:
  %t67 = load i1, ptr %l37, !tbaa !21
  store i1 %t67, ptr %l34, !tbaa !21
  br label %bb19
bb19:
  %t68 = load i1, ptr %l34, !tbaa !21
  br i1 %t68, label %bb20, label %bb21
bb20:
  %t69 = load ptr, ptr %l0, !tbaa !29
  store ptr %t69, ptr %l38, !tbaa !29
  %t70 = load ptr, ptr %l2, !tbaa !29
  %t71 = load i32, ptr %l3, !tbaa !23
  %t74 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t70, i32 %t71)
  store i32 %t74, ptr %l41
  br label %bb22
bb21:
  br label %bb24
bb22:
  %t75 = load ptr, ptr %l38, !tbaa !29
  %t76 = load i32, ptr %l41, !tbaa !23
  %t77 = call { i64, ptr } @compiler_2flower_2ecompiler_2flower_3alowering_2eitems(ptr %v0, ptr %v1, ptr %t75, i32 %t76)
  store { i64, ptr } %t77, ptr %l42
  br label %bb23
bb23:
  %t78 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t79 = insertvalue { { i64, ptr }, i1 } undef, { i64, ptr } %t78, 0
  %t80 = insertvalue { { i64, ptr }, i1 } %t79, i1 true, 1
  store { { i64, ptr }, i1 } %t80, ptr %rv
  br label %ret
bb24:
  %t82 = icmp sge i64 0, 0
  br i1 %t82, label %bb25, label %bb26
bb25:
  %t84 = icmp sle i64 0, 2305843009213693951
  br i1 %t84, label %bb27, label %bb28
bb26:
  call void @__olang_check_failed(ptr @olang_loc_af661f8aed04ff3d_6c60afe101a0b409)
  unreachable
bb27:
  %t86 = mul i64 0, 4
  %t87 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t86)
  %t88 = insertvalue { i64, ptr } undef, i64 0, 0
  %t89 = insertvalue { i64, ptr } %t88, ptr %t87, 1
  %t91 = insertvalue { { i64, ptr }, i1 } undef, { i64, ptr } %t89, 0
  %t92 = insertvalue { { i64, ptr }, i1 } %t91, i1 false, 1
  store { { i64, ptr }, i1 } %t92, ptr %rv
  br label %ret
bb28:
  call void @__olang_check_failed(ptr @olang_loc_af661f8aed04ff3d_6c60afe101a0b409)
  unreachable
ret:
  %rr = load { { i64, ptr }, i1 }, ptr %rv
  ret { { i64, ptr }, i1 } %rr
}

define dso_local %"compiler/mir:Range" @compiler_2flower_2ecompiler_2flower_3alowering_2epassed(ptr %v0, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l18 = alloca i64
  %l21 = alloca i64
  %l43 = alloca i1
  %l46 = alloca i1
  %l53 = alloca i64
  %l54 = alloca ptr
  %l59 = alloca { i64, [1 x i64] }
  %l60 = alloca { i64, [1 x i64] }
  %l66 = alloca %"compiler/mir:Range"
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca %"compiler/mir:Range"
  %t63 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l1, !tbaa !24
  store i64 %t1, ptr %l10, !tbaa !24
  %t2 = load i64, ptr %l10, !tbaa !24
  %t3 = icmp sge i64 %t2, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load i64, ptr %l10, !tbaa !24
  %t6 = icmp sle i64 %t5, 576460752303423487
  br i1 %t6, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_279896acdd8c6bde_4c10668047ad718a)
  unreachable
bb3:
  %t8 = load i64, ptr %l10, !tbaa !24
  %t9 = mul i64 %t8, 16
  %t10 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t9)
  %t11 = insertvalue { i64, ptr } undef, i64 %t8, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t14 = load i64, ptr %l1, !tbaa !24
  store i64 %t14, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t16 = load i64, ptr %l5, !tbaa !24
  %t17 = load i64, ptr %l4, !tbaa !24
  %t20 = icmp sgt i64 %t16, %t17
  br i1 %t20, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_279896acdd8c6bde_4c10668047ad718a)
  unreachable
bb5:
  %t22 = load i64, ptr %l6, !tbaa !24
  %t24 = icmp sgt i64 %t22, 0
  br i1 %t24, label %bb7, label %bb8
bb6:
  store i64 0, ptr %l18, !tbaa !24
  br label %bb10
bb7:
  %t26 = load i64, ptr %l5, !tbaa !24
  %t27 = load i64, ptr %l4, !tbaa !24
  %t30 = sub i64 %t26, %t27
  %t31 = load i64, ptr %l6, !tbaa !24
  %t34 = add i64 %t30, %t31
  %t36 = sub i64 %t34, 1
  %t37 = load i64, ptr %l6, !tbaa !24
  %t40 = sdiv i64 %t36, %t37
  store i64 %t40, ptr %l21, !tbaa !24
  br label %bb9
bb8:
  store i64 0, ptr %l21, !tbaa !24
  br label %bb9
bb9:
  %t42 = load i64, ptr %l21, !tbaa !24
  store i64 %t42, ptr %l18, !tbaa !24
  br label %bb10
bb10:
  %t43 = load i64, ptr %l18, !tbaa !24
  store i64 %t43, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb11
bb11:
  store %olang.scope zeroinitializer, ptr %s2
  %t44 = load i64, ptr %l8, !tbaa !24
  %t45 = load i64, ptr %l7, !tbaa !24
  %t48 = icmp slt i64 %t44, %t45
  %t50 = xor i1 %t48, true
  br i1 %t50, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s2)
  br label %bb27
bb13:
  br label %bb14
bb14:
  %t52 = load i64, ptr %l4, !tbaa !24
  %t53 = load i64, ptr %l8, !tbaa !24
  %t54 = load i64, ptr %l6, !tbaa !24
  %t57 = mul i64 %t53, %t54
  %t60 = add i64 %t52, %t57
  store i64 %t60, ptr %l9, !tbaa !24
  %t62 = load i64, ptr %l9, !tbaa !24
  store { i64, [1 x i64] } zeroinitializer, ptr %t63
  %t64 = getelementptr { i64, [1 x i64] }, ptr %t63, i32 0, i32 0
  store i64 2, ptr %t64
  %t65 = load { i64, [1 x i64] }, ptr %t63
  %t68 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t69 = load ptr, ptr %t68, !tbaa !27
  %t70 = getelementptr { i64, [1 x i64] }, ptr %t69, i64 %t62
  store { i64, [1 x i64] } %t65, ptr %t70
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/lower:lowering", ptr %t71, i32 0, i32 19
  %t74 = load i1, ptr %t73, !tbaa !21
  br i1 %t74, label %bb15, label %bb16
bb15:
  %t76 = load i32, ptr %l2, !tbaa !23
  %t78 = icmp sge i32 %t76, 0
  store i1 %t78, ptr %l43, !tbaa !21
  br label %bb17
bb16:
  store i1 false, ptr %l43, !tbaa !21
  br label %bb17
bb17:
  %t80 = load i1, ptr %l43, !tbaa !21
  br i1 %t80, label %bb18, label %bb19
bb18:
  %t81 = load i32, ptr %l2, !tbaa !23
  %t83 = sext i32 %t81 to i64
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr %"compiler/lower:lowering", ptr %t84, i32 0, i32 22
  %t87 = getelementptr %"compiler/typed:Plan", ptr %t86, i32 0, i32 0
  %t88 = load { i64, ptr }, ptr %t87, !tbaa !27
  %t90 = extractvalue { i64, ptr } %t88, 0
  %t93 = icmp slt i64 %t83, %t90
  store i1 %t93, ptr %l46, !tbaa !21
  br label %bb20
bb19:
  store i1 false, ptr %l46, !tbaa !21
  br label %bb20
bb20:
  %t95 = load i1, ptr %l46, !tbaa !21
  br i1 %t95, label %bb21, label %bb22
bb21:
  %t96 = load i64, ptr %l9, !tbaa !24
  store i64 %t96, ptr %l53, !tbaa !24
  %t97 = load ptr, ptr %l0, !tbaa !29
  store ptr %t97, ptr %l54, !tbaa !29
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t100 = getelementptr %"compiler/lower:lowering", ptr %t98, i32 0, i32 22
  %t101 = load i32, ptr %l2, !tbaa !23
  %t102 = load i64, ptr %l9, !tbaa !24
  %t106 = call { i64, [1 x i64] } @compiler_2ftyped_2ecompiler_2ftyped_3aPlan_2ePassed(ptr %v0, ptr %t100, i32 %t101, i64 %t102)
  store { i64, [1 x i64] } %t106, ptr %l59
  br label %bb23
bb22:
  br label %bb25
bb23:
  %t107 = load ptr, ptr %l54, !tbaa !29
  %t108 = load { i64, [1 x i64] }, ptr %l59
  %t109 = call { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2escopeRef(ptr %v0, ptr %t107, { i64, [1 x i64] } %t108)
  store { i64, [1 x i64] } %t109, ptr %l60
  br label %bb24
bb24:
  %t110 = load { i64, [1 x i64] }, ptr %l60
  %t111 = load i64, ptr %l53, !tbaa !24
  %t112 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t113 = load ptr, ptr %t112, !tbaa !27
  %t114 = getelementptr { i64, [1 x i64] }, ptr %t113, i64 %t111
  store { i64, [1 x i64] } %t110, ptr %t114
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s2)
  br label %bb26
bb26:
  %t115 = load i64, ptr %l8, !tbaa !24
  %t117 = add i64 %t115, 1
  store i64 %t117, ptr %l8, !tbaa !24
  br label %bb11
bb27:
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t121 = getelementptr %"compiler/lower:lowering", ptr %t119, i32 0, i32 3
  %t122 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t125 = call %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eScopeRefs(ptr %v0, ptr %s0, ptr %t121, { i64, ptr } %t122)
  store %"compiler/mir:Range" %t125, ptr %l66
  br label %bb28
bb28:
  call void @__olang_scope_close(ptr %s0)
  %t126 = load %"compiler/mir:Range", ptr %l66
  store %"compiler/mir:Range" %t126, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/mir:Range", ptr %rv
  ret %"compiler/mir:Range" %rr
}

define dso_local %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2epayload(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %lp3 = alloca ptr
  %l10 = alloca %"compiler/lower:pl"
  %l18 = alloca ptr
  %l19 = alloca i32
  %l22 = alloca %"compiler/mir:Place"
  %l25 = alloca { i64, [4 x i64] }
  %l26 = alloca ptr
  %l27 = alloca i32
  %l28 = alloca i32
  %l29 = alloca { i64, [4 x i64] }
  %l33 = alloca { i64, [4 x i64] }
  %l34 = alloca { i64, ptr }
  %l36 = alloca { i64, [4 x i64] }
  %l49 = alloca %"compiler/lower:pl"
  %s2 = alloca %olang.scope
  %rv = alloca %"compiler/lower:pl"
  %t39 = alloca { i64, [15 x i64] }, align 8
  %t104 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t4 = getelementptr %"compiler/typed:Payload", ptr %t2, i32 0, i32 0
  %t5 = load ptr, ptr %t4, !tbaa !29
  %t9 = call %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2eplace(ptr %v0, ptr %v1, ptr %v2, ptr %t1, ptr %t5)
  store %"compiler/lower:pl" %t9, ptr %l10
  br label %bb1
bb1:
  %t10 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 32, i64 8)
  store ptr %t10, ptr %lp3
  %t11 = load %"compiler/lower:pl", ptr %l10
  %t12 = load ptr, ptr %lp3
  store %"compiler/lower:pl" %t11, ptr %t12
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/lower:lowering", ptr %t13, i32 0, i32 7
  %t16 = load i1, ptr %t15, !tbaa !21
  br i1 %t16, label %bb2, label %bb3
bb2:
  %t18 = load ptr, ptr %lp3
  %t19 = load %"compiler/lower:pl", ptr %t18
  store %"compiler/lower:pl" %t19, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t21 = load ptr, ptr %l1, !tbaa !29
  %t23 = getelementptr %"compiler/typed:Payload", ptr %t21, i32 0, i32 2
  %t24 = load i32, ptr %t23
  %t26 = trunc i64 0 to i32
  %t27 = icmp eq i32 %t24, %t26
  %t29 = xor i1 %t27, true
  br i1 %t29, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s2
  %t31 = load ptr, ptr %l0, !tbaa !29
  store ptr %t31, ptr %l18, !tbaa !29
  %t32 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  store i32 %t32, ptr %l19, !tbaa !23
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t34 = load ptr, ptr %lp3
  %t35 = load %"compiler/lower:pl", ptr %t34
  %t38 = call %"compiler/mir:Place" @compiler_2flower_2ecompiler_2flower_3alowering_2emk(ptr %v0, ptr %v2, ptr %t33, %"compiler/lower:pl" %t35)
  store %"compiler/mir:Place" %t38, ptr %l22
  br label %bb7
bb6:
  br label %bb12
bb7:
  store { i64, [15 x i64] } zeroinitializer, ptr %t39
  %t40 = getelementptr { i64, [15 x i64] }, ptr %t39, i32 0, i32 0
  store i64 5, ptr %t40
  %t41 = load %"compiler/mir:Place", ptr %l22
  %t42 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t41, 0
  %t43 = getelementptr { i64, [15 x i64] }, ptr %t39, i32 0, i32 1
  store { %"compiler/mir:Place" } %t42, ptr %t43
  %t44 = load { i64, [15 x i64] }, ptr %t39
  %t45 = load %"compiler/source:Span", ptr %l2
  %t46 = load ptr, ptr %l18, !tbaa !29
  %t47 = load i32, ptr %l19, !tbaa !23
  %t50 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %t46, i32 %t47, { i64, [15 x i64] } %t44, %"compiler/source:Span" %t45)
  store { i64, [4 x i64] } %t50, ptr %l25
  br label %bb8
bb8:
  %t51 = load { i64, [4 x i64] }, ptr %l25
  %t52 = load ptr, ptr %l0, !tbaa !29
  store ptr %t52, ptr %l26, !tbaa !29
  store i32 13, ptr %l27
  %t53 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t53, ptr %l28, !tbaa !23
  store { i64, [4 x i64] } %t51, ptr %l29
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t56 = load ptr, ptr %l1, !tbaa !29
  %t58 = getelementptr %"compiler/typed:Payload", ptr %t56, i32 0, i32 1
  %t59 = load i64, ptr %t58, !tbaa !24
  %t62 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2econstI64(ptr %v0, ptr %t55, i64 %t59)
  store { i64, [4 x i64] } %t62, ptr %l33
  br label %bb9
bb9:
  %t63 = mul i64 2, 40
  %t64 = call ptr @__olang_scope_alloc_zeroed(ptr %s2, i64 %t63)
  %t65 = insertvalue { i64, ptr } undef, i64 2, 0
  %t66 = insertvalue { i64, ptr } %t65, ptr %t64, 1
  store { i64, ptr } %t66, ptr %l34, !tbaa !27
  %t67 = load { i64, [4 x i64] }, ptr %l29
  %t68 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t69 = load ptr, ptr %t68, !tbaa !27
  %t70 = getelementptr { i64, [4 x i64] }, ptr %t69, i64 0
  store { i64, [4 x i64] } %t67, ptr %t70
  %t71 = load { i64, [4 x i64] }, ptr %l33
  %t72 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !27
  %t74 = getelementptr { i64, [4 x i64] }, ptr %t73, i64 1
  store { i64, [4 x i64] } %t71, ptr %t74
  %t75 = load %"compiler/source:Span", ptr %l2
  %t76 = load ptr, ptr %l26, !tbaa !29
  %t77 = load i32, ptr %l27
  %t78 = load i32, ptr %l28, !tbaa !23
  %t79 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t81 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s2, ptr %t76, i32 %t77, i32 %t78, { i64, ptr } %t79, %"compiler/source:Span" %t75)
  store { i64, [4 x i64] } %t81, ptr %l36
  br label %bb10
bb10:
  %t82 = load { i64, [4 x i64] }, ptr %l36
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = load ptr, ptr %l1, !tbaa !29
  %t87 = getelementptr %"compiler/typed:Payload", ptr %t85, i32 0, i32 2
  %t88 = load i32, ptr %t87
  %t89 = load i64, ptr @G_2ecompiler_2flower_2eWrongCase, !tbaa !24
  %t90 = load %"compiler/source:Span", ptr %l2
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2echeck(ptr %v0, ptr %t83, { i64, [4 x i64] } %t82, i32 %t88, i32 8, i64 %t89, %"compiler/source:Span" %t90)
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s2)
  br label %bb12
bb12:
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t98 = load ptr, ptr %lp3
  %t99 = load %"compiler/lower:pl", ptr %t98
  %t100 = load ptr, ptr %l1, !tbaa !29
  %t102 = getelementptr %"compiler/typed:Payload", ptr %t100, i32 0, i32 1
  %t103 = load i64, ptr %t102, !tbaa !24
  store { i64, [1 x i64] } zeroinitializer, ptr %t104
  %t105 = getelementptr { i64, [1 x i64] }, ptr %t104, i32 0, i32 0
  store i64 4, ptr %t105
  %t107 = insertvalue { i64 } undef, i64 %t103, 0
  %t108 = getelementptr { i64, [1 x i64] }, ptr %t104, i32 0, i32 1
  store { i64 } %t107, ptr %t108
  %t109 = load { i64, [1 x i64] }, ptr %t104
  %t113 = call %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2ewith(ptr %v0, ptr %v2, ptr %v2, ptr %t97, %"compiler/lower:pl" %t99, { i64, [1 x i64] } %t109)
  store %"compiler/lower:pl" %t113, ptr %l49
  br label %bb13
bb13:
  %t114 = load %"compiler/lower:pl", ptr %l49
  store %"compiler/lower:pl" %t114, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/lower:pl", ptr %rv
  ret %"compiler/lower:pl" %rr
}

define dso_local %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2eplace(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca i32
  %l6 = alloca %"compiler/source:Span"
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca %"compiler/source:Span"
  %l11 = alloca ptr
  %l12 = alloca %"compiler/source:Span"
  %l13 = alloca ptr
  %l14 = alloca %"compiler/source:Span"
  %l15 = alloca i32
  %l16 = alloca ptr
  %l17 = alloca %"compiler/source:Span"
  %l21 = alloca %"compiler/lower:pl"
  %l29 = alloca %"compiler/lower:pl"
  %l30 = alloca %"compiler/lower:pl"
  %l31 = alloca ptr
  %l32 = alloca i1
  %l41 = alloca %"compiler/lower:pl"
  %l42 = alloca ptr
  %l43 = alloca i1
  %l56 = alloca %"compiler/lower:pl"
  %l57 = alloca ptr
  %l58 = alloca i1
  %l68 = alloca %"compiler/lower:pl"
  %l69 = alloca ptr
  %l70 = alloca i1
  %l77 = alloca ptr
  %l81 = alloca %"compiler/lower:pl"
  %l84 = alloca %"compiler/lower:pl"
  %l85 = alloca ptr
  %l86 = alloca i1
  %l96 = alloca %"compiler/lower:pl"
  %l97 = alloca ptr
  %l98 = alloca i1
  %l108 = alloca %"compiler/lower:pl"
  %l109 = alloca ptr
  %l110 = alloca i1
  %l119 = alloca ptr
  %l123 = alloca { i64, [4 x i64] }
  %l126 = alloca i32
  %l128 = alloca %"compiler/lower:pl"
  %l129 = alloca ptr
  %l130 = alloca i1
  %l137 = alloca %"compiler/lower:pl"
  %s2 = alloca %olang.scope
  %rv = alloca %"compiler/lower:pl"
  %t6 = alloca { i64, [2 x i64] }, align 8
  %t26 = alloca { i64, [2 x i64] }, align 8
  %t50 = alloca { i64, [2 x i64] }, align 8
  %t89 = alloca { i64, [2 x i64] }, align 8
  %t160 = alloca { i64, [1 x i64] }, align 8
  %t270 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 7
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  store { i64, [2 x i64] } zeroinitializer, ptr %t6
  %t7 = getelementptr { i64, [2 x i64] }, ptr %t6, i32 0, i32 0
  store i64 0, ptr %t7
  %t8 = load { i64, [2 x i64] }, ptr %t6
  %t10 = call %"compiler/lower:pl" @compiler_2flower_3apl_2ector(ptr %v2, { i64, [2 x i64] } %t8)
  store %"compiler/lower:pl" %t10, ptr %l21
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t11 = load %"compiler/lower:pl", ptr %l21
  store %"compiler/lower:pl" %t11, ptr %rv
  br label %ret
bb4:
  %t12 = load ptr, ptr %l1, !tbaa !29
  %t14 = icmp eq ptr %t12, null
  br i1 %t14, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s2
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/lower:lowering", ptr %t17, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !29
  %t22 = getelementptr %"compiler/typed:Body", ptr %t20, i32 0, i32 4
  %t23 = load %"compiler/source:Span", ptr %t22
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2egap(ptr %v0, ptr %s2, ptr %t16, %"compiler/source:Span" %t23, { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d15, i32 0, i32 1) })
  br label %bb7
bb6:
  br label %bb9
bb7:
  store { i64, [2 x i64] } zeroinitializer, ptr %t26
  %t27 = getelementptr { i64, [2 x i64] }, ptr %t26, i32 0, i32 0
  store i64 0, ptr %t27
  %t28 = load { i64, [2 x i64] }, ptr %t26
  %t30 = call %"compiler/lower:pl" @compiler_2flower_3apl_2ector(ptr %v2, { i64, [2 x i64] } %t28)
  store %"compiler/lower:pl" %t30, ptr %l29
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s2)
  %t31 = load %"compiler/lower:pl", ptr %l29
  store %"compiler/lower:pl" %t31, ptr %rv
  br label %ret
bb9:
  %t32 = load ptr, ptr %l1, !tbaa !29
  store ptr %t32, ptr %l31, !tbaa !29
  store i1 false, ptr %l32, !tbaa !21
  %t33 = load ptr, ptr %l31, !tbaa !29
  %t34 = icmp ne ptr %t33, null
  br i1 %t34, label %bb10, label %bb11
bb10:
  %t36 = load ptr, ptr %l31, !tbaa !29
  %t37 = load i64, ptr %t36
  %t39 = icmp eq i64 %t37, 0
  store i1 %t39, ptr %l32, !tbaa !21
  br label %bb11
bb11:
  %t40 = load i1, ptr %l32, !tbaa !21
  br i1 %t40, label %bb12, label %bb13
bb12:
  %t41 = load ptr, ptr %l1, !tbaa !29
  %t43 = getelementptr { i64, [4 x i64] }, ptr %t41, i32 0, i32 1
  %t44 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t43, i32 0, i32 2
  %t45 = load i32, ptr %t44
  store i32 %t45, ptr %l2, !tbaa !23
  br label %bb14
bb13:
  br label %bb16
bb14:
  %t47 = load i32, ptr %l2, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t50
  %t51 = getelementptr { i64, [2 x i64] }, ptr %t50, i32 0, i32 0
  store i64 1, ptr %t51
  %t53 = insertvalue { i32 } undef, i32 %t47, 0
  %t54 = getelementptr { i64, [2 x i64] }, ptr %t50, i32 0, i32 1
  store { i32 } %t53, ptr %t54
  %t55 = load { i64, [2 x i64] }, ptr %t50
  %t57 = call %"compiler/lower:pl" @compiler_2flower_3apl_2ector(ptr %v2, { i64, [2 x i64] } %t55)
  store %"compiler/lower:pl" %t57, ptr %l41
  br label %bb15
bb15:
  %t58 = load %"compiler/lower:pl", ptr %l41
  store %"compiler/lower:pl" %t58, ptr %l30
  br label %bb69
bb16:
  %t59 = load ptr, ptr %l1, !tbaa !29
  store ptr %t59, ptr %l42, !tbaa !29
  store i1 false, ptr %l43, !tbaa !21
  %t60 = load ptr, ptr %l42, !tbaa !29
  %t61 = icmp ne ptr %t60, null
  br i1 %t61, label %bb17, label %bb18
bb17:
  %t63 = load ptr, ptr %l42, !tbaa !29
  %t64 = load i64, ptr %t63
  %t66 = icmp eq i64 %t64, 1
  store i1 %t66, ptr %l43, !tbaa !21
  br label %bb18
bb18:
  %t67 = load i1, ptr %l43, !tbaa !21
  br i1 %t67, label %bb19, label %bb20
bb19:
  %t68 = load ptr, ptr %l1, !tbaa !29
  %t70 = getelementptr { i64, [4 x i64] }, ptr %t68, i32 0, i32 1
  %t71 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t70, i32 0, i32 1
  %t72 = load i32, ptr %t71
  store i32 %t72, ptr %l3, !tbaa !23
  %t74 = load ptr, ptr %l1, !tbaa !29
  %t76 = getelementptr { i64, [4 x i64] }, ptr %t74, i32 0, i32 1
  %t77 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t76, i32 0, i32 2
  %t78 = load i64, ptr %t77
  store i64 %t78, ptr %l4, !tbaa !24
  %t80 = load ptr, ptr %l1, !tbaa !29
  %t82 = getelementptr { i64, [4 x i64] }, ptr %t80, i32 0, i32 1
  %t83 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t82, i32 0, i32 3
  %t84 = load i32, ptr %t83
  store i32 %t84, ptr %l5, !tbaa !23
  br label %bb21
bb20:
  br label %bb23
bb21:
  %t86 = load i64, ptr %l4, !tbaa !24
  %t87 = load i32, ptr %l5, !tbaa !23
  %t88 = load i32, ptr %l3, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t89
  %t90 = getelementptr { i64, [2 x i64] }, ptr %t89, i32 0, i32 0
  store i64 2, ptr %t90
  %t92 = insertvalue { i64, i32, i32 } undef, i64 %t86, 0
  %t94 = insertvalue { i64, i32, i32 } %t92, i32 %t87, 1
  %t96 = insertvalue { i64, i32, i32 } %t94, i32 %t88, 2
  %t97 = getelementptr { i64, [2 x i64] }, ptr %t89, i32 0, i32 1
  store { i64, i32, i32 } %t96, ptr %t97
  %t98 = load { i64, [2 x i64] }, ptr %t89
  %t100 = call %"compiler/lower:pl" @compiler_2flower_3apl_2ector(ptr %v2, { i64, [2 x i64] } %t98)
  store %"compiler/lower:pl" %t100, ptr %l56
  br label %bb22
bb22:
  %t101 = load %"compiler/lower:pl", ptr %l56
  store %"compiler/lower:pl" %t101, ptr %l30
  br label %bb69
bb23:
  %t102 = load ptr, ptr %l1, !tbaa !29
  store ptr %t102, ptr %l57, !tbaa !29
  store i1 false, ptr %l58, !tbaa !21
  %t103 = load ptr, ptr %l57, !tbaa !29
  %t104 = icmp ne ptr %t103, null
  br i1 %t104, label %bb24, label %bb25
bb24:
  %t106 = load ptr, ptr %l57, !tbaa !29
  %t107 = load i64, ptr %t106
  %t109 = icmp eq i64 %t107, 2
  store i1 %t109, ptr %l58, !tbaa !21
  br label %bb25
bb25:
  %t110 = load i1, ptr %l58, !tbaa !21
  br i1 %t110, label %bb26, label %bb27
bb26:
  %t111 = load ptr, ptr %l1, !tbaa !29
  %t113 = getelementptr { i64, [4 x i64] }, ptr %t111, i32 0, i32 1
  %t114 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t113, i32 0, i32 0
  %t115 = load %"compiler/source:Span", ptr %t114
  store %"compiler/source:Span" %t115, ptr %l6
  %t117 = load ptr, ptr %l1, !tbaa !29
  %t119 = getelementptr { i64, [4 x i64] }, ptr %t117, i32 0, i32 1
  %t120 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t119, i32 0, i32 2
  %t121 = load ptr, ptr %t120
  store ptr %t121, ptr %l7, !tbaa !29
  br label %bb28
bb27:
  br label %bb30
bb28:
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t124 = load ptr, ptr %l7, !tbaa !29
  %t125 = load %"compiler/source:Span", ptr %l6
  %t129 = call %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2ederef(ptr %v0, ptr %v1, ptr %v2, ptr %t123, ptr %t124, %"compiler/source:Span" %t125)
  store %"compiler/lower:pl" %t129, ptr %l68
  br label %bb29
bb29:
  %t130 = load %"compiler/lower:pl", ptr %l68
  store %"compiler/lower:pl" %t130, ptr %l30
  br label %bb69
bb30:
  %t131 = load ptr, ptr %l1, !tbaa !29
  store ptr %t131, ptr %l69, !tbaa !29
  store i1 false, ptr %l70, !tbaa !21
  %t132 = load ptr, ptr %l69, !tbaa !29
  %t133 = icmp ne ptr %t132, null
  br i1 %t133, label %bb31, label %bb32
bb31:
  %t135 = load ptr, ptr %l69, !tbaa !29
  %t136 = load i64, ptr %t135
  %t138 = icmp eq i64 %t136, 3
  store i1 %t138, ptr %l70, !tbaa !21
  br label %bb32
bb32:
  %t139 = load i1, ptr %l70, !tbaa !21
  br i1 %t139, label %bb33, label %bb34
bb33:
  %t140 = load ptr, ptr %l1, !tbaa !29
  %t142 = getelementptr { i64, [4 x i64] }, ptr %t140, i32 0, i32 1
  %t143 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t142, i32 0, i32 2
  %t144 = load ptr, ptr %t143
  store ptr %t144, ptr %l8, !tbaa !29
  %t146 = load ptr, ptr %l1, !tbaa !29
  %t148 = getelementptr { i64, [4 x i64] }, ptr %t146, i32 0, i32 1
  %t149 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t148, i32 0, i32 3
  %t150 = load i64, ptr %t149
  store i64 %t150, ptr %l9, !tbaa !24
  br label %bb35
bb34:
  br label %bb38
bb35:
  %t152 = load ptr, ptr %l0, !tbaa !29
  store ptr %t152, ptr %l77, !tbaa !29
  %t153 = load ptr, ptr %l0, !tbaa !29
  %t154 = load ptr, ptr %l8, !tbaa !29
  %t158 = call %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2eplace(ptr %v0, ptr %v1, ptr %v0, ptr %t153, ptr %t154)
  store %"compiler/lower:pl" %t158, ptr %l81
  br label %bb36
bb36:
  %t159 = load i64, ptr %l9, !tbaa !24
  store { i64, [1 x i64] } zeroinitializer, ptr %t160
  %t161 = getelementptr { i64, [1 x i64] }, ptr %t160, i32 0, i32 0
  store i64 0, ptr %t161
  %t163 = insertvalue { i64 } undef, i64 %t159, 0
  %t164 = getelementptr { i64, [1 x i64] }, ptr %t160, i32 0, i32 1
  store { i64 } %t163, ptr %t164
  %t165 = load { i64, [1 x i64] }, ptr %t160
  %t166 = load ptr, ptr %l77, !tbaa !29
  %t167 = load %"compiler/lower:pl", ptr %l81
  %t169 = call %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2ewith(ptr %v0, ptr %v0, ptr %v2, ptr %t166, %"compiler/lower:pl" %t167, { i64, [1 x i64] } %t165)
  store %"compiler/lower:pl" %t169, ptr %l84
  br label %bb37
bb37:
  %t170 = load %"compiler/lower:pl", ptr %l84
  store %"compiler/lower:pl" %t170, ptr %l30
  br label %bb69
bb38:
  %t171 = load ptr, ptr %l1, !tbaa !29
  store ptr %t171, ptr %l85, !tbaa !29
  store i1 false, ptr %l86, !tbaa !21
  %t172 = load ptr, ptr %l85, !tbaa !29
  %t173 = icmp ne ptr %t172, null
  br i1 %t173, label %bb39, label %bb40
bb39:
  %t175 = load ptr, ptr %l85, !tbaa !29
  %t176 = load i64, ptr %t175
  %t178 = icmp eq i64 %t176, 4
  store i1 %t178, ptr %l86, !tbaa !21
  br label %bb40
bb40:
  %t179 = load i1, ptr %l86, !tbaa !21
  br i1 %t179, label %bb41, label %bb42
bb41:
  %t180 = load ptr, ptr %l1, !tbaa !29
  %t182 = getelementptr { i64, [4 x i64] }, ptr %t180, i32 0, i32 1
  %t183 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t182, i32 0, i32 0
  %t184 = load %"compiler/source:Span", ptr %t183
  store %"compiler/source:Span" %t184, ptr %l10
  %t186 = load ptr, ptr %l1, !tbaa !29
  %t188 = getelementptr { i64, [4 x i64] }, ptr %t186, i32 0, i32 1
  %t189 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t188, i32 0, i32 2
  %t190 = load ptr, ptr %t189
  store ptr %t190, ptr %l11, !tbaa !29
  br label %bb43
bb42:
  br label %bb45
bb43:
  %t192 = load ptr, ptr %l0, !tbaa !29
  %t193 = load ptr, ptr %l11, !tbaa !29
  %t194 = load %"compiler/source:Span", ptr %l10
  %t198 = call %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2eelem(ptr %v0, ptr %v1, ptr %v2, ptr %t192, ptr %t193, %"compiler/source:Span" %t194)
  store %"compiler/lower:pl" %t198, ptr %l96
  br label %bb44
bb44:
  %t199 = load %"compiler/lower:pl", ptr %l96
  store %"compiler/lower:pl" %t199, ptr %l30
  br label %bb69
bb45:
  %t200 = load ptr, ptr %l1, !tbaa !29
  store ptr %t200, ptr %l97, !tbaa !29
  store i1 false, ptr %l98, !tbaa !21
  %t201 = load ptr, ptr %l97, !tbaa !29
  %t202 = icmp ne ptr %t201, null
  br i1 %t202, label %bb46, label %bb47
bb46:
  %t204 = load ptr, ptr %l97, !tbaa !29
  %t205 = load i64, ptr %t204
  %t207 = icmp eq i64 %t205, 5
  store i1 %t207, ptr %l98, !tbaa !21
  br label %bb47
bb47:
  %t208 = load i1, ptr %l98, !tbaa !21
  br i1 %t208, label %bb48, label %bb49
bb48:
  %t209 = load ptr, ptr %l1, !tbaa !29
  %t211 = getelementptr { i64, [4 x i64] }, ptr %t209, i32 0, i32 1
  %t212 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t211, i32 0, i32 0
  %t213 = load %"compiler/source:Span", ptr %t212
  store %"compiler/source:Span" %t213, ptr %l12
  %t215 = load ptr, ptr %l1, !tbaa !29
  %t217 = getelementptr { i64, [4 x i64] }, ptr %t215, i32 0, i32 1
  %t218 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t217, i32 0, i32 2
  %t219 = load ptr, ptr %t218
  store ptr %t219, ptr %l13, !tbaa !29
  br label %bb50
bb49:
  br label %bb52
bb50:
  %t221 = load ptr, ptr %l0, !tbaa !29
  %t222 = load ptr, ptr %l13, !tbaa !29
  %t223 = load %"compiler/source:Span", ptr %l12
  %t227 = call %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2epayload(ptr %v0, ptr %v1, ptr %v2, ptr %t221, ptr %t222, %"compiler/source:Span" %t223)
  store %"compiler/lower:pl" %t227, ptr %l108
  br label %bb51
bb51:
  %t228 = load %"compiler/lower:pl", ptr %l108
  store %"compiler/lower:pl" %t228, ptr %l30
  br label %bb69
bb52:
  %t229 = load ptr, ptr %l1, !tbaa !29
  store ptr %t229, ptr %l109, !tbaa !29
  store i1 false, ptr %l110, !tbaa !21
  %t230 = load ptr, ptr %l109, !tbaa !29
  %t231 = icmp ne ptr %t230, null
  br i1 %t231, label %bb53, label %bb54
bb53:
  %t233 = load ptr, ptr %l109, !tbaa !29
  %t234 = load i64, ptr %t233
  %t236 = icmp eq i64 %t234, 6
  store i1 %t236, ptr %l110, !tbaa !21
  br label %bb54
bb54:
  %t237 = load i1, ptr %l110, !tbaa !21
  br i1 %t237, label %bb55, label %bb56
bb55:
  %t238 = load ptr, ptr %l1, !tbaa !29
  %t240 = getelementptr { i64, [4 x i64] }, ptr %t238, i32 0, i32 1
  %t241 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t240, i32 0, i32 0
  %t242 = load %"compiler/source:Span", ptr %t241
  store %"compiler/source:Span" %t242, ptr %l14
  %t244 = load ptr, ptr %l1, !tbaa !29
  %t246 = getelementptr { i64, [4 x i64] }, ptr %t244, i32 0, i32 1
  %t247 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t246, i32 0, i32 1
  %t248 = load i32, ptr %t247
  store i32 %t248, ptr %l15, !tbaa !23
  %t250 = load ptr, ptr %l1, !tbaa !29
  %t252 = getelementptr { i64, [4 x i64] }, ptr %t250, i32 0, i32 1
  %t253 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t252, i32 0, i32 2
  %t254 = load ptr, ptr %t253
  store ptr %t254, ptr %l16, !tbaa !29
  br label %bb57
bb56:
  br label %bb61
bb57:
  %t256 = load ptr, ptr %l0, !tbaa !29
  store ptr %t256, ptr %l119, !tbaa !29
  %t257 = load ptr, ptr %l0, !tbaa !29
  %t258 = load ptr, ptr %l16, !tbaa !29
  %t262 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v1, ptr %t257, ptr %t258)
  store { i64, [4 x i64] } %t262, ptr %l123
  br label %bb58
bb58:
  %t263 = load i32, ptr %l15, !tbaa !23
  %t264 = load %"compiler/source:Span", ptr %l14
  %t265 = load ptr, ptr %l119, !tbaa !29
  %t266 = load { i64, [4 x i64] }, ptr %l123
  %t269 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2elocal(ptr %v0, ptr %t265, { i64, [4 x i64] } %t266, i32 %t263, %"compiler/source:Span" %t264)
  store i32 %t269, ptr %l126
  br label %bb59
bb59:
  store { i64, [2 x i64] } zeroinitializer, ptr %t270
  %t271 = getelementptr { i64, [2 x i64] }, ptr %t270, i32 0, i32 0
  store i64 1, ptr %t271
  %t272 = load i32, ptr %l126, !tbaa !23
  %t273 = insertvalue { i32 } undef, i32 %t272, 0
  %t274 = getelementptr { i64, [2 x i64] }, ptr %t270, i32 0, i32 1
  store { i32 } %t273, ptr %t274
  %t275 = load { i64, [2 x i64] }, ptr %t270
  %t277 = call %"compiler/lower:pl" @compiler_2flower_3apl_2ector(ptr %v2, { i64, [2 x i64] } %t275)
  store %"compiler/lower:pl" %t277, ptr %l128
  br label %bb60
bb60:
  %t278 = load %"compiler/lower:pl", ptr %l128
  store %"compiler/lower:pl" %t278, ptr %l30
  br label %bb69
bb61:
  %t279 = load ptr, ptr %l1, !tbaa !29
  store ptr %t279, ptr %l129, !tbaa !29
  store i1 false, ptr %l130, !tbaa !21
  %t280 = load ptr, ptr %l129, !tbaa !29
  %t281 = icmp ne ptr %t280, null
  br i1 %t281, label %bb62, label %bb63
bb62:
  %t283 = load ptr, ptr %l129, !tbaa !29
  %t284 = load i64, ptr %t283
  %t286 = icmp eq i64 %t284, 7
  store i1 %t286, ptr %l130, !tbaa !21
  br label %bb63
bb63:
  %t287 = load i1, ptr %l130, !tbaa !21
  br i1 %t287, label %bb64, label %bb65
bb64:
  %t288 = load ptr, ptr %l1, !tbaa !29
  %t290 = getelementptr { i64, [4 x i64] }, ptr %t288, i32 0, i32 1
  %t291 = getelementptr { %"compiler/source:Span", i32 }, ptr %t290, i32 0, i32 0
  %t292 = load %"compiler/source:Span", ptr %t291
  store %"compiler/source:Span" %t292, ptr %l17
  br label %bb66
bb65:
  br label %bb68
bb66:
  %t294 = load ptr, ptr %l0, !tbaa !29
  %t295 = load %"compiler/source:Span", ptr %l17
  %t298 = call %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2etarget(ptr %v0, ptr %v2, ptr %t294, %"compiler/source:Span" %t295)
  store %"compiler/lower:pl" %t298, ptr %l137
  br label %bb67
bb67:
  %t299 = load %"compiler/lower:pl", ptr %l137
  store %"compiler/lower:pl" %t299, ptr %l30
  br label %bb69
bb68:
  call void @__olang_check_failed(ptr @olang_loc_25aa1fca937793b6_1bfa8a59c48f3aa2)
  unreachable
bb69:
  %t300 = load %"compiler/lower:pl", ptr %l30
  store %"compiler/lower:pl" %t300, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/lower:pl", ptr %rv
  ret %"compiler/lower:pl" %rr
}

define dso_local i32 @compiler_2flower_2ecompiler_2flower_3alowering_2ereadOnly(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l1 = alloca i32
  %l2 = alloca ptr
  %l7 = alloca i1
  %l8 = alloca ptr
  %l11 = alloca i32
  %l14 = alloca i64
  %l18 = alloca i32
  %rv = alloca i32
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/lower:lowering", ptr %a0, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t7 = load i32, ptr %l1, !tbaa !23
  %t10 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t6, i32 %t7)
  store i1 %t10, ptr %l7
  br label %bb1
bb1:
  %t11 = load i1, ptr %l7, !tbaa !21
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t12 = load ptr, ptr %l2, !tbaa !29
  store ptr %t12, ptr %l8, !tbaa !29
  %t13 = load ptr, ptr %l2, !tbaa !29
  %t14 = load i32, ptr %l1, !tbaa !23
  %t17 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t13, i32 %t14)
  store i32 %t17, ptr %l11
  br label %bb4
bb3:
  br label %bb7
bb4:
  %t18 = load ptr, ptr %l2, !tbaa !29
  %t19 = load i32, ptr %l1, !tbaa !23
  %t22 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t18, i32 %t19)
  store i64 %t22, ptr %l14
  br label %bb5
bb5:
  %t23 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t25 = sub i64 -1, %t23
  %t26 = load i64, ptr %l14, !tbaa !24
  %t28 = and i64 %t26, %t25
  %t29 = load ptr, ptr %l8, !tbaa !29
  %t30 = load i32, ptr %l11, !tbaa !23
  %t32 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t29, i32 %t30, i64 %t28)
  store i32 %t32, ptr %l18
  br label %bb6
bb6:
  %t33 = load i32, ptr %l18, !tbaa !23
  store i32 %t33, ptr %rv
  br label %ret
bb7:
  %t34 = load i32, ptr %l1, !tbaa !23
  store i32 %t34, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2ereleaseAt(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca %"compiler/lower:pl"
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l16 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l20 = alloca i32
  %l29 = alloca { i64, ptr }
  %l34 = alloca %"compiler/lower:pl"
  %l42 = alloca { i64, ptr }
  %l49 = alloca %"compiler/lower:pl"
  %l52 = alloca ptr
  %l53 = alloca %"compiler/source:Span"
  %l56 = alloca %"compiler/mir:Place"
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %t40 = alloca { i64, [2 x i64] }, align 8
  %t74 = alloca { i64, [1 x i64] }, align 8
  %t96 = alloca { i64, [21 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a2, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t3 = load ptr, ptr %l4, !tbaa !29
  %t4 = load i64, ptr %l5, !tbaa !24
  %t7 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3cI64_3e_26_3e_2eRunFrom_3cArray_3cI64_3e_26_3e(ptr %v1, ptr %t3, i64 %t4)
  %t8 = extractvalue { i32, { i64, ptr } } %t7, 1
  %t9 = extractvalue { i32, { i64, ptr } } %t7, 0
  store i32 %t9, ptr %l20
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb3, label %ok.11
ok.11:
  store { i64, ptr } %t8, ptr %l19
  br label %bb2
bb2:
  %t12 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t12, ptr %l16, !tbaa !27
  br label %bb7
bb3:
  %t13 = load i32, ptr %l20, !tbaa !23
  %t14 = ashr i32 %t13, 16
  %t16 = icmp eq i32 %t14, 1
  br i1 %t16, label %bb4, label %bb5
bb4:
  br label %bb6
bb5:
  call void @__olang_check_failed(ptr @olang_loc_5375c9cb83678927_a7b5000221ce904b)
  unreachable
bb6:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s2)
  br label %bb25
bb7:
  %t18 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t18, ptr %l6, !tbaa !27
  %t19 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t21 = extractvalue { i64, ptr } %t19, 0
  store i64 %t21, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s3
  %t23 = load i64, ptr %l8, !tbaa !24
  %t24 = load i64, ptr %l7, !tbaa !24
  %t27 = icmp slt i64 %t23, %t24
  %t29 = xor i1 %t27, true
  br i1 %t29, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s3)
  br label %bb23
bb10:
  br label %bb11
bb11:
  %t31 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t31, ptr %l29, !tbaa !27
  %t32 = load i64, ptr %l8, !tbaa !24
  %t34 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !27
  %t36 = getelementptr { i64, ptr }, ptr %t35, i64 %t32
  %t37 = load { i64, ptr }, ptr %t36, !tbaa !37
  store { i64, ptr } %t37, ptr %l9, !tbaa !27
  store { i64, [2 x i64] } zeroinitializer, ptr %t40
  %t41 = getelementptr { i64, [2 x i64] }, ptr %t40, i32 0, i32 0
  store i64 1, ptr %t41
  %t43 = insertvalue { i32 } undef, i32 %a1, 0
  %t44 = getelementptr { i64, [2 x i64] }, ptr %t40, i32 0, i32 1
  store { i32 } %t43, ptr %t44
  %t45 = load { i64, [2 x i64] }, ptr %t40
  %t47 = call %"compiler/lower:pl" @compiler_2flower_3apl_2ector(ptr %s3, { i64, [2 x i64] } %t45)
  store %"compiler/lower:pl" %t47, ptr %l34
  br label %bb12
bb12:
  %t48 = load %"compiler/lower:pl", ptr %l34
  store %"compiler/lower:pl" %t48, ptr %l10
  %t49 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t49, ptr %l11, !tbaa !27
  store i64 0, ptr %l12, !tbaa !24
  %t51 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t53 = extractvalue { i64, ptr } %t51, 0
  store i64 %t53, ptr %l13, !tbaa !24
  br label %bb13
bb13:
  store %olang.scope zeroinitializer, ptr %s5
  %t55 = load i64, ptr %l12, !tbaa !24
  %t56 = load i64, ptr %l13, !tbaa !24
  %t59 = icmp slt i64 %t55, %t56
  %t61 = xor i1 %t59, true
  br i1 %t61, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s5)
  br label %bb19
bb15:
  br label %bb16
bb16:
  %t63 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t63, ptr %l42, !tbaa !27
  %t64 = load i64, ptr %l12, !tbaa !24
  %t66 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t67 = load ptr, ptr %t66, !tbaa !27
  %t68 = getelementptr i64, ptr %t67, i64 %t64
  %t69 = load i64, ptr %t68, !tbaa !34
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t72 = load %"compiler/lower:pl", ptr %l10
  store { i64, [1 x i64] } zeroinitializer, ptr %t74
  %t75 = getelementptr { i64, [1 x i64] }, ptr %t74, i32 0, i32 0
  store i64 0, ptr %t75
  %t77 = insertvalue { i64 } undef, i64 %t69, 0
  %t78 = getelementptr { i64, [1 x i64] }, ptr %t74, i32 0, i32 1
  store { i64 } %t77, ptr %t78
  %t79 = load { i64, [1 x i64] }, ptr %t74
  %t83 = call %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2ewith(ptr %v0, ptr %s3, ptr %s3, ptr %t71, %"compiler/lower:pl" %t72, { i64, [1 x i64] } %t79)
  store %"compiler/lower:pl" %t83, ptr %l49
  br label %bb17
bb17:
  %t84 = load %"compiler/lower:pl", ptr %l49
  store %"compiler/lower:pl" %t84, ptr %l10
  call void @__olang_scope_close(ptr %s5)
  br label %bb18
bb18:
  %t85 = load i64, ptr %l12, !tbaa !24
  %t87 = add i64 %t85, 1
  store i64 %t87, ptr %l12, !tbaa !24
  br label %bb13
bb19:
  %t89 = load ptr, ptr %l0, !tbaa !29
  store ptr %t89, ptr %l52, !tbaa !29
  store %"compiler/source:Span" %a3, ptr %l53
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t92 = load %"compiler/lower:pl", ptr %l10
  %t95 = call %"compiler/mir:Place" @compiler_2flower_2ecompiler_2flower_3alowering_2emk(ptr %v0, ptr %s3, ptr %t91, %"compiler/lower:pl" %t92)
  store %"compiler/mir:Place" %t95, ptr %l56
  br label %bb20
bb20:
  store { i64, [21 x i64] } zeroinitializer, ptr %t96
  %t97 = getelementptr { i64, [21 x i64] }, ptr %t96, i32 0, i32 0
  store i64 8, ptr %t97
  %t98 = load %"compiler/source:Span", ptr %l53
  %t99 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place" } undef, %"compiler/source:Span" %t98, 0
  %t100 = load %"compiler/mir:Place", ptr %l56
  %t101 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place" } %t99, %"compiler/mir:Place" %t100, 1
  %t102 = getelementptr { i64, [21 x i64] }, ptr %t96, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Place" } %t101, ptr %t102
  %t103 = load { i64, [21 x i64] }, ptr %t96
  %t105 = call ptr @__olang_scope_alloc_a(ptr %s3, i64 176, i64 8)
  store { i64, [21 x i64] } %t103, ptr %t105
  %t106 = load ptr, ptr %l52, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s3, ptr %t106, ptr %t105)
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s3)
  br label %bb22
bb22:
  %t108 = load i64, ptr %l8, !tbaa !24
  %t110 = add i64 %t108, 1
  store i64 %t110, ptr %l8, !tbaa !24
  br label %bb8
bb23:
  %t112 = load i64, ptr %l5, !tbaa !24
  %t113 = load i64, ptr %l7, !tbaa !24
  %t116 = add i64 %t112, %t113
  store i64 %t116, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb24
bb24:
  br label %bb1
bb25:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2erenderAt(ptr %v0, ptr %v1, ptr %a0, %"compiler/lower:pl" %a1, i32 %a2, { i64, [1 x i64] } %a3, %"compiler/source:Span" %a4, i1 %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/lower:pl"
  %l2 = alloca i32
  %l3 = alloca { i64, [1 x i64] }
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca i1
  %l6 = alloca ptr
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca i32
  %l10 = alloca i32
  %l11 = alloca { i64, [4 x i64] }
  %l12 = alloca i32
  %l13 = alloca i32
  %l14 = alloca { i64, [4 x i64] }
  %l15 = alloca { i64, [4 x i64] }
  %l16 = alloca i32
  %l17 = alloca i32
  %l18 = alloca { i64, [4 x i64] }
  %l20 = alloca { i64, [4 x i64] }
  %l21 = alloca i32
  %l22 = alloca i32
  %l23 = alloca i32
  %l24 = alloca { { i64, ptr }, i1 }
  %l25 = alloca { i64, ptr }
  %l26 = alloca i1
  %l27 = alloca { { i64, ptr }, i1 }
  %l28 = alloca { i64, ptr }
  %l29 = alloca i1
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca { i64, ptr }
  %l37 = alloca { i64, [4 x i64] }
  %l38 = alloca { i64, ptr }
  %l39 = alloca i32
  %l40 = alloca { i64, ptr }
  %l41 = alloca { i64, ptr }
  %l42 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i64
  %l45 = alloca i64
  %l46 = alloca i64
  %l47 = alloca i64
  %l48 = alloca i64
  %l49 = alloca i64
  %l50 = alloca i64
  %l51 = alloca i64
  %l52 = alloca i64
  %l53 = alloca i64
  %l55 = alloca { i64, ptr }
  %l56 = alloca i64
  %l57 = alloca i64
  %l58 = alloca i64
  %l59 = alloca i64
  %l60 = alloca i64
  %l61 = alloca i64
  %l62 = alloca i32
  %l66 = alloca ptr
  %l69 = alloca i32
  %l70 = alloca i1
  %l71 = alloca ptr
  %l72 = alloca { i64, [1 x i64] }
  %l75 = alloca %"compiler/mir:Place"
  %l85 = alloca i1
  %l88 = alloca i32
  %l91 = alloca i1
  %l92 = alloca ptr
  %l95 = alloca %"compiler/mir:Place"
  %l99 = alloca i32
  %l102 = alloca i32
  %l105 = alloca i32
  %l108 = alloca i1
  %l111 = alloca ptr
  %l112 = alloca i32
  %l113 = alloca i32
  %l115 = alloca %"compiler/mir:Place"
  %l119 = alloca { i64, ptr }
  %l121 = alloca { i64, [4 x i64] }
  %l124 = alloca i32
  %l141 = alloca i32
  %l144 = alloca i32
  %l147 = alloca i1
  %l148 = alloca ptr
  %l151 = alloca i32
  %l152 = alloca i32
  %l155 = alloca ptr
  %l156 = alloca { i64, [1 x i64] }
  %l159 = alloca ptr
  %l160 = alloca ptr
  %l163 = alloca i32
  %l164 = alloca i32
  %l165 = alloca { i64, ptr }
  %l172 = alloca { i64, [4 x i64] }
  %l173 = alloca ptr
  %l174 = alloca i32
  %l175 = alloca i32
  %l176 = alloca { i64, [4 x i64] }
  %l178 = alloca { i64, [4 x i64] }
  %l179 = alloca { i64, ptr }
  %l181 = alloca { i64, [4 x i64] }
  %l184 = alloca i32
  %l187 = alloca i32
  %l204 = alloca ptr
  %l205 = alloca ptr
  %l206 = alloca i32
  %l207 = alloca i32
  %l208 = alloca { i64, [4 x i64] }
  %l210 = alloca { i64, [4 x i64] }
  %l211 = alloca { i64, ptr }
  %l213 = alloca { i64, [4 x i64] }
  %l214 = alloca ptr
  %l217 = alloca %"compiler/lower:pl"
  %l220 = alloca i32
  %l231 = alloca i32
  %l234 = alloca ptr
  %l237 = alloca %"compiler/mir:Place"
  %l241 = alloca i32
  %l242 = alloca ptr
  %l243 = alloca i32
  %l244 = alloca i32
  %l246 = alloca %"compiler/mir:Place"
  %l250 = alloca { i64, ptr }
  %l252 = alloca { i64, [4 x i64] }
  %l255 = alloca i32
  %l258 = alloca i32
  %l261 = alloca i32
  %l276 = alloca ptr
  %l277 = alloca { i64, [1 x i64] }
  %l282 = alloca { i64, ptr }
  %l291 = alloca ptr
  %l292 = alloca i32
  %l293 = alloca i32
  %l298 = alloca { i64, [4 x i64] }
  %l300 = alloca { i64, [4 x i64] }
  %l301 = alloca { i64, ptr }
  %l303 = alloca { i64, ptr }
  %l306 = alloca { i64, [4 x i64] }
  %l309 = alloca { { i64, ptr }, i1 }
  %l310 = alloca { i64, ptr }
  %l311 = alloca i64
  %l312 = alloca { i64, ptr }
  %l316 = alloca { { i64, ptr }, i1 }
  %l317 = alloca { i64, ptr }
  %l318 = alloca i64
  %l319 = alloca { i64, ptr }
  %l324 = alloca i32
  %l327 = alloca ptr
  %l328 = alloca { i64, [1 x i64] }
  %l331 = alloca ptr
  %l332 = alloca ptr
  %l335 = alloca i32
  %l336 = alloca i32
  %l337 = alloca { i64, ptr }
  %l347 = alloca i64
  %l350 = alloca i64
  %l373 = alloca ptr
  %l378 = alloca %"compiler/lower:pl"
  %l391 = alloca i32
  %l394 = alloca { i64, ptr }
  %l397 = alloca { i64, ptr }
  %l400 = alloca { i64, ptr }
  %l401 = alloca ptr
  %l402 = alloca i32
  %l405 = alloca %"compiler/mir:Place"
  %l408 = alloca { i64, [4 x i64] }
  %l411 = alloca i32
  %l415 = alloca { i64, ptr }
  %l418 = alloca ptr
  %l419 = alloca ptr
  %l422 = alloca i32
  %l423 = alloca i32
  %l424 = alloca { i64, ptr }
  %l429 = alloca i32
  %l431 = alloca i64
  %l432 = alloca %"compiler/mir:Case"
  %l434 = alloca %"compiler/mir:Case"
  %l439 = alloca i64
  %l448 = alloca i64
  %l451 = alloca i64
  %l469 = alloca i64
  %l472 = alloca i32
  %l473 = alloca i64
  %l477 = alloca %"compiler/mir:Case"
  %l480 = alloca ptr
  %l481 = alloca { i64, [4 x i64] }
  %l485 = alloca %"compiler/mir:Range"
  %l493 = alloca i64
  %l496 = alloca i64
  %l520 = alloca i1
  %l525 = alloca { i64, ptr }
  %l529 = alloca { i64, ptr }
  %l532 = alloca { i64, ptr }
  %l546 = alloca ptr
  %l550 = alloca i32
  %l551 = alloca { i64, ptr }
  %l563 = alloca i64
  %l566 = alloca i64
  %l589 = alloca ptr
  %l590 = alloca ptr
  %l595 = alloca %"compiler/lower:pl"
  %l598 = alloca %"compiler/lower:pl"
  %l616 = alloca i32
  %l619 = alloca ptr
  %l622 = alloca i32
  %l623 = alloca i32
  %l624 = alloca ptr
  %l625 = alloca { i64, [1 x i64] }
  %l626 = alloca ptr
  %l629 = alloca i32
  %l630 = alloca { i64, ptr }
  %l634 = alloca ptr
  %l635 = alloca i32
  %l636 = alloca i32
  %l639 = alloca %"compiler/mir:Place"
  %l641 = alloca { i64, ptr }
  %l643 = alloca { i64, [4 x i64] }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %s25 = alloca %olang.scope
  %s26 = alloca %olang.scope
  %s28 = alloca %olang.scope
  %s29 = alloca %olang.scope
  %s33 = alloca %olang.scope
  %s35 = alloca %olang.scope
  %t23 = alloca { i64, [4 x i64] }, align 8
  %t68 = alloca { i64, [4 x i64] }, align 8
  %t109 = alloca { i64, [4 x i64] }, align 8
  %t116 = alloca { i64, [4 x i64] }, align 8
  %t153 = alloca { i64, [8 x i64] }, align 8
  %t294 = alloca { i64, [8 x i64] }, align 8
  %t405 = alloca { i64, [4 x i64] }, align 8
  %t424 = alloca { i64, [4 x i64] }, align 8
  %t431 = alloca { i64, [4 x i64] }, align 8
  %t480 = alloca { i64, [8 x i64] }, align 8
  %t750 = alloca { i64, [1 x i64] }, align 8
  %t818 = alloca { i64, [15 x i64] }, align 8
  %t905 = alloca i64
  %t1022 = alloca { i64, [8 x i64] }, align 8
  %t1270 = alloca { i64, [1 x i64] }, align 8
  %t1281 = alloca { i64, [1 x i64] }, align 8
  %t1385 = alloca { i64, [4 x i64] }, align 8
  %t1417 = alloca { ptr, %"compiler/source:Span", { i64, [1 x i64] }, %"compiler/lower:pl", i32, ptr, ptr }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/lower:pl" %a1, ptr %l1
  store i32 %a2, ptr %l2
  store { i64, [1 x i64] } %a3, ptr %l3
  store %"compiler/source:Span" %a4, ptr %l4
  store i1 %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l6, !tbaa !29
  %t6 = load ptr, ptr %l6, !tbaa !29
  store ptr %t6, ptr %l66, !tbaa !29
  %t7 = load ptr, ptr %l6, !tbaa !29
  %t8 = load i32, ptr %l2, !tbaa !23
  %t11 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t7, i32 %t8)
  store i32 %t11, ptr %l69
  br label %bb1
bb1:
  %t12 = load ptr, ptr %l66, !tbaa !29
  %t13 = load i32, ptr %l69, !tbaa !23
  %t14 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsAny(ptr %v0, ptr %t12, i32 %t13)
  store i1 %t14, ptr %l70
  br label %bb2
bb2:
  %t15 = load i1, ptr %l70, !tbaa !21
  br i1 %t15, label %bb3, label %bb4
bb3:
  %t16 = load ptr, ptr %l0, !tbaa !29
  store ptr %t16, ptr %l71, !tbaa !29
  %t17 = load { i64, [1 x i64] }, ptr %l3
  store { i64, [1 x i64] } %t17, ptr %l72
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t19 = load %"compiler/lower:pl", ptr %l1
  %t22 = call %"compiler/mir:Place" @compiler_2flower_2ecompiler_2flower_3alowering_2emk(ptr %v0, ptr %v1, ptr %t18, %"compiler/lower:pl" %t19)
  store %"compiler/mir:Place" %t22, ptr %l75
  br label %bb5
bb4:
  br label %bb7
bb5:
  store { i64, [4 x i64] } zeroinitializer, ptr %t23
  %t24 = getelementptr { i64, [4 x i64] }, ptr %t23, i32 0, i32 0
  store i64 1, ptr %t24
  %t25 = load %"compiler/mir:Place", ptr %l75
  %t26 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t25, 0
  %t27 = getelementptr { i64, [4 x i64] }, ptr %t23, i32 0, i32 1
  store { %"compiler/mir:Place" } %t26, ptr %t27
  %t28 = load { i64, [4 x i64] }, ptr %t23
  %t29 = load i32, ptr %l2, !tbaa !23
  %t30 = load i1, ptr %l5, !tbaa !21
  %t31 = load %"compiler/source:Span", ptr %l4
  %t32 = load ptr, ptr %l71, !tbaa !29
  %t33 = load { i64, [1 x i64] }, ptr %l72
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2erenderAny(ptr %v0, ptr %t32, { i64, [1 x i64] } %t33, { i64, [4 x i64] } %t28, i32 %t29, i1 %t30, %"compiler/source:Span" %t31)
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb7:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t39 = load %"compiler/lower:pl", ptr %l1
  %t40 = load i32, ptr %l2, !tbaa !23
  %t41 = load { i64, [1 x i64] }, ptr %l3
  %t42 = load %"compiler/source:Span", ptr %l4
  %t48 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2erenderStr(ptr %v0, ptr %v1, ptr %t38, %"compiler/lower:pl" %t39, i32 %t40, { i64, [1 x i64] } %t41, %"compiler/source:Span" %t42)
  store i1 %t48, ptr %l85
  br label %bb8
bb8:
  %t49 = load i1, ptr %l85, !tbaa !21
  br i1 %t49, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb10:
  br label %bb11
bb11:
  %t50 = load ptr, ptr %l6, !tbaa !29
  %t51 = load i32, ptr %l2, !tbaa !23
  %t54 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t50, i32 %t51)
  store i32 %t54, ptr %l88
  br label %bb12
bb12:
  %t55 = load i32, ptr %l88, !tbaa !23
  store i32 %t55, ptr %l7, !tbaa !23
  %t56 = load ptr, ptr %l6, !tbaa !29
  %t57 = load i32, ptr %l7, !tbaa !23
  %t60 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t56, i32 %t57)
  store i1 %t60, ptr %l91
  br label %bb13
bb13:
  %t61 = load i1, ptr %l91, !tbaa !21
  br i1 %t61, label %bb14, label %bb15
bb14:
  store %olang.scope zeroinitializer, ptr %s3
  %t62 = load ptr, ptr %l0, !tbaa !29
  store ptr %t62, ptr %l92, !tbaa !29
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t64 = load %"compiler/lower:pl", ptr %l1
  %t67 = call %"compiler/mir:Place" @compiler_2flower_2ecompiler_2flower_3alowering_2emk(ptr %v0, ptr %v1, ptr %t63, %"compiler/lower:pl" %t64)
  store %"compiler/mir:Place" %t67, ptr %l95
  br label %bb16
bb15:
  br label %bb66
bb16:
  store { i64, [4 x i64] } zeroinitializer, ptr %t68
  %t69 = getelementptr { i64, [4 x i64] }, ptr %t68, i32 0, i32 0
  store i64 1, ptr %t69
  %t70 = load %"compiler/mir:Place", ptr %l95
  %t71 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t70, 0
  %t72 = getelementptr { i64, [4 x i64] }, ptr %t68, i32 0, i32 1
  store { %"compiler/mir:Place" } %t71, ptr %t72
  %t73 = load { i64, [4 x i64] }, ptr %t68
  %t74 = load i32, ptr %l2, !tbaa !23
  %t75 = load %"compiler/source:Span", ptr %l4
  %t76 = load ptr, ptr %l92, !tbaa !29
  %t80 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2elocal(ptr %v0, ptr %t76, { i64, [4 x i64] } %t73, i32 %t74, %"compiler/source:Span" %t75)
  store i32 %t80, ptr %l99
  br label %bb17
bb17:
  %t81 = load i32, ptr %l99, !tbaa !23
  store i32 %t81, ptr %l8, !tbaa !23
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/lower:lowering", ptr %t82, i32 0, i32 3
  %t86 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t84)
  store i32 %t86, ptr %l102
  br label %bb18
bb18:
  %t87 = load i32, ptr %l102, !tbaa !23
  store i32 %t87, ptr %l9, !tbaa !23
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t90 = getelementptr %"compiler/lower:lowering", ptr %t88, i32 0, i32 3
  %t92 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t90)
  store i32 %t92, ptr %l105
  br label %bb19
bb19:
  %t93 = load i32, ptr %l105, !tbaa !23
  store i32 %t93, ptr %l10, !tbaa !23
  %t94 = load ptr, ptr %l6, !tbaa !29
  %t95 = load i32, ptr %l7, !tbaa !23
  %t98 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArrayRef(ptr %v0, ptr %t94, i32 %t95)
  store i1 %t98, ptr %l108
  br label %bb20
bb20:
  %t99 = load i1, ptr %l108, !tbaa !21
  br i1 %t99, label %bb21, label %bb22
bb21:
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t101 = load i32, ptr %l9, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2egoto(ptr %v0, ptr %t100, i32 %t101)
  br label %bb23
bb22:
  store %olang.scope zeroinitializer, ptr %s5
  %t104 = load ptr, ptr %l0, !tbaa !29
  store ptr %t104, ptr %l111, !tbaa !29
  store i32 14, ptr %l112
  %t105 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t105, ptr %l113, !tbaa !23
  %t106 = load i32, ptr %l8, !tbaa !23
  %t108 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t106)
  store %"compiler/mir:Place" %t108, ptr %l115
  br label %bb24
bb23:
  br label %bb31
bb24:
  store { i64, [4 x i64] } zeroinitializer, ptr %t109
  %t110 = getelementptr { i64, [4 x i64] }, ptr %t109, i32 0, i32 0
  store i64 1, ptr %t110
  %t111 = load %"compiler/mir:Place", ptr %l115
  %t112 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t111, 0
  %t113 = getelementptr { i64, [4 x i64] }, ptr %t109, i32 0, i32 1
  store { %"compiler/mir:Place" } %t112, ptr %t113
  %t114 = load { i64, [4 x i64] }, ptr %t109
  %t115 = load i32, ptr %l2, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t116
  %t117 = getelementptr { i64, [4 x i64] }, ptr %t116, i32 0, i32 0
  store i64 2, ptr %t117
  %t119 = insertvalue { i32, i64 } undef, i32 %t115, 0
  %t120 = insertvalue { i32, i64 } %t119, i64 0, 1
  %t121 = getelementptr { i64, [4 x i64] }, ptr %t116, i32 0, i32 1
  store { i32, i64 } %t120, ptr %t121
  %t122 = load { i64, [4 x i64] }, ptr %t116
  %t123 = mul i64 2, 40
  %t124 = call ptr @__olang_scope_alloc_zeroed(ptr %s5, i64 %t123)
  %t125 = insertvalue { i64, ptr } undef, i64 2, 0
  %t126 = insertvalue { i64, ptr } %t125, ptr %t124, 1
  store { i64, ptr } %t126, ptr %l119, !tbaa !27
  %t128 = getelementptr { i64, ptr }, ptr %l119, i32 0, i32 1
  %t129 = load ptr, ptr %t128, !tbaa !27
  %t130 = getelementptr { i64, [4 x i64] }, ptr %t129, i64 0
  store { i64, [4 x i64] } %t114, ptr %t130
  %t132 = getelementptr { i64, ptr }, ptr %l119, i32 0, i32 1
  %t133 = load ptr, ptr %t132, !tbaa !27
  %t134 = getelementptr { i64, [4 x i64] }, ptr %t133, i64 1
  store { i64, [4 x i64] } %t122, ptr %t134
  %t135 = load %"compiler/source:Span", ptr %l4
  %t136 = load ptr, ptr %l111, !tbaa !29
  %t137 = load i32, ptr %l112
  %t138 = load i32, ptr %l113, !tbaa !23
  %t139 = load { i64, ptr }, ptr %l119, !tbaa !27
  %t141 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s5, ptr %t136, i32 %t137, i32 %t138, { i64, ptr } %t139, %"compiler/source:Span" %t135)
  store { i64, [4 x i64] } %t141, ptr %l121
  br label %bb25
bb25:
  %t142 = load { i64, [4 x i64] }, ptr %l121
  store { i64, [4 x i64] } %t142, ptr %l11
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t145 = getelementptr %"compiler/lower:lowering", ptr %t143, i32 0, i32 3
  %t147 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t145)
  store i32 %t147, ptr %l124
  br label %bb26
bb26:
  %t148 = load i32, ptr %l124, !tbaa !23
  store i32 %t148, ptr %l12, !tbaa !23
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t150 = load { i64, [4 x i64] }, ptr %l11
  %t151 = load i32, ptr %l9, !tbaa !23
  %t152 = load i32, ptr %l12, !tbaa !23
  store { i64, [8 x i64] } zeroinitializer, ptr %t153
  %t154 = getelementptr { i64, [8 x i64] }, ptr %t153, i32 0, i32 0
  store i64 2, ptr %t154
  %t156 = insertvalue { { i64, [4 x i64] }, i32, i32 } undef, { i64, [4 x i64] } %t150, 0
  %t158 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t156, i32 %t151, 1
  %t160 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t158, i32 %t152, 2
  %t161 = getelementptr { i64, [8 x i64] }, ptr %t153, i32 0, i32 1
  store { { i64, [4 x i64] }, i32, i32 } %t160, ptr %t161
  %t162 = load { i64, [8 x i64] }, ptr %t153
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t149, { i64, [8 x i64] } %t162)
  br label %bb27
bb27:
  %t165 = load ptr, ptr %l0, !tbaa !29
  %t166 = load i32, ptr %l12, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t165, i32 %t166)
  br label %bb28
bb28:
  %t169 = load ptr, ptr %l0, !tbaa !29
  %t170 = load { i64, [1 x i64] }, ptr %l3
  %t171 = load %"compiler/source:Span", ptr %l4
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eword(ptr %v0, ptr %s5, ptr %t169, { i64, [1 x i64] } %t170, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d16, i32 0, i32 1) }, %"compiler/source:Span" %t171)
  br label %bb29
bb29:
  %t175 = load ptr, ptr %l0, !tbaa !29
  %t176 = load i32, ptr %l10, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2egoto(ptr %v0, ptr %t175, i32 %t176)
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s5)
  br label %bb31
bb31:
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t180 = load i32, ptr %l9, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t179, i32 %t180)
  br label %bb32
bb32:
  %t183 = load ptr, ptr %l6, !tbaa !29
  %t184 = load i32, ptr %l7, !tbaa !23
  %t187 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t183, i32 %t184)
  store i32 %t187, ptr %l141
  br label %bb33
bb33:
  %t188 = load i32, ptr %l141, !tbaa !23
  store i32 %t188, ptr %l13, !tbaa !23
  %t189 = load ptr, ptr %l6, !tbaa !29
  %t190 = load i32, ptr %l13, !tbaa !23
  %t193 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t189, i32 %t190)
  store i32 %t193, ptr %l144
  br label %bb34
bb34:
  %t194 = load i32, ptr %l144
  %t196 = trunc i64 18 to i32
  %t197 = icmp eq i32 %t194, %t196
  br i1 %t197, label %bb35, label %bb36
bb35:
  %t199 = load ptr, ptr %l6, !tbaa !29
  store ptr %t199, ptr %l148, !tbaa !29
  %t200 = load ptr, ptr %l6, !tbaa !29
  %t201 = load i32, ptr %l13, !tbaa !23
  %t204 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t200, i32 %t201)
  store i32 %t204, ptr %l151
  br label %bb37
bb36:
  store i1 false, ptr %l147, !tbaa !21
  br label %bb39
bb37:
  %t205 = load ptr, ptr %l148, !tbaa !29
  %t206 = load i32, ptr %l151, !tbaa !23
  %t207 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t205, i32 %t206)
  store i32 %t207, ptr %l152
  br label %bb38
bb38:
  %t208 = load i32, ptr %l152
  %t210 = trunc i64 5 to i32
  %t211 = icmp eq i32 %t208, %t210
  store i1 %t211, ptr %l147, !tbaa !21
  br label %bb39
bb39:
  %t213 = load i1, ptr %l147, !tbaa !21
  br i1 %t213, label %bb40, label %bb41
bb40:
  %t214 = load ptr, ptr %l0, !tbaa !29
  store ptr %t214, ptr %l155, !tbaa !29
  %t215 = load { i64, [1 x i64] }, ptr %l3
  store { i64, [1 x i64] } %t215, ptr %l156
  %t216 = load ptr, ptr %l0, !tbaa !29
  %t218 = getelementptr %"compiler/lower:lowering", ptr %t216, i32 0, i32 2
  %t219 = load ptr, ptr %t218, !tbaa !29
  %t221 = getelementptr %"compiler/types:Table", ptr %t219, i32 0, i32 0
  %t222 = load ptr, ptr %t221, !tbaa !29
  store ptr %t222, ptr %l159, !tbaa !29
  %t223 = load ptr, ptr %l6, !tbaa !29
  store ptr %t223, ptr %l160, !tbaa !29
  %t224 = load ptr, ptr %l6, !tbaa !29
  %t225 = load i32, ptr %l13, !tbaa !23
  %t228 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t224, i32 %t225)
  store i32 %t228, ptr %l163
  br label %bb42
bb41:
  br label %bb48
bb42:
  %t229 = load ptr, ptr %l160, !tbaa !29
  %t230 = load i32, ptr %l163, !tbaa !23
  %t231 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %t229, i32 %t230)
  store i32 %t231, ptr %l164
  br label %bb43
bb43:
  %t232 = load ptr, ptr %l159, !tbaa !29
  %t233 = load i32, ptr %l164, !tbaa !23
  %t234 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t232, i32 %t233)
  store { i64, ptr } %t234, ptr %l165
  br label %bb44
bb44:
  %t235 = load %"compiler/source:Span", ptr %l4
  %t236 = load ptr, ptr %l155, !tbaa !29
  %t237 = load { i64, [1 x i64] }, ptr %l156
  %t238 = load { i64, ptr }, ptr %l165, !tbaa !27
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eword(ptr %v0, ptr %v0, ptr %t236, { i64, [1 x i64] } %t237, { i64, ptr } %t238, %"compiler/source:Span" %t235)
  br label %bb45
bb45:
  %t240 = load ptr, ptr %l0, !tbaa !29
  %t241 = load i32, ptr %l10, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2egoto(ptr %v0, ptr %t240, i32 %t241)
  br label %bb46
bb46:
  %t244 = load ptr, ptr %l0, !tbaa !29
  %t245 = load i32, ptr %l10, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t244, i32 %t245)
  br label %bb47
bb47:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb48:
  %t248 = load ptr, ptr %l0, !tbaa !29
  %t250 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2edepth(ptr %v0, ptr %t248)
  store { i64, [4 x i64] } %t250, ptr %l172
  br label %bb49
bb49:
  %t251 = load { i64, [4 x i64] }, ptr %l172
  store { i64, [4 x i64] } %t251, ptr %l14
  %t252 = load ptr, ptr %l0, !tbaa !29
  store ptr %t252, ptr %l173, !tbaa !29
  store i32 18, ptr %l174
  %t253 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t253, ptr %l175, !tbaa !23
  %t254 = load { i64, [4 x i64] }, ptr %l14
  store { i64, [4 x i64] } %t254, ptr %l176
  %t255 = load ptr, ptr %l0, !tbaa !29
  %t257 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2econstI64(ptr %v0, ptr %t255, i64 8)
  store { i64, [4 x i64] } %t257, ptr %l178
  br label %bb50
bb50:
  %t258 = mul i64 2, 40
  %t259 = call ptr @__olang_scope_alloc_zeroed(ptr %s3, i64 %t258)
  %t260 = insertvalue { i64, ptr } undef, i64 2, 0
  %t261 = insertvalue { i64, ptr } %t260, ptr %t259, 1
  store { i64, ptr } %t261, ptr %l179, !tbaa !27
  %t262 = load { i64, [4 x i64] }, ptr %l176
  %t263 = getelementptr { i64, ptr }, ptr %l179, i32 0, i32 1
  %t264 = load ptr, ptr %t263, !tbaa !27
  %t265 = getelementptr { i64, [4 x i64] }, ptr %t264, i64 0
  store { i64, [4 x i64] } %t262, ptr %t265
  %t266 = load { i64, [4 x i64] }, ptr %l178
  %t267 = getelementptr { i64, ptr }, ptr %l179, i32 0, i32 1
  %t268 = load ptr, ptr %t267, !tbaa !27
  %t269 = getelementptr { i64, [4 x i64] }, ptr %t268, i64 1
  store { i64, [4 x i64] } %t266, ptr %t269
  %t270 = load %"compiler/source:Span", ptr %l4
  %t271 = load ptr, ptr %l173, !tbaa !29
  %t272 = load i32, ptr %l174
  %t273 = load i32, ptr %l175, !tbaa !23
  %t274 = load { i64, ptr }, ptr %l179, !tbaa !27
  %t276 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s3, ptr %t271, i32 %t272, i32 %t273, { i64, ptr } %t274, %"compiler/source:Span" %t270)
  store { i64, [4 x i64] } %t276, ptr %l181
  br label %bb51
bb51:
  %t277 = load { i64, [4 x i64] }, ptr %l181
  store { i64, [4 x i64] } %t277, ptr %l15
  %t278 = load ptr, ptr %l0, !tbaa !29
  %t280 = getelementptr %"compiler/lower:lowering", ptr %t278, i32 0, i32 3
  %t282 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t280)
  store i32 %t282, ptr %l184
  br label %bb52
bb52:
  %t283 = load i32, ptr %l184, !tbaa !23
  store i32 %t283, ptr %l16, !tbaa !23
  %t284 = load ptr, ptr %l0, !tbaa !29
  %t286 = getelementptr %"compiler/lower:lowering", ptr %t284, i32 0, i32 3
  %t288 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t286)
  store i32 %t288, ptr %l187
  br label %bb53
bb53:
  %t289 = load i32, ptr %l187, !tbaa !23
  store i32 %t289, ptr %l17, !tbaa !23
  %t290 = load ptr, ptr %l0, !tbaa !29
  %t291 = load { i64, [4 x i64] }, ptr %l15
  %t292 = load i32, ptr %l16, !tbaa !23
  %t293 = load i32, ptr %l17, !tbaa !23
  store { i64, [8 x i64] } zeroinitializer, ptr %t294
  %t295 = getelementptr { i64, [8 x i64] }, ptr %t294, i32 0, i32 0
  store i64 2, ptr %t295
  %t297 = insertvalue { { i64, [4 x i64] }, i32, i32 } undef, { i64, [4 x i64] } %t291, 0
  %t299 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t297, i32 %t292, 1
  %t301 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t299, i32 %t293, 2
  %t302 = getelementptr { i64, [8 x i64] }, ptr %t294, i32 0, i32 1
  store { { i64, [4 x i64] }, i32, i32 } %t301, ptr %t302
  %t303 = load { i64, [8 x i64] }, ptr %t294
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t290, { i64, [8 x i64] } %t303)
  br label %bb54
bb54:
  %t306 = load ptr, ptr %l0, !tbaa !29
  %t307 = load i32, ptr %l16, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t306, i32 %t307)
  br label %bb55
bb55:
  %t310 = load ptr, ptr %l0, !tbaa !29
  %t311 = load { i64, [1 x i64] }, ptr %l3
  %t312 = load %"compiler/source:Span", ptr %l4
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eword(ptr %v0, ptr %s3, ptr %t310, { i64, [1 x i64] } %t311, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d17, i32 0, i32 1) }, %"compiler/source:Span" %t312)
  br label %bb56
bb56:
  %t316 = load ptr, ptr %l0, !tbaa !29
  %t317 = load i32, ptr %l10, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2egoto(ptr %v0, ptr %t316, i32 %t317)
  br label %bb57
bb57:
  %t320 = load ptr, ptr %l0, !tbaa !29
  %t321 = load i32, ptr %l17, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t320, i32 %t321)
  br label %bb58
bb58:
  %t324 = load ptr, ptr %l0, !tbaa !29
  %t326 = getelementptr %"compiler/lower:lowering", ptr %t324, i32 0, i32 5
  %t327 = load { i64, [4 x i64] }, ptr %t326
  store { i64, [4 x i64] } %t327, ptr %l18
  %t329 = load ptr, ptr %l0, !tbaa !29
  store ptr %t329, ptr %l204, !tbaa !29
  %t330 = load ptr, ptr %l0, !tbaa !29
  store ptr %t330, ptr %l205, !tbaa !29
  store i32 3, ptr %l206
  %t331 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  store i32 %t331, ptr %l207, !tbaa !23
  %t332 = load { i64, [4 x i64] }, ptr %l14
  store { i64, [4 x i64] } %t332, ptr %l208
  %t333 = load ptr, ptr %l0, !tbaa !29
  %t335 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2econstI64(ptr %v0, ptr %t333, i64 1)
  store { i64, [4 x i64] } %t335, ptr %l210
  br label %bb59
bb59:
  %t336 = mul i64 2, 40
  %t337 = call ptr @__olang_scope_alloc_zeroed(ptr %s3, i64 %t336)
  %t338 = insertvalue { i64, ptr } undef, i64 2, 0
  %t339 = insertvalue { i64, ptr } %t338, ptr %t337, 1
  store { i64, ptr } %t339, ptr %l211, !tbaa !27
  %t340 = load { i64, [4 x i64] }, ptr %l208
  %t341 = getelementptr { i64, ptr }, ptr %l211, i32 0, i32 1
  %t342 = load ptr, ptr %t341, !tbaa !27
  %t343 = getelementptr { i64, [4 x i64] }, ptr %t342, i64 0
  store { i64, [4 x i64] } %t340, ptr %t343
  %t344 = load { i64, [4 x i64] }, ptr %l210
  %t345 = getelementptr { i64, ptr }, ptr %l211, i32 0, i32 1
  %t346 = load ptr, ptr %t345, !tbaa !27
  %t347 = getelementptr { i64, [4 x i64] }, ptr %t346, i64 1
  store { i64, [4 x i64] } %t344, ptr %t347
  %t348 = load %"compiler/source:Span", ptr %l4
  %t349 = load ptr, ptr %l205, !tbaa !29
  %t350 = load i32, ptr %l206
  %t351 = load i32, ptr %l207, !tbaa !23
  %t352 = load { i64, ptr }, ptr %l211, !tbaa !27
  %t354 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s3, ptr %t349, i32 %t350, i32 %t351, { i64, ptr } %t352, %"compiler/source:Span" %t348)
  store { i64, [4 x i64] } %t354, ptr %l213
  br label %bb60
bb60:
  %t355 = load { i64, [4 x i64] }, ptr %l213
  %t356 = load ptr, ptr %l204, !tbaa !29
  %t357 = getelementptr %"compiler/lower:lowering", ptr %t356, i32 0, i32 5
  store { i64, [4 x i64] } %t355, ptr %t357
  %t358 = load ptr, ptr %l0, !tbaa !29
  store ptr %t358, ptr %l214, !tbaa !29
  %t359 = load ptr, ptr %l0, !tbaa !29
  %t360 = load i32, ptr %l8, !tbaa !23
  %t363 = call %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2eat(ptr %v0, ptr %s3, ptr %t359, i32 %t360)
  store %"compiler/lower:pl" %t363, ptr %l217
  br label %bb61
bb61:
  %t364 = load ptr, ptr %l6, !tbaa !29
  %t365 = load i32, ptr %l7, !tbaa !23
  %t368 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t364, i32 %t365)
  store i32 %t368, ptr %l220
  br label %bb62
bb62:
  %t369 = load { i64, [1 x i64] }, ptr %l3
  %t370 = load %"compiler/source:Span", ptr %l4
  %t371 = load ptr, ptr %l214, !tbaa !29
  %t372 = load %"compiler/lower:pl", ptr %l217
  %t373 = load i32, ptr %l220, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2einner(ptr %v0, ptr %s3, ptr %t371, %"compiler/lower:pl" %t372, i32 %t373, { i64, [1 x i64] } %t369, %"compiler/source:Span" %t370)
  br label %bb63
bb63:
  %t376 = load ptr, ptr %l0, !tbaa !29
  %t377 = load { i64, [4 x i64] }, ptr %l18
  %t380 = getelementptr %"compiler/lower:lowering", ptr %t376, i32 0, i32 5
  store { i64, [4 x i64] } %t377, ptr %t380
  %t381 = load ptr, ptr %l0, !tbaa !29
  %t382 = load i32, ptr %l10, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2egoto(ptr %v0, ptr %t381, i32 %t382)
  br label %bb64
bb64:
  %t385 = load ptr, ptr %l0, !tbaa !29
  %t386 = load i32, ptr %l10, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t385, i32 %t386)
  br label %bb65
bb65:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb66:
  %t389 = load ptr, ptr %l6, !tbaa !29
  %t390 = load i32, ptr %l7, !tbaa !23
  %t393 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t389, i32 %t390)
  store i32 %t393, ptr %l231
  br label %bb67
bb67:
  %t394 = load i32, ptr %l231
  %t396 = trunc i64 21 to i32
  %t397 = icmp eq i32 %t394, %t396
  br i1 %t397, label %bb68, label %bb69
bb68:
  store %olang.scope zeroinitializer, ptr %s7
  %t399 = load ptr, ptr %l0, !tbaa !29
  store ptr %t399, ptr %l234, !tbaa !29
  %t400 = load ptr, ptr %l0, !tbaa !29
  %t401 = load %"compiler/lower:pl", ptr %l1
  %t404 = call %"compiler/mir:Place" @compiler_2flower_2ecompiler_2flower_3alowering_2emk(ptr %v0, ptr %v1, ptr %t400, %"compiler/lower:pl" %t401)
  store %"compiler/mir:Place" %t404, ptr %l237
  br label %bb70
bb69:
  br label %bb86
bb70:
  store { i64, [4 x i64] } zeroinitializer, ptr %t405
  %t406 = getelementptr { i64, [4 x i64] }, ptr %t405, i32 0, i32 0
  store i64 1, ptr %t406
  %t407 = load %"compiler/mir:Place", ptr %l237
  %t408 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t407, 0
  %t409 = getelementptr { i64, [4 x i64] }, ptr %t405, i32 0, i32 1
  store { %"compiler/mir:Place" } %t408, ptr %t409
  %t410 = load { i64, [4 x i64] }, ptr %t405
  %t411 = load i32, ptr %l2, !tbaa !23
  %t412 = load %"compiler/source:Span", ptr %l4
  %t413 = load ptr, ptr %l234, !tbaa !29
  %t417 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2elocal(ptr %v0, ptr %t413, { i64, [4 x i64] } %t410, i32 %t411, %"compiler/source:Span" %t412)
  store i32 %t417, ptr %l241
  br label %bb71
bb71:
  %t418 = load i32, ptr %l241, !tbaa !23
  %t419 = load ptr, ptr %l0, !tbaa !29
  store ptr %t419, ptr %l242, !tbaa !29
  store i32 14, ptr %l243
  %t420 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t420, ptr %l244, !tbaa !23
  %t423 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t418)
  store %"compiler/mir:Place" %t423, ptr %l246
  br label %bb72
bb72:
  store { i64, [4 x i64] } zeroinitializer, ptr %t424
  %t425 = getelementptr { i64, [4 x i64] }, ptr %t424, i32 0, i32 0
  store i64 1, ptr %t425
  %t426 = load %"compiler/mir:Place", ptr %l246
  %t427 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t426, 0
  %t428 = getelementptr { i64, [4 x i64] }, ptr %t424, i32 0, i32 1
  store { %"compiler/mir:Place" } %t427, ptr %t428
  %t429 = load { i64, [4 x i64] }, ptr %t424
  %t430 = load i32, ptr %l2, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t431
  %t432 = getelementptr { i64, [4 x i64] }, ptr %t431, i32 0, i32 0
  store i64 2, ptr %t432
  %t434 = insertvalue { i32, i64 } undef, i32 %t430, 0
  %t435 = insertvalue { i32, i64 } %t434, i64 0, 1
  %t436 = getelementptr { i64, [4 x i64] }, ptr %t431, i32 0, i32 1
  store { i32, i64 } %t435, ptr %t436
  %t437 = load { i64, [4 x i64] }, ptr %t431
  %t438 = mul i64 2, 40
  %t439 = call ptr @__olang_scope_alloc_zeroed(ptr %s7, i64 %t438)
  %t440 = insertvalue { i64, ptr } undef, i64 2, 0
  %t441 = insertvalue { i64, ptr } %t440, ptr %t439, 1
  store { i64, ptr } %t441, ptr %l250, !tbaa !27
  %t443 = getelementptr { i64, ptr }, ptr %l250, i32 0, i32 1
  %t444 = load ptr, ptr %t443, !tbaa !27
  %t445 = getelementptr { i64, [4 x i64] }, ptr %t444, i64 0
  store { i64, [4 x i64] } %t429, ptr %t445
  %t447 = getelementptr { i64, ptr }, ptr %l250, i32 0, i32 1
  %t448 = load ptr, ptr %t447, !tbaa !27
  %t449 = getelementptr { i64, [4 x i64] }, ptr %t448, i64 1
  store { i64, [4 x i64] } %t437, ptr %t449
  %t450 = load %"compiler/source:Span", ptr %l4
  %t451 = load ptr, ptr %l242, !tbaa !29
  %t452 = load i32, ptr %l243
  %t453 = load i32, ptr %l244, !tbaa !23
  %t454 = load { i64, ptr }, ptr %l250, !tbaa !27
  %t456 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s7, ptr %t451, i32 %t452, i32 %t453, { i64, ptr } %t454, %"compiler/source:Span" %t450)
  store { i64, [4 x i64] } %t456, ptr %l252
  br label %bb73
bb73:
  %t457 = load { i64, [4 x i64] }, ptr %l252
  store { i64, [4 x i64] } %t457, ptr %l20
  %t458 = load ptr, ptr %l0, !tbaa !29
  %t460 = getelementptr %"compiler/lower:lowering", ptr %t458, i32 0, i32 3
  %t462 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t460)
  store i32 %t462, ptr %l255
  br label %bb74
bb74:
  %t463 = load i32, ptr %l255, !tbaa !23
  store i32 %t463, ptr %l21, !tbaa !23
  %t464 = load ptr, ptr %l0, !tbaa !29
  %t466 = getelementptr %"compiler/lower:lowering", ptr %t464, i32 0, i32 3
  %t468 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t466)
  store i32 %t468, ptr %l258
  br label %bb75
bb75:
  %t469 = load i32, ptr %l258, !tbaa !23
  store i32 %t469, ptr %l22, !tbaa !23
  %t470 = load ptr, ptr %l0, !tbaa !29
  %t472 = getelementptr %"compiler/lower:lowering", ptr %t470, i32 0, i32 3
  %t474 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t472)
  store i32 %t474, ptr %l261
  br label %bb76
bb76:
  %t475 = load i32, ptr %l261, !tbaa !23
  store i32 %t475, ptr %l23, !tbaa !23
  %t476 = load ptr, ptr %l0, !tbaa !29
  %t477 = load { i64, [4 x i64] }, ptr %l20
  %t478 = load i32, ptr %l21, !tbaa !23
  %t479 = load i32, ptr %l22, !tbaa !23
  store { i64, [8 x i64] } zeroinitializer, ptr %t480
  %t481 = getelementptr { i64, [8 x i64] }, ptr %t480, i32 0, i32 0
  store i64 2, ptr %t481
  %t483 = insertvalue { { i64, [4 x i64] }, i32, i32 } undef, { i64, [4 x i64] } %t477, 0
  %t485 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t483, i32 %t478, 1
  %t487 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t485, i32 %t479, 2
  %t488 = getelementptr { i64, [8 x i64] }, ptr %t480, i32 0, i32 1
  store { { i64, [4 x i64] }, i32, i32 } %t487, ptr %t488
  %t489 = load { i64, [8 x i64] }, ptr %t480
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t476, { i64, [8 x i64] } %t489)
  br label %bb77
bb77:
  %t492 = load ptr, ptr %l0, !tbaa !29
  %t493 = load i32, ptr %l22, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t492, i32 %t493)
  br label %bb78
bb78:
  %t496 = load ptr, ptr %l0, !tbaa !29
  %t497 = load { i64, [1 x i64] }, ptr %l3
  %t498 = load %"compiler/source:Span", ptr %l4
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eword(ptr %v0, ptr %s7, ptr %t496, { i64, [1 x i64] } %t497, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d18, i32 0, i32 1) }, %"compiler/source:Span" %t498)
  br label %bb79
bb79:
  %t502 = load ptr, ptr %l0, !tbaa !29
  %t503 = load i32, ptr %l23, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2egoto(ptr %v0, ptr %t502, i32 %t503)
  br label %bb80
bb80:
  %t506 = load ptr, ptr %l0, !tbaa !29
  %t507 = load i32, ptr %l21, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t506, i32 %t507)
  br label %bb81
bb81:
  %t510 = load ptr, ptr %l0, !tbaa !29
  store ptr %t510, ptr %l276, !tbaa !29
  %t511 = load { i64, [1 x i64] }, ptr %l3
  store { i64, [1 x i64] } %t511, ptr %l277
  %t512 = load ptr, ptr %l0, !tbaa !29
  %t513 = load i32, ptr %l2, !tbaa !23
  %t514 = load i1, ptr %l5, !tbaa !21
  %t516 = xor i1 %t514, true
  %t520 = call { i64, ptr } @compiler_2flower_2ecompiler_2flower_3alowering_2espell(ptr %v0, ptr %s7, ptr %t512, i32 %t513, i1 true, i1 %t516, i1 false)
  store { i64, ptr } %t520, ptr %l282
  br label %bb82
bb82:
  %t521 = load { i64, ptr }, ptr %l282, !tbaa !27
  %t522 = extractvalue { i64, ptr } %t521, 0
  %t523 = extractvalue { i64, ptr } %t521, 1
  %t524 = mul i64 %t522, 1
  %t525 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t524)
  call void @llvm.memcpy.p0.p0.i64(ptr %t525, ptr %t523, i64 %t524, i1 false)
  %t526 = insertvalue { i64, ptr } undef, i64 %t522, 0
  %t527 = insertvalue { i64, ptr } %t526, ptr %t525, 1
  %t528 = load %"compiler/source:Span", ptr %l4
  %t529 = load ptr, ptr %l276, !tbaa !29
  %t530 = load { i64, [1 x i64] }, ptr %l277
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eword(ptr %v0, ptr %s7, ptr %t529, { i64, [1 x i64] } %t530, { i64, ptr } %t527, %"compiler/source:Span" %t528)
  br label %bb83
bb83:
  %t533 = load ptr, ptr %l0, !tbaa !29
  %t534 = load i32, ptr %l23, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2egoto(ptr %v0, ptr %t533, i32 %t534)
  br label %bb84
bb84:
  %t537 = load ptr, ptr %l0, !tbaa !29
  %t538 = load i32, ptr %l23, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t537, i32 %t538)
  br label %bb85
bb85:
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb86:
  %t541 = load i1, ptr %l5, !tbaa !21
  %t543 = xor i1 %t541, true
  br i1 %t543, label %bb87, label %bb88
bb87:
  store %olang.scope zeroinitializer, ptr %s8
  %t545 = load ptr, ptr %l0, !tbaa !29
  store ptr %t545, ptr %l291, !tbaa !29
  store i32 0, ptr %l292
  %t546 = load i32, ptr %l2, !tbaa !23
  store i32 %t546, ptr %l293, !tbaa !23
  %t547 = load ptr, ptr %l0, !tbaa !29
  %t548 = load %"compiler/lower:pl", ptr %l1
  %t549 = load i32, ptr %l2, !tbaa !23
  %t550 = load %"compiler/source:Span", ptr %l4
  %t555 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2erefTo(ptr %v0, ptr %v1, ptr %t547, %"compiler/lower:pl" %t548, i32 %t549, %"compiler/source:Span" %t550)
  store { i64, [4 x i64] } %t555, ptr %l298
  br label %bb89
bb88:
  br label %bb92
bb89:
  %t556 = load ptr, ptr %l0, !tbaa !29
  %t558 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2edepth(ptr %v0, ptr %t556)
  store { i64, [4 x i64] } %t558, ptr %l300
  br label %bb90
bb90:
  %t559 = mul i64 2, 40
  %t560 = call ptr @__olang_scope_alloc_zeroed(ptr %s8, i64 %t559)
  %t561 = insertvalue { i64, ptr } undef, i64 2, 0
  %t562 = insertvalue { i64, ptr } %t561, ptr %t560, 1
  store { i64, ptr } %t562, ptr %l301, !tbaa !27
  %t563 = load { i64, [4 x i64] }, ptr %l298
  %t564 = getelementptr { i64, ptr }, ptr %l301, i32 0, i32 1
  %t565 = load ptr, ptr %t564, !tbaa !27
  %t566 = getelementptr { i64, [4 x i64] }, ptr %t565, i64 0
  store { i64, [4 x i64] } %t563, ptr %t566
  %t567 = load { i64, [4 x i64] }, ptr %l300
  %t568 = getelementptr { i64, ptr }, ptr %l301, i32 0, i32 1
  %t569 = load ptr, ptr %t568, !tbaa !27
  %t570 = getelementptr { i64, [4 x i64] }, ptr %t569, i64 1
  store { i64, [4 x i64] } %t567, ptr %t570
  %t571 = load { i64, [1 x i64] }, ptr %l3
  %t572 = mul i64 1, 16
  %t573 = call ptr @__olang_scope_alloc_zeroed(ptr %s8, i64 %t572)
  %t574 = insertvalue { i64, ptr } undef, i64 1, 0
  %t575 = insertvalue { i64, ptr } %t574, ptr %t573, 1
  store { i64, ptr } %t575, ptr %l303, !tbaa !27
  %t577 = getelementptr { i64, ptr }, ptr %l303, i32 0, i32 1
  %t578 = load ptr, ptr %t577, !tbaa !27
  %t579 = getelementptr { i64, [1 x i64] }, ptr %t578, i64 0
  store { i64, [1 x i64] } %t571, ptr %t579
  %t580 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t581 = load %"compiler/source:Span", ptr %l4
  %t582 = load ptr, ptr %l291, !tbaa !29
  %t583 = load i32, ptr %l292
  %t584 = load i32, ptr %l293, !tbaa !23
  %t585 = load { i64, ptr }, ptr %l301, !tbaa !27
  %t586 = load { i64, ptr }, ptr %l303, !tbaa !27
  %t589 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ehelperCall(ptr %v0, ptr %s8, ptr %s8, ptr %t582, i32 %t583, i32 %t584, { i64, ptr } %t585, { i64, ptr } %t586, i32 %t580, %"compiler/source:Span" %t581)
  store { i64, [4 x i64] } %t589, ptr %l306
  br label %bb91
bb91:
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb92:
  %t590 = load ptr, ptr %l0, !tbaa !29
  %t591 = load i32, ptr %l2, !tbaa !23
  %t594 = call { { i64, ptr }, i1 } @compiler_2flower_2ecompiler_2flower_3alowering_2epartsOf(ptr %v0, ptr %s0, ptr %t590, i32 %t591)
  store { { i64, ptr }, i1 } %t594, ptr %l309
  br label %bb93
bb93:
  %t595 = load { { i64, ptr }, i1 }, ptr %l309
  store { { i64, ptr }, i1 } %t595, ptr %l24
  %t596 = getelementptr { { i64, ptr }, i1 }, ptr %l24, i32 0, i32 0
  %t597 = load { i64, ptr }, ptr %t596, !tbaa !27
  store { i64, ptr } %t597, ptr %l310, !tbaa !27
  %t598 = load { i64, ptr }, ptr %l310, !tbaa !27
  %t599 = extractvalue { i64, ptr } %t598, 0
  store i64 %t599, ptr %l311, !tbaa !24
  %t600 = load i64, ptr %l311, !tbaa !24
  %t601 = mul i64 %t600, 4
  %t602 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t601)
  %t603 = insertvalue { i64, ptr } undef, i64 %t600, 0
  %t604 = insertvalue { i64, ptr } %t603, ptr %t602, 1
  store { i64, ptr } %t604, ptr %l312, !tbaa !27
  %t605 = getelementptr { i64, ptr }, ptr %l312, i32 0, i32 1
  %t606 = load ptr, ptr %t605, !tbaa !27
  %t607 = getelementptr { i64, ptr }, ptr %l310, i32 0, i32 1
  %t608 = load ptr, ptr %t607, !tbaa !27
  %t609 = load i64, ptr %l311, !tbaa !24
  %t610 = mul i64 %t609, 4
  call void @llvm.memmove.p0.p0.i64(ptr %t606, ptr %t608, i64 %t610, i1 false)
  %t611 = load { i64, ptr }, ptr %l312, !tbaa !27
  store { i64, ptr } %t611, ptr %l25, !tbaa !27
  %t612 = getelementptr { { i64, ptr }, i1 }, ptr %l24, i32 0, i32 1
  %t613 = load i1, ptr %t612, !tbaa !21
  store i1 %t613, ptr %l26, !tbaa !21
  %t615 = load ptr, ptr %l0, !tbaa !29
  %t616 = load i32, ptr %l2, !tbaa !23
  %t619 = call { { i64, ptr }, i1 } @compiler_2flower_2ecompiler_2flower_3alowering_2ecasesOf(ptr %v0, ptr %s0, ptr %t615, i32 %t616)
  store { { i64, ptr }, i1 } %t619, ptr %l316
  br label %bb94
bb94:
  %t620 = load { { i64, ptr }, i1 }, ptr %l316
  store { { i64, ptr }, i1 } %t620, ptr %l27
  %t621 = getelementptr { { i64, ptr }, i1 }, ptr %l27, i32 0, i32 0
  %t622 = load { i64, ptr }, ptr %t621, !tbaa !27
  store { i64, ptr } %t622, ptr %l317, !tbaa !27
  %t623 = load { i64, ptr }, ptr %l317, !tbaa !27
  %t624 = extractvalue { i64, ptr } %t623, 0
  store i64 %t624, ptr %l318, !tbaa !24
  %t625 = load i64, ptr %l318, !tbaa !24
  %t626 = mul i64 %t625, 4
  %t627 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t626)
  %t628 = insertvalue { i64, ptr } undef, i64 %t625, 0
  %t629 = insertvalue { i64, ptr } %t628, ptr %t627, 1
  store { i64, ptr } %t629, ptr %l319, !tbaa !27
  %t630 = getelementptr { i64, ptr }, ptr %l319, i32 0, i32 1
  %t631 = load ptr, ptr %t630, !tbaa !27
  %t632 = getelementptr { i64, ptr }, ptr %l317, i32 0, i32 1
  %t633 = load ptr, ptr %t632, !tbaa !27
  %t634 = load i64, ptr %l318, !tbaa !24
  %t635 = mul i64 %t634, 4
  call void @llvm.memmove.p0.p0.i64(ptr %t631, ptr %t633, i64 %t635, i1 false)
  %t636 = load { i64, ptr }, ptr %l319, !tbaa !27
  store { i64, ptr } %t636, ptr %l28, !tbaa !27
  %t637 = getelementptr { { i64, ptr }, i1 }, ptr %l27, i32 0, i32 1
  %t638 = load i1, ptr %t637, !tbaa !21
  store i1 %t638, ptr %l29, !tbaa !21
  %t640 = load i1, ptr %l26, !tbaa !21
  br i1 %t640, label %bb95, label %bb96
bb95:
  store %olang.scope zeroinitializer, ptr %s9
  %t642 = load ptr, ptr %l6, !tbaa !29
  %t643 = load i32, ptr %l7, !tbaa !23
  %t646 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t642, i32 %t643)
  store i32 %t646, ptr %l324
  br label %bb97
bb96:
  %t647 = load i1, ptr %l29, !tbaa !21
  br i1 %t647, label %bb125, label %bb126
bb97:
  %t649 = load i32, ptr %l324
  %t651 = trunc i64 18 to i32
  %t652 = icmp eq i32 %t649, %t651
  br i1 %t652, label %bb98, label %bb99
bb98:
  %t654 = load ptr, ptr %l0, !tbaa !29
  store ptr %t654, ptr %l327, !tbaa !29
  %t655 = load { i64, [1 x i64] }, ptr %l3
  store { i64, [1 x i64] } %t655, ptr %l328
  %t656 = load ptr, ptr %l0, !tbaa !29
  %t658 = getelementptr %"compiler/lower:lowering", ptr %t656, i32 0, i32 2
  %t659 = load ptr, ptr %t658, !tbaa !29
  %t661 = getelementptr %"compiler/types:Table", ptr %t659, i32 0, i32 0
  %t662 = load ptr, ptr %t661, !tbaa !29
  store ptr %t662, ptr %l331, !tbaa !29
  %t663 = load ptr, ptr %l6, !tbaa !29
  store ptr %t663, ptr %l332, !tbaa !29
  %t664 = load ptr, ptr %l6, !tbaa !29
  %t665 = load i32, ptr %l7, !tbaa !23
  %t668 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t664, i32 %t665)
  store i32 %t668, ptr %l335
  br label %bb100
bb99:
  br label %bb104
bb100:
  %t669 = load ptr, ptr %l332, !tbaa !29
  %t670 = load i32, ptr %l335, !tbaa !23
  %t671 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %t669, i32 %t670)
  store i32 %t671, ptr %l336
  br label %bb101
bb101:
  %t672 = load ptr, ptr %l331, !tbaa !29
  %t673 = load i32, ptr %l336, !tbaa !23
  %t674 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t672, i32 %t673)
  store { i64, ptr } %t674, ptr %l337
  br label %bb102
bb102:
  %t675 = load %"compiler/source:Span", ptr %l4
  %t676 = load ptr, ptr %l327, !tbaa !29
  %t677 = load { i64, [1 x i64] }, ptr %l328
  %t678 = load { i64, ptr }, ptr %l337, !tbaa !27
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eword(ptr %v0, ptr %v0, ptr %t676, { i64, [1 x i64] } %t677, { i64, ptr } %t678, %"compiler/source:Span" %t675)
  br label %bb103
bb103:
  br label %bb104
bb104:
  %t680 = load ptr, ptr %l0, !tbaa !29
  %t681 = load { i64, [1 x i64] }, ptr %l3
  %t682 = load %"compiler/source:Span", ptr %l4
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eword(ptr %v0, ptr %s9, ptr %t680, { i64, [1 x i64] } %t681, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d19, i32 0, i32 1) }, %"compiler/source:Span" %t682)
  br label %bb105
bb105:
  store i64 0, ptr %l30, !tbaa !24
  %t686 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t688 = extractvalue { i64, ptr } %t686, 0
  store i64 %t688, ptr %l31, !tbaa !24
  store i64 1, ptr %l32, !tbaa !24
  %t690 = load i64, ptr %l31, !tbaa !24
  %t691 = load i64, ptr %l30, !tbaa !24
  %t694 = icmp sgt i64 %t690, %t691
  br i1 %t694, label %bb106, label %bb107
bb106:
  %t696 = load i64, ptr %l32, !tbaa !24
  %t698 = icmp sgt i64 %t696, 0
  br i1 %t698, label %bb108, label %bb109
bb107:
  store i64 0, ptr %l347, !tbaa !24
  br label %bb111
bb108:
  %t700 = load i64, ptr %l31, !tbaa !24
  %t701 = load i64, ptr %l30, !tbaa !24
  %t704 = sub i64 %t700, %t701
  %t705 = load i64, ptr %l32, !tbaa !24
  %t708 = add i64 %t704, %t705
  %t710 = sub i64 %t708, 1
  %t711 = load i64, ptr %l32, !tbaa !24
  %t714 = sdiv i64 %t710, %t711
  store i64 %t714, ptr %l350, !tbaa !24
  br label %bb110
bb109:
  store i64 0, ptr %l350, !tbaa !24
  br label %bb110
bb110:
  %t716 = load i64, ptr %l350, !tbaa !24
  store i64 %t716, ptr %l347, !tbaa !24
  br label %bb111
bb111:
  %t717 = load i64, ptr %l347, !tbaa !24
  store i64 %t717, ptr %l33, !tbaa !24
  store i64 0, ptr %l34, !tbaa !24
  br label %bb112
bb112:
  store %olang.scope zeroinitializer, ptr %s12
  %t718 = load i64, ptr %l34, !tbaa !24
  %t719 = load i64, ptr %l33, !tbaa !24
  %t722 = icmp slt i64 %t718, %t719
  %t724 = xor i1 %t722, true
  br i1 %t724, label %bb113, label %bb114
bb113:
  call void @__olang_scope_close(ptr %s12)
  br label %bb123
bb114:
  br label %bb115
bb115:
  %t726 = load i64, ptr %l30, !tbaa !24
  %t727 = load i64, ptr %l34, !tbaa !24
  %t728 = load i64, ptr %l32, !tbaa !24
  %t731 = mul i64 %t727, %t728
  %t734 = add i64 %t726, %t731
  store i64 %t734, ptr %l35, !tbaa !24
  %t736 = load i64, ptr %l35, !tbaa !24
  %t738 = icmp sgt i64 %t736, 0
  br i1 %t738, label %bb116, label %bb117
bb116:
  store %olang.scope zeroinitializer, ptr %s13
  %t740 = load ptr, ptr %l0, !tbaa !29
  %t741 = load { i64, [1 x i64] }, ptr %l3
  %t742 = load %"compiler/source:Span", ptr %l4
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eword(ptr %v0, ptr %s13, ptr %t740, { i64, [1 x i64] } %t741, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d20, i32 0, i32 1) }, %"compiler/source:Span" %t742)
  br label %bb118
bb117:
  br label %bb119
bb118:
  call void @__olang_scope_close(ptr %s13)
  br label %bb119
bb119:
  %t746 = load ptr, ptr %l0, !tbaa !29
  store ptr %t746, ptr %l373, !tbaa !29
  %t747 = load ptr, ptr %l0, !tbaa !29
  %t748 = load %"compiler/lower:pl", ptr %l1
  %t749 = load i64, ptr %l35, !tbaa !24
  store { i64, [1 x i64] } zeroinitializer, ptr %t750
  %t751 = getelementptr { i64, [1 x i64] }, ptr %t750, i32 0, i32 0
  store i64 0, ptr %t751
  %t753 = insertvalue { i64 } undef, i64 %t749, 0
  %t754 = getelementptr { i64, [1 x i64] }, ptr %t750, i32 0, i32 1
  store { i64 } %t753, ptr %t754
  %t755 = load { i64, [1 x i64] }, ptr %t750
  %t759 = call %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2ewith(ptr %v0, ptr %v1, ptr %s12, ptr %t747, %"compiler/lower:pl" %t748, { i64, [1 x i64] } %t755)
  store %"compiler/lower:pl" %t759, ptr %l378
  br label %bb120
bb120:
  %t760 = load i64, ptr %l35, !tbaa !24
  %t762 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t763 = load ptr, ptr %t762, !tbaa !27
  %t764 = getelementptr i32, ptr %t763, i64 %t760
  %t765 = load i32, ptr %t764, !tbaa !33
  %t766 = load { i64, [1 x i64] }, ptr %l3
  %t767 = load %"compiler/source:Span", ptr %l4
  %t768 = load ptr, ptr %l373, !tbaa !29
  %t769 = load %"compiler/lower:pl", ptr %l378
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2einner(ptr %v0, ptr %s12, ptr %t768, %"compiler/lower:pl" %t769, i32 %t765, { i64, [1 x i64] } %t766, %"compiler/source:Span" %t767)
  br label %bb121
bb121:
  call void @__olang_scope_close(ptr %s12)
  br label %bb122
bb122:
  %t773 = load i64, ptr %l34, !tbaa !24
  %t775 = add i64 %t773, 1
  store i64 %t775, ptr %l34, !tbaa !24
  br label %bb112
bb123:
  %t777 = load ptr, ptr %l0, !tbaa !29
  %t778 = load { i64, [1 x i64] }, ptr %l3
  %t779 = load %"compiler/source:Span", ptr %l4
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eword(ptr %v0, ptr %s9, ptr %t777, { i64, [1 x i64] } %t778, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d21, i32 0, i32 1) }, %"compiler/source:Span" %t779)
  br label %bb124
bb124:
  call void @__olang_scope_close(ptr %s9)
  br label %bb237
bb125:
  store %olang.scope zeroinitializer, ptr %s16
  %t783 = load ptr, ptr %l6, !tbaa !29
  %t784 = load i32, ptr %l7, !tbaa !23
  %t787 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t783, i32 %t784)
  store i32 %t787, ptr %l391
  br label %bb127
bb126:
  %t788 = load ptr, ptr %l0, !tbaa !29
  %t789 = load i32, ptr %l2, !tbaa !23
  %t792 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2earrayOf(ptr %v0, ptr %t788, i32 %t789)
  store i32 %t792, ptr %l616
  br label %bb222
bb127:
  %t793 = load i32, ptr %l391
  %t795 = trunc i64 18 to i32
  %t796 = icmp eq i32 %t793, %t795
  br i1 %t796, label %bb128, label %bb129
bb128:
  %t798 = load ptr, ptr %l6, !tbaa !29
  %t799 = load i32, ptr %l7, !tbaa !23
  %t802 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCaseNames(ptr %v0, ptr %t798, i32 %t799)
  store { i64, ptr } %t802, ptr %l397
  br label %bb130
bb129:
  %t803 = load ptr, ptr %l6, !tbaa !29
  %t804 = load i32, ptr %l7, !tbaa !23
  %t807 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeNames(ptr %v0, ptr %t803, i32 %t804)
  store { i64, ptr } %t807, ptr %l400
  br label %bb131
bb130:
  %t808 = load { i64, ptr }, ptr %l397, !tbaa !27
  store { i64, ptr } %t808, ptr %l394, !tbaa !27
  br label %bb132
bb131:
  %t809 = load { i64, ptr }, ptr %l400, !tbaa !27
  store { i64, ptr } %t809, ptr %l394, !tbaa !27
  br label %bb132
bb132:
  %t810 = load { i64, ptr }, ptr %l394, !tbaa !27
  store { i64, ptr } %t810, ptr %l36, !tbaa !27
  %t811 = load ptr, ptr %l0, !tbaa !29
  store ptr %t811, ptr %l401, !tbaa !29
  %t812 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  store i32 %t812, ptr %l402, !tbaa !23
  %t813 = load ptr, ptr %l0, !tbaa !29
  %t814 = load %"compiler/lower:pl", ptr %l1
  %t817 = call %"compiler/mir:Place" @compiler_2flower_2ecompiler_2flower_3alowering_2emk(ptr %v0, ptr %v1, ptr %t813, %"compiler/lower:pl" %t814)
  store %"compiler/mir:Place" %t817, ptr %l405
  br label %bb133
bb133:
  store { i64, [15 x i64] } zeroinitializer, ptr %t818
  %t819 = getelementptr { i64, [15 x i64] }, ptr %t818, i32 0, i32 0
  store i64 5, ptr %t819
  %t820 = load %"compiler/mir:Place", ptr %l405
  %t821 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t820, 0
  %t822 = getelementptr { i64, [15 x i64] }, ptr %t818, i32 0, i32 1
  store { %"compiler/mir:Place" } %t821, ptr %t822
  %t823 = load { i64, [15 x i64] }, ptr %t818
  %t824 = load %"compiler/source:Span", ptr %l4
  %t825 = load ptr, ptr %l401, !tbaa !29
  %t826 = load i32, ptr %l402, !tbaa !23
  %t829 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %t825, i32 %t826, { i64, [15 x i64] } %t823, %"compiler/source:Span" %t824)
  store { i64, [4 x i64] } %t829, ptr %l408
  br label %bb134
bb134:
  %t830 = load { i64, [4 x i64] }, ptr %l408
  store { i64, [4 x i64] } %t830, ptr %l37
  %t831 = load ptr, ptr %l6, !tbaa !29
  %t832 = load i32, ptr %l7, !tbaa !23
  %t835 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t831, i32 %t832)
  store i32 %t835, ptr %l411
  br label %bb135
bb135:
  %t836 = load i32, ptr %l411
  %t838 = trunc i64 18 to i32
  %t839 = icmp eq i32 %t836, %t838
  %t841 = xor i1 %t839, true
  br i1 %t841, label %bb136, label %bb137
bb136:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d22, i32 0, i32 1) }, ptr %l415, !tbaa !27
  br label %bb141
bb137:
  %t843 = load ptr, ptr %l0, !tbaa !29
  %t845 = getelementptr %"compiler/lower:lowering", ptr %t843, i32 0, i32 2
  %t846 = load ptr, ptr %t845, !tbaa !29
  %t848 = getelementptr %"compiler/types:Table", ptr %t846, i32 0, i32 0
  %t849 = load ptr, ptr %t848, !tbaa !29
  store ptr %t849, ptr %l418, !tbaa !29
  %t850 = load ptr, ptr %l6, !tbaa !29
  store ptr %t850, ptr %l419, !tbaa !29
  %t851 = load ptr, ptr %l6, !tbaa !29
  %t852 = load i32, ptr %l7, !tbaa !23
  %t855 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t851, i32 %t852)
  store i32 %t855, ptr %l422
  br label %bb138
bb138:
  %t856 = load ptr, ptr %l419, !tbaa !29
  %t857 = load i32, ptr %l422, !tbaa !23
  %t858 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %t856, i32 %t857)
  store i32 %t858, ptr %l423
  br label %bb139
bb139:
  %t859 = load ptr, ptr %l418, !tbaa !29
  %t860 = load i32, ptr %l423, !tbaa !23
  %t861 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t859, i32 %t860)
  store { i64, ptr } %t861, ptr %l424
  br label %bb140
bb140:
  %t862 = load { i64, ptr }, ptr %l424, !tbaa !27
  %t863 = extractvalue { i64, ptr } %t862, 1
  %t864 = extractvalue { i64, ptr } %t862, 0
  %t865 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d23, i32 0, i32 1) }, 1
  %t866 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d23, i32 0, i32 1) }, 0
  %t867 = add i64 %t864, %t866
  %t868 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t867)
  call void @olang_textcopy(ptr %t868, ptr %t863, i64 %t864)
  %t869 = getelementptr i8, ptr %t868, i64 %t864
  call void @olang_textcopy(ptr %t869, ptr %t865, i64 %t866)
  %t870 = insertvalue { i64, ptr } undef, i64 %t867, 0
  %t871 = insertvalue { i64, ptr } %t870, ptr %t868, 1
  %t873 = extractvalue { i64, ptr } %t871, 0
  %t874 = extractvalue { i64, ptr } %t871, 1
  %t875 = mul i64 %t873, 1
  %t876 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t875)
  call void @llvm.memcpy.p0.p0.i64(ptr %t876, ptr %t874, i64 %t875, i1 false)
  %t877 = insertvalue { i64, ptr } undef, i64 %t873, 0
  %t878 = insertvalue { i64, ptr } %t877, ptr %t876, 1
  store { i64, ptr } %t878, ptr %l415, !tbaa !27
  br label %bb141
bb141:
  %t880 = load { i64, ptr }, ptr %l415, !tbaa !27
  store { i64, ptr } %t880, ptr %l38, !tbaa !27
  %t881 = load ptr, ptr %l0, !tbaa !29
  %t883 = getelementptr %"compiler/lower:lowering", ptr %t881, i32 0, i32 3
  %t885 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t883)
  store i32 %t885, ptr %l429
  br label %bb142
bb142:
  %t886 = load i32, ptr %l429, !tbaa !23
  store i32 %t886, ptr %l39, !tbaa !23
  %t887 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t889 = extractvalue { i64, ptr } %t887, 0
  store i64 %t889, ptr %l431, !tbaa !24
  store %"compiler/mir:Case" zeroinitializer, ptr %l432
  %t890 = load i64, ptr %l431, !tbaa !24
  %t891 = icmp sgt i64 %t890, 0
  br i1 %t891, label %bb143, label %bb144
bb143:
  %t893 = call %"compiler/mir:Case" @compiler_2fmir_3aCase_2ector(ptr %s16, i64 0, i32 0)
  store %"compiler/mir:Case" %t893, ptr %l434
  br label %bb145
bb144:
  %t894 = load i64, ptr %l431, !tbaa !24
  %t895 = icmp sge i64 %t894, 0
  br i1 %t895, label %bb146, label %bb147
bb145:
  %t897 = load %"compiler/mir:Case", ptr %l434
  store %"compiler/mir:Case" %t897, ptr %l432
  br label %bb144
bb146:
  %t898 = load i64, ptr %l431, !tbaa !24
  %t899 = icmp sle i64 %t898, 576460752303423487
  br i1 %t899, label %bb148, label %bb149
bb147:
  call void @__olang_check_failed(ptr @olang_loc_7adf76f2408b5bdd_bd99dd0034e41651)
  unreachable
bb148:
  %t901 = load i64, ptr %l431, !tbaa !24
  %t902 = mul i64 %t901, 16
  %t903 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t902)
  %t904 = load %"compiler/mir:Case", ptr %l432
  store i64 0, ptr %t905
  br label %fill.906
fill.906:
  %t909 = load i64, ptr %t905
  %t910 = icmp slt i64 %t909, %t901
  br i1 %t910, label %fillb.907, label %filld.908
fillb.907:
  %t911 = getelementptr %"compiler/mir:Case", ptr %t903, i64 %t909
  store %"compiler/mir:Case" %t904, ptr %t911
  %t912 = add i64 %t909, 1
  store i64 %t912, ptr %t905
  br label %fill.906
filld.908:
  %t913 = insertvalue { i64, ptr } undef, i64 %t901, 0
  %t914 = insertvalue { i64, ptr } %t913, ptr %t903, 1
  store { i64, ptr } %t914, ptr %l40, !tbaa !27
  %t916 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t918 = extractvalue { i64, ptr } %t916, 0
  store i64 %t918, ptr %l439, !tbaa !24
  %t919 = load i64, ptr %l439, !tbaa !24
  %t920 = icmp sge i64 %t919, 0
  br i1 %t920, label %bb150, label %bb151
bb149:
  call void @__olang_check_failed(ptr @olang_loc_7adf76f2408b5bdd_bd99dd0034e41651)
  unreachable
bb150:
  %t922 = load i64, ptr %l439, !tbaa !24
  %t923 = icmp sle i64 %t922, 2305843009213693951
  br i1 %t923, label %bb152, label %bb153
bb151:
  call void @__olang_check_failed(ptr @olang_loc_4257ffd395d48830_792957a97ae844)
  unreachable
bb152:
  %t925 = load i64, ptr %l439, !tbaa !24
  %t926 = mul i64 %t925, 4
  %t927 = call ptr @__olang_scope_alloc_zeroed(ptr %s16, i64 %t926)
  %t928 = insertvalue { i64, ptr } undef, i64 %t925, 0
  %t929 = insertvalue { i64, ptr } %t928, ptr %t927, 1
  store { i64, ptr } %t929, ptr %l41, !tbaa !27
  store i64 0, ptr %l42, !tbaa !24
  %t931 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t933 = extractvalue { i64, ptr } %t931, 0
  store i64 %t933, ptr %l43, !tbaa !24
  store i64 1, ptr %l44, !tbaa !24
  %t935 = load i64, ptr %l43, !tbaa !24
  %t936 = load i64, ptr %l42, !tbaa !24
  %t939 = icmp sgt i64 %t935, %t936
  br i1 %t939, label %bb154, label %bb155
bb153:
  call void @__olang_check_failed(ptr @olang_loc_4257ffd395d48830_792957a97ae844)
  unreachable
bb154:
  %t941 = load i64, ptr %l44, !tbaa !24
  %t943 = icmp sgt i64 %t941, 0
  br i1 %t943, label %bb156, label %bb157
bb155:
  store i64 0, ptr %l448, !tbaa !24
  br label %bb159
bb156:
  %t945 = load i64, ptr %l43, !tbaa !24
  %t946 = load i64, ptr %l42, !tbaa !24
  %t949 = sub i64 %t945, %t946
  %t950 = load i64, ptr %l44, !tbaa !24
  %t953 = add i64 %t949, %t950
  %t955 = sub i64 %t953, 1
  %t956 = load i64, ptr %l44, !tbaa !24
  %t959 = sdiv i64 %t955, %t956
  store i64 %t959, ptr %l451, !tbaa !24
  br label %bb158
bb157:
  store i64 0, ptr %l451, !tbaa !24
  br label %bb158
bb158:
  %t961 = load i64, ptr %l451, !tbaa !24
  store i64 %t961, ptr %l448, !tbaa !24
  br label %bb159
bb159:
  %t962 = load i64, ptr %l448, !tbaa !24
  store i64 %t962, ptr %l45, !tbaa !24
  store i64 0, ptr %l46, !tbaa !24
  br label %bb160
bb160:
  store %olang.scope zeroinitializer, ptr %s19
  %t963 = load i64, ptr %l46, !tbaa !24
  %t964 = load i64, ptr %l45, !tbaa !24
  %t967 = icmp slt i64 %t963, %t964
  %t969 = xor i1 %t967, true
  br i1 %t969, label %bb161, label %bb162
bb161:
  call void @__olang_scope_close(ptr %s19)
  br label %bb167
bb162:
  br label %bb163
bb163:
  %t971 = load i64, ptr %l42, !tbaa !24
  %t972 = load i64, ptr %l46, !tbaa !24
  %t973 = load i64, ptr %l44, !tbaa !24
  %t976 = mul i64 %t972, %t973
  %t979 = add i64 %t971, %t976
  store i64 %t979, ptr %l47, !tbaa !24
  %t981 = load i64, ptr %l47, !tbaa !24
  store i64 %t981, ptr %l469, !tbaa !24
  %t982 = load ptr, ptr %l0, !tbaa !29
  %t984 = getelementptr %"compiler/lower:lowering", ptr %t982, i32 0, i32 3
  %t986 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t984)
  store i32 %t986, ptr %l472
  br label %bb164
bb164:
  %t987 = load i32, ptr %l472, !tbaa !23
  %t988 = load i64, ptr %l469, !tbaa !24
  %t989 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t990 = load ptr, ptr %t989, !tbaa !27
  %t991 = getelementptr i32, ptr %t990, i64 %t988
  store i32 %t987, ptr %t991, !tbaa !33
  %t992 = load i64, ptr %l47, !tbaa !24
  store i64 %t992, ptr %l473, !tbaa !24
  %t993 = load i64, ptr %l47, !tbaa !24
  %t994 = load i64, ptr %l47, !tbaa !24
  %t996 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t997 = load ptr, ptr %t996, !tbaa !27
  %t998 = getelementptr i32, ptr %t997, i64 %t994
  %t999 = load i32, ptr %t998, !tbaa !33
  %t1002 = call %"compiler/mir:Case" @compiler_2fmir_3aCase_2ector(ptr %s19, i64 %t993, i32 %t999)
  store %"compiler/mir:Case" %t1002, ptr %l477
  br label %bb165
bb165:
  %t1003 = load %"compiler/mir:Case", ptr %l477
  %t1004 = load i64, ptr %l473, !tbaa !24
  %t1005 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t1006 = load ptr, ptr %t1005, !tbaa !27
  %t1007 = getelementptr %"compiler/mir:Case", ptr %t1006, i64 %t1004
  store %"compiler/mir:Case" %t1003, ptr %t1007
  call void @__olang_scope_close(ptr %s19)
  br label %bb166
bb166:
  %t1008 = load i64, ptr %l46, !tbaa !24
  %t1010 = add i64 %t1008, 1
  store i64 %t1010, ptr %l46, !tbaa !24
  br label %bb160
bb167:
  %t1012 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1012, ptr %l480, !tbaa !29
  %t1013 = load { i64, [4 x i64] }, ptr %l37
  store { i64, [4 x i64] } %t1013, ptr %l481
  %t1014 = load ptr, ptr %l0, !tbaa !29
  %t1016 = getelementptr %"compiler/lower:lowering", ptr %t1014, i32 0, i32 3
  %t1017 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t1020 = call %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddCases(ptr %v0, ptr %s16, ptr %t1016, { i64, ptr } %t1017)
  store %"compiler/mir:Range" %t1020, ptr %l485
  br label %bb168
bb168:
  %t1021 = load i32, ptr %l39, !tbaa !23
  store { i64, [8 x i64] } zeroinitializer, ptr %t1022
  %t1023 = getelementptr { i64, [8 x i64] }, ptr %t1022, i32 0, i32 0
  store i64 3, ptr %t1023
  %t1024 = load { i64, [4 x i64] }, ptr %l481
  %t1025 = insertvalue { { i64, [4 x i64] }, %"compiler/mir:Range", i32 } undef, { i64, [4 x i64] } %t1024, 0
  %t1026 = load %"compiler/mir:Range", ptr %l485
  %t1027 = insertvalue { { i64, [4 x i64] }, %"compiler/mir:Range", i32 } %t1025, %"compiler/mir:Range" %t1026, 1
  %t1029 = insertvalue { { i64, [4 x i64] }, %"compiler/mir:Range", i32 } %t1027, i32 %t1021, 2
  %t1030 = getelementptr { i64, [8 x i64] }, ptr %t1022, i32 0, i32 1
  store { { i64, [4 x i64] }, %"compiler/mir:Range", i32 } %t1029, ptr %t1030
  %t1031 = load { i64, [8 x i64] }, ptr %t1022
  %t1032 = load ptr, ptr %l480, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t1032, { i64, [8 x i64] } %t1031)
  br label %bb169
bb169:
  store i64 0, ptr %l48, !tbaa !24
  %t1034 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t1036 = extractvalue { i64, ptr } %t1034, 0
  store i64 %t1036, ptr %l49, !tbaa !24
  store i64 1, ptr %l50, !tbaa !24
  %t1038 = load i64, ptr %l49, !tbaa !24
  %t1039 = load i64, ptr %l48, !tbaa !24
  %t1042 = icmp sgt i64 %t1038, %t1039
  br i1 %t1042, label %bb170, label %bb171
bb170:
  %t1044 = load i64, ptr %l50, !tbaa !24
  %t1046 = icmp sgt i64 %t1044, 0
  br i1 %t1046, label %bb172, label %bb173
bb171:
  store i64 0, ptr %l493, !tbaa !24
  br label %bb175
bb172:
  %t1048 = load i64, ptr %l49, !tbaa !24
  %t1049 = load i64, ptr %l48, !tbaa !24
  %t1052 = sub i64 %t1048, %t1049
  %t1053 = load i64, ptr %l50, !tbaa !24
  %t1056 = add i64 %t1052, %t1053
  %t1058 = sub i64 %t1056, 1
  %t1059 = load i64, ptr %l50, !tbaa !24
  %t1062 = sdiv i64 %t1058, %t1059
  store i64 %t1062, ptr %l496, !tbaa !24
  br label %bb174
bb173:
  store i64 0, ptr %l496, !tbaa !24
  br label %bb174
bb174:
  %t1064 = load i64, ptr %l496, !tbaa !24
  store i64 %t1064, ptr %l493, !tbaa !24
  br label %bb175
bb175:
  %t1065 = load i64, ptr %l493, !tbaa !24
  store i64 %t1065, ptr %l51, !tbaa !24
  store i64 0, ptr %l52, !tbaa !24
  br label %bb176
bb176:
  store %olang.scope zeroinitializer, ptr %s22
  %t1066 = load i64, ptr %l52, !tbaa !24
  %t1067 = load i64, ptr %l51, !tbaa !24
  %t1070 = icmp slt i64 %t1066, %t1067
  %t1072 = xor i1 %t1070, true
  br i1 %t1072, label %bb177, label %bb178
bb177:
  call void @__olang_scope_close(ptr %s22)
  br label %bb220
bb178:
  br label %bb179
bb179:
  %t1074 = load i64, ptr %l48, !tbaa !24
  %t1075 = load i64, ptr %l52, !tbaa !24
  %t1076 = load i64, ptr %l50, !tbaa !24
  %t1079 = mul i64 %t1075, %t1076
  %t1082 = add i64 %t1074, %t1079
  store i64 %t1082, ptr %l53, !tbaa !24
  %t1084 = load ptr, ptr %l0, !tbaa !29
  %t1085 = load i64, ptr %l53, !tbaa !24
  %t1087 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t1088 = load ptr, ptr %t1087, !tbaa !27
  %t1089 = getelementptr i32, ptr %t1088, i64 %t1085
  %t1090 = load i32, ptr %t1089, !tbaa !33
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t1084, i32 %t1090)
  br label %bb180
bb180:
  %t1093 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t1095 = extractvalue { i64, ptr } %t1093, 0
  %t1097 = icmp sgt i64 %t1095, 0
  br i1 %t1097, label %bb181, label %bb182
bb181:
  %t1099 = load i64, ptr %l53, !tbaa !24
  %t1100 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t1102 = extractvalue { i64, ptr } %t1100, 0
  %t1105 = icmp slt i64 %t1099, %t1102
  store i1 %t1105, ptr %l520, !tbaa !21
  br label %bb183
bb182:
  store i1 false, ptr %l520, !tbaa !21
  br label %bb183
bb183:
  %t1107 = load i1, ptr %l520, !tbaa !21
  br i1 %t1107, label %bb184, label %bb185
bb184:
  %t1108 = load ptr, ptr %l0, !tbaa !29
  %t1110 = getelementptr %"compiler/lower:lowering", ptr %t1108, i32 0, i32 2
  %t1111 = load ptr, ptr %t1110, !tbaa !29
  %t1113 = getelementptr %"compiler/types:Table", ptr %t1111, i32 0, i32 0
  %t1114 = load ptr, ptr %t1113, !tbaa !29
  %t1115 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t1115, ptr %l529, !tbaa !27
  %t1116 = load i64, ptr %l53, !tbaa !24
  %t1118 = getelementptr { i64, ptr }, ptr %l529, i32 0, i32 1
  %t1119 = load ptr, ptr %t1118, !tbaa !27
  %t1120 = getelementptr i32, ptr %t1119, i64 %t1116
  %t1121 = load i32, ptr %t1120, !tbaa !33
  %t1124 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t1114, i32 %t1121)
  store { i64, ptr } %t1124, ptr %l532
  br label %bb186
bb185:
  %t1125 = load i64, ptr %l53, !tbaa !24
  %t1127 = call i64 @__olang_fmt_i64(ptr null, i64 %t1125)
  %t1128 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t1127)
  %t1129 = call i64 @__olang_fmt_i64(ptr %t1128, i64 %t1125)
  %t1130 = insertvalue { i64, ptr } undef, i64 %t1127, 0
  %t1131 = insertvalue { i64, ptr } %t1130, ptr %t1128, 1
  %t1133 = extractvalue { i64, ptr } %t1131, 0
  %t1134 = extractvalue { i64, ptr } %t1131, 1
  %t1135 = mul i64 %t1133, 1
  %t1136 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t1135)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1136, ptr %t1134, i64 %t1135, i1 false)
  %t1137 = insertvalue { i64, ptr } undef, i64 %t1133, 0
  %t1138 = insertvalue { i64, ptr } %t1137, ptr %t1136, 1
  store { i64, ptr } %t1138, ptr %l525, !tbaa !27
  br label %bb187
bb186:
  %t1140 = load { i64, ptr }, ptr %l532, !tbaa !27
  store { i64, ptr } %t1140, ptr %l525, !tbaa !27
  br label %bb187
bb187:
  %t1141 = load { i64, ptr }, ptr %l525, !tbaa !27
  %t1142 = load ptr, ptr %l0, !tbaa !29
  %t1143 = load { i64, [1 x i64] }, ptr %l3
  %t1144 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t1147 = extractvalue { i64, ptr } %t1144, 1
  %t1148 = extractvalue { i64, ptr } %t1144, 0
  %t1150 = extractvalue { i64, ptr } %t1141, 1
  %t1151 = extractvalue { i64, ptr } %t1141, 0
  %t1152 = add i64 %t1148, %t1151
  %t1153 = call ptr @__olang_scope_alloc(ptr %s22, i64 %t1152)
  call void @olang_textcopy(ptr %t1153, ptr %t1147, i64 %t1148)
  %t1154 = getelementptr i8, ptr %t1153, i64 %t1148
  call void @olang_textcopy(ptr %t1154, ptr %t1150, i64 %t1151)
  %t1155 = insertvalue { i64, ptr } undef, i64 %t1152, 0
  %t1156 = insertvalue { i64, ptr } %t1155, ptr %t1153, 1
  %t1158 = extractvalue { i64, ptr } %t1156, 0
  %t1159 = extractvalue { i64, ptr } %t1156, 1
  %t1160 = mul i64 %t1158, 1
  %t1161 = call ptr @__olang_scope_alloc(ptr %s22, i64 %t1160)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1161, ptr %t1159, i64 %t1160, i1 false)
  %t1162 = insertvalue { i64, ptr } undef, i64 %t1158, 0
  %t1163 = insertvalue { i64, ptr } %t1162, ptr %t1161, 1
  %t1164 = load %"compiler/source:Span", ptr %l4
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eword(ptr %v0, ptr %s22, ptr %t1142, { i64, [1 x i64] } %t1143, { i64, ptr } %t1163, %"compiler/source:Span" %t1164)
  br label %bb188
bb188:
  %t1169 = load i64, ptr %l53, !tbaa !24
  %t1171 = getelementptr { i64, ptr }, ptr %l28, i32 0, i32 1
  %t1172 = load ptr, ptr %t1171, !tbaa !27
  %t1173 = getelementptr i32, ptr %t1172, i64 %t1169
  %t1174 = load i32, ptr %t1173, !tbaa !33
  %t1176 = icmp ne i32 %t1174, 0
  br i1 %t1176, label %bb189, label %bb190
bb189:
  store %olang.scope zeroinitializer, ptr %s25
  %t1178 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1178, ptr %l546, !tbaa !29
  %t1179 = load ptr, ptr %l6, !tbaa !29
  %t1180 = load i64, ptr %l53, !tbaa !24
  %t1182 = getelementptr { i64, ptr }, ptr %l28, i32 0, i32 1
  %t1183 = load ptr, ptr %t1182, !tbaa !27
  %t1184 = getelementptr i32, ptr %t1183, i64 %t1180
  %t1185 = load i32, ptr %t1184, !tbaa !33
  %t1188 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t1179, i32 %t1185)
  store i32 %t1188, ptr %l550
  br label %bb191
bb190:
  br label %bb217
bb191:
  %t1189 = load ptr, ptr %l546, !tbaa !29
  %t1190 = load i32, ptr %l550, !tbaa !23
  %t1191 = call { i64, ptr } @compiler_2flower_2ecompiler_2flower_3alowering_2eitems(ptr %v0, ptr %s25, ptr %t1189, i32 %t1190)
  store { i64, ptr } %t1191, ptr %l551
  br label %bb192
bb192:
  %t1192 = load { i64, ptr }, ptr %l551, !tbaa !27
  store { i64, ptr } %t1192, ptr %l55, !tbaa !27
  %t1193 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t1195 = extractvalue { i64, ptr } %t1193, 0
  %t1197 = icmp sgt i64 %t1195, 0
  br i1 %t1197, label %bb193, label %bb194
bb193:
  store %olang.scope zeroinitializer, ptr %s26
  %t1199 = load ptr, ptr %l0, !tbaa !29
  %t1200 = load { i64, [1 x i64] }, ptr %l3
  %t1201 = load %"compiler/source:Span", ptr %l4
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eword(ptr %v0, ptr %s26, ptr %t1199, { i64, [1 x i64] } %t1200, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d24, i32 0, i32 1) }, %"compiler/source:Span" %t1201)
  br label %bb195
bb194:
  br label %bb216
bb195:
  store i64 0, ptr %l56, !tbaa !24
  %t1205 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t1207 = extractvalue { i64, ptr } %t1205, 0
  store i64 %t1207, ptr %l57, !tbaa !24
  store i64 1, ptr %l58, !tbaa !24
  %t1209 = load i64, ptr %l57, !tbaa !24
  %t1210 = load i64, ptr %l56, !tbaa !24
  %t1213 = icmp sgt i64 %t1209, %t1210
  br i1 %t1213, label %bb196, label %bb197
bb196:
  %t1215 = load i64, ptr %l58, !tbaa !24
  %t1217 = icmp sgt i64 %t1215, 0
  br i1 %t1217, label %bb198, label %bb199
bb197:
  store i64 0, ptr %l563, !tbaa !24
  br label %bb201
bb198:
  %t1219 = load i64, ptr %l57, !tbaa !24
  %t1220 = load i64, ptr %l56, !tbaa !24
  %t1223 = sub i64 %t1219, %t1220
  %t1224 = load i64, ptr %l58, !tbaa !24
  %t1227 = add i64 %t1223, %t1224
  %t1229 = sub i64 %t1227, 1
  %t1230 = load i64, ptr %l58, !tbaa !24
  %t1233 = sdiv i64 %t1229, %t1230
  store i64 %t1233, ptr %l566, !tbaa !24
  br label %bb200
bb199:
  store i64 0, ptr %l566, !tbaa !24
  br label %bb200
bb200:
  %t1235 = load i64, ptr %l566, !tbaa !24
  store i64 %t1235, ptr %l563, !tbaa !24
  br label %bb201
bb201:
  %t1236 = load i64, ptr %l563, !tbaa !24
  store i64 %t1236, ptr %l59, !tbaa !24
  store i64 0, ptr %l60, !tbaa !24
  br label %bb202
bb202:
  store %olang.scope zeroinitializer, ptr %s28
  %t1237 = load i64, ptr %l60, !tbaa !24
  %t1238 = load i64, ptr %l59, !tbaa !24
  %t1241 = icmp slt i64 %t1237, %t1238
  %t1243 = xor i1 %t1241, true
  br i1 %t1243, label %bb203, label %bb204
bb203:
  call void @__olang_scope_close(ptr %s28)
  br label %bb214
bb204:
  br label %bb205
bb205:
  %t1245 = load i64, ptr %l56, !tbaa !24
  %t1246 = load i64, ptr %l60, !tbaa !24
  %t1247 = load i64, ptr %l58, !tbaa !24
  %t1250 = mul i64 %t1246, %t1247
  %t1253 = add i64 %t1245, %t1250
  store i64 %t1253, ptr %l61, !tbaa !24
  %t1255 = load i64, ptr %l61, !tbaa !24
  %t1257 = icmp sgt i64 %t1255, 0
  br i1 %t1257, label %bb206, label %bb207
bb206:
  store %olang.scope zeroinitializer, ptr %s29
  %t1259 = load ptr, ptr %l0, !tbaa !29
  %t1260 = load { i64, [1 x i64] }, ptr %l3
  %t1261 = load %"compiler/source:Span", ptr %l4
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eword(ptr %v0, ptr %s29, ptr %t1259, { i64, [1 x i64] } %t1260, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d25, i32 0, i32 1) }, %"compiler/source:Span" %t1261)
  br label %bb208
bb207:
  br label %bb209
bb208:
  call void @__olang_scope_close(ptr %s29)
  br label %bb209
bb209:
  %t1265 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1265, ptr %l589, !tbaa !29
  %t1266 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1266, ptr %l590, !tbaa !29
  %t1267 = load ptr, ptr %l0, !tbaa !29
  %t1268 = load %"compiler/lower:pl", ptr %l1
  %t1269 = load i64, ptr %l53, !tbaa !24
  store { i64, [1 x i64] } zeroinitializer, ptr %t1270
  %t1271 = getelementptr { i64, [1 x i64] }, ptr %t1270, i32 0, i32 0
  store i64 4, ptr %t1271
  %t1273 = insertvalue { i64 } undef, i64 %t1269, 0
  %t1274 = getelementptr { i64, [1 x i64] }, ptr %t1270, i32 0, i32 1
  store { i64 } %t1273, ptr %t1274
  %t1275 = load { i64, [1 x i64] }, ptr %t1270
  %t1279 = call %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2ewith(ptr %v0, ptr %v1, ptr %s28, ptr %t1267, %"compiler/lower:pl" %t1268, { i64, [1 x i64] } %t1275)
  store %"compiler/lower:pl" %t1279, ptr %l595
  br label %bb210
bb210:
  %t1280 = load i64, ptr %l61, !tbaa !24
  store { i64, [1 x i64] } zeroinitializer, ptr %t1281
  %t1282 = getelementptr { i64, [1 x i64] }, ptr %t1281, i32 0, i32 0
  store i64 0, ptr %t1282
  %t1284 = insertvalue { i64 } undef, i64 %t1280, 0
  %t1285 = getelementptr { i64, [1 x i64] }, ptr %t1281, i32 0, i32 1
  store { i64 } %t1284, ptr %t1285
  %t1286 = load { i64, [1 x i64] }, ptr %t1281
  %t1287 = load ptr, ptr %l590, !tbaa !29
  %t1288 = load %"compiler/lower:pl", ptr %l595
  %t1290 = call %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2ewith(ptr %v0, ptr %s28, ptr %s28, ptr %t1287, %"compiler/lower:pl" %t1288, { i64, [1 x i64] } %t1286)
  store %"compiler/lower:pl" %t1290, ptr %l598
  br label %bb211
bb211:
  %t1291 = load i64, ptr %l61, !tbaa !24
  %t1293 = getelementptr { i64, ptr }, ptr %l55, i32 0, i32 1
  %t1294 = load ptr, ptr %t1293, !tbaa !27
  %t1295 = getelementptr i32, ptr %t1294, i64 %t1291
  %t1296 = load i32, ptr %t1295, !tbaa !33
  %t1297 = load { i64, [1 x i64] }, ptr %l3
  %t1298 = load %"compiler/source:Span", ptr %l4
  %t1299 = load ptr, ptr %l589, !tbaa !29
  %t1300 = load %"compiler/lower:pl", ptr %l598
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2einner(ptr %v0, ptr %s28, ptr %t1299, %"compiler/lower:pl" %t1300, i32 %t1296, { i64, [1 x i64] } %t1297, %"compiler/source:Span" %t1298)
  br label %bb212
bb212:
  call void @__olang_scope_close(ptr %s28)
  br label %bb213
bb213:
  %t1304 = load i64, ptr %l60, !tbaa !24
  %t1306 = add i64 %t1304, 1
  store i64 %t1306, ptr %l60, !tbaa !24
  br label %bb202
bb214:
  %t1308 = load ptr, ptr %l0, !tbaa !29
  %t1309 = load { i64, [1 x i64] }, ptr %l3
  %t1310 = load %"compiler/source:Span", ptr %l4
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eword(ptr %v0, ptr %s26, ptr %t1308, { i64, [1 x i64] } %t1309, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d26, i32 0, i32 1) }, %"compiler/source:Span" %t1310)
  br label %bb215
bb215:
  call void @__olang_scope_close(ptr %s26)
  br label %bb216
bb216:
  call void @__olang_scope_close(ptr %s25)
  br label %bb217
bb217:
  %t1314 = load ptr, ptr %l0, !tbaa !29
  %t1315 = load i32, ptr %l39, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2egoto(ptr %v0, ptr %t1314, i32 %t1315)
  br label %bb218
bb218:
  call void @__olang_scope_close(ptr %s22)
  br label %bb219
bb219:
  %t1318 = load i64, ptr %l52, !tbaa !24
  %t1320 = add i64 %t1318, 1
  store i64 %t1320, ptr %l52, !tbaa !24
  br label %bb176
bb220:
  %t1322 = load ptr, ptr %l0, !tbaa !29
  %t1323 = load i32, ptr %l39, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t1322, i32 %t1323)
  br label %bb221
bb221:
  call void @__olang_scope_close(ptr %s16)
  br label %bb236
bb222:
  %t1326 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t1327 = load i32, ptr %l616, !tbaa !23
  %t1329 = icmp ne i32 %t1327, %t1326
  br i1 %t1329, label %bb223, label %bb224
bb223:
  store %olang.scope zeroinitializer, ptr %s33
  %t1331 = load ptr, ptr %l6, !tbaa !29
  store ptr %t1331, ptr %l619, !tbaa !29
  %t1332 = load ptr, ptr %l0, !tbaa !29
  %t1333 = load i32, ptr %l2, !tbaa !23
  %t1336 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2earrayOf(ptr %v0, ptr %t1332, i32 %t1333)
  store i32 %t1336, ptr %l622
  br label %bb225
bb224:
  store %olang.scope zeroinitializer, ptr %s35
  %t1337 = load ptr, ptr %l0, !tbaa !29
  %t1338 = load %"compiler/source:Span", ptr %l4
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2egap(ptr %v0, ptr %s35, ptr %t1337, %"compiler/source:Span" %t1338, { i64, ptr } { i64 44, ptr getelementptr inbounds (<{ i64, [44 x i8] }>, ptr @.d27, i32 0, i32 1) })
  br label %bb234
bb225:
  %t1341 = load ptr, ptr %l619, !tbaa !29
  %t1342 = load i32, ptr %l622, !tbaa !23
  %t1343 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t1341, i32 %t1342)
  store i32 %t1343, ptr %l623
  br label %bb226
bb226:
  %t1344 = load i32, ptr %l623, !tbaa !23
  store i32 %t1344, ptr %l62, !tbaa !23
  %t1345 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1345, ptr %l624, !tbaa !29
  %t1346 = load { i64, [1 x i64] }, ptr %l3
  store { i64, [1 x i64] } %t1346, ptr %l625
  %t1347 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1347, ptr %l626, !tbaa !29
  %t1348 = load ptr, ptr %l0, !tbaa !29
  %t1349 = load i32, ptr %l62, !tbaa !23
  %t1352 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2ereadOnly(ptr %v0, ptr %t1348, i32 %t1349)
  store i32 %t1352, ptr %l629
  br label %bb227
bb227:
  %t1353 = load ptr, ptr %l626, !tbaa !29
  %t1354 = load i32, ptr %l629, !tbaa !23
  %t1355 = call { i64, ptr } @compiler_2flower_2ecompiler_2flower_3alowering_2espell(ptr %v0, ptr %s33, ptr %t1353, i32 %t1354, i1 true, i1 true, i1 false)
  store { i64, ptr } %t1355, ptr %l630
  br label %bb228
bb228:
  %t1356 = load { i64, ptr }, ptr %l630, !tbaa !27
  %t1357 = extractvalue { i64, ptr } %t1356, 1
  %t1358 = extractvalue { i64, ptr } %t1356, 0
  %t1359 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d28, i32 0, i32 1) }, 1
  %t1360 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d28, i32 0, i32 1) }, 0
  %t1361 = add i64 %t1358, %t1360
  %t1362 = call ptr @__olang_scope_alloc(ptr %s33, i64 %t1361)
  call void @olang_textcopy(ptr %t1362, ptr %t1357, i64 %t1358)
  %t1363 = getelementptr i8, ptr %t1362, i64 %t1358
  call void @olang_textcopy(ptr %t1363, ptr %t1359, i64 %t1360)
  %t1364 = insertvalue { i64, ptr } undef, i64 %t1361, 0
  %t1365 = insertvalue { i64, ptr } %t1364, ptr %t1362, 1
  %t1367 = extractvalue { i64, ptr } %t1365, 0
  %t1368 = extractvalue { i64, ptr } %t1365, 1
  %t1369 = mul i64 %t1367, 1
  %t1370 = call ptr @__olang_scope_alloc(ptr %s33, i64 %t1369)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1370, ptr %t1368, i64 %t1369, i1 false)
  %t1371 = insertvalue { i64, ptr } undef, i64 %t1367, 0
  %t1372 = insertvalue { i64, ptr } %t1371, ptr %t1370, 1
  %t1373 = load %"compiler/source:Span", ptr %l4
  %t1374 = load ptr, ptr %l624, !tbaa !29
  %t1375 = load { i64, [1 x i64] }, ptr %l625
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eword(ptr %v0, ptr %s33, ptr %t1374, { i64, [1 x i64] } %t1375, { i64, ptr } %t1372, %"compiler/source:Span" %t1373)
  br label %bb229
bb229:
  %t1378 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1378, ptr %l634, !tbaa !29
  store i32 22, ptr %l635
  %t1379 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  store i32 %t1379, ptr %l636, !tbaa !23
  %t1380 = load ptr, ptr %l0, !tbaa !29
  %t1381 = load %"compiler/lower:pl", ptr %l1
  %t1384 = call %"compiler/mir:Place" @compiler_2flower_2ecompiler_2flower_3alowering_2emk(ptr %v0, ptr %v1, ptr %t1380, %"compiler/lower:pl" %t1381)
  store %"compiler/mir:Place" %t1384, ptr %l639
  br label %bb230
bb230:
  store { i64, [4 x i64] } zeroinitializer, ptr %t1385
  %t1386 = getelementptr { i64, [4 x i64] }, ptr %t1385, i32 0, i32 0
  store i64 1, ptr %t1386
  %t1387 = load %"compiler/mir:Place", ptr %l639
  %t1388 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t1387, 0
  %t1389 = getelementptr { i64, [4 x i64] }, ptr %t1385, i32 0, i32 1
  store { %"compiler/mir:Place" } %t1388, ptr %t1389
  %t1390 = load { i64, [4 x i64] }, ptr %t1385
  %t1391 = mul i64 1, 40
  %t1392 = call ptr @__olang_scope_alloc_zeroed(ptr %s33, i64 %t1391)
  %t1393 = insertvalue { i64, ptr } undef, i64 1, 0
  %t1394 = insertvalue { i64, ptr } %t1393, ptr %t1392, 1
  store { i64, ptr } %t1394, ptr %l641, !tbaa !27
  %t1396 = getelementptr { i64, ptr }, ptr %l641, i32 0, i32 1
  %t1397 = load ptr, ptr %t1396, !tbaa !27
  %t1398 = getelementptr { i64, [4 x i64] }, ptr %t1397, i64 0
  store { i64, [4 x i64] } %t1390, ptr %t1398
  %t1399 = load %"compiler/source:Span", ptr %l4
  %t1400 = load ptr, ptr %l634, !tbaa !29
  %t1401 = load i32, ptr %l635
  %t1402 = load i32, ptr %l636, !tbaa !23
  %t1403 = load { i64, ptr }, ptr %l641, !tbaa !27
  %t1405 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s33, ptr %t1400, i32 %t1401, i32 %t1402, { i64, ptr } %t1403, %"compiler/source:Span" %t1399)
  store { i64, [4 x i64] } %t1405, ptr %l643
  br label %bb231
bb231:
  %t1406 = load { i64, [4 x i64] }, ptr %l643
  %t1407 = load ptr, ptr %l0, !tbaa !29
  %t1409 = load %"compiler/source:Span", ptr %l4
  %t1410 = load ptr, ptr %l0, !tbaa !29
  %t1411 = load %"compiler/source:Span", ptr %l4
  %t1412 = load { i64, [1 x i64] }, ptr %l3
  %t1413 = load %"compiler/lower:pl", ptr %l1
  %t1414 = load i32, ptr %l62, !tbaa !23
  %t1415 = getelementptr { ptr, %"compiler/source:Span", { i64, [1 x i64] }, %"compiler/lower:pl", i32, ptr, ptr }, ptr null, i32 1
  %t1416 = ptrtoint ptr %t1415 to i64
  %t1418 = getelementptr { ptr, %"compiler/source:Span", { i64, [1 x i64] }, %"compiler/lower:pl", i32, ptr, ptr }, ptr %t1417, i32 0, i32 0
  store ptr %t1410, ptr %t1418, !tbaa !28
  %t1420 = getelementptr { ptr, %"compiler/source:Span", { i64, [1 x i64] }, %"compiler/lower:pl", i32, ptr, ptr }, ptr %t1417, i32 0, i32 1
  store %"compiler/source:Span" %t1411, ptr %t1420, !tbaa !28
  %t1422 = getelementptr { ptr, %"compiler/source:Span", { i64, [1 x i64] }, %"compiler/lower:pl", i32, ptr, ptr }, ptr %t1417, i32 0, i32 2
  store { i64, [1 x i64] } %t1412, ptr %t1422, !tbaa !28
  %t1424 = getelementptr { ptr, %"compiler/source:Span", { i64, [1 x i64] }, %"compiler/lower:pl", i32, ptr, ptr }, ptr %t1417, i32 0, i32 3
  store %"compiler/lower:pl" %t1413, ptr %t1424, !tbaa !28
  %t1426 = getelementptr { ptr, %"compiler/source:Span", { i64, [1 x i64] }, %"compiler/lower:pl", i32, ptr, ptr }, ptr %t1417, i32 0, i32 4
  store i32 %t1414, ptr %t1426, !tbaa !28
  call void @__olang_scope_escape(ptr %v0)
  %t1428 = getelementptr { ptr, %"compiler/source:Span", { i64, [1 x i64] }, %"compiler/lower:pl", i32, ptr, ptr }, ptr %t1417, i32 0, i32 5
  store ptr %v0, ptr %t1428, !tbaa !28
  call void @__olang_scope_escape(ptr %v1)
  %t1429 = getelementptr { ptr, %"compiler/source:Span", { i64, [1 x i64] }, %"compiler/lower:pl", i32, ptr, ptr }, ptr %t1417, i32 0, i32 6
  store ptr %v1, ptr %t1429, !tbaa !28
  %t1430 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_29, 0
  %t1431 = insertvalue { ptr, ptr } %t1430, ptr %t1417, 1
  %t1436 = extractvalue { ptr, ptr } %t1431, 0
  %t1437 = extractvalue { ptr, ptr } %t1431, 1
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eeachIndex(ptr %v0, ptr %s33, ptr %t1407, { i64, [4 x i64] } %t1406, %"compiler/source:Span" %t1409, ptr %t1436, ptr %t1437)
  br label %bb232
bb232:
  %t1438 = load ptr, ptr %l0, !tbaa !29
  %t1439 = load { i64, [1 x i64] }, ptr %l3
  %t1440 = load %"compiler/source:Span", ptr %l4
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eword(ptr %v0, ptr %s33, ptr %t1438, { i64, [1 x i64] } %t1439, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d30, i32 0, i32 1) }, %"compiler/source:Span" %t1440)
  br label %bb233
bb233:
  call void @__olang_scope_close(ptr %s33)
  br label %bb235
bb234:
  call void @__olang_scope_close(ptr %s35)
  br label %bb235
bb235:
  br label %bb236
bb236:
  br label %bb237
bb237:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3alowering_2erenderStr(ptr %v0, ptr %v1, ptr %a0, %"compiler/lower:pl" %a1, i32 %a2, { i64, [1 x i64] } %a3, %"compiler/source:Span" %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/lower:pl"
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca { { i64, [7 x i64] }, i32 }
  %l8 = alloca { i64, [7 x i64] }
  %l9 = alloca i32
  %l10 = alloca i32
  %l11 = alloca { i64, [4 x i64] }
  %l12 = alloca i32
  %l13 = alloca i32
  %l14 = alloca i32
  %l15 = alloca i32
  %l16 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l27 = alloca i64
  %l37 = alloca { { i64, [7 x i64] }, i32 }
  %l40 = alloca ptr
  %l43 = alloca i32
  %l44 = alloca { i64, ptr }
  %l45 = alloca { i64, ptr }
  %l49 = alloca i1
  %l50 = alloca { i64, [4 x i64] }
  %l51 = alloca ptr
  %l52 = alloca i32
  %l55 = alloca %"compiler/mir:Place"
  %l59 = alloca { i64, [4 x i64] }
  %l60 = alloca ptr
  %l61 = alloca i32
  %l64 = alloca %"compiler/mir:Place"
  %l68 = alloca { i64, [4 x i64] }
  %l71 = alloca i32
  %l74 = alloca i32
  %l78 = alloca i32
  %l80 = alloca ptr
  %l81 = alloca i32
  %l83 = alloca %"compiler/lower:level"
  %l86 = alloca i32
  %l94 = alloca { i64, ptr }
  %l96 = alloca i64
  %l105 = alloca i64
  %l108 = alloca i64
  %l126 = alloca i64
  %l131 = alloca { i64, [1 x i64] }
  %l138 = alloca ptr
  %l139 = alloca { i64, [7 x i64] }
  %l143 = alloca { i64, ptr }
  %l144 = alloca %"compiler/mir:Range"
  %l148 = alloca %"compiler/mir:Range"
  %l150 = alloca %"compiler/mir:Place"
  %l154 = alloca %"compiler/mir:Call"
  %l155 = alloca i32
  %l162 = alloca ptr
  %l163 = alloca %"compiler/source:Span"
  %l164 = alloca { i64, [1 x i64] }
  %l165 = alloca i32
  %l167 = alloca %"compiler/mir:Place"
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca i1
  %t68 = alloca { i64, [15 x i64] }, align 8
  %t83 = alloca { i64, [4 x i64] }, align 8
  %t89 = alloca { i64, [15 x i64] }, align 8
  %t141 = alloca { i64, [21 x i64] }, align 8
  %t237 = alloca { i64, [1 x i64] }, align 8
  %t244 = alloca { i64, [1 x i64] }, align 8
  %t304 = alloca { i64, [8 x i64] }, align 8
  %t324 = alloca { i64, [4 x i64] }, align 8
  %t330 = alloca { i64, [21 x i64] }, align 8
  %t349 = alloca { i64, [21 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/lower:pl" %a1, ptr %l1
  store %"compiler/source:Span" %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i64 @compiler_2flower_2ecompiler_2flower_3alowering_2estrBody(ptr %v0, ptr %t1, i32 %a2)
  store i64 %t5, ptr %l27
  br label %bb1
bb1:
  %t6 = load i64, ptr %l27, !tbaa !24
  store i64 %t6, ptr %l5, !tbaa !24
  %t7 = load i64, ptr %l5, !tbaa !24
  %t9 = icmp slt i64 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/lower:lowering", ptr %t12, i32 0, i32 2
  %t15 = load ptr, ptr %t14, !tbaa !29
  store ptr %t15, ptr %l6, !tbaa !29
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t18 = load i64, ptr %l5, !tbaa !24
  %t20 = trunc i64 %t18 to i32
  %t24 = call { { i64, [7 x i64] }, i32 } @compiler_2flower_2ecompiler_2flower_3alowering_2ebodyCallee(ptr %v0, ptr %t17, i32 %t20)
  store { { i64, [7 x i64] }, i32 } %t24, ptr %l37
  br label %bb5
bb5:
  %t25 = load { { i64, [7 x i64] }, i32 }, ptr %l37
  store { { i64, [7 x i64] }, i32 } %t25, ptr %l7
  %t26 = getelementptr { { i64, [7 x i64] }, i32 }, ptr %l7, i32 0, i32 0
  %t27 = load { i64, [7 x i64] }, ptr %t26
  store { i64, [7 x i64] } %t27, ptr %l8
  %t29 = getelementptr { { i64, [7 x i64] }, i32 }, ptr %l7, i32 0, i32 1
  %t30 = load i32, ptr %t29, !tbaa !23
  store i32 %t30, ptr %l9, !tbaa !23
  %t32 = load ptr, ptr %l6, !tbaa !29
  store ptr %t32, ptr %l40, !tbaa !29
  %t33 = load ptr, ptr %l6, !tbaa !29
  %t34 = load i32, ptr %l9, !tbaa !23
  %t37 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t33, i32 %t34)
  store i32 %t37, ptr %l43
  br label %bb6
bb6:
  %t38 = load ptr, ptr %l40, !tbaa !29
  %t39 = load i32, ptr %l43, !tbaa !23
  %t40 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t38, i32 %t39)
  store { i64, ptr } %t40, ptr %l44
  br label %bb7
bb7:
  %t41 = load { i64, ptr }, ptr %l44, !tbaa !27
  store { i64, ptr } %t41, ptr %l45, !tbaa !27
  %t42 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = getelementptr i32, ptr %t43, i64 0
  %t45 = load i32, ptr %t44, !tbaa !33
  store i32 %t45, ptr %l10, !tbaa !23
  %t47 = load ptr, ptr %l6, !tbaa !29
  %t48 = load i32, ptr %l10, !tbaa !23
  %t51 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t47, i32 %t48)
  store i1 %t51, ptr %l49
  br label %bb8
bb8:
  %t52 = load i1, ptr %l49, !tbaa !21
  br i1 %t52, label %bb9, label %bb10
bb9:
  %t53 = load ptr, ptr %l0, !tbaa !29
  store ptr %t53, ptr %l51, !tbaa !29
  %t54 = load i32, ptr %l10, !tbaa !23
  store i32 %t54, ptr %l52, !tbaa !23
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t56 = load %"compiler/lower:pl", ptr %l1
  %t59 = call %"compiler/mir:Place" @compiler_2flower_2ecompiler_2flower_3alowering_2emk(ptr %v0, ptr %v1, ptr %t55, %"compiler/lower:pl" %t56)
  store %"compiler/mir:Place" %t59, ptr %l55
  br label %bb11
bb10:
  %t60 = load ptr, ptr %l0, !tbaa !29
  store ptr %t60, ptr %l60, !tbaa !29
  %t61 = load i32, ptr %l10, !tbaa !23
  store i32 %t61, ptr %l61, !tbaa !23
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t63 = load %"compiler/lower:pl", ptr %l1
  %t66 = call %"compiler/mir:Place" @compiler_2flower_2ecompiler_2flower_3alowering_2emk(ptr %v0, ptr %v1, ptr %t62, %"compiler/lower:pl" %t63)
  store %"compiler/mir:Place" %t66, ptr %l64
  br label %bb13
bb11:
  %t67 = load i32, ptr %l10, !tbaa !23
  store { i64, [15 x i64] } zeroinitializer, ptr %t68
  %t69 = getelementptr { i64, [15 x i64] }, ptr %t68, i32 0, i32 0
  store i64 1, ptr %t69
  %t70 = load %"compiler/mir:Place", ptr %l55
  %t71 = insertvalue { %"compiler/mir:Place", i32 } undef, %"compiler/mir:Place" %t70, 0
  %t73 = insertvalue { %"compiler/mir:Place", i32 } %t71, i32 %t67, 1
  %t74 = getelementptr { i64, [15 x i64] }, ptr %t68, i32 0, i32 1
  store { %"compiler/mir:Place", i32 } %t73, ptr %t74
  %t75 = load { i64, [15 x i64] }, ptr %t68
  %t76 = load %"compiler/source:Span", ptr %l4
  %t77 = load ptr, ptr %l51, !tbaa !29
  %t78 = load i32, ptr %l52, !tbaa !23
  %t81 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %t77, i32 %t78, { i64, [15 x i64] } %t75, %"compiler/source:Span" %t76)
  store { i64, [4 x i64] } %t81, ptr %l59
  br label %bb12
bb12:
  %t82 = load { i64, [4 x i64] }, ptr %l59
  store { i64, [4 x i64] } %t82, ptr %l50
  br label %bb15
bb13:
  store { i64, [4 x i64] } zeroinitializer, ptr %t83
  %t84 = getelementptr { i64, [4 x i64] }, ptr %t83, i32 0, i32 0
  store i64 1, ptr %t84
  %t85 = load %"compiler/mir:Place", ptr %l64
  %t86 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t85, 0
  %t87 = getelementptr { i64, [4 x i64] }, ptr %t83, i32 0, i32 1
  store { %"compiler/mir:Place" } %t86, ptr %t87
  %t88 = load { i64, [4 x i64] }, ptr %t83
  store { i64, [15 x i64] } zeroinitializer, ptr %t89
  %t90 = getelementptr { i64, [15 x i64] }, ptr %t89, i32 0, i32 0
  store i64 0, ptr %t90
  %t92 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t88, 0
  %t93 = getelementptr { i64, [15 x i64] }, ptr %t89, i32 0, i32 1
  store { { i64, [4 x i64] } } %t92, ptr %t93
  %t94 = load { i64, [15 x i64] }, ptr %t89
  %t95 = load %"compiler/source:Span", ptr %l4
  %t96 = load ptr, ptr %l60, !tbaa !29
  %t97 = load i32, ptr %l61, !tbaa !23
  %t100 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %t96, i32 %t97, { i64, [15 x i64] } %t94, %"compiler/source:Span" %t95)
  store { i64, [4 x i64] } %t100, ptr %l68
  br label %bb14
bb14:
  %t101 = load { i64, [4 x i64] }, ptr %l68
  store { i64, [4 x i64] } %t101, ptr %l50
  br label %bb15
bb15:
  %t102 = load { i64, [4 x i64] }, ptr %l50
  store { i64, [4 x i64] } %t102, ptr %l11
  %t103 = load ptr, ptr %l6, !tbaa !29
  %t104 = load i32, ptr %l9, !tbaa !23
  %t107 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t103, i32 %t104)
  store i32 %t107, ptr %l71
  br label %bb16
bb16:
  %t108 = load i32, ptr %l71, !tbaa !23
  store i32 %t108, ptr %l12, !tbaa !23
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t111 = getelementptr %"compiler/lower:lowering", ptr %t109, i32 0, i32 3
  %t113 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t111)
  store i32 %t113, ptr %l74
  br label %bb17
bb17:
  %t114 = load i32, ptr %l74, !tbaa !23
  store i32 %t114, ptr %l13, !tbaa !23
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t116 = load i32, ptr %l12, !tbaa !23
  %t117 = load %"compiler/source:Span", ptr %l4
  %t121 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2etemp(ptr %v0, ptr %t115, i32 %t116, %"compiler/source:Span" %t117)
  store i32 %t121, ptr %l78
  br label %bb18
bb18:
  %t122 = load i32, ptr %l78, !tbaa !23
  store i32 %t122, ptr %l14, !tbaa !23
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t125 = getelementptr %"compiler/lower:lowering", ptr %t123, i32 0, i32 3
  store ptr %t125, ptr %l80, !tbaa !29
  store i32 1, ptr %l81
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t128 = call %"compiler/lower:level" @compiler_2flower_2ecompiler_2flower_3alowering_2etop(ptr %v0, ptr %t126)
  store %"compiler/lower:level" %t128, ptr %l83
  br label %bb19
bb19:
  %t129 = getelementptr %"compiler/lower:level", ptr %l83, i32 0, i32 0
  %t130 = load i32, ptr %t129, !tbaa !23
  %t131 = load %"compiler/source:Span", ptr %l4
  %t132 = load ptr, ptr %l80, !tbaa !29
  %t133 = load i32, ptr %l81
  %t136 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddScope(ptr %v0, ptr %t132, i32 %t133, i32 %t130, i32 -1, %"compiler/source:Span" %t131, i32 0)
  store i32 %t136, ptr %l86
  br label %bb20
bb20:
  %t137 = load i32, ptr %l86, !tbaa !23
  store i32 %t137, ptr %l15, !tbaa !23
  %t138 = load ptr, ptr %l0, !tbaa !29
  %t139 = load %"compiler/source:Span", ptr %l4
  %t140 = load i32, ptr %l15, !tbaa !23
  store { i64, [21 x i64] } zeroinitializer, ptr %t141
  %t142 = getelementptr { i64, [21 x i64] }, ptr %t141, i32 0, i32 0
  store i64 3, ptr %t142
  %t144 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t139, 0
  %t146 = insertvalue { %"compiler/source:Span", i32 } %t144, i32 %t140, 1
  %t147 = getelementptr { i64, [21 x i64] }, ptr %t141, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t146, ptr %t147
  %t148 = load { i64, [21 x i64] }, ptr %t141
  %t150 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t148, ptr %t150
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s0, ptr %t138, ptr %t150)
  br label %bb21
bb21:
  %t153 = load ptr, ptr %l6, !tbaa !29
  %t154 = load i32, ptr %l9, !tbaa !23
  %t157 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopeVarsOf(ptr %v0, ptr %s0, ptr %t153, i32 %t154)
  store { i64, ptr } %t157, ptr %l94
  br label %bb22
bb22:
  %t158 = load { i64, ptr }, ptr %l94, !tbaa !27
  store { i64, ptr } %t158, ptr %l16, !tbaa !27
  %t159 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t161 = extractvalue { i64, ptr } %t159, 0
  store i64 %t161, ptr %l96, !tbaa !24
  %t162 = load i64, ptr %l96, !tbaa !24
  %t163 = icmp sge i64 %t162, 0
  br i1 %t163, label %bb23, label %bb24
bb23:
  %t165 = load i64, ptr %l96, !tbaa !24
  %t166 = icmp sle i64 %t165, 576460752303423487
  br i1 %t166, label %bb25, label %bb26
bb24:
  call void @__olang_check_failed(ptr @olang_loc_838d4f7d17068d91_8ef0a18bf216f57d)
  unreachable
bb25:
  %t168 = load i64, ptr %l96, !tbaa !24
  %t169 = mul i64 %t168, 16
  %t170 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t169)
  %t171 = insertvalue { i64, ptr } undef, i64 %t168, 0
  %t172 = insertvalue { i64, ptr } %t171, ptr %t170, 1
  store { i64, ptr } %t172, ptr %l17, !tbaa !27
  store i64 0, ptr %l18, !tbaa !24
  %t174 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t176 = extractvalue { i64, ptr } %t174, 0
  store i64 %t176, ptr %l19, !tbaa !24
  store i64 1, ptr %l20, !tbaa !24
  %t178 = load i64, ptr %l19, !tbaa !24
  %t179 = load i64, ptr %l18, !tbaa !24
  %t182 = icmp sgt i64 %t178, %t179
  br i1 %t182, label %bb27, label %bb28
bb26:
  call void @__olang_check_failed(ptr @olang_loc_838d4f7d17068d91_8ef0a18bf216f57d)
  unreachable
bb27:
  %t184 = load i64, ptr %l20, !tbaa !24
  %t186 = icmp sgt i64 %t184, 0
  br i1 %t186, label %bb29, label %bb30
bb28:
  store i64 0, ptr %l105, !tbaa !24
  br label %bb32
bb29:
  %t188 = load i64, ptr %l19, !tbaa !24
  %t189 = load i64, ptr %l18, !tbaa !24
  %t192 = sub i64 %t188, %t189
  %t193 = load i64, ptr %l20, !tbaa !24
  %t196 = add i64 %t192, %t193
  %t198 = sub i64 %t196, 1
  %t199 = load i64, ptr %l20, !tbaa !24
  %t202 = sdiv i64 %t198, %t199
  store i64 %t202, ptr %l108, !tbaa !24
  br label %bb31
bb30:
  store i64 0, ptr %l108, !tbaa !24
  br label %bb31
bb31:
  %t204 = load i64, ptr %l108, !tbaa !24
  store i64 %t204, ptr %l105, !tbaa !24
  br label %bb32
bb32:
  %t205 = load i64, ptr %l105, !tbaa !24
  store i64 %t205, ptr %l21, !tbaa !24
  store i64 0, ptr %l22, !tbaa !24
  br label %bb33
bb33:
  store %olang.scope zeroinitializer, ptr %s3
  %t206 = load i64, ptr %l22, !tbaa !24
  %t207 = load i64, ptr %l21, !tbaa !24
  %t210 = icmp slt i64 %t206, %t207
  %t212 = xor i1 %t210, true
  br i1 %t212, label %bb34, label %bb35
bb34:
  call void @__olang_scope_close(ptr %s3)
  br label %bb41
bb35:
  br label %bb36
bb36:
  %t214 = load i64, ptr %l18, !tbaa !24
  %t215 = load i64, ptr %l22, !tbaa !24
  %t216 = load i64, ptr %l20, !tbaa !24
  %t219 = mul i64 %t215, %t216
  %t222 = add i64 %t214, %t219
  store i64 %t222, ptr %l23, !tbaa !24
  %t224 = load i64, ptr %l23, !tbaa !24
  store i64 %t224, ptr %l126, !tbaa !24
  %t225 = load i64, ptr %l23, !tbaa !24
  %t227 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t228 = load ptr, ptr %t227, !tbaa !27
  %t229 = getelementptr i64, ptr %t228, i64 %t225
  %t230 = load i64, ptr %t229, !tbaa !34
  %t231 = load i64, ptr @G_2ecompiler_2ftypes_2eResultVar, !tbaa !24
  %t234 = icmp eq i64 %t230, %t231
  br i1 %t234, label %bb37, label %bb38
bb37:
  %t236 = load i32, ptr %l15, !tbaa !23
  store { i64, [1 x i64] } zeroinitializer, ptr %t237
  %t238 = getelementptr { i64, [1 x i64] }, ptr %t237, i32 0, i32 0
  store i64 0, ptr %t238
  %t240 = insertvalue { i32 } undef, i32 %t236, 0
  %t241 = getelementptr { i64, [1 x i64] }, ptr %t237, i32 0, i32 1
  store { i32 } %t240, ptr %t241
  %t242 = load { i64, [1 x i64] }, ptr %t237
  store { i64, [1 x i64] } %t242, ptr %l131
  br label %bb39
bb38:
  store { i64, [1 x i64] } zeroinitializer, ptr %t244
  %t245 = getelementptr { i64, [1 x i64] }, ptr %t244, i32 0, i32 0
  store i64 2, ptr %t245
  %t246 = load { i64, [1 x i64] }, ptr %t244
  store { i64, [1 x i64] } %t246, ptr %l131
  br label %bb39
bb39:
  %t248 = load { i64, [1 x i64] }, ptr %l131
  %t249 = load i64, ptr %l126, !tbaa !24
  %t250 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t251 = load ptr, ptr %t250, !tbaa !27
  %t252 = getelementptr { i64, [1 x i64] }, ptr %t251, i64 %t249
  store { i64, [1 x i64] } %t248, ptr %t252
  call void @__olang_scope_close(ptr %s3)
  br label %bb40
bb40:
  %t253 = load i64, ptr %l22, !tbaa !24
  %t255 = add i64 %t253, 1
  store i64 %t255, ptr %l22, !tbaa !24
  br label %bb33
bb41:
  %t257 = load ptr, ptr %l0, !tbaa !29
  %t259 = getelementptr %"compiler/lower:lowering", ptr %t257, i32 0, i32 3
  store ptr %t259, ptr %l138, !tbaa !29
  %t260 = load { i64, [7 x i64] }, ptr %l8
  store { i64, [7 x i64] } %t260, ptr %l139
  %t261 = load ptr, ptr %l0, !tbaa !29
  %t263 = getelementptr %"compiler/lower:lowering", ptr %t261, i32 0, i32 3
  %t264 = load { i64, [4 x i64] }, ptr %l11
  %t265 = mul i64 1, 40
  %t266 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t265)
  %t267 = insertvalue { i64, ptr } undef, i64 1, 0
  %t268 = insertvalue { i64, ptr } %t267, ptr %t266, 1
  store { i64, ptr } %t268, ptr %l143, !tbaa !27
  %t270 = getelementptr { i64, ptr }, ptr %l143, i32 0, i32 1
  %t271 = load ptr, ptr %t270, !tbaa !27
  %t272 = getelementptr { i64, [4 x i64] }, ptr %t271, i64 0
  store { i64, [4 x i64] } %t264, ptr %t272
  %t274 = load { i64, ptr }, ptr %l143, !tbaa !27
  %t275 = call %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eArgs(ptr %v0, ptr %s0, ptr %t263, { i64, ptr } %t274)
  store %"compiler/mir:Range" %t275, ptr %l144
  br label %bb42
bb42:
  %t276 = load ptr, ptr %l0, !tbaa !29
  %t278 = getelementptr %"compiler/lower:lowering", ptr %t276, i32 0, i32 3
  %t279 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t282 = call %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eScopeRefs(ptr %v0, ptr %s0, ptr %t278, { i64, ptr } %t279)
  store %"compiler/mir:Range" %t282, ptr %l148
  br label %bb43
bb43:
  %t283 = load i32, ptr %l14, !tbaa !23
  %t285 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t283)
  store %"compiler/mir:Place" %t285, ptr %l150
  br label %bb44
bb44:
  %t286 = load i32, ptr %l13, !tbaa !23
  %t287 = load i32, ptr @G_2ecompiler_2fmir_2eNoLocal, !tbaa !23
  %t288 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t289 = load { i64, [7 x i64] }, ptr %l139
  %t290 = load %"compiler/mir:Range", ptr %l144
  %t291 = load %"compiler/mir:Range", ptr %l148
  %t292 = load %"compiler/mir:Place", ptr %l150
  %t296 = call %"compiler/mir:Call" @compiler_2fmir_3aCall_2ector(ptr %s0, { i64, [7 x i64] } %t289, %"compiler/mir:Range" %t290, %"compiler/mir:Range" %t291, %"compiler/mir:Place" %t292, i1 true, i32 %t286, i32 %t287, i32 %t288)
  store %"compiler/mir:Call" %t296, ptr %l154
  br label %bb45
bb45:
  %t297 = load ptr, ptr %l138, !tbaa !29
  %t298 = load %"compiler/mir:Call", ptr %l154
  %t299 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddCall(ptr %v0, ptr %t297, %"compiler/mir:Call" %t298)
  store i32 %t299, ptr %l155
  br label %bb46
bb46:
  %t300 = load i32, ptr %l155, !tbaa !23
  %t301 = load ptr, ptr %l0, !tbaa !29
  %t302 = load %"compiler/source:Span", ptr %l4
  store { i64, [8 x i64] } zeroinitializer, ptr %t304
  %t305 = getelementptr { i64, [8 x i64] }, ptr %t304, i32 0, i32 0
  store i64 4, ptr %t305
  %t307 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t302, 0
  %t309 = insertvalue { %"compiler/source:Span", i32 } %t307, i32 %t300, 1
  %t310 = getelementptr { i64, [8 x i64] }, ptr %t304, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t309, ptr %t310
  %t311 = load { i64, [8 x i64] }, ptr %t304
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t301, { i64, [8 x i64] } %t311)
  br label %bb47
bb47:
  %t314 = load ptr, ptr %l0, !tbaa !29
  %t315 = load i32, ptr %l13, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t314, i32 %t315)
  br label %bb48
bb48:
  %t318 = load ptr, ptr %l0, !tbaa !29
  store ptr %t318, ptr %l162, !tbaa !29
  %t319 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t319, ptr %l163
  store { i64, [1 x i64] } %a3, ptr %l164
  store i32 0, ptr %l165
  %t321 = load i32, ptr %l14, !tbaa !23
  %t323 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t321)
  store %"compiler/mir:Place" %t323, ptr %l167
  br label %bb49
bb49:
  store { i64, [4 x i64] } zeroinitializer, ptr %t324
  %t325 = getelementptr { i64, [4 x i64] }, ptr %t324, i32 0, i32 0
  store i64 1, ptr %t325
  %t326 = load %"compiler/mir:Place", ptr %l167
  %t327 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t326, 0
  %t328 = getelementptr { i64, [4 x i64] }, ptr %t324, i32 0, i32 1
  store { %"compiler/mir:Place" } %t327, ptr %t328
  %t329 = load { i64, [4 x i64] }, ptr %t324
  store { i64, [21 x i64] } zeroinitializer, ptr %t330
  %t331 = getelementptr { i64, [21 x i64] }, ptr %t330, i32 0, i32 0
  store i64 9, ptr %t331
  %t332 = load %"compiler/source:Span", ptr %l163
  %t333 = insertvalue { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } undef, %"compiler/source:Span" %t332, 0
  %t334 = load { i64, [1 x i64] }, ptr %l164
  %t335 = insertvalue { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } %t333, { i64, [1 x i64] } %t334, 1
  %t336 = load i32, ptr %l165
  %t337 = insertvalue { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } %t335, i32 %t336, 2
  %t339 = insertvalue { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } %t337, { i64, [4 x i64] } %t329, 3
  %t340 = getelementptr { i64, [21 x i64] }, ptr %t330, i32 0, i32 1
  store { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } %t339, ptr %t340
  %t341 = load { i64, [21 x i64] }, ptr %t330
  %t343 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t341, ptr %t343
  %t344 = load ptr, ptr %l162, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s0, ptr %t344, ptr %t343)
  br label %bb50
bb50:
  %t346 = load ptr, ptr %l0, !tbaa !29
  %t347 = load %"compiler/source:Span", ptr %l4
  %t348 = load i32, ptr %l15, !tbaa !23
  store { i64, [21 x i64] } zeroinitializer, ptr %t349
  %t350 = getelementptr { i64, [21 x i64] }, ptr %t349, i32 0, i32 0
  store i64 4, ptr %t350
  %t352 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t347, 0
  %t354 = insertvalue { %"compiler/source:Span", i32 } %t352, i32 %t348, 1
  %t355 = getelementptr { i64, [21 x i64] }, ptr %t349, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t354, ptr %t355
  %t356 = load { i64, [21 x i64] }, ptr %t349
  %t358 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t356, ptr %t358
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s0, ptr %t346, ptr %t358)
  br label %bb51
bb51:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2eret(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca { i64, [4 x i64] }
  %l5 = alloca i32
  %l18 = alloca i32
  %l19 = alloca ptr
  %l20 = alloca ptr
  %l21 = alloca i32
  %l22 = alloca %"compiler/source:Span"
  %l24 = alloca { i64, [1 x i64] }
  %l25 = alloca { i64, [4 x i64] }
  %l32 = alloca i32
  %l37 = alloca i1
  %l39 = alloca i1
  %l43 = alloca i1
  %l51 = alloca ptr
  %l52 = alloca %"compiler/source:Span"
  %l54 = alloca %"compiler/mir:Place"
  %t9 = alloca { i64, [4 x i64] }, align 8
  %t12 = alloca { i64, [8 x i64] }, align 8
  %t105 = alloca { i64, [4 x i64] }, align 8
  %t111 = alloca { i64, [8 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eleave(ptr %v0, ptr %t5, i64 0)
  br label %bb3
bb2:
  br label %bb5
bb3:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load %"compiler/source:Span", ptr %l1
  store { i64, [4 x i64] } zeroinitializer, ptr %t9
  %t10 = getelementptr { i64, [4 x i64] }, ptr %t9, i32 0, i32 0
  store i64 0, ptr %t10
  %t11 = load { i64, [4 x i64] }, ptr %t9
  store { i64, [8 x i64] } zeroinitializer, ptr %t12
  %t13 = getelementptr { i64, [8 x i64] }, ptr %t12, i32 0, i32 0
  store i64 5, ptr %t13
  %t15 = insertvalue { %"compiler/source:Span", { i64, [4 x i64] } } undef, %"compiler/source:Span" %t8, 0
  %t17 = insertvalue { %"compiler/source:Span", { i64, [4 x i64] } } %t15, { i64, [4 x i64] } %t11, 1
  %t18 = getelementptr { i64, [8 x i64] }, ptr %t12, i32 0, i32 1
  store { %"compiler/source:Span", { i64, [4 x i64] } } %t17, ptr %t18
  %t19 = load { i64, [8 x i64] }, ptr %t12
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t7, { i64, [8 x i64] } %t19)
  br label %bb4
bb4:
  br label %ret
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/lower:lowering", ptr %t22, i32 0, i32 2
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/lower:lowering", ptr %t26, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !29
  %t31 = getelementptr %"compiler/typed:Body", ptr %t29, i32 0, i32 2
  %t32 = load i32, ptr %t31, !tbaa !23
  %t35 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t25, i32 %t32)
  store i32 %t35, ptr %l18
  br label %bb6
bb6:
  %t36 = load i32, ptr %l18, !tbaa !23
  store i32 %t36, ptr %l3, !tbaa !23
  %t37 = load ptr, ptr %l0, !tbaa !29
  store ptr %t37, ptr %l19, !tbaa !29
  %t38 = load ptr, ptr %l2, !tbaa !29
  store ptr %t38, ptr %l20, !tbaa !29
  %t39 = load i32, ptr %l3, !tbaa !23
  store i32 %t39, ptr %l21, !tbaa !23
  %t40 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t40, ptr %l22
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = call { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eresultScope(ptr %v0, ptr %t41)
  store { i64, [1 x i64] } %t43, ptr %l24
  br label %bb7
bb7:
  %t44 = load ptr, ptr %l19, !tbaa !29
  %t45 = load ptr, ptr %l20, !tbaa !29
  %t46 = load i32, ptr %l21, !tbaa !23
  %t47 = load %"compiler/source:Span", ptr %l22
  %t48 = load { i64, [1 x i64] }, ptr %l24
  %t49 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2efitAt(ptr %v0, ptr %v1, ptr %t44, ptr %t45, i32 %t46, %"compiler/source:Span" %t47, { i64, [1 x i64] } %t48)
  store { i64, [4 x i64] } %t49, ptr %l25
  br label %bb8
bb8:
  %t50 = load { i64, [4 x i64] }, ptr %l25
  store { i64, [4 x i64] } %t50, ptr %l4
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = getelementptr %"compiler/lower:lowering", ptr %t51, i32 0, i32 7
  %t54 = load i1, ptr %t53, !tbaa !21
  br i1 %t54, label %bb9, label %bb10
bb9:
  br label %ret
bb10:
  br label %bb11
bb11:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t57 = load { i64, [4 x i64] }, ptr %l4
  %t58 = load i32, ptr %l3, !tbaa !23
  %t59 = load %"compiler/source:Span", ptr %l1
  %t64 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2elocal(ptr %v0, ptr %t56, { i64, [4 x i64] } %t57, i32 %t58, %"compiler/source:Span" %t59)
  store i32 %t64, ptr %l32
  br label %bb12
bb12:
  %t65 = load i32, ptr %l32, !tbaa !23
  store i32 %t65, ptr %l5, !tbaa !23
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t67 = load ptr, ptr %l2, !tbaa !29
  %t69 = load i32, ptr %l3, !tbaa !23
  %t73 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2efits(ptr %v0, ptr %v1, ptr %t66, ptr %t67, i32 %t69)
  store i1 %t73, ptr %l37
  br label %bb13
bb13:
  %t74 = load i1, ptr %l37, !tbaa !21
  %t75 = xor i1 %t74, true
  br i1 %t75, label %bb14, label %bb15
bb14:
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t78 = load ptr, ptr %l2, !tbaa !29
  %t79 = load i32, ptr %l3, !tbaa !23
  %t83 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2ewidens(ptr %v0, ptr %v1, ptr %t77, ptr %t78, i32 %t79)
  store i1 %t83, ptr %l43
  br label %bb16
bb15:
  store i1 false, ptr %l39, !tbaa !21
  br label %bb17
bb16:
  %t84 = load i1, ptr %l43, !tbaa !21
  %t85 = xor i1 %t84, true
  store i1 %t85, ptr %l39, !tbaa !21
  br label %bb17
bb17:
  %t87 = load i1, ptr %l39, !tbaa !21
  br i1 %t87, label %bb18, label %bb19
bb18:
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t89 = load i32, ptr %l5, !tbaa !23
  %t90 = load i32, ptr %l3, !tbaa !23
  %t91 = load ptr, ptr %l2, !tbaa !29
  %t92 = load %"compiler/source:Span", ptr %l1
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eretArrays(ptr %v0, ptr %v1, ptr %t88, i32 %t89, i32 %t90, ptr %t91, %"compiler/source:Span" %t92)
  br label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb21
bb21:
  %t98 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eleave(ptr %v0, ptr %t98, i64 0)
  br label %bb22
bb22:
  %t100 = load ptr, ptr %l0, !tbaa !29
  store ptr %t100, ptr %l51, !tbaa !29
  %t101 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t101, ptr %l52
  %t102 = load i32, ptr %l5, !tbaa !23
  %t104 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t102)
  store %"compiler/mir:Place" %t104, ptr %l54
  br label %bb23
bb23:
  store { i64, [4 x i64] } zeroinitializer, ptr %t105
  %t106 = getelementptr { i64, [4 x i64] }, ptr %t105, i32 0, i32 0
  store i64 1, ptr %t106
  %t107 = load %"compiler/mir:Place", ptr %l54
  %t108 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t107, 0
  %t109 = getelementptr { i64, [4 x i64] }, ptr %t105, i32 0, i32 1
  store { %"compiler/mir:Place" } %t108, ptr %t109
  %t110 = load { i64, [4 x i64] }, ptr %t105
  store { i64, [8 x i64] } zeroinitializer, ptr %t111
  %t112 = getelementptr { i64, [8 x i64] }, ptr %t111, i32 0, i32 0
  store i64 5, ptr %t112
  %t113 = load %"compiler/source:Span", ptr %l52
  %t114 = insertvalue { %"compiler/source:Span", { i64, [4 x i64] } } undef, %"compiler/source:Span" %t113, 0
  %t116 = insertvalue { %"compiler/source:Span", { i64, [4 x i64] } } %t114, { i64, [4 x i64] } %t110, 1
  %t117 = getelementptr { i64, [8 x i64] }, ptr %t111, i32 0, i32 1
  store { %"compiler/source:Span", { i64, [4 x i64] } } %t116, ptr %t117
  %t118 = load { i64, [8 x i64] }, ptr %t111
  %t119 = load ptr, ptr %l51, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t119, { i64, [8 x i64] } %t118)
  br label %bb24
bb24:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2eretArrays(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2, ptr %a3, %"compiler/source:Span" %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca ptr
  %l6 = alloca { i64, [4 x i64] }
  %l7 = alloca i32
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca %"compiler/mir:Place"
  %l22 = alloca i1
  %l27 = alloca i1
  %l28 = alloca ptr
  %l30 = alloca %"compiler/mir:Place"
  %l31 = alloca { i64, [4 x i64] }
  %l32 = alloca i32
  %l33 = alloca %"compiler/source:Span"
  %l35 = alloca { i64, [1 x i64] }
  %l36 = alloca { i64, [4 x i64] }
  %l37 = alloca ptr
  %l38 = alloca %"compiler/source:Span"
  %l40 = alloca %"compiler/mir:Place"
  %l47 = alloca i32
  %l50 = alloca i32
  %l54 = alloca ptr
  %l57 = alloca i32
  %l58 = alloca { i64, ptr }
  %l60 = alloca { i64, ptr }
  %l66 = alloca i64
  %l69 = alloca i64
  %l88 = alloca { i64, ptr }
  %l91 = alloca i1
  %l96 = alloca i1
  %l101 = alloca i1
  %l103 = alloca { i64, ptr }
  %l107 = alloca { i64, ptr }
  %l110 = alloca i1
  %l112 = alloca ptr
  %l113 = alloca ptr
  %l116 = alloca %"compiler/lower:pl"
  %l119 = alloca %"compiler/lower:pl"
  %l120 = alloca %"compiler/mir:Place"
  %l121 = alloca ptr
  %l123 = alloca { i64, [4 x i64] }
  %l124 = alloca { i64, ptr }
  %l126 = alloca i32
  %l127 = alloca %"compiler/source:Span"
  %l129 = alloca { i64, [1 x i64] }
  %l130 = alloca { i64, [4 x i64] }
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %t25 = alloca { i64, [4 x i64] }, align 8
  %t49 = alloca { i64, [15 x i64] }, align 8
  %t55 = alloca { i64, [21 x i64] }, align 8
  %t207 = alloca { i64, [2 x i64] }, align 8
  %t216 = alloca { i64, [1 x i64] }, align 8
  %t232 = alloca { i64, [4 x i64] }, align 8
  %t260 = alloca { i64, [15 x i64] }, align 8
  %t266 = alloca { i64, [21 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  store ptr %a3, ptr %l3
  store %"compiler/source:Span" %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l5, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t7 = load i32, ptr %l2, !tbaa !23
  %t10 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2evalueArray(ptr %v0, ptr %t6, i32 %t7)
  store i1 %t10, ptr %l22
  br label %bb1
bb1:
  %t11 = load i1, ptr %l22, !tbaa !21
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load ptr, ptr %l3, !tbaa !29
  %t15 = load i32, ptr %l2, !tbaa !23
  %t19 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eretCopies(ptr %v0, ptr %v1, ptr %t12, ptr %t13, i32 %t15)
  store i1 %t19, ptr %l27
  br label %bb4
bb3:
  br label %bb13
bb4:
  %t20 = load i1, ptr %l27, !tbaa !21
  br i1 %t20, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s2
  %t21 = load ptr, ptr %l0, !tbaa !29
  store ptr %t21, ptr %l28, !tbaa !29
  %t22 = load i32, ptr %l1, !tbaa !23
  %t24 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t22)
  store %"compiler/mir:Place" %t24, ptr %l30
  br label %bb7
bb6:
  br label %bb12
bb7:
  store { i64, [4 x i64] } zeroinitializer, ptr %t25
  %t26 = getelementptr { i64, [4 x i64] }, ptr %t25, i32 0, i32 0
  store i64 1, ptr %t26
  %t27 = load %"compiler/mir:Place", ptr %l30
  %t28 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t27, 0
  %t29 = getelementptr { i64, [4 x i64] }, ptr %t25, i32 0, i32 1
  store { %"compiler/mir:Place" } %t28, ptr %t29
  %t30 = load { i64, [4 x i64] }, ptr %t25
  store { i64, [4 x i64] } %t30, ptr %l31
  %t31 = load i32, ptr %l2, !tbaa !23
  store i32 %t31, ptr %l32, !tbaa !23
  %t32 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t32, ptr %l33
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = call { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eresultScope(ptr %v0, ptr %t33)
  store { i64, [1 x i64] } %t35, ptr %l35
  br label %bb8
bb8:
  %t36 = load ptr, ptr %l28, !tbaa !29
  %t37 = load { i64, [4 x i64] }, ptr %l31
  %t38 = load i32, ptr %l32, !tbaa !23
  %t39 = load %"compiler/source:Span", ptr %l33
  %t40 = load { i64, [1 x i64] }, ptr %l35
  %t41 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2earrayCopy(ptr %v0, ptr %t36, { i64, [4 x i64] } %t37, i32 %t38, %"compiler/source:Span" %t39, { i64, [1 x i64] } %t40)
  store { i64, [4 x i64] } %t41, ptr %l36
  br label %bb9
bb9:
  %t42 = load { i64, [4 x i64] }, ptr %l36
  store { i64, [4 x i64] } %t42, ptr %l6
  %t43 = load ptr, ptr %l0, !tbaa !29
  store ptr %t43, ptr %l37, !tbaa !29
  %t44 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t44, ptr %l38
  %t45 = load i32, ptr %l1, !tbaa !23
  %t47 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t45)
  store %"compiler/mir:Place" %t47, ptr %l40
  br label %bb10
bb10:
  %t48 = load { i64, [4 x i64] }, ptr %l6
  store { i64, [15 x i64] } zeroinitializer, ptr %t49
  %t50 = getelementptr { i64, [15 x i64] }, ptr %t49, i32 0, i32 0
  store i64 0, ptr %t50
  %t52 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t48, 0
  %t53 = getelementptr { i64, [15 x i64] }, ptr %t49, i32 0, i32 1
  store { { i64, [4 x i64] } } %t52, ptr %t53
  %t54 = load { i64, [15 x i64] }, ptr %t49
  store { i64, [21 x i64] } zeroinitializer, ptr %t55
  %t56 = getelementptr { i64, [21 x i64] }, ptr %t55, i32 0, i32 0
  store i64 0, ptr %t56
  %t57 = load %"compiler/source:Span", ptr %l38
  %t58 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t57, 0
  %t59 = load %"compiler/mir:Place", ptr %l40
  %t60 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t58, %"compiler/mir:Place" %t59, 1
  %t62 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t60, { i64, [15 x i64] } %t54, 2
  %t63 = getelementptr { i64, [21 x i64] }, ptr %t55, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t62, ptr %t63
  %t64 = load { i64, [21 x i64] }, ptr %t55
  %t66 = call ptr @__olang_scope_alloc_a(ptr %s2, i64 176, i64 8)
  store { i64, [21 x i64] } %t64, ptr %t66
  %t67 = load ptr, ptr %l37, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s2, ptr %t67, ptr %t66)
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s2)
  br label %bb12
bb12:
  br label %ret
bb13:
  %t69 = load ptr, ptr %l5, !tbaa !29
  %t70 = load i32, ptr %l2, !tbaa !23
  %t73 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t69, i32 %t70)
  store i32 %t73, ptr %l47
  br label %bb14
bb14:
  %t74 = load i32, ptr %l47, !tbaa !23
  store i32 %t74, ptr %l7, !tbaa !23
  %t75 = load ptr, ptr %l5, !tbaa !29
  %t76 = load i32, ptr %l7, !tbaa !23
  %t79 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t75, i32 %t76)
  store i32 %t79, ptr %l50
  br label %bb15
bb15:
  %t80 = load i32, ptr %l50
  %t82 = trunc i64 22 to i32
  %t83 = icmp eq i32 %t80, %t82
  %t85 = xor i1 %t83, true
  br i1 %t85, label %bb16, label %bb17
bb16:
  br label %ret
bb17:
  br label %bb18
bb18:
  %t87 = load ptr, ptr %l5, !tbaa !29
  store ptr %t87, ptr %l54, !tbaa !29
  %t88 = load ptr, ptr %l5, !tbaa !29
  %t89 = load i32, ptr %l7, !tbaa !23
  %t92 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t88, i32 %t89)
  store i32 %t92, ptr %l57
  br label %bb19
bb19:
  %t93 = load ptr, ptr %l54, !tbaa !29
  %t94 = load i32, ptr %l57, !tbaa !23
  %t95 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t93, i32 %t94)
  store { i64, ptr } %t95, ptr %l58
  br label %bb20
bb20:
  %t96 = load { i64, ptr }, ptr %l58, !tbaa !27
  store { i64, ptr } %t96, ptr %l8, !tbaa !27
  %t97 = load ptr, ptr %l3, !tbaa !29
  %t99 = call { i64, ptr } @compiler_2flower_2etupleItems(ptr %v1, ptr %t97)
  store { i64, ptr } %t99, ptr %l60
  br label %bb21
bb21:
  %t100 = load { i64, ptr }, ptr %l60, !tbaa !27
  store { i64, ptr } %t100, ptr %l9, !tbaa !27
  store i64 0, ptr %l10, !tbaa !24
  %t101 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t103 = extractvalue { i64, ptr } %t101, 0
  store i64 %t103, ptr %l11, !tbaa !24
  store i64 1, ptr %l12, !tbaa !24
  %t105 = load i64, ptr %l11, !tbaa !24
  %t106 = load i64, ptr %l10, !tbaa !24
  %t109 = icmp sgt i64 %t105, %t106
  br i1 %t109, label %bb22, label %bb23
bb22:
  %t111 = load i64, ptr %l12, !tbaa !24
  %t113 = icmp sgt i64 %t111, 0
  br i1 %t113, label %bb24, label %bb25
bb23:
  store i64 0, ptr %l66, !tbaa !24
  br label %bb27
bb24:
  %t115 = load i64, ptr %l11, !tbaa !24
  %t116 = load i64, ptr %l10, !tbaa !24
  %t119 = sub i64 %t115, %t116
  %t120 = load i64, ptr %l12, !tbaa !24
  %t123 = add i64 %t119, %t120
  %t125 = sub i64 %t123, 1
  %t126 = load i64, ptr %l12, !tbaa !24
  %t129 = sdiv i64 %t125, %t126
  store i64 %t129, ptr %l69, !tbaa !24
  br label %bb26
bb25:
  store i64 0, ptr %l69, !tbaa !24
  br label %bb26
bb26:
  %t131 = load i64, ptr %l69, !tbaa !24
  store i64 %t131, ptr %l66, !tbaa !24
  br label %bb27
bb27:
  %t132 = load i64, ptr %l66, !tbaa !24
  store i64 %t132, ptr %l13, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  br label %bb28
bb28:
  store %olang.scope zeroinitializer, ptr %s5
  %t133 = load i64, ptr %l14, !tbaa !24
  %t134 = load i64, ptr %l13, !tbaa !24
  %t137 = icmp slt i64 %t133, %t134
  %t139 = xor i1 %t137, true
  br i1 %t139, label %bb29, label %bb30
bb29:
  call void @__olang_scope_close(ptr %s5)
  br label %bb53
bb30:
  br label %bb31
bb31:
  %t141 = load i64, ptr %l10, !tbaa !24
  %t142 = load i64, ptr %l14, !tbaa !24
  %t143 = load i64, ptr %l12, !tbaa !24
  %t146 = mul i64 %t142, %t143
  %t149 = add i64 %t141, %t146
  store i64 %t149, ptr %l15, !tbaa !24
  %t151 = load ptr, ptr %l0, !tbaa !29
  %t152 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t152, ptr %l88, !tbaa !27
  %t153 = load i64, ptr %l15, !tbaa !24
  %t155 = getelementptr { i64, ptr }, ptr %l88, i32 0, i32 1
  %t156 = load ptr, ptr %t155, !tbaa !27
  %t157 = getelementptr i32, ptr %t156, i64 %t153
  %t158 = load i32, ptr %t157, !tbaa !33
  %t161 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2evalueArray(ptr %v0, ptr %t151, i32 %t158)
  store i1 %t161, ptr %l91
  br label %bb32
bb32:
  %t162 = load i1, ptr %l91, !tbaa !21
  %t163 = xor i1 %t162, true
  br i1 %t163, label %bb33, label %bb34
bb33:
  call void @__olang_scope_close(ptr %s5)
  br label %bb52
bb34:
  br label %bb35
bb35:
  %t165 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t167 = extractvalue { i64, ptr } %t165, 0
  %t169 = icmp sgt i64 %t167, 0
  br i1 %t169, label %bb36, label %bb37
bb36:
  %t171 = load i64, ptr %l15, !tbaa !24
  %t172 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t174 = extractvalue { i64, ptr } %t172, 0
  %t177 = icmp slt i64 %t171, %t174
  store i1 %t177, ptr %l96, !tbaa !21
  br label %bb38
bb37:
  store i1 false, ptr %l96, !tbaa !21
  br label %bb38
bb38:
  %t179 = load i1, ptr %l96, !tbaa !21
  br i1 %t179, label %bb39, label %bb40
bb39:
  %t180 = load ptr, ptr %l0, !tbaa !29
  %t181 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t181, ptr %l103, !tbaa !27
  %t182 = load i64, ptr %l15, !tbaa !24
  %t184 = getelementptr { i64, ptr }, ptr %l103, i32 0, i32 1
  %t185 = load ptr, ptr %t184, !tbaa !27
  %t186 = getelementptr ptr, ptr %t185, i64 %t182
  %t187 = load ptr, ptr %t186, !tbaa !39
  %t189 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t189, ptr %l107, !tbaa !27
  %t190 = load i64, ptr %l15, !tbaa !24
  %t192 = getelementptr { i64, ptr }, ptr %l107, i32 0, i32 1
  %t193 = load ptr, ptr %t192, !tbaa !27
  %t194 = getelementptr i32, ptr %t193, i64 %t190
  %t195 = load i32, ptr %t194, !tbaa !33
  %t199 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eretCopies(ptr %v0, ptr %v1, ptr %t180, ptr %t187, i32 %t195)
  store i1 %t199, ptr %l110
  br label %bb41
bb40:
  store i1 false, ptr %l101, !tbaa !21
  br label %bb42
bb41:
  %t200 = load i1, ptr %l110, !tbaa !21
  %t201 = xor i1 %t200, true
  store i1 %t201, ptr %l101, !tbaa !21
  br label %bb42
bb42:
  %t203 = load i1, ptr %l101, !tbaa !21
  br i1 %t203, label %bb43, label %bb44
bb43:
  call void @__olang_scope_close(ptr %s5)
  br label %bb52
bb44:
  br label %bb45
bb45:
  %t204 = load ptr, ptr %l0, !tbaa !29
  store ptr %t204, ptr %l112, !tbaa !29
  %t205 = load ptr, ptr %l0, !tbaa !29
  store ptr %t205, ptr %l113, !tbaa !29
  %t206 = load i32, ptr %l1, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t207
  %t208 = getelementptr { i64, [2 x i64] }, ptr %t207, i32 0, i32 0
  store i64 1, ptr %t208
  %t210 = insertvalue { i32 } undef, i32 %t206, 0
  %t211 = getelementptr { i64, [2 x i64] }, ptr %t207, i32 0, i32 1
  store { i32 } %t210, ptr %t211
  %t212 = load { i64, [2 x i64] }, ptr %t207
  %t214 = call %"compiler/lower:pl" @compiler_2flower_3apl_2ector(ptr %s5, { i64, [2 x i64] } %t212)
  store %"compiler/lower:pl" %t214, ptr %l116
  br label %bb46
bb46:
  %t215 = load i64, ptr %l15, !tbaa !24
  store { i64, [1 x i64] } zeroinitializer, ptr %t216
  %t217 = getelementptr { i64, [1 x i64] }, ptr %t216, i32 0, i32 0
  store i64 0, ptr %t217
  %t219 = insertvalue { i64 } undef, i64 %t215, 0
  %t220 = getelementptr { i64, [1 x i64] }, ptr %t216, i32 0, i32 1
  store { i64 } %t219, ptr %t220
  %t221 = load { i64, [1 x i64] }, ptr %t216
  %t222 = load ptr, ptr %l113, !tbaa !29
  %t223 = load %"compiler/lower:pl", ptr %l116
  %t225 = call %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2ewith(ptr %v0, ptr %s5, ptr %s5, ptr %t222, %"compiler/lower:pl" %t223, { i64, [1 x i64] } %t221)
  store %"compiler/lower:pl" %t225, ptr %l119
  br label %bb47
bb47:
  %t226 = load ptr, ptr %l112, !tbaa !29
  %t227 = load %"compiler/lower:pl", ptr %l119
  %t228 = call %"compiler/mir:Place" @compiler_2flower_2ecompiler_2flower_3alowering_2emk(ptr %v0, ptr %s5, ptr %t226, %"compiler/lower:pl" %t227)
  store %"compiler/mir:Place" %t228, ptr %l120
  br label %bb48
bb48:
  %t229 = load %"compiler/mir:Place", ptr %l120
  store %"compiler/mir:Place" %t229, ptr %l16
  %t230 = load ptr, ptr %l0, !tbaa !29
  store ptr %t230, ptr %l121, !tbaa !29
  %t231 = load %"compiler/mir:Place", ptr %l16
  store { i64, [4 x i64] } zeroinitializer, ptr %t232
  %t233 = getelementptr { i64, [4 x i64] }, ptr %t232, i32 0, i32 0
  store i64 1, ptr %t233
  %t235 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t231, 0
  %t236 = getelementptr { i64, [4 x i64] }, ptr %t232, i32 0, i32 1
  store { %"compiler/mir:Place" } %t235, ptr %t236
  %t237 = load { i64, [4 x i64] }, ptr %t232
  store { i64, [4 x i64] } %t237, ptr %l123
  %t238 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t238, ptr %l124, !tbaa !27
  %t239 = load i64, ptr %l15, !tbaa !24
  %t241 = getelementptr { i64, ptr }, ptr %l124, i32 0, i32 1
  %t242 = load ptr, ptr %t241, !tbaa !27
  %t243 = getelementptr i32, ptr %t242, i64 %t239
  %t244 = load i32, ptr %t243, !tbaa !33
  store i32 %t244, ptr %l126, !tbaa !23
  %t245 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t245, ptr %l127
  %t246 = load ptr, ptr %l0, !tbaa !29
  %t248 = call { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eresultScope(ptr %v0, ptr %t246)
  store { i64, [1 x i64] } %t248, ptr %l129
  br label %bb49
bb49:
  %t249 = load ptr, ptr %l121, !tbaa !29
  %t250 = load { i64, [4 x i64] }, ptr %l123
  %t251 = load i32, ptr %l126, !tbaa !23
  %t252 = load %"compiler/source:Span", ptr %l127
  %t253 = load { i64, [1 x i64] }, ptr %l129
  %t254 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2earrayCopy(ptr %v0, ptr %t249, { i64, [4 x i64] } %t250, i32 %t251, %"compiler/source:Span" %t252, { i64, [1 x i64] } %t253)
  store { i64, [4 x i64] } %t254, ptr %l130
  br label %bb50
bb50:
  %t255 = load { i64, [4 x i64] }, ptr %l130
  %t256 = load ptr, ptr %l0, !tbaa !29
  %t257 = load %"compiler/source:Span", ptr %l4
  %t258 = load %"compiler/mir:Place", ptr %l16
  store { i64, [15 x i64] } zeroinitializer, ptr %t260
  %t261 = getelementptr { i64, [15 x i64] }, ptr %t260, i32 0, i32 0
  store i64 0, ptr %t261
  %t263 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t255, 0
  %t264 = getelementptr { i64, [15 x i64] }, ptr %t260, i32 0, i32 1
  store { { i64, [4 x i64] } } %t263, ptr %t264
  %t265 = load { i64, [15 x i64] }, ptr %t260
  store { i64, [21 x i64] } zeroinitializer, ptr %t266
  %t267 = getelementptr { i64, [21 x i64] }, ptr %t266, i32 0, i32 0
  store i64 0, ptr %t267
  %t269 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t257, 0
  %t271 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t269, %"compiler/mir:Place" %t258, 1
  %t273 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t271, { i64, [15 x i64] } %t265, 2
  %t274 = getelementptr { i64, [21 x i64] }, ptr %t266, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t273, ptr %t274
  %t275 = load { i64, [21 x i64] }, ptr %t266
  %t277 = call ptr @__olang_scope_alloc_a(ptr %s5, i64 176, i64 8)
  store { i64, [21 x i64] } %t275, ptr %t277
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s5, ptr %t256, ptr %t277)
  br label %bb51
bb51:
  call void @__olang_scope_close(ptr %s5)
  br label %bb52
bb52:
  %t280 = load i64, ptr %l14, !tbaa !24
  %t282 = add i64 %t280, 1
  store i64 %t282, ptr %l14, !tbaa !24
  br label %bb28
bb53:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eretCopies(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca i64
  %l18 = alloca ptr
  %l19 = alloca ptr
  %l20 = alloca i64
  %l21 = alloca { i64, ptr }
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca %"compiler/lower:level"
  %l25 = alloca ptr
  %l26 = alloca ptr
  %l27 = alloca i32
  %l33 = alloca i1
  %l34 = alloca ptr
  %l35 = alloca i1
  %l44 = alloca i1
  %l45 = alloca i1
  %l51 = alloca i1
  %l52 = alloca ptr
  %l53 = alloca i1
  %l66 = alloca { i64, ptr }
  %l73 = alloca i1
  %l81 = alloca i1
  %l82 = alloca ptr
  %l91 = alloca i1
  %l92 = alloca ptr
  %l93 = alloca i1
  %l102 = alloca i1
  %l112 = alloca { i64, ptr }
  %l123 = alloca { i64, ptr }
  %l130 = alloca i1
  %l137 = alloca ptr
  %l138 = alloca i1
  %l147 = alloca i1
  %l151 = alloca i1
  %l160 = alloca i64
  %l165 = alloca { i64, ptr }
  %l168 = alloca { i64, ptr }
  %l169 = alloca i32
  %l178 = alloca { i64, ptr }
  %l191 = alloca ptr
  %l192 = alloca ptr
  %l193 = alloca i1
  %l198 = alloca ptr
  %l199 = alloca i1
  %l208 = alloca %"compiler/mir:Local"
  %l209 = alloca { i64, [1 x i64] }
  %l210 = alloca ptr
  %l212 = alloca { i64, [1 x i64] }
  %l214 = alloca i1
  %l216 = alloca i1
  %l218 = alloca { i64, ptr }
  %s6 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s24 = alloca %olang.scope
  %s25 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t7 = load i32, ptr %l2, !tbaa !23
  %t10 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2evalueArray(ptr %v0, ptr %t6, i32 %t7)
  store i1 %t10, ptr %l33
  br label %bb4
bb4:
  %t11 = load i1, ptr %l33, !tbaa !21
  br i1 %t11, label %bb5, label %bb6
bb5:
  %t12 = load ptr, ptr %l1, !tbaa !29
  store ptr %t12, ptr %l34, !tbaa !29
  store i1 false, ptr %l35, !tbaa !21
  %t13 = load ptr, ptr %l34, !tbaa !29
  %t14 = icmp ne ptr %t13, null
  br i1 %t14, label %bb7, label %bb8
bb6:
  br label %bb79
bb7:
  %t16 = load ptr, ptr %l34, !tbaa !29
  %t17 = load i64, ptr %t16
  %t19 = icmp eq i64 %t17, 11
  store i1 %t19, ptr %l35, !tbaa !21
  br label %bb8
bb8:
  %t20 = load i1, ptr %l35, !tbaa !21
  br i1 %t20, label %bb9, label %bb10
bb9:
  %t21 = load ptr, ptr %l1, !tbaa !29
  %t23 = getelementptr { i64, [5 x i64] }, ptr %t21, i32 0, i32 1
  %t24 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t23, i32 0, i32 2
  %t25 = load ptr, ptr %t24
  store ptr %t25, ptr %l3, !tbaa !29
  br label %bb11
bb10:
  br label %bb17
bb11:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load ptr, ptr %l3, !tbaa !29
  %t30 = getelementptr %"compiler/typed:Cond", ptr %t28, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !29
  %t32 = load i32, ptr %l2, !tbaa !23
  %t36 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eretCopies(ptr %v0, ptr %v1, ptr %t27, ptr %t31, i32 %t32)
  store i1 %t36, ptr %l44
  br label %bb12
bb12:
  %t37 = load i1, ptr %l44, !tbaa !21
  br i1 %t37, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l45, !tbaa !21
  br label %bb16
bb14:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t39 = load ptr, ptr %l3, !tbaa !29
  %t41 = getelementptr %"compiler/typed:Cond", ptr %t39, i32 0, i32 2
  %t42 = load ptr, ptr %t41, !tbaa !29
  %t44 = load i32, ptr %l2, !tbaa !23
  %t48 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eretCopies(ptr %v0, ptr %v1, ptr %t38, ptr %t42, i32 %t44)
  store i1 %t48, ptr %l51
  br label %bb15
bb15:
  %t49 = load i1, ptr %l51, !tbaa !21
  store i1 %t49, ptr %l45, !tbaa !21
  br label %bb16
bb16:
  %t50 = load i1, ptr %l45, !tbaa !21
  store i1 %t50, ptr %rv
  br label %ret
bb17:
  %t51 = load ptr, ptr %l1, !tbaa !29
  store ptr %t51, ptr %l52, !tbaa !29
  store i1 false, ptr %l53, !tbaa !21
  %t52 = load ptr, ptr %l52, !tbaa !29
  %t53 = icmp ne ptr %t52, null
  br i1 %t53, label %bb18, label %bb19
bb18:
  %t55 = load ptr, ptr %l52, !tbaa !29
  %t56 = load i64, ptr %t55
  %t58 = icmp eq i64 %t56, 13
  store i1 %t58, ptr %l53, !tbaa !21
  br label %bb19
bb19:
  %t59 = load i1, ptr %l53, !tbaa !21
  br i1 %t59, label %bb20, label %bb21
bb20:
  %t60 = load ptr, ptr %l1, !tbaa !29
  %t62 = getelementptr { i64, [5 x i64] }, ptr %t60, i32 0, i32 1
  %t63 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t62, i32 0, i32 2
  %t64 = load ptr, ptr %t63
  store ptr %t64, ptr %l4, !tbaa !29
  br label %bb22
bb21:
  br label %bb40
bb22:
  %t66 = load ptr, ptr %l4, !tbaa !29
  %t68 = getelementptr %"compiler/typed:Match", ptr %t66, i32 0, i32 1
  %t69 = load { i64, ptr }, ptr %t68, !tbaa !27
  store { i64, ptr } %t69, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t71 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t73 = extractvalue { i64, ptr } %t71, 0
  store i64 %t73, ptr %l7, !tbaa !24
  br label %bb23
bb23:
  store %olang.scope zeroinitializer, ptr %s6
  %t75 = load i64, ptr %l6, !tbaa !24
  %t76 = load i64, ptr %l7, !tbaa !24
  %t79 = icmp slt i64 %t75, %t76
  %t81 = xor i1 %t79, true
  br i1 %t81, label %bb24, label %bb25
bb24:
  call void @__olang_scope_close(ptr %s6)
  br label %bb32
bb25:
  br label %bb26
bb26:
  %t83 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t83, ptr %l66, !tbaa !27
  %t84 = load i64, ptr %l6, !tbaa !24
  %t86 = getelementptr { i64, ptr }, ptr %l66, i32 0, i32 1
  %t87 = load ptr, ptr %t86, !tbaa !27
  %t88 = getelementptr ptr, ptr %t87, i64 %t84
  %t89 = load ptr, ptr %t88, !tbaa !39
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"compiler/typed:Arm", ptr %t89, i32 0, i32 4
  %t95 = load ptr, ptr %t94, !tbaa !29
  %t96 = load i32, ptr %l2, !tbaa !23
  %t100 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eretCopies(ptr %v0, ptr %v1, ptr %t91, ptr %t95, i32 %t96)
  store i1 %t100, ptr %l73
  br label %bb27
bb27:
  %t101 = load i1, ptr %l73, !tbaa !21
  br i1 %t101, label %bb28, label %bb29
bb28:
  call void @__olang_scope_close(ptr %s6)
  store i1 true, ptr %rv
  br label %ret
bb29:
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s6)
  br label %bb31
bb31:
  %t103 = load i64, ptr %l6, !tbaa !24
  %t105 = add i64 %t103, 1
  store i64 %t105, ptr %l6, !tbaa !24
  br label %bb23
bb32:
  %t107 = load ptr, ptr %l4, !tbaa !29
  %t109 = getelementptr %"compiler/typed:Match", ptr %t107, i32 0, i32 2
  %t110 = load ptr, ptr %t109, !tbaa !29
  %t112 = icmp eq ptr %t110, null
  %t114 = xor i1 %t112, true
  br i1 %t114, label %bb33, label %bb34
bb33:
  %t116 = load ptr, ptr %l0, !tbaa !29
  store ptr %t116, ptr %l82, !tbaa !29
  %t117 = load ptr, ptr %l4, !tbaa !29
  %t119 = getelementptr %"compiler/typed:Match", ptr %t117, i32 0, i32 2
  %t120 = load ptr, ptr %t119, !tbaa !29
  %t122 = icmp eq ptr %t120, null
  br i1 %t122, label %bb35, label %bb36
bb34:
  store i1 false, ptr %l81, !tbaa !21
  br label %bb39
bb35:
  call void @__olang_check_failed(ptr @olang_loc_ddcb411f232bf43e_ce3417657830a5fa)
  unreachable
bb36:
  br label %bb37
bb37:
  %t124 = load ptr, ptr %l4, !tbaa !29
  %t126 = getelementptr %"compiler/typed:Match", ptr %t124, i32 0, i32 2
  %t127 = load ptr, ptr %t126, !tbaa !29
  %t130 = getelementptr %"compiler/typed:Arm", ptr %t127, i32 0, i32 4
  %t131 = load ptr, ptr %t130, !tbaa !29
  %t132 = load i32, ptr %l2, !tbaa !23
  %t133 = load ptr, ptr %l82, !tbaa !29
  %t136 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eretCopies(ptr %v0, ptr %v1, ptr %t133, ptr %t131, i32 %t132)
  store i1 %t136, ptr %l91
  br label %bb38
bb38:
  %t137 = load i1, ptr %l91, !tbaa !21
  store i1 %t137, ptr %l81, !tbaa !21
  br label %bb39
bb39:
  %t138 = load i1, ptr %l81, !tbaa !21
  store i1 %t138, ptr %rv
  br label %ret
bb40:
  %t139 = load ptr, ptr %l1, !tbaa !29
  store ptr %t139, ptr %l92, !tbaa !29
  store i1 false, ptr %l93, !tbaa !21
  %t140 = load ptr, ptr %l92, !tbaa !29
  %t141 = icmp ne ptr %t140, null
  br i1 %t141, label %bb41, label %bb42
bb41:
  %t143 = load ptr, ptr %l92, !tbaa !29
  %t144 = load i64, ptr %t143
  %t146 = icmp eq i64 %t144, 14
  store i1 %t146, ptr %l93, !tbaa !21
  br label %bb42
bb42:
  %t147 = load i1, ptr %l93, !tbaa !21
  br i1 %t147, label %bb43, label %bb44
bb43:
  %t148 = load ptr, ptr %l1, !tbaa !29
  %t150 = getelementptr { i64, [5 x i64] }, ptr %t148, i32 0, i32 1
  %t151 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t150, i32 0, i32 2
  %t152 = load ptr, ptr %t151
  store ptr %t152, ptr %l9, !tbaa !29
  br label %bb45
bb44:
  br label %bb66
bb45:
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t155 = load ptr, ptr %l9, !tbaa !29
  %t157 = getelementptr %"compiler/typed:Try", ptr %t155, i32 0, i32 0
  %t158 = load ptr, ptr %t157, !tbaa !29
  %t159 = load i32, ptr %l2, !tbaa !23
  %t163 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eretCopies(ptr %v0, ptr %v1, ptr %t154, ptr %t158, i32 %t159)
  store i1 %t163, ptr %l102
  br label %bb46
bb46:
  %t164 = load i1, ptr %l102, !tbaa !21
  br i1 %t164, label %bb47, label %bb48
bb47:
  store i1 true, ptr %rv
  br label %ret
bb48:
  br label %bb49
bb49:
  %t166 = load ptr, ptr %l9, !tbaa !29
  %t168 = getelementptr %"compiler/typed:Try", ptr %t166, i32 0, i32 1
  %t169 = load { i64, ptr }, ptr %t168, !tbaa !27
  store { i64, ptr } %t169, ptr %l10, !tbaa !27
  store i64 0, ptr %l11, !tbaa !24
  %t171 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t173 = extractvalue { i64, ptr } %t171, 0
  store i64 %t173, ptr %l12, !tbaa !24
  br label %bb50
bb50:
  store %olang.scope zeroinitializer, ptr %s12
  %t175 = load i64, ptr %l11, !tbaa !24
  %t176 = load i64, ptr %l12, !tbaa !24
  %t179 = icmp slt i64 %t175, %t176
  %t181 = xor i1 %t179, true
  br i1 %t181, label %bb51, label %bb52
bb51:
  call void @__olang_scope_close(ptr %s12)
  br label %bb65
bb52:
  br label %bb53
bb53:
  %t183 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t183, ptr %l112, !tbaa !27
  %t184 = load i64, ptr %l11, !tbaa !24
  %t186 = getelementptr { i64, ptr }, ptr %l112, i32 0, i32 1
  %t187 = load ptr, ptr %t186, !tbaa !27
  %t188 = getelementptr ptr, ptr %t187, i64 %t184
  %t189 = load ptr, ptr %t188, !tbaa !39
  %t193 = getelementptr %"compiler/typed:Clause", ptr %t189, i32 0, i32 4
  %t194 = load { i64, ptr }, ptr %t193, !tbaa !27
  store { i64, ptr } %t194, ptr %l14, !tbaa !27
  store i64 0, ptr %l15, !tbaa !24
  %t196 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t198 = extractvalue { i64, ptr } %t196, 0
  store i64 %t198, ptr %l16, !tbaa !24
  br label %bb54
bb54:
  store %olang.scope zeroinitializer, ptr %s14
  %t200 = load i64, ptr %l15, !tbaa !24
  %t201 = load i64, ptr %l16, !tbaa !24
  %t204 = icmp slt i64 %t200, %t201
  %t206 = xor i1 %t204, true
  br i1 %t206, label %bb55, label %bb56
bb55:
  call void @__olang_scope_close(ptr %s14)
  br label %bb63
bb56:
  br label %bb57
bb57:
  %t208 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t208, ptr %l123, !tbaa !27
  %t209 = load i64, ptr %l15, !tbaa !24
  %t211 = getelementptr { i64, ptr }, ptr %l123, i32 0, i32 1
  %t212 = load ptr, ptr %t211, !tbaa !27
  %t213 = getelementptr ptr, ptr %t212, i64 %t209
  %t214 = load ptr, ptr %t213, !tbaa !39
  %t216 = load ptr, ptr %l0, !tbaa !29
  %t219 = load i32, ptr %l2, !tbaa !23
  %t223 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eretCopies(ptr %v0, ptr %v1, ptr %t216, ptr %t214, i32 %t219)
  store i1 %t223, ptr %l130
  br label %bb58
bb58:
  %t224 = load i1, ptr %l130, !tbaa !21
  br i1 %t224, label %bb59, label %bb60
bb59:
  call void @__olang_scope_close(ptr %s14)
  call void @__olang_scope_close(ptr %s12)
  store i1 true, ptr %rv
  br label %ret
bb60:
  br label %bb61
bb61:
  call void @__olang_scope_close(ptr %s14)
  br label %bb62
bb62:
  %t226 = load i64, ptr %l15, !tbaa !24
  %t228 = add i64 %t226, 1
  store i64 %t228, ptr %l15, !tbaa !24
  br label %bb54
bb63:
  call void @__olang_scope_close(ptr %s12)
  br label %bb64
bb64:
  %t230 = load i64, ptr %l11, !tbaa !24
  %t232 = add i64 %t230, 1
  store i64 %t232, ptr %l11, !tbaa !24
  br label %bb50
bb65:
  store i1 false, ptr %rv
  br label %ret
bb66:
  %t235 = load ptr, ptr %l1, !tbaa !29
  store ptr %t235, ptr %l137, !tbaa !29
  store i1 false, ptr %l138, !tbaa !21
  %t236 = load ptr, ptr %l137, !tbaa !29
  %t237 = icmp ne ptr %t236, null
  br i1 %t237, label %bb67, label %bb68
bb67:
  %t239 = load ptr, ptr %l137, !tbaa !29
  %t240 = load i64, ptr %t239
  %t242 = icmp eq i64 %t240, 12
  store i1 %t242, ptr %l138, !tbaa !21
  br label %bb68
bb68:
  %t243 = load i1, ptr %l138, !tbaa !21
  br i1 %t243, label %bb69, label %bb70
bb69:
  %t244 = load ptr, ptr %l1, !tbaa !29
  %t246 = getelementptr { i64, [5 x i64] }, ptr %t244, i32 0, i32 1
  %t247 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t246, i32 0, i32 2
  %t248 = load ptr, ptr %t247
  store ptr %t248, ptr %l18, !tbaa !29
  br label %bb71
bb70:
  br label %bb73
bb71:
  %t250 = load ptr, ptr %l0, !tbaa !29
  %t251 = load ptr, ptr %l18, !tbaa !29
  %t253 = getelementptr %"compiler/typed:Seq", ptr %t251, i32 0, i32 1
  %t254 = load ptr, ptr %t253, !tbaa !29
  %t255 = load i32, ptr %l2, !tbaa !23
  %t259 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eretCopies(ptr %v0, ptr %v1, ptr %t250, ptr %t254, i32 %t255)
  store i1 %t259, ptr %l147
  br label %bb72
bb72:
  %t260 = load i1, ptr %l147, !tbaa !21
  store i1 %t260, ptr %rv
  br label %ret
bb73:
  br i1 true, label %bb74, label %bb75
bb74:
  br label %bb76
bb75:
  br label %bb77
bb76:
  br label %bb78
bb77:
  call void @__olang_check_failed(ptr @olang_loc_ecde87765d07009c_52dfe83edba10a08)
  unreachable
bb78:
  br label %bb79
bb79:
  %t261 = load ptr, ptr %l0, !tbaa !29
  %t262 = load ptr, ptr %l1, !tbaa !29
  %t263 = load i32, ptr %l2, !tbaa !23
  %t267 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2ecopiesArray(ptr %v0, ptr %v1, ptr %t261, ptr %t262, i32 %t263)
  store i1 %t267, ptr %l151
  br label %bb80
bb80:
  %t268 = load i1, ptr %l151, !tbaa !21
  %t269 = xor i1 %t268, true
  br i1 %t269, label %bb81, label %bb82
bb81:
  store i1 false, ptr %rv
  br label %ret
bb82:
  br label %bb83
bb83:
  %t272 = load ptr, ptr %l0, !tbaa !29
  %t274 = getelementptr %"compiler/lower:lowering", ptr %t272, i32 0, i32 19
  %t275 = load i1, ptr %t274, !tbaa !21
  %t277 = xor i1 %t275, true
  br i1 %t277, label %bb84, label %bb85
bb84:
  store i1 true, ptr %rv
  br label %ret
bb85:
  br label %bb86
bb86:
  %t280 = load ptr, ptr %l0, !tbaa !29
  %t282 = getelementptr %"compiler/lower:lowering", ptr %t280, i32 0, i32 10
  %t284 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aBlock_26_3e_2eLe_H8743fc75fe5cead0bda2da42e1adf3f3(ptr %v0, ptr %t282)
  store i64 %t284, ptr %l160
  br label %bb87
bb87:
  %t285 = load i64, ptr %l160, !tbaa !24
  %t286 = icmp sgt i64 %t285, 0
  br i1 %t286, label %bb88, label %bb89
bb88:
  store i1 true, ptr %rv
  br label %ret
bb89:
  br label %bb90
bb90:
  %t289 = load ptr, ptr %l0, !tbaa !29
  %t291 = getelementptr %"compiler/lower:lowering", ptr %t289, i32 0, i32 9
  store ptr %t291, ptr %l19, !tbaa !29
  store i64 0, ptr %l20, !tbaa !24
  br label %bb91
bb91:
  store %olang.scope zeroinitializer, ptr %s24
  %t293 = load ptr, ptr %l19, !tbaa !29
  %t294 = load i64, ptr %l20, !tbaa !24
  %t297 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3alevel_3e_2eRunFrom_3ccompiler_2flower_3alevel_3e(ptr %v0, ptr %t293, i64 %t294)
  %t298 = extractvalue { i32, { i64, ptr } } %t297, 1
  %t299 = extractvalue { i32, { i64, ptr } } %t297, 0
  store i32 %t299, ptr %l169
  %t300 = icmp ne i32 %t299, 0
  br i1 %t300, label %bb93, label %ok.301
ok.301:
  store { i64, ptr } %t298, ptr %l168
  br label %bb92
bb92:
  %t302 = load { i64, ptr }, ptr %l168, !tbaa !27
  store { i64, ptr } %t302, ptr %l165, !tbaa !27
  br label %bb97
bb93:
  %t303 = load i32, ptr %l169, !tbaa !23
  %t304 = ashr i32 %t303, 16
  %t306 = icmp eq i32 %t304, 1
  br i1 %t306, label %bb94, label %bb95
bb94:
  br label %bb96
bb95:
  call void @__olang_check_failed(ptr @olang_loc_2e0d72be7b5575d7_214712821f524de3)
  unreachable
bb96:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s24)
  br label %bb108
bb97:
  %t308 = load { i64, ptr }, ptr %l165, !tbaa !27
  store { i64, ptr } %t308, ptr %l21, !tbaa !27
  %t309 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t311 = extractvalue { i64, ptr } %t309, 0
  store i64 %t311, ptr %l22, !tbaa !24
  store i64 0, ptr %l23, !tbaa !24
  br label %bb98
bb98:
  store %olang.scope zeroinitializer, ptr %s25
  %t313 = load i64, ptr %l23, !tbaa !24
  %t314 = load i64, ptr %l22, !tbaa !24
  %t317 = icmp slt i64 %t313, %t314
  %t319 = xor i1 %t317, true
  br i1 %t319, label %bb99, label %bb100
bb99:
  call void @__olang_scope_close(ptr %s25)
  br label %bb106
bb100:
  br label %bb101
bb101:
  %t321 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t321, ptr %l178, !tbaa !27
  %t322 = load i64, ptr %l23, !tbaa !24
  %t324 = getelementptr { i64, ptr }, ptr %l178, i32 0, i32 1
  %t325 = load ptr, ptr %t324, !tbaa !27
  %t326 = getelementptr %"compiler/lower:level", ptr %t325, i64 %t322
  %t327 = load %"compiler/lower:level", ptr %t326
  store %"compiler/lower:level" %t327, ptr %l24
  %t329 = getelementptr %"compiler/lower:level", ptr %l24, i32 0, i32 2
  %t330 = load i32, ptr %t329
  %t332 = trunc i64 3 to i32
  %t333 = icmp eq i32 %t330, %t332
  br i1 %t333, label %bb102, label %bb103
bb102:
  call void @__olang_scope_close(ptr %s25)
  call void @__olang_scope_close(ptr %s24)
  store i1 true, ptr %rv
  br label %ret
bb103:
  br label %bb104
bb104:
  call void @__olang_scope_close(ptr %s25)
  br label %bb105
bb105:
  %t336 = load i64, ptr %l23, !tbaa !24
  %t338 = add i64 %t336, 1
  store i64 %t338, ptr %l23, !tbaa !24
  br label %bb98
bb106:
  %t340 = load i64, ptr %l20, !tbaa !24
  %t341 = load i64, ptr %l22, !tbaa !24
  %t344 = add i64 %t340, %t341
  store i64 %t344, ptr %l20, !tbaa !24
  call void @__olang_scope_close(ptr %s24)
  br label %bb107
bb107:
  br label %bb91
bb108:
  %t346 = load ptr, ptr %l0, !tbaa !29
  %t347 = load ptr, ptr %l1, !tbaa !29
  %t350 = call ptr @compiler_2flower_2ecompiler_2flower_3alowering_2eunconvert(ptr %v0, ptr %v1, ptr %t346, ptr %t347)
  store ptr %t350, ptr %l191
  br label %bb109
bb109:
  %t351 = load ptr, ptr %l191, !tbaa !29
  store ptr %t351, ptr %l25, !tbaa !29
  %t352 = load ptr, ptr %l25, !tbaa !29
  store ptr %t352, ptr %l192, !tbaa !29
  store i1 false, ptr %l193, !tbaa !21
  %t353 = load ptr, ptr %l192, !tbaa !29
  %t354 = icmp ne ptr %t353, null
  br i1 %t354, label %bb110, label %bb111
bb110:
  %t356 = load ptr, ptr %l192, !tbaa !29
  %t357 = load i64, ptr %t356
  %t359 = icmp eq i64 %t357, 2
  store i1 %t359, ptr %l193, !tbaa !21
  br label %bb111
bb111:
  %t360 = load i1, ptr %l193, !tbaa !21
  br i1 %t360, label %bb112, label %bb113
bb112:
  %t361 = load ptr, ptr %l25, !tbaa !29
  %t363 = getelementptr { i64, [5 x i64] }, ptr %t361, i32 0, i32 1
  %t364 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t363, i32 0, i32 2
  %t365 = load ptr, ptr %t364
  store ptr %t365, ptr %l26, !tbaa !29
  br label %bb114
bb113:
  br label %bb132
bb114:
  %t367 = load ptr, ptr %l26, !tbaa !29
  store ptr %t367, ptr %l198, !tbaa !29
  store i1 false, ptr %l199, !tbaa !21
  %t368 = load ptr, ptr %l198, !tbaa !29
  %t369 = icmp ne ptr %t368, null
  br i1 %t369, label %bb115, label %bb116
bb115:
  %t371 = load ptr, ptr %l198, !tbaa !29
  %t372 = load i64, ptr %t371
  %t374 = icmp eq i64 %t372, 0
  store i1 %t374, ptr %l199, !tbaa !21
  br label %bb116
bb116:
  %t375 = load i1, ptr %l199, !tbaa !21
  br i1 %t375, label %bb117, label %bb118
bb117:
  %t376 = load ptr, ptr %l26, !tbaa !29
  %t378 = getelementptr { i64, [4 x i64] }, ptr %t376, i32 0, i32 1
  %t379 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t378, i32 0, i32 2
  %t380 = load i32, ptr %t379
  store i32 %t380, ptr %l27, !tbaa !23
  br label %bb119
bb118:
  br label %bb126
bb119:
  %t382 = load ptr, ptr %l0, !tbaa !29
  %t384 = getelementptr %"compiler/lower:lowering", ptr %t382, i32 0, i32 3
  %t385 = getelementptr %"compiler/mir:Fn", ptr %t384, i32 0, i32 7
  %t386 = load i32, ptr %l27, !tbaa !23
  %t388 = sext i32 %t386 to i64
  %t391 = call %"compiler/mir:Local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aLocal_3e_2eAt_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %t385, i64 %t388)
  store %"compiler/mir:Local" %t391, ptr %l208
  br label %bb120
bb120:
  %t392 = getelementptr %"compiler/mir:Local", ptr %l208, i32 0, i32 4
  %t393 = load { i64, [1 x i64] }, ptr %t392
  store { i64, [1 x i64] } %t393, ptr %l209
  store ptr %l209, ptr %l210, !tbaa !29
  %t394 = load ptr, ptr %l0, !tbaa !29
  %t396 = call { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eresultScope(ptr %v0, ptr %t394)
  store { i64, [1 x i64] } %t396, ptr %l212
  br label %bb121
bb121:
  %t397 = load ptr, ptr %l210, !tbaa !29
  %t399 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fmir_3aScopeRef(ptr %t397, ptr %l212)
  store i1 %t399, ptr %l214
  br label %bb122
bb122:
  %t400 = load i1, ptr %l214, !tbaa !21
  %t401 = xor i1 %t400, true
  br i1 %t401, label %bb123, label %bb124
bb123:
  store i1 true, ptr %l216, !tbaa !21
  br label %bb125
bb124:
  %t403 = load ptr, ptr %l0, !tbaa !29
  %t405 = getelementptr %"compiler/lower:lowering", ptr %t403, i32 0, i32 22
  %t406 = getelementptr %"compiler/typed:Plan", ptr %t405, i32 0, i32 3
  %t407 = load { i64, ptr }, ptr %t406, !tbaa !27
  store { i64, ptr } %t407, ptr %l218, !tbaa !27
  %t408 = load i32, ptr %l27, !tbaa !23
  %t410 = sext i32 %t408 to i64
  %t412 = getelementptr { i64, ptr }, ptr %l218, i32 0, i32 1
  %t413 = load ptr, ptr %t412, !tbaa !27
  %t414 = getelementptr i1, ptr %t413, i64 %t410
  %t415 = load i1, ptr %t414, !tbaa !31
  %t417 = xor i1 %t415, true
  store i1 %t417, ptr %l216, !tbaa !21
  br label %bb125
bb125:
  %t419 = load i1, ptr %l216, !tbaa !21
  store i1 %t419, ptr %rv
  br label %ret
bb126:
  br i1 true, label %bb127, label %bb128
bb127:
  br label %bb129
bb128:
  br label %bb130
bb129:
  br label %bb131
bb130:
  call void @__olang_check_failed(ptr @olang_loc_4b16c1f6667ae236_8522eea6e5c16fe2)
  unreachable
bb131:
  br label %bb137
bb132:
  br i1 true, label %bb133, label %bb134
bb133:
  br label %bb135
bb134:
  br label %bb136
bb135:
  br label %bb137
bb136:
  call void @__olang_check_failed(ptr @olang_loc_d0e8b819f5194451_9afcdf330b6f59b5)
  unreachable
bb137:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2erun(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca %"compiler/typed:Local"
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca { i64, [1 x i64] }
  %l13 = alloca { i64, [1 x i64] }
  %l14 = alloca i64
  %l15 = alloca ptr
  %l16 = alloca i64
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca i64
  %l21 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca ptr
  %l29 = alloca i64
  %l30 = alloca { i64, ptr }
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca { i64, [1 x i64] }
  %l34 = alloca i32
  %l35 = alloca i32
  %l37 = alloca ptr
  %l38 = alloca i32
  %l39 = alloca { i64, ptr }
  %l40 = alloca i64
  %l41 = alloca i64
  %l44 = alloca i1
  %l45 = alloca i32
  %l52 = alloca i64
  %l56 = alloca i64
  %l59 = alloca i64
  %l80 = alloca %"compiler/typed:Local"
  %l82 = alloca i32
  %l97 = alloca i1
  %l104 = alloca { i64, ptr }
  %l116 = alloca ptr
  %l122 = alloca %"compiler/mir:Local"
  %l123 = alloca i32
  %l128 = alloca { i64, ptr }
  %l131 = alloca { i64, ptr }
  %l132 = alloca i32
  %l141 = alloca { i64, ptr }
  %l154 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l157 = alloca i64
  %l161 = alloca i64
  %l164 = alloca i64
  %l185 = alloca %"compiler/typed:Local"
  %l201 = alloca { i64, ptr }
  %l204 = alloca { i64, ptr }
  %l205 = alloca i32
  %l214 = alloca { i64, ptr }
  %l217 = alloca { i64, [1 x i64] }
  %l224 = alloca i64
  %l240 = alloca i64
  %l254 = alloca ptr
  %l259 = alloca %"compiler/lower:Gap"
  %l262 = alloca i32
  %l266 = alloca ptr
  %l267 = alloca i32
  %l268 = alloca i32
  %l276 = alloca i32
  %l284 = alloca ptr
  %l285 = alloca i32
  %l292 = alloca %"compiler/lower:level"
  %l304 = alloca { i64, ptr }
  %l315 = alloca i1
  %l321 = alloca i32
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %s31 = alloca %olang.scope
  %t98 = alloca { i64, [1 x i64] }, align 8
  %t142 = alloca { i64, [1 x i64] }, align 8
  %t154 = alloca { i64, [1 x i64] }, align 8
  %t385 = alloca { i64, [1 x i64] }, align 8
  %t397 = alloca { i64, [1 x i64] }, align 8
  %t406 = alloca { i64, [1 x i64] }, align 8
  %t415 = alloca { i64, [1 x i64] }, align 8
  %t433 = alloca { i64, [1 x i64] }, align 8
  %t522 = alloca { i64, [21 x i64] }, align 8
  %t635 = alloca { i64, [4 x i64] }, align 8
  %t638 = alloca { i64, [8 x i64] }, align 8
  %t655 = alloca { i64, [4 x i64] }, align 8
  %t658 = alloca { i64, [8 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l1, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/lower:lowering", ptr %t6, i32 0, i32 2
  %t9 = load ptr, ptr %t8, !tbaa !29
  store ptr %t9, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  %t11 = load ptr, ptr %l1, !tbaa !29
  %t13 = getelementptr %"compiler/typed:Body", ptr %t11, i32 0, i32 7
  %t15 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eLen_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t13)
  store i64 %t15, ptr %l52
  br label %bb1
bb1:
  %t16 = load i64, ptr %l52, !tbaa !24
  store i64 %t16, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t17 = load i64, ptr %l4, !tbaa !24
  %t18 = load i64, ptr %l3, !tbaa !24
  %t21 = icmp sgt i64 %t17, %t18
  br i1 %t21, label %bb2, label %bb3
bb2:
  %t23 = load i64, ptr %l5, !tbaa !24
  %t25 = icmp sgt i64 %t23, 0
  br i1 %t25, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l56, !tbaa !24
  br label %bb7
bb4:
  %t27 = load i64, ptr %l4, !tbaa !24
  %t28 = load i64, ptr %l3, !tbaa !24
  %t31 = sub i64 %t27, %t28
  %t32 = load i64, ptr %l5, !tbaa !24
  %t35 = add i64 %t31, %t32
  %t37 = sub i64 %t35, 1
  %t38 = load i64, ptr %l5, !tbaa !24
  %t41 = sdiv i64 %t37, %t38
  store i64 %t41, ptr %l59, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l59, !tbaa !24
  br label %bb6
bb6:
  %t43 = load i64, ptr %l59, !tbaa !24
  store i64 %t43, ptr %l56, !tbaa !24
  br label %bb7
bb7:
  %t44 = load i64, ptr %l56, !tbaa !24
  store i64 %t44, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t45 = load i64, ptr %l7, !tbaa !24
  %t46 = load i64, ptr %l6, !tbaa !24
  %t49 = icmp slt i64 %t45, %t46
  %t51 = xor i1 %t49, true
  br i1 %t51, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb51
bb10:
  br label %bb11
bb11:
  %t53 = load i64, ptr %l3, !tbaa !24
  %t54 = load i64, ptr %l7, !tbaa !24
  %t55 = load i64, ptr %l5, !tbaa !24
  %t58 = mul i64 %t54, %t55
  %t61 = add i64 %t53, %t58
  store i64 %t61, ptr %l8, !tbaa !24
  %t63 = load ptr, ptr %l1, !tbaa !29
  %t65 = getelementptr %"compiler/typed:Body", ptr %t63, i32 0, i32 7
  %t66 = load i64, ptr %l8, !tbaa !24
  %t69 = call %"compiler/typed:Local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t65, i64 %t66)
  store %"compiler/typed:Local" %t69, ptr %l80
  br label %bb12
bb12:
  %t70 = load %"compiler/typed:Local", ptr %l80
  store %"compiler/typed:Local" %t70, ptr %l9
  %t71 = getelementptr %"compiler/typed:Local", ptr %l9, i32 0, i32 4
  %t72 = load i32, ptr %t71
  store i32 %t72, ptr %l10
  %t74 = load i32, ptr %l10
  %t76 = trunc i64 0 to i32
  %t77 = icmp eq i32 %t74, %t76
  br i1 %t77, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  store i32 0, ptr %l82
  br label %bb25
bb16:
  %t80 = load i32, ptr %l10
  %t82 = trunc i64 5 to i32
  %t83 = icmp eq i32 %t80, %t82
  br i1 %t83, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  store i32 1, ptr %l82
  br label %bb25
bb20:
  br i1 true, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  store i32 2, ptr %l82
  br label %bb25
bb24:
  call void @__olang_check_failed(ptr @olang_loc_a41c6179c77e6584_47cab6c73a638ed0)
  unreachable
bb25:
  %t87 = load i32, ptr %l82
  store i32 %t87, ptr %l11
  %t88 = getelementptr %"compiler/typed:Local", ptr %l9, i32 0, i32 2
  %t89 = load i32, ptr %t88, !tbaa !23
  %t90 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t93 = icmp eq i32 %t89, %t90
  br i1 %t93, label %bb26, label %bb27
bb26:
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t97 = getelementptr %"compiler/lower:lowering", ptr %t95, i32 0, i32 8
  store i1 true, ptr %t97, !tbaa !21
  br label %bb28
bb27:
  br label %bb28
bb28:
  store { i64, [1 x i64] } zeroinitializer, ptr %t98
  %t99 = getelementptr { i64, [1 x i64] }, ptr %t98, i32 0, i32 0
  store i64 3, ptr %t99
  %t100 = load { i64, [1 x i64] }, ptr %t98
  store { i64, [1 x i64] } %t100, ptr %l12
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = getelementptr %"compiler/lower:lowering", ptr %t102, i32 0, i32 19
  %t105 = load i1, ptr %t104, !tbaa !21
  br i1 %t105, label %bb29, label %bb30
bb29:
  %t107 = load i64, ptr %l8, !tbaa !24
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = getelementptr %"compiler/lower:lowering", ptr %t108, i32 0, i32 22
  %t111 = getelementptr %"compiler/typed:Plan", ptr %t110, i32 0, i32 1
  %t112 = load { i64, ptr }, ptr %t111, !tbaa !27
  %t114 = extractvalue { i64, ptr } %t112, 0
  %t117 = icmp slt i64 %t107, %t114
  store i1 %t117, ptr %l97, !tbaa !21
  br label %bb31
bb30:
  store i1 false, ptr %l97, !tbaa !21
  br label %bb31
bb31:
  %t119 = load i1, ptr %l97, !tbaa !21
  br i1 %t119, label %bb32, label %bb33
bb32:
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t122 = getelementptr %"compiler/lower:lowering", ptr %t120, i32 0, i32 22
  %t123 = getelementptr %"compiler/typed:Plan", ptr %t122, i32 0, i32 1
  %t124 = load { i64, ptr }, ptr %t123, !tbaa !27
  store { i64, ptr } %t124, ptr %l104, !tbaa !27
  %t125 = load i64, ptr %l8, !tbaa !24
  %t127 = getelementptr { i64, ptr }, ptr %l104, i32 0, i32 1
  %t128 = load ptr, ptr %t127, !tbaa !27
  %t129 = getelementptr { i64, [1 x i64] }, ptr %t128, i64 %t125
  %t130 = load { i64, [1 x i64] }, ptr %t129
  store { i64, [1 x i64] } %t130, ptr %l13
  %t132 = load { i64, [1 x i64] }, ptr %l13
  %t134 = extractvalue { i64, [1 x i64] } %t132, 0
  %t135 = icmp eq i64 %t134, 2
  br i1 %t135, label %bb34, label %bb35
bb33:
  br label %bb47
bb34:
  %t137 = getelementptr { i64, [1 x i64] }, ptr %l13, i32 0, i32 1
  %t138 = getelementptr { i64 }, ptr %t137, i32 0, i32 0
  %t139 = load i64, ptr %t138
  store i64 %t139, ptr %l14, !tbaa !24
  br label %bb36
bb35:
  br label %bb37
bb36:
  %t141 = load i64, ptr %l14, !tbaa !24
  store { i64, [1 x i64] } zeroinitializer, ptr %t142
  %t143 = getelementptr { i64, [1 x i64] }, ptr %t142, i32 0, i32 0
  store i64 1, ptr %t143
  %t145 = insertvalue { i64 } undef, i64 %t141, 0
  %t146 = getelementptr { i64, [1 x i64] }, ptr %t142, i32 0, i32 1
  store { i64 } %t145, ptr %t146
  %t147 = load { i64, [1 x i64] }, ptr %t142
  store { i64, [1 x i64] } %t147, ptr %l12
  br label %bb46
bb37:
  %t149 = load { i64, [1 x i64] }, ptr %l13
  %t151 = extractvalue { i64, [1 x i64] } %t149, 0
  %t152 = icmp eq i64 %t151, 3
  br i1 %t152, label %bb38, label %bb39
bb38:
  br label %bb40
bb39:
  br label %bb41
bb40:
  store { i64, [1 x i64] } zeroinitializer, ptr %t154
  %t155 = getelementptr { i64, [1 x i64] }, ptr %t154, i32 0, i32 0
  store i64 2, ptr %t155
  %t156 = load { i64, [1 x i64] }, ptr %t154
  store { i64, [1 x i64] } %t156, ptr %l12
  br label %bb46
bb41:
  br i1 true, label %bb42, label %bb43
bb42:
  br label %bb44
bb43:
  br label %bb45
bb44:
  br label %bb46
bb45:
  call void @__olang_check_failed(ptr @olang_loc_d5691da7c866d175_fd62f9716bce2461)
  unreachable
bb46:
  br label %bb47
bb47:
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t160 = getelementptr %"compiler/lower:lowering", ptr %t158, i32 0, i32 3
  store ptr %t160, ptr %l116, !tbaa !29
  %t161 = getelementptr %"compiler/typed:Local", ptr %l9, i32 0, i32 0
  %t162 = load i32, ptr %t161, !tbaa !23
  %t163 = getelementptr %"compiler/typed:Local", ptr %l9, i32 0, i32 1
  %t164 = load %"compiler/source:Span", ptr %t163
  %t165 = getelementptr %"compiler/typed:Local", ptr %l9, i32 0, i32 2
  %t166 = load i32, ptr %t165, !tbaa !23
  %t167 = load i32, ptr %l11
  %t168 = load { i64, [1 x i64] }, ptr %l12
  %t174 = call %"compiler/mir:Local" @compiler_2fmir_3aLocal_2ector(ptr %s2, i32 %t162, %"compiler/source:Span" %t164, i32 %t166, i32 %t167, { i64, [1 x i64] } %t168)
  store %"compiler/mir:Local" %t174, ptr %l122
  br label %bb48
bb48:
  %t175 = load ptr, ptr %l116, !tbaa !29
  %t176 = load %"compiler/mir:Local", ptr %l122
  %t177 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddLocal(ptr %v0, ptr %t175, %"compiler/mir:Local" %t176)
  store i32 %t177, ptr %l123
  br label %bb49
bb49:
  call void @__olang_scope_close(ptr %s2)
  br label %bb50
bb50:
  %t178 = load i64, ptr %l7, !tbaa !24
  %t180 = add i64 %t178, 1
  store i64 %t180, ptr %l7, !tbaa !24
  br label %bb8
bb51:
  %t182 = load ptr, ptr %l1, !tbaa !29
  %t184 = getelementptr %"compiler/typed:Body", ptr %t182, i32 0, i32 5
  store ptr %t184, ptr %l15, !tbaa !29
  store i64 0, ptr %l16, !tbaa !24
  br label %bb52
bb52:
  store %olang.scope zeroinitializer, ptr %s13
  %t186 = load ptr, ptr %l15, !tbaa !29
  %t187 = load i64, ptr %l16, !tbaa !24
  %t190 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2eRun_H55075af11bca18d6ea540b66cb20a6c9(ptr %v0, ptr %t186, i64 %t187)
  %t191 = extractvalue { i32, { i64, ptr } } %t190, 1
  %t192 = extractvalue { i32, { i64, ptr } } %t190, 0
  store i32 %t192, ptr %l132
  %t193 = icmp ne i32 %t192, 0
  br i1 %t193, label %bb54, label %ok.194
ok.194:
  store { i64, ptr } %t191, ptr %l131
  br label %bb53
bb53:
  %t195 = load { i64, ptr }, ptr %l131, !tbaa !27
  store { i64, ptr } %t195, ptr %l128, !tbaa !27
  br label %bb58
bb54:
  %t196 = load i32, ptr %l132, !tbaa !23
  %t197 = ashr i32 %t196, 16
  %t199 = icmp eq i32 %t197, 1
  br i1 %t199, label %bb55, label %bb56
bb55:
  br label %bb57
bb56:
  call void @__olang_check_failed(ptr @olang_loc_9d64f8741da6e7be_5ae354e0f93b83ca)
  unreachable
bb57:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s13)
  br label %bb67
bb58:
  %t201 = load { i64, ptr }, ptr %l128, !tbaa !27
  store { i64, ptr } %t201, ptr %l17, !tbaa !27
  %t202 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t204 = extractvalue { i64, ptr } %t202, 0
  store i64 %t204, ptr %l18, !tbaa !24
  store i64 0, ptr %l19, !tbaa !24
  br label %bb59
bb59:
  store %olang.scope zeroinitializer, ptr %s14
  %t206 = load i64, ptr %l19, !tbaa !24
  %t207 = load i64, ptr %l18, !tbaa !24
  %t210 = icmp slt i64 %t206, %t207
  %t212 = xor i1 %t210, true
  br i1 %t212, label %bb60, label %bb61
bb60:
  call void @__olang_scope_close(ptr %s14)
  br label %bb65
bb61:
  br label %bb62
bb62:
  %t214 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t214, ptr %l141, !tbaa !27
  %t215 = load i64, ptr %l19, !tbaa !24
  %t217 = getelementptr { i64, ptr }, ptr %l141, i32 0, i32 1
  %t218 = load ptr, ptr %t217, !tbaa !27
  %t219 = getelementptr i32, ptr %t218, i64 %t215
  %t220 = load i32, ptr %t219, !tbaa !33
  %t222 = load ptr, ptr %l0, !tbaa !29
  %t224 = getelementptr %"compiler/lower:lowering", ptr %t222, i32 0, i32 3
  %t225 = getelementptr %"compiler/mir:Fn", ptr %t224, i32 0, i32 4
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aLocalId_3e_2ePush_3ccompiler_2fmir_3aLocalId_3e(ptr %v0, ptr %t225, i32 %t220)
  br label %bb63
bb63:
  call void @__olang_scope_close(ptr %s14)
  br label %bb64
bb64:
  %t231 = load i64, ptr %l19, !tbaa !24
  %t233 = add i64 %t231, 1
  store i64 %t233, ptr %l19, !tbaa !24
  br label %bb59
bb65:
  %t235 = load i64, ptr %l16, !tbaa !24
  %t236 = load i64, ptr %l18, !tbaa !24
  %t239 = add i64 %t235, %t236
  store i64 %t239, ptr %l16, !tbaa !24
  call void @__olang_scope_close(ptr %s13)
  br label %bb66
bb66:
  br label %bb52
bb67:
  %t241 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e(ptr %s0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t241, ptr %l154
  br label %bb68
bb68:
  %t242 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l154
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t242, ptr %l21
  store i64 0, ptr %l22, !tbaa !24
  %t243 = load ptr, ptr %l1, !tbaa !29
  %t245 = getelementptr %"compiler/typed:Body", ptr %t243, i32 0, i32 7
  %t247 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eLen_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t245)
  store i64 %t247, ptr %l157
  br label %bb69
bb69:
  %t248 = load i64, ptr %l157, !tbaa !24
  store i64 %t248, ptr %l23, !tbaa !24
  store i64 1, ptr %l24, !tbaa !24
  %t249 = load i64, ptr %l23, !tbaa !24
  %t250 = load i64, ptr %l22, !tbaa !24
  %t253 = icmp sgt i64 %t249, %t250
  br i1 %t253, label %bb70, label %bb71
bb70:
  %t255 = load i64, ptr %l24, !tbaa !24
  %t257 = icmp sgt i64 %t255, 0
  br i1 %t257, label %bb72, label %bb73
bb71:
  store i64 0, ptr %l161, !tbaa !24
  br label %bb75
bb72:
  %t259 = load i64, ptr %l23, !tbaa !24
  %t260 = load i64, ptr %l22, !tbaa !24
  %t263 = sub i64 %t259, %t260
  %t264 = load i64, ptr %l24, !tbaa !24
  %t267 = add i64 %t263, %t264
  %t269 = sub i64 %t267, 1
  %t270 = load i64, ptr %l24, !tbaa !24
  %t273 = sdiv i64 %t269, %t270
  store i64 %t273, ptr %l164, !tbaa !24
  br label %bb74
bb73:
  store i64 0, ptr %l164, !tbaa !24
  br label %bb74
bb74:
  %t275 = load i64, ptr %l164, !tbaa !24
  store i64 %t275, ptr %l161, !tbaa !24
  br label %bb75
bb75:
  %t276 = load i64, ptr %l161, !tbaa !24
  store i64 %t276, ptr %l25, !tbaa !24
  store i64 0, ptr %l26, !tbaa !24
  br label %bb76
bb76:
  store %olang.scope zeroinitializer, ptr %s17
  %t277 = load i64, ptr %l26, !tbaa !24
  %t278 = load i64, ptr %l25, !tbaa !24
  %t281 = icmp slt i64 %t277, %t278
  %t283 = xor i1 %t281, true
  br i1 %t283, label %bb77, label %bb78
bb77:
  call void @__olang_scope_close(ptr %s17)
  br label %bb87
bb78:
  br label %bb79
bb79:
  %t285 = load i64, ptr %l22, !tbaa !24
  %t286 = load i64, ptr %l26, !tbaa !24
  %t287 = load i64, ptr %l24, !tbaa !24
  %t290 = mul i64 %t286, %t287
  %t293 = add i64 %t285, %t290
  store i64 %t293, ptr %l27, !tbaa !24
  %t295 = load ptr, ptr %l1, !tbaa !29
  %t297 = getelementptr %"compiler/typed:Body", ptr %t295, i32 0, i32 7
  %t298 = load i64, ptr %l27, !tbaa !24
  %t301 = call %"compiler/typed:Local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t297, i64 %t298)
  store %"compiler/typed:Local" %t301, ptr %l185
  br label %bb80
bb80:
  %t302 = getelementptr %"compiler/typed:Local", ptr %l185, i32 0, i32 4
  %t303 = load i32, ptr %t302
  %t305 = trunc i64 5 to i32
  %t306 = icmp eq i32 %t303, %t305
  br i1 %t306, label %bb81, label %bb82
bb81:
  %t308 = load i64, ptr %l27, !tbaa !24
  %t310 = trunc i64 %t308 to i32
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2ePus_H9afb0399fee55ed1ef4b4d03ad72cb66(ptr %s0, ptr %l21, i32 %t310)
  br label %bb83
bb82:
  br label %bb85
bb83:
  %t314 = load ptr, ptr %l0, !tbaa !29
  %t316 = getelementptr %"compiler/lower:lowering", ptr %t314, i32 0, i32 3
  %t317 = getelementptr %"compiler/mir:Fn", ptr %t316, i32 0, i32 5
  %t318 = load i64, ptr %l27, !tbaa !24
  %t320 = trunc i64 %t318 to i32
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aLocalId_3e_2ePush_3ccompiler_2fmir_3aLocalId_3e(ptr %v0, ptr %t317, i32 %t320)
  br label %bb84
bb84:
  br label %bb85
bb85:
  call void @__olang_scope_close(ptr %s17)
  br label %bb86
bb86:
  %t324 = load i64, ptr %l26, !tbaa !24
  %t326 = add i64 %t324, 1
  store i64 %t326, ptr %l26, !tbaa !24
  br label %bb76
bb87:
  %t328 = load ptr, ptr %l1, !tbaa !29
  %t330 = getelementptr %"compiler/typed:Body", ptr %t328, i32 0, i32 6
  store ptr %t330, ptr %l28, !tbaa !29
  store i64 0, ptr %l29, !tbaa !24
  br label %bb88
bb88:
  store %olang.scope zeroinitializer, ptr %s21
  %t332 = load ptr, ptr %l28, !tbaa !29
  %t333 = load i64, ptr %l29, !tbaa !24
  %t336 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aScopeVar_3e_2eRu_Hba7f56c70b20c8f60a4a5345f2cfd0c9(ptr %v0, ptr %t332, i64 %t333)
  %t337 = extractvalue { i32, { i64, ptr } } %t336, 1
  %t338 = extractvalue { i32, { i64, ptr } } %t336, 0
  store i32 %t338, ptr %l205
  %t339 = icmp ne i32 %t338, 0
  br i1 %t339, label %bb90, label %ok.340
ok.340:
  store { i64, ptr } %t337, ptr %l204
  br label %bb89
bb89:
  %t341 = load { i64, ptr }, ptr %l204, !tbaa !27
  store { i64, ptr } %t341, ptr %l201, !tbaa !27
  br label %bb94
bb90:
  %t342 = load i32, ptr %l205, !tbaa !23
  %t343 = ashr i32 %t342, 16
  %t345 = icmp eq i32 %t343, 1
  br i1 %t345, label %bb91, label %bb92
bb91:
  br label %bb93
bb92:
  call void @__olang_check_failed(ptr @olang_loc_3c711cf1361ddabf_138c88590169ee0b)
  unreachable
bb93:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s21)
  br label %bb126
bb94:
  %t347 = load { i64, ptr }, ptr %l201, !tbaa !27
  store { i64, ptr } %t347, ptr %l30, !tbaa !27
  %t348 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t350 = extractvalue { i64, ptr } %t348, 0
  store i64 %t350, ptr %l31, !tbaa !24
  store i64 0, ptr %l32, !tbaa !24
  br label %bb95
bb95:
  store %olang.scope zeroinitializer, ptr %s22
  %t352 = load i64, ptr %l32, !tbaa !24
  %t353 = load i64, ptr %l31, !tbaa !24
  %t356 = icmp slt i64 %t352, %t353
  %t358 = xor i1 %t356, true
  br i1 %t358, label %bb96, label %bb97
bb96:
  call void @__olang_scope_close(ptr %s22)
  br label %bb124
bb97:
  br label %bb98
bb98:
  %t360 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t360, ptr %l214, !tbaa !27
  %t361 = load i64, ptr %l32, !tbaa !24
  %t363 = getelementptr { i64, ptr }, ptr %l214, i32 0, i32 1
  %t364 = load ptr, ptr %t363, !tbaa !27
  %t365 = getelementptr { i64, [1 x i64] }, ptr %t364, i64 %t361
  %t366 = load { i64, [1 x i64] }, ptr %t365
  store { i64, [1 x i64] } %t366, ptr %l33
  %t368 = load { i64, [1 x i64] }, ptr %l33
  %t370 = extractvalue { i64, [1 x i64] } %t368, 0
  %t371 = icmp eq i64 %t370, 0
  br i1 %t371, label %bb99, label %bb100
bb99:
  %t373 = getelementptr { i64, [1 x i64] }, ptr %l33, i32 0, i32 1
  %t374 = getelementptr { i32 }, ptr %t373, i32 0, i32 0
  %t375 = load i32, ptr %t374
  store i32 %t375, ptr %l34, !tbaa !23
  br label %bb101
bb100:
  br label %bb103
bb101:
  %t377 = load ptr, ptr %l1, !tbaa !29
  %t379 = getelementptr %"compiler/typed:Body", ptr %t377, i32 0, i32 5
  %t380 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t379
  %t381 = load i32, ptr %l34, !tbaa !23
  %t384 = call i64 @compiler_2flower_2eindexOf(ptr %v0, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t380, i32 %t381)
  store i64 %t384, ptr %l224
  br label %bb102
bb102:
  store { i64, [1 x i64] } zeroinitializer, ptr %t385
  %t386 = getelementptr { i64, [1 x i64] }, ptr %t385, i32 0, i32 0
  store i64 0, ptr %t386
  %t387 = load i64, ptr %l224, !tbaa !24
  %t388 = insertvalue { i64 } undef, i64 %t387, 0
  %t389 = getelementptr { i64, [1 x i64] }, ptr %t385, i32 0, i32 1
  store { i64 } %t388, ptr %t389
  %t390 = load { i64, [1 x i64] }, ptr %t385
  store { i64, [1 x i64] } %t390, ptr %l217
  br label %bb121
bb103:
  %t392 = load { i64, [1 x i64] }, ptr %l33
  %t394 = extractvalue { i64, [1 x i64] } %t392, 0
  %t395 = icmp eq i64 %t394, 1
  br i1 %t395, label %bb104, label %bb105
bb104:
  br label %bb106
bb105:
  br label %bb107
bb106:
  store { i64, [1 x i64] } zeroinitializer, ptr %t397
  %t398 = getelementptr { i64, [1 x i64] }, ptr %t397, i32 0, i32 0
  store i64 1, ptr %t398
  %t399 = load { i64, [1 x i64] }, ptr %t397
  store { i64, [1 x i64] } %t399, ptr %l217
  br label %bb121
bb107:
  %t401 = load { i64, [1 x i64] }, ptr %l33
  %t403 = extractvalue { i64, [1 x i64] } %t401, 0
  %t404 = icmp eq i64 %t403, 2
  br i1 %t404, label %bb108, label %bb109
bb108:
  br label %bb110
bb109:
  br label %bb111
bb110:
  store { i64, [1 x i64] } zeroinitializer, ptr %t406
  %t407 = getelementptr { i64, [1 x i64] }, ptr %t406, i32 0, i32 0
  store i64 2, ptr %t407
  %t408 = load { i64, [1 x i64] }, ptr %t406
  store { i64, [1 x i64] } %t408, ptr %l217
  br label %bb121
bb111:
  %t410 = load { i64, [1 x i64] }, ptr %l33
  %t412 = extractvalue { i64, [1 x i64] } %t410, 0
  %t413 = icmp eq i64 %t412, 3
  br i1 %t413, label %bb112, label %bb113
bb112:
  br label %bb114
bb113:
  br label %bb115
bb114:
  store { i64, [1 x i64] } zeroinitializer, ptr %t415
  %t416 = getelementptr { i64, [1 x i64] }, ptr %t415, i32 0, i32 0
  store i64 3, ptr %t416
  %t417 = load { i64, [1 x i64] }, ptr %t415
  store { i64, [1 x i64] } %t417, ptr %l217
  br label %bb121
bb115:
  %t419 = load { i64, [1 x i64] }, ptr %l33
  %t421 = extractvalue { i64, [1 x i64] } %t419, 0
  %t422 = icmp eq i64 %t421, 4
  br i1 %t422, label %bb116, label %bb117
bb116:
  %t424 = getelementptr { i64, [1 x i64] }, ptr %l33, i32 0, i32 1
  %t425 = getelementptr { i32 }, ptr %t424, i32 0, i32 0
  %t426 = load i32, ptr %t425
  store i32 %t426, ptr %l35, !tbaa !23
  br label %bb118
bb117:
  br label %bb120
bb118:
  %t428 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l21
  %t429 = load i32, ptr %l35, !tbaa !23
  %t432 = call i64 @compiler_2flower_2eindexOf(ptr %s0, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t428, i32 %t429)
  store i64 %t432, ptr %l240
  br label %bb119
bb119:
  store { i64, [1 x i64] } zeroinitializer, ptr %t433
  %t434 = getelementptr { i64, [1 x i64] }, ptr %t433, i32 0, i32 0
  store i64 4, ptr %t434
  %t435 = load i64, ptr %l240, !tbaa !24
  %t436 = insertvalue { i64 } undef, i64 %t435, 0
  %t437 = getelementptr { i64, [1 x i64] }, ptr %t433, i32 0, i32 1
  store { i64 } %t436, ptr %t437
  %t438 = load { i64, [1 x i64] }, ptr %t433
  store { i64, [1 x i64] } %t438, ptr %l217
  br label %bb121
bb120:
  call void @__olang_check_failed(ptr @olang_loc_2bd09fabd8df32c8_ad90679d53368f6c)
  unreachable
bb121:
  %t440 = load { i64, [1 x i64] }, ptr %l217
  %t441 = load ptr, ptr %l0, !tbaa !29
  %t443 = getelementptr %"compiler/lower:lowering", ptr %t441, i32 0, i32 3
  %t444 = getelementptr %"compiler/mir:Fn", ptr %t443, i32 0, i32 6
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aVarKind_3e_2ePush_3ccompiler_2fmir_3aVarKind_3e(ptr %v0, ptr %t444, { i64, [1 x i64] } %t440)
  br label %bb122
bb122:
  call void @__olang_scope_close(ptr %s22)
  br label %bb123
bb123:
  %t448 = load i64, ptr %l32, !tbaa !24
  %t450 = add i64 %t448, 1
  store i64 %t450, ptr %l32, !tbaa !24
  br label %bb95
bb124:
  %t452 = load i64, ptr %l29, !tbaa !24
  %t453 = load i64, ptr %l31, !tbaa !24
  %t456 = add i64 %t452, %t453
  store i64 %t456, ptr %l29, !tbaa !24
  call void @__olang_scope_close(ptr %s21)
  br label %bb125
bb125:
  br label %bb88
bb126:
  %t458 = load ptr, ptr %l0, !tbaa !29
  %t460 = getelementptr %"compiler/lower:lowering", ptr %t458, i32 0, i32 8
  %t461 = load i1, ptr %t460, !tbaa !21
  br i1 %t461, label %bb127, label %bb128
bb127:
  %t463 = load ptr, ptr %l0, !tbaa !29
  %t465 = getelementptr %"compiler/lower:lowering", ptr %t463, i32 0, i32 0
  %t466 = load ptr, ptr %t465, !tbaa !29
  %t468 = getelementptr %"compiler/lower:Lowerer", ptr %t466, i32 0, i32 4
  store ptr %t468, ptr %l254, !tbaa !29
  %t469 = load ptr, ptr %l0, !tbaa !29
  %t471 = getelementptr %"compiler/lower:lowering", ptr %t469, i32 0, i32 4
  %t472 = load i64, ptr %t471, !tbaa !24
  %t473 = load ptr, ptr %l1, !tbaa !29
  %t475 = getelementptr %"compiler/typed:Body", ptr %t473, i32 0, i32 4
  %t476 = load %"compiler/source:Span", ptr %t475
  %t479 = call %"compiler/lower:Gap" @compiler_2flower_3aGap_2ector(ptr %v0, ptr %v0, i64 %t472, %"compiler/source:Span" %t476, { i64, ptr } { i64 47, ptr getelementptr inbounds (<{ i64, [47 x i8] }>, ptr @.d31, i32 0, i32 1) })
  store %"compiler/lower:Gap" %t479, ptr %l259
  br label %bb129
bb128:
  br label %bb131
bb129:
  %t480 = load ptr, ptr %l254, !tbaa !29
  %t481 = load %"compiler/lower:Gap", ptr %l259
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3aGap_3e_2ePush_3ccompiler_2flower_3aGap_3e(ptr %v0, ptr %v0, ptr %t480, %"compiler/lower:Gap" %t481)
  br label %bb130
bb130:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb131:
  %t482 = load ptr, ptr %l0, !tbaa !29
  %t484 = getelementptr %"compiler/lower:lowering", ptr %t482, i32 0, i32 3
  %t486 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t484)
  store i32 %t486, ptr %l262
  br label %bb132
bb132:
  %t487 = load ptr, ptr %l1, !tbaa !29
  %t489 = getelementptr %"compiler/typed:Body", ptr %t487, i32 0, i32 11
  %t490 = load ptr, ptr %t489, !tbaa !29
  store ptr %t490, ptr %l37, !tbaa !29
  %t492 = load ptr, ptr %l0, !tbaa !29
  %t494 = getelementptr %"compiler/lower:lowering", ptr %t492, i32 0, i32 3
  store ptr %t494, ptr %l266, !tbaa !29
  store i32 0, ptr %l267
  %t495 = load i32, ptr @G_2ecompiler_2fmir_2eNoScope, !tbaa !23
  store i32 %t495, ptr %l268, !tbaa !23
  %t496 = load ptr, ptr %l37, !tbaa !29
  %t498 = icmp eq ptr %t496, null
  br i1 %t498, label %bb133, label %bb134
bb133:
  call void @__olang_check_failed(ptr @olang_loc_796d2b5c84af77ba_ecbdfcaab288560e)
  unreachable
bb134:
  br label %bb135
bb135:
  %t500 = load ptr, ptr %l37, !tbaa !29
  %t503 = getelementptr %"compiler/typed:Block", ptr %t500, i32 0, i32 0
  %t504 = load i32, ptr %t503, !tbaa !23
  %t505 = load ptr, ptr %l1, !tbaa !29
  %t507 = getelementptr %"compiler/typed:Body", ptr %t505, i32 0, i32 4
  %t508 = load %"compiler/source:Span", ptr %t507
  %t509 = load ptr, ptr %l266, !tbaa !29
  %t510 = load i32, ptr %l267
  %t511 = load i32, ptr %l268, !tbaa !23
  %t514 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddScope(ptr %v0, ptr %t509, i32 %t510, i32 %t511, i32 %t504, %"compiler/source:Span" %t508, i32 0)
  store i32 %t514, ptr %l276
  br label %bb136
bb136:
  %t515 = load i32, ptr %l276, !tbaa !23
  store i32 %t515, ptr %l38, !tbaa !23
  %t516 = load ptr, ptr %l0, !tbaa !29
  %t517 = load ptr, ptr %l1, !tbaa !29
  %t519 = getelementptr %"compiler/typed:Body", ptr %t517, i32 0, i32 4
  %t520 = load %"compiler/source:Span", ptr %t519
  %t521 = load i32, ptr %l38, !tbaa !23
  store { i64, [21 x i64] } zeroinitializer, ptr %t522
  %t523 = getelementptr { i64, [21 x i64] }, ptr %t522, i32 0, i32 0
  store i64 3, ptr %t523
  %t525 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t520, 0
  %t527 = insertvalue { %"compiler/source:Span", i32 } %t525, i32 %t521, 1
  %t528 = getelementptr { i64, [21 x i64] }, ptr %t522, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t527, ptr %t528
  %t529 = load { i64, [21 x i64] }, ptr %t522
  %t531 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t529, ptr %t531
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s0, ptr %t516, ptr %t531)
  br label %bb137
bb137:
  %t534 = load ptr, ptr %l0, !tbaa !29
  %t536 = getelementptr %"compiler/lower:lowering", ptr %t534, i32 0, i32 9
  store ptr %t536, ptr %l284, !tbaa !29
  %t537 = load i32, ptr %l38, !tbaa !23
  store i32 %t537, ptr %l285, !tbaa !23
  %t538 = load ptr, ptr %l37, !tbaa !29
  %t540 = icmp eq ptr %t538, null
  br i1 %t540, label %bb138, label %bb139
bb138:
  call void @__olang_check_failed(ptr @olang_loc_4394b993bdead47b_2aac5c58087818bf)
  unreachable
bb139:
  br label %bb140
bb140:
  %t542 = load ptr, ptr %l37, !tbaa !29
  %t545 = getelementptr %"compiler/typed:Block", ptr %t542, i32 0, i32 0
  %t546 = load i32, ptr %t545, !tbaa !23
  %t547 = load i32, ptr %l285, !tbaa !23
  %t550 = call %"compiler/lower:level" @compiler_2flower_3alevel_2ector(ptr %s0, i32 %t547, i32 %t546, i32 0)
  store %"compiler/lower:level" %t550, ptr %l292
  br label %bb141
bb141:
  %t551 = load ptr, ptr %l284, !tbaa !29
  %t552 = load %"compiler/lower:level", ptr %l292
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3alevel_3e_2ePush_3ccompiler_2flower_3alevel_3e(ptr %v0, ptr %t551, %"compiler/lower:level" %t552)
  br label %bb142
bb142:
  %t553 = load ptr, ptr %l37, !tbaa !29
  %t555 = icmp eq ptr %t553, null
  br i1 %t555, label %bb143, label %bb144
bb143:
  call void @__olang_check_failed(ptr @olang_loc_cb00feebc120520c_2eeb4c944941e6a0)
  unreachable
bb144:
  br label %bb145
bb145:
  %t557 = load ptr, ptr %l37, !tbaa !29
  %t560 = getelementptr %"compiler/typed:Block", ptr %t557, i32 0, i32 1
  %t561 = load { i64, ptr }, ptr %t560, !tbaa !27
  store { i64, ptr } %t561, ptr %l39, !tbaa !27
  store i64 0, ptr %l40, !tbaa !24
  %t563 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t565 = extractvalue { i64, ptr } %t563, 0
  store i64 %t565, ptr %l41, !tbaa !24
  br label %bb146
bb146:
  store %olang.scope zeroinitializer, ptr %s31
  %t567 = load i64, ptr %l40, !tbaa !24
  %t568 = load i64, ptr %l41, !tbaa !24
  %t571 = icmp slt i64 %t567, %t568
  %t573 = xor i1 %t571, true
  br i1 %t573, label %bb147, label %bb148
bb147:
  call void @__olang_scope_close(ptr %s31)
  br label %bb152
bb148:
  br label %bb149
bb149:
  %t575 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t575, ptr %l304, !tbaa !27
  %t576 = load i64, ptr %l40, !tbaa !24
  %t578 = getelementptr { i64, ptr }, ptr %l304, i32 0, i32 1
  %t579 = load ptr, ptr %t578, !tbaa !27
  %t580 = getelementptr ptr, ptr %t579, i64 %t576
  %t581 = load ptr, ptr %t580, !tbaa !39
  %t583 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estmt(ptr %v0, ptr %v0, ptr %t583, ptr %t581)
  br label %bb150
bb150:
  call void @__olang_scope_close(ptr %s31)
  br label %bb151
bb151:
  %t587 = load i64, ptr %l40, !tbaa !24
  %t589 = add i64 %t587, 1
  store i64 %t589, ptr %l40, !tbaa !24
  br label %bb146
bb152:
  %t591 = load ptr, ptr %l0, !tbaa !29
  %t593 = getelementptr %"compiler/lower:lowering", ptr %t591, i32 0, i32 7
  %t594 = load i1, ptr %t593, !tbaa !21
  br i1 %t594, label %bb153, label %bb154
bb153:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb154:
  br label %bb155
bb155:
  %t596 = load ptr, ptr %l1, !tbaa !29
  %t598 = getelementptr %"compiler/typed:Body", ptr %t596, i32 0, i32 1
  %t599 = load { i64, [2 x i64] }, ptr %t598
  %t603 = extractvalue { i64, [2 x i64] } %t599, 0
  %t604 = icmp eq i64 %t603, 1
  br i1 %t604, label %bb156, label %bb157
bb156:
  br label %bb158
bb157:
  br label %bb159
bb158:
  store i1 true, ptr %l315, !tbaa !21
  br label %bb164
bb159:
  br i1 true, label %bb160, label %bb161
bb160:
  br label %bb162
bb161:
  br label %bb163
bb162:
  store i1 false, ptr %l315, !tbaa !21
  br label %bb164
bb163:
  call void @__olang_check_failed(ptr @olang_loc_d4c7911af5db15c_82661c1bde5043d8)
  unreachable
bb164:
  %t606 = load i1, ptr %l315, !tbaa !21
  store i1 %t606, ptr %l44, !tbaa !21
  %t607 = load ptr, ptr %l2, !tbaa !29
  %t608 = load ptr, ptr %l1, !tbaa !29
  %t610 = getelementptr %"compiler/typed:Body", ptr %t608, i32 0, i32 2
  %t611 = load i32, ptr %t610, !tbaa !23
  %t614 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t607, i32 %t611)
  store i32 %t614, ptr %l321
  br label %bb165
bb165:
  %t615 = load i32, ptr %l321, !tbaa !23
  store i32 %t615, ptr %l45, !tbaa !23
  %t616 = load i1, ptr %l44, !tbaa !21
  br i1 %t616, label %bb166, label %bb167
bb166:
  %t618 = load ptr, ptr %l0, !tbaa !29
  %t619 = load i32, ptr %l45, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eassemble(ptr %v0, ptr %t618, i32 %t619)
  br label %bb168
bb167:
  %t622 = load i32, ptr %l45, !tbaa !23
  %t623 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t626 = icmp eq i32 %t622, %t623
  br i1 %t626, label %bb169, label %bb170
bb168:
  br label %bb175
bb169:
  %t628 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eleave(ptr %v0, ptr %t628, i64 0)
  br label %bb171
bb170:
  %t630 = load ptr, ptr %l0, !tbaa !29
  %t631 = load ptr, ptr %l1, !tbaa !29
  %t633 = getelementptr %"compiler/typed:Body", ptr %t631, i32 0, i32 4
  %t634 = load %"compiler/source:Span", ptr %t633
  store { i64, [4 x i64] } zeroinitializer, ptr %t635
  %t636 = getelementptr { i64, [4 x i64] }, ptr %t635, i32 0, i32 0
  store i64 0, ptr %t636
  %t637 = load { i64, [4 x i64] }, ptr %t635
  store { i64, [8 x i64] } zeroinitializer, ptr %t638
  %t639 = getelementptr { i64, [8 x i64] }, ptr %t638, i32 0, i32 0
  store i64 8, ptr %t639
  %t641 = insertvalue { %"compiler/source:Span", i32, { i64, [4 x i64] } } undef, %"compiler/source:Span" %t634, 0
  %t643 = insertvalue { %"compiler/source:Span", i32, { i64, [4 x i64] } } %t641, i32 3, 1
  %t645 = insertvalue { %"compiler/source:Span", i32, { i64, [4 x i64] } } %t643, { i64, [4 x i64] } %t637, 2
  %t646 = getelementptr { i64, [8 x i64] }, ptr %t638, i32 0, i32 1
  store { %"compiler/source:Span", i32, { i64, [4 x i64] } } %t645, ptr %t646
  %t647 = load { i64, [8 x i64] }, ptr %t638
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t630, { i64, [8 x i64] } %t647)
  br label %bb173
bb171:
  %t650 = load ptr, ptr %l0, !tbaa !29
  %t651 = load ptr, ptr %l1, !tbaa !29
  %t653 = getelementptr %"compiler/typed:Body", ptr %t651, i32 0, i32 4
  %t654 = load %"compiler/source:Span", ptr %t653
  store { i64, [4 x i64] } zeroinitializer, ptr %t655
  %t656 = getelementptr { i64, [4 x i64] }, ptr %t655, i32 0, i32 0
  store i64 0, ptr %t656
  %t657 = load { i64, [4 x i64] }, ptr %t655
  store { i64, [8 x i64] } zeroinitializer, ptr %t658
  %t659 = getelementptr { i64, [8 x i64] }, ptr %t658, i32 0, i32 0
  store i64 5, ptr %t659
  %t661 = insertvalue { %"compiler/source:Span", { i64, [4 x i64] } } undef, %"compiler/source:Span" %t654, 0
  %t663 = insertvalue { %"compiler/source:Span", { i64, [4 x i64] } } %t661, { i64, [4 x i64] } %t657, 1
  %t664 = getelementptr { i64, [8 x i64] }, ptr %t658, i32 0, i32 1
  store { %"compiler/source:Span", { i64, [4 x i64] } } %t663, ptr %t664
  %t665 = load { i64, [8 x i64] }, ptr %t658
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t650, { i64, [8 x i64] } %t665)
  br label %bb172
bb172:
  br label %bb174
bb173:
  br label %bb174
bb174:
  br label %bb175
bb175:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eseq(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l14 = alloca { i64, ptr }
  %l28 = alloca { i64, [4 x i64] }
  %s2 = alloca %olang.scope
  %rv = alloca { i64, [4 x i64] }
  %t41 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Seq", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t6 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  store i64 %t8, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t10 = load i64, ptr %l3, !tbaa !24
  %t11 = load i64, ptr %l4, !tbaa !24
  %t14 = icmp slt i64 %t10, %t11
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s2)
  br label %bb7
bb3:
  br label %bb4
bb4:
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t18, ptr %l14, !tbaa !27
  %t19 = load i64, ptr %l3, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr ptr, ptr %t22, i64 %t19
  %t24 = load ptr, ptr %t23, !tbaa !39
  %t26 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estmt(ptr %v0, ptr %v1, ptr %t26, ptr %t24)
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s2)
  br label %bb6
bb6:
  %t30 = load i64, ptr %l3, !tbaa !24
  %t32 = add i64 %t30, 1
  store i64 %t32, ptr %l3, !tbaa !24
  br label %bb1
bb7:
  %t34 = load ptr, ptr %l1, !tbaa !29
  %t36 = getelementptr %"compiler/typed:Seq", ptr %t34, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !29
  %t39 = icmp eq ptr %t37, null
  br i1 %t39, label %bb8, label %bb9
bb8:
  store { i64, [4 x i64] } zeroinitializer, ptr %t41
  %t42 = getelementptr { i64, [4 x i64] }, ptr %t41, i32 0, i32 0
  store i64 0, ptr %t42
  %t43 = load { i64, [4 x i64] }, ptr %t41
  store { i64, [4 x i64] } %t43, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t46 = load ptr, ptr %l1, !tbaa !29
  %t48 = getelementptr %"compiler/typed:Seq", ptr %t46, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !29
  %t52 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v1, ptr %t45, ptr %t49)
  store { i64, [4 x i64] } %t52, ptr %l28
  br label %bb11
bb11:
  %t53 = load { i64, [4 x i64] }, ptr %l28
  store { i64, [4 x i64] } %t53, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2espawnErrors(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l1 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l17 = alloca { i64, ptr }
  %s3 = alloca %olang.scope
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t7 = getelementptr %"compiler/typed:Block", ptr %t5, i32 0, i32 1
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  store { i64, ptr } %t8, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l5, !tbaa !24
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s3
  %t14 = load i64, ptr %l4, !tbaa !24
  %t15 = load i64, ptr %l5, !tbaa !24
  %t18 = icmp slt i64 %t14, %t15
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s3)
  br label %bb10
bb6:
  br label %bb7
bb7:
  %t22 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t22, ptr %l17, !tbaa !27
  %t23 = load i64, ptr %l4, !tbaa !24
  %t25 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr ptr, ptr %t26, i64 %t23
  %t28 = load ptr, ptr %t27, !tbaa !39
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estmtSpawnErrors(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %t28, ptr %a2)
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s3)
  br label %bb9
bb9:
  %t36 = load i64, ptr %l4, !tbaa !24
  %t38 = add i64 %t36, 1
  store i64 %t38, ptr %l4, !tbaa !24
  br label %bb4
bb10:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 6
  store i32 %a1, ptr %t5, !tbaa !23
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/lower:lowering", ptr %t6, i32 0, i32 7
  store i1 false, ptr %t8, !tbaa !21
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca { i64, [4 x i64] }
  %l7 = alloca %"compiler/source:Span"
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca %"compiler/lower:pl"
  %l11 = alloca { i64, [4 x i64] }
  %l12 = alloca i1
  %l13 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l14 = alloca i32
  %l15 = alloca %"compiler/source:Span"
  %l16 = alloca ptr
  %l17 = alloca %"compiler/source:Span"
  %l18 = alloca ptr
  %l19 = alloca %"compiler/source:Span"
  %l20 = alloca ptr
  %l21 = alloca %"compiler/source:Span"
  %l22 = alloca ptr
  %l23 = alloca ptr
  %l24 = alloca %"compiler/source:Span"
  %l25 = alloca i32
  %l26 = alloca i32
  %l27 = alloca %"compiler/source:Span"
  %l28 = alloca ptr
  %l29 = alloca %"compiler/source:Span"
  %l30 = alloca i32
  %l31 = alloca i64
  %l33 = alloca %"compiler/source:Span"
  %l34 = alloca ptr
  %l35 = alloca i32
  %l36 = alloca { i64, [4 x i64] }
  %l37 = alloca %"compiler/source:Span"
  %l38 = alloca i32
  %l39 = alloca ptr
  %l40 = alloca { i64, [4 x i64] }
  %l41 = alloca i32
  %l42 = alloca %"compiler/source:Span"
  %l43 = alloca ptr
  %l44 = alloca ptr
  %l45 = alloca ptr
  %l46 = alloca %"compiler/source:Span"
  %l47 = alloca ptr
  %l48 = alloca %"compiler/source:Span"
  %l49 = alloca ptr
  %l50 = alloca %"compiler/source:Span"
  %l51 = alloca ptr
  %l52 = alloca %"compiler/source:Span"
  %l53 = alloca ptr
  %l56 = alloca ptr
  %l57 = alloca i1
  %l71 = alloca %"compiler/typed:Local"
  %l73 = alloca ptr
  %l74 = alloca ptr
  %l75 = alloca i32
  %l76 = alloca %"compiler/source:Span"
  %l79 = alloca { i64, [1 x i64] }
  %l80 = alloca { i64, [4 x i64] }
  %l84 = alloca i1
  %l85 = alloca i1
  %l90 = alloca i1
  %l92 = alloca i1
  %l96 = alloca i1
  %l98 = alloca i1
  %l102 = alloca ptr
  %l103 = alloca { i64, [4 x i64] }
  %l104 = alloca i32
  %l105 = alloca %"compiler/source:Span"
  %l108 = alloca { i64, [1 x i64] }
  %l109 = alloca { i64, [4 x i64] }
  %l114 = alloca %"compiler/mir:Local"
  %l125 = alloca ptr
  %l126 = alloca %"compiler/source:Span"
  %l130 = alloca %"compiler/mir:Place"
  %l135 = alloca ptr
  %l136 = alloca i1
  %l148 = alloca %"compiler/lower:pl"
  %l152 = alloca ptr
  %l156 = alloca { i64, [4 x i64] }
  %l158 = alloca ptr
  %l160 = alloca i32
  %l162 = alloca { i64, [4 x i64] }
  %l163 = alloca %"compiler/lower:pl"
  %l166 = alloca %"compiler/lower:pl"
  %l167 = alloca i32
  %l168 = alloca ptr
  %l170 = alloca i32
  %l171 = alloca i1
  %l172 = alloca i1
  %l176 = alloca ptr
  %l177 = alloca ptr
  %l179 = alloca i32
  %l180 = alloca i1
  %l181 = alloca ptr
  %l184 = alloca %"compiler/mir:Place"
  %l185 = alloca { i64, [4 x i64] }
  %l187 = alloca i32
  %l188 = alloca i1
  %l189 = alloca %"compiler/source:Span"
  %l192 = alloca { i64, [1 x i64] }
  %l195 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l198 = alloca i64
  %l200 = alloca i1
  %l204 = alloca ptr
  %l206 = alloca i32
  %l208 = alloca i32
  %l209 = alloca ptr
  %l210 = alloca %"compiler/source:Span"
  %l212 = alloca %"compiler/mir:Place"
  %l215 = alloca %"compiler/mir:Place"
  %l220 = alloca ptr
  %l221 = alloca %"compiler/source:Span"
  %l224 = alloca %"compiler/mir:Place"
  %l236 = alloca ptr
  %l237 = alloca i1
  %l247 = alloca ptr
  %l248 = alloca i1
  %l255 = alloca ptr
  %l256 = alloca %"compiler/source:Span"
  %l260 = alloca ptr
  %l261 = alloca i1
  %l271 = alloca ptr
  %l272 = alloca i1
  %l285 = alloca ptr
  %l286 = alloca i1
  %l299 = alloca ptr
  %l300 = alloca i1
  %l310 = alloca ptr
  %l311 = alloca i1
  %l321 = alloca ptr
  %l327 = alloca i32
  %l330 = alloca i64
  %l336 = alloca ptr
  %l337 = alloca i1
  %l349 = alloca { i64, [4 x i64] }
  %l353 = alloca i1
  %l355 = alloca ptr
  %l361 = alloca i32
  %l362 = alloca { i64, ptr }
  %l365 = alloca ptr
  %l366 = alloca %"compiler/source:Span"
  %l367 = alloca ptr
  %l368 = alloca i32
  %l369 = alloca { i64, [4 x i64] }
  %l370 = alloca i32
  %l376 = alloca i32
  %l379 = alloca { i64, [4 x i64] }
  %l386 = alloca ptr
  %l387 = alloca i1
  %l403 = alloca { i64, [4 x i64] }
  %l406 = alloca i32
  %l417 = alloca ptr
  %l418 = alloca i1
  %l431 = alloca ptr
  %l432 = alloca i1
  %l439 = alloca ptr
  %l440 = alloca i1
  %l451 = alloca ptr
  %l453 = alloca %"compiler/lower:level"
  %l458 = alloca i1
  %l459 = alloca ptr
  %l462 = alloca i64
  %l464 = alloca i1
  %l466 = alloca ptr
  %l467 = alloca %"compiler/source:Span"
  %l470 = alloca i64
  %l472 = alloca ptr
  %l473 = alloca i1
  %l483 = alloca ptr
  %l484 = alloca i1
  %l494 = alloca ptr
  %l495 = alloca i1
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %t142 = alloca { i64, [21 x i64] }, align 8
  %t162 = alloca { i64, [15 x i64] }, align 8
  %t168 = alloca { i64, [21 x i64] }, align 8
  %t343 = alloca { i64, [4 x i64] }, align 8
  %t349 = alloca { i64, [15 x i64] }, align 8
  %t355 = alloca { i64, [21 x i64] }, align 8
  %t377 = alloca { i64, [15 x i64] }, align 8
  %t383 = alloca { i64, [21 x i64] }, align 8
  %t649 = alloca { i64, [4 x i64] }, align 8
  %t755 = alloca { i64, [15 x i64] }, align 8
  %t807 = alloca { i64, [4 x i64] }, align 8
  %t843 = alloca { i64, [8 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 7
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l1, !tbaa !29
  store ptr %t6, ptr %l56, !tbaa !29
  store i1 false, ptr %l57, !tbaa !21
  %t7 = load ptr, ptr %l56, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb4, label %bb5
bb4:
  %t10 = load ptr, ptr %l56, !tbaa !29
  %t11 = load i64, ptr %t10
  %t13 = icmp eq i64 %t11, 0
  store i1 %t13, ptr %l57, !tbaa !21
  br label %bb5
bb5:
  %t14 = load i1, ptr %l57, !tbaa !21
  br i1 %t14, label %bb6, label %bb7
bb6:
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t17 = getelementptr { i64, [3 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t17, i32 0, i32 0
  %t19 = load %"compiler/source:Span", ptr %t18
  store %"compiler/source:Span" %t19, ptr %l2
  %t21 = load ptr, ptr %l1, !tbaa !29
  %t23 = getelementptr { i64, [3 x i64] }, ptr %t21, i32 0, i32 1
  %t24 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t23, i32 0, i32 1
  %t25 = load i32, ptr %t24
  store i32 %t25, ptr %l3, !tbaa !23
  %t27 = load ptr, ptr %l1, !tbaa !29
  %t29 = getelementptr { i64, [3 x i64] }, ptr %t27, i32 0, i32 1
  %t30 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t29, i32 0, i32 2
  %t31 = load ptr, ptr %t30
  store ptr %t31, ptr %l4, !tbaa !29
  br label %bb8
bb7:
  br label %bb36
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/lower:lowering", ptr %t33, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !29
  %t38 = getelementptr %"compiler/typed:Body", ptr %t36, i32 0, i32 7
  %t39 = load i32, ptr %l3, !tbaa !23
  %t41 = sext i32 %t39 to i64
  %t44 = call %"compiler/typed:Local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t38, i64 %t41)
  store %"compiler/typed:Local" %t44, ptr %l71
  br label %bb9
bb9:
  %t45 = getelementptr %"compiler/typed:Local", ptr %l71, i32 0, i32 2
  %t46 = load i32, ptr %t45, !tbaa !23
  store i32 %t46, ptr %l5, !tbaa !23
  %t48 = load ptr, ptr %l0, !tbaa !29
  store ptr %t48, ptr %l73, !tbaa !29
  %t49 = load ptr, ptr %l4, !tbaa !29
  store ptr %t49, ptr %l74, !tbaa !29
  %t50 = load i32, ptr %l5, !tbaa !23
  store i32 %t50, ptr %l75, !tbaa !23
  %t51 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t51, ptr %l76
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = load i32, ptr %l3, !tbaa !23
  %t56 = call { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2estorageOf(ptr %v0, ptr %t52, i32 %t53)
  store { i64, [1 x i64] } %t56, ptr %l79
  br label %bb10
bb10:
  %t57 = load ptr, ptr %l73, !tbaa !29
  %t58 = load ptr, ptr %l74, !tbaa !29
  %t59 = load i32, ptr %l75, !tbaa !23
  %t60 = load %"compiler/source:Span", ptr %l76
  %t61 = load { i64, [1 x i64] }, ptr %l79
  %t62 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2efitAt(ptr %v0, ptr %v1, ptr %t57, ptr %t58, i32 %t59, %"compiler/source:Span" %t60, { i64, [1 x i64] } %t61)
  store { i64, [4 x i64] } %t62, ptr %l80
  br label %bb11
bb11:
  %t63 = load { i64, [4 x i64] }, ptr %l80
  store { i64, [4 x i64] } %t63, ptr %l6
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t65 = load ptr, ptr %l4, !tbaa !29
  %t66 = load i32, ptr %l5, !tbaa !23
  %t70 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2ecopiesArray(ptr %v0, ptr %v1, ptr %t64, ptr %t65, i32 %t66)
  store i1 %t70, ptr %l84
  br label %bb12
bb12:
  %t71 = load i1, ptr %l84, !tbaa !21
  br i1 %t71, label %bb13, label %bb14
bb13:
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t73 = load ptr, ptr %l4, !tbaa !29
  %t75 = load i32, ptr %l5, !tbaa !23
  %t79 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2efits(ptr %v0, ptr %v1, ptr %t72, ptr %t73, i32 %t75)
  store i1 %t79, ptr %l90
  br label %bb15
bb14:
  store i1 false, ptr %l85, !tbaa !21
  br label %bb16
bb15:
  %t80 = load i1, ptr %l90, !tbaa !21
  %t81 = xor i1 %t80, true
  store i1 %t81, ptr %l85, !tbaa !21
  br label %bb16
bb16:
  %t83 = load i1, ptr %l85, !tbaa !21
  br i1 %t83, label %bb17, label %bb18
bb17:
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t85 = load ptr, ptr %l4, !tbaa !29
  %t86 = load i32, ptr %l5, !tbaa !23
  %t90 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2ewidens(ptr %v0, ptr %v1, ptr %t84, ptr %t85, i32 %t86)
  store i1 %t90, ptr %l96
  br label %bb19
bb18:
  store i1 false, ptr %l92, !tbaa !21
  br label %bb20
bb19:
  %t91 = load i1, ptr %l96, !tbaa !21
  %t92 = xor i1 %t91, true
  store i1 %t92, ptr %l92, !tbaa !21
  br label %bb20
bb20:
  %t94 = load i1, ptr %l92, !tbaa !21
  br i1 %t94, label %bb21, label %bb22
bb21:
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t97 = getelementptr %"compiler/lower:lowering", ptr %t95, i32 0, i32 7
  %t98 = load i1, ptr %t97, !tbaa !21
  %t100 = xor i1 %t98, true
  store i1 %t100, ptr %l98, !tbaa !21
  br label %bb23
bb22:
  store i1 false, ptr %l98, !tbaa !21
  br label %bb23
bb23:
  %t102 = load i1, ptr %l98, !tbaa !21
  br i1 %t102, label %bb24, label %bb25
bb24:
  %t103 = load ptr, ptr %l0, !tbaa !29
  store ptr %t103, ptr %l102, !tbaa !29
  %t104 = load { i64, [4 x i64] }, ptr %l6
  store { i64, [4 x i64] } %t104, ptr %l103
  %t105 = load i32, ptr %l5, !tbaa !23
  store i32 %t105, ptr %l104, !tbaa !23
  %t106 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t106, ptr %l105
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t108 = load i32, ptr %l3, !tbaa !23
  %t111 = call { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2estorageOf(ptr %v0, ptr %t107, i32 %t108)
  store { i64, [1 x i64] } %t111, ptr %l108
  br label %bb26
bb25:
  br label %bb28
bb26:
  %t112 = load ptr, ptr %l102, !tbaa !29
  %t113 = load { i64, [4 x i64] }, ptr %l103
  %t114 = load i32, ptr %l104, !tbaa !23
  %t115 = load %"compiler/source:Span", ptr %l105
  %t116 = load { i64, [1 x i64] }, ptr %l108
  %t117 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2earrayCopy(ptr %v0, ptr %t112, { i64, [4 x i64] } %t113, i32 %t114, %"compiler/source:Span" %t115, { i64, [1 x i64] } %t116)
  store { i64, [4 x i64] } %t117, ptr %l109
  br label %bb27
bb27:
  %t118 = load { i64, [4 x i64] }, ptr %l109
  store { i64, [4 x i64] } %t118, ptr %l6
  br label %bb28
bb28:
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t121 = getelementptr %"compiler/lower:lowering", ptr %t119, i32 0, i32 3
  %t122 = getelementptr %"compiler/mir:Fn", ptr %t121, i32 0, i32 7
  %t123 = load i32, ptr %l3, !tbaa !23
  %t125 = sext i32 %t123 to i64
  %t128 = call %"compiler/mir:Local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aLocal_3e_2eAt_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %t122, i64 %t125)
  store %"compiler/mir:Local" %t128, ptr %l114
  br label %bb29
bb29:
  %t129 = getelementptr %"compiler/mir:Local", ptr %l114, i32 0, i32 4
  %t130 = load { i64, [1 x i64] }, ptr %t129
  %t132 = extractvalue { i64, [1 x i64] } %t130, 0
  %t133 = icmp eq i64 %t132, 3
  %t135 = xor i1 %t133, true
  br i1 %t135, label %bb30, label %bb31
bb30:
  store %olang.scope zeroinitializer, ptr %s4
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t138 = load %"compiler/source:Span", ptr %l2
  %t139 = load i32, ptr %l3, !tbaa !23
  store { i64, [21 x i64] } zeroinitializer, ptr %t142
  %t143 = getelementptr { i64, [21 x i64] }, ptr %t142, i32 0, i32 0
  store i64 1, ptr %t143
  %t145 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t138, 0
  %t147 = insertvalue { %"compiler/source:Span", i32 } %t145, i32 %t139, 1
  %t148 = getelementptr { i64, [21 x i64] }, ptr %t142, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t147, ptr %t148
  %t149 = load { i64, [21 x i64] }, ptr %t142
  %t151 = call ptr @__olang_scope_alloc_a(ptr %s4, i64 176, i64 8)
  store { i64, [21 x i64] } %t149, ptr %t151
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s4, ptr %t137, ptr %t151)
  br label %bb32
bb31:
  br label %bb33
bb32:
  call void @__olang_scope_close(ptr %s4)
  br label %bb33
bb33:
  %t154 = load ptr, ptr %l0, !tbaa !29
  store ptr %t154, ptr %l125, !tbaa !29
  %t155 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t155, ptr %l126
  %t156 = load i32, ptr %l3, !tbaa !23
  %t160 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t156)
  store %"compiler/mir:Place" %t160, ptr %l130
  br label %bb34
bb34:
  %t161 = load { i64, [4 x i64] }, ptr %l6
  store { i64, [15 x i64] } zeroinitializer, ptr %t162
  %t163 = getelementptr { i64, [15 x i64] }, ptr %t162, i32 0, i32 0
  store i64 0, ptr %t163
  %t165 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t161, 0
  %t166 = getelementptr { i64, [15 x i64] }, ptr %t162, i32 0, i32 1
  store { { i64, [4 x i64] } } %t165, ptr %t166
  %t167 = load { i64, [15 x i64] }, ptr %t162
  store { i64, [21 x i64] } zeroinitializer, ptr %t168
  %t169 = getelementptr { i64, [21 x i64] }, ptr %t168, i32 0, i32 0
  store i64 0, ptr %t169
  %t170 = load %"compiler/source:Span", ptr %l126
  %t171 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t170, 0
  %t172 = load %"compiler/mir:Place", ptr %l130
  %t173 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t171, %"compiler/mir:Place" %t172, 1
  %t175 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t173, { i64, [15 x i64] } %t167, 2
  %t176 = getelementptr { i64, [21 x i64] }, ptr %t168, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t175, ptr %t176
  %t177 = load { i64, [21 x i64] }, ptr %t168
  %t179 = call ptr @__olang_scope_alloc_a(ptr %s2, i64 176, i64 8)
  store { i64, [21 x i64] } %t177, ptr %t179
  %t180 = load ptr, ptr %l125, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s2, ptr %t180, ptr %t179)
  br label %bb35
bb35:
  call void @__olang_scope_close(ptr %s2)
  br label %bb232
bb36:
  %t182 = load ptr, ptr %l1, !tbaa !29
  store ptr %t182, ptr %l135, !tbaa !29
  store i1 false, ptr %l136, !tbaa !21
  %t183 = load ptr, ptr %l135, !tbaa !29
  %t184 = icmp ne ptr %t183, null
  br i1 %t184, label %bb37, label %bb38
bb37:
  %t186 = load ptr, ptr %l135, !tbaa !29
  %t187 = load i64, ptr %t186
  %t189 = icmp eq i64 %t187, 1
  store i1 %t189, ptr %l136, !tbaa !21
  br label %bb38
bb38:
  %t190 = load i1, ptr %l136, !tbaa !21
  br i1 %t190, label %bb39, label %bb40
bb39:
  %t191 = load ptr, ptr %l1, !tbaa !29
  %t193 = getelementptr { i64, [3 x i64] }, ptr %t191, i32 0, i32 1
  %t194 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t193, i32 0, i32 0
  %t195 = load %"compiler/source:Span", ptr %t194
  store %"compiler/source:Span" %t195, ptr %l7
  %t197 = load ptr, ptr %l1, !tbaa !29
  %t199 = getelementptr { i64, [3 x i64] }, ptr %t197, i32 0, i32 1
  %t200 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t199, i32 0, i32 1
  %t201 = load ptr, ptr %t200
  store ptr %t201, ptr %l8, !tbaa !29
  %t203 = load ptr, ptr %l1, !tbaa !29
  %t205 = getelementptr { i64, [3 x i64] }, ptr %t203, i32 0, i32 1
  %t206 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t205, i32 0, i32 2
  %t207 = load ptr, ptr %t206
  store ptr %t207, ptr %l9, !tbaa !29
  br label %bb41
bb40:
  br label %bb84
bb41:
  %t209 = load ptr, ptr %l0, !tbaa !29
  %t210 = load ptr, ptr %l8, !tbaa !29
  %t214 = call %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2eplace(ptr %v0, ptr %v1, ptr %v0, ptr %t209, ptr %t210)
  store %"compiler/lower:pl" %t214, ptr %l148
  br label %bb42
bb42:
  %t215 = load %"compiler/lower:pl", ptr %l148
  store %"compiler/lower:pl" %t215, ptr %l10
  %t216 = load ptr, ptr %l0, !tbaa !29
  %t218 = getelementptr %"compiler/lower:lowering", ptr %t216, i32 0, i32 15
  %t219 = load %"compiler/lower:pl", ptr %l10
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3apl_3e_2ePush_3ccompiler_2flower_3apl_3e(ptr %v0, ptr %v0, ptr %t218, %"compiler/lower:pl" %t219)
  br label %bb43
bb43:
  %t222 = load ptr, ptr %l0, !tbaa !29
  store ptr %t222, ptr %l152, !tbaa !29
  %t223 = load ptr, ptr %l0, !tbaa !29
  %t224 = load ptr, ptr %l9, !tbaa !29
  %t228 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v1, ptr %t223, ptr %t224)
  store { i64, [4 x i64] } %t228, ptr %l156
  br label %bb44
bb44:
  %t229 = load ptr, ptr %l9, !tbaa !29
  store ptr %t229, ptr %l158, !tbaa !29
  %t231 = load ptr, ptr %l8, !tbaa !29
  %t233 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aPlace_2eType(ptr %v1, ptr %t231)
  store i32 %t233, ptr %l160
  br label %bb45
bb45:
  %t234 = load %"compiler/source:Span", ptr %l7
  %t235 = load ptr, ptr %l152, !tbaa !29
  %t236 = load { i64, [4 x i64] }, ptr %l156
  %t237 = load ptr, ptr %l158, !tbaa !29
  %t238 = load i32, ptr %l160, !tbaa !23
  %t240 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2efit(ptr %v0, ptr %v1, ptr %t235, { i64, [4 x i64] } %t236, ptr %t237, i32 %t238, %"compiler/source:Span" %t234)
  store { i64, [4 x i64] } %t240, ptr %l162
  br label %bb46
bb46:
  %t241 = load { i64, [4 x i64] }, ptr %l162
  store { i64, [4 x i64] } %t241, ptr %l11
  %t242 = load ptr, ptr %l0, !tbaa !29
  %t244 = getelementptr %"compiler/lower:lowering", ptr %t242, i32 0, i32 15
  %t246 = call { i32, %"compiler/lower:pl" } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3apl_3e_2ePop_3ccompiler_2flower_3apl_3e(ptr %v0, ptr %v0, ptr %t244)
  %t247 = extractvalue { i32, %"compiler/lower:pl" } %t246, 1
  %t248 = extractvalue { i32, %"compiler/lower:pl" } %t246, 0
  store i32 %t248, ptr %l167
  %t249 = icmp ne i32 %t248, 0
  br i1 %t249, label %bb48, label %ok.250
ok.250:
  store %"compiler/lower:pl" %t247, ptr %l166
  br label %bb47
bb47:
  %t251 = load %"compiler/lower:pl", ptr %l166
  store %"compiler/lower:pl" %t251, ptr %l163
  br label %bb50
bb48:
  br label %bb49
bb49:
  call void @__olang_ert_req_clear()
  br label %bb50
bb50:
  %t252 = load ptr, ptr %l0, !tbaa !29
  store ptr %t252, ptr %l168, !tbaa !29
  %t253 = load ptr, ptr %l8, !tbaa !29
  %t255 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aPlace_2eType(ptr %v1, ptr %t253)
  store i32 %t255, ptr %l170
  br label %bb51
bb51:
  %t256 = load ptr, ptr %l168, !tbaa !29
  %t257 = load i32, ptr %l170, !tbaa !23
  %t258 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2evalueArray(ptr %v0, ptr %t256, i32 %t257)
  store i1 %t258, ptr %l171
  br label %bb52
bb52:
  %t259 = load i1, ptr %l171, !tbaa !21
  br i1 %t259, label %bb53, label %bb54
bb53:
  %t260 = load ptr, ptr %l0, !tbaa !29
  %t262 = getelementptr %"compiler/lower:lowering", ptr %t260, i32 0, i32 7
  %t263 = load i1, ptr %t262, !tbaa !21
  %t265 = xor i1 %t263, true
  store i1 %t265, ptr %l172, !tbaa !21
  br label %bb55
bb54:
  store i1 false, ptr %l172, !tbaa !21
  br label %bb55
bb55:
  %t267 = load i1, ptr %l172, !tbaa !21
  br i1 %t267, label %bb56, label %bb57
bb56:
  %t268 = load ptr, ptr %l0, !tbaa !29
  store ptr %t268, ptr %l176, !tbaa !29
  %t269 = load ptr, ptr %l9, !tbaa !29
  store ptr %t269, ptr %l177, !tbaa !29
  %t270 = load ptr, ptr %l8, !tbaa !29
  %t272 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aPlace_2eType(ptr %v1, ptr %t270)
  store i32 %t272, ptr %l179
  br label %bb58
bb57:
  store %olang.scope zeroinitializer, ptr %s8
  %t273 = load ptr, ptr %l0, !tbaa !29
  %t274 = load ptr, ptr %l8, !tbaa !29
  %t277 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2flower_2ecompiler_2flower_3alowering_2ereleases(ptr %v0, ptr %v1, ptr %s8, ptr %t273, ptr %t274, i1 true)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t277, ptr %l195
  br label %bb64
bb58:
  %t278 = load ptr, ptr %l176, !tbaa !29
  %t279 = load ptr, ptr %l177, !tbaa !29
  %t280 = load i32, ptr %l179, !tbaa !23
  %t281 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2ecopiesArray(ptr %v0, ptr %v1, ptr %t278, ptr %t279, i32 %t280)
  store i1 %t281, ptr %l180
  br label %bb59
bb59:
  %t282 = load i1, ptr %l180, !tbaa !21
  store i1 %t282, ptr %l12, !tbaa !21
  %t283 = load ptr, ptr %l0, !tbaa !29
  store ptr %t283, ptr %l181, !tbaa !29
  %t284 = load ptr, ptr %l0, !tbaa !29
  %t285 = load %"compiler/lower:pl", ptr %l10
  %t288 = call %"compiler/mir:Place" @compiler_2flower_2ecompiler_2flower_3alowering_2emk(ptr %v0, ptr %v0, ptr %t284, %"compiler/lower:pl" %t285)
  store %"compiler/mir:Place" %t288, ptr %l184
  br label %bb60
bb60:
  %t289 = load { i64, [4 x i64] }, ptr %l11
  store { i64, [4 x i64] } %t289, ptr %l185
  %t290 = load ptr, ptr %l8, !tbaa !29
  %t292 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aPlace_2eType(ptr %v1, ptr %t290)
  store i32 %t292, ptr %l187
  br label %bb61
bb61:
  %t293 = load i1, ptr %l12, !tbaa !21
  store i1 %t293, ptr %l188, !tbaa !21
  %t294 = load %"compiler/source:Span", ptr %l7
  store %"compiler/source:Span" %t294, ptr %l189
  %t295 = load ptr, ptr %l0, !tbaa !29
  %t296 = load ptr, ptr %l8, !tbaa !29
  %t299 = call { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eplaceStorage(ptr %v0, ptr %v1, ptr %t295, ptr %t296)
  store { i64, [1 x i64] } %t299, ptr %l192
  br label %bb62
bb62:
  %t300 = load ptr, ptr %l181, !tbaa !29
  %t301 = load %"compiler/mir:Place", ptr %l184
  %t302 = load { i64, [4 x i64] }, ptr %l185
  %t303 = load i32, ptr %l187, !tbaa !23
  %t304 = load i1, ptr %l188, !tbaa !21
  %t305 = load %"compiler/source:Span", ptr %l189
  %t306 = load { i64, [1 x i64] }, ptr %l192
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2earrayStore(ptr %v0, ptr %t300, %"compiler/mir:Place" %t301, { i64, [4 x i64] } %t302, i32 %t303, i1 %t304, %"compiler/source:Span" %t305, { i64, [1 x i64] } %t306)
  br label %bb63
bb63:
  br label %bb83
bb64:
  %t307 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l195
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t307, ptr %l13
  %t308 = load i32, ptr @G_2ecompiler_2fmir_2eNoLocal, !tbaa !23
  store i32 %t308, ptr %l14, !tbaa !23
  %t311 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3cI64_3e_26_3e_2eLen_3cArray_3cI64_3e_26_3e(ptr %s8, ptr %l13)
  store i64 %t311, ptr %l198
  br label %bb65
bb65:
  %t312 = load i64, ptr %l198, !tbaa !24
  %t313 = icmp sgt i64 %t312, 0
  br i1 %t313, label %bb66, label %bb67
bb66:
  %t315 = load ptr, ptr %l0, !tbaa !29
  %t317 = getelementptr %"compiler/lower:lowering", ptr %t315, i32 0, i32 7
  %t318 = load i1, ptr %t317, !tbaa !21
  %t320 = xor i1 %t318, true
  store i1 %t320, ptr %l200, !tbaa !21
  br label %bb68
bb67:
  store i1 false, ptr %l200, !tbaa !21
  br label %bb68
bb68:
  %t322 = load i1, ptr %l200, !tbaa !21
  br i1 %t322, label %bb69, label %bb70
bb69:
  store %olang.scope zeroinitializer, ptr %s9
  %t323 = load ptr, ptr %l0, !tbaa !29
  store ptr %t323, ptr %l204, !tbaa !29
  %t324 = load ptr, ptr %l8, !tbaa !29
  %t326 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aPlace_2eType(ptr %v1, ptr %t324)
  store i32 %t326, ptr %l206
  br label %bb71
bb70:
  br label %bb76
bb71:
  %t327 = load %"compiler/source:Span", ptr %l7
  %t328 = load ptr, ptr %l204, !tbaa !29
  %t329 = load i32, ptr %l206, !tbaa !23
  %t331 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2etemp(ptr %v0, ptr %t328, i32 %t329, %"compiler/source:Span" %t327)
  store i32 %t331, ptr %l208
  br label %bb72
bb72:
  %t332 = load i32, ptr %l208, !tbaa !23
  store i32 %t332, ptr %l14, !tbaa !23
  %t333 = load ptr, ptr %l0, !tbaa !29
  store ptr %t333, ptr %l209, !tbaa !29
  %t334 = load %"compiler/source:Span", ptr %l7
  store %"compiler/source:Span" %t334, ptr %l210
  %t335 = load i32, ptr %l14, !tbaa !23
  %t337 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t335)
  store %"compiler/mir:Place" %t337, ptr %l212
  br label %bb73
bb73:
  %t338 = load ptr, ptr %l0, !tbaa !29
  %t339 = load %"compiler/lower:pl", ptr %l10
  %t342 = call %"compiler/mir:Place" @compiler_2flower_2ecompiler_2flower_3alowering_2emk(ptr %v0, ptr %v0, ptr %t338, %"compiler/lower:pl" %t339)
  store %"compiler/mir:Place" %t342, ptr %l215
  br label %bb74
bb74:
  store { i64, [4 x i64] } zeroinitializer, ptr %t343
  %t344 = getelementptr { i64, [4 x i64] }, ptr %t343, i32 0, i32 0
  store i64 1, ptr %t344
  %t345 = load %"compiler/mir:Place", ptr %l215
  %t346 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t345, 0
  %t347 = getelementptr { i64, [4 x i64] }, ptr %t343, i32 0, i32 1
  store { %"compiler/mir:Place" } %t346, ptr %t347
  %t348 = load { i64, [4 x i64] }, ptr %t343
  store { i64, [15 x i64] } zeroinitializer, ptr %t349
  %t350 = getelementptr { i64, [15 x i64] }, ptr %t349, i32 0, i32 0
  store i64 0, ptr %t350
  %t352 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t348, 0
  %t353 = getelementptr { i64, [15 x i64] }, ptr %t349, i32 0, i32 1
  store { { i64, [4 x i64] } } %t352, ptr %t353
  %t354 = load { i64, [15 x i64] }, ptr %t349
  store { i64, [21 x i64] } zeroinitializer, ptr %t355
  %t356 = getelementptr { i64, [21 x i64] }, ptr %t355, i32 0, i32 0
  store i64 0, ptr %t356
  %t357 = load %"compiler/source:Span", ptr %l210
  %t358 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t357, 0
  %t359 = load %"compiler/mir:Place", ptr %l212
  %t360 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t358, %"compiler/mir:Place" %t359, 1
  %t362 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t360, { i64, [15 x i64] } %t354, 2
  %t363 = getelementptr { i64, [21 x i64] }, ptr %t355, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t362, ptr %t363
  %t364 = load { i64, [21 x i64] }, ptr %t355
  %t366 = call ptr @__olang_scope_alloc_a(ptr %s9, i64 176, i64 8)
  store { i64, [21 x i64] } %t364, ptr %t366
  %t367 = load ptr, ptr %l209, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s9, ptr %t367, ptr %t366)
  br label %bb75
bb75:
  call void @__olang_scope_close(ptr %s9)
  br label %bb76
bb76:
  %t369 = load ptr, ptr %l0, !tbaa !29
  store ptr %t369, ptr %l220, !tbaa !29
  %t370 = load %"compiler/source:Span", ptr %l7
  store %"compiler/source:Span" %t370, ptr %l221
  %t371 = load ptr, ptr %l0, !tbaa !29
  %t372 = load %"compiler/lower:pl", ptr %l10
  %t375 = call %"compiler/mir:Place" @compiler_2flower_2ecompiler_2flower_3alowering_2emk(ptr %v0, ptr %v0, ptr %t371, %"compiler/lower:pl" %t372)
  store %"compiler/mir:Place" %t375, ptr %l224
  br label %bb77
bb77:
  %t376 = load { i64, [4 x i64] }, ptr %l11
  store { i64, [15 x i64] } zeroinitializer, ptr %t377
  %t378 = getelementptr { i64, [15 x i64] }, ptr %t377, i32 0, i32 0
  store i64 0, ptr %t378
  %t380 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t376, 0
  %t381 = getelementptr { i64, [15 x i64] }, ptr %t377, i32 0, i32 1
  store { { i64, [4 x i64] } } %t380, ptr %t381
  %t382 = load { i64, [15 x i64] }, ptr %t377
  store { i64, [21 x i64] } zeroinitializer, ptr %t383
  %t384 = getelementptr { i64, [21 x i64] }, ptr %t383, i32 0, i32 0
  store i64 0, ptr %t384
  %t385 = load %"compiler/source:Span", ptr %l221
  %t386 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t385, 0
  %t387 = load %"compiler/mir:Place", ptr %l224
  %t388 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t386, %"compiler/mir:Place" %t387, 1
  %t390 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t388, { i64, [15 x i64] } %t382, 2
  %t391 = getelementptr { i64, [21 x i64] }, ptr %t383, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t390, ptr %t391
  %t392 = load { i64, [21 x i64] }, ptr %t383
  %t394 = call ptr @__olang_scope_alloc_a(ptr %s8, i64 176, i64 8)
  store { i64, [21 x i64] } %t392, ptr %t394
  %t395 = load ptr, ptr %l220, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s8, ptr %t395, ptr %t394)
  br label %bb78
bb78:
  %t397 = load i32, ptr %l14, !tbaa !23
  %t398 = load i32, ptr @G_2ecompiler_2fmir_2eNoLocal, !tbaa !23
  %t401 = icmp ne i32 %t397, %t398
  br i1 %t401, label %bb79, label %bb80
bb79:
  %t403 = load ptr, ptr %l0, !tbaa !29
  %t404 = load i32, ptr %l14, !tbaa !23
  %t405 = load %"compiler/source:Span", ptr %l7
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2ereleaseAt(ptr %v0, ptr %s8, ptr %t403, i32 %t404, ptr %l13, %"compiler/source:Span" %t405)
  br label %bb81
bb80:
  br label %bb82
bb81:
  br label %bb82
bb82:
  call void @__olang_scope_close(ptr %s8)
  br label %bb83
bb83:
  br label %bb232
bb84:
  %t410 = load ptr, ptr %l1, !tbaa !29
  store ptr %t410, ptr %l236, !tbaa !29
  store i1 false, ptr %l237, !tbaa !21
  %t411 = load ptr, ptr %l236, !tbaa !29
  %t412 = icmp ne ptr %t411, null
  br i1 %t412, label %bb85, label %bb86
bb85:
  %t414 = load ptr, ptr %l236, !tbaa !29
  %t415 = load i64, ptr %t414
  %t417 = icmp eq i64 %t415, 2
  store i1 %t417, ptr %l237, !tbaa !21
  br label %bb86
bb86:
  %t418 = load i1, ptr %l237, !tbaa !21
  br i1 %t418, label %bb87, label %bb88
bb87:
  %t419 = load ptr, ptr %l1, !tbaa !29
  %t421 = getelementptr { i64, [3 x i64] }, ptr %t419, i32 0, i32 1
  %t422 = getelementptr { %"compiler/source:Span", ptr }, ptr %t421, i32 0, i32 0
  %t423 = load %"compiler/source:Span", ptr %t422
  store %"compiler/source:Span" %t423, ptr %l15
  %t425 = load ptr, ptr %l1, !tbaa !29
  %t427 = getelementptr { i64, [3 x i64] }, ptr %t425, i32 0, i32 1
  %t428 = getelementptr { %"compiler/source:Span", ptr }, ptr %t427, i32 0, i32 1
  %t429 = load ptr, ptr %t428
  store ptr %t429, ptr %l16, !tbaa !29
  br label %bb89
bb88:
  br label %bb91
bb89:
  %t431 = load ptr, ptr %l0, !tbaa !29
  %t432 = load %"compiler/source:Span", ptr %l15
  %t433 = load ptr, ptr %l16, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eevalStmt(ptr %v0, ptr %v1, ptr %t431, %"compiler/source:Span" %t432, ptr %t433)
  br label %bb90
bb90:
  br label %bb232
bb91:
  %t437 = load ptr, ptr %l1, !tbaa !29
  store ptr %t437, ptr %l247, !tbaa !29
  store i1 false, ptr %l248, !tbaa !21
  %t438 = load ptr, ptr %l247, !tbaa !29
  %t439 = icmp ne ptr %t438, null
  br i1 %t439, label %bb92, label %bb93
bb92:
  %t441 = load ptr, ptr %l247, !tbaa !29
  %t442 = load i64, ptr %t441
  %t444 = icmp eq i64 %t442, 16
  store i1 %t444, ptr %l248, !tbaa !21
  br label %bb93
bb93:
  %t445 = load i1, ptr %l248, !tbaa !21
  br i1 %t445, label %bb94, label %bb95
bb94:
  %t446 = load ptr, ptr %l1, !tbaa !29
  %t448 = getelementptr { i64, [3 x i64] }, ptr %t446, i32 0, i32 1
  %t449 = getelementptr { %"compiler/source:Span", ptr }, ptr %t448, i32 0, i32 0
  %t450 = load %"compiler/source:Span", ptr %t449
  store %"compiler/source:Span" %t450, ptr %l17
  %t452 = load ptr, ptr %l1, !tbaa !29
  %t454 = getelementptr { i64, [3 x i64] }, ptr %t452, i32 0, i32 1
  %t455 = getelementptr { %"compiler/source:Span", ptr }, ptr %t454, i32 0, i32 1
  %t456 = load ptr, ptr %t455
  store ptr %t456, ptr %l18, !tbaa !29
  br label %bb96
bb95:
  br label %bb101
bb96:
  %t458 = load ptr, ptr %l0, !tbaa !29
  store ptr %t458, ptr %l255, !tbaa !29
  %t459 = load %"compiler/source:Span", ptr %l17
  store %"compiler/source:Span" %t459, ptr %l256
  %t460 = load ptr, ptr %l18, !tbaa !29
  %t462 = icmp eq ptr %t460, null
  br i1 %t462, label %bb97, label %bb98
bb97:
  call void @__olang_check_failed(ptr @olang_loc_54f6f20918e68778_2b66c13484f447b4)
  unreachable
bb98:
  br label %bb99
bb99:
  %t464 = load ptr, ptr %l18, !tbaa !29
  %t465 = load ptr, ptr %l255, !tbaa !29
  %t466 = load %"compiler/source:Span", ptr %l256
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2esuspend(ptr %v0, ptr %v1, ptr %t465, %"compiler/source:Span" %t466, ptr %t464)
  br label %bb100
bb100:
  br label %bb232
bb101:
  %t468 = load ptr, ptr %l1, !tbaa !29
  store ptr %t468, ptr %l260, !tbaa !29
  store i1 false, ptr %l261, !tbaa !21
  %t469 = load ptr, ptr %l260, !tbaa !29
  %t470 = icmp ne ptr %t469, null
  br i1 %t470, label %bb102, label %bb103
bb102:
  %t472 = load ptr, ptr %l260, !tbaa !29
  %t473 = load i64, ptr %t472
  %t475 = icmp eq i64 %t473, 3
  store i1 %t475, ptr %l261, !tbaa !21
  br label %bb103
bb103:
  %t476 = load i1, ptr %l261, !tbaa !21
  br i1 %t476, label %bb104, label %bb105
bb104:
  %t477 = load ptr, ptr %l1, !tbaa !29
  %t479 = getelementptr { i64, [3 x i64] }, ptr %t477, i32 0, i32 1
  %t480 = getelementptr { %"compiler/source:Span", ptr }, ptr %t479, i32 0, i32 0
  %t481 = load %"compiler/source:Span", ptr %t480
  store %"compiler/source:Span" %t481, ptr %l19
  %t483 = load ptr, ptr %l1, !tbaa !29
  %t485 = getelementptr { i64, [3 x i64] }, ptr %t483, i32 0, i32 1
  %t486 = getelementptr { %"compiler/source:Span", ptr }, ptr %t485, i32 0, i32 1
  %t487 = load ptr, ptr %t486
  store ptr %t487, ptr %l20, !tbaa !29
  br label %bb106
bb105:
  br label %bb108
bb106:
  %t489 = load ptr, ptr %l0, !tbaa !29
  %t490 = load %"compiler/source:Span", ptr %l19
  %t491 = load ptr, ptr %l20, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eifStmt(ptr %v0, ptr %v1, ptr %t489, %"compiler/source:Span" %t490, ptr %t491)
  br label %bb107
bb107:
  br label %bb232
bb108:
  %t495 = load ptr, ptr %l1, !tbaa !29
  store ptr %t495, ptr %l271, !tbaa !29
  store i1 false, ptr %l272, !tbaa !21
  %t496 = load ptr, ptr %l271, !tbaa !29
  %t497 = icmp ne ptr %t496, null
  br i1 %t497, label %bb109, label %bb110
bb109:
  %t499 = load ptr, ptr %l271, !tbaa !29
  %t500 = load i64, ptr %t499
  %t502 = icmp eq i64 %t500, 4
  store i1 %t502, ptr %l272, !tbaa !21
  br label %bb110
bb110:
  %t503 = load i1, ptr %l272, !tbaa !21
  br i1 %t503, label %bb111, label %bb112
bb111:
  %t504 = load ptr, ptr %l1, !tbaa !29
  %t506 = getelementptr { i64, [3 x i64] }, ptr %t504, i32 0, i32 1
  %t507 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t506, i32 0, i32 0
  %t508 = load %"compiler/source:Span", ptr %t507
  store %"compiler/source:Span" %t508, ptr %l21
  %t510 = load ptr, ptr %l1, !tbaa !29
  %t512 = getelementptr { i64, [3 x i64] }, ptr %t510, i32 0, i32 1
  %t513 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t512, i32 0, i32 1
  %t514 = load ptr, ptr %t513
  store ptr %t514, ptr %l22, !tbaa !29
  %t516 = load ptr, ptr %l1, !tbaa !29
  %t518 = getelementptr { i64, [3 x i64] }, ptr %t516, i32 0, i32 1
  %t519 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t518, i32 0, i32 2
  %t520 = load ptr, ptr %t519
  store ptr %t520, ptr %l23, !tbaa !29
  br label %bb113
bb112:
  br label %bb115
bb113:
  %t522 = load ptr, ptr %l0, !tbaa !29
  %t523 = load %"compiler/source:Span", ptr %l21
  %t524 = load ptr, ptr %l22, !tbaa !29
  %t525 = load ptr, ptr %l23, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eloop(ptr %v0, ptr %v1, ptr %v1, ptr %t522, %"compiler/source:Span" %t523, ptr %t524, ptr %t525)
  br label %bb114
bb114:
  br label %bb232
bb115:
  %t530 = load ptr, ptr %l1, !tbaa !29
  store ptr %t530, ptr %l285, !tbaa !29
  store i1 false, ptr %l286, !tbaa !21
  %t531 = load ptr, ptr %l285, !tbaa !29
  %t532 = icmp ne ptr %t531, null
  br i1 %t532, label %bb116, label %bb117
bb116:
  %t534 = load ptr, ptr %l285, !tbaa !29
  %t535 = load i64, ptr %t534
  %t537 = icmp eq i64 %t535, 5
  store i1 %t537, ptr %l286, !tbaa !21
  br label %bb117
bb117:
  %t538 = load i1, ptr %l286, !tbaa !21
  br i1 %t538, label %bb118, label %bb119
bb118:
  %t539 = load ptr, ptr %l1, !tbaa !29
  %t541 = getelementptr { i64, [3 x i64] }, ptr %t539, i32 0, i32 1
  %t542 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t541, i32 0, i32 0
  %t543 = load %"compiler/source:Span", ptr %t542
  store %"compiler/source:Span" %t543, ptr %l24
  %t545 = load ptr, ptr %l1, !tbaa !29
  %t547 = getelementptr { i64, [3 x i64] }, ptr %t545, i32 0, i32 1
  %t548 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t547, i32 0, i32 1
  %t549 = load i32, ptr %t548
  store i32 %t549, ptr %l25
  %t551 = load ptr, ptr %l1, !tbaa !29
  %t553 = getelementptr { i64, [3 x i64] }, ptr %t551, i32 0, i32 1
  %t554 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t553, i32 0, i32 2
  %t555 = load i32, ptr %t554
  store i32 %t555, ptr %l26, !tbaa !23
  br label %bb120
bb119:
  br label %bb122
bb120:
  %t557 = load ptr, ptr %l0, !tbaa !29
  %t558 = load %"compiler/source:Span", ptr %l24
  %t559 = load i32, ptr %l25
  %t560 = load i32, ptr %l26, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2ejump(ptr %v0, ptr %t557, %"compiler/source:Span" %t558, i32 %t559, i32 %t560)
  br label %bb121
bb121:
  br label %bb232
bb122:
  %t565 = load ptr, ptr %l1, !tbaa !29
  store ptr %t565, ptr %l299, !tbaa !29
  store i1 false, ptr %l300, !tbaa !21
  %t566 = load ptr, ptr %l299, !tbaa !29
  %t567 = icmp ne ptr %t566, null
  br i1 %t567, label %bb123, label %bb124
bb123:
  %t569 = load ptr, ptr %l299, !tbaa !29
  %t570 = load i64, ptr %t569
  %t572 = icmp eq i64 %t570, 6
  store i1 %t572, ptr %l300, !tbaa !21
  br label %bb124
bb124:
  %t573 = load i1, ptr %l300, !tbaa !21
  br i1 %t573, label %bb125, label %bb126
bb125:
  %t574 = load ptr, ptr %l1, !tbaa !29
  %t576 = getelementptr { i64, [3 x i64] }, ptr %t574, i32 0, i32 1
  %t577 = getelementptr { %"compiler/source:Span", ptr }, ptr %t576, i32 0, i32 0
  %t578 = load %"compiler/source:Span", ptr %t577
  store %"compiler/source:Span" %t578, ptr %l27
  %t580 = load ptr, ptr %l1, !tbaa !29
  %t582 = getelementptr { i64, [3 x i64] }, ptr %t580, i32 0, i32 1
  %t583 = getelementptr { %"compiler/source:Span", ptr }, ptr %t582, i32 0, i32 1
  %t584 = load ptr, ptr %t583
  store ptr %t584, ptr %l28, !tbaa !29
  br label %bb127
bb126:
  br label %bb129
bb127:
  %t586 = load ptr, ptr %l0, !tbaa !29
  %t587 = load %"compiler/source:Span", ptr %l27
  %t588 = load ptr, ptr %l28, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eret(ptr %v0, ptr %v1, ptr %t586, %"compiler/source:Span" %t587, ptr %t588)
  br label %bb128
bb128:
  br label %bb232
bb129:
  %t592 = load ptr, ptr %l1, !tbaa !29
  store ptr %t592, ptr %l310, !tbaa !29
  store i1 false, ptr %l311, !tbaa !21
  %t593 = load ptr, ptr %l310, !tbaa !29
  %t594 = icmp ne ptr %t593, null
  br i1 %t594, label %bb130, label %bb131
bb130:
  %t596 = load ptr, ptr %l310, !tbaa !29
  %t597 = load i64, ptr %t596
  %t599 = icmp eq i64 %t597, 7
  store i1 %t599, ptr %l311, !tbaa !21
  br label %bb131
bb131:
  %t600 = load i1, ptr %l311, !tbaa !21
  br i1 %t600, label %bb132, label %bb133
bb132:
  %t601 = load ptr, ptr %l1, !tbaa !29
  %t603 = getelementptr { i64, [3 x i64] }, ptr %t601, i32 0, i32 1
  %t604 = getelementptr { %"compiler/source:Span", i32, i64 }, ptr %t603, i32 0, i32 0
  %t605 = load %"compiler/source:Span", ptr %t604
  store %"compiler/source:Span" %t605, ptr %l29
  %t607 = load ptr, ptr %l1, !tbaa !29
  %t609 = getelementptr { i64, [3 x i64] }, ptr %t607, i32 0, i32 1
  %t610 = getelementptr { %"compiler/source:Span", i32, i64 }, ptr %t609, i32 0, i32 1
  %t611 = load i32, ptr %t610
  store i32 %t611, ptr %l30, !tbaa !23
  %t613 = load ptr, ptr %l1, !tbaa !29
  %t615 = getelementptr { i64, [3 x i64] }, ptr %t613, i32 0, i32 1
  %t616 = getelementptr { %"compiler/source:Span", i32, i64 }, ptr %t615, i32 0, i32 2
  %t617 = load i64, ptr %t616
  store i64 %t617, ptr %l31, !tbaa !24
  br label %bb134
bb133:
  br label %bb138
bb134:
  %t619 = load ptr, ptr %l0, !tbaa !29
  %t621 = getelementptr %"compiler/lower:lowering", ptr %t619, i32 0, i32 2
  %t622 = load ptr, ptr %t621, !tbaa !29
  store ptr %t622, ptr %l321, !tbaa !29
  %t623 = load ptr, ptr %l0, !tbaa !29
  %t625 = getelementptr %"compiler/lower:lowering", ptr %t623, i32 0, i32 2
  %t626 = load ptr, ptr %t625, !tbaa !29
  %t627 = load ptr, ptr %l0, !tbaa !29
  %t629 = getelementptr %"compiler/lower:lowering", ptr %t627, i32 0, i32 1
  %t630 = load ptr, ptr %t629, !tbaa !29
  %t632 = getelementptr %"compiler/typed:Body", ptr %t630, i32 0, i32 2
  %t633 = load i32, ptr %t632, !tbaa !23
  %t636 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t626, i32 %t633)
  store i32 %t636, ptr %l327
  br label %bb135
bb135:
  %t637 = load i32, ptr %l30, !tbaa !23
  %t638 = load i64, ptr %l31, !tbaa !24
  %t639 = load ptr, ptr %l321, !tbaa !29
  %t640 = load i32, ptr %l327, !tbaa !23
  %t643 = call i64 @compiler_2fmir_2eErrorCode(ptr %v0, ptr %t639, i32 %t640, i32 %t637, i64 %t638)
  store i64 %t643, ptr %l330
  br label %bb136
bb136:
  %t644 = load i64, ptr %l330, !tbaa !24
  %t645 = load ptr, ptr %l0, !tbaa !29
  %t646 = load %"compiler/source:Span", ptr %l29
  %t647 = load i32, ptr @G_2ecompiler_2fmir_2eI32T, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t649
  %t650 = getelementptr { i64, [4 x i64] }, ptr %t649, i32 0, i32 0
  store i64 2, ptr %t650
  %t652 = insertvalue { i32, i64 } undef, i32 %t647, 0
  %t654 = insertvalue { i32, i64 } %t652, i64 %t644, 1
  %t655 = getelementptr { i64, [4 x i64] }, ptr %t649, i32 0, i32 1
  store { i32, i64 } %t654, ptr %t655
  %t656 = load { i64, [4 x i64] }, ptr %t649
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eraise(ptr %v0, ptr %t645, %"compiler/source:Span" %t646, { i64, [4 x i64] } %t656)
  br label %bb137
bb137:
  br label %bb232
bb138:
  %t660 = load ptr, ptr %l1, !tbaa !29
  store ptr %t660, ptr %l336, !tbaa !29
  store i1 false, ptr %l337, !tbaa !21
  %t661 = load ptr, ptr %l336, !tbaa !29
  %t662 = icmp ne ptr %t661, null
  br i1 %t662, label %bb139, label %bb140
bb139:
  %t664 = load ptr, ptr %l336, !tbaa !29
  %t665 = load i64, ptr %t664
  %t667 = icmp eq i64 %t665, 8
  store i1 %t667, ptr %l337, !tbaa !21
  br label %bb140
bb140:
  %t668 = load i1, ptr %l337, !tbaa !21
  br i1 %t668, label %bb141, label %bb142
bb141:
  %t669 = load ptr, ptr %l1, !tbaa !29
  %t671 = getelementptr { i64, [3 x i64] }, ptr %t669, i32 0, i32 1
  %t672 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t671, i32 0, i32 0
  %t673 = load %"compiler/source:Span", ptr %t672
  store %"compiler/source:Span" %t673, ptr %l33
  %t675 = load ptr, ptr %l1, !tbaa !29
  %t677 = getelementptr { i64, [3 x i64] }, ptr %t675, i32 0, i32 1
  %t678 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t677, i32 0, i32 1
  %t679 = load ptr, ptr %t678
  store ptr %t679, ptr %l34, !tbaa !29
  %t681 = load ptr, ptr %l1, !tbaa !29
  %t683 = getelementptr { i64, [3 x i64] }, ptr %t681, i32 0, i32 1
  %t684 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t683, i32 0, i32 2
  %t685 = load i32, ptr %t684
  store i32 %t685, ptr %l35, !tbaa !23
  br label %bb143
bb142:
  br label %bb160
bb143:
  %t687 = load ptr, ptr %l0, !tbaa !29
  %t688 = load ptr, ptr %l34, !tbaa !29
  %t692 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v1, ptr %t687, ptr %t688)
  store { i64, [4 x i64] } %t692, ptr %l349
  br label %bb144
bb144:
  %t693 = load { i64, [4 x i64] }, ptr %l349
  store { i64, [4 x i64] } %t693, ptr %l36
  %t694 = load ptr, ptr %l0, !tbaa !29
  %t696 = getelementptr %"compiler/lower:lowering", ptr %t694, i32 0, i32 7
  %t697 = load i1, ptr %t696, !tbaa !21
  %t699 = xor i1 %t697, true
  br i1 %t699, label %bb145, label %bb146
bb145:
  %t701 = load ptr, ptr %l0, !tbaa !29
  %t703 = getelementptr %"compiler/lower:lowering", ptr %t701, i32 0, i32 2
  %t704 = load ptr, ptr %t703, !tbaa !29
  store ptr %t704, ptr %l355, !tbaa !29
  %t705 = load ptr, ptr %l0, !tbaa !29
  %t707 = getelementptr %"compiler/lower:lowering", ptr %t705, i32 0, i32 2
  %t708 = load ptr, ptr %t707, !tbaa !29
  %t709 = load ptr, ptr %l0, !tbaa !29
  %t711 = getelementptr %"compiler/lower:lowering", ptr %t709, i32 0, i32 1
  %t712 = load ptr, ptr %t711, !tbaa !29
  %t714 = getelementptr %"compiler/typed:Body", ptr %t712, i32 0, i32 2
  %t715 = load i32, ptr %t714, !tbaa !23
  %t718 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t708, i32 %t715)
  store i32 %t718, ptr %l361
  br label %bb147
bb146:
  store i1 false, ptr %l353, !tbaa !21
  br label %bb149
bb147:
  %t719 = load ptr, ptr %l355, !tbaa !29
  %t720 = load i32, ptr %l361, !tbaa !23
  %t721 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t719, i32 %t720)
  store { i64, ptr } %t721, ptr %l362
  br label %bb148
bb148:
  %t722 = load { i64, ptr }, ptr %l362, !tbaa !27
  %t723 = extractvalue { i64, ptr } %t722, 0
  %t725 = icmp sgt i64 %t723, 0
  store i1 %t725, ptr %l353, !tbaa !21
  br label %bb149
bb149:
  %t727 = load i1, ptr %l353, !tbaa !21
  br i1 %t727, label %bb150, label %bb151
bb150:
  %t728 = load ptr, ptr %l0, !tbaa !29
  store ptr %t728, ptr %l365, !tbaa !29
  %t729 = load %"compiler/source:Span", ptr %l33
  store %"compiler/source:Span" %t729, ptr %l366
  %t730 = load ptr, ptr %l0, !tbaa !29
  store ptr %t730, ptr %l367, !tbaa !29
  %t731 = load i32, ptr @G_2ecompiler_2fmir_2eI32T, !tbaa !23
  store i32 %t731, ptr %l368, !tbaa !23
  %t732 = load { i64, [4 x i64] }, ptr %l36
  store { i64, [4 x i64] } %t732, ptr %l369
  %t733 = load i32, ptr %l35, !tbaa !23
  store i32 %t733, ptr %l370, !tbaa !23
  %t734 = load ptr, ptr %l0, !tbaa !29
  %t736 = getelementptr %"compiler/lower:lowering", ptr %t734, i32 0, i32 2
  %t737 = load ptr, ptr %t736, !tbaa !29
  %t738 = load ptr, ptr %l0, !tbaa !29
  %t740 = getelementptr %"compiler/lower:lowering", ptr %t738, i32 0, i32 1
  %t741 = load ptr, ptr %t740, !tbaa !29
  %t743 = getelementptr %"compiler/typed:Body", ptr %t741, i32 0, i32 2
  %t744 = load i32, ptr %t743, !tbaa !23
  %t747 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t737, i32 %t744)
  store i32 %t747, ptr %l376
  br label %bb152
bb151:
  %t748 = load ptr, ptr %l0, !tbaa !29
  %t750 = getelementptr %"compiler/lower:lowering", ptr %t748, i32 0, i32 7
  %t751 = load i1, ptr %t750, !tbaa !21
  %t753 = xor i1 %t751, true
  br i1 %t753, label %bb155, label %bb156
bb152:
  store { i64, [15 x i64] } zeroinitializer, ptr %t755
  %t756 = getelementptr { i64, [15 x i64] }, ptr %t755, i32 0, i32 0
  store i64 11, ptr %t756
  %t757 = load { i64, [4 x i64] }, ptr %l369
  %t758 = insertvalue { { i64, [4 x i64] }, i32, i32 } undef, { i64, [4 x i64] } %t757, 0
  %t759 = load i32, ptr %l370, !tbaa !23
  %t760 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t758, i32 %t759, 1
  %t761 = load i32, ptr %l376, !tbaa !23
  %t762 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t760, i32 %t761, 2
  %t763 = getelementptr { i64, [15 x i64] }, ptr %t755, i32 0, i32 1
  store { { i64, [4 x i64] }, i32, i32 } %t762, ptr %t763
  %t764 = load { i64, [15 x i64] }, ptr %t755
  %t765 = load %"compiler/source:Span", ptr %l33
  %t766 = load ptr, ptr %l367, !tbaa !29
  %t767 = load i32, ptr %l368, !tbaa !23
  %t770 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %t766, i32 %t767, { i64, [15 x i64] } %t764, %"compiler/source:Span" %t765)
  store { i64, [4 x i64] } %t770, ptr %l379
  br label %bb153
bb153:
  %t771 = load ptr, ptr %l365, !tbaa !29
  %t772 = load %"compiler/source:Span", ptr %l366
  %t773 = load { i64, [4 x i64] }, ptr %l379
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eraise(ptr %v0, ptr %t771, %"compiler/source:Span" %t772, { i64, [4 x i64] } %t773)
  br label %bb154
bb154:
  br label %bb159
bb155:
  %t774 = load ptr, ptr %l0, !tbaa !29
  %t775 = load %"compiler/source:Span", ptr %l33
  %t776 = load { i64, [4 x i64] }, ptr %l36
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eraise(ptr %v0, ptr %t774, %"compiler/source:Span" %t775, { i64, [4 x i64] } %t776)
  br label %bb157
bb156:
  br label %bb158
bb157:
  br label %bb158
bb158:
  br label %bb159
bb159:
  br label %bb232
bb160:
  %t780 = load ptr, ptr %l1, !tbaa !29
  store ptr %t780, ptr %l386, !tbaa !29
  store i1 false, ptr %l387, !tbaa !21
  %t781 = load ptr, ptr %l386, !tbaa !29
  %t782 = icmp ne ptr %t781, null
  br i1 %t782, label %bb161, label %bb162
bb161:
  %t784 = load ptr, ptr %l386, !tbaa !29
  %t785 = load i64, ptr %t784
  %t787 = icmp eq i64 %t785, 9
  store i1 %t787, ptr %l387, !tbaa !21
  br label %bb162
bb162:
  %t788 = load i1, ptr %l387, !tbaa !21
  br i1 %t788, label %bb163, label %bb164
bb163:
  %t789 = load ptr, ptr %l1, !tbaa !29
  %t791 = getelementptr { i64, [3 x i64] }, ptr %t789, i32 0, i32 1
  %t792 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t791, i32 0, i32 0
  %t793 = load %"compiler/source:Span", ptr %t792
  store %"compiler/source:Span" %t793, ptr %l37
  %t795 = load ptr, ptr %l1, !tbaa !29
  %t797 = getelementptr { i64, [3 x i64] }, ptr %t795, i32 0, i32 1
  %t798 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t797, i32 0, i32 1
  %t799 = load i32, ptr %t798
  store i32 %t799, ptr %l38
  %t801 = load ptr, ptr %l1, !tbaa !29
  %t803 = getelementptr { i64, [3 x i64] }, ptr %t801, i32 0, i32 1
  %t804 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t803, i32 0, i32 2
  %t805 = load ptr, ptr %t804
  store ptr %t805, ptr %l39, !tbaa !29
  br label %bb165
bb164:
  br label %bb177
bb165:
  store { i64, [4 x i64] } zeroinitializer, ptr %t807
  %t808 = getelementptr { i64, [4 x i64] }, ptr %t807, i32 0, i32 0
  store i64 0, ptr %t808
  %t809 = load { i64, [4 x i64] }, ptr %t807
  store { i64, [4 x i64] } %t809, ptr %l40
  %t811 = load ptr, ptr %l39, !tbaa !29
  %t813 = icmp eq ptr %t811, null
  %t815 = xor i1 %t813, true
  br i1 %t815, label %bb166, label %bb167
bb166:
  %t817 = load ptr, ptr %l0, !tbaa !29
  %t818 = load ptr, ptr %l39, !tbaa !29
  %t822 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v1, ptr %t817, ptr %t818)
  store { i64, [4 x i64] } %t822, ptr %l403
  br label %bb168
bb167:
  br label %bb169
bb168:
  %t823 = load { i64, [4 x i64] }, ptr %l403
  store { i64, [4 x i64] } %t823, ptr %l40
  br label %bb169
bb169:
  %t824 = load i32, ptr %l38
  %t826 = trunc i64 1 to i32
  %t827 = icmp eq i32 %t824, %t826
  br i1 %t827, label %bb170, label %bb171
bb170:
  store i32 4, ptr %l406
  br label %bb172
bb171:
  store i32 3, ptr %l406
  br label %bb172
bb172:
  %t831 = load i32, ptr %l406
  store i32 %t831, ptr %l41
  %t832 = load ptr, ptr %l0, !tbaa !29
  %t834 = getelementptr %"compiler/lower:lowering", ptr %t832, i32 0, i32 7
  %t835 = load i1, ptr %t834, !tbaa !21
  %t837 = xor i1 %t835, true
  br i1 %t837, label %bb173, label %bb174
bb173:
  %t839 = load ptr, ptr %l0, !tbaa !29
  %t840 = load %"compiler/source:Span", ptr %l37
  %t841 = load i32, ptr %l41
  %t842 = load { i64, [4 x i64] }, ptr %l40
  store { i64, [8 x i64] } zeroinitializer, ptr %t843
  %t844 = getelementptr { i64, [8 x i64] }, ptr %t843, i32 0, i32 0
  store i64 8, ptr %t844
  %t846 = insertvalue { %"compiler/source:Span", i32, { i64, [4 x i64] } } undef, %"compiler/source:Span" %t840, 0
  %t848 = insertvalue { %"compiler/source:Span", i32, { i64, [4 x i64] } } %t846, i32 %t841, 1
  %t850 = insertvalue { %"compiler/source:Span", i32, { i64, [4 x i64] } } %t848, { i64, [4 x i64] } %t842, 2
  %t851 = getelementptr { i64, [8 x i64] }, ptr %t843, i32 0, i32 1
  store { %"compiler/source:Span", i32, { i64, [4 x i64] } } %t850, ptr %t851
  %t852 = load { i64, [8 x i64] }, ptr %t843
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t839, { i64, [8 x i64] } %t852)
  br label %bb175
bb174:
  br label %bb176
bb175:
  br label %bb176
bb176:
  br label %bb232
bb177:
  %t855 = load ptr, ptr %l1, !tbaa !29
  store ptr %t855, ptr %l417, !tbaa !29
  store i1 false, ptr %l418, !tbaa !21
  %t856 = load ptr, ptr %l417, !tbaa !29
  %t857 = icmp ne ptr %t856, null
  br i1 %t857, label %bb178, label %bb179
bb178:
  %t859 = load ptr, ptr %l417, !tbaa !29
  %t860 = load i64, ptr %t859
  %t862 = icmp eq i64 %t860, 10
  store i1 %t862, ptr %l418, !tbaa !21
  br label %bb179
bb179:
  %t863 = load i1, ptr %l418, !tbaa !21
  br i1 %t863, label %bb180, label %bb181
bb180:
  %t864 = load ptr, ptr %l1, !tbaa !29
  %t866 = getelementptr { i64, [3 x i64] }, ptr %t864, i32 0, i32 1
  %t867 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t866, i32 0, i32 0
  %t868 = load %"compiler/source:Span", ptr %t867
  store %"compiler/source:Span" %t868, ptr %l42
  %t870 = load ptr, ptr %l1, !tbaa !29
  %t872 = getelementptr { i64, [3 x i64] }, ptr %t870, i32 0, i32 1
  %t873 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t872, i32 0, i32 1
  %t874 = load ptr, ptr %t873
  store ptr %t874, ptr %l43, !tbaa !29
  %t876 = load ptr, ptr %l1, !tbaa !29
  %t878 = getelementptr { i64, [3 x i64] }, ptr %t876, i32 0, i32 1
  %t879 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t878, i32 0, i32 2
  %t880 = load ptr, ptr %t879
  store ptr %t880, ptr %l44, !tbaa !29
  br label %bb182
bb181:
  br label %bb184
bb182:
  %t882 = load ptr, ptr %l0, !tbaa !29
  %t883 = load %"compiler/source:Span", ptr %l42
  %t884 = load ptr, ptr %l43, !tbaa !29
  %t885 = load ptr, ptr %l44, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eassert(ptr %v0, ptr %v1, ptr %v1, ptr %t882, %"compiler/source:Span" %t883, ptr %t884, ptr %t885)
  br label %bb183
bb183:
  br label %bb232
bb184:
  %t890 = load ptr, ptr %l1, !tbaa !29
  store ptr %t890, ptr %l431, !tbaa !29
  store i1 false, ptr %l432, !tbaa !21
  %t891 = load ptr, ptr %l431, !tbaa !29
  %t892 = icmp ne ptr %t891, null
  br i1 %t892, label %bb185, label %bb186
bb185:
  %t894 = load ptr, ptr %l431, !tbaa !29
  %t895 = load i64, ptr %t894
  %t897 = icmp eq i64 %t895, 11
  store i1 %t897, ptr %l432, !tbaa !21
  br label %bb186
bb186:
  %t898 = load i1, ptr %l432, !tbaa !21
  br i1 %t898, label %bb187, label %bb188
bb187:
  %t899 = load ptr, ptr %l1, !tbaa !29
  %t901 = getelementptr { i64, [3 x i64] }, ptr %t899, i32 0, i32 1
  %t902 = getelementptr { %"compiler/source:Span", ptr }, ptr %t901, i32 0, i32 1
  %t903 = load ptr, ptr %t902
  store ptr %t903, ptr %l45, !tbaa !29
  br label %bb189
bb188:
  br label %bb191
bb189:
  %t905 = load ptr, ptr %l0, !tbaa !29
  %t906 = load ptr, ptr %l45, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eblock(ptr %v0, ptr %v1, ptr %t905, ptr %t906)
  br label %bb190
bb190:
  br label %bb232
bb191:
  %t909 = load ptr, ptr %l1, !tbaa !29
  store ptr %t909, ptr %l439, !tbaa !29
  store i1 false, ptr %l440, !tbaa !21
  %t910 = load ptr, ptr %l439, !tbaa !29
  %t911 = icmp ne ptr %t910, null
  br i1 %t911, label %bb192, label %bb193
bb192:
  %t913 = load ptr, ptr %l439, !tbaa !29
  %t914 = load i64, ptr %t913
  %t916 = icmp eq i64 %t914, 12
  store i1 %t916, ptr %l440, !tbaa !21
  br label %bb193
bb193:
  %t917 = load i1, ptr %l440, !tbaa !21
  br i1 %t917, label %bb194, label %bb195
bb194:
  %t918 = load ptr, ptr %l1, !tbaa !29
  %t920 = getelementptr { i64, [3 x i64] }, ptr %t918, i32 0, i32 1
  %t921 = getelementptr { %"compiler/source:Span", ptr }, ptr %t920, i32 0, i32 0
  %t922 = load %"compiler/source:Span", ptr %t921
  store %"compiler/source:Span" %t922, ptr %l46
  %t924 = load ptr, ptr %l1, !tbaa !29
  %t926 = getelementptr { i64, [3 x i64] }, ptr %t924, i32 0, i32 1
  %t927 = getelementptr { %"compiler/source:Span", ptr }, ptr %t926, i32 0, i32 1
  %t928 = load ptr, ptr %t927
  store ptr %t928, ptr %l47, !tbaa !29
  br label %bb196
bb195:
  br label %bb210
bb196:
  %t930 = load ptr, ptr %l0, !tbaa !29
  %t932 = getelementptr %"compiler/lower:lowering", ptr %t930, i32 0, i32 10
  %t933 = load ptr, ptr %l47, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aBlock_26_3e_2ePu_H0a6921d1f6104d156ffed3729e33edeb(ptr %v0, ptr %v1, ptr %t932, ptr %t933)
  br label %bb197
bb197:
  %t936 = load ptr, ptr %l0, !tbaa !29
  %t938 = getelementptr %"compiler/lower:lowering", ptr %t936, i32 0, i32 11
  store ptr %t938, ptr %l451, !tbaa !29
  %t939 = load ptr, ptr %l0, !tbaa !29
  %t941 = call %"compiler/lower:level" @compiler_2flower_2ecompiler_2flower_3alowering_2etop(ptr %v0, ptr %t939)
  store %"compiler/lower:level" %t941, ptr %l453
  br label %bb198
bb198:
  %t942 = getelementptr %"compiler/lower:level", ptr %l453, i32 0, i32 0
  %t943 = load i32, ptr %t942, !tbaa !23
  %t944 = load ptr, ptr %l451, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeId_3e_2ePush_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t944, i32 %t943)
  br label %bb199
bb199:
  %t946 = load ptr, ptr %l0, !tbaa !29
  %t948 = getelementptr %"compiler/lower:lowering", ptr %t946, i32 0, i32 0
  %t949 = load ptr, ptr %t948, !tbaa !29
  %t951 = getelementptr %"compiler/lower:Lowerer", ptr %t949, i32 0, i32 6
  %t952 = load i1, ptr %t951, !tbaa !21
  br i1 %t952, label %bb200, label %bb201
bb200:
  %t954 = load ptr, ptr %l0, !tbaa !29
  store ptr %t954, ptr %l459, !tbaa !29
  %t955 = load ptr, ptr %l0, !tbaa !29
  %t957 = getelementptr %"compiler/lower:lowering", ptr %t955, i32 0, i32 10
  %t959 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aBlock_26_3e_2eLe_H8743fc75fe5cead0bda2da42e1adf3f3(ptr %v0, ptr %t957)
  store i64 %t959, ptr %l462
  br label %bb202
bb201:
  store i1 false, ptr %l458, !tbaa !21
  br label %bb204
bb202:
  %t960 = load i64, ptr %l462, !tbaa !24
  %t961 = sub i64 %t960, 1
  %t962 = load ptr, ptr %l459, !tbaa !29
  %t964 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eonError(ptr %v0, ptr %t962, i64 %t961)
  store i1 %t964, ptr %l464
  br label %bb203
bb203:
  %t965 = load i1, ptr %l464, !tbaa !21
  %t966 = xor i1 %t965, true
  store i1 %t966, ptr %l458, !tbaa !21
  br label %bb204
bb204:
  %t968 = load i1, ptr %l458, !tbaa !21
  br i1 %t968, label %bb205, label %bb206
bb205:
  %t969 = load ptr, ptr %l0, !tbaa !29
  store ptr %t969, ptr %l466, !tbaa !29
  %t970 = load %"compiler/source:Span", ptr %l46
  store %"compiler/source:Span" %t970, ptr %l467
  %t971 = load ptr, ptr %l0, !tbaa !29
  %t973 = getelementptr %"compiler/lower:lowering", ptr %t971, i32 0, i32 10
  %t975 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aBlock_26_3e_2eLe_H8743fc75fe5cead0bda2da42e1adf3f3(ptr %v0, ptr %t973)
  store i64 %t975, ptr %l470
  br label %bb207
bb206:
  br label %bb209
bb207:
  %t976 = load i64, ptr %l470, !tbaa !24
  %t977 = sub i64 %t976, 1
  %t978 = load ptr, ptr %l466, !tbaa !29
  %t979 = load %"compiler/source:Span", ptr %l467
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2ecleanup(ptr %v0, ptr %t978, %"compiler/source:Span" %t979, i64 %t977)
  br label %bb208
bb208:
  br label %bb209
bb209:
  br label %bb232
bb210:
  %t981 = load ptr, ptr %l1, !tbaa !29
  store ptr %t981, ptr %l472, !tbaa !29
  store i1 false, ptr %l473, !tbaa !21
  %t982 = load ptr, ptr %l472, !tbaa !29
  %t983 = icmp ne ptr %t982, null
  br i1 %t983, label %bb211, label %bb212
bb211:
  %t985 = load ptr, ptr %l472, !tbaa !29
  %t986 = load i64, ptr %t985
  %t988 = icmp eq i64 %t986, 13
  store i1 %t988, ptr %l473, !tbaa !21
  br label %bb212
bb212:
  %t989 = load i1, ptr %l473, !tbaa !21
  br i1 %t989, label %bb213, label %bb214
bb213:
  %t990 = load ptr, ptr %l1, !tbaa !29
  %t992 = getelementptr { i64, [3 x i64] }, ptr %t990, i32 0, i32 1
  %t993 = getelementptr { %"compiler/source:Span", ptr }, ptr %t992, i32 0, i32 0
  %t994 = load %"compiler/source:Span", ptr %t993
  store %"compiler/source:Span" %t994, ptr %l48
  %t996 = load ptr, ptr %l1, !tbaa !29
  %t998 = getelementptr { i64, [3 x i64] }, ptr %t996, i32 0, i32 1
  %t999 = getelementptr { %"compiler/source:Span", ptr }, ptr %t998, i32 0, i32 1
  %t1000 = load ptr, ptr %t999
  store ptr %t1000, ptr %l49, !tbaa !29
  br label %bb215
bb214:
  br label %bb217
bb215:
  %t1002 = load ptr, ptr %l0, !tbaa !29
  %t1003 = load %"compiler/source:Span", ptr %l48
  %t1004 = load ptr, ptr %l49, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2ejoin(ptr %v0, ptr %v1, ptr %t1002, %"compiler/source:Span" %t1003, ptr %t1004)
  br label %bb216
bb216:
  br label %bb232
bb217:
  %t1008 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1008, ptr %l483, !tbaa !29
  store i1 false, ptr %l484, !tbaa !21
  %t1009 = load ptr, ptr %l483, !tbaa !29
  %t1010 = icmp ne ptr %t1009, null
  br i1 %t1010, label %bb218, label %bb219
bb218:
  %t1012 = load ptr, ptr %l483, !tbaa !29
  %t1013 = load i64, ptr %t1012
  %t1015 = icmp eq i64 %t1013, 14
  store i1 %t1015, ptr %l484, !tbaa !21
  br label %bb219
bb219:
  %t1016 = load i1, ptr %l484, !tbaa !21
  br i1 %t1016, label %bb220, label %bb221
bb220:
  %t1017 = load ptr, ptr %l1, !tbaa !29
  %t1019 = getelementptr { i64, [3 x i64] }, ptr %t1017, i32 0, i32 1
  %t1020 = getelementptr { %"compiler/source:Span", ptr }, ptr %t1019, i32 0, i32 0
  %t1021 = load %"compiler/source:Span", ptr %t1020
  store %"compiler/source:Span" %t1021, ptr %l50
  %t1023 = load ptr, ptr %l1, !tbaa !29
  %t1025 = getelementptr { i64, [3 x i64] }, ptr %t1023, i32 0, i32 1
  %t1026 = getelementptr { %"compiler/source:Span", ptr }, ptr %t1025, i32 0, i32 1
  %t1027 = load ptr, ptr %t1026
  store ptr %t1027, ptr %l51, !tbaa !29
  br label %bb222
bb221:
  br label %bb224
bb222:
  %t1029 = load ptr, ptr %l0, !tbaa !29
  %t1030 = load %"compiler/source:Span", ptr %l50
  %t1031 = load ptr, ptr %l51, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2espawn(ptr %v0, ptr %v1, ptr %t1029, %"compiler/source:Span" %t1030, ptr %t1031)
  br label %bb223
bb223:
  br label %bb232
bb224:
  %t1035 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1035, ptr %l494, !tbaa !29
  store i1 false, ptr %l495, !tbaa !21
  %t1036 = load ptr, ptr %l494, !tbaa !29
  %t1037 = icmp ne ptr %t1036, null
  br i1 %t1037, label %bb225, label %bb226
bb225:
  %t1039 = load ptr, ptr %l494, !tbaa !29
  %t1040 = load i64, ptr %t1039
  %t1042 = icmp eq i64 %t1040, 15
  store i1 %t1042, ptr %l495, !tbaa !21
  br label %bb226
bb226:
  %t1043 = load i1, ptr %l495, !tbaa !21
  br i1 %t1043, label %bb227, label %bb228
bb227:
  %t1044 = load ptr, ptr %l1, !tbaa !29
  %t1046 = getelementptr { i64, [3 x i64] }, ptr %t1044, i32 0, i32 1
  %t1047 = getelementptr { %"compiler/source:Span", ptr }, ptr %t1046, i32 0, i32 0
  %t1048 = load %"compiler/source:Span", ptr %t1047
  store %"compiler/source:Span" %t1048, ptr %l52
  %t1050 = load ptr, ptr %l1, !tbaa !29
  %t1052 = getelementptr { i64, [3 x i64] }, ptr %t1050, i32 0, i32 1
  %t1053 = getelementptr { %"compiler/source:Span", ptr }, ptr %t1052, i32 0, i32 1
  %t1054 = load ptr, ptr %t1053
  store ptr %t1054, ptr %l53, !tbaa !29
  br label %bb229
bb228:
  br label %bb231
bb229:
  %t1056 = load ptr, ptr %l0, !tbaa !29
  %t1057 = load %"compiler/source:Span", ptr %l52
  %t1058 = load ptr, ptr %l53, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eyield(ptr %v0, ptr %v1, ptr %t1056, %"compiler/source:Span" %t1057, ptr %t1058)
  br label %bb230
bb230:
  br label %bb232
bb231:
  call void @__olang_check_failed(ptr @olang_loc_b5bb8520bdd983ae_ea4f1f3c05c6deda)
  unreachable
bb232:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2estmtSpawnErrors(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i32
  %l10 = alloca i1
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca ptr
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca %"compiler/typed:Item"
  %l19 = alloca i1
  %l20 = alloca ptr
  %l21 = alloca i64
  %l22 = alloca { i64, ptr }
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i32
  %l26 = alloca ptr
  %l27 = alloca ptr
  %l28 = alloca ptr
  %l29 = alloca ptr
  %l32 = alloca ptr
  %l33 = alloca i1
  %l41 = alloca i32
  %l45 = alloca ptr
  %l48 = alloca i32
  %l49 = alloca { i64, ptr }
  %l56 = alloca { i64, ptr }
  %l67 = alloca { i64, ptr }
  %l80 = alloca { i64, ptr }
  %l85 = alloca i1
  %l86 = alloca ptr
  %l89 = alloca i32
  %l92 = alloca i32
  %l93 = alloca i1
  %l100 = alloca { i64, ptr }
  %l103 = alloca { i64, ptr }
  %l104 = alloca i32
  %l113 = alloca { i64, ptr }
  %l117 = alloca i1
  %l118 = alloca ptr
  %l121 = alloca i32
  %l124 = alloca i32
  %l125 = alloca i1
  %l133 = alloca ptr
  %l136 = alloca i32
  %l139 = alloca ptr
  %l140 = alloca i1
  %l149 = alloca ptr
  %l150 = alloca i1
  %l164 = alloca ptr
  %l165 = alloca i1
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s16 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t6 = load ptr, ptr %l1, !tbaa !29
  store ptr %t6, ptr %l32, !tbaa !29
  store i1 false, ptr %l33, !tbaa !21
  %t7 = load ptr, ptr %l32, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l32, !tbaa !29
  %t11 = load i64, ptr %t10
  %t13 = icmp eq i64 %t11, 14
  store i1 %t13, ptr %l33, !tbaa !21
  br label %bb2
bb2:
  %t14 = load i1, ptr %l33, !tbaa !21
  br i1 %t14, label %bb3, label %bb4
bb3:
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t17 = getelementptr { i64, [3 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { %"compiler/source:Span", ptr }, ptr %t17, i32 0, i32 1
  %t19 = load ptr, ptr %t18
  store ptr %t19, ptr %l4, !tbaa !29
  br label %bb5
bb4:
  br label %bb71
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load ptr, ptr %l4, !tbaa !29
  %t24 = getelementptr %"compiler/typed:Spawn", ptr %t22, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t28 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2etaskType(ptr %v0, ptr %v1, ptr %t21, ptr %t25)
  store i32 %t28, ptr %l41
  br label %bb6
bb6:
  %t29 = load i32, ptr %l41, !tbaa !23
  store i32 %t29, ptr %l5, !tbaa !23
  %t30 = load i32, ptr %l5, !tbaa !23
  %t31 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t34 = icmp eq i32 %t30, %t31
  br i1 %t34, label %bb7, label %bb8
bb7:
  br label %ret
bb8:
  br label %bb9
bb9:
  %t36 = load ptr, ptr %l3, !tbaa !29
  store ptr %t36, ptr %l45, !tbaa !29
  %t37 = load ptr, ptr %l3, !tbaa !29
  %t38 = load i32, ptr %l5, !tbaa !23
  %t41 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t37, i32 %t38)
  store i32 %t41, ptr %l48
  br label %bb10
bb10:
  %t42 = load ptr, ptr %l45, !tbaa !29
  %t43 = load i32, ptr %l48, !tbaa !23
  %t44 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t42, i32 %t43)
  store { i64, ptr } %t44, ptr %l49
  br label %bb11
bb11:
  %t45 = load { i64, ptr }, ptr %l49, !tbaa !27
  store { i64, ptr } %t45, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t46 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t48 = extractvalue { i64, ptr } %t46, 0
  store i64 %t48, ptr %l8, !tbaa !24
  br label %bb12
bb12:
  store %olang.scope zeroinitializer, ptr %s4
  %t50 = load i64, ptr %l7, !tbaa !24
  %t51 = load i64, ptr %l8, !tbaa !24
  %t54 = icmp slt i64 %t50, %t51
  %t56 = xor i1 %t54, true
  br i1 %t56, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s4)
  br label %bb70
bb14:
  br label %bb15
bb15:
  %t58 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t58, ptr %l56, !tbaa !27
  %t59 = load i64, ptr %l7, !tbaa !24
  %t61 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !27
  %t63 = getelementptr i32, ptr %t62, i64 %t59
  %t64 = load i32, ptr %t63, !tbaa !33
  store i32 %t64, ptr %l9, !tbaa !23
  store i1 false, ptr %l10, !tbaa !21
  %t66 = load ptr, ptr %l4, !tbaa !29
  %t68 = getelementptr %"compiler/typed:Spawn", ptr %t66, i32 0, i32 2
  %t69 = load { i64, ptr }, ptr %t68, !tbaa !27
  store { i64, ptr } %t69, ptr %l11, !tbaa !27
  store i64 0, ptr %l12, !tbaa !24
  %t71 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t73 = extractvalue { i64, ptr } %t71, 0
  store i64 %t73, ptr %l13, !tbaa !24
  br label %bb16
bb16:
  store %olang.scope zeroinitializer, ptr %s6
  %t75 = load i64, ptr %l12, !tbaa !24
  %t76 = load i64, ptr %l13, !tbaa !24
  %t79 = icmp slt i64 %t75, %t76
  %t81 = xor i1 %t79, true
  br i1 %t81, label %bb17, label %bb18
bb17:
  call void @__olang_scope_close(ptr %s6)
  br label %bb39
bb18:
  br label %bb19
bb19:
  %t83 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t83, ptr %l67, !tbaa !27
  %t84 = load i64, ptr %l12, !tbaa !24
  %t86 = getelementptr { i64, ptr }, ptr %l67, i32 0, i32 1
  %t87 = load ptr, ptr %t86, !tbaa !27
  %t88 = getelementptr ptr, ptr %t87, i64 %t84
  %t89 = load ptr, ptr %t88, !tbaa !39
  store ptr %t89, ptr %l14, !tbaa !29
  %t91 = load ptr, ptr %l14, !tbaa !29
  %t93 = getelementptr %"compiler/typed:TaskClause", ptr %t91, i32 0, i32 2
  %t94 = load i1, ptr %t93, !tbaa !21
  br i1 %t94, label %bb20, label %bb21
bb20:
  store i1 true, ptr %l10, !tbaa !21
  br label %bb22
bb21:
  br label %bb22
bb22:
  %t96 = load ptr, ptr %l14, !tbaa !29
  %t98 = getelementptr %"compiler/typed:TaskClause", ptr %t96, i32 0, i32 1
  %t99 = load { i64, ptr }, ptr %t98, !tbaa !27
  store { i64, ptr } %t99, ptr %l15, !tbaa !27
  store i64 0, ptr %l16, !tbaa !24
  %t101 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t103 = extractvalue { i64, ptr } %t101, 0
  store i64 %t103, ptr %l17, !tbaa !24
  br label %bb23
bb23:
  store %olang.scope zeroinitializer, ptr %s9
  %t105 = load i64, ptr %l16, !tbaa !24
  %t106 = load i64, ptr %l17, !tbaa !24
  %t109 = icmp slt i64 %t105, %t106
  %t111 = xor i1 %t109, true
  br i1 %t111, label %bb24, label %bb25
bb24:
  call void @__olang_scope_close(ptr %s9)
  br label %bb37
bb25:
  br label %bb26
bb26:
  %t113 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t113, ptr %l80, !tbaa !27
  %t114 = load i64, ptr %l16, !tbaa !24
  %t116 = getelementptr { i64, ptr }, ptr %l80, i32 0, i32 1
  %t117 = load ptr, ptr %t116, !tbaa !27
  %t118 = getelementptr %"compiler/typed:Item", ptr %t117, i64 %t114
  %t119 = load %"compiler/typed:Item", ptr %t118
  store %"compiler/typed:Item" %t119, ptr %l18
  %t121 = getelementptr %"compiler/typed:Item", ptr %l18, i32 0, i32 1
  %t122 = load i64, ptr %t121, !tbaa !24
  %t124 = icmp slt i64 %t122, 0
  br i1 %t124, label %bb27, label %bb28
bb27:
  %t126 = load ptr, ptr %l3, !tbaa !29
  store ptr %t126, ptr %l86, !tbaa !29
  %t127 = load ptr, ptr %l3, !tbaa !29
  %t128 = getelementptr %"compiler/typed:Item", ptr %l18, i32 0, i32 0
  %t129 = load i32, ptr %t128, !tbaa !23
  %t132 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t127, i32 %t129)
  store i32 %t132, ptr %l89
  br label %bb29
bb28:
  store i1 false, ptr %l85, !tbaa !21
  br label %bb32
bb29:
  %t133 = load ptr, ptr %l3, !tbaa !29
  %t134 = load i32, ptr %l9, !tbaa !23
  %t137 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t133, i32 %t134)
  store i32 %t137, ptr %l92
  br label %bb30
bb30:
  %t138 = load ptr, ptr %l86, !tbaa !29
  %t139 = load i32, ptr %l89, !tbaa !23
  %t140 = load i32, ptr %l92, !tbaa !23
  %t141 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t138, i32 %t139, i32 %t140)
  store i1 %t141, ptr %l93
  br label %bb31
bb31:
  %t142 = load i1, ptr %l93, !tbaa !21
  store i1 %t142, ptr %l85, !tbaa !21
  br label %bb32
bb32:
  %t143 = load i1, ptr %l85, !tbaa !21
  br i1 %t143, label %bb33, label %bb34
bb33:
  store i1 true, ptr %l10, !tbaa !21
  br label %bb35
bb34:
  br label %bb35
bb35:
  call void @__olang_scope_close(ptr %s9)
  br label %bb36
bb36:
  %t144 = load i64, ptr %l16, !tbaa !24
  %t146 = add i64 %t144, 1
  store i64 %t146, ptr %l16, !tbaa !24
  br label %bb23
bb37:
  call void @__olang_scope_close(ptr %s6)
  br label %bb38
bb38:
  %t148 = load i64, ptr %l12, !tbaa !24
  %t150 = add i64 %t148, 1
  store i64 %t150, ptr %l12, !tbaa !24
  br label %bb16
bb39:
  %t152 = load i1, ptr %l10, !tbaa !21
  br i1 %t152, label %bb40, label %bb41
bb40:
  call void @__olang_scope_close(ptr %s4)
  br label %bb69
bb41:
  br label %bb42
bb42:
  store i1 false, ptr %l19, !tbaa !21
  %t154 = load ptr, ptr %l2, !tbaa !29
  store ptr %t154, ptr %l20, !tbaa !29
  store i64 0, ptr %l21, !tbaa !24
  br label %bb43
bb43:
  store %olang.scope zeroinitializer, ptr %s15
  %t156 = load ptr, ptr %l20, !tbaa !29
  %t157 = load i64, ptr %l21, !tbaa !24
  %t160 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eRunF_H9c1707946c43ec840ffe1821bea89b1f(ptr %v2, ptr %t156, i64 %t157)
  %t161 = extractvalue { i32, { i64, ptr } } %t160, 1
  %t162 = extractvalue { i32, { i64, ptr } } %t160, 0
  store i32 %t162, ptr %l104
  %t163 = icmp ne i32 %t162, 0
  br i1 %t163, label %bb45, label %ok.164
ok.164:
  store { i64, ptr } %t161, ptr %l103
  br label %bb44
bb44:
  %t165 = load { i64, ptr }, ptr %l103, !tbaa !27
  store { i64, ptr } %t165, ptr %l100, !tbaa !27
  br label %bb49
bb45:
  %t166 = load i32, ptr %l104, !tbaa !23
  %t167 = ashr i32 %t166, 16
  %t169 = icmp eq i32 %t167, 1
  br i1 %t169, label %bb46, label %bb47
bb46:
  br label %bb48
bb47:
  call void @__olang_check_failed(ptr @olang_loc_7b1a9423057e34c5_261f06cd9be6d659)
  unreachable
bb48:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s15)
  br label %bb63
bb49:
  %t171 = load { i64, ptr }, ptr %l100, !tbaa !27
  store { i64, ptr } %t171, ptr %l22, !tbaa !27
  %t172 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t174 = extractvalue { i64, ptr } %t172, 0
  store i64 %t174, ptr %l23, !tbaa !24
  store i64 0, ptr %l24, !tbaa !24
  br label %bb50
bb50:
  store %olang.scope zeroinitializer, ptr %s16
  %t176 = load i64, ptr %l24, !tbaa !24
  %t177 = load i64, ptr %l23, !tbaa !24
  %t180 = icmp slt i64 %t176, %t177
  %t182 = xor i1 %t180, true
  br i1 %t182, label %bb51, label %bb52
bb51:
  call void @__olang_scope_close(ptr %s16)
  br label %bb61
bb52:
  br label %bb53
bb53:
  %t184 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t184, ptr %l113, !tbaa !27
  %t185 = load i64, ptr %l24, !tbaa !24
  %t187 = getelementptr { i64, ptr }, ptr %l113, i32 0, i32 1
  %t188 = load ptr, ptr %t187, !tbaa !27
  %t189 = getelementptr i32, ptr %t188, i64 %t185
  %t190 = load i32, ptr %t189, !tbaa !33
  store i32 %t190, ptr %l25, !tbaa !23
  %t192 = load i1, ptr %l19, !tbaa !21
  br i1 %t192, label %bb54, label %bb55
bb54:
  store i1 true, ptr %l117, !tbaa !21
  br label %bb59
bb55:
  %t194 = load ptr, ptr %l3, !tbaa !29
  store ptr %t194, ptr %l118, !tbaa !29
  %t195 = load ptr, ptr %l3, !tbaa !29
  %t196 = load i32, ptr %l25, !tbaa !23
  %t199 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t195, i32 %t196)
  store i32 %t199, ptr %l121
  br label %bb56
bb56:
  %t200 = load ptr, ptr %l3, !tbaa !29
  %t201 = load i32, ptr %l9, !tbaa !23
  %t204 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t200, i32 %t201)
  store i32 %t204, ptr %l124
  br label %bb57
bb57:
  %t205 = load ptr, ptr %l118, !tbaa !29
  %t206 = load i32, ptr %l121, !tbaa !23
  %t207 = load i32, ptr %l124, !tbaa !23
  %t208 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t205, i32 %t206, i32 %t207)
  store i1 %t208, ptr %l125
  br label %bb58
bb58:
  %t209 = load i1, ptr %l125, !tbaa !21
  store i1 %t209, ptr %l117, !tbaa !21
  br label %bb59
bb59:
  %t210 = load i1, ptr %l117, !tbaa !21
  store i1 %t210, ptr %l19, !tbaa !21
  call void @__olang_scope_close(ptr %s16)
  br label %bb60
bb60:
  %t211 = load i64, ptr %l24, !tbaa !24
  %t213 = add i64 %t211, 1
  store i64 %t213, ptr %l24, !tbaa !24
  br label %bb50
bb61:
  %t215 = load i64, ptr %l21, !tbaa !24
  %t216 = load i64, ptr %l23, !tbaa !24
  %t219 = add i64 %t215, %t216
  store i64 %t219, ptr %l21, !tbaa !24
  call void @__olang_scope_close(ptr %s15)
  br label %bb62
bb62:
  br label %bb43
bb63:
  %t221 = load i1, ptr %l19, !tbaa !21
  %t223 = xor i1 %t221, true
  br i1 %t223, label %bb64, label %bb65
bb64:
  %t225 = load ptr, ptr %l2, !tbaa !29
  store ptr %t225, ptr %l133, !tbaa !29
  %t226 = load ptr, ptr %l3, !tbaa !29
  %t227 = load i32, ptr %l9, !tbaa !23
  %t230 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t226, i32 %t227)
  store i32 %t230, ptr %l136
  br label %bb66
bb65:
  br label %bb68
bb66:
  %t231 = load ptr, ptr %l133, !tbaa !29
  %t232 = load i32, ptr %l136, !tbaa !23
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v2, ptr %t231, i32 %t232)
  br label %bb67
bb67:
  br label %bb68
bb68:
  call void @__olang_scope_close(ptr %s4)
  br label %bb69
bb69:
  %t233 = load i64, ptr %l7, !tbaa !24
  %t235 = add i64 %t233, 1
  store i64 %t235, ptr %l7, !tbaa !24
  br label %bb12
bb70:
  br label %bb99
bb71:
  %t237 = load ptr, ptr %l1, !tbaa !29
  store ptr %t237, ptr %l139, !tbaa !29
  store i1 false, ptr %l140, !tbaa !21
  %t238 = load ptr, ptr %l139, !tbaa !29
  %t239 = icmp ne ptr %t238, null
  br i1 %t239, label %bb72, label %bb73
bb72:
  %t241 = load ptr, ptr %l139, !tbaa !29
  %t242 = load i64, ptr %t241
  %t244 = icmp eq i64 %t242, 11
  store i1 %t244, ptr %l140, !tbaa !21
  br label %bb73
bb73:
  %t245 = load i1, ptr %l140, !tbaa !21
  br i1 %t245, label %bb74, label %bb75
bb74:
  %t246 = load ptr, ptr %l1, !tbaa !29
  %t248 = getelementptr { i64, [3 x i64] }, ptr %t246, i32 0, i32 1
  %t249 = getelementptr { %"compiler/source:Span", ptr }, ptr %t248, i32 0, i32 1
  %t250 = load ptr, ptr %t249
  store ptr %t250, ptr %l26, !tbaa !29
  br label %bb76
bb75:
  br label %bb78
bb76:
  %t252 = load ptr, ptr %l0, !tbaa !29
  %t253 = load ptr, ptr %l26, !tbaa !29
  %t255 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2espawnErrors(ptr %v0, ptr %v1, ptr %v2, ptr %t252, ptr %t253, ptr %t255)
  br label %bb77
bb77:
  br label %bb99
bb78:
  %t259 = load ptr, ptr %l1, !tbaa !29
  store ptr %t259, ptr %l149, !tbaa !29
  store i1 false, ptr %l150, !tbaa !21
  %t260 = load ptr, ptr %l149, !tbaa !29
  %t261 = icmp ne ptr %t260, null
  br i1 %t261, label %bb79, label %bb80
bb79:
  %t263 = load ptr, ptr %l149, !tbaa !29
  %t264 = load i64, ptr %t263
  %t266 = icmp eq i64 %t264, 3
  store i1 %t266, ptr %l150, !tbaa !21
  br label %bb80
bb80:
  %t267 = load i1, ptr %l150, !tbaa !21
  br i1 %t267, label %bb81, label %bb82
bb81:
  %t268 = load ptr, ptr %l1, !tbaa !29
  %t270 = getelementptr { i64, [3 x i64] }, ptr %t268, i32 0, i32 1
  %t271 = getelementptr { %"compiler/source:Span", ptr }, ptr %t270, i32 0, i32 1
  %t272 = load ptr, ptr %t271
  store ptr %t272, ptr %l27, !tbaa !29
  br label %bb83
bb82:
  br label %bb86
bb83:
  %t274 = load ptr, ptr %l0, !tbaa !29
  %t275 = load ptr, ptr %l27, !tbaa !29
  %t277 = getelementptr %"compiler/typed:If", ptr %t275, i32 0, i32 1
  %t278 = load ptr, ptr %t277, !tbaa !29
  %t280 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2espawnErrors(ptr %v0, ptr %v1, ptr %v2, ptr %t274, ptr %t278, ptr %t280)
  br label %bb84
bb84:
  %t284 = load ptr, ptr %l0, !tbaa !29
  %t285 = load ptr, ptr %l27, !tbaa !29
  %t287 = getelementptr %"compiler/typed:If", ptr %t285, i32 0, i32 2
  %t288 = load ptr, ptr %t287, !tbaa !29
  %t289 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2espawnErrors(ptr %v0, ptr %v1, ptr %v2, ptr %t284, ptr %t288, ptr %t289)
  br label %bb85
bb85:
  br label %bb99
bb86:
  %t293 = load ptr, ptr %l1, !tbaa !29
  store ptr %t293, ptr %l164, !tbaa !29
  store i1 false, ptr %l165, !tbaa !21
  %t294 = load ptr, ptr %l164, !tbaa !29
  %t295 = icmp ne ptr %t294, null
  br i1 %t295, label %bb87, label %bb88
bb87:
  %t297 = load ptr, ptr %l164, !tbaa !29
  %t298 = load i64, ptr %t297
  %t300 = icmp eq i64 %t298, 4
  store i1 %t300, ptr %l165, !tbaa !21
  br label %bb88
bb88:
  %t301 = load i1, ptr %l165, !tbaa !21
  br i1 %t301, label %bb89, label %bb90
bb89:
  %t302 = load ptr, ptr %l1, !tbaa !29
  %t304 = getelementptr { i64, [3 x i64] }, ptr %t302, i32 0, i32 1
  %t305 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t304, i32 0, i32 1
  %t306 = load ptr, ptr %t305
  store ptr %t306, ptr %l28, !tbaa !29
  %t308 = load ptr, ptr %l1, !tbaa !29
  %t310 = getelementptr { i64, [3 x i64] }, ptr %t308, i32 0, i32 1
  %t311 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t310, i32 0, i32 2
  %t312 = load ptr, ptr %t311
  store ptr %t312, ptr %l29, !tbaa !29
  br label %bb91
bb90:
  br label %bb94
bb91:
  %t314 = load ptr, ptr %l0, !tbaa !29
  %t315 = load ptr, ptr %l28, !tbaa !29
  %t317 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2espawnErrors(ptr %v0, ptr %v1, ptr %v2, ptr %t314, ptr %t315, ptr %t317)
  br label %bb92
bb92:
  %t321 = load ptr, ptr %l0, !tbaa !29
  %t322 = load ptr, ptr %l29, !tbaa !29
  %t323 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2espawnErrors(ptr %v0, ptr %v1, ptr %v2, ptr %t321, ptr %t322, ptr %t323)
  br label %bb93
bb93:
  br label %bb99
bb94:
  br i1 true, label %bb95, label %bb96
bb95:
  br label %bb97
bb96:
  br label %bb98
bb97:
  br label %bb99
bb98:
  call void @__olang_check_failed(ptr @olang_loc_4d2a900631880414_3719f57230f55c88)
  unreachable
bb99:
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2etarget(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca i64
  %l9 = alloca %"compiler/lower:pl"
  %l11 = alloca ptr
  %l14 = alloca i64
  %l16 = alloca %"compiler/lower:pl"
  %s1 = alloca %olang.scope
  %rv = alloca %"compiler/lower:pl"
  %t13 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 15
  %t5 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3apl_3e_2eLen_3ccompiler_2flower_3apl_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i64, ptr %l4, !tbaa !24
  %t7 = icmp eq i64 %t6, 0
  br i1 %t7, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t9 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2egap(ptr %v0, ptr %s1, ptr %t9, %"compiler/source:Span" %a1, { i64, ptr } { i64 55, ptr getelementptr inbounds (<{ i64, [55 x i8] }>, ptr @.d32, i32 0, i32 1) })
  br label %bb4
bb3:
  br label %bb6
bb4:
  store { i64, [2 x i64] } zeroinitializer, ptr %t13
  %t14 = getelementptr { i64, [2 x i64] }, ptr %t13, i32 0, i32 0
  store i64 0, ptr %t14
  %t15 = load { i64, [2 x i64] }, ptr %t13
  %t17 = call %"compiler/lower:pl" @compiler_2flower_3apl_2ector(ptr %v1, { i64, [2 x i64] } %t15)
  store %"compiler/lower:pl" %t17, ptr %l9
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s1)
  %t18 = load %"compiler/lower:pl", ptr %l9
  store %"compiler/lower:pl" %t18, ptr %rv
  br label %ret
bb6:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/lower:lowering", ptr %t19, i32 0, i32 15
  store ptr %t21, ptr %l11, !tbaa !29
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/lower:lowering", ptr %t22, i32 0, i32 15
  %t26 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3apl_3e_2eLen_3ccompiler_2flower_3apl_3e(ptr %v0, ptr %t24)
  store i64 %t26, ptr %l14
  br label %bb7
bb7:
  %t27 = load i64, ptr %l14, !tbaa !24
  %t28 = sub i64 %t27, 1
  %t29 = load ptr, ptr %l11, !tbaa !29
  %t31 = call %"compiler/lower:pl" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3apl_3e_2eAt_3ccompiler_2flower_3apl_3e(ptr %v0, ptr %v1, ptr %t29, i64 %t28)
  store %"compiler/lower:pl" %t31, ptr %l16
  br label %bb8
bb8:
  %t32 = load %"compiler/lower:pl", ptr %l16
  store %"compiler/lower:pl" %t32, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/lower:pl", ptr %rv
  ret %"compiler/lower:pl" %rr
}

define dso_local { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2etext(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca { { i64, [4 x i64] }, i32 }
  %l16 = alloca i32
  %l17 = alloca { i64, [1 x i64] }
  %l19 = alloca i32
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca ptr
  %l27 = alloca { i64, ptr }
  %l29 = alloca { i64, [4 x i64] }
  %l34 = alloca i64
  %l40 = alloca i64
  %l50 = alloca i64
  %l53 = alloca i64
  %l72 = alloca { i64, ptr }
  %l75 = alloca ptr
  %l76 = alloca i1
  %l84 = alloca { { i64, [4 x i64] }, i32 }
  %l95 = alloca ptr
  %l96 = alloca i32
  %l98 = alloca %"compiler/lower:level"
  %l101 = alloca i32
  %l110 = alloca i32
  %l111 = alloca ptr
  %l114 = alloca i32
  %l116 = alloca i32
  %l123 = alloca i64
  %l126 = alloca i64
  %l145 = alloca { i64, ptr }
  %l148 = alloca ptr
  %l149 = alloca i1
  %l159 = alloca i32
  %l172 = alloca ptr
  %l173 = alloca i1
  %l185 = alloca ptr
  %l186 = alloca i32
  %l187 = alloca { i64, [1 x i64] }
  %l191 = alloca { i64, [1 x i64] }
  %l195 = alloca { i64, [4 x i64] }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %rv = alloca { i64, [4 x i64] }
  %t154 = alloca { i64, [4 x i64] }, align 8
  %t176 = alloca { i64, [21 x i64] }, align 8
  %t189 = alloca { i64, [1 x i64] }, align 8
  %t295 = alloca { i64, [2 x i64] }, align 8
  %t317 = alloca { i64, [4 x i64] }, align 8
  %t329 = alloca { i64, [21 x i64] }, align 8
  %t390 = alloca { i64, [15 x i64] }, align 8
  %t410 = alloca { i64, [21 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  store %"compiler/source:Span" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t6 = load ptr, ptr %l1, !tbaa !29
  %t8 = getelementptr %"compiler/typed:Text", ptr %t6, i32 0, i32 0
  %t9 = load { i64, ptr }, ptr %t8, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t9, 0
  store i64 %t11, ptr %l34, !tbaa !24
  %t12 = load i64, ptr %l34, !tbaa !24
  %t13 = icmp sge i64 %t12, 0
  br i1 %t13, label %bb1, label %bb2
bb1:
  %t15 = load i64, ptr %l34, !tbaa !24
  %t16 = icmp sle i64 %t15, 230584300921369395
  br i1 %t16, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_77939bd7b34e0fa3_983f89b6cb89307)
  unreachable
bb3:
  %t18 = load i64, ptr %l34, !tbaa !24
  %t19 = mul i64 %t18, 40
  %t20 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t19)
  %t21 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  store { i64, ptr } %t22, ptr %l5, !tbaa !27
  %t24 = load ptr, ptr %l1, !tbaa !29
  %t26 = getelementptr %"compiler/typed:Text", ptr %t24, i32 0, i32 0
  %t27 = load { i64, ptr }, ptr %t26, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t27, 0
  store i64 %t29, ptr %l40, !tbaa !24
  %t30 = load i64, ptr %l40, !tbaa !24
  %t31 = icmp sge i64 %t30, 0
  br i1 %t31, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_77939bd7b34e0fa3_983f89b6cb89307)
  unreachable
bb5:
  %t33 = load i64, ptr %l40, !tbaa !24
  %t34 = icmp sle i64 %t33, 2305843009213693951
  br i1 %t34, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_cbdf5e9a9cabb32e_3680da0cabce8c12)
  unreachable
bb7:
  %t36 = load i64, ptr %l40, !tbaa !24
  %t37 = mul i64 %t36, 4
  %t38 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t37)
  %t39 = insertvalue { i64, ptr } undef, i64 %t36, 0
  %t40 = insertvalue { i64, ptr } %t39, ptr %t38, 1
  store { i64, ptr } %t40, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t42 = load ptr, ptr %l1, !tbaa !29
  %t44 = getelementptr %"compiler/typed:Text", ptr %t42, i32 0, i32 0
  %t45 = load { i64, ptr }, ptr %t44, !tbaa !27
  %t47 = extractvalue { i64, ptr } %t45, 0
  store i64 %t47, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t49 = load i64, ptr %l8, !tbaa !24
  %t50 = load i64, ptr %l7, !tbaa !24
  %t53 = icmp sgt i64 %t49, %t50
  br i1 %t53, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_cbdf5e9a9cabb32e_3680da0cabce8c12)
  unreachable
bb9:
  %t55 = load i64, ptr %l9, !tbaa !24
  %t57 = icmp sgt i64 %t55, 0
  br i1 %t57, label %bb11, label %bb12
bb10:
  store i64 0, ptr %l50, !tbaa !24
  br label %bb14
bb11:
  %t59 = load i64, ptr %l8, !tbaa !24
  %t60 = load i64, ptr %l7, !tbaa !24
  %t63 = sub i64 %t59, %t60
  %t64 = load i64, ptr %l9, !tbaa !24
  %t67 = add i64 %t63, %t64
  %t69 = sub i64 %t67, 1
  %t70 = load i64, ptr %l9, !tbaa !24
  %t73 = sdiv i64 %t69, %t70
  store i64 %t73, ptr %l53, !tbaa !24
  br label %bb13
bb12:
  store i64 0, ptr %l53, !tbaa !24
  br label %bb13
bb13:
  %t75 = load i64, ptr %l53, !tbaa !24
  store i64 %t75, ptr %l50, !tbaa !24
  br label %bb14
bb14:
  %t76 = load i64, ptr %l50, !tbaa !24
  store i64 %t76, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb15
bb15:
  store %olang.scope zeroinitializer, ptr %s2
  %t77 = load i64, ptr %l11, !tbaa !24
  %t78 = load i64, ptr %l10, !tbaa !24
  %t81 = icmp slt i64 %t77, %t78
  %t83 = xor i1 %t81, true
  br i1 %t83, label %bb16, label %bb17
bb16:
  call void @__olang_scope_close(ptr %s2)
  br label %bb32
bb17:
  br label %bb18
bb18:
  %t85 = load i64, ptr %l7, !tbaa !24
  %t86 = load i64, ptr %l11, !tbaa !24
  %t87 = load i64, ptr %l9, !tbaa !24
  %t90 = mul i64 %t86, %t87
  %t93 = add i64 %t85, %t90
  store i64 %t93, ptr %l12, !tbaa !24
  %t95 = load ptr, ptr %l1, !tbaa !29
  %t97 = getelementptr %"compiler/typed:Text", ptr %t95, i32 0, i32 0
  %t98 = load { i64, ptr }, ptr %t97, !tbaa !27
  store { i64, ptr } %t98, ptr %l72, !tbaa !27
  %t99 = load i64, ptr %l12, !tbaa !24
  %t101 = getelementptr { i64, ptr }, ptr %l72, i32 0, i32 1
  %t102 = load ptr, ptr %t101, !tbaa !27
  %t103 = getelementptr ptr, ptr %t102, i64 %t99
  %t104 = load ptr, ptr %t103, !tbaa !39
  store ptr %t104, ptr %l13, !tbaa !29
  %t106 = load ptr, ptr %l13, !tbaa !29
  store ptr %t106, ptr %l75, !tbaa !29
  store i1 false, ptr %l76, !tbaa !21
  %t107 = load ptr, ptr %l75, !tbaa !29
  %t108 = icmp ne ptr %t107, null
  br i1 %t108, label %bb19, label %bb20
bb19:
  %t110 = load ptr, ptr %l75, !tbaa !29
  %t111 = load i64, ptr %t110
  %t113 = icmp eq i64 %t111, 1
  store i1 %t113, ptr %l76, !tbaa !21
  br label %bb20
bb20:
  %t114 = load i1, ptr %l76, !tbaa !21
  br i1 %t114, label %bb21, label %bb22
bb21:
  %t115 = load ptr, ptr %l13, !tbaa !29
  %t117 = getelementptr { i64, [2 x i64] }, ptr %t115, i32 0, i32 1
  %t118 = getelementptr { ptr }, ptr %t117, i32 0, i32 0
  %t119 = load ptr, ptr %t118
  store ptr %t119, ptr %l14, !tbaa !29
  br label %bb23
bb22:
  br label %bb25
bb23:
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t122 = load ptr, ptr %l14, !tbaa !29
  %t123 = load %"compiler/source:Span", ptr %l3
  %t127 = call { { i64, [4 x i64] }, i32 } @compiler_2flower_2ecompiler_2flower_3alowering_2epiece(ptr %v0, ptr %v1, ptr %t121, ptr %t122, %"compiler/source:Span" %t123)
  store { { i64, [4 x i64] }, i32 } %t127, ptr %l84
  br label %bb24
bb24:
  %t128 = load { { i64, [4 x i64] }, i32 }, ptr %l84
  store { { i64, [4 x i64] }, i32 } %t128, ptr %l15
  %t129 = load i64, ptr %l12, !tbaa !24
  %t130 = getelementptr { { i64, [4 x i64] }, i32 }, ptr %l15, i32 0, i32 0
  %t131 = load { i64, [4 x i64] }, ptr %t130
  %t134 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t135 = load ptr, ptr %t134, !tbaa !27
  %t136 = getelementptr { i64, [4 x i64] }, ptr %t135, i64 %t129
  store { i64, [4 x i64] } %t131, ptr %t136
  %t137 = load i64, ptr %l12, !tbaa !24
  %t138 = getelementptr { { i64, [4 x i64] }, i32 }, ptr %l15, i32 0, i32 1
  %t139 = load i32, ptr %t138, !tbaa !23
  %t142 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t143 = load ptr, ptr %t142, !tbaa !27
  %t144 = getelementptr i32, ptr %t143, i64 %t137
  store i32 %t139, ptr %t144, !tbaa !33
  br label %bb30
bb25:
  br i1 true, label %bb26, label %bb27
bb26:
  br label %bb28
bb27:
  br label %bb29
bb28:
  br label %bb30
bb29:
  call void @__olang_check_failed(ptr @olang_loc_459157e65df33c7e_1dfbf278634bff4a)
  unreachable
bb30:
  call void @__olang_scope_close(ptr %s2)
  br label %bb31
bb31:
  %t145 = load i64, ptr %l11, !tbaa !24
  %t147 = add i64 %t145, 1
  store i64 %t147, ptr %l11, !tbaa !24
  br label %bb15
bb32:
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t151 = getelementptr %"compiler/lower:lowering", ptr %t149, i32 0, i32 7
  %t152 = load i1, ptr %t151, !tbaa !21
  br i1 %t152, label %bb33, label %bb34
bb33:
  store { i64, [4 x i64] } zeroinitializer, ptr %t154
  %t155 = getelementptr { i64, [4 x i64] }, ptr %t154, i32 0, i32 0
  store i64 0, ptr %t155
  %t156 = load { i64, [4 x i64] }, ptr %t154
  call void @__olang_scope_close(ptr %s0)
  store { i64, [4 x i64] } %t156, ptr %rv
  br label %ret
bb34:
  br label %bb35
bb35:
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t160 = getelementptr %"compiler/lower:lowering", ptr %t158, i32 0, i32 3
  store ptr %t160, ptr %l95, !tbaa !29
  store i32 6, ptr %l96
  %t161 = load ptr, ptr %l0, !tbaa !29
  %t163 = call %"compiler/lower:level" @compiler_2flower_2ecompiler_2flower_3alowering_2etop(ptr %v0, ptr %t161)
  store %"compiler/lower:level" %t163, ptr %l98
  br label %bb36
bb36:
  %t164 = getelementptr %"compiler/lower:level", ptr %l98, i32 0, i32 0
  %t165 = load i32, ptr %t164, !tbaa !23
  %t166 = load %"compiler/source:Span", ptr %l3
  %t167 = load ptr, ptr %l95, !tbaa !29
  %t168 = load i32, ptr %l96
  %t171 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddScope(ptr %v0, ptr %t167, i32 %t168, i32 %t165, i32 -1, %"compiler/source:Span" %t166, i32 0)
  store i32 %t171, ptr %l101
  br label %bb37
bb37:
  %t172 = load i32, ptr %l101, !tbaa !23
  store i32 %t172, ptr %l16, !tbaa !23
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t174 = load %"compiler/source:Span", ptr %l3
  %t175 = load i32, ptr %l16, !tbaa !23
  store { i64, [21 x i64] } zeroinitializer, ptr %t176
  %t177 = getelementptr { i64, [21 x i64] }, ptr %t176, i32 0, i32 0
  store i64 3, ptr %t177
  %t179 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t174, 0
  %t181 = insertvalue { %"compiler/source:Span", i32 } %t179, i32 %t175, 1
  %t182 = getelementptr { i64, [21 x i64] }, ptr %t176, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t181, ptr %t182
  %t183 = load { i64, [21 x i64] }, ptr %t176
  %t185 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t183, ptr %t185
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s0, ptr %t173, ptr %t185)
  br label %bb38
bb38:
  %t188 = load i32, ptr %l16, !tbaa !23
  store { i64, [1 x i64] } zeroinitializer, ptr %t189
  %t190 = getelementptr { i64, [1 x i64] }, ptr %t189, i32 0, i32 0
  store i64 0, ptr %t190
  %t192 = insertvalue { i32 } undef, i32 %t188, 0
  %t193 = getelementptr { i64, [1 x i64] }, ptr %t189, i32 0, i32 1
  store { i32 } %t192, ptr %t193
  %t194 = load { i64, [1 x i64] }, ptr %t189
  store { i64, [1 x i64] } %t194, ptr %l17
  %t196 = load ptr, ptr %l4, !tbaa !29
  %t198 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s0, ptr %t196, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d33, i32 0, i32 1) })
  store i32 %t198, ptr %l110
  br label %bb39
bb39:
  %t199 = load i32, ptr %l110, !tbaa !23
  %t200 = load ptr, ptr %l4, !tbaa !29
  store ptr %t200, ptr %l111, !tbaa !29
  %t201 = load ptr, ptr %l4, !tbaa !29
  %t205 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArray(ptr %v0, ptr %t201, i32 %t199, i32 0)
  store i32 %t205, ptr %l114
  br label %bb40
bb40:
  %t206 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t207 = load ptr, ptr %l111, !tbaa !29
  %t208 = load i32, ptr %l114, !tbaa !23
  %t210 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t207, i32 %t208, i64 %t206)
  store i32 %t210, ptr %l116
  br label %bb41
bb41:
  %t211 = load i32, ptr %l116, !tbaa !23
  store i32 %t211, ptr %l19, !tbaa !23
  store i64 0, ptr %l20, !tbaa !24
  %t212 = load ptr, ptr %l1, !tbaa !29
  %t214 = getelementptr %"compiler/typed:Text", ptr %t212, i32 0, i32 0
  %t215 = load { i64, ptr }, ptr %t214, !tbaa !27
  %t217 = extractvalue { i64, ptr } %t215, 0
  store i64 %t217, ptr %l21, !tbaa !24
  store i64 1, ptr %l22, !tbaa !24
  %t219 = load i64, ptr %l21, !tbaa !24
  %t220 = load i64, ptr %l20, !tbaa !24
  %t223 = icmp sgt i64 %t219, %t220
  br i1 %t223, label %bb42, label %bb43
bb42:
  %t225 = load i64, ptr %l22, !tbaa !24
  %t227 = icmp sgt i64 %t225, 0
  br i1 %t227, label %bb44, label %bb45
bb43:
  store i64 0, ptr %l123, !tbaa !24
  br label %bb47
bb44:
  %t229 = load i64, ptr %l21, !tbaa !24
  %t230 = load i64, ptr %l20, !tbaa !24
  %t233 = sub i64 %t229, %t230
  %t234 = load i64, ptr %l22, !tbaa !24
  %t237 = add i64 %t233, %t234
  %t239 = sub i64 %t237, 1
  %t240 = load i64, ptr %l22, !tbaa !24
  %t243 = sdiv i64 %t239, %t240
  store i64 %t243, ptr %l126, !tbaa !24
  br label %bb46
bb45:
  store i64 0, ptr %l126, !tbaa !24
  br label %bb46
bb46:
  %t245 = load i64, ptr %l126, !tbaa !24
  store i64 %t245, ptr %l123, !tbaa !24
  br label %bb47
bb47:
  %t246 = load i64, ptr %l123, !tbaa !24
  store i64 %t246, ptr %l23, !tbaa !24
  store i64 0, ptr %l24, !tbaa !24
  br label %bb48
bb48:
  store %olang.scope zeroinitializer, ptr %s8
  %t247 = load i64, ptr %l24, !tbaa !24
  %t248 = load i64, ptr %l23, !tbaa !24
  %t251 = icmp slt i64 %t247, %t248
  %t253 = xor i1 %t251, true
  br i1 %t253, label %bb49, label %bb50
bb49:
  call void @__olang_scope_close(ptr %s8)
  br label %bb69
bb50:
  br label %bb51
bb51:
  %t255 = load i64, ptr %l20, !tbaa !24
  %t256 = load i64, ptr %l24, !tbaa !24
  %t257 = load i64, ptr %l22, !tbaa !24
  %t260 = mul i64 %t256, %t257
  %t263 = add i64 %t255, %t260
  store i64 %t263, ptr %l25, !tbaa !24
  %t265 = load ptr, ptr %l1, !tbaa !29
  %t267 = getelementptr %"compiler/typed:Text", ptr %t265, i32 0, i32 0
  %t268 = load { i64, ptr }, ptr %t267, !tbaa !27
  store { i64, ptr } %t268, ptr %l145, !tbaa !27
  %t269 = load i64, ptr %l25, !tbaa !24
  %t271 = getelementptr { i64, ptr }, ptr %l145, i32 0, i32 1
  %t272 = load ptr, ptr %t271, !tbaa !27
  %t273 = getelementptr ptr, ptr %t272, i64 %t269
  %t274 = load ptr, ptr %t273, !tbaa !39
  store ptr %t274, ptr %l26, !tbaa !29
  %t276 = load ptr, ptr %l26, !tbaa !29
  store ptr %t276, ptr %l148, !tbaa !29
  store i1 false, ptr %l149, !tbaa !21
  %t277 = load ptr, ptr %l148, !tbaa !29
  %t278 = icmp ne ptr %t277, null
  br i1 %t278, label %bb52, label %bb53
bb52:
  %t280 = load ptr, ptr %l148, !tbaa !29
  %t281 = load i64, ptr %t280
  %t283 = icmp eq i64 %t281, 0
  store i1 %t283, ptr %l149, !tbaa !21
  br label %bb53
bb53:
  %t284 = load i1, ptr %l149, !tbaa !21
  br i1 %t284, label %bb54, label %bb55
bb54:
  %t285 = load ptr, ptr %l26, !tbaa !29
  %t287 = getelementptr { i64, [2 x i64] }, ptr %t285, i32 0, i32 1
  %t288 = getelementptr { { i64, ptr } }, ptr %t287, i32 0, i32 0
  %t289 = load { i64, ptr }, ptr %t288
  store { i64, ptr } %t289, ptr %l27, !tbaa !27
  br label %bb56
bb55:
  br label %bb59
bb56:
  store %olang.scope zeroinitializer, ptr %s9
  %t291 = load ptr, ptr %l0, !tbaa !29
  %t293 = getelementptr %"compiler/lower:lowering", ptr %t291, i32 0, i32 3
  %t294 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, [2 x i64] } zeroinitializer, ptr %t295
  %t296 = getelementptr { i64, [2 x i64] }, ptr %t295, i32 0, i32 0
  store i64 1, ptr %t296
  %t298 = insertvalue { { i64, ptr } } undef, { i64, ptr } %t294, 0
  %t299 = getelementptr { i64, [2 x i64] }, ptr %t295, i32 0, i32 1
  store { { i64, ptr } } %t298, ptr %t299
  %t300 = load { i64, [2 x i64] }, ptr %t295
  %t302 = call ptr @__olang_scope_alloc_a(ptr %s9, i64 24, i64 8)
  store { i64, [2 x i64] } %t300, ptr %t302
  %t305 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddConst(ptr %v0, ptr %s9, ptr %t293, ptr %t302)
  store i32 %t305, ptr %l159
  br label %bb57
bb57:
  %t306 = load i32, ptr %l159, !tbaa !23
  %t307 = load ptr, ptr %l0, !tbaa !29
  %t308 = load %"compiler/source:Span", ptr %l3
  %t309 = load { i64, [1 x i64] }, ptr %l17
  %t310 = load i32, ptr %l19, !tbaa !23
  %t312 = load ptr, ptr %l0, !tbaa !29
  %t314 = getelementptr %"compiler/lower:lowering", ptr %t312, i32 0, i32 4
  %t315 = load i64, ptr %t314, !tbaa !24
  %t316 = load %"compiler/source:Span", ptr %l3
  store { i64, [4 x i64] } zeroinitializer, ptr %t317
  %t318 = getelementptr { i64, [4 x i64] }, ptr %t317, i32 0, i32 0
  store i64 3, ptr %t318
  %t320 = insertvalue { i32, i32, i64, %"compiler/source:Span" } undef, i32 %t310, 0
  %t322 = insertvalue { i32, i32, i64, %"compiler/source:Span" } %t320, i32 %t306, 1
  %t324 = insertvalue { i32, i32, i64, %"compiler/source:Span" } %t322, i64 %t315, 2
  %t326 = insertvalue { i32, i32, i64, %"compiler/source:Span" } %t324, %"compiler/source:Span" %t316, 3
  %t327 = getelementptr { i64, [4 x i64] }, ptr %t317, i32 0, i32 1
  store { i32, i32, i64, %"compiler/source:Span" } %t326, ptr %t327
  %t328 = load { i64, [4 x i64] }, ptr %t317
  store { i64, [21 x i64] } zeroinitializer, ptr %t329
  %t330 = getelementptr { i64, [21 x i64] }, ptr %t329, i32 0, i32 0
  store i64 9, ptr %t330
  %t332 = insertvalue { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } undef, %"compiler/source:Span" %t308, 0
  %t334 = insertvalue { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } %t332, { i64, [1 x i64] } %t309, 1
  %t336 = insertvalue { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } %t334, i32 0, 2
  %t338 = insertvalue { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } %t336, { i64, [4 x i64] } %t328, 3
  %t339 = getelementptr { i64, [21 x i64] }, ptr %t329, i32 0, i32 1
  store { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } %t338, ptr %t339
  %t340 = load { i64, [21 x i64] }, ptr %t329
  %t342 = call ptr @__olang_scope_alloc_a(ptr %s9, i64 176, i64 8)
  store { i64, [21 x i64] } %t340, ptr %t342
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s9, ptr %t307, ptr %t342)
  br label %bb58
bb58:
  call void @__olang_scope_close(ptr %s9)
  br label %bb67
bb59:
  %t345 = load ptr, ptr %l26, !tbaa !29
  store ptr %t345, ptr %l172, !tbaa !29
  store i1 false, ptr %l173, !tbaa !21
  %t346 = load ptr, ptr %l172, !tbaa !29
  %t347 = icmp ne ptr %t346, null
  br i1 %t347, label %bb60, label %bb61
bb60:
  %t349 = load ptr, ptr %l172, !tbaa !29
  %t350 = load i64, ptr %t349
  %t352 = icmp eq i64 %t350, 1
  store i1 %t352, ptr %l173, !tbaa !21
  br label %bb61
bb61:
  %t353 = load i1, ptr %l173, !tbaa !21
  br i1 %t353, label %bb62, label %bb63
bb62:
  br label %bb64
bb63:
  br label %bb66
bb64:
  %t354 = load ptr, ptr %l0, !tbaa !29
  %t355 = load { i64, [1 x i64] }, ptr %l17
  %t356 = load i64, ptr %l25, !tbaa !24
  %t358 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t359 = load ptr, ptr %t358, !tbaa !27
  %t360 = getelementptr { i64, [4 x i64] }, ptr %t359, i64 %t356
  %t361 = load { i64, [4 x i64] }, ptr %t360
  %t362 = load i64, ptr %l25, !tbaa !24
  %t364 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t365 = load ptr, ptr %t364, !tbaa !27
  %t366 = getelementptr i32, ptr %t365, i64 %t362
  %t367 = load i32, ptr %t366, !tbaa !33
  %t368 = load %"compiler/source:Span", ptr %l3
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2erender(ptr %v0, ptr %t354, { i64, [1 x i64] } %t355, { i64, [4 x i64] } %t361, i32 %t367, %"compiler/source:Span" %t368)
  br label %bb65
bb65:
  br label %bb67
bb66:
  call void @__olang_check_failed(ptr @olang_loc_3db4c7c32145727f_d6a525f06b7a698b)
  unreachable
bb67:
  call void @__olang_scope_close(ptr %s8)
  br label %bb68
bb68:
  %t374 = load i64, ptr %l24, !tbaa !24
  %t376 = add i64 %t374, 1
  store i64 %t376, ptr %l24, !tbaa !24
  br label %bb48
bb69:
  %t378 = load ptr, ptr %l0, !tbaa !29
  store ptr %t378, ptr %l185, !tbaa !29
  %t379 = load i32, ptr %l2, !tbaa !23
  store i32 %t379, ptr %l186, !tbaa !23
  %t380 = load { i64, [1 x i64] }, ptr %l17
  store { i64, [1 x i64] } %t380, ptr %l187
  %t381 = load ptr, ptr %l0, !tbaa !29
  %t382 = load ptr, ptr %l1, !tbaa !29
  %t384 = getelementptr %"compiler/typed:Text", ptr %t382, i32 0, i32 1
  %t385 = load i32, ptr %t384, !tbaa !23
  %t388 = call { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ebuilt(ptr %v0, ptr %t381, i32 %t385)
  store { i64, [1 x i64] } %t388, ptr %l191
  br label %bb70
bb70:
  %t389 = load i32, ptr %l2, !tbaa !23
  store { i64, [15 x i64] } zeroinitializer, ptr %t390
  %t391 = getelementptr { i64, [15 x i64] }, ptr %t390, i32 0, i32 0
  store i64 12, ptr %t391
  %t392 = load { i64, [1 x i64] }, ptr %l187
  %t393 = insertvalue { { i64, [1 x i64] }, { i64, [1 x i64] }, i32 } undef, { i64, [1 x i64] } %t392, 0
  %t394 = load { i64, [1 x i64] }, ptr %l191
  %t395 = insertvalue { { i64, [1 x i64] }, { i64, [1 x i64] }, i32 } %t393, { i64, [1 x i64] } %t394, 1
  %t397 = insertvalue { { i64, [1 x i64] }, { i64, [1 x i64] }, i32 } %t395, i32 %t389, 2
  %t398 = getelementptr { i64, [15 x i64] }, ptr %t390, i32 0, i32 1
  store { { i64, [1 x i64] }, { i64, [1 x i64] }, i32 } %t397, ptr %t398
  %t399 = load { i64, [15 x i64] }, ptr %t390
  %t400 = load %"compiler/source:Span", ptr %l3
  %t401 = load ptr, ptr %l185, !tbaa !29
  %t402 = load i32, ptr %l186, !tbaa !23
  %t405 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %t401, i32 %t402, { i64, [15 x i64] } %t399, %"compiler/source:Span" %t400)
  store { i64, [4 x i64] } %t405, ptr %l195
  br label %bb71
bb71:
  %t406 = load { i64, [4 x i64] }, ptr %l195
  store { i64, [4 x i64] } %t406, ptr %l29
  %t407 = load ptr, ptr %l0, !tbaa !29
  %t408 = load %"compiler/source:Span", ptr %l3
  %t409 = load i32, ptr %l16, !tbaa !23
  store { i64, [21 x i64] } zeroinitializer, ptr %t410
  %t411 = getelementptr { i64, [21 x i64] }, ptr %t410, i32 0, i32 0
  store i64 4, ptr %t411
  %t413 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t408, 0
  %t415 = insertvalue { %"compiler/source:Span", i32 } %t413, i32 %t409, 1
  %t416 = getelementptr { i64, [21 x i64] }, ptr %t410, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t415, ptr %t416
  %t417 = load { i64, [21 x i64] }, ptr %t410
  %t419 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t417, ptr %t419
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s0, ptr %t407, ptr %t419)
  br label %bb72
bb72:
  %t422 = load { i64, [4 x i64] }, ptr %l29
  call void @__olang_scope_close(ptr %s0)
  store { i64, [4 x i64] } %t422, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2etextData(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i32
  %l10 = alloca i32
  %l12 = alloca ptr
  %l15 = alloca i32
  %l17 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca { i64, [4 x i64] }
  %t6 = alloca { i64, [2 x i64] }, align 8
  %t39 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 3
  store { i64, [2 x i64] } zeroinitializer, ptr %t6
  %t7 = getelementptr { i64, [2 x i64] }, ptr %t6, i32 0, i32 0
  store i64 1, ptr %t7
  %t9 = insertvalue { { i64, ptr } } undef, { i64, ptr } %a1, 0
  %t10 = getelementptr { i64, [2 x i64] }, ptr %t6, i32 0, i32 1
  store { { i64, ptr } } %t9, ptr %t10
  %t11 = load { i64, [2 x i64] }, ptr %t6
  %t13 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 24, i64 8)
  store { i64, [2 x i64] } %t11, ptr %t13
  %t16 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddConst(ptr %v0, ptr %s0, ptr %t3, ptr %t13)
  store i32 %t16, ptr %l10
  br label %bb1
bb1:
  %t17 = load i32, ptr %l10, !tbaa !23
  store i32 %t17, ptr %l3, !tbaa !23
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/lower:lowering", ptr %t18, i32 0, i32 2
  %t21 = load ptr, ptr %t20, !tbaa !29
  store ptr %t21, ptr %l12, !tbaa !29
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/lower:lowering", ptr %t22, i32 0, i32 0
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t27 = call i32 @compiler_2flower_2ecompiler_2flower_3aLowerer_2etext(ptr %v0, ptr %t25)
  store i32 %t27, ptr %l15
  br label %bb2
bb2:
  %t28 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t29 = load ptr, ptr %l12, !tbaa !29
  %t30 = load i32, ptr %l15, !tbaa !23
  %t32 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t29, i32 %t30, i64 %t28)
  store i32 %t32, ptr %l17
  br label %bb3
bb3:
  %t33 = load i32, ptr %l3, !tbaa !23
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/lower:lowering", ptr %t34, i32 0, i32 4
  %t37 = load i64, ptr %t36, !tbaa !24
  store { i64, [4 x i64] } zeroinitializer, ptr %t39
  %t40 = getelementptr { i64, [4 x i64] }, ptr %t39, i32 0, i32 0
  store i64 3, ptr %t40
  %t41 = load i32, ptr %l17, !tbaa !23
  %t42 = insertvalue { i32, i32, i64, %"compiler/source:Span" } undef, i32 %t41, 0
  %t44 = insertvalue { i32, i32, i64, %"compiler/source:Span" } %t42, i32 %t33, 1
  %t46 = insertvalue { i32, i32, i64, %"compiler/source:Span" } %t44, i64 %t37, 2
  %t48 = insertvalue { i32, i32, i64, %"compiler/source:Span" } %t46, %"compiler/source:Span" %a2, 3
  %t49 = getelementptr { i64, [4 x i64] }, ptr %t39, i32 0, i32 1
  store { i32, i32, i64, %"compiler/source:Span" } %t48, ptr %t49
  %t50 = load { i64, [4 x i64] }, ptr %t39
  call void @__olang_scope_close(ptr %s0)
  store { i64, [4 x i64] } %t50, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca { i64, [4 x i64] }
  %l6 = alloca i1
  %l12 = alloca i64
  %l17 = alloca { i64, [4 x i64] }
  %l20 = alloca { i64, [1 x i64] }
  %l23 = alloca { i64, [4 x i64] }
  %l27 = alloca i1
  %rv = alloca { i64, [4 x i64] }
  %t11 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 7
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb3
bb2:
  %t6 = load ptr, ptr %l1, !tbaa !29
  %t8 = icmp eq ptr %t6, null
  store i1 %t8, ptr %l6, !tbaa !21
  br label %bb3
bb3:
  %t10 = load i1, ptr %l6, !tbaa !21
  br i1 %t10, label %bb4, label %bb5
bb4:
  store { i64, [4 x i64] } zeroinitializer, ptr %t11
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t11, i32 0, i32 0
  store i64 0, ptr %t12
  %t13 = load { i64, [4 x i64] }, ptr %t11
  store { i64, [4 x i64] } %t13, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t19 = call i64 @compiler_2flower_2ecompiler_2flower_3alowering_2eregionSite(ptr %v0, ptr %v1, ptr %t15, ptr %t16)
  store i64 %t19, ptr %l12
  br label %bb7
bb7:
  %t20 = load i64, ptr %l12, !tbaa !24
  store i64 %t20, ptr %l2, !tbaa !24
  %t21 = load i64, ptr %l2, !tbaa !24
  %t23 = icmp slt i64 %t21, 0
  br i1 %t23, label %bb8, label %bb9
bb8:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t26 = load ptr, ptr %l1, !tbaa !29
  %t29 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2evalue(ptr %v0, ptr %v1, ptr %t25, ptr %t26)
  store { i64, [4 x i64] } %t29, ptr %l17
  br label %bb10
bb9:
  br label %bb11
bb10:
  %t30 = load { i64, [4 x i64] }, ptr %l17
  store { i64, [4 x i64] } %t30, ptr %rv
  br label %ret
bb11:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load i64, ptr %l2, !tbaa !24
  %t35 = call { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eregionOf(ptr %v0, ptr %t31, i64 %t32)
  store { i64, [1 x i64] } %t35, ptr %l20
  br label %bb12
bb12:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t37 = load ptr, ptr %l1, !tbaa !29
  %t40 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2evalue(ptr %v0, ptr %v1, ptr %t36, ptr %t37)
  store { i64, [4 x i64] } %t40, ptr %l23
  br label %bb13
bb13:
  %t41 = load { i64, [4 x i64] }, ptr %l23
  store { i64, [4 x i64] } %t41, ptr %l3
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/lower:lowering", ptr %t42, i32 0, i32 24
  %t45 = load i64, ptr %l2, !tbaa !24
  %t48 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fmir_3aLocalId_3e_2_Hf0fb0e232c68e27195d0770621b0035a(ptr %v0, ptr %t44, i64 %t45)
  store i1 %t48, ptr %l27
  br label %bb14
bb14:
  %t49 = load { i64, [4 x i64] }, ptr %l3
  store { i64, [4 x i64] } %t49, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local { i64, ptr } @compiler_2flower_2ecompiler_2flower_3alowering_2evals(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %lp2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l10 = alloca i64
  %l19 = alloca i64
  %l22 = alloca i64
  %l40 = alloca i64
  %l42 = alloca { i64, ptr }
  %l46 = alloca { i64, [4 x i64] }
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  store i64 %t3, ptr %l10, !tbaa !24
  %t4 = load i64, ptr %l10, !tbaa !24
  %t5 = icmp sge i64 %t4, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load i64, ptr %l10, !tbaa !24
  %t8 = icmp sle i64 %t7, 230584300921369395
  br i1 %t8, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_73384406ab4916da_7af5324ba56268d6)
  unreachable
bb3:
  %t10 = load i64, ptr %l10, !tbaa !24
  %t11 = mul i64 %t10, 40
  %t12 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t11)
  %t13 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  %t15 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 16, i64 8)
  store ptr %t15, ptr %lp2
  %t17 = load ptr, ptr %lp2
  store { i64, ptr } %t14, ptr %t17, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t18 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t20 = extractvalue { i64, ptr } %t18, 0
  store i64 %t20, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t22 = load i64, ptr %l4, !tbaa !24
  %t23 = load i64, ptr %l3, !tbaa !24
  %t26 = icmp sgt i64 %t22, %t23
  br i1 %t26, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_73384406ab4916da_7af5324ba56268d6)
  unreachable
bb5:
  %t28 = load i64, ptr %l5, !tbaa !24
  %t30 = icmp sgt i64 %t28, 0
  br i1 %t30, label %bb7, label %bb8
bb6:
  store i64 0, ptr %l19, !tbaa !24
  br label %bb10
bb7:
  %t32 = load i64, ptr %l4, !tbaa !24
  %t33 = load i64, ptr %l3, !tbaa !24
  %t36 = sub i64 %t32, %t33
  %t37 = load i64, ptr %l5, !tbaa !24
  %t40 = add i64 %t36, %t37
  %t42 = sub i64 %t40, 1
  %t43 = load i64, ptr %l5, !tbaa !24
  %t46 = sdiv i64 %t42, %t43
  store i64 %t46, ptr %l22, !tbaa !24
  br label %bb9
bb8:
  store i64 0, ptr %l22, !tbaa !24
  br label %bb9
bb9:
  %t48 = load i64, ptr %l22, !tbaa !24
  store i64 %t48, ptr %l19, !tbaa !24
  br label %bb10
bb10:
  %t49 = load i64, ptr %l19, !tbaa !24
  store i64 %t49, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb11
bb11:
  store %olang.scope zeroinitializer, ptr %s2
  %t50 = load i64, ptr %l7, !tbaa !24
  %t51 = load i64, ptr %l6, !tbaa !24
  %t54 = icmp slt i64 %t50, %t51
  %t56 = xor i1 %t54, true
  br i1 %t56, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s2)
  br label %bb17
bb13:
  br label %bb14
bb14:
  %t58 = load i64, ptr %l3, !tbaa !24
  %t59 = load i64, ptr %l7, !tbaa !24
  %t60 = load i64, ptr %l5, !tbaa !24
  %t63 = mul i64 %t59, %t60
  %t66 = add i64 %t58, %t63
  store i64 %t66, ptr %l8, !tbaa !24
  %t68 = load i64, ptr %l8, !tbaa !24
  store i64 %t68, ptr %l40, !tbaa !24
  %t70 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t70, ptr %l42, !tbaa !27
  %t71 = load i64, ptr %l8, !tbaa !24
  %t73 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t74 = load ptr, ptr %t73, !tbaa !27
  %t75 = getelementptr ptr, ptr %t74, i64 %t71
  %t76 = load ptr, ptr %t75, !tbaa !39
  %t80 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v1, ptr %a0, ptr %t76)
  store { i64, [4 x i64] } %t80, ptr %l46
  br label %bb15
bb15:
  %t81 = load { i64, [4 x i64] }, ptr %l46
  %t82 = load ptr, ptr %lp2
  %t83 = load i64, ptr %l40, !tbaa !24
  %t84 = getelementptr { i64, ptr }, ptr %t82, i32 0, i32 1
  %t85 = load ptr, ptr %t84, !tbaa !27
  %t86 = getelementptr { i64, [4 x i64] }, ptr %t85, i64 %t83
  store { i64, [4 x i64] } %t81, ptr %t86
  call void @__olang_scope_close(ptr %s2)
  br label %bb16
bb16:
  %t87 = load i64, ptr %l7, !tbaa !24
  %t89 = add i64 %t87, 1
  store i64 %t89, ptr %l7, !tbaa !24
  br label %bb11
bb17:
  %t91 = load ptr, ptr %lp2
  %t92 = load { i64, ptr }, ptr %t91, !tbaa !27
  store { i64, ptr } %t92, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2evalue(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca i64
  %l6 = alloca %"compiler/source:Span"
  %l7 = alloca i32
  %l8 = alloca ptr
  %l9 = alloca %"compiler/source:Span"
  %l10 = alloca i32
  %l11 = alloca ptr
  %l12 = alloca %"compiler/source:Span"
  %l13 = alloca i32
  %l14 = alloca ptr
  %l15 = alloca %"compiler/source:Span"
  %l16 = alloca i32
  %l17 = alloca ptr
  %l18 = alloca %"compiler/source:Span"
  %l19 = alloca i32
  %l20 = alloca ptr
  %l21 = alloca %"compiler/source:Span"
  %l22 = alloca i32
  %l23 = alloca ptr
  %l24 = alloca %"compiler/source:Span"
  %l25 = alloca i32
  %l26 = alloca ptr
  %l27 = alloca %"compiler/source:Span"
  %l28 = alloca i32
  %l29 = alloca ptr
  %l30 = alloca %"compiler/source:Span"
  %l31 = alloca i32
  %l32 = alloca i32
  %l33 = alloca i32
  %l34 = alloca { i64, ptr }
  %l35 = alloca %"compiler/source:Span"
  %l36 = alloca i32
  %l37 = alloca ptr
  %l38 = alloca %"compiler/source:Span"
  %l39 = alloca i32
  %l40 = alloca ptr
  %l41 = alloca ptr
  %l42 = alloca %"compiler/source:Span"
  %l43 = alloca i32
  %l44 = alloca ptr
  %l45 = alloca %"compiler/source:Span"
  %l46 = alloca ptr
  %l47 = alloca %"compiler/source:Span"
  %l48 = alloca i32
  %l49 = alloca ptr
  %l50 = alloca %"compiler/source:Span"
  %l51 = alloca i32
  %l52 = alloca ptr
  %l53 = alloca i64
  %l54 = alloca ptr
  %l58 = alloca i32
  %l62 = alloca ptr
  %l64 = alloca %"compiler/source:Span"
  %l66 = alloca { i64, [4 x i64] }
  %l67 = alloca ptr
  %l68 = alloca i1
  %l78 = alloca ptr
  %l79 = alloca i1
  %l88 = alloca i32
  %l92 = alloca i32
  %l97 = alloca ptr
  %l98 = alloca i1
  %l111 = alloca { i64, [4 x i64] }
  %l112 = alloca ptr
  %l113 = alloca i1
  %l122 = alloca ptr
  %l123 = alloca i32
  %l124 = alloca ptr
  %l128 = alloca %"compiler/lower:pl"
  %l129 = alloca %"compiler/mir:Place"
  %l133 = alloca { i64, [4 x i64] }
  %l134 = alloca ptr
  %l135 = alloca i1
  %l148 = alloca { i64, [4 x i64] }
  %l149 = alloca ptr
  %l150 = alloca i1
  %l163 = alloca { i64, [4 x i64] }
  %l164 = alloca ptr
  %l165 = alloca i1
  %l178 = alloca { i64, [4 x i64] }
  %l179 = alloca ptr
  %l180 = alloca i1
  %l193 = alloca { i64, [4 x i64] }
  %l194 = alloca ptr
  %l195 = alloca i1
  %l208 = alloca { i64, [4 x i64] }
  %l209 = alloca ptr
  %l210 = alloca i1
  %l229 = alloca { i64, [4 x i64] }
  %l230 = alloca ptr
  %l231 = alloca i1
  %l244 = alloca { i64, [4 x i64] }
  %l245 = alloca ptr
  %l246 = alloca i1
  %l259 = alloca { i64, [4 x i64] }
  %l260 = alloca ptr
  %l261 = alloca i1
  %l268 = alloca { i64, [4 x i64] }
  %l269 = alloca ptr
  %l270 = alloca i1
  %l283 = alloca { i64, [4 x i64] }
  %l284 = alloca ptr
  %l285 = alloca i1
  %l296 = alloca { i64, [4 x i64] }
  %l297 = alloca ptr
  %l298 = alloca i1
  %l311 = alloca { i64, [4 x i64] }
  %l312 = alloca ptr
  %l313 = alloca i1
  %l326 = alloca { i64, [4 x i64] }
  %l327 = alloca ptr
  %l328 = alloca i1
  %l338 = alloca { i64, [4 x i64] }
  %s1 = alloca %olang.scope
  %rv = alloca { i64, [4 x i64] }
  %t22 = alloca { i64, [4 x i64] }, align 8
  %t49 = alloca { i64, [4 x i64] }, align 8
  %t98 = alloca { i64, [4 x i64] }, align 8
  %t188 = alloca { i64, [15 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l1, !tbaa !29
  %t8 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t6)
  store i32 %t8, ptr %l58
  br label %bb1
bb1:
  %t9 = load i32, ptr %l58, !tbaa !23
  %t11 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t14 = icmp eq i32 %t9, %t11
  br i1 %t14, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t16 = load ptr, ptr %l0, !tbaa !29
  store ptr %t16, ptr %l62, !tbaa !29
  %t17 = load ptr, ptr %l1, !tbaa !29
  %t19 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v1, ptr %t17)
  store %"compiler/source:Span" %t19, ptr %l64
  br label %bb4
bb3:
  br label %bb6
bb4:
  %t20 = load ptr, ptr %l62, !tbaa !29
  %t21 = load %"compiler/source:Span", ptr %l64
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2egap(ptr %v0, ptr %s1, ptr %t20, %"compiler/source:Span" %t21, { i64, ptr } { i64 53, ptr getelementptr inbounds (<{ i64, [53 x i8] }>, ptr @.d34, i32 0, i32 1) })
  br label %bb5
bb5:
  store { i64, [4 x i64] } zeroinitializer, ptr %t22
  %t23 = getelementptr { i64, [4 x i64] }, ptr %t22, i32 0, i32 0
  store i64 0, ptr %t23
  %t24 = load { i64, [4 x i64] }, ptr %t22
  call void @__olang_scope_close(ptr %s1)
  store { i64, [4 x i64] } %t24, ptr %rv
  br label %ret
bb6:
  %t26 = load ptr, ptr %l1, !tbaa !29
  store ptr %t26, ptr %l67, !tbaa !29
  store i1 false, ptr %l68, !tbaa !21
  %t27 = load ptr, ptr %l67, !tbaa !29
  %t28 = icmp ne ptr %t27, null
  br i1 %t28, label %bb7, label %bb8
bb7:
  %t30 = load ptr, ptr %l67, !tbaa !29
  %t31 = load i64, ptr %t30
  %t33 = icmp eq i64 %t31, 0
  store i1 %t33, ptr %l68, !tbaa !21
  br label %bb8
bb8:
  %t34 = load i1, ptr %l68, !tbaa !21
  br i1 %t34, label %bb9, label %bb10
bb9:
  %t35 = load ptr, ptr %l1, !tbaa !29
  %t37 = getelementptr { i64, [5 x i64] }, ptr %t35, i32 0, i32 1
  %t38 = getelementptr { %"compiler/source:Span", i32, i64 }, ptr %t37, i32 0, i32 1
  %t39 = load i32, ptr %t38
  store i32 %t39, ptr %l4, !tbaa !23
  %t41 = load ptr, ptr %l1, !tbaa !29
  %t43 = getelementptr { i64, [5 x i64] }, ptr %t41, i32 0, i32 1
  %t44 = getelementptr { %"compiler/source:Span", i32, i64 }, ptr %t43, i32 0, i32 2
  %t45 = load i64, ptr %t44
  store i64 %t45, ptr %l5, !tbaa !24
  br label %bb11
bb10:
  br label %bb12
bb11:
  %t47 = load i32, ptr %l4, !tbaa !23
  %t48 = load i64, ptr %l5, !tbaa !24
  store { i64, [4 x i64] } zeroinitializer, ptr %t49
  %t50 = getelementptr { i64, [4 x i64] }, ptr %t49, i32 0, i32 0
  store i64 2, ptr %t50
  %t52 = insertvalue { i32, i64 } undef, i32 %t47, 0
  %t54 = insertvalue { i32, i64 } %t52, i64 %t48, 1
  %t55 = getelementptr { i64, [4 x i64] }, ptr %t49, i32 0, i32 1
  store { i32, i64 } %t54, ptr %t55
  %t56 = load { i64, [4 x i64] }, ptr %t49
  store { i64, [4 x i64] } %t56, ptr %l66
  br label %bb134
bb12:
  %t58 = load ptr, ptr %l1, !tbaa !29
  store ptr %t58, ptr %l78, !tbaa !29
  store i1 false, ptr %l79, !tbaa !21
  %t59 = load ptr, ptr %l78, !tbaa !29
  %t60 = icmp ne ptr %t59, null
  br i1 %t60, label %bb13, label %bb14
bb13:
  %t62 = load ptr, ptr %l78, !tbaa !29
  %t63 = load i64, ptr %t62
  %t65 = icmp eq i64 %t63, 1
  store i1 %t65, ptr %l79, !tbaa !21
  br label %bb14
bb14:
  %t66 = load i1, ptr %l79, !tbaa !21
  br i1 %t66, label %bb15, label %bb16
bb15:
  %t67 = load ptr, ptr %l1, !tbaa !29
  %t69 = getelementptr { i64, [5 x i64] }, ptr %t67, i32 0, i32 1
  %t70 = getelementptr { %"compiler/source:Span", i32, i64, ptr }, ptr %t69, i32 0, i32 0
  %t71 = load %"compiler/source:Span", ptr %t70
  store %"compiler/source:Span" %t71, ptr %l6
  %t73 = load ptr, ptr %l1, !tbaa !29
  %t75 = getelementptr { i64, [5 x i64] }, ptr %t73, i32 0, i32 1
  %t76 = getelementptr { %"compiler/source:Span", i32, i64, ptr }, ptr %t75, i32 0, i32 1
  %t77 = load i32, ptr %t76
  store i32 %t77, ptr %l7, !tbaa !23
  %t79 = load ptr, ptr %l1, !tbaa !29
  %t81 = getelementptr { i64, [5 x i64] }, ptr %t79, i32 0, i32 1
  %t82 = getelementptr { %"compiler/source:Span", i32, i64, ptr }, ptr %t81, i32 0, i32 3
  %t83 = load ptr, ptr %t82
  store ptr %t83, ptr %l8, !tbaa !29
  br label %bb17
bb16:
  br label %bb19
bb17:
  %t85 = load i32, ptr %l7, !tbaa !23
  store i32 %t85, ptr %l88, !tbaa !23
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t88 = getelementptr %"compiler/lower:lowering", ptr %t86, i32 0, i32 3
  %t89 = load ptr, ptr %l8, !tbaa !29
  %t92 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddConst(ptr %v0, ptr %v1, ptr %t88, ptr %t89)
  store i32 %t92, ptr %l92
  br label %bb18
bb18:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/lower:lowering", ptr %t93, i32 0, i32 4
  %t96 = load i64, ptr %t95, !tbaa !24
  %t97 = load %"compiler/source:Span", ptr %l6
  store { i64, [4 x i64] } zeroinitializer, ptr %t98
  %t99 = getelementptr { i64, [4 x i64] }, ptr %t98, i32 0, i32 0
  store i64 3, ptr %t99
  %t100 = load i32, ptr %l88, !tbaa !23
  %t101 = insertvalue { i32, i32, i64, %"compiler/source:Span" } undef, i32 %t100, 0
  %t102 = load i32, ptr %l92, !tbaa !23
  %t103 = insertvalue { i32, i32, i64, %"compiler/source:Span" } %t101, i32 %t102, 1
  %t105 = insertvalue { i32, i32, i64, %"compiler/source:Span" } %t103, i64 %t96, 2
  %t107 = insertvalue { i32, i32, i64, %"compiler/source:Span" } %t105, %"compiler/source:Span" %t97, 3
  %t108 = getelementptr { i64, [4 x i64] }, ptr %t98, i32 0, i32 1
  store { i32, i32, i64, %"compiler/source:Span" } %t107, ptr %t108
  %t109 = load { i64, [4 x i64] }, ptr %t98
  store { i64, [4 x i64] } %t109, ptr %l66
  br label %bb134
bb19:
  %t111 = load ptr, ptr %l1, !tbaa !29
  store ptr %t111, ptr %l97, !tbaa !29
  store i1 false, ptr %l98, !tbaa !21
  %t112 = load ptr, ptr %l97, !tbaa !29
  %t113 = icmp ne ptr %t112, null
  br i1 %t113, label %bb20, label %bb21
bb20:
  %t115 = load ptr, ptr %l97, !tbaa !29
  %t116 = load i64, ptr %t115
  %t118 = icmp eq i64 %t116, 2
  store i1 %t118, ptr %l98, !tbaa !21
  br label %bb21
bb21:
  %t119 = load i1, ptr %l98, !tbaa !21
  br i1 %t119, label %bb22, label %bb23
bb22:
  %t120 = load ptr, ptr %l1, !tbaa !29
  %t122 = getelementptr { i64, [5 x i64] }, ptr %t120, i32 0, i32 1
  %t123 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t122, i32 0, i32 0
  %t124 = load %"compiler/source:Span", ptr %t123
  store %"compiler/source:Span" %t124, ptr %l9
  %t126 = load ptr, ptr %l1, !tbaa !29
  %t128 = getelementptr { i64, [5 x i64] }, ptr %t126, i32 0, i32 1
  %t129 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t128, i32 0, i32 1
  %t130 = load i32, ptr %t129
  store i32 %t130, ptr %l10, !tbaa !23
  %t132 = load ptr, ptr %l1, !tbaa !29
  %t134 = getelementptr { i64, [5 x i64] }, ptr %t132, i32 0, i32 1
  %t135 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t134, i32 0, i32 2
  %t136 = load ptr, ptr %t135
  store ptr %t136, ptr %l11, !tbaa !29
  br label %bb24
bb23:
  br label %bb26
bb24:
  %t138 = load ptr, ptr %l0, !tbaa !29
  %t139 = load ptr, ptr %l11, !tbaa !29
  %t140 = load i32, ptr %l10, !tbaa !23
  %t141 = load %"compiler/source:Span", ptr %l9
  %t146 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eread(ptr %v0, ptr %v1, ptr %t138, ptr %t139, i32 %t140, %"compiler/source:Span" %t141)
  store { i64, [4 x i64] } %t146, ptr %l111
  br label %bb25
bb25:
  %t147 = load { i64, [4 x i64] }, ptr %l111
  store { i64, [4 x i64] } %t147, ptr %l66
  br label %bb134
bb26:
  %t148 = load ptr, ptr %l1, !tbaa !29
  store ptr %t148, ptr %l112, !tbaa !29
  store i1 false, ptr %l113, !tbaa !21
  %t149 = load ptr, ptr %l112, !tbaa !29
  %t150 = icmp ne ptr %t149, null
  br i1 %t150, label %bb27, label %bb28
bb27:
  %t152 = load ptr, ptr %l112, !tbaa !29
  %t153 = load i64, ptr %t152
  %t155 = icmp eq i64 %t153, 3
  store i1 %t155, ptr %l113, !tbaa !21
  br label %bb28
bb28:
  %t156 = load i1, ptr %l113, !tbaa !21
  br i1 %t156, label %bb29, label %bb30
bb29:
  %t157 = load ptr, ptr %l1, !tbaa !29
  %t159 = getelementptr { i64, [5 x i64] }, ptr %t157, i32 0, i32 1
  %t160 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t159, i32 0, i32 0
  %t161 = load %"compiler/source:Span", ptr %t160
  store %"compiler/source:Span" %t161, ptr %l12
  %t163 = load ptr, ptr %l1, !tbaa !29
  %t165 = getelementptr { i64, [5 x i64] }, ptr %t163, i32 0, i32 1
  %t166 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t165, i32 0, i32 1
  %t167 = load i32, ptr %t166
  store i32 %t167, ptr %l13, !tbaa !23
  %t169 = load ptr, ptr %l1, !tbaa !29
  %t171 = getelementptr { i64, [5 x i64] }, ptr %t169, i32 0, i32 1
  %t172 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t171, i32 0, i32 2
  %t173 = load ptr, ptr %t172
  store ptr %t173, ptr %l14, !tbaa !29
  br label %bb31
bb30:
  br label %bb35
bb31:
  %t175 = load ptr, ptr %l0, !tbaa !29
  store ptr %t175, ptr %l122, !tbaa !29
  %t176 = load i32, ptr %l13, !tbaa !23
  store i32 %t176, ptr %l123, !tbaa !23
  %t177 = load ptr, ptr %l0, !tbaa !29
  store ptr %t177, ptr %l124, !tbaa !29
  %t178 = load ptr, ptr %l0, !tbaa !29
  %t179 = load ptr, ptr %l14, !tbaa !29
  %t183 = call %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2eplace(ptr %v0, ptr %v1, ptr %v0, ptr %t178, ptr %t179)
  store %"compiler/lower:pl" %t183, ptr %l128
  br label %bb32
bb32:
  %t184 = load ptr, ptr %l124, !tbaa !29
  %t185 = load %"compiler/lower:pl", ptr %l128
  %t186 = call %"compiler/mir:Place" @compiler_2flower_2ecompiler_2flower_3alowering_2emk(ptr %v0, ptr %v0, ptr %t184, %"compiler/lower:pl" %t185)
  store %"compiler/mir:Place" %t186, ptr %l129
  br label %bb33
bb33:
  %t187 = load i32, ptr %l13, !tbaa !23
  store { i64, [15 x i64] } zeroinitializer, ptr %t188
  %t189 = getelementptr { i64, [15 x i64] }, ptr %t188, i32 0, i32 0
  store i64 1, ptr %t189
  %t190 = load %"compiler/mir:Place", ptr %l129
  %t191 = insertvalue { %"compiler/mir:Place", i32 } undef, %"compiler/mir:Place" %t190, 0
  %t193 = insertvalue { %"compiler/mir:Place", i32 } %t191, i32 %t187, 1
  %t194 = getelementptr { i64, [15 x i64] }, ptr %t188, i32 0, i32 1
  store { %"compiler/mir:Place", i32 } %t193, ptr %t194
  %t195 = load { i64, [15 x i64] }, ptr %t188
  %t196 = load %"compiler/source:Span", ptr %l12
  %t197 = load ptr, ptr %l122, !tbaa !29
  %t198 = load i32, ptr %l123, !tbaa !23
  %t201 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %t197, i32 %t198, { i64, [15 x i64] } %t195, %"compiler/source:Span" %t196)
  store { i64, [4 x i64] } %t201, ptr %l133
  br label %bb34
bb34:
  %t202 = load { i64, [4 x i64] }, ptr %l133
  store { i64, [4 x i64] } %t202, ptr %l66
  br label %bb134
bb35:
  %t203 = load ptr, ptr %l1, !tbaa !29
  store ptr %t203, ptr %l134, !tbaa !29
  store i1 false, ptr %l135, !tbaa !21
  %t204 = load ptr, ptr %l134, !tbaa !29
  %t205 = icmp ne ptr %t204, null
  br i1 %t205, label %bb36, label %bb37
bb36:
  %t207 = load ptr, ptr %l134, !tbaa !29
  %t208 = load i64, ptr %t207
  %t210 = icmp eq i64 %t208, 4
  store i1 %t210, ptr %l135, !tbaa !21
  br label %bb37
bb37:
  %t211 = load i1, ptr %l135, !tbaa !21
  br i1 %t211, label %bb38, label %bb39
bb38:
  %t212 = load ptr, ptr %l1, !tbaa !29
  %t214 = getelementptr { i64, [5 x i64] }, ptr %t212, i32 0, i32 1
  %t215 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t214, i32 0, i32 0
  %t216 = load %"compiler/source:Span", ptr %t215
  store %"compiler/source:Span" %t216, ptr %l15
  %t218 = load ptr, ptr %l1, !tbaa !29
  %t220 = getelementptr { i64, [5 x i64] }, ptr %t218, i32 0, i32 1
  %t221 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t220, i32 0, i32 1
  %t222 = load i32, ptr %t221
  store i32 %t222, ptr %l16, !tbaa !23
  %t224 = load ptr, ptr %l1, !tbaa !29
  %t226 = getelementptr { i64, [5 x i64] }, ptr %t224, i32 0, i32 1
  %t227 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t226, i32 0, i32 2
  %t228 = load ptr, ptr %t227
  store ptr %t228, ptr %l17, !tbaa !29
  br label %bb40
bb39:
  br label %bb42
bb40:
  %t230 = load ptr, ptr %l0, !tbaa !29
  %t231 = load ptr, ptr %l17, !tbaa !29
  %t232 = load i32, ptr %l16, !tbaa !23
  %t233 = load %"compiler/source:Span", ptr %l15
  %t238 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2etake(ptr %v0, ptr %v1, ptr %t230, ptr %t231, i32 %t232, %"compiler/source:Span" %t233)
  store { i64, [4 x i64] } %t238, ptr %l148
  br label %bb41
bb41:
  %t239 = load { i64, [4 x i64] }, ptr %l148
  store { i64, [4 x i64] } %t239, ptr %l66
  br label %bb134
bb42:
  %t240 = load ptr, ptr %l1, !tbaa !29
  store ptr %t240, ptr %l149, !tbaa !29
  store i1 false, ptr %l150, !tbaa !21
  %t241 = load ptr, ptr %l149, !tbaa !29
  %t242 = icmp ne ptr %t241, null
  br i1 %t242, label %bb43, label %bb44
bb43:
  %t244 = load ptr, ptr %l149, !tbaa !29
  %t245 = load i64, ptr %t244
  %t247 = icmp eq i64 %t245, 5
  store i1 %t247, ptr %l150, !tbaa !21
  br label %bb44
bb44:
  %t248 = load i1, ptr %l150, !tbaa !21
  br i1 %t248, label %bb45, label %bb46
bb45:
  %t249 = load ptr, ptr %l1, !tbaa !29
  %t251 = getelementptr { i64, [5 x i64] }, ptr %t249, i32 0, i32 1
  %t252 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t251, i32 0, i32 0
  %t253 = load %"compiler/source:Span", ptr %t252
  store %"compiler/source:Span" %t253, ptr %l18
  %t255 = load ptr, ptr %l1, !tbaa !29
  %t257 = getelementptr { i64, [5 x i64] }, ptr %t255, i32 0, i32 1
  %t258 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t257, i32 0, i32 1
  %t259 = load i32, ptr %t258
  store i32 %t259, ptr %l19, !tbaa !23
  %t261 = load ptr, ptr %l1, !tbaa !29
  %t263 = getelementptr { i64, [5 x i64] }, ptr %t261, i32 0, i32 1
  %t264 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t263, i32 0, i32 2
  %t265 = load ptr, ptr %t264
  store ptr %t265, ptr %l20, !tbaa !29
  br label %bb47
bb46:
  br label %bb49
bb47:
  %t267 = load ptr, ptr %l0, !tbaa !29
  %t268 = load ptr, ptr %l20, !tbaa !29
  %t269 = load i32, ptr %l19, !tbaa !23
  %t270 = load %"compiler/source:Span", ptr %l18
  %t275 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2epromote(ptr %v0, ptr %v1, ptr %t267, ptr %t268, i32 %t269, %"compiler/source:Span" %t270)
  store { i64, [4 x i64] } %t275, ptr %l163
  br label %bb48
bb48:
  %t276 = load { i64, [4 x i64] }, ptr %l163
  store { i64, [4 x i64] } %t276, ptr %l66
  br label %bb134
bb49:
  %t277 = load ptr, ptr %l1, !tbaa !29
  store ptr %t277, ptr %l164, !tbaa !29
  store i1 false, ptr %l165, !tbaa !21
  %t278 = load ptr, ptr %l164, !tbaa !29
  %t279 = icmp ne ptr %t278, null
  br i1 %t279, label %bb50, label %bb51
bb50:
  %t281 = load ptr, ptr %l164, !tbaa !29
  %t282 = load i64, ptr %t281
  %t284 = icmp eq i64 %t282, 6
  store i1 %t284, ptr %l165, !tbaa !21
  br label %bb51
bb51:
  %t285 = load i1, ptr %l165, !tbaa !21
  br i1 %t285, label %bb52, label %bb53
bb52:
  %t286 = load ptr, ptr %l1, !tbaa !29
  %t288 = getelementptr { i64, [5 x i64] }, ptr %t286, i32 0, i32 1
  %t289 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t288, i32 0, i32 0
  %t290 = load %"compiler/source:Span", ptr %t289
  store %"compiler/source:Span" %t290, ptr %l21
  %t292 = load ptr, ptr %l1, !tbaa !29
  %t294 = getelementptr { i64, [5 x i64] }, ptr %t292, i32 0, i32 1
  %t295 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t294, i32 0, i32 1
  %t296 = load i32, ptr %t295
  store i32 %t296, ptr %l22, !tbaa !23
  %t298 = load ptr, ptr %l1, !tbaa !29
  %t300 = getelementptr { i64, [5 x i64] }, ptr %t298, i32 0, i32 1
  %t301 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t300, i32 0, i32 2
  %t302 = load ptr, ptr %t301
  store ptr %t302, ptr %l23, !tbaa !29
  br label %bb54
bb53:
  br label %bb56
bb54:
  %t304 = load ptr, ptr %l0, !tbaa !29
  %t305 = load ptr, ptr %l23, !tbaa !29
  %t306 = load i32, ptr %l22, !tbaa !23
  %t307 = load %"compiler/source:Span", ptr %l21
  %t312 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ecall(ptr %v0, ptr %v1, ptr %t304, ptr %t305, i32 %t306, %"compiler/source:Span" %t307)
  store { i64, [4 x i64] } %t312, ptr %l178
  br label %bb55
bb55:
  %t313 = load { i64, [4 x i64] }, ptr %l178
  store { i64, [4 x i64] } %t313, ptr %l66
  br label %bb134
bb56:
  %t314 = load ptr, ptr %l1, !tbaa !29
  store ptr %t314, ptr %l179, !tbaa !29
  store i1 false, ptr %l180, !tbaa !21
  %t315 = load ptr, ptr %l179, !tbaa !29
  %t316 = icmp ne ptr %t315, null
  br i1 %t316, label %bb57, label %bb58
bb57:
  %t318 = load ptr, ptr %l179, !tbaa !29
  %t319 = load i64, ptr %t318
  %t321 = icmp eq i64 %t319, 7
  store i1 %t321, ptr %l180, !tbaa !21
  br label %bb58
bb58:
  %t322 = load i1, ptr %l180, !tbaa !21
  br i1 %t322, label %bb59, label %bb60
bb59:
  %t323 = load ptr, ptr %l1, !tbaa !29
  %t325 = getelementptr { i64, [5 x i64] }, ptr %t323, i32 0, i32 1
  %t326 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t325, i32 0, i32 0
  %t327 = load %"compiler/source:Span", ptr %t326
  store %"compiler/source:Span" %t327, ptr %l24
  %t329 = load ptr, ptr %l1, !tbaa !29
  %t331 = getelementptr { i64, [5 x i64] }, ptr %t329, i32 0, i32 1
  %t332 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t331, i32 0, i32 1
  %t333 = load i32, ptr %t332
  store i32 %t333, ptr %l25, !tbaa !23
  %t335 = load ptr, ptr %l1, !tbaa !29
  %t337 = getelementptr { i64, [5 x i64] }, ptr %t335, i32 0, i32 1
  %t338 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t337, i32 0, i32 2
  %t339 = load ptr, ptr %t338
  store ptr %t339, ptr %l26, !tbaa !29
  br label %bb61
bb60:
  br label %bb63
bb61:
  %t341 = load ptr, ptr %l0, !tbaa !29
  %t342 = load ptr, ptr %l26, !tbaa !29
  %t343 = load i32, ptr %l25, !tbaa !23
  %t344 = load %"compiler/source:Span", ptr %l24
  %t349 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2emake(ptr %v0, ptr %v1, ptr %t341, ptr %t342, i32 %t343, %"compiler/source:Span" %t344)
  store { i64, [4 x i64] } %t349, ptr %l193
  br label %bb62
bb62:
  %t350 = load { i64, [4 x i64] }, ptr %l193
  store { i64, [4 x i64] } %t350, ptr %l66
  br label %bb134
bb63:
  %t351 = load ptr, ptr %l1, !tbaa !29
  store ptr %t351, ptr %l194, !tbaa !29
  store i1 false, ptr %l195, !tbaa !21
  %t352 = load ptr, ptr %l194, !tbaa !29
  %t353 = icmp ne ptr %t352, null
  br i1 %t353, label %bb64, label %bb65
bb64:
  %t355 = load ptr, ptr %l194, !tbaa !29
  %t356 = load i64, ptr %t355
  %t358 = icmp eq i64 %t356, 8
  store i1 %t358, ptr %l195, !tbaa !21
  br label %bb65
bb65:
  %t359 = load i1, ptr %l195, !tbaa !21
  br i1 %t359, label %bb66, label %bb67
bb66:
  %t360 = load ptr, ptr %l1, !tbaa !29
  %t362 = getelementptr { i64, [5 x i64] }, ptr %t360, i32 0, i32 1
  %t363 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t362, i32 0, i32 0
  %t364 = load %"compiler/source:Span", ptr %t363
  store %"compiler/source:Span" %t364, ptr %l27
  %t366 = load ptr, ptr %l1, !tbaa !29
  %t368 = getelementptr { i64, [5 x i64] }, ptr %t366, i32 0, i32 1
  %t369 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t368, i32 0, i32 1
  %t370 = load i32, ptr %t369
  store i32 %t370, ptr %l28, !tbaa !23
  %t372 = load ptr, ptr %l1, !tbaa !29
  %t374 = getelementptr { i64, [5 x i64] }, ptr %t372, i32 0, i32 1
  %t375 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t374, i32 0, i32 2
  %t376 = load ptr, ptr %t375
  store ptr %t376, ptr %l29, !tbaa !29
  br label %bb68
bb67:
  br label %bb70
bb68:
  %t378 = load ptr, ptr %l0, !tbaa !29
  %t379 = load ptr, ptr %l29, !tbaa !29
  %t380 = load i32, ptr %l28, !tbaa !23
  %t381 = load %"compiler/source:Span", ptr %l27
  %t386 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ecollect(ptr %v0, ptr %v1, ptr %t378, ptr %t379, i32 %t380, %"compiler/source:Span" %t381)
  store { i64, [4 x i64] } %t386, ptr %l208
  br label %bb69
bb69:
  %t387 = load { i64, [4 x i64] }, ptr %l208
  store { i64, [4 x i64] } %t387, ptr %l66
  br label %bb134
bb70:
  %t388 = load ptr, ptr %l1, !tbaa !29
  store ptr %t388, ptr %l209, !tbaa !29
  store i1 false, ptr %l210, !tbaa !21
  %t389 = load ptr, ptr %l209, !tbaa !29
  %t390 = icmp ne ptr %t389, null
  br i1 %t390, label %bb71, label %bb72
bb71:
  %t392 = load ptr, ptr %l209, !tbaa !29
  %t393 = load i64, ptr %t392
  %t395 = icmp eq i64 %t393, 9
  store i1 %t395, ptr %l210, !tbaa !21
  br label %bb72
bb72:
  %t396 = load i1, ptr %l210, !tbaa !21
  br i1 %t396, label %bb73, label %bb74
bb73:
  %t397 = load ptr, ptr %l1, !tbaa !29
  %t399 = getelementptr { i64, [5 x i64] }, ptr %t397, i32 0, i32 1
  %t400 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t399, i32 0, i32 0
  %t401 = load %"compiler/source:Span", ptr %t400
  store %"compiler/source:Span" %t401, ptr %l30
  %t403 = load ptr, ptr %l1, !tbaa !29
  %t405 = getelementptr { i64, [5 x i64] }, ptr %t403, i32 0, i32 1
  %t406 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t405, i32 0, i32 1
  %t407 = load i32, ptr %t406
  store i32 %t407, ptr %l31, !tbaa !23
  %t409 = load ptr, ptr %l1, !tbaa !29
  %t411 = getelementptr { i64, [5 x i64] }, ptr %t409, i32 0, i32 1
  %t412 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t411, i32 0, i32 2
  %t413 = load i32, ptr %t412
  store i32 %t413, ptr %l32
  %t415 = load ptr, ptr %l1, !tbaa !29
  %t417 = getelementptr { i64, [5 x i64] }, ptr %t415, i32 0, i32 1
  %t418 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t417, i32 0, i32 3
  %t419 = load i32, ptr %t418
  store i32 %t419, ptr %l33
  %t421 = load ptr, ptr %l1, !tbaa !29
  %t423 = getelementptr { i64, [5 x i64] }, ptr %t421, i32 0, i32 1
  %t424 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t423, i32 0, i32 4
  %t425 = load { i64, ptr }, ptr %t424
  store { i64, ptr } %t425, ptr %l34, !tbaa !27
  br label %bb75
bb74:
  br label %bb77
bb75:
  %t427 = load ptr, ptr %l0, !tbaa !29
  %t428 = load i32, ptr %l32
  %t429 = load i32, ptr %l33
  %t430 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t431 = load i32, ptr %l31, !tbaa !23
  %t432 = load %"compiler/source:Span", ptr %l30
  %t439 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprimExpr(ptr %v0, ptr %v1, ptr %t427, i32 %t428, i32 %t429, { i64, ptr } %t430, i32 %t431, %"compiler/source:Span" %t432)
  store { i64, [4 x i64] } %t439, ptr %l229
  br label %bb76
bb76:
  %t440 = load { i64, [4 x i64] }, ptr %l229
  store { i64, [4 x i64] } %t440, ptr %l66
  br label %bb134
bb77:
  %t441 = load ptr, ptr %l1, !tbaa !29
  store ptr %t441, ptr %l230, !tbaa !29
  store i1 false, ptr %l231, !tbaa !21
  %t442 = load ptr, ptr %l230, !tbaa !29
  %t443 = icmp ne ptr %t442, null
  br i1 %t443, label %bb78, label %bb79
bb78:
  %t445 = load ptr, ptr %l230, !tbaa !29
  %t446 = load i64, ptr %t445
  %t448 = icmp eq i64 %t446, 10
  store i1 %t448, ptr %l231, !tbaa !21
  br label %bb79
bb79:
  %t449 = load i1, ptr %l231, !tbaa !21
  br i1 %t449, label %bb80, label %bb81
bb80:
  %t450 = load ptr, ptr %l1, !tbaa !29
  %t452 = getelementptr { i64, [5 x i64] }, ptr %t450, i32 0, i32 1
  %t453 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t452, i32 0, i32 0
  %t454 = load %"compiler/source:Span", ptr %t453
  store %"compiler/source:Span" %t454, ptr %l35
  %t456 = load ptr, ptr %l1, !tbaa !29
  %t458 = getelementptr { i64, [5 x i64] }, ptr %t456, i32 0, i32 1
  %t459 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t458, i32 0, i32 1
  %t460 = load i32, ptr %t459
  store i32 %t460, ptr %l36, !tbaa !23
  %t462 = load ptr, ptr %l1, !tbaa !29
  %t464 = getelementptr { i64, [5 x i64] }, ptr %t462, i32 0, i32 1
  %t465 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t464, i32 0, i32 2
  %t466 = load ptr, ptr %t465
  store ptr %t466, ptr %l37, !tbaa !29
  br label %bb82
bb81:
  br label %bb84
bb82:
  %t468 = load ptr, ptr %l0, !tbaa !29
  %t469 = load ptr, ptr %l37, !tbaa !29
  %t470 = load i32, ptr %l36, !tbaa !23
  %t471 = load %"compiler/source:Span", ptr %l35
  %t476 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eslice(ptr %v0, ptr %v1, ptr %t468, ptr %t469, i32 %t470, %"compiler/source:Span" %t471)
  store { i64, [4 x i64] } %t476, ptr %l244
  br label %bb83
bb83:
  %t477 = load { i64, [4 x i64] }, ptr %l244
  store { i64, [4 x i64] } %t477, ptr %l66
  br label %bb134
bb84:
  %t478 = load ptr, ptr %l1, !tbaa !29
  store ptr %t478, ptr %l245, !tbaa !29
  store i1 false, ptr %l246, !tbaa !21
  %t479 = load ptr, ptr %l245, !tbaa !29
  %t480 = icmp ne ptr %t479, null
  br i1 %t480, label %bb85, label %bb86
bb85:
  %t482 = load ptr, ptr %l245, !tbaa !29
  %t483 = load i64, ptr %t482
  %t485 = icmp eq i64 %t483, 11
  store i1 %t485, ptr %l246, !tbaa !21
  br label %bb86
bb86:
  %t486 = load i1, ptr %l246, !tbaa !21
  br i1 %t486, label %bb87, label %bb88
bb87:
  %t487 = load ptr, ptr %l1, !tbaa !29
  %t489 = getelementptr { i64, [5 x i64] }, ptr %t487, i32 0, i32 1
  %t490 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t489, i32 0, i32 0
  %t491 = load %"compiler/source:Span", ptr %t490
  store %"compiler/source:Span" %t491, ptr %l38
  %t493 = load ptr, ptr %l1, !tbaa !29
  %t495 = getelementptr { i64, [5 x i64] }, ptr %t493, i32 0, i32 1
  %t496 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t495, i32 0, i32 1
  %t497 = load i32, ptr %t496
  store i32 %t497, ptr %l39, !tbaa !23
  %t499 = load ptr, ptr %l1, !tbaa !29
  %t501 = getelementptr { i64, [5 x i64] }, ptr %t499, i32 0, i32 1
  %t502 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t501, i32 0, i32 2
  %t503 = load ptr, ptr %t502
  store ptr %t503, ptr %l40, !tbaa !29
  br label %bb89
bb88:
  br label %bb91
bb89:
  %t505 = load ptr, ptr %l0, !tbaa !29
  %t506 = load ptr, ptr %l40, !tbaa !29
  %t507 = load i32, ptr %l39, !tbaa !23
  %t508 = load %"compiler/source:Span", ptr %l38
  %t513 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2econd(ptr %v0, ptr %v1, ptr %t505, ptr %t506, i32 %t507, %"compiler/source:Span" %t508)
  store { i64, [4 x i64] } %t513, ptr %l259
  br label %bb90
bb90:
  %t514 = load { i64, [4 x i64] }, ptr %l259
  store { i64, [4 x i64] } %t514, ptr %l66
  br label %bb134
bb91:
  %t515 = load ptr, ptr %l1, !tbaa !29
  store ptr %t515, ptr %l260, !tbaa !29
  store i1 false, ptr %l261, !tbaa !21
  %t516 = load ptr, ptr %l260, !tbaa !29
  %t517 = icmp ne ptr %t516, null
  br i1 %t517, label %bb92, label %bb93
bb92:
  %t519 = load ptr, ptr %l260, !tbaa !29
  %t520 = load i64, ptr %t519
  %t522 = icmp eq i64 %t520, 12
  store i1 %t522, ptr %l261, !tbaa !21
  br label %bb93
bb93:
  %t523 = load i1, ptr %l261, !tbaa !21
  br i1 %t523, label %bb94, label %bb95
bb94:
  %t524 = load ptr, ptr %l1, !tbaa !29
  %t526 = getelementptr { i64, [5 x i64] }, ptr %t524, i32 0, i32 1
  %t527 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t526, i32 0, i32 2
  %t528 = load ptr, ptr %t527
  store ptr %t528, ptr %l41, !tbaa !29
  br label %bb96
bb95:
  br label %bb98
bb96:
  %t530 = load ptr, ptr %l0, !tbaa !29
  %t531 = load ptr, ptr %l41, !tbaa !29
  %t534 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eseq(ptr %v0, ptr %v1, ptr %t530, ptr %t531)
  store { i64, [4 x i64] } %t534, ptr %l268
  br label %bb97
bb97:
  %t535 = load { i64, [4 x i64] }, ptr %l268
  store { i64, [4 x i64] } %t535, ptr %l66
  br label %bb134
bb98:
  %t536 = load ptr, ptr %l1, !tbaa !29
  store ptr %t536, ptr %l269, !tbaa !29
  store i1 false, ptr %l270, !tbaa !21
  %t537 = load ptr, ptr %l269, !tbaa !29
  %t538 = icmp ne ptr %t537, null
  br i1 %t538, label %bb99, label %bb100
bb99:
  %t540 = load ptr, ptr %l269, !tbaa !29
  %t541 = load i64, ptr %t540
  %t543 = icmp eq i64 %t541, 13
  store i1 %t543, ptr %l270, !tbaa !21
  br label %bb100
bb100:
  %t544 = load i1, ptr %l270, !tbaa !21
  br i1 %t544, label %bb101, label %bb102
bb101:
  %t545 = load ptr, ptr %l1, !tbaa !29
  %t547 = getelementptr { i64, [5 x i64] }, ptr %t545, i32 0, i32 1
  %t548 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t547, i32 0, i32 0
  %t549 = load %"compiler/source:Span", ptr %t548
  store %"compiler/source:Span" %t549, ptr %l42
  %t551 = load ptr, ptr %l1, !tbaa !29
  %t553 = getelementptr { i64, [5 x i64] }, ptr %t551, i32 0, i32 1
  %t554 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t553, i32 0, i32 1
  %t555 = load i32, ptr %t554
  store i32 %t555, ptr %l43, !tbaa !23
  %t557 = load ptr, ptr %l1, !tbaa !29
  %t559 = getelementptr { i64, [5 x i64] }, ptr %t557, i32 0, i32 1
  %t560 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t559, i32 0, i32 2
  %t561 = load ptr, ptr %t560
  store ptr %t561, ptr %l44, !tbaa !29
  br label %bb103
bb102:
  br label %bb105
bb103:
  %t563 = load ptr, ptr %l0, !tbaa !29
  %t564 = load ptr, ptr %l44, !tbaa !29
  %t565 = load i32, ptr %l43, !tbaa !23
  %t566 = load %"compiler/source:Span", ptr %l42
  %t571 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ematch(ptr %v0, ptr %v1, ptr %t563, ptr %t564, i32 %t565, %"compiler/source:Span" %t566)
  store { i64, [4 x i64] } %t571, ptr %l283
  br label %bb104
bb104:
  %t572 = load { i64, [4 x i64] }, ptr %l283
  store { i64, [4 x i64] } %t572, ptr %l66
  br label %bb134
bb105:
  %t573 = load ptr, ptr %l1, !tbaa !29
  store ptr %t573, ptr %l284, !tbaa !29
  store i1 false, ptr %l285, !tbaa !21
  %t574 = load ptr, ptr %l284, !tbaa !29
  %t575 = icmp ne ptr %t574, null
  br i1 %t575, label %bb106, label %bb107
bb106:
  %t577 = load ptr, ptr %l284, !tbaa !29
  %t578 = load i64, ptr %t577
  %t580 = icmp eq i64 %t578, 14
  store i1 %t580, ptr %l285, !tbaa !21
  br label %bb107
bb107:
  %t581 = load i1, ptr %l285, !tbaa !21
  br i1 %t581, label %bb108, label %bb109
bb108:
  %t582 = load ptr, ptr %l1, !tbaa !29
  %t584 = getelementptr { i64, [5 x i64] }, ptr %t582, i32 0, i32 1
  %t585 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t584, i32 0, i32 0
  %t586 = load %"compiler/source:Span", ptr %t585
  store %"compiler/source:Span" %t586, ptr %l45
  %t588 = load ptr, ptr %l1, !tbaa !29
  %t590 = getelementptr { i64, [5 x i64] }, ptr %t588, i32 0, i32 1
  %t591 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t590, i32 0, i32 2
  %t592 = load ptr, ptr %t591
  store ptr %t592, ptr %l46, !tbaa !29
  br label %bb110
bb109:
  br label %bb112
bb110:
  %t594 = load ptr, ptr %l0, !tbaa !29
  %t595 = load ptr, ptr %l1, !tbaa !29
  %t596 = load ptr, ptr %l46, !tbaa !29
  %t597 = load %"compiler/source:Span", ptr %l45
  %t602 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2etry(ptr %v0, ptr %v1, ptr %v1, ptr %t594, ptr %t595, ptr %t596, %"compiler/source:Span" %t597)
  store { i64, [4 x i64] } %t602, ptr %l296
  br label %bb111
bb111:
  %t603 = load { i64, [4 x i64] }, ptr %l296
  store { i64, [4 x i64] } %t603, ptr %l66
  br label %bb134
bb112:
  %t604 = load ptr, ptr %l1, !tbaa !29
  store ptr %t604, ptr %l297, !tbaa !29
  store i1 false, ptr %l298, !tbaa !21
  %t605 = load ptr, ptr %l297, !tbaa !29
  %t606 = icmp ne ptr %t605, null
  br i1 %t606, label %bb113, label %bb114
bb113:
  %t608 = load ptr, ptr %l297, !tbaa !29
  %t609 = load i64, ptr %t608
  %t611 = icmp eq i64 %t609, 15
  store i1 %t611, ptr %l298, !tbaa !21
  br label %bb114
bb114:
  %t612 = load i1, ptr %l298, !tbaa !21
  br i1 %t612, label %bb115, label %bb116
bb115:
  %t613 = load ptr, ptr %l1, !tbaa !29
  %t615 = getelementptr { i64, [5 x i64] }, ptr %t613, i32 0, i32 1
  %t616 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t615, i32 0, i32 0
  %t617 = load %"compiler/source:Span", ptr %t616
  store %"compiler/source:Span" %t617, ptr %l47
  %t619 = load ptr, ptr %l1, !tbaa !29
  %t621 = getelementptr { i64, [5 x i64] }, ptr %t619, i32 0, i32 1
  %t622 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t621, i32 0, i32 1
  %t623 = load i32, ptr %t622
  store i32 %t623, ptr %l48, !tbaa !23
  %t625 = load ptr, ptr %l1, !tbaa !29
  %t627 = getelementptr { i64, [5 x i64] }, ptr %t625, i32 0, i32 1
  %t628 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t627, i32 0, i32 2
  %t629 = load ptr, ptr %t628
  store ptr %t629, ptr %l49, !tbaa !29
  br label %bb117
bb116:
  br label %bb119
bb117:
  %t631 = load ptr, ptr %l0, !tbaa !29
  %t632 = load ptr, ptr %l49, !tbaa !29
  %t633 = load i32, ptr %l48, !tbaa !23
  %t634 = load %"compiler/source:Span", ptr %l47
  %t639 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2efnVal(ptr %v0, ptr %v1, ptr %t631, ptr %t632, i32 %t633, %"compiler/source:Span" %t634)
  store { i64, [4 x i64] } %t639, ptr %l311
  br label %bb118
bb118:
  %t640 = load { i64, [4 x i64] }, ptr %l311
  store { i64, [4 x i64] } %t640, ptr %l66
  br label %bb134
bb119:
  %t641 = load ptr, ptr %l1, !tbaa !29
  store ptr %t641, ptr %l312, !tbaa !29
  store i1 false, ptr %l313, !tbaa !21
  %t642 = load ptr, ptr %l312, !tbaa !29
  %t643 = icmp ne ptr %t642, null
  br i1 %t643, label %bb120, label %bb121
bb120:
  %t645 = load ptr, ptr %l312, !tbaa !29
  %t646 = load i64, ptr %t645
  %t648 = icmp eq i64 %t646, 16
  store i1 %t648, ptr %l313, !tbaa !21
  br label %bb121
bb121:
  %t649 = load i1, ptr %l313, !tbaa !21
  br i1 %t649, label %bb122, label %bb123
bb122:
  %t650 = load ptr, ptr %l1, !tbaa !29
  %t652 = getelementptr { i64, [5 x i64] }, ptr %t650, i32 0, i32 1
  %t653 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t652, i32 0, i32 0
  %t654 = load %"compiler/source:Span", ptr %t653
  store %"compiler/source:Span" %t654, ptr %l50
  %t656 = load ptr, ptr %l1, !tbaa !29
  %t658 = getelementptr { i64, [5 x i64] }, ptr %t656, i32 0, i32 1
  %t659 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t658, i32 0, i32 1
  %t660 = load i32, ptr %t659
  store i32 %t660, ptr %l51, !tbaa !23
  %t662 = load ptr, ptr %l1, !tbaa !29
  %t664 = getelementptr { i64, [5 x i64] }, ptr %t662, i32 0, i32 1
  %t665 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t664, i32 0, i32 2
  %t666 = load ptr, ptr %t665
  store ptr %t666, ptr %l52, !tbaa !29
  br label %bb124
bb123:
  br label %bb126
bb124:
  %t668 = load ptr, ptr %l0, !tbaa !29
  %t669 = load ptr, ptr %l52, !tbaa !29
  %t670 = load i32, ptr %l51, !tbaa !23
  %t671 = load %"compiler/source:Span", ptr %l50
  %t676 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2etext(ptr %v0, ptr %v1, ptr %t668, ptr %t669, i32 %t670, %"compiler/source:Span" %t671)
  store { i64, [4 x i64] } %t676, ptr %l326
  br label %bb125
bb125:
  %t677 = load { i64, [4 x i64] }, ptr %l326
  store { i64, [4 x i64] } %t677, ptr %l66
  br label %bb134
bb126:
  %t678 = load ptr, ptr %l1, !tbaa !29
  store ptr %t678, ptr %l327, !tbaa !29
  store i1 false, ptr %l328, !tbaa !21
  %t679 = load ptr, ptr %l327, !tbaa !29
  %t680 = icmp ne ptr %t679, null
  br i1 %t680, label %bb127, label %bb128
bb127:
  %t682 = load ptr, ptr %l327, !tbaa !29
  %t683 = load i64, ptr %t682
  %t685 = icmp eq i64 %t683, 17
  store i1 %t685, ptr %l328, !tbaa !21
  br label %bb128
bb128:
  %t686 = load i1, ptr %l328, !tbaa !21
  br i1 %t686, label %bb129, label %bb130
bb129:
  %t687 = load ptr, ptr %l1, !tbaa !29
  %t689 = getelementptr { i64, [5 x i64] }, ptr %t687, i32 0, i32 1
  %t690 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t689, i32 0, i32 1
  %t691 = load i64, ptr %t690
  store i64 %t691, ptr %l53, !tbaa !24
  %t693 = load ptr, ptr %l1, !tbaa !29
  %t695 = getelementptr { i64, [5 x i64] }, ptr %t693, i32 0, i32 1
  %t696 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t695, i32 0, i32 2
  %t697 = load ptr, ptr %t696
  store ptr %t697, ptr %l54, !tbaa !29
  br label %bb131
bb130:
  br label %bb133
bb131:
  %t699 = load ptr, ptr %l0, !tbaa !29
  %t700 = load i64, ptr %l53, !tbaa !24
  %t701 = load ptr, ptr %l54, !tbaa !29
  %t705 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eaway(ptr %v0, ptr %v1, ptr %t699, i64 %t700, ptr %t701)
  store { i64, [4 x i64] } %t705, ptr %l338
  br label %bb132
bb132:
  %t706 = load { i64, [4 x i64] }, ptr %l338
  store { i64, [4 x i64] } %t706, ptr %l66
  br label %bb134
bb133:
  call void @__olang_check_failed(ptr @olang_loc_c62658d3c5a83b98_5474a5965e06e124)
  unreachable
bb134:
  %t707 = load { i64, [4 x i64] }, ptr %l66
  store { i64, [4 x i64] } %t707, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local { { i64, [7 x i64] }, i32 } @compiler_2flower_2ecompiler_2flower_3alowering_2evalueCallee(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  %l6 = alloca { i64, [4 x i64] }
  %l8 = alloca { i64, [7 x i64] }
  %l10 = alloca i32
  %rv = alloca { { i64, [7 x i64] }, i32 }
  %t9 = alloca { i64, [7 x i64] }, align 8
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t6 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v1, ptr %a0, ptr %t2)
  store { i64, [4 x i64] } %t6, ptr %l6
  br label %bb1
bb1:
  %t7 = load { i64, [4 x i64] }, ptr %l6
  store { i64, [7 x i64] } zeroinitializer, ptr %t9
  %t10 = getelementptr { i64, [7 x i64] }, ptr %t9, i32 0, i32 0
  store i64 2, ptr %t10
  %t12 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t7, 0
  %t13 = getelementptr { i64, [7 x i64] }, ptr %t9, i32 0, i32 1
  store { { i64, [4 x i64] } } %t12, ptr %t13
  %t14 = load { i64, [7 x i64] }, ptr %t9
  store { i64, [7 x i64] } %t14, ptr %l8
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t17 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t15)
  store i32 %t17, ptr %l10
  br label %bb2
bb2:
  %t18 = load { i64, [7 x i64] }, ptr %l8
  %t19 = insertvalue { { i64, [7 x i64] }, i32 } undef, { i64, [7 x i64] } %t18, 0
  %t20 = load i32, ptr %l10, !tbaa !23
  %t21 = insertvalue { { i64, [7 x i64] }, i32 } %t19, i32 %t20, 1
  store { { i64, [7 x i64] }, i32 } %t21, ptr %rv
  br label %ret
ret:
  %rr = load { { i64, [7 x i64] }, i32 }, ptr %rv
  ret { { i64, [7 x i64] }, i32 } %rr
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3alowering_2ewidens(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l6 = alloca ptr
  %l7 = alloca i1
  %l8 = alloca ptr
  %l9 = alloca i1
  %l22 = alloca i1
  %l23 = alloca ptr
  %l24 = alloca i1
  %rv = alloca i1
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t2 = load ptr, ptr %l8, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l8, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 9
  store i1 %t8, ptr %l9, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l9, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l3, !tbaa !23
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t18, i32 0, i32 2
  %t20 = load i32, ptr %t19
  store i32 %t20, ptr %l4
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t24 = getelementptr { i64, [5 x i64] }, ptr %t22, i32 0, i32 1
  %t25 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t24, i32 0, i32 4
  %t26 = load { i64, ptr }, ptr %t25
  store { i64, ptr } %t26, ptr %l5, !tbaa !27
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t29 = load i32, ptr %l4
  %t30 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t31 = load i32, ptr %l3, !tbaa !23
  %t36 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2ewidening(ptr %v0, ptr %v1, ptr %a0, i32 %t29, { i64, ptr } %t30, i32 %t31)
  store i1 %t36, ptr %l22
  br label %bb6
bb6:
  %t37 = load i1, ptr %l22, !tbaa !21
  store i1 %t37, ptr %l7, !tbaa !21
  br label %bb18
bb7:
  %t38 = load ptr, ptr %l1, !tbaa !29
  store ptr %t38, ptr %l23, !tbaa !29
  store i1 false, ptr %l24, !tbaa !21
  %t39 = load ptr, ptr %l23, !tbaa !29
  %t40 = icmp ne ptr %t39, null
  br i1 %t40, label %bb8, label %bb9
bb8:
  %t42 = load ptr, ptr %l23, !tbaa !29
  %t43 = load i64, ptr %t42
  %t45 = icmp eq i64 %t43, 17
  store i1 %t45, ptr %l24, !tbaa !21
  br label %bb9
bb9:
  %t46 = load i1, ptr %l24, !tbaa !21
  br i1 %t46, label %bb10, label %bb11
bb10:
  %t47 = load ptr, ptr %l1, !tbaa !29
  %t49 = getelementptr { i64, [5 x i64] }, ptr %t47, i32 0, i32 1
  %t50 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t49, i32 0, i32 2
  %t51 = load ptr, ptr %t50
  store ptr %t51, ptr %l6, !tbaa !29
  br label %bb12
bb11:
  br label %bb13
bb12:
  store i1 false, ptr %l7, !tbaa !21
  br label %bb18
bb13:
  br i1 true, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb17
bb16:
  store i1 false, ptr %l7, !tbaa !21
  br label %bb18
bb17:
  call void @__olang_check_failed(ptr @olang_loc_d2f9ab61c66bb7bd_ba20d4faed7cd6b1)
  unreachable
bb18:
  %t53 = load i1, ptr %l7, !tbaa !21
  store i1 %t53, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ezero(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca %"compiler/source:Span"
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca { i64, [7 x i64] }
  %l7 = alloca i32
  %l8 = alloca i32
  %l16 = alloca i32
  %l20 = alloca i32
  %l33 = alloca i32
  %l37 = alloca i32
  %l39 = alloca ptr
  %l40 = alloca { i64, [7 x i64] }
  %l41 = alloca %"compiler/mir:Range"
  %l42 = alloca ptr
  %l46 = alloca i64
  %l48 = alloca %"compiler/mir:Range"
  %l50 = alloca %"compiler/mir:Place"
  %l54 = alloca %"compiler/mir:Call"
  %l55 = alloca i32
  %l63 = alloca %"compiler/mir:Place"
  %s0 = alloca %olang.scope
  %rv = alloca { i64, [4 x i64] }
  %t24 = alloca { i64, [2 x i64] }, align 8
  %t33 = alloca { i64, [7 x i64] }, align 8
  %t47 = alloca { i64, [2 x i64] }, align 8
  %t110 = alloca { i64, [8 x i64] }, align 8
  %t127 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/lower:lowering", ptr %t6, i32 0, i32 0
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t10 = load i32, ptr %l1, !tbaa !23
  %t14 = call i32 @compiler_2flower_2ecompiler_2flower_3aLowerer_2ehelperTy(ptr %v0, ptr %t9, i32 3, i32 %t10)
  store i32 %t14, ptr %l16
  br label %bb1
bb1:
  %t15 = load i32, ptr %l16, !tbaa !23
  store i32 %t15, ptr %l1, !tbaa !23
  %t16 = load ptr, ptr %l4, !tbaa !29
  %t17 = load i32, ptr %l1, !tbaa !23
  %t21 = call i32 @compiler_2fmir_2eHelperType(ptr %v0, ptr %t16, i32 3, i32 %t17)
  store i32 %t21, ptr %l20
  br label %bb2
bb2:
  %t22 = load i32, ptr %l20, !tbaa !23
  store i32 %t22, ptr %l5, !tbaa !23
  %t23 = load i32, ptr %l1, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t24
  %t25 = getelementptr { i64, [2 x i64] }, ptr %t24, i32 0, i32 0
  store i64 2, ptr %t25
  %t27 = insertvalue { i32, i32 } undef, i32 3, 0
  %t29 = insertvalue { i32, i32 } %t27, i32 %t23, 1
  %t30 = getelementptr { i64, [2 x i64] }, ptr %t24, i32 0, i32 1
  store { i32, i32 } %t29, ptr %t30
  %t31 = load { i64, [2 x i64] }, ptr %t24
  %t32 = load i32, ptr %l5, !tbaa !23
  store { i64, [7 x i64] } zeroinitializer, ptr %t33
  %t34 = getelementptr { i64, [7 x i64] }, ptr %t33, i32 0, i32 0
  store i64 0, ptr %t34
  %t36 = insertvalue { { i64, [2 x i64] }, i32 } undef, { i64, [2 x i64] } %t31, 0
  %t38 = insertvalue { { i64, [2 x i64] }, i32 } %t36, i32 %t32, 1
  %t39 = getelementptr { i64, [7 x i64] }, ptr %t33, i32 0, i32 1
  store { { i64, [2 x i64] }, i32 } %t38, ptr %t39
  %t40 = load { i64, [7 x i64] }, ptr %t33
  store { i64, [7 x i64] } %t40, ptr %l6
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/lower:lowering", ptr %t42, i32 0, i32 0
  %t45 = load ptr, ptr %t44, !tbaa !29
  %t46 = load i32, ptr %l1, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t47
  %t48 = getelementptr { i64, [2 x i64] }, ptr %t47, i32 0, i32 0
  store i64 2, ptr %t48
  %t50 = insertvalue { i32, i32 } undef, i32 3, 0
  %t52 = insertvalue { i32, i32 } %t50, i32 %t46, 1
  %t53 = getelementptr { i64, [2 x i64] }, ptr %t47, i32 0, i32 1
  store { i32, i32 } %t52, ptr %t53
  %t54 = load { i64, [2 x i64] }, ptr %t47
  call void @compiler_2flower_2ecompiler_2flower_3aLowerer_2eWant(ptr %v0, ptr %t45, { i64, [2 x i64] } %t54)
  br label %bb3
bb3:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/lower:lowering", ptr %t57, i32 0, i32 3
  %t61 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t59)
  store i32 %t61, ptr %l33
  br label %bb4
bb4:
  %t62 = load i32, ptr %l33, !tbaa !23
  store i32 %t62, ptr %l7, !tbaa !23
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t64 = load i32, ptr %l1, !tbaa !23
  %t65 = load %"compiler/source:Span", ptr %l2
  %t69 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2etemp(ptr %v0, ptr %t63, i32 %t64, %"compiler/source:Span" %t65)
  store i32 %t69, ptr %l37
  br label %bb5
bb5:
  %t70 = load i32, ptr %l37, !tbaa !23
  store i32 %t70, ptr %l8, !tbaa !23
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/lower:lowering", ptr %t71, i32 0, i32 3
  store ptr %t73, ptr %l39, !tbaa !29
  %t74 = load { i64, [7 x i64] }, ptr %l6
  store { i64, [7 x i64] } %t74, ptr %l40
  %t75 = load %"compiler/mir:Range", ptr @G_2ecompiler_2fmir_2eEmpty
  store %"compiler/mir:Range" %t75, ptr %l41
  %t76 = load ptr, ptr %l0, !tbaa !29
  store ptr %t76, ptr %l42, !tbaa !29
  %t77 = load ptr, ptr %l4, !tbaa !29
  %t78 = load { i64, [7 x i64] }, ptr %l6
  %t79 = load i32, ptr %l5, !tbaa !23
  %t83 = call i64 @compiler_2fmir_2ePassedCount(ptr %v0, ptr %t77, { i64, [7 x i64] } %t78, i32 %t79)
  store i64 %t83, ptr %l46
  br label %bb6
bb6:
  %t85 = load ptr, ptr %l42, !tbaa !29
  %t86 = load i64, ptr %l46, !tbaa !24
  %t88 = call %"compiler/mir:Range" @compiler_2flower_2ecompiler_2flower_3alowering_2epassed(ptr %v0, ptr %t85, i64 %t86, i32 %a3)
  store %"compiler/mir:Range" %t88, ptr %l48
  br label %bb7
bb7:
  %t89 = load i32, ptr %l8, !tbaa !23
  %t91 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t89)
  store %"compiler/mir:Place" %t91, ptr %l50
  br label %bb8
bb8:
  %t92 = load i32, ptr %l7, !tbaa !23
  %t93 = load i32, ptr @G_2ecompiler_2fmir_2eNoLocal, !tbaa !23
  %t94 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t95 = load { i64, [7 x i64] }, ptr %l40
  %t96 = load %"compiler/mir:Range", ptr %l41
  %t97 = load %"compiler/mir:Range", ptr %l48
  %t98 = load %"compiler/mir:Place", ptr %l50
  %t102 = call %"compiler/mir:Call" @compiler_2fmir_3aCall_2ector(ptr %s0, { i64, [7 x i64] } %t95, %"compiler/mir:Range" %t96, %"compiler/mir:Range" %t97, %"compiler/mir:Place" %t98, i1 true, i32 %t92, i32 %t93, i32 %t94)
  store %"compiler/mir:Call" %t102, ptr %l54
  br label %bb9
bb9:
  %t103 = load ptr, ptr %l39, !tbaa !29
  %t104 = load %"compiler/mir:Call", ptr %l54
  %t105 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddCall(ptr %v0, ptr %t103, %"compiler/mir:Call" %t104)
  store i32 %t105, ptr %l55
  br label %bb10
bb10:
  %t106 = load i32, ptr %l55, !tbaa !23
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t108 = load %"compiler/source:Span", ptr %l2
  store { i64, [8 x i64] } zeroinitializer, ptr %t110
  %t111 = getelementptr { i64, [8 x i64] }, ptr %t110, i32 0, i32 0
  store i64 4, ptr %t111
  %t113 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t108, 0
  %t115 = insertvalue { %"compiler/source:Span", i32 } %t113, i32 %t106, 1
  %t116 = getelementptr { i64, [8 x i64] }, ptr %t110, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t115, ptr %t116
  %t117 = load { i64, [8 x i64] }, ptr %t110
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t107, { i64, [8 x i64] } %t117)
  br label %bb11
bb11:
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t121 = load i32, ptr %l7, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t120, i32 %t121)
  br label %bb12
bb12:
  %t124 = load i32, ptr %l8, !tbaa !23
  %t126 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t124)
  store %"compiler/mir:Place" %t126, ptr %l63
  br label %bb13
bb13:
  store { i64, [4 x i64] } zeroinitializer, ptr %t127
  %t128 = getelementptr { i64, [4 x i64] }, ptr %t127, i32 0, i32 0
  store i64 1, ptr %t128
  %t129 = load %"compiler/mir:Place", ptr %l63
  %t130 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t129, 0
  %t131 = getelementptr { i64, [4 x i64] }, ptr %t127, i32 0, i32 1
  store { %"compiler/mir:Place" } %t130, ptr %t131
  %t132 = load { i64, [4 x i64] }, ptr %t127
  call void @__olang_scope_close(ptr %s0)
  store { i64, [4 x i64] } %t132, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ezeroOf(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2, i1 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca %"compiler/source:Span"
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca { { i64, [7 x i64] }, i32 }
  %l8 = alloca { i64, [7 x i64] }
  %l9 = alloca i32
  %l10 = alloca i32
  %l11 = alloca i32
  %l13 = alloca i64
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l25 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i32
  %l35 = alloca i1
  %l36 = alloca ptr
  %l37 = alloca ptr
  %l41 = alloca ptr
  %l44 = alloca i32
  %l45 = alloca { i64, ptr }
  %l52 = alloca { { i64, [7 x i64] }, i32 }
  %l57 = alloca i32
  %l61 = alloca i32
  %l64 = alloca i32
  %l67 = alloca { i64, ptr }
  %l76 = alloca i64
  %l77 = alloca i64
  %l85 = alloca i64
  %l88 = alloca i64
  %l106 = alloca i64
  %l108 = alloca { i64, [1 x i64] }
  %l114 = alloca ptr
  %l115 = alloca { i64, [7 x i64] }
  %l116 = alloca %"compiler/mir:Range"
  %l120 = alloca %"compiler/mir:Range"
  %l122 = alloca %"compiler/mir:Place"
  %l126 = alloca %"compiler/mir:Call"
  %l127 = alloca i32
  %l135 = alloca %"compiler/mir:Place"
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca { i64, [4 x i64] }
  %t104 = alloca { i64, [4 x i64] }, align 8
  %t180 = alloca { i64, [1 x i64] }, align 8
  %t186 = alloca { i64, [1 x i64] }, align 8
  %t232 = alloca { i64, [8 x i64] }, align 8
  %t249 = alloca { i64, [4 x i64] }, align 8
  %t257 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t6 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3aLowerer_2eindex(ptr %v0, ptr %t6)
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l4, !tbaa !29
  %t10 = getelementptr %"compiler/lower:Lowerer", ptr %t8, i32 0, i32 10
  %t11 = load i32, ptr %l1, !tbaa !23
  %t14 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e__H165e1ff795edcbb725e28dde18fd1dc2(ptr %v0, ptr %t10, i32 %t11)
  %t15 = extractvalue { i32, i64 } %t14, 1
  %t16 = extractvalue { i32, i64 } %t14, 0
  store i32 %t16, ptr %l30
  %t17 = icmp ne i32 %t16, 0
  br i1 %t17, label %bb3, label %ok.18
ok.18:
  store i64 %t15, ptr %l29
  br label %bb2
bb2:
  %t19 = load i64, ptr %l29, !tbaa !24
  store i64 %t19, ptr %l25, !tbaa !24
  br label %bb5
bb3:
  br label %bb4
bb4:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l25, !tbaa !24
  br label %bb5
bb5:
  %t20 = load i64, ptr %l25, !tbaa !24
  store i64 %t20, ptr %l5, !tbaa !24
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/lower:lowering", ptr %t21, i32 0, i32 2
  %t24 = load ptr, ptr %t23, !tbaa !29
  store ptr %t24, ptr %l6, !tbaa !29
  %t26 = load i64, ptr %l5, !tbaa !24
  %t28 = icmp sge i64 %t26, 0
  br i1 %t28, label %bb6, label %bb7
bb6:
  %t30 = load ptr, ptr %l6, !tbaa !29
  store ptr %t30, ptr %l36, !tbaa !29
  %t31 = load ptr, ptr %l6, !tbaa !29
  store ptr %t31, ptr %l37, !tbaa !29
  %t32 = load ptr, ptr %l4, !tbaa !29
  %t34 = getelementptr %"compiler/lower:Lowerer", ptr %t32, i32 0, i32 1
  %t35 = load i64, ptr %l5, !tbaa !24
  %t38 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t34, i64 %t35)
  store ptr %t38, ptr %l41
  br label %bb8
bb7:
  store i1 false, ptr %l35, !tbaa !21
  br label %bb11
bb8:
  %t39 = load ptr, ptr %l41, !tbaa !29
  %t41 = getelementptr %"compiler/typed:Body", ptr %t39, i32 0, i32 2
  %t42 = load i32, ptr %t41, !tbaa !23
  %t43 = load ptr, ptr %l37, !tbaa !29
  %t45 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t43, i32 %t42)
  store i32 %t45, ptr %l44
  br label %bb9
bb9:
  %t46 = load ptr, ptr %l36, !tbaa !29
  %t47 = load i32, ptr %l44, !tbaa !23
  %t48 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t46, i32 %t47)
  store { i64, ptr } %t48, ptr %l45
  br label %bb10
bb10:
  %t49 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t50 = extractvalue { i64, ptr } %t49, 0
  %t52 = icmp eq i64 %t50, 0
  store i1 %t52, ptr %l35, !tbaa !21
  br label %bb11
bb11:
  %t54 = load i1, ptr %l35, !tbaa !21
  br i1 %t54, label %bb12, label %bb13
bb12:
  store %olang.scope zeroinitializer, ptr %s1
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t56 = load i64, ptr %l5, !tbaa !24
  %t58 = trunc i64 %t56 to i32
  %t62 = call { { i64, [7 x i64] }, i32 } @compiler_2flower_2ecompiler_2flower_3alowering_2ebodyCallee(ptr %v0, ptr %t55, i32 %t58)
  store { { i64, [7 x i64] }, i32 } %t62, ptr %l52
  br label %bb14
bb13:
  br label %bb50
bb14:
  %t63 = load { { i64, [7 x i64] }, i32 }, ptr %l52
  store { { i64, [7 x i64] }, i32 } %t63, ptr %l7
  %t64 = getelementptr { { i64, [7 x i64] }, i32 }, ptr %l7, i32 0, i32 0
  %t65 = load { i64, [7 x i64] }, ptr %t64
  store { i64, [7 x i64] } %t65, ptr %l8
  %t67 = getelementptr { { i64, [7 x i64] }, i32 }, ptr %l7, i32 0, i32 1
  %t68 = load i32, ptr %t67, !tbaa !23
  store i32 %t68, ptr %l9, !tbaa !23
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/lower:lowering", ptr %t70, i32 0, i32 3
  %t74 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t72)
  store i32 %t74, ptr %l57
  br label %bb15
bb15:
  %t75 = load i32, ptr %l57, !tbaa !23
  store i32 %t75, ptr %l10, !tbaa !23
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t77 = load i32, ptr %l1, !tbaa !23
  %t78 = load %"compiler/source:Span", ptr %l2
  %t82 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2etemp(ptr %v0, ptr %t76, i32 %t77, %"compiler/source:Span" %t78)
  store i32 %t82, ptr %l61
  br label %bb16
bb16:
  %t83 = load i32, ptr %l61, !tbaa !23
  store i32 %t83, ptr %l11, !tbaa !23
  %t84 = load ptr, ptr %l6, !tbaa !29
  %t85 = load i32, ptr %l9, !tbaa !23
  %t88 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t84, i32 %t85)
  store i32 %t88, ptr %l64
  br label %bb17
bb17:
  %t89 = load i32, ptr %l64, !tbaa !23
  %t90 = load ptr, ptr %l6, !tbaa !29
  %t94 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t90, i32 %t89)
  store { i64, ptr } %t94, ptr %l67
  br label %bb18
bb18:
  %t95 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t96 = extractvalue { i64, ptr } %t95, 0
  %t98 = icmp sgt i64 %t96, 0
  br i1 %t98, label %bb19, label %bb20
bb19:
  store %olang.scope zeroinitializer, ptr %s2
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t101 = load %"compiler/source:Span", ptr %l2
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2egap(ptr %v0, ptr %s2, ptr %t100, %"compiler/source:Span" %t101, { i64, ptr } { i64 39, ptr getelementptr inbounds (<{ i64, [39 x i8] }>, ptr @.d35, i32 0, i32 1) })
  br label %bb21
bb20:
  br label %bb22
bb21:
  store { i64, [4 x i64] } zeroinitializer, ptr %t104
  %t105 = getelementptr { i64, [4 x i64] }, ptr %t104, i32 0, i32 0
  store i64 0, ptr %t105
  %t106 = load { i64, [4 x i64] }, ptr %t104
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s1)
  store { i64, [4 x i64] } %t106, ptr %rv
  br label %ret
bb22:
  %t108 = load ptr, ptr %l6, !tbaa !29
  %t109 = load { i64, [7 x i64] }, ptr %l8
  %t110 = load i32, ptr %l9, !tbaa !23
  %t114 = call i64 @compiler_2fmir_2ePassedCount(ptr %v0, ptr %t108, { i64, [7 x i64] } %t109, i32 %t110)
  store i64 %t114, ptr %l76
  br label %bb23
bb23:
  %t115 = load i64, ptr %l76, !tbaa !24
  store i64 %t115, ptr %l13, !tbaa !24
  %t116 = load i64, ptr %l13, !tbaa !24
  store i64 %t116, ptr %l77, !tbaa !24
  %t117 = load i64, ptr %l77, !tbaa !24
  %t118 = icmp sge i64 %t117, 0
  br i1 %t118, label %bb24, label %bb25
bb24:
  %t120 = load i64, ptr %l77, !tbaa !24
  %t121 = icmp sle i64 %t120, 576460752303423487
  br i1 %t121, label %bb26, label %bb27
bb25:
  call void @__olang_check_failed(ptr @olang_loc_fc0d1138e57259ff_a3fb1151381844db)
  unreachable
bb26:
  %t123 = load i64, ptr %l77, !tbaa !24
  %t124 = mul i64 %t123, 16
  %t125 = call ptr @__olang_scope_alloc_zeroed(ptr %s1, i64 %t124)
  %t126 = insertvalue { i64, ptr } undef, i64 %t123, 0
  %t127 = insertvalue { i64, ptr } %t126, ptr %t125, 1
  store { i64, ptr } %t127, ptr %l14, !tbaa !27
  store i64 0, ptr %l15, !tbaa !24
  %t129 = load i64, ptr %l13, !tbaa !24
  store i64 %t129, ptr %l16, !tbaa !24
  store i64 1, ptr %l17, !tbaa !24
  %t131 = load i64, ptr %l16, !tbaa !24
  %t132 = load i64, ptr %l15, !tbaa !24
  %t135 = icmp sgt i64 %t131, %t132
  br i1 %t135, label %bb28, label %bb29
bb27:
  call void @__olang_check_failed(ptr @olang_loc_fc0d1138e57259ff_a3fb1151381844db)
  unreachable
bb28:
  %t137 = load i64, ptr %l17, !tbaa !24
  %t139 = icmp sgt i64 %t137, 0
  br i1 %t139, label %bb30, label %bb31
bb29:
  store i64 0, ptr %l85, !tbaa !24
  br label %bb33
bb30:
  %t141 = load i64, ptr %l16, !tbaa !24
  %t142 = load i64, ptr %l15, !tbaa !24
  %t145 = sub i64 %t141, %t142
  %t146 = load i64, ptr %l17, !tbaa !24
  %t149 = add i64 %t145, %t146
  %t151 = sub i64 %t149, 1
  %t152 = load i64, ptr %l17, !tbaa !24
  %t155 = sdiv i64 %t151, %t152
  store i64 %t155, ptr %l88, !tbaa !24
  br label %bb32
bb31:
  store i64 0, ptr %l88, !tbaa !24
  br label %bb32
bb32:
  %t157 = load i64, ptr %l88, !tbaa !24
  store i64 %t157, ptr %l85, !tbaa !24
  br label %bb33
bb33:
  %t158 = load i64, ptr %l85, !tbaa !24
  store i64 %t158, ptr %l18, !tbaa !24
  store i64 0, ptr %l19, !tbaa !24
  br label %bb34
bb34:
  store %olang.scope zeroinitializer, ptr %s4
  %t159 = load i64, ptr %l19, !tbaa !24
  %t160 = load i64, ptr %l18, !tbaa !24
  %t163 = icmp slt i64 %t159, %t160
  %t165 = xor i1 %t163, true
  br i1 %t165, label %bb35, label %bb36
bb35:
  call void @__olang_scope_close(ptr %s4)
  br label %bb42
bb36:
  br label %bb37
bb37:
  %t167 = load i64, ptr %l15, !tbaa !24
  %t168 = load i64, ptr %l19, !tbaa !24
  %t169 = load i64, ptr %l17, !tbaa !24
  %t172 = mul i64 %t168, %t169
  %t175 = add i64 %t167, %t172
  store i64 %t175, ptr %l106, !tbaa !24
  br i1 %a3, label %bb38, label %bb39
bb38:
  store { i64, [1 x i64] } zeroinitializer, ptr %t180
  %t181 = getelementptr { i64, [1 x i64] }, ptr %t180, i32 0, i32 0
  store i64 1, ptr %t181
  %t182 = insertvalue { i64 } undef, i64 0, 0
  %t183 = getelementptr { i64, [1 x i64] }, ptr %t180, i32 0, i32 1
  store { i64 } %t182, ptr %t183
  %t184 = load { i64, [1 x i64] }, ptr %t180
  store { i64, [1 x i64] } %t184, ptr %l108
  br label %bb40
bb39:
  store { i64, [1 x i64] } zeroinitializer, ptr %t186
  %t187 = getelementptr { i64, [1 x i64] }, ptr %t186, i32 0, i32 0
  store i64 2, ptr %t187
  %t188 = load { i64, [1 x i64] }, ptr %t186
  store { i64, [1 x i64] } %t188, ptr %l108
  br label %bb40
bb40:
  %t190 = load { i64, [1 x i64] }, ptr %l108
  %t191 = load i64, ptr %l106, !tbaa !24
  %t192 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t193 = load ptr, ptr %t192, !tbaa !27
  %t194 = getelementptr { i64, [1 x i64] }, ptr %t193, i64 %t191
  store { i64, [1 x i64] } %t190, ptr %t194
  call void @__olang_scope_close(ptr %s4)
  br label %bb41
bb41:
  %t195 = load i64, ptr %l19, !tbaa !24
  %t197 = add i64 %t195, 1
  store i64 %t197, ptr %l19, !tbaa !24
  br label %bb34
bb42:
  %t199 = load ptr, ptr %l0, !tbaa !29
  %t201 = getelementptr %"compiler/lower:lowering", ptr %t199, i32 0, i32 3
  store ptr %t201, ptr %l114, !tbaa !29
  %t202 = load { i64, [7 x i64] }, ptr %l8
  store { i64, [7 x i64] } %t202, ptr %l115
  %t203 = load %"compiler/mir:Range", ptr @G_2ecompiler_2fmir_2eEmpty
  store %"compiler/mir:Range" %t203, ptr %l116
  %t204 = load ptr, ptr %l0, !tbaa !29
  %t206 = getelementptr %"compiler/lower:lowering", ptr %t204, i32 0, i32 3
  %t207 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t210 = call %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eScopeRefs(ptr %v0, ptr %s1, ptr %t206, { i64, ptr } %t207)
  store %"compiler/mir:Range" %t210, ptr %l120
  br label %bb43
bb43:
  %t211 = load i32, ptr %l11, !tbaa !23
  %t213 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t211)
  store %"compiler/mir:Place" %t213, ptr %l122
  br label %bb44
bb44:
  %t214 = load i32, ptr %l10, !tbaa !23
  %t215 = load i32, ptr @G_2ecompiler_2fmir_2eNoLocal, !tbaa !23
  %t216 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t217 = load { i64, [7 x i64] }, ptr %l115
  %t218 = load %"compiler/mir:Range", ptr %l116
  %t219 = load %"compiler/mir:Range", ptr %l120
  %t220 = load %"compiler/mir:Place", ptr %l122
  %t224 = call %"compiler/mir:Call" @compiler_2fmir_3aCall_2ector(ptr %s1, { i64, [7 x i64] } %t217, %"compiler/mir:Range" %t218, %"compiler/mir:Range" %t219, %"compiler/mir:Place" %t220, i1 true, i32 %t214, i32 %t215, i32 %t216)
  store %"compiler/mir:Call" %t224, ptr %l126
  br label %bb45
bb45:
  %t225 = load ptr, ptr %l114, !tbaa !29
  %t226 = load %"compiler/mir:Call", ptr %l126
  %t227 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddCall(ptr %v0, ptr %t225, %"compiler/mir:Call" %t226)
  store i32 %t227, ptr %l127
  br label %bb46
bb46:
  %t228 = load i32, ptr %l127, !tbaa !23
  %t229 = load ptr, ptr %l0, !tbaa !29
  %t230 = load %"compiler/source:Span", ptr %l2
  store { i64, [8 x i64] } zeroinitializer, ptr %t232
  %t233 = getelementptr { i64, [8 x i64] }, ptr %t232, i32 0, i32 0
  store i64 4, ptr %t233
  %t235 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t230, 0
  %t237 = insertvalue { %"compiler/source:Span", i32 } %t235, i32 %t228, 1
  %t238 = getelementptr { i64, [8 x i64] }, ptr %t232, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t237, ptr %t238
  %t239 = load { i64, [8 x i64] }, ptr %t232
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t229, { i64, [8 x i64] } %t239)
  br label %bb47
bb47:
  %t242 = load ptr, ptr %l0, !tbaa !29
  %t243 = load i32, ptr %l10, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t242, i32 %t243)
  br label %bb48
bb48:
  %t246 = load i32, ptr %l11, !tbaa !23
  %t248 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t246)
  store %"compiler/mir:Place" %t248, ptr %l135
  br label %bb49
bb49:
  store { i64, [4 x i64] } zeroinitializer, ptr %t249
  %t250 = getelementptr { i64, [4 x i64] }, ptr %t249, i32 0, i32 0
  store i64 1, ptr %t250
  %t251 = load %"compiler/mir:Place", ptr %l135
  %t252 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t251, 0
  %t253 = getelementptr { i64, [4 x i64] }, ptr %t249, i32 0, i32 1
  store { %"compiler/mir:Place" } %t252, ptr %t253
  %t254 = load { i64, [4 x i64] }, ptr %t249
  call void @__olang_scope_close(ptr %s1)
  store { i64, [4 x i64] } %t254, ptr %rv
  br label %ret
bb50:
  %t256 = load i32, ptr %l1, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t257
  %t258 = getelementptr { i64, [4 x i64] }, ptr %t257, i32 0, i32 0
  store i64 2, ptr %t258
  %t260 = insertvalue { i32, i64 } undef, i32 %t256, 0
  %t261 = insertvalue { i32, i64 } %t260, i64 0, 1
  %t262 = getelementptr { i64, [4 x i64] }, ptr %t257, i32 0, i32 1
  store { i32, i64 } %t261, ptr %t262
  %t263 = load { i64, [4 x i64] }, ptr %t257
  store { i64, [4 x i64] } %t263, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local i64 @compiler_2flower_2eindexOf(ptr %v0, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %a0, i32 %a1) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l9 = alloca i64
  %l13 = alloca i64
  %l16 = alloca i64
  %l36 = alloca i32
  %s2 = alloca %olang.scope
  %rv = alloca i64
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l2, !tbaa !24
  %t2 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %l0)
  store i64 %t2, ptr %l9
  br label %bb1
bb1:
  %t3 = load i64, ptr %l9, !tbaa !24
  store i64 %t3, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t4 = load i64, ptr %l3, !tbaa !24
  %t5 = load i64, ptr %l2, !tbaa !24
  %t8 = icmp sgt i64 %t4, %t5
  br i1 %t8, label %bb2, label %bb3
bb2:
  %t10 = load i64, ptr %l4, !tbaa !24
  %t12 = icmp sgt i64 %t10, 0
  br i1 %t12, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l13, !tbaa !24
  br label %bb7
bb4:
  %t14 = load i64, ptr %l3, !tbaa !24
  %t15 = load i64, ptr %l2, !tbaa !24
  %t18 = sub i64 %t14, %t15
  %t19 = load i64, ptr %l4, !tbaa !24
  %t22 = add i64 %t18, %t19
  %t24 = sub i64 %t22, 1
  %t25 = load i64, ptr %l4, !tbaa !24
  %t28 = sdiv i64 %t24, %t25
  store i64 %t28, ptr %l16, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l16, !tbaa !24
  br label %bb6
bb6:
  %t30 = load i64, ptr %l16, !tbaa !24
  store i64 %t30, ptr %l13, !tbaa !24
  br label %bb7
bb7:
  %t31 = load i64, ptr %l13, !tbaa !24
  store i64 %t31, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t32 = load i64, ptr %l6, !tbaa !24
  %t33 = load i64, ptr %l5, !tbaa !24
  %t36 = icmp slt i64 %t32, %t33
  %t38 = xor i1 %t36, true
  br i1 %t38, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb17
bb10:
  br label %bb11
bb11:
  %t40 = load i64, ptr %l2, !tbaa !24
  %t41 = load i64, ptr %l6, !tbaa !24
  %t42 = load i64, ptr %l4, !tbaa !24
  %t45 = mul i64 %t41, %t42
  %t48 = add i64 %t40, %t45
  store i64 %t48, ptr %l7, !tbaa !24
  %t50 = load i64, ptr %l7, !tbaa !24
  %t53 = call i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %l0, i64 %t50)
  store i32 %t53, ptr %l36
  br label %bb12
bb12:
  %t55 = load i32, ptr %l36, !tbaa !23
  %t57 = icmp eq i32 %t55, %a1
  br i1 %t57, label %bb13, label %bb14
bb13:
  %t59 = load i64, ptr %l7, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  store i64 %t59, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s2)
  br label %bb16
bb16:
  %t61 = load i64, ptr %l6, !tbaa !24
  %t63 = add i64 %t61, 1
  store i64 %t63, ptr %l6, !tbaa !24
  br label %bb8
bb17:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { { i64, ptr }, { i64, ptr } } @compiler_2flower_2elowerText(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l3 = alloca %"compiler/cond:Consts"
  %l4 = alloca %"compiler/load:Loader"
  %l5 = alloca %"compiler/names:Resolver"
  %l6 = alloca %"compiler/generic:Program"
  %l7 = alloca %"compiler/check:Checker"
  %l8 = alloca %"compiler/lower:Lowerer"
  %l9 = alloca %"std/prelude/text:StringBuilder"
  %l10 = alloca %"std/prelude/text:StringBuilder"
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca ptr
  %l19 = alloca { i64, ptr }
  %l20 = alloca { i64, [2 x i64] }
  %l21 = alloca i64
  %l24 = alloca { i1, { i64, ptr }, { i64, ptr } }
  %l26 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca { i64, ptr }
  %l32 = alloca ptr
  %l33 = alloca i64
  %l34 = alloca { i64, ptr }
  %l35 = alloca i64
  %l36 = alloca i64
  %l38 = alloca i64
  %l39 = alloca { i64, [2 x i64] }
  %l40 = alloca { i1, { i64, ptr }, { i64, ptr } }
  %l42 = alloca { i64, ptr }
  %l43 = alloca { i64, ptr }
  %l44 = alloca i64
  %l45 = alloca i64
  %l46 = alloca { i64, ptr }
  %l47 = alloca ptr
  %l48 = alloca i64
  %l49 = alloca { i64, ptr }
  %l50 = alloca i64
  %l51 = alloca i64
  %l52 = alloca %"compiler/lower:Gap"
  %l53 = alloca { i64, ptr }
  %l54 = alloca { i64, ptr }
  %l55 = alloca i32
  %l63 = alloca i32
  %l66 = alloca %"compiler/cond:Consts"
  %l68 = alloca ptr
  %l75 = alloca %"compiler/fetch:Fetcher"
  %l76 = alloca ptr
  %l77 = alloca %"compiler/source:Names"
  %l78 = alloca ptr
  %l79 = alloca %"compiler/diag:Diagnostics"
  %l81 = alloca %"compiler/load:Loader"
  %l86 = alloca i64
  %l88 = alloca %"compiler/names:Resolver"
  %l92 = alloca %"compiler/generic:Program"
  %l94 = alloca %"compiler/check:Checker"
  %l98 = alloca %"compiler/lower:Lowerer"
  %l99 = alloca %"std/prelude/text:StringBuilder"
  %l100 = alloca %"std/prelude/text:StringBuilder"
  %l103 = alloca ptr
  %l107 = alloca i64
  %l111 = alloca i64
  %l114 = alloca i64
  %l134 = alloca i1
  %l138 = alloca ptr
  %l139 = alloca { i64, ptr }
  %l140 = alloca { i64, ptr }
  %l141 = alloca i64
  %l142 = alloca { i64, ptr }
  %l149 = alloca ptr
  %l150 = alloca ptr
  %l153 = alloca i64
  %l154 = alloca ptr
  %l157 = alloca { i64, ptr }
  %l158 = alloca { i64, ptr }
  %l160 = alloca i64
  %l166 = alloca i1
  %l167 = alloca { i64, ptr }
  %l168 = alloca i64
  %l169 = alloca { i64, ptr }
  %l172 = alloca i1
  %l176 = alloca { i1, { i64, ptr }, { i64, ptr } }
  %l178 = alloca { i64, ptr }
  %l179 = alloca i64
  %l180 = alloca { i64, ptr }
  %l181 = alloca { i64, ptr }
  %l182 = alloca i64
  %l183 = alloca { i64, ptr }
  %l190 = alloca { i64, ptr }
  %l197 = alloca { i64, ptr }
  %l215 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l217 = alloca { i64, ptr }
  %l220 = alloca { i64, ptr }
  %l221 = alloca i32
  %l230 = alloca { i64, ptr }
  %l241 = alloca i64
  %l243 = alloca i64
  %l248 = alloca { i64, [2 x i64] }
  %l253 = alloca { i1, { i64, ptr }, { i64, ptr } }
  %l255 = alloca { i64, ptr }
  %l256 = alloca i64
  %l257 = alloca { i64, ptr }
  %l259 = alloca ptr
  %l260 = alloca { i64, [2 x i64] }
  %l262 = alloca { i64, ptr }
  %l265 = alloca { i64, ptr }
  %l272 = alloca { i64, ptr }
  %l278 = alloca ptr
  %l279 = alloca { i64, [2 x i64] }
  %l280 = alloca { i64, ptr }
  %l282 = alloca { i64, ptr }
  %l287 = alloca { i64, ptr }
  %l290 = alloca { i64, ptr }
  %l291 = alloca i32
  %l300 = alloca { i64, ptr }
  %l313 = alloca { i64, ptr }
  %l314 = alloca { i64, ptr }
  %l316 = alloca { i64, ptr }
  %l318 = alloca { { i64, ptr }, { i64, ptr } }
  %l319 = alloca { i64, ptr }
  %l320 = alloca i64
  %l321 = alloca { i64, ptr }
  %l322 = alloca { i64, ptr }
  %l323 = alloca i64
  %l324 = alloca { i64, ptr }
  %l326 = alloca i32
  %s0 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %s25 = alloca %olang.scope
  %s26 = alloca %olang.scope
  %s27 = alloca %olang.builder
  %s27room = alloca [64 x i8], align 8
  %s28 = alloca %olang.scope
  %s29 = alloca %olang.scope
  %s30 = alloca %olang.scope
  %s31 = alloca %olang.builder
  %s31room = alloca [64 x i8], align 8
  %s34 = alloca %olang.scope
  %s35 = alloca %olang.scope
  %rv = alloca { { i64, ptr }, { i64, ptr } }
  %t90 = alloca %"compiler/diag:Diagnostics", align 8
  %t123 = alloca %"compiler/generic:Program", align 8
  %t126 = alloca %"compiler/check:Checker", align 8
  %t498 = alloca { i64, [2 x i64] }, align 8
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call { i32, { i64, ptr } } @std_2fos_2eMkTemp(ptr %s0, ptr %s0, ptr %s0, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d36, i32 0, i32 1) }, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d37, i32 0, i32 1) })
  %t2 = extractvalue { i32, { i64, ptr } } %t1, 1
  %t3 = extractvalue { i32, { i64, ptr } } %t1, 0
  store i32 %t3, ptr %l55
  %t4 = icmp ne i32 %t3, 0
  br i1 %t4, label %bb2, label %ok.5
ok.5:
  store { i64, ptr } %t2, ptr %l54
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l54, !tbaa !27
  store { i64, ptr } %t6, ptr %l53, !tbaa !27
  br label %bb6
bb2:
  %t7 = load i32, ptr %l55, !tbaa !23
  %t8 = ashr i32 %t7, 16
  %t10 = icmp eq i32 %t8, 1
  br i1 %t10, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  call void @__olang_check_failed(ptr @olang_loc_81127ece44b68b70_f66d78f9cc0faa8c)
  unreachable
bb5:
  call void @__olang_ert_req_clear()
  call void @__olang_check_failed(ptr @olang_loc_81127ece44b68b70_f66d78f9cc0faa8c)
  unreachable
bb6:
  %t12 = load { i64, ptr }, ptr %l53, !tbaa !27
  store { i64, ptr } %t12, ptr %l2, !tbaa !27
  %t13 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 1
  %t16 = extractvalue { i64, ptr } %t13, 0
  %t17 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d38, i32 0, i32 1) }, 1
  %t18 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d38, i32 0, i32 1) }, 0
  %t19 = add i64 %t16, %t18
  %t20 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t19)
  call void @olang_textcopy(ptr %t20, ptr %t15, i64 %t16)
  %t21 = getelementptr i8, ptr %t20, i64 %t16
  call void @olang_textcopy(ptr %t21, ptr %t17, i64 %t18)
  %t22 = insertvalue { i64, ptr } undef, i64 %t19, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t20, 1
  %t25 = extractvalue { i64, ptr } %t23, 0
  %t26 = extractvalue { i64, ptr } %t23, 1
  %t27 = mul i64 %t25, 1
  %t28 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t27)
  call void @llvm.memcpy.p0.p0.i64(ptr %t28, ptr %t26, i64 %t27, i1 false)
  %t29 = insertvalue { i64, ptr } undef, i64 %t25, 0
  %t30 = insertvalue { i64, ptr } %t29, ptr %t28, 1
  %t35 = call i32 @std_2fos_2eWriteFile(ptr %s0, ptr %v0, { i64, ptr } %t30, { i64, ptr } %a0)
  store i32 %t35, ptr %l63
  %t36 = icmp ne i32 %t35, 0
  br i1 %t36, label %bb8, label %ok.37
ok.37:
  br label %bb7
bb7:
  br label %bb12
bb8:
  %t38 = load i32, ptr %l63, !tbaa !23
  %t39 = ashr i32 %t38, 16
  %t41 = icmp eq i32 %t39, 1
  br i1 %t41, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_7f253c69ef622f01_ac20b514bf3261bd)
  unreachable
bb11:
  call void @__olang_ert_req_clear()
  br label %bb12
bb12:
  %t43 = call %"compiler/cond:Consts" @compiler_2fcond_3aConsts_2ector(ptr %s0)
  store %"compiler/cond:Consts" %t43, ptr %l66
  br label %bb13
bb13:
  %t44 = load %"compiler/cond:Consts", ptr %l66
  store %"compiler/cond:Consts" %t44, ptr %l3
  call void @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eBuiltins(ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %l3, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d39, i32 0, i32 1) }, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d40, i32 0, i32 1) }, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d41, i32 0, i32 1) }, i64 128, i64 0, i1 false, i1 false, i1 false)
  br label %bb14
bb14:
  store ptr %l3, ptr %l68, !tbaa !29
  %t46 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t48 = extractvalue { i64, ptr } %t46, 1
  %t49 = extractvalue { i64, ptr } %t46, 0
  %t50 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d42, i32 0, i32 1) }, 1
  %t51 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d42, i32 0, i32 1) }, 0
  %t52 = add i64 %t49, %t51
  %t53 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t52)
  call void @olang_textcopy(ptr %t53, ptr %t48, i64 %t49)
  %t54 = getelementptr i8, ptr %t53, i64 %t49
  call void @olang_textcopy(ptr %t54, ptr %t50, i64 %t51)
  %t55 = insertvalue { i64, ptr } undef, i64 %t52, 0
  %t56 = insertvalue { i64, ptr } %t55, ptr %t53, 1
  %t58 = extractvalue { i64, ptr } %t56, 0
  %t59 = extractvalue { i64, ptr } %t56, 1
  %t60 = mul i64 %t58, 1
  %t61 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t60)
  call void @llvm.memcpy.p0.p0.i64(ptr %t61, ptr %t59, i64 %t60, i1 false)
  %t62 = insertvalue { i64, ptr } undef, i64 %t58, 0
  %t63 = insertvalue { i64, ptr } %t62, ptr %t61, 1
  %t64 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t66 = extractvalue { i64, ptr } %t64, 1
  %t67 = extractvalue { i64, ptr } %t64, 0
  %t68 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d43, i32 0, i32 1) }, 1
  %t69 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d43, i32 0, i32 1) }, 0
  %t70 = add i64 %t67, %t69
  %t71 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t70)
  call void @olang_textcopy(ptr %t71, ptr %t66, i64 %t67)
  %t72 = getelementptr i8, ptr %t71, i64 %t67
  call void @olang_textcopy(ptr %t72, ptr %t68, i64 %t69)
  %t73 = insertvalue { i64, ptr } undef, i64 %t70, 0
  %t74 = insertvalue { i64, ptr } %t73, ptr %t71, 1
  %t76 = extractvalue { i64, ptr } %t74, 0
  %t77 = extractvalue { i64, ptr } %t74, 1
  %t78 = mul i64 %t76, 1
  %t79 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t78)
  call void @llvm.memcpy.p0.p0.i64(ptr %t79, ptr %t77, i64 %t78, i1 false)
  %t80 = insertvalue { i64, ptr } undef, i64 %t76, 0
  %t81 = insertvalue { i64, ptr } %t80, ptr %t79, 1
  %t84 = call %"compiler/fetch:Fetcher" @compiler_2ffetch_3aFetcher_2ector(ptr %s0, ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t63, { i64, ptr } %t81, { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d44, i32 0, i32 1) }, i1 false, i1 true)
  store %"compiler/fetch:Fetcher" %t84, ptr %l75
  br label %bb15
bb15:
  %t85 = load %"compiler/fetch:Fetcher", ptr %l75
  %t86 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 88, i64 8)
  store %"compiler/fetch:Fetcher" %t85, ptr %t86
  store ptr %t86, ptr %l76, !tbaa !29
  %t87 = call %"compiler/source:Names" @compiler_2fsource_3aNames_2ector(ptr %s0)
  store %"compiler/source:Names" %t87, ptr %l77
  br label %bb16
bb16:
  %t88 = load %"compiler/source:Names", ptr %l77
  %t89 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 16, i64 8)
  store %"compiler/source:Names" %t88, ptr %t89
  store ptr %t89, ptr %l78, !tbaa !29
  call void @compiler_2fdiag_3aDiagnostics_2ector(ptr %t90, ptr %s0, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %l79, ptr %t90, i64 200, i1 false)
  br label %bb17
bb17:
  %t91 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 200, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t91, ptr %l79, i64 200, i1 false)
  %t92 = load ptr, ptr %l68, !tbaa !29
  %t93 = load ptr, ptr %l76, !tbaa !29
  %t94 = load ptr, ptr %l78, !tbaa !29
  %t96 = call %"compiler/load:Loader" @compiler_2fload_3aLoader_2ector(ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d45, i32 0, i32 1) }, ptr %t92, ptr %t93, ptr %t94, ptr %t91)
  store %"compiler/load:Loader" %t96, ptr %l81
  br label %bb18
bb18:
  %t97 = load %"compiler/load:Loader", ptr %l81
  store %"compiler/load:Loader" %t97, ptr %l4
  %t98 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t100 = extractvalue { i64, ptr } %t98, 1
  %t101 = extractvalue { i64, ptr } %t98, 0
  %t102 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d46, i32 0, i32 1) }, 1
  %t103 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d46, i32 0, i32 1) }, 0
  %t104 = add i64 %t101, %t103
  %t105 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t104)
  call void @olang_textcopy(ptr %t105, ptr %t100, i64 %t101)
  %t106 = getelementptr i8, ptr %t105, i64 %t101
  call void @olang_textcopy(ptr %t106, ptr %t102, i64 %t103)
  %t107 = insertvalue { i64, ptr } undef, i64 %t104, 0
  %t108 = insertvalue { i64, ptr } %t107, ptr %t105, 1
  %t110 = extractvalue { i64, ptr } %t108, 0
  %t111 = extractvalue { i64, ptr } %t108, 1
  %t112 = mul i64 %t110, 1
  %t113 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t112)
  call void @llvm.memcpy.p0.p0.i64(ptr %t113, ptr %t111, i64 %t112, i1 false)
  %t114 = insertvalue { i64, ptr } undef, i64 %t110, 0
  %t115 = insertvalue { i64, ptr } %t114, ptr %t113, 1
  %t118 = call i64 @compiler_2fload_2ecompiler_2fload_3aLoader_2eLoad(ptr %s0, ptr %s0, ptr %l4, { i64, ptr } %t115)
  store i64 %t118, ptr %l86
  br label %bb19
bb19:
  %t120 = call %"compiler/names:Resolver" @compiler_2fnames_3aResolver_2ector(ptr %s0, ptr %s0, ptr %l4)
  store %"compiler/names:Resolver" %t120, ptr %l88
  br label %bb20
bb20:
  %t121 = load %"compiler/names:Resolver", ptr %l88
  store %"compiler/names:Resolver" %t121, ptr %l5
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eResolve(ptr %s0, ptr %l5)
  br label %bb21
bb21:
  call void @compiler_2fgeneric_3aProgram_2ector(ptr %t123, ptr %s0, ptr %s0, ptr %s0, ptr %l4, ptr %l5)
  call void @llvm.memmove.p0.p0.i64(ptr %l92, ptr %t123, i64 640, i1 false)
  br label %bb22
bb22:
  call void @llvm.memmove.p0.p0.i64(ptr %l6, ptr %l92, i64 640, i1 false)
  call void @compiler_2fcheck_3aChecker_2ector(ptr %t126, ptr %s0, ptr %s0, ptr %l6, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %l94, ptr %t126, i64 752, i1 false)
  br label %bb23
bb23:
  call void @llvm.memmove.p0.p0.i64(ptr %l7, ptr %l94, i64 752, i1 false)
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eCheckProgram(ptr %s0, ptr %l7)
  br label %bb24
bb24:
  %t129 = getelementptr %"compiler/check:Checker", ptr %l7, i32 0, i32 11
  %t130 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t129
  %t133 = call %"compiler/lower:Lowerer" @compiler_2flower_3aLowerer_2ector(ptr %s0, ptr %s0, ptr %s0, ptr %l6, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t130)
  store %"compiler/lower:Lowerer" %t133, ptr %l98
  br label %bb25
bb25:
  %t134 = load %"compiler/lower:Lowerer", ptr %l98
  store %"compiler/lower:Lowerer" %t134, ptr %l8
  %t135 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t135, ptr %l99
  br label %bb26
bb26:
  %t136 = load %"std/prelude/text:StringBuilder", ptr %l99
  store %"std/prelude/text:StringBuilder" %t136, ptr %l9
  %t137 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t137, ptr %l100
  br label %bb27
bb27:
  %t138 = load %"std/prelude/text:StringBuilder", ptr %l100
  store %"std/prelude/text:StringBuilder" %t138, ptr %l10
  %t139 = getelementptr %"compiler/load:Loader", ptr %l4, i32 0, i32 5
  %t140 = getelementptr %"compiler/load:Loader", ptr %l4, i32 0, i32 7
  %t141 = load i64, ptr %t140, !tbaa !24
  %t144 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %s0, ptr %s0, ptr %t139, i64 %t141)
  store ptr %t144, ptr %l103
  br label %bb28
bb28:
  %t145 = load ptr, ptr %l103, !tbaa !29
  %t147 = getelementptr %"compiler/load:Module", ptr %t145, i32 0, i32 4
  %t148 = load i64, ptr %t147, !tbaa !24
  store i64 %t148, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  %t150 = getelementptr %"compiler/check:Checker", ptr %l7, i32 0, i32 11
  %t152 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_Ha6bcf4d517e3d7b46809e1dbf938da91(ptr %s0, ptr %t150)
  store i64 %t152, ptr %l107
  br label %bb29
bb29:
  %t153 = load i64, ptr %l107, !tbaa !24
  store i64 %t153, ptr %l13, !tbaa !24
  store i64 1, ptr %l14, !tbaa !24
  %t154 = load i64, ptr %l13, !tbaa !24
  %t155 = load i64, ptr %l12, !tbaa !24
  %t158 = icmp sgt i64 %t154, %t155
  br i1 %t158, label %bb30, label %bb31
bb30:
  %t160 = load i64, ptr %l14, !tbaa !24
  %t162 = icmp sgt i64 %t160, 0
  br i1 %t162, label %bb32, label %bb33
bb31:
  store i64 0, ptr %l111, !tbaa !24
  br label %bb35
bb32:
  %t164 = load i64, ptr %l13, !tbaa !24
  %t165 = load i64, ptr %l12, !tbaa !24
  %t168 = sub i64 %t164, %t165
  %t169 = load i64, ptr %l14, !tbaa !24
  %t172 = add i64 %t168, %t169
  %t174 = sub i64 %t172, 1
  %t175 = load i64, ptr %l14, !tbaa !24
  %t178 = sdiv i64 %t174, %t175
  store i64 %t178, ptr %l114, !tbaa !24
  br label %bb34
bb33:
  store i64 0, ptr %l114, !tbaa !24
  br label %bb34
bb34:
  %t180 = load i64, ptr %l114, !tbaa !24
  store i64 %t180, ptr %l111, !tbaa !24
  br label %bb35
bb35:
  %t181 = load i64, ptr %l111, !tbaa !24
  store i64 %t181, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  br label %bb36
bb36:
  store %olang.scope zeroinitializer, ptr %s8
  %t182 = load i64, ptr %l16, !tbaa !24
  %t183 = load i64, ptr %l15, !tbaa !24
  %t186 = icmp slt i64 %t182, %t183
  %t188 = xor i1 %t186, true
  br i1 %t188, label %bb37, label %bb38
bb37:
  call void @__olang_scope_close(ptr %s8)
  br label %bb82
bb38:
  br label %bb39
bb39:
  %t190 = load i64, ptr %l12, !tbaa !24
  %t191 = load i64, ptr %l16, !tbaa !24
  %t192 = load i64, ptr %l14, !tbaa !24
  %t195 = mul i64 %t191, %t192
  %t198 = add i64 %t190, %t195
  store i64 %t198, ptr %l17, !tbaa !24
  %t200 = load i64, ptr %l17, !tbaa !24
  %t203 = call i1 @compiler_2flower_2ecompiler_2flower_3aLowerer_2eHasCode(ptr %s0, ptr %l8, i64 %t200)
  store i1 %t203, ptr %l134
  br label %bb40
bb40:
  %t204 = load i1, ptr %l134, !tbaa !21
  %t205 = xor i1 %t204, true
  br i1 %t205, label %bb41, label %bb42
bb41:
  call void @__olang_scope_close(ptr %s8)
  br label %bb81
bb42:
  br label %bb43
bb43:
  %t207 = getelementptr %"compiler/check:Checker", ptr %l7, i32 0, i32 11
  %t208 = load i64, ptr %l17, !tbaa !24
  %t211 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %s0, ptr %s0, ptr %t207, i64 %t208)
  store ptr %t211, ptr %l138
  br label %bb44
bb44:
  %t212 = load ptr, ptr %l138, !tbaa !29
  store ptr %t212, ptr %l18, !tbaa !29
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d47, i32 0, i32 1) }, ptr %l139, !tbaa !27
  %t213 = load { i64, ptr }, ptr %l139, !tbaa !27
  store { i64, ptr } %t213, ptr %l140, !tbaa !27
  %t214 = load { i64, ptr }, ptr %l140, !tbaa !27
  %t215 = extractvalue { i64, ptr } %t214, 0
  store i64 %t215, ptr %l141, !tbaa !24
  %t216 = load i64, ptr %l141, !tbaa !24
  %t217 = mul i64 %t216, 1
  %t218 = call ptr @__olang_scope_alloc_zeroed(ptr %s8, i64 %t217)
  %t219 = insertvalue { i64, ptr } undef, i64 %t216, 0
  %t220 = insertvalue { i64, ptr } %t219, ptr %t218, 1
  store { i64, ptr } %t220, ptr %l142, !tbaa !27
  %t221 = getelementptr { i64, ptr }, ptr %l142, i32 0, i32 1
  %t222 = load ptr, ptr %t221, !tbaa !27
  %t223 = getelementptr { i64, ptr }, ptr %l140, i32 0, i32 1
  %t224 = load ptr, ptr %t223, !tbaa !27
  %t225 = load i64, ptr %l141, !tbaa !24
  %t226 = mul i64 %t225, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t222, ptr %t224, i64 %t226, i1 false)
  %t227 = load { i64, ptr }, ptr %l142, !tbaa !27
  store { i64, ptr } %t227, ptr %l19, !tbaa !27
  %t228 = load ptr, ptr %l18, !tbaa !29
  %t230 = getelementptr %"compiler/typed:Body", ptr %t228, i32 0, i32 1
  %t231 = load { i64, [2 x i64] }, ptr %t230
  store { i64, [2 x i64] } %t231, ptr %l20
  %t233 = load { i64, [2 x i64] }, ptr %l20
  %t235 = extractvalue { i64, [2 x i64] } %t233, 0
  %t236 = icmp eq i64 %t235, 0
  br i1 %t236, label %bb45, label %bb46
bb45:
  %t238 = getelementptr { i64, [2 x i64] }, ptr %l20, i32 0, i32 1
  %t239 = getelementptr { i64 }, ptr %t238, i32 0, i32 0
  %t240 = load i64, ptr %t239
  store i64 %t240, ptr %l21, !tbaa !24
  br label %bb47
bb46:
  br label %bb54
bb47:
  %t242 = getelementptr %"compiler/generic:Program", ptr %l6, i32 0, i32 0
  %t243 = load ptr, ptr %t242, !tbaa !29
  %t245 = getelementptr %"compiler/load:Loader", ptr %t243, i32 0, i32 3
  %t246 = load ptr, ptr %t245, !tbaa !29
  store ptr %t246, ptr %l149, !tbaa !29
  store ptr %l6, ptr %l150, !tbaa !29
  %t247 = load i64, ptr %l21, !tbaa !24
  %t250 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %s0, ptr %l6, i64 %t247)
  store i64 %t250, ptr %l153
  br label %bb48
bb48:
  %t251 = load ptr, ptr %l150, !tbaa !29
  %t252 = load i64, ptr %l153, !tbaa !24
  %t253 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %s0, ptr %t251, i64 %t252)
  store ptr %t253, ptr %l154
  br label %bb49
bb49:
  %t254 = load ptr, ptr %l154, !tbaa !29
  %t256 = getelementptr %"compiler/ast:Func", ptr %t254, i32 0, i32 2
  %t257 = load i32, ptr %t256, !tbaa !23
  %t258 = load ptr, ptr %l149, !tbaa !29
  %t260 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %s0, ptr %t258, i32 %t257)
  store { i64, ptr } %t260, ptr %l157
  br label %bb50
bb50:
  %t261 = load { i64, ptr }, ptr %l157, !tbaa !27
  %t262 = extractvalue { i64, ptr } %t261, 1
  %t263 = extractvalue { i64, ptr } %t261, 0
  %t264 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t263)
  call void @olang_textcopy(ptr %t264, ptr %t262, i64 %t263)
  %t265 = insertvalue { i64, ptr } undef, i64 %t263, 0
  %t266 = insertvalue { i64, ptr } %t265, ptr %t264, 1
  store { i64, ptr } %t266, ptr %l158, !tbaa !27
  %t267 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t268 = extractvalue { i64, ptr } %t267, 0
  %t269 = load { i64, ptr }, ptr %l158, !tbaa !27
  %t270 = extractvalue { i64, ptr } %t269, 0
  store i64 %t270, ptr %l160, !tbaa !24
  %t272 = load i64, ptr %l160, !tbaa !24
  %t273 = icmp eq i64 %t268, %t272
  br i1 %t273, label %bb51, label %bb52
bb51:
  %t275 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t276 = load ptr, ptr %t275, !tbaa !27
  %t277 = getelementptr { i64, ptr }, ptr %l158, i32 0, i32 1
  %t278 = load ptr, ptr %t277, !tbaa !27
  %t279 = load i64, ptr %l160, !tbaa !24
  %t280 = mul i64 %t279, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t276, ptr %t278, i64 %t280, i1 false)
  br label %bb53
bb52:
  %t281 = load { i64, ptr }, ptr %l158, !tbaa !27
  store { i64, ptr } %t281, ptr %l19, !tbaa !27
  br label %bb53
bb53:
  br label %bb59
bb54:
  br i1 true, label %bb55, label %bb56
bb55:
  br label %bb57
bb56:
  br label %bb58
bb57:
  br label %bb59
bb58:
  call void @__olang_check_failed(ptr @olang_loc_39416637e90302ea_f3cefb4d13e12826)
  unreachable
bb59:
  %t282 = load ptr, ptr %l18, !tbaa !29
  %t284 = getelementptr %"compiler/typed:Body", ptr %t282, i32 0, i32 3
  %t285 = load i64, ptr %t284, !tbaa !24
  %t286 = load i64, ptr %l11, !tbaa !24
  %t289 = icmp eq i64 %t285, %t286
  br i1 %t289, label %bb60, label %bb61
bb60:
  %t291 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t291, ptr %l167, !tbaa !27
  %t292 = load { i64, ptr }, ptr %l167, !tbaa !27
  %t293 = extractvalue { i64, ptr } %t292, 0
  store i64 %t293, ptr %l168, !tbaa !24
  %t294 = load i64, ptr %l168, !tbaa !24
  %t295 = mul i64 %t294, 1
  %t296 = call ptr @__olang_scope_alloc_zeroed(ptr %s8, i64 %t295)
  %t297 = insertvalue { i64, ptr } undef, i64 %t294, 0
  %t298 = insertvalue { i64, ptr } %t297, ptr %t296, 1
  store { i64, ptr } %t298, ptr %l169, !tbaa !27
  %t299 = getelementptr { i64, ptr }, ptr %l169, i32 0, i32 1
  %t300 = load ptr, ptr %t299, !tbaa !27
  %t301 = getelementptr { i64, ptr }, ptr %l167, i32 0, i32 1
  %t302 = load ptr, ptr %t301, !tbaa !27
  %t303 = load i64, ptr %l168, !tbaa !24
  %t304 = mul i64 %t303, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t300, ptr %t302, i64 %t304, i1 false)
  %t305 = load { i64, ptr }, ptr %l169, !tbaa !27
  %t310 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2eHas_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v1, ptr %s8, { i64, ptr } %a1, { i64, ptr } %t305)
  store i1 %t310, ptr %l172
  br label %bb62
bb61:
  store i1 false, ptr %l166, !tbaa !21
  br label %bb63
bb62:
  %t311 = load i1, ptr %l172, !tbaa !21
  store i1 %t311, ptr %l166, !tbaa !21
  br label %bb63
bb63:
  %t312 = load i1, ptr %l166, !tbaa !21
  %t313 = load i64, ptr %l17, !tbaa !24
  %t318 = call { i1, { i64, ptr }, { i64, ptr } } @compiler_2flower_2ecompiler_2flower_3aLowerer_2eVerified(ptr %s0, ptr %s8, ptr %l8, i64 %t313, i1 %t312)
  store { i1, { i64, ptr }, { i64, ptr } } %t318, ptr %l176
  br label %bb64
bb64:
  %t319 = load { i1, { i64, ptr }, { i64, ptr } }, ptr %l176
  store { i1, { i64, ptr }, { i64, ptr } } %t319, ptr %l24
  %t320 = getelementptr { i1, { i64, ptr }, { i64, ptr } }, ptr %l24, i32 0, i32 0
  %t321 = load i1, ptr %t320, !tbaa !21
  %t323 = getelementptr { i1, { i64, ptr }, { i64, ptr } }, ptr %l24, i32 0, i32 1
  %t324 = load { i64, ptr }, ptr %t323, !tbaa !27
  store { i64, ptr } %t324, ptr %l178, !tbaa !27
  %t325 = load { i64, ptr }, ptr %l178, !tbaa !27
  %t326 = extractvalue { i64, ptr } %t325, 0
  store i64 %t326, ptr %l179, !tbaa !24
  %t327 = load i64, ptr %l179, !tbaa !24
  %t328 = mul i64 %t327, 1
  %t329 = call ptr @__olang_scope_alloc_zeroed(ptr %s8, i64 %t328)
  %t330 = insertvalue { i64, ptr } undef, i64 %t327, 0
  %t331 = insertvalue { i64, ptr } %t330, ptr %t329, 1
  store { i64, ptr } %t331, ptr %l180, !tbaa !27
  %t332 = getelementptr { i64, ptr }, ptr %l180, i32 0, i32 1
  %t333 = load ptr, ptr %t332, !tbaa !27
  %t334 = getelementptr { i64, ptr }, ptr %l178, i32 0, i32 1
  %t335 = load ptr, ptr %t334, !tbaa !27
  %t336 = load i64, ptr %l179, !tbaa !24
  %t337 = mul i64 %t336, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t333, ptr %t335, i64 %t337, i1 false)
  %t338 = load { i64, ptr }, ptr %l180, !tbaa !27
  store { i64, ptr } %t338, ptr %l26, !tbaa !27
  %t339 = getelementptr { i1, { i64, ptr }, { i64, ptr } }, ptr %l24, i32 0, i32 2
  %t340 = load { i64, ptr }, ptr %t339, !tbaa !27
  store { i64, ptr } %t340, ptr %l181, !tbaa !27
  %t341 = load { i64, ptr }, ptr %l181, !tbaa !27
  %t342 = extractvalue { i64, ptr } %t341, 0
  store i64 %t342, ptr %l182, !tbaa !24
  %t343 = load i64, ptr %l182, !tbaa !24
  %t344 = mul i64 %t343, 1
  %t345 = call ptr @__olang_scope_alloc_zeroed(ptr %s8, i64 %t344)
  %t346 = insertvalue { i64, ptr } undef, i64 %t343, 0
  %t347 = insertvalue { i64, ptr } %t346, ptr %t345, 1
  store { i64, ptr } %t347, ptr %l183, !tbaa !27
  %t348 = getelementptr { i64, ptr }, ptr %l183, i32 0, i32 1
  %t349 = load ptr, ptr %t348, !tbaa !27
  %t350 = getelementptr { i64, ptr }, ptr %l181, i32 0, i32 1
  %t351 = load ptr, ptr %t350, !tbaa !27
  %t352 = load i64, ptr %l182, !tbaa !24
  %t353 = mul i64 %t352, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t349, ptr %t351, i64 %t353, i1 false)
  %t354 = load { i64, ptr }, ptr %l183, !tbaa !27
  store { i64, ptr } %t354, ptr %l27, !tbaa !27
  br i1 %t321, label %bb65, label %bb66
bb65:
  store %olang.scope zeroinitializer, ptr %s13
  %t357 = load i64, ptr %l17, !tbaa !24
  %t358 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d48, i32 0, i32 1) }, 1
  %t359 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d48, i32 0, i32 1) }, 0
  %t361 = call i64 @__olang_fmt_i64(ptr null, i64 %t357)
  %t362 = add i64 %t359, %t361
  %t363 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d49, i32 0, i32 1) }, 1
  %t364 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d49, i32 0, i32 1) }, 0
  %t365 = add i64 %t362, %t364
  %t366 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t365)
  call void @olang_textcopy(ptr %t366, ptr %t358, i64 %t359)
  %t367 = getelementptr i8, ptr %t366, i64 %t359
  %t368 = call i64 @__olang_fmt_i64(ptr %t367, i64 %t357)
  %t369 = getelementptr i8, ptr %t367, i64 %t361
  call void @olang_textcopy(ptr %t369, ptr %t363, i64 %t364)
  %t370 = insertvalue { i64, ptr } undef, i64 %t365, 0
  %t371 = insertvalue { i64, ptr } %t370, ptr %t366, 1
  %t373 = extractvalue { i64, ptr } %t371, 0
  %t374 = extractvalue { i64, ptr } %t371, 1
  %t375 = mul i64 %t373, 1
  %t376 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t375)
  call void @llvm.memcpy.p0.p0.i64(ptr %t376, ptr %t374, i64 %t375, i1 false)
  %t377 = insertvalue { i64, ptr } undef, i64 %t373, 0
  %t378 = insertvalue { i64, ptr } %t377, ptr %t376, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s13, ptr %l9, { i64, ptr } %t378)
  br label %bb67
bb66:
  br label %bb68
bb67:
  call void @__olang_scope_close(ptr %s13)
  br label %bb68
bb68:
  store %olang.scope zeroinitializer, ptr %s15
  %t381 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t383 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eSplit(ptr %s8, ptr %s15, { i64, ptr } %t381, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d50, i32 0, i32 1) })
  store { i64, ptr } %t383, ptr %l190
  br label %bb69
bb69:
  %t384 = load { i64, ptr }, ptr %l190, !tbaa !27
  store { i64, ptr } %t384, ptr %l28, !tbaa !27
  store i64 0, ptr %l29, !tbaa !24
  %t385 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t387 = extractvalue { i64, ptr } %t385, 0
  store i64 %t387, ptr %l30, !tbaa !24
  br label %bb70
bb70:
  store %olang.scope zeroinitializer, ptr %s16
  %t389 = load i64, ptr %l29, !tbaa !24
  %t390 = load i64, ptr %l30, !tbaa !24
  %t393 = icmp slt i64 %t389, %t390
  %t395 = xor i1 %t393, true
  br i1 %t395, label %bb71, label %bb72
bb71:
  call void @__olang_scope_close(ptr %s16)
  br label %bb79
bb72:
  br label %bb73
bb73:
  %t397 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t397, ptr %l197, !tbaa !27
  %t398 = load i64, ptr %l29, !tbaa !24
  %t400 = getelementptr { i64, ptr }, ptr %l197, i32 0, i32 1
  %t401 = load ptr, ptr %t400, !tbaa !27
  %t402 = getelementptr { i64, ptr }, ptr %t401, i64 %t398
  %t403 = load { i64, ptr }, ptr %t402, !tbaa !37
  store { i64, ptr } %t403, ptr %l31, !tbaa !27
  %t405 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t407 = extractvalue { i64, ptr } %t405, 0
  %t409 = icmp sgt i64 %t407, 0
  br i1 %t409, label %bb74, label %bb75
bb74:
  store %olang.scope zeroinitializer, ptr %s17
  %t411 = load i64, ptr %l17, !tbaa !24
  %t412 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t413 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d51, i32 0, i32 1) }, 1
  %t414 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d51, i32 0, i32 1) }, 0
  %t416 = call i64 @__olang_fmt_i64(ptr null, i64 %t411)
  %t417 = add i64 %t414, %t416
  %t418 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d52, i32 0, i32 1) }, 1
  %t419 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d52, i32 0, i32 1) }, 0
  %t420 = add i64 %t417, %t419
  %t422 = extractvalue { i64, ptr } %t412, 1
  %t423 = extractvalue { i64, ptr } %t412, 0
  %t424 = add i64 %t420, %t423
  %t425 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d53, i32 0, i32 1) }, 1
  %t426 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d53, i32 0, i32 1) }, 0
  %t427 = add i64 %t424, %t426
  %t428 = call ptr @__olang_scope_alloc(ptr %s17, i64 %t427)
  call void @olang_textcopy(ptr %t428, ptr %t413, i64 %t414)
  %t429 = getelementptr i8, ptr %t428, i64 %t414
  %t430 = call i64 @__olang_fmt_i64(ptr %t429, i64 %t411)
  %t431 = getelementptr i8, ptr %t429, i64 %t416
  call void @olang_textcopy(ptr %t431, ptr %t418, i64 %t419)
  %t432 = getelementptr i8, ptr %t431, i64 %t419
  call void @olang_textcopy(ptr %t432, ptr %t422, i64 %t423)
  %t433 = getelementptr i8, ptr %t432, i64 %t423
  call void @olang_textcopy(ptr %t433, ptr %t425, i64 %t426)
  %t434 = insertvalue { i64, ptr } undef, i64 %t427, 0
  %t435 = insertvalue { i64, ptr } %t434, ptr %t428, 1
  %t437 = extractvalue { i64, ptr } %t435, 0
  %t438 = extractvalue { i64, ptr } %t435, 1
  %t439 = mul i64 %t437, 1
  %t440 = call ptr @__olang_scope_alloc(ptr %s17, i64 %t439)
  call void @llvm.memcpy.p0.p0.i64(ptr %t440, ptr %t438, i64 %t439, i1 false)
  %t441 = insertvalue { i64, ptr } undef, i64 %t437, 0
  %t442 = insertvalue { i64, ptr } %t441, ptr %t440, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s17, ptr %l9, { i64, ptr } %t442)
  br label %bb76
bb75:
  br label %bb77
bb76:
  call void @__olang_scope_close(ptr %s17)
  br label %bb77
bb77:
  call void @__olang_scope_close(ptr %s16)
  br label %bb78
bb78:
  %t445 = load i64, ptr %l29, !tbaa !24
  %t447 = add i64 %t445, 1
  store i64 %t447, ptr %l29, !tbaa !24
  br label %bb70
bb79:
  call void @__olang_scope_close(ptr %s15)
  %t449 = load { i64, ptr }, ptr %l27, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s8, ptr %l10, { i64, ptr } %t449)
  br label %bb80
bb80:
  call void @__olang_scope_close(ptr %s8)
  br label %bb81
bb81:
  %t452 = load i64, ptr %l16, !tbaa !24
  %t454 = add i64 %t452, 1
  store i64 %t454, ptr %l16, !tbaa !24
  br label %bb36
bb82:
  store %olang.scope zeroinitializer, ptr %s21
  %t457 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2flower_2ecompiler_2flower_3aLowerer_2eInitModules(ptr %s0, ptr %s21, ptr %l8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t457, ptr %l215
  br label %bb83
bb83:
  %t458 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l215
  %t459 = call ptr @__olang_scope_alloc_a(ptr %s21, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t458, ptr %t459
  store ptr %t459, ptr %l32, !tbaa !29
  store i64 0, ptr %l33, !tbaa !24
  br label %bb84
bb84:
  store %olang.scope zeroinitializer, ptr %s22
  %t461 = load ptr, ptr %l32, !tbaa !29
  %t462 = load i64, ptr %l33, !tbaa !24
  %t465 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %s21, ptr %t461, i64 %t462)
  %t466 = extractvalue { i32, { i64, ptr } } %t465, 1
  %t467 = extractvalue { i32, { i64, ptr } } %t465, 0
  store i32 %t467, ptr %l221
  %t468 = icmp ne i32 %t467, 0
  br i1 %t468, label %bb86, label %ok.469
ok.469:
  store { i64, ptr } %t466, ptr %l220
  br label %bb85
bb85:
  %t470 = load { i64, ptr }, ptr %l220, !tbaa !27
  store { i64, ptr } %t470, ptr %l217, !tbaa !27
  br label %bb90
bb86:
  %t471 = load i32, ptr %l221, !tbaa !23
  %t472 = ashr i32 %t471, 16
  %t474 = icmp eq i32 %t472, 1
  br i1 %t474, label %bb87, label %bb88
bb87:
  br label %bb89
bb88:
  call void @__olang_check_failed(ptr @olang_loc_e1e79b1ec4507fab_255afe6ac3958787)
  unreachable
bb89:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s22)
  br label %bb99
bb90:
  %t476 = load { i64, ptr }, ptr %l217, !tbaa !27
  store { i64, ptr } %t476, ptr %l34, !tbaa !27
  %t477 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t479 = extractvalue { i64, ptr } %t477, 0
  store i64 %t479, ptr %l35, !tbaa !24
  store i64 0, ptr %l36, !tbaa !24
  br label %bb91
bb91:
  store %olang.scope zeroinitializer, ptr %s23
  %t481 = load i64, ptr %l36, !tbaa !24
  %t482 = load i64, ptr %l35, !tbaa !24
  %t485 = icmp slt i64 %t481, %t482
  %t487 = xor i1 %t485, true
  br i1 %t487, label %bb92, label %bb93
bb92:
  call void @__olang_scope_close(ptr %s23)
  br label %bb97
bb93:
  br label %bb94
bb94:
  %t489 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t489, ptr %l230, !tbaa !27
  %t490 = load i64, ptr %l36, !tbaa !24
  %t492 = getelementptr { i64, ptr }, ptr %l230, i32 0, i32 1
  %t493 = load ptr, ptr %t492, !tbaa !27
  %t494 = getelementptr i64, ptr %t493, i64 %t490
  %t495 = load i64, ptr %t494, !tbaa !34
  store { i64, [2 x i64] } zeroinitializer, ptr %t498
  %t499 = getelementptr { i64, [2 x i64] }, ptr %t498, i32 0, i32 0
  store i64 3, ptr %t499
  %t501 = insertvalue { i64 } undef, i64 %t495, 0
  %t502 = getelementptr { i64, [2 x i64] }, ptr %t498, i32 0, i32 1
  store { i64 } %t501, ptr %t502
  %t503 = load { i64, [2 x i64] }, ptr %t498
  call void @compiler_2flower_2ecompiler_2flower_3aLowerer_2eWant(ptr %s0, ptr %l8, { i64, [2 x i64] } %t503)
  br label %bb95
bb95:
  call void @__olang_scope_close(ptr %s23)
  br label %bb96
bb96:
  %t506 = load i64, ptr %l36, !tbaa !24
  %t508 = add i64 %t506, 1
  store i64 %t508, ptr %l36, !tbaa !24
  br label %bb91
bb97:
  %t510 = load i64, ptr %l33, !tbaa !24
  %t511 = load i64, ptr %l35, !tbaa !24
  %t514 = add i64 %t510, %t511
  store i64 %t514, ptr %l33, !tbaa !24
  call void @__olang_scope_close(ptr %s22)
  br label %bb98
bb98:
  br label %bb84
bb99:
  call void @__olang_scope_close(ptr %s21)
  store i64 0, ptr %l38, !tbaa !24
  br label %bb100
bb100:
  store %olang.scope zeroinitializer, ptr %s25
  %t516 = load i64, ptr %l38, !tbaa !24
  store i64 %t516, ptr %l241, !tbaa !24
  %t517 = getelementptr %"compiler/lower:Lowerer", ptr %l8, i32 0, i32 8
  %t519 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aFnKey_3e_2eLen_3ccompiler_2fmir_3aFnKey_3e(ptr %s0, ptr %t517)
  store i64 %t519, ptr %l243
  br label %bb101
bb101:
  %t520 = load i64, ptr %l241, !tbaa !24
  %t521 = load i64, ptr %l243, !tbaa !24
  %t522 = icmp slt i64 %t520, %t521
  %t524 = xor i1 %t522, true
  br i1 %t524, label %bb102, label %bb103
bb102:
  call void @__olang_scope_close(ptr %s25)
  br label %bb125
bb103:
  br label %bb104
bb104:
  %t526 = getelementptr %"compiler/lower:Lowerer", ptr %l8, i32 0, i32 8
  %t527 = load i64, ptr %l38, !tbaa !24
  %t530 = call { i64, [2 x i64] } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aFnKey_3e_2eAt_3ccompiler_2fmir_3aFnKey_3e(ptr %s0, ptr %t526, i64 %t527)
  store { i64, [2 x i64] } %t530, ptr %l248
  br label %bb105
bb105:
  %t531 = load { i64, [2 x i64] }, ptr %l248
  store { i64, [2 x i64] } %t531, ptr %l39
  %t532 = load i64, ptr %l38, !tbaa !24
  %t534 = add i64 %t532, 1
  store i64 %t534, ptr %l38, !tbaa !24
  %t536 = load { i64, [2 x i64] }, ptr %l39
  %t539 = call { i1, { i64, ptr }, { i64, ptr } } @compiler_2flower_2ecompiler_2flower_3aLowerer_2eVerifiedKey(ptr %s0, ptr %s25, ptr %l8, { i64, [2 x i64] } %t536, i1 false)
  store { i1, { i64, ptr }, { i64, ptr } } %t539, ptr %l253
  br label %bb106
bb106:
  %t540 = load { i1, { i64, ptr }, { i64, ptr } }, ptr %l253
  store { i1, { i64, ptr }, { i64, ptr } } %t540, ptr %l40
  %t541 = getelementptr { i1, { i64, ptr }, { i64, ptr } }, ptr %l40, i32 0, i32 0
  %t542 = load i1, ptr %t541, !tbaa !21
  %t544 = getelementptr { i1, { i64, ptr }, { i64, ptr } }, ptr %l40, i32 0, i32 1
  %t545 = load { i64, ptr }, ptr %t544, !tbaa !27
  store { i64, ptr } %t545, ptr %l255, !tbaa !27
  %t546 = load { i64, ptr }, ptr %l255, !tbaa !27
  %t547 = extractvalue { i64, ptr } %t546, 0
  store i64 %t547, ptr %l256, !tbaa !24
  %t548 = load i64, ptr %l256, !tbaa !24
  %t549 = mul i64 %t548, 1
  %t550 = call ptr @__olang_scope_alloc_zeroed(ptr %s25, i64 %t549)
  %t551 = insertvalue { i64, ptr } undef, i64 %t548, 0
  %t552 = insertvalue { i64, ptr } %t551, ptr %t550, 1
  store { i64, ptr } %t552, ptr %l257, !tbaa !27
  %t553 = getelementptr { i64, ptr }, ptr %l257, i32 0, i32 1
  %t554 = load ptr, ptr %t553, !tbaa !27
  %t555 = getelementptr { i64, ptr }, ptr %l255, i32 0, i32 1
  %t556 = load ptr, ptr %t555, !tbaa !27
  %t557 = load i64, ptr %l256, !tbaa !24
  %t558 = mul i64 %t557, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t554, ptr %t556, i64 %t558, i1 false)
  %t559 = load { i64, ptr }, ptr %l257, !tbaa !27
  store { i64, ptr } %t559, ptr %l42, !tbaa !27
  br i1 %t542, label %bb107, label %bb108
bb107:
  store %olang.scope zeroinitializer, ptr %s26
  store ptr %l9, ptr %l259, !tbaa !29
  %t562 = load { i64, [2 x i64] }, ptr %l39
  store { i64, [2 x i64] } %t562, ptr %l260
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s27
  store ptr %s27room, ptr %s27
  call void @olang_2eHelperKind_2eRender_2ecompiler_2fmir_3aFnKey(ptr %s27, ptr %l260, i64 0)
  br label %bb109
bb108:
  br label %bb111
bb109:
  %t564 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d54, i32 0, i32 1) }, 1
  %t565 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d54, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s27, ptr %t564, i64 %t565)
  %t566 = load ptr, ptr %s27
  %t567 = getelementptr %olang.builder, ptr %s27, i32 0, i32 1
  %t568 = load i64, ptr %t567
  %t569 = call ptr @__olang_scope_alloc(ptr %s26, i64 %t568)
  call void @olang_textcopy(ptr %t569, ptr %t566, i64 %t568)
  %t570 = insertvalue { i64, ptr } undef, i64 %t568, 0
  %t571 = insertvalue { i64, ptr } %t570, ptr %t569, 1
  store { i64, ptr } %t571, ptr %l262, !tbaa !27
  %t572 = getelementptr %olang.builder, ptr %s27, i32 0, i32 3
  %t573 = load ptr, ptr %t572
  %t574 = icmp ne ptr %t573, null
  br i1 %t574, label %sbgrew.575, label %sbdone.576
sbgrew.575:
  call void @__olang_sb_done(ptr %s27)
  br label %sbdone.576
sbdone.576:
  %t577 = load { i64, ptr }, ptr %l262, !tbaa !27
  %t578 = extractvalue { i64, ptr } %t577, 0
  %t579 = extractvalue { i64, ptr } %t577, 1
  %t580 = mul i64 %t578, 1
  %t581 = call ptr @__olang_scope_alloc(ptr %s26, i64 %t580)
  call void @llvm.memcpy.p0.p0.i64(ptr %t581, ptr %t579, i64 %t580, i1 false)
  %t582 = insertvalue { i64, ptr } undef, i64 %t578, 0
  %t583 = insertvalue { i64, ptr } %t582, ptr %t581, 1
  %t584 = load ptr, ptr %l259, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s26, ptr %t584, { i64, ptr } %t583)
  br label %bb110
bb110:
  call void @__olang_scope_close(ptr %s26)
  br label %bb111
bb111:
  store %olang.scope zeroinitializer, ptr %s28
  %t586 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t588 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eSplit(ptr %s25, ptr %s28, { i64, ptr } %t586, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d55, i32 0, i32 1) })
  store { i64, ptr } %t588, ptr %l265
  br label %bb112
bb112:
  %t589 = load { i64, ptr }, ptr %l265, !tbaa !27
  store { i64, ptr } %t589, ptr %l43, !tbaa !27
  store i64 0, ptr %l44, !tbaa !24
  %t590 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t592 = extractvalue { i64, ptr } %t590, 0
  store i64 %t592, ptr %l45, !tbaa !24
  br label %bb113
bb113:
  store %olang.scope zeroinitializer, ptr %s29
  %t594 = load i64, ptr %l44, !tbaa !24
  %t595 = load i64, ptr %l45, !tbaa !24
  %t598 = icmp slt i64 %t594, %t595
  %t600 = xor i1 %t598, true
  br i1 %t600, label %bb114, label %bb115
bb114:
  call void @__olang_scope_close(ptr %s29)
  br label %bb123
bb115:
  br label %bb116
bb116:
  %t602 = load { i64, ptr }, ptr %l43, !tbaa !27
  store { i64, ptr } %t602, ptr %l272, !tbaa !27
  %t603 = load i64, ptr %l44, !tbaa !24
  %t605 = getelementptr { i64, ptr }, ptr %l272, i32 0, i32 1
  %t606 = load ptr, ptr %t605, !tbaa !27
  %t607 = getelementptr { i64, ptr }, ptr %t606, i64 %t603
  %t608 = load { i64, ptr }, ptr %t607, !tbaa !37
  store { i64, ptr } %t608, ptr %l46, !tbaa !27
  %t610 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t612 = extractvalue { i64, ptr } %t610, 0
  %t614 = icmp sgt i64 %t612, 0
  br i1 %t614, label %bb117, label %bb118
bb117:
  store %olang.scope zeroinitializer, ptr %s30
  store ptr %l9, ptr %l278, !tbaa !29
  %t616 = load { i64, [2 x i64] }, ptr %l39
  store { i64, [2 x i64] } %t616, ptr %l279
  %t617 = load { i64, ptr }, ptr %l46, !tbaa !27
  store { i64, ptr } %t617, ptr %l280, !tbaa !27
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s31
  store ptr %s31room, ptr %s31
  call void @olang_2eHelperKind_2eRender_2ecompiler_2fmir_3aFnKey(ptr %s31, ptr %l279, i64 0)
  br label %bb119
bb118:
  br label %bb121
bb119:
  %t619 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d56, i32 0, i32 1) }, 1
  %t620 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d56, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s31, ptr %t619, i64 %t620)
  %t621 = load { i64, ptr }, ptr %l280, !tbaa !27
  %t622 = extractvalue { i64, ptr } %t621, 1
  %t623 = extractvalue { i64, ptr } %t621, 0
  call void @__olang_sb_put(ptr %s31, ptr %t622, i64 %t623)
  %t624 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d57, i32 0, i32 1) }, 1
  %t625 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d57, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s31, ptr %t624, i64 %t625)
  %t626 = load ptr, ptr %s31
  %t627 = getelementptr %olang.builder, ptr %s31, i32 0, i32 1
  %t628 = load i64, ptr %t627
  %t629 = call ptr @__olang_scope_alloc(ptr %s30, i64 %t628)
  call void @olang_textcopy(ptr %t629, ptr %t626, i64 %t628)
  %t630 = insertvalue { i64, ptr } undef, i64 %t628, 0
  %t631 = insertvalue { i64, ptr } %t630, ptr %t629, 1
  store { i64, ptr } %t631, ptr %l282, !tbaa !27
  %t632 = getelementptr %olang.builder, ptr %s31, i32 0, i32 3
  %t633 = load ptr, ptr %t632
  %t634 = icmp ne ptr %t633, null
  br i1 %t634, label %sbgrew.635, label %sbdone.636
sbgrew.635:
  call void @__olang_sb_done(ptr %s31)
  br label %sbdone.636
sbdone.636:
  %t637 = load { i64, ptr }, ptr %l282, !tbaa !27
  %t638 = extractvalue { i64, ptr } %t637, 0
  %t639 = extractvalue { i64, ptr } %t637, 1
  %t640 = mul i64 %t638, 1
  %t641 = call ptr @__olang_scope_alloc(ptr %s30, i64 %t640)
  call void @llvm.memcpy.p0.p0.i64(ptr %t641, ptr %t639, i64 %t640, i1 false)
  %t642 = insertvalue { i64, ptr } undef, i64 %t638, 0
  %t643 = insertvalue { i64, ptr } %t642, ptr %t641, 1
  %t644 = load ptr, ptr %l278, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s30, ptr %t644, { i64, ptr } %t643)
  br label %bb120
bb120:
  call void @__olang_scope_close(ptr %s30)
  br label %bb121
bb121:
  call void @__olang_scope_close(ptr %s29)
  br label %bb122
bb122:
  %t646 = load i64, ptr %l44, !tbaa !24
  %t648 = add i64 %t646, 1
  store i64 %t648, ptr %l44, !tbaa !24
  br label %bb113
bb123:
  call void @__olang_scope_close(ptr %s28)
  call void @__olang_scope_close(ptr %s25)
  br label %bb124
bb124:
  br label %bb100
bb125:
  %t650 = getelementptr %"compiler/lower:Lowerer", ptr %l8, i32 0, i32 4
  store ptr %t650, ptr %l47, !tbaa !29
  store i64 0, ptr %l48, !tbaa !24
  br label %bb126
bb126:
  store %olang.scope zeroinitializer, ptr %s34
  %t652 = load ptr, ptr %l47, !tbaa !29
  %t653 = load i64, ptr %l48, !tbaa !24
  %t656 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3aGap_3e_2eRunFrom_3ccompiler_2flower_3aGap_3e(ptr %s0, ptr %t652, i64 %t653)
  %t657 = extractvalue { i32, { i64, ptr } } %t656, 1
  %t658 = extractvalue { i32, { i64, ptr } } %t656, 0
  store i32 %t658, ptr %l291
  %t659 = icmp ne i32 %t658, 0
  br i1 %t659, label %bb128, label %ok.660
ok.660:
  store { i64, ptr } %t657, ptr %l290
  br label %bb127
bb127:
  %t661 = load { i64, ptr }, ptr %l290, !tbaa !27
  store { i64, ptr } %t661, ptr %l287, !tbaa !27
  br label %bb132
bb128:
  %t662 = load i32, ptr %l291, !tbaa !23
  %t663 = ashr i32 %t662, 16
  %t665 = icmp eq i32 %t663, 1
  br i1 %t665, label %bb129, label %bb130
bb129:
  br label %bb131
bb130:
  call void @__olang_check_failed(ptr @olang_loc_4f17ddcf0f41430c_286819f90184f2f0)
  unreachable
bb131:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s34)
  br label %bb141
bb132:
  %t667 = load { i64, ptr }, ptr %l287, !tbaa !27
  store { i64, ptr } %t667, ptr %l49, !tbaa !27
  %t668 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t670 = extractvalue { i64, ptr } %t668, 0
  store i64 %t670, ptr %l50, !tbaa !24
  store i64 0, ptr %l51, !tbaa !24
  br label %bb133
bb133:
  store %olang.scope zeroinitializer, ptr %s35
  %t672 = load i64, ptr %l51, !tbaa !24
  %t673 = load i64, ptr %l50, !tbaa !24
  %t676 = icmp slt i64 %t672, %t673
  %t678 = xor i1 %t676, true
  br i1 %t678, label %bb134, label %bb135
bb134:
  call void @__olang_scope_close(ptr %s35)
  br label %bb139
bb135:
  br label %bb136
bb136:
  %t680 = load { i64, ptr }, ptr %l49, !tbaa !27
  store { i64, ptr } %t680, ptr %l300, !tbaa !27
  %t681 = load i64, ptr %l51, !tbaa !24
  %t683 = getelementptr { i64, ptr }, ptr %l300, i32 0, i32 1
  %t684 = load ptr, ptr %t683, !tbaa !27
  %t685 = getelementptr %"compiler/lower:Gap", ptr %t684, i64 %t681
  %t686 = load %"compiler/lower:Gap", ptr %t685
  store %"compiler/lower:Gap" %t686, ptr %l52
  %t688 = getelementptr %"compiler/lower:Gap", ptr %l52, i32 0, i32 2
  %t689 = load { i64, ptr }, ptr %t688, !tbaa !27
  %t690 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d58, i32 0, i32 1) }, 1
  %t691 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d58, i32 0, i32 1) }, 0
  %t693 = extractvalue { i64, ptr } %t689, 1
  %t694 = extractvalue { i64, ptr } %t689, 0
  %t695 = add i64 %t691, %t694
  %t696 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d59, i32 0, i32 1) }, 1
  %t697 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d59, i32 0, i32 1) }, 0
  %t698 = add i64 %t695, %t697
  %t699 = call ptr @__olang_scope_alloc(ptr %s35, i64 %t698)
  call void @olang_textcopy(ptr %t699, ptr %t690, i64 %t691)
  %t700 = getelementptr i8, ptr %t699, i64 %t691
  call void @olang_textcopy(ptr %t700, ptr %t693, i64 %t694)
  %t701 = getelementptr i8, ptr %t700, i64 %t694
  call void @olang_textcopy(ptr %t701, ptr %t696, i64 %t697)
  %t702 = insertvalue { i64, ptr } undef, i64 %t698, 0
  %t703 = insertvalue { i64, ptr } %t702, ptr %t699, 1
  %t705 = extractvalue { i64, ptr } %t703, 0
  %t706 = extractvalue { i64, ptr } %t703, 1
  %t707 = mul i64 %t705, 1
  %t708 = call ptr @__olang_scope_alloc(ptr %s35, i64 %t707)
  call void @llvm.memcpy.p0.p0.i64(ptr %t708, ptr %t706, i64 %t707, i1 false)
  %t709 = insertvalue { i64, ptr } undef, i64 %t705, 0
  %t710 = insertvalue { i64, ptr } %t709, ptr %t708, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s35, ptr %l9, { i64, ptr } %t710)
  br label %bb137
bb137:
  call void @__olang_scope_close(ptr %s35)
  br label %bb138
bb138:
  %t713 = load i64, ptr %l51, !tbaa !24
  %t715 = add i64 %t713, 1
  store i64 %t715, ptr %l51, !tbaa !24
  br label %bb133
bb139:
  %t717 = load i64, ptr %l48, !tbaa !24
  %t718 = load i64, ptr %l50, !tbaa !24
  %t721 = add i64 %t717, %t718
  store i64 %t721, ptr %l48, !tbaa !24
  call void @__olang_scope_close(ptr %s34)
  br label %bb140
bb140:
  br label %bb126
bb141:
  %t724 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v2, ptr %l9)
  store { i64, ptr } %t724, ptr %l313
  br label %bb142
bb142:
  %t725 = load { i64, ptr }, ptr %l313, !tbaa !27
  store { i64, ptr } %t725, ptr %l314, !tbaa !27
  %t727 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v2, ptr %l10)
  store { i64, ptr } %t727, ptr %l316
  br label %bb143
bb143:
  %t728 = load { i64, ptr }, ptr %l316, !tbaa !27
  %t729 = load { i64, ptr }, ptr %l314, !tbaa !27
  %t730 = insertvalue { { i64, ptr }, { i64, ptr } } undef, { i64, ptr } %t729, 0
  %t732 = insertvalue { { i64, ptr }, { i64, ptr } } %t730, { i64, ptr } %t728, 1
  store { { i64, ptr }, { i64, ptr } } %t732, ptr %l318
  %t733 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l318, i32 0, i32 0
  %t734 = load { i64, ptr }, ptr %t733, !tbaa !27
  store { i64, ptr } %t734, ptr %l319, !tbaa !27
  %t735 = load { i64, ptr }, ptr %l319, !tbaa !27
  %t736 = extractvalue { i64, ptr } %t735, 0
  store i64 %t736, ptr %l320, !tbaa !24
  %t737 = load i64, ptr %l320, !tbaa !24
  %t738 = mul i64 %t737, 1
  %t739 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t738)
  %t740 = insertvalue { i64, ptr } undef, i64 %t737, 0
  %t741 = insertvalue { i64, ptr } %t740, ptr %t739, 1
  store { i64, ptr } %t741, ptr %l321, !tbaa !27
  %t742 = getelementptr { i64, ptr }, ptr %l321, i32 0, i32 1
  %t743 = load ptr, ptr %t742, !tbaa !27
  %t744 = getelementptr { i64, ptr }, ptr %l319, i32 0, i32 1
  %t745 = load ptr, ptr %t744, !tbaa !27
  %t746 = load i64, ptr %l320, !tbaa !24
  %t747 = mul i64 %t746, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t743, ptr %t745, i64 %t747, i1 false)
  %t748 = load { i64, ptr }, ptr %l321, !tbaa !27
  %t749 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l318, i32 0, i32 0
  store { i64, ptr } %t748, ptr %t749, !tbaa !27
  %t750 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l318, i32 0, i32 1
  %t751 = load { i64, ptr }, ptr %t750, !tbaa !27
  store { i64, ptr } %t751, ptr %l322, !tbaa !27
  %t752 = load { i64, ptr }, ptr %l322, !tbaa !27
  %t753 = extractvalue { i64, ptr } %t752, 0
  store i64 %t753, ptr %l323, !tbaa !24
  %t754 = load i64, ptr %l323, !tbaa !24
  %t755 = mul i64 %t754, 1
  %t756 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t755)
  %t757 = insertvalue { i64, ptr } undef, i64 %t754, 0
  %t758 = insertvalue { i64, ptr } %t757, ptr %t756, 1
  store { i64, ptr } %t758, ptr %l324, !tbaa !27
  %t759 = getelementptr { i64, ptr }, ptr %l324, i32 0, i32 1
  %t760 = load ptr, ptr %t759, !tbaa !27
  %t761 = getelementptr { i64, ptr }, ptr %l322, i32 0, i32 1
  %t762 = load ptr, ptr %t761, !tbaa !27
  %t763 = load i64, ptr %l323, !tbaa !24
  %t764 = mul i64 %t763, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t760, ptr %t762, i64 %t764, i1 false)
  %t765 = load { i64, ptr }, ptr %l324, !tbaa !27
  %t766 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l318, i32 0, i32 1
  store { i64, ptr } %t765, ptr %t766, !tbaa !27
  %t767 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t769 = call i32 @std_2fos_2eRemoveAll(ptr %s0, { i64, ptr } %t767)
  store i32 %t769, ptr %l326
  %t770 = icmp ne i32 %t769, 0
  br i1 %t770, label %bb145, label %ok.771
ok.771:
  br label %bb144
bb144:
  br label %bb149
bb145:
  %t772 = load i32, ptr %l326, !tbaa !23
  %t773 = ashr i32 %t772, 16
  %t775 = icmp eq i32 %t773, 1
  br i1 %t775, label %bb146, label %bb147
bb146:
  br label %bb148
bb147:
  call void @__olang_check_failed(ptr @olang_loc_4cb19ea0263fa3d_267ad794ac309681)
  unreachable
bb148:
  call void @__olang_ert_req_clear()
  br label %bb149
bb149:
  call void @__olang_scope_close(ptr %s0)
  %t777 = load { { i64, ptr }, { i64, ptr } }, ptr %l318
  store { { i64, ptr }, { i64, ptr } } %t777, ptr %rv
  br label %ret
ret:
  %rr = load { { i64, ptr }, { i64, ptr } }, ptr %rv
  ret { { i64, ptr }, { i64, ptr } } %rr
}

define dso_local { i64, ptr } @compiler_2flower_2etupleItems(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i1
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  store i1 false, ptr %l3, !tbaa !21
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 7
  store i1 %t8, ptr %l3, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l3, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb9
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr %"compiler/typed:Make", ptr %t16, i32 0, i32 0
  %t19 = load i32, ptr %t18
  %t21 = trunc i64 0 to i32
  %t22 = icmp eq i32 %t19, %t21
  br i1 %t22, label %bb6, label %bb7
bb6:
  %t24 = load ptr, ptr %l1, !tbaa !29
  %t26 = getelementptr %"compiler/typed:Make", ptr %t24, i32 0, i32 2
  %t27 = load { i64, ptr }, ptr %t26, !tbaa !27
  store { i64, ptr } %t27, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  br label %bb14
bb9:
  br i1 true, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_9199c0a93cf9da48_dd64f3db35db750c)
  unreachable
bb14:
  %t29 = icmp sge i64 0, 0
  br i1 %t29, label %bb15, label %bb16
bb15:
  %t31 = icmp sle i64 0, 1152921504606846975
  br i1 %t31, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_9332d5fa6ed1089a_91d46adad91ba686)
  unreachable
bb17:
  %t33 = mul i64 0, 8
  %t34 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t33)
  %t35 = insertvalue { i64, ptr } undef, i64 0, 0
  %t36 = insertvalue { i64, ptr } %t35, ptr %t34, 1
  store { i64, ptr } %t36, ptr %rv
  br label %ret
bb18:
  call void @__olang_check_failed(ptr @olang_loc_9332d5fa6ed1089a_91d46adad91ba686)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"compiler/lower:collectCtx" @compiler_2flower_3acollectCtx_2ector(ptr %v0, i32 %a0, i32 %a1, i32 %a2, i32 %a3, { i64, [1 x i64] } %a4, i1 %a5, i1 %a6) #0 {
entry:
  %rv = alloca %"compiler/lower:collectCtx"
  br label %start
start:
  br label %bb0
bb0:
  %t16 = insertvalue %"compiler/lower:collectCtx" undef, i32 %a0, 0
  %t18 = insertvalue %"compiler/lower:collectCtx" %t16, i32 %a1, 1
  %t20 = insertvalue %"compiler/lower:collectCtx" %t18, i32 %a2, 2
  %t22 = insertvalue %"compiler/lower:collectCtx" %t20, i32 %a3, 3
  %t24 = insertvalue %"compiler/lower:collectCtx" %t22, { i64, [1 x i64] } %a4, 4
  %t26 = insertvalue %"compiler/lower:collectCtx" %t24, i1 %a5, 5
  %t28 = insertvalue %"compiler/lower:collectCtx" %t26, i1 %a6, 6
  store %"compiler/lower:collectCtx" %t28, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/lower:collectCtx", ptr %rv
  ret %"compiler/lower:collectCtx" %rr
}

declare void @__olang_check_failed(ptr)
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

declare noalias ptr @__olang_scope_alloc_a(ptr, i64, i64)
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  call void @__olang_dtor_head(ptr %fd, ptr %pdp)
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %dhasnext = icmp ne ptr %dnext, null
  br i1 %dhasnext, label %dfixpp, label %drun
dfixpp:
  %dnpp = getelementptr %olang.dtornode, ptr %dnext, i32 0, i32 3
  store ptr %dheadptr, ptr %dnpp
  br label %drun
drun:
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  call void @__olang_dtor_head(ptr %wfd, ptr %dheadptr)
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@.d0 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d1 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
@.d2 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@.d3 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"std/prelude/text" }>, align 8
@.d4 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Char" }>, align 8
@__olang_prog_scope = external thread_local(initialexec) global ptr
@.d5 = private constant <{ i64, [41 x i8] }> <{ i64 0, [41 x i8] c"a constructor of a type that is no struct" }>, align 8
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aBlockId_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fmir_3aBlockId_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define available_externally void @__olang_scope_escape(ptr %s) alwaysinline {
entry:
  %op = getelementptr %olang.scope, ptr %s, i32 0, i32 3
  %o = load atomic ptr, ptr %op monotonic, align 8
  %un = icmp eq ptr %o, null
  br i1 %un, label %claim, label %done
claim:
  %me = load ptr, ptr @__olang_self
  store atomic ptr %me, ptr %op monotonic, align 8
  br label %done
done:
  ret void
}
define internal void @olang_lambda_6(ptr %env, i64 %a0, i32 %a1) #0 {
entry:
  %l0 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l11 = alloca %"compiler/lower:pl"
  %l15 = alloca { i64, [4 x i64] }
  %l16 = alloca i32
  %l18 = alloca ptr
  %l22 = alloca i32
  %l23 = alloca { i64, ptr }
  %l29 = alloca i64
  %l32 = alloca i64
  %l50 = alloca ptr
  %l55 = alloca %"compiler/lower:pl"
  %l58 = alloca %"compiler/lower:pl"
  %l59 = alloca ptr
  %l64 = alloca %"compiler/lower:pl"
  %l67 = alloca %"compiler/lower:pl"
  %l74 = alloca { i64, [4 x i64] }
  %l77 = alloca i32
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %t68 = alloca { i64, [1 x i64] }, align 8
  %t79 = alloca { i64, [1 x i64] }, align 8
  %t94 = alloca { i64, [1 x i64] }, align 8
  %t105 = alloca { i64, [1 x i64] }, align 8
  %t143 = alloca { i64, [8 x i64] }, align 8
  store i64 %a0, ptr %l0
  %cp0 = getelementptr { ptr, %"compiler/lower:pl", %"compiler/lower:pl", %"compiler/source:Span", i32, ptr, ptr, ptr }, ptr %env, i32 0, i32 0
  %cv0 = load ptr, ptr %cp0, !tbaa !28
  store ptr %cv0, ptr %l2
  %cp1 = getelementptr { ptr, %"compiler/lower:pl", %"compiler/lower:pl", %"compiler/source:Span", i32, ptr, ptr, ptr }, ptr %env, i32 0, i32 1
  %cv1 = load %"compiler/lower:pl", ptr %cp1, !tbaa !28
  %cp2 = getelementptr { ptr, %"compiler/lower:pl", %"compiler/lower:pl", %"compiler/source:Span", i32, ptr, ptr, ptr }, ptr %env, i32 0, i32 2
  %cv2 = load %"compiler/lower:pl", ptr %cp2, !tbaa !28
  %cp3 = getelementptr { ptr, %"compiler/lower:pl", %"compiler/lower:pl", %"compiler/source:Span", i32, ptr, ptr, ptr }, ptr %env, i32 0, i32 3
  %cv3 = load %"compiler/source:Span", ptr %cp3, !tbaa !28
  %cp4 = getelementptr { ptr, %"compiler/lower:pl", %"compiler/lower:pl", %"compiler/source:Span", i32, ptr, ptr, ptr }, ptr %env, i32 0, i32 4
  %cv4 = load i32, ptr %cp4, !tbaa !28
  %vq0 = getelementptr { ptr, %"compiler/lower:pl", %"compiler/lower:pl", %"compiler/source:Span", i32, ptr, ptr, ptr }, ptr %env, i32 0, i32 5
  %vr0 = load ptr, ptr %vq0, !tbaa !28
  %vc0 = call ptr @__olang_capture_scope(ptr %vr0)
  %vq1 = getelementptr { ptr, %"compiler/lower:pl", %"compiler/lower:pl", %"compiler/source:Span", i32, ptr, ptr, ptr }, ptr %env, i32 0, i32 6
  %vr1 = load ptr, ptr %vq1, !tbaa !28
  %vc1 = call ptr @__olang_capture_scope(ptr %vr1)
  %vq2 = getelementptr { ptr, %"compiler/lower:pl", %"compiler/lower:pl", %"compiler/source:Span", i32, ptr, ptr, ptr }, ptr %env, i32 0, i32 7
  %vr2 = load ptr, ptr %vq2, !tbaa !28
  %vc2 = call ptr @__olang_capture_scope(ptr %vr2)
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l2, !tbaa !29
  store ptr %t1, ptr %l18, !tbaa !29
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t4 = getelementptr %"compiler/lower:lowering", ptr %t2, i32 0, i32 2
  %t5 = load ptr, ptr %t4, !tbaa !29
  %t9 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %vc0, ptr %t5, i32 %a1)
  store i32 %t9, ptr %l22
  br label %bb1
bb1:
  %t10 = load ptr, ptr %l18, !tbaa !29
  %t11 = load i32, ptr %l22, !tbaa !23
  %t12 = call { i64, ptr } @compiler_2flower_2ecompiler_2flower_3alowering_2eitems(ptr %vc0, ptr %s0, ptr %t10, i32 %t11)
  store { i64, ptr } %t12, ptr %l23
  br label %bb2
bb2:
  %t13 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t13, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t14 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t16 = extractvalue { i64, ptr } %t14, 0
  store i64 %t16, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t18 = load i64, ptr %l5, !tbaa !24
  %t19 = load i64, ptr %l4, !tbaa !24
  %t22 = icmp sgt i64 %t18, %t19
  br i1 %t22, label %bb3, label %bb4
bb3:
  %t24 = load i64, ptr %l6, !tbaa !24
  %t26 = icmp sgt i64 %t24, 0
  br i1 %t26, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l29, !tbaa !24
  br label %bb8
bb5:
  %t28 = load i64, ptr %l5, !tbaa !24
  %t29 = load i64, ptr %l4, !tbaa !24
  %t32 = sub i64 %t28, %t29
  %t33 = load i64, ptr %l6, !tbaa !24
  %t36 = add i64 %t32, %t33
  %t38 = sub i64 %t36, 1
  %t39 = load i64, ptr %l6, !tbaa !24
  %t42 = sdiv i64 %t38, %t39
  store i64 %t42, ptr %l32, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l32, !tbaa !24
  br label %bb7
bb7:
  %t44 = load i64, ptr %l32, !tbaa !24
  store i64 %t44, ptr %l29, !tbaa !24
  br label %bb8
bb8:
  %t45 = load i64, ptr %l29, !tbaa !24
  store i64 %t45, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t46 = load i64, ptr %l8, !tbaa !24
  %t47 = load i64, ptr %l7, !tbaa !24
  %t50 = icmp slt i64 %t46, %t47
  %t52 = xor i1 %t50, true
  br i1 %t52, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb22
bb11:
  br label %bb12
bb12:
  %t54 = load i64, ptr %l4, !tbaa !24
  %t55 = load i64, ptr %l8, !tbaa !24
  %t56 = load i64, ptr %l6, !tbaa !24
  %t59 = mul i64 %t55, %t56
  %t62 = add i64 %t54, %t59
  store i64 %t62, ptr %l9, !tbaa !24
  %t64 = load ptr, ptr %l2, !tbaa !29
  store ptr %t64, ptr %l50, !tbaa !29
  %t65 = load ptr, ptr %l2, !tbaa !29
  %t67 = load i64, ptr %l0, !tbaa !24
  store { i64, [1 x i64] } zeroinitializer, ptr %t68
  %t69 = getelementptr { i64, [1 x i64] }, ptr %t68, i32 0, i32 0
  store i64 4, ptr %t69
  %t71 = insertvalue { i64 } undef, i64 %t67, 0
  %t72 = getelementptr { i64, [1 x i64] }, ptr %t68, i32 0, i32 1
  store { i64 } %t71, ptr %t72
  %t73 = load { i64, [1 x i64] }, ptr %t68
  %t77 = call %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2ewith(ptr %vc0, ptr %vc1, ptr %s2, ptr %t65, %"compiler/lower:pl" %cv1, { i64, [1 x i64] } %t73)
  store %"compiler/lower:pl" %t77, ptr %l55
  br label %bb13
bb13:
  %t78 = load i64, ptr %l9, !tbaa !24
  store { i64, [1 x i64] } zeroinitializer, ptr %t79
  %t80 = getelementptr { i64, [1 x i64] }, ptr %t79, i32 0, i32 0
  store i64 0, ptr %t80
  %t82 = insertvalue { i64 } undef, i64 %t78, 0
  %t83 = getelementptr { i64, [1 x i64] }, ptr %t79, i32 0, i32 1
  store { i64 } %t82, ptr %t83
  %t84 = load { i64, [1 x i64] }, ptr %t79
  %t85 = load ptr, ptr %l50, !tbaa !29
  %t86 = load %"compiler/lower:pl", ptr %l55
  %t88 = call %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2ewith(ptr %vc0, ptr %s2, ptr %s2, ptr %t85, %"compiler/lower:pl" %t86, { i64, [1 x i64] } %t84)
  store %"compiler/lower:pl" %t88, ptr %l58
  br label %bb14
bb14:
  %t89 = load %"compiler/lower:pl", ptr %l58
  store %"compiler/lower:pl" %t89, ptr %l11
  %t90 = load ptr, ptr %l2, !tbaa !29
  store ptr %t90, ptr %l59, !tbaa !29
  %t91 = load ptr, ptr %l2, !tbaa !29
  %t93 = load i64, ptr %l0, !tbaa !24
  store { i64, [1 x i64] } zeroinitializer, ptr %t94
  %t95 = getelementptr { i64, [1 x i64] }, ptr %t94, i32 0, i32 0
  store i64 4, ptr %t95
  %t97 = insertvalue { i64 } undef, i64 %t93, 0
  %t98 = getelementptr { i64, [1 x i64] }, ptr %t94, i32 0, i32 1
  store { i64 } %t97, ptr %t98
  %t99 = load { i64, [1 x i64] }, ptr %t94
  %t103 = call %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2ewith(ptr %vc0, ptr %vc2, ptr %s2, ptr %t91, %"compiler/lower:pl" %cv2, { i64, [1 x i64] } %t99)
  store %"compiler/lower:pl" %t103, ptr %l64
  br label %bb15
bb15:
  %t104 = load i64, ptr %l9, !tbaa !24
  store { i64, [1 x i64] } zeroinitializer, ptr %t105
  %t106 = getelementptr { i64, [1 x i64] }, ptr %t105, i32 0, i32 0
  store i64 0, ptr %t106
  %t108 = insertvalue { i64 } undef, i64 %t104, 0
  %t109 = getelementptr { i64, [1 x i64] }, ptr %t105, i32 0, i32 1
  store { i64 } %t108, ptr %t109
  %t110 = load { i64, [1 x i64] }, ptr %t105
  %t111 = load ptr, ptr %l59, !tbaa !29
  %t112 = load %"compiler/lower:pl", ptr %l64
  %t114 = call %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2ewith(ptr %vc0, ptr %s2, ptr %s2, ptr %t111, %"compiler/lower:pl" %t112, { i64, [1 x i64] } %t110)
  store %"compiler/lower:pl" %t114, ptr %l67
  br label %bb16
bb16:
  %t115 = load %"compiler/lower:pl", ptr %l67
  %t116 = load ptr, ptr %l2, !tbaa !29
  %t117 = load %"compiler/lower:pl", ptr %l11
  %t119 = load i64, ptr %l9, !tbaa !24
  %t121 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t122 = load ptr, ptr %t121, !tbaa !27
  %t123 = getelementptr i32, ptr %t122, i64 %t119
  %t124 = load i32, ptr %t123, !tbaa !33
  %t131 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eequalAt(ptr %vc0, ptr %s2, ptr %s2, ptr %t116, %"compiler/lower:pl" %t117, %"compiler/lower:pl" %t115, i32 %t124, %"compiler/source:Span" %cv3, i1 false)
  store { i64, [4 x i64] } %t131, ptr %l74
  br label %bb17
bb17:
  %t132 = load { i64, [4 x i64] }, ptr %l74
  store { i64, [4 x i64] } %t132, ptr %l15
  %t133 = load ptr, ptr %l2, !tbaa !29
  %t135 = getelementptr %"compiler/lower:lowering", ptr %t133, i32 0, i32 3
  %t137 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %vc0, ptr %t135)
  store i32 %t137, ptr %l77
  br label %bb18
bb18:
  %t138 = load i32, ptr %l77, !tbaa !23
  store i32 %t138, ptr %l16, !tbaa !23
  %t139 = load ptr, ptr %l2, !tbaa !29
  %t140 = load { i64, [4 x i64] }, ptr %l15
  %t141 = load i32, ptr %l16, !tbaa !23
  store { i64, [8 x i64] } zeroinitializer, ptr %t143
  %t144 = getelementptr { i64, [8 x i64] }, ptr %t143, i32 0, i32 0
  store i64 2, ptr %t144
  %t146 = insertvalue { { i64, [4 x i64] }, i32, i32 } undef, { i64, [4 x i64] } %t140, 0
  %t148 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t146, i32 %t141, 1
  %t150 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t148, i32 %cv4, 2
  %t151 = getelementptr { i64, [8 x i64] }, ptr %t143, i32 0, i32 1
  store { { i64, [4 x i64] }, i32, i32 } %t150, ptr %t151
  %t152 = load { i64, [8 x i64] }, ptr %t143
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %vc0, ptr %t139, { i64, [8 x i64] } %t152)
  br label %bb19
bb19:
  %t155 = load ptr, ptr %l2, !tbaa !29
  %t156 = load i32, ptr %l16, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %vc0, ptr %t155, i32 %t156)
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s2)
  br label %bb21
bb21:
  %t159 = load i64, ptr %l8, !tbaa !24
  %t161 = add i64 %t159, 1
  store i64 %t161, ptr %l8, !tbaa !24
  br label %bb9
bb22:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

@.d7 = private constant <{ i64, [40 x i8] }> <{ i64 0, [40 x i8] c"an Equal helper for a type with no parts" }>, align 8
define internal void @olang_lambda_8(ptr %env, i32 %a0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca ptr
  %l6 = alloca { i64, [4 x i64] }
  %l7 = alloca i32
  %l9 = alloca ptr
  %l14 = alloca %"compiler/lower:pl"
  %l19 = alloca %"compiler/lower:pl"
  %l22 = alloca { i64, [4 x i64] }
  %l25 = alloca i32
  %s0 = alloca %olang.scope
  %t5 = alloca { i64, [1 x i64] }, align 8
  %t18 = alloca { i64, [1 x i64] }, align 8
  %t47 = alloca { i64, [8 x i64] }, align 8
  store i32 %a0, ptr %l0
  %cp0 = getelementptr { ptr, %"compiler/lower:pl", %"compiler/lower:pl", i32, %"compiler/source:Span", i32, ptr, ptr, ptr }, ptr %env, i32 0, i32 0
  %cv0 = load ptr, ptr %cp0, !tbaa !28
  store ptr %cv0, ptr %l1
  %cp1 = getelementptr { ptr, %"compiler/lower:pl", %"compiler/lower:pl", i32, %"compiler/source:Span", i32, ptr, ptr, ptr }, ptr %env, i32 0, i32 1
  %cv1 = load %"compiler/lower:pl", ptr %cp1, !tbaa !28
  %cp2 = getelementptr { ptr, %"compiler/lower:pl", %"compiler/lower:pl", i32, %"compiler/source:Span", i32, ptr, ptr, ptr }, ptr %env, i32 0, i32 2
  %cv2 = load %"compiler/lower:pl", ptr %cp2, !tbaa !28
  %cp3 = getelementptr { ptr, %"compiler/lower:pl", %"compiler/lower:pl", i32, %"compiler/source:Span", i32, ptr, ptr, ptr }, ptr %env, i32 0, i32 3
  %cv3 = load i32, ptr %cp3, !tbaa !28
  %cp4 = getelementptr { ptr, %"compiler/lower:pl", %"compiler/lower:pl", i32, %"compiler/source:Span", i32, ptr, ptr, ptr }, ptr %env, i32 0, i32 4
  %cv4 = load %"compiler/source:Span", ptr %cp4, !tbaa !28
  %cp5 = getelementptr { ptr, %"compiler/lower:pl", %"compiler/lower:pl", i32, %"compiler/source:Span", i32, ptr, ptr, ptr }, ptr %env, i32 0, i32 5
  %cv5 = load i32, ptr %cp5, !tbaa !28
  %vq0 = getelementptr { ptr, %"compiler/lower:pl", %"compiler/lower:pl", i32, %"compiler/source:Span", i32, ptr, ptr, ptr }, ptr %env, i32 0, i32 6
  %vr0 = load ptr, ptr %vq0, !tbaa !28
  %vc0 = call ptr @__olang_capture_scope(ptr %vr0)
  %vq1 = getelementptr { ptr, %"compiler/lower:pl", %"compiler/lower:pl", i32, %"compiler/source:Span", i32, ptr, ptr, ptr }, ptr %env, i32 0, i32 7
  %vr1 = load ptr, ptr %vq1, !tbaa !28
  %vc1 = call ptr @__olang_capture_scope(ptr %vr1)
  %vq2 = getelementptr { ptr, %"compiler/lower:pl", %"compiler/lower:pl", i32, %"compiler/source:Span", i32, ptr, ptr, ptr }, ptr %env, i32 0, i32 8
  %vr2 = load ptr, ptr %vq2, !tbaa !28
  %vc2 = call ptr @__olang_capture_scope(ptr %vr2)
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l9, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t4 = load i32, ptr %l0, !tbaa !23
  store { i64, [1 x i64] } zeroinitializer, ptr %t5
  %t6 = getelementptr { i64, [1 x i64] }, ptr %t5, i32 0, i32 0
  store i64 1, ptr %t6
  %t8 = insertvalue { i32 } undef, i32 %t4, 0
  %t9 = getelementptr { i64, [1 x i64] }, ptr %t5, i32 0, i32 1
  store { i32 } %t8, ptr %t9
  %t10 = load { i64, [1 x i64] }, ptr %t5
  %t14 = call %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2ewith(ptr %vc0, ptr %vc1, ptr %s0, ptr %t2, %"compiler/lower:pl" %cv1, { i64, [1 x i64] } %t10)
  store %"compiler/lower:pl" %t14, ptr %l14
  br label %bb1
bb1:
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t17 = load i32, ptr %l0, !tbaa !23
  store { i64, [1 x i64] } zeroinitializer, ptr %t18
  %t19 = getelementptr { i64, [1 x i64] }, ptr %t18, i32 0, i32 0
  store i64 1, ptr %t19
  %t21 = insertvalue { i32 } undef, i32 %t17, 0
  %t22 = getelementptr { i64, [1 x i64] }, ptr %t18, i32 0, i32 1
  store { i32 } %t21, ptr %t22
  %t23 = load { i64, [1 x i64] }, ptr %t18
  %t27 = call %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2ewith(ptr %vc0, ptr %vc2, ptr %s0, ptr %t15, %"compiler/lower:pl" %cv2, { i64, [1 x i64] } %t23)
  store %"compiler/lower:pl" %t27, ptr %l19
  br label %bb2
bb2:
  %t30 = load ptr, ptr %l9, !tbaa !29
  %t31 = load %"compiler/lower:pl", ptr %l14
  %t32 = load %"compiler/lower:pl", ptr %l19
  %t35 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eequalAt(ptr %vc0, ptr %s0, ptr %s0, ptr %t30, %"compiler/lower:pl" %t31, %"compiler/lower:pl" %t32, i32 %cv3, %"compiler/source:Span" %cv4, i1 false)
  store { i64, [4 x i64] } %t35, ptr %l22
  br label %bb3
bb3:
  %t36 = load { i64, [4 x i64] }, ptr %l22
  store { i64, [4 x i64] } %t36, ptr %l6
  %t37 = load ptr, ptr %l1, !tbaa !29
  %t39 = getelementptr %"compiler/lower:lowering", ptr %t37, i32 0, i32 3
  %t41 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %vc0, ptr %t39)
  store i32 %t41, ptr %l25
  br label %bb4
bb4:
  %t42 = load i32, ptr %l25, !tbaa !23
  store i32 %t42, ptr %l7, !tbaa !23
  %t43 = load ptr, ptr %l1, !tbaa !29
  %t44 = load { i64, [4 x i64] }, ptr %l6
  %t45 = load i32, ptr %l7, !tbaa !23
  store { i64, [8 x i64] } zeroinitializer, ptr %t47
  %t48 = getelementptr { i64, [8 x i64] }, ptr %t47, i32 0, i32 0
  store i64 2, ptr %t48
  %t50 = insertvalue { { i64, [4 x i64] }, i32, i32 } undef, { i64, [4 x i64] } %t44, 0
  %t52 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t50, i32 %t45, 1
  %t54 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t52, i32 %cv5, 2
  %t55 = getelementptr { i64, [8 x i64] }, ptr %t47, i32 0, i32 1
  store { { i64, [4 x i64] }, i32, i32 } %t54, ptr %t55
  %t56 = load { i64, [8 x i64] }, ptr %t47
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %vc0, ptr %t43, { i64, [8 x i64] } %t56)
  br label %bb5
bb5:
  %t59 = load ptr, ptr %l1, !tbaa !29
  %t60 = load i32, ptr %l7, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %vc0, ptr %t59, i32 %t60)
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
@.d9 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Hash" }>, align 8
@.d10 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"hash" }>, align 8
define internal void @olang_lambda_11(ptr %env, i64 %a0, i32 %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l12 = alloca %"compiler/source:Span"
  %l13 = alloca ptr
  %l17 = alloca i32
  %l18 = alloca { i64, ptr }
  %l24 = alloca i64
  %l27 = alloca i64
  %l45 = alloca ptr
  %l46 = alloca i32
  %l47 = alloca ptr
  %l48 = alloca ptr
  %l53 = alloca %"compiler/lower:pl"
  %l56 = alloca %"compiler/lower:pl"
  %l60 = alloca { i64, [4 x i64] }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %t71 = alloca { i64, [1 x i64] }, align 8
  %t82 = alloca { i64, [1 x i64] }, align 8
  %cp0 = getelementptr { ptr, i32, %"compiler/lower:pl", %"compiler/source:Span", ptr, ptr }, ptr %env, i32 0, i32 0
  %cv0 = load ptr, ptr %cp0, !tbaa !28
  store ptr %cv0, ptr %l2
  %cp1 = getelementptr { ptr, i32, %"compiler/lower:pl", %"compiler/source:Span", ptr, ptr }, ptr %env, i32 0, i32 1
  %cv1 = load i32, ptr %cp1, !tbaa !28
  %cp2 = getelementptr { ptr, i32, %"compiler/lower:pl", %"compiler/source:Span", ptr, ptr }, ptr %env, i32 0, i32 2
  %cv2 = load %"compiler/lower:pl", ptr %cp2, !tbaa !28
  %cp3 = getelementptr { ptr, i32, %"compiler/lower:pl", %"compiler/source:Span", ptr, ptr }, ptr %env, i32 0, i32 3
  %cv3 = load %"compiler/source:Span", ptr %cp3, !tbaa !28
  store %"compiler/source:Span" %cv3, ptr %l12
  %vq0 = getelementptr { ptr, i32, %"compiler/lower:pl", %"compiler/source:Span", ptr, ptr }, ptr %env, i32 0, i32 4
  %vr0 = load ptr, ptr %vq0, !tbaa !28
  %vc0 = call ptr @__olang_capture_scope(ptr %vr0)
  %vq1 = getelementptr { ptr, i32, %"compiler/lower:pl", %"compiler/source:Span", ptr, ptr }, ptr %env, i32 0, i32 5
  %vr1 = load ptr, ptr %vq1, !tbaa !28
  %vc1 = call ptr @__olang_capture_scope(ptr %vr1)
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l2, !tbaa !29
  store ptr %t1, ptr %l13, !tbaa !29
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t4 = getelementptr %"compiler/lower:lowering", ptr %t2, i32 0, i32 2
  %t5 = load ptr, ptr %t4, !tbaa !29
  %t9 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %vc0, ptr %t5, i32 %a1)
  store i32 %t9, ptr %l17
  br label %bb1
bb1:
  %t10 = load ptr, ptr %l13, !tbaa !29
  %t11 = load i32, ptr %l17, !tbaa !23
  %t12 = call { i64, ptr } @compiler_2flower_2ecompiler_2flower_3alowering_2eitems(ptr %vc0, ptr %s0, ptr %t10, i32 %t11)
  store { i64, ptr } %t12, ptr %l18
  br label %bb2
bb2:
  %t13 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t13, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t14 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t16 = extractvalue { i64, ptr } %t14, 0
  store i64 %t16, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t18 = load i64, ptr %l5, !tbaa !24
  %t19 = load i64, ptr %l4, !tbaa !24
  %t22 = icmp sgt i64 %t18, %t19
  br i1 %t22, label %bb3, label %bb4
bb3:
  %t24 = load i64, ptr %l6, !tbaa !24
  %t26 = icmp sgt i64 %t24, 0
  br i1 %t26, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l24, !tbaa !24
  br label %bb8
bb5:
  %t28 = load i64, ptr %l5, !tbaa !24
  %t29 = load i64, ptr %l4, !tbaa !24
  %t32 = sub i64 %t28, %t29
  %t33 = load i64, ptr %l6, !tbaa !24
  %t36 = add i64 %t32, %t33
  %t38 = sub i64 %t36, 1
  %t39 = load i64, ptr %l6, !tbaa !24
  %t42 = sdiv i64 %t38, %t39
  store i64 %t42, ptr %l27, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l27, !tbaa !24
  br label %bb7
bb7:
  %t44 = load i64, ptr %l27, !tbaa !24
  store i64 %t44, ptr %l24, !tbaa !24
  br label %bb8
bb8:
  %t45 = load i64, ptr %l24, !tbaa !24
  store i64 %t45, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t46 = load i64, ptr %l8, !tbaa !24
  %t47 = load i64, ptr %l7, !tbaa !24
  %t50 = icmp slt i64 %t46, %t47
  %t52 = xor i1 %t50, true
  br i1 %t52, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb18
bb11:
  br label %bb12
bb12:
  %t54 = load i64, ptr %l4, !tbaa !24
  %t55 = load i64, ptr %l8, !tbaa !24
  %t56 = load i64, ptr %l6, !tbaa !24
  %t59 = mul i64 %t55, %t56
  %t62 = add i64 %t54, %t59
  store i64 %t62, ptr %l9, !tbaa !24
  %t64 = load ptr, ptr %l2, !tbaa !29
  store ptr %t64, ptr %l45, !tbaa !29
  store i32 %cv1, ptr %l46, !tbaa !23
  %t66 = load ptr, ptr %l2, !tbaa !29
  store ptr %t66, ptr %l47, !tbaa !29
  %t67 = load ptr, ptr %l2, !tbaa !29
  store ptr %t67, ptr %l48, !tbaa !29
  %t68 = load ptr, ptr %l2, !tbaa !29
  store { i64, [1 x i64] } zeroinitializer, ptr %t71
  %t72 = getelementptr { i64, [1 x i64] }, ptr %t71, i32 0, i32 0
  store i64 4, ptr %t72
  %t74 = insertvalue { i64 } undef, i64 %a0, 0
  %t75 = getelementptr { i64, [1 x i64] }, ptr %t71, i32 0, i32 1
  store { i64 } %t74, ptr %t75
  %t76 = load { i64, [1 x i64] }, ptr %t71
  %t80 = call %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2ewith(ptr %vc0, ptr %vc1, ptr %s2, ptr %t68, %"compiler/lower:pl" %cv2, { i64, [1 x i64] } %t76)
  store %"compiler/lower:pl" %t80, ptr %l53
  br label %bb13
bb13:
  %t81 = load i64, ptr %l9, !tbaa !24
  store { i64, [1 x i64] } zeroinitializer, ptr %t82
  %t83 = getelementptr { i64, [1 x i64] }, ptr %t82, i32 0, i32 0
  store i64 0, ptr %t83
  %t85 = insertvalue { i64 } undef, i64 %t81, 0
  %t86 = getelementptr { i64, [1 x i64] }, ptr %t82, i32 0, i32 1
  store { i64 } %t85, ptr %t86
  %t87 = load { i64, [1 x i64] }, ptr %t82
  %t88 = load ptr, ptr %l48, !tbaa !29
  %t89 = load %"compiler/lower:pl", ptr %l53
  %t91 = call %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2ewith(ptr %vc0, ptr %s2, ptr %s2, ptr %t88, %"compiler/lower:pl" %t89, { i64, [1 x i64] } %t87)
  store %"compiler/lower:pl" %t91, ptr %l56
  br label %bb14
bb14:
  %t92 = load i64, ptr %l9, !tbaa !24
  %t94 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !27
  %t96 = getelementptr i32, ptr %t95, i64 %t92
  %t97 = load i32, ptr %t96, !tbaa !33
  %t98 = load %"compiler/source:Span", ptr %l12
  %t99 = load ptr, ptr %l47, !tbaa !29
  %t100 = load %"compiler/lower:pl", ptr %l56
  %t103 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ehashAt(ptr %vc0, ptr %s2, ptr %t99, %"compiler/lower:pl" %t100, i32 %t97, %"compiler/source:Span" %t98, i1 false)
  store { i64, [4 x i64] } %t103, ptr %l60
  br label %bb15
bb15:
  %t104 = load %"compiler/source:Span", ptr %l12
  %t105 = load ptr, ptr %l45, !tbaa !29
  %t106 = load i32, ptr %l46, !tbaa !23
  %t107 = load { i64, [4 x i64] }, ptr %l60
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2ecombine(ptr %vc0, ptr %t105, i32 %t106, { i64, [4 x i64] } %t107, %"compiler/source:Span" %t104)
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s2)
  br label %bb17
bb17:
  %t109 = load i64, ptr %l8, !tbaa !24
  %t111 = add i64 %t109, 1
  store i64 %t111, ptr %l8, !tbaa !24
  br label %bb9
bb18:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

@.d12 = private constant <{ i64, [38 x i8] }> <{ i64 0, [38 x i8] c"a Hash helper for a type with no parts" }>, align 8
define internal void @olang_lambda_13(ptr %env, i32 %a0) #0 {
entry:
  %l1 = alloca ptr
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca ptr
  %l7 = alloca i32
  %l8 = alloca ptr
  %l13 = alloca %"compiler/lower:pl"
  %l16 = alloca { i64, [4 x i64] }
  %s0 = alloca %olang.scope
  %t7 = alloca { i64, [1 x i64] }, align 8
  %cp0 = getelementptr { ptr, i32, %"compiler/lower:pl", i32, %"compiler/source:Span", ptr, ptr }, ptr %env, i32 0, i32 0
  %cv0 = load ptr, ptr %cp0, !tbaa !28
  store ptr %cv0, ptr %l1
  %cp1 = getelementptr { ptr, i32, %"compiler/lower:pl", i32, %"compiler/source:Span", ptr, ptr }, ptr %env, i32 0, i32 1
  %cv1 = load i32, ptr %cp1, !tbaa !28
  %cp2 = getelementptr { ptr, i32, %"compiler/lower:pl", i32, %"compiler/source:Span", ptr, ptr }, ptr %env, i32 0, i32 2
  %cv2 = load %"compiler/lower:pl", ptr %cp2, !tbaa !28
  %cp3 = getelementptr { ptr, i32, %"compiler/lower:pl", i32, %"compiler/source:Span", ptr, ptr }, ptr %env, i32 0, i32 3
  %cv3 = load i32, ptr %cp3, !tbaa !28
  %cp4 = getelementptr { ptr, i32, %"compiler/lower:pl", i32, %"compiler/source:Span", ptr, ptr }, ptr %env, i32 0, i32 4
  %cv4 = load %"compiler/source:Span", ptr %cp4, !tbaa !28
  store %"compiler/source:Span" %cv4, ptr %l5
  %vq0 = getelementptr { ptr, i32, %"compiler/lower:pl", i32, %"compiler/source:Span", ptr, ptr }, ptr %env, i32 0, i32 5
  %vr0 = load ptr, ptr %vq0, !tbaa !28
  %vc0 = call ptr @__olang_capture_scope(ptr %vr0)
  %vq1 = getelementptr { ptr, i32, %"compiler/lower:pl", i32, %"compiler/source:Span", ptr, ptr }, ptr %env, i32 0, i32 6
  %vr1 = load ptr, ptr %vq1, !tbaa !28
  %vc1 = call ptr @__olang_capture_scope(ptr %vr1)
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l6, !tbaa !29
  store i32 %cv1, ptr %l7, !tbaa !23
  %t3 = load ptr, ptr %l1, !tbaa !29
  store ptr %t3, ptr %l8, !tbaa !29
  %t4 = load ptr, ptr %l1, !tbaa !29
  store { i64, [1 x i64] } zeroinitializer, ptr %t7
  %t8 = getelementptr { i64, [1 x i64] }, ptr %t7, i32 0, i32 0
  store i64 1, ptr %t8
  %t10 = insertvalue { i32 } undef, i32 %a0, 0
  %t11 = getelementptr { i64, [1 x i64] }, ptr %t7, i32 0, i32 1
  store { i32 } %t10, ptr %t11
  %t12 = load { i64, [1 x i64] }, ptr %t7
  %t16 = call %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2ewith(ptr %vc0, ptr %vc1, ptr %s0, ptr %t4, %"compiler/lower:pl" %cv2, { i64, [1 x i64] } %t12)
  store %"compiler/lower:pl" %t16, ptr %l13
  br label %bb1
bb1:
  %t18 = load %"compiler/source:Span", ptr %l5
  %t19 = load ptr, ptr %l8, !tbaa !29
  %t20 = load %"compiler/lower:pl", ptr %l13
  %t23 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ehashAt(ptr %vc0, ptr %s0, ptr %t19, %"compiler/lower:pl" %t20, i32 %cv3, %"compiler/source:Span" %t18, i1 false)
  store { i64, [4 x i64] } %t23, ptr %l16
  br label %bb2
bb2:
  %t24 = load %"compiler/source:Span", ptr %l5
  %t25 = load ptr, ptr %l6, !tbaa !29
  %t26 = load i32, ptr %l7, !tbaa !23
  %t27 = load { i64, [4 x i64] }, ptr %l16
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2ecombine(ptr %vc0, ptr %t25, i32 %t26, { i64, [4 x i64] } %t27, %"compiler/source:Span" %t24)
  br label %bb3
bb3:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3alevel_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2flower_3alevel_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

declare void @__olang_ert_req_clear()
@.d14 = private constant <{ i64, [38 x i8] }> <{ i64 0, [38 x i8] c"a jump out of a loop not being lowered" }>, align 8
@.d15 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"a place that is none" }>, align 8
@.d16 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"null" }>, align 8
@.d17 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"..." }>, align 8
@.d18 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"null" }>, align 8
@.d19 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d20 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d21 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d22 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d23 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
declare i64 @__olang_fmt_i64(ptr, i64)
@.d24 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d25 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d26 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d27 = private constant <{ i64, [44 x i8] }> <{ i64 0, [44 x i8] c"a Render helper for a type with no rendering" }>, align 8
@.d28 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"[" }>, align 8
define internal void @olang_lambda_29(ptr %env, i32 %a0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca { i64, [4 x i64] }
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca { i64, [1 x i64] }
  %l9 = alloca ptr
  %l10 = alloca i32
  %l11 = alloca i32
  %l13 = alloca %"compiler/mir:Place"
  %l14 = alloca { i64, [4 x i64] }
  %l16 = alloca { i64, [4 x i64] }
  %l17 = alloca { i64, ptr }
  %l19 = alloca { i64, [4 x i64] }
  %l22 = alloca i32
  %l25 = alloca i32
  %l40 = alloca ptr
  %l45 = alloca %"compiler/lower:pl"
  %s0 = alloca %olang.scope
  %t6 = alloca { i64, [4 x i64] }, align 8
  %t51 = alloca { i64, [8 x i64] }, align 8
  %t85 = alloca { i64, [1 x i64] }, align 8
  store i32 %a0, ptr %l0
  %cp0 = getelementptr { ptr, %"compiler/source:Span", { i64, [1 x i64] }, %"compiler/lower:pl", i32, ptr, ptr }, ptr %env, i32 0, i32 0
  %cv0 = load ptr, ptr %cp0, !tbaa !28
  store ptr %cv0, ptr %l1
  %cp1 = getelementptr { ptr, %"compiler/source:Span", { i64, [1 x i64] }, %"compiler/lower:pl", i32, ptr, ptr }, ptr %env, i32 0, i32 1
  %cv1 = load %"compiler/source:Span", ptr %cp1, !tbaa !28
  store %"compiler/source:Span" %cv1, ptr %l2
  %cp2 = getelementptr { ptr, %"compiler/source:Span", { i64, [1 x i64] }, %"compiler/lower:pl", i32, ptr, ptr }, ptr %env, i32 0, i32 2
  %cv2 = load { i64, [1 x i64] }, ptr %cp2, !tbaa !28
  store { i64, [1 x i64] } %cv2, ptr %l6
  %cp3 = getelementptr { ptr, %"compiler/source:Span", { i64, [1 x i64] }, %"compiler/lower:pl", i32, ptr, ptr }, ptr %env, i32 0, i32 3
  %cv3 = load %"compiler/lower:pl", ptr %cp3, !tbaa !28
  %cp4 = getelementptr { ptr, %"compiler/source:Span", { i64, [1 x i64] }, %"compiler/lower:pl", i32, ptr, ptr }, ptr %env, i32 0, i32 4
  %cv4 = load i32, ptr %cp4, !tbaa !28
  %vq0 = getelementptr { ptr, %"compiler/source:Span", { i64, [1 x i64] }, %"compiler/lower:pl", i32, ptr, ptr }, ptr %env, i32 0, i32 5
  %vr0 = load ptr, ptr %vq0, !tbaa !28
  %vc0 = call ptr @__olang_capture_scope(ptr %vr0)
  %vq1 = getelementptr { ptr, %"compiler/source:Span", { i64, [1 x i64] }, %"compiler/lower:pl", i32, ptr, ptr }, ptr %env, i32 0, i32 6
  %vr1 = load ptr, ptr %vq1, !tbaa !28
  %vc1 = call ptr @__olang_capture_scope(ptr %vr1)
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l9, !tbaa !29
  store i32 13, ptr %l10
  %t2 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t2, ptr %l11, !tbaa !23
  %t3 = load i32, ptr %l0, !tbaa !23
  %t5 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t3)
  store %"compiler/mir:Place" %t5, ptr %l13
  br label %bb1
bb1:
  store { i64, [4 x i64] } zeroinitializer, ptr %t6
  %t7 = getelementptr { i64, [4 x i64] }, ptr %t6, i32 0, i32 0
  store i64 1, ptr %t7
  %t8 = load %"compiler/mir:Place", ptr %l13
  %t9 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t8, 0
  %t10 = getelementptr { i64, [4 x i64] }, ptr %t6, i32 0, i32 1
  store { %"compiler/mir:Place" } %t9, ptr %t10
  %t11 = load { i64, [4 x i64] }, ptr %t6
  store { i64, [4 x i64] } %t11, ptr %l14
  %t12 = load ptr, ptr %l1, !tbaa !29
  %t14 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2econstI64(ptr %vc0, ptr %t12, i64 0)
  store { i64, [4 x i64] } %t14, ptr %l16
  br label %bb2
bb2:
  %t15 = mul i64 2, 40
  %t16 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t15)
  %t17 = insertvalue { i64, ptr } undef, i64 2, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  store { i64, ptr } %t18, ptr %l17, !tbaa !27
  %t19 = load { i64, [4 x i64] }, ptr %l14
  %t20 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = getelementptr { i64, [4 x i64] }, ptr %t21, i64 0
  store { i64, [4 x i64] } %t19, ptr %t22
  %t23 = load { i64, [4 x i64] }, ptr %l16
  %t24 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = getelementptr { i64, [4 x i64] }, ptr %t25, i64 1
  store { i64, [4 x i64] } %t23, ptr %t26
  %t27 = load %"compiler/source:Span", ptr %l2
  %t28 = load ptr, ptr %l9, !tbaa !29
  %t29 = load i32, ptr %l10
  %t30 = load i32, ptr %l11, !tbaa !23
  %t31 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t33 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %vc0, ptr %s0, ptr %t28, i32 %t29, i32 %t30, { i64, ptr } %t31, %"compiler/source:Span" %t27)
  store { i64, [4 x i64] } %t33, ptr %l19
  br label %bb3
bb3:
  %t34 = load { i64, [4 x i64] }, ptr %l19
  store { i64, [4 x i64] } %t34, ptr %l3
  %t35 = load ptr, ptr %l1, !tbaa !29
  %t37 = getelementptr %"compiler/lower:lowering", ptr %t35, i32 0, i32 3
  %t39 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %vc0, ptr %t37)
  store i32 %t39, ptr %l22
  br label %bb4
bb4:
  %t40 = load i32, ptr %l22, !tbaa !23
  store i32 %t40, ptr %l4, !tbaa !23
  %t41 = load ptr, ptr %l1, !tbaa !29
  %t43 = getelementptr %"compiler/lower:lowering", ptr %t41, i32 0, i32 3
  %t45 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %vc0, ptr %t43)
  store i32 %t45, ptr %l25
  br label %bb5
bb5:
  %t46 = load i32, ptr %l25, !tbaa !23
  store i32 %t46, ptr %l5, !tbaa !23
  %t47 = load ptr, ptr %l1, !tbaa !29
  %t48 = load { i64, [4 x i64] }, ptr %l3
  %t49 = load i32, ptr %l5, !tbaa !23
  %t50 = load i32, ptr %l4, !tbaa !23
  store { i64, [8 x i64] } zeroinitializer, ptr %t51
  %t52 = getelementptr { i64, [8 x i64] }, ptr %t51, i32 0, i32 0
  store i64 2, ptr %t52
  %t54 = insertvalue { { i64, [4 x i64] }, i32, i32 } undef, { i64, [4 x i64] } %t48, 0
  %t56 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t54, i32 %t49, 1
  %t58 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t56, i32 %t50, 2
  %t59 = getelementptr { i64, [8 x i64] }, ptr %t51, i32 0, i32 1
  store { { i64, [4 x i64] }, i32, i32 } %t58, ptr %t59
  %t60 = load { i64, [8 x i64] }, ptr %t51
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %vc0, ptr %t47, { i64, [8 x i64] } %t60)
  br label %bb6
bb6:
  %t63 = load ptr, ptr %l1, !tbaa !29
  %t64 = load i32, ptr %l4, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %vc0, ptr %t63, i32 %t64)
  br label %bb7
bb7:
  %t67 = load ptr, ptr %l1, !tbaa !29
  %t68 = load { i64, [1 x i64] }, ptr %l6
  %t69 = load %"compiler/source:Span", ptr %l2
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eword(ptr %vc0, ptr %s0, ptr %t67, { i64, [1 x i64] } %t68, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d60, i32 0, i32 1) }, %"compiler/source:Span" %t69)
  br label %bb8
bb8:
  %t73 = load ptr, ptr %l1, !tbaa !29
  %t74 = load i32, ptr %l5, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2egoto(ptr %vc0, ptr %t73, i32 %t74)
  br label %bb9
bb9:
  %t77 = load ptr, ptr %l1, !tbaa !29
  %t78 = load i32, ptr %l5, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %vc0, ptr %t77, i32 %t78)
  br label %bb10
bb10:
  %t81 = load ptr, ptr %l1, !tbaa !29
  store ptr %t81, ptr %l40, !tbaa !29
  %t82 = load ptr, ptr %l1, !tbaa !29
  %t84 = load i32, ptr %l0, !tbaa !23
  store { i64, [1 x i64] } zeroinitializer, ptr %t85
  %t86 = getelementptr { i64, [1 x i64] }, ptr %t85, i32 0, i32 0
  store i64 1, ptr %t86
  %t88 = insertvalue { i32 } undef, i32 %t84, 0
  %t89 = getelementptr { i64, [1 x i64] }, ptr %t85, i32 0, i32 1
  store { i32 } %t88, ptr %t89
  %t90 = load { i64, [1 x i64] }, ptr %t85
  %t94 = call %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2ewith(ptr %vc0, ptr %vc1, ptr %s0, ptr %t82, %"compiler/lower:pl" %cv3, { i64, [1 x i64] } %t90)
  store %"compiler/lower:pl" %t94, ptr %l45
  br label %bb11
bb11:
  %t96 = load { i64, [1 x i64] }, ptr %l6
  %t97 = load %"compiler/source:Span", ptr %l2
  %t98 = load ptr, ptr %l40, !tbaa !29
  %t99 = load %"compiler/lower:pl", ptr %l45
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2einner(ptr %vc0, ptr %s0, ptr %t98, %"compiler/lower:pl" %t99, i32 %cv4, { i64, [1 x i64] } %t96, %"compiler/source:Span" %t97)
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

@.d30 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"]" }>, align 8
define linkonce_odr i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fmir_3aScopeRef(ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca i64
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %t1
  store i64 %t2, ptr %l3, !tbaa !24
  %t3 = load ptr, ptr %l1, !tbaa !29
  %t4 = load i64, ptr %t3
  %t5 = load i64, ptr %l3, !tbaa !24
  %t7 = icmp eq i64 %t5, %t4
  br i1 %t7, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb10
bb2:
  %t9 = load i64, ptr %l3, !tbaa !24
  switch i64 %t9, label %bb3 [ i64 0, label %bb4 i64 1, label %bb5 i64 4, label %bb6 ]
bb3:
  br label %bb10
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr { i64, [1 x i64] }, ptr %t10, i32 0, i32 1
  %t12 = getelementptr { i32 }, ptr %t11, i32 0, i32 0
  %t13 = load i32, ptr %t12
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t15 = getelementptr { i64, [1 x i64] }, ptr %t14, i32 0, i32 1
  %t16 = getelementptr { i32 }, ptr %t15, i32 0, i32 0
  %t17 = load i32, ptr %t16
  %t20 = icmp eq i32 %t13, %t17
  br i1 %t20, label %bb7, label %bb1
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr { i64, [1 x i64] }, ptr %t22, i32 0, i32 1
  %t24 = getelementptr { i64 }, ptr %t23, i32 0, i32 0
  %t25 = load i64, ptr %t24
  %t26 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr { i64, [1 x i64] }, ptr %t26, i32 0, i32 1
  %t28 = getelementptr { i64 }, ptr %t27, i32 0, i32 0
  %t29 = load i64, ptr %t28
  %t32 = icmp eq i64 %t25, %t29
  br i1 %t32, label %bb8, label %bb1
bb6:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr { i64, [1 x i64] }, ptr %t34, i32 0, i32 1
  %t36 = getelementptr { i32 }, ptr %t35, i32 0, i32 0
  %t37 = load i32, ptr %t36
  %t38 = load ptr, ptr %l1, !tbaa !29
  %t39 = getelementptr { i64, [1 x i64] }, ptr %t38, i32 0, i32 1
  %t40 = getelementptr { i32 }, ptr %t39, i32 0, i32 0
  %t41 = load i32, ptr %t40
  %t44 = icmp eq i32 %t37, %t41
  br i1 %t44, label %bb9, label %bb1
bb7:
  br label %bb3
bb8:
  br label %bb3
bb9:
  br label %bb3
bb10:
  %t46 = load i1, ptr %l2, !tbaa !21
  store i1 %t46, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

@.d31 = private constant <{ i64, [47 x i8] }> <{ i64 0, [47 x i8] c"an unknown type (a check error or gap): a local" }>, align 8
@.d32 = private constant <{ i64, [55 x i8] }> <{ i64 0, [55 x i8] c"a compound assignment's old value outside an assignment" }>, align 8
@.d33 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"U8" }>, align 8
@.d34 = private constant <{ i64, [53 x i8] }> <{ i64 0, [53 x i8] c"an unknown type (a check error or gap): an expression" }>, align 8
@.d35 = private constant <{ i64, [39 x i8] }> <{ i64 0, [39 x i8] c"a zero value whose constructor can fail" }>, align 8
@.d36 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d37 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d38 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"/main.olang" }>, align 8
@.d39 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"linux" }>, align 8
@.d40 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"x86_64" }>, align 8
@.d41 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"x86-64" }>, align 8
@.d42 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"/olang.lock" }>, align 8
@.d43 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"/cache" }>, align 8
@.d44 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"file:///nowhere/" }>, align 8
@.d45 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"std" }>, align 8
@.d46 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"/main.olang" }>, align 8
@.d47 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d48 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"B" }>, align 8
@.d49 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c": gapped\0A" }>, align 8
@.d50 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d51 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"B" }>, align 8
@.d52 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c": " }>, align 8
@.d53 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
define linkonce_odr void @olang_2eHelperKind_2eRender_2ecompiler_2fmir_3aFnKey(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %t1
  switch i64 %t2, label %bb1 [ i64 0, label %bb2 i64 1, label %bb3 i64 2, label %bb4 i64 3, label %bb5 i64 4, label %bb6 ]
bb1:
  br label %ret
bb2:
  %t4 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d61, i32 0, i32 1) }, 1
  %t5 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d61, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t4, i64 %t5)
  %t6 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d62, i32 0, i32 1) }, 1
  %t7 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d62, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t6, i64 %t7)
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr { i64, [2 x i64] }, ptr %t8, i32 0, i32 1
  %t10 = getelementptr { i32 }, ptr %t9, i32 0, i32 0
  %t11 = load i32, ptr %t10
  %t13 = sext i32 %t11 to i64
  %t14 = call ptr @__olang_sb_room(ptr %v0, i64 24)
  %t15 = call i64 @__olang_fmt_i64(ptr %t14, i64 %t13)
  call void @__olang_sb_add(ptr %v0, i64 %t15)
  %t16 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d63, i32 0, i32 1) }, 1
  %t17 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d63, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t16, i64 %t17)
  br label %bb1
bb3:
  %t18 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d64, i32 0, i32 1) }, 1
  %t19 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d64, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t18, i64 %t19)
  %t20 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d62, i32 0, i32 1) }, 1
  %t21 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d62, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t20, i64 %t21)
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr { i64, [2 x i64] }, ptr %t22, i32 0, i32 1
  %t24 = getelementptr { i32 }, ptr %t23, i32 0, i32 0
  %t25 = load i32, ptr %t24
  %t27 = sext i32 %t25 to i64
  %t28 = call ptr @__olang_sb_room(ptr %v0, i64 24)
  %t29 = call i64 @__olang_fmt_i64(ptr %t28, i64 %t27)
  call void @__olang_sb_add(ptr %v0, i64 %t29)
  %t30 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d63, i32 0, i32 1) }, 1
  %t31 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d63, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t30, i64 %t31)
  br label %bb1
bb4:
  %t32 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d65, i32 0, i32 1) }, 1
  %t33 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d65, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t32, i64 %t33)
  %t34 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d62, i32 0, i32 1) }, 1
  %t35 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d62, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t34, i64 %t35)
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr { i64, [2 x i64] }, ptr %t36, i32 0, i32 1
  %t38 = getelementptr { i32, i32 }, ptr %t37, i32 0, i32 0
  call void @olang_2eHelperKind_2eRender_2ecompiler_2fmir_3aHelperKind(ptr %v0, ptr %t38, i64 %a1)
  br label %bb7
bb5:
  %t41 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d66, i32 0, i32 1) }, 1
  %t42 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d66, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t41, i64 %t42)
  %t43 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d62, i32 0, i32 1) }, 1
  %t44 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d62, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t43, i64 %t44)
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr { i64, [2 x i64] }, ptr %t45, i32 0, i32 1
  %t47 = getelementptr { i64 }, ptr %t46, i32 0, i32 0
  %t48 = load i64, ptr %t47
  %t50 = call ptr @__olang_sb_room(ptr %v0, i64 24)
  %t51 = call i64 @__olang_fmt_i64(ptr %t50, i64 %t48)
  call void @__olang_sb_add(ptr %v0, i64 %t51)
  %t52 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d63, i32 0, i32 1) }, 1
  %t53 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d63, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t52, i64 %t53)
  br label %bb1
bb6:
  %t54 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d67, i32 0, i32 1) }, 1
  %t55 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d67, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t54, i64 %t55)
  %t56 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d62, i32 0, i32 1) }, 1
  %t57 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d62, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t56, i64 %t57)
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr { i64, [2 x i64] }, ptr %t58, i32 0, i32 1
  %t60 = getelementptr { i64, i1 }, ptr %t59, i32 0, i32 0
  %t61 = load i64, ptr %t60
  %t63 = call ptr @__olang_sb_room(ptr %v0, i64 24)
  %t64 = call i64 @__olang_fmt_i64(ptr %t63, i64 %t61)
  call void @__olang_sb_add(ptr %v0, i64 %t64)
  %t65 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d68, i32 0, i32 1) }, 1
  %t66 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d68, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t65, i64 %t66)
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr { i64, [2 x i64] }, ptr %t67, i32 0, i32 1
  %t69 = getelementptr { i64, i1 }, ptr %t68, i32 0, i32 1
  %t70 = load i1, ptr %t69
  %t72 = select i1 %t70, ptr @.c69, ptr @.c70
  %t73 = select i1 %t70, i64 4, i64 5
  call void @__olang_sb_put(ptr %v0, ptr %t72, i64 %t73)
  %t74 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d63, i32 0, i32 1) }, 1
  %t75 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d63, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t74, i64 %t75)
  br label %bb1
bb7:
  %t76 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d68, i32 0, i32 1) }, 1
  %t77 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d68, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t76, i64 %t77)
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr { i64, [2 x i64] }, ptr %t78, i32 0, i32 1
  %t80 = getelementptr { i32, i32 }, ptr %t79, i32 0, i32 1
  %t81 = load i32, ptr %t80
  %t83 = sext i32 %t81 to i64
  %t84 = call ptr @__olang_sb_room(ptr %v0, i64 24)
  %t85 = call i64 @__olang_fmt_i64(ptr %t84, i64 %t83)
  call void @__olang_sb_add(ptr %v0, i64 %t85)
  %t86 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d63, i32 0, i32 1) }, 1
  %t87 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d63, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t86, i64 %t87)
  br label %bb1
ret:
  ret void
}

@.d54 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c": gapped\0A" }>, align 8
declare void @__olang_sb_put(ptr, ptr, i64)
declare void @__olang_sb_done(ptr)
@.d55 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d56 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c": " }>, align 8
@.d57 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d58 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"gap " }>, align 8
@.d59 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
define available_externally void @__olang_dtor_head(ptr %node, ptr %at) alwaysinline {
entry:
  %has = icmp ne ptr %node, null
  br i1 %has, label %fix, label %done
fix:
  %ppp = getelementptr %olang.dtornode, ptr %node, i32 0, i32 3
  store ptr %at, ptr %ppp
  br label %done
done:
  ret void
}
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
@__olang_self = external thread_local(initialexec) global ptr
define available_externally ptr @__olang_capture_scope(ptr %s) alwaysinline {
entry:
  %isprog = icmp eq ptr %s, null
  br i1 %isprog, label %prog, label %mine
prog:
  %p = load ptr, ptr @__olang_prog_scope
  ret ptr %p
mine:
  %m = call ptr @__olang_scope_mine(ptr %s)
  ret ptr %m
}
@.d60 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d61 = private unnamed_addr constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"FnKey.Body" }>, align 8
@.d62 = private unnamed_addr constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
define available_externally ptr @__olang_sb_room(ptr %sb, i64 %need) alwaysinline {
entry:
  %lenp = getelementptr { ptr, i64, i64, ptr }, ptr %sb, i32 0, i32 1
  %capp = getelementptr { ptr, i64, i64, ptr }, ptr %sb, i32 0, i32 2
  %len = load i64, ptr %lenp
  %cap = load i64, ptr %capp
  %want = add i64 %len, %need
  %fits = icmp ule i64 %want, %cap
  br i1 %fits, label %ok, label %grow
ok:
  %data = load ptr, ptr %sb
  %p = getelementptr i8, ptr %data, i64 %len
  ret ptr %p
grow:
  %g = call ptr @__olang_sb_grow(ptr %sb, i64 %need)
  ret ptr %g
}
declare void @__olang_sb_add(ptr, i64)
@.d63 = private unnamed_addr constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d64 = private unnamed_addr constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"FnKey.Adapter" }>, align 8
@.d65 = private unnamed_addr constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"FnKey.Helper" }>, align 8
define linkonce_odr void @olang_2eHelperKind_2eRender_2ecompiler_2fmir_3aHelperKind(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load i32, ptr %a0
  %t3 = sext i32 %t2 to i64
  switch i64 %t3, label %bb1 [ i64 0, label %bb2 i64 1, label %bb3 i64 2, label %bb4 i64 3, label %bb5 ]
bb1:
  br label %ret
bb2:
  %t5 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d71, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d71, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t5, i64 %t6)
  br label %bb1
bb3:
  %t7 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d72, i32 0, i32 1) }, 1
  %t8 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d72, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t7, i64 %t8)
  br label %bb1
bb4:
  %t9 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d73, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d73, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t9, i64 %t10)
  br label %bb1
bb5:
  %t11 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d74, i32 0, i32 1) }, 1
  %t12 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d74, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t11, i64 %t12)
  br label %bb1
ret:
  ret void
}

@.d66 = private unnamed_addr constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"FnKey.Init" }>, align 8
@.d67 = private unnamed_addr constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"FnKey.AnyRender" }>, align 8
@.d68 = private unnamed_addr constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.c69 = private unnamed_addr constant [5 x i8] c"true\00"
@.c70 = private unnamed_addr constant [6 x i8] c"false\00"
define available_externally ptr @__olang_scope_mine(ptr %s) alwaysinline {
entry:
  %op = getelementptr %olang.scope, ptr %s, i32 0, i32 3
  %o = load atomic ptr, ptr %op monotonic, align 8
  %me = load ptr, ptr @__olang_self
  %own = icmp eq ptr %o, %me
  br i1 %own, label %mine, label %slow
mine:
  ret ptr %s
slow:
  %r = call ptr @__olang_scope_mine_slow(ptr %s)
  ret ptr %r
}
declare ptr @__olang_sb_grow(ptr, i64) noinline
@.d71 = private unnamed_addr constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"HelperKind.Render" }>, align 8
@.d72 = private unnamed_addr constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"HelperKind.Equal" }>, align 8
@.d73 = private unnamed_addr constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"HelperKind.Hash" }>, align 8
@.d74 = private unnamed_addr constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"HelperKind.Zero" }>, align 8
declare ptr @__olang_scope_mine_slow(ptr) noinline
@G_2ecompiler_2flower_2eInvalid = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2flower_2eOutOfBounds = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
@olang_loc_fb323a156c70c4fe_3d15b87c8f91a072 = external constant [0 x i8]
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_Ha6bcf4d517e3d7b46809e1dbf938da91(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eHas_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_e3721461a855ef35_c24433bc0ae5f641 = external constant [0 x i8]
declare void @compiler_2flower_2ecompiler_2flower_3aLowerer_2eLower(ptr %out, ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3aFn_2eVerify(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3aFn_2eDump(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_4e4c17ebfaf5d7b6_624a73934957b6f2 = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i32 %a3, i32 %a4, i64 %a5)
declare void @compiler_2flower_2estandIn(ptr %out, ptr %v0, i32 %a0)
declare void @compiler_2flower_2ecompiler_2flower_3aLowerer_2ebare(ptr %out, ptr %v0, ptr %v1, ptr %a0, { i64, [2 x i64] } %a1, i32 %a2)
declare void @compiler_2flower_3alowering_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, ptr %a2, ptr %a3)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2eadapterBody(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i32 %a3)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ePreludeType(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0)
@G_2ecompiler_2flower_2eFailIds = external constant <{ [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr }>
@G_2ecompiler_2flower_2eFailTypes = external constant <{ [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr }>
@G_2ecompiler_2flower_2eFailWords = external constant <{ [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr }>
@G_2ecompiler_2ftypes_2eUnknownT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorWords(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %a0, i32 %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i32 %a1)
declare i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e__Hccd9659a44f570da1fa06b019882a84d(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
@olang_loc_3aca88f8a70b165c_61af268fc3dc2410 = external constant [0 x i8]
declare void @compiler_2flower_2ecompiler_2flower_3aLowerer_2eWant(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1)
declare { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ebuilt(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eArgs(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare %"compiler/mir:Range" @compiler_2flower_2ecompiler_2flower_3alowering_2ecapScopes(ptr %v0, ptr %a0, i32 %a1)
declare { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %a0, i32 %a1, { i64, [15 x i64] } %a2, %"compiler/source:Span" %a3)
@G_2ecompiler_2fmir_2eNoLocal = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\FF\FF\FF\FF" }>, align 8
declare %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %a0)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3alevel_3e_2eLen_3ccompiler_2flower_3alevel_3e(ptr %v0, ptr %a0)
declare %"compiler/lower:level" @compiler_2flower_2ecompiler_2flower_3alowering_2etop(ptr %v0, ptr %a0)
@olang_loc_2262f7260befbeda_ad33d1a86099f68e = external constant [0 x i8]
@olang_loc_78466967dd42e061_bdc585e3e8213235 = external constant [0 x i8]
@olang_loc_6143a96035d3ceac_ef612191f7538720 = external constant [0 x i8]
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2eopenBlock(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, i32 %a3)
@olang_loc_9919e1798def049b_eb223155b689b93f = external constant [0 x i8]
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2ecloseBlock(ptr %v0, ptr %a0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2fmir_2eI64T = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\06\00\00\00" }>, align 8
declare { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2, { i64, ptr } %a3, %"compiler/source:Span" %a4)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %a0, { i64, [8 x i64] } %a1)
@olang_loc_b4f44bfc4c4e49f2_17d18a81dcc1f1de = external constant [0 x i8]
declare { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einstance(ptr %v0, ptr %a0)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDestructs(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eBoolT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
declare { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2econstI64(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2echeck(ptr %v0, ptr %a0, { i64, [4 x i64] } %a1, i32 %a2, i32 %a3, i64 %a4, %"compiler/source:Span" %a5)
declare ptr @compiler_2flower_2ederefOf(ptr %v0, ptr %a0)
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v0, ptr %a0)
declare i1 @compiler_2flower_2ecompiler_2flower_3alowering_2evalueArray(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2flower_2ecompiler_2flower_3alowering_2ewidening(ptr %v0, ptr %v1, ptr %a0, i32 %a1, { i64, ptr } %a2, i32 %a3)
declare i1 @compiler_2ftyped_2eScopedCall(ptr %v0, ptr %a0)
@olang_loc_755da8ec4c9a9682_903a5def85eef08e = external constant [0 x i8]
@olang_loc_429a5ad7d8f4c2a0_c1ea905c2e39baec = external constant [0 x i8]
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3atryCtx_3e_2eLen_3ccompiler_2flower_3atryCtx_3e(ptr %v0, ptr %a0)
declare %"compiler/lower:tryCtx" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3atryCtx_3e_2eAt_3ccompiler_2flower_3atryCtx_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
@G_2ecompiler_2fmir_2eI32T = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\05\00\00\00" }>, align 8
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2etoClause(ptr %v0, ptr %v1, ptr %a0, %"compiler/lower:tryCtx" %a1, i64 %a2, { i64, [4 x i64] } %a3, i32 %a4)
declare i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %a0)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2ebang(ptr %v0, ptr %a0, { i64, [4 x i64] } %a1, i32 %a2, %"compiler/source:Span" %a3, i32 %a4)
@olang_loc_c6e2ba3cedb073a3_23085f6ef83cda97 = external constant [0 x i8]
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2eraise(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, { i64, [4 x i64] } %a2)
declare i1 @compiler_2flower_2ecompiler_2flower_3alowering_2escalar(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/mir:Place" @compiler_2flower_2ecompiler_2flower_3alowering_2emk(ptr %v0, ptr %v1, ptr %a0, %"compiler/lower:pl" %a1)
declare i32 @compiler_2flower_2ecompiler_2flower_3alowering_2earrayOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2flower_2ecompiler_2flower_3alowering_2elocal(ptr %v0, ptr %a0, { i64, [4 x i64] } %a1, i32 %a2, %"compiler/source:Span" %a3)
declare i32 @compiler_2flower_2ecompiler_2flower_3alowering_2eflag(ptr %v0, ptr %a0, i1 %a1, %"compiler/source:Span" %a2)
declare { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2econstBool(ptr %v0, ptr %a0, i1 %a1, %"compiler/source:Span" %a2)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2egoto(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2eat(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2erefTo(ptr %v0, ptr %v1, ptr %a0, %"compiler/lower:pl" %a1, i32 %a2, %"compiler/source:Span" %a3)
declare { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ehelperCall(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, i32 %a2, { i64, ptr } %a3, { i64, ptr } %a4, i32 %a5, %"compiler/source:Span" %a6)
declare { { i64, ptr }, i1 } @compiler_2flower_2ecompiler_2flower_3alowering_2ecasesOf(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2ewith(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/lower:pl" %a1, { i64, [1 x i64] } %a2)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2epayloads(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, [4 x i64] } %a2, %"compiler/source:Span" %a3, ptr %a4c, ptr %a4e)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2eeachIndex(ptr %v0, ptr %v1, ptr %a0, { i64, [4 x i64] } %a1, %"compiler/source:Span" %a2, ptr %a3c, ptr %a3e)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2epatch(ptr %v0, ptr %v1, ptr %a0, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstValue(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/lower:Gap" @compiler_2flower_3aGap_2ector(ptr %v0, ptr %v1, i64 %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3aGap_3e_2ePush_3ccompiler_2flower_3aGap_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/lower:Gap" %a1)
declare i64 @compiler_2flower_2ecompiler_2flower_3alowering_2emethodBody(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, { i64, ptr } %a2, { i64, ptr } %a3)
declare i32 @compiler_2flower_2ecompiler_2flower_3alowering_2etemp(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2)
declare i64 @compiler_2fmir_2ePassedCount(ptr %v0, ptr %a0, { i64, [7 x i64] } %a1, i32 %a2)
@G_2ecompiler_2fmir_2eNoBlock = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\FF\FF\FF\FF" }>, align 8
declare %"compiler/mir:Call" @compiler_2fmir_3aCall_2ector(ptr %v0, { i64, [7 x i64] } %a0, %"compiler/mir:Range" %a1, %"compiler/mir:Range" %a2, %"compiler/mir:Place" %a3, i1 %a4, i32 %a5, i32 %a6, i32 %a7)
declare i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddCall(ptr %v0, ptr %a0, %"compiler/mir:Call" %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %a0, i32 %a1)
declare { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2emix(ptr %v0, ptr %a0, { i64, [4 x i64] } %a1, %"compiler/source:Span" %a2)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2ecombine(ptr %v0, ptr %a0, i32 %a1, { i64, [4 x i64] } %a2, %"compiler/source:Span" %a3)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_fe6f132f471090d8_e27fa787bcbe9484 = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eToAr_H9d0f958437b2bc29fe1d416dfb9901d7(ptr %v0, ptr %v1, ptr %a0)
declare { i32, %"compiler/lower:level" } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3alevel_3e_2ePop_3ccompiler_2flower_3alevel_3e(ptr %v0, ptr %a0)
@olang_loc_ef20f52c973b68a_c1ac21606c61e00e = external constant [0 x i8]
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3alevel_3e_2ePush_3ccompiler_2flower_3alevel_3e(ptr %v0, ptr %a0, %"compiler/lower:level" %a1)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2flower_3atryCtx_3e_2ector(ptr %v0)
declare { i32, %"compiler/lower:tryCtx" } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3atryCtx_3e_2ePop_3ccompiler_2flower_3atryCtx_3e(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_4cb37aee5d59facb_f2ca314d8498104f = external constant [0 x i8]
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3atryCtx_3e_2ePush_3ccompiler_2flower_3atryCtx_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/lower:tryCtx" %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeId_3e_2eLen_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeId_3e_2eAt_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_d999208a3f1ad790_f453fe23535d6e14 = external constant [0 x i8]
@olang_loc_25181308607ed221_2244024027539ec5 = external constant [0 x i8]
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3aloopCtx_3e_2eLen_3ccompiler_2flower_3aloopCtx_3e(ptr %v0, ptr %a0)
declare %"compiler/lower:loopCtx" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3aloopCtx_3e_2eAt_3ccompiler_2flower_3aloopCtx_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2eexitLevel(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aBlockId_3e_2ePush_3ccompiler_2fmir_3aBlockId_3e(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eVoidT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
@G_2ecompiler_2ftypes_2eNoreturnT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\11\00\00\00" }>, align 8
@olang_loc_820fb920c7f3fc9d_41590fa82c6def29 = external constant [0 x i8]
declare ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aBlock_26_3e_2eAt_Hef81d01aee8891fe569e7a3039d88992(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"compiler/typed:BlockInfo" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aBlockInfo_3e_2eA_Hdb91c1ab6f912bb6141763aa02d0b766(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_af661f8aed04ff3d_6c60afe101a0b409 = external constant [0 x i8]
@olang_loc_279896acdd8c6bde_4c10668047ad718a = external constant [0 x i8]
declare { i64, [1 x i64] } @compiler_2ftyped_2ecompiler_2ftyped_3aPlan_2ePassed(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2escopeRef(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1)
declare %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eScopeRefs(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@G_2ecompiler_2flower_2eWrongCase = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
declare %"compiler/lower:pl" @compiler_2flower_3apl_2ector(ptr %v0, { i64, [2 x i64] } %a0)
declare %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2ederef(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, %"compiler/source:Span" %a2)
declare %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2eelem(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, %"compiler/source:Span" %a2)
@olang_loc_25aa1fca937793b6_1bfa8a59c48f3aa2 = external constant [0 x i8]
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eWritable = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3cI64_3e_26_3e_2eRunFrom_3cArray_3cI64_3e_26_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_5375c9cb83678927_a7b5000221ce904b = external constant [0 x i8]
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsAny(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2erenderAny(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1, { i64, [4 x i64] } %a2, i32 %a3, i1 %a4, %"compiler/source:Span" %a5)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArrayRef(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2eword(ptr %v0, ptr %v1, ptr %a0, { i64, [1 x i64] } %a1, { i64, ptr } %a2, %"compiler/source:Span" %a3)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %a0, i32 %a1)
declare { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2edepth(ptr %v0, ptr %a0)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2einner(ptr %v0, ptr %v1, ptr %a0, %"compiler/lower:pl" %a1, i32 %a2, { i64, [1 x i64] } %a3, %"compiler/source:Span" %a4)
declare { i64, ptr } @compiler_2flower_2ecompiler_2flower_3alowering_2espell(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i1 %a2, i1 %a3, i1 %a4)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCaseNames(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeNames(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/mir:Case" @compiler_2fmir_3aCase_2ector(ptr %v0, i64 %a0, i32 %a1)
@olang_loc_7adf76f2408b5bdd_bd99dd0034e41651 = external constant [0 x i8]
@olang_loc_4257ffd395d48830_792957a97ae844 = external constant [0 x i8]
declare %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddCases(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @compiler_2flower_2ecompiler_2flower_3alowering_2estrBody(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddScope(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i32 %a3, %"compiler/source:Span" %a4, i32 %a5)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopeVarsOf(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_838d4f7d17068d91_8ef0a18bf216f57d = external constant [0 x i8]
@G_2ecompiler_2ftypes_2eResultVar = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FF\FF\FF\FF\FF\FF\FF\FF" }>, align 8
declare { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eresultScope(ptr %v0, ptr %a0)
declare { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2efitAt(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3, { i64, [1 x i64] } %a4)
declare i1 @compiler_2flower_2ecompiler_2flower_3alowering_2efits(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
declare { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2earrayCopy(ptr %v0, ptr %a0, { i64, [4 x i64] } %a1, i32 %a2, %"compiler/source:Span" %a3, { i64, [1 x i64] } %a4)
@olang_loc_ddcb411f232bf43e_ce3417657830a5fa = external constant [0 x i8]
@olang_loc_ecde87765d07009c_52dfe83edba10a08 = external constant [0 x i8]
declare i1 @compiler_2flower_2ecompiler_2flower_3alowering_2ecopiesArray(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aBlock_26_3e_2eLe_H8743fc75fe5cead0bda2da42e1adf3f3(ptr %v0, ptr %a0)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3alevel_3e_2eRunFrom_3ccompiler_2flower_3alevel_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_2e0d72be7b5575d7_214712821f524de3 = external constant [0 x i8]
declare ptr @compiler_2flower_2ecompiler_2flower_3alowering_2eunconvert(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/mir:Local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aLocal_3e_2eAt_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_4b16c1f6667ae236_8522eea6e5c16fe2 = external constant [0 x i8]
@olang_loc_d0e8b819f5194451_9afcdf330b6f59b5 = external constant [0 x i8]
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eLen_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0)
declare %"compiler/typed:Local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_a41c6179c77e6584_47cab6c73a638ed0 = external constant [0 x i8]
@olang_loc_d5691da7c866d175_fd62f9716bce2461 = external constant [0 x i8]
declare %"compiler/mir:Local" @compiler_2fmir_3aLocal_2ector(ptr %v0, i32 %a0, %"compiler/source:Span" %a1, i32 %a2, i32 %a3, { i64, [1 x i64] } %a4)
declare i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddLocal(ptr %v0, ptr %a0, %"compiler/mir:Local" %a1)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2eRun_H55075af11bca18d6ea540b66cb20a6c9(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_9d64f8741da6e7be_5ae354e0f93b83ca = external constant [0 x i8]
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aLocalId_3e_2ePush_3ccompiler_2fmir_3aLocalId_3e(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2ePus_H9afb0399fee55ed1ef4b4d03ad72cb66(ptr %v0, ptr %a0, i32 %a1)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aScopeVar_3e_2eRu_Hba7f56c70b20c8f60a4a5345f2cfd0c9(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_3c711cf1361ddabf_138c88590169ee0b = external constant [0 x i8]
@olang_loc_2bd09fabd8df32c8_ad90679d53368f6c = external constant [0 x i8]
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aVarKind_3e_2ePush_3ccompiler_2fmir_3aVarKind_3e(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1)
@G_2ecompiler_2fmir_2eNoScope = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\FF\FF\FF\FF" }>, align 8
@olang_loc_796d2b5c84af77ba_ecbdfcaab288560e = external constant [0 x i8]
@olang_loc_4394b993bdead47b_2aac5c58087818bf = external constant [0 x i8]
declare %"compiler/lower:level" @compiler_2flower_3alevel_2ector(ptr %v0, i32 %a0, i32 %a1, i32 %a2)
@olang_loc_cb00feebc120520c_2eeb4c944941e6a0 = external constant [0 x i8]
@olang_loc_d4c7911af5db15c_82661c1bde5043d8 = external constant [0 x i8]
declare { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2estorageOf(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3apl_3e_2ePush_3ccompiler_2flower_3apl_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/lower:pl" %a1)
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aPlace_2eType(ptr %v0, ptr %a0)
declare { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2efit(ptr %v0, ptr %v1, ptr %a0, { i64, [4 x i64] } %a1, ptr %a2, i32 %a3, %"compiler/source:Span" %a4)
declare { i32, %"compiler/lower:pl" } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3apl_3e_2ePop_3ccompiler_2flower_3apl_3e(ptr %v0, ptr %v1, ptr %a0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2flower_2ecompiler_2flower_3alowering_2ereleases(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i1 %a2)
declare { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eplaceStorage(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2earrayStore(ptr %v0, ptr %a0, %"compiler/mir:Place" %a1, { i64, [4 x i64] } %a2, i32 %a3, i1 %a4, %"compiler/source:Span" %a5, { i64, [1 x i64] } %a6)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3cI64_3e_26_3e_2eLen_3cArray_3cI64_3e_26_3e(ptr %v0, ptr %a0)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2eevalStmt(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
@olang_loc_54f6f20918e68778_2b66c13484f447b4 = external constant [0 x i8]
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2esuspend(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2eifStmt(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2eloop(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3)
declare i64 @compiler_2fmir_2eErrorCode(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i64 %a3)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2eassert(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2eblock(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aBlock_26_3e_2ePu_H0a6921d1f6104d156ffed3729e33edeb(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeId_3e_2ePush_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2ecleanup(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i64 %a2)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2ejoin(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2espawn(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2eyield(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
@olang_loc_b5bb8520bdd983ae_ea4f1f3c05c6deda = external constant [0 x i8]
declare i32 @compiler_2flower_2ecompiler_2flower_3alowering_2etaskType(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eRunF_H9c1707946c43ec840ffe1821bea89b1f(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_7b1a9423057e34c5_261f06cd9be6d659 = external constant [0 x i8]
@olang_loc_4d2a900631880414_3719f57230f55c88 = external constant [0 x i8]
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3apl_3e_2eLen_3ccompiler_2flower_3apl_3e(ptr %v0, ptr %a0)
declare %"compiler/lower:pl" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3apl_3e_2eAt_3ccompiler_2flower_3apl_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_77939bd7b34e0fa3_983f89b6cb89307 = external constant [0 x i8]
@olang_loc_cbdf5e9a9cabb32e_3680da0cabce8c12 = external constant [0 x i8]
declare { { i64, [4 x i64] }, i32 } @compiler_2flower_2ecompiler_2flower_3alowering_2epiece(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/source:Span" %a2)
@olang_loc_459157e65df33c7e_1dfbf278634bff4a = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArray(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
@G_2ecompiler_2ftypes_2eReadOnly = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddConst(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2erender(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1, { i64, [4 x i64] } %a2, i32 %a3, %"compiler/source:Span" %a4)
@olang_loc_3db4c7c32145727f_d6a525f06b7a698b = external constant [0 x i8]
declare i32 @compiler_2flower_2ecompiler_2flower_3aLowerer_2etext(ptr %v0, ptr %a0)
declare i64 @compiler_2flower_2ecompiler_2flower_3alowering_2eregionSite(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eregionOf(ptr %v0, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fmir_3aLocalId_3e_2_Hf0fb0e232c68e27195d0770621b0035a(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_73384406ab4916da_7af5324ba56268d6 = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v0, ptr %a0)
declare { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eread(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3)
declare { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2etake(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3)
declare { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2epromote(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3)
declare { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ecall(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3)
declare { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2emake(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3)
declare { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ecollect(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3)
declare { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprimExpr(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2, { i64, ptr } %a3, i32 %a4, %"compiler/source:Span" %a5)
declare { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eslice(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3)
declare { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2econd(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3)
declare { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2etry(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, %"compiler/source:Span" %a3)
declare { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2efnVal(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3)
@olang_loc_c62658d3c5a83b98_5474a5965e06e124 = external constant [0 x i8]
@olang_loc_d2f9ab61c66bb7bd_ba20d4faed7cd6b1 = external constant [0 x i8]
declare i32 @compiler_2flower_2ecompiler_2flower_3aLowerer_2ehelperTy(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i32 @compiler_2fmir_2eHelperType(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
@G_2ecompiler_2fmir_2eEmpty = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e__H165e1ff795edcbb725e28dde18fd1dc2(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_fc0d1138e57259ff_a3fb1151381844db = external constant [0 x i8]
declare { i32, { i64, ptr } } @std_2fos_2eMkTemp(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_81127ece44b68b70_f66d78f9cc0faa8c = external constant [0 x i8]
declare i32 @std_2fos_2eWriteFile(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_7f253c69ef622f01_ac20b514bf3261bd = external constant [0 x i8]
declare %"compiler/cond:Consts" @compiler_2fcond_3aConsts_2ector(ptr %v0)
declare void @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eBuiltins(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, i64 %a4, i64 %a5, i1 %a6, i1 %a7, i1 %a8)
declare %"compiler/fetch:Fetcher" @compiler_2ffetch_3aFetcher_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, i1 %a3, i1 %a4)
declare %"compiler/source:Names" @compiler_2fsource_3aNames_2ector(ptr %v0)
declare void @compiler_2fdiag_3aDiagnostics_2ector(ptr %out, ptr %v0, i1 %a0)
declare %"compiler/load:Loader" @compiler_2fload_3aLoader_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, { i64, ptr } %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4)
declare i64 @compiler_2fload_2ecompiler_2fload_3aLoader_2eLoad(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare %"compiler/names:Resolver" @compiler_2fnames_3aResolver_2ector(ptr %v0, ptr %v1, ptr %a0)
declare void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eResolve(ptr %v0, ptr %a0)
declare void @compiler_2fgeneric_3aProgram_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare void @compiler_2fcheck_3aChecker_2ector(ptr %out, ptr %v0, ptr %v1, ptr %a0, i1 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eCheckProgram(ptr %v0, ptr %a0)
declare %"compiler/lower:Lowerer" @compiler_2flower_3aLowerer_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %a1)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @compiler_2flower_2ecompiler_2flower_3aLowerer_2eHasCode(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %a0, i64 %a1)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_39416637e90302ea_f3cefb4d13e12826 = external constant [0 x i8]
declare i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2eHas_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eSplit(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_e1e79b1ec4507fab_255afe6ac3958787 = external constant [0 x i8]
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aFnKey_3e_2eLen_3ccompiler_2fmir_3aFnKey_3e(ptr %v0, ptr %a0)
declare { i64, [2 x i64] } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aFnKey_3e_2eAt_3ccompiler_2fmir_3aFnKey_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i1, { i64, ptr }, { i64, ptr } } @compiler_2flower_2ecompiler_2flower_3aLowerer_2eVerifiedKey(ptr %v0, ptr %v1, ptr %a0, { i64, [2 x i64] } %a1, i1 %a2)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3aGap_3e_2eRunFrom_3ccompiler_2flower_3aGap_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_4f17ddcf0f41430c_286819f90184f2f0 = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare i32 @std_2fos_2eRemoveAll(ptr %v0, { i64, ptr } %a0)
@olang_loc_4cb19ea0263fa3d_267ad794ac309681 = external constant [0 x i8]
@olang_loc_9199c0a93cf9da48_dd64f3db35db750c = external constant [0 x i8]
@olang_loc_9332d5fa6ed1089a_91d46adad91ba686 = external constant [0 x i8]
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fmir_3aBlockId_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2flower_3alevel_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
