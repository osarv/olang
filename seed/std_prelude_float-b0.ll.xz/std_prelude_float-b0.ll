; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr, i64, ptr }
%olang.home = type { ptr, ptr }
%olang.slotscope = type { %olang.scope, i64, [8 x ptr] }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
define dso_local { i64, ptr } @std_2fprelude_2ffloat_2eF64_2eFixed(ptr %v0, double %a0, i64 %a1) #0 {
entry:
  %l2 = alloca i64
  %l3 = alloca i1
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca { i64, ptr }
  %l23 = alloca %"std/prelude/text:StringBuilder"
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l46 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l48 = alloca i64
  %l49 = alloca { i64, ptr }
  %l51 = alloca { i64, ptr }
  %l52 = alloca { i64, ptr }
  %l53 = alloca i64
  %l54 = alloca { i64, ptr }
  %l55 = alloca { i64, ptr }
  %l56 = alloca { i64, ptr }
  %l57 = alloca i64
  %l58 = alloca { i64, ptr }
  %l79 = alloca i64
  %l93 = alloca i64
  %l101 = alloca i64
  %l104 = alloca i64
  %l113 = alloca i64
  %l116 = alloca i1
  %l135 = alloca i64
  %l144 = alloca i64
  %l151 = alloca i64
  %l153 = alloca i64
  %l158 = alloca i64
  %l161 = alloca { i64, ptr }
  %l162 = alloca %"std/prelude/text:StringBuilder"
  %l175 = alloca ptr
  %l176 = alloca i64
  %l177 = alloca i64
  %l183 = alloca ptr
  %l184 = alloca i64
  %l186 = alloca i64
  %l187 = alloca i64
  %l198 = alloca i64
  %l201 = alloca i64
  %l226 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = bitcast double %a0 to i64
  store i64 %t3, ptr %l2, !tbaa !65
  %t5 = load i64, ptr %l2, !tbaa !65
  %t7 = lshr i64 %t5, 63
  %t9 = icmp eq i64 %t7, 1
  store i1 %t9, ptr %l3, !tbaa !21
  %t11 = load i64, ptr %l2, !tbaa !65
  %t13 = lshr i64 %t11, 52
  %t15 = and i64 %t13, 2047
  store i64 %t15, ptr %l4, !tbaa !24
  %t18 = load i64, ptr %l2, !tbaa !65
  %t20 = and i64 %t18, 4503599627370495
  store i64 %t20, ptr %l5, !tbaa !65
  %t22 = load i64, ptr %l4, !tbaa !24
  %t24 = icmp eq i64 %t22, 2047
  br i1 %t24, label %bb1, label %bb2
bb1:
  %t26 = load i64, ptr %l5, !tbaa !65
  %t28 = icmp ne i64 %t26, 0
  br i1 %t28, label %bb3, label %bb4
bb2:
  br label %bb9
bb3:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d0, i32 0, i32 1) }, ptr %l46, !tbaa !27
  %t30 = load { i64, ptr }, ptr %l46, !tbaa !27
  store { i64, ptr } %t30, ptr %l47, !tbaa !27
  %t31 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t31, 0
  store i64 %t32, ptr %l48, !tbaa !24
  %t33 = load i64, ptr %l48, !tbaa !24
  %t34 = mul i64 %t33, 1
  %t35 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t34)
  %t36 = insertvalue { i64, ptr } undef, i64 %t33, 0
  %t37 = insertvalue { i64, ptr } %t36, ptr %t35, 1
  store { i64, ptr } %t37, ptr %l49, !tbaa !27
  %t38 = getelementptr { i64, ptr }, ptr %l49, i32 0, i32 1
  %t39 = load ptr, ptr %t38, !tbaa !27
  %t40 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !27
  %t42 = load i64, ptr %l48, !tbaa !24
  %t43 = mul i64 %t42, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t39, ptr %t41, i64 %t43, i1 false)
  %t44 = load { i64, ptr }, ptr %l49, !tbaa !27
  store { i64, ptr } %t44, ptr %l47, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t45 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } %t45, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t46 = load i1, ptr %l3, !tbaa !21
  br i1 %t46, label %bb6, label %bb7
bb6:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d1, i32 0, i32 1) }, ptr %l51, !tbaa !27
  %t48 = load { i64, ptr }, ptr %l51, !tbaa !27
  store { i64, ptr } %t48, ptr %l52, !tbaa !27
  %t49 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t50 = extractvalue { i64, ptr } %t49, 0
  store i64 %t50, ptr %l53, !tbaa !24
  %t51 = load i64, ptr %l53, !tbaa !24
  %t52 = mul i64 %t51, 1
  %t53 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t52)
  %t54 = insertvalue { i64, ptr } undef, i64 %t51, 0
  %t55 = insertvalue { i64, ptr } %t54, ptr %t53, 1
  store { i64, ptr } %t55, ptr %l54, !tbaa !27
  %t56 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t57 = load ptr, ptr %t56, !tbaa !27
  %t58 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !27
  %t60 = load i64, ptr %l53, !tbaa !24
  %t61 = mul i64 %t60, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t57, ptr %t59, i64 %t61, i1 false)
  %t62 = load { i64, ptr }, ptr %l54, !tbaa !27
  store { i64, ptr } %t62, ptr %l52, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t63 = load { i64, ptr }, ptr %l52, !tbaa !27
  store { i64, ptr } %t63, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d2, i32 0, i32 1) }, ptr %l55, !tbaa !27
  %t64 = load { i64, ptr }, ptr %l55, !tbaa !27
  store { i64, ptr } %t64, ptr %l56, !tbaa !27
  %t65 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t66 = extractvalue { i64, ptr } %t65, 0
  store i64 %t66, ptr %l57, !tbaa !24
  %t67 = load i64, ptr %l57, !tbaa !24
  %t68 = mul i64 %t67, 1
  %t69 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t68)
  %t70 = insertvalue { i64, ptr } undef, i64 %t67, 0
  %t71 = insertvalue { i64, ptr } %t70, ptr %t69, 1
  store { i64, ptr } %t71, ptr %l58, !tbaa !27
  %t72 = getelementptr { i64, ptr }, ptr %l58, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !27
  %t74 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t75 = load ptr, ptr %t74, !tbaa !27
  %t76 = load i64, ptr %l57, !tbaa !24
  %t77 = mul i64 %t76, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t73, ptr %t75, i64 %t77, i1 false)
  %t78 = load { i64, ptr }, ptr %l58, !tbaa !27
  store { i64, ptr } %t78, ptr %l56, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t79 = load { i64, ptr }, ptr %l56, !tbaa !27
  store { i64, ptr } %t79, ptr %rv
  br label %ret
bb9:
  store i64 %a1, ptr %l6, !tbaa !24
  %t82 = load i64, ptr %l6, !tbaa !24
  %t84 = icmp slt i64 %t82, 0
  br i1 %t84, label %bb10, label %bb11
bb10:
  store i64 0, ptr %l6, !tbaa !24
  br label %bb12
bb11:
  br label %bb12
bb12:
  %t86 = load i64, ptr %l5, !tbaa !65
  store i64 %t86, ptr %l7, !tbaa !65
  store i64 -1074, ptr %l8, !tbaa !24
  %t88 = load i64, ptr %l4, !tbaa !24
  %t90 = icmp ne i64 %t88, 0
  br i1 %t90, label %bb13, label %bb14
bb13:
  %t92 = load i64, ptr %l5, !tbaa !65
  %t94 = or i64 %t92, 4503599627370496
  store i64 %t94, ptr %l7, !tbaa !65
  %t96 = load i64, ptr %l4, !tbaa !24
  %t98 = sub i64 %t96, 1075
  store i64 %t98, ptr %l8, !tbaa !24
  br label %bb15
bb14:
  br label %bb15
bb15:
  %t100 = load i64, ptr %l8, !tbaa !24
  store i64 %t100, ptr %l9, !tbaa !24
  %t102 = load i64, ptr %l9, !tbaa !24
  %t104 = icmp slt i64 %t102, 0
  br i1 %t104, label %bb16, label %bb17
bb16:
  store i64 0, ptr %l9, !tbaa !24
  br label %bb18
bb17:
  br label %bb18
bb18:
  %t106 = load i64, ptr %l6, !tbaa !24
  %t108 = mul i64 %t106, 4
  %t110 = add i64 53, %t108
  %t111 = load i64, ptr %l9, !tbaa !24
  %t114 = add i64 %t110, %t111
  %t116 = sdiv i64 %t114, 32
  %t118 = add i64 %t116, 3
  store i64 %t118, ptr %l79, !tbaa !24
  %t121 = load i64, ptr %l79, !tbaa !24
  %t122 = icmp sge i64 %t121, 0
  br i1 %t122, label %bb19, label %bb20
bb19:
  %t124 = load i64, ptr %l79, !tbaa !24
  %t125 = icmp sle i64 %t124, 1152921504606846975
  br i1 %t125, label %bb21, label %bb22
bb20:
  call void @__olang_check_failed(ptr @olang_loc_b54d1cbdf5010812_d73f61472c36938e)
  unreachable
bb21:
  %t127 = load i64, ptr %l79, !tbaa !24
  %t128 = mul i64 %t127, 8
  %t129 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t128)
  %t130 = insertvalue { i64, ptr } undef, i64 %t127, 0
  %t131 = insertvalue { i64, ptr } %t130, ptr %t129, 1
  store { i64, ptr } %t131, ptr %l11, !tbaa !27
  %t133 = load i64, ptr %l7, !tbaa !65
  %t135 = and i64 %t133, 4294967295
  %t137 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t138 = load ptr, ptr %t137, !tbaa !27
  %t139 = getelementptr i64, ptr %t138, i64 0
  store i64 %t135, ptr %t139, !tbaa !85
  %t140 = load i64, ptr %l7, !tbaa !65
  %t142 = lshr i64 %t140, 32
  %t144 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t145 = load ptr, ptr %t144, !tbaa !27
  %t146 = getelementptr i64, ptr %t145, i64 1
  store i64 %t142, ptr %t146, !tbaa !85
  store i64 2, ptr %l12, !tbaa !24
  %t147 = load i64, ptr %l6, !tbaa !24
  store i64 %t147, ptr %l13, !tbaa !24
  br label %bb23
bb22:
  call void @__olang_check_failed(ptr @olang_loc_b54d1cbdf5010812_d73f61472c36938e)
  unreachable
bb23:
  %t149 = load i64, ptr %l13, !tbaa !24
  %t151 = icmp sge i64 %t149, 9
  %t153 = xor i1 %t151, true
  br i1 %t153, label %bb24, label %bb25
bb24:
  br label %bb29
bb25:
  br label %bb26
bb26:
  %t155 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t156 = load i64, ptr %l12, !tbaa !24
  %t159 = call i64 @std_2fprelude_2ffloat_2efixedMul(ptr %s0, { i64, ptr } %t155, i64 %t156, i64 1000000000)
  store i64 %t159, ptr %l93
  br label %bb27
bb27:
  %t160 = load i64, ptr %l93, !tbaa !24
  store i64 %t160, ptr %l12, !tbaa !24
  %t161 = load i64, ptr %l13, !tbaa !24
  %t164 = sub i64 %t161, 9
  store i64 %t164, ptr %l13, !tbaa !24
  br label %bb28
bb28:
  br label %bb23
bb29:
  store i64 1, ptr %l14, !tbaa !65
  store i64 0, ptr %l15, !tbaa !24
  %t166 = load i64, ptr %l13, !tbaa !24
  store i64 %t166, ptr %l16, !tbaa !24
  store i64 1, ptr %l17, !tbaa !24
  %t168 = load i64, ptr %l16, !tbaa !24
  %t169 = load i64, ptr %l15, !tbaa !24
  %t172 = icmp sgt i64 %t168, %t169
  br i1 %t172, label %bb30, label %bb31
bb30:
  %t174 = load i64, ptr %l17, !tbaa !24
  %t176 = icmp sgt i64 %t174, 0
  br i1 %t176, label %bb32, label %bb33
bb31:
  store i64 0, ptr %l101, !tbaa !24
  br label %bb35
bb32:
  %t178 = load i64, ptr %l16, !tbaa !24
  %t179 = load i64, ptr %l15, !tbaa !24
  %t182 = sub i64 %t178, %t179
  %t183 = load i64, ptr %l17, !tbaa !24
  %t186 = add i64 %t182, %t183
  %t188 = sub i64 %t186, 1
  %t189 = load i64, ptr %l17, !tbaa !24
  %t192 = sdiv i64 %t188, %t189
  store i64 %t192, ptr %l104, !tbaa !24
  br label %bb34
bb33:
  store i64 0, ptr %l104, !tbaa !24
  br label %bb34
bb34:
  %t194 = load i64, ptr %l104, !tbaa !24
  store i64 %t194, ptr %l101, !tbaa !24
  br label %bb35
bb35:
  %t195 = load i64, ptr %l101, !tbaa !24
  store i64 %t195, ptr %l18, !tbaa !24
  store i64 0, ptr %l19, !tbaa !24
  %t196 = load i64, ptr %l18, !tbaa !24
  %t197 = sub i64 %t196, 1
  store i64 %t197, ptr %l113, !tbaa !24
  %t198 = load i64, ptr %l18, !tbaa !24
  %t199 = icmp slt i64 %t198, 2147483648
  %t200 = load i64, ptr %l19, !tbaa !24
  %t201 = icmp sge i64 %t200, 0
  %t204 = and i1 %t199, %t201
  store i1 %t204, ptr %l116, !tbaa !21
  br label %bb36
bb36:
  %t205 = load i64, ptr %l19, !tbaa !24
  %t206 = load i64, ptr %l18, !tbaa !24
  %t209 = icmp slt i64 %t205, %t206
  %t211 = xor i1 %t209, true
  br i1 %t211, label %bb37, label %bb38
bb37:
  br label %bb41
bb38:
  br label %bb39
bb39:
  %t213 = load i64, ptr %l15, !tbaa !24
  %t214 = load i64, ptr %l19, !tbaa !24
  %t215 = load i64, ptr %l17, !tbaa !24
  %t218 = mul i64 %t214, %t215
  %t221 = add i64 %t213, %t218
  store i64 %t221, ptr %l20, !tbaa !24
  %t223 = load i64, ptr %l14, !tbaa !65
  %t226 = mul i64 %t223, 10
  store i64 %t226, ptr %l14, !tbaa !65
  br label %bb40
bb40:
  %t228 = load i64, ptr %l19, !tbaa !24
  %t231 = add i64 %t228, 1
  store i64 %t231, ptr %l19, !tbaa !24
  br label %bb36
bb41:
  %t233 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t234 = load i64, ptr %l12, !tbaa !24
  %t235 = load i64, ptr %l14, !tbaa !65
  %t239 = call i64 @std_2fprelude_2ffloat_2efixedMul(ptr %s0, { i64, ptr } %t233, i64 %t234, i64 %t235)
  store i64 %t239, ptr %l135
  br label %bb42
bb42:
  %t240 = load i64, ptr %l135, !tbaa !24
  store i64 %t240, ptr %l12, !tbaa !24
  %t241 = load i64, ptr %l8, !tbaa !24
  %t243 = icmp sge i64 %t241, 0
  br i1 %t243, label %bb43, label %bb44
bb43:
  %t245 = load i64, ptr %l8, !tbaa !24
  store i64 %t245, ptr %l21, !tbaa !24
  br label %bb45
bb44:
  %t247 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t248 = load i64, ptr %l12, !tbaa !24
  %t249 = load i64, ptr %l8, !tbaa !24
  %t251 = sub i64 0, %t249
  %t255 = call i64 @std_2fprelude_2ffloat_2efixedShiftRound(ptr %s0, { i64, ptr } %t247, i64 %t248, i64 %t251)
  store i64 %t255, ptr %l158
  br label %bb53
bb45:
  %t256 = load i64, ptr %l21, !tbaa !24
  %t258 = icmp sge i64 %t256, 31
  %t260 = xor i1 %t258, true
  br i1 %t260, label %bb46, label %bb47
bb46:
  br label %bb51
bb47:
  br label %bb48
bb48:
  %t262 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t263 = load i64, ptr %l12, !tbaa !24
  %t266 = call i64 @std_2fprelude_2ffloat_2efixedMul(ptr %s0, { i64, ptr } %t262, i64 %t263, i64 2147483648)
  store i64 %t266, ptr %l144
  br label %bb49
bb49:
  %t267 = load i64, ptr %l144, !tbaa !24
  store i64 %t267, ptr %l12, !tbaa !24
  %t268 = load i64, ptr %l21, !tbaa !24
  %t271 = sub i64 %t268, 31
  store i64 %t271, ptr %l21, !tbaa !24
  br label %bb50
bb50:
  br label %bb45
bb51:
  %t273 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t274 = load i64, ptr %l12, !tbaa !24
  %t275 = load i64, ptr %l21, !tbaa !24
  store i64 %t275, ptr %l151, !tbaa !65
  %t277 = load i64, ptr %l151, !tbaa !65
  %t278 = load i64, ptr %l151, !tbaa !65
  %t279 = shl i64 1, %t278
  %t283 = call i64 @std_2fprelude_2ffloat_2efixedMul(ptr %s0, { i64, ptr } %t273, i64 %t274, i64 %t279)
  store i64 %t283, ptr %l153
  br label %bb52
bb52:
  %t284 = load i64, ptr %l153, !tbaa !24
  store i64 %t284, ptr %l12, !tbaa !24
  br label %bb54
bb53:
  %t285 = load i64, ptr %l158, !tbaa !24
  store i64 %t285, ptr %l12, !tbaa !24
  br label %bb54
bb54:
  %t286 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t287 = load i64, ptr %l12, !tbaa !24
  %t290 = call { i64, ptr } @std_2fprelude_2ffloat_2efixedDecimal(ptr %s0, ptr %s0, { i64, ptr } %t286, i64 %t287)
  store { i64, ptr } %t290, ptr %l161
  br label %bb55
bb55:
  %t291 = load { i64, ptr }, ptr %l161, !tbaa !27
  store { i64, ptr } %t291, ptr %l22, !tbaa !27
  %t292 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t292, ptr %l162
  br label %bb56
bb56:
  %t293 = load %"std/prelude/text:StringBuilder", ptr %l162
  store %"std/prelude/text:StringBuilder" %t293, ptr %l23
  %t294 = load i1, ptr %l3, !tbaa !21
  br i1 %t294, label %bb57, label %bb58
bb57:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l23, i8 45)
  br label %bb59
bb58:
  br label %bb60
bb59:
  br label %bb60
bb60:
  %t297 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t299 = extractvalue { i64, ptr } %t297, 0
  %t300 = load i64, ptr %l6, !tbaa !24
  %t303 = sub i64 %t299, %t300
  store i64 %t303, ptr %l24, !tbaa !24
  %t305 = load i64, ptr %l6, !tbaa !24
  %t307 = icmp eq i64 %t305, 0
  br i1 %t307, label %bb61, label %bb62
bb61:
  %t309 = load { i64, ptr }, ptr %l22, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l23, { i64, ptr } %t309)
  br label %bb63
bb62:
  %t312 = load i64, ptr %l24, !tbaa !24
  %t314 = icmp sgt i64 %t312, 0
  br i1 %t314, label %bb64, label %bb65
bb63:
  br label %bb97
bb64:
  store ptr %l23, ptr %l175, !tbaa !29
  %t316 = load i64, ptr %l24, !tbaa !24
  store i64 %t316, ptr %l176, !tbaa !24
  %t317 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t318 = extractvalue { i64, ptr } %t317, 0
  store i64 %t318, ptr %l177, !tbaa !24
  %t319 = icmp sge i64 0, 0
  br i1 %t319, label %bb66, label %bb67
bb65:
  store %olang.scope zeroinitializer, ptr %s18
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s18, ptr %l23, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d3, i32 0, i32 1) })
  br label %bb81
bb66:
  %t322 = load i64, ptr %l176, !tbaa !24
  %t323 = icmp sle i64 0, %t322
  br i1 %t323, label %bb68, label %bb69
bb67:
  call void @__olang_check_failed(ptr @olang_loc_9154939ee93e3ee7_46d85fccfb22748b)
  unreachable
bb68:
  %t325 = load i64, ptr %l176, !tbaa !24
  %t326 = load i64, ptr %l177, !tbaa !24
  %t327 = icmp sle i64 %t325, %t326
  br i1 %t327, label %bb70, label %bb71
bb69:
  call void @__olang_check_failed(ptr @olang_loc_9154939ee93e3ee7_46d85fccfb22748b)
  unreachable
bb70:
  %t329 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t330 = load ptr, ptr %t329, !tbaa !27
  %t331 = load i64, ptr %l176, !tbaa !24
  %t332 = getelementptr i8, ptr %t330, i64 0
  %t333 = sub i64 %t331, 0
  %t334 = insertvalue { i64, ptr } undef, i64 %t333, 0
  %t335 = insertvalue { i64, ptr } %t334, ptr %t332, 1
  %t336 = load ptr, ptr %l175, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t336, { i64, ptr } %t335)
  br label %bb72
bb71:
  call void @__olang_check_failed(ptr @olang_loc_9154939ee93e3ee7_46d85fccfb22748b)
  unreachable
bb72:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l23, i8 46)
  br label %bb73
bb73:
  store ptr %l23, ptr %l183, !tbaa !29
  %t339 = load i64, ptr %l24, !tbaa !24
  store i64 %t339, ptr %l184, !tbaa !24
  %t340 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t342 = extractvalue { i64, ptr } %t340, 0
  store i64 %t342, ptr %l186, !tbaa !24
  %t343 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t344 = extractvalue { i64, ptr } %t343, 0
  store i64 %t344, ptr %l187, !tbaa !24
  %t345 = load i64, ptr %l184, !tbaa !24
  %t346 = icmp sge i64 %t345, 0
  br i1 %t346, label %bb74, label %bb75
bb74:
  %t348 = load i64, ptr %l184, !tbaa !24
  %t349 = load i64, ptr %l186, !tbaa !24
  %t350 = icmp sle i64 %t348, %t349
  br i1 %t350, label %bb76, label %bb77
bb75:
  call void @__olang_check_failed(ptr @olang_loc_ae21cbbaee55273c_45c9c102c2e73d10)
  unreachable
bb76:
  %t352 = load i64, ptr %l186, !tbaa !24
  %t353 = load i64, ptr %l187, !tbaa !24
  %t354 = icmp sle i64 %t352, %t353
  br i1 %t354, label %bb78, label %bb79
bb77:
  call void @__olang_check_failed(ptr @olang_loc_ae21cbbaee55273c_45c9c102c2e73d10)
  unreachable
bb78:
  %t356 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t357 = load ptr, ptr %t356, !tbaa !27
  %t358 = load i64, ptr %l184, !tbaa !24
  %t359 = load i64, ptr %l186, !tbaa !24
  %t360 = getelementptr i8, ptr %t357, i64 %t358
  %t361 = sub i64 %t359, %t358
  %t362 = insertvalue { i64, ptr } undef, i64 %t361, 0
  %t363 = insertvalue { i64, ptr } %t362, ptr %t360, 1
  %t364 = load ptr, ptr %l183, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t364, { i64, ptr } %t363)
  br label %bb80
bb79:
  call void @__olang_check_failed(ptr @olang_loc_ae21cbbaee55273c_45c9c102c2e73d10)
  unreachable
bb80:
  br label %bb96
bb81:
  store i64 0, ptr %l25, !tbaa !24
  %t366 = load i64, ptr %l24, !tbaa !24
  %t368 = sub i64 0, %t366
  store i64 %t368, ptr %l26, !tbaa !24
  store i64 1, ptr %l27, !tbaa !24
  %t370 = load i64, ptr %l26, !tbaa !24
  %t371 = load i64, ptr %l25, !tbaa !24
  %t374 = icmp sgt i64 %t370, %t371
  br i1 %t374, label %bb82, label %bb83
bb82:
  %t376 = load i64, ptr %l27, !tbaa !24
  %t378 = icmp sgt i64 %t376, 0
  br i1 %t378, label %bb84, label %bb85
bb83:
  store i64 0, ptr %l198, !tbaa !24
  br label %bb87
bb84:
  %t380 = load i64, ptr %l26, !tbaa !24
  %t381 = load i64, ptr %l25, !tbaa !24
  %t384 = sub i64 %t380, %t381
  %t385 = load i64, ptr %l27, !tbaa !24
  %t388 = add i64 %t384, %t385
  %t390 = sub i64 %t388, 1
  %t391 = load i64, ptr %l27, !tbaa !24
  %t394 = sdiv i64 %t390, %t391
  store i64 %t394, ptr %l201, !tbaa !24
  br label %bb86
bb85:
  store i64 0, ptr %l201, !tbaa !24
  br label %bb86
bb86:
  %t396 = load i64, ptr %l201, !tbaa !24
  store i64 %t396, ptr %l198, !tbaa !24
  br label %bb87
bb87:
  %t397 = load i64, ptr %l198, !tbaa !24
  store i64 %t397, ptr %l28, !tbaa !24
  store i64 0, ptr %l29, !tbaa !24
  br label %bb88
bb88:
  %t398 = load i64, ptr %l29, !tbaa !24
  %t399 = load i64, ptr %l28, !tbaa !24
  %t402 = icmp slt i64 %t398, %t399
  %t404 = xor i1 %t402, true
  br i1 %t404, label %bb89, label %bb90
bb89:
  br label %bb94
bb90:
  br label %bb91
bb91:
  %t406 = load i64, ptr %l25, !tbaa !24
  %t407 = load i64, ptr %l29, !tbaa !24
  %t408 = load i64, ptr %l27, !tbaa !24
  %t411 = mul i64 %t407, %t408
  %t414 = add i64 %t406, %t411
  store i64 %t414, ptr %l30, !tbaa !24
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l23, i8 48)
  br label %bb92
bb92:
  br label %bb93
bb93:
  %t417 = load i64, ptr %l29, !tbaa !24
  %t420 = add i64 %t417, 1
  store i64 %t420, ptr %l29, !tbaa !24
  br label %bb88
bb94:
  %t422 = load { i64, ptr }, ptr %l22, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l23, { i64, ptr } %t422)
  br label %bb95
bb95:
  call void @__olang_scope_close(ptr %s18)
  br label %bb96
bb96:
  br label %bb97
bb97:
  %t426 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v0, ptr %l23)
  store { i64, ptr } %t426, ptr %l226
  br label %bb98
bb98:
  call void @__olang_scope_close(ptr %s0)
  %t427 = load { i64, ptr }, ptr %l226, !tbaa !27
  store { i64, ptr } %t427, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @std_2fprelude_2ffloat_2efixedDecimal(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca %"std/prelude/text:StringBuilder"
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l36 = alloca i64
  %l39 = alloca i64
  %l48 = alloca i64
  %l51 = alloca i1
  %l67 = alloca { i64, ptr }
  %l71 = alloca { i64, ptr }
  %l84 = alloca i1
  %l85 = alloca { i64, ptr }
  %l95 = alloca i64
  %l97 = alloca { i64, ptr }
  %l98 = alloca { i64, ptr }
  %l99 = alloca i64
  %l100 = alloca { i64, ptr }
  %l101 = alloca %"std/prelude/text:StringBuilder"
  %l102 = alloca ptr
  %l103 = alloca ptr
  %l105 = alloca i64
  %l107 = alloca i64
  %l111 = alloca i64
  %l116 = alloca i64
  %l119 = alloca i64
  %l137 = alloca ptr
  %l139 = alloca i64
  %l143 = alloca i64
  %l151 = alloca i64
  %l154 = alloca i64
  %l182 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cU64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l27
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l27
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l2
  store i64 %a1, ptr %l3, !tbaa !24
  br label %bb2
bb2:
  %t5 = load i64, ptr %l3, !tbaa !24
  %t7 = icmp sgt i64 %t5, 0
  %t9 = xor i1 %t7, true
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb29
bb4:
  br label %bb5
bb5:
  store i64 0, ptr %l4, !tbaa !65
  store i64 0, ptr %l5, !tbaa !24
  %t11 = load i64, ptr %l3, !tbaa !24
  store i64 %t11, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t13 = load i64, ptr %l6, !tbaa !24
  %t14 = load i64, ptr %l5, !tbaa !24
  %t17 = icmp sgt i64 %t13, %t14
  br i1 %t17, label %bb6, label %bb7
bb6:
  %t19 = load i64, ptr %l7, !tbaa !24
  %t21 = icmp sgt i64 %t19, 0
  br i1 %t21, label %bb8, label %bb9
bb7:
  store i64 0, ptr %l36, !tbaa !24
  br label %bb11
bb8:
  %t23 = load i64, ptr %l6, !tbaa !24
  %t24 = load i64, ptr %l5, !tbaa !24
  %t27 = sub i64 %t23, %t24
  %t28 = load i64, ptr %l7, !tbaa !24
  %t31 = add i64 %t27, %t28
  %t33 = sub i64 %t31, 1
  %t34 = load i64, ptr %l7, !tbaa !24
  %t37 = sdiv i64 %t33, %t34
  store i64 %t37, ptr %l39, !tbaa !24
  br label %bb10
bb9:
  store i64 0, ptr %l39, !tbaa !24
  br label %bb10
bb10:
  %t39 = load i64, ptr %l39, !tbaa !24
  store i64 %t39, ptr %l36, !tbaa !24
  br label %bb11
bb11:
  %t40 = load i64, ptr %l36, !tbaa !24
  store i64 %t40, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  %t41 = load i64, ptr %l8, !tbaa !24
  %t42 = sub i64 %t41, 1
  store i64 %t42, ptr %l48, !tbaa !24
  %t43 = load i64, ptr %l8, !tbaa !24
  %t44 = icmp slt i64 %t43, 2147483648
  %t45 = load i64, ptr %l9, !tbaa !24
  %t46 = icmp sge i64 %t45, 0
  %t49 = and i1 %t44, %t46
  store i1 %t49, ptr %l51, !tbaa !21
  br label %bb12
bb12:
  %t50 = load i64, ptr %l9, !tbaa !24
  %t51 = load i64, ptr %l8, !tbaa !24
  %t54 = icmp slt i64 %t50, %t51
  %t56 = xor i1 %t54, true
  br i1 %t56, label %bb13, label %bb14
bb13:
  br label %bb17
bb14:
  br label %bb15
bb15:
  %t58 = load i64, ptr %l5, !tbaa !24
  %t59 = load i64, ptr %l9, !tbaa !24
  %t60 = load i64, ptr %l7, !tbaa !24
  %t63 = mul i64 %t59, %t60
  %t66 = add i64 %t58, %t63
  %t68 = load i64, ptr %l3, !tbaa !24
  %t70 = sub i64 %t68, 1
  %t74 = sub i64 %t70, %t66
  store i64 %t74, ptr %l11, !tbaa !24
  %t76 = load i64, ptr %l4, !tbaa !65
  %t78 = shl i64 %t76, 32
  %t79 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t79, ptr %l67, !tbaa !27
  %t80 = load i64, ptr %l11, !tbaa !24
  %t82 = getelementptr { i64, ptr }, ptr %l67, i32 0, i32 1
  %t83 = load ptr, ptr %t82, !tbaa !27
  %t84 = getelementptr i64, ptr %t83, i64 %t80
  %t85 = load i64, ptr %t84, !tbaa !85
  %t88 = or i64 %t78, %t85
  store i64 %t88, ptr %l12, !tbaa !65
  %t90 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t90, ptr %l71, !tbaa !27
  %t91 = load i64, ptr %l11, !tbaa !24
  %t92 = load i64, ptr %l12, !tbaa !65
  %t94 = udiv i64 %t92, 1000000000
  %t97 = getelementptr { i64, ptr }, ptr %l71, i32 0, i32 1
  %t98 = load ptr, ptr %t97, !tbaa !27
  %t99 = getelementptr i64, ptr %t98, i64 %t91
  store i64 %t94, ptr %t99, !tbaa !85
  %t100 = load i64, ptr %l12, !tbaa !65
  %t102 = urem i64 %t100, 1000000000
  store i64 %t102, ptr %l4, !tbaa !65
  br label %bb16
bb16:
  %t104 = load i64, ptr %l9, !tbaa !24
  %t107 = add i64 %t104, 1
  store i64 %t107, ptr %l9, !tbaa !24
  br label %bb12
bb17:
  %t109 = load i64, ptr %l4, !tbaa !65
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU64_3e_2ePush_3cU64_3e(ptr %s0, ptr %l2, i64 %t109)
  br label %bb18
bb18:
  br label %bb19
bb19:
  %t112 = load i64, ptr %l3, !tbaa !24
  %t114 = icmp sgt i64 %t112, 0
  br i1 %t114, label %bb20, label %bb21
bb20:
  %t116 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t116, ptr %l85, !tbaa !27
  %t117 = load i64, ptr %l3, !tbaa !24
  %t119 = sub i64 %t117, 1
  %t121 = getelementptr { i64, ptr }, ptr %l85, i32 0, i32 1
  %t122 = load ptr, ptr %t121, !tbaa !27
  %t123 = getelementptr i64, ptr %t122, i64 %t119
  %t124 = load i64, ptr %t123, !tbaa !85
  %t126 = icmp eq i64 %t124, 0
  store i1 %t126, ptr %l84, !tbaa !21
  br label %bb22
bb21:
  store i1 false, ptr %l84, !tbaa !21
  br label %bb22
bb22:
  %t128 = load i1, ptr %l84, !tbaa !21
  %t129 = xor i1 %t128, true
  br i1 %t129, label %bb23, label %bb24
bb23:
  br label %bb27
bb24:
  br label %bb25
bb25:
  %t131 = load i64, ptr %l3, !tbaa !24
  %t134 = sub i64 %t131, 1
  store i64 %t134, ptr %l3, !tbaa !24
  br label %bb26
bb26:
  br label %bb19
bb27:
  br label %bb28
bb28:
  br label %bb2
bb29:
  %t137 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU64_3e_2eLen_3cU64_3e(ptr %s0, ptr %l2)
  store i64 %t137, ptr %l95
  br label %bb30
bb30:
  %t138 = load i64, ptr %l95, !tbaa !24
  %t139 = icmp eq i64 %t138, 0
  br i1 %t139, label %bb31, label %bb32
bb31:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d4, i32 0, i32 1) }, ptr %l97, !tbaa !27
  %t141 = load { i64, ptr }, ptr %l97, !tbaa !27
  store { i64, ptr } %t141, ptr %l98, !tbaa !27
  %t142 = load { i64, ptr }, ptr %l98, !tbaa !27
  %t143 = extractvalue { i64, ptr } %t142, 0
  store i64 %t143, ptr %l99, !tbaa !24
  %t144 = load i64, ptr %l99, !tbaa !24
  %t145 = mul i64 %t144, 1
  %t146 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t145)
  %t147 = insertvalue { i64, ptr } undef, i64 %t144, 0
  %t148 = insertvalue { i64, ptr } %t147, ptr %t146, 1
  store { i64, ptr } %t148, ptr %l100, !tbaa !27
  %t149 = getelementptr { i64, ptr }, ptr %l100, i32 0, i32 1
  %t150 = load ptr, ptr %t149, !tbaa !27
  %t151 = getelementptr { i64, ptr }, ptr %l98, i32 0, i32 1
  %t152 = load ptr, ptr %t151, !tbaa !27
  %t153 = load i64, ptr %l99, !tbaa !24
  %t154 = mul i64 %t153, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t150, ptr %t152, i64 %t154, i1 false)
  %t155 = load { i64, ptr }, ptr %l100, !tbaa !27
  store { i64, ptr } %t155, ptr %l98, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t156 = load { i64, ptr }, ptr %l98, !tbaa !27
  store { i64, ptr } %t156, ptr %rv
  br label %ret
bb32:
  br label %bb33
bb33:
  %t157 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t157, ptr %l101
  br label %bb34
bb34:
  %t158 = load %"std/prelude/text:StringBuilder", ptr %l101
  store %"std/prelude/text:StringBuilder" %t158, ptr %l13
  store ptr %l13, ptr %l102, !tbaa !29
  store ptr %l2, ptr %l103, !tbaa !29
  %t160 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU64_3e_2eLen_3cU64_3e(ptr %s0, ptr %l2)
  store i64 %t160, ptr %l105
  br label %bb35
bb35:
  %t161 = load i64, ptr %l105, !tbaa !24
  %t162 = sub i64 %t161, 1
  %t163 = load ptr, ptr %l103, !tbaa !29
  %t165 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU64_3e_2eAt_3cU64_3e(ptr %s0, ptr %t163, i64 %t162)
  store i64 %t165, ptr %l107
  br label %bb36
bb36:
  %t166 = load i64, ptr %l107, !tbaa !65
  %t167 = call i64 @__olang_fmt_u64(ptr null, i64 %t166)
  %t168 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t167)
  %t169 = call i64 @__olang_fmt_u64(ptr %t168, i64 %t166)
  %t170 = insertvalue { i64, ptr } undef, i64 %t167, 0
  %t171 = insertvalue { i64, ptr } %t170, ptr %t168, 1
  %t173 = load ptr, ptr %l102, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t173, { i64, ptr } %t171)
  br label %bb37
bb37:
  store i64 0, ptr %l14, !tbaa !24
  %t176 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU64_3e_2eLen_3cU64_3e(ptr %s0, ptr %l2)
  store i64 %t176, ptr %l111
  br label %bb38
bb38:
  %t177 = load i64, ptr %l111, !tbaa !24
  %t178 = sub i64 %t177, 1
  store i64 %t178, ptr %l15, !tbaa !24
  store i64 1, ptr %l16, !tbaa !24
  %t180 = load i64, ptr %l15, !tbaa !24
  %t181 = load i64, ptr %l14, !tbaa !24
  %t184 = icmp sgt i64 %t180, %t181
  br i1 %t184, label %bb39, label %bb40
bb39:
  %t186 = load i64, ptr %l16, !tbaa !24
  %t188 = icmp sgt i64 %t186, 0
  br i1 %t188, label %bb41, label %bb42
bb40:
  store i64 0, ptr %l116, !tbaa !24
  br label %bb44
bb41:
  %t190 = load i64, ptr %l15, !tbaa !24
  %t191 = load i64, ptr %l14, !tbaa !24
  %t194 = sub i64 %t190, %t191
  %t195 = load i64, ptr %l16, !tbaa !24
  %t198 = add i64 %t194, %t195
  %t200 = sub i64 %t198, 1
  %t201 = load i64, ptr %l16, !tbaa !24
  %t204 = sdiv i64 %t200, %t201
  store i64 %t204, ptr %l119, !tbaa !24
  br label %bb43
bb42:
  store i64 0, ptr %l119, !tbaa !24
  br label %bb43
bb43:
  %t206 = load i64, ptr %l119, !tbaa !24
  store i64 %t206, ptr %l116, !tbaa !24
  br label %bb44
bb44:
  %t207 = load i64, ptr %l116, !tbaa !24
  store i64 %t207, ptr %l17, !tbaa !24
  store i64 0, ptr %l18, !tbaa !24
  br label %bb45
bb45:
  store %olang.scope zeroinitializer, ptr %s9
  %t208 = load i64, ptr %l18, !tbaa !24
  %t209 = load i64, ptr %l17, !tbaa !24
  %t212 = icmp slt i64 %t208, %t209
  %t214 = xor i1 %t212, true
  br i1 %t214, label %bb46, label %bb47
bb46:
  call void @__olang_scope_close(ptr %s9)
  br label %bb66
bb47:
  br label %bb48
bb48:
  %t216 = load i64, ptr %l14, !tbaa !24
  %t217 = load i64, ptr %l18, !tbaa !24
  %t218 = load i64, ptr %l16, !tbaa !24
  %t221 = mul i64 %t217, %t218
  %t224 = add i64 %t216, %t221
  store i64 %t224, ptr %l19, !tbaa !24
  store ptr %l2, ptr %l137, !tbaa !29
  %t227 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU64_3e_2eLen_3cU64_3e(ptr %s0, ptr %l2)
  store i64 %t227, ptr %l139
  br label %bb49
bb49:
  %t228 = load i64, ptr %l139, !tbaa !24
  %t229 = sub i64 %t228, 2
  %t230 = load i64, ptr %l19, !tbaa !24
  %t233 = sub i64 %t229, %t230
  %t234 = load ptr, ptr %l137, !tbaa !29
  %t236 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU64_3e_2eAt_3cU64_3e(ptr %s0, ptr %t234, i64 %t233)
  store i64 %t236, ptr %l143
  br label %bb50
bb50:
  %t237 = load i64, ptr %l143, !tbaa !65
  %t238 = call i64 @__olang_fmt_u64(ptr null, i64 %t237)
  %t239 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t238)
  %t240 = call i64 @__olang_fmt_u64(ptr %t239, i64 %t237)
  %t241 = insertvalue { i64, ptr } undef, i64 %t238, 0
  %t242 = insertvalue { i64, ptr } %t241, ptr %t239, 1
  store { i64, ptr } %t242, ptr %l20, !tbaa !27
  store i64 0, ptr %l21, !tbaa !24
  %t244 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t246 = extractvalue { i64, ptr } %t244, 0
  %t248 = sub i64 9, %t246
  store i64 %t248, ptr %l22, !tbaa !24
  store i64 1, ptr %l23, !tbaa !24
  %t250 = load i64, ptr %l22, !tbaa !24
  %t251 = load i64, ptr %l21, !tbaa !24
  %t254 = icmp sgt i64 %t250, %t251
  br i1 %t254, label %bb51, label %bb52
bb51:
  %t256 = load i64, ptr %l23, !tbaa !24
  %t258 = icmp sgt i64 %t256, 0
  br i1 %t258, label %bb53, label %bb54
bb52:
  store i64 0, ptr %l151, !tbaa !24
  br label %bb56
bb53:
  %t260 = load i64, ptr %l22, !tbaa !24
  %t261 = load i64, ptr %l21, !tbaa !24
  %t264 = sub i64 %t260, %t261
  %t265 = load i64, ptr %l23, !tbaa !24
  %t268 = add i64 %t264, %t265
  %t270 = sub i64 %t268, 1
  %t271 = load i64, ptr %l23, !tbaa !24
  %t274 = sdiv i64 %t270, %t271
  store i64 %t274, ptr %l154, !tbaa !24
  br label %bb55
bb54:
  store i64 0, ptr %l154, !tbaa !24
  br label %bb55
bb55:
  %t276 = load i64, ptr %l154, !tbaa !24
  store i64 %t276, ptr %l151, !tbaa !24
  br label %bb56
bb56:
  %t277 = load i64, ptr %l151, !tbaa !24
  store i64 %t277, ptr %l24, !tbaa !24
  store i64 0, ptr %l25, !tbaa !24
  br label %bb57
bb57:
  %t278 = load i64, ptr %l25, !tbaa !24
  %t279 = load i64, ptr %l24, !tbaa !24
  %t282 = icmp slt i64 %t278, %t279
  %t284 = xor i1 %t282, true
  br i1 %t284, label %bb58, label %bb59
bb58:
  br label %bb63
bb59:
  br label %bb60
bb60:
  %t286 = load i64, ptr %l21, !tbaa !24
  %t287 = load i64, ptr %l25, !tbaa !24
  %t288 = load i64, ptr %l23, !tbaa !24
  %t291 = mul i64 %t287, %t288
  %t294 = add i64 %t286, %t291
  store i64 %t294, ptr %l26, !tbaa !24
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l13, i8 48)
  br label %bb61
bb61:
  br label %bb62
bb62:
  %t297 = load i64, ptr %l25, !tbaa !24
  %t300 = add i64 %t297, 1
  store i64 %t300, ptr %l25, !tbaa !24
  br label %bb57
bb63:
  %t302 = load { i64, ptr }, ptr %l20, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s9, ptr %l13, { i64, ptr } %t302)
  br label %bb64
bb64:
  call void @__olang_scope_close(ptr %s9)
  br label %bb65
bb65:
  %t305 = load i64, ptr %l18, !tbaa !24
  %t308 = add i64 %t305, 1
  store i64 %t308, ptr %l18, !tbaa !24
  br label %bb45
bb66:
  %t311 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l13)
  store { i64, ptr } %t311, ptr %l182
  br label %bb67
bb67:
  call void @__olang_scope_close(ptr %s0)
  %t312 = load { i64, ptr }, ptr %l182, !tbaa !27
  store { i64, ptr } %t312, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @std_2fprelude_2ffloat_2efixedMul(ptr %v0, { i64, ptr } %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l15 = alloca i64
  %l18 = alloca i64
  %l27 = alloca i64
  %l30 = alloca i1
  %l40 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l59 = alloca { i64, ptr }
  %rv = alloca i64
  store { i64, ptr } %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l3, !tbaa !65
  store i64 0, ptr %l4, !tbaa !24
  %t1 = load i64, ptr %l1, !tbaa !24
  store i64 %t1, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t3 = load i64, ptr %l5, !tbaa !24
  %t4 = load i64, ptr %l4, !tbaa !24
  %t7 = icmp sgt i64 %t3, %t4
  br i1 %t7, label %bb1, label %bb2
bb1:
  %t9 = load i64, ptr %l6, !tbaa !24
  %t11 = icmp sgt i64 %t9, 0
  br i1 %t11, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l15, !tbaa !24
  br label %bb6
bb3:
  %t13 = load i64, ptr %l5, !tbaa !24
  %t14 = load i64, ptr %l4, !tbaa !24
  %t17 = sub i64 %t13, %t14
  %t18 = load i64, ptr %l6, !tbaa !24
  %t21 = add i64 %t17, %t18
  %t23 = sub i64 %t21, 1
  %t24 = load i64, ptr %l6, !tbaa !24
  %t27 = sdiv i64 %t23, %t24
  store i64 %t27, ptr %l18, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l18, !tbaa !24
  br label %bb5
bb5:
  %t29 = load i64, ptr %l18, !tbaa !24
  store i64 %t29, ptr %l15, !tbaa !24
  br label %bb6
bb6:
  %t30 = load i64, ptr %l15, !tbaa !24
  store i64 %t30, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  %t31 = load i64, ptr %l7, !tbaa !24
  %t32 = sub i64 %t31, 1
  store i64 %t32, ptr %l27, !tbaa !24
  %t33 = load i64, ptr %l7, !tbaa !24
  %t34 = icmp slt i64 %t33, 2147483648
  %t35 = load i64, ptr %l8, !tbaa !24
  %t36 = icmp sge i64 %t35, 0
  %t39 = and i1 %t34, %t36
  store i1 %t39, ptr %l30, !tbaa !21
  br label %bb7
bb7:
  %t40 = load i64, ptr %l8, !tbaa !24
  %t41 = load i64, ptr %l7, !tbaa !24
  %t44 = icmp slt i64 %t40, %t41
  %t46 = xor i1 %t44, true
  br i1 %t46, label %bb8, label %bb9
bb8:
  br label %bb12
bb9:
  br label %bb10
bb10:
  %t48 = load i64, ptr %l4, !tbaa !24
  %t49 = load i64, ptr %l8, !tbaa !24
  %t50 = load i64, ptr %l6, !tbaa !24
  %t53 = mul i64 %t49, %t50
  %t56 = add i64 %t48, %t53
  store i64 %t56, ptr %l9, !tbaa !24
  %t58 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t58, ptr %l40, !tbaa !27
  %t59 = load i64, ptr %l9, !tbaa !24
  %t61 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !27
  %t63 = getelementptr i64, ptr %t62, i64 %t59
  %t64 = load i64, ptr %t63, !tbaa !85
  %t68 = mul i64 %t64, %a2
  %t69 = load i64, ptr %l3, !tbaa !65
  %t72 = add i64 %t68, %t69
  store i64 %t72, ptr %l10, !tbaa !65
  %t74 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t74, ptr %l47, !tbaa !27
  %t75 = load i64, ptr %l9, !tbaa !24
  %t76 = load i64, ptr %l10, !tbaa !65
  %t78 = and i64 %t76, 4294967295
  %t81 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !27
  %t83 = getelementptr i64, ptr %t82, i64 %t75
  store i64 %t78, ptr %t83, !tbaa !85
  %t84 = load i64, ptr %l10, !tbaa !65
  %t86 = lshr i64 %t84, 32
  store i64 %t86, ptr %l3, !tbaa !65
  br label %bb11
bb11:
  %t88 = load i64, ptr %l8, !tbaa !24
  %t91 = add i64 %t88, 1
  store i64 %t91, ptr %l8, !tbaa !24
  br label %bb7
bb12:
  %t93 = load i64, ptr %l3, !tbaa !65
  %t95 = icmp eq i64 %t93, 0
  br i1 %t95, label %bb13, label %bb14
bb13:
  %t97 = load i64, ptr %l1, !tbaa !24
  store i64 %t97, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  %t99 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t99, ptr %l59, !tbaa !27
  %t100 = load i64, ptr %l1, !tbaa !24
  %t101 = load i64, ptr %l3, !tbaa !65
  %t104 = getelementptr { i64, ptr }, ptr %l59, i32 0, i32 1
  %t105 = load ptr, ptr %t104, !tbaa !27
  %t106 = getelementptr i64, ptr %t105, i64 %t100
  store i64 %t101, ptr %t106, !tbaa !85
  %t107 = load i64, ptr %l1, !tbaa !24
  %t109 = add i64 %t107, 1
  store i64 %t109, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @std_2fprelude_2ffloat_2efixedShiftRound(ptr %v0, { i64, ptr } %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i1
  %l6 = alloca i1
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l34 = alloca i1
  %l35 = alloca { i64, ptr }
  %l38 = alloca i64
  %l45 = alloca i1
  %l46 = alloca { i64, ptr }
  %l49 = alloca i64
  %l58 = alloca i64
  %l61 = alloca i64
  %l70 = alloca i64
  %l73 = alloca i1
  %l86 = alloca i1
  %l87 = alloca { i64, ptr }
  %l108 = alloca i64
  %l111 = alloca i64
  %l120 = alloca i64
  %l123 = alloca i1
  %l133 = alloca { i64, ptr }
  %l138 = alloca i64
  %l142 = alloca i1
  %l151 = alloca { i64, ptr }
  %l158 = alloca i64
  %l162 = alloca { i64, ptr }
  %l169 = alloca i1
  %l171 = alloca i1
  %l174 = alloca i1
  %l175 = alloca { i64, ptr }
  %l182 = alloca { i64, ptr }
  %l187 = alloca { i64, ptr }
  %l188 = alloca i64
  %l192 = alloca { i64, ptr }
  %l196 = alloca { i64, ptr }
  %l203 = alloca i1
  %l204 = alloca { i64, ptr }
  %rv = alloca i64
  store { i64, ptr } %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l2, !tbaa !24
  %t3 = sub i64 %t1, 1
  %t5 = sdiv i64 %t3, 32
  store i64 %t5, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l2, !tbaa !24
  %t9 = sub i64 %t7, 1
  %t11 = srem i64 %t9, 32
  store i64 %t11, ptr %l4, !tbaa !65
  %t14 = load i64, ptr %l3, !tbaa !24
  %t15 = load i64, ptr %l1, !tbaa !24
  %t18 = icmp slt i64 %t14, %t15
  br i1 %t18, label %bb1, label %bb2
bb1:
  %t20 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t20, ptr %l35, !tbaa !27
  %t21 = load i64, ptr %l3, !tbaa !24
  %t23 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !27
  %t25 = getelementptr i64, ptr %t24, i64 %t21
  %t26 = load i64, ptr %t25, !tbaa !85
  %t27 = load i64, ptr %l4, !tbaa !65
  store i64 %t27, ptr %l38, !tbaa !65
  %t29 = load i64, ptr %l38, !tbaa !65
  %t30 = load i64, ptr %l38, !tbaa !65
  %t31 = lshr i64 %t26, %t30
  %t33 = and i64 %t31, 1
  %t35 = icmp eq i64 %t33, 1
  store i1 %t35, ptr %l34, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l34, !tbaa !21
  br label %bb3
bb3:
  %t37 = load i1, ptr %l34, !tbaa !21
  store i1 %t37, ptr %l5, !tbaa !21
  %t38 = load i64, ptr %l3, !tbaa !24
  %t39 = load i64, ptr %l1, !tbaa !24
  %t42 = icmp slt i64 %t38, %t39
  br i1 %t42, label %bb4, label %bb5
bb4:
  %t44 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t44, ptr %l46, !tbaa !27
  %t45 = load i64, ptr %l3, !tbaa !24
  %t47 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t48 = load ptr, ptr %t47, !tbaa !27
  %t49 = getelementptr i64, ptr %t48, i64 %t45
  %t50 = load i64, ptr %t49, !tbaa !85
  %t51 = load i64, ptr %l4, !tbaa !65
  store i64 %t51, ptr %l49, !tbaa !65
  %t52 = load i64, ptr %l49, !tbaa !65
  %t53 = load i64, ptr %l49, !tbaa !65
  %t54 = shl i64 1, %t53
  %t56 = sub i64 %t54, 1
  %t59 = and i64 %t50, %t56
  %t61 = icmp ne i64 %t59, 0
  store i1 %t61, ptr %l45, !tbaa !21
  br label %bb6
bb5:
  store i1 false, ptr %l45, !tbaa !21
  br label %bb6
bb6:
  %t63 = load i1, ptr %l45, !tbaa !21
  store i1 %t63, ptr %l6, !tbaa !21
  store i64 0, ptr %l7, !tbaa !24
  %t64 = load i64, ptr %l3, !tbaa !24
  store i64 %t64, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t66 = load i64, ptr %l8, !tbaa !24
  %t67 = load i64, ptr %l7, !tbaa !24
  %t70 = icmp sgt i64 %t66, %t67
  br i1 %t70, label %bb7, label %bb8
bb7:
  %t72 = load i64, ptr %l9, !tbaa !24
  %t74 = icmp sgt i64 %t72, 0
  br i1 %t74, label %bb9, label %bb10
bb8:
  store i64 0, ptr %l58, !tbaa !24
  br label %bb12
bb9:
  %t76 = load i64, ptr %l8, !tbaa !24
  %t77 = load i64, ptr %l7, !tbaa !24
  %t80 = sub i64 %t76, %t77
  %t81 = load i64, ptr %l9, !tbaa !24
  %t84 = add i64 %t80, %t81
  %t86 = sub i64 %t84, 1
  %t87 = load i64, ptr %l9, !tbaa !24
  %t90 = sdiv i64 %t86, %t87
  store i64 %t90, ptr %l61, !tbaa !24
  br label %bb11
bb10:
  store i64 0, ptr %l61, !tbaa !24
  br label %bb11
bb11:
  %t92 = load i64, ptr %l61, !tbaa !24
  store i64 %t92, ptr %l58, !tbaa !24
  br label %bb12
bb12:
  %t93 = load i64, ptr %l58, !tbaa !24
  store i64 %t93, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  %t94 = load i64, ptr %l10, !tbaa !24
  %t95 = sub i64 %t94, 1
  store i64 %t95, ptr %l70, !tbaa !24
  %t96 = load i64, ptr %l10, !tbaa !24
  %t97 = icmp slt i64 %t96, 2147483648
  %t98 = load i64, ptr %l11, !tbaa !24
  %t99 = icmp sge i64 %t98, 0
  %t102 = and i1 %t97, %t99
  store i1 %t102, ptr %l73, !tbaa !21
  br label %bb13
bb13:
  %t103 = load i64, ptr %l11, !tbaa !24
  %t104 = load i64, ptr %l10, !tbaa !24
  %t107 = icmp slt i64 %t103, %t104
  %t109 = xor i1 %t107, true
  br i1 %t109, label %bb14, label %bb15
bb14:
  br label %bb24
bb15:
  br label %bb16
bb16:
  %t111 = load i64, ptr %l7, !tbaa !24
  %t112 = load i64, ptr %l11, !tbaa !24
  %t113 = load i64, ptr %l9, !tbaa !24
  %t116 = mul i64 %t112, %t113
  %t119 = add i64 %t111, %t116
  store i64 %t119, ptr %l12, !tbaa !24
  %t121 = load i64, ptr %l12, !tbaa !24
  %t122 = load i64, ptr %l1, !tbaa !24
  %t125 = icmp slt i64 %t121, %t122
  br i1 %t125, label %bb17, label %bb18
bb17:
  %t127 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t127, ptr %l87, !tbaa !27
  %t128 = load i64, ptr %l12, !tbaa !24
  %t130 = getelementptr { i64, ptr }, ptr %l87, i32 0, i32 1
  %t131 = load ptr, ptr %t130, !tbaa !27
  %t132 = getelementptr i64, ptr %t131, i64 %t128
  %t133 = load i64, ptr %t132, !tbaa !85
  %t135 = icmp ne i64 %t133, 0
  store i1 %t135, ptr %l86, !tbaa !21
  br label %bb19
bb18:
  store i1 false, ptr %l86, !tbaa !21
  br label %bb19
bb19:
  %t137 = load i1, ptr %l86, !tbaa !21
  br i1 %t137, label %bb20, label %bb21
bb20:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb22
bb21:
  br label %bb22
bb22:
  br label %bb23
bb23:
  %t138 = load i64, ptr %l11, !tbaa !24
  %t141 = add i64 %t138, 1
  store i64 %t141, ptr %l11, !tbaa !24
  br label %bb13
bb24:
  %t143 = load i64, ptr %l2, !tbaa !24
  %t145 = sdiv i64 %t143, 32
  store i64 %t145, ptr %l13, !tbaa !24
  %t147 = load i64, ptr %l2, !tbaa !24
  %t149 = srem i64 %t147, 32
  store i64 %t149, ptr %l14, !tbaa !65
  %t152 = load i64, ptr %l1, !tbaa !24
  %t153 = load i64, ptr %l13, !tbaa !24
  %t156 = sub i64 %t152, %t153
  store i64 %t156, ptr %l15, !tbaa !24
  %t158 = load i64, ptr %l15, !tbaa !24
  %t160 = icmp sle i64 %t158, 0
  br i1 %t160, label %bb25, label %bb26
bb25:
  store i64 0, ptr %l15, !tbaa !24
  br label %bb45
bb26:
  store i64 0, ptr %l16, !tbaa !24
  %t162 = load i64, ptr %l15, !tbaa !24
  store i64 %t162, ptr %l17, !tbaa !24
  store i64 1, ptr %l18, !tbaa !24
  %t164 = load i64, ptr %l17, !tbaa !24
  %t165 = load i64, ptr %l16, !tbaa !24
  %t168 = icmp sgt i64 %t164, %t165
  br i1 %t168, label %bb27, label %bb28
bb27:
  %t170 = load i64, ptr %l18, !tbaa !24
  %t172 = icmp sgt i64 %t170, 0
  br i1 %t172, label %bb29, label %bb30
bb28:
  store i64 0, ptr %l108, !tbaa !24
  br label %bb32
bb29:
  %t174 = load i64, ptr %l17, !tbaa !24
  %t175 = load i64, ptr %l16, !tbaa !24
  %t178 = sub i64 %t174, %t175
  %t179 = load i64, ptr %l18, !tbaa !24
  %t182 = add i64 %t178, %t179
  %t184 = sub i64 %t182, 1
  %t185 = load i64, ptr %l18, !tbaa !24
  %t188 = sdiv i64 %t184, %t185
  store i64 %t188, ptr %l111, !tbaa !24
  br label %bb31
bb30:
  store i64 0, ptr %l111, !tbaa !24
  br label %bb31
bb31:
  %t190 = load i64, ptr %l111, !tbaa !24
  store i64 %t190, ptr %l108, !tbaa !24
  br label %bb32
bb32:
  %t191 = load i64, ptr %l108, !tbaa !24
  store i64 %t191, ptr %l19, !tbaa !24
  store i64 0, ptr %l20, !tbaa !24
  %t192 = load i64, ptr %l19, !tbaa !24
  %t193 = sub i64 %t192, 1
  store i64 %t193, ptr %l120, !tbaa !24
  %t194 = load i64, ptr %l19, !tbaa !24
  %t195 = icmp slt i64 %t194, 2147483648
  %t196 = load i64, ptr %l20, !tbaa !24
  %t197 = icmp sge i64 %t196, 0
  %t200 = and i1 %t195, %t197
  store i1 %t200, ptr %l123, !tbaa !21
  br label %bb33
bb33:
  %t201 = load i64, ptr %l20, !tbaa !24
  %t202 = load i64, ptr %l19, !tbaa !24
  %t205 = icmp slt i64 %t201, %t202
  %t207 = xor i1 %t205, true
  br i1 %t207, label %bb34, label %bb35
bb34:
  br label %bb44
bb35:
  br label %bb36
bb36:
  %t209 = load i64, ptr %l16, !tbaa !24
  %t210 = load i64, ptr %l20, !tbaa !24
  %t211 = load i64, ptr %l18, !tbaa !24
  %t214 = mul i64 %t210, %t211
  %t217 = add i64 %t209, %t214
  store i64 %t217, ptr %l21, !tbaa !24
  %t219 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t219, ptr %l133, !tbaa !27
  %t220 = load i64, ptr %l21, !tbaa !24
  %t221 = load i64, ptr %l13, !tbaa !24
  %t224 = add i64 %t220, %t221
  %t226 = getelementptr { i64, ptr }, ptr %l133, i32 0, i32 1
  %t227 = load ptr, ptr %t226, !tbaa !27
  %t228 = getelementptr i64, ptr %t227, i64 %t224
  %t229 = load i64, ptr %t228, !tbaa !85
  %t230 = load i64, ptr %l14, !tbaa !65
  store i64 %t230, ptr %l138, !tbaa !65
  %t232 = load i64, ptr %l138, !tbaa !65
  %t233 = load i64, ptr %l138, !tbaa !65
  %t234 = lshr i64 %t229, %t233
  store i64 %t234, ptr %l22, !tbaa !65
  %t236 = load i64, ptr %l14, !tbaa !65
  %t238 = icmp ugt i64 %t236, 0
  br i1 %t238, label %bb37, label %bb38
bb37:
  %t240 = load i64, ptr %l21, !tbaa !24
  %t241 = load i64, ptr %l13, !tbaa !24
  %t244 = add i64 %t240, %t241
  %t246 = add i64 %t244, 1
  %t247 = load i64, ptr %l1, !tbaa !24
  %t250 = icmp slt i64 %t246, %t247
  store i1 %t250, ptr %l142, !tbaa !21
  br label %bb39
bb38:
  store i1 false, ptr %l142, !tbaa !21
  br label %bb39
bb39:
  %t252 = load i1, ptr %l142, !tbaa !21
  br i1 %t252, label %bb40, label %bb41
bb40:
  %t253 = load i64, ptr %l22, !tbaa !65
  %t255 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t255, ptr %l151, !tbaa !27
  %t256 = load i64, ptr %l21, !tbaa !24
  %t257 = load i64, ptr %l13, !tbaa !24
  %t260 = add i64 %t256, %t257
  %t262 = add i64 %t260, 1
  %t264 = getelementptr { i64, ptr }, ptr %l151, i32 0, i32 1
  %t265 = load ptr, ptr %t264, !tbaa !27
  %t266 = getelementptr i64, ptr %t265, i64 %t262
  %t267 = load i64, ptr %t266, !tbaa !85
  %t268 = load i64, ptr %l14, !tbaa !65
  %t270 = sub i64 32, %t268
  store i64 %t270, ptr %l158, !tbaa !65
  %t272 = load i64, ptr %l158, !tbaa !65
  %t273 = load i64, ptr %l158, !tbaa !65
  %t274 = shl i64 %t267, %t273
  %t276 = and i64 %t274, 4294967295
  %t279 = or i64 %t253, %t276
  store i64 %t279, ptr %l22, !tbaa !65
  br label %bb42
bb41:
  br label %bb42
bb42:
  %t281 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t281, ptr %l162, !tbaa !27
  %t282 = load i64, ptr %l21, !tbaa !24
  %t283 = load i64, ptr %l22, !tbaa !65
  %t286 = getelementptr { i64, ptr }, ptr %l162, i32 0, i32 1
  %t287 = load ptr, ptr %t286, !tbaa !27
  %t288 = getelementptr i64, ptr %t287, i64 %t282
  store i64 %t283, ptr %t288, !tbaa !85
  br label %bb43
bb43:
  %t289 = load i64, ptr %l20, !tbaa !24
  %t292 = add i64 %t289, 1
  store i64 %t292, ptr %l20, !tbaa !24
  br label %bb33
bb44:
  br label %bb45
bb45:
  %t294 = load i1, ptr %l5, !tbaa !21
  br i1 %t294, label %bb46, label %bb47
bb46:
  %t296 = load i1, ptr %l6, !tbaa !21
  br i1 %t296, label %bb48, label %bb49
bb47:
  store i1 false, ptr %l169, !tbaa !21
  br label %bb54
bb48:
  store i1 true, ptr %l171, !tbaa !21
  br label %bb53
bb49:
  %t298 = load i64, ptr %l15, !tbaa !24
  %t300 = icmp sgt i64 %t298, 0
  br i1 %t300, label %bb50, label %bb51
bb50:
  %t302 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t302, ptr %l175, !tbaa !27
  %t303 = getelementptr { i64, ptr }, ptr %l175, i32 0, i32 1
  %t304 = load ptr, ptr %t303, !tbaa !27
  %t305 = getelementptr i64, ptr %t304, i64 0
  %t306 = load i64, ptr %t305, !tbaa !85
  %t308 = and i64 %t306, 1
  %t310 = icmp eq i64 %t308, 1
  store i1 %t310, ptr %l174, !tbaa !21
  br label %bb52
bb51:
  store i1 false, ptr %l174, !tbaa !21
  br label %bb52
bb52:
  %t312 = load i1, ptr %l174, !tbaa !21
  store i1 %t312, ptr %l171, !tbaa !21
  br label %bb53
bb53:
  %t313 = load i1, ptr %l171, !tbaa !21
  store i1 %t313, ptr %l169, !tbaa !21
  br label %bb54
bb54:
  %t314 = load i1, ptr %l169, !tbaa !21
  br i1 %t314, label %bb55, label %bb56
bb55:
  store i64 0, ptr %l23, !tbaa !24
  br label %bb57
bb56:
  br label %bb66
bb57:
  %t315 = load i64, ptr %l23, !tbaa !24
  %t316 = load i64, ptr %l15, !tbaa !24
  %t319 = icmp eq i64 %t315, %t316
  br i1 %t319, label %bb58, label %bb59
bb58:
  %t321 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t321, ptr %l182, !tbaa !27
  %t322 = load i64, ptr %l15, !tbaa !24
  %t324 = getelementptr { i64, ptr }, ptr %l182, i32 0, i32 1
  %t325 = load ptr, ptr %t324, !tbaa !27
  %t326 = getelementptr i64, ptr %t325, i64 %t322
  store i64 1, ptr %t326, !tbaa !85
  %t327 = load i64, ptr %l15, !tbaa !24
  %t330 = add i64 %t327, 1
  store i64 %t330, ptr %l15, !tbaa !24
  br label %bb65
bb59:
  br label %bb60
bb60:
  %t332 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t332, ptr %l187, !tbaa !27
  %t333 = load i64, ptr %l23, !tbaa !24
  store i64 %t333, ptr %l188, !tbaa !24
  %t334 = load i64, ptr %l188, !tbaa !24
  %t335 = getelementptr { i64, ptr }, ptr %l187, i32 0, i32 1
  %t336 = load ptr, ptr %t335, !tbaa !27
  %t337 = getelementptr i64, ptr %t336, i64 %t334
  %t338 = load i64, ptr %t337, !tbaa !85
  %t341 = add i64 %t338, 1
  %t343 = load i64, ptr %l188, !tbaa !24
  %t344 = getelementptr { i64, ptr }, ptr %l187, i32 0, i32 1
  %t345 = load ptr, ptr %t344, !tbaa !27
  %t346 = getelementptr i64, ptr %t345, i64 %t343
  store i64 %t341, ptr %t346, !tbaa !85
  %t347 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t347, ptr %l192, !tbaa !27
  %t348 = load i64, ptr %l23, !tbaa !24
  %t350 = getelementptr { i64, ptr }, ptr %l192, i32 0, i32 1
  %t351 = load ptr, ptr %t350, !tbaa !27
  %t352 = getelementptr i64, ptr %t351, i64 %t348
  %t353 = load i64, ptr %t352, !tbaa !85
  %t355 = icmp ule i64 %t353, 4294967295
  br i1 %t355, label %bb61, label %bb62
bb61:
  br label %bb65
bb62:
  br label %bb63
bb63:
  %t357 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t357, ptr %l196, !tbaa !27
  %t358 = load i64, ptr %l23, !tbaa !24
  %t360 = getelementptr { i64, ptr }, ptr %l196, i32 0, i32 1
  %t361 = load ptr, ptr %t360, !tbaa !27
  %t362 = getelementptr i64, ptr %t361, i64 %t358
  store i64 0, ptr %t362, !tbaa !85
  %t363 = load i64, ptr %l23, !tbaa !24
  %t366 = add i64 %t363, 1
  store i64 %t366, ptr %l23, !tbaa !24
  br label %bb64
bb64:
  br label %bb57
bb65:
  br label %bb66
bb66:
  br label %bb67
bb67:
  %t368 = load i64, ptr %l15, !tbaa !24
  %t370 = icmp sgt i64 %t368, 0
  br i1 %t370, label %bb68, label %bb69
bb68:
  %t372 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t372, ptr %l204, !tbaa !27
  %t373 = load i64, ptr %l15, !tbaa !24
  %t375 = sub i64 %t373, 1
  %t377 = getelementptr { i64, ptr }, ptr %l204, i32 0, i32 1
  %t378 = load ptr, ptr %t377, !tbaa !27
  %t379 = getelementptr i64, ptr %t378, i64 %t375
  %t380 = load i64, ptr %t379, !tbaa !85
  %t382 = icmp eq i64 %t380, 0
  store i1 %t382, ptr %l203, !tbaa !21
  br label %bb70
bb69:
  store i1 false, ptr %l203, !tbaa !21
  br label %bb70
bb70:
  %t384 = load i1, ptr %l203, !tbaa !21
  %t385 = xor i1 %t384, true
  br i1 %t385, label %bb71, label %bb72
bb71:
  br label %bb75
bb72:
  br label %bb73
bb73:
  %t387 = load i64, ptr %l15, !tbaa !24
  %t390 = sub i64 %t387, 1
  store i64 %t390, ptr %l15, !tbaa !24
  br label %bb74
bb74:
  br label %bb67
bb75:
  %t392 = load i64, ptr %l15, !tbaa !24
  store i64 %t392, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

@.d0 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"nan" }>, align 8
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %dh = load ptr, ptr %dheadptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  %hasd = icmp ne ptr %dh, null
  %owns = or i1 %hasf, %hasd
  br i1 %owns, label %owned, label %chunks
owned:
  call void @__olang_scope_close_owned(ptr %scope)
  br label %chunks
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
@.d1 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"-inf" }>, align 8
@.d2 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"inf" }>, align 8
declare void @__olang_check_failed(ptr) cold noreturn
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
@.d3 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"0." }>, align 8
@.d4 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"0" }>, align 8
declare i64 @__olang_fmt_u64(ptr, i64)
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ; B19b: a benchmark build counts what this thread allocates - here and at the slow path's own bump, so each
  ; allocation is counted once wherever it is made (a region's and a forwarded scope's come back through here)
; @bench %bna = load i64, ptr @__olang_bench_allocs
; @bench %bna1 = add i64 %bna, 1
; @bench store i64 %bna1, ptr @__olang_bench_allocs
; @bench %bnb = load i64, ptr @__olang_bench_bytes
; @bench %bnb1 = add i64 %bnb, %size
; @bench store i64 %bnb1, ptr @__olang_bench_bytes
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
declare void @__olang_scope_close_owned(ptr) noinline
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
@olang_loc_b54d1cbdf5010812_d73f61472c36938e = external constant [0 x i8]
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %a0, i8 %a1)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_9154939ee93e3ee7_46d85fccfb22748b = external constant [0 x i8]
@olang_loc_ae21cbbaee55273c_45c9c102c2e73d10 = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cU64_3e_2ector(ptr %v0, i64 %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU64_3e_2ePush_3cU64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU64_3e_2eLen_3cU64_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU64_3e_2eAt_3cU64_3e(ptr %v0, ptr %a0, i64 %a1)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
