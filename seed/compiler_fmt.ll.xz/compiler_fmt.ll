; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/source:Source" = type { { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/source:Names" = type { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/diag:Diagnostics" = type { i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, i1, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, [3 x i64] }, { i64, ptr }, { i64, ptr }, i1 }
%"compiler/parse:Oracle" = type { %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/scan:Tokens" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/scan:Diag" = type { i32, i32, i32, i8 }
%"compiler/parse:Parser" = type { ptr, ptr, ptr, ptr, ptr, i64, i64, i32, i32, i32, i32, i1, i1, i1, i1, i64, i1, i1, i64, i1, i64, i1, i32, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/msgs:Msg" = type { i32, { i64, ptr }, { i64, ptr } }
%"std/io:Writer" = type { i32, { i64, ptr }, i64, i32 }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/fmt:formatter" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/text:StringBuilder", i1, i64, i64, { i64, ptr }, i64, i1, i64, i64, i64, i64, i64, i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1 }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/fmt:loader" = type { { i64, ptr }, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/token:Token" = type { i32, i8, i32, i32 }
define dso_local { i32, { i64, ptr } } @compiler_2ffmt_2eFileLayout(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, i1 %a3, ptr %a4) #0 {
entry:
  %l0 = alloca ptr
  %l5 = alloca %"compiler/source:Source"
  %l6 = alloca %"compiler/source:Names"
  %l7 = alloca %"compiler/diag:Diagnostics"
  %l8 = alloca %"compiler/parse:Oracle"
  %l9 = alloca i64
  %l10 = alloca %"compiler/scan:Tokens"
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca %"compiler/scan:Diag"
  %l15 = alloca %"compiler/parse:Parser"
  %l16 = alloca { i64, ptr }
  %l26 = alloca %"compiler/source:Source"
  %l27 = alloca %"compiler/source:Names"
  %l29 = alloca %"compiler/diag:Diagnostics"
  %l34 = alloca %"compiler/parse:Oracle"
  %l38 = alloca i64
  %l40 = alloca %"compiler/scan:Tokens"
  %l48 = alloca { i64, ptr }
  %l51 = alloca ptr
  %l57 = alloca { i64, [3 x i64] }
  %l58 = alloca i32
  %l60 = alloca { i64, ptr }
  %l62 = alloca { i64, ptr }
  %l64 = alloca %"compiler/msgs:Msg"
  %l65 = alloca i64
  %l74 = alloca %"compiler/parse:Parser"
  %l76 = alloca { i64, ptr }
  %l80 = alloca i1
  %l82 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l84 = alloca i64
  %l86 = alloca ptr
  %l88 = alloca { i64, ptr }
  %l95 = alloca { i64, ptr }
  %l102 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  %t42 = alloca %"compiler/diag:Diagnostics", align 8
  %t100 = alloca { i64, [3 x i64] }, align 8
  %t136 = alloca %"compiler/parse:Parser", align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/source:Source", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 1
  %t7 = extractvalue { i64, ptr } %t4, 0
  %t8 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t6, i64 %t7)
  %t9 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t10 = insertvalue { i64, ptr } %t9, ptr %t8, 1
  %t12 = extractvalue { i64, ptr } %t10, 0
  %t13 = extractvalue { i64, ptr } %t10, 1
  %t14 = mul i64 %t12, 1
  %t15 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t14)
  call void @llvm.memcpy.p0.p0.i64(ptr %t15, ptr %t13, i64 %t14, i1 false)
  %t16 = insertvalue { i64, ptr } undef, i64 %t12, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %t15, 1
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/source:Source", ptr %t18, i32 0, i32 1
  %t21 = load { i64, ptr }, ptr %t20, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t21, 1
  %t24 = extractvalue { i64, ptr } %t21, 0
  %t25 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t24)
  call void @olang_textcopy(ptr %t25, ptr %t23, i64 %t24)
  %t26 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t25, 1
  %t29 = extractvalue { i64, ptr } %t27, 0
  %t30 = extractvalue { i64, ptr } %t27, 1
  %t31 = mul i64 %t29, 1
  %t32 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t31)
  call void @llvm.memcpy.p0.p0.i64(ptr %t32, ptr %t30, i64 %t31, i1 false)
  %t33 = insertvalue { i64, ptr } undef, i64 %t29, 0
  %t34 = insertvalue { i64, ptr } %t33, ptr %t32, 1
  %t37 = call %"compiler/source:Source" @compiler_2fsource_3aSource_2ector(ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t17, { i64, ptr } %t34)
  store %"compiler/source:Source" %t37, ptr %l26
  br label %bb1
bb1:
  %t38 = load %"compiler/source:Source", ptr %l26
  store %"compiler/source:Source" %t38, ptr %l5
  %t39 = call %"compiler/source:Names" @compiler_2fsource_3aNames_2ector(ptr %s0)
  store %"compiler/source:Names" %t39, ptr %l27
  br label %bb2
bb2:
  %t40 = load %"compiler/source:Names", ptr %l27
  store %"compiler/source:Names" %t40, ptr %l6
  call void @compiler_2fdiag_3aDiagnostics_2ector(ptr %t42, ptr %s0, i1 %a3)
  call void @llvm.memmove.p0.p0.i64(ptr %l29, ptr %t42, i64 200, i1 false)
  br label %bb3
bb3:
  call void @llvm.memmove.p0.p0.i64(ptr %l7, ptr %l29, i64 200, i1 false)
  %t44 = getelementptr %"compiler/source:Source", ptr %l5, i32 0, i32 0
  %t45 = load { i64, ptr }, ptr %t44, !tbaa !27
  %t52 = call %"compiler/parse:Oracle" @compiler_2ffmt_2eOracleFor(ptr %s0, ptr %v1, ptr %v2, ptr %s0, ptr %s0, { i64, ptr } %t45, { i64, ptr } %a1, { i64, ptr } %a2, ptr %l6)
  store %"compiler/parse:Oracle" %t52, ptr %l34
  br label %bb4
bb4:
  %t53 = load %"compiler/parse:Oracle", ptr %l34
  store %"compiler/parse:Oracle" %t53, ptr %l8
  %t54 = getelementptr %"compiler/source:Source", ptr %l5, i32 0, i32 0
  %t55 = load { i64, ptr }, ptr %t54, !tbaa !27
  %t56 = getelementptr %"compiler/source:Source", ptr %l5, i32 0, i32 1
  %t57 = load { i64, ptr }, ptr %t56, !tbaa !27
  %t61 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eAddFile(ptr %s0, ptr %s0, ptr %s0, ptr %l7, { i64, ptr } %t55, { i64, ptr } %t57, i1 false)
  store i64 %t61, ptr %l38
  br label %bb5
bb5:
  %t62 = load i64, ptr %l38, !tbaa !24
  store i64 %t62, ptr %l9, !tbaa !24
  %t63 = getelementptr %"compiler/source:Source", ptr %l5, i32 0, i32 1
  %t64 = load { i64, ptr }, ptr %t63, !tbaa !27
  %t66 = call %"compiler/scan:Tokens" @compiler_2fscan_2eScan(ptr %s0, ptr %s0, { i64, ptr } %t64)
  store %"compiler/scan:Tokens" %t66, ptr %l40
  br label %bb6
bb6:
  %t67 = load %"compiler/scan:Tokens", ptr %l40
  store %"compiler/scan:Tokens" %t67, ptr %l10
  %t68 = getelementptr %"compiler/scan:Tokens", ptr %l10, i32 0, i32 3
  %t69 = load { i64, ptr }, ptr %t68, !tbaa !27
  store { i64, ptr } %t69, ptr %l11, !tbaa !27
  store i64 0, ptr %l12, !tbaa !24
  %t71 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t73 = extractvalue { i64, ptr } %t71, 0
  store i64 %t73, ptr %l13, !tbaa !24
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s4
  %t75 = load i64, ptr %l12, !tbaa !24
  %t76 = load i64, ptr %l13, !tbaa !24
  %t79 = icmp slt i64 %t75, %t76
  %t81 = xor i1 %t79, true
  br i1 %t81, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s4)
  br label %bb16
bb9:
  br label %bb10
bb10:
  %t83 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t83, ptr %l48, !tbaa !27
  %t84 = load i64, ptr %l12, !tbaa !24
  %t86 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t87 = load ptr, ptr %t86, !tbaa !27
  %t88 = getelementptr %"compiler/scan:Diag", ptr %t87, i64 %t84
  %t89 = load %"compiler/scan:Diag", ptr %t88
  store %"compiler/scan:Diag" %t89, ptr %l14
  store ptr %l7, ptr %l51, !tbaa !29
  %t91 = load i64, ptr %l9, !tbaa !24
  %t92 = getelementptr %"compiler/scan:Diag", ptr %l14, i32 0, i32 1
  %t93 = load i32, ptr %t92, !tbaa !23
  %t95 = sext i32 %t93 to i64
  %t96 = getelementptr %"compiler/scan:Diag", ptr %l14, i32 0, i32 2
  %t97 = load i32, ptr %t96, !tbaa !23
  %t99 = sext i32 %t97 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t100
  %t101 = getelementptr { i64, [3 x i64] }, ptr %t100, i32 0, i32 0
  store i64 3, ptr %t101
  %t103 = insertvalue { i64, i64, i64 } undef, i64 %t91, 0
  %t105 = insertvalue { i64, i64, i64 } %t103, i64 %t95, 1
  %t107 = insertvalue { i64, i64, i64 } %t105, i64 %t99, 2
  %t108 = getelementptr { i64, [3 x i64] }, ptr %t100, i32 0, i32 1
  store { i64, i64, i64 } %t107, ptr %t108
  %t109 = load { i64, [3 x i64] }, ptr %t100
  store { i64, [3 x i64] } %t109, ptr %l57
  store i32 47, ptr %l58
  %t110 = load %"compiler/scan:Diag", ptr %l14
  %t112 = call { i64, ptr } @compiler_2fscan_2ecompiler_2fscan_3aDiag_2eRule(ptr %s4, %"compiler/scan:Diag" %t110)
  store { i64, ptr } %t112, ptr %l60
  br label %bb11
bb11:
  %t113 = load %"compiler/scan:Diag", ptr %l14
  %t115 = call { i64, ptr } @compiler_2fscan_2ecompiler_2fscan_3aDiag_2eMessage(ptr %s4, %"compiler/scan:Diag" %t113)
  store { i64, ptr } %t115, ptr %l62
  br label %bb12
bb12:
  %t116 = load { i64, ptr }, ptr %l62, !tbaa !27
  %t117 = extractvalue { i64, ptr } %t116, 0
  %t118 = extractvalue { i64, ptr } %t116, 1
  %t119 = mul i64 %t117, 1
  %t120 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t119)
  call void @llvm.memcpy.p0.p0.i64(ptr %t120, ptr %t118, i64 %t119, i1 false)
  %t121 = insertvalue { i64, ptr } undef, i64 %t117, 0
  %t122 = insertvalue { i64, ptr } %t121, ptr %t120, 1
  %t123 = load i32, ptr %l58
  %t124 = load { i64, ptr }, ptr %l60, !tbaa !27
  %t126 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %s4, ptr %s4, ptr %s4, i32 %t123, { i64, ptr } %t124, { i64, ptr } %t122)
  store %"compiler/msgs:Msg" %t126, ptr %l64
  br label %bb13
bb13:
  %t127 = load ptr, ptr %l51, !tbaa !29
  %t128 = load { i64, [3 x i64] }, ptr %l57
  %t129 = load %"compiler/msgs:Msg", ptr %l64
  %t130 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %s0, ptr %s4, ptr %t127, { i64, [3 x i64] } %t128, %"compiler/msgs:Msg" %t129)
  store i64 %t130, ptr %l65
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s4)
  br label %bb15
bb15:
  %t131 = load i64, ptr %l12, !tbaa !24
  %t133 = add i64 %t131, 1
  store i64 %t133, ptr %l12, !tbaa !24
  br label %bb7
bb16:
  %t135 = load i64, ptr %l9, !tbaa !24
  call void @compiler_2fparse_3aParser_2ector(ptr %t136, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %l5, ptr %l10, ptr %l6, ptr %l8, ptr %l7, i64 %t135)
  call void @llvm.memmove.p0.p0.i64(ptr %l74, ptr %t136, i64 272, i1 false)
  br label %bb17
bb17:
  call void @llvm.memmove.p0.p0.i64(ptr %l15, ptr %l74, i64 272, i1 false)
  %t144 = call { i64, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eFile(ptr %s0, ptr %l15)
  store { i64, ptr } %t144, ptr %l76
  br label %bb18
bb18:
  %t145 = load { i64, ptr }, ptr %l76, !tbaa !27
  store { i64, ptr } %t145, ptr %l16, !tbaa !27
  %t146 = getelementptr %"compiler/scan:Tokens", ptr %l10, i32 0, i32 3
  %t147 = load { i64, ptr }, ptr %t146, !tbaa !27
  %t149 = extractvalue { i64, ptr } %t147, 0
  %t151 = icmp sgt i64 %t149, 0
  br i1 %t151, label %bb19, label %bb20
bb19:
  store i1 true, ptr %l80, !tbaa !21
  br label %bb23
bb20:
  %t154 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eAllSaid(ptr %s0, ptr %s0, ptr %l7)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t154, ptr %l82
  br label %bb21
bb21:
  %t155 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l82
  %t156 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t155, ptr %t156
  %t158 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fdiag_3aSaid_3e_2eLen_3ccompiler_2fdiag_3aSaid_3e(ptr %s0, ptr %t156)
  store i64 %t158, ptr %l84
  br label %bb22
bb22:
  %t159 = load i64, ptr %l84, !tbaa !24
  %t160 = icmp sgt i64 %t159, 0
  store i1 %t160, ptr %l80, !tbaa !21
  br label %bb23
bb23:
  %t162 = load i1, ptr %l80, !tbaa !21
  br i1 %t162, label %bb24, label %bb25
bb24:
  store %olang.scope zeroinitializer, ptr %s6
  store ptr %a4, ptr %l86, !tbaa !29
  %t165 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eRender(ptr %s0, ptr %s6, ptr %l7)
  store { i64, ptr } %t165, ptr %l88
  br label %bb26
bb25:
  br label %bb28
bb26:
  %t166 = load { i64, ptr }, ptr %l88, !tbaa !27
  %t167 = extractvalue { i64, ptr } %t166, 0
  %t168 = extractvalue { i64, ptr } %t166, 1
  %t169 = mul i64 %t167, 1
  %t170 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t169)
  call void @llvm.memcpy.p0.p0.i64(ptr %t170, ptr %t168, i64 %t169, i1 false)
  %t171 = insertvalue { i64, ptr } undef, i64 %t167, 0
  %t172 = insertvalue { i64, ptr } %t171, ptr %t170, 1
  %t173 = load ptr, ptr %l86, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v3, ptr %s6, ptr %t173, { i64, ptr } %t172)
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  %t176 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t176, ptr %rv
  br label %ret
bb28:
  %t177 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t178 = getelementptr %"compiler/source:Source", ptr %l5, i32 0, i32 1
  %t179 = load { i64, ptr }, ptr %t178, !tbaa !27
  %t184 = call { i64, ptr } @compiler_2funparse_2eHeldBranches(ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t177, ptr %l6, { i64, ptr } %t179, ptr %l7)
  store { i64, ptr } %t184, ptr %l95
  br label %bb29
bb29:
  %t185 = load { i64, ptr }, ptr %l95, !tbaa !27
  %t186 = getelementptr %"compiler/source:Source", ptr %l5, i32 0, i32 1
  %t187 = load { i64, ptr }, ptr %t186, !tbaa !27
  %t188 = getelementptr %"compiler/parse:Parser", ptr %l15, i32 0, i32 37
  %t189 = getelementptr %"compiler/parse:Parser", ptr %l15, i32 0, i32 38
  %t191 = getelementptr %"compiler/parse:Parser", ptr %l15, i32 0, i32 39
  %t198 = call { i64, ptr } @compiler_2ffmt_2eFormat(ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %v4, { i64, ptr } %t187, ptr %l10, ptr %t188, ptr %t189, { i64, ptr } %t185, ptr %t191)
  store { i64, ptr } %t198, ptr %l102
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s0)
  %t199 = load { i64, ptr }, ptr %l102, !tbaa !27
  %t200 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t199, 1
  store { i32, { i64, ptr } } %t200, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local i32 @compiler_2ffmt_2eFiles(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca %"std/io:Writer"
  %l4 = alloca %"std/io:Writer"
  %l5 = alloca { i64, ptr }
  %l6 = alloca i32
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca %"compiler/source:Source"
  %l12 = alloca %"std/prelude/text:StringBuilder"
  %l13 = alloca { i64, ptr }
  %l14 = alloca %"std/io:Writer"
  %l15 = alloca %"std/io:Writer"
  %l17 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l28 = alloca %"compiler/source:Source"
  %l30 = alloca %"compiler/source:Source"
  %l31 = alloca i32
  %l39 = alloca %"std/prelude/text:StringBuilder"
  %l40 = alloca { i64, ptr }
  %l41 = alloca ptr
  %l42 = alloca { i64, ptr }
  %l43 = alloca { i64, ptr }
  %l44 = alloca i1
  %l46 = alloca { i64, ptr }
  %l47 = alloca i32
  %l48 = alloca ptr
  %l50 = alloca { i64, ptr }
  %l53 = alloca i1
  %l56 = alloca i1
  %l60 = alloca i32
  %l69 = alloca i1
  %l74 = alloca i1
  %l84 = alloca i32
  %l89 = alloca i32
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %rv = alloca i32
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/io:Writer" @std_2fio_3aWriter_2ector(ptr %s0, i32 1, i64 65536)
  store %"std/io:Writer" %t1, ptr %l14
  br label %bb1
bb1:
  %t2 = load %"std/io:Writer", ptr %l14
  store %"std/io:Writer" %t2, ptr %l3
  %t3 = call %"std/io:Writer" @std_2fio_3aWriter_2ector(ptr %s0, i32 2, i64 65536)
  store %"std/io:Writer" %t3, ptr %l15
  br label %bb2
bb2:
  %t4 = load %"std/io:Writer", ptr %l15
  store %"std/io:Writer" %t4, ptr %l4
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t7 = call { i64, ptr } @compiler_2ffmt_2ePreludeTypes(ptr %v2, ptr %s0, { i64, ptr } %t5)
  store { i64, ptr } %t7, ptr %l17
  br label %bb3
bb3:
  %t8 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t8, ptr %l5, !tbaa !27
  store i32 0, ptr %l6, !tbaa !23
  store { i64, ptr } %a1, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t11 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t11, 0
  store i64 %t13, ptr %l9, !tbaa !24
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s2
  %t15 = load i64, ptr %l8, !tbaa !24
  %t16 = load i64, ptr %l9, !tbaa !24
  %t19 = icmp slt i64 %t15, %t16
  %t21 = xor i1 %t19, true
  br i1 %t21, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s2)
  br label %bb49
bb6:
  br label %bb7
bb7:
  %t23 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t23, ptr %l25, !tbaa !27
  %t24 = load i64, ptr %l8, !tbaa !24
  %t26 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = getelementptr { i64, ptr }, ptr %t27, i64 %t24
  %t29 = load { i64, ptr }, ptr %t28, !tbaa !37
  store { i64, ptr } %t29, ptr %l10, !tbaa !27
  %t31 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t33 = call { i32, %"compiler/source:Source" } @compiler_2fsource_2eRead(ptr %v1, ptr %s2, { i64, ptr } %t31)
  %t34 = extractvalue { i32, %"compiler/source:Source" } %t33, 1
  %t35 = extractvalue { i32, %"compiler/source:Source" } %t33, 0
  store i32 %t35, ptr %l31
  %t36 = icmp ne i32 %t35, 0
  br i1 %t36, label %bb9, label %ok.37
ok.37:
  store %"compiler/source:Source" %t34, ptr %l30
  br label %bb8
bb8:
  %t38 = load %"compiler/source:Source", ptr %l30
  store %"compiler/source:Source" %t38, ptr %l28
  br label %bb14
bb9:
  %t39 = load i32, ptr %l31, !tbaa !23
  %t40 = ashr i32 %t39, 16
  %t42 = icmp eq i32 %t40, 1
  br i1 %t42, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  call void @__olang_check_failed(ptr @.c0)
  unreachable
bb12:
  store %olang.scope zeroinitializer, ptr %s3
  %t44 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t45 = extractvalue { i64, ptr } { i64 7, ptr @.d1 }, 1
  %t46 = extractvalue { i64, ptr } { i64 7, ptr @.d1 }, 0
  %t48 = extractvalue { i64, ptr } %t44, 1
  %t49 = extractvalue { i64, ptr } %t44, 0
  %t50 = add i64 %t46, %t49
  %t51 = extractvalue { i64, ptr } { i64 17, ptr @.d2 }, 1
  %t52 = extractvalue { i64, ptr } { i64 17, ptr @.d2 }, 0
  %t53 = add i64 %t50, %t52
  %t54 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t53)
  call void @olang_textcopy(ptr %t54, ptr %t45, i64 %t46)
  %t55 = getelementptr i8, ptr %t54, i64 %t46
  call void @olang_textcopy(ptr %t55, ptr %t48, i64 %t49)
  %t56 = getelementptr i8, ptr %t55, i64 %t49
  call void @olang_textcopy(ptr %t56, ptr %t51, i64 %t52)
  %t57 = insertvalue { i64, ptr } undef, i64 %t53, 0
  %t58 = insertvalue { i64, ptr } %t57, ptr %t54, 1
  %t61 = extractvalue { i64, ptr } %t58, 0
  %t62 = extractvalue { i64, ptr } %t58, 1
  %t63 = mul i64 %t61, 1
  %t64 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t63)
  call void @llvm.memcpy.p0.p0.i64(ptr %t64, ptr %t62, i64 %t63, i1 false)
  %t65 = insertvalue { i64, ptr } undef, i64 %t61, 0
  %t66 = insertvalue { i64, ptr } %t65, ptr %t64, 1
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %s0, ptr %s3, ptr %l4, { i64, ptr } %t66)
  br label %bb13
bb13:
  store i32 1, ptr %l6, !tbaa !23
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  br label %bb48
bb14:
  %t69 = load %"compiler/source:Source", ptr %l28
  store %"compiler/source:Source" %t69, ptr %l11
  %t70 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s2)
  store %"std/prelude/text:StringBuilder" %t70, ptr %l39
  br label %bb15
bb15:
  %t71 = load %"std/prelude/text:StringBuilder", ptr %l39
  store %"std/prelude/text:StringBuilder" %t71, ptr %l12
  store ptr %l11, ptr %l41, !tbaa !29
  %t72 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t72, ptr %l42, !tbaa !27
  %t73 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t73, ptr %l43, !tbaa !27
  %t74 = call i1 @compiler_2fdiag_2eColorWanted()
  store i1 %t74, ptr %l44
  br label %bb16
bb16:
  %t75 = load ptr, ptr %l41, !tbaa !29
  %t76 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t77 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t78 = load i1, ptr %l44, !tbaa !21
  %t80 = call { i32, { i64, ptr } } @compiler_2ffmt_2eFileLayout(ptr %s2, ptr %v2, ptr %s0, ptr %s2, ptr %s2, ptr %t75, { i64, ptr } %t76, { i64, ptr } %t77, i1 %t78, ptr %l12)
  %t81 = extractvalue { i32, { i64, ptr } } %t80, 1
  %t82 = extractvalue { i32, { i64, ptr } } %t80, 0
  store i32 %t82, ptr %l47
  %t83 = icmp ne i32 %t82, 0
  br i1 %t83, label %bb18, label %ok.84
ok.84:
  store { i64, ptr } %t81, ptr %l46
  br label %bb17
bb17:
  %t85 = load { i64, ptr }, ptr %l46, !tbaa !27
  store { i64, ptr } %t85, ptr %l40, !tbaa !27
  br label %bb22
bb18:
  br label %bb19
bb19:
  store %olang.scope zeroinitializer, ptr %s5
  store ptr %l4, ptr %l48, !tbaa !29
  %t87 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s2, ptr %s5, ptr %l12)
  store { i64, ptr } %t87, ptr %l50
  br label %bb20
bb20:
  %t88 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t89 = load ptr, ptr %l48, !tbaa !29
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %s0, ptr %s5, ptr %t89, { i64, ptr } %t88)
  br label %bb21
bb21:
  store i32 1, ptr %l6, !tbaa !23
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s2)
  br label %bb48
bb22:
  %t91 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t91, ptr %l13, !tbaa !27
  %t92 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t94 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s2, { i64, ptr } %t92, { i64, ptr } { i64 2, ptr @.d3 })
  store i1 %t94, ptr %l53
  br label %bb23
bb23:
  %t95 = load i1, ptr %l53, !tbaa !21
  br i1 %t95, label %bb24, label %bb25
bb24:
  %t96 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t97 = getelementptr %"compiler/source:Source", ptr %l11, i32 0, i32 1
  %t98 = load { i64, ptr }, ptr %t97, !tbaa !27
  %t101 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s2, ptr %s2, { i64, ptr } %t96, { i64, ptr } %t98)
  store i1 %t101, ptr %l56
  br label %bb26
bb25:
  store %olang.scope zeroinitializer, ptr %s10
  %t102 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t104 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s10, { i64, ptr } %t102, { i64, ptr } { i64 2, ptr @.d4 })
  store i1 %t104, ptr %l69
  br label %bb37
bb26:
  %t105 = load i1, ptr %l56, !tbaa !21
  %t106 = xor i1 %t105, true
  br i1 %t106, label %bb27, label %bb28
bb27:
  %t108 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t109 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t112 = call i32 @std_2fos_2eWriteFile(ptr %v1, ptr %s2, { i64, ptr } %t108, { i64, ptr } %t109)
  store i32 %t112, ptr %l60
  %t113 = icmp ne i32 %t112, 0
  br i1 %t113, label %bb30, label %ok.114
ok.114:
  br label %bb29
bb28:
  br label %bb36
bb29:
  br label %bb35
bb30:
  %t115 = load i32, ptr %l60, !tbaa !23
  %t116 = ashr i32 %t115, 16
  %t118 = icmp eq i32 %t116, 1
  br i1 %t118, label %bb31, label %bb32
bb31:
  br label %bb33
bb32:
  call void @__olang_check_failed(ptr @.c5)
  unreachable
bb33:
  store %olang.scope zeroinitializer, ptr %s8
  %t120 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t121 = extractvalue { i64, ptr } { i64 7, ptr @.d6 }, 1
  %t122 = extractvalue { i64, ptr } { i64 7, ptr @.d6 }, 0
  %t124 = extractvalue { i64, ptr } %t120, 1
  %t125 = extractvalue { i64, ptr } %t120, 0
  %t126 = add i64 %t122, %t125
  %t127 = extractvalue { i64, ptr } { i64 20, ptr @.d7 }, 1
  %t128 = extractvalue { i64, ptr } { i64 20, ptr @.d7 }, 0
  %t129 = add i64 %t126, %t128
  %t130 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t129)
  call void @olang_textcopy(ptr %t130, ptr %t121, i64 %t122)
  %t131 = getelementptr i8, ptr %t130, i64 %t122
  call void @olang_textcopy(ptr %t131, ptr %t124, i64 %t125)
  %t132 = getelementptr i8, ptr %t131, i64 %t125
  call void @olang_textcopy(ptr %t132, ptr %t127, i64 %t128)
  %t133 = insertvalue { i64, ptr } undef, i64 %t129, 0
  %t134 = insertvalue { i64, ptr } %t133, ptr %t130, 1
  %t137 = extractvalue { i64, ptr } %t134, 0
  %t138 = extractvalue { i64, ptr } %t134, 1
  %t139 = mul i64 %t137, 1
  %t140 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t139)
  call void @llvm.memcpy.p0.p0.i64(ptr %t140, ptr %t138, i64 %t139, i1 false)
  %t141 = insertvalue { i64, ptr } undef, i64 %t137, 0
  %t142 = insertvalue { i64, ptr } %t141, ptr %t140, 1
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %s0, ptr %s8, ptr %l4, { i64, ptr } %t142)
  br label %bb34
bb34:
  store i32 1, ptr %l6, !tbaa !23
  call void @__olang_scope_close(ptr %s8)
  br label %bb35
bb35:
  br label %bb36
bb36:
  br label %bb47
bb37:
  %t145 = load i1, ptr %l69, !tbaa !21
  br i1 %t145, label %bb38, label %bb39
bb38:
  %t146 = load { i64, ptr }, ptr %l13, !tbaa !27
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %s0, ptr %s2, ptr %l3, { i64, ptr } %t146)
  br label %bb40
bb39:
  %t149 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t150 = getelementptr %"compiler/source:Source", ptr %l11, i32 0, i32 1
  %t151 = load { i64, ptr }, ptr %t150, !tbaa !27
  %t154 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s2, ptr %s2, { i64, ptr } %t149, { i64, ptr } %t151)
  store i1 %t154, ptr %l74
  br label %bb41
bb40:
  br label %bb46
bb41:
  %t155 = load i1, ptr %l74, !tbaa !21
  %t156 = xor i1 %t155, true
  br i1 %t156, label %bb42, label %bb43
bb42:
  store %olang.scope zeroinitializer, ptr %s13
  %t158 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t160 = extractvalue { i64, ptr } %t158, 1
  %t161 = extractvalue { i64, ptr } %t158, 0
  %t162 = extractvalue { i64, ptr } { i64 1, ptr @.d8 }, 1
  %t163 = extractvalue { i64, ptr } { i64 1, ptr @.d8 }, 0
  %t164 = add i64 %t161, %t163
  %t165 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t164)
  call void @olang_textcopy(ptr %t165, ptr %t160, i64 %t161)
  %t166 = getelementptr i8, ptr %t165, i64 %t161
  call void @olang_textcopy(ptr %t166, ptr %t162, i64 %t163)
  %t167 = insertvalue { i64, ptr } undef, i64 %t164, 0
  %t168 = insertvalue { i64, ptr } %t167, ptr %t165, 1
  %t171 = extractvalue { i64, ptr } %t168, 0
  %t172 = extractvalue { i64, ptr } %t168, 1
  %t173 = mul i64 %t171, 1
  %t174 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t173)
  call void @llvm.memcpy.p0.p0.i64(ptr %t174, ptr %t172, i64 %t173, i1 false)
  %t175 = insertvalue { i64, ptr } undef, i64 %t171, 0
  %t176 = insertvalue { i64, ptr } %t175, ptr %t174, 1
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %s0, ptr %s13, ptr %l3, { i64, ptr } %t176)
  br label %bb44
bb43:
  br label %bb45
bb44:
  store i32 1, ptr %l6, !tbaa !23
  call void @__olang_scope_close(ptr %s13)
  br label %bb45
bb45:
  br label %bb46
bb46:
  call void @__olang_scope_close(ptr %s10)
  br label %bb47
bb47:
  call void @__olang_scope_close(ptr %s2)
  br label %bb48
bb48:
  %t179 = load i64, ptr %l8, !tbaa !24
  %t181 = add i64 %t179, 1
  store i64 %t181, ptr %l8, !tbaa !24
  br label %bb4
bb49:
  %t184 = call i32 @std_2fio_2estd_2fio_3aWriter_2eFlush(ptr %s0, ptr %l3)
  store i32 %t184, ptr %l84
  %t185 = icmp ne i32 %t184, 0
  br i1 %t185, label %bb51, label %ok.186
ok.186:
  br label %bb50
bb50:
  br label %bb55
bb51:
  %t187 = load i32, ptr %l84, !tbaa !23
  %t188 = ashr i32 %t187, 16
  %t190 = icmp eq i32 %t188, 1
  br i1 %t190, label %bb52, label %bb53
bb52:
  br label %bb54
bb53:
  call void @__olang_check_failed(ptr @.c9)
  unreachable
bb54:
  call void @__olang_scope_close(ptr %s0)
  store i32 1, ptr %rv
  br label %ret
bb55:
  %t194 = call i32 @std_2fio_2estd_2fio_3aWriter_2eFlush(ptr %s0, ptr %l4)
  store i32 %t194, ptr %l89
  %t195 = icmp ne i32 %t194, 0
  br i1 %t195, label %bb57, label %ok.196
ok.196:
  br label %bb56
bb56:
  br label %bb61
bb57:
  %t197 = load i32, ptr %l89, !tbaa !23
  %t198 = ashr i32 %t197, 16
  %t200 = icmp eq i32 %t198, 1
  br i1 %t200, label %bb58, label %bb59
bb58:
  br label %bb60
bb59:
  call void @__olang_check_failed(ptr @.c10)
  unreachable
bb60:
  call void @__olang_scope_close(ptr %s0)
  store i32 1, ptr %rv
  br label %ret
bb61:
  %t203 = load i32, ptr %l6, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t203, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2ffmt_2eFormat(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %v6, { i64, ptr } %a0, ptr %a1, ptr %a2, ptr %a3, { i64, ptr } %a4, ptr %a5) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l6 = alloca %"compiler/fmt:formatter"
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca i64
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca i64
  %l19 = alloca ptr
  %l20 = alloca i64
  %l21 = alloca { i64, ptr }
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca { i64, ptr }
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca %"compiler/source:Span"
  %l32 = alloca %"compiler/fmt:formatter"
  %l34 = alloca { i64, ptr }
  %l37 = alloca { i64, ptr }
  %l38 = alloca i32
  %l47 = alloca { i64, ptr }
  %l50 = alloca { i64, ptr }
  %l52 = alloca { i64, ptr }
  %l62 = alloca { i64, ptr }
  %l65 = alloca { i64, ptr }
  %l66 = alloca i32
  %l75 = alloca { i64, ptr }
  %l78 = alloca { i64, ptr }
  %l86 = alloca { i64, ptr }
  %l89 = alloca { i64, ptr }
  %l90 = alloca i32
  %l99 = alloca { i64, ptr }
  %l102 = alloca { i64, ptr }
  %l104 = alloca { i64, ptr }
  %l120 = alloca { i64, ptr }
  %l123 = alloca ptr
  %l127 = alloca i64
  %l128 = alloca ptr
  %l133 = alloca i64
  %l138 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  %t6 = alloca %"compiler/fmt:formatter", align 8
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t4 = getelementptr %"compiler/scan:Tokens", ptr %a1, i32 0, i32 0
  %t5 = load { i64, ptr }, ptr %t4, !tbaa !27
  call void @compiler_2ffmt_3aformatter_2ector(ptr %t6, ptr %v0, ptr %v1, ptr %s0, { i64, ptr } %t1, { i64, ptr } %t5)
  call void @llvm.memmove.p0.p0.i64(ptr %l32, ptr %t6, i64 328, i1 false)
  br label %bb1
bb1:
  call void @llvm.memmove.p0.p0.i64(ptr %l6, ptr %l32, i64 328, i1 false)
  store ptr %a2, ptr %l7, !tbaa !29
  store i64 0, ptr %l8, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t11 = load ptr, ptr %l7, !tbaa !29
  %t12 = load i64, ptr %l8, !tbaa !24
  %t15 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %v2, ptr %t11, i64 %t12)
  %t16 = extractvalue { i32, { i64, ptr } } %t15, 1
  %t17 = extractvalue { i32, { i64, ptr } } %t15, 0
  store i32 %t17, ptr %l38
  %t18 = icmp ne i32 %t17, 0
  br i1 %t18, label %bb4, label %ok.19
ok.19:
  store { i64, ptr } %t16, ptr %l37
  br label %bb3
bb3:
  %t20 = load { i64, ptr }, ptr %l37, !tbaa !27
  store { i64, ptr } %t20, ptr %l34, !tbaa !27
  br label %bb8
bb4:
  %t21 = load i32, ptr %l38, !tbaa !23
  %t22 = ashr i32 %t21, 16
  %t24 = icmp eq i32 %t22, 1
  br i1 %t24, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  call void @__olang_check_failed(ptr @.c11)
  unreachable
bb7:
  call void @__olang_scope_close(ptr %s2)
  br label %bb16
bb8:
  %t26 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t26, ptr %l9, !tbaa !27
  %t27 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t27, 0
  store i64 %t29, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s3
  %t31 = load i64, ptr %l11, !tbaa !24
  %t32 = load i64, ptr %l10, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  %t37 = xor i1 %t35, true
  br i1 %t37, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s3)
  br label %bb14
bb11:
  br label %bb12
bb12:
  %t39 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t39, ptr %l47, !tbaa !27
  %t40 = load i64, ptr %l11, !tbaa !24
  %t42 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = getelementptr i64, ptr %t43, i64 %t40
  %t45 = load i64, ptr %t44, !tbaa !34
  store i64 %t45, ptr %l12, !tbaa !24
  %t47 = getelementptr %"compiler/fmt:formatter", ptr %l6, i32 0, i32 2
  %t48 = load { i64, ptr }, ptr %t47, !tbaa !27
  store { i64, ptr } %t48, ptr %l50, !tbaa !27
  %t49 = load i64, ptr %l12, !tbaa !24
  %t50 = getelementptr %"compiler/fmt:formatter", ptr %l6, i32 0, i32 2
  %t51 = load { i64, ptr }, ptr %t50, !tbaa !27
  store { i64, ptr } %t51, ptr %l52, !tbaa !27
  %t52 = load i64, ptr %l12, !tbaa !24
  %t54 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !27
  %t56 = getelementptr i64, ptr %t55, i64 %t52
  %t57 = load i64, ptr %t56, !tbaa !34
  %t59 = add i64 %t57, 1
  %t62 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !27
  %t64 = getelementptr i64, ptr %t63, i64 %t49
  store i64 %t59, ptr %t64, !tbaa !34
  call void @__olang_scope_close(ptr %s3)
  br label %bb13
bb13:
  %t65 = load i64, ptr %l11, !tbaa !24
  %t67 = add i64 %t65, 1
  store i64 %t67, ptr %l11, !tbaa !24
  br label %bb9
bb14:
  %t69 = load i64, ptr %l8, !tbaa !24
  %t70 = load i64, ptr %l10, !tbaa !24
  %t73 = add i64 %t69, %t70
  store i64 %t73, ptr %l8, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb15
bb15:
  br label %bb2
bb16:
  store ptr %a5, ptr %l13, !tbaa !29
  store i64 0, ptr %l14, !tbaa !24
  br label %bb17
bb17:
  store %olang.scope zeroinitializer, ptr %s6
  %t77 = load ptr, ptr %l13, !tbaa !29
  %t78 = load i64, ptr %l14, !tbaa !24
  %t81 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %v5, ptr %t77, i64 %t78)
  %t82 = extractvalue { i32, { i64, ptr } } %t81, 1
  %t83 = extractvalue { i32, { i64, ptr } } %t81, 0
  store i32 %t83, ptr %l66
  %t84 = icmp ne i32 %t83, 0
  br i1 %t84, label %bb19, label %ok.85
ok.85:
  store { i64, ptr } %t82, ptr %l65
  br label %bb18
bb18:
  %t86 = load { i64, ptr }, ptr %l65, !tbaa !27
  store { i64, ptr } %t86, ptr %l62, !tbaa !27
  br label %bb23
bb19:
  %t87 = load i32, ptr %l66, !tbaa !23
  %t88 = ashr i32 %t87, 16
  %t90 = icmp eq i32 %t88, 1
  br i1 %t90, label %bb20, label %bb21
bb20:
  br label %bb22
bb21:
  call void @__olang_check_failed(ptr @.c12)
  unreachable
bb22:
  call void @__olang_scope_close(ptr %s6)
  br label %bb31
bb23:
  %t92 = load { i64, ptr }, ptr %l62, !tbaa !27
  store { i64, ptr } %t92, ptr %l15, !tbaa !27
  %t93 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t95 = extractvalue { i64, ptr } %t93, 0
  store i64 %t95, ptr %l16, !tbaa !24
  store i64 0, ptr %l17, !tbaa !24
  br label %bb24
bb24:
  store %olang.scope zeroinitializer, ptr %s7
  %t97 = load i64, ptr %l17, !tbaa !24
  %t98 = load i64, ptr %l16, !tbaa !24
  %t101 = icmp slt i64 %t97, %t98
  %t103 = xor i1 %t101, true
  br i1 %t103, label %bb25, label %bb26
bb25:
  call void @__olang_scope_close(ptr %s7)
  br label %bb29
bb26:
  br label %bb27
bb27:
  %t105 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t105, ptr %l75, !tbaa !27
  %t106 = load i64, ptr %l17, !tbaa !24
  %t108 = getelementptr { i64, ptr }, ptr %l75, i32 0, i32 1
  %t109 = load ptr, ptr %t108, !tbaa !27
  %t110 = getelementptr i64, ptr %t109, i64 %t106
  %t111 = load i64, ptr %t110, !tbaa !34
  %t113 = getelementptr %"compiler/fmt:formatter", ptr %l6, i32 0, i32 3
  %t114 = load { i64, ptr }, ptr %t113, !tbaa !27
  store { i64, ptr } %t114, ptr %l78, !tbaa !27
  %t117 = getelementptr { i64, ptr }, ptr %l78, i32 0, i32 1
  %t118 = load ptr, ptr %t117, !tbaa !27
  %t119 = getelementptr i1, ptr %t118, i64 %t111
  store i1 true, ptr %t119, !tbaa !31
  call void @__olang_scope_close(ptr %s7)
  br label %bb28
bb28:
  %t120 = load i64, ptr %l17, !tbaa !24
  %t122 = add i64 %t120, 1
  store i64 %t122, ptr %l17, !tbaa !24
  br label %bb24
bb29:
  %t124 = load i64, ptr %l14, !tbaa !24
  %t125 = load i64, ptr %l16, !tbaa !24
  %t128 = add i64 %t124, %t125
  store i64 %t128, ptr %l14, !tbaa !24
  call void @__olang_scope_close(ptr %s6)
  br label %bb30
bb30:
  br label %bb17
bb31:
  store ptr %a3, ptr %l19, !tbaa !29
  store i64 0, ptr %l20, !tbaa !24
  br label %bb32
bb32:
  store %olang.scope zeroinitializer, ptr %s10
  %t132 = load ptr, ptr %l19, !tbaa !29
  %t133 = load i64, ptr %l20, !tbaa !24
  %t136 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %v3, ptr %t132, i64 %t133)
  %t137 = extractvalue { i32, { i64, ptr } } %t136, 1
  %t138 = extractvalue { i32, { i64, ptr } } %t136, 0
  store i32 %t138, ptr %l90
  %t139 = icmp ne i32 %t138, 0
  br i1 %t139, label %bb34, label %ok.140
ok.140:
  store { i64, ptr } %t137, ptr %l89
  br label %bb33
bb33:
  %t141 = load { i64, ptr }, ptr %l89, !tbaa !27
  store { i64, ptr } %t141, ptr %l86, !tbaa !27
  br label %bb38
bb34:
  %t142 = load i32, ptr %l90, !tbaa !23
  %t143 = ashr i32 %t142, 16
  %t145 = icmp eq i32 %t143, 1
  br i1 %t145, label %bb35, label %bb36
bb35:
  br label %bb37
bb36:
  call void @__olang_check_failed(ptr @.c13)
  unreachable
bb37:
  call void @__olang_scope_close(ptr %s10)
  br label %bb46
bb38:
  %t147 = load { i64, ptr }, ptr %l86, !tbaa !27
  store { i64, ptr } %t147, ptr %l21, !tbaa !27
  %t148 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t150 = extractvalue { i64, ptr } %t148, 0
  store i64 %t150, ptr %l22, !tbaa !24
  store i64 0, ptr %l23, !tbaa !24
  br label %bb39
bb39:
  store %olang.scope zeroinitializer, ptr %s11
  %t152 = load i64, ptr %l23, !tbaa !24
  %t153 = load i64, ptr %l22, !tbaa !24
  %t156 = icmp slt i64 %t152, %t153
  %t158 = xor i1 %t156, true
  br i1 %t158, label %bb40, label %bb41
bb40:
  call void @__olang_scope_close(ptr %s11)
  br label %bb44
bb41:
  br label %bb42
bb42:
  %t160 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t160, ptr %l99, !tbaa !27
  %t161 = load i64, ptr %l23, !tbaa !24
  %t163 = getelementptr { i64, ptr }, ptr %l99, i32 0, i32 1
  %t164 = load ptr, ptr %t163, !tbaa !27
  %t165 = getelementptr i64, ptr %t164, i64 %t161
  %t166 = load i64, ptr %t165, !tbaa !34
  store i64 %t166, ptr %l24, !tbaa !24
  %t168 = getelementptr %"compiler/fmt:formatter", ptr %l6, i32 0, i32 4
  %t169 = load { i64, ptr }, ptr %t168, !tbaa !27
  store { i64, ptr } %t169, ptr %l102, !tbaa !27
  %t170 = load i64, ptr %l24, !tbaa !24
  %t171 = getelementptr %"compiler/fmt:formatter", ptr %l6, i32 0, i32 4
  %t172 = load { i64, ptr }, ptr %t171, !tbaa !27
  store { i64, ptr } %t172, ptr %l104, !tbaa !27
  %t173 = load i64, ptr %l24, !tbaa !24
  %t175 = getelementptr { i64, ptr }, ptr %l104, i32 0, i32 1
  %t176 = load ptr, ptr %t175, !tbaa !27
  %t177 = getelementptr i64, ptr %t176, i64 %t173
  %t178 = load i64, ptr %t177, !tbaa !34
  %t180 = add i64 %t178, 1
  %t183 = getelementptr { i64, ptr }, ptr %l102, i32 0, i32 1
  %t184 = load ptr, ptr %t183, !tbaa !27
  %t185 = getelementptr i64, ptr %t184, i64 %t170
  store i64 %t180, ptr %t185, !tbaa !34
  call void @__olang_scope_close(ptr %s11)
  br label %bb43
bb43:
  %t186 = load i64, ptr %l23, !tbaa !24
  %t188 = add i64 %t186, 1
  store i64 %t188, ptr %l23, !tbaa !24
  br label %bb39
bb44:
  %t190 = load i64, ptr %l20, !tbaa !24
  %t191 = load i64, ptr %l22, !tbaa !24
  %t194 = add i64 %t190, %t191
  store i64 %t194, ptr %l20, !tbaa !24
  call void @__olang_scope_close(ptr %s10)
  br label %bb45
bb45:
  br label %bb32
bb46:
  store { i64, ptr } %a4, ptr %l25, !tbaa !27
  store i64 0, ptr %l26, !tbaa !24
  %t198 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t200 = extractvalue { i64, ptr } %t198, 0
  store i64 %t200, ptr %l27, !tbaa !24
  br label %bb47
bb47:
  store %olang.scope zeroinitializer, ptr %s14
  %t202 = load i64, ptr %l26, !tbaa !24
  %t203 = load i64, ptr %l27, !tbaa !24
  %t206 = icmp slt i64 %t202, %t203
  %t208 = xor i1 %t206, true
  br i1 %t208, label %bb48, label %bb49
bb48:
  call void @__olang_scope_close(ptr %s14)
  br label %bb56
bb49:
  br label %bb50
bb50:
  %t210 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t210, ptr %l120, !tbaa !27
  %t211 = load i64, ptr %l26, !tbaa !24
  %t213 = getelementptr { i64, ptr }, ptr %l120, i32 0, i32 1
  %t214 = load ptr, ptr %t213, !tbaa !27
  %t215 = getelementptr %"compiler/source:Span", ptr %t214, i64 %t211
  %t216 = load %"compiler/source:Span", ptr %t215
  store %"compiler/source:Span" %t216, ptr %l28
  %t218 = getelementptr %"compiler/fmt:formatter", ptr %l6, i32 0, i32 31
  store ptr %t218, ptr %l123, !tbaa !29
  %t219 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t220 = getelementptr %"compiler/source:Span", ptr %l28, i32 0, i32 0
  %t221 = load i32, ptr %t220, !tbaa !23
  %t223 = sext i32 %t221 to i64
  %t226 = call i64 @compiler_2ffmt_2elineStartOf(ptr %v0, { i64, ptr } %t219, i64 %t223)
  store i64 %t226, ptr %l127
  br label %bb51
bb51:
  %t227 = load ptr, ptr %l123, !tbaa !29
  %t228 = load i64, ptr %l127, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %t227, i64 %t228)
  br label %bb52
bb52:
  %t229 = getelementptr %"compiler/fmt:formatter", ptr %l6, i32 0, i32 32
  store ptr %t229, ptr %l128, !tbaa !29
  %t230 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t231 = getelementptr %"compiler/source:Span", ptr %l28, i32 0, i32 1
  %t232 = load i32, ptr %t231, !tbaa !23
  %t234 = sext i32 %t232 to i64
  %t236 = sub i64 %t234, 1
  %t239 = call i64 @compiler_2ffmt_2elineEndOf(ptr %v0, { i64, ptr } %t230, i64 %t236)
  store i64 %t239, ptr %l133
  br label %bb53
bb53:
  %t240 = load ptr, ptr %l128, !tbaa !29
  %t241 = load i64, ptr %l133, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %t240, i64 %t241)
  br label %bb54
bb54:
  call void @__olang_scope_close(ptr %s14)
  br label %bb55
bb55:
  %t242 = load i64, ptr %l26, !tbaa !24
  %t244 = add i64 %t242, 1
  store i64 %t244, ptr %l26, !tbaa !24
  br label %bb47
bb56:
  call void @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2erun(ptr %s0, ptr %l6)
  br label %bb57
bb57:
  %t248 = call { i64, ptr } @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2ewrite(ptr %s0, ptr %v6, ptr %l6)
  store { i64, ptr } %t248, ptr %l138
  br label %bb58
bb58:
  call void @__olang_scope_close(ptr %s0)
  %t249 = load { i64, ptr }, ptr %l138, !tbaa !27
  store { i64, ptr } %t249, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"compiler/parse:Oracle" @compiler_2ffmt_2eOracleFor(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, ptr %a3) #0 {
entry:
  %l4 = alloca %"compiler/fmt:loader"
  %l5 = alloca i64
  %lp6 = alloca ptr
  %l8 = alloca %"compiler/fmt:loader"
  %l11 = alloca i64
  %l12 = alloca %"compiler/parse:Oracle"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/parse:Oracle"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = call %"compiler/fmt:loader" @compiler_2ffmt_3aloader_2ector(ptr %v1, ptr %s0, { i64, ptr } %a1)
  store %"compiler/fmt:loader" %t3, ptr %l8
  br label %bb1
bb1:
  %t4 = load %"compiler/fmt:loader", ptr %l8
  store %"compiler/fmt:loader" %t4, ptr %l4
  %t8 = call i64 @compiler_2ffmt_2ecompiler_2ffmt_3aloader_2eload(ptr %s0, ptr %v0, ptr %l4, { i64, ptr } %a0)
  store i64 %t8, ptr %l11
  br label %bb2
bb2:
  %t9 = load i64, ptr %l11, !tbaa !24
  store i64 %t9, ptr %l5, !tbaa !24
  %t10 = call %"compiler/parse:Oracle" @compiler_2fparse_3aOracle_2ector(ptr %v4)
  store %"compiler/parse:Oracle" %t10, ptr %l12
  br label %bb3
bb3:
  %t11 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 32, i64 8)
  store ptr %t11, ptr %lp6
  %t12 = load %"compiler/parse:Oracle", ptr %l12
  %t13 = load ptr, ptr %lp6
  store %"compiler/parse:Oracle" %t12, ptr %t13
  %t14 = load i64, ptr %l5, !tbaa !24
  %t16 = icmp sge i64 %t14, 0
  br i1 %t16, label %bb4, label %bb5
bb4:
  %t18 = load ptr, ptr %lp6
  %t20 = load i64, ptr %l5, !tbaa !24
  call void @compiler_2ffmt_2ecompiler_2ffmt_3aloader_2eoracle(ptr %s0, ptr %v4, ptr %v3, ptr %v2, ptr %l4, ptr %t18, ptr %a3, i64 %t20, { i64, ptr } %a2)
  br label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb7
bb7:
  %t27 = load ptr, ptr %lp6
  %t28 = load %"compiler/parse:Oracle", ptr %t27
  call void @__olang_scope_close(ptr %s0)
  store %"compiler/parse:Oracle" %t28, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/parse:Oracle", ptr %rv
  ret %"compiler/parse:Oracle" %rr
}

define dso_local { i64, ptr } @compiler_2ffmt_2ePreludeTypes(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca %"compiler/fmt:loader"
  %l3 = alloca %"compiler/fmt:loader"
  %l5 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = call %"compiler/fmt:loader" @compiler_2ffmt_3aloader_2ector(ptr %v0, ptr %s0, { i64, ptr } %a0)
  store %"compiler/fmt:loader" %t3, ptr %l3
  br label %bb1
bb1:
  %t4 = load %"compiler/fmt:loader", ptr %l3
  store %"compiler/fmt:loader" %t4, ptr %l1
  %t6 = call { i64, ptr } @compiler_2ffmt_2ecompiler_2ffmt_3aloader_2eprelude(ptr %s0, ptr %v1, ptr %l1)
  store { i64, ptr } %t6, ptr %l5
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  %t7 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t7, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2easWritten(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l3 = alloca { i64, ptr }
  %l7 = alloca i1
  %l8 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/fmt:formatter", ptr %a0, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l3, !tbaa !27
  %t7 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t8 = load ptr, ptr %t7, !tbaa !27
  %t9 = getelementptr %"compiler/token:Token", ptr %t8, i64 %a1
  %t10 = load %"compiler/token:Token", ptr %t9
  %t11 = load i8, ptr @G_2ecompiler_2ftoken_2eSpace, !tbaa !22
  %t14 = call i1 @compiler_2ftoken_2ecompiler_2ftoken_3aToken_2eHas(%"compiler/token:Token" %t10, i8 %t11)
  store i1 %t14, ptr %l7
  br label %bb1
bb1:
  %t15 = load i1, ptr %l7, !tbaa !21
  br i1 %t15, label %bb2, label %bb3
bb2:
  store { i64, ptr } { i64 1, ptr @.d14 }, ptr %l8, !tbaa !27
  br label %bb4
bb3:
  store { i64, ptr } { i64 0, ptr @.d15 }, ptr %l8, !tbaa !27
  br label %bb4
bb4:
  %t16 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t16, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2ebefore(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l10 = alloca i64
  %l12 = alloca { i64, ptr }
  %l16 = alloca i64
  %l19 = alloca i1
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp sle i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i64 -1, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/fmt:formatter", ptr %t6, i32 0, i32 6
  %t9 = load i64, ptr %l1, !tbaa !24
  %t11 = sub i64 %t9, 1
  %t14 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t8, i64 %t11)
  store i64 %t14, ptr %l10
  br label %bb4
bb4:
  %t15 = load i64, ptr %l10, !tbaa !24
  store i64 %t15, ptr %l2, !tbaa !24
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/fmt:formatter", ptr %t16, i32 0, i32 1
  %t19 = load { i64, ptr }, ptr %t18, !tbaa !27
  store { i64, ptr } %t19, ptr %l12, !tbaa !27
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/fmt:formatter", ptr %t20, i32 0, i32 6
  %t23 = load i64, ptr %l1, !tbaa !24
  %t26 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t22, i64 %t23)
  store i64 %t26, ptr %l16
  br label %bb5
bb5:
  %t27 = load i64, ptr %l16, !tbaa !24
  %t28 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !27
  %t30 = getelementptr %"compiler/token:Token", ptr %t29, i64 %t27
  %t31 = load %"compiler/token:Token", ptr %t30
  %t32 = load i8, ptr @G_2ecompiler_2ftoken_2eLineBreak, !tbaa !22
  %t35 = call i1 @compiler_2ftoken_2ecompiler_2ftoken_3aToken_2eHas(%"compiler/token:Token" %t31, i8 %t32)
  store i1 %t35, ptr %l19
  br label %bb6
bb6:
  %t36 = load i1, ptr %l19, !tbaa !21
  br i1 %t36, label %bb7, label %bb8
bb7:
  store i64 -1, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t38 = load i64, ptr %l2, !tbaa !24
  store i64 %t38, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2ebegin(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca i32
  %l7 = alloca i1
  %l10 = alloca i64
  %l18 = alloca i32
  %l19 = alloca i32
  %l21 = alloca i32
  %l23 = alloca i1
  %l24 = alloca i1
  %l25 = alloca i32
  %l27 = alloca i32
  %l29 = alloca i1
  %l30 = alloca i1
  %l31 = alloca i32
  %l33 = alloca i32
  %l35 = alloca i1
  %l36 = alloca i1
  %l38 = alloca { i64, ptr }
  %l63 = alloca ptr
  %l66 = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/fmt:formatter", ptr %t1, i32 0, i32 29
  %t4 = load i64, ptr %t3, !tbaa !24
  %t6 = icmp sgt i64 %t4, 0
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/fmt:formatter", ptr %t8, i32 0, i32 11
  %t12 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t10)
  store i64 %t12, ptr %l10
  br label %bb3
bb2:
  store i1 false, ptr %l7, !tbaa !21
  br label %bb4
bb3:
  %t13 = load i64, ptr %l10, !tbaa !24
  %t14 = icmp sgt i64 %t13, 0
  store i1 %t14, ptr %l7, !tbaa !21
  br label %bb4
bb4:
  %t16 = load i1, ptr %l7, !tbaa !21
  br i1 %t16, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l2, !tbaa !21
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/fmt:formatter", ptr %t17, i32 0, i32 30
  %t20 = load i64, ptr %t19, !tbaa !24
  %t22 = icmp sge i64 %t20, 0
  br i1 %t22, label %bb7, label %bb8
bb6:
  br label %bb36
bb7:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/fmt:formatter", ptr %t25, i32 0, i32 30
  %t28 = load i64, ptr %t27, !tbaa !24
  %t31 = call i32 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2ekind(ptr %v0, ptr %t24, i64 %t28)
  store i32 %t31, ptr %l18
  br label %bb9
bb8:
  br label %bb25
bb9:
  %t32 = load i32, ptr %l18
  store i32 %t32, ptr %l3
  %t33 = load i32, ptr %l3
  store i32 %t33, ptr %l19
  store i32 92, ptr %l21
  %t36 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l19, ptr %l21)
  store i1 %t36, ptr %l23
  br label %bb10
bb10:
  %t37 = load i1, ptr %l23, !tbaa !21
  br i1 %t37, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l24, !tbaa !21
  br label %bb14
bb12:
  %t38 = load i32, ptr %l3
  store i32 %t38, ptr %l25
  store i32 88, ptr %l27
  %t41 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l25, ptr %l27)
  store i1 %t41, ptr %l29
  br label %bb13
bb13:
  %t42 = load i1, ptr %l29, !tbaa !21
  store i1 %t42, ptr %l24, !tbaa !21
  br label %bb14
bb14:
  %t43 = load i1, ptr %l24, !tbaa !21
  br i1 %t43, label %bb15, label %bb16
bb15:
  store i1 true, ptr %l30, !tbaa !21
  br label %bb18
bb16:
  %t44 = load i32, ptr %l3
  store i32 %t44, ptr %l31
  store i32 90, ptr %l33
  %t47 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l31, ptr %l33)
  store i1 %t47, ptr %l35
  br label %bb17
bb17:
  %t48 = load i1, ptr %l35, !tbaa !21
  store i1 %t48, ptr %l30, !tbaa !21
  br label %bb18
bb18:
  %t49 = load i1, ptr %l30, !tbaa !21
  br i1 %t49, label %bb19, label %bb20
bb19:
  store i1 true, ptr %l36, !tbaa !21
  br label %bb21
bb20:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/fmt:formatter", ptr %t50, i32 0, i32 2
  %t53 = load { i64, ptr }, ptr %t52, !tbaa !27
  store { i64, ptr } %t53, ptr %l38, !tbaa !27
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/fmt:formatter", ptr %t54, i32 0, i32 30
  %t57 = load i64, ptr %t56, !tbaa !24
  %t59 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !27
  %t61 = getelementptr i64, ptr %t60, i64 %t57
  %t62 = load i64, ptr %t61, !tbaa !34
  %t64 = icmp sgt i64 %t62, 0
  store i1 %t64, ptr %l36, !tbaa !21
  br label %bb21
bb21:
  %t66 = load i1, ptr %l36, !tbaa !21
  br i1 %t66, label %bb22, label %bb23
bb22:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb24
bb23:
  br label %bb24
bb24:
  br label %bb25
bb25:
  %t67 = load i1, ptr %l2, !tbaa !21
  br i1 %t67, label %bb26, label %bb27
bb26:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/fmt:formatter", ptr %t69, i32 0, i32 11
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t71, i64 1)
  br label %bb28
bb27:
  br label %bb35
bb28:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/fmt:formatter", ptr %t73, i32 0, i32 12
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t75, i64 0)
  br label %bb29
bb29:
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/fmt:formatter", ptr %t77, i32 0, i32 13
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t79, i64 0)
  br label %bb30
bb30:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"compiler/fmt:formatter", ptr %t81, i32 0, i32 14
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t83, i64 0)
  br label %bb31
bb31:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"compiler/fmt:formatter", ptr %t85, i32 0, i32 15
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t87, i64 -1)
  br label %bb32
bb32:
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr %"compiler/fmt:formatter", ptr %t89, i32 0, i32 16
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t91, i64 -1)
  br label %bb33
bb33:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/fmt:formatter", ptr %t93, i32 0, i32 17
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t95, i1 false)
  br label %bb34
bb34:
  br label %bb35
bb35:
  br label %bb36
bb36:
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = getelementptr %"compiler/fmt:formatter", ptr %t97, i32 0, i32 29
  store i64 0, ptr %t99, !tbaa !24
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t102 = getelementptr %"compiler/fmt:formatter", ptr %t100, i32 0, i32 19
  store i1 true, ptr %t102, !tbaa !21
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t105 = getelementptr %"compiler/fmt:formatter", ptr %t103, i32 0, i32 33
  store i1 false, ptr %t105, !tbaa !21
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t110 = getelementptr %"compiler/fmt:formatter", ptr %t106, i32 0, i32 20
  store i64 %a1, ptr %t110, !tbaa !24
  %t111 = load ptr, ptr %l0, !tbaa !29
  store ptr %t111, ptr %l63, !tbaa !29
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t114 = getelementptr %"compiler/fmt:formatter", ptr %t112, i32 0, i32 18
  %t116 = call i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eLen(ptr %v0, ptr %t114)
  store i64 %t116, ptr %l66
  br label %bb37
bb37:
  %t117 = load i64, ptr %l66, !tbaa !24
  %t118 = load ptr, ptr %l63, !tbaa !29
  %t119 = getelementptr %"compiler/fmt:formatter", ptr %t118, i32 0, i32 23
  store i64 %t117, ptr %t119, !tbaa !24
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t122 = getelementptr %"compiler/fmt:formatter", ptr %t120, i32 0, i32 24
  store i1 false, ptr %t122, !tbaa !21
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t125 = getelementptr %"compiler/fmt:formatter", ptr %t123, i32 0, i32 27
  store i64 0, ptr %t125, !tbaa !24
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t128 = getelementptr %"compiler/fmt:formatter", ptr %t126, i32 0, i32 28
  store i64 -1, ptr %t128, !tbaa !24
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t131 = getelementptr %"compiler/fmt:formatter", ptr %t129, i32 0, i32 25
  store i64 -1, ptr %t131, !tbaa !24
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t134 = getelementptr %"compiler/fmt:formatter", ptr %t132, i32 0, i32 26
  store i64 -1, ptr %t134, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2echild(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l4 = alloca i64
  %l12 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/fmt:formatter", ptr %t1, i32 0, i32 8
  %t5 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i64, ptr %l4, !tbaa !24
  store i64 %t6, ptr %l1, !tbaa !24
  %t7 = load i64, ptr %l1, !tbaa !24
  %t9 = icmp eq i64 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  store i64 0, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/fmt:formatter", ptr %t12, i32 0, i32 9
  %t15 = load i64, ptr %l1, !tbaa !24
  %t17 = sub i64 %t15, 1
  %t20 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t14, i64 %t17)
  store i64 %t20, ptr %l12
  br label %bb5
bb5:
  %t21 = load i64, ptr %l12, !tbaa !24
  store i64 %t21, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2eclosing(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l4 = alloca i32
  %l5 = alloca i1
  %l6 = alloca i1
  %l8 = alloca { i64, ptr }
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  %t5 = call i32 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2ekind(ptr %v0, ptr %t1, i64 %t2)
  store i32 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i32, ptr %l4
  %t7 = call i1 @compiler_2ffmt_2eisCloser(i32 %t6)
  store i1 %t7, ptr %l5
  br label %bb2
bb2:
  %t8 = load i1, ptr %l5, !tbaa !21
  br i1 %t8, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb5
bb4:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/fmt:formatter", ptr %t9, i32 0, i32 4
  %t12 = load { i64, ptr }, ptr %t11, !tbaa !27
  store { i64, ptr } %t12, ptr %l8, !tbaa !27
  %t13 = load i64, ptr %l1, !tbaa !24
  %t15 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !27
  %t17 = getelementptr i64, ptr %t16, i64 %t13
  %t18 = load i64, ptr %t17, !tbaa !34
  %t20 = icmp sgt i64 %t18, 0
  store i1 %t20, ptr %l6, !tbaa !21
  br label %bb5
bb5:
  %t22 = load i1, ptr %l6, !tbaa !21
  store i1 %t22, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2ecomment(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i1 %a3, i64 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l16 = alloca i1
  %l18 = alloca { i64, ptr }
  %l23 = alloca i1
  %l25 = alloca { i64, ptr }
  %l36 = alloca ptr
  %l39 = alloca i64
  %l47 = alloca ptr
  %l50 = alloca i64
  %l61 = alloca i64
  %l64 = alloca i64
  %l83 = alloca { i64, ptr }
  %l91 = alloca ptr
  %l93 = alloca { i64, ptr }
  %l94 = alloca i64
  %l95 = alloca i64
  %l96 = alloca i64
  %s2 = alloca %olang.scope
  %s8 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  store i64 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t3 = xor i1 %a3, true
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb20
bb3:
  store %olang.scope zeroinitializer, ptr %s2
  %t5 = load i64, ptr %l2, !tbaa !24
  %t6 = load i64, ptr %l1, !tbaa !24
  %t9 = icmp sgt i64 %t5, %t6
  br i1 %t9, label %bb4, label %bb5
bb4:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/fmt:formatter", ptr %t11, i32 0, i32 0
  %t14 = load { i64, ptr }, ptr %t13, !tbaa !27
  store { i64, ptr } %t14, ptr %l18, !tbaa !27
  %t15 = load i64, ptr %l2, !tbaa !24
  %t17 = sub i64 %t15, 1
  %t19 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !27
  %t21 = getelementptr i8, ptr %t20, i64 %t17
  %t22 = load i8, ptr %t21, !tbaa !32
  %t24 = icmp eq i8 %t22, 32
  br i1 %t24, label %bb6, label %bb7
bb5:
  store i1 false, ptr %l16, !tbaa !21
  br label %bb9
bb6:
  store i1 true, ptr %l23, !tbaa !21
  br label %bb8
bb7:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/fmt:formatter", ptr %t26, i32 0, i32 0
  %t29 = load { i64, ptr }, ptr %t28, !tbaa !27
  store { i64, ptr } %t29, ptr %l25, !tbaa !27
  %t30 = load i64, ptr %l2, !tbaa !24
  %t32 = sub i64 %t30, 1
  %t34 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !27
  %t36 = getelementptr i8, ptr %t35, i64 %t32
  %t37 = load i8, ptr %t36, !tbaa !32
  %t39 = icmp eq i8 %t37, 9
  store i1 %t39, ptr %l23, !tbaa !21
  br label %bb8
bb8:
  %t41 = load i1, ptr %l23, !tbaa !21
  store i1 %t41, ptr %l16, !tbaa !21
  br label %bb9
bb9:
  %t42 = load i1, ptr %l16, !tbaa !21
  %t43 = xor i1 %t42, true
  br i1 %t43, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb14
bb11:
  br label %bb12
bb12:
  %t45 = load i64, ptr %l2, !tbaa !24
  %t47 = sub i64 %t45, 1
  store i64 %t47, ptr %l2, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb13
bb13:
  br label %bb3
bb14:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/fmt:formatter", ptr %t49, i32 0, i32 19
  %t52 = load i1, ptr %t51, !tbaa !21
  %t54 = xor i1 %t52, true
  br i1 %t54, label %bb15, label %bb16
bb15:
  %t56 = load ptr, ptr %l0, !tbaa !29
  store ptr %t56, ptr %l36, !tbaa !29
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t58 = load i64, ptr %l4, !tbaa !24
  %t61 = call i64 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2elevelAt(ptr %v0, ptr %t57, i64 %t58)
  store i64 %t61, ptr %l39
  br label %bb17
bb16:
  br label %bb19
bb17:
  %t62 = load ptr, ptr %l36, !tbaa !29
  %t63 = load i64, ptr %l39, !tbaa !24
  call void @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2ebegin(ptr %v0, ptr %t62, i64 %t63)
  br label %bb18
bb18:
  br label %bb19
bb19:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t65 = load i64, ptr %l1, !tbaa !24
  %t68 = getelementptr %"compiler/fmt:formatter", ptr %t64, i32 0, i32 25
  store i64 %t65, ptr %t68, !tbaa !24
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t70 = load i64, ptr %l2, !tbaa !24
  %t73 = getelementptr %"compiler/fmt:formatter", ptr %t69, i32 0, i32 26
  store i64 %t70, ptr %t73, !tbaa !24
  br label %ret
bb20:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr %"compiler/fmt:formatter", ptr %t74, i32 0, i32 19
  %t77 = load i1, ptr %t76, !tbaa !21
  %t79 = xor i1 %t77, true
  br i1 %t79, label %bb21, label %bb22
bb21:
  %t81 = load ptr, ptr %l0, !tbaa !29
  store ptr %t81, ptr %l47, !tbaa !29
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t83 = load i64, ptr %l4, !tbaa !24
  %t86 = call i64 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2elevelAt(ptr %v0, ptr %t82, i64 %t83)
  store i64 %t86, ptr %l50
  br label %bb23
bb22:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr %"compiler/fmt:formatter", ptr %t87, i32 0, i32 27
  %t90 = load i64, ptr %t89, !tbaa !24
  %t92 = icmp ne i64 %t90, 0
  br i1 %t92, label %bb25, label %bb26
bb23:
  %t94 = load ptr, ptr %l47, !tbaa !29
  %t95 = load i64, ptr %l50, !tbaa !24
  call void @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2ebegin(ptr %v0, ptr %t94, i64 %t95)
  br label %bb24
bb24:
  br label %bb29
bb25:
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"compiler/fmt:formatter", ptr %t96, i32 0, i32 18
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %t98, i8 32)
  br label %bb27
bb26:
  br label %bb28
bb27:
  br label %bb28
bb28:
  br label %bb29
bb29:
  %t100 = load i64, ptr %l1, !tbaa !24
  store i64 %t100, ptr %l5, !tbaa !24
  %t102 = load i64, ptr %l2, !tbaa !24
  store i64 %t102, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t104 = load i64, ptr %l6, !tbaa !24
  %t105 = load i64, ptr %l5, !tbaa !24
  %t108 = icmp sgt i64 %t104, %t105
  br i1 %t108, label %bb30, label %bb31
bb30:
  %t110 = load i64, ptr %l7, !tbaa !24
  %t112 = icmp sgt i64 %t110, 0
  br i1 %t112, label %bb32, label %bb33
bb31:
  store i64 0, ptr %l61, !tbaa !24
  br label %bb35
bb32:
  %t114 = load i64, ptr %l6, !tbaa !24
  %t115 = load i64, ptr %l5, !tbaa !24
  %t118 = sub i64 %t114, %t115
  %t119 = load i64, ptr %l7, !tbaa !24
  %t122 = add i64 %t118, %t119
  %t124 = sub i64 %t122, 1
  %t125 = load i64, ptr %l7, !tbaa !24
  %t128 = sdiv i64 %t124, %t125
  store i64 %t128, ptr %l64, !tbaa !24
  br label %bb34
bb33:
  store i64 0, ptr %l64, !tbaa !24
  br label %bb34
bb34:
  %t130 = load i64, ptr %l64, !tbaa !24
  store i64 %t130, ptr %l61, !tbaa !24
  br label %bb35
bb35:
  %t131 = load i64, ptr %l61, !tbaa !24
  store i64 %t131, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb36
bb36:
  store %olang.scope zeroinitializer, ptr %s8
  %t132 = load i64, ptr %l9, !tbaa !24
  %t133 = load i64, ptr %l8, !tbaa !24
  %t136 = icmp slt i64 %t132, %t133
  %t138 = xor i1 %t136, true
  br i1 %t138, label %bb37, label %bb38
bb37:
  call void @__olang_scope_close(ptr %s8)
  br label %bb44
bb38:
  br label %bb39
bb39:
  %t140 = load i64, ptr %l5, !tbaa !24
  %t141 = load i64, ptr %l9, !tbaa !24
  %t142 = load i64, ptr %l7, !tbaa !24
  %t145 = mul i64 %t141, %t142
  %t148 = add i64 %t140, %t145
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t152 = getelementptr %"compiler/fmt:formatter", ptr %t150, i32 0, i32 0
  %t153 = load { i64, ptr }, ptr %t152, !tbaa !27
  store { i64, ptr } %t153, ptr %l83, !tbaa !27
  %t156 = getelementptr { i64, ptr }, ptr %l83, i32 0, i32 1
  %t157 = load ptr, ptr %t156, !tbaa !27
  %t158 = getelementptr i8, ptr %t157, i64 %t148
  %t159 = load i8, ptr %t158, !tbaa !32
  %t161 = icmp eq i8 %t159, 10
  br i1 %t161, label %bb40, label %bb41
bb40:
  %t163 = load ptr, ptr %l0, !tbaa !29
  %t165 = getelementptr %"compiler/fmt:formatter", ptr %t163, i32 0, i32 24
  store i1 true, ptr %t165, !tbaa !21
  br label %bb42
bb41:
  br label %bb42
bb42:
  call void @__olang_scope_close(ptr %s8)
  br label %bb43
bb43:
  %t166 = load i64, ptr %l9, !tbaa !24
  %t168 = add i64 %t166, 1
  store i64 %t168, ptr %l9, !tbaa !24
  br label %bb36
bb44:
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t172 = getelementptr %"compiler/fmt:formatter", ptr %t170, i32 0, i32 18
  store ptr %t172, ptr %l91, !tbaa !29
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t175 = getelementptr %"compiler/fmt:formatter", ptr %t173, i32 0, i32 0
  %t176 = load { i64, ptr }, ptr %t175, !tbaa !27
  store { i64, ptr } %t176, ptr %l93, !tbaa !27
  %t177 = load i64, ptr %l1, !tbaa !24
  store i64 %t177, ptr %l94, !tbaa !24
  %t178 = load i64, ptr %l2, !tbaa !24
  store i64 %t178, ptr %l95, !tbaa !24
  %t179 = load { i64, ptr }, ptr %l93, !tbaa !27
  %t180 = extractvalue { i64, ptr } %t179, 0
  store i64 %t180, ptr %l96, !tbaa !24
  %t181 = load i64, ptr %l94, !tbaa !24
  %t182 = icmp sge i64 %t181, 0
  br i1 %t182, label %bb45, label %bb46
bb45:
  %t184 = load i64, ptr %l94, !tbaa !24
  %t185 = load i64, ptr %l95, !tbaa !24
  %t186 = icmp sle i64 %t184, %t185
  br i1 %t186, label %bb47, label %bb48
bb46:
  call void @__olang_check_failed(ptr @.c16)
  unreachable
bb47:
  %t188 = load i64, ptr %l95, !tbaa !24
  %t189 = load i64, ptr %l96, !tbaa !24
  %t190 = icmp sle i64 %t188, %t189
  br i1 %t190, label %bb49, label %bb50
bb48:
  call void @__olang_check_failed(ptr @.c16)
  unreachable
bb49:
  %t192 = getelementptr { i64, ptr }, ptr %l93, i32 0, i32 1
  %t193 = load ptr, ptr %t192, !tbaa !27
  %t194 = load i64, ptr %l94, !tbaa !24
  %t195 = load i64, ptr %l95, !tbaa !24
  %t196 = getelementptr i8, ptr %t193, i64 %t194
  %t197 = sub i64 %t195, %t194
  %t198 = insertvalue { i64, ptr } undef, i64 %t197, 0
  %t199 = insertvalue { i64, ptr } %t198, ptr %t196, 1
  %t200 = load ptr, ptr %l91, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v0, ptr %t200, { i64, ptr } %t199)
  br label %bb51
bb50:
  call void @__olang_check_failed(ptr @.c16)
  unreachable
bb51:
  %t202 = load ptr, ptr %l0, !tbaa !29
  %t204 = getelementptr %"compiler/fmt:formatter", ptr %t202, i32 0, i32 27
  store i64 2, ptr %t204, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2econt(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i32
  %l4 = alloca i64
  %l7 = alloca i1
  %l11 = alloca i1
  %l17 = alloca i64
  %l20 = alloca i32
  %l21 = alloca i32
  %l23 = alloca i32
  %l25 = alloca i1
  %l26 = alloca i1
  %l27 = alloca i32
  %l29 = alloca i32
  %l31 = alloca i1
  %l32 = alloca i1
  %l33 = alloca i32
  %l35 = alloca i32
  %l37 = alloca i1
  %l38 = alloca i1
  %l39 = alloca i32
  %l41 = alloca i32
  %l43 = alloca i1
  %l46 = alloca { i64, ptr }
  %l50 = alloca i1
  %l52 = alloca { i64, ptr }
  %l57 = alloca i32
  %l59 = alloca i32
  %l61 = alloca i1
  %l62 = alloca i1
  %l64 = alloca { i64, ptr }
  %l68 = alloca i1
  %l71 = alloca i32
  %l73 = alloca i32
  %l75 = alloca i1
  %l78 = alloca i64
  %l81 = alloca i1
  %l86 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp sle i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb4
bb2:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/fmt:formatter", ptr %t5, i32 0, i32 7
  %t8 = load i64, ptr %l1, !tbaa !24
  %t11 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t7, i64 %t8)
  store i1 %t11, ptr %l11
  br label %bb3
bb3:
  %t12 = load i1, ptr %l11, !tbaa !21
  store i1 %t12, ptr %l7, !tbaa !21
  br label %bb4
bb4:
  %t13 = load i1, ptr %l7, !tbaa !21
  br i1 %t13, label %bb5, label %bb6
bb5:
  store i64 0, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/fmt:formatter", ptr %t15, i32 0, i32 6
  %t18 = load i64, ptr %l1, !tbaa !24
  %t20 = sub i64 %t18, 1
  %t23 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t17, i64 %t20)
  store i64 %t23, ptr %l17
  br label %bb8
bb8:
  %t24 = load i64, ptr %l17, !tbaa !24
  store i64 %t24, ptr %l2, !tbaa !24
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t26 = load i64, ptr %l2, !tbaa !24
  %t29 = call i32 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2ekind(ptr %v0, ptr %t25, i64 %t26)
  store i32 %t29, ptr %l20
  br label %bb9
bb9:
  %t30 = load i32, ptr %l20
  store i32 %t30, ptr %l3
  %t31 = load i32, ptr %l3
  store i32 %t31, ptr %l21
  store i32 92, ptr %l23
  %t34 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l21, ptr %l23)
  store i1 %t34, ptr %l25
  br label %bb10
bb10:
  %t35 = load i1, ptr %l25, !tbaa !21
  br i1 %t35, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l26, !tbaa !21
  br label %bb14
bb12:
  %t36 = load i32, ptr %l3
  store i32 %t36, ptr %l27
  store i32 88, ptr %l29
  %t39 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l27, ptr %l29)
  store i1 %t39, ptr %l31
  br label %bb13
bb13:
  %t40 = load i1, ptr %l31, !tbaa !21
  store i1 %t40, ptr %l26, !tbaa !21
  br label %bb14
bb14:
  %t41 = load i1, ptr %l26, !tbaa !21
  br i1 %t41, label %bb15, label %bb16
bb15:
  store i1 true, ptr %l32, !tbaa !21
  br label %bb18
bb16:
  %t42 = load i32, ptr %l3
  store i32 %t42, ptr %l33
  store i32 90, ptr %l35
  %t45 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l33, ptr %l35)
  store i1 %t45, ptr %l37
  br label %bb17
bb17:
  %t46 = load i1, ptr %l37, !tbaa !21
  store i1 %t46, ptr %l32, !tbaa !21
  br label %bb18
bb18:
  %t47 = load i1, ptr %l32, !tbaa !21
  br i1 %t47, label %bb19, label %bb20
bb19:
  store i1 true, ptr %l38, !tbaa !21
  br label %bb22
bb20:
  %t48 = load i32, ptr %l3
  store i32 %t48, ptr %l39
  store i32 93, ptr %l41
  %t51 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l39, ptr %l41)
  store i1 %t51, ptr %l43
  br label %bb21
bb21:
  %t52 = load i1, ptr %l43, !tbaa !21
  store i1 %t52, ptr %l38, !tbaa !21
  br label %bb22
bb22:
  %t53 = load i1, ptr %l38, !tbaa !21
  br i1 %t53, label %bb23, label %bb24
bb23:
  store i64 0, ptr %rv
  br label %ret
bb24:
  br label %bb25
bb25:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/fmt:formatter", ptr %t55, i32 0, i32 2
  %t58 = load { i64, ptr }, ptr %t57, !tbaa !27
  store { i64, ptr } %t58, ptr %l46, !tbaa !27
  %t59 = load i64, ptr %l2, !tbaa !24
  %t61 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !27
  %t63 = getelementptr i64, ptr %t62, i64 %t59
  %t64 = load i64, ptr %t63, !tbaa !34
  %t66 = icmp sgt i64 %t64, 0
  br i1 %t66, label %bb26, label %bb27
bb26:
  store i1 true, ptr %l50, !tbaa !21
  br label %bb28
bb27:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/fmt:formatter", ptr %t68, i32 0, i32 4
  %t71 = load { i64, ptr }, ptr %t70, !tbaa !27
  store { i64, ptr } %t71, ptr %l52, !tbaa !27
  %t72 = load i64, ptr %l2, !tbaa !24
  %t74 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t75 = load ptr, ptr %t74, !tbaa !27
  %t76 = getelementptr i64, ptr %t75, i64 %t72
  %t77 = load i64, ptr %t76, !tbaa !34
  %t79 = icmp sgt i64 %t77, 0
  store i1 %t79, ptr %l50, !tbaa !21
  br label %bb28
bb28:
  %t81 = load i1, ptr %l50, !tbaa !21
  br i1 %t81, label %bb29, label %bb30
bb29:
  store i64 0, ptr %rv
  br label %ret
bb30:
  br label %bb31
bb31:
  %t83 = load i32, ptr %l3
  store i32 %t83, ptr %l57
  store i32 81, ptr %l59
  %t86 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l57, ptr %l59)
  store i1 %t86, ptr %l61
  br label %bb32
bb32:
  %t87 = load i1, ptr %l61, !tbaa !21
  br i1 %t87, label %bb33, label %bb34
bb33:
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t90 = getelementptr %"compiler/fmt:formatter", ptr %t88, i32 0, i32 1
  %t91 = load { i64, ptr }, ptr %t90, !tbaa !27
  store { i64, ptr } %t91, ptr %l64, !tbaa !27
  %t92 = load i64, ptr %l2, !tbaa !24
  %t94 = getelementptr { i64, ptr }, ptr %l64, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !27
  %t96 = getelementptr %"compiler/token:Token", ptr %t95, i64 %t92
  %t97 = load %"compiler/token:Token", ptr %t96
  %t98 = load i8, ptr @G_2ecompiler_2ftoken_2eSpace, !tbaa !22
  %t101 = call i1 @compiler_2ftoken_2ecompiler_2ftoken_3aToken_2eHas(%"compiler/token:Token" %t97, i8 %t98)
  store i1 %t101, ptr %l68
  br label %bb35
bb34:
  store i1 false, ptr %l62, !tbaa !21
  br label %bb36
bb35:
  %t102 = load i1, ptr %l68, !tbaa !21
  %t103 = xor i1 %t102, true
  store i1 %t103, ptr %l62, !tbaa !21
  br label %bb36
bb36:
  %t105 = load i1, ptr %l62, !tbaa !21
  br i1 %t105, label %bb37, label %bb38
bb37:
  store i64 0, ptr %rv
  br label %ret
bb38:
  br label %bb39
bb39:
  %t107 = load i32, ptr %l3
  store i32 %t107, ptr %l71
  store i32 55, ptr %l73
  %t110 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l71, ptr %l73)
  store i1 %t110, ptr %l75
  br label %bb40
bb40:
  %t111 = load i1, ptr %l75, !tbaa !21
  br i1 %t111, label %bb41, label %bb42
bb41:
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t114 = getelementptr %"compiler/fmt:formatter", ptr %t112, i32 0, i32 8
  %t116 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t114)
  store i64 %t116, ptr %l78
  br label %bb43
bb42:
  br label %bb51
bb43:
  %t117 = load i64, ptr %l78, !tbaa !24
  store i64 %t117, ptr %l4, !tbaa !24
  %t118 = load i64, ptr %l4, !tbaa !24
  %t120 = icmp sgt i64 %t118, 0
  br i1 %t120, label %bb44, label %bb45
bb44:
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t124 = getelementptr %"compiler/fmt:formatter", ptr %t122, i32 0, i32 8
  %t125 = load i64, ptr %l4, !tbaa !24
  %t127 = sub i64 %t125, 1
  %t130 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t124, i64 %t127)
  store i64 %t130, ptr %l86
  br label %bb46
bb45:
  store i1 false, ptr %l81, !tbaa !21
  br label %bb47
bb46:
  %t131 = load i64, ptr %l86, !tbaa !24
  %t132 = icmp eq i64 %t131, 1
  store i1 %t132, ptr %l81, !tbaa !21
  br label %bb47
bb47:
  %t134 = load i1, ptr %l81, !tbaa !21
  br i1 %t134, label %bb48, label %bb49
bb48:
  store i64 0, ptr %rv
  br label %ret
bb49:
  br label %bb50
bb50:
  br label %bb51
bb51:
  store i64 1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2edropBlank(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l4 = alloca i64
  %l7 = alloca i1
  %l12 = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/fmt:formatter", ptr %t1, i32 0, i32 11
  %t5 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i64, ptr %l4, !tbaa !24
  store i64 %t6, ptr %l1, !tbaa !24
  %t7 = load i64, ptr %l1, !tbaa !24
  %t9 = icmp eq i64 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb5
bb3:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/fmt:formatter", ptr %t11, i32 0, i32 11
  %t14 = load i64, ptr %l1, !tbaa !24
  %t16 = sub i64 %t14, 1
  %t19 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t13, i64 %t16)
  store i64 %t19, ptr %l12
  br label %bb4
bb4:
  %t20 = load i64, ptr %l12, !tbaa !24
  %t21 = icmp ne i64 %t20, 1
  store i1 %t21, ptr %l7, !tbaa !21
  br label %bb5
bb5:
  %t23 = load i1, ptr %l7, !tbaa !21
  br i1 %t23, label %bb6, label %bb7
bb6:
  br label %ret
bb7:
  br label %bb8
bb8:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/fmt:formatter", ptr %t24, i32 0, i32 11
  %t27 = load i64, ptr %l1, !tbaa !24
  %t29 = sub i64 %t27, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eTruncate_3cI64_3e(ptr %v0, ptr %t26, i64 %t29)
  br label %bb9
bb9:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/fmt:formatter", ptr %t32, i32 0, i32 12
  %t35 = load i64, ptr %l1, !tbaa !24
  %t37 = sub i64 %t35, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eTruncate_3cI64_3e(ptr %v0, ptr %t34, i64 %t37)
  br label %bb10
bb10:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/fmt:formatter", ptr %t40, i32 0, i32 13
  %t43 = load i64, ptr %l1, !tbaa !24
  %t45 = sub i64 %t43, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eTruncate_3cI64_3e(ptr %v0, ptr %t42, i64 %t45)
  br label %bb11
bb11:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/fmt:formatter", ptr %t48, i32 0, i32 14
  %t51 = load i64, ptr %l1, !tbaa !24
  %t53 = sub i64 %t51, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eTruncate_3cI64_3e(ptr %v0, ptr %t50, i64 %t53)
  br label %bb12
bb12:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/fmt:formatter", ptr %t56, i32 0, i32 15
  %t59 = load i64, ptr %l1, !tbaa !24
  %t61 = sub i64 %t59, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eTruncate_3cI64_3e(ptr %v0, ptr %t58, i64 %t61)
  br label %bb13
bb13:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/fmt:formatter", ptr %t64, i32 0, i32 16
  %t67 = load i64, ptr %l1, !tbaa !24
  %t69 = sub i64 %t67, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eTruncate_3cI64_3e(ptr %v0, ptr %t66, i64 %t69)
  br label %bb14
bb14:
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t74 = getelementptr %"compiler/fmt:formatter", ptr %t72, i32 0, i32 17
  %t75 = load i64, ptr %l1, !tbaa !24
  %t77 = sub i64 %t75, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eTruncate_3cBool_3e(ptr %v0, ptr %t74, i64 %t77)
  br label %bb15
bb15:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2efinish(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l12 = alloca ptr
  %l15 = alloca i64
  %l23 = alloca ptr
  %l26 = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/fmt:formatter", ptr %t1, i32 0, i32 15
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t6 = getelementptr %"compiler/fmt:formatter", ptr %t4, i32 0, i32 25
  %t7 = load i64, ptr %t6, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t3, i64 %t7)
  br label %bb1
bb1:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/fmt:formatter", ptr %t10, i32 0, i32 16
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/fmt:formatter", ptr %t13, i32 0, i32 26
  %t16 = load i64, ptr %t15, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t12, i64 %t16)
  br label %bb2
bb2:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/fmt:formatter", ptr %t19, i32 0, i32 11
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t21, i64 0)
  br label %bb3
bb3:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/fmt:formatter", ptr %t23, i32 0, i32 12
  store ptr %t25, ptr %l12, !tbaa !29
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/fmt:formatter", ptr %t26, i32 0, i32 33
  %t29 = load i1, ptr %t28, !tbaa !21
  br i1 %t29, label %bb4, label %bb5
bb4:
  store i64 0, ptr %l15, !tbaa !24
  br label %bb6
bb5:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/fmt:formatter", ptr %t31, i32 0, i32 20
  %t34 = load i64, ptr %t33, !tbaa !24
  store i64 %t34, ptr %l15, !tbaa !24
  br label %bb6
bb6:
  %t36 = load ptr, ptr %l12, !tbaa !29
  %t37 = load i64, ptr %l15, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t36, i64 %t37)
  br label %bb7
bb7:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/fmt:formatter", ptr %t38, i32 0, i32 13
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/fmt:formatter", ptr %t41, i32 0, i32 23
  %t44 = load i64, ptr %t43, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t40, i64 %t44)
  br label %bb8
bb8:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/fmt:formatter", ptr %t47, i32 0, i32 14
  store ptr %t49, ptr %l23, !tbaa !29
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/fmt:formatter", ptr %t50, i32 0, i32 18
  %t54 = call i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eLen(ptr %v0, ptr %t52)
  store i64 %t54, ptr %l26
  br label %bb9
bb9:
  %t55 = load ptr, ptr %l23, !tbaa !29
  %t56 = load i64, ptr %l26, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t55, i64 %t56)
  br label %bb10
bb10:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/fmt:formatter", ptr %t57, i32 0, i32 17
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/fmt:formatter", ptr %t60, i32 0, i32 24
  %t63 = load i1, ptr %t62, !tbaa !21
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t59, i1 %t63)
  br label %bb11
bb11:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"compiler/fmt:formatter", ptr %t66, i32 0, i32 28
  %t69 = load i64, ptr %t68, !tbaa !24
  %t71 = icmp sge i64 %t69, 0
  br i1 %t71, label %bb12, label %bb13
bb12:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr %"compiler/fmt:formatter", ptr %t74, i32 0, i32 28
  %t77 = load i64, ptr %t76, !tbaa !24
  %t80 = getelementptr %"compiler/fmt:formatter", ptr %t73, i32 0, i32 30
  store i64 %t77, ptr %t80, !tbaa !24
  br label %bb14
bb13:
  br label %bb14
bb14:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"compiler/fmt:formatter", ptr %t81, i32 0, i32 19
  store i1 false, ptr %t83, !tbaa !21
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr %"compiler/fmt:formatter", ptr %t84, i32 0, i32 29
  store i64 0, ptr %t86, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2egap(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i8
  %l7 = alloca i64
  %l8 = alloca i1
  %l16 = alloca { i64, ptr }
  %l24 = alloca ptr
  %l36 = alloca i1
  %l37 = alloca { i64, ptr }
  %l48 = alloca i1
  %l49 = alloca { i64, ptr }
  %l53 = alloca i1
  %l54 = alloca { i64, ptr }
  %l67 = alloca i64
  %l74 = alloca i1
  %l75 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s10 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/fmt:formatter", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l4, !tbaa !27
  store i64 %a1, ptr %l5, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t8 = load i64, ptr %l5, !tbaa !24
  %t9 = load i64, ptr %l2, !tbaa !24
  %t12 = icmp slt i64 %t8, %t9
  %t14 = xor i1 %t12, true
  br i1 %t14, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s1)
  br label %bb47
bb3:
  br label %bb4
bb4:
  %t16 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t16, ptr %l16, !tbaa !27
  %t17 = load i64, ptr %l5, !tbaa !24
  %t19 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !27
  %t21 = getelementptr i8, ptr %t20, i64 %t17
  %t22 = load i8, ptr %t21, !tbaa !32
  store i8 %t22, ptr %l6, !tbaa !22
  %t24 = load i8, ptr %l6, !tbaa !22
  %t26 = icmp eq i8 %t24, 10
  br i1 %t26, label %bb5, label %bb6
bb5:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/fmt:formatter", ptr %t28, i32 0, i32 19
  %t31 = load i1, ptr %t30, !tbaa !21
  br i1 %t31, label %bb7, label %bb8
bb6:
  %t33 = load i8, ptr %l6, !tbaa !22
  %t35 = icmp eq i8 %t33, 35
  br i1 %t35, label %bb11, label %bb12
bb7:
  %t37 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2efinish(ptr %v0, ptr %t37)
  br label %bb9
bb8:
  %t39 = load ptr, ptr %l0, !tbaa !29
  store ptr %t39, ptr %l24, !tbaa !29
  %t40 = load ptr, ptr %l24, !tbaa !29
  %t41 = getelementptr %"compiler/fmt:formatter", ptr %t40, i32 0, i32 29
  %t42 = load i64, ptr %t41, !tbaa !24
  %t44 = add i64 %t42, 1
  %t46 = load ptr, ptr %l24, !tbaa !29
  %t47 = getelementptr %"compiler/fmt:formatter", ptr %t46, i32 0, i32 29
  store i64 %t44, ptr %t47, !tbaa !24
  br label %bb10
bb9:
  br label %bb10
bb10:
  %t48 = load i64, ptr %l5, !tbaa !24
  %t50 = add i64 %t48, 1
  store i64 %t50, ptr %l5, !tbaa !24
  br label %bb45
bb11:
  %t52 = load i64, ptr %l5, !tbaa !24
  %t54 = add i64 %t52, 1
  store i64 %t54, ptr %l7, !tbaa !24
  %t56 = load i64, ptr %l7, !tbaa !24
  %t57 = load i64, ptr %l2, !tbaa !24
  %t60 = icmp slt i64 %t56, %t57
  br i1 %t60, label %bb13, label %bb14
bb12:
  %t62 = load i64, ptr %l5, !tbaa !24
  %t64 = add i64 %t62, 1
  store i64 %t64, ptr %l5, !tbaa !24
  br label %bb44
bb13:
  %t66 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t66, ptr %l37, !tbaa !27
  %t67 = load i64, ptr %l7, !tbaa !24
  %t69 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !27
  %t71 = getelementptr i8, ptr %t70, i64 %t67
  %t72 = load i8, ptr %t71, !tbaa !32
  %t74 = icmp eq i8 %t72, 35
  store i1 %t74, ptr %l36, !tbaa !21
  br label %bb15
bb14:
  store i1 false, ptr %l36, !tbaa !21
  br label %bb15
bb15:
  %t76 = load i1, ptr %l36, !tbaa !21
  store i1 %t76, ptr %l8, !tbaa !21
  %t77 = load i1, ptr %l8, !tbaa !21
  br i1 %t77, label %bb16, label %bb17
bb16:
  %t79 = load i64, ptr %l7, !tbaa !24
  %t81 = add i64 %t79, 1
  store i64 %t81, ptr %l7, !tbaa !24
  br label %bb18
bb17:
  br label %bb33
bb18:
  store %olang.scope zeroinitializer, ptr %s8
  %t83 = load i64, ptr %l7, !tbaa !24
  %t85 = add i64 %t83, 1
  %t86 = load i64, ptr %l2, !tbaa !24
  %t89 = icmp slt i64 %t85, %t86
  br i1 %t89, label %bb19, label %bb20
bb19:
  %t91 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t91, ptr %l49, !tbaa !27
  %t92 = load i64, ptr %l7, !tbaa !24
  %t94 = getelementptr { i64, ptr }, ptr %l49, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !27
  %t96 = getelementptr i8, ptr %t95, i64 %t92
  %t97 = load i8, ptr %t96, !tbaa !32
  %t99 = icmp eq i8 %t97, 35
  br i1 %t99, label %bb21, label %bb22
bb20:
  store i1 false, ptr %l48, !tbaa !21
  br label %bb24
bb21:
  %t101 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t101, ptr %l54, !tbaa !27
  %t102 = load i64, ptr %l7, !tbaa !24
  %t104 = add i64 %t102, 1
  %t106 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t107 = load ptr, ptr %t106, !tbaa !27
  %t108 = getelementptr i8, ptr %t107, i64 %t104
  %t109 = load i8, ptr %t108, !tbaa !32
  %t111 = icmp eq i8 %t109, 35
  store i1 %t111, ptr %l53, !tbaa !21
  br label %bb23
bb22:
  store i1 false, ptr %l53, !tbaa !21
  br label %bb23
bb23:
  %t113 = load i1, ptr %l53, !tbaa !21
  %t114 = xor i1 %t113, true
  store i1 %t114, ptr %l48, !tbaa !21
  br label %bb24
bb24:
  %t116 = load i1, ptr %l48, !tbaa !21
  %t117 = xor i1 %t116, true
  br i1 %t117, label %bb25, label %bb26
bb25:
  call void @__olang_scope_close(ptr %s8)
  br label %bb29
bb26:
  br label %bb27
bb27:
  %t119 = load i64, ptr %l7, !tbaa !24
  %t121 = add i64 %t119, 1
  store i64 %t121, ptr %l7, !tbaa !24
  call void @__olang_scope_close(ptr %s8)
  br label %bb28
bb28:
  br label %bb18
bb29:
  %t123 = load i64, ptr %l7, !tbaa !24
  %t125 = add i64 %t123, 1
  %t126 = load i64, ptr %l2, !tbaa !24
  %t129 = icmp slt i64 %t125, %t126
  br i1 %t129, label %bb30, label %bb31
bb30:
  %t131 = load i64, ptr %l7, !tbaa !24
  %t133 = add i64 %t131, 2
  store i64 %t133, ptr %l67, !tbaa !24
  br label %bb32
bb31:
  %t135 = load i64, ptr %l2, !tbaa !24
  store i64 %t135, ptr %l67, !tbaa !24
  br label %bb32
bb32:
  %t137 = load i64, ptr %l67, !tbaa !24
  store i64 %t137, ptr %l7, !tbaa !24
  br label %bb42
bb33:
  store %olang.scope zeroinitializer, ptr %s10
  %t138 = load i64, ptr %l7, !tbaa !24
  %t139 = load i64, ptr %l2, !tbaa !24
  %t142 = icmp slt i64 %t138, %t139
  br i1 %t142, label %bb34, label %bb35
bb34:
  %t144 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t144, ptr %l75, !tbaa !27
  %t145 = load i64, ptr %l7, !tbaa !24
  %t147 = getelementptr { i64, ptr }, ptr %l75, i32 0, i32 1
  %t148 = load ptr, ptr %t147, !tbaa !27
  %t149 = getelementptr i8, ptr %t148, i64 %t145
  %t150 = load i8, ptr %t149, !tbaa !32
  %t152 = icmp ne i8 %t150, 10
  store i1 %t152, ptr %l74, !tbaa !21
  br label %bb36
bb35:
  store i1 false, ptr %l74, !tbaa !21
  br label %bb36
bb36:
  %t154 = load i1, ptr %l74, !tbaa !21
  %t155 = xor i1 %t154, true
  br i1 %t155, label %bb37, label %bb38
bb37:
  call void @__olang_scope_close(ptr %s10)
  br label %bb41
bb38:
  br label %bb39
bb39:
  %t157 = load i64, ptr %l7, !tbaa !24
  %t159 = add i64 %t157, 1
  store i64 %t159, ptr %l7, !tbaa !24
  call void @__olang_scope_close(ptr %s10)
  br label %bb40
bb40:
  br label %bb33
bb41:
  br label %bb42
bb42:
  %t161 = load ptr, ptr %l0, !tbaa !29
  %t162 = load i64, ptr %l5, !tbaa !24
  %t163 = load i64, ptr %l7, !tbaa !24
  %t164 = load i1, ptr %l8, !tbaa !21
  call void @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2ecomment(ptr %v0, ptr %t161, i64 %t162, i64 %t163, i1 %t164, i64 %a3)
  br label %bb43
bb43:
  %t171 = load i64, ptr %l7, !tbaa !24
  store i64 %t171, ptr %l5, !tbaa !24
  br label %bb44
bb44:
  br label %bb45
bb45:
  call void @__olang_scope_close(ptr %s1)
  br label %bb46
bb46:
  br label %bb1
bb47:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2eheldAt(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l10 = alloca i64
  %l14 = alloca i64
  %l17 = alloca i64
  %l38 = alloca i64
  %l41 = alloca i1
  %l42 = alloca i64
  %l46 = alloca i64
  %s2 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l2, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/fmt:formatter", ptr %t1, i32 0, i32 31
  %t5 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l10
  br label %bb1
bb1:
  %t6 = load i64, ptr %l10, !tbaa !24
  store i64 %t6, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = load i64, ptr %l2, !tbaa !24
  %t11 = icmp sgt i64 %t7, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load i64, ptr %l4, !tbaa !24
  %t15 = icmp sgt i64 %t13, 0
  br i1 %t15, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l14, !tbaa !24
  br label %bb7
bb4:
  %t17 = load i64, ptr %l3, !tbaa !24
  %t18 = load i64, ptr %l2, !tbaa !24
  %t21 = sub i64 %t17, %t18
  %t22 = load i64, ptr %l4, !tbaa !24
  %t25 = add i64 %t21, %t22
  %t27 = sub i64 %t25, 1
  %t28 = load i64, ptr %l4, !tbaa !24
  %t31 = sdiv i64 %t27, %t28
  store i64 %t31, ptr %l17, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l17, !tbaa !24
  br label %bb6
bb6:
  %t33 = load i64, ptr %l17, !tbaa !24
  store i64 %t33, ptr %l14, !tbaa !24
  br label %bb7
bb7:
  %t34 = load i64, ptr %l14, !tbaa !24
  store i64 %t34, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t35 = load i64, ptr %l6, !tbaa !24
  %t36 = load i64, ptr %l5, !tbaa !24
  %t39 = icmp slt i64 %t35, %t36
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb21
bb10:
  br label %bb11
bb11:
  %t43 = load i64, ptr %l2, !tbaa !24
  %t44 = load i64, ptr %l6, !tbaa !24
  %t45 = load i64, ptr %l4, !tbaa !24
  %t48 = mul i64 %t44, %t45
  %t51 = add i64 %t43, %t48
  store i64 %t51, ptr %l7, !tbaa !24
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/fmt:formatter", ptr %t53, i32 0, i32 31
  %t56 = load i64, ptr %l7, !tbaa !24
  %t59 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t55, i64 %t56)
  store i64 %t59, ptr %l38
  br label %bb12
bb12:
  %t60 = load i64, ptr %l1, !tbaa !24
  %t61 = load i64, ptr %l38, !tbaa !24
  %t63 = icmp sle i64 %t61, %t60
  br i1 %t63, label %bb13, label %bb14
bb13:
  %t65 = load i64, ptr %l1, !tbaa !24
  store i64 %t65, ptr %l42, !tbaa !24
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"compiler/fmt:formatter", ptr %t66, i32 0, i32 32
  %t69 = load i64, ptr %l7, !tbaa !24
  %t72 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t68, i64 %t69)
  store i64 %t72, ptr %l46
  br label %bb15
bb14:
  store i1 false, ptr %l41, !tbaa !21
  br label %bb16
bb15:
  %t73 = load i64, ptr %l42, !tbaa !24
  %t74 = load i64, ptr %l46, !tbaa !24
  %t75 = icmp sle i64 %t73, %t74
  store i1 %t75, ptr %l41, !tbaa !21
  br label %bb16
bb16:
  %t77 = load i1, ptr %l41, !tbaa !21
  br i1 %t77, label %bb17, label %bb18
bb17:
  %t78 = load i64, ptr %l7, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  store i64 %t78, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s2)
  br label %bb20
bb20:
  %t80 = load i64, ptr %l6, !tbaa !24
  %t82 = add i64 %t80, 1
  store i64 %t82, ptr %l6, !tbaa !24
  br label %bb8
bb21:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2ekeyword(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l3 = alloca i8
  %l6 = alloca i32
  %l7 = alloca i32
  %l9 = alloca i32
  %l11 = alloca i1
  %l12 = alloca i1
  %l13 = alloca i32
  %l15 = alloca i32
  %l17 = alloca i1
  %l18 = alloca i1
  %l19 = alloca i32
  %l21 = alloca i32
  %l23 = alloca i1
  %l26 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  %l34 = alloca i1
  %l37 = alloca i1
  %l40 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  %t5 = call i32 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2ekind(ptr %v0, ptr %t1, i64 %t2)
  store i32 %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load i32, ptr %l6
  store i32 %t6, ptr %l2
  %t7 = load i32, ptr %l2
  store i32 %t7, ptr %l7
  store i32 1, ptr %l9
  %t10 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l7, ptr %l9)
  store i1 %t10, ptr %l11
  br label %bb2
bb2:
  %t11 = load i1, ptr %l11, !tbaa !21
  br i1 %t11, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb6
bb4:
  %t12 = load i32, ptr %l2
  store i32 %t12, ptr %l13
  store i32 6, ptr %l15
  %t15 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l13, ptr %l15)
  store i1 %t15, ptr %l17
  br label %bb5
bb5:
  %t16 = load i1, ptr %l17, !tbaa !21
  store i1 %t16, ptr %l12, !tbaa !21
  br label %bb6
bb6:
  %t17 = load i1, ptr %l12, !tbaa !21
  br i1 %t17, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l18, !tbaa !21
  br label %bb10
bb8:
  %t18 = load i32, ptr %l2
  store i32 %t18, ptr %l19
  store i32 7, ptr %l21
  %t21 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l19, ptr %l21)
  store i1 %t21, ptr %l23
  br label %bb9
bb9:
  %t22 = load i1, ptr %l23, !tbaa !21
  store i1 %t22, ptr %l18, !tbaa !21
  br label %bb10
bb10:
  %t23 = load i1, ptr %l18, !tbaa !21
  br i1 %t23, label %bb11, label %bb12
bb11:
  store i1 false, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/fmt:formatter", ptr %t25, i32 0, i32 0
  %t28 = load { i64, ptr }, ptr %t27, !tbaa !27
  store { i64, ptr } %t28, ptr %l26, !tbaa !27
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/fmt:formatter", ptr %t29, i32 0, i32 1
  %t32 = load { i64, ptr }, ptr %t31, !tbaa !27
  store { i64, ptr } %t32, ptr %l28, !tbaa !27
  %t33 = load i64, ptr %l1, !tbaa !24
  %t35 = getelementptr { i64, ptr }, ptr %l28, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !27
  %t37 = getelementptr %"compiler/token:Token", ptr %t36, i64 %t33
  %t38 = getelementptr %"compiler/token:Token", ptr %t37, i32 0, i32 2
  %t39 = load i32, ptr %t38, !tbaa !23
  %t41 = sext i32 %t39 to i64
  %t42 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = getelementptr i8, ptr %t43, i64 %t41
  %t45 = load i8, ptr %t44, !tbaa !32
  store i8 %t45, ptr %l3, !tbaa !22
  %t47 = load i8, ptr %l3, !tbaa !22
  %t49 = icmp uge i8 %t47, 97
  br i1 %t49, label %bb14, label %bb15
bb14:
  %t51 = load i8, ptr %l3, !tbaa !22
  %t53 = icmp ule i8 %t51, 122
  store i1 %t53, ptr %l34, !tbaa !21
  br label %bb16
bb15:
  store i1 false, ptr %l34, !tbaa !21
  br label %bb16
bb16:
  %t55 = load i1, ptr %l34, !tbaa !21
  br i1 %t55, label %bb17, label %bb18
bb17:
  store i1 true, ptr %l37, !tbaa !21
  br label %bb22
bb18:
  %t56 = load i8, ptr %l3, !tbaa !22
  %t58 = icmp uge i8 %t56, 65
  br i1 %t58, label %bb19, label %bb20
bb19:
  %t60 = load i8, ptr %l3, !tbaa !22
  %t62 = icmp ule i8 %t60, 90
  store i1 %t62, ptr %l40, !tbaa !21
  br label %bb21
bb20:
  store i1 false, ptr %l40, !tbaa !21
  br label %bb21
bb21:
  %t64 = load i1, ptr %l40, !tbaa !21
  store i1 %t64, ptr %l37, !tbaa !21
  br label %bb22
bb22:
  %t65 = load i1, ptr %l37, !tbaa !21
  store i1 %t65, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2ekind(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l3 = alloca { i64, ptr }
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/fmt:formatter", ptr %a0, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l3, !tbaa !27
  %t7 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t8 = load ptr, ptr %t7, !tbaa !27
  %t9 = getelementptr %"compiler/token:Token", ptr %t8, i64 %a1
  %t10 = getelementptr %"compiler/token:Token", ptr %t9, i32 0, i32 0
  %t11 = load i32, ptr %t10
  store i32 %t11, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i64 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2elevel(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i1
  %l5 = alloca i64
  %l6 = alloca i64
  %l10 = alloca i64
  %l13 = alloca i64
  %l16 = alloca i1
  %l18 = alloca i1
  %l25 = alloca i64
  %l28 = alloca i64
  %l30 = alloca i64
  %l35 = alloca i1
  %l38 = alloca i1
  %l43 = alloca i64
  %l45 = alloca i1
  %l47 = alloca i1
  %l50 = alloca i1
  %l55 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/fmt:formatter", ptr %t1, i32 0, i32 6
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t3, i64 %t4)
  store i64 %t7, ptr %l10
  br label %bb1
bb1:
  %t8 = load i64, ptr %l10, !tbaa !24
  store i64 %t8, ptr %l2, !tbaa !24
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/fmt:formatter", ptr %t9, i32 0, i32 8
  %t13 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t11)
  store i64 %t13, ptr %l13
  br label %bb2
bb2:
  %t14 = load i64, ptr %l13, !tbaa !24
  store i64 %t14, ptr %l3, !tbaa !24
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load i64, ptr %l2, !tbaa !24
  %t19 = call i1 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2eclosing(ptr %v0, ptr %t15, i64 %t16)
  store i1 %t19, ptr %l16
  br label %bb3
bb3:
  %t20 = load i1, ptr %l16, !tbaa !21
  store i1 %t20, ptr %l4, !tbaa !21
  store i64 0, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  %t21 = load i1, ptr %l4, !tbaa !21
  br i1 %t21, label %bb4, label %bb5
bb4:
  %t23 = load i64, ptr %l3, !tbaa !24
  %t25 = icmp sgt i64 %t23, 0
  store i1 %t25, ptr %l18, !tbaa !21
  br label %bb6
bb5:
  store i1 false, ptr %l18, !tbaa !21
  br label %bb6
bb6:
  %t27 = load i1, ptr %l18, !tbaa !21
  br i1 %t27, label %bb7, label %bb8
bb7:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/fmt:formatter", ptr %t28, i32 0, i32 10
  %t31 = load i64, ptr %l3, !tbaa !24
  %t33 = sub i64 %t31, 1
  %t36 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t30, i64 %t33)
  store i64 %t36, ptr %l25
  br label %bb9
bb8:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load i64, ptr %l1, !tbaa !24
  %t41 = call i64 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2econt(ptr %v0, ptr %t37, i64 %t38)
  store i64 %t41, ptr %l28
  br label %bb10
bb9:
  %t42 = load i64, ptr %l25, !tbaa !24
  store i64 %t42, ptr %l6, !tbaa !24
  br label %bb12
bb10:
  %t43 = load i64, ptr %l28, !tbaa !24
  store i64 %t43, ptr %l5, !tbaa !24
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = call i64 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2echild(ptr %v0, ptr %t44)
  store i64 %t46, ptr %l30
  br label %bb11
bb11:
  %t47 = load i64, ptr %l5, !tbaa !24
  %t48 = load i64, ptr %l30, !tbaa !24
  %t50 = add i64 %t48, %t47
  store i64 %t50, ptr %l6, !tbaa !24
  br label %bb12
bb12:
  %t52 = load i64, ptr %l5, !tbaa !24
  %t54 = icmp eq i64 %t52, 0
  br i1 %t54, label %bb13, label %bb14
bb13:
  %t56 = load i64, ptr %l3, !tbaa !24
  %t58 = icmp eq i64 %t56, 0
  br i1 %t58, label %bb15, label %bb16
bb14:
  store i1 false, ptr %l35, !tbaa !21
  br label %bb29
bb15:
  store i1 true, ptr %l38, !tbaa !21
  br label %bb18
bb16:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/fmt:formatter", ptr %t60, i32 0, i32 8
  %t63 = load i64, ptr %l3, !tbaa !24
  %t65 = sub i64 %t63, 1
  %t68 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t62, i64 %t65)
  store i64 %t68, ptr %l43
  br label %bb17
bb17:
  %t69 = load i64, ptr %l43, !tbaa !24
  %t70 = icmp eq i64 %t69, 0
  store i1 %t70, ptr %l38, !tbaa !21
  br label %bb18
bb18:
  %t72 = load i1, ptr %l38, !tbaa !21
  br i1 %t72, label %bb19, label %bb20
bb19:
  store i1 true, ptr %l45, !tbaa !21
  br label %bb28
bb20:
  %t73 = load i1, ptr %l4, !tbaa !21
  br i1 %t73, label %bb21, label %bb22
bb21:
  %t75 = load i64, ptr %l3, !tbaa !24
  %t77 = icmp sgt i64 %t75, 1
  store i1 %t77, ptr %l47, !tbaa !21
  br label %bb23
bb22:
  store i1 false, ptr %l47, !tbaa !21
  br label %bb23
bb23:
  %t79 = load i1, ptr %l47, !tbaa !21
  br i1 %t79, label %bb24, label %bb25
bb24:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t82 = getelementptr %"compiler/fmt:formatter", ptr %t80, i32 0, i32 8
  %t83 = load i64, ptr %l3, !tbaa !24
  %t85 = sub i64 %t83, 2
  %t88 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t82, i64 %t85)
  store i64 %t88, ptr %l55
  br label %bb26
bb25:
  store i1 false, ptr %l50, !tbaa !21
  br label %bb27
bb26:
  %t89 = load i64, ptr %l55, !tbaa !24
  %t90 = icmp eq i64 %t89, 0
  store i1 %t90, ptr %l50, !tbaa !21
  br label %bb27
bb27:
  %t92 = load i1, ptr %l50, !tbaa !21
  store i1 %t92, ptr %l45, !tbaa !21
  br label %bb28
bb28:
  %t93 = load i1, ptr %l45, !tbaa !21
  store i1 %t93, ptr %l35, !tbaa !21
  br label %bb29
bb29:
  %t94 = load i1, ptr %l35, !tbaa !21
  br i1 %t94, label %bb30, label %bb31
bb30:
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t96 = load i64, ptr %l6, !tbaa !24
  %t99 = getelementptr %"compiler/fmt:formatter", ptr %t95, i32 0, i32 21
  store i64 %t96, ptr %t99, !tbaa !24
  br label %bb32
bb31:
  br label %bb32
bb32:
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t101 = load i64, ptr %l6, !tbaa !24
  %t104 = getelementptr %"compiler/fmt:formatter", ptr %t100, i32 0, i32 20
  store i64 %t101, ptr %t104, !tbaa !24
  %t105 = load i64, ptr %l6, !tbaa !24
  store i64 %t105, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2elevelAt(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l4 = alloca i64
  %l8 = alloca i64
  %l11 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i64 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2echild(ptr %v0, ptr %t1)
  store i64 %t3, ptr %l4
  br label %bb1
bb1:
  %t4 = load i64, ptr %l4, !tbaa !24
  store i64 %t4, ptr %l2, !tbaa !24
  %t5 = load i64, ptr %l1, !tbaa !24
  %t7 = icmp slt i64 %t5, 0
  br i1 %t7, label %bb2, label %bb3
bb2:
  %t9 = load i64, ptr %l2, !tbaa !24
  store i64 %t9, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t11 = load i64, ptr %l2, !tbaa !24
  store i64 %t11, ptr %l8, !tbaa !24
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load i64, ptr %l1, !tbaa !24
  %t16 = call i64 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2econt(ptr %v0, ptr %t12, i64 %t13)
  store i64 %t16, ptr %l11
  br label %bb5
bb5:
  %t17 = load i64, ptr %l8, !tbaa !24
  %t18 = load i64, ptr %l11, !tbaa !24
  %t19 = add i64 %t17, %t18
  store i64 %t19, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2eoperandEnd(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l5 = alloca i32
  %l7 = alloca { i64, ptr }
  %l12 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  %t5 = call i32 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2ekind(ptr %v0, ptr %t1, i64 %t2)
  store i32 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i32, ptr %l5
  store i32 %t6, ptr %l2
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/fmt:formatter", ptr %t7, i32 0, i32 4
  %t10 = load { i64, ptr }, ptr %t9, !tbaa !27
  store { i64, ptr } %t10, ptr %l7, !tbaa !27
  %t11 = load i64, ptr %l1, !tbaa !24
  %t13 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !27
  %t15 = getelementptr i64, ptr %t14, i64 %t11
  %t16 = load i64, ptr %t15, !tbaa !34
  %t18 = icmp sgt i64 %t16, 0
  br i1 %t18, label %bb2, label %bb3
bb2:
  store i1 true, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t21 = load i32, ptr %l2
  %t23 = trunc i64 1 to i32
  %t24 = icmp eq i32 %t21, %t23
  br i1 %t24, label %bb5, label %bb6
bb5:
  br label %bb15
bb6:
  %t26 = load i32, ptr %l2
  %t28 = trunc i64 2 to i32
  %t29 = icmp eq i32 %t26, %t28
  br i1 %t29, label %bb7, label %bb8
bb7:
  br label %bb15
bb8:
  %t31 = load i32, ptr %l2
  %t33 = trunc i64 3 to i32
  %t34 = icmp eq i32 %t31, %t33
  br i1 %t34, label %bb9, label %bb10
bb9:
  br label %bb15
bb10:
  %t36 = load i32, ptr %l2
  %t38 = trunc i64 4 to i32
  %t39 = icmp eq i32 %t36, %t38
  br i1 %t39, label %bb11, label %bb12
bb11:
  br label %bb15
bb12:
  %t41 = load i32, ptr %l2
  %t43 = trunc i64 5 to i32
  %t44 = icmp eq i32 %t41, %t43
  br i1 %t44, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb35
bb16:
  %t46 = load i32, ptr %l2
  %t48 = trunc i64 6 to i32
  %t49 = icmp eq i32 %t46, %t48
  br i1 %t49, label %bb17, label %bb18
bb17:
  br label %bb27
bb18:
  %t51 = load i32, ptr %l2
  %t53 = trunc i64 7 to i32
  %t54 = icmp eq i32 %t51, %t53
  br i1 %t54, label %bb19, label %bb20
bb19:
  br label %bb27
bb20:
  %t56 = load i32, ptr %l2
  %t58 = trunc i64 89 to i32
  %t59 = icmp eq i32 %t56, %t58
  br i1 %t59, label %bb21, label %bb22
bb21:
  br label %bb27
bb22:
  %t61 = load i32, ptr %l2
  %t63 = trunc i64 91 to i32
  %t64 = icmp eq i32 %t61, %t63
  br i1 %t64, label %bb23, label %bb24
bb23:
  br label %bb27
bb24:
  %t66 = load i32, ptr %l2
  %t68 = trunc i64 93 to i32
  %t69 = icmp eq i32 %t66, %t68
  br i1 %t69, label %bb25, label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb28
bb27:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb35
bb28:
  %t71 = load i32, ptr %l2
  %t73 = trunc i64 71 to i32
  %t74 = icmp eq i32 %t71, %t73
  br i1 %t74, label %bb29, label %bb30
bb29:
  br label %bb33
bb30:
  %t76 = load i32, ptr %l2
  %t78 = trunc i64 72 to i32
  %t79 = icmp eq i32 %t76, %t78
  br i1 %t79, label %bb31, label %bb32
bb31:
  br label %bb33
bb32:
  br label %bb34
bb33:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb35
bb34:
  store i1 false, ptr %l12, !tbaa !21
  br label %bb35
bb35:
  %t81 = load i1, ptr %l12, !tbaa !21
  store i1 %t81, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2eparams(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca i64
  %l10 = alloca i1
  %l13 = alloca i32
  %l15 = alloca i32
  %l17 = alloca i1
  %l26 = alloca i32
  %l27 = alloca i32
  %l29 = alloca i32
  %l31 = alloca i1
  %l32 = alloca i1
  %l33 = alloca i32
  %l35 = alloca i32
  %l37 = alloca i1
  %l39 = alloca i32
  %l41 = alloca i32
  %l43 = alloca i1
  %l45 = alloca i1
  %l48 = alloca i1
  %l55 = alloca i1
  %l58 = alloca i32
  %l60 = alloca i32
  %l62 = alloca i1
  %l68 = alloca i1
  %l71 = alloca i32
  %l73 = alloca i32
  %l75 = alloca i1
  %l79 = alloca i1
  %l82 = alloca i32
  %l84 = alloca i32
  %l86 = alloca i1
  %l88 = alloca { i64, ptr }
  %l94 = alloca i1
  %l97 = alloca i32
  %l99 = alloca i32
  %l101 = alloca i1
  %l107 = alloca i1
  %l110 = alloca i32
  %l112 = alloca i32
  %l114 = alloca i1
  %l118 = alloca i1
  %l121 = alloca i32
  %l123 = alloca i32
  %l125 = alloca i1
  %l126 = alloca i1
  %l128 = alloca { i64, ptr }
  %l132 = alloca i1
  %s1 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t3 = sub i64 %a1, 1
  store i64 %t3, ptr %l2, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t5 = load i64, ptr %l2, !tbaa !24
  %t7 = icmp sge i64 %t5, 0
  br i1 %t7, label %bb2, label %bb3
bb2:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t10 = load i64, ptr %l2, !tbaa !24
  %t13 = call i32 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2ekind(ptr %v0, ptr %t9, i64 %t10)
  store i32 %t13, ptr %l13
  br label %bb4
bb3:
  store i1 false, ptr %l10, !tbaa !21
  br label %bb6
bb4:
  store i32 8, ptr %l15
  %t16 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l13, ptr %l15)
  store i1 %t16, ptr %l17
  br label %bb5
bb5:
  %t17 = load i1, ptr %l17, !tbaa !21
  store i1 %t17, ptr %l10, !tbaa !21
  br label %bb6
bb6:
  %t18 = load i1, ptr %l10, !tbaa !21
  %t19 = xor i1 %t18, true
  br i1 %t19, label %bb7, label %bb8
bb7:
  call void @__olang_scope_close(ptr %s1)
  br label %bb11
bb8:
  br label %bb9
bb9:
  %t21 = load i64, ptr %l2, !tbaa !24
  %t23 = sub i64 %t21, 1
  store i64 %t23, ptr %l2, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  br label %bb10
bb10:
  br label %bb1
bb11:
  %t25 = load i64, ptr %l2, !tbaa !24
  %t27 = icmp slt i64 %t25, 0
  br i1 %t27, label %bb12, label %bb13
bb12:
  store i64 0, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t31 = load i64, ptr %l2, !tbaa !24
  %t34 = call i32 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2ekind(ptr %v0, ptr %t30, i64 %t31)
  store i32 %t34, ptr %l26
  br label %bb15
bb15:
  %t35 = load i32, ptr %l26
  store i32 %t35, ptr %l3
  %t36 = load i32, ptr %l3
  store i32 %t36, ptr %l27
  store i32 37, ptr %l29
  %t39 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l27, ptr %l29)
  store i1 %t39, ptr %l31
  br label %bb16
bb16:
  %t40 = load i1, ptr %l31, !tbaa !21
  br i1 %t40, label %bb17, label %bb18
bb17:
  store i1 true, ptr %l32, !tbaa !21
  br label %bb20
bb18:
  %t41 = load i32, ptr %l3
  store i32 %t41, ptr %l33
  store i32 34, ptr %l35
  %t44 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l33, ptr %l35)
  store i1 %t44, ptr %l37
  br label %bb19
bb19:
  %t45 = load i1, ptr %l37, !tbaa !21
  store i1 %t45, ptr %l32, !tbaa !21
  br label %bb20
bb20:
  %t46 = load i1, ptr %l32, !tbaa !21
  br i1 %t46, label %bb21, label %bb22
bb21:
  store i64 1, ptr %rv
  br label %ret
bb22:
  br label %bb23
bb23:
  %t48 = load i32, ptr %l3
  store i32 %t48, ptr %l39
  store i32 1, ptr %l41
  %t51 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l39, ptr %l41)
  store i1 %t51, ptr %l43
  br label %bb24
bb24:
  %t52 = load i1, ptr %l43, !tbaa !21
  %t53 = xor i1 %t52, true
  br i1 %t53, label %bb25, label %bb26
bb25:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t56 = load i64, ptr %l2, !tbaa !24
  %t59 = call i1 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2ekeyword(ptr %v0, ptr %t55, i64 %t56)
  store i1 %t59, ptr %l48
  br label %bb27
bb26:
  store i1 false, ptr %l45, !tbaa !21
  br label %bb28
bb27:
  %t60 = load i1, ptr %l48, !tbaa !21
  %t61 = xor i1 %t60, true
  store i1 %t61, ptr %l45, !tbaa !21
  br label %bb28
bb28:
  %t63 = load i1, ptr %l45, !tbaa !21
  br i1 %t63, label %bb29, label %bb30
bb29:
  store i64 0, ptr %rv
  br label %ret
bb30:
  br label %bb31
bb31:
  %t65 = load i64, ptr %l2, !tbaa !24
  %t67 = sub i64 %t65, 1
  store i64 %t67, ptr %l4, !tbaa !24
  br label %bb32
bb32:
  store %olang.scope zeroinitializer, ptr %s5
  %t69 = load i64, ptr %l4, !tbaa !24
  %t71 = icmp sge i64 %t69, 0
  br i1 %t71, label %bb33, label %bb34
bb33:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t74 = load i64, ptr %l4, !tbaa !24
  %t77 = call i32 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2ekind(ptr %v0, ptr %t73, i64 %t74)
  store i32 %t77, ptr %l58
  br label %bb35
bb34:
  store i1 false, ptr %l55, !tbaa !21
  br label %bb37
bb35:
  store i32 8, ptr %l60
  %t80 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l58, ptr %l60)
  store i1 %t80, ptr %l62
  br label %bb36
bb36:
  %t81 = load i1, ptr %l62, !tbaa !21
  store i1 %t81, ptr %l55, !tbaa !21
  br label %bb37
bb37:
  %t82 = load i1, ptr %l55, !tbaa !21
  %t83 = xor i1 %t82, true
  br i1 %t83, label %bb38, label %bb39
bb38:
  call void @__olang_scope_close(ptr %s5)
  br label %bb42
bb39:
  br label %bb40
bb40:
  %t85 = load i64, ptr %l4, !tbaa !24
  %t87 = sub i64 %t85, 1
  store i64 %t87, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s5)
  br label %bb41
bb41:
  br label %bb32
bb42:
  %t89 = load i64, ptr %l4, !tbaa !24
  %t91 = icmp sge i64 %t89, 0
  br i1 %t91, label %bb43, label %bb44
bb43:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t94 = load i64, ptr %l4, !tbaa !24
  %t97 = call i32 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2ekind(ptr %v0, ptr %t93, i64 %t94)
  store i32 %t97, ptr %l71
  br label %bb45
bb44:
  store i1 false, ptr %l68, !tbaa !21
  br label %bb47
bb45:
  store i32 37, ptr %l73
  %t100 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l71, ptr %l73)
  store i1 %t100, ptr %l75
  br label %bb46
bb46:
  %t101 = load i1, ptr %l75, !tbaa !21
  store i1 %t101, ptr %l68, !tbaa !21
  br label %bb47
bb47:
  %t102 = load i1, ptr %l68, !tbaa !21
  br i1 %t102, label %bb48, label %bb49
bb48:
  store i64 1, ptr %rv
  br label %ret
bb49:
  br label %bb50
bb50:
  %t104 = load i64, ptr %l4, !tbaa !24
  %t106 = icmp sge i64 %t104, 0
  br i1 %t106, label %bb51, label %bb52
bb51:
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t109 = load i64, ptr %l4, !tbaa !24
  %t112 = call i32 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2ekind(ptr %v0, ptr %t108, i64 %t109)
  store i32 %t112, ptr %l82
  br label %bb53
bb52:
  store i1 false, ptr %l79, !tbaa !21
  br label %bb55
bb53:
  store i32 89, ptr %l84
  %t115 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l82, ptr %l84)
  store i1 %t115, ptr %l86
  br label %bb54
bb54:
  %t116 = load i1, ptr %l86, !tbaa !21
  store i1 %t116, ptr %l79, !tbaa !21
  br label %bb55
bb55:
  %t117 = load i1, ptr %l79, !tbaa !21
  br i1 %t117, label %bb56, label %bb57
bb56:
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t120 = getelementptr %"compiler/fmt:formatter", ptr %t118, i32 0, i32 22
  %t121 = load { i64, ptr }, ptr %t120, !tbaa !27
  store { i64, ptr } %t121, ptr %l88, !tbaa !27
  %t122 = load i64, ptr %l4, !tbaa !24
  %t124 = getelementptr { i64, ptr }, ptr %l88, i32 0, i32 1
  %t125 = load ptr, ptr %t124, !tbaa !27
  %t126 = getelementptr i64, ptr %t125, i64 %t122
  %t127 = load i64, ptr %t126, !tbaa !34
  %t129 = sub i64 %t127, 1
  store i64 %t129, ptr %l5, !tbaa !24
  br label %bb58
bb57:
  br label %bb77
bb58:
  store %olang.scope zeroinitializer, ptr %s8
  %t131 = load i64, ptr %l5, !tbaa !24
  %t133 = icmp sge i64 %t131, 0
  br i1 %t133, label %bb59, label %bb60
bb59:
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t136 = load i64, ptr %l5, !tbaa !24
  %t139 = call i32 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2ekind(ptr %v0, ptr %t135, i64 %t136)
  store i32 %t139, ptr %l97
  br label %bb61
bb60:
  store i1 false, ptr %l94, !tbaa !21
  br label %bb63
bb61:
  store i32 8, ptr %l99
  %t142 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l97, ptr %l99)
  store i1 %t142, ptr %l101
  br label %bb62
bb62:
  %t143 = load i1, ptr %l101, !tbaa !21
  store i1 %t143, ptr %l94, !tbaa !21
  br label %bb63
bb63:
  %t144 = load i1, ptr %l94, !tbaa !21
  %t145 = xor i1 %t144, true
  br i1 %t145, label %bb64, label %bb65
bb64:
  call void @__olang_scope_close(ptr %s8)
  br label %bb68
bb65:
  br label %bb66
bb66:
  %t147 = load i64, ptr %l5, !tbaa !24
  %t149 = sub i64 %t147, 1
  store i64 %t149, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s8)
  br label %bb67
bb67:
  br label %bb58
bb68:
  %t151 = load i64, ptr %l5, !tbaa !24
  %t153 = icmp sge i64 %t151, 0
  br i1 %t153, label %bb69, label %bb70
bb69:
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t156 = load i64, ptr %l5, !tbaa !24
  %t159 = call i32 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2ekind(ptr %v0, ptr %t155, i64 %t156)
  store i32 %t159, ptr %l110
  br label %bb71
bb70:
  store i1 false, ptr %l107, !tbaa !21
  br label %bb73
bb71:
  store i32 37, ptr %l112
  %t162 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l110, ptr %l112)
  store i1 %t162, ptr %l114
  br label %bb72
bb72:
  %t163 = load i1, ptr %l114, !tbaa !21
  store i1 %t163, ptr %l107, !tbaa !21
  br label %bb73
bb73:
  %t164 = load i1, ptr %l107, !tbaa !21
  br i1 %t164, label %bb74, label %bb75
bb74:
  store i64 1, ptr %rv
  br label %ret
bb75:
  br label %bb76
bb76:
  br label %bb77
bb77:
  %t166 = load i64, ptr %l4, !tbaa !24
  %t168 = icmp slt i64 %t166, 0
  br i1 %t168, label %bb78, label %bb79
bb78:
  store i1 true, ptr %l118, !tbaa !21
  br label %bb82
bb79:
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t171 = load i64, ptr %l4, !tbaa !24
  %t174 = call i32 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2ekind(ptr %v0, ptr %t170, i64 %t171)
  store i32 %t174, ptr %l121
  br label %bb80
bb80:
  store i32 92, ptr %l123
  %t177 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l121, ptr %l123)
  store i1 %t177, ptr %l125
  br label %bb81
bb81:
  %t178 = load i1, ptr %l125, !tbaa !21
  store i1 %t178, ptr %l118, !tbaa !21
  br label %bb82
bb82:
  %t179 = load i1, ptr %l118, !tbaa !21
  br i1 %t179, label %bb83, label %bb84
bb83:
  store i1 true, ptr %l126, !tbaa !21
  br label %bb86
bb84:
  %t180 = load ptr, ptr %l0, !tbaa !29
  %t182 = getelementptr %"compiler/fmt:formatter", ptr %t180, i32 0, i32 1
  %t183 = load { i64, ptr }, ptr %t182, !tbaa !27
  store { i64, ptr } %t183, ptr %l128, !tbaa !27
  %t184 = load i64, ptr %l2, !tbaa !24
  %t186 = getelementptr { i64, ptr }, ptr %l128, i32 0, i32 1
  %t187 = load ptr, ptr %t186, !tbaa !27
  %t188 = getelementptr %"compiler/token:Token", ptr %t187, i64 %t184
  %t189 = load %"compiler/token:Token", ptr %t188
  %t190 = load i8, ptr @G_2ecompiler_2ftoken_2eLineBreak, !tbaa !22
  %t193 = call i1 @compiler_2ftoken_2ecompiler_2ftoken_3aToken_2eHas(%"compiler/token:Token" %t189, i8 %t190)
  store i1 %t193, ptr %l132
  br label %bb85
bb85:
  %t194 = load i1, ptr %l132, !tbaa !21
  store i1 %t194, ptr %l126, !tbaa !21
  br label %bb86
bb86:
  %t195 = load i1, ptr %l126, !tbaa !21
  br i1 %t195, label %bb87, label %bb88
bb87:
  store i64 2, ptr %rv
  br label %ret
bb88:
  br label %bb89
bb89:
  store i64 0, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2eprefix(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i64
  %l7 = alloca i32
  %l8 = alloca i32
  %l10 = alloca i32
  %l12 = alloca i1
  %l13 = alloca i1
  %l14 = alloca i32
  %l16 = alloca i32
  %l18 = alloca i1
  %l20 = alloca i32
  %l22 = alloca i32
  %l24 = alloca i1
  %l26 = alloca i1
  %l27 = alloca i32
  %l29 = alloca i32
  %l31 = alloca i1
  %l33 = alloca i1
  %l34 = alloca i32
  %l36 = alloca i32
  %l38 = alloca i1
  %l43 = alloca i64
  %l46 = alloca i1
  %l49 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i32 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2ekind(ptr %v0, ptr %t1, i64 %a1)
  store i32 %t5, ptr %l7
  br label %bb1
bb1:
  %t6 = load i32, ptr %l7
  store i32 %t6, ptr %l3
  %t7 = load i32, ptr %l3
  store i32 %t7, ptr %l8
  store i32 84, ptr %l10
  %t10 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l8, ptr %l10)
  store i1 %t10, ptr %l12
  br label %bb2
bb2:
  %t11 = load i1, ptr %l12, !tbaa !21
  br i1 %t11, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l13, !tbaa !21
  br label %bb6
bb4:
  %t12 = load i32, ptr %l3
  store i32 %t12, ptr %l14
  store i32 85, ptr %l16
  %t15 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l14, ptr %l16)
  store i1 %t15, ptr %l18
  br label %bb5
bb5:
  %t16 = load i1, ptr %l18, !tbaa !21
  store i1 %t16, ptr %l13, !tbaa !21
  br label %bb6
bb6:
  %t17 = load i1, ptr %l13, !tbaa !21
  br i1 %t17, label %bb7, label %bb8
bb7:
  store i1 true, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t19 = load i32, ptr %l3
  store i32 %t19, ptr %l20
  store i32 50, ptr %l22
  %t22 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l20, ptr %l22)
  store i1 %t22, ptr %l24
  br label %bb10
bb10:
  %t23 = load i1, ptr %l24, !tbaa !21
  %t24 = xor i1 %t23, true
  br i1 %t24, label %bb11, label %bb12
bb11:
  %t26 = load i32, ptr %l3
  store i32 %t26, ptr %l27
  store i32 71, ptr %l29
  %t29 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l27, ptr %l29)
  store i1 %t29, ptr %l31
  br label %bb13
bb12:
  store i1 false, ptr %l26, !tbaa !21
  br label %bb14
bb13:
  %t30 = load i1, ptr %l31, !tbaa !21
  %t31 = xor i1 %t30, true
  store i1 %t31, ptr %l26, !tbaa !21
  br label %bb14
bb14:
  %t33 = load i1, ptr %l26, !tbaa !21
  br i1 %t33, label %bb15, label %bb16
bb15:
  %t34 = load i32, ptr %l3
  store i32 %t34, ptr %l34
  store i32 72, ptr %l36
  %t37 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l34, ptr %l36)
  store i1 %t37, ptr %l38
  br label %bb17
bb16:
  store i1 false, ptr %l33, !tbaa !21
  br label %bb18
bb17:
  %t38 = load i1, ptr %l38, !tbaa !21
  %t39 = xor i1 %t38, true
  store i1 %t39, ptr %l33, !tbaa !21
  br label %bb18
bb18:
  %t41 = load i1, ptr %l33, !tbaa !21
  br i1 %t41, label %bb19, label %bb20
bb19:
  store i1 false, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t47 = call i64 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2ebefore(ptr %v0, ptr %t43, i64 %a2)
  store i64 %t47, ptr %l43
  br label %bb22
bb22:
  %t48 = load i64, ptr %l43, !tbaa !24
  store i64 %t48, ptr %l4, !tbaa !24
  %t49 = load i64, ptr %l4, !tbaa !24
  %t51 = icmp slt i64 %t49, 0
  br i1 %t51, label %bb23, label %bb24
bb23:
  store i1 true, ptr %l46, !tbaa !21
  br label %bb26
bb24:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t54 = load i64, ptr %l4, !tbaa !24
  %t57 = call i1 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2eoperandEnd(ptr %v0, ptr %t53, i64 %t54)
  store i1 %t57, ptr %l49
  br label %bb25
bb25:
  %t58 = load i1, ptr %l49, !tbaa !21
  %t59 = xor i1 %t58, true
  store i1 %t59, ptr %l46, !tbaa !21
  br label %bb26
bb26:
  %t61 = load i1, ptr %l46, !tbaa !21
  store i1 %t61, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2epush(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/fmt:formatter", ptr %t1, i32 0, i32 8
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t3, i64 %a1)
  br label %bb1
bb1:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/fmt:formatter", ptr %t7, i32 0, i32 9
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t9, i64 %a2)
  br label %bb2
bb2:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/fmt:formatter", ptr %t13, i32 0, i32 10
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t15, i64 %a3)
  br label %bb3
bb3:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2ereceiver(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i32
  %l6 = alloca i64
  %l9 = alloca i64
  %l12 = alloca i64
  %l15 = alloca ptr
  %l19 = alloca i64
  %l20 = alloca i32
  %l21 = alloca i32
  %l23 = alloca i32
  %l25 = alloca i1
  %l28 = alloca i32
  %l30 = alloca i32
  %l32 = alloca i1
  %l40 = alloca i64
  %l43 = alloca i64
  %l50 = alloca i64
  %l53 = alloca i32
  %l55 = alloca i32
  %l57 = alloca i1
  %l58 = alloca i1
  %l61 = alloca i1
  %l62 = alloca i1
  %l63 = alloca ptr
  %l68 = alloca i64
  %l69 = alloca i32
  %l71 = alloca i32
  %l73 = alloca i1
  %s1 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l3, !tbaa !24
  %t3 = add i64 %a2, 1
  store i64 %t3, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t5 = load i64, ptr %l4, !tbaa !24
  store i64 %t5, ptr %l9, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/fmt:formatter", ptr %t6, i32 0, i32 6
  %t10 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t8)
  store i64 %t10, ptr %l12
  br label %bb2
bb2:
  %t11 = load i64, ptr %l9, !tbaa !24
  %t12 = load i64, ptr %l12, !tbaa !24
  %t13 = icmp slt i64 %t11, %t12
  %t15 = xor i1 %t13, true
  br i1 %t15, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s1)
  br label %bb20
bb4:
  br label %bb5
bb5:
  %t17 = load ptr, ptr %l0, !tbaa !29
  store ptr %t17, ptr %l15, !tbaa !29
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/fmt:formatter", ptr %t18, i32 0, i32 6
  %t21 = load i64, ptr %l4, !tbaa !24
  %t24 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t20, i64 %t21)
  store i64 %t24, ptr %l19
  br label %bb6
bb6:
  %t25 = load ptr, ptr %l15, !tbaa !29
  %t26 = load i64, ptr %l19, !tbaa !24
  %t27 = call i32 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2ekind(ptr %v0, ptr %t25, i64 %t26)
  store i32 %t27, ptr %l20
  br label %bb7
bb7:
  %t28 = load i32, ptr %l20
  store i32 %t28, ptr %l5
  %t29 = load i32, ptr %l5
  store i32 %t29, ptr %l21
  store i32 88, ptr %l23
  %t32 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l21, ptr %l23)
  store i1 %t32, ptr %l25
  br label %bb8
bb8:
  %t33 = load i1, ptr %l25, !tbaa !21
  br i1 %t33, label %bb9, label %bb10
bb9:
  %t34 = load i64, ptr %l3, !tbaa !24
  %t36 = add i64 %t34, 1
  store i64 %t36, ptr %l3, !tbaa !24
  br label %bb11
bb10:
  br label %bb11
bb11:
  %t38 = load i32, ptr %l5
  store i32 %t38, ptr %l28
  store i32 89, ptr %l30
  %t41 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l28, ptr %l30)
  store i1 %t41, ptr %l32
  br label %bb12
bb12:
  %t42 = load i1, ptr %l32, !tbaa !21
  br i1 %t42, label %bb13, label %bb14
bb13:
  %t43 = load i64, ptr %l3, !tbaa !24
  %t45 = sub i64 %t43, 1
  store i64 %t45, ptr %l3, !tbaa !24
  %t47 = load i64, ptr %l3, !tbaa !24
  %t49 = icmp eq i64 %t47, 0
  br i1 %t49, label %bb15, label %bb16
bb14:
  br label %bb18
bb15:
  call void @__olang_scope_close(ptr %s1)
  br label %bb20
bb16:
  br label %bb17
bb17:
  br label %bb18
bb18:
  %t51 = load i64, ptr %l4, !tbaa !24
  %t53 = add i64 %t51, 1
  store i64 %t53, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  br label %bb19
bb19:
  br label %bb1
bb20:
  %t55 = load i64, ptr %l4, !tbaa !24
  %t57 = add i64 %t55, 2
  store i64 %t57, ptr %l40, !tbaa !24
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/fmt:formatter", ptr %t58, i32 0, i32 6
  %t62 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t60)
  store i64 %t62, ptr %l43
  br label %bb21
bb21:
  %t63 = load i64, ptr %l40, !tbaa !24
  %t64 = load i64, ptr %l43, !tbaa !24
  %t65 = icmp sge i64 %t63, %t64
  br i1 %t65, label %bb22, label %bb23
bb22:
  store i1 false, ptr %rv
  br label %ret
bb23:
  br label %bb24
bb24:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/fmt:formatter", ptr %t68, i32 0, i32 6
  %t71 = load i64, ptr %l4, !tbaa !24
  %t73 = add i64 %t71, 1
  %t76 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t70, i64 %t73)
  store i64 %t76, ptr %l50
  br label %bb25
bb25:
  %t77 = load i64, ptr %l50, !tbaa !24
  store i64 %t77, ptr %l6, !tbaa !24
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t79 = load i64, ptr %l6, !tbaa !24
  %t82 = call i32 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2ekind(ptr %v0, ptr %t78, i64 %t79)
  store i32 %t82, ptr %l53
  br label %bb26
bb26:
  store i32 1, ptr %l55
  %t85 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l53, ptr %l55)
  store i1 %t85, ptr %l57
  br label %bb27
bb27:
  %t86 = load i1, ptr %l57, !tbaa !21
  br i1 %t86, label %bb28, label %bb29
bb28:
  store i1 true, ptr %l58, !tbaa !21
  br label %bb31
bb29:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t88 = load i64, ptr %l6, !tbaa !24
  %t91 = call i1 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2ekeyword(ptr %v0, ptr %t87, i64 %t88)
  store i1 %t91, ptr %l61
  br label %bb30
bb30:
  %t92 = load i1, ptr %l61, !tbaa !21
  store i1 %t92, ptr %l58, !tbaa !21
  br label %bb31
bb31:
  %t93 = load i1, ptr %l58, !tbaa !21
  br i1 %t93, label %bb32, label %bb33
bb32:
  %t94 = load ptr, ptr %l0, !tbaa !29
  store ptr %t94, ptr %l63, !tbaa !29
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t97 = getelementptr %"compiler/fmt:formatter", ptr %t95, i32 0, i32 6
  %t98 = load i64, ptr %l4, !tbaa !24
  %t100 = add i64 %t98, 2
  %t103 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t97, i64 %t100)
  store i64 %t103, ptr %l68
  br label %bb34
bb33:
  store i1 false, ptr %l62, !tbaa !21
  br label %bb37
bb34:
  %t104 = load ptr, ptr %l63, !tbaa !29
  %t105 = load i64, ptr %l68, !tbaa !24
  %t106 = call i32 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2ekind(ptr %v0, ptr %t104, i64 %t105)
  store i32 %t106, ptr %l69
  br label %bb35
bb35:
  store i32 88, ptr %l71
  %t109 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l69, ptr %l71)
  store i1 %t109, ptr %l73
  br label %bb36
bb36:
  %t110 = load i1, ptr %l73, !tbaa !21
  store i1 %t110, ptr %l62, !tbaa !21
  br label %bb37
bb37:
  %t111 = load i1, ptr %l62, !tbaa !21
  store i1 %t111, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2erun(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i1
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i32
  %l9 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i32
  %l17 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l18 = alloca ptr
  %l19 = alloca i64
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i32
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i1
  %l46 = alloca i64
  %l49 = alloca i64
  %l68 = alloca { i64, ptr }
  %l71 = alloca i32
  %l73 = alloca i32
  %l75 = alloca i1
  %l76 = alloca i32
  %l78 = alloca i32
  %l80 = alloca i1
  %l90 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l93 = alloca { i64, ptr }
  %l96 = alloca { i64, ptr }
  %l97 = alloca i32
  %l106 = alloca { i64, ptr }
  %l111 = alloca i32
  %l112 = alloca i32
  %l114 = alloca i32
  %l116 = alloca i1
  %l119 = alloca i32
  %l121 = alloca i32
  %l123 = alloca i1
  %l124 = alloca i1
  %l126 = alloca i64
  %l129 = alloca { i64, ptr }
  %l130 = alloca i64
  %l131 = alloca i64
  %l133 = alloca i64
  %l134 = alloca i32
  %l140 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l143 = alloca { i64, ptr }
  %l146 = alloca { i64, ptr }
  %l147 = alloca i32
  %l156 = alloca { i64, ptr }
  %l161 = alloca i32
  %l162 = alloca i32
  %l164 = alloca i32
  %l166 = alloca i1
  %l167 = alloca i1
  %l168 = alloca i32
  %l170 = alloca i32
  %l172 = alloca i1
  %l173 = alloca i1
  %l174 = alloca i32
  %l176 = alloca i32
  %l178 = alloca i1
  %l181 = alloca i32
  %l183 = alloca i32
  %l185 = alloca i1
  %l186 = alloca i1
  %l187 = alloca i32
  %l189 = alloca i32
  %l191 = alloca i1
  %l192 = alloca i1
  %l193 = alloca i32
  %l195 = alloca i32
  %l197 = alloca i1
  %l198 = alloca i1
  %l200 = alloca i64
  %l202 = alloca i32
  %l204 = alloca i32
  %l205 = alloca i32
  %l209 = alloca i32
  %l211 = alloca i32
  %l213 = alloca i1
  %l215 = alloca { i64, ptr }
  %l216 = alloca i64
  %l218 = alloca i64
  %l220 = alloca i1
  %l221 = alloca i32
  %l223 = alloca i32
  %l224 = alloca i32
  %l227 = alloca i32
  %l229 = alloca i1
  %l235 = alloca i64
  %l238 = alloca i64
  %l244 = alloca i64
  %l247 = alloca { i64, ptr }
  %l251 = alloca i64
  %l257 = alloca i64
  %l261 = alloca i64
  %l264 = alloca i64
  %l268 = alloca i64
  %l271 = alloca i64
  %l292 = alloca i64
  %l295 = alloca i1
  %l299 = alloca i64
  %l305 = alloca i64
  %l319 = alloca i1
  %l330 = alloca i64
  %l334 = alloca ptr
  %l336 = alloca { i64, ptr }
  %l337 = alloca i64
  %l338 = alloca i64
  %l339 = alloca i64
  %l344 = alloca i64
  %l347 = alloca i64
  %l349 = alloca i1
  %l351 = alloca { i64, ptr }
  %l355 = alloca i64
  %l364 = alloca i64
  %l365 = alloca ptr
  %l369 = alloca i64
  %l370 = alloca ptr
  %l374 = alloca i64
  %l385 = alloca i64
  %l393 = alloca { i64, ptr }
  %l401 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %s27 = alloca %olang.scope
  %s28 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i1 false, ptr %l1, !tbaa !21
  store i64 0, ptr %l2, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/fmt:formatter", ptr %t1, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  store i64 %t6, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t8 = load i64, ptr %l3, !tbaa !24
  %t9 = load i64, ptr %l2, !tbaa !24
  %t12 = icmp sgt i64 %t8, %t9
  br i1 %t12, label %bb1, label %bb2
bb1:
  %t14 = load i64, ptr %l4, !tbaa !24
  %t16 = icmp sgt i64 %t14, 0
  br i1 %t16, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l46, !tbaa !24
  br label %bb6
bb3:
  %t18 = load i64, ptr %l3, !tbaa !24
  %t19 = load i64, ptr %l2, !tbaa !24
  %t22 = sub i64 %t18, %t19
  %t23 = load i64, ptr %l4, !tbaa !24
  %t26 = add i64 %t22, %t23
  %t28 = sub i64 %t26, 1
  %t29 = load i64, ptr %l4, !tbaa !24
  %t32 = sdiv i64 %t28, %t29
  store i64 %t32, ptr %l49, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l49, !tbaa !24
  br label %bb5
bb5:
  %t34 = load i64, ptr %l49, !tbaa !24
  store i64 %t34, ptr %l46, !tbaa !24
  br label %bb6
bb6:
  %t35 = load i64, ptr %l46, !tbaa !24
  store i64 %t35, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t36 = load i64, ptr %l6, !tbaa !24
  %t37 = load i64, ptr %l5, !tbaa !24
  %t40 = icmp slt i64 %t36, %t37
  %t42 = xor i1 %t40, true
  br i1 %t42, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb22
bb9:
  br label %bb10
bb10:
  %t44 = load i64, ptr %l2, !tbaa !24
  %t45 = load i64, ptr %l6, !tbaa !24
  %t46 = load i64, ptr %l4, !tbaa !24
  %t49 = mul i64 %t45, %t46
  %t52 = add i64 %t44, %t49
  store i64 %t52, ptr %l7, !tbaa !24
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/fmt:formatter", ptr %t54, i32 0, i32 1
  %t57 = load { i64, ptr }, ptr %t56, !tbaa !27
  store { i64, ptr } %t57, ptr %l68, !tbaa !27
  %t58 = load i64, ptr %l7, !tbaa !24
  %t60 = getelementptr { i64, ptr }, ptr %l68, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !27
  %t62 = getelementptr %"compiler/token:Token", ptr %t61, i64 %t58
  %t63 = getelementptr %"compiler/token:Token", ptr %t62, i32 0, i32 0
  %t64 = load i32, ptr %t63
  store i32 %t64, ptr %l8
  %t66 = load i32, ptr %l8
  store i32 %t66, ptr %l71
  store i32 8, ptr %l73
  %t69 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l71, ptr %l73)
  store i1 %t69, ptr %l75
  br label %bb11
bb11:
  %t70 = load i1, ptr %l75, !tbaa !21
  br i1 %t70, label %bb12, label %bb13
bb12:
  store i1 true, ptr %l1, !tbaa !21
  br label %bb20
bb13:
  %t71 = load i32, ptr %l8
  store i32 %t71, ptr %l76
  store i32 0, ptr %l78
  %t74 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l76, ptr %l78)
  store i1 %t74, ptr %l80
  br label %bb14
bb14:
  %t75 = load i1, ptr %l80, !tbaa !21
  %t76 = xor i1 %t75, true
  br i1 %t76, label %bb15, label %bb16
bb15:
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t80 = getelementptr %"compiler/fmt:formatter", ptr %t78, i32 0, i32 6
  %t81 = load i64, ptr %l7, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t80, i64 %t81)
  br label %bb17
bb16:
  br label %bb19
bb17:
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr %"compiler/fmt:formatter", ptr %t84, i32 0, i32 7
  %t87 = load i1, ptr %l1, !tbaa !21
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t86, i1 %t87)
  br label %bb18
bb18:
  store i1 false, ptr %l1, !tbaa !21
  br label %bb19
bb19:
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s2)
  br label %bb21
bb21:
  %t90 = load i64, ptr %l6, !tbaa !24
  %t92 = add i64 %t90, 1
  store i64 %t92, ptr %l6, !tbaa !24
  br label %bb7
bb22:
  %t94 = load ptr, ptr @__olang_prog_scope
  %t95 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t94)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t95, ptr %l90
  br label %bb23
bb23:
  %t96 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l90
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t96, ptr %l9
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = getelementptr %"compiler/fmt:formatter", ptr %t97, i32 0, i32 6
  store ptr %t99, ptr %l10, !tbaa !29
  store i64 0, ptr %l11, !tbaa !24
  br label %bb24
bb24:
  store %olang.scope zeroinitializer, ptr %s8
  %t101 = load ptr, ptr %l10, !tbaa !29
  %t102 = load i64, ptr %l11, !tbaa !24
  %t105 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %v0, ptr %t101, i64 %t102)
  %t106 = extractvalue { i32, { i64, ptr } } %t105, 1
  %t107 = extractvalue { i32, { i64, ptr } } %t105, 0
  store i32 %t107, ptr %l97
  %t108 = icmp ne i32 %t107, 0
  br i1 %t108, label %bb26, label %ok.109
ok.109:
  store { i64, ptr } %t106, ptr %l96
  br label %bb25
bb25:
  %t110 = load { i64, ptr }, ptr %l96, !tbaa !27
  store { i64, ptr } %t110, ptr %l93, !tbaa !27
  br label %bb30
bb26:
  %t111 = load i32, ptr %l97, !tbaa !23
  %t112 = ashr i32 %t111, 16
  %t114 = icmp eq i32 %t112, 1
  br i1 %t114, label %bb27, label %bb28
bb27:
  br label %bb29
bb28:
  call void @__olang_check_failed(ptr @.c17)
  unreachable
bb29:
  call void @__olang_scope_close(ptr %s8)
  br label %bb56
bb30:
  %t116 = load { i64, ptr }, ptr %l93, !tbaa !27
  store { i64, ptr } %t116, ptr %l12, !tbaa !27
  %t117 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t119 = extractvalue { i64, ptr } %t117, 0
  store i64 %t119, ptr %l13, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  br label %bb31
bb31:
  store %olang.scope zeroinitializer, ptr %s9
  %t121 = load i64, ptr %l14, !tbaa !24
  %t122 = load i64, ptr %l13, !tbaa !24
  %t125 = icmp slt i64 %t121, %t122
  %t127 = xor i1 %t125, true
  br i1 %t127, label %bb32, label %bb33
bb32:
  call void @__olang_scope_close(ptr %s9)
  br label %bb54
bb33:
  br label %bb34
bb34:
  %t129 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t129, ptr %l106, !tbaa !27
  %t130 = load i64, ptr %l14, !tbaa !24
  %t132 = getelementptr { i64, ptr }, ptr %l106, i32 0, i32 1
  %t133 = load ptr, ptr %t132, !tbaa !27
  %t134 = getelementptr i64, ptr %t133, i64 %t130
  %t135 = load i64, ptr %t134, !tbaa !34
  store i64 %t135, ptr %l15, !tbaa !24
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t138 = load i64, ptr %l15, !tbaa !24
  %t141 = call i32 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2ekind(ptr %v0, ptr %t137, i64 %t138)
  store i32 %t141, ptr %l111
  br label %bb35
bb35:
  %t142 = load i32, ptr %l111
  store i32 %t142, ptr %l16
  %t143 = load i32, ptr %l16
  store i32 %t143, ptr %l112
  store i32 88, ptr %l114
  %t146 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l112, ptr %l114)
  store i1 %t146, ptr %l116
  br label %bb36
bb36:
  %t147 = load i1, ptr %l116, !tbaa !21
  br i1 %t147, label %bb37, label %bb38
bb37:
  %t148 = load i64, ptr %l15, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l9, i64 %t148)
  br label %bb39
bb38:
  br label %bb40
bb39:
  br label %bb40
bb40:
  %t151 = load i32, ptr %l16
  store i32 %t151, ptr %l119
  store i32 89, ptr %l121
  %t154 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l119, ptr %l121)
  store i1 %t154, ptr %l123
  br label %bb41
bb41:
  %t155 = load i1, ptr %l123, !tbaa !21
  br i1 %t155, label %bb42, label %bb43
bb42:
  %t157 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l9)
  store i64 %t157, ptr %l126
  br label %bb44
bb43:
  store i1 false, ptr %l124, !tbaa !21
  br label %bb45
bb44:
  %t158 = load i64, ptr %l126, !tbaa !24
  %t159 = icmp sgt i64 %t158, 0
  store i1 %t159, ptr %l124, !tbaa !21
  br label %bb45
bb45:
  %t161 = load i1, ptr %l124, !tbaa !21
  br i1 %t161, label %bb46, label %bb47
bb46:
  %t162 = load ptr, ptr %l0, !tbaa !29
  %t164 = getelementptr %"compiler/fmt:formatter", ptr %t162, i32 0, i32 22
  %t165 = load { i64, ptr }, ptr %t164, !tbaa !27
  store { i64, ptr } %t165, ptr %l129, !tbaa !27
  %t166 = load i64, ptr %l15, !tbaa !24
  store i64 %t166, ptr %l130, !tbaa !24
  %t168 = call { i32, i64 } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePop_3cI64_3e(ptr %s0, ptr %l9)
  %t169 = extractvalue { i32, i64 } %t168, 1
  %t170 = extractvalue { i32, i64 } %t168, 0
  store i32 %t170, ptr %l134
  %t171 = icmp ne i32 %t170, 0
  br i1 %t171, label %bb49, label %ok.172
ok.172:
  store i64 %t169, ptr %l133
  br label %bb48
bb47:
  br label %bb52
bb48:
  %t173 = load i64, ptr %l133, !tbaa !24
  store i64 %t173, ptr %l131, !tbaa !24
  br label %bb51
bb49:
  br label %bb50
bb50:
  store i64 0, ptr %l131, !tbaa !24
  br label %bb51
bb51:
  %t174 = load i64, ptr %l131, !tbaa !24
  %t175 = load i64, ptr %l130, !tbaa !24
  %t176 = getelementptr { i64, ptr }, ptr %l129, i32 0, i32 1
  %t177 = load ptr, ptr %t176, !tbaa !27
  %t178 = getelementptr i64, ptr %t177, i64 %t175
  store i64 %t174, ptr %t178, !tbaa !34
  br label %bb52
bb52:
  call void @__olang_scope_close(ptr %s9)
  br label %bb53
bb53:
  %t179 = load i64, ptr %l14, !tbaa !24
  %t181 = add i64 %t179, 1
  store i64 %t181, ptr %l14, !tbaa !24
  br label %bb31
bb54:
  %t183 = load i64, ptr %l11, !tbaa !24
  %t184 = load i64, ptr %l13, !tbaa !24
  %t187 = add i64 %t183, %t184
  store i64 %t187, ptr %l11, !tbaa !24
  call void @__olang_scope_close(ptr %s8)
  br label %bb55
bb55:
  br label %bb24
bb56:
  %t189 = load ptr, ptr @__olang_prog_scope
  %t190 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftoken_3aTok_3e(ptr %t189)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t190, ptr %l140
  br label %bb57
bb57:
  %t191 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l140
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t191, ptr %l17
  %t192 = load ptr, ptr %l0, !tbaa !29
  %t194 = getelementptr %"compiler/fmt:formatter", ptr %t192, i32 0, i32 6
  store ptr %t194, ptr %l18, !tbaa !29
  store i64 0, ptr %l19, !tbaa !24
  br label %bb58
bb58:
  store %olang.scope zeroinitializer, ptr %s14
  %t196 = load ptr, ptr %l18, !tbaa !29
  %t197 = load i64, ptr %l19, !tbaa !24
  %t200 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %v0, ptr %t196, i64 %t197)
  %t201 = extractvalue { i32, { i64, ptr } } %t200, 1
  %t202 = extractvalue { i32, { i64, ptr } } %t200, 0
  store i32 %t202, ptr %l147
  %t203 = icmp ne i32 %t202, 0
  br i1 %t203, label %bb60, label %ok.204
ok.204:
  store { i64, ptr } %t201, ptr %l146
  br label %bb59
bb59:
  %t205 = load { i64, ptr }, ptr %l146, !tbaa !27
  store { i64, ptr } %t205, ptr %l143, !tbaa !27
  br label %bb64
bb60:
  %t206 = load i32, ptr %l147, !tbaa !23
  %t207 = ashr i32 %t206, 16
  %t209 = icmp eq i32 %t207, 1
  br i1 %t209, label %bb61, label %bb62
bb61:
  br label %bb63
bb62:
  call void @__olang_check_failed(ptr @.c18)
  unreachable
bb63:
  call void @__olang_scope_close(ptr %s14)
  br label %bb124
bb64:
  %t211 = load { i64, ptr }, ptr %l143, !tbaa !27
  store { i64, ptr } %t211, ptr %l20, !tbaa !27
  %t212 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t214 = extractvalue { i64, ptr } %t212, 0
  store i64 %t214, ptr %l21, !tbaa !24
  store i64 0, ptr %l22, !tbaa !24
  br label %bb65
bb65:
  store %olang.scope zeroinitializer, ptr %s15
  %t216 = load i64, ptr %l22, !tbaa !24
  %t217 = load i64, ptr %l21, !tbaa !24
  %t220 = icmp slt i64 %t216, %t217
  %t222 = xor i1 %t220, true
  br i1 %t222, label %bb66, label %bb67
bb66:
  call void @__olang_scope_close(ptr %s15)
  br label %bb122
bb67:
  br label %bb68
bb68:
  %t224 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t224, ptr %l156, !tbaa !27
  %t225 = load i64, ptr %l22, !tbaa !24
  %t227 = getelementptr { i64, ptr }, ptr %l156, i32 0, i32 1
  %t228 = load ptr, ptr %t227, !tbaa !27
  %t229 = getelementptr i64, ptr %t228, i64 %t225
  %t230 = load i64, ptr %t229, !tbaa !34
  store i64 %t230, ptr %l23, !tbaa !24
  %t232 = load ptr, ptr %l0, !tbaa !29
  %t233 = load i64, ptr %l23, !tbaa !24
  %t236 = call i32 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2ekind(ptr %v0, ptr %t232, i64 %t233)
  store i32 %t236, ptr %l161
  br label %bb69
bb69:
  %t237 = load i32, ptr %l161
  store i32 %t237, ptr %l24
  %t238 = load i32, ptr %l24
  store i32 %t238, ptr %l162
  store i32 88, ptr %l164
  %t241 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l162, ptr %l164)
  store i1 %t241, ptr %l166
  br label %bb70
bb70:
  %t242 = load i1, ptr %l166, !tbaa !21
  br i1 %t242, label %bb71, label %bb72
bb71:
  store i1 true, ptr %l167, !tbaa !21
  br label %bb74
bb72:
  %t243 = load i32, ptr %l24
  store i32 %t243, ptr %l168
  store i32 90, ptr %l170
  %t246 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l168, ptr %l170)
  store i1 %t246, ptr %l172
  br label %bb73
bb73:
  %t247 = load i1, ptr %l172, !tbaa !21
  store i1 %t247, ptr %l167, !tbaa !21
  br label %bb74
bb74:
  %t248 = load i1, ptr %l167, !tbaa !21
  br i1 %t248, label %bb75, label %bb76
bb75:
  store i1 true, ptr %l173, !tbaa !21
  br label %bb78
bb76:
  %t249 = load i32, ptr %l24
  store i32 %t249, ptr %l174
  store i32 92, ptr %l176
  %t252 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l174, ptr %l176)
  store i1 %t252, ptr %l178
  br label %bb77
bb77:
  %t253 = load i1, ptr %l178, !tbaa !21
  store i1 %t253, ptr %l173, !tbaa !21
  br label %bb78
bb78:
  %t254 = load i1, ptr %l173, !tbaa !21
  br i1 %t254, label %bb79, label %bb80
bb79:
  %t255 = load i32, ptr %l24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftoken_3aTok_3e_2ePush_3ccompiler_2ftoken_3aTok_3e(ptr %s0, ptr %l17, i32 %t255)
  br label %bb81
bb80:
  br label %bb82
bb81:
  br label %bb82
bb82:
  %t258 = load i32, ptr %l24
  store i32 %t258, ptr %l181
  store i32 89, ptr %l183
  %t261 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l181, ptr %l183)
  store i1 %t261, ptr %l185
  br label %bb83
bb83:
  %t262 = load i1, ptr %l185, !tbaa !21
  br i1 %t262, label %bb84, label %bb85
bb84:
  store i1 true, ptr %l186, !tbaa !21
  br label %bb87
bb85:
  %t263 = load i32, ptr %l24
  store i32 %t263, ptr %l187
  store i32 91, ptr %l189
  %t266 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l187, ptr %l189)
  store i1 %t266, ptr %l191
  br label %bb86
bb86:
  %t267 = load i1, ptr %l191, !tbaa !21
  store i1 %t267, ptr %l186, !tbaa !21
  br label %bb87
bb87:
  %t268 = load i1, ptr %l186, !tbaa !21
  br i1 %t268, label %bb88, label %bb89
bb88:
  store i1 true, ptr %l192, !tbaa !21
  br label %bb91
bb89:
  %t269 = load i32, ptr %l24
  store i32 %t269, ptr %l193
  store i32 93, ptr %l195
  %t272 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l193, ptr %l195)
  store i1 %t272, ptr %l197
  br label %bb90
bb90:
  %t273 = load i1, ptr %l197, !tbaa !21
  store i1 %t273, ptr %l192, !tbaa !21
  br label %bb91
bb91:
  %t274 = load i1, ptr %l192, !tbaa !21
  br i1 %t274, label %bb92, label %bb93
bb92:
  %t276 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftoken_3aTok_3e_2eLen_3ccompiler_2ftoken_3aTok_3e(ptr %s0, ptr %l17)
  store i64 %t276, ptr %l200
  br label %bb94
bb93:
  store i1 false, ptr %l198, !tbaa !21
  br label %bb95
bb94:
  %t277 = load i64, ptr %l200, !tbaa !24
  %t278 = icmp sgt i64 %t277, 0
  store i1 %t278, ptr %l198, !tbaa !21
  br label %bb95
bb95:
  %t280 = load i1, ptr %l198, !tbaa !21
  br i1 %t280, label %bb96, label %bb97
bb96:
  %t282 = call { i32, i32 } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftoken_3aTok_3e_2ePop_3ccompiler_2ftoken_3aTok_3e(ptr %s0, ptr %l17)
  %t283 = extractvalue { i32, i32 } %t282, 1
  %t284 = extractvalue { i32, i32 } %t282, 0
  store i32 %t284, ptr %l205
  %t285 = icmp ne i32 %t284, 0
  br i1 %t285, label %bb99, label %ok.286
ok.286:
  store i32 %t283, ptr %l204
  br label %bb98
bb97:
  br label %bb107
bb98:
  %t287 = load i32, ptr %l204
  store i32 %t287, ptr %l202
  br label %bb106
bb99:
  %t288 = load i32, ptr %l205, !tbaa !23
  %t289 = icmp eq i32 %t288, 65536
  br i1 %t289, label %bb100, label %bb101
bb100:
  call void @__olang_bang_failed(ptr @.c19)
  unreachable
bb101:
  %t291 = load i32, ptr %l205, !tbaa !23
  %t292 = icmp eq i32 %t291, 65537
  br i1 %t292, label %bb102, label %bb103
bb102:
  call void @__olang_bang_failed(ptr @.c20)
  unreachable
bb103:
  %t294 = load i32, ptr %l205, !tbaa !23
  %t295 = icmp eq i32 %t294, 65538
  br i1 %t295, label %bb104, label %bb105
bb104:
  call void @__olang_bang_failed(ptr @.c21)
  unreachable
bb105:
  call void @__olang_bang_failed(ptr @.c22)
  unreachable
bb106:
  br label %bb107
bb107:
  %t297 = load i32, ptr %l24
  store i32 %t297, ptr %l209
  store i32 59, ptr %l211
  %t300 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l209, ptr %l211)
  store i1 %t300, ptr %l213
  br label %bb108
bb108:
  %t301 = load i1, ptr %l213, !tbaa !21
  br i1 %t301, label %bb109, label %bb110
bb109:
  %t302 = load ptr, ptr %l0, !tbaa !29
  %t304 = getelementptr %"compiler/fmt:formatter", ptr %t302, i32 0, i32 5
  %t305 = load { i64, ptr }, ptr %t304, !tbaa !27
  store { i64, ptr } %t305, ptr %l215, !tbaa !27
  %t306 = load i64, ptr %l23, !tbaa !24
  store i64 %t306, ptr %l216, !tbaa !24
  %t308 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftoken_3aTok_3e_2eLen_3ccompiler_2ftoken_3aTok_3e(ptr %s0, ptr %l17)
  store i64 %t308, ptr %l218
  br label %bb111
bb110:
  br label %bb120
bb111:
  %t309 = load i64, ptr %l218, !tbaa !24
  %t310 = icmp eq i64 %t309, 0
  br i1 %t310, label %bb112, label %bb113
bb112:
  store i1 true, ptr %l220, !tbaa !21
  br label %bb119
bb113:
  %t313 = call { i32, i32 } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftoken_3aTok_3e_2eLast_3ccompiler_2ftoken_3aTok_3e(ptr %s0, ptr %l17)
  %t314 = extractvalue { i32, i32 } %t313, 1
  %t315 = extractvalue { i32, i32 } %t313, 0
  store i32 %t315, ptr %l224
  %t316 = icmp ne i32 %t315, 0
  br i1 %t316, label %bb115, label %ok.317
ok.317:
  store i32 %t314, ptr %l223
  br label %bb114
bb114:
  %t318 = load i32, ptr %l223
  store i32 %t318, ptr %l221
  br label %bb117
bb115:
  br label %bb116
bb116:
  store i32 92, ptr %l221
  br label %bb117
bb117:
  store i32 92, ptr %l227
  %t322 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l221, ptr %l227)
  store i1 %t322, ptr %l229
  br label %bb118
bb118:
  %t323 = load i1, ptr %l229, !tbaa !21
  store i1 %t323, ptr %l220, !tbaa !21
  br label %bb119
bb119:
  %t324 = load i1, ptr %l220, !tbaa !21
  %t325 = load i64, ptr %l216, !tbaa !24
  %t326 = getelementptr { i64, ptr }, ptr %l215, i32 0, i32 1
  %t327 = load ptr, ptr %t326, !tbaa !27
  %t328 = getelementptr i1, ptr %t327, i64 %t325
  store i1 %t324, ptr %t328, !tbaa !31
  br label %bb120
bb120:
  call void @__olang_scope_close(ptr %s15)
  br label %bb121
bb121:
  %t329 = load i64, ptr %l22, !tbaa !24
  %t331 = add i64 %t329, 1
  store i64 %t331, ptr %l22, !tbaa !24
  br label %bb65
bb122:
  %t333 = load i64, ptr %l19, !tbaa !24
  %t334 = load i64, ptr %l21, !tbaa !24
  %t337 = add i64 %t333, %t334
  store i64 %t337, ptr %l19, !tbaa !24
  call void @__olang_scope_close(ptr %s14)
  br label %bb123
bb123:
  br label %bb58
bb124:
  store i64 0, ptr %l25, !tbaa !24
  store i64 0, ptr %l26, !tbaa !24
  br label %bb125
bb125:
  store %olang.scope zeroinitializer, ptr %s20
  %t339 = load i64, ptr %l26, !tbaa !24
  store i64 %t339, ptr %l235, !tbaa !24
  %t340 = load ptr, ptr %l0, !tbaa !29
  %t342 = getelementptr %"compiler/fmt:formatter", ptr %t340, i32 0, i32 6
  %t344 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t342)
  store i64 %t344, ptr %l238
  br label %bb126
bb126:
  %t345 = load i64, ptr %l235, !tbaa !24
  %t346 = load i64, ptr %l238, !tbaa !24
  %t347 = icmp slt i64 %t345, %t346
  %t349 = xor i1 %t347, true
  br i1 %t349, label %bb127, label %bb128
bb127:
  call void @__olang_scope_close(ptr %s20)
  br label %bb207
bb128:
  br label %bb129
bb129:
  %t351 = load ptr, ptr %l0, !tbaa !29
  %t353 = getelementptr %"compiler/fmt:formatter", ptr %t351, i32 0, i32 6
  %t354 = load i64, ptr %l26, !tbaa !24
  %t357 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t353, i64 %t354)
  store i64 %t357, ptr %l244
  br label %bb130
bb130:
  %t358 = load i64, ptr %l244, !tbaa !24
  store i64 %t358, ptr %l27, !tbaa !24
  %t359 = load ptr, ptr %l0, !tbaa !29
  %t360 = load ptr, ptr %l0, !tbaa !29
  %t362 = getelementptr %"compiler/fmt:formatter", ptr %t360, i32 0, i32 1
  %t363 = load { i64, ptr }, ptr %t362, !tbaa !27
  store { i64, ptr } %t363, ptr %l247, !tbaa !27
  %t364 = load i64, ptr %l27, !tbaa !24
  %t366 = getelementptr { i64, ptr }, ptr %l247, i32 0, i32 1
  %t367 = load ptr, ptr %t366, !tbaa !27
  %t368 = getelementptr %"compiler/token:Token", ptr %t367, i64 %t364
  %t369 = getelementptr %"compiler/token:Token", ptr %t368, i32 0, i32 2
  %t370 = load i32, ptr %t369, !tbaa !23
  %t372 = sext i32 %t370 to i64
  %t375 = call i64 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2eheldAt(ptr %v0, ptr %t359, i64 %t372)
  store i64 %t375, ptr %l251
  br label %bb131
bb131:
  %t376 = load i64, ptr %l251, !tbaa !24
  store i64 %t376, ptr %l28, !tbaa !24
  %t377 = load i64, ptr %l28, !tbaa !24
  %t379 = icmp sge i64 %t377, 0
  br i1 %t379, label %bb132, label %bb133
bb132:
  %t381 = load ptr, ptr %l0, !tbaa !29
  %t383 = getelementptr %"compiler/fmt:formatter", ptr %t381, i32 0, i32 31
  %t384 = load i64, ptr %l28, !tbaa !24
  %t387 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t383, i64 %t384)
  store i64 %t387, ptr %l257
  br label %bb134
bb133:
  br label %bb203
bb134:
  %t388 = load i64, ptr %l257, !tbaa !24
  store i64 %t388, ptr %l29, !tbaa !24
  %t389 = load ptr, ptr %l0, !tbaa !29
  %t391 = getelementptr %"compiler/fmt:formatter", ptr %t389, i32 0, i32 32
  %t392 = load i64, ptr %l28, !tbaa !24
  %t395 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t391, i64 %t392)
  store i64 %t395, ptr %l261
  br label %bb135
bb135:
  %t396 = load i64, ptr %l261, !tbaa !24
  store i64 %t396, ptr %l30, !tbaa !24
  store i64 0, ptr %l31, !tbaa !24
  %t397 = load ptr, ptr %l0, !tbaa !29
  %t399 = getelementptr %"compiler/fmt:formatter", ptr %t397, i32 0, i32 31
  %t401 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t399)
  store i64 %t401, ptr %l264
  br label %bb136
bb136:
  %t402 = load i64, ptr %l264, !tbaa !24
  store i64 %t402, ptr %l32, !tbaa !24
  store i64 1, ptr %l33, !tbaa !24
  %t403 = load i64, ptr %l32, !tbaa !24
  %t404 = load i64, ptr %l31, !tbaa !24
  %t407 = icmp sgt i64 %t403, %t404
  br i1 %t407, label %bb137, label %bb138
bb137:
  %t409 = load i64, ptr %l33, !tbaa !24
  %t411 = icmp sgt i64 %t409, 0
  br i1 %t411, label %bb139, label %bb140
bb138:
  store i64 0, ptr %l268, !tbaa !24
  br label %bb142
bb139:
  %t413 = load i64, ptr %l32, !tbaa !24
  %t414 = load i64, ptr %l31, !tbaa !24
  %t417 = sub i64 %t413, %t414
  %t418 = load i64, ptr %l33, !tbaa !24
  %t421 = add i64 %t417, %t418
  %t423 = sub i64 %t421, 1
  %t424 = load i64, ptr %l33, !tbaa !24
  %t427 = sdiv i64 %t423, %t424
  store i64 %t427, ptr %l271, !tbaa !24
  br label %bb141
bb140:
  store i64 0, ptr %l271, !tbaa !24
  br label %bb141
bb141:
  %t429 = load i64, ptr %l271, !tbaa !24
  store i64 %t429, ptr %l268, !tbaa !24
  br label %bb142
bb142:
  %t430 = load i64, ptr %l268, !tbaa !24
  store i64 %t430, ptr %l34, !tbaa !24
  store i64 0, ptr %l35, !tbaa !24
  br label %bb143
bb143:
  store %olang.scope zeroinitializer, ptr %s23
  %t431 = load i64, ptr %l35, !tbaa !24
  %t432 = load i64, ptr %l34, !tbaa !24
  %t435 = icmp slt i64 %t431, %t432
  %t437 = xor i1 %t435, true
  br i1 %t437, label %bb144, label %bb145
bb144:
  call void @__olang_scope_close(ptr %s23)
  br label %bb157
bb145:
  br label %bb146
bb146:
  %t439 = load i64, ptr %l31, !tbaa !24
  %t440 = load i64, ptr %l35, !tbaa !24
  %t441 = load i64, ptr %l33, !tbaa !24
  %t444 = mul i64 %t440, %t441
  %t447 = add i64 %t439, %t444
  store i64 %t447, ptr %l36, !tbaa !24
  %t449 = load ptr, ptr %l0, !tbaa !29
  %t451 = getelementptr %"compiler/fmt:formatter", ptr %t449, i32 0, i32 31
  %t452 = load i64, ptr %l36, !tbaa !24
  %t455 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t451, i64 %t452)
  store i64 %t455, ptr %l292
  br label %bb147
bb147:
  %t456 = load i64, ptr %l30, !tbaa !24
  %t457 = load i64, ptr %l292, !tbaa !24
  %t459 = icmp sle i64 %t457, %t456
  br i1 %t459, label %bb148, label %bb149
bb148:
  %t461 = load ptr, ptr %l0, !tbaa !29
  %t463 = getelementptr %"compiler/fmt:formatter", ptr %t461, i32 0, i32 32
  %t464 = load i64, ptr %l36, !tbaa !24
  %t467 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t463, i64 %t464)
  store i64 %t467, ptr %l299
  br label %bb150
bb149:
  store i1 false, ptr %l295, !tbaa !21
  br label %bb151
bb150:
  %t468 = load i64, ptr %l30, !tbaa !24
  %t469 = load i64, ptr %l299, !tbaa !24
  %t471 = icmp sgt i64 %t469, %t468
  store i1 %t471, ptr %l295, !tbaa !21
  br label %bb151
bb151:
  %t473 = load i1, ptr %l295, !tbaa !21
  br i1 %t473, label %bb152, label %bb153
bb152:
  %t474 = load ptr, ptr %l0, !tbaa !29
  %t476 = getelementptr %"compiler/fmt:formatter", ptr %t474, i32 0, i32 32
  %t477 = load i64, ptr %l36, !tbaa !24
  %t480 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t476, i64 %t477)
  store i64 %t480, ptr %l305
  br label %bb154
bb153:
  br label %bb155
bb154:
  %t481 = load i64, ptr %l305, !tbaa !24
  store i64 %t481, ptr %l30, !tbaa !24
  br label %bb155
bb155:
  call void @__olang_scope_close(ptr %s23)
  br label %bb156
bb156:
  %t482 = load i64, ptr %l35, !tbaa !24
  %t484 = add i64 %t482, 1
  store i64 %t484, ptr %l35, !tbaa !24
  br label %bb143
bb157:
  %t486 = load ptr, ptr %l0, !tbaa !29
  %t487 = load i64, ptr %l25, !tbaa !24
  %t488 = load i64, ptr %l29, !tbaa !24
  %t489 = load i64, ptr %l26, !tbaa !24
  call void @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2egap(ptr %v0, ptr %t486, i64 %t487, i64 %t488, i64 %t489)
  br label %bb158
bb158:
  %t494 = load ptr, ptr %l0, !tbaa !29
  %t496 = getelementptr %"compiler/fmt:formatter", ptr %t494, i32 0, i32 19
  %t497 = load i1, ptr %t496, !tbaa !21
  br i1 %t497, label %bb159, label %bb160
bb159:
  %t499 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2efinish(ptr %v0, ptr %t499)
  br label %bb161
bb160:
  br label %bb162
bb161:
  br label %bb162
bb162:
  %t501 = load i64, ptr %l29, !tbaa !24
  store i64 %t501, ptr %l37, !tbaa !24
  br label %bb163
bb163:
  store %olang.scope zeroinitializer, ptr %s27
  %t503 = load i64, ptr %l37, !tbaa !24
  %t504 = load i64, ptr %l30, !tbaa !24
  %t507 = icmp sle i64 %t503, %t504
  br i1 %t507, label %bb164, label %bb165
bb164:
  %t509 = load i64, ptr %l37, !tbaa !24
  %t510 = load ptr, ptr %l0, !tbaa !29
  %t512 = getelementptr %"compiler/fmt:formatter", ptr %t510, i32 0, i32 0
  %t513 = load { i64, ptr }, ptr %t512, !tbaa !27
  %t515 = extractvalue { i64, ptr } %t513, 0
  %t517 = add i64 %t515, 1
  %t520 = icmp slt i64 %t509, %t517
  store i1 %t520, ptr %l319, !tbaa !21
  br label %bb166
bb165:
  store i1 false, ptr %l319, !tbaa !21
  br label %bb166
bb166:
  %t522 = load i1, ptr %l319, !tbaa !21
  %t523 = xor i1 %t522, true
  br i1 %t523, label %bb167, label %bb168
bb167:
  call void @__olang_scope_close(ptr %s27)
  br label %bb199
bb168:
  br label %bb169
bb169:
  %t525 = load ptr, ptr %l0, !tbaa !29
  %t527 = getelementptr %"compiler/fmt:formatter", ptr %t525, i32 0, i32 0
  %t528 = load { i64, ptr }, ptr %t527, !tbaa !27
  %t529 = load i64, ptr %l37, !tbaa !24
  %t532 = call i64 @compiler_2ffmt_2elineEndOf(ptr %v0, { i64, ptr } %t528, i64 %t529)
  store i64 %t532, ptr %l330
  br label %bb170
bb170:
  %t533 = load i64, ptr %l330, !tbaa !24
  store i64 %t533, ptr %l38, !tbaa !24
  %t534 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2ebegin(ptr %v0, ptr %t534, i64 0)
  br label %bb171
bb171:
  %t536 = load ptr, ptr %l0, !tbaa !29
  %t538 = getelementptr %"compiler/fmt:formatter", ptr %t536, i32 0, i32 33
  store i1 true, ptr %t538, !tbaa !21
  %t539 = load ptr, ptr %l0, !tbaa !29
  %t541 = getelementptr %"compiler/fmt:formatter", ptr %t539, i32 0, i32 18
  store ptr %t541, ptr %l334, !tbaa !29
  %t542 = load ptr, ptr %l0, !tbaa !29
  %t544 = getelementptr %"compiler/fmt:formatter", ptr %t542, i32 0, i32 0
  %t545 = load { i64, ptr }, ptr %t544, !tbaa !27
  store { i64, ptr } %t545, ptr %l336, !tbaa !27
  %t546 = load i64, ptr %l37, !tbaa !24
  store i64 %t546, ptr %l337, !tbaa !24
  %t547 = load i64, ptr %l38, !tbaa !24
  store i64 %t547, ptr %l338, !tbaa !24
  %t548 = load { i64, ptr }, ptr %l336, !tbaa !27
  %t549 = extractvalue { i64, ptr } %t548, 0
  store i64 %t549, ptr %l339, !tbaa !24
  %t550 = load i64, ptr %l337, !tbaa !24
  %t551 = icmp sge i64 %t550, 0
  br i1 %t551, label %bb172, label %bb173
bb172:
  %t553 = load i64, ptr %l337, !tbaa !24
  %t554 = load i64, ptr %l338, !tbaa !24
  %t555 = icmp sle i64 %t553, %t554
  br i1 %t555, label %bb174, label %bb175
bb173:
  call void @__olang_check_failed(ptr @.c23)
  unreachable
bb174:
  %t557 = load i64, ptr %l338, !tbaa !24
  %t558 = load i64, ptr %l339, !tbaa !24
  %t559 = icmp sle i64 %t557, %t558
  br i1 %t559, label %bb176, label %bb177
bb175:
  call void @__olang_check_failed(ptr @.c23)
  unreachable
bb176:
  %t561 = getelementptr { i64, ptr }, ptr %l336, i32 0, i32 1
  %t562 = load ptr, ptr %t561, !tbaa !27
  %t563 = load i64, ptr %l337, !tbaa !24
  %t564 = load i64, ptr %l338, !tbaa !24
  %t565 = getelementptr i8, ptr %t562, i64 %t563
  %t566 = sub i64 %t564, %t563
  %t567 = insertvalue { i64, ptr } undef, i64 %t566, 0
  %t568 = insertvalue { i64, ptr } %t567, ptr %t565, 1
  %t569 = load ptr, ptr %l334, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v0, ptr %t569, { i64, ptr } %t568)
  br label %bb178
bb177:
  call void @__olang_check_failed(ptr @.c23)
  unreachable
bb178:
  store i1 true, ptr %l39, !tbaa !21
  br label %bb179
bb179:
  store %olang.scope zeroinitializer, ptr %s28
  %t571 = load i64, ptr %l26, !tbaa !24
  store i64 %t571, ptr %l344, !tbaa !24
  %t572 = load ptr, ptr %l0, !tbaa !29
  %t574 = getelementptr %"compiler/fmt:formatter", ptr %t572, i32 0, i32 6
  %t576 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t574)
  store i64 %t576, ptr %l347
  br label %bb180
bb180:
  %t577 = load i64, ptr %l344, !tbaa !24
  %t578 = load i64, ptr %l347, !tbaa !24
  %t579 = icmp slt i64 %t577, %t578
  br i1 %t579, label %bb181, label %bb182
bb181:
  %t581 = load ptr, ptr %l0, !tbaa !29
  %t583 = getelementptr %"compiler/fmt:formatter", ptr %t581, i32 0, i32 1
  %t584 = load { i64, ptr }, ptr %t583, !tbaa !27
  store { i64, ptr } %t584, ptr %l351, !tbaa !27
  %t585 = load ptr, ptr %l0, !tbaa !29
  %t587 = getelementptr %"compiler/fmt:formatter", ptr %t585, i32 0, i32 6
  %t588 = load i64, ptr %l26, !tbaa !24
  %t591 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t587, i64 %t588)
  store i64 %t591, ptr %l355
  br label %bb183
bb182:
  store i1 false, ptr %l349, !tbaa !21
  br label %bb184
bb183:
  %t592 = load i64, ptr %l355, !tbaa !24
  %t593 = getelementptr { i64, ptr }, ptr %l351, i32 0, i32 1
  %t594 = load ptr, ptr %t593, !tbaa !27
  %t595 = getelementptr %"compiler/token:Token", ptr %t594, i64 %t592
  %t596 = getelementptr %"compiler/token:Token", ptr %t595, i32 0, i32 2
  %t597 = load i32, ptr %t596, !tbaa !23
  %t599 = sext i32 %t597 to i64
  %t600 = load i64, ptr %l38, !tbaa !24
  %t603 = icmp slt i64 %t599, %t600
  store i1 %t603, ptr %l349, !tbaa !21
  br label %bb184
bb184:
  %t605 = load i1, ptr %l349, !tbaa !21
  %t606 = xor i1 %t605, true
  br i1 %t606, label %bb185, label %bb186
bb185:
  call void @__olang_scope_close(ptr %s28)
  br label %bb196
bb186:
  br label %bb187
bb187:
  %t608 = load i1, ptr %l39, !tbaa !21
  br i1 %t608, label %bb188, label %bb189
bb188:
  %t610 = load ptr, ptr %l0, !tbaa !29
  %t611 = load i64, ptr %l26, !tbaa !24
  %t614 = call i64 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2elevel(ptr %v0, ptr %t610, i64 %t611)
  store i64 %t614, ptr %l364
  br label %bb190
bb189:
  br label %bb191
bb190:
  br label %bb191
bb191:
  store i1 false, ptr %l39, !tbaa !21
  %t615 = load ptr, ptr %l0, !tbaa !29
  store ptr %t615, ptr %l365, !tbaa !29
  %t616 = load ptr, ptr %l0, !tbaa !29
  %t618 = getelementptr %"compiler/fmt:formatter", ptr %t616, i32 0, i32 6
  %t619 = load i64, ptr %l26, !tbaa !24
  %t622 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t618, i64 %t619)
  store i64 %t622, ptr %l369
  br label %bb192
bb192:
  %t623 = load i64, ptr %l369, !tbaa !24
  %t624 = load ptr, ptr %l365, !tbaa !29
  %t625 = getelementptr %"compiler/fmt:formatter", ptr %t624, i32 0, i32 28
  store i64 %t623, ptr %t625, !tbaa !24
  %t626 = load ptr, ptr %l0, !tbaa !29
  store ptr %t626, ptr %l370, !tbaa !29
  %t627 = load ptr, ptr %l0, !tbaa !29
  %t629 = getelementptr %"compiler/fmt:formatter", ptr %t627, i32 0, i32 6
  %t630 = load i64, ptr %l26, !tbaa !24
  %t633 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t629, i64 %t630)
  store i64 %t633, ptr %l374
  br label %bb193
bb193:
  %t634 = load ptr, ptr %l370, !tbaa !29
  %t635 = load i64, ptr %l374, !tbaa !24
  call void @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2etrack(ptr %v0, ptr %t634, i64 %t635)
  br label %bb194
bb194:
  %t636 = load i64, ptr %l26, !tbaa !24
  %t638 = add i64 %t636, 1
  store i64 %t638, ptr %l26, !tbaa !24
  call void @__olang_scope_close(ptr %s28)
  br label %bb195
bb195:
  br label %bb179
bb196:
  %t640 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2efinish(ptr %v0, ptr %t640)
  br label %bb197
bb197:
  %t642 = load i64, ptr %l38, !tbaa !24
  %t644 = add i64 %t642, 1
  store i64 %t644, ptr %l37, !tbaa !24
  call void @__olang_scope_close(ptr %s27)
  br label %bb198
bb198:
  br label %bb163
bb199:
  %t646 = load i64, ptr %l37, !tbaa !24
  %t647 = load ptr, ptr %l0, !tbaa !29
  %t649 = getelementptr %"compiler/fmt:formatter", ptr %t647, i32 0, i32 0
  %t650 = load { i64, ptr }, ptr %t649, !tbaa !27
  %t652 = extractvalue { i64, ptr } %t650, 0
  %t655 = icmp sle i64 %t646, %t652
  br i1 %t655, label %bb200, label %bb201
bb200:
  %t657 = load i64, ptr %l37, !tbaa !24
  store i64 %t657, ptr %l385, !tbaa !24
  br label %bb202
bb201:
  %t659 = load ptr, ptr %l0, !tbaa !29
  %t661 = getelementptr %"compiler/fmt:formatter", ptr %t659, i32 0, i32 0
  %t662 = load { i64, ptr }, ptr %t661, !tbaa !27
  %t664 = extractvalue { i64, ptr } %t662, 0
  store i64 %t664, ptr %l385, !tbaa !24
  br label %bb202
bb202:
  %t666 = load i64, ptr %l385, !tbaa !24
  store i64 %t666, ptr %l25, !tbaa !24
  call void @__olang_scope_close(ptr %s20)
  br label %bb206
bb203:
  %t667 = load ptr, ptr %l0, !tbaa !29
  %t668 = load i64, ptr %l25, !tbaa !24
  %t669 = load ptr, ptr %l0, !tbaa !29
  %t671 = getelementptr %"compiler/fmt:formatter", ptr %t669, i32 0, i32 1
  %t672 = load { i64, ptr }, ptr %t671, !tbaa !27
  store { i64, ptr } %t672, ptr %l393, !tbaa !27
  %t673 = load i64, ptr %l27, !tbaa !24
  %t675 = getelementptr { i64, ptr }, ptr %l393, i32 0, i32 1
  %t676 = load ptr, ptr %t675, !tbaa !27
  %t677 = getelementptr %"compiler/token:Token", ptr %t676, i64 %t673
  %t678 = getelementptr %"compiler/token:Token", ptr %t677, i32 0, i32 2
  %t679 = load i32, ptr %t678, !tbaa !23
  %t681 = sext i32 %t679 to i64
  %t682 = load i64, ptr %l26, !tbaa !24
  call void @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2egap(ptr %v0, ptr %t667, i64 %t668, i64 %t681, i64 %t682)
  br label %bb204
bb204:
  %t687 = load ptr, ptr %l0, !tbaa !29
  %t688 = load i64, ptr %l26, !tbaa !24
  call void @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2etoken(ptr %v0, ptr %t687, i64 %t688)
  br label %bb205
bb205:
  %t691 = load ptr, ptr %l0, !tbaa !29
  %t693 = getelementptr %"compiler/fmt:formatter", ptr %t691, i32 0, i32 1
  %t694 = load { i64, ptr }, ptr %t693, !tbaa !27
  store { i64, ptr } %t694, ptr %l401, !tbaa !27
  %t695 = load i64, ptr %l27, !tbaa !24
  %t697 = getelementptr { i64, ptr }, ptr %l401, i32 0, i32 1
  %t698 = load ptr, ptr %t697, !tbaa !27
  %t699 = getelementptr %"compiler/token:Token", ptr %t698, i64 %t695
  %t700 = getelementptr %"compiler/token:Token", ptr %t699, i32 0, i32 3
  %t701 = load i32, ptr %t700, !tbaa !23
  %t703 = sext i32 %t701 to i64
  store i64 %t703, ptr %l25, !tbaa !24
  %t705 = load i64, ptr %l26, !tbaa !24
  %t707 = add i64 %t705, 1
  store i64 %t707, ptr %l26, !tbaa !24
  call void @__olang_scope_close(ptr %s20)
  br label %bb206
bb206:
  br label %bb125
bb207:
  %t709 = load ptr, ptr %l0, !tbaa !29
  %t710 = load i64, ptr %l25, !tbaa !24
  %t711 = load ptr, ptr %l0, !tbaa !29
  %t713 = getelementptr %"compiler/fmt:formatter", ptr %t711, i32 0, i32 0
  %t714 = load { i64, ptr }, ptr %t713, !tbaa !27
  %t716 = extractvalue { i64, ptr } %t714, 0
  call void @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2egap(ptr %v0, ptr %t709, i64 %t710, i64 %t716, i64 -1)
  br label %bb208
bb208:
  %t720 = load ptr, ptr %l0, !tbaa !29
  %t722 = getelementptr %"compiler/fmt:formatter", ptr %t720, i32 0, i32 19
  %t723 = load i1, ptr %t722, !tbaa !21
  br i1 %t723, label %bb209, label %bb210
bb209:
  %t725 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2efinish(ptr %v0, ptr %t725)
  br label %bb211
bb210:
  br label %bb212
bb211:
  br label %bb212
bb212:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2espace(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l11 = alloca i32
  %l14 = alloca i32
  %l15 = alloca i32
  %l17 = alloca i32
  %l19 = alloca i1
  %l20 = alloca { i64, ptr }
  %l21 = alloca i32
  %l23 = alloca i32
  %l25 = alloca i1
  %l26 = alloca i1
  %l27 = alloca i32
  %l29 = alloca i32
  %l31 = alloca i1
  %l32 = alloca { i64, ptr }
  %l33 = alloca i32
  %l35 = alloca i32
  %l37 = alloca i1
  %l38 = alloca i1
  %l39 = alloca i32
  %l41 = alloca i32
  %l43 = alloca i1
  %l44 = alloca { i64, ptr }
  %l46 = alloca { i64, ptr }
  %l50 = alloca { i64, ptr }
  %l52 = alloca { i64, ptr }
  %l56 = alloca { i64, ptr }
  %l57 = alloca i32
  %l59 = alloca i32
  %l61 = alloca i1
  %l62 = alloca i1
  %l64 = alloca { i64, ptr }
  %l68 = alloca i1
  %l72 = alloca { i64, ptr }
  %l73 = alloca i32
  %l75 = alloca i32
  %l77 = alloca i1
  %l80 = alloca { i64, ptr }
  %l81 = alloca i32
  %l83 = alloca i32
  %l85 = alloca i1
  %l86 = alloca i1
  %l87 = alloca i32
  %l89 = alloca i32
  %l91 = alloca i1
  %l92 = alloca i1
  %l95 = alloca i1
  %l97 = alloca { i64, ptr }
  %l101 = alloca i1
  %l107 = alloca i64
  %l110 = alloca i32
  %l112 = alloca i32
  %l114 = alloca i1
  %l115 = alloca i1
  %l117 = alloca { i64, ptr }
  %l121 = alloca i1
  %l125 = alloca { i64, ptr }
  %l126 = alloca i32
  %l128 = alloca i32
  %l130 = alloca i1
  %l131 = alloca i1
  %l132 = alloca i32
  %l134 = alloca i32
  %l136 = alloca i1
  %l137 = alloca { i64, ptr }
  %l138 = alloca i32
  %l140 = alloca i32
  %l142 = alloca i1
  %l143 = alloca { i64, ptr }
  %l144 = alloca i32
  %l146 = alloca i32
  %l148 = alloca i1
  %l149 = alloca i1
  %l151 = alloca { i64, ptr }
  %l154 = alloca { i64, ptr }
  %l155 = alloca i32
  %l157 = alloca i32
  %l159 = alloca i1
  %l160 = alloca i1
  %l161 = alloca i32
  %l163 = alloca i32
  %l165 = alloca i1
  %l166 = alloca { i64, ptr }
  %l171 = alloca i1
  %l172 = alloca i32
  %l174 = alloca i32
  %l176 = alloca i1
  %l177 = alloca i1
  %l178 = alloca i32
  %l180 = alloca i32
  %l182 = alloca i1
  %l183 = alloca i1
  %l184 = alloca i32
  %l186 = alloca i32
  %l188 = alloca i1
  %l189 = alloca i1
  %l190 = alloca i32
  %l192 = alloca i32
  %l194 = alloca i1
  %l195 = alloca i1
  %l196 = alloca i32
  %l198 = alloca i32
  %l200 = alloca i1
  %l201 = alloca { i64, ptr }
  %l202 = alloca { i64, ptr }
  %l203 = alloca i32
  %l205 = alloca i32
  %l207 = alloca i1
  %l208 = alloca i1
  %l209 = alloca i32
  %l211 = alloca i32
  %l213 = alloca i1
  %l214 = alloca i1
  %l217 = alloca i1
  %l218 = alloca { i64, ptr }
  %l219 = alloca i32
  %l221 = alloca i32
  %l223 = alloca i1
  %l225 = alloca { i64, ptr }
  %l228 = alloca { i64, ptr }
  %l229 = alloca i32
  %l231 = alloca i32
  %l233 = alloca i1
  %l238 = alloca i1
  %l239 = alloca { i64, ptr }
  %l240 = alloca i32
  %l242 = alloca i32
  %l244 = alloca i1
  %l245 = alloca { i64, ptr }
  %l246 = alloca i32
  %l248 = alloca i32
  %l250 = alloca i1
  %l253 = alloca { i64, ptr }
  %l256 = alloca i1
  %l257 = alloca i1
  %l260 = alloca i1
  %l261 = alloca ptr
  %l266 = alloca i64
  %l267 = alloca i32
  %l269 = alloca i32
  %l271 = alloca i1
  %l273 = alloca { i64, ptr }
  %l278 = alloca i64
  %l282 = alloca i1
  %l286 = alloca i32
  %l288 = alloca i32
  %l290 = alloca i1
  %l291 = alloca { i64, ptr }
  %l292 = alloca i32
  %l294 = alloca i32
  %l296 = alloca i1
  %l299 = alloca { i64, ptr }
  %l302 = alloca i64
  %l305 = alloca { i64, ptr }
  %l310 = alloca { i64, ptr }
  %l313 = alloca i1
  %l314 = alloca i1
  %l315 = alloca i32
  %l317 = alloca i32
  %l319 = alloca i1
  %l321 = alloca i1
  %l322 = alloca i32
  %l324 = alloca i32
  %l326 = alloca i1
  %l328 = alloca { i64, ptr }
  %l329 = alloca { i64, ptr }
  %l330 = alloca i32
  %l332 = alloca i32
  %l334 = alloca i1
  %l335 = alloca i32
  %l337 = alloca i32
  %l339 = alloca i1
  %l342 = alloca { i64, ptr }
  %l345 = alloca i1
  %l346 = alloca i1
  %l347 = alloca i32
  %l349 = alloca i32
  %l351 = alloca i1
  %l353 = alloca i1
  %l354 = alloca i32
  %l356 = alloca i32
  %l358 = alloca i1
  %l360 = alloca i1
  %l361 = alloca i32
  %l363 = alloca i32
  %l365 = alloca i1
  %l367 = alloca i1
  %l368 = alloca i32
  %l370 = alloca i32
  %l372 = alloca i1
  %l374 = alloca { i64, ptr }
  %l375 = alloca { i64, ptr }
  %l377 = alloca { i64, ptr }
  %l381 = alloca { i64, ptr }
  %l382 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  %t5 = call i32 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2ekind(ptr %v0, ptr %t1, i64 %t2)
  store i32 %t5, ptr %l11
  br label %bb1
bb1:
  %t6 = load i32, ptr %l11
  store i32 %t6, ptr %l4
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load i64, ptr %l2, !tbaa !24
  %t11 = call i32 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2ekind(ptr %v0, ptr %t7, i64 %t8)
  store i32 %t11, ptr %l14
  br label %bb2
bb2:
  %t12 = load i32, ptr %l14
  store i32 %t12, ptr %l5
  %t13 = load i32, ptr %l5
  store i32 %t13, ptr %l15
  store i32 55, ptr %l17
  %t16 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l15, ptr %l17)
  store i1 %t16, ptr %l19
  br label %bb3
bb3:
  %t17 = load i1, ptr %l19, !tbaa !21
  br i1 %t17, label %bb4, label %bb5
bb4:
  store { i64, ptr } { i64 0, ptr @.d24 }, ptr %l20, !tbaa !27
  %t18 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t18, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t19 = load i32, ptr %l5
  store i32 %t19, ptr %l21
  store i32 89, ptr %l23
  %t22 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l21, ptr %l23)
  store i1 %t22, ptr %l25
  br label %bb7
bb7:
  %t23 = load i1, ptr %l25, !tbaa !21
  br i1 %t23, label %bb8, label %bb9
bb8:
  store i1 true, ptr %l26, !tbaa !21
  br label %bb11
bb9:
  %t24 = load i32, ptr %l5
  store i32 %t24, ptr %l27
  store i32 91, ptr %l29
  %t27 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l27, ptr %l29)
  store i1 %t27, ptr %l31
  br label %bb10
bb10:
  %t28 = load i1, ptr %l31, !tbaa !21
  store i1 %t28, ptr %l26, !tbaa !21
  br label %bb11
bb11:
  %t29 = load i1, ptr %l26, !tbaa !21
  br i1 %t29, label %bb12, label %bb13
bb12:
  store { i64, ptr } { i64 0, ptr @.d25 }, ptr %l32, !tbaa !27
  %t30 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t30, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  %t31 = load i32, ptr %l4
  store i32 %t31, ptr %l33
  store i32 88, ptr %l35
  %t34 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l33, ptr %l35)
  store i1 %t34, ptr %l37
  br label %bb15
bb15:
  %t35 = load i1, ptr %l37, !tbaa !21
  br i1 %t35, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l38, !tbaa !21
  br label %bb19
bb17:
  %t36 = load i32, ptr %l4
  store i32 %t36, ptr %l39
  store i32 90, ptr %l41
  %t39 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l39, ptr %l41)
  store i1 %t39, ptr %l43
  br label %bb18
bb18:
  %t40 = load i1, ptr %l43, !tbaa !21
  store i1 %t40, ptr %l38, !tbaa !21
  br label %bb19
bb19:
  %t41 = load i1, ptr %l38, !tbaa !21
  br i1 %t41, label %bb20, label %bb21
bb20:
  store { i64, ptr } { i64 0, ptr @.d26 }, ptr %l44, !tbaa !27
  %t42 = load { i64, ptr }, ptr %l44, !tbaa !27
  store { i64, ptr } %t42, ptr %rv
  br label %ret
bb21:
  br label %bb22
bb22:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/fmt:formatter", ptr %t43, i32 0, i32 4
  %t46 = load { i64, ptr }, ptr %t45, !tbaa !27
  store { i64, ptr } %t46, ptr %l46, !tbaa !27
  %t47 = load i64, ptr %l2, !tbaa !24
  %t49 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !27
  %t51 = getelementptr i64, ptr %t50, i64 %t47
  %t52 = load i64, ptr %t51, !tbaa !34
  %t54 = icmp sgt i64 %t52, 0
  br i1 %t54, label %bb23, label %bb24
bb23:
  store { i64, ptr } { i64 0, ptr @.d27 }, ptr %l50, !tbaa !27
  %t56 = load { i64, ptr }, ptr %l50, !tbaa !27
  store { i64, ptr } %t56, ptr %rv
  br label %ret
bb24:
  br label %bb25
bb25:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/fmt:formatter", ptr %t57, i32 0, i32 2
  %t60 = load { i64, ptr }, ptr %t59, !tbaa !27
  store { i64, ptr } %t60, ptr %l52, !tbaa !27
  %t61 = load i64, ptr %l1, !tbaa !24
  %t63 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t64 = load ptr, ptr %t63, !tbaa !27
  %t65 = getelementptr i64, ptr %t64, i64 %t61
  %t66 = load i64, ptr %t65, !tbaa !34
  %t68 = icmp sgt i64 %t66, 0
  br i1 %t68, label %bb26, label %bb27
bb26:
  store { i64, ptr } { i64 0, ptr @.d28 }, ptr %l56, !tbaa !27
  %t70 = load { i64, ptr }, ptr %l56, !tbaa !27
  store { i64, ptr } %t70, ptr %rv
  br label %ret
bb27:
  br label %bb28
bb28:
  %t71 = load i32, ptr %l4
  store i32 %t71, ptr %l57
  store i32 81, ptr %l59
  %t74 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l57, ptr %l59)
  store i1 %t74, ptr %l61
  br label %bb29
bb29:
  %t75 = load i1, ptr %l61, !tbaa !21
  br i1 %t75, label %bb30, label %bb31
bb30:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"compiler/fmt:formatter", ptr %t76, i32 0, i32 1
  %t79 = load { i64, ptr }, ptr %t78, !tbaa !27
  store { i64, ptr } %t79, ptr %l64, !tbaa !27
  %t80 = load i64, ptr %l1, !tbaa !24
  %t82 = getelementptr { i64, ptr }, ptr %l64, i32 0, i32 1
  %t83 = load ptr, ptr %t82, !tbaa !27
  %t84 = getelementptr %"compiler/token:Token", ptr %t83, i64 %t80
  %t85 = load %"compiler/token:Token", ptr %t84
  %t86 = load i8, ptr @G_2ecompiler_2ftoken_2eSpace, !tbaa !22
  %t89 = call i1 @compiler_2ftoken_2ecompiler_2ftoken_3aToken_2eHas(%"compiler/token:Token" %t85, i8 %t86)
  store i1 %t89, ptr %l68
  br label %bb32
bb31:
  store i1 false, ptr %l62, !tbaa !21
  br label %bb33
bb32:
  %t90 = load i1, ptr %l68, !tbaa !21
  %t91 = xor i1 %t90, true
  store i1 %t91, ptr %l62, !tbaa !21
  br label %bb33
bb33:
  %t93 = load i1, ptr %l62, !tbaa !21
  br i1 %t93, label %bb34, label %bb35
bb34:
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t95 = load i64, ptr %l2, !tbaa !24
  %t98 = call { i64, ptr } @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2easWritten(ptr %v0, ptr %v1, ptr %t94, i64 %t95)
  store { i64, ptr } %t98, ptr %l72
  br label %bb36
bb35:
  br label %bb37
bb36:
  %t99 = load { i64, ptr }, ptr %l72, !tbaa !27
  store { i64, ptr } %t99, ptr %rv
  br label %ret
bb37:
  %t100 = load i32, ptr %l5
  store i32 %t100, ptr %l73
  store i32 81, ptr %l75
  %t103 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l73, ptr %l75)
  store i1 %t103, ptr %l77
  br label %bb38
bb38:
  %t104 = load i1, ptr %l77, !tbaa !21
  br i1 %t104, label %bb39, label %bb40
bb39:
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t106 = load i64, ptr %l2, !tbaa !24
  %t109 = call { i64, ptr } @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2easWritten(ptr %v0, ptr %v1, ptr %t105, i64 %t106)
  store { i64, ptr } %t109, ptr %l80
  br label %bb41
bb40:
  br label %bb42
bb41:
  %t110 = load { i64, ptr }, ptr %l80, !tbaa !27
  store { i64, ptr } %t110, ptr %rv
  br label %ret
bb42:
  %t111 = load i32, ptr %l4
  store i32 %t111, ptr %l81
  store i32 1, ptr %l83
  %t114 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l81, ptr %l83)
  store i1 %t114, ptr %l85
  br label %bb43
bb43:
  %t115 = load i1, ptr %l85, !tbaa !21
  br i1 %t115, label %bb44, label %bb45
bb44:
  store i1 true, ptr %l86, !tbaa !21
  br label %bb47
bb45:
  %t116 = load i32, ptr %l4
  store i32 %t116, ptr %l87
  store i32 14, ptr %l89
  %t119 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l87, ptr %l89)
  store i1 %t119, ptr %l91
  br label %bb46
bb46:
  %t120 = load i1, ptr %l91, !tbaa !21
  store i1 %t120, ptr %l86, !tbaa !21
  br label %bb47
bb47:
  %t121 = load i1, ptr %l86, !tbaa !21
  br i1 %t121, label %bb48, label %bb49
bb48:
  %t122 = load i64, ptr %l3, !tbaa !24
  %t124 = icmp sge i64 %t122, 2
  store i1 %t124, ptr %l92, !tbaa !21
  br label %bb50
bb49:
  store i1 false, ptr %l92, !tbaa !21
  br label %bb50
bb50:
  %t126 = load i1, ptr %l92, !tbaa !21
  br i1 %t126, label %bb51, label %bb52
bb51:
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t129 = getelementptr %"compiler/fmt:formatter", ptr %t127, i32 0, i32 1
  %t130 = load { i64, ptr }, ptr %t129, !tbaa !27
  store { i64, ptr } %t130, ptr %l97, !tbaa !27
  %t131 = load i64, ptr %l1, !tbaa !24
  %t133 = getelementptr { i64, ptr }, ptr %l97, i32 0, i32 1
  %t134 = load ptr, ptr %t133, !tbaa !27
  %t135 = getelementptr %"compiler/token:Token", ptr %t134, i64 %t131
  %t136 = load %"compiler/token:Token", ptr %t135
  %t137 = load i8, ptr @G_2ecompiler_2ftoken_2eSpace, !tbaa !22
  %t140 = call i1 @compiler_2ftoken_2ecompiler_2ftoken_3aToken_2eHas(%"compiler/token:Token" %t136, i8 %t137)
  store i1 %t140, ptr %l101
  br label %bb53
bb52:
  store i1 false, ptr %l95, !tbaa !21
  br label %bb54
bb53:
  %t141 = load i1, ptr %l101, !tbaa !21
  %t142 = xor i1 %t141, true
  store i1 %t142, ptr %l95, !tbaa !21
  br label %bb54
bb54:
  %t144 = load i1, ptr %l95, !tbaa !21
  br i1 %t144, label %bb55, label %bb56
bb55:
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t147 = getelementptr %"compiler/fmt:formatter", ptr %t145, i32 0, i32 6
  %t148 = load i64, ptr %l3, !tbaa !24
  %t150 = sub i64 %t148, 2
  %t153 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t147, i64 %t150)
  store i64 %t153, ptr %l107
  br label %bb57
bb56:
  br label %bb68
bb57:
  %t154 = load i64, ptr %l107, !tbaa !24
  store i64 %t154, ptr %l6, !tbaa !24
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t156 = load i64, ptr %l6, !tbaa !24
  %t159 = call i32 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2ekind(ptr %v0, ptr %t155, i64 %t156)
  store i32 %t159, ptr %l110
  br label %bb58
bb58:
  store i32 81, ptr %l112
  %t162 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l110, ptr %l112)
  store i1 %t162, ptr %l114
  br label %bb59
bb59:
  %t163 = load i1, ptr %l114, !tbaa !21
  br i1 %t163, label %bb60, label %bb61
bb60:
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t166 = getelementptr %"compiler/fmt:formatter", ptr %t164, i32 0, i32 1
  %t167 = load { i64, ptr }, ptr %t166, !tbaa !27
  store { i64, ptr } %t167, ptr %l117, !tbaa !27
  %t168 = load i64, ptr %l6, !tbaa !24
  %t170 = getelementptr { i64, ptr }, ptr %l117, i32 0, i32 1
  %t171 = load ptr, ptr %t170, !tbaa !27
  %t172 = getelementptr %"compiler/token:Token", ptr %t171, i64 %t168
  %t173 = load %"compiler/token:Token", ptr %t172
  %t174 = load i8, ptr @G_2ecompiler_2ftoken_2eSpace, !tbaa !22
  %t177 = call i1 @compiler_2ftoken_2ecompiler_2ftoken_3aToken_2eHas(%"compiler/token:Token" %t173, i8 %t174)
  store i1 %t177, ptr %l121
  br label %bb62
bb61:
  store i1 false, ptr %l115, !tbaa !21
  br label %bb63
bb62:
  %t178 = load i1, ptr %l121, !tbaa !21
  %t179 = xor i1 %t178, true
  store i1 %t179, ptr %l115, !tbaa !21
  br label %bb63
bb63:
  %t181 = load i1, ptr %l115, !tbaa !21
  br i1 %t181, label %bb64, label %bb65
bb64:
  %t182 = load ptr, ptr %l0, !tbaa !29
  %t183 = load i64, ptr %l2, !tbaa !24
  %t186 = call { i64, ptr } @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2easWritten(ptr %v0, ptr %v1, ptr %t182, i64 %t183)
  store { i64, ptr } %t186, ptr %l125
  br label %bb66
bb65:
  br label %bb67
bb66:
  %t187 = load { i64, ptr }, ptr %l125, !tbaa !27
  store { i64, ptr } %t187, ptr %rv
  br label %ret
bb67:
  br label %bb68
bb68:
  %t188 = load i32, ptr %l4
  store i32 %t188, ptr %l126
  store i32 56, ptr %l128
  %t191 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l126, ptr %l128)
  store i1 %t191, ptr %l130
  br label %bb69
bb69:
  %t192 = load i1, ptr %l130, !tbaa !21
  br i1 %t192, label %bb70, label %bb71
bb70:
  store i1 true, ptr %l131, !tbaa !21
  br label %bb73
bb71:
  %t193 = load i32, ptr %l5
  store i32 %t193, ptr %l132
  store i32 56, ptr %l134
  %t196 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l132, ptr %l134)
  store i1 %t196, ptr %l136
  br label %bb72
bb72:
  %t197 = load i1, ptr %l136, !tbaa !21
  store i1 %t197, ptr %l131, !tbaa !21
  br label %bb73
bb73:
  %t198 = load i1, ptr %l131, !tbaa !21
  br i1 %t198, label %bb74, label %bb75
bb74:
  store { i64, ptr } { i64 0, ptr @.d29 }, ptr %l137, !tbaa !27
  %t199 = load { i64, ptr }, ptr %l137, !tbaa !27
  store { i64, ptr } %t199, ptr %rv
  br label %ret
bb75:
  br label %bb76
bb76:
  %t200 = load i32, ptr %l5
  store i32 %t200, ptr %l138
  store i32 76, ptr %l140
  %t203 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l138, ptr %l140)
  store i1 %t203, ptr %l142
  br label %bb77
bb77:
  %t204 = load i1, ptr %l142, !tbaa !21
  br i1 %t204, label %bb78, label %bb79
bb78:
  store { i64, ptr } { i64 0, ptr @.d30 }, ptr %l143, !tbaa !27
  %t205 = load { i64, ptr }, ptr %l143, !tbaa !27
  store { i64, ptr } %t205, ptr %rv
  br label %ret
bb79:
  br label %bb80
bb80:
  %t206 = load i32, ptr %l4
  store i32 %t206, ptr %l144
  store i32 59, ptr %l146
  %t209 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l144, ptr %l146)
  store i1 %t209, ptr %l148
  br label %bb81
bb81:
  %t210 = load i1, ptr %l148, !tbaa !21
  br i1 %t210, label %bb82, label %bb83
bb82:
  %t211 = load ptr, ptr %l0, !tbaa !29
  %t213 = getelementptr %"compiler/fmt:formatter", ptr %t211, i32 0, i32 5
  %t214 = load { i64, ptr }, ptr %t213, !tbaa !27
  store { i64, ptr } %t214, ptr %l151, !tbaa !27
  %t215 = load i64, ptr %l1, !tbaa !24
  %t217 = getelementptr { i64, ptr }, ptr %l151, i32 0, i32 1
  %t218 = load ptr, ptr %t217, !tbaa !27
  %t219 = getelementptr i1, ptr %t218, i64 %t215
  %t220 = load i1, ptr %t219, !tbaa !31
  store i1 %t220, ptr %l149, !tbaa !21
  br label %bb84
bb83:
  store i1 false, ptr %l149, !tbaa !21
  br label %bb84
bb84:
  %t222 = load i1, ptr %l149, !tbaa !21
  br i1 %t222, label %bb85, label %bb86
bb85:
  store { i64, ptr } { i64 1, ptr @.d31 }, ptr %l154, !tbaa !27
  %t223 = load { i64, ptr }, ptr %l154, !tbaa !27
  store { i64, ptr } %t223, ptr %rv
  br label %ret
bb86:
  br label %bb87
bb87:
  %t224 = load i32, ptr %l4
  store i32 %t224, ptr %l155
  store i32 59, ptr %l157
  %t227 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l155, ptr %l157)
  store i1 %t227, ptr %l159
  br label %bb88
bb88:
  %t228 = load i1, ptr %l159, !tbaa !21
  br i1 %t228, label %bb89, label %bb90
bb89:
  store i1 true, ptr %l160, !tbaa !21
  br label %bb92
bb90:
  %t229 = load i32, ptr %l5
  store i32 %t229, ptr %l161
  store i32 59, ptr %l163
  %t232 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l161, ptr %l163)
  store i1 %t232, ptr %l165
  br label %bb91
bb91:
  %t233 = load i1, ptr %l165, !tbaa !21
  store i1 %t233, ptr %l160, !tbaa !21
  br label %bb92
bb92:
  %t234 = load i1, ptr %l160, !tbaa !21
  br i1 %t234, label %bb93, label %bb94
bb93:
  store { i64, ptr } { i64 0, ptr @.d32 }, ptr %l166, !tbaa !27
  %t235 = load { i64, ptr }, ptr %l166, !tbaa !27
  store { i64, ptr } %t235, ptr %rv
  br label %ret
bb94:
  br label %bb95
bb95:
  %t236 = load ptr, ptr %l0, !tbaa !29
  %t237 = load i64, ptr %l1, !tbaa !24
  %t238 = load i64, ptr %l3, !tbaa !24
  %t240 = sub i64 %t238, 1
  %t244 = call i1 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2eprefix(ptr %v0, ptr %t236, i64 %t237, i64 %t240)
  store i1 %t244, ptr %l171
  br label %bb96
bb96:
  %t245 = load i1, ptr %l171, !tbaa !21
  br i1 %t245, label %bb97, label %bb98
bb97:
  %t246 = load i32, ptr %l4
  store i32 %t246, ptr %l172
  store i32 50, ptr %l174
  %t249 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l172, ptr %l174)
  store i1 %t249, ptr %l176
  br label %bb99
bb98:
  br label %bb119
bb99:
  %t250 = load i1, ptr %l176, !tbaa !21
  br i1 %t250, label %bb100, label %bb101
bb100:
  %t251 = load i32, ptr %l5
  store i32 %t251, ptr %l178
  store i32 50, ptr %l180
  %t254 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l178, ptr %l180)
  store i1 %t254, ptr %l182
  br label %bb102
bb101:
  store i1 false, ptr %l177, !tbaa !21
  br label %bb107
bb102:
  %t255 = load i1, ptr %l182, !tbaa !21
  br i1 %t255, label %bb103, label %bb104
bb103:
  store i1 true, ptr %l183, !tbaa !21
  br label %bb106
bb104:
  %t256 = load i32, ptr %l5
  store i32 %t256, ptr %l184
  store i32 72, ptr %l186
  %t259 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l184, ptr %l186)
  store i1 %t259, ptr %l188
  br label %bb105
bb105:
  %t260 = load i1, ptr %l188, !tbaa !21
  store i1 %t260, ptr %l183, !tbaa !21
  br label %bb106
bb106:
  %t261 = load i1, ptr %l183, !tbaa !21
  store i1 %t261, ptr %l177, !tbaa !21
  br label %bb107
bb107:
  %t262 = load i1, ptr %l177, !tbaa !21
  br i1 %t262, label %bb108, label %bb109
bb108:
  store i1 true, ptr %l189, !tbaa !21
  br label %bb115
bb109:
  %t263 = load i32, ptr %l4
  store i32 %t263, ptr %l190
  store i32 72, ptr %l192
  %t266 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l190, ptr %l192)
  store i1 %t266, ptr %l194
  br label %bb110
bb110:
  %t267 = load i1, ptr %l194, !tbaa !21
  br i1 %t267, label %bb111, label %bb112
bb111:
  %t268 = load i32, ptr %l5
  store i32 %t268, ptr %l196
  store i32 50, ptr %l198
  %t271 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l196, ptr %l198)
  store i1 %t271, ptr %l200
  br label %bb113
bb112:
  store i1 false, ptr %l195, !tbaa !21
  br label %bb114
bb113:
  %t272 = load i1, ptr %l200, !tbaa !21
  store i1 %t272, ptr %l195, !tbaa !21
  br label %bb114
bb114:
  %t273 = load i1, ptr %l195, !tbaa !21
  store i1 %t273, ptr %l189, !tbaa !21
  br label %bb115
bb115:
  %t274 = load i1, ptr %l189, !tbaa !21
  br i1 %t274, label %bb116, label %bb117
bb116:
  store { i64, ptr } { i64 1, ptr @.d33 }, ptr %l201, !tbaa !27
  %t275 = load { i64, ptr }, ptr %l201, !tbaa !27
  store { i64, ptr } %t275, ptr %rv
  br label %ret
bb117:
  br label %bb118
bb118:
  store { i64, ptr } { i64 0, ptr @.d34 }, ptr %l202, !tbaa !27
  %t276 = load { i64, ptr }, ptr %l202, !tbaa !27
  store { i64, ptr } %t276, ptr %rv
  br label %ret
bb119:
  %t277 = load i32, ptr %l5
  store i32 %t277, ptr %l203
  store i32 71, ptr %l205
  %t280 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l203, ptr %l205)
  store i1 %t280, ptr %l207
  br label %bb120
bb120:
  %t281 = load i1, ptr %l207, !tbaa !21
  br i1 %t281, label %bb121, label %bb122
bb121:
  store i1 true, ptr %l208, !tbaa !21
  br label %bb124
bb122:
  %t282 = load i32, ptr %l5
  store i32 %t282, ptr %l209
  store i32 72, ptr %l211
  %t285 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l209, ptr %l211)
  store i1 %t285, ptr %l213
  br label %bb123
bb123:
  %t286 = load i1, ptr %l213, !tbaa !21
  store i1 %t286, ptr %l208, !tbaa !21
  br label %bb124
bb124:
  %t287 = load i1, ptr %l208, !tbaa !21
  br i1 %t287, label %bb125, label %bb126
bb125:
  %t288 = load ptr, ptr %l0, !tbaa !29
  %t289 = load i64, ptr %l1, !tbaa !24
  %t292 = call i1 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2eoperandEnd(ptr %v0, ptr %t288, i64 %t289)
  store i1 %t292, ptr %l217
  br label %bb127
bb126:
  store i1 false, ptr %l214, !tbaa !21
  br label %bb128
bb127:
  %t293 = load i1, ptr %l217, !tbaa !21
  store i1 %t293, ptr %l214, !tbaa !21
  br label %bb128
bb128:
  %t294 = load i1, ptr %l214, !tbaa !21
  br i1 %t294, label %bb129, label %bb130
bb129:
  store { i64, ptr } { i64 0, ptr @.d35 }, ptr %l218, !tbaa !27
  %t295 = load { i64, ptr }, ptr %l218, !tbaa !27
  store { i64, ptr } %t295, ptr %rv
  br label %ret
bb130:
  br label %bb131
bb131:
  %t296 = load i32, ptr %l5
  store i32 %t296, ptr %l219
  store i32 88, ptr %l221
  %t299 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l219, ptr %l221)
  store i1 %t299, ptr %l223
  br label %bb132
bb132:
  %t300 = load i1, ptr %l223, !tbaa !21
  br i1 %t300, label %bb133, label %bb134
bb133:
  %t301 = load ptr, ptr %l0, !tbaa !29
  %t303 = getelementptr %"compiler/fmt:formatter", ptr %t301, i32 0, i32 3
  %t304 = load { i64, ptr }, ptr %t303, !tbaa !27
  store { i64, ptr } %t304, ptr %l225, !tbaa !27
  %t305 = load i64, ptr %l2, !tbaa !24
  %t307 = getelementptr { i64, ptr }, ptr %l225, i32 0, i32 1
  %t308 = load ptr, ptr %t307, !tbaa !27
  %t309 = getelementptr i1, ptr %t308, i64 %t305
  %t310 = load i1, ptr %t309, !tbaa !31
  br i1 %t310, label %bb135, label %bb136
bb134:
  br label %bb201
bb135:
  store { i64, ptr } { i64 1, ptr @.d36 }, ptr %l228, !tbaa !27
  %t312 = load { i64, ptr }, ptr %l228, !tbaa !27
  store { i64, ptr } %t312, ptr %rv
  br label %ret
bb136:
  br label %bb137
bb137:
  %t313 = load i32, ptr %l4
  store i32 %t313, ptr %l229
  store i32 37, ptr %l231
  %t316 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l229, ptr %l231)
  store i1 %t316, ptr %l233
  br label %bb138
bb138:
  %t317 = load i1, ptr %l233, !tbaa !21
  br i1 %t317, label %bb139, label %bb140
bb139:
  %t318 = load ptr, ptr %l0, !tbaa !29
  %t319 = load i64, ptr %l1, !tbaa !24
  %t320 = load i64, ptr %l3, !tbaa !24
  %t322 = sub i64 %t320, 1
  %t326 = call i1 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2ereceiver(ptr %v0, ptr %t318, i64 %t319, i64 %t322)
  store i1 %t326, ptr %l238
  br label %bb141
bb140:
  br label %bb145
bb141:
  %t327 = load i1, ptr %l238, !tbaa !21
  br i1 %t327, label %bb142, label %bb143
bb142:
  store { i64, ptr } { i64 1, ptr @.d37 }, ptr %l239, !tbaa !27
  br label %bb144
bb143:
  store { i64, ptr } { i64 0, ptr @.d38 }, ptr %l239, !tbaa !27
  br label %bb144
bb144:
  %t328 = load { i64, ptr }, ptr %l239, !tbaa !27
  store { i64, ptr } %t328, ptr %rv
  br label %ret
bb145:
  %t329 = load i32, ptr %l4
  store i32 %t329, ptr %l240
  store i32 34, ptr %l242
  %t332 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l240, ptr %l242)
  store i1 %t332, ptr %l244
  br label %bb146
bb146:
  %t333 = load i1, ptr %l244, !tbaa !21
  br i1 %t333, label %bb147, label %bb148
bb147:
  store { i64, ptr } { i64 0, ptr @.d39 }, ptr %l245, !tbaa !27
  %t334 = load { i64, ptr }, ptr %l245, !tbaa !27
  store { i64, ptr } %t334, ptr %rv
  br label %ret
bb148:
  br label %bb149
bb149:
  %t335 = load i32, ptr %l4
  store i32 %t335, ptr %l246
  store i32 93, ptr %l248
  %t338 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l246, ptr %l248)
  store i1 %t338, ptr %l250
  br label %bb150
bb150:
  %t339 = load i1, ptr %l250, !tbaa !21
  br i1 %t339, label %bb151, label %bb152
bb151:
  %t340 = load ptr, ptr %l0, !tbaa !29
  %t341 = load i64, ptr %l2, !tbaa !24
  %t344 = call { i64, ptr } @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2easWritten(ptr %v0, ptr %v1, ptr %t340, i64 %t341)
  store { i64, ptr } %t344, ptr %l253
  br label %bb153
bb152:
  br label %bb154
bb153:
  %t345 = load { i64, ptr }, ptr %l253, !tbaa !27
  store { i64, ptr } %t345, ptr %rv
  br label %ret
bb154:
  %t346 = load ptr, ptr %l0, !tbaa !29
  %t347 = load i64, ptr %l1, !tbaa !24
  %t350 = call i1 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2ekeyword(ptr %v0, ptr %t346, i64 %t347)
  store i1 %t350, ptr %l256
  br label %bb155
bb155:
  %t351 = load i1, ptr %l256, !tbaa !21
  br i1 %t351, label %bb156, label %bb157
bb156:
  %t352 = load i64, ptr %l3, !tbaa !24
  %t354 = icmp sge i64 %t352, 2
  store i1 %t354, ptr %l257, !tbaa !21
  br label %bb158
bb157:
  store i1 false, ptr %l257, !tbaa !21
  br label %bb158
bb158:
  %t356 = load i1, ptr %l257, !tbaa !21
  br i1 %t356, label %bb159, label %bb160
bb159:
  %t357 = load ptr, ptr %l0, !tbaa !29
  store ptr %t357, ptr %l261, !tbaa !29
  %t358 = load ptr, ptr %l0, !tbaa !29
  %t360 = getelementptr %"compiler/fmt:formatter", ptr %t358, i32 0, i32 6
  %t361 = load i64, ptr %l3, !tbaa !24
  %t363 = sub i64 %t361, 2
  %t366 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t360, i64 %t363)
  store i64 %t366, ptr %l266
  br label %bb161
bb160:
  store i1 false, ptr %l260, !tbaa !21
  br label %bb164
bb161:
  %t367 = load ptr, ptr %l261, !tbaa !29
  %t368 = load i64, ptr %l266, !tbaa !24
  %t369 = call i32 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2ekind(ptr %v0, ptr %t367, i64 %t368)
  store i32 %t369, ptr %l267
  br label %bb162
bb162:
  store i32 89, ptr %l269
  %t372 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l267, ptr %l269)
  store i1 %t372, ptr %l271
  br label %bb163
bb163:
  %t373 = load i1, ptr %l271, !tbaa !21
  store i1 %t373, ptr %l260, !tbaa !21
  br label %bb164
bb164:
  %t374 = load i1, ptr %l260, !tbaa !21
  br i1 %t374, label %bb165, label %bb166
bb165:
  %t375 = load ptr, ptr %l0, !tbaa !29
  %t377 = getelementptr %"compiler/fmt:formatter", ptr %t375, i32 0, i32 22
  %t378 = load { i64, ptr }, ptr %t377, !tbaa !27
  store { i64, ptr } %t378, ptr %l273, !tbaa !27
  %t379 = load ptr, ptr %l0, !tbaa !29
  %t381 = getelementptr %"compiler/fmt:formatter", ptr %t379, i32 0, i32 6
  %t382 = load i64, ptr %l3, !tbaa !24
  %t384 = sub i64 %t382, 2
  %t387 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t381, i64 %t384)
  store i64 %t387, ptr %l278
  br label %bb167
bb166:
  br label %bb176
bb167:
  %t388 = load i64, ptr %l278, !tbaa !24
  %t389 = getelementptr { i64, ptr }, ptr %l273, i32 0, i32 1
  %t390 = load ptr, ptr %t389, !tbaa !27
  %t391 = getelementptr i64, ptr %t390, i64 %t388
  %t392 = load i64, ptr %t391, !tbaa !34
  store i64 %t392, ptr %l7, !tbaa !24
  %t394 = load i64, ptr %l7, !tbaa !24
  %t396 = icmp sgt i64 %t394, 0
  br i1 %t396, label %bb168, label %bb169
bb168:
  %t398 = load ptr, ptr %l0, !tbaa !29
  %t399 = load i64, ptr %l7, !tbaa !24
  %t401 = sub i64 %t399, 1
  %t404 = call i32 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2ekind(ptr %v0, ptr %t398, i64 %t401)
  store i32 %t404, ptr %l286
  br label %bb170
bb169:
  store i1 false, ptr %l282, !tbaa !21
  br label %bb172
bb170:
  store i32 37, ptr %l288
  %t407 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l286, ptr %l288)
  store i1 %t407, ptr %l290
  br label %bb171
bb171:
  %t408 = load i1, ptr %l290, !tbaa !21
  store i1 %t408, ptr %l282, !tbaa !21
  br label %bb172
bb172:
  %t409 = load i1, ptr %l282, !tbaa !21
  br i1 %t409, label %bb173, label %bb174
bb173:
  store { i64, ptr } { i64 0, ptr @.d40 }, ptr %l291, !tbaa !27
  %t410 = load { i64, ptr }, ptr %l291, !tbaa !27
  store { i64, ptr } %t410, ptr %rv
  br label %ret
bb174:
  br label %bb175
bb175:
  br label %bb176
bb176:
  %t411 = load i32, ptr %l4
  store i32 %t411, ptr %l292
  store i32 89, ptr %l294
  %t414 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l292, ptr %l294)
  store i1 %t414, ptr %l296
  br label %bb177
bb177:
  %t415 = load i1, ptr %l296, !tbaa !21
  br i1 %t415, label %bb178, label %bb179
bb178:
  %t416 = load ptr, ptr %l0, !tbaa !29
  %t417 = load ptr, ptr %l0, !tbaa !29
  %t419 = getelementptr %"compiler/fmt:formatter", ptr %t417, i32 0, i32 22
  %t420 = load { i64, ptr }, ptr %t419, !tbaa !27
  store { i64, ptr } %t420, ptr %l299, !tbaa !27
  %t421 = load i64, ptr %l1, !tbaa !24
  %t423 = getelementptr { i64, ptr }, ptr %l299, i32 0, i32 1
  %t424 = load ptr, ptr %t423, !tbaa !27
  %t425 = getelementptr i64, ptr %t424, i64 %t421
  %t426 = load i64, ptr %t425, !tbaa !34
  %t429 = call i64 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2eparams(ptr %v0, ptr %t416, i64 %t426)
  store i64 %t429, ptr %l302
  br label %bb180
bb179:
  br label %bb188
bb180:
  %t430 = load i64, ptr %l302, !tbaa !24
  store i64 %t430, ptr %l8, !tbaa !24
  %t431 = load i64, ptr %l8, !tbaa !24
  %t433 = icmp eq i64 %t431, 1
  br i1 %t433, label %bb181, label %bb182
bb181:
  store { i64, ptr } { i64 1, ptr @.d41 }, ptr %l305, !tbaa !27
  %t435 = load { i64, ptr }, ptr %l305, !tbaa !27
  store { i64, ptr } %t435, ptr %rv
  br label %ret
bb182:
  br label %bb183
bb183:
  %t436 = load i64, ptr %l8, !tbaa !24
  %t438 = icmp eq i64 %t436, 2
  br i1 %t438, label %bb184, label %bb185
bb184:
  %t440 = load ptr, ptr %l0, !tbaa !29
  %t441 = load i64, ptr %l2, !tbaa !24
  %t444 = call { i64, ptr } @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2easWritten(ptr %v0, ptr %v1, ptr %t440, i64 %t441)
  store { i64, ptr } %t444, ptr %l310
  br label %bb186
bb185:
  br label %bb187
bb186:
  %t445 = load { i64, ptr }, ptr %l310, !tbaa !27
  store { i64, ptr } %t445, ptr %rv
  br label %ret
bb187:
  br label %bb188
bb188:
  %t446 = load ptr, ptr %l0, !tbaa !29
  %t447 = load i64, ptr %l1, !tbaa !24
  %t450 = call i1 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2eoperandEnd(ptr %v0, ptr %t446, i64 %t447)
  store i1 %t450, ptr %l313
  br label %bb189
bb189:
  %t451 = load i1, ptr %l313, !tbaa !21
  br i1 %t451, label %bb190, label %bb191
bb190:
  %t452 = load i32, ptr %l4
  store i32 %t452, ptr %l315
  store i32 71, ptr %l317
  %t455 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l315, ptr %l317)
  store i1 %t455, ptr %l319
  br label %bb192
bb191:
  store i1 false, ptr %l314, !tbaa !21
  br label %bb193
bb192:
  %t456 = load i1, ptr %l319, !tbaa !21
  %t457 = xor i1 %t456, true
  store i1 %t457, ptr %l314, !tbaa !21
  br label %bb193
bb193:
  %t459 = load i1, ptr %l314, !tbaa !21
  br i1 %t459, label %bb194, label %bb195
bb194:
  %t460 = load i32, ptr %l4
  store i32 %t460, ptr %l322
  store i32 72, ptr %l324
  %t463 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l322, ptr %l324)
  store i1 %t463, ptr %l326
  br label %bb196
bb195:
  store i1 false, ptr %l321, !tbaa !21
  br label %bb197
bb196:
  %t464 = load i1, ptr %l326, !tbaa !21
  %t465 = xor i1 %t464, true
  store i1 %t465, ptr %l321, !tbaa !21
  br label %bb197
bb197:
  %t467 = load i1, ptr %l321, !tbaa !21
  br i1 %t467, label %bb198, label %bb199
bb198:
  store { i64, ptr } { i64 0, ptr @.d42 }, ptr %l328, !tbaa !27
  %t468 = load { i64, ptr }, ptr %l328, !tbaa !27
  store { i64, ptr } %t468, ptr %rv
  br label %ret
bb199:
  br label %bb200
bb200:
  store { i64, ptr } { i64 1, ptr @.d43 }, ptr %l329, !tbaa !27
  %t469 = load { i64, ptr }, ptr %l329, !tbaa !27
  store { i64, ptr } %t469, ptr %rv
  br label %ret
bb201:
  %t470 = load i32, ptr %l5
  store i32 %t470, ptr %l330
  store i32 90, ptr %l332
  %t473 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l330, ptr %l332)
  store i1 %t473, ptr %l334
  br label %bb202
bb202:
  %t474 = load i1, ptr %l334, !tbaa !21
  br i1 %t474, label %bb203, label %bb204
bb203:
  %t475 = load i32, ptr %l4
  store i32 %t475, ptr %l335
  store i32 93, ptr %l337
  %t478 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l335, ptr %l337)
  store i1 %t478, ptr %l339
  br label %bb205
bb204:
  br label %bb230
bb205:
  %t479 = load i1, ptr %l339, !tbaa !21
  br i1 %t479, label %bb206, label %bb207
bb206:
  %t480 = load ptr, ptr %l0, !tbaa !29
  %t481 = load i64, ptr %l2, !tbaa !24
  %t484 = call { i64, ptr } @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2easWritten(ptr %v0, ptr %v1, ptr %t480, i64 %t481)
  store { i64, ptr } %t484, ptr %l342
  br label %bb208
bb207:
  br label %bb209
bb208:
  %t485 = load { i64, ptr }, ptr %l342, !tbaa !27
  store { i64, ptr } %t485, ptr %rv
  br label %ret
bb209:
  %t486 = load ptr, ptr %l0, !tbaa !29
  %t487 = load i64, ptr %l1, !tbaa !24
  %t490 = call i1 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2eoperandEnd(ptr %v0, ptr %t486, i64 %t487)
  store i1 %t490, ptr %l345
  br label %bb210
bb210:
  %t491 = load i1, ptr %l345, !tbaa !21
  br i1 %t491, label %bb211, label %bb212
bb211:
  %t492 = load i32, ptr %l4
  store i32 %t492, ptr %l347
  store i32 71, ptr %l349
  %t495 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l347, ptr %l349)
  store i1 %t495, ptr %l351
  br label %bb213
bb212:
  store i1 false, ptr %l346, !tbaa !21
  br label %bb214
bb213:
  %t496 = load i1, ptr %l351, !tbaa !21
  %t497 = xor i1 %t496, true
  store i1 %t497, ptr %l346, !tbaa !21
  br label %bb214
bb214:
  %t499 = load i1, ptr %l346, !tbaa !21
  br i1 %t499, label %bb215, label %bb216
bb215:
  %t500 = load i32, ptr %l4
  store i32 %t500, ptr %l354
  store i32 72, ptr %l356
  %t503 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l354, ptr %l356)
  store i1 %t503, ptr %l358
  br label %bb217
bb216:
  store i1 false, ptr %l353, !tbaa !21
  br label %bb218
bb217:
  %t504 = load i1, ptr %l358, !tbaa !21
  %t505 = xor i1 %t504, true
  store i1 %t505, ptr %l353, !tbaa !21
  br label %bb218
bb218:
  %t507 = load i1, ptr %l353, !tbaa !21
  br i1 %t507, label %bb219, label %bb220
bb219:
  %t508 = load i32, ptr %l4
  store i32 %t508, ptr %l361
  store i32 2, ptr %l363
  %t511 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l361, ptr %l363)
  store i1 %t511, ptr %l365
  br label %bb221
bb220:
  store i1 false, ptr %l360, !tbaa !21
  br label %bb222
bb221:
  %t512 = load i1, ptr %l365, !tbaa !21
  %t513 = xor i1 %t512, true
  store i1 %t513, ptr %l360, !tbaa !21
  br label %bb222
bb222:
  %t515 = load i1, ptr %l360, !tbaa !21
  br i1 %t515, label %bb223, label %bb224
bb223:
  %t516 = load i32, ptr %l4
  store i32 %t516, ptr %l368
  store i32 3, ptr %l370
  %t519 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l368, ptr %l370)
  store i1 %t519, ptr %l372
  br label %bb225
bb224:
  store i1 false, ptr %l367, !tbaa !21
  br label %bb226
bb225:
  %t520 = load i1, ptr %l372, !tbaa !21
  %t521 = xor i1 %t520, true
  store i1 %t521, ptr %l367, !tbaa !21
  br label %bb226
bb226:
  %t523 = load i1, ptr %l367, !tbaa !21
  br i1 %t523, label %bb227, label %bb228
bb227:
  store { i64, ptr } { i64 0, ptr @.d44 }, ptr %l374, !tbaa !27
  %t524 = load { i64, ptr }, ptr %l374, !tbaa !27
  store { i64, ptr } %t524, ptr %rv
  br label %ret
bb228:
  br label %bb229
bb229:
  store { i64, ptr } { i64 1, ptr @.d45 }, ptr %l375, !tbaa !27
  %t525 = load { i64, ptr }, ptr %l375, !tbaa !27
  store { i64, ptr } %t525, ptr %rv
  br label %ret
bb230:
  %t526 = load ptr, ptr %l0, !tbaa !29
  %t528 = getelementptr %"compiler/fmt:formatter", ptr %t526, i32 0, i32 2
  %t529 = load { i64, ptr }, ptr %t528, !tbaa !27
  store { i64, ptr } %t529, ptr %l377, !tbaa !27
  %t530 = load i64, ptr %l2, !tbaa !24
  %t532 = getelementptr { i64, ptr }, ptr %l377, i32 0, i32 1
  %t533 = load ptr, ptr %t532, !tbaa !27
  %t534 = getelementptr i64, ptr %t533, i64 %t530
  %t535 = load i64, ptr %t534, !tbaa !34
  %t537 = icmp sgt i64 %t535, 0
  br i1 %t537, label %bb231, label %bb232
bb231:
  store { i64, ptr } { i64 0, ptr @.d46 }, ptr %l381, !tbaa !27
  %t539 = load { i64, ptr }, ptr %l381, !tbaa !27
  store { i64, ptr } %t539, ptr %rv
  br label %ret
bb232:
  br label %bb233
bb233:
  store { i64, ptr } { i64 1, ptr @.d47 }, ptr %l382, !tbaa !27
  %t540 = load { i64, ptr }, ptr %l382, !tbaa !27
  store { i64, ptr } %t540, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2etokText(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l8 = alloca i64
  %l10 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/fmt:formatter", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l3, !tbaa !27
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/fmt:formatter", ptr %t5, i32 0, i32 1
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  store { i64, ptr } %t8, ptr %l5, !tbaa !27
  %t9 = load i64, ptr %l1, !tbaa !24
  %t11 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t12 = load ptr, ptr %t11, !tbaa !27
  %t13 = getelementptr %"compiler/token:Token", ptr %t12, i64 %t9
  %t14 = getelementptr %"compiler/token:Token", ptr %t13, i32 0, i32 2
  %t15 = load i32, ptr %t14, !tbaa !23
  %t17 = sext i32 %t15 to i64
  store i64 %t17, ptr %l8, !tbaa !24
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/fmt:formatter", ptr %t18, i32 0, i32 1
  %t21 = load { i64, ptr }, ptr %t20, !tbaa !27
  store { i64, ptr } %t21, ptr %l10, !tbaa !27
  %t22 = load i64, ptr %l1, !tbaa !24
  %t24 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = getelementptr %"compiler/token:Token", ptr %t25, i64 %t22
  %t27 = getelementptr %"compiler/token:Token", ptr %t26, i32 0, i32 3
  %t28 = load i32, ptr %t27, !tbaa !23
  %t30 = sext i32 %t28 to i64
  store i64 %t30, ptr %l13, !tbaa !24
  %t31 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t31, 0
  store i64 %t32, ptr %l14, !tbaa !24
  %t33 = load i64, ptr %l8, !tbaa !24
  %t34 = icmp sge i64 %t33, 0
  br i1 %t34, label %bb1, label %bb2
bb1:
  %t36 = load i64, ptr %l8, !tbaa !24
  %t37 = load i64, ptr %l13, !tbaa !24
  %t38 = icmp sle i64 %t36, %t37
  br i1 %t38, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @.c48)
  unreachable
bb3:
  %t40 = load i64, ptr %l13, !tbaa !24
  %t41 = load i64, ptr %l14, !tbaa !24
  %t42 = icmp sle i64 %t40, %t41
  br i1 %t42, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @.c48)
  unreachable
bb5:
  %t44 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !27
  %t46 = load i64, ptr %l8, !tbaa !24
  %t47 = load i64, ptr %l13, !tbaa !24
  %t48 = getelementptr i8, ptr %t45, i64 %t46
  %t49 = sub i64 %t47, %t46
  %t50 = insertvalue { i64, ptr } undef, i64 %t49, 0
  %t51 = insertvalue { i64, ptr } %t50, ptr %t48, 1
  store { i64, ptr } %t51, ptr %rv
  br label %ret
bb6:
  call void @__olang_check_failed(ptr @.c48)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2etoken(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l4 = alloca { i64, ptr }
  %l8 = alloca i64
  %l14 = alloca i64
  %l19 = alloca i1
  %l30 = alloca ptr
  %l36 = alloca { i64, ptr }
  %l39 = alloca { i64, ptr }
  %l41 = alloca { i64, ptr }
  %l45 = alloca i1
  %l47 = alloca { i64, ptr }
  %l53 = alloca i1
  %l54 = alloca { i64, ptr }
  %l56 = alloca { i64, ptr }
  %l58 = alloca i64
  %l61 = alloca i64
  %l62 = alloca i64
  %l67 = alloca i1
  %l69 = alloca ptr
  %l70 = alloca { i64, ptr }
  %l72 = alloca { i64, ptr }
  %l74 = alloca i64
  %l75 = alloca i64
  %s0 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/fmt:formatter", ptr %t1, i32 0, i32 6
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t3, i64 %t4)
  store i64 %t7, ptr %l8
  br label %bb1
bb1:
  %t8 = load i64, ptr %l8, !tbaa !24
  store i64 %t8, ptr %l2, !tbaa !24
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/fmt:formatter", ptr %t9, i32 0, i32 19
  %t12 = load i1, ptr %t11, !tbaa !21
  %t14 = xor i1 %t12, true
  br i1 %t14, label %bb2, label %bb3
bb2:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load i64, ptr %l1, !tbaa !24
  %t20 = call i64 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2elevel(ptr %v0, ptr %t16, i64 %t17)
  store i64 %t20, ptr %l14
  br label %bb4
bb3:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/fmt:formatter", ptr %t21, i32 0, i32 27
  %t24 = load i64, ptr %t23, !tbaa !24
  %t26 = icmp eq i64 %t24, 2
  br i1 %t26, label %bb11, label %bb12
bb4:
  %t28 = load i64, ptr %l14, !tbaa !24
  %t29 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2ebegin(ptr %v0, ptr %t29, i64 %t28)
  br label %bb5
bb5:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t34 = load i64, ptr %l2, !tbaa !24
  %t37 = call i1 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2eclosing(ptr %v0, ptr %t33, i64 %t34)
  store i1 %t37, ptr %l19
  br label %bb6
bb6:
  %t38 = load i1, ptr %l19, !tbaa !21
  br i1 %t38, label %bb7, label %bb8
bb7:
  %t39 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2edropBlank(ptr %v0, ptr %t39)
  br label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb10
bb10:
  br label %bb20
bb11:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/fmt:formatter", ptr %t41, i32 0, i32 18
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %t43, i8 32)
  br label %bb13
bb12:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/fmt:formatter", ptr %t45, i32 0, i32 27
  %t48 = load i64, ptr %t47, !tbaa !24
  %t50 = icmp eq i64 %t48, 1
  br i1 %t50, label %bb14, label %bb15
bb13:
  br label %bb19
bb14:
  store %olang.scope zeroinitializer, ptr %s6
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/fmt:formatter", ptr %t52, i32 0, i32 18
  store ptr %t54, ptr %l30, !tbaa !29
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/fmt:formatter", ptr %t56, i32 0, i32 28
  %t59 = load i64, ptr %t58, !tbaa !24
  %t60 = load i64, ptr %l2, !tbaa !24
  %t61 = load i64, ptr %l1, !tbaa !24
  %t66 = call { i64, ptr } @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2espace(ptr %v0, ptr %s6, ptr %t55, i64 %t59, i64 %t60, i64 %t61)
  store { i64, ptr } %t66, ptr %l36
  br label %bb16
bb15:
  br label %bb18
bb16:
  %t67 = load ptr, ptr %l30, !tbaa !29
  %t68 = load { i64, ptr }, ptr %l36, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s6, ptr %t67, { i64, ptr } %t68)
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s6)
  br label %bb18
bb18:
  br label %bb19
bb19:
  br label %bb20
bb20:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t70 = load i64, ptr %l2, !tbaa !24
  %t73 = call { i64, ptr } @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2etokText(ptr %v0, ptr %t69, i64 %t70)
  store { i64, ptr } %t73, ptr %l39
  br label %bb21
bb21:
  %t74 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t74, ptr %l4, !tbaa !27
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = getelementptr %"compiler/fmt:formatter", ptr %t75, i32 0, i32 4
  %t78 = load { i64, ptr }, ptr %t77, !tbaa !27
  store { i64, ptr } %t78, ptr %l41, !tbaa !27
  %t79 = load i64, ptr %l2, !tbaa !24
  %t81 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !27
  %t83 = getelementptr i64, ptr %t82, i64 %t79
  %t84 = load i64, ptr %t83, !tbaa !34
  %t86 = icmp sgt i64 %t84, 0
  br i1 %t86, label %bb22, label %bb23
bb22:
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t90 = getelementptr %"compiler/fmt:formatter", ptr %t88, i32 0, i32 4
  %t91 = load { i64, ptr }, ptr %t90, !tbaa !27
  store { i64, ptr } %t91, ptr %l47, !tbaa !27
  %t92 = load i64, ptr %l2, !tbaa !24
  %t94 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !27
  %t96 = getelementptr i64, ptr %t95, i64 %t92
  %t97 = load i64, ptr %t96, !tbaa !34
  %t98 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t100 = extractvalue { i64, ptr } %t98, 0
  %t103 = icmp slt i64 %t97, %t100
  store i1 %t103, ptr %l45, !tbaa !21
  br label %bb24
bb23:
  store i1 false, ptr %l45, !tbaa !21
  br label %bb24
bb24:
  %t105 = load i1, ptr %l45, !tbaa !21
  br i1 %t105, label %bb25, label %bb26
bb25:
  %t106 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t106, ptr %l54, !tbaa !27
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t109 = getelementptr %"compiler/fmt:formatter", ptr %t107, i32 0, i32 4
  %t110 = load { i64, ptr }, ptr %t109, !tbaa !27
  store { i64, ptr } %t110, ptr %l56, !tbaa !27
  %t111 = load i64, ptr %l2, !tbaa !24
  %t113 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t114 = load ptr, ptr %t113, !tbaa !27
  %t115 = getelementptr i64, ptr %t114, i64 %t111
  %t116 = load i64, ptr %t115, !tbaa !34
  store i64 %t116, ptr %l58, !tbaa !24
  %t117 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t120 = extractvalue { i64, ptr } %t117, 0
  store i64 %t120, ptr %l61, !tbaa !24
  %t121 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t122 = extractvalue { i64, ptr } %t121, 0
  store i64 %t122, ptr %l62, !tbaa !24
  %t123 = load i64, ptr %l58, !tbaa !24
  %t124 = icmp sge i64 %t123, 0
  br i1 %t124, label %bb27, label %bb28
bb26:
  store i1 false, ptr %l53, !tbaa !21
  br label %bb34
bb27:
  %t126 = load i64, ptr %l58, !tbaa !24
  %t127 = load i64, ptr %l61, !tbaa !24
  %t128 = icmp sle i64 %t126, %t127
  br i1 %t128, label %bb29, label %bb30
bb28:
  call void @__olang_check_failed(ptr @.c49)
  unreachable
bb29:
  %t130 = load i64, ptr %l61, !tbaa !24
  %t131 = load i64, ptr %l62, !tbaa !24
  %t132 = icmp sle i64 %t130, %t131
  br i1 %t132, label %bb31, label %bb32
bb30:
  call void @__olang_check_failed(ptr @.c49)
  unreachable
bb31:
  %t134 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t135 = load ptr, ptr %t134, !tbaa !27
  %t136 = load i64, ptr %l58, !tbaa !24
  %t137 = load i64, ptr %l61, !tbaa !24
  %t138 = getelementptr i8, ptr %t135, i64 %t136
  %t139 = sub i64 %t137, %t136
  %t140 = insertvalue { i64, ptr } undef, i64 %t139, 0
  %t141 = insertvalue { i64, ptr } %t140, ptr %t138, 1
  %t143 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t141, { i64, ptr } { i64 1, ptr @.d50 })
  store i1 %t143, ptr %l67
  br label %bb33
bb32:
  call void @__olang_check_failed(ptr @.c49)
  unreachable
bb33:
  %t144 = load i1, ptr %l67, !tbaa !21
  store i1 %t144, ptr %l53, !tbaa !21
  br label %bb34
bb34:
  %t145 = load i1, ptr %l53, !tbaa !21
  br i1 %t145, label %bb35, label %bb36
bb35:
  store %olang.scope zeroinitializer, ptr %s7
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t148 = getelementptr %"compiler/fmt:formatter", ptr %t146, i32 0, i32 18
  store ptr %t148, ptr %l69, !tbaa !29
  %t149 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t149, ptr %l70, !tbaa !27
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t152 = getelementptr %"compiler/fmt:formatter", ptr %t150, i32 0, i32 4
  %t153 = load { i64, ptr }, ptr %t152, !tbaa !27
  store { i64, ptr } %t153, ptr %l72, !tbaa !27
  %t154 = load i64, ptr %l2, !tbaa !24
  %t156 = getelementptr { i64, ptr }, ptr %l72, i32 0, i32 1
  %t157 = load ptr, ptr %t156, !tbaa !27
  %t158 = getelementptr i64, ptr %t157, i64 %t154
  %t159 = load i64, ptr %t158, !tbaa !34
  store i64 %t159, ptr %l74, !tbaa !24
  %t160 = load { i64, ptr }, ptr %l70, !tbaa !27
  %t161 = extractvalue { i64, ptr } %t160, 0
  store i64 %t161, ptr %l75, !tbaa !24
  %t162 = icmp sge i64 0, 0
  br i1 %t162, label %bb37, label %bb38
bb36:
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t166 = getelementptr %"compiler/fmt:formatter", ptr %t164, i32 0, i32 18
  %t167 = load { i64, ptr }, ptr %l4, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v0, ptr %t166, { i64, ptr } %t167)
  br label %bb45
bb37:
  %t170 = load i64, ptr %l74, !tbaa !24
  %t171 = icmp sle i64 0, %t170
  br i1 %t171, label %bb39, label %bb40
bb38:
  call void @__olang_check_failed(ptr @.c51)
  unreachable
bb39:
  %t173 = load i64, ptr %l74, !tbaa !24
  %t174 = load i64, ptr %l75, !tbaa !24
  %t175 = icmp sle i64 %t173, %t174
  br i1 %t175, label %bb41, label %bb42
bb40:
  call void @__olang_check_failed(ptr @.c51)
  unreachable
bb41:
  %t177 = getelementptr { i64, ptr }, ptr %l70, i32 0, i32 1
  %t178 = load ptr, ptr %t177, !tbaa !27
  %t179 = load i64, ptr %l74, !tbaa !24
  %t180 = getelementptr i8, ptr %t178, i64 0
  %t181 = sub i64 %t179, 0
  %t182 = insertvalue { i64, ptr } undef, i64 %t181, 0
  %t183 = insertvalue { i64, ptr } %t182, ptr %t180, 1
  %t184 = load ptr, ptr %l69, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v0, ptr %t184, { i64, ptr } %t183)
  br label %bb43
bb42:
  call void @__olang_check_failed(ptr @.c51)
  unreachable
bb43:
  %t186 = load ptr, ptr %l0, !tbaa !29
  %t188 = getelementptr %"compiler/fmt:formatter", ptr %t186, i32 0, i32 18
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s7, ptr %t188, { i64, ptr } { i64 2, ptr @.d52 })
  br label %bb44
bb44:
  call void @__olang_scope_close(ptr %s7)
  br label %bb46
bb45:
  br label %bb46
bb46:
  %t190 = load ptr, ptr %l0, !tbaa !29
  %t192 = getelementptr %"compiler/fmt:formatter", ptr %t190, i32 0, i32 27
  store i64 1, ptr %t192, !tbaa !24
  %t193 = load ptr, ptr %l0, !tbaa !29
  %t194 = load i64, ptr %l2, !tbaa !24
  %t197 = getelementptr %"compiler/fmt:formatter", ptr %t193, i32 0, i32 28
  store i64 %t194, ptr %t197, !tbaa !24
  %t198 = load ptr, ptr %l0, !tbaa !29
  %t199 = load i64, ptr %l2, !tbaa !24
  call void @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2etrack(ptr %v0, ptr %t198, i64 %t199)
  br label %bb47
bb47:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2etrack(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l20 = alloca i32
  %l22 = alloca { i64, ptr }
  %l26 = alloca i1
  %l31 = alloca i64
  %l34 = alloca i64
  %l54 = alloca i64
  %l71 = alloca i32
  %l73 = alloca i32
  %l75 = alloca i1
  %l78 = alloca i64
  %l81 = alloca i1
  %l86 = alloca i64
  %l100 = alloca i32
  %l102 = alloca i32
  %l104 = alloca i1
  %l105 = alloca i1
  %l106 = alloca i32
  %l108 = alloca i32
  %l110 = alloca i1
  %l118 = alloca { i64, ptr }
  %l124 = alloca i64
  %l127 = alloca i64
  %s3 = alloca %olang.scope
  %s13 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  %t5 = call i32 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2ekind(ptr %v0, ptr %t1, i64 %t2)
  store i32 %t5, ptr %l20
  br label %bb1
bb1:
  %t6 = load i32, ptr %l20
  store i32 %t6, ptr %l2
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/fmt:formatter", ptr %t7, i32 0, i32 4
  %t10 = load { i64, ptr }, ptr %t9, !tbaa !27
  store { i64, ptr } %t10, ptr %l22, !tbaa !27
  %t11 = load i64, ptr %l1, !tbaa !24
  %t13 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !27
  %t15 = getelementptr i64, ptr %t14, i64 %t11
  %t16 = load i64, ptr %t15, !tbaa !34
  store i64 %t16, ptr %l3, !tbaa !24
  %t18 = load i32, ptr %l2
  %t20 = call i1 @compiler_2ffmt_2eisCloser(i32 %t18)
  store i1 %t20, ptr %l26
  br label %bb2
bb2:
  %t21 = load i1, ptr %l26, !tbaa !21
  br i1 %t21, label %bb3, label %bb4
bb3:
  store i64 1, ptr %l3, !tbaa !24
  br label %bb5
bb4:
  br label %bb5
bb5:
  store i64 0, ptr %l4, !tbaa !24
  %t22 = load i64, ptr %l3, !tbaa !24
  store i64 %t22, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t24 = load i64, ptr %l5, !tbaa !24
  %t25 = load i64, ptr %l4, !tbaa !24
  %t28 = icmp sgt i64 %t24, %t25
  br i1 %t28, label %bb6, label %bb7
bb6:
  %t30 = load i64, ptr %l6, !tbaa !24
  %t32 = icmp sgt i64 %t30, 0
  br i1 %t32, label %bb8, label %bb9
bb7:
  store i64 0, ptr %l31, !tbaa !24
  br label %bb11
bb8:
  %t34 = load i64, ptr %l5, !tbaa !24
  %t35 = load i64, ptr %l4, !tbaa !24
  %t38 = sub i64 %t34, %t35
  %t39 = load i64, ptr %l6, !tbaa !24
  %t42 = add i64 %t38, %t39
  %t44 = sub i64 %t42, 1
  %t45 = load i64, ptr %l6, !tbaa !24
  %t48 = sdiv i64 %t44, %t45
  store i64 %t48, ptr %l34, !tbaa !24
  br label %bb10
bb9:
  store i64 0, ptr %l34, !tbaa !24
  br label %bb10
bb10:
  %t50 = load i64, ptr %l34, !tbaa !24
  store i64 %t50, ptr %l31, !tbaa !24
  br label %bb11
bb11:
  %t51 = load i64, ptr %l31, !tbaa !24
  store i64 %t51, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb12
bb12:
  store %olang.scope zeroinitializer, ptr %s3
  %t52 = load i64, ptr %l8, !tbaa !24
  %t53 = load i64, ptr %l7, !tbaa !24
  %t56 = icmp slt i64 %t52, %t53
  %t58 = xor i1 %t56, true
  br i1 %t58, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s3)
  br label %bb24
bb14:
  br label %bb15
bb15:
  %t60 = load i64, ptr %l4, !tbaa !24
  %t61 = load i64, ptr %l8, !tbaa !24
  %t62 = load i64, ptr %l6, !tbaa !24
  %t65 = mul i64 %t61, %t62
  %t68 = add i64 %t60, %t65
  store i64 %t68, ptr %l9, !tbaa !24
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/fmt:formatter", ptr %t70, i32 0, i32 8
  %t74 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t72)
  store i64 %t74, ptr %l54
  br label %bb16
bb16:
  %t75 = load i64, ptr %l54, !tbaa !24
  store i64 %t75, ptr %l10, !tbaa !24
  %t76 = load i64, ptr %l10, !tbaa !24
  %t78 = icmp sgt i64 %t76, 0
  br i1 %t78, label %bb17, label %bb18
bb17:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t82 = getelementptr %"compiler/fmt:formatter", ptr %t80, i32 0, i32 8
  %t83 = load i64, ptr %l10, !tbaa !24
  %t85 = sub i64 %t83, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eTruncate_3cI64_3e(ptr %v0, ptr %t82, i64 %t85)
  br label %bb19
bb18:
  br label %bb22
bb19:
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t90 = getelementptr %"compiler/fmt:formatter", ptr %t88, i32 0, i32 9
  %t91 = load i64, ptr %l10, !tbaa !24
  %t93 = sub i64 %t91, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eTruncate_3cI64_3e(ptr %v0, ptr %t90, i64 %t93)
  br label %bb20
bb20:
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"compiler/fmt:formatter", ptr %t96, i32 0, i32 10
  %t99 = load i64, ptr %l10, !tbaa !24
  %t101 = sub i64 %t99, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eTruncate_3cI64_3e(ptr %v0, ptr %t98, i64 %t101)
  br label %bb21
bb21:
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s3)
  br label %bb23
bb23:
  %t104 = load i64, ptr %l8, !tbaa !24
  %t106 = add i64 %t104, 1
  store i64 %t106, ptr %l8, !tbaa !24
  br label %bb12
bb24:
  %t108 = load i32, ptr %l2
  store i32 %t108, ptr %l71
  store i32 92, ptr %l73
  %t111 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l71, ptr %l73)
  store i1 %t111, ptr %l75
  br label %bb25
bb25:
  %t112 = load i1, ptr %l75, !tbaa !21
  br i1 %t112, label %bb26, label %bb27
bb26:
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t115 = getelementptr %"compiler/fmt:formatter", ptr %t113, i32 0, i32 8
  %t117 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t115)
  store i64 %t117, ptr %l78
  br label %bb28
bb27:
  %t118 = load i32, ptr %l2
  store i32 %t118, ptr %l100
  store i32 88, ptr %l102
  %t121 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l100, ptr %l102)
  store i1 %t121, ptr %l104
  br label %bb38
bb28:
  %t122 = load i64, ptr %l78, !tbaa !24
  store i64 %t122, ptr %l11, !tbaa !24
  %t123 = load i64, ptr %l11, !tbaa !24
  %t125 = icmp eq i64 %t123, 0
  br i1 %t125, label %bb29, label %bb30
bb29:
  store i1 true, ptr %l81, !tbaa !21
  br label %bb32
bb30:
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t129 = getelementptr %"compiler/fmt:formatter", ptr %t127, i32 0, i32 8
  %t130 = load i64, ptr %l11, !tbaa !24
  %t132 = sub i64 %t130, 1
  %t135 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t129, i64 %t132)
  store i64 %t135, ptr %l86
  br label %bb31
bb31:
  %t136 = load i64, ptr %l86, !tbaa !24
  %t137 = icmp eq i64 %t136, 0
  store i1 %t137, ptr %l81, !tbaa !21
  br label %bb32
bb32:
  %t139 = load i1, ptr %l81, !tbaa !21
  br i1 %t139, label %bb33, label %bb34
bb33:
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t143 = getelementptr %"compiler/fmt:formatter", ptr %t141, i32 0, i32 21
  %t144 = load i64, ptr %t143, !tbaa !24
  %t146 = add i64 %t144, 1
  %t147 = load ptr, ptr %l0, !tbaa !29
  %t149 = getelementptr %"compiler/fmt:formatter", ptr %t147, i32 0, i32 21
  %t150 = load i64, ptr %t149, !tbaa !24
  call void @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2epush(ptr %v0, ptr %t140, i64 0, i64 %t146, i64 %t150)
  br label %bb35
bb34:
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t157 = getelementptr %"compiler/fmt:formatter", ptr %t155, i32 0, i32 20
  %t158 = load i64, ptr %t157, !tbaa !24
  %t160 = add i64 %t158, 1
  %t161 = load ptr, ptr %l0, !tbaa !29
  %t163 = getelementptr %"compiler/fmt:formatter", ptr %t161, i32 0, i32 20
  %t164 = load i64, ptr %t163, !tbaa !24
  call void @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2epush(ptr %v0, ptr %t154, i64 0, i64 %t160, i64 %t164)
  br label %bb36
bb35:
  br label %bb37
bb36:
  br label %bb37
bb37:
  br label %bb60
bb38:
  %t168 = load i1, ptr %l104, !tbaa !21
  br i1 %t168, label %bb39, label %bb40
bb39:
  store i1 true, ptr %l105, !tbaa !21
  br label %bb42
bb40:
  %t169 = load i32, ptr %l2
  store i32 %t169, ptr %l106
  store i32 90, ptr %l108
  %t172 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l106, ptr %l108)
  store i1 %t172, ptr %l110
  br label %bb41
bb41:
  %t173 = load i1, ptr %l110, !tbaa !21
  store i1 %t173, ptr %l105, !tbaa !21
  br label %bb42
bb42:
  %t174 = load i1, ptr %l105, !tbaa !21
  br i1 %t174, label %bb43, label %bb44
bb43:
  %t175 = load ptr, ptr %l0, !tbaa !29
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t178 = getelementptr %"compiler/fmt:formatter", ptr %t176, i32 0, i32 20
  %t179 = load i64, ptr %t178, !tbaa !24
  %t181 = add i64 %t179, 1
  %t182 = load ptr, ptr %l0, !tbaa !29
  %t184 = getelementptr %"compiler/fmt:formatter", ptr %t182, i32 0, i32 20
  %t185 = load i64, ptr %t184, !tbaa !24
  call void @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2epush(ptr %v0, ptr %t175, i64 1, i64 %t181, i64 %t185)
  br label %bb45
bb44:
  store i64 0, ptr %l12, !tbaa !24
  %t189 = load ptr, ptr %l0, !tbaa !29
  %t191 = getelementptr %"compiler/fmt:formatter", ptr %t189, i32 0, i32 2
  %t192 = load { i64, ptr }, ptr %t191, !tbaa !27
  store { i64, ptr } %t192, ptr %l118, !tbaa !27
  %t193 = load i64, ptr %l1, !tbaa !24
  %t195 = getelementptr { i64, ptr }, ptr %l118, i32 0, i32 1
  %t196 = load ptr, ptr %t195, !tbaa !27
  %t197 = getelementptr i64, ptr %t196, i64 %t193
  %t198 = load i64, ptr %t197, !tbaa !34
  store i64 %t198, ptr %l13, !tbaa !24
  store i64 1, ptr %l14, !tbaa !24
  %t200 = load i64, ptr %l13, !tbaa !24
  %t201 = load i64, ptr %l12, !tbaa !24
  %t204 = icmp sgt i64 %t200, %t201
  br i1 %t204, label %bb46, label %bb47
bb45:
  br label %bb59
bb46:
  %t206 = load i64, ptr %l14, !tbaa !24
  %t208 = icmp sgt i64 %t206, 0
  br i1 %t208, label %bb48, label %bb49
bb47:
  store i64 0, ptr %l124, !tbaa !24
  br label %bb51
bb48:
  %t210 = load i64, ptr %l13, !tbaa !24
  %t211 = load i64, ptr %l12, !tbaa !24
  %t214 = sub i64 %t210, %t211
  %t215 = load i64, ptr %l14, !tbaa !24
  %t218 = add i64 %t214, %t215
  %t220 = sub i64 %t218, 1
  %t221 = load i64, ptr %l14, !tbaa !24
  %t224 = sdiv i64 %t220, %t221
  store i64 %t224, ptr %l127, !tbaa !24
  br label %bb50
bb49:
  store i64 0, ptr %l127, !tbaa !24
  br label %bb50
bb50:
  %t226 = load i64, ptr %l127, !tbaa !24
  store i64 %t226, ptr %l124, !tbaa !24
  br label %bb51
bb51:
  %t227 = load i64, ptr %l124, !tbaa !24
  store i64 %t227, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  br label %bb52
bb52:
  store %olang.scope zeroinitializer, ptr %s13
  %t228 = load i64, ptr %l16, !tbaa !24
  %t229 = load i64, ptr %l15, !tbaa !24
  %t232 = icmp slt i64 %t228, %t229
  %t234 = xor i1 %t232, true
  br i1 %t234, label %bb53, label %bb54
bb53:
  call void @__olang_scope_close(ptr %s13)
  br label %bb58
bb54:
  br label %bb55
bb55:
  %t236 = load i64, ptr %l12, !tbaa !24
  %t237 = load i64, ptr %l16, !tbaa !24
  %t238 = load i64, ptr %l14, !tbaa !24
  %t241 = mul i64 %t237, %t238
  %t244 = add i64 %t236, %t241
  store i64 %t244, ptr %l17, !tbaa !24
  %t246 = load ptr, ptr %l0, !tbaa !29
  %t247 = load ptr, ptr %l0, !tbaa !29
  %t249 = getelementptr %"compiler/fmt:formatter", ptr %t247, i32 0, i32 20
  %t250 = load i64, ptr %t249, !tbaa !24
  %t252 = add i64 %t250, 1
  %t253 = load ptr, ptr %l0, !tbaa !29
  %t255 = getelementptr %"compiler/fmt:formatter", ptr %t253, i32 0, i32 20
  %t256 = load i64, ptr %t255, !tbaa !24
  call void @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2epush(ptr %v0, ptr %t246, i64 1, i64 %t252, i64 %t256)
  br label %bb56
bb56:
  call void @__olang_scope_close(ptr %s13)
  br label %bb57
bb57:
  %t260 = load i64, ptr %l16, !tbaa !24
  %t262 = add i64 %t260, 1
  store i64 %t262, ptr %l16, !tbaa !24
  br label %bb52
bb58:
  br label %bb59
bb59:
  br label %bb60
bb60:
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2ewrite(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l31 = alloca { i64, ptr }
  %l32 = alloca %"std/prelude/text:StringBuilder"
  %l35 = alloca i64
  %l38 = alloca i1
  %l43 = alloca i64
  %l56 = alloca i1
  %l60 = alloca i64
  %l62 = alloca i1
  %l66 = alloca i64
  %l68 = alloca i1
  %l72 = alloca i64
  %l76 = alloca i64
  %l78 = alloca i1
  %l82 = alloca i1
  %l88 = alloca i64
  %l89 = alloca i64
  %l93 = alloca i64
  %l94 = alloca i64
  %l98 = alloca i64
  %l116 = alloca i64
  %l119 = alloca i64
  %l140 = alloca i64
  %l142 = alloca { i64, ptr }
  %l146 = alloca i64
  %l150 = alloca i64
  %l151 = alloca i64
  %l159 = alloca i1
  %l163 = alloca i64
  %l168 = alloca i64
  %l172 = alloca i64
  %l175 = alloca i64
  %l201 = alloca i64
  %l209 = alloca i64
  %l216 = alloca i64
  %l225 = alloca i64
  %l228 = alloca i64
  %l249 = alloca ptr
  %l251 = alloca { i64, ptr }
  %l255 = alloca i64
  %l259 = alloca i64
  %l260 = alloca i64
  %l270 = alloca { i64, ptr }
  %l271 = alloca { i64, ptr }
  %l272 = alloca i64
  %l273 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/fmt:formatter", ptr %t1, i32 0, i32 18
  %t5 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %s0, ptr %t3)
  store { i64, ptr } %t5, ptr %l31
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t6, ptr %l1, !tbaa !27
  %t7 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t7, ptr %l32
  br label %bb2
bb2:
  %t8 = load %"std/prelude/text:StringBuilder", ptr %l32
  store %"std/prelude/text:StringBuilder" %t8, ptr %l2
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/fmt:formatter", ptr %t9, i32 0, i32 11
  %t13 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t11)
  store i64 %t13, ptr %l35
  br label %bb3
bb3:
  %t14 = load i64, ptr %l35, !tbaa !24
  store i64 %t14, ptr %l3, !tbaa !24
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s1
  %t15 = load i64, ptr %l3, !tbaa !24
  %t17 = icmp sgt i64 %t15, 0
  br i1 %t17, label %bb5, label %bb6
bb5:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/fmt:formatter", ptr %t19, i32 0, i32 11
  %t22 = load i64, ptr %l3, !tbaa !24
  %t24 = sub i64 %t22, 1
  %t27 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t21, i64 %t24)
  store i64 %t27, ptr %l43
  br label %bb7
bb6:
  store i1 false, ptr %l38, !tbaa !21
  br label %bb8
bb7:
  %t28 = load i64, ptr %l43, !tbaa !24
  %t29 = icmp eq i64 %t28, 1
  store i1 %t29, ptr %l38, !tbaa !21
  br label %bb8
bb8:
  %t31 = load i1, ptr %l38, !tbaa !21
  %t32 = xor i1 %t31, true
  br i1 %t32, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s1)
  br label %bb13
bb10:
  br label %bb11
bb11:
  %t34 = load i64, ptr %l3, !tbaa !24
  %t36 = sub i64 %t34, 1
  store i64 %t36, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  br label %bb12
bb12:
  br label %bb4
bb13:
  store i64 0, ptr %l4, !tbaa !24
  br label %bb14
bb14:
  store %olang.scope zeroinitializer, ptr %s2
  %t38 = load i64, ptr %l4, !tbaa !24
  %t39 = load i64, ptr %l3, !tbaa !24
  %t42 = icmp slt i64 %t38, %t39
  %t44 = xor i1 %t42, true
  br i1 %t44, label %bb15, label %bb16
bb15:
  call void @__olang_scope_close(ptr %s2)
  br label %bb131
bb16:
  br label %bb17
bb17:
  %t46 = load i64, ptr %l4, !tbaa !24
  store i64 %t46, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb18
bb18:
  store %olang.scope zeroinitializer, ptr %s3
  %t48 = load i64, ptr %l5, !tbaa !24
  %t49 = load i64, ptr %l3, !tbaa !24
  %t52 = icmp slt i64 %t48, %t49
  br i1 %t52, label %bb19, label %bb20
bb19:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/fmt:formatter", ptr %t54, i32 0, i32 11
  %t57 = load i64, ptr %l5, !tbaa !24
  %t60 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t56, i64 %t57)
  store i64 %t60, ptr %l60
  br label %bb21
bb20:
  store i1 false, ptr %l56, !tbaa !21
  br label %bb22
bb21:
  %t61 = load i64, ptr %l60, !tbaa !24
  %t62 = icmp eq i64 %t61, 0
  store i1 %t62, ptr %l56, !tbaa !21
  br label %bb22
bb22:
  %t64 = load i1, ptr %l56, !tbaa !21
  br i1 %t64, label %bb23, label %bb24
bb23:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/fmt:formatter", ptr %t65, i32 0, i32 15
  %t68 = load i64, ptr %l5, !tbaa !24
  %t71 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t67, i64 %t68)
  store i64 %t71, ptr %l66
  br label %bb25
bb24:
  store i1 false, ptr %l62, !tbaa !21
  br label %bb26
bb25:
  %t72 = load i64, ptr %l66, !tbaa !24
  %t73 = icmp sge i64 %t72, 0
  store i1 %t73, ptr %l62, !tbaa !21
  br label %bb26
bb26:
  %t75 = load i1, ptr %l62, !tbaa !21
  br i1 %t75, label %bb27, label %bb28
bb27:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"compiler/fmt:formatter", ptr %t76, i32 0, i32 14
  %t79 = load i64, ptr %l5, !tbaa !24
  %t82 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t78, i64 %t79)
  store i64 %t82, ptr %l72
  br label %bb29
bb28:
  store i1 false, ptr %l68, !tbaa !21
  br label %bb31
bb29:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr %"compiler/fmt:formatter", ptr %t83, i32 0, i32 13
  %t86 = load i64, ptr %l5, !tbaa !24
  %t89 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t85, i64 %t86)
  store i64 %t89, ptr %l76
  br label %bb30
bb30:
  %t90 = load i64, ptr %l72, !tbaa !24
  %t91 = load i64, ptr %l76, !tbaa !24
  %t92 = icmp sgt i64 %t90, %t91
  store i1 %t92, ptr %l68, !tbaa !21
  br label %bb31
bb31:
  %t94 = load i1, ptr %l68, !tbaa !21
  br i1 %t94, label %bb32, label %bb33
bb32:
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t97 = getelementptr %"compiler/fmt:formatter", ptr %t95, i32 0, i32 17
  %t98 = load i64, ptr %l5, !tbaa !24
  %t101 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t97, i64 %t98)
  store i1 %t101, ptr %l82
  br label %bb34
bb33:
  store i1 false, ptr %l78, !tbaa !21
  br label %bb35
bb34:
  %t102 = load i1, ptr %l82, !tbaa !21
  %t103 = xor i1 %t102, true
  store i1 %t103, ptr %l78, !tbaa !21
  br label %bb35
bb35:
  %t105 = load i1, ptr %l78, !tbaa !21
  %t106 = xor i1 %t105, true
  br i1 %t106, label %bb36, label %bb37
bb36:
  call void @__olang_scope_close(ptr %s3)
  br label %bb46
bb37:
  br label %bb38
bb38:
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = getelementptr %"compiler/fmt:formatter", ptr %t108, i32 0, i32 12
  %t111 = load i64, ptr %l5, !tbaa !24
  %t114 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t110, i64 %t111)
  store i64 %t114, ptr %l88
  br label %bb39
bb39:
  %t115 = load i64, ptr %l88, !tbaa !24
  %t116 = mul i64 %t115, 4
  store i64 %t116, ptr %l89, !tbaa !24
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr %"compiler/fmt:formatter", ptr %t117, i32 0, i32 14
  %t120 = load i64, ptr %l5, !tbaa !24
  %t123 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t119, i64 %t120)
  store i64 %t123, ptr %l93
  br label %bb40
bb40:
  %t124 = load i64, ptr %l89, !tbaa !24
  %t125 = load i64, ptr %l93, !tbaa !24
  %t126 = add i64 %t124, %t125
  store i64 %t126, ptr %l94, !tbaa !24
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t129 = getelementptr %"compiler/fmt:formatter", ptr %t127, i32 0, i32 13
  %t130 = load i64, ptr %l5, !tbaa !24
  %t133 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t129, i64 %t130)
  store i64 %t133, ptr %l98
  br label %bb41
bb41:
  %t134 = load i64, ptr %l94, !tbaa !24
  %t135 = load i64, ptr %l98, !tbaa !24
  %t136 = sub i64 %t134, %t135
  store i64 %t136, ptr %l7, !tbaa !24
  %t138 = load i64, ptr %l7, !tbaa !24
  %t139 = load i64, ptr %l6, !tbaa !24
  %t142 = icmp sgt i64 %t138, %t139
  br i1 %t142, label %bb42, label %bb43
bb42:
  %t144 = load i64, ptr %l7, !tbaa !24
  store i64 %t144, ptr %l6, !tbaa !24
  br label %bb44
bb43:
  br label %bb44
bb44:
  %t146 = load i64, ptr %l5, !tbaa !24
  %t148 = add i64 %t146, 1
  store i64 %t148, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb45
bb45:
  br label %bb18
bb46:
  %t150 = load i64, ptr %l5, !tbaa !24
  %t151 = load i64, ptr %l4, !tbaa !24
  %t154 = icmp eq i64 %t150, %t151
  br i1 %t154, label %bb47, label %bb48
bb47:
  %t156 = load i64, ptr %l4, !tbaa !24
  %t158 = add i64 %t156, 1
  store i64 %t158, ptr %l5, !tbaa !24
  br label %bb49
bb48:
  br label %bb49
bb49:
  %t160 = load i64, ptr %l4, !tbaa !24
  store i64 %t160, ptr %l8, !tbaa !24
  %t162 = load i64, ptr %l5, !tbaa !24
  store i64 %t162, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t164 = load i64, ptr %l9, !tbaa !24
  %t165 = load i64, ptr %l8, !tbaa !24
  %t168 = icmp sgt i64 %t164, %t165
  br i1 %t168, label %bb50, label %bb51
bb50:
  %t170 = load i64, ptr %l10, !tbaa !24
  %t172 = icmp sgt i64 %t170, 0
  br i1 %t172, label %bb52, label %bb53
bb51:
  store i64 0, ptr %l116, !tbaa !24
  br label %bb55
bb52:
  %t174 = load i64, ptr %l9, !tbaa !24
  %t175 = load i64, ptr %l8, !tbaa !24
  %t178 = sub i64 %t174, %t175
  %t179 = load i64, ptr %l10, !tbaa !24
  %t182 = add i64 %t178, %t179
  %t184 = sub i64 %t182, 1
  %t185 = load i64, ptr %l10, !tbaa !24
  %t188 = sdiv i64 %t184, %t185
  store i64 %t188, ptr %l119, !tbaa !24
  br label %bb54
bb53:
  store i64 0, ptr %l119, !tbaa !24
  br label %bb54
bb54:
  %t190 = load i64, ptr %l119, !tbaa !24
  store i64 %t190, ptr %l116, !tbaa !24
  br label %bb55
bb55:
  %t191 = load i64, ptr %l116, !tbaa !24
  store i64 %t191, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb56
bb56:
  store %olang.scope zeroinitializer, ptr %s7
  %t192 = load i64, ptr %l12, !tbaa !24
  %t193 = load i64, ptr %l11, !tbaa !24
  %t196 = icmp slt i64 %t192, %t193
  %t198 = xor i1 %t196, true
  br i1 %t198, label %bb57, label %bb58
bb57:
  call void @__olang_scope_close(ptr %s7)
  br label %bb129
bb58:
  br label %bb59
bb59:
  %t200 = load i64, ptr %l8, !tbaa !24
  %t201 = load i64, ptr %l12, !tbaa !24
  %t202 = load i64, ptr %l10, !tbaa !24
  %t205 = mul i64 %t201, %t202
  %t208 = add i64 %t200, %t205
  store i64 %t208, ptr %l13, !tbaa !24
  %t210 = load ptr, ptr %l0, !tbaa !29
  %t212 = getelementptr %"compiler/fmt:formatter", ptr %t210, i32 0, i32 11
  %t213 = load i64, ptr %l13, !tbaa !24
  %t216 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t212, i64 %t213)
  store i64 %t216, ptr %l140
  br label %bb60
bb60:
  %t217 = load i64, ptr %l140, !tbaa !24
  %t218 = icmp eq i64 %t217, 0
  br i1 %t218, label %bb61, label %bb62
bb61:
  %t220 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t220, ptr %l142, !tbaa !27
  %t221 = load ptr, ptr %l0, !tbaa !29
  %t223 = getelementptr %"compiler/fmt:formatter", ptr %t221, i32 0, i32 13
  %t224 = load i64, ptr %l13, !tbaa !24
  %t227 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t223, i64 %t224)
  store i64 %t227, ptr %l146
  br label %bb63
bb62:
  br label %bb126
bb63:
  %t228 = load ptr, ptr %l0, !tbaa !29
  %t230 = getelementptr %"compiler/fmt:formatter", ptr %t228, i32 0, i32 14
  %t231 = load i64, ptr %l13, !tbaa !24
  %t234 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t230, i64 %t231)
  store i64 %t234, ptr %l150
  br label %bb64
bb64:
  %t235 = load { i64, ptr }, ptr %l142, !tbaa !27
  %t236 = extractvalue { i64, ptr } %t235, 0
  store i64 %t236, ptr %l151, !tbaa !24
  %t237 = load i64, ptr %l146, !tbaa !24
  %t238 = icmp sge i64 %t237, 0
  br i1 %t238, label %bb65, label %bb66
bb65:
  %t240 = load i64, ptr %l146, !tbaa !24
  %t241 = load i64, ptr %l150, !tbaa !24
  %t242 = icmp sle i64 %t240, %t241
  br i1 %t242, label %bb67, label %bb68
bb66:
  call void @__olang_check_failed(ptr @.c53)
  unreachable
bb67:
  %t244 = load i64, ptr %l150, !tbaa !24
  %t245 = load i64, ptr %l151, !tbaa !24
  %t246 = icmp sle i64 %t244, %t245
  br i1 %t246, label %bb69, label %bb70
bb68:
  call void @__olang_check_failed(ptr @.c53)
  unreachable
bb69:
  %t248 = getelementptr { i64, ptr }, ptr %l142, i32 0, i32 1
  %t249 = load ptr, ptr %t248, !tbaa !27
  %t250 = load i64, ptr %l146, !tbaa !24
  %t251 = load i64, ptr %l150, !tbaa !24
  %t252 = getelementptr i8, ptr %t249, i64 %t250
  %t253 = sub i64 %t251, %t250
  %t254 = insertvalue { i64, ptr } undef, i64 %t253, 0
  %t255 = insertvalue { i64, ptr } %t254, ptr %t252, 1
  store { i64, ptr } %t255, ptr %l14, !tbaa !27
  %t257 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t259 = extractvalue { i64, ptr } %t257, 0
  %t261 = icmp sgt i64 %t259, 0
  br i1 %t261, label %bb71, label %bb72
bb70:
  call void @__olang_check_failed(ptr @.c53)
  unreachable
bb71:
  store i1 true, ptr %l159, !tbaa !21
  br label %bb74
bb72:
  %t263 = load ptr, ptr %l0, !tbaa !29
  %t265 = getelementptr %"compiler/fmt:formatter", ptr %t263, i32 0, i32 15
  %t266 = load i64, ptr %l13, !tbaa !24
  %t269 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t265, i64 %t266)
  store i64 %t269, ptr %l163
  br label %bb73
bb73:
  %t270 = load i64, ptr %l163, !tbaa !24
  %t271 = icmp sge i64 %t270, 0
  store i1 %t271, ptr %l159, !tbaa !21
  br label %bb74
bb74:
  %t273 = load i1, ptr %l159, !tbaa !21
  br i1 %t273, label %bb75, label %bb76
bb75:
  store i64 0, ptr %l15, !tbaa !24
  %t274 = load ptr, ptr %l0, !tbaa !29
  %t276 = getelementptr %"compiler/fmt:formatter", ptr %t274, i32 0, i32 12
  %t277 = load i64, ptr %l13, !tbaa !24
  %t280 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t276, i64 %t277)
  store i64 %t280, ptr %l168
  br label %bb77
bb76:
  br label %bb91
bb77:
  %t281 = load i64, ptr %l168, !tbaa !24
  store i64 %t281, ptr %l16, !tbaa !24
  store i64 1, ptr %l17, !tbaa !24
  %t282 = load i64, ptr %l16, !tbaa !24
  %t283 = load i64, ptr %l15, !tbaa !24
  %t286 = icmp sgt i64 %t282, %t283
  br i1 %t286, label %bb78, label %bb79
bb78:
  %t288 = load i64, ptr %l17, !tbaa !24
  %t290 = icmp sgt i64 %t288, 0
  br i1 %t290, label %bb80, label %bb81
bb79:
  store i64 0, ptr %l172, !tbaa !24
  br label %bb83
bb80:
  %t292 = load i64, ptr %l16, !tbaa !24
  %t293 = load i64, ptr %l15, !tbaa !24
  %t296 = sub i64 %t292, %t293
  %t297 = load i64, ptr %l17, !tbaa !24
  %t300 = add i64 %t296, %t297
  %t302 = sub i64 %t300, 1
  %t303 = load i64, ptr %l17, !tbaa !24
  %t306 = sdiv i64 %t302, %t303
  store i64 %t306, ptr %l175, !tbaa !24
  br label %bb82
bb81:
  store i64 0, ptr %l175, !tbaa !24
  br label %bb82
bb82:
  %t308 = load i64, ptr %l175, !tbaa !24
  store i64 %t308, ptr %l172, !tbaa !24
  br label %bb83
bb83:
  %t309 = load i64, ptr %l172, !tbaa !24
  store i64 %t309, ptr %l18, !tbaa !24
  store i64 0, ptr %l19, !tbaa !24
  br label %bb84
bb84:
  store %olang.scope zeroinitializer, ptr %s11
  %t310 = load i64, ptr %l19, !tbaa !24
  %t311 = load i64, ptr %l18, !tbaa !24
  %t314 = icmp slt i64 %t310, %t311
  %t316 = xor i1 %t314, true
  br i1 %t316, label %bb85, label %bb86
bb85:
  call void @__olang_scope_close(ptr %s11)
  br label %bb90
bb86:
  br label %bb87
bb87:
  %t318 = load i64, ptr %l15, !tbaa !24
  %t319 = load i64, ptr %l19, !tbaa !24
  %t320 = load i64, ptr %l17, !tbaa !24
  %t323 = mul i64 %t319, %t320
  %t326 = add i64 %t318, %t323
  store i64 %t326, ptr %l20, !tbaa !24
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s11, ptr %l2, { i64, ptr } { i64 4, ptr @.d54 })
  br label %bb88
bb88:
  call void @__olang_scope_close(ptr %s11)
  br label %bb89
bb89:
  %t329 = load i64, ptr %l19, !tbaa !24
  %t331 = add i64 %t329, 1
  store i64 %t331, ptr %l19, !tbaa !24
  br label %bb84
bb90:
  br label %bb91
bb91:
  %t333 = load { i64, ptr }, ptr %l14, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l2, { i64, ptr } %t333)
  br label %bb92
bb92:
  %t336 = load ptr, ptr %l0, !tbaa !29
  %t338 = getelementptr %"compiler/fmt:formatter", ptr %t336, i32 0, i32 15
  %t339 = load i64, ptr %l13, !tbaa !24
  %t342 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t338, i64 %t339)
  store i64 %t342, ptr %l201
  br label %bb93
bb93:
  %t343 = load i64, ptr %l201, !tbaa !24
  %t344 = icmp sge i64 %t343, 0
  br i1 %t344, label %bb94, label %bb95
bb94:
  %t346 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t348 = extractvalue { i64, ptr } %t346, 0
  %t350 = icmp sgt i64 %t348, 0
  br i1 %t350, label %bb96, label %bb97
bb95:
  br label %bb125
bb96:
  %t352 = load ptr, ptr %l0, !tbaa !29
  %t354 = getelementptr %"compiler/fmt:formatter", ptr %t352, i32 0, i32 12
  %t355 = load i64, ptr %l13, !tbaa !24
  %t358 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t354, i64 %t355)
  store i64 %t358, ptr %l209
  br label %bb98
bb97:
  br label %bb115
bb98:
  %t359 = load i64, ptr %l209, !tbaa !24
  %t360 = mul i64 %t359, 4
  %t361 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t363 = extractvalue { i64, ptr } %t361, 0
  %t366 = add i64 %t360, %t363
  store i64 %t366, ptr %l21, !tbaa !24
  %t368 = load i64, ptr %l6, !tbaa !24
  %t370 = icmp sgt i64 %t368, 0
  br i1 %t370, label %bb99, label %bb100
bb99:
  %t372 = load i64, ptr %l6, !tbaa !24
  %t373 = load i64, ptr %l21, !tbaa !24
  %t376 = sub i64 %t372, %t373
  %t378 = add i64 %t376, 1
  store i64 %t378, ptr %l216, !tbaa !24
  br label %bb101
bb100:
  store i64 1, ptr %l216, !tbaa !24
  br label %bb101
bb101:
  %t380 = load i64, ptr %l216, !tbaa !24
  store i64 0, ptr %l23, !tbaa !24
  store i64 %t380, ptr %l24, !tbaa !24
  store i64 1, ptr %l25, !tbaa !24
  %t383 = load i64, ptr %l24, !tbaa !24
  %t384 = load i64, ptr %l23, !tbaa !24
  %t387 = icmp sgt i64 %t383, %t384
  br i1 %t387, label %bb102, label %bb103
bb102:
  %t389 = load i64, ptr %l25, !tbaa !24
  %t391 = icmp sgt i64 %t389, 0
  br i1 %t391, label %bb104, label %bb105
bb103:
  store i64 0, ptr %l225, !tbaa !24
  br label %bb107
bb104:
  %t393 = load i64, ptr %l24, !tbaa !24
  %t394 = load i64, ptr %l23, !tbaa !24
  %t397 = sub i64 %t393, %t394
  %t398 = load i64, ptr %l25, !tbaa !24
  %t401 = add i64 %t397, %t398
  %t403 = sub i64 %t401, 1
  %t404 = load i64, ptr %l25, !tbaa !24
  %t407 = sdiv i64 %t403, %t404
  store i64 %t407, ptr %l228, !tbaa !24
  br label %bb106
bb105:
  store i64 0, ptr %l228, !tbaa !24
  br label %bb106
bb106:
  %t409 = load i64, ptr %l228, !tbaa !24
  store i64 %t409, ptr %l225, !tbaa !24
  br label %bb107
bb107:
  %t410 = load i64, ptr %l225, !tbaa !24
  store i64 %t410, ptr %l26, !tbaa !24
  store i64 0, ptr %l27, !tbaa !24
  br label %bb108
bb108:
  store %olang.scope zeroinitializer, ptr %s16
  %t411 = load i64, ptr %l27, !tbaa !24
  %t412 = load i64, ptr %l26, !tbaa !24
  %t415 = icmp slt i64 %t411, %t412
  %t417 = xor i1 %t415, true
  br i1 %t417, label %bb109, label %bb110
bb109:
  call void @__olang_scope_close(ptr %s16)
  br label %bb114
bb110:
  br label %bb111
bb111:
  %t419 = load i64, ptr %l23, !tbaa !24
  %t420 = load i64, ptr %l27, !tbaa !24
  %t421 = load i64, ptr %l25, !tbaa !24
  %t424 = mul i64 %t420, %t421
  %t427 = add i64 %t419, %t424
  store i64 %t427, ptr %l28, !tbaa !24
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l2, i8 32)
  br label %bb112
bb112:
  call void @__olang_scope_close(ptr %s16)
  br label %bb113
bb113:
  %t430 = load i64, ptr %l27, !tbaa !24
  %t432 = add i64 %t430, 1
  store i64 %t432, ptr %l27, !tbaa !24
  br label %bb108
bb114:
  br label %bb115
bb115:
  store ptr %l2, ptr %l249, !tbaa !29
  %t434 = load ptr, ptr %l0, !tbaa !29
  %t436 = getelementptr %"compiler/fmt:formatter", ptr %t434, i32 0, i32 0
  %t437 = load { i64, ptr }, ptr %t436, !tbaa !27
  store { i64, ptr } %t437, ptr %l251, !tbaa !27
  %t438 = load ptr, ptr %l0, !tbaa !29
  %t440 = getelementptr %"compiler/fmt:formatter", ptr %t438, i32 0, i32 15
  %t441 = load i64, ptr %l13, !tbaa !24
  %t444 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t440, i64 %t441)
  store i64 %t444, ptr %l255
  br label %bb116
bb116:
  %t445 = load ptr, ptr %l0, !tbaa !29
  %t447 = getelementptr %"compiler/fmt:formatter", ptr %t445, i32 0, i32 16
  %t448 = load i64, ptr %l13, !tbaa !24
  %t451 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t447, i64 %t448)
  store i64 %t451, ptr %l259
  br label %bb117
bb117:
  %t452 = load { i64, ptr }, ptr %l251, !tbaa !27
  %t453 = extractvalue { i64, ptr } %t452, 0
  store i64 %t453, ptr %l260, !tbaa !24
  %t454 = load i64, ptr %l255, !tbaa !24
  %t455 = icmp sge i64 %t454, 0
  br i1 %t455, label %bb118, label %bb119
bb118:
  %t457 = load i64, ptr %l255, !tbaa !24
  %t458 = load i64, ptr %l259, !tbaa !24
  %t459 = icmp sle i64 %t457, %t458
  br i1 %t459, label %bb120, label %bb121
bb119:
  call void @__olang_check_failed(ptr @.c55)
  unreachable
bb120:
  %t461 = load i64, ptr %l259, !tbaa !24
  %t462 = load i64, ptr %l260, !tbaa !24
  %t463 = icmp sle i64 %t461, %t462
  br i1 %t463, label %bb122, label %bb123
bb121:
  call void @__olang_check_failed(ptr @.c55)
  unreachable
bb122:
  %t465 = getelementptr { i64, ptr }, ptr %l251, i32 0, i32 1
  %t466 = load ptr, ptr %t465, !tbaa !27
  %t467 = load i64, ptr %l255, !tbaa !24
  %t468 = load i64, ptr %l259, !tbaa !24
  %t469 = getelementptr i8, ptr %t466, i64 %t467
  %t470 = sub i64 %t468, %t467
  %t471 = insertvalue { i64, ptr } undef, i64 %t470, 0
  %t472 = insertvalue { i64, ptr } %t471, ptr %t469, 1
  %t473 = load ptr, ptr %l249, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %t473, { i64, ptr } %t472)
  br label %bb124
bb123:
  call void @__olang_check_failed(ptr @.c55)
  unreachable
bb124:
  br label %bb125
bb125:
  br label %bb126
bb126:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l2, i8 10)
  br label %bb127
bb127:
  call void @__olang_scope_close(ptr %s7)
  br label %bb128
bb128:
  %t476 = load i64, ptr %l12, !tbaa !24
  %t478 = add i64 %t476, 1
  store i64 %t478, ptr %l12, !tbaa !24
  br label %bb56
bb129:
  %t480 = load i64, ptr %l5, !tbaa !24
  store i64 %t480, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb130
bb130:
  br label %bb14
bb131:
  %t483 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l2)
  store { i64, ptr } %t483, ptr %l270
  br label %bb132
bb132:
  %t484 = load { i64, ptr }, ptr %l270, !tbaa !27
  store { i64, ptr } %t484, ptr %l271, !tbaa !27
  %t485 = load { i64, ptr }, ptr %l271, !tbaa !27
  %t486 = extractvalue { i64, ptr } %t485, 0
  store i64 %t486, ptr %l272, !tbaa !24
  %t487 = load i64, ptr %l272, !tbaa !24
  %t488 = mul i64 %t487, 1
  %t489 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t488)
  %t490 = insertvalue { i64, ptr } undef, i64 %t487, 0
  %t491 = insertvalue { i64, ptr } %t490, ptr %t489, 1
  store { i64, ptr } %t491, ptr %l273, !tbaa !27
  %t492 = getelementptr { i64, ptr }, ptr %l273, i32 0, i32 1
  %t493 = load ptr, ptr %t492, !tbaa !27
  %t494 = getelementptr { i64, ptr }, ptr %l271, i32 0, i32 1
  %t495 = load ptr, ptr %t494, !tbaa !27
  %t496 = load i64, ptr %l272, !tbaa !24
  %t497 = mul i64 %t496, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t493, ptr %t495, i64 %t497, i1 false)
  %t498 = load { i64, ptr }, ptr %l273, !tbaa !27
  store { i64, ptr } %t498, ptr %l271, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t499 = load { i64, ptr }, ptr %l271, !tbaa !27
  store { i64, ptr } %t499, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2ffmt_2ecompiler_2ffmt_3aloader_2eaddNames(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, ptr %a2, { i64, ptr } %a3, { i64, ptr } %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l21 = alloca i1
  %l22 = alloca ptr
  %l23 = alloca ptr
  %l24 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l28 = alloca i64
  %l29 = alloca i64
  %l35 = alloca i1
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s1
  %t3 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eSplit(ptr %v4, ptr %s1, { i64, ptr } %a4, { i64, ptr } { i64 1, ptr @.d56 })
  store { i64, ptr } %t3, ptr %l10
  br label %bb1
bb1:
  %t4 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t4, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t5 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  store i64 %t7, ptr %l7, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t9 = load i64, ptr %l6, !tbaa !24
  %t10 = load i64, ptr %l7, !tbaa !24
  %t13 = icmp slt i64 %t9, %t10
  %t15 = xor i1 %t13, true
  br i1 %t15, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb23
bb4:
  br label %bb5
bb5:
  %t17 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t17, ptr %l17, !tbaa !27
  %t18 = load i64, ptr %l6, !tbaa !24
  %t20 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = getelementptr { i64, ptr }, ptr %t21, i64 %t18
  %t23 = load { i64, ptr }, ptr %t22, !tbaa !37
  store { i64, ptr } %t23, ptr %l8, !tbaa !27
  %t25 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t27 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v4, ptr %s2, { i64, ptr } %t25, { i64, ptr } { i64 3, ptr @.d57 })
  store i1 %t27, ptr %l21
  br label %bb6
bb6:
  %t28 = load i1, ptr %l21, !tbaa !21
  br i1 %t28, label %bb7, label %bb8
bb7:
  %t29 = load ptr, ptr %l1, !tbaa !29
  store ptr %t29, ptr %l22, !tbaa !29
  %t30 = load ptr, ptr %l2, !tbaa !29
  store ptr %t30, ptr %l23, !tbaa !29
  %t31 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t31, ptr %l24, !tbaa !27
  %t32 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t32, ptr %l25, !tbaa !27
  %t33 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t36 = extractvalue { i64, ptr } %t33, 0
  store i64 %t36, ptr %l28, !tbaa !24
  %t37 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t38 = extractvalue { i64, ptr } %t37, 0
  store i64 %t38, ptr %l29, !tbaa !24
  %t39 = icmp sge i64 3, 0
  br i1 %t39, label %bb9, label %bb10
bb8:
  store %olang.scope zeroinitializer, ptr %s4
  %t41 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t43 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v4, ptr %s4, { i64, ptr } %t41, { i64, ptr } { i64 0, ptr @.d58 })
  store i1 %t43, ptr %l35
  br label %bb16
bb9:
  %t44 = load i64, ptr %l28, !tbaa !24
  %t45 = icmp sle i64 3, %t44
  br i1 %t45, label %bb11, label %bb12
bb10:
  call void @__olang_check_failed(ptr @.c59)
  unreachable
bb11:
  %t47 = load i64, ptr %l28, !tbaa !24
  %t48 = load i64, ptr %l29, !tbaa !24
  %t49 = icmp sle i64 %t47, %t48
  br i1 %t49, label %bb13, label %bb14
bb12:
  call void @__olang_check_failed(ptr @.c59)
  unreachable
bb13:
  %t51 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t52 = load ptr, ptr %t51, !tbaa !27
  %t53 = load i64, ptr %l28, !tbaa !24
  %t54 = getelementptr i8, ptr %t52, i64 3
  %t55 = sub i64 %t53, 3
  %t56 = insertvalue { i64, ptr } undef, i64 %t55, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t54, 1
  %t58 = load ptr, ptr %l22, !tbaa !29
  %t59 = load ptr, ptr %l23, !tbaa !29
  %t60 = load { i64, ptr }, ptr %l24, !tbaa !27
  call void @compiler_2fparse_2ecompiler_2fparse_3aOracle_2eAddFn(ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %t58, ptr %t59, { i64, ptr } %t60, { i64, ptr } %t57)
  br label %bb15
bb14:
  call void @__olang_check_failed(ptr @.c59)
  unreachable
bb15:
  br label %bb21
bb16:
  %t62 = load i1, ptr %l35, !tbaa !21
  %t63 = xor i1 %t62, true
  br i1 %t63, label %bb17, label %bb18
bb17:
  %t65 = load ptr, ptr %l1, !tbaa !29
  %t66 = load ptr, ptr %l2, !tbaa !29
  %t67 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t68 = load { i64, ptr }, ptr %l8, !tbaa !27
  call void @compiler_2fparse_2ecompiler_2fparse_3aOracle_2eAdd(ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %t65, ptr %t66, { i64, ptr } %t67, { i64, ptr } %t68)
  br label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s4)
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s2)
  br label %bb22
bb22:
  %t73 = load i64, ptr %l6, !tbaa !24
  %t75 = add i64 %t73, 1
  store i64 %t75, ptr %l6, !tbaa !24
  br label %bb2
bb23:
  call void @__olang_scope_close(ptr %s1)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffmt_2ecompiler_2ffmt_3aloader_2echains(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, i64 %a3, { i64, ptr } %a4, i64 %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca { i64, ptr }
  %l17 = alloca i64
  %l21 = alloca i64
  %l24 = alloca i64
  %l45 = alloca i64
  %l48 = alloca i1
  %l52 = alloca i64
  %l54 = alloca { i64, ptr }
  %l58 = alloca { i64, ptr }
  %l60 = alloca ptr
  %l61 = alloca ptr
  %l62 = alloca ptr
  %l63 = alloca { i64, ptr }
  %l65 = alloca ptr
  %l69 = alloca i64
  %l70 = alloca { i64, ptr }
  %l71 = alloca ptr
  %l72 = alloca ptr
  %l73 = alloca ptr
  %l77 = alloca i64
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i64 %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l5, !tbaa !24
  %t3 = icmp sge i64 %t1, 4
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  store i64 0, ptr %l6, !tbaa !24
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/fmt:loader", ptr %t5, i32 0, i32 3
  %t9 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t7)
  store i64 %t9, ptr %l17
  br label %bb4
bb4:
  %t10 = load i64, ptr %l17, !tbaa !24
  store i64 %t10, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t11 = load i64, ptr %l7, !tbaa !24
  %t12 = load i64, ptr %l6, !tbaa !24
  %t15 = icmp sgt i64 %t11, %t12
  br i1 %t15, label %bb5, label %bb6
bb5:
  %t17 = load i64, ptr %l8, !tbaa !24
  %t19 = icmp sgt i64 %t17, 0
  br i1 %t19, label %bb7, label %bb8
bb6:
  store i64 0, ptr %l21, !tbaa !24
  br label %bb10
bb7:
  %t21 = load i64, ptr %l7, !tbaa !24
  %t22 = load i64, ptr %l6, !tbaa !24
  %t25 = sub i64 %t21, %t22
  %t26 = load i64, ptr %l8, !tbaa !24
  %t29 = add i64 %t25, %t26
  %t31 = sub i64 %t29, 1
  %t32 = load i64, ptr %l8, !tbaa !24
  %t35 = sdiv i64 %t31, %t32
  store i64 %t35, ptr %l24, !tbaa !24
  br label %bb9
bb8:
  store i64 0, ptr %l24, !tbaa !24
  br label %bb9
bb9:
  %t37 = load i64, ptr %l24, !tbaa !24
  store i64 %t37, ptr %l21, !tbaa !24
  br label %bb10
bb10:
  %t38 = load i64, ptr %l21, !tbaa !24
  store i64 %t38, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb11
bb11:
  store %olang.scope zeroinitializer, ptr %s3
  %t39 = load i64, ptr %l10, !tbaa !24
  %t40 = load i64, ptr %l9, !tbaa !24
  %t43 = icmp slt i64 %t39, %t40
  %t45 = xor i1 %t43, true
  br i1 %t45, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s3)
  br label %bb30
bb13:
  br label %bb14
bb14:
  %t47 = load i64, ptr %l6, !tbaa !24
  %t48 = load i64, ptr %l10, !tbaa !24
  %t49 = load i64, ptr %l8, !tbaa !24
  %t52 = mul i64 %t48, %t49
  %t55 = add i64 %t47, %t52
  store i64 %t55, ptr %l11, !tbaa !24
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/fmt:loader", ptr %t57, i32 0, i32 3
  %t60 = load i64, ptr %l11, !tbaa !24
  %t63 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t59, i64 %t60)
  store i64 %t63, ptr %l45
  br label %bb15
bb15:
  %t65 = load i64, ptr %l45, !tbaa !24
  %t67 = icmp ne i64 %t65, %a3
  br i1 %t67, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l48, !tbaa !21
  br label %bb19
bb17:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/fmt:loader", ptr %t69, i32 0, i32 5
  %t72 = load i64, ptr %l11, !tbaa !24
  %t75 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t71, i64 %t72)
  store i64 %t75, ptr %l52
  br label %bb18
bb18:
  %t76 = load i64, ptr %l52, !tbaa !24
  %t77 = icmp slt i64 %t76, 0
  store i1 %t77, ptr %l48, !tbaa !21
  br label %bb19
bb19:
  %t79 = load i1, ptr %l48, !tbaa !21
  br i1 %t79, label %bb20, label %bb21
bb20:
  call void @__olang_scope_close(ptr %s3)
  br label %bb29
bb21:
  br label %bb22
bb22:
  store { i64, ptr } %a4, ptr %l54, !tbaa !27
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"compiler/fmt:loader", ptr %t81, i32 0, i32 4
  %t84 = load i64, ptr %l11, !tbaa !24
  %t87 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %s3, ptr %t83, i64 %t84)
  store { i64, ptr } %t87, ptr %l58
  br label %bb23
bb23:
  %t88 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t89 = extractvalue { i64, ptr } %t88, 1
  %t90 = extractvalue { i64, ptr } %t88, 0
  %t91 = load { i64, ptr }, ptr %l58, !tbaa !27
  %t92 = extractvalue { i64, ptr } %t91, 1
  %t93 = extractvalue { i64, ptr } %t91, 0
  %t94 = add i64 %t90, %t93
  %t95 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t94)
  call void @olang_textcopy(ptr %t95, ptr %t89, i64 %t90)
  %t96 = getelementptr i8, ptr %t95, i64 %t90
  call void @olang_textcopy(ptr %t96, ptr %t92, i64 %t93)
  %t97 = insertvalue { i64, ptr } undef, i64 %t94, 0
  %t98 = insertvalue { i64, ptr } %t97, ptr %t95, 1
  store { i64, ptr } %t98, ptr %l12, !tbaa !27
  %t100 = load ptr, ptr %l0, !tbaa !29
  store ptr %t100, ptr %l60, !tbaa !29
  %t101 = load ptr, ptr %l1, !tbaa !29
  store ptr %t101, ptr %l61, !tbaa !29
  %t102 = load ptr, ptr %l2, !tbaa !29
  store ptr %t102, ptr %l62, !tbaa !29
  %t103 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t103, ptr %l63, !tbaa !27
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t106 = getelementptr %"compiler/fmt:loader", ptr %t104, i32 0, i32 2
  store ptr %t106, ptr %l65, !tbaa !29
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t109 = getelementptr %"compiler/fmt:loader", ptr %t107, i32 0, i32 5
  %t110 = load i64, ptr %l11, !tbaa !24
  %t113 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t109, i64 %t110)
  store i64 %t113, ptr %l69
  br label %bb24
bb24:
  %t114 = load ptr, ptr %l65, !tbaa !29
  %t115 = load i64, ptr %l69, !tbaa !24
  %t116 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %v0, ptr %t114, i64 %t115)
  store { i64, ptr } %t116, ptr %l70
  br label %bb25
bb25:
  %t117 = load ptr, ptr %l60, !tbaa !29
  %t118 = load ptr, ptr %l61, !tbaa !29
  %t119 = load ptr, ptr %l62, !tbaa !29
  %t120 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t121 = load { i64, ptr }, ptr %l70, !tbaa !27
  call void @compiler_2ffmt_2ecompiler_2ffmt_3aloader_2eaddNames(ptr %v0, ptr %v1, ptr %v2, ptr %s3, ptr %v0, ptr %t117, ptr %t118, ptr %t119, { i64, ptr } %t120, { i64, ptr } %t121)
  br label %bb26
bb26:
  %t122 = load ptr, ptr %l0, !tbaa !29
  store ptr %t122, ptr %l71, !tbaa !29
  %t123 = load ptr, ptr %l1, !tbaa !29
  store ptr %t123, ptr %l72, !tbaa !29
  %t124 = load ptr, ptr %l2, !tbaa !29
  store ptr %t124, ptr %l73, !tbaa !29
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t127 = getelementptr %"compiler/fmt:loader", ptr %t125, i32 0, i32 5
  %t128 = load i64, ptr %l11, !tbaa !24
  %t131 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t127, i64 %t128)
  store i64 %t131, ptr %l77
  br label %bb27
bb27:
  %t132 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t134 = extractvalue { i64, ptr } %t132, 1
  %t135 = extractvalue { i64, ptr } %t132, 0
  %t136 = extractvalue { i64, ptr } { i64 1, ptr @.d60 }, 1
  %t137 = extractvalue { i64, ptr } { i64 1, ptr @.d60 }, 0
  %t138 = add i64 %t135, %t137
  %t139 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t138)
  call void @olang_textcopy(ptr %t139, ptr %t134, i64 %t135)
  %t140 = getelementptr i8, ptr %t139, i64 %t135
  call void @olang_textcopy(ptr %t140, ptr %t136, i64 %t137)
  %t141 = insertvalue { i64, ptr } undef, i64 %t138, 0
  %t142 = insertvalue { i64, ptr } %t141, ptr %t139, 1
  %t144 = extractvalue { i64, ptr } %t142, 0
  %t145 = extractvalue { i64, ptr } %t142, 1
  %t146 = mul i64 %t144, 1
  %t147 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t146)
  call void @llvm.memcpy.p0.p0.i64(ptr %t147, ptr %t145, i64 %t146, i1 false)
  %t148 = insertvalue { i64, ptr } undef, i64 %t144, 0
  %t149 = insertvalue { i64, ptr } %t148, ptr %t147, 1
  %t150 = load i64, ptr %l5, !tbaa !24
  %t152 = add i64 %t150, 1
  %t153 = load ptr, ptr %l71, !tbaa !29
  %t154 = load ptr, ptr %l72, !tbaa !29
  %t155 = load ptr, ptr %l73, !tbaa !29
  %t156 = load i64, ptr %l77, !tbaa !24
  call void @compiler_2ffmt_2ecompiler_2ffmt_3aloader_2echains(ptr %v0, ptr %v1, ptr %v2, ptr %s3, ptr %t153, ptr %t154, ptr %t155, i64 %t156, { i64, ptr } %t149, i64 %t152)
  br label %bb28
bb28:
  call void @__olang_scope_close(ptr %s3)
  br label %bb29
bb29:
  %t159 = load i64, ptr %l10, !tbaa !24
  %t161 = add i64 %t159, 1
  store i64 %t161, ptr %l10, !tbaa !24
  br label %bb11
bb30:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2ffmt_2ecompiler_2ffmt_3aloader_2eload(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca %"compiler/source:Source"
  %l10 = alloca %"compiler/scan:Tokens"
  %l11 = alloca i64
  %l12 = alloca %"std/prelude/text:StringBuilder"
  %l13 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l14 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i32
  %l24 = alloca i1
  %l25 = alloca i64
  %l26 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca { i64, ptr }
  %l35 = alloca i64
  %l36 = alloca { i64, ptr }
  %l38 = alloca { i64, ptr }
  %l39 = alloca i32
  %l45 = alloca i64
  %l49 = alloca i64
  %l52 = alloca i64
  %l73 = alloca { i64, ptr }
  %l75 = alloca i1
  %l79 = alloca %"compiler/source:Source"
  %l81 = alloca %"compiler/source:Source"
  %l82 = alloca i32
  %l87 = alloca %"compiler/scan:Tokens"
  %l90 = alloca i64
  %l96 = alloca %"std/prelude/text:StringBuilder"
  %l98 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l99 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l107 = alloca i64
  %l110 = alloca i64
  %l128 = alloca { i64, ptr }
  %l135 = alloca i1
  %l136 = alloca { i64, ptr }
  %l139 = alloca i32
  %l141 = alloca i32
  %l143 = alloca i1
  %l144 = alloca i32
  %l146 = alloca i32
  %l148 = alloca i1
  %l149 = alloca i1
  %l151 = alloca i1
  %l152 = alloca i32
  %l154 = alloca i32
  %l156 = alloca i1
  %l157 = alloca i1
  %l159 = alloca i1
  %l164 = alloca i1
  %l165 = alloca { i64, ptr }
  %l168 = alloca i32
  %l170 = alloca i32
  %l172 = alloca i1
  %l173 = alloca ptr
  %l174 = alloca { i64, ptr }
  %l175 = alloca { i64, ptr }
  %l179 = alloca i64
  %l180 = alloca { i64, ptr }
  %l184 = alloca i64
  %l185 = alloca i64
  %l191 = alloca i32
  %l193 = alloca i32
  %l195 = alloca i1
  %l196 = alloca i1
  %l198 = alloca i1
  %l203 = alloca i1
  %l204 = alloca { i64, ptr }
  %l207 = alloca i32
  %l209 = alloca i32
  %l211 = alloca i1
  %l212 = alloca ptr
  %l213 = alloca { i64, ptr }
  %l214 = alloca { i64, ptr }
  %l218 = alloca i64
  %l219 = alloca { i64, ptr }
  %l223 = alloca i64
  %l224 = alloca i64
  %l232 = alloca i32
  %l234 = alloca i32
  %l236 = alloca i1
  %l242 = alloca i1
  %l243 = alloca { i64, ptr }
  %l245 = alloca i32
  %l247 = alloca i32
  %l249 = alloca i1
  %l250 = alloca { i64, ptr }
  %l251 = alloca { i64, ptr }
  %l254 = alloca i64
  %l255 = alloca { i64, ptr }
  %l258 = alloca i64
  %l259 = alloca i64
  %l271 = alloca i1
  %l272 = alloca { i64, ptr }
  %l274 = alloca i32
  %l276 = alloca i32
  %l278 = alloca i1
  %l279 = alloca { i64, ptr }
  %l280 = alloca { i64, ptr }
  %l284 = alloca i64
  %l285 = alloca { i64, ptr }
  %l289 = alloca i64
  %l290 = alloca i64
  %l296 = alloca i1
  %l298 = alloca { i64, ptr }
  %l312 = alloca ptr
  %l314 = alloca { i64, ptr }
  %l316 = alloca i64
  %l320 = alloca i64
  %l323 = alloca i64
  %l341 = alloca ptr
  %l342 = alloca { i64, ptr }
  %l345 = alloca { i64, ptr }
  %l346 = alloca { i64, ptr }
  %l348 = alloca i1
  %l352 = alloca i64
  %l357 = alloca ptr
  %l360 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = call { i32, { i64, ptr } } @std_2fos_2eRealPath(ptr %v1, ptr %s0, { i64, ptr } %a1)
  %t4 = extractvalue { i32, { i64, ptr } } %t3, 1
  %t5 = extractvalue { i32, { i64, ptr } } %t3, 0
  store i32 %t5, ptr %l39
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7
ok.7:
  store { i64, ptr } %t4, ptr %l38
  br label %bb1
bb1:
  %t8 = load { i64, ptr }, ptr %l38, !tbaa !27
  store { i64, ptr } %t8, ptr %l36, !tbaa !27
  br label %bb6
bb2:
  %t9 = load i32, ptr %l39, !tbaa !23
  %t10 = ashr i32 %t9, 16
  %t12 = icmp eq i32 %t10, 1
  br i1 %t12, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  call void @__olang_check_failed(ptr @.c61)
  unreachable
bb5:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb6:
  %t15 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t15, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/fmt:loader", ptr %t16, i32 0, i32 1
  %t20 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %v0, ptr %t18)
  store i64 %t20, ptr %l45
  br label %bb7
bb7:
  %t21 = load i64, ptr %l45, !tbaa !24
  store i64 %t21, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t22 = load i64, ptr %l4, !tbaa !24
  %t23 = load i64, ptr %l3, !tbaa !24
  %t26 = icmp sgt i64 %t22, %t23
  br i1 %t26, label %bb8, label %bb9
bb8:
  %t28 = load i64, ptr %l5, !tbaa !24
  %t30 = icmp sgt i64 %t28, 0
  br i1 %t30, label %bb10, label %bb11
bb9:
  store i64 0, ptr %l49, !tbaa !24
  br label %bb13
bb10:
  %t32 = load i64, ptr %l4, !tbaa !24
  %t33 = load i64, ptr %l3, !tbaa !24
  %t36 = sub i64 %t32, %t33
  %t37 = load i64, ptr %l5, !tbaa !24
  %t40 = add i64 %t36, %t37
  %t42 = sub i64 %t40, 1
  %t43 = load i64, ptr %l5, !tbaa !24
  %t46 = sdiv i64 %t42, %t43
  store i64 %t46, ptr %l52, !tbaa !24
  br label %bb12
bb11:
  store i64 0, ptr %l52, !tbaa !24
  br label %bb12
bb12:
  %t48 = load i64, ptr %l52, !tbaa !24
  store i64 %t48, ptr %l49, !tbaa !24
  br label %bb13
bb13:
  %t49 = load i64, ptr %l49, !tbaa !24
  store i64 %t49, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb14
bb14:
  store %olang.scope zeroinitializer, ptr %s3
  %t50 = load i64, ptr %l7, !tbaa !24
  %t51 = load i64, ptr %l6, !tbaa !24
  %t54 = icmp slt i64 %t50, %t51
  %t56 = xor i1 %t54, true
  br i1 %t56, label %bb15, label %bb16
bb15:
  call void @__olang_scope_close(ptr %s3)
  br label %bb24
bb16:
  br label %bb17
bb17:
  %t58 = load i64, ptr %l3, !tbaa !24
  %t59 = load i64, ptr %l7, !tbaa !24
  %t60 = load i64, ptr %l5, !tbaa !24
  %t63 = mul i64 %t59, %t60
  %t66 = add i64 %t58, %t63
  store i64 %t66, ptr %l8, !tbaa !24
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/fmt:loader", ptr %t68, i32 0, i32 1
  %t71 = load i64, ptr %l8, !tbaa !24
  %t74 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %v0, ptr %t70, i64 %t71)
  store { i64, ptr } %t74, ptr %l73
  br label %bb18
bb18:
  %t75 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t76 = load { i64, ptr }, ptr %l73, !tbaa !27
  %t78 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t76, { i64, ptr } %t75)
  store i1 %t78, ptr %l75
  br label %bb19
bb19:
  %t79 = load i1, ptr %l75, !tbaa !21
  br i1 %t79, label %bb20, label %bb21
bb20:
  %t80 = load i64, ptr %l8, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  store i64 %t80, ptr %rv
  br label %ret
bb21:
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s3)
  br label %bb23
bb23:
  %t82 = load i64, ptr %l7, !tbaa !24
  %t84 = add i64 %t82, 1
  store i64 %t84, ptr %l7, !tbaa !24
  br label %bb14
bb24:
  %t86 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t88 = call { i32, %"compiler/source:Source" } @compiler_2fsource_2eRead(ptr %s0, ptr %s0, { i64, ptr } %t86)
  %t89 = extractvalue { i32, %"compiler/source:Source" } %t88, 1
  %t90 = extractvalue { i32, %"compiler/source:Source" } %t88, 0
  store i32 %t90, ptr %l82
  %t91 = icmp ne i32 %t90, 0
  br i1 %t91, label %bb26, label %ok.92
ok.92:
  store %"compiler/source:Source" %t89, ptr %l81
  br label %bb25
bb25:
  %t93 = load %"compiler/source:Source", ptr %l81
  store %"compiler/source:Source" %t93, ptr %l79
  br label %bb30
bb26:
  %t94 = load i32, ptr %l82, !tbaa !23
  %t95 = ashr i32 %t94, 16
  %t97 = icmp eq i32 %t95, 1
  br i1 %t97, label %bb27, label %bb28
bb27:
  br label %bb29
bb28:
  call void @__olang_check_failed(ptr @.c62)
  unreachable
bb29:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb30:
  %t100 = load %"compiler/source:Source", ptr %l79
  store %"compiler/source:Source" %t100, ptr %l9
  %t101 = getelementptr %"compiler/source:Source", ptr %l9, i32 0, i32 1
  %t102 = load { i64, ptr }, ptr %t101, !tbaa !27
  %t104 = call %"compiler/scan:Tokens" @compiler_2fscan_2eScan(ptr %s0, ptr %s0, { i64, ptr } %t102)
  store %"compiler/scan:Tokens" %t104, ptr %l87
  br label %bb31
bb31:
  %t105 = load %"compiler/scan:Tokens", ptr %l87
  store %"compiler/scan:Tokens" %t105, ptr %l10
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t108 = getelementptr %"compiler/fmt:loader", ptr %t106, i32 0, i32 1
  %t110 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %v0, ptr %t108)
  store i64 %t110, ptr %l90
  br label %bb32
bb32:
  %t111 = load i64, ptr %l90, !tbaa !24
  store i64 %t111, ptr %l11, !tbaa !24
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t114 = getelementptr %"compiler/fmt:loader", ptr %t112, i32 0, i32 1
  %t115 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t117 = extractvalue { i64, ptr } %t115, 1
  %t118 = extractvalue { i64, ptr } %t115, 0
  %t119 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t118)
  call void @olang_textcopy(ptr %t119, ptr %t117, i64 %t118)
  %t120 = insertvalue { i64, ptr } undef, i64 %t118, 0
  %t121 = insertvalue { i64, ptr } %t120, ptr %t119, 1
  %t123 = extractvalue { i64, ptr } %t121, 0
  %t124 = extractvalue { i64, ptr } %t121, 1
  %t125 = mul i64 %t123, 1
  %t126 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t125)
  call void @llvm.memcpy.p0.p0.i64(ptr %t126, ptr %t124, i64 %t125, i1 false)
  %t127 = insertvalue { i64, ptr } undef, i64 %t123, 0
  %t128 = insertvalue { i64, ptr } %t127, ptr %t126, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v0, ptr %v0, ptr %t114, { i64, ptr } %t128)
  br label %bb33
bb33:
  %t131 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t131, ptr %l96
  br label %bb34
bb34:
  %t132 = load %"std/prelude/text:StringBuilder", ptr %l96
  store %"std/prelude/text:StringBuilder" %t132, ptr %l12
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l12, i8 32)
  br label %bb35
bb35:
  %t134 = load ptr, ptr @__olang_prog_scope
  %t135 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t134)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t135, ptr %l98
  br label %bb36
bb36:
  %t136 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l98
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t136, ptr %l13
  %t137 = load ptr, ptr @__olang_prog_scope
  %t138 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t137)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t138, ptr %l99
  br label %bb37
bb37:
  %t139 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l99
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t139, ptr %l14
  %t140 = getelementptr %"compiler/scan:Tokens", ptr %l10, i32 0, i32 0
  %t141 = load { i64, ptr }, ptr %t140, !tbaa !27
  store { i64, ptr } %t141, ptr %l15, !tbaa !27
  %t143 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t145 = extractvalue { i64, ptr } %t143, 0
  store i64 %t145, ptr %l16, !tbaa !24
  store i64 0, ptr %l17, !tbaa !24
  %t147 = load i64, ptr %l16, !tbaa !24
  store i64 %t147, ptr %l18, !tbaa !24
  store i64 1, ptr %l19, !tbaa !24
  %t149 = load i64, ptr %l18, !tbaa !24
  %t150 = load i64, ptr %l17, !tbaa !24
  %t153 = icmp sgt i64 %t149, %t150
  br i1 %t153, label %bb38, label %bb39
bb38:
  %t155 = load i64, ptr %l19, !tbaa !24
  %t157 = icmp sgt i64 %t155, 0
  br i1 %t157, label %bb40, label %bb41
bb39:
  store i64 0, ptr %l107, !tbaa !24
  br label %bb43
bb40:
  %t159 = load i64, ptr %l18, !tbaa !24
  %t160 = load i64, ptr %l17, !tbaa !24
  %t163 = sub i64 %t159, %t160
  %t164 = load i64, ptr %l19, !tbaa !24
  %t167 = add i64 %t163, %t164
  %t169 = sub i64 %t167, 1
  %t170 = load i64, ptr %l19, !tbaa !24
  %t173 = sdiv i64 %t169, %t170
  store i64 %t173, ptr %l110, !tbaa !24
  br label %bb42
bb41:
  store i64 0, ptr %l110, !tbaa !24
  br label %bb42
bb42:
  %t175 = load i64, ptr %l110, !tbaa !24
  store i64 %t175, ptr %l107, !tbaa !24
  br label %bb43
bb43:
  %t176 = load i64, ptr %l107, !tbaa !24
  store i64 %t176, ptr %l20, !tbaa !24
  store i64 0, ptr %l21, !tbaa !24
  br label %bb44
bb44:
  store %olang.scope zeroinitializer, ptr %s9
  %t177 = load i64, ptr %l21, !tbaa !24
  %t178 = load i64, ptr %l20, !tbaa !24
  %t181 = icmp slt i64 %t177, %t178
  %t183 = xor i1 %t181, true
  br i1 %t183, label %bb45, label %bb46
bb45:
  call void @__olang_scope_close(ptr %s9)
  br label %bb141
bb46:
  br label %bb47
bb47:
  %t185 = load i64, ptr %l17, !tbaa !24
  %t186 = load i64, ptr %l21, !tbaa !24
  %t187 = load i64, ptr %l19, !tbaa !24
  %t190 = mul i64 %t186, %t187
  %t193 = add i64 %t185, %t190
  store i64 %t193, ptr %l22, !tbaa !24
  %t195 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t195, ptr %l128, !tbaa !27
  %t196 = load i64, ptr %l22, !tbaa !24
  %t198 = getelementptr { i64, ptr }, ptr %l128, i32 0, i32 1
  %t199 = load ptr, ptr %t198, !tbaa !27
  %t200 = getelementptr %"compiler/token:Token", ptr %t199, i64 %t196
  %t201 = getelementptr %"compiler/token:Token", ptr %t200, i32 0, i32 0
  %t202 = load i32, ptr %t201
  store i32 %t202, ptr %l23
  %t204 = load i64, ptr %l22, !tbaa !24
  %t206 = add i64 %t204, 1
  %t207 = load i64, ptr %l16, !tbaa !24
  %t210 = icmp slt i64 %t206, %t207
  br i1 %t210, label %bb48, label %bb49
bb48:
  %t212 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t212, ptr %l136, !tbaa !27
  %t213 = load i64, ptr %l22, !tbaa !24
  %t215 = add i64 %t213, 1
  %t217 = getelementptr { i64, ptr }, ptr %l136, i32 0, i32 1
  %t218 = load ptr, ptr %t217, !tbaa !27
  %t219 = getelementptr %"compiler/token:Token", ptr %t218, i64 %t215
  %t220 = getelementptr %"compiler/token:Token", ptr %t219, i32 0, i32 0
  %t221 = load i32, ptr %t220
  store i32 %t221, ptr %l139
  store i32 1, ptr %l141
  %t224 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l139, ptr %l141)
  store i1 %t224, ptr %l143
  br label %bb50
bb49:
  store i1 false, ptr %l135, !tbaa !21
  br label %bb51
bb50:
  %t225 = load i1, ptr %l143, !tbaa !21
  store i1 %t225, ptr %l135, !tbaa !21
  br label %bb51
bb51:
  %t226 = load i1, ptr %l135, !tbaa !21
  store i1 %t226, ptr %l24, !tbaa !21
  %t227 = load i32, ptr %l23
  store i32 %t227, ptr %l144
  store i32 33, ptr %l146
  %t230 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l144, ptr %l146)
  store i1 %t230, ptr %l148
  br label %bb52
bb52:
  %t231 = load i1, ptr %l148, !tbaa !21
  br i1 %t231, label %bb53, label %bb54
bb53:
  %t232 = load i1, ptr %l24, !tbaa !21
  store i1 %t232, ptr %l149, !tbaa !21
  br label %bb55
bb54:
  store i1 false, ptr %l149, !tbaa !21
  br label %bb55
bb55:
  %t234 = load i1, ptr %l149, !tbaa !21
  br i1 %t234, label %bb56, label %bb57
bb56:
  store i1 true, ptr %l151, !tbaa !21
  br label %bb69
bb57:
  %t235 = load i32, ptr %l23
  store i32 %t235, ptr %l152
  store i32 38, ptr %l154
  %t238 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l152, ptr %l154)
  store i1 %t238, ptr %l156
  br label %bb58
bb58:
  %t239 = load i1, ptr %l156, !tbaa !21
  br i1 %t239, label %bb59, label %bb60
bb59:
  %t240 = load i1, ptr %l24, !tbaa !21
  store i1 %t240, ptr %l157, !tbaa !21
  br label %bb61
bb60:
  store i1 false, ptr %l157, !tbaa !21
  br label %bb61
bb61:
  %t242 = load i1, ptr %l157, !tbaa !21
  br i1 %t242, label %bb62, label %bb63
bb62:
  %t243 = load i64, ptr %l22, !tbaa !24
  %t245 = add i64 %t243, 2
  %t246 = load i64, ptr %l16, !tbaa !24
  %t249 = icmp slt i64 %t245, %t246
  store i1 %t249, ptr %l159, !tbaa !21
  br label %bb64
bb63:
  store i1 false, ptr %l159, !tbaa !21
  br label %bb64
bb64:
  %t251 = load i1, ptr %l159, !tbaa !21
  br i1 %t251, label %bb65, label %bb66
bb65:
  %t252 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t252, ptr %l165, !tbaa !27
  %t253 = load i64, ptr %l22, !tbaa !24
  %t255 = add i64 %t253, 2
  %t257 = getelementptr { i64, ptr }, ptr %l165, i32 0, i32 1
  %t258 = load ptr, ptr %t257, !tbaa !27
  %t259 = getelementptr %"compiler/token:Token", ptr %t258, i64 %t255
  %t260 = getelementptr %"compiler/token:Token", ptr %t259, i32 0, i32 0
  %t261 = load i32, ptr %t260
  store i32 %t261, ptr %l168
  store i32 92, ptr %l170
  %t264 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l168, ptr %l170)
  store i1 %t264, ptr %l172
  br label %bb67
bb66:
  store i1 false, ptr %l164, !tbaa !21
  br label %bb68
bb67:
  %t265 = load i1, ptr %l172, !tbaa !21
  store i1 %t265, ptr %l164, !tbaa !21
  br label %bb68
bb68:
  %t266 = load i1, ptr %l164, !tbaa !21
  store i1 %t266, ptr %l151, !tbaa !21
  br label %bb69
bb69:
  %t267 = load i1, ptr %l151, !tbaa !21
  br i1 %t267, label %bb70, label %bb71
bb70:
  store ptr %l12, ptr %l173, !tbaa !29
  %t268 = getelementptr %"compiler/source:Source", ptr %l9, i32 0, i32 1
  %t269 = load { i64, ptr }, ptr %t268, !tbaa !27
  store { i64, ptr } %t269, ptr %l174, !tbaa !27
  %t270 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t270, ptr %l175, !tbaa !27
  %t271 = load i64, ptr %l22, !tbaa !24
  %t273 = add i64 %t271, 1
  %t275 = getelementptr { i64, ptr }, ptr %l175, i32 0, i32 1
  %t276 = load ptr, ptr %t275, !tbaa !27
  %t277 = getelementptr %"compiler/token:Token", ptr %t276, i64 %t273
  %t278 = getelementptr %"compiler/token:Token", ptr %t277, i32 0, i32 2
  %t279 = load i32, ptr %t278, !tbaa !23
  %t281 = sext i32 %t279 to i64
  store i64 %t281, ptr %l179, !tbaa !24
  %t282 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t282, ptr %l180, !tbaa !27
  %t283 = load i64, ptr %l22, !tbaa !24
  %t285 = add i64 %t283, 1
  %t287 = getelementptr { i64, ptr }, ptr %l180, i32 0, i32 1
  %t288 = load ptr, ptr %t287, !tbaa !27
  %t289 = getelementptr %"compiler/token:Token", ptr %t288, i64 %t285
  %t290 = getelementptr %"compiler/token:Token", ptr %t289, i32 0, i32 3
  %t291 = load i32, ptr %t290, !tbaa !23
  %t293 = sext i32 %t291 to i64
  store i64 %t293, ptr %l184, !tbaa !24
  %t294 = load { i64, ptr }, ptr %l174, !tbaa !27
  %t295 = extractvalue { i64, ptr } %t294, 0
  store i64 %t295, ptr %l185, !tbaa !24
  %t296 = load i64, ptr %l179, !tbaa !24
  %t297 = icmp sge i64 %t296, 0
  br i1 %t297, label %bb72, label %bb73
bb71:
  br label %bb80
bb72:
  %t299 = load i64, ptr %l179, !tbaa !24
  %t300 = load i64, ptr %l184, !tbaa !24
  %t301 = icmp sle i64 %t299, %t300
  br i1 %t301, label %bb74, label %bb75
bb73:
  call void @__olang_check_failed(ptr @.c63)
  unreachable
bb74:
  %t303 = load i64, ptr %l184, !tbaa !24
  %t304 = load i64, ptr %l185, !tbaa !24
  %t305 = icmp sle i64 %t303, %t304
  br i1 %t305, label %bb76, label %bb77
bb75:
  call void @__olang_check_failed(ptr @.c63)
  unreachable
bb76:
  %t307 = getelementptr { i64, ptr }, ptr %l174, i32 0, i32 1
  %t308 = load ptr, ptr %t307, !tbaa !27
  %t309 = load i64, ptr %l179, !tbaa !24
  %t310 = load i64, ptr %l184, !tbaa !24
  %t311 = getelementptr i8, ptr %t308, i64 %t309
  %t312 = sub i64 %t310, %t309
  %t313 = insertvalue { i64, ptr } undef, i64 %t312, 0
  %t314 = insertvalue { i64, ptr } %t313, ptr %t311, 1
  %t315 = load ptr, ptr %l173, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t315, { i64, ptr } %t314)
  br label %bb78
bb77:
  call void @__olang_check_failed(ptr @.c63)
  unreachable
bb78:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l12, i8 32)
  br label %bb79
bb79:
  br label %bb80
bb80:
  %t318 = load i32, ptr %l23
  store i32 %t318, ptr %l191
  store i32 37, ptr %l193
  %t321 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l191, ptr %l193)
  store i1 %t321, ptr %l195
  br label %bb81
bb81:
  %t322 = load i1, ptr %l195, !tbaa !21
  br i1 %t322, label %bb82, label %bb83
bb82:
  %t323 = load i1, ptr %l24, !tbaa !21
  store i1 %t323, ptr %l196, !tbaa !21
  br label %bb84
bb83:
  store i1 false, ptr %l196, !tbaa !21
  br label %bb84
bb84:
  %t325 = load i1, ptr %l196, !tbaa !21
  br i1 %t325, label %bb85, label %bb86
bb85:
  %t326 = load i64, ptr %l22, !tbaa !24
  %t328 = add i64 %t326, 2
  %t329 = load i64, ptr %l16, !tbaa !24
  %t332 = icmp slt i64 %t328, %t329
  store i1 %t332, ptr %l198, !tbaa !21
  br label %bb87
bb86:
  store i1 false, ptr %l198, !tbaa !21
  br label %bb87
bb87:
  %t334 = load i1, ptr %l198, !tbaa !21
  br i1 %t334, label %bb88, label %bb89
bb88:
  %t335 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t335, ptr %l204, !tbaa !27
  %t336 = load i64, ptr %l22, !tbaa !24
  %t338 = add i64 %t336, 2
  %t340 = getelementptr { i64, ptr }, ptr %l204, i32 0, i32 1
  %t341 = load ptr, ptr %t340, !tbaa !27
  %t342 = getelementptr %"compiler/token:Token", ptr %t341, i64 %t338
  %t343 = getelementptr %"compiler/token:Token", ptr %t342, i32 0, i32 0
  %t344 = load i32, ptr %t343
  store i32 %t344, ptr %l207
  store i32 77, ptr %l209
  %t347 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l207, ptr %l209)
  store i1 %t347, ptr %l211
  br label %bb90
bb89:
  store i1 false, ptr %l203, !tbaa !21
  br label %bb91
bb90:
  %t348 = load i1, ptr %l211, !tbaa !21
  store i1 %t348, ptr %l203, !tbaa !21
  br label %bb91
bb91:
  %t349 = load i1, ptr %l203, !tbaa !21
  br i1 %t349, label %bb92, label %bb93
bb92:
  store %olang.scope zeroinitializer, ptr %s11
  store ptr %l12, ptr %l212, !tbaa !29
  %t350 = getelementptr %"compiler/source:Source", ptr %l9, i32 0, i32 1
  %t351 = load { i64, ptr }, ptr %t350, !tbaa !27
  store { i64, ptr } %t351, ptr %l213, !tbaa !27
  %t352 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t352, ptr %l214, !tbaa !27
  %t353 = load i64, ptr %l22, !tbaa !24
  %t355 = add i64 %t353, 1
  %t357 = getelementptr { i64, ptr }, ptr %l214, i32 0, i32 1
  %t358 = load ptr, ptr %t357, !tbaa !27
  %t359 = getelementptr %"compiler/token:Token", ptr %t358, i64 %t355
  %t360 = getelementptr %"compiler/token:Token", ptr %t359, i32 0, i32 2
  %t361 = load i32, ptr %t360, !tbaa !23
  %t363 = sext i32 %t361 to i64
  store i64 %t363, ptr %l218, !tbaa !24
  %t364 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t364, ptr %l219, !tbaa !27
  %t365 = load i64, ptr %l22, !tbaa !24
  %t367 = add i64 %t365, 1
  %t369 = getelementptr { i64, ptr }, ptr %l219, i32 0, i32 1
  %t370 = load ptr, ptr %t369, !tbaa !27
  %t371 = getelementptr %"compiler/token:Token", ptr %t370, i64 %t367
  %t372 = getelementptr %"compiler/token:Token", ptr %t371, i32 0, i32 3
  %t373 = load i32, ptr %t372, !tbaa !23
  %t375 = sext i32 %t373 to i64
  store i64 %t375, ptr %l223, !tbaa !24
  %t376 = load { i64, ptr }, ptr %l213, !tbaa !27
  %t377 = extractvalue { i64, ptr } %t376, 0
  store i64 %t377, ptr %l224, !tbaa !24
  %t378 = load i64, ptr %l218, !tbaa !24
  %t379 = icmp sge i64 %t378, 0
  br i1 %t379, label %bb94, label %bb95
bb93:
  br label %bb102
bb94:
  %t381 = load i64, ptr %l218, !tbaa !24
  %t382 = load i64, ptr %l223, !tbaa !24
  %t383 = icmp sle i64 %t381, %t382
  br i1 %t383, label %bb96, label %bb97
bb95:
  call void @__olang_check_failed(ptr @.c64)
  unreachable
bb96:
  %t385 = load i64, ptr %l223, !tbaa !24
  %t386 = load i64, ptr %l224, !tbaa !24
  %t387 = icmp sle i64 %t385, %t386
  br i1 %t387, label %bb98, label %bb99
bb97:
  call void @__olang_check_failed(ptr @.c64)
  unreachable
bb98:
  %t389 = getelementptr { i64, ptr }, ptr %l213, i32 0, i32 1
  %t390 = load ptr, ptr %t389, !tbaa !27
  %t391 = load i64, ptr %l218, !tbaa !24
  %t392 = load i64, ptr %l223, !tbaa !24
  %t393 = getelementptr i8, ptr %t390, i64 %t391
  %t394 = sub i64 %t392, %t391
  %t395 = insertvalue { i64, ptr } undef, i64 %t394, 0
  %t396 = insertvalue { i64, ptr } %t395, ptr %t393, 1
  %t397 = extractvalue { i64, ptr } { i64 3, ptr @.d65 }, 1
  %t398 = extractvalue { i64, ptr } { i64 3, ptr @.d65 }, 0
  %t400 = extractvalue { i64, ptr } %t396, 1
  %t401 = extractvalue { i64, ptr } %t396, 0
  %t402 = add i64 %t398, %t401
  %t403 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t402)
  call void @olang_textcopy(ptr %t403, ptr %t397, i64 %t398)
  %t404 = getelementptr i8, ptr %t403, i64 %t398
  call void @olang_textcopy(ptr %t404, ptr %t400, i64 %t401)
  %t405 = insertvalue { i64, ptr } undef, i64 %t402, 0
  %t406 = insertvalue { i64, ptr } %t405, ptr %t403, 1
  %t408 = extractvalue { i64, ptr } %t406, 0
  %t409 = extractvalue { i64, ptr } %t406, 1
  %t410 = mul i64 %t408, 1
  %t411 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t410)
  call void @llvm.memcpy.p0.p0.i64(ptr %t411, ptr %t409, i64 %t410, i1 false)
  %t412 = insertvalue { i64, ptr } undef, i64 %t408, 0
  %t413 = insertvalue { i64, ptr } %t412, ptr %t411, 1
  %t414 = load ptr, ptr %l212, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s11, ptr %t414, { i64, ptr } %t413)
  br label %bb100
bb99:
  call void @__olang_check_failed(ptr @.c64)
  unreachable
bb100:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l12, i8 32)
  br label %bb101
bb101:
  call void @__olang_scope_close(ptr %s11)
  br label %bb102
bb102:
  %t417 = load i32, ptr %l23
  store i32 %t417, ptr %l232
  store i32 40, ptr %l234
  %t420 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l232, ptr %l234)
  store i1 %t420, ptr %l236
  br label %bb103
bb103:
  %t421 = load i1, ptr %l236, !tbaa !21
  br i1 %t421, label %bb104, label %bb105
bb104:
  store %olang.scope zeroinitializer, ptr %s13
  %t422 = load i64, ptr %l22, !tbaa !24
  %t424 = add i64 %t422, 1
  store i64 %t424, ptr %l25, !tbaa !24
  store { i64, ptr } { i64 0, ptr @.d66 }, ptr %l26, !tbaa !27
  %t426 = load i64, ptr %l25, !tbaa !24
  %t427 = load i64, ptr %l16, !tbaa !24
  %t430 = icmp slt i64 %t426, %t427
  br i1 %t430, label %bb106, label %bb107
bb105:
  br label %bb139
bb106:
  %t432 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t432, ptr %l243, !tbaa !27
  %t433 = load i64, ptr %l25, !tbaa !24
  %t435 = getelementptr { i64, ptr }, ptr %l243, i32 0, i32 1
  %t436 = load ptr, ptr %t435, !tbaa !27
  %t437 = getelementptr %"compiler/token:Token", ptr %t436, i64 %t433
  %t438 = getelementptr %"compiler/token:Token", ptr %t437, i32 0, i32 0
  %t439 = load i32, ptr %t438
  store i32 %t439, ptr %l245
  store i32 1, ptr %l247
  %t442 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l245, ptr %l247)
  store i1 %t442, ptr %l249
  br label %bb108
bb107:
  store i1 false, ptr %l242, !tbaa !21
  br label %bb109
bb108:
  %t443 = load i1, ptr %l249, !tbaa !21
  store i1 %t443, ptr %l242, !tbaa !21
  br label %bb109
bb109:
  %t444 = load i1, ptr %l242, !tbaa !21
  br i1 %t444, label %bb110, label %bb111
bb110:
  %t445 = getelementptr %"compiler/source:Source", ptr %l9, i32 0, i32 1
  %t446 = load { i64, ptr }, ptr %t445, !tbaa !27
  store { i64, ptr } %t446, ptr %l250, !tbaa !27
  %t447 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t447, ptr %l251, !tbaa !27
  %t448 = load i64, ptr %l25, !tbaa !24
  %t450 = getelementptr { i64, ptr }, ptr %l251, i32 0, i32 1
  %t451 = load ptr, ptr %t450, !tbaa !27
  %t452 = getelementptr %"compiler/token:Token", ptr %t451, i64 %t448
  %t453 = getelementptr %"compiler/token:Token", ptr %t452, i32 0, i32 2
  %t454 = load i32, ptr %t453, !tbaa !23
  %t456 = sext i32 %t454 to i64
  store i64 %t456, ptr %l254, !tbaa !24
  %t457 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t457, ptr %l255, !tbaa !27
  %t458 = load i64, ptr %l25, !tbaa !24
  %t460 = getelementptr { i64, ptr }, ptr %l255, i32 0, i32 1
  %t461 = load ptr, ptr %t460, !tbaa !27
  %t462 = getelementptr %"compiler/token:Token", ptr %t461, i64 %t458
  %t463 = getelementptr %"compiler/token:Token", ptr %t462, i32 0, i32 3
  %t464 = load i32, ptr %t463, !tbaa !23
  %t466 = sext i32 %t464 to i64
  store i64 %t466, ptr %l258, !tbaa !24
  %t467 = load { i64, ptr }, ptr %l250, !tbaa !27
  %t468 = extractvalue { i64, ptr } %t467, 0
  store i64 %t468, ptr %l259, !tbaa !24
  %t469 = load i64, ptr %l254, !tbaa !24
  %t470 = icmp sge i64 %t469, 0
  br i1 %t470, label %bb112, label %bb113
bb111:
  br label %bb118
bb112:
  %t472 = load i64, ptr %l254, !tbaa !24
  %t473 = load i64, ptr %l258, !tbaa !24
  %t474 = icmp sle i64 %t472, %t473
  br i1 %t474, label %bb114, label %bb115
bb113:
  call void @__olang_check_failed(ptr @.c67)
  unreachable
bb114:
  %t476 = load i64, ptr %l258, !tbaa !24
  %t477 = load i64, ptr %l259, !tbaa !24
  %t478 = icmp sle i64 %t476, %t477
  br i1 %t478, label %bb116, label %bb117
bb115:
  call void @__olang_check_failed(ptr @.c67)
  unreachable
bb116:
  %t480 = getelementptr { i64, ptr }, ptr %l250, i32 0, i32 1
  %t481 = load ptr, ptr %t480, !tbaa !27
  %t482 = load i64, ptr %l254, !tbaa !24
  %t483 = load i64, ptr %l258, !tbaa !24
  %t484 = getelementptr i8, ptr %t481, i64 %t482
  %t485 = sub i64 %t483, %t482
  %t486 = insertvalue { i64, ptr } undef, i64 %t485, 0
  %t487 = insertvalue { i64, ptr } %t486, ptr %t484, 1
  %t489 = extractvalue { i64, ptr } %t487, 1
  %t490 = extractvalue { i64, ptr } %t487, 0
  %t491 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t490)
  call void @olang_textcopy(ptr %t491, ptr %t489, i64 %t490)
  %t492 = insertvalue { i64, ptr } undef, i64 %t490, 0
  %t493 = insertvalue { i64, ptr } %t492, ptr %t491, 1
  %t495 = extractvalue { i64, ptr } %t493, 0
  %t496 = extractvalue { i64, ptr } %t493, 1
  %t497 = mul i64 %t495, 1
  %t498 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t497)
  call void @llvm.memcpy.p0.p0.i64(ptr %t498, ptr %t496, i64 %t497, i1 false)
  %t499 = insertvalue { i64, ptr } undef, i64 %t495, 0
  %t500 = insertvalue { i64, ptr } %t499, ptr %t498, 1
  store { i64, ptr } %t500, ptr %l26, !tbaa !27
  %t502 = load i64, ptr %l25, !tbaa !24
  %t504 = add i64 %t502, 1
  store i64 %t504, ptr %l25, !tbaa !24
  br label %bb118
bb117:
  call void @__olang_check_failed(ptr @.c67)
  unreachable
bb118:
  %t506 = load i64, ptr %l25, !tbaa !24
  %t507 = load i64, ptr %l16, !tbaa !24
  %t510 = icmp slt i64 %t506, %t507
  br i1 %t510, label %bb119, label %bb120
bb119:
  %t512 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t512, ptr %l272, !tbaa !27
  %t513 = load i64, ptr %l25, !tbaa !24
  %t515 = getelementptr { i64, ptr }, ptr %l272, i32 0, i32 1
  %t516 = load ptr, ptr %t515, !tbaa !27
  %t517 = getelementptr %"compiler/token:Token", ptr %t516, i64 %t513
  %t518 = getelementptr %"compiler/token:Token", ptr %t517, i32 0, i32 0
  %t519 = load i32, ptr %t518
  store i32 %t519, ptr %l274
  store i32 5, ptr %l276
  %t522 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l274, ptr %l276)
  store i1 %t522, ptr %l278
  br label %bb121
bb120:
  store i1 false, ptr %l271, !tbaa !21
  br label %bb122
bb121:
  %t523 = load i1, ptr %l278, !tbaa !21
  store i1 %t523, ptr %l271, !tbaa !21
  br label %bb122
bb122:
  %t524 = load i1, ptr %l271, !tbaa !21
  br i1 %t524, label %bb123, label %bb124
bb123:
  store %olang.scope zeroinitializer, ptr %s16
  %t525 = getelementptr %"compiler/source:Source", ptr %l9, i32 0, i32 1
  %t526 = load { i64, ptr }, ptr %t525, !tbaa !27
  store { i64, ptr } %t526, ptr %l279, !tbaa !27
  %t527 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t527, ptr %l280, !tbaa !27
  %t528 = load i64, ptr %l25, !tbaa !24
  %t530 = getelementptr { i64, ptr }, ptr %l280, i32 0, i32 1
  %t531 = load ptr, ptr %t530, !tbaa !27
  %t532 = getelementptr %"compiler/token:Token", ptr %t531, i64 %t528
  %t533 = getelementptr %"compiler/token:Token", ptr %t532, i32 0, i32 2
  %t534 = load i32, ptr %t533, !tbaa !23
  %t536 = add i32 %t534, 1
  %t538 = sext i32 %t536 to i64
  store i64 %t538, ptr %l284, !tbaa !24
  %t539 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t539, ptr %l285, !tbaa !27
  %t540 = load i64, ptr %l25, !tbaa !24
  %t542 = getelementptr { i64, ptr }, ptr %l285, i32 0, i32 1
  %t543 = load ptr, ptr %t542, !tbaa !27
  %t544 = getelementptr %"compiler/token:Token", ptr %t543, i64 %t540
  %t545 = getelementptr %"compiler/token:Token", ptr %t544, i32 0, i32 3
  %t546 = load i32, ptr %t545, !tbaa !23
  %t548 = sub i32 %t546, 1
  %t550 = sext i32 %t548 to i64
  store i64 %t550, ptr %l289, !tbaa !24
  %t551 = load { i64, ptr }, ptr %l279, !tbaa !27
  %t552 = extractvalue { i64, ptr } %t551, 0
  store i64 %t552, ptr %l290, !tbaa !24
  %t553 = load i64, ptr %l284, !tbaa !24
  %t554 = icmp sge i64 %t553, 0
  br i1 %t554, label %bb125, label %bb126
bb124:
  br label %bb138
bb125:
  %t556 = load i64, ptr %l284, !tbaa !24
  %t557 = load i64, ptr %l289, !tbaa !24
  %t558 = icmp sle i64 %t556, %t557
  br i1 %t558, label %bb127, label %bb128
bb126:
  call void @__olang_check_failed(ptr @.c68)
  unreachable
bb127:
  %t560 = load i64, ptr %l289, !tbaa !24
  %t561 = load i64, ptr %l290, !tbaa !24
  %t562 = icmp sle i64 %t560, %t561
  br i1 %t562, label %bb129, label %bb130
bb128:
  call void @__olang_check_failed(ptr @.c68)
  unreachable
bb129:
  %t564 = getelementptr { i64, ptr }, ptr %l279, i32 0, i32 1
  %t565 = load ptr, ptr %t564, !tbaa !27
  %t566 = load i64, ptr %l284, !tbaa !24
  %t567 = load i64, ptr %l289, !tbaa !24
  %t568 = getelementptr i8, ptr %t565, i64 %t566
  %t569 = sub i64 %t567, %t566
  %t570 = insertvalue { i64, ptr } undef, i64 %t569, 0
  %t571 = insertvalue { i64, ptr } %t570, ptr %t568, 1
  store { i64, ptr } %t571, ptr %l27, !tbaa !27
  %t573 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t575 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s13, ptr %s16, { i64, ptr } %t573, { i64, ptr } { i64 0, ptr @.d69 })
  store i1 %t575, ptr %l296
  br label %bb131
bb130:
  call void @__olang_check_failed(ptr @.c68)
  unreachable
bb131:
  %t576 = load i1, ptr %l296, !tbaa !21
  br i1 %t576, label %bb132, label %bb133
bb132:
  %t577 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t579 = call { i64, ptr } @std_2ffilepath_2eBase(ptr %s0, { i64, ptr } %t577)
  store { i64, ptr } %t579, ptr %l298
  br label %bb134
bb133:
  br label %bb135
bb134:
  %t580 = load { i64, ptr }, ptr %l298, !tbaa !27
  %t581 = extractvalue { i64, ptr } %t580, 1
  %t582 = extractvalue { i64, ptr } %t580, 0
  %t583 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t582)
  call void @olang_textcopy(ptr %t583, ptr %t581, i64 %t582)
  %t584 = insertvalue { i64, ptr } undef, i64 %t582, 0
  %t585 = insertvalue { i64, ptr } %t584, ptr %t583, 1
  %t587 = extractvalue { i64, ptr } %t585, 0
  %t588 = extractvalue { i64, ptr } %t585, 1
  %t589 = mul i64 %t587, 1
  %t590 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t589)
  call void @llvm.memcpy.p0.p0.i64(ptr %t590, ptr %t588, i64 %t589, i1 false)
  %t591 = insertvalue { i64, ptr } undef, i64 %t587, 0
  %t592 = insertvalue { i64, ptr } %t591, ptr %t590, 1
  store { i64, ptr } %t592, ptr %l26, !tbaa !27
  br label %bb135
bb135:
  %t594 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t596 = extractvalue { i64, ptr } %t594, 1
  %t597 = extractvalue { i64, ptr } %t594, 0
  %t598 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t597)
  call void @olang_textcopy(ptr %t598, ptr %t596, i64 %t597)
  %t599 = insertvalue { i64, ptr } undef, i64 %t597, 0
  %t600 = insertvalue { i64, ptr } %t599, ptr %t598, 1
  %t602 = extractvalue { i64, ptr } %t600, 0
  %t603 = extractvalue { i64, ptr } %t600, 1
  %t604 = mul i64 %t602, 1
  %t605 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t604)
  call void @llvm.memcpy.p0.p0.i64(ptr %t605, ptr %t603, i64 %t604, i1 false)
  %t606 = insertvalue { i64, ptr } undef, i64 %t602, 0
  %t607 = insertvalue { i64, ptr } %t606, ptr %t605, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %s0, ptr %l13, { i64, ptr } %t607)
  br label %bb136
bb136:
  %t610 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t612 = extractvalue { i64, ptr } %t610, 1
  %t613 = extractvalue { i64, ptr } %t610, 0
  %t614 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t613)
  call void @olang_textcopy(ptr %t614, ptr %t612, i64 %t613)
  %t615 = insertvalue { i64, ptr } undef, i64 %t613, 0
  %t616 = insertvalue { i64, ptr } %t615, ptr %t614, 1
  %t618 = extractvalue { i64, ptr } %t616, 0
  %t619 = extractvalue { i64, ptr } %t616, 1
  %t620 = mul i64 %t618, 1
  %t621 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t620)
  call void @llvm.memcpy.p0.p0.i64(ptr %t621, ptr %t619, i64 %t620, i1 false)
  %t622 = insertvalue { i64, ptr } undef, i64 %t618, 0
  %t623 = insertvalue { i64, ptr } %t622, ptr %t621, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %s0, ptr %l14, { i64, ptr } %t623)
  br label %bb137
bb137:
  call void @__olang_scope_close(ptr %s16)
  br label %bb138
bb138:
  call void @__olang_scope_close(ptr %s13)
  br label %bb139
bb139:
  call void @__olang_scope_close(ptr %s9)
  br label %bb140
bb140:
  %t626 = load i64, ptr %l21, !tbaa !24
  %t628 = add i64 %t626, 1
  store i64 %t628, ptr %l21, !tbaa !24
  br label %bb44
bb141:
  %t630 = load ptr, ptr %l0, !tbaa !29
  %t632 = getelementptr %"compiler/fmt:loader", ptr %t630, i32 0, i32 2
  store ptr %t632, ptr %l312, !tbaa !29
  %t634 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v0, ptr %l12)
  store { i64, ptr } %t634, ptr %l314
  br label %bb142
bb142:
  %t635 = load ptr, ptr %l312, !tbaa !29
  %t636 = load { i64, ptr }, ptr %l314, !tbaa !27
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v0, ptr %v0, ptr %t635, { i64, ptr } %t636)
  br label %bb143
bb143:
  store i64 0, ptr %l28, !tbaa !24
  %t638 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %s0, ptr %l13)
  store i64 %t638, ptr %l316
  br label %bb144
bb144:
  %t639 = load i64, ptr %l316, !tbaa !24
  store i64 %t639, ptr %l29, !tbaa !24
  store i64 1, ptr %l30, !tbaa !24
  %t640 = load i64, ptr %l29, !tbaa !24
  %t641 = load i64, ptr %l28, !tbaa !24
  %t644 = icmp sgt i64 %t640, %t641
  br i1 %t644, label %bb145, label %bb146
bb145:
  %t646 = load i64, ptr %l30, !tbaa !24
  %t648 = icmp sgt i64 %t646, 0
  br i1 %t648, label %bb147, label %bb148
bb146:
  store i64 0, ptr %l320, !tbaa !24
  br label %bb150
bb147:
  %t650 = load i64, ptr %l29, !tbaa !24
  %t651 = load i64, ptr %l28, !tbaa !24
  %t654 = sub i64 %t650, %t651
  %t655 = load i64, ptr %l30, !tbaa !24
  %t658 = add i64 %t654, %t655
  %t660 = sub i64 %t658, 1
  %t661 = load i64, ptr %l30, !tbaa !24
  %t664 = sdiv i64 %t660, %t661
  store i64 %t664, ptr %l323, !tbaa !24
  br label %bb149
bb148:
  store i64 0, ptr %l323, !tbaa !24
  br label %bb149
bb149:
  %t666 = load i64, ptr %l323, !tbaa !24
  store i64 %t666, ptr %l320, !tbaa !24
  br label %bb150
bb150:
  %t667 = load i64, ptr %l320, !tbaa !24
  store i64 %t667, ptr %l31, !tbaa !24
  store i64 0, ptr %l32, !tbaa !24
  br label %bb151
bb151:
  store %olang.scope zeroinitializer, ptr %s23
  %t668 = load i64, ptr %l32, !tbaa !24
  %t669 = load i64, ptr %l31, !tbaa !24
  %t672 = icmp slt i64 %t668, %t669
  %t674 = xor i1 %t672, true
  br i1 %t674, label %bb152, label %bb153
bb152:
  call void @__olang_scope_close(ptr %s23)
  br label %bb167
bb153:
  br label %bb154
bb154:
  %t676 = load i64, ptr %l28, !tbaa !24
  %t677 = load i64, ptr %l32, !tbaa !24
  %t678 = load i64, ptr %l30, !tbaa !24
  %t681 = mul i64 %t677, %t678
  %t684 = add i64 %t676, %t681
  store i64 %t684, ptr %l33, !tbaa !24
  %t686 = load ptr, ptr %l0, !tbaa !29
  store ptr %t686, ptr %l341, !tbaa !29
  %t687 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t687, ptr %l342, !tbaa !27
  %t688 = load i64, ptr %l33, !tbaa !24
  %t691 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %s0, ptr %s0, ptr %l14, i64 %t688)
  store { i64, ptr } %t691, ptr %l345
  br label %bb155
bb155:
  %t692 = load ptr, ptr %l341, !tbaa !29
  %t693 = load { i64, ptr }, ptr %l342, !tbaa !27
  %t694 = load { i64, ptr }, ptr %l345, !tbaa !27
  %t695 = call { i64, ptr } @compiler_2ffmt_2ecompiler_2ffmt_3aloader_2etarget(ptr %v0, ptr %s0, ptr %s0, ptr %s23, ptr %t692, { i64, ptr } %t693, { i64, ptr } %t694)
  store { i64, ptr } %t695, ptr %l346
  br label %bb156
bb156:
  %t696 = load { i64, ptr }, ptr %l346, !tbaa !27
  store { i64, ptr } %t696, ptr %l34, !tbaa !27
  store i64 -1, ptr %l35, !tbaa !24
  %t697 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t699 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s23, ptr %s23, { i64, ptr } %t697, { i64, ptr } { i64 0, ptr @.d70 })
  store i1 %t699, ptr %l348
  br label %bb157
bb157:
  %t700 = load i1, ptr %l348, !tbaa !21
  %t701 = xor i1 %t700, true
  br i1 %t701, label %bb158, label %bb159
bb158:
  %t703 = load ptr, ptr %l0, !tbaa !29
  %t704 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t707 = call i64 @compiler_2ffmt_2ecompiler_2ffmt_3aloader_2eload(ptr %v0, ptr %s23, ptr %t703, { i64, ptr } %t704)
  store i64 %t707, ptr %l352
  br label %bb160
bb159:
  br label %bb161
bb160:
  %t708 = load i64, ptr %l352, !tbaa !24
  store i64 %t708, ptr %l35, !tbaa !24
  br label %bb161
bb161:
  %t709 = load ptr, ptr %l0, !tbaa !29
  %t711 = getelementptr %"compiler/fmt:loader", ptr %t709, i32 0, i32 3
  %t712 = load i64, ptr %l11, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t711, i64 %t712)
  br label %bb162
bb162:
  %t715 = load ptr, ptr %l0, !tbaa !29
  %t717 = getelementptr %"compiler/fmt:loader", ptr %t715, i32 0, i32 4
  store ptr %t717, ptr %l357, !tbaa !29
  %t718 = load i64, ptr %l33, !tbaa !24
  %t721 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %s0, ptr %s23, ptr %l13, i64 %t718)
  store { i64, ptr } %t721, ptr %l360
  br label %bb163
bb163:
  %t722 = load { i64, ptr }, ptr %l360, !tbaa !27
  %t723 = extractvalue { i64, ptr } %t722, 1
  %t724 = extractvalue { i64, ptr } %t722, 0
  %t725 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t724)
  call void @olang_textcopy(ptr %t725, ptr %t723, i64 %t724)
  %t726 = insertvalue { i64, ptr } undef, i64 %t724, 0
  %t727 = insertvalue { i64, ptr } %t726, ptr %t725, 1
  %t729 = extractvalue { i64, ptr } %t727, 0
  %t730 = extractvalue { i64, ptr } %t727, 1
  %t731 = mul i64 %t729, 1
  %t732 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t731)
  call void @llvm.memcpy.p0.p0.i64(ptr %t732, ptr %t730, i64 %t731, i1 false)
  %t733 = insertvalue { i64, ptr } undef, i64 %t729, 0
  %t734 = insertvalue { i64, ptr } %t733, ptr %t732, 1
  %t735 = load ptr, ptr %l357, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v0, ptr %v0, ptr %t735, { i64, ptr } %t734)
  br label %bb164
bb164:
  %t737 = load ptr, ptr %l0, !tbaa !29
  %t739 = getelementptr %"compiler/fmt:loader", ptr %t737, i32 0, i32 5
  %t740 = load i64, ptr %l35, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t739, i64 %t740)
  br label %bb165
bb165:
  call void @__olang_scope_close(ptr %s23)
  br label %bb166
bb166:
  %t743 = load i64, ptr %l32, !tbaa !24
  %t745 = add i64 %t743, 1
  store i64 %t745, ptr %l32, !tbaa !24
  br label %bb151
bb167:
  %t747 = load i64, ptr %l11, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t747, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2ffmt_2ecompiler_2ffmt_3aloader_2eoracle(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, i64 %a3, { i64, ptr } %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l15 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l28 = alloca i1
  %l30 = alloca i1
  %l31 = alloca { i64, ptr }
  %l33 = alloca i1
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l9, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  store ptr %t2, ptr %l10, !tbaa !29
  %t3 = load ptr, ptr %l2, !tbaa !29
  store ptr %t3, ptr %l11, !tbaa !29
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t6 = getelementptr %"compiler/fmt:loader", ptr %t4, i32 0, i32 2
  %t7 = load i64, ptr %l3, !tbaa !24
  %t10 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %v0, ptr %t6, i64 %t7)
  store { i64, ptr } %t10, ptr %l15
  br label %bb1
bb1:
  %t11 = load ptr, ptr %l9, !tbaa !29
  %t12 = load ptr, ptr %l10, !tbaa !29
  %t13 = load ptr, ptr %l11, !tbaa !29
  %t14 = load { i64, ptr }, ptr %l15, !tbaa !27
  call void @compiler_2ffmt_2ecompiler_2ffmt_3aloader_2eaddNames(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %v0, ptr %t11, ptr %t12, ptr %t13, { i64, ptr } { i64 0, ptr @.d71 }, { i64, ptr } %t14)
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t17 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eSplit(ptr %v3, ptr %s1, { i64, ptr } %a4, { i64, ptr } { i64 1, ptr @.d72 })
  store { i64, ptr } %t17, ptr %l17
  br label %bb3
bb3:
  %t18 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t18, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t19 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t21 = extractvalue { i64, ptr } %t19, 0
  store i64 %t21, ptr %l7, !tbaa !24
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s2
  %t23 = load i64, ptr %l6, !tbaa !24
  %t24 = load i64, ptr %l7, !tbaa !24
  %t27 = icmp slt i64 %t23, %t24
  %t29 = xor i1 %t27, true
  br i1 %t29, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s2)
  br label %bb18
bb6:
  br label %bb7
bb7:
  %t31 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t31, ptr %l24, !tbaa !27
  %t32 = load i64, ptr %l6, !tbaa !24
  %t34 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !27
  %t36 = getelementptr { i64, ptr }, ptr %t35, i64 %t32
  %t37 = load { i64, ptr }, ptr %t36, !tbaa !37
  store { i64, ptr } %t37, ptr %l8, !tbaa !27
  %t39 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t41 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v3, ptr %s2, { i64, ptr } %t39, { i64, ptr } { i64 0, ptr @.d73 })
  store i1 %t41, ptr %l28
  br label %bb8
bb8:
  %t42 = load i1, ptr %l28, !tbaa !21
  %t43 = xor i1 %t42, true
  br i1 %t43, label %bb9, label %bb10
bb9:
  %t45 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t45, ptr %l31, !tbaa !27
  %t46 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !27
  %t48 = getelementptr i8, ptr %t47, i64 0
  %t49 = load i8, ptr %t48, !tbaa !32
  %t51 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsUpper(i8 %t49)
  store i1 %t51, ptr %l33
  br label %bb11
bb10:
  store i1 false, ptr %l30, !tbaa !21
  br label %bb12
bb11:
  %t52 = load i1, ptr %l33, !tbaa !21
  store i1 %t52, ptr %l30, !tbaa !21
  br label %bb12
bb12:
  %t53 = load i1, ptr %l30, !tbaa !21
  br i1 %t53, label %bb13, label %bb14
bb13:
  store %olang.scope zeroinitializer, ptr %s3
  %t54 = load ptr, ptr %l1, !tbaa !29
  %t55 = load ptr, ptr %l2, !tbaa !29
  %t56 = load { i64, ptr }, ptr %l8, !tbaa !27
  call void @compiler_2fparse_2ecompiler_2fparse_3aOracle_2eAdd(ptr %v1, ptr %v2, ptr %s3, ptr %v3, ptr %t54, ptr %t55, { i64, ptr } { i64 0, ptr @.d74 }, { i64, ptr } %t56)
  br label %bb15
bb14:
  br label %bb16
bb15:
  call void @__olang_scope_close(ptr %s3)
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s2)
  br label %bb17
bb17:
  %t60 = load i64, ptr %l6, !tbaa !24
  %t62 = add i64 %t60, 1
  store i64 %t62, ptr %l6, !tbaa !24
  br label %bb4
bb18:
  call void @__olang_scope_close(ptr %s1)
  %t64 = load ptr, ptr %l1, !tbaa !29
  %t65 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fparse_2ecompiler_2fparse_3aOracle_2eAdd(ptr %v1, ptr %v2, ptr %s0, ptr %s0, ptr %t64, ptr %t65, { i64, ptr } { i64 0, ptr @.d75 }, { i64, ptr } { i64 5, ptr @.d76 })
  br label %bb19
bb19:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t69 = load ptr, ptr %l1, !tbaa !29
  %t70 = load ptr, ptr %l2, !tbaa !29
  %t71 = load i64, ptr %l3, !tbaa !24
  call void @compiler_2ffmt_2ecompiler_2ffmt_3aloader_2echains(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %t68, ptr %t69, ptr %t70, i64 %t71, { i64, ptr } { i64 0, ptr @.d77 }, i64 0)
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2ffmt_2ecompiler_2ffmt_3aloader_2eprelude(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"std/prelude/text:StringBuilder"
  %l2 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca %"std/prelude/text:StringBuilder"
  %l13 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l17 = alloca i32
  %l20 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l22 = alloca i64
  %l23 = alloca { i64, ptr }
  %l31 = alloca { i64, ptr }
  %l35 = alloca i1
  %l37 = alloca ptr
  %l40 = alloca { i64, ptr }
  %l42 = alloca i64
  %l45 = alloca ptr
  %l49 = alloca { i64, ptr }
  %l50 = alloca { i64, ptr }
  %l54 = alloca { i64, ptr }
  %l57 = alloca i64
  %l58 = alloca i64
  %l66 = alloca { i64, ptr }
  %l67 = alloca { i64, ptr }
  %l68 = alloca i64
  %l69 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l9
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l9
  store %"std/prelude/text:StringBuilder" %t2, ptr %l1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 32)
  br label %bb2
bb2:
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t6 = getelementptr %"compiler/fmt:loader", ptr %t4, i32 0, i32 0
  %t7 = load { i64, ptr }, ptr %t6, !tbaa !27
  %t9 = call { i64, ptr } @std_2ffilepath_2eJoin(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t7, { i64, ptr } { i64 7, ptr @.d78 }, { i64, ptr } { i64 0, ptr @.d79 }, { i64, ptr } { i64 0, ptr @.d80 }, { i64, ptr } { i64 0, ptr @.d81 }, { i64, ptr } { i64 0, ptr @.d82 })
  store { i64, ptr } %t9, ptr %l13
  br label %bb3
bb3:
  %t10 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t10, ptr %l2, !tbaa !27
  %t11 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t13 = call { i32, { i64, ptr } } @std_2fos_2eReadDir(ptr %s0, ptr %s0, { i64, ptr } %t11)
  %t14 = extractvalue { i32, { i64, ptr } } %t13, 1
  %t15 = extractvalue { i32, { i64, ptr } } %t13, 0
  store i32 %t15, ptr %l17
  %t16 = icmp ne i32 %t15, 0
  br i1 %t16, label %bb5, label %ok.17
ok.17:
  store { i64, ptr } %t14, ptr %l16
  br label %bb4
bb4:
  %t18 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t18, ptr %l14, !tbaa !27
  br label %bb9
bb5:
  %t19 = load i32, ptr %l17, !tbaa !23
  %t20 = ashr i32 %t19, 16
  %t22 = icmp eq i32 %t20, 1
  br i1 %t22, label %bb6, label %bb7
bb6:
  br label %bb8
bb7:
  call void @__olang_check_failed(ptr @.c83)
  unreachable
bb8:
  store { i64, ptr } { i64 1, ptr @.d84 }, ptr %l20, !tbaa !27
  %t24 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t24, ptr %l21, !tbaa !27
  %t25 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t25, 0
  store i64 %t26, ptr %l22, !tbaa !24
  %t27 = load i64, ptr %l22, !tbaa !24
  %t28 = mul i64 %t27, 1
  %t29 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t28)
  %t30 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t31 = insertvalue { i64, ptr } %t30, ptr %t29, 1
  store { i64, ptr } %t31, ptr %l23, !tbaa !27
  %t32 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !27
  %t34 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !27
  %t36 = load i64, ptr %l22, !tbaa !24
  %t37 = mul i64 %t36, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t33, ptr %t35, i64 %t37, i1 false)
  %t38 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t38, ptr %l21, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t39 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t39, ptr %rv
  br label %ret
bb9:
  %t40 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t40, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t43 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t45 = extractvalue { i64, ptr } %t43, 0
  store i64 %t45, ptr %l6, !tbaa !24
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s3
  %t47 = load i64, ptr %l5, !tbaa !24
  %t48 = load i64, ptr %l6, !tbaa !24
  %t51 = icmp slt i64 %t47, %t48
  %t53 = xor i1 %t51, true
  br i1 %t53, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s3)
  br label %bb33
bb12:
  br label %bb13
bb13:
  %t55 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t55, ptr %l31, !tbaa !27
  %t56 = load i64, ptr %l5, !tbaa !24
  %t58 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !27
  %t60 = getelementptr { i64, ptr }, ptr %t59, i64 %t56
  %t61 = load { i64, ptr }, ptr %t60, !tbaa !37
  store { i64, ptr } %t61, ptr %l7, !tbaa !27
  %t63 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t65 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %s0, ptr %s3, { i64, ptr } %t63, { i64, ptr } { i64 6, ptr @.d85 })
  store i1 %t65, ptr %l35
  br label %bb14
bb14:
  %t66 = load i1, ptr %l35, !tbaa !21
  %t67 = xor i1 %t66, true
  br i1 %t67, label %bb15, label %bb16
bb15:
  call void @__olang_scope_close(ptr %s3)
  br label %bb32
bb16:
  br label %bb17
bb17:
  %t69 = load ptr, ptr %l0, !tbaa !29
  store ptr %t69, ptr %l37, !tbaa !29
  %t70 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t71 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t74 = call { i64, ptr } @std_2ffilepath_2eJoin(ptr %s0, ptr %s0, ptr %s3, ptr %s3, ptr %s3, ptr %s3, ptr %s3, { i64, ptr } %t70, { i64, ptr } %t71, { i64, ptr } { i64 0, ptr @.d86 }, { i64, ptr } { i64 0, ptr @.d87 }, { i64, ptr } { i64 0, ptr @.d88 }, { i64, ptr } { i64 0, ptr @.d89 })
  store { i64, ptr } %t74, ptr %l40
  br label %bb18
bb18:
  %t75 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t76 = extractvalue { i64, ptr } %t75, 0
  %t77 = extractvalue { i64, ptr } %t75, 1
  %t78 = mul i64 %t76, 1
  %t79 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t78)
  call void @llvm.memcpy.p0.p0.i64(ptr %t79, ptr %t77, i64 %t78, i1 false)
  %t80 = insertvalue { i64, ptr } undef, i64 %t76, 0
  %t81 = insertvalue { i64, ptr } %t80, ptr %t79, 1
  %t82 = load ptr, ptr %l37, !tbaa !29
  %t84 = call i64 @compiler_2ffmt_2ecompiler_2ffmt_3aloader_2eload(ptr %v0, ptr %s3, ptr %t82, { i64, ptr } %t81)
  store i64 %t84, ptr %l42
  br label %bb19
bb19:
  %t85 = load i64, ptr %l42, !tbaa !24
  store i64 %t85, ptr %l8, !tbaa !24
  %t86 = load i64, ptr %l8, !tbaa !24
  %t88 = icmp sge i64 %t86, 0
  br i1 %t88, label %bb20, label %bb21
bb20:
  store ptr %l1, ptr %l45, !tbaa !29
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t92 = getelementptr %"compiler/fmt:loader", ptr %t90, i32 0, i32 2
  %t93 = load i64, ptr %l8, !tbaa !24
  %t96 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %v0, ptr %t92, i64 %t93)
  store { i64, ptr } %t96, ptr %l49
  br label %bb22
bb21:
  br label %bb31
bb22:
  %t97 = load { i64, ptr }, ptr %l49, !tbaa !27
  store { i64, ptr } %t97, ptr %l50, !tbaa !27
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t100 = getelementptr %"compiler/fmt:loader", ptr %t98, i32 0, i32 2
  %t101 = load i64, ptr %l8, !tbaa !24
  %t104 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %v0, ptr %t100, i64 %t101)
  store { i64, ptr } %t104, ptr %l54
  br label %bb23
bb23:
  %t105 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t108 = extractvalue { i64, ptr } %t105, 0
  store i64 %t108, ptr %l57, !tbaa !24
  %t109 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t110 = extractvalue { i64, ptr } %t109, 0
  store i64 %t110, ptr %l58, !tbaa !24
  %t111 = icmp sge i64 1, 0
  br i1 %t111, label %bb24, label %bb25
bb24:
  %t113 = load i64, ptr %l57, !tbaa !24
  %t114 = icmp sle i64 1, %t113
  br i1 %t114, label %bb26, label %bb27
bb25:
  call void @__olang_check_failed(ptr @.c90)
  unreachable
bb26:
  %t116 = load i64, ptr %l57, !tbaa !24
  %t117 = load i64, ptr %l58, !tbaa !24
  %t118 = icmp sle i64 %t116, %t117
  br i1 %t118, label %bb28, label %bb29
bb27:
  call void @__olang_check_failed(ptr @.c90)
  unreachable
bb28:
  %t120 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t121 = load ptr, ptr %t120, !tbaa !27
  %t122 = load i64, ptr %l57, !tbaa !24
  %t123 = getelementptr i8, ptr %t121, i64 1
  %t124 = sub i64 %t122, 1
  %t125 = insertvalue { i64, ptr } undef, i64 %t124, 0
  %t126 = insertvalue { i64, ptr } %t125, ptr %t123, 1
  %t127 = load ptr, ptr %l45, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %t127, { i64, ptr } %t126)
  br label %bb30
bb29:
  call void @__olang_check_failed(ptr @.c90)
  unreachable
bb30:
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s3)
  br label %bb32
bb32:
  %t129 = load i64, ptr %l5, !tbaa !24
  %t131 = add i64 %t129, 1
  store i64 %t131, ptr %l5, !tbaa !24
  br label %bb10
bb33:
  %t134 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l1)
  store { i64, ptr } %t134, ptr %l66
  br label %bb34
bb34:
  %t135 = load { i64, ptr }, ptr %l66, !tbaa !27
  store { i64, ptr } %t135, ptr %l67, !tbaa !27
  %t136 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t137 = extractvalue { i64, ptr } %t136, 0
  store i64 %t137, ptr %l68, !tbaa !24
  %t138 = load i64, ptr %l68, !tbaa !24
  %t139 = mul i64 %t138, 1
  %t140 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t139)
  %t141 = insertvalue { i64, ptr } undef, i64 %t138, 0
  %t142 = insertvalue { i64, ptr } %t141, ptr %t140, 1
  store { i64, ptr } %t142, ptr %l69, !tbaa !27
  %t143 = getelementptr { i64, ptr }, ptr %l69, i32 0, i32 1
  %t144 = load ptr, ptr %t143, !tbaa !27
  %t145 = getelementptr { i64, ptr }, ptr %l67, i32 0, i32 1
  %t146 = load ptr, ptr %t145, !tbaa !27
  %t147 = load i64, ptr %l68, !tbaa !24
  %t148 = mul i64 %t147, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t144, ptr %t146, i64 %t148, i1 false)
  %t149 = load { i64, ptr }, ptr %l69, !tbaa !27
  store { i64, ptr } %t149, ptr %l67, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t150 = load { i64, ptr }, ptr %l67, !tbaa !27
  store { i64, ptr } %t150, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2ffmt_2ecompiler_2ffmt_3aloader_2etarget(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l6 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i32
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l22 = alloca { i64, ptr }
  %l23 = alloca i1
  %l24 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l26 = alloca i64
  %l27 = alloca { i64, ptr }
  %l29 = alloca i1
  %l31 = alloca { i64, ptr }
  %l32 = alloca { i64, ptr }
  %l35 = alloca i64
  %l36 = alloca i64
  %l41 = alloca { i64, ptr }
  %l44 = alloca { i64, ptr }
  %l46 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t1, ptr %l3, !tbaa !27
  %t3 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindByte(ptr %v2, { i64, ptr } %t3, i8 47)
  %t7 = extractvalue { i32, i64 } %t6, 1
  %t8 = extractvalue { i32, i64 } %t6, 0
  store i32 %t8, ptr %l10
  %t9 = icmp ne i32 %t8, 0
  br i1 %t9, label %bb2, label %ok.10
ok.10:
  store i64 %t7, ptr %l9
  br label %bb1
bb1:
  %t11 = load i64, ptr %l9, !tbaa !24
  store i64 %t11, ptr %l6, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  store i64 -1, ptr %l6, !tbaa !24
  br label %bb4
bb4:
  %t12 = load i64, ptr %l6, !tbaa !24
  store i64 %t12, ptr %l4, !tbaa !24
  %t13 = load i64, ptr %l4, !tbaa !24
  %t15 = icmp sge i64 %t13, 0
  br i1 %t15, label %bb5, label %bb6
bb5:
  %t17 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t17, ptr %l13, !tbaa !27
  %t18 = load i64, ptr %l4, !tbaa !24
  store i64 %t18, ptr %l14, !tbaa !24
  %t19 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t20 = extractvalue { i64, ptr } %t19, 0
  store i64 %t20, ptr %l15, !tbaa !24
  %t21 = icmp sge i64 0, 0
  br i1 %t21, label %bb7, label %bb8
bb6:
  br label %bb13
bb7:
  %t23 = load i64, ptr %l14, !tbaa !24
  %t24 = icmp sle i64 0, %t23
  br i1 %t24, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @.c91)
  unreachable
bb9:
  %t26 = load i64, ptr %l14, !tbaa !24
  %t27 = load i64, ptr %l15, !tbaa !24
  %t28 = icmp sle i64 %t26, %t27
  br i1 %t28, label %bb11, label %bb12
bb10:
  call void @__olang_check_failed(ptr @.c91)
  unreachable
bb11:
  %t30 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !27
  %t32 = load i64, ptr %l14, !tbaa !24
  %t33 = getelementptr i8, ptr %t31, i64 0
  %t34 = sub i64 %t32, 0
  %t35 = insertvalue { i64, ptr } undef, i64 %t34, 0
  %t36 = insertvalue { i64, ptr } %t35, ptr %t33, 1
  store { i64, ptr } %t36, ptr %l3, !tbaa !27
  br label %bb13
bb12:
  call void @__olang_check_failed(ptr @.c91)
  unreachable
bb13:
  %t38 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } { i64 1, ptr @.d92 }, ptr %l22, !tbaa !27
  %t41 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t42 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v2, ptr %s0, { i64, ptr } %t38, { i64, ptr } %t41)
  store i1 %t42, ptr %l23
  br label %bb14
bb14:
  %t43 = load i1, ptr %l23, !tbaa !21
  br i1 %t43, label %bb15, label %bb16
bb15:
  store { i64, ptr } { i64 0, ptr @.d93 }, ptr %l24, !tbaa !27
  %t44 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t44, ptr %l25, !tbaa !27
  %t45 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t46 = extractvalue { i64, ptr } %t45, 0
  store i64 %t46, ptr %l26, !tbaa !24
  %t47 = load i64, ptr %l26, !tbaa !24
  %t48 = mul i64 %t47, 1
  %t49 = call ptr @__olang_scope_alloc_zeroed(ptr %v3, i64 %t48)
  %t50 = insertvalue { i64, ptr } undef, i64 %t47, 0
  %t51 = insertvalue { i64, ptr } %t50, ptr %t49, 1
  store { i64, ptr } %t51, ptr %l27, !tbaa !27
  %t52 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !27
  %t54 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !27
  %t56 = load i64, ptr %l26, !tbaa !24
  %t57 = mul i64 %t56, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t53, ptr %t55, i64 %t57, i1 false)
  %t58 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t58, ptr %l25, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t59 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t59, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  %t60 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t62 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v2, ptr %s0, { i64, ptr } %t60, { i64, ptr } { i64 4, ptr @.d94 })
  store i1 %t62, ptr %l29
  br label %bb18
bb18:
  %t63 = load i1, ptr %l29, !tbaa !21
  br i1 %t63, label %bb19, label %bb20
bb19:
  store %olang.scope zeroinitializer, ptr %s3
  %t66 = getelementptr %"compiler/fmt:loader", ptr %a0, i32 0, i32 0
  %t67 = load { i64, ptr }, ptr %t66, !tbaa !27
  store { i64, ptr } %t67, ptr %l31, !tbaa !27
  %t68 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t68, ptr %l32, !tbaa !27
  %t69 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t72 = extractvalue { i64, ptr } %t69, 0
  store i64 %t72, ptr %l35, !tbaa !24
  %t73 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t74 = extractvalue { i64, ptr } %t73, 0
  store i64 %t74, ptr %l36, !tbaa !24
  %t75 = icmp sge i64 4, 0
  br i1 %t75, label %bb21, label %bb22
bb20:
  br label %bb28
bb21:
  %t77 = load i64, ptr %l35, !tbaa !24
  %t78 = icmp sle i64 4, %t77
  br i1 %t78, label %bb23, label %bb24
bb22:
  call void @__olang_check_failed(ptr @.c95)
  unreachable
bb23:
  %t80 = load i64, ptr %l35, !tbaa !24
  %t81 = load i64, ptr %l36, !tbaa !24
  %t82 = icmp sle i64 %t80, %t81
  br i1 %t82, label %bb25, label %bb26
bb24:
  call void @__olang_check_failed(ptr @.c95)
  unreachable
bb25:
  %t84 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t85 = load ptr, ptr %t84, !tbaa !27
  %t86 = load i64, ptr %l35, !tbaa !24
  %t87 = getelementptr i8, ptr %t85, i64 4
  %t88 = sub i64 %t86, 4
  %t89 = insertvalue { i64, ptr } undef, i64 %t88, 0
  %t90 = insertvalue { i64, ptr } %t89, ptr %t87, 1
  %t91 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t93 = call { i64, ptr } @std_2ffilepath_2eJoin(ptr %v0, ptr %v2, ptr %s3, ptr %s3, ptr %s3, ptr %s3, ptr %s3, { i64, ptr } %t91, { i64, ptr } %t90, { i64, ptr } { i64 0, ptr @.d96 }, { i64, ptr } { i64 0, ptr @.d97 }, { i64, ptr } { i64 0, ptr @.d98 }, { i64, ptr } { i64 0, ptr @.d99 })
  store { i64, ptr } %t93, ptr %l41
  br label %bb27
bb26:
  call void @__olang_check_failed(ptr @.c95)
  unreachable
bb27:
  %t94 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t95 = extractvalue { i64, ptr } %t94, 1
  %t96 = extractvalue { i64, ptr } %t94, 0
  %t97 = extractvalue { i64, ptr } { i64 6, ptr @.d100 }, 1
  %t98 = extractvalue { i64, ptr } { i64 6, ptr @.d100 }, 0
  %t99 = add i64 %t96, %t98
  %t100 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t99)
  call void @olang_textcopy(ptr %t100, ptr %t95, i64 %t96)
  %t101 = getelementptr i8, ptr %t100, i64 %t96
  call void @olang_textcopy(ptr %t101, ptr %t97, i64 %t98)
  %t102 = insertvalue { i64, ptr } undef, i64 %t99, 0
  %t103 = insertvalue { i64, ptr } %t102, ptr %t100, 1
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t103, ptr %rv
  br label %ret
bb28:
  %t107 = call { i64, ptr } @std_2ffilepath_2eDir(ptr %v1, { i64, ptr } %a1)
  store { i64, ptr } %t107, ptr %l44
  br label %bb29
bb29:
  %t108 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t109 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t111 = call { i64, ptr } @std_2ffilepath_2eJoin(ptr %v1, ptr %v2, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t109, { i64, ptr } %t108, { i64, ptr } { i64 0, ptr @.d101 }, { i64, ptr } { i64 0, ptr @.d102 }, { i64, ptr } { i64 0, ptr @.d103 }, { i64, ptr } { i64 0, ptr @.d104 })
  store { i64, ptr } %t111, ptr %l46
  br label %bb30
bb30:
  %t112 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t113 = extractvalue { i64, ptr } %t112, 1
  %t114 = extractvalue { i64, ptr } %t112, 0
  %t115 = extractvalue { i64, ptr } { i64 6, ptr @.d105 }, 1
  %t116 = extractvalue { i64, ptr } { i64 6, ptr @.d105 }, 0
  %t117 = add i64 %t114, %t116
  %t118 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t117)
  call void @olang_textcopy(ptr %t118, ptr %t113, i64 %t114)
  %t119 = getelementptr i8, ptr %t118, i64 %t114
  call void @olang_textcopy(ptr %t119, ptr %t115, i64 %t116)
  %t120 = insertvalue { i64, ptr } undef, i64 %t117, 0
  %t121 = insertvalue { i64, ptr } %t120, ptr %t118, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t121, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2ffmt_2eisCloser(i32 %a0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca i32
  %l3 = alloca i32
  %l5 = alloca i1
  %l6 = alloca i1
  %l7 = alloca i32
  %l9 = alloca i32
  %l11 = alloca i1
  %l12 = alloca i1
  %l13 = alloca i32
  %l15 = alloca i32
  %l17 = alloca i1
  %rv = alloca i1
  store i32 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l0
  store i32 %t1, ptr %l1
  store i32 89, ptr %l3
  %t4 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l1, ptr %l3)
  store i1 %t4, ptr %l5
  br label %bb1
bb1:
  %t5 = load i1, ptr %l5, !tbaa !21
  br i1 %t5, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb5
bb3:
  %t6 = load i32, ptr %l0
  store i32 %t6, ptr %l7
  store i32 91, ptr %l9
  %t9 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l7, ptr %l9)
  store i1 %t9, ptr %l11
  br label %bb4
bb4:
  %t10 = load i1, ptr %l11, !tbaa !21
  store i1 %t10, ptr %l6, !tbaa !21
  br label %bb5
bb5:
  %t11 = load i1, ptr %l6, !tbaa !21
  br i1 %t11, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb9
bb7:
  %t12 = load i32, ptr %l0
  store i32 %t12, ptr %l13
  store i32 93, ptr %l15
  %t15 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l13, ptr %l15)
  store i1 %t15, ptr %l17
  br label %bb8
bb8:
  %t16 = load i1, ptr %l17, !tbaa !21
  store i1 %t16, ptr %l12, !tbaa !21
  br label %bb9
bb9:
  %t17 = load i1, ptr %l12, !tbaa !21
  store i1 %t17, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2ffmt_2elineEndOf(ptr %v0, { i64, ptr } %a0, i64 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca i64
  %l5 = alloca i64
  %l11 = alloca i1
  %l12 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %rv = alloca i64
  store { i64, ptr } %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp sgt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load i64, ptr %l1, !tbaa !24
  store i64 %t5, ptr %l5, !tbaa !24
  br label %bb3
bb2:
  store i64 0, ptr %l5, !tbaa !24
  br label %bb3
bb3:
  %t7 = load i64, ptr %l5, !tbaa !24
  store i64 %t7, ptr %l2, !tbaa !24
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s1
  %t8 = load i64, ptr %l2, !tbaa !24
  %t9 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t9, 0
  %t14 = icmp slt i64 %t8, %t11
  br i1 %t14, label %bb5, label %bb6
bb5:
  %t16 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t16, ptr %l12, !tbaa !27
  %t17 = load i64, ptr %l2, !tbaa !24
  %t19 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !27
  %t21 = getelementptr i8, ptr %t20, i64 %t17
  %t22 = load i8, ptr %t21, !tbaa !32
  %t24 = icmp ne i8 %t22, 10
  store i1 %t24, ptr %l11, !tbaa !21
  br label %bb7
bb6:
  store i1 false, ptr %l11, !tbaa !21
  br label %bb7
bb7:
  %t26 = load i1, ptr %l11, !tbaa !21
  %t27 = xor i1 %t26, true
  br i1 %t27, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s1)
  br label %bb12
bb9:
  br label %bb10
bb10:
  %t29 = load i64, ptr %l2, !tbaa !24
  %t31 = add i64 %t29, 1
  store i64 %t31, ptr %l2, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  br label %bb11
bb11:
  br label %bb4
bb12:
  %t33 = load i64, ptr %l2, !tbaa !24
  store i64 %t33, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2ffmt_2elineStartOf(ptr %v0, { i64, ptr } %a0, i64 %a1) #0 {
entry:
  %l2 = alloca i64
  %l6 = alloca i1
  %l7 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  store i64 %a1, ptr %l2, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t3 = load i64, ptr %l2, !tbaa !24
  %t5 = icmp sgt i64 %t3, 0
  br i1 %t5, label %bb2, label %bb3
bb2:
  store { i64, ptr } %a0, ptr %l7, !tbaa !27
  %t8 = load i64, ptr %l2, !tbaa !24
  %t10 = sub i64 %t8, 1
  %t12 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr i8, ptr %t13, i64 %t10
  %t15 = load i8, ptr %t14, !tbaa !32
  %t17 = icmp ne i8 %t15, 10
  store i1 %t17, ptr %l6, !tbaa !21
  br label %bb4
bb3:
  store i1 false, ptr %l6, !tbaa !21
  br label %bb4
bb4:
  %t19 = load i1, ptr %l6, !tbaa !21
  %t20 = xor i1 %t19, true
  br i1 %t20, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s1)
  br label %bb9
bb6:
  br label %bb7
bb7:
  %t22 = load i64, ptr %l2, !tbaa !24
  %t24 = sub i64 %t22, 1
  store i64 %t24, ptr %l2, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  br label %bb8
bb8:
  br label %bb1
bb9:
  %t26 = load i64, ptr %l2, !tbaa !24
  store i64 %t26, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2ffmt_3aformatter_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l9 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l10 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l11 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l12 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l13 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l14 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l15 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l16 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l17 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l18 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l19 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l20 = alloca %"std/prelude/text:StringBuilder"
  %l21 = alloca i1
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca { i64, ptr }
  %l25 = alloca i64
  %l26 = alloca i1
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l39 = alloca i64
  %l44 = alloca i64
  %l48 = alloca i64
  %l53 = alloca i64
  %l56 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l57 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l58 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l59 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l60 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l61 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l62 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l63 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l64 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l65 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l66 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l67 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l68 = alloca %"std/prelude/text:StringBuilder"
  %l70 = alloca i64
  %l74 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l75 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l76 = alloca %"compiler/fmt:formatter"
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a0, ptr %l2, !tbaa !27
  %t3 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t3, ptr %l3, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  store i64 %t7, ptr %l39, !tbaa !24
  %t8 = load i64, ptr %l39, !tbaa !24
  %t9 = icmp sge i64 %t8, 0
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = load i64, ptr %l39, !tbaa !24
  %t12 = icmp sle i64 %t11, 1152921504606846975
  br i1 %t12, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @.c106)
  unreachable
bb3:
  %t14 = load i64, ptr %l39, !tbaa !24
  %t15 = mul i64 %t14, 8
  %t16 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t15)
  %t17 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  store { i64, ptr } %t18, ptr %l4, !tbaa !27
  %t20 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t22 = extractvalue { i64, ptr } %t20, 0
  store i64 %t22, ptr %l44, !tbaa !24
  %t23 = load i64, ptr %l44, !tbaa !24
  %t24 = icmp sge i64 %t23, 0
  br i1 %t24, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @.c106)
  unreachable
bb5:
  %t26 = load i64, ptr %l44, !tbaa !24
  %t27 = mul i64 %t26, 1
  %t28 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t27)
  %t29 = insertvalue { i64, ptr } undef, i64 %t26, 0
  %t30 = insertvalue { i64, ptr } %t29, ptr %t28, 1
  store { i64, ptr } %t30, ptr %l5, !tbaa !27
  %t32 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t34 = extractvalue { i64, ptr } %t32, 0
  store i64 %t34, ptr %l48, !tbaa !24
  %t35 = load i64, ptr %l48, !tbaa !24
  %t36 = icmp sge i64 %t35, 0
  br i1 %t36, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @.c107)
  unreachable
bb7:
  %t38 = load i64, ptr %l48, !tbaa !24
  %t39 = icmp sle i64 %t38, 1152921504606846975
  br i1 %t39, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @.c108)
  unreachable
bb9:
  %t41 = load i64, ptr %l48, !tbaa !24
  %t42 = mul i64 %t41, 8
  %t43 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t42)
  %t44 = insertvalue { i64, ptr } undef, i64 %t41, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t43, 1
  store { i64, ptr } %t45, ptr %l6, !tbaa !27
  %t47 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t49 = extractvalue { i64, ptr } %t47, 0
  store i64 %t49, ptr %l53, !tbaa !24
  %t50 = load i64, ptr %l53, !tbaa !24
  %t51 = icmp sge i64 %t50, 0
  br i1 %t51, label %bb11, label %bb12
bb10:
  call void @__olang_check_failed(ptr @.c108)
  unreachable
bb11:
  %t53 = load i64, ptr %l53, !tbaa !24
  %t54 = mul i64 %t53, 1
  %t55 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t54)
  %t56 = insertvalue { i64, ptr } undef, i64 %t53, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t55, 1
  store { i64, ptr } %t57, ptr %l7, !tbaa !27
  %t59 = load ptr, ptr @__olang_prog_scope
  %t60 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t59)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t60, ptr %l56
  br label %bb13
bb12:
  call void @__olang_check_failed(ptr @.c109)
  unreachable
bb13:
  %t61 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l56
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t61, ptr %l8
  %t62 = load ptr, ptr @__olang_prog_scope
  %t63 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cBool_3e(ptr %t62)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t63, ptr %l57
  br label %bb14
bb14:
  %t64 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l57
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t64, ptr %l9
  %t65 = load ptr, ptr @__olang_prog_scope
  %t66 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t65)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t66, ptr %l58
  br label %bb15
bb15:
  %t67 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l58
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t67, ptr %l10
  %t68 = load ptr, ptr @__olang_prog_scope
  %t69 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t68)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t69, ptr %l59
  br label %bb16
bb16:
  %t70 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l59
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t70, ptr %l11
  %t71 = load ptr, ptr @__olang_prog_scope
  %t72 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t71)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t72, ptr %l60
  br label %bb17
bb17:
  %t73 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l60
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t73, ptr %l12
  %t74 = load ptr, ptr @__olang_prog_scope
  %t75 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t74)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t75, ptr %l61
  br label %bb18
bb18:
  %t76 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l61
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t76, ptr %l13
  %t77 = load ptr, ptr @__olang_prog_scope
  %t78 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t77)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t78, ptr %l62
  br label %bb19
bb19:
  %t79 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l62
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t79, ptr %l14
  %t80 = load ptr, ptr @__olang_prog_scope
  %t81 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t80)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t81, ptr %l63
  br label %bb20
bb20:
  %t82 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l63
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t82, ptr %l15
  %t83 = load ptr, ptr @__olang_prog_scope
  %t84 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t83)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t84, ptr %l64
  br label %bb21
bb21:
  %t85 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l64
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t85, ptr %l16
  %t86 = load ptr, ptr @__olang_prog_scope
  %t87 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t86)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t87, ptr %l65
  br label %bb22
bb22:
  %t88 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l65
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t88, ptr %l17
  %t89 = load ptr, ptr @__olang_prog_scope
  %t90 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t89)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t90, ptr %l66
  br label %bb23
bb23:
  %t91 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l66
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t91, ptr %l18
  %t92 = load ptr, ptr @__olang_prog_scope
  %t93 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cBool_3e(ptr %t92)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t93, ptr %l67
  br label %bb24
bb24:
  %t94 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l67
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t94, ptr %l19
  %t95 = load ptr, ptr @__olang_prog_scope
  %t96 = call %"std/prelude/text:StringBuilder" @olang_2eHelperKind_2eZero_2estd_2fprelude_2ftext_3aStringBuilder(ptr %t95)
  store %"std/prelude/text:StringBuilder" %t96, ptr %l68
  br label %bb25
bb25:
  %t97 = load %"std/prelude/text:StringBuilder", ptr %l68
  store %"std/prelude/text:StringBuilder" %t97, ptr %l20
  store i1 false, ptr %l21, !tbaa !21
  store i64 0, ptr %l22, !tbaa !24
  store i64 0, ptr %l23, !tbaa !24
  %t98 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t100 = extractvalue { i64, ptr } %t98, 0
  store i64 %t100, ptr %l70, !tbaa !24
  %t101 = load i64, ptr %l70, !tbaa !24
  %t102 = icmp sge i64 %t101, 0
  br i1 %t102, label %bb26, label %bb27
bb26:
  %t104 = load i64, ptr %l70, !tbaa !24
  %t105 = icmp sle i64 %t104, 1152921504606846975
  br i1 %t105, label %bb28, label %bb29
bb27:
  call void @__olang_check_failed(ptr @.c110)
  unreachable
bb28:
  %t107 = load i64, ptr %l70, !tbaa !24
  %t108 = mul i64 %t107, 8
  %t109 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t108)
  %t110 = insertvalue { i64, ptr } undef, i64 %t107, 0
  %t111 = insertvalue { i64, ptr } %t110, ptr %t109, 1
  store { i64, ptr } %t111, ptr %l24, !tbaa !27
  store i64 0, ptr %l25, !tbaa !24
  store i1 false, ptr %l26, !tbaa !21
  store i64 -1, ptr %l27, !tbaa !24
  store i64 -1, ptr %l28, !tbaa !24
  store i64 0, ptr %l29, !tbaa !24
  store i64 -1, ptr %l30, !tbaa !24
  store i64 0, ptr %l31, !tbaa !24
  store i64 -1, ptr %l32, !tbaa !24
  %t113 = load ptr, ptr @__olang_prog_scope
  %t114 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t113)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t114, ptr %l74
  br label %bb30
bb29:
  call void @__olang_check_failed(ptr @.c110)
  unreachable
bb30:
  %t115 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l74
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t115, ptr %l33
  %t116 = load ptr, ptr @__olang_prog_scope
  %t117 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t116)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t117, ptr %l75
  br label %bb31
bb31:
  %t118 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l75
  %t119 = getelementptr %"compiler/fmt:formatter", ptr %l76, i32 0, i32 0
  %t120 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t120, ptr %t119, !tbaa !27
  %t121 = getelementptr %"compiler/fmt:formatter", ptr %l76, i32 0, i32 1
  %t122 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t122, ptr %t121, !tbaa !27
  %t123 = getelementptr %"compiler/fmt:formatter", ptr %l76, i32 0, i32 2
  %t124 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t124, ptr %t123, !tbaa !27
  %t125 = getelementptr %"compiler/fmt:formatter", ptr %l76, i32 0, i32 3
  %t126 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t126, ptr %t125, !tbaa !27
  %t127 = getelementptr %"compiler/fmt:formatter", ptr %l76, i32 0, i32 4
  %t128 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t128, ptr %t127, !tbaa !27
  %t129 = getelementptr %"compiler/fmt:formatter", ptr %l76, i32 0, i32 5
  %t130 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t130, ptr %t129, !tbaa !27
  %t131 = getelementptr %"compiler/fmt:formatter", ptr %l76, i32 0, i32 6
  %t132 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l8
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t132, ptr %t131
  %t133 = getelementptr %"compiler/fmt:formatter", ptr %l76, i32 0, i32 7
  %t134 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l9
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t134, ptr %t133
  %t135 = getelementptr %"compiler/fmt:formatter", ptr %l76, i32 0, i32 8
  %t136 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l10
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t136, ptr %t135
  %t137 = getelementptr %"compiler/fmt:formatter", ptr %l76, i32 0, i32 9
  %t138 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l11
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t138, ptr %t137
  %t139 = getelementptr %"compiler/fmt:formatter", ptr %l76, i32 0, i32 10
  %t140 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l12
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t140, ptr %t139
  %t141 = getelementptr %"compiler/fmt:formatter", ptr %l76, i32 0, i32 11
  %t142 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l13
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t142, ptr %t141
  %t143 = getelementptr %"compiler/fmt:formatter", ptr %l76, i32 0, i32 12
  %t144 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l14
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t144, ptr %t143
  %t145 = getelementptr %"compiler/fmt:formatter", ptr %l76, i32 0, i32 13
  %t146 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l15
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t146, ptr %t145
  %t147 = getelementptr %"compiler/fmt:formatter", ptr %l76, i32 0, i32 14
  %t148 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l16
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t148, ptr %t147
  %t149 = getelementptr %"compiler/fmt:formatter", ptr %l76, i32 0, i32 15
  %t150 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l17
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t150, ptr %t149
  %t151 = getelementptr %"compiler/fmt:formatter", ptr %l76, i32 0, i32 16
  %t152 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l18
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t152, ptr %t151
  %t153 = getelementptr %"compiler/fmt:formatter", ptr %l76, i32 0, i32 17
  %t154 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l19
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t154, ptr %t153
  %t155 = getelementptr %"compiler/fmt:formatter", ptr %l76, i32 0, i32 18
  %t156 = load %"std/prelude/text:StringBuilder", ptr %l20
  store %"std/prelude/text:StringBuilder" %t156, ptr %t155
  %t157 = getelementptr %"compiler/fmt:formatter", ptr %l76, i32 0, i32 19
  %t158 = load i1, ptr %l21, !tbaa !21
  store i1 %t158, ptr %t157, !tbaa !21
  %t159 = getelementptr %"compiler/fmt:formatter", ptr %l76, i32 0, i32 20
  %t160 = load i64, ptr %l22, !tbaa !24
  store i64 %t160, ptr %t159, !tbaa !24
  %t161 = getelementptr %"compiler/fmt:formatter", ptr %l76, i32 0, i32 21
  %t162 = load i64, ptr %l23, !tbaa !24
  store i64 %t162, ptr %t161, !tbaa !24
  %t163 = getelementptr %"compiler/fmt:formatter", ptr %l76, i32 0, i32 22
  %t164 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t164, ptr %t163, !tbaa !27
  %t165 = getelementptr %"compiler/fmt:formatter", ptr %l76, i32 0, i32 23
  %t166 = load i64, ptr %l25, !tbaa !24
  store i64 %t166, ptr %t165, !tbaa !24
  %t167 = getelementptr %"compiler/fmt:formatter", ptr %l76, i32 0, i32 24
  %t168 = load i1, ptr %l26, !tbaa !21
  store i1 %t168, ptr %t167, !tbaa !21
  %t169 = getelementptr %"compiler/fmt:formatter", ptr %l76, i32 0, i32 25
  %t170 = load i64, ptr %l27, !tbaa !24
  store i64 %t170, ptr %t169, !tbaa !24
  %t171 = getelementptr %"compiler/fmt:formatter", ptr %l76, i32 0, i32 26
  %t172 = load i64, ptr %l28, !tbaa !24
  store i64 %t172, ptr %t171, !tbaa !24
  %t173 = getelementptr %"compiler/fmt:formatter", ptr %l76, i32 0, i32 27
  %t174 = load i64, ptr %l29, !tbaa !24
  store i64 %t174, ptr %t173, !tbaa !24
  %t175 = getelementptr %"compiler/fmt:formatter", ptr %l76, i32 0, i32 28
  %t176 = load i64, ptr %l30, !tbaa !24
  store i64 %t176, ptr %t175, !tbaa !24
  %t177 = getelementptr %"compiler/fmt:formatter", ptr %l76, i32 0, i32 29
  %t178 = load i64, ptr %l31, !tbaa !24
  store i64 %t178, ptr %t177, !tbaa !24
  %t179 = getelementptr %"compiler/fmt:formatter", ptr %l76, i32 0, i32 30
  %t180 = load i64, ptr %l32, !tbaa !24
  store i64 %t180, ptr %t179, !tbaa !24
  %t181 = getelementptr %"compiler/fmt:formatter", ptr %l76, i32 0, i32 31
  %t182 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l33
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t182, ptr %t181
  %t183 = getelementptr %"compiler/fmt:formatter", ptr %l76, i32 0, i32 32
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t118, ptr %t183
  %t185 = getelementptr %"compiler/fmt:formatter", ptr %l76, i32 0, i32 33
  store i1 false, ptr %t185, !tbaa !21
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l76, i64 328, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/fmt:loader" @compiler_2ffmt_3aloader_2ector(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l3 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l4 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l5 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l8 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l9 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l10 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l11 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l12 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"compiler/fmt:loader"
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a0, ptr %l1, !tbaa !27
  %t3 = load ptr, ptr @__olang_prog_scope
  %t4 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t3)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t4, ptr %l8
  br label %bb1
bb1:
  %t5 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l8
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t5, ptr %l2
  %t6 = load ptr, ptr @__olang_prog_scope
  %t7 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t6)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t7, ptr %l9
  br label %bb2
bb2:
  %t8 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l9
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t8, ptr %l3
  %t9 = load ptr, ptr @__olang_prog_scope
  %t10 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t9)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t10, ptr %l10
  br label %bb3
bb3:
  %t11 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l10
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t11, ptr %l4
  %t12 = load ptr, ptr @__olang_prog_scope
  %t13 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t12)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t13, ptr %l11
  br label %bb4
bb4:
  %t14 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l11
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t14, ptr %l5
  %t15 = load ptr, ptr @__olang_prog_scope
  %t16 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t15)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t16, ptr %l12
  br label %bb5
bb5:
  %t17 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l12
  %t18 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t19 = insertvalue %"compiler/fmt:loader" undef, { i64, ptr } %t18, 0
  %t20 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l2
  %t21 = insertvalue %"compiler/fmt:loader" %t19, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t20, 1
  %t22 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l3
  %t23 = insertvalue %"compiler/fmt:loader" %t21, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t22, 2
  %t24 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l4
  %t25 = insertvalue %"compiler/fmt:loader" %t23, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t24, 3
  %t26 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l5
  %t27 = insertvalue %"compiler/fmt:loader" %t25, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t26, 4
  %t29 = insertvalue %"compiler/fmt:loader" %t27, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t17, 5
  store %"compiler/fmt:loader" %t29, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/fmt:loader", ptr %rv
  ret %"compiler/fmt:loader" %rr
}

define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
chunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
declare noalias ptr @__olang_scope_alloc_a(ptr, i64, i64)
declare void @__olang_check_failed(ptr)
@.c0 = private unnamed_addr constant [45 x i8] c"compiler/fmt.olang:639: unreachable reached\0A\00"
@.d1 = private constant [7 x i8] c"olang: "
@.d2 = private constant [17 x i8] c": cannot be read\0A"
@.d3 = private constant [2 x i8] c"-f"
@.d4 = private constant [2 x i8] c"-p"
@.c5 = private unnamed_addr constant [45 x i8] c"compiler/fmt.olang:652: unreachable reached\0A\00"
@.d6 = private constant [7 x i8] c"olang: "
@.d7 = private constant [20 x i8] c": cannot be written\0A"
@.d8 = private constant [1 x i8] c"\0A"
@.c9 = private unnamed_addr constant [45 x i8] c"compiler/fmt.olang:664: unreachable reached\0A\00"
@.c10 = private unnamed_addr constant [45 x i8] c"compiler/fmt.olang:665: unreachable reached\0A\00"
@.c11 = private unnamed_addr constant [44 x i8] c"compiler/fmt.olang:45: unreachable reached\0A\00"
@.c12 = private unnamed_addr constant [44 x i8] c"compiler/fmt.olang:46: unreachable reached\0A\00"
@.c13 = private unnamed_addr constant [44 x i8] c"compiler/fmt.olang:47: unreachable reached\0A\00"
@.d14 = private constant [1 x i8] c" "
@.d15 = private constant [0 x i8] c""
define linkonce_odr i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %a0, ptr %a1) #0 {
entry:
  %l2 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t2 = load i32, ptr %a0
  %t3 = sext i32 %t2 to i64
  %t5 = load i32, ptr %a1
  %t6 = sext i32 %t5 to i64
  %t9 = icmp eq i64 %t3, %t6
  br i1 %t9, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb3
bb2:
  br label %bb3
bb3:
  %t11 = load i1, ptr %l2, !tbaa !21
  store i1 %t11, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.c16 = private unnamed_addr constant [51 x i8] c"compiler/fmt.olang:233: slice bounds out of range\0A\00"
@__olang_prog_scope = external thread_local(initialexec) global ptr
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

@.c17 = private unnamed_addr constant [45 x i8] c"compiler/fmt.olang:127: unreachable reached\0A\00"
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftoken_3aTok_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftoken_3aTok_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

@.c18 = private unnamed_addr constant [45 x i8] c"compiler/fmt.olang:134: unreachable reached\0A\00"
declare void @__olang_bang_failed(ptr)
@.c19 = private unnamed_addr constant [87 x i8] c"compiler/fmt.olang:137: ListError.EMPTY\0A(build with -debug to see where it came from)\0A\00"
@.c20 = private unnamed_addr constant [91 x i8] c"compiler/fmt.olang:137: ListError.NOT_FOUND\0A(build with -debug to see where it came from)\0A\00"
@.c21 = private unnamed_addr constant [94 x i8] c"compiler/fmt.olang:137: ListError.OUT_OF_RANGE\0A(build with -debug to see where it came from)\0A\00"
@.c22 = private unnamed_addr constant [87 x i8] c"compiler/fmt.olang:137: unhandled error\0A(build with -debug to see where it came from)\0A\00"
@.c23 = private unnamed_addr constant [51 x i8] c"compiler/fmt.olang:159: slice bounds out of range\0A\00"
@.d24 = private constant [0 x i8] c""
@.d25 = private constant [0 x i8] c""
@.d26 = private constant [0 x i8] c""
@.d27 = private constant [0 x i8] c""
@.d28 = private constant [0 x i8] c""
@.d29 = private constant [0 x i8] c""
@.d30 = private constant [0 x i8] c""
@.d31 = private constant [1 x i8] c" "
@.d32 = private constant [0 x i8] c""
@.d33 = private constant [1 x i8] c" "
@.d34 = private constant [0 x i8] c""
@.d35 = private constant [0 x i8] c""
@.d36 = private constant [1 x i8] c" "
@.d37 = private constant [1 x i8] c" "
@.d38 = private constant [0 x i8] c""
@.d39 = private constant [0 x i8] c""
@.d40 = private constant [0 x i8] c""
@.d41 = private constant [1 x i8] c" "
@.d42 = private constant [0 x i8] c""
@.d43 = private constant [1 x i8] c" "
@.d44 = private constant [0 x i8] c""
@.d45 = private constant [1 x i8] c" "
@.d46 = private constant [0 x i8] c""
@.d47 = private constant [1 x i8] c" "
@.c48 = private unnamed_addr constant [51 x i8] c"compiler/fmt.olang:112: slice bounds out of range\0A\00"
@.c49 = private unnamed_addr constant [51 x i8] c"compiler/fmt.olang:338: slice bounds out of range\0A\00"
@.d50 = private constant [1 x i8] c"="
@.c51 = private unnamed_addr constant [51 x i8] c"compiler/fmt.olang:339: slice bounds out of range\0A\00"
@.d52 = private constant [2 x i8] c" ="
@.c53 = private unnamed_addr constant [51 x i8] c"compiler/fmt.olang:580: slice bounds out of range\0A\00"
@.d54 = private constant [4 x i8] c"    "
@.c55 = private unnamed_addr constant [51 x i8] c"compiler/fmt.olang:591: slice bounds out of range\0A\00"
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
@.d56 = private constant [1 x i8] c" "
@.d57 = private constant [3 x i8] c"fn:"
@.d58 = private constant [0 x i8] c""
@.c59 = private unnamed_addr constant [51 x i8] c"compiler/fmt.olang:792: slice bounds out of range\0A\00"
@.d60 = private constant [1 x i8] c"."
@.c61 = private unnamed_addr constant [45 x i8] c"compiler/fmt.olang:724: unreachable reached\0A\00"
@.c62 = private unnamed_addr constant [45 x i8] c"compiler/fmt.olang:728: unreachable reached\0A\00"
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

@.c63 = private unnamed_addr constant [51 x i8] c"compiler/fmt.olang:743: slice bounds out of range\0A\00"
@.c64 = private unnamed_addr constant [51 x i8] c"compiler/fmt.olang:748: slice bounds out of range\0A\00"
@.d65 = private constant [3 x i8] c"fn:"
@.d66 = private constant [0 x i8] c""
@.c67 = private unnamed_addr constant [51 x i8] c"compiler/fmt.olang:755: slice bounds out of range\0A\00"
@.c68 = private unnamed_addr constant [51 x i8] c"compiler/fmt.olang:759: slice bounds out of range\0A\00"
@.d69 = private constant [0 x i8] c""
@.d70 = private constant [0 x i8] c""
@.d71 = private constant [0 x i8] c""
@.d72 = private constant [1 x i8] c" "
@.d73 = private constant [0 x i8] c""
@.d74 = private constant [0 x i8] c""
@.d75 = private constant [0 x i8] c""
@.d76 = private constant [5 x i8] c"Array"
@.d77 = private constant [0 x i8] c""
@.d78 = private constant [7 x i8] c"prelude"
@.d79 = private constant [0 x i8] c""
@.d80 = private constant [0 x i8] c""
@.d81 = private constant [0 x i8] c""
@.d82 = private constant [0 x i8] c""
@.c83 = private unnamed_addr constant [45 x i8] c"compiler/fmt.olang:703: unreachable reached\0A\00"
@.d84 = private constant [1 x i8] c" "
@.d85 = private constant [6 x i8] c".olang"
@.d86 = private constant [0 x i8] c""
@.d87 = private constant [0 x i8] c""
@.d88 = private constant [0 x i8] c""
@.d89 = private constant [0 x i8] c""
@.c90 = private unnamed_addr constant [51 x i8] c"compiler/fmt.olang:707: slice bounds out of range\0A\00"
@.c91 = private unnamed_addr constant [51 x i8] c"compiler/fmt.olang:716: slice bounds out of range\0A\00"
@.d92 = private constant [1 x i8] c"."
@.d93 = private constant [0 x i8] c""
@.d94 = private constant [4 x i8] c"std/"
@.c95 = private unnamed_addr constant [51 x i8] c"compiler/fmt.olang:718: slice bounds out of range\0A\00"
@.d96 = private constant [0 x i8] c""
@.d97 = private constant [0 x i8] c""
@.d98 = private constant [0 x i8] c""
@.d99 = private constant [0 x i8] c""
@.d100 = private constant [6 x i8] c".olang"
@.d101 = private constant [0 x i8] c""
@.d102 = private constant [0 x i8] c""
@.d103 = private constant [0 x i8] c""
@.d104 = private constant [0 x i8] c""
@.d105 = private constant [6 x i8] c".olang"
@.c106 = private unnamed_addr constant [50 x i8] c"compiler/fmt.olang:72: array length out of range\0A\00"
@.c107 = private unnamed_addr constant [50 x i8] c"compiler/fmt.olang:73: array length out of range\0A\00"
@.c108 = private unnamed_addr constant [50 x i8] c"compiler/fmt.olang:74: array length out of range\0A\00"
@.c109 = private unnamed_addr constant [50 x i8] c"compiler/fmt.olang:75: array length out of range\0A\00"
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cBool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cBool_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/text:StringBuilder" @olang_2eHelperKind_2eZero_2estd_2fprelude_2ftext_3aStringBuilder(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/text:StringBuilder"
  %rv = alloca %"std/prelude/text:StringBuilder"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %t1)
  store %"std/prelude/text:StringBuilder" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/text:StringBuilder", ptr %l0
  store %"std/prelude/text:StringBuilder" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/text:StringBuilder", ptr %rv
  ret %"std/prelude/text:StringBuilder" %rr
}

@.c110 = private unnamed_addr constant [50 x i8] c"compiler/fmt.olang:97: array length out of range\0A\00"
declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare %"compiler/source:Source" @compiler_2fsource_3aSource_2ector(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/source:Names" @compiler_2fsource_3aNames_2ector(ptr %v0)
declare void @compiler_2fdiag_3aDiagnostics_2ector(ptr %out, ptr %v0, i1 %a0)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eAddFile(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, i1 %a3)
declare %"compiler/scan:Tokens" @compiler_2fscan_2eScan(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2fscan_2ecompiler_2fscan_3aDiag_2eRule(ptr %v0, %"compiler/scan:Diag" %a0)
declare { i64, ptr } @compiler_2fscan_2ecompiler_2fscan_3aDiag_2eMessage(ptr %v0, %"compiler/scan:Diag" %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v1, ptr %v2, i32 %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, %"compiler/msgs:Msg" %a2)
declare void @compiler_2fparse_3aParser_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4, i64 %a5)
declare { i64, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eFile(ptr %v0, ptr %a0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eAllSaid(ptr %v0, ptr %v1, ptr %a0)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fdiag_3aSaid_3e_2eLen_3ccompiler_2fdiag_3aSaid_3e(ptr %v0, ptr %a0)
declare { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eRender(ptr %v0, ptr %v1, ptr %a0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2funparse_2eHeldBranches(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, ptr %a1, { i64, ptr } %a2, ptr %a3)
declare %"std/io:Writer" @std_2fio_3aWriter_2ector(ptr %v0, i32 %a0, i64 %a1)
declare { i32, %"compiler/source:Source" } @compiler_2fsource_2eRead(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare i1 @compiler_2fdiag_2eColorWanted()
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i32 @std_2fos_2eWriteFile(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i32 @std_2fio_2estd_2fio_3aWriter_2eFlush(ptr %v0, ptr %a0)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/parse:Oracle" @compiler_2fparse_3aOracle_2ector(ptr %v0)
@G_2ecompiler_2ftoken_2eSpace = available_externally constant <{ [1 x i8] }> <{ [1 x i8] c"\02" }>, align 8
declare i1 @compiler_2ftoken_2ecompiler_2ftoken_3aToken_2eHas(%"compiler/token:Token" %a0, i8 %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
@G_2ecompiler_2ftoken_2eLineBreak = available_externally constant <{ [1 x i8] }> <{ [1 x i8] c"\01" }>, align 8
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %a0, i1 %a1)
declare i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eLen(ptr %v0, ptr %a0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %a0, i8 %a1)
declare i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eTruncate_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eTruncate_3cBool_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i32, i64 } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftoken_3aTok_3e_2ePush_3ccompiler_2ftoken_3aTok_3e(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftoken_3aTok_3e_2eLen_3ccompiler_2ftoken_3aTok_3e(ptr %v0, ptr %a0)
declare { i32, i32 } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftoken_3aTok_3e_2ePop_3ccompiler_2ftoken_3aTok_3e(ptr %v0, ptr %a0)
declare { i32, i32 } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftoken_3aTok_3e_2eLast_3ccompiler_2ftoken_3aTok_3e(ptr %v0, ptr %a0)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eSplit(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare void @compiler_2fparse_2ecompiler_2fparse_3aOracle_2eAddFn(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, { i64, ptr } %a2, { i64, ptr } %a3)
declare void @compiler_2fparse_2ecompiler_2fparse_3aOracle_2eAdd(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, { i64, ptr } %a2, { i64, ptr } %a3)
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i32, { i64, ptr } } @std_2fos_2eRealPath(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %v0, ptr %a0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2ffilepath_2eBase(ptr %v0, { i64, ptr } %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsUpper(i8 %a0)
declare { i64, ptr } @std_2ffilepath_2eJoin(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %v6, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, { i64, ptr } %a4, { i64, ptr } %a5)
declare { i32, { i64, ptr } } @std_2fos_2eReadDir(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindByte(ptr %v0, { i64, ptr } %a0, i8 %a1)
declare i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2ffilepath_2eDir(ptr %v0, { i64, ptr } %a0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftoken_3aTok_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cBool_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
