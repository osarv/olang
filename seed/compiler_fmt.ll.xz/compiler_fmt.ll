; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/source:Source" = type { { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/source:Names" = type { %"std/prelude/list:List<std/prelude/text:String&>", %"std/prelude/map:Map<std/prelude/text:String&, compiler/source:NameId>" }
%"std/prelude/list:List<std/prelude/text:String&>" = type { ptr }
%"std/prelude/map:Map<std/prelude/text:String&, compiler/source:NameId>" = type { ptr }
%"compiler/diag:Diagnostics" = type { i1, %"std/prelude/list:List<std/prelude/text:String&>", %"std/prelude/list:List<std/prelude/text:String&>", %"std/prelude/list:List<Bool>", %"std/prelude/list:List<I64>", %"std/prelude/list:List<I64>", %"std/prelude/list:List<I64>", %"std/prelude/list:List<compiler/diag:record>", %"std/prelude/list:List<compiler/diag:note>", %"std/prelude/list:List<I64>", %"std/prelude/list:List<I64>", %"std/prelude/list:List<I64>", %"std/prelude/list:List<compiler/diag:context>", i64, i1, i1, { i64, [3 x i64] }, { i64, ptr }, { i64, ptr }, i1 }
%"std/prelude/list:List<Bool>" = type { ptr }
%"std/prelude/list:List<I64>" = type { ptr }
%"std/prelude/list:List<compiler/diag:record>" = type { ptr }
%"std/prelude/list:List<compiler/diag:note>" = type { ptr }
%"std/prelude/list:List<compiler/diag:context>" = type { ptr }
%"compiler/parse:Oracle" = type { %"std/prelude/map:Map<compiler/source:NameId, Bool>", %"std/prelude/map:Map<std/prelude/text:String&, Bool>" }
%"std/prelude/map:Map<compiler/source:NameId, Bool>" = type { ptr }
%"std/prelude/map:Map<std/prelude/text:String&, Bool>" = type { ptr }
%"compiler/scan:Tokens" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/scan:Diag" = type { i32, i32, i32, i8 }
%"compiler/parse:Parser" = type { ptr, ptr, ptr, ptr, ptr, i64, i64, i32, i32, i32, i32, i1, i1, i1, i64, i1, i64, i1, i64, i1, i32, %"std/prelude/list:List<I32>", %"std/prelude/list:List<Bool>", %"std/prelude/map:Map<I32, I64>", %"std/prelude/list:List<compiler/source:NameId>", %"std/prelude/list:List<compiler/ast:Expr&>", %"std/prelude/list:List<compiler/ast:Stmt&>", %"std/prelude/list:List<compiler/ast:TypeRef&>", %"std/prelude/list:List<compiler/ast:Param&>", %"std/prelude/list:List<compiler/ast:Pattern&>", %"std/prelude/list:List<compiler/source:NameId>", %"std/prelude/list:List<compiler/source:Span>", %"std/prelude/list:List<compiler/ast:Decl&>", %"std/prelude/list:List<compiler/ast:Decl&>", { i64, ptr }, %"std/prelude/list:List<I64>", %"std/prelude/list:List<I64>" }
%"std/prelude/list:List<I32>" = type { ptr }
%"std/prelude/map:Map<I32, I64>" = type { ptr }
%"std/prelude/list:List<compiler/source:NameId>" = type { ptr }
%"std/prelude/list:List<compiler/ast:Expr&>" = type { ptr }
%"std/prelude/list:List<compiler/ast:Stmt&>" = type { ptr }
%"std/prelude/list:List<compiler/ast:TypeRef&>" = type { ptr }
%"std/prelude/list:List<compiler/ast:Param&>" = type { ptr }
%"std/prelude/list:List<compiler/ast:Pattern&>" = type { ptr }
%"std/prelude/list:List<compiler/source:Span>" = type { ptr }
%"std/prelude/list:List<compiler/ast:Decl&>" = type { ptr }
%"compiler/msgs:Msg" = type { i32, { i64, ptr }, { i64, ptr } }
%"std/prelude/list:List<compiler/diag:Said>" = type { ptr }
%"std/io:Writer" = type { i32, { i64, ptr }, i64, i32 }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/list:List<std/prelude/text:Char>" }
%"std/prelude/list:List<std/prelude/text:Char>" = type { ptr }
%"compiler/fmt:formatter" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/list:List<I64>", %"std/prelude/list:List<Bool>", %"std/prelude/list:List<I64>", %"std/prelude/list:List<I64>", %"std/prelude/list:List<I64>", %"std/prelude/list:List<I64>", %"std/prelude/list:List<I64>", %"std/prelude/list:List<I64>", %"std/prelude/list:List<I64>", %"std/prelude/list:List<I64>", %"std/prelude/list:List<I64>", %"std/prelude/list:List<Bool>", %"std/prelude/text:StringBuilder", i1, i64, i64, { i64, ptr }, i64, i1, i64, i64, i64, i64, i64, i64, %"std/prelude/list:List<I64>", %"std/prelude/list:List<I64>", i1 }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/fmt:loader" = type { { i64, ptr }, %"std/prelude/list:List<std/prelude/text:String&>", %"std/prelude/list:List<std/prelude/text:String&>", %"std/prelude/list:List<I64>", %"std/prelude/list:List<std/prelude/text:String&>", %"std/prelude/list:List<I64>" }
%"compiler/token:Token" = type { i32, i8, i32, i32 }
define dso_local { i32, { i64, ptr } } @compiler_2ffmt_2eFileLayout(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, i1 %a3, ptr %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i1
  %l4 = alloca ptr
  %l5 = alloca %"compiler/source:Source"
  %l6 = alloca %"compiler/source:Names"
  %l7 = alloca %"compiler/diag:Diagnostics"
  %l8 = alloca %"compiler/parse:Oracle"
  %l9 = alloca i64
  %l10 = alloca %"compiler/scan:Tokens"
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca %"compiler/scan:Diag"
  %l15 = alloca %"compiler/parse:Parser"
  %l16 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca ptr
  %l19 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l22 = alloca ptr
  %l23 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l26 = alloca %"compiler/source:Source"
  %l27 = alloca %"compiler/source:Names"
  %l28 = alloca i1
  %l29 = alloca %"compiler/diag:Diagnostics"
  %l30 = alloca { i64, ptr }
  %l31 = alloca { i64, ptr }
  %l32 = alloca { i64, ptr }
  %l33 = alloca ptr
  %l34 = alloca %"compiler/parse:Oracle"
  %l35 = alloca ptr
  %l36 = alloca { i64, ptr }
  %l37 = alloca { i64, ptr }
  %l38 = alloca i64
  %l39 = alloca { i64, ptr }
  %l40 = alloca %"compiler/scan:Tokens"
  %l41 = alloca { i64, ptr }
  %l42 = alloca { i64, ptr }
  %l43 = alloca i64
  %l44 = alloca i64
  %l45 = alloca i64
  %l46 = alloca i1
  %l47 = alloca i1
  %l48 = alloca { i64, ptr }
  %l49 = alloca i64
  %l50 = alloca %"compiler/scan:Diag"
  %l51 = alloca ptr
  %l52 = alloca i64
  %l53 = alloca i32
  %l54 = alloca i64
  %l55 = alloca i32
  %l56 = alloca i64
  %l57 = alloca { i64, [3 x i64] }
  %l58 = alloca i32
  %l59 = alloca %"compiler/scan:Diag"
  %l60 = alloca { i64, ptr }
  %l61 = alloca %"compiler/scan:Diag"
  %l62 = alloca { i64, ptr }
  %l63 = alloca { i64, ptr }
  %l64 = alloca %"compiler/msgs:Msg"
  %l65 = alloca i64
  %l66 = alloca i64
  %l67 = alloca i64
  %l68 = alloca ptr
  %l69 = alloca ptr
  %l70 = alloca ptr
  %l71 = alloca ptr
  %l72 = alloca ptr
  %l73 = alloca i64
  %l74 = alloca %"compiler/parse:Parser"
  %l75 = alloca ptr
  %l76 = alloca { i64, ptr }
  %l77 = alloca { i64, ptr }
  %l78 = alloca i64
  %l79 = alloca i1
  %l80 = alloca i1
  %l81 = alloca ptr
  %l82 = alloca %"std/prelude/list:List<compiler/diag:Said>"
  %l83 = alloca ptr
  %l84 = alloca i64
  %l85 = alloca i1
  %l86 = alloca ptr
  %l87 = alloca ptr
  %l88 = alloca { i64, ptr }
  %l89 = alloca { i64, ptr }
  %l90 = alloca i32
  %l91 = alloca { i64, ptr }
  %l92 = alloca ptr
  %l93 = alloca { i64, ptr }
  %l94 = alloca ptr
  %l95 = alloca { i64, ptr }
  %l96 = alloca { i64, ptr }
  %l97 = alloca ptr
  %l98 = alloca ptr
  %l99 = alloca ptr
  %l100 = alloca { i64, ptr }
  %l101 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %s2 = alloca %olang.builder
  %s2room = alloca [64 x i8], align 8
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  %t48 = alloca %"compiler/diag:Diagnostics", align 8
  %t107 = alloca { i64, [3 x i64] }, align 8
  %t143 = alloca %"compiler/parse:Parser", align 8
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store i1 %a3, ptr %l3
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l18, !tbaa !29
  %t2 = load ptr, ptr %l18, !tbaa !29
  %t3 = getelementptr %"compiler/source:Source", ptr %t2, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l19, !tbaa !27
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t5 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 1
  %t7 = extractvalue { i64, ptr } %t5, 0
  call void @__olang_sb_put(ptr %s1, ptr %t6, i64 %t7)
  %t8 = load ptr, ptr %s1
  %t9 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t10 = load i64, ptr %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t10)
  call void @llvm.memcpy.p0.p0.i64(ptr %t11, ptr %t8, i64 %t10, i1 false)
  %t12 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t13 = insertvalue { i64, ptr } %t12, ptr %t11, 1
  store { i64, ptr } %t13, ptr %l20, !tbaa !27
  call void @__olang_sb_done(ptr %s1)
  %t14 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t14, 0
  %t16 = extractvalue { i64, ptr } %t14, 1
  %t17 = mul i64 %t15, 1
  %t18 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t17)
  call void @llvm.memcpy.p0.p0.i64(ptr %t18, ptr %t16, i64 %t17, i1 false)
  %t19 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t18, 1
  store { i64, ptr } %t20, ptr %l21, !tbaa !27
  %t21 = load ptr, ptr %l0, !tbaa !29
  store ptr %t21, ptr %l22, !tbaa !29
  %t22 = load ptr, ptr %l22, !tbaa !29
  %t23 = getelementptr %"compiler/source:Source", ptr %t22, i32 0, i32 1
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  store { i64, ptr } %t24, ptr %l23, !tbaa !27
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s2
  store ptr %s2room, ptr %s2
  %t25 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t25, 1
  %t27 = extractvalue { i64, ptr } %t25, 0
  call void @__olang_sb_put(ptr %s2, ptr %t26, i64 %t27)
  %t28 = load ptr, ptr %s2
  %t29 = getelementptr %olang.builder, ptr %s2, i32 0, i32 1
  %t30 = load i64, ptr %t29
  %t31 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t30)
  call void @llvm.memcpy.p0.p0.i64(ptr %t31, ptr %t28, i64 %t30, i1 false)
  %t32 = insertvalue { i64, ptr } undef, i64 %t30, 0
  %t33 = insertvalue { i64, ptr } %t32, ptr %t31, 1
  store { i64, ptr } %t33, ptr %l24, !tbaa !27
  call void @__olang_sb_done(ptr %s2)
  %t34 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t35 = extractvalue { i64, ptr } %t34, 0
  %t36 = extractvalue { i64, ptr } %t34, 1
  %t37 = mul i64 %t35, 1
  %t38 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t37)
  call void @llvm.memcpy.p0.p0.i64(ptr %t38, ptr %t36, i64 %t37, i1 false)
  %t39 = insertvalue { i64, ptr } undef, i64 %t35, 0
  %t40 = insertvalue { i64, ptr } %t39, ptr %t38, 1
  store { i64, ptr } %t40, ptr %l25, !tbaa !27
  %t41 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t42 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t43 = call %"compiler/source:Source" @compiler_2fsource_3aSource_2ector(ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t41, { i64, ptr } %t42)
  store %"compiler/source:Source" %t43, ptr %l26
  br label %bb1
bb1:
  %t44 = load %"compiler/source:Source", ptr %l26
  store %"compiler/source:Source" %t44, ptr %l5
  %t45 = call %"compiler/source:Names" @compiler_2fsource_3aNames_2ector(ptr %s0)
  store %"compiler/source:Names" %t45, ptr %l27
  br label %bb2
bb2:
  %t46 = load %"compiler/source:Names", ptr %l27
  store %"compiler/source:Names" %t46, ptr %l6
  %t47 = load i1, ptr %l3, !tbaa !21
  store i1 %t47, ptr %l28, !tbaa !21
  %t49 = load i1, ptr %l28, !tbaa !21
  call void @compiler_2fdiag_3aDiagnostics_2ector(ptr %t48, ptr %s0, i1 %t49)
  %t50 = load %"compiler/diag:Diagnostics", ptr %t48
  store %"compiler/diag:Diagnostics" %t50, ptr %l29
  br label %bb3
bb3:
  call void @llvm.memmove.p0.p0.i64(ptr %l7, ptr %l29, i64 192, i1 false)
  %t51 = getelementptr %"compiler/source:Source", ptr %l5, i32 0, i32 0
  %t52 = load { i64, ptr }, ptr %t51, !tbaa !27
  store { i64, ptr } %t52, ptr %l30, !tbaa !27
  %t53 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t53, ptr %l31, !tbaa !27
  %t54 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t54, ptr %l32, !tbaa !27
  store ptr %l6, ptr %l33, !tbaa !29
  %t55 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t56 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t57 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t58 = load ptr, ptr %l33, !tbaa !29
  %t59 = call %"compiler/parse:Oracle" @compiler_2ffmt_2eOracleFor(ptr %s0, ptr %v1, ptr %v2, ptr %s0, ptr %s0, { i64, ptr } %t55, { i64, ptr } %t56, { i64, ptr } %t57, ptr %t58)
  store %"compiler/parse:Oracle" %t59, ptr %l34
  br label %bb4
bb4:
  %t60 = load %"compiler/parse:Oracle", ptr %l34
  store %"compiler/parse:Oracle" %t60, ptr %l8
  store ptr %l7, ptr %l35, !tbaa !29
  %t61 = getelementptr %"compiler/source:Source", ptr %l5, i32 0, i32 0
  %t62 = load { i64, ptr }, ptr %t61, !tbaa !27
  store { i64, ptr } %t62, ptr %l36, !tbaa !27
  %t63 = getelementptr %"compiler/source:Source", ptr %l5, i32 0, i32 1
  %t64 = load { i64, ptr }, ptr %t63, !tbaa !27
  store { i64, ptr } %t64, ptr %l37, !tbaa !27
  %t65 = load ptr, ptr %l35, !tbaa !29
  %t66 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t67 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t68 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eAddFile(ptr %s0, ptr %s0, ptr %s0, ptr %t65, { i64, ptr } %t66, { i64, ptr } %t67, i1 false)
  store i64 %t68, ptr %l38
  br label %bb5
bb5:
  %t69 = load i64, ptr %l38, !tbaa !24
  store i64 %t69, ptr %l9, !tbaa !24
  %t70 = getelementptr %"compiler/source:Source", ptr %l5, i32 0, i32 1
  %t71 = load { i64, ptr }, ptr %t70, !tbaa !27
  store { i64, ptr } %t71, ptr %l39, !tbaa !27
  %t72 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t73 = call %"compiler/scan:Tokens" @compiler_2fscan_2eScan(ptr %s0, ptr %s0, { i64, ptr } %t72)
  store %"compiler/scan:Tokens" %t73, ptr %l40
  br label %bb6
bb6:
  %t74 = load %"compiler/scan:Tokens", ptr %l40
  store %"compiler/scan:Tokens" %t74, ptr %l10
  store %olang.scope zeroinitializer, ptr %s3
  %t75 = getelementptr %"compiler/scan:Tokens", ptr %l10, i32 0, i32 3
  %t76 = load { i64, ptr }, ptr %t75, !tbaa !27
  store { i64, ptr } %t76, ptr %l41, !tbaa !27
  %t77 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t77, ptr %l11, !tbaa !27
  store i64 0, ptr %l12, !tbaa !24
  %t78 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t78, ptr %l42, !tbaa !27
  %t79 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t80 = extractvalue { i64, ptr } %t79, 0
  store i64 %t80, ptr %l43, !tbaa !24
  %t81 = load i64, ptr %l43, !tbaa !24
  store i64 %t81, ptr %l13, !tbaa !24
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s4
  %t82 = load i64, ptr %l12, !tbaa !24
  store i64 %t82, ptr %l44, !tbaa !24
  %t83 = load i64, ptr %l13, !tbaa !24
  store i64 %t83, ptr %l45, !tbaa !24
  %t84 = load i64, ptr %l44, !tbaa !24
  %t85 = load i64, ptr %l45, !tbaa !24
  %t86 = icmp slt i64 %t84, %t85
  store i1 %t86, ptr %l46, !tbaa !21
  %t87 = load i1, ptr %l46, !tbaa !21
  %t88 = xor i1 %t87, true
  store i1 %t88, ptr %l47, !tbaa !21
  %t89 = load i1, ptr %l47, !tbaa !21
  br i1 %t89, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s4)
  br label %bb16
bb9:
  br label %bb10
bb10:
  %t90 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t90, ptr %l48, !tbaa !27
  %t91 = load i64, ptr %l12, !tbaa !24
  store i64 %t91, ptr %l49, !tbaa !24
  %t92 = load i64, ptr %l49, !tbaa !24
  %t93 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t94 = load ptr, ptr %t93, !tbaa !27
  %t95 = getelementptr %"compiler/scan:Diag", ptr %t94, i64 %t92
  %t96 = load %"compiler/scan:Diag", ptr %t95
  store %"compiler/scan:Diag" %t96, ptr %l50
  %t97 = load %"compiler/scan:Diag", ptr %l50
  store %"compiler/scan:Diag" %t97, ptr %l14
  store ptr %l7, ptr %l51, !tbaa !29
  %t98 = load i64, ptr %l9, !tbaa !24
  store i64 %t98, ptr %l52, !tbaa !24
  %t99 = getelementptr %"compiler/scan:Diag", ptr %l14, i32 0, i32 1
  %t100 = load i32, ptr %t99, !tbaa !23
  store i32 %t100, ptr %l53, !tbaa !23
  %t101 = load i32, ptr %l53, !tbaa !23
  %t102 = sext i32 %t101 to i64
  store i64 %t102, ptr %l54, !tbaa !24
  %t103 = getelementptr %"compiler/scan:Diag", ptr %l14, i32 0, i32 2
  %t104 = load i32, ptr %t103, !tbaa !23
  store i32 %t104, ptr %l55, !tbaa !23
  %t105 = load i32, ptr %l55, !tbaa !23
  %t106 = sext i32 %t105 to i64
  store i64 %t106, ptr %l56, !tbaa !24
  store { i64, [3 x i64] } zeroinitializer, ptr %t107
  %t108 = getelementptr { i64, [3 x i64] }, ptr %t107, i32 0, i32 0
  store i64 3, ptr %t108
  %t109 = load i64, ptr %l52, !tbaa !24
  %t110 = insertvalue { i64, i64, i64 } undef, i64 %t109, 0
  %t111 = load i64, ptr %l54, !tbaa !24
  %t112 = insertvalue { i64, i64, i64 } %t110, i64 %t111, 1
  %t113 = load i64, ptr %l56, !tbaa !24
  %t114 = insertvalue { i64, i64, i64 } %t112, i64 %t113, 2
  %t115 = getelementptr { i64, [3 x i64] }, ptr %t107, i32 0, i32 1
  store { i64, i64, i64 } %t114, ptr %t115
  %t116 = load { i64, [3 x i64] }, ptr %t107
  store { i64, [3 x i64] } %t116, ptr %l57
  store i32 42, ptr %l58
  %t117 = load %"compiler/scan:Diag", ptr %l14
  store %"compiler/scan:Diag" %t117, ptr %l59
  %t118 = load %"compiler/scan:Diag", ptr %l59
  %t119 = call { i64, ptr } @compiler_2fscan_2ecompiler_2fscan_3aDiag_2eRule(ptr %s4, %"compiler/scan:Diag" %t118)
  store { i64, ptr } %t119, ptr %l60
  br label %bb11
bb11:
  %t120 = load %"compiler/scan:Diag", ptr %l14
  store %"compiler/scan:Diag" %t120, ptr %l61
  %t121 = load %"compiler/scan:Diag", ptr %l61
  %t122 = call { i64, ptr } @compiler_2fscan_2ecompiler_2fscan_3aDiag_2eMessage(ptr %s4, %"compiler/scan:Diag" %t121)
  store { i64, ptr } %t122, ptr %l62
  br label %bb12
bb12:
  %t123 = load { i64, ptr }, ptr %l62, !tbaa !27
  %t124 = extractvalue { i64, ptr } %t123, 0
  %t125 = extractvalue { i64, ptr } %t123, 1
  %t126 = mul i64 %t124, 1
  %t127 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t126)
  call void @llvm.memcpy.p0.p0.i64(ptr %t127, ptr %t125, i64 %t126, i1 false)
  %t128 = insertvalue { i64, ptr } undef, i64 %t124, 0
  %t129 = insertvalue { i64, ptr } %t128, ptr %t127, 1
  store { i64, ptr } %t129, ptr %l63, !tbaa !27
  %t130 = load i32, ptr %l58
  %t131 = load { i64, ptr }, ptr %l60, !tbaa !27
  %t132 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t133 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %s4, ptr %s4, ptr %s4, i32 %t130, { i64, ptr } %t131, { i64, ptr } %t132)
  store %"compiler/msgs:Msg" %t133, ptr %l64
  br label %bb13
bb13:
  %t134 = load ptr, ptr %l51, !tbaa !29
  %t135 = load { i64, [3 x i64] }, ptr %l57
  %t136 = load %"compiler/msgs:Msg", ptr %l64
  %t137 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %s0, ptr %s4, ptr %t134, { i64, [3 x i64] } %t135, %"compiler/msgs:Msg" %t136)
  store i64 %t137, ptr %l65
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s4)
  br label %bb15
bb15:
  store %olang.scope zeroinitializer, ptr %s5
  %t138 = load i64, ptr %l12, !tbaa !24
  store i64 %t138, ptr %l66, !tbaa !24
  %t139 = load i64, ptr %l66, !tbaa !24
  %t140 = add i64 %t139, 1
  store i64 %t140, ptr %l67, !tbaa !24
  %t141 = load i64, ptr %l67, !tbaa !24
  store i64 %t141, ptr %l12, !tbaa !24
  call void @__olang_scope_close(ptr %s5)
  br label %bb7
bb16:
  call void @__olang_scope_close(ptr %s3)
  store ptr %l5, ptr %l68, !tbaa !29
  store ptr %l10, ptr %l69, !tbaa !29
  store ptr %l6, ptr %l70, !tbaa !29
  store ptr %l8, ptr %l71, !tbaa !29
  store ptr %l7, ptr %l72, !tbaa !29
  %t142 = load i64, ptr %l9, !tbaa !24
  store i64 %t142, ptr %l73, !tbaa !24
  %t144 = load ptr, ptr %l68, !tbaa !29
  %t145 = load ptr, ptr %l69, !tbaa !29
  %t146 = load ptr, ptr %l70, !tbaa !29
  %t147 = load ptr, ptr %l71, !tbaa !29
  %t148 = load ptr, ptr %l72, !tbaa !29
  %t149 = load i64, ptr %l73, !tbaa !24
  call void @compiler_2fparse_3aParser_2ector(ptr %t143, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %t144, ptr %t145, ptr %t146, ptr %t147, ptr %t148, i64 %t149)
  %t150 = load %"compiler/parse:Parser", ptr %t143
  store %"compiler/parse:Parser" %t150, ptr %l74
  br label %bb17
bb17:
  call void @llvm.memmove.p0.p0.i64(ptr %l15, ptr %l74, i64 264, i1 false)
  store ptr %l15, ptr %l75, !tbaa !29
  %t151 = load ptr, ptr %l75, !tbaa !29
  %t152 = call { i64, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eFile(ptr %s0, ptr %t151)
  store { i64, ptr } %t152, ptr %l76
  br label %bb18
bb18:
  %t153 = load { i64, ptr }, ptr %l76, !tbaa !27
  store { i64, ptr } %t153, ptr %l16, !tbaa !27
  %t154 = getelementptr %"compiler/scan:Tokens", ptr %l10, i32 0, i32 3
  %t155 = load { i64, ptr }, ptr %t154, !tbaa !27
  store { i64, ptr } %t155, ptr %l77, !tbaa !27
  %t156 = load { i64, ptr }, ptr %l77, !tbaa !27
  %t157 = extractvalue { i64, ptr } %t156, 0
  store i64 %t157, ptr %l78, !tbaa !24
  %t158 = load i64, ptr %l78, !tbaa !24
  %t159 = icmp sgt i64 %t158, 0
  store i1 %t159, ptr %l79, !tbaa !21
  %t160 = load i1, ptr %l79, !tbaa !21
  br i1 %t160, label %bb19, label %bb20
bb19:
  store i1 true, ptr %l80, !tbaa !21
  br label %bb23
bb20:
  store ptr %l7, ptr %l81, !tbaa !29
  %t161 = load ptr, ptr %l81, !tbaa !29
  %t162 = call %"std/prelude/list:List<compiler/diag:Said>" @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eAllSaid(ptr %s0, ptr %s0, ptr %t161)
  store %"std/prelude/list:List<compiler/diag:Said>" %t162, ptr %l82
  br label %bb21
bb21:
  %t163 = load %"std/prelude/list:List<compiler/diag:Said>", ptr %l82
  %t164 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 8, i64 8)
  store %"std/prelude/list:List<compiler/diag:Said>" %t163, ptr %t164
  store ptr %t164, ptr %l83, !tbaa !29
  %t165 = load ptr, ptr %l83, !tbaa !29
  %t166 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fdiag_3aSaid_3e_2eLen_3ccompiler_2fdiag_3aSaid_3e(ptr %s0, ptr %t165)
  store i64 %t166, ptr %l84
  br label %bb22
bb22:
  %t167 = load i64, ptr %l84, !tbaa !24
  %t168 = icmp sgt i64 %t167, 0
  store i1 %t168, ptr %l85, !tbaa !21
  %t169 = load i1, ptr %l85, !tbaa !21
  store i1 %t169, ptr %l80, !tbaa !21
  br label %bb23
bb23:
  %t170 = load i1, ptr %l80, !tbaa !21
  br i1 %t170, label %bb24, label %bb25
bb24:
  store %olang.scope zeroinitializer, ptr %s6
  %t171 = load ptr, ptr %l4, !tbaa !29
  store ptr %t171, ptr %l86, !tbaa !29
  store ptr %l7, ptr %l87, !tbaa !29
  %t172 = load ptr, ptr %l87, !tbaa !29
  %t173 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eRender(ptr %s0, ptr %s6, ptr %t172)
  store { i64, ptr } %t173, ptr %l88
  br label %bb26
bb25:
  br label %bb28
bb26:
  %t174 = load { i64, ptr }, ptr %l88, !tbaa !27
  %t175 = extractvalue { i64, ptr } %t174, 0
  %t176 = extractvalue { i64, ptr } %t174, 1
  %t177 = mul i64 %t175, 1
  %t178 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t177)
  call void @llvm.memcpy.p0.p0.i64(ptr %t178, ptr %t176, i64 %t177, i1 false)
  %t179 = insertvalue { i64, ptr } undef, i64 %t175, 0
  %t180 = insertvalue { i64, ptr } %t179, ptr %t178, 1
  store { i64, ptr } %t180, ptr %l89, !tbaa !27
  %t181 = load ptr, ptr %l86, !tbaa !29
  %t182 = load { i64, ptr }, ptr %l89, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v3, ptr %s6, ptr %t181, { i64, ptr } %t182)
  br label %bb27
bb27:
  store i32 65536, ptr %l90, !tbaa !23
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  %t183 = load i32, ptr %l90, !tbaa !23
  %t184 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t183, 0
  store { i32, { i64, ptr } } %t184, ptr %rv
  br label %ret
bb28:
  %t185 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t185, ptr %l91, !tbaa !27
  store ptr %l6, ptr %l92, !tbaa !29
  %t186 = getelementptr %"compiler/source:Source", ptr %l5, i32 0, i32 1
  %t187 = load { i64, ptr }, ptr %t186, !tbaa !27
  store { i64, ptr } %t187, ptr %l93, !tbaa !27
  store ptr %l7, ptr %l94, !tbaa !29
  %t188 = load { i64, ptr }, ptr %l91, !tbaa !27
  %t189 = load ptr, ptr %l92, !tbaa !29
  %t190 = load { i64, ptr }, ptr %l93, !tbaa !27
  %t191 = load ptr, ptr %l94, !tbaa !29
  %t192 = call { i64, ptr } @compiler_2funparse_2eHeldBranches(ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t188, ptr %t189, { i64, ptr } %t190, ptr %t191)
  store { i64, ptr } %t192, ptr %l95
  br label %bb29
bb29:
  %t193 = load { i64, ptr }, ptr %l95, !tbaa !27
  store { i64, ptr } %t193, ptr %l17, !tbaa !27
  %t194 = getelementptr %"compiler/source:Source", ptr %l5, i32 0, i32 1
  %t195 = load { i64, ptr }, ptr %t194, !tbaa !27
  store { i64, ptr } %t195, ptr %l96, !tbaa !27
  store ptr %l10, ptr %l97, !tbaa !29
  %t196 = getelementptr %"compiler/parse:Parser", ptr %l15, i32 0, i32 35
  store ptr %t196, ptr %l98, !tbaa !29
  %t197 = getelementptr %"compiler/parse:Parser", ptr %l15, i32 0, i32 36
  store ptr %t197, ptr %l99, !tbaa !29
  %t198 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t198, ptr %l100, !tbaa !27
  %t199 = load { i64, ptr }, ptr %l96, !tbaa !27
  %t200 = load ptr, ptr %l97, !tbaa !29
  %t201 = load ptr, ptr %l98, !tbaa !29
  %t202 = load ptr, ptr %l99, !tbaa !29
  %t203 = load { i64, ptr }, ptr %l100, !tbaa !27
  %t204 = call { i64, ptr } @compiler_2ffmt_2eFormat(ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %v4, { i64, ptr } %t199, ptr %t200, ptr %t201, ptr %t202, { i64, ptr } %t203)
  store { i64, ptr } %t204, ptr %l101
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s0)
  %t205 = load { i64, ptr }, ptr %l101, !tbaa !27
  %t206 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t205, 1
  store { i32, { i64, ptr } } %t206, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local i32 @compiler_2ffmt_2eFiles(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca %"std/io:Writer"
  %l4 = alloca %"std/io:Writer"
  %l5 = alloca { i64, ptr }
  %l6 = alloca i32
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca %"compiler/source:Source"
  %l12 = alloca %"std/prelude/text:StringBuilder"
  %l13 = alloca { i64, ptr }
  %l14 = alloca %"std/io:Writer"
  %l15 = alloca %"std/io:Writer"
  %l16 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i1
  %l24 = alloca i1
  %l25 = alloca { i64, ptr }
  %l26 = alloca i64
  %l27 = alloca { i64, ptr }
  %l28 = alloca %"compiler/source:Source"
  %l29 = alloca { i64, ptr }
  %l30 = alloca %"compiler/source:Source"
  %l31 = alloca i32
  %l32 = alloca i32
  %l33 = alloca i1
  %l34 = alloca ptr
  %l35 = alloca { i64, ptr }
  %l36 = alloca { i64, ptr }
  %l37 = alloca { i64, ptr }
  %l38 = alloca { i64, ptr }
  %l39 = alloca %"std/prelude/text:StringBuilder"
  %l40 = alloca { i64, ptr }
  %l41 = alloca ptr
  %l42 = alloca { i64, ptr }
  %l43 = alloca { i64, ptr }
  %l44 = alloca i1
  %l45 = alloca ptr
  %l46 = alloca { i64, ptr }
  %l47 = alloca i32
  %l48 = alloca ptr
  %l49 = alloca ptr
  %l50 = alloca { i64, ptr }
  %l51 = alloca { i64, ptr }
  %l52 = alloca { i64, ptr }
  %l53 = alloca i1
  %l54 = alloca { i64, ptr }
  %l55 = alloca { i64, ptr }
  %l56 = alloca i1
  %l57 = alloca i1
  %l58 = alloca { i64, ptr }
  %l59 = alloca { i64, ptr }
  %l60 = alloca i32
  %l61 = alloca i32
  %l62 = alloca i1
  %l63 = alloca ptr
  %l64 = alloca { i64, ptr }
  %l65 = alloca { i64, ptr }
  %l66 = alloca { i64, ptr }
  %l67 = alloca { i64, ptr }
  %l68 = alloca { i64, ptr }
  %l69 = alloca i1
  %l70 = alloca ptr
  %l71 = alloca { i64, ptr }
  %l72 = alloca { i64, ptr }
  %l73 = alloca { i64, ptr }
  %l74 = alloca i1
  %l75 = alloca i1
  %l76 = alloca ptr
  %l77 = alloca { i64, ptr }
  %l78 = alloca { i64, ptr }
  %l79 = alloca { i64, ptr }
  %l80 = alloca { i64, ptr }
  %l81 = alloca i64
  %l82 = alloca i64
  %l83 = alloca ptr
  %l84 = alloca i32
  %l85 = alloca i32
  %l86 = alloca i1
  %l87 = alloca i32
  %l88 = alloca ptr
  %l89 = alloca i32
  %l90 = alloca i32
  %l91 = alloca i1
  %l92 = alloca i32
  %l93 = alloca i32
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.builder
  %s4room = alloca [64 x i8], align 8
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.builder
  %s9room = alloca [64 x i8], align 8
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s14 = alloca %olang.builder
  %s14room = alloca [64 x i8], align 8
  %s15 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %rv = alloca i32
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/io:Writer" @std_2fio_3aWriter_2ector(ptr %s0, i32 1, i64 65536)
  store %"std/io:Writer" %t1, ptr %l14
  br label %bb1
bb1:
  %t2 = load %"std/io:Writer", ptr %l14
  store %"std/io:Writer" %t2, ptr %l3
  %t3 = call %"std/io:Writer" @std_2fio_3aWriter_2ector(ptr %s0, i32 2, i64 65536)
  store %"std/io:Writer" %t3, ptr %l15
  br label %bb2
bb2:
  %t4 = load %"std/io:Writer", ptr %l15
  store %"std/io:Writer" %t4, ptr %l4
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t5, ptr %l16, !tbaa !27
  %t6 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t7 = call { i64, ptr } @compiler_2ffmt_2ePreludeTypes(ptr %v2, ptr %s0, { i64, ptr } %t6)
  store { i64, ptr } %t7, ptr %l17
  br label %bb3
bb3:
  %t8 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t8, ptr %l5, !tbaa !27
  store i32 0, ptr %l6, !tbaa !23
  store %olang.scope zeroinitializer, ptr %s1
  %t9 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t9, ptr %l18, !tbaa !27
  %t10 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t10, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t11 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t11, ptr %l19, !tbaa !27
  %t12 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t12, 0
  store i64 %t13, ptr %l20, !tbaa !24
  %t14 = load i64, ptr %l20, !tbaa !24
  store i64 %t14, ptr %l9, !tbaa !24
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s2
  %t15 = load i64, ptr %l8, !tbaa !24
  store i64 %t15, ptr %l21, !tbaa !24
  %t16 = load i64, ptr %l9, !tbaa !24
  store i64 %t16, ptr %l22, !tbaa !24
  %t17 = load i64, ptr %l21, !tbaa !24
  %t18 = load i64, ptr %l22, !tbaa !24
  %t19 = icmp slt i64 %t17, %t18
  store i1 %t19, ptr %l23, !tbaa !21
  %t20 = load i1, ptr %l23, !tbaa !21
  %t21 = xor i1 %t20, true
  store i1 %t21, ptr %l24, !tbaa !21
  %t22 = load i1, ptr %l24, !tbaa !21
  br i1 %t22, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s2)
  br label %bb49
bb6:
  br label %bb7
bb7:
  %t23 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t23, ptr %l25, !tbaa !27
  %t24 = load i64, ptr %l8, !tbaa !24
  store i64 %t24, ptr %l26, !tbaa !24
  %t25 = load i64, ptr %l26, !tbaa !24
  %t26 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = getelementptr { i64, ptr }, ptr %t27, i64 %t25
  %t29 = load { i64, ptr }, ptr %t28, !tbaa !37
  store { i64, ptr } %t29, ptr %l27, !tbaa !27
  %t30 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t30, ptr %l10, !tbaa !27
  %t31 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t31, ptr %l29, !tbaa !27
  %t32 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t33 = call { i32, %"compiler/source:Source" } @compiler_2fsource_2eRead(ptr %v1, ptr %s2, { i64, ptr } %t32)
  %t34 = extractvalue { i32, %"compiler/source:Source" } %t33, 1
  %t35 = extractvalue { i32, %"compiler/source:Source" } %t33, 0
  store i32 %t35, ptr %l31
  %t36 = icmp ne i32 %t35, 0
  br i1 %t36, label %bb9, label %ok.37
ok.37:
  store %"compiler/source:Source" %t34, ptr %l30
  br label %bb8
bb8:
  %t38 = load %"compiler/source:Source", ptr %l30
  store %"compiler/source:Source" %t38, ptr %l28
  br label %bb14
bb9:
  %t39 = load i32, ptr %l31, !tbaa !23
  %t40 = ashr i32 %t39, 16
  store i32 %t40, ptr %l32, !tbaa !23
  %t41 = load i32, ptr %l32, !tbaa !23
  %t42 = icmp eq i32 %t41, 1
  store i1 %t42, ptr %l33, !tbaa !21
  %t43 = load i1, ptr %l33, !tbaa !21
  br i1 %t43, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  call void @__olang_check_failed(ptr @.c0)
  unreachable
bb12:
  store %olang.scope zeroinitializer, ptr %s3
  store ptr %l4, ptr %l34, !tbaa !29
  %t44 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t44, ptr %l35, !tbaa !27
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s4
  store ptr %s4room, ptr %s4
  %t45 = extractvalue { i64, ptr } { i64 7, ptr @.d1 }, 1
  %t46 = extractvalue { i64, ptr } { i64 7, ptr @.d1 }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t45, i64 %t46)
  %t47 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t48 = extractvalue { i64, ptr } %t47, 1
  %t49 = extractvalue { i64, ptr } %t47, 0
  call void @__olang_sb_put(ptr %s4, ptr %t48, i64 %t49)
  %t50 = extractvalue { i64, ptr } { i64 17, ptr @.d2 }, 1
  %t51 = extractvalue { i64, ptr } { i64 17, ptr @.d2 }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t50, i64 %t51)
  %t52 = load ptr, ptr %s4
  %t53 = getelementptr %olang.builder, ptr %s4, i32 0, i32 1
  %t54 = load i64, ptr %t53
  %t55 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t54)
  call void @llvm.memcpy.p0.p0.i64(ptr %t55, ptr %t52, i64 %t54, i1 false)
  %t56 = insertvalue { i64, ptr } undef, i64 %t54, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t55, 1
  store { i64, ptr } %t57, ptr %l36, !tbaa !27
  call void @__olang_sb_done(ptr %s4)
  %t58 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t58, ptr %l37, !tbaa !27
  %t59 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t60 = extractvalue { i64, ptr } %t59, 0
  %t61 = extractvalue { i64, ptr } %t59, 1
  %t62 = mul i64 %t60, 1
  %t63 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t62)
  call void @llvm.memcpy.p0.p0.i64(ptr %t63, ptr %t61, i64 %t62, i1 false)
  %t64 = insertvalue { i64, ptr } undef, i64 %t60, 0
  %t65 = insertvalue { i64, ptr } %t64, ptr %t63, 1
  store { i64, ptr } %t65, ptr %l38, !tbaa !27
  %t66 = load ptr, ptr %l34, !tbaa !29
  %t67 = load { i64, ptr }, ptr %l38, !tbaa !27
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %s0, ptr %s3, ptr %t66, { i64, ptr } %t67)
  br label %bb13
bb13:
  store i32 1, ptr %l6, !tbaa !23
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  br label %bb48
bb14:
  %t68 = load %"compiler/source:Source", ptr %l28
  store %"compiler/source:Source" %t68, ptr %l11
  %t69 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s2)
  store %"std/prelude/text:StringBuilder" %t69, ptr %l39
  br label %bb15
bb15:
  %t70 = load %"std/prelude/text:StringBuilder", ptr %l39
  store %"std/prelude/text:StringBuilder" %t70, ptr %l12
  store ptr %l11, ptr %l41, !tbaa !29
  %t71 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t71, ptr %l42, !tbaa !27
  %t72 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t72, ptr %l43, !tbaa !27
  %t73 = call i1 @compiler_2fdiag_2eColorWanted()
  store i1 %t73, ptr %l44
  br label %bb16
bb16:
  store ptr %l12, ptr %l45, !tbaa !29
  %t74 = load ptr, ptr %l41, !tbaa !29
  %t75 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t76 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t77 = load i1, ptr %l44, !tbaa !21
  %t78 = load ptr, ptr %l45, !tbaa !29
  %t79 = call { i32, { i64, ptr } } @compiler_2ffmt_2eFileLayout(ptr %s2, ptr %v2, ptr %s0, ptr %s2, ptr %s2, ptr %t74, { i64, ptr } %t75, { i64, ptr } %t76, i1 %t77, ptr %t78)
  %t80 = extractvalue { i32, { i64, ptr } } %t79, 1
  %t81 = extractvalue { i32, { i64, ptr } } %t79, 0
  store i32 %t81, ptr %l47
  %t82 = icmp ne i32 %t81, 0
  br i1 %t82, label %bb18, label %ok.83
ok.83:
  store { i64, ptr } %t80, ptr %l46
  br label %bb17
bb17:
  %t84 = load { i64, ptr }, ptr %l46, !tbaa !27
  store { i64, ptr } %t84, ptr %l40, !tbaa !27
  br label %bb22
bb18:
  br label %bb19
bb19:
  store %olang.scope zeroinitializer, ptr %s5
  store ptr %l4, ptr %l48, !tbaa !29
  store ptr %l12, ptr %l49, !tbaa !29
  %t85 = load ptr, ptr %l49, !tbaa !29
  %t86 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s2, ptr %s5, ptr %t85)
  store { i64, ptr } %t86, ptr %l50
  br label %bb20
bb20:
  %t87 = load { i64, ptr }, ptr %l50, !tbaa !27
  store { i64, ptr } %t87, ptr %l51, !tbaa !27
  %t88 = load ptr, ptr %l48, !tbaa !29
  %t89 = load { i64, ptr }, ptr %l51, !tbaa !27
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %s0, ptr %s5, ptr %t88, { i64, ptr } %t89)
  br label %bb21
bb21:
  store i32 1, ptr %l6, !tbaa !23
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s2)
  br label %bb48
bb22:
  %t90 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t90, ptr %l13, !tbaa !27
  %t91 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t91, ptr %l52, !tbaa !27
  %t92 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t93 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s2, { i64, ptr } %t92, { i64, ptr } { i64 2, ptr @.d3 })
  store i1 %t93, ptr %l53
  br label %bb23
bb23:
  %t94 = load i1, ptr %l53, !tbaa !21
  br i1 %t94, label %bb24, label %bb25
bb24:
  store %olang.scope zeroinitializer, ptr %s6
  %t95 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t95, ptr %l54, !tbaa !27
  %t96 = getelementptr %"compiler/source:Source", ptr %l11, i32 0, i32 1
  %t97 = load { i64, ptr }, ptr %t96, !tbaa !27
  store { i64, ptr } %t97, ptr %l55, !tbaa !27
  %t98 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t99 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t100 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s2, ptr %s2, { i64, ptr } %t98, { i64, ptr } %t99)
  store i1 %t100, ptr %l56
  br label %bb26
bb25:
  store %olang.scope zeroinitializer, ptr %s10
  %t101 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t101, ptr %l68, !tbaa !27
  %t102 = load { i64, ptr }, ptr %l68, !tbaa !27
  %t103 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s10, { i64, ptr } %t102, { i64, ptr } { i64 2, ptr @.d4 })
  store i1 %t103, ptr %l69
  br label %bb37
bb26:
  %t104 = load i1, ptr %l56, !tbaa !21
  %t105 = xor i1 %t104, true
  store i1 %t105, ptr %l57, !tbaa !21
  %t106 = load i1, ptr %l57, !tbaa !21
  br i1 %t106, label %bb27, label %bb28
bb27:
  store %olang.scope zeroinitializer, ptr %s7
  %t107 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t107, ptr %l58, !tbaa !27
  %t108 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t108, ptr %l59, !tbaa !27
  %t109 = load { i64, ptr }, ptr %l58, !tbaa !27
  %t110 = load { i64, ptr }, ptr %l59, !tbaa !27
  %t111 = call i32 @std_2fos_2eWriteFile(ptr %v1, ptr %s2, { i64, ptr } %t109, { i64, ptr } %t110)
  store i32 %t111, ptr %l60
  %t112 = icmp ne i32 %t111, 0
  br i1 %t112, label %bb30, label %ok.113
ok.113:
  br label %bb29
bb28:
  br label %bb36
bb29:
  br label %bb35
bb30:
  %t114 = load i32, ptr %l60, !tbaa !23
  %t115 = ashr i32 %t114, 16
  store i32 %t115, ptr %l61, !tbaa !23
  %t116 = load i32, ptr %l61, !tbaa !23
  %t117 = icmp eq i32 %t116, 1
  store i1 %t117, ptr %l62, !tbaa !21
  %t118 = load i1, ptr %l62, !tbaa !21
  br i1 %t118, label %bb31, label %bb32
bb31:
  br label %bb33
bb32:
  call void @__olang_check_failed(ptr @.c5)
  unreachable
bb33:
  store %olang.scope zeroinitializer, ptr %s8
  store ptr %l4, ptr %l63, !tbaa !29
  %t119 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t119, ptr %l64, !tbaa !27
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s9
  store ptr %s9room, ptr %s9
  %t120 = extractvalue { i64, ptr } { i64 7, ptr @.d6 }, 1
  %t121 = extractvalue { i64, ptr } { i64 7, ptr @.d6 }, 0
  call void @__olang_sb_put(ptr %s9, ptr %t120, i64 %t121)
  %t122 = load { i64, ptr }, ptr %l64, !tbaa !27
  %t123 = extractvalue { i64, ptr } %t122, 1
  %t124 = extractvalue { i64, ptr } %t122, 0
  call void @__olang_sb_put(ptr %s9, ptr %t123, i64 %t124)
  %t125 = extractvalue { i64, ptr } { i64 20, ptr @.d7 }, 1
  %t126 = extractvalue { i64, ptr } { i64 20, ptr @.d7 }, 0
  call void @__olang_sb_put(ptr %s9, ptr %t125, i64 %t126)
  %t127 = load ptr, ptr %s9
  %t128 = getelementptr %olang.builder, ptr %s9, i32 0, i32 1
  %t129 = load i64, ptr %t128
  %t130 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t129)
  call void @llvm.memcpy.p0.p0.i64(ptr %t130, ptr %t127, i64 %t129, i1 false)
  %t131 = insertvalue { i64, ptr } undef, i64 %t129, 0
  %t132 = insertvalue { i64, ptr } %t131, ptr %t130, 1
  store { i64, ptr } %t132, ptr %l65, !tbaa !27
  call void @__olang_sb_done(ptr %s9)
  %t133 = load { i64, ptr }, ptr %l65, !tbaa !27
  store { i64, ptr } %t133, ptr %l66, !tbaa !27
  %t134 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t135 = extractvalue { i64, ptr } %t134, 0
  %t136 = extractvalue { i64, ptr } %t134, 1
  %t137 = mul i64 %t135, 1
  %t138 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t137)
  call void @llvm.memcpy.p0.p0.i64(ptr %t138, ptr %t136, i64 %t137, i1 false)
  %t139 = insertvalue { i64, ptr } undef, i64 %t135, 0
  %t140 = insertvalue { i64, ptr } %t139, ptr %t138, 1
  store { i64, ptr } %t140, ptr %l67, !tbaa !27
  %t141 = load ptr, ptr %l63, !tbaa !29
  %t142 = load { i64, ptr }, ptr %l67, !tbaa !27
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %s0, ptr %s8, ptr %t141, { i64, ptr } %t142)
  br label %bb34
bb34:
  store i32 1, ptr %l6, !tbaa !23
  call void @__olang_scope_close(ptr %s8)
  br label %bb35
bb35:
  call void @__olang_scope_close(ptr %s7)
  br label %bb36
bb36:
  call void @__olang_scope_close(ptr %s6)
  br label %bb47
bb37:
  %t143 = load i1, ptr %l69, !tbaa !21
  br i1 %t143, label %bb38, label %bb39
bb38:
  store %olang.scope zeroinitializer, ptr %s11
  store ptr %l3, ptr %l70, !tbaa !29
  %t144 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t144, ptr %l71, !tbaa !27
  %t145 = load ptr, ptr %l70, !tbaa !29
  %t146 = load { i64, ptr }, ptr %l71, !tbaa !27
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %s0, ptr %s2, ptr %t145, { i64, ptr } %t146)
  br label %bb40
bb39:
  store %olang.scope zeroinitializer, ptr %s12
  %t147 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t147, ptr %l72, !tbaa !27
  %t148 = getelementptr %"compiler/source:Source", ptr %l11, i32 0, i32 1
  %t149 = load { i64, ptr }, ptr %t148, !tbaa !27
  store { i64, ptr } %t149, ptr %l73, !tbaa !27
  %t150 = load { i64, ptr }, ptr %l72, !tbaa !27
  %t151 = load { i64, ptr }, ptr %l73, !tbaa !27
  %t152 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s2, ptr %s2, { i64, ptr } %t150, { i64, ptr } %t151)
  store i1 %t152, ptr %l74
  br label %bb41
bb40:
  call void @__olang_scope_close(ptr %s11)
  br label %bb46
bb41:
  %t153 = load i1, ptr %l74, !tbaa !21
  %t154 = xor i1 %t153, true
  store i1 %t154, ptr %l75, !tbaa !21
  %t155 = load i1, ptr %l75, !tbaa !21
  br i1 %t155, label %bb42, label %bb43
bb42:
  store %olang.scope zeroinitializer, ptr %s13
  store ptr %l3, ptr %l76, !tbaa !29
  %t156 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t156, ptr %l77, !tbaa !27
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s14
  store ptr %s14room, ptr %s14
  %t157 = load { i64, ptr }, ptr %l77, !tbaa !27
  %t158 = extractvalue { i64, ptr } %t157, 1
  %t159 = extractvalue { i64, ptr } %t157, 0
  call void @__olang_sb_put(ptr %s14, ptr %t158, i64 %t159)
  %t160 = extractvalue { i64, ptr } { i64 1, ptr @.d8 }, 1
  %t161 = extractvalue { i64, ptr } { i64 1, ptr @.d8 }, 0
  call void @__olang_sb_put(ptr %s14, ptr %t160, i64 %t161)
  %t162 = load ptr, ptr %s14
  %t163 = getelementptr %olang.builder, ptr %s14, i32 0, i32 1
  %t164 = load i64, ptr %t163
  %t165 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t164)
  call void @llvm.memcpy.p0.p0.i64(ptr %t165, ptr %t162, i64 %t164, i1 false)
  %t166 = insertvalue { i64, ptr } undef, i64 %t164, 0
  %t167 = insertvalue { i64, ptr } %t166, ptr %t165, 1
  store { i64, ptr } %t167, ptr %l78, !tbaa !27
  call void @__olang_sb_done(ptr %s14)
  %t168 = load { i64, ptr }, ptr %l78, !tbaa !27
  store { i64, ptr } %t168, ptr %l79, !tbaa !27
  %t169 = load { i64, ptr }, ptr %l79, !tbaa !27
  %t170 = extractvalue { i64, ptr } %t169, 0
  %t171 = extractvalue { i64, ptr } %t169, 1
  %t172 = mul i64 %t170, 1
  %t173 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t172)
  call void @llvm.memcpy.p0.p0.i64(ptr %t173, ptr %t171, i64 %t172, i1 false)
  %t174 = insertvalue { i64, ptr } undef, i64 %t170, 0
  %t175 = insertvalue { i64, ptr } %t174, ptr %t173, 1
  store { i64, ptr } %t175, ptr %l80, !tbaa !27
  %t176 = load ptr, ptr %l76, !tbaa !29
  %t177 = load { i64, ptr }, ptr %l80, !tbaa !27
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %s0, ptr %s13, ptr %t176, { i64, ptr } %t177)
  br label %bb44
bb43:
  br label %bb45
bb44:
  store i32 1, ptr %l6, !tbaa !23
  call void @__olang_scope_close(ptr %s13)
  br label %bb45
bb45:
  call void @__olang_scope_close(ptr %s12)
  br label %bb46
bb46:
  call void @__olang_scope_close(ptr %s10)
  br label %bb47
bb47:
  call void @__olang_scope_close(ptr %s2)
  br label %bb48
bb48:
  store %olang.scope zeroinitializer, ptr %s15
  %t178 = load i64, ptr %l8, !tbaa !24
  store i64 %t178, ptr %l81, !tbaa !24
  %t179 = load i64, ptr %l81, !tbaa !24
  %t180 = add i64 %t179, 1
  store i64 %t180, ptr %l82, !tbaa !24
  %t181 = load i64, ptr %l82, !tbaa !24
  store i64 %t181, ptr %l8, !tbaa !24
  call void @__olang_scope_close(ptr %s15)
  br label %bb4
bb49:
  call void @__olang_scope_close(ptr %s1)
  store ptr %l3, ptr %l83, !tbaa !29
  %t182 = load ptr, ptr %l83, !tbaa !29
  %t183 = call i32 @std_2fio_2estd_2fio_3aWriter_2eFlush(ptr %s0, ptr %t182)
  store i32 %t183, ptr %l84
  %t184 = icmp ne i32 %t183, 0
  br i1 %t184, label %bb51, label %ok.185
ok.185:
  br label %bb50
bb50:
  br label %bb55
bb51:
  %t186 = load i32, ptr %l84, !tbaa !23
  %t187 = ashr i32 %t186, 16
  store i32 %t187, ptr %l85, !tbaa !23
  %t188 = load i32, ptr %l85, !tbaa !23
  %t189 = icmp eq i32 %t188, 1
  store i1 %t189, ptr %l86, !tbaa !21
  %t190 = load i1, ptr %l86, !tbaa !21
  br i1 %t190, label %bb52, label %bb53
bb52:
  br label %bb54
bb53:
  call void @__olang_check_failed(ptr @.c9)
  unreachable
bb54:
  store %olang.scope zeroinitializer, ptr %s16
  store i32 1, ptr %l87, !tbaa !23
  call void @__olang_scope_close(ptr %s16)
  call void @__olang_scope_close(ptr %s0)
  %t191 = load i32, ptr %l87, !tbaa !23
  store i32 %t191, ptr %rv
  br label %ret
bb55:
  store ptr %l4, ptr %l88, !tbaa !29
  %t192 = load ptr, ptr %l88, !tbaa !29
  %t193 = call i32 @std_2fio_2estd_2fio_3aWriter_2eFlush(ptr %s0, ptr %t192)
  store i32 %t193, ptr %l89
  %t194 = icmp ne i32 %t193, 0
  br i1 %t194, label %bb57, label %ok.195
ok.195:
  br label %bb56
bb56:
  br label %bb61
bb57:
  %t196 = load i32, ptr %l89, !tbaa !23
  %t197 = ashr i32 %t196, 16
  store i32 %t197, ptr %l90, !tbaa !23
  %t198 = load i32, ptr %l90, !tbaa !23
  %t199 = icmp eq i32 %t198, 1
  store i1 %t199, ptr %l91, !tbaa !21
  %t200 = load i1, ptr %l91, !tbaa !21
  br i1 %t200, label %bb58, label %bb59
bb58:
  br label %bb60
bb59:
  call void @__olang_check_failed(ptr @.c10)
  unreachable
bb60:
  store %olang.scope zeroinitializer, ptr %s17
  store i32 1, ptr %l92, !tbaa !23
  call void @__olang_scope_close(ptr %s17)
  call void @__olang_scope_close(ptr %s0)
  %t201 = load i32, ptr %l92, !tbaa !23
  store i32 %t201, ptr %rv
  br label %ret
bb61:
  %t202 = load i32, ptr %l6, !tbaa !23
  store i32 %t202, ptr %l93, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  %t203 = load i32, ptr %l93, !tbaa !23
  store i32 %t203, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2ffmt_2eFormat(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, { i64, ptr } %a0, ptr %a1, ptr %a2, ptr %a3, { i64, ptr } %a4) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/fmt:formatter"
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca ptr
  %l13 = alloca i64
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca %"compiler/source:Span"
  %l22 = alloca { i64, ptr }
  %l23 = alloca ptr
  %l24 = alloca { i64, ptr }
  %l25 = alloca %"compiler/fmt:formatter"
  %l26 = alloca ptr
  %l27 = alloca { i64, ptr }
  %l28 = alloca ptr
  %l29 = alloca i64
  %l30 = alloca { i64, ptr }
  %l31 = alloca i32
  %l32 = alloca i32
  %l33 = alloca i1
  %l34 = alloca { i64, ptr }
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i1
  %l39 = alloca i1
  %l40 = alloca { i64, ptr }
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca { i64, ptr }
  %l44 = alloca i64
  %l45 = alloca { i64, ptr }
  %l46 = alloca i64
  %l47 = alloca i64
  %l48 = alloca i64
  %l49 = alloca i64
  %l50 = alloca i64
  %l51 = alloca i64
  %l52 = alloca i64
  %l53 = alloca i64
  %l54 = alloca ptr
  %l55 = alloca { i64, ptr }
  %l56 = alloca ptr
  %l57 = alloca i64
  %l58 = alloca { i64, ptr }
  %l59 = alloca i32
  %l60 = alloca i32
  %l61 = alloca i1
  %l62 = alloca { i64, ptr }
  %l63 = alloca i64
  %l64 = alloca i64
  %l65 = alloca i64
  %l66 = alloca i1
  %l67 = alloca i1
  %l68 = alloca { i64, ptr }
  %l69 = alloca i64
  %l70 = alloca i64
  %l71 = alloca { i64, ptr }
  %l72 = alloca i64
  %l73 = alloca { i64, ptr }
  %l74 = alloca i64
  %l75 = alloca i64
  %l76 = alloca i64
  %l77 = alloca i64
  %l78 = alloca i64
  %l79 = alloca i64
  %l80 = alloca i64
  %l81 = alloca i64
  %l82 = alloca { i64, ptr }
  %l83 = alloca { i64, ptr }
  %l84 = alloca i64
  %l85 = alloca i64
  %l86 = alloca i64
  %l87 = alloca i1
  %l88 = alloca i1
  %l89 = alloca { i64, ptr }
  %l90 = alloca i64
  %l91 = alloca %"compiler/source:Span"
  %l92 = alloca ptr
  %l93 = alloca { i64, ptr }
  %l94 = alloca i32
  %l95 = alloca i64
  %l96 = alloca i64
  %l97 = alloca ptr
  %l98 = alloca { i64, ptr }
  %l99 = alloca i32
  %l100 = alloca i64
  %l101 = alloca i64
  %l102 = alloca i64
  %l103 = alloca i64
  %l104 = alloca i64
  %l105 = alloca ptr
  %l106 = alloca ptr
  %l107 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  %t6 = alloca %"compiler/fmt:formatter", align 8
  store { i64, ptr } %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  store { i64, ptr } %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t1, ptr %l22, !tbaa !27
  %t2 = load ptr, ptr %l1, !tbaa !29
  store ptr %t2, ptr %l23, !tbaa !29
  %t3 = load ptr, ptr %l23, !tbaa !29
  %t4 = getelementptr %"compiler/scan:Tokens", ptr %t3, i32 0, i32 0
  %t5 = load { i64, ptr }, ptr %t4, !tbaa !27
  store { i64, ptr } %t5, ptr %l24, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t8 = load { i64, ptr }, ptr %l24, !tbaa !27
  call void @compiler_2ffmt_3aformatter_2ector(ptr %t6, ptr %v0, ptr %v1, ptr %s0, { i64, ptr } %t7, { i64, ptr } %t8)
  %t9 = load %"compiler/fmt:formatter", ptr %t6
  store %"compiler/fmt:formatter" %t9, ptr %l25
  br label %bb1
bb1:
  call void @llvm.memmove.p0.p0.i64(ptr %l5, ptr %l25, i64 296, i1 false)
  store %olang.scope zeroinitializer, ptr %s1
  %t10 = load ptr, ptr %l2, !tbaa !29
  store ptr %t10, ptr %l26, !tbaa !29
  %t11 = load ptr, ptr %l26, !tbaa !29
  store ptr %t11, ptr %l6, !tbaa !29
  store i64 0, ptr %l7, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t12 = load ptr, ptr %l6, !tbaa !29
  store ptr %t12, ptr %l28, !tbaa !29
  %t13 = load i64, ptr %l7, !tbaa !24
  store i64 %t13, ptr %l29, !tbaa !24
  %t14 = load ptr, ptr %l28, !tbaa !29
  %t15 = load i64, ptr %l29, !tbaa !24
  %t16 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %v2, ptr %t14, i64 %t15)
  %t17 = extractvalue { i32, { i64, ptr } } %t16, 1
  %t18 = extractvalue { i32, { i64, ptr } } %t16, 0
  store i32 %t18, ptr %l31
  %t19 = icmp ne i32 %t18, 0
  br i1 %t19, label %bb4, label %ok.20
ok.20:
  store { i64, ptr } %t17, ptr %l30
  br label %bb3
bb3:
  %t21 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t21, ptr %l27, !tbaa !27
  br label %bb8
bb4:
  %t22 = load i32, ptr %l31, !tbaa !23
  %t23 = ashr i32 %t22, 16
  store i32 %t23, ptr %l32, !tbaa !23
  %t24 = load i32, ptr %l32, !tbaa !23
  %t25 = icmp eq i32 %t24, 1
  store i1 %t25, ptr %l33, !tbaa !21
  %t26 = load i1, ptr %l33, !tbaa !21
  br i1 %t26, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  call void @__olang_check_failed(ptr @.c11)
  unreachable
bb7:
  call void @__olang_scope_close(ptr %s2)
  br label %bb16
bb8:
  %t27 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t27, ptr %l8, !tbaa !27
  %t28 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t28, ptr %l34, !tbaa !27
  %t29 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t30 = extractvalue { i64, ptr } %t29, 0
  store i64 %t30, ptr %l35, !tbaa !24
  %t31 = load i64, ptr %l35, !tbaa !24
  store i64 %t31, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s3
  %t32 = load i64, ptr %l10, !tbaa !24
  store i64 %t32, ptr %l36, !tbaa !24
  %t33 = load i64, ptr %l9, !tbaa !24
  store i64 %t33, ptr %l37, !tbaa !24
  %t34 = load i64, ptr %l36, !tbaa !24
  %t35 = load i64, ptr %l37, !tbaa !24
  %t36 = icmp slt i64 %t34, %t35
  store i1 %t36, ptr %l38, !tbaa !21
  %t37 = load i1, ptr %l38, !tbaa !21
  %t38 = xor i1 %t37, true
  store i1 %t38, ptr %l39, !tbaa !21
  %t39 = load i1, ptr %l39, !tbaa !21
  br i1 %t39, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s3)
  br label %bb14
bb11:
  br label %bb12
bb12:
  %t40 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t40, ptr %l40, !tbaa !27
  %t41 = load i64, ptr %l10, !tbaa !24
  store i64 %t41, ptr %l41, !tbaa !24
  %t42 = load i64, ptr %l41, !tbaa !24
  %t43 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !27
  %t45 = getelementptr i64, ptr %t44, i64 %t42
  %t46 = load i64, ptr %t45, !tbaa !34
  store i64 %t46, ptr %l42, !tbaa !24
  %t47 = load i64, ptr %l42, !tbaa !24
  store i64 %t47, ptr %l11, !tbaa !24
  %t48 = getelementptr %"compiler/fmt:formatter", ptr %l5, i32 0, i32 2
  %t49 = load { i64, ptr }, ptr %t48, !tbaa !27
  store { i64, ptr } %t49, ptr %l43, !tbaa !27
  %t50 = load i64, ptr %l11, !tbaa !24
  store i64 %t50, ptr %l44, !tbaa !24
  %t51 = getelementptr %"compiler/fmt:formatter", ptr %l5, i32 0, i32 2
  %t52 = load { i64, ptr }, ptr %t51, !tbaa !27
  store { i64, ptr } %t52, ptr %l45, !tbaa !27
  %t53 = load i64, ptr %l11, !tbaa !24
  store i64 %t53, ptr %l46, !tbaa !24
  %t54 = load i64, ptr %l46, !tbaa !24
  %t55 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t56 = load ptr, ptr %t55, !tbaa !27
  %t57 = getelementptr i64, ptr %t56, i64 %t54
  %t58 = load i64, ptr %t57, !tbaa !34
  store i64 %t58, ptr %l47, !tbaa !24
  %t59 = load i64, ptr %l47, !tbaa !24
  %t60 = add i64 %t59, 1
  store i64 %t60, ptr %l48, !tbaa !24
  %t61 = load i64, ptr %l48, !tbaa !24
  %t62 = load i64, ptr %l44, !tbaa !24
  %t63 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t64 = load ptr, ptr %t63, !tbaa !27
  %t65 = getelementptr i64, ptr %t64, i64 %t62
  store i64 %t61, ptr %t65, !tbaa !34
  call void @__olang_scope_close(ptr %s3)
  br label %bb13
bb13:
  store %olang.scope zeroinitializer, ptr %s4
  %t66 = load i64, ptr %l10, !tbaa !24
  store i64 %t66, ptr %l49, !tbaa !24
  %t67 = load i64, ptr %l49, !tbaa !24
  %t68 = add i64 %t67, 1
  store i64 %t68, ptr %l50, !tbaa !24
  %t69 = load i64, ptr %l50, !tbaa !24
  store i64 %t69, ptr %l10, !tbaa !24
  call void @__olang_scope_close(ptr %s4)
  br label %bb9
bb14:
  %t70 = load i64, ptr %l7, !tbaa !24
  store i64 %t70, ptr %l51, !tbaa !24
  %t71 = load i64, ptr %l9, !tbaa !24
  store i64 %t71, ptr %l52, !tbaa !24
  %t72 = load i64, ptr %l51, !tbaa !24
  %t73 = load i64, ptr %l52, !tbaa !24
  %t74 = add i64 %t72, %t73
  store i64 %t74, ptr %l53, !tbaa !24
  %t75 = load i64, ptr %l53, !tbaa !24
  store i64 %t75, ptr %l7, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb15
bb15:
  br label %bb2
bb16:
  call void @__olang_scope_close(ptr %s1)
  store %olang.scope zeroinitializer, ptr %s5
  %t76 = load ptr, ptr %l3, !tbaa !29
  store ptr %t76, ptr %l54, !tbaa !29
  %t77 = load ptr, ptr %l54, !tbaa !29
  store ptr %t77, ptr %l12, !tbaa !29
  store i64 0, ptr %l13, !tbaa !24
  br label %bb17
bb17:
  store %olang.scope zeroinitializer, ptr %s6
  %t78 = load ptr, ptr %l12, !tbaa !29
  store ptr %t78, ptr %l56, !tbaa !29
  %t79 = load i64, ptr %l13, !tbaa !24
  store i64 %t79, ptr %l57, !tbaa !24
  %t80 = load ptr, ptr %l56, !tbaa !29
  %t81 = load i64, ptr %l57, !tbaa !24
  %t82 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %v3, ptr %t80, i64 %t81)
  %t83 = extractvalue { i32, { i64, ptr } } %t82, 1
  %t84 = extractvalue { i32, { i64, ptr } } %t82, 0
  store i32 %t84, ptr %l59
  %t85 = icmp ne i32 %t84, 0
  br i1 %t85, label %bb19, label %ok.86
ok.86:
  store { i64, ptr } %t83, ptr %l58
  br label %bb18
bb18:
  %t87 = load { i64, ptr }, ptr %l58, !tbaa !27
  store { i64, ptr } %t87, ptr %l55, !tbaa !27
  br label %bb23
bb19:
  %t88 = load i32, ptr %l59, !tbaa !23
  %t89 = ashr i32 %t88, 16
  store i32 %t89, ptr %l60, !tbaa !23
  %t90 = load i32, ptr %l60, !tbaa !23
  %t91 = icmp eq i32 %t90, 1
  store i1 %t91, ptr %l61, !tbaa !21
  %t92 = load i1, ptr %l61, !tbaa !21
  br i1 %t92, label %bb20, label %bb21
bb20:
  br label %bb22
bb21:
  call void @__olang_check_failed(ptr @.c12)
  unreachable
bb22:
  call void @__olang_scope_close(ptr %s6)
  br label %bb31
bb23:
  %t93 = load { i64, ptr }, ptr %l55, !tbaa !27
  store { i64, ptr } %t93, ptr %l14, !tbaa !27
  %t94 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t94, ptr %l62, !tbaa !27
  %t95 = load { i64, ptr }, ptr %l62, !tbaa !27
  %t96 = extractvalue { i64, ptr } %t95, 0
  store i64 %t96, ptr %l63, !tbaa !24
  %t97 = load i64, ptr %l63, !tbaa !24
  store i64 %t97, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  br label %bb24
bb24:
  store %olang.scope zeroinitializer, ptr %s7
  %t98 = load i64, ptr %l16, !tbaa !24
  store i64 %t98, ptr %l64, !tbaa !24
  %t99 = load i64, ptr %l15, !tbaa !24
  store i64 %t99, ptr %l65, !tbaa !24
  %t100 = load i64, ptr %l64, !tbaa !24
  %t101 = load i64, ptr %l65, !tbaa !24
  %t102 = icmp slt i64 %t100, %t101
  store i1 %t102, ptr %l66, !tbaa !21
  %t103 = load i1, ptr %l66, !tbaa !21
  %t104 = xor i1 %t103, true
  store i1 %t104, ptr %l67, !tbaa !21
  %t105 = load i1, ptr %l67, !tbaa !21
  br i1 %t105, label %bb25, label %bb26
bb25:
  call void @__olang_scope_close(ptr %s7)
  br label %bb29
bb26:
  br label %bb27
bb27:
  %t106 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t106, ptr %l68, !tbaa !27
  %t107 = load i64, ptr %l16, !tbaa !24
  store i64 %t107, ptr %l69, !tbaa !24
  %t108 = load i64, ptr %l69, !tbaa !24
  %t109 = getelementptr { i64, ptr }, ptr %l68, i32 0, i32 1
  %t110 = load ptr, ptr %t109, !tbaa !27
  %t111 = getelementptr i64, ptr %t110, i64 %t108
  %t112 = load i64, ptr %t111, !tbaa !34
  store i64 %t112, ptr %l70, !tbaa !24
  %t113 = load i64, ptr %l70, !tbaa !24
  store i64 %t113, ptr %l17, !tbaa !24
  %t114 = getelementptr %"compiler/fmt:formatter", ptr %l5, i32 0, i32 3
  %t115 = load { i64, ptr }, ptr %t114, !tbaa !27
  store { i64, ptr } %t115, ptr %l71, !tbaa !27
  %t116 = load i64, ptr %l17, !tbaa !24
  store i64 %t116, ptr %l72, !tbaa !24
  %t117 = getelementptr %"compiler/fmt:formatter", ptr %l5, i32 0, i32 3
  %t118 = load { i64, ptr }, ptr %t117, !tbaa !27
  store { i64, ptr } %t118, ptr %l73, !tbaa !27
  %t119 = load i64, ptr %l17, !tbaa !24
  store i64 %t119, ptr %l74, !tbaa !24
  %t120 = load i64, ptr %l74, !tbaa !24
  %t121 = getelementptr { i64, ptr }, ptr %l73, i32 0, i32 1
  %t122 = load ptr, ptr %t121, !tbaa !27
  %t123 = getelementptr i64, ptr %t122, i64 %t120
  %t124 = load i64, ptr %t123, !tbaa !34
  store i64 %t124, ptr %l75, !tbaa !24
  %t125 = load i64, ptr %l75, !tbaa !24
  %t126 = add i64 %t125, 1
  store i64 %t126, ptr %l76, !tbaa !24
  %t127 = load i64, ptr %l76, !tbaa !24
  %t128 = load i64, ptr %l72, !tbaa !24
  %t129 = getelementptr { i64, ptr }, ptr %l71, i32 0, i32 1
  %t130 = load ptr, ptr %t129, !tbaa !27
  %t131 = getelementptr i64, ptr %t130, i64 %t128
  store i64 %t127, ptr %t131, !tbaa !34
  call void @__olang_scope_close(ptr %s7)
  br label %bb28
bb28:
  store %olang.scope zeroinitializer, ptr %s8
  %t132 = load i64, ptr %l16, !tbaa !24
  store i64 %t132, ptr %l77, !tbaa !24
  %t133 = load i64, ptr %l77, !tbaa !24
  %t134 = add i64 %t133, 1
  store i64 %t134, ptr %l78, !tbaa !24
  %t135 = load i64, ptr %l78, !tbaa !24
  store i64 %t135, ptr %l16, !tbaa !24
  call void @__olang_scope_close(ptr %s8)
  br label %bb24
bb29:
  %t136 = load i64, ptr %l13, !tbaa !24
  store i64 %t136, ptr %l79, !tbaa !24
  %t137 = load i64, ptr %l15, !tbaa !24
  store i64 %t137, ptr %l80, !tbaa !24
  %t138 = load i64, ptr %l79, !tbaa !24
  %t139 = load i64, ptr %l80, !tbaa !24
  %t140 = add i64 %t138, %t139
  store i64 %t140, ptr %l81, !tbaa !24
  %t141 = load i64, ptr %l81, !tbaa !24
  store i64 %t141, ptr %l13, !tbaa !24
  call void @__olang_scope_close(ptr %s6)
  br label %bb30
bb30:
  br label %bb17
bb31:
  call void @__olang_scope_close(ptr %s5)
  store %olang.scope zeroinitializer, ptr %s9
  %t142 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t142, ptr %l82, !tbaa !27
  %t143 = load { i64, ptr }, ptr %l82, !tbaa !27
  store { i64, ptr } %t143, ptr %l18, !tbaa !27
  store i64 0, ptr %l19, !tbaa !24
  %t144 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t144, ptr %l83, !tbaa !27
  %t145 = load { i64, ptr }, ptr %l83, !tbaa !27
  %t146 = extractvalue { i64, ptr } %t145, 0
  store i64 %t146, ptr %l84, !tbaa !24
  %t147 = load i64, ptr %l84, !tbaa !24
  store i64 %t147, ptr %l20, !tbaa !24
  br label %bb32
bb32:
  store %olang.scope zeroinitializer, ptr %s10
  %t148 = load i64, ptr %l19, !tbaa !24
  store i64 %t148, ptr %l85, !tbaa !24
  %t149 = load i64, ptr %l20, !tbaa !24
  store i64 %t149, ptr %l86, !tbaa !24
  %t150 = load i64, ptr %l85, !tbaa !24
  %t151 = load i64, ptr %l86, !tbaa !24
  %t152 = icmp slt i64 %t150, %t151
  store i1 %t152, ptr %l87, !tbaa !21
  %t153 = load i1, ptr %l87, !tbaa !21
  %t154 = xor i1 %t153, true
  store i1 %t154, ptr %l88, !tbaa !21
  %t155 = load i1, ptr %l88, !tbaa !21
  br i1 %t155, label %bb33, label %bb34
bb33:
  call void @__olang_scope_close(ptr %s10)
  br label %bb41
bb34:
  br label %bb35
bb35:
  %t156 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t156, ptr %l89, !tbaa !27
  %t157 = load i64, ptr %l19, !tbaa !24
  store i64 %t157, ptr %l90, !tbaa !24
  %t158 = load i64, ptr %l90, !tbaa !24
  %t159 = getelementptr { i64, ptr }, ptr %l89, i32 0, i32 1
  %t160 = load ptr, ptr %t159, !tbaa !27
  %t161 = getelementptr %"compiler/source:Span", ptr %t160, i64 %t158
  %t162 = load %"compiler/source:Span", ptr %t161
  store %"compiler/source:Span" %t162, ptr %l91
  %t163 = load %"compiler/source:Span", ptr %l91
  store %"compiler/source:Span" %t163, ptr %l21
  %t164 = getelementptr %"compiler/fmt:formatter", ptr %l5, i32 0, i32 29
  store ptr %t164, ptr %l92, !tbaa !29
  %t165 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t165, ptr %l93, !tbaa !27
  %t166 = getelementptr %"compiler/source:Span", ptr %l21, i32 0, i32 0
  %t167 = load i32, ptr %t166, !tbaa !23
  store i32 %t167, ptr %l94, !tbaa !23
  %t168 = load i32, ptr %l94, !tbaa !23
  %t169 = sext i32 %t168 to i64
  store i64 %t169, ptr %l95, !tbaa !24
  %t170 = load { i64, ptr }, ptr %l93, !tbaa !27
  %t171 = load i64, ptr %l95, !tbaa !24
  %t172 = call i64 @compiler_2ffmt_2elineStartOf(ptr %v0, { i64, ptr } %t170, i64 %t171)
  store i64 %t172, ptr %l96
  br label %bb36
bb36:
  %t173 = load ptr, ptr %l92, !tbaa !29
  %t174 = load i64, ptr %l96, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %t173, i64 %t174)
  br label %bb37
bb37:
  %t175 = getelementptr %"compiler/fmt:formatter", ptr %l5, i32 0, i32 30
  store ptr %t175, ptr %l97, !tbaa !29
  %t176 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t176, ptr %l98, !tbaa !27
  %t177 = getelementptr %"compiler/source:Span", ptr %l21, i32 0, i32 1
  %t178 = load i32, ptr %t177, !tbaa !23
  store i32 %t178, ptr %l99, !tbaa !23
  %t179 = load i32, ptr %l99, !tbaa !23
  %t180 = sext i32 %t179 to i64
  store i64 %t180, ptr %l100, !tbaa !24
  %t181 = load i64, ptr %l100, !tbaa !24
  %t182 = sub i64 %t181, 1
  store i64 %t182, ptr %l101, !tbaa !24
  %t183 = load { i64, ptr }, ptr %l98, !tbaa !27
  %t184 = load i64, ptr %l101, !tbaa !24
  %t185 = call i64 @compiler_2ffmt_2elineEndOf(ptr %v0, { i64, ptr } %t183, i64 %t184)
  store i64 %t185, ptr %l102
  br label %bb38
bb38:
  %t186 = load ptr, ptr %l97, !tbaa !29
  %t187 = load i64, ptr %l102, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %t186, i64 %t187)
  br label %bb39
bb39:
  call void @__olang_scope_close(ptr %s10)
  br label %bb40
bb40:
  store %olang.scope zeroinitializer, ptr %s11
  %t188 = load i64, ptr %l19, !tbaa !24
  store i64 %t188, ptr %l103, !tbaa !24
  %t189 = load i64, ptr %l103, !tbaa !24
  %t190 = add i64 %t189, 1
  store i64 %t190, ptr %l104, !tbaa !24
  %t191 = load i64, ptr %l104, !tbaa !24
  store i64 %t191, ptr %l19, !tbaa !24
  call void @__olang_scope_close(ptr %s11)
  br label %bb32
bb41:
  call void @__olang_scope_close(ptr %s9)
  store ptr %l5, ptr %l105, !tbaa !29
  %t192 = load ptr, ptr %l105, !tbaa !29
  call void @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2erun(ptr %s0, ptr %t192)
  br label %bb42
bb42:
  store ptr %l5, ptr %l106, !tbaa !29
  %t193 = load ptr, ptr %l106, !tbaa !29
  %t194 = call { i64, ptr } @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2ewrite(ptr %s0, ptr %v5, ptr %t193)
  store { i64, ptr } %t194, ptr %l107
  br label %bb43
bb43:
  call void @__olang_scope_close(ptr %s0)
  %t195 = load { i64, ptr }, ptr %l107, !tbaa !27
  store { i64, ptr } %t195, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"compiler/parse:Oracle" @compiler_2ffmt_2eOracleFor(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, ptr %a3) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca ptr
  %l4 = alloca %"compiler/fmt:loader"
  %l5 = alloca i64
  %lp6 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l8 = alloca %"compiler/fmt:loader"
  %l9 = alloca ptr
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca %"compiler/parse:Oracle"
  %l13 = alloca i64
  %l14 = alloca i1
  %l15 = alloca ptr
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l18 = alloca i64
  %l19 = alloca { i64, ptr }
  %l20 = alloca %"compiler/parse:Oracle"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca %"compiler/parse:Oracle"
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t1, ptr %l7, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t3 = call %"compiler/fmt:loader" @compiler_2ffmt_3aloader_2ector(ptr %v1, ptr %s0, { i64, ptr } %t2)
  store %"compiler/fmt:loader" %t3, ptr %l8
  br label %bb1
bb1:
  %t4 = load %"compiler/fmt:loader", ptr %l8
  store %"compiler/fmt:loader" %t4, ptr %l4
  store ptr %l4, ptr %l9, !tbaa !29
  %t5 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t5, ptr %l10, !tbaa !27
  %t6 = load ptr, ptr %l9, !tbaa !29
  %t7 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t8 = call i64 @compiler_2ffmt_2ecompiler_2ffmt_3aloader_2eload(ptr %s0, ptr %v0, ptr %t6, { i64, ptr } %t7)
  store i64 %t8, ptr %l11
  br label %bb2
bb2:
  %t9 = load i64, ptr %l11, !tbaa !24
  store i64 %t9, ptr %l5, !tbaa !24
  %t10 = call %"compiler/parse:Oracle" @compiler_2fparse_3aOracle_2ector(ptr %v4)
  store %"compiler/parse:Oracle" %t10, ptr %l12
  br label %bb3
bb3:
  %t11 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 16, i64 8)
  store ptr %t11, ptr %lp6
  %t12 = load %"compiler/parse:Oracle", ptr %l12
  %t13 = load ptr, ptr %lp6
  store %"compiler/parse:Oracle" %t12, ptr %t13
  %t14 = load i64, ptr %l5, !tbaa !24
  store i64 %t14, ptr %l13, !tbaa !24
  %t15 = load i64, ptr %l13, !tbaa !24
  %t16 = icmp sge i64 %t15, 0
  store i1 %t16, ptr %l14, !tbaa !21
  %t17 = load i1, ptr %l14, !tbaa !21
  br i1 %t17, label %bb4, label %bb5
bb4:
  store %olang.scope zeroinitializer, ptr %s1
  store ptr %l4, ptr %l15, !tbaa !29
  %t18 = load ptr, ptr %lp6
  store ptr %t18, ptr %l16, !tbaa !29
  %t19 = load ptr, ptr %l3, !tbaa !29
  store ptr %t19, ptr %l17, !tbaa !29
  %t20 = load i64, ptr %l5, !tbaa !24
  store i64 %t20, ptr %l18, !tbaa !24
  %t21 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t21, ptr %l19, !tbaa !27
  %t22 = load ptr, ptr %l15, !tbaa !29
  %t23 = load ptr, ptr %l16, !tbaa !29
  %t24 = load ptr, ptr %l17, !tbaa !29
  %t25 = load i64, ptr %l18, !tbaa !24
  %t26 = load { i64, ptr }, ptr %l19, !tbaa !27
  call void @compiler_2ffmt_2ecompiler_2ffmt_3aloader_2eoracle(ptr %s0, ptr %v4, ptr %v3, ptr %v2, ptr %t22, ptr %t23, ptr %t24, i64 %t25, { i64, ptr } %t26)
  br label %bb6
bb5:
  br label %bb7
bb6:
  call void @__olang_scope_close(ptr %s1)
  br label %bb7
bb7:
  %t27 = load ptr, ptr %lp6
  %t28 = load %"compiler/parse:Oracle", ptr %t27
  store %"compiler/parse:Oracle" %t28, ptr %l20
  call void @__olang_scope_close(ptr %s0)
  %t29 = load %"compiler/parse:Oracle", ptr %l20
  store %"compiler/parse:Oracle" %t29, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/parse:Oracle", ptr %rv
  ret %"compiler/parse:Oracle" %rr
}

define dso_local { i64, ptr } @compiler_2ffmt_2ePreludeTypes(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca %"compiler/fmt:loader"
  %l2 = alloca { i64, ptr }
  %l3 = alloca %"compiler/fmt:loader"
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t1, ptr %l2, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t3 = call %"compiler/fmt:loader" @compiler_2ffmt_3aloader_2ector(ptr %v0, ptr %s0, { i64, ptr } %t2)
  store %"compiler/fmt:loader" %t3, ptr %l3
  br label %bb1
bb1:
  %t4 = load %"compiler/fmt:loader", ptr %l3
  store %"compiler/fmt:loader" %t4, ptr %l1
  store ptr %l1, ptr %l4, !tbaa !29
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = call { i64, ptr } @compiler_2ffmt_2ecompiler_2ffmt_3aloader_2eprelude(ptr %s0, ptr %v1, ptr %t5)
  store { i64, ptr } %t6, ptr %l5
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  %t7 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t7, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2easWritten(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca %"compiler/token:Token"
  %l6 = alloca i8
  %l7 = alloca i1
  %l8 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/fmt:formatter", ptr %t2, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l3, !tbaa !27
  %t5 = load i64, ptr %l1, !tbaa !24
  store i64 %t5, ptr %l4, !tbaa !24
  %t6 = load i64, ptr %l4, !tbaa !24
  %t7 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t8 = load ptr, ptr %t7, !tbaa !27
  %t9 = getelementptr %"compiler/token:Token", ptr %t8, i64 %t6
  %t10 = load %"compiler/token:Token", ptr %t9
  store %"compiler/token:Token" %t10, ptr %l5
  %t11 = load i8, ptr @G_2ecompiler_2ftoken_2eSpace, !tbaa !22
  store i8 %t11, ptr %l6, !tbaa !22
  %t12 = load %"compiler/token:Token", ptr %l5
  %t13 = load i8, ptr %l6, !tbaa !22
  %t14 = call i1 @compiler_2ftoken_2ecompiler_2ftoken_3aToken_2eHas(%"compiler/token:Token" %t12, i8 %t13)
  store i1 %t14, ptr %l7
  br label %bb1
bb1:
  %t15 = load i1, ptr %l7, !tbaa !21
  br i1 %t15, label %bb2, label %bb3
bb2:
  store { i64, ptr } { i64 1, ptr @.d13 }, ptr %l8, !tbaa !27
  br label %bb4
bb3:
  store { i64, ptr } { i64 0, ptr @.d14 }, ptr %l8, !tbaa !27
  br label %bb4
bb4:
  call void @__olang_scope_close(ptr %s0)
  %t16 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t16, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2ebefore(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i1
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca { i64, ptr }
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca %"compiler/token:Token"
  %l18 = alloca i8
  %l19 = alloca i1
  %l20 = alloca i64
  %l21 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l1, !tbaa !24
  store i64 %t1, ptr %l3, !tbaa !24
  %t2 = load i64, ptr %l3, !tbaa !24
  %t3 = icmp sle i64 %t2, 0
  store i1 %t3, ptr %l4, !tbaa !21
  %t4 = load i1, ptr %l4, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  store i64 -1, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t5 = load i64, ptr %l5, !tbaa !24
  store i64 %t5, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  store ptr %t6, ptr %l6, !tbaa !29
  %t7 = load ptr, ptr %l6, !tbaa !29
  %t8 = getelementptr %"compiler/fmt:formatter", ptr %t7, i32 0, i32 4
  store ptr %t8, ptr %l7, !tbaa !29
  %t9 = load i64, ptr %l1, !tbaa !24
  store i64 %t9, ptr %l8, !tbaa !24
  %t10 = load i64, ptr %l8, !tbaa !24
  %t11 = sub i64 %t10, 1
  store i64 %t11, ptr %l9, !tbaa !24
  %t12 = load ptr, ptr %l7, !tbaa !29
  %t13 = load i64, ptr %l9, !tbaa !24
  %t14 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t12, i64 %t13)
  store i64 %t14, ptr %l10
  br label %bb4
bb4:
  %t15 = load i64, ptr %l10, !tbaa !24
  store i64 %t15, ptr %l2, !tbaa !24
  %t16 = load ptr, ptr %l0, !tbaa !29
  store ptr %t16, ptr %l11, !tbaa !29
  %t17 = load ptr, ptr %l11, !tbaa !29
  %t18 = getelementptr %"compiler/fmt:formatter", ptr %t17, i32 0, i32 1
  %t19 = load { i64, ptr }, ptr %t18, !tbaa !27
  store { i64, ptr } %t19, ptr %l12, !tbaa !27
  %t20 = load ptr, ptr %l0, !tbaa !29
  store ptr %t20, ptr %l13, !tbaa !29
  %t21 = load ptr, ptr %l13, !tbaa !29
  %t22 = getelementptr %"compiler/fmt:formatter", ptr %t21, i32 0, i32 4
  store ptr %t22, ptr %l14, !tbaa !29
  %t23 = load i64, ptr %l1, !tbaa !24
  store i64 %t23, ptr %l15, !tbaa !24
  %t24 = load ptr, ptr %l14, !tbaa !29
  %t25 = load i64, ptr %l15, !tbaa !24
  %t26 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t24, i64 %t25)
  store i64 %t26, ptr %l16
  br label %bb5
bb5:
  %t27 = load i64, ptr %l16, !tbaa !24
  %t28 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !27
  %t30 = getelementptr %"compiler/token:Token", ptr %t29, i64 %t27
  %t31 = load %"compiler/token:Token", ptr %t30
  store %"compiler/token:Token" %t31, ptr %l17
  %t32 = load i8, ptr @G_2ecompiler_2ftoken_2eLineBreak, !tbaa !22
  store i8 %t32, ptr %l18, !tbaa !22
  %t33 = load %"compiler/token:Token", ptr %l17
  %t34 = load i8, ptr %l18, !tbaa !22
  %t35 = call i1 @compiler_2ftoken_2ecompiler_2ftoken_3aToken_2eHas(%"compiler/token:Token" %t33, i8 %t34)
  store i1 %t35, ptr %l19
  br label %bb6
bb6:
  %t36 = load i1, ptr %l19, !tbaa !21
  br i1 %t36, label %bb7, label %bb8
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  store i64 -1, ptr %l20, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t37 = load i64, ptr %l20, !tbaa !24
  store i64 %t37, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t38 = load i64, ptr %l2, !tbaa !24
  store i64 %t38, ptr %l21, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  %t39 = load i64, ptr %l21, !tbaa !24
  store i64 %t39, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2ebegin(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i1
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i1
  %l7 = alloca i1
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca i1
  %l12 = alloca ptr
  %l13 = alloca i64
  %l14 = alloca i1
  %l15 = alloca ptr
  %l16 = alloca ptr
  %l17 = alloca i64
  %l18 = alloca i32
  %l19 = alloca i32
  %l20 = alloca ptr
  %l21 = alloca i32
  %l22 = alloca ptr
  %l23 = alloca i1
  %l24 = alloca i1
  %l25 = alloca i32
  %l26 = alloca ptr
  %l27 = alloca i32
  %l28 = alloca ptr
  %l29 = alloca i1
  %l30 = alloca i1
  %l31 = alloca i32
  %l32 = alloca ptr
  %l33 = alloca i32
  %l34 = alloca ptr
  %l35 = alloca i1
  %l36 = alloca i1
  %l37 = alloca ptr
  %l38 = alloca { i64, ptr }
  %l39 = alloca ptr
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i1
  %l43 = alloca i1
  %l44 = alloca ptr
  %l45 = alloca ptr
  %l46 = alloca ptr
  %l47 = alloca ptr
  %l48 = alloca ptr
  %l49 = alloca ptr
  %l50 = alloca ptr
  %l51 = alloca ptr
  %l52 = alloca ptr
  %l53 = alloca ptr
  %l54 = alloca ptr
  %l55 = alloca ptr
  %l56 = alloca ptr
  %l57 = alloca ptr
  %l58 = alloca ptr
  %l59 = alloca ptr
  %l60 = alloca ptr
  %l61 = alloca ptr
  %l62 = alloca i64
  %l63 = alloca ptr
  %l64 = alloca ptr
  %l65 = alloca ptr
  %l66 = alloca i64
  %l67 = alloca ptr
  %l68 = alloca ptr
  %l69 = alloca ptr
  %l70 = alloca ptr
  %l71 = alloca ptr
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = getelementptr %"compiler/fmt:formatter", ptr %t2, i32 0, i32 27
  %t4 = load i64, ptr %t3, !tbaa !24
  store i64 %t4, ptr %l5, !tbaa !24
  %t5 = load i64, ptr %l5, !tbaa !24
  %t6 = icmp sgt i64 %t5, 0
  store i1 %t6, ptr %l6, !tbaa !21
  %t7 = load i1, ptr %l6, !tbaa !21
  br i1 %t7, label %bb1, label %bb2
bb1:
  %t8 = load ptr, ptr %l0, !tbaa !29
  store ptr %t8, ptr %l8, !tbaa !29
  %t9 = load ptr, ptr %l8, !tbaa !29
  %t10 = getelementptr %"compiler/fmt:formatter", ptr %t9, i32 0, i32 9
  store ptr %t10, ptr %l9, !tbaa !29
  %t11 = load ptr, ptr %l9, !tbaa !29
  %t12 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t11)
  store i64 %t12, ptr %l10
  br label %bb3
bb2:
  store i1 false, ptr %l7, !tbaa !21
  br label %bb4
bb3:
  %t13 = load i64, ptr %l10, !tbaa !24
  %t14 = icmp sgt i64 %t13, 0
  store i1 %t14, ptr %l11, !tbaa !21
  %t15 = load i1, ptr %l11, !tbaa !21
  store i1 %t15, ptr %l7, !tbaa !21
  br label %bb4
bb4:
  %t16 = load i1, ptr %l7, !tbaa !21
  br i1 %t16, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  store i1 true, ptr %l2, !tbaa !21
  %t17 = load ptr, ptr %l0, !tbaa !29
  store ptr %t17, ptr %l12, !tbaa !29
  %t18 = load ptr, ptr %l12, !tbaa !29
  %t19 = getelementptr %"compiler/fmt:formatter", ptr %t18, i32 0, i32 28
  %t20 = load i64, ptr %t19, !tbaa !24
  store i64 %t20, ptr %l13, !tbaa !24
  %t21 = load i64, ptr %l13, !tbaa !24
  %t22 = icmp sge i64 %t21, 0
  store i1 %t22, ptr %l14, !tbaa !21
  %t23 = load i1, ptr %l14, !tbaa !21
  br i1 %t23, label %bb7, label %bb8
bb6:
  br label %bb36
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t24 = load ptr, ptr %l0, !tbaa !29
  store ptr %t24, ptr %l15, !tbaa !29
  %t25 = load ptr, ptr %l0, !tbaa !29
  store ptr %t25, ptr %l16, !tbaa !29
  %t26 = load ptr, ptr %l16, !tbaa !29
  %t27 = getelementptr %"compiler/fmt:formatter", ptr %t26, i32 0, i32 28
  %t28 = load i64, ptr %t27, !tbaa !24
  store i64 %t28, ptr %l17, !tbaa !24
  %t29 = load ptr, ptr %l15, !tbaa !29
  %t30 = load i64, ptr %l17, !tbaa !24
  %t31 = call i32 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2ekind(ptr %v0, ptr %t29, i64 %t30)
  store i32 %t31, ptr %l18
  br label %bb9
bb8:
  br label %bb25
bb9:
  %t32 = load i32, ptr %l18
  store i32 %t32, ptr %l3
  %t33 = load i32, ptr %l3
  store i32 %t33, ptr %l19
  store ptr %l19, ptr %l20, !tbaa !29
  store i32 94, ptr %l21
  store ptr %l21, ptr %l22, !tbaa !29
  %t34 = load ptr, ptr %l20, !tbaa !29
  %t35 = load ptr, ptr %l22, !tbaa !29
  %t36 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t34, ptr %t35)
  store i1 %t36, ptr %l23
  br label %bb10
bb10:
  %t37 = load i1, ptr %l23, !tbaa !21
  br i1 %t37, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l24, !tbaa !21
  br label %bb14
bb12:
  %t38 = load i32, ptr %l3
  store i32 %t38, ptr %l25
  store ptr %l25, ptr %l26, !tbaa !29
  store i32 90, ptr %l27
  store ptr %l27, ptr %l28, !tbaa !29
  %t39 = load ptr, ptr %l26, !tbaa !29
  %t40 = load ptr, ptr %l28, !tbaa !29
  %t41 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t39, ptr %t40)
  store i1 %t41, ptr %l29
  br label %bb13
bb13:
  %t42 = load i1, ptr %l29, !tbaa !21
  store i1 %t42, ptr %l24, !tbaa !21
  br label %bb14
bb14:
  %t43 = load i1, ptr %l24, !tbaa !21
  br i1 %t43, label %bb15, label %bb16
bb15:
  store i1 true, ptr %l30, !tbaa !21
  br label %bb18
bb16:
  %t44 = load i32, ptr %l3
  store i32 %t44, ptr %l31
  store ptr %l31, ptr %l32, !tbaa !29
  store i32 92, ptr %l33
  store ptr %l33, ptr %l34, !tbaa !29
  %t45 = load ptr, ptr %l32, !tbaa !29
  %t46 = load ptr, ptr %l34, !tbaa !29
  %t47 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t45, ptr %t46)
  store i1 %t47, ptr %l35
  br label %bb17
bb17:
  %t48 = load i1, ptr %l35, !tbaa !21
  store i1 %t48, ptr %l30, !tbaa !21
  br label %bb18
bb18:
  %t49 = load i1, ptr %l30, !tbaa !21
  br i1 %t49, label %bb19, label %bb20
bb19:
  store i1 true, ptr %l36, !tbaa !21
  br label %bb21
bb20:
  %t50 = load ptr, ptr %l0, !tbaa !29
  store ptr %t50, ptr %l37, !tbaa !29
  %t51 = load ptr, ptr %l37, !tbaa !29
  %t52 = getelementptr %"compiler/fmt:formatter", ptr %t51, i32 0, i32 2
  %t53 = load { i64, ptr }, ptr %t52, !tbaa !27
  store { i64, ptr } %t53, ptr %l38, !tbaa !27
  %t54 = load ptr, ptr %l0, !tbaa !29
  store ptr %t54, ptr %l39, !tbaa !29
  %t55 = load ptr, ptr %l39, !tbaa !29
  %t56 = getelementptr %"compiler/fmt:formatter", ptr %t55, i32 0, i32 28
  %t57 = load i64, ptr %t56, !tbaa !24
  store i64 %t57, ptr %l40, !tbaa !24
  %t58 = load i64, ptr %l40, !tbaa !24
  %t59 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !27
  %t61 = getelementptr i64, ptr %t60, i64 %t58
  %t62 = load i64, ptr %t61, !tbaa !34
  store i64 %t62, ptr %l41, !tbaa !24
  %t63 = load i64, ptr %l41, !tbaa !24
  %t64 = icmp sgt i64 %t63, 0
  store i1 %t64, ptr %l42, !tbaa !21
  %t65 = load i1, ptr %l42, !tbaa !21
  store i1 %t65, ptr %l36, !tbaa !21
  br label %bb21
bb21:
  %t66 = load i1, ptr %l36, !tbaa !21
  br i1 %t66, label %bb22, label %bb23
bb22:
  store %olang.scope zeroinitializer, ptr %s3
  store i1 false, ptr %l2, !tbaa !21
  call void @__olang_scope_close(ptr %s3)
  br label %bb24
bb23:
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s2)
  br label %bb25
bb25:
  %t67 = load i1, ptr %l2, !tbaa !21
  store i1 %t67, ptr %l43, !tbaa !21
  %t68 = load i1, ptr %l43, !tbaa !21
  br i1 %t68, label %bb26, label %bb27
bb26:
  store %olang.scope zeroinitializer, ptr %s4
  %t69 = load ptr, ptr %l0, !tbaa !29
  store ptr %t69, ptr %l44, !tbaa !29
  %t70 = load ptr, ptr %l44, !tbaa !29
  %t71 = getelementptr %"compiler/fmt:formatter", ptr %t70, i32 0, i32 9
  store ptr %t71, ptr %l45, !tbaa !29
  %t72 = load ptr, ptr %l45, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t72, i64 1)
  br label %bb28
bb27:
  br label %bb35
bb28:
  %t73 = load ptr, ptr %l0, !tbaa !29
  store ptr %t73, ptr %l46, !tbaa !29
  %t74 = load ptr, ptr %l46, !tbaa !29
  %t75 = getelementptr %"compiler/fmt:formatter", ptr %t74, i32 0, i32 10
  store ptr %t75, ptr %l47, !tbaa !29
  %t76 = load ptr, ptr %l47, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t76, i64 0)
  br label %bb29
bb29:
  %t77 = load ptr, ptr %l0, !tbaa !29
  store ptr %t77, ptr %l48, !tbaa !29
  %t78 = load ptr, ptr %l48, !tbaa !29
  %t79 = getelementptr %"compiler/fmt:formatter", ptr %t78, i32 0, i32 11
  store ptr %t79, ptr %l49, !tbaa !29
  %t80 = load ptr, ptr %l49, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t80, i64 0)
  br label %bb30
bb30:
  %t81 = load ptr, ptr %l0, !tbaa !29
  store ptr %t81, ptr %l50, !tbaa !29
  %t82 = load ptr, ptr %l50, !tbaa !29
  %t83 = getelementptr %"compiler/fmt:formatter", ptr %t82, i32 0, i32 12
  store ptr %t83, ptr %l51, !tbaa !29
  %t84 = load ptr, ptr %l51, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t84, i64 0)
  br label %bb31
bb31:
  %t85 = load ptr, ptr %l0, !tbaa !29
  store ptr %t85, ptr %l52, !tbaa !29
  %t86 = load ptr, ptr %l52, !tbaa !29
  %t87 = getelementptr %"compiler/fmt:formatter", ptr %t86, i32 0, i32 13
  store ptr %t87, ptr %l53, !tbaa !29
  %t88 = load ptr, ptr %l53, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t88, i64 -1)
  br label %bb32
bb32:
  %t89 = load ptr, ptr %l0, !tbaa !29
  store ptr %t89, ptr %l54, !tbaa !29
  %t90 = load ptr, ptr %l54, !tbaa !29
  %t91 = getelementptr %"compiler/fmt:formatter", ptr %t90, i32 0, i32 14
  store ptr %t91, ptr %l55, !tbaa !29
  %t92 = load ptr, ptr %l55, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t92, i64 -1)
  br label %bb33
bb33:
  %t93 = load ptr, ptr %l0, !tbaa !29
  store ptr %t93, ptr %l56, !tbaa !29
  %t94 = load ptr, ptr %l56, !tbaa !29
  %t95 = getelementptr %"compiler/fmt:formatter", ptr %t94, i32 0, i32 15
  store ptr %t95, ptr %l57, !tbaa !29
  %t96 = load ptr, ptr %l57, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t96, i1 false)
  br label %bb34
bb34:
  call void @__olang_scope_close(ptr %s4)
  br label %bb35
bb35:
  call void @__olang_scope_close(ptr %s1)
  br label %bb36
bb36:
  %t97 = load ptr, ptr %l0, !tbaa !29
  store ptr %t97, ptr %l58, !tbaa !29
  %t98 = load ptr, ptr %l58, !tbaa !29
  %t99 = getelementptr %"compiler/fmt:formatter", ptr %t98, i32 0, i32 27
  store i64 0, ptr %t99, !tbaa !24
  %t100 = load ptr, ptr %l0, !tbaa !29
  store ptr %t100, ptr %l59, !tbaa !29
  %t101 = load ptr, ptr %l59, !tbaa !29
  %t102 = getelementptr %"compiler/fmt:formatter", ptr %t101, i32 0, i32 17
  store i1 true, ptr %t102, !tbaa !21
  %t103 = load ptr, ptr %l0, !tbaa !29
  store ptr %t103, ptr %l60, !tbaa !29
  %t104 = load ptr, ptr %l60, !tbaa !29
  %t105 = getelementptr %"compiler/fmt:formatter", ptr %t104, i32 0, i32 31
  store i1 false, ptr %t105, !tbaa !21
  %t106 = load ptr, ptr %l0, !tbaa !29
  store ptr %t106, ptr %l61, !tbaa !29
  %t107 = load i64, ptr %l1, !tbaa !24
  store i64 %t107, ptr %l62, !tbaa !24
  %t108 = load i64, ptr %l62, !tbaa !24
  %t109 = load ptr, ptr %l61, !tbaa !29
  %t110 = getelementptr %"compiler/fmt:formatter", ptr %t109, i32 0, i32 18
  store i64 %t108, ptr %t110, !tbaa !24
  %t111 = load ptr, ptr %l0, !tbaa !29
  store ptr %t111, ptr %l63, !tbaa !29
  %t112 = load ptr, ptr %l0, !tbaa !29
  store ptr %t112, ptr %l64, !tbaa !29
  %t113 = load ptr, ptr %l64, !tbaa !29
  %t114 = getelementptr %"compiler/fmt:formatter", ptr %t113, i32 0, i32 16
  store ptr %t114, ptr %l65, !tbaa !29
  %t115 = load ptr, ptr %l65, !tbaa !29
  %t116 = call i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eLen(ptr %v0, ptr %t115)
  store i64 %t116, ptr %l66
  br label %bb37
bb37:
  %t117 = load i64, ptr %l66, !tbaa !24
  %t118 = load ptr, ptr %l63, !tbaa !29
  %t119 = getelementptr %"compiler/fmt:formatter", ptr %t118, i32 0, i32 21
  store i64 %t117, ptr %t119, !tbaa !24
  %t120 = load ptr, ptr %l0, !tbaa !29
  store ptr %t120, ptr %l67, !tbaa !29
  %t121 = load ptr, ptr %l67, !tbaa !29
  %t122 = getelementptr %"compiler/fmt:formatter", ptr %t121, i32 0, i32 22
  store i1 false, ptr %t122, !tbaa !21
  %t123 = load ptr, ptr %l0, !tbaa !29
  store ptr %t123, ptr %l68, !tbaa !29
  %t124 = load ptr, ptr %l68, !tbaa !29
  %t125 = getelementptr %"compiler/fmt:formatter", ptr %t124, i32 0, i32 25
  store i64 0, ptr %t125, !tbaa !24
  %t126 = load ptr, ptr %l0, !tbaa !29
  store ptr %t126, ptr %l69, !tbaa !29
  %t127 = load ptr, ptr %l69, !tbaa !29
  %t128 = getelementptr %"compiler/fmt:formatter", ptr %t127, i32 0, i32 26
  store i64 -1, ptr %t128, !tbaa !24
  %t129 = load ptr, ptr %l0, !tbaa !29
  store ptr %t129, ptr %l70, !tbaa !29
  %t130 = load ptr, ptr %l70, !tbaa !29
  %t131 = getelementptr %"compiler/fmt:formatter", ptr %t130, i32 0, i32 23
  store i64 -1, ptr %t131, !tbaa !24
  %t132 = load ptr, ptr %l0, !tbaa !29
  store ptr %t132, ptr %l71, !tbaa !29
  %t133 = load ptr, ptr %l71, !tbaa !29
  %t134 = getelementptr %"compiler/fmt:formatter", ptr %t133, i32 0, i32 24
  store i64 -1, ptr %t134, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2echild(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i1
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/fmt:formatter", ptr %t2, i32 0, i32 6
  store ptr %t3, ptr %l3, !tbaa !29
  %t4 = load ptr, ptr %l3, !tbaa !29
  %t5 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t4)
  store i64 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i64, ptr %l4, !tbaa !24
  store i64 %t6, ptr %l1, !tbaa !24
  %t7 = load i64, ptr %l1, !tbaa !24
  store i64 %t7, ptr %l5, !tbaa !24
  %t8 = load i64, ptr %l5, !tbaa !24
  %t9 = icmp eq i64 %t8, 0
  store i1 %t9, ptr %l6, !tbaa !21
  %t10 = load i1, ptr %l6, !tbaa !21
  br i1 %t10, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  store i64 0, ptr %l7, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t11 = load i64, ptr %l7, !tbaa !24
  store i64 %t11, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t12 = load ptr, ptr %l0, !tbaa !29
  store ptr %t12, ptr %l8, !tbaa !29
  %t13 = load ptr, ptr %l8, !tbaa !29
  %t14 = getelementptr %"compiler/fmt:formatter", ptr %t13, i32 0, i32 7
  store ptr %t14, ptr %l9, !tbaa !29
  %t15 = load i64, ptr %l1, !tbaa !24
  store i64 %t15, ptr %l10, !tbaa !24
  %t16 = load i64, ptr %l10, !tbaa !24
  %t17 = sub i64 %t16, 1
  store i64 %t17, ptr %l11, !tbaa !24
  %t18 = load ptr, ptr %l9, !tbaa !29
  %t19 = load i64, ptr %l11, !tbaa !24
  %t20 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t18, i64 %t19)
  store i64 %t20, ptr %l12
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s0)
  %t21 = load i64, ptr %l12, !tbaa !24
  store i64 %t21, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2eclosing(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i32
  %l5 = alloca i1
  %l6 = alloca i1
  %l7 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  store i64 %t2, ptr %l3, !tbaa !24
  %t3 = load ptr, ptr %l2, !tbaa !29
  %t4 = load i64, ptr %l3, !tbaa !24
  %t5 = call i32 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2ekind(ptr %v0, ptr %t3, i64 %t4)
  store i32 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i32, ptr %l4
  %t7 = call i1 @compiler_2ffmt_2eisCloser(i32 %t6)
  store i1 %t7, ptr %l5
  br label %bb2
bb2:
  %t8 = load i1, ptr %l5, !tbaa !21
  br i1 %t8, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb5
bb4:
  %t9 = load ptr, ptr %l0, !tbaa !29
  store ptr %t9, ptr %l7, !tbaa !29
  %t10 = load ptr, ptr %l7, !tbaa !29
  %t11 = getelementptr %"compiler/fmt:formatter", ptr %t10, i32 0, i32 3
  %t12 = load { i64, ptr }, ptr %t11, !tbaa !27
  store { i64, ptr } %t12, ptr %l8, !tbaa !27
  %t13 = load i64, ptr %l1, !tbaa !24
  store i64 %t13, ptr %l9, !tbaa !24
  %t14 = load i64, ptr %l9, !tbaa !24
  %t15 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !27
  %t17 = getelementptr i64, ptr %t16, i64 %t14
  %t18 = load i64, ptr %t17, !tbaa !34
  store i64 %t18, ptr %l10, !tbaa !24
  %t19 = load i64, ptr %l10, !tbaa !24
  %t20 = icmp sgt i64 %t19, 0
  store i1 %t20, ptr %l11, !tbaa !21
  %t21 = load i1, ptr %l11, !tbaa !21
  store i1 %t21, ptr %l6, !tbaa !21
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s0)
  %t22 = load i1, ptr %l6, !tbaa !21
  store i1 %t22, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2ecomment(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i1 %a3, i64 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i1
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i1
  %l12 = alloca i1
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i1
  %l16 = alloca i1
  %l17 = alloca ptr
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i8
  %l22 = alloca i1
  %l23 = alloca i1
  %l24 = alloca ptr
  %l25 = alloca { i64, ptr }
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i8
  %l29 = alloca i1
  %l30 = alloca i1
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca ptr
  %l34 = alloca i1
  %l35 = alloca i1
  %l36 = alloca ptr
  %l37 = alloca ptr
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca ptr
  %l41 = alloca i64
  %l42 = alloca ptr
  %l43 = alloca i64
  %l44 = alloca ptr
  %l45 = alloca i1
  %l46 = alloca i1
  %l47 = alloca ptr
  %l48 = alloca ptr
  %l49 = alloca i64
  %l50 = alloca i64
  %l51 = alloca ptr
  %l52 = alloca i64
  %l53 = alloca i1
  %l54 = alloca ptr
  %l55 = alloca ptr
  %l56 = alloca i64
  %l57 = alloca i64
  %l58 = alloca i64
  %l59 = alloca i64
  %l60 = alloca i1
  %l61 = alloca i64
  %l62 = alloca i64
  %l63 = alloca i1
  %l64 = alloca i64
  %l65 = alloca i64
  %l66 = alloca i64
  %l67 = alloca i64
  %l68 = alloca i64
  %l69 = alloca i64
  %l70 = alloca i64
  %l71 = alloca i64
  %l72 = alloca i64
  %l73 = alloca i64
  %l74 = alloca i64
  %l75 = alloca i1
  %l76 = alloca i1
  %l77 = alloca i64
  %l78 = alloca i64
  %l79 = alloca i64
  %l80 = alloca i64
  %l81 = alloca i64
  %l82 = alloca ptr
  %l83 = alloca { i64, ptr }
  %l84 = alloca i64
  %l85 = alloca i8
  %l86 = alloca i1
  %l87 = alloca ptr
  %l88 = alloca i64
  %l89 = alloca i64
  %l90 = alloca ptr
  %l91 = alloca ptr
  %l92 = alloca ptr
  %l93 = alloca { i64, ptr }
  %l94 = alloca i64
  %l95 = alloca i64
  %l96 = alloca i64
  %l97 = alloca i1
  %l98 = alloca i1
  %l99 = alloca i1
  %l100 = alloca { i64, ptr }
  %l101 = alloca ptr
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  store i1 %a3, ptr %l3
  store i64 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i1, ptr %l3, !tbaa !21
  store i1 %t1, ptr %l11, !tbaa !21
  %t2 = load i1, ptr %l11, !tbaa !21
  %t3 = xor i1 %t2, true
  store i1 %t3, ptr %l12, !tbaa !21
  %t4 = load i1, ptr %l12, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  br label %bb3
bb2:
  br label %bb20
bb3:
  store %olang.scope zeroinitializer, ptr %s2
  %t5 = load i64, ptr %l2, !tbaa !24
  store i64 %t5, ptr %l13, !tbaa !24
  %t6 = load i64, ptr %l1, !tbaa !24
  store i64 %t6, ptr %l14, !tbaa !24
  %t7 = load i64, ptr %l13, !tbaa !24
  %t8 = load i64, ptr %l14, !tbaa !24
  %t9 = icmp sgt i64 %t7, %t8
  store i1 %t9, ptr %l15, !tbaa !21
  %t10 = load i1, ptr %l15, !tbaa !21
  br i1 %t10, label %bb4, label %bb5
bb4:
  %t11 = load ptr, ptr %l0, !tbaa !29
  store ptr %t11, ptr %l17, !tbaa !29
  %t12 = load ptr, ptr %l17, !tbaa !29
  %t13 = getelementptr %"compiler/fmt:formatter", ptr %t12, i32 0, i32 0
  %t14 = load { i64, ptr }, ptr %t13, !tbaa !27
  store { i64, ptr } %t14, ptr %l18, !tbaa !27
  %t15 = load i64, ptr %l2, !tbaa !24
  store i64 %t15, ptr %l19, !tbaa !24
  %t16 = load i64, ptr %l19, !tbaa !24
  %t17 = sub i64 %t16, 1
  store i64 %t17, ptr %l20, !tbaa !24
  %t18 = load i64, ptr %l20, !tbaa !24
  %t19 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !27
  %t21 = getelementptr i8, ptr %t20, i64 %t18
  %t22 = load i8, ptr %t21, !tbaa !32
  store i8 %t22, ptr %l21, !tbaa !22
  %t23 = load i8, ptr %l21, !tbaa !22
  %t24 = icmp eq i8 %t23, 32
  store i1 %t24, ptr %l22, !tbaa !21
  %t25 = load i1, ptr %l22, !tbaa !21
  br i1 %t25, label %bb6, label %bb7
bb5:
  store i1 false, ptr %l16, !tbaa !21
  br label %bb9
bb6:
  store i1 true, ptr %l23, !tbaa !21
  br label %bb8
bb7:
  %t26 = load ptr, ptr %l0, !tbaa !29
  store ptr %t26, ptr %l24, !tbaa !29
  %t27 = load ptr, ptr %l24, !tbaa !29
  %t28 = getelementptr %"compiler/fmt:formatter", ptr %t27, i32 0, i32 0
  %t29 = load { i64, ptr }, ptr %t28, !tbaa !27
  store { i64, ptr } %t29, ptr %l25, !tbaa !27
  %t30 = load i64, ptr %l2, !tbaa !24
  store i64 %t30, ptr %l26, !tbaa !24
  %t31 = load i64, ptr %l26, !tbaa !24
  %t32 = sub i64 %t31, 1
  store i64 %t32, ptr %l27, !tbaa !24
  %t33 = load i64, ptr %l27, !tbaa !24
  %t34 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !27
  %t36 = getelementptr i8, ptr %t35, i64 %t33
  %t37 = load i8, ptr %t36, !tbaa !32
  store i8 %t37, ptr %l28, !tbaa !22
  %t38 = load i8, ptr %l28, !tbaa !22
  %t39 = icmp eq i8 %t38, 9
  store i1 %t39, ptr %l29, !tbaa !21
  %t40 = load i1, ptr %l29, !tbaa !21
  store i1 %t40, ptr %l23, !tbaa !21
  br label %bb8
bb8:
  %t41 = load i1, ptr %l23, !tbaa !21
  store i1 %t41, ptr %l16, !tbaa !21
  br label %bb9
bb9:
  %t42 = load i1, ptr %l16, !tbaa !21
  %t43 = xor i1 %t42, true
  store i1 %t43, ptr %l30, !tbaa !21
  %t44 = load i1, ptr %l30, !tbaa !21
  br i1 %t44, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb14
bb11:
  br label %bb12
bb12:
  %t45 = load i64, ptr %l2, !tbaa !24
  store i64 %t45, ptr %l31, !tbaa !24
  %t46 = load i64, ptr %l31, !tbaa !24
  %t47 = sub i64 %t46, 1
  store i64 %t47, ptr %l32, !tbaa !24
  %t48 = load i64, ptr %l32, !tbaa !24
  store i64 %t48, ptr %l2, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb13
bb13:
  br label %bb3
bb14:
  %t49 = load ptr, ptr %l0, !tbaa !29
  store ptr %t49, ptr %l33, !tbaa !29
  %t50 = load ptr, ptr %l33, !tbaa !29
  %t51 = getelementptr %"compiler/fmt:formatter", ptr %t50, i32 0, i32 17
  %t52 = load i1, ptr %t51, !tbaa !21
  store i1 %t52, ptr %l34, !tbaa !21
  %t53 = load i1, ptr %l34, !tbaa !21
  %t54 = xor i1 %t53, true
  store i1 %t54, ptr %l35, !tbaa !21
  %t55 = load i1, ptr %l35, !tbaa !21
  br i1 %t55, label %bb15, label %bb16
bb15:
  store %olang.scope zeroinitializer, ptr %s3
  %t56 = load ptr, ptr %l0, !tbaa !29
  store ptr %t56, ptr %l36, !tbaa !29
  %t57 = load ptr, ptr %l0, !tbaa !29
  store ptr %t57, ptr %l37, !tbaa !29
  %t58 = load i64, ptr %l4, !tbaa !24
  store i64 %t58, ptr %l38, !tbaa !24
  %t59 = load ptr, ptr %l37, !tbaa !29
  %t60 = load i64, ptr %l38, !tbaa !24
  %t61 = call i64 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2elevelAt(ptr %v0, ptr %t59, i64 %t60)
  store i64 %t61, ptr %l39
  br label %bb17
bb16:
  br label %bb19
bb17:
  %t62 = load ptr, ptr %l36, !tbaa !29
  %t63 = load i64, ptr %l39, !tbaa !24
  call void @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2ebegin(ptr %v0, ptr %t62, i64 %t63)
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s3)
  br label %bb19
bb19:
  %t64 = load ptr, ptr %l0, !tbaa !29
  store ptr %t64, ptr %l40, !tbaa !29
  %t65 = load i64, ptr %l1, !tbaa !24
  store i64 %t65, ptr %l41, !tbaa !24
  %t66 = load i64, ptr %l41, !tbaa !24
  %t67 = load ptr, ptr %l40, !tbaa !29
  %t68 = getelementptr %"compiler/fmt:formatter", ptr %t67, i32 0, i32 23
  store i64 %t66, ptr %t68, !tbaa !24
  %t69 = load ptr, ptr %l0, !tbaa !29
  store ptr %t69, ptr %l42, !tbaa !29
  %t70 = load i64, ptr %l2, !tbaa !24
  store i64 %t70, ptr %l43, !tbaa !24
  %t71 = load i64, ptr %l43, !tbaa !24
  %t72 = load ptr, ptr %l42, !tbaa !29
  %t73 = getelementptr %"compiler/fmt:formatter", ptr %t72, i32 0, i32 24
  store i64 %t71, ptr %t73, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb20:
  %t74 = load ptr, ptr %l0, !tbaa !29
  store ptr %t74, ptr %l44, !tbaa !29
  %t75 = load ptr, ptr %l44, !tbaa !29
  %t76 = getelementptr %"compiler/fmt:formatter", ptr %t75, i32 0, i32 17
  %t77 = load i1, ptr %t76, !tbaa !21
  store i1 %t77, ptr %l45, !tbaa !21
  %t78 = load i1, ptr %l45, !tbaa !21
  %t79 = xor i1 %t78, true
  store i1 %t79, ptr %l46, !tbaa !21
  %t80 = load i1, ptr %l46, !tbaa !21
  br i1 %t80, label %bb21, label %bb22
bb21:
  store %olang.scope zeroinitializer, ptr %s4
  %t81 = load ptr, ptr %l0, !tbaa !29
  store ptr %t81, ptr %l47, !tbaa !29
  %t82 = load ptr, ptr %l0, !tbaa !29
  store ptr %t82, ptr %l48, !tbaa !29
  %t83 = load i64, ptr %l4, !tbaa !24
  store i64 %t83, ptr %l49, !tbaa !24
  %t84 = load ptr, ptr %l48, !tbaa !29
  %t85 = load i64, ptr %l49, !tbaa !24
  %t86 = call i64 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2elevelAt(ptr %v0, ptr %t84, i64 %t85)
  store i64 %t86, ptr %l50
  br label %bb23
bb22:
  store %olang.scope zeroinitializer, ptr %s5
  %t87 = load ptr, ptr %l0, !tbaa !29
  store ptr %t87, ptr %l51, !tbaa !29
  %t88 = load ptr, ptr %l51, !tbaa !29
  %t89 = getelementptr %"compiler/fmt:formatter", ptr %t88, i32 0, i32 25
  %t90 = load i64, ptr %t89, !tbaa !24
  store i64 %t90, ptr %l52, !tbaa !24
  %t91 = load i64, ptr %l52, !tbaa !24
  %t92 = icmp ne i64 %t91, 0
  store i1 %t92, ptr %l53, !tbaa !21
  %t93 = load i1, ptr %l53, !tbaa !21
  br i1 %t93, label %bb25, label %bb26
bb23:
  %t94 = load ptr, ptr %l47, !tbaa !29
  %t95 = load i64, ptr %l50, !tbaa !24
  call void @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2ebegin(ptr %v0, ptr %t94, i64 %t95)
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s4)
  br label %bb29
bb25:
  store %olang.scope zeroinitializer, ptr %s6
  %t96 = load ptr, ptr %l0, !tbaa !29
  store ptr %t96, ptr %l54, !tbaa !29
  %t97 = load ptr, ptr %l54, !tbaa !29
  %t98 = getelementptr %"compiler/fmt:formatter", ptr %t97, i32 0, i32 16
  store ptr %t98, ptr %l55, !tbaa !29
  %t99 = load ptr, ptr %l55, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %t99, i8 32)
  br label %bb27
bb26:
  br label %bb28
bb27:
  call void @__olang_scope_close(ptr %s6)
  br label %bb28
bb28:
  call void @__olang_scope_close(ptr %s5)
  br label %bb29
bb29:
  store %olang.scope zeroinitializer, ptr %s7
  %t100 = load i64, ptr %l1, !tbaa !24
  store i64 %t100, ptr %l56, !tbaa !24
  %t101 = load i64, ptr %l56, !tbaa !24
  store i64 %t101, ptr %l5, !tbaa !24
  %t102 = load i64, ptr %l2, !tbaa !24
  store i64 %t102, ptr %l57, !tbaa !24
  %t103 = load i64, ptr %l57, !tbaa !24
  store i64 %t103, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t104 = load i64, ptr %l6, !tbaa !24
  store i64 %t104, ptr %l58, !tbaa !24
  %t105 = load i64, ptr %l5, !tbaa !24
  store i64 %t105, ptr %l59, !tbaa !24
  %t106 = load i64, ptr %l58, !tbaa !24
  %t107 = load i64, ptr %l59, !tbaa !24
  %t108 = icmp sgt i64 %t106, %t107
  store i1 %t108, ptr %l60, !tbaa !21
  %t109 = load i1, ptr %l60, !tbaa !21
  br i1 %t109, label %bb30, label %bb31
bb30:
  %t110 = load i64, ptr %l7, !tbaa !24
  store i64 %t110, ptr %l62, !tbaa !24
  %t111 = load i64, ptr %l62, !tbaa !24
  %t112 = icmp sgt i64 %t111, 0
  store i1 %t112, ptr %l63, !tbaa !21
  %t113 = load i1, ptr %l63, !tbaa !21
  br i1 %t113, label %bb32, label %bb33
bb31:
  store i64 0, ptr %l61, !tbaa !24
  br label %bb35
bb32:
  %t114 = load i64, ptr %l6, !tbaa !24
  store i64 %t114, ptr %l65, !tbaa !24
  %t115 = load i64, ptr %l5, !tbaa !24
  store i64 %t115, ptr %l66, !tbaa !24
  %t116 = load i64, ptr %l65, !tbaa !24
  %t117 = load i64, ptr %l66, !tbaa !24
  %t118 = sub i64 %t116, %t117
  store i64 %t118, ptr %l67, !tbaa !24
  %t119 = load i64, ptr %l7, !tbaa !24
  store i64 %t119, ptr %l68, !tbaa !24
  %t120 = load i64, ptr %l67, !tbaa !24
  %t121 = load i64, ptr %l68, !tbaa !24
  %t122 = add i64 %t120, %t121
  store i64 %t122, ptr %l69, !tbaa !24
  %t123 = load i64, ptr %l69, !tbaa !24
  %t124 = sub i64 %t123, 1
  store i64 %t124, ptr %l70, !tbaa !24
  %t125 = load i64, ptr %l7, !tbaa !24
  store i64 %t125, ptr %l71, !tbaa !24
  %t126 = load i64, ptr %l70, !tbaa !24
  %t127 = load i64, ptr %l71, !tbaa !24
  %t128 = sdiv i64 %t126, %t127
  store i64 %t128, ptr %l72, !tbaa !24
  %t129 = load i64, ptr %l72, !tbaa !24
  store i64 %t129, ptr %l64, !tbaa !24
  br label %bb34
bb33:
  store i64 0, ptr %l64, !tbaa !24
  br label %bb34
bb34:
  %t130 = load i64, ptr %l64, !tbaa !24
  store i64 %t130, ptr %l61, !tbaa !24
  br label %bb35
bb35:
  %t131 = load i64, ptr %l61, !tbaa !24
  store i64 %t131, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb36
bb36:
  store %olang.scope zeroinitializer, ptr %s8
  %t132 = load i64, ptr %l9, !tbaa !24
  store i64 %t132, ptr %l73, !tbaa !24
  %t133 = load i64, ptr %l8, !tbaa !24
  store i64 %t133, ptr %l74, !tbaa !24
  %t134 = load i64, ptr %l73, !tbaa !24
  %t135 = load i64, ptr %l74, !tbaa !24
  %t136 = icmp slt i64 %t134, %t135
  store i1 %t136, ptr %l75, !tbaa !21
  %t137 = load i1, ptr %l75, !tbaa !21
  %t138 = xor i1 %t137, true
  store i1 %t138, ptr %l76, !tbaa !21
  %t139 = load i1, ptr %l76, !tbaa !21
  br i1 %t139, label %bb37, label %bb38
bb37:
  call void @__olang_scope_close(ptr %s8)
  br label %bb44
bb38:
  br label %bb39
bb39:
  %t140 = load i64, ptr %l5, !tbaa !24
  store i64 %t140, ptr %l77, !tbaa !24
  %t141 = load i64, ptr %l9, !tbaa !24
  store i64 %t141, ptr %l78, !tbaa !24
  %t142 = load i64, ptr %l7, !tbaa !24
  store i64 %t142, ptr %l79, !tbaa !24
  %t143 = load i64, ptr %l78, !tbaa !24
  %t144 = load i64, ptr %l79, !tbaa !24
  %t145 = mul i64 %t143, %t144
  store i64 %t145, ptr %l80, !tbaa !24
  %t146 = load i64, ptr %l77, !tbaa !24
  %t147 = load i64, ptr %l80, !tbaa !24
  %t148 = add i64 %t146, %t147
  store i64 %t148, ptr %l81, !tbaa !24
  %t149 = load i64, ptr %l81, !tbaa !24
  store i64 %t149, ptr %l10, !tbaa !24
  %t150 = load ptr, ptr %l0, !tbaa !29
  store ptr %t150, ptr %l82, !tbaa !29
  %t151 = load ptr, ptr %l82, !tbaa !29
  %t152 = getelementptr %"compiler/fmt:formatter", ptr %t151, i32 0, i32 0
  %t153 = load { i64, ptr }, ptr %t152, !tbaa !27
  store { i64, ptr } %t153, ptr %l83, !tbaa !27
  %t154 = load i64, ptr %l10, !tbaa !24
  store i64 %t154, ptr %l84, !tbaa !24
  %t155 = load i64, ptr %l84, !tbaa !24
  %t156 = getelementptr { i64, ptr }, ptr %l83, i32 0, i32 1
  %t157 = load ptr, ptr %t156, !tbaa !27
  %t158 = getelementptr i8, ptr %t157, i64 %t155
  %t159 = load i8, ptr %t158, !tbaa !32
  store i8 %t159, ptr %l85, !tbaa !22
  %t160 = load i8, ptr %l85, !tbaa !22
  %t161 = icmp eq i8 %t160, 10
  store i1 %t161, ptr %l86, !tbaa !21
  %t162 = load i1, ptr %l86, !tbaa !21
  br i1 %t162, label %bb40, label %bb41
bb40:
  store %olang.scope zeroinitializer, ptr %s9
  %t163 = load ptr, ptr %l0, !tbaa !29
  store ptr %t163, ptr %l87, !tbaa !29
  %t164 = load ptr, ptr %l87, !tbaa !29
  %t165 = getelementptr %"compiler/fmt:formatter", ptr %t164, i32 0, i32 22
  store i1 true, ptr %t165, !tbaa !21
  call void @__olang_scope_close(ptr %s9)
  br label %bb42
bb41:
  br label %bb42
bb42:
  call void @__olang_scope_close(ptr %s8)
  br label %bb43
bb43:
  store %olang.scope zeroinitializer, ptr %s10
  %t166 = load i64, ptr %l9, !tbaa !24
  store i64 %t166, ptr %l88, !tbaa !24
  %t167 = load i64, ptr %l88, !tbaa !24
  %t168 = add i64 %t167, 1
  store i64 %t168, ptr %l89, !tbaa !24
  %t169 = load i64, ptr %l89, !tbaa !24
  store i64 %t169, ptr %l9, !tbaa !24
  call void @__olang_scope_close(ptr %s10)
  br label %bb36
bb44:
  call void @__olang_scope_close(ptr %s7)
  %t170 = load ptr, ptr %l0, !tbaa !29
  store ptr %t170, ptr %l90, !tbaa !29
  %t171 = load ptr, ptr %l90, !tbaa !29
  %t172 = getelementptr %"compiler/fmt:formatter", ptr %t171, i32 0, i32 16
  store ptr %t172, ptr %l91, !tbaa !29
  %t173 = load ptr, ptr %l0, !tbaa !29
  store ptr %t173, ptr %l92, !tbaa !29
  %t174 = load ptr, ptr %l92, !tbaa !29
  %t175 = getelementptr %"compiler/fmt:formatter", ptr %t174, i32 0, i32 0
  %t176 = load { i64, ptr }, ptr %t175, !tbaa !27
  store { i64, ptr } %t176, ptr %l93, !tbaa !27
  %t177 = load i64, ptr %l1, !tbaa !24
  store i64 %t177, ptr %l94, !tbaa !24
  %t178 = load i64, ptr %l2, !tbaa !24
  store i64 %t178, ptr %l95, !tbaa !24
  %t179 = load { i64, ptr }, ptr %l93, !tbaa !27
  %t180 = extractvalue { i64, ptr } %t179, 0
  store i64 %t180, ptr %l96, !tbaa !24
  %t181 = load i64, ptr %l94, !tbaa !24
  %t182 = icmp sge i64 %t181, 0
  store i1 %t182, ptr %l97, !tbaa !21
  %t183 = load i1, ptr %l97, !tbaa !21
  br i1 %t183, label %bb45, label %bb46
bb45:
  %t184 = load i64, ptr %l94, !tbaa !24
  %t185 = load i64, ptr %l95, !tbaa !24
  %t186 = icmp sle i64 %t184, %t185
  store i1 %t186, ptr %l98, !tbaa !21
  %t187 = load i1, ptr %l98, !tbaa !21
  br i1 %t187, label %bb47, label %bb48
bb46:
  call void @__olang_check_failed(ptr @.c15)
  unreachable
bb47:
  %t188 = load i64, ptr %l95, !tbaa !24
  %t189 = load i64, ptr %l96, !tbaa !24
  %t190 = icmp sle i64 %t188, %t189
  store i1 %t190, ptr %l99, !tbaa !21
  %t191 = load i1, ptr %l99, !tbaa !21
  br i1 %t191, label %bb49, label %bb50
bb48:
  call void @__olang_check_failed(ptr @.c15)
  unreachable
bb49:
  %t192 = getelementptr { i64, ptr }, ptr %l93, i32 0, i32 1
  %t193 = load ptr, ptr %t192, !tbaa !27
  %t194 = load i64, ptr %l94, !tbaa !24
  %t195 = load i64, ptr %l95, !tbaa !24
  %t196 = getelementptr i8, ptr %t193, i64 %t194
  %t197 = sub i64 %t195, %t194
  %t198 = insertvalue { i64, ptr } undef, i64 %t197, 0
  %t199 = insertvalue { i64, ptr } %t198, ptr %t196, 1
  store { i64, ptr } %t199, ptr %l100, !tbaa !27
  %t200 = load ptr, ptr %l91, !tbaa !29
  %t201 = load { i64, ptr }, ptr %l100, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v0, ptr %t200, { i64, ptr } %t201)
  br label %bb51
bb50:
  call void @__olang_check_failed(ptr @.c15)
  unreachable
bb51:
  %t202 = load ptr, ptr %l0, !tbaa !29
  store ptr %t202, ptr %l101, !tbaa !29
  %t203 = load ptr, ptr %l101, !tbaa !29
  %t204 = getelementptr %"compiler/fmt:formatter", ptr %t203, i32 0, i32 25
  store i64 2, ptr %t204, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2econt(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i1
  %l7 = alloca i1
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca i1
  %l12 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca ptr
  %l19 = alloca i64
  %l20 = alloca i32
  %l21 = alloca i32
  %l22 = alloca ptr
  %l23 = alloca i32
  %l24 = alloca ptr
  %l25 = alloca i1
  %l26 = alloca i1
  %l27 = alloca i32
  %l28 = alloca ptr
  %l29 = alloca i32
  %l30 = alloca ptr
  %l31 = alloca i1
  %l32 = alloca i1
  %l33 = alloca i32
  %l34 = alloca ptr
  %l35 = alloca i32
  %l36 = alloca ptr
  %l37 = alloca i1
  %l38 = alloca i1
  %l39 = alloca i32
  %l40 = alloca ptr
  %l41 = alloca i32
  %l42 = alloca ptr
  %l43 = alloca i1
  %l44 = alloca i64
  %l45 = alloca ptr
  %l46 = alloca { i64, ptr }
  %l47 = alloca i64
  %l48 = alloca i64
  %l49 = alloca i1
  %l50 = alloca i1
  %l51 = alloca ptr
  %l52 = alloca { i64, ptr }
  %l53 = alloca i64
  %l54 = alloca i64
  %l55 = alloca i1
  %l56 = alloca i64
  %l57 = alloca i32
  %l58 = alloca ptr
  %l59 = alloca i32
  %l60 = alloca ptr
  %l61 = alloca i1
  %l62 = alloca i1
  %l63 = alloca ptr
  %l64 = alloca { i64, ptr }
  %l65 = alloca i64
  %l66 = alloca %"compiler/token:Token"
  %l67 = alloca i8
  %l68 = alloca i1
  %l69 = alloca i1
  %l70 = alloca i64
  %l71 = alloca i32
  %l72 = alloca ptr
  %l73 = alloca i32
  %l74 = alloca ptr
  %l75 = alloca i1
  %l76 = alloca ptr
  %l77 = alloca ptr
  %l78 = alloca i64
  %l79 = alloca i64
  %l80 = alloca i1
  %l81 = alloca i1
  %l82 = alloca ptr
  %l83 = alloca ptr
  %l84 = alloca i64
  %l85 = alloca i64
  %l86 = alloca i64
  %l87 = alloca i1
  %l88 = alloca i64
  %l89 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l1, !tbaa !24
  store i64 %t1, ptr %l5, !tbaa !24
  %t2 = load i64, ptr %l5, !tbaa !24
  %t3 = icmp sle i64 %t2, 0
  store i1 %t3, ptr %l6, !tbaa !21
  %t4 = load i1, ptr %l6, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb4
bb2:
  %t5 = load ptr, ptr %l0, !tbaa !29
  store ptr %t5, ptr %l8, !tbaa !29
  %t6 = load ptr, ptr %l8, !tbaa !29
  %t7 = getelementptr %"compiler/fmt:formatter", ptr %t6, i32 0, i32 5
  store ptr %t7, ptr %l9, !tbaa !29
  %t8 = load i64, ptr %l1, !tbaa !24
  store i64 %t8, ptr %l10, !tbaa !24
  %t9 = load ptr, ptr %l9, !tbaa !29
  %t10 = load i64, ptr %l10, !tbaa !24
  %t11 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t9, i64 %t10)
  store i1 %t11, ptr %l11
  br label %bb3
bb3:
  %t12 = load i1, ptr %l11, !tbaa !21
  store i1 %t12, ptr %l7, !tbaa !21
  br label %bb4
bb4:
  %t13 = load i1, ptr %l7, !tbaa !21
  br i1 %t13, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  store i64 0, ptr %l12, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t14 = load i64, ptr %l12, !tbaa !24
  store i64 %t14, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t15 = load ptr, ptr %l0, !tbaa !29
  store ptr %t15, ptr %l13, !tbaa !29
  %t16 = load ptr, ptr %l13, !tbaa !29
  %t17 = getelementptr %"compiler/fmt:formatter", ptr %t16, i32 0, i32 4
  store ptr %t17, ptr %l14, !tbaa !29
  %t18 = load i64, ptr %l1, !tbaa !24
  store i64 %t18, ptr %l15, !tbaa !24
  %t19 = load i64, ptr %l15, !tbaa !24
  %t20 = sub i64 %t19, 1
  store i64 %t20, ptr %l16, !tbaa !24
  %t21 = load ptr, ptr %l14, !tbaa !29
  %t22 = load i64, ptr %l16, !tbaa !24
  %t23 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t21, i64 %t22)
  store i64 %t23, ptr %l17
  br label %bb8
bb8:
  %t24 = load i64, ptr %l17, !tbaa !24
  store i64 %t24, ptr %l2, !tbaa !24
  %t25 = load ptr, ptr %l0, !tbaa !29
  store ptr %t25, ptr %l18, !tbaa !29
  %t26 = load i64, ptr %l2, !tbaa !24
  store i64 %t26, ptr %l19, !tbaa !24
  %t27 = load ptr, ptr %l18, !tbaa !29
  %t28 = load i64, ptr %l19, !tbaa !24
  %t29 = call i32 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2ekind(ptr %v0, ptr %t27, i64 %t28)
  store i32 %t29, ptr %l20
  br label %bb9
bb9:
  %t30 = load i32, ptr %l20
  store i32 %t30, ptr %l3
  %t31 = load i32, ptr %l3
  store i32 %t31, ptr %l21
  store ptr %l21, ptr %l22, !tbaa !29
  store i32 94, ptr %l23
  store ptr %l23, ptr %l24, !tbaa !29
  %t32 = load ptr, ptr %l22, !tbaa !29
  %t33 = load ptr, ptr %l24, !tbaa !29
  %t34 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t32, ptr %t33)
  store i1 %t34, ptr %l25
  br label %bb10
bb10:
  %t35 = load i1, ptr %l25, !tbaa !21
  br i1 %t35, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l26, !tbaa !21
  br label %bb14
bb12:
  %t36 = load i32, ptr %l3
  store i32 %t36, ptr %l27
  store ptr %l27, ptr %l28, !tbaa !29
  store i32 90, ptr %l29
  store ptr %l29, ptr %l30, !tbaa !29
  %t37 = load ptr, ptr %l28, !tbaa !29
  %t38 = load ptr, ptr %l30, !tbaa !29
  %t39 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t37, ptr %t38)
  store i1 %t39, ptr %l31
  br label %bb13
bb13:
  %t40 = load i1, ptr %l31, !tbaa !21
  store i1 %t40, ptr %l26, !tbaa !21
  br label %bb14
bb14:
  %t41 = load i1, ptr %l26, !tbaa !21
  br i1 %t41, label %bb15, label %bb16
bb15:
  store i1 true, ptr %l32, !tbaa !21
  br label %bb18
bb16:
  %t42 = load i32, ptr %l3
  store i32 %t42, ptr %l33
  store ptr %l33, ptr %l34, !tbaa !29
  store i32 92, ptr %l35
  store ptr %l35, ptr %l36, !tbaa !29
  %t43 = load ptr, ptr %l34, !tbaa !29
  %t44 = load ptr, ptr %l36, !tbaa !29
  %t45 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t43, ptr %t44)
  store i1 %t45, ptr %l37
  br label %bb17
bb17:
  %t46 = load i1, ptr %l37, !tbaa !21
  store i1 %t46, ptr %l32, !tbaa !21
  br label %bb18
bb18:
  %t47 = load i1, ptr %l32, !tbaa !21
  br i1 %t47, label %bb19, label %bb20
bb19:
  store i1 true, ptr %l38, !tbaa !21
  br label %bb22
bb20:
  %t48 = load i32, ptr %l3
  store i32 %t48, ptr %l39
  store ptr %l39, ptr %l40, !tbaa !29
  store i32 95, ptr %l41
  store ptr %l41, ptr %l42, !tbaa !29
  %t49 = load ptr, ptr %l40, !tbaa !29
  %t50 = load ptr, ptr %l42, !tbaa !29
  %t51 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t49, ptr %t50)
  store i1 %t51, ptr %l43
  br label %bb21
bb21:
  %t52 = load i1, ptr %l43, !tbaa !21
  store i1 %t52, ptr %l38, !tbaa !21
  br label %bb22
bb22:
  %t53 = load i1, ptr %l38, !tbaa !21
  br i1 %t53, label %bb23, label %bb24
bb23:
  store %olang.scope zeroinitializer, ptr %s2
  store i64 0, ptr %l44, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t54 = load i64, ptr %l44, !tbaa !24
  store i64 %t54, ptr %rv
  br label %ret
bb24:
  br label %bb25
bb25:
  %t55 = load ptr, ptr %l0, !tbaa !29
  store ptr %t55, ptr %l45, !tbaa !29
  %t56 = load ptr, ptr %l45, !tbaa !29
  %t57 = getelementptr %"compiler/fmt:formatter", ptr %t56, i32 0, i32 2
  %t58 = load { i64, ptr }, ptr %t57, !tbaa !27
  store { i64, ptr } %t58, ptr %l46, !tbaa !27
  %t59 = load i64, ptr %l2, !tbaa !24
  store i64 %t59, ptr %l47, !tbaa !24
  %t60 = load i64, ptr %l47, !tbaa !24
  %t61 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !27
  %t63 = getelementptr i64, ptr %t62, i64 %t60
  %t64 = load i64, ptr %t63, !tbaa !34
  store i64 %t64, ptr %l48, !tbaa !24
  %t65 = load i64, ptr %l48, !tbaa !24
  %t66 = icmp sgt i64 %t65, 0
  store i1 %t66, ptr %l49, !tbaa !21
  %t67 = load i1, ptr %l49, !tbaa !21
  br i1 %t67, label %bb26, label %bb27
bb26:
  store i1 true, ptr %l50, !tbaa !21
  br label %bb28
bb27:
  %t68 = load ptr, ptr %l0, !tbaa !29
  store ptr %t68, ptr %l51, !tbaa !29
  %t69 = load ptr, ptr %l51, !tbaa !29
  %t70 = getelementptr %"compiler/fmt:formatter", ptr %t69, i32 0, i32 3
  %t71 = load { i64, ptr }, ptr %t70, !tbaa !27
  store { i64, ptr } %t71, ptr %l52, !tbaa !27
  %t72 = load i64, ptr %l2, !tbaa !24
  store i64 %t72, ptr %l53, !tbaa !24
  %t73 = load i64, ptr %l53, !tbaa !24
  %t74 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t75 = load ptr, ptr %t74, !tbaa !27
  %t76 = getelementptr i64, ptr %t75, i64 %t73
  %t77 = load i64, ptr %t76, !tbaa !34
  store i64 %t77, ptr %l54, !tbaa !24
  %t78 = load i64, ptr %l54, !tbaa !24
  %t79 = icmp sgt i64 %t78, 0
  store i1 %t79, ptr %l55, !tbaa !21
  %t80 = load i1, ptr %l55, !tbaa !21
  store i1 %t80, ptr %l50, !tbaa !21
  br label %bb28
bb28:
  %t81 = load i1, ptr %l50, !tbaa !21
  br i1 %t81, label %bb29, label %bb30
bb29:
  store %olang.scope zeroinitializer, ptr %s3
  store i64 0, ptr %l56, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t82 = load i64, ptr %l56, !tbaa !24
  store i64 %t82, ptr %rv
  br label %ret
bb30:
  br label %bb31
bb31:
  %t83 = load i32, ptr %l3
  store i32 %t83, ptr %l57
  store ptr %l57, ptr %l58, !tbaa !29
  store i32 83, ptr %l59
  store ptr %l59, ptr %l60, !tbaa !29
  %t84 = load ptr, ptr %l58, !tbaa !29
  %t85 = load ptr, ptr %l60, !tbaa !29
  %t86 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t84, ptr %t85)
  store i1 %t86, ptr %l61
  br label %bb32
bb32:
  %t87 = load i1, ptr %l61, !tbaa !21
  br i1 %t87, label %bb33, label %bb34
bb33:
  %t88 = load ptr, ptr %l0, !tbaa !29
  store ptr %t88, ptr %l63, !tbaa !29
  %t89 = load ptr, ptr %l63, !tbaa !29
  %t90 = getelementptr %"compiler/fmt:formatter", ptr %t89, i32 0, i32 1
  %t91 = load { i64, ptr }, ptr %t90, !tbaa !27
  store { i64, ptr } %t91, ptr %l64, !tbaa !27
  %t92 = load i64, ptr %l2, !tbaa !24
  store i64 %t92, ptr %l65, !tbaa !24
  %t93 = load i64, ptr %l65, !tbaa !24
  %t94 = getelementptr { i64, ptr }, ptr %l64, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !27
  %t96 = getelementptr %"compiler/token:Token", ptr %t95, i64 %t93
  %t97 = load %"compiler/token:Token", ptr %t96
  store %"compiler/token:Token" %t97, ptr %l66
  %t98 = load i8, ptr @G_2ecompiler_2ftoken_2eSpace, !tbaa !22
  store i8 %t98, ptr %l67, !tbaa !22
  %t99 = load %"compiler/token:Token", ptr %l66
  %t100 = load i8, ptr %l67, !tbaa !22
  %t101 = call i1 @compiler_2ftoken_2ecompiler_2ftoken_3aToken_2eHas(%"compiler/token:Token" %t99, i8 %t100)
  store i1 %t101, ptr %l68
  br label %bb35
bb34:
  store i1 false, ptr %l62, !tbaa !21
  br label %bb36
bb35:
  %t102 = load i1, ptr %l68, !tbaa !21
  %t103 = xor i1 %t102, true
  store i1 %t103, ptr %l69, !tbaa !21
  %t104 = load i1, ptr %l69, !tbaa !21
  store i1 %t104, ptr %l62, !tbaa !21
  br label %bb36
bb36:
  %t105 = load i1, ptr %l62, !tbaa !21
  br i1 %t105, label %bb37, label %bb38
bb37:
  store %olang.scope zeroinitializer, ptr %s4
  store i64 0, ptr %l70, !tbaa !24
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t106 = load i64, ptr %l70, !tbaa !24
  store i64 %t106, ptr %rv
  br label %ret
bb38:
  br label %bb39
bb39:
  %t107 = load i32, ptr %l3
  store i32 %t107, ptr %l71
  store ptr %l71, ptr %l72, !tbaa !29
  store i32 57, ptr %l73
  store ptr %l73, ptr %l74, !tbaa !29
  %t108 = load ptr, ptr %l72, !tbaa !29
  %t109 = load ptr, ptr %l74, !tbaa !29
  %t110 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t108, ptr %t109)
  store i1 %t110, ptr %l75
  br label %bb40
bb40:
  %t111 = load i1, ptr %l75, !tbaa !21
  br i1 %t111, label %bb41, label %bb42
bb41:
  store %olang.scope zeroinitializer, ptr %s5
  %t112 = load ptr, ptr %l0, !tbaa !29
  store ptr %t112, ptr %l76, !tbaa !29
  %t113 = load ptr, ptr %l76, !tbaa !29
  %t114 = getelementptr %"compiler/fmt:formatter", ptr %t113, i32 0, i32 6
  store ptr %t114, ptr %l77, !tbaa !29
  %t115 = load ptr, ptr %l77, !tbaa !29
  %t116 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t115)
  store i64 %t116, ptr %l78
  br label %bb43
bb42:
  br label %bb51
bb43:
  %t117 = load i64, ptr %l78, !tbaa !24
  store i64 %t117, ptr %l4, !tbaa !24
  %t118 = load i64, ptr %l4, !tbaa !24
  store i64 %t118, ptr %l79, !tbaa !24
  %t119 = load i64, ptr %l79, !tbaa !24
  %t120 = icmp sgt i64 %t119, 0
  store i1 %t120, ptr %l80, !tbaa !21
  %t121 = load i1, ptr %l80, !tbaa !21
  br i1 %t121, label %bb44, label %bb45
bb44:
  %t122 = load ptr, ptr %l0, !tbaa !29
  store ptr %t122, ptr %l82, !tbaa !29
  %t123 = load ptr, ptr %l82, !tbaa !29
  %t124 = getelementptr %"compiler/fmt:formatter", ptr %t123, i32 0, i32 6
  store ptr %t124, ptr %l83, !tbaa !29
  %t125 = load i64, ptr %l4, !tbaa !24
  store i64 %t125, ptr %l84, !tbaa !24
  %t126 = load i64, ptr %l84, !tbaa !24
  %t127 = sub i64 %t126, 1
  store i64 %t127, ptr %l85, !tbaa !24
  %t128 = load ptr, ptr %l83, !tbaa !29
  %t129 = load i64, ptr %l85, !tbaa !24
  %t130 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t128, i64 %t129)
  store i64 %t130, ptr %l86
  br label %bb46
bb45:
  store i1 false, ptr %l81, !tbaa !21
  br label %bb47
bb46:
  %t131 = load i64, ptr %l86, !tbaa !24
  %t132 = icmp eq i64 %t131, 1
  store i1 %t132, ptr %l87, !tbaa !21
  %t133 = load i1, ptr %l87, !tbaa !21
  store i1 %t133, ptr %l81, !tbaa !21
  br label %bb47
bb47:
  %t134 = load i1, ptr %l81, !tbaa !21
  br i1 %t134, label %bb48, label %bb49
bb48:
  store %olang.scope zeroinitializer, ptr %s6
  store i64 0, ptr %l88, !tbaa !24
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  %t135 = load i64, ptr %l88, !tbaa !24
  store i64 %t135, ptr %rv
  br label %ret
bb49:
  br label %bb50
bb50:
  call void @__olang_scope_close(ptr %s5)
  br label %bb51
bb51:
  store i64 1, ptr %l89, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  %t136 = load i64, ptr %l89, !tbaa !24
  store i64 %t136, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2edropBlank(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i1
  %l7 = alloca i1
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i1
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca ptr
  %l19 = alloca ptr
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca ptr
  %l23 = alloca ptr
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca ptr
  %l27 = alloca ptr
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca ptr
  %l31 = alloca ptr
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca ptr
  %l35 = alloca ptr
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca ptr
  %l39 = alloca ptr
  %l40 = alloca i64
  %l41 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/fmt:formatter", ptr %t2, i32 0, i32 9
  store ptr %t3, ptr %l3, !tbaa !29
  %t4 = load ptr, ptr %l3, !tbaa !29
  %t5 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t4)
  store i64 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i64, ptr %l4, !tbaa !24
  store i64 %t6, ptr %l1, !tbaa !24
  %t7 = load i64, ptr %l1, !tbaa !24
  store i64 %t7, ptr %l5, !tbaa !24
  %t8 = load i64, ptr %l5, !tbaa !24
  %t9 = icmp eq i64 %t8, 0
  store i1 %t9, ptr %l6, !tbaa !21
  %t10 = load i1, ptr %l6, !tbaa !21
  br i1 %t10, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb5
bb3:
  %t11 = load ptr, ptr %l0, !tbaa !29
  store ptr %t11, ptr %l8, !tbaa !29
  %t12 = load ptr, ptr %l8, !tbaa !29
  %t13 = getelementptr %"compiler/fmt:formatter", ptr %t12, i32 0, i32 9
  store ptr %t13, ptr %l9, !tbaa !29
  %t14 = load i64, ptr %l1, !tbaa !24
  store i64 %t14, ptr %l10, !tbaa !24
  %t15 = load i64, ptr %l10, !tbaa !24
  %t16 = sub i64 %t15, 1
  store i64 %t16, ptr %l11, !tbaa !24
  %t17 = load ptr, ptr %l9, !tbaa !29
  %t18 = load i64, ptr %l11, !tbaa !24
  %t19 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t17, i64 %t18)
  store i64 %t19, ptr %l12
  br label %bb4
bb4:
  %t20 = load i64, ptr %l12, !tbaa !24
  %t21 = icmp ne i64 %t20, 1
  store i1 %t21, ptr %l13, !tbaa !21
  %t22 = load i1, ptr %l13, !tbaa !21
  store i1 %t22, ptr %l7, !tbaa !21
  br label %bb5
bb5:
  %t23 = load i1, ptr %l7, !tbaa !21
  br i1 %t23, label %bb6, label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s1
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb7:
  br label %bb8
bb8:
  %t24 = load ptr, ptr %l0, !tbaa !29
  store ptr %t24, ptr %l14, !tbaa !29
  %t25 = load ptr, ptr %l14, !tbaa !29
  %t26 = getelementptr %"compiler/fmt:formatter", ptr %t25, i32 0, i32 9
  store ptr %t26, ptr %l15, !tbaa !29
  %t27 = load i64, ptr %l1, !tbaa !24
  store i64 %t27, ptr %l16, !tbaa !24
  %t28 = load i64, ptr %l16, !tbaa !24
  %t29 = sub i64 %t28, 1
  store i64 %t29, ptr %l17, !tbaa !24
  %t30 = load ptr, ptr %l15, !tbaa !29
  %t31 = load i64, ptr %l17, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eTruncate_3cI64_3e(ptr %v0, ptr %t30, i64 %t31)
  br label %bb9
bb9:
  %t32 = load ptr, ptr %l0, !tbaa !29
  store ptr %t32, ptr %l18, !tbaa !29
  %t33 = load ptr, ptr %l18, !tbaa !29
  %t34 = getelementptr %"compiler/fmt:formatter", ptr %t33, i32 0, i32 10
  store ptr %t34, ptr %l19, !tbaa !29
  %t35 = load i64, ptr %l1, !tbaa !24
  store i64 %t35, ptr %l20, !tbaa !24
  %t36 = load i64, ptr %l20, !tbaa !24
  %t37 = sub i64 %t36, 1
  store i64 %t37, ptr %l21, !tbaa !24
  %t38 = load ptr, ptr %l19, !tbaa !29
  %t39 = load i64, ptr %l21, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eTruncate_3cI64_3e(ptr %v0, ptr %t38, i64 %t39)
  br label %bb10
bb10:
  %t40 = load ptr, ptr %l0, !tbaa !29
  store ptr %t40, ptr %l22, !tbaa !29
  %t41 = load ptr, ptr %l22, !tbaa !29
  %t42 = getelementptr %"compiler/fmt:formatter", ptr %t41, i32 0, i32 11
  store ptr %t42, ptr %l23, !tbaa !29
  %t43 = load i64, ptr %l1, !tbaa !24
  store i64 %t43, ptr %l24, !tbaa !24
  %t44 = load i64, ptr %l24, !tbaa !24
  %t45 = sub i64 %t44, 1
  store i64 %t45, ptr %l25, !tbaa !24
  %t46 = load ptr, ptr %l23, !tbaa !29
  %t47 = load i64, ptr %l25, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eTruncate_3cI64_3e(ptr %v0, ptr %t46, i64 %t47)
  br label %bb11
bb11:
  %t48 = load ptr, ptr %l0, !tbaa !29
  store ptr %t48, ptr %l26, !tbaa !29
  %t49 = load ptr, ptr %l26, !tbaa !29
  %t50 = getelementptr %"compiler/fmt:formatter", ptr %t49, i32 0, i32 12
  store ptr %t50, ptr %l27, !tbaa !29
  %t51 = load i64, ptr %l1, !tbaa !24
  store i64 %t51, ptr %l28, !tbaa !24
  %t52 = load i64, ptr %l28, !tbaa !24
  %t53 = sub i64 %t52, 1
  store i64 %t53, ptr %l29, !tbaa !24
  %t54 = load ptr, ptr %l27, !tbaa !29
  %t55 = load i64, ptr %l29, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eTruncate_3cI64_3e(ptr %v0, ptr %t54, i64 %t55)
  br label %bb12
bb12:
  %t56 = load ptr, ptr %l0, !tbaa !29
  store ptr %t56, ptr %l30, !tbaa !29
  %t57 = load ptr, ptr %l30, !tbaa !29
  %t58 = getelementptr %"compiler/fmt:formatter", ptr %t57, i32 0, i32 13
  store ptr %t58, ptr %l31, !tbaa !29
  %t59 = load i64, ptr %l1, !tbaa !24
  store i64 %t59, ptr %l32, !tbaa !24
  %t60 = load i64, ptr %l32, !tbaa !24
  %t61 = sub i64 %t60, 1
  store i64 %t61, ptr %l33, !tbaa !24
  %t62 = load ptr, ptr %l31, !tbaa !29
  %t63 = load i64, ptr %l33, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eTruncate_3cI64_3e(ptr %v0, ptr %t62, i64 %t63)
  br label %bb13
bb13:
  %t64 = load ptr, ptr %l0, !tbaa !29
  store ptr %t64, ptr %l34, !tbaa !29
  %t65 = load ptr, ptr %l34, !tbaa !29
  %t66 = getelementptr %"compiler/fmt:formatter", ptr %t65, i32 0, i32 14
  store ptr %t66, ptr %l35, !tbaa !29
  %t67 = load i64, ptr %l1, !tbaa !24
  store i64 %t67, ptr %l36, !tbaa !24
  %t68 = load i64, ptr %l36, !tbaa !24
  %t69 = sub i64 %t68, 1
  store i64 %t69, ptr %l37, !tbaa !24
  %t70 = load ptr, ptr %l35, !tbaa !29
  %t71 = load i64, ptr %l37, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eTruncate_3cI64_3e(ptr %v0, ptr %t70, i64 %t71)
  br label %bb14
bb14:
  %t72 = load ptr, ptr %l0, !tbaa !29
  store ptr %t72, ptr %l38, !tbaa !29
  %t73 = load ptr, ptr %l38, !tbaa !29
  %t74 = getelementptr %"compiler/fmt:formatter", ptr %t73, i32 0, i32 15
  store ptr %t74, ptr %l39, !tbaa !29
  %t75 = load i64, ptr %l1, !tbaa !24
  store i64 %t75, ptr %l40, !tbaa !24
  %t76 = load i64, ptr %l40, !tbaa !24
  %t77 = sub i64 %t76, 1
  store i64 %t77, ptr %l41, !tbaa !24
  %t78 = load ptr, ptr %l39, !tbaa !29
  %t79 = load i64, ptr %l41, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eTruncate_3cBool_3e(ptr %v0, ptr %t78, i64 %t79)
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2efinish(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca i1
  %l15 = alloca i64
  %l16 = alloca ptr
  %l17 = alloca i64
  %l18 = alloca ptr
  %l19 = alloca ptr
  %l20 = alloca ptr
  %l21 = alloca i64
  %l22 = alloca ptr
  %l23 = alloca ptr
  %l24 = alloca ptr
  %l25 = alloca ptr
  %l26 = alloca i64
  %l27 = alloca ptr
  %l28 = alloca ptr
  %l29 = alloca ptr
  %l30 = alloca i1
  %l31 = alloca ptr
  %l32 = alloca i64
  %l33 = alloca i1
  %l34 = alloca ptr
  %l35 = alloca ptr
  %l36 = alloca i64
  %l37 = alloca ptr
  %l38 = alloca ptr
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l1, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/fmt:formatter", ptr %t2, i32 0, i32 13
  store ptr %t3, ptr %l2, !tbaa !29
  %t4 = load ptr, ptr %l0, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t6 = getelementptr %"compiler/fmt:formatter", ptr %t5, i32 0, i32 23
  %t7 = load i64, ptr %t6, !tbaa !24
  store i64 %t7, ptr %l4, !tbaa !24
  %t8 = load ptr, ptr %l2, !tbaa !29
  %t9 = load i64, ptr %l4, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t8, i64 %t9)
  br label %bb1
bb1:
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l5, !tbaa !29
  %t11 = load ptr, ptr %l5, !tbaa !29
  %t12 = getelementptr %"compiler/fmt:formatter", ptr %t11, i32 0, i32 14
  store ptr %t12, ptr %l6, !tbaa !29
  %t13 = load ptr, ptr %l0, !tbaa !29
  store ptr %t13, ptr %l7, !tbaa !29
  %t14 = load ptr, ptr %l7, !tbaa !29
  %t15 = getelementptr %"compiler/fmt:formatter", ptr %t14, i32 0, i32 24
  %t16 = load i64, ptr %t15, !tbaa !24
  store i64 %t16, ptr %l8, !tbaa !24
  %t17 = load ptr, ptr %l6, !tbaa !29
  %t18 = load i64, ptr %l8, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t17, i64 %t18)
  br label %bb2
bb2:
  %t19 = load ptr, ptr %l0, !tbaa !29
  store ptr %t19, ptr %l9, !tbaa !29
  %t20 = load ptr, ptr %l9, !tbaa !29
  %t21 = getelementptr %"compiler/fmt:formatter", ptr %t20, i32 0, i32 9
  store ptr %t21, ptr %l10, !tbaa !29
  %t22 = load ptr, ptr %l10, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t22, i64 0)
  br label %bb3
bb3:
  %t23 = load ptr, ptr %l0, !tbaa !29
  store ptr %t23, ptr %l11, !tbaa !29
  %t24 = load ptr, ptr %l11, !tbaa !29
  %t25 = getelementptr %"compiler/fmt:formatter", ptr %t24, i32 0, i32 10
  store ptr %t25, ptr %l12, !tbaa !29
  %t26 = load ptr, ptr %l0, !tbaa !29
  store ptr %t26, ptr %l13, !tbaa !29
  %t27 = load ptr, ptr %l13, !tbaa !29
  %t28 = getelementptr %"compiler/fmt:formatter", ptr %t27, i32 0, i32 31
  %t29 = load i1, ptr %t28, !tbaa !21
  store i1 %t29, ptr %l14, !tbaa !21
  %t30 = load i1, ptr %l14, !tbaa !21
  br i1 %t30, label %bb4, label %bb5
bb4:
  store i64 0, ptr %l15, !tbaa !24
  br label %bb6
bb5:
  %t31 = load ptr, ptr %l0, !tbaa !29
  store ptr %t31, ptr %l16, !tbaa !29
  %t32 = load ptr, ptr %l16, !tbaa !29
  %t33 = getelementptr %"compiler/fmt:formatter", ptr %t32, i32 0, i32 18
  %t34 = load i64, ptr %t33, !tbaa !24
  store i64 %t34, ptr %l17, !tbaa !24
  %t35 = load i64, ptr %l17, !tbaa !24
  store i64 %t35, ptr %l15, !tbaa !24
  br label %bb6
bb6:
  %t36 = load ptr, ptr %l12, !tbaa !29
  %t37 = load i64, ptr %l15, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t36, i64 %t37)
  br label %bb7
bb7:
  %t38 = load ptr, ptr %l0, !tbaa !29
  store ptr %t38, ptr %l18, !tbaa !29
  %t39 = load ptr, ptr %l18, !tbaa !29
  %t40 = getelementptr %"compiler/fmt:formatter", ptr %t39, i32 0, i32 11
  store ptr %t40, ptr %l19, !tbaa !29
  %t41 = load ptr, ptr %l0, !tbaa !29
  store ptr %t41, ptr %l20, !tbaa !29
  %t42 = load ptr, ptr %l20, !tbaa !29
  %t43 = getelementptr %"compiler/fmt:formatter", ptr %t42, i32 0, i32 21
  %t44 = load i64, ptr %t43, !tbaa !24
  store i64 %t44, ptr %l21, !tbaa !24
  %t45 = load ptr, ptr %l19, !tbaa !29
  %t46 = load i64, ptr %l21, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t45, i64 %t46)
  br label %bb8
bb8:
  %t47 = load ptr, ptr %l0, !tbaa !29
  store ptr %t47, ptr %l22, !tbaa !29
  %t48 = load ptr, ptr %l22, !tbaa !29
  %t49 = getelementptr %"compiler/fmt:formatter", ptr %t48, i32 0, i32 12
  store ptr %t49, ptr %l23, !tbaa !29
  %t50 = load ptr, ptr %l0, !tbaa !29
  store ptr %t50, ptr %l24, !tbaa !29
  %t51 = load ptr, ptr %l24, !tbaa !29
  %t52 = getelementptr %"compiler/fmt:formatter", ptr %t51, i32 0, i32 16
  store ptr %t52, ptr %l25, !tbaa !29
  %t53 = load ptr, ptr %l25, !tbaa !29
  %t54 = call i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eLen(ptr %v0, ptr %t53)
  store i64 %t54, ptr %l26
  br label %bb9
bb9:
  %t55 = load ptr, ptr %l23, !tbaa !29
  %t56 = load i64, ptr %l26, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t55, i64 %t56)
  br label %bb10
bb10:
  %t57 = load ptr, ptr %l0, !tbaa !29
  store ptr %t57, ptr %l27, !tbaa !29
  %t58 = load ptr, ptr %l27, !tbaa !29
  %t59 = getelementptr %"compiler/fmt:formatter", ptr %t58, i32 0, i32 15
  store ptr %t59, ptr %l28, !tbaa !29
  %t60 = load ptr, ptr %l0, !tbaa !29
  store ptr %t60, ptr %l29, !tbaa !29
  %t61 = load ptr, ptr %l29, !tbaa !29
  %t62 = getelementptr %"compiler/fmt:formatter", ptr %t61, i32 0, i32 22
  %t63 = load i1, ptr %t62, !tbaa !21
  store i1 %t63, ptr %l30, !tbaa !21
  %t64 = load ptr, ptr %l28, !tbaa !29
  %t65 = load i1, ptr %l30, !tbaa !21
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t64, i1 %t65)
  br label %bb11
bb11:
  %t66 = load ptr, ptr %l0, !tbaa !29
  store ptr %t66, ptr %l31, !tbaa !29
  %t67 = load ptr, ptr %l31, !tbaa !29
  %t68 = getelementptr %"compiler/fmt:formatter", ptr %t67, i32 0, i32 26
  %t69 = load i64, ptr %t68, !tbaa !24
  store i64 %t69, ptr %l32, !tbaa !24
  %t70 = load i64, ptr %l32, !tbaa !24
  %t71 = icmp sge i64 %t70, 0
  store i1 %t71, ptr %l33, !tbaa !21
  %t72 = load i1, ptr %l33, !tbaa !21
  br i1 %t72, label %bb12, label %bb13
bb12:
  store %olang.scope zeroinitializer, ptr %s1
  %t73 = load ptr, ptr %l0, !tbaa !29
  store ptr %t73, ptr %l34, !tbaa !29
  %t74 = load ptr, ptr %l0, !tbaa !29
  store ptr %t74, ptr %l35, !tbaa !29
  %t75 = load ptr, ptr %l35, !tbaa !29
  %t76 = getelementptr %"compiler/fmt:formatter", ptr %t75, i32 0, i32 26
  %t77 = load i64, ptr %t76, !tbaa !24
  store i64 %t77, ptr %l36, !tbaa !24
  %t78 = load i64, ptr %l36, !tbaa !24
  %t79 = load ptr, ptr %l34, !tbaa !29
  %t80 = getelementptr %"compiler/fmt:formatter", ptr %t79, i32 0, i32 28
  store i64 %t78, ptr %t80, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  br label %bb14
bb13:
  br label %bb14
bb14:
  %t81 = load ptr, ptr %l0, !tbaa !29
  store ptr %t81, ptr %l37, !tbaa !29
  %t82 = load ptr, ptr %l37, !tbaa !29
  %t83 = getelementptr %"compiler/fmt:formatter", ptr %t82, i32 0, i32 17
  store i1 false, ptr %t83, !tbaa !21
  %t84 = load ptr, ptr %l0, !tbaa !29
  store ptr %t84, ptr %l38, !tbaa !29
  %t85 = load ptr, ptr %l38, !tbaa !29
  %t86 = getelementptr %"compiler/fmt:formatter", ptr %t85, i32 0, i32 27
  store i64 0, ptr %t86, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2egap(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i8
  %l7 = alloca i64
  %l8 = alloca i1
  %l9 = alloca ptr
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i1
  %l15 = alloca i1
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca i8
  %l19 = alloca i8
  %l20 = alloca i1
  %l21 = alloca ptr
  %l22 = alloca i1
  %l23 = alloca ptr
  %l24 = alloca ptr
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i8
  %l30 = alloca i1
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i1
  %l36 = alloca i1
  %l37 = alloca { i64, ptr }
  %l38 = alloca i64
  %l39 = alloca i8
  %l40 = alloca i1
  %l41 = alloca i1
  %l42 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i64
  %l45 = alloca i64
  %l46 = alloca i64
  %l47 = alloca i1
  %l48 = alloca i1
  %l49 = alloca { i64, ptr }
  %l50 = alloca i64
  %l51 = alloca i8
  %l52 = alloca i1
  %l53 = alloca i1
  %l54 = alloca { i64, ptr }
  %l55 = alloca i64
  %l56 = alloca i64
  %l57 = alloca i8
  %l58 = alloca i1
  %l59 = alloca i1
  %l60 = alloca i1
  %l61 = alloca i64
  %l62 = alloca i64
  %l63 = alloca i64
  %l64 = alloca i64
  %l65 = alloca i64
  %l66 = alloca i1
  %l67 = alloca i64
  %l68 = alloca i64
  %l69 = alloca i64
  %l70 = alloca i64
  %l71 = alloca i64
  %l72 = alloca i64
  %l73 = alloca i1
  %l74 = alloca i1
  %l75 = alloca { i64, ptr }
  %l76 = alloca i64
  %l77 = alloca i8
  %l78 = alloca i1
  %l79 = alloca i1
  %l80 = alloca i64
  %l81 = alloca i64
  %l82 = alloca ptr
  %l83 = alloca i64
  %l84 = alloca i64
  %l85 = alloca i1
  %l86 = alloca i64
  %l87 = alloca i64
  %l88 = alloca i64
  %l89 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l9, !tbaa !29
  %t2 = load ptr, ptr %l9, !tbaa !29
  %t3 = getelementptr %"compiler/fmt:formatter", ptr %t2, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l10, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t5, ptr %l4, !tbaa !27
  %t6 = load i64, ptr %l1, !tbaa !24
  store i64 %t6, ptr %l11, !tbaa !24
  %t7 = load i64, ptr %l11, !tbaa !24
  store i64 %t7, ptr %l5, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t8 = load i64, ptr %l5, !tbaa !24
  store i64 %t8, ptr %l12, !tbaa !24
  %t9 = load i64, ptr %l2, !tbaa !24
  store i64 %t9, ptr %l13, !tbaa !24
  %t10 = load i64, ptr %l12, !tbaa !24
  %t11 = load i64, ptr %l13, !tbaa !24
  %t12 = icmp slt i64 %t10, %t11
  store i1 %t12, ptr %l14, !tbaa !21
  %t13 = load i1, ptr %l14, !tbaa !21
  %t14 = xor i1 %t13, true
  store i1 %t14, ptr %l15, !tbaa !21
  %t15 = load i1, ptr %l15, !tbaa !21
  br i1 %t15, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s1)
  br label %bb47
bb3:
  br label %bb4
bb4:
  %t16 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t16, ptr %l16, !tbaa !27
  %t17 = load i64, ptr %l5, !tbaa !24
  store i64 %t17, ptr %l17, !tbaa !24
  %t18 = load i64, ptr %l17, !tbaa !24
  %t19 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !27
  %t21 = getelementptr i8, ptr %t20, i64 %t18
  %t22 = load i8, ptr %t21, !tbaa !32
  store i8 %t22, ptr %l18, !tbaa !22
  %t23 = load i8, ptr %l18, !tbaa !22
  store i8 %t23, ptr %l6, !tbaa !22
  %t24 = load i8, ptr %l6, !tbaa !22
  store i8 %t24, ptr %l19, !tbaa !22
  %t25 = load i8, ptr %l19, !tbaa !22
  %t26 = icmp eq i8 %t25, 10
  store i1 %t26, ptr %l20, !tbaa !21
  %t27 = load i1, ptr %l20, !tbaa !21
  br i1 %t27, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s2
  %t28 = load ptr, ptr %l0, !tbaa !29
  store ptr %t28, ptr %l21, !tbaa !29
  %t29 = load ptr, ptr %l21, !tbaa !29
  %t30 = getelementptr %"compiler/fmt:formatter", ptr %t29, i32 0, i32 17
  %t31 = load i1, ptr %t30, !tbaa !21
  store i1 %t31, ptr %l22, !tbaa !21
  %t32 = load i1, ptr %l22, !tbaa !21
  br i1 %t32, label %bb7, label %bb8
bb6:
  store %olang.scope zeroinitializer, ptr %s5
  %t33 = load i8, ptr %l6, !tbaa !22
  store i8 %t33, ptr %l29, !tbaa !22
  %t34 = load i8, ptr %l29, !tbaa !22
  %t35 = icmp eq i8 %t34, 35
  store i1 %t35, ptr %l30, !tbaa !21
  %t36 = load i1, ptr %l30, !tbaa !21
  br i1 %t36, label %bb11, label %bb12
bb7:
  store %olang.scope zeroinitializer, ptr %s3
  %t37 = load ptr, ptr %l0, !tbaa !29
  store ptr %t37, ptr %l23, !tbaa !29
  %t38 = load ptr, ptr %l23, !tbaa !29
  call void @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2efinish(ptr %v0, ptr %t38)
  br label %bb9
bb8:
  store %olang.scope zeroinitializer, ptr %s4
  %t39 = load ptr, ptr %l0, !tbaa !29
  store ptr %t39, ptr %l24, !tbaa !29
  %t40 = load ptr, ptr %l24, !tbaa !29
  %t41 = getelementptr %"compiler/fmt:formatter", ptr %t40, i32 0, i32 27
  %t42 = load i64, ptr %t41, !tbaa !24
  store i64 %t42, ptr %l25, !tbaa !24
  %t43 = load i64, ptr %l25, !tbaa !24
  %t44 = add i64 %t43, 1
  store i64 %t44, ptr %l26, !tbaa !24
  %t45 = load i64, ptr %l26, !tbaa !24
  %t46 = load ptr, ptr %l24, !tbaa !29
  %t47 = getelementptr %"compiler/fmt:formatter", ptr %t46, i32 0, i32 27
  store i64 %t45, ptr %t47, !tbaa !24
  call void @__olang_scope_close(ptr %s4)
  br label %bb10
bb9:
  call void @__olang_scope_close(ptr %s3)
  br label %bb10
bb10:
  %t48 = load i64, ptr %l5, !tbaa !24
  store i64 %t48, ptr %l27, !tbaa !24
  %t49 = load i64, ptr %l27, !tbaa !24
  %t50 = add i64 %t49, 1
  store i64 %t50, ptr %l28, !tbaa !24
  %t51 = load i64, ptr %l28, !tbaa !24
  store i64 %t51, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb45
bb11:
  store %olang.scope zeroinitializer, ptr %s6
  %t52 = load i64, ptr %l5, !tbaa !24
  store i64 %t52, ptr %l31, !tbaa !24
  %t53 = load i64, ptr %l31, !tbaa !24
  %t54 = add i64 %t53, 1
  store i64 %t54, ptr %l32, !tbaa !24
  %t55 = load i64, ptr %l32, !tbaa !24
  store i64 %t55, ptr %l7, !tbaa !24
  %t56 = load i64, ptr %l7, !tbaa !24
  store i64 %t56, ptr %l33, !tbaa !24
  %t57 = load i64, ptr %l2, !tbaa !24
  store i64 %t57, ptr %l34, !tbaa !24
  %t58 = load i64, ptr %l33, !tbaa !24
  %t59 = load i64, ptr %l34, !tbaa !24
  %t60 = icmp slt i64 %t58, %t59
  store i1 %t60, ptr %l35, !tbaa !21
  %t61 = load i1, ptr %l35, !tbaa !21
  br i1 %t61, label %bb13, label %bb14
bb12:
  store %olang.scope zeroinitializer, ptr %s11
  %t62 = load i64, ptr %l5, !tbaa !24
  store i64 %t62, ptr %l88, !tbaa !24
  %t63 = load i64, ptr %l88, !tbaa !24
  %t64 = add i64 %t63, 1
  store i64 %t64, ptr %l89, !tbaa !24
  %t65 = load i64, ptr %l89, !tbaa !24
  store i64 %t65, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s11)
  br label %bb44
bb13:
  %t66 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t66, ptr %l37, !tbaa !27
  %t67 = load i64, ptr %l7, !tbaa !24
  store i64 %t67, ptr %l38, !tbaa !24
  %t68 = load i64, ptr %l38, !tbaa !24
  %t69 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !27
  %t71 = getelementptr i8, ptr %t70, i64 %t68
  %t72 = load i8, ptr %t71, !tbaa !32
  store i8 %t72, ptr %l39, !tbaa !22
  %t73 = load i8, ptr %l39, !tbaa !22
  %t74 = icmp eq i8 %t73, 35
  store i1 %t74, ptr %l40, !tbaa !21
  %t75 = load i1, ptr %l40, !tbaa !21
  store i1 %t75, ptr %l36, !tbaa !21
  br label %bb15
bb14:
  store i1 false, ptr %l36, !tbaa !21
  br label %bb15
bb15:
  %t76 = load i1, ptr %l36, !tbaa !21
  store i1 %t76, ptr %l8, !tbaa !21
  %t77 = load i1, ptr %l8, !tbaa !21
  store i1 %t77, ptr %l41, !tbaa !21
  %t78 = load i1, ptr %l41, !tbaa !21
  br i1 %t78, label %bb16, label %bb17
bb16:
  store %olang.scope zeroinitializer, ptr %s7
  %t79 = load i64, ptr %l7, !tbaa !24
  store i64 %t79, ptr %l42, !tbaa !24
  %t80 = load i64, ptr %l42, !tbaa !24
  %t81 = add i64 %t80, 1
  store i64 %t81, ptr %l43, !tbaa !24
  %t82 = load i64, ptr %l43, !tbaa !24
  store i64 %t82, ptr %l7, !tbaa !24
  br label %bb18
bb17:
  store %olang.scope zeroinitializer, ptr %s9
  br label %bb33
bb18:
  store %olang.scope zeroinitializer, ptr %s8
  %t83 = load i64, ptr %l7, !tbaa !24
  store i64 %t83, ptr %l44, !tbaa !24
  %t84 = load i64, ptr %l44, !tbaa !24
  %t85 = add i64 %t84, 1
  store i64 %t85, ptr %l45, !tbaa !24
  %t86 = load i64, ptr %l2, !tbaa !24
  store i64 %t86, ptr %l46, !tbaa !24
  %t87 = load i64, ptr %l45, !tbaa !24
  %t88 = load i64, ptr %l46, !tbaa !24
  %t89 = icmp slt i64 %t87, %t88
  store i1 %t89, ptr %l47, !tbaa !21
  %t90 = load i1, ptr %l47, !tbaa !21
  br i1 %t90, label %bb19, label %bb20
bb19:
  %t91 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t91, ptr %l49, !tbaa !27
  %t92 = load i64, ptr %l7, !tbaa !24
  store i64 %t92, ptr %l50, !tbaa !24
  %t93 = load i64, ptr %l50, !tbaa !24
  %t94 = getelementptr { i64, ptr }, ptr %l49, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !27
  %t96 = getelementptr i8, ptr %t95, i64 %t93
  %t97 = load i8, ptr %t96, !tbaa !32
  store i8 %t97, ptr %l51, !tbaa !22
  %t98 = load i8, ptr %l51, !tbaa !22
  %t99 = icmp eq i8 %t98, 35
  store i1 %t99, ptr %l52, !tbaa !21
  %t100 = load i1, ptr %l52, !tbaa !21
  br i1 %t100, label %bb21, label %bb22
bb20:
  store i1 false, ptr %l48, !tbaa !21
  br label %bb24
bb21:
  %t101 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t101, ptr %l54, !tbaa !27
  %t102 = load i64, ptr %l7, !tbaa !24
  store i64 %t102, ptr %l55, !tbaa !24
  %t103 = load i64, ptr %l55, !tbaa !24
  %t104 = add i64 %t103, 1
  store i64 %t104, ptr %l56, !tbaa !24
  %t105 = load i64, ptr %l56, !tbaa !24
  %t106 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t107 = load ptr, ptr %t106, !tbaa !27
  %t108 = getelementptr i8, ptr %t107, i64 %t105
  %t109 = load i8, ptr %t108, !tbaa !32
  store i8 %t109, ptr %l57, !tbaa !22
  %t110 = load i8, ptr %l57, !tbaa !22
  %t111 = icmp eq i8 %t110, 35
  store i1 %t111, ptr %l58, !tbaa !21
  %t112 = load i1, ptr %l58, !tbaa !21
  store i1 %t112, ptr %l53, !tbaa !21
  br label %bb23
bb22:
  store i1 false, ptr %l53, !tbaa !21
  br label %bb23
bb23:
  %t113 = load i1, ptr %l53, !tbaa !21
  %t114 = xor i1 %t113, true
  store i1 %t114, ptr %l59, !tbaa !21
  %t115 = load i1, ptr %l59, !tbaa !21
  store i1 %t115, ptr %l48, !tbaa !21
  br label %bb24
bb24:
  %t116 = load i1, ptr %l48, !tbaa !21
  %t117 = xor i1 %t116, true
  store i1 %t117, ptr %l60, !tbaa !21
  %t118 = load i1, ptr %l60, !tbaa !21
  br i1 %t118, label %bb25, label %bb26
bb25:
  call void @__olang_scope_close(ptr %s8)
  br label %bb29
bb26:
  br label %bb27
bb27:
  %t119 = load i64, ptr %l7, !tbaa !24
  store i64 %t119, ptr %l61, !tbaa !24
  %t120 = load i64, ptr %l61, !tbaa !24
  %t121 = add i64 %t120, 1
  store i64 %t121, ptr %l62, !tbaa !24
  %t122 = load i64, ptr %l62, !tbaa !24
  store i64 %t122, ptr %l7, !tbaa !24
  call void @__olang_scope_close(ptr %s8)
  br label %bb28
bb28:
  br label %bb18
bb29:
  %t123 = load i64, ptr %l7, !tbaa !24
  store i64 %t123, ptr %l63, !tbaa !24
  %t124 = load i64, ptr %l63, !tbaa !24
  %t125 = add i64 %t124, 1
  store i64 %t125, ptr %l64, !tbaa !24
  %t126 = load i64, ptr %l2, !tbaa !24
  store i64 %t126, ptr %l65, !tbaa !24
  %t127 = load i64, ptr %l64, !tbaa !24
  %t128 = load i64, ptr %l65, !tbaa !24
  %t129 = icmp slt i64 %t127, %t128
  store i1 %t129, ptr %l66, !tbaa !21
  %t130 = load i1, ptr %l66, !tbaa !21
  br i1 %t130, label %bb30, label %bb31
bb30:
  %t131 = load i64, ptr %l7, !tbaa !24
  store i64 %t131, ptr %l68, !tbaa !24
  %t132 = load i64, ptr %l68, !tbaa !24
  %t133 = add i64 %t132, 2
  store i64 %t133, ptr %l69, !tbaa !24
  %t134 = load i64, ptr %l69, !tbaa !24
  store i64 %t134, ptr %l67, !tbaa !24
  br label %bb32
bb31:
  %t135 = load i64, ptr %l2, !tbaa !24
  store i64 %t135, ptr %l70, !tbaa !24
  %t136 = load i64, ptr %l70, !tbaa !24
  store i64 %t136, ptr %l67, !tbaa !24
  br label %bb32
bb32:
  %t137 = load i64, ptr %l67, !tbaa !24
  store i64 %t137, ptr %l7, !tbaa !24
  call void @__olang_scope_close(ptr %s7)
  br label %bb42
bb33:
  store %olang.scope zeroinitializer, ptr %s10
  %t138 = load i64, ptr %l7, !tbaa !24
  store i64 %t138, ptr %l71, !tbaa !24
  %t139 = load i64, ptr %l2, !tbaa !24
  store i64 %t139, ptr %l72, !tbaa !24
  %t140 = load i64, ptr %l71, !tbaa !24
  %t141 = load i64, ptr %l72, !tbaa !24
  %t142 = icmp slt i64 %t140, %t141
  store i1 %t142, ptr %l73, !tbaa !21
  %t143 = load i1, ptr %l73, !tbaa !21
  br i1 %t143, label %bb34, label %bb35
bb34:
  %t144 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t144, ptr %l75, !tbaa !27
  %t145 = load i64, ptr %l7, !tbaa !24
  store i64 %t145, ptr %l76, !tbaa !24
  %t146 = load i64, ptr %l76, !tbaa !24
  %t147 = getelementptr { i64, ptr }, ptr %l75, i32 0, i32 1
  %t148 = load ptr, ptr %t147, !tbaa !27
  %t149 = getelementptr i8, ptr %t148, i64 %t146
  %t150 = load i8, ptr %t149, !tbaa !32
  store i8 %t150, ptr %l77, !tbaa !22
  %t151 = load i8, ptr %l77, !tbaa !22
  %t152 = icmp ne i8 %t151, 10
  store i1 %t152, ptr %l78, !tbaa !21
  %t153 = load i1, ptr %l78, !tbaa !21
  store i1 %t153, ptr %l74, !tbaa !21
  br label %bb36
bb35:
  store i1 false, ptr %l74, !tbaa !21
  br label %bb36
bb36:
  %t154 = load i1, ptr %l74, !tbaa !21
  %t155 = xor i1 %t154, true
  store i1 %t155, ptr %l79, !tbaa !21
  %t156 = load i1, ptr %l79, !tbaa !21
  br i1 %t156, label %bb37, label %bb38
bb37:
  call void @__olang_scope_close(ptr %s10)
  br label %bb41
bb38:
  br label %bb39
bb39:
  %t157 = load i64, ptr %l7, !tbaa !24
  store i64 %t157, ptr %l80, !tbaa !24
  %t158 = load i64, ptr %l80, !tbaa !24
  %t159 = add i64 %t158, 1
  store i64 %t159, ptr %l81, !tbaa !24
  %t160 = load i64, ptr %l81, !tbaa !24
  store i64 %t160, ptr %l7, !tbaa !24
  call void @__olang_scope_close(ptr %s10)
  br label %bb40
bb40:
  br label %bb33
bb41:
  call void @__olang_scope_close(ptr %s9)
  br label %bb42
bb42:
  %t161 = load ptr, ptr %l0, !tbaa !29
  store ptr %t161, ptr %l82, !tbaa !29
  %t162 = load i64, ptr %l5, !tbaa !24
  store i64 %t162, ptr %l83, !tbaa !24
  %t163 = load i64, ptr %l7, !tbaa !24
  store i64 %t163, ptr %l84, !tbaa !24
  %t164 = load i1, ptr %l8, !tbaa !21
  store i1 %t164, ptr %l85, !tbaa !21
  %t165 = load i64, ptr %l3, !tbaa !24
  store i64 %t165, ptr %l86, !tbaa !24
  %t166 = load ptr, ptr %l82, !tbaa !29
  %t167 = load i64, ptr %l83, !tbaa !24
  %t168 = load i64, ptr %l84, !tbaa !24
  %t169 = load i1, ptr %l85, !tbaa !21
  %t170 = load i64, ptr %l86, !tbaa !24
  call void @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2ecomment(ptr %v0, ptr %t166, i64 %t167, i64 %t168, i1 %t169, i64 %t170)
  br label %bb43
bb43:
  %t171 = load i64, ptr %l7, !tbaa !24
  store i64 %t171, ptr %l87, !tbaa !24
  %t172 = load i64, ptr %l87, !tbaa !24
  store i64 %t172, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s6)
  br label %bb44
bb44:
  call void @__olang_scope_close(ptr %s5)
  br label %bb45
bb45:
  call void @__olang_scope_close(ptr %s1)
  br label %bb46
bb46:
  br label %bb1
bb47:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2eheldAt(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i1
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i1
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i1
  %l29 = alloca i1
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca ptr
  %l36 = alloca ptr
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i1
  %l41 = alloca i1
  %l42 = alloca i64
  %l43 = alloca ptr
  %l44 = alloca ptr
  %l45 = alloca i64
  %l46 = alloca i64
  %l47 = alloca i1
  %l48 = alloca i64
  %l49 = alloca i64
  %l50 = alloca i64
  %l51 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store %olang.scope zeroinitializer, ptr %s1
  store i64 0, ptr %l2, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l8, !tbaa !29
  %t2 = load ptr, ptr %l8, !tbaa !29
  %t3 = getelementptr %"compiler/fmt:formatter", ptr %t2, i32 0, i32 29
  store ptr %t3, ptr %l9, !tbaa !29
  %t4 = load ptr, ptr %l9, !tbaa !29
  %t5 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t4)
  store i64 %t5, ptr %l10
  br label %bb1
bb1:
  %t6 = load i64, ptr %l10, !tbaa !24
  store i64 %t6, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  store i64 %t7, ptr %l11, !tbaa !24
  %t8 = load i64, ptr %l2, !tbaa !24
  store i64 %t8, ptr %l12, !tbaa !24
  %t9 = load i64, ptr %l11, !tbaa !24
  %t10 = load i64, ptr %l12, !tbaa !24
  %t11 = icmp sgt i64 %t9, %t10
  store i1 %t11, ptr %l13, !tbaa !21
  %t12 = load i1, ptr %l13, !tbaa !21
  br i1 %t12, label %bb2, label %bb3
bb2:
  %t13 = load i64, ptr %l4, !tbaa !24
  store i64 %t13, ptr %l15, !tbaa !24
  %t14 = load i64, ptr %l15, !tbaa !24
  %t15 = icmp sgt i64 %t14, 0
  store i1 %t15, ptr %l16, !tbaa !21
  %t16 = load i1, ptr %l16, !tbaa !21
  br i1 %t16, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l14, !tbaa !24
  br label %bb7
bb4:
  %t17 = load i64, ptr %l3, !tbaa !24
  store i64 %t17, ptr %l18, !tbaa !24
  %t18 = load i64, ptr %l2, !tbaa !24
  store i64 %t18, ptr %l19, !tbaa !24
  %t19 = load i64, ptr %l18, !tbaa !24
  %t20 = load i64, ptr %l19, !tbaa !24
  %t21 = sub i64 %t19, %t20
  store i64 %t21, ptr %l20, !tbaa !24
  %t22 = load i64, ptr %l4, !tbaa !24
  store i64 %t22, ptr %l21, !tbaa !24
  %t23 = load i64, ptr %l20, !tbaa !24
  %t24 = load i64, ptr %l21, !tbaa !24
  %t25 = add i64 %t23, %t24
  store i64 %t25, ptr %l22, !tbaa !24
  %t26 = load i64, ptr %l22, !tbaa !24
  %t27 = sub i64 %t26, 1
  store i64 %t27, ptr %l23, !tbaa !24
  %t28 = load i64, ptr %l4, !tbaa !24
  store i64 %t28, ptr %l24, !tbaa !24
  %t29 = load i64, ptr %l23, !tbaa !24
  %t30 = load i64, ptr %l24, !tbaa !24
  %t31 = sdiv i64 %t29, %t30
  store i64 %t31, ptr %l25, !tbaa !24
  %t32 = load i64, ptr %l25, !tbaa !24
  store i64 %t32, ptr %l17, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l17, !tbaa !24
  br label %bb6
bb6:
  %t33 = load i64, ptr %l17, !tbaa !24
  store i64 %t33, ptr %l14, !tbaa !24
  br label %bb7
bb7:
  %t34 = load i64, ptr %l14, !tbaa !24
  store i64 %t34, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t35 = load i64, ptr %l6, !tbaa !24
  store i64 %t35, ptr %l26, !tbaa !24
  %t36 = load i64, ptr %l5, !tbaa !24
  store i64 %t36, ptr %l27, !tbaa !24
  %t37 = load i64, ptr %l26, !tbaa !24
  %t38 = load i64, ptr %l27, !tbaa !24
  %t39 = icmp slt i64 %t37, %t38
  store i1 %t39, ptr %l28, !tbaa !21
  %t40 = load i1, ptr %l28, !tbaa !21
  %t41 = xor i1 %t40, true
  store i1 %t41, ptr %l29, !tbaa !21
  %t42 = load i1, ptr %l29, !tbaa !21
  br i1 %t42, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb21
bb10:
  br label %bb11
bb11:
  %t43 = load i64, ptr %l2, !tbaa !24
  store i64 %t43, ptr %l30, !tbaa !24
  %t44 = load i64, ptr %l6, !tbaa !24
  store i64 %t44, ptr %l31, !tbaa !24
  %t45 = load i64, ptr %l4, !tbaa !24
  store i64 %t45, ptr %l32, !tbaa !24
  %t46 = load i64, ptr %l31, !tbaa !24
  %t47 = load i64, ptr %l32, !tbaa !24
  %t48 = mul i64 %t46, %t47
  store i64 %t48, ptr %l33, !tbaa !24
  %t49 = load i64, ptr %l30, !tbaa !24
  %t50 = load i64, ptr %l33, !tbaa !24
  %t51 = add i64 %t49, %t50
  store i64 %t51, ptr %l34, !tbaa !24
  %t52 = load i64, ptr %l34, !tbaa !24
  store i64 %t52, ptr %l7, !tbaa !24
  %t53 = load ptr, ptr %l0, !tbaa !29
  store ptr %t53, ptr %l35, !tbaa !29
  %t54 = load ptr, ptr %l35, !tbaa !29
  %t55 = getelementptr %"compiler/fmt:formatter", ptr %t54, i32 0, i32 29
  store ptr %t55, ptr %l36, !tbaa !29
  %t56 = load i64, ptr %l7, !tbaa !24
  store i64 %t56, ptr %l37, !tbaa !24
  %t57 = load ptr, ptr %l36, !tbaa !29
  %t58 = load i64, ptr %l37, !tbaa !24
  %t59 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t57, i64 %t58)
  store i64 %t59, ptr %l38
  br label %bb12
bb12:
  %t60 = load i64, ptr %l1, !tbaa !24
  store i64 %t60, ptr %l39, !tbaa !24
  %t61 = load i64, ptr %l38, !tbaa !24
  %t62 = load i64, ptr %l39, !tbaa !24
  %t63 = icmp sle i64 %t61, %t62
  store i1 %t63, ptr %l40, !tbaa !21
  %t64 = load i1, ptr %l40, !tbaa !21
  br i1 %t64, label %bb13, label %bb14
bb13:
  %t65 = load i64, ptr %l1, !tbaa !24
  store i64 %t65, ptr %l42, !tbaa !24
  %t66 = load ptr, ptr %l0, !tbaa !29
  store ptr %t66, ptr %l43, !tbaa !29
  %t67 = load ptr, ptr %l43, !tbaa !29
  %t68 = getelementptr %"compiler/fmt:formatter", ptr %t67, i32 0, i32 30
  store ptr %t68, ptr %l44, !tbaa !29
  %t69 = load i64, ptr %l7, !tbaa !24
  store i64 %t69, ptr %l45, !tbaa !24
  %t70 = load ptr, ptr %l44, !tbaa !29
  %t71 = load i64, ptr %l45, !tbaa !24
  %t72 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t70, i64 %t71)
  store i64 %t72, ptr %l46
  br label %bb15
bb14:
  store i1 false, ptr %l41, !tbaa !21
  br label %bb16
bb15:
  %t73 = load i64, ptr %l42, !tbaa !24
  %t74 = load i64, ptr %l46, !tbaa !24
  %t75 = icmp sle i64 %t73, %t74
  store i1 %t75, ptr %l47, !tbaa !21
  %t76 = load i1, ptr %l47, !tbaa !21
  store i1 %t76, ptr %l41, !tbaa !21
  br label %bb16
bb16:
  %t77 = load i1, ptr %l41, !tbaa !21
  br i1 %t77, label %bb17, label %bb18
bb17:
  store %olang.scope zeroinitializer, ptr %s3
  %t78 = load i64, ptr %l7, !tbaa !24
  store i64 %t78, ptr %l48, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t79 = load i64, ptr %l48, !tbaa !24
  store i64 %t79, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s2)
  br label %bb20
bb20:
  store %olang.scope zeroinitializer, ptr %s4
  %t80 = load i64, ptr %l6, !tbaa !24
  store i64 %t80, ptr %l49, !tbaa !24
  %t81 = load i64, ptr %l49, !tbaa !24
  %t82 = add i64 %t81, 1
  store i64 %t82, ptr %l50, !tbaa !24
  %t83 = load i64, ptr %l50, !tbaa !24
  store i64 %t83, ptr %l6, !tbaa !24
  call void @__olang_scope_close(ptr %s4)
  br label %bb8
bb21:
  call void @__olang_scope_close(ptr %s1)
  store i64 -1, ptr %l51, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  %t84 = load i64, ptr %l51, !tbaa !24
  store i64 %t84, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2ekeyword(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l3 = alloca i8
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca ptr
  %l9 = alloca i32
  %l10 = alloca ptr
  %l11 = alloca i1
  %l12 = alloca i1
  %l13 = alloca i32
  %l14 = alloca ptr
  %l15 = alloca i32
  %l16 = alloca ptr
  %l17 = alloca i1
  %l18 = alloca i1
  %l19 = alloca i32
  %l20 = alloca ptr
  %l21 = alloca i32
  %l22 = alloca ptr
  %l23 = alloca i1
  %l24 = alloca i1
  %l25 = alloca ptr
  %l26 = alloca { i64, ptr }
  %l27 = alloca ptr
  %l28 = alloca { i64, ptr }
  %l29 = alloca i64
  %l30 = alloca i32
  %l31 = alloca i8
  %l32 = alloca i8
  %l33 = alloca i1
  %l34 = alloca i1
  %l35 = alloca i8
  %l36 = alloca i1
  %l37 = alloca i1
  %l38 = alloca i8
  %l39 = alloca i1
  %l40 = alloca i1
  %l41 = alloca i8
  %l42 = alloca i1
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  store i64 %t2, ptr %l5, !tbaa !24
  %t3 = load ptr, ptr %l4, !tbaa !29
  %t4 = load i64, ptr %l5, !tbaa !24
  %t5 = call i32 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2ekind(ptr %v0, ptr %t3, i64 %t4)
  store i32 %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load i32, ptr %l6
  store i32 %t6, ptr %l2
  %t7 = load i32, ptr %l2
  store i32 %t7, ptr %l7
  store ptr %l7, ptr %l8, !tbaa !29
  store i32 1, ptr %l9
  store ptr %l9, ptr %l10, !tbaa !29
  %t8 = load ptr, ptr %l8, !tbaa !29
  %t9 = load ptr, ptr %l10, !tbaa !29
  %t10 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t8, ptr %t9)
  store i1 %t10, ptr %l11
  br label %bb2
bb2:
  %t11 = load i1, ptr %l11, !tbaa !21
  br i1 %t11, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb6
bb4:
  %t12 = load i32, ptr %l2
  store i32 %t12, ptr %l13
  store ptr %l13, ptr %l14, !tbaa !29
  store i32 6, ptr %l15
  store ptr %l15, ptr %l16, !tbaa !29
  %t13 = load ptr, ptr %l14, !tbaa !29
  %t14 = load ptr, ptr %l16, !tbaa !29
  %t15 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t13, ptr %t14)
  store i1 %t15, ptr %l17
  br label %bb5
bb5:
  %t16 = load i1, ptr %l17, !tbaa !21
  store i1 %t16, ptr %l12, !tbaa !21
  br label %bb6
bb6:
  %t17 = load i1, ptr %l12, !tbaa !21
  br i1 %t17, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l18, !tbaa !21
  br label %bb10
bb8:
  %t18 = load i32, ptr %l2
  store i32 %t18, ptr %l19
  store ptr %l19, ptr %l20, !tbaa !29
  store i32 7, ptr %l21
  store ptr %l21, ptr %l22, !tbaa !29
  %t19 = load ptr, ptr %l20, !tbaa !29
  %t20 = load ptr, ptr %l22, !tbaa !29
  %t21 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t19, ptr %t20)
  store i1 %t21, ptr %l23
  br label %bb9
bb9:
  %t22 = load i1, ptr %l23, !tbaa !21
  store i1 %t22, ptr %l18, !tbaa !21
  br label %bb10
bb10:
  %t23 = load i1, ptr %l18, !tbaa !21
  br i1 %t23, label %bb11, label %bb12
bb11:
  store %olang.scope zeroinitializer, ptr %s1
  store i1 false, ptr %l24, !tbaa !21
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t24 = load i1, ptr %l24, !tbaa !21
  store i1 %t24, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  %t25 = load ptr, ptr %l0, !tbaa !29
  store ptr %t25, ptr %l25, !tbaa !29
  %t26 = load ptr, ptr %l25, !tbaa !29
  %t27 = getelementptr %"compiler/fmt:formatter", ptr %t26, i32 0, i32 0
  %t28 = load { i64, ptr }, ptr %t27, !tbaa !27
  store { i64, ptr } %t28, ptr %l26, !tbaa !27
  %t29 = load ptr, ptr %l0, !tbaa !29
  store ptr %t29, ptr %l27, !tbaa !29
  %t30 = load ptr, ptr %l27, !tbaa !29
  %t31 = getelementptr %"compiler/fmt:formatter", ptr %t30, i32 0, i32 1
  %t32 = load { i64, ptr }, ptr %t31, !tbaa !27
  store { i64, ptr } %t32, ptr %l28, !tbaa !27
  %t33 = load i64, ptr %l1, !tbaa !24
  store i64 %t33, ptr %l29, !tbaa !24
  %t34 = load i64, ptr %l29, !tbaa !24
  %t35 = getelementptr { i64, ptr }, ptr %l28, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !27
  %t37 = getelementptr %"compiler/token:Token", ptr %t36, i64 %t34
  %t38 = getelementptr %"compiler/token:Token", ptr %t37, i32 0, i32 2
  %t39 = load i32, ptr %t38, !tbaa !23
  store i32 %t39, ptr %l30, !tbaa !23
  %t40 = load i32, ptr %l30, !tbaa !23
  %t41 = sext i32 %t40 to i64
  %t42 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = getelementptr i8, ptr %t43, i64 %t41
  %t45 = load i8, ptr %t44, !tbaa !32
  store i8 %t45, ptr %l31, !tbaa !22
  %t46 = load i8, ptr %l31, !tbaa !22
  store i8 %t46, ptr %l3, !tbaa !22
  %t47 = load i8, ptr %l3, !tbaa !22
  store i8 %t47, ptr %l32, !tbaa !22
  %t48 = load i8, ptr %l32, !tbaa !22
  %t49 = icmp uge i8 %t48, 97
  store i1 %t49, ptr %l33, !tbaa !21
  %t50 = load i1, ptr %l33, !tbaa !21
  br i1 %t50, label %bb14, label %bb15
bb14:
  %t51 = load i8, ptr %l3, !tbaa !22
  store i8 %t51, ptr %l35, !tbaa !22
  %t52 = load i8, ptr %l35, !tbaa !22
  %t53 = icmp ule i8 %t52, 122
  store i1 %t53, ptr %l36, !tbaa !21
  %t54 = load i1, ptr %l36, !tbaa !21
  store i1 %t54, ptr %l34, !tbaa !21
  br label %bb16
bb15:
  store i1 false, ptr %l34, !tbaa !21
  br label %bb16
bb16:
  %t55 = load i1, ptr %l34, !tbaa !21
  br i1 %t55, label %bb17, label %bb18
bb17:
  store i1 true, ptr %l37, !tbaa !21
  br label %bb22
bb18:
  %t56 = load i8, ptr %l3, !tbaa !22
  store i8 %t56, ptr %l38, !tbaa !22
  %t57 = load i8, ptr %l38, !tbaa !22
  %t58 = icmp uge i8 %t57, 65
  store i1 %t58, ptr %l39, !tbaa !21
  %t59 = load i1, ptr %l39, !tbaa !21
  br i1 %t59, label %bb19, label %bb20
bb19:
  %t60 = load i8, ptr %l3, !tbaa !22
  store i8 %t60, ptr %l41, !tbaa !22
  %t61 = load i8, ptr %l41, !tbaa !22
  %t62 = icmp ule i8 %t61, 90
  store i1 %t62, ptr %l42, !tbaa !21
  %t63 = load i1, ptr %l42, !tbaa !21
  store i1 %t63, ptr %l40, !tbaa !21
  br label %bb21
bb20:
  store i1 false, ptr %l40, !tbaa !21
  br label %bb21
bb21:
  %t64 = load i1, ptr %l40, !tbaa !21
  store i1 %t64, ptr %l37, !tbaa !21
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s0)
  %t65 = load i1, ptr %l37, !tbaa !21
  store i1 %t65, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2ekind(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/fmt:formatter", ptr %t2, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l3, !tbaa !27
  %t5 = load i64, ptr %l1, !tbaa !24
  store i64 %t5, ptr %l4, !tbaa !24
  %t6 = load i64, ptr %l4, !tbaa !24
  %t7 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t8 = load ptr, ptr %t7, !tbaa !27
  %t9 = getelementptr %"compiler/token:Token", ptr %t8, i64 %t6
  %t10 = getelementptr %"compiler/token:Token", ptr %t9, i32 0, i32 0
  %t11 = load i32, ptr %t10
  store i32 %t11, ptr %l5
  call void @__olang_scope_close(ptr %s0)
  %t12 = load i32, ptr %l5
  store i32 %t12, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i64 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2elevel(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i1
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca i64
  %l14 = alloca ptr
  %l15 = alloca i64
  %l16 = alloca i1
  %l17 = alloca i1
  %l18 = alloca i1
  %l19 = alloca i64
  %l20 = alloca i1
  %l21 = alloca ptr
  %l22 = alloca ptr
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca ptr
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca ptr
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i1
  %l35 = alloca i1
  %l36 = alloca i64
  %l37 = alloca i1
  %l38 = alloca i1
  %l39 = alloca ptr
  %l40 = alloca ptr
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i1
  %l45 = alloca i1
  %l46 = alloca i1
  %l47 = alloca i1
  %l48 = alloca i64
  %l49 = alloca i1
  %l50 = alloca i1
  %l51 = alloca ptr
  %l52 = alloca ptr
  %l53 = alloca i64
  %l54 = alloca i64
  %l55 = alloca i64
  %l56 = alloca i1
  %l57 = alloca ptr
  %l58 = alloca i64
  %l59 = alloca ptr
  %l60 = alloca i64
  %l61 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l7, !tbaa !29
  %t2 = load ptr, ptr %l7, !tbaa !29
  %t3 = getelementptr %"compiler/fmt:formatter", ptr %t2, i32 0, i32 4
  store ptr %t3, ptr %l8, !tbaa !29
  %t4 = load i64, ptr %l1, !tbaa !24
  store i64 %t4, ptr %l9, !tbaa !24
  %t5 = load ptr, ptr %l8, !tbaa !29
  %t6 = load i64, ptr %l9, !tbaa !24
  %t7 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t5, i64 %t6)
  store i64 %t7, ptr %l10
  br label %bb1
bb1:
  %t8 = load i64, ptr %l10, !tbaa !24
  store i64 %t8, ptr %l2, !tbaa !24
  %t9 = load ptr, ptr %l0, !tbaa !29
  store ptr %t9, ptr %l11, !tbaa !29
  %t10 = load ptr, ptr %l11, !tbaa !29
  %t11 = getelementptr %"compiler/fmt:formatter", ptr %t10, i32 0, i32 6
  store ptr %t11, ptr %l12, !tbaa !29
  %t12 = load ptr, ptr %l12, !tbaa !29
  %t13 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t12)
  store i64 %t13, ptr %l13
  br label %bb2
bb2:
  %t14 = load i64, ptr %l13, !tbaa !24
  store i64 %t14, ptr %l3, !tbaa !24
  %t15 = load ptr, ptr %l0, !tbaa !29
  store ptr %t15, ptr %l14, !tbaa !29
  %t16 = load i64, ptr %l2, !tbaa !24
  store i64 %t16, ptr %l15, !tbaa !24
  %t17 = load ptr, ptr %l14, !tbaa !29
  %t18 = load i64, ptr %l15, !tbaa !24
  %t19 = call i1 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2eclosing(ptr %v0, ptr %t17, i64 %t18)
  store i1 %t19, ptr %l16
  br label %bb3
bb3:
  %t20 = load i1, ptr %l16, !tbaa !21
  store i1 %t20, ptr %l4, !tbaa !21
  store i64 0, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  %t21 = load i1, ptr %l4, !tbaa !21
  store i1 %t21, ptr %l17, !tbaa !21
  %t22 = load i1, ptr %l17, !tbaa !21
  br i1 %t22, label %bb4, label %bb5
bb4:
  %t23 = load i64, ptr %l3, !tbaa !24
  store i64 %t23, ptr %l19, !tbaa !24
  %t24 = load i64, ptr %l19, !tbaa !24
  %t25 = icmp sgt i64 %t24, 0
  store i1 %t25, ptr %l20, !tbaa !21
  %t26 = load i1, ptr %l20, !tbaa !21
  store i1 %t26, ptr %l18, !tbaa !21
  br label %bb6
bb5:
  store i1 false, ptr %l18, !tbaa !21
  br label %bb6
bb6:
  %t27 = load i1, ptr %l18, !tbaa !21
  br i1 %t27, label %bb7, label %bb8
bb7:
  store %olang.scope zeroinitializer, ptr %s1
  %t28 = load ptr, ptr %l0, !tbaa !29
  store ptr %t28, ptr %l21, !tbaa !29
  %t29 = load ptr, ptr %l21, !tbaa !29
  %t30 = getelementptr %"compiler/fmt:formatter", ptr %t29, i32 0, i32 8
  store ptr %t30, ptr %l22, !tbaa !29
  %t31 = load i64, ptr %l3, !tbaa !24
  store i64 %t31, ptr %l23, !tbaa !24
  %t32 = load i64, ptr %l23, !tbaa !24
  %t33 = sub i64 %t32, 1
  store i64 %t33, ptr %l24, !tbaa !24
  %t34 = load ptr, ptr %l22, !tbaa !29
  %t35 = load i64, ptr %l24, !tbaa !24
  %t36 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t34, i64 %t35)
  store i64 %t36, ptr %l25
  br label %bb9
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t37 = load ptr, ptr %l0, !tbaa !29
  store ptr %t37, ptr %l26, !tbaa !29
  %t38 = load i64, ptr %l1, !tbaa !24
  store i64 %t38, ptr %l27, !tbaa !24
  %t39 = load ptr, ptr %l26, !tbaa !29
  %t40 = load i64, ptr %l27, !tbaa !24
  %t41 = call i64 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2econt(ptr %v0, ptr %t39, i64 %t40)
  store i64 %t41, ptr %l28
  br label %bb10
bb9:
  %t42 = load i64, ptr %l25, !tbaa !24
  store i64 %t42, ptr %l6, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  br label %bb12
bb10:
  %t43 = load i64, ptr %l28, !tbaa !24
  store i64 %t43, ptr %l5, !tbaa !24
  %t44 = load ptr, ptr %l0, !tbaa !29
  store ptr %t44, ptr %l29, !tbaa !29
  %t45 = load ptr, ptr %l29, !tbaa !29
  %t46 = call i64 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2echild(ptr %v0, ptr %t45)
  store i64 %t46, ptr %l30
  br label %bb11
bb11:
  %t47 = load i64, ptr %l5, !tbaa !24
  store i64 %t47, ptr %l31, !tbaa !24
  %t48 = load i64, ptr %l30, !tbaa !24
  %t49 = load i64, ptr %l31, !tbaa !24
  %t50 = add i64 %t48, %t49
  store i64 %t50, ptr %l32, !tbaa !24
  %t51 = load i64, ptr %l32, !tbaa !24
  store i64 %t51, ptr %l6, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb12
bb12:
  %t52 = load i64, ptr %l5, !tbaa !24
  store i64 %t52, ptr %l33, !tbaa !24
  %t53 = load i64, ptr %l33, !tbaa !24
  %t54 = icmp eq i64 %t53, 0
  store i1 %t54, ptr %l34, !tbaa !21
  %t55 = load i1, ptr %l34, !tbaa !21
  br i1 %t55, label %bb13, label %bb14
bb13:
  %t56 = load i64, ptr %l3, !tbaa !24
  store i64 %t56, ptr %l36, !tbaa !24
  %t57 = load i64, ptr %l36, !tbaa !24
  %t58 = icmp eq i64 %t57, 0
  store i1 %t58, ptr %l37, !tbaa !21
  %t59 = load i1, ptr %l37, !tbaa !21
  br i1 %t59, label %bb15, label %bb16
bb14:
  store i1 false, ptr %l35, !tbaa !21
  br label %bb29
bb15:
  store i1 true, ptr %l38, !tbaa !21
  br label %bb18
bb16:
  %t60 = load ptr, ptr %l0, !tbaa !29
  store ptr %t60, ptr %l39, !tbaa !29
  %t61 = load ptr, ptr %l39, !tbaa !29
  %t62 = getelementptr %"compiler/fmt:formatter", ptr %t61, i32 0, i32 6
  store ptr %t62, ptr %l40, !tbaa !29
  %t63 = load i64, ptr %l3, !tbaa !24
  store i64 %t63, ptr %l41, !tbaa !24
  %t64 = load i64, ptr %l41, !tbaa !24
  %t65 = sub i64 %t64, 1
  store i64 %t65, ptr %l42, !tbaa !24
  %t66 = load ptr, ptr %l40, !tbaa !29
  %t67 = load i64, ptr %l42, !tbaa !24
  %t68 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t66, i64 %t67)
  store i64 %t68, ptr %l43
  br label %bb17
bb17:
  %t69 = load i64, ptr %l43, !tbaa !24
  %t70 = icmp eq i64 %t69, 0
  store i1 %t70, ptr %l44, !tbaa !21
  %t71 = load i1, ptr %l44, !tbaa !21
  store i1 %t71, ptr %l38, !tbaa !21
  br label %bb18
bb18:
  %t72 = load i1, ptr %l38, !tbaa !21
  br i1 %t72, label %bb19, label %bb20
bb19:
  store i1 true, ptr %l45, !tbaa !21
  br label %bb28
bb20:
  %t73 = load i1, ptr %l4, !tbaa !21
  store i1 %t73, ptr %l46, !tbaa !21
  %t74 = load i1, ptr %l46, !tbaa !21
  br i1 %t74, label %bb21, label %bb22
bb21:
  %t75 = load i64, ptr %l3, !tbaa !24
  store i64 %t75, ptr %l48, !tbaa !24
  %t76 = load i64, ptr %l48, !tbaa !24
  %t77 = icmp sgt i64 %t76, 1
  store i1 %t77, ptr %l49, !tbaa !21
  %t78 = load i1, ptr %l49, !tbaa !21
  store i1 %t78, ptr %l47, !tbaa !21
  br label %bb23
bb22:
  store i1 false, ptr %l47, !tbaa !21
  br label %bb23
bb23:
  %t79 = load i1, ptr %l47, !tbaa !21
  br i1 %t79, label %bb24, label %bb25
bb24:
  %t80 = load ptr, ptr %l0, !tbaa !29
  store ptr %t80, ptr %l51, !tbaa !29
  %t81 = load ptr, ptr %l51, !tbaa !29
  %t82 = getelementptr %"compiler/fmt:formatter", ptr %t81, i32 0, i32 6
  store ptr %t82, ptr %l52, !tbaa !29
  %t83 = load i64, ptr %l3, !tbaa !24
  store i64 %t83, ptr %l53, !tbaa !24
  %t84 = load i64, ptr %l53, !tbaa !24
  %t85 = sub i64 %t84, 2
  store i64 %t85, ptr %l54, !tbaa !24
  %t86 = load ptr, ptr %l52, !tbaa !29
  %t87 = load i64, ptr %l54, !tbaa !24
  %t88 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t86, i64 %t87)
  store i64 %t88, ptr %l55
  br label %bb26
bb25:
  store i1 false, ptr %l50, !tbaa !21
  br label %bb27
bb26:
  %t89 = load i64, ptr %l55, !tbaa !24
  %t90 = icmp eq i64 %t89, 0
  store i1 %t90, ptr %l56, !tbaa !21
  %t91 = load i1, ptr %l56, !tbaa !21
  store i1 %t91, ptr %l50, !tbaa !21
  br label %bb27
bb27:
  %t92 = load i1, ptr %l50, !tbaa !21
  store i1 %t92, ptr %l45, !tbaa !21
  br label %bb28
bb28:
  %t93 = load i1, ptr %l45, !tbaa !21
  store i1 %t93, ptr %l35, !tbaa !21
  br label %bb29
bb29:
  %t94 = load i1, ptr %l35, !tbaa !21
  br i1 %t94, label %bb30, label %bb31
bb30:
  store %olang.scope zeroinitializer, ptr %s3
  %t95 = load ptr, ptr %l0, !tbaa !29
  store ptr %t95, ptr %l57, !tbaa !29
  %t96 = load i64, ptr %l6, !tbaa !24
  store i64 %t96, ptr %l58, !tbaa !24
  %t97 = load i64, ptr %l58, !tbaa !24
  %t98 = load ptr, ptr %l57, !tbaa !29
  %t99 = getelementptr %"compiler/fmt:formatter", ptr %t98, i32 0, i32 19
  store i64 %t97, ptr %t99, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb32
bb31:
  br label %bb32
bb32:
  %t100 = load ptr, ptr %l0, !tbaa !29
  store ptr %t100, ptr %l59, !tbaa !29
  %t101 = load i64, ptr %l6, !tbaa !24
  store i64 %t101, ptr %l60, !tbaa !24
  %t102 = load i64, ptr %l60, !tbaa !24
  %t103 = load ptr, ptr %l59, !tbaa !29
  %t104 = getelementptr %"compiler/fmt:formatter", ptr %t103, i32 0, i32 18
  store i64 %t102, ptr %t104, !tbaa !24
  %t105 = load i64, ptr %l6, !tbaa !24
  store i64 %t105, ptr %l61, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  %t106 = load i64, ptr %l61, !tbaa !24
  store i64 %t106, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2elevelAt(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i1
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t3 = call i64 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2echild(ptr %v0, ptr %t2)
  store i64 %t3, ptr %l4
  br label %bb1
bb1:
  %t4 = load i64, ptr %l4, !tbaa !24
  store i64 %t4, ptr %l2, !tbaa !24
  %t5 = load i64, ptr %l1, !tbaa !24
  store i64 %t5, ptr %l5, !tbaa !24
  %t6 = load i64, ptr %l5, !tbaa !24
  %t7 = icmp slt i64 %t6, 0
  store i1 %t7, ptr %l6, !tbaa !21
  %t8 = load i1, ptr %l6, !tbaa !21
  br i1 %t8, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t9 = load i64, ptr %l2, !tbaa !24
  store i64 %t9, ptr %l7, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t10 = load i64, ptr %l7, !tbaa !24
  store i64 %t10, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t11 = load i64, ptr %l2, !tbaa !24
  store i64 %t11, ptr %l8, !tbaa !24
  %t12 = load ptr, ptr %l0, !tbaa !29
  store ptr %t12, ptr %l9, !tbaa !29
  %t13 = load i64, ptr %l1, !tbaa !24
  store i64 %t13, ptr %l10, !tbaa !24
  %t14 = load ptr, ptr %l9, !tbaa !29
  %t15 = load i64, ptr %l10, !tbaa !24
  %t16 = call i64 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2econt(ptr %v0, ptr %t14, i64 %t15)
  store i64 %t16, ptr %l11
  br label %bb5
bb5:
  %t17 = load i64, ptr %l8, !tbaa !24
  %t18 = load i64, ptr %l11, !tbaa !24
  %t19 = add i64 %t17, %t18
  store i64 %t19, ptr %l12, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  %t20 = load i64, ptr %l12, !tbaa !24
  store i64 %t20, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2eoperandEnd(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i32
  %l6 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i1
  %l11 = alloca i1
  %l12 = alloca i1
  %l13 = alloca i32
  %l14 = alloca i1
  %l15 = alloca i32
  %l16 = alloca i1
  %l17 = alloca i32
  %l18 = alloca i1
  %l19 = alloca i32
  %l20 = alloca i1
  %l21 = alloca i32
  %l22 = alloca i1
  %l23 = alloca i32
  %l24 = alloca i1
  %l25 = alloca i32
  %l26 = alloca i1
  %l27 = alloca i32
  %l28 = alloca i1
  %l29 = alloca i32
  %l30 = alloca i1
  %l31 = alloca i32
  %l32 = alloca i1
  %l33 = alloca i32
  %l34 = alloca i1
  %l35 = alloca i32
  %l36 = alloca i1
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  store i64 %t2, ptr %l4, !tbaa !24
  %t3 = load ptr, ptr %l3, !tbaa !29
  %t4 = load i64, ptr %l4, !tbaa !24
  %t5 = call i32 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2ekind(ptr %v0, ptr %t3, i64 %t4)
  store i32 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i32, ptr %l5
  store i32 %t6, ptr %l2
  %t7 = load ptr, ptr %l0, !tbaa !29
  store ptr %t7, ptr %l6, !tbaa !29
  %t8 = load ptr, ptr %l6, !tbaa !29
  %t9 = getelementptr %"compiler/fmt:formatter", ptr %t8, i32 0, i32 3
  %t10 = load { i64, ptr }, ptr %t9, !tbaa !27
  store { i64, ptr } %t10, ptr %l7, !tbaa !27
  %t11 = load i64, ptr %l1, !tbaa !24
  store i64 %t11, ptr %l8, !tbaa !24
  %t12 = load i64, ptr %l8, !tbaa !24
  %t13 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !27
  %t15 = getelementptr i64, ptr %t14, i64 %t12
  %t16 = load i64, ptr %t15, !tbaa !34
  store i64 %t16, ptr %l9, !tbaa !24
  %t17 = load i64, ptr %l9, !tbaa !24
  %t18 = icmp sgt i64 %t17, 0
  store i1 %t18, ptr %l10, !tbaa !21
  %t19 = load i1, ptr %l10, !tbaa !21
  br i1 %t19, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  store i1 true, ptr %l11, !tbaa !21
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t20 = load i1, ptr %l11, !tbaa !21
  store i1 %t20, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t21 = load i32, ptr %l2
  store i32 %t21, ptr %l13
  %t22 = load i32, ptr %l13
  %t23 = trunc i64 1 to i32
  %t24 = icmp eq i32 %t22, %t23
  store i1 %t24, ptr %l14, !tbaa !21
  %t25 = load i1, ptr %l14, !tbaa !21
  br i1 %t25, label %bb5, label %bb6
bb5:
  br label %bb15
bb6:
  %t26 = load i32, ptr %l2
  store i32 %t26, ptr %l15
  %t27 = load i32, ptr %l15
  %t28 = trunc i64 2 to i32
  %t29 = icmp eq i32 %t27, %t28
  store i1 %t29, ptr %l16, !tbaa !21
  %t30 = load i1, ptr %l16, !tbaa !21
  br i1 %t30, label %bb7, label %bb8
bb7:
  br label %bb15
bb8:
  %t31 = load i32, ptr %l2
  store i32 %t31, ptr %l17
  %t32 = load i32, ptr %l17
  %t33 = trunc i64 3 to i32
  %t34 = icmp eq i32 %t32, %t33
  store i1 %t34, ptr %l18, !tbaa !21
  %t35 = load i1, ptr %l18, !tbaa !21
  br i1 %t35, label %bb9, label %bb10
bb9:
  br label %bb15
bb10:
  %t36 = load i32, ptr %l2
  store i32 %t36, ptr %l19
  %t37 = load i32, ptr %l19
  %t38 = trunc i64 4 to i32
  %t39 = icmp eq i32 %t37, %t38
  store i1 %t39, ptr %l20, !tbaa !21
  %t40 = load i1, ptr %l20, !tbaa !21
  br i1 %t40, label %bb11, label %bb12
bb11:
  br label %bb15
bb12:
  %t41 = load i32, ptr %l2
  store i32 %t41, ptr %l21
  %t42 = load i32, ptr %l21
  %t43 = trunc i64 5 to i32
  %t44 = icmp eq i32 %t42, %t43
  store i1 %t44, ptr %l22, !tbaa !21
  %t45 = load i1, ptr %l22, !tbaa !21
  br i1 %t45, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  store %olang.scope zeroinitializer, ptr %s2
  store i1 true, ptr %l12, !tbaa !21
  call void @__olang_scope_close(ptr %s2)
  br label %bb35
bb16:
  %t46 = load i32, ptr %l2
  store i32 %t46, ptr %l23
  %t47 = load i32, ptr %l23
  %t48 = trunc i64 6 to i32
  %t49 = icmp eq i32 %t47, %t48
  store i1 %t49, ptr %l24, !tbaa !21
  %t50 = load i1, ptr %l24, !tbaa !21
  br i1 %t50, label %bb17, label %bb18
bb17:
  br label %bb27
bb18:
  %t51 = load i32, ptr %l2
  store i32 %t51, ptr %l25
  %t52 = load i32, ptr %l25
  %t53 = trunc i64 7 to i32
  %t54 = icmp eq i32 %t52, %t53
  store i1 %t54, ptr %l26, !tbaa !21
  %t55 = load i1, ptr %l26, !tbaa !21
  br i1 %t55, label %bb19, label %bb20
bb19:
  br label %bb27
bb20:
  %t56 = load i32, ptr %l2
  store i32 %t56, ptr %l27
  %t57 = load i32, ptr %l27
  %t58 = trunc i64 91 to i32
  %t59 = icmp eq i32 %t57, %t58
  store i1 %t59, ptr %l28, !tbaa !21
  %t60 = load i1, ptr %l28, !tbaa !21
  br i1 %t60, label %bb21, label %bb22
bb21:
  br label %bb27
bb22:
  %t61 = load i32, ptr %l2
  store i32 %t61, ptr %l29
  %t62 = load i32, ptr %l29
  %t63 = trunc i64 93 to i32
  %t64 = icmp eq i32 %t62, %t63
  store i1 %t64, ptr %l30, !tbaa !21
  %t65 = load i1, ptr %l30, !tbaa !21
  br i1 %t65, label %bb23, label %bb24
bb23:
  br label %bb27
bb24:
  %t66 = load i32, ptr %l2
  store i32 %t66, ptr %l31
  %t67 = load i32, ptr %l31
  %t68 = trunc i64 95 to i32
  %t69 = icmp eq i32 %t67, %t68
  store i1 %t69, ptr %l32, !tbaa !21
  %t70 = load i1, ptr %l32, !tbaa !21
  br i1 %t70, label %bb25, label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb28
bb27:
  store %olang.scope zeroinitializer, ptr %s3
  store i1 true, ptr %l12, !tbaa !21
  call void @__olang_scope_close(ptr %s3)
  br label %bb35
bb28:
  %t71 = load i32, ptr %l2
  store i32 %t71, ptr %l33
  %t72 = load i32, ptr %l33
  %t73 = trunc i64 73 to i32
  %t74 = icmp eq i32 %t72, %t73
  store i1 %t74, ptr %l34, !tbaa !21
  %t75 = load i1, ptr %l34, !tbaa !21
  br i1 %t75, label %bb29, label %bb30
bb29:
  br label %bb33
bb30:
  %t76 = load i32, ptr %l2
  store i32 %t76, ptr %l35
  %t77 = load i32, ptr %l35
  %t78 = trunc i64 74 to i32
  %t79 = icmp eq i32 %t77, %t78
  store i1 %t79, ptr %l36, !tbaa !21
  %t80 = load i1, ptr %l36, !tbaa !21
  br i1 %t80, label %bb31, label %bb32
bb31:
  br label %bb33
bb32:
  br label %bb34
bb33:
  store %olang.scope zeroinitializer, ptr %s4
  store i1 true, ptr %l12, !tbaa !21
  call void @__olang_scope_close(ptr %s4)
  br label %bb35
bb34:
  store %olang.scope zeroinitializer, ptr %s5
  store i1 false, ptr %l12, !tbaa !21
  call void @__olang_scope_close(ptr %s5)
  br label %bb35
bb35:
  call void @__olang_scope_close(ptr %s0)
  %t81 = load i1, ptr %l12, !tbaa !21
  store i1 %t81, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2eparams(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i1
  %l10 = alloca i1
  %l11 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca i32
  %l14 = alloca ptr
  %l15 = alloca i32
  %l16 = alloca ptr
  %l17 = alloca i1
  %l18 = alloca i1
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i1
  %l23 = alloca i64
  %l24 = alloca ptr
  %l25 = alloca i64
  %l26 = alloca i32
  %l27 = alloca i32
  %l28 = alloca ptr
  %l29 = alloca i32
  %l30 = alloca ptr
  %l31 = alloca i1
  %l32 = alloca i1
  %l33 = alloca i32
  %l34 = alloca ptr
  %l35 = alloca i32
  %l36 = alloca ptr
  %l37 = alloca i1
  %l38 = alloca i64
  %l39 = alloca i32
  %l40 = alloca ptr
  %l41 = alloca i32
  %l42 = alloca ptr
  %l43 = alloca i1
  %l44 = alloca i1
  %l45 = alloca i1
  %l46 = alloca ptr
  %l47 = alloca i64
  %l48 = alloca i1
  %l49 = alloca i1
  %l50 = alloca i64
  %l51 = alloca i64
  %l52 = alloca i64
  %l53 = alloca i64
  %l54 = alloca i1
  %l55 = alloca i1
  %l56 = alloca ptr
  %l57 = alloca i64
  %l58 = alloca i32
  %l59 = alloca ptr
  %l60 = alloca i32
  %l61 = alloca ptr
  %l62 = alloca i1
  %l63 = alloca i1
  %l64 = alloca i64
  %l65 = alloca i64
  %l66 = alloca i64
  %l67 = alloca i1
  %l68 = alloca i1
  %l69 = alloca ptr
  %l70 = alloca i64
  %l71 = alloca i32
  %l72 = alloca ptr
  %l73 = alloca i32
  %l74 = alloca ptr
  %l75 = alloca i1
  %l76 = alloca i64
  %l77 = alloca i64
  %l78 = alloca i1
  %l79 = alloca i1
  %l80 = alloca ptr
  %l81 = alloca i64
  %l82 = alloca i32
  %l83 = alloca ptr
  %l84 = alloca i32
  %l85 = alloca ptr
  %l86 = alloca i1
  %l87 = alloca ptr
  %l88 = alloca { i64, ptr }
  %l89 = alloca i64
  %l90 = alloca i64
  %l91 = alloca i64
  %l92 = alloca i64
  %l93 = alloca i1
  %l94 = alloca i1
  %l95 = alloca ptr
  %l96 = alloca i64
  %l97 = alloca i32
  %l98 = alloca ptr
  %l99 = alloca i32
  %l100 = alloca ptr
  %l101 = alloca i1
  %l102 = alloca i1
  %l103 = alloca i64
  %l104 = alloca i64
  %l105 = alloca i64
  %l106 = alloca i1
  %l107 = alloca i1
  %l108 = alloca ptr
  %l109 = alloca i64
  %l110 = alloca i32
  %l111 = alloca ptr
  %l112 = alloca i32
  %l113 = alloca ptr
  %l114 = alloca i1
  %l115 = alloca i64
  %l116 = alloca i64
  %l117 = alloca i1
  %l118 = alloca i1
  %l119 = alloca ptr
  %l120 = alloca i64
  %l121 = alloca i32
  %l122 = alloca ptr
  %l123 = alloca i32
  %l124 = alloca ptr
  %l125 = alloca i1
  %l126 = alloca i1
  %l127 = alloca ptr
  %l128 = alloca { i64, ptr }
  %l129 = alloca i64
  %l130 = alloca %"compiler/token:Token"
  %l131 = alloca i8
  %l132 = alloca i1
  %l133 = alloca i64
  %l134 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l1, !tbaa !24
  store i64 %t1, ptr %l6, !tbaa !24
  %t2 = load i64, ptr %l6, !tbaa !24
  %t3 = sub i64 %t2, 1
  store i64 %t3, ptr %l7, !tbaa !24
  %t4 = load i64, ptr %l7, !tbaa !24
  store i64 %t4, ptr %l2, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t5 = load i64, ptr %l2, !tbaa !24
  store i64 %t5, ptr %l8, !tbaa !24
  %t6 = load i64, ptr %l8, !tbaa !24
  %t7 = icmp sge i64 %t6, 0
  store i1 %t7, ptr %l9, !tbaa !21
  %t8 = load i1, ptr %l9, !tbaa !21
  br i1 %t8, label %bb2, label %bb3
bb2:
  %t9 = load ptr, ptr %l0, !tbaa !29
  store ptr %t9, ptr %l11, !tbaa !29
  %t10 = load i64, ptr %l2, !tbaa !24
  store i64 %t10, ptr %l12, !tbaa !24
  %t11 = load ptr, ptr %l11, !tbaa !29
  %t12 = load i64, ptr %l12, !tbaa !24
  %t13 = call i32 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2ekind(ptr %v0, ptr %t11, i64 %t12)
  store i32 %t13, ptr %l13
  br label %bb4
bb3:
  store i1 false, ptr %l10, !tbaa !21
  br label %bb6
bb4:
  store ptr %l13, ptr %l14, !tbaa !29
  store i32 8, ptr %l15
  store ptr %l15, ptr %l16, !tbaa !29
  %t14 = load ptr, ptr %l14, !tbaa !29
  %t15 = load ptr, ptr %l16, !tbaa !29
  %t16 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t14, ptr %t15)
  store i1 %t16, ptr %l17
  br label %bb5
bb5:
  %t17 = load i1, ptr %l17, !tbaa !21
  store i1 %t17, ptr %l10, !tbaa !21
  br label %bb6
bb6:
  %t18 = load i1, ptr %l10, !tbaa !21
  %t19 = xor i1 %t18, true
  store i1 %t19, ptr %l18, !tbaa !21
  %t20 = load i1, ptr %l18, !tbaa !21
  br i1 %t20, label %bb7, label %bb8
bb7:
  call void @__olang_scope_close(ptr %s1)
  br label %bb11
bb8:
  br label %bb9
bb9:
  %t21 = load i64, ptr %l2, !tbaa !24
  store i64 %t21, ptr %l19, !tbaa !24
  %t22 = load i64, ptr %l19, !tbaa !24
  %t23 = sub i64 %t22, 1
  store i64 %t23, ptr %l20, !tbaa !24
  %t24 = load i64, ptr %l20, !tbaa !24
  store i64 %t24, ptr %l2, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  br label %bb10
bb10:
  br label %bb1
bb11:
  %t25 = load i64, ptr %l2, !tbaa !24
  store i64 %t25, ptr %l21, !tbaa !24
  %t26 = load i64, ptr %l21, !tbaa !24
  %t27 = icmp slt i64 %t26, 0
  store i1 %t27, ptr %l22, !tbaa !21
  %t28 = load i1, ptr %l22, !tbaa !21
  br i1 %t28, label %bb12, label %bb13
bb12:
  store %olang.scope zeroinitializer, ptr %s2
  store i64 0, ptr %l23, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t29 = load i64, ptr %l23, !tbaa !24
  store i64 %t29, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  %t30 = load ptr, ptr %l0, !tbaa !29
  store ptr %t30, ptr %l24, !tbaa !29
  %t31 = load i64, ptr %l2, !tbaa !24
  store i64 %t31, ptr %l25, !tbaa !24
  %t32 = load ptr, ptr %l24, !tbaa !29
  %t33 = load i64, ptr %l25, !tbaa !24
  %t34 = call i32 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2ekind(ptr %v0, ptr %t32, i64 %t33)
  store i32 %t34, ptr %l26
  br label %bb15
bb15:
  %t35 = load i32, ptr %l26
  store i32 %t35, ptr %l3
  %t36 = load i32, ptr %l3
  store i32 %t36, ptr %l27
  store ptr %l27, ptr %l28, !tbaa !29
  store i32 37, ptr %l29
  store ptr %l29, ptr %l30, !tbaa !29
  %t37 = load ptr, ptr %l28, !tbaa !29
  %t38 = load ptr, ptr %l30, !tbaa !29
  %t39 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t37, ptr %t38)
  store i1 %t39, ptr %l31
  br label %bb16
bb16:
  %t40 = load i1, ptr %l31, !tbaa !21
  br i1 %t40, label %bb17, label %bb18
bb17:
  store i1 true, ptr %l32, !tbaa !21
  br label %bb20
bb18:
  %t41 = load i32, ptr %l3
  store i32 %t41, ptr %l33
  store ptr %l33, ptr %l34, !tbaa !29
  store i32 34, ptr %l35
  store ptr %l35, ptr %l36, !tbaa !29
  %t42 = load ptr, ptr %l34, !tbaa !29
  %t43 = load ptr, ptr %l36, !tbaa !29
  %t44 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t42, ptr %t43)
  store i1 %t44, ptr %l37
  br label %bb19
bb19:
  %t45 = load i1, ptr %l37, !tbaa !21
  store i1 %t45, ptr %l32, !tbaa !21
  br label %bb20
bb20:
  %t46 = load i1, ptr %l32, !tbaa !21
  br i1 %t46, label %bb21, label %bb22
bb21:
  store %olang.scope zeroinitializer, ptr %s3
  store i64 1, ptr %l38, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t47 = load i64, ptr %l38, !tbaa !24
  store i64 %t47, ptr %rv
  br label %ret
bb22:
  br label %bb23
bb23:
  %t48 = load i32, ptr %l3
  store i32 %t48, ptr %l39
  store ptr %l39, ptr %l40, !tbaa !29
  store i32 1, ptr %l41
  store ptr %l41, ptr %l42, !tbaa !29
  %t49 = load ptr, ptr %l40, !tbaa !29
  %t50 = load ptr, ptr %l42, !tbaa !29
  %t51 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t49, ptr %t50)
  store i1 %t51, ptr %l43
  br label %bb24
bb24:
  %t52 = load i1, ptr %l43, !tbaa !21
  %t53 = xor i1 %t52, true
  store i1 %t53, ptr %l44, !tbaa !21
  %t54 = load i1, ptr %l44, !tbaa !21
  br i1 %t54, label %bb25, label %bb26
bb25:
  %t55 = load ptr, ptr %l0, !tbaa !29
  store ptr %t55, ptr %l46, !tbaa !29
  %t56 = load i64, ptr %l2, !tbaa !24
  store i64 %t56, ptr %l47, !tbaa !24
  %t57 = load ptr, ptr %l46, !tbaa !29
  %t58 = load i64, ptr %l47, !tbaa !24
  %t59 = call i1 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2ekeyword(ptr %v0, ptr %t57, i64 %t58)
  store i1 %t59, ptr %l48
  br label %bb27
bb26:
  store i1 false, ptr %l45, !tbaa !21
  br label %bb28
bb27:
  %t60 = load i1, ptr %l48, !tbaa !21
  %t61 = xor i1 %t60, true
  store i1 %t61, ptr %l49, !tbaa !21
  %t62 = load i1, ptr %l49, !tbaa !21
  store i1 %t62, ptr %l45, !tbaa !21
  br label %bb28
bb28:
  %t63 = load i1, ptr %l45, !tbaa !21
  br i1 %t63, label %bb29, label %bb30
bb29:
  store %olang.scope zeroinitializer, ptr %s4
  store i64 0, ptr %l50, !tbaa !24
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t64 = load i64, ptr %l50, !tbaa !24
  store i64 %t64, ptr %rv
  br label %ret
bb30:
  br label %bb31
bb31:
  %t65 = load i64, ptr %l2, !tbaa !24
  store i64 %t65, ptr %l51, !tbaa !24
  %t66 = load i64, ptr %l51, !tbaa !24
  %t67 = sub i64 %t66, 1
  store i64 %t67, ptr %l52, !tbaa !24
  %t68 = load i64, ptr %l52, !tbaa !24
  store i64 %t68, ptr %l4, !tbaa !24
  br label %bb32
bb32:
  store %olang.scope zeroinitializer, ptr %s5
  %t69 = load i64, ptr %l4, !tbaa !24
  store i64 %t69, ptr %l53, !tbaa !24
  %t70 = load i64, ptr %l53, !tbaa !24
  %t71 = icmp sge i64 %t70, 0
  store i1 %t71, ptr %l54, !tbaa !21
  %t72 = load i1, ptr %l54, !tbaa !21
  br i1 %t72, label %bb33, label %bb34
bb33:
  %t73 = load ptr, ptr %l0, !tbaa !29
  store ptr %t73, ptr %l56, !tbaa !29
  %t74 = load i64, ptr %l4, !tbaa !24
  store i64 %t74, ptr %l57, !tbaa !24
  %t75 = load ptr, ptr %l56, !tbaa !29
  %t76 = load i64, ptr %l57, !tbaa !24
  %t77 = call i32 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2ekind(ptr %v0, ptr %t75, i64 %t76)
  store i32 %t77, ptr %l58
  br label %bb35
bb34:
  store i1 false, ptr %l55, !tbaa !21
  br label %bb37
bb35:
  store ptr %l58, ptr %l59, !tbaa !29
  store i32 8, ptr %l60
  store ptr %l60, ptr %l61, !tbaa !29
  %t78 = load ptr, ptr %l59, !tbaa !29
  %t79 = load ptr, ptr %l61, !tbaa !29
  %t80 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t78, ptr %t79)
  store i1 %t80, ptr %l62
  br label %bb36
bb36:
  %t81 = load i1, ptr %l62, !tbaa !21
  store i1 %t81, ptr %l55, !tbaa !21
  br label %bb37
bb37:
  %t82 = load i1, ptr %l55, !tbaa !21
  %t83 = xor i1 %t82, true
  store i1 %t83, ptr %l63, !tbaa !21
  %t84 = load i1, ptr %l63, !tbaa !21
  br i1 %t84, label %bb38, label %bb39
bb38:
  call void @__olang_scope_close(ptr %s5)
  br label %bb42
bb39:
  br label %bb40
bb40:
  %t85 = load i64, ptr %l4, !tbaa !24
  store i64 %t85, ptr %l64, !tbaa !24
  %t86 = load i64, ptr %l64, !tbaa !24
  %t87 = sub i64 %t86, 1
  store i64 %t87, ptr %l65, !tbaa !24
  %t88 = load i64, ptr %l65, !tbaa !24
  store i64 %t88, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s5)
  br label %bb41
bb41:
  br label %bb32
bb42:
  %t89 = load i64, ptr %l4, !tbaa !24
  store i64 %t89, ptr %l66, !tbaa !24
  %t90 = load i64, ptr %l66, !tbaa !24
  %t91 = icmp sge i64 %t90, 0
  store i1 %t91, ptr %l67, !tbaa !21
  %t92 = load i1, ptr %l67, !tbaa !21
  br i1 %t92, label %bb43, label %bb44
bb43:
  %t93 = load ptr, ptr %l0, !tbaa !29
  store ptr %t93, ptr %l69, !tbaa !29
  %t94 = load i64, ptr %l4, !tbaa !24
  store i64 %t94, ptr %l70, !tbaa !24
  %t95 = load ptr, ptr %l69, !tbaa !29
  %t96 = load i64, ptr %l70, !tbaa !24
  %t97 = call i32 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2ekind(ptr %v0, ptr %t95, i64 %t96)
  store i32 %t97, ptr %l71
  br label %bb45
bb44:
  store i1 false, ptr %l68, !tbaa !21
  br label %bb47
bb45:
  store ptr %l71, ptr %l72, !tbaa !29
  store i32 37, ptr %l73
  store ptr %l73, ptr %l74, !tbaa !29
  %t98 = load ptr, ptr %l72, !tbaa !29
  %t99 = load ptr, ptr %l74, !tbaa !29
  %t100 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t98, ptr %t99)
  store i1 %t100, ptr %l75
  br label %bb46
bb46:
  %t101 = load i1, ptr %l75, !tbaa !21
  store i1 %t101, ptr %l68, !tbaa !21
  br label %bb47
bb47:
  %t102 = load i1, ptr %l68, !tbaa !21
  br i1 %t102, label %bb48, label %bb49
bb48:
  store %olang.scope zeroinitializer, ptr %s6
  store i64 1, ptr %l76, !tbaa !24
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  %t103 = load i64, ptr %l76, !tbaa !24
  store i64 %t103, ptr %rv
  br label %ret
bb49:
  br label %bb50
bb50:
  %t104 = load i64, ptr %l4, !tbaa !24
  store i64 %t104, ptr %l77, !tbaa !24
  %t105 = load i64, ptr %l77, !tbaa !24
  %t106 = icmp sge i64 %t105, 0
  store i1 %t106, ptr %l78, !tbaa !21
  %t107 = load i1, ptr %l78, !tbaa !21
  br i1 %t107, label %bb51, label %bb52
bb51:
  %t108 = load ptr, ptr %l0, !tbaa !29
  store ptr %t108, ptr %l80, !tbaa !29
  %t109 = load i64, ptr %l4, !tbaa !24
  store i64 %t109, ptr %l81, !tbaa !24
  %t110 = load ptr, ptr %l80, !tbaa !29
  %t111 = load i64, ptr %l81, !tbaa !24
  %t112 = call i32 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2ekind(ptr %v0, ptr %t110, i64 %t111)
  store i32 %t112, ptr %l82
  br label %bb53
bb52:
  store i1 false, ptr %l79, !tbaa !21
  br label %bb55
bb53:
  store ptr %l82, ptr %l83, !tbaa !29
  store i32 91, ptr %l84
  store ptr %l84, ptr %l85, !tbaa !29
  %t113 = load ptr, ptr %l83, !tbaa !29
  %t114 = load ptr, ptr %l85, !tbaa !29
  %t115 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t113, ptr %t114)
  store i1 %t115, ptr %l86
  br label %bb54
bb54:
  %t116 = load i1, ptr %l86, !tbaa !21
  store i1 %t116, ptr %l79, !tbaa !21
  br label %bb55
bb55:
  %t117 = load i1, ptr %l79, !tbaa !21
  br i1 %t117, label %bb56, label %bb57
bb56:
  store %olang.scope zeroinitializer, ptr %s7
  %t118 = load ptr, ptr %l0, !tbaa !29
  store ptr %t118, ptr %l87, !tbaa !29
  %t119 = load ptr, ptr %l87, !tbaa !29
  %t120 = getelementptr %"compiler/fmt:formatter", ptr %t119, i32 0, i32 20
  %t121 = load { i64, ptr }, ptr %t120, !tbaa !27
  store { i64, ptr } %t121, ptr %l88, !tbaa !27
  %t122 = load i64, ptr %l4, !tbaa !24
  store i64 %t122, ptr %l89, !tbaa !24
  %t123 = load i64, ptr %l89, !tbaa !24
  %t124 = getelementptr { i64, ptr }, ptr %l88, i32 0, i32 1
  %t125 = load ptr, ptr %t124, !tbaa !27
  %t126 = getelementptr i64, ptr %t125, i64 %t123
  %t127 = load i64, ptr %t126, !tbaa !34
  store i64 %t127, ptr %l90, !tbaa !24
  %t128 = load i64, ptr %l90, !tbaa !24
  %t129 = sub i64 %t128, 1
  store i64 %t129, ptr %l91, !tbaa !24
  %t130 = load i64, ptr %l91, !tbaa !24
  store i64 %t130, ptr %l5, !tbaa !24
  br label %bb58
bb57:
  br label %bb77
bb58:
  store %olang.scope zeroinitializer, ptr %s8
  %t131 = load i64, ptr %l5, !tbaa !24
  store i64 %t131, ptr %l92, !tbaa !24
  %t132 = load i64, ptr %l92, !tbaa !24
  %t133 = icmp sge i64 %t132, 0
  store i1 %t133, ptr %l93, !tbaa !21
  %t134 = load i1, ptr %l93, !tbaa !21
  br i1 %t134, label %bb59, label %bb60
bb59:
  %t135 = load ptr, ptr %l0, !tbaa !29
  store ptr %t135, ptr %l95, !tbaa !29
  %t136 = load i64, ptr %l5, !tbaa !24
  store i64 %t136, ptr %l96, !tbaa !24
  %t137 = load ptr, ptr %l95, !tbaa !29
  %t138 = load i64, ptr %l96, !tbaa !24
  %t139 = call i32 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2ekind(ptr %v0, ptr %t137, i64 %t138)
  store i32 %t139, ptr %l97
  br label %bb61
bb60:
  store i1 false, ptr %l94, !tbaa !21
  br label %bb63
bb61:
  store ptr %l97, ptr %l98, !tbaa !29
  store i32 8, ptr %l99
  store ptr %l99, ptr %l100, !tbaa !29
  %t140 = load ptr, ptr %l98, !tbaa !29
  %t141 = load ptr, ptr %l100, !tbaa !29
  %t142 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t140, ptr %t141)
  store i1 %t142, ptr %l101
  br label %bb62
bb62:
  %t143 = load i1, ptr %l101, !tbaa !21
  store i1 %t143, ptr %l94, !tbaa !21
  br label %bb63
bb63:
  %t144 = load i1, ptr %l94, !tbaa !21
  %t145 = xor i1 %t144, true
  store i1 %t145, ptr %l102, !tbaa !21
  %t146 = load i1, ptr %l102, !tbaa !21
  br i1 %t146, label %bb64, label %bb65
bb64:
  call void @__olang_scope_close(ptr %s8)
  br label %bb68
bb65:
  br label %bb66
bb66:
  %t147 = load i64, ptr %l5, !tbaa !24
  store i64 %t147, ptr %l103, !tbaa !24
  %t148 = load i64, ptr %l103, !tbaa !24
  %t149 = sub i64 %t148, 1
  store i64 %t149, ptr %l104, !tbaa !24
  %t150 = load i64, ptr %l104, !tbaa !24
  store i64 %t150, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s8)
  br label %bb67
bb67:
  br label %bb58
bb68:
  %t151 = load i64, ptr %l5, !tbaa !24
  store i64 %t151, ptr %l105, !tbaa !24
  %t152 = load i64, ptr %l105, !tbaa !24
  %t153 = icmp sge i64 %t152, 0
  store i1 %t153, ptr %l106, !tbaa !21
  %t154 = load i1, ptr %l106, !tbaa !21
  br i1 %t154, label %bb69, label %bb70
bb69:
  %t155 = load ptr, ptr %l0, !tbaa !29
  store ptr %t155, ptr %l108, !tbaa !29
  %t156 = load i64, ptr %l5, !tbaa !24
  store i64 %t156, ptr %l109, !tbaa !24
  %t157 = load ptr, ptr %l108, !tbaa !29
  %t158 = load i64, ptr %l109, !tbaa !24
  %t159 = call i32 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2ekind(ptr %v0, ptr %t157, i64 %t158)
  store i32 %t159, ptr %l110
  br label %bb71
bb70:
  store i1 false, ptr %l107, !tbaa !21
  br label %bb73
bb71:
  store ptr %l110, ptr %l111, !tbaa !29
  store i32 37, ptr %l112
  store ptr %l112, ptr %l113, !tbaa !29
  %t160 = load ptr, ptr %l111, !tbaa !29
  %t161 = load ptr, ptr %l113, !tbaa !29
  %t162 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t160, ptr %t161)
  store i1 %t162, ptr %l114
  br label %bb72
bb72:
  %t163 = load i1, ptr %l114, !tbaa !21
  store i1 %t163, ptr %l107, !tbaa !21
  br label %bb73
bb73:
  %t164 = load i1, ptr %l107, !tbaa !21
  br i1 %t164, label %bb74, label %bb75
bb74:
  store %olang.scope zeroinitializer, ptr %s9
  store i64 1, ptr %l115, !tbaa !24
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s0)
  %t165 = load i64, ptr %l115, !tbaa !24
  store i64 %t165, ptr %rv
  br label %ret
bb75:
  br label %bb76
bb76:
  call void @__olang_scope_close(ptr %s7)
  br label %bb77
bb77:
  %t166 = load i64, ptr %l4, !tbaa !24
  store i64 %t166, ptr %l116, !tbaa !24
  %t167 = load i64, ptr %l116, !tbaa !24
  %t168 = icmp slt i64 %t167, 0
  store i1 %t168, ptr %l117, !tbaa !21
  %t169 = load i1, ptr %l117, !tbaa !21
  br i1 %t169, label %bb78, label %bb79
bb78:
  store i1 true, ptr %l118, !tbaa !21
  br label %bb82
bb79:
  %t170 = load ptr, ptr %l0, !tbaa !29
  store ptr %t170, ptr %l119, !tbaa !29
  %t171 = load i64, ptr %l4, !tbaa !24
  store i64 %t171, ptr %l120, !tbaa !24
  %t172 = load ptr, ptr %l119, !tbaa !29
  %t173 = load i64, ptr %l120, !tbaa !24
  %t174 = call i32 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2ekind(ptr %v0, ptr %t172, i64 %t173)
  store i32 %t174, ptr %l121
  br label %bb80
bb80:
  store ptr %l121, ptr %l122, !tbaa !29
  store i32 94, ptr %l123
  store ptr %l123, ptr %l124, !tbaa !29
  %t175 = load ptr, ptr %l122, !tbaa !29
  %t176 = load ptr, ptr %l124, !tbaa !29
  %t177 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t175, ptr %t176)
  store i1 %t177, ptr %l125
  br label %bb81
bb81:
  %t178 = load i1, ptr %l125, !tbaa !21
  store i1 %t178, ptr %l118, !tbaa !21
  br label %bb82
bb82:
  %t179 = load i1, ptr %l118, !tbaa !21
  br i1 %t179, label %bb83, label %bb84
bb83:
  store i1 true, ptr %l126, !tbaa !21
  br label %bb86
bb84:
  %t180 = load ptr, ptr %l0, !tbaa !29
  store ptr %t180, ptr %l127, !tbaa !29
  %t181 = load ptr, ptr %l127, !tbaa !29
  %t182 = getelementptr %"compiler/fmt:formatter", ptr %t181, i32 0, i32 1
  %t183 = load { i64, ptr }, ptr %t182, !tbaa !27
  store { i64, ptr } %t183, ptr %l128, !tbaa !27
  %t184 = load i64, ptr %l2, !tbaa !24
  store i64 %t184, ptr %l129, !tbaa !24
  %t185 = load i64, ptr %l129, !tbaa !24
  %t186 = getelementptr { i64, ptr }, ptr %l128, i32 0, i32 1
  %t187 = load ptr, ptr %t186, !tbaa !27
  %t188 = getelementptr %"compiler/token:Token", ptr %t187, i64 %t185
  %t189 = load %"compiler/token:Token", ptr %t188
  store %"compiler/token:Token" %t189, ptr %l130
  %t190 = load i8, ptr @G_2ecompiler_2ftoken_2eLineBreak, !tbaa !22
  store i8 %t190, ptr %l131, !tbaa !22
  %t191 = load %"compiler/token:Token", ptr %l130
  %t192 = load i8, ptr %l131, !tbaa !22
  %t193 = call i1 @compiler_2ftoken_2ecompiler_2ftoken_3aToken_2eHas(%"compiler/token:Token" %t191, i8 %t192)
  store i1 %t193, ptr %l132
  br label %bb85
bb85:
  %t194 = load i1, ptr %l132, !tbaa !21
  store i1 %t194, ptr %l126, !tbaa !21
  br label %bb86
bb86:
  %t195 = load i1, ptr %l126, !tbaa !21
  br i1 %t195, label %bb87, label %bb88
bb87:
  store %olang.scope zeroinitializer, ptr %s10
  store i64 2, ptr %l133, !tbaa !24
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s0)
  %t196 = load i64, ptr %l133, !tbaa !24
  store i64 %t196, ptr %rv
  br label %ret
bb88:
  br label %bb89
bb89:
  store i64 0, ptr %l134, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  %t197 = load i64, ptr %l134, !tbaa !24
  store i64 %t197, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2eprefix(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca ptr
  %l10 = alloca i32
  %l11 = alloca ptr
  %l12 = alloca i1
  %l13 = alloca i1
  %l14 = alloca i32
  %l15 = alloca ptr
  %l16 = alloca i32
  %l17 = alloca ptr
  %l18 = alloca i1
  %l19 = alloca i1
  %l20 = alloca i32
  %l21 = alloca ptr
  %l22 = alloca i32
  %l23 = alloca ptr
  %l24 = alloca i1
  %l25 = alloca i1
  %l26 = alloca i1
  %l27 = alloca i32
  %l28 = alloca ptr
  %l29 = alloca i32
  %l30 = alloca ptr
  %l31 = alloca i1
  %l32 = alloca i1
  %l33 = alloca i1
  %l34 = alloca i32
  %l35 = alloca ptr
  %l36 = alloca i32
  %l37 = alloca ptr
  %l38 = alloca i1
  %l39 = alloca i1
  %l40 = alloca i1
  %l41 = alloca ptr
  %l42 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i64
  %l45 = alloca i1
  %l46 = alloca i1
  %l47 = alloca ptr
  %l48 = alloca i64
  %l49 = alloca i1
  %l50 = alloca i1
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  store i64 %t2, ptr %l6, !tbaa !24
  %t3 = load ptr, ptr %l5, !tbaa !29
  %t4 = load i64, ptr %l6, !tbaa !24
  %t5 = call i32 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2ekind(ptr %v0, ptr %t3, i64 %t4)
  store i32 %t5, ptr %l7
  br label %bb1
bb1:
  %t6 = load i32, ptr %l7
  store i32 %t6, ptr %l3
  %t7 = load i32, ptr %l3
  store i32 %t7, ptr %l8
  store ptr %l8, ptr %l9, !tbaa !29
  store i32 86, ptr %l10
  store ptr %l10, ptr %l11, !tbaa !29
  %t8 = load ptr, ptr %l9, !tbaa !29
  %t9 = load ptr, ptr %l11, !tbaa !29
  %t10 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t8, ptr %t9)
  store i1 %t10, ptr %l12
  br label %bb2
bb2:
  %t11 = load i1, ptr %l12, !tbaa !21
  br i1 %t11, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l13, !tbaa !21
  br label %bb6
bb4:
  %t12 = load i32, ptr %l3
  store i32 %t12, ptr %l14
  store ptr %l14, ptr %l15, !tbaa !29
  store i32 87, ptr %l16
  store ptr %l16, ptr %l17, !tbaa !29
  %t13 = load ptr, ptr %l15, !tbaa !29
  %t14 = load ptr, ptr %l17, !tbaa !29
  %t15 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t13, ptr %t14)
  store i1 %t15, ptr %l18
  br label %bb5
bb5:
  %t16 = load i1, ptr %l18, !tbaa !21
  store i1 %t16, ptr %l13, !tbaa !21
  br label %bb6
bb6:
  %t17 = load i1, ptr %l13, !tbaa !21
  br i1 %t17, label %bb7, label %bb8
bb7:
  store %olang.scope zeroinitializer, ptr %s1
  store i1 true, ptr %l19, !tbaa !21
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t18 = load i1, ptr %l19, !tbaa !21
  store i1 %t18, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t19 = load i32, ptr %l3
  store i32 %t19, ptr %l20
  store ptr %l20, ptr %l21, !tbaa !29
  store i32 52, ptr %l22
  store ptr %l22, ptr %l23, !tbaa !29
  %t20 = load ptr, ptr %l21, !tbaa !29
  %t21 = load ptr, ptr %l23, !tbaa !29
  %t22 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t20, ptr %t21)
  store i1 %t22, ptr %l24
  br label %bb10
bb10:
  %t23 = load i1, ptr %l24, !tbaa !21
  %t24 = xor i1 %t23, true
  store i1 %t24, ptr %l25, !tbaa !21
  %t25 = load i1, ptr %l25, !tbaa !21
  br i1 %t25, label %bb11, label %bb12
bb11:
  %t26 = load i32, ptr %l3
  store i32 %t26, ptr %l27
  store ptr %l27, ptr %l28, !tbaa !29
  store i32 73, ptr %l29
  store ptr %l29, ptr %l30, !tbaa !29
  %t27 = load ptr, ptr %l28, !tbaa !29
  %t28 = load ptr, ptr %l30, !tbaa !29
  %t29 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t27, ptr %t28)
  store i1 %t29, ptr %l31
  br label %bb13
bb12:
  store i1 false, ptr %l26, !tbaa !21
  br label %bb14
bb13:
  %t30 = load i1, ptr %l31, !tbaa !21
  %t31 = xor i1 %t30, true
  store i1 %t31, ptr %l32, !tbaa !21
  %t32 = load i1, ptr %l32, !tbaa !21
  store i1 %t32, ptr %l26, !tbaa !21
  br label %bb14
bb14:
  %t33 = load i1, ptr %l26, !tbaa !21
  br i1 %t33, label %bb15, label %bb16
bb15:
  %t34 = load i32, ptr %l3
  store i32 %t34, ptr %l34
  store ptr %l34, ptr %l35, !tbaa !29
  store i32 74, ptr %l36
  store ptr %l36, ptr %l37, !tbaa !29
  %t35 = load ptr, ptr %l35, !tbaa !29
  %t36 = load ptr, ptr %l37, !tbaa !29
  %t37 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t35, ptr %t36)
  store i1 %t37, ptr %l38
  br label %bb17
bb16:
  store i1 false, ptr %l33, !tbaa !21
  br label %bb18
bb17:
  %t38 = load i1, ptr %l38, !tbaa !21
  %t39 = xor i1 %t38, true
  store i1 %t39, ptr %l39, !tbaa !21
  %t40 = load i1, ptr %l39, !tbaa !21
  store i1 %t40, ptr %l33, !tbaa !21
  br label %bb18
bb18:
  %t41 = load i1, ptr %l33, !tbaa !21
  br i1 %t41, label %bb19, label %bb20
bb19:
  store %olang.scope zeroinitializer, ptr %s2
  store i1 false, ptr %l40, !tbaa !21
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t42 = load i1, ptr %l40, !tbaa !21
  store i1 %t42, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  %t43 = load ptr, ptr %l0, !tbaa !29
  store ptr %t43, ptr %l41, !tbaa !29
  %t44 = load i64, ptr %l2, !tbaa !24
  store i64 %t44, ptr %l42, !tbaa !24
  %t45 = load ptr, ptr %l41, !tbaa !29
  %t46 = load i64, ptr %l42, !tbaa !24
  %t47 = call i64 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2ebefore(ptr %v0, ptr %t45, i64 %t46)
  store i64 %t47, ptr %l43
  br label %bb22
bb22:
  %t48 = load i64, ptr %l43, !tbaa !24
  store i64 %t48, ptr %l4, !tbaa !24
  %t49 = load i64, ptr %l4, !tbaa !24
  store i64 %t49, ptr %l44, !tbaa !24
  %t50 = load i64, ptr %l44, !tbaa !24
  %t51 = icmp slt i64 %t50, 0
  store i1 %t51, ptr %l45, !tbaa !21
  %t52 = load i1, ptr %l45, !tbaa !21
  br i1 %t52, label %bb23, label %bb24
bb23:
  store i1 true, ptr %l46, !tbaa !21
  br label %bb26
bb24:
  %t53 = load ptr, ptr %l0, !tbaa !29
  store ptr %t53, ptr %l47, !tbaa !29
  %t54 = load i64, ptr %l4, !tbaa !24
  store i64 %t54, ptr %l48, !tbaa !24
  %t55 = load ptr, ptr %l47, !tbaa !29
  %t56 = load i64, ptr %l48, !tbaa !24
  %t57 = call i1 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2eoperandEnd(ptr %v0, ptr %t55, i64 %t56)
  store i1 %t57, ptr %l49
  br label %bb25
bb25:
  %t58 = load i1, ptr %l49, !tbaa !21
  %t59 = xor i1 %t58, true
  store i1 %t59, ptr %l50, !tbaa !21
  %t60 = load i1, ptr %l50, !tbaa !21
  store i1 %t60, ptr %l46, !tbaa !21
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s0)
  %t61 = load i1, ptr %l46, !tbaa !21
  store i1 %t61, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2epush(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca i64
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = getelementptr %"compiler/fmt:formatter", ptr %t2, i32 0, i32 6
  store ptr %t3, ptr %l5, !tbaa !29
  %t4 = load i64, ptr %l1, !tbaa !24
  store i64 %t4, ptr %l6, !tbaa !24
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i64, ptr %l6, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t5, i64 %t6)
  br label %bb1
bb1:
  %t7 = load ptr, ptr %l0, !tbaa !29
  store ptr %t7, ptr %l7, !tbaa !29
  %t8 = load ptr, ptr %l7, !tbaa !29
  %t9 = getelementptr %"compiler/fmt:formatter", ptr %t8, i32 0, i32 7
  store ptr %t9, ptr %l8, !tbaa !29
  %t10 = load i64, ptr %l2, !tbaa !24
  store i64 %t10, ptr %l9, !tbaa !24
  %t11 = load ptr, ptr %l8, !tbaa !29
  %t12 = load i64, ptr %l9, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t11, i64 %t12)
  br label %bb2
bb2:
  %t13 = load ptr, ptr %l0, !tbaa !29
  store ptr %t13, ptr %l10, !tbaa !29
  %t14 = load ptr, ptr %l10, !tbaa !29
  %t15 = getelementptr %"compiler/fmt:formatter", ptr %t14, i32 0, i32 8
  store ptr %t15, ptr %l11, !tbaa !29
  %t16 = load i64, ptr %l3, !tbaa !24
  store i64 %t16, ptr %l12, !tbaa !24
  %t17 = load ptr, ptr %l11, !tbaa !29
  %t18 = load i64, ptr %l12, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t17, i64 %t18)
  br label %bb3
bb3:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2ereceiver(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i32
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca i1
  %l14 = alloca i1
  %l15 = alloca ptr
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i32
  %l21 = alloca i32
  %l22 = alloca ptr
  %l23 = alloca i32
  %l24 = alloca ptr
  %l25 = alloca i1
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i32
  %l29 = alloca ptr
  %l30 = alloca i32
  %l31 = alloca ptr
  %l32 = alloca i1
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i1
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca ptr
  %l42 = alloca ptr
  %l43 = alloca i64
  %l44 = alloca i1
  %l45 = alloca i1
  %l46 = alloca ptr
  %l47 = alloca ptr
  %l48 = alloca i64
  %l49 = alloca i64
  %l50 = alloca i64
  %l51 = alloca ptr
  %l52 = alloca i64
  %l53 = alloca i32
  %l54 = alloca ptr
  %l55 = alloca i32
  %l56 = alloca ptr
  %l57 = alloca i1
  %l58 = alloca i1
  %l59 = alloca ptr
  %l60 = alloca i64
  %l61 = alloca i1
  %l62 = alloca i1
  %l63 = alloca ptr
  %l64 = alloca ptr
  %l65 = alloca ptr
  %l66 = alloca i64
  %l67 = alloca i64
  %l68 = alloca i64
  %l69 = alloca i32
  %l70 = alloca ptr
  %l71 = alloca i32
  %l72 = alloca ptr
  %l73 = alloca i1
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i64 0, ptr %l3, !tbaa !24
  %t1 = load i64, ptr %l2, !tbaa !24
  store i64 %t1, ptr %l7, !tbaa !24
  %t2 = load i64, ptr %l7, !tbaa !24
  %t3 = add i64 %t2, 1
  store i64 %t3, ptr %l8, !tbaa !24
  %t4 = load i64, ptr %l8, !tbaa !24
  store i64 %t4, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t5 = load i64, ptr %l4, !tbaa !24
  store i64 %t5, ptr %l9, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  store ptr %t6, ptr %l10, !tbaa !29
  %t7 = load ptr, ptr %l10, !tbaa !29
  %t8 = getelementptr %"compiler/fmt:formatter", ptr %t7, i32 0, i32 4
  store ptr %t8, ptr %l11, !tbaa !29
  %t9 = load ptr, ptr %l11, !tbaa !29
  %t10 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t9)
  store i64 %t10, ptr %l12
  br label %bb2
bb2:
  %t11 = load i64, ptr %l9, !tbaa !24
  %t12 = load i64, ptr %l12, !tbaa !24
  %t13 = icmp slt i64 %t11, %t12
  store i1 %t13, ptr %l13, !tbaa !21
  %t14 = load i1, ptr %l13, !tbaa !21
  %t15 = xor i1 %t14, true
  store i1 %t15, ptr %l14, !tbaa !21
  %t16 = load i1, ptr %l14, !tbaa !21
  br i1 %t16, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s1)
  br label %bb20
bb4:
  br label %bb5
bb5:
  %t17 = load ptr, ptr %l0, !tbaa !29
  store ptr %t17, ptr %l15, !tbaa !29
  %t18 = load ptr, ptr %l0, !tbaa !29
  store ptr %t18, ptr %l16, !tbaa !29
  %t19 = load ptr, ptr %l16, !tbaa !29
  %t20 = getelementptr %"compiler/fmt:formatter", ptr %t19, i32 0, i32 4
  store ptr %t20, ptr %l17, !tbaa !29
  %t21 = load i64, ptr %l4, !tbaa !24
  store i64 %t21, ptr %l18, !tbaa !24
  %t22 = load ptr, ptr %l17, !tbaa !29
  %t23 = load i64, ptr %l18, !tbaa !24
  %t24 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t22, i64 %t23)
  store i64 %t24, ptr %l19
  br label %bb6
bb6:
  %t25 = load ptr, ptr %l15, !tbaa !29
  %t26 = load i64, ptr %l19, !tbaa !24
  %t27 = call i32 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2ekind(ptr %v0, ptr %t25, i64 %t26)
  store i32 %t27, ptr %l20
  br label %bb7
bb7:
  %t28 = load i32, ptr %l20
  store i32 %t28, ptr %l5
  %t29 = load i32, ptr %l5
  store i32 %t29, ptr %l21
  store ptr %l21, ptr %l22, !tbaa !29
  store i32 90, ptr %l23
  store ptr %l23, ptr %l24, !tbaa !29
  %t30 = load ptr, ptr %l22, !tbaa !29
  %t31 = load ptr, ptr %l24, !tbaa !29
  %t32 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t30, ptr %t31)
  store i1 %t32, ptr %l25
  br label %bb8
bb8:
  %t33 = load i1, ptr %l25, !tbaa !21
  br i1 %t33, label %bb9, label %bb10
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t34 = load i64, ptr %l3, !tbaa !24
  store i64 %t34, ptr %l26, !tbaa !24
  %t35 = load i64, ptr %l26, !tbaa !24
  %t36 = add i64 %t35, 1
  store i64 %t36, ptr %l27, !tbaa !24
  %t37 = load i64, ptr %l27, !tbaa !24
  store i64 %t37, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb11
bb10:
  br label %bb11
bb11:
  %t38 = load i32, ptr %l5
  store i32 %t38, ptr %l28
  store ptr %l28, ptr %l29, !tbaa !29
  store i32 91, ptr %l30
  store ptr %l30, ptr %l31, !tbaa !29
  %t39 = load ptr, ptr %l29, !tbaa !29
  %t40 = load ptr, ptr %l31, !tbaa !29
  %t41 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t39, ptr %t40)
  store i1 %t41, ptr %l32
  br label %bb12
bb12:
  %t42 = load i1, ptr %l32, !tbaa !21
  br i1 %t42, label %bb13, label %bb14
bb13:
  store %olang.scope zeroinitializer, ptr %s3
  %t43 = load i64, ptr %l3, !tbaa !24
  store i64 %t43, ptr %l33, !tbaa !24
  %t44 = load i64, ptr %l33, !tbaa !24
  %t45 = sub i64 %t44, 1
  store i64 %t45, ptr %l34, !tbaa !24
  %t46 = load i64, ptr %l34, !tbaa !24
  store i64 %t46, ptr %l3, !tbaa !24
  %t47 = load i64, ptr %l3, !tbaa !24
  store i64 %t47, ptr %l35, !tbaa !24
  %t48 = load i64, ptr %l35, !tbaa !24
  %t49 = icmp eq i64 %t48, 0
  store i1 %t49, ptr %l36, !tbaa !21
  %t50 = load i1, ptr %l36, !tbaa !21
  br i1 %t50, label %bb15, label %bb16
bb14:
  br label %bb18
bb15:
  store %olang.scope zeroinitializer, ptr %s4
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s1)
  br label %bb20
bb16:
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s3)
  br label %bb18
bb18:
  %t51 = load i64, ptr %l4, !tbaa !24
  store i64 %t51, ptr %l37, !tbaa !24
  %t52 = load i64, ptr %l37, !tbaa !24
  %t53 = add i64 %t52, 1
  store i64 %t53, ptr %l38, !tbaa !24
  %t54 = load i64, ptr %l38, !tbaa !24
  store i64 %t54, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  br label %bb19
bb19:
  br label %bb1
bb20:
  %t55 = load i64, ptr %l4, !tbaa !24
  store i64 %t55, ptr %l39, !tbaa !24
  %t56 = load i64, ptr %l39, !tbaa !24
  %t57 = add i64 %t56, 2
  store i64 %t57, ptr %l40, !tbaa !24
  %t58 = load ptr, ptr %l0, !tbaa !29
  store ptr %t58, ptr %l41, !tbaa !29
  %t59 = load ptr, ptr %l41, !tbaa !29
  %t60 = getelementptr %"compiler/fmt:formatter", ptr %t59, i32 0, i32 4
  store ptr %t60, ptr %l42, !tbaa !29
  %t61 = load ptr, ptr %l42, !tbaa !29
  %t62 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t61)
  store i64 %t62, ptr %l43
  br label %bb21
bb21:
  %t63 = load i64, ptr %l40, !tbaa !24
  %t64 = load i64, ptr %l43, !tbaa !24
  %t65 = icmp sge i64 %t63, %t64
  store i1 %t65, ptr %l44, !tbaa !21
  %t66 = load i1, ptr %l44, !tbaa !21
  br i1 %t66, label %bb22, label %bb23
bb22:
  store %olang.scope zeroinitializer, ptr %s5
  store i1 false, ptr %l45, !tbaa !21
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  %t67 = load i1, ptr %l45, !tbaa !21
  store i1 %t67, ptr %rv
  br label %ret
bb23:
  br label %bb24
bb24:
  %t68 = load ptr, ptr %l0, !tbaa !29
  store ptr %t68, ptr %l46, !tbaa !29
  %t69 = load ptr, ptr %l46, !tbaa !29
  %t70 = getelementptr %"compiler/fmt:formatter", ptr %t69, i32 0, i32 4
  store ptr %t70, ptr %l47, !tbaa !29
  %t71 = load i64, ptr %l4, !tbaa !24
  store i64 %t71, ptr %l48, !tbaa !24
  %t72 = load i64, ptr %l48, !tbaa !24
  %t73 = add i64 %t72, 1
  store i64 %t73, ptr %l49, !tbaa !24
  %t74 = load ptr, ptr %l47, !tbaa !29
  %t75 = load i64, ptr %l49, !tbaa !24
  %t76 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t74, i64 %t75)
  store i64 %t76, ptr %l50
  br label %bb25
bb25:
  %t77 = load i64, ptr %l50, !tbaa !24
  store i64 %t77, ptr %l6, !tbaa !24
  %t78 = load ptr, ptr %l0, !tbaa !29
  store ptr %t78, ptr %l51, !tbaa !29
  %t79 = load i64, ptr %l6, !tbaa !24
  store i64 %t79, ptr %l52, !tbaa !24
  %t80 = load ptr, ptr %l51, !tbaa !29
  %t81 = load i64, ptr %l52, !tbaa !24
  %t82 = call i32 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2ekind(ptr %v0, ptr %t80, i64 %t81)
  store i32 %t82, ptr %l53
  br label %bb26
bb26:
  store ptr %l53, ptr %l54, !tbaa !29
  store i32 1, ptr %l55
  store ptr %l55, ptr %l56, !tbaa !29
  %t83 = load ptr, ptr %l54, !tbaa !29
  %t84 = load ptr, ptr %l56, !tbaa !29
  %t85 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t83, ptr %t84)
  store i1 %t85, ptr %l57
  br label %bb27
bb27:
  %t86 = load i1, ptr %l57, !tbaa !21
  br i1 %t86, label %bb28, label %bb29
bb28:
  store i1 true, ptr %l58, !tbaa !21
  br label %bb31
bb29:
  %t87 = load ptr, ptr %l0, !tbaa !29
  store ptr %t87, ptr %l59, !tbaa !29
  %t88 = load i64, ptr %l6, !tbaa !24
  store i64 %t88, ptr %l60, !tbaa !24
  %t89 = load ptr, ptr %l59, !tbaa !29
  %t90 = load i64, ptr %l60, !tbaa !24
  %t91 = call i1 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2ekeyword(ptr %v0, ptr %t89, i64 %t90)
  store i1 %t91, ptr %l61
  br label %bb30
bb30:
  %t92 = load i1, ptr %l61, !tbaa !21
  store i1 %t92, ptr %l58, !tbaa !21
  br label %bb31
bb31:
  %t93 = load i1, ptr %l58, !tbaa !21
  br i1 %t93, label %bb32, label %bb33
bb32:
  %t94 = load ptr, ptr %l0, !tbaa !29
  store ptr %t94, ptr %l63, !tbaa !29
  %t95 = load ptr, ptr %l0, !tbaa !29
  store ptr %t95, ptr %l64, !tbaa !29
  %t96 = load ptr, ptr %l64, !tbaa !29
  %t97 = getelementptr %"compiler/fmt:formatter", ptr %t96, i32 0, i32 4
  store ptr %t97, ptr %l65, !tbaa !29
  %t98 = load i64, ptr %l4, !tbaa !24
  store i64 %t98, ptr %l66, !tbaa !24
  %t99 = load i64, ptr %l66, !tbaa !24
  %t100 = add i64 %t99, 2
  store i64 %t100, ptr %l67, !tbaa !24
  %t101 = load ptr, ptr %l65, !tbaa !29
  %t102 = load i64, ptr %l67, !tbaa !24
  %t103 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t101, i64 %t102)
  store i64 %t103, ptr %l68
  br label %bb34
bb33:
  store i1 false, ptr %l62, !tbaa !21
  br label %bb37
bb34:
  %t104 = load ptr, ptr %l63, !tbaa !29
  %t105 = load i64, ptr %l68, !tbaa !24
  %t106 = call i32 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2ekind(ptr %v0, ptr %t104, i64 %t105)
  store i32 %t106, ptr %l69
  br label %bb35
bb35:
  store ptr %l69, ptr %l70, !tbaa !29
  store i32 90, ptr %l71
  store ptr %l71, ptr %l72, !tbaa !29
  %t107 = load ptr, ptr %l70, !tbaa !29
  %t108 = load ptr, ptr %l72, !tbaa !29
  %t109 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t107, ptr %t108)
  store i1 %t109, ptr %l73
  br label %bb36
bb36:
  %t110 = load i1, ptr %l73, !tbaa !21
  store i1 %t110, ptr %l62, !tbaa !21
  br label %bb37
bb37:
  call void @__olang_scope_close(ptr %s0)
  %t111 = load i1, ptr %l62, !tbaa !21
  store i1 %t111, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2erun(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i1
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i32
  %l9 = alloca %"std/prelude/list:List<I64>"
  %l10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i32
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i1
  %l32 = alloca ptr
  %l33 = alloca { i64, ptr }
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i1
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i1
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i64
  %l45 = alloca i64
  %l46 = alloca i64
  %l47 = alloca i64
  %l48 = alloca i64
  %l49 = alloca i64
  %l50 = alloca i64
  %l51 = alloca i64
  %l52 = alloca i1
  %l53 = alloca i1
  %l54 = alloca i64
  %l55 = alloca i64
  %l56 = alloca i64
  %l57 = alloca i64
  %l58 = alloca i64
  %l59 = alloca ptr
  %l60 = alloca { i64, ptr }
  %l61 = alloca i64
  %l62 = alloca i32
  %l63 = alloca i32
  %l64 = alloca ptr
  %l65 = alloca i32
  %l66 = alloca ptr
  %l67 = alloca i1
  %l68 = alloca i32
  %l69 = alloca ptr
  %l70 = alloca i32
  %l71 = alloca ptr
  %l72 = alloca i1
  %l73 = alloca i1
  %l74 = alloca ptr
  %l75 = alloca ptr
  %l76 = alloca i64
  %l77 = alloca ptr
  %l78 = alloca ptr
  %l79 = alloca i1
  %l80 = alloca i64
  %l81 = alloca i64
  %l82 = alloca %"std/prelude/list:List<I64>"
  %l83 = alloca ptr
  %l84 = alloca ptr
  %l85 = alloca { i64, ptr }
  %l86 = alloca ptr
  %l87 = alloca i64
  %l88 = alloca { i64, ptr }
  %l89 = alloca i32
  %l90 = alloca i32
  %l91 = alloca i1
  %l92 = alloca { i64, ptr }
  %l93 = alloca i64
  %l94 = alloca i64
  %l95 = alloca i64
  %l96 = alloca i1
  %l97 = alloca i1
  %l98 = alloca { i64, ptr }
  %l99 = alloca i64
  %l100 = alloca i64
  %l101 = alloca ptr
  %l102 = alloca i64
  %l103 = alloca i32
  %l104 = alloca i32
  %l105 = alloca ptr
  %l106 = alloca i32
  %l107 = alloca ptr
  %l108 = alloca i1
  %l109 = alloca ptr
  %l110 = alloca i64
  %l111 = alloca i32
  %l112 = alloca ptr
  %l113 = alloca i32
  %l114 = alloca ptr
  %l115 = alloca i1
  %l116 = alloca i1
  %l117 = alloca ptr
  %l118 = alloca i64
  %l119 = alloca i1
  %l120 = alloca ptr
  %l121 = alloca { i64, ptr }
  %l122 = alloca i64
  %l123 = alloca i64
  %l124 = alloca ptr
  %l125 = alloca i64
  %l126 = alloca i32
  %l127 = alloca i64
  %l128 = alloca i64
  %l129 = alloca i64
  %l130 = alloca i64
  %l131 = alloca i64
  %l132 = alloca i64
  %l133 = alloca ptr
  %l134 = alloca ptr
  %l135 = alloca i64
  %l136 = alloca i1
  %l137 = alloca i1
  %l138 = alloca ptr
  %l139 = alloca ptr
  %l140 = alloca i64
  %l141 = alloca i64
  %l142 = alloca ptr
  %l143 = alloca ptr
  %l144 = alloca { i64, ptr }
  %l145 = alloca i64
  %l146 = alloca i32
  %l147 = alloca i64
  %l148 = alloca i64
  %l149 = alloca i64
  %l150 = alloca i1
  %l151 = alloca ptr
  %l152 = alloca ptr
  %l153 = alloca i64
  %l154 = alloca i64
  %l155 = alloca ptr
  %l156 = alloca ptr
  %l157 = alloca i64
  %l158 = alloca i64
  %l159 = alloca ptr
  %l160 = alloca ptr
  %l161 = alloca i64
  %l162 = alloca i64
  %l163 = alloca i64
  %l164 = alloca i1
  %l165 = alloca i64
  %l166 = alloca i64
  %l167 = alloca i1
  %l168 = alloca i64
  %l169 = alloca i64
  %l170 = alloca i64
  %l171 = alloca i64
  %l172 = alloca i64
  %l173 = alloca i64
  %l174 = alloca i64
  %l175 = alloca i64
  %l176 = alloca i64
  %l177 = alloca i64
  %l178 = alloca i64
  %l179 = alloca i1
  %l180 = alloca i1
  %l181 = alloca i64
  %l182 = alloca i64
  %l183 = alloca i64
  %l184 = alloca i64
  %l185 = alloca i64
  %l186 = alloca ptr
  %l187 = alloca ptr
  %l188 = alloca i64
  %l189 = alloca i64
  %l190 = alloca i64
  %l191 = alloca i1
  %l192 = alloca i1
  %l193 = alloca ptr
  %l194 = alloca ptr
  %l195 = alloca i64
  %l196 = alloca i64
  %l197 = alloca i64
  %l198 = alloca i1
  %l199 = alloca ptr
  %l200 = alloca ptr
  %l201 = alloca i64
  %l202 = alloca i64
  %l203 = alloca i64
  %l204 = alloca i64
  %l205 = alloca ptr
  %l206 = alloca i64
  %l207 = alloca i64
  %l208 = alloca i64
  %l209 = alloca ptr
  %l210 = alloca i1
  %l211 = alloca ptr
  %l212 = alloca i64
  %l213 = alloca i64
  %l214 = alloca i64
  %l215 = alloca i1
  %l216 = alloca i1
  %l217 = alloca i64
  %l218 = alloca ptr
  %l219 = alloca { i64, ptr }
  %l220 = alloca i64
  %l221 = alloca i64
  %l222 = alloca i1
  %l223 = alloca i1
  %l224 = alloca ptr
  %l225 = alloca { i64, ptr }
  %l226 = alloca i64
  %l227 = alloca i64
  %l228 = alloca ptr
  %l229 = alloca ptr
  %l230 = alloca ptr
  %l231 = alloca ptr
  %l232 = alloca ptr
  %l233 = alloca { i64, ptr }
  %l234 = alloca i64
  %l235 = alloca i64
  %l236 = alloca i64
  %l237 = alloca i1
  %l238 = alloca i1
  %l239 = alloca i1
  %l240 = alloca { i64, ptr }
  %l241 = alloca i64
  %l242 = alloca ptr
  %l243 = alloca ptr
  %l244 = alloca i64
  %l245 = alloca i1
  %l246 = alloca i1
  %l247 = alloca ptr
  %l248 = alloca { i64, ptr }
  %l249 = alloca ptr
  %l250 = alloca ptr
  %l251 = alloca i64
  %l252 = alloca i64
  %l253 = alloca i32
  %l254 = alloca i64
  %l255 = alloca i64
  %l256 = alloca i1
  %l257 = alloca i1
  %l258 = alloca i1
  %l259 = alloca ptr
  %l260 = alloca i64
  %l261 = alloca i64
  %l262 = alloca ptr
  %l263 = alloca ptr
  %l264 = alloca ptr
  %l265 = alloca i64
  %l266 = alloca i64
  %l267 = alloca ptr
  %l268 = alloca ptr
  %l269 = alloca ptr
  %l270 = alloca i64
  %l271 = alloca i64
  %l272 = alloca i64
  %l273 = alloca i64
  %l274 = alloca ptr
  %l275 = alloca i64
  %l276 = alloca i64
  %l277 = alloca i64
  %l278 = alloca ptr
  %l279 = alloca { i64, ptr }
  %l280 = alloca i64
  %l281 = alloca i1
  %l282 = alloca i64
  %l283 = alloca i64
  %l284 = alloca ptr
  %l285 = alloca { i64, ptr }
  %l286 = alloca i64
  %l287 = alloca ptr
  %l288 = alloca i64
  %l289 = alloca ptr
  %l290 = alloca { i64, ptr }
  %l291 = alloca i64
  %l292 = alloca i32
  %l293 = alloca i64
  %l294 = alloca i64
  %l295 = alloca ptr
  %l296 = alloca i64
  %l297 = alloca ptr
  %l298 = alloca { i64, ptr }
  %l299 = alloca i64
  %l300 = alloca i32
  %l301 = alloca i64
  %l302 = alloca i64
  %l303 = alloca i64
  %l304 = alloca ptr
  %l305 = alloca i64
  %l306 = alloca ptr
  %l307 = alloca { i64, ptr }
  %l308 = alloca i64
  %l309 = alloca ptr
  %l310 = alloca i1
  %l311 = alloca ptr
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %s23 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i1 false, ptr %l1, !tbaa !21
  store %olang.scope zeroinitializer, ptr %s1
  store i64 0, ptr %l2, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l32, !tbaa !29
  %t2 = load ptr, ptr %l32, !tbaa !29
  %t3 = getelementptr %"compiler/fmt:formatter", ptr %t2, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l33, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l34, !tbaa !24
  %t7 = load i64, ptr %l34, !tbaa !24
  store i64 %t7, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t8 = load i64, ptr %l3, !tbaa !24
  store i64 %t8, ptr %l35, !tbaa !24
  %t9 = load i64, ptr %l2, !tbaa !24
  store i64 %t9, ptr %l36, !tbaa !24
  %t10 = load i64, ptr %l35, !tbaa !24
  %t11 = load i64, ptr %l36, !tbaa !24
  %t12 = icmp sgt i64 %t10, %t11
  store i1 %t12, ptr %l37, !tbaa !21
  %t13 = load i1, ptr %l37, !tbaa !21
  br i1 %t13, label %bb1, label %bb2
bb1:
  %t14 = load i64, ptr %l4, !tbaa !24
  store i64 %t14, ptr %l39, !tbaa !24
  %t15 = load i64, ptr %l39, !tbaa !24
  %t16 = icmp sgt i64 %t15, 0
  store i1 %t16, ptr %l40, !tbaa !21
  %t17 = load i1, ptr %l40, !tbaa !21
  br i1 %t17, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l38, !tbaa !24
  br label %bb6
bb3:
  %t18 = load i64, ptr %l3, !tbaa !24
  store i64 %t18, ptr %l42, !tbaa !24
  %t19 = load i64, ptr %l2, !tbaa !24
  store i64 %t19, ptr %l43, !tbaa !24
  %t20 = load i64, ptr %l42, !tbaa !24
  %t21 = load i64, ptr %l43, !tbaa !24
  %t22 = sub i64 %t20, %t21
  store i64 %t22, ptr %l44, !tbaa !24
  %t23 = load i64, ptr %l4, !tbaa !24
  store i64 %t23, ptr %l45, !tbaa !24
  %t24 = load i64, ptr %l44, !tbaa !24
  %t25 = load i64, ptr %l45, !tbaa !24
  %t26 = add i64 %t24, %t25
  store i64 %t26, ptr %l46, !tbaa !24
  %t27 = load i64, ptr %l46, !tbaa !24
  %t28 = sub i64 %t27, 1
  store i64 %t28, ptr %l47, !tbaa !24
  %t29 = load i64, ptr %l4, !tbaa !24
  store i64 %t29, ptr %l48, !tbaa !24
  %t30 = load i64, ptr %l47, !tbaa !24
  %t31 = load i64, ptr %l48, !tbaa !24
  %t32 = sdiv i64 %t30, %t31
  store i64 %t32, ptr %l49, !tbaa !24
  %t33 = load i64, ptr %l49, !tbaa !24
  store i64 %t33, ptr %l41, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l41, !tbaa !24
  br label %bb5
bb5:
  %t34 = load i64, ptr %l41, !tbaa !24
  store i64 %t34, ptr %l38, !tbaa !24
  br label %bb6
bb6:
  %t35 = load i64, ptr %l38, !tbaa !24
  store i64 %t35, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t36 = load i64, ptr %l6, !tbaa !24
  store i64 %t36, ptr %l50, !tbaa !24
  %t37 = load i64, ptr %l5, !tbaa !24
  store i64 %t37, ptr %l51, !tbaa !24
  %t38 = load i64, ptr %l50, !tbaa !24
  %t39 = load i64, ptr %l51, !tbaa !24
  %t40 = icmp slt i64 %t38, %t39
  store i1 %t40, ptr %l52, !tbaa !21
  %t41 = load i1, ptr %l52, !tbaa !21
  %t42 = xor i1 %t41, true
  store i1 %t42, ptr %l53, !tbaa !21
  %t43 = load i1, ptr %l53, !tbaa !21
  br i1 %t43, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb22
bb9:
  br label %bb10
bb10:
  %t44 = load i64, ptr %l2, !tbaa !24
  store i64 %t44, ptr %l54, !tbaa !24
  %t45 = load i64, ptr %l6, !tbaa !24
  store i64 %t45, ptr %l55, !tbaa !24
  %t46 = load i64, ptr %l4, !tbaa !24
  store i64 %t46, ptr %l56, !tbaa !24
  %t47 = load i64, ptr %l55, !tbaa !24
  %t48 = load i64, ptr %l56, !tbaa !24
  %t49 = mul i64 %t47, %t48
  store i64 %t49, ptr %l57, !tbaa !24
  %t50 = load i64, ptr %l54, !tbaa !24
  %t51 = load i64, ptr %l57, !tbaa !24
  %t52 = add i64 %t50, %t51
  store i64 %t52, ptr %l58, !tbaa !24
  %t53 = load i64, ptr %l58, !tbaa !24
  store i64 %t53, ptr %l7, !tbaa !24
  %t54 = load ptr, ptr %l0, !tbaa !29
  store ptr %t54, ptr %l59, !tbaa !29
  %t55 = load ptr, ptr %l59, !tbaa !29
  %t56 = getelementptr %"compiler/fmt:formatter", ptr %t55, i32 0, i32 1
  %t57 = load { i64, ptr }, ptr %t56, !tbaa !27
  store { i64, ptr } %t57, ptr %l60, !tbaa !27
  %t58 = load i64, ptr %l7, !tbaa !24
  store i64 %t58, ptr %l61, !tbaa !24
  %t59 = load i64, ptr %l61, !tbaa !24
  %t60 = getelementptr { i64, ptr }, ptr %l60, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !27
  %t62 = getelementptr %"compiler/token:Token", ptr %t61, i64 %t59
  %t63 = getelementptr %"compiler/token:Token", ptr %t62, i32 0, i32 0
  %t64 = load i32, ptr %t63
  store i32 %t64, ptr %l62
  %t65 = load i32, ptr %l62
  store i32 %t65, ptr %l8
  %t66 = load i32, ptr %l8
  store i32 %t66, ptr %l63
  store ptr %l63, ptr %l64, !tbaa !29
  store i32 8, ptr %l65
  store ptr %l65, ptr %l66, !tbaa !29
  %t67 = load ptr, ptr %l64, !tbaa !29
  %t68 = load ptr, ptr %l66, !tbaa !29
  %t69 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t67, ptr %t68)
  store i1 %t69, ptr %l67
  br label %bb11
bb11:
  %t70 = load i1, ptr %l67, !tbaa !21
  br i1 %t70, label %bb12, label %bb13
bb12:
  store %olang.scope zeroinitializer, ptr %s3
  store i1 true, ptr %l1, !tbaa !21
  call void @__olang_scope_close(ptr %s3)
  br label %bb20
bb13:
  store %olang.scope zeroinitializer, ptr %s4
  %t71 = load i32, ptr %l8
  store i32 %t71, ptr %l68
  store ptr %l68, ptr %l69, !tbaa !29
  store i32 0, ptr %l70
  store ptr %l70, ptr %l71, !tbaa !29
  %t72 = load ptr, ptr %l69, !tbaa !29
  %t73 = load ptr, ptr %l71, !tbaa !29
  %t74 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t72, ptr %t73)
  store i1 %t74, ptr %l72
  br label %bb14
bb14:
  %t75 = load i1, ptr %l72, !tbaa !21
  %t76 = xor i1 %t75, true
  store i1 %t76, ptr %l73, !tbaa !21
  %t77 = load i1, ptr %l73, !tbaa !21
  br i1 %t77, label %bb15, label %bb16
bb15:
  store %olang.scope zeroinitializer, ptr %s5
  %t78 = load ptr, ptr %l0, !tbaa !29
  store ptr %t78, ptr %l74, !tbaa !29
  %t79 = load ptr, ptr %l74, !tbaa !29
  %t80 = getelementptr %"compiler/fmt:formatter", ptr %t79, i32 0, i32 4
  store ptr %t80, ptr %l75, !tbaa !29
  %t81 = load i64, ptr %l7, !tbaa !24
  store i64 %t81, ptr %l76, !tbaa !24
  %t82 = load ptr, ptr %l75, !tbaa !29
  %t83 = load i64, ptr %l76, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t82, i64 %t83)
  br label %bb17
bb16:
  br label %bb19
bb17:
  %t84 = load ptr, ptr %l0, !tbaa !29
  store ptr %t84, ptr %l77, !tbaa !29
  %t85 = load ptr, ptr %l77, !tbaa !29
  %t86 = getelementptr %"compiler/fmt:formatter", ptr %t85, i32 0, i32 5
  store ptr %t86, ptr %l78, !tbaa !29
  %t87 = load i1, ptr %l1, !tbaa !21
  store i1 %t87, ptr %l79, !tbaa !21
  %t88 = load ptr, ptr %l78, !tbaa !29
  %t89 = load i1, ptr %l79, !tbaa !21
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t88, i1 %t89)
  br label %bb18
bb18:
  store i1 false, ptr %l1, !tbaa !21
  call void @__olang_scope_close(ptr %s5)
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s4)
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s2)
  br label %bb21
bb21:
  store %olang.scope zeroinitializer, ptr %s6
  %t90 = load i64, ptr %l6, !tbaa !24
  store i64 %t90, ptr %l80, !tbaa !24
  %t91 = load i64, ptr %l80, !tbaa !24
  %t92 = add i64 %t91, 1
  store i64 %t92, ptr %l81, !tbaa !24
  %t93 = load i64, ptr %l81, !tbaa !24
  store i64 %t93, ptr %l6, !tbaa !24
  call void @__olang_scope_close(ptr %s6)
  br label %bb7
bb22:
  call void @__olang_scope_close(ptr %s1)
  %t94 = load ptr, ptr @__olang_prog_scope
  %t95 = call %"std/prelude/list:List<I64>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t94)
  store %"std/prelude/list:List<I64>" %t95, ptr %l82
  br label %bb23
bb23:
  %t96 = load %"std/prelude/list:List<I64>", ptr %l82
  store %"std/prelude/list:List<I64>" %t96, ptr %l9
  store %olang.scope zeroinitializer, ptr %s7
  %t97 = load ptr, ptr %l0, !tbaa !29
  store ptr %t97, ptr %l83, !tbaa !29
  %t98 = load ptr, ptr %l83, !tbaa !29
  %t99 = getelementptr %"compiler/fmt:formatter", ptr %t98, i32 0, i32 4
  store ptr %t99, ptr %l84, !tbaa !29
  %t100 = load ptr, ptr %l84, !tbaa !29
  store ptr %t100, ptr %l10, !tbaa !29
  store i64 0, ptr %l11, !tbaa !24
  br label %bb24
bb24:
  store %olang.scope zeroinitializer, ptr %s8
  %t101 = load ptr, ptr %l10, !tbaa !29
  store ptr %t101, ptr %l86, !tbaa !29
  %t102 = load i64, ptr %l11, !tbaa !24
  store i64 %t102, ptr %l87, !tbaa !24
  %t103 = load ptr, ptr %l86, !tbaa !29
  %t104 = load i64, ptr %l87, !tbaa !24
  %t105 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %v0, ptr %t103, i64 %t104)
  %t106 = extractvalue { i32, { i64, ptr } } %t105, 1
  %t107 = extractvalue { i32, { i64, ptr } } %t105, 0
  store i32 %t107, ptr %l89
  %t108 = icmp ne i32 %t107, 0
  br i1 %t108, label %bb26, label %ok.109
ok.109:
  store { i64, ptr } %t106, ptr %l88
  br label %bb25
bb25:
  %t110 = load { i64, ptr }, ptr %l88, !tbaa !27
  store { i64, ptr } %t110, ptr %l85, !tbaa !27
  br label %bb30
bb26:
  %t111 = load i32, ptr %l89, !tbaa !23
  %t112 = ashr i32 %t111, 16
  store i32 %t112, ptr %l90, !tbaa !23
  %t113 = load i32, ptr %l90, !tbaa !23
  %t114 = icmp eq i32 %t113, 1
  store i1 %t114, ptr %l91, !tbaa !21
  %t115 = load i1, ptr %l91, !tbaa !21
  br i1 %t115, label %bb27, label %bb28
bb27:
  br label %bb29
bb28:
  call void @__olang_check_failed(ptr @.c16)
  unreachable
bb29:
  call void @__olang_scope_close(ptr %s8)
  br label %bb56
bb30:
  %t116 = load { i64, ptr }, ptr %l85, !tbaa !27
  store { i64, ptr } %t116, ptr %l12, !tbaa !27
  %t117 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t117, ptr %l92, !tbaa !27
  %t118 = load { i64, ptr }, ptr %l92, !tbaa !27
  %t119 = extractvalue { i64, ptr } %t118, 0
  store i64 %t119, ptr %l93, !tbaa !24
  %t120 = load i64, ptr %l93, !tbaa !24
  store i64 %t120, ptr %l13, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  br label %bb31
bb31:
  store %olang.scope zeroinitializer, ptr %s9
  %t121 = load i64, ptr %l14, !tbaa !24
  store i64 %t121, ptr %l94, !tbaa !24
  %t122 = load i64, ptr %l13, !tbaa !24
  store i64 %t122, ptr %l95, !tbaa !24
  %t123 = load i64, ptr %l94, !tbaa !24
  %t124 = load i64, ptr %l95, !tbaa !24
  %t125 = icmp slt i64 %t123, %t124
  store i1 %t125, ptr %l96, !tbaa !21
  %t126 = load i1, ptr %l96, !tbaa !21
  %t127 = xor i1 %t126, true
  store i1 %t127, ptr %l97, !tbaa !21
  %t128 = load i1, ptr %l97, !tbaa !21
  br i1 %t128, label %bb32, label %bb33
bb32:
  call void @__olang_scope_close(ptr %s9)
  br label %bb54
bb33:
  br label %bb34
bb34:
  %t129 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t129, ptr %l98, !tbaa !27
  %t130 = load i64, ptr %l14, !tbaa !24
  store i64 %t130, ptr %l99, !tbaa !24
  %t131 = load i64, ptr %l99, !tbaa !24
  %t132 = getelementptr { i64, ptr }, ptr %l98, i32 0, i32 1
  %t133 = load ptr, ptr %t132, !tbaa !27
  %t134 = getelementptr i64, ptr %t133, i64 %t131
  %t135 = load i64, ptr %t134, !tbaa !34
  store i64 %t135, ptr %l100, !tbaa !24
  %t136 = load i64, ptr %l100, !tbaa !24
  store i64 %t136, ptr %l15, !tbaa !24
  %t137 = load ptr, ptr %l0, !tbaa !29
  store ptr %t137, ptr %l101, !tbaa !29
  %t138 = load i64, ptr %l15, !tbaa !24
  store i64 %t138, ptr %l102, !tbaa !24
  %t139 = load ptr, ptr %l101, !tbaa !29
  %t140 = load i64, ptr %l102, !tbaa !24
  %t141 = call i32 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2ekind(ptr %v0, ptr %t139, i64 %t140)
  store i32 %t141, ptr %l103
  br label %bb35
bb35:
  %t142 = load i32, ptr %l103
  store i32 %t142, ptr %l16
  %t143 = load i32, ptr %l16
  store i32 %t143, ptr %l104
  store ptr %l104, ptr %l105, !tbaa !29
  store i32 90, ptr %l106
  store ptr %l106, ptr %l107, !tbaa !29
  %t144 = load ptr, ptr %l105, !tbaa !29
  %t145 = load ptr, ptr %l107, !tbaa !29
  %t146 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t144, ptr %t145)
  store i1 %t146, ptr %l108
  br label %bb36
bb36:
  %t147 = load i1, ptr %l108, !tbaa !21
  br i1 %t147, label %bb37, label %bb38
bb37:
  store %olang.scope zeroinitializer, ptr %s10
  store ptr %l9, ptr %l109, !tbaa !29
  %t148 = load i64, ptr %l15, !tbaa !24
  store i64 %t148, ptr %l110, !tbaa !24
  %t149 = load ptr, ptr %l109, !tbaa !29
  %t150 = load i64, ptr %l110, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %t149, i64 %t150)
  br label %bb39
bb38:
  br label %bb40
bb39:
  call void @__olang_scope_close(ptr %s10)
  br label %bb40
bb40:
  %t151 = load i32, ptr %l16
  store i32 %t151, ptr %l111
  store ptr %l111, ptr %l112, !tbaa !29
  store i32 91, ptr %l113
  store ptr %l113, ptr %l114, !tbaa !29
  %t152 = load ptr, ptr %l112, !tbaa !29
  %t153 = load ptr, ptr %l114, !tbaa !29
  %t154 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t152, ptr %t153)
  store i1 %t154, ptr %l115
  br label %bb41
bb41:
  %t155 = load i1, ptr %l115, !tbaa !21
  br i1 %t155, label %bb42, label %bb43
bb42:
  store ptr %l9, ptr %l117, !tbaa !29
  %t156 = load ptr, ptr %l117, !tbaa !29
  %t157 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t156)
  store i64 %t157, ptr %l118
  br label %bb44
bb43:
  store i1 false, ptr %l116, !tbaa !21
  br label %bb45
bb44:
  %t158 = load i64, ptr %l118, !tbaa !24
  %t159 = icmp sgt i64 %t158, 0
  store i1 %t159, ptr %l119, !tbaa !21
  %t160 = load i1, ptr %l119, !tbaa !21
  store i1 %t160, ptr %l116, !tbaa !21
  br label %bb45
bb45:
  %t161 = load i1, ptr %l116, !tbaa !21
  br i1 %t161, label %bb46, label %bb47
bb46:
  store %olang.scope zeroinitializer, ptr %s11
  %t162 = load ptr, ptr %l0, !tbaa !29
  store ptr %t162, ptr %l120, !tbaa !29
  %t163 = load ptr, ptr %l120, !tbaa !29
  %t164 = getelementptr %"compiler/fmt:formatter", ptr %t163, i32 0, i32 20
  %t165 = load { i64, ptr }, ptr %t164, !tbaa !27
  store { i64, ptr } %t165, ptr %l121, !tbaa !27
  %t166 = load i64, ptr %l15, !tbaa !24
  store i64 %t166, ptr %l122, !tbaa !24
  store ptr %l9, ptr %l124, !tbaa !29
  %t167 = load ptr, ptr %l124, !tbaa !29
  %t168 = call { i32, i64 } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePop_3cI64_3e(ptr %s0, ptr %t167)
  %t169 = extractvalue { i32, i64 } %t168, 1
  %t170 = extractvalue { i32, i64 } %t168, 0
  store i32 %t170, ptr %l126
  %t171 = icmp ne i32 %t170, 0
  br i1 %t171, label %bb49, label %ok.172
ok.172:
  store i64 %t169, ptr %l125
  br label %bb48
bb47:
  br label %bb52
bb48:
  %t173 = load i64, ptr %l125, !tbaa !24
  store i64 %t173, ptr %l123, !tbaa !24
  br label %bb51
bb49:
  br label %bb50
bb50:
  store i64 0, ptr %l123, !tbaa !24
  br label %bb51
bb51:
  %t174 = load i64, ptr %l123, !tbaa !24
  %t175 = load i64, ptr %l122, !tbaa !24
  %t176 = getelementptr { i64, ptr }, ptr %l121, i32 0, i32 1
  %t177 = load ptr, ptr %t176, !tbaa !27
  %t178 = getelementptr i64, ptr %t177, i64 %t175
  store i64 %t174, ptr %t178, !tbaa !34
  call void @__olang_scope_close(ptr %s11)
  br label %bb52
bb52:
  call void @__olang_scope_close(ptr %s9)
  br label %bb53
bb53:
  store %olang.scope zeroinitializer, ptr %s12
  %t179 = load i64, ptr %l14, !tbaa !24
  store i64 %t179, ptr %l127, !tbaa !24
  %t180 = load i64, ptr %l127, !tbaa !24
  %t181 = add i64 %t180, 1
  store i64 %t181, ptr %l128, !tbaa !24
  %t182 = load i64, ptr %l128, !tbaa !24
  store i64 %t182, ptr %l14, !tbaa !24
  call void @__olang_scope_close(ptr %s12)
  br label %bb31
bb54:
  %t183 = load i64, ptr %l11, !tbaa !24
  store i64 %t183, ptr %l129, !tbaa !24
  %t184 = load i64, ptr %l13, !tbaa !24
  store i64 %t184, ptr %l130, !tbaa !24
  %t185 = load i64, ptr %l129, !tbaa !24
  %t186 = load i64, ptr %l130, !tbaa !24
  %t187 = add i64 %t185, %t186
  store i64 %t187, ptr %l131, !tbaa !24
  %t188 = load i64, ptr %l131, !tbaa !24
  store i64 %t188, ptr %l11, !tbaa !24
  call void @__olang_scope_close(ptr %s8)
  br label %bb55
bb55:
  br label %bb24
bb56:
  call void @__olang_scope_close(ptr %s7)
  store i64 0, ptr %l17, !tbaa !24
  store i64 0, ptr %l18, !tbaa !24
  br label %bb57
bb57:
  store %olang.scope zeroinitializer, ptr %s13
  %t189 = load i64, ptr %l18, !tbaa !24
  store i64 %t189, ptr %l132, !tbaa !24
  %t190 = load ptr, ptr %l0, !tbaa !29
  store ptr %t190, ptr %l133, !tbaa !29
  %t191 = load ptr, ptr %l133, !tbaa !29
  %t192 = getelementptr %"compiler/fmt:formatter", ptr %t191, i32 0, i32 4
  store ptr %t192, ptr %l134, !tbaa !29
  %t193 = load ptr, ptr %l134, !tbaa !29
  %t194 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t193)
  store i64 %t194, ptr %l135
  br label %bb58
bb58:
  %t195 = load i64, ptr %l132, !tbaa !24
  %t196 = load i64, ptr %l135, !tbaa !24
  %t197 = icmp slt i64 %t195, %t196
  store i1 %t197, ptr %l136, !tbaa !21
  %t198 = load i1, ptr %l136, !tbaa !21
  %t199 = xor i1 %t198, true
  store i1 %t199, ptr %l137, !tbaa !21
  %t200 = load i1, ptr %l137, !tbaa !21
  br i1 %t200, label %bb59, label %bb60
bb59:
  call void @__olang_scope_close(ptr %s13)
  br label %bb139
bb60:
  br label %bb61
bb61:
  %t201 = load ptr, ptr %l0, !tbaa !29
  store ptr %t201, ptr %l138, !tbaa !29
  %t202 = load ptr, ptr %l138, !tbaa !29
  %t203 = getelementptr %"compiler/fmt:formatter", ptr %t202, i32 0, i32 4
  store ptr %t203, ptr %l139, !tbaa !29
  %t204 = load i64, ptr %l18, !tbaa !24
  store i64 %t204, ptr %l140, !tbaa !24
  %t205 = load ptr, ptr %l139, !tbaa !29
  %t206 = load i64, ptr %l140, !tbaa !24
  %t207 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t205, i64 %t206)
  store i64 %t207, ptr %l141
  br label %bb62
bb62:
  %t208 = load i64, ptr %l141, !tbaa !24
  store i64 %t208, ptr %l19, !tbaa !24
  %t209 = load ptr, ptr %l0, !tbaa !29
  store ptr %t209, ptr %l142, !tbaa !29
  %t210 = load ptr, ptr %l0, !tbaa !29
  store ptr %t210, ptr %l143, !tbaa !29
  %t211 = load ptr, ptr %l143, !tbaa !29
  %t212 = getelementptr %"compiler/fmt:formatter", ptr %t211, i32 0, i32 1
  %t213 = load { i64, ptr }, ptr %t212, !tbaa !27
  store { i64, ptr } %t213, ptr %l144, !tbaa !27
  %t214 = load i64, ptr %l19, !tbaa !24
  store i64 %t214, ptr %l145, !tbaa !24
  %t215 = load i64, ptr %l145, !tbaa !24
  %t216 = getelementptr { i64, ptr }, ptr %l144, i32 0, i32 1
  %t217 = load ptr, ptr %t216, !tbaa !27
  %t218 = getelementptr %"compiler/token:Token", ptr %t217, i64 %t215
  %t219 = getelementptr %"compiler/token:Token", ptr %t218, i32 0, i32 2
  %t220 = load i32, ptr %t219, !tbaa !23
  store i32 %t220, ptr %l146, !tbaa !23
  %t221 = load i32, ptr %l146, !tbaa !23
  %t222 = sext i32 %t221 to i64
  store i64 %t222, ptr %l147, !tbaa !24
  %t223 = load ptr, ptr %l142, !tbaa !29
  %t224 = load i64, ptr %l147, !tbaa !24
  %t225 = call i64 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2eheldAt(ptr %v0, ptr %t223, i64 %t224)
  store i64 %t225, ptr %l148
  br label %bb63
bb63:
  %t226 = load i64, ptr %l148, !tbaa !24
  store i64 %t226, ptr %l20, !tbaa !24
  %t227 = load i64, ptr %l20, !tbaa !24
  store i64 %t227, ptr %l149, !tbaa !24
  %t228 = load i64, ptr %l149, !tbaa !24
  %t229 = icmp sge i64 %t228, 0
  store i1 %t229, ptr %l150, !tbaa !21
  %t230 = load i1, ptr %l150, !tbaa !21
  br i1 %t230, label %bb64, label %bb65
bb64:
  store %olang.scope zeroinitializer, ptr %s14
  %t231 = load ptr, ptr %l0, !tbaa !29
  store ptr %t231, ptr %l151, !tbaa !29
  %t232 = load ptr, ptr %l151, !tbaa !29
  %t233 = getelementptr %"compiler/fmt:formatter", ptr %t232, i32 0, i32 29
  store ptr %t233, ptr %l152, !tbaa !29
  %t234 = load i64, ptr %l20, !tbaa !24
  store i64 %t234, ptr %l153, !tbaa !24
  %t235 = load ptr, ptr %l152, !tbaa !29
  %t236 = load i64, ptr %l153, !tbaa !24
  %t237 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t235, i64 %t236)
  store i64 %t237, ptr %l154
  br label %bb66
bb65:
  br label %bb135
bb66:
  %t238 = load i64, ptr %l154, !tbaa !24
  store i64 %t238, ptr %l21, !tbaa !24
  %t239 = load ptr, ptr %l0, !tbaa !29
  store ptr %t239, ptr %l155, !tbaa !29
  %t240 = load ptr, ptr %l155, !tbaa !29
  %t241 = getelementptr %"compiler/fmt:formatter", ptr %t240, i32 0, i32 30
  store ptr %t241, ptr %l156, !tbaa !29
  %t242 = load i64, ptr %l20, !tbaa !24
  store i64 %t242, ptr %l157, !tbaa !24
  %t243 = load ptr, ptr %l156, !tbaa !29
  %t244 = load i64, ptr %l157, !tbaa !24
  %t245 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t243, i64 %t244)
  store i64 %t245, ptr %l158
  br label %bb67
bb67:
  %t246 = load i64, ptr %l158, !tbaa !24
  store i64 %t246, ptr %l22, !tbaa !24
  store %olang.scope zeroinitializer, ptr %s15
  store i64 0, ptr %l23, !tbaa !24
  %t247 = load ptr, ptr %l0, !tbaa !29
  store ptr %t247, ptr %l159, !tbaa !29
  %t248 = load ptr, ptr %l159, !tbaa !29
  %t249 = getelementptr %"compiler/fmt:formatter", ptr %t248, i32 0, i32 29
  store ptr %t249, ptr %l160, !tbaa !29
  %t250 = load ptr, ptr %l160, !tbaa !29
  %t251 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t250)
  store i64 %t251, ptr %l161
  br label %bb68
bb68:
  %t252 = load i64, ptr %l161, !tbaa !24
  store i64 %t252, ptr %l24, !tbaa !24
  store i64 1, ptr %l25, !tbaa !24
  %t253 = load i64, ptr %l24, !tbaa !24
  store i64 %t253, ptr %l162, !tbaa !24
  %t254 = load i64, ptr %l23, !tbaa !24
  store i64 %t254, ptr %l163, !tbaa !24
  %t255 = load i64, ptr %l162, !tbaa !24
  %t256 = load i64, ptr %l163, !tbaa !24
  %t257 = icmp sgt i64 %t255, %t256
  store i1 %t257, ptr %l164, !tbaa !21
  %t258 = load i1, ptr %l164, !tbaa !21
  br i1 %t258, label %bb69, label %bb70
bb69:
  %t259 = load i64, ptr %l25, !tbaa !24
  store i64 %t259, ptr %l166, !tbaa !24
  %t260 = load i64, ptr %l166, !tbaa !24
  %t261 = icmp sgt i64 %t260, 0
  store i1 %t261, ptr %l167, !tbaa !21
  %t262 = load i1, ptr %l167, !tbaa !21
  br i1 %t262, label %bb71, label %bb72
bb70:
  store i64 0, ptr %l165, !tbaa !24
  br label %bb74
bb71:
  %t263 = load i64, ptr %l24, !tbaa !24
  store i64 %t263, ptr %l169, !tbaa !24
  %t264 = load i64, ptr %l23, !tbaa !24
  store i64 %t264, ptr %l170, !tbaa !24
  %t265 = load i64, ptr %l169, !tbaa !24
  %t266 = load i64, ptr %l170, !tbaa !24
  %t267 = sub i64 %t265, %t266
  store i64 %t267, ptr %l171, !tbaa !24
  %t268 = load i64, ptr %l25, !tbaa !24
  store i64 %t268, ptr %l172, !tbaa !24
  %t269 = load i64, ptr %l171, !tbaa !24
  %t270 = load i64, ptr %l172, !tbaa !24
  %t271 = add i64 %t269, %t270
  store i64 %t271, ptr %l173, !tbaa !24
  %t272 = load i64, ptr %l173, !tbaa !24
  %t273 = sub i64 %t272, 1
  store i64 %t273, ptr %l174, !tbaa !24
  %t274 = load i64, ptr %l25, !tbaa !24
  store i64 %t274, ptr %l175, !tbaa !24
  %t275 = load i64, ptr %l174, !tbaa !24
  %t276 = load i64, ptr %l175, !tbaa !24
  %t277 = sdiv i64 %t275, %t276
  store i64 %t277, ptr %l176, !tbaa !24
  %t278 = load i64, ptr %l176, !tbaa !24
  store i64 %t278, ptr %l168, !tbaa !24
  br label %bb73
bb72:
  store i64 0, ptr %l168, !tbaa !24
  br label %bb73
bb73:
  %t279 = load i64, ptr %l168, !tbaa !24
  store i64 %t279, ptr %l165, !tbaa !24
  br label %bb74
bb74:
  %t280 = load i64, ptr %l165, !tbaa !24
  store i64 %t280, ptr %l26, !tbaa !24
  store i64 0, ptr %l27, !tbaa !24
  br label %bb75
bb75:
  store %olang.scope zeroinitializer, ptr %s16
  %t281 = load i64, ptr %l27, !tbaa !24
  store i64 %t281, ptr %l177, !tbaa !24
  %t282 = load i64, ptr %l26, !tbaa !24
  store i64 %t282, ptr %l178, !tbaa !24
  %t283 = load i64, ptr %l177, !tbaa !24
  %t284 = load i64, ptr %l178, !tbaa !24
  %t285 = icmp slt i64 %t283, %t284
  store i1 %t285, ptr %l179, !tbaa !21
  %t286 = load i1, ptr %l179, !tbaa !21
  %t287 = xor i1 %t286, true
  store i1 %t287, ptr %l180, !tbaa !21
  %t288 = load i1, ptr %l180, !tbaa !21
  br i1 %t288, label %bb76, label %bb77
bb76:
  call void @__olang_scope_close(ptr %s16)
  br label %bb89
bb77:
  br label %bb78
bb78:
  %t289 = load i64, ptr %l23, !tbaa !24
  store i64 %t289, ptr %l181, !tbaa !24
  %t290 = load i64, ptr %l27, !tbaa !24
  store i64 %t290, ptr %l182, !tbaa !24
  %t291 = load i64, ptr %l25, !tbaa !24
  store i64 %t291, ptr %l183, !tbaa !24
  %t292 = load i64, ptr %l182, !tbaa !24
  %t293 = load i64, ptr %l183, !tbaa !24
  %t294 = mul i64 %t292, %t293
  store i64 %t294, ptr %l184, !tbaa !24
  %t295 = load i64, ptr %l181, !tbaa !24
  %t296 = load i64, ptr %l184, !tbaa !24
  %t297 = add i64 %t295, %t296
  store i64 %t297, ptr %l185, !tbaa !24
  %t298 = load i64, ptr %l185, !tbaa !24
  store i64 %t298, ptr %l28, !tbaa !24
  %t299 = load ptr, ptr %l0, !tbaa !29
  store ptr %t299, ptr %l186, !tbaa !29
  %t300 = load ptr, ptr %l186, !tbaa !29
  %t301 = getelementptr %"compiler/fmt:formatter", ptr %t300, i32 0, i32 29
  store ptr %t301, ptr %l187, !tbaa !29
  %t302 = load i64, ptr %l28, !tbaa !24
  store i64 %t302, ptr %l188, !tbaa !24
  %t303 = load ptr, ptr %l187, !tbaa !29
  %t304 = load i64, ptr %l188, !tbaa !24
  %t305 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t303, i64 %t304)
  store i64 %t305, ptr %l189
  br label %bb79
bb79:
  %t306 = load i64, ptr %l22, !tbaa !24
  store i64 %t306, ptr %l190, !tbaa !24
  %t307 = load i64, ptr %l189, !tbaa !24
  %t308 = load i64, ptr %l190, !tbaa !24
  %t309 = icmp sle i64 %t307, %t308
  store i1 %t309, ptr %l191, !tbaa !21
  %t310 = load i1, ptr %l191, !tbaa !21
  br i1 %t310, label %bb80, label %bb81
bb80:
  %t311 = load ptr, ptr %l0, !tbaa !29
  store ptr %t311, ptr %l193, !tbaa !29
  %t312 = load ptr, ptr %l193, !tbaa !29
  %t313 = getelementptr %"compiler/fmt:formatter", ptr %t312, i32 0, i32 30
  store ptr %t313, ptr %l194, !tbaa !29
  %t314 = load i64, ptr %l28, !tbaa !24
  store i64 %t314, ptr %l195, !tbaa !24
  %t315 = load ptr, ptr %l194, !tbaa !29
  %t316 = load i64, ptr %l195, !tbaa !24
  %t317 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t315, i64 %t316)
  store i64 %t317, ptr %l196
  br label %bb82
bb81:
  store i1 false, ptr %l192, !tbaa !21
  br label %bb83
bb82:
  %t318 = load i64, ptr %l22, !tbaa !24
  store i64 %t318, ptr %l197, !tbaa !24
  %t319 = load i64, ptr %l196, !tbaa !24
  %t320 = load i64, ptr %l197, !tbaa !24
  %t321 = icmp sgt i64 %t319, %t320
  store i1 %t321, ptr %l198, !tbaa !21
  %t322 = load i1, ptr %l198, !tbaa !21
  store i1 %t322, ptr %l192, !tbaa !21
  br label %bb83
bb83:
  %t323 = load i1, ptr %l192, !tbaa !21
  br i1 %t323, label %bb84, label %bb85
bb84:
  store %olang.scope zeroinitializer, ptr %s17
  %t324 = load ptr, ptr %l0, !tbaa !29
  store ptr %t324, ptr %l199, !tbaa !29
  %t325 = load ptr, ptr %l199, !tbaa !29
  %t326 = getelementptr %"compiler/fmt:formatter", ptr %t325, i32 0, i32 30
  store ptr %t326, ptr %l200, !tbaa !29
  %t327 = load i64, ptr %l28, !tbaa !24
  store i64 %t327, ptr %l201, !tbaa !24
  %t328 = load ptr, ptr %l200, !tbaa !29
  %t329 = load i64, ptr %l201, !tbaa !24
  %t330 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t328, i64 %t329)
  store i64 %t330, ptr %l202
  br label %bb86
bb85:
  br label %bb87
bb86:
  %t331 = load i64, ptr %l202, !tbaa !24
  store i64 %t331, ptr %l22, !tbaa !24
  call void @__olang_scope_close(ptr %s17)
  br label %bb87
bb87:
  call void @__olang_scope_close(ptr %s16)
  br label %bb88
bb88:
  store %olang.scope zeroinitializer, ptr %s18
  %t332 = load i64, ptr %l27, !tbaa !24
  store i64 %t332, ptr %l203, !tbaa !24
  %t333 = load i64, ptr %l203, !tbaa !24
  %t334 = add i64 %t333, 1
  store i64 %t334, ptr %l204, !tbaa !24
  %t335 = load i64, ptr %l204, !tbaa !24
  store i64 %t335, ptr %l27, !tbaa !24
  call void @__olang_scope_close(ptr %s18)
  br label %bb75
bb89:
  call void @__olang_scope_close(ptr %s15)
  %t336 = load ptr, ptr %l0, !tbaa !29
  store ptr %t336, ptr %l205, !tbaa !29
  %t337 = load i64, ptr %l17, !tbaa !24
  store i64 %t337, ptr %l206, !tbaa !24
  %t338 = load i64, ptr %l21, !tbaa !24
  store i64 %t338, ptr %l207, !tbaa !24
  %t339 = load i64, ptr %l18, !tbaa !24
  store i64 %t339, ptr %l208, !tbaa !24
  %t340 = load ptr, ptr %l205, !tbaa !29
  %t341 = load i64, ptr %l206, !tbaa !24
  %t342 = load i64, ptr %l207, !tbaa !24
  %t343 = load i64, ptr %l208, !tbaa !24
  call void @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2egap(ptr %v0, ptr %t340, i64 %t341, i64 %t342, i64 %t343)
  br label %bb90
bb90:
  %t344 = load ptr, ptr %l0, !tbaa !29
  store ptr %t344, ptr %l209, !tbaa !29
  %t345 = load ptr, ptr %l209, !tbaa !29
  %t346 = getelementptr %"compiler/fmt:formatter", ptr %t345, i32 0, i32 17
  %t347 = load i1, ptr %t346, !tbaa !21
  store i1 %t347, ptr %l210, !tbaa !21
  %t348 = load i1, ptr %l210, !tbaa !21
  br i1 %t348, label %bb91, label %bb92
bb91:
  store %olang.scope zeroinitializer, ptr %s19
  %t349 = load ptr, ptr %l0, !tbaa !29
  store ptr %t349, ptr %l211, !tbaa !29
  %t350 = load ptr, ptr %l211, !tbaa !29
  call void @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2efinish(ptr %v0, ptr %t350)
  br label %bb93
bb92:
  br label %bb94
bb93:
  call void @__olang_scope_close(ptr %s19)
  br label %bb94
bb94:
  %t351 = load i64, ptr %l21, !tbaa !24
  store i64 %t351, ptr %l212, !tbaa !24
  %t352 = load i64, ptr %l212, !tbaa !24
  store i64 %t352, ptr %l29, !tbaa !24
  br label %bb95
bb95:
  store %olang.scope zeroinitializer, ptr %s20
  %t353 = load i64, ptr %l29, !tbaa !24
  store i64 %t353, ptr %l213, !tbaa !24
  %t354 = load i64, ptr %l22, !tbaa !24
  store i64 %t354, ptr %l214, !tbaa !24
  %t355 = load i64, ptr %l213, !tbaa !24
  %t356 = load i64, ptr %l214, !tbaa !24
  %t357 = icmp sle i64 %t355, %t356
  store i1 %t357, ptr %l215, !tbaa !21
  %t358 = load i1, ptr %l215, !tbaa !21
  br i1 %t358, label %bb96, label %bb97
bb96:
  %t359 = load i64, ptr %l29, !tbaa !24
  store i64 %t359, ptr %l217, !tbaa !24
  %t360 = load ptr, ptr %l0, !tbaa !29
  store ptr %t360, ptr %l218, !tbaa !29
  %t361 = load ptr, ptr %l218, !tbaa !29
  %t362 = getelementptr %"compiler/fmt:formatter", ptr %t361, i32 0, i32 0
  %t363 = load { i64, ptr }, ptr %t362, !tbaa !27
  store { i64, ptr } %t363, ptr %l219, !tbaa !27
  %t364 = load { i64, ptr }, ptr %l219, !tbaa !27
  %t365 = extractvalue { i64, ptr } %t364, 0
  store i64 %t365, ptr %l220, !tbaa !24
  %t366 = load i64, ptr %l220, !tbaa !24
  %t367 = add i64 %t366, 1
  store i64 %t367, ptr %l221, !tbaa !24
  %t368 = load i64, ptr %l217, !tbaa !24
  %t369 = load i64, ptr %l221, !tbaa !24
  %t370 = icmp slt i64 %t368, %t369
  store i1 %t370, ptr %l222, !tbaa !21
  %t371 = load i1, ptr %l222, !tbaa !21
  store i1 %t371, ptr %l216, !tbaa !21
  br label %bb98
bb97:
  store i1 false, ptr %l216, !tbaa !21
  br label %bb98
bb98:
  %t372 = load i1, ptr %l216, !tbaa !21
  %t373 = xor i1 %t372, true
  store i1 %t373, ptr %l223, !tbaa !21
  %t374 = load i1, ptr %l223, !tbaa !21
  br i1 %t374, label %bb99, label %bb100
bb99:
  call void @__olang_scope_close(ptr %s20)
  br label %bb131
bb100:
  br label %bb101
bb101:
  %t375 = load ptr, ptr %l0, !tbaa !29
  store ptr %t375, ptr %l224, !tbaa !29
  %t376 = load ptr, ptr %l224, !tbaa !29
  %t377 = getelementptr %"compiler/fmt:formatter", ptr %t376, i32 0, i32 0
  %t378 = load { i64, ptr }, ptr %t377, !tbaa !27
  store { i64, ptr } %t378, ptr %l225, !tbaa !27
  %t379 = load i64, ptr %l29, !tbaa !24
  store i64 %t379, ptr %l226, !tbaa !24
  %t380 = load { i64, ptr }, ptr %l225, !tbaa !27
  %t381 = load i64, ptr %l226, !tbaa !24
  %t382 = call i64 @compiler_2ffmt_2elineEndOf(ptr %v0, { i64, ptr } %t380, i64 %t381)
  store i64 %t382, ptr %l227
  br label %bb102
bb102:
  %t383 = load i64, ptr %l227, !tbaa !24
  store i64 %t383, ptr %l30, !tbaa !24
  %t384 = load ptr, ptr %l0, !tbaa !29
  store ptr %t384, ptr %l228, !tbaa !29
  %t385 = load ptr, ptr %l228, !tbaa !29
  call void @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2ebegin(ptr %v0, ptr %t385, i64 0)
  br label %bb103
bb103:
  %t386 = load ptr, ptr %l0, !tbaa !29
  store ptr %t386, ptr %l229, !tbaa !29
  %t387 = load ptr, ptr %l229, !tbaa !29
  %t388 = getelementptr %"compiler/fmt:formatter", ptr %t387, i32 0, i32 31
  store i1 true, ptr %t388, !tbaa !21
  %t389 = load ptr, ptr %l0, !tbaa !29
  store ptr %t389, ptr %l230, !tbaa !29
  %t390 = load ptr, ptr %l230, !tbaa !29
  %t391 = getelementptr %"compiler/fmt:formatter", ptr %t390, i32 0, i32 16
  store ptr %t391, ptr %l231, !tbaa !29
  %t392 = load ptr, ptr %l0, !tbaa !29
  store ptr %t392, ptr %l232, !tbaa !29
  %t393 = load ptr, ptr %l232, !tbaa !29
  %t394 = getelementptr %"compiler/fmt:formatter", ptr %t393, i32 0, i32 0
  %t395 = load { i64, ptr }, ptr %t394, !tbaa !27
  store { i64, ptr } %t395, ptr %l233, !tbaa !27
  %t396 = load i64, ptr %l29, !tbaa !24
  store i64 %t396, ptr %l234, !tbaa !24
  %t397 = load i64, ptr %l30, !tbaa !24
  store i64 %t397, ptr %l235, !tbaa !24
  %t398 = load { i64, ptr }, ptr %l233, !tbaa !27
  %t399 = extractvalue { i64, ptr } %t398, 0
  store i64 %t399, ptr %l236, !tbaa !24
  %t400 = load i64, ptr %l234, !tbaa !24
  %t401 = icmp sge i64 %t400, 0
  store i1 %t401, ptr %l237, !tbaa !21
  %t402 = load i1, ptr %l237, !tbaa !21
  br i1 %t402, label %bb104, label %bb105
bb104:
  %t403 = load i64, ptr %l234, !tbaa !24
  %t404 = load i64, ptr %l235, !tbaa !24
  %t405 = icmp sle i64 %t403, %t404
  store i1 %t405, ptr %l238, !tbaa !21
  %t406 = load i1, ptr %l238, !tbaa !21
  br i1 %t406, label %bb106, label %bb107
bb105:
  call void @__olang_check_failed(ptr @.c17)
  unreachable
bb106:
  %t407 = load i64, ptr %l235, !tbaa !24
  %t408 = load i64, ptr %l236, !tbaa !24
  %t409 = icmp sle i64 %t407, %t408
  store i1 %t409, ptr %l239, !tbaa !21
  %t410 = load i1, ptr %l239, !tbaa !21
  br i1 %t410, label %bb108, label %bb109
bb107:
  call void @__olang_check_failed(ptr @.c17)
  unreachable
bb108:
  %t411 = getelementptr { i64, ptr }, ptr %l233, i32 0, i32 1
  %t412 = load ptr, ptr %t411, !tbaa !27
  %t413 = load i64, ptr %l234, !tbaa !24
  %t414 = load i64, ptr %l235, !tbaa !24
  %t415 = getelementptr i8, ptr %t412, i64 %t413
  %t416 = sub i64 %t414, %t413
  %t417 = insertvalue { i64, ptr } undef, i64 %t416, 0
  %t418 = insertvalue { i64, ptr } %t417, ptr %t415, 1
  store { i64, ptr } %t418, ptr %l240, !tbaa !27
  %t419 = load ptr, ptr %l231, !tbaa !29
  %t420 = load { i64, ptr }, ptr %l240, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v0, ptr %t419, { i64, ptr } %t420)
  br label %bb110
bb109:
  call void @__olang_check_failed(ptr @.c17)
  unreachable
bb110:
  store i1 true, ptr %l31, !tbaa !21
  br label %bb111
bb111:
  store %olang.scope zeroinitializer, ptr %s21
  %t421 = load i64, ptr %l18, !tbaa !24
  store i64 %t421, ptr %l241, !tbaa !24
  %t422 = load ptr, ptr %l0, !tbaa !29
  store ptr %t422, ptr %l242, !tbaa !29
  %t423 = load ptr, ptr %l242, !tbaa !29
  %t424 = getelementptr %"compiler/fmt:formatter", ptr %t423, i32 0, i32 4
  store ptr %t424, ptr %l243, !tbaa !29
  %t425 = load ptr, ptr %l243, !tbaa !29
  %t426 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t425)
  store i64 %t426, ptr %l244
  br label %bb112
bb112:
  %t427 = load i64, ptr %l241, !tbaa !24
  %t428 = load i64, ptr %l244, !tbaa !24
  %t429 = icmp slt i64 %t427, %t428
  store i1 %t429, ptr %l245, !tbaa !21
  %t430 = load i1, ptr %l245, !tbaa !21
  br i1 %t430, label %bb113, label %bb114
bb113:
  %t431 = load ptr, ptr %l0, !tbaa !29
  store ptr %t431, ptr %l247, !tbaa !29
  %t432 = load ptr, ptr %l247, !tbaa !29
  %t433 = getelementptr %"compiler/fmt:formatter", ptr %t432, i32 0, i32 1
  %t434 = load { i64, ptr }, ptr %t433, !tbaa !27
  store { i64, ptr } %t434, ptr %l248, !tbaa !27
  %t435 = load ptr, ptr %l0, !tbaa !29
  store ptr %t435, ptr %l249, !tbaa !29
  %t436 = load ptr, ptr %l249, !tbaa !29
  %t437 = getelementptr %"compiler/fmt:formatter", ptr %t436, i32 0, i32 4
  store ptr %t437, ptr %l250, !tbaa !29
  %t438 = load i64, ptr %l18, !tbaa !24
  store i64 %t438, ptr %l251, !tbaa !24
  %t439 = load ptr, ptr %l250, !tbaa !29
  %t440 = load i64, ptr %l251, !tbaa !24
  %t441 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t439, i64 %t440)
  store i64 %t441, ptr %l252
  br label %bb115
bb114:
  store i1 false, ptr %l246, !tbaa !21
  br label %bb116
bb115:
  %t442 = load i64, ptr %l252, !tbaa !24
  %t443 = getelementptr { i64, ptr }, ptr %l248, i32 0, i32 1
  %t444 = load ptr, ptr %t443, !tbaa !27
  %t445 = getelementptr %"compiler/token:Token", ptr %t444, i64 %t442
  %t446 = getelementptr %"compiler/token:Token", ptr %t445, i32 0, i32 2
  %t447 = load i32, ptr %t446, !tbaa !23
  store i32 %t447, ptr %l253, !tbaa !23
  %t448 = load i32, ptr %l253, !tbaa !23
  %t449 = sext i32 %t448 to i64
  store i64 %t449, ptr %l254, !tbaa !24
  %t450 = load i64, ptr %l30, !tbaa !24
  store i64 %t450, ptr %l255, !tbaa !24
  %t451 = load i64, ptr %l254, !tbaa !24
  %t452 = load i64, ptr %l255, !tbaa !24
  %t453 = icmp slt i64 %t451, %t452
  store i1 %t453, ptr %l256, !tbaa !21
  %t454 = load i1, ptr %l256, !tbaa !21
  store i1 %t454, ptr %l246, !tbaa !21
  br label %bb116
bb116:
  %t455 = load i1, ptr %l246, !tbaa !21
  %t456 = xor i1 %t455, true
  store i1 %t456, ptr %l257, !tbaa !21
  %t457 = load i1, ptr %l257, !tbaa !21
  br i1 %t457, label %bb117, label %bb118
bb117:
  call void @__olang_scope_close(ptr %s21)
  br label %bb128
bb118:
  br label %bb119
bb119:
  %t458 = load i1, ptr %l31, !tbaa !21
  store i1 %t458, ptr %l258, !tbaa !21
  %t459 = load i1, ptr %l258, !tbaa !21
  br i1 %t459, label %bb120, label %bb121
bb120:
  store %olang.scope zeroinitializer, ptr %s22
  %t460 = load ptr, ptr %l0, !tbaa !29
  store ptr %t460, ptr %l259, !tbaa !29
  %t461 = load i64, ptr %l18, !tbaa !24
  store i64 %t461, ptr %l260, !tbaa !24
  %t462 = load ptr, ptr %l259, !tbaa !29
  %t463 = load i64, ptr %l260, !tbaa !24
  %t464 = call i64 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2elevel(ptr %v0, ptr %t462, i64 %t463)
  store i64 %t464, ptr %l261
  br label %bb122
bb121:
  br label %bb123
bb122:
  call void @__olang_scope_close(ptr %s22)
  br label %bb123
bb123:
  store i1 false, ptr %l31, !tbaa !21
  %t465 = load ptr, ptr %l0, !tbaa !29
  store ptr %t465, ptr %l262, !tbaa !29
  %t466 = load ptr, ptr %l0, !tbaa !29
  store ptr %t466, ptr %l263, !tbaa !29
  %t467 = load ptr, ptr %l263, !tbaa !29
  %t468 = getelementptr %"compiler/fmt:formatter", ptr %t467, i32 0, i32 4
  store ptr %t468, ptr %l264, !tbaa !29
  %t469 = load i64, ptr %l18, !tbaa !24
  store i64 %t469, ptr %l265, !tbaa !24
  %t470 = load ptr, ptr %l264, !tbaa !29
  %t471 = load i64, ptr %l265, !tbaa !24
  %t472 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t470, i64 %t471)
  store i64 %t472, ptr %l266
  br label %bb124
bb124:
  %t473 = load i64, ptr %l266, !tbaa !24
  %t474 = load ptr, ptr %l262, !tbaa !29
  %t475 = getelementptr %"compiler/fmt:formatter", ptr %t474, i32 0, i32 26
  store i64 %t473, ptr %t475, !tbaa !24
  %t476 = load ptr, ptr %l0, !tbaa !29
  store ptr %t476, ptr %l267, !tbaa !29
  %t477 = load ptr, ptr %l0, !tbaa !29
  store ptr %t477, ptr %l268, !tbaa !29
  %t478 = load ptr, ptr %l268, !tbaa !29
  %t479 = getelementptr %"compiler/fmt:formatter", ptr %t478, i32 0, i32 4
  store ptr %t479, ptr %l269, !tbaa !29
  %t480 = load i64, ptr %l18, !tbaa !24
  store i64 %t480, ptr %l270, !tbaa !24
  %t481 = load ptr, ptr %l269, !tbaa !29
  %t482 = load i64, ptr %l270, !tbaa !24
  %t483 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t481, i64 %t482)
  store i64 %t483, ptr %l271
  br label %bb125
bb125:
  %t484 = load ptr, ptr %l267, !tbaa !29
  %t485 = load i64, ptr %l271, !tbaa !24
  call void @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2etrack(ptr %v0, ptr %t484, i64 %t485)
  br label %bb126
bb126:
  %t486 = load i64, ptr %l18, !tbaa !24
  store i64 %t486, ptr %l272, !tbaa !24
  %t487 = load i64, ptr %l272, !tbaa !24
  %t488 = add i64 %t487, 1
  store i64 %t488, ptr %l273, !tbaa !24
  %t489 = load i64, ptr %l273, !tbaa !24
  store i64 %t489, ptr %l18, !tbaa !24
  call void @__olang_scope_close(ptr %s21)
  br label %bb127
bb127:
  br label %bb111
bb128:
  %t490 = load ptr, ptr %l0, !tbaa !29
  store ptr %t490, ptr %l274, !tbaa !29
  %t491 = load ptr, ptr %l274, !tbaa !29
  call void @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2efinish(ptr %v0, ptr %t491)
  br label %bb129
bb129:
  %t492 = load i64, ptr %l30, !tbaa !24
  store i64 %t492, ptr %l275, !tbaa !24
  %t493 = load i64, ptr %l275, !tbaa !24
  %t494 = add i64 %t493, 1
  store i64 %t494, ptr %l276, !tbaa !24
  %t495 = load i64, ptr %l276, !tbaa !24
  store i64 %t495, ptr %l29, !tbaa !24
  call void @__olang_scope_close(ptr %s20)
  br label %bb130
bb130:
  br label %bb95
bb131:
  %t496 = load i64, ptr %l29, !tbaa !24
  store i64 %t496, ptr %l277, !tbaa !24
  %t497 = load ptr, ptr %l0, !tbaa !29
  store ptr %t497, ptr %l278, !tbaa !29
  %t498 = load ptr, ptr %l278, !tbaa !29
  %t499 = getelementptr %"compiler/fmt:formatter", ptr %t498, i32 0, i32 0
  %t500 = load { i64, ptr }, ptr %t499, !tbaa !27
  store { i64, ptr } %t500, ptr %l279, !tbaa !27
  %t501 = load { i64, ptr }, ptr %l279, !tbaa !27
  %t502 = extractvalue { i64, ptr } %t501, 0
  store i64 %t502, ptr %l280, !tbaa !24
  %t503 = load i64, ptr %l277, !tbaa !24
  %t504 = load i64, ptr %l280, !tbaa !24
  %t505 = icmp sle i64 %t503, %t504
  store i1 %t505, ptr %l281, !tbaa !21
  %t506 = load i1, ptr %l281, !tbaa !21
  br i1 %t506, label %bb132, label %bb133
bb132:
  %t507 = load i64, ptr %l29, !tbaa !24
  store i64 %t507, ptr %l283, !tbaa !24
  %t508 = load i64, ptr %l283, !tbaa !24
  store i64 %t508, ptr %l282, !tbaa !24
  br label %bb134
bb133:
  %t509 = load ptr, ptr %l0, !tbaa !29
  store ptr %t509, ptr %l284, !tbaa !29
  %t510 = load ptr, ptr %l284, !tbaa !29
  %t511 = getelementptr %"compiler/fmt:formatter", ptr %t510, i32 0, i32 0
  %t512 = load { i64, ptr }, ptr %t511, !tbaa !27
  store { i64, ptr } %t512, ptr %l285, !tbaa !27
  %t513 = load { i64, ptr }, ptr %l285, !tbaa !27
  %t514 = extractvalue { i64, ptr } %t513, 0
  store i64 %t514, ptr %l286, !tbaa !24
  %t515 = load i64, ptr %l286, !tbaa !24
  store i64 %t515, ptr %l282, !tbaa !24
  br label %bb134
bb134:
  %t516 = load i64, ptr %l282, !tbaa !24
  store i64 %t516, ptr %l17, !tbaa !24
  call void @__olang_scope_close(ptr %s14)
  call void @__olang_scope_close(ptr %s13)
  br label %bb138
bb135:
  %t517 = load ptr, ptr %l0, !tbaa !29
  store ptr %t517, ptr %l287, !tbaa !29
  %t518 = load i64, ptr %l17, !tbaa !24
  store i64 %t518, ptr %l288, !tbaa !24
  %t519 = load ptr, ptr %l0, !tbaa !29
  store ptr %t519, ptr %l289, !tbaa !29
  %t520 = load ptr, ptr %l289, !tbaa !29
  %t521 = getelementptr %"compiler/fmt:formatter", ptr %t520, i32 0, i32 1
  %t522 = load { i64, ptr }, ptr %t521, !tbaa !27
  store { i64, ptr } %t522, ptr %l290, !tbaa !27
  %t523 = load i64, ptr %l19, !tbaa !24
  store i64 %t523, ptr %l291, !tbaa !24
  %t524 = load i64, ptr %l291, !tbaa !24
  %t525 = getelementptr { i64, ptr }, ptr %l290, i32 0, i32 1
  %t526 = load ptr, ptr %t525, !tbaa !27
  %t527 = getelementptr %"compiler/token:Token", ptr %t526, i64 %t524
  %t528 = getelementptr %"compiler/token:Token", ptr %t527, i32 0, i32 2
  %t529 = load i32, ptr %t528, !tbaa !23
  store i32 %t529, ptr %l292, !tbaa !23
  %t530 = load i32, ptr %l292, !tbaa !23
  %t531 = sext i32 %t530 to i64
  store i64 %t531, ptr %l293, !tbaa !24
  %t532 = load i64, ptr %l18, !tbaa !24
  store i64 %t532, ptr %l294, !tbaa !24
  %t533 = load ptr, ptr %l287, !tbaa !29
  %t534 = load i64, ptr %l288, !tbaa !24
  %t535 = load i64, ptr %l293, !tbaa !24
  %t536 = load i64, ptr %l294, !tbaa !24
  call void @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2egap(ptr %v0, ptr %t533, i64 %t534, i64 %t535, i64 %t536)
  br label %bb136
bb136:
  %t537 = load ptr, ptr %l0, !tbaa !29
  store ptr %t537, ptr %l295, !tbaa !29
  %t538 = load i64, ptr %l18, !tbaa !24
  store i64 %t538, ptr %l296, !tbaa !24
  %t539 = load ptr, ptr %l295, !tbaa !29
  %t540 = load i64, ptr %l296, !tbaa !24
  call void @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2etoken(ptr %v0, ptr %t539, i64 %t540)
  br label %bb137
bb137:
  %t541 = load ptr, ptr %l0, !tbaa !29
  store ptr %t541, ptr %l297, !tbaa !29
  %t542 = load ptr, ptr %l297, !tbaa !29
  %t543 = getelementptr %"compiler/fmt:formatter", ptr %t542, i32 0, i32 1
  %t544 = load { i64, ptr }, ptr %t543, !tbaa !27
  store { i64, ptr } %t544, ptr %l298, !tbaa !27
  %t545 = load i64, ptr %l19, !tbaa !24
  store i64 %t545, ptr %l299, !tbaa !24
  %t546 = load i64, ptr %l299, !tbaa !24
  %t547 = getelementptr { i64, ptr }, ptr %l298, i32 0, i32 1
  %t548 = load ptr, ptr %t547, !tbaa !27
  %t549 = getelementptr %"compiler/token:Token", ptr %t548, i64 %t546
  %t550 = getelementptr %"compiler/token:Token", ptr %t549, i32 0, i32 3
  %t551 = load i32, ptr %t550, !tbaa !23
  store i32 %t551, ptr %l300, !tbaa !23
  %t552 = load i32, ptr %l300, !tbaa !23
  %t553 = sext i32 %t552 to i64
  store i64 %t553, ptr %l301, !tbaa !24
  %t554 = load i64, ptr %l301, !tbaa !24
  store i64 %t554, ptr %l17, !tbaa !24
  %t555 = load i64, ptr %l18, !tbaa !24
  store i64 %t555, ptr %l302, !tbaa !24
  %t556 = load i64, ptr %l302, !tbaa !24
  %t557 = add i64 %t556, 1
  store i64 %t557, ptr %l303, !tbaa !24
  %t558 = load i64, ptr %l303, !tbaa !24
  store i64 %t558, ptr %l18, !tbaa !24
  call void @__olang_scope_close(ptr %s13)
  br label %bb138
bb138:
  br label %bb57
bb139:
  %t559 = load ptr, ptr %l0, !tbaa !29
  store ptr %t559, ptr %l304, !tbaa !29
  %t560 = load i64, ptr %l17, !tbaa !24
  store i64 %t560, ptr %l305, !tbaa !24
  %t561 = load ptr, ptr %l0, !tbaa !29
  store ptr %t561, ptr %l306, !tbaa !29
  %t562 = load ptr, ptr %l306, !tbaa !29
  %t563 = getelementptr %"compiler/fmt:formatter", ptr %t562, i32 0, i32 0
  %t564 = load { i64, ptr }, ptr %t563, !tbaa !27
  store { i64, ptr } %t564, ptr %l307, !tbaa !27
  %t565 = load { i64, ptr }, ptr %l307, !tbaa !27
  %t566 = extractvalue { i64, ptr } %t565, 0
  store i64 %t566, ptr %l308, !tbaa !24
  %t567 = load ptr, ptr %l304, !tbaa !29
  %t568 = load i64, ptr %l305, !tbaa !24
  %t569 = load i64, ptr %l308, !tbaa !24
  call void @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2egap(ptr %v0, ptr %t567, i64 %t568, i64 %t569, i64 -1)
  br label %bb140
bb140:
  %t570 = load ptr, ptr %l0, !tbaa !29
  store ptr %t570, ptr %l309, !tbaa !29
  %t571 = load ptr, ptr %l309, !tbaa !29
  %t572 = getelementptr %"compiler/fmt:formatter", ptr %t571, i32 0, i32 17
  %t573 = load i1, ptr %t572, !tbaa !21
  store i1 %t573, ptr %l310, !tbaa !21
  %t574 = load i1, ptr %l310, !tbaa !21
  br i1 %t574, label %bb141, label %bb142
bb141:
  store %olang.scope zeroinitializer, ptr %s23
  %t575 = load ptr, ptr %l0, !tbaa !29
  store ptr %t575, ptr %l311, !tbaa !29
  %t576 = load ptr, ptr %l311, !tbaa !29
  call void @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2efinish(ptr %v0, ptr %t576)
  br label %bb143
bb142:
  br label %bb144
bb143:
  call void @__olang_scope_close(ptr %s23)
  br label %bb144
bb144:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2espace(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca i32
  %l12 = alloca ptr
  %l13 = alloca i64
  %l14 = alloca i32
  %l15 = alloca i32
  %l16 = alloca ptr
  %l17 = alloca i32
  %l18 = alloca ptr
  %l19 = alloca i1
  %l20 = alloca { i64, ptr }
  %l21 = alloca i32
  %l22 = alloca ptr
  %l23 = alloca i32
  %l24 = alloca ptr
  %l25 = alloca i1
  %l26 = alloca i1
  %l27 = alloca i32
  %l28 = alloca ptr
  %l29 = alloca i32
  %l30 = alloca ptr
  %l31 = alloca i1
  %l32 = alloca { i64, ptr }
  %l33 = alloca i32
  %l34 = alloca ptr
  %l35 = alloca i32
  %l36 = alloca ptr
  %l37 = alloca i1
  %l38 = alloca i1
  %l39 = alloca i32
  %l40 = alloca ptr
  %l41 = alloca i32
  %l42 = alloca ptr
  %l43 = alloca i1
  %l44 = alloca { i64, ptr }
  %l45 = alloca ptr
  %l46 = alloca { i64, ptr }
  %l47 = alloca i64
  %l48 = alloca i64
  %l49 = alloca i1
  %l50 = alloca { i64, ptr }
  %l51 = alloca ptr
  %l52 = alloca { i64, ptr }
  %l53 = alloca i64
  %l54 = alloca i64
  %l55 = alloca i1
  %l56 = alloca { i64, ptr }
  %l57 = alloca i32
  %l58 = alloca ptr
  %l59 = alloca i32
  %l60 = alloca ptr
  %l61 = alloca i1
  %l62 = alloca i1
  %l63 = alloca ptr
  %l64 = alloca { i64, ptr }
  %l65 = alloca i64
  %l66 = alloca %"compiler/token:Token"
  %l67 = alloca i8
  %l68 = alloca i1
  %l69 = alloca i1
  %l70 = alloca ptr
  %l71 = alloca i64
  %l72 = alloca { i64, ptr }
  %l73 = alloca i32
  %l74 = alloca ptr
  %l75 = alloca i32
  %l76 = alloca ptr
  %l77 = alloca i1
  %l78 = alloca ptr
  %l79 = alloca i64
  %l80 = alloca { i64, ptr }
  %l81 = alloca i32
  %l82 = alloca ptr
  %l83 = alloca i32
  %l84 = alloca ptr
  %l85 = alloca i1
  %l86 = alloca i1
  %l87 = alloca i32
  %l88 = alloca ptr
  %l89 = alloca i32
  %l90 = alloca ptr
  %l91 = alloca i1
  %l92 = alloca i1
  %l93 = alloca i64
  %l94 = alloca i1
  %l95 = alloca i1
  %l96 = alloca ptr
  %l97 = alloca { i64, ptr }
  %l98 = alloca i64
  %l99 = alloca %"compiler/token:Token"
  %l100 = alloca i8
  %l101 = alloca i1
  %l102 = alloca i1
  %l103 = alloca ptr
  %l104 = alloca ptr
  %l105 = alloca i64
  %l106 = alloca i64
  %l107 = alloca i64
  %l108 = alloca ptr
  %l109 = alloca i64
  %l110 = alloca i32
  %l111 = alloca ptr
  %l112 = alloca i32
  %l113 = alloca ptr
  %l114 = alloca i1
  %l115 = alloca i1
  %l116 = alloca ptr
  %l117 = alloca { i64, ptr }
  %l118 = alloca i64
  %l119 = alloca %"compiler/token:Token"
  %l120 = alloca i8
  %l121 = alloca i1
  %l122 = alloca i1
  %l123 = alloca ptr
  %l124 = alloca i64
  %l125 = alloca { i64, ptr }
  %l126 = alloca i32
  %l127 = alloca ptr
  %l128 = alloca i32
  %l129 = alloca ptr
  %l130 = alloca i1
  %l131 = alloca i1
  %l132 = alloca i32
  %l133 = alloca ptr
  %l134 = alloca i32
  %l135 = alloca ptr
  %l136 = alloca i1
  %l137 = alloca { i64, ptr }
  %l138 = alloca i32
  %l139 = alloca ptr
  %l140 = alloca i32
  %l141 = alloca ptr
  %l142 = alloca i1
  %l143 = alloca i1
  %l144 = alloca i32
  %l145 = alloca ptr
  %l146 = alloca i32
  %l147 = alloca ptr
  %l148 = alloca i1
  %l149 = alloca { i64, ptr }
  %l150 = alloca ptr
  %l151 = alloca i64
  %l152 = alloca i64
  %l153 = alloca i64
  %l154 = alloca i1
  %l155 = alloca i32
  %l156 = alloca ptr
  %l157 = alloca i32
  %l158 = alloca ptr
  %l159 = alloca i1
  %l160 = alloca i1
  %l161 = alloca i32
  %l162 = alloca ptr
  %l163 = alloca i32
  %l164 = alloca ptr
  %l165 = alloca i1
  %l166 = alloca i1
  %l167 = alloca i32
  %l168 = alloca ptr
  %l169 = alloca i32
  %l170 = alloca ptr
  %l171 = alloca i1
  %l172 = alloca i1
  %l173 = alloca i32
  %l174 = alloca ptr
  %l175 = alloca i32
  %l176 = alloca ptr
  %l177 = alloca i1
  %l178 = alloca i1
  %l179 = alloca i32
  %l180 = alloca ptr
  %l181 = alloca i32
  %l182 = alloca ptr
  %l183 = alloca i1
  %l184 = alloca { i64, ptr }
  %l185 = alloca { i64, ptr }
  %l186 = alloca i32
  %l187 = alloca ptr
  %l188 = alloca i32
  %l189 = alloca ptr
  %l190 = alloca i1
  %l191 = alloca i1
  %l192 = alloca i32
  %l193 = alloca ptr
  %l194 = alloca i32
  %l195 = alloca ptr
  %l196 = alloca i1
  %l197 = alloca i1
  %l198 = alloca ptr
  %l199 = alloca i64
  %l200 = alloca i1
  %l201 = alloca { i64, ptr }
  %l202 = alloca i32
  %l203 = alloca ptr
  %l204 = alloca i32
  %l205 = alloca ptr
  %l206 = alloca i1
  %l207 = alloca i32
  %l208 = alloca ptr
  %l209 = alloca i32
  %l210 = alloca ptr
  %l211 = alloca i1
  %l212 = alloca ptr
  %l213 = alloca i64
  %l214 = alloca i64
  %l215 = alloca i64
  %l216 = alloca i1
  %l217 = alloca { i64, ptr }
  %l218 = alloca i32
  %l219 = alloca ptr
  %l220 = alloca i32
  %l221 = alloca ptr
  %l222 = alloca i1
  %l223 = alloca { i64, ptr }
  %l224 = alloca i32
  %l225 = alloca ptr
  %l226 = alloca i32
  %l227 = alloca ptr
  %l228 = alloca i1
  %l229 = alloca ptr
  %l230 = alloca i64
  %l231 = alloca { i64, ptr }
  %l232 = alloca ptr
  %l233 = alloca i64
  %l234 = alloca i1
  %l235 = alloca i1
  %l236 = alloca i64
  %l237 = alloca i1
  %l238 = alloca i1
  %l239 = alloca ptr
  %l240 = alloca ptr
  %l241 = alloca ptr
  %l242 = alloca i64
  %l243 = alloca i64
  %l244 = alloca i64
  %l245 = alloca i32
  %l246 = alloca ptr
  %l247 = alloca i32
  %l248 = alloca ptr
  %l249 = alloca i1
  %l250 = alloca ptr
  %l251 = alloca { i64, ptr }
  %l252 = alloca ptr
  %l253 = alloca ptr
  %l254 = alloca i64
  %l255 = alloca i64
  %l256 = alloca i64
  %l257 = alloca i64
  %l258 = alloca i64
  %l259 = alloca i1
  %l260 = alloca i1
  %l261 = alloca ptr
  %l262 = alloca i64
  %l263 = alloca i64
  %l264 = alloca i32
  %l265 = alloca ptr
  %l266 = alloca i32
  %l267 = alloca ptr
  %l268 = alloca i1
  %l269 = alloca { i64, ptr }
  %l270 = alloca i32
  %l271 = alloca ptr
  %l272 = alloca i32
  %l273 = alloca ptr
  %l274 = alloca i1
  %l275 = alloca ptr
  %l276 = alloca ptr
  %l277 = alloca { i64, ptr }
  %l278 = alloca i64
  %l279 = alloca i64
  %l280 = alloca i64
  %l281 = alloca i64
  %l282 = alloca i1
  %l283 = alloca { i64, ptr }
  %l284 = alloca i64
  %l285 = alloca i1
  %l286 = alloca ptr
  %l287 = alloca i64
  %l288 = alloca { i64, ptr }
  %l289 = alloca ptr
  %l290 = alloca i64
  %l291 = alloca i1
  %l292 = alloca i1
  %l293 = alloca i32
  %l294 = alloca ptr
  %l295 = alloca i32
  %l296 = alloca ptr
  %l297 = alloca i1
  %l298 = alloca i1
  %l299 = alloca i1
  %l300 = alloca i32
  %l301 = alloca ptr
  %l302 = alloca i32
  %l303 = alloca ptr
  %l304 = alloca i1
  %l305 = alloca i1
  %l306 = alloca { i64, ptr }
  %l307 = alloca { i64, ptr }
  %l308 = alloca i32
  %l309 = alloca ptr
  %l310 = alloca i32
  %l311 = alloca ptr
  %l312 = alloca i1
  %l313 = alloca i32
  %l314 = alloca ptr
  %l315 = alloca i32
  %l316 = alloca ptr
  %l317 = alloca i1
  %l318 = alloca ptr
  %l319 = alloca i64
  %l320 = alloca { i64, ptr }
  %l321 = alloca ptr
  %l322 = alloca i64
  %l323 = alloca i1
  %l324 = alloca i1
  %l325 = alloca i32
  %l326 = alloca ptr
  %l327 = alloca i32
  %l328 = alloca ptr
  %l329 = alloca i1
  %l330 = alloca i1
  %l331 = alloca i1
  %l332 = alloca i32
  %l333 = alloca ptr
  %l334 = alloca i32
  %l335 = alloca ptr
  %l336 = alloca i1
  %l337 = alloca i1
  %l338 = alloca i1
  %l339 = alloca i32
  %l340 = alloca ptr
  %l341 = alloca i32
  %l342 = alloca ptr
  %l343 = alloca i1
  %l344 = alloca i1
  %l345 = alloca i1
  %l346 = alloca i32
  %l347 = alloca ptr
  %l348 = alloca i32
  %l349 = alloca ptr
  %l350 = alloca i1
  %l351 = alloca i1
  %l352 = alloca { i64, ptr }
  %l353 = alloca { i64, ptr }
  %l354 = alloca ptr
  %l355 = alloca { i64, ptr }
  %l356 = alloca i64
  %l357 = alloca i64
  %l358 = alloca i1
  %l359 = alloca { i64, ptr }
  %l360 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %s24 = alloca %olang.scope
  %s25 = alloca %olang.scope
  %s26 = alloca %olang.scope
  %s27 = alloca %olang.scope
  %s28 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l9, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  store i64 %t2, ptr %l10, !tbaa !24
  %t3 = load ptr, ptr %l9, !tbaa !29
  %t4 = load i64, ptr %l10, !tbaa !24
  %t5 = call i32 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2ekind(ptr %v0, ptr %t3, i64 %t4)
  store i32 %t5, ptr %l11
  br label %bb1
bb1:
  %t6 = load i32, ptr %l11
  store i32 %t6, ptr %l4
  %t7 = load ptr, ptr %l0, !tbaa !29
  store ptr %t7, ptr %l12, !tbaa !29
  %t8 = load i64, ptr %l2, !tbaa !24
  store i64 %t8, ptr %l13, !tbaa !24
  %t9 = load ptr, ptr %l12, !tbaa !29
  %t10 = load i64, ptr %l13, !tbaa !24
  %t11 = call i32 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2ekind(ptr %v0, ptr %t9, i64 %t10)
  store i32 %t11, ptr %l14
  br label %bb2
bb2:
  %t12 = load i32, ptr %l14
  store i32 %t12, ptr %l5
  %t13 = load i32, ptr %l5
  store i32 %t13, ptr %l15
  store ptr %l15, ptr %l16, !tbaa !29
  store i32 57, ptr %l17
  store ptr %l17, ptr %l18, !tbaa !29
  %t14 = load ptr, ptr %l16, !tbaa !29
  %t15 = load ptr, ptr %l18, !tbaa !29
  %t16 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t14, ptr %t15)
  store i1 %t16, ptr %l19
  br label %bb3
bb3:
  %t17 = load i1, ptr %l19, !tbaa !21
  br i1 %t17, label %bb4, label %bb5
bb4:
  store %olang.scope zeroinitializer, ptr %s1
  store { i64, ptr } { i64 0, ptr @.d18 }, ptr %l20, !tbaa !27
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t18 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t18, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t19 = load i32, ptr %l5
  store i32 %t19, ptr %l21
  store ptr %l21, ptr %l22, !tbaa !29
  store i32 91, ptr %l23
  store ptr %l23, ptr %l24, !tbaa !29
  %t20 = load ptr, ptr %l22, !tbaa !29
  %t21 = load ptr, ptr %l24, !tbaa !29
  %t22 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t20, ptr %t21)
  store i1 %t22, ptr %l25
  br label %bb7
bb7:
  %t23 = load i1, ptr %l25, !tbaa !21
  br i1 %t23, label %bb8, label %bb9
bb8:
  store i1 true, ptr %l26, !tbaa !21
  br label %bb11
bb9:
  %t24 = load i32, ptr %l5
  store i32 %t24, ptr %l27
  store ptr %l27, ptr %l28, !tbaa !29
  store i32 93, ptr %l29
  store ptr %l29, ptr %l30, !tbaa !29
  %t25 = load ptr, ptr %l28, !tbaa !29
  %t26 = load ptr, ptr %l30, !tbaa !29
  %t27 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t25, ptr %t26)
  store i1 %t27, ptr %l31
  br label %bb10
bb10:
  %t28 = load i1, ptr %l31, !tbaa !21
  store i1 %t28, ptr %l26, !tbaa !21
  br label %bb11
bb11:
  %t29 = load i1, ptr %l26, !tbaa !21
  br i1 %t29, label %bb12, label %bb13
bb12:
  store %olang.scope zeroinitializer, ptr %s2
  store { i64, ptr } { i64 0, ptr @.d19 }, ptr %l32, !tbaa !27
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t30 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t30, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  %t31 = load i32, ptr %l4
  store i32 %t31, ptr %l33
  store ptr %l33, ptr %l34, !tbaa !29
  store i32 90, ptr %l35
  store ptr %l35, ptr %l36, !tbaa !29
  %t32 = load ptr, ptr %l34, !tbaa !29
  %t33 = load ptr, ptr %l36, !tbaa !29
  %t34 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t32, ptr %t33)
  store i1 %t34, ptr %l37
  br label %bb15
bb15:
  %t35 = load i1, ptr %l37, !tbaa !21
  br i1 %t35, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l38, !tbaa !21
  br label %bb19
bb17:
  %t36 = load i32, ptr %l4
  store i32 %t36, ptr %l39
  store ptr %l39, ptr %l40, !tbaa !29
  store i32 92, ptr %l41
  store ptr %l41, ptr %l42, !tbaa !29
  %t37 = load ptr, ptr %l40, !tbaa !29
  %t38 = load ptr, ptr %l42, !tbaa !29
  %t39 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t37, ptr %t38)
  store i1 %t39, ptr %l43
  br label %bb18
bb18:
  %t40 = load i1, ptr %l43, !tbaa !21
  store i1 %t40, ptr %l38, !tbaa !21
  br label %bb19
bb19:
  %t41 = load i1, ptr %l38, !tbaa !21
  br i1 %t41, label %bb20, label %bb21
bb20:
  store %olang.scope zeroinitializer, ptr %s3
  store { i64, ptr } { i64 0, ptr @.d20 }, ptr %l44, !tbaa !27
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t42 = load { i64, ptr }, ptr %l44, !tbaa !27
  store { i64, ptr } %t42, ptr %rv
  br label %ret
bb21:
  br label %bb22
bb22:
  %t43 = load ptr, ptr %l0, !tbaa !29
  store ptr %t43, ptr %l45, !tbaa !29
  %t44 = load ptr, ptr %l45, !tbaa !29
  %t45 = getelementptr %"compiler/fmt:formatter", ptr %t44, i32 0, i32 3
  %t46 = load { i64, ptr }, ptr %t45, !tbaa !27
  store { i64, ptr } %t46, ptr %l46, !tbaa !27
  %t47 = load i64, ptr %l2, !tbaa !24
  store i64 %t47, ptr %l47, !tbaa !24
  %t48 = load i64, ptr %l47, !tbaa !24
  %t49 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !27
  %t51 = getelementptr i64, ptr %t50, i64 %t48
  %t52 = load i64, ptr %t51, !tbaa !34
  store i64 %t52, ptr %l48, !tbaa !24
  %t53 = load i64, ptr %l48, !tbaa !24
  %t54 = icmp sgt i64 %t53, 0
  store i1 %t54, ptr %l49, !tbaa !21
  %t55 = load i1, ptr %l49, !tbaa !21
  br i1 %t55, label %bb23, label %bb24
bb23:
  store %olang.scope zeroinitializer, ptr %s4
  store { i64, ptr } { i64 0, ptr @.d21 }, ptr %l50, !tbaa !27
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t56 = load { i64, ptr }, ptr %l50, !tbaa !27
  store { i64, ptr } %t56, ptr %rv
  br label %ret
bb24:
  br label %bb25
bb25:
  %t57 = load ptr, ptr %l0, !tbaa !29
  store ptr %t57, ptr %l51, !tbaa !29
  %t58 = load ptr, ptr %l51, !tbaa !29
  %t59 = getelementptr %"compiler/fmt:formatter", ptr %t58, i32 0, i32 2
  %t60 = load { i64, ptr }, ptr %t59, !tbaa !27
  store { i64, ptr } %t60, ptr %l52, !tbaa !27
  %t61 = load i64, ptr %l1, !tbaa !24
  store i64 %t61, ptr %l53, !tbaa !24
  %t62 = load i64, ptr %l53, !tbaa !24
  %t63 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t64 = load ptr, ptr %t63, !tbaa !27
  %t65 = getelementptr i64, ptr %t64, i64 %t62
  %t66 = load i64, ptr %t65, !tbaa !34
  store i64 %t66, ptr %l54, !tbaa !24
  %t67 = load i64, ptr %l54, !tbaa !24
  %t68 = icmp sgt i64 %t67, 0
  store i1 %t68, ptr %l55, !tbaa !21
  %t69 = load i1, ptr %l55, !tbaa !21
  br i1 %t69, label %bb26, label %bb27
bb26:
  store %olang.scope zeroinitializer, ptr %s5
  store { i64, ptr } { i64 0, ptr @.d22 }, ptr %l56, !tbaa !27
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  %t70 = load { i64, ptr }, ptr %l56, !tbaa !27
  store { i64, ptr } %t70, ptr %rv
  br label %ret
bb27:
  br label %bb28
bb28:
  %t71 = load i32, ptr %l4
  store i32 %t71, ptr %l57
  store ptr %l57, ptr %l58, !tbaa !29
  store i32 83, ptr %l59
  store ptr %l59, ptr %l60, !tbaa !29
  %t72 = load ptr, ptr %l58, !tbaa !29
  %t73 = load ptr, ptr %l60, !tbaa !29
  %t74 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t72, ptr %t73)
  store i1 %t74, ptr %l61
  br label %bb29
bb29:
  %t75 = load i1, ptr %l61, !tbaa !21
  br i1 %t75, label %bb30, label %bb31
bb30:
  %t76 = load ptr, ptr %l0, !tbaa !29
  store ptr %t76, ptr %l63, !tbaa !29
  %t77 = load ptr, ptr %l63, !tbaa !29
  %t78 = getelementptr %"compiler/fmt:formatter", ptr %t77, i32 0, i32 1
  %t79 = load { i64, ptr }, ptr %t78, !tbaa !27
  store { i64, ptr } %t79, ptr %l64, !tbaa !27
  %t80 = load i64, ptr %l1, !tbaa !24
  store i64 %t80, ptr %l65, !tbaa !24
  %t81 = load i64, ptr %l65, !tbaa !24
  %t82 = getelementptr { i64, ptr }, ptr %l64, i32 0, i32 1
  %t83 = load ptr, ptr %t82, !tbaa !27
  %t84 = getelementptr %"compiler/token:Token", ptr %t83, i64 %t81
  %t85 = load %"compiler/token:Token", ptr %t84
  store %"compiler/token:Token" %t85, ptr %l66
  %t86 = load i8, ptr @G_2ecompiler_2ftoken_2eSpace, !tbaa !22
  store i8 %t86, ptr %l67, !tbaa !22
  %t87 = load %"compiler/token:Token", ptr %l66
  %t88 = load i8, ptr %l67, !tbaa !22
  %t89 = call i1 @compiler_2ftoken_2ecompiler_2ftoken_3aToken_2eHas(%"compiler/token:Token" %t87, i8 %t88)
  store i1 %t89, ptr %l68
  br label %bb32
bb31:
  store i1 false, ptr %l62, !tbaa !21
  br label %bb33
bb32:
  %t90 = load i1, ptr %l68, !tbaa !21
  %t91 = xor i1 %t90, true
  store i1 %t91, ptr %l69, !tbaa !21
  %t92 = load i1, ptr %l69, !tbaa !21
  store i1 %t92, ptr %l62, !tbaa !21
  br label %bb33
bb33:
  %t93 = load i1, ptr %l62, !tbaa !21
  br i1 %t93, label %bb34, label %bb35
bb34:
  store %olang.scope zeroinitializer, ptr %s6
  %t94 = load ptr, ptr %l0, !tbaa !29
  store ptr %t94, ptr %l70, !tbaa !29
  %t95 = load i64, ptr %l2, !tbaa !24
  store i64 %t95, ptr %l71, !tbaa !24
  %t96 = load ptr, ptr %l70, !tbaa !29
  %t97 = load i64, ptr %l71, !tbaa !24
  %t98 = call { i64, ptr } @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2easWritten(ptr %v0, ptr %v1, ptr %t96, i64 %t97)
  store { i64, ptr } %t98, ptr %l72
  br label %bb36
bb35:
  br label %bb37
bb36:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  %t99 = load { i64, ptr }, ptr %l72, !tbaa !27
  store { i64, ptr } %t99, ptr %rv
  br label %ret
bb37:
  %t100 = load i32, ptr %l5
  store i32 %t100, ptr %l73
  store ptr %l73, ptr %l74, !tbaa !29
  store i32 83, ptr %l75
  store ptr %l75, ptr %l76, !tbaa !29
  %t101 = load ptr, ptr %l74, !tbaa !29
  %t102 = load ptr, ptr %l76, !tbaa !29
  %t103 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t101, ptr %t102)
  store i1 %t103, ptr %l77
  br label %bb38
bb38:
  %t104 = load i1, ptr %l77, !tbaa !21
  br i1 %t104, label %bb39, label %bb40
bb39:
  store %olang.scope zeroinitializer, ptr %s7
  %t105 = load ptr, ptr %l0, !tbaa !29
  store ptr %t105, ptr %l78, !tbaa !29
  %t106 = load i64, ptr %l2, !tbaa !24
  store i64 %t106, ptr %l79, !tbaa !24
  %t107 = load ptr, ptr %l78, !tbaa !29
  %t108 = load i64, ptr %l79, !tbaa !24
  %t109 = call { i64, ptr } @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2easWritten(ptr %v0, ptr %v1, ptr %t107, i64 %t108)
  store { i64, ptr } %t109, ptr %l80
  br label %bb41
bb40:
  br label %bb42
bb41:
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s0)
  %t110 = load { i64, ptr }, ptr %l80, !tbaa !27
  store { i64, ptr } %t110, ptr %rv
  br label %ret
bb42:
  %t111 = load i32, ptr %l4
  store i32 %t111, ptr %l81
  store ptr %l81, ptr %l82, !tbaa !29
  store i32 1, ptr %l83
  store ptr %l83, ptr %l84, !tbaa !29
  %t112 = load ptr, ptr %l82, !tbaa !29
  %t113 = load ptr, ptr %l84, !tbaa !29
  %t114 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t112, ptr %t113)
  store i1 %t114, ptr %l85
  br label %bb43
bb43:
  %t115 = load i1, ptr %l85, !tbaa !21
  br i1 %t115, label %bb44, label %bb45
bb44:
  store i1 true, ptr %l86, !tbaa !21
  br label %bb47
bb45:
  %t116 = load i32, ptr %l4
  store i32 %t116, ptr %l87
  store ptr %l87, ptr %l88, !tbaa !29
  store i32 14, ptr %l89
  store ptr %l89, ptr %l90, !tbaa !29
  %t117 = load ptr, ptr %l88, !tbaa !29
  %t118 = load ptr, ptr %l90, !tbaa !29
  %t119 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t117, ptr %t118)
  store i1 %t119, ptr %l91
  br label %bb46
bb46:
  %t120 = load i1, ptr %l91, !tbaa !21
  store i1 %t120, ptr %l86, !tbaa !21
  br label %bb47
bb47:
  %t121 = load i1, ptr %l86, !tbaa !21
  br i1 %t121, label %bb48, label %bb49
bb48:
  %t122 = load i64, ptr %l3, !tbaa !24
  store i64 %t122, ptr %l93, !tbaa !24
  %t123 = load i64, ptr %l93, !tbaa !24
  %t124 = icmp sge i64 %t123, 2
  store i1 %t124, ptr %l94, !tbaa !21
  %t125 = load i1, ptr %l94, !tbaa !21
  store i1 %t125, ptr %l92, !tbaa !21
  br label %bb50
bb49:
  store i1 false, ptr %l92, !tbaa !21
  br label %bb50
bb50:
  %t126 = load i1, ptr %l92, !tbaa !21
  br i1 %t126, label %bb51, label %bb52
bb51:
  %t127 = load ptr, ptr %l0, !tbaa !29
  store ptr %t127, ptr %l96, !tbaa !29
  %t128 = load ptr, ptr %l96, !tbaa !29
  %t129 = getelementptr %"compiler/fmt:formatter", ptr %t128, i32 0, i32 1
  %t130 = load { i64, ptr }, ptr %t129, !tbaa !27
  store { i64, ptr } %t130, ptr %l97, !tbaa !27
  %t131 = load i64, ptr %l1, !tbaa !24
  store i64 %t131, ptr %l98, !tbaa !24
  %t132 = load i64, ptr %l98, !tbaa !24
  %t133 = getelementptr { i64, ptr }, ptr %l97, i32 0, i32 1
  %t134 = load ptr, ptr %t133, !tbaa !27
  %t135 = getelementptr %"compiler/token:Token", ptr %t134, i64 %t132
  %t136 = load %"compiler/token:Token", ptr %t135
  store %"compiler/token:Token" %t136, ptr %l99
  %t137 = load i8, ptr @G_2ecompiler_2ftoken_2eSpace, !tbaa !22
  store i8 %t137, ptr %l100, !tbaa !22
  %t138 = load %"compiler/token:Token", ptr %l99
  %t139 = load i8, ptr %l100, !tbaa !22
  %t140 = call i1 @compiler_2ftoken_2ecompiler_2ftoken_3aToken_2eHas(%"compiler/token:Token" %t138, i8 %t139)
  store i1 %t140, ptr %l101
  br label %bb53
bb52:
  store i1 false, ptr %l95, !tbaa !21
  br label %bb54
bb53:
  %t141 = load i1, ptr %l101, !tbaa !21
  %t142 = xor i1 %t141, true
  store i1 %t142, ptr %l102, !tbaa !21
  %t143 = load i1, ptr %l102, !tbaa !21
  store i1 %t143, ptr %l95, !tbaa !21
  br label %bb54
bb54:
  %t144 = load i1, ptr %l95, !tbaa !21
  br i1 %t144, label %bb55, label %bb56
bb55:
  store %olang.scope zeroinitializer, ptr %s8
  %t145 = load ptr, ptr %l0, !tbaa !29
  store ptr %t145, ptr %l103, !tbaa !29
  %t146 = load ptr, ptr %l103, !tbaa !29
  %t147 = getelementptr %"compiler/fmt:formatter", ptr %t146, i32 0, i32 4
  store ptr %t147, ptr %l104, !tbaa !29
  %t148 = load i64, ptr %l3, !tbaa !24
  store i64 %t148, ptr %l105, !tbaa !24
  %t149 = load i64, ptr %l105, !tbaa !24
  %t150 = sub i64 %t149, 2
  store i64 %t150, ptr %l106, !tbaa !24
  %t151 = load ptr, ptr %l104, !tbaa !29
  %t152 = load i64, ptr %l106, !tbaa !24
  %t153 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t151, i64 %t152)
  store i64 %t153, ptr %l107
  br label %bb57
bb56:
  br label %bb68
bb57:
  %t154 = load i64, ptr %l107, !tbaa !24
  store i64 %t154, ptr %l6, !tbaa !24
  %t155 = load ptr, ptr %l0, !tbaa !29
  store ptr %t155, ptr %l108, !tbaa !29
  %t156 = load i64, ptr %l6, !tbaa !24
  store i64 %t156, ptr %l109, !tbaa !24
  %t157 = load ptr, ptr %l108, !tbaa !29
  %t158 = load i64, ptr %l109, !tbaa !24
  %t159 = call i32 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2ekind(ptr %v0, ptr %t157, i64 %t158)
  store i32 %t159, ptr %l110
  br label %bb58
bb58:
  store ptr %l110, ptr %l111, !tbaa !29
  store i32 83, ptr %l112
  store ptr %l112, ptr %l113, !tbaa !29
  %t160 = load ptr, ptr %l111, !tbaa !29
  %t161 = load ptr, ptr %l113, !tbaa !29
  %t162 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t160, ptr %t161)
  store i1 %t162, ptr %l114
  br label %bb59
bb59:
  %t163 = load i1, ptr %l114, !tbaa !21
  br i1 %t163, label %bb60, label %bb61
bb60:
  %t164 = load ptr, ptr %l0, !tbaa !29
  store ptr %t164, ptr %l116, !tbaa !29
  %t165 = load ptr, ptr %l116, !tbaa !29
  %t166 = getelementptr %"compiler/fmt:formatter", ptr %t165, i32 0, i32 1
  %t167 = load { i64, ptr }, ptr %t166, !tbaa !27
  store { i64, ptr } %t167, ptr %l117, !tbaa !27
  %t168 = load i64, ptr %l6, !tbaa !24
  store i64 %t168, ptr %l118, !tbaa !24
  %t169 = load i64, ptr %l118, !tbaa !24
  %t170 = getelementptr { i64, ptr }, ptr %l117, i32 0, i32 1
  %t171 = load ptr, ptr %t170, !tbaa !27
  %t172 = getelementptr %"compiler/token:Token", ptr %t171, i64 %t169
  %t173 = load %"compiler/token:Token", ptr %t172
  store %"compiler/token:Token" %t173, ptr %l119
  %t174 = load i8, ptr @G_2ecompiler_2ftoken_2eSpace, !tbaa !22
  store i8 %t174, ptr %l120, !tbaa !22
  %t175 = load %"compiler/token:Token", ptr %l119
  %t176 = load i8, ptr %l120, !tbaa !22
  %t177 = call i1 @compiler_2ftoken_2ecompiler_2ftoken_3aToken_2eHas(%"compiler/token:Token" %t175, i8 %t176)
  store i1 %t177, ptr %l121
  br label %bb62
bb61:
  store i1 false, ptr %l115, !tbaa !21
  br label %bb63
bb62:
  %t178 = load i1, ptr %l121, !tbaa !21
  %t179 = xor i1 %t178, true
  store i1 %t179, ptr %l122, !tbaa !21
  %t180 = load i1, ptr %l122, !tbaa !21
  store i1 %t180, ptr %l115, !tbaa !21
  br label %bb63
bb63:
  %t181 = load i1, ptr %l115, !tbaa !21
  br i1 %t181, label %bb64, label %bb65
bb64:
  store %olang.scope zeroinitializer, ptr %s9
  %t182 = load ptr, ptr %l0, !tbaa !29
  store ptr %t182, ptr %l123, !tbaa !29
  %t183 = load i64, ptr %l2, !tbaa !24
  store i64 %t183, ptr %l124, !tbaa !24
  %t184 = load ptr, ptr %l123, !tbaa !29
  %t185 = load i64, ptr %l124, !tbaa !24
  %t186 = call { i64, ptr } @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2easWritten(ptr %v0, ptr %v1, ptr %t184, i64 %t185)
  store { i64, ptr } %t186, ptr %l125
  br label %bb66
bb65:
  br label %bb67
bb66:
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  %t187 = load { i64, ptr }, ptr %l125, !tbaa !27
  store { i64, ptr } %t187, ptr %rv
  br label %ret
bb67:
  call void @__olang_scope_close(ptr %s8)
  br label %bb68
bb68:
  %t188 = load i32, ptr %l4
  store i32 %t188, ptr %l126
  store ptr %l126, ptr %l127, !tbaa !29
  store i32 58, ptr %l128
  store ptr %l128, ptr %l129, !tbaa !29
  %t189 = load ptr, ptr %l127, !tbaa !29
  %t190 = load ptr, ptr %l129, !tbaa !29
  %t191 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t189, ptr %t190)
  store i1 %t191, ptr %l130
  br label %bb69
bb69:
  %t192 = load i1, ptr %l130, !tbaa !21
  br i1 %t192, label %bb70, label %bb71
bb70:
  store i1 true, ptr %l131, !tbaa !21
  br label %bb73
bb71:
  %t193 = load i32, ptr %l5
  store i32 %t193, ptr %l132
  store ptr %l132, ptr %l133, !tbaa !29
  store i32 58, ptr %l134
  store ptr %l134, ptr %l135, !tbaa !29
  %t194 = load ptr, ptr %l133, !tbaa !29
  %t195 = load ptr, ptr %l135, !tbaa !29
  %t196 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t194, ptr %t195)
  store i1 %t196, ptr %l136
  br label %bb72
bb72:
  %t197 = load i1, ptr %l136, !tbaa !21
  store i1 %t197, ptr %l131, !tbaa !21
  br label %bb73
bb73:
  %t198 = load i1, ptr %l131, !tbaa !21
  br i1 %t198, label %bb74, label %bb75
bb74:
  store %olang.scope zeroinitializer, ptr %s10
  store { i64, ptr } { i64 0, ptr @.d23 }, ptr %l137, !tbaa !27
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s0)
  %t199 = load { i64, ptr }, ptr %l137, !tbaa !27
  store { i64, ptr } %t199, ptr %rv
  br label %ret
bb75:
  br label %bb76
bb76:
  %t200 = load i32, ptr %l4
  store i32 %t200, ptr %l138
  store ptr %l138, ptr %l139, !tbaa !29
  store i32 61, ptr %l140
  store ptr %l140, ptr %l141, !tbaa !29
  %t201 = load ptr, ptr %l139, !tbaa !29
  %t202 = load ptr, ptr %l141, !tbaa !29
  %t203 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t201, ptr %t202)
  store i1 %t203, ptr %l142
  br label %bb77
bb77:
  %t204 = load i1, ptr %l142, !tbaa !21
  br i1 %t204, label %bb78, label %bb79
bb78:
  store i1 true, ptr %l143, !tbaa !21
  br label %bb81
bb79:
  %t205 = load i32, ptr %l5
  store i32 %t205, ptr %l144
  store ptr %l144, ptr %l145, !tbaa !29
  store i32 61, ptr %l146
  store ptr %l146, ptr %l147, !tbaa !29
  %t206 = load ptr, ptr %l145, !tbaa !29
  %t207 = load ptr, ptr %l147, !tbaa !29
  %t208 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t206, ptr %t207)
  store i1 %t208, ptr %l148
  br label %bb80
bb80:
  %t209 = load i1, ptr %l148, !tbaa !21
  store i1 %t209, ptr %l143, !tbaa !21
  br label %bb81
bb81:
  %t210 = load i1, ptr %l143, !tbaa !21
  br i1 %t210, label %bb82, label %bb83
bb82:
  store %olang.scope zeroinitializer, ptr %s11
  store { i64, ptr } { i64 0, ptr @.d24 }, ptr %l149, !tbaa !27
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s0)
  %t211 = load { i64, ptr }, ptr %l149, !tbaa !27
  store { i64, ptr } %t211, ptr %rv
  br label %ret
bb83:
  br label %bb84
bb84:
  %t212 = load ptr, ptr %l0, !tbaa !29
  store ptr %t212, ptr %l150, !tbaa !29
  %t213 = load i64, ptr %l1, !tbaa !24
  store i64 %t213, ptr %l151, !tbaa !24
  %t214 = load i64, ptr %l3, !tbaa !24
  store i64 %t214, ptr %l152, !tbaa !24
  %t215 = load i64, ptr %l152, !tbaa !24
  %t216 = sub i64 %t215, 1
  store i64 %t216, ptr %l153, !tbaa !24
  %t217 = load ptr, ptr %l150, !tbaa !29
  %t218 = load i64, ptr %l151, !tbaa !24
  %t219 = load i64, ptr %l153, !tbaa !24
  %t220 = call i1 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2eprefix(ptr %v0, ptr %t217, i64 %t218, i64 %t219)
  store i1 %t220, ptr %l154
  br label %bb85
bb85:
  %t221 = load i1, ptr %l154, !tbaa !21
  br i1 %t221, label %bb86, label %bb87
bb86:
  store %olang.scope zeroinitializer, ptr %s12
  %t222 = load i32, ptr %l4
  store i32 %t222, ptr %l155
  store ptr %l155, ptr %l156, !tbaa !29
  store i32 52, ptr %l157
  store ptr %l157, ptr %l158, !tbaa !29
  %t223 = load ptr, ptr %l156, !tbaa !29
  %t224 = load ptr, ptr %l158, !tbaa !29
  %t225 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t223, ptr %t224)
  store i1 %t225, ptr %l159
  br label %bb88
bb87:
  br label %bb108
bb88:
  %t226 = load i1, ptr %l159, !tbaa !21
  br i1 %t226, label %bb89, label %bb90
bb89:
  %t227 = load i32, ptr %l5
  store i32 %t227, ptr %l161
  store ptr %l161, ptr %l162, !tbaa !29
  store i32 52, ptr %l163
  store ptr %l163, ptr %l164, !tbaa !29
  %t228 = load ptr, ptr %l162, !tbaa !29
  %t229 = load ptr, ptr %l164, !tbaa !29
  %t230 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t228, ptr %t229)
  store i1 %t230, ptr %l165
  br label %bb91
bb90:
  store i1 false, ptr %l160, !tbaa !21
  br label %bb96
bb91:
  %t231 = load i1, ptr %l165, !tbaa !21
  br i1 %t231, label %bb92, label %bb93
bb92:
  store i1 true, ptr %l166, !tbaa !21
  br label %bb95
bb93:
  %t232 = load i32, ptr %l5
  store i32 %t232, ptr %l167
  store ptr %l167, ptr %l168, !tbaa !29
  store i32 74, ptr %l169
  store ptr %l169, ptr %l170, !tbaa !29
  %t233 = load ptr, ptr %l168, !tbaa !29
  %t234 = load ptr, ptr %l170, !tbaa !29
  %t235 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t233, ptr %t234)
  store i1 %t235, ptr %l171
  br label %bb94
bb94:
  %t236 = load i1, ptr %l171, !tbaa !21
  store i1 %t236, ptr %l166, !tbaa !21
  br label %bb95
bb95:
  %t237 = load i1, ptr %l166, !tbaa !21
  store i1 %t237, ptr %l160, !tbaa !21
  br label %bb96
bb96:
  %t238 = load i1, ptr %l160, !tbaa !21
  br i1 %t238, label %bb97, label %bb98
bb97:
  store i1 true, ptr %l172, !tbaa !21
  br label %bb104
bb98:
  %t239 = load i32, ptr %l4
  store i32 %t239, ptr %l173
  store ptr %l173, ptr %l174, !tbaa !29
  store i32 74, ptr %l175
  store ptr %l175, ptr %l176, !tbaa !29
  %t240 = load ptr, ptr %l174, !tbaa !29
  %t241 = load ptr, ptr %l176, !tbaa !29
  %t242 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t240, ptr %t241)
  store i1 %t242, ptr %l177
  br label %bb99
bb99:
  %t243 = load i1, ptr %l177, !tbaa !21
  br i1 %t243, label %bb100, label %bb101
bb100:
  %t244 = load i32, ptr %l5
  store i32 %t244, ptr %l179
  store ptr %l179, ptr %l180, !tbaa !29
  store i32 52, ptr %l181
  store ptr %l181, ptr %l182, !tbaa !29
  %t245 = load ptr, ptr %l180, !tbaa !29
  %t246 = load ptr, ptr %l182, !tbaa !29
  %t247 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t245, ptr %t246)
  store i1 %t247, ptr %l183
  br label %bb102
bb101:
  store i1 false, ptr %l178, !tbaa !21
  br label %bb103
bb102:
  %t248 = load i1, ptr %l183, !tbaa !21
  store i1 %t248, ptr %l178, !tbaa !21
  br label %bb103
bb103:
  %t249 = load i1, ptr %l178, !tbaa !21
  store i1 %t249, ptr %l172, !tbaa !21
  br label %bb104
bb104:
  %t250 = load i1, ptr %l172, !tbaa !21
  br i1 %t250, label %bb105, label %bb106
bb105:
  store %olang.scope zeroinitializer, ptr %s13
  store { i64, ptr } { i64 1, ptr @.d25 }, ptr %l184, !tbaa !27
  call void @__olang_scope_close(ptr %s13)
  call void @__olang_scope_close(ptr %s12)
  call void @__olang_scope_close(ptr %s0)
  %t251 = load { i64, ptr }, ptr %l184, !tbaa !27
  store { i64, ptr } %t251, ptr %rv
  br label %ret
bb106:
  br label %bb107
bb107:
  store { i64, ptr } { i64 0, ptr @.d26 }, ptr %l185, !tbaa !27
  call void @__olang_scope_close(ptr %s12)
  call void @__olang_scope_close(ptr %s0)
  %t252 = load { i64, ptr }, ptr %l185, !tbaa !27
  store { i64, ptr } %t252, ptr %rv
  br label %ret
bb108:
  %t253 = load i32, ptr %l5
  store i32 %t253, ptr %l186
  store ptr %l186, ptr %l187, !tbaa !29
  store i32 73, ptr %l188
  store ptr %l188, ptr %l189, !tbaa !29
  %t254 = load ptr, ptr %l187, !tbaa !29
  %t255 = load ptr, ptr %l189, !tbaa !29
  %t256 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t254, ptr %t255)
  store i1 %t256, ptr %l190
  br label %bb109
bb109:
  %t257 = load i1, ptr %l190, !tbaa !21
  br i1 %t257, label %bb110, label %bb111
bb110:
  store i1 true, ptr %l191, !tbaa !21
  br label %bb113
bb111:
  %t258 = load i32, ptr %l5
  store i32 %t258, ptr %l192
  store ptr %l192, ptr %l193, !tbaa !29
  store i32 74, ptr %l194
  store ptr %l194, ptr %l195, !tbaa !29
  %t259 = load ptr, ptr %l193, !tbaa !29
  %t260 = load ptr, ptr %l195, !tbaa !29
  %t261 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t259, ptr %t260)
  store i1 %t261, ptr %l196
  br label %bb112
bb112:
  %t262 = load i1, ptr %l196, !tbaa !21
  store i1 %t262, ptr %l191, !tbaa !21
  br label %bb113
bb113:
  %t263 = load i1, ptr %l191, !tbaa !21
  br i1 %t263, label %bb114, label %bb115
bb114:
  %t264 = load ptr, ptr %l0, !tbaa !29
  store ptr %t264, ptr %l198, !tbaa !29
  %t265 = load i64, ptr %l1, !tbaa !24
  store i64 %t265, ptr %l199, !tbaa !24
  %t266 = load ptr, ptr %l198, !tbaa !29
  %t267 = load i64, ptr %l199, !tbaa !24
  %t268 = call i1 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2eoperandEnd(ptr %v0, ptr %t266, i64 %t267)
  store i1 %t268, ptr %l200
  br label %bb116
bb115:
  store i1 false, ptr %l197, !tbaa !21
  br label %bb117
bb116:
  %t269 = load i1, ptr %l200, !tbaa !21
  store i1 %t269, ptr %l197, !tbaa !21
  br label %bb117
bb117:
  %t270 = load i1, ptr %l197, !tbaa !21
  br i1 %t270, label %bb118, label %bb119
bb118:
  store %olang.scope zeroinitializer, ptr %s14
  store { i64, ptr } { i64 0, ptr @.d27 }, ptr %l201, !tbaa !27
  call void @__olang_scope_close(ptr %s14)
  call void @__olang_scope_close(ptr %s0)
  %t271 = load { i64, ptr }, ptr %l201, !tbaa !27
  store { i64, ptr } %t271, ptr %rv
  br label %ret
bb119:
  br label %bb120
bb120:
  %t272 = load i32, ptr %l5
  store i32 %t272, ptr %l202
  store ptr %l202, ptr %l203, !tbaa !29
  store i32 90, ptr %l204
  store ptr %l204, ptr %l205, !tbaa !29
  %t273 = load ptr, ptr %l203, !tbaa !29
  %t274 = load ptr, ptr %l205, !tbaa !29
  %t275 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t273, ptr %t274)
  store i1 %t275, ptr %l206
  br label %bb121
bb121:
  %t276 = load i1, ptr %l206, !tbaa !21
  br i1 %t276, label %bb122, label %bb123
bb122:
  store %olang.scope zeroinitializer, ptr %s15
  %t277 = load i32, ptr %l4
  store i32 %t277, ptr %l207
  store ptr %l207, ptr %l208, !tbaa !29
  store i32 37, ptr %l209
  store ptr %l209, ptr %l210, !tbaa !29
  %t278 = load ptr, ptr %l208, !tbaa !29
  %t279 = load ptr, ptr %l210, !tbaa !29
  %t280 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t278, ptr %t279)
  store i1 %t280, ptr %l211
  br label %bb124
bb123:
  br label %bb187
bb124:
  %t281 = load i1, ptr %l211, !tbaa !21
  br i1 %t281, label %bb125, label %bb126
bb125:
  store %olang.scope zeroinitializer, ptr %s16
  %t282 = load ptr, ptr %l0, !tbaa !29
  store ptr %t282, ptr %l212, !tbaa !29
  %t283 = load i64, ptr %l1, !tbaa !24
  store i64 %t283, ptr %l213, !tbaa !24
  %t284 = load i64, ptr %l3, !tbaa !24
  store i64 %t284, ptr %l214, !tbaa !24
  %t285 = load i64, ptr %l214, !tbaa !24
  %t286 = sub i64 %t285, 1
  store i64 %t286, ptr %l215, !tbaa !24
  %t287 = load ptr, ptr %l212, !tbaa !29
  %t288 = load i64, ptr %l213, !tbaa !24
  %t289 = load i64, ptr %l215, !tbaa !24
  %t290 = call i1 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2ereceiver(ptr %v0, ptr %t287, i64 %t288, i64 %t289)
  store i1 %t290, ptr %l216
  br label %bb127
bb126:
  br label %bb131
bb127:
  %t291 = load i1, ptr %l216, !tbaa !21
  br i1 %t291, label %bb128, label %bb129
bb128:
  store { i64, ptr } { i64 1, ptr @.d28 }, ptr %l217, !tbaa !27
  br label %bb130
bb129:
  store { i64, ptr } { i64 0, ptr @.d29 }, ptr %l217, !tbaa !27
  br label %bb130
bb130:
  call void @__olang_scope_close(ptr %s16)
  call void @__olang_scope_close(ptr %s15)
  call void @__olang_scope_close(ptr %s0)
  %t292 = load { i64, ptr }, ptr %l217, !tbaa !27
  store { i64, ptr } %t292, ptr %rv
  br label %ret
bb131:
  %t293 = load i32, ptr %l4
  store i32 %t293, ptr %l218
  store ptr %l218, ptr %l219, !tbaa !29
  store i32 34, ptr %l220
  store ptr %l220, ptr %l221, !tbaa !29
  %t294 = load ptr, ptr %l219, !tbaa !29
  %t295 = load ptr, ptr %l221, !tbaa !29
  %t296 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t294, ptr %t295)
  store i1 %t296, ptr %l222
  br label %bb132
bb132:
  %t297 = load i1, ptr %l222, !tbaa !21
  br i1 %t297, label %bb133, label %bb134
bb133:
  store %olang.scope zeroinitializer, ptr %s17
  store { i64, ptr } { i64 0, ptr @.d30 }, ptr %l223, !tbaa !27
  call void @__olang_scope_close(ptr %s17)
  call void @__olang_scope_close(ptr %s15)
  call void @__olang_scope_close(ptr %s0)
  %t298 = load { i64, ptr }, ptr %l223, !tbaa !27
  store { i64, ptr } %t298, ptr %rv
  br label %ret
bb134:
  br label %bb135
bb135:
  %t299 = load i32, ptr %l4
  store i32 %t299, ptr %l224
  store ptr %l224, ptr %l225, !tbaa !29
  store i32 95, ptr %l226
  store ptr %l226, ptr %l227, !tbaa !29
  %t300 = load ptr, ptr %l225, !tbaa !29
  %t301 = load ptr, ptr %l227, !tbaa !29
  %t302 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t300, ptr %t301)
  store i1 %t302, ptr %l228
  br label %bb136
bb136:
  %t303 = load i1, ptr %l228, !tbaa !21
  br i1 %t303, label %bb137, label %bb138
bb137:
  store %olang.scope zeroinitializer, ptr %s18
  %t304 = load ptr, ptr %l0, !tbaa !29
  store ptr %t304, ptr %l229, !tbaa !29
  %t305 = load i64, ptr %l2, !tbaa !24
  store i64 %t305, ptr %l230, !tbaa !24
  %t306 = load ptr, ptr %l229, !tbaa !29
  %t307 = load i64, ptr %l230, !tbaa !24
  %t308 = call { i64, ptr } @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2easWritten(ptr %v0, ptr %v1, ptr %t306, i64 %t307)
  store { i64, ptr } %t308, ptr %l231
  br label %bb139
bb138:
  br label %bb140
bb139:
  call void @__olang_scope_close(ptr %s18)
  call void @__olang_scope_close(ptr %s15)
  call void @__olang_scope_close(ptr %s0)
  %t309 = load { i64, ptr }, ptr %l231, !tbaa !27
  store { i64, ptr } %t309, ptr %rv
  br label %ret
bb140:
  %t310 = load ptr, ptr %l0, !tbaa !29
  store ptr %t310, ptr %l232, !tbaa !29
  %t311 = load i64, ptr %l1, !tbaa !24
  store i64 %t311, ptr %l233, !tbaa !24
  %t312 = load ptr, ptr %l232, !tbaa !29
  %t313 = load i64, ptr %l233, !tbaa !24
  %t314 = call i1 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2ekeyword(ptr %v0, ptr %t312, i64 %t313)
  store i1 %t314, ptr %l234
  br label %bb141
bb141:
  %t315 = load i1, ptr %l234, !tbaa !21
  br i1 %t315, label %bb142, label %bb143
bb142:
  %t316 = load i64, ptr %l3, !tbaa !24
  store i64 %t316, ptr %l236, !tbaa !24
  %t317 = load i64, ptr %l236, !tbaa !24
  %t318 = icmp sge i64 %t317, 2
  store i1 %t318, ptr %l237, !tbaa !21
  %t319 = load i1, ptr %l237, !tbaa !21
  store i1 %t319, ptr %l235, !tbaa !21
  br label %bb144
bb143:
  store i1 false, ptr %l235, !tbaa !21
  br label %bb144
bb144:
  %t320 = load i1, ptr %l235, !tbaa !21
  br i1 %t320, label %bb145, label %bb146
bb145:
  %t321 = load ptr, ptr %l0, !tbaa !29
  store ptr %t321, ptr %l239, !tbaa !29
  %t322 = load ptr, ptr %l0, !tbaa !29
  store ptr %t322, ptr %l240, !tbaa !29
  %t323 = load ptr, ptr %l240, !tbaa !29
  %t324 = getelementptr %"compiler/fmt:formatter", ptr %t323, i32 0, i32 4
  store ptr %t324, ptr %l241, !tbaa !29
  %t325 = load i64, ptr %l3, !tbaa !24
  store i64 %t325, ptr %l242, !tbaa !24
  %t326 = load i64, ptr %l242, !tbaa !24
  %t327 = sub i64 %t326, 2
  store i64 %t327, ptr %l243, !tbaa !24
  %t328 = load ptr, ptr %l241, !tbaa !29
  %t329 = load i64, ptr %l243, !tbaa !24
  %t330 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t328, i64 %t329)
  store i64 %t330, ptr %l244
  br label %bb147
bb146:
  store i1 false, ptr %l238, !tbaa !21
  br label %bb150
bb147:
  %t331 = load ptr, ptr %l239, !tbaa !29
  %t332 = load i64, ptr %l244, !tbaa !24
  %t333 = call i32 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2ekind(ptr %v0, ptr %t331, i64 %t332)
  store i32 %t333, ptr %l245
  br label %bb148
bb148:
  store ptr %l245, ptr %l246, !tbaa !29
  store i32 91, ptr %l247
  store ptr %l247, ptr %l248, !tbaa !29
  %t334 = load ptr, ptr %l246, !tbaa !29
  %t335 = load ptr, ptr %l248, !tbaa !29
  %t336 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t334, ptr %t335)
  store i1 %t336, ptr %l249
  br label %bb149
bb149:
  %t337 = load i1, ptr %l249, !tbaa !21
  store i1 %t337, ptr %l238, !tbaa !21
  br label %bb150
bb150:
  %t338 = load i1, ptr %l238, !tbaa !21
  br i1 %t338, label %bb151, label %bb152
bb151:
  store %olang.scope zeroinitializer, ptr %s19
  %t339 = load ptr, ptr %l0, !tbaa !29
  store ptr %t339, ptr %l250, !tbaa !29
  %t340 = load ptr, ptr %l250, !tbaa !29
  %t341 = getelementptr %"compiler/fmt:formatter", ptr %t340, i32 0, i32 20
  %t342 = load { i64, ptr }, ptr %t341, !tbaa !27
  store { i64, ptr } %t342, ptr %l251, !tbaa !27
  %t343 = load ptr, ptr %l0, !tbaa !29
  store ptr %t343, ptr %l252, !tbaa !29
  %t344 = load ptr, ptr %l252, !tbaa !29
  %t345 = getelementptr %"compiler/fmt:formatter", ptr %t344, i32 0, i32 4
  store ptr %t345, ptr %l253, !tbaa !29
  %t346 = load i64, ptr %l3, !tbaa !24
  store i64 %t346, ptr %l254, !tbaa !24
  %t347 = load i64, ptr %l254, !tbaa !24
  %t348 = sub i64 %t347, 2
  store i64 %t348, ptr %l255, !tbaa !24
  %t349 = load ptr, ptr %l253, !tbaa !29
  %t350 = load i64, ptr %l255, !tbaa !24
  %t351 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t349, i64 %t350)
  store i64 %t351, ptr %l256
  br label %bb153
bb152:
  br label %bb162
bb153:
  %t352 = load i64, ptr %l256, !tbaa !24
  %t353 = getelementptr { i64, ptr }, ptr %l251, i32 0, i32 1
  %t354 = load ptr, ptr %t353, !tbaa !27
  %t355 = getelementptr i64, ptr %t354, i64 %t352
  %t356 = load i64, ptr %t355, !tbaa !34
  store i64 %t356, ptr %l257, !tbaa !24
  %t357 = load i64, ptr %l257, !tbaa !24
  store i64 %t357, ptr %l7, !tbaa !24
  %t358 = load i64, ptr %l7, !tbaa !24
  store i64 %t358, ptr %l258, !tbaa !24
  %t359 = load i64, ptr %l258, !tbaa !24
  %t360 = icmp sgt i64 %t359, 0
  store i1 %t360, ptr %l259, !tbaa !21
  %t361 = load i1, ptr %l259, !tbaa !21
  br i1 %t361, label %bb154, label %bb155
bb154:
  %t362 = load ptr, ptr %l0, !tbaa !29
  store ptr %t362, ptr %l261, !tbaa !29
  %t363 = load i64, ptr %l7, !tbaa !24
  store i64 %t363, ptr %l262, !tbaa !24
  %t364 = load i64, ptr %l262, !tbaa !24
  %t365 = sub i64 %t364, 1
  store i64 %t365, ptr %l263, !tbaa !24
  %t366 = load ptr, ptr %l261, !tbaa !29
  %t367 = load i64, ptr %l263, !tbaa !24
  %t368 = call i32 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2ekind(ptr %v0, ptr %t366, i64 %t367)
  store i32 %t368, ptr %l264
  br label %bb156
bb155:
  store i1 false, ptr %l260, !tbaa !21
  br label %bb158
bb156:
  store ptr %l264, ptr %l265, !tbaa !29
  store i32 37, ptr %l266
  store ptr %l266, ptr %l267, !tbaa !29
  %t369 = load ptr, ptr %l265, !tbaa !29
  %t370 = load ptr, ptr %l267, !tbaa !29
  %t371 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t369, ptr %t370)
  store i1 %t371, ptr %l268
  br label %bb157
bb157:
  %t372 = load i1, ptr %l268, !tbaa !21
  store i1 %t372, ptr %l260, !tbaa !21
  br label %bb158
bb158:
  %t373 = load i1, ptr %l260, !tbaa !21
  br i1 %t373, label %bb159, label %bb160
bb159:
  store %olang.scope zeroinitializer, ptr %s20
  store { i64, ptr } { i64 0, ptr @.d31 }, ptr %l269, !tbaa !27
  call void @__olang_scope_close(ptr %s20)
  call void @__olang_scope_close(ptr %s19)
  call void @__olang_scope_close(ptr %s15)
  call void @__olang_scope_close(ptr %s0)
  %t374 = load { i64, ptr }, ptr %l269, !tbaa !27
  store { i64, ptr } %t374, ptr %rv
  br label %ret
bb160:
  br label %bb161
bb161:
  call void @__olang_scope_close(ptr %s19)
  br label %bb162
bb162:
  %t375 = load i32, ptr %l4
  store i32 %t375, ptr %l270
  store ptr %l270, ptr %l271, !tbaa !29
  store i32 91, ptr %l272
  store ptr %l272, ptr %l273, !tbaa !29
  %t376 = load ptr, ptr %l271, !tbaa !29
  %t377 = load ptr, ptr %l273, !tbaa !29
  %t378 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t376, ptr %t377)
  store i1 %t378, ptr %l274
  br label %bb163
bb163:
  %t379 = load i1, ptr %l274, !tbaa !21
  br i1 %t379, label %bb164, label %bb165
bb164:
  store %olang.scope zeroinitializer, ptr %s21
  %t380 = load ptr, ptr %l0, !tbaa !29
  store ptr %t380, ptr %l275, !tbaa !29
  %t381 = load ptr, ptr %l0, !tbaa !29
  store ptr %t381, ptr %l276, !tbaa !29
  %t382 = load ptr, ptr %l276, !tbaa !29
  %t383 = getelementptr %"compiler/fmt:formatter", ptr %t382, i32 0, i32 20
  %t384 = load { i64, ptr }, ptr %t383, !tbaa !27
  store { i64, ptr } %t384, ptr %l277, !tbaa !27
  %t385 = load i64, ptr %l1, !tbaa !24
  store i64 %t385, ptr %l278, !tbaa !24
  %t386 = load i64, ptr %l278, !tbaa !24
  %t387 = getelementptr { i64, ptr }, ptr %l277, i32 0, i32 1
  %t388 = load ptr, ptr %t387, !tbaa !27
  %t389 = getelementptr i64, ptr %t388, i64 %t386
  %t390 = load i64, ptr %t389, !tbaa !34
  store i64 %t390, ptr %l279, !tbaa !24
  %t391 = load ptr, ptr %l275, !tbaa !29
  %t392 = load i64, ptr %l279, !tbaa !24
  %t393 = call i64 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2eparams(ptr %v0, ptr %t391, i64 %t392)
  store i64 %t393, ptr %l280
  br label %bb166
bb165:
  br label %bb174
bb166:
  %t394 = load i64, ptr %l280, !tbaa !24
  store i64 %t394, ptr %l8, !tbaa !24
  %t395 = load i64, ptr %l8, !tbaa !24
  store i64 %t395, ptr %l281, !tbaa !24
  %t396 = load i64, ptr %l281, !tbaa !24
  %t397 = icmp eq i64 %t396, 1
  store i1 %t397, ptr %l282, !tbaa !21
  %t398 = load i1, ptr %l282, !tbaa !21
  br i1 %t398, label %bb167, label %bb168
bb167:
  store %olang.scope zeroinitializer, ptr %s22
  store { i64, ptr } { i64 1, ptr @.d32 }, ptr %l283, !tbaa !27
  call void @__olang_scope_close(ptr %s22)
  call void @__olang_scope_close(ptr %s21)
  call void @__olang_scope_close(ptr %s15)
  call void @__olang_scope_close(ptr %s0)
  %t399 = load { i64, ptr }, ptr %l283, !tbaa !27
  store { i64, ptr } %t399, ptr %rv
  br label %ret
bb168:
  br label %bb169
bb169:
  %t400 = load i64, ptr %l8, !tbaa !24
  store i64 %t400, ptr %l284, !tbaa !24
  %t401 = load i64, ptr %l284, !tbaa !24
  %t402 = icmp eq i64 %t401, 2
  store i1 %t402, ptr %l285, !tbaa !21
  %t403 = load i1, ptr %l285, !tbaa !21
  br i1 %t403, label %bb170, label %bb171
bb170:
  store %olang.scope zeroinitializer, ptr %s23
  %t404 = load ptr, ptr %l0, !tbaa !29
  store ptr %t404, ptr %l286, !tbaa !29
  %t405 = load i64, ptr %l2, !tbaa !24
  store i64 %t405, ptr %l287, !tbaa !24
  %t406 = load ptr, ptr %l286, !tbaa !29
  %t407 = load i64, ptr %l287, !tbaa !24
  %t408 = call { i64, ptr } @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2easWritten(ptr %v0, ptr %v1, ptr %t406, i64 %t407)
  store { i64, ptr } %t408, ptr %l288
  br label %bb172
bb171:
  br label %bb173
bb172:
  call void @__olang_scope_close(ptr %s23)
  call void @__olang_scope_close(ptr %s21)
  call void @__olang_scope_close(ptr %s15)
  call void @__olang_scope_close(ptr %s0)
  %t409 = load { i64, ptr }, ptr %l288, !tbaa !27
  store { i64, ptr } %t409, ptr %rv
  br label %ret
bb173:
  call void @__olang_scope_close(ptr %s21)
  br label %bb174
bb174:
  %t410 = load ptr, ptr %l0, !tbaa !29
  store ptr %t410, ptr %l289, !tbaa !29
  %t411 = load i64, ptr %l1, !tbaa !24
  store i64 %t411, ptr %l290, !tbaa !24
  %t412 = load ptr, ptr %l289, !tbaa !29
  %t413 = load i64, ptr %l290, !tbaa !24
  %t414 = call i1 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2eoperandEnd(ptr %v0, ptr %t412, i64 %t413)
  store i1 %t414, ptr %l291
  br label %bb175
bb175:
  %t415 = load i1, ptr %l291, !tbaa !21
  br i1 %t415, label %bb176, label %bb177
bb176:
  %t416 = load i32, ptr %l4
  store i32 %t416, ptr %l293
  store ptr %l293, ptr %l294, !tbaa !29
  store i32 73, ptr %l295
  store ptr %l295, ptr %l296, !tbaa !29
  %t417 = load ptr, ptr %l294, !tbaa !29
  %t418 = load ptr, ptr %l296, !tbaa !29
  %t419 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t417, ptr %t418)
  store i1 %t419, ptr %l297
  br label %bb178
bb177:
  store i1 false, ptr %l292, !tbaa !21
  br label %bb179
bb178:
  %t420 = load i1, ptr %l297, !tbaa !21
  %t421 = xor i1 %t420, true
  store i1 %t421, ptr %l298, !tbaa !21
  %t422 = load i1, ptr %l298, !tbaa !21
  store i1 %t422, ptr %l292, !tbaa !21
  br label %bb179
bb179:
  %t423 = load i1, ptr %l292, !tbaa !21
  br i1 %t423, label %bb180, label %bb181
bb180:
  %t424 = load i32, ptr %l4
  store i32 %t424, ptr %l300
  store ptr %l300, ptr %l301, !tbaa !29
  store i32 74, ptr %l302
  store ptr %l302, ptr %l303, !tbaa !29
  %t425 = load ptr, ptr %l301, !tbaa !29
  %t426 = load ptr, ptr %l303, !tbaa !29
  %t427 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t425, ptr %t426)
  store i1 %t427, ptr %l304
  br label %bb182
bb181:
  store i1 false, ptr %l299, !tbaa !21
  br label %bb183
bb182:
  %t428 = load i1, ptr %l304, !tbaa !21
  %t429 = xor i1 %t428, true
  store i1 %t429, ptr %l305, !tbaa !21
  %t430 = load i1, ptr %l305, !tbaa !21
  store i1 %t430, ptr %l299, !tbaa !21
  br label %bb183
bb183:
  %t431 = load i1, ptr %l299, !tbaa !21
  br i1 %t431, label %bb184, label %bb185
bb184:
  store %olang.scope zeroinitializer, ptr %s24
  store { i64, ptr } { i64 0, ptr @.d33 }, ptr %l306, !tbaa !27
  call void @__olang_scope_close(ptr %s24)
  call void @__olang_scope_close(ptr %s15)
  call void @__olang_scope_close(ptr %s0)
  %t432 = load { i64, ptr }, ptr %l306, !tbaa !27
  store { i64, ptr } %t432, ptr %rv
  br label %ret
bb185:
  br label %bb186
bb186:
  store { i64, ptr } { i64 1, ptr @.d34 }, ptr %l307, !tbaa !27
  call void @__olang_scope_close(ptr %s15)
  call void @__olang_scope_close(ptr %s0)
  %t433 = load { i64, ptr }, ptr %l307, !tbaa !27
  store { i64, ptr } %t433, ptr %rv
  br label %ret
bb187:
  %t434 = load i32, ptr %l5
  store i32 %t434, ptr %l308
  store ptr %l308, ptr %l309, !tbaa !29
  store i32 92, ptr %l310
  store ptr %l310, ptr %l311, !tbaa !29
  %t435 = load ptr, ptr %l309, !tbaa !29
  %t436 = load ptr, ptr %l311, !tbaa !29
  %t437 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t435, ptr %t436)
  store i1 %t437, ptr %l312
  br label %bb188
bb188:
  %t438 = load i1, ptr %l312, !tbaa !21
  br i1 %t438, label %bb189, label %bb190
bb189:
  store %olang.scope zeroinitializer, ptr %s25
  %t439 = load i32, ptr %l4
  store i32 %t439, ptr %l313
  store ptr %l313, ptr %l314, !tbaa !29
  store i32 95, ptr %l315
  store ptr %l315, ptr %l316, !tbaa !29
  %t440 = load ptr, ptr %l314, !tbaa !29
  %t441 = load ptr, ptr %l316, !tbaa !29
  %t442 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t440, ptr %t441)
  store i1 %t442, ptr %l317
  br label %bb191
bb190:
  br label %bb216
bb191:
  %t443 = load i1, ptr %l317, !tbaa !21
  br i1 %t443, label %bb192, label %bb193
bb192:
  store %olang.scope zeroinitializer, ptr %s26
  %t444 = load ptr, ptr %l0, !tbaa !29
  store ptr %t444, ptr %l318, !tbaa !29
  %t445 = load i64, ptr %l2, !tbaa !24
  store i64 %t445, ptr %l319, !tbaa !24
  %t446 = load ptr, ptr %l318, !tbaa !29
  %t447 = load i64, ptr %l319, !tbaa !24
  %t448 = call { i64, ptr } @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2easWritten(ptr %v0, ptr %v1, ptr %t446, i64 %t447)
  store { i64, ptr } %t448, ptr %l320
  br label %bb194
bb193:
  br label %bb195
bb194:
  call void @__olang_scope_close(ptr %s26)
  call void @__olang_scope_close(ptr %s25)
  call void @__olang_scope_close(ptr %s0)
  %t449 = load { i64, ptr }, ptr %l320, !tbaa !27
  store { i64, ptr } %t449, ptr %rv
  br label %ret
bb195:
  %t450 = load ptr, ptr %l0, !tbaa !29
  store ptr %t450, ptr %l321, !tbaa !29
  %t451 = load i64, ptr %l1, !tbaa !24
  store i64 %t451, ptr %l322, !tbaa !24
  %t452 = load ptr, ptr %l321, !tbaa !29
  %t453 = load i64, ptr %l322, !tbaa !24
  %t454 = call i1 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2eoperandEnd(ptr %v0, ptr %t452, i64 %t453)
  store i1 %t454, ptr %l323
  br label %bb196
bb196:
  %t455 = load i1, ptr %l323, !tbaa !21
  br i1 %t455, label %bb197, label %bb198
bb197:
  %t456 = load i32, ptr %l4
  store i32 %t456, ptr %l325
  store ptr %l325, ptr %l326, !tbaa !29
  store i32 73, ptr %l327
  store ptr %l327, ptr %l328, !tbaa !29
  %t457 = load ptr, ptr %l326, !tbaa !29
  %t458 = load ptr, ptr %l328, !tbaa !29
  %t459 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t457, ptr %t458)
  store i1 %t459, ptr %l329
  br label %bb199
bb198:
  store i1 false, ptr %l324, !tbaa !21
  br label %bb200
bb199:
  %t460 = load i1, ptr %l329, !tbaa !21
  %t461 = xor i1 %t460, true
  store i1 %t461, ptr %l330, !tbaa !21
  %t462 = load i1, ptr %l330, !tbaa !21
  store i1 %t462, ptr %l324, !tbaa !21
  br label %bb200
bb200:
  %t463 = load i1, ptr %l324, !tbaa !21
  br i1 %t463, label %bb201, label %bb202
bb201:
  %t464 = load i32, ptr %l4
  store i32 %t464, ptr %l332
  store ptr %l332, ptr %l333, !tbaa !29
  store i32 74, ptr %l334
  store ptr %l334, ptr %l335, !tbaa !29
  %t465 = load ptr, ptr %l333, !tbaa !29
  %t466 = load ptr, ptr %l335, !tbaa !29
  %t467 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t465, ptr %t466)
  store i1 %t467, ptr %l336
  br label %bb203
bb202:
  store i1 false, ptr %l331, !tbaa !21
  br label %bb204
bb203:
  %t468 = load i1, ptr %l336, !tbaa !21
  %t469 = xor i1 %t468, true
  store i1 %t469, ptr %l337, !tbaa !21
  %t470 = load i1, ptr %l337, !tbaa !21
  store i1 %t470, ptr %l331, !tbaa !21
  br label %bb204
bb204:
  %t471 = load i1, ptr %l331, !tbaa !21
  br i1 %t471, label %bb205, label %bb206
bb205:
  %t472 = load i32, ptr %l4
  store i32 %t472, ptr %l339
  store ptr %l339, ptr %l340, !tbaa !29
  store i32 2, ptr %l341
  store ptr %l341, ptr %l342, !tbaa !29
  %t473 = load ptr, ptr %l340, !tbaa !29
  %t474 = load ptr, ptr %l342, !tbaa !29
  %t475 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t473, ptr %t474)
  store i1 %t475, ptr %l343
  br label %bb207
bb206:
  store i1 false, ptr %l338, !tbaa !21
  br label %bb208
bb207:
  %t476 = load i1, ptr %l343, !tbaa !21
  %t477 = xor i1 %t476, true
  store i1 %t477, ptr %l344, !tbaa !21
  %t478 = load i1, ptr %l344, !tbaa !21
  store i1 %t478, ptr %l338, !tbaa !21
  br label %bb208
bb208:
  %t479 = load i1, ptr %l338, !tbaa !21
  br i1 %t479, label %bb209, label %bb210
bb209:
  %t480 = load i32, ptr %l4
  store i32 %t480, ptr %l346
  store ptr %l346, ptr %l347, !tbaa !29
  store i32 3, ptr %l348
  store ptr %l348, ptr %l349, !tbaa !29
  %t481 = load ptr, ptr %l347, !tbaa !29
  %t482 = load ptr, ptr %l349, !tbaa !29
  %t483 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t481, ptr %t482)
  store i1 %t483, ptr %l350
  br label %bb211
bb210:
  store i1 false, ptr %l345, !tbaa !21
  br label %bb212
bb211:
  %t484 = load i1, ptr %l350, !tbaa !21
  %t485 = xor i1 %t484, true
  store i1 %t485, ptr %l351, !tbaa !21
  %t486 = load i1, ptr %l351, !tbaa !21
  store i1 %t486, ptr %l345, !tbaa !21
  br label %bb212
bb212:
  %t487 = load i1, ptr %l345, !tbaa !21
  br i1 %t487, label %bb213, label %bb214
bb213:
  store %olang.scope zeroinitializer, ptr %s27
  store { i64, ptr } { i64 0, ptr @.d35 }, ptr %l352, !tbaa !27
  call void @__olang_scope_close(ptr %s27)
  call void @__olang_scope_close(ptr %s25)
  call void @__olang_scope_close(ptr %s0)
  %t488 = load { i64, ptr }, ptr %l352, !tbaa !27
  store { i64, ptr } %t488, ptr %rv
  br label %ret
bb214:
  br label %bb215
bb215:
  store { i64, ptr } { i64 1, ptr @.d36 }, ptr %l353, !tbaa !27
  call void @__olang_scope_close(ptr %s25)
  call void @__olang_scope_close(ptr %s0)
  %t489 = load { i64, ptr }, ptr %l353, !tbaa !27
  store { i64, ptr } %t489, ptr %rv
  br label %ret
bb216:
  %t490 = load ptr, ptr %l0, !tbaa !29
  store ptr %t490, ptr %l354, !tbaa !29
  %t491 = load ptr, ptr %l354, !tbaa !29
  %t492 = getelementptr %"compiler/fmt:formatter", ptr %t491, i32 0, i32 2
  %t493 = load { i64, ptr }, ptr %t492, !tbaa !27
  store { i64, ptr } %t493, ptr %l355, !tbaa !27
  %t494 = load i64, ptr %l2, !tbaa !24
  store i64 %t494, ptr %l356, !tbaa !24
  %t495 = load i64, ptr %l356, !tbaa !24
  %t496 = getelementptr { i64, ptr }, ptr %l355, i32 0, i32 1
  %t497 = load ptr, ptr %t496, !tbaa !27
  %t498 = getelementptr i64, ptr %t497, i64 %t495
  %t499 = load i64, ptr %t498, !tbaa !34
  store i64 %t499, ptr %l357, !tbaa !24
  %t500 = load i64, ptr %l357, !tbaa !24
  %t501 = icmp sgt i64 %t500, 0
  store i1 %t501, ptr %l358, !tbaa !21
  %t502 = load i1, ptr %l358, !tbaa !21
  br i1 %t502, label %bb217, label %bb218
bb217:
  store %olang.scope zeroinitializer, ptr %s28
  store { i64, ptr } { i64 0, ptr @.d37 }, ptr %l359, !tbaa !27
  call void @__olang_scope_close(ptr %s28)
  call void @__olang_scope_close(ptr %s0)
  %t503 = load { i64, ptr }, ptr %l359, !tbaa !27
  store { i64, ptr } %t503, ptr %rv
  br label %ret
bb218:
  br label %bb219
bb219:
  store { i64, ptr } { i64 1, ptr @.d38 }, ptr %l360, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t504 = load { i64, ptr }, ptr %l360, !tbaa !27
  store { i64, ptr } %t504, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2etokText(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i32
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i32
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i1
  %l16 = alloca i1
  %l17 = alloca i1
  %l18 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/fmt:formatter", ptr %t2, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l3, !tbaa !27
  %t5 = load ptr, ptr %l0, !tbaa !29
  store ptr %t5, ptr %l4, !tbaa !29
  %t6 = load ptr, ptr %l4, !tbaa !29
  %t7 = getelementptr %"compiler/fmt:formatter", ptr %t6, i32 0, i32 1
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  store { i64, ptr } %t8, ptr %l5, !tbaa !27
  %t9 = load i64, ptr %l1, !tbaa !24
  store i64 %t9, ptr %l6, !tbaa !24
  %t10 = load i64, ptr %l6, !tbaa !24
  %t11 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t12 = load ptr, ptr %t11, !tbaa !27
  %t13 = getelementptr %"compiler/token:Token", ptr %t12, i64 %t10
  %t14 = getelementptr %"compiler/token:Token", ptr %t13, i32 0, i32 2
  %t15 = load i32, ptr %t14, !tbaa !23
  store i32 %t15, ptr %l7, !tbaa !23
  %t16 = load i32, ptr %l7, !tbaa !23
  %t17 = sext i32 %t16 to i64
  store i64 %t17, ptr %l8, !tbaa !24
  %t18 = load ptr, ptr %l0, !tbaa !29
  store ptr %t18, ptr %l9, !tbaa !29
  %t19 = load ptr, ptr %l9, !tbaa !29
  %t20 = getelementptr %"compiler/fmt:formatter", ptr %t19, i32 0, i32 1
  %t21 = load { i64, ptr }, ptr %t20, !tbaa !27
  store { i64, ptr } %t21, ptr %l10, !tbaa !27
  %t22 = load i64, ptr %l1, !tbaa !24
  store i64 %t22, ptr %l11, !tbaa !24
  %t23 = load i64, ptr %l11, !tbaa !24
  %t24 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = getelementptr %"compiler/token:Token", ptr %t25, i64 %t23
  %t27 = getelementptr %"compiler/token:Token", ptr %t26, i32 0, i32 3
  %t28 = load i32, ptr %t27, !tbaa !23
  store i32 %t28, ptr %l12, !tbaa !23
  %t29 = load i32, ptr %l12, !tbaa !23
  %t30 = sext i32 %t29 to i64
  store i64 %t30, ptr %l13, !tbaa !24
  %t31 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t31, 0
  store i64 %t32, ptr %l14, !tbaa !24
  %t33 = load i64, ptr %l8, !tbaa !24
  %t34 = icmp sge i64 %t33, 0
  store i1 %t34, ptr %l15, !tbaa !21
  %t35 = load i1, ptr %l15, !tbaa !21
  br i1 %t35, label %bb1, label %bb2
bb1:
  %t36 = load i64, ptr %l8, !tbaa !24
  %t37 = load i64, ptr %l13, !tbaa !24
  %t38 = icmp sle i64 %t36, %t37
  store i1 %t38, ptr %l16, !tbaa !21
  %t39 = load i1, ptr %l16, !tbaa !21
  br i1 %t39, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @.c39)
  unreachable
bb3:
  %t40 = load i64, ptr %l13, !tbaa !24
  %t41 = load i64, ptr %l14, !tbaa !24
  %t42 = icmp sle i64 %t40, %t41
  store i1 %t42, ptr %l17, !tbaa !21
  %t43 = load i1, ptr %l17, !tbaa !21
  br i1 %t43, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @.c39)
  unreachable
bb5:
  %t44 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !27
  %t46 = load i64, ptr %l8, !tbaa !24
  %t47 = load i64, ptr %l13, !tbaa !24
  %t48 = getelementptr i8, ptr %t45, i64 %t46
  %t49 = sub i64 %t47, %t46
  %t50 = insertvalue { i64, ptr } undef, i64 %t49, 0
  %t51 = insertvalue { i64, ptr } %t50, ptr %t48, 1
  store { i64, ptr } %t51, ptr %l18, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t52 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t52, ptr %rv
  br label %ret
bb6:
  call void @__olang_check_failed(ptr @.c39)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2etoken(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca i1
  %l11 = alloca i1
  %l12 = alloca ptr
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca ptr
  %l16 = alloca i64
  %l17 = alloca ptr
  %l18 = alloca i64
  %l19 = alloca i1
  %l20 = alloca ptr
  %l21 = alloca ptr
  %l22 = alloca i64
  %l23 = alloca i1
  %l24 = alloca ptr
  %l25 = alloca ptr
  %l26 = alloca ptr
  %l27 = alloca i64
  %l28 = alloca i1
  %l29 = alloca ptr
  %l30 = alloca ptr
  %l31 = alloca ptr
  %l32 = alloca ptr
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca { i64, ptr }
  %l37 = alloca ptr
  %l38 = alloca i64
  %l39 = alloca { i64, ptr }
  %l40 = alloca ptr
  %l41 = alloca { i64, ptr }
  %l42 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i1
  %l45 = alloca i1
  %l46 = alloca ptr
  %l47 = alloca { i64, ptr }
  %l48 = alloca i64
  %l49 = alloca i64
  %l50 = alloca { i64, ptr }
  %l51 = alloca i64
  %l52 = alloca i1
  %l53 = alloca i1
  %l54 = alloca { i64, ptr }
  %l55 = alloca ptr
  %l56 = alloca { i64, ptr }
  %l57 = alloca i64
  %l58 = alloca i64
  %l59 = alloca { i64, ptr }
  %l60 = alloca { i64, ptr }
  %l61 = alloca i64
  %l62 = alloca i64
  %l63 = alloca i1
  %l64 = alloca i1
  %l65 = alloca i1
  %l66 = alloca { i64, ptr }
  %l67 = alloca i1
  %l68 = alloca ptr
  %l69 = alloca ptr
  %l70 = alloca { i64, ptr }
  %l71 = alloca ptr
  %l72 = alloca { i64, ptr }
  %l73 = alloca i64
  %l74 = alloca i64
  %l75 = alloca i64
  %l76 = alloca i1
  %l77 = alloca i1
  %l78 = alloca i1
  %l79 = alloca { i64, ptr }
  %l80 = alloca ptr
  %l81 = alloca ptr
  %l82 = alloca ptr
  %l83 = alloca ptr
  %l84 = alloca { i64, ptr }
  %l85 = alloca ptr
  %l86 = alloca ptr
  %l87 = alloca i64
  %l88 = alloca ptr
  %l89 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = getelementptr %"compiler/fmt:formatter", ptr %t2, i32 0, i32 4
  store ptr %t3, ptr %l6, !tbaa !29
  %t4 = load i64, ptr %l1, !tbaa !24
  store i64 %t4, ptr %l7, !tbaa !24
  %t5 = load ptr, ptr %l6, !tbaa !29
  %t6 = load i64, ptr %l7, !tbaa !24
  %t7 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t5, i64 %t6)
  store i64 %t7, ptr %l8
  br label %bb1
bb1:
  %t8 = load i64, ptr %l8, !tbaa !24
  store i64 %t8, ptr %l2, !tbaa !24
  %t9 = load ptr, ptr %l0, !tbaa !29
  store ptr %t9, ptr %l9, !tbaa !29
  %t10 = load ptr, ptr %l9, !tbaa !29
  %t11 = getelementptr %"compiler/fmt:formatter", ptr %t10, i32 0, i32 17
  %t12 = load i1, ptr %t11, !tbaa !21
  store i1 %t12, ptr %l10, !tbaa !21
  %t13 = load i1, ptr %l10, !tbaa !21
  %t14 = xor i1 %t13, true
  store i1 %t14, ptr %l11, !tbaa !21
  %t15 = load i1, ptr %l11, !tbaa !21
  br i1 %t15, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t16 = load ptr, ptr %l0, !tbaa !29
  store ptr %t16, ptr %l12, !tbaa !29
  %t17 = load i64, ptr %l1, !tbaa !24
  store i64 %t17, ptr %l13, !tbaa !24
  %t18 = load ptr, ptr %l12, !tbaa !29
  %t19 = load i64, ptr %l13, !tbaa !24
  %t20 = call i64 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2elevel(ptr %v0, ptr %t18, i64 %t19)
  store i64 %t20, ptr %l14
  br label %bb4
bb3:
  store %olang.scope zeroinitializer, ptr %s3
  %t21 = load ptr, ptr %l0, !tbaa !29
  store ptr %t21, ptr %l21, !tbaa !29
  %t22 = load ptr, ptr %l21, !tbaa !29
  %t23 = getelementptr %"compiler/fmt:formatter", ptr %t22, i32 0, i32 25
  %t24 = load i64, ptr %t23, !tbaa !24
  store i64 %t24, ptr %l22, !tbaa !24
  %t25 = load i64, ptr %l22, !tbaa !24
  %t26 = icmp eq i64 %t25, 2
  store i1 %t26, ptr %l23, !tbaa !21
  %t27 = load i1, ptr %l23, !tbaa !21
  br i1 %t27, label %bb11, label %bb12
bb4:
  %t28 = load i64, ptr %l14, !tbaa !24
  store i64 %t28, ptr %l3, !tbaa !24
  %t29 = load ptr, ptr %l0, !tbaa !29
  store ptr %t29, ptr %l15, !tbaa !29
  %t30 = load i64, ptr %l3, !tbaa !24
  store i64 %t30, ptr %l16, !tbaa !24
  %t31 = load ptr, ptr %l15, !tbaa !29
  %t32 = load i64, ptr %l16, !tbaa !24
  call void @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2ebegin(ptr %v0, ptr %t31, i64 %t32)
  br label %bb5
bb5:
  %t33 = load ptr, ptr %l0, !tbaa !29
  store ptr %t33, ptr %l17, !tbaa !29
  %t34 = load i64, ptr %l2, !tbaa !24
  store i64 %t34, ptr %l18, !tbaa !24
  %t35 = load ptr, ptr %l17, !tbaa !29
  %t36 = load i64, ptr %l18, !tbaa !24
  %t37 = call i1 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2eclosing(ptr %v0, ptr %t35, i64 %t36)
  store i1 %t37, ptr %l19
  br label %bb6
bb6:
  %t38 = load i1, ptr %l19, !tbaa !21
  br i1 %t38, label %bb7, label %bb8
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t39 = load ptr, ptr %l0, !tbaa !29
  store ptr %t39, ptr %l20, !tbaa !29
  %t40 = load ptr, ptr %l20, !tbaa !29
  call void @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2edropBlank(ptr %v0, ptr %t40)
  br label %bb9
bb8:
  br label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s1)
  br label %bb20
bb11:
  store %olang.scope zeroinitializer, ptr %s4
  %t41 = load ptr, ptr %l0, !tbaa !29
  store ptr %t41, ptr %l24, !tbaa !29
  %t42 = load ptr, ptr %l24, !tbaa !29
  %t43 = getelementptr %"compiler/fmt:formatter", ptr %t42, i32 0, i32 16
  store ptr %t43, ptr %l25, !tbaa !29
  %t44 = load ptr, ptr %l25, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %t44, i8 32)
  br label %bb13
bb12:
  store %olang.scope zeroinitializer, ptr %s5
  %t45 = load ptr, ptr %l0, !tbaa !29
  store ptr %t45, ptr %l26, !tbaa !29
  %t46 = load ptr, ptr %l26, !tbaa !29
  %t47 = getelementptr %"compiler/fmt:formatter", ptr %t46, i32 0, i32 25
  %t48 = load i64, ptr %t47, !tbaa !24
  store i64 %t48, ptr %l27, !tbaa !24
  %t49 = load i64, ptr %l27, !tbaa !24
  %t50 = icmp eq i64 %t49, 1
  store i1 %t50, ptr %l28, !tbaa !21
  %t51 = load i1, ptr %l28, !tbaa !21
  br i1 %t51, label %bb14, label %bb15
bb13:
  call void @__olang_scope_close(ptr %s4)
  br label %bb19
bb14:
  store %olang.scope zeroinitializer, ptr %s6
  %t52 = load ptr, ptr %l0, !tbaa !29
  store ptr %t52, ptr %l29, !tbaa !29
  %t53 = load ptr, ptr %l29, !tbaa !29
  %t54 = getelementptr %"compiler/fmt:formatter", ptr %t53, i32 0, i32 16
  store ptr %t54, ptr %l30, !tbaa !29
  %t55 = load ptr, ptr %l0, !tbaa !29
  store ptr %t55, ptr %l31, !tbaa !29
  %t56 = load ptr, ptr %l0, !tbaa !29
  store ptr %t56, ptr %l32, !tbaa !29
  %t57 = load ptr, ptr %l32, !tbaa !29
  %t58 = getelementptr %"compiler/fmt:formatter", ptr %t57, i32 0, i32 26
  %t59 = load i64, ptr %t58, !tbaa !24
  store i64 %t59, ptr %l33, !tbaa !24
  %t60 = load i64, ptr %l2, !tbaa !24
  store i64 %t60, ptr %l34, !tbaa !24
  %t61 = load i64, ptr %l1, !tbaa !24
  store i64 %t61, ptr %l35, !tbaa !24
  %t62 = load ptr, ptr %l31, !tbaa !29
  %t63 = load i64, ptr %l33, !tbaa !24
  %t64 = load i64, ptr %l34, !tbaa !24
  %t65 = load i64, ptr %l35, !tbaa !24
  %t66 = call { i64, ptr } @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2espace(ptr %v0, ptr %s6, ptr %t62, i64 %t63, i64 %t64, i64 %t65)
  store { i64, ptr } %t66, ptr %l36
  br label %bb16
bb15:
  br label %bb18
bb16:
  %t67 = load ptr, ptr %l30, !tbaa !29
  %t68 = load { i64, ptr }, ptr %l36, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s6, ptr %t67, { i64, ptr } %t68)
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s6)
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s5)
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s3)
  br label %bb20
bb20:
  %t69 = load ptr, ptr %l0, !tbaa !29
  store ptr %t69, ptr %l37, !tbaa !29
  %t70 = load i64, ptr %l2, !tbaa !24
  store i64 %t70, ptr %l38, !tbaa !24
  %t71 = load ptr, ptr %l37, !tbaa !29
  %t72 = load i64, ptr %l38, !tbaa !24
  %t73 = call { i64, ptr } @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2etokText(ptr %v0, ptr %t71, i64 %t72)
  store { i64, ptr } %t73, ptr %l39
  br label %bb21
bb21:
  %t74 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t74, ptr %l4, !tbaa !27
  %t75 = load ptr, ptr %l0, !tbaa !29
  store ptr %t75, ptr %l40, !tbaa !29
  %t76 = load ptr, ptr %l40, !tbaa !29
  %t77 = getelementptr %"compiler/fmt:formatter", ptr %t76, i32 0, i32 3
  %t78 = load { i64, ptr }, ptr %t77, !tbaa !27
  store { i64, ptr } %t78, ptr %l41, !tbaa !27
  %t79 = load i64, ptr %l2, !tbaa !24
  store i64 %t79, ptr %l42, !tbaa !24
  %t80 = load i64, ptr %l42, !tbaa !24
  %t81 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !27
  %t83 = getelementptr i64, ptr %t82, i64 %t80
  %t84 = load i64, ptr %t83, !tbaa !34
  store i64 %t84, ptr %l43, !tbaa !24
  %t85 = load i64, ptr %l43, !tbaa !24
  %t86 = icmp sgt i64 %t85, 0
  store i1 %t86, ptr %l44, !tbaa !21
  %t87 = load i1, ptr %l44, !tbaa !21
  br i1 %t87, label %bb22, label %bb23
bb22:
  %t88 = load ptr, ptr %l0, !tbaa !29
  store ptr %t88, ptr %l46, !tbaa !29
  %t89 = load ptr, ptr %l46, !tbaa !29
  %t90 = getelementptr %"compiler/fmt:formatter", ptr %t89, i32 0, i32 3
  %t91 = load { i64, ptr }, ptr %t90, !tbaa !27
  store { i64, ptr } %t91, ptr %l47, !tbaa !27
  %t92 = load i64, ptr %l2, !tbaa !24
  store i64 %t92, ptr %l48, !tbaa !24
  %t93 = load i64, ptr %l48, !tbaa !24
  %t94 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !27
  %t96 = getelementptr i64, ptr %t95, i64 %t93
  %t97 = load i64, ptr %t96, !tbaa !34
  store i64 %t97, ptr %l49, !tbaa !24
  %t98 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t98, ptr %l50, !tbaa !27
  %t99 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t100 = extractvalue { i64, ptr } %t99, 0
  store i64 %t100, ptr %l51, !tbaa !24
  %t101 = load i64, ptr %l49, !tbaa !24
  %t102 = load i64, ptr %l51, !tbaa !24
  %t103 = icmp slt i64 %t101, %t102
  store i1 %t103, ptr %l52, !tbaa !21
  %t104 = load i1, ptr %l52, !tbaa !21
  store i1 %t104, ptr %l45, !tbaa !21
  br label %bb24
bb23:
  store i1 false, ptr %l45, !tbaa !21
  br label %bb24
bb24:
  %t105 = load i1, ptr %l45, !tbaa !21
  br i1 %t105, label %bb25, label %bb26
bb25:
  %t106 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t106, ptr %l54, !tbaa !27
  %t107 = load ptr, ptr %l0, !tbaa !29
  store ptr %t107, ptr %l55, !tbaa !29
  %t108 = load ptr, ptr %l55, !tbaa !29
  %t109 = getelementptr %"compiler/fmt:formatter", ptr %t108, i32 0, i32 3
  %t110 = load { i64, ptr }, ptr %t109, !tbaa !27
  store { i64, ptr } %t110, ptr %l56, !tbaa !27
  %t111 = load i64, ptr %l2, !tbaa !24
  store i64 %t111, ptr %l57, !tbaa !24
  %t112 = load i64, ptr %l57, !tbaa !24
  %t113 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t114 = load ptr, ptr %t113, !tbaa !27
  %t115 = getelementptr i64, ptr %t114, i64 %t112
  %t116 = load i64, ptr %t115, !tbaa !34
  store i64 %t116, ptr %l58, !tbaa !24
  %t117 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t117, ptr %l59, !tbaa !27
  %t118 = load { i64, ptr }, ptr %l59, !tbaa !27
  store { i64, ptr } %t118, ptr %l60, !tbaa !27
  %t119 = load { i64, ptr }, ptr %l60, !tbaa !27
  %t120 = extractvalue { i64, ptr } %t119, 0
  store i64 %t120, ptr %l61, !tbaa !24
  %t121 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t122 = extractvalue { i64, ptr } %t121, 0
  store i64 %t122, ptr %l62, !tbaa !24
  %t123 = load i64, ptr %l58, !tbaa !24
  %t124 = icmp sge i64 %t123, 0
  store i1 %t124, ptr %l63, !tbaa !21
  %t125 = load i1, ptr %l63, !tbaa !21
  br i1 %t125, label %bb27, label %bb28
bb26:
  store i1 false, ptr %l53, !tbaa !21
  br label %bb34
bb27:
  %t126 = load i64, ptr %l58, !tbaa !24
  %t127 = load i64, ptr %l61, !tbaa !24
  %t128 = icmp sle i64 %t126, %t127
  store i1 %t128, ptr %l64, !tbaa !21
  %t129 = load i1, ptr %l64, !tbaa !21
  br i1 %t129, label %bb29, label %bb30
bb28:
  call void @__olang_check_failed(ptr @.c40)
  unreachable
bb29:
  %t130 = load i64, ptr %l61, !tbaa !24
  %t131 = load i64, ptr %l62, !tbaa !24
  %t132 = icmp sle i64 %t130, %t131
  store i1 %t132, ptr %l65, !tbaa !21
  %t133 = load i1, ptr %l65, !tbaa !21
  br i1 %t133, label %bb31, label %bb32
bb30:
  call void @__olang_check_failed(ptr @.c40)
  unreachable
bb31:
  %t134 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t135 = load ptr, ptr %t134, !tbaa !27
  %t136 = load i64, ptr %l58, !tbaa !24
  %t137 = load i64, ptr %l61, !tbaa !24
  %t138 = getelementptr i8, ptr %t135, i64 %t136
  %t139 = sub i64 %t137, %t136
  %t140 = insertvalue { i64, ptr } undef, i64 %t139, 0
  %t141 = insertvalue { i64, ptr } %t140, ptr %t138, 1
  store { i64, ptr } %t141, ptr %l66, !tbaa !27
  %t142 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t143 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t142, { i64, ptr } { i64 1, ptr @.d41 })
  store i1 %t143, ptr %l67
  br label %bb33
bb32:
  call void @__olang_check_failed(ptr @.c40)
  unreachable
bb33:
  %t144 = load i1, ptr %l67, !tbaa !21
  store i1 %t144, ptr %l53, !tbaa !21
  br label %bb34
bb34:
  %t145 = load i1, ptr %l53, !tbaa !21
  br i1 %t145, label %bb35, label %bb36
bb35:
  store %olang.scope zeroinitializer, ptr %s7
  %t146 = load ptr, ptr %l0, !tbaa !29
  store ptr %t146, ptr %l68, !tbaa !29
  %t147 = load ptr, ptr %l68, !tbaa !29
  %t148 = getelementptr %"compiler/fmt:formatter", ptr %t147, i32 0, i32 16
  store ptr %t148, ptr %l69, !tbaa !29
  %t149 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t149, ptr %l70, !tbaa !27
  %t150 = load ptr, ptr %l0, !tbaa !29
  store ptr %t150, ptr %l71, !tbaa !29
  %t151 = load ptr, ptr %l71, !tbaa !29
  %t152 = getelementptr %"compiler/fmt:formatter", ptr %t151, i32 0, i32 3
  %t153 = load { i64, ptr }, ptr %t152, !tbaa !27
  store { i64, ptr } %t153, ptr %l72, !tbaa !27
  %t154 = load i64, ptr %l2, !tbaa !24
  store i64 %t154, ptr %l73, !tbaa !24
  %t155 = load i64, ptr %l73, !tbaa !24
  %t156 = getelementptr { i64, ptr }, ptr %l72, i32 0, i32 1
  %t157 = load ptr, ptr %t156, !tbaa !27
  %t158 = getelementptr i64, ptr %t157, i64 %t155
  %t159 = load i64, ptr %t158, !tbaa !34
  store i64 %t159, ptr %l74, !tbaa !24
  %t160 = load { i64, ptr }, ptr %l70, !tbaa !27
  %t161 = extractvalue { i64, ptr } %t160, 0
  store i64 %t161, ptr %l75, !tbaa !24
  %t162 = icmp sge i64 0, 0
  store i1 %t162, ptr %l76, !tbaa !21
  %t163 = load i1, ptr %l76, !tbaa !21
  br i1 %t163, label %bb37, label %bb38
bb36:
  store %olang.scope zeroinitializer, ptr %s8
  %t164 = load ptr, ptr %l0, !tbaa !29
  store ptr %t164, ptr %l82, !tbaa !29
  %t165 = load ptr, ptr %l82, !tbaa !29
  %t166 = getelementptr %"compiler/fmt:formatter", ptr %t165, i32 0, i32 16
  store ptr %t166, ptr %l83, !tbaa !29
  %t167 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t167, ptr %l84, !tbaa !27
  %t168 = load ptr, ptr %l83, !tbaa !29
  %t169 = load { i64, ptr }, ptr %l84, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v0, ptr %t168, { i64, ptr } %t169)
  br label %bb45
bb37:
  %t170 = load i64, ptr %l74, !tbaa !24
  %t171 = icmp sle i64 0, %t170
  store i1 %t171, ptr %l77, !tbaa !21
  %t172 = load i1, ptr %l77, !tbaa !21
  br i1 %t172, label %bb39, label %bb40
bb38:
  call void @__olang_check_failed(ptr @.c42)
  unreachable
bb39:
  %t173 = load i64, ptr %l74, !tbaa !24
  %t174 = load i64, ptr %l75, !tbaa !24
  %t175 = icmp sle i64 %t173, %t174
  store i1 %t175, ptr %l78, !tbaa !21
  %t176 = load i1, ptr %l78, !tbaa !21
  br i1 %t176, label %bb41, label %bb42
bb40:
  call void @__olang_check_failed(ptr @.c42)
  unreachable
bb41:
  %t177 = getelementptr { i64, ptr }, ptr %l70, i32 0, i32 1
  %t178 = load ptr, ptr %t177, !tbaa !27
  %t179 = load i64, ptr %l74, !tbaa !24
  %t180 = getelementptr i8, ptr %t178, i64 0
  %t181 = sub i64 %t179, 0
  %t182 = insertvalue { i64, ptr } undef, i64 %t181, 0
  %t183 = insertvalue { i64, ptr } %t182, ptr %t180, 1
  store { i64, ptr } %t183, ptr %l79, !tbaa !27
  %t184 = load ptr, ptr %l69, !tbaa !29
  %t185 = load { i64, ptr }, ptr %l79, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v0, ptr %t184, { i64, ptr } %t185)
  br label %bb43
bb42:
  call void @__olang_check_failed(ptr @.c42)
  unreachable
bb43:
  %t186 = load ptr, ptr %l0, !tbaa !29
  store ptr %t186, ptr %l80, !tbaa !29
  %t187 = load ptr, ptr %l80, !tbaa !29
  %t188 = getelementptr %"compiler/fmt:formatter", ptr %t187, i32 0, i32 16
  store ptr %t188, ptr %l81, !tbaa !29
  %t189 = load ptr, ptr %l81, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s7, ptr %t189, { i64, ptr } { i64 2, ptr @.d43 })
  br label %bb44
bb44:
  call void @__olang_scope_close(ptr %s7)
  br label %bb46
bb45:
  call void @__olang_scope_close(ptr %s8)
  br label %bb46
bb46:
  %t190 = load ptr, ptr %l0, !tbaa !29
  store ptr %t190, ptr %l85, !tbaa !29
  %t191 = load ptr, ptr %l85, !tbaa !29
  %t192 = getelementptr %"compiler/fmt:formatter", ptr %t191, i32 0, i32 25
  store i64 1, ptr %t192, !tbaa !24
  %t193 = load ptr, ptr %l0, !tbaa !29
  store ptr %t193, ptr %l86, !tbaa !29
  %t194 = load i64, ptr %l2, !tbaa !24
  store i64 %t194, ptr %l87, !tbaa !24
  %t195 = load i64, ptr %l87, !tbaa !24
  %t196 = load ptr, ptr %l86, !tbaa !29
  %t197 = getelementptr %"compiler/fmt:formatter", ptr %t196, i32 0, i32 26
  store i64 %t195, ptr %t197, !tbaa !24
  %t198 = load ptr, ptr %l0, !tbaa !29
  store ptr %t198, ptr %l88, !tbaa !29
  %t199 = load i64, ptr %l2, !tbaa !24
  store i64 %t199, ptr %l89, !tbaa !24
  %t200 = load ptr, ptr %l88, !tbaa !29
  %t201 = load i64, ptr %l89, !tbaa !24
  call void @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2etrack(ptr %v0, ptr %t200, i64 %t201)
  br label %bb47
bb47:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2etrack(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca ptr
  %l19 = alloca i64
  %l20 = alloca i32
  %l21 = alloca ptr
  %l22 = alloca { i64, ptr }
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i32
  %l26 = alloca i1
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i1
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i1
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i64
  %l45 = alloca i1
  %l46 = alloca i1
  %l47 = alloca i64
  %l48 = alloca i64
  %l49 = alloca i64
  %l50 = alloca i64
  %l51 = alloca i64
  %l52 = alloca ptr
  %l53 = alloca ptr
  %l54 = alloca i64
  %l55 = alloca i64
  %l56 = alloca i1
  %l57 = alloca ptr
  %l58 = alloca ptr
  %l59 = alloca i64
  %l60 = alloca i64
  %l61 = alloca ptr
  %l62 = alloca ptr
  %l63 = alloca i64
  %l64 = alloca i64
  %l65 = alloca ptr
  %l66 = alloca ptr
  %l67 = alloca i64
  %l68 = alloca i64
  %l69 = alloca i64
  %l70 = alloca i64
  %l71 = alloca i32
  %l72 = alloca ptr
  %l73 = alloca i32
  %l74 = alloca ptr
  %l75 = alloca i1
  %l76 = alloca ptr
  %l77 = alloca ptr
  %l78 = alloca i64
  %l79 = alloca i64
  %l80 = alloca i1
  %l81 = alloca i1
  %l82 = alloca ptr
  %l83 = alloca ptr
  %l84 = alloca i64
  %l85 = alloca i64
  %l86 = alloca i64
  %l87 = alloca i1
  %l88 = alloca ptr
  %l89 = alloca ptr
  %l90 = alloca i64
  %l91 = alloca i64
  %l92 = alloca ptr
  %l93 = alloca i64
  %l94 = alloca ptr
  %l95 = alloca ptr
  %l96 = alloca i64
  %l97 = alloca i64
  %l98 = alloca ptr
  %l99 = alloca i64
  %l100 = alloca i32
  %l101 = alloca ptr
  %l102 = alloca i32
  %l103 = alloca ptr
  %l104 = alloca i1
  %l105 = alloca i1
  %l106 = alloca i32
  %l107 = alloca ptr
  %l108 = alloca i32
  %l109 = alloca ptr
  %l110 = alloca i1
  %l111 = alloca ptr
  %l112 = alloca ptr
  %l113 = alloca i64
  %l114 = alloca i64
  %l115 = alloca ptr
  %l116 = alloca i64
  %l117 = alloca ptr
  %l118 = alloca { i64, ptr }
  %l119 = alloca i64
  %l120 = alloca i64
  %l121 = alloca i64
  %l122 = alloca i64
  %l123 = alloca i1
  %l124 = alloca i64
  %l125 = alloca i64
  %l126 = alloca i1
  %l127 = alloca i64
  %l128 = alloca i64
  %l129 = alloca i64
  %l130 = alloca i64
  %l131 = alloca i64
  %l132 = alloca i64
  %l133 = alloca i64
  %l134 = alloca i64
  %l135 = alloca i64
  %l136 = alloca i64
  %l137 = alloca i64
  %l138 = alloca i1
  %l139 = alloca i1
  %l140 = alloca i64
  %l141 = alloca i64
  %l142 = alloca i64
  %l143 = alloca i64
  %l144 = alloca i64
  %l145 = alloca ptr
  %l146 = alloca ptr
  %l147 = alloca i64
  %l148 = alloca i64
  %l149 = alloca ptr
  %l150 = alloca i64
  %l151 = alloca i64
  %l152 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s14 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l18, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  store i64 %t2, ptr %l19, !tbaa !24
  %t3 = load ptr, ptr %l18, !tbaa !29
  %t4 = load i64, ptr %l19, !tbaa !24
  %t5 = call i32 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2ekind(ptr %v0, ptr %t3, i64 %t4)
  store i32 %t5, ptr %l20
  br label %bb1
bb1:
  %t6 = load i32, ptr %l20
  store i32 %t6, ptr %l2
  %t7 = load ptr, ptr %l0, !tbaa !29
  store ptr %t7, ptr %l21, !tbaa !29
  %t8 = load ptr, ptr %l21, !tbaa !29
  %t9 = getelementptr %"compiler/fmt:formatter", ptr %t8, i32 0, i32 3
  %t10 = load { i64, ptr }, ptr %t9, !tbaa !27
  store { i64, ptr } %t10, ptr %l22, !tbaa !27
  %t11 = load i64, ptr %l1, !tbaa !24
  store i64 %t11, ptr %l23, !tbaa !24
  %t12 = load i64, ptr %l23, !tbaa !24
  %t13 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !27
  %t15 = getelementptr i64, ptr %t14, i64 %t12
  %t16 = load i64, ptr %t15, !tbaa !34
  store i64 %t16, ptr %l24, !tbaa !24
  %t17 = load i64, ptr %l24, !tbaa !24
  store i64 %t17, ptr %l3, !tbaa !24
  %t18 = load i32, ptr %l2
  store i32 %t18, ptr %l25
  %t19 = load i32, ptr %l25
  %t20 = call i1 @compiler_2ffmt_2eisCloser(i32 %t19)
  store i1 %t20, ptr %l26
  br label %bb2
bb2:
  %t21 = load i1, ptr %l26, !tbaa !21
  br i1 %t21, label %bb3, label %bb4
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  store i64 1, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  br label %bb5
bb4:
  br label %bb5
bb5:
  store %olang.scope zeroinitializer, ptr %s2
  store i64 0, ptr %l4, !tbaa !24
  %t22 = load i64, ptr %l3, !tbaa !24
  store i64 %t22, ptr %l27, !tbaa !24
  %t23 = load i64, ptr %l27, !tbaa !24
  store i64 %t23, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t24 = load i64, ptr %l5, !tbaa !24
  store i64 %t24, ptr %l28, !tbaa !24
  %t25 = load i64, ptr %l4, !tbaa !24
  store i64 %t25, ptr %l29, !tbaa !24
  %t26 = load i64, ptr %l28, !tbaa !24
  %t27 = load i64, ptr %l29, !tbaa !24
  %t28 = icmp sgt i64 %t26, %t27
  store i1 %t28, ptr %l30, !tbaa !21
  %t29 = load i1, ptr %l30, !tbaa !21
  br i1 %t29, label %bb6, label %bb7
bb6:
  %t30 = load i64, ptr %l6, !tbaa !24
  store i64 %t30, ptr %l32, !tbaa !24
  %t31 = load i64, ptr %l32, !tbaa !24
  %t32 = icmp sgt i64 %t31, 0
  store i1 %t32, ptr %l33, !tbaa !21
  %t33 = load i1, ptr %l33, !tbaa !21
  br i1 %t33, label %bb8, label %bb9
bb7:
  store i64 0, ptr %l31, !tbaa !24
  br label %bb11
bb8:
  %t34 = load i64, ptr %l5, !tbaa !24
  store i64 %t34, ptr %l35, !tbaa !24
  %t35 = load i64, ptr %l4, !tbaa !24
  store i64 %t35, ptr %l36, !tbaa !24
  %t36 = load i64, ptr %l35, !tbaa !24
  %t37 = load i64, ptr %l36, !tbaa !24
  %t38 = sub i64 %t36, %t37
  store i64 %t38, ptr %l37, !tbaa !24
  %t39 = load i64, ptr %l6, !tbaa !24
  store i64 %t39, ptr %l38, !tbaa !24
  %t40 = load i64, ptr %l37, !tbaa !24
  %t41 = load i64, ptr %l38, !tbaa !24
  %t42 = add i64 %t40, %t41
  store i64 %t42, ptr %l39, !tbaa !24
  %t43 = load i64, ptr %l39, !tbaa !24
  %t44 = sub i64 %t43, 1
  store i64 %t44, ptr %l40, !tbaa !24
  %t45 = load i64, ptr %l6, !tbaa !24
  store i64 %t45, ptr %l41, !tbaa !24
  %t46 = load i64, ptr %l40, !tbaa !24
  %t47 = load i64, ptr %l41, !tbaa !24
  %t48 = sdiv i64 %t46, %t47
  store i64 %t48, ptr %l42, !tbaa !24
  %t49 = load i64, ptr %l42, !tbaa !24
  store i64 %t49, ptr %l34, !tbaa !24
  br label %bb10
bb9:
  store i64 0, ptr %l34, !tbaa !24
  br label %bb10
bb10:
  %t50 = load i64, ptr %l34, !tbaa !24
  store i64 %t50, ptr %l31, !tbaa !24
  br label %bb11
bb11:
  %t51 = load i64, ptr %l31, !tbaa !24
  store i64 %t51, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb12
bb12:
  store %olang.scope zeroinitializer, ptr %s3
  %t52 = load i64, ptr %l8, !tbaa !24
  store i64 %t52, ptr %l43, !tbaa !24
  %t53 = load i64, ptr %l7, !tbaa !24
  store i64 %t53, ptr %l44, !tbaa !24
  %t54 = load i64, ptr %l43, !tbaa !24
  %t55 = load i64, ptr %l44, !tbaa !24
  %t56 = icmp slt i64 %t54, %t55
  store i1 %t56, ptr %l45, !tbaa !21
  %t57 = load i1, ptr %l45, !tbaa !21
  %t58 = xor i1 %t57, true
  store i1 %t58, ptr %l46, !tbaa !21
  %t59 = load i1, ptr %l46, !tbaa !21
  br i1 %t59, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s3)
  br label %bb24
bb14:
  br label %bb15
bb15:
  %t60 = load i64, ptr %l4, !tbaa !24
  store i64 %t60, ptr %l47, !tbaa !24
  %t61 = load i64, ptr %l8, !tbaa !24
  store i64 %t61, ptr %l48, !tbaa !24
  %t62 = load i64, ptr %l6, !tbaa !24
  store i64 %t62, ptr %l49, !tbaa !24
  %t63 = load i64, ptr %l48, !tbaa !24
  %t64 = load i64, ptr %l49, !tbaa !24
  %t65 = mul i64 %t63, %t64
  store i64 %t65, ptr %l50, !tbaa !24
  %t66 = load i64, ptr %l47, !tbaa !24
  %t67 = load i64, ptr %l50, !tbaa !24
  %t68 = add i64 %t66, %t67
  store i64 %t68, ptr %l51, !tbaa !24
  %t69 = load i64, ptr %l51, !tbaa !24
  store i64 %t69, ptr %l9, !tbaa !24
  %t70 = load ptr, ptr %l0, !tbaa !29
  store ptr %t70, ptr %l52, !tbaa !29
  %t71 = load ptr, ptr %l52, !tbaa !29
  %t72 = getelementptr %"compiler/fmt:formatter", ptr %t71, i32 0, i32 6
  store ptr %t72, ptr %l53, !tbaa !29
  %t73 = load ptr, ptr %l53, !tbaa !29
  %t74 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t73)
  store i64 %t74, ptr %l54
  br label %bb16
bb16:
  %t75 = load i64, ptr %l54, !tbaa !24
  store i64 %t75, ptr %l10, !tbaa !24
  %t76 = load i64, ptr %l10, !tbaa !24
  store i64 %t76, ptr %l55, !tbaa !24
  %t77 = load i64, ptr %l55, !tbaa !24
  %t78 = icmp sgt i64 %t77, 0
  store i1 %t78, ptr %l56, !tbaa !21
  %t79 = load i1, ptr %l56, !tbaa !21
  br i1 %t79, label %bb17, label %bb18
bb17:
  store %olang.scope zeroinitializer, ptr %s4
  %t80 = load ptr, ptr %l0, !tbaa !29
  store ptr %t80, ptr %l57, !tbaa !29
  %t81 = load ptr, ptr %l57, !tbaa !29
  %t82 = getelementptr %"compiler/fmt:formatter", ptr %t81, i32 0, i32 6
  store ptr %t82, ptr %l58, !tbaa !29
  %t83 = load i64, ptr %l10, !tbaa !24
  store i64 %t83, ptr %l59, !tbaa !24
  %t84 = load i64, ptr %l59, !tbaa !24
  %t85 = sub i64 %t84, 1
  store i64 %t85, ptr %l60, !tbaa !24
  %t86 = load ptr, ptr %l58, !tbaa !29
  %t87 = load i64, ptr %l60, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eTruncate_3cI64_3e(ptr %v0, ptr %t86, i64 %t87)
  br label %bb19
bb18:
  br label %bb22
bb19:
  %t88 = load ptr, ptr %l0, !tbaa !29
  store ptr %t88, ptr %l61, !tbaa !29
  %t89 = load ptr, ptr %l61, !tbaa !29
  %t90 = getelementptr %"compiler/fmt:formatter", ptr %t89, i32 0, i32 7
  store ptr %t90, ptr %l62, !tbaa !29
  %t91 = load i64, ptr %l10, !tbaa !24
  store i64 %t91, ptr %l63, !tbaa !24
  %t92 = load i64, ptr %l63, !tbaa !24
  %t93 = sub i64 %t92, 1
  store i64 %t93, ptr %l64, !tbaa !24
  %t94 = load ptr, ptr %l62, !tbaa !29
  %t95 = load i64, ptr %l64, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eTruncate_3cI64_3e(ptr %v0, ptr %t94, i64 %t95)
  br label %bb20
bb20:
  %t96 = load ptr, ptr %l0, !tbaa !29
  store ptr %t96, ptr %l65, !tbaa !29
  %t97 = load ptr, ptr %l65, !tbaa !29
  %t98 = getelementptr %"compiler/fmt:formatter", ptr %t97, i32 0, i32 8
  store ptr %t98, ptr %l66, !tbaa !29
  %t99 = load i64, ptr %l10, !tbaa !24
  store i64 %t99, ptr %l67, !tbaa !24
  %t100 = load i64, ptr %l67, !tbaa !24
  %t101 = sub i64 %t100, 1
  store i64 %t101, ptr %l68, !tbaa !24
  %t102 = load ptr, ptr %l66, !tbaa !29
  %t103 = load i64, ptr %l68, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eTruncate_3cI64_3e(ptr %v0, ptr %t102, i64 %t103)
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s4)
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s3)
  br label %bb23
bb23:
  store %olang.scope zeroinitializer, ptr %s5
  %t104 = load i64, ptr %l8, !tbaa !24
  store i64 %t104, ptr %l69, !tbaa !24
  %t105 = load i64, ptr %l69, !tbaa !24
  %t106 = add i64 %t105, 1
  store i64 %t106, ptr %l70, !tbaa !24
  %t107 = load i64, ptr %l70, !tbaa !24
  store i64 %t107, ptr %l8, !tbaa !24
  call void @__olang_scope_close(ptr %s5)
  br label %bb12
bb24:
  call void @__olang_scope_close(ptr %s2)
  %t108 = load i32, ptr %l2
  store i32 %t108, ptr %l71
  store ptr %l71, ptr %l72, !tbaa !29
  store i32 94, ptr %l73
  store ptr %l73, ptr %l74, !tbaa !29
  %t109 = load ptr, ptr %l72, !tbaa !29
  %t110 = load ptr, ptr %l74, !tbaa !29
  %t111 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t109, ptr %t110)
  store i1 %t111, ptr %l75
  br label %bb25
bb25:
  %t112 = load i1, ptr %l75, !tbaa !21
  br i1 %t112, label %bb26, label %bb27
bb26:
  store %olang.scope zeroinitializer, ptr %s6
  %t113 = load ptr, ptr %l0, !tbaa !29
  store ptr %t113, ptr %l76, !tbaa !29
  %t114 = load ptr, ptr %l76, !tbaa !29
  %t115 = getelementptr %"compiler/fmt:formatter", ptr %t114, i32 0, i32 6
  store ptr %t115, ptr %l77, !tbaa !29
  %t116 = load ptr, ptr %l77, !tbaa !29
  %t117 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t116)
  store i64 %t117, ptr %l78
  br label %bb28
bb27:
  store %olang.scope zeroinitializer, ptr %s9
  %t118 = load i32, ptr %l2
  store i32 %t118, ptr %l100
  store ptr %l100, ptr %l101, !tbaa !29
  store i32 90, ptr %l102
  store ptr %l102, ptr %l103, !tbaa !29
  %t119 = load ptr, ptr %l101, !tbaa !29
  %t120 = load ptr, ptr %l103, !tbaa !29
  %t121 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t119, ptr %t120)
  store i1 %t121, ptr %l104
  br label %bb38
bb28:
  %t122 = load i64, ptr %l78, !tbaa !24
  store i64 %t122, ptr %l11, !tbaa !24
  %t123 = load i64, ptr %l11, !tbaa !24
  store i64 %t123, ptr %l79, !tbaa !24
  %t124 = load i64, ptr %l79, !tbaa !24
  %t125 = icmp eq i64 %t124, 0
  store i1 %t125, ptr %l80, !tbaa !21
  %t126 = load i1, ptr %l80, !tbaa !21
  br i1 %t126, label %bb29, label %bb30
bb29:
  store i1 true, ptr %l81, !tbaa !21
  br label %bb32
bb30:
  %t127 = load ptr, ptr %l0, !tbaa !29
  store ptr %t127, ptr %l82, !tbaa !29
  %t128 = load ptr, ptr %l82, !tbaa !29
  %t129 = getelementptr %"compiler/fmt:formatter", ptr %t128, i32 0, i32 6
  store ptr %t129, ptr %l83, !tbaa !29
  %t130 = load i64, ptr %l11, !tbaa !24
  store i64 %t130, ptr %l84, !tbaa !24
  %t131 = load i64, ptr %l84, !tbaa !24
  %t132 = sub i64 %t131, 1
  store i64 %t132, ptr %l85, !tbaa !24
  %t133 = load ptr, ptr %l83, !tbaa !29
  %t134 = load i64, ptr %l85, !tbaa !24
  %t135 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t133, i64 %t134)
  store i64 %t135, ptr %l86
  br label %bb31
bb31:
  %t136 = load i64, ptr %l86, !tbaa !24
  %t137 = icmp eq i64 %t136, 0
  store i1 %t137, ptr %l87, !tbaa !21
  %t138 = load i1, ptr %l87, !tbaa !21
  store i1 %t138, ptr %l81, !tbaa !21
  br label %bb32
bb32:
  %t139 = load i1, ptr %l81, !tbaa !21
  br i1 %t139, label %bb33, label %bb34
bb33:
  store %olang.scope zeroinitializer, ptr %s7
  %t140 = load ptr, ptr %l0, !tbaa !29
  store ptr %t140, ptr %l88, !tbaa !29
  %t141 = load ptr, ptr %l0, !tbaa !29
  store ptr %t141, ptr %l89, !tbaa !29
  %t142 = load ptr, ptr %l89, !tbaa !29
  %t143 = getelementptr %"compiler/fmt:formatter", ptr %t142, i32 0, i32 19
  %t144 = load i64, ptr %t143, !tbaa !24
  store i64 %t144, ptr %l90, !tbaa !24
  %t145 = load i64, ptr %l90, !tbaa !24
  %t146 = add i64 %t145, 1
  store i64 %t146, ptr %l91, !tbaa !24
  %t147 = load ptr, ptr %l0, !tbaa !29
  store ptr %t147, ptr %l92, !tbaa !29
  %t148 = load ptr, ptr %l92, !tbaa !29
  %t149 = getelementptr %"compiler/fmt:formatter", ptr %t148, i32 0, i32 19
  %t150 = load i64, ptr %t149, !tbaa !24
  store i64 %t150, ptr %l93, !tbaa !24
  %t151 = load ptr, ptr %l88, !tbaa !29
  %t152 = load i64, ptr %l91, !tbaa !24
  %t153 = load i64, ptr %l93, !tbaa !24
  call void @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2epush(ptr %v0, ptr %t151, i64 0, i64 %t152, i64 %t153)
  br label %bb35
bb34:
  store %olang.scope zeroinitializer, ptr %s8
  %t154 = load ptr, ptr %l0, !tbaa !29
  store ptr %t154, ptr %l94, !tbaa !29
  %t155 = load ptr, ptr %l0, !tbaa !29
  store ptr %t155, ptr %l95, !tbaa !29
  %t156 = load ptr, ptr %l95, !tbaa !29
  %t157 = getelementptr %"compiler/fmt:formatter", ptr %t156, i32 0, i32 18
  %t158 = load i64, ptr %t157, !tbaa !24
  store i64 %t158, ptr %l96, !tbaa !24
  %t159 = load i64, ptr %l96, !tbaa !24
  %t160 = add i64 %t159, 1
  store i64 %t160, ptr %l97, !tbaa !24
  %t161 = load ptr, ptr %l0, !tbaa !29
  store ptr %t161, ptr %l98, !tbaa !29
  %t162 = load ptr, ptr %l98, !tbaa !29
  %t163 = getelementptr %"compiler/fmt:formatter", ptr %t162, i32 0, i32 18
  %t164 = load i64, ptr %t163, !tbaa !24
  store i64 %t164, ptr %l99, !tbaa !24
  %t165 = load ptr, ptr %l94, !tbaa !29
  %t166 = load i64, ptr %l97, !tbaa !24
  %t167 = load i64, ptr %l99, !tbaa !24
  call void @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2epush(ptr %v0, ptr %t165, i64 0, i64 %t166, i64 %t167)
  br label %bb36
bb35:
  call void @__olang_scope_close(ptr %s7)
  br label %bb37
bb36:
  call void @__olang_scope_close(ptr %s8)
  br label %bb37
bb37:
  call void @__olang_scope_close(ptr %s6)
  br label %bb60
bb38:
  %t168 = load i1, ptr %l104, !tbaa !21
  br i1 %t168, label %bb39, label %bb40
bb39:
  store i1 true, ptr %l105, !tbaa !21
  br label %bb42
bb40:
  %t169 = load i32, ptr %l2
  store i32 %t169, ptr %l106
  store ptr %l106, ptr %l107, !tbaa !29
  store i32 92, ptr %l108
  store ptr %l108, ptr %l109, !tbaa !29
  %t170 = load ptr, ptr %l107, !tbaa !29
  %t171 = load ptr, ptr %l109, !tbaa !29
  %t172 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t170, ptr %t171)
  store i1 %t172, ptr %l110
  br label %bb41
bb41:
  %t173 = load i1, ptr %l110, !tbaa !21
  store i1 %t173, ptr %l105, !tbaa !21
  br label %bb42
bb42:
  %t174 = load i1, ptr %l105, !tbaa !21
  br i1 %t174, label %bb43, label %bb44
bb43:
  store %olang.scope zeroinitializer, ptr %s10
  %t175 = load ptr, ptr %l0, !tbaa !29
  store ptr %t175, ptr %l111, !tbaa !29
  %t176 = load ptr, ptr %l0, !tbaa !29
  store ptr %t176, ptr %l112, !tbaa !29
  %t177 = load ptr, ptr %l112, !tbaa !29
  %t178 = getelementptr %"compiler/fmt:formatter", ptr %t177, i32 0, i32 18
  %t179 = load i64, ptr %t178, !tbaa !24
  store i64 %t179, ptr %l113, !tbaa !24
  %t180 = load i64, ptr %l113, !tbaa !24
  %t181 = add i64 %t180, 1
  store i64 %t181, ptr %l114, !tbaa !24
  %t182 = load ptr, ptr %l0, !tbaa !29
  store ptr %t182, ptr %l115, !tbaa !29
  %t183 = load ptr, ptr %l115, !tbaa !29
  %t184 = getelementptr %"compiler/fmt:formatter", ptr %t183, i32 0, i32 18
  %t185 = load i64, ptr %t184, !tbaa !24
  store i64 %t185, ptr %l116, !tbaa !24
  %t186 = load ptr, ptr %l111, !tbaa !29
  %t187 = load i64, ptr %l114, !tbaa !24
  %t188 = load i64, ptr %l116, !tbaa !24
  call void @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2epush(ptr %v0, ptr %t186, i64 1, i64 %t187, i64 %t188)
  br label %bb45
bb44:
  store %olang.scope zeroinitializer, ptr %s11
  store %olang.scope zeroinitializer, ptr %s12
  store i64 0, ptr %l12, !tbaa !24
  %t189 = load ptr, ptr %l0, !tbaa !29
  store ptr %t189, ptr %l117, !tbaa !29
  %t190 = load ptr, ptr %l117, !tbaa !29
  %t191 = getelementptr %"compiler/fmt:formatter", ptr %t190, i32 0, i32 2
  %t192 = load { i64, ptr }, ptr %t191, !tbaa !27
  store { i64, ptr } %t192, ptr %l118, !tbaa !27
  %t193 = load i64, ptr %l1, !tbaa !24
  store i64 %t193, ptr %l119, !tbaa !24
  %t194 = load i64, ptr %l119, !tbaa !24
  %t195 = getelementptr { i64, ptr }, ptr %l118, i32 0, i32 1
  %t196 = load ptr, ptr %t195, !tbaa !27
  %t197 = getelementptr i64, ptr %t196, i64 %t194
  %t198 = load i64, ptr %t197, !tbaa !34
  store i64 %t198, ptr %l120, !tbaa !24
  %t199 = load i64, ptr %l120, !tbaa !24
  store i64 %t199, ptr %l13, !tbaa !24
  store i64 1, ptr %l14, !tbaa !24
  %t200 = load i64, ptr %l13, !tbaa !24
  store i64 %t200, ptr %l121, !tbaa !24
  %t201 = load i64, ptr %l12, !tbaa !24
  store i64 %t201, ptr %l122, !tbaa !24
  %t202 = load i64, ptr %l121, !tbaa !24
  %t203 = load i64, ptr %l122, !tbaa !24
  %t204 = icmp sgt i64 %t202, %t203
  store i1 %t204, ptr %l123, !tbaa !21
  %t205 = load i1, ptr %l123, !tbaa !21
  br i1 %t205, label %bb46, label %bb47
bb45:
  call void @__olang_scope_close(ptr %s10)
  br label %bb59
bb46:
  %t206 = load i64, ptr %l14, !tbaa !24
  store i64 %t206, ptr %l125, !tbaa !24
  %t207 = load i64, ptr %l125, !tbaa !24
  %t208 = icmp sgt i64 %t207, 0
  store i1 %t208, ptr %l126, !tbaa !21
  %t209 = load i1, ptr %l126, !tbaa !21
  br i1 %t209, label %bb48, label %bb49
bb47:
  store i64 0, ptr %l124, !tbaa !24
  br label %bb51
bb48:
  %t210 = load i64, ptr %l13, !tbaa !24
  store i64 %t210, ptr %l128, !tbaa !24
  %t211 = load i64, ptr %l12, !tbaa !24
  store i64 %t211, ptr %l129, !tbaa !24
  %t212 = load i64, ptr %l128, !tbaa !24
  %t213 = load i64, ptr %l129, !tbaa !24
  %t214 = sub i64 %t212, %t213
  store i64 %t214, ptr %l130, !tbaa !24
  %t215 = load i64, ptr %l14, !tbaa !24
  store i64 %t215, ptr %l131, !tbaa !24
  %t216 = load i64, ptr %l130, !tbaa !24
  %t217 = load i64, ptr %l131, !tbaa !24
  %t218 = add i64 %t216, %t217
  store i64 %t218, ptr %l132, !tbaa !24
  %t219 = load i64, ptr %l132, !tbaa !24
  %t220 = sub i64 %t219, 1
  store i64 %t220, ptr %l133, !tbaa !24
  %t221 = load i64, ptr %l14, !tbaa !24
  store i64 %t221, ptr %l134, !tbaa !24
  %t222 = load i64, ptr %l133, !tbaa !24
  %t223 = load i64, ptr %l134, !tbaa !24
  %t224 = sdiv i64 %t222, %t223
  store i64 %t224, ptr %l135, !tbaa !24
  %t225 = load i64, ptr %l135, !tbaa !24
  store i64 %t225, ptr %l127, !tbaa !24
  br label %bb50
bb49:
  store i64 0, ptr %l127, !tbaa !24
  br label %bb50
bb50:
  %t226 = load i64, ptr %l127, !tbaa !24
  store i64 %t226, ptr %l124, !tbaa !24
  br label %bb51
bb51:
  %t227 = load i64, ptr %l124, !tbaa !24
  store i64 %t227, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  br label %bb52
bb52:
  store %olang.scope zeroinitializer, ptr %s13
  %t228 = load i64, ptr %l16, !tbaa !24
  store i64 %t228, ptr %l136, !tbaa !24
  %t229 = load i64, ptr %l15, !tbaa !24
  store i64 %t229, ptr %l137, !tbaa !24
  %t230 = load i64, ptr %l136, !tbaa !24
  %t231 = load i64, ptr %l137, !tbaa !24
  %t232 = icmp slt i64 %t230, %t231
  store i1 %t232, ptr %l138, !tbaa !21
  %t233 = load i1, ptr %l138, !tbaa !21
  %t234 = xor i1 %t233, true
  store i1 %t234, ptr %l139, !tbaa !21
  %t235 = load i1, ptr %l139, !tbaa !21
  br i1 %t235, label %bb53, label %bb54
bb53:
  call void @__olang_scope_close(ptr %s13)
  br label %bb58
bb54:
  br label %bb55
bb55:
  %t236 = load i64, ptr %l12, !tbaa !24
  store i64 %t236, ptr %l140, !tbaa !24
  %t237 = load i64, ptr %l16, !tbaa !24
  store i64 %t237, ptr %l141, !tbaa !24
  %t238 = load i64, ptr %l14, !tbaa !24
  store i64 %t238, ptr %l142, !tbaa !24
  %t239 = load i64, ptr %l141, !tbaa !24
  %t240 = load i64, ptr %l142, !tbaa !24
  %t241 = mul i64 %t239, %t240
  store i64 %t241, ptr %l143, !tbaa !24
  %t242 = load i64, ptr %l140, !tbaa !24
  %t243 = load i64, ptr %l143, !tbaa !24
  %t244 = add i64 %t242, %t243
  store i64 %t244, ptr %l144, !tbaa !24
  %t245 = load i64, ptr %l144, !tbaa !24
  store i64 %t245, ptr %l17, !tbaa !24
  %t246 = load ptr, ptr %l0, !tbaa !29
  store ptr %t246, ptr %l145, !tbaa !29
  %t247 = load ptr, ptr %l0, !tbaa !29
  store ptr %t247, ptr %l146, !tbaa !29
  %t248 = load ptr, ptr %l146, !tbaa !29
  %t249 = getelementptr %"compiler/fmt:formatter", ptr %t248, i32 0, i32 18
  %t250 = load i64, ptr %t249, !tbaa !24
  store i64 %t250, ptr %l147, !tbaa !24
  %t251 = load i64, ptr %l147, !tbaa !24
  %t252 = add i64 %t251, 1
  store i64 %t252, ptr %l148, !tbaa !24
  %t253 = load ptr, ptr %l0, !tbaa !29
  store ptr %t253, ptr %l149, !tbaa !29
  %t254 = load ptr, ptr %l149, !tbaa !29
  %t255 = getelementptr %"compiler/fmt:formatter", ptr %t254, i32 0, i32 18
  %t256 = load i64, ptr %t255, !tbaa !24
  store i64 %t256, ptr %l150, !tbaa !24
  %t257 = load ptr, ptr %l145, !tbaa !29
  %t258 = load i64, ptr %l148, !tbaa !24
  %t259 = load i64, ptr %l150, !tbaa !24
  call void @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2epush(ptr %v0, ptr %t257, i64 1, i64 %t258, i64 %t259)
  br label %bb56
bb56:
  call void @__olang_scope_close(ptr %s13)
  br label %bb57
bb57:
  store %olang.scope zeroinitializer, ptr %s14
  %t260 = load i64, ptr %l16, !tbaa !24
  store i64 %t260, ptr %l151, !tbaa !24
  %t261 = load i64, ptr %l151, !tbaa !24
  %t262 = add i64 %t261, 1
  store i64 %t262, ptr %l152, !tbaa !24
  %t263 = load i64, ptr %l152, !tbaa !24
  store i64 %t263, ptr %l16, !tbaa !24
  call void @__olang_scope_close(ptr %s14)
  br label %bb52
bb58:
  call void @__olang_scope_close(ptr %s12)
  call void @__olang_scope_close(ptr %s11)
  br label %bb59
bb59:
  call void @__olang_scope_close(ptr %s9)
  br label %bb60
bb60:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2ewrite(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca ptr
  %l30 = alloca ptr
  %l31 = alloca { i64, ptr }
  %l32 = alloca %"std/prelude/text:StringBuilder"
  %l33 = alloca ptr
  %l34 = alloca ptr
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i1
  %l38 = alloca i1
  %l39 = alloca ptr
  %l40 = alloca ptr
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i1
  %l45 = alloca i1
  %l46 = alloca i64
  %l47 = alloca i64
  %l48 = alloca i64
  %l49 = alloca i64
  %l50 = alloca i1
  %l51 = alloca i1
  %l52 = alloca i64
  %l53 = alloca i64
  %l54 = alloca i64
  %l55 = alloca i1
  %l56 = alloca i1
  %l57 = alloca ptr
  %l58 = alloca ptr
  %l59 = alloca i64
  %l60 = alloca i64
  %l61 = alloca i1
  %l62 = alloca i1
  %l63 = alloca ptr
  %l64 = alloca ptr
  %l65 = alloca i64
  %l66 = alloca i64
  %l67 = alloca i1
  %l68 = alloca i1
  %l69 = alloca ptr
  %l70 = alloca ptr
  %l71 = alloca i64
  %l72 = alloca i64
  %l73 = alloca ptr
  %l74 = alloca ptr
  %l75 = alloca i64
  %l76 = alloca i64
  %l77 = alloca i1
  %l78 = alloca i1
  %l79 = alloca ptr
  %l80 = alloca ptr
  %l81 = alloca i64
  %l82 = alloca i1
  %l83 = alloca i1
  %l84 = alloca i1
  %l85 = alloca ptr
  %l86 = alloca ptr
  %l87 = alloca i64
  %l88 = alloca i64
  %l89 = alloca i64
  %l90 = alloca ptr
  %l91 = alloca ptr
  %l92 = alloca i64
  %l93 = alloca i64
  %l94 = alloca i64
  %l95 = alloca ptr
  %l96 = alloca ptr
  %l97 = alloca i64
  %l98 = alloca i64
  %l99 = alloca i64
  %l100 = alloca i64
  %l101 = alloca i64
  %l102 = alloca i1
  %l103 = alloca i64
  %l104 = alloca i64
  %l105 = alloca i64
  %l106 = alloca i64
  %l107 = alloca i64
  %l108 = alloca i1
  %l109 = alloca i64
  %l110 = alloca i64
  %l111 = alloca i64
  %l112 = alloca i64
  %l113 = alloca i64
  %l114 = alloca i64
  %l115 = alloca i1
  %l116 = alloca i64
  %l117 = alloca i64
  %l118 = alloca i1
  %l119 = alloca i64
  %l120 = alloca i64
  %l121 = alloca i64
  %l122 = alloca i64
  %l123 = alloca i64
  %l124 = alloca i64
  %l125 = alloca i64
  %l126 = alloca i64
  %l127 = alloca i64
  %l128 = alloca i64
  %l129 = alloca i64
  %l130 = alloca i1
  %l131 = alloca i1
  %l132 = alloca i64
  %l133 = alloca i64
  %l134 = alloca i64
  %l135 = alloca i64
  %l136 = alloca i64
  %l137 = alloca ptr
  %l138 = alloca ptr
  %l139 = alloca i64
  %l140 = alloca i64
  %l141 = alloca i1
  %l142 = alloca { i64, ptr }
  %l143 = alloca ptr
  %l144 = alloca ptr
  %l145 = alloca i64
  %l146 = alloca i64
  %l147 = alloca ptr
  %l148 = alloca ptr
  %l149 = alloca i64
  %l150 = alloca i64
  %l151 = alloca i64
  %l152 = alloca i1
  %l153 = alloca i1
  %l154 = alloca i1
  %l155 = alloca { i64, ptr }
  %l156 = alloca { i64, ptr }
  %l157 = alloca i64
  %l158 = alloca i1
  %l159 = alloca i1
  %l160 = alloca ptr
  %l161 = alloca ptr
  %l162 = alloca i64
  %l163 = alloca i64
  %l164 = alloca i1
  %l165 = alloca ptr
  %l166 = alloca ptr
  %l167 = alloca i64
  %l168 = alloca i64
  %l169 = alloca i64
  %l170 = alloca i64
  %l171 = alloca i1
  %l172 = alloca i64
  %l173 = alloca i64
  %l174 = alloca i1
  %l175 = alloca i64
  %l176 = alloca i64
  %l177 = alloca i64
  %l178 = alloca i64
  %l179 = alloca i64
  %l180 = alloca i64
  %l181 = alloca i64
  %l182 = alloca i64
  %l183 = alloca i64
  %l184 = alloca i64
  %l185 = alloca i64
  %l186 = alloca i1
  %l187 = alloca i1
  %l188 = alloca i64
  %l189 = alloca i64
  %l190 = alloca i64
  %l191 = alloca i64
  %l192 = alloca i64
  %l193 = alloca ptr
  %l194 = alloca i64
  %l195 = alloca i64
  %l196 = alloca ptr
  %l197 = alloca { i64, ptr }
  %l198 = alloca ptr
  %l199 = alloca ptr
  %l200 = alloca i64
  %l201 = alloca i64
  %l202 = alloca i1
  %l203 = alloca { i64, ptr }
  %l204 = alloca i64
  %l205 = alloca i1
  %l206 = alloca ptr
  %l207 = alloca ptr
  %l208 = alloca i64
  %l209 = alloca i64
  %l210 = alloca i64
  %l211 = alloca { i64, ptr }
  %l212 = alloca i64
  %l213 = alloca i64
  %l214 = alloca i64
  %l215 = alloca i1
  %l216 = alloca i64
  %l217 = alloca i64
  %l218 = alloca i64
  %l219 = alloca i64
  %l220 = alloca i64
  %l221 = alloca i64
  %l222 = alloca i64
  %l223 = alloca i64
  %l224 = alloca i1
  %l225 = alloca i64
  %l226 = alloca i64
  %l227 = alloca i1
  %l228 = alloca i64
  %l229 = alloca i64
  %l230 = alloca i64
  %l231 = alloca i64
  %l232 = alloca i64
  %l233 = alloca i64
  %l234 = alloca i64
  %l235 = alloca i64
  %l236 = alloca i64
  %l237 = alloca i64
  %l238 = alloca i64
  %l239 = alloca i1
  %l240 = alloca i1
  %l241 = alloca i64
  %l242 = alloca i64
  %l243 = alloca i64
  %l244 = alloca i64
  %l245 = alloca i64
  %l246 = alloca ptr
  %l247 = alloca i64
  %l248 = alloca i64
  %l249 = alloca ptr
  %l250 = alloca ptr
  %l251 = alloca { i64, ptr }
  %l252 = alloca ptr
  %l253 = alloca ptr
  %l254 = alloca i64
  %l255 = alloca i64
  %l256 = alloca ptr
  %l257 = alloca ptr
  %l258 = alloca i64
  %l259 = alloca i64
  %l260 = alloca i64
  %l261 = alloca i1
  %l262 = alloca i1
  %l263 = alloca i1
  %l264 = alloca { i64, ptr }
  %l265 = alloca ptr
  %l266 = alloca i64
  %l267 = alloca i64
  %l268 = alloca i64
  %l269 = alloca ptr
  %l270 = alloca { i64, ptr }
  %l271 = alloca { i64, ptr }
  %l272 = alloca i64
  %l273 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l29, !tbaa !29
  %t2 = load ptr, ptr %l29, !tbaa !29
  %t3 = getelementptr %"compiler/fmt:formatter", ptr %t2, i32 0, i32 16
  store ptr %t3, ptr %l30, !tbaa !29
  %t4 = load ptr, ptr %l30, !tbaa !29
  %t5 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %s0, ptr %t4)
  store { i64, ptr } %t5, ptr %l31
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t6, ptr %l1, !tbaa !27
  %t7 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t7, ptr %l32
  br label %bb2
bb2:
  %t8 = load %"std/prelude/text:StringBuilder", ptr %l32
  store %"std/prelude/text:StringBuilder" %t8, ptr %l2
  %t9 = load ptr, ptr %l0, !tbaa !29
  store ptr %t9, ptr %l33, !tbaa !29
  %t10 = load ptr, ptr %l33, !tbaa !29
  %t11 = getelementptr %"compiler/fmt:formatter", ptr %t10, i32 0, i32 9
  store ptr %t11, ptr %l34, !tbaa !29
  %t12 = load ptr, ptr %l34, !tbaa !29
  %t13 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t12)
  store i64 %t13, ptr %l35
  br label %bb3
bb3:
  %t14 = load i64, ptr %l35, !tbaa !24
  store i64 %t14, ptr %l3, !tbaa !24
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s1
  %t15 = load i64, ptr %l3, !tbaa !24
  store i64 %t15, ptr %l36, !tbaa !24
  %t16 = load i64, ptr %l36, !tbaa !24
  %t17 = icmp sgt i64 %t16, 0
  store i1 %t17, ptr %l37, !tbaa !21
  %t18 = load i1, ptr %l37, !tbaa !21
  br i1 %t18, label %bb5, label %bb6
bb5:
  %t19 = load ptr, ptr %l0, !tbaa !29
  store ptr %t19, ptr %l39, !tbaa !29
  %t20 = load ptr, ptr %l39, !tbaa !29
  %t21 = getelementptr %"compiler/fmt:formatter", ptr %t20, i32 0, i32 9
  store ptr %t21, ptr %l40, !tbaa !29
  %t22 = load i64, ptr %l3, !tbaa !24
  store i64 %t22, ptr %l41, !tbaa !24
  %t23 = load i64, ptr %l41, !tbaa !24
  %t24 = sub i64 %t23, 1
  store i64 %t24, ptr %l42, !tbaa !24
  %t25 = load ptr, ptr %l40, !tbaa !29
  %t26 = load i64, ptr %l42, !tbaa !24
  %t27 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t25, i64 %t26)
  store i64 %t27, ptr %l43
  br label %bb7
bb6:
  store i1 false, ptr %l38, !tbaa !21
  br label %bb8
bb7:
  %t28 = load i64, ptr %l43, !tbaa !24
  %t29 = icmp eq i64 %t28, 1
  store i1 %t29, ptr %l44, !tbaa !21
  %t30 = load i1, ptr %l44, !tbaa !21
  store i1 %t30, ptr %l38, !tbaa !21
  br label %bb8
bb8:
  %t31 = load i1, ptr %l38, !tbaa !21
  %t32 = xor i1 %t31, true
  store i1 %t32, ptr %l45, !tbaa !21
  %t33 = load i1, ptr %l45, !tbaa !21
  br i1 %t33, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s1)
  br label %bb13
bb10:
  br label %bb11
bb11:
  %t34 = load i64, ptr %l3, !tbaa !24
  store i64 %t34, ptr %l46, !tbaa !24
  %t35 = load i64, ptr %l46, !tbaa !24
  %t36 = sub i64 %t35, 1
  store i64 %t36, ptr %l47, !tbaa !24
  %t37 = load i64, ptr %l47, !tbaa !24
  store i64 %t37, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  br label %bb12
bb12:
  br label %bb4
bb13:
  store i64 0, ptr %l4, !tbaa !24
  br label %bb14
bb14:
  store %olang.scope zeroinitializer, ptr %s2
  %t38 = load i64, ptr %l4, !tbaa !24
  store i64 %t38, ptr %l48, !tbaa !24
  %t39 = load i64, ptr %l3, !tbaa !24
  store i64 %t39, ptr %l49, !tbaa !24
  %t40 = load i64, ptr %l48, !tbaa !24
  %t41 = load i64, ptr %l49, !tbaa !24
  %t42 = icmp slt i64 %t40, %t41
  store i1 %t42, ptr %l50, !tbaa !21
  %t43 = load i1, ptr %l50, !tbaa !21
  %t44 = xor i1 %t43, true
  store i1 %t44, ptr %l51, !tbaa !21
  %t45 = load i1, ptr %l51, !tbaa !21
  br i1 %t45, label %bb15, label %bb16
bb15:
  call void @__olang_scope_close(ptr %s2)
  br label %bb131
bb16:
  br label %bb17
bb17:
  %t46 = load i64, ptr %l4, !tbaa !24
  store i64 %t46, ptr %l52, !tbaa !24
  %t47 = load i64, ptr %l52, !tbaa !24
  store i64 %t47, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb18
bb18:
  store %olang.scope zeroinitializer, ptr %s3
  %t48 = load i64, ptr %l5, !tbaa !24
  store i64 %t48, ptr %l53, !tbaa !24
  %t49 = load i64, ptr %l3, !tbaa !24
  store i64 %t49, ptr %l54, !tbaa !24
  %t50 = load i64, ptr %l53, !tbaa !24
  %t51 = load i64, ptr %l54, !tbaa !24
  %t52 = icmp slt i64 %t50, %t51
  store i1 %t52, ptr %l55, !tbaa !21
  %t53 = load i1, ptr %l55, !tbaa !21
  br i1 %t53, label %bb19, label %bb20
bb19:
  %t54 = load ptr, ptr %l0, !tbaa !29
  store ptr %t54, ptr %l57, !tbaa !29
  %t55 = load ptr, ptr %l57, !tbaa !29
  %t56 = getelementptr %"compiler/fmt:formatter", ptr %t55, i32 0, i32 9
  store ptr %t56, ptr %l58, !tbaa !29
  %t57 = load i64, ptr %l5, !tbaa !24
  store i64 %t57, ptr %l59, !tbaa !24
  %t58 = load ptr, ptr %l58, !tbaa !29
  %t59 = load i64, ptr %l59, !tbaa !24
  %t60 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t58, i64 %t59)
  store i64 %t60, ptr %l60
  br label %bb21
bb20:
  store i1 false, ptr %l56, !tbaa !21
  br label %bb22
bb21:
  %t61 = load i64, ptr %l60, !tbaa !24
  %t62 = icmp eq i64 %t61, 0
  store i1 %t62, ptr %l61, !tbaa !21
  %t63 = load i1, ptr %l61, !tbaa !21
  store i1 %t63, ptr %l56, !tbaa !21
  br label %bb22
bb22:
  %t64 = load i1, ptr %l56, !tbaa !21
  br i1 %t64, label %bb23, label %bb24
bb23:
  %t65 = load ptr, ptr %l0, !tbaa !29
  store ptr %t65, ptr %l63, !tbaa !29
  %t66 = load ptr, ptr %l63, !tbaa !29
  %t67 = getelementptr %"compiler/fmt:formatter", ptr %t66, i32 0, i32 13
  store ptr %t67, ptr %l64, !tbaa !29
  %t68 = load i64, ptr %l5, !tbaa !24
  store i64 %t68, ptr %l65, !tbaa !24
  %t69 = load ptr, ptr %l64, !tbaa !29
  %t70 = load i64, ptr %l65, !tbaa !24
  %t71 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t69, i64 %t70)
  store i64 %t71, ptr %l66
  br label %bb25
bb24:
  store i1 false, ptr %l62, !tbaa !21
  br label %bb26
bb25:
  %t72 = load i64, ptr %l66, !tbaa !24
  %t73 = icmp sge i64 %t72, 0
  store i1 %t73, ptr %l67, !tbaa !21
  %t74 = load i1, ptr %l67, !tbaa !21
  store i1 %t74, ptr %l62, !tbaa !21
  br label %bb26
bb26:
  %t75 = load i1, ptr %l62, !tbaa !21
  br i1 %t75, label %bb27, label %bb28
bb27:
  %t76 = load ptr, ptr %l0, !tbaa !29
  store ptr %t76, ptr %l69, !tbaa !29
  %t77 = load ptr, ptr %l69, !tbaa !29
  %t78 = getelementptr %"compiler/fmt:formatter", ptr %t77, i32 0, i32 12
  store ptr %t78, ptr %l70, !tbaa !29
  %t79 = load i64, ptr %l5, !tbaa !24
  store i64 %t79, ptr %l71, !tbaa !24
  %t80 = load ptr, ptr %l70, !tbaa !29
  %t81 = load i64, ptr %l71, !tbaa !24
  %t82 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t80, i64 %t81)
  store i64 %t82, ptr %l72
  br label %bb29
bb28:
  store i1 false, ptr %l68, !tbaa !21
  br label %bb31
bb29:
  %t83 = load ptr, ptr %l0, !tbaa !29
  store ptr %t83, ptr %l73, !tbaa !29
  %t84 = load ptr, ptr %l73, !tbaa !29
  %t85 = getelementptr %"compiler/fmt:formatter", ptr %t84, i32 0, i32 11
  store ptr %t85, ptr %l74, !tbaa !29
  %t86 = load i64, ptr %l5, !tbaa !24
  store i64 %t86, ptr %l75, !tbaa !24
  %t87 = load ptr, ptr %l74, !tbaa !29
  %t88 = load i64, ptr %l75, !tbaa !24
  %t89 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t87, i64 %t88)
  store i64 %t89, ptr %l76
  br label %bb30
bb30:
  %t90 = load i64, ptr %l72, !tbaa !24
  %t91 = load i64, ptr %l76, !tbaa !24
  %t92 = icmp sgt i64 %t90, %t91
  store i1 %t92, ptr %l77, !tbaa !21
  %t93 = load i1, ptr %l77, !tbaa !21
  store i1 %t93, ptr %l68, !tbaa !21
  br label %bb31
bb31:
  %t94 = load i1, ptr %l68, !tbaa !21
  br i1 %t94, label %bb32, label %bb33
bb32:
  %t95 = load ptr, ptr %l0, !tbaa !29
  store ptr %t95, ptr %l79, !tbaa !29
  %t96 = load ptr, ptr %l79, !tbaa !29
  %t97 = getelementptr %"compiler/fmt:formatter", ptr %t96, i32 0, i32 15
  store ptr %t97, ptr %l80, !tbaa !29
  %t98 = load i64, ptr %l5, !tbaa !24
  store i64 %t98, ptr %l81, !tbaa !24
  %t99 = load ptr, ptr %l80, !tbaa !29
  %t100 = load i64, ptr %l81, !tbaa !24
  %t101 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t99, i64 %t100)
  store i1 %t101, ptr %l82
  br label %bb34
bb33:
  store i1 false, ptr %l78, !tbaa !21
  br label %bb35
bb34:
  %t102 = load i1, ptr %l82, !tbaa !21
  %t103 = xor i1 %t102, true
  store i1 %t103, ptr %l83, !tbaa !21
  %t104 = load i1, ptr %l83, !tbaa !21
  store i1 %t104, ptr %l78, !tbaa !21
  br label %bb35
bb35:
  %t105 = load i1, ptr %l78, !tbaa !21
  %t106 = xor i1 %t105, true
  store i1 %t106, ptr %l84, !tbaa !21
  %t107 = load i1, ptr %l84, !tbaa !21
  br i1 %t107, label %bb36, label %bb37
bb36:
  call void @__olang_scope_close(ptr %s3)
  br label %bb46
bb37:
  br label %bb38
bb38:
  %t108 = load ptr, ptr %l0, !tbaa !29
  store ptr %t108, ptr %l85, !tbaa !29
  %t109 = load ptr, ptr %l85, !tbaa !29
  %t110 = getelementptr %"compiler/fmt:formatter", ptr %t109, i32 0, i32 10
  store ptr %t110, ptr %l86, !tbaa !29
  %t111 = load i64, ptr %l5, !tbaa !24
  store i64 %t111, ptr %l87, !tbaa !24
  %t112 = load ptr, ptr %l86, !tbaa !29
  %t113 = load i64, ptr %l87, !tbaa !24
  %t114 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t112, i64 %t113)
  store i64 %t114, ptr %l88
  br label %bb39
bb39:
  %t115 = load i64, ptr %l88, !tbaa !24
  %t116 = mul i64 %t115, 4
  store i64 %t116, ptr %l89, !tbaa !24
  %t117 = load ptr, ptr %l0, !tbaa !29
  store ptr %t117, ptr %l90, !tbaa !29
  %t118 = load ptr, ptr %l90, !tbaa !29
  %t119 = getelementptr %"compiler/fmt:formatter", ptr %t118, i32 0, i32 12
  store ptr %t119, ptr %l91, !tbaa !29
  %t120 = load i64, ptr %l5, !tbaa !24
  store i64 %t120, ptr %l92, !tbaa !24
  %t121 = load ptr, ptr %l91, !tbaa !29
  %t122 = load i64, ptr %l92, !tbaa !24
  %t123 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t121, i64 %t122)
  store i64 %t123, ptr %l93
  br label %bb40
bb40:
  %t124 = load i64, ptr %l89, !tbaa !24
  %t125 = load i64, ptr %l93, !tbaa !24
  %t126 = add i64 %t124, %t125
  store i64 %t126, ptr %l94, !tbaa !24
  %t127 = load ptr, ptr %l0, !tbaa !29
  store ptr %t127, ptr %l95, !tbaa !29
  %t128 = load ptr, ptr %l95, !tbaa !29
  %t129 = getelementptr %"compiler/fmt:formatter", ptr %t128, i32 0, i32 11
  store ptr %t129, ptr %l96, !tbaa !29
  %t130 = load i64, ptr %l5, !tbaa !24
  store i64 %t130, ptr %l97, !tbaa !24
  %t131 = load ptr, ptr %l96, !tbaa !29
  %t132 = load i64, ptr %l97, !tbaa !24
  %t133 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t131, i64 %t132)
  store i64 %t133, ptr %l98
  br label %bb41
bb41:
  %t134 = load i64, ptr %l94, !tbaa !24
  %t135 = load i64, ptr %l98, !tbaa !24
  %t136 = sub i64 %t134, %t135
  store i64 %t136, ptr %l99, !tbaa !24
  %t137 = load i64, ptr %l99, !tbaa !24
  store i64 %t137, ptr %l7, !tbaa !24
  %t138 = load i64, ptr %l7, !tbaa !24
  store i64 %t138, ptr %l100, !tbaa !24
  %t139 = load i64, ptr %l6, !tbaa !24
  store i64 %t139, ptr %l101, !tbaa !24
  %t140 = load i64, ptr %l100, !tbaa !24
  %t141 = load i64, ptr %l101, !tbaa !24
  %t142 = icmp sgt i64 %t140, %t141
  store i1 %t142, ptr %l102, !tbaa !21
  %t143 = load i1, ptr %l102, !tbaa !21
  br i1 %t143, label %bb42, label %bb43
bb42:
  store %olang.scope zeroinitializer, ptr %s4
  %t144 = load i64, ptr %l7, !tbaa !24
  store i64 %t144, ptr %l103, !tbaa !24
  %t145 = load i64, ptr %l103, !tbaa !24
  store i64 %t145, ptr %l6, !tbaa !24
  call void @__olang_scope_close(ptr %s4)
  br label %bb44
bb43:
  br label %bb44
bb44:
  %t146 = load i64, ptr %l5, !tbaa !24
  store i64 %t146, ptr %l104, !tbaa !24
  %t147 = load i64, ptr %l104, !tbaa !24
  %t148 = add i64 %t147, 1
  store i64 %t148, ptr %l105, !tbaa !24
  %t149 = load i64, ptr %l105, !tbaa !24
  store i64 %t149, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb45
bb45:
  br label %bb18
bb46:
  %t150 = load i64, ptr %l5, !tbaa !24
  store i64 %t150, ptr %l106, !tbaa !24
  %t151 = load i64, ptr %l4, !tbaa !24
  store i64 %t151, ptr %l107, !tbaa !24
  %t152 = load i64, ptr %l106, !tbaa !24
  %t153 = load i64, ptr %l107, !tbaa !24
  %t154 = icmp eq i64 %t152, %t153
  store i1 %t154, ptr %l108, !tbaa !21
  %t155 = load i1, ptr %l108, !tbaa !21
  br i1 %t155, label %bb47, label %bb48
bb47:
  store %olang.scope zeroinitializer, ptr %s5
  %t156 = load i64, ptr %l4, !tbaa !24
  store i64 %t156, ptr %l109, !tbaa !24
  %t157 = load i64, ptr %l109, !tbaa !24
  %t158 = add i64 %t157, 1
  store i64 %t158, ptr %l110, !tbaa !24
  %t159 = load i64, ptr %l110, !tbaa !24
  store i64 %t159, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s5)
  br label %bb49
bb48:
  br label %bb49
bb49:
  store %olang.scope zeroinitializer, ptr %s6
  %t160 = load i64, ptr %l4, !tbaa !24
  store i64 %t160, ptr %l111, !tbaa !24
  %t161 = load i64, ptr %l111, !tbaa !24
  store i64 %t161, ptr %l8, !tbaa !24
  %t162 = load i64, ptr %l5, !tbaa !24
  store i64 %t162, ptr %l112, !tbaa !24
  %t163 = load i64, ptr %l112, !tbaa !24
  store i64 %t163, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t164 = load i64, ptr %l9, !tbaa !24
  store i64 %t164, ptr %l113, !tbaa !24
  %t165 = load i64, ptr %l8, !tbaa !24
  store i64 %t165, ptr %l114, !tbaa !24
  %t166 = load i64, ptr %l113, !tbaa !24
  %t167 = load i64, ptr %l114, !tbaa !24
  %t168 = icmp sgt i64 %t166, %t167
  store i1 %t168, ptr %l115, !tbaa !21
  %t169 = load i1, ptr %l115, !tbaa !21
  br i1 %t169, label %bb50, label %bb51
bb50:
  %t170 = load i64, ptr %l10, !tbaa !24
  store i64 %t170, ptr %l117, !tbaa !24
  %t171 = load i64, ptr %l117, !tbaa !24
  %t172 = icmp sgt i64 %t171, 0
  store i1 %t172, ptr %l118, !tbaa !21
  %t173 = load i1, ptr %l118, !tbaa !21
  br i1 %t173, label %bb52, label %bb53
bb51:
  store i64 0, ptr %l116, !tbaa !24
  br label %bb55
bb52:
  %t174 = load i64, ptr %l9, !tbaa !24
  store i64 %t174, ptr %l120, !tbaa !24
  %t175 = load i64, ptr %l8, !tbaa !24
  store i64 %t175, ptr %l121, !tbaa !24
  %t176 = load i64, ptr %l120, !tbaa !24
  %t177 = load i64, ptr %l121, !tbaa !24
  %t178 = sub i64 %t176, %t177
  store i64 %t178, ptr %l122, !tbaa !24
  %t179 = load i64, ptr %l10, !tbaa !24
  store i64 %t179, ptr %l123, !tbaa !24
  %t180 = load i64, ptr %l122, !tbaa !24
  %t181 = load i64, ptr %l123, !tbaa !24
  %t182 = add i64 %t180, %t181
  store i64 %t182, ptr %l124, !tbaa !24
  %t183 = load i64, ptr %l124, !tbaa !24
  %t184 = sub i64 %t183, 1
  store i64 %t184, ptr %l125, !tbaa !24
  %t185 = load i64, ptr %l10, !tbaa !24
  store i64 %t185, ptr %l126, !tbaa !24
  %t186 = load i64, ptr %l125, !tbaa !24
  %t187 = load i64, ptr %l126, !tbaa !24
  %t188 = sdiv i64 %t186, %t187
  store i64 %t188, ptr %l127, !tbaa !24
  %t189 = load i64, ptr %l127, !tbaa !24
  store i64 %t189, ptr %l119, !tbaa !24
  br label %bb54
bb53:
  store i64 0, ptr %l119, !tbaa !24
  br label %bb54
bb54:
  %t190 = load i64, ptr %l119, !tbaa !24
  store i64 %t190, ptr %l116, !tbaa !24
  br label %bb55
bb55:
  %t191 = load i64, ptr %l116, !tbaa !24
  store i64 %t191, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb56
bb56:
  store %olang.scope zeroinitializer, ptr %s7
  %t192 = load i64, ptr %l12, !tbaa !24
  store i64 %t192, ptr %l128, !tbaa !24
  %t193 = load i64, ptr %l11, !tbaa !24
  store i64 %t193, ptr %l129, !tbaa !24
  %t194 = load i64, ptr %l128, !tbaa !24
  %t195 = load i64, ptr %l129, !tbaa !24
  %t196 = icmp slt i64 %t194, %t195
  store i1 %t196, ptr %l130, !tbaa !21
  %t197 = load i1, ptr %l130, !tbaa !21
  %t198 = xor i1 %t197, true
  store i1 %t198, ptr %l131, !tbaa !21
  %t199 = load i1, ptr %l131, !tbaa !21
  br i1 %t199, label %bb57, label %bb58
bb57:
  call void @__olang_scope_close(ptr %s7)
  br label %bb129
bb58:
  br label %bb59
bb59:
  %t200 = load i64, ptr %l8, !tbaa !24
  store i64 %t200, ptr %l132, !tbaa !24
  %t201 = load i64, ptr %l12, !tbaa !24
  store i64 %t201, ptr %l133, !tbaa !24
  %t202 = load i64, ptr %l10, !tbaa !24
  store i64 %t202, ptr %l134, !tbaa !24
  %t203 = load i64, ptr %l133, !tbaa !24
  %t204 = load i64, ptr %l134, !tbaa !24
  %t205 = mul i64 %t203, %t204
  store i64 %t205, ptr %l135, !tbaa !24
  %t206 = load i64, ptr %l132, !tbaa !24
  %t207 = load i64, ptr %l135, !tbaa !24
  %t208 = add i64 %t206, %t207
  store i64 %t208, ptr %l136, !tbaa !24
  %t209 = load i64, ptr %l136, !tbaa !24
  store i64 %t209, ptr %l13, !tbaa !24
  %t210 = load ptr, ptr %l0, !tbaa !29
  store ptr %t210, ptr %l137, !tbaa !29
  %t211 = load ptr, ptr %l137, !tbaa !29
  %t212 = getelementptr %"compiler/fmt:formatter", ptr %t211, i32 0, i32 9
  store ptr %t212, ptr %l138, !tbaa !29
  %t213 = load i64, ptr %l13, !tbaa !24
  store i64 %t213, ptr %l139, !tbaa !24
  %t214 = load ptr, ptr %l138, !tbaa !29
  %t215 = load i64, ptr %l139, !tbaa !24
  %t216 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t214, i64 %t215)
  store i64 %t216, ptr %l140
  br label %bb60
bb60:
  %t217 = load i64, ptr %l140, !tbaa !24
  %t218 = icmp eq i64 %t217, 0
  store i1 %t218, ptr %l141, !tbaa !21
  %t219 = load i1, ptr %l141, !tbaa !21
  br i1 %t219, label %bb61, label %bb62
bb61:
  store %olang.scope zeroinitializer, ptr %s8
  %t220 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t220, ptr %l142, !tbaa !27
  %t221 = load ptr, ptr %l0, !tbaa !29
  store ptr %t221, ptr %l143, !tbaa !29
  %t222 = load ptr, ptr %l143, !tbaa !29
  %t223 = getelementptr %"compiler/fmt:formatter", ptr %t222, i32 0, i32 11
  store ptr %t223, ptr %l144, !tbaa !29
  %t224 = load i64, ptr %l13, !tbaa !24
  store i64 %t224, ptr %l145, !tbaa !24
  %t225 = load ptr, ptr %l144, !tbaa !29
  %t226 = load i64, ptr %l145, !tbaa !24
  %t227 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t225, i64 %t226)
  store i64 %t227, ptr %l146
  br label %bb63
bb62:
  br label %bb126
bb63:
  %t228 = load ptr, ptr %l0, !tbaa !29
  store ptr %t228, ptr %l147, !tbaa !29
  %t229 = load ptr, ptr %l147, !tbaa !29
  %t230 = getelementptr %"compiler/fmt:formatter", ptr %t229, i32 0, i32 12
  store ptr %t230, ptr %l148, !tbaa !29
  %t231 = load i64, ptr %l13, !tbaa !24
  store i64 %t231, ptr %l149, !tbaa !24
  %t232 = load ptr, ptr %l148, !tbaa !29
  %t233 = load i64, ptr %l149, !tbaa !24
  %t234 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t232, i64 %t233)
  store i64 %t234, ptr %l150
  br label %bb64
bb64:
  %t235 = load { i64, ptr }, ptr %l142, !tbaa !27
  %t236 = extractvalue { i64, ptr } %t235, 0
  store i64 %t236, ptr %l151, !tbaa !24
  %t237 = load i64, ptr %l146, !tbaa !24
  %t238 = icmp sge i64 %t237, 0
  store i1 %t238, ptr %l152, !tbaa !21
  %t239 = load i1, ptr %l152, !tbaa !21
  br i1 %t239, label %bb65, label %bb66
bb65:
  %t240 = load i64, ptr %l146, !tbaa !24
  %t241 = load i64, ptr %l150, !tbaa !24
  %t242 = icmp sle i64 %t240, %t241
  store i1 %t242, ptr %l153, !tbaa !21
  %t243 = load i1, ptr %l153, !tbaa !21
  br i1 %t243, label %bb67, label %bb68
bb66:
  call void @__olang_check_failed(ptr @.c44)
  unreachable
bb67:
  %t244 = load i64, ptr %l150, !tbaa !24
  %t245 = load i64, ptr %l151, !tbaa !24
  %t246 = icmp sle i64 %t244, %t245
  store i1 %t246, ptr %l154, !tbaa !21
  %t247 = load i1, ptr %l154, !tbaa !21
  br i1 %t247, label %bb69, label %bb70
bb68:
  call void @__olang_check_failed(ptr @.c44)
  unreachable
bb69:
  %t248 = getelementptr { i64, ptr }, ptr %l142, i32 0, i32 1
  %t249 = load ptr, ptr %t248, !tbaa !27
  %t250 = load i64, ptr %l146, !tbaa !24
  %t251 = load i64, ptr %l150, !tbaa !24
  %t252 = getelementptr i8, ptr %t249, i64 %t250
  %t253 = sub i64 %t251, %t250
  %t254 = insertvalue { i64, ptr } undef, i64 %t253, 0
  %t255 = insertvalue { i64, ptr } %t254, ptr %t252, 1
  store { i64, ptr } %t255, ptr %l155, !tbaa !27
  %t256 = load { i64, ptr }, ptr %l155, !tbaa !27
  store { i64, ptr } %t256, ptr %l14, !tbaa !27
  %t257 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t257, ptr %l156, !tbaa !27
  %t258 = load { i64, ptr }, ptr %l156, !tbaa !27
  %t259 = extractvalue { i64, ptr } %t258, 0
  store i64 %t259, ptr %l157, !tbaa !24
  %t260 = load i64, ptr %l157, !tbaa !24
  %t261 = icmp sgt i64 %t260, 0
  store i1 %t261, ptr %l158, !tbaa !21
  %t262 = load i1, ptr %l158, !tbaa !21
  br i1 %t262, label %bb71, label %bb72
bb70:
  call void @__olang_check_failed(ptr @.c44)
  unreachable
bb71:
  store i1 true, ptr %l159, !tbaa !21
  br label %bb74
bb72:
  %t263 = load ptr, ptr %l0, !tbaa !29
  store ptr %t263, ptr %l160, !tbaa !29
  %t264 = load ptr, ptr %l160, !tbaa !29
  %t265 = getelementptr %"compiler/fmt:formatter", ptr %t264, i32 0, i32 13
  store ptr %t265, ptr %l161, !tbaa !29
  %t266 = load i64, ptr %l13, !tbaa !24
  store i64 %t266, ptr %l162, !tbaa !24
  %t267 = load ptr, ptr %l161, !tbaa !29
  %t268 = load i64, ptr %l162, !tbaa !24
  %t269 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t267, i64 %t268)
  store i64 %t269, ptr %l163
  br label %bb73
bb73:
  %t270 = load i64, ptr %l163, !tbaa !24
  %t271 = icmp sge i64 %t270, 0
  store i1 %t271, ptr %l164, !tbaa !21
  %t272 = load i1, ptr %l164, !tbaa !21
  store i1 %t272, ptr %l159, !tbaa !21
  br label %bb74
bb74:
  %t273 = load i1, ptr %l159, !tbaa !21
  br i1 %t273, label %bb75, label %bb76
bb75:
  store %olang.scope zeroinitializer, ptr %s9
  store %olang.scope zeroinitializer, ptr %s10
  store i64 0, ptr %l15, !tbaa !24
  %t274 = load ptr, ptr %l0, !tbaa !29
  store ptr %t274, ptr %l165, !tbaa !29
  %t275 = load ptr, ptr %l165, !tbaa !29
  %t276 = getelementptr %"compiler/fmt:formatter", ptr %t275, i32 0, i32 10
  store ptr %t276, ptr %l166, !tbaa !29
  %t277 = load i64, ptr %l13, !tbaa !24
  store i64 %t277, ptr %l167, !tbaa !24
  %t278 = load ptr, ptr %l166, !tbaa !29
  %t279 = load i64, ptr %l167, !tbaa !24
  %t280 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t278, i64 %t279)
  store i64 %t280, ptr %l168
  br label %bb77
bb76:
  br label %bb91
bb77:
  %t281 = load i64, ptr %l168, !tbaa !24
  store i64 %t281, ptr %l16, !tbaa !24
  store i64 1, ptr %l17, !tbaa !24
  %t282 = load i64, ptr %l16, !tbaa !24
  store i64 %t282, ptr %l169, !tbaa !24
  %t283 = load i64, ptr %l15, !tbaa !24
  store i64 %t283, ptr %l170, !tbaa !24
  %t284 = load i64, ptr %l169, !tbaa !24
  %t285 = load i64, ptr %l170, !tbaa !24
  %t286 = icmp sgt i64 %t284, %t285
  store i1 %t286, ptr %l171, !tbaa !21
  %t287 = load i1, ptr %l171, !tbaa !21
  br i1 %t287, label %bb78, label %bb79
bb78:
  %t288 = load i64, ptr %l17, !tbaa !24
  store i64 %t288, ptr %l173, !tbaa !24
  %t289 = load i64, ptr %l173, !tbaa !24
  %t290 = icmp sgt i64 %t289, 0
  store i1 %t290, ptr %l174, !tbaa !21
  %t291 = load i1, ptr %l174, !tbaa !21
  br i1 %t291, label %bb80, label %bb81
bb79:
  store i64 0, ptr %l172, !tbaa !24
  br label %bb83
bb80:
  %t292 = load i64, ptr %l16, !tbaa !24
  store i64 %t292, ptr %l176, !tbaa !24
  %t293 = load i64, ptr %l15, !tbaa !24
  store i64 %t293, ptr %l177, !tbaa !24
  %t294 = load i64, ptr %l176, !tbaa !24
  %t295 = load i64, ptr %l177, !tbaa !24
  %t296 = sub i64 %t294, %t295
  store i64 %t296, ptr %l178, !tbaa !24
  %t297 = load i64, ptr %l17, !tbaa !24
  store i64 %t297, ptr %l179, !tbaa !24
  %t298 = load i64, ptr %l178, !tbaa !24
  %t299 = load i64, ptr %l179, !tbaa !24
  %t300 = add i64 %t298, %t299
  store i64 %t300, ptr %l180, !tbaa !24
  %t301 = load i64, ptr %l180, !tbaa !24
  %t302 = sub i64 %t301, 1
  store i64 %t302, ptr %l181, !tbaa !24
  %t303 = load i64, ptr %l17, !tbaa !24
  store i64 %t303, ptr %l182, !tbaa !24
  %t304 = load i64, ptr %l181, !tbaa !24
  %t305 = load i64, ptr %l182, !tbaa !24
  %t306 = sdiv i64 %t304, %t305
  store i64 %t306, ptr %l183, !tbaa !24
  %t307 = load i64, ptr %l183, !tbaa !24
  store i64 %t307, ptr %l175, !tbaa !24
  br label %bb82
bb81:
  store i64 0, ptr %l175, !tbaa !24
  br label %bb82
bb82:
  %t308 = load i64, ptr %l175, !tbaa !24
  store i64 %t308, ptr %l172, !tbaa !24
  br label %bb83
bb83:
  %t309 = load i64, ptr %l172, !tbaa !24
  store i64 %t309, ptr %l18, !tbaa !24
  store i64 0, ptr %l19, !tbaa !24
  br label %bb84
bb84:
  store %olang.scope zeroinitializer, ptr %s11
  %t310 = load i64, ptr %l19, !tbaa !24
  store i64 %t310, ptr %l184, !tbaa !24
  %t311 = load i64, ptr %l18, !tbaa !24
  store i64 %t311, ptr %l185, !tbaa !24
  %t312 = load i64, ptr %l184, !tbaa !24
  %t313 = load i64, ptr %l185, !tbaa !24
  %t314 = icmp slt i64 %t312, %t313
  store i1 %t314, ptr %l186, !tbaa !21
  %t315 = load i1, ptr %l186, !tbaa !21
  %t316 = xor i1 %t315, true
  store i1 %t316, ptr %l187, !tbaa !21
  %t317 = load i1, ptr %l187, !tbaa !21
  br i1 %t317, label %bb85, label %bb86
bb85:
  call void @__olang_scope_close(ptr %s11)
  br label %bb90
bb86:
  br label %bb87
bb87:
  %t318 = load i64, ptr %l15, !tbaa !24
  store i64 %t318, ptr %l188, !tbaa !24
  %t319 = load i64, ptr %l19, !tbaa !24
  store i64 %t319, ptr %l189, !tbaa !24
  %t320 = load i64, ptr %l17, !tbaa !24
  store i64 %t320, ptr %l190, !tbaa !24
  %t321 = load i64, ptr %l189, !tbaa !24
  %t322 = load i64, ptr %l190, !tbaa !24
  %t323 = mul i64 %t321, %t322
  store i64 %t323, ptr %l191, !tbaa !24
  %t324 = load i64, ptr %l188, !tbaa !24
  %t325 = load i64, ptr %l191, !tbaa !24
  %t326 = add i64 %t324, %t325
  store i64 %t326, ptr %l192, !tbaa !24
  %t327 = load i64, ptr %l192, !tbaa !24
  store i64 %t327, ptr %l20, !tbaa !24
  store ptr %l2, ptr %l193, !tbaa !29
  %t328 = load ptr, ptr %l193, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s11, ptr %t328, { i64, ptr } { i64 4, ptr @.d45 })
  br label %bb88
bb88:
  call void @__olang_scope_close(ptr %s11)
  br label %bb89
bb89:
  store %olang.scope zeroinitializer, ptr %s12
  %t329 = load i64, ptr %l19, !tbaa !24
  store i64 %t329, ptr %l194, !tbaa !24
  %t330 = load i64, ptr %l194, !tbaa !24
  %t331 = add i64 %t330, 1
  store i64 %t331, ptr %l195, !tbaa !24
  %t332 = load i64, ptr %l195, !tbaa !24
  store i64 %t332, ptr %l19, !tbaa !24
  call void @__olang_scope_close(ptr %s12)
  br label %bb84
bb90:
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s9)
  br label %bb91
bb91:
  store ptr %l2, ptr %l196, !tbaa !29
  %t333 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t333, ptr %l197, !tbaa !27
  %t334 = load ptr, ptr %l196, !tbaa !29
  %t335 = load { i64, ptr }, ptr %l197, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t334, { i64, ptr } %t335)
  br label %bb92
bb92:
  %t336 = load ptr, ptr %l0, !tbaa !29
  store ptr %t336, ptr %l198, !tbaa !29
  %t337 = load ptr, ptr %l198, !tbaa !29
  %t338 = getelementptr %"compiler/fmt:formatter", ptr %t337, i32 0, i32 13
  store ptr %t338, ptr %l199, !tbaa !29
  %t339 = load i64, ptr %l13, !tbaa !24
  store i64 %t339, ptr %l200, !tbaa !24
  %t340 = load ptr, ptr %l199, !tbaa !29
  %t341 = load i64, ptr %l200, !tbaa !24
  %t342 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t340, i64 %t341)
  store i64 %t342, ptr %l201
  br label %bb93
bb93:
  %t343 = load i64, ptr %l201, !tbaa !24
  %t344 = icmp sge i64 %t343, 0
  store i1 %t344, ptr %l202, !tbaa !21
  %t345 = load i1, ptr %l202, !tbaa !21
  br i1 %t345, label %bb94, label %bb95
bb94:
  store %olang.scope zeroinitializer, ptr %s13
  %t346 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t346, ptr %l203, !tbaa !27
  %t347 = load { i64, ptr }, ptr %l203, !tbaa !27
  %t348 = extractvalue { i64, ptr } %t347, 0
  store i64 %t348, ptr %l204, !tbaa !24
  %t349 = load i64, ptr %l204, !tbaa !24
  %t350 = icmp sgt i64 %t349, 0
  store i1 %t350, ptr %l205, !tbaa !21
  %t351 = load i1, ptr %l205, !tbaa !21
  br i1 %t351, label %bb96, label %bb97
bb95:
  br label %bb125
bb96:
  store %olang.scope zeroinitializer, ptr %s14
  %t352 = load ptr, ptr %l0, !tbaa !29
  store ptr %t352, ptr %l206, !tbaa !29
  %t353 = load ptr, ptr %l206, !tbaa !29
  %t354 = getelementptr %"compiler/fmt:formatter", ptr %t353, i32 0, i32 10
  store ptr %t354, ptr %l207, !tbaa !29
  %t355 = load i64, ptr %l13, !tbaa !24
  store i64 %t355, ptr %l208, !tbaa !24
  %t356 = load ptr, ptr %l207, !tbaa !29
  %t357 = load i64, ptr %l208, !tbaa !24
  %t358 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t356, i64 %t357)
  store i64 %t358, ptr %l209
  br label %bb98
bb97:
  br label %bb115
bb98:
  %t359 = load i64, ptr %l209, !tbaa !24
  %t360 = mul i64 %t359, 4
  store i64 %t360, ptr %l210, !tbaa !24
  %t361 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t361, ptr %l211, !tbaa !27
  %t362 = load { i64, ptr }, ptr %l211, !tbaa !27
  %t363 = extractvalue { i64, ptr } %t362, 0
  store i64 %t363, ptr %l212, !tbaa !24
  %t364 = load i64, ptr %l210, !tbaa !24
  %t365 = load i64, ptr %l212, !tbaa !24
  %t366 = add i64 %t364, %t365
  store i64 %t366, ptr %l213, !tbaa !24
  %t367 = load i64, ptr %l213, !tbaa !24
  store i64 %t367, ptr %l21, !tbaa !24
  %t368 = load i64, ptr %l6, !tbaa !24
  store i64 %t368, ptr %l214, !tbaa !24
  %t369 = load i64, ptr %l214, !tbaa !24
  %t370 = icmp sgt i64 %t369, 0
  store i1 %t370, ptr %l215, !tbaa !21
  %t371 = load i1, ptr %l215, !tbaa !21
  br i1 %t371, label %bb99, label %bb100
bb99:
  %t372 = load i64, ptr %l6, !tbaa !24
  store i64 %t372, ptr %l217, !tbaa !24
  %t373 = load i64, ptr %l21, !tbaa !24
  store i64 %t373, ptr %l218, !tbaa !24
  %t374 = load i64, ptr %l217, !tbaa !24
  %t375 = load i64, ptr %l218, !tbaa !24
  %t376 = sub i64 %t374, %t375
  store i64 %t376, ptr %l219, !tbaa !24
  %t377 = load i64, ptr %l219, !tbaa !24
  %t378 = add i64 %t377, 1
  store i64 %t378, ptr %l220, !tbaa !24
  %t379 = load i64, ptr %l220, !tbaa !24
  store i64 %t379, ptr %l216, !tbaa !24
  br label %bb101
bb100:
  store i64 1, ptr %l216, !tbaa !24
  br label %bb101
bb101:
  %t380 = load i64, ptr %l216, !tbaa !24
  store i64 %t380, ptr %l22, !tbaa !24
  store %olang.scope zeroinitializer, ptr %s15
  store i64 0, ptr %l23, !tbaa !24
  %t381 = load i64, ptr %l22, !tbaa !24
  store i64 %t381, ptr %l221, !tbaa !24
  %t382 = load i64, ptr %l221, !tbaa !24
  store i64 %t382, ptr %l24, !tbaa !24
  store i64 1, ptr %l25, !tbaa !24
  %t383 = load i64, ptr %l24, !tbaa !24
  store i64 %t383, ptr %l222, !tbaa !24
  %t384 = load i64, ptr %l23, !tbaa !24
  store i64 %t384, ptr %l223, !tbaa !24
  %t385 = load i64, ptr %l222, !tbaa !24
  %t386 = load i64, ptr %l223, !tbaa !24
  %t387 = icmp sgt i64 %t385, %t386
  store i1 %t387, ptr %l224, !tbaa !21
  %t388 = load i1, ptr %l224, !tbaa !21
  br i1 %t388, label %bb102, label %bb103
bb102:
  %t389 = load i64, ptr %l25, !tbaa !24
  store i64 %t389, ptr %l226, !tbaa !24
  %t390 = load i64, ptr %l226, !tbaa !24
  %t391 = icmp sgt i64 %t390, 0
  store i1 %t391, ptr %l227, !tbaa !21
  %t392 = load i1, ptr %l227, !tbaa !21
  br i1 %t392, label %bb104, label %bb105
bb103:
  store i64 0, ptr %l225, !tbaa !24
  br label %bb107
bb104:
  %t393 = load i64, ptr %l24, !tbaa !24
  store i64 %t393, ptr %l229, !tbaa !24
  %t394 = load i64, ptr %l23, !tbaa !24
  store i64 %t394, ptr %l230, !tbaa !24
  %t395 = load i64, ptr %l229, !tbaa !24
  %t396 = load i64, ptr %l230, !tbaa !24
  %t397 = sub i64 %t395, %t396
  store i64 %t397, ptr %l231, !tbaa !24
  %t398 = load i64, ptr %l25, !tbaa !24
  store i64 %t398, ptr %l232, !tbaa !24
  %t399 = load i64, ptr %l231, !tbaa !24
  %t400 = load i64, ptr %l232, !tbaa !24
  %t401 = add i64 %t399, %t400
  store i64 %t401, ptr %l233, !tbaa !24
  %t402 = load i64, ptr %l233, !tbaa !24
  %t403 = sub i64 %t402, 1
  store i64 %t403, ptr %l234, !tbaa !24
  %t404 = load i64, ptr %l25, !tbaa !24
  store i64 %t404, ptr %l235, !tbaa !24
  %t405 = load i64, ptr %l234, !tbaa !24
  %t406 = load i64, ptr %l235, !tbaa !24
  %t407 = sdiv i64 %t405, %t406
  store i64 %t407, ptr %l236, !tbaa !24
  %t408 = load i64, ptr %l236, !tbaa !24
  store i64 %t408, ptr %l228, !tbaa !24
  br label %bb106
bb105:
  store i64 0, ptr %l228, !tbaa !24
  br label %bb106
bb106:
  %t409 = load i64, ptr %l228, !tbaa !24
  store i64 %t409, ptr %l225, !tbaa !24
  br label %bb107
bb107:
  %t410 = load i64, ptr %l225, !tbaa !24
  store i64 %t410, ptr %l26, !tbaa !24
  store i64 0, ptr %l27, !tbaa !24
  br label %bb108
bb108:
  store %olang.scope zeroinitializer, ptr %s16
  %t411 = load i64, ptr %l27, !tbaa !24
  store i64 %t411, ptr %l237, !tbaa !24
  %t412 = load i64, ptr %l26, !tbaa !24
  store i64 %t412, ptr %l238, !tbaa !24
  %t413 = load i64, ptr %l237, !tbaa !24
  %t414 = load i64, ptr %l238, !tbaa !24
  %t415 = icmp slt i64 %t413, %t414
  store i1 %t415, ptr %l239, !tbaa !21
  %t416 = load i1, ptr %l239, !tbaa !21
  %t417 = xor i1 %t416, true
  store i1 %t417, ptr %l240, !tbaa !21
  %t418 = load i1, ptr %l240, !tbaa !21
  br i1 %t418, label %bb109, label %bb110
bb109:
  call void @__olang_scope_close(ptr %s16)
  br label %bb114
bb110:
  br label %bb111
bb111:
  %t419 = load i64, ptr %l23, !tbaa !24
  store i64 %t419, ptr %l241, !tbaa !24
  %t420 = load i64, ptr %l27, !tbaa !24
  store i64 %t420, ptr %l242, !tbaa !24
  %t421 = load i64, ptr %l25, !tbaa !24
  store i64 %t421, ptr %l243, !tbaa !24
  %t422 = load i64, ptr %l242, !tbaa !24
  %t423 = load i64, ptr %l243, !tbaa !24
  %t424 = mul i64 %t422, %t423
  store i64 %t424, ptr %l244, !tbaa !24
  %t425 = load i64, ptr %l241, !tbaa !24
  %t426 = load i64, ptr %l244, !tbaa !24
  %t427 = add i64 %t425, %t426
  store i64 %t427, ptr %l245, !tbaa !24
  %t428 = load i64, ptr %l245, !tbaa !24
  store i64 %t428, ptr %l28, !tbaa !24
  store ptr %l2, ptr %l246, !tbaa !29
  %t429 = load ptr, ptr %l246, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %t429, i8 32)
  br label %bb112
bb112:
  call void @__olang_scope_close(ptr %s16)
  br label %bb113
bb113:
  store %olang.scope zeroinitializer, ptr %s17
  %t430 = load i64, ptr %l27, !tbaa !24
  store i64 %t430, ptr %l247, !tbaa !24
  %t431 = load i64, ptr %l247, !tbaa !24
  %t432 = add i64 %t431, 1
  store i64 %t432, ptr %l248, !tbaa !24
  %t433 = load i64, ptr %l248, !tbaa !24
  store i64 %t433, ptr %l27, !tbaa !24
  call void @__olang_scope_close(ptr %s17)
  br label %bb108
bb114:
  call void @__olang_scope_close(ptr %s15)
  call void @__olang_scope_close(ptr %s14)
  br label %bb115
bb115:
  store ptr %l2, ptr %l249, !tbaa !29
  %t434 = load ptr, ptr %l0, !tbaa !29
  store ptr %t434, ptr %l250, !tbaa !29
  %t435 = load ptr, ptr %l250, !tbaa !29
  %t436 = getelementptr %"compiler/fmt:formatter", ptr %t435, i32 0, i32 0
  %t437 = load { i64, ptr }, ptr %t436, !tbaa !27
  store { i64, ptr } %t437, ptr %l251, !tbaa !27
  %t438 = load ptr, ptr %l0, !tbaa !29
  store ptr %t438, ptr %l252, !tbaa !29
  %t439 = load ptr, ptr %l252, !tbaa !29
  %t440 = getelementptr %"compiler/fmt:formatter", ptr %t439, i32 0, i32 13
  store ptr %t440, ptr %l253, !tbaa !29
  %t441 = load i64, ptr %l13, !tbaa !24
  store i64 %t441, ptr %l254, !tbaa !24
  %t442 = load ptr, ptr %l253, !tbaa !29
  %t443 = load i64, ptr %l254, !tbaa !24
  %t444 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t442, i64 %t443)
  store i64 %t444, ptr %l255
  br label %bb116
bb116:
  %t445 = load ptr, ptr %l0, !tbaa !29
  store ptr %t445, ptr %l256, !tbaa !29
  %t446 = load ptr, ptr %l256, !tbaa !29
  %t447 = getelementptr %"compiler/fmt:formatter", ptr %t446, i32 0, i32 14
  store ptr %t447, ptr %l257, !tbaa !29
  %t448 = load i64, ptr %l13, !tbaa !24
  store i64 %t448, ptr %l258, !tbaa !24
  %t449 = load ptr, ptr %l257, !tbaa !29
  %t450 = load i64, ptr %l258, !tbaa !24
  %t451 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t449, i64 %t450)
  store i64 %t451, ptr %l259
  br label %bb117
bb117:
  %t452 = load { i64, ptr }, ptr %l251, !tbaa !27
  %t453 = extractvalue { i64, ptr } %t452, 0
  store i64 %t453, ptr %l260, !tbaa !24
  %t454 = load i64, ptr %l255, !tbaa !24
  %t455 = icmp sge i64 %t454, 0
  store i1 %t455, ptr %l261, !tbaa !21
  %t456 = load i1, ptr %l261, !tbaa !21
  br i1 %t456, label %bb118, label %bb119
bb118:
  %t457 = load i64, ptr %l255, !tbaa !24
  %t458 = load i64, ptr %l259, !tbaa !24
  %t459 = icmp sle i64 %t457, %t458
  store i1 %t459, ptr %l262, !tbaa !21
  %t460 = load i1, ptr %l262, !tbaa !21
  br i1 %t460, label %bb120, label %bb121
bb119:
  call void @__olang_check_failed(ptr @.c46)
  unreachable
bb120:
  %t461 = load i64, ptr %l259, !tbaa !24
  %t462 = load i64, ptr %l260, !tbaa !24
  %t463 = icmp sle i64 %t461, %t462
  store i1 %t463, ptr %l263, !tbaa !21
  %t464 = load i1, ptr %l263, !tbaa !21
  br i1 %t464, label %bb122, label %bb123
bb121:
  call void @__olang_check_failed(ptr @.c46)
  unreachable
bb122:
  %t465 = getelementptr { i64, ptr }, ptr %l251, i32 0, i32 1
  %t466 = load ptr, ptr %t465, !tbaa !27
  %t467 = load i64, ptr %l255, !tbaa !24
  %t468 = load i64, ptr %l259, !tbaa !24
  %t469 = getelementptr i8, ptr %t466, i64 %t467
  %t470 = sub i64 %t468, %t467
  %t471 = insertvalue { i64, ptr } undef, i64 %t470, 0
  %t472 = insertvalue { i64, ptr } %t471, ptr %t469, 1
  store { i64, ptr } %t472, ptr %l264, !tbaa !27
  %t473 = load ptr, ptr %l249, !tbaa !29
  %t474 = load { i64, ptr }, ptr %l264, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %t473, { i64, ptr } %t474)
  br label %bb124
bb123:
  call void @__olang_check_failed(ptr @.c46)
  unreachable
bb124:
  call void @__olang_scope_close(ptr %s13)
  br label %bb125
bb125:
  call void @__olang_scope_close(ptr %s8)
  br label %bb126
bb126:
  store ptr %l2, ptr %l265, !tbaa !29
  %t475 = load ptr, ptr %l265, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %t475, i8 10)
  br label %bb127
bb127:
  call void @__olang_scope_close(ptr %s7)
  br label %bb128
bb128:
  store %olang.scope zeroinitializer, ptr %s18
  %t476 = load i64, ptr %l12, !tbaa !24
  store i64 %t476, ptr %l266, !tbaa !24
  %t477 = load i64, ptr %l266, !tbaa !24
  %t478 = add i64 %t477, 1
  store i64 %t478, ptr %l267, !tbaa !24
  %t479 = load i64, ptr %l267, !tbaa !24
  store i64 %t479, ptr %l12, !tbaa !24
  call void @__olang_scope_close(ptr %s18)
  br label %bb56
bb129:
  call void @__olang_scope_close(ptr %s6)
  %t480 = load i64, ptr %l5, !tbaa !24
  store i64 %t480, ptr %l268, !tbaa !24
  %t481 = load i64, ptr %l268, !tbaa !24
  store i64 %t481, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb130
bb130:
  br label %bb14
bb131:
  store ptr %l2, ptr %l269, !tbaa !29
  %t482 = load ptr, ptr %l269, !tbaa !29
  %t483 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %t482)
  store { i64, ptr } %t483, ptr %l270
  br label %bb132
bb132:
  %t484 = load { i64, ptr }, ptr %l270, !tbaa !27
  store { i64, ptr } %t484, ptr %l271, !tbaa !27
  %t485 = load { i64, ptr }, ptr %l271, !tbaa !27
  %t486 = extractvalue { i64, ptr } %t485, 0
  store i64 %t486, ptr %l272, !tbaa !24
  %t487 = load i64, ptr %l272, !tbaa !24
  %t488 = mul i64 %t487, 1
  %t489 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t488)
  %t490 = insertvalue { i64, ptr } undef, i64 %t487, 0
  %t491 = insertvalue { i64, ptr } %t490, ptr %t489, 1
  store { i64, ptr } %t491, ptr %l273, !tbaa !27
  %t492 = getelementptr { i64, ptr }, ptr %l273, i32 0, i32 1
  %t493 = load ptr, ptr %t492, !tbaa !27
  %t494 = getelementptr { i64, ptr }, ptr %l271, i32 0, i32 1
  %t495 = load ptr, ptr %t494, !tbaa !27
  %t496 = load i64, ptr %l272, !tbaa !24
  %t497 = mul i64 %t496, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t493, ptr %t495, i64 %t497, i1 false)
  %t498 = load { i64, ptr }, ptr %l273, !tbaa !27
  store { i64, ptr } %t498, ptr %l271, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t499 = load { i64, ptr }, ptr %l271, !tbaa !27
  store { i64, ptr } %t499, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2ffmt_2ecompiler_2ffmt_3aloader_2eaddNames(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, ptr %a2, { i64, ptr } %a3, { i64, ptr } %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i1
  %l16 = alloca i1
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l21 = alloca i1
  %l22 = alloca i1
  %l23 = alloca ptr
  %l24 = alloca ptr
  %l25 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l27 = alloca i64
  %l28 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  store { i64, ptr } %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store %olang.scope zeroinitializer, ptr %s1
  %t1 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t1, ptr %l9, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t3 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eSplit(ptr %v4, ptr %s1, { i64, ptr } %t2, { i64, ptr } { i64 1, ptr @.d47 })
  store { i64, ptr } %t3, ptr %l10
  br label %bb1
bb1:
  %t4 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t4, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t5 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t5, ptr %l11, !tbaa !27
  %t6 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t6, 0
  store i64 %t7, ptr %l12, !tbaa !24
  %t8 = load i64, ptr %l12, !tbaa !24
  store i64 %t8, ptr %l7, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t9 = load i64, ptr %l6, !tbaa !24
  store i64 %t9, ptr %l13, !tbaa !24
  %t10 = load i64, ptr %l7, !tbaa !24
  store i64 %t10, ptr %l14, !tbaa !24
  %t11 = load i64, ptr %l13, !tbaa !24
  %t12 = load i64, ptr %l14, !tbaa !24
  %t13 = icmp slt i64 %t11, %t12
  store i1 %t13, ptr %l15, !tbaa !21
  %t14 = load i1, ptr %l15, !tbaa !21
  %t15 = xor i1 %t14, true
  store i1 %t15, ptr %l16, !tbaa !21
  %t16 = load i1, ptr %l16, !tbaa !21
  br i1 %t16, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb12
bb4:
  br label %bb5
bb5:
  %t17 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t17, ptr %l17, !tbaa !27
  %t18 = load i64, ptr %l6, !tbaa !24
  store i64 %t18, ptr %l18, !tbaa !24
  %t19 = load i64, ptr %l18, !tbaa !24
  %t20 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = getelementptr { i64, ptr }, ptr %t21, i64 %t19
  %t23 = load { i64, ptr }, ptr %t22, !tbaa !37
  store { i64, ptr } %t23, ptr %l19, !tbaa !27
  %t24 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t24, ptr %l8, !tbaa !27
  %t25 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t25, ptr %l20, !tbaa !27
  %t26 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t27 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v4, ptr %s2, { i64, ptr } %t26, { i64, ptr } { i64 0, ptr @.d48 })
  store i1 %t27, ptr %l21
  br label %bb6
bb6:
  %t28 = load i1, ptr %l21, !tbaa !21
  %t29 = xor i1 %t28, true
  store i1 %t29, ptr %l22, !tbaa !21
  %t30 = load i1, ptr %l22, !tbaa !21
  br i1 %t30, label %bb7, label %bb8
bb7:
  store %olang.scope zeroinitializer, ptr %s3
  %t31 = load ptr, ptr %l1, !tbaa !29
  store ptr %t31, ptr %l23, !tbaa !29
  %t32 = load ptr, ptr %l2, !tbaa !29
  store ptr %t32, ptr %l24, !tbaa !29
  %t33 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t33, ptr %l25, !tbaa !27
  %t34 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t34, ptr %l26, !tbaa !27
  %t35 = load ptr, ptr %l23, !tbaa !29
  %t36 = load ptr, ptr %l24, !tbaa !29
  %t37 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t38 = load { i64, ptr }, ptr %l26, !tbaa !27
  call void @compiler_2fparse_2ecompiler_2fparse_3aOracle_2eAdd(ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %t35, ptr %t36, { i64, ptr } %t37, { i64, ptr } %t38)
  br label %bb9
bb8:
  br label %bb10
bb9:
  call void @__olang_scope_close(ptr %s3)
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb11
bb11:
  store %olang.scope zeroinitializer, ptr %s4
  %t39 = load i64, ptr %l6, !tbaa !24
  store i64 %t39, ptr %l27, !tbaa !24
  %t40 = load i64, ptr %l27, !tbaa !24
  %t41 = add i64 %t40, 1
  store i64 %t41, ptr %l28, !tbaa !24
  %t42 = load i64, ptr %l28, !tbaa !24
  store i64 %t42, ptr %l6, !tbaa !24
  call void @__olang_scope_close(ptr %s4)
  br label %bb2
bb12:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffmt_2ecompiler_2ffmt_3aloader_2echains(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, i64 %a3, { i64, ptr } %a4, i64 %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i1
  %l15 = alloca ptr
  %l16 = alloca ptr
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i1
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i1
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i1
  %l36 = alloca i1
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca ptr
  %l43 = alloca ptr
  %l44 = alloca i64
  %l45 = alloca i64
  %l46 = alloca i64
  %l47 = alloca i1
  %l48 = alloca i1
  %l49 = alloca ptr
  %l50 = alloca ptr
  %l51 = alloca i64
  %l52 = alloca i64
  %l53 = alloca i1
  %l54 = alloca { i64, ptr }
  %l55 = alloca ptr
  %l56 = alloca ptr
  %l57 = alloca i64
  %l58 = alloca { i64, ptr }
  %l59 = alloca { i64, ptr }
  %l60 = alloca ptr
  %l61 = alloca ptr
  %l62 = alloca ptr
  %l63 = alloca { i64, ptr }
  %l64 = alloca ptr
  %l65 = alloca ptr
  %l66 = alloca ptr
  %l67 = alloca ptr
  %l68 = alloca i64
  %l69 = alloca i64
  %l70 = alloca { i64, ptr }
  %l71 = alloca ptr
  %l72 = alloca ptr
  %l73 = alloca ptr
  %l74 = alloca ptr
  %l75 = alloca ptr
  %l76 = alloca i64
  %l77 = alloca i64
  %l78 = alloca { i64, ptr }
  %l79 = alloca { i64, ptr }
  %l80 = alloca { i64, ptr }
  %l81 = alloca i64
  %l82 = alloca i64
  %l83 = alloca i64
  %l84 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.builder
  %s5room = alloca [64 x i8], align 8
  %s6 = alloca %olang.builder
  %s6room = alloca [64 x i8], align 8
  %s7 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i64 %a3, ptr %l3
  store { i64, ptr } %a4, ptr %l4
  store i64 %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l5, !tbaa !24
  store i64 %t1, ptr %l13, !tbaa !24
  %t2 = load i64, ptr %l13, !tbaa !24
  %t3 = icmp sge i64 %t2, 4
  store i1 %t3, ptr %l14, !tbaa !21
  %t4 = load i1, ptr %l14, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb2:
  br label %bb3
bb3:
  store %olang.scope zeroinitializer, ptr %s2
  store i64 0, ptr %l6, !tbaa !24
  %t5 = load ptr, ptr %l0, !tbaa !29
  store ptr %t5, ptr %l15, !tbaa !29
  %t6 = load ptr, ptr %l15, !tbaa !29
  %t7 = getelementptr %"compiler/fmt:loader", ptr %t6, i32 0, i32 3
  store ptr %t7, ptr %l16, !tbaa !29
  %t8 = load ptr, ptr %l16, !tbaa !29
  %t9 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t8)
  store i64 %t9, ptr %l17
  br label %bb4
bb4:
  %t10 = load i64, ptr %l17, !tbaa !24
  store i64 %t10, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t11 = load i64, ptr %l7, !tbaa !24
  store i64 %t11, ptr %l18, !tbaa !24
  %t12 = load i64, ptr %l6, !tbaa !24
  store i64 %t12, ptr %l19, !tbaa !24
  %t13 = load i64, ptr %l18, !tbaa !24
  %t14 = load i64, ptr %l19, !tbaa !24
  %t15 = icmp sgt i64 %t13, %t14
  store i1 %t15, ptr %l20, !tbaa !21
  %t16 = load i1, ptr %l20, !tbaa !21
  br i1 %t16, label %bb5, label %bb6
bb5:
  %t17 = load i64, ptr %l8, !tbaa !24
  store i64 %t17, ptr %l22, !tbaa !24
  %t18 = load i64, ptr %l22, !tbaa !24
  %t19 = icmp sgt i64 %t18, 0
  store i1 %t19, ptr %l23, !tbaa !21
  %t20 = load i1, ptr %l23, !tbaa !21
  br i1 %t20, label %bb7, label %bb8
bb6:
  store i64 0, ptr %l21, !tbaa !24
  br label %bb10
bb7:
  %t21 = load i64, ptr %l7, !tbaa !24
  store i64 %t21, ptr %l25, !tbaa !24
  %t22 = load i64, ptr %l6, !tbaa !24
  store i64 %t22, ptr %l26, !tbaa !24
  %t23 = load i64, ptr %l25, !tbaa !24
  %t24 = load i64, ptr %l26, !tbaa !24
  %t25 = sub i64 %t23, %t24
  store i64 %t25, ptr %l27, !tbaa !24
  %t26 = load i64, ptr %l8, !tbaa !24
  store i64 %t26, ptr %l28, !tbaa !24
  %t27 = load i64, ptr %l27, !tbaa !24
  %t28 = load i64, ptr %l28, !tbaa !24
  %t29 = add i64 %t27, %t28
  store i64 %t29, ptr %l29, !tbaa !24
  %t30 = load i64, ptr %l29, !tbaa !24
  %t31 = sub i64 %t30, 1
  store i64 %t31, ptr %l30, !tbaa !24
  %t32 = load i64, ptr %l8, !tbaa !24
  store i64 %t32, ptr %l31, !tbaa !24
  %t33 = load i64, ptr %l30, !tbaa !24
  %t34 = load i64, ptr %l31, !tbaa !24
  %t35 = sdiv i64 %t33, %t34
  store i64 %t35, ptr %l32, !tbaa !24
  %t36 = load i64, ptr %l32, !tbaa !24
  store i64 %t36, ptr %l24, !tbaa !24
  br label %bb9
bb8:
  store i64 0, ptr %l24, !tbaa !24
  br label %bb9
bb9:
  %t37 = load i64, ptr %l24, !tbaa !24
  store i64 %t37, ptr %l21, !tbaa !24
  br label %bb10
bb10:
  %t38 = load i64, ptr %l21, !tbaa !24
  store i64 %t38, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb11
bb11:
  store %olang.scope zeroinitializer, ptr %s3
  %t39 = load i64, ptr %l10, !tbaa !24
  store i64 %t39, ptr %l33, !tbaa !24
  %t40 = load i64, ptr %l9, !tbaa !24
  store i64 %t40, ptr %l34, !tbaa !24
  %t41 = load i64, ptr %l33, !tbaa !24
  %t42 = load i64, ptr %l34, !tbaa !24
  %t43 = icmp slt i64 %t41, %t42
  store i1 %t43, ptr %l35, !tbaa !21
  %t44 = load i1, ptr %l35, !tbaa !21
  %t45 = xor i1 %t44, true
  store i1 %t45, ptr %l36, !tbaa !21
  %t46 = load i1, ptr %l36, !tbaa !21
  br i1 %t46, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s3)
  br label %bb30
bb13:
  br label %bb14
bb14:
  %t47 = load i64, ptr %l6, !tbaa !24
  store i64 %t47, ptr %l37, !tbaa !24
  %t48 = load i64, ptr %l10, !tbaa !24
  store i64 %t48, ptr %l38, !tbaa !24
  %t49 = load i64, ptr %l8, !tbaa !24
  store i64 %t49, ptr %l39, !tbaa !24
  %t50 = load i64, ptr %l38, !tbaa !24
  %t51 = load i64, ptr %l39, !tbaa !24
  %t52 = mul i64 %t50, %t51
  store i64 %t52, ptr %l40, !tbaa !24
  %t53 = load i64, ptr %l37, !tbaa !24
  %t54 = load i64, ptr %l40, !tbaa !24
  %t55 = add i64 %t53, %t54
  store i64 %t55, ptr %l41, !tbaa !24
  %t56 = load i64, ptr %l41, !tbaa !24
  store i64 %t56, ptr %l11, !tbaa !24
  %t57 = load ptr, ptr %l0, !tbaa !29
  store ptr %t57, ptr %l42, !tbaa !29
  %t58 = load ptr, ptr %l42, !tbaa !29
  %t59 = getelementptr %"compiler/fmt:loader", ptr %t58, i32 0, i32 3
  store ptr %t59, ptr %l43, !tbaa !29
  %t60 = load i64, ptr %l11, !tbaa !24
  store i64 %t60, ptr %l44, !tbaa !24
  %t61 = load ptr, ptr %l43, !tbaa !29
  %t62 = load i64, ptr %l44, !tbaa !24
  %t63 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t61, i64 %t62)
  store i64 %t63, ptr %l45
  br label %bb15
bb15:
  %t64 = load i64, ptr %l3, !tbaa !24
  store i64 %t64, ptr %l46, !tbaa !24
  %t65 = load i64, ptr %l45, !tbaa !24
  %t66 = load i64, ptr %l46, !tbaa !24
  %t67 = icmp ne i64 %t65, %t66
  store i1 %t67, ptr %l47, !tbaa !21
  %t68 = load i1, ptr %l47, !tbaa !21
  br i1 %t68, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l48, !tbaa !21
  br label %bb19
bb17:
  %t69 = load ptr, ptr %l0, !tbaa !29
  store ptr %t69, ptr %l49, !tbaa !29
  %t70 = load ptr, ptr %l49, !tbaa !29
  %t71 = getelementptr %"compiler/fmt:loader", ptr %t70, i32 0, i32 5
  store ptr %t71, ptr %l50, !tbaa !29
  %t72 = load i64, ptr %l11, !tbaa !24
  store i64 %t72, ptr %l51, !tbaa !24
  %t73 = load ptr, ptr %l50, !tbaa !29
  %t74 = load i64, ptr %l51, !tbaa !24
  %t75 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t73, i64 %t74)
  store i64 %t75, ptr %l52
  br label %bb18
bb18:
  %t76 = load i64, ptr %l52, !tbaa !24
  %t77 = icmp slt i64 %t76, 0
  store i1 %t77, ptr %l53, !tbaa !21
  %t78 = load i1, ptr %l53, !tbaa !21
  store i1 %t78, ptr %l48, !tbaa !21
  br label %bb19
bb19:
  %t79 = load i1, ptr %l48, !tbaa !21
  br i1 %t79, label %bb20, label %bb21
bb20:
  store %olang.scope zeroinitializer, ptr %s4
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s3)
  br label %bb29
bb21:
  br label %bb22
bb22:
  %t80 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t80, ptr %l54, !tbaa !27
  %t81 = load ptr, ptr %l0, !tbaa !29
  store ptr %t81, ptr %l55, !tbaa !29
  %t82 = load ptr, ptr %l55, !tbaa !29
  %t83 = getelementptr %"compiler/fmt:loader", ptr %t82, i32 0, i32 4
  store ptr %t83, ptr %l56, !tbaa !29
  %t84 = load i64, ptr %l11, !tbaa !24
  store i64 %t84, ptr %l57, !tbaa !24
  %t85 = load ptr, ptr %l56, !tbaa !29
  %t86 = load i64, ptr %l57, !tbaa !24
  %t87 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %s3, ptr %t85, i64 %t86)
  store { i64, ptr } %t87, ptr %l58
  br label %bb23
bb23:
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s5
  store ptr %s5room, ptr %s5
  %t88 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t89 = extractvalue { i64, ptr } %t88, 1
  %t90 = extractvalue { i64, ptr } %t88, 0
  call void @__olang_sb_put(ptr %s5, ptr %t89, i64 %t90)
  %t91 = load { i64, ptr }, ptr %l58, !tbaa !27
  %t92 = extractvalue { i64, ptr } %t91, 1
  %t93 = extractvalue { i64, ptr } %t91, 0
  call void @__olang_sb_put(ptr %s5, ptr %t92, i64 %t93)
  %t94 = load ptr, ptr %s5
  %t95 = getelementptr %olang.builder, ptr %s5, i32 0, i32 1
  %t96 = load i64, ptr %t95
  %t97 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t96)
  call void @llvm.memcpy.p0.p0.i64(ptr %t97, ptr %t94, i64 %t96, i1 false)
  %t98 = insertvalue { i64, ptr } undef, i64 %t96, 0
  %t99 = insertvalue { i64, ptr } %t98, ptr %t97, 1
  store { i64, ptr } %t99, ptr %l59, !tbaa !27
  call void @__olang_sb_done(ptr %s5)
  %t100 = load { i64, ptr }, ptr %l59, !tbaa !27
  store { i64, ptr } %t100, ptr %l12, !tbaa !27
  %t101 = load ptr, ptr %l0, !tbaa !29
  store ptr %t101, ptr %l60, !tbaa !29
  %t102 = load ptr, ptr %l1, !tbaa !29
  store ptr %t102, ptr %l61, !tbaa !29
  %t103 = load ptr, ptr %l2, !tbaa !29
  store ptr %t103, ptr %l62, !tbaa !29
  %t104 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t104, ptr %l63, !tbaa !27
  %t105 = load ptr, ptr %l0, !tbaa !29
  store ptr %t105, ptr %l64, !tbaa !29
  %t106 = load ptr, ptr %l64, !tbaa !29
  %t107 = getelementptr %"compiler/fmt:loader", ptr %t106, i32 0, i32 2
  store ptr %t107, ptr %l65, !tbaa !29
  %t108 = load ptr, ptr %l0, !tbaa !29
  store ptr %t108, ptr %l66, !tbaa !29
  %t109 = load ptr, ptr %l66, !tbaa !29
  %t110 = getelementptr %"compiler/fmt:loader", ptr %t109, i32 0, i32 5
  store ptr %t110, ptr %l67, !tbaa !29
  %t111 = load i64, ptr %l11, !tbaa !24
  store i64 %t111, ptr %l68, !tbaa !24
  %t112 = load ptr, ptr %l67, !tbaa !29
  %t113 = load i64, ptr %l68, !tbaa !24
  %t114 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t112, i64 %t113)
  store i64 %t114, ptr %l69
  br label %bb24
bb24:
  %t115 = load ptr, ptr %l65, !tbaa !29
  %t116 = load i64, ptr %l69, !tbaa !24
  %t117 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %v0, ptr %t115, i64 %t116)
  store { i64, ptr } %t117, ptr %l70
  br label %bb25
bb25:
  %t118 = load ptr, ptr %l60, !tbaa !29
  %t119 = load ptr, ptr %l61, !tbaa !29
  %t120 = load ptr, ptr %l62, !tbaa !29
  %t121 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t122 = load { i64, ptr }, ptr %l70, !tbaa !27
  call void @compiler_2ffmt_2ecompiler_2ffmt_3aloader_2eaddNames(ptr %v0, ptr %v1, ptr %v2, ptr %s3, ptr %v0, ptr %t118, ptr %t119, ptr %t120, { i64, ptr } %t121, { i64, ptr } %t122)
  br label %bb26
bb26:
  %t123 = load ptr, ptr %l0, !tbaa !29
  store ptr %t123, ptr %l71, !tbaa !29
  %t124 = load ptr, ptr %l1, !tbaa !29
  store ptr %t124, ptr %l72, !tbaa !29
  %t125 = load ptr, ptr %l2, !tbaa !29
  store ptr %t125, ptr %l73, !tbaa !29
  %t126 = load ptr, ptr %l0, !tbaa !29
  store ptr %t126, ptr %l74, !tbaa !29
  %t127 = load ptr, ptr %l74, !tbaa !29
  %t128 = getelementptr %"compiler/fmt:loader", ptr %t127, i32 0, i32 5
  store ptr %t128, ptr %l75, !tbaa !29
  %t129 = load i64, ptr %l11, !tbaa !24
  store i64 %t129, ptr %l76, !tbaa !24
  %t130 = load ptr, ptr %l75, !tbaa !29
  %t131 = load i64, ptr %l76, !tbaa !24
  %t132 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t130, i64 %t131)
  store i64 %t132, ptr %l77
  br label %bb27
bb27:
  %t133 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t133, ptr %l78, !tbaa !27
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s6
  store ptr %s6room, ptr %s6
  %t134 = load { i64, ptr }, ptr %l78, !tbaa !27
  %t135 = extractvalue { i64, ptr } %t134, 1
  %t136 = extractvalue { i64, ptr } %t134, 0
  call void @__olang_sb_put(ptr %s6, ptr %t135, i64 %t136)
  %t137 = extractvalue { i64, ptr } { i64 1, ptr @.d49 }, 1
  %t138 = extractvalue { i64, ptr } { i64 1, ptr @.d49 }, 0
  call void @__olang_sb_put(ptr %s6, ptr %t137, i64 %t138)
  %t139 = load ptr, ptr %s6
  %t140 = getelementptr %olang.builder, ptr %s6, i32 0, i32 1
  %t141 = load i64, ptr %t140
  %t142 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t141)
  call void @llvm.memcpy.p0.p0.i64(ptr %t142, ptr %t139, i64 %t141, i1 false)
  %t143 = insertvalue { i64, ptr } undef, i64 %t141, 0
  %t144 = insertvalue { i64, ptr } %t143, ptr %t142, 1
  store { i64, ptr } %t144, ptr %l79, !tbaa !27
  call void @__olang_sb_done(ptr %s6)
  %t145 = load { i64, ptr }, ptr %l79, !tbaa !27
  %t146 = extractvalue { i64, ptr } %t145, 0
  %t147 = extractvalue { i64, ptr } %t145, 1
  %t148 = mul i64 %t146, 1
  %t149 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t148)
  call void @llvm.memcpy.p0.p0.i64(ptr %t149, ptr %t147, i64 %t148, i1 false)
  %t150 = insertvalue { i64, ptr } undef, i64 %t146, 0
  %t151 = insertvalue { i64, ptr } %t150, ptr %t149, 1
  store { i64, ptr } %t151, ptr %l80, !tbaa !27
  %t152 = load i64, ptr %l5, !tbaa !24
  store i64 %t152, ptr %l81, !tbaa !24
  %t153 = load i64, ptr %l81, !tbaa !24
  %t154 = add i64 %t153, 1
  store i64 %t154, ptr %l82, !tbaa !24
  %t155 = load ptr, ptr %l71, !tbaa !29
  %t156 = load ptr, ptr %l72, !tbaa !29
  %t157 = load ptr, ptr %l73, !tbaa !29
  %t158 = load i64, ptr %l77, !tbaa !24
  %t159 = load { i64, ptr }, ptr %l80, !tbaa !27
  %t160 = load i64, ptr %l82, !tbaa !24
  call void @compiler_2ffmt_2ecompiler_2ffmt_3aloader_2echains(ptr %v0, ptr %v1, ptr %v2, ptr %s3, ptr %t155, ptr %t156, ptr %t157, i64 %t158, { i64, ptr } %t159, i64 %t160)
  br label %bb28
bb28:
  call void @__olang_scope_close(ptr %s3)
  br label %bb29
bb29:
  store %olang.scope zeroinitializer, ptr %s7
  %t161 = load i64, ptr %l10, !tbaa !24
  store i64 %t161, ptr %l83, !tbaa !24
  %t162 = load i64, ptr %l83, !tbaa !24
  %t163 = add i64 %t162, 1
  store i64 %t163, ptr %l84, !tbaa !24
  %t164 = load i64, ptr %l84, !tbaa !24
  store i64 %t164, ptr %l10, !tbaa !24
  call void @__olang_scope_close(ptr %s7)
  br label %bb11
bb30:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2ffmt_2ecompiler_2ffmt_3aloader_2eload(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca %"compiler/source:Source"
  %l10 = alloca %"compiler/scan:Tokens"
  %l11 = alloca i64
  %l12 = alloca %"std/prelude/text:StringBuilder"
  %l13 = alloca %"std/prelude/list:List<std/prelude/text:String&>"
  %l14 = alloca %"std/prelude/list:List<std/prelude/text:String&>"
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i32
  %l24 = alloca i1
  %l25 = alloca i64
  %l26 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca { i64, ptr }
  %l35 = alloca i64
  %l36 = alloca { i64, ptr }
  %l37 = alloca { i64, ptr }
  %l38 = alloca { i64, ptr }
  %l39 = alloca i32
  %l40 = alloca i32
  %l41 = alloca i1
  %l42 = alloca i64
  %l43 = alloca ptr
  %l44 = alloca ptr
  %l45 = alloca i64
  %l46 = alloca i64
  %l47 = alloca i64
  %l48 = alloca i1
  %l49 = alloca i64
  %l50 = alloca i64
  %l51 = alloca i1
  %l52 = alloca i64
  %l53 = alloca i64
  %l54 = alloca i64
  %l55 = alloca i64
  %l56 = alloca i64
  %l57 = alloca i64
  %l58 = alloca i64
  %l59 = alloca i64
  %l60 = alloca i64
  %l61 = alloca i64
  %l62 = alloca i64
  %l63 = alloca i1
  %l64 = alloca i1
  %l65 = alloca i64
  %l66 = alloca i64
  %l67 = alloca i64
  %l68 = alloca i64
  %l69 = alloca i64
  %l70 = alloca ptr
  %l71 = alloca ptr
  %l72 = alloca i64
  %l73 = alloca { i64, ptr }
  %l74 = alloca { i64, ptr }
  %l75 = alloca i1
  %l76 = alloca i64
  %l77 = alloca i64
  %l78 = alloca i64
  %l79 = alloca %"compiler/source:Source"
  %l80 = alloca { i64, ptr }
  %l81 = alloca %"compiler/source:Source"
  %l82 = alloca i32
  %l83 = alloca i32
  %l84 = alloca i1
  %l85 = alloca i64
  %l86 = alloca { i64, ptr }
  %l87 = alloca %"compiler/scan:Tokens"
  %l88 = alloca ptr
  %l89 = alloca ptr
  %l90 = alloca i64
  %l91 = alloca ptr
  %l92 = alloca ptr
  %l93 = alloca { i64, ptr }
  %l94 = alloca { i64, ptr }
  %l95 = alloca { i64, ptr }
  %l96 = alloca %"std/prelude/text:StringBuilder"
  %l97 = alloca ptr
  %l98 = alloca %"std/prelude/list:List<std/prelude/text:String&>"
  %l99 = alloca %"std/prelude/list:List<std/prelude/text:String&>"
  %l100 = alloca { i64, ptr }
  %l101 = alloca { i64, ptr }
  %l102 = alloca i64
  %l103 = alloca i64
  %l104 = alloca i64
  %l105 = alloca i64
  %l106 = alloca i1
  %l107 = alloca i64
  %l108 = alloca i64
  %l109 = alloca i1
  %l110 = alloca i64
  %l111 = alloca i64
  %l112 = alloca i64
  %l113 = alloca i64
  %l114 = alloca i64
  %l115 = alloca i64
  %l116 = alloca i64
  %l117 = alloca i64
  %l118 = alloca i64
  %l119 = alloca i64
  %l120 = alloca i64
  %l121 = alloca i1
  %l122 = alloca i1
  %l123 = alloca i64
  %l124 = alloca i64
  %l125 = alloca i64
  %l126 = alloca i64
  %l127 = alloca i64
  %l128 = alloca { i64, ptr }
  %l129 = alloca i64
  %l130 = alloca i32
  %l131 = alloca i64
  %l132 = alloca i64
  %l133 = alloca i64
  %l134 = alloca i1
  %l135 = alloca i1
  %l136 = alloca { i64, ptr }
  %l137 = alloca i64
  %l138 = alloca i64
  %l139 = alloca i32
  %l140 = alloca ptr
  %l141 = alloca i32
  %l142 = alloca ptr
  %l143 = alloca i1
  %l144 = alloca i32
  %l145 = alloca ptr
  %l146 = alloca i32
  %l147 = alloca ptr
  %l148 = alloca i1
  %l149 = alloca i1
  %l150 = alloca i1
  %l151 = alloca i1
  %l152 = alloca i32
  %l153 = alloca ptr
  %l154 = alloca i32
  %l155 = alloca ptr
  %l156 = alloca i1
  %l157 = alloca i1
  %l158 = alloca i1
  %l159 = alloca i1
  %l160 = alloca i64
  %l161 = alloca i64
  %l162 = alloca i64
  %l163 = alloca i1
  %l164 = alloca i1
  %l165 = alloca { i64, ptr }
  %l166 = alloca i64
  %l167 = alloca i64
  %l168 = alloca i32
  %l169 = alloca ptr
  %l170 = alloca i32
  %l171 = alloca ptr
  %l172 = alloca i1
  %l173 = alloca ptr
  %l174 = alloca { i64, ptr }
  %l175 = alloca { i64, ptr }
  %l176 = alloca i64
  %l177 = alloca i64
  %l178 = alloca i32
  %l179 = alloca i64
  %l180 = alloca { i64, ptr }
  %l181 = alloca i64
  %l182 = alloca i64
  %l183 = alloca i32
  %l184 = alloca i64
  %l185 = alloca i64
  %l186 = alloca i1
  %l187 = alloca i1
  %l188 = alloca i1
  %l189 = alloca { i64, ptr }
  %l190 = alloca ptr
  %l191 = alloca i32
  %l192 = alloca ptr
  %l193 = alloca i32
  %l194 = alloca ptr
  %l195 = alloca i1
  %l196 = alloca i64
  %l197 = alloca i64
  %l198 = alloca i64
  %l199 = alloca i64
  %l200 = alloca i1
  %l201 = alloca i1
  %l202 = alloca { i64, ptr }
  %l203 = alloca i64
  %l204 = alloca i32
  %l205 = alloca ptr
  %l206 = alloca i32
  %l207 = alloca ptr
  %l208 = alloca i1
  %l209 = alloca { i64, ptr }
  %l210 = alloca { i64, ptr }
  %l211 = alloca i64
  %l212 = alloca i32
  %l213 = alloca i64
  %l214 = alloca { i64, ptr }
  %l215 = alloca i64
  %l216 = alloca i32
  %l217 = alloca i64
  %l218 = alloca i64
  %l219 = alloca i1
  %l220 = alloca i1
  %l221 = alloca i1
  %l222 = alloca { i64, ptr }
  %l223 = alloca { i64, ptr }
  %l224 = alloca { i64, ptr }
  %l225 = alloca i64
  %l226 = alloca i64
  %l227 = alloca i64
  %l228 = alloca i64
  %l229 = alloca i1
  %l230 = alloca i1
  %l231 = alloca { i64, ptr }
  %l232 = alloca i64
  %l233 = alloca i32
  %l234 = alloca ptr
  %l235 = alloca i32
  %l236 = alloca ptr
  %l237 = alloca i1
  %l238 = alloca { i64, ptr }
  %l239 = alloca { i64, ptr }
  %l240 = alloca i64
  %l241 = alloca i32
  %l242 = alloca i32
  %l243 = alloca i64
  %l244 = alloca { i64, ptr }
  %l245 = alloca i64
  %l246 = alloca i32
  %l247 = alloca i32
  %l248 = alloca i64
  %l249 = alloca i64
  %l250 = alloca i1
  %l251 = alloca i1
  %l252 = alloca i1
  %l253 = alloca { i64, ptr }
  %l254 = alloca { i64, ptr }
  %l255 = alloca i1
  %l256 = alloca { i64, ptr }
  %l257 = alloca { i64, ptr }
  %l258 = alloca { i64, ptr }
  %l259 = alloca { i64, ptr }
  %l260 = alloca ptr
  %l261 = alloca { i64, ptr }
  %l262 = alloca { i64, ptr }
  %l263 = alloca { i64, ptr }
  %l264 = alloca ptr
  %l265 = alloca { i64, ptr }
  %l266 = alloca { i64, ptr }
  %l267 = alloca { i64, ptr }
  %l268 = alloca i64
  %l269 = alloca i64
  %l270 = alloca ptr
  %l271 = alloca ptr
  %l272 = alloca ptr
  %l273 = alloca { i64, ptr }
  %l274 = alloca ptr
  %l275 = alloca i64
  %l276 = alloca i64
  %l277 = alloca i64
  %l278 = alloca i1
  %l279 = alloca i64
  %l280 = alloca i64
  %l281 = alloca i1
  %l282 = alloca i64
  %l283 = alloca i64
  %l284 = alloca i64
  %l285 = alloca i64
  %l286 = alloca i64
  %l287 = alloca i64
  %l288 = alloca i64
  %l289 = alloca i64
  %l290 = alloca i64
  %l291 = alloca i64
  %l292 = alloca i64
  %l293 = alloca i1
  %l294 = alloca i1
  %l295 = alloca i64
  %l296 = alloca i64
  %l297 = alloca i64
  %l298 = alloca i64
  %l299 = alloca i64
  %l300 = alloca ptr
  %l301 = alloca { i64, ptr }
  %l302 = alloca ptr
  %l303 = alloca i64
  %l304 = alloca { i64, ptr }
  %l305 = alloca { i64, ptr }
  %l306 = alloca { i64, ptr }
  %l307 = alloca i1
  %l308 = alloca i1
  %l309 = alloca ptr
  %l310 = alloca { i64, ptr }
  %l311 = alloca i64
  %l312 = alloca ptr
  %l313 = alloca ptr
  %l314 = alloca i64
  %l315 = alloca ptr
  %l316 = alloca ptr
  %l317 = alloca ptr
  %l318 = alloca i64
  %l319 = alloca { i64, ptr }
  %l320 = alloca { i64, ptr }
  %l321 = alloca { i64, ptr }
  %l322 = alloca ptr
  %l323 = alloca ptr
  %l324 = alloca i64
  %l325 = alloca i64
  %l326 = alloca i64
  %l327 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.builder
  %s7room = alloca [64 x i8], align 8
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s13 = alloca %olang.builder
  %s13room = alloca [64 x i8], align 8
  %s14 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s16 = alloca %olang.builder
  %s16room = alloca [64 x i8], align 8
  %s17 = alloca %olang.builder
  %s17room = alloca [64 x i8], align 8
  %s18 = alloca %olang.builder
  %s18room = alloca [64 x i8], align 8
  %s19 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %s23 = alloca %olang.builder
  %s23room = alloca [64 x i8], align 8
  %s24 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t1, ptr %l37, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t3 = call { i32, { i64, ptr } } @std_2fos_2eRealPath(ptr %v1, ptr %s0, { i64, ptr } %t2)
  %t4 = extractvalue { i32, { i64, ptr } } %t3, 1
  %t5 = extractvalue { i32, { i64, ptr } } %t3, 0
  store i32 %t5, ptr %l39
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7
ok.7:
  store { i64, ptr } %t4, ptr %l38
  br label %bb1
bb1:
  %t8 = load { i64, ptr }, ptr %l38, !tbaa !27
  store { i64, ptr } %t8, ptr %l36, !tbaa !27
  br label %bb6
bb2:
  %t9 = load i32, ptr %l39, !tbaa !23
  %t10 = ashr i32 %t9, 16
  store i32 %t10, ptr %l40, !tbaa !23
  %t11 = load i32, ptr %l40, !tbaa !23
  %t12 = icmp eq i32 %t11, 1
  store i1 %t12, ptr %l41, !tbaa !21
  %t13 = load i1, ptr %l41, !tbaa !21
  br i1 %t13, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  call void @__olang_check_failed(ptr @.c50)
  unreachable
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  store i64 -1, ptr %l42, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t14 = load i64, ptr %l42, !tbaa !24
  store i64 %t14, ptr %rv
  br label %ret
bb6:
  %t15 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t15, ptr %l2, !tbaa !27
  store %olang.scope zeroinitializer, ptr %s2
  store i64 0, ptr %l3, !tbaa !24
  %t16 = load ptr, ptr %l0, !tbaa !29
  store ptr %t16, ptr %l43, !tbaa !29
  %t17 = load ptr, ptr %l43, !tbaa !29
  %t18 = getelementptr %"compiler/fmt:loader", ptr %t17, i32 0, i32 1
  store ptr %t18, ptr %l44, !tbaa !29
  %t19 = load ptr, ptr %l44, !tbaa !29
  %t20 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %v0, ptr %t19)
  store i64 %t20, ptr %l45
  br label %bb7
bb7:
  %t21 = load i64, ptr %l45, !tbaa !24
  store i64 %t21, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t22 = load i64, ptr %l4, !tbaa !24
  store i64 %t22, ptr %l46, !tbaa !24
  %t23 = load i64, ptr %l3, !tbaa !24
  store i64 %t23, ptr %l47, !tbaa !24
  %t24 = load i64, ptr %l46, !tbaa !24
  %t25 = load i64, ptr %l47, !tbaa !24
  %t26 = icmp sgt i64 %t24, %t25
  store i1 %t26, ptr %l48, !tbaa !21
  %t27 = load i1, ptr %l48, !tbaa !21
  br i1 %t27, label %bb8, label %bb9
bb8:
  %t28 = load i64, ptr %l5, !tbaa !24
  store i64 %t28, ptr %l50, !tbaa !24
  %t29 = load i64, ptr %l50, !tbaa !24
  %t30 = icmp sgt i64 %t29, 0
  store i1 %t30, ptr %l51, !tbaa !21
  %t31 = load i1, ptr %l51, !tbaa !21
  br i1 %t31, label %bb10, label %bb11
bb9:
  store i64 0, ptr %l49, !tbaa !24
  br label %bb13
bb10:
  %t32 = load i64, ptr %l4, !tbaa !24
  store i64 %t32, ptr %l53, !tbaa !24
  %t33 = load i64, ptr %l3, !tbaa !24
  store i64 %t33, ptr %l54, !tbaa !24
  %t34 = load i64, ptr %l53, !tbaa !24
  %t35 = load i64, ptr %l54, !tbaa !24
  %t36 = sub i64 %t34, %t35
  store i64 %t36, ptr %l55, !tbaa !24
  %t37 = load i64, ptr %l5, !tbaa !24
  store i64 %t37, ptr %l56, !tbaa !24
  %t38 = load i64, ptr %l55, !tbaa !24
  %t39 = load i64, ptr %l56, !tbaa !24
  %t40 = add i64 %t38, %t39
  store i64 %t40, ptr %l57, !tbaa !24
  %t41 = load i64, ptr %l57, !tbaa !24
  %t42 = sub i64 %t41, 1
  store i64 %t42, ptr %l58, !tbaa !24
  %t43 = load i64, ptr %l5, !tbaa !24
  store i64 %t43, ptr %l59, !tbaa !24
  %t44 = load i64, ptr %l58, !tbaa !24
  %t45 = load i64, ptr %l59, !tbaa !24
  %t46 = sdiv i64 %t44, %t45
  store i64 %t46, ptr %l60, !tbaa !24
  %t47 = load i64, ptr %l60, !tbaa !24
  store i64 %t47, ptr %l52, !tbaa !24
  br label %bb12
bb11:
  store i64 0, ptr %l52, !tbaa !24
  br label %bb12
bb12:
  %t48 = load i64, ptr %l52, !tbaa !24
  store i64 %t48, ptr %l49, !tbaa !24
  br label %bb13
bb13:
  %t49 = load i64, ptr %l49, !tbaa !24
  store i64 %t49, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb14
bb14:
  store %olang.scope zeroinitializer, ptr %s3
  %t50 = load i64, ptr %l7, !tbaa !24
  store i64 %t50, ptr %l61, !tbaa !24
  %t51 = load i64, ptr %l6, !tbaa !24
  store i64 %t51, ptr %l62, !tbaa !24
  %t52 = load i64, ptr %l61, !tbaa !24
  %t53 = load i64, ptr %l62, !tbaa !24
  %t54 = icmp slt i64 %t52, %t53
  store i1 %t54, ptr %l63, !tbaa !21
  %t55 = load i1, ptr %l63, !tbaa !21
  %t56 = xor i1 %t55, true
  store i1 %t56, ptr %l64, !tbaa !21
  %t57 = load i1, ptr %l64, !tbaa !21
  br i1 %t57, label %bb15, label %bb16
bb15:
  call void @__olang_scope_close(ptr %s3)
  br label %bb24
bb16:
  br label %bb17
bb17:
  %t58 = load i64, ptr %l3, !tbaa !24
  store i64 %t58, ptr %l65, !tbaa !24
  %t59 = load i64, ptr %l7, !tbaa !24
  store i64 %t59, ptr %l66, !tbaa !24
  %t60 = load i64, ptr %l5, !tbaa !24
  store i64 %t60, ptr %l67, !tbaa !24
  %t61 = load i64, ptr %l66, !tbaa !24
  %t62 = load i64, ptr %l67, !tbaa !24
  %t63 = mul i64 %t61, %t62
  store i64 %t63, ptr %l68, !tbaa !24
  %t64 = load i64, ptr %l65, !tbaa !24
  %t65 = load i64, ptr %l68, !tbaa !24
  %t66 = add i64 %t64, %t65
  store i64 %t66, ptr %l69, !tbaa !24
  %t67 = load i64, ptr %l69, !tbaa !24
  store i64 %t67, ptr %l8, !tbaa !24
  %t68 = load ptr, ptr %l0, !tbaa !29
  store ptr %t68, ptr %l70, !tbaa !29
  %t69 = load ptr, ptr %l70, !tbaa !29
  %t70 = getelementptr %"compiler/fmt:loader", ptr %t69, i32 0, i32 1
  store ptr %t70, ptr %l71, !tbaa !29
  %t71 = load i64, ptr %l8, !tbaa !24
  store i64 %t71, ptr %l72, !tbaa !24
  %t72 = load ptr, ptr %l71, !tbaa !29
  %t73 = load i64, ptr %l72, !tbaa !24
  %t74 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %v0, ptr %t72, i64 %t73)
  store { i64, ptr } %t74, ptr %l73
  br label %bb18
bb18:
  %t75 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t75, ptr %l74, !tbaa !27
  %t76 = load { i64, ptr }, ptr %l73, !tbaa !27
  %t77 = load { i64, ptr }, ptr %l74, !tbaa !27
  %t78 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t76, { i64, ptr } %t77)
  store i1 %t78, ptr %l75
  br label %bb19
bb19:
  %t79 = load i1, ptr %l75, !tbaa !21
  br i1 %t79, label %bb20, label %bb21
bb20:
  store %olang.scope zeroinitializer, ptr %s4
  %t80 = load i64, ptr %l8, !tbaa !24
  store i64 %t80, ptr %l76, !tbaa !24
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t81 = load i64, ptr %l76, !tbaa !24
  store i64 %t81, ptr %rv
  br label %ret
bb21:
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s3)
  br label %bb23
bb23:
  store %olang.scope zeroinitializer, ptr %s5
  %t82 = load i64, ptr %l7, !tbaa !24
  store i64 %t82, ptr %l77, !tbaa !24
  %t83 = load i64, ptr %l77, !tbaa !24
  %t84 = add i64 %t83, 1
  store i64 %t84, ptr %l78, !tbaa !24
  %t85 = load i64, ptr %l78, !tbaa !24
  store i64 %t85, ptr %l7, !tbaa !24
  call void @__olang_scope_close(ptr %s5)
  br label %bb14
bb24:
  call void @__olang_scope_close(ptr %s2)
  %t86 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t86, ptr %l80, !tbaa !27
  %t87 = load { i64, ptr }, ptr %l80, !tbaa !27
  %t88 = call { i32, %"compiler/source:Source" } @compiler_2fsource_2eRead(ptr %s0, ptr %s0, { i64, ptr } %t87)
  %t89 = extractvalue { i32, %"compiler/source:Source" } %t88, 1
  %t90 = extractvalue { i32, %"compiler/source:Source" } %t88, 0
  store i32 %t90, ptr %l82
  %t91 = icmp ne i32 %t90, 0
  br i1 %t91, label %bb26, label %ok.92
ok.92:
  store %"compiler/source:Source" %t89, ptr %l81
  br label %bb25
bb25:
  %t93 = load %"compiler/source:Source", ptr %l81
  store %"compiler/source:Source" %t93, ptr %l79
  br label %bb30
bb26:
  %t94 = load i32, ptr %l82, !tbaa !23
  %t95 = ashr i32 %t94, 16
  store i32 %t95, ptr %l83, !tbaa !23
  %t96 = load i32, ptr %l83, !tbaa !23
  %t97 = icmp eq i32 %t96, 1
  store i1 %t97, ptr %l84, !tbaa !21
  %t98 = load i1, ptr %l84, !tbaa !21
  br i1 %t98, label %bb27, label %bb28
bb27:
  br label %bb29
bb28:
  call void @__olang_check_failed(ptr @.c51)
  unreachable
bb29:
  store %olang.scope zeroinitializer, ptr %s6
  store i64 -1, ptr %l85, !tbaa !24
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  %t99 = load i64, ptr %l85, !tbaa !24
  store i64 %t99, ptr %rv
  br label %ret
bb30:
  %t100 = load %"compiler/source:Source", ptr %l79
  store %"compiler/source:Source" %t100, ptr %l9
  %t101 = getelementptr %"compiler/source:Source", ptr %l9, i32 0, i32 1
  %t102 = load { i64, ptr }, ptr %t101, !tbaa !27
  store { i64, ptr } %t102, ptr %l86, !tbaa !27
  %t103 = load { i64, ptr }, ptr %l86, !tbaa !27
  %t104 = call %"compiler/scan:Tokens" @compiler_2fscan_2eScan(ptr %s0, ptr %s0, { i64, ptr } %t103)
  store %"compiler/scan:Tokens" %t104, ptr %l87
  br label %bb31
bb31:
  %t105 = load %"compiler/scan:Tokens", ptr %l87
  store %"compiler/scan:Tokens" %t105, ptr %l10
  %t106 = load ptr, ptr %l0, !tbaa !29
  store ptr %t106, ptr %l88, !tbaa !29
  %t107 = load ptr, ptr %l88, !tbaa !29
  %t108 = getelementptr %"compiler/fmt:loader", ptr %t107, i32 0, i32 1
  store ptr %t108, ptr %l89, !tbaa !29
  %t109 = load ptr, ptr %l89, !tbaa !29
  %t110 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %v0, ptr %t109)
  store i64 %t110, ptr %l90
  br label %bb32
bb32:
  %t111 = load i64, ptr %l90, !tbaa !24
  store i64 %t111, ptr %l11, !tbaa !24
  %t112 = load ptr, ptr %l0, !tbaa !29
  store ptr %t112, ptr %l91, !tbaa !29
  %t113 = load ptr, ptr %l91, !tbaa !29
  %t114 = getelementptr %"compiler/fmt:loader", ptr %t113, i32 0, i32 1
  store ptr %t114, ptr %l92, !tbaa !29
  %t115 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t115, ptr %l93, !tbaa !27
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s7
  store ptr %s7room, ptr %s7
  %t116 = load { i64, ptr }, ptr %l93, !tbaa !27
  %t117 = extractvalue { i64, ptr } %t116, 1
  %t118 = extractvalue { i64, ptr } %t116, 0
  call void @__olang_sb_put(ptr %s7, ptr %t117, i64 %t118)
  %t119 = load ptr, ptr %s7
  %t120 = getelementptr %olang.builder, ptr %s7, i32 0, i32 1
  %t121 = load i64, ptr %t120
  %t122 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t121)
  call void @llvm.memcpy.p0.p0.i64(ptr %t122, ptr %t119, i64 %t121, i1 false)
  %t123 = insertvalue { i64, ptr } undef, i64 %t121, 0
  %t124 = insertvalue { i64, ptr } %t123, ptr %t122, 1
  store { i64, ptr } %t124, ptr %l94, !tbaa !27
  call void @__olang_sb_done(ptr %s7)
  %t125 = load { i64, ptr }, ptr %l94, !tbaa !27
  %t126 = extractvalue { i64, ptr } %t125, 0
  %t127 = extractvalue { i64, ptr } %t125, 1
  %t128 = mul i64 %t126, 1
  %t129 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t128)
  call void @llvm.memcpy.p0.p0.i64(ptr %t129, ptr %t127, i64 %t128, i1 false)
  %t130 = insertvalue { i64, ptr } undef, i64 %t126, 0
  %t131 = insertvalue { i64, ptr } %t130, ptr %t129, 1
  store { i64, ptr } %t131, ptr %l95, !tbaa !27
  %t132 = load ptr, ptr %l92, !tbaa !29
  %t133 = load { i64, ptr }, ptr %l95, !tbaa !27
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v0, ptr %v0, ptr %t132, { i64, ptr } %t133)
  br label %bb33
bb33:
  %t134 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t134, ptr %l96
  br label %bb34
bb34:
  %t135 = load %"std/prelude/text:StringBuilder", ptr %l96
  store %"std/prelude/text:StringBuilder" %t135, ptr %l12
  store ptr %l12, ptr %l97, !tbaa !29
  %t136 = load ptr, ptr %l97, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %t136, i8 32)
  br label %bb35
bb35:
  %t137 = load ptr, ptr @__olang_prog_scope
  %t138 = call %"std/prelude/list:List<std/prelude/text:String&>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t137)
  store %"std/prelude/list:List<std/prelude/text:String&>" %t138, ptr %l98
  br label %bb36
bb36:
  %t139 = load %"std/prelude/list:List<std/prelude/text:String&>", ptr %l98
  store %"std/prelude/list:List<std/prelude/text:String&>" %t139, ptr %l13
  %t140 = load ptr, ptr @__olang_prog_scope
  %t141 = call %"std/prelude/list:List<std/prelude/text:String&>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t140)
  store %"std/prelude/list:List<std/prelude/text:String&>" %t141, ptr %l99
  br label %bb37
bb37:
  %t142 = load %"std/prelude/list:List<std/prelude/text:String&>", ptr %l99
  store %"std/prelude/list:List<std/prelude/text:String&>" %t142, ptr %l14
  %t143 = getelementptr %"compiler/scan:Tokens", ptr %l10, i32 0, i32 0
  %t144 = load { i64, ptr }, ptr %t143, !tbaa !27
  store { i64, ptr } %t144, ptr %l100, !tbaa !27
  %t145 = load { i64, ptr }, ptr %l100, !tbaa !27
  store { i64, ptr } %t145, ptr %l15, !tbaa !27
  %t146 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t146, ptr %l101, !tbaa !27
  %t147 = load { i64, ptr }, ptr %l101, !tbaa !27
  %t148 = extractvalue { i64, ptr } %t147, 0
  store i64 %t148, ptr %l102, !tbaa !24
  %t149 = load i64, ptr %l102, !tbaa !24
  store i64 %t149, ptr %l16, !tbaa !24
  store %olang.scope zeroinitializer, ptr %s8
  store i64 0, ptr %l17, !tbaa !24
  %t150 = load i64, ptr %l16, !tbaa !24
  store i64 %t150, ptr %l103, !tbaa !24
  %t151 = load i64, ptr %l103, !tbaa !24
  store i64 %t151, ptr %l18, !tbaa !24
  store i64 1, ptr %l19, !tbaa !24
  %t152 = load i64, ptr %l18, !tbaa !24
  store i64 %t152, ptr %l104, !tbaa !24
  %t153 = load i64, ptr %l17, !tbaa !24
  store i64 %t153, ptr %l105, !tbaa !24
  %t154 = load i64, ptr %l104, !tbaa !24
  %t155 = load i64, ptr %l105, !tbaa !24
  %t156 = icmp sgt i64 %t154, %t155
  store i1 %t156, ptr %l106, !tbaa !21
  %t157 = load i1, ptr %l106, !tbaa !21
  br i1 %t157, label %bb38, label %bb39
bb38:
  %t158 = load i64, ptr %l19, !tbaa !24
  store i64 %t158, ptr %l108, !tbaa !24
  %t159 = load i64, ptr %l108, !tbaa !24
  %t160 = icmp sgt i64 %t159, 0
  store i1 %t160, ptr %l109, !tbaa !21
  %t161 = load i1, ptr %l109, !tbaa !21
  br i1 %t161, label %bb40, label %bb41
bb39:
  store i64 0, ptr %l107, !tbaa !24
  br label %bb43
bb40:
  %t162 = load i64, ptr %l18, !tbaa !24
  store i64 %t162, ptr %l111, !tbaa !24
  %t163 = load i64, ptr %l17, !tbaa !24
  store i64 %t163, ptr %l112, !tbaa !24
  %t164 = load i64, ptr %l111, !tbaa !24
  %t165 = load i64, ptr %l112, !tbaa !24
  %t166 = sub i64 %t164, %t165
  store i64 %t166, ptr %l113, !tbaa !24
  %t167 = load i64, ptr %l19, !tbaa !24
  store i64 %t167, ptr %l114, !tbaa !24
  %t168 = load i64, ptr %l113, !tbaa !24
  %t169 = load i64, ptr %l114, !tbaa !24
  %t170 = add i64 %t168, %t169
  store i64 %t170, ptr %l115, !tbaa !24
  %t171 = load i64, ptr %l115, !tbaa !24
  %t172 = sub i64 %t171, 1
  store i64 %t172, ptr %l116, !tbaa !24
  %t173 = load i64, ptr %l19, !tbaa !24
  store i64 %t173, ptr %l117, !tbaa !24
  %t174 = load i64, ptr %l116, !tbaa !24
  %t175 = load i64, ptr %l117, !tbaa !24
  %t176 = sdiv i64 %t174, %t175
  store i64 %t176, ptr %l118, !tbaa !24
  %t177 = load i64, ptr %l118, !tbaa !24
  store i64 %t177, ptr %l110, !tbaa !24
  br label %bb42
bb41:
  store i64 0, ptr %l110, !tbaa !24
  br label %bb42
bb42:
  %t178 = load i64, ptr %l110, !tbaa !24
  store i64 %t178, ptr %l107, !tbaa !24
  br label %bb43
bb43:
  %t179 = load i64, ptr %l107, !tbaa !24
  store i64 %t179, ptr %l20, !tbaa !24
  store i64 0, ptr %l21, !tbaa !24
  br label %bb44
bb44:
  store %olang.scope zeroinitializer, ptr %s9
  %t180 = load i64, ptr %l21, !tbaa !24
  store i64 %t180, ptr %l119, !tbaa !24
  %t181 = load i64, ptr %l20, !tbaa !24
  store i64 %t181, ptr %l120, !tbaa !24
  %t182 = load i64, ptr %l119, !tbaa !24
  %t183 = load i64, ptr %l120, !tbaa !24
  %t184 = icmp slt i64 %t182, %t183
  store i1 %t184, ptr %l121, !tbaa !21
  %t185 = load i1, ptr %l121, !tbaa !21
  %t186 = xor i1 %t185, true
  store i1 %t186, ptr %l122, !tbaa !21
  %t187 = load i1, ptr %l122, !tbaa !21
  br i1 %t187, label %bb45, label %bb46
bb45:
  call void @__olang_scope_close(ptr %s9)
  br label %bb119
bb46:
  br label %bb47
bb47:
  %t188 = load i64, ptr %l17, !tbaa !24
  store i64 %t188, ptr %l123, !tbaa !24
  %t189 = load i64, ptr %l21, !tbaa !24
  store i64 %t189, ptr %l124, !tbaa !24
  %t190 = load i64, ptr %l19, !tbaa !24
  store i64 %t190, ptr %l125, !tbaa !24
  %t191 = load i64, ptr %l124, !tbaa !24
  %t192 = load i64, ptr %l125, !tbaa !24
  %t193 = mul i64 %t191, %t192
  store i64 %t193, ptr %l126, !tbaa !24
  %t194 = load i64, ptr %l123, !tbaa !24
  %t195 = load i64, ptr %l126, !tbaa !24
  %t196 = add i64 %t194, %t195
  store i64 %t196, ptr %l127, !tbaa !24
  %t197 = load i64, ptr %l127, !tbaa !24
  store i64 %t197, ptr %l22, !tbaa !24
  %t198 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t198, ptr %l128, !tbaa !27
  %t199 = load i64, ptr %l22, !tbaa !24
  store i64 %t199, ptr %l129, !tbaa !24
  %t200 = load i64, ptr %l129, !tbaa !24
  %t201 = getelementptr { i64, ptr }, ptr %l128, i32 0, i32 1
  %t202 = load ptr, ptr %t201, !tbaa !27
  %t203 = getelementptr %"compiler/token:Token", ptr %t202, i64 %t200
  %t204 = getelementptr %"compiler/token:Token", ptr %t203, i32 0, i32 0
  %t205 = load i32, ptr %t204
  store i32 %t205, ptr %l130
  %t206 = load i32, ptr %l130
  store i32 %t206, ptr %l23
  %t207 = load i64, ptr %l22, !tbaa !24
  store i64 %t207, ptr %l131, !tbaa !24
  %t208 = load i64, ptr %l131, !tbaa !24
  %t209 = add i64 %t208, 1
  store i64 %t209, ptr %l132, !tbaa !24
  %t210 = load i64, ptr %l16, !tbaa !24
  store i64 %t210, ptr %l133, !tbaa !24
  %t211 = load i64, ptr %l132, !tbaa !24
  %t212 = load i64, ptr %l133, !tbaa !24
  %t213 = icmp slt i64 %t211, %t212
  store i1 %t213, ptr %l134, !tbaa !21
  %t214 = load i1, ptr %l134, !tbaa !21
  br i1 %t214, label %bb48, label %bb49
bb48:
  %t215 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t215, ptr %l136, !tbaa !27
  %t216 = load i64, ptr %l22, !tbaa !24
  store i64 %t216, ptr %l137, !tbaa !24
  %t217 = load i64, ptr %l137, !tbaa !24
  %t218 = add i64 %t217, 1
  store i64 %t218, ptr %l138, !tbaa !24
  %t219 = load i64, ptr %l138, !tbaa !24
  %t220 = getelementptr { i64, ptr }, ptr %l136, i32 0, i32 1
  %t221 = load ptr, ptr %t220, !tbaa !27
  %t222 = getelementptr %"compiler/token:Token", ptr %t221, i64 %t219
  %t223 = getelementptr %"compiler/token:Token", ptr %t222, i32 0, i32 0
  %t224 = load i32, ptr %t223
  store i32 %t224, ptr %l139
  store ptr %l139, ptr %l140, !tbaa !29
  store i32 1, ptr %l141
  store ptr %l141, ptr %l142, !tbaa !29
  %t225 = load ptr, ptr %l140, !tbaa !29
  %t226 = load ptr, ptr %l142, !tbaa !29
  %t227 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t225, ptr %t226)
  store i1 %t227, ptr %l143
  br label %bb50
bb49:
  store i1 false, ptr %l135, !tbaa !21
  br label %bb51
bb50:
  %t228 = load i1, ptr %l143, !tbaa !21
  store i1 %t228, ptr %l135, !tbaa !21
  br label %bb51
bb51:
  %t229 = load i1, ptr %l135, !tbaa !21
  store i1 %t229, ptr %l24, !tbaa !21
  %t230 = load i32, ptr %l23
  store i32 %t230, ptr %l144
  store ptr %l144, ptr %l145, !tbaa !29
  store i32 33, ptr %l146
  store ptr %l146, ptr %l147, !tbaa !29
  %t231 = load ptr, ptr %l145, !tbaa !29
  %t232 = load ptr, ptr %l147, !tbaa !29
  %t233 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t231, ptr %t232)
  store i1 %t233, ptr %l148
  br label %bb52
bb52:
  %t234 = load i1, ptr %l148, !tbaa !21
  br i1 %t234, label %bb53, label %bb54
bb53:
  %t235 = load i1, ptr %l24, !tbaa !21
  store i1 %t235, ptr %l150, !tbaa !21
  %t236 = load i1, ptr %l150, !tbaa !21
  store i1 %t236, ptr %l149, !tbaa !21
  br label %bb55
bb54:
  store i1 false, ptr %l149, !tbaa !21
  br label %bb55
bb55:
  %t237 = load i1, ptr %l149, !tbaa !21
  br i1 %t237, label %bb56, label %bb57
bb56:
  store i1 true, ptr %l151, !tbaa !21
  br label %bb69
bb57:
  %t238 = load i32, ptr %l23
  store i32 %t238, ptr %l152
  store ptr %l152, ptr %l153, !tbaa !29
  store i32 38, ptr %l154
  store ptr %l154, ptr %l155, !tbaa !29
  %t239 = load ptr, ptr %l153, !tbaa !29
  %t240 = load ptr, ptr %l155, !tbaa !29
  %t241 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t239, ptr %t240)
  store i1 %t241, ptr %l156
  br label %bb58
bb58:
  %t242 = load i1, ptr %l156, !tbaa !21
  br i1 %t242, label %bb59, label %bb60
bb59:
  %t243 = load i1, ptr %l24, !tbaa !21
  store i1 %t243, ptr %l158, !tbaa !21
  %t244 = load i1, ptr %l158, !tbaa !21
  store i1 %t244, ptr %l157, !tbaa !21
  br label %bb61
bb60:
  store i1 false, ptr %l157, !tbaa !21
  br label %bb61
bb61:
  %t245 = load i1, ptr %l157, !tbaa !21
  br i1 %t245, label %bb62, label %bb63
bb62:
  %t246 = load i64, ptr %l22, !tbaa !24
  store i64 %t246, ptr %l160, !tbaa !24
  %t247 = load i64, ptr %l160, !tbaa !24
  %t248 = add i64 %t247, 2
  store i64 %t248, ptr %l161, !tbaa !24
  %t249 = load i64, ptr %l16, !tbaa !24
  store i64 %t249, ptr %l162, !tbaa !24
  %t250 = load i64, ptr %l161, !tbaa !24
  %t251 = load i64, ptr %l162, !tbaa !24
  %t252 = icmp slt i64 %t250, %t251
  store i1 %t252, ptr %l163, !tbaa !21
  %t253 = load i1, ptr %l163, !tbaa !21
  store i1 %t253, ptr %l159, !tbaa !21
  br label %bb64
bb63:
  store i1 false, ptr %l159, !tbaa !21
  br label %bb64
bb64:
  %t254 = load i1, ptr %l159, !tbaa !21
  br i1 %t254, label %bb65, label %bb66
bb65:
  %t255 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t255, ptr %l165, !tbaa !27
  %t256 = load i64, ptr %l22, !tbaa !24
  store i64 %t256, ptr %l166, !tbaa !24
  %t257 = load i64, ptr %l166, !tbaa !24
  %t258 = add i64 %t257, 2
  store i64 %t258, ptr %l167, !tbaa !24
  %t259 = load i64, ptr %l167, !tbaa !24
  %t260 = getelementptr { i64, ptr }, ptr %l165, i32 0, i32 1
  %t261 = load ptr, ptr %t260, !tbaa !27
  %t262 = getelementptr %"compiler/token:Token", ptr %t261, i64 %t259
  %t263 = getelementptr %"compiler/token:Token", ptr %t262, i32 0, i32 0
  %t264 = load i32, ptr %t263
  store i32 %t264, ptr %l168
  store ptr %l168, ptr %l169, !tbaa !29
  store i32 94, ptr %l170
  store ptr %l170, ptr %l171, !tbaa !29
  %t265 = load ptr, ptr %l169, !tbaa !29
  %t266 = load ptr, ptr %l171, !tbaa !29
  %t267 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t265, ptr %t266)
  store i1 %t267, ptr %l172
  br label %bb67
bb66:
  store i1 false, ptr %l164, !tbaa !21
  br label %bb68
bb67:
  %t268 = load i1, ptr %l172, !tbaa !21
  store i1 %t268, ptr %l164, !tbaa !21
  br label %bb68
bb68:
  %t269 = load i1, ptr %l164, !tbaa !21
  store i1 %t269, ptr %l151, !tbaa !21
  br label %bb69
bb69:
  %t270 = load i1, ptr %l151, !tbaa !21
  br i1 %t270, label %bb70, label %bb71
bb70:
  store %olang.scope zeroinitializer, ptr %s10
  store ptr %l12, ptr %l173, !tbaa !29
  %t271 = getelementptr %"compiler/source:Source", ptr %l9, i32 0, i32 1
  %t272 = load { i64, ptr }, ptr %t271, !tbaa !27
  store { i64, ptr } %t272, ptr %l174, !tbaa !27
  %t273 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t273, ptr %l175, !tbaa !27
  %t274 = load i64, ptr %l22, !tbaa !24
  store i64 %t274, ptr %l176, !tbaa !24
  %t275 = load i64, ptr %l176, !tbaa !24
  %t276 = add i64 %t275, 1
  store i64 %t276, ptr %l177, !tbaa !24
  %t277 = load i64, ptr %l177, !tbaa !24
  %t278 = getelementptr { i64, ptr }, ptr %l175, i32 0, i32 1
  %t279 = load ptr, ptr %t278, !tbaa !27
  %t280 = getelementptr %"compiler/token:Token", ptr %t279, i64 %t277
  %t281 = getelementptr %"compiler/token:Token", ptr %t280, i32 0, i32 2
  %t282 = load i32, ptr %t281, !tbaa !23
  store i32 %t282, ptr %l178, !tbaa !23
  %t283 = load i32, ptr %l178, !tbaa !23
  %t284 = sext i32 %t283 to i64
  store i64 %t284, ptr %l179, !tbaa !24
  %t285 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t285, ptr %l180, !tbaa !27
  %t286 = load i64, ptr %l22, !tbaa !24
  store i64 %t286, ptr %l181, !tbaa !24
  %t287 = load i64, ptr %l181, !tbaa !24
  %t288 = add i64 %t287, 1
  store i64 %t288, ptr %l182, !tbaa !24
  %t289 = load i64, ptr %l182, !tbaa !24
  %t290 = getelementptr { i64, ptr }, ptr %l180, i32 0, i32 1
  %t291 = load ptr, ptr %t290, !tbaa !27
  %t292 = getelementptr %"compiler/token:Token", ptr %t291, i64 %t289
  %t293 = getelementptr %"compiler/token:Token", ptr %t292, i32 0, i32 3
  %t294 = load i32, ptr %t293, !tbaa !23
  store i32 %t294, ptr %l183, !tbaa !23
  %t295 = load i32, ptr %l183, !tbaa !23
  %t296 = sext i32 %t295 to i64
  store i64 %t296, ptr %l184, !tbaa !24
  %t297 = load { i64, ptr }, ptr %l174, !tbaa !27
  %t298 = extractvalue { i64, ptr } %t297, 0
  store i64 %t298, ptr %l185, !tbaa !24
  %t299 = load i64, ptr %l179, !tbaa !24
  %t300 = icmp sge i64 %t299, 0
  store i1 %t300, ptr %l186, !tbaa !21
  %t301 = load i1, ptr %l186, !tbaa !21
  br i1 %t301, label %bb72, label %bb73
bb71:
  br label %bb80
bb72:
  %t302 = load i64, ptr %l179, !tbaa !24
  %t303 = load i64, ptr %l184, !tbaa !24
  %t304 = icmp sle i64 %t302, %t303
  store i1 %t304, ptr %l187, !tbaa !21
  %t305 = load i1, ptr %l187, !tbaa !21
  br i1 %t305, label %bb74, label %bb75
bb73:
  call void @__olang_check_failed(ptr @.c52)
  unreachable
bb74:
  %t306 = load i64, ptr %l184, !tbaa !24
  %t307 = load i64, ptr %l185, !tbaa !24
  %t308 = icmp sle i64 %t306, %t307
  store i1 %t308, ptr %l188, !tbaa !21
  %t309 = load i1, ptr %l188, !tbaa !21
  br i1 %t309, label %bb76, label %bb77
bb75:
  call void @__olang_check_failed(ptr @.c52)
  unreachable
bb76:
  %t310 = getelementptr { i64, ptr }, ptr %l174, i32 0, i32 1
  %t311 = load ptr, ptr %t310, !tbaa !27
  %t312 = load i64, ptr %l179, !tbaa !24
  %t313 = load i64, ptr %l184, !tbaa !24
  %t314 = getelementptr i8, ptr %t311, i64 %t312
  %t315 = sub i64 %t313, %t312
  %t316 = insertvalue { i64, ptr } undef, i64 %t315, 0
  %t317 = insertvalue { i64, ptr } %t316, ptr %t314, 1
  store { i64, ptr } %t317, ptr %l189, !tbaa !27
  %t318 = load ptr, ptr %l173, !tbaa !29
  %t319 = load { i64, ptr }, ptr %l189, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t318, { i64, ptr } %t319)
  br label %bb78
bb77:
  call void @__olang_check_failed(ptr @.c52)
  unreachable
bb78:
  store ptr %l12, ptr %l190, !tbaa !29
  %t320 = load ptr, ptr %l190, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %t320, i8 32)
  br label %bb79
bb79:
  call void @__olang_scope_close(ptr %s10)
  br label %bb80
bb80:
  %t321 = load i32, ptr %l23
  store i32 %t321, ptr %l191
  store ptr %l191, ptr %l192, !tbaa !29
  store i32 42, ptr %l193
  store ptr %l193, ptr %l194, !tbaa !29
  %t322 = load ptr, ptr %l192, !tbaa !29
  %t323 = load ptr, ptr %l194, !tbaa !29
  %t324 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t322, ptr %t323)
  store i1 %t324, ptr %l195
  br label %bb81
bb81:
  %t325 = load i1, ptr %l195, !tbaa !21
  br i1 %t325, label %bb82, label %bb83
bb82:
  store %olang.scope zeroinitializer, ptr %s11
  %t326 = load i64, ptr %l22, !tbaa !24
  store i64 %t326, ptr %l196, !tbaa !24
  %t327 = load i64, ptr %l196, !tbaa !24
  %t328 = add i64 %t327, 1
  store i64 %t328, ptr %l197, !tbaa !24
  %t329 = load i64, ptr %l197, !tbaa !24
  store i64 %t329, ptr %l25, !tbaa !24
  store { i64, ptr } { i64 0, ptr @.d53 }, ptr %l26, !tbaa !27
  %t330 = load i64, ptr %l25, !tbaa !24
  store i64 %t330, ptr %l198, !tbaa !24
  %t331 = load i64, ptr %l16, !tbaa !24
  store i64 %t331, ptr %l199, !tbaa !24
  %t332 = load i64, ptr %l198, !tbaa !24
  %t333 = load i64, ptr %l199, !tbaa !24
  %t334 = icmp slt i64 %t332, %t333
  store i1 %t334, ptr %l200, !tbaa !21
  %t335 = load i1, ptr %l200, !tbaa !21
  br i1 %t335, label %bb84, label %bb85
bb83:
  br label %bb117
bb84:
  %t336 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t336, ptr %l202, !tbaa !27
  %t337 = load i64, ptr %l25, !tbaa !24
  store i64 %t337, ptr %l203, !tbaa !24
  %t338 = load i64, ptr %l203, !tbaa !24
  %t339 = getelementptr { i64, ptr }, ptr %l202, i32 0, i32 1
  %t340 = load ptr, ptr %t339, !tbaa !27
  %t341 = getelementptr %"compiler/token:Token", ptr %t340, i64 %t338
  %t342 = getelementptr %"compiler/token:Token", ptr %t341, i32 0, i32 0
  %t343 = load i32, ptr %t342
  store i32 %t343, ptr %l204
  store ptr %l204, ptr %l205, !tbaa !29
  store i32 1, ptr %l206
  store ptr %l206, ptr %l207, !tbaa !29
  %t344 = load ptr, ptr %l205, !tbaa !29
  %t345 = load ptr, ptr %l207, !tbaa !29
  %t346 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t344, ptr %t345)
  store i1 %t346, ptr %l208
  br label %bb86
bb85:
  store i1 false, ptr %l201, !tbaa !21
  br label %bb87
bb86:
  %t347 = load i1, ptr %l208, !tbaa !21
  store i1 %t347, ptr %l201, !tbaa !21
  br label %bb87
bb87:
  %t348 = load i1, ptr %l201, !tbaa !21
  br i1 %t348, label %bb88, label %bb89
bb88:
  store %olang.scope zeroinitializer, ptr %s12
  %t349 = getelementptr %"compiler/source:Source", ptr %l9, i32 0, i32 1
  %t350 = load { i64, ptr }, ptr %t349, !tbaa !27
  store { i64, ptr } %t350, ptr %l209, !tbaa !27
  %t351 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t351, ptr %l210, !tbaa !27
  %t352 = load i64, ptr %l25, !tbaa !24
  store i64 %t352, ptr %l211, !tbaa !24
  %t353 = load i64, ptr %l211, !tbaa !24
  %t354 = getelementptr { i64, ptr }, ptr %l210, i32 0, i32 1
  %t355 = load ptr, ptr %t354, !tbaa !27
  %t356 = getelementptr %"compiler/token:Token", ptr %t355, i64 %t353
  %t357 = getelementptr %"compiler/token:Token", ptr %t356, i32 0, i32 2
  %t358 = load i32, ptr %t357, !tbaa !23
  store i32 %t358, ptr %l212, !tbaa !23
  %t359 = load i32, ptr %l212, !tbaa !23
  %t360 = sext i32 %t359 to i64
  store i64 %t360, ptr %l213, !tbaa !24
  %t361 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t361, ptr %l214, !tbaa !27
  %t362 = load i64, ptr %l25, !tbaa !24
  store i64 %t362, ptr %l215, !tbaa !24
  %t363 = load i64, ptr %l215, !tbaa !24
  %t364 = getelementptr { i64, ptr }, ptr %l214, i32 0, i32 1
  %t365 = load ptr, ptr %t364, !tbaa !27
  %t366 = getelementptr %"compiler/token:Token", ptr %t365, i64 %t363
  %t367 = getelementptr %"compiler/token:Token", ptr %t366, i32 0, i32 3
  %t368 = load i32, ptr %t367, !tbaa !23
  store i32 %t368, ptr %l216, !tbaa !23
  %t369 = load i32, ptr %l216, !tbaa !23
  %t370 = sext i32 %t369 to i64
  store i64 %t370, ptr %l217, !tbaa !24
  %t371 = load { i64, ptr }, ptr %l209, !tbaa !27
  %t372 = extractvalue { i64, ptr } %t371, 0
  store i64 %t372, ptr %l218, !tbaa !24
  %t373 = load i64, ptr %l213, !tbaa !24
  %t374 = icmp sge i64 %t373, 0
  store i1 %t374, ptr %l219, !tbaa !21
  %t375 = load i1, ptr %l219, !tbaa !21
  br i1 %t375, label %bb90, label %bb91
bb89:
  br label %bb96
bb90:
  %t376 = load i64, ptr %l213, !tbaa !24
  %t377 = load i64, ptr %l217, !tbaa !24
  %t378 = icmp sle i64 %t376, %t377
  store i1 %t378, ptr %l220, !tbaa !21
  %t379 = load i1, ptr %l220, !tbaa !21
  br i1 %t379, label %bb92, label %bb93
bb91:
  call void @__olang_check_failed(ptr @.c54)
  unreachable
bb92:
  %t380 = load i64, ptr %l217, !tbaa !24
  %t381 = load i64, ptr %l218, !tbaa !24
  %t382 = icmp sle i64 %t380, %t381
  store i1 %t382, ptr %l221, !tbaa !21
  %t383 = load i1, ptr %l221, !tbaa !21
  br i1 %t383, label %bb94, label %bb95
bb93:
  call void @__olang_check_failed(ptr @.c54)
  unreachable
bb94:
  %t384 = getelementptr { i64, ptr }, ptr %l209, i32 0, i32 1
  %t385 = load ptr, ptr %t384, !tbaa !27
  %t386 = load i64, ptr %l213, !tbaa !24
  %t387 = load i64, ptr %l217, !tbaa !24
  %t388 = getelementptr i8, ptr %t385, i64 %t386
  %t389 = sub i64 %t387, %t386
  %t390 = insertvalue { i64, ptr } undef, i64 %t389, 0
  %t391 = insertvalue { i64, ptr } %t390, ptr %t388, 1
  store { i64, ptr } %t391, ptr %l222, !tbaa !27
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s13
  store ptr %s13room, ptr %s13
  %t392 = load { i64, ptr }, ptr %l222, !tbaa !27
  %t393 = extractvalue { i64, ptr } %t392, 1
  %t394 = extractvalue { i64, ptr } %t392, 0
  call void @__olang_sb_put(ptr %s13, ptr %t393, i64 %t394)
  %t395 = load ptr, ptr %s13
  %t396 = getelementptr %olang.builder, ptr %s13, i32 0, i32 1
  %t397 = load i64, ptr %t396
  %t398 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t397)
  call void @llvm.memcpy.p0.p0.i64(ptr %t398, ptr %t395, i64 %t397, i1 false)
  %t399 = insertvalue { i64, ptr } undef, i64 %t397, 0
  %t400 = insertvalue { i64, ptr } %t399, ptr %t398, 1
  store { i64, ptr } %t400, ptr %l223, !tbaa !27
  call void @__olang_sb_done(ptr %s13)
  %t401 = load { i64, ptr }, ptr %l223, !tbaa !27
  %t402 = extractvalue { i64, ptr } %t401, 0
  %t403 = extractvalue { i64, ptr } %t401, 1
  %t404 = mul i64 %t402, 1
  %t405 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t404)
  call void @llvm.memcpy.p0.p0.i64(ptr %t405, ptr %t403, i64 %t404, i1 false)
  %t406 = insertvalue { i64, ptr } undef, i64 %t402, 0
  %t407 = insertvalue { i64, ptr } %t406, ptr %t405, 1
  store { i64, ptr } %t407, ptr %l224, !tbaa !27
  %t408 = load { i64, ptr }, ptr %l224, !tbaa !27
  store { i64, ptr } %t408, ptr %l26, !tbaa !27
  %t409 = load i64, ptr %l25, !tbaa !24
  store i64 %t409, ptr %l225, !tbaa !24
  %t410 = load i64, ptr %l225, !tbaa !24
  %t411 = add i64 %t410, 1
  store i64 %t411, ptr %l226, !tbaa !24
  %t412 = load i64, ptr %l226, !tbaa !24
  store i64 %t412, ptr %l25, !tbaa !24
  call void @__olang_scope_close(ptr %s12)
  br label %bb96
bb95:
  call void @__olang_check_failed(ptr @.c54)
  unreachable
bb96:
  %t413 = load i64, ptr %l25, !tbaa !24
  store i64 %t413, ptr %l227, !tbaa !24
  %t414 = load i64, ptr %l16, !tbaa !24
  store i64 %t414, ptr %l228, !tbaa !24
  %t415 = load i64, ptr %l227, !tbaa !24
  %t416 = load i64, ptr %l228, !tbaa !24
  %t417 = icmp slt i64 %t415, %t416
  store i1 %t417, ptr %l229, !tbaa !21
  %t418 = load i1, ptr %l229, !tbaa !21
  br i1 %t418, label %bb97, label %bb98
bb97:
  %t419 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t419, ptr %l231, !tbaa !27
  %t420 = load i64, ptr %l25, !tbaa !24
  store i64 %t420, ptr %l232, !tbaa !24
  %t421 = load i64, ptr %l232, !tbaa !24
  %t422 = getelementptr { i64, ptr }, ptr %l231, i32 0, i32 1
  %t423 = load ptr, ptr %t422, !tbaa !27
  %t424 = getelementptr %"compiler/token:Token", ptr %t423, i64 %t421
  %t425 = getelementptr %"compiler/token:Token", ptr %t424, i32 0, i32 0
  %t426 = load i32, ptr %t425
  store i32 %t426, ptr %l233
  store ptr %l233, ptr %l234, !tbaa !29
  store i32 5, ptr %l235
  store ptr %l235, ptr %l236, !tbaa !29
  %t427 = load ptr, ptr %l234, !tbaa !29
  %t428 = load ptr, ptr %l236, !tbaa !29
  %t429 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t427, ptr %t428)
  store i1 %t429, ptr %l237
  br label %bb99
bb98:
  store i1 false, ptr %l230, !tbaa !21
  br label %bb100
bb99:
  %t430 = load i1, ptr %l237, !tbaa !21
  store i1 %t430, ptr %l230, !tbaa !21
  br label %bb100
bb100:
  %t431 = load i1, ptr %l230, !tbaa !21
  br i1 %t431, label %bb101, label %bb102
bb101:
  store %olang.scope zeroinitializer, ptr %s14
  %t432 = getelementptr %"compiler/source:Source", ptr %l9, i32 0, i32 1
  %t433 = load { i64, ptr }, ptr %t432, !tbaa !27
  store { i64, ptr } %t433, ptr %l238, !tbaa !27
  %t434 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t434, ptr %l239, !tbaa !27
  %t435 = load i64, ptr %l25, !tbaa !24
  store i64 %t435, ptr %l240, !tbaa !24
  %t436 = load i64, ptr %l240, !tbaa !24
  %t437 = getelementptr { i64, ptr }, ptr %l239, i32 0, i32 1
  %t438 = load ptr, ptr %t437, !tbaa !27
  %t439 = getelementptr %"compiler/token:Token", ptr %t438, i64 %t436
  %t440 = getelementptr %"compiler/token:Token", ptr %t439, i32 0, i32 2
  %t441 = load i32, ptr %t440, !tbaa !23
  store i32 %t441, ptr %l241, !tbaa !23
  %t442 = load i32, ptr %l241, !tbaa !23
  %t443 = add i32 %t442, 1
  store i32 %t443, ptr %l242, !tbaa !23
  %t444 = load i32, ptr %l242, !tbaa !23
  %t445 = sext i32 %t444 to i64
  store i64 %t445, ptr %l243, !tbaa !24
  %t446 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t446, ptr %l244, !tbaa !27
  %t447 = load i64, ptr %l25, !tbaa !24
  store i64 %t447, ptr %l245, !tbaa !24
  %t448 = load i64, ptr %l245, !tbaa !24
  %t449 = getelementptr { i64, ptr }, ptr %l244, i32 0, i32 1
  %t450 = load ptr, ptr %t449, !tbaa !27
  %t451 = getelementptr %"compiler/token:Token", ptr %t450, i64 %t448
  %t452 = getelementptr %"compiler/token:Token", ptr %t451, i32 0, i32 3
  %t453 = load i32, ptr %t452, !tbaa !23
  store i32 %t453, ptr %l246, !tbaa !23
  %t454 = load i32, ptr %l246, !tbaa !23
  %t455 = sub i32 %t454, 1
  store i32 %t455, ptr %l247, !tbaa !23
  %t456 = load i32, ptr %l247, !tbaa !23
  %t457 = sext i32 %t456 to i64
  store i64 %t457, ptr %l248, !tbaa !24
  %t458 = load { i64, ptr }, ptr %l238, !tbaa !27
  %t459 = extractvalue { i64, ptr } %t458, 0
  store i64 %t459, ptr %l249, !tbaa !24
  %t460 = load i64, ptr %l243, !tbaa !24
  %t461 = icmp sge i64 %t460, 0
  store i1 %t461, ptr %l250, !tbaa !21
  %t462 = load i1, ptr %l250, !tbaa !21
  br i1 %t462, label %bb103, label %bb104
bb102:
  br label %bb116
bb103:
  %t463 = load i64, ptr %l243, !tbaa !24
  %t464 = load i64, ptr %l248, !tbaa !24
  %t465 = icmp sle i64 %t463, %t464
  store i1 %t465, ptr %l251, !tbaa !21
  %t466 = load i1, ptr %l251, !tbaa !21
  br i1 %t466, label %bb105, label %bb106
bb104:
  call void @__olang_check_failed(ptr @.c55)
  unreachable
bb105:
  %t467 = load i64, ptr %l248, !tbaa !24
  %t468 = load i64, ptr %l249, !tbaa !24
  %t469 = icmp sle i64 %t467, %t468
  store i1 %t469, ptr %l252, !tbaa !21
  %t470 = load i1, ptr %l252, !tbaa !21
  br i1 %t470, label %bb107, label %bb108
bb106:
  call void @__olang_check_failed(ptr @.c55)
  unreachable
bb107:
  %t471 = getelementptr { i64, ptr }, ptr %l238, i32 0, i32 1
  %t472 = load ptr, ptr %t471, !tbaa !27
  %t473 = load i64, ptr %l243, !tbaa !24
  %t474 = load i64, ptr %l248, !tbaa !24
  %t475 = getelementptr i8, ptr %t472, i64 %t473
  %t476 = sub i64 %t474, %t473
  %t477 = insertvalue { i64, ptr } undef, i64 %t476, 0
  %t478 = insertvalue { i64, ptr } %t477, ptr %t475, 1
  store { i64, ptr } %t478, ptr %l253, !tbaa !27
  %t479 = load { i64, ptr }, ptr %l253, !tbaa !27
  store { i64, ptr } %t479, ptr %l27, !tbaa !27
  %t480 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t480, ptr %l254, !tbaa !27
  %t481 = load { i64, ptr }, ptr %l254, !tbaa !27
  %t482 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s11, ptr %s14, { i64, ptr } %t481, { i64, ptr } { i64 0, ptr @.d56 })
  store i1 %t482, ptr %l255
  br label %bb109
bb108:
  call void @__olang_check_failed(ptr @.c55)
  unreachable
bb109:
  %t483 = load i1, ptr %l255, !tbaa !21
  br i1 %t483, label %bb110, label %bb111
bb110:
  store %olang.scope zeroinitializer, ptr %s15
  %t484 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t484, ptr %l256, !tbaa !27
  %t485 = load { i64, ptr }, ptr %l256, !tbaa !27
  %t486 = call { i64, ptr } @std_2ffilepath_2eBase(ptr %s0, { i64, ptr } %t485)
  store { i64, ptr } %t486, ptr %l257
  br label %bb112
bb111:
  br label %bb113
bb112:
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s16
  store ptr %s16room, ptr %s16
  %t487 = load { i64, ptr }, ptr %l257, !tbaa !27
  %t488 = extractvalue { i64, ptr } %t487, 1
  %t489 = extractvalue { i64, ptr } %t487, 0
  call void @__olang_sb_put(ptr %s16, ptr %t488, i64 %t489)
  %t490 = load ptr, ptr %s16
  %t491 = getelementptr %olang.builder, ptr %s16, i32 0, i32 1
  %t492 = load i64, ptr %t491
  %t493 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t492)
  call void @llvm.memcpy.p0.p0.i64(ptr %t493, ptr %t490, i64 %t492, i1 false)
  %t494 = insertvalue { i64, ptr } undef, i64 %t492, 0
  %t495 = insertvalue { i64, ptr } %t494, ptr %t493, 1
  store { i64, ptr } %t495, ptr %l258, !tbaa !27
  call void @__olang_sb_done(ptr %s16)
  %t496 = load { i64, ptr }, ptr %l258, !tbaa !27
  %t497 = extractvalue { i64, ptr } %t496, 0
  %t498 = extractvalue { i64, ptr } %t496, 1
  %t499 = mul i64 %t497, 1
  %t500 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t499)
  call void @llvm.memcpy.p0.p0.i64(ptr %t500, ptr %t498, i64 %t499, i1 false)
  %t501 = insertvalue { i64, ptr } undef, i64 %t497, 0
  %t502 = insertvalue { i64, ptr } %t501, ptr %t500, 1
  store { i64, ptr } %t502, ptr %l259, !tbaa !27
  %t503 = load { i64, ptr }, ptr %l259, !tbaa !27
  store { i64, ptr } %t503, ptr %l26, !tbaa !27
  call void @__olang_scope_close(ptr %s15)
  br label %bb113
bb113:
  store ptr %l13, ptr %l260, !tbaa !29
  %t504 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t504, ptr %l261, !tbaa !27
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s17
  store ptr %s17room, ptr %s17
  %t505 = load { i64, ptr }, ptr %l261, !tbaa !27
  %t506 = extractvalue { i64, ptr } %t505, 1
  %t507 = extractvalue { i64, ptr } %t505, 0
  call void @__olang_sb_put(ptr %s17, ptr %t506, i64 %t507)
  %t508 = load ptr, ptr %s17
  %t509 = getelementptr %olang.builder, ptr %s17, i32 0, i32 1
  %t510 = load i64, ptr %t509
  %t511 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t510)
  call void @llvm.memcpy.p0.p0.i64(ptr %t511, ptr %t508, i64 %t510, i1 false)
  %t512 = insertvalue { i64, ptr } undef, i64 %t510, 0
  %t513 = insertvalue { i64, ptr } %t512, ptr %t511, 1
  store { i64, ptr } %t513, ptr %l262, !tbaa !27
  call void @__olang_sb_done(ptr %s17)
  %t514 = load { i64, ptr }, ptr %l262, !tbaa !27
  %t515 = extractvalue { i64, ptr } %t514, 0
  %t516 = extractvalue { i64, ptr } %t514, 1
  %t517 = mul i64 %t515, 1
  %t518 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t517)
  call void @llvm.memcpy.p0.p0.i64(ptr %t518, ptr %t516, i64 %t517, i1 false)
  %t519 = insertvalue { i64, ptr } undef, i64 %t515, 0
  %t520 = insertvalue { i64, ptr } %t519, ptr %t518, 1
  store { i64, ptr } %t520, ptr %l263, !tbaa !27
  %t521 = load ptr, ptr %l260, !tbaa !29
  %t522 = load { i64, ptr }, ptr %l263, !tbaa !27
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %s0, ptr %t521, { i64, ptr } %t522)
  br label %bb114
bb114:
  store ptr %l14, ptr %l264, !tbaa !29
  %t523 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t523, ptr %l265, !tbaa !27
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s18
  store ptr %s18room, ptr %s18
  %t524 = load { i64, ptr }, ptr %l265, !tbaa !27
  %t525 = extractvalue { i64, ptr } %t524, 1
  %t526 = extractvalue { i64, ptr } %t524, 0
  call void @__olang_sb_put(ptr %s18, ptr %t525, i64 %t526)
  %t527 = load ptr, ptr %s18
  %t528 = getelementptr %olang.builder, ptr %s18, i32 0, i32 1
  %t529 = load i64, ptr %t528
  %t530 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t529)
  call void @llvm.memcpy.p0.p0.i64(ptr %t530, ptr %t527, i64 %t529, i1 false)
  %t531 = insertvalue { i64, ptr } undef, i64 %t529, 0
  %t532 = insertvalue { i64, ptr } %t531, ptr %t530, 1
  store { i64, ptr } %t532, ptr %l266, !tbaa !27
  call void @__olang_sb_done(ptr %s18)
  %t533 = load { i64, ptr }, ptr %l266, !tbaa !27
  %t534 = extractvalue { i64, ptr } %t533, 0
  %t535 = extractvalue { i64, ptr } %t533, 1
  %t536 = mul i64 %t534, 1
  %t537 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t536)
  call void @llvm.memcpy.p0.p0.i64(ptr %t537, ptr %t535, i64 %t536, i1 false)
  %t538 = insertvalue { i64, ptr } undef, i64 %t534, 0
  %t539 = insertvalue { i64, ptr } %t538, ptr %t537, 1
  store { i64, ptr } %t539, ptr %l267, !tbaa !27
  %t540 = load ptr, ptr %l264, !tbaa !29
  %t541 = load { i64, ptr }, ptr %l267, !tbaa !27
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %s0, ptr %t540, { i64, ptr } %t541)
  br label %bb115
bb115:
  call void @__olang_scope_close(ptr %s14)
  br label %bb116
bb116:
  call void @__olang_scope_close(ptr %s11)
  br label %bb117
bb117:
  call void @__olang_scope_close(ptr %s9)
  br label %bb118
bb118:
  store %olang.scope zeroinitializer, ptr %s19
  %t542 = load i64, ptr %l21, !tbaa !24
  store i64 %t542, ptr %l268, !tbaa !24
  %t543 = load i64, ptr %l268, !tbaa !24
  %t544 = add i64 %t543, 1
  store i64 %t544, ptr %l269, !tbaa !24
  %t545 = load i64, ptr %l269, !tbaa !24
  store i64 %t545, ptr %l21, !tbaa !24
  call void @__olang_scope_close(ptr %s19)
  br label %bb44
bb119:
  call void @__olang_scope_close(ptr %s8)
  %t546 = load ptr, ptr %l0, !tbaa !29
  store ptr %t546, ptr %l270, !tbaa !29
  %t547 = load ptr, ptr %l270, !tbaa !29
  %t548 = getelementptr %"compiler/fmt:loader", ptr %t547, i32 0, i32 2
  store ptr %t548, ptr %l271, !tbaa !29
  store ptr %l12, ptr %l272, !tbaa !29
  %t549 = load ptr, ptr %l272, !tbaa !29
  %t550 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v0, ptr %t549)
  store { i64, ptr } %t550, ptr %l273
  br label %bb120
bb120:
  %t551 = load ptr, ptr %l271, !tbaa !29
  %t552 = load { i64, ptr }, ptr %l273, !tbaa !27
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v0, ptr %v0, ptr %t551, { i64, ptr } %t552)
  br label %bb121
bb121:
  store %olang.scope zeroinitializer, ptr %s20
  store i64 0, ptr %l28, !tbaa !24
  store ptr %l13, ptr %l274, !tbaa !29
  %t553 = load ptr, ptr %l274, !tbaa !29
  %t554 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %s0, ptr %t553)
  store i64 %t554, ptr %l275
  br label %bb122
bb122:
  %t555 = load i64, ptr %l275, !tbaa !24
  store i64 %t555, ptr %l29, !tbaa !24
  store i64 1, ptr %l30, !tbaa !24
  %t556 = load i64, ptr %l29, !tbaa !24
  store i64 %t556, ptr %l276, !tbaa !24
  %t557 = load i64, ptr %l28, !tbaa !24
  store i64 %t557, ptr %l277, !tbaa !24
  %t558 = load i64, ptr %l276, !tbaa !24
  %t559 = load i64, ptr %l277, !tbaa !24
  %t560 = icmp sgt i64 %t558, %t559
  store i1 %t560, ptr %l278, !tbaa !21
  %t561 = load i1, ptr %l278, !tbaa !21
  br i1 %t561, label %bb123, label %bb124
bb123:
  %t562 = load i64, ptr %l30, !tbaa !24
  store i64 %t562, ptr %l280, !tbaa !24
  %t563 = load i64, ptr %l280, !tbaa !24
  %t564 = icmp sgt i64 %t563, 0
  store i1 %t564, ptr %l281, !tbaa !21
  %t565 = load i1, ptr %l281, !tbaa !21
  br i1 %t565, label %bb125, label %bb126
bb124:
  store i64 0, ptr %l279, !tbaa !24
  br label %bb128
bb125:
  %t566 = load i64, ptr %l29, !tbaa !24
  store i64 %t566, ptr %l283, !tbaa !24
  %t567 = load i64, ptr %l28, !tbaa !24
  store i64 %t567, ptr %l284, !tbaa !24
  %t568 = load i64, ptr %l283, !tbaa !24
  %t569 = load i64, ptr %l284, !tbaa !24
  %t570 = sub i64 %t568, %t569
  store i64 %t570, ptr %l285, !tbaa !24
  %t571 = load i64, ptr %l30, !tbaa !24
  store i64 %t571, ptr %l286, !tbaa !24
  %t572 = load i64, ptr %l285, !tbaa !24
  %t573 = load i64, ptr %l286, !tbaa !24
  %t574 = add i64 %t572, %t573
  store i64 %t574, ptr %l287, !tbaa !24
  %t575 = load i64, ptr %l287, !tbaa !24
  %t576 = sub i64 %t575, 1
  store i64 %t576, ptr %l288, !tbaa !24
  %t577 = load i64, ptr %l30, !tbaa !24
  store i64 %t577, ptr %l289, !tbaa !24
  %t578 = load i64, ptr %l288, !tbaa !24
  %t579 = load i64, ptr %l289, !tbaa !24
  %t580 = sdiv i64 %t578, %t579
  store i64 %t580, ptr %l290, !tbaa !24
  %t581 = load i64, ptr %l290, !tbaa !24
  store i64 %t581, ptr %l282, !tbaa !24
  br label %bb127
bb126:
  store i64 0, ptr %l282, !tbaa !24
  br label %bb127
bb127:
  %t582 = load i64, ptr %l282, !tbaa !24
  store i64 %t582, ptr %l279, !tbaa !24
  br label %bb128
bb128:
  %t583 = load i64, ptr %l279, !tbaa !24
  store i64 %t583, ptr %l31, !tbaa !24
  store i64 0, ptr %l32, !tbaa !24
  br label %bb129
bb129:
  store %olang.scope zeroinitializer, ptr %s21
  %t584 = load i64, ptr %l32, !tbaa !24
  store i64 %t584, ptr %l291, !tbaa !24
  %t585 = load i64, ptr %l31, !tbaa !24
  store i64 %t585, ptr %l292, !tbaa !24
  %t586 = load i64, ptr %l291, !tbaa !24
  %t587 = load i64, ptr %l292, !tbaa !24
  %t588 = icmp slt i64 %t586, %t587
  store i1 %t588, ptr %l293, !tbaa !21
  %t589 = load i1, ptr %l293, !tbaa !21
  %t590 = xor i1 %t589, true
  store i1 %t590, ptr %l294, !tbaa !21
  %t591 = load i1, ptr %l294, !tbaa !21
  br i1 %t591, label %bb130, label %bb131
bb130:
  call void @__olang_scope_close(ptr %s21)
  br label %bb145
bb131:
  br label %bb132
bb132:
  %t592 = load i64, ptr %l28, !tbaa !24
  store i64 %t592, ptr %l295, !tbaa !24
  %t593 = load i64, ptr %l32, !tbaa !24
  store i64 %t593, ptr %l296, !tbaa !24
  %t594 = load i64, ptr %l30, !tbaa !24
  store i64 %t594, ptr %l297, !tbaa !24
  %t595 = load i64, ptr %l296, !tbaa !24
  %t596 = load i64, ptr %l297, !tbaa !24
  %t597 = mul i64 %t595, %t596
  store i64 %t597, ptr %l298, !tbaa !24
  %t598 = load i64, ptr %l295, !tbaa !24
  %t599 = load i64, ptr %l298, !tbaa !24
  %t600 = add i64 %t598, %t599
  store i64 %t600, ptr %l299, !tbaa !24
  %t601 = load i64, ptr %l299, !tbaa !24
  store i64 %t601, ptr %l33, !tbaa !24
  %t602 = load ptr, ptr %l0, !tbaa !29
  store ptr %t602, ptr %l300, !tbaa !29
  %t603 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t603, ptr %l301, !tbaa !27
  store ptr %l14, ptr %l302, !tbaa !29
  %t604 = load i64, ptr %l33, !tbaa !24
  store i64 %t604, ptr %l303, !tbaa !24
  %t605 = load ptr, ptr %l302, !tbaa !29
  %t606 = load i64, ptr %l303, !tbaa !24
  %t607 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %s0, ptr %s0, ptr %t605, i64 %t606)
  store { i64, ptr } %t607, ptr %l304
  br label %bb133
bb133:
  %t608 = load ptr, ptr %l300, !tbaa !29
  %t609 = load { i64, ptr }, ptr %l301, !tbaa !27
  %t610 = load { i64, ptr }, ptr %l304, !tbaa !27
  %t611 = call { i64, ptr } @compiler_2ffmt_2ecompiler_2ffmt_3aloader_2etarget(ptr %v0, ptr %s0, ptr %s0, ptr %s21, ptr %t608, { i64, ptr } %t609, { i64, ptr } %t610)
  store { i64, ptr } %t611, ptr %l305
  br label %bb134
bb134:
  %t612 = load { i64, ptr }, ptr %l305, !tbaa !27
  store { i64, ptr } %t612, ptr %l34, !tbaa !27
  store i64 -1, ptr %l35, !tbaa !24
  %t613 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t613, ptr %l306, !tbaa !27
  %t614 = load { i64, ptr }, ptr %l306, !tbaa !27
  %t615 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s21, ptr %s21, { i64, ptr } %t614, { i64, ptr } { i64 0, ptr @.d57 })
  store i1 %t615, ptr %l307
  br label %bb135
bb135:
  %t616 = load i1, ptr %l307, !tbaa !21
  %t617 = xor i1 %t616, true
  store i1 %t617, ptr %l308, !tbaa !21
  %t618 = load i1, ptr %l308, !tbaa !21
  br i1 %t618, label %bb136, label %bb137
bb136:
  store %olang.scope zeroinitializer, ptr %s22
  %t619 = load ptr, ptr %l0, !tbaa !29
  store ptr %t619, ptr %l309, !tbaa !29
  %t620 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t620, ptr %l310, !tbaa !27
  %t621 = load ptr, ptr %l309, !tbaa !29
  %t622 = load { i64, ptr }, ptr %l310, !tbaa !27
  %t623 = call i64 @compiler_2ffmt_2ecompiler_2ffmt_3aloader_2eload(ptr %v0, ptr %s21, ptr %t621, { i64, ptr } %t622)
  store i64 %t623, ptr %l311
  br label %bb138
bb137:
  br label %bb139
bb138:
  %t624 = load i64, ptr %l311, !tbaa !24
  store i64 %t624, ptr %l35, !tbaa !24
  call void @__olang_scope_close(ptr %s22)
  br label %bb139
bb139:
  %t625 = load ptr, ptr %l0, !tbaa !29
  store ptr %t625, ptr %l312, !tbaa !29
  %t626 = load ptr, ptr %l312, !tbaa !29
  %t627 = getelementptr %"compiler/fmt:loader", ptr %t626, i32 0, i32 3
  store ptr %t627, ptr %l313, !tbaa !29
  %t628 = load i64, ptr %l11, !tbaa !24
  store i64 %t628, ptr %l314, !tbaa !24
  %t629 = load ptr, ptr %l313, !tbaa !29
  %t630 = load i64, ptr %l314, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t629, i64 %t630)
  br label %bb140
bb140:
  %t631 = load ptr, ptr %l0, !tbaa !29
  store ptr %t631, ptr %l315, !tbaa !29
  %t632 = load ptr, ptr %l315, !tbaa !29
  %t633 = getelementptr %"compiler/fmt:loader", ptr %t632, i32 0, i32 4
  store ptr %t633, ptr %l316, !tbaa !29
  store ptr %l13, ptr %l317, !tbaa !29
  %t634 = load i64, ptr %l33, !tbaa !24
  store i64 %t634, ptr %l318, !tbaa !24
  %t635 = load ptr, ptr %l317, !tbaa !29
  %t636 = load i64, ptr %l318, !tbaa !24
  %t637 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %s0, ptr %s21, ptr %t635, i64 %t636)
  store { i64, ptr } %t637, ptr %l319
  br label %bb141
bb141:
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s23
  store ptr %s23room, ptr %s23
  %t638 = load { i64, ptr }, ptr %l319, !tbaa !27
  %t639 = extractvalue { i64, ptr } %t638, 1
  %t640 = extractvalue { i64, ptr } %t638, 0
  call void @__olang_sb_put(ptr %s23, ptr %t639, i64 %t640)
  %t641 = load ptr, ptr %s23
  %t642 = getelementptr %olang.builder, ptr %s23, i32 0, i32 1
  %t643 = load i64, ptr %t642
  %t644 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t643)
  call void @llvm.memcpy.p0.p0.i64(ptr %t644, ptr %t641, i64 %t643, i1 false)
  %t645 = insertvalue { i64, ptr } undef, i64 %t643, 0
  %t646 = insertvalue { i64, ptr } %t645, ptr %t644, 1
  store { i64, ptr } %t646, ptr %l320, !tbaa !27
  call void @__olang_sb_done(ptr %s23)
  %t647 = load { i64, ptr }, ptr %l320, !tbaa !27
  %t648 = extractvalue { i64, ptr } %t647, 0
  %t649 = extractvalue { i64, ptr } %t647, 1
  %t650 = mul i64 %t648, 1
  %t651 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t650)
  call void @llvm.memcpy.p0.p0.i64(ptr %t651, ptr %t649, i64 %t650, i1 false)
  %t652 = insertvalue { i64, ptr } undef, i64 %t648, 0
  %t653 = insertvalue { i64, ptr } %t652, ptr %t651, 1
  store { i64, ptr } %t653, ptr %l321, !tbaa !27
  %t654 = load ptr, ptr %l316, !tbaa !29
  %t655 = load { i64, ptr }, ptr %l321, !tbaa !27
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v0, ptr %v0, ptr %t654, { i64, ptr } %t655)
  br label %bb142
bb142:
  %t656 = load ptr, ptr %l0, !tbaa !29
  store ptr %t656, ptr %l322, !tbaa !29
  %t657 = load ptr, ptr %l322, !tbaa !29
  %t658 = getelementptr %"compiler/fmt:loader", ptr %t657, i32 0, i32 5
  store ptr %t658, ptr %l323, !tbaa !29
  %t659 = load i64, ptr %l35, !tbaa !24
  store i64 %t659, ptr %l324, !tbaa !24
  %t660 = load ptr, ptr %l323, !tbaa !29
  %t661 = load i64, ptr %l324, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t660, i64 %t661)
  br label %bb143
bb143:
  call void @__olang_scope_close(ptr %s21)
  br label %bb144
bb144:
  store %olang.scope zeroinitializer, ptr %s24
  %t662 = load i64, ptr %l32, !tbaa !24
  store i64 %t662, ptr %l325, !tbaa !24
  %t663 = load i64, ptr %l325, !tbaa !24
  %t664 = add i64 %t663, 1
  store i64 %t664, ptr %l326, !tbaa !24
  %t665 = load i64, ptr %l326, !tbaa !24
  store i64 %t665, ptr %l32, !tbaa !24
  call void @__olang_scope_close(ptr %s24)
  br label %bb129
bb145:
  call void @__olang_scope_close(ptr %s20)
  %t666 = load i64, ptr %l11, !tbaa !24
  store i64 %t666, ptr %l327, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  %t667 = load i64, ptr %l327, !tbaa !24
  store i64 %t667, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2ffmt_2ecompiler_2ffmt_3aloader_2eoracle(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, i64 %a3, { i64, ptr } %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca i64
  %l15 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i1
  %l23 = alloca i1
  %l24 = alloca { i64, ptr }
  %l25 = alloca i64
  %l26 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l28 = alloca i1
  %l29 = alloca i1
  %l30 = alloca i1
  %l31 = alloca { i64, ptr }
  %l32 = alloca i8
  %l33 = alloca i1
  %l34 = alloca ptr
  %l35 = alloca ptr
  %l36 = alloca { i64, ptr }
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca ptr
  %l40 = alloca ptr
  %l41 = alloca ptr
  %l42 = alloca ptr
  %l43 = alloca ptr
  %l44 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i64 %a3, ptr %l3
  store { i64, ptr } %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l9, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  store ptr %t2, ptr %l10, !tbaa !29
  %t3 = load ptr, ptr %l2, !tbaa !29
  store ptr %t3, ptr %l11, !tbaa !29
  %t4 = load ptr, ptr %l0, !tbaa !29
  store ptr %t4, ptr %l12, !tbaa !29
  %t5 = load ptr, ptr %l12, !tbaa !29
  %t6 = getelementptr %"compiler/fmt:loader", ptr %t5, i32 0, i32 2
  store ptr %t6, ptr %l13, !tbaa !29
  %t7 = load i64, ptr %l3, !tbaa !24
  store i64 %t7, ptr %l14, !tbaa !24
  %t8 = load ptr, ptr %l13, !tbaa !29
  %t9 = load i64, ptr %l14, !tbaa !24
  %t10 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %v0, ptr %t8, i64 %t9)
  store { i64, ptr } %t10, ptr %l15
  br label %bb1
bb1:
  %t11 = load ptr, ptr %l9, !tbaa !29
  %t12 = load ptr, ptr %l10, !tbaa !29
  %t13 = load ptr, ptr %l11, !tbaa !29
  %t14 = load { i64, ptr }, ptr %l15, !tbaa !27
  call void @compiler_2ffmt_2ecompiler_2ffmt_3aloader_2eaddNames(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %v0, ptr %t11, ptr %t12, ptr %t13, { i64, ptr } { i64 0, ptr @.d58 }, { i64, ptr } %t14)
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t15 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t15, ptr %l16, !tbaa !27
  %t16 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t17 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eSplit(ptr %v3, ptr %s1, { i64, ptr } %t16, { i64, ptr } { i64 1, ptr @.d59 })
  store { i64, ptr } %t17, ptr %l17
  br label %bb3
bb3:
  %t18 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t18, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t19 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t19, ptr %l18, !tbaa !27
  %t20 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t21 = extractvalue { i64, ptr } %t20, 0
  store i64 %t21, ptr %l19, !tbaa !24
  %t22 = load i64, ptr %l19, !tbaa !24
  store i64 %t22, ptr %l7, !tbaa !24
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s2
  %t23 = load i64, ptr %l6, !tbaa !24
  store i64 %t23, ptr %l20, !tbaa !24
  %t24 = load i64, ptr %l7, !tbaa !24
  store i64 %t24, ptr %l21, !tbaa !24
  %t25 = load i64, ptr %l20, !tbaa !24
  %t26 = load i64, ptr %l21, !tbaa !24
  %t27 = icmp slt i64 %t25, %t26
  store i1 %t27, ptr %l22, !tbaa !21
  %t28 = load i1, ptr %l22, !tbaa !21
  %t29 = xor i1 %t28, true
  store i1 %t29, ptr %l23, !tbaa !21
  %t30 = load i1, ptr %l23, !tbaa !21
  br i1 %t30, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s2)
  br label %bb18
bb6:
  br label %bb7
bb7:
  %t31 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t31, ptr %l24, !tbaa !27
  %t32 = load i64, ptr %l6, !tbaa !24
  store i64 %t32, ptr %l25, !tbaa !24
  %t33 = load i64, ptr %l25, !tbaa !24
  %t34 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !27
  %t36 = getelementptr { i64, ptr }, ptr %t35, i64 %t33
  %t37 = load { i64, ptr }, ptr %t36, !tbaa !37
  store { i64, ptr } %t37, ptr %l26, !tbaa !27
  %t38 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t38, ptr %l8, !tbaa !27
  %t39 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t39, ptr %l27, !tbaa !27
  %t40 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t41 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v3, ptr %s2, { i64, ptr } %t40, { i64, ptr } { i64 0, ptr @.d60 })
  store i1 %t41, ptr %l28
  br label %bb8
bb8:
  %t42 = load i1, ptr %l28, !tbaa !21
  %t43 = xor i1 %t42, true
  store i1 %t43, ptr %l29, !tbaa !21
  %t44 = load i1, ptr %l29, !tbaa !21
  br i1 %t44, label %bb9, label %bb10
bb9:
  %t45 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t45, ptr %l31, !tbaa !27
  %t46 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !27
  %t48 = getelementptr i8, ptr %t47, i64 0
  %t49 = load i8, ptr %t48, !tbaa !32
  store i8 %t49, ptr %l32, !tbaa !22
  %t50 = load i8, ptr %l32, !tbaa !22
  %t51 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsUpper(i8 %t50)
  store i1 %t51, ptr %l33
  br label %bb11
bb10:
  store i1 false, ptr %l30, !tbaa !21
  br label %bb12
bb11:
  %t52 = load i1, ptr %l33, !tbaa !21
  store i1 %t52, ptr %l30, !tbaa !21
  br label %bb12
bb12:
  %t53 = load i1, ptr %l30, !tbaa !21
  br i1 %t53, label %bb13, label %bb14
bb13:
  store %olang.scope zeroinitializer, ptr %s3
  %t54 = load ptr, ptr %l1, !tbaa !29
  store ptr %t54, ptr %l34, !tbaa !29
  %t55 = load ptr, ptr %l2, !tbaa !29
  store ptr %t55, ptr %l35, !tbaa !29
  %t56 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t56, ptr %l36, !tbaa !27
  %t57 = load ptr, ptr %l34, !tbaa !29
  %t58 = load ptr, ptr %l35, !tbaa !29
  %t59 = load { i64, ptr }, ptr %l36, !tbaa !27
  call void @compiler_2fparse_2ecompiler_2fparse_3aOracle_2eAdd(ptr %v1, ptr %v2, ptr %s3, ptr %v3, ptr %t57, ptr %t58, { i64, ptr } { i64 0, ptr @.d61 }, { i64, ptr } %t59)
  br label %bb15
bb14:
  br label %bb16
bb15:
  call void @__olang_scope_close(ptr %s3)
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s2)
  br label %bb17
bb17:
  store %olang.scope zeroinitializer, ptr %s4
  %t60 = load i64, ptr %l6, !tbaa !24
  store i64 %t60, ptr %l37, !tbaa !24
  %t61 = load i64, ptr %l37, !tbaa !24
  %t62 = add i64 %t61, 1
  store i64 %t62, ptr %l38, !tbaa !24
  %t63 = load i64, ptr %l38, !tbaa !24
  store i64 %t63, ptr %l6, !tbaa !24
  call void @__olang_scope_close(ptr %s4)
  br label %bb4
bb18:
  call void @__olang_scope_close(ptr %s1)
  %t64 = load ptr, ptr %l1, !tbaa !29
  store ptr %t64, ptr %l39, !tbaa !29
  %t65 = load ptr, ptr %l2, !tbaa !29
  store ptr %t65, ptr %l40, !tbaa !29
  %t66 = load ptr, ptr %l39, !tbaa !29
  %t67 = load ptr, ptr %l40, !tbaa !29
  call void @compiler_2fparse_2ecompiler_2fparse_3aOracle_2eAdd(ptr %v1, ptr %v2, ptr %s0, ptr %s0, ptr %t66, ptr %t67, { i64, ptr } { i64 0, ptr @.d62 }, { i64, ptr } { i64 5, ptr @.d63 })
  br label %bb19
bb19:
  %t68 = load ptr, ptr %l0, !tbaa !29
  store ptr %t68, ptr %l41, !tbaa !29
  %t69 = load ptr, ptr %l1, !tbaa !29
  store ptr %t69, ptr %l42, !tbaa !29
  %t70 = load ptr, ptr %l2, !tbaa !29
  store ptr %t70, ptr %l43, !tbaa !29
  %t71 = load i64, ptr %l3, !tbaa !24
  store i64 %t71, ptr %l44, !tbaa !24
  %t72 = load ptr, ptr %l41, !tbaa !29
  %t73 = load ptr, ptr %l42, !tbaa !29
  %t74 = load ptr, ptr %l43, !tbaa !29
  %t75 = load i64, ptr %l44, !tbaa !24
  call void @compiler_2ffmt_2ecompiler_2ffmt_3aloader_2echains(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %t72, ptr %t73, ptr %t74, i64 %t75, { i64, ptr } { i64 0, ptr @.d64 }, i64 0)
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2ffmt_2ecompiler_2ffmt_3aloader_2eprelude(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"std/prelude/text:StringBuilder"
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca %"std/prelude/text:StringBuilder"
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l17 = alloca i32
  %l18 = alloca i32
  %l19 = alloca i1
  %l20 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l22 = alloca i64
  %l23 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i1
  %l30 = alloca i1
  %l31 = alloca { i64, ptr }
  %l32 = alloca i64
  %l33 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l35 = alloca i1
  %l36 = alloca i1
  %l37 = alloca ptr
  %l38 = alloca { i64, ptr }
  %l39 = alloca { i64, ptr }
  %l40 = alloca { i64, ptr }
  %l41 = alloca { i64, ptr }
  %l42 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i1
  %l45 = alloca ptr
  %l46 = alloca ptr
  %l47 = alloca ptr
  %l48 = alloca i64
  %l49 = alloca { i64, ptr }
  %l50 = alloca { i64, ptr }
  %l51 = alloca ptr
  %l52 = alloca ptr
  %l53 = alloca i64
  %l54 = alloca { i64, ptr }
  %l55 = alloca { i64, ptr }
  %l56 = alloca { i64, ptr }
  %l57 = alloca i64
  %l58 = alloca i64
  %l59 = alloca i1
  %l60 = alloca i1
  %l61 = alloca i1
  %l62 = alloca { i64, ptr }
  %l63 = alloca i64
  %l64 = alloca i64
  %l65 = alloca ptr
  %l66 = alloca { i64, ptr }
  %l67 = alloca { i64, ptr }
  %l68 = alloca i64
  %l69 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l9
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l9
  store %"std/prelude/text:StringBuilder" %t2, ptr %l1
  store ptr %l1, ptr %l10, !tbaa !29
  %t3 = load ptr, ptr %l10, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %t3, i8 32)
  br label %bb2
bb2:
  %t4 = load ptr, ptr %l0, !tbaa !29
  store ptr %t4, ptr %l11, !tbaa !29
  %t5 = load ptr, ptr %l11, !tbaa !29
  %t6 = getelementptr %"compiler/fmt:loader", ptr %t5, i32 0, i32 0
  %t7 = load { i64, ptr }, ptr %t6, !tbaa !27
  store { i64, ptr } %t7, ptr %l12, !tbaa !27
  %t8 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t9 = call { i64, ptr } @std_2ffilepath_2eJoin(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t8, { i64, ptr } { i64 7, ptr @.d65 }, { i64, ptr } { i64 0, ptr @.d66 }, { i64, ptr } { i64 0, ptr @.d67 }, { i64, ptr } { i64 0, ptr @.d68 }, { i64, ptr } { i64 0, ptr @.d69 })
  store { i64, ptr } %t9, ptr %l13
  br label %bb3
bb3:
  %t10 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t10, ptr %l2, !tbaa !27
  %t11 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t11, ptr %l15, !tbaa !27
  %t12 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t13 = call { i32, { i64, ptr } } @std_2fos_2eReadDir(ptr %s0, ptr %s0, { i64, ptr } %t12)
  %t14 = extractvalue { i32, { i64, ptr } } %t13, 1
  %t15 = extractvalue { i32, { i64, ptr } } %t13, 0
  store i32 %t15, ptr %l17
  %t16 = icmp ne i32 %t15, 0
  br i1 %t16, label %bb5, label %ok.17
ok.17:
  store { i64, ptr } %t14, ptr %l16
  br label %bb4
bb4:
  %t18 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t18, ptr %l14, !tbaa !27
  br label %bb9
bb5:
  %t19 = load i32, ptr %l17, !tbaa !23
  %t20 = ashr i32 %t19, 16
  store i32 %t20, ptr %l18, !tbaa !23
  %t21 = load i32, ptr %l18, !tbaa !23
  %t22 = icmp eq i32 %t21, 1
  store i1 %t22, ptr %l19, !tbaa !21
  %t23 = load i1, ptr %l19, !tbaa !21
  br i1 %t23, label %bb6, label %bb7
bb6:
  br label %bb8
bb7:
  call void @__olang_check_failed(ptr @.c70)
  unreachable
bb8:
  store %olang.scope zeroinitializer, ptr %s1
  store { i64, ptr } { i64 1, ptr @.d71 }, ptr %l20, !tbaa !27
  %t24 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t24, ptr %l21, !tbaa !27
  %t25 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t25, 0
  store i64 %t26, ptr %l22, !tbaa !24
  %t27 = load i64, ptr %l22, !tbaa !24
  %t28 = mul i64 %t27, 1
  %t29 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t28)
  %t30 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t31 = insertvalue { i64, ptr } %t30, ptr %t29, 1
  store { i64, ptr } %t31, ptr %l23, !tbaa !27
  %t32 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !27
  %t34 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !27
  %t36 = load i64, ptr %l22, !tbaa !24
  %t37 = mul i64 %t36, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t33, ptr %t35, i64 %t37, i1 false)
  %t38 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t38, ptr %l21, !tbaa !27
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t39 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t39, ptr %rv
  br label %ret
bb9:
  %t40 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t40, ptr %l3, !tbaa !27
  store %olang.scope zeroinitializer, ptr %s2
  %t41 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t41, ptr %l24, !tbaa !27
  %t42 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t42, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t43 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t43, ptr %l25, !tbaa !27
  %t44 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t45 = extractvalue { i64, ptr } %t44, 0
  store i64 %t45, ptr %l26, !tbaa !24
  %t46 = load i64, ptr %l26, !tbaa !24
  store i64 %t46, ptr %l6, !tbaa !24
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s3
  %t47 = load i64, ptr %l5, !tbaa !24
  store i64 %t47, ptr %l27, !tbaa !24
  %t48 = load i64, ptr %l6, !tbaa !24
  store i64 %t48, ptr %l28, !tbaa !24
  %t49 = load i64, ptr %l27, !tbaa !24
  %t50 = load i64, ptr %l28, !tbaa !24
  %t51 = icmp slt i64 %t49, %t50
  store i1 %t51, ptr %l29, !tbaa !21
  %t52 = load i1, ptr %l29, !tbaa !21
  %t53 = xor i1 %t52, true
  store i1 %t53, ptr %l30, !tbaa !21
  %t54 = load i1, ptr %l30, !tbaa !21
  br i1 %t54, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s3)
  br label %bb33
bb12:
  br label %bb13
bb13:
  %t55 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t55, ptr %l31, !tbaa !27
  %t56 = load i64, ptr %l5, !tbaa !24
  store i64 %t56, ptr %l32, !tbaa !24
  %t57 = load i64, ptr %l32, !tbaa !24
  %t58 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !27
  %t60 = getelementptr { i64, ptr }, ptr %t59, i64 %t57
  %t61 = load { i64, ptr }, ptr %t60, !tbaa !37
  store { i64, ptr } %t61, ptr %l33, !tbaa !27
  %t62 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t62, ptr %l7, !tbaa !27
  %t63 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t63, ptr %l34, !tbaa !27
  %t64 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t65 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %s0, ptr %s3, { i64, ptr } %t64, { i64, ptr } { i64 6, ptr @.d72 })
  store i1 %t65, ptr %l35
  br label %bb14
bb14:
  %t66 = load i1, ptr %l35, !tbaa !21
  %t67 = xor i1 %t66, true
  store i1 %t67, ptr %l36, !tbaa !21
  %t68 = load i1, ptr %l36, !tbaa !21
  br i1 %t68, label %bb15, label %bb16
bb15:
  store %olang.scope zeroinitializer, ptr %s4
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s3)
  br label %bb32
bb16:
  br label %bb17
bb17:
  %t69 = load ptr, ptr %l0, !tbaa !29
  store ptr %t69, ptr %l37, !tbaa !29
  %t70 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t70, ptr %l38, !tbaa !27
  %t71 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t71, ptr %l39, !tbaa !27
  %t72 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t73 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t74 = call { i64, ptr } @std_2ffilepath_2eJoin(ptr %s0, ptr %s0, ptr %s3, ptr %s3, ptr %s3, ptr %s3, ptr %s3, { i64, ptr } %t72, { i64, ptr } %t73, { i64, ptr } { i64 0, ptr @.d73 }, { i64, ptr } { i64 0, ptr @.d74 }, { i64, ptr } { i64 0, ptr @.d75 }, { i64, ptr } { i64 0, ptr @.d76 })
  store { i64, ptr } %t74, ptr %l40
  br label %bb18
bb18:
  %t75 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t76 = extractvalue { i64, ptr } %t75, 0
  %t77 = extractvalue { i64, ptr } %t75, 1
  %t78 = mul i64 %t76, 1
  %t79 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t78)
  call void @llvm.memcpy.p0.p0.i64(ptr %t79, ptr %t77, i64 %t78, i1 false)
  %t80 = insertvalue { i64, ptr } undef, i64 %t76, 0
  %t81 = insertvalue { i64, ptr } %t80, ptr %t79, 1
  store { i64, ptr } %t81, ptr %l41, !tbaa !27
  %t82 = load ptr, ptr %l37, !tbaa !29
  %t83 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t84 = call i64 @compiler_2ffmt_2ecompiler_2ffmt_3aloader_2eload(ptr %v0, ptr %s3, ptr %t82, { i64, ptr } %t83)
  store i64 %t84, ptr %l42
  br label %bb19
bb19:
  %t85 = load i64, ptr %l42, !tbaa !24
  store i64 %t85, ptr %l8, !tbaa !24
  %t86 = load i64, ptr %l8, !tbaa !24
  store i64 %t86, ptr %l43, !tbaa !24
  %t87 = load i64, ptr %l43, !tbaa !24
  %t88 = icmp sge i64 %t87, 0
  store i1 %t88, ptr %l44, !tbaa !21
  %t89 = load i1, ptr %l44, !tbaa !21
  br i1 %t89, label %bb20, label %bb21
bb20:
  store %olang.scope zeroinitializer, ptr %s5
  store ptr %l1, ptr %l45, !tbaa !29
  %t90 = load ptr, ptr %l0, !tbaa !29
  store ptr %t90, ptr %l46, !tbaa !29
  %t91 = load ptr, ptr %l46, !tbaa !29
  %t92 = getelementptr %"compiler/fmt:loader", ptr %t91, i32 0, i32 2
  store ptr %t92, ptr %l47, !tbaa !29
  %t93 = load i64, ptr %l8, !tbaa !24
  store i64 %t93, ptr %l48, !tbaa !24
  %t94 = load ptr, ptr %l47, !tbaa !29
  %t95 = load i64, ptr %l48, !tbaa !24
  %t96 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %v0, ptr %t94, i64 %t95)
  store { i64, ptr } %t96, ptr %l49
  br label %bb22
bb21:
  br label %bb31
bb22:
  %t97 = load { i64, ptr }, ptr %l49, !tbaa !27
  store { i64, ptr } %t97, ptr %l50, !tbaa !27
  %t98 = load ptr, ptr %l0, !tbaa !29
  store ptr %t98, ptr %l51, !tbaa !29
  %t99 = load ptr, ptr %l51, !tbaa !29
  %t100 = getelementptr %"compiler/fmt:loader", ptr %t99, i32 0, i32 2
  store ptr %t100, ptr %l52, !tbaa !29
  %t101 = load i64, ptr %l8, !tbaa !24
  store i64 %t101, ptr %l53, !tbaa !24
  %t102 = load ptr, ptr %l52, !tbaa !29
  %t103 = load i64, ptr %l53, !tbaa !24
  %t104 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %v0, ptr %t102, i64 %t103)
  store { i64, ptr } %t104, ptr %l54
  br label %bb23
bb23:
  %t105 = load { i64, ptr }, ptr %l54, !tbaa !27
  store { i64, ptr } %t105, ptr %l55, !tbaa !27
  %t106 = load { i64, ptr }, ptr %l55, !tbaa !27
  store { i64, ptr } %t106, ptr %l56, !tbaa !27
  %t107 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t108 = extractvalue { i64, ptr } %t107, 0
  store i64 %t108, ptr %l57, !tbaa !24
  %t109 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t110 = extractvalue { i64, ptr } %t109, 0
  store i64 %t110, ptr %l58, !tbaa !24
  %t111 = icmp sge i64 1, 0
  store i1 %t111, ptr %l59, !tbaa !21
  %t112 = load i1, ptr %l59, !tbaa !21
  br i1 %t112, label %bb24, label %bb25
bb24:
  %t113 = load i64, ptr %l57, !tbaa !24
  %t114 = icmp sle i64 1, %t113
  store i1 %t114, ptr %l60, !tbaa !21
  %t115 = load i1, ptr %l60, !tbaa !21
  br i1 %t115, label %bb26, label %bb27
bb25:
  call void @__olang_check_failed(ptr @.c77)
  unreachable
bb26:
  %t116 = load i64, ptr %l57, !tbaa !24
  %t117 = load i64, ptr %l58, !tbaa !24
  %t118 = icmp sle i64 %t116, %t117
  store i1 %t118, ptr %l61, !tbaa !21
  %t119 = load i1, ptr %l61, !tbaa !21
  br i1 %t119, label %bb28, label %bb29
bb27:
  call void @__olang_check_failed(ptr @.c77)
  unreachable
bb28:
  %t120 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t121 = load ptr, ptr %t120, !tbaa !27
  %t122 = load i64, ptr %l57, !tbaa !24
  %t123 = getelementptr i8, ptr %t121, i64 1
  %t124 = sub i64 %t122, 1
  %t125 = insertvalue { i64, ptr } undef, i64 %t124, 0
  %t126 = insertvalue { i64, ptr } %t125, ptr %t123, 1
  store { i64, ptr } %t126, ptr %l62, !tbaa !27
  %t127 = load ptr, ptr %l45, !tbaa !29
  %t128 = load { i64, ptr }, ptr %l62, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %t127, { i64, ptr } %t128)
  br label %bb30
bb29:
  call void @__olang_check_failed(ptr @.c77)
  unreachable
bb30:
  call void @__olang_scope_close(ptr %s5)
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s3)
  br label %bb32
bb32:
  store %olang.scope zeroinitializer, ptr %s6
  %t129 = load i64, ptr %l5, !tbaa !24
  store i64 %t129, ptr %l63, !tbaa !24
  %t130 = load i64, ptr %l63, !tbaa !24
  %t131 = add i64 %t130, 1
  store i64 %t131, ptr %l64, !tbaa !24
  %t132 = load i64, ptr %l64, !tbaa !24
  store i64 %t132, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s6)
  br label %bb10
bb33:
  call void @__olang_scope_close(ptr %s2)
  store ptr %l1, ptr %l65, !tbaa !29
  %t133 = load ptr, ptr %l65, !tbaa !29
  %t134 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %t133)
  store { i64, ptr } %t134, ptr %l66
  br label %bb34
bb34:
  %t135 = load { i64, ptr }, ptr %l66, !tbaa !27
  store { i64, ptr } %t135, ptr %l67, !tbaa !27
  %t136 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t137 = extractvalue { i64, ptr } %t136, 0
  store i64 %t137, ptr %l68, !tbaa !24
  %t138 = load i64, ptr %l68, !tbaa !24
  %t139 = mul i64 %t138, 1
  %t140 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t139)
  %t141 = insertvalue { i64, ptr } undef, i64 %t138, 0
  %t142 = insertvalue { i64, ptr } %t141, ptr %t140, 1
  store { i64, ptr } %t142, ptr %l69, !tbaa !27
  %t143 = getelementptr { i64, ptr }, ptr %l69, i32 0, i32 1
  %t144 = load ptr, ptr %t143, !tbaa !27
  %t145 = getelementptr { i64, ptr }, ptr %l67, i32 0, i32 1
  %t146 = load ptr, ptr %t145, !tbaa !27
  %t147 = load i64, ptr %l68, !tbaa !24
  %t148 = mul i64 %t147, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t144, ptr %t146, i64 %t148, i1 false)
  %t149 = load { i64, ptr }, ptr %l69, !tbaa !27
  store { i64, ptr } %t149, ptr %l67, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t150 = load { i64, ptr }, ptr %l67, !tbaa !27
  store { i64, ptr } %t150, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2ffmt_2ecompiler_2ffmt_3aloader_2etarget(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca i8
  %l9 = alloca i64
  %l10 = alloca i32
  %l11 = alloca i64
  %l12 = alloca i1
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i1
  %l17 = alloca i1
  %l18 = alloca i1
  %l19 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l23 = alloca i1
  %l24 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l26 = alloca i64
  %l27 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  %l29 = alloca i1
  %l30 = alloca ptr
  %l31 = alloca { i64, ptr }
  %l32 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i1
  %l38 = alloca i1
  %l39 = alloca i1
  %l40 = alloca { i64, ptr }
  %l41 = alloca { i64, ptr }
  %l42 = alloca { i64, ptr }
  %l43 = alloca { i64, ptr }
  %l44 = alloca { i64, ptr }
  %l45 = alloca { i64, ptr }
  %l46 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.builder
  %s4room = alloca [64 x i8], align 8
  %s5 = alloca %olang.builder
  %s5room = alloca [64 x i8], align 8
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t1, ptr %l5, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t2, ptr %l3, !tbaa !27
  %t3 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t3, ptr %l7, !tbaa !27
  store i8 47, ptr %l8, !tbaa !22
  %t4 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t5 = load i8, ptr %l8, !tbaa !22
  %t6 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindByte(ptr %v2, { i64, ptr } %t4, i8 %t5)
  %t7 = extractvalue { i32, i64 } %t6, 1
  %t8 = extractvalue { i32, i64 } %t6, 0
  store i32 %t8, ptr %l10
  %t9 = icmp ne i32 %t8, 0
  br i1 %t9, label %bb2, label %ok.10
ok.10:
  store i64 %t7, ptr %l9
  br label %bb1
bb1:
  %t11 = load i64, ptr %l9, !tbaa !24
  store i64 %t11, ptr %l6, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  store i64 -1, ptr %l6, !tbaa !24
  br label %bb4
bb4:
  %t12 = load i64, ptr %l6, !tbaa !24
  store i64 %t12, ptr %l4, !tbaa !24
  %t13 = load i64, ptr %l4, !tbaa !24
  store i64 %t13, ptr %l11, !tbaa !24
  %t14 = load i64, ptr %l11, !tbaa !24
  %t15 = icmp sge i64 %t14, 0
  store i1 %t15, ptr %l12, !tbaa !21
  %t16 = load i1, ptr %l12, !tbaa !21
  br i1 %t16, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t17 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t17, ptr %l13, !tbaa !27
  %t18 = load i64, ptr %l4, !tbaa !24
  store i64 %t18, ptr %l14, !tbaa !24
  %t19 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t20 = extractvalue { i64, ptr } %t19, 0
  store i64 %t20, ptr %l15, !tbaa !24
  %t21 = icmp sge i64 0, 0
  store i1 %t21, ptr %l16, !tbaa !21
  %t22 = load i1, ptr %l16, !tbaa !21
  br i1 %t22, label %bb7, label %bb8
bb6:
  br label %bb13
bb7:
  %t23 = load i64, ptr %l14, !tbaa !24
  %t24 = icmp sle i64 0, %t23
  store i1 %t24, ptr %l17, !tbaa !21
  %t25 = load i1, ptr %l17, !tbaa !21
  br i1 %t25, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @.c78)
  unreachable
bb9:
  %t26 = load i64, ptr %l14, !tbaa !24
  %t27 = load i64, ptr %l15, !tbaa !24
  %t28 = icmp sle i64 %t26, %t27
  store i1 %t28, ptr %l18, !tbaa !21
  %t29 = load i1, ptr %l18, !tbaa !21
  br i1 %t29, label %bb11, label %bb12
bb10:
  call void @__olang_check_failed(ptr @.c78)
  unreachable
bb11:
  %t30 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !27
  %t32 = load i64, ptr %l14, !tbaa !24
  %t33 = getelementptr i8, ptr %t31, i64 0
  %t34 = sub i64 %t32, 0
  %t35 = insertvalue { i64, ptr } undef, i64 %t34, 0
  %t36 = insertvalue { i64, ptr } %t35, ptr %t33, 1
  store { i64, ptr } %t36, ptr %l19, !tbaa !27
  %t37 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t37, ptr %l3, !tbaa !27
  call void @__olang_scope_close(ptr %s1)
  br label %bb13
bb12:
  call void @__olang_check_failed(ptr @.c78)
  unreachable
bb13:
  %t38 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t38, ptr %l20, !tbaa !27
  %t39 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t39, ptr %l21, !tbaa !27
  store { i64, ptr } { i64 1, ptr @.d79 }, ptr %l22, !tbaa !27
  %t40 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t41 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t42 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v2, ptr %s0, { i64, ptr } %t40, { i64, ptr } %t41)
  store i1 %t42, ptr %l23
  br label %bb14
bb14:
  %t43 = load i1, ptr %l23, !tbaa !21
  br i1 %t43, label %bb15, label %bb16
bb15:
  store %olang.scope zeroinitializer, ptr %s2
  store { i64, ptr } { i64 0, ptr @.d80 }, ptr %l24, !tbaa !27
  %t44 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t44, ptr %l25, !tbaa !27
  %t45 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t46 = extractvalue { i64, ptr } %t45, 0
  store i64 %t46, ptr %l26, !tbaa !24
  %t47 = load i64, ptr %l26, !tbaa !24
  %t48 = mul i64 %t47, 1
  %t49 = call ptr @__olang_scope_alloc_zeroed(ptr %v3, i64 %t48)
  %t50 = insertvalue { i64, ptr } undef, i64 %t47, 0
  %t51 = insertvalue { i64, ptr } %t50, ptr %t49, 1
  store { i64, ptr } %t51, ptr %l27, !tbaa !27
  %t52 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !27
  %t54 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !27
  %t56 = load i64, ptr %l26, !tbaa !24
  %t57 = mul i64 %t56, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t53, ptr %t55, i64 %t57, i1 false)
  %t58 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t58, ptr %l25, !tbaa !27
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t59 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t59, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  %t60 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t60, ptr %l28, !tbaa !27
  %t61 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t62 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v2, ptr %s0, { i64, ptr } %t61, { i64, ptr } { i64 4, ptr @.d81 })
  store i1 %t62, ptr %l29
  br label %bb18
bb18:
  %t63 = load i1, ptr %l29, !tbaa !21
  br i1 %t63, label %bb19, label %bb20
bb19:
  store %olang.scope zeroinitializer, ptr %s3
  %t64 = load ptr, ptr %l0, !tbaa !29
  store ptr %t64, ptr %l30, !tbaa !29
  %t65 = load ptr, ptr %l30, !tbaa !29
  %t66 = getelementptr %"compiler/fmt:loader", ptr %t65, i32 0, i32 0
  %t67 = load { i64, ptr }, ptr %t66, !tbaa !27
  store { i64, ptr } %t67, ptr %l31, !tbaa !27
  %t68 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t68, ptr %l32, !tbaa !27
  %t69 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t69, ptr %l33, !tbaa !27
  %t70 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t70, ptr %l34, !tbaa !27
  %t71 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t72 = extractvalue { i64, ptr } %t71, 0
  store i64 %t72, ptr %l35, !tbaa !24
  %t73 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t74 = extractvalue { i64, ptr } %t73, 0
  store i64 %t74, ptr %l36, !tbaa !24
  %t75 = icmp sge i64 4, 0
  store i1 %t75, ptr %l37, !tbaa !21
  %t76 = load i1, ptr %l37, !tbaa !21
  br i1 %t76, label %bb21, label %bb22
bb20:
  br label %bb28
bb21:
  %t77 = load i64, ptr %l35, !tbaa !24
  %t78 = icmp sle i64 4, %t77
  store i1 %t78, ptr %l38, !tbaa !21
  %t79 = load i1, ptr %l38, !tbaa !21
  br i1 %t79, label %bb23, label %bb24
bb22:
  call void @__olang_check_failed(ptr @.c82)
  unreachable
bb23:
  %t80 = load i64, ptr %l35, !tbaa !24
  %t81 = load i64, ptr %l36, !tbaa !24
  %t82 = icmp sle i64 %t80, %t81
  store i1 %t82, ptr %l39, !tbaa !21
  %t83 = load i1, ptr %l39, !tbaa !21
  br i1 %t83, label %bb25, label %bb26
bb24:
  call void @__olang_check_failed(ptr @.c82)
  unreachable
bb25:
  %t84 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t85 = load ptr, ptr %t84, !tbaa !27
  %t86 = load i64, ptr %l35, !tbaa !24
  %t87 = getelementptr i8, ptr %t85, i64 4
  %t88 = sub i64 %t86, 4
  %t89 = insertvalue { i64, ptr } undef, i64 %t88, 0
  %t90 = insertvalue { i64, ptr } %t89, ptr %t87, 1
  store { i64, ptr } %t90, ptr %l40, !tbaa !27
  %t91 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t92 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t93 = call { i64, ptr } @std_2ffilepath_2eJoin(ptr %v0, ptr %v2, ptr %s3, ptr %s3, ptr %s3, ptr %s3, ptr %s3, { i64, ptr } %t91, { i64, ptr } %t92, { i64, ptr } { i64 0, ptr @.d83 }, { i64, ptr } { i64 0, ptr @.d84 }, { i64, ptr } { i64 0, ptr @.d85 }, { i64, ptr } { i64 0, ptr @.d86 })
  store { i64, ptr } %t93, ptr %l41
  br label %bb27
bb26:
  call void @__olang_check_failed(ptr @.c82)
  unreachable
bb27:
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s4
  store ptr %s4room, ptr %s4
  %t94 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t95 = extractvalue { i64, ptr } %t94, 1
  %t96 = extractvalue { i64, ptr } %t94, 0
  call void @__olang_sb_put(ptr %s4, ptr %t95, i64 %t96)
  %t97 = extractvalue { i64, ptr } { i64 6, ptr @.d87 }, 1
  %t98 = extractvalue { i64, ptr } { i64 6, ptr @.d87 }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t97, i64 %t98)
  %t99 = load ptr, ptr %s4
  %t100 = getelementptr %olang.builder, ptr %s4, i32 0, i32 1
  %t101 = load i64, ptr %t100
  %t102 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t101)
  call void @llvm.memcpy.p0.p0.i64(ptr %t102, ptr %t99, i64 %t101, i1 false)
  %t103 = insertvalue { i64, ptr } undef, i64 %t101, 0
  %t104 = insertvalue { i64, ptr } %t103, ptr %t102, 1
  store { i64, ptr } %t104, ptr %l42, !tbaa !27
  call void @__olang_sb_done(ptr %s4)
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t105 = load { i64, ptr }, ptr %l42, !tbaa !27
  store { i64, ptr } %t105, ptr %rv
  br label %ret
bb28:
  %t106 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t106, ptr %l43, !tbaa !27
  %t107 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t108 = call { i64, ptr } @std_2ffilepath_2eDir(ptr %v1, { i64, ptr } %t107)
  store { i64, ptr } %t108, ptr %l44
  br label %bb29
bb29:
  %t109 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t109, ptr %l45, !tbaa !27
  %t110 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t111 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t112 = call { i64, ptr } @std_2ffilepath_2eJoin(ptr %v1, ptr %v2, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t110, { i64, ptr } %t111, { i64, ptr } { i64 0, ptr @.d88 }, { i64, ptr } { i64 0, ptr @.d89 }, { i64, ptr } { i64 0, ptr @.d90 }, { i64, ptr } { i64 0, ptr @.d91 })
  store { i64, ptr } %t112, ptr %l46
  br label %bb30
bb30:
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s5
  store ptr %s5room, ptr %s5
  %t113 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t114 = extractvalue { i64, ptr } %t113, 1
  %t115 = extractvalue { i64, ptr } %t113, 0
  call void @__olang_sb_put(ptr %s5, ptr %t114, i64 %t115)
  %t116 = extractvalue { i64, ptr } { i64 6, ptr @.d92 }, 1
  %t117 = extractvalue { i64, ptr } { i64 6, ptr @.d92 }, 0
  call void @__olang_sb_put(ptr %s5, ptr %t116, i64 %t117)
  %t118 = load ptr, ptr %s5
  %t119 = getelementptr %olang.builder, ptr %s5, i32 0, i32 1
  %t120 = load i64, ptr %t119
  %t121 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t120)
  call void @llvm.memcpy.p0.p0.i64(ptr %t121, ptr %t118, i64 %t120, i1 false)
  %t122 = insertvalue { i64, ptr } undef, i64 %t120, 0
  %t123 = insertvalue { i64, ptr } %t122, ptr %t121, 1
  store { i64, ptr } %t123, ptr %l47, !tbaa !27
  call void @__olang_sb_done(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  %t124 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } %t124, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2ffmt_2eisCloser(i32 %a0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca i1
  %l6 = alloca i1
  %l7 = alloca i32
  %l8 = alloca ptr
  %l9 = alloca i32
  %l10 = alloca ptr
  %l11 = alloca i1
  %l12 = alloca i1
  %l13 = alloca i32
  %l14 = alloca ptr
  %l15 = alloca i32
  %l16 = alloca ptr
  %l17 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store i32 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l0
  store i32 %t1, ptr %l1
  store ptr %l1, ptr %l2, !tbaa !29
  store i32 91, ptr %l3
  store ptr %l3, ptr %l4, !tbaa !29
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = load ptr, ptr %l4, !tbaa !29
  %t4 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t2, ptr %t3)
  store i1 %t4, ptr %l5
  br label %bb1
bb1:
  %t5 = load i1, ptr %l5, !tbaa !21
  br i1 %t5, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb5
bb3:
  %t6 = load i32, ptr %l0
  store i32 %t6, ptr %l7
  store ptr %l7, ptr %l8, !tbaa !29
  store i32 93, ptr %l9
  store ptr %l9, ptr %l10, !tbaa !29
  %t7 = load ptr, ptr %l8, !tbaa !29
  %t8 = load ptr, ptr %l10, !tbaa !29
  %t9 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t7, ptr %t8)
  store i1 %t9, ptr %l11
  br label %bb4
bb4:
  %t10 = load i1, ptr %l11, !tbaa !21
  store i1 %t10, ptr %l6, !tbaa !21
  br label %bb5
bb5:
  %t11 = load i1, ptr %l6, !tbaa !21
  br i1 %t11, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb9
bb7:
  %t12 = load i32, ptr %l0
  store i32 %t12, ptr %l13
  store ptr %l13, ptr %l14, !tbaa !29
  store i32 95, ptr %l15
  store ptr %l15, ptr %l16, !tbaa !29
  %t13 = load ptr, ptr %l14, !tbaa !29
  %t14 = load ptr, ptr %l16, !tbaa !29
  %t15 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t13, ptr %t14)
  store i1 %t15, ptr %l17
  br label %bb8
bb8:
  %t16 = load i1, ptr %l17, !tbaa !21
  store i1 %t16, ptr %l12, !tbaa !21
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s0)
  %t17 = load i1, ptr %l12, !tbaa !21
  store i1 %t17, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2ffmt_2elineEndOf(ptr %v0, { i64, ptr } %a0, i64 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i1
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i1
  %l11 = alloca i1
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i8
  %l15 = alloca i1
  %l16 = alloca i1
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca i64
  store { i64, ptr } %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l1, !tbaa !24
  store i64 %t1, ptr %l3, !tbaa !24
  %t2 = load i64, ptr %l3, !tbaa !24
  %t3 = icmp sgt i64 %t2, 0
  store i1 %t3, ptr %l4, !tbaa !21
  %t4 = load i1, ptr %l4, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t5 = load i64, ptr %l1, !tbaa !24
  store i64 %t5, ptr %l6, !tbaa !24
  %t6 = load i64, ptr %l6, !tbaa !24
  store i64 %t6, ptr %l5, !tbaa !24
  br label %bb3
bb2:
  store i64 0, ptr %l5, !tbaa !24
  br label %bb3
bb3:
  %t7 = load i64, ptr %l5, !tbaa !24
  store i64 %t7, ptr %l2, !tbaa !24
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s1
  %t8 = load i64, ptr %l2, !tbaa !24
  store i64 %t8, ptr %l7, !tbaa !24
  %t9 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t9, ptr %l8, !tbaa !27
  %t10 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t10, 0
  store i64 %t11, ptr %l9, !tbaa !24
  %t12 = load i64, ptr %l7, !tbaa !24
  %t13 = load i64, ptr %l9, !tbaa !24
  %t14 = icmp slt i64 %t12, %t13
  store i1 %t14, ptr %l10, !tbaa !21
  %t15 = load i1, ptr %l10, !tbaa !21
  br i1 %t15, label %bb5, label %bb6
bb5:
  %t16 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t16, ptr %l12, !tbaa !27
  %t17 = load i64, ptr %l2, !tbaa !24
  store i64 %t17, ptr %l13, !tbaa !24
  %t18 = load i64, ptr %l13, !tbaa !24
  %t19 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !27
  %t21 = getelementptr i8, ptr %t20, i64 %t18
  %t22 = load i8, ptr %t21, !tbaa !32
  store i8 %t22, ptr %l14, !tbaa !22
  %t23 = load i8, ptr %l14, !tbaa !22
  %t24 = icmp ne i8 %t23, 10
  store i1 %t24, ptr %l15, !tbaa !21
  %t25 = load i1, ptr %l15, !tbaa !21
  store i1 %t25, ptr %l11, !tbaa !21
  br label %bb7
bb6:
  store i1 false, ptr %l11, !tbaa !21
  br label %bb7
bb7:
  %t26 = load i1, ptr %l11, !tbaa !21
  %t27 = xor i1 %t26, true
  store i1 %t27, ptr %l16, !tbaa !21
  %t28 = load i1, ptr %l16, !tbaa !21
  br i1 %t28, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s1)
  br label %bb12
bb9:
  br label %bb10
bb10:
  %t29 = load i64, ptr %l2, !tbaa !24
  store i64 %t29, ptr %l17, !tbaa !24
  %t30 = load i64, ptr %l17, !tbaa !24
  %t31 = add i64 %t30, 1
  store i64 %t31, ptr %l18, !tbaa !24
  %t32 = load i64, ptr %l18, !tbaa !24
  store i64 %t32, ptr %l2, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  br label %bb11
bb11:
  br label %bb4
bb12:
  %t33 = load i64, ptr %l2, !tbaa !24
  store i64 %t33, ptr %l19, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  %t34 = load i64, ptr %l19, !tbaa !24
  store i64 %t34, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2ffmt_2elineStartOf(ptr %v0, { i64, ptr } %a0, i64 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i1
  %l6 = alloca i1
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i8
  %l11 = alloca i1
  %l12 = alloca i1
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca i64
  store { i64, ptr } %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l1, !tbaa !24
  store i64 %t1, ptr %l3, !tbaa !24
  %t2 = load i64, ptr %l3, !tbaa !24
  store i64 %t2, ptr %l2, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t3 = load i64, ptr %l2, !tbaa !24
  store i64 %t3, ptr %l4, !tbaa !24
  %t4 = load i64, ptr %l4, !tbaa !24
  %t5 = icmp sgt i64 %t4, 0
  store i1 %t5, ptr %l5, !tbaa !21
  %t6 = load i1, ptr %l5, !tbaa !21
  br i1 %t6, label %bb2, label %bb3
bb2:
  %t7 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t7, ptr %l7, !tbaa !27
  %t8 = load i64, ptr %l2, !tbaa !24
  store i64 %t8, ptr %l8, !tbaa !24
  %t9 = load i64, ptr %l8, !tbaa !24
  %t10 = sub i64 %t9, 1
  store i64 %t10, ptr %l9, !tbaa !24
  %t11 = load i64, ptr %l9, !tbaa !24
  %t12 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr i8, ptr %t13, i64 %t11
  %t15 = load i8, ptr %t14, !tbaa !32
  store i8 %t15, ptr %l10, !tbaa !22
  %t16 = load i8, ptr %l10, !tbaa !22
  %t17 = icmp ne i8 %t16, 10
  store i1 %t17, ptr %l11, !tbaa !21
  %t18 = load i1, ptr %l11, !tbaa !21
  store i1 %t18, ptr %l6, !tbaa !21
  br label %bb4
bb3:
  store i1 false, ptr %l6, !tbaa !21
  br label %bb4
bb4:
  %t19 = load i1, ptr %l6, !tbaa !21
  %t20 = xor i1 %t19, true
  store i1 %t20, ptr %l12, !tbaa !21
  %t21 = load i1, ptr %l12, !tbaa !21
  br i1 %t21, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s1)
  br label %bb9
bb6:
  br label %bb7
bb7:
  %t22 = load i64, ptr %l2, !tbaa !24
  store i64 %t22, ptr %l13, !tbaa !24
  %t23 = load i64, ptr %l13, !tbaa !24
  %t24 = sub i64 %t23, 1
  store i64 %t24, ptr %l14, !tbaa !24
  %t25 = load i64, ptr %l14, !tbaa !24
  store i64 %t25, ptr %l2, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  br label %bb8
bb8:
  br label %bb1
bb9:
  %t26 = load i64, ptr %l2, !tbaa !24
  store i64 %t26, ptr %l15, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  %t27 = load i64, ptr %l15, !tbaa !24
  store i64 %t27, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2ffmt_3aformatter_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca %"std/prelude/list:List<I64>"
  %l7 = alloca %"std/prelude/list:List<Bool>"
  %l8 = alloca %"std/prelude/list:List<I64>"
  %l9 = alloca %"std/prelude/list:List<I64>"
  %l10 = alloca %"std/prelude/list:List<I64>"
  %l11 = alloca %"std/prelude/list:List<I64>"
  %l12 = alloca %"std/prelude/list:List<I64>"
  %l13 = alloca %"std/prelude/list:List<I64>"
  %l14 = alloca %"std/prelude/list:List<I64>"
  %l15 = alloca %"std/prelude/list:List<I64>"
  %l16 = alloca %"std/prelude/list:List<I64>"
  %l17 = alloca %"std/prelude/list:List<Bool>"
  %l18 = alloca %"std/prelude/text:StringBuilder"
  %l19 = alloca i1
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca { i64, ptr }
  %l23 = alloca i64
  %l24 = alloca i1
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca %"std/prelude/list:List<I64>"
  %l32 = alloca %"std/prelude/list:List<I64>"
  %l33 = alloca i1
  %l34 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l36 = alloca { i64, ptr }
  %l37 = alloca i64
  %l38 = alloca i1
  %l39 = alloca i1
  %l40 = alloca { i64, ptr }
  %l41 = alloca { i64, ptr }
  %l42 = alloca { i64, ptr }
  %l43 = alloca i64
  %l44 = alloca i1
  %l45 = alloca i1
  %l46 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l48 = alloca %"std/prelude/list:List<I64>"
  %l49 = alloca %"std/prelude/list:List<Bool>"
  %l50 = alloca %"std/prelude/list:List<I64>"
  %l51 = alloca %"std/prelude/list:List<I64>"
  %l52 = alloca %"std/prelude/list:List<I64>"
  %l53 = alloca %"std/prelude/list:List<I64>"
  %l54 = alloca %"std/prelude/list:List<I64>"
  %l55 = alloca %"std/prelude/list:List<I64>"
  %l56 = alloca %"std/prelude/list:List<I64>"
  %l57 = alloca %"std/prelude/list:List<I64>"
  %l58 = alloca %"std/prelude/list:List<I64>"
  %l59 = alloca %"std/prelude/list:List<Bool>"
  %l60 = alloca %"std/prelude/text:StringBuilder"
  %l61 = alloca { i64, ptr }
  %l62 = alloca i64
  %l63 = alloca i1
  %l64 = alloca i1
  %l65 = alloca { i64, ptr }
  %l66 = alloca { i64, ptr }
  %l67 = alloca %"std/prelude/list:List<I64>"
  %l68 = alloca %"std/prelude/list:List<I64>"
  %l69 = alloca %"compiler/fmt:formatter"
  %s0 = alloca %olang.scope
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t1, ptr %l34, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t2, ptr %l2, !tbaa !27
  %t3 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t3, ptr %l35, !tbaa !27
  %t4 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t4, ptr %l3, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t5, ptr %l36, !tbaa !27
  %t6 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t6, 0
  store i64 %t7, ptr %l37, !tbaa !24
  %t8 = load i64, ptr %l37, !tbaa !24
  %t9 = icmp sge i64 %t8, 0
  store i1 %t9, ptr %l38, !tbaa !21
  %t10 = load i1, ptr %l38, !tbaa !21
  br i1 %t10, label %bb1, label %bb2
bb1:
  %t11 = load i64, ptr %l37, !tbaa !24
  %t12 = icmp sle i64 %t11, 1152921504606846975
  store i1 %t12, ptr %l39, !tbaa !21
  %t13 = load i1, ptr %l39, !tbaa !21
  br i1 %t13, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @.c93)
  unreachable
bb3:
  %t14 = load i64, ptr %l37, !tbaa !24
  %t15 = mul i64 %t14, 8
  %t16 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t15)
  %t17 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  store { i64, ptr } %t18, ptr %l40, !tbaa !27
  %t19 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t20 = extractvalue { i64, ptr } %t19, 0
  %t21 = extractvalue { i64, ptr } %t19, 1
  %t22 = mul i64 %t20, 8
  %t23 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t22)
  call void @llvm.memcpy.p0.p0.i64(ptr %t23, ptr %t21, i64 %t22, i1 false)
  %t24 = insertvalue { i64, ptr } undef, i64 %t20, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t23, 1
  store { i64, ptr } %t25, ptr %l41, !tbaa !27
  %t26 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t26, ptr %l4, !tbaa !27
  %t27 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t27, ptr %l42, !tbaa !27
  %t28 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t28, 0
  store i64 %t29, ptr %l43, !tbaa !24
  %t30 = load i64, ptr %l43, !tbaa !24
  %t31 = icmp sge i64 %t30, 0
  store i1 %t31, ptr %l44, !tbaa !21
  %t32 = load i1, ptr %l44, !tbaa !21
  br i1 %t32, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @.c93)
  unreachable
bb5:
  %t33 = load i64, ptr %l43, !tbaa !24
  %t34 = icmp sle i64 %t33, 1152921504606846975
  store i1 %t34, ptr %l45, !tbaa !21
  %t35 = load i1, ptr %l45, !tbaa !21
  br i1 %t35, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @.c94)
  unreachable
bb7:
  %t36 = load i64, ptr %l43, !tbaa !24
  %t37 = mul i64 %t36, 8
  %t38 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t37)
  %t39 = insertvalue { i64, ptr } undef, i64 %t36, 0
  %t40 = insertvalue { i64, ptr } %t39, ptr %t38, 1
  store { i64, ptr } %t40, ptr %l46, !tbaa !27
  %t41 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t42 = extractvalue { i64, ptr } %t41, 0
  %t43 = extractvalue { i64, ptr } %t41, 1
  %t44 = mul i64 %t42, 8
  %t45 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t44)
  call void @llvm.memcpy.p0.p0.i64(ptr %t45, ptr %t43, i64 %t44, i1 false)
  %t46 = insertvalue { i64, ptr } undef, i64 %t42, 0
  %t47 = insertvalue { i64, ptr } %t46, ptr %t45, 1
  store { i64, ptr } %t47, ptr %l47, !tbaa !27
  %t48 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } %t48, ptr %l5, !tbaa !27
  %t49 = load ptr, ptr @__olang_prog_scope
  %t50 = call %"std/prelude/list:List<I64>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t49)
  store %"std/prelude/list:List<I64>" %t50, ptr %l48
  br label %bb9
bb8:
  call void @__olang_check_failed(ptr @.c94)
  unreachable
bb9:
  %t51 = load %"std/prelude/list:List<I64>", ptr %l48
  store %"std/prelude/list:List<I64>" %t51, ptr %l6
  %t52 = load ptr, ptr @__olang_prog_scope
  %t53 = call %"std/prelude/list:List<Bool>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cBool_3e(ptr %t52)
  store %"std/prelude/list:List<Bool>" %t53, ptr %l49
  br label %bb10
bb10:
  %t54 = load %"std/prelude/list:List<Bool>", ptr %l49
  store %"std/prelude/list:List<Bool>" %t54, ptr %l7
  %t55 = load ptr, ptr @__olang_prog_scope
  %t56 = call %"std/prelude/list:List<I64>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t55)
  store %"std/prelude/list:List<I64>" %t56, ptr %l50
  br label %bb11
bb11:
  %t57 = load %"std/prelude/list:List<I64>", ptr %l50
  store %"std/prelude/list:List<I64>" %t57, ptr %l8
  %t58 = load ptr, ptr @__olang_prog_scope
  %t59 = call %"std/prelude/list:List<I64>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t58)
  store %"std/prelude/list:List<I64>" %t59, ptr %l51
  br label %bb12
bb12:
  %t60 = load %"std/prelude/list:List<I64>", ptr %l51
  store %"std/prelude/list:List<I64>" %t60, ptr %l9
  %t61 = load ptr, ptr @__olang_prog_scope
  %t62 = call %"std/prelude/list:List<I64>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t61)
  store %"std/prelude/list:List<I64>" %t62, ptr %l52
  br label %bb13
bb13:
  %t63 = load %"std/prelude/list:List<I64>", ptr %l52
  store %"std/prelude/list:List<I64>" %t63, ptr %l10
  %t64 = load ptr, ptr @__olang_prog_scope
  %t65 = call %"std/prelude/list:List<I64>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t64)
  store %"std/prelude/list:List<I64>" %t65, ptr %l53
  br label %bb14
bb14:
  %t66 = load %"std/prelude/list:List<I64>", ptr %l53
  store %"std/prelude/list:List<I64>" %t66, ptr %l11
  %t67 = load ptr, ptr @__olang_prog_scope
  %t68 = call %"std/prelude/list:List<I64>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t67)
  store %"std/prelude/list:List<I64>" %t68, ptr %l54
  br label %bb15
bb15:
  %t69 = load %"std/prelude/list:List<I64>", ptr %l54
  store %"std/prelude/list:List<I64>" %t69, ptr %l12
  %t70 = load ptr, ptr @__olang_prog_scope
  %t71 = call %"std/prelude/list:List<I64>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t70)
  store %"std/prelude/list:List<I64>" %t71, ptr %l55
  br label %bb16
bb16:
  %t72 = load %"std/prelude/list:List<I64>", ptr %l55
  store %"std/prelude/list:List<I64>" %t72, ptr %l13
  %t73 = load ptr, ptr @__olang_prog_scope
  %t74 = call %"std/prelude/list:List<I64>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t73)
  store %"std/prelude/list:List<I64>" %t74, ptr %l56
  br label %bb17
bb17:
  %t75 = load %"std/prelude/list:List<I64>", ptr %l56
  store %"std/prelude/list:List<I64>" %t75, ptr %l14
  %t76 = load ptr, ptr @__olang_prog_scope
  %t77 = call %"std/prelude/list:List<I64>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t76)
  store %"std/prelude/list:List<I64>" %t77, ptr %l57
  br label %bb18
bb18:
  %t78 = load %"std/prelude/list:List<I64>", ptr %l57
  store %"std/prelude/list:List<I64>" %t78, ptr %l15
  %t79 = load ptr, ptr @__olang_prog_scope
  %t80 = call %"std/prelude/list:List<I64>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t79)
  store %"std/prelude/list:List<I64>" %t80, ptr %l58
  br label %bb19
bb19:
  %t81 = load %"std/prelude/list:List<I64>", ptr %l58
  store %"std/prelude/list:List<I64>" %t81, ptr %l16
  %t82 = load ptr, ptr @__olang_prog_scope
  %t83 = call %"std/prelude/list:List<Bool>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cBool_3e(ptr %t82)
  store %"std/prelude/list:List<Bool>" %t83, ptr %l59
  br label %bb20
bb20:
  %t84 = load %"std/prelude/list:List<Bool>", ptr %l59
  store %"std/prelude/list:List<Bool>" %t84, ptr %l17
  %t85 = load ptr, ptr @__olang_prog_scope
  %t86 = call %"std/prelude/text:StringBuilder" @olang_2eHelperKind_2eZero_2estd_2fprelude_2ftext_3aStringBuilder(ptr %t85)
  store %"std/prelude/text:StringBuilder" %t86, ptr %l60
  br label %bb21
bb21:
  %t87 = load %"std/prelude/text:StringBuilder", ptr %l60
  store %"std/prelude/text:StringBuilder" %t87, ptr %l18
  store i1 false, ptr %l19, !tbaa !21
  store i64 0, ptr %l20, !tbaa !24
  store i64 0, ptr %l21, !tbaa !24
  %t88 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t88, ptr %l61, !tbaa !27
  %t89 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t90 = extractvalue { i64, ptr } %t89, 0
  store i64 %t90, ptr %l62, !tbaa !24
  %t91 = load i64, ptr %l62, !tbaa !24
  %t92 = icmp sge i64 %t91, 0
  store i1 %t92, ptr %l63, !tbaa !21
  %t93 = load i1, ptr %l63, !tbaa !21
  br i1 %t93, label %bb22, label %bb23
bb22:
  %t94 = load i64, ptr %l62, !tbaa !24
  %t95 = icmp sle i64 %t94, 1152921504606846975
  store i1 %t95, ptr %l64, !tbaa !21
  %t96 = load i1, ptr %l64, !tbaa !21
  br i1 %t96, label %bb24, label %bb25
bb23:
  call void @__olang_check_failed(ptr @.c95)
  unreachable
bb24:
  %t97 = load i64, ptr %l62, !tbaa !24
  %t98 = mul i64 %t97, 8
  %t99 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t98)
  %t100 = insertvalue { i64, ptr } undef, i64 %t97, 0
  %t101 = insertvalue { i64, ptr } %t100, ptr %t99, 1
  store { i64, ptr } %t101, ptr %l65, !tbaa !27
  %t102 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t103 = extractvalue { i64, ptr } %t102, 0
  %t104 = extractvalue { i64, ptr } %t102, 1
  %t105 = mul i64 %t103, 8
  %t106 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t105)
  call void @llvm.memcpy.p0.p0.i64(ptr %t106, ptr %t104, i64 %t105, i1 false)
  %t107 = insertvalue { i64, ptr } undef, i64 %t103, 0
  %t108 = insertvalue { i64, ptr } %t107, ptr %t106, 1
  store { i64, ptr } %t108, ptr %l66, !tbaa !27
  %t109 = load { i64, ptr }, ptr %l66, !tbaa !27
  store { i64, ptr } %t109, ptr %l22, !tbaa !27
  store i64 0, ptr %l23, !tbaa !24
  store i1 false, ptr %l24, !tbaa !21
  store i64 -1, ptr %l25, !tbaa !24
  store i64 -1, ptr %l26, !tbaa !24
  store i64 0, ptr %l27, !tbaa !24
  store i64 -1, ptr %l28, !tbaa !24
  store i64 0, ptr %l29, !tbaa !24
  store i64 -1, ptr %l30, !tbaa !24
  %t110 = load ptr, ptr @__olang_prog_scope
  %t111 = call %"std/prelude/list:List<I64>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t110)
  store %"std/prelude/list:List<I64>" %t111, ptr %l67
  br label %bb26
bb25:
  call void @__olang_check_failed(ptr @.c95)
  unreachable
bb26:
  %t112 = load %"std/prelude/list:List<I64>", ptr %l67
  store %"std/prelude/list:List<I64>" %t112, ptr %l31
  %t113 = load ptr, ptr @__olang_prog_scope
  %t114 = call %"std/prelude/list:List<I64>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t113)
  store %"std/prelude/list:List<I64>" %t114, ptr %l68
  br label %bb27
bb27:
  %t115 = load %"std/prelude/list:List<I64>", ptr %l68
  store %"std/prelude/list:List<I64>" %t115, ptr %l32
  store i1 false, ptr %l33, !tbaa !21
  %t116 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t117 = insertvalue %"compiler/fmt:formatter" undef, { i64, ptr } %t116, 0
  %t118 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t119 = insertvalue %"compiler/fmt:formatter" %t117, { i64, ptr } %t118, 1
  %t120 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t121 = insertvalue %"compiler/fmt:formatter" %t119, { i64, ptr } %t120, 2
  %t122 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t123 = insertvalue %"compiler/fmt:formatter" %t121, { i64, ptr } %t122, 3
  %t124 = load %"std/prelude/list:List<I64>", ptr %l6
  %t125 = insertvalue %"compiler/fmt:formatter" %t123, %"std/prelude/list:List<I64>" %t124, 4
  %t126 = load %"std/prelude/list:List<Bool>", ptr %l7
  %t127 = insertvalue %"compiler/fmt:formatter" %t125, %"std/prelude/list:List<Bool>" %t126, 5
  %t128 = load %"std/prelude/list:List<I64>", ptr %l8
  %t129 = insertvalue %"compiler/fmt:formatter" %t127, %"std/prelude/list:List<I64>" %t128, 6
  %t130 = load %"std/prelude/list:List<I64>", ptr %l9
  %t131 = insertvalue %"compiler/fmt:formatter" %t129, %"std/prelude/list:List<I64>" %t130, 7
  %t132 = load %"std/prelude/list:List<I64>", ptr %l10
  %t133 = insertvalue %"compiler/fmt:formatter" %t131, %"std/prelude/list:List<I64>" %t132, 8
  %t134 = load %"std/prelude/list:List<I64>", ptr %l11
  %t135 = insertvalue %"compiler/fmt:formatter" %t133, %"std/prelude/list:List<I64>" %t134, 9
  %t136 = load %"std/prelude/list:List<I64>", ptr %l12
  %t137 = insertvalue %"compiler/fmt:formatter" %t135, %"std/prelude/list:List<I64>" %t136, 10
  %t138 = load %"std/prelude/list:List<I64>", ptr %l13
  %t139 = insertvalue %"compiler/fmt:formatter" %t137, %"std/prelude/list:List<I64>" %t138, 11
  %t140 = load %"std/prelude/list:List<I64>", ptr %l14
  %t141 = insertvalue %"compiler/fmt:formatter" %t139, %"std/prelude/list:List<I64>" %t140, 12
  %t142 = load %"std/prelude/list:List<I64>", ptr %l15
  %t143 = insertvalue %"compiler/fmt:formatter" %t141, %"std/prelude/list:List<I64>" %t142, 13
  %t144 = load %"std/prelude/list:List<I64>", ptr %l16
  %t145 = insertvalue %"compiler/fmt:formatter" %t143, %"std/prelude/list:List<I64>" %t144, 14
  %t146 = load %"std/prelude/list:List<Bool>", ptr %l17
  %t147 = insertvalue %"compiler/fmt:formatter" %t145, %"std/prelude/list:List<Bool>" %t146, 15
  %t148 = load %"std/prelude/text:StringBuilder", ptr %l18
  %t149 = insertvalue %"compiler/fmt:formatter" %t147, %"std/prelude/text:StringBuilder" %t148, 16
  %t150 = load i1, ptr %l19, !tbaa !21
  %t151 = insertvalue %"compiler/fmt:formatter" %t149, i1 %t150, 17
  %t152 = load i64, ptr %l20, !tbaa !24
  %t153 = insertvalue %"compiler/fmt:formatter" %t151, i64 %t152, 18
  %t154 = load i64, ptr %l21, !tbaa !24
  %t155 = insertvalue %"compiler/fmt:formatter" %t153, i64 %t154, 19
  %t156 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t157 = insertvalue %"compiler/fmt:formatter" %t155, { i64, ptr } %t156, 20
  %t158 = load i64, ptr %l23, !tbaa !24
  %t159 = insertvalue %"compiler/fmt:formatter" %t157, i64 %t158, 21
  %t160 = load i1, ptr %l24, !tbaa !21
  %t161 = insertvalue %"compiler/fmt:formatter" %t159, i1 %t160, 22
  %t162 = load i64, ptr %l25, !tbaa !24
  %t163 = insertvalue %"compiler/fmt:formatter" %t161, i64 %t162, 23
  %t164 = load i64, ptr %l26, !tbaa !24
  %t165 = insertvalue %"compiler/fmt:formatter" %t163, i64 %t164, 24
  %t166 = load i64, ptr %l27, !tbaa !24
  %t167 = insertvalue %"compiler/fmt:formatter" %t165, i64 %t166, 25
  %t168 = load i64, ptr %l28, !tbaa !24
  %t169 = insertvalue %"compiler/fmt:formatter" %t167, i64 %t168, 26
  %t170 = load i64, ptr %l29, !tbaa !24
  %t171 = insertvalue %"compiler/fmt:formatter" %t169, i64 %t170, 27
  %t172 = load i64, ptr %l30, !tbaa !24
  %t173 = insertvalue %"compiler/fmt:formatter" %t171, i64 %t172, 28
  %t174 = load %"std/prelude/list:List<I64>", ptr %l31
  %t175 = insertvalue %"compiler/fmt:formatter" %t173, %"std/prelude/list:List<I64>" %t174, 29
  %t176 = load %"std/prelude/list:List<I64>", ptr %l32
  %t177 = insertvalue %"compiler/fmt:formatter" %t175, %"std/prelude/list:List<I64>" %t176, 30
  %t178 = load i1, ptr %l33, !tbaa !21
  %t179 = insertvalue %"compiler/fmt:formatter" %t177, i1 %t178, 31
  store %"compiler/fmt:formatter" %t179, ptr %l69
  call void @__olang_scope_close(ptr %s0)
  %t180 = load %"compiler/fmt:formatter", ptr %l69
  store %"compiler/fmt:formatter" %t180, ptr %out
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/fmt:loader" @compiler_2ffmt_3aloader_2ector(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca %"std/prelude/list:List<std/prelude/text:String&>"
  %l3 = alloca %"std/prelude/list:List<std/prelude/text:String&>"
  %l4 = alloca %"std/prelude/list:List<I64>"
  %l5 = alloca %"std/prelude/list:List<std/prelude/text:String&>"
  %l6 = alloca %"std/prelude/list:List<I64>"
  %l7 = alloca { i64, ptr }
  %l8 = alloca %"std/prelude/list:List<std/prelude/text:String&>"
  %l9 = alloca %"std/prelude/list:List<std/prelude/text:String&>"
  %l10 = alloca %"std/prelude/list:List<I64>"
  %l11 = alloca %"std/prelude/list:List<std/prelude/text:String&>"
  %l12 = alloca %"std/prelude/list:List<I64>"
  %l13 = alloca %"compiler/fmt:loader"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/fmt:loader"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t1, ptr %l7, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t2, ptr %l1, !tbaa !27
  %t3 = load ptr, ptr @__olang_prog_scope
  %t4 = call %"std/prelude/list:List<std/prelude/text:String&>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t3)
  store %"std/prelude/list:List<std/prelude/text:String&>" %t4, ptr %l8
  br label %bb1
bb1:
  %t5 = load %"std/prelude/list:List<std/prelude/text:String&>", ptr %l8
  store %"std/prelude/list:List<std/prelude/text:String&>" %t5, ptr %l2
  %t6 = load ptr, ptr @__olang_prog_scope
  %t7 = call %"std/prelude/list:List<std/prelude/text:String&>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t6)
  store %"std/prelude/list:List<std/prelude/text:String&>" %t7, ptr %l9
  br label %bb2
bb2:
  %t8 = load %"std/prelude/list:List<std/prelude/text:String&>", ptr %l9
  store %"std/prelude/list:List<std/prelude/text:String&>" %t8, ptr %l3
  %t9 = load ptr, ptr @__olang_prog_scope
  %t10 = call %"std/prelude/list:List<I64>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t9)
  store %"std/prelude/list:List<I64>" %t10, ptr %l10
  br label %bb3
bb3:
  %t11 = load %"std/prelude/list:List<I64>", ptr %l10
  store %"std/prelude/list:List<I64>" %t11, ptr %l4
  %t12 = load ptr, ptr @__olang_prog_scope
  %t13 = call %"std/prelude/list:List<std/prelude/text:String&>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t12)
  store %"std/prelude/list:List<std/prelude/text:String&>" %t13, ptr %l11
  br label %bb4
bb4:
  %t14 = load %"std/prelude/list:List<std/prelude/text:String&>", ptr %l11
  store %"std/prelude/list:List<std/prelude/text:String&>" %t14, ptr %l5
  %t15 = load ptr, ptr @__olang_prog_scope
  %t16 = call %"std/prelude/list:List<I64>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t15)
  store %"std/prelude/list:List<I64>" %t16, ptr %l12
  br label %bb5
bb5:
  %t17 = load %"std/prelude/list:List<I64>", ptr %l12
  store %"std/prelude/list:List<I64>" %t17, ptr %l6
  %t18 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t19 = insertvalue %"compiler/fmt:loader" undef, { i64, ptr } %t18, 0
  %t20 = load %"std/prelude/list:List<std/prelude/text:String&>", ptr %l2
  %t21 = insertvalue %"compiler/fmt:loader" %t19, %"std/prelude/list:List<std/prelude/text:String&>" %t20, 1
  %t22 = load %"std/prelude/list:List<std/prelude/text:String&>", ptr %l3
  %t23 = insertvalue %"compiler/fmt:loader" %t21, %"std/prelude/list:List<std/prelude/text:String&>" %t22, 2
  %t24 = load %"std/prelude/list:List<I64>", ptr %l4
  %t25 = insertvalue %"compiler/fmt:loader" %t23, %"std/prelude/list:List<I64>" %t24, 3
  %t26 = load %"std/prelude/list:List<std/prelude/text:String&>", ptr %l5
  %t27 = insertvalue %"compiler/fmt:loader" %t25, %"std/prelude/list:List<std/prelude/text:String&>" %t26, 4
  %t28 = load %"std/prelude/list:List<I64>", ptr %l6
  %t29 = insertvalue %"compiler/fmt:loader" %t27, %"std/prelude/list:List<I64>" %t28, 5
  store %"compiler/fmt:loader" %t29, ptr %l13
  call void @__olang_scope_close(ptr %s0)
  %t30 = load %"compiler/fmt:loader", ptr %l13
  store %"compiler/fmt:loader" %t30, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/fmt:loader", ptr %rv
  ret %"compiler/fmt:loader" %rr
}

declare void @__olang_sb_put(ptr, ptr, i64)
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
declare void @__olang_sb_done(ptr)
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
chunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
declare noalias ptr @__olang_scope_alloc_a(ptr, i64, i64)
declare void @__olang_check_failed(ptr)
@.c0 = private unnamed_addr constant [50 x i8] c"compiler/fmt.olang:625: reached unreachable code\0A\00"
@.d1 = private constant [7 x i8] c"olang: "
@.d2 = private constant [17 x i8] c": cannot be read\0A"
@.d3 = private constant [2 x i8] c"-f"
@.d4 = private constant [2 x i8] c"-p"
@.c5 = private unnamed_addr constant [50 x i8] c"compiler/fmt.olang:638: reached unreachable code\0A\00"
@.d6 = private constant [7 x i8] c"olang: "
@.d7 = private constant [20 x i8] c": cannot be written\0A"
@.d8 = private constant [1 x i8] c"\0A"
@.c9 = private unnamed_addr constant [50 x i8] c"compiler/fmt.olang:650: reached unreachable code\0A\00"
@.c10 = private unnamed_addr constant [50 x i8] c"compiler/fmt.olang:651: reached unreachable code\0A\00"
@.c11 = private unnamed_addr constant [49 x i8] c"compiler/fmt.olang:45: reached unreachable code\0A\00"
@.c12 = private unnamed_addr constant [49 x i8] c"compiler/fmt.olang:46: reached unreachable code\0A\00"
@.d13 = private constant [1 x i8] c" "
@.d14 = private constant [0 x i8] c""
define linkonce_odr i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i1 true, ptr %l2, !tbaa !21
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %t1
  %t3 = sext i32 %t2 to i64
  store i64 %t3, ptr %l3, !tbaa !24
  %t4 = load ptr, ptr %l1, !tbaa !29
  %t5 = load i32, ptr %t4
  %t6 = sext i32 %t5 to i64
  store i64 %t6, ptr %l4, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = load i64, ptr %l4, !tbaa !24
  %t9 = icmp eq i64 %t7, %t8
  store i1 %t9, ptr %l5, !tbaa !21
  %t10 = load i1, ptr %l5, !tbaa !21
  br i1 %t10, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb3
bb2:
  br label %bb3
bb3:
  call void @__olang_scope_close(ptr %s0)
  %t11 = load i1, ptr %l2, !tbaa !21
  store i1 %t11, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.c15 = private unnamed_addr constant [51 x i8] c"compiler/fmt.olang:222: slice bounds out of range\0A\00"
@__olang_prog_scope = external thread_local(initialexec) global ptr
define linkonce_odr %"std/prelude/list:List<I64>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List<I64>"
  %s0 = alloca %olang.scope
  %rv = alloca %"std/prelude/list:List<I64>"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List<I64>" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %t1)
  store %"std/prelude/list:List<I64>" %t2, ptr %l0
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"std/prelude/list:List<I64>", ptr %l0
  store %"std/prelude/list:List<I64>" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List<I64>", ptr %rv
  ret %"std/prelude/list:List<I64>" %rr
}

@.c16 = private unnamed_addr constant [50 x i8] c"compiler/fmt.olang:124: reached unreachable code\0A\00"
@.c17 = private unnamed_addr constant [51 x i8] c"compiler/fmt.olang:148: slice bounds out of range\0A\00"
@.d18 = private constant [0 x i8] c""
@.d19 = private constant [0 x i8] c""
@.d20 = private constant [0 x i8] c""
@.d21 = private constant [0 x i8] c""
@.d22 = private constant [0 x i8] c""
@.d23 = private constant [0 x i8] c""
@.d24 = private constant [0 x i8] c""
@.d25 = private constant [1 x i8] c" "
@.d26 = private constant [0 x i8] c""
@.d27 = private constant [0 x i8] c""
@.d28 = private constant [1 x i8] c" "
@.d29 = private constant [0 x i8] c""
@.d30 = private constant [0 x i8] c""
@.d31 = private constant [0 x i8] c""
@.d32 = private constant [1 x i8] c" "
@.d33 = private constant [0 x i8] c""
@.d34 = private constant [1 x i8] c" "
@.d35 = private constant [0 x i8] c""
@.d36 = private constant [1 x i8] c" "
@.d37 = private constant [0 x i8] c""
@.d38 = private constant [1 x i8] c" "
@.c39 = private unnamed_addr constant [51 x i8] c"compiler/fmt.olang:109: slice bounds out of range\0A\00"
@.c40 = private unnamed_addr constant [51 x i8] c"compiler/fmt.olang:327: slice bounds out of range\0A\00"
@.d41 = private constant [1 x i8] c"="
@.c42 = private unnamed_addr constant [51 x i8] c"compiler/fmt.olang:328: slice bounds out of range\0A\00"
@.d43 = private constant [2 x i8] c" ="
@.c44 = private unnamed_addr constant [51 x i8] c"compiler/fmt.olang:566: slice bounds out of range\0A\00"
@.d45 = private constant [4 x i8] c"    "
@.c46 = private unnamed_addr constant [51 x i8] c"compiler/fmt.olang:577: slice bounds out of range\0A\00"
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
@.d47 = private constant [1 x i8] c" "
@.d48 = private constant [0 x i8] c""
@.d49 = private constant [1 x i8] c"."
@.c50 = private unnamed_addr constant [50 x i8] c"compiler/fmt.olang:710: reached unreachable code\0A\00"
@.c51 = private unnamed_addr constant [50 x i8] c"compiler/fmt.olang:714: reached unreachable code\0A\00"
define linkonce_odr %"std/prelude/list:List<std/prelude/text:String&>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List<std/prelude/text:String&>"
  %s0 = alloca %olang.scope
  %rv = alloca %"std/prelude/list:List<std/prelude/text:String&>"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List<std/prelude/text:String&>" @std_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %t1)
  store %"std/prelude/list:List<std/prelude/text:String&>" %t2, ptr %l0
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"std/prelude/list:List<std/prelude/text:String&>", ptr %l0
  store %"std/prelude/list:List<std/prelude/text:String&>" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List<std/prelude/text:String&>", ptr %rv
  ret %"std/prelude/list:List<std/prelude/text:String&>" %rr
}

@.c52 = private unnamed_addr constant [51 x i8] c"compiler/fmt.olang:729: slice bounds out of range\0A\00"
@.d53 = private constant [0 x i8] c""
@.c54 = private unnamed_addr constant [51 x i8] c"compiler/fmt.olang:736: slice bounds out of range\0A\00"
@.c55 = private unnamed_addr constant [51 x i8] c"compiler/fmt.olang:740: slice bounds out of range\0A\00"
@.d56 = private constant [0 x i8] c""
@.d57 = private constant [0 x i8] c""
@.d58 = private constant [0 x i8] c""
@.d59 = private constant [1 x i8] c" "
@.d60 = private constant [0 x i8] c""
@.d61 = private constant [0 x i8] c""
@.d62 = private constant [0 x i8] c""
@.d63 = private constant [5 x i8] c"Array"
@.d64 = private constant [0 x i8] c""
@.d65 = private constant [7 x i8] c"prelude"
@.d66 = private constant [0 x i8] c""
@.d67 = private constant [0 x i8] c""
@.d68 = private constant [0 x i8] c""
@.d69 = private constant [0 x i8] c""
@.c70 = private unnamed_addr constant [50 x i8] c"compiler/fmt.olang:689: reached unreachable code\0A\00"
@.d71 = private constant [1 x i8] c" "
@.d72 = private constant [6 x i8] c".olang"
@.d73 = private constant [0 x i8] c""
@.d74 = private constant [0 x i8] c""
@.d75 = private constant [0 x i8] c""
@.d76 = private constant [0 x i8] c""
@.c77 = private unnamed_addr constant [51 x i8] c"compiler/fmt.olang:693: slice bounds out of range\0A\00"
@.c78 = private unnamed_addr constant [51 x i8] c"compiler/fmt.olang:702: slice bounds out of range\0A\00"
@.d79 = private constant [1 x i8] c"."
@.d80 = private constant [0 x i8] c""
@.d81 = private constant [4 x i8] c"std/"
@.c82 = private unnamed_addr constant [51 x i8] c"compiler/fmt.olang:704: slice bounds out of range\0A\00"
@.d83 = private constant [0 x i8] c""
@.d84 = private constant [0 x i8] c""
@.d85 = private constant [0 x i8] c""
@.d86 = private constant [0 x i8] c""
@.d87 = private constant [6 x i8] c".olang"
@.d88 = private constant [0 x i8] c""
@.d89 = private constant [0 x i8] c""
@.d90 = private constant [0 x i8] c""
@.d91 = private constant [0 x i8] c""
@.d92 = private constant [6 x i8] c".olang"
@.c93 = private unnamed_addr constant [50 x i8] c"compiler/fmt.olang:71: array length out of range\0A\00"
@.c94 = private unnamed_addr constant [50 x i8] c"compiler/fmt.olang:72: array length out of range\0A\00"
define linkonce_odr %"std/prelude/list:List<Bool>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cBool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List<Bool>"
  %s0 = alloca %olang.scope
  %rv = alloca %"std/prelude/list:List<Bool>"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List<Bool>" @std_2fprelude_2flist_3aList_3cBool_3e_2ector(ptr %t1)
  store %"std/prelude/list:List<Bool>" %t2, ptr %l0
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"std/prelude/list:List<Bool>", ptr %l0
  store %"std/prelude/list:List<Bool>" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List<Bool>", ptr %rv
  ret %"std/prelude/list:List<Bool>" %rr
}

define linkonce_odr %"std/prelude/text:StringBuilder" @olang_2eHelperKind_2eZero_2estd_2fprelude_2ftext_3aStringBuilder(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/text:StringBuilder"
  %s0 = alloca %olang.scope
  %rv = alloca %"std/prelude/text:StringBuilder"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %t1)
  store %"std/prelude/text:StringBuilder" %t2, ptr %l0
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"std/prelude/text:StringBuilder", ptr %l0
  store %"std/prelude/text:StringBuilder" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/text:StringBuilder", ptr %rv
  ret %"std/prelude/text:StringBuilder" %rr
}

@.c95 = private unnamed_addr constant [50 x i8] c"compiler/fmt.olang:94: array length out of range\0A\00"
declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare %"compiler/source:Source" @compiler_2fsource_3aSource_2ector(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/source:Names" @compiler_2fsource_3aNames_2ector(ptr %v0)
declare void @compiler_2fdiag_3aDiagnostics_2ector(ptr %out, ptr %v0, i1 %a0)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eAddFile(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, i1 %a3)
declare %"compiler/scan:Tokens" @compiler_2fscan_2eScan(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2fscan_2ecompiler_2fscan_3aDiag_2eRule(ptr %v0, %"compiler/scan:Diag" %a0)
declare { i64, ptr } @compiler_2fscan_2ecompiler_2fscan_3aDiag_2eMessage(ptr %v0, %"compiler/scan:Diag" %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v1, ptr %v2, i32 %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, %"compiler/msgs:Msg" %a2)
declare void @compiler_2fparse_3aParser_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4, i64 %a5)
declare { i64, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eFile(ptr %v0, ptr %a0)
declare %"std/prelude/list:List<compiler/diag:Said>" @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eAllSaid(ptr %v0, ptr %v1, ptr %a0)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fdiag_3aSaid_3e_2eLen_3ccompiler_2fdiag_3aSaid_3e(ptr %v0, ptr %a0)
declare { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eRender(ptr %v0, ptr %v1, ptr %a0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2funparse_2eHeldBranches(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, ptr %a1, { i64, ptr } %a2, ptr %a3)
declare %"std/io:Writer" @std_2fio_3aWriter_2ector(ptr %v0, i32 %a0, i64 %a1)
declare { i32, %"compiler/source:Source" } @compiler_2fsource_2eRead(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare i1 @compiler_2fdiag_2eColorWanted()
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i32 @std_2fos_2eWriteFile(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i32 @std_2fio_2estd_2fio_3aWriter_2eFlush(ptr %v0, ptr %a0)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/parse:Oracle" @compiler_2fparse_3aOracle_2ector(ptr %v0)
@G_2ecompiler_2ftoken_2eSpace = external global i8
declare i1 @compiler_2ftoken_2ecompiler_2ftoken_3aToken_2eHas(%"compiler/token:Token" %a0, i8 %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
@G_2ecompiler_2ftoken_2eLineBreak = external global i8
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %a0, i1 %a1)
declare i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eLen(ptr %v0, ptr %a0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %a0, i8 %a1)
declare i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eTruncate_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eTruncate_3cBool_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i32, i64 } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %a0)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eSplit(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare void @compiler_2fparse_2ecompiler_2fparse_3aOracle_2eAdd(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, { i64, ptr } %a2, { i64, ptr } %a3)
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i32, { i64, ptr } } @std_2fos_2eRealPath(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %v0, ptr %a0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2ffilepath_2eBase(ptr %v0, { i64, ptr } %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsUpper(i8 %a0)
declare { i64, ptr } @std_2ffilepath_2eJoin(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %v6, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, { i64, ptr } %a4, { i64, ptr } %a5)
declare { i32, { i64, ptr } } @std_2fos_2eReadDir(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindByte(ptr %v0, { i64, ptr } %a0, i8 %a1)
declare i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2ffilepath_2eDir(ptr %v0, { i64, ptr } %a0)
declare %"std/prelude/list:List<I64>" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %v0)
declare %"std/prelude/list:List<std/prelude/text:String&>" @std_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0)
declare %"std/prelude/list:List<Bool>" @std_2fprelude_2flist_3aList_3cBool_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
