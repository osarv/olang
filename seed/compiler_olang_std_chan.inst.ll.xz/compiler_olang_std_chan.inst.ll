; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc" = type { i64, { i64, ptr }, i64, i64, i64, i1, i64, i64, i1, [8 x i64], [8 x i64], [8 x i64] }
%"std/chan:reading" = type { i32, double }
define dso_local void @std_2fchan_2eClose_3cI32_3e(ptr %v0, ptr %a0) #0 {
entry:
  tail call void @std_2fchan_2eClose_3cI64_3e(ptr %v0, ptr %a0)
  ret void
}

define dso_local { i32, i32 } @std_2fchan_2eRecvUntil_3cI32_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca [2 x i64]
  %l3 = alloca i32
  %l9 = alloca i32
  %l13 = alloca i1
  %l19 = alloca i1
  %l24 = alloca i32
  %l26 = alloca i32
  %l42 = alloca i32
  %l50 = alloca i32
  %l53 = alloca i32
  %l58 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca { i32, i32 }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = insertvalue [2 x i64] undef, i64 0, 0
  %t2 = insertvalue [2 x i64] %t1, i64 0, 1
  store [2 x i64] %t2, ptr %l2
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t6 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t4, i32 0, i32 9
  %t8 = insertvalue { i64, ptr } undef, i64 8, 0
  %t9 = insertvalue { i64, ptr } %t8, ptr %t6, 1
  %t12 = extractvalue { i64, ptr } %t9, 1
  %t13 = extractvalue { i64, ptr } %t9, 0
  %t14 = call i32 @pthread_mutex_lock(ptr %t12)
  store i32 %t14, ptr %l9
  br label %bb1
bb1:
  br label %bb2
bb2:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t15, i32 0, i32 4
  %t18 = load i64, ptr %t17, !tbaa !24
  %t20 = icmp eq i64 %t18, 0
  br i1 %t20, label %bb3, label %bb4
bb3:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t22, i32 0, i32 8
  %t25 = load i1, ptr %t24, !tbaa !21
  %t27 = xor i1 %t25, true
  store i1 %t27, ptr %l13, !tbaa !21
  br label %bb5
bb4:
  store i1 false, ptr %l13, !tbaa !21
  br label %bb5
bb5:
  %t29 = load i1, ptr %l13, !tbaa !21
  %t30 = xor i1 %t29, true
  br i1 %t30, label %bb6, label %bb7
bb6:
  br label %bb20
bb7:
  br label %bb8
bb8:
  %t32 = load ptr, ptr %l1, !tbaa !29
  %t34 = call i1 @std_2fcancel_2estd_2fcancel_3aToken_2eCancelled(ptr %v1, ptr %t32)
  store i1 %t34, ptr %l19
  br label %bb9
bb9:
  %t35 = load i1, ptr %l19, !tbaa !21
  br i1 %t35, label %bb10, label %bb11
bb10:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t36, i32 0, i32 9
  %t40 = insertvalue { i64, ptr } undef, i64 8, 0
  %t41 = insertvalue { i64, ptr } %t40, ptr %t38, 1
  %t44 = extractvalue { i64, ptr } %t41, 1
  %t45 = extractvalue { i64, ptr } %t41, 0
  %t46 = call i32 @pthread_mutex_unlock(ptr %t44)
  store i32 %t46, ptr %l24
  br label %bb12
bb11:
  br label %bb16
bb12:
  %t47 = load ptr, ptr %l1, !tbaa !29
  %t49 = call i32 @std_2fcancel_2estd_2fcancel_3aToken_2eReason(ptr %v1, ptr %t47)
  store i32 %t49, ptr %l26
  %t50 = icmp ne i32 %t49, 0
  br i1 %t50, label %bb14, label %ok.51
ok.51:
  br label %bb13
bb13:
  br label %bb15
bb14:
  %t52 = load i32, ptr %l26, !tbaa !23
  %t53 = lshr i32 %t52, 16
  %t54 = and i32 %t52, 65535
  %t55 = icmp eq i32 %t53, 1
  %t56 = select i1 %t55, i32 1, i32 0
  %t57 = icmp eq i32 %t52, 0
  %t58 = shl i32 %t56, 16
  %t59 = or i32 %t58, %t54
  %t60 = select i1 %t57, i32 0, i32 %t59
  call void @__olang_scope_close(ptr %s0)
  %t62 = insertvalue { i32, i32 } zeroinitializer, i32 %t60, 0
  store { i32, i32 } %t62, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  %t63 = load ptr, ptr %l1, !tbaa !29
  %t65 = insertvalue { i64, ptr } undef, i64 2, 0
  %t66 = insertvalue { i64, ptr } %t65, ptr %l2, 1
  call void @std_2fcancel_2estd_2fcancel_3aToken_2eWakeAt(ptr %v1, ptr %s0, ptr %t63, { i64, ptr } %t66)
  br label %bb17
bb17:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t69, i32 0, i32 10
  %t73 = insertvalue { i64, ptr } undef, i64 8, 0
  %t74 = insertvalue { i64, ptr } %t73, ptr %t71, 1
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t76, i32 0, i32 9
  %t80 = insertvalue { i64, ptr } undef, i64 8, 0
  %t81 = insertvalue { i64, ptr } %t80, ptr %t78, 1
  %t84 = insertvalue { i64, ptr } undef, i64 2, 0
  %t85 = insertvalue { i64, ptr } %t84, ptr %l2, 1
  %t88 = extractvalue { i64, ptr } %t74, 1
  %t89 = extractvalue { i64, ptr } %t74, 0
  %t91 = extractvalue { i64, ptr } %t81, 1
  %t92 = extractvalue { i64, ptr } %t81, 0
  %t94 = extractvalue { i64, ptr } %t85, 1
  %t95 = extractvalue { i64, ptr } %t85, 0
  %t96 = call i32 @pthread_cond_timedwait(ptr %t88, ptr %t91, ptr %t94)
  store i32 %t96, ptr %l42
  br label %bb18
bb18:
  br label %bb19
bb19:
  br label %bb2
bb20:
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t97, i32 0, i32 4
  %t100 = load i64, ptr %t99, !tbaa !24
  %t102 = icmp eq i64 %t100, 0
  br i1 %t102, label %bb21, label %bb22
bb21:
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t106 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t104, i32 0, i32 9
  %t108 = insertvalue { i64, ptr } undef, i64 8, 0
  %t109 = insertvalue { i64, ptr } %t108, ptr %t106, 1
  %t112 = extractvalue { i64, ptr } %t109, 1
  %t113 = extractvalue { i64, ptr } %t109, 0
  %t114 = call i32 @pthread_mutex_unlock(ptr %t112)
  store i32 %t114, ptr %l50
  br label %bb23
bb22:
  br label %bb24
bb23:
  call void @__olang_scope_close(ptr %s0)
  %t116 = insertvalue { i32, i32 } zeroinitializer, i32 131072, 0
  store { i32, i32 } %t116, ptr %rv
  br label %ret
bb24:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = call i32 @std_2fchan_2eoldest_3cI32_3e(ptr %v0, ptr %t117)
  store i32 %t119, ptr %l53
  br label %bb25
bb25:
  %t120 = load i32, ptr %l53, !tbaa !23
  store i32 %t120, ptr %l3, !tbaa !23
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t123 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t121, i32 0, i32 9
  %t125 = insertvalue { i64, ptr } undef, i64 8, 0
  %t126 = insertvalue { i64, ptr } %t125, ptr %t123, 1
  %t129 = extractvalue { i64, ptr } %t126, 1
  %t130 = extractvalue { i64, ptr } %t126, 0
  %t131 = call i32 @pthread_mutex_unlock(ptr %t129)
  store i32 %t131, ptr %l58
  br label %bb26
bb26:
  %t132 = load i32, ptr %l3, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  %t134 = insertvalue { i32, i32 } zeroinitializer, i32 %t132, 1
  store { i32, i32 } %t134, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i32 }, ptr %rv
  ret { i32, i32 } %rr
}

define dso_local { i32, i32 } @std_2fchan_2eRecv_3cI32_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l6 = alloca i32
  %l10 = alloca i1
  %l23 = alloca i32
  %l31 = alloca i32
  %l34 = alloca i32
  %l39 = alloca i32
  %rv = alloca { i32, i32 }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t1, i32 0, i32 9
  %t5 = insertvalue { i64, ptr } undef, i64 8, 0
  %t6 = insertvalue { i64, ptr } %t5, ptr %t3, 1
  %t9 = extractvalue { i64, ptr } %t6, 1
  %t10 = extractvalue { i64, ptr } %t6, 0
  %t11 = call i32 @pthread_mutex_lock(ptr %t9)
  store i32 %t11, ptr %l6
  br label %bb1
bb1:
  br label %bb2
bb2:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t12, i32 0, i32 4
  %t15 = load i64, ptr %t14, !tbaa !24
  %t17 = icmp eq i64 %t15, 0
  br i1 %t17, label %bb3, label %bb4
bb3:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t19, i32 0, i32 8
  %t22 = load i1, ptr %t21, !tbaa !21
  %t24 = xor i1 %t22, true
  store i1 %t24, ptr %l10, !tbaa !21
  br label %bb5
bb4:
  store i1 false, ptr %l10, !tbaa !21
  br label %bb5
bb5:
  %t26 = load i1, ptr %l10, !tbaa !21
  %t27 = xor i1 %t26, true
  br i1 %t27, label %bb6, label %bb7
bb6:
  br label %bb11
bb7:
  br label %bb8
bb8:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t29, i32 0, i32 10
  %t33 = insertvalue { i64, ptr } undef, i64 8, 0
  %t34 = insertvalue { i64, ptr } %t33, ptr %t31, 1
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t36, i32 0, i32 9
  %t40 = insertvalue { i64, ptr } undef, i64 8, 0
  %t41 = insertvalue { i64, ptr } %t40, ptr %t38, 1
  %t44 = extractvalue { i64, ptr } %t34, 1
  %t45 = extractvalue { i64, ptr } %t34, 0
  %t47 = extractvalue { i64, ptr } %t41, 1
  %t48 = extractvalue { i64, ptr } %t41, 0
  %t49 = call i32 @pthread_cond_wait(ptr %t44, ptr %t47)
  store i32 %t49, ptr %l23
  br label %bb9
bb9:
  br label %bb10
bb10:
  br label %bb2
bb11:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t50, i32 0, i32 4
  %t53 = load i64, ptr %t52, !tbaa !24
  %t55 = icmp eq i64 %t53, 0
  br i1 %t55, label %bb12, label %bb13
bb12:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t57, i32 0, i32 9
  %t61 = insertvalue { i64, ptr } undef, i64 8, 0
  %t62 = insertvalue { i64, ptr } %t61, ptr %t59, 1
  %t65 = extractvalue { i64, ptr } %t62, 1
  %t66 = extractvalue { i64, ptr } %t62, 0
  %t67 = call i32 @pthread_mutex_unlock(ptr %t65)
  store i32 %t67, ptr %l31
  br label %bb14
bb13:
  br label %bb15
bb14:
  %t69 = insertvalue { i32, i32 } zeroinitializer, i32 65536, 0
  store { i32, i32 } %t69, ptr %rv
  br label %ret
bb15:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = call i32 @std_2fchan_2eoldest_3cI32_3e(ptr %v0, ptr %t70)
  store i32 %t72, ptr %l34
  br label %bb16
bb16:
  %t73 = load i32, ptr %l34, !tbaa !23
  store i32 %t73, ptr %l1, !tbaa !23
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t74, i32 0, i32 9
  %t78 = insertvalue { i64, ptr } undef, i64 8, 0
  %t79 = insertvalue { i64, ptr } %t78, ptr %t76, 1
  %t82 = extractvalue { i64, ptr } %t79, 1
  %t83 = extractvalue { i64, ptr } %t79, 0
  %t84 = call i32 @pthread_mutex_unlock(ptr %t82)
  store i32 %t84, ptr %l39
  br label %bb17
bb17:
  %t85 = load i32, ptr %l1, !tbaa !23
  %t87 = insertvalue { i32, i32 } zeroinitializer, i32 %t85, 1
  store { i32, i32 } %t87, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i32 }, ptr %rv
  ret { i32, i32 } %rr
}

define dso_local { i32, %"std/chan:reading" } @std_2fchan_2eRecv_3cstd_2fchan_3areading_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"std/chan:reading"
  %l6 = alloca i32
  %l10 = alloca i1
  %l23 = alloca i32
  %l31 = alloca i32
  %l34 = alloca %"std/chan:reading"
  %l39 = alloca i32
  %rv = alloca { i32, %"std/chan:reading" }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t1, i32 0, i32 9
  %t5 = insertvalue { i64, ptr } undef, i64 8, 0
  %t6 = insertvalue { i64, ptr } %t5, ptr %t3, 1
  %t9 = extractvalue { i64, ptr } %t6, 1
  %t10 = extractvalue { i64, ptr } %t6, 0
  %t11 = call i32 @pthread_mutex_lock(ptr %t9)
  store i32 %t11, ptr %l6
  br label %bb1
bb1:
  br label %bb2
bb2:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t12, i32 0, i32 4
  %t15 = load i64, ptr %t14, !tbaa !24
  %t17 = icmp eq i64 %t15, 0
  br i1 %t17, label %bb3, label %bb4
bb3:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t19, i32 0, i32 8
  %t22 = load i1, ptr %t21, !tbaa !21
  %t24 = xor i1 %t22, true
  store i1 %t24, ptr %l10, !tbaa !21
  br label %bb5
bb4:
  store i1 false, ptr %l10, !tbaa !21
  br label %bb5
bb5:
  %t26 = load i1, ptr %l10, !tbaa !21
  %t27 = xor i1 %t26, true
  br i1 %t27, label %bb6, label %bb7
bb6:
  br label %bb11
bb7:
  br label %bb8
bb8:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t29, i32 0, i32 10
  %t33 = insertvalue { i64, ptr } undef, i64 8, 0
  %t34 = insertvalue { i64, ptr } %t33, ptr %t31, 1
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t36, i32 0, i32 9
  %t40 = insertvalue { i64, ptr } undef, i64 8, 0
  %t41 = insertvalue { i64, ptr } %t40, ptr %t38, 1
  %t44 = extractvalue { i64, ptr } %t34, 1
  %t45 = extractvalue { i64, ptr } %t34, 0
  %t47 = extractvalue { i64, ptr } %t41, 1
  %t48 = extractvalue { i64, ptr } %t41, 0
  %t49 = call i32 @pthread_cond_wait(ptr %t44, ptr %t47)
  store i32 %t49, ptr %l23
  br label %bb9
bb9:
  br label %bb10
bb10:
  br label %bb2
bb11:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t50, i32 0, i32 4
  %t53 = load i64, ptr %t52, !tbaa !24
  %t55 = icmp eq i64 %t53, 0
  br i1 %t55, label %bb12, label %bb13
bb12:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t57, i32 0, i32 9
  %t61 = insertvalue { i64, ptr } undef, i64 8, 0
  %t62 = insertvalue { i64, ptr } %t61, ptr %t59, 1
  %t65 = extractvalue { i64, ptr } %t62, 1
  %t66 = extractvalue { i64, ptr } %t62, 0
  %t67 = call i32 @pthread_mutex_unlock(ptr %t65)
  store i32 %t67, ptr %l31
  br label %bb14
bb13:
  br label %bb15
bb14:
  %t69 = insertvalue { i32, %"std/chan:reading" } zeroinitializer, i32 65536, 0
  store { i32, %"std/chan:reading" } %t69, ptr %rv
  br label %ret
bb15:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = call %"std/chan:reading" @std_2fchan_2eoldest_3cstd_2fchan_3areading_3e(ptr %v0, ptr %t70)
  store %"std/chan:reading" %t72, ptr %l34
  br label %bb16
bb16:
  %t73 = load %"std/chan:reading", ptr %l34
  store %"std/chan:reading" %t73, ptr %l1
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t74, i32 0, i32 9
  %t78 = insertvalue { i64, ptr } undef, i64 8, 0
  %t79 = insertvalue { i64, ptr } %t78, ptr %t76, 1
  %t82 = extractvalue { i64, ptr } %t79, 1
  %t83 = extractvalue { i64, ptr } %t79, 0
  %t84 = call i32 @pthread_mutex_unlock(ptr %t82)
  store i32 %t84, ptr %l39
  br label %bb17
bb17:
  %t85 = load %"std/chan:reading", ptr %l1
  %t87 = insertvalue { i32, %"std/chan:reading" } zeroinitializer, %"std/chan:reading" %t85, 1
  store { i32, %"std/chan:reading" } %t87, ptr %rv
  br label %ret
ret:
  %rr = load { i32, %"std/chan:reading" }, ptr %rv
  ret { i32, %"std/chan:reading" } %rr
}

define dso_local i32 @std_2fchan_2eSend_3cI32_3e(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l7 = alloca i32
  %l13 = alloca i1
  %l26 = alloca i32
  %l28 = alloca i32
  %l32 = alloca i64
  %l35 = alloca i1
  %l40 = alloca i1
  %l53 = alloca i32
  %l56 = alloca i1
  %l63 = alloca i32
  %l69 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t1, i32 0, i32 9
  %t5 = insertvalue { i64, ptr } undef, i64 8, 0
  %t6 = insertvalue { i64, ptr } %t5, ptr %t3, 1
  %t9 = extractvalue { i64, ptr } %t6, 1
  %t10 = extractvalue { i64, ptr } %t6, 0
  %t11 = call i32 @pthread_mutex_lock(ptr %t9)
  store i32 %t11, ptr %l7
  br label %bb1
bb1:
  br label %bb2
bb2:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t12, i32 0, i32 4
  %t15 = load i64, ptr %t14, !tbaa !24
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t16, i32 0, i32 0
  %t19 = load i64, ptr %t18, !tbaa !24
  %t22 = icmp eq i64 %t15, %t19
  br i1 %t22, label %bb3, label %bb4
bb3:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t24, i32 0, i32 8
  %t27 = load i1, ptr %t26, !tbaa !21
  %t29 = xor i1 %t27, true
  store i1 %t29, ptr %l13, !tbaa !21
  br label %bb5
bb4:
  store i1 false, ptr %l13, !tbaa !21
  br label %bb5
bb5:
  %t31 = load i1, ptr %l13, !tbaa !21
  %t32 = xor i1 %t31, true
  br i1 %t32, label %bb6, label %bb7
bb6:
  br label %bb11
bb7:
  br label %bb8
bb8:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t34, i32 0, i32 11
  %t38 = insertvalue { i64, ptr } undef, i64 8, 0
  %t39 = insertvalue { i64, ptr } %t38, ptr %t36, 1
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t41, i32 0, i32 9
  %t45 = insertvalue { i64, ptr } undef, i64 8, 0
  %t46 = insertvalue { i64, ptr } %t45, ptr %t43, 1
  %t49 = extractvalue { i64, ptr } %t39, 1
  %t50 = extractvalue { i64, ptr } %t39, 0
  %t52 = extractvalue { i64, ptr } %t46, 1
  %t53 = extractvalue { i64, ptr } %t46, 0
  %t54 = call i32 @pthread_cond_wait(ptr %t49, ptr %t52)
  store i32 %t54, ptr %l26
  br label %bb9
bb9:
  br label %bb10
bb10:
  br label %bb2
bb11:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = call i32 @std_2fchan_2esendOpen_3cI64_3e(ptr %v0, ptr %t55)
  store i32 %t57, ptr %l28
  %t58 = icmp ne i32 %t57, 0
  br i1 %t58, label %bb13, label %ok.59
ok.59:
  br label %bb12
bb12:
  br label %bb14
bb13:
  %t60 = load i32, ptr %l28, !tbaa !23
  %t61 = lshr i32 %t60, 16
  %t62 = and i32 %t60, 65535
  %t63 = icmp eq i32 %t61, 1
  %t64 = select i1 %t63, i32 1, i32 0
  %t65 = icmp eq i32 %t60, 0
  %t66 = shl i32 %t64, 16
  %t67 = or i32 %t66, %t62
  %t68 = select i1 %t65, i32 0, i32 %t67
  store i32 %t68, ptr %rv
  br label %ret
bb14:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t74 = call i64 @std_2fchan_2eplace_3cI32_3e(ptr %v0, ptr %t70, i32 %a1)
  store i64 %t74, ptr %l32
  br label %bb15
bb15:
  %t75 = load i64, ptr %l32, !tbaa !24
  store i64 %t75, ptr %l2, !tbaa !24
  br label %bb16
bb16:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t76, i32 0, i32 5
  %t79 = load i1, ptr %t78, !tbaa !21
  br i1 %t79, label %bb17, label %bb18
bb17:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t81, i32 0, i32 7
  %t84 = load i64, ptr %t83, !tbaa !24
  %t85 = load i64, ptr %l2, !tbaa !24
  %t88 = icmp sle i64 %t84, %t85
  store i1 %t88, ptr %l35, !tbaa !21
  br label %bb19
bb18:
  store i1 false, ptr %l35, !tbaa !21
  br label %bb19
bb19:
  %t90 = load i1, ptr %l35, !tbaa !21
  br i1 %t90, label %bb20, label %bb21
bb20:
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t93 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t91, i32 0, i32 8
  %t94 = load i1, ptr %t93, !tbaa !21
  %t96 = xor i1 %t94, true
  store i1 %t96, ptr %l40, !tbaa !21
  br label %bb22
bb21:
  store i1 false, ptr %l40, !tbaa !21
  br label %bb22
bb22:
  %t98 = load i1, ptr %l40, !tbaa !21
  %t99 = xor i1 %t98, true
  br i1 %t99, label %bb23, label %bb24
bb23:
  br label %bb28
bb24:
  br label %bb25
bb25:
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t103 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t101, i32 0, i32 11
  %t105 = insertvalue { i64, ptr } undef, i64 8, 0
  %t106 = insertvalue { i64, ptr } %t105, ptr %t103, 1
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t108, i32 0, i32 9
  %t112 = insertvalue { i64, ptr } undef, i64 8, 0
  %t113 = insertvalue { i64, ptr } %t112, ptr %t110, 1
  %t116 = extractvalue { i64, ptr } %t106, 1
  %t117 = extractvalue { i64, ptr } %t106, 0
  %t119 = extractvalue { i64, ptr } %t113, 1
  %t120 = extractvalue { i64, ptr } %t113, 0
  %t121 = call i32 @pthread_cond_wait(ptr %t116, ptr %t119)
  store i32 %t121, ptr %l53
  br label %bb26
bb26:
  br label %bb27
bb27:
  br label %bb16
bb28:
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t124 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t122, i32 0, i32 5
  %t125 = load i1, ptr %t124, !tbaa !21
  br i1 %t125, label %bb29, label %bb30
bb29:
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t129 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t127, i32 0, i32 7
  %t130 = load i64, ptr %t129, !tbaa !24
  %t131 = load i64, ptr %l2, !tbaa !24
  %t134 = icmp sle i64 %t130, %t131
  store i1 %t134, ptr %l56, !tbaa !21
  br label %bb31
bb30:
  store i1 false, ptr %l56, !tbaa !21
  br label %bb31
bb31:
  %t136 = load i1, ptr %l56, !tbaa !21
  br i1 %t136, label %bb32, label %bb33
bb32:
  %t137 = load ptr, ptr %l0, !tbaa !29
  call void @std_2fchan_2ewithdraw_3cI64_3e(ptr %v0, ptr %t137)
  br label %bb34
bb33:
  br label %bb38
bb34:
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t141 = call i32 @std_2fchan_2esendOpen_3cI64_3e(ptr %v0, ptr %t139)
  store i32 %t141, ptr %l63
  %t142 = icmp ne i32 %t141, 0
  br i1 %t142, label %bb36, label %ok.143
ok.143:
  br label %bb35
bb35:
  br label %bb37
bb36:
  %t144 = load i32, ptr %l63, !tbaa !23
  %t145 = lshr i32 %t144, 16
  %t146 = and i32 %t144, 65535
  %t147 = icmp eq i32 %t145, 1
  %t148 = select i1 %t147, i32 1, i32 0
  %t149 = icmp eq i32 %t144, 0
  %t150 = shl i32 %t148, 16
  %t151 = or i32 %t150, %t146
  %t152 = select i1 %t149, i32 0, i32 %t151
  store i32 %t152, ptr %rv
  br label %ret
bb37:
  br label %bb38
bb38:
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t156 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t154, i32 0, i32 9
  %t158 = insertvalue { i64, ptr } undef, i64 8, 0
  %t159 = insertvalue { i64, ptr } %t158, ptr %t156, 1
  %t162 = extractvalue { i64, ptr } %t159, 1
  %t163 = extractvalue { i64, ptr } %t159, 0
  %t164 = call i32 @pthread_mutex_unlock(ptr %t162)
  store i32 %t164, ptr %l69
  br label %bb39
bb39:
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @std_2fchan_2eSend_3cstd_2fchan_3areading_3e(ptr %v0, ptr %a0, %"std/chan:reading" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l7 = alloca i32
  %l13 = alloca i1
  %l26 = alloca i32
  %l28 = alloca i32
  %l32 = alloca i64
  %l35 = alloca i1
  %l40 = alloca i1
  %l53 = alloca i32
  %l56 = alloca i1
  %l63 = alloca i32
  %l69 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t1, i32 0, i32 9
  %t5 = insertvalue { i64, ptr } undef, i64 8, 0
  %t6 = insertvalue { i64, ptr } %t5, ptr %t3, 1
  %t9 = extractvalue { i64, ptr } %t6, 1
  %t10 = extractvalue { i64, ptr } %t6, 0
  %t11 = call i32 @pthread_mutex_lock(ptr %t9)
  store i32 %t11, ptr %l7
  br label %bb1
bb1:
  br label %bb2
bb2:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t12, i32 0, i32 4
  %t15 = load i64, ptr %t14, !tbaa !24
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t16, i32 0, i32 0
  %t19 = load i64, ptr %t18, !tbaa !24
  %t22 = icmp eq i64 %t15, %t19
  br i1 %t22, label %bb3, label %bb4
bb3:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t24, i32 0, i32 8
  %t27 = load i1, ptr %t26, !tbaa !21
  %t29 = xor i1 %t27, true
  store i1 %t29, ptr %l13, !tbaa !21
  br label %bb5
bb4:
  store i1 false, ptr %l13, !tbaa !21
  br label %bb5
bb5:
  %t31 = load i1, ptr %l13, !tbaa !21
  %t32 = xor i1 %t31, true
  br i1 %t32, label %bb6, label %bb7
bb6:
  br label %bb11
bb7:
  br label %bb8
bb8:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t34, i32 0, i32 11
  %t38 = insertvalue { i64, ptr } undef, i64 8, 0
  %t39 = insertvalue { i64, ptr } %t38, ptr %t36, 1
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t41, i32 0, i32 9
  %t45 = insertvalue { i64, ptr } undef, i64 8, 0
  %t46 = insertvalue { i64, ptr } %t45, ptr %t43, 1
  %t49 = extractvalue { i64, ptr } %t39, 1
  %t50 = extractvalue { i64, ptr } %t39, 0
  %t52 = extractvalue { i64, ptr } %t46, 1
  %t53 = extractvalue { i64, ptr } %t46, 0
  %t54 = call i32 @pthread_cond_wait(ptr %t49, ptr %t52)
  store i32 %t54, ptr %l26
  br label %bb9
bb9:
  br label %bb10
bb10:
  br label %bb2
bb11:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = call i32 @std_2fchan_2esendOpen_3cI64_3e(ptr %v0, ptr %t55)
  store i32 %t57, ptr %l28
  %t58 = icmp ne i32 %t57, 0
  br i1 %t58, label %bb13, label %ok.59
ok.59:
  br label %bb12
bb12:
  br label %bb14
bb13:
  %t60 = load i32, ptr %l28, !tbaa !23
  %t61 = lshr i32 %t60, 16
  %t62 = and i32 %t60, 65535
  %t63 = icmp eq i32 %t61, 1
  %t64 = select i1 %t63, i32 1, i32 0
  %t65 = icmp eq i32 %t60, 0
  %t66 = shl i32 %t64, 16
  %t67 = or i32 %t66, %t62
  %t68 = select i1 %t65, i32 0, i32 %t67
  store i32 %t68, ptr %rv
  br label %ret
bb14:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t74 = call i64 @std_2fchan_2eplace_3cstd_2fchan_3areading_3e(ptr %v0, ptr %t70, %"std/chan:reading" %a1)
  store i64 %t74, ptr %l32
  br label %bb15
bb15:
  %t75 = load i64, ptr %l32, !tbaa !24
  store i64 %t75, ptr %l2, !tbaa !24
  br label %bb16
bb16:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t76, i32 0, i32 5
  %t79 = load i1, ptr %t78, !tbaa !21
  br i1 %t79, label %bb17, label %bb18
bb17:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t81, i32 0, i32 7
  %t84 = load i64, ptr %t83, !tbaa !24
  %t85 = load i64, ptr %l2, !tbaa !24
  %t88 = icmp sle i64 %t84, %t85
  store i1 %t88, ptr %l35, !tbaa !21
  br label %bb19
bb18:
  store i1 false, ptr %l35, !tbaa !21
  br label %bb19
bb19:
  %t90 = load i1, ptr %l35, !tbaa !21
  br i1 %t90, label %bb20, label %bb21
bb20:
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t93 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t91, i32 0, i32 8
  %t94 = load i1, ptr %t93, !tbaa !21
  %t96 = xor i1 %t94, true
  store i1 %t96, ptr %l40, !tbaa !21
  br label %bb22
bb21:
  store i1 false, ptr %l40, !tbaa !21
  br label %bb22
bb22:
  %t98 = load i1, ptr %l40, !tbaa !21
  %t99 = xor i1 %t98, true
  br i1 %t99, label %bb23, label %bb24
bb23:
  br label %bb28
bb24:
  br label %bb25
bb25:
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t103 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t101, i32 0, i32 11
  %t105 = insertvalue { i64, ptr } undef, i64 8, 0
  %t106 = insertvalue { i64, ptr } %t105, ptr %t103, 1
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t108, i32 0, i32 9
  %t112 = insertvalue { i64, ptr } undef, i64 8, 0
  %t113 = insertvalue { i64, ptr } %t112, ptr %t110, 1
  %t116 = extractvalue { i64, ptr } %t106, 1
  %t117 = extractvalue { i64, ptr } %t106, 0
  %t119 = extractvalue { i64, ptr } %t113, 1
  %t120 = extractvalue { i64, ptr } %t113, 0
  %t121 = call i32 @pthread_cond_wait(ptr %t116, ptr %t119)
  store i32 %t121, ptr %l53
  br label %bb26
bb26:
  br label %bb27
bb27:
  br label %bb16
bb28:
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t124 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t122, i32 0, i32 5
  %t125 = load i1, ptr %t124, !tbaa !21
  br i1 %t125, label %bb29, label %bb30
bb29:
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t129 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t127, i32 0, i32 7
  %t130 = load i64, ptr %t129, !tbaa !24
  %t131 = load i64, ptr %l2, !tbaa !24
  %t134 = icmp sle i64 %t130, %t131
  store i1 %t134, ptr %l56, !tbaa !21
  br label %bb31
bb30:
  store i1 false, ptr %l56, !tbaa !21
  br label %bb31
bb31:
  %t136 = load i1, ptr %l56, !tbaa !21
  br i1 %t136, label %bb32, label %bb33
bb32:
  %t137 = load ptr, ptr %l0, !tbaa !29
  call void @std_2fchan_2ewithdraw_3cI64_3e(ptr %v0, ptr %t137)
  br label %bb34
bb33:
  br label %bb38
bb34:
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t141 = call i32 @std_2fchan_2esendOpen_3cI64_3e(ptr %v0, ptr %t139)
  store i32 %t141, ptr %l63
  %t142 = icmp ne i32 %t141, 0
  br i1 %t142, label %bb36, label %ok.143
ok.143:
  br label %bb35
bb35:
  br label %bb37
bb36:
  %t144 = load i32, ptr %l63, !tbaa !23
  %t145 = lshr i32 %t144, 16
  %t146 = and i32 %t144, 65535
  %t147 = icmp eq i32 %t145, 1
  %t148 = select i1 %t147, i32 1, i32 0
  %t149 = icmp eq i32 %t144, 0
  %t150 = shl i32 %t148, 16
  %t151 = or i32 %t150, %t146
  %t152 = select i1 %t149, i32 0, i32 %t151
  store i32 %t152, ptr %rv
  br label %ret
bb37:
  br label %bb38
bb38:
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t156 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t154, i32 0, i32 9
  %t158 = insertvalue { i64, ptr } undef, i64 8, 0
  %t159 = insertvalue { i64, ptr } %t158, ptr %t156, 1
  %t162 = extractvalue { i64, ptr } %t159, 1
  %t163 = extractvalue { i64, ptr } %t159, 0
  %t164 = call i32 @pthread_mutex_unlock(ptr %t162)
  store i32 %t164, ptr %l69
  br label %bb39
bb39:
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @std_2fchan_2eoldest_3cI32_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l3 = alloca { i64, ptr }
  %l26 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t1, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l3, !tbaa !27
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t5, i32 0, i32 2
  %t8 = load i64, ptr %t7, !tbaa !24
  %t10 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t11 = load ptr, ptr %t10, !tbaa !27
  %t12 = getelementptr i32, ptr %t11, i64 %t8
  %t13 = load i32, ptr %t12, !tbaa !33
  store i32 %t13, ptr %l1, !tbaa !23
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t16, i32 0, i32 2
  %t19 = load i64, ptr %t18, !tbaa !24
  %t21 = add i64 %t19, 1
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t22, i32 0, i32 0
  %t25 = load i64, ptr %t24, !tbaa !24
  %t28 = srem i64 %t21, %t25
  %t31 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t15, i32 0, i32 2
  store i64 %t28, ptr %t31, !tbaa !24
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t33, i32 0, i32 4
  %t36 = load i64, ptr %t35, !tbaa !24
  %t38 = sub i64 %t36, 1
  %t41 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t32, i32 0, i32 4
  store i64 %t38, ptr %t41, !tbaa !24
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t43, i32 0, i32 7
  %t46 = load i64, ptr %t45, !tbaa !24
  %t48 = add i64 %t46, 1
  %t51 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t42, i32 0, i32 7
  store i64 %t48, ptr %t51, !tbaa !24
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t52, i32 0, i32 11
  %t56 = insertvalue { i64, ptr } undef, i64 8, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t54, 1
  %t60 = extractvalue { i64, ptr } %t57, 1
  %t61 = extractvalue { i64, ptr } %t57, 0
  %t62 = call i32 @pthread_cond_broadcast(ptr %t60)
  store i32 %t62, ptr %l26
  br label %bb1
bb1:
  %t63 = load i32, ptr %l1, !tbaa !23
  store i32 %t63, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local %"std/chan:reading" @std_2fchan_2eoldest_3cstd_2fchan_3areading_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"std/chan:reading"
  %l3 = alloca { i64, ptr }
  %l26 = alloca i32
  %rv = alloca %"std/chan:reading"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t1, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l3, !tbaa !27
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t5, i32 0, i32 2
  %t8 = load i64, ptr %t7, !tbaa !24
  %t10 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t11 = load ptr, ptr %t10, !tbaa !27
  %t12 = getelementptr %"std/chan:reading", ptr %t11, i64 %t8
  %t13 = load %"std/chan:reading", ptr %t12
  store %"std/chan:reading" %t13, ptr %l1
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t16, i32 0, i32 2
  %t19 = load i64, ptr %t18, !tbaa !24
  %t21 = add i64 %t19, 1
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t22, i32 0, i32 0
  %t25 = load i64, ptr %t24, !tbaa !24
  %t28 = srem i64 %t21, %t25
  %t31 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t15, i32 0, i32 2
  store i64 %t28, ptr %t31, !tbaa !24
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t33, i32 0, i32 4
  %t36 = load i64, ptr %t35, !tbaa !24
  %t38 = sub i64 %t36, 1
  %t41 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t32, i32 0, i32 4
  store i64 %t38, ptr %t41, !tbaa !24
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t43, i32 0, i32 7
  %t46 = load i64, ptr %t45, !tbaa !24
  %t48 = add i64 %t46, 1
  %t51 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t42, i32 0, i32 7
  store i64 %t48, ptr %t51, !tbaa !24
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t52, i32 0, i32 11
  %t56 = insertvalue { i64, ptr } undef, i64 8, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t54, 1
  %t60 = extractvalue { i64, ptr } %t57, 1
  %t61 = extractvalue { i64, ptr } %t57, 0
  %t62 = call i32 @pthread_cond_broadcast(ptr %t60)
  store i32 %t62, ptr %l26
  br label %bb1
bb1:
  %t63 = load %"std/chan:reading", ptr %l1
  store %"std/chan:reading" %t63, ptr %rv
  br label %ret
ret:
  %rr = load %"std/chan:reading", ptr %rv
  ret %"std/chan:reading" %rr
}

define dso_local i64 @std_2fchan_2eplace_3cI32_3e(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l6 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca i32
  %l14 = alloca { i64, ptr }
  %l37 = alloca i32
  %rv = alloca i64
  %t26 = alloca i64
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t1, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t8 = icmp eq i64 %t6, 0
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l6, !tbaa !29
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t11, i32 0, i32 0
  %t14 = load i64, ptr %t13, !tbaa !24
  store i64 %t14, ptr %l8, !tbaa !24
  %t15 = load i32, ptr %l1, !tbaa !23
  store i32 %t15, ptr %l9, !tbaa !23
  %t16 = load i64, ptr %l8, !tbaa !24
  %t17 = icmp sge i64 %t16, 0
  br i1 %t17, label %bb3, label %bb4
bb2:
  br label %bb7
bb3:
  %t19 = load i64, ptr %l8, !tbaa !24
  %t20 = icmp sle i64 %t19, 2305843009213693951
  br i1 %t20, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_f51c3b74f2d4a8af_eaf8dafb70d5bb93)
  unreachable
bb5:
  %t22 = load i64, ptr %l8, !tbaa !24
  %t23 = mul i64 %t22, 4
  %t24 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t23)
  %t25 = load i32, ptr %l9, !tbaa !23
  store i64 0, ptr %t26
  br label %fill.27
fill.27:
  %t30 = load i64, ptr %t26
  %t31 = icmp slt i64 %t30, %t22
  br i1 %t31, label %fillb.28, label %filld.29
fillb.28:
  %t32 = getelementptr i32, ptr %t24, i64 %t30
  store i32 %t25, ptr %t32
  %t33 = add i64 %t30, 1
  store i64 %t33, ptr %t26
  br label %fill.27
filld.29:
  %t34 = insertvalue { i64, ptr } undef, i64 %t22, 0
  %t35 = insertvalue { i64, ptr } %t34, ptr %t24, 1
  %t37 = load ptr, ptr %l6, !tbaa !29
  %t38 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t37, i32 0, i32 1
  store { i64, ptr } %t35, ptr %t38, !tbaa !27
  br label %bb7
bb6:
  call void @__olang_check_failed(ptr @olang_loc_f51c3b74f2d4a8af_eaf8dafb70d5bb93)
  unreachable
bb7:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t39, i32 0, i32 1
  %t42 = load { i64, ptr }, ptr %t41, !tbaa !27
  store { i64, ptr } %t42, ptr %l14, !tbaa !27
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t43, i32 0, i32 3
  %t46 = load i64, ptr %t45, !tbaa !24
  %t47 = load i32, ptr %l1, !tbaa !23
  %t50 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t51 = load ptr, ptr %t50, !tbaa !27
  %t52 = getelementptr i32, ptr %t51, i64 %t46
  store i32 %t47, ptr %t52, !tbaa !33
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t54, i32 0, i32 3
  %t57 = load i64, ptr %t56, !tbaa !24
  %t59 = add i64 %t57, 1
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t60, i32 0, i32 0
  %t63 = load i64, ptr %t62, !tbaa !24
  %t66 = srem i64 %t59, %t63
  %t69 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t53, i32 0, i32 3
  store i64 %t66, ptr %t69, !tbaa !24
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t71, i32 0, i32 4
  %t74 = load i64, ptr %t73, !tbaa !24
  %t76 = add i64 %t74, 1
  %t79 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t70, i32 0, i32 4
  store i64 %t76, ptr %t79, !tbaa !24
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t81, i32 0, i32 6
  %t84 = load i64, ptr %t83, !tbaa !24
  %t86 = add i64 %t84, 1
  %t89 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t80, i32 0, i32 6
  store i64 %t86, ptr %t89, !tbaa !24
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t92 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t90, i32 0, i32 10
  %t94 = insertvalue { i64, ptr } undef, i64 8, 0
  %t95 = insertvalue { i64, ptr } %t94, ptr %t92, 1
  %t98 = extractvalue { i64, ptr } %t95, 1
  %t99 = extractvalue { i64, ptr } %t95, 0
  %t100 = call i32 @pthread_cond_broadcast(ptr %t98)
  store i32 %t100, ptr %l37
  br label %bb8
bb8:
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t103 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t101, i32 0, i32 6
  %t104 = load i64, ptr %t103, !tbaa !24
  %t106 = sub i64 %t104, 1
  store i64 %t106, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @std_2fchan_2eplace_3cstd_2fchan_3areading_3e(ptr %v0, ptr %a0, %"std/chan:reading" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"std/chan:reading"
  %l6 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca %"std/chan:reading"
  %l14 = alloca { i64, ptr }
  %l37 = alloca i32
  %rv = alloca i64
  %t26 = alloca i64
  store ptr %a0, ptr %l0
  store %"std/chan:reading" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t1, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t8 = icmp eq i64 %t6, 0
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l6, !tbaa !29
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t11, i32 0, i32 0
  %t14 = load i64, ptr %t13, !tbaa !24
  store i64 %t14, ptr %l8, !tbaa !24
  %t15 = load %"std/chan:reading", ptr %l1
  store %"std/chan:reading" %t15, ptr %l9
  %t16 = load i64, ptr %l8, !tbaa !24
  %t17 = icmp sge i64 %t16, 0
  br i1 %t17, label %bb3, label %bb4
bb2:
  br label %bb7
bb3:
  %t19 = load i64, ptr %l8, !tbaa !24
  %t20 = icmp sle i64 %t19, 576460752303423487
  br i1 %t20, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_772c54764e337a02_1b08b3073a69a3ee)
  unreachable
bb5:
  %t22 = load i64, ptr %l8, !tbaa !24
  %t23 = mul i64 %t22, 16
  %t24 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t23)
  %t25 = load %"std/chan:reading", ptr %l9
  store i64 0, ptr %t26
  br label %fill.27
fill.27:
  %t30 = load i64, ptr %t26
  %t31 = icmp slt i64 %t30, %t22
  br i1 %t31, label %fillb.28, label %filld.29
fillb.28:
  %t32 = getelementptr %"std/chan:reading", ptr %t24, i64 %t30
  store %"std/chan:reading" %t25, ptr %t32
  %t33 = add i64 %t30, 1
  store i64 %t33, ptr %t26
  br label %fill.27
filld.29:
  %t34 = insertvalue { i64, ptr } undef, i64 %t22, 0
  %t35 = insertvalue { i64, ptr } %t34, ptr %t24, 1
  %t37 = load ptr, ptr %l6, !tbaa !29
  %t38 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t37, i32 0, i32 1
  store { i64, ptr } %t35, ptr %t38, !tbaa !27
  br label %bb7
bb6:
  call void @__olang_check_failed(ptr @olang_loc_772c54764e337a02_1b08b3073a69a3ee)
  unreachable
bb7:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t39, i32 0, i32 1
  %t42 = load { i64, ptr }, ptr %t41, !tbaa !27
  store { i64, ptr } %t42, ptr %l14, !tbaa !27
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t43, i32 0, i32 3
  %t46 = load i64, ptr %t45, !tbaa !24
  %t47 = load %"std/chan:reading", ptr %l1
  %t50 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t51 = load ptr, ptr %t50, !tbaa !27
  %t52 = getelementptr %"std/chan:reading", ptr %t51, i64 %t46
  store %"std/chan:reading" %t47, ptr %t52
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t54, i32 0, i32 3
  %t57 = load i64, ptr %t56, !tbaa !24
  %t59 = add i64 %t57, 1
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t60, i32 0, i32 0
  %t63 = load i64, ptr %t62, !tbaa !24
  %t66 = srem i64 %t59, %t63
  %t69 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t53, i32 0, i32 3
  store i64 %t66, ptr %t69, !tbaa !24
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t71, i32 0, i32 4
  %t74 = load i64, ptr %t73, !tbaa !24
  %t76 = add i64 %t74, 1
  %t79 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t70, i32 0, i32 4
  store i64 %t76, ptr %t79, !tbaa !24
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t81, i32 0, i32 6
  %t84 = load i64, ptr %t83, !tbaa !24
  %t86 = add i64 %t84, 1
  %t89 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t80, i32 0, i32 6
  store i64 %t86, ptr %t89, !tbaa !24
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t92 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t90, i32 0, i32 10
  %t94 = insertvalue { i64, ptr } undef, i64 8, 0
  %t95 = insertvalue { i64, ptr } %t94, ptr %t92, 1
  %t98 = extractvalue { i64, ptr } %t95, 1
  %t99 = extractvalue { i64, ptr } %t95, 0
  %t100 = call i32 @pthread_cond_broadcast(ptr %t98)
  store i32 %t100, ptr %l37
  br label %bb8
bb8:
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t103 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t101, i32 0, i32 6
  %t104 = load i64, ptr %t103, !tbaa !24
  %t106 = sub i64 %t104, 1
  store i64 %t106, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i32 @std_2fchan_2esendOpen_3cI32_3e(ptr %v0, ptr %a0) #0 {
entry:
  %r = tail call i32 @std_2fchan_2esendOpen_3cI64_3e(ptr %v0, ptr %a0)
  ret i32 %r
}

define dso_local i32 @std_2fchan_2esendOpen_3cstd_2fchan_3areading_3e(ptr %v0, ptr %a0) #0 {
entry:
  %r = tail call i32 @std_2fchan_2esendOpen_3cI64_3e(ptr %v0, ptr %a0)
  ret i32 %r
}

define dso_local { i32, i32 } @std_2fchan_2estd_2fchan_3aChan_3cI32_3e_2eNext_3cI32_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca i32
  %l3 = alloca i32
  %l4 = alloca i32
  %rv = alloca { i32, i32 }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call { i32, i32 } @std_2fchan_2eRecv_3cI32_3e(ptr %v0, ptr %a0)
  %t4 = extractvalue { i32, i32 } %t3, 1
  %t5 = extractvalue { i32, i32 } %t3, 0
  store i32 %t5, ptr %l4
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7
ok.7:
  store i32 %t4, ptr %l3
  br label %bb1
bb1:
  %t8 = load i32, ptr %l3, !tbaa !23
  store i32 %t8, ptr %l1, !tbaa !23
  br label %bb6
bb2:
  %t9 = load i32, ptr %l4, !tbaa !23
  %t10 = ashr i32 %t9, 16
  %t12 = icmp eq i32 %t10, 1
  br i1 %t12, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  %t14 = load i32, ptr %l4, !tbaa !23
  %t15 = lshr i32 %t14, 16
  %t16 = and i32 %t14, 65535
  %t17 = icmp eq i32 %t15, 1
  %t18 = select i1 %t17, i32 0, i32 0
  %t19 = icmp eq i32 %t14, 0
  %t20 = shl i32 %t18, 16
  %t21 = or i32 %t20, %t16
  %t22 = select i1 %t19, i32 0, i32 %t21
  %t24 = insertvalue { i32, i32 } zeroinitializer, i32 %t22, 0
  store { i32, i32 } %t24, ptr %rv
  br label %ret
bb5:
  call void @__olang_ert_req_clear()
  %t26 = insertvalue { i32, i32 } zeroinitializer, i32 65536, 0
  store { i32, i32 } %t26, ptr %rv
  br label %ret
bb6:
  %t27 = load i32, ptr %l1, !tbaa !23
  %t28 = insertvalue { i32, i32 } zeroinitializer, i32 %t27, 1
  store { i32, i32 } %t28, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i32 }, ptr %rv
  ret { i32, i32 } %rr
}

define dso_local void @std_2fchan_2ewithdraw_3cI32_3e(ptr %v0, ptr %a0) #0 {
entry:
  tail call void @std_2fchan_2ewithdraw_3cI64_3e(ptr %v0, ptr %a0)
  ret void
}

define dso_local void @std_2fchan_2ewithdraw_3cstd_2fchan_3areading_3e(ptr %v0, ptr %a0) #0 {
entry:
  tail call void @std_2fchan_2ewithdraw_3cI64_3e(ptr %v0, ptr %a0)
  ret void
}

declare i32 @pthread_mutex_lock(ptr)
declare i32 @pthread_mutex_unlock(ptr)
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  call void @__olang_dtor_head(ptr %fd, ptr %pdp)
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %dhasnext = icmp ne ptr %dnext, null
  br i1 %dhasnext, label %dfixpp, label %drun
dfixpp:
  %dnpp = getelementptr %olang.dtornode, ptr %dnext, i32 0, i32 3
  store ptr %dheadptr, ptr %dnpp
  br label %drun
drun:
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  call void @__olang_dtor_head(ptr %wfd, ptr %dheadptr)
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
declare i32 @pthread_cond_timedwait(ptr, ptr, ptr)
declare i32 @pthread_cond_wait(ptr, ptr)
declare i32 @pthread_cond_broadcast(ptr)
declare void @__olang_check_failed(ptr)
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @__olang_ert_req_clear()
declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
define available_externally void @__olang_dtor_head(ptr %node, ptr %at) alwaysinline {
entry:
  %has = icmp ne ptr %node, null
  br i1 %has, label %fix, label %done
fix:
  %ppp = getelementptr %olang.dtornode, ptr %node, i32 0, i32 3
  store ptr %at, ptr %ppp
  br label %done
done:
  ret void
}
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare noalias ptr @__olang_scope_alloc_a(ptr, i64, i64)
declare void @std_2fchan_2eClose_3cI64_3e(ptr %v0, ptr %a0)
declare i1 @std_2fcancel_2estd_2fcancel_3aToken_2eCancelled(ptr %v0, ptr %a0)
declare i32 @std_2fcancel_2estd_2fcancel_3aToken_2eReason(ptr %v0, ptr %a0)
declare void @std_2fcancel_2estd_2fcancel_3aToken_2eWakeAt(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i32 @std_2fchan_2esendOpen_3cI64_3e(ptr %v0, ptr %a0)
declare void @std_2fchan_2ewithdraw_3cI64_3e(ptr %v0, ptr %a0)
@olang_loc_f51c3b74f2d4a8af_eaf8dafb70d5bb93 = external constant [0 x i8]
@olang_loc_772c54764e337a02_1b08b3073a69a3ee = external constant [0 x i8]

!20 = !{!"olang"}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
