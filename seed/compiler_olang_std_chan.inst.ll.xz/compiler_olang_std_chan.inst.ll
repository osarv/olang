; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr, i64, ptr }
%olang.home = type { ptr, ptr }
%olang.slotscope = type { %olang.scope, i64, [8 x ptr] }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"std/chan:Chan.2a97fb60857ef5a63442ec031c672e33" = type { i64, { i64, ptr }, i64, i64, i64, i1, i64, i64, i1, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"<pthread.h>:pthread_mutex_t", %"<pthread.h>:pthread_cond_t", %"<pthread.h>:pthread_cond_t" }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"<pthread.h>:pthread_mutex_t" = type { [5 x i64] }
%"<pthread.h>:pthread_cond_t" = type { [6 x i64] }
%"std/chan:reading" = type { i32, double }
define dso_local void @std_2fchan_2eClose_3cI32_3e(ptr %v0, ptr %a0) #0 {
entry:
  tail call void @std_2fchan_2eClose_3cI64_3e(ptr %v0, ptr %a0)
  ret void
}

define dso_local { i32, i32 } @std_2fchan_2eRecvUntil_3cI32_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i32
  %l6 = alloca i32
  %l10 = alloca i1
  %l16 = alloca i1
  %l21 = alloca i32
  %l23 = alloca i32
  %l28 = alloca i64
  %l29 = alloca ptr
  %l43 = alloca i32
  %l46 = alloca i32
  %l49 = alloca i32
  %rv = alloca { i32, i32 }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/chan:Chan.2a97fb60857ef5a63442ec031c672e33", ptr %t1, i32 0, i32 12
  %t5 = call i32 @pthread_mutex_lock(ptr %t3)
  store i32 %t5, ptr %l6
  br label %bb1
bb1:
  store i64 -1, ptr %l2, !tbaa !24
  br label %bb2
bb2:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"std/chan:Chan.2a97fb60857ef5a63442ec031c672e33", ptr %t6, i32 0, i32 4
  %t9 = load i64, ptr %t8, !tbaa !24
  %t11 = icmp eq i64 %t9, 0
  br i1 %t11, label %bb3, label %bb4
bb3:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"std/chan:Chan.2a97fb60857ef5a63442ec031c672e33", ptr %t13, i32 0, i32 8
  %t16 = load i1, ptr %t15, !tbaa !21
  %t18 = xor i1 %t16, true
  store i1 %t18, ptr %l10, !tbaa !21
  br label %bb5
bb4:
  store i1 false, ptr %l10, !tbaa !21
  br label %bb5
bb5:
  %t20 = load i1, ptr %l10, !tbaa !21
  %t21 = xor i1 %t20, true
  br i1 %t21, label %bb6, label %bb7
bb6:
  br label %bb24
bb7:
  br label %bb8
bb8:
  %t23 = load ptr, ptr %l1, !tbaa !29
  %t25 = call i1 @std_2fcancel_2estd_2fcancel_3aToken_2eCancelled(ptr %v1, ptr %t23)
  store i1 %t25, ptr %l16
  br label %bb9
bb9:
  %t26 = load i1, ptr %l16, !tbaa !21
  br i1 %t26, label %bb10, label %bb11
bb10:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load i64, ptr %l2, !tbaa !24
  call void @std_2fchan_2eunparkReceiver_3cI32_3e(ptr %v0, ptr %t27, i64 %t28)
  br label %bb12
bb11:
  br label %bb17
bb12:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"std/chan:Chan.2a97fb60857ef5a63442ec031c672e33", ptr %t31, i32 0, i32 12
  %t35 = call i32 @pthread_mutex_unlock(ptr %t33)
  store i32 %t35, ptr %l21
  br label %bb13
bb13:
  %t36 = load ptr, ptr %l1, !tbaa !29
  %t38 = call i32 @std_2fcancel_2estd_2fcancel_3aToken_2eReason(ptr %v1, ptr %t36)
  store i32 %t38, ptr %l23
  %t39 = icmp ne i32 %t38, 0
  br i1 %t39, label %bb15, label %ok.40, !prof !99
ok.40:
  br label %bb14
bb14:
  br label %bb16
bb15:
  %t41 = load i32, ptr %l23, !tbaa !23
  %t42 = lshr i32 %t41, 16
  %t43 = and i32 %t41, 65535
  %t44 = icmp eq i32 %t42, 1
  %t45 = select i1 %t44, i32 1, i32 0
  %t46 = icmp eq i32 %t41, 0
  %t47 = shl i32 %t45, 16
  %t48 = or i32 %t47, %t43
  %t49 = select i1 %t46, i32 0, i32 %t48
  %t51 = insertvalue { i32, i32 } zeroinitializer, i32 %t49, 0
  store { i32, i32 } %t51, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  %t52 = load i64, ptr %l2, !tbaa !24
  %t54 = icmp slt i64 %t52, 0
  br i1 %t54, label %bb18, label %bb19
bb18:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = call i64 @std_2fchan_2epark_3cI32_3e(ptr %v0, ptr %t56)
  store i64 %t58, ptr %l28
  br label %bb20
bb19:
  br label %bb21
bb20:
  %t59 = load i64, ptr %l28, !tbaa !24
  store i64 %t59, ptr %l2, !tbaa !24
  %t60 = load ptr, ptr %l0, !tbaa !29
  store ptr %t60, ptr %l29, !tbaa !29
  %t61 = load ptr, ptr %l29, !tbaa !29
  %t62 = getelementptr %"std/chan:Chan.2a97fb60857ef5a63442ec031c672e33", ptr %t61, i32 0, i32 9
  %t63 = load i64, ptr %t62, !tbaa !24
  %t66 = add i64 %t63, 1
  %t68 = load ptr, ptr %l29, !tbaa !29
  %t69 = getelementptr %"std/chan:Chan.2a97fb60857ef5a63442ec031c672e33", ptr %t68, i32 0, i32 9
  store i64 %t66, ptr %t69, !tbaa !24
  br label %bb23
bb21:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t71 = load ptr, ptr %l1, !tbaa !29
  %t72 = load i64, ptr %l2, !tbaa !24
  call void @std_2fchan_2esleep_3cI32_3e(ptr %v0, ptr %v1, ptr %t70, ptr %t71, i64 %t72)
  br label %bb22
bb22:
  br label %bb23
bb23:
  br label %bb2
bb24:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t77 = load i64, ptr %l2, !tbaa !24
  call void @std_2fchan_2eunparkReceiver_3cI32_3e(ptr %v0, ptr %t76, i64 %t77)
  br label %bb25
bb25:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t82 = getelementptr %"std/chan:Chan.2a97fb60857ef5a63442ec031c672e33", ptr %t80, i32 0, i32 4
  %t83 = load i64, ptr %t82, !tbaa !24
  %t85 = icmp eq i64 %t83, 0
  br i1 %t85, label %bb26, label %bb27
bb26:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr %"std/chan:Chan.2a97fb60857ef5a63442ec031c672e33", ptr %t87, i32 0, i32 12
  %t91 = call i32 @pthread_mutex_unlock(ptr %t89)
  store i32 %t91, ptr %l43
  br label %bb28
bb27:
  br label %bb29
bb28:
  %t93 = insertvalue { i32, i32 } zeroinitializer, i32 131072, 0
  store { i32, i32 } %t93, ptr %rv
  br label %ret
bb29:
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t96 = call i32 @std_2fchan_2eoldest_3cI32_3e(ptr %v0, ptr %t94)
  store i32 %t96, ptr %l46
  br label %bb30
bb30:
  %t97 = load i32, ptr %l46, !tbaa !23
  store i32 %t97, ptr %l3, !tbaa !23
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t100 = getelementptr %"std/chan:Chan.2a97fb60857ef5a63442ec031c672e33", ptr %t98, i32 0, i32 12
  %t102 = call i32 @pthread_mutex_unlock(ptr %t100)
  store i32 %t102, ptr %l49
  br label %bb31
bb31:
  %t103 = load i32, ptr %l3, !tbaa !23
  %t105 = insertvalue { i32, i32 } zeroinitializer, i32 %t103, 1
  store { i32, i32 } %t105, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i32 }, ptr %rv
  ret { i32, i32 } %rr
}

define dso_local { i32, i32 } @std_2fchan_2eRecv_3cI32_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l4 = alloca i32
  %l5 = alloca ptr
  %l12 = alloca i1
  %l21 = alloca i32
  %l22 = alloca ptr
  %l31 = alloca i32
  %l34 = alloca i32
  %l37 = alloca i32
  %rv = alloca { i32, i32 }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/chan:Chan.2a97fb60857ef5a63442ec031c672e33", ptr %t1, i32 0, i32 12
  %t5 = call i32 @pthread_mutex_lock(ptr %t3)
  store i32 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load ptr, ptr %l0, !tbaa !29
  store ptr %t6, ptr %l5, !tbaa !29
  %t7 = load ptr, ptr %l5, !tbaa !29
  %t8 = getelementptr %"std/chan:Chan.2a97fb60857ef5a63442ec031c672e33", ptr %t7, i32 0, i32 9
  %t9 = load i64, ptr %t8, !tbaa !24
  %t12 = add i64 %t9, 1
  %t14 = load ptr, ptr %l5, !tbaa !29
  %t15 = getelementptr %"std/chan:Chan.2a97fb60857ef5a63442ec031c672e33", ptr %t14, i32 0, i32 9
  store i64 %t12, ptr %t15, !tbaa !24
  br label %bb2
bb2:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"std/chan:Chan.2a97fb60857ef5a63442ec031c672e33", ptr %t16, i32 0, i32 4
  %t19 = load i64, ptr %t18, !tbaa !24
  %t21 = icmp eq i64 %t19, 0
  br i1 %t21, label %bb3, label %bb4
bb3:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"std/chan:Chan.2a97fb60857ef5a63442ec031c672e33", ptr %t23, i32 0, i32 8
  %t26 = load i1, ptr %t25, !tbaa !21
  %t28 = xor i1 %t26, true
  store i1 %t28, ptr %l12, !tbaa !21
  br label %bb5
bb4:
  store i1 false, ptr %l12, !tbaa !21
  br label %bb5
bb5:
  %t30 = load i1, ptr %l12, !tbaa !21
  %t31 = xor i1 %t30, true
  br i1 %t31, label %bb6, label %bb7
bb6:
  br label %bb11
bb7:
  br label %bb8
bb8:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"std/chan:Chan.2a97fb60857ef5a63442ec031c672e33", ptr %t33, i32 0, i32 13
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"std/chan:Chan.2a97fb60857ef5a63442ec031c672e33", ptr %t36, i32 0, i32 12
  %t41 = call i32 @pthread_cond_wait(ptr %t35, ptr %t38)
  store i32 %t41, ptr %l21
  br label %bb9
bb9:
  br label %bb10
bb10:
  br label %bb2
bb11:
  %t42 = load ptr, ptr %l0, !tbaa !29
  store ptr %t42, ptr %l22, !tbaa !29
  %t43 = load ptr, ptr %l22, !tbaa !29
  %t44 = getelementptr %"std/chan:Chan.2a97fb60857ef5a63442ec031c672e33", ptr %t43, i32 0, i32 9
  %t45 = load i64, ptr %t44, !tbaa !24
  %t48 = sub i64 %t45, 1
  %t50 = load ptr, ptr %l22, !tbaa !29
  %t51 = getelementptr %"std/chan:Chan.2a97fb60857ef5a63442ec031c672e33", ptr %t50, i32 0, i32 9
  store i64 %t48, ptr %t51, !tbaa !24
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"std/chan:Chan.2a97fb60857ef5a63442ec031c672e33", ptr %t52, i32 0, i32 4
  %t55 = load i64, ptr %t54, !tbaa !24
  %t57 = icmp eq i64 %t55, 0
  br i1 %t57, label %bb12, label %bb13
bb12:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"std/chan:Chan.2a97fb60857ef5a63442ec031c672e33", ptr %t59, i32 0, i32 12
  %t63 = call i32 @pthread_mutex_unlock(ptr %t61)
  store i32 %t63, ptr %l31
  br label %bb14
bb13:
  br label %bb15
bb14:
  %t65 = insertvalue { i32, i32 } zeroinitializer, i32 65536, 0
  store { i32, i32 } %t65, ptr %rv
  br label %ret
bb15:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = call i32 @std_2fchan_2eoldest_3cI32_3e(ptr %v0, ptr %t66)
  store i32 %t68, ptr %l34
  br label %bb16
bb16:
  %t69 = load i32, ptr %l34, !tbaa !23
  store i32 %t69, ptr %l1, !tbaa !23
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"std/chan:Chan.2a97fb60857ef5a63442ec031c672e33", ptr %t70, i32 0, i32 12
  %t74 = call i32 @pthread_mutex_unlock(ptr %t72)
  store i32 %t74, ptr %l37
  br label %bb17
bb17:
  %t75 = load i32, ptr %l1, !tbaa !23
  %t77 = insertvalue { i32, i32 } zeroinitializer, i32 %t75, 1
  store { i32, i32 } %t77, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i32 }, ptr %rv
  ret { i32, i32 } %rr
}

define dso_local { i32, %"std/chan:reading" } @std_2fchan_2eRecv_3cstd_2fchan_3areading_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"std/chan:reading"
  %l4 = alloca i32
  %l5 = alloca ptr
  %l12 = alloca i1
  %l21 = alloca i32
  %l22 = alloca ptr
  %l31 = alloca i32
  %l34 = alloca %"std/chan:reading"
  %l37 = alloca i32
  %rv = alloca { i32, %"std/chan:reading" }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/chan:Chan.2a97fb60857ef5a63442ec031c672e33", ptr %t1, i32 0, i32 12
  %t5 = call i32 @pthread_mutex_lock(ptr %t3)
  store i32 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load ptr, ptr %l0, !tbaa !29
  store ptr %t6, ptr %l5, !tbaa !29
  %t7 = load ptr, ptr %l5, !tbaa !29
  %t8 = getelementptr %"std/chan:Chan.2a97fb60857ef5a63442ec031c672e33", ptr %t7, i32 0, i32 9
  %t9 = load i64, ptr %t8, !tbaa !24
  %t12 = add i64 %t9, 1
  %t14 = load ptr, ptr %l5, !tbaa !29
  %t15 = getelementptr %"std/chan:Chan.2a97fb60857ef5a63442ec031c672e33", ptr %t14, i32 0, i32 9
  store i64 %t12, ptr %t15, !tbaa !24
  br label %bb2
bb2:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"std/chan:Chan.2a97fb60857ef5a63442ec031c672e33", ptr %t16, i32 0, i32 4
  %t19 = load i64, ptr %t18, !tbaa !24
  %t21 = icmp eq i64 %t19, 0
  br i1 %t21, label %bb3, label %bb4
bb3:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"std/chan:Chan.2a97fb60857ef5a63442ec031c672e33", ptr %t23, i32 0, i32 8
  %t26 = load i1, ptr %t25, !tbaa !21
  %t28 = xor i1 %t26, true
  store i1 %t28, ptr %l12, !tbaa !21
  br label %bb5
bb4:
  store i1 false, ptr %l12, !tbaa !21
  br label %bb5
bb5:
  %t30 = load i1, ptr %l12, !tbaa !21
  %t31 = xor i1 %t30, true
  br i1 %t31, label %bb6, label %bb7
bb6:
  br label %bb11
bb7:
  br label %bb8
bb8:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"std/chan:Chan.2a97fb60857ef5a63442ec031c672e33", ptr %t33, i32 0, i32 13
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"std/chan:Chan.2a97fb60857ef5a63442ec031c672e33", ptr %t36, i32 0, i32 12
  %t41 = call i32 @pthread_cond_wait(ptr %t35, ptr %t38)
  store i32 %t41, ptr %l21
  br label %bb9
bb9:
  br label %bb10
bb10:
  br label %bb2
bb11:
  %t42 = load ptr, ptr %l0, !tbaa !29
  store ptr %t42, ptr %l22, !tbaa !29
  %t43 = load ptr, ptr %l22, !tbaa !29
  %t44 = getelementptr %"std/chan:Chan.2a97fb60857ef5a63442ec031c672e33", ptr %t43, i32 0, i32 9
  %t45 = load i64, ptr %t44, !tbaa !24
  %t48 = sub i64 %t45, 1
  %t50 = load ptr, ptr %l22, !tbaa !29
  %t51 = getelementptr %"std/chan:Chan.2a97fb60857ef5a63442ec031c672e33", ptr %t50, i32 0, i32 9
  store i64 %t48, ptr %t51, !tbaa !24
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"std/chan:Chan.2a97fb60857ef5a63442ec031c672e33", ptr %t52, i32 0, i32 4
  %t55 = load i64, ptr %t54, !tbaa !24
  %t57 = icmp eq i64 %t55, 0
  br i1 %t57, label %bb12, label %bb13
bb12:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"std/chan:Chan.2a97fb60857ef5a63442ec031c672e33", ptr %t59, i32 0, i32 12
  %t63 = call i32 @pthread_mutex_unlock(ptr %t61)
  store i32 %t63, ptr %l31
  br label %bb14
bb13:
  br label %bb15
bb14:
  %t65 = insertvalue { i32, %"std/chan:reading" } zeroinitializer, i32 65536, 0
  store { i32, %"std/chan:reading" } %t65, ptr %rv
  br label %ret
bb15:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = call %"std/chan:reading" @std_2fchan_2eoldest_3cstd_2fchan_3areading_3e(ptr %v0, ptr %t66)
  store %"std/chan:reading" %t68, ptr %l34
  br label %bb16
bb16:
  %t69 = load %"std/chan:reading", ptr %l34
  store %"std/chan:reading" %t69, ptr %l1
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"std/chan:Chan.2a97fb60857ef5a63442ec031c672e33", ptr %t70, i32 0, i32 12
  %t74 = call i32 @pthread_mutex_unlock(ptr %t72)
  store i32 %t74, ptr %l37
  br label %bb17
bb17:
  %t75 = load %"std/chan:reading", ptr %l1
  %t77 = insertvalue { i32, %"std/chan:reading" } zeroinitializer, %"std/chan:reading" %t75, 1
  store { i32, %"std/chan:reading" } %t77, ptr %rv
  br label %ret
ret:
  %rr = load { i32, %"std/chan:reading" }, ptr %rv
  ret { i32, %"std/chan:reading" } %rr
}

define dso_local i32 @std_2fchan_2eSend_3cI32_3e(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l5 = alloca i32
  %l11 = alloca i1
  %l20 = alloca i32
  %l22 = alloca i32
  %l26 = alloca i64
  %l29 = alloca i1
  %l34 = alloca i1
  %l43 = alloca i32
  %l46 = alloca i1
  %l53 = alloca i32
  %l57 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/chan:Chan.2a97fb60857ef5a63442ec031c672e33", ptr %t1, i32 0, i32 12
  %t5 = call i32 @pthread_mutex_lock(ptr %t3)
  store i32 %t5, ptr %l5
  br label %bb1
bb1:
  br label %bb2
bb2:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"std/chan:Chan.2a97fb60857ef5a63442ec031c672e33", ptr %t6, i32 0, i32 4
  %t9 = load i64, ptr %t8, !tbaa !24
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"std/chan:Chan.2a97fb60857ef5a63442ec031c672e33", ptr %t10, i32 0, i32 0
  %t13 = load i64, ptr %t12, !tbaa !24
  %t16 = icmp eq i64 %t9, %t13
  br i1 %t16, label %bb3, label %bb4
bb3:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"std/chan:Chan.2a97fb60857ef5a63442ec031c672e33", ptr %t18, i32 0, i32 8
  %t21 = load i1, ptr %t20, !tbaa !21
  %t23 = xor i1 %t21, true
  store i1 %t23, ptr %l11, !tbaa !21
  br label %bb5
bb4:
  store i1 false, ptr %l11, !tbaa !21
  br label %bb5
bb5:
  %t25 = load i1, ptr %l11, !tbaa !21
  %t26 = xor i1 %t25, true
  br i1 %t26, label %bb6, label %bb7
bb6:
  br label %bb11
bb7:
  br label %bb8
bb8:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"std/chan:Chan.2a97fb60857ef5a63442ec031c672e33", ptr %t28, i32 0, i32 14
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"std/chan:Chan.2a97fb60857ef5a63442ec031c672e33", ptr %t31, i32 0, i32 12
  %t36 = call i32 @pthread_cond_wait(ptr %t30, ptr %t33)
  store i32 %t36, ptr %l20
  br label %bb9
bb9:
  br label %bb10
bb10:
  br label %bb2
bb11:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = call i32 @std_2fchan_2esendOpen_3cI64_3e(ptr %v0, ptr %t37)
  store i32 %t39, ptr %l22
  %t40 = icmp ne i32 %t39, 0
  br i1 %t40, label %bb13, label %ok.41, !prof !99
ok.41:
  br label %bb12
bb12:
  br label %bb14
bb13:
  %t42 = load i32, ptr %l22, !tbaa !23
  %t43 = lshr i32 %t42, 16
  %t44 = and i32 %t42, 65535
  %t45 = icmp eq i32 %t43, 1
  %t46 = select i1 %t45, i32 1, i32 0
  %t47 = icmp eq i32 %t42, 0
  %t48 = shl i32 %t46, 16
  %t49 = or i32 %t48, %t44
  %t50 = select i1 %t47, i32 0, i32 %t49
  store i32 %t50, ptr %rv
  br label %ret
bb14:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t56 = call i64 @std_2fchan_2eplace_3cI32_3e(ptr %v0, ptr %t52, i32 %a1)
  store i64 %t56, ptr %l26
  br label %bb15
bb15:
  %t57 = load i64, ptr %l26, !tbaa !24
  store i64 %t57, ptr %l2, !tbaa !24
  br label %bb16
bb16:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"std/chan:Chan.2a97fb60857ef5a63442ec031c672e33", ptr %t58, i32 0, i32 5
  %t61 = load i1, ptr %t60, !tbaa !21
  br i1 %t61, label %bb17, label %bb18
bb17:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"std/chan:Chan.2a97fb60857ef5a63442ec031c672e33", ptr %t63, i32 0, i32 7
  %t66 = load i64, ptr %t65, !tbaa !24
  %t67 = load i64, ptr %l2, !tbaa !24
  %t70 = icmp sle i64 %t66, %t67
  store i1 %t70, ptr %l29, !tbaa !21
  br label %bb19
bb18:
  store i1 false, ptr %l29, !tbaa !21
  br label %bb19
bb19:
  %t72 = load i1, ptr %l29, !tbaa !21
  br i1 %t72, label %bb20, label %bb21
bb20:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"std/chan:Chan.2a97fb60857ef5a63442ec031c672e33", ptr %t73, i32 0, i32 8
  %t76 = load i1, ptr %t75, !tbaa !21
  %t78 = xor i1 %t76, true
  store i1 %t78, ptr %l34, !tbaa !21
  br label %bb22
bb21:
  store i1 false, ptr %l34, !tbaa !21
  br label %bb22
bb22:
  %t80 = load i1, ptr %l34, !tbaa !21
  %t81 = xor i1 %t80, true
  br i1 %t81, label %bb23, label %bb24
bb23:
  br label %bb28
bb24:
  br label %bb25
bb25:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr %"std/chan:Chan.2a97fb60857ef5a63442ec031c672e33", ptr %t83, i32 0, i32 14
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t88 = getelementptr %"std/chan:Chan.2a97fb60857ef5a63442ec031c672e33", ptr %t86, i32 0, i32 12
  %t91 = call i32 @pthread_cond_wait(ptr %t85, ptr %t88)
  store i32 %t91, ptr %l43
  br label %bb26
bb26:
  br label %bb27
bb27:
  br label %bb16
bb28:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"std/chan:Chan.2a97fb60857ef5a63442ec031c672e33", ptr %t92, i32 0, i32 5
  %t95 = load i1, ptr %t94, !tbaa !21
  br i1 %t95, label %bb29, label %bb30
bb29:
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = getelementptr %"std/chan:Chan.2a97fb60857ef5a63442ec031c672e33", ptr %t97, i32 0, i32 7
  %t100 = load i64, ptr %t99, !tbaa !24
  %t101 = load i64, ptr %l2, !tbaa !24
  %t104 = icmp sle i64 %t100, %t101
  store i1 %t104, ptr %l46, !tbaa !21
  br label %bb31
bb30:
  store i1 false, ptr %l46, !tbaa !21
  br label %bb31
bb31:
  %t106 = load i1, ptr %l46, !tbaa !21
  br i1 %t106, label %bb32, label %bb33
bb32:
  %t107 = load ptr, ptr %l0, !tbaa !29
  call void @std_2fchan_2ewithdraw_3cI64_3e(ptr %v0, ptr %t107)
  br label %bb34
bb33:
  br label %bb38
bb34:
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t111 = call i32 @std_2fchan_2esendOpen_3cI64_3e(ptr %v0, ptr %t109)
  store i32 %t111, ptr %l53
  %t112 = icmp ne i32 %t111, 0
  br i1 %t112, label %bb36, label %ok.113, !prof !99
ok.113:
  br label %bb35
bb35:
  br label %bb37
bb36:
  %t114 = load i32, ptr %l53, !tbaa !23
  %t115 = lshr i32 %t114, 16
  %t116 = and i32 %t114, 65535
  %t117 = icmp eq i32 %t115, 1
  %t118 = select i1 %t117, i32 1, i32 0
  %t119 = icmp eq i32 %t114, 0
  %t120 = shl i32 %t118, 16
  %t121 = or i32 %t120, %t116
  %t122 = select i1 %t119, i32 0, i32 %t121
  store i32 %t122, ptr %rv
  br label %ret
bb37:
  br label %bb38
bb38:
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t126 = getelementptr %"std/chan:Chan.2a97fb60857ef5a63442ec031c672e33", ptr %t124, i32 0, i32 12
  %t128 = call i32 @pthread_mutex_unlock(ptr %t126)
  store i32 %t128, ptr %l57
  br label %bb39
bb39:
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @std_2fchan_2eSend_3cstd_2fchan_3areading_3e(ptr %v0, ptr %a0, %"std/chan:reading" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l5 = alloca i32
  %l11 = alloca i1
  %l20 = alloca i32
  %l22 = alloca i32
  %l26 = alloca i64
  %l29 = alloca i1
  %l34 = alloca i1
  %l43 = alloca i32
  %l46 = alloca i1
  %l53 = alloca i32
  %l57 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/chan:Chan.2a97fb60857ef5a63442ec031c672e33", ptr %t1, i32 0, i32 12
  %t5 = call i32 @pthread_mutex_lock(ptr %t3)
  store i32 %t5, ptr %l5
  br label %bb1
bb1:
  br label %bb2
bb2:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"std/chan:Chan.2a97fb60857ef5a63442ec031c672e33", ptr %t6, i32 0, i32 4
  %t9 = load i64, ptr %t8, !tbaa !24
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"std/chan:Chan.2a97fb60857ef5a63442ec031c672e33", ptr %t10, i32 0, i32 0
  %t13 = load i64, ptr %t12, !tbaa !24
  %t16 = icmp eq i64 %t9, %t13
  br i1 %t16, label %bb3, label %bb4
bb3:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"std/chan:Chan.2a97fb60857ef5a63442ec031c672e33", ptr %t18, i32 0, i32 8
  %t21 = load i1, ptr %t20, !tbaa !21
  %t23 = xor i1 %t21, true
  store i1 %t23, ptr %l11, !tbaa !21
  br label %bb5
bb4:
  store i1 false, ptr %l11, !tbaa !21
  br label %bb5
bb5:
  %t25 = load i1, ptr %l11, !tbaa !21
  %t26 = xor i1 %t25, true
  br i1 %t26, label %bb6, label %bb7
bb6:
  br label %bb11
bb7:
  br label %bb8
bb8:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"std/chan:Chan.2a97fb60857ef5a63442ec031c672e33", ptr %t28, i32 0, i32 14
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"std/chan:Chan.2a97fb60857ef5a63442ec031c672e33", ptr %t31, i32 0, i32 12
  %t36 = call i32 @pthread_cond_wait(ptr %t30, ptr %t33)
  store i32 %t36, ptr %l20
  br label %bb9
bb9:
  br label %bb10
bb10:
  br label %bb2
bb11:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = call i32 @std_2fchan_2esendOpen_3cI64_3e(ptr %v0, ptr %t37)
  store i32 %t39, ptr %l22
  %t40 = icmp ne i32 %t39, 0
  br i1 %t40, label %bb13, label %ok.41, !prof !99
ok.41:
  br label %bb12
bb12:
  br label %bb14
bb13:
  %t42 = load i32, ptr %l22, !tbaa !23
  %t43 = lshr i32 %t42, 16
  %t44 = and i32 %t42, 65535
  %t45 = icmp eq i32 %t43, 1
  %t46 = select i1 %t45, i32 1, i32 0
  %t47 = icmp eq i32 %t42, 0
  %t48 = shl i32 %t46, 16
  %t49 = or i32 %t48, %t44
  %t50 = select i1 %t47, i32 0, i32 %t49
  store i32 %t50, ptr %rv
  br label %ret
bb14:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t56 = call i64 @std_2fchan_2eplace_3cstd_2fchan_3areading_3e(ptr %v0, ptr %t52, %"std/chan:reading" %a1)
  store i64 %t56, ptr %l26
  br label %bb15
bb15:
  %t57 = load i64, ptr %l26, !tbaa !24
  store i64 %t57, ptr %l2, !tbaa !24
  br label %bb16
bb16:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"std/chan:Chan.2a97fb60857ef5a63442ec031c672e33", ptr %t58, i32 0, i32 5
  %t61 = load i1, ptr %t60, !tbaa !21
  br i1 %t61, label %bb17, label %bb18
bb17:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"std/chan:Chan.2a97fb60857ef5a63442ec031c672e33", ptr %t63, i32 0, i32 7
  %t66 = load i64, ptr %t65, !tbaa !24
  %t67 = load i64, ptr %l2, !tbaa !24
  %t70 = icmp sle i64 %t66, %t67
  store i1 %t70, ptr %l29, !tbaa !21
  br label %bb19
bb18:
  store i1 false, ptr %l29, !tbaa !21
  br label %bb19
bb19:
  %t72 = load i1, ptr %l29, !tbaa !21
  br i1 %t72, label %bb20, label %bb21
bb20:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"std/chan:Chan.2a97fb60857ef5a63442ec031c672e33", ptr %t73, i32 0, i32 8
  %t76 = load i1, ptr %t75, !tbaa !21
  %t78 = xor i1 %t76, true
  store i1 %t78, ptr %l34, !tbaa !21
  br label %bb22
bb21:
  store i1 false, ptr %l34, !tbaa !21
  br label %bb22
bb22:
  %t80 = load i1, ptr %l34, !tbaa !21
  %t81 = xor i1 %t80, true
  br i1 %t81, label %bb23, label %bb24
bb23:
  br label %bb28
bb24:
  br label %bb25
bb25:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr %"std/chan:Chan.2a97fb60857ef5a63442ec031c672e33", ptr %t83, i32 0, i32 14
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t88 = getelementptr %"std/chan:Chan.2a97fb60857ef5a63442ec031c672e33", ptr %t86, i32 0, i32 12
  %t91 = call i32 @pthread_cond_wait(ptr %t85, ptr %t88)
  store i32 %t91, ptr %l43
  br label %bb26
bb26:
  br label %bb27
bb27:
  br label %bb16
bb28:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"std/chan:Chan.2a97fb60857ef5a63442ec031c672e33", ptr %t92, i32 0, i32 5
  %t95 = load i1, ptr %t94, !tbaa !21
  br i1 %t95, label %bb29, label %bb30
bb29:
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = getelementptr %"std/chan:Chan.2a97fb60857ef5a63442ec031c672e33", ptr %t97, i32 0, i32 7
  %t100 = load i64, ptr %t99, !tbaa !24
  %t101 = load i64, ptr %l2, !tbaa !24
  %t104 = icmp sle i64 %t100, %t101
  store i1 %t104, ptr %l46, !tbaa !21
  br label %bb31
bb30:
  store i1 false, ptr %l46, !tbaa !21
  br label %bb31
bb31:
  %t106 = load i1, ptr %l46, !tbaa !21
  br i1 %t106, label %bb32, label %bb33
bb32:
  %t107 = load ptr, ptr %l0, !tbaa !29
  call void @std_2fchan_2ewithdraw_3cI64_3e(ptr %v0, ptr %t107)
  br label %bb34
bb33:
  br label %bb38
bb34:
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t111 = call i32 @std_2fchan_2esendOpen_3cI64_3e(ptr %v0, ptr %t109)
  store i32 %t111, ptr %l53
  %t112 = icmp ne i32 %t111, 0
  br i1 %t112, label %bb36, label %ok.113, !prof !99
ok.113:
  br label %bb35
bb35:
  br label %bb37
bb36:
  %t114 = load i32, ptr %l53, !tbaa !23
  %t115 = lshr i32 %t114, 16
  %t116 = and i32 %t114, 65535
  %t117 = icmp eq i32 %t115, 1
  %t118 = select i1 %t117, i32 1, i32 0
  %t119 = icmp eq i32 %t114, 0
  %t120 = shl i32 %t118, 16
  %t121 = or i32 %t120, %t116
  %t122 = select i1 %t119, i32 0, i32 %t121
  store i32 %t122, ptr %rv
  br label %ret
bb37:
  br label %bb38
bb38:
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t126 = getelementptr %"std/chan:Chan.2a97fb60857ef5a63442ec031c672e33", ptr %t124, i32 0, i32 12
  %t128 = call i32 @pthread_mutex_unlock(ptr %t126)
  store i32 %t128, ptr %l57
  br label %bb39
bb39:
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @std_2fchan_2eoldest_3cI32_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l3 = alloca { i64, ptr }
  %l7 = alloca ptr
  %l14 = alloca ptr
  %l18 = alloca ptr
  %l24 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/chan:Chan.2a97fb60857ef5a63442ec031c672e33", ptr %t1, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l3, !tbaa !27
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"std/chan:Chan.2a97fb60857ef5a63442ec031c672e33", ptr %t5, i32 0, i32 2
  %t8 = load i64, ptr %t7, !tbaa !24
  %t10 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t11 = load ptr, ptr %t10, !tbaa !27
  %t12 = getelementptr i32, ptr %t11, i64 %t8
  %t13 = load i32, ptr %t12, !tbaa !33
  store i32 %t13, ptr %l1, !tbaa !23
  %t15 = load ptr, ptr %l0, !tbaa !29
  store ptr %t15, ptr %l7, !tbaa !29
  %t16 = load ptr, ptr %l7, !tbaa !29
  %t17 = getelementptr %"std/chan:Chan.2a97fb60857ef5a63442ec031c672e33", ptr %t16, i32 0, i32 2
  %t18 = load i64, ptr %t17, !tbaa !24
  %t21 = add i64 %t18, 1
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"std/chan:Chan.2a97fb60857ef5a63442ec031c672e33", ptr %t22, i32 0, i32 0
  %t25 = load i64, ptr %t24, !tbaa !24
  %t28 = srem i64 %t21, %t25
  %t30 = load ptr, ptr %l7, !tbaa !29
  %t31 = getelementptr %"std/chan:Chan.2a97fb60857ef5a63442ec031c672e33", ptr %t30, i32 0, i32 2
  store i64 %t28, ptr %t31, !tbaa !24
  %t32 = load ptr, ptr %l0, !tbaa !29
  store ptr %t32, ptr %l14, !tbaa !29
  %t33 = load ptr, ptr %l14, !tbaa !29
  %t34 = getelementptr %"std/chan:Chan.2a97fb60857ef5a63442ec031c672e33", ptr %t33, i32 0, i32 4
  %t35 = load i64, ptr %t34, !tbaa !24
  %t38 = sub i64 %t35, 1
  %t40 = load ptr, ptr %l14, !tbaa !29
  %t41 = getelementptr %"std/chan:Chan.2a97fb60857ef5a63442ec031c672e33", ptr %t40, i32 0, i32 4
  store i64 %t38, ptr %t41, !tbaa !24
  %t42 = load ptr, ptr %l0, !tbaa !29
  store ptr %t42, ptr %l18, !tbaa !29
  %t43 = load ptr, ptr %l18, !tbaa !29
  %t44 = getelementptr %"std/chan:Chan.2a97fb60857ef5a63442ec031c672e33", ptr %t43, i32 0, i32 7
  %t45 = load i64, ptr %t44, !tbaa !24
  %t48 = add i64 %t45, 1
  %t50 = load ptr, ptr %l18, !tbaa !29
  %t51 = getelementptr %"std/chan:Chan.2a97fb60857ef5a63442ec031c672e33", ptr %t50, i32 0, i32 7
  store i64 %t48, ptr %t51, !tbaa !24
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"std/chan:Chan.2a97fb60857ef5a63442ec031c672e33", ptr %t52, i32 0, i32 14
  %t56 = call i32 @pthread_cond_broadcast(ptr %t54)
  store i32 %t56, ptr %l24
  br label %bb1
bb1:
  %t57 = load ptr, ptr %l0, !tbaa !29
  call void @std_2fchan_2ewakeParked_3cI64_3e(ptr %v0, ptr %t57)
  br label %bb2
bb2:
  %t59 = load i32, ptr %l1, !tbaa !23
  store i32 %t59, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local %"std/chan:reading" @std_2fchan_2eoldest_3cstd_2fchan_3areading_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"std/chan:reading"
  %l3 = alloca { i64, ptr }
  %l7 = alloca ptr
  %l14 = alloca ptr
  %l18 = alloca ptr
  %l24 = alloca i32
  %rv = alloca %"std/chan:reading"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/chan:Chan.2a97fb60857ef5a63442ec031c672e33", ptr %t1, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l3, !tbaa !27
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"std/chan:Chan.2a97fb60857ef5a63442ec031c672e33", ptr %t5, i32 0, i32 2
  %t8 = load i64, ptr %t7, !tbaa !24
  %t10 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t11 = load ptr, ptr %t10, !tbaa !27
  %t12 = getelementptr %"std/chan:reading", ptr %t11, i64 %t8
  %t13 = load %"std/chan:reading", ptr %t12
  store %"std/chan:reading" %t13, ptr %l1
  %t15 = load ptr, ptr %l0, !tbaa !29
  store ptr %t15, ptr %l7, !tbaa !29
  %t16 = load ptr, ptr %l7, !tbaa !29
  %t17 = getelementptr %"std/chan:Chan.2a97fb60857ef5a63442ec031c672e33", ptr %t16, i32 0, i32 2
  %t18 = load i64, ptr %t17, !tbaa !24
  %t21 = add i64 %t18, 1
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"std/chan:Chan.2a97fb60857ef5a63442ec031c672e33", ptr %t22, i32 0, i32 0
  %t25 = load i64, ptr %t24, !tbaa !24
  %t28 = srem i64 %t21, %t25
  %t30 = load ptr, ptr %l7, !tbaa !29
  %t31 = getelementptr %"std/chan:Chan.2a97fb60857ef5a63442ec031c672e33", ptr %t30, i32 0, i32 2
  store i64 %t28, ptr %t31, !tbaa !24
  %t32 = load ptr, ptr %l0, !tbaa !29
  store ptr %t32, ptr %l14, !tbaa !29
  %t33 = load ptr, ptr %l14, !tbaa !29
  %t34 = getelementptr %"std/chan:Chan.2a97fb60857ef5a63442ec031c672e33", ptr %t33, i32 0, i32 4
  %t35 = load i64, ptr %t34, !tbaa !24
  %t38 = sub i64 %t35, 1
  %t40 = load ptr, ptr %l14, !tbaa !29
  %t41 = getelementptr %"std/chan:Chan.2a97fb60857ef5a63442ec031c672e33", ptr %t40, i32 0, i32 4
  store i64 %t38, ptr %t41, !tbaa !24
  %t42 = load ptr, ptr %l0, !tbaa !29
  store ptr %t42, ptr %l18, !tbaa !29
  %t43 = load ptr, ptr %l18, !tbaa !29
  %t44 = getelementptr %"std/chan:Chan.2a97fb60857ef5a63442ec031c672e33", ptr %t43, i32 0, i32 7
  %t45 = load i64, ptr %t44, !tbaa !24
  %t48 = add i64 %t45, 1
  %t50 = load ptr, ptr %l18, !tbaa !29
  %t51 = getelementptr %"std/chan:Chan.2a97fb60857ef5a63442ec031c672e33", ptr %t50, i32 0, i32 7
  store i64 %t48, ptr %t51, !tbaa !24
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"std/chan:Chan.2a97fb60857ef5a63442ec031c672e33", ptr %t52, i32 0, i32 14
  %t56 = call i32 @pthread_cond_broadcast(ptr %t54)
  store i32 %t56, ptr %l24
  br label %bb1
bb1:
  %t57 = load ptr, ptr %l0, !tbaa !29
  call void @std_2fchan_2ewakeParked_3cI64_3e(ptr %v0, ptr %t57)
  br label %bb2
bb2:
  %t59 = load %"std/chan:reading", ptr %l1
  store %"std/chan:reading" %t59, ptr %rv
  br label %ret
ret:
  %rr = load %"std/chan:reading", ptr %rv
  ret %"std/chan:reading" %rr
}

define dso_local i64 @std_2fchan_2epark_3cI32_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca i64
  %l2 = alloca i64
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call i64 @std_2fcancel_2ePark(i32 -1)
  store i64 %t1, ptr %l2
  br label %bb1
bb1:
  %t2 = load i64, ptr %l2, !tbaa !24
  store i64 %t2, ptr %l1, !tbaa !24
  %t5 = getelementptr %"std/chan:Chan.2a97fb60857ef5a63442ec031c672e33", ptr %a0, i32 0, i32 10
  %t6 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t5, i64 %t6)
  br label %bb2
bb2:
  %t9 = load i64, ptr %l1, !tbaa !24
  store i64 %t9, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @std_2fchan_2eplace_3cI32_3e(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l6 = alloca ptr
  %l7 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i32
  %l14 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l20 = alloca ptr
  %l27 = alloca ptr
  %l31 = alloca ptr
  %l37 = alloca i32
  %rv = alloca i64
  %t30 = alloca i64
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/chan:Chan.2a97fb60857ef5a63442ec031c672e33", ptr %t1, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t8 = icmp eq i64 %t6, 0
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l6, !tbaa !29
  %t11 = call ptr @__olang_region_make(ptr %v0)
  %t12 = ptrtoint ptr %t11 to i64
  store i64 %t12, ptr %l7, !tbaa !24
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"std/chan:Chan.2a97fb60857ef5a63442ec031c672e33", ptr %t13, i32 0, i32 0
  %t16 = load i64, ptr %t15, !tbaa !24
  store i64 %t16, ptr %l9, !tbaa !24
  %t17 = load i32, ptr %l1, !tbaa !23
  store i32 %t17, ptr %l10, !tbaa !23
  %t18 = load i64, ptr %l9, !tbaa !24
  %t19 = icmp sge i64 %t18, 0
  br i1 %t19, label %bb3, label %bb4
bb2:
  br label %bb7
bb3:
  %t21 = load i64, ptr %l9, !tbaa !24
  %t22 = icmp sle i64 %t21, 2305843009213693951
  br i1 %t22, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_f51c3b74f2d4a8af_eaf8dafb70d5bb93)
  unreachable
bb5:
  %t24 = load i64, ptr %l9, !tbaa !24
  %t25 = mul i64 %t24, 4
  %t26 = load i64, ptr %l7
  %t27 = inttoptr i64 %t26 to ptr
  %t28 = call ptr @__olang_held_alloc(ptr %t27, i64 %t25)
  %t29 = load i32, ptr %l10, !tbaa !23
  store i64 0, ptr %t30
  br label %fill.31
fill.31:
  %t34 = load i64, ptr %t30
  %t35 = icmp slt i64 %t34, %t24
  br i1 %t35, label %fillb.32, label %filld.33
fillb.32:
  %t36 = getelementptr i32, ptr %t28, i64 %t34
  store i32 %t29, ptr %t36
  %t37 = add i64 %t34, 1
  store i64 %t37, ptr %t30
  br label %fill.31
filld.33:
  %t38 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t39 = insertvalue { i64, ptr } %t38, ptr %t28, 1
  %t40 = load ptr, ptr %l6, !tbaa !29
  %t41 = getelementptr %"std/chan:Chan.2a97fb60857ef5a63442ec031c672e33", ptr %t40, i32 0, i32 1
  %t42 = load { i64, ptr }, ptr %t41, !tbaa !27
  store { i64, ptr } %t42, ptr %l14, !tbaa !27
  %t44 = load ptr, ptr %l6, !tbaa !29
  %t45 = getelementptr %"std/chan:Chan.2a97fb60857ef5a63442ec031c672e33", ptr %t44, i32 0, i32 1
  store { i64, ptr } %t39, ptr %t45, !tbaa !27
  %t46 = load { i64, ptr }, ptr %l14
  %t47 = extractvalue { i64, ptr } %t46, 1
  call void @__olang_region_release(ptr %t47)
  store { i64, ptr } zeroinitializer, ptr %l14
  br label %bb7
bb6:
  call void @__olang_check_failed(ptr @olang_loc_f51c3b74f2d4a8af_eaf8dafb70d5bb93)
  unreachable
bb7:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"std/chan:Chan.2a97fb60857ef5a63442ec031c672e33", ptr %t48, i32 0, i32 1
  %t51 = load { i64, ptr }, ptr %t50, !tbaa !27
  store { i64, ptr } %t51, ptr %l16, !tbaa !27
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"std/chan:Chan.2a97fb60857ef5a63442ec031c672e33", ptr %t52, i32 0, i32 3
  %t55 = load i64, ptr %t54, !tbaa !24
  %t56 = load i32, ptr %l1, !tbaa !23
  %t59 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !27
  %t61 = getelementptr i32, ptr %t60, i64 %t55
  store i32 %t56, ptr %t61, !tbaa !33
  %t62 = load ptr, ptr %l0, !tbaa !29
  store ptr %t62, ptr %l20, !tbaa !29
  %t63 = load ptr, ptr %l20, !tbaa !29
  %t64 = getelementptr %"std/chan:Chan.2a97fb60857ef5a63442ec031c672e33", ptr %t63, i32 0, i32 3
  %t65 = load i64, ptr %t64, !tbaa !24
  %t68 = add i64 %t65, 1
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"std/chan:Chan.2a97fb60857ef5a63442ec031c672e33", ptr %t69, i32 0, i32 0
  %t72 = load i64, ptr %t71, !tbaa !24
  %t75 = srem i64 %t68, %t72
  %t77 = load ptr, ptr %l20, !tbaa !29
  %t78 = getelementptr %"std/chan:Chan.2a97fb60857ef5a63442ec031c672e33", ptr %t77, i32 0, i32 3
  store i64 %t75, ptr %t78, !tbaa !24
  %t79 = load ptr, ptr %l0, !tbaa !29
  store ptr %t79, ptr %l27, !tbaa !29
  %t80 = load ptr, ptr %l27, !tbaa !29
  %t81 = getelementptr %"std/chan:Chan.2a97fb60857ef5a63442ec031c672e33", ptr %t80, i32 0, i32 4
  %t82 = load i64, ptr %t81, !tbaa !24
  %t85 = add i64 %t82, 1
  %t87 = load ptr, ptr %l27, !tbaa !29
  %t88 = getelementptr %"std/chan:Chan.2a97fb60857ef5a63442ec031c672e33", ptr %t87, i32 0, i32 4
  store i64 %t85, ptr %t88, !tbaa !24
  %t89 = load ptr, ptr %l0, !tbaa !29
  store ptr %t89, ptr %l31, !tbaa !29
  %t90 = load ptr, ptr %l31, !tbaa !29
  %t91 = getelementptr %"std/chan:Chan.2a97fb60857ef5a63442ec031c672e33", ptr %t90, i32 0, i32 6
  %t92 = load i64, ptr %t91, !tbaa !24
  %t95 = add i64 %t92, 1
  %t97 = load ptr, ptr %l31, !tbaa !29
  %t98 = getelementptr %"std/chan:Chan.2a97fb60857ef5a63442ec031c672e33", ptr %t97, i32 0, i32 6
  store i64 %t95, ptr %t98, !tbaa !24
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = getelementptr %"std/chan:Chan.2a97fb60857ef5a63442ec031c672e33", ptr %t99, i32 0, i32 13
  %t103 = call i32 @pthread_cond_broadcast(ptr %t101)
  store i32 %t103, ptr %l37
  br label %bb8
bb8:
  %t104 = load ptr, ptr %l0, !tbaa !29
  call void @std_2fchan_2ewakeParked_3cI64_3e(ptr %v0, ptr %t104)
  br label %bb9
bb9:
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t108 = getelementptr %"std/chan:Chan.2a97fb60857ef5a63442ec031c672e33", ptr %t106, i32 0, i32 6
  %t109 = load i64, ptr %t108, !tbaa !24
  %t111 = sub i64 %t109, 1
  store i64 %t111, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @std_2fchan_2eplace_3cstd_2fchan_3areading_3e(ptr %v0, ptr %a0, %"std/chan:reading" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"std/chan:reading"
  %l6 = alloca ptr
  %l7 = alloca i64
  %l9 = alloca i64
  %l10 = alloca %"std/chan:reading"
  %l14 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l20 = alloca ptr
  %l27 = alloca ptr
  %l31 = alloca ptr
  %l37 = alloca i32
  %rv = alloca i64
  %t30 = alloca i64
  store ptr %a0, ptr %l0
  store %"std/chan:reading" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/chan:Chan.2a97fb60857ef5a63442ec031c672e33", ptr %t1, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t8 = icmp eq i64 %t6, 0
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l6, !tbaa !29
  %t11 = call ptr @__olang_region_make(ptr %v0)
  %t12 = ptrtoint ptr %t11 to i64
  store i64 %t12, ptr %l7, !tbaa !24
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"std/chan:Chan.2a97fb60857ef5a63442ec031c672e33", ptr %t13, i32 0, i32 0
  %t16 = load i64, ptr %t15, !tbaa !24
  store i64 %t16, ptr %l9, !tbaa !24
  %t17 = load %"std/chan:reading", ptr %l1
  store %"std/chan:reading" %t17, ptr %l10
  %t18 = load i64, ptr %l9, !tbaa !24
  %t19 = icmp sge i64 %t18, 0
  br i1 %t19, label %bb3, label %bb4
bb2:
  br label %bb7
bb3:
  %t21 = load i64, ptr %l9, !tbaa !24
  %t22 = icmp sle i64 %t21, 576460752303423487
  br i1 %t22, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_772c54764e337a02_1b08b3073a69a3ee)
  unreachable
bb5:
  %t24 = load i64, ptr %l9, !tbaa !24
  %t25 = mul i64 %t24, 16
  %t26 = load i64, ptr %l7
  %t27 = inttoptr i64 %t26 to ptr
  %t28 = call ptr @__olang_held_alloc(ptr %t27, i64 %t25)
  %t29 = load %"std/chan:reading", ptr %l10
  store i64 0, ptr %t30
  br label %fill.31
fill.31:
  %t34 = load i64, ptr %t30
  %t35 = icmp slt i64 %t34, %t24
  br i1 %t35, label %fillb.32, label %filld.33
fillb.32:
  %t36 = getelementptr %"std/chan:reading", ptr %t28, i64 %t34
  store %"std/chan:reading" %t29, ptr %t36
  %t37 = add i64 %t34, 1
  store i64 %t37, ptr %t30
  br label %fill.31
filld.33:
  %t38 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t39 = insertvalue { i64, ptr } %t38, ptr %t28, 1
  %t40 = load ptr, ptr %l6, !tbaa !29
  %t41 = getelementptr %"std/chan:Chan.2a97fb60857ef5a63442ec031c672e33", ptr %t40, i32 0, i32 1
  %t42 = load { i64, ptr }, ptr %t41, !tbaa !27
  store { i64, ptr } %t42, ptr %l14, !tbaa !27
  %t44 = load ptr, ptr %l6, !tbaa !29
  %t45 = getelementptr %"std/chan:Chan.2a97fb60857ef5a63442ec031c672e33", ptr %t44, i32 0, i32 1
  store { i64, ptr } %t39, ptr %t45, !tbaa !27
  %t46 = load { i64, ptr }, ptr %l14
  %t47 = extractvalue { i64, ptr } %t46, 1
  call void @__olang_region_release(ptr %t47)
  store { i64, ptr } zeroinitializer, ptr %l14
  br label %bb7
bb6:
  call void @__olang_check_failed(ptr @olang_loc_772c54764e337a02_1b08b3073a69a3ee)
  unreachable
bb7:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"std/chan:Chan.2a97fb60857ef5a63442ec031c672e33", ptr %t48, i32 0, i32 1
  %t51 = load { i64, ptr }, ptr %t50, !tbaa !27
  store { i64, ptr } %t51, ptr %l16, !tbaa !27
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"std/chan:Chan.2a97fb60857ef5a63442ec031c672e33", ptr %t52, i32 0, i32 3
  %t55 = load i64, ptr %t54, !tbaa !24
  %t56 = load %"std/chan:reading", ptr %l1
  %t59 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !27
  %t61 = getelementptr %"std/chan:reading", ptr %t60, i64 %t55
  store %"std/chan:reading" %t56, ptr %t61
  %t62 = load ptr, ptr %l0, !tbaa !29
  store ptr %t62, ptr %l20, !tbaa !29
  %t63 = load ptr, ptr %l20, !tbaa !29
  %t64 = getelementptr %"std/chan:Chan.2a97fb60857ef5a63442ec031c672e33", ptr %t63, i32 0, i32 3
  %t65 = load i64, ptr %t64, !tbaa !24
  %t68 = add i64 %t65, 1
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"std/chan:Chan.2a97fb60857ef5a63442ec031c672e33", ptr %t69, i32 0, i32 0
  %t72 = load i64, ptr %t71, !tbaa !24
  %t75 = srem i64 %t68, %t72
  %t77 = load ptr, ptr %l20, !tbaa !29
  %t78 = getelementptr %"std/chan:Chan.2a97fb60857ef5a63442ec031c672e33", ptr %t77, i32 0, i32 3
  store i64 %t75, ptr %t78, !tbaa !24
  %t79 = load ptr, ptr %l0, !tbaa !29
  store ptr %t79, ptr %l27, !tbaa !29
  %t80 = load ptr, ptr %l27, !tbaa !29
  %t81 = getelementptr %"std/chan:Chan.2a97fb60857ef5a63442ec031c672e33", ptr %t80, i32 0, i32 4
  %t82 = load i64, ptr %t81, !tbaa !24
  %t85 = add i64 %t82, 1
  %t87 = load ptr, ptr %l27, !tbaa !29
  %t88 = getelementptr %"std/chan:Chan.2a97fb60857ef5a63442ec031c672e33", ptr %t87, i32 0, i32 4
  store i64 %t85, ptr %t88, !tbaa !24
  %t89 = load ptr, ptr %l0, !tbaa !29
  store ptr %t89, ptr %l31, !tbaa !29
  %t90 = load ptr, ptr %l31, !tbaa !29
  %t91 = getelementptr %"std/chan:Chan.2a97fb60857ef5a63442ec031c672e33", ptr %t90, i32 0, i32 6
  %t92 = load i64, ptr %t91, !tbaa !24
  %t95 = add i64 %t92, 1
  %t97 = load ptr, ptr %l31, !tbaa !29
  %t98 = getelementptr %"std/chan:Chan.2a97fb60857ef5a63442ec031c672e33", ptr %t97, i32 0, i32 6
  store i64 %t95, ptr %t98, !tbaa !24
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = getelementptr %"std/chan:Chan.2a97fb60857ef5a63442ec031c672e33", ptr %t99, i32 0, i32 13
  %t103 = call i32 @pthread_cond_broadcast(ptr %t101)
  store i32 %t103, ptr %l37
  br label %bb8
bb8:
  %t104 = load ptr, ptr %l0, !tbaa !29
  call void @std_2fchan_2ewakeParked_3cI64_3e(ptr %v0, ptr %t104)
  br label %bb9
bb9:
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t108 = getelementptr %"std/chan:Chan.2a97fb60857ef5a63442ec031c672e33", ptr %t106, i32 0, i32 6
  %t109 = load i64, ptr %t108, !tbaa !24
  %t111 = sub i64 %t109, 1
  store i64 %t111, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i32 @std_2fchan_2esendOpen_3cI32_3e(ptr %v0, ptr %a0) #0 {
entry:
  %r = tail call i32 @std_2fchan_2esendOpen_3cI64_3e(ptr %v0, ptr %a0)
  ret i32 %r
}

define dso_local i32 @std_2fchan_2esendOpen_3cstd_2fchan_3areading_3e(ptr %v0, ptr %a0) #0 {
entry:
  %r = tail call i32 @std_2fchan_2esendOpen_3cI64_3e(ptr %v0, ptr %a0)
  ret i32 %r
}

define dso_local void @std_2fchan_2esleep_3cI32_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l5 = alloca i32
  %l10 = alloca i32
  %l11 = alloca ptr
  store ptr %a0, ptr %l0
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/chan:Chan.2a97fb60857ef5a63442ec031c672e33", ptr %t1, i32 0, i32 12
  %t5 = call i32 @pthread_mutex_unlock(ptr %t3)
  store i32 %t5, ptr %l5
  br label %bb1
bb1:
  %t7 = load i64, ptr %l2, !tbaa !24
  call void @std_2fcancel_2estd_2fcancel_3aToken_2eSleep(ptr %v1, ptr %a1, i64 %t7)
  br label %bb2
bb2:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"std/chan:Chan.2a97fb60857ef5a63442ec031c672e33", ptr %t10, i32 0, i32 12
  %t14 = call i32 @pthread_mutex_lock(ptr %t12)
  store i32 %t14, ptr %l10
  br label %bb3
bb3:
  %t15 = load ptr, ptr %l0, !tbaa !29
  store ptr %t15, ptr %l11, !tbaa !29
  %t16 = load ptr, ptr %l11, !tbaa !29
  %t17 = getelementptr %"std/chan:Chan.2a97fb60857ef5a63442ec031c672e33", ptr %t16, i32 0, i32 11
  %t18 = load i64, ptr %t17, !tbaa !24
  %t21 = add i64 %t18, 1
  %t23 = load ptr, ptr %l11, !tbaa !29
  %t24 = getelementptr %"std/chan:Chan.2a97fb60857ef5a63442ec031c672e33", ptr %t23, i32 0, i32 11
  store i64 %t21, ptr %t24, !tbaa !24
  %t25 = load i64, ptr %l2, !tbaa !24
  call void @std_2fcancel_2eRearm(i64 %t25)
  br label %bb4
bb4:
  br label %ret
ret:
  ret void
}

define dso_local { i32, i32 } @std_2fchan_2estd_2fchan_3aChan_3cI32_3e_2eNext_3cI32_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca i32
  %l3 = alloca i32
  %l4 = alloca i32
  %l6 = alloca i1
  %rv = alloca { i32, i32 }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call { i32, i32 } @std_2fchan_2eRecv_3cI32_3e(ptr %v0, ptr %a0)
  %t4 = extractvalue { i32, i32 } %t3, 1
  %t5 = extractvalue { i32, i32 } %t3, 0
  store i32 %t5, ptr %l4
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7, !prof !99
ok.7:
  store i32 %t4, ptr %l3
  br label %bb1
bb1:
  %t8 = load i32, ptr %l3, !tbaa !23
  store i32 %t8, ptr %l1, !tbaa !23
  br label %bb4
bb2:
  %t9 = load i32, ptr %l4, !tbaa !23
  %t10 = ashr i32 %t9, 16
  %t12 = icmp eq i32 %t10, 1
  store i1 %t12, ptr %l6, !tbaa !21
  br label %bb3
bb3:
  %t14 = insertvalue { i32, i32 } zeroinitializer, i32 65536, 0
  store { i32, i32 } %t14, ptr %rv
  br label %ret
bb4:
  %t15 = load i32, ptr %l1, !tbaa !23
  %t16 = insertvalue { i32, i32 } zeroinitializer, i32 %t15, 1
  store { i32, i32 } %t16, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i32 }, ptr %rv
  ret { i32, i32 } %rr
}

define dso_local void @std_2fchan_2eunparkReceiver_3cI32_3e(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l4 = alloca ptr
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l0, !tbaa !29
  store ptr %t5, ptr %l4, !tbaa !29
  %t6 = load ptr, ptr %l4, !tbaa !29
  %t7 = getelementptr %"std/chan:Chan.2a97fb60857ef5a63442ec031c672e33", ptr %t6, i32 0, i32 9
  %t8 = load i64, ptr %t7, !tbaa !24
  %t11 = sub i64 %t8, 1
  %t13 = load ptr, ptr %l4, !tbaa !29
  %t14 = getelementptr %"std/chan:Chan.2a97fb60857ef5a63442ec031c672e33", ptr %t13, i32 0, i32 9
  store i64 %t11, ptr %t14, !tbaa !24
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load i64, ptr %l1, !tbaa !24
  call void @std_2fchan_2eunpark_3cI32_3e(ptr %v0, ptr %t15, i64 %t16)
  br label %bb4
bb4:
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fchan_2eunpark_3cI32_3e(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  %l7 = alloca i1
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t7 = getelementptr %"std/chan:Chan.2a97fb60857ef5a63442ec031c672e33", ptr %a0, i32 0, i32 10
  %t8 = load i64, ptr %l1, !tbaa !24
  %t11 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eRemove_3cI64_3e(ptr %v0, ptr %t7, i64 %t8)
  store i1 %t11, ptr %l7
  br label %bb4
bb4:
  %t12 = load i64, ptr %l1, !tbaa !24
  call void @std_2fcancel_2eDone(i64 %t12)
  br label %bb5
bb5:
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fchan_2ewakeParked_3cI32_3e(ptr %v0, ptr %a0) #0 {
entry:
  tail call void @std_2fchan_2ewakeParked_3cI64_3e(ptr %v0, ptr %a0)
  ret void
}

define dso_local void @std_2fchan_2ewakeParked_3cstd_2fchan_3areading_3e(ptr %v0, ptr %a0) #0 {
entry:
  tail call void @std_2fchan_2ewakeParked_3cI64_3e(ptr %v0, ptr %a0)
  ret void
}

define dso_local void @std_2fchan_2ewithdraw_3cI32_3e(ptr %v0, ptr %a0) #0 {
entry:
  tail call void @std_2fchan_2ewithdraw_3cI64_3e(ptr %v0, ptr %a0)
  ret void
}

define dso_local void @std_2fchan_2ewithdraw_3cstd_2fchan_3areading_3e(ptr %v0, ptr %a0) #0 {
entry:
  tail call void @std_2fchan_2ewithdraw_3cI64_3e(ptr %v0, ptr %a0)
  ret void
}

define dso_local { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eIndexOf_3cI64_3e(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l13 = alloca i64
  %l16 = alloca i64
  %l25 = alloca i64
  %l28 = alloca i1
  %rv = alloca { i32, i64 }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l2, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t1, i32 0, i32 1
  %t4 = load i64, ptr %t3, !tbaa !24
  store i64 %t4, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t6 = load i64, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l2, !tbaa !24
  %t10 = icmp sgt i64 %t6, %t7
  br i1 %t10, label %bb1, label %bb2
bb1:
  %t12 = load i64, ptr %l4, !tbaa !24
  %t14 = icmp sgt i64 %t12, 0
  br i1 %t14, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l13, !tbaa !24
  br label %bb6
bb3:
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = load i64, ptr %l2, !tbaa !24
  %t20 = sub i64 %t16, %t17
  %t21 = load i64, ptr %l4, !tbaa !24
  %t24 = add i64 %t20, %t21
  %t26 = sub i64 %t24, 1
  %t27 = load i64, ptr %l4, !tbaa !24
  %t30 = sdiv i64 %t26, %t27
  store i64 %t30, ptr %l16, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l16, !tbaa !24
  br label %bb5
bb5:
  %t32 = load i64, ptr %l16, !tbaa !24
  store i64 %t32, ptr %l13, !tbaa !24
  br label %bb6
bb6:
  %t33 = load i64, ptr %l13, !tbaa !24
  store i64 %t33, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  %t34 = load i64, ptr %l5, !tbaa !24
  %t35 = sub i64 %t34, 1
  store i64 %t35, ptr %l25, !tbaa !24
  %t36 = load i64, ptr %l5, !tbaa !24
  %t37 = icmp slt i64 %t36, 2147483648
  %t38 = load i64, ptr %l6, !tbaa !24
  %t39 = icmp sge i64 %t38, 0
  %t42 = and i1 %t37, %t39
  store i1 %t42, ptr %l28, !tbaa !21
  br label %bb7
bb7:
  %t43 = load i64, ptr %l6, !tbaa !24
  %t44 = load i64, ptr %l5, !tbaa !24
  %t47 = icmp slt i64 %t43, %t44
  %t49 = xor i1 %t47, true
  br i1 %t49, label %bb8, label %bb9
bb8:
  br label %bb15
bb9:
  br label %bb10
bb10:
  %t51 = load i64, ptr %l2, !tbaa !24
  %t52 = load i64, ptr %l6, !tbaa !24
  %t53 = load i64, ptr %l4, !tbaa !24
  %t56 = mul i64 %t52, %t53
  %t59 = add i64 %t51, %t56
  store i64 %t59, ptr %l7, !tbaa !24
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t62 = load i64, ptr %l7, !tbaa !24
  %t64 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t61, i32 0, i32 0
  %t66 = getelementptr { i64, ptr }, ptr %t64, i32 0, i32 1
  %t67 = load ptr, ptr %t66, !tbaa !27
  %t68 = getelementptr i64, ptr %t67, i64 %t62
  %t69 = load i64, ptr %t68, !tbaa !34
  %t73 = icmp eq i64 %t69, %a1
  br i1 %t73, label %bb11, label %bb12
bb11:
  %t75 = load i64, ptr %l7, !tbaa !24
  %t77 = insertvalue { i32, i64 } zeroinitializer, i64 %t75, 1
  store { i32, i64 } %t77, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  br label %bb14
bb14:
  %t78 = load i64, ptr %l6, !tbaa !24
  %t81 = add i64 %t78, 1
  store i64 %t81, ptr %l6, !tbaa !24
  br label %bb7
bb15:
  %t84 = insertvalue { i32, i64 } zeroinitializer, i32 65537, 0
  store { i32, i64 } %t84, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i64 }, ptr %rv
  ret { i32, i64 } %rr
}

define dso_local i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eRemoveAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l10 = alloca i1
  %l18 = alloca i64
  %l26 = alloca i64
  %l29 = alloca i64
  %l56 = alloca ptr
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l10, !tbaa !21
  br label %bb3
bb2:
  %t5 = load i64, ptr %l1, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t6, i32 0, i32 1
  %t9 = load i64, ptr %t8, !tbaa !24
  %t12 = icmp sge i64 %t5, %t9
  store i1 %t12, ptr %l10, !tbaa !21
  br label %bb3
bb3:
  %t14 = load i1, ptr %l10, !tbaa !21
  br i1 %t14, label %bb4, label %bb5
bb4:
  store i32 65538, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load i64, ptr %l1, !tbaa !24
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t16, i32 0, i32 0
  %t21 = getelementptr { i64, ptr }, ptr %t19, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr i64, ptr %t22, i64 %t17
  %t24 = load i64, ptr %t23, !tbaa !34
  store i64 %t24, ptr %l18, !tbaa !24
  %t25 = load i64, ptr %l1, !tbaa !24
  store i64 %t25, ptr %l2, !tbaa !24
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t27, i32 0, i32 1
  %t30 = load i64, ptr %t29, !tbaa !24
  %t32 = sub i64 %t30, 1
  store i64 %t32, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t34 = load i64, ptr %l3, !tbaa !24
  %t35 = load i64, ptr %l2, !tbaa !24
  %t38 = icmp sgt i64 %t34, %t35
  br i1 %t38, label %bb7, label %bb8
bb7:
  %t40 = load i64, ptr %l4, !tbaa !24
  %t42 = icmp sgt i64 %t40, 0
  br i1 %t42, label %bb9, label %bb10
bb8:
  store i64 0, ptr %l26, !tbaa !24
  br label %bb12
bb9:
  %t44 = load i64, ptr %l3, !tbaa !24
  %t45 = load i64, ptr %l2, !tbaa !24
  %t48 = sub i64 %t44, %t45
  %t49 = load i64, ptr %l4, !tbaa !24
  %t52 = add i64 %t48, %t49
  %t54 = sub i64 %t52, 1
  %t55 = load i64, ptr %l4, !tbaa !24
  %t58 = sdiv i64 %t54, %t55
  store i64 %t58, ptr %l29, !tbaa !24
  br label %bb11
bb10:
  store i64 0, ptr %l29, !tbaa !24
  br label %bb11
bb11:
  %t60 = load i64, ptr %l29, !tbaa !24
  store i64 %t60, ptr %l26, !tbaa !24
  br label %bb12
bb12:
  %t61 = load i64, ptr %l26, !tbaa !24
  store i64 %t61, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb13
bb13:
  %t62 = load i64, ptr %l6, !tbaa !24
  %t63 = load i64, ptr %l5, !tbaa !24
  %t66 = icmp slt i64 %t62, %t63
  %t68 = xor i1 %t66, true
  br i1 %t68, label %bb14, label %bb15
bb14:
  br label %bb18
bb15:
  br label %bb16
bb16:
  %t70 = load i64, ptr %l2, !tbaa !24
  %t71 = load i64, ptr %l6, !tbaa !24
  %t72 = load i64, ptr %l4, !tbaa !24
  %t75 = mul i64 %t71, %t72
  %t78 = add i64 %t70, %t75
  store i64 %t78, ptr %l7, !tbaa !24
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t81 = load i64, ptr %l7, !tbaa !24
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t83 = load i64, ptr %l7, !tbaa !24
  %t85 = add i64 %t83, 1
  %t87 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t82, i32 0, i32 0
  %t89 = getelementptr { i64, ptr }, ptr %t87, i32 0, i32 1
  %t90 = load ptr, ptr %t89, !tbaa !27
  %t91 = getelementptr i64, ptr %t90, i64 %t85
  %t92 = load i64, ptr %t91, !tbaa !34
  %t95 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t80, i32 0, i32 0
  %t97 = getelementptr { i64, ptr }, ptr %t95, i32 0, i32 1
  %t98 = load ptr, ptr %t97, !tbaa !27
  %t99 = getelementptr i64, ptr %t98, i64 %t81
  store i64 %t92, ptr %t99, !tbaa !34
  br label %bb17
bb17:
  %t100 = load i64, ptr %l6, !tbaa !24
  %t103 = add i64 %t100, 1
  store i64 %t103, ptr %l6, !tbaa !24
  br label %bb13
bb18:
  %t105 = load ptr, ptr %l0, !tbaa !29
  store ptr %t105, ptr %l56, !tbaa !29
  %t106 = load ptr, ptr %l56, !tbaa !29
  %t107 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t106, i32 0, i32 1
  %t108 = load i64, ptr %t107, !tbaa !24
  %t111 = sub i64 %t108, 1
  %t113 = load ptr, ptr %l56, !tbaa !29
  %t114 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t113, i32 0, i32 1
  store i64 %t111, ptr %t114, !tbaa !24
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eRemove_3cI64_3e(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i32
  %l11 = alloca i32
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eIndexOf_3cI64_3e(ptr %v0, ptr %t1, i64 %a1)
  %t6 = extractvalue { i32, i64 } %t5, 1
  %t7 = extractvalue { i32, i64 } %t5, 0
  store i32 %t7, ptr %l7
  %t8 = icmp ne i32 %t7, 0
  br i1 %t8, label %bb2, label %ok.9, !prof !99
ok.9:
  store i64 %t6, ptr %l6
  br label %bb1
bb1:
  %t10 = load i64, ptr %l6, !tbaa !24
  store i64 %t10, ptr %l3, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  store i1 false, ptr %rv
  br label %ret
bb4:
  %t12 = load i64, ptr %l3, !tbaa !24
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t17 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eRemoveAt_3cI64_3e(ptr %v0, ptr %t13, i64 %t12)
  store i32 %t17, ptr %l11
  %t18 = icmp ne i32 %t17, 0
  br i1 %t18, label %bb6, label %ok.19, !prof !99
ok.19:
  br label %bb5
bb5:
  br label %bb8
bb6:
  br label %bb7
bb7:
  call void @__olang_check_failed(ptr @olang_loc_6aedc85f0c11dafa_37647e3d146f545e)
  unreachable
bb8:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

declare i32 @pthread_mutex_lock(ptr)
declare i32 @pthread_mutex_unlock(ptr)
declare i32 @pthread_cond_wait(ptr, ptr)
declare i32 @pthread_cond_broadcast(ptr)
declare ptr @__olang_region_make(ptr) noinline
declare void @__olang_check_failed(ptr) cold noreturn
define available_externally noalias ptr @__olang_held_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @__olang_region_release(ptr) noinline
define available_externally noalias ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  %head = load ptr, ptr %scope, !tbaa !59
  %isslot = icmp eq ptr %head, @__olang_slot_chunk
  br i1 %isslot, label %slot, label %plain
slot:
  %s = call ptr @__olang_slot_alloc(ptr %scope, i64 %rawsize)
  ret ptr %s
plain:
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
@__olang_slot_chunk = external global %olang.chunk
declare noalias ptr @__olang_slot_alloc(ptr, i64) noinline
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ; B19b: a benchmark build counts what this thread allocates - here and at the slow path's own bump, so each
  ; allocation is counted once wherever it is made (a region's and a forwarded scope's come back through here)
; @bench %bna = load i64, ptr @__olang_bench_allocs
; @bench %bna1 = add i64 %bna, 1
; @bench store i64 %bna1, ptr @__olang_bench_allocs
; @bench %bnb = load i64, ptr @__olang_bench_bytes
; @bench %bnb1 = add i64 %bnb, %size
; @bench store i64 %bnb1, ptr @__olang_bench_bytes
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
declare void @std_2fchan_2eClose_3cI64_3e(ptr %v0, ptr %a0)
declare i1 @std_2fcancel_2estd_2fcancel_3aToken_2eCancelled(ptr %v0, ptr %a0)
declare i32 @std_2fcancel_2estd_2fcancel_3aToken_2eReason(ptr %v0, ptr %a0)
declare i32 @std_2fchan_2esendOpen_3cI64_3e(ptr %v0, ptr %a0)
declare void @std_2fchan_2ewithdraw_3cI64_3e(ptr %v0, ptr %a0)
declare void @std_2fchan_2ewakeParked_3cI64_3e(ptr %v0, ptr %a0)
declare i64 @std_2fcancel_2ePark(i32 %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_f51c3b74f2d4a8af_eaf8dafb70d5bb93 = external constant [0 x i8]
@olang_loc_772c54764e337a02_1b08b3073a69a3ee = external constant [0 x i8]
declare void @std_2fcancel_2estd_2fcancel_3aToken_2eSleep(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fcancel_2eRearm(i64 %a0)
declare void @std_2fcancel_2eDone(i64 %a0)
@olang_loc_6aedc85f0c11dafa_37647e3d146f545e = external constant [0 x i8]

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
