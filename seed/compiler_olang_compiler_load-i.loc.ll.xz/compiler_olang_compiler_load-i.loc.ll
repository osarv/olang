; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

@olang_loc_112cef6ff8c5e600_e406a0f5f22f7c = weak_odr constant [54 x i8] c"std/prelude/map.olang:122: array length out of range\0A\00"
@olang_loc_4a226f1fbff82bc8_1ed4a6072c48064c = weak_odr constant [54 x i8] c"std/prelude/map.olang:122: array length out of range\0A\00"
@olang_loc_84aba8d42b34d7d2_ca574fe095a7686 = weak_odr constant [53 x i8] c"std/prelude/vec.olang:61: slice bounds out of range\0A\00"
@olang_loc_92280e297a968950_2e64b120260a431c = weak_odr constant [54 x i8] c"std/prelude/map.olang:105: slice bounds out of range\0A\00"
@olang_loc_9ee5a70effcba02d_b97d9820569a4089 = weak_odr constant [54 x i8] c"std/prelude/map.olang:102: slice bounds out of range\0A\00"
@olang_loc_b50f13e459394536_6a5df5a7d863bf22 = weak_odr constant [53 x i8] c"std/prelude/vec.olang:61: slice bounds out of range\0A\00"
@olang_loc_b5a6035365d2ddda_e798575aadca4ebe = weak_odr constant [54 x i8] c"std/prelude/map.olang:111: array length out of range\0A\00"
@olang_loc_bb7809cd4b0d08eb_b3326c955baff457 = weak_odr constant [54 x i8] c"std/prelude/map.olang:105: slice bounds out of range\0A\00"
@olang_loc_d9f58b89f20fce34_2aa3178b75e3e608 = weak_odr constant [53 x i8] c"std/prelude/vec.olang:61: slice bounds out of range\0A\00"
@olang_loc_e7404e0750e85aee_9621beedfd051e7a = weak_odr constant [54 x i8] c"std/prelude/map.olang:102: slice bounds out of range\0A\00"
@olang_loc_e89de1f8470e5b6f_c8d6736bd632addb = weak_odr constant [54 x i8] c"std/prelude/map.olang:111: array length out of range\0A\00"
