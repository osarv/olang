; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

@olang_loc_3930a330b99048b_60f181b178defbf = weak_odr constant [54 x i8] c"std/prelude/vec.olang:201: slice bounds out of range\0A\00"
@olang_loc_515f29ffee229a6d_d5fa4378f0cb8159 = weak_odr constant [53 x i8] c"std/prelude/vec.olang:52: array length out of range\0A\00"
@olang_loc_680953d89658a0b1_57ff2b2c427df88d = weak_odr constant [53 x i8] c"std/prelude/map.olang:84: array length out of range\0A\00"
@olang_loc_8bb3f1bab20e1466_8ca39d8fc682d88a = weak_odr constant [53 x i8] c"std/prelude/map.olang:84: array length out of range\0A\00"
@olang_loc_96f0c036d4cac36e_79ee3c1cc84010ea = weak_odr constant [53 x i8] c"std/prelude/vec.olang:36: array length out of range\0A\00"
@olang_loc_9fd14e3978a7323_df75a538d2991fcf = weak_odr constant [53 x i8] c"std/prelude/vec.olang:52: array length out of range\0A\00"
@olang_loc_f919bb22d713e8ac_19d1e0967e5f6368 = weak_odr constant [53 x i8] c"std/prelude/vec.olang:52: array length out of range\0A\00"
