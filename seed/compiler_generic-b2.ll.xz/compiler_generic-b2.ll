; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr, i64, ptr }
%olang.home = type { ptr, ptr }
%olang.slotscope = type { %olang.scope, i64, [8 x ptr] }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"compiler/generic:AnySlot" = type { i32, i32, i64, i64, i1, i32, i32 }
%"compiler/generic:fnRow" = type { i64, ptr, i1 }
%"compiler/generic:Program" = type { ptr, ptr, %"compiler/types:Table", %"compiler/facts:Table", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"compiler/generic:Origin", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/types:Table" = type { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i64, i64 }
%"compiler/facts:Table" = type { %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i64 }
%"compiler/generic:Origin" = type { i64, %"compiler/source:Span", i64, i32 }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/ast:TypeDecl" = type { i32, { i64, ptr }, i1, ptr, i32, i1, ptr, i32 }
%"compiler/ast:Func" = type { %"compiler/source:Span", ptr, i32, ptr, { i64, ptr }, { i64, ptr }, i1, i1, ptr, i32 }
%"compiler/generic:Binding" = type { i64, i64, { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/names:Entry" = type { i32, %"compiler/source:Span", i32, i1, ptr }
%"compiler/msgs:Nearest" = type { { i64, ptr }, { i64, ptr }, i64 }
%"compiler/load:Loader" = type { { i64, ptr }, ptr, ptr, ptr, ptr, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/load:Module" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i64, i1, ptr, ptr, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr, i1, i64, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr, ptr, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/names:Resolver" = type { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/names:Table" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"std/prelude/iterator:ViewGenerator.00c7c71992d6e1815cd052c47b979cdd" = type { { ptr, ptr } }
%"compiler/ast:VarDecl" = type { { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, i1, i1, i1 }
%"compiler/generic:folded" = type { i64, i64, i32 }
%"compiler/generic:ConstAsk" = type { i64, ptr, i32, i64, { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" = type { ptr, i64 }
%"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" = type { i32, i32 }
%"compiler/generic:Context" = type { i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" = type { i64, i64 }
%"compiler/generic:memberRow" = type { i64, %"compiler/source:Span", ptr, i32, { i64, ptr }, ptr, i32, i64 }
%"compiler/generic:Unmet" = type { i64, i32, i32, i1, i1, i1 }
%"compiler/generic:Desc" = type { i64, i32, i64, i64 }
%"compiler/ast:Sig" = type { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, i1, i1, i1, { i64, ptr }, i1 }
%"compiler/generic:AnyTable" = type { i32, i32, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/generic:pattern" = type { ptr, i64, i64, i32, ptr }
%"compiler/generic:varRow" = type { i64, i32, i32, i32, i32 }
%"compiler/ast:Param" = type { %"compiler/source:Span", i32, ptr, ptr }
%"compiler/ast:CaseDecl" = type { %"compiler/source:Span", i32, { i64, ptr }, i1, ptr }
%"compiler/generic:cursor" = type { { i64, ptr }, i64 }
%"compiler/generic:FnDefault" = type { i64, ptr, %"compiler/generic:Context" }
%"compiler/source:Source" = type { { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/ast:StructBody" = type { { i64, ptr }, ptr, { i64, ptr }, %"compiler/source:Span", { i64, ptr }, { i64, ptr } }
%"compiler/names:Ref" = type { i32, i64, i64 }
%"compiler/diagmsg:Msg" = type { i32, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/ast:Promise" = type { %"compiler/source:Span", i32, { i64, ptr } }
%"compiler/cond:Consts" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/fetch:Fetcher" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/source:Names" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/diag:Diagnostics" = type { i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, [3 x i64] }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
define dso_local { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAnySlots(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i32
  %l10 = alloca i32
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca ptr
  %l23 = alloca i32
  %l24 = alloca i1
  %l26 = alloca %"compiler/generic:AnySlot"
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i32
  %l35 = alloca i32
  %l36 = alloca { i64, ptr }
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i32
  %l40 = alloca i32
  %l41 = alloca { i64, ptr }
  %l42 = alloca i1
  %l43 = alloca { i64, ptr }
  %l44 = alloca i64
  %l45 = alloca i64
  %l46 = alloca i64
  %l47 = alloca i64
  %l48 = alloca i64
  %l49 = alloca i64
  %l50 = alloca { i64, ptr }
  %l54 = alloca { i64, ptr }
  %l55 = alloca i32
  %l62 = alloca i1
  %l66 = alloca i1
  %l69 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l70 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l73 = alloca { i64, ptr }
  %l81 = alloca { i64, ptr }
  %l87 = alloca i32
  %l90 = alloca ptr
  %l93 = alloca i1
  %l102 = alloca ptr
  %l103 = alloca i1
  %l118 = alloca i64
  %l121 = alloca i64
  %l140 = alloca { i64, ptr }
  %l144 = alloca i1
  %l145 = alloca i1
  %l149 = alloca i1
  %l153 = alloca ptr
  %l154 = alloca i32
  %l155 = alloca ptr
  %l159 = alloca i32
  %l160 = alloca i32
  %l165 = alloca ptr
  %l166 = alloca i32
  %l168 = alloca ptr
  %l172 = alloca i32
  %l174 = alloca i64
  %l177 = alloca i32
  %l178 = alloca i32
  %l180 = alloca i32
  %l181 = alloca i32
  %l182 = alloca i64
  %l183 = alloca i1
  %l185 = alloca ptr
  %l186 = alloca i32
  %l190 = alloca i64
  %l191 = alloca i32
  %l192 = alloca %"compiler/generic:AnySlot"
  %l204 = alloca i64
  %l208 = alloca i64
  %l211 = alloca i64
  %l232 = alloca i64
  %l236 = alloca i64
  %l247 = alloca { i64, ptr }
  %l253 = alloca i32
  %l263 = alloca i1
  %l264 = alloca ptr
  %l268 = alloca %"compiler/generic:fnRow"
  %l271 = alloca i1
  %l272 = alloca ptr
  %l273 = alloca i64
  %l277 = alloca i32
  %l278 = alloca i32
  %l282 = alloca ptr
  %l286 = alloca %"compiler/generic:fnRow"
  %l290 = alloca ptr
  %l294 = alloca i32
  %l295 = alloca { i64, ptr }
  %l299 = alloca i1
  %l302 = alloca { i64, ptr }
  %l304 = alloca i32
  %l307 = alloca i1
  %l310 = alloca { i64, ptr }
  %l312 = alloca i64
  %l316 = alloca ptr
  %l320 = alloca %"compiler/generic:fnRow"
  %l327 = alloca %"compiler/generic:AnySlot"
  %l332 = alloca i64
  %l335 = alloca %"compiler/generic:AnySlot"
  %l340 = alloca i64
  %l344 = alloca i64
  %l347 = alloca i64
  %l365 = alloca { i64, ptr }
  %l366 = alloca i64
  %l369 = alloca %"compiler/generic:AnySlot"
  %s0 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  %t588 = alloca i64
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/generic:Program", ptr %t1, i32 0, i32 72
  %t4 = load i32, ptr %l1, !tbaa !23
  %t7 = call { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Array_3_H5ded0725d411df67b2648301e639bd4e(ptr %v0, ptr %v1, ptr %t3, i32 %t4)
  %t8 = extractvalue { i32, { i64, ptr } } %t7, 1
  %t9 = extractvalue { i32, { i64, ptr } } %t7, 0
  store i32 %t9, ptr %l55
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb2, label %ok.11, !prof !99
ok.11:
  store { i64, ptr } %t8, ptr %l54
  br label %bb1
bb1:
  %t12 = load { i64, ptr }, ptr %l54, !tbaa !27
  store { i64, ptr } %t12, ptr %l50, !tbaa !27
  br label %bb8
bb2:
  br label %bb3
bb3:
  %t13 = icmp sge i64 0, 0
  br i1 %t13, label %bb4, label %bb5
bb4:
  %t15 = icmp sle i64 0, 230584300921369395
  br i1 %t15, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_c2f0255997df361c_a6c9f390e9e9df68)
  unreachable
bb6:
  %t17 = mul i64 0, 40
  %t18 = insertvalue { i64, ptr } undef, i64 0, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t19, ptr %l50, !tbaa !27
  br label %bb8
bb7:
  call void @__olang_check_failed(ptr @olang_loc_c2f0255997df361c_a6c9f390e9e9df68)
  unreachable
bb8:
  %t21 = load { i64, ptr }, ptr %l50, !tbaa !27
  store { i64, ptr } %t21, ptr %l2, !tbaa !27
  %t22 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t24 = extractvalue { i64, ptr } %t22, 0
  %t26 = icmp sgt i64 %t24, 0
  br i1 %t26, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l62, !tbaa !21
  br label %bb12
bb10:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/generic:Program", ptr %t28, i32 0, i32 72
  %t31 = load i32, ptr %l1, !tbaa !23
  %t34 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Array_3_H9e3d6110ebf70523261e6bda2644191a(ptr %v0, ptr %t30, i32 %t31)
  store i1 %t34, ptr %l66
  br label %bb11
bb11:
  %t35 = load i1, ptr %l66, !tbaa !21
  store i1 %t35, ptr %l62, !tbaa !21
  br label %bb12
bb12:
  %t36 = load i1, ptr %l62, !tbaa !21
  br i1 %t36, label %bb13, label %bb14
bb13:
  %t37 = load { i64, ptr }, ptr %l2, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t37, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  %t39 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eallFns(ptr %v0, ptr %t39)
  br label %bb16
bb16:
  %t41 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3aAnySlot_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t41, ptr %l69
  br label %bb17
bb17:
  %t42 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l69
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t42, ptr %l3
  %t43 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t43, ptr %l70
  br label %bb18
bb18:
  %t44 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l70
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t44, ptr %l4
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t46 = load i32, ptr %l1, !tbaa !23
  %t49 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAnyCovers(ptr %v0, ptr %s0, ptr %t45, i32 %t46)
  store { i64, ptr } %t49, ptr %l73
  br label %bb19
bb19:
  %t50 = load { i64, ptr }, ptr %l73, !tbaa !27
  store { i64, ptr } %t50, ptr %l5, !tbaa !27
  %t51 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t51, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t53 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t55 = extractvalue { i64, ptr } %t53, 0
  store i64 %t55, ptr %l8, !tbaa !24
  br label %bb20
bb20:
  %t57 = load i64, ptr %l7, !tbaa !24
  %t58 = load i64, ptr %l8, !tbaa !24
  %t61 = icmp slt i64 %t57, %t58
  %t63 = xor i1 %t61, true
  br i1 %t63, label %bb21, label %bb22
bb21:
  br label %bb74
bb22:
  br label %bb23
bb23:
  %t65 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t65, ptr %l81, !tbaa !27
  %t66 = load i64, ptr %l7, !tbaa !24
  %t68 = getelementptr { i64, ptr }, ptr %l81, i32 0, i32 1
  %t69 = load ptr, ptr %t68, !tbaa !27
  %t70 = getelementptr i32, ptr %t69, i64 %t66
  %t71 = load i32, ptr %t70, !tbaa !33
  store i32 %t71, ptr %l9, !tbaa !23
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/generic:Program", ptr %t73, i32 0, i32 2
  %t76 = load i32, ptr %l9, !tbaa !23
  %t79 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t75, i32 %t76)
  store i32 %t79, ptr %l87
  br label %bb24
bb24:
  %t80 = load i32, ptr %l87, !tbaa !23
  store i32 %t80, ptr %l10, !tbaa !23
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t82 = load i32, ptr %l10, !tbaa !23
  %t85 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2etypeDecl(ptr %v0, ptr %v0, ptr %t81, i32 %t82)
  store ptr %t85, ptr %l90
  br label %bb25
bb25:
  %t86 = load ptr, ptr %l90, !tbaa !29
  store ptr %t86, ptr %l11, !tbaa !29
  %t87 = load ptr, ptr %l11, !tbaa !29
  %t89 = icmp eq ptr %t87, null
  br i1 %t89, label %bb26, label %bb27
bb26:
  store i1 true, ptr %l93, !tbaa !21
  br label %bb28
bb27:
  %t91 = load ptr, ptr %l11, !tbaa !29
  %t93 = getelementptr %"compiler/ast:TypeDecl", ptr %t91, i32 0, i32 3
  %t94 = load ptr, ptr %t93, !tbaa !29
  %t96 = icmp eq ptr %t94, null
  store i1 %t96, ptr %l93, !tbaa !21
  br label %bb28
bb28:
  %t98 = load i1, ptr %l93, !tbaa !21
  br i1 %t98, label %bb29, label %bb30
bb29:
  br label %bb73
bb30:
  br label %bb31
bb31:
  %t99 = load ptr, ptr %l11, !tbaa !29
  %t101 = getelementptr %"compiler/ast:TypeDecl", ptr %t99, i32 0, i32 3
  %t102 = load ptr, ptr %t101, !tbaa !29
  %t104 = icmp eq ptr %t102, null
  br i1 %t104, label %bb32, label %bb33
bb32:
  call void @__olang_check_failed(ptr @olang_loc_b551b6343ae0ce4b_58fdc1bfeb477ccf)
  unreachable
bb33:
  br label %bb34
bb34:
  %t106 = load ptr, ptr %l11, !tbaa !29
  %t108 = getelementptr %"compiler/ast:TypeDecl", ptr %t106, i32 0, i32 3
  %t109 = load ptr, ptr %t108, !tbaa !29
  store ptr %t109, ptr %l12, !tbaa !29
  %t111 = load ptr, ptr %l12, !tbaa !29
  store ptr %t111, ptr %l102, !tbaa !29
  store i1 false, ptr %l103, !tbaa !21
  %t112 = load ptr, ptr %l102, !tbaa !29
  %t113 = icmp ne ptr %t112, null
  br i1 %t113, label %bb35, label %bb36
bb35:
  %t115 = load ptr, ptr %l102, !tbaa !29
  %t116 = load i64, ptr %t115, !range !{i64 0, i64 5}
  %t118 = icmp eq i64 %t116, 2
  store i1 %t118, ptr %l103, !tbaa !21
  br label %bb36
bb36:
  %t119 = load i1, ptr %l103, !tbaa !21
  %t120 = xor i1 %t119, true
  br i1 %t120, label %bb37, label %bb38
bb37:
  br label %bb73
bb38:
  br label %bb39
bb39:
  %t122 = load ptr, ptr %l12, !tbaa !29
  %t124 = getelementptr { i64, [6 x i64] }, ptr %t122, i32 0, i32 1
  %t125 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr } }, ptr %t124, i32 0, i32 0
  %t126 = load { i64, ptr }, ptr %t125
  store { i64, ptr } %t126, ptr %l13, !tbaa !27
  %t128 = load ptr, ptr %l12, !tbaa !29
  %t130 = getelementptr { i64, [6 x i64] }, ptr %t128, i32 0, i32 1
  %t131 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr } }, ptr %t130, i32 0, i32 1
  %t132 = load { i64, ptr }, ptr %t131
  store { i64, ptr } %t132, ptr %l14, !tbaa !27
  %t134 = load ptr, ptr %l12, !tbaa !29
  %t136 = getelementptr { i64, [6 x i64] }, ptr %t134, i32 0, i32 1
  %t137 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr } }, ptr %t136, i32 0, i32 2
  %t138 = load { i64, ptr }, ptr %t137
  store { i64, ptr } %t138, ptr %l15, !tbaa !27
  store i64 0, ptr %l16, !tbaa !24
  %t140 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t142 = extractvalue { i64, ptr } %t140, 0
  store i64 %t142, ptr %l17, !tbaa !24
  store i64 1, ptr %l18, !tbaa !24
  %t144 = load i64, ptr %l17, !tbaa !24
  %t145 = load i64, ptr %l16, !tbaa !24
  %t148 = icmp sgt i64 %t144, %t145
  br i1 %t148, label %bb40, label %bb41
bb40:
  %t150 = load i64, ptr %l18, !tbaa !24
  %t152 = icmp sgt i64 %t150, 0
  br i1 %t152, label %bb42, label %bb43
bb41:
  store i64 0, ptr %l118, !tbaa !24
  br label %bb45
bb42:
  %t154 = load i64, ptr %l17, !tbaa !24
  %t155 = load i64, ptr %l16, !tbaa !24
  %t158 = sub i64 %t154, %t155
  %t159 = load i64, ptr %l18, !tbaa !24
  %t162 = add i64 %t158, %t159
  %t164 = sub i64 %t162, 1
  %t165 = load i64, ptr %l18, !tbaa !24
  %t168 = sdiv i64 %t164, %t165
  store i64 %t168, ptr %l121, !tbaa !24
  br label %bb44
bb43:
  store i64 0, ptr %l121, !tbaa !24
  br label %bb44
bb44:
  %t170 = load i64, ptr %l121, !tbaa !24
  store i64 %t170, ptr %l118, !tbaa !24
  br label %bb45
bb45:
  %t171 = load i64, ptr %l118, !tbaa !24
  store i64 %t171, ptr %l19, !tbaa !24
  store i64 0, ptr %l20, !tbaa !24
  br label %bb46
bb46:
  store %olang.scope zeroinitializer, ptr %s7
  %t172 = load i64, ptr %l20, !tbaa !24
  %t173 = load i64, ptr %l19, !tbaa !24
  %t176 = icmp slt i64 %t172, %t173
  %t178 = xor i1 %t176, true
  br i1 %t178, label %bb47, label %bb48
bb47:
  call void @__olang_scope_close(ptr %s7)
  br label %bb72
bb48:
  br label %bb49
bb49:
  %t180 = load i64, ptr %l16, !tbaa !24
  %t181 = load i64, ptr %l20, !tbaa !24
  %t182 = load i64, ptr %l18, !tbaa !24
  %t185 = mul i64 %t181, %t182
  %t188 = add i64 %t180, %t185
  store i64 %t188, ptr %l21, !tbaa !24
  %t190 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t190, ptr %l140, !tbaa !27
  %t192 = load i64, ptr %l21, !tbaa !24
  %t194 = getelementptr { i64, ptr }, ptr %l140, i32 0, i32 1
  %t195 = load ptr, ptr %t194, !tbaa !27
  %t196 = getelementptr ptr, ptr %t195, i64 %t192
  %t197 = load ptr, ptr %t196, !tbaa !39
  store ptr %t197, ptr %l22, !tbaa !29
  %t199 = load ptr, ptr %l22, !tbaa !29
  %t201 = call i1 @compiler_2fast_2ecompiler_2fast_3aFunc_2eIsBuilder(ptr %v0, ptr %t199)
  store i1 %t201, ptr %l144
  br label %bb50
bb50:
  %t202 = load i1, ptr %l144, !tbaa !21
  br i1 %t202, label %bb51, label %bb52
bb51:
  store i1 true, ptr %l145, !tbaa !21
  br label %bb54
bb52:
  %t203 = load ptr, ptr %l22, !tbaa !29
  %t205 = getelementptr %"compiler/ast:Func", ptr %t203, i32 0, i32 2
  %t206 = load i32, ptr %t205, !tbaa !23
  %t209 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eHas_3ccompiler_2fsource_3aNameId_3e(ptr %s0, ptr %l4, i32 %t206)
  store i1 %t209, ptr %l149
  br label %bb53
bb53:
  %t210 = load i1, ptr %l149, !tbaa !21
  store i1 %t210, ptr %l145, !tbaa !21
  br label %bb54
bb54:
  %t211 = load i1, ptr %l145, !tbaa !21
  br i1 %t211, label %bb55, label %bb56
bb55:
  call void @__olang_scope_close(ptr %s7)
  br label %bb71
bb56:
  br label %bb57
bb57:
  %t212 = load ptr, ptr %l22, !tbaa !29
  %t214 = getelementptr %"compiler/ast:Func", ptr %t212, i32 0, i32 2
  %t215 = load i32, ptr %t214, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ePush_3ccompiler_2fsource_3aNameId_3e(ptr %s0, ptr %l4, i32 %t215)
  br label %bb58
bb58:
  %t218 = load ptr, ptr %l0, !tbaa !29
  store ptr %t218, ptr %l153, !tbaa !29
  %t219 = load i32, ptr %l10, !tbaa !23
  store i32 %t219, ptr %l154, !tbaa !23
  %t220 = load ptr, ptr %l22, !tbaa !29
  store ptr %t220, ptr %l155, !tbaa !29
  %t221 = load ptr, ptr %l0, !tbaa !29
  %t223 = getelementptr %"compiler/generic:Program", ptr %t221, i32 0, i32 2
  %t224 = load i32, ptr %l9, !tbaa !23
  %t227 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %t223, i32 %t224)
  store i32 %t227, ptr %l159
  br label %bb59
bb59:
  %t228 = load ptr, ptr %l153, !tbaa !29
  %t229 = load i32, ptr %l154, !tbaa !23
  %t230 = load ptr, ptr %l155, !tbaa !29
  %t231 = load i32, ptr %l159, !tbaa !23
  %t232 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTraitSig(ptr %v0, ptr %v0, ptr %t228, i32 %t229, ptr %t230, i32 %t231)
  store i32 %t232, ptr %l160
  br label %bb60
bb60:
  %t233 = load i32, ptr %l160, !tbaa !23
  store i32 %t233, ptr %l23, !tbaa !23
  %t234 = load ptr, ptr %l22, !tbaa !29
  %t236 = getelementptr %"compiler/ast:Func", ptr %t234, i32 0, i32 1
  %t237 = load ptr, ptr %t236, !tbaa !29
  %t239 = icmp eq ptr %t237, null
  %t241 = xor i1 %t239, true
  store i1 %t241, ptr %l24, !tbaa !21
  %t243 = load ptr, ptr %l0, !tbaa !29
  store ptr %t243, ptr %l165, !tbaa !29
  %t244 = load i32, ptr %l23, !tbaa !23
  store i32 %t244, ptr %l166, !tbaa !23
  %t245 = load ptr, ptr %l0, !tbaa !29
  %t247 = getelementptr %"compiler/generic:Program", ptr %t245, i32 0, i32 2
  store ptr %t247, ptr %l168, !tbaa !29
  %t248 = load ptr, ptr %l0, !tbaa !29
  %t250 = getelementptr %"compiler/generic:Program", ptr %t248, i32 0, i32 2
  %t251 = load i32, ptr %l1, !tbaa !23
  %t254 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAny(ptr %v0, ptr %t250, i32 %t251)
  store i32 %t254, ptr %l172
  br label %bb61
bb61:
  %t255 = load i1, ptr %l24, !tbaa !21
  br i1 %t255, label %bb62, label %bb63
bb62:
  %t257 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  store i64 %t257, ptr %l174, !tbaa !24
  br label %bb64
bb63:
  %t259 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  store i64 %t259, ptr %l174, !tbaa !24
  br label %bb64
bb64:
  %t261 = load ptr, ptr %l168, !tbaa !29
  %t262 = load i32, ptr %l172, !tbaa !23
  %t263 = load i64, ptr %l174, !tbaa !24
  %t264 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t261, i32 %t262, i64 %t263)
  store i32 %t264, ptr %l177
  br label %bb65
bb65:
  %t265 = load ptr, ptr %l165, !tbaa !29
  %t266 = load i32, ptr %l166, !tbaa !23
  %t267 = load i32, ptr %l177, !tbaa !23
  %t268 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eWithReceiver(ptr %v0, ptr %t265, i32 %t266, i32 %t267)
  store i32 %t268, ptr %l178
  br label %bb66
bb66:
  %t269 = load i32, ptr %l178, !tbaa !23
  %t270 = load ptr, ptr %l22, !tbaa !29
  %t272 = getelementptr %"compiler/ast:Func", ptr %t270, i32 0, i32 2
  %t273 = load i32, ptr %t272, !tbaa !23
  store i32 %t273, ptr %l180, !tbaa !23
  %t274 = load i32, ptr %l9, !tbaa !23
  store i32 %t274, ptr %l181, !tbaa !23
  %t275 = load i64, ptr %l21, !tbaa !24
  store i64 %t275, ptr %l182, !tbaa !24
  %t276 = load i1, ptr %l24, !tbaa !21
  store i1 %t276, ptr %l183, !tbaa !21
  %t277 = load ptr, ptr %l0, !tbaa !29
  %t279 = getelementptr %"compiler/generic:Program", ptr %t277, i32 0, i32 2
  store ptr %t279, ptr %l185, !tbaa !29
  store i32 %t269, ptr %l186, !tbaa !23
  %t281 = load ptr, ptr %l0, !tbaa !29
  %t283 = getelementptr %"compiler/generic:Program", ptr %t281, i32 0, i32 2
  %t284 = load i32, ptr %l23, !tbaa !23
  %t287 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReceiverPromises(ptr %v0, ptr %t283, i32 %t284)
  store i64 %t287, ptr %l190
  br label %bb67
bb67:
  %t288 = load ptr, ptr %l185, !tbaa !29
  %t289 = load i32, ptr %l186, !tbaa !23
  %t290 = load i64, ptr %l190, !tbaa !24
  %t291 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eWithPromises(ptr %v0, ptr %t288, i32 %t289, i64 %t290)
  store i32 %t291, ptr %l191
  br label %bb68
bb68:
  %t292 = load i32, ptr %l180, !tbaa !23
  %t293 = load i32, ptr %l181, !tbaa !23
  %t294 = load i64, ptr %l182, !tbaa !24
  %t295 = load i1, ptr %l183, !tbaa !21
  %t296 = load i32, ptr %l191, !tbaa !23
  %t297 = call %"compiler/generic:AnySlot" @compiler_2fgeneric_3aAnySlot_2ector(ptr %s7, i32 %t292, i32 %t293, i64 %t294, i64 -1, i1 %t295, i32 %t296)
  store %"compiler/generic:AnySlot" %t297, ptr %l192
  br label %bb69
bb69:
  %t298 = load %"compiler/generic:AnySlot", ptr %l192
  store %"compiler/generic:AnySlot" %t298, ptr %l26
  %t299 = load i32, ptr %l23, !tbaa !23
  %t301 = getelementptr %"compiler/generic:AnySlot", ptr %l26, i32 0, i32 6
  store i32 %t299, ptr %t301, !tbaa !23
  %t302 = load %"compiler/generic:AnySlot", ptr %l26
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3aAnySlot_3e_2ePush_H53ed042998733b8f648bef68c9e795c2(ptr %s0, ptr %l3, %"compiler/generic:AnySlot" %t302)
  br label %bb70
bb70:
  call void @__olang_scope_close(ptr %s7)
  br label %bb71
bb71:
  %t305 = load i64, ptr %l20, !tbaa !24
  %t308 = add i64 %t305, 1
  store i64 %t308, ptr %l20, !tbaa !24
  br label %bb46
bb72:
  br label %bb73
bb73:
  %t310 = load i64, ptr %l7, !tbaa !24
  %t313 = add i64 %t310, 1
  store i64 %t313, ptr %l7, !tbaa !24
  br label %bb20
bb74:
  store i64 0, ptr %l27, !tbaa !24
  %t315 = load ptr, ptr %l0, !tbaa !29
  %t317 = getelementptr %"compiler/generic:Program", ptr %t315, i32 0, i32 40
  %t319 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t317)
  store i64 %t319, ptr %l204
  br label %bb75
bb75:
  %t320 = load i64, ptr %l204, !tbaa !24
  store i64 %t320, ptr %l28, !tbaa !24
  store i64 1, ptr %l29, !tbaa !24
  %t321 = load i64, ptr %l28, !tbaa !24
  %t322 = load i64, ptr %l27, !tbaa !24
  %t325 = icmp sgt i64 %t321, %t322
  br i1 %t325, label %bb76, label %bb77
bb76:
  %t327 = load i64, ptr %l29, !tbaa !24
  %t329 = icmp sgt i64 %t327, 0
  br i1 %t329, label %bb78, label %bb79
bb77:
  store i64 0, ptr %l208, !tbaa !24
  br label %bb81
bb78:
  %t331 = load i64, ptr %l28, !tbaa !24
  %t332 = load i64, ptr %l27, !tbaa !24
  %t335 = sub i64 %t331, %t332
  %t336 = load i64, ptr %l29, !tbaa !24
  %t339 = add i64 %t335, %t336
  %t341 = sub i64 %t339, 1
  %t342 = load i64, ptr %l29, !tbaa !24
  %t345 = sdiv i64 %t341, %t342
  store i64 %t345, ptr %l211, !tbaa !24
  br label %bb80
bb79:
  store i64 0, ptr %l211, !tbaa !24
  br label %bb80
bb80:
  %t347 = load i64, ptr %l211, !tbaa !24
  store i64 %t347, ptr %l208, !tbaa !24
  br label %bb81
bb81:
  %t348 = load i64, ptr %l208, !tbaa !24
  store i64 %t348, ptr %l30, !tbaa !24
  store i64 0, ptr %l31, !tbaa !24
  br label %bb82
bb82:
  store %olang.scope zeroinitializer, ptr %s12
  %t349 = load i64, ptr %l31, !tbaa !24
  %t350 = load i64, ptr %l30, !tbaa !24
  %t353 = icmp slt i64 %t349, %t350
  %t355 = xor i1 %t353, true
  br i1 %t355, label %bb83, label %bb84
bb83:
  call void @__olang_scope_close(ptr %s12)
  br label %bb127
bb84:
  br label %bb85
bb85:
  %t357 = load i64, ptr %l27, !tbaa !24
  %t358 = load i64, ptr %l31, !tbaa !24
  %t359 = load i64, ptr %l29, !tbaa !24
  %t362 = mul i64 %t358, %t359
  %t365 = add i64 %t357, %t362
  store i64 %t365, ptr %l32, !tbaa !24
  %t367 = load ptr, ptr %l0, !tbaa !29
  %t369 = getelementptr %"compiler/generic:Program", ptr %t367, i32 0, i32 40
  %t370 = load i64, ptr %l32, !tbaa !24
  %t373 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t369, i64 %t370)
  store i64 %t373, ptr %l232
  br label %bb86
bb86:
  %t374 = load i64, ptr %l232, !tbaa !24
  store i64 %t374, ptr %l33, !tbaa !24
  %t375 = load ptr, ptr %l0, !tbaa !29
  %t377 = getelementptr %"compiler/generic:Program", ptr %t375, i32 0, i32 41
  %t378 = load i64, ptr %l32, !tbaa !24
  %t381 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t377, i64 %t378)
  store i64 %t381, ptr %l236
  br label %bb87
bb87:
  %t382 = load i64, ptr %l236, !tbaa !24
  %t383 = trunc i64 %t382 to i32
  store i32 %t383, ptr %l34, !tbaa !23
  %t386 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t386, ptr %l35, !tbaa !23
  %t388 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t388, ptr %l36, !tbaa !27
  store i64 0, ptr %l37, !tbaa !24
  %t390 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t392 = extractvalue { i64, ptr } %t390, 0
  store i64 %t392, ptr %l38, !tbaa !24
  br label %bb88
bb88:
  %t394 = load i64, ptr %l37, !tbaa !24
  %t395 = load i64, ptr %l38, !tbaa !24
  %t398 = icmp slt i64 %t394, %t395
  %t400 = xor i1 %t398, true
  br i1 %t400, label %bb89, label %bb90
bb89:
  br label %bb97
bb90:
  br label %bb91
bb91:
  %t402 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t402, ptr %l247, !tbaa !27
  %t403 = load i64, ptr %l37, !tbaa !24
  %t405 = getelementptr { i64, ptr }, ptr %l247, i32 0, i32 1
  %t406 = load ptr, ptr %t405, !tbaa !27
  %t407 = getelementptr i32, ptr %t406, i64 %t403
  %t408 = load i32, ptr %t407, !tbaa !33
  store i32 %t408, ptr %l39, !tbaa !23
  %t410 = load ptr, ptr %l0, !tbaa !29
  %t412 = getelementptr %"compiler/generic:Program", ptr %t410, i32 0, i32 2
  %t413 = load i32, ptr %l39, !tbaa !23
  %t416 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t412, i32 %t413)
  store i32 %t416, ptr %l253
  br label %bb92
bb92:
  %t417 = load i32, ptr %l34, !tbaa !23
  %t418 = load i32, ptr %l253, !tbaa !23
  %t420 = icmp eq i32 %t418, %t417
  br i1 %t420, label %bb93, label %bb94
bb93:
  %t422 = load i32, ptr %l39, !tbaa !23
  store i32 %t422, ptr %l35, !tbaa !23
  br label %bb95
bb94:
  br label %bb95
bb95:
  br label %bb96
bb96:
  %t424 = load i64, ptr %l37, !tbaa !24
  %t427 = add i64 %t424, 1
  store i64 %t427, ptr %l37, !tbaa !24
  br label %bb88
bb97:
  %t429 = load i32, ptr %l35, !tbaa !23
  %t430 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t433 = icmp eq i32 %t429, %t430
  br i1 %t433, label %bb98, label %bb99
bb98:
  store i1 true, ptr %l263, !tbaa !21
  br label %bb102
bb99:
  store ptr %l4, ptr %l264, !tbaa !29
  %t435 = load ptr, ptr %l0, !tbaa !29
  %t437 = getelementptr %"compiler/generic:Program", ptr %t435, i32 0, i32 31
  %t438 = load i64, ptr %l33, !tbaa !24
  %t441 = call %"compiler/generic:fnRow" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3afnRow_3e_2eAt_3ccompiler_2fgeneric_3afnRow_3e(ptr %v0, ptr %s12, ptr %t437, i64 %t438)
  store %"compiler/generic:fnRow" %t441, ptr %l268
  br label %bb100
bb100:
  %t442 = getelementptr %"compiler/generic:fnRow", ptr %l268, i32 0, i32 1
  %t443 = load ptr, ptr %t442, !tbaa !29
  %t445 = getelementptr %"compiler/ast:Func", ptr %t443, i32 0, i32 2
  %t446 = load i32, ptr %t445, !tbaa !23
  %t447 = load ptr, ptr %l264, !tbaa !29
  %t449 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eHas_3ccompiler_2fsource_3aNameId_3e(ptr %s0, ptr %t447, i32 %t446)
  store i1 %t449, ptr %l271
  br label %bb101
bb101:
  %t450 = load i1, ptr %l271, !tbaa !21
  store i1 %t450, ptr %l263, !tbaa !21
  br label %bb102
bb102:
  %t451 = load i1, ptr %l263, !tbaa !21
  br i1 %t451, label %bb103, label %bb104
bb103:
  call void @__olang_scope_close(ptr %s12)
  br label %bb126
bb104:
  br label %bb105
bb105:
  %t452 = load ptr, ptr %l0, !tbaa !29
  store ptr %t452, ptr %l272, !tbaa !29
  %t453 = load i64, ptr %l33, !tbaa !24
  store i64 %t453, ptr %l273, !tbaa !24
  %t454 = load ptr, ptr %l0, !tbaa !29
  %t456 = getelementptr %"compiler/generic:Program", ptr %t454, i32 0, i32 2
  %t457 = load i32, ptr %l1, !tbaa !23
  %t460 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAny(ptr %v0, ptr %t456, i32 %t457)
  store i32 %t460, ptr %l277
  br label %bb106
bb106:
  %t461 = load ptr, ptr %l272, !tbaa !29
  %t462 = load i64, ptr %l273, !tbaa !24
  %t463 = load i32, ptr %l277, !tbaa !23
  %t464 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDefaultAt(ptr %v0, ptr %t461, i64 %t462, i32 %t463)
  store i32 %t464, ptr %l278
  br label %bb107
bb107:
  %t465 = load i32, ptr %l278, !tbaa !23
  store i32 %t465, ptr %l40, !tbaa !23
  %t466 = load i32, ptr %l40, !tbaa !23
  %t467 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t470 = icmp eq i32 %t466, %t467
  br i1 %t470, label %bb108, label %bb109
bb108:
  call void @__olang_scope_close(ptr %s12)
  br label %bb126
bb109:
  br label %bb110
bb110:
  store ptr %l4, ptr %l282, !tbaa !29
  %t472 = load ptr, ptr %l0, !tbaa !29
  %t474 = getelementptr %"compiler/generic:Program", ptr %t472, i32 0, i32 31
  %t475 = load i64, ptr %l33, !tbaa !24
  %t478 = call %"compiler/generic:fnRow" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3afnRow_3e_2eAt_3ccompiler_2fgeneric_3afnRow_3e(ptr %v0, ptr %s12, ptr %t474, i64 %t475)
  store %"compiler/generic:fnRow" %t478, ptr %l286
  br label %bb111
bb111:
  %t479 = getelementptr %"compiler/generic:fnRow", ptr %l286, i32 0, i32 1
  %t480 = load ptr, ptr %t479, !tbaa !29
  %t482 = getelementptr %"compiler/ast:Func", ptr %t480, i32 0, i32 2
  %t483 = load i32, ptr %t482, !tbaa !23
  %t484 = load ptr, ptr %l282, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ePush_3ccompiler_2fsource_3aNameId_3e(ptr %s0, ptr %t484, i32 %t483)
  br label %bb112
bb112:
  %t486 = load ptr, ptr %l0, !tbaa !29
  %t488 = getelementptr %"compiler/generic:Program", ptr %t486, i32 0, i32 2
  store ptr %t488, ptr %l290, !tbaa !29
  %t489 = load ptr, ptr %l0, !tbaa !29
  %t491 = getelementptr %"compiler/generic:Program", ptr %t489, i32 0, i32 2
  %t492 = load i32, ptr %l40, !tbaa !23
  %t495 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t491, i32 %t492)
  store i32 %t495, ptr %l294
  br label %bb113
bb113:
  %t496 = load ptr, ptr %l290, !tbaa !29
  %t497 = load i32, ptr %l294, !tbaa !23
  %t498 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t496, i32 %t497)
  store { i64, ptr } %t498, ptr %l295
  br label %bb114
bb114:
  %t499 = load { i64, ptr }, ptr %l295, !tbaa !27
  store { i64, ptr } %t499, ptr %l41, !tbaa !27
  %t500 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t502 = extractvalue { i64, ptr } %t500, 0
  %t504 = icmp sgt i64 %t502, 0
  br i1 %t504, label %bb115, label %bb116
bb115:
  %t506 = load ptr, ptr %l0, !tbaa !29
  %t508 = getelementptr %"compiler/generic:Program", ptr %t506, i32 0, i32 2
  %t509 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t509, ptr %l302, !tbaa !27
  %t510 = getelementptr { i64, ptr }, ptr %l302, i32 0, i32 1
  %t511 = load ptr, ptr %t510, !tbaa !27
  %t512 = getelementptr i32, ptr %t511, i64 0
  %t513 = load i32, ptr %t512, !tbaa !33
  %t516 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t508, i32 %t513)
  store i32 %t516, ptr %l304
  br label %bb117
bb116:
  store i1 false, ptr %l299, !tbaa !21
  br label %bb118
bb117:
  %t517 = load i32, ptr %l304, !range !{i32 0, i32 33}
  %t519 = trunc i64 20 to i32
  %t520 = icmp eq i32 %t517, %t519
  store i1 %t520, ptr %l299, !tbaa !21
  br label %bb118
bb118:
  %t522 = load i1, ptr %l299, !tbaa !21
  br i1 %t522, label %bb119, label %bb120
bb119:
  %t523 = load ptr, ptr %l0, !tbaa !29
  %t525 = getelementptr %"compiler/generic:Program", ptr %t523, i32 0, i32 2
  %t526 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t526, ptr %l310, !tbaa !27
  %t527 = getelementptr { i64, ptr }, ptr %l310, i32 0, i32 1
  %t528 = load ptr, ptr %t527, !tbaa !27
  %t529 = getelementptr i32, ptr %t528, i64 0
  %t530 = load i32, ptr %t529, !tbaa !33
  %t533 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t525, i32 %t530)
  store i64 %t533, ptr %l312
  br label %bb121
bb120:
  store i1 false, ptr %l307, !tbaa !21
  br label %bb122
bb121:
  %t534 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t535 = load i64, ptr %l312, !tbaa !24
  %t537 = and i64 %t535, %t534
  %t539 = icmp ne i64 %t537, 0
  store i1 %t539, ptr %l307, !tbaa !21
  br label %bb122
bb122:
  %t541 = load i1, ptr %l307, !tbaa !21
  store i1 %t541, ptr %l42, !tbaa !21
  store ptr %l3, ptr %l316, !tbaa !29
  %t542 = load ptr, ptr %l0, !tbaa !29
  %t544 = getelementptr %"compiler/generic:Program", ptr %t542, i32 0, i32 31
  %t545 = load i64, ptr %l33, !tbaa !24
  %t548 = call %"compiler/generic:fnRow" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3afnRow_3e_2eAt_3ccompiler_2fgeneric_3afnRow_3e(ptr %v0, ptr %s12, ptr %t544, i64 %t545)
  store %"compiler/generic:fnRow" %t548, ptr %l320
  br label %bb123
bb123:
  %t549 = getelementptr %"compiler/generic:fnRow", ptr %l320, i32 0, i32 1
  %t550 = load ptr, ptr %t549, !tbaa !29
  %t552 = getelementptr %"compiler/ast:Func", ptr %t550, i32 0, i32 2
  %t553 = load i32, ptr %t552, !tbaa !23
  %t554 = load i32, ptr %l35, !tbaa !23
  %t555 = load i64, ptr %l33, !tbaa !24
  %t556 = load i1, ptr %l42, !tbaa !21
  %t557 = load i32, ptr %l40, !tbaa !23
  %t563 = call %"compiler/generic:AnySlot" @compiler_2fgeneric_3aAnySlot_2ector(ptr %s12, i32 %t553, i32 %t554, i64 -1, i64 %t555, i1 %t556, i32 %t557)
  store %"compiler/generic:AnySlot" %t563, ptr %l327
  br label %bb124
bb124:
  %t564 = load ptr, ptr %l316, !tbaa !29
  %t565 = load %"compiler/generic:AnySlot", ptr %l327
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3aAnySlot_3e_2ePush_H53ed042998733b8f648bef68c9e795c2(ptr %s0, ptr %t564, %"compiler/generic:AnySlot" %t565)
  br label %bb125
bb125:
  call void @__olang_scope_close(ptr %s12)
  br label %bb126
bb126:
  %t566 = load i64, ptr %l31, !tbaa !24
  %t569 = add i64 %t566, 1
  store i64 %t569, ptr %l31, !tbaa !24
  br label %bb82
bb127:
  %t572 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3aAnySlot_3e_2eLen__H711cec3afad496782566ddd729023773(ptr %s0, ptr %l3)
  store i64 %t572, ptr %l332
  br label %bb128
bb128:
  %t573 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t574 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t577 = call %"compiler/generic:AnySlot" @compiler_2fgeneric_3aAnySlot_2ector(ptr %v1, i32 0, i32 %t573, i64 -1, i64 -1, i1 false, i32 %t574)
  store %"compiler/generic:AnySlot" %t577, ptr %l335
  br label %bb129
bb129:
  %t578 = load i64, ptr %l332, !tbaa !24
  %t579 = icmp sge i64 %t578, 0
  br i1 %t579, label %bb130, label %bb131
bb130:
  %t581 = load i64, ptr %l332, !tbaa !24
  %t582 = icmp sle i64 %t581, 230584300921369395
  br i1 %t582, label %bb132, label %bb133
bb131:
  call void @__olang_check_failed(ptr @olang_loc_98166f45573479aa_46aa63c900b34a36)
  unreachable
bb132:
  %t584 = load i64, ptr %l332, !tbaa !24
  %t585 = mul i64 %t584, 40
  %t586 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t585)
  %t587 = load %"compiler/generic:AnySlot", ptr %l335
  store i64 0, ptr %t588
  br label %fill.589
fill.589:
  %t592 = load i64, ptr %t588
  %t593 = icmp slt i64 %t592, %t584
  br i1 %t593, label %fillb.590, label %filld.591
fillb.590:
  %t594 = getelementptr %"compiler/generic:AnySlot", ptr %t586, i64 %t592
  store %"compiler/generic:AnySlot" %t587, ptr %t594
  %t595 = add i64 %t592, 1
  store i64 %t595, ptr %t588
  br label %fill.589
filld.591:
  %t596 = insertvalue { i64, ptr } undef, i64 %t584, 0
  %t597 = insertvalue { i64, ptr } %t596, ptr %t586, 1
  store { i64, ptr } %t597, ptr %l43, !tbaa !27
  store i64 0, ptr %l44, !tbaa !24
  %t600 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3aAnySlot_3e_2eLen__H711cec3afad496782566ddd729023773(ptr %s0, ptr %l3)
  store i64 %t600, ptr %l340
  br label %bb134
bb133:
  call void @__olang_check_failed(ptr @olang_loc_98166f45573479aa_46aa63c900b34a36)
  unreachable
bb134:
  %t601 = load i64, ptr %l340, !tbaa !24
  store i64 %t601, ptr %l45, !tbaa !24
  store i64 1, ptr %l46, !tbaa !24
  %t602 = load i64, ptr %l45, !tbaa !24
  %t603 = load i64, ptr %l44, !tbaa !24
  %t606 = icmp sgt i64 %t602, %t603
  br i1 %t606, label %bb135, label %bb136
bb135:
  %t608 = load i64, ptr %l46, !tbaa !24
  %t610 = icmp sgt i64 %t608, 0
  br i1 %t610, label %bb137, label %bb138
bb136:
  store i64 0, ptr %l344, !tbaa !24
  br label %bb140
bb137:
  %t612 = load i64, ptr %l45, !tbaa !24
  %t613 = load i64, ptr %l44, !tbaa !24
  %t616 = sub i64 %t612, %t613
  %t617 = load i64, ptr %l46, !tbaa !24
  %t620 = add i64 %t616, %t617
  %t622 = sub i64 %t620, 1
  %t623 = load i64, ptr %l46, !tbaa !24
  %t626 = sdiv i64 %t622, %t623
  store i64 %t626, ptr %l347, !tbaa !24
  br label %bb139
bb138:
  store i64 0, ptr %l347, !tbaa !24
  br label %bb139
bb139:
  %t628 = load i64, ptr %l347, !tbaa !24
  store i64 %t628, ptr %l344, !tbaa !24
  br label %bb140
bb140:
  %t629 = load i64, ptr %l344, !tbaa !24
  store i64 %t629, ptr %l47, !tbaa !24
  store i64 0, ptr %l48, !tbaa !24
  br label %bb141
bb141:
  %t630 = load i64, ptr %l48, !tbaa !24
  %t631 = load i64, ptr %l47, !tbaa !24
  %t634 = icmp slt i64 %t630, %t631
  %t636 = xor i1 %t634, true
  br i1 %t636, label %bb142, label %bb143
bb142:
  br label %bb147
bb143:
  br label %bb144
bb144:
  %t638 = load i64, ptr %l44, !tbaa !24
  %t639 = load i64, ptr %l48, !tbaa !24
  %t640 = load i64, ptr %l46, !tbaa !24
  %t643 = mul i64 %t639, %t640
  %t646 = add i64 %t638, %t643
  store i64 %t646, ptr %l49, !tbaa !24
  %t648 = load { i64, ptr }, ptr %l43, !tbaa !27
  store { i64, ptr } %t648, ptr %l365, !tbaa !27
  %t649 = load i64, ptr %l49, !tbaa !24
  store i64 %t649, ptr %l366, !tbaa !24
  %t650 = load i64, ptr %l49, !tbaa !24
  %t653 = call %"compiler/generic:AnySlot" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3aAnySlot_3e_2eAt_3ccompiler_2fgeneric_3aAnySlot_3e(ptr %s0, ptr %l3, i64 %t650)
  store %"compiler/generic:AnySlot" %t653, ptr %l369
  br label %bb145
bb145:
  %t654 = load %"compiler/generic:AnySlot", ptr %l369
  %t655 = load i64, ptr %l366, !tbaa !24
  %t656 = getelementptr { i64, ptr }, ptr %l365, i32 0, i32 1
  %t657 = load ptr, ptr %t656, !tbaa !27
  %t658 = getelementptr %"compiler/generic:AnySlot", ptr %t657, i64 %t655
  store %"compiler/generic:AnySlot" %t654, ptr %t658
  br label %bb146
bb146:
  %t659 = load i64, ptr %l48, !tbaa !24
  %t662 = add i64 %t659, 1
  store i64 %t662, ptr %l48, !tbaa !24
  br label %bb141
bb147:
  %t664 = load ptr, ptr %l0, !tbaa !29
  %t666 = getelementptr %"compiler/generic:Program", ptr %t664, i32 0, i32 72
  %t667 = load i32, ptr %l1, !tbaa !23
  %t668 = load { i64, ptr }, ptr %l43, !tbaa !27
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Array_3_H5c1f2db077436d08712784f933dc3852(ptr %v0, ptr %v1, ptr %t666, i32 %t667, { i64, ptr } %t668)
  br label %bb148
bb148:
  %t672 = load { i64, ptr }, ptr %l43, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t672, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDefaultAt(ptr %v0, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca i64
  %l10 = alloca %"compiler/generic:Binding"
  %l11 = alloca i32
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l24 = alloca i32
  %l26 = alloca i64
  %l29 = alloca i64
  %l31 = alloca ptr
  %l35 = alloca i32
  %l36 = alloca { i64, ptr }
  %l41 = alloca { i64, ptr }
  %l47 = alloca i32
  %l53 = alloca i32
  %l57 = alloca i32
  %l61 = alloca i1
  %l65 = alloca i64
  %l72 = alloca i64
  %l75 = alloca %"compiler/generic:Binding"
  %l80 = alloca i32
  %l84 = alloca i1
  %l88 = alloca i32
  %l95 = alloca i32
  %l96 = alloca { i64, ptr }
  %l104 = alloca i64
  %l107 = alloca i1
  %l112 = alloca { i64, ptr }
  %l128 = alloca i64
  %l131 = alloca i64
  %l150 = alloca { i64, ptr }
  %l156 = alloca i1
  %l161 = alloca ptr
  %l165 = alloca i32
  %l168 = alloca i1
  %l170 = alloca ptr
  %l171 = alloca i32
  %l172 = alloca i64
  %l176 = alloca i32
  %l177 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  %t5 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t1, i64 %t2)
  store i32 %t5, ptr %l24
  br label %bb1
bb1:
  %t6 = load i32, ptr %l24, !tbaa !23
  store i32 %t6, ptr %l3, !tbaa !23
  %t7 = load i64, ptr %l1, !tbaa !24
  %t9 = call i64 @compiler_2fgeneric_2eFnOwner(i64 %t7)
  store i64 %t9, ptr %l26
  br label %bb2
bb2:
  %t10 = load i64, ptr %l26, !tbaa !24
  store i64 %t10, ptr %l4, !tbaa !24
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load i64, ptr %l4, !tbaa !24
  %t15 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v0, ptr %t11, i64 %t12)
  store i64 %t15, ptr %l29
  br label %bb3
bb3:
  %t16 = load i64, ptr %l29, !tbaa !24
  store i64 %t16, ptr %l5, !tbaa !24
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/generic:Program", ptr %t17, i32 0, i32 2
  store ptr %t19, ptr %l31, !tbaa !29
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/generic:Program", ptr %t20, i32 0, i32 2
  %t23 = load i32, ptr %l3, !tbaa !23
  %t26 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t22, i32 %t23)
  store i32 %t26, ptr %l35
  br label %bb4
bb4:
  %t27 = load ptr, ptr %l31, !tbaa !29
  %t28 = load i32, ptr %l35, !tbaa !23
  %t29 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t27, i32 %t28)
  store { i64, ptr } %t29, ptr %l36
  br label %bb5
bb5:
  %t30 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t30, ptr %l6, !tbaa !27
  %t31 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t33 = extractvalue { i64, ptr } %t31, 0
  %t35 = icmp eq i64 %t33, 0
  br i1 %t35, label %bb6, label %bb7
bb6:
  %t37 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t37, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t39 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t39, ptr %l41, !tbaa !27
  %t40 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !27
  %t42 = getelementptr i32, ptr %t41, i64 0
  %t43 = load i32, ptr %t42, !tbaa !33
  store i32 %t43, ptr %l7, !tbaa !23
  %t45 = load i32, ptr %l7, !tbaa !23
  store i32 %t45, ptr %l8, !tbaa !23
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/generic:Program", ptr %t47, i32 0, i32 2
  %t50 = load i32, ptr %l8, !tbaa !23
  %t53 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t49, i32 %t50)
  store i32 %t53, ptr %l47
  br label %bb9
bb9:
  %t54 = load i32, ptr %l47, !range !{i32 0, i32 33}
  %t56 = trunc i64 20 to i32
  %t57 = icmp eq i32 %t54, %t56
  br i1 %t57, label %bb10, label %bb11
bb10:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/generic:Program", ptr %t59, i32 0, i32 2
  %t62 = load i32, ptr %l8, !tbaa !23
  %t65 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t61, i32 %t62)
  store i32 %t65, ptr %l53
  br label %bb12
bb11:
  br label %bb13
bb12:
  %t66 = load i32, ptr %l53, !tbaa !23
  store i32 %t66, ptr %l8, !tbaa !23
  br label %bb13
bb13:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/generic:Program", ptr %t67, i32 0, i32 2
  %t70 = load i32, ptr %l8, !tbaa !23
  %t73 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t69, i32 %t70)
  store i32 %t73, ptr %l57
  br label %bb14
bb14:
  %t74 = load i32, ptr %l57, !range !{i32 0, i32 33}
  %t76 = trunc i64 25 to i32
  %t77 = icmp eq i32 %t74, %t76
  %t79 = xor i1 %t77, true
  br i1 %t79, label %bb15, label %bb16
bb15:
  store i1 true, ptr %l61, !tbaa !21
  br label %bb18
bb16:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"compiler/generic:Program", ptr %t81, i32 0, i32 2
  %t84 = load i32, ptr %l8, !tbaa !23
  %t87 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eA(ptr %v0, ptr %t83, i32 %t84)
  store i64 %t87, ptr %l65
  br label %bb17
bb17:
  %t88 = load i64, ptr %l4, !tbaa !24
  %t89 = load i64, ptr %l65, !tbaa !24
  %t91 = icmp ne i64 %t89, %t88
  store i1 %t91, ptr %l61, !tbaa !21
  br label %bb18
bb18:
  %t93 = load i1, ptr %l61, !tbaa !21
  br i1 %t93, label %bb19, label %bb20
bb19:
  %t94 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t94, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"compiler/generic:Program", ptr %t96, i32 0, i32 2
  %t99 = load i32, ptr %l8, !tbaa !23
  %t102 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eB(ptr %v0, ptr %t98, i32 %t99)
  store i64 %t102, ptr %l72
  br label %bb22
bb22:
  %t103 = load i64, ptr %l72, !tbaa !24
  store i64 %t103, ptr %l9, !tbaa !24
  %t104 = load i64, ptr %l4, !tbaa !24
  %t105 = load i64, ptr %l5, !tbaa !24
  %t108 = call %"compiler/generic:Binding" @compiler_2fgeneric_3aBinding_2ector(ptr %s0, i64 %t104, i64 %t105)
  store %"compiler/generic:Binding" %t108, ptr %l75
  br label %bb23
bb23:
  %t109 = load %"compiler/generic:Binding", ptr %l75
  store %"compiler/generic:Binding" %t109, ptr %l10
  %t110 = load i32, ptr %l2, !tbaa !23
  store i32 %t110, ptr %l11, !tbaa !23
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t114 = getelementptr %"compiler/generic:Program", ptr %t112, i32 0, i32 2
  %t115 = load i32, ptr %l7, !tbaa !23
  %t118 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t114, i32 %t115)
  store i32 %t118, ptr %l80
  br label %bb24
bb24:
  %t119 = load i32, ptr %l80, !range !{i32 0, i32 33}
  %t121 = trunc i64 20 to i32
  %t122 = icmp eq i32 %t119, %t121
  %t124 = xor i1 %t122, true
  br i1 %t124, label %bb25, label %bb26
bb25:
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t128 = getelementptr %"compiler/generic:Program", ptr %t126, i32 0, i32 2
  %t129 = load i32, ptr %l2, !tbaa !23
  %t132 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t128, i32 %t129)
  store i32 %t132, ptr %l88
  br label %bb27
bb26:
  store i1 false, ptr %l84, !tbaa !21
  br label %bb28
bb27:
  %t133 = load i32, ptr %l88, !range !{i32 0, i32 33}
  %t135 = trunc i64 29 to i32
  %t136 = icmp eq i32 %t133, %t135
  store i1 %t136, ptr %l84, !tbaa !21
  br label %bb28
bb28:
  %t138 = load i1, ptr %l84, !tbaa !21
  br i1 %t138, label %bb29, label %bb30
bb29:
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t141 = getelementptr %"compiler/generic:Program", ptr %t139, i32 0, i32 2
  %t142 = load i32, ptr %l2, !tbaa !23
  %t143 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t147 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t141, i32 %t142, i64 %t143)
  store i32 %t147, ptr %l95
  br label %bb31
bb30:
  br label %bb32
bb31:
  %t148 = load i32, ptr %l95, !tbaa !23
  store i32 %t148, ptr %l11, !tbaa !23
  br label %bb32
bb32:
  %t149 = getelementptr %"compiler/generic:Binding", ptr %l10, i32 0, i32 2
  %t150 = load { i64, ptr }, ptr %t149, !tbaa !27
  store { i64, ptr } %t150, ptr %l96, !tbaa !27
  %t151 = load i64, ptr %l9, !tbaa !24
  %t152 = load i32, ptr %l11, !tbaa !23
  %t155 = getelementptr { i64, ptr }, ptr %l96, i32 0, i32 1
  %t156 = load ptr, ptr %t155, !tbaa !27
  %t157 = getelementptr i32, ptr %t156, i64 %t151
  store i32 %t152, ptr %t157, !tbaa !33
  %t158 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInferThroughBounds(ptr %v0, ptr %s0, ptr %t158, ptr %l10)
  br label %bb33
bb33:
  %t161 = getelementptr %"compiler/generic:Binding", ptr %l10, i32 0, i32 2
  %t162 = load { i64, ptr }, ptr %t161, !tbaa !27
  store { i64, ptr } %t162, ptr %l12, !tbaa !27
  store i64 0, ptr %l13, !tbaa !24
  %t164 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t166 = extractvalue { i64, ptr } %t164, 0
  store i64 %t166, ptr %l14, !tbaa !24
  %t168 = load i64, ptr %l14, !tbaa !24
  %t169 = sub i64 %t168, 1
  store i64 %t169, ptr %l104, !tbaa !24
  %t170 = load i64, ptr %l14, !tbaa !24
  %t171 = icmp slt i64 %t170, 2147483648
  %t172 = load i64, ptr %l13, !tbaa !24
  %t173 = icmp sge i64 %t172, 0
  %t176 = and i1 %t171, %t173
  store i1 %t176, ptr %l107, !tbaa !21
  br label %bb34
bb34:
  %t177 = load i64, ptr %l13, !tbaa !24
  %t178 = load i64, ptr %l14, !tbaa !24
  %t181 = icmp slt i64 %t177, %t178
  %t183 = xor i1 %t181, true
  br i1 %t183, label %bb35, label %bb36
bb35:
  br label %bb42
bb36:
  br label %bb37
bb37:
  %t185 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t185, ptr %l112, !tbaa !27
  %t186 = load i64, ptr %l13, !tbaa !24
  %t188 = getelementptr { i64, ptr }, ptr %l112, i32 0, i32 1
  %t189 = load ptr, ptr %t188, !tbaa !27
  %t190 = getelementptr i32, ptr %t189, i64 %t186
  %t191 = load i32, ptr %t190, !tbaa !33
  %t194 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t197 = icmp eq i32 %t191, %t194
  br i1 %t197, label %bb38, label %bb39
bb38:
  %t199 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t199, ptr %rv
  br label %ret
bb39:
  br label %bb40
bb40:
  br label %bb41
bb41:
  %t201 = load i64, ptr %l13, !tbaa !24
  %t204 = add i64 %t201, 1
  store i64 %t204, ptr %l13, !tbaa !24
  br label %bb34
bb42:
  store i64 0, ptr %l16, !tbaa !24
  %t206 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t208 = extractvalue { i64, ptr } %t206, 0
  %t210 = sub i64 %t208, 1
  store i64 %t210, ptr %l17, !tbaa !24
  store i64 1, ptr %l18, !tbaa !24
  %t212 = load i64, ptr %l17, !tbaa !24
  %t213 = load i64, ptr %l16, !tbaa !24
  %t216 = icmp sgt i64 %t212, %t213
  br i1 %t216, label %bb43, label %bb44
bb43:
  %t218 = load i64, ptr %l18, !tbaa !24
  %t220 = icmp sgt i64 %t218, 0
  br i1 %t220, label %bb45, label %bb46
bb44:
  store i64 0, ptr %l128, !tbaa !24
  br label %bb48
bb45:
  %t222 = load i64, ptr %l17, !tbaa !24
  %t223 = load i64, ptr %l16, !tbaa !24
  %t226 = sub i64 %t222, %t223
  %t227 = load i64, ptr %l18, !tbaa !24
  %t230 = add i64 %t226, %t227
  %t232 = sub i64 %t230, 1
  %t233 = load i64, ptr %l18, !tbaa !24
  %t236 = sdiv i64 %t232, %t233
  store i64 %t236, ptr %l131, !tbaa !24
  br label %bb47
bb46:
  store i64 0, ptr %l131, !tbaa !24
  br label %bb47
bb47:
  %t238 = load i64, ptr %l131, !tbaa !24
  store i64 %t238, ptr %l128, !tbaa !24
  br label %bb48
bb48:
  %t239 = load i64, ptr %l128, !tbaa !24
  store i64 %t239, ptr %l19, !tbaa !24
  store i64 0, ptr %l20, !tbaa !24
  br label %bb49
bb49:
  %t240 = load i64, ptr %l20, !tbaa !24
  %t241 = load i64, ptr %l19, !tbaa !24
  %t244 = icmp slt i64 %t240, %t241
  %t246 = xor i1 %t244, true
  br i1 %t246, label %bb50, label %bb51
bb50:
  br label %bb58
bb51:
  br label %bb52
bb52:
  %t248 = load i64, ptr %l16, !tbaa !24
  %t249 = load i64, ptr %l20, !tbaa !24
  %t250 = load i64, ptr %l18, !tbaa !24
  %t253 = mul i64 %t249, %t250
  %t256 = add i64 %t248, %t253
  %t258 = load ptr, ptr %l0, !tbaa !29
  %t259 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t259, ptr %l150, !tbaa !27
  %t262 = add i64 %t256, 1
  %t264 = getelementptr { i64, ptr }, ptr %l150, i32 0, i32 1
  %t265 = load ptr, ptr %t264, !tbaa !27
  %t266 = getelementptr i32, ptr %t265, i64 %t262
  %t267 = load i32, ptr %t266, !tbaa !33
  %t268 = load i64, ptr %l4, !tbaa !24
  %t269 = load i64, ptr %l9, !tbaa !24
  %t274 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ementionsVar(ptr %v0, ptr %t258, i32 %t267, i64 %t268, i64 %t269, i64 0)
  store i1 %t274, ptr %l156
  br label %bb53
bb53:
  %t275 = load i1, ptr %l156, !tbaa !21
  br i1 %t275, label %bb54, label %bb55
bb54:
  %t276 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t276, ptr %rv
  br label %ret
bb55:
  br label %bb56
bb56:
  br label %bb57
bb57:
  %t278 = load i64, ptr %l20, !tbaa !24
  %t281 = add i64 %t278, 1
  store i64 %t281, ptr %l20, !tbaa !24
  br label %bb49
bb58:
  %t283 = load ptr, ptr %l0, !tbaa !29
  store ptr %t283, ptr %l161, !tbaa !29
  %t284 = load ptr, ptr %l0, !tbaa !29
  %t286 = getelementptr %"compiler/generic:Program", ptr %t284, i32 0, i32 2
  %t287 = load i32, ptr %l3, !tbaa !23
  %t290 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t286, i32 %t287)
  store i32 %t290, ptr %l165
  br label %bb59
bb59:
  %t291 = load i64, ptr %l4, !tbaa !24
  %t292 = load i64, ptr %l9, !tbaa !24
  %t293 = load ptr, ptr %l161, !tbaa !29
  %t294 = load i32, ptr %l165, !tbaa !23
  %t297 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ementionsVar(ptr %v0, ptr %t293, i32 %t294, i64 %t291, i64 %t292, i64 0)
  store i1 %t297, ptr %l168
  br label %bb60
bb60:
  %t298 = load i1, ptr %l168, !tbaa !21
  br i1 %t298, label %bb61, label %bb62
bb61:
  %t299 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t299, ptr %rv
  br label %ret
bb62:
  br label %bb63
bb63:
  %t301 = load ptr, ptr %l0, !tbaa !29
  store ptr %t301, ptr %l170, !tbaa !29
  %t302 = load i32, ptr %l3, !tbaa !23
  store i32 %t302, ptr %l171, !tbaa !23
  %t303 = load i64, ptr %l4, !tbaa !24
  store i64 %t303, ptr %l172, !tbaa !24
  %t304 = load ptr, ptr %l0, !tbaa !29
  %t306 = getelementptr %"compiler/generic:Program", ptr %t304, i32 0, i32 2
  %t307 = getelementptr %"compiler/generic:Binding", ptr %l10, i32 0, i32 2
  %t308 = load { i64, ptr }, ptr %t307, !tbaa !27
  %t311 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s0, ptr %t306, { i64, ptr } %t308)
  store i32 %t311, ptr %l176
  br label %bb64
bb64:
  %t312 = load ptr, ptr %l170, !tbaa !29
  %t313 = load i32, ptr %l171, !tbaa !23
  %t314 = load i64, ptr %l172, !tbaa !24
  %t315 = load i32, ptr %l176, !tbaa !23
  %t316 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSubst(ptr %v0, ptr %t312, i32 %t313, i64 %t314, i32 %t315)
  store i32 %t316, ptr %l177
  br label %bb65
bb65:
  call void @__olang_scope_close(ptr %s0)
  %t317 = load i32, ptr %l177, !tbaa !23
  store i32 %t317, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorTypeHint(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca %"compiler/names:Entry"
  %l17 = alloca { i64, ptr }
  %l19 = alloca %"compiler/msgs:Nearest"
  %l24 = alloca i64
  %l28 = alloca i64
  %l31 = alloca i64
  %l52 = alloca i1
  %l57 = alloca ptr
  %l65 = alloca ptr
  %l68 = alloca i64
  %l72 = alloca i64
  %l75 = alloca i64
  %l97 = alloca ptr
  %l101 = alloca %"compiler/names:Entry"
  %l107 = alloca { i64, ptr }
  %l111 = alloca i1
  %l113 = alloca i1
  %l116 = alloca ptr
  %l120 = alloca i32
  %l121 = alloca i32
  %l133 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = call %"compiler/msgs:Nearest" @compiler_2fmsgs_3aNearest_2ector(ptr %v1, ptr %s0, { i64, ptr } %a2)
  store %"compiler/msgs:Nearest" %t3, ptr %l19
  br label %bb1
bb1:
  %t4 = load %"compiler/msgs:Nearest", ptr %l19
  %t5 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 40, i64 8)
  store %"compiler/msgs:Nearest" %t4, ptr %t5
  store ptr %t5, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/generic:Program", ptr %t7, i32 0, i32 0
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/load:Loader", ptr %t10, i32 0, i32 10
  %t14 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %t12)
  store i64 %t14, ptr %l24
  br label %bb2
bb2:
  %t15 = load i64, ptr %l24, !tbaa !24
  store i64 %t15, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t16 = load i64, ptr %l5, !tbaa !24
  %t17 = load i64, ptr %l4, !tbaa !24
  %t20 = icmp sgt i64 %t16, %t17
  br i1 %t20, label %bb3, label %bb4
bb3:
  %t22 = load i64, ptr %l6, !tbaa !24
  %t24 = icmp sgt i64 %t22, 0
  br i1 %t24, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l28, !tbaa !24
  br label %bb8
bb5:
  %t26 = load i64, ptr %l5, !tbaa !24
  %t27 = load i64, ptr %l4, !tbaa !24
  %t30 = sub i64 %t26, %t27
  %t31 = load i64, ptr %l6, !tbaa !24
  %t34 = add i64 %t30, %t31
  %t36 = sub i64 %t34, 1
  %t37 = load i64, ptr %l6, !tbaa !24
  %t40 = sdiv i64 %t36, %t37
  store i64 %t40, ptr %l31, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l31, !tbaa !24
  br label %bb7
bb7:
  %t42 = load i64, ptr %l31, !tbaa !24
  store i64 %t42, ptr %l28, !tbaa !24
  br label %bb8
bb8:
  %t43 = load i64, ptr %l28, !tbaa !24
  store i64 %t43, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb9
bb9:
  %t44 = load i64, ptr %l8, !tbaa !24
  %t45 = load i64, ptr %l7, !tbaa !24
  %t48 = icmp slt i64 %t44, %t45
  %t50 = xor i1 %t48, true
  br i1 %t50, label %bb10, label %bb11
bb10:
  br label %bb54
bb11:
  br label %bb12
bb12:
  %t52 = load i64, ptr %l4, !tbaa !24
  %t53 = load i64, ptr %l8, !tbaa !24
  %t54 = load i64, ptr %l6, !tbaa !24
  %t57 = mul i64 %t53, %t54
  %t60 = add i64 %t52, %t57
  store i64 %t60, ptr %l9, !tbaa !24
  %t62 = load i64, ptr %l9, !tbaa !24
  %t63 = load i64, ptr %l1, !tbaa !24
  %t66 = icmp ne i64 %t62, %t63
  br i1 %t66, label %bb13, label %bb14
bb13:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/generic:Program", ptr %t68, i32 0, i32 0
  %t71 = load ptr, ptr %t70, !tbaa !29
  %t73 = getelementptr %"compiler/load:Loader", ptr %t71, i32 0, i32 10
  %t74 = load i64, ptr %l9, !tbaa !24
  %t77 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t73, i64 %t74)
  store ptr %t77, ptr %l57
  br label %bb15
bb14:
  store i1 false, ptr %l52, !tbaa !21
  br label %bb16
bb15:
  %t78 = load ptr, ptr %l57, !tbaa !29
  %t80 = getelementptr %"compiler/load:Module", ptr %t78, i32 0, i32 3
  %t81 = load i1, ptr %t80, !tbaa !21
  %t83 = xor i1 %t81, true
  store i1 %t83, ptr %l52, !tbaa !21
  br label %bb16
bb16:
  %t85 = load i1, ptr %l52, !tbaa !21
  br i1 %t85, label %bb17, label %bb18
bb17:
  br label %bb53
bb18:
  br label %bb19
bb19:
  store i64 0, ptr %l10, !tbaa !24
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t88 = getelementptr %"compiler/generic:Program", ptr %t86, i32 0, i32 1
  %t89 = load ptr, ptr %t88, !tbaa !29
  %t91 = getelementptr %"compiler/names:Resolver", ptr %t89, i32 0, i32 1
  %t92 = load i64, ptr %l9, !tbaa !24
  %t95 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_Hc2ccbbc5952c057a60f016e9cc1626d2(ptr %v0, ptr %v0, ptr %t91, i64 %t92)
  store ptr %t95, ptr %l65
  br label %bb20
bb20:
  %t96 = load ptr, ptr %l65, !tbaa !29
  %t98 = getelementptr %"compiler/names:Table", ptr %t96, i32 0, i32 0
  %t100 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eLen_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %t98)
  store i64 %t100, ptr %l68
  br label %bb21
bb21:
  %t101 = load i64, ptr %l68, !tbaa !24
  store i64 %t101, ptr %l11, !tbaa !24
  store i64 1, ptr %l12, !tbaa !24
  %t102 = load i64, ptr %l11, !tbaa !24
  %t103 = load i64, ptr %l10, !tbaa !24
  %t106 = icmp sgt i64 %t102, %t103
  br i1 %t106, label %bb22, label %bb23
bb22:
  %t108 = load i64, ptr %l12, !tbaa !24
  %t110 = icmp sgt i64 %t108, 0
  br i1 %t110, label %bb24, label %bb25
bb23:
  store i64 0, ptr %l72, !tbaa !24
  br label %bb27
bb24:
  %t112 = load i64, ptr %l11, !tbaa !24
  %t113 = load i64, ptr %l10, !tbaa !24
  %t116 = sub i64 %t112, %t113
  %t117 = load i64, ptr %l12, !tbaa !24
  %t120 = add i64 %t116, %t117
  %t122 = sub i64 %t120, 1
  %t123 = load i64, ptr %l12, !tbaa !24
  %t126 = sdiv i64 %t122, %t123
  store i64 %t126, ptr %l75, !tbaa !24
  br label %bb26
bb25:
  store i64 0, ptr %l75, !tbaa !24
  br label %bb26
bb26:
  %t128 = load i64, ptr %l75, !tbaa !24
  store i64 %t128, ptr %l72, !tbaa !24
  br label %bb27
bb27:
  %t129 = load i64, ptr %l72, !tbaa !24
  store i64 %t129, ptr %l13, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  br label %bb28
bb28:
  %t130 = load i64, ptr %l14, !tbaa !24
  %t131 = load i64, ptr %l13, !tbaa !24
  %t134 = icmp slt i64 %t130, %t131
  %t136 = xor i1 %t134, true
  br i1 %t136, label %bb29, label %bb30
bb29:
  br label %bb52
bb30:
  br label %bb31
bb31:
  %t138 = load i64, ptr %l10, !tbaa !24
  %t139 = load i64, ptr %l14, !tbaa !24
  %t140 = load i64, ptr %l12, !tbaa !24
  %t143 = mul i64 %t139, %t140
  %t146 = add i64 %t138, %t143
  store i64 %t146, ptr %l15, !tbaa !24
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t150 = getelementptr %"compiler/generic:Program", ptr %t148, i32 0, i32 1
  %t151 = load ptr, ptr %t150, !tbaa !29
  %t153 = getelementptr %"compiler/names:Resolver", ptr %t151, i32 0, i32 1
  %t154 = load i64, ptr %l9, !tbaa !24
  %t157 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_Hc2ccbbc5952c057a60f016e9cc1626d2(ptr %v0, ptr %v0, ptr %t153, i64 %t154)
  store ptr %t157, ptr %l97
  br label %bb32
bb32:
  %t158 = load ptr, ptr %l97, !tbaa !29
  %t160 = getelementptr %"compiler/names:Table", ptr %t158, i32 0, i32 0
  %t161 = load i64, ptr %l15, !tbaa !24
  %t164 = call %"compiler/names:Entry" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eAt_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %v0, ptr %t160, i64 %t161)
  store %"compiler/names:Entry" %t164, ptr %l101
  br label %bb33
bb33:
  %t165 = load %"compiler/names:Entry", ptr %l101
  store %"compiler/names:Entry" %t165, ptr %l16
  %t166 = getelementptr %"compiler/names:Entry", ptr %l16, i32 0, i32 2
  %t167 = load i32, ptr %t166, !range !{i32 0, i32 9}
  %t169 = trunc i64 4 to i32
  %t170 = icmp eq i32 %t167, %t169
  %t172 = xor i1 %t170, true
  br i1 %t172, label %bb34, label %bb35
bb34:
  br label %bb51
bb35:
  br label %bb36
bb36:
  %t174 = load ptr, ptr %l0, !tbaa !29
  %t175 = getelementptr %"compiler/names:Entry", ptr %l16, i32 0, i32 0
  %t176 = load i32, ptr %t175, !tbaa !23
  %t179 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2etext(ptr %v0, ptr %v0, ptr %t174, i32 %t176)
  store { i64, ptr } %t179, ptr %l107
  br label %bb37
bb37:
  %t180 = load { i64, ptr }, ptr %l107, !tbaa !27
  store { i64, ptr } %t180, ptr %l17, !tbaa !27
  %t181 = load i64, ptr %l9, !tbaa !24
  %t182 = load i64, ptr %l1, !tbaa !24
  %t185 = icmp ne i64 %t181, %t182
  br i1 %t185, label %bb38, label %bb39
bb38:
  %t187 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t189 = call i1 @compiler_2fload_2ePublic(ptr %v0, { i64, ptr } %t187)
  store i1 %t189, ptr %l113
  br label %bb40
bb39:
  store i1 false, ptr %l111, !tbaa !21
  br label %bb41
bb40:
  %t190 = load i1, ptr %l113, !tbaa !21
  %t191 = xor i1 %t190, true
  store i1 %t191, ptr %l111, !tbaa !21
  br label %bb41
bb41:
  %t193 = load i1, ptr %l111, !tbaa !21
  br i1 %t193, label %bb42, label %bb43
bb42:
  br label %bb51
bb43:
  br label %bb44
bb44:
  %t194 = load ptr, ptr %l0, !tbaa !29
  %t196 = getelementptr %"compiler/generic:Program", ptr %t194, i32 0, i32 2
  store ptr %t196, ptr %l116, !tbaa !29
  %t197 = load ptr, ptr %l0, !tbaa !29
  %t198 = load i64, ptr %l9, !tbaa !24
  %t199 = load i64, ptr %l15, !tbaa !24
  %t203 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclFor(ptr %v0, ptr %t197, i64 %t198, i64 %t199)
  store i32 %t203, ptr %l120
  br label %bb45
bb45:
  %t204 = load ptr, ptr %l116, !tbaa !29
  %t205 = load i32, ptr %l120, !tbaa !23
  %t206 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t204, i32 %t205)
  store i32 %t206, ptr %l121
  br label %bb46
bb46:
  %t207 = load i32, ptr %l121, !range !{i32 0, i32 6}
  %t209 = trunc i64 2 to i32
  %t210 = icmp eq i32 %t207, %t209
  br i1 %t210, label %bb47, label %bb48
bb47:
  %t212 = load ptr, ptr %l3, !tbaa !29
  %t213 = load { i64, ptr }, ptr %l17, !tbaa !27
  call void @compiler_2fmsgs_2ecompiler_2fmsgs_3aNearest_2eOffer(ptr %s0, ptr %v0, ptr %t212, { i64, ptr } %t213)
  br label %bb49
bb48:
  br label %bb50
bb49:
  br label %bb50
bb50:
  br label %bb51
bb51:
  %t216 = load i64, ptr %l14, !tbaa !24
  %t219 = add i64 %t216, 1
  store i64 %t219, ptr %l14, !tbaa !24
  br label %bb28
bb52:
  br label %bb53
bb53:
  %t221 = load i64, ptr %l8, !tbaa !24
  %t224 = add i64 %t221, 1
  store i64 %t224, ptr %l8, !tbaa !24
  br label %bb9
bb54:
  %t226 = load ptr, ptr %l3, !tbaa !29
  %t228 = call { i64, ptr } @compiler_2fmsgs_2ecompiler_2fmsgs_3aNearest_2eHint(ptr %s0, ptr %v2, ptr %t226)
  store { i64, ptr } %t228, ptr %l133
  br label %bb55
bb55:
  call void @__olang_scope_close(ptr %s0)
  %t229 = load { i64, ptr }, ptr %l133, !tbaa !27
  store { i64, ptr } %t229, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFieldNames(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca %"std/prelude/iterator:ViewGenerator.00c7c71992d6e1815cd052c47b979cdd"
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l12 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l16 = alloca i32
  %l21 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l23 = alloca i64
  %l24 = alloca { i64, ptr }
  %l27 = alloca i1
  %l28 = alloca ptr
  %l31 = alloca i32
  %l32 = alloca { i64, ptr }
  %l33 = alloca ptr
  %l37 = alloca i32
  %l38 = alloca ptr
  %l41 = alloca i1
  %l46 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l48 = alloca i64
  %l49 = alloca { i64, ptr }
  %l52 = alloca ptr
  %l53 = alloca i1
  %l59 = alloca %"std/prelude/iterator:ViewGenerator.00c7c71992d6e1815cd052c47b979cdd"
  %l60 = alloca ptr
  %l62 = alloca ptr
  %l63 = alloca i32
  %l65 = alloca i1
  %l74 = alloca { i64, ptr }
  %l83 = alloca { i64, ptr }
  %l84 = alloca { i64, ptr }
  %l85 = alloca i64
  %l86 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %wh5 = alloca ptr
  %wc5 = alloca ptr
  %ws5 = alloca i32
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l12
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l12
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l2
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/generic:Program", ptr %t3, i32 0, i32 2
  %t6 = load i32, ptr %l1, !tbaa !23
  %t9 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t5, i32 %t6)
  store i32 %t9, ptr %l16
  br label %bb2
bb2:
  %t10 = load i32, ptr %l16, !range !{i32 0, i32 33}
  %t12 = trunc i64 18 to i32
  %t13 = icmp eq i32 %t10, %t12
  %t15 = xor i1 %t13, true
  br i1 %t15, label %bb3, label %bb4
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t18 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eToArra_H4d02a0b2e27e8f31ffc99daa43750593(ptr %s0, ptr %s1, ptr %l2)
  store { i64, ptr } %t18, ptr %l21
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t19 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t19, ptr %l22, !tbaa !27
  %t20 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t21 = extractvalue { i64, ptr } %t20, 0
  store i64 %t21, ptr %l23, !tbaa !24
  %t22 = load i64, ptr %l23, !tbaa !24
  %t23 = mul i64 %t22, 4
  %t24 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t23)
  %t25 = insertvalue { i64, ptr } undef, i64 %t22, 0
  %t26 = insertvalue { i64, ptr } %t25, ptr %t24, 1
  store { i64, ptr } %t26, ptr %l24, !tbaa !27
  %t27 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !27
  %t29 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !27
  %t31 = load i64, ptr %l23, !tbaa !24
  %t32 = mul i64 %t31, 4
  call void @llvm.memmove.p0.p0.i64(ptr %t28, ptr %t30, i64 %t32, i1 false)
  %t33 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t33, ptr %l22, !tbaa !27
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t34 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t34, ptr %rv
  br label %ret
bb6:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load i32, ptr %l1, !tbaa !23
  %t39 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsColumns(ptr %v0, ptr %t35, i32 %t36)
  store i1 %t39, ptr %l27
  br label %bb7
bb7:
  %t40 = load i1, ptr %l27, !tbaa !21
  br i1 %t40, label %bb8, label %bb9
bb8:
  %t41 = load ptr, ptr %l0, !tbaa !29
  store ptr %t41, ptr %l28, !tbaa !29
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t43 = load i32, ptr %l1, !tbaa !23
  %t46 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eColumnsRow(ptr %v0, ptr %t42, i32 %t43)
  store i32 %t46, ptr %l31
  br label %bb10
bb9:
  br label %bb12
bb10:
  %t47 = load ptr, ptr %l28, !tbaa !29
  %t48 = load i32, ptr %l31, !tbaa !23
  %t49 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFieldNames(ptr %v0, ptr %v1, ptr %t47, i32 %t48)
  store { i64, ptr } %t49, ptr %l32
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s0)
  %t50 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t50, ptr %rv
  br label %ret
bb12:
  %t51 = load ptr, ptr %l0, !tbaa !29
  store ptr %t51, ptr %l33, !tbaa !29
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/generic:Program", ptr %t52, i32 0, i32 2
  %t55 = load i32, ptr %l1, !tbaa !23
  %t58 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t54, i32 %t55)
  store i32 %t58, ptr %l37
  br label %bb13
bb13:
  %t59 = load ptr, ptr %l33, !tbaa !29
  %t60 = load i32, ptr %l37, !tbaa !23
  %t61 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2etypeDecl(ptr %v0, ptr %v0, ptr %t59, i32 %t60)
  store ptr %t61, ptr %l38
  br label %bb14
bb14:
  %t62 = load ptr, ptr %l38, !tbaa !29
  store ptr %t62, ptr %l3, !tbaa !29
  %t63 = load ptr, ptr %l3, !tbaa !29
  %t65 = icmp eq ptr %t63, null
  br i1 %t65, label %bb15, label %bb16
bb15:
  store i1 true, ptr %l41, !tbaa !21
  br label %bb17
bb16:
  %t67 = load ptr, ptr %l3, !tbaa !29
  %t69 = getelementptr %"compiler/ast:TypeDecl", ptr %t67, i32 0, i32 3
  %t70 = load ptr, ptr %t69, !tbaa !29
  %t72 = icmp eq ptr %t70, null
  store i1 %t72, ptr %l41, !tbaa !21
  br label %bb17
bb17:
  %t74 = load i1, ptr %l41, !tbaa !21
  br i1 %t74, label %bb18, label %bb19
bb18:
  store %olang.scope zeroinitializer, ptr %s3
  %t76 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eToArra_H4d02a0b2e27e8f31ffc99daa43750593(ptr %s0, ptr %s3, ptr %l2)
  store { i64, ptr } %t76, ptr %l46
  br label %bb20
bb19:
  br label %bb21
bb20:
  %t77 = load { i64, ptr }, ptr %l46, !tbaa !27
  store { i64, ptr } %t77, ptr %l47, !tbaa !27
  %t78 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t79 = extractvalue { i64, ptr } %t78, 0
  store i64 %t79, ptr %l48, !tbaa !24
  %t80 = load i64, ptr %l48, !tbaa !24
  %t81 = mul i64 %t80, 4
  %t82 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t81)
  %t83 = insertvalue { i64, ptr } undef, i64 %t80, 0
  %t84 = insertvalue { i64, ptr } %t83, ptr %t82, 1
  store { i64, ptr } %t84, ptr %l49, !tbaa !27
  %t85 = getelementptr { i64, ptr }, ptr %l49, i32 0, i32 1
  %t86 = load ptr, ptr %t85, !tbaa !27
  %t87 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t88 = load ptr, ptr %t87, !tbaa !27
  %t89 = load i64, ptr %l48, !tbaa !24
  %t90 = mul i64 %t89, 4
  call void @llvm.memmove.p0.p0.i64(ptr %t86, ptr %t88, i64 %t90, i1 false)
  %t91 = load { i64, ptr }, ptr %l49, !tbaa !27
  store { i64, ptr } %t91, ptr %l47, !tbaa !27
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t92 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } %t92, ptr %rv
  br label %ret
bb21:
  %t93 = load ptr, ptr %l3, !tbaa !29
  %t95 = getelementptr %"compiler/ast:TypeDecl", ptr %t93, i32 0, i32 3
  %t96 = load ptr, ptr %t95, !tbaa !29
  store ptr %t96, ptr %l4, !tbaa !29
  %t98 = load ptr, ptr %l4, !tbaa !29
  store ptr %t98, ptr %l52, !tbaa !29
  store i1 false, ptr %l53, !tbaa !21
  %t99 = load ptr, ptr %l52, !tbaa !29
  %t100 = icmp ne ptr %t99, null
  br i1 %t100, label %bb22, label %bb23
bb22:
  %t102 = load ptr, ptr %l52, !tbaa !29
  %t103 = load i64, ptr %t102, !range !{i64 0, i64 5}
  %t105 = icmp eq i64 %t103, 0
  store i1 %t105, ptr %l53, !tbaa !21
  br label %bb23
bb23:
  %t106 = load i1, ptr %l53, !tbaa !21
  br i1 %t106, label %bb24, label %bb25
bb24:
  %t107 = load ptr, ptr %l4, !tbaa !29
  %t109 = getelementptr { i64, [6 x i64] }, ptr %t107, i32 0, i32 1
  %t110 = getelementptr { ptr }, ptr %t109, i32 0, i32 0
  %t111 = load ptr, ptr %t110
  store ptr %t111, ptr %l5, !tbaa !29
  br label %bb26
bb25:
  br label %bb42
bb26:
  store %olang.scope zeroinitializer, ptr %s5
  %t113 = load ptr, ptr %l5, !tbaa !29
  %t115 = call %"std/prelude/iterator:ViewGenerator.00c7c71992d6e1815cd052c47b979cdd" @compiler_2fgeneric_2eFieldDecls.walk(ptr %v0, ptr %s5, ptr %t113)
  %t116 = extractvalue %"std/prelude/iterator:ViewGenerator.00c7c71992d6e1815cd052c47b979cdd" %t115, 0, 1
  %t117 = extractvalue %"std/prelude/iterator:ViewGenerator.00c7c71992d6e1815cd052c47b979cdd" %t115, 0, 0
  store ptr %t116, ptr %wh5
  store ptr %t117, ptr %wc5
  store %"std/prelude/iterator:ViewGenerator.00c7c71992d6e1815cd052c47b979cdd" %t115, ptr %l59
  br label %bb27
bb27:
  %t118 = load %"std/prelude/iterator:ViewGenerator.00c7c71992d6e1815cd052c47b979cdd", ptr %l59
  store %"std/prelude/iterator:ViewGenerator.00c7c71992d6e1815cd052c47b979cdd" %t118, ptr %l6
  br label %bb28
bb28:
  %t120 = call { i32, ptr } @std_2fprelude_2fiterator_2estd_2fprelude_2fiterator_3aViewGenerator_3ccompiler_2fast_3aV_Hf179e857cb72c72900f4614cd5df5a25(ptr %s5, ptr %l6)
  %t121 = extractvalue { i32, ptr } %t120, 1
  %t122 = extractvalue { i32, ptr } %t120, 0
  store i32 %t122, ptr %l63
  %t123 = icmp ne i32 %t122, 0
  br i1 %t123, label %bb30, label %ok.124, !prof !99
ok.124:
  store ptr %t121, ptr %l62
  br label %bb29
bb29:
  %t125 = load ptr, ptr %l62, !tbaa !29
  store ptr %t125, ptr %l60, !tbaa !29
  br label %bb32
bb30:
  %t126 = load i32, ptr %l63, !tbaa !23
  %t127 = ashr i32 %t126, 16
  %t129 = icmp eq i32 %t127, 1
  store i1 %t129, ptr %l65, !tbaa !21
  br label %bb31
bb31:
  br label %bb41
bb32:
  %t130 = load ptr, ptr %l60, !tbaa !29
  %t133 = getelementptr %"compiler/ast:VarDecl", ptr %t130, i32 0, i32 0
  %t134 = load { i64, ptr }, ptr %t133, !tbaa !27
  store { i64, ptr } %t134, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t136 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t138 = extractvalue { i64, ptr } %t136, 0
  store i64 %t138, ptr %l10, !tbaa !24
  br label %bb33
bb33:
  %t140 = load i64, ptr %l9, !tbaa !24
  %t141 = load i64, ptr %l10, !tbaa !24
  %t144 = icmp slt i64 %t140, %t141
  %t146 = xor i1 %t144, true
  br i1 %t146, label %bb34, label %bb35
bb34:
  br label %bb39
bb35:
  br label %bb36
bb36:
  %t148 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t148, ptr %l74, !tbaa !27
  %t149 = load i64, ptr %l9, !tbaa !24
  %t151 = getelementptr { i64, ptr }, ptr %l74, i32 0, i32 1
  %t152 = load ptr, ptr %t151, !tbaa !27
  %t153 = getelementptr i32, ptr %t152, i64 %t149
  %t154 = load i32, ptr %t153, !tbaa !33
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ePush_3ccompiler_2fsource_3aNameId_3e(ptr %s0, ptr %l2, i32 %t154)
  br label %bb37
bb37:
  br label %bb38
bb38:
  %t159 = load i64, ptr %l9, !tbaa !24
  %t162 = add i64 %t159, 1
  store i64 %t162, ptr %l9, !tbaa !24
  br label %bb33
bb39:
  br label %bb40
bb40:
  br label %bb28
bb41:
  store i32 0, ptr %ws5
  br label %wend5
wend5.c0:
  call void @__olang_scope_close(ptr %s5)
  br label %bb47
bb42:
  br i1 true, label %bb43, label %bb44
bb43:
  br label %bb45
bb44:
  br label %bb46
bb45:
  br label %bb47
bb46:
  call void @__olang_check_failed(ptr @olang_loc_2a66b784d9289786_f31abe169e6a7bb2)
  unreachable
bb47:
  %t165 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eToArra_H4d02a0b2e27e8f31ffc99daa43750593(ptr %s0, ptr %s0, ptr %l2)
  store { i64, ptr } %t165, ptr %l83
  br label %bb48
bb48:
  %t166 = load { i64, ptr }, ptr %l83, !tbaa !27
  store { i64, ptr } %t166, ptr %l84, !tbaa !27
  %t167 = load { i64, ptr }, ptr %l84, !tbaa !27
  %t168 = extractvalue { i64, ptr } %t167, 0
  store i64 %t168, ptr %l85, !tbaa !24
  %t169 = load i64, ptr %l85, !tbaa !24
  %t170 = mul i64 %t169, 4
  %t171 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t170)
  %t172 = insertvalue { i64, ptr } undef, i64 %t169, 0
  %t173 = insertvalue { i64, ptr } %t172, ptr %t171, 1
  store { i64, ptr } %t173, ptr %l86, !tbaa !27
  %t174 = getelementptr { i64, ptr }, ptr %l86, i32 0, i32 1
  %t175 = load ptr, ptr %t174, !tbaa !27
  %t176 = getelementptr { i64, ptr }, ptr %l84, i32 0, i32 1
  %t177 = load ptr, ptr %t176, !tbaa !27
  %t178 = load i64, ptr %l85, !tbaa !24
  %t179 = mul i64 %t178, 4
  call void @llvm.memmove.p0.p0.i64(ptr %t175, ptr %t177, i64 %t179, i1 false)
  %t180 = load { i64, ptr }, ptr %l86, !tbaa !27
  store { i64, ptr } %t180, ptr %l84, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t181 = load { i64, ptr }, ptr %l84, !tbaa !27
  store { i64, ptr } %t181, ptr %rv
  br label %ret
wend5:
  %t182 = load ptr, ptr %wh5
  %t183 = load ptr, ptr %wc5
  %t184 = call ptr @llvm.coro.promise(ptr %t182, i32 8, i1 false)
  %t185 = getelementptr { { i32, ptr }, i32 }, ptr %t184, i32 0, i32 1
  store i32 2, ptr %t185
  %t186 = call { i32, ptr } %t183(ptr %t182, ptr null)
  %t187 = load i32, ptr %ws5
  switch i32 %t187, label %wend5.c0 [ ]
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFoldLength(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca %"compiler/generic:folded"
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i1
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca %"compiler/generic:ConstAsk"
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9"
  %l15 = alloca %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa"
  %l20 = alloca i1
  %l25 = alloca i1
  %l29 = alloca i32
  %l33 = alloca %"compiler/generic:folded"
  %l37 = alloca i1
  %l41 = alloca i1
  %l44 = alloca i1
  %l48 = alloca { i64, ptr }
  %l53 = alloca i1
  %l54 = alloca i64
  %l58 = alloca i64
  %l59 = alloca i32
  %l64 = alloca i32
  %l69 = alloca i32
  %l72 = alloca i64
  %l74 = alloca i64
  %l79 = alloca %"compiler/generic:ConstAsk"
  %l82 = alloca i1
  %l90 = alloca i64
  %l96 = alloca i64
  %l102 = alloca %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9"
  %l103 = alloca %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa"
  %l105 = alloca %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa"
  %l106 = alloca i32
  %l108 = alloca i1
  %l111 = alloca { i64, ptr }
  %l114 = alloca { i64, ptr }
  %l121 = alloca ptr
  %l131 = alloca %"compiler/generic:ConstAsk"
  %l133 = alloca i32
  %l137 = alloca i1
  %l141 = alloca i1
  %l142 = alloca i1
  %l146 = alloca i1
  %l150 = alloca i1
  %l152 = alloca i1
  %l154 = alloca i1
  %l160 = alloca i1
  %l164 = alloca i1
  %l168 = alloca i1
  %l177 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l20, !tbaa !21
  br label %bb4
bb2:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t6 = load ptr, ptr %l1, !tbaa !29
  %t7 = load ptr, ptr %l2, !tbaa !29
  %t12 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ereadsLocal(ptr %v0, ptr %v1, ptr %v2, ptr %t5, ptr %t6, ptr %t7)
  store i1 %t12, ptr %l25
  br label %bb3
bb3:
  %t13 = load i1, ptr %l25, !tbaa !21
  store i1 %t13, ptr %l20, !tbaa !21
  br label %bb4
bb4:
  %t14 = load i1, ptr %l20, !tbaa !21
  br i1 %t14, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/generic:Program", ptr %t16, i32 0, i32 2
  %t20 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s0, ptr %t18, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d0, i32 0, i32 1) })
  store i32 %t20, ptr %l29
  br label %bb8
bb8:
  %t21 = load i32, ptr %l29, !tbaa !23
  store i32 %t21, ptr %l3, !tbaa !23
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = load ptr, ptr %l1, !tbaa !29
  %t24 = load ptr, ptr %l2, !tbaa !29
  %t28 = call %"compiler/generic:folded" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eeval(ptr %v0, ptr %v1, ptr %v2, ptr %t22, ptr %t23, ptr %t24)
  store %"compiler/generic:folded" %t28, ptr %l33
  br label %bb9
bb9:
  %t29 = load %"compiler/generic:folded", ptr %l33
  store %"compiler/generic:folded" %t29, ptr %l4
  %t30 = getelementptr %"compiler/generic:folded", ptr %l4, i32 0, i32 0
  %t31 = load i64, ptr %t30, !tbaa !24
  %t32 = load i64, ptr @G_2ecompiler_2fgeneric_2eUnfolded, !tbaa !24
  %t35 = icmp eq i64 %t31, %t32
  br i1 %t35, label %bb10, label %bb11
bb10:
  %t37 = load ptr, ptr %l1, !tbaa !29
  %t39 = getelementptr %"compiler/generic:Context", ptr %t37, i32 0, i32 1
  %t40 = load i64, ptr %t39, !tbaa !24
  %t42 = icmp slt i64 %t40, 0
  br i1 %t42, label %bb12, label %bb13
bb11:
  store i1 false, ptr %l37, !tbaa !21
  br label %bb16
bb12:
  store i1 true, ptr %l41, !tbaa !21
  br label %bb15
bb13:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t45 = load ptr, ptr %l1, !tbaa !29
  %t48 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2evarsBound(ptr %v0, ptr %v1, ptr %t44, ptr %t45)
  store i1 %t48, ptr %l44
  br label %bb14
bb14:
  %t49 = load i1, ptr %l44, !tbaa !21
  store i1 %t49, ptr %l41, !tbaa !21
  br label %bb15
bb15:
  %t50 = load i1, ptr %l41, !tbaa !21
  store i1 %t50, ptr %l37, !tbaa !21
  br label %bb16
bb16:
  %t51 = load i1, ptr %l37, !tbaa !21
  br i1 %t51, label %bb17, label %bb18
bb17:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = load ptr, ptr %l1, !tbaa !29
  %t54 = load ptr, ptr %l2, !tbaa !29
  %t58 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eLengthKey(ptr %v0, ptr %v1, ptr %v2, ptr %v0, ptr %t52, ptr %t53, ptr %t54)
  store { i64, ptr } %t58, ptr %l48
  br label %bb19
bb18:
  br label %bb68
bb19:
  %t59 = load { i64, ptr }, ptr %l48, !tbaa !27
  store { i64, ptr } %t59, ptr %l5, !tbaa !27
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = getelementptr %"compiler/generic:Program", ptr %t61, i32 0, i32 63
  %t64 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t67 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9b83f66eba65594537030636cb0b52b7(ptr %v0, ptr %v0, ptr %t63, { i64, ptr } %t64)
  store i1 %t67, ptr %l53
  br label %bb20
bb20:
  %t68 = load i1, ptr %l53, !tbaa !21
  br i1 %t68, label %bb21, label %bb22
bb21:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/generic:Program", ptr %t69, i32 0, i32 63
  %t72 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t75 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9162e3b7f03fcbf954b681204d5f6cca(ptr %v0, ptr %v0, ptr %t71, { i64, ptr } %t72)
  %t76 = extractvalue { i32, i64 } %t75, 1
  %t77 = extractvalue { i32, i64 } %t75, 0
  store i32 %t77, ptr %l59
  %t78 = icmp ne i32 %t77, 0
  br i1 %t78, label %bb24, label %ok.79, !prof !99
ok.79:
  store i64 %t76, ptr %l58
  br label %bb23
bb22:
  br label %bb31
bb23:
  %t80 = load i64, ptr %l58, !tbaa !24
  store i64 %t80, ptr %l54, !tbaa !24
  br label %bb26
bb24:
  br label %bb25
bb25:
  %t81 = load i64, ptr @G_2ecompiler_2fgeneric_2eRunTimeLength, !tbaa !24
  store i64 %t81, ptr %l54, !tbaa !24
  br label %bb26
bb26:
  %t83 = load i64, ptr %l54, !tbaa !24
  store i64 %t83, ptr %l6, !tbaa !24
  %t84 = load i64, ptr %l6, !tbaa !24
  %t85 = load i64, ptr @G_2ecompiler_2fgeneric_2eRunTimeLength, !tbaa !24
  %t88 = icmp eq i64 %t84, %t85
  br i1 %t88, label %bb27, label %bb28
bb27:
  store i32 0, ptr %l64, !tbaa !23
  br label %bb30
bb28:
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t92 = getelementptr %"compiler/generic:Program", ptr %t90, i32 0, i32 2
  %t93 = load i32, ptr %l3, !tbaa !23
  %t94 = load i64, ptr %l6, !tbaa !24
  %t98 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConst(ptr %v0, ptr %t92, i32 %t93, i64 %t94)
  store i32 %t98, ptr %l69
  br label %bb29
bb29:
  %t99 = load i32, ptr %l69, !tbaa !23
  store i32 %t99, ptr %l64, !tbaa !23
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s0)
  %t100 = load i32, ptr %l64, !tbaa !23
  store i32 %t100, ptr %rv
  br label %ret
bb31:
  store i1 false, ptr %l7, !tbaa !21
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t103 = getelementptr %"compiler/generic:Program", ptr %t101, i32 0, i32 64
  store ptr %t103, ptr %l8, !tbaa !29
  store i64 0, ptr %l9, !tbaa !24
  br label %bb32
bb32:
  %t105 = load i64, ptr %l9, !tbaa !24
  store i64 %t105, ptr %l72, !tbaa !24
  %t106 = load ptr, ptr %l8, !tbaa !29
  %t108 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3aConstAsk_3e_2eLen_H192b02349624a37821a23e7def80c714(ptr %v0, ptr %t106)
  store i64 %t108, ptr %l74
  br label %bb33
bb33:
  %t109 = load i64, ptr %l72, !tbaa !24
  %t110 = load i64, ptr %l74, !tbaa !24
  %t111 = icmp slt i64 %t109, %t110
  %t113 = xor i1 %t111, true
  br i1 %t113, label %bb34, label %bb35
bb34:
  br label %bb43
bb35:
  br label %bb36
bb36:
  %t115 = load ptr, ptr %l8, !tbaa !29
  %t116 = load i64, ptr %l9, !tbaa !24
  %t119 = call %"compiler/generic:ConstAsk" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3aConstAsk_3e_2eAt__H3f4459851a287fa27378a94ef8fff763(ptr %v0, ptr %v0, ptr %t115, i64 %t116)
  store %"compiler/generic:ConstAsk" %t119, ptr %l79
  br label %bb37
bb37:
  %t120 = load %"compiler/generic:ConstAsk", ptr %l79
  store %"compiler/generic:ConstAsk" %t120, ptr %l10
  %t121 = getelementptr %"compiler/generic:ConstAsk", ptr %l10, i32 0, i32 6
  %t122 = load { i64, ptr }, ptr %t121, !tbaa !27
  %t123 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t126 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v0, { i64, ptr } %t122, { i64, ptr } %t123)
  store i1 %t126, ptr %l82
  br label %bb38
bb38:
  %t127 = load i1, ptr %l82, !tbaa !21
  br i1 %t127, label %bb39, label %bb40
bb39:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb41
bb40:
  br label %bb41
bb41:
  br label %bb42
bb42:
  %t128 = load i64, ptr %l9, !tbaa !24
  %t131 = add i64 %t128, 1
  store i64 %t131, ptr %l9, !tbaa !24
  br label %bb32
bb43:
  %t133 = load i1, ptr %l7, !tbaa !21
  %t135 = xor i1 %t133, true
  br i1 %t135, label %bb44, label %bb45
bb44:
  %t137 = load ptr, ptr %l1, !tbaa !29
  %t139 = getelementptr %"compiler/generic:Context", ptr %t137, i32 0, i32 2
  %t141 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_H0e73c22773457b60eb954c2c4a2643e9(ptr %v1, ptr %t139)
  store i64 %t141, ptr %l90
  br label %bb46
bb45:
  br label %bb66
bb46:
  %t142 = load i64, ptr %l90, !tbaa !24
  %t143 = icmp sge i64 %t142, 0
  br i1 %t143, label %bb47, label %bb48
bb47:
  %t145 = load i64, ptr %l90, !tbaa !24
  %t146 = icmp sle i64 %t145, 2305843009213693951
  br i1 %t146, label %bb49, label %bb50
bb48:
  call void @__olang_check_failed(ptr @olang_loc_99cf014ebb3d252c_a323a427e7fb0b10)
  unreachable
bb49:
  %t148 = load i64, ptr %l90, !tbaa !24
  %t149 = mul i64 %t148, 4
  %t150 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t149)
  %t151 = insertvalue { i64, ptr } undef, i64 %t148, 0
  %t152 = insertvalue { i64, ptr } %t151, ptr %t150, 1
  store { i64, ptr } %t152, ptr %l11, !tbaa !27
  %t154 = load ptr, ptr %l1, !tbaa !29
  %t156 = getelementptr %"compiler/generic:Context", ptr %t154, i32 0, i32 2
  %t158 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_H0e73c22773457b60eb954c2c4a2643e9(ptr %v1, ptr %t156)
  store i64 %t158, ptr %l96
  br label %bb51
bb50:
  call void @__olang_check_failed(ptr @olang_loc_99cf014ebb3d252c_a323a427e7fb0b10)
  unreachable
bb51:
  %t159 = load i64, ptr %l96, !tbaa !24
  %t160 = icmp sge i64 %t159, 0
  br i1 %t160, label %bb52, label %bb53
bb52:
  %t162 = load i64, ptr %l96, !tbaa !24
  %t163 = icmp sle i64 %t162, 2305843009213693951
  br i1 %t163, label %bb54, label %bb55
bb53:
  call void @__olang_check_failed(ptr @olang_loc_9c491d6513909eb9_b2019bc0b634333d)
  unreachable
bb54:
  %t165 = load i64, ptr %l96, !tbaa !24
  %t166 = mul i64 %t165, 4
  %t167 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t166)
  %t168 = insertvalue { i64, ptr } undef, i64 %t165, 0
  %t169 = insertvalue { i64, ptr } %t168, ptr %t167, 1
  store { i64, ptr } %t169, ptr %l12, !tbaa !27
  store i64 0, ptr %l13, !tbaa !24
  %t171 = load ptr, ptr %l1, !tbaa !29
  %t173 = getelementptr %"compiler/generic:Context", ptr %t171, i32 0, i32 2
  %t175 = call %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_Ha72624ba64524ee3315305b5d1bfb369(ptr %v1, ptr %v1, ptr %t173)
  store %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" %t175, ptr %l102
  br label %bb56
bb55:
  call void @__olang_check_failed(ptr @olang_loc_9c491d6513909eb9_b2019bc0b634333d)
  unreachable
bb56:
  %t176 = load %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9", ptr %l102
  store %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" %t176, ptr %l14
  br label %bb57
bb57:
  %t178 = call { i32, %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapIter_3ccompiler_2fsource_3aNameId_2c_20co_H6cf169b12565f300e9fe11f1c8d55061(ptr %v1, ptr %l14)
  %t179 = extractvalue { i32, %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" } %t178, 1
  %t180 = extractvalue { i32, %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" } %t178, 0
  store i32 %t180, ptr %l106
  %t181 = icmp ne i32 %t180, 0
  br i1 %t181, label %bb59, label %ok.182, !prof !99
ok.182:
  store %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" %t179, ptr %l105
  br label %bb58
bb58:
  %t183 = load %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa", ptr %l105
  store %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" %t183, ptr %l103
  br label %bb61
bb59:
  %t184 = load i32, ptr %l106, !tbaa !23
  %t185 = ashr i32 %t184, 16
  %t187 = icmp eq i32 %t185, 1
  store i1 %t187, ptr %l108, !tbaa !21
  br label %bb60
bb60:
  br label %bb63
bb61:
  %t188 = load %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa", ptr %l103
  store %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" %t188, ptr %l15
  %t189 = getelementptr %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa", ptr %l15, i32 0, i32 0
  %t190 = load i32, ptr %t189, !tbaa !23
  %t192 = getelementptr %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa", ptr %l15, i32 0, i32 1
  %t193 = load i32, ptr %t192, !tbaa !23
  %t195 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t195, ptr %l111, !tbaa !27
  %t196 = load i64, ptr %l13, !tbaa !24
  %t200 = getelementptr { i64, ptr }, ptr %l111, i32 0, i32 1
  %t201 = load ptr, ptr %t200, !tbaa !27
  %t202 = getelementptr i32, ptr %t201, i64 %t196
  store i32 %t190, ptr %t202, !tbaa !33
  %t203 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t203, ptr %l114, !tbaa !27
  %t204 = load i64, ptr %l13, !tbaa !24
  %t208 = getelementptr { i64, ptr }, ptr %l114, i32 0, i32 1
  %t209 = load ptr, ptr %t208, !tbaa !27
  %t210 = getelementptr i32, ptr %t209, i64 %t204
  store i32 %t193, ptr %t210, !tbaa !33
  %t211 = load i64, ptr %l13, !tbaa !24
  %t214 = add i64 %t211, 1
  store i64 %t214, ptr %l13, !tbaa !24
  br label %bb62
bb62:
  br label %bb57
bb63:
  %t216 = load ptr, ptr %l0, !tbaa !29
  %t218 = getelementptr %"compiler/generic:Program", ptr %t216, i32 0, i32 64
  store ptr %t218, ptr %l121, !tbaa !29
  %t219 = load ptr, ptr %l1, !tbaa !29
  %t221 = getelementptr %"compiler/generic:Context", ptr %t219, i32 0, i32 0
  %t222 = load i64, ptr %t221, !tbaa !24
  %t223 = load ptr, ptr %l2, !tbaa !29
  %t224 = load i32, ptr %l3, !tbaa !23
  %t225 = load ptr, ptr %l1, !tbaa !29
  %t227 = getelementptr %"compiler/generic:Context", ptr %t225, i32 0, i32 1
  %t228 = load i64, ptr %t227, !tbaa !24
  %t229 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t230 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t231 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t239 = call %"compiler/generic:ConstAsk" @compiler_2fgeneric_3aConstAsk_2ector(ptr %v2, ptr %v0, ptr %v0, ptr %v0, ptr %v0, i64 %t222, ptr %t223, i32 %t224, i64 %t228, { i64, ptr } %t229, { i64, ptr } %t230, { i64, ptr } %t231)
  store %"compiler/generic:ConstAsk" %t239, ptr %l131
  br label %bb64
bb64:
  %t240 = load ptr, ptr %l121, !tbaa !29
  %t241 = load %"compiler/generic:ConstAsk", ptr %l131
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3aConstAsk_3e_2ePus_H9314813d35e39659e36ddfdc05758427(ptr %v0, ptr %v0, ptr %t240, %"compiler/generic:ConstAsk" %t241)
  br label %bb65
bb65:
  br label %bb66
bb66:
  %t242 = load ptr, ptr %l0, !tbaa !29
  %t244 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eUnknownConst(ptr %v0, ptr %t242)
  store i32 %t244, ptr %l133
  br label %bb67
bb67:
  call void @__olang_scope_close(ptr %s0)
  %t245 = load i32, ptr %l133, !tbaa !23
  store i32 %t245, ptr %rv
  br label %ret
bb68:
  %t246 = getelementptr %"compiler/generic:folded", ptr %l4, i32 0, i32 0
  %t247 = load i64, ptr %t246, !tbaa !24
  %t248 = load i64, ptr @G_2ecompiler_2fgeneric_2eFolded, !tbaa !24
  %t251 = icmp eq i64 %t247, %t248
  br i1 %t251, label %bb69, label %bb70
bb69:
  %t253 = load ptr, ptr %l0, !tbaa !29
  %t255 = getelementptr %"compiler/generic:Program", ptr %t253, i32 0, i32 2
  %t256 = getelementptr %"compiler/generic:folded", ptr %l4, i32 0, i32 2
  %t257 = load i32, ptr %t256, !tbaa !23
  %t260 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %t255, i32 %t257)
  store i1 %t260, ptr %l141
  br label %bb71
bb70:
  store i1 false, ptr %l137, !tbaa !21
  br label %bb72
bb71:
  %t261 = load i1, ptr %l141, !tbaa !21
  store i1 %t261, ptr %l137, !tbaa !21
  br label %bb72
bb72:
  %t262 = load i1, ptr %l137, !tbaa !21
  br i1 %t262, label %bb73, label %bb74
bb73:
  %t263 = getelementptr %"compiler/generic:folded", ptr %l4, i32 0, i32 2
  %t264 = load i32, ptr %t263, !tbaa !23
  %t265 = load i32, ptr %l3, !tbaa !23
  %t268 = icmp ne i32 %t264, %t265
  store i1 %t268, ptr %l142, !tbaa !21
  br label %bb75
bb74:
  store i1 false, ptr %l142, !tbaa !21
  br label %bb75
bb75:
  %t270 = load i1, ptr %l142, !tbaa !21
  br i1 %t270, label %bb76, label %bb77
bb76:
  %t271 = load ptr, ptr %l0, !tbaa !29
  %t272 = getelementptr %"compiler/generic:folded", ptr %l4, i32 0, i32 2
  %t273 = load i32, ptr %t272, !tbaa !23
  %t274 = load i32, ptr %l3, !tbaa !23
  %t278 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFlows(ptr %v0, ptr %t271, i32 %t273, i32 %t274)
  store i1 %t278, ptr %l150
  br label %bb78
bb77:
  store i1 false, ptr %l146, !tbaa !21
  br label %bb79
bb78:
  %t279 = load i1, ptr %l150, !tbaa !21
  %t280 = xor i1 %t279, true
  store i1 %t280, ptr %l146, !tbaa !21
  br label %bb79
bb79:
  %t282 = load i1, ptr %l146, !tbaa !21
  br i1 %t282, label %bb80, label %bb81
bb80:
  %t283 = load ptr, ptr %l2, !tbaa !29
  %t285 = call i1 @compiler_2fgeneric_2elitOnly(ptr %v2, ptr %t283)
  store i1 %t285, ptr %l154
  br label %bb82
bb81:
  store i1 false, ptr %l152, !tbaa !21
  br label %bb83
bb82:
  %t286 = load i1, ptr %l154, !tbaa !21
  %t287 = xor i1 %t286, true
  store i1 %t287, ptr %l152, !tbaa !21
  br label %bb83
bb83:
  %t289 = load i1, ptr %l152, !tbaa !21
  br i1 %t289, label %bb84, label %bb85
bb84:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
bb85:
  br label %bb86
bb86:
  %t291 = getelementptr %"compiler/generic:folded", ptr %l4, i32 0, i32 0
  %t292 = load i64, ptr %t291, !tbaa !24
  %t293 = load i64, ptr @G_2ecompiler_2fgeneric_2eFolded, !tbaa !24
  %t296 = icmp eq i64 %t292, %t293
  br i1 %t296, label %bb87, label %bb88
bb87:
  %t298 = getelementptr %"compiler/generic:folded", ptr %l4, i32 0, i32 2
  %t299 = load i32, ptr %t298, !tbaa !23
  %t300 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t303 = icmp ne i32 %t299, %t300
  store i1 %t303, ptr %l160, !tbaa !21
  br label %bb89
bb88:
  store i1 false, ptr %l160, !tbaa !21
  br label %bb89
bb89:
  %t305 = load i1, ptr %l160, !tbaa !21
  br i1 %t305, label %bb90, label %bb91
bb90:
  %t306 = load ptr, ptr %l0, !tbaa !29
  %t308 = getelementptr %"compiler/generic:Program", ptr %t306, i32 0, i32 2
  %t309 = getelementptr %"compiler/generic:folded", ptr %l4, i32 0, i32 2
  %t310 = load i32, ptr %t309, !tbaa !23
  %t313 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %t308, i32 %t310)
  store i1 %t313, ptr %l168
  br label %bb92
bb91:
  store i1 false, ptr %l164, !tbaa !21
  br label %bb93
bb92:
  %t314 = load i1, ptr %l168, !tbaa !21
  %t315 = xor i1 %t314, true
  store i1 %t315, ptr %l164, !tbaa !21
  br label %bb93
bb93:
  %t317 = load i1, ptr %l164, !tbaa !21
  br i1 %t317, label %bb94, label %bb95
bb94:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
bb95:
  br label %bb96
bb96:
  %t319 = load ptr, ptr %l0, !tbaa !29
  %t320 = load ptr, ptr %l1, !tbaa !29
  %t321 = load %"compiler/generic:folded", ptr %l4
  %t322 = load i32, ptr %l3, !tbaa !23
  %t323 = load ptr, ptr %l2, !tbaa !29
  %t330 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2econstOf(ptr %v0, ptr %v1, ptr %v2, ptr %t319, ptr %t320, %"compiler/generic:folded" %t321, i32 %t322, ptr %t323)
  store i32 %t330, ptr %l177
  br label %bb97
bb97:
  call void @__olang_scope_close(ptr %s0)
  %t331 = load i32, ptr %l177, !tbaa !23
  store i32 %t331, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eLayout(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca i1
  %l4 = alloca i1
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l16 = alloca i64
  %l34 = alloca i32
  %l37 = alloca i1
  %l39 = alloca ptr
  %l43 = alloca i32
  %l44 = alloca { i64, ptr }
  %l48 = alloca i1
  %l53 = alloca ptr
  %l57 = alloca i32
  %l68 = alloca ptr
  %l74 = alloca i1
  %l79 = alloca i1
  %l83 = alloca i32
  %l86 = alloca ptr
  %l90 = alloca i32
  %l95 = alloca { i64, ptr }
  %l103 = alloca { i64, ptr }
  %l108 = alloca i1
  %l114 = alloca i1
  %l118 = alloca i1
  %l120 = alloca ptr
  %l124 = alloca i32
  %l125 = alloca { i64, ptr }
  %l132 = alloca { i64, ptr }
  %l144 = alloca i1
  %l146 = alloca ptr
  %l153 = alloca i64
  %l157 = alloca ptr
  %l158 = alloca i32
  %l160 = alloca i64
  %s0 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/generic:Program", ptr %t1, i32 0, i32 2
  %t4 = load i32, ptr %l1, !tbaa !23
  %t7 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLayoutState(ptr %v0, ptr %t3, i32 %t4)
  store i64 %t7, ptr %l16
  br label %bb1
bb1:
  %t8 = load i64, ptr %l16, !tbaa !24
  store i64 %t8, ptr %l2, !tbaa !24
  %t9 = load i64, ptr %l2, !tbaa !24
  %t10 = load i64, ptr @G_2ecompiler_2ftypes_2eLaidOut, !tbaa !24
  %t13 = icmp eq i64 %t9, %t10
  br i1 %t13, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t16 = load i64, ptr %l2, !tbaa !24
  %t17 = load i64, ptr @G_2ecompiler_2ftypes_2eNoLayout, !tbaa !24
  %t20 = icmp eq i64 %t16, %t17
  br i1 %t20, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t23 = load i64, ptr %l2, !tbaa !24
  %t24 = load i64, ptr @G_2ecompiler_2ftypes_2eLayingOut, !tbaa !24
  %t27 = icmp eq i64 %t23, %t24
  br i1 %t27, label %bb8, label %bb9
bb8:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t30 = load i32, ptr %l1, !tbaa !23
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eholdsItself(ptr %v0, ptr %t29, i32 %t30)
  br label %bb10
bb9:
  br label %bb11
bb10:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb11:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/generic:Program", ptr %t34, i32 0, i32 2
  %t37 = load i32, ptr %l1, !tbaa !23
  %t40 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t36, i32 %t37)
  store i32 %t40, ptr %l34
  br label %bb12
bb12:
  %t41 = load i32, ptr %l34, !range !{i32 0, i32 33}
  %t43 = trunc i64 18 to i32
  %t44 = icmp eq i32 %t41, %t43
  br i1 %t44, label %bb13, label %bb14
bb13:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/generic:Program", ptr %t46, i32 0, i32 2
  store ptr %t48, ptr %l39, !tbaa !29
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/generic:Program", ptr %t49, i32 0, i32 2
  %t52 = load i32, ptr %l1, !tbaa !23
  %t55 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %t51, i32 %t52)
  store i32 %t55, ptr %l43
  br label %bb15
bb14:
  store i1 false, ptr %l37, !tbaa !21
  br label %bb17
bb15:
  %t56 = load ptr, ptr %l39, !tbaa !29
  %t57 = load i32, ptr %l43, !tbaa !23
  %t58 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s0, ptr %t56, i32 %t57)
  store { i64, ptr } %t58, ptr %l44
  br label %bb16
bb16:
  %t59 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t60 = extractvalue { i64, ptr } %t59, 0
  %t62 = icmp sgt i64 %t60, 0
  store i1 %t62, ptr %l37, !tbaa !21
  br label %bb17
bb17:
  %t64 = load i1, ptr %l37, !tbaa !21
  store i1 %t64, ptr %l3, !tbaa !21
  %t65 = load i1, ptr %l3, !tbaa !21
  br i1 %t65, label %bb18, label %bb19
bb18:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/generic:Program", ptr %t67, i32 0, i32 59
  %t70 = load i64, ptr %t69, !tbaa !24
  %t71 = load i64, ptr @G_2ecompiler_2fgeneric_2eMaxChain, !tbaa !24
  %t74 = icmp sge i64 %t70, %t71
  store i1 %t74, ptr %l48, !tbaa !21
  br label %bb20
bb19:
  store i1 false, ptr %l48, !tbaa !21
  br label %bb20
bb20:
  %t76 = load i1, ptr %l48, !tbaa !21
  br i1 %t76, label %bb21, label %bb22
bb21:
  %t77 = load ptr, ptr %l0, !tbaa !29
  store ptr %t77, ptr %l53, !tbaa !29
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t80 = getelementptr %"compiler/generic:Program", ptr %t78, i32 0, i32 2
  %t81 = load i32, ptr %l1, !tbaa !23
  %t84 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t80, i32 %t81)
  store i32 %t84, ptr %l57
  br label %bb23
bb22:
  br label %bb26
bb23:
  %t85 = load ptr, ptr %l53, !tbaa !29
  %t86 = load i32, ptr %l57, !tbaa !23
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eunbounded(ptr %v0, ptr %t85, i32 %t86)
  br label %bb24
bb24:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr %"compiler/generic:Program", ptr %t87, i32 0, i32 2
  %t90 = load i32, ptr %l1, !tbaa !23
  %t91 = load i64, ptr @G_2ecompiler_2ftypes_2eNoLayout, !tbaa !24
  call void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSetLayoutState(ptr %v0, ptr %t89, i32 %t90, i64 %t91)
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb26:
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"compiler/generic:Program", ptr %t96, i32 0, i32 2
  %t99 = load i32, ptr %l1, !tbaa !23
  %t100 = load i64, ptr @G_2ecompiler_2ftypes_2eLayingOut, !tbaa !24
  call void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSetLayoutState(ptr %v0, ptr %t98, i32 %t99, i64 %t100)
  br label %bb27
bb27:
  %t104 = load i1, ptr %l3, !tbaa !21
  br i1 %t104, label %bb28, label %bb29
bb28:
  %t106 = load ptr, ptr %l0, !tbaa !29
  store ptr %t106, ptr %l68, !tbaa !29
  %t107 = load ptr, ptr %l68, !tbaa !29
  %t108 = getelementptr %"compiler/generic:Program", ptr %t107, i32 0, i32 59
  %t109 = load i64, ptr %t108, !tbaa !24
  %t112 = add i64 %t109, 1
  %t114 = load ptr, ptr %l68, !tbaa !29
  %t115 = getelementptr %"compiler/generic:Program", ptr %t114, i32 0, i32 59
  store i64 %t112, ptr %t115, !tbaa !24
  br label %bb30
bb29:
  br label %bb30
bb30:
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t117 = load i32, ptr %l1, !tbaa !23
  %t120 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %t116, i32 %t117)
  store i1 %t120, ptr %l74
  br label %bb31
bb31:
  %t121 = load i1, ptr %l74, !tbaa !21
  store i1 %t121, ptr %l4, !tbaa !21
  %t122 = load i1, ptr %l4, !tbaa !21
  br i1 %t122, label %bb32, label %bb33
bb32:
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t125 = load i32, ptr %l1, !tbaa !23
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ereprReady(ptr %v0, ptr %t124, i32 %t125)
  br label %bb34
bb33:
  br label %bb35
bb34:
  br label %bb35
bb35:
  %t128 = load i1, ptr %l4, !tbaa !21
  br i1 %t128, label %bb36, label %bb37
bb36:
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t132 = getelementptr %"compiler/generic:Program", ptr %t130, i32 0, i32 2
  %t133 = load i32, ptr %l1, !tbaa !23
  %t136 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t132, i32 %t133)
  store i32 %t136, ptr %l83
  br label %bb38
bb37:
  store i1 false, ptr %l79, !tbaa !21
  br label %bb39
bb38:
  %t137 = load i32, ptr %l83, !range !{i32 0, i32 33}
  %t139 = trunc i64 20 to i32
  %t140 = icmp eq i32 %t137, %t139
  store i1 %t140, ptr %l79, !tbaa !21
  br label %bb39
bb39:
  %t142 = load i1, ptr %l79, !tbaa !21
  br i1 %t142, label %bb40, label %bb41
bb40:
  %t143 = load ptr, ptr %l0, !tbaa !29
  store ptr %t143, ptr %l86, !tbaa !29
  %t144 = load ptr, ptr %l0, !tbaa !29
  %t146 = getelementptr %"compiler/generic:Program", ptr %t144, i32 0, i32 2
  %t147 = load i32, ptr %l1, !tbaa !23
  %t150 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t146, i32 %t147)
  store i32 %t150, ptr %l90
  br label %bb42
bb41:
  br label %bb44
bb42:
  %t151 = load ptr, ptr %l86, !tbaa !29
  %t152 = load i32, ptr %l90, !tbaa !23
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ereprReady(ptr %v0, ptr %t151, i32 %t152)
  br label %bb43
bb43:
  br label %bb44
bb44:
  %t153 = load i1, ptr %l4, !tbaa !21
  br i1 %t153, label %bb45, label %bb46
bb45:
  store %olang.scope zeroinitializer, ptr %s9
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t157 = getelementptr %"compiler/generic:Program", ptr %t155, i32 0, i32 2
  %t158 = load i32, ptr %l1, !tbaa !23
  %t161 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eEmbedded(ptr %v0, ptr %s9, ptr %t157, i32 %t158)
  store { i64, ptr } %t161, ptr %l95
  br label %bb47
bb46:
  br label %bb58
bb47:
  %t162 = load { i64, ptr }, ptr %l95, !tbaa !27
  store { i64, ptr } %t162, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t164 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t166 = extractvalue { i64, ptr } %t164, 0
  store i64 %t166, ptr %l7, !tbaa !24
  br label %bb48
bb48:
  %t168 = load i64, ptr %l6, !tbaa !24
  %t169 = load i64, ptr %l7, !tbaa !24
  %t172 = icmp slt i64 %t168, %t169
  %t174 = xor i1 %t172, true
  br i1 %t174, label %bb49, label %bb50
bb49:
  br label %bb57
bb50:
  br label %bb51
bb51:
  %t176 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t176, ptr %l103, !tbaa !27
  %t177 = load i64, ptr %l6, !tbaa !24
  %t179 = getelementptr { i64, ptr }, ptr %l103, i32 0, i32 1
  %t180 = load ptr, ptr %t179, !tbaa !27
  %t181 = getelementptr i32, ptr %t180, i64 %t177
  %t182 = load i32, ptr %t181, !tbaa !33
  %t184 = load ptr, ptr %l0, !tbaa !29
  %t188 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eLayout(ptr %v0, ptr %t184, i32 %t182)
  store i1 %t188, ptr %l108
  br label %bb52
bb52:
  %t189 = load i1, ptr %l108, !tbaa !21
  %t190 = xor i1 %t189, true
  br i1 %t190, label %bb53, label %bb54
bb53:
  store i1 false, ptr %l4, !tbaa !21
  br label %bb55
bb54:
  br label %bb55
bb55:
  br label %bb56
bb56:
  %t192 = load i64, ptr %l6, !tbaa !24
  %t195 = add i64 %t192, 1
  store i64 %t195, ptr %l6, !tbaa !24
  br label %bb48
bb57:
  call void @__olang_scope_close(ptr %s9)
  br label %bb58
bb58:
  %t197 = load i1, ptr %l4, !tbaa !21
  br i1 %t197, label %bb59, label %bb60
bb59:
  %t199 = load ptr, ptr %l0, !tbaa !29
  %t201 = getelementptr %"compiler/generic:Program", ptr %t199, i32 0, i32 2
  %t202 = load i32, ptr %l1, !tbaa !23
  %t205 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePacked(ptr %v0, ptr %t201, i32 %t202)
  store i1 %t205, ptr %l118
  br label %bb61
bb60:
  store i1 false, ptr %l114, !tbaa !21
  br label %bb62
bb61:
  %t206 = load i1, ptr %l118, !tbaa !21
  store i1 %t206, ptr %l114, !tbaa !21
  br label %bb62
bb62:
  %t207 = load i1, ptr %l114, !tbaa !21
  br i1 %t207, label %bb63, label %bb64
bb63:
  %t208 = load ptr, ptr %l0, !tbaa !29
  %t210 = getelementptr %"compiler/generic:Program", ptr %t208, i32 0, i32 2
  store ptr %t210, ptr %l120, !tbaa !29
  %t211 = load ptr, ptr %l0, !tbaa !29
  %t213 = getelementptr %"compiler/generic:Program", ptr %t211, i32 0, i32 2
  %t214 = load i32, ptr %l1, !tbaa !23
  %t217 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t213, i32 %t214)
  store i32 %t217, ptr %l124
  br label %bb65
bb64:
  br label %bb74
bb65:
  %t218 = load ptr, ptr %l120, !tbaa !29
  %t219 = load i32, ptr %l124, !tbaa !23
  %t220 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t218, i32 %t219)
  store { i64, ptr } %t220, ptr %l125
  br label %bb66
bb66:
  %t221 = load { i64, ptr }, ptr %l125, !tbaa !27
  store { i64, ptr } %t221, ptr %l9, !tbaa !27
  store i64 0, ptr %l10, !tbaa !24
  %t222 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t224 = extractvalue { i64, ptr } %t222, 0
  store i64 %t224, ptr %l11, !tbaa !24
  br label %bb67
bb67:
  %t226 = load i64, ptr %l10, !tbaa !24
  %t227 = load i64, ptr %l11, !tbaa !24
  %t230 = icmp slt i64 %t226, %t227
  %t232 = xor i1 %t230, true
  br i1 %t232, label %bb68, label %bb69
bb68:
  br label %bb73
bb69:
  br label %bb70
bb70:
  %t234 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t234, ptr %l132, !tbaa !27
  %t235 = load i64, ptr %l10, !tbaa !24
  %t237 = getelementptr { i64, ptr }, ptr %l132, i32 0, i32 1
  %t238 = load ptr, ptr %t237, !tbaa !27
  %t239 = getelementptr i32, ptr %t238, i64 %t235
  %t240 = load i32, ptr %t239, !tbaa !33
  %t242 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2enoteRawType(ptr %v0, ptr %t242, i32 %t240)
  br label %bb71
bb71:
  br label %bb72
bb72:
  %t246 = load i64, ptr %l10, !tbaa !24
  %t249 = add i64 %t246, 1
  store i64 %t249, ptr %l10, !tbaa !24
  br label %bb67
bb73:
  br label %bb74
bb74:
  %t251 = load i1, ptr %l4, !tbaa !21
  br i1 %t251, label %bb75, label %bb76
bb75:
  %t253 = load ptr, ptr %l0, !tbaa !29
  %t255 = getelementptr %"compiler/generic:Program", ptr %t253, i32 0, i32 2
  %t256 = load i32, ptr %l1, !tbaa !23
  %t259 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eComputeLayout(ptr %v0, ptr %t255, i32 %t256)
  store i1 %t259, ptr %l144
  br label %bb77
bb76:
  br label %bb78
bb77:
  %t260 = load i1, ptr %l144, !tbaa !21
  store i1 %t260, ptr %l4, !tbaa !21
  br label %bb78
bb78:
  %t261 = load i1, ptr %l3, !tbaa !21
  br i1 %t261, label %bb79, label %bb80
bb79:
  %t263 = load ptr, ptr %l0, !tbaa !29
  store ptr %t263, ptr %l146, !tbaa !29
  %t264 = load ptr, ptr %l146, !tbaa !29
  %t265 = getelementptr %"compiler/generic:Program", ptr %t264, i32 0, i32 59
  %t266 = load i64, ptr %t265, !tbaa !24
  %t269 = sub i64 %t266, 1
  %t271 = load ptr, ptr %l146, !tbaa !29
  %t272 = getelementptr %"compiler/generic:Program", ptr %t271, i32 0, i32 59
  store i64 %t269, ptr %t272, !tbaa !24
  br label %bb81
bb80:
  br label %bb81
bb81:
  %t273 = load ptr, ptr %l0, !tbaa !29
  %t275 = getelementptr %"compiler/generic:Program", ptr %t273, i32 0, i32 2
  %t276 = load i32, ptr %l1, !tbaa !23
  %t279 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLayoutState(ptr %v0, ptr %t275, i32 %t276)
  store i64 %t279, ptr %l153
  br label %bb82
bb82:
  %t280 = load i64, ptr @G_2ecompiler_2ftypes_2eLayingOut, !tbaa !24
  %t281 = load i64, ptr %l153, !tbaa !24
  %t283 = icmp eq i64 %t281, %t280
  br i1 %t283, label %bb83, label %bb84
bb83:
  %t285 = load ptr, ptr %l0, !tbaa !29
  %t287 = getelementptr %"compiler/generic:Program", ptr %t285, i32 0, i32 2
  store ptr %t287, ptr %l157, !tbaa !29
  %t288 = load i32, ptr %l1, !tbaa !23
  store i32 %t288, ptr %l158, !tbaa !23
  %t289 = load i1, ptr %l4, !tbaa !21
  br i1 %t289, label %bb85, label %bb86
bb84:
  br label %bb89
bb85:
  %t291 = load i64, ptr @G_2ecompiler_2ftypes_2eLaidOut, !tbaa !24
  store i64 %t291, ptr %l160, !tbaa !24
  br label %bb87
bb86:
  %t293 = load i64, ptr @G_2ecompiler_2ftypes_2eNoLayout, !tbaa !24
  store i64 %t293, ptr %l160, !tbaa !24
  br label %bb87
bb87:
  %t295 = load ptr, ptr %l157, !tbaa !29
  %t296 = load i32, ptr %l158, !tbaa !23
  %t297 = load i64, ptr %l160, !tbaa !24
  call void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSetLayoutState(ptr %v0, ptr %t295, i32 %t296, i64 %t297)
  br label %bb88
bb88:
  br label %bb89
bb89:
  %t298 = load i1, ptr %l4, !tbaa !21
  call void @__olang_scope_close(ptr %s0)
  store i1 %t298, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMemberOf(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca i64
  %l14 = alloca i64
  %l18 = alloca ptr
  %l22 = alloca i32
  %l25 = alloca i32
  %l29 = alloca i32
  %l31 = alloca i32
  %l34 = alloca i64
  %l37 = alloca i64
  %l39 = alloca ptr
  %l43 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l44 = alloca i64
  %l45 = alloca i32
  %l51 = alloca i64
  %l53 = alloca i64
  %l58 = alloca i64
  %l62 = alloca %"compiler/generic:memberRow"
  %l69 = alloca %"compiler/generic:memberRow"
  %l74 = alloca ptr
  %l75 = alloca i32
  %l80 = alloca i32
  %l81 = alloca i1
  %l85 = alloca i1
  %l89 = alloca %"compiler/generic:memberRow"
  %l90 = alloca i64
  %l94 = alloca %"compiler/generic:memberRow"
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eallFns(ptr %v0, ptr %t1)
  br label %bb1
bb1:
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/generic:Program", ptr %t3, i32 0, i32 46
  %t7 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3amemberRow_3e_2eLe_Hffef742b46d9f4381d344302148f855f(ptr %v0, ptr %t5)
  store i64 %t7, ptr %l14
  br label %bb2
bb2:
  %t8 = load i64, ptr %l14, !tbaa !24
  %t9 = icmp eq i64 %t8, 0
  br i1 %t9, label %bb3, label %bb4
bb3:
  store i64 -1, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/generic:Program", ptr %t12, i32 0, i32 2
  store ptr %t14, ptr %l18, !tbaa !29
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/generic:Program", ptr %t15, i32 0, i32 2
  %t18 = load i32, ptr %l1, !tbaa !23
  %t21 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t17, i32 %t18)
  store i32 %t21, ptr %l22
  br label %bb6
bb6:
  %t22 = load i32, ptr %l22, !range !{i32 0, i32 33}
  %t24 = trunc i64 20 to i32
  %t25 = icmp eq i32 %t22, %t24
  br i1 %t25, label %bb7, label %bb8
bb7:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/generic:Program", ptr %t27, i32 0, i32 2
  %t30 = load i32, ptr %l1, !tbaa !23
  %t33 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t29, i32 %t30)
  store i32 %t33, ptr %l29
  br label %bb9
bb8:
  %t34 = load i32, ptr %l1, !tbaa !23
  store i32 %t34, ptr %l25, !tbaa !23
  br label %bb10
bb9:
  %t36 = load i32, ptr %l29, !tbaa !23
  store i32 %t36, ptr %l25, !tbaa !23
  br label %bb10
bb10:
  %t37 = load ptr, ptr %l18, !tbaa !29
  %t38 = load i32, ptr %l25, !tbaa !23
  %t39 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %t37, i32 %t38)
  store i32 %t39, ptr %l31
  br label %bb11
bb11:
  %t40 = load i32, ptr %l31, !tbaa !23
  store i32 %t40, ptr %l3, !tbaa !23
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t42 = load i32, ptr %l3, !tbaa !23
  %t45 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2etypeKey(ptr %v0, ptr %t41, i32 %t42)
  store i64 %t45, ptr %l34
  br label %bb12
bb12:
  %t46 = load i64, ptr %l34, !tbaa !24
  store i64 %t46, ptr %l4, !tbaa !24
  %t47 = load i64, ptr %l4, !tbaa !24
  %t49 = icmp sge i64 %t47, 0
  br i1 %t49, label %bb13, label %bb14
bb13:
  store %olang.scope zeroinitializer, ptr %s2
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = getelementptr %"compiler/generic:Program", ptr %t51, i32 0, i32 47
  store ptr %t53, ptr %l39, !tbaa !29
  %t54 = load i64, ptr %l4, !tbaa !24
  %t55 = load i32, ptr %l2, !tbaa !23
  %t57 = sext i32 %t55 to i64
  %t60 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s2, i64 %t54, i64 %t57)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t60, ptr %l43
  br label %bb15
bb14:
  br label %bb23
bb15:
  %t61 = load ptr, ptr %l39, !tbaa !29
  %t62 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l43
  %t63 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H5696e1a008d256bf9453cde2b49c6c45(ptr %v0, ptr %t61, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t62)
  %t64 = extractvalue { i32, i64 } %t63, 1
  %t65 = extractvalue { i32, i64 } %t63, 0
  store i32 %t65, ptr %l45
  %t66 = icmp ne i32 %t65, 0
  br i1 %t66, label %bb17, label %ok.67, !prof !99
ok.67:
  store i64 %t64, ptr %l44
  br label %bb16
bb16:
  %t68 = load i64, ptr %l44, !tbaa !24
  store i64 %t68, ptr %l37, !tbaa !24
  br label %bb19
bb17:
  br label %bb18
bb18:
  store i64 -1, ptr %l37, !tbaa !24
  br label %bb19
bb19:
  %t69 = load i64, ptr %l37, !tbaa !24
  store i64 %t69, ptr %l5, !tbaa !24
  %t70 = load i64, ptr %l5, !tbaa !24
  %t72 = icmp sge i64 %t70, 0
  br i1 %t72, label %bb20, label %bb21
bb20:
  %t74 = load i64, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  store i64 %t74, ptr %rv
  br label %ret
bb21:
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s2)
  br label %bb23
bb23:
  store i64 -1, ptr %l6, !tbaa !24
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"compiler/generic:Program", ptr %t76, i32 0, i32 49
  store ptr %t78, ptr %l7, !tbaa !29
  store i64 0, ptr %l8, !tbaa !24
  br label %bb24
bb24:
  store %olang.scope zeroinitializer, ptr %s5
  %t80 = load i64, ptr %l8, !tbaa !24
  store i64 %t80, ptr %l51, !tbaa !24
  %t81 = load ptr, ptr %l7, !tbaa !29
  %t83 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t81)
  store i64 %t83, ptr %l53
  br label %bb25
bb25:
  %t84 = load i64, ptr %l51, !tbaa !24
  %t85 = load i64, ptr %l53, !tbaa !24
  %t86 = icmp slt i64 %t84, %t85
  %t88 = xor i1 %t86, true
  br i1 %t88, label %bb26, label %bb27
bb26:
  call void @__olang_scope_close(ptr %s5)
  br label %bb52
bb27:
  br label %bb28
bb28:
  %t90 = load ptr, ptr %l7, !tbaa !29
  %t91 = load i64, ptr %l8, !tbaa !24
  %t94 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t90, i64 %t91)
  store i64 %t94, ptr %l58
  br label %bb29
bb29:
  %t95 = load i64, ptr %l58, !tbaa !24
  store i64 %t95, ptr %l9, !tbaa !24
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"compiler/generic:Program", ptr %t96, i32 0, i32 46
  %t99 = load i64, ptr %l9, !tbaa !24
  %t102 = call %"compiler/generic:memberRow" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3amemberRow_3e_2eAt_H0818468919c31b926123191f6718935b(ptr %v0, ptr %s5, ptr %t98, i64 %t99)
  store %"compiler/generic:memberRow" %t102, ptr %l62
  br label %bb30
bb30:
  %t103 = getelementptr %"compiler/generic:memberRow", ptr %l62, i32 0, i32 3
  %t104 = load i32, ptr %t103, !tbaa !23
  %t105 = load i32, ptr %l2, !tbaa !23
  %t108 = icmp ne i32 %t104, %t105
  br i1 %t108, label %bb31, label %bb32
bb31:
  call void @__olang_scope_close(ptr %s5)
  br label %bb51
bb32:
  br label %bb33
bb33:
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t112 = getelementptr %"compiler/generic:Program", ptr %t110, i32 0, i32 46
  %t113 = load i64, ptr %l9, !tbaa !24
  %t116 = call %"compiler/generic:memberRow" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3amemberRow_3e_2eAt_H0818468919c31b926123191f6718935b(ptr %v0, ptr %s5, ptr %t112, i64 %t113)
  store %"compiler/generic:memberRow" %t116, ptr %l69
  br label %bb34
bb34:
  %t117 = getelementptr %"compiler/generic:memberRow", ptr %l69, i32 0, i32 7
  %t118 = load i64, ptr %t117, !tbaa !24
  %t119 = shl i64 1, 40
  %t121 = sub i64 %t119, 1
  %t124 = and i64 %t118, %t121
  %t126 = load ptr, ptr %l0, !tbaa !29
  store ptr %t126, ptr %l74, !tbaa !29
  %t127 = load i32, ptr %l3, !tbaa !23
  store i32 %t127, ptr %l75, !tbaa !23
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t131 = trunc i64 %t124 to i32
  %t135 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSelfType(ptr %v0, ptr %t128, i32 %t131)
  store i32 %t135, ptr %l80
  br label %bb35
bb35:
  %t136 = load ptr, ptr %l74, !tbaa !29
  %t137 = load i32, ptr %l75, !tbaa !23
  %t138 = load i32, ptr %l80, !tbaa !23
  %t139 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ereachesDefault(ptr %v0, ptr %t136, i32 %t137, i32 %t138)
  store i1 %t139, ptr %l81
  br label %bb36
bb36:
  %t140 = load i1, ptr %l81, !tbaa !21
  %t141 = xor i1 %t140, true
  br i1 %t141, label %bb37, label %bb38
bb37:
  call void @__olang_scope_close(ptr %s5)
  br label %bb51
bb38:
  br label %bb39
bb39:
  %t143 = load i64, ptr %l6, !tbaa !24
  %t145 = icmp sge i64 %t143, 0
  br i1 %t145, label %bb40, label %bb41
bb40:
  %t147 = load ptr, ptr %l0, !tbaa !29
  %t149 = getelementptr %"compiler/generic:Program", ptr %t147, i32 0, i32 46
  %t150 = load i64, ptr %l6, !tbaa !24
  %t153 = call %"compiler/generic:memberRow" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3amemberRow_3e_2eAt_H0818468919c31b926123191f6718935b(ptr %v0, ptr %s5, ptr %t149, i64 %t150)
  store %"compiler/generic:memberRow" %t153, ptr %l89
  br label %bb42
bb41:
  store i1 false, ptr %l85, !tbaa !21
  br label %bb44
bb42:
  %t154 = getelementptr %"compiler/generic:memberRow", ptr %l89, i32 0, i32 7
  %t155 = load i64, ptr %t154, !tbaa !24
  store i64 %t155, ptr %l90, !tbaa !24
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t158 = getelementptr %"compiler/generic:Program", ptr %t156, i32 0, i32 46
  %t159 = load i64, ptr %l9, !tbaa !24
  %t162 = call %"compiler/generic:memberRow" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3amemberRow_3e_2eAt_H0818468919c31b926123191f6718935b(ptr %v0, ptr %s5, ptr %t158, i64 %t159)
  store %"compiler/generic:memberRow" %t162, ptr %l94
  br label %bb43
bb43:
  %t163 = getelementptr %"compiler/generic:memberRow", ptr %l94, i32 0, i32 7
  %t164 = load i64, ptr %t163, !tbaa !24
  %t165 = load i64, ptr %l90, !tbaa !24
  %t167 = icmp ne i64 %t165, %t164
  store i1 %t167, ptr %l85, !tbaa !21
  br label %bb44
bb44:
  %t169 = load i1, ptr %l85, !tbaa !21
  br i1 %t169, label %bb45, label %bb46
bb45:
  call void @__olang_scope_close(ptr %s5)
  store i64 -2, ptr %rv
  br label %ret
bb46:
  br label %bb47
bb47:
  %t171 = load i64, ptr %l6, !tbaa !24
  %t173 = icmp slt i64 %t171, 0
  br i1 %t173, label %bb48, label %bb49
bb48:
  %t175 = load i64, ptr %l9, !tbaa !24
  store i64 %t175, ptr %l6, !tbaa !24
  br label %bb50
bb49:
  br label %bb50
bb50:
  call void @__olang_scope_close(ptr %s5)
  br label %bb51
bb51:
  %t177 = load i64, ptr %l8, !tbaa !24
  %t180 = add i64 %t177, 1
  store i64 %t180, ptr %l8, !tbaa !24
  br label %bb24
bb52:
  %t182 = load i64, ptr %l6, !tbaa !24
  store i64 %t182, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local %"compiler/generic:Unmet" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMissing(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i1 %a3, i64 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i1
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l9 = alloca %"compiler/generic:Unmet"
  %l10 = alloca i32
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l15 = alloca i32
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l18 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca ptr
  %l25 = alloca i32
  %l26 = alloca %"compiler/generic:Unmet"
  %l27 = alloca { i64, ptr }
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca ptr
  %l31 = alloca i1
  %l32 = alloca i32
  %l33 = alloca i1
  %l36 = alloca %"compiler/generic:Unmet"
  %l40 = alloca i32
  %l44 = alloca ptr
  %l48 = alloca i32
  %l49 = alloca { i64, ptr }
  %l56 = alloca { i64, ptr }
  %l65 = alloca %"compiler/generic:Unmet"
  %l72 = alloca %"compiler/generic:Unmet"
  %l76 = alloca i32
  %l81 = alloca %"compiler/generic:Unmet"
  %l85 = alloca i32
  %l88 = alloca i32
  %l92 = alloca i32
  %l97 = alloca i32
  %l100 = alloca ptr
  %l104 = alloca i32
  %l105 = alloca { i64, ptr }
  %l113 = alloca { i64, ptr }
  %l120 = alloca i1
  %l121 = alloca %"compiler/generic:Unmet"
  %l126 = alloca %"compiler/generic:Unmet"
  %l130 = alloca i32
  %l133 = alloca ptr
  %l136 = alloca i1
  %l141 = alloca %"compiler/generic:Unmet"
  %l144 = alloca ptr
  %l145 = alloca i1
  %l155 = alloca i1
  %l159 = alloca i1
  %l163 = alloca i1
  %l166 = alloca %"compiler/generic:Unmet"
  %l174 = alloca { i64, ptr }
  %l177 = alloca ptr
  %l178 = alloca ptr
  %l181 = alloca %"compiler/generic:Context"
  %l185 = alloca i32
  %l187 = alloca i64
  %l191 = alloca i32
  %l192 = alloca i32
  %l196 = alloca i32
  %l200 = alloca i1
  %l210 = alloca %"compiler/generic:Unmet"
  %l224 = alloca { i64, ptr }
  %l228 = alloca i1
  %l229 = alloca ptr
  %l230 = alloca i32
  %l234 = alloca i32
  %l236 = alloca i1
  %l240 = alloca %"compiler/generic:Unmet"
  %l241 = alloca ptr
  %l242 = alloca i32
  %l243 = alloca i32
  %l247 = alloca i32
  %l249 = alloca i1
  %l253 = alloca { i64, ptr }
  %l254 = alloca i1
  %l259 = alloca i32
  %l262 = alloca i32
  %l266 = alloca i32
  %l271 = alloca i32
  %l275 = alloca i1
  %l276 = alloca ptr
  %l280 = alloca i32
  %l281 = alloca i64
  %l284 = alloca i64
  %l286 = alloca i32
  %l288 = alloca i32
  %l290 = alloca i1
  %l292 = alloca %"compiler/generic:Unmet"
  %l296 = alloca %"compiler/generic:Unmet"
  %l298 = alloca %"compiler/generic:Unmet"
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %s27 = alloca %olang.scope
  %rv = alloca %"compiler/generic:Unmet"
  %t300 = alloca %"compiler/generic:Context", align 8
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  store i1 %a3, ptr %l3
  store i64 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l4, !tbaa !24
  %t3 = icmp sgt i64 %t1, 32
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call %"compiler/generic:Unmet" @compiler_2fgeneric_2eUnmet_2emet()
  store %"compiler/generic:Unmet" %t5, ptr %l36
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t6 = load %"compiler/generic:Unmet", ptr %l36
  store %"compiler/generic:Unmet" %t6, ptr %rv
  br label %ret
bb4:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/generic:Program", ptr %t7, i32 0, i32 2
  %t10 = load i32, ptr %l2, !tbaa !23
  %t13 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t9, i32 %t10)
  store i32 %t13, ptr %l40
  br label %bb5
bb5:
  %t14 = load i32, ptr %l40, !range !{i32 0, i32 33}
  %t16 = trunc i64 22 to i32
  %t17 = icmp eq i32 %t14, %t16
  br i1 %t17, label %bb6, label %bb7
bb6:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/generic:Program", ptr %t19, i32 0, i32 2
  store ptr %t21, ptr %l44, !tbaa !29
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/generic:Program", ptr %t22, i32 0, i32 2
  %t25 = load i32, ptr %l2, !tbaa !23
  %t28 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t24, i32 %t25)
  store i32 %t28, ptr %l48
  br label %bb8
bb7:
  br label %bb21
bb8:
  %t29 = load ptr, ptr %l44, !tbaa !29
  %t30 = load i32, ptr %l48, !tbaa !23
  %t31 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t29, i32 %t30)
  store { i64, ptr } %t31, ptr %l49
  br label %bb9
bb9:
  %t32 = load { i64, ptr }, ptr %l49, !tbaa !27
  store { i64, ptr } %t32, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t33 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t35 = extractvalue { i64, ptr } %t33, 0
  store i64 %t35, ptr %l7, !tbaa !24
  br label %bb10
bb10:
  %t37 = load i64, ptr %l6, !tbaa !24
  %t38 = load i64, ptr %l7, !tbaa !24
  %t41 = icmp slt i64 %t37, %t38
  %t43 = xor i1 %t41, true
  br i1 %t43, label %bb11, label %bb12
bb11:
  br label %bb19
bb12:
  br label %bb13
bb13:
  %t45 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t45, ptr %l56, !tbaa !27
  %t46 = load i64, ptr %l6, !tbaa !24
  %t48 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !27
  %t50 = getelementptr i32, ptr %t49, i64 %t46
  %t51 = load i32, ptr %t50, !tbaa !33
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t54 = load i32, ptr %l1, !tbaa !23
  %t56 = load i1, ptr %l3, !tbaa !21
  %t57 = load i64, ptr %l4, !tbaa !24
  %t59 = add i64 %t57, 1
  %t65 = call %"compiler/generic:Unmet" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMissing(ptr %v0, ptr %t53, i32 %t54, i32 %t51, i1 %t56, i64 %t59)
  store %"compiler/generic:Unmet" %t65, ptr %l65
  br label %bb14
bb14:
  %t66 = load %"compiler/generic:Unmet", ptr %l65
  store %"compiler/generic:Unmet" %t66, ptr %l9
  %t67 = getelementptr %"compiler/generic:Unmet", ptr %l9, i32 0, i32 0
  %t68 = load i64, ptr %t67, !tbaa !24
  %t70 = icmp sge i64 %t68, 0
  br i1 %t70, label %bb15, label %bb16
bb15:
  %t72 = load %"compiler/generic:Unmet", ptr %l9
  store %"compiler/generic:Unmet" %t72, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  br label %bb18
bb18:
  %t74 = load i64, ptr %l6, !tbaa !24
  %t77 = add i64 %t74, 1
  store i64 %t77, ptr %l6, !tbaa !24
  br label %bb10
bb19:
  %t79 = call %"compiler/generic:Unmet" @compiler_2fgeneric_2eUnmet_2emet()
  store %"compiler/generic:Unmet" %t79, ptr %l72
  br label %bb20
bb20:
  %t80 = load %"compiler/generic:Unmet", ptr %l72
  store %"compiler/generic:Unmet" %t80, ptr %rv
  br label %ret
bb21:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"compiler/generic:Program", ptr %t81, i32 0, i32 2
  %t84 = load i32, ptr %l2, !tbaa !23
  %t87 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t83, i32 %t84)
  store i32 %t87, ptr %l76
  br label %bb22
bb22:
  %t88 = load i32, ptr %l76, !range !{i32 0, i32 33}
  %t90 = trunc i64 18 to i32
  %t91 = icmp eq i32 %t88, %t90
  %t93 = xor i1 %t91, true
  br i1 %t93, label %bb23, label %bb24
bb23:
  store %olang.scope zeroinitializer, ptr %s7
  %t95 = load i32, ptr %l2, !tbaa !23
  %t97 = call %"compiler/generic:Unmet" @compiler_2fgeneric_3aUnmet_2ector(ptr %s7, i64 0, i32 %t95, i32 0, i1 false, i1 false, i1 false)
  store %"compiler/generic:Unmet" %t97, ptr %l81
  br label %bb25
bb24:
  br label %bb26
bb25:
  call void @__olang_scope_close(ptr %s7)
  %t98 = load %"compiler/generic:Unmet", ptr %l81
  store %"compiler/generic:Unmet" %t98, ptr %rv
  br label %ret
bb26:
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = getelementptr %"compiler/generic:Program", ptr %t99, i32 0, i32 2
  %t102 = load i32, ptr %l1, !tbaa !23
  %t105 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t101, i32 %t102)
  store i32 %t105, ptr %l85
  br label %bb27
bb27:
  %t106 = load i32, ptr %l85, !range !{i32 0, i32 33}
  %t108 = trunc i64 20 to i32
  %t109 = icmp eq i32 %t106, %t108
  br i1 %t109, label %bb28, label %bb29
bb28:
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t113 = getelementptr %"compiler/generic:Program", ptr %t111, i32 0, i32 2
  %t114 = load i32, ptr %l1, !tbaa !23
  %t117 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t113, i32 %t114)
  store i32 %t117, ptr %l92
  br label %bb30
bb29:
  %t118 = load i32, ptr %l1, !tbaa !23
  store i32 %t118, ptr %l88, !tbaa !23
  br label %bb31
bb30:
  %t120 = load i32, ptr %l92, !tbaa !23
  store i32 %t120, ptr %l88, !tbaa !23
  br label %bb31
bb31:
  %t121 = load i32, ptr %l88, !tbaa !23
  store i32 %t121, ptr %l10, !tbaa !23
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t124 = getelementptr %"compiler/generic:Program", ptr %t122, i32 0, i32 2
  %t125 = load i32, ptr %l10, !tbaa !23
  %t128 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t124, i32 %t125)
  store i32 %t128, ptr %l97
  br label %bb32
bb32:
  %t129 = load i32, ptr %l97, !range !{i32 0, i32 33}
  %t131 = trunc i64 29 to i32
  %t132 = icmp eq i32 %t129, %t131
  br i1 %t132, label %bb33, label %bb34
bb33:
  store %olang.scope zeroinitializer, ptr %s8
  store %olang.scope zeroinitializer, ptr %s9
  %t134 = load ptr, ptr %l0, !tbaa !29
  store ptr %t134, ptr %l100, !tbaa !29
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t137 = getelementptr %"compiler/generic:Program", ptr %t135, i32 0, i32 2
  %t138 = load i32, ptr %l10, !tbaa !23
  %t141 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAnyTrait(ptr %v0, ptr %t137, i32 %t138)
  store i32 %t141, ptr %l104
  br label %bb35
bb34:
  br label %bb49
bb35:
  %t142 = load ptr, ptr %l100, !tbaa !29
  %t143 = load i32, ptr %l104, !tbaa !23
  %t144 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAnyCovers(ptr %v0, ptr %s9, ptr %t142, i32 %t143)
  store { i64, ptr } %t144, ptr %l105
  br label %bb36
bb36:
  %t145 = load { i64, ptr }, ptr %l105, !tbaa !27
  store { i64, ptr } %t145, ptr %l11, !tbaa !27
  store i64 0, ptr %l12, !tbaa !24
  %t147 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t149 = extractvalue { i64, ptr } %t147, 0
  store i64 %t149, ptr %l13, !tbaa !24
  br label %bb37
bb37:
  %t151 = load i64, ptr %l12, !tbaa !24
  %t152 = load i64, ptr %l13, !tbaa !24
  %t155 = icmp slt i64 %t151, %t152
  %t157 = xor i1 %t155, true
  br i1 %t157, label %bb38, label %bb39
bb38:
  br label %bb47
bb39:
  br label %bb40
bb40:
  %t159 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t159, ptr %l113, !tbaa !27
  %t160 = load i64, ptr %l12, !tbaa !24
  %t162 = getelementptr { i64, ptr }, ptr %l113, i32 0, i32 1
  %t163 = load ptr, ptr %t162, !tbaa !27
  %t164 = getelementptr i32, ptr %t163, i64 %t160
  %t165 = load i32, ptr %t164, !tbaa !33
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t169 = getelementptr %"compiler/generic:Program", ptr %t167, i32 0, i32 2
  %t171 = load i32, ptr %l2, !tbaa !23
  %t175 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t169, i32 %t165, i32 %t171)
  store i1 %t175, ptr %l120
  br label %bb41
bb41:
  %t176 = load i1, ptr %l120, !tbaa !21
  br i1 %t176, label %bb42, label %bb43
bb42:
  %t177 = call %"compiler/generic:Unmet" @compiler_2fgeneric_2eUnmet_2emet()
  store %"compiler/generic:Unmet" %t177, ptr %l121
  br label %bb44
bb43:
  br label %bb45
bb44:
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s8)
  %t178 = load %"compiler/generic:Unmet", ptr %l121
  store %"compiler/generic:Unmet" %t178, ptr %rv
  br label %ret
bb45:
  br label %bb46
bb46:
  %t179 = load i64, ptr %l12, !tbaa !24
  %t182 = add i64 %t179, 1
  store i64 %t182, ptr %l12, !tbaa !24
  br label %bb37
bb47:
  call void @__olang_scope_close(ptr %s9)
  %t184 = load i32, ptr %l2, !tbaa !23
  %t186 = call %"compiler/generic:Unmet" @compiler_2fgeneric_3aUnmet_2ector(ptr %s8, i64 0, i32 %t184, i32 0, i1 false, i1 false, i1 false)
  store %"compiler/generic:Unmet" %t186, ptr %l126
  br label %bb48
bb48:
  call void @__olang_scope_close(ptr %s8)
  %t187 = load %"compiler/generic:Unmet", ptr %l126
  store %"compiler/generic:Unmet" %t187, ptr %rv
  br label %ret
bb49:
  %t188 = load ptr, ptr %l0, !tbaa !29
  %t190 = getelementptr %"compiler/generic:Program", ptr %t188, i32 0, i32 2
  %t191 = load i32, ptr %l2, !tbaa !23
  %t194 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t190, i32 %t191)
  store i32 %t194, ptr %l130
  br label %bb50
bb50:
  %t195 = load i32, ptr %l130, !tbaa !23
  store i32 %t195, ptr %l15, !tbaa !23
  %t196 = load ptr, ptr %l0, !tbaa !29
  %t197 = load i32, ptr %l15, !tbaa !23
  %t200 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2etypeDecl(ptr %v0, ptr %v0, ptr %t196, i32 %t197)
  store ptr %t200, ptr %l133
  br label %bb51
bb51:
  %t201 = load ptr, ptr %l133, !tbaa !29
  store ptr %t201, ptr %l16, !tbaa !29
  %t202 = load ptr, ptr %l16, !tbaa !29
  %t204 = icmp eq ptr %t202, null
  br i1 %t204, label %bb52, label %bb53
bb52:
  store i1 true, ptr %l136, !tbaa !21
  br label %bb54
bb53:
  %t206 = load ptr, ptr %l16, !tbaa !29
  %t208 = getelementptr %"compiler/ast:TypeDecl", ptr %t206, i32 0, i32 3
  %t209 = load ptr, ptr %t208, !tbaa !29
  %t211 = icmp eq ptr %t209, null
  store i1 %t211, ptr %l136, !tbaa !21
  br label %bb54
bb54:
  %t213 = load i1, ptr %l136, !tbaa !21
  br i1 %t213, label %bb55, label %bb56
bb55:
  store %olang.scope zeroinitializer, ptr %s13
  %t214 = load i32, ptr %l2, !tbaa !23
  %t216 = call %"compiler/generic:Unmet" @compiler_2fgeneric_3aUnmet_2ector(ptr %s13, i64 0, i32 %t214, i32 0, i1 false, i1 false, i1 false)
  store %"compiler/generic:Unmet" %t216, ptr %l141
  br label %bb57
bb56:
  br label %bb58
bb57:
  call void @__olang_scope_close(ptr %s13)
  %t217 = load %"compiler/generic:Unmet", ptr %l141
  store %"compiler/generic:Unmet" %t217, ptr %rv
  br label %ret
bb58:
  %t218 = load ptr, ptr %l16, !tbaa !29
  %t220 = getelementptr %"compiler/ast:TypeDecl", ptr %t218, i32 0, i32 3
  %t221 = load ptr, ptr %t220, !tbaa !29
  store ptr %t221, ptr %l17, !tbaa !29
  %t223 = load ptr, ptr %l17, !tbaa !29
  store ptr %t223, ptr %l144, !tbaa !29
  store i1 false, ptr %l145, !tbaa !21
  %t224 = load ptr, ptr %l144, !tbaa !29
  %t225 = icmp ne ptr %t224, null
  br i1 %t225, label %bb59, label %bb60
bb59:
  %t227 = load ptr, ptr %l144, !tbaa !29
  %t228 = load i64, ptr %t227, !range !{i64 0, i64 5}
  %t230 = icmp eq i64 %t228, 2
  store i1 %t230, ptr %l145, !tbaa !21
  br label %bb60
bb60:
  %t231 = load i1, ptr %l145, !tbaa !21
  br i1 %t231, label %bb61, label %bb62
bb61:
  %t232 = load ptr, ptr %l17, !tbaa !29
  %t234 = getelementptr { i64, [6 x i64] }, ptr %t232, i32 0, i32 1
  %t235 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr } }, ptr %t234, i32 0, i32 0
  %t236 = load { i64, ptr }, ptr %t235
  store { i64, ptr } %t236, ptr %l18, !tbaa !27
  %t238 = load ptr, ptr %l17, !tbaa !29
  %t240 = getelementptr { i64, [6 x i64] }, ptr %t238, i32 0, i32 1
  %t241 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr } }, ptr %t240, i32 0, i32 1
  %t242 = load { i64, ptr }, ptr %t241
  store { i64, ptr } %t242, ptr %l19, !tbaa !27
  %t244 = load ptr, ptr %l17, !tbaa !29
  %t246 = getelementptr { i64, [6 x i64] }, ptr %t244, i32 0, i32 1
  %t247 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr } }, ptr %t246, i32 0, i32 2
  %t248 = load { i64, ptr }, ptr %t247
  store { i64, ptr } %t248, ptr %l20, !tbaa !27
  br label %bb63
bb62:
  br label %bb137
bb63:
  %t250 = load i1, ptr %l3, !tbaa !21
  br i1 %t250, label %bb64, label %bb65
bb64:
  %t252 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t254 = extractvalue { i64, ptr } %t252, 0
  %t256 = icmp sgt i64 %t254, 0
  store i1 %t256, ptr %l155, !tbaa !21
  br label %bb66
bb65:
  store i1 false, ptr %l155, !tbaa !21
  br label %bb66
bb66:
  %t258 = load i1, ptr %l155, !tbaa !21
  br i1 %t258, label %bb67, label %bb68
bb67:
  %t259 = load ptr, ptr %l0, !tbaa !29
  %t260 = load i32, ptr %l1, !tbaa !23
  %t261 = load i32, ptr %l2, !tbaa !23
  %t265 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMember(ptr %v0, ptr %t259, i32 %t260, i32 %t261)
  store i1 %t265, ptr %l163
  br label %bb69
bb68:
  store i1 false, ptr %l159, !tbaa !21
  br label %bb70
bb69:
  %t266 = load i1, ptr %l163, !tbaa !21
  %t267 = xor i1 %t266, true
  store i1 %t267, ptr %l159, !tbaa !21
  br label %bb70
bb70:
  %t269 = load i1, ptr %l159, !tbaa !21
  br i1 %t269, label %bb71, label %bb72
bb71:
  store %olang.scope zeroinitializer, ptr %s15
  %t270 = load i32, ptr %l2, !tbaa !23
  %t272 = call %"compiler/generic:Unmet" @compiler_2fgeneric_3aUnmet_2ector(ptr %s15, i64 0, i32 %t270, i32 0, i1 false, i1 false, i1 true)
  store %"compiler/generic:Unmet" %t272, ptr %l166
  br label %bb73
bb72:
  br label %bb74
bb73:
  call void @__olang_scope_close(ptr %s15)
  %t273 = load %"compiler/generic:Unmet", ptr %l166
  store %"compiler/generic:Unmet" %t273, ptr %rv
  br label %ret
bb74:
  %t274 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t274, ptr %l21, !tbaa !27
  store i64 0, ptr %l22, !tbaa !24
  %t276 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t278 = extractvalue { i64, ptr } %t276, 0
  store i64 %t278, ptr %l23, !tbaa !24
  br label %bb75
bb75:
  store %olang.scope zeroinitializer, ptr %s17
  %t280 = load i64, ptr %l22, !tbaa !24
  %t281 = load i64, ptr %l23, !tbaa !24
  %t284 = icmp slt i64 %t280, %t281
  %t286 = xor i1 %t284, true
  br i1 %t286, label %bb76, label %bb77
bb76:
  call void @__olang_scope_close(ptr %s17)
  br label %bb96
bb77:
  br label %bb78
bb78:
  %t288 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t288, ptr %l174, !tbaa !27
  %t289 = load i64, ptr %l22, !tbaa !24
  %t291 = getelementptr { i64, ptr }, ptr %l174, i32 0, i32 1
  %t292 = load ptr, ptr %t291, !tbaa !27
  %t293 = getelementptr ptr, ptr %t292, i64 %t289
  %t294 = load ptr, ptr %t293, !tbaa !39
  store ptr %t294, ptr %l24, !tbaa !29
  %t296 = load ptr, ptr %l0, !tbaa !29
  store ptr %t296, ptr %l177, !tbaa !29
  %t297 = load ptr, ptr %l0, !tbaa !29
  store ptr %t297, ptr %l178, !tbaa !29
  %t298 = load ptr, ptr %l0, !tbaa !29
  %t299 = load i32, ptr %l15, !tbaa !23
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2edeclContext(ptr %t300, ptr %v0, ptr %s17, ptr %t298, i32 %t299)
  call void @llvm.memmove.p0.p0.i64(ptr %l181, ptr %t300, i64 160, i1 false)
  br label %bb79
bb79:
  %t303 = call ptr @__olang_scope_alloc_a(ptr %s17, i64 160, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t303, ptr %l181, i64 160, i1 false)
  %t304 = load ptr, ptr %l24, !tbaa !29
  %t306 = load ptr, ptr %l178, !tbaa !29
  %t309 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eResolve(ptr %v0, ptr %s17, ptr %v0, ptr %t306, ptr %t303, ptr %t304)
  store i32 %t309, ptr %l185
  br label %bb80
bb80:
  %t310 = load i32, ptr %l15, !tbaa !23
  %t312 = call i64 @compiler_2fgeneric_2eDeclOwner(i32 %t310)
  store i64 %t312, ptr %l187
  br label %bb81
bb81:
  %t313 = load ptr, ptr %l0, !tbaa !29
  %t315 = getelementptr %"compiler/generic:Program", ptr %t313, i32 0, i32 2
  %t316 = load i32, ptr %l2, !tbaa !23
  %t319 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %t315, i32 %t316)
  store i32 %t319, ptr %l191
  br label %bb82
bb82:
  %t320 = load ptr, ptr %l177, !tbaa !29
  %t321 = load i32, ptr %l185, !tbaa !23
  %t322 = load i64, ptr %l187, !tbaa !24
  %t323 = load i32, ptr %l191, !tbaa !23
  %t324 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSubst(ptr %v0, ptr %t320, i32 %t321, i64 %t322, i32 %t323)
  store i32 %t324, ptr %l192
  br label %bb83
bb83:
  %t325 = load i32, ptr %l192, !tbaa !23
  store i32 %t325, ptr %l25, !tbaa !23
  %t326 = load ptr, ptr %l0, !tbaa !29
  %t328 = getelementptr %"compiler/generic:Program", ptr %t326, i32 0, i32 2
  %t329 = load i32, ptr %l25, !tbaa !23
  %t332 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t328, i32 %t329)
  store i32 %t332, ptr %l196
  br label %bb84
bb84:
  %t333 = load i32, ptr %l196, !range !{i32 0, i32 33}
  %t335 = trunc i64 18 to i32
  %t336 = icmp eq i32 %t333, %t335
  %t338 = xor i1 %t336, true
  br i1 %t338, label %bb85, label %bb86
bb85:
  store i1 true, ptr %l200, !tbaa !21
  br label %bb87
bb86:
  %t340 = load i32, ptr %l25, !tbaa !23
  %t341 = load i32, ptr %l2, !tbaa !23
  %t344 = icmp eq i32 %t340, %t341
  store i1 %t344, ptr %l200, !tbaa !21
  br label %bb87
bb87:
  %t346 = load i1, ptr %l200, !tbaa !21
  br i1 %t346, label %bb88, label %bb89
bb88:
  call void @__olang_scope_close(ptr %s17)
  br label %bb95
bb89:
  br label %bb90
bb90:
  %t347 = load ptr, ptr %l0, !tbaa !29
  %t348 = load i32, ptr %l1, !tbaa !23
  %t349 = load i32, ptr %l25, !tbaa !23
  %t350 = load i1, ptr %l3, !tbaa !21
  %t351 = load i64, ptr %l4, !tbaa !24
  %t353 = add i64 %t351, 1
  %t359 = call %"compiler/generic:Unmet" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMissing(ptr %v0, ptr %t347, i32 %t348, i32 %t349, i1 %t350, i64 %t353)
  store %"compiler/generic:Unmet" %t359, ptr %l210
  br label %bb91
bb91:
  %t360 = load %"compiler/generic:Unmet", ptr %l210
  store %"compiler/generic:Unmet" %t360, ptr %l26
  %t361 = getelementptr %"compiler/generic:Unmet", ptr %l26, i32 0, i32 0
  %t362 = load i64, ptr %t361, !tbaa !24
  %t364 = icmp sge i64 %t362, 0
  br i1 %t364, label %bb92, label %bb93
bb92:
  %t366 = load %"compiler/generic:Unmet", ptr %l26
  call void @__olang_scope_close(ptr %s17)
  store %"compiler/generic:Unmet" %t366, ptr %rv
  br label %ret
bb93:
  br label %bb94
bb94:
  call void @__olang_scope_close(ptr %s17)
  br label %bb95
bb95:
  %t368 = load i64, ptr %l22, !tbaa !24
  %t371 = add i64 %t368, 1
  store i64 %t371, ptr %l22, !tbaa !24
  br label %bb75
bb96:
  %t373 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t373, ptr %l27, !tbaa !27
  store i64 0, ptr %l28, !tbaa !24
  %t375 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t377 = extractvalue { i64, ptr } %t375, 0
  store i64 %t377, ptr %l29, !tbaa !24
  br label %bb97
bb97:
  store %olang.scope zeroinitializer, ptr %s22
  %t379 = load i64, ptr %l28, !tbaa !24
  %t380 = load i64, ptr %l29, !tbaa !24
  %t383 = icmp slt i64 %t379, %t380
  %t385 = xor i1 %t383, true
  br i1 %t385, label %bb98, label %bb99
bb98:
  call void @__olang_scope_close(ptr %s22)
  br label %bb135
bb99:
  br label %bb100
bb100:
  %t387 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t387, ptr %l224, !tbaa !27
  %t388 = load i64, ptr %l28, !tbaa !24
  %t390 = getelementptr { i64, ptr }, ptr %l224, i32 0, i32 1
  %t391 = load ptr, ptr %t390, !tbaa !27
  %t392 = getelementptr ptr, ptr %t391, i64 %t388
  %t393 = load ptr, ptr %t392, !tbaa !39
  store ptr %t393, ptr %l30, !tbaa !29
  %t395 = load ptr, ptr %l30, !tbaa !29
  %t397 = call i1 @compiler_2fast_2ecompiler_2fast_3aFunc_2eIsBuilder(ptr %v0, ptr %t395)
  store i1 %t397, ptr %l228
  br label %bb101
bb101:
  %t398 = load i1, ptr %l228, !tbaa !21
  br i1 %t398, label %bb102, label %bb103
bb102:
  store %olang.scope zeroinitializer, ptr %s23
  %t399 = load ptr, ptr %l0, !tbaa !29
  store ptr %t399, ptr %l229, !tbaa !29
  %t400 = load i32, ptr %l15, !tbaa !23
  store i32 %t400, ptr %l230, !tbaa !23
  %t401 = load ptr, ptr %l0, !tbaa !29
  %t403 = getelementptr %"compiler/generic:Program", ptr %t401, i32 0, i32 2
  %t404 = load i32, ptr %l2, !tbaa !23
  %t407 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %t403, i32 %t404)
  store i32 %t407, ptr %l234
  br label %bb104
bb103:
  br label %bb110
bb104:
  %t408 = load ptr, ptr %l30, !tbaa !29
  %t409 = load ptr, ptr %l229, !tbaa !29
  %t410 = load i32, ptr %l230, !tbaa !23
  %t411 = load i32, ptr %l234, !tbaa !23
  %t413 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2emeetsBuilder(ptr %v0, ptr %v0, ptr %t409, i32 %t410, i32 %t411, ptr %t408)
  store i1 %t413, ptr %l236
  br label %bb105
bb105:
  %t414 = load i1, ptr %l236, !tbaa !21
  br i1 %t414, label %bb106, label %bb107
bb106:
  call void @__olang_scope_close(ptr %s23)
  call void @__olang_scope_close(ptr %s22)
  br label %bb134
bb107:
  br label %bb108
bb108:
  %t415 = load i32, ptr %l2, !tbaa !23
  %t416 = load ptr, ptr %l30, !tbaa !29
  %t418 = getelementptr %"compiler/ast:Func", ptr %t416, i32 0, i32 2
  %t419 = load i32, ptr %t418, !tbaa !23
  %t422 = call %"compiler/generic:Unmet" @compiler_2fgeneric_3aUnmet_2ector(ptr %s23, i64 0, i32 %t415, i32 %t419, i1 true, i1 false, i1 false)
  store %"compiler/generic:Unmet" %t422, ptr %l240
  br label %bb109
bb109:
  call void @__olang_scope_close(ptr %s23)
  call void @__olang_scope_close(ptr %s22)
  %t423 = load %"compiler/generic:Unmet", ptr %l240
  store %"compiler/generic:Unmet" %t423, ptr %rv
  br label %ret
bb110:
  %t424 = load ptr, ptr %l0, !tbaa !29
  store ptr %t424, ptr %l241, !tbaa !29
  %t425 = load i32, ptr %l1, !tbaa !23
  store i32 %t425, ptr %l242, !tbaa !23
  %t426 = load i32, ptr %l15, !tbaa !23
  store i32 %t426, ptr %l243, !tbaa !23
  %t427 = load ptr, ptr %l0, !tbaa !29
  %t429 = getelementptr %"compiler/generic:Program", ptr %t427, i32 0, i32 2
  %t430 = load i32, ptr %l2, !tbaa !23
  %t433 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %t429, i32 %t430)
  store i32 %t433, ptr %l247
  br label %bb111
bb111:
  %t434 = load ptr, ptr %l30, !tbaa !29
  %t435 = load ptr, ptr %l241, !tbaa !29
  %t436 = load i32, ptr %l242, !tbaa !23
  %t437 = load i32, ptr %l243, !tbaa !23
  %t438 = load i32, ptr %l247, !tbaa !23
  %t440 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2emeets(ptr %v0, ptr %v0, ptr %t435, i32 %t436, i32 %t437, i32 %t438, ptr %t434)
  store i1 %t440, ptr %l249
  br label %bb112
bb112:
  %t441 = load i1, ptr %l249, !tbaa !21
  br i1 %t441, label %bb113, label %bb114
bb113:
  call void @__olang_scope_close(ptr %s22)
  br label %bb134
bb114:
  br label %bb115
bb115:
  %t442 = load ptr, ptr %l0, !tbaa !29
  %t443 = load ptr, ptr %l30, !tbaa !29
  %t445 = getelementptr %"compiler/ast:Func", ptr %t443, i32 0, i32 2
  %t446 = load i32, ptr %t445, !tbaa !23
  %t449 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2etext(ptr %v0, ptr %v0, ptr %t442, i32 %t446)
  store { i64, ptr } %t449, ptr %l253
  br label %bb116
bb116:
  %t450 = load { i64, ptr }, ptr %l253, !tbaa !27
  %t451 = call i1 @compiler_2fload_2ePublic(ptr %v0, { i64, ptr } %t450)
  store i1 %t451, ptr %l254
  br label %bb117
bb117:
  %t452 = load i1, ptr %l254, !tbaa !21
  %t453 = xor i1 %t452, true
  store i1 %t453, ptr %l31, !tbaa !21
  %t455 = load ptr, ptr %l0, !tbaa !29
  %t457 = getelementptr %"compiler/generic:Program", ptr %t455, i32 0, i32 2
  %t458 = load i32, ptr %l1, !tbaa !23
  %t461 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t457, i32 %t458)
  store i32 %t461, ptr %l259
  br label %bb118
bb118:
  %t462 = load i32, ptr %l259, !range !{i32 0, i32 33}
  %t464 = trunc i64 20 to i32
  %t465 = icmp eq i32 %t462, %t464
  br i1 %t465, label %bb119, label %bb120
bb119:
  %t467 = load ptr, ptr %l0, !tbaa !29
  %t469 = getelementptr %"compiler/generic:Program", ptr %t467, i32 0, i32 2
  %t470 = load i32, ptr %l1, !tbaa !23
  %t473 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t469, i32 %t470)
  store i32 %t473, ptr %l266
  br label %bb121
bb120:
  %t474 = load i32, ptr %l1, !tbaa !23
  store i32 %t474, ptr %l262, !tbaa !23
  br label %bb122
bb121:
  %t476 = load i32, ptr %l266, !tbaa !23
  store i32 %t476, ptr %l262, !tbaa !23
  br label %bb122
bb122:
  %t477 = load i32, ptr %l262, !tbaa !23
  store i32 %t477, ptr %l32, !tbaa !23
  %t478 = load ptr, ptr %l0, !tbaa !29
  %t480 = getelementptr %"compiler/generic:Program", ptr %t478, i32 0, i32 2
  %t481 = load i32, ptr %l32, !tbaa !23
  %t484 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t480, i32 %t481)
  store i32 %t484, ptr %l271
  br label %bb123
bb123:
  %t485 = load i32, ptr %l271, !range !{i32 0, i32 33}
  %t487 = trunc i64 18 to i32
  %t488 = icmp eq i32 %t485, %t487
  %t490 = xor i1 %t488, true
  br i1 %t490, label %bb124, label %bb125
bb124:
  store i1 true, ptr %l275, !tbaa !21
  br label %bb129
bb125:
  %t492 = load ptr, ptr %l0, !tbaa !29
  store ptr %t492, ptr %l276, !tbaa !29
  %t493 = load ptr, ptr %l0, !tbaa !29
  %t495 = getelementptr %"compiler/generic:Program", ptr %t493, i32 0, i32 2
  %t496 = load i32, ptr %l32, !tbaa !23
  %t499 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t495, i32 %t496)
  store i32 %t499, ptr %l280
  br label %bb126
bb126:
  %t500 = load ptr, ptr %l276, !tbaa !29
  %t501 = load i32, ptr %l280, !tbaa !23
  %t502 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclModule(ptr %v0, ptr %t500, i32 %t501)
  store i64 %t502, ptr %l281
  br label %bb127
bb127:
  %t503 = load ptr, ptr %l0, !tbaa !29
  %t504 = load i32, ptr %l15, !tbaa !23
  %t507 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclModule(ptr %v0, ptr %t503, i32 %t504)
  store i64 %t507, ptr %l284
  br label %bb128
bb128:
  %t508 = load i64, ptr %l281, !tbaa !24
  %t509 = load i64, ptr %l284, !tbaa !24
  %t510 = icmp ne i64 %t508, %t509
  store i1 %t510, ptr %l275, !tbaa !21
  br label %bb129
bb129:
  %t512 = load i1, ptr %l275, !tbaa !21
  store i1 %t512, ptr %l33, !tbaa !21
  %t513 = load i32, ptr %l2, !tbaa !23
  store i32 %t513, ptr %l286, !tbaa !23
  %t514 = load ptr, ptr %l30, !tbaa !29
  %t516 = getelementptr %"compiler/ast:Func", ptr %t514, i32 0, i32 2
  %t517 = load i32, ptr %t516, !tbaa !23
  store i32 %t517, ptr %l288, !tbaa !23
  %t518 = load i1, ptr %l31, !tbaa !21
  br i1 %t518, label %bb130, label %bb131
bb130:
  %t520 = load i1, ptr %l33, !tbaa !21
  store i1 %t520, ptr %l290, !tbaa !21
  br label %bb132
bb131:
  store i1 false, ptr %l290, !tbaa !21
  br label %bb132
bb132:
  %t522 = load i32, ptr %l286, !tbaa !23
  %t523 = load i32, ptr %l288, !tbaa !23
  %t524 = load i1, ptr %l290, !tbaa !21
  %t525 = call %"compiler/generic:Unmet" @compiler_2fgeneric_3aUnmet_2ector(ptr %s22, i64 0, i32 %t522, i32 %t523, i1 true, i1 %t524, i1 false)
  store %"compiler/generic:Unmet" %t525, ptr %l292
  br label %bb133
bb133:
  call void @__olang_scope_close(ptr %s22)
  %t526 = load %"compiler/generic:Unmet", ptr %l292
  store %"compiler/generic:Unmet" %t526, ptr %rv
  br label %ret
bb134:
  %t527 = load i64, ptr %l28, !tbaa !24
  %t530 = add i64 %t527, 1
  store i64 %t530, ptr %l28, !tbaa !24
  br label %bb97
bb135:
  %t532 = call %"compiler/generic:Unmet" @compiler_2fgeneric_2eUnmet_2emet()
  store %"compiler/generic:Unmet" %t532, ptr %l296
  br label %bb136
bb136:
  %t533 = load %"compiler/generic:Unmet", ptr %l296
  store %"compiler/generic:Unmet" %t533, ptr %rv
  br label %ret
bb137:
  br i1 true, label %bb138, label %bb139
bb138:
  br label %bb140
bb139:
  br label %bb142
bb140:
  store %olang.scope zeroinitializer, ptr %s27
  %t534 = load i32, ptr %l2, !tbaa !23
  %t536 = call %"compiler/generic:Unmet" @compiler_2fgeneric_3aUnmet_2ector(ptr %s27, i64 0, i32 %t534, i32 0, i1 false, i1 false, i1 false)
  store %"compiler/generic:Unmet" %t536, ptr %l298
  br label %bb141
bb141:
  call void @__olang_scope_close(ptr %s27)
  %t537 = load %"compiler/generic:Unmet", ptr %l298
  store %"compiler/generic:Unmet" %t537, ptr %rv
  br label %ret
bb142:
  call void @__olang_check_failed(ptr @olang_loc_baaca818f0e4393a_2cd871f7f771e33e)
  unreachable
ret:
  %rr = load %"compiler/generic:Unmet", ptr %rv
  ret %"compiler/generic:Unmet" %rr
}

define dso_local { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eModuleFns(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca %"compiler/generic:fnRow"
  %l13 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l16 = alloca i64
  %l20 = alloca i64
  %l23 = alloca i64
  %l44 = alloca %"compiler/generic:fnRow"
  %l48 = alloca i1
  %l50 = alloca i1
  %l55 = alloca i1
  %l57 = alloca i1
  %l58 = alloca i1
  %l66 = alloca i1
  %l70 = alloca { i64, ptr }
  %l71 = alloca { i64, ptr }
  %l73 = alloca i1
  %l81 = alloca { i64, ptr }
  %l82 = alloca { i64, ptr }
  %l83 = alloca i64
  %l84 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2efnsIn(ptr %v0, ptr %t1, i64 %t2)
  br label %bb1
bb1:
  %t5 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %l13
  br label %bb2
bb2:
  %t6 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l13
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t6, ptr %l3
  store i64 0, ptr %l4, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/generic:Program", ptr %t7, i32 0, i32 31
  %t11 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3afnRow_3e_2eLen_3ccompiler_2fgeneric_3afnRow_3e(ptr %v0, ptr %t9)
  store i64 %t11, ptr %l16
  br label %bb3
bb3:
  %t12 = load i64, ptr %l16, !tbaa !24
  store i64 %t12, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t13 = load i64, ptr %l5, !tbaa !24
  %t14 = load i64, ptr %l4, !tbaa !24
  %t17 = icmp sgt i64 %t13, %t14
  br i1 %t17, label %bb4, label %bb5
bb4:
  %t19 = load i64, ptr %l6, !tbaa !24
  %t21 = icmp sgt i64 %t19, 0
  br i1 %t21, label %bb6, label %bb7
bb5:
  store i64 0, ptr %l20, !tbaa !24
  br label %bb9
bb6:
  %t23 = load i64, ptr %l5, !tbaa !24
  %t24 = load i64, ptr %l4, !tbaa !24
  %t27 = sub i64 %t23, %t24
  %t28 = load i64, ptr %l6, !tbaa !24
  %t31 = add i64 %t27, %t28
  %t33 = sub i64 %t31, 1
  %t34 = load i64, ptr %l6, !tbaa !24
  %t37 = sdiv i64 %t33, %t34
  store i64 %t37, ptr %l23, !tbaa !24
  br label %bb8
bb7:
  store i64 0, ptr %l23, !tbaa !24
  br label %bb8
bb8:
  %t39 = load i64, ptr %l23, !tbaa !24
  store i64 %t39, ptr %l20, !tbaa !24
  br label %bb9
bb9:
  %t40 = load i64, ptr %l20, !tbaa !24
  store i64 %t40, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s2
  %t41 = load i64, ptr %l8, !tbaa !24
  %t42 = load i64, ptr %l7, !tbaa !24
  %t45 = icmp slt i64 %t41, %t42
  %t47 = xor i1 %t45, true
  br i1 %t47, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s2)
  br label %bb41
bb12:
  br label %bb13
bb13:
  %t49 = load i64, ptr %l4, !tbaa !24
  %t50 = load i64, ptr %l8, !tbaa !24
  %t51 = load i64, ptr %l6, !tbaa !24
  %t54 = mul i64 %t50, %t51
  %t57 = add i64 %t49, %t54
  store i64 %t57, ptr %l9, !tbaa !24
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/generic:Program", ptr %t59, i32 0, i32 31
  %t62 = load i64, ptr %l9, !tbaa !24
  %t65 = call %"compiler/generic:fnRow" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3afnRow_3e_2eAt_3ccompiler_2fgeneric_3afnRow_3e(ptr %v0, ptr %v0, ptr %t61, i64 %t62)
  store %"compiler/generic:fnRow" %t65, ptr %l44
  br label %bb14
bb14:
  %t66 = load %"compiler/generic:fnRow", ptr %l44
  store %"compiler/generic:fnRow" %t66, ptr %l10
  %t67 = getelementptr %"compiler/generic:fnRow", ptr %l10, i32 0, i32 0
  %t68 = load i64, ptr %t67, !tbaa !24
  %t69 = load i64, ptr %l1, !tbaa !24
  %t72 = icmp ne i64 %t68, %t69
  br i1 %t72, label %bb15, label %bb16
bb15:
  store i1 true, ptr %l48, !tbaa !21
  br label %bb17
bb16:
  %t74 = getelementptr %"compiler/generic:fnRow", ptr %l10, i32 0, i32 2
  %t75 = load i1, ptr %t74, !tbaa !21
  store i1 %t75, ptr %l48, !tbaa !21
  br label %bb17
bb17:
  %t77 = load i1, ptr %l48, !tbaa !21
  br i1 %t77, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l50, !tbaa !21
  br label %bb20
bb19:
  %t78 = getelementptr %"compiler/generic:fnRow", ptr %l10, i32 0, i32 1
  %t79 = load ptr, ptr %t78, !tbaa !29
  %t81 = getelementptr %"compiler/ast:Func", ptr %t79, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !29
  %t84 = icmp eq ptr %t82, null
  %t86 = xor i1 %t84, true
  store i1 %t86, ptr %l50, !tbaa !21
  br label %bb20
bb20:
  %t88 = load i1, ptr %l50, !tbaa !21
  br i1 %t88, label %bb21, label %bb22
bb21:
  store i1 true, ptr %l55, !tbaa !21
  br label %bb24
bb22:
  %t89 = getelementptr %"compiler/generic:fnRow", ptr %l10, i32 0, i32 1
  %t90 = load ptr, ptr %t89, !tbaa !29
  %t92 = call i1 @compiler_2fast_2ecompiler_2fast_3aFunc_2eIsBuilder(ptr %v0, ptr %t90)
  store i1 %t92, ptr %l57
  br label %bb23
bb23:
  %t93 = load i1, ptr %l57, !tbaa !21
  store i1 %t93, ptr %l55, !tbaa !21
  br label %bb24
bb24:
  %t94 = load i1, ptr %l55, !tbaa !21
  br i1 %t94, label %bb25, label %bb26
bb25:
  store i1 true, ptr %l58, !tbaa !21
  br label %bb27
bb26:
  %t95 = getelementptr %"compiler/generic:fnRow", ptr %l10, i32 0, i32 1
  %t96 = load ptr, ptr %t95, !tbaa !29
  %t98 = getelementptr %"compiler/ast:Func", ptr %t96, i32 0, i32 5
  %t99 = load { i64, ptr }, ptr %t98, !tbaa !27
  %t101 = extractvalue { i64, ptr } %t99, 0
  %t103 = icmp sgt i64 %t101, 0
  store i1 %t103, ptr %l58, !tbaa !21
  br label %bb27
bb27:
  %t105 = load i1, ptr %l58, !tbaa !21
  br i1 %t105, label %bb28, label %bb29
bb28:
  call void @__olang_scope_close(ptr %s2)
  br label %bb40
bb29:
  br label %bb30
bb30:
  %t106 = load i64, ptr %l1, !tbaa !24
  %t110 = icmp ne i64 %t106, %a2
  br i1 %t110, label %bb31, label %bb32
bb31:
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t113 = getelementptr %"compiler/generic:fnRow", ptr %l10, i32 0, i32 1
  %t114 = load ptr, ptr %t113, !tbaa !29
  %t116 = getelementptr %"compiler/ast:Func", ptr %t114, i32 0, i32 2
  %t117 = load i32, ptr %t116, !tbaa !23
  %t120 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2etext(ptr %v0, ptr %s2, ptr %t112, i32 %t117)
  store { i64, ptr } %t120, ptr %l70
  br label %bb33
bb32:
  store i1 false, ptr %l66, !tbaa !21
  br label %bb35
bb33:
  %t121 = load { i64, ptr }, ptr %l70, !tbaa !27
  store { i64, ptr } %t121, ptr %l71, !tbaa !27
  %t122 = getelementptr { i64, ptr }, ptr %l71, i32 0, i32 1
  %t123 = load ptr, ptr %t122, !tbaa !27
  %t124 = getelementptr i8, ptr %t123, i64 0
  %t125 = load i8, ptr %t124, !tbaa !32
  %t127 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsUpper(i8 %t125)
  store i1 %t127, ptr %l73
  br label %bb34
bb34:
  %t128 = load i1, ptr %l73, !tbaa !21
  %t129 = xor i1 %t128, true
  store i1 %t129, ptr %l66, !tbaa !21
  br label %bb35
bb35:
  %t131 = load i1, ptr %l66, !tbaa !21
  br i1 %t131, label %bb36, label %bb37
bb36:
  call void @__olang_scope_close(ptr %s2)
  br label %bb40
bb37:
  br label %bb38
bb38:
  %t132 = load i64, ptr %l9, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l3, i64 %t132)
  br label %bb39
bb39:
  call void @__olang_scope_close(ptr %s2)
  br label %bb40
bb40:
  %t135 = load i64, ptr %l8, !tbaa !24
  %t138 = add i64 %t135, 1
  store i64 %t138, ptr %l8, !tbaa !24
  br label %bb10
bb41:
  %t141 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eToArray_3cI64_3e(ptr %s0, ptr %s0, ptr %l3)
  store { i64, ptr } %t141, ptr %l81
  br label %bb42
bb42:
  %t142 = load { i64, ptr }, ptr %l81, !tbaa !27
  store { i64, ptr } %t142, ptr %l82, !tbaa !27
  %t143 = load { i64, ptr }, ptr %l82, !tbaa !27
  %t144 = extractvalue { i64, ptr } %t143, 0
  store i64 %t144, ptr %l83, !tbaa !24
  %t145 = load i64, ptr %l83, !tbaa !24
  %t146 = mul i64 %t145, 8
  %t147 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t146)
  %t148 = insertvalue { i64, ptr } undef, i64 %t145, 0
  %t149 = insertvalue { i64, ptr } %t148, ptr %t147, 1
  store { i64, ptr } %t149, ptr %l84, !tbaa !27
  %t150 = getelementptr { i64, ptr }, ptr %l84, i32 0, i32 1
  %t151 = load ptr, ptr %t150, !tbaa !27
  %t152 = getelementptr { i64, ptr }, ptr %l82, i32 0, i32 1
  %t153 = load ptr, ptr %t152, !tbaa !27
  %t154 = load i64, ptr %l83, !tbaa !24
  %t155 = mul i64 %t154, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t151, ptr %t153, i64 %t155, i1 false)
  %t156 = load { i64, ptr }, ptr %l84, !tbaa !27
  store { i64, ptr } %t156, ptr %l82, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t157 = load { i64, ptr }, ptr %l82, !tbaa !27
  store { i64, ptr } %t157, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eProject(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca %"compiler/generic:Desc"
  %l4 = alloca i32
  %l5 = alloca %"compiler/generic:Desc"
  %l6 = alloca i64
  %l8 = alloca i1
  %l11 = alloca %"compiler/generic:Desc"
  %l16 = alloca { i64, ptr }
  %l18 = alloca { i32, { i64, ptr } }
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca { i64, ptr }
  %l24 = alloca { i32, { i64, ptr } }
  %l25 = alloca { i64, ptr }
  %l26 = alloca i64
  %l27 = alloca { i64, ptr }
  %l29 = alloca i1
  %l33 = alloca i32
  %l36 = alloca i1
  %l39 = alloca i1
  %l40 = alloca i1
  %l42 = alloca ptr
  %l46 = alloca i32
  %l47 = alloca i32
  %l53 = alloca i32
  %l54 = alloca { i64, ptr }
  %l56 = alloca { i32, { i64, ptr } }
  %l57 = alloca { i64, ptr }
  %l58 = alloca i64
  %l59 = alloca { i64, ptr }
  %l61 = alloca { i64, ptr }
  %l63 = alloca { i32, { i64, ptr } }
  %l64 = alloca { i64, ptr }
  %l65 = alloca i64
  %l66 = alloca { i64, ptr }
  %l68 = alloca i1
  %l71 = alloca i32
  %l75 = alloca i32
  %l81 = alloca i32
  %l82 = alloca { i64, ptr }
  %l84 = alloca { i32, { i64, ptr } }
  %l85 = alloca { i64, ptr }
  %l86 = alloca i64
  %l87 = alloca { i64, ptr }
  %l90 = alloca i32
  %l95 = alloca i32
  %l96 = alloca { i64, ptr }
  %l98 = alloca { i32, { i64, ptr } }
  %l99 = alloca { i64, ptr }
  %l100 = alloca i64
  %l101 = alloca { i64, ptr }
  %l103 = alloca { i64, ptr }
  %l105 = alloca { i32, { i64, ptr } }
  %l106 = alloca { i64, ptr }
  %l107 = alloca i64
  %l108 = alloca { i64, ptr }
  %l110 = alloca i1
  %l114 = alloca i32
  %l120 = alloca i32
  %l121 = alloca { i64, ptr }
  %l123 = alloca { i32, { i64, ptr } }
  %l124 = alloca { i64, ptr }
  %l125 = alloca i64
  %l126 = alloca { i64, ptr }
  %l128 = alloca { i64, ptr }
  %l130 = alloca { i32, { i64, ptr } }
  %l131 = alloca { i64, ptr }
  %l132 = alloca i64
  %l133 = alloca { i64, ptr }
  %l135 = alloca i1
  %l139 = alloca i32
  %l142 = alloca ptr
  %l146 = alloca i32
  %l147 = alloca i32
  %l148 = alloca { i64, ptr }
  %l150 = alloca { i32, { i64, ptr } }
  %l151 = alloca { i64, ptr }
  %l152 = alloca i64
  %l153 = alloca { i64, ptr }
  %l156 = alloca %"compiler/generic:Desc"
  %l160 = alloca ptr
  %l164 = alloca i32
  %l165 = alloca i32
  %l166 = alloca { i64, ptr }
  %l168 = alloca { i32, { i64, ptr } }
  %l169 = alloca { i64, ptr }
  %l170 = alloca i64
  %l171 = alloca { i64, ptr }
  %l173 = alloca { i64, ptr }
  %l175 = alloca { i32, { i64, ptr } }
  %l176 = alloca { i64, ptr }
  %l177 = alloca i64
  %l178 = alloca { i64, ptr }
  %l179 = alloca ptr
  %l180 = alloca i32
  %l185 = alloca i32
  %l186 = alloca i64
  %l192 = alloca i32
  %l193 = alloca { i64, ptr }
  %l195 = alloca { i32, { i64, ptr } }
  %l196 = alloca { i64, ptr }
  %l197 = alloca i64
  %l198 = alloca { i64, ptr }
  %l202 = alloca { i64, ptr }
  %l204 = alloca { i32, { i64, ptr } }
  %l205 = alloca { i64, ptr }
  %l206 = alloca i64
  %l207 = alloca { i64, ptr }
  %l208 = alloca i32
  %l211 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d1, i32 0, i32 1) })
  store i1 %t3, ptr %l8
  br label %bb1
bb1:
  %t4 = load i1, ptr %l8, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t6 = load i32, ptr %l1, !tbaa !23
  %t9 = call %"compiler/generic:Desc" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDescOf(ptr %v0, ptr %t5, i32 %t6)
  store %"compiler/generic:Desc" %t9, ptr %l11
  br label %bb4
bb3:
  br label %bb9
bb4:
  %t10 = load %"compiler/generic:Desc", ptr %l11
  store %"compiler/generic:Desc" %t10, ptr %l3
  %t11 = getelementptr %"compiler/generic:Desc", ptr %l3, i32 0, i32 0
  %t12 = load i64, ptr %t11, !tbaa !24
  %t13 = load i64, ptr @G_2ecompiler_2fgeneric_2eDescNone, !tbaa !24
  %t16 = icmp eq i64 %t12, %t13
  br i1 %t16, label %bb5, label %bb6
bb5:
  %t18 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store { i64, ptr } { i64 60, ptr getelementptr inbounds (<{ i64, [60 x i8] }>, ptr @.d2, i32 0, i32 1) }, ptr %l16, !tbaa !27
  %t19 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t21 = insertvalue { i32, { i64, ptr } } undef, i32 %t18, 0
  %t23 = insertvalue { i32, { i64, ptr } } %t21, { i64, ptr } %t19, 1
  store { i32, { i64, ptr } } %t23, ptr %l18
  %t24 = getelementptr { i32, { i64, ptr } }, ptr %l18, i32 0, i32 1
  %t25 = load { i64, ptr }, ptr %t24, !tbaa !27
  store { i64, ptr } %t25, ptr %l19, !tbaa !27
  %t26 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t27 = extractvalue { i64, ptr } %t26, 0
  store i64 %t27, ptr %l20, !tbaa !24
  %t28 = load i64, ptr %l20, !tbaa !24
  %t29 = mul i64 %t28, 1
  %t30 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t29)
  %t31 = insertvalue { i64, ptr } undef, i64 %t28, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  store { i64, ptr } %t32, ptr %l21, !tbaa !27
  %t33 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !27
  %t35 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !27
  %t37 = load i64, ptr %l20, !tbaa !24
  %t38 = mul i64 %t37, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t34, ptr %t36, i64 %t38, i1 false)
  %t39 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t40 = getelementptr { i32, { i64, ptr } }, ptr %l18, i32 0, i32 1
  store { i64, ptr } %t39, ptr %t40, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t41 = load { i32, { i64, ptr } }, ptr %l18
  store { i32, { i64, ptr } } %t41, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t43 = load %"compiler/generic:Desc", ptr %l3
  %t46 = call { i32, { i64, ptr } } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDescType(ptr %v0, ptr %v2, ptr %t42, %"compiler/generic:Desc" %t43)
  store { i32, { i64, ptr } } %t46, ptr %l24
  br label %bb8
bb8:
  %t47 = getelementptr { i32, { i64, ptr } }, ptr %l24, i32 0, i32 1
  %t48 = load { i64, ptr }, ptr %t47, !tbaa !27
  store { i64, ptr } %t48, ptr %l25, !tbaa !27
  %t49 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t50 = extractvalue { i64, ptr } %t49, 0
  store i64 %t50, ptr %l26, !tbaa !24
  %t51 = load i64, ptr %l26, !tbaa !24
  %t52 = mul i64 %t51, 1
  %t53 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t52)
  %t54 = insertvalue { i64, ptr } undef, i64 %t51, 0
  %t55 = insertvalue { i64, ptr } %t54, ptr %t53, 1
  store { i64, ptr } %t55, ptr %l27, !tbaa !27
  %t56 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t57 = load ptr, ptr %t56, !tbaa !27
  %t58 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !27
  %t60 = load i64, ptr %l26, !tbaa !24
  %t61 = mul i64 %t60, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t57, ptr %t59, i64 %t61, i1 false)
  %t62 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t63 = getelementptr { i32, { i64, ptr } }, ptr %l24, i32 0, i32 1
  store { i64, ptr } %t62, ptr %t63, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t64 = load { i32, { i64, ptr } }, ptr %l24
  store { i32, { i64, ptr } } %t64, ptr %rv
  br label %ret
bb9:
  %t65 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t67 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t65, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d3, i32 0, i32 1) })
  store i1 %t67, ptr %l29
  br label %bb10
bb10:
  %t68 = load i1, ptr %l29, !tbaa !21
  br i1 %t68, label %bb11, label %bb12
bb11:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/generic:Program", ptr %t69, i32 0, i32 2
  %t72 = load i32, ptr %l1, !tbaa !23
  %t75 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t71, i32 %t72)
  store i32 %t75, ptr %l33
  br label %bb13
bb12:
  br label %bb27
bb13:
  %t76 = load i32, ptr %l33, !range !{i32 0, i32 33}
  %t78 = trunc i64 18 to i32
  %t79 = icmp eq i32 %t76, %t78
  br i1 %t79, label %bb14, label %bb15
bb14:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t82 = load i32, ptr %l1, !tbaa !23
  %t85 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %t81, i32 %t82)
  store i1 %t85, ptr %l39
  br label %bb16
bb15:
  store i1 false, ptr %l36, !tbaa !21
  br label %bb17
bb16:
  %t86 = load i1, ptr %l39, !tbaa !21
  store i1 %t86, ptr %l36, !tbaa !21
  br label %bb17
bb17:
  %t87 = load i1, ptr %l36, !tbaa !21
  br i1 %t87, label %bb18, label %bb19
bb18:
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t90 = getelementptr %"compiler/generic:Program", ptr %t88, i32 0, i32 2
  store ptr %t90, ptr %l42, !tbaa !29
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t93 = getelementptr %"compiler/generic:Program", ptr %t91, i32 0, i32 2
  %t94 = load i32, ptr %l1, !tbaa !23
  %t97 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t93, i32 %t94)
  store i32 %t97, ptr %l46
  br label %bb20
bb19:
  store i1 false, ptr %l40, !tbaa !21
  br label %bb22
bb20:
  %t98 = load ptr, ptr %l42, !tbaa !29
  %t99 = load i32, ptr %l46, !tbaa !23
  %t100 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t98, i32 %t99)
  store i32 %t100, ptr %l47
  br label %bb21
bb21:
  %t101 = load i32, ptr %l47, !range !{i32 0, i32 6}
  %t103 = trunc i64 4 to i32
  %t104 = icmp eq i32 %t101, %t103
  store i1 %t104, ptr %l40, !tbaa !21
  br label %bb22
bb22:
  %t106 = load i1, ptr %l40, !tbaa !21
  br i1 %t106, label %bb23, label %bb24
bb23:
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t109 = getelementptr %"compiler/generic:Program", ptr %t107, i32 0, i32 2
  %t110 = load i32, ptr %l1, !tbaa !23
  %t113 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %t109, i32 %t110)
  store i32 %t113, ptr %l53
  br label %bb25
bb24:
  br label %bb26
bb25:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d4, i32 0, i32 1) }, ptr %l54, !tbaa !27
  %t114 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t115 = load i32, ptr %l53, !tbaa !23
  %t116 = insertvalue { i32, { i64, ptr } } undef, i32 %t115, 0
  %t118 = insertvalue { i32, { i64, ptr } } %t116, { i64, ptr } %t114, 1
  store { i32, { i64, ptr } } %t118, ptr %l56
  %t119 = getelementptr { i32, { i64, ptr } }, ptr %l56, i32 0, i32 1
  %t120 = load { i64, ptr }, ptr %t119, !tbaa !27
  store { i64, ptr } %t120, ptr %l57, !tbaa !27
  %t121 = load { i64, ptr }, ptr %l57, !tbaa !27
  %t122 = extractvalue { i64, ptr } %t121, 0
  store i64 %t122, ptr %l58, !tbaa !24
  %t123 = load i64, ptr %l58, !tbaa !24
  %t124 = mul i64 %t123, 1
  %t125 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t124)
  %t126 = insertvalue { i64, ptr } undef, i64 %t123, 0
  %t127 = insertvalue { i64, ptr } %t126, ptr %t125, 1
  store { i64, ptr } %t127, ptr %l59, !tbaa !27
  %t128 = getelementptr { i64, ptr }, ptr %l59, i32 0, i32 1
  %t129 = load ptr, ptr %t128, !tbaa !27
  %t130 = getelementptr { i64, ptr }, ptr %l57, i32 0, i32 1
  %t131 = load ptr, ptr %t130, !tbaa !27
  %t132 = load i64, ptr %l58, !tbaa !24
  %t133 = mul i64 %t132, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t129, ptr %t131, i64 %t133, i1 false)
  %t134 = load { i64, ptr }, ptr %l59, !tbaa !27
  %t135 = getelementptr { i32, { i64, ptr } }, ptr %l56, i32 0, i32 1
  store { i64, ptr } %t134, ptr %t135, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t136 = load { i32, { i64, ptr } }, ptr %l56
  store { i32, { i64, ptr } } %t136, ptr %rv
  br label %ret
bb26:
  %t137 = load i32, ptr %l1, !tbaa !23
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d5, i32 0, i32 1) }, ptr %l61, !tbaa !27
  %t138 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t140 = insertvalue { i32, { i64, ptr } } undef, i32 %t137, 0
  %t142 = insertvalue { i32, { i64, ptr } } %t140, { i64, ptr } %t138, 1
  store { i32, { i64, ptr } } %t142, ptr %l63
  %t143 = getelementptr { i32, { i64, ptr } }, ptr %l63, i32 0, i32 1
  %t144 = load { i64, ptr }, ptr %t143, !tbaa !27
  store { i64, ptr } %t144, ptr %l64, !tbaa !27
  %t145 = load { i64, ptr }, ptr %l64, !tbaa !27
  %t146 = extractvalue { i64, ptr } %t145, 0
  store i64 %t146, ptr %l65, !tbaa !24
  %t147 = load i64, ptr %l65, !tbaa !24
  %t148 = mul i64 %t147, 1
  %t149 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t148)
  %t150 = insertvalue { i64, ptr } undef, i64 %t147, 0
  %t151 = insertvalue { i64, ptr } %t150, ptr %t149, 1
  store { i64, ptr } %t151, ptr %l66, !tbaa !27
  %t152 = getelementptr { i64, ptr }, ptr %l66, i32 0, i32 1
  %t153 = load ptr, ptr %t152, !tbaa !27
  %t154 = getelementptr { i64, ptr }, ptr %l64, i32 0, i32 1
  %t155 = load ptr, ptr %t154, !tbaa !27
  %t156 = load i64, ptr %l65, !tbaa !24
  %t157 = mul i64 %t156, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t153, ptr %t155, i64 %t157, i1 false)
  %t158 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t159 = getelementptr { i32, { i64, ptr } }, ptr %l63, i32 0, i32 1
  store { i64, ptr } %t158, ptr %t159, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t160 = load { i32, { i64, ptr } }, ptr %l63
  store { i32, { i64, ptr } } %t160, ptr %rv
  br label %ret
bb27:
  %t161 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t163 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t161, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d6, i32 0, i32 1) })
  store i1 %t163, ptr %l68
  br label %bb28
bb28:
  %t164 = load i1, ptr %l68, !tbaa !21
  br i1 %t164, label %bb29, label %bb30
bb29:
  %t165 = load ptr, ptr %l0, !tbaa !29
  %t166 = load i32, ptr %l1, !tbaa !23
  %t169 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eReflUnder(ptr %v0, ptr %t165, i32 %t166)
  store i32 %t169, ptr %l71
  br label %bb31
bb30:
  br label %bb42
bb31:
  %t170 = load i32, ptr %l71, !tbaa !23
  store i32 %t170, ptr %l4, !tbaa !23
  %t171 = load ptr, ptr %l0, !tbaa !29
  %t173 = getelementptr %"compiler/generic:Program", ptr %t171, i32 0, i32 2
  %t174 = load i32, ptr %l4, !tbaa !23
  %t177 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t173, i32 %t174)
  store i32 %t177, ptr %l75
  br label %bb32
bb32:
  %t178 = load i32, ptr %l75, !range !{i32 0, i32 33}
  %t180 = trunc i64 19 to i32
  %t181 = icmp eq i32 %t178, %t180
  br i1 %t181, label %bb33, label %bb34
bb33:
  %t183 = load ptr, ptr %l0, !tbaa !29
  %t185 = getelementptr %"compiler/generic:Program", ptr %t183, i32 0, i32 2
  %t186 = load i32, ptr %l4, !tbaa !23
  %t189 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t185, i32 %t186)
  store i32 %t189, ptr %l81
  br label %bb35
bb34:
  br label %bb36
bb35:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d7, i32 0, i32 1) }, ptr %l82, !tbaa !27
  %t190 = load { i64, ptr }, ptr %l82, !tbaa !27
  %t191 = load i32, ptr %l81, !tbaa !23
  %t192 = insertvalue { i32, { i64, ptr } } undef, i32 %t191, 0
  %t194 = insertvalue { i32, { i64, ptr } } %t192, { i64, ptr } %t190, 1
  store { i32, { i64, ptr } } %t194, ptr %l84
  %t195 = getelementptr { i32, { i64, ptr } }, ptr %l84, i32 0, i32 1
  %t196 = load { i64, ptr }, ptr %t195, !tbaa !27
  store { i64, ptr } %t196, ptr %l85, !tbaa !27
  %t197 = load { i64, ptr }, ptr %l85, !tbaa !27
  %t198 = extractvalue { i64, ptr } %t197, 0
  store i64 %t198, ptr %l86, !tbaa !24
  %t199 = load i64, ptr %l86, !tbaa !24
  %t200 = mul i64 %t199, 1
  %t201 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t200)
  %t202 = insertvalue { i64, ptr } undef, i64 %t199, 0
  %t203 = insertvalue { i64, ptr } %t202, ptr %t201, 1
  store { i64, ptr } %t203, ptr %l87, !tbaa !27
  %t204 = getelementptr { i64, ptr }, ptr %l87, i32 0, i32 1
  %t205 = load ptr, ptr %t204, !tbaa !27
  %t206 = getelementptr { i64, ptr }, ptr %l85, i32 0, i32 1
  %t207 = load ptr, ptr %t206, !tbaa !27
  %t208 = load i64, ptr %l86, !tbaa !24
  %t209 = mul i64 %t208, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t205, ptr %t207, i64 %t209, i1 false)
  %t210 = load { i64, ptr }, ptr %l87, !tbaa !27
  %t211 = getelementptr { i32, { i64, ptr } }, ptr %l84, i32 0, i32 1
  store { i64, ptr } %t210, ptr %t211, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t212 = load { i32, { i64, ptr } }, ptr %l84
  store { i32, { i64, ptr } } %t212, ptr %rv
  br label %ret
bb36:
  %t213 = load ptr, ptr %l0, !tbaa !29
  %t214 = load i32, ptr %l4, !tbaa !23
  %t217 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eColumnsRow(ptr %v0, ptr %t213, i32 %t214)
  store i32 %t217, ptr %l90
  br label %bb37
bb37:
  %t218 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t219 = load i32, ptr %l90, !tbaa !23
  %t221 = icmp ne i32 %t219, %t218
  br i1 %t221, label %bb38, label %bb39
bb38:
  %t223 = load ptr, ptr %l0, !tbaa !29
  %t224 = load i32, ptr %l4, !tbaa !23
  %t227 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eColumnsRow(ptr %v0, ptr %t223, i32 %t224)
  store i32 %t227, ptr %l95
  br label %bb40
bb39:
  br label %bb41
bb40:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d8, i32 0, i32 1) }, ptr %l96, !tbaa !27
  %t228 = load { i64, ptr }, ptr %l96, !tbaa !27
  %t229 = load i32, ptr %l95, !tbaa !23
  %t230 = insertvalue { i32, { i64, ptr } } undef, i32 %t229, 0
  %t232 = insertvalue { i32, { i64, ptr } } %t230, { i64, ptr } %t228, 1
  store { i32, { i64, ptr } } %t232, ptr %l98
  %t233 = getelementptr { i32, { i64, ptr } }, ptr %l98, i32 0, i32 1
  %t234 = load { i64, ptr }, ptr %t233, !tbaa !27
  store { i64, ptr } %t234, ptr %l99, !tbaa !27
  %t235 = load { i64, ptr }, ptr %l99, !tbaa !27
  %t236 = extractvalue { i64, ptr } %t235, 0
  store i64 %t236, ptr %l100, !tbaa !24
  %t237 = load i64, ptr %l100, !tbaa !24
  %t238 = mul i64 %t237, 1
  %t239 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t238)
  %t240 = insertvalue { i64, ptr } undef, i64 %t237, 0
  %t241 = insertvalue { i64, ptr } %t240, ptr %t239, 1
  store { i64, ptr } %t241, ptr %l101, !tbaa !27
  %t242 = getelementptr { i64, ptr }, ptr %l101, i32 0, i32 1
  %t243 = load ptr, ptr %t242, !tbaa !27
  %t244 = getelementptr { i64, ptr }, ptr %l99, i32 0, i32 1
  %t245 = load ptr, ptr %t244, !tbaa !27
  %t246 = load i64, ptr %l100, !tbaa !24
  %t247 = mul i64 %t246, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t243, ptr %t245, i64 %t247, i1 false)
  %t248 = load { i64, ptr }, ptr %l101, !tbaa !27
  %t249 = getelementptr { i32, { i64, ptr } }, ptr %l98, i32 0, i32 1
  store { i64, ptr } %t248, ptr %t249, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t250 = load { i32, { i64, ptr } }, ptr %l98
  store { i32, { i64, ptr } } %t250, ptr %rv
  br label %ret
bb41:
  %t251 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store { i64, ptr } { i64 56, ptr getelementptr inbounds (<{ i64, [56 x i8] }>, ptr @.d9, i32 0, i32 1) }, ptr %l103, !tbaa !27
  %t252 = load { i64, ptr }, ptr %l103, !tbaa !27
  %t254 = insertvalue { i32, { i64, ptr } } undef, i32 %t251, 0
  %t256 = insertvalue { i32, { i64, ptr } } %t254, { i64, ptr } %t252, 1
  store { i32, { i64, ptr } } %t256, ptr %l105
  %t257 = getelementptr { i32, { i64, ptr } }, ptr %l105, i32 0, i32 1
  %t258 = load { i64, ptr }, ptr %t257, !tbaa !27
  store { i64, ptr } %t258, ptr %l106, !tbaa !27
  %t259 = load { i64, ptr }, ptr %l106, !tbaa !27
  %t260 = extractvalue { i64, ptr } %t259, 0
  store i64 %t260, ptr %l107, !tbaa !24
  %t261 = load i64, ptr %l107, !tbaa !24
  %t262 = mul i64 %t261, 1
  %t263 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t262)
  %t264 = insertvalue { i64, ptr } undef, i64 %t261, 0
  %t265 = insertvalue { i64, ptr } %t264, ptr %t263, 1
  store { i64, ptr } %t265, ptr %l108, !tbaa !27
  %t266 = getelementptr { i64, ptr }, ptr %l108, i32 0, i32 1
  %t267 = load ptr, ptr %t266, !tbaa !27
  %t268 = getelementptr { i64, ptr }, ptr %l106, i32 0, i32 1
  %t269 = load ptr, ptr %t268, !tbaa !27
  %t270 = load i64, ptr %l107, !tbaa !24
  %t271 = mul i64 %t270, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t267, ptr %t269, i64 %t271, i1 false)
  %t272 = load { i64, ptr }, ptr %l108, !tbaa !27
  %t273 = getelementptr { i32, { i64, ptr } }, ptr %l105, i32 0, i32 1
  store { i64, ptr } %t272, ptr %t273, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t274 = load { i32, { i64, ptr } }, ptr %l105
  store { i32, { i64, ptr } } %t274, ptr %rv
  br label %ret
bb42:
  %t275 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t277 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t275, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d10, i32 0, i32 1) })
  store i1 %t277, ptr %l110
  br label %bb43
bb43:
  %t278 = load i1, ptr %l110, !tbaa !21
  br i1 %t278, label %bb44, label %bb45
bb44:
  %t279 = load ptr, ptr %l0, !tbaa !29
  %t281 = getelementptr %"compiler/generic:Program", ptr %t279, i32 0, i32 2
  %t282 = load i32, ptr %l1, !tbaa !23
  %t285 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t281, i32 %t282)
  store i32 %t285, ptr %l114
  br label %bb46
bb45:
  br label %bb51
bb46:
  %t286 = load i32, ptr %l114, !range !{i32 0, i32 33}
  %t288 = trunc i64 20 to i32
  %t289 = icmp eq i32 %t286, %t288
  br i1 %t289, label %bb47, label %bb48
bb47:
  %t291 = load ptr, ptr %l0, !tbaa !29
  %t293 = getelementptr %"compiler/generic:Program", ptr %t291, i32 0, i32 2
  %t294 = load i32, ptr %l1, !tbaa !23
  %t297 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t293, i32 %t294)
  store i32 %t297, ptr %l120
  br label %bb49
bb48:
  br label %bb50
bb49:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d11, i32 0, i32 1) }, ptr %l121, !tbaa !27
  %t298 = load { i64, ptr }, ptr %l121, !tbaa !27
  %t299 = load i32, ptr %l120, !tbaa !23
  %t300 = insertvalue { i32, { i64, ptr } } undef, i32 %t299, 0
  %t302 = insertvalue { i32, { i64, ptr } } %t300, { i64, ptr } %t298, 1
  store { i32, { i64, ptr } } %t302, ptr %l123
  %t303 = getelementptr { i32, { i64, ptr } }, ptr %l123, i32 0, i32 1
  %t304 = load { i64, ptr }, ptr %t303, !tbaa !27
  store { i64, ptr } %t304, ptr %l124, !tbaa !27
  %t305 = load { i64, ptr }, ptr %l124, !tbaa !27
  %t306 = extractvalue { i64, ptr } %t305, 0
  store i64 %t306, ptr %l125, !tbaa !24
  %t307 = load i64, ptr %l125, !tbaa !24
  %t308 = mul i64 %t307, 1
  %t309 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t308)
  %t310 = insertvalue { i64, ptr } undef, i64 %t307, 0
  %t311 = insertvalue { i64, ptr } %t310, ptr %t309, 1
  store { i64, ptr } %t311, ptr %l126, !tbaa !27
  %t312 = getelementptr { i64, ptr }, ptr %l126, i32 0, i32 1
  %t313 = load ptr, ptr %t312, !tbaa !27
  %t314 = getelementptr { i64, ptr }, ptr %l124, i32 0, i32 1
  %t315 = load ptr, ptr %t314, !tbaa !27
  %t316 = load i64, ptr %l125, !tbaa !24
  %t317 = mul i64 %t316, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t313, ptr %t315, i64 %t317, i1 false)
  %t318 = load { i64, ptr }, ptr %l126, !tbaa !27
  %t319 = getelementptr { i32, { i64, ptr } }, ptr %l123, i32 0, i32 1
  store { i64, ptr } %t318, ptr %t319, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t320 = load { i32, { i64, ptr } }, ptr %l123
  store { i32, { i64, ptr } } %t320, ptr %rv
  br label %ret
bb50:
  %t321 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d12, i32 0, i32 1) }, ptr %l128, !tbaa !27
  %t322 = load { i64, ptr }, ptr %l128, !tbaa !27
  %t324 = insertvalue { i32, { i64, ptr } } undef, i32 %t321, 0
  %t326 = insertvalue { i32, { i64, ptr } } %t324, { i64, ptr } %t322, 1
  store { i32, { i64, ptr } } %t326, ptr %l130
  %t327 = getelementptr { i32, { i64, ptr } }, ptr %l130, i32 0, i32 1
  %t328 = load { i64, ptr }, ptr %t327, !tbaa !27
  store { i64, ptr } %t328, ptr %l131, !tbaa !27
  %t329 = load { i64, ptr }, ptr %l131, !tbaa !27
  %t330 = extractvalue { i64, ptr } %t329, 0
  store i64 %t330, ptr %l132, !tbaa !24
  %t331 = load i64, ptr %l132, !tbaa !24
  %t332 = mul i64 %t331, 1
  %t333 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t332)
  %t334 = insertvalue { i64, ptr } undef, i64 %t331, 0
  %t335 = insertvalue { i64, ptr } %t334, ptr %t333, 1
  store { i64, ptr } %t335, ptr %l133, !tbaa !27
  %t336 = getelementptr { i64, ptr }, ptr %l133, i32 0, i32 1
  %t337 = load ptr, ptr %t336, !tbaa !27
  %t338 = getelementptr { i64, ptr }, ptr %l131, i32 0, i32 1
  %t339 = load ptr, ptr %t338, !tbaa !27
  %t340 = load i64, ptr %l132, !tbaa !24
  %t341 = mul i64 %t340, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t337, ptr %t339, i64 %t341, i1 false)
  %t342 = load { i64, ptr }, ptr %l133, !tbaa !27
  %t343 = getelementptr { i32, { i64, ptr } }, ptr %l130, i32 0, i32 1
  store { i64, ptr } %t342, ptr %t343, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t344 = load { i32, { i64, ptr } }, ptr %l130
  store { i32, { i64, ptr } } %t344, ptr %rv
  br label %ret
bb51:
  %t345 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t347 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t345, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d13, i32 0, i32 1) })
  store i1 %t347, ptr %l135
  br label %bb52
bb52:
  %t348 = load i1, ptr %l135, !tbaa !21
  br i1 %t348, label %bb53, label %bb54
bb53:
  %t349 = load ptr, ptr %l0, !tbaa !29
  %t351 = getelementptr %"compiler/generic:Program", ptr %t349, i32 0, i32 2
  %t352 = load i32, ptr %l1, !tbaa !23
  %t355 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t351, i32 %t352)
  store i32 %t355, ptr %l139
  br label %bb55
bb54:
  br label %bb67
bb55:
  %t356 = load i32, ptr %l139, !range !{i32 0, i32 33}
  %t358 = trunc i64 21 to i32
  %t359 = icmp eq i32 %t356, %t358
  br i1 %t359, label %bb56, label %bb57
bb56:
  %t361 = load ptr, ptr %l0, !tbaa !29
  store ptr %t361, ptr %l142, !tbaa !29
  %t362 = load ptr, ptr %l0, !tbaa !29
  %t364 = getelementptr %"compiler/generic:Program", ptr %t362, i32 0, i32 2
  %t365 = load i32, ptr %l1, !tbaa !23
  %t368 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t364, i32 %t365)
  store i32 %t368, ptr %l146
  br label %bb58
bb57:
  br label %bb60
bb58:
  %t369 = load ptr, ptr %l142, !tbaa !29
  %t370 = load i32, ptr %l146, !tbaa !23
  %t371 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrSetOf(ptr %v0, ptr %t369, i32 %t370)
  store i32 %t371, ptr %l147
  br label %bb59
bb59:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d14, i32 0, i32 1) }, ptr %l148, !tbaa !27
  %t372 = load { i64, ptr }, ptr %l148, !tbaa !27
  %t373 = load i32, ptr %l147, !tbaa !23
  %t374 = insertvalue { i32, { i64, ptr } } undef, i32 %t373, 0
  %t376 = insertvalue { i32, { i64, ptr } } %t374, { i64, ptr } %t372, 1
  store { i32, { i64, ptr } } %t376, ptr %l150
  %t377 = getelementptr { i32, { i64, ptr } }, ptr %l150, i32 0, i32 1
  %t378 = load { i64, ptr }, ptr %t377, !tbaa !27
  store { i64, ptr } %t378, ptr %l151, !tbaa !27
  %t379 = load { i64, ptr }, ptr %l151, !tbaa !27
  %t380 = extractvalue { i64, ptr } %t379, 0
  store i64 %t380, ptr %l152, !tbaa !24
  %t381 = load i64, ptr %l152, !tbaa !24
  %t382 = mul i64 %t381, 1
  %t383 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t382)
  %t384 = insertvalue { i64, ptr } undef, i64 %t381, 0
  %t385 = insertvalue { i64, ptr } %t384, ptr %t383, 1
  store { i64, ptr } %t385, ptr %l153, !tbaa !27
  %t386 = getelementptr { i64, ptr }, ptr %l153, i32 0, i32 1
  %t387 = load ptr, ptr %t386, !tbaa !27
  %t388 = getelementptr { i64, ptr }, ptr %l151, i32 0, i32 1
  %t389 = load ptr, ptr %t388, !tbaa !27
  %t390 = load i64, ptr %l152, !tbaa !24
  %t391 = mul i64 %t390, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t387, ptr %t389, i64 %t391, i1 false)
  %t392 = load { i64, ptr }, ptr %l153, !tbaa !27
  %t393 = getelementptr { i32, { i64, ptr } }, ptr %l150, i32 0, i32 1
  store { i64, ptr } %t392, ptr %t393, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t394 = load { i32, { i64, ptr } }, ptr %l150
  store { i32, { i64, ptr } } %t394, ptr %rv
  br label %ret
bb60:
  %t395 = load ptr, ptr %l0, !tbaa !29
  %t396 = load i32, ptr %l1, !tbaa !23
  %t399 = call %"compiler/generic:Desc" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDescOf(ptr %v0, ptr %t395, i32 %t396)
  store %"compiler/generic:Desc" %t399, ptr %l156
  br label %bb61
bb61:
  %t400 = load %"compiler/generic:Desc", ptr %l156
  store %"compiler/generic:Desc" %t400, ptr %l5
  %t401 = getelementptr %"compiler/generic:Desc", ptr %l5, i32 0, i32 0
  %t402 = load i64, ptr %t401, !tbaa !24
  %t403 = load i64, ptr @G_2ecompiler_2fgeneric_2eDescFunc, !tbaa !24
  %t406 = icmp eq i64 %t402, %t403
  br i1 %t406, label %bb62, label %bb63
bb62:
  %t408 = load ptr, ptr %l0, !tbaa !29
  store ptr %t408, ptr %l160, !tbaa !29
  %t409 = load ptr, ptr %l0, !tbaa !29
  %t411 = getelementptr %"compiler/generic:Program", ptr %t409, i32 0, i32 2
  %t412 = getelementptr %"compiler/generic:Desc", ptr %l5, i32 0, i32 1
  %t413 = load i32, ptr %t412, !tbaa !23
  %t416 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t411, i32 %t413)
  store i32 %t416, ptr %l164
  br label %bb64
bb63:
  br label %bb66
bb64:
  %t417 = load ptr, ptr %l160, !tbaa !29
  %t418 = load i32, ptr %l164, !tbaa !23
  %t419 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrSetOf(ptr %v0, ptr %t417, i32 %t418)
  store i32 %t419, ptr %l165
  br label %bb65
bb65:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d15, i32 0, i32 1) }, ptr %l166, !tbaa !27
  %t420 = load { i64, ptr }, ptr %l166, !tbaa !27
  %t421 = load i32, ptr %l165, !tbaa !23
  %t422 = insertvalue { i32, { i64, ptr } } undef, i32 %t421, 0
  %t424 = insertvalue { i32, { i64, ptr } } %t422, { i64, ptr } %t420, 1
  store { i32, { i64, ptr } } %t424, ptr %l168
  %t425 = getelementptr { i32, { i64, ptr } }, ptr %l168, i32 0, i32 1
  %t426 = load { i64, ptr }, ptr %t425, !tbaa !27
  store { i64, ptr } %t426, ptr %l169, !tbaa !27
  %t427 = load { i64, ptr }, ptr %l169, !tbaa !27
  %t428 = extractvalue { i64, ptr } %t427, 0
  store i64 %t428, ptr %l170, !tbaa !24
  %t429 = load i64, ptr %l170, !tbaa !24
  %t430 = mul i64 %t429, 1
  %t431 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t430)
  %t432 = insertvalue { i64, ptr } undef, i64 %t429, 0
  %t433 = insertvalue { i64, ptr } %t432, ptr %t431, 1
  store { i64, ptr } %t433, ptr %l171, !tbaa !27
  %t434 = getelementptr { i64, ptr }, ptr %l171, i32 0, i32 1
  %t435 = load ptr, ptr %t434, !tbaa !27
  %t436 = getelementptr { i64, ptr }, ptr %l169, i32 0, i32 1
  %t437 = load ptr, ptr %t436, !tbaa !27
  %t438 = load i64, ptr %l170, !tbaa !24
  %t439 = mul i64 %t438, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t435, ptr %t437, i64 %t439, i1 false)
  %t440 = load { i64, ptr }, ptr %l171, !tbaa !27
  %t441 = getelementptr { i32, { i64, ptr } }, ptr %l168, i32 0, i32 1
  store { i64, ptr } %t440, ptr %t441, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t442 = load { i32, { i64, ptr } }, ptr %l168
  store { i32, { i64, ptr } } %t442, ptr %rv
  br label %ret
bb66:
  %t443 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d16, i32 0, i32 1) }, ptr %l173, !tbaa !27
  %t444 = load { i64, ptr }, ptr %l173, !tbaa !27
  %t446 = insertvalue { i32, { i64, ptr } } undef, i32 %t443, 0
  %t448 = insertvalue { i32, { i64, ptr } } %t446, { i64, ptr } %t444, 1
  store { i32, { i64, ptr } } %t448, ptr %l175
  %t449 = getelementptr { i32, { i64, ptr } }, ptr %l175, i32 0, i32 1
  %t450 = load { i64, ptr }, ptr %t449, !tbaa !27
  store { i64, ptr } %t450, ptr %l176, !tbaa !27
  %t451 = load { i64, ptr }, ptr %l176, !tbaa !27
  %t452 = extractvalue { i64, ptr } %t451, 0
  store i64 %t452, ptr %l177, !tbaa !24
  %t453 = load i64, ptr %l177, !tbaa !24
  %t454 = mul i64 %t453, 1
  %t455 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t454)
  %t456 = insertvalue { i64, ptr } undef, i64 %t453, 0
  %t457 = insertvalue { i64, ptr } %t456, ptr %t455, 1
  store { i64, ptr } %t457, ptr %l178, !tbaa !27
  %t458 = getelementptr { i64, ptr }, ptr %l178, i32 0, i32 1
  %t459 = load ptr, ptr %t458, !tbaa !27
  %t460 = getelementptr { i64, ptr }, ptr %l176, i32 0, i32 1
  %t461 = load ptr, ptr %t460, !tbaa !27
  %t462 = load i64, ptr %l177, !tbaa !24
  %t463 = mul i64 %t462, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t459, ptr %t461, i64 %t463, i1 false)
  %t464 = load { i64, ptr }, ptr %l178, !tbaa !27
  %t465 = getelementptr { i32, { i64, ptr } }, ptr %l175, i32 0, i32 1
  store { i64, ptr } %t464, ptr %t465, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t466 = load { i32, { i64, ptr } }, ptr %l175
  store { i32, { i64, ptr } } %t466, ptr %rv
  br label %ret
bb67:
  %t467 = load ptr, ptr %l0, !tbaa !29
  store ptr %t467, ptr %l179, !tbaa !29
  %t468 = load i32, ptr %l1, !tbaa !23
  store i32 %t468, ptr %l180, !tbaa !23
  %t469 = load ptr, ptr %l0, !tbaa !29
  %t471 = getelementptr %"compiler/generic:Program", ptr %t469, i32 0, i32 0
  %t472 = load ptr, ptr %t471, !tbaa !29
  %t474 = getelementptr %"compiler/load:Loader", ptr %t472, i32 0, i32 3
  %t475 = load ptr, ptr %t474, !tbaa !29
  %t476 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t479 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v1, ptr %t475, { i64, ptr } %t476)
  store i32 %t479, ptr %l185
  br label %bb68
bb68:
  %t480 = load ptr, ptr %l179, !tbaa !29
  %t481 = load i32, ptr %l180, !tbaa !23
  %t482 = load i32, ptr %l185, !tbaa !23
  %t483 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMemberOf(ptr %v0, ptr %t480, i32 %t481, i32 %t482)
  store i64 %t483, ptr %l186
  br label %bb69
bb69:
  %t484 = load i64, ptr %l186, !tbaa !24
  store i64 %t484, ptr %l6, !tbaa !24
  %t485 = load i64, ptr %l6, !tbaa !24
  %t487 = icmp sge i64 %t485, 0
  br i1 %t487, label %bb70, label %bb71
bb70:
  %t489 = load ptr, ptr %l0, !tbaa !29
  %t490 = load i64, ptr %l6, !tbaa !24
  %t491 = load i32, ptr %l1, !tbaa !23
  %t495 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMemberType(ptr %v0, ptr %t489, i64 %t490, i32 %t491)
  store i32 %t495, ptr %l192
  br label %bb72
bb71:
  br label %bb73
bb72:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d17, i32 0, i32 1) }, ptr %l193, !tbaa !27
  %t496 = load { i64, ptr }, ptr %l193, !tbaa !27
  %t497 = load i32, ptr %l192, !tbaa !23
  %t498 = insertvalue { i32, { i64, ptr } } undef, i32 %t497, 0
  %t500 = insertvalue { i32, { i64, ptr } } %t498, { i64, ptr } %t496, 1
  store { i32, { i64, ptr } } %t500, ptr %l195
  %t501 = getelementptr { i32, { i64, ptr } }, ptr %l195, i32 0, i32 1
  %t502 = load { i64, ptr }, ptr %t501, !tbaa !27
  store { i64, ptr } %t502, ptr %l196, !tbaa !27
  %t503 = load { i64, ptr }, ptr %l196, !tbaa !27
  %t504 = extractvalue { i64, ptr } %t503, 0
  store i64 %t504, ptr %l197, !tbaa !24
  %t505 = load i64, ptr %l197, !tbaa !24
  %t506 = mul i64 %t505, 1
  %t507 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t506)
  %t508 = insertvalue { i64, ptr } undef, i64 %t505, 0
  %t509 = insertvalue { i64, ptr } %t508, ptr %t507, 1
  store { i64, ptr } %t509, ptr %l198, !tbaa !27
  %t510 = getelementptr { i64, ptr }, ptr %l198, i32 0, i32 1
  %t511 = load ptr, ptr %t510, !tbaa !27
  %t512 = getelementptr { i64, ptr }, ptr %l196, i32 0, i32 1
  %t513 = load ptr, ptr %t512, !tbaa !27
  %t514 = load i64, ptr %l197, !tbaa !24
  %t515 = mul i64 %t514, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t511, ptr %t513, i64 %t515, i1 false)
  %t516 = load { i64, ptr }, ptr %l198, !tbaa !27
  %t517 = getelementptr { i32, { i64, ptr } }, ptr %l195, i32 0, i32 1
  store { i64, ptr } %t516, ptr %t517, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t518 = load { i32, { i64, ptr } }, ptr %l195
  store { i32, { i64, ptr } } %t518, ptr %rv
  br label %ret
bb73:
  %t519 = load i64, ptr %l6, !tbaa !24
  %t521 = icmp eq i64 %t519, -2
  br i1 %t521, label %bb74, label %bb75
bb74:
  %t523 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store { i64, ptr } { i64 76, ptr getelementptr inbounds (<{ i64, [76 x i8] }>, ptr @.d18, i32 0, i32 1) }, ptr %l202, !tbaa !27
  %t524 = load { i64, ptr }, ptr %l202, !tbaa !27
  %t526 = insertvalue { i32, { i64, ptr } } undef, i32 %t523, 0
  %t528 = insertvalue { i32, { i64, ptr } } %t526, { i64, ptr } %t524, 1
  store { i32, { i64, ptr } } %t528, ptr %l204
  %t529 = getelementptr { i32, { i64, ptr } }, ptr %l204, i32 0, i32 1
  %t530 = load { i64, ptr }, ptr %t529, !tbaa !27
  store { i64, ptr } %t530, ptr %l205, !tbaa !27
  %t531 = load { i64, ptr }, ptr %l205, !tbaa !27
  %t532 = extractvalue { i64, ptr } %t531, 0
  store i64 %t532, ptr %l206, !tbaa !24
  %t533 = load i64, ptr %l206, !tbaa !24
  %t534 = mul i64 %t533, 1
  %t535 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t534)
  %t536 = insertvalue { i64, ptr } undef, i64 %t533, 0
  %t537 = insertvalue { i64, ptr } %t536, ptr %t535, 1
  store { i64, ptr } %t537, ptr %l207, !tbaa !27
  %t538 = getelementptr { i64, ptr }, ptr %l207, i32 0, i32 1
  %t539 = load ptr, ptr %t538, !tbaa !27
  %t540 = getelementptr { i64, ptr }, ptr %l205, i32 0, i32 1
  %t541 = load ptr, ptr %t540, !tbaa !27
  %t542 = load i64, ptr %l206, !tbaa !24
  %t543 = mul i64 %t542, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t539, ptr %t541, i64 %t543, i1 false)
  %t544 = load { i64, ptr }, ptr %l207, !tbaa !27
  %t545 = getelementptr { i32, { i64, ptr } }, ptr %l204, i32 0, i32 1
  store { i64, ptr } %t544, ptr %t545, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t546 = load { i32, { i64, ptr } }, ptr %l204
  store { i32, { i64, ptr } } %t546, ptr %rv
  br label %ret
bb75:
  br label %bb76
bb76:
  %t547 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t547, ptr %l208, !tbaa !23
  %t548 = load ptr, ptr %l0, !tbaa !29
  %t549 = load i32, ptr %l1, !tbaa !23
  %t552 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eNoMemberWhy(ptr %v0, ptr %v2, ptr %t548, i32 %t549)
  store { i64, ptr } %t552, ptr %l211
  br label %bb77
bb77:
  %t553 = load i32, ptr %l208, !tbaa !23
  %t554 = insertvalue { i32, { i64, ptr } } undef, i32 %t553, 0
  %t555 = load { i64, ptr }, ptr %l211, !tbaa !27
  %t556 = insertvalue { i32, { i64, ptr } } %t554, { i64, ptr } %t555, 1
  call void @__olang_scope_close(ptr %s0)
  store { i32, { i64, ptr } } %t556, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local { { i64, ptr }, { i64, ptr } } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eReflItems(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i64 %a2, i64 %a3, i64 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca [0 x i64]
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l13 = alloca %"compiler/generic:Desc"
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l26 = alloca i32
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l33 = alloca i32
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i64
  %l46 = alloca { i64, ptr }
  %l47 = alloca i32
  %l48 = alloca i1
  %l49 = alloca i64
  %l50 = alloca i64
  %l51 = alloca i64
  %l52 = alloca i64
  %l53 = alloca i64
  %l54 = alloca i64
  %l56 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l63 = alloca i32
  %l67 = alloca [0 x i64]
  %l68 = alloca { i64, ptr }
  %l69 = alloca { i64, ptr }
  %l71 = alloca { { i64, ptr }, { i64, ptr } }
  %l72 = alloca { i64, ptr }
  %l73 = alloca i64
  %l74 = alloca { i64, ptr }
  %l75 = alloca { i64, ptr }
  %l76 = alloca i64
  %l77 = alloca { i64, ptr }
  %l81 = alloca { i64, ptr }
  %l86 = alloca i64
  %l89 = alloca i64
  %l113 = alloca { i64, ptr }
  %l115 = alloca { i64, ptr }
  %l117 = alloca { { i64, ptr }, { i64, ptr } }
  %l118 = alloca { i64, ptr }
  %l119 = alloca i64
  %l120 = alloca { i64, ptr }
  %l121 = alloca { i64, ptr }
  %l122 = alloca i64
  %l123 = alloca { i64, ptr }
  %l130 = alloca { i64, ptr }
  %l131 = alloca { i64, ptr }
  %l133 = alloca { { i64, ptr }, { i64, ptr } }
  %l134 = alloca { i64, ptr }
  %l135 = alloca i64
  %l136 = alloca { i64, ptr }
  %l143 = alloca { i64, ptr }
  %l144 = alloca { i64, ptr }
  %l146 = alloca { { i64, ptr }, { i64, ptr } }
  %l147 = alloca { i64, ptr }
  %l148 = alloca i64
  %l149 = alloca { i64, ptr }
  %l156 = alloca i32
  %l160 = alloca i1
  %l163 = alloca i1
  %l165 = alloca [0 x i64]
  %l166 = alloca { i64, ptr }
  %l167 = alloca { i64, ptr }
  %l169 = alloca { { i64, ptr }, { i64, ptr } }
  %l170 = alloca { i64, ptr }
  %l171 = alloca i64
  %l172 = alloca { i64, ptr }
  %l173 = alloca { i64, ptr }
  %l174 = alloca i64
  %l175 = alloca { i64, ptr }
  %l179 = alloca { i64, ptr }
  %l180 = alloca { i64, ptr }
  %l182 = alloca { { i64, ptr }, { i64, ptr } }
  %l183 = alloca { i64, ptr }
  %l184 = alloca i64
  %l185 = alloca { i64, ptr }
  %l191 = alloca %"compiler/generic:Desc"
  %l198 = alloca %"compiler/generic:fnRow"
  %l206 = alloca i64
  %l209 = alloca i64
  %l233 = alloca { i64, ptr }
  %l235 = alloca { i64, ptr }
  %l237 = alloca { { i64, ptr }, { i64, ptr } }
  %l238 = alloca { i64, ptr }
  %l239 = alloca i64
  %l240 = alloca { i64, ptr }
  %l241 = alloca { i64, ptr }
  %l242 = alloca i64
  %l243 = alloca { i64, ptr }
  %l247 = alloca i32
  %l251 = alloca ptr
  %l255 = alloca i32
  %l256 = alloca { i64, ptr }
  %l261 = alloca i64
  %l264 = alloca i64
  %l288 = alloca { i64, ptr }
  %l290 = alloca { i64, ptr }
  %l292 = alloca { { i64, ptr }, { i64, ptr } }
  %l293 = alloca { i64, ptr }
  %l294 = alloca i64
  %l295 = alloca { i64, ptr }
  %l296 = alloca { i64, ptr }
  %l297 = alloca i64
  %l298 = alloca { i64, ptr }
  %l302 = alloca i32
  %l305 = alloca i32
  %l308 = alloca i32
  %l313 = alloca [0 x i64]
  %l314 = alloca { i64, ptr }
  %l315 = alloca { i64, ptr }
  %l317 = alloca { { i64, ptr }, { i64, ptr } }
  %l318 = alloca { i64, ptr }
  %l319 = alloca i64
  %l320 = alloca { i64, ptr }
  %l321 = alloca { i64, ptr }
  %l322 = alloca i64
  %l323 = alloca { i64, ptr }
  %l325 = alloca ptr
  %l329 = alloca i32
  %l330 = alloca { i64, ptr }
  %l335 = alloca i64
  %l338 = alloca i64
  %l362 = alloca { i64, ptr }
  %l364 = alloca { i64, ptr }
  %l366 = alloca { { i64, ptr }, { i64, ptr } }
  %l367 = alloca { i64, ptr }
  %l368 = alloca i64
  %l369 = alloca { i64, ptr }
  %l370 = alloca { i64, ptr }
  %l371 = alloca i64
  %l372 = alloca { i64, ptr }
  %l375 = alloca i32
  %l382 = alloca i32
  %l387 = alloca { i64, ptr }
  %l392 = alloca i64
  %l395 = alloca i64
  %l419 = alloca { i64, ptr }
  %l421 = alloca { i64, ptr }
  %l423 = alloca { { i64, ptr }, { i64, ptr } }
  %l424 = alloca { i64, ptr }
  %l425 = alloca i64
  %l426 = alloca { i64, ptr }
  %l427 = alloca { i64, ptr }
  %l428 = alloca i64
  %l429 = alloca { i64, ptr }
  %l432 = alloca i1
  %l436 = alloca { i64, ptr }
  %l441 = alloca i64
  %l444 = alloca i64
  %l468 = alloca { i64, ptr }
  %l470 = alloca { i64, ptr }
  %l472 = alloca { { i64, ptr }, { i64, ptr } }
  %l473 = alloca { i64, ptr }
  %l474 = alloca i64
  %l475 = alloca { i64, ptr }
  %l476 = alloca { i64, ptr }
  %l477 = alloca i64
  %l478 = alloca { i64, ptr }
  %l481 = alloca i1
  %l482 = alloca { i64, ptr }
  %l483 = alloca { i64, ptr }
  %l485 = alloca { { i64, ptr }, { i64, ptr } }
  %l486 = alloca { i64, ptr }
  %l487 = alloca i64
  %l488 = alloca { i64, ptr }
  %l489 = alloca { i64, ptr }
  %l490 = alloca i64
  %l491 = alloca { i64, ptr }
  %l492 = alloca [0 x i64]
  %l493 = alloca { i64, ptr }
  %l494 = alloca { i64, ptr }
  %l496 = alloca { { i64, ptr }, { i64, ptr } }
  %l497 = alloca { i64, ptr }
  %l498 = alloca i64
  %l499 = alloca { i64, ptr }
  %l500 = alloca { i64, ptr }
  %l501 = alloca i64
  %l502 = alloca { i64, ptr }
  %l503 = alloca i64
  %l505 = alloca [0 x i32]
  %l506 = alloca i64
  %l508 = alloca { i64, ptr }
  %l512 = alloca i32
  %l515 = alloca i1
  %l518 = alloca [0 x i64]
  %l519 = alloca { i64, ptr }
  %l520 = alloca { i64, ptr }
  %l522 = alloca { { i64, ptr }, { i64, ptr } }
  %l523 = alloca { i64, ptr }
  %l524 = alloca i64
  %l525 = alloca { i64, ptr }
  %l526 = alloca { i64, ptr }
  %l527 = alloca i64
  %l528 = alloca { i64, ptr }
  %l531 = alloca i1
  %l534 = alloca { i64, ptr }
  %l536 = alloca { i64, ptr }
  %l538 = alloca i64
  %l542 = alloca i1
  %l543 = alloca i1
  %l549 = alloca { i64, ptr }
  %l551 = alloca { i64, ptr }
  %l553 = alloca i64
  %l557 = alloca i1
  %l558 = alloca [0 x i64]
  %l559 = alloca { i64, ptr }
  %l560 = alloca { i64, ptr }
  %l562 = alloca { { i64, ptr }, { i64, ptr } }
  %l563 = alloca { i64, ptr }
  %l564 = alloca i64
  %l565 = alloca { i64, ptr }
  %l566 = alloca { i64, ptr }
  %l567 = alloca i64
  %l568 = alloca { i64, ptr }
  %l569 = alloca [0 x i64]
  %l570 = alloca { i64, ptr }
  %l571 = alloca { i64, ptr }
  %l573 = alloca { { i64, ptr }, { i64, ptr } }
  %l574 = alloca { i64, ptr }
  %l575 = alloca i64
  %l576 = alloca { i64, ptr }
  %l577 = alloca { i64, ptr }
  %l578 = alloca i64
  %l579 = alloca { i64, ptr }
  %l583 = alloca i1
  %l584 = alloca i1
  %l585 = alloca ptr
  %l588 = alloca i32
  %l589 = alloca i1
  %l592 = alloca i32
  %l594 = alloca ptr
  %l598 = alloca i32
  %l599 = alloca i64
  %l602 = alloca i1
  %l605 = alloca i1
  %l607 = alloca i1
  %l610 = alloca ptr
  %l612 = alloca ptr
  %l616 = alloca i32
  %l617 = alloca i64
  %l618 = alloca ptr
  %l621 = alloca i1
  %l624 = alloca i1
  %l625 = alloca i64
  %l629 = alloca i64
  %l631 = alloca i1
  %l636 = alloca ptr
  %l644 = alloca i64
  %l647 = alloca i64
  %l666 = alloca i1
  %l670 = alloca { i64, ptr }
  %l671 = alloca { i64, ptr }
  %l673 = alloca i1
  %l680 = alloca { i64, ptr }
  %l682 = alloca { i64, ptr }
  %l684 = alloca { { i64, ptr }, { i64, ptr } }
  %l685 = alloca { i64, ptr }
  %l686 = alloca i64
  %l687 = alloca { i64, ptr }
  %l688 = alloca { i64, ptr }
  %l689 = alloca i64
  %l690 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %s24 = alloca %olang.scope
  %s25 = alloca %olang.scope
  %s28 = alloca %olang.scope
  %s29 = alloca %olang.scope
  %s33 = alloca %olang.scope
  %s39 = alloca %olang.scope
  %s40 = alloca %olang.scope
  %s43 = alloca %olang.scope
  %rv = alloca { { i64, ptr }, { i64, ptr } }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i64 %a2, ptr %l2
  store i64 %a3, ptr %l3
  store i64 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store [0 x i64] zeroinitializer, ptr %l5
  %t2 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l56
  br label %bb1
bb1:
  %t3 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l56
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %l6
  %t4 = load i64, ptr %l2, !tbaa !24
  %t5 = load i64, ptr @G_2ecompiler_2fgeneric_2eListResults, !tbaa !24
  %t8 = icmp eq i64 %t4, %t5
  br i1 %t8, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/generic:Program", ptr %t10, i32 0, i32 2
  %t13 = load i32, ptr %l1, !tbaa !23
  %t16 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t12, i32 %t13)
  store i32 %t16, ptr %l63
  br label %bb4
bb3:
  br label %bb23
bb4:
  %t17 = load i32, ptr %l63, !range !{i32 0, i32 33}
  %t19 = trunc i64 21 to i32
  %t20 = icmp eq i32 %t17, %t19
  %t22 = xor i1 %t20, true
  br i1 %t22, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s2
  %t24 = load [0 x i64], ptr %l5
  store [0 x i64] %t24, ptr %l67
  %t25 = mul i64 0, 8
  %t26 = insertvalue { i64, ptr } undef, i64 0, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t27, ptr %l68, !tbaa !27
  %t28 = getelementptr { i64, ptr }, ptr %l68, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !27
  %t30 = mul i64 0, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t29, ptr %l67, i64 %t30, i1 false)
  store { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d19, i32 0, i32 1) }, ptr %l69, !tbaa !27
  %t31 = load { i64, ptr }, ptr %l69, !tbaa !27
  %t32 = load { i64, ptr }, ptr %l68, !tbaa !27
  %t33 = insertvalue { { i64, ptr }, { i64, ptr } } undef, { i64, ptr } %t32, 0
  %t35 = insertvalue { { i64, ptr }, { i64, ptr } } %t33, { i64, ptr } %t31, 1
  store { { i64, ptr }, { i64, ptr } } %t35, ptr %l71
  %t36 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l71, i32 0, i32 0
  %t37 = load { i64, ptr }, ptr %t36, !tbaa !27
  store { i64, ptr } %t37, ptr %l72, !tbaa !27
  %t38 = load { i64, ptr }, ptr %l72, !tbaa !27
  %t39 = extractvalue { i64, ptr } %t38, 0
  store i64 %t39, ptr %l73, !tbaa !24
  %t40 = load i64, ptr %l73, !tbaa !24
  %t41 = mul i64 %t40, 8
  %t42 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t41)
  %t43 = insertvalue { i64, ptr } undef, i64 %t40, 0
  %t44 = insertvalue { i64, ptr } %t43, ptr %t42, 1
  store { i64, ptr } %t44, ptr %l74, !tbaa !27
  %t45 = getelementptr { i64, ptr }, ptr %l74, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !27
  %t47 = getelementptr { i64, ptr }, ptr %l72, i32 0, i32 1
  %t48 = load ptr, ptr %t47, !tbaa !27
  %t49 = load i64, ptr %l73, !tbaa !24
  %t50 = mul i64 %t49, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t46, ptr %t48, i64 %t50, i1 false)
  %t51 = load { i64, ptr }, ptr %l74, !tbaa !27
  %t52 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l71, i32 0, i32 0
  store { i64, ptr } %t51, ptr %t52, !tbaa !27
  %t53 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l71, i32 0, i32 1
  %t54 = load { i64, ptr }, ptr %t53, !tbaa !27
  store { i64, ptr } %t54, ptr %l75, !tbaa !27
  %t55 = load { i64, ptr }, ptr %l75, !tbaa !27
  %t56 = extractvalue { i64, ptr } %t55, 0
  store i64 %t56, ptr %l76, !tbaa !24
  %t57 = load i64, ptr %l76, !tbaa !24
  %t58 = mul i64 %t57, 1
  %t59 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t58)
  %t60 = insertvalue { i64, ptr } undef, i64 %t57, 0
  %t61 = insertvalue { i64, ptr } %t60, ptr %t59, 1
  store { i64, ptr } %t61, ptr %l77, !tbaa !27
  %t62 = getelementptr { i64, ptr }, ptr %l77, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !27
  %t64 = getelementptr { i64, ptr }, ptr %l75, i32 0, i32 1
  %t65 = load ptr, ptr %t64, !tbaa !27
  %t66 = load i64, ptr %l76, !tbaa !24
  %t67 = mul i64 %t66, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t63, ptr %t65, i64 %t67, i1 false)
  %t68 = load { i64, ptr }, ptr %l77, !tbaa !27
  %t69 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l71, i32 0, i32 1
  store { i64, ptr } %t68, ptr %t69, !tbaa !27
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t70 = load { { i64, ptr }, { i64, ptr } }, ptr %l71
  store { { i64, ptr }, { i64, ptr } } %t70, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s3
  store i64 0, ptr %l7, !tbaa !24
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/generic:Program", ptr %t71, i32 0, i32 2
  %t74 = load i32, ptr %l1, !tbaa !23
  %t77 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResults(ptr %v0, ptr %s3, ptr %t73, i32 %t74)
  store { i64, ptr } %t77, ptr %l81
  br label %bb8
bb8:
  %t78 = load { i64, ptr }, ptr %l81, !tbaa !27
  %t79 = extractvalue { i64, ptr } %t78, 0
  store i64 %t79, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t81 = load i64, ptr %l8, !tbaa !24
  %t82 = load i64, ptr %l7, !tbaa !24
  %t85 = icmp sgt i64 %t81, %t82
  br i1 %t85, label %bb9, label %bb10
bb9:
  %t87 = load i64, ptr %l9, !tbaa !24
  %t89 = icmp sgt i64 %t87, 0
  br i1 %t89, label %bb11, label %bb12
bb10:
  store i64 0, ptr %l86, !tbaa !24
  br label %bb14
bb11:
  %t91 = load i64, ptr %l8, !tbaa !24
  %t92 = load i64, ptr %l7, !tbaa !24
  %t95 = sub i64 %t91, %t92
  %t96 = load i64, ptr %l9, !tbaa !24
  %t99 = add i64 %t95, %t96
  %t101 = sub i64 %t99, 1
  %t102 = load i64, ptr %l9, !tbaa !24
  %t105 = sdiv i64 %t101, %t102
  store i64 %t105, ptr %l89, !tbaa !24
  br label %bb13
bb12:
  store i64 0, ptr %l89, !tbaa !24
  br label %bb13
bb13:
  %t107 = load i64, ptr %l89, !tbaa !24
  store i64 %t107, ptr %l86, !tbaa !24
  br label %bb14
bb14:
  %t108 = load i64, ptr %l86, !tbaa !24
  store i64 %t108, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb15
bb15:
  %t109 = load i64, ptr %l11, !tbaa !24
  %t110 = load i64, ptr %l10, !tbaa !24
  %t113 = icmp slt i64 %t109, %t110
  %t115 = xor i1 %t113, true
  br i1 %t115, label %bb16, label %bb17
bb16:
  br label %bb21
bb17:
  br label %bb18
bb18:
  %t117 = load i64, ptr %l7, !tbaa !24
  %t118 = load i64, ptr %l11, !tbaa !24
  %t119 = load i64, ptr %l9, !tbaa !24
  %t122 = mul i64 %t118, %t119
  %t125 = add i64 %t117, %t122
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l6, i64 %t125)
  br label %bb19
bb19:
  br label %bb20
bb20:
  %t130 = load i64, ptr %l11, !tbaa !24
  %t133 = add i64 %t130, 1
  store i64 %t133, ptr %l11, !tbaa !24
  br label %bb15
bb21:
  call void @__olang_scope_close(ptr %s3)
  %t136 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eToArray_3cI64_3e(ptr %s0, ptr %s1, ptr %l6)
  store { i64, ptr } %t136, ptr %l113
  br label %bb22
bb22:
  %t137 = load { i64, ptr }, ptr %l113, !tbaa !27
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d20, i32 0, i32 1) }, ptr %l115, !tbaa !27
  %t138 = load { i64, ptr }, ptr %l115, !tbaa !27
  %t140 = insertvalue { { i64, ptr }, { i64, ptr } } undef, { i64, ptr } %t137, 0
  %t142 = insertvalue { { i64, ptr }, { i64, ptr } } %t140, { i64, ptr } %t138, 1
  store { { i64, ptr }, { i64, ptr } } %t142, ptr %l117
  %t143 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l117, i32 0, i32 0
  %t144 = load { i64, ptr }, ptr %t143, !tbaa !27
  store { i64, ptr } %t144, ptr %l118, !tbaa !27
  %t145 = load { i64, ptr }, ptr %l118, !tbaa !27
  %t146 = extractvalue { i64, ptr } %t145, 0
  store i64 %t146, ptr %l119, !tbaa !24
  %t147 = load i64, ptr %l119, !tbaa !24
  %t148 = mul i64 %t147, 8
  %t149 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t148)
  %t150 = insertvalue { i64, ptr } undef, i64 %t147, 0
  %t151 = insertvalue { i64, ptr } %t150, ptr %t149, 1
  store { i64, ptr } %t151, ptr %l120, !tbaa !27
  %t152 = getelementptr { i64, ptr }, ptr %l120, i32 0, i32 1
  %t153 = load ptr, ptr %t152, !tbaa !27
  %t154 = getelementptr { i64, ptr }, ptr %l118, i32 0, i32 1
  %t155 = load ptr, ptr %t154, !tbaa !27
  %t156 = load i64, ptr %l119, !tbaa !24
  %t157 = mul i64 %t156, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t153, ptr %t155, i64 %t157, i1 false)
  %t158 = load { i64, ptr }, ptr %l120, !tbaa !27
  %t159 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l117, i32 0, i32 0
  store { i64, ptr } %t158, ptr %t159, !tbaa !27
  %t160 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l117, i32 0, i32 1
  %t161 = load { i64, ptr }, ptr %t160, !tbaa !27
  store { i64, ptr } %t161, ptr %l121, !tbaa !27
  %t162 = load { i64, ptr }, ptr %l121, !tbaa !27
  %t163 = extractvalue { i64, ptr } %t162, 0
  store i64 %t163, ptr %l122, !tbaa !24
  %t164 = load i64, ptr %l122, !tbaa !24
  %t165 = mul i64 %t164, 1
  %t166 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t165)
  %t167 = insertvalue { i64, ptr } undef, i64 %t164, 0
  %t168 = insertvalue { i64, ptr } %t167, ptr %t166, 1
  store { i64, ptr } %t168, ptr %l123, !tbaa !27
  %t169 = getelementptr { i64, ptr }, ptr %l123, i32 0, i32 1
  %t170 = load ptr, ptr %t169, !tbaa !27
  %t171 = getelementptr { i64, ptr }, ptr %l121, i32 0, i32 1
  %t172 = load ptr, ptr %t171, !tbaa !27
  %t173 = load i64, ptr %l122, !tbaa !24
  %t174 = mul i64 %t173, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t170, ptr %t172, i64 %t174, i1 false)
  %t175 = load { i64, ptr }, ptr %l123, !tbaa !27
  %t176 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l117, i32 0, i32 1
  store { i64, ptr } %t175, ptr %t176, !tbaa !27
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t177 = load { { i64, ptr }, { i64, ptr } }, ptr %l117
  store { { i64, ptr }, { i64, ptr } } %t177, ptr %rv
  br label %ret
bb23:
  %t178 = load i64, ptr %l2, !tbaa !24
  %t179 = load i64, ptr @G_2ecompiler_2fgeneric_2eListFunctions, !tbaa !24
  %t182 = icmp eq i64 %t178, %t179
  br i1 %t182, label %bb24, label %bb25
bb24:
  %t184 = load ptr, ptr %l0, !tbaa !29
  %t185 = load i64, ptr %l3, !tbaa !24
  %t186 = load i64, ptr %l4, !tbaa !24
  %t190 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eModuleFns(ptr %v0, ptr %v1, ptr %t184, i64 %t185, i64 %t186)
  store { i64, ptr } %t190, ptr %l130
  br label %bb26
bb25:
  br label %bb27
bb26:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d21, i32 0, i32 1) }, ptr %l131, !tbaa !27
  %t191 = load { i64, ptr }, ptr %l131, !tbaa !27
  %t192 = load { i64, ptr }, ptr %l130, !tbaa !27
  %t193 = insertvalue { { i64, ptr }, { i64, ptr } } undef, { i64, ptr } %t192, 0
  %t195 = insertvalue { { i64, ptr }, { i64, ptr } } %t193, { i64, ptr } %t191, 1
  store { { i64, ptr }, { i64, ptr } } %t195, ptr %l133
  %t196 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l133, i32 0, i32 1
  %t197 = load { i64, ptr }, ptr %t196, !tbaa !27
  store { i64, ptr } %t197, ptr %l134, !tbaa !27
  %t198 = load { i64, ptr }, ptr %l134, !tbaa !27
  %t199 = extractvalue { i64, ptr } %t198, 0
  store i64 %t199, ptr %l135, !tbaa !24
  %t200 = load i64, ptr %l135, !tbaa !24
  %t201 = mul i64 %t200, 1
  %t202 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t201)
  %t203 = insertvalue { i64, ptr } undef, i64 %t200, 0
  %t204 = insertvalue { i64, ptr } %t203, ptr %t202, 1
  store { i64, ptr } %t204, ptr %l136, !tbaa !27
  %t205 = getelementptr { i64, ptr }, ptr %l136, i32 0, i32 1
  %t206 = load ptr, ptr %t205, !tbaa !27
  %t207 = getelementptr { i64, ptr }, ptr %l134, i32 0, i32 1
  %t208 = load ptr, ptr %t207, !tbaa !27
  %t209 = load i64, ptr %l135, !tbaa !24
  %t210 = mul i64 %t209, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t206, ptr %t208, i64 %t210, i1 false)
  %t211 = load { i64, ptr }, ptr %l136, !tbaa !27
  %t212 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l133, i32 0, i32 1
  store { i64, ptr } %t211, ptr %t212, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t213 = load { { i64, ptr }, { i64, ptr } }, ptr %l133
  store { { i64, ptr }, { i64, ptr } } %t213, ptr %rv
  br label %ret
bb27:
  %t214 = load i64, ptr %l2, !tbaa !24
  %t215 = load i64, ptr @G_2ecompiler_2fgeneric_2eListBuilders, !tbaa !24
  %t218 = icmp eq i64 %t214, %t215
  br i1 %t218, label %bb28, label %bb29
bb28:
  %t220 = load ptr, ptr %l0, !tbaa !29
  %t221 = load i32, ptr %l1, !tbaa !23
  %t222 = load i64, ptr %l4, !tbaa !24
  %t226 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeBuilders(ptr %v0, ptr %v1, ptr %t220, i32 %t221, i64 %t222)
  store { i64, ptr } %t226, ptr %l143
  br label %bb30
bb29:
  br label %bb31
bb30:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d22, i32 0, i32 1) }, ptr %l144, !tbaa !27
  %t227 = load { i64, ptr }, ptr %l144, !tbaa !27
  %t228 = load { i64, ptr }, ptr %l143, !tbaa !27
  %t229 = insertvalue { { i64, ptr }, { i64, ptr } } undef, { i64, ptr } %t228, 0
  %t231 = insertvalue { { i64, ptr }, { i64, ptr } } %t229, { i64, ptr } %t227, 1
  store { { i64, ptr }, { i64, ptr } } %t231, ptr %l146
  %t232 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l146, i32 0, i32 1
  %t233 = load { i64, ptr }, ptr %t232, !tbaa !27
  store { i64, ptr } %t233, ptr %l147, !tbaa !27
  %t234 = load { i64, ptr }, ptr %l147, !tbaa !27
  %t235 = extractvalue { i64, ptr } %t234, 0
  store i64 %t235, ptr %l148, !tbaa !24
  %t236 = load i64, ptr %l148, !tbaa !24
  %t237 = mul i64 %t236, 1
  %t238 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t237)
  %t239 = insertvalue { i64, ptr } undef, i64 %t236, 0
  %t240 = insertvalue { i64, ptr } %t239, ptr %t238, 1
  store { i64, ptr } %t240, ptr %l149, !tbaa !27
  %t241 = getelementptr { i64, ptr }, ptr %l149, i32 0, i32 1
  %t242 = load ptr, ptr %t241, !tbaa !27
  %t243 = getelementptr { i64, ptr }, ptr %l147, i32 0, i32 1
  %t244 = load ptr, ptr %t243, !tbaa !27
  %t245 = load i64, ptr %l148, !tbaa !24
  %t246 = mul i64 %t245, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t242, ptr %t244, i64 %t246, i1 false)
  %t247 = load { i64, ptr }, ptr %l149, !tbaa !27
  %t248 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l146, i32 0, i32 1
  store { i64, ptr } %t247, ptr %t248, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t249 = load { { i64, ptr }, { i64, ptr } }, ptr %l146
  store { { i64, ptr }, { i64, ptr } } %t249, ptr %rv
  br label %ret
bb31:
  %t250 = load i64, ptr %l2, !tbaa !24
  %t251 = load i64, ptr @G_2ecompiler_2fgeneric_2eListMethods, !tbaa !24
  %t254 = icmp eq i64 %t250, %t251
  br i1 %t254, label %bb32, label %bb33
bb32:
  %t256 = load ptr, ptr %l0, !tbaa !29
  %t258 = getelementptr %"compiler/generic:Program", ptr %t256, i32 0, i32 2
  %t259 = load i32, ptr %l1, !tbaa !23
  %t262 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t258, i32 %t259)
  store i32 %t262, ptr %l156
  br label %bb34
bb33:
  br label %bb43
bb34:
  %t263 = load i32, ptr %l156, !range !{i32 0, i32 33}
  %t265 = trunc i64 18 to i32
  %t266 = icmp eq i32 %t263, %t265
  %t268 = xor i1 %t266, true
  br i1 %t268, label %bb35, label %bb36
bb35:
  store i1 true, ptr %l160, !tbaa !21
  br label %bb38
bb36:
  %t270 = load ptr, ptr %l0, !tbaa !29
  %t271 = load i32, ptr %l1, !tbaa !23
  %t274 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %t270, i32 %t271)
  store i1 %t274, ptr %l163
  br label %bb37
bb37:
  %t275 = load i1, ptr %l163, !tbaa !21
  %t276 = xor i1 %t275, true
  store i1 %t276, ptr %l160, !tbaa !21
  br label %bb38
bb38:
  %t278 = load i1, ptr %l160, !tbaa !21
  br i1 %t278, label %bb39, label %bb40
bb39:
  store %olang.scope zeroinitializer, ptr %s9
  %t279 = load [0 x i64], ptr %l5
  store [0 x i64] %t279, ptr %l165
  %t280 = mul i64 0, 8
  %t281 = insertvalue { i64, ptr } undef, i64 0, 0
  %t282 = insertvalue { i64, ptr } %t281, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t282, ptr %l166, !tbaa !27
  %t283 = getelementptr { i64, ptr }, ptr %l166, i32 0, i32 1
  %t284 = load ptr, ptr %t283, !tbaa !27
  %t285 = mul i64 0, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t284, ptr %l165, i64 %t285, i1 false)
  store { i64, ptr } { i64 50, ptr getelementptr inbounds (<{ i64, [50 x i8] }>, ptr @.d23, i32 0, i32 1) }, ptr %l167, !tbaa !27
  %t286 = load { i64, ptr }, ptr %l167, !tbaa !27
  %t287 = load { i64, ptr }, ptr %l166, !tbaa !27
  %t288 = insertvalue { { i64, ptr }, { i64, ptr } } undef, { i64, ptr } %t287, 0
  %t290 = insertvalue { { i64, ptr }, { i64, ptr } } %t288, { i64, ptr } %t286, 1
  store { { i64, ptr }, { i64, ptr } } %t290, ptr %l169
  %t291 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l169, i32 0, i32 0
  %t292 = load { i64, ptr }, ptr %t291, !tbaa !27
  store { i64, ptr } %t292, ptr %l170, !tbaa !27
  %t293 = load { i64, ptr }, ptr %l170, !tbaa !27
  %t294 = extractvalue { i64, ptr } %t293, 0
  store i64 %t294, ptr %l171, !tbaa !24
  %t295 = load i64, ptr %l171, !tbaa !24
  %t296 = mul i64 %t295, 8
  %t297 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t296)
  %t298 = insertvalue { i64, ptr } undef, i64 %t295, 0
  %t299 = insertvalue { i64, ptr } %t298, ptr %t297, 1
  store { i64, ptr } %t299, ptr %l172, !tbaa !27
  %t300 = getelementptr { i64, ptr }, ptr %l172, i32 0, i32 1
  %t301 = load ptr, ptr %t300, !tbaa !27
  %t302 = getelementptr { i64, ptr }, ptr %l170, i32 0, i32 1
  %t303 = load ptr, ptr %t302, !tbaa !27
  %t304 = load i64, ptr %l171, !tbaa !24
  %t305 = mul i64 %t304, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t301, ptr %t303, i64 %t305, i1 false)
  %t306 = load { i64, ptr }, ptr %l172, !tbaa !27
  %t307 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l169, i32 0, i32 0
  store { i64, ptr } %t306, ptr %t307, !tbaa !27
  %t308 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l169, i32 0, i32 1
  %t309 = load { i64, ptr }, ptr %t308, !tbaa !27
  store { i64, ptr } %t309, ptr %l173, !tbaa !27
  %t310 = load { i64, ptr }, ptr %l173, !tbaa !27
  %t311 = extractvalue { i64, ptr } %t310, 0
  store i64 %t311, ptr %l174, !tbaa !24
  %t312 = load i64, ptr %l174, !tbaa !24
  %t313 = mul i64 %t312, 1
  %t314 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t313)
  %t315 = insertvalue { i64, ptr } undef, i64 %t312, 0
  %t316 = insertvalue { i64, ptr } %t315, ptr %t314, 1
  store { i64, ptr } %t316, ptr %l175, !tbaa !27
  %t317 = getelementptr { i64, ptr }, ptr %l175, i32 0, i32 1
  %t318 = load ptr, ptr %t317, !tbaa !27
  %t319 = getelementptr { i64, ptr }, ptr %l173, i32 0, i32 1
  %t320 = load ptr, ptr %t319, !tbaa !27
  %t321 = load i64, ptr %l174, !tbaa !24
  %t322 = mul i64 %t321, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t318, ptr %t320, i64 %t322, i1 false)
  %t323 = load { i64, ptr }, ptr %l175, !tbaa !27
  %t324 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l169, i32 0, i32 1
  store { i64, ptr } %t323, ptr %t324, !tbaa !27
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s0)
  %t325 = load { { i64, ptr }, { i64, ptr } }, ptr %l169
  store { { i64, ptr }, { i64, ptr } } %t325, ptr %rv
  br label %ret
bb40:
  br label %bb41
bb41:
  %t326 = load ptr, ptr %l0, !tbaa !29
  %t327 = load i32, ptr %l1, !tbaa !23
  %t328 = load i64, ptr %l4, !tbaa !24
  %t332 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeMethods(ptr %v0, ptr %v1, ptr %t326, i32 %t327, i64 %t328)
  store { i64, ptr } %t332, ptr %l179
  br label %bb42
bb42:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d24, i32 0, i32 1) }, ptr %l180, !tbaa !27
  %t333 = load { i64, ptr }, ptr %l180, !tbaa !27
  %t334 = load { i64, ptr }, ptr %l179, !tbaa !27
  %t335 = insertvalue { { i64, ptr }, { i64, ptr } } undef, { i64, ptr } %t334, 0
  %t337 = insertvalue { { i64, ptr }, { i64, ptr } } %t335, { i64, ptr } %t333, 1
  store { { i64, ptr }, { i64, ptr } } %t337, ptr %l182
  %t338 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l182, i32 0, i32 1
  %t339 = load { i64, ptr }, ptr %t338, !tbaa !27
  store { i64, ptr } %t339, ptr %l183, !tbaa !27
  %t340 = load { i64, ptr }, ptr %l183, !tbaa !27
  %t341 = extractvalue { i64, ptr } %t340, 0
  store i64 %t341, ptr %l184, !tbaa !24
  %t342 = load i64, ptr %l184, !tbaa !24
  %t343 = mul i64 %t342, 1
  %t344 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t343)
  %t345 = insertvalue { i64, ptr } undef, i64 %t342, 0
  %t346 = insertvalue { i64, ptr } %t345, ptr %t344, 1
  store { i64, ptr } %t346, ptr %l185, !tbaa !27
  %t347 = getelementptr { i64, ptr }, ptr %l185, i32 0, i32 1
  %t348 = load ptr, ptr %t347, !tbaa !27
  %t349 = getelementptr { i64, ptr }, ptr %l183, i32 0, i32 1
  %t350 = load ptr, ptr %t349, !tbaa !27
  %t351 = load i64, ptr %l184, !tbaa !24
  %t352 = mul i64 %t351, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t348, ptr %t350, i64 %t352, i1 false)
  %t353 = load { i64, ptr }, ptr %l185, !tbaa !27
  %t354 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l182, i32 0, i32 1
  store { i64, ptr } %t353, ptr %t354, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t355 = load { { i64, ptr }, { i64, ptr } }, ptr %l182
  store { { i64, ptr }, { i64, ptr } } %t355, ptr %rv
  br label %ret
bb43:
  %t356 = load i64, ptr %l2, !tbaa !24
  %t357 = load i64, ptr @G_2ecompiler_2fgeneric_2eListParams, !tbaa !24
  %t360 = icmp eq i64 %t356, %t357
  br i1 %t360, label %bb44, label %bb45
bb44:
  store %olang.scope zeroinitializer, ptr %s10
  %t362 = load ptr, ptr %l0, !tbaa !29
  %t363 = load i32, ptr %l1, !tbaa !23
  %t366 = call %"compiler/generic:Desc" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDescOf(ptr %v0, ptr %t362, i32 %t363)
  store %"compiler/generic:Desc" %t366, ptr %l191
  br label %bb46
bb45:
  br label %bb109
bb46:
  %t367 = load %"compiler/generic:Desc", ptr %l191
  store %"compiler/generic:Desc" %t367, ptr %l13
  %t368 = getelementptr %"compiler/generic:Desc", ptr %l13, i32 0, i32 0
  %t369 = load i64, ptr %t368, !tbaa !24
  %t370 = load i64, ptr @G_2ecompiler_2fgeneric_2eDescFunc, !tbaa !24
  %t373 = icmp eq i64 %t369, %t370
  br i1 %t373, label %bb47, label %bb48
bb47:
  store %olang.scope zeroinitializer, ptr %s11
  store i64 0, ptr %l14, !tbaa !24
  %t375 = load ptr, ptr %l0, !tbaa !29
  %t377 = getelementptr %"compiler/generic:Program", ptr %t375, i32 0, i32 31
  %t378 = getelementptr %"compiler/generic:Desc", ptr %l13, i32 0, i32 2
  %t379 = load i64, ptr %t378, !tbaa !24
  %t382 = call %"compiler/generic:fnRow" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3afnRow_3e_2eAt_3ccompiler_2fgeneric_3afnRow_3e(ptr %v0, ptr %v0, ptr %t377, i64 %t379)
  store %"compiler/generic:fnRow" %t382, ptr %l198
  br label %bb49
bb48:
  br label %bb64
bb49:
  %t383 = getelementptr %"compiler/generic:fnRow", ptr %l198, i32 0, i32 1
  %t384 = load ptr, ptr %t383, !tbaa !29
  %t386 = getelementptr %"compiler/ast:Func", ptr %t384, i32 0, i32 3
  %t387 = load ptr, ptr %t386, !tbaa !29
  %t389 = getelementptr %"compiler/ast:Sig", ptr %t387, i32 0, i32 0
  %t390 = load { i64, ptr }, ptr %t389, !tbaa !27
  %t392 = extractvalue { i64, ptr } %t390, 0
  store i64 %t392, ptr %l15, !tbaa !24
  store i64 1, ptr %l16, !tbaa !24
  %t394 = load i64, ptr %l15, !tbaa !24
  %t395 = load i64, ptr %l14, !tbaa !24
  %t398 = icmp sgt i64 %t394, %t395
  br i1 %t398, label %bb50, label %bb51
bb50:
  %t400 = load i64, ptr %l16, !tbaa !24
  %t402 = icmp sgt i64 %t400, 0
  br i1 %t402, label %bb52, label %bb53
bb51:
  store i64 0, ptr %l206, !tbaa !24
  br label %bb55
bb52:
  %t404 = load i64, ptr %l15, !tbaa !24
  %t405 = load i64, ptr %l14, !tbaa !24
  %t408 = sub i64 %t404, %t405
  %t409 = load i64, ptr %l16, !tbaa !24
  %t412 = add i64 %t408, %t409
  %t414 = sub i64 %t412, 1
  %t415 = load i64, ptr %l16, !tbaa !24
  %t418 = sdiv i64 %t414, %t415
  store i64 %t418, ptr %l209, !tbaa !24
  br label %bb54
bb53:
  store i64 0, ptr %l209, !tbaa !24
  br label %bb54
bb54:
  %t420 = load i64, ptr %l209, !tbaa !24
  store i64 %t420, ptr %l206, !tbaa !24
  br label %bb55
bb55:
  %t421 = load i64, ptr %l206, !tbaa !24
  store i64 %t421, ptr %l17, !tbaa !24
  store i64 0, ptr %l18, !tbaa !24
  br label %bb56
bb56:
  %t422 = load i64, ptr %l18, !tbaa !24
  %t423 = load i64, ptr %l17, !tbaa !24
  %t426 = icmp slt i64 %t422, %t423
  %t428 = xor i1 %t426, true
  br i1 %t428, label %bb57, label %bb58
bb57:
  br label %bb62
bb58:
  br label %bb59
bb59:
  %t430 = load i64, ptr %l14, !tbaa !24
  %t431 = load i64, ptr %l18, !tbaa !24
  %t432 = load i64, ptr %l16, !tbaa !24
  %t435 = mul i64 %t431, %t432
  %t438 = add i64 %t430, %t435
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l6, i64 %t438)
  br label %bb60
bb60:
  br label %bb61
bb61:
  %t443 = load i64, ptr %l18, !tbaa !24
  %t446 = add i64 %t443, 1
  store i64 %t446, ptr %l18, !tbaa !24
  br label %bb56
bb62:
  %t449 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eToArray_3cI64_3e(ptr %s0, ptr %s11, ptr %l6)
  store { i64, ptr } %t449, ptr %l233
  br label %bb63
bb63:
  %t450 = load { i64, ptr }, ptr %l233, !tbaa !27
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d25, i32 0, i32 1) }, ptr %l235, !tbaa !27
  %t451 = load { i64, ptr }, ptr %l235, !tbaa !27
  %t453 = insertvalue { { i64, ptr }, { i64, ptr } } undef, { i64, ptr } %t450, 0
  %t455 = insertvalue { { i64, ptr }, { i64, ptr } } %t453, { i64, ptr } %t451, 1
  store { { i64, ptr }, { i64, ptr } } %t455, ptr %l237
  %t456 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l237, i32 0, i32 0
  %t457 = load { i64, ptr }, ptr %t456, !tbaa !27
  store { i64, ptr } %t457, ptr %l238, !tbaa !27
  %t458 = load { i64, ptr }, ptr %l238, !tbaa !27
  %t459 = extractvalue { i64, ptr } %t458, 0
  store i64 %t459, ptr %l239, !tbaa !24
  %t460 = load i64, ptr %l239, !tbaa !24
  %t461 = mul i64 %t460, 8
  %t462 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t461)
  %t463 = insertvalue { i64, ptr } undef, i64 %t460, 0
  %t464 = insertvalue { i64, ptr } %t463, ptr %t462, 1
  store { i64, ptr } %t464, ptr %l240, !tbaa !27
  %t465 = getelementptr { i64, ptr }, ptr %l240, i32 0, i32 1
  %t466 = load ptr, ptr %t465, !tbaa !27
  %t467 = getelementptr { i64, ptr }, ptr %l238, i32 0, i32 1
  %t468 = load ptr, ptr %t467, !tbaa !27
  %t469 = load i64, ptr %l239, !tbaa !24
  %t470 = mul i64 %t469, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t466, ptr %t468, i64 %t470, i1 false)
  %t471 = load { i64, ptr }, ptr %l240, !tbaa !27
  %t472 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l237, i32 0, i32 0
  store { i64, ptr } %t471, ptr %t472, !tbaa !27
  %t473 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l237, i32 0, i32 1
  %t474 = load { i64, ptr }, ptr %t473, !tbaa !27
  store { i64, ptr } %t474, ptr %l241, !tbaa !27
  %t475 = load { i64, ptr }, ptr %l241, !tbaa !27
  %t476 = extractvalue { i64, ptr } %t475, 0
  store i64 %t476, ptr %l242, !tbaa !24
  %t477 = load i64, ptr %l242, !tbaa !24
  %t478 = mul i64 %t477, 1
  %t479 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t478)
  %t480 = insertvalue { i64, ptr } undef, i64 %t477, 0
  %t481 = insertvalue { i64, ptr } %t480, ptr %t479, 1
  store { i64, ptr } %t481, ptr %l243, !tbaa !27
  %t482 = getelementptr { i64, ptr }, ptr %l243, i32 0, i32 1
  %t483 = load ptr, ptr %t482, !tbaa !27
  %t484 = getelementptr { i64, ptr }, ptr %l241, i32 0, i32 1
  %t485 = load ptr, ptr %t484, !tbaa !27
  %t486 = load i64, ptr %l242, !tbaa !24
  %t487 = mul i64 %t486, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t483, ptr %t485, i64 %t487, i1 false)
  %t488 = load { i64, ptr }, ptr %l243, !tbaa !27
  %t489 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l237, i32 0, i32 1
  store { i64, ptr } %t488, ptr %t489, !tbaa !27
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s0)
  %t490 = load { { i64, ptr }, { i64, ptr } }, ptr %l237
  store { { i64, ptr }, { i64, ptr } } %t490, ptr %rv
  br label %ret
bb64:
  %t491 = load ptr, ptr %l0, !tbaa !29
  %t493 = getelementptr %"compiler/generic:Program", ptr %t491, i32 0, i32 2
  %t494 = load i32, ptr %l1, !tbaa !23
  %t497 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t493, i32 %t494)
  store i32 %t497, ptr %l247
  br label %bb65
bb65:
  %t498 = load i32, ptr %l247, !range !{i32 0, i32 33}
  %t500 = trunc i64 21 to i32
  %t501 = icmp eq i32 %t498, %t500
  br i1 %t501, label %bb66, label %bb67
bb66:
  store %olang.scope zeroinitializer, ptr %s15
  store %olang.scope zeroinitializer, ptr %s16
  store i64 0, ptr %l20, !tbaa !24
  %t503 = load ptr, ptr %l0, !tbaa !29
  %t505 = getelementptr %"compiler/generic:Program", ptr %t503, i32 0, i32 2
  store ptr %t505, ptr %l251, !tbaa !29
  %t506 = load ptr, ptr %l0, !tbaa !29
  %t508 = getelementptr %"compiler/generic:Program", ptr %t506, i32 0, i32 2
  %t509 = load i32, ptr %l1, !tbaa !23
  %t512 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t508, i32 %t509)
  store i32 %t512, ptr %l255
  br label %bb68
bb67:
  br label %bb84
bb68:
  %t513 = load ptr, ptr %l251, !tbaa !29
  %t514 = load i32, ptr %l255, !tbaa !23
  %t515 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s16, ptr %t513, i32 %t514)
  store { i64, ptr } %t515, ptr %l256
  br label %bb69
bb69:
  %t516 = load { i64, ptr }, ptr %l256, !tbaa !27
  %t517 = extractvalue { i64, ptr } %t516, 0
  store i64 %t517, ptr %l21, !tbaa !24
  store i64 1, ptr %l22, !tbaa !24
  %t519 = load i64, ptr %l21, !tbaa !24
  %t520 = load i64, ptr %l20, !tbaa !24
  %t523 = icmp sgt i64 %t519, %t520
  br i1 %t523, label %bb70, label %bb71
bb70:
  %t525 = load i64, ptr %l22, !tbaa !24
  %t527 = icmp sgt i64 %t525, 0
  br i1 %t527, label %bb72, label %bb73
bb71:
  store i64 0, ptr %l261, !tbaa !24
  br label %bb75
bb72:
  %t529 = load i64, ptr %l21, !tbaa !24
  %t530 = load i64, ptr %l20, !tbaa !24
  %t533 = sub i64 %t529, %t530
  %t534 = load i64, ptr %l22, !tbaa !24
  %t537 = add i64 %t533, %t534
  %t539 = sub i64 %t537, 1
  %t540 = load i64, ptr %l22, !tbaa !24
  %t543 = sdiv i64 %t539, %t540
  store i64 %t543, ptr %l264, !tbaa !24
  br label %bb74
bb73:
  store i64 0, ptr %l264, !tbaa !24
  br label %bb74
bb74:
  %t545 = load i64, ptr %l264, !tbaa !24
  store i64 %t545, ptr %l261, !tbaa !24
  br label %bb75
bb75:
  %t546 = load i64, ptr %l261, !tbaa !24
  store i64 %t546, ptr %l23, !tbaa !24
  store i64 0, ptr %l24, !tbaa !24
  br label %bb76
bb76:
  %t547 = load i64, ptr %l24, !tbaa !24
  %t548 = load i64, ptr %l23, !tbaa !24
  %t551 = icmp slt i64 %t547, %t548
  %t553 = xor i1 %t551, true
  br i1 %t553, label %bb77, label %bb78
bb77:
  br label %bb82
bb78:
  br label %bb79
bb79:
  %t555 = load i64, ptr %l20, !tbaa !24
  %t556 = load i64, ptr %l24, !tbaa !24
  %t557 = load i64, ptr %l22, !tbaa !24
  %t560 = mul i64 %t556, %t557
  %t563 = add i64 %t555, %t560
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l6, i64 %t563)
  br label %bb80
bb80:
  br label %bb81
bb81:
  %t568 = load i64, ptr %l24, !tbaa !24
  %t571 = add i64 %t568, 1
  store i64 %t571, ptr %l24, !tbaa !24
  br label %bb76
bb82:
  call void @__olang_scope_close(ptr %s16)
  %t574 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eToArray_3cI64_3e(ptr %s0, ptr %s15, ptr %l6)
  store { i64, ptr } %t574, ptr %l288
  br label %bb83
bb83:
  %t575 = load { i64, ptr }, ptr %l288, !tbaa !27
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d26, i32 0, i32 1) }, ptr %l290, !tbaa !27
  %t576 = load { i64, ptr }, ptr %l290, !tbaa !27
  %t578 = insertvalue { { i64, ptr }, { i64, ptr } } undef, { i64, ptr } %t575, 0
  %t580 = insertvalue { { i64, ptr }, { i64, ptr } } %t578, { i64, ptr } %t576, 1
  store { { i64, ptr }, { i64, ptr } } %t580, ptr %l292
  %t581 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l292, i32 0, i32 0
  %t582 = load { i64, ptr }, ptr %t581, !tbaa !27
  store { i64, ptr } %t582, ptr %l293, !tbaa !27
  %t583 = load { i64, ptr }, ptr %l293, !tbaa !27
  %t584 = extractvalue { i64, ptr } %t583, 0
  store i64 %t584, ptr %l294, !tbaa !24
  %t585 = load i64, ptr %l294, !tbaa !24
  %t586 = mul i64 %t585, 8
  %t587 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t586)
  %t588 = insertvalue { i64, ptr } undef, i64 %t585, 0
  %t589 = insertvalue { i64, ptr } %t588, ptr %t587, 1
  store { i64, ptr } %t589, ptr %l295, !tbaa !27
  %t590 = getelementptr { i64, ptr }, ptr %l295, i32 0, i32 1
  %t591 = load ptr, ptr %t590, !tbaa !27
  %t592 = getelementptr { i64, ptr }, ptr %l293, i32 0, i32 1
  %t593 = load ptr, ptr %t592, !tbaa !27
  %t594 = load i64, ptr %l294, !tbaa !24
  %t595 = mul i64 %t594, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t591, ptr %t593, i64 %t595, i1 false)
  %t596 = load { i64, ptr }, ptr %l295, !tbaa !27
  %t597 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l292, i32 0, i32 0
  store { i64, ptr } %t596, ptr %t597, !tbaa !27
  %t598 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l292, i32 0, i32 1
  %t599 = load { i64, ptr }, ptr %t598, !tbaa !27
  store { i64, ptr } %t599, ptr %l296, !tbaa !27
  %t600 = load { i64, ptr }, ptr %l296, !tbaa !27
  %t601 = extractvalue { i64, ptr } %t600, 0
  store i64 %t601, ptr %l297, !tbaa !24
  %t602 = load i64, ptr %l297, !tbaa !24
  %t603 = mul i64 %t602, 1
  %t604 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t603)
  %t605 = insertvalue { i64, ptr } undef, i64 %t602, 0
  %t606 = insertvalue { i64, ptr } %t605, ptr %t604, 1
  store { i64, ptr } %t606, ptr %l298, !tbaa !27
  %t607 = getelementptr { i64, ptr }, ptr %l298, i32 0, i32 1
  %t608 = load ptr, ptr %t607, !tbaa !27
  %t609 = getelementptr { i64, ptr }, ptr %l296, i32 0, i32 1
  %t610 = load ptr, ptr %t609, !tbaa !27
  %t611 = load i64, ptr %l297, !tbaa !24
  %t612 = mul i64 %t611, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t608, ptr %t610, i64 %t612, i1 false)
  %t613 = load { i64, ptr }, ptr %l298, !tbaa !27
  %t614 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l292, i32 0, i32 1
  store { i64, ptr } %t613, ptr %t614, !tbaa !27
  call void @__olang_scope_close(ptr %s15)
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s0)
  %t615 = load { { i64, ptr }, { i64, ptr } }, ptr %l292
  store { { i64, ptr }, { i64, ptr } } %t615, ptr %rv
  br label %ret
bb84:
  %t616 = load ptr, ptr %l0, !tbaa !29
  %t618 = getelementptr %"compiler/generic:Program", ptr %t616, i32 0, i32 2
  %t619 = load i32, ptr %l1, !tbaa !23
  %t622 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t618, i32 %t619)
  store i32 %t622, ptr %l302
  br label %bb85
bb85:
  %t623 = load i32, ptr %l302, !range !{i32 0, i32 33}
  %t625 = trunc i64 18 to i32
  %t626 = icmp eq i32 %t623, %t625
  br i1 %t626, label %bb86, label %bb87
bb86:
  %t628 = load ptr, ptr %l0, !tbaa !29
  %t629 = load i32, ptr %l1, !tbaa !23
  %t632 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCtorSig(ptr %v0, ptr %t628, i32 %t629)
  store i32 %t632, ptr %l308
  br label %bb88
bb87:
  %t633 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t633, ptr %l305, !tbaa !23
  br label %bb89
bb88:
  %t635 = load i32, ptr %l308, !tbaa !23
  store i32 %t635, ptr %l305, !tbaa !23
  br label %bb89
bb89:
  %t636 = load i32, ptr %l305, !tbaa !23
  store i32 %t636, ptr %l26, !tbaa !23
  %t637 = load i32, ptr %l26, !tbaa !23
  %t638 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t641 = icmp eq i32 %t637, %t638
  br i1 %t641, label %bb90, label %bb91
bb90:
  store %olang.scope zeroinitializer, ptr %s19
  %t643 = load [0 x i64], ptr %l5
  store [0 x i64] %t643, ptr %l313
  %t644 = mul i64 0, 8
  %t645 = insertvalue { i64, ptr } undef, i64 0, 0
  %t646 = insertvalue { i64, ptr } %t645, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t646, ptr %l314, !tbaa !27
  %t647 = getelementptr { i64, ptr }, ptr %l314, i32 0, i32 1
  %t648 = load ptr, ptr %t647, !tbaa !27
  %t649 = mul i64 0, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t648, ptr %l313, i64 %t649, i1 false)
  store { i64, ptr } { i64 66, ptr getelementptr inbounds (<{ i64, [66 x i8] }>, ptr @.d27, i32 0, i32 1) }, ptr %l315, !tbaa !27
  %t650 = load { i64, ptr }, ptr %l315, !tbaa !27
  %t651 = load { i64, ptr }, ptr %l314, !tbaa !27
  %t652 = insertvalue { { i64, ptr }, { i64, ptr } } undef, { i64, ptr } %t651, 0
  %t654 = insertvalue { { i64, ptr }, { i64, ptr } } %t652, { i64, ptr } %t650, 1
  store { { i64, ptr }, { i64, ptr } } %t654, ptr %l317
  %t655 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l317, i32 0, i32 0
  %t656 = load { i64, ptr }, ptr %t655, !tbaa !27
  store { i64, ptr } %t656, ptr %l318, !tbaa !27
  %t657 = load { i64, ptr }, ptr %l318, !tbaa !27
  %t658 = extractvalue { i64, ptr } %t657, 0
  store i64 %t658, ptr %l319, !tbaa !24
  %t659 = load i64, ptr %l319, !tbaa !24
  %t660 = mul i64 %t659, 8
  %t661 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t660)
  %t662 = insertvalue { i64, ptr } undef, i64 %t659, 0
  %t663 = insertvalue { i64, ptr } %t662, ptr %t661, 1
  store { i64, ptr } %t663, ptr %l320, !tbaa !27
  %t664 = getelementptr { i64, ptr }, ptr %l320, i32 0, i32 1
  %t665 = load ptr, ptr %t664, !tbaa !27
  %t666 = getelementptr { i64, ptr }, ptr %l318, i32 0, i32 1
  %t667 = load ptr, ptr %t666, !tbaa !27
  %t668 = load i64, ptr %l319, !tbaa !24
  %t669 = mul i64 %t668, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t665, ptr %t667, i64 %t669, i1 false)
  %t670 = load { i64, ptr }, ptr %l320, !tbaa !27
  %t671 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l317, i32 0, i32 0
  store { i64, ptr } %t670, ptr %t671, !tbaa !27
  %t672 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l317, i32 0, i32 1
  %t673 = load { i64, ptr }, ptr %t672, !tbaa !27
  store { i64, ptr } %t673, ptr %l321, !tbaa !27
  %t674 = load { i64, ptr }, ptr %l321, !tbaa !27
  %t675 = extractvalue { i64, ptr } %t674, 0
  store i64 %t675, ptr %l322, !tbaa !24
  %t676 = load i64, ptr %l322, !tbaa !24
  %t677 = mul i64 %t676, 1
  %t678 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t677)
  %t679 = insertvalue { i64, ptr } undef, i64 %t676, 0
  %t680 = insertvalue { i64, ptr } %t679, ptr %t678, 1
  store { i64, ptr } %t680, ptr %l323, !tbaa !27
  %t681 = getelementptr { i64, ptr }, ptr %l323, i32 0, i32 1
  %t682 = load ptr, ptr %t681, !tbaa !27
  %t683 = getelementptr { i64, ptr }, ptr %l321, i32 0, i32 1
  %t684 = load ptr, ptr %t683, !tbaa !27
  %t685 = load i64, ptr %l322, !tbaa !24
  %t686 = mul i64 %t685, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t682, ptr %t684, i64 %t686, i1 false)
  %t687 = load { i64, ptr }, ptr %l323, !tbaa !27
  %t688 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l317, i32 0, i32 1
  store { i64, ptr } %t687, ptr %t688, !tbaa !27
  call void @__olang_scope_close(ptr %s19)
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s0)
  %t689 = load { { i64, ptr }, { i64, ptr } }, ptr %l317
  store { { i64, ptr }, { i64, ptr } } %t689, ptr %rv
  br label %ret
bb91:
  br label %bb92
bb92:
  store %olang.scope zeroinitializer, ptr %s20
  store i64 0, ptr %l27, !tbaa !24
  %t690 = load ptr, ptr %l0, !tbaa !29
  %t692 = getelementptr %"compiler/generic:Program", ptr %t690, i32 0, i32 2
  store ptr %t692, ptr %l325, !tbaa !29
  %t693 = load ptr, ptr %l0, !tbaa !29
  %t695 = getelementptr %"compiler/generic:Program", ptr %t693, i32 0, i32 2
  %t696 = load i32, ptr %l26, !tbaa !23
  %t699 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t695, i32 %t696)
  store i32 %t699, ptr %l329
  br label %bb93
bb93:
  %t700 = load ptr, ptr %l325, !tbaa !29
  %t701 = load i32, ptr %l329, !tbaa !23
  %t702 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s20, ptr %t700, i32 %t701)
  store { i64, ptr } %t702, ptr %l330
  br label %bb94
bb94:
  %t703 = load { i64, ptr }, ptr %l330, !tbaa !27
  %t704 = extractvalue { i64, ptr } %t703, 0
  store i64 %t704, ptr %l28, !tbaa !24
  store i64 1, ptr %l29, !tbaa !24
  %t706 = load i64, ptr %l28, !tbaa !24
  %t707 = load i64, ptr %l27, !tbaa !24
  %t710 = icmp sgt i64 %t706, %t707
  br i1 %t710, label %bb95, label %bb96
bb95:
  %t712 = load i64, ptr %l29, !tbaa !24
  %t714 = icmp sgt i64 %t712, 0
  br i1 %t714, label %bb97, label %bb98
bb96:
  store i64 0, ptr %l335, !tbaa !24
  br label %bb100
bb97:
  %t716 = load i64, ptr %l28, !tbaa !24
  %t717 = load i64, ptr %l27, !tbaa !24
  %t720 = sub i64 %t716, %t717
  %t721 = load i64, ptr %l29, !tbaa !24
  %t724 = add i64 %t720, %t721
  %t726 = sub i64 %t724, 1
  %t727 = load i64, ptr %l29, !tbaa !24
  %t730 = sdiv i64 %t726, %t727
  store i64 %t730, ptr %l338, !tbaa !24
  br label %bb99
bb98:
  store i64 0, ptr %l338, !tbaa !24
  br label %bb99
bb99:
  %t732 = load i64, ptr %l338, !tbaa !24
  store i64 %t732, ptr %l335, !tbaa !24
  br label %bb100
bb100:
  %t733 = load i64, ptr %l335, !tbaa !24
  store i64 %t733, ptr %l30, !tbaa !24
  store i64 0, ptr %l31, !tbaa !24
  br label %bb101
bb101:
  %t734 = load i64, ptr %l31, !tbaa !24
  %t735 = load i64, ptr %l30, !tbaa !24
  %t738 = icmp slt i64 %t734, %t735
  %t740 = xor i1 %t738, true
  br i1 %t740, label %bb102, label %bb103
bb102:
  br label %bb107
bb103:
  br label %bb104
bb104:
  %t742 = load i64, ptr %l27, !tbaa !24
  %t743 = load i64, ptr %l31, !tbaa !24
  %t744 = load i64, ptr %l29, !tbaa !24
  %t747 = mul i64 %t743, %t744
  %t750 = add i64 %t742, %t747
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l6, i64 %t750)
  br label %bb105
bb105:
  br label %bb106
bb106:
  %t755 = load i64, ptr %l31, !tbaa !24
  %t758 = add i64 %t755, 1
  store i64 %t758, ptr %l31, !tbaa !24
  br label %bb101
bb107:
  call void @__olang_scope_close(ptr %s20)
  %t761 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eToArray_3cI64_3e(ptr %s0, ptr %s10, ptr %l6)
  store { i64, ptr } %t761, ptr %l362
  br label %bb108
bb108:
  %t762 = load { i64, ptr }, ptr %l362, !tbaa !27
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d28, i32 0, i32 1) }, ptr %l364, !tbaa !27
  %t763 = load { i64, ptr }, ptr %l364, !tbaa !27
  %t765 = insertvalue { { i64, ptr }, { i64, ptr } } undef, { i64, ptr } %t762, 0
  %t767 = insertvalue { { i64, ptr }, { i64, ptr } } %t765, { i64, ptr } %t763, 1
  store { { i64, ptr }, { i64, ptr } } %t767, ptr %l366
  %t768 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l366, i32 0, i32 0
  %t769 = load { i64, ptr }, ptr %t768, !tbaa !27
  store { i64, ptr } %t769, ptr %l367, !tbaa !27
  %t770 = load { i64, ptr }, ptr %l367, !tbaa !27
  %t771 = extractvalue { i64, ptr } %t770, 0
  store i64 %t771, ptr %l368, !tbaa !24
  %t772 = load i64, ptr %l368, !tbaa !24
  %t773 = mul i64 %t772, 8
  %t774 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t773)
  %t775 = insertvalue { i64, ptr } undef, i64 %t772, 0
  %t776 = insertvalue { i64, ptr } %t775, ptr %t774, 1
  store { i64, ptr } %t776, ptr %l369, !tbaa !27
  %t777 = getelementptr { i64, ptr }, ptr %l369, i32 0, i32 1
  %t778 = load ptr, ptr %t777, !tbaa !27
  %t779 = getelementptr { i64, ptr }, ptr %l367, i32 0, i32 1
  %t780 = load ptr, ptr %t779, !tbaa !27
  %t781 = load i64, ptr %l368, !tbaa !24
  %t782 = mul i64 %t781, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t778, ptr %t780, i64 %t782, i1 false)
  %t783 = load { i64, ptr }, ptr %l369, !tbaa !27
  %t784 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l366, i32 0, i32 0
  store { i64, ptr } %t783, ptr %t784, !tbaa !27
  %t785 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l366, i32 0, i32 1
  %t786 = load { i64, ptr }, ptr %t785, !tbaa !27
  store { i64, ptr } %t786, ptr %l370, !tbaa !27
  %t787 = load { i64, ptr }, ptr %l370, !tbaa !27
  %t788 = extractvalue { i64, ptr } %t787, 0
  store i64 %t788, ptr %l371, !tbaa !24
  %t789 = load i64, ptr %l371, !tbaa !24
  %t790 = mul i64 %t789, 1
  %t791 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t790)
  %t792 = insertvalue { i64, ptr } undef, i64 %t789, 0
  %t793 = insertvalue { i64, ptr } %t792, ptr %t791, 1
  store { i64, ptr } %t793, ptr %l372, !tbaa !27
  %t794 = getelementptr { i64, ptr }, ptr %l372, i32 0, i32 1
  %t795 = load ptr, ptr %t794, !tbaa !27
  %t796 = getelementptr { i64, ptr }, ptr %l370, i32 0, i32 1
  %t797 = load ptr, ptr %t796, !tbaa !27
  %t798 = load i64, ptr %l371, !tbaa !24
  %t799 = mul i64 %t798, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t795, ptr %t797, i64 %t799, i1 false)
  %t800 = load { i64, ptr }, ptr %l372, !tbaa !27
  %t801 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l366, i32 0, i32 1
  store { i64, ptr } %t800, ptr %t801, !tbaa !27
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s0)
  %t802 = load { { i64, ptr }, { i64, ptr } }, ptr %l366
  store { { i64, ptr }, { i64, ptr } } %t802, ptr %rv
  br label %ret
bb109:
  %t803 = load ptr, ptr %l0, !tbaa !29
  %t804 = load i32, ptr %l1, !tbaa !23
  %t807 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eReflUnder(ptr %v0, ptr %t803, i32 %t804)
  store i32 %t807, ptr %l375
  br label %bb110
bb110:
  %t808 = load i32, ptr %l375, !tbaa !23
  store i32 %t808, ptr %l33, !tbaa !23
  %t809 = load i64, ptr %l2, !tbaa !24
  %t810 = load i64, ptr @G_2ecompiler_2fgeneric_2eListCases, !tbaa !24
  %t813 = icmp eq i64 %t809, %t810
  br i1 %t813, label %bb111, label %bb112
bb111:
  store %olang.scope zeroinitializer, ptr %s23
  %t815 = load ptr, ptr %l0, !tbaa !29
  %t817 = getelementptr %"compiler/generic:Program", ptr %t815, i32 0, i32 2
  %t818 = load i32, ptr %l33, !tbaa !23
  %t821 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t817, i32 %t818)
  store i32 %t821, ptr %l382
  br label %bb113
bb112:
  br label %bb155
bb113:
  %t822 = load i32, ptr %l382, !range !{i32 0, i32 33}
  %t824 = trunc i64 32 to i32
  %t825 = icmp eq i32 %t822, %t824
  br i1 %t825, label %bb114, label %bb115
bb114:
  store %olang.scope zeroinitializer, ptr %s24
  store %olang.scope zeroinitializer, ptr %s25
  store i64 0, ptr %l34, !tbaa !24
  %t827 = load ptr, ptr %l0, !tbaa !29
  %t828 = load i32, ptr %l33, !tbaa !23
  %t831 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrValCodes(ptr %v0, ptr %s25, ptr %t827, i32 %t828)
  store { i64, ptr } %t831, ptr %l387
  br label %bb116
bb115:
  br label %bb131
bb116:
  %t832 = load { i64, ptr }, ptr %l387, !tbaa !27
  %t833 = extractvalue { i64, ptr } %t832, 0
  store i64 %t833, ptr %l35, !tbaa !24
  store i64 1, ptr %l36, !tbaa !24
  %t835 = load i64, ptr %l35, !tbaa !24
  %t836 = load i64, ptr %l34, !tbaa !24
  %t839 = icmp sgt i64 %t835, %t836
  br i1 %t839, label %bb117, label %bb118
bb117:
  %t841 = load i64, ptr %l36, !tbaa !24
  %t843 = icmp sgt i64 %t841, 0
  br i1 %t843, label %bb119, label %bb120
bb118:
  store i64 0, ptr %l392, !tbaa !24
  br label %bb122
bb119:
  %t845 = load i64, ptr %l35, !tbaa !24
  %t846 = load i64, ptr %l34, !tbaa !24
  %t849 = sub i64 %t845, %t846
  %t850 = load i64, ptr %l36, !tbaa !24
  %t853 = add i64 %t849, %t850
  %t855 = sub i64 %t853, 1
  %t856 = load i64, ptr %l36, !tbaa !24
  %t859 = sdiv i64 %t855, %t856
  store i64 %t859, ptr %l395, !tbaa !24
  br label %bb121
bb120:
  store i64 0, ptr %l395, !tbaa !24
  br label %bb121
bb121:
  %t861 = load i64, ptr %l395, !tbaa !24
  store i64 %t861, ptr %l392, !tbaa !24
  br label %bb122
bb122:
  %t862 = load i64, ptr %l392, !tbaa !24
  store i64 %t862, ptr %l37, !tbaa !24
  store i64 0, ptr %l38, !tbaa !24
  br label %bb123
bb123:
  %t863 = load i64, ptr %l38, !tbaa !24
  %t864 = load i64, ptr %l37, !tbaa !24
  %t867 = icmp slt i64 %t863, %t864
  %t869 = xor i1 %t867, true
  br i1 %t869, label %bb124, label %bb125
bb124:
  br label %bb129
bb125:
  br label %bb126
bb126:
  %t871 = load i64, ptr %l34, !tbaa !24
  %t872 = load i64, ptr %l38, !tbaa !24
  %t873 = load i64, ptr %l36, !tbaa !24
  %t876 = mul i64 %t872, %t873
  %t879 = add i64 %t871, %t876
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l6, i64 %t879)
  br label %bb127
bb127:
  br label %bb128
bb128:
  %t884 = load i64, ptr %l38, !tbaa !24
  %t887 = add i64 %t884, 1
  store i64 %t887, ptr %l38, !tbaa !24
  br label %bb123
bb129:
  call void @__olang_scope_close(ptr %s25)
  %t890 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eToArray_3cI64_3e(ptr %s0, ptr %s24, ptr %l6)
  store { i64, ptr } %t890, ptr %l419
  br label %bb130
bb130:
  %t891 = load { i64, ptr }, ptr %l419, !tbaa !27
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d29, i32 0, i32 1) }, ptr %l421, !tbaa !27
  %t892 = load { i64, ptr }, ptr %l421, !tbaa !27
  %t894 = insertvalue { { i64, ptr }, { i64, ptr } } undef, { i64, ptr } %t891, 0
  %t896 = insertvalue { { i64, ptr }, { i64, ptr } } %t894, { i64, ptr } %t892, 1
  store { { i64, ptr }, { i64, ptr } } %t896, ptr %l423
  %t897 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l423, i32 0, i32 0
  %t898 = load { i64, ptr }, ptr %t897, !tbaa !27
  store { i64, ptr } %t898, ptr %l424, !tbaa !27
  %t899 = load { i64, ptr }, ptr %l424, !tbaa !27
  %t900 = extractvalue { i64, ptr } %t899, 0
  store i64 %t900, ptr %l425, !tbaa !24
  %t901 = load i64, ptr %l425, !tbaa !24
  %t902 = mul i64 %t901, 8
  %t903 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t902)
  %t904 = insertvalue { i64, ptr } undef, i64 %t901, 0
  %t905 = insertvalue { i64, ptr } %t904, ptr %t903, 1
  store { i64, ptr } %t905, ptr %l426, !tbaa !27
  %t906 = getelementptr { i64, ptr }, ptr %l426, i32 0, i32 1
  %t907 = load ptr, ptr %t906, !tbaa !27
  %t908 = getelementptr { i64, ptr }, ptr %l424, i32 0, i32 1
  %t909 = load ptr, ptr %t908, !tbaa !27
  %t910 = load i64, ptr %l425, !tbaa !24
  %t911 = mul i64 %t910, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t907, ptr %t909, i64 %t911, i1 false)
  %t912 = load { i64, ptr }, ptr %l426, !tbaa !27
  %t913 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l423, i32 0, i32 0
  store { i64, ptr } %t912, ptr %t913, !tbaa !27
  %t914 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l423, i32 0, i32 1
  %t915 = load { i64, ptr }, ptr %t914, !tbaa !27
  store { i64, ptr } %t915, ptr %l427, !tbaa !27
  %t916 = load { i64, ptr }, ptr %l427, !tbaa !27
  %t917 = extractvalue { i64, ptr } %t916, 0
  store i64 %t917, ptr %l428, !tbaa !24
  %t918 = load i64, ptr %l428, !tbaa !24
  %t919 = mul i64 %t918, 1
  %t920 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t919)
  %t921 = insertvalue { i64, ptr } undef, i64 %t918, 0
  %t922 = insertvalue { i64, ptr } %t921, ptr %t920, 1
  store { i64, ptr } %t922, ptr %l429, !tbaa !27
  %t923 = getelementptr { i64, ptr }, ptr %l429, i32 0, i32 1
  %t924 = load ptr, ptr %t923, !tbaa !27
  %t925 = getelementptr { i64, ptr }, ptr %l427, i32 0, i32 1
  %t926 = load ptr, ptr %t925, !tbaa !27
  %t927 = load i64, ptr %l428, !tbaa !24
  %t928 = mul i64 %t927, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t924, ptr %t926, i64 %t928, i1 false)
  %t929 = load { i64, ptr }, ptr %l429, !tbaa !27
  %t930 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l423, i32 0, i32 1
  store { i64, ptr } %t929, ptr %t930, !tbaa !27
  call void @__olang_scope_close(ptr %s24)
  call void @__olang_scope_close(ptr %s23)
  call void @__olang_scope_close(ptr %s0)
  %t931 = load { { i64, ptr }, { i64, ptr } }, ptr %l423
  store { { i64, ptr }, { i64, ptr } } %t931, ptr %rv
  br label %ret
bb131:
  %t932 = load ptr, ptr %l0, !tbaa !29
  %t933 = load i32, ptr %l33, !tbaa !23
  %t936 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eisEnumT(ptr %v0, ptr %t932, i32 %t933)
  store i1 %t936, ptr %l432
  br label %bb132
bb132:
  %t937 = load i1, ptr %l432, !tbaa !21
  br i1 %t937, label %bb133, label %bb134
bb133:
  store %olang.scope zeroinitializer, ptr %s28
  store %olang.scope zeroinitializer, ptr %s29
  store i64 0, ptr %l40, !tbaa !24
  %t938 = load ptr, ptr %l0, !tbaa !29
  %t940 = getelementptr %"compiler/generic:Program", ptr %t938, i32 0, i32 2
  %t941 = load i32, ptr %l33, !tbaa !23
  %t944 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCaseNames(ptr %v0, ptr %s29, ptr %t940, i32 %t941)
  store { i64, ptr } %t944, ptr %l436
  br label %bb135
bb134:
  br label %bb150
bb135:
  %t945 = load { i64, ptr }, ptr %l436, !tbaa !27
  %t946 = extractvalue { i64, ptr } %t945, 0
  store i64 %t946, ptr %l41, !tbaa !24
  store i64 1, ptr %l42, !tbaa !24
  %t948 = load i64, ptr %l41, !tbaa !24
  %t949 = load i64, ptr %l40, !tbaa !24
  %t952 = icmp sgt i64 %t948, %t949
  br i1 %t952, label %bb136, label %bb137
bb136:
  %t954 = load i64, ptr %l42, !tbaa !24
  %t956 = icmp sgt i64 %t954, 0
  br i1 %t956, label %bb138, label %bb139
bb137:
  store i64 0, ptr %l441, !tbaa !24
  br label %bb141
bb138:
  %t958 = load i64, ptr %l41, !tbaa !24
  %t959 = load i64, ptr %l40, !tbaa !24
  %t962 = sub i64 %t958, %t959
  %t963 = load i64, ptr %l42, !tbaa !24
  %t966 = add i64 %t962, %t963
  %t968 = sub i64 %t966, 1
  %t969 = load i64, ptr %l42, !tbaa !24
  %t972 = sdiv i64 %t968, %t969
  store i64 %t972, ptr %l444, !tbaa !24
  br label %bb140
bb139:
  store i64 0, ptr %l444, !tbaa !24
  br label %bb140
bb140:
  %t974 = load i64, ptr %l444, !tbaa !24
  store i64 %t974, ptr %l441, !tbaa !24
  br label %bb141
bb141:
  %t975 = load i64, ptr %l441, !tbaa !24
  store i64 %t975, ptr %l43, !tbaa !24
  store i64 0, ptr %l44, !tbaa !24
  br label %bb142
bb142:
  %t976 = load i64, ptr %l44, !tbaa !24
  %t977 = load i64, ptr %l43, !tbaa !24
  %t980 = icmp slt i64 %t976, %t977
  %t982 = xor i1 %t980, true
  br i1 %t982, label %bb143, label %bb144
bb143:
  br label %bb148
bb144:
  br label %bb145
bb145:
  %t984 = load i64, ptr %l40, !tbaa !24
  %t985 = load i64, ptr %l44, !tbaa !24
  %t986 = load i64, ptr %l42, !tbaa !24
  %t989 = mul i64 %t985, %t986
  %t992 = add i64 %t984, %t989
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l6, i64 %t992)
  br label %bb146
bb146:
  br label %bb147
bb147:
  %t997 = load i64, ptr %l44, !tbaa !24
  %t1000 = add i64 %t997, 1
  store i64 %t1000, ptr %l44, !tbaa !24
  br label %bb142
bb148:
  call void @__olang_scope_close(ptr %s29)
  %t1003 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eToArray_3cI64_3e(ptr %s0, ptr %s28, ptr %l6)
  store { i64, ptr } %t1003, ptr %l468
  br label %bb149
bb149:
  %t1004 = load { i64, ptr }, ptr %l468, !tbaa !27
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d30, i32 0, i32 1) }, ptr %l470, !tbaa !27
  %t1005 = load { i64, ptr }, ptr %l470, !tbaa !27
  %t1007 = insertvalue { { i64, ptr }, { i64, ptr } } undef, { i64, ptr } %t1004, 0
  %t1009 = insertvalue { { i64, ptr }, { i64, ptr } } %t1007, { i64, ptr } %t1005, 1
  store { { i64, ptr }, { i64, ptr } } %t1009, ptr %l472
  %t1010 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l472, i32 0, i32 0
  %t1011 = load { i64, ptr }, ptr %t1010, !tbaa !27
  store { i64, ptr } %t1011, ptr %l473, !tbaa !27
  %t1012 = load { i64, ptr }, ptr %l473, !tbaa !27
  %t1013 = extractvalue { i64, ptr } %t1012, 0
  store i64 %t1013, ptr %l474, !tbaa !24
  %t1014 = load i64, ptr %l474, !tbaa !24
  %t1015 = mul i64 %t1014, 8
  %t1016 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t1015)
  %t1017 = insertvalue { i64, ptr } undef, i64 %t1014, 0
  %t1018 = insertvalue { i64, ptr } %t1017, ptr %t1016, 1
  store { i64, ptr } %t1018, ptr %l475, !tbaa !27
  %t1019 = getelementptr { i64, ptr }, ptr %l475, i32 0, i32 1
  %t1020 = load ptr, ptr %t1019, !tbaa !27
  %t1021 = getelementptr { i64, ptr }, ptr %l473, i32 0, i32 1
  %t1022 = load ptr, ptr %t1021, !tbaa !27
  %t1023 = load i64, ptr %l474, !tbaa !24
  %t1024 = mul i64 %t1023, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t1020, ptr %t1022, i64 %t1024, i1 false)
  %t1025 = load { i64, ptr }, ptr %l475, !tbaa !27
  %t1026 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l472, i32 0, i32 0
  store { i64, ptr } %t1025, ptr %t1026, !tbaa !27
  %t1027 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l472, i32 0, i32 1
  %t1028 = load { i64, ptr }, ptr %t1027, !tbaa !27
  store { i64, ptr } %t1028, ptr %l476, !tbaa !27
  %t1029 = load { i64, ptr }, ptr %l476, !tbaa !27
  %t1030 = extractvalue { i64, ptr } %t1029, 0
  store i64 %t1030, ptr %l477, !tbaa !24
  %t1031 = load i64, ptr %l477, !tbaa !24
  %t1032 = mul i64 %t1031, 1
  %t1033 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t1032)
  %t1034 = insertvalue { i64, ptr } undef, i64 %t1031, 0
  %t1035 = insertvalue { i64, ptr } %t1034, ptr %t1033, 1
  store { i64, ptr } %t1035, ptr %l478, !tbaa !27
  %t1036 = getelementptr { i64, ptr }, ptr %l478, i32 0, i32 1
  %t1037 = load ptr, ptr %t1036, !tbaa !27
  %t1038 = getelementptr { i64, ptr }, ptr %l476, i32 0, i32 1
  %t1039 = load ptr, ptr %t1038, !tbaa !27
  %t1040 = load i64, ptr %l477, !tbaa !24
  %t1041 = mul i64 %t1040, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t1037, ptr %t1039, i64 %t1041, i1 false)
  %t1042 = load { i64, ptr }, ptr %l478, !tbaa !27
  %t1043 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l472, i32 0, i32 1
  store { i64, ptr } %t1042, ptr %t1043, !tbaa !27
  call void @__olang_scope_close(ptr %s28)
  call void @__olang_scope_close(ptr %s23)
  call void @__olang_scope_close(ptr %s0)
  %t1044 = load { { i64, ptr }, { i64, ptr } }, ptr %l472
  store { { i64, ptr }, { i64, ptr } } %t1044, ptr %rv
  br label %ret
bb150:
  %t1045 = load ptr, ptr %l0, !tbaa !29
  %t1046 = load i32, ptr %l33, !tbaa !23
  %t1049 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eisStructT(ptr %v0, ptr %t1045, i32 %t1046)
  store i1 %t1049, ptr %l481
  br label %bb151
bb151:
  %t1050 = load i1, ptr %l481, !tbaa !21
  br i1 %t1050, label %bb152, label %bb153
bb152:
  %t1051 = mul i64 1, 8
  %t1052 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t1051)
  %t1053 = insertvalue { i64, ptr } undef, i64 1, 0
  %t1054 = insertvalue { i64, ptr } %t1053, ptr %t1052, 1
  store { i64, ptr } %t1054, ptr %l482, !tbaa !27
  %t1055 = getelementptr { i64, ptr }, ptr %l482, i32 0, i32 1
  %t1056 = load ptr, ptr %t1055, !tbaa !27
  %t1057 = getelementptr i64, ptr %t1056, i64 0
  store i64 0, ptr %t1057, !tbaa !34
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d31, i32 0, i32 1) }, ptr %l483, !tbaa !27
  %t1058 = load { i64, ptr }, ptr %l483, !tbaa !27
  %t1059 = load { i64, ptr }, ptr %l482, !tbaa !27
  %t1060 = insertvalue { { i64, ptr }, { i64, ptr } } undef, { i64, ptr } %t1059, 0
  %t1062 = insertvalue { { i64, ptr }, { i64, ptr } } %t1060, { i64, ptr } %t1058, 1
  store { { i64, ptr }, { i64, ptr } } %t1062, ptr %l485
  %t1063 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l485, i32 0, i32 0
  %t1064 = load { i64, ptr }, ptr %t1063, !tbaa !27
  store { i64, ptr } %t1064, ptr %l486, !tbaa !27
  %t1065 = load { i64, ptr }, ptr %l486, !tbaa !27
  %t1066 = extractvalue { i64, ptr } %t1065, 0
  store i64 %t1066, ptr %l487, !tbaa !24
  %t1067 = load i64, ptr %l487, !tbaa !24
  %t1068 = mul i64 %t1067, 8
  %t1069 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t1068)
  %t1070 = insertvalue { i64, ptr } undef, i64 %t1067, 0
  %t1071 = insertvalue { i64, ptr } %t1070, ptr %t1069, 1
  store { i64, ptr } %t1071, ptr %l488, !tbaa !27
  %t1072 = getelementptr { i64, ptr }, ptr %l488, i32 0, i32 1
  %t1073 = load ptr, ptr %t1072, !tbaa !27
  %t1074 = getelementptr { i64, ptr }, ptr %l486, i32 0, i32 1
  %t1075 = load ptr, ptr %t1074, !tbaa !27
  %t1076 = load i64, ptr %l487, !tbaa !24
  %t1077 = mul i64 %t1076, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t1073, ptr %t1075, i64 %t1077, i1 false)
  %t1078 = load { i64, ptr }, ptr %l488, !tbaa !27
  %t1079 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l485, i32 0, i32 0
  store { i64, ptr } %t1078, ptr %t1079, !tbaa !27
  %t1080 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l485, i32 0, i32 1
  %t1081 = load { i64, ptr }, ptr %t1080, !tbaa !27
  store { i64, ptr } %t1081, ptr %l489, !tbaa !27
  %t1082 = load { i64, ptr }, ptr %l489, !tbaa !27
  %t1083 = extractvalue { i64, ptr } %t1082, 0
  store i64 %t1083, ptr %l490, !tbaa !24
  %t1084 = load i64, ptr %l490, !tbaa !24
  %t1085 = mul i64 %t1084, 1
  %t1086 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t1085)
  %t1087 = insertvalue { i64, ptr } undef, i64 %t1084, 0
  %t1088 = insertvalue { i64, ptr } %t1087, ptr %t1086, 1
  store { i64, ptr } %t1088, ptr %l491, !tbaa !27
  %t1089 = getelementptr { i64, ptr }, ptr %l491, i32 0, i32 1
  %t1090 = load ptr, ptr %t1089, !tbaa !27
  %t1091 = getelementptr { i64, ptr }, ptr %l489, i32 0, i32 1
  %t1092 = load ptr, ptr %t1091, !tbaa !27
  %t1093 = load i64, ptr %l490, !tbaa !24
  %t1094 = mul i64 %t1093, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t1090, ptr %t1092, i64 %t1094, i1 false)
  %t1095 = load { i64, ptr }, ptr %l491, !tbaa !27
  %t1096 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l485, i32 0, i32 1
  store { i64, ptr } %t1095, ptr %t1096, !tbaa !27
  call void @__olang_scope_close(ptr %s23)
  call void @__olang_scope_close(ptr %s0)
  %t1097 = load { { i64, ptr }, { i64, ptr } }, ptr %l485
  store { { i64, ptr }, { i64, ptr } } %t1097, ptr %rv
  br label %ret
bb153:
  br label %bb154
bb154:
  %t1098 = load [0 x i64], ptr %l5
  store [0 x i64] %t1098, ptr %l492
  %t1099 = mul i64 0, 8
  %t1100 = insertvalue { i64, ptr } undef, i64 0, 0
  %t1101 = insertvalue { i64, ptr } %t1100, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t1101, ptr %l493, !tbaa !27
  %t1102 = getelementptr { i64, ptr }, ptr %l493, i32 0, i32 1
  %t1103 = load ptr, ptr %t1102, !tbaa !27
  %t1104 = mul i64 0, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t1103, ptr %l492, i64 %t1104, i1 false)
  store { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d32, i32 0, i32 1) }, ptr %l494, !tbaa !27
  %t1105 = load { i64, ptr }, ptr %l494, !tbaa !27
  %t1106 = load { i64, ptr }, ptr %l493, !tbaa !27
  %t1107 = insertvalue { { i64, ptr }, { i64, ptr } } undef, { i64, ptr } %t1106, 0
  %t1109 = insertvalue { { i64, ptr }, { i64, ptr } } %t1107, { i64, ptr } %t1105, 1
  store { { i64, ptr }, { i64, ptr } } %t1109, ptr %l496
  %t1110 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l496, i32 0, i32 0
  %t1111 = load { i64, ptr }, ptr %t1110, !tbaa !27
  store { i64, ptr } %t1111, ptr %l497, !tbaa !27
  %t1112 = load { i64, ptr }, ptr %l497, !tbaa !27
  %t1113 = extractvalue { i64, ptr } %t1112, 0
  store i64 %t1113, ptr %l498, !tbaa !24
  %t1114 = load i64, ptr %l498, !tbaa !24
  %t1115 = mul i64 %t1114, 8
  %t1116 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t1115)
  %t1117 = insertvalue { i64, ptr } undef, i64 %t1114, 0
  %t1118 = insertvalue { i64, ptr } %t1117, ptr %t1116, 1
  store { i64, ptr } %t1118, ptr %l499, !tbaa !27
  %t1119 = getelementptr { i64, ptr }, ptr %l499, i32 0, i32 1
  %t1120 = load ptr, ptr %t1119, !tbaa !27
  %t1121 = getelementptr { i64, ptr }, ptr %l497, i32 0, i32 1
  %t1122 = load ptr, ptr %t1121, !tbaa !27
  %t1123 = load i64, ptr %l498, !tbaa !24
  %t1124 = mul i64 %t1123, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t1120, ptr %t1122, i64 %t1124, i1 false)
  %t1125 = load { i64, ptr }, ptr %l499, !tbaa !27
  %t1126 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l496, i32 0, i32 0
  store { i64, ptr } %t1125, ptr %t1126, !tbaa !27
  %t1127 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l496, i32 0, i32 1
  %t1128 = load { i64, ptr }, ptr %t1127, !tbaa !27
  store { i64, ptr } %t1128, ptr %l500, !tbaa !27
  %t1129 = load { i64, ptr }, ptr %l500, !tbaa !27
  %t1130 = extractvalue { i64, ptr } %t1129, 0
  store i64 %t1130, ptr %l501, !tbaa !24
  %t1131 = load i64, ptr %l501, !tbaa !24
  %t1132 = mul i64 %t1131, 1
  %t1133 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t1132)
  %t1134 = insertvalue { i64, ptr } undef, i64 %t1131, 0
  %t1135 = insertvalue { i64, ptr } %t1134, ptr %t1133, 1
  store { i64, ptr } %t1135, ptr %l502, !tbaa !27
  %t1136 = getelementptr { i64, ptr }, ptr %l502, i32 0, i32 1
  %t1137 = load ptr, ptr %t1136, !tbaa !27
  %t1138 = getelementptr { i64, ptr }, ptr %l500, i32 0, i32 1
  %t1139 = load ptr, ptr %t1138, !tbaa !27
  %t1140 = load i64, ptr %l501, !tbaa !24
  %t1141 = mul i64 %t1140, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t1137, ptr %t1139, i64 %t1141, i1 false)
  %t1142 = load { i64, ptr }, ptr %l502, !tbaa !27
  %t1143 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l496, i32 0, i32 1
  store { i64, ptr } %t1142, ptr %t1143, !tbaa !27
  call void @__olang_scope_close(ptr %s23)
  call void @__olang_scope_close(ptr %s0)
  %t1144 = load { { i64, ptr }, { i64, ptr } }, ptr %l496
  store { { i64, ptr }, { i64, ptr } } %t1144, ptr %rv
  br label %ret
bb155:
  %t1145 = call ptr @__olang_scope_hold(ptr %s0)
  %t1146 = ptrtoint ptr %t1145 to i64
  store i64 %t1146, ptr %l503, !tbaa !24
  %t1147 = load i1, ptr @olang_2esole_2ecompiler__2fgeneric__2ecompiler__2fgeneric__3aProgram__2eReflItems_2elocal_2e46
  br i1 %t1147, label %bb156, label %bb157
bb156:
  %t1149 = call ptr @__olang_region_make(ptr %s0)
  %t1150 = ptrtoint ptr %t1149 to i64
  store i64 %t1150, ptr %l503, !tbaa !24
  br label %bb157
bb157:
  store [0 x i32] zeroinitializer, ptr %l505
  %t1151 = call ptr @__olang_scope_hold(ptr %s0)
  %t1152 = ptrtoint ptr %t1151 to i64
  store i64 %t1152, ptr %l506, !tbaa !24
  %t1153 = load i1, ptr @olang_2esole_2ecompiler__2fgeneric__2ecompiler__2fgeneric__3aProgram__2eReflItems_2elocal_2e46
  br i1 %t1153, label %bb158, label %bb159
bb158:
  %t1155 = call ptr @__olang_region_make(ptr %s0)
  %t1156 = ptrtoint ptr %t1155 to i64
  store i64 %t1156, ptr %l506, !tbaa !24
  br label %bb159
bb159:
  %t1157 = mul i64 0, 4
  %t1158 = load i64, ptr %l506
  %t1159 = inttoptr i64 %t1158 to ptr
  %t1160 = insertvalue { i64, ptr } undef, i64 0, 0
  %t1161 = insertvalue { i64, ptr } %t1160, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t1161, ptr %l508, !tbaa !27
  %t1162 = getelementptr { i64, ptr }, ptr %l508, i32 0, i32 1
  %t1163 = load ptr, ptr %t1162, !tbaa !27
  %t1164 = mul i64 0, 4
  call void @llvm.memmove.p0.p0.i64(ptr %t1163, ptr %l505, i64 %t1164, i1 false)
  %t1165 = load { i64, ptr }, ptr %l508, !tbaa !27
  store { i64, ptr } %t1165, ptr %l46, !tbaa !27
  %t1166 = load ptr, ptr %l0, !tbaa !29
  %t1168 = getelementptr %"compiler/generic:Program", ptr %t1166, i32 0, i32 2
  %t1169 = load i32, ptr %l33, !tbaa !23
  %t1172 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t1168, i32 %t1169)
  store i32 %t1172, ptr %l512
  br label %bb160
bb160:
  %t1173 = load i32, ptr %l512, !range !{i32 0, i32 33}
  %t1175 = trunc i64 32 to i32
  %t1176 = icmp eq i32 %t1173, %t1175
  br i1 %t1176, label %bb161, label %bb162
bb161:
  %t1178 = load i64, ptr %l3, !tbaa !24
  %t1180 = icmp sge i64 %t1178, 0
  store i1 %t1180, ptr %l515, !tbaa !21
  br label %bb163
bb162:
  store i1 false, ptr %l515, !tbaa !21
  br label %bb163
bb163:
  %t1182 = load i1, ptr %l515, !tbaa !21
  br i1 %t1182, label %bb164, label %bb165
bb164:
  store %olang.scope zeroinitializer, ptr %s33
  %t1183 = load [0 x i64], ptr %l5
  store [0 x i64] %t1183, ptr %l518
  %t1184 = mul i64 0, 8
  %t1185 = insertvalue { i64, ptr } undef, i64 0, 0
  %t1186 = insertvalue { i64, ptr } %t1185, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t1186, ptr %l519, !tbaa !27
  %t1187 = getelementptr { i64, ptr }, ptr %l519, i32 0, i32 1
  %t1188 = load ptr, ptr %t1187, !tbaa !27
  %t1189 = mul i64 0, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t1188, ptr %l518, i64 %t1189, i1 false)
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d33, i32 0, i32 1) }, ptr %l520, !tbaa !27
  %t1190 = load { i64, ptr }, ptr %l520, !tbaa !27
  %t1191 = load { i64, ptr }, ptr %l519, !tbaa !27
  %t1192 = insertvalue { { i64, ptr }, { i64, ptr } } undef, { i64, ptr } %t1191, 0
  %t1194 = insertvalue { { i64, ptr }, { i64, ptr } } %t1192, { i64, ptr } %t1190, 1
  store { { i64, ptr }, { i64, ptr } } %t1194, ptr %l522
  %t1195 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l522, i32 0, i32 0
  %t1196 = load { i64, ptr }, ptr %t1195, !tbaa !27
  store { i64, ptr } %t1196, ptr %l523, !tbaa !27
  %t1197 = load { i64, ptr }, ptr %l523, !tbaa !27
  %t1198 = extractvalue { i64, ptr } %t1197, 0
  store i64 %t1198, ptr %l524, !tbaa !24
  %t1199 = load i64, ptr %l524, !tbaa !24
  %t1200 = mul i64 %t1199, 8
  %t1201 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t1200)
  %t1202 = insertvalue { i64, ptr } undef, i64 %t1199, 0
  %t1203 = insertvalue { i64, ptr } %t1202, ptr %t1201, 1
  store { i64, ptr } %t1203, ptr %l525, !tbaa !27
  %t1204 = getelementptr { i64, ptr }, ptr %l525, i32 0, i32 1
  %t1205 = load ptr, ptr %t1204, !tbaa !27
  %t1206 = getelementptr { i64, ptr }, ptr %l523, i32 0, i32 1
  %t1207 = load ptr, ptr %t1206, !tbaa !27
  %t1208 = load i64, ptr %l524, !tbaa !24
  %t1209 = mul i64 %t1208, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t1205, ptr %t1207, i64 %t1209, i1 false)
  %t1210 = load { i64, ptr }, ptr %l525, !tbaa !27
  %t1211 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l522, i32 0, i32 0
  store { i64, ptr } %t1210, ptr %t1211, !tbaa !27
  %t1212 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l522, i32 0, i32 1
  %t1213 = load { i64, ptr }, ptr %t1212, !tbaa !27
  store { i64, ptr } %t1213, ptr %l526, !tbaa !27
  %t1214 = load { i64, ptr }, ptr %l526, !tbaa !27
  %t1215 = extractvalue { i64, ptr } %t1214, 0
  store i64 %t1215, ptr %l527, !tbaa !24
  %t1216 = load i64, ptr %l527, !tbaa !24
  %t1217 = mul i64 %t1216, 1
  %t1218 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t1217)
  %t1219 = insertvalue { i64, ptr } undef, i64 %t1216, 0
  %t1220 = insertvalue { i64, ptr } %t1219, ptr %t1218, 1
  store { i64, ptr } %t1220, ptr %l528, !tbaa !27
  %t1221 = getelementptr { i64, ptr }, ptr %l528, i32 0, i32 1
  %t1222 = load ptr, ptr %t1221, !tbaa !27
  %t1223 = getelementptr { i64, ptr }, ptr %l526, i32 0, i32 1
  %t1224 = load ptr, ptr %t1223, !tbaa !27
  %t1225 = load i64, ptr %l527, !tbaa !24
  %t1226 = mul i64 %t1225, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t1222, ptr %t1224, i64 %t1226, i1 false)
  %t1227 = load { i64, ptr }, ptr %l528, !tbaa !27
  %t1228 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l522, i32 0, i32 1
  store { i64, ptr } %t1227, ptr %t1228, !tbaa !27
  call void @__olang_scope_close(ptr %s33)
  call void @__olang_scope_close(ptr %s0)
  %t1229 = load { { i64, ptr }, { i64, ptr } }, ptr %l522
  store { { i64, ptr }, { i64, ptr } } %t1229, ptr %rv
  br label %ret
bb165:
  %t1230 = load ptr, ptr %l0, !tbaa !29
  %t1231 = load i32, ptr %l33, !tbaa !23
  %t1234 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eisStructT(ptr %v0, ptr %t1230, i32 %t1231)
  store i1 %t1234, ptr %l531
  br label %bb166
bb166:
  %t1235 = load i1, ptr %l531, !tbaa !21
  br i1 %t1235, label %bb167, label %bb168
bb167:
  %t1236 = load ptr, ptr %l0, !tbaa !29
  %t1237 = load i32, ptr %l33, !tbaa !23
  %t1240 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFieldNames(ptr %v0, ptr %s0, ptr %t1236, i32 %t1237)
  store { i64, ptr } %t1240, ptr %l534
  br label %bb169
bb168:
  %t1241 = load ptr, ptr %l0, !tbaa !29
  %t1242 = load i32, ptr %l33, !tbaa !23
  %t1245 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eisEnumT(ptr %v0, ptr %t1241, i32 %t1242)
  store i1 %t1245, ptr %l542
  br label %bb176
bb169:
  %t1246 = load i1, ptr @olang_2esole_2ecompiler__2fgeneric__2ecompiler__2fgeneric__3aProgram__2eReflItems_2elocal_2e46
  br i1 %t1246, label %bb170, label %bb171
bb170:
  %t1248 = load { i64, ptr }, ptr %l46, !tbaa !27
  store { i64, ptr } %t1248, ptr %l536, !tbaa !27
  %t1249 = load { i64, ptr }, ptr %l534, !tbaa !27
  store { i64, ptr } %t1249, ptr %l46, !tbaa !27
  %t1250 = load { i64, ptr }, ptr %l536
  %t1251 = extractvalue { i64, ptr } %t1250, 1
  call void @__olang_region_release(ptr %t1251)
  store { i64, ptr } zeroinitializer, ptr %l536
  br label %bb172
bb171:
  %t1252 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t1253 = extractvalue { i64, ptr } %t1252, 0
  %t1254 = load { i64, ptr }, ptr %l534, !tbaa !27
  %t1255 = extractvalue { i64, ptr } %t1254, 0
  store i64 %t1255, ptr %l538, !tbaa !24
  %t1257 = load i64, ptr %l538, !tbaa !24
  %t1258 = icmp eq i64 %t1253, %t1257
  br i1 %t1258, label %bb173, label %bb174
bb172:
  br label %bb193
bb173:
  %t1260 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t1261 = load ptr, ptr %t1260, !tbaa !27
  %t1262 = getelementptr { i64, ptr }, ptr %l534, i32 0, i32 1
  %t1263 = load ptr, ptr %t1262, !tbaa !27
  %t1264 = load i64, ptr %l538, !tbaa !24
  %t1265 = mul i64 %t1264, 4
  call void @llvm.memmove.p0.p0.i64(ptr %t1261, ptr %t1263, i64 %t1265, i1 false)
  br label %bb175
bb174:
  %t1266 = load { i64, ptr }, ptr %l534, !tbaa !27
  store { i64, ptr } %t1266, ptr %l46, !tbaa !27
  br label %bb175
bb175:
  br label %bb172
bb176:
  %t1267 = load i1, ptr %l542, !tbaa !21
  br i1 %t1267, label %bb177, label %bb178
bb177:
  %t1268 = load i64, ptr %l3, !tbaa !24
  %t1270 = icmp sge i64 %t1268, 0
  store i1 %t1270, ptr %l543, !tbaa !21
  br label %bb179
bb178:
  store i1 false, ptr %l543, !tbaa !21
  br label %bb179
bb179:
  %t1272 = load i1, ptr %l543, !tbaa !21
  br i1 %t1272, label %bb180, label %bb181
bb180:
  %t1273 = load ptr, ptr %l0, !tbaa !29
  %t1274 = load i32, ptr %l33, !tbaa !23
  %t1275 = load i64, ptr %l3, !tbaa !24
  %t1279 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCaseFieldNames(ptr %v0, ptr %s0, ptr %t1273, i32 %t1274, i64 %t1275)
  store { i64, ptr } %t1279, ptr %l549
  br label %bb182
bb181:
  %t1280 = load ptr, ptr %l0, !tbaa !29
  %t1281 = load i32, ptr %l33, !tbaa !23
  %t1284 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eisEnumT(ptr %v0, ptr %t1280, i32 %t1281)
  store i1 %t1284, ptr %l557
  br label %bb189
bb182:
  %t1285 = load i1, ptr @olang_2esole_2ecompiler__2fgeneric__2ecompiler__2fgeneric__3aProgram__2eReflItems_2elocal_2e46
  br i1 %t1285, label %bb183, label %bb184
bb183:
  %t1287 = load { i64, ptr }, ptr %l46, !tbaa !27
  store { i64, ptr } %t1287, ptr %l551, !tbaa !27
  %t1288 = load { i64, ptr }, ptr %l549, !tbaa !27
  store { i64, ptr } %t1288, ptr %l46, !tbaa !27
  %t1289 = load { i64, ptr }, ptr %l551
  %t1290 = extractvalue { i64, ptr } %t1289, 1
  call void @__olang_region_release(ptr %t1290)
  store { i64, ptr } zeroinitializer, ptr %l551
  br label %bb185
bb184:
  %t1291 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t1292 = extractvalue { i64, ptr } %t1291, 0
  %t1293 = load { i64, ptr }, ptr %l549, !tbaa !27
  %t1294 = extractvalue { i64, ptr } %t1293, 0
  store i64 %t1294, ptr %l553, !tbaa !24
  %t1296 = load i64, ptr %l553, !tbaa !24
  %t1297 = icmp eq i64 %t1292, %t1296
  br i1 %t1297, label %bb186, label %bb187
bb185:
  br label %bb192
bb186:
  %t1299 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t1300 = load ptr, ptr %t1299, !tbaa !27
  %t1301 = getelementptr { i64, ptr }, ptr %l549, i32 0, i32 1
  %t1302 = load ptr, ptr %t1301, !tbaa !27
  %t1303 = load i64, ptr %l553, !tbaa !24
  %t1304 = mul i64 %t1303, 4
  call void @llvm.memmove.p0.p0.i64(ptr %t1300, ptr %t1302, i64 %t1304, i1 false)
  br label %bb188
bb187:
  %t1305 = load { i64, ptr }, ptr %l549, !tbaa !27
  store { i64, ptr } %t1305, ptr %l46, !tbaa !27
  br label %bb188
bb188:
  br label %bb185
bb189:
  %t1306 = load i1, ptr %l557, !tbaa !21
  br i1 %t1306, label %bb190, label %bb191
bb190:
  store %olang.scope zeroinitializer, ptr %s39
  %t1307 = load [0 x i64], ptr %l5
  store [0 x i64] %t1307, ptr %l558
  %t1308 = mul i64 0, 8
  %t1309 = insertvalue { i64, ptr } undef, i64 0, 0
  %t1310 = insertvalue { i64, ptr } %t1309, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t1310, ptr %l559, !tbaa !27
  %t1311 = getelementptr { i64, ptr }, ptr %l559, i32 0, i32 1
  %t1312 = load ptr, ptr %t1311, !tbaa !27
  %t1313 = mul i64 0, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t1312, ptr %l558, i64 %t1313, i1 false)
  store { i64, ptr } { i64 71, ptr getelementptr inbounds (<{ i64, [71 x i8] }>, ptr @.d34, i32 0, i32 1) }, ptr %l560, !tbaa !27
  %t1314 = load { i64, ptr }, ptr %l560, !tbaa !27
  %t1315 = load { i64, ptr }, ptr %l559, !tbaa !27
  %t1316 = insertvalue { { i64, ptr }, { i64, ptr } } undef, { i64, ptr } %t1315, 0
  %t1318 = insertvalue { { i64, ptr }, { i64, ptr } } %t1316, { i64, ptr } %t1314, 1
  store { { i64, ptr }, { i64, ptr } } %t1318, ptr %l562
  %t1319 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l562, i32 0, i32 0
  %t1320 = load { i64, ptr }, ptr %t1319, !tbaa !27
  store { i64, ptr } %t1320, ptr %l563, !tbaa !27
  %t1321 = load { i64, ptr }, ptr %l563, !tbaa !27
  %t1322 = extractvalue { i64, ptr } %t1321, 0
  store i64 %t1322, ptr %l564, !tbaa !24
  %t1323 = load i64, ptr %l564, !tbaa !24
  %t1324 = mul i64 %t1323, 8
  %t1325 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t1324)
  %t1326 = insertvalue { i64, ptr } undef, i64 %t1323, 0
  %t1327 = insertvalue { i64, ptr } %t1326, ptr %t1325, 1
  store { i64, ptr } %t1327, ptr %l565, !tbaa !27
  %t1328 = getelementptr { i64, ptr }, ptr %l565, i32 0, i32 1
  %t1329 = load ptr, ptr %t1328, !tbaa !27
  %t1330 = getelementptr { i64, ptr }, ptr %l563, i32 0, i32 1
  %t1331 = load ptr, ptr %t1330, !tbaa !27
  %t1332 = load i64, ptr %l564, !tbaa !24
  %t1333 = mul i64 %t1332, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t1329, ptr %t1331, i64 %t1333, i1 false)
  %t1334 = load { i64, ptr }, ptr %l565, !tbaa !27
  %t1335 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l562, i32 0, i32 0
  store { i64, ptr } %t1334, ptr %t1335, !tbaa !27
  %t1336 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l562, i32 0, i32 1
  %t1337 = load { i64, ptr }, ptr %t1336, !tbaa !27
  store { i64, ptr } %t1337, ptr %l566, !tbaa !27
  %t1338 = load { i64, ptr }, ptr %l566, !tbaa !27
  %t1339 = extractvalue { i64, ptr } %t1338, 0
  store i64 %t1339, ptr %l567, !tbaa !24
  %t1340 = load i64, ptr %l567, !tbaa !24
  %t1341 = mul i64 %t1340, 1
  %t1342 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t1341)
  %t1343 = insertvalue { i64, ptr } undef, i64 %t1340, 0
  %t1344 = insertvalue { i64, ptr } %t1343, ptr %t1342, 1
  store { i64, ptr } %t1344, ptr %l568, !tbaa !27
  %t1345 = getelementptr { i64, ptr }, ptr %l568, i32 0, i32 1
  %t1346 = load ptr, ptr %t1345, !tbaa !27
  %t1347 = getelementptr { i64, ptr }, ptr %l566, i32 0, i32 1
  %t1348 = load ptr, ptr %t1347, !tbaa !27
  %t1349 = load i64, ptr %l567, !tbaa !24
  %t1350 = mul i64 %t1349, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t1346, ptr %t1348, i64 %t1350, i1 false)
  %t1351 = load { i64, ptr }, ptr %l568, !tbaa !27
  %t1352 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l562, i32 0, i32 1
  store { i64, ptr } %t1351, ptr %t1352, !tbaa !27
  call void @__olang_scope_close(ptr %s39)
  call void @__olang_scope_close(ptr %s0)
  %t1353 = load { { i64, ptr }, { i64, ptr } }, ptr %l562
  store { { i64, ptr }, { i64, ptr } } %t1353, ptr %rv
  br label %ret
bb191:
  store %olang.scope zeroinitializer, ptr %s40
  %t1354 = load [0 x i64], ptr %l5
  store [0 x i64] %t1354, ptr %l569
  %t1355 = mul i64 0, 8
  %t1356 = insertvalue { i64, ptr } undef, i64 0, 0
  %t1357 = insertvalue { i64, ptr } %t1356, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t1357, ptr %l570, !tbaa !27
  %t1358 = getelementptr { i64, ptr }, ptr %l570, i32 0, i32 1
  %t1359 = load ptr, ptr %t1358, !tbaa !27
  %t1360 = mul i64 0, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t1359, ptr %l569, i64 %t1360, i1 false)
  store { i64, ptr } { i64 44, ptr getelementptr inbounds (<{ i64, [44 x i8] }>, ptr @.d35, i32 0, i32 1) }, ptr %l571, !tbaa !27
  %t1361 = load { i64, ptr }, ptr %l571, !tbaa !27
  %t1362 = load { i64, ptr }, ptr %l570, !tbaa !27
  %t1363 = insertvalue { { i64, ptr }, { i64, ptr } } undef, { i64, ptr } %t1362, 0
  %t1365 = insertvalue { { i64, ptr }, { i64, ptr } } %t1363, { i64, ptr } %t1361, 1
  store { { i64, ptr }, { i64, ptr } } %t1365, ptr %l573
  %t1366 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l573, i32 0, i32 0
  %t1367 = load { i64, ptr }, ptr %t1366, !tbaa !27
  store { i64, ptr } %t1367, ptr %l574, !tbaa !27
  %t1368 = load { i64, ptr }, ptr %l574, !tbaa !27
  %t1369 = extractvalue { i64, ptr } %t1368, 0
  store i64 %t1369, ptr %l575, !tbaa !24
  %t1370 = load i64, ptr %l575, !tbaa !24
  %t1371 = mul i64 %t1370, 8
  %t1372 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t1371)
  %t1373 = insertvalue { i64, ptr } undef, i64 %t1370, 0
  %t1374 = insertvalue { i64, ptr } %t1373, ptr %t1372, 1
  store { i64, ptr } %t1374, ptr %l576, !tbaa !27
  %t1375 = getelementptr { i64, ptr }, ptr %l576, i32 0, i32 1
  %t1376 = load ptr, ptr %t1375, !tbaa !27
  %t1377 = getelementptr { i64, ptr }, ptr %l574, i32 0, i32 1
  %t1378 = load ptr, ptr %t1377, !tbaa !27
  %t1379 = load i64, ptr %l575, !tbaa !24
  %t1380 = mul i64 %t1379, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t1376, ptr %t1378, i64 %t1380, i1 false)
  %t1381 = load { i64, ptr }, ptr %l576, !tbaa !27
  %t1382 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l573, i32 0, i32 0
  store { i64, ptr } %t1381, ptr %t1382, !tbaa !27
  %t1383 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l573, i32 0, i32 1
  %t1384 = load { i64, ptr }, ptr %t1383, !tbaa !27
  store { i64, ptr } %t1384, ptr %l577, !tbaa !27
  %t1385 = load { i64, ptr }, ptr %l577, !tbaa !27
  %t1386 = extractvalue { i64, ptr } %t1385, 0
  store i64 %t1386, ptr %l578, !tbaa !24
  %t1387 = load i64, ptr %l578, !tbaa !24
  %t1388 = mul i64 %t1387, 1
  %t1389 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t1388)
  %t1390 = insertvalue { i64, ptr } undef, i64 %t1387, 0
  %t1391 = insertvalue { i64, ptr } %t1390, ptr %t1389, 1
  store { i64, ptr } %t1391, ptr %l579, !tbaa !27
  %t1392 = getelementptr { i64, ptr }, ptr %l579, i32 0, i32 1
  %t1393 = load ptr, ptr %t1392, !tbaa !27
  %t1394 = getelementptr { i64, ptr }, ptr %l577, i32 0, i32 1
  %t1395 = load ptr, ptr %t1394, !tbaa !27
  %t1396 = load i64, ptr %l578, !tbaa !24
  %t1397 = mul i64 %t1396, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t1393, ptr %t1395, i64 %t1397, i1 false)
  %t1398 = load { i64, ptr }, ptr %l579, !tbaa !27
  %t1399 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l573, i32 0, i32 1
  store { i64, ptr } %t1398, ptr %t1399, !tbaa !27
  call void @__olang_scope_close(ptr %s40)
  call void @__olang_scope_close(ptr %s0)
  %t1400 = load { { i64, ptr }, { i64, ptr } }, ptr %l573
  store { { i64, ptr }, { i64, ptr } } %t1400, ptr %rv
  br label %ret
bb192:
  br label %bb193
bb193:
  br label %bb194
bb194:
  %t1401 = load i32, ptr %l33, !tbaa !23
  store i32 %t1401, ptr %l47, !tbaa !23
  %t1403 = load ptr, ptr %l0, !tbaa !29
  %t1404 = load i32, ptr %l33, !tbaa !23
  %t1407 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsColumns(ptr %v0, ptr %t1403, i32 %t1404)
  store i1 %t1407, ptr %l583
  br label %bb195
bb195:
  %t1408 = load i1, ptr %l583, !tbaa !21
  br i1 %t1408, label %bb196, label %bb197
bb196:
  %t1409 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1409, ptr %l585, !tbaa !29
  %t1410 = load ptr, ptr %l0, !tbaa !29
  %t1411 = load i32, ptr %l33, !tbaa !23
  %t1414 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eColumnsRow(ptr %v0, ptr %t1410, i32 %t1411)
  store i32 %t1414, ptr %l588
  br label %bb198
bb197:
  store i1 false, ptr %l584, !tbaa !21
  br label %bb200
bb198:
  %t1415 = load ptr, ptr %l585, !tbaa !29
  %t1416 = load i32, ptr %l588, !tbaa !23
  %t1417 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eisStructT(ptr %v0, ptr %t1415, i32 %t1416)
  store i1 %t1417, ptr %l589
  br label %bb199
bb199:
  %t1418 = load i1, ptr %l589, !tbaa !21
  store i1 %t1418, ptr %l584, !tbaa !21
  br label %bb200
bb200:
  %t1419 = load i1, ptr %l584, !tbaa !21
  br i1 %t1419, label %bb201, label %bb202
bb201:
  %t1420 = load ptr, ptr %l0, !tbaa !29
  %t1421 = load i32, ptr %l33, !tbaa !23
  %t1424 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eColumnsRow(ptr %v0, ptr %t1420, i32 %t1421)
  store i32 %t1424, ptr %l592
  br label %bb203
bb202:
  br label %bb204
bb203:
  %t1425 = load i32, ptr %l592, !tbaa !23
  store i32 %t1425, ptr %l47, !tbaa !23
  br label %bb204
bb204:
  %t1426 = load ptr, ptr %l0, !tbaa !29
  %t1428 = getelementptr %"compiler/generic:Program", ptr %t1426, i32 0, i32 2
  store ptr %t1428, ptr %l594, !tbaa !29
  %t1429 = load ptr, ptr %l0, !tbaa !29
  %t1431 = getelementptr %"compiler/generic:Program", ptr %t1429, i32 0, i32 2
  %t1432 = load i32, ptr %l47, !tbaa !23
  %t1435 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t1431, i32 %t1432)
  store i32 %t1435, ptr %l598
  br label %bb205
bb205:
  %t1436 = load ptr, ptr %l594, !tbaa !29
  %t1437 = load i32, ptr %l598, !tbaa !23
  %t1438 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %t1436, i32 %t1437)
  store i64 %t1438, ptr %l599
  br label %bb206
bb206:
  %t1439 = load i64, ptr %l4, !tbaa !24
  %t1440 = load i64, ptr %l599, !tbaa !24
  %t1442 = icmp eq i64 %t1440, %t1439
  br i1 %t1442, label %bb207, label %bb208
bb207:
  store i1 true, ptr %l602, !tbaa !21
  br label %bb210
bb208:
  %t1444 = load ptr, ptr %l0, !tbaa !29
  %t1445 = load i32, ptr %l47, !tbaa !23
  %t1448 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eisStructT(ptr %v0, ptr %t1444, i32 %t1445)
  store i1 %t1448, ptr %l605
  br label %bb209
bb209:
  %t1449 = load i1, ptr %l605, !tbaa !21
  %t1450 = xor i1 %t1449, true
  store i1 %t1450, ptr %l602, !tbaa !21
  br label %bb210
bb210:
  %t1452 = load i1, ptr %l602, !tbaa !21
  br i1 %t1452, label %bb211, label %bb212
bb211:
  store i1 true, ptr %l607, !tbaa !21
  br label %bb216
bb212:
  %t1453 = load ptr, ptr %l0, !tbaa !29
  %t1455 = getelementptr %"compiler/generic:Program", ptr %t1453, i32 0, i32 0
  %t1456 = load ptr, ptr %t1455, !tbaa !29
  %t1458 = getelementptr %"compiler/load:Loader", ptr %t1456, i32 0, i32 10
  store ptr %t1458, ptr %l610, !tbaa !29
  %t1459 = load ptr, ptr %l0, !tbaa !29
  %t1461 = getelementptr %"compiler/generic:Program", ptr %t1459, i32 0, i32 2
  store ptr %t1461, ptr %l612, !tbaa !29
  %t1462 = load ptr, ptr %l0, !tbaa !29
  %t1464 = getelementptr %"compiler/generic:Program", ptr %t1462, i32 0, i32 2
  %t1465 = load i32, ptr %l47, !tbaa !23
  %t1468 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t1464, i32 %t1465)
  store i32 %t1468, ptr %l616
  br label %bb213
bb213:
  %t1469 = load ptr, ptr %l612, !tbaa !29
  %t1470 = load i32, ptr %l616, !tbaa !23
  %t1471 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %t1469, i32 %t1470)
  store i64 %t1471, ptr %l617
  br label %bb214
bb214:
  %t1472 = load ptr, ptr %l610, !tbaa !29
  %t1473 = load i64, ptr %l617, !tbaa !24
  %t1474 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t1472, i64 %t1473)
  store ptr %t1474, ptr %l618
  br label %bb215
bb215:
  %t1475 = load ptr, ptr %l618, !tbaa !29
  %t1477 = getelementptr %"compiler/load:Module", ptr %t1475, i32 0, i32 33
  %t1478 = load i1, ptr %t1477, !tbaa !21
  store i1 %t1478, ptr %l607, !tbaa !21
  br label %bb216
bb216:
  %t1480 = load i1, ptr %l607, !tbaa !21
  br i1 %t1480, label %bb217, label %bb218
bb217:
  store i1 true, ptr %l621, !tbaa !21
  br label %bb227
bb218:
  %t1481 = load i64, ptr %l4, !tbaa !24
  %t1483 = icmp sge i64 %t1481, 0
  br i1 %t1483, label %bb219, label %bb220
bb219:
  %t1485 = load i64, ptr %l4, !tbaa !24
  store i64 %t1485, ptr %l625, !tbaa !24
  %t1486 = load ptr, ptr %l0, !tbaa !29
  %t1488 = getelementptr %"compiler/generic:Program", ptr %t1486, i32 0, i32 0
  %t1489 = load ptr, ptr %t1488, !tbaa !29
  %t1491 = getelementptr %"compiler/load:Loader", ptr %t1489, i32 0, i32 10
  %t1493 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %t1491)
  store i64 %t1493, ptr %l629
  br label %bb221
bb220:
  store i1 false, ptr %l624, !tbaa !21
  br label %bb222
bb221:
  %t1494 = load i64, ptr %l625, !tbaa !24
  %t1495 = load i64, ptr %l629, !tbaa !24
  %t1496 = icmp slt i64 %t1494, %t1495
  store i1 %t1496, ptr %l624, !tbaa !21
  br label %bb222
bb222:
  %t1498 = load i1, ptr %l624, !tbaa !21
  br i1 %t1498, label %bb223, label %bb224
bb223:
  %t1499 = load ptr, ptr %l0, !tbaa !29
  %t1501 = getelementptr %"compiler/generic:Program", ptr %t1499, i32 0, i32 0
  %t1502 = load ptr, ptr %t1501, !tbaa !29
  %t1504 = getelementptr %"compiler/load:Loader", ptr %t1502, i32 0, i32 10
  %t1505 = load i64, ptr %l4, !tbaa !24
  %t1508 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t1504, i64 %t1505)
  store ptr %t1508, ptr %l636
  br label %bb225
bb224:
  store i1 false, ptr %l631, !tbaa !21
  br label %bb226
bb225:
  %t1509 = load ptr, ptr %l636, !tbaa !29
  %t1511 = getelementptr %"compiler/load:Module", ptr %t1509, i32 0, i32 3
  %t1512 = load i1, ptr %t1511, !tbaa !21
  store i1 %t1512, ptr %l631, !tbaa !21
  br label %bb226
bb226:
  %t1514 = load i1, ptr %l631, !tbaa !21
  store i1 %t1514, ptr %l621, !tbaa !21
  br label %bb227
bb227:
  %t1515 = load i1, ptr %l621, !tbaa !21
  store i1 %t1515, ptr %l48, !tbaa !21
  store i64 0, ptr %l49, !tbaa !24
  %t1516 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t1518 = extractvalue { i64, ptr } %t1516, 0
  store i64 %t1518, ptr %l50, !tbaa !24
  store i64 1, ptr %l51, !tbaa !24
  %t1520 = load i64, ptr %l50, !tbaa !24
  %t1521 = load i64, ptr %l49, !tbaa !24
  %t1524 = icmp sgt i64 %t1520, %t1521
  br i1 %t1524, label %bb228, label %bb229
bb228:
  %t1526 = load i64, ptr %l51, !tbaa !24
  %t1528 = icmp sgt i64 %t1526, 0
  br i1 %t1528, label %bb230, label %bb231
bb229:
  store i64 0, ptr %l644, !tbaa !24
  br label %bb233
bb230:
  %t1530 = load i64, ptr %l50, !tbaa !24
  %t1531 = load i64, ptr %l49, !tbaa !24
  %t1534 = sub i64 %t1530, %t1531
  %t1535 = load i64, ptr %l51, !tbaa !24
  %t1538 = add i64 %t1534, %t1535
  %t1540 = sub i64 %t1538, 1
  %t1541 = load i64, ptr %l51, !tbaa !24
  %t1544 = sdiv i64 %t1540, %t1541
  store i64 %t1544, ptr %l647, !tbaa !24
  br label %bb232
bb231:
  store i64 0, ptr %l647, !tbaa !24
  br label %bb232
bb232:
  %t1546 = load i64, ptr %l647, !tbaa !24
  store i64 %t1546, ptr %l644, !tbaa !24
  br label %bb233
bb233:
  %t1547 = load i64, ptr %l644, !tbaa !24
  store i64 %t1547, ptr %l52, !tbaa !24
  store i64 0, ptr %l53, !tbaa !24
  br label %bb234
bb234:
  store %olang.scope zeroinitializer, ptr %s43
  %t1548 = load i64, ptr %l53, !tbaa !24
  %t1549 = load i64, ptr %l52, !tbaa !24
  %t1552 = icmp slt i64 %t1548, %t1549
  %t1554 = xor i1 %t1552, true
  br i1 %t1554, label %bb235, label %bb236
bb235:
  call void @__olang_scope_close(ptr %s43)
  br label %bb248
bb236:
  br label %bb237
bb237:
  %t1556 = load i64, ptr %l49, !tbaa !24
  %t1557 = load i64, ptr %l53, !tbaa !24
  %t1558 = load i64, ptr %l51, !tbaa !24
  %t1561 = mul i64 %t1557, %t1558
  %t1564 = add i64 %t1556, %t1561
  store i64 %t1564, ptr %l54, !tbaa !24
  %t1566 = load i1, ptr %l48, !tbaa !21
  br i1 %t1566, label %bb238, label %bb239
bb238:
  store i1 true, ptr %l666, !tbaa !21
  br label %bb242
bb239:
  %t1568 = load ptr, ptr %l0, !tbaa !29
  %t1569 = load i64, ptr %l54, !tbaa !24
  %t1571 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t1572 = load ptr, ptr %t1571, !tbaa !27
  %t1573 = getelementptr i32, ptr %t1572, i64 %t1569
  %t1574 = load i32, ptr %t1573, !tbaa !33
  %t1577 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2etext(ptr %v0, ptr %s43, ptr %t1568, i32 %t1574)
  store { i64, ptr } %t1577, ptr %l670
  br label %bb240
bb240:
  %t1578 = load { i64, ptr }, ptr %l670, !tbaa !27
  store { i64, ptr } %t1578, ptr %l671, !tbaa !27
  %t1579 = getelementptr { i64, ptr }, ptr %l671, i32 0, i32 1
  %t1580 = load ptr, ptr %t1579, !tbaa !27
  %t1581 = getelementptr i8, ptr %t1580, i64 0
  %t1582 = load i8, ptr %t1581, !tbaa !32
  %t1584 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsUpper(i8 %t1582)
  store i1 %t1584, ptr %l673
  br label %bb241
bb241:
  %t1585 = load i1, ptr %l673, !tbaa !21
  store i1 %t1585, ptr %l666, !tbaa !21
  br label %bb242
bb242:
  %t1586 = load i1, ptr %l666, !tbaa !21
  br i1 %t1586, label %bb243, label %bb244
bb243:
  %t1587 = load i64, ptr %l54, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l6, i64 %t1587)
  br label %bb245
bb244:
  br label %bb246
bb245:
  br label %bb246
bb246:
  call void @__olang_scope_close(ptr %s43)
  br label %bb247
bb247:
  %t1590 = load i64, ptr %l53, !tbaa !24
  %t1593 = add i64 %t1590, 1
  store i64 %t1593, ptr %l53, !tbaa !24
  br label %bb234
bb248:
  %t1596 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eToArray_3cI64_3e(ptr %s0, ptr %s0, ptr %l6)
  store { i64, ptr } %t1596, ptr %l680
  br label %bb249
bb249:
  %t1597 = load { i64, ptr }, ptr %l680, !tbaa !27
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d36, i32 0, i32 1) }, ptr %l682, !tbaa !27
  %t1598 = load { i64, ptr }, ptr %l682, !tbaa !27
  %t1600 = insertvalue { { i64, ptr }, { i64, ptr } } undef, { i64, ptr } %t1597, 0
  %t1602 = insertvalue { { i64, ptr }, { i64, ptr } } %t1600, { i64, ptr } %t1598, 1
  store { { i64, ptr }, { i64, ptr } } %t1602, ptr %l684
  %t1603 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l684, i32 0, i32 0
  %t1604 = load { i64, ptr }, ptr %t1603, !tbaa !27
  store { i64, ptr } %t1604, ptr %l685, !tbaa !27
  %t1605 = load { i64, ptr }, ptr %l685, !tbaa !27
  %t1606 = extractvalue { i64, ptr } %t1605, 0
  store i64 %t1606, ptr %l686, !tbaa !24
  %t1607 = load i64, ptr %l686, !tbaa !24
  %t1608 = mul i64 %t1607, 8
  %t1609 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t1608)
  %t1610 = insertvalue { i64, ptr } undef, i64 %t1607, 0
  %t1611 = insertvalue { i64, ptr } %t1610, ptr %t1609, 1
  store { i64, ptr } %t1611, ptr %l687, !tbaa !27
  %t1612 = getelementptr { i64, ptr }, ptr %l687, i32 0, i32 1
  %t1613 = load ptr, ptr %t1612, !tbaa !27
  %t1614 = getelementptr { i64, ptr }, ptr %l685, i32 0, i32 1
  %t1615 = load ptr, ptr %t1614, !tbaa !27
  %t1616 = load i64, ptr %l686, !tbaa !24
  %t1617 = mul i64 %t1616, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t1613, ptr %t1615, i64 %t1617, i1 false)
  %t1618 = load { i64, ptr }, ptr %l687, !tbaa !27
  %t1619 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l684, i32 0, i32 0
  store { i64, ptr } %t1618, ptr %t1619, !tbaa !27
  %t1620 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l684, i32 0, i32 1
  %t1621 = load { i64, ptr }, ptr %t1620, !tbaa !27
  store { i64, ptr } %t1621, ptr %l688, !tbaa !27
  %t1622 = load { i64, ptr }, ptr %l688, !tbaa !27
  %t1623 = extractvalue { i64, ptr } %t1622, 0
  store i64 %t1623, ptr %l689, !tbaa !24
  %t1624 = load i64, ptr %l689, !tbaa !24
  %t1625 = mul i64 %t1624, 1
  %t1626 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t1625)
  %t1627 = insertvalue { i64, ptr } undef, i64 %t1624, 0
  %t1628 = insertvalue { i64, ptr } %t1627, ptr %t1626, 1
  store { i64, ptr } %t1628, ptr %l690, !tbaa !27
  %t1629 = getelementptr { i64, ptr }, ptr %l690, i32 0, i32 1
  %t1630 = load ptr, ptr %t1629, !tbaa !27
  %t1631 = getelementptr { i64, ptr }, ptr %l688, i32 0, i32 1
  %t1632 = load ptr, ptr %t1631, !tbaa !27
  %t1633 = load i64, ptr %l689, !tbaa !24
  %t1634 = mul i64 %t1633, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t1630, ptr %t1632, i64 %t1634, i1 false)
  %t1635 = load { i64, ptr }, ptr %l690, !tbaa !27
  %t1636 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l684, i32 0, i32 1
  store { i64, ptr } %t1635, ptr %t1636, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t1637 = load { { i64, ptr }, { i64, ptr } }, ptr %l684
  store { { i64, ptr }, { i64, ptr } } %t1637, ptr %rv
  br label %ret
ret:
  %rr = load { { i64, ptr }, { i64, ptr } }, ptr %rv
  ret { { i64, ptr }, { i64, ptr } } %rr
}

define dso_local void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eResetAny(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l4 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l8 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca i64
  %l16 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l18 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l1, !tbaa !29
  %t2 = call ptr @__olang_scope_hold(ptr %v0)
  %t3 = ptrtoint ptr %t2 to i64
  store i64 %t3, ptr %l2, !tbaa !24
  %t4 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aProgram_2e70
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = call ptr @__olang_region_make(ptr %v0)
  %t7 = ptrtoint ptr %t6 to i64
  store i64 %t7, ptr %l2, !tbaa !24
  br label %bb2
bb2:
  %t8 = load i64, ptr %l2
  %t9 = inttoptr i64 %t8 to ptr
  %t10 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3aAnyTable_3e_2ector(ptr %t9, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t10, ptr %l4
  br label %bb3
bb3:
  %t11 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aProgram_2e70
  br i1 %t11, label %bb4, label %bb5
bb4:
  %t13 = load i64, ptr %l2
  %t14 = inttoptr i64 %t13 to ptr
  %t15 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l4, i32 0, i32 0
  %t16 = load { i64, ptr }, ptr %t15
  %t17 = extractvalue { i64, ptr } %t16, 1
  %t18 = call ptr @__olang_region_or(ptr %t17, ptr null)
  %t19 = call ptr @__olang_region_home(ptr %t18)
  %t20 = icmp ne ptr %t19, null
  %t21 = select i1 %t20, ptr %t19, ptr null
  call void @__olang_region_settle_in(ptr %t14, ptr %t21)
  br label %bb5
bb5:
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t23 = getelementptr %"compiler/generic:Program", ptr %t22, i32 0, i32 70
  %t24 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t23
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t24, ptr %l6
  %t25 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l4
  %t26 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr %"compiler/generic:Program", ptr %t26, i32 0, i32 70
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t25, ptr %t27
  %t28 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aProgram_2e70
  br i1 %t28, label %bb6, label %bb7
bb6:
  %t30 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l6, i32 0, i32 0
  %t31 = load { i64, ptr }, ptr %t30
  %t32 = extractvalue { i64, ptr } %t31, 1
  %t33 = call ptr @__olang_region_or(ptr %t32, ptr null)
  %t34 = call ptr @__olang_region_home(ptr %t33)
  %t35 = icmp ne ptr %t34, null
  %t36 = select i1 %t35, ptr %t34, ptr null
  call void @__olang_region_drop(ptr %t36)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" zeroinitializer, ptr %l6
  br label %bb7
bb7:
  store i64 0, ptr %l8, !tbaa !24
  br label %bb8
bb8:
  %t37 = load i64, ptr %l8, !tbaa !24
  %t38 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l6, i32 0, i32 1
  %t39 = load i64, ptr %t38, !tbaa !24
  %t40 = icmp slt i64 %t37, %t39
  br i1 %t40, label %bb9, label %bb10
bb9:
  %t42 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aAnyTable_2e5
  br i1 %t42, label %bb11, label %bb12
bb10:
  %t44 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3aAnyTable_3e_2e0
  br i1 %t44, label %bb15, label %bb16
bb11:
  %t46 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l6, i32 0, i32 0
  %t47 = load i64, ptr %l8, !tbaa !24
  %t48 = getelementptr { i64, ptr }, ptr %t46, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !27
  %t50 = getelementptr %"compiler/generic:AnyTable", ptr %t49, i64 %t47
  %t51 = getelementptr %"compiler/generic:AnyTable", ptr %t50, i32 0, i32 5
  %t52 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t51, i32 0, i32 0
  %t53 = load { i64, ptr }, ptr %t52
  %t54 = extractvalue { i64, ptr } %t53, 1
  %t55 = call ptr @__olang_region_or(ptr %t54, ptr null)
  %t56 = call ptr @__olang_region_home(ptr %t55)
  %t57 = icmp ne ptr %t56, null
  %t58 = select i1 %t57, ptr %t56, ptr null
  call void @__olang_region_drop(ptr %t58)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" zeroinitializer, ptr %t51
  br label %bb12
bb12:
  %t59 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t59, label %bb13, label %bb14
bb13:
  %t61 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l6, i32 0, i32 0
  %t62 = load i64, ptr %l8, !tbaa !24
  %t63 = getelementptr { i64, ptr }, ptr %t61, i32 0, i32 1
  %t64 = load ptr, ptr %t63, !tbaa !27
  %t65 = getelementptr %"compiler/generic:AnyTable", ptr %t64, i64 %t62
  %t66 = getelementptr %"compiler/generic:AnyTable", ptr %t65, i32 0, i32 5
  %t67 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t66, i32 0, i32 0
  %t68 = load { i64, ptr }, ptr %t67
  %t69 = extractvalue { i64, ptr } %t68, 0
  %t70 = extractvalue { i64, ptr } %t68, 1
  call void @__olang_region_release_part(ptr %t70, i64 %t69)
  store { i64, ptr } zeroinitializer, ptr %t67
  br label %bb14
bb14:
  %t71 = load i64, ptr %l8, !tbaa !24
  %t72 = add i64 %t71, 1
  store i64 %t72, ptr %l8, !tbaa !24
  br label %bb8
bb15:
  %t73 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l6, i32 0, i32 0
  %t74 = load { i64, ptr }, ptr %t73
  %t75 = extractvalue { i64, ptr } %t74, 0
  %t76 = extractvalue { i64, ptr } %t74, 1
  call void @__olang_region_release_part(ptr %t76, i64 %t75)
  store { i64, ptr } zeroinitializer, ptr %t73
  br label %bb16
bb16:
  %t77 = load ptr, ptr %l0, !tbaa !29
  store ptr %t77, ptr %l13, !tbaa !29
  %t78 = call ptr @__olang_scope_hold(ptr %v0)
  %t79 = ptrtoint ptr %t78 to i64
  store i64 %t79, ptr %l14, !tbaa !24
  %t80 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aProgram_2e71
  br i1 %t80, label %bb17, label %bb18
bb17:
  %t82 = call ptr @__olang_region_make(ptr %v0)
  %t83 = ptrtoint ptr %t82 to i64
  store i64 %t83, ptr %l14, !tbaa !24
  br label %bb18
bb18:
  %t84 = load i64, ptr %l14
  %t85 = inttoptr i64 %t84 to ptr
  %t86 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20I64_3e_2ector(ptr %t85)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t86, ptr %l16
  br label %bb19
bb19:
  %t87 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aProgram_2e71
  br i1 %t87, label %bb20, label %bb21
bb20:
  %t89 = load i64, ptr %l14
  %t90 = inttoptr i64 %t89 to ptr
  %t91 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l16, i32 0, i32 2
  %t92 = load { i64, ptr }, ptr %t91
  %t93 = extractvalue { i64, ptr } %t92, 1
  %t94 = call ptr @__olang_region_or(ptr %t93, ptr null)
  %t95 = call ptr @__olang_region_home(ptr %t94)
  %t96 = icmp ne ptr %t95, null
  %t97 = select i1 %t96, ptr %t95, ptr null
  %t98 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l16, i32 0, i32 1
  %t99 = load { i64, ptr }, ptr %t98
  %t100 = extractvalue { i64, ptr } %t99, 1
  %t101 = call ptr @__olang_region_or(ptr %t100, ptr null)
  %t102 = call ptr @__olang_region_home(ptr %t101)
  %t103 = icmp ne ptr %t102, null
  %t104 = select i1 %t103, ptr %t102, ptr %t97
  %t105 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l16, i32 0, i32 0
  %t106 = load { i64, ptr }, ptr %t105
  %t107 = extractvalue { i64, ptr } %t106, 1
  %t108 = call ptr @__olang_region_or(ptr %t107, ptr null)
  %t109 = call ptr @__olang_region_home(ptr %t108)
  %t110 = icmp ne ptr %t109, null
  %t111 = select i1 %t110, ptr %t109, ptr %t104
  call void @__olang_region_settle_in(ptr %t90, ptr %t111)
  br label %bb21
bb21:
  %t112 = load ptr, ptr %l13, !tbaa !29
  %t113 = getelementptr %"compiler/generic:Program", ptr %t112, i32 0, i32 71
  %t114 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t113
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t114, ptr %l18
  %t115 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l16
  %t116 = load ptr, ptr %l13, !tbaa !29
  %t117 = getelementptr %"compiler/generic:Program", ptr %t116, i32 0, i32 71
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t115, ptr %t117
  %t118 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aProgram_2e71
  br i1 %t118, label %bb22, label %bb23
bb22:
  %t120 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l18, i32 0, i32 2
  %t121 = load { i64, ptr }, ptr %t120
  %t122 = extractvalue { i64, ptr } %t121, 1
  %t123 = call ptr @__olang_region_or(ptr %t122, ptr null)
  %t124 = call ptr @__olang_region_home(ptr %t123)
  %t125 = icmp ne ptr %t124, null
  %t126 = select i1 %t125, ptr %t124, ptr null
  %t127 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l18, i32 0, i32 1
  %t128 = load { i64, ptr }, ptr %t127
  %t129 = extractvalue { i64, ptr } %t128, 1
  %t130 = call ptr @__olang_region_or(ptr %t129, ptr null)
  %t131 = call ptr @__olang_region_home(ptr %t130)
  %t132 = icmp ne ptr %t131, null
  %t133 = select i1 %t132, ptr %t131, ptr %t126
  %t134 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l18, i32 0, i32 0
  %t135 = load { i64, ptr }, ptr %t134
  %t136 = extractvalue { i64, ptr } %t135, 1
  %t137 = call ptr @__olang_region_or(ptr %t136, ptr null)
  %t138 = call ptr @__olang_region_home(ptr %t137)
  %t139 = icmp ne ptr %t138, null
  %t140 = select i1 %t139, ptr %t138, ptr %t133
  call void @__olang_region_drop(ptr %t140)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" zeroinitializer, ptr %l18
  br label %bb23
bb23:
  %t141 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20I64_3e_2e0
  br i1 %t141, label %bb24, label %bb25
bb24:
  %t143 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l18, i32 0, i32 0
  %t144 = load { i64, ptr }, ptr %t143
  %t145 = extractvalue { i64, ptr } %t144, 0
  %t146 = extractvalue { i64, ptr } %t144, 1
  call void @__olang_region_release_part(ptr %t146, i64 %t145)
  store { i64, ptr } zeroinitializer, ptr %t143
  br label %bb25
bb25:
  %t147 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20I64_3e_2e1
  br i1 %t147, label %bb26, label %bb27
bb26:
  %t149 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l18, i32 0, i32 1
  %t150 = load { i64, ptr }, ptr %t149
  %t151 = extractvalue { i64, ptr } %t150, 0
  %t152 = extractvalue { i64, ptr } %t150, 1
  call void @__olang_region_release_part(ptr %t152, i64 %t151)
  store { i64, ptr } zeroinitializer, ptr %t149
  br label %bb27
bb27:
  %t153 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20I64_3e_2e2
  br i1 %t153, label %bb28, label %bb29
bb28:
  %t155 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l18, i32 0, i32 2
  %t156 = load { i64, ptr }, ptr %t155
  %t157 = extractvalue { i64, ptr } %t156, 0
  %t158 = extractvalue { i64, ptr } %t156, 1
  call void @__olang_region_release_part(ptr %t158, i64 %t157)
  store { i64, ptr } zeroinitializer, ptr %t155
  br label %bb29
bb29:
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSubst(ptr %v0, ptr %a0, i32 %a1, i64 %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca %"compiler/generic:pattern"
  %l10 = alloca %"compiler/generic:Context"
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i32
  %l22 = alloca { i64, ptr }
  %l26 = alloca i32
  %l32 = alloca i64
  %l35 = alloca i1
  %l39 = alloca i64
  %l44 = alloca { i64, ptr }
  %l48 = alloca i64
  %l53 = alloca i32
  %l56 = alloca i1
  %l59 = alloca i1
  %l61 = alloca ptr
  %l65 = alloca i32
  %l66 = alloca { i64, ptr }
  %l70 = alloca i1
  %l73 = alloca { i64, ptr }
  %l75 = alloca i32
  %l78 = alloca { i64, ptr }
  %l83 = alloca i64
  %l87 = alloca i1
  %l91 = alloca i32
  %l95 = alloca ptr
  %l99 = alloca i32
  %l103 = alloca i64
  %l106 = alloca i32
  %l110 = alloca %"compiler/generic:pattern"
  %l112 = alloca ptr
  %l116 = alloca i64
  %l117 = alloca %"compiler/generic:pattern"
  %l118 = alloca i32
  %l120 = alloca %"compiler/generic:pattern"
  %l130 = alloca %"compiler/generic:Context"
  %l133 = alloca i64
  %l138 = alloca i64
  %l141 = alloca i64
  %l163 = alloca ptr
  %l167 = alloca %"compiler/generic:varRow"
  %l169 = alloca { i64, ptr }
  %l182 = alloca i32
  %l183 = alloca ptr
  %l184 = alloca ptr
  %l189 = alloca i32
  %l195 = alloca i32
  %l198 = alloca ptr
  %l202 = alloca i32
  %l203 = alloca ptr
  %l207 = alloca i32
  %l210 = alloca i32
  %l211 = alloca i32
  %l215 = alloca ptr
  %l216 = alloca ptr
  %l220 = alloca i32
  %l223 = alloca i32
  %l224 = alloca ptr
  %l228 = alloca i32
  %l231 = alloca i32
  %l232 = alloca i32
  %l236 = alloca ptr
  %l237 = alloca ptr
  %l241 = alloca i32
  %l244 = alloca i32
  %l248 = alloca i64
  %l249 = alloca i32
  %l255 = alloca i32
  %l263 = alloca i32
  %l265 = alloca ptr
  %l266 = alloca ptr
  %l270 = alloca i32
  %l273 = alloca i32
  %l274 = alloca ptr
  %l278 = alloca i32
  %l281 = alloca i32
  %l282 = alloca ptr
  %l286 = alloca i32
  %l289 = alloca i32
  %l293 = alloca i32
  %l297 = alloca i64
  %l301 = alloca i1
  %l302 = alloca i32
  %l306 = alloca i64
  %l307 = alloca i32
  %l310 = alloca ptr
  %l311 = alloca ptr
  %l315 = alloca i32
  %l318 = alloca i32
  %l319 = alloca i32
  %l323 = alloca ptr
  %l324 = alloca ptr
  %l328 = alloca i32
  %l331 = alloca i32
  %l332 = alloca i32
  %l336 = alloca ptr
  %l337 = alloca ptr
  %l341 = alloca i32
  %l344 = alloca i32
  %l345 = alloca i32
  %l349 = alloca ptr
  %l353 = alloca { i64, ptr }
  %l354 = alloca ptr
  %l358 = alloca i32
  %l361 = alloca i32
  %l365 = alloca { i64, ptr }
  %l366 = alloca i32
  %l370 = alloca ptr
  %l371 = alloca ptr
  %l375 = alloca i32
  %l378 = alloca i32
  %l379 = alloca i32
  %s6 = alloca %olang.scope
  %rv = alloca i32
  %t229 = alloca %"compiler/generic:Context", align 8
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i64 %a2, ptr %l2
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/generic:Program", ptr %t1, i32 0, i32 2
  %t4 = load i32, ptr %l3, !tbaa !23
  %t7 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t3, i32 %t4)
  store { i64, ptr } %t7, ptr %l22
  br label %bb1
bb1:
  %t8 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t8, ptr %l4, !tbaa !27
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/generic:Program", ptr %t9, i32 0, i32 2
  %t12 = load i32, ptr %l1, !tbaa !23
  %t15 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t11, i32 %t12)
  store i32 %t15, ptr %l26
  br label %bb2
bb2:
  %t16 = load i32, ptr %l26, !range !{i32 0, i32 33}
  store i32 %t16, ptr %l5
  %t17 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t19 = trunc i64 25 to i32
  %t20 = icmp eq i32 %t17, %t19
  br i1 %t20, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb43
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/generic:Program", ptr %t22, i32 0, i32 2
  %t25 = load i32, ptr %l1, !tbaa !23
  %t28 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eA(ptr %v0, ptr %t24, i32 %t25)
  store i64 %t28, ptr %l32
  br label %bb6
bb6:
  %t29 = load i64, ptr %l2, !tbaa !24
  %t30 = load i64, ptr %l32, !tbaa !24
  %t32 = icmp ne i64 %t30, %t29
  br i1 %t32, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l35, !tbaa !21
  br label %bb10
bb8:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/generic:Program", ptr %t34, i32 0, i32 2
  %t37 = load i32, ptr %l1, !tbaa !23
  %t40 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eB(ptr %v0, ptr %t36, i32 %t37)
  store i64 %t40, ptr %l39
  br label %bb9
bb9:
  %t41 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t41, 0
  %t44 = load i64, ptr %l39, !tbaa !24
  %t46 = icmp sge i64 %t44, %t43
  store i1 %t46, ptr %l35, !tbaa !21
  br label %bb10
bb10:
  %t48 = load i1, ptr %l35, !tbaa !21
  br i1 %t48, label %bb11, label %bb12
bb11:
  %t49 = load i32, ptr %l1, !tbaa !23
  store i32 %t49, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  %t51 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t51, ptr %l44, !tbaa !27
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/generic:Program", ptr %t52, i32 0, i32 2
  %t55 = load i32, ptr %l1, !tbaa !23
  %t58 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eB(ptr %v0, ptr %t54, i32 %t55)
  store i64 %t58, ptr %l48
  br label %bb14
bb14:
  %t59 = load i64, ptr %l48, !tbaa !24
  %t60 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !27
  %t62 = getelementptr i32, ptr %t61, i64 %t59
  %t63 = load i32, ptr %t62, !tbaa !33
  store i32 %t63, ptr %l6, !tbaa !23
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/generic:Program", ptr %t65, i32 0, i32 2
  %t68 = load i32, ptr %l6, !tbaa !23
  %t71 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t67, i32 %t68)
  store i32 %t71, ptr %l53
  br label %bb15
bb15:
  %t72 = load i32, ptr %l53, !range !{i32 0, i32 33}
  %t74 = trunc i64 30 to i32
  %t75 = icmp eq i32 %t72, %t74
  br i1 %t75, label %bb16, label %bb17
bb16:
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t78 = load i32, ptr %l1, !tbaa !23
  %t81 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsErrVar(ptr %v0, ptr %t77, i32 %t78)
  store i1 %t81, ptr %l59
  br label %bb18
bb17:
  store i1 false, ptr %l56, !tbaa !21
  br label %bb19
bb18:
  %t82 = load i1, ptr %l59, !tbaa !21
  store i1 %t82, ptr %l56, !tbaa !21
  br label %bb19
bb19:
  %t83 = load i1, ptr %l56, !tbaa !21
  br i1 %t83, label %bb20, label %bb21
bb20:
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr %"compiler/generic:Program", ptr %t84, i32 0, i32 2
  store ptr %t86, ptr %l61, !tbaa !29
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr %"compiler/generic:Program", ptr %t87, i32 0, i32 2
  %t90 = load i32, ptr %l6, !tbaa !23
  %t93 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrSetItems(ptr %v0, ptr %t89, i32 %t90)
  store i32 %t93, ptr %l65
  br label %bb22
bb21:
  br label %bb31
bb22:
  %t94 = load ptr, ptr %l61, !tbaa !29
  %t95 = load i32, ptr %l65, !tbaa !23
  %t96 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t94, i32 %t95)
  store { i64, ptr } %t96, ptr %l66
  br label %bb23
bb23:
  %t97 = load { i64, ptr }, ptr %l66, !tbaa !27
  store { i64, ptr } %t97, ptr %l7, !tbaa !27
  %t98 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t100 = extractvalue { i64, ptr } %t98, 0
  %t102 = icmp eq i64 %t100, 1
  br i1 %t102, label %bb24, label %bb25
bb24:
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t106 = getelementptr %"compiler/generic:Program", ptr %t104, i32 0, i32 2
  %t107 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t107, ptr %l73, !tbaa !27
  %t108 = getelementptr { i64, ptr }, ptr %l73, i32 0, i32 1
  %t109 = load ptr, ptr %t108, !tbaa !27
  %t110 = getelementptr i32, ptr %t109, i64 0
  %t111 = load i32, ptr %t110, !tbaa !33
  %t114 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t106, i32 %t111)
  store i32 %t114, ptr %l75
  br label %bb26
bb25:
  store i1 false, ptr %l70, !tbaa !21
  br label %bb27
bb26:
  %t115 = load i32, ptr %l75, !range !{i32 0, i32 33}
  %t117 = trunc i64 25 to i32
  %t118 = icmp eq i32 %t115, %t117
  store i1 %t118, ptr %l70, !tbaa !21
  br label %bb27
bb27:
  %t120 = load i1, ptr %l70, !tbaa !21
  br i1 %t120, label %bb28, label %bb29
bb28:
  %t121 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t121, ptr %l78, !tbaa !27
  %t122 = getelementptr { i64, ptr }, ptr %l78, i32 0, i32 1
  %t123 = load ptr, ptr %t122, !tbaa !27
  %t124 = getelementptr i32, ptr %t123, i64 0
  %t125 = load i32, ptr %t124, !tbaa !33
  store i32 %t125, ptr %rv
  br label %ret
bb29:
  br label %bb30
bb30:
  br label %bb31
bb31:
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t129 = getelementptr %"compiler/generic:Program", ptr %t127, i32 0, i32 2
  %t130 = load i32, ptr %l1, !tbaa !23
  %t133 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eC(ptr %v0, ptr %t129, i32 %t130)
  store i64 %t133, ptr %l83
  br label %bb32
bb32:
  %t134 = load i64, ptr %l83, !tbaa !24
  store i64 %t134, ptr %l8, !tbaa !24
  %t135 = load i64, ptr %l8, !tbaa !24
  %t136 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t139 = icmp ne i64 %t135, %t136
  br i1 %t139, label %bb33, label %bb34
bb33:
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t143 = getelementptr %"compiler/generic:Program", ptr %t141, i32 0, i32 2
  %t144 = load i32, ptr %l6, !tbaa !23
  %t147 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t143, i32 %t144)
  store i32 %t147, ptr %l91
  br label %bb35
bb34:
  store i1 false, ptr %l87, !tbaa !21
  br label %bb36
bb35:
  %t148 = load i32, ptr %l91, !range !{i32 0, i32 33}
  %t150 = trunc i64 20 to i32
  %t151 = icmp eq i32 %t148, %t150
  store i1 %t151, ptr %l87, !tbaa !21
  br label %bb36
bb36:
  %t153 = load i1, ptr %l87, !tbaa !21
  br i1 %t153, label %bb37, label %bb38
bb37:
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t156 = getelementptr %"compiler/generic:Program", ptr %t154, i32 0, i32 2
  store ptr %t156, ptr %l95, !tbaa !29
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t159 = getelementptr %"compiler/generic:Program", ptr %t157, i32 0, i32 2
  %t160 = load i32, ptr %l6, !tbaa !23
  %t163 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t159, i32 %t160)
  store i32 %t163, ptr %l99
  br label %bb39
bb38:
  br label %bb42
bb39:
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t166 = getelementptr %"compiler/generic:Program", ptr %t164, i32 0, i32 2
  %t167 = load i32, ptr %l6, !tbaa !23
  %t170 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t166, i32 %t167)
  store i64 %t170, ptr %l103
  br label %bb40
bb40:
  %t171 = load i64, ptr %l8, !tbaa !24
  %t172 = load i64, ptr %l103, !tbaa !24
  %t174 = or i64 %t172, %t171
  %t175 = load ptr, ptr %l95, !tbaa !29
  %t176 = load i32, ptr %l99, !tbaa !23
  %t178 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t175, i32 %t176, i64 %t174)
  store i32 %t178, ptr %l106
  br label %bb41
bb41:
  %t179 = load i32, ptr %l106, !tbaa !23
  store i32 %t179, ptr %rv
  br label %ret
bb42:
  %t180 = load i32, ptr %l6, !tbaa !23
  store i32 %t180, ptr %rv
  br label %ret
bb43:
  %t182 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t184 = trunc i64 27 to i32
  %t185 = icmp eq i32 %t182, %t184
  br i1 %t185, label %bb44, label %bb45
bb44:
  br label %bb46
bb45:
  br label %bb86
bb46:
  store %olang.scope zeroinitializer, ptr %s6
  %t187 = load ptr, ptr %l0, !tbaa !29
  %t189 = getelementptr %"compiler/generic:Program", ptr %t187, i32 0, i32 30
  store ptr %t189, ptr %l112, !tbaa !29
  %t190 = load ptr, ptr %l0, !tbaa !29
  %t192 = getelementptr %"compiler/generic:Program", ptr %t190, i32 0, i32 2
  %t193 = load i32, ptr %l1, !tbaa !23
  %t196 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eA(ptr %v0, ptr %t192, i32 %t193)
  store i64 %t196, ptr %l116
  br label %bb47
bb47:
  %t197 = load ptr, ptr %l112, !tbaa !29
  %t198 = load i64, ptr %l116, !tbaa !24
  %t199 = call { i32, %"compiler/generic:pattern" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fgeneric_3apattern__He653b1131e20b64758f13c09ef1dc8c5(ptr %v0, ptr %v0, ptr %t197, i64 %t198)
  %t200 = extractvalue { i32, %"compiler/generic:pattern" } %t199, 1
  %t201 = extractvalue { i32, %"compiler/generic:pattern" } %t199, 0
  store i32 %t201, ptr %l118
  %t202 = icmp ne i32 %t201, 0
  br i1 %t202, label %bb49, label %ok.203, !prof !99
ok.203:
  store %"compiler/generic:pattern" %t200, ptr %l117
  br label %bb48
bb48:
  %t204 = load %"compiler/generic:pattern", ptr %l117
  store %"compiler/generic:pattern" %t204, ptr %l110
  br label %bb52
bb49:
  br label %bb50
bb50:
  %t205 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t207 = call %"compiler/generic:pattern" @compiler_2fgeneric_3apattern_2ector(ptr %v0, ptr %v0, ptr %v0, ptr null, i64 -1, i64 -2, i32 %t205, ptr null)
  store %"compiler/generic:pattern" %t207, ptr %l120
  br label %bb51
bb51:
  %t208 = load %"compiler/generic:pattern", ptr %l120
  store %"compiler/generic:pattern" %t208, ptr %l110
  br label %bb52
bb52:
  %t209 = load %"compiler/generic:pattern", ptr %l110
  store %"compiler/generic:pattern" %t209, ptr %l9
  %t210 = getelementptr %"compiler/generic:pattern", ptr %l9, i32 0, i32 2
  %t211 = load i64, ptr %t210, !tbaa !24
  %t213 = icmp eq i64 %t211, -2
  br i1 %t213, label %bb53, label %bb54
bb53:
  %t215 = load i32, ptr %l1, !tbaa !23
  call void @__olang_scope_close(ptr %s6)
  store i32 %t215, ptr %rv
  br label %ret
bb54:
  br label %bb55
bb55:
  %t217 = getelementptr %"compiler/generic:pattern", ptr %l9, i32 0, i32 2
  %t218 = load i64, ptr %t217, !tbaa !24
  %t219 = load i64, ptr %l2, !tbaa !24
  %t222 = icmp ne i64 %t218, %t219
  br i1 %t222, label %bb56, label %bb57
bb56:
  %t224 = load i32, ptr %l1, !tbaa !23
  call void @__olang_scope_close(ptr %s6)
  store i32 %t224, ptr %rv
  br label %ret
bb57:
  br label %bb58
bb58:
  %t226 = getelementptr %"compiler/generic:pattern", ptr %l9, i32 0, i32 1
  %t227 = load i64, ptr %t226, !tbaa !24
  %t228 = load i64, ptr %l2, !tbaa !24
  call void @compiler_2fgeneric_3aContext_2ector(ptr %t229, ptr %s6, i64 %t227, i64 %t228)
  call void @llvm.memmove.p0.p0.i64(ptr %l130, ptr %t229, i64 160, i1 false)
  br label %bb59
bb59:
  call void @llvm.memmove.p0.p0.i64(ptr %l10, ptr %l130, i64 160, i1 false)
  %t232 = load ptr, ptr %l0, !tbaa !29
  %t233 = load i64, ptr %l2, !tbaa !24
  %t236 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v0, ptr %t232, i64 %t233)
  store i64 %t236, ptr %l133
  br label %bb60
bb60:
  %t237 = load i64, ptr %l133, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  store i64 %t237, ptr %l13, !tbaa !24
  store i64 1, ptr %l14, !tbaa !24
  %t240 = load i64, ptr %l13, !tbaa !24
  %t241 = load i64, ptr %l12, !tbaa !24
  %t244 = icmp sgt i64 %t240, %t241
  br i1 %t244, label %bb61, label %bb62
bb61:
  %t246 = load i64, ptr %l14, !tbaa !24
  %t248 = icmp sgt i64 %t246, 0
  br i1 %t248, label %bb63, label %bb64
bb62:
  store i64 0, ptr %l138, !tbaa !24
  br label %bb66
bb63:
  %t250 = load i64, ptr %l13, !tbaa !24
  %t251 = load i64, ptr %l12, !tbaa !24
  %t254 = sub i64 %t250, %t251
  %t255 = load i64, ptr %l14, !tbaa !24
  %t258 = add i64 %t254, %t255
  %t260 = sub i64 %t258, 1
  %t261 = load i64, ptr %l14, !tbaa !24
  %t264 = sdiv i64 %t260, %t261
  store i64 %t264, ptr %l141, !tbaa !24
  br label %bb65
bb64:
  store i64 0, ptr %l141, !tbaa !24
  br label %bb65
bb65:
  %t266 = load i64, ptr %l141, !tbaa !24
  store i64 %t266, ptr %l138, !tbaa !24
  br label %bb66
bb66:
  %t267 = load i64, ptr %l138, !tbaa !24
  store i64 %t267, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  br label %bb67
bb67:
  %t268 = load i64, ptr %l16, !tbaa !24
  %t269 = load i64, ptr %l15, !tbaa !24
  %t272 = icmp slt i64 %t268, %t269
  %t274 = xor i1 %t272, true
  br i1 %t274, label %bb68, label %bb69
bb68:
  br label %bb77
bb69:
  br label %bb70
bb70:
  %t276 = load i64, ptr %l12, !tbaa !24
  %t277 = load i64, ptr %l16, !tbaa !24
  %t278 = load i64, ptr %l14, !tbaa !24
  %t281 = mul i64 %t277, %t278
  %t284 = add i64 %t276, %t281
  store i64 %t284, ptr %l17, !tbaa !24
  %t286 = load i64, ptr %l17, !tbaa !24
  %t287 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t289 = extractvalue { i64, ptr } %t287, 0
  %t292 = icmp slt i64 %t286, %t289
  br i1 %t292, label %bb71, label %bb72
bb71:
  %t294 = getelementptr %"compiler/generic:Context", ptr %l10, i32 0, i32 2
  store ptr %t294, ptr %l163, !tbaa !29
  %t295 = load ptr, ptr %l0, !tbaa !29
  %t296 = load i64, ptr %l2, !tbaa !24
  %t297 = load i64, ptr %l17, !tbaa !24
  %t301 = call %"compiler/generic:varRow" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarAt(ptr %v0, ptr %t295, i64 %t296, i64 %t297)
  store %"compiler/generic:varRow" %t301, ptr %l167
  br label %bb73
bb72:
  br label %bb75
bb73:
  %t302 = getelementptr %"compiler/generic:varRow", ptr %l167, i32 0, i32 1
  %t303 = load i32, ptr %t302, !tbaa !23
  %t304 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t304, ptr %l169, !tbaa !27
  %t305 = load i64, ptr %l17, !tbaa !24
  %t307 = getelementptr { i64, ptr }, ptr %l169, i32 0, i32 1
  %t308 = load ptr, ptr %t307, !tbaa !27
  %t309 = getelementptr i32, ptr %t308, i64 %t305
  %t310 = load i32, ptr %t309, !tbaa !33
  %t311 = load ptr, ptr %l163, !tbaa !29
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_H943a9bb03970f71acf57214091669a7d(ptr %s6, ptr %t311, i32 %t303, i32 %t310)
  br label %bb74
bb74:
  br label %bb75
bb75:
  br label %bb76
bb76:
  %t314 = load i64, ptr %l16, !tbaa !24
  %t317 = add i64 %t314, 1
  store i64 %t317, ptr %l16, !tbaa !24
  br label %bb67
bb77:
  %t319 = getelementptr %"compiler/generic:pattern", ptr %l9, i32 0, i32 4
  %t320 = load ptr, ptr %t319, !tbaa !29
  %t322 = icmp eq ptr %t320, null
  %t324 = xor i1 %t322, true
  br i1 %t324, label %bb78, label %bb79
bb78:
  %t326 = load ptr, ptr %l0, !tbaa !29
  %t327 = getelementptr %"compiler/generic:pattern", ptr %l9, i32 0, i32 4
  %t328 = load ptr, ptr %t327, !tbaa !29
  %t333 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eResolve(ptr %v0, ptr %s6, ptr %v0, ptr %t326, ptr %l10, ptr %t328)
  store i32 %t333, ptr %l182
  br label %bb80
bb79:
  br label %bb81
bb80:
  call void @__olang_scope_close(ptr %s6)
  %t334 = load i32, ptr %l182, !tbaa !23
  store i32 %t334, ptr %rv
  br label %ret
bb81:
  %t335 = load ptr, ptr %l0, !tbaa !29
  store ptr %t335, ptr %l183, !tbaa !29
  store ptr %l10, ptr %l184, !tbaa !29
  %t336 = getelementptr %"compiler/generic:pattern", ptr %l9, i32 0, i32 0
  %t337 = load ptr, ptr %t336, !tbaa !29
  %t339 = icmp eq ptr %t337, null
  br i1 %t339, label %bb82, label %bb83
bb82:
  call void @__olang_check_failed(ptr @olang_loc_58f0122f37ec3c06_2c6a4c04431557c2)
  unreachable
bb83:
  br label %bb84
bb84:
  %t341 = getelementptr %"compiler/generic:pattern", ptr %l9, i32 0, i32 0
  %t342 = load ptr, ptr %t341, !tbaa !29
  %t343 = getelementptr %"compiler/generic:pattern", ptr %l9, i32 0, i32 3
  %t344 = load i32, ptr %t343, !tbaa !23
  %t345 = load ptr, ptr %l183, !tbaa !29
  %t346 = load ptr, ptr %l184, !tbaa !29
  %t349 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2efold(ptr %v0, ptr %s6, ptr %v0, ptr %t345, ptr %t346, ptr %t342, i32 %t344)
  store i32 %t349, ptr %l189
  br label %bb85
bb85:
  call void @__olang_scope_close(ptr %s6)
  %t350 = load i32, ptr %l189, !tbaa !23
  store i32 %t350, ptr %rv
  br label %ret
bb86:
  %t351 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t353 = trunc i64 18 to i32
  %t354 = icmp eq i32 %t351, %t353
  br i1 %t354, label %bb87, label %bb88
bb87:
  br label %bb89
bb88:
  br label %bb98
bb89:
  %t356 = load ptr, ptr %l0, !tbaa !29
  %t358 = getelementptr %"compiler/generic:Program", ptr %t356, i32 0, i32 2
  %t359 = load i32, ptr %l1, !tbaa !23
  %t362 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %t358, i32 %t359)
  store i32 %t362, ptr %l195
  br label %bb90
bb90:
  %t363 = load i32, ptr %l195, !tbaa !23
  %t364 = icmp eq i32 %t363, 0
  br i1 %t364, label %bb91, label %bb92
bb91:
  %t366 = load i32, ptr %l1, !tbaa !23
  store i32 %t366, ptr %rv
  br label %ret
bb92:
  br label %bb93
bb93:
  %t368 = load ptr, ptr %l0, !tbaa !29
  store ptr %t368, ptr %l198, !tbaa !29
  %t369 = load ptr, ptr %l0, !tbaa !29
  %t371 = getelementptr %"compiler/generic:Program", ptr %t369, i32 0, i32 2
  %t372 = load i32, ptr %l1, !tbaa !23
  %t375 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t371, i32 %t372)
  store i32 %t375, ptr %l202
  br label %bb94
bb94:
  %t376 = load ptr, ptr %l0, !tbaa !29
  store ptr %t376, ptr %l203, !tbaa !29
  %t377 = load ptr, ptr %l0, !tbaa !29
  %t379 = getelementptr %"compiler/generic:Program", ptr %t377, i32 0, i32 2
  %t380 = load i32, ptr %l1, !tbaa !23
  %t383 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %t379, i32 %t380)
  store i32 %t383, ptr %l207
  br label %bb95
bb95:
  %t384 = load i64, ptr %l2, !tbaa !24
  %t385 = load i32, ptr %l3, !tbaa !23
  %t386 = load ptr, ptr %l203, !tbaa !29
  %t387 = load i32, ptr %l207, !tbaa !23
  %t390 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2esubstList(ptr %v0, ptr %t386, i32 %t387, i64 %t384, i32 %t385)
  store i32 %t390, ptr %l210
  br label %bb96
bb96:
  %t391 = load ptr, ptr %l198, !tbaa !29
  %t392 = load i32, ptr %l202, !tbaa !23
  %t393 = load i32, ptr %l210, !tbaa !23
  %t394 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstance(ptr %v0, ptr %t391, i32 %t392, i32 %t393)
  store i32 %t394, ptr %l211
  br label %bb97
bb97:
  %t395 = load i32, ptr %l211, !tbaa !23
  store i32 %t395, ptr %rv
  br label %ret
bb98:
  %t396 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t398 = trunc i64 19 to i32
  %t399 = icmp eq i32 %t396, %t398
  br i1 %t399, label %bb99, label %bb100
bb99:
  br label %bb101
bb100:
  br label %bb107
bb101:
  %t401 = load ptr, ptr %l0, !tbaa !29
  %t403 = getelementptr %"compiler/generic:Program", ptr %t401, i32 0, i32 2
  store ptr %t403, ptr %l215, !tbaa !29
  %t404 = load ptr, ptr %l0, !tbaa !29
  store ptr %t404, ptr %l216, !tbaa !29
  %t405 = load ptr, ptr %l0, !tbaa !29
  %t407 = getelementptr %"compiler/generic:Program", ptr %t405, i32 0, i32 2
  %t408 = load i32, ptr %l1, !tbaa !23
  %t411 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t407, i32 %t408)
  store i32 %t411, ptr %l220
  br label %bb102
bb102:
  %t412 = load i64, ptr %l2, !tbaa !24
  %t413 = load i32, ptr %l3, !tbaa !23
  %t414 = load ptr, ptr %l216, !tbaa !29
  %t415 = load i32, ptr %l220, !tbaa !23
  %t418 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSubst(ptr %v0, ptr %t414, i32 %t415, i64 %t412, i32 %t413)
  store i32 %t418, ptr %l223
  br label %bb103
bb103:
  %t419 = load ptr, ptr %l0, !tbaa !29
  store ptr %t419, ptr %l224, !tbaa !29
  %t420 = load ptr, ptr %l0, !tbaa !29
  %t422 = getelementptr %"compiler/generic:Program", ptr %t420, i32 0, i32 2
  %t423 = load i32, ptr %l1, !tbaa !23
  %t426 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t422, i32 %t423)
  store i32 %t426, ptr %l228
  br label %bb104
bb104:
  %t427 = load i64, ptr %l2, !tbaa !24
  %t428 = load i32, ptr %l3, !tbaa !23
  %t429 = load ptr, ptr %l224, !tbaa !29
  %t430 = load i32, ptr %l228, !tbaa !23
  %t433 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSubst(ptr %v0, ptr %t429, i32 %t430, i64 %t427, i32 %t428)
  store i32 %t433, ptr %l231
  br label %bb105
bb105:
  %t434 = load ptr, ptr %l215, !tbaa !29
  %t435 = load i32, ptr %l223, !tbaa !23
  %t436 = load i32, ptr %l231, !tbaa !23
  %t437 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArray(ptr %v0, ptr %t434, i32 %t435, i32 %t436)
  store i32 %t437, ptr %l232
  br label %bb106
bb106:
  %t438 = load i32, ptr %l232, !tbaa !23
  store i32 %t438, ptr %rv
  br label %ret
bb107:
  %t439 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t441 = trunc i64 20 to i32
  %t442 = icmp eq i32 %t439, %t441
  br i1 %t442, label %bb108, label %bb109
bb108:
  br label %bb110
bb109:
  br label %bb115
bb110:
  %t444 = load ptr, ptr %l0, !tbaa !29
  %t446 = getelementptr %"compiler/generic:Program", ptr %t444, i32 0, i32 2
  store ptr %t446, ptr %l236, !tbaa !29
  %t447 = load ptr, ptr %l0, !tbaa !29
  store ptr %t447, ptr %l237, !tbaa !29
  %t448 = load ptr, ptr %l0, !tbaa !29
  %t450 = getelementptr %"compiler/generic:Program", ptr %t448, i32 0, i32 2
  %t451 = load i32, ptr %l1, !tbaa !23
  %t454 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t450, i32 %t451)
  store i32 %t454, ptr %l241
  br label %bb111
bb111:
  %t455 = load i64, ptr %l2, !tbaa !24
  %t456 = load i32, ptr %l3, !tbaa !23
  %t457 = load ptr, ptr %l237, !tbaa !29
  %t458 = load i32, ptr %l241, !tbaa !23
  %t461 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSubst(ptr %v0, ptr %t457, i32 %t458, i64 %t455, i32 %t456)
  store i32 %t461, ptr %l244
  br label %bb112
bb112:
  %t462 = load ptr, ptr %l0, !tbaa !29
  %t464 = getelementptr %"compiler/generic:Program", ptr %t462, i32 0, i32 2
  %t465 = load i32, ptr %l1, !tbaa !23
  %t468 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t464, i32 %t465)
  store i64 %t468, ptr %l248
  br label %bb113
bb113:
  %t469 = load ptr, ptr %l236, !tbaa !29
  %t470 = load i32, ptr %l244, !tbaa !23
  %t471 = load i64, ptr %l248, !tbaa !24
  %t472 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t469, i32 %t470, i64 %t471)
  store i32 %t472, ptr %l249
  br label %bb114
bb114:
  %t473 = load i32, ptr %l249, !tbaa !23
  store i32 %t473, ptr %rv
  br label %ret
bb115:
  %t474 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t476 = trunc i64 21 to i32
  %t477 = icmp eq i32 %t474, %t476
  br i1 %t477, label %bb116, label %bb117
bb116:
  br label %bb118
bb117:
  br label %bb135
bb118:
  %t479 = load ptr, ptr %l0, !tbaa !29
  %t481 = getelementptr %"compiler/generic:Program", ptr %t479, i32 0, i32 2
  %t482 = load i32, ptr %l1, !tbaa !23
  %t485 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFuncTag(ptr %v0, ptr %t481, i32 %t482)
  store i32 %t485, ptr %l255
  br label %bb119
bb119:
  %t486 = load i32, ptr %l255, !tbaa !23
  store i32 %t486, ptr %l18, !tbaa !23
  %t487 = load i32, ptr %l18, !tbaa !23
  %t488 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t491 = icmp ne i32 %t487, %t488
  br i1 %t491, label %bb120, label %bb121
bb120:
  %t493 = load ptr, ptr %l0, !tbaa !29
  %t494 = load i32, ptr %l18, !tbaa !23
  %t495 = load i64, ptr %l2, !tbaa !24
  %t496 = load i32, ptr %l3, !tbaa !23
  %t501 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSubst(ptr %v0, ptr %t493, i32 %t494, i64 %t495, i32 %t496)
  store i32 %t501, ptr %l263
  br label %bb122
bb121:
  br label %bb123
bb122:
  %t502 = load i32, ptr %l263, !tbaa !23
  store i32 %t502, ptr %l18, !tbaa !23
  br label %bb123
bb123:
  %t503 = load ptr, ptr %l0, !tbaa !29
  %t505 = getelementptr %"compiler/generic:Program", ptr %t503, i32 0, i32 2
  store ptr %t505, ptr %l265, !tbaa !29
  %t506 = load ptr, ptr %l0, !tbaa !29
  store ptr %t506, ptr %l266, !tbaa !29
  %t507 = load ptr, ptr %l0, !tbaa !29
  %t509 = getelementptr %"compiler/generic:Program", ptr %t507, i32 0, i32 2
  %t510 = load i32, ptr %l1, !tbaa !23
  %t513 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t509, i32 %t510)
  store i32 %t513, ptr %l270
  br label %bb124
bb124:
  %t514 = load i64, ptr %l2, !tbaa !24
  %t515 = load i32, ptr %l3, !tbaa !23
  %t516 = load ptr, ptr %l266, !tbaa !29
  %t517 = load i32, ptr %l270, !tbaa !23
  %t520 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2esubstList(ptr %v0, ptr %t516, i32 %t517, i64 %t514, i32 %t515)
  store i32 %t520, ptr %l273
  br label %bb125
bb125:
  %t521 = load ptr, ptr %l0, !tbaa !29
  store ptr %t521, ptr %l274, !tbaa !29
  %t522 = load ptr, ptr %l0, !tbaa !29
  %t524 = getelementptr %"compiler/generic:Program", ptr %t522, i32 0, i32 2
  %t525 = load i32, ptr %l1, !tbaa !23
  %t528 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t524, i32 %t525)
  store i32 %t528, ptr %l278
  br label %bb126
bb126:
  %t529 = load i64, ptr %l2, !tbaa !24
  %t530 = load i32, ptr %l3, !tbaa !23
  %t531 = load ptr, ptr %l274, !tbaa !29
  %t532 = load i32, ptr %l278, !tbaa !23
  %t535 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSubst(ptr %v0, ptr %t531, i32 %t532, i64 %t529, i32 %t530)
  store i32 %t535, ptr %l281
  br label %bb127
bb127:
  %t536 = load ptr, ptr %l0, !tbaa !29
  store ptr %t536, ptr %l282, !tbaa !29
  %t537 = load ptr, ptr %l0, !tbaa !29
  %t539 = getelementptr %"compiler/generic:Program", ptr %t537, i32 0, i32 2
  %t540 = load i32, ptr %l1, !tbaa !23
  %t543 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t539, i32 %t540)
  store i32 %t543, ptr %l286
  br label %bb128
bb128:
  %t544 = load i64, ptr %l2, !tbaa !24
  %t545 = load i32, ptr %l3, !tbaa !23
  %t546 = load ptr, ptr %l282, !tbaa !29
  %t547 = load i32, ptr %l286, !tbaa !23
  %t550 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2esubstErrs(ptr %v0, ptr %t546, i32 %t547, i64 %t544, i32 %t545)
  store i32 %t550, ptr %l289
  br label %bb129
bb129:
  %t551 = load ptr, ptr %l0, !tbaa !29
  %t553 = getelementptr %"compiler/generic:Program", ptr %t551, i32 0, i32 2
  %t554 = load i32, ptr %l1, !tbaa !23
  %t557 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopesOf(ptr %v0, ptr %t553, i32 %t554)
  store i32 %t557, ptr %l293
  br label %bb130
bb130:
  %t558 = load ptr, ptr %l0, !tbaa !29
  %t560 = getelementptr %"compiler/generic:Program", ptr %t558, i32 0, i32 2
  %t561 = load i32, ptr %l1, !tbaa !23
  %t564 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNamesIdOf(ptr %v0, ptr %t560, i32 %t561)
  store i64 %t564, ptr %l297
  br label %bb131
bb131:
  %t565 = load ptr, ptr %l0, !tbaa !29
  %t567 = getelementptr %"compiler/generic:Program", ptr %t565, i32 0, i32 2
  %t568 = load i32, ptr %l1, !tbaa !23
  %t571 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFuncNullable(ptr %v0, ptr %t567, i32 %t568)
  store i1 %t571, ptr %l301
  br label %bb132
bb132:
  %t572 = load i32, ptr %l18, !tbaa !23
  store i32 %t572, ptr %l302, !tbaa !23
  %t573 = load ptr, ptr %l0, !tbaa !29
  %t575 = getelementptr %"compiler/generic:Program", ptr %t573, i32 0, i32 2
  %t576 = load i32, ptr %l1, !tbaa !23
  %t579 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePromisesOf(ptr %v0, ptr %t575, i32 %t576)
  store i64 %t579, ptr %l306
  br label %bb133
bb133:
  %t580 = load ptr, ptr %l265, !tbaa !29
  %t581 = load i32, ptr %l273, !tbaa !23
  %t582 = load i32, ptr %l281, !tbaa !23
  %t583 = load i32, ptr %l289, !tbaa !23
  %t584 = load i32, ptr %l293, !tbaa !23
  %t585 = load i64, ptr %l297, !tbaa !24
  %t586 = load i1, ptr %l301, !tbaa !21
  %t587 = load i32, ptr %l302, !tbaa !23
  %t588 = load i64, ptr %l306, !tbaa !24
  %t589 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t580, i32 %t581, i32 %t582, i32 %t583, i32 %t584, i64 %t585, i1 %t586, i32 %t587, i64 %t588)
  store i32 %t589, ptr %l307
  br label %bb134
bb134:
  %t590 = load i32, ptr %l307, !tbaa !23
  store i32 %t590, ptr %rv
  br label %ret
bb135:
  %t591 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t593 = trunc i64 30 to i32
  %t594 = icmp eq i32 %t591, %t593
  br i1 %t594, label %bb136, label %bb137
bb136:
  br label %bb138
bb137:
  br label %bb142
bb138:
  %t596 = load ptr, ptr %l0, !tbaa !29
  store ptr %t596, ptr %l310, !tbaa !29
  %t597 = load ptr, ptr %l0, !tbaa !29
  store ptr %t597, ptr %l311, !tbaa !29
  %t598 = load ptr, ptr %l0, !tbaa !29
  %t600 = getelementptr %"compiler/generic:Program", ptr %t598, i32 0, i32 2
  %t601 = load i32, ptr %l1, !tbaa !23
  %t604 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrSetItems(ptr %v0, ptr %t600, i32 %t601)
  store i32 %t604, ptr %l315
  br label %bb139
bb139:
  %t605 = load i64, ptr %l2, !tbaa !24
  %t606 = load i32, ptr %l3, !tbaa !23
  %t607 = load ptr, ptr %l311, !tbaa !29
  %t608 = load i32, ptr %l315, !tbaa !23
  %t611 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2esubstErrs(ptr %v0, ptr %t607, i32 %t608, i64 %t605, i32 %t606)
  store i32 %t611, ptr %l318
  br label %bb140
bb140:
  %t612 = load ptr, ptr %l310, !tbaa !29
  %t613 = load i32, ptr %l318, !tbaa !23
  %t614 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrSetOf(ptr %v0, ptr %t612, i32 %t613)
  store i32 %t614, ptr %l319
  br label %bb141
bb141:
  %t615 = load i32, ptr %l319, !tbaa !23
  store i32 %t615, ptr %rv
  br label %ret
bb142:
  %t616 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t618 = trunc i64 22 to i32
  %t619 = icmp eq i32 %t616, %t618
  br i1 %t619, label %bb143, label %bb144
bb143:
  br label %bb145
bb144:
  br label %bb149
bb145:
  %t621 = load ptr, ptr %l0, !tbaa !29
  %t623 = getelementptr %"compiler/generic:Program", ptr %t621, i32 0, i32 2
  store ptr %t623, ptr %l323, !tbaa !29
  %t624 = load ptr, ptr %l0, !tbaa !29
  store ptr %t624, ptr %l324, !tbaa !29
  %t625 = load ptr, ptr %l0, !tbaa !29
  %t627 = getelementptr %"compiler/generic:Program", ptr %t625, i32 0, i32 2
  %t628 = load i32, ptr %l1, !tbaa !23
  %t631 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t627, i32 %t628)
  store i32 %t631, ptr %l328
  br label %bb146
bb146:
  %t632 = load i64, ptr %l2, !tbaa !24
  %t633 = load i32, ptr %l3, !tbaa !23
  %t634 = load ptr, ptr %l324, !tbaa !29
  %t635 = load i32, ptr %l328, !tbaa !23
  %t638 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2esubstList(ptr %v0, ptr %t634, i32 %t635, i64 %t632, i32 %t633)
  store i32 %t638, ptr %l331
  br label %bb147
bb147:
  %t639 = load ptr, ptr %l323, !tbaa !29
  %t640 = load i32, ptr %l331, !tbaa !23
  %t641 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eTuple(ptr %v0, ptr %t639, i32 %t640)
  store i32 %t641, ptr %l332
  br label %bb148
bb148:
  %t642 = load i32, ptr %l332, !tbaa !23
  store i32 %t642, ptr %rv
  br label %ret
bb149:
  %t643 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t645 = trunc i64 23 to i32
  %t646 = icmp eq i32 %t643, %t645
  br i1 %t646, label %bb150, label %bb151
bb150:
  br label %bb152
bb151:
  br label %bb156
bb152:
  %t648 = load ptr, ptr %l0, !tbaa !29
  %t650 = getelementptr %"compiler/generic:Program", ptr %t648, i32 0, i32 2
  store ptr %t650, ptr %l336, !tbaa !29
  %t651 = load ptr, ptr %l0, !tbaa !29
  store ptr %t651, ptr %l337, !tbaa !29
  %t652 = load ptr, ptr %l0, !tbaa !29
  %t654 = getelementptr %"compiler/generic:Program", ptr %t652, i32 0, i32 2
  %t655 = load i32, ptr %l1, !tbaa !23
  %t658 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t654, i32 %t655)
  store i32 %t658, ptr %l341
  br label %bb153
bb153:
  %t659 = load i64, ptr %l2, !tbaa !24
  %t660 = load i32, ptr %l3, !tbaa !23
  %t661 = load ptr, ptr %l337, !tbaa !29
  %t662 = load i32, ptr %l341, !tbaa !23
  %t665 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2esubstList(ptr %v0, ptr %t661, i32 %t662, i64 %t659, i32 %t660)
  store i32 %t665, ptr %l344
  br label %bb154
bb154:
  %t666 = load ptr, ptr %l336, !tbaa !29
  %t667 = load i32, ptr %l344, !tbaa !23
  %t668 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRecord(ptr %v0, ptr %t666, i32 %t667)
  store i32 %t668, ptr %l345
  br label %bb155
bb155:
  %t669 = load i32, ptr %l345, !tbaa !23
  store i32 %t669, ptr %rv
  br label %ret
bb156:
  %t670 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t672 = trunc i64 24 to i32
  %t673 = icmp eq i32 %t670, %t672
  br i1 %t673, label %bb157, label %bb158
bb157:
  br label %bb159
bb158:
  br label %bb165
bb159:
  %t675 = load ptr, ptr %l0, !tbaa !29
  %t677 = getelementptr %"compiler/generic:Program", ptr %t675, i32 0, i32 2
  store ptr %t677, ptr %l349, !tbaa !29
  %t678 = load ptr, ptr %l0, !tbaa !29
  %t680 = getelementptr %"compiler/generic:Program", ptr %t678, i32 0, i32 2
  %t681 = load i32, ptr %l1, !tbaa !23
  %t684 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeNames(ptr %v0, ptr %v0, ptr %t680, i32 %t681)
  store { i64, ptr } %t684, ptr %l353
  br label %bb160
bb160:
  %t685 = load ptr, ptr %l0, !tbaa !29
  store ptr %t685, ptr %l354, !tbaa !29
  %t686 = load ptr, ptr %l0, !tbaa !29
  %t688 = getelementptr %"compiler/generic:Program", ptr %t686, i32 0, i32 2
  %t689 = load i32, ptr %l1, !tbaa !23
  %t692 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeCases(ptr %v0, ptr %t688, i32 %t689)
  store i32 %t692, ptr %l358
  br label %bb161
bb161:
  %t693 = load i64, ptr %l2, !tbaa !24
  %t694 = load i32, ptr %l3, !tbaa !23
  %t695 = load ptr, ptr %l354, !tbaa !29
  %t696 = load i32, ptr %l358, !tbaa !23
  %t699 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2esubstList(ptr %v0, ptr %t695, i32 %t696, i64 %t693, i32 %t694)
  store i32 %t699, ptr %l361
  br label %bb162
bb162:
  %t700 = load ptr, ptr %l0, !tbaa !29
  %t702 = getelementptr %"compiler/generic:Program", ptr %t700, i32 0, i32 2
  %t703 = load i32, ptr %l1, !tbaa !23
  %t706 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeFields(ptr %v0, ptr %v0, ptr %t702, i32 %t703)
  store { i64, ptr } %t706, ptr %l365
  br label %bb163
bb163:
  %t707 = load ptr, ptr %l349, !tbaa !29
  %t708 = load { i64, ptr }, ptr %l353, !tbaa !27
  %t709 = load i32, ptr %l361, !tbaa !23
  %t710 = load { i64, ptr }, ptr %l365, !tbaa !27
  %t711 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAnonEnum(ptr %v0, ptr %v0, ptr %v0, ptr %t707, { i64, ptr } %t708, i32 %t709, { i64, ptr } %t710)
  store i32 %t711, ptr %l366
  br label %bb164
bb164:
  %t712 = load i32, ptr %l366, !tbaa !23
  store i32 %t712, ptr %rv
  br label %ret
bb165:
  %t713 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t715 = trunc i64 29 to i32
  %t716 = icmp eq i32 %t713, %t715
  br i1 %t716, label %bb166, label %bb167
bb166:
  br label %bb168
bb167:
  br label %bb172
bb168:
  %t718 = load ptr, ptr %l0, !tbaa !29
  %t720 = getelementptr %"compiler/generic:Program", ptr %t718, i32 0, i32 2
  store ptr %t720, ptr %l370, !tbaa !29
  %t721 = load ptr, ptr %l0, !tbaa !29
  store ptr %t721, ptr %l371, !tbaa !29
  %t722 = load ptr, ptr %l0, !tbaa !29
  %t724 = getelementptr %"compiler/generic:Program", ptr %t722, i32 0, i32 2
  %t725 = load i32, ptr %l1, !tbaa !23
  %t728 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAnyTrait(ptr %v0, ptr %t724, i32 %t725)
  store i32 %t728, ptr %l375
  br label %bb169
bb169:
  %t729 = load i64, ptr %l2, !tbaa !24
  %t730 = load i32, ptr %l3, !tbaa !23
  %t731 = load ptr, ptr %l371, !tbaa !29
  %t732 = load i32, ptr %l375, !tbaa !23
  %t735 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSubst(ptr %v0, ptr %t731, i32 %t732, i64 %t729, i32 %t730)
  store i32 %t735, ptr %l378
  br label %bb170
bb170:
  %t736 = load ptr, ptr %l370, !tbaa !29
  %t737 = load i32, ptr %l378, !tbaa !23
  %t738 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAny(ptr %v0, ptr %t736, i32 %t737)
  store i32 %t738, ptr %l379
  br label %bb171
bb171:
  %t739 = load i32, ptr %l379, !tbaa !23
  store i32 %t739, ptr %rv
  br label %ret
bb172:
  br i1 true, label %bb173, label %bb174
bb173:
  br label %bb175
bb174:
  br label %bb176
bb175:
  %t740 = load i32, ptr %l1, !tbaa !23
  store i32 %t740, ptr %rv
  br label %ret
bb176:
  call void @__olang_check_failed(ptr @olang_loc_55e2d1aec6f2d594_eb547a8d425546e0)
  unreachable
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSynthGlobal(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2, ptr %a3) #0 {
entry:
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i64
  %l7 = alloca i32
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l14 = alloca %"compiler/source:Span"
  %l17 = alloca { i64, ptr }
  %l18 = alloca ptr
  %l22 = alloca %"compiler/ast:VarDecl"
  %l25 = alloca ptr
  %l29 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %s0 = alloca %olang.scope
  %t17 = alloca i64
  %t45 = alloca i64
  %t63 = alloca i64
  store i32 %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call ptr @__olang_scope_hold(ptr %v0)
  %t2 = ptrtoint ptr %t1 to i64
  store i64 %t2, ptr %l5, !tbaa !24
  %t3 = load i1, ptr @olang_2esole_2ecompiler_2fast_3aVarDecl_2e0
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call ptr @__olang_region_make(ptr %v0)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  %t7 = load i32, ptr %l2, !tbaa !23
  store i32 %t7, ptr %l7, !tbaa !23
  %t8 = icmp sge i64 1, 0
  br i1 %t8, label %bb3, label %bb4
bb3:
  %t10 = icmp sle i64 1, 2305843009213693951
  br i1 %t10, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_c20939017dfa028a_da62df5ce2abe84e)
  unreachable
bb5:
  %t12 = mul i64 1, 4
  %t13 = load i64, ptr %l5
  %t14 = inttoptr i64 %t13 to ptr
  %t15 = call ptr @__olang_held_alloc(ptr %t14, i64 %t12)
  %t16 = load i32, ptr %l7, !tbaa !23
  store i64 0, ptr %t17
  br label %fill.18
fill.18:
  %t21 = load i64, ptr %t17
  %t22 = icmp slt i64 %t21, 1
  br i1 %t22, label %fillb.19, label %filld.20
fillb.19:
  %t23 = getelementptr i32, ptr %t15, i64 %t21
  store i32 %t16, ptr %t23
  %t24 = add i64 %t21, 1
  store i64 %t24, ptr %t17
  br label %fill.18
filld.20:
  %t25 = insertvalue { i64, ptr } undef, i64 1, 0
  %t26 = insertvalue { i64, ptr } %t25, ptr %t15, 1
  store { i64, ptr } %t26, ptr %l10, !tbaa !27
  %t27 = call ptr @__olang_scope_hold(ptr %v0)
  %t28 = ptrtoint ptr %t27 to i64
  store i64 %t28, ptr %l11, !tbaa !24
  %t29 = load i1, ptr @olang_2esole_2ecompiler_2fast_3aVarDecl_2e1
  br i1 %t29, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_c20939017dfa028a_da62df5ce2abe84e)
  unreachable
bb7:
  %t31 = call ptr @__olang_region_make(ptr %v0)
  %t32 = ptrtoint ptr %t31 to i64
  store i64 %t32, ptr %l11, !tbaa !24
  br label %bb8
bb8:
  %t33 = load ptr, ptr %l3, !tbaa !29
  %t35 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t33)
  store %"compiler/source:Span" %t35, ptr %l14
  br label %bb9
bb9:
  %t36 = icmp sge i64 1, 0
  br i1 %t36, label %bb10, label %bb11
bb10:
  %t38 = icmp sle i64 1, 1152921504606846975
  br i1 %t38, label %bb12, label %bb13
bb11:
  call void @__olang_check_failed(ptr @olang_loc_c20939017dfa028a_da62df5ce2abe84e)
  unreachable
bb12:
  %t40 = mul i64 1, 8
  %t41 = load i64, ptr %l11
  %t42 = inttoptr i64 %t41 to ptr
  %t43 = call ptr @__olang_held_alloc(ptr %t42, i64 %t40)
  %t44 = load %"compiler/source:Span", ptr %l14
  store i64 0, ptr %t45
  br label %fill.46
fill.46:
  %t49 = load i64, ptr %t45
  %t50 = icmp slt i64 %t49, 1
  br i1 %t50, label %fillb.47, label %filld.48
fillb.47:
  %t51 = getelementptr %"compiler/source:Span", ptr %t43, i64 %t49
  store %"compiler/source:Span" %t44, ptr %t51
  %t52 = add i64 %t49, 1
  store i64 %t52, ptr %t45
  br label %fill.46
filld.48:
  %t53 = insertvalue { i64, ptr } undef, i64 1, 0
  %t54 = insertvalue { i64, ptr } %t53, ptr %t43, 1
  store { i64, ptr } %t54, ptr %l17, !tbaa !27
  %t55 = load ptr, ptr %l3, !tbaa !29
  store ptr %t55, ptr %l18, !tbaa !29
  %t56 = icmp sge i64 1, 0
  br i1 %t56, label %bb14, label %bb15
bb13:
  call void @__olang_check_failed(ptr @olang_loc_c20939017dfa028a_da62df5ce2abe84e)
  unreachable
bb14:
  %t58 = icmp sle i64 1, 1152921504606846975
  br i1 %t58, label %bb16, label %bb17
bb15:
  call void @__olang_check_failed(ptr @olang_loc_c20939017dfa028a_da62df5ce2abe84e)
  unreachable
bb16:
  %t60 = mul i64 1, 8
  %t61 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t60)
  %t62 = load ptr, ptr %l18, !tbaa !29
  store i64 0, ptr %t63
  br label %fill.64
fill.64:
  %t67 = load i64, ptr %t63
  %t68 = icmp slt i64 %t67, 1
  br i1 %t68, label %fillb.65, label %filld.66
fillb.65:
  %t69 = getelementptr ptr, ptr %t61, i64 %t67
  store ptr %t62, ptr %t69
  %t70 = add i64 %t67, 1
  store i64 %t70, ptr %t63
  br label %fill.64
filld.66:
  %t71 = insertvalue { i64, ptr } undef, i64 1, 0
  %t72 = insertvalue { i64, ptr } %t71, ptr %t61, 1
  %t73 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t74 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t76 = call %"compiler/ast:VarDecl" @compiler_2fast_3aVarDecl_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, { i64, ptr } %t73, { i64, ptr } %t74, ptr null, { i64, ptr } %t72, i1 true, i1 false, i1 false)
  store %"compiler/ast:VarDecl" %t76, ptr %l22
  br label %bb18
bb17:
  call void @__olang_check_failed(ptr @olang_loc_c20939017dfa028a_da62df5ce2abe84e)
  unreachable
bb18:
  %t77 = load %"compiler/ast:VarDecl", ptr %l22
  %t78 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 64, i64 8)
  store %"compiler/ast:VarDecl" %t77, ptr %t78
  store ptr %t78, ptr %l4, !tbaa !29
  %t82 = getelementptr %"compiler/generic:Program", ptr %a0, i32 0, i32 68
  store ptr %t82, ptr %l25, !tbaa !29
  %t84 = load i32, ptr %l2, !tbaa !23
  %t86 = sext i32 %t84 to i64
  %t89 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s0, i64 %a1, i64 %t86)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t89, ptr %l29
  br label %bb19
bb19:
  %t90 = load ptr, ptr %l4, !tbaa !29
  %t91 = load ptr, ptr %l25, !tbaa !29
  %t92 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l29
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H6466f280e8b3243621b03e95613f722a(ptr %v0, ptr %v0, ptr %t91, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t92, ptr %t90)
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeBuilders(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca %"compiler/generic:fnRow"
  %l13 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l16 = alloca i64
  %l20 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l22 = alloca i64
  %l23 = alloca { i64, ptr }
  %l26 = alloca i64
  %l30 = alloca i64
  %l33 = alloca i64
  %l54 = alloca %"compiler/generic:fnRow"
  %l56 = alloca i1
  %l58 = alloca i1
  %l60 = alloca i1
  %l71 = alloca i64
  %l74 = alloca i1
  %l78 = alloca i1
  %l83 = alloca i1
  %l87 = alloca { i64, ptr }
  %l88 = alloca { i64, ptr }
  %l90 = alloca i1
  %l98 = alloca { i64, ptr }
  %l99 = alloca { i64, ptr }
  %l100 = alloca i64
  %l101 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eallFns(ptr %v0, ptr %t1)
  br label %bb1
bb1:
  %t3 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %l13
  br label %bb2
bb2:
  %t4 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l13
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t4, ptr %l3
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t6 = load i32, ptr %l1, !tbaa !23
  %t9 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2etypeKey(ptr %v0, ptr %t5, i32 %t6)
  store i64 %t9, ptr %l16
  br label %bb3
bb3:
  %t10 = load i64, ptr %l16, !tbaa !24
  store i64 %t10, ptr %l4, !tbaa !24
  %t11 = load i64, ptr %l4, !tbaa !24
  %t13 = icmp slt i64 %t11, 0
  br i1 %t13, label %bb4, label %bb5
bb4:
  store %olang.scope zeroinitializer, ptr %s1
  %t16 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eToArray_3cI64_3e(ptr %s0, ptr %s1, ptr %l3)
  store { i64, ptr } %t16, ptr %l20
  br label %bb6
bb5:
  br label %bb7
bb6:
  %t17 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t17, ptr %l21, !tbaa !27
  %t18 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t19 = extractvalue { i64, ptr } %t18, 0
  store i64 %t19, ptr %l22, !tbaa !24
  %t20 = load i64, ptr %l22, !tbaa !24
  %t21 = mul i64 %t20, 8
  %t22 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t21)
  %t23 = insertvalue { i64, ptr } undef, i64 %t20, 0
  %t24 = insertvalue { i64, ptr } %t23, ptr %t22, 1
  store { i64, ptr } %t24, ptr %l23, !tbaa !27
  %t25 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !27
  %t29 = load i64, ptr %l22, !tbaa !24
  %t30 = mul i64 %t29, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t26, ptr %t28, i64 %t30, i1 false)
  %t31 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t31, ptr %l21, !tbaa !27
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t32 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t32, ptr %rv
  br label %ret
bb7:
  store i64 0, ptr %l5, !tbaa !24
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/generic:Program", ptr %t33, i32 0, i32 31
  %t37 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3afnRow_3e_2eLen_3ccompiler_2fgeneric_3afnRow_3e(ptr %v0, ptr %t35)
  store i64 %t37, ptr %l26
  br label %bb8
bb8:
  %t38 = load i64, ptr %l26, !tbaa !24
  store i64 %t38, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t39 = load i64, ptr %l6, !tbaa !24
  %t40 = load i64, ptr %l5, !tbaa !24
  %t43 = icmp sgt i64 %t39, %t40
  br i1 %t43, label %bb9, label %bb10
bb9:
  %t45 = load i64, ptr %l7, !tbaa !24
  %t47 = icmp sgt i64 %t45, 0
  br i1 %t47, label %bb11, label %bb12
bb10:
  store i64 0, ptr %l30, !tbaa !24
  br label %bb14
bb11:
  %t49 = load i64, ptr %l6, !tbaa !24
  %t50 = load i64, ptr %l5, !tbaa !24
  %t53 = sub i64 %t49, %t50
  %t54 = load i64, ptr %l7, !tbaa !24
  %t57 = add i64 %t53, %t54
  %t59 = sub i64 %t57, 1
  %t60 = load i64, ptr %l7, !tbaa !24
  %t63 = sdiv i64 %t59, %t60
  store i64 %t63, ptr %l33, !tbaa !24
  br label %bb13
bb12:
  store i64 0, ptr %l33, !tbaa !24
  br label %bb13
bb13:
  %t65 = load i64, ptr %l33, !tbaa !24
  store i64 %t65, ptr %l30, !tbaa !24
  br label %bb14
bb14:
  %t66 = load i64, ptr %l30, !tbaa !24
  store i64 %t66, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb15
bb15:
  store %olang.scope zeroinitializer, ptr %s3
  %t67 = load i64, ptr %l9, !tbaa !24
  %t68 = load i64, ptr %l8, !tbaa !24
  %t71 = icmp slt i64 %t67, %t68
  %t73 = xor i1 %t71, true
  br i1 %t73, label %bb16, label %bb17
bb16:
  call void @__olang_scope_close(ptr %s3)
  br label %bb48
bb17:
  br label %bb18
bb18:
  %t75 = load i64, ptr %l5, !tbaa !24
  %t76 = load i64, ptr %l9, !tbaa !24
  %t77 = load i64, ptr %l7, !tbaa !24
  %t80 = mul i64 %t76, %t77
  %t83 = add i64 %t75, %t80
  store i64 %t83, ptr %l10, !tbaa !24
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"compiler/generic:Program", ptr %t85, i32 0, i32 31
  %t88 = load i64, ptr %l10, !tbaa !24
  %t91 = call %"compiler/generic:fnRow" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3afnRow_3e_2eAt_3ccompiler_2fgeneric_3afnRow_3e(ptr %v0, ptr %v0, ptr %t87, i64 %t88)
  store %"compiler/generic:fnRow" %t91, ptr %l54
  br label %bb19
bb19:
  %t92 = load %"compiler/generic:fnRow", ptr %l54
  store %"compiler/generic:fnRow" %t92, ptr %l11
  %t93 = getelementptr %"compiler/generic:fnRow", ptr %l11, i32 0, i32 1
  %t94 = load ptr, ptr %t93, !tbaa !29
  %t96 = call i1 @compiler_2fast_2ecompiler_2fast_3aFunc_2eIsBuilder(ptr %v0, ptr %t94)
  store i1 %t96, ptr %l56
  br label %bb20
bb20:
  %t97 = load i1, ptr %l56, !tbaa !21
  %t98 = xor i1 %t97, true
  br i1 %t98, label %bb21, label %bb22
bb21:
  store i1 true, ptr %l58, !tbaa !21
  br label %bb23
bb22:
  %t100 = getelementptr %"compiler/generic:fnRow", ptr %l11, i32 0, i32 2
  %t101 = load i1, ptr %t100, !tbaa !21
  store i1 %t101, ptr %l58, !tbaa !21
  br label %bb23
bb23:
  %t103 = load i1, ptr %l58, !tbaa !21
  br i1 %t103, label %bb24, label %bb25
bb24:
  store i1 true, ptr %l60, !tbaa !21
  br label %bb26
bb25:
  %t104 = getelementptr %"compiler/generic:fnRow", ptr %l11, i32 0, i32 1
  %t105 = load ptr, ptr %t104, !tbaa !29
  %t107 = getelementptr %"compiler/ast:Func", ptr %t105, i32 0, i32 5
  %t108 = load { i64, ptr }, ptr %t107, !tbaa !27
  %t110 = extractvalue { i64, ptr } %t108, 0
  %t112 = icmp sgt i64 %t110, 0
  store i1 %t112, ptr %l60, !tbaa !21
  br label %bb26
bb26:
  %t114 = load i1, ptr %l60, !tbaa !21
  br i1 %t114, label %bb27, label %bb28
bb27:
  call void @__olang_scope_close(ptr %s3)
  br label %bb47
bb28:
  br label %bb29
bb29:
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t116 = getelementptr %"compiler/generic:fnRow", ptr %l11, i32 0, i32 0
  %t117 = load i64, ptr %t116, !tbaa !24
  %t118 = getelementptr %"compiler/generic:fnRow", ptr %l11, i32 0, i32 1
  %t119 = load ptr, ptr %t118, !tbaa !29
  %t121 = getelementptr %"compiler/ast:Func", ptr %t119, i32 0, i32 8
  %t122 = load ptr, ptr %t121, !tbaa !29
  %t123 = getelementptr %"compiler/generic:fnRow", ptr %l11, i32 0, i32 1
  %t124 = load ptr, ptr %t123, !tbaa !29
  %t126 = getelementptr %"compiler/ast:Func", ptr %t124, i32 0, i32 5
  %t127 = load { i64, ptr }, ptr %t126, !tbaa !27
  %t132 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2erecvKey(ptr %v0, ptr %v0, ptr %v0, ptr %t115, i64 %t117, ptr %t122, { i64, ptr } %t127)
  store i64 %t132, ptr %l71
  br label %bb30
bb30:
  %t133 = load i64, ptr %l4, !tbaa !24
  %t134 = load i64, ptr %l71, !tbaa !24
  %t136 = icmp ne i64 %t134, %t133
  br i1 %t136, label %bb31, label %bb32
bb31:
  store i1 true, ptr %l74, !tbaa !21
  br label %bb34
bb32:
  %t138 = load ptr, ptr %l0, !tbaa !29
  %t139 = load i64, ptr %l10, !tbaa !24
  %t140 = load i32, ptr %l1, !tbaa !23
  %t144 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eownerApplies(ptr %v0, ptr %t138, i64 %t139, i32 %t140)
  store i1 %t144, ptr %l78
  br label %bb33
bb33:
  %t145 = load i1, ptr %l78, !tbaa !21
  %t146 = xor i1 %t145, true
  store i1 %t146, ptr %l74, !tbaa !21
  br label %bb34
bb34:
  %t148 = load i1, ptr %l74, !tbaa !21
  br i1 %t148, label %bb35, label %bb36
bb35:
  call void @__olang_scope_close(ptr %s3)
  br label %bb47
bb36:
  br label %bb37
bb37:
  %t149 = getelementptr %"compiler/generic:fnRow", ptr %l11, i32 0, i32 0
  %t150 = load i64, ptr %t149, !tbaa !24
  %t154 = icmp ne i64 %t150, %a2
  br i1 %t154, label %bb38, label %bb39
bb38:
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t157 = getelementptr %"compiler/generic:fnRow", ptr %l11, i32 0, i32 1
  %t158 = load ptr, ptr %t157, !tbaa !29
  %t160 = getelementptr %"compiler/ast:Func", ptr %t158, i32 0, i32 9
  %t161 = load i32, ptr %t160, !tbaa !23
  %t164 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2etext(ptr %v0, ptr %s3, ptr %t156, i32 %t161)
  store { i64, ptr } %t164, ptr %l87
  br label %bb40
bb39:
  store i1 false, ptr %l83, !tbaa !21
  br label %bb42
bb40:
  %t165 = load { i64, ptr }, ptr %l87, !tbaa !27
  store { i64, ptr } %t165, ptr %l88, !tbaa !27
  %t166 = getelementptr { i64, ptr }, ptr %l88, i32 0, i32 1
  %t167 = load ptr, ptr %t166, !tbaa !27
  %t168 = getelementptr i8, ptr %t167, i64 0
  %t169 = load i8, ptr %t168, !tbaa !32
  %t171 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsUpper(i8 %t169)
  store i1 %t171, ptr %l90
  br label %bb41
bb41:
  %t172 = load i1, ptr %l90, !tbaa !21
  %t173 = xor i1 %t172, true
  store i1 %t173, ptr %l83, !tbaa !21
  br label %bb42
bb42:
  %t175 = load i1, ptr %l83, !tbaa !21
  br i1 %t175, label %bb43, label %bb44
bb43:
  call void @__olang_scope_close(ptr %s3)
  br label %bb47
bb44:
  br label %bb45
bb45:
  %t176 = load i64, ptr %l10, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l3, i64 %t176)
  br label %bb46
bb46:
  call void @__olang_scope_close(ptr %s3)
  br label %bb47
bb47:
  %t179 = load i64, ptr %l9, !tbaa !24
  %t182 = add i64 %t179, 1
  store i64 %t182, ptr %l9, !tbaa !24
  br label %bb15
bb48:
  %t185 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eToArray_3cI64_3e(ptr %s0, ptr %s0, ptr %l3)
  store { i64, ptr } %t185, ptr %l98
  br label %bb49
bb49:
  %t186 = load { i64, ptr }, ptr %l98, !tbaa !27
  store { i64, ptr } %t186, ptr %l99, !tbaa !27
  %t187 = load { i64, ptr }, ptr %l99, !tbaa !27
  %t188 = extractvalue { i64, ptr } %t187, 0
  store i64 %t188, ptr %l100, !tbaa !24
  %t189 = load i64, ptr %l100, !tbaa !24
  %t190 = mul i64 %t189, 8
  %t191 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t190)
  %t192 = insertvalue { i64, ptr } undef, i64 %t189, 0
  %t193 = insertvalue { i64, ptr } %t192, ptr %t191, 1
  store { i64, ptr } %t193, ptr %l101, !tbaa !27
  %t194 = getelementptr { i64, ptr }, ptr %l101, i32 0, i32 1
  %t195 = load ptr, ptr %t194, !tbaa !27
  %t196 = getelementptr { i64, ptr }, ptr %l99, i32 0, i32 1
  %t197 = load ptr, ptr %t196, !tbaa !27
  %t198 = load i64, ptr %l100, !tbaa !24
  %t199 = mul i64 %t198, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t195, ptr %t197, i64 %t199, i1 false)
  %t200 = load { i64, ptr }, ptr %l101, !tbaa !27
  store { i64, ptr } %t200, ptr %l99, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t201 = load { i64, ptr }, ptr %l99, !tbaa !27
  store { i64, ptr } %t201, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeMethods(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca %"compiler/generic:fnRow"
  %l13 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l16 = alloca i64
  %l20 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l22 = alloca i64
  %l23 = alloca { i64, ptr }
  %l26 = alloca i64
  %l30 = alloca i64
  %l33 = alloca i64
  %l54 = alloca %"compiler/generic:fnRow"
  %l58 = alloca i1
  %l60 = alloca i1
  %l65 = alloca ptr
  %l66 = alloca i64
  %l76 = alloca i64
  %l79 = alloca i1
  %l83 = alloca i1
  %l88 = alloca i1
  %l92 = alloca { i64, ptr }
  %l93 = alloca { i64, ptr }
  %l95 = alloca i1
  %l103 = alloca { i64, ptr }
  %l104 = alloca { i64, ptr }
  %l105 = alloca i64
  %l106 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eallFns(ptr %v0, ptr %t1)
  br label %bb1
bb1:
  %t3 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %l13
  br label %bb2
bb2:
  %t4 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l13
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t4, ptr %l3
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t6 = load i32, ptr %l1, !tbaa !23
  %t9 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2etypeKey(ptr %v0, ptr %t5, i32 %t6)
  store i64 %t9, ptr %l16
  br label %bb3
bb3:
  %t10 = load i64, ptr %l16, !tbaa !24
  store i64 %t10, ptr %l4, !tbaa !24
  %t11 = load i64, ptr %l4, !tbaa !24
  %t13 = icmp slt i64 %t11, 0
  br i1 %t13, label %bb4, label %bb5
bb4:
  store %olang.scope zeroinitializer, ptr %s1
  %t16 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eToArray_3cI64_3e(ptr %s0, ptr %s1, ptr %l3)
  store { i64, ptr } %t16, ptr %l20
  br label %bb6
bb5:
  br label %bb7
bb6:
  %t17 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t17, ptr %l21, !tbaa !27
  %t18 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t19 = extractvalue { i64, ptr } %t18, 0
  store i64 %t19, ptr %l22, !tbaa !24
  %t20 = load i64, ptr %l22, !tbaa !24
  %t21 = mul i64 %t20, 8
  %t22 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t21)
  %t23 = insertvalue { i64, ptr } undef, i64 %t20, 0
  %t24 = insertvalue { i64, ptr } %t23, ptr %t22, 1
  store { i64, ptr } %t24, ptr %l23, !tbaa !27
  %t25 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !27
  %t29 = load i64, ptr %l22, !tbaa !24
  %t30 = mul i64 %t29, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t26, ptr %t28, i64 %t30, i1 false)
  %t31 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t31, ptr %l21, !tbaa !27
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t32 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t32, ptr %rv
  br label %ret
bb7:
  store i64 0, ptr %l5, !tbaa !24
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/generic:Program", ptr %t33, i32 0, i32 31
  %t37 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3afnRow_3e_2eLen_3ccompiler_2fgeneric_3afnRow_3e(ptr %v0, ptr %t35)
  store i64 %t37, ptr %l26
  br label %bb8
bb8:
  %t38 = load i64, ptr %l26, !tbaa !24
  store i64 %t38, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t39 = load i64, ptr %l6, !tbaa !24
  %t40 = load i64, ptr %l5, !tbaa !24
  %t43 = icmp sgt i64 %t39, %t40
  br i1 %t43, label %bb9, label %bb10
bb9:
  %t45 = load i64, ptr %l7, !tbaa !24
  %t47 = icmp sgt i64 %t45, 0
  br i1 %t47, label %bb11, label %bb12
bb10:
  store i64 0, ptr %l30, !tbaa !24
  br label %bb14
bb11:
  %t49 = load i64, ptr %l6, !tbaa !24
  %t50 = load i64, ptr %l5, !tbaa !24
  %t53 = sub i64 %t49, %t50
  %t54 = load i64, ptr %l7, !tbaa !24
  %t57 = add i64 %t53, %t54
  %t59 = sub i64 %t57, 1
  %t60 = load i64, ptr %l7, !tbaa !24
  %t63 = sdiv i64 %t59, %t60
  store i64 %t63, ptr %l33, !tbaa !24
  br label %bb13
bb12:
  store i64 0, ptr %l33, !tbaa !24
  br label %bb13
bb13:
  %t65 = load i64, ptr %l33, !tbaa !24
  store i64 %t65, ptr %l30, !tbaa !24
  br label %bb14
bb14:
  %t66 = load i64, ptr %l30, !tbaa !24
  store i64 %t66, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb15
bb15:
  store %olang.scope zeroinitializer, ptr %s3
  %t67 = load i64, ptr %l9, !tbaa !24
  %t68 = load i64, ptr %l8, !tbaa !24
  %t71 = icmp slt i64 %t67, %t68
  %t73 = xor i1 %t71, true
  br i1 %t73, label %bb16, label %bb17
bb16:
  call void @__olang_scope_close(ptr %s3)
  br label %bb50
bb17:
  br label %bb18
bb18:
  %t75 = load i64, ptr %l5, !tbaa !24
  %t76 = load i64, ptr %l9, !tbaa !24
  %t77 = load i64, ptr %l7, !tbaa !24
  %t80 = mul i64 %t76, %t77
  %t83 = add i64 %t75, %t80
  store i64 %t83, ptr %l10, !tbaa !24
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"compiler/generic:Program", ptr %t85, i32 0, i32 31
  %t88 = load i64, ptr %l10, !tbaa !24
  %t91 = call %"compiler/generic:fnRow" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3afnRow_3e_2eAt_3ccompiler_2fgeneric_3afnRow_3e(ptr %v0, ptr %v0, ptr %t87, i64 %t88)
  store %"compiler/generic:fnRow" %t91, ptr %l54
  br label %bb19
bb19:
  %t92 = load %"compiler/generic:fnRow", ptr %l54
  store %"compiler/generic:fnRow" %t92, ptr %l11
  %t93 = getelementptr %"compiler/generic:fnRow", ptr %l11, i32 0, i32 1
  %t94 = load ptr, ptr %t93, !tbaa !29
  %t96 = getelementptr %"compiler/ast:Func", ptr %t94, i32 0, i32 1
  %t97 = load ptr, ptr %t96, !tbaa !29
  %t99 = icmp eq ptr %t97, null
  br i1 %t99, label %bb20, label %bb21
bb20:
  store i1 true, ptr %l58, !tbaa !21
  br label %bb22
bb21:
  %t101 = getelementptr %"compiler/generic:fnRow", ptr %l11, i32 0, i32 2
  %t102 = load i1, ptr %t101, !tbaa !21
  store i1 %t102, ptr %l58, !tbaa !21
  br label %bb22
bb22:
  %t104 = load i1, ptr %l58, !tbaa !21
  br i1 %t104, label %bb23, label %bb24
bb23:
  store i1 true, ptr %l60, !tbaa !21
  br label %bb25
bb24:
  %t105 = getelementptr %"compiler/generic:fnRow", ptr %l11, i32 0, i32 1
  %t106 = load ptr, ptr %t105, !tbaa !29
  %t108 = getelementptr %"compiler/ast:Func", ptr %t106, i32 0, i32 5
  %t109 = load { i64, ptr }, ptr %t108, !tbaa !27
  %t111 = extractvalue { i64, ptr } %t109, 0
  %t113 = icmp sgt i64 %t111, 0
  store i1 %t113, ptr %l60, !tbaa !21
  br label %bb25
bb25:
  %t115 = load i1, ptr %l60, !tbaa !21
  br i1 %t115, label %bb26, label %bb27
bb26:
  call void @__olang_scope_close(ptr %s3)
  br label %bb49
bb27:
  br label %bb28
bb28:
  %t116 = load ptr, ptr %l0, !tbaa !29
  store ptr %t116, ptr %l65, !tbaa !29
  %t117 = getelementptr %"compiler/generic:fnRow", ptr %l11, i32 0, i32 0
  %t118 = load i64, ptr %t117, !tbaa !24
  store i64 %t118, ptr %l66, !tbaa !24
  %t119 = getelementptr %"compiler/generic:fnRow", ptr %l11, i32 0, i32 1
  %t120 = load ptr, ptr %t119, !tbaa !29
  %t122 = getelementptr %"compiler/ast:Func", ptr %t120, i32 0, i32 1
  %t123 = load ptr, ptr %t122, !tbaa !29
  %t125 = icmp eq ptr %t123, null
  br i1 %t125, label %bb29, label %bb30
bb29:
  call void @__olang_check_failed(ptr @olang_loc_8878e002d59779fd_75c347076df58361)
  unreachable
bb30:
  br label %bb31
bb31:
  %t127 = getelementptr %"compiler/generic:fnRow", ptr %l11, i32 0, i32 1
  %t128 = load ptr, ptr %t127, !tbaa !29
  %t130 = getelementptr %"compiler/ast:Func", ptr %t128, i32 0, i32 1
  %t131 = load ptr, ptr %t130, !tbaa !29
  %t134 = getelementptr %"compiler/ast:Param", ptr %t131, i32 0, i32 2
  %t135 = load ptr, ptr %t134, !tbaa !29
  %t136 = getelementptr %"compiler/generic:fnRow", ptr %l11, i32 0, i32 1
  %t137 = load ptr, ptr %t136, !tbaa !29
  %t139 = getelementptr %"compiler/ast:Func", ptr %t137, i32 0, i32 5
  %t140 = load { i64, ptr }, ptr %t139, !tbaa !27
  %t141 = load ptr, ptr %l65, !tbaa !29
  %t142 = load i64, ptr %l66, !tbaa !24
  %t145 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2erecvKey(ptr %v0, ptr %v0, ptr %v0, ptr %t141, i64 %t142, ptr %t135, { i64, ptr } %t140)
  store i64 %t145, ptr %l76
  br label %bb32
bb32:
  %t146 = load i64, ptr %l4, !tbaa !24
  %t147 = load i64, ptr %l76, !tbaa !24
  %t149 = icmp ne i64 %t147, %t146
  br i1 %t149, label %bb33, label %bb34
bb33:
  store i1 true, ptr %l79, !tbaa !21
  br label %bb36
bb34:
  %t151 = load ptr, ptr %l0, !tbaa !29
  %t152 = load i64, ptr %l10, !tbaa !24
  %t153 = load i32, ptr %l1, !tbaa !23
  %t157 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2erecvApplies(ptr %v0, ptr %t151, i64 %t152, i32 %t153)
  store i1 %t157, ptr %l83
  br label %bb35
bb35:
  %t158 = load i1, ptr %l83, !tbaa !21
  %t159 = xor i1 %t158, true
  store i1 %t159, ptr %l79, !tbaa !21
  br label %bb36
bb36:
  %t161 = load i1, ptr %l79, !tbaa !21
  br i1 %t161, label %bb37, label %bb38
bb37:
  call void @__olang_scope_close(ptr %s3)
  br label %bb49
bb38:
  br label %bb39
bb39:
  %t162 = getelementptr %"compiler/generic:fnRow", ptr %l11, i32 0, i32 0
  %t163 = load i64, ptr %t162, !tbaa !24
  %t167 = icmp ne i64 %t163, %a2
  br i1 %t167, label %bb40, label %bb41
bb40:
  %t169 = load ptr, ptr %l0, !tbaa !29
  %t170 = getelementptr %"compiler/generic:fnRow", ptr %l11, i32 0, i32 1
  %t171 = load ptr, ptr %t170, !tbaa !29
  %t173 = getelementptr %"compiler/ast:Func", ptr %t171, i32 0, i32 2
  %t174 = load i32, ptr %t173, !tbaa !23
  %t177 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2etext(ptr %v0, ptr %s3, ptr %t169, i32 %t174)
  store { i64, ptr } %t177, ptr %l92
  br label %bb42
bb41:
  store i1 false, ptr %l88, !tbaa !21
  br label %bb44
bb42:
  %t178 = load { i64, ptr }, ptr %l92, !tbaa !27
  store { i64, ptr } %t178, ptr %l93, !tbaa !27
  %t179 = getelementptr { i64, ptr }, ptr %l93, i32 0, i32 1
  %t180 = load ptr, ptr %t179, !tbaa !27
  %t181 = getelementptr i8, ptr %t180, i64 0
  %t182 = load i8, ptr %t181, !tbaa !32
  %t184 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsUpper(i8 %t182)
  store i1 %t184, ptr %l95
  br label %bb43
bb43:
  %t185 = load i1, ptr %l95, !tbaa !21
  %t186 = xor i1 %t185, true
  store i1 %t186, ptr %l88, !tbaa !21
  br label %bb44
bb44:
  %t188 = load i1, ptr %l88, !tbaa !21
  br i1 %t188, label %bb45, label %bb46
bb45:
  call void @__olang_scope_close(ptr %s3)
  br label %bb49
bb46:
  br label %bb47
bb47:
  %t189 = load i64, ptr %l10, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l3, i64 %t189)
  br label %bb48
bb48:
  call void @__olang_scope_close(ptr %s3)
  br label %bb49
bb49:
  %t192 = load i64, ptr %l9, !tbaa !24
  %t195 = add i64 %t192, 1
  store i64 %t195, ptr %l9, !tbaa !24
  br label %bb15
bb50:
  %t198 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eToArray_3cI64_3e(ptr %s0, ptr %s0, ptr %l3)
  store { i64, ptr } %t198, ptr %l103
  br label %bb51
bb51:
  %t199 = load { i64, ptr }, ptr %l103, !tbaa !27
  store { i64, ptr } %t199, ptr %l104, !tbaa !27
  %t200 = load { i64, ptr }, ptr %l104, !tbaa !27
  %t201 = extractvalue { i64, ptr } %t200, 0
  store i64 %t201, ptr %l105, !tbaa !24
  %t202 = load i64, ptr %l105, !tbaa !24
  %t203 = mul i64 %t202, 8
  %t204 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t203)
  %t205 = insertvalue { i64, ptr } undef, i64 %t202, 0
  %t206 = insertvalue { i64, ptr } %t205, ptr %t204, 1
  store { i64, ptr } %t206, ptr %l106, !tbaa !27
  %t207 = getelementptr { i64, ptr }, ptr %l106, i32 0, i32 1
  %t208 = load ptr, ptr %t207, !tbaa !27
  %t209 = getelementptr { i64, ptr }, ptr %l104, i32 0, i32 1
  %t210 = load ptr, ptr %t209, !tbaa !27
  %t211 = load i64, ptr %l105, !tbaa !24
  %t212 = mul i64 %t211, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t208, ptr %t210, i64 %t212, i1 false)
  %t213 = load { i64, ptr }, ptr %l106, !tbaa !27
  store { i64, ptr } %t213, ptr %l104, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t214 = load { i64, ptr }, ptr %l104, !tbaa !27
  store { i64, ptr } %t214, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eWithReceiver(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l29 = alloca ptr
  %l33 = alloca i32
  %l34 = alloca { i64, ptr }
  %l37 = alloca i64
  %l47 = alloca i64
  %l50 = alloca i64
  %l59 = alloca i64
  %l62 = alloca i1
  %l74 = alloca { i64, ptr }
  %l82 = alloca i64
  %l83 = alloca i64
  %l92 = alloca i64
  %l95 = alloca i64
  %l117 = alloca i64
  %l119 = alloca i64
  %l122 = alloca i64
  %l132 = alloca { i64, ptr }
  %l134 = alloca i64
  %l135 = alloca i64
  %l144 = alloca i64
  %l147 = alloca i64
  %l169 = alloca i64
  %l170 = alloca i64
  %l173 = alloca i64
  %l181 = alloca ptr
  %l185 = alloca i32
  %l189 = alloca i32
  %l193 = alloca i32
  %l195 = alloca ptr
  %l199 = alloca i64
  %l202 = alloca i32
  %l203 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  %t132 = alloca i64
  %t248 = alloca i64
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/generic:Program", ptr %t1, i32 0, i32 2
  store ptr %t3, ptr %l29, !tbaa !29
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t7 = load i32, ptr %l1, !tbaa !23
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t6, i32 %t7)
  store i32 %t10, ptr %l33
  br label %bb1
bb1:
  %t11 = load ptr, ptr %l29, !tbaa !29
  %t12 = load i32, ptr %l33, !tbaa !23
  %t13 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t11, i32 %t12)
  store { i64, ptr } %t13, ptr %l34
  br label %bb2
bb2:
  %t14 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t14, ptr %l3, !tbaa !27
  %t15 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t19 = add i64 %t17, 1
  store i64 %t19, ptr %l37, !tbaa !24
  %t20 = load i64, ptr %l37, !tbaa !24
  %t21 = icmp sge i64 %t20, 0
  br i1 %t21, label %bb3, label %bb4
bb3:
  %t23 = load i64, ptr %l37, !tbaa !24
  %t24 = icmp sle i64 %t23, 2305843009213693951
  br i1 %t24, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_b441b4212013472a_a2c9244dd812c346)
  unreachable
bb5:
  %t26 = load i64, ptr %l37, !tbaa !24
  %t27 = mul i64 %t26, 4
  %t28 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t27)
  %t29 = insertvalue { i64, ptr } undef, i64 %t26, 0
  %t30 = insertvalue { i64, ptr } %t29, ptr %t28, 1
  store { i64, ptr } %t30, ptr %l4, !tbaa !27
  %t34 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !27
  %t36 = getelementptr i32, ptr %t35, i64 0
  store i32 %a2, ptr %t36, !tbaa !33
  store i64 0, ptr %l5, !tbaa !24
  %t37 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t39 = extractvalue { i64, ptr } %t37, 0
  store i64 %t39, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t41 = load i64, ptr %l6, !tbaa !24
  %t42 = load i64, ptr %l5, !tbaa !24
  %t45 = icmp sgt i64 %t41, %t42
  br i1 %t45, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_b441b4212013472a_a2c9244dd812c346)
  unreachable
bb7:
  %t47 = load i64, ptr %l7, !tbaa !24
  %t49 = icmp sgt i64 %t47, 0
  br i1 %t49, label %bb9, label %bb10
bb8:
  store i64 0, ptr %l47, !tbaa !24
  br label %bb12
bb9:
  %t51 = load i64, ptr %l6, !tbaa !24
  %t52 = load i64, ptr %l5, !tbaa !24
  %t55 = sub i64 %t51, %t52
  %t56 = load i64, ptr %l7, !tbaa !24
  %t59 = add i64 %t55, %t56
  %t61 = sub i64 %t59, 1
  %t62 = load i64, ptr %l7, !tbaa !24
  %t65 = sdiv i64 %t61, %t62
  store i64 %t65, ptr %l50, !tbaa !24
  br label %bb11
bb10:
  store i64 0, ptr %l50, !tbaa !24
  br label %bb11
bb11:
  %t67 = load i64, ptr %l50, !tbaa !24
  store i64 %t67, ptr %l47, !tbaa !24
  br label %bb12
bb12:
  %t68 = load i64, ptr %l47, !tbaa !24
  store i64 %t68, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  %t69 = load i64, ptr %l8, !tbaa !24
  %t70 = sub i64 %t69, 1
  store i64 %t70, ptr %l59, !tbaa !24
  %t71 = load i64, ptr %l8, !tbaa !24
  %t72 = icmp slt i64 %t71, 2147483648
  %t73 = load i64, ptr %l9, !tbaa !24
  %t74 = icmp sge i64 %t73, 0
  %t77 = and i1 %t72, %t74
  store i1 %t77, ptr %l62, !tbaa !21
  br label %bb13
bb13:
  %t78 = load i64, ptr %l9, !tbaa !24
  %t79 = load i64, ptr %l8, !tbaa !24
  %t82 = icmp slt i64 %t78, %t79
  %t84 = xor i1 %t82, true
  br i1 %t84, label %bb14, label %bb15
bb14:
  br label %bb18
bb15:
  br label %bb16
bb16:
  %t86 = load i64, ptr %l5, !tbaa !24
  %t87 = load i64, ptr %l9, !tbaa !24
  %t88 = load i64, ptr %l7, !tbaa !24
  %t91 = mul i64 %t87, %t88
  %t94 = add i64 %t86, %t91
  store i64 %t94, ptr %l10, !tbaa !24
  %t96 = load i64, ptr %l10, !tbaa !24
  %t98 = add i64 %t96, 1
  %t99 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t99, ptr %l74, !tbaa !27
  %t100 = load i64, ptr %l10, !tbaa !24
  %t102 = getelementptr { i64, ptr }, ptr %l74, i32 0, i32 1
  %t103 = load ptr, ptr %t102, !tbaa !27
  %t104 = getelementptr i32, ptr %t103, i64 %t100
  %t105 = load i32, ptr %t104, !tbaa !33
  %t108 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t109 = load ptr, ptr %t108, !tbaa !27
  %t110 = getelementptr i32, ptr %t109, i64 %t98
  store i32 %t105, ptr %t110, !tbaa !33
  br label %bb17
bb17:
  %t111 = load i64, ptr %l9, !tbaa !24
  %t114 = add i64 %t111, 1
  store i64 %t114, ptr %l9, !tbaa !24
  br label %bb13
bb18:
  %t116 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t118 = extractvalue { i64, ptr } %t116, 0
  %t120 = add i64 %t118, 1
  store i64 %t120, ptr %l82, !tbaa !24
  %t121 = load i64, ptr @G_2ecompiler_2ftypes_2eOwnScope, !tbaa !24
  store i64 %t121, ptr %l83, !tbaa !24
  %t122 = load i64, ptr %l82, !tbaa !24
  %t123 = icmp sge i64 %t122, 0
  br i1 %t123, label %bb19, label %bb20
bb19:
  %t125 = load i64, ptr %l82, !tbaa !24
  %t126 = icmp sle i64 %t125, 1152921504606846975
  br i1 %t126, label %bb21, label %bb22
bb20:
  call void @__olang_check_failed(ptr @olang_loc_aa576265ebda78ff_b2b17010594f46db)
  unreachable
bb21:
  %t128 = load i64, ptr %l82, !tbaa !24
  %t129 = mul i64 %t128, 8
  %t130 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t129)
  %t131 = load i64, ptr %l83, !tbaa !24
  store i64 0, ptr %t132
  br label %fill.133
fill.133:
  %t136 = load i64, ptr %t132
  %t137 = icmp slt i64 %t136, %t128
  br i1 %t137, label %fillb.134, label %filld.135
fillb.134:
  %t138 = getelementptr i64, ptr %t130, i64 %t136
  store i64 %t131, ptr %t138
  %t139 = add i64 %t136, 1
  store i64 %t139, ptr %t132
  br label %fill.133
filld.135:
  %t140 = insertvalue { i64, ptr } undef, i64 %t128, 0
  %t141 = insertvalue { i64, ptr } %t140, ptr %t130, 1
  store { i64, ptr } %t141, ptr %l11, !tbaa !27
  store i64 0, ptr %l12, !tbaa !24
  %t143 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t145 = extractvalue { i64, ptr } %t143, 0
  store i64 %t145, ptr %l13, !tbaa !24
  store i64 1, ptr %l14, !tbaa !24
  %t147 = load i64, ptr %l13, !tbaa !24
  %t148 = load i64, ptr %l12, !tbaa !24
  %t151 = icmp sgt i64 %t147, %t148
  br i1 %t151, label %bb23, label %bb24
bb22:
  call void @__olang_check_failed(ptr @olang_loc_aa576265ebda78ff_b2b17010594f46db)
  unreachable
bb23:
  %t153 = load i64, ptr %l14, !tbaa !24
  %t155 = icmp sgt i64 %t153, 0
  br i1 %t155, label %bb25, label %bb26
bb24:
  store i64 0, ptr %l92, !tbaa !24
  br label %bb28
bb25:
  %t157 = load i64, ptr %l13, !tbaa !24
  %t158 = load i64, ptr %l12, !tbaa !24
  %t161 = sub i64 %t157, %t158
  %t162 = load i64, ptr %l14, !tbaa !24
  %t165 = add i64 %t161, %t162
  %t167 = sub i64 %t165, 1
  %t168 = load i64, ptr %l14, !tbaa !24
  %t171 = sdiv i64 %t167, %t168
  store i64 %t171, ptr %l95, !tbaa !24
  br label %bb27
bb26:
  store i64 0, ptr %l95, !tbaa !24
  br label %bb27
bb27:
  %t173 = load i64, ptr %l95, !tbaa !24
  store i64 %t173, ptr %l92, !tbaa !24
  br label %bb28
bb28:
  %t174 = load i64, ptr %l92, !tbaa !24
  store i64 %t174, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  br label %bb29
bb29:
  %t175 = load i64, ptr %l16, !tbaa !24
  %t176 = load i64, ptr %l15, !tbaa !24
  %t179 = icmp slt i64 %t175, %t176
  %t181 = xor i1 %t179, true
  br i1 %t181, label %bb30, label %bb31
bb30:
  br label %bb38
bb31:
  br label %bb32
bb32:
  %t183 = load i64, ptr %l12, !tbaa !24
  %t184 = load i64, ptr %l16, !tbaa !24
  %t185 = load i64, ptr %l14, !tbaa !24
  %t188 = mul i64 %t184, %t185
  %t191 = add i64 %t183, %t188
  store i64 %t191, ptr %l17, !tbaa !24
  %t193 = load ptr, ptr %l0, !tbaa !29
  %t195 = getelementptr %"compiler/generic:Program", ptr %t193, i32 0, i32 2
  %t196 = load i32, ptr %l1, !tbaa !23
  %t197 = load i64, ptr %l17, !tbaa !24
  %t201 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShareOf(ptr %v0, ptr %t195, i32 %t196, i64 %t197)
  store i64 %t201, ptr %l117
  br label %bb33
bb33:
  %t202 = load i64, ptr %l117, !tbaa !24
  store i64 %t202, ptr %l18, !tbaa !24
  %t203 = load i64, ptr %l17, !tbaa !24
  %t205 = add i64 %t203, 1
  store i64 %t205, ptr %l119, !tbaa !24
  %t206 = load i64, ptr %l18, !tbaa !24
  %t208 = icmp sge i64 %t206, 0
  br i1 %t208, label %bb34, label %bb35
bb34:
  %t210 = load i64, ptr %l18, !tbaa !24
  %t212 = add i64 %t210, 1
  store i64 %t212, ptr %l122, !tbaa !24
  br label %bb36
bb35:
  %t214 = load i64, ptr %l18, !tbaa !24
  store i64 %t214, ptr %l122, !tbaa !24
  br label %bb36
bb36:
  %t216 = load i64, ptr %l122, !tbaa !24
  %t217 = load i64, ptr %l119, !tbaa !24
  %t218 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t219 = load ptr, ptr %t218, !tbaa !27
  %t220 = getelementptr i64, ptr %t219, i64 %t217
  store i64 %t216, ptr %t220, !tbaa !34
  br label %bb37
bb37:
  %t221 = load i64, ptr %l16, !tbaa !24
  %t224 = add i64 %t221, 1
  store i64 %t224, ptr %l16, !tbaa !24
  br label %bb29
bb38:
  %t226 = load ptr, ptr %l0, !tbaa !29
  %t228 = getelementptr %"compiler/generic:Program", ptr %t226, i32 0, i32 2
  %t229 = load i32, ptr %l1, !tbaa !23
  %t232 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResults(ptr %v0, ptr %s0, ptr %t228, i32 %t229)
  store { i64, ptr } %t232, ptr %l132
  br label %bb39
bb39:
  %t233 = load { i64, ptr }, ptr %l132, !tbaa !27
  store { i64, ptr } %t233, ptr %l19, !tbaa !27
  %t234 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t236 = extractvalue { i64, ptr } %t234, 0
  store i64 %t236, ptr %l134, !tbaa !24
  %t237 = load i64, ptr @G_2ecompiler_2ftypes_2eOwnScope, !tbaa !24
  store i64 %t237, ptr %l135, !tbaa !24
  %t238 = load i64, ptr %l134, !tbaa !24
  %t239 = icmp sge i64 %t238, 0
  br i1 %t239, label %bb40, label %bb41
bb40:
  %t241 = load i64, ptr %l134, !tbaa !24
  %t242 = icmp sle i64 %t241, 1152921504606846975
  br i1 %t242, label %bb42, label %bb43
bb41:
  call void @__olang_check_failed(ptr @olang_loc_df1b6a3560be039c_3d298a2e16c742f8)
  unreachable
bb42:
  %t244 = load i64, ptr %l134, !tbaa !24
  %t245 = mul i64 %t244, 8
  %t246 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t245)
  %t247 = load i64, ptr %l135, !tbaa !24
  store i64 0, ptr %t248
  br label %fill.249
fill.249:
  %t252 = load i64, ptr %t248
  %t253 = icmp slt i64 %t252, %t244
  br i1 %t253, label %fillb.250, label %filld.251
fillb.250:
  %t254 = getelementptr i64, ptr %t246, i64 %t252
  store i64 %t247, ptr %t254
  %t255 = add i64 %t252, 1
  store i64 %t255, ptr %t248
  br label %fill.249
filld.251:
  %t256 = insertvalue { i64, ptr } undef, i64 %t244, 0
  %t257 = insertvalue { i64, ptr } %t256, ptr %t246, 1
  store { i64, ptr } %t257, ptr %l20, !tbaa !27
  store i64 0, ptr %l21, !tbaa !24
  %t259 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t261 = extractvalue { i64, ptr } %t259, 0
  store i64 %t261, ptr %l22, !tbaa !24
  store i64 1, ptr %l23, !tbaa !24
  %t263 = load i64, ptr %l22, !tbaa !24
  %t264 = load i64, ptr %l21, !tbaa !24
  %t267 = icmp sgt i64 %t263, %t264
  br i1 %t267, label %bb44, label %bb45
bb43:
  call void @__olang_check_failed(ptr @olang_loc_df1b6a3560be039c_3d298a2e16c742f8)
  unreachable
bb44:
  %t269 = load i64, ptr %l23, !tbaa !24
  %t271 = icmp sgt i64 %t269, 0
  br i1 %t271, label %bb46, label %bb47
bb45:
  store i64 0, ptr %l144, !tbaa !24
  br label %bb49
bb46:
  %t273 = load i64, ptr %l22, !tbaa !24
  %t274 = load i64, ptr %l21, !tbaa !24
  %t277 = sub i64 %t273, %t274
  %t278 = load i64, ptr %l23, !tbaa !24
  %t281 = add i64 %t277, %t278
  %t283 = sub i64 %t281, 1
  %t284 = load i64, ptr %l23, !tbaa !24
  %t287 = sdiv i64 %t283, %t284
  store i64 %t287, ptr %l147, !tbaa !24
  br label %bb48
bb47:
  store i64 0, ptr %l147, !tbaa !24
  br label %bb48
bb48:
  %t289 = load i64, ptr %l147, !tbaa !24
  store i64 %t289, ptr %l144, !tbaa !24
  br label %bb49
bb49:
  %t290 = load i64, ptr %l144, !tbaa !24
  store i64 %t290, ptr %l24, !tbaa !24
  store i64 0, ptr %l25, !tbaa !24
  br label %bb50
bb50:
  %t291 = load i64, ptr %l25, !tbaa !24
  %t292 = load i64, ptr %l24, !tbaa !24
  %t295 = icmp slt i64 %t291, %t292
  %t297 = xor i1 %t295, true
  br i1 %t297, label %bb51, label %bb52
bb51:
  br label %bb59
bb52:
  br label %bb53
bb53:
  %t299 = load i64, ptr %l21, !tbaa !24
  %t300 = load i64, ptr %l25, !tbaa !24
  %t301 = load i64, ptr %l23, !tbaa !24
  %t304 = mul i64 %t300, %t301
  %t307 = add i64 %t299, %t304
  store i64 %t307, ptr %l26, !tbaa !24
  %t309 = load ptr, ptr %l0, !tbaa !29
  %t311 = getelementptr %"compiler/generic:Program", ptr %t309, i32 0, i32 2
  %t312 = load i32, ptr %l1, !tbaa !23
  %t313 = load i64, ptr %l26, !tbaa !24
  %t317 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResultFrom(ptr %v0, ptr %t311, i32 %t312, i64 %t313)
  store i64 %t317, ptr %l169
  br label %bb54
bb54:
  %t318 = load i64, ptr %l169, !tbaa !24
  store i64 %t318, ptr %l27, !tbaa !24
  %t319 = load i64, ptr %l26, !tbaa !24
  store i64 %t319, ptr %l170, !tbaa !24
  %t320 = load i64, ptr %l27, !tbaa !24
  %t322 = icmp sge i64 %t320, 0
  br i1 %t322, label %bb55, label %bb56
bb55:
  %t324 = load i64, ptr %l27, !tbaa !24
  %t326 = add i64 %t324, 1
  store i64 %t326, ptr %l173, !tbaa !24
  br label %bb57
bb56:
  %t328 = load i64, ptr %l27, !tbaa !24
  store i64 %t328, ptr %l173, !tbaa !24
  br label %bb57
bb57:
  %t330 = load i64, ptr %l173, !tbaa !24
  %t331 = load i64, ptr %l170, !tbaa !24
  %t332 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t333 = load ptr, ptr %t332, !tbaa !27
  %t334 = getelementptr i64, ptr %t333, i64 %t331
  store i64 %t330, ptr %t334, !tbaa !34
  br label %bb58
bb58:
  %t335 = load i64, ptr %l25, !tbaa !24
  %t338 = add i64 %t335, 1
  store i64 %t338, ptr %l25, !tbaa !24
  br label %bb50
bb59:
  %t340 = load ptr, ptr %l0, !tbaa !29
  %t342 = getelementptr %"compiler/generic:Program", ptr %t340, i32 0, i32 2
  store ptr %t342, ptr %l181, !tbaa !29
  %t343 = load ptr, ptr %l0, !tbaa !29
  %t345 = getelementptr %"compiler/generic:Program", ptr %t343, i32 0, i32 2
  %t346 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t349 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s0, ptr %t345, { i64, ptr } %t346)
  store i32 %t349, ptr %l185
  br label %bb60
bb60:
  %t350 = load ptr, ptr %l0, !tbaa !29
  %t352 = getelementptr %"compiler/generic:Program", ptr %t350, i32 0, i32 2
  %t353 = load i32, ptr %l1, !tbaa !23
  %t356 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t352, i32 %t353)
  store i32 %t356, ptr %l189
  br label %bb61
bb61:
  %t357 = load ptr, ptr %l0, !tbaa !29
  %t359 = getelementptr %"compiler/generic:Program", ptr %t357, i32 0, i32 2
  %t360 = load i32, ptr %l1, !tbaa !23
  %t363 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t359, i32 %t360)
  store i32 %t363, ptr %l193
  br label %bb62
bb62:
  %t364 = load ptr, ptr %l0, !tbaa !29
  %t366 = getelementptr %"compiler/generic:Program", ptr %t364, i32 0, i32 2
  store ptr %t366, ptr %l195, !tbaa !29
  %t367 = load ptr, ptr %l0, !tbaa !29
  %t369 = getelementptr %"compiler/generic:Program", ptr %t367, i32 0, i32 2
  %t370 = load i32, ptr %l1, !tbaa !23
  %t373 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRole(ptr %v0, ptr %t369, i32 %t370)
  store i64 %t373, ptr %l199
  br label %bb63
bb63:
  %t374 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t375 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t376 = load ptr, ptr %l195, !tbaa !29
  %t377 = load i64, ptr %l199, !tbaa !24
  %t380 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopes(ptr %v0, ptr %s0, ptr %s0, ptr %t376, i64 %t377, { i64, ptr } %t374, { i64, ptr } %t375)
  store i32 %t380, ptr %l202
  br label %bb64
bb64:
  %t381 = load ptr, ptr %l181, !tbaa !29
  %t382 = load i32, ptr %l185, !tbaa !23
  %t383 = load i32, ptr %l189, !tbaa !23
  %t384 = load i32, ptr %l193, !tbaa !23
  %t385 = load i32, ptr %l202, !tbaa !23
  %t386 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t381, i32 %t382, i32 %t383, i32 %t384, i32 %t385, i64 0, i1 false, i32 0, i64 0)
  store i32 %t386, ptr %l203
  br label %bb65
bb65:
  call void @__olang_scope_close(ptr %s0)
  %t387 = load i32, ptr %l203, !tbaa !23
  store i32 %t387, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eaddBuilder(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l6 = alloca i64
  %l13 = alloca i64
  %l20 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l21 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i32
  %l36 = alloca i1
  %l38 = alloca i64
  %l42 = alloca i64
  %l43 = alloca i32
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = load ptr, ptr %l2, !tbaa !29
  %t5 = getelementptr %"compiler/ast:Func", ptr %t3, i32 0, i32 8
  %t6 = load ptr, ptr %t5, !tbaa !29
  %t7 = load ptr, ptr %l2, !tbaa !29
  %t9 = getelementptr %"compiler/ast:Func", ptr %t7, i32 0, i32 5
  %t10 = load { i64, ptr }, ptr %t9, !tbaa !27
  %t15 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2erecvKey(ptr %v0, ptr %v1, ptr %v1, ptr %t1, i64 %a1, ptr %t6, { i64, ptr } %t10)
  store i64 %t15, ptr %l13
  br label %bb1
bb1:
  %t16 = load i64, ptr %l13, !tbaa !24
  store i64 %t16, ptr %l4, !tbaa !24
  %t17 = load i64, ptr %l4, !tbaa !24
  %t19 = icmp slt i64 %t17, 0
  br i1 %t19, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb3:
  br label %bb4
bb4:
  %t21 = load i64, ptr %l4, !tbaa !24
  %t22 = load ptr, ptr %l2, !tbaa !29
  %t24 = getelementptr %"compiler/ast:Func", ptr %t22, i32 0, i32 9
  %t25 = load i32, ptr %t24, !tbaa !23
  %t27 = sext i32 %t25 to i64
  %t30 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s0, i64 %t21, i64 %t27)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t30, ptr %l20
  br label %bb5
bb5:
  %t31 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l20
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t31, ptr %l5
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/generic:Program", ptr %t32, i32 0, i32 42
  %t35 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l5
  %t38 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H5696e1a008d256bf9453cde2b49c6c45(ptr %v0, ptr %t34, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t35)
  %t39 = extractvalue { i32, i64 } %t38, 1
  %t40 = extractvalue { i32, i64 } %t38, 0
  store i32 %t40, ptr %l26
  %t41 = icmp ne i32 %t40, 0
  br i1 %t41, label %bb7, label %ok.42, !prof !99
ok.42:
  store i64 %t39, ptr %l25
  br label %bb6
bb6:
  %t43 = load i64, ptr %l25, !tbaa !24
  store i64 %t43, ptr %l21, !tbaa !24
  br label %bb9
bb7:
  br label %bb8
bb8:
  store i64 -1, ptr %l21, !tbaa !24
  br label %bb9
bb9:
  %t44 = load i64, ptr %l21, !tbaa !24
  store i64 %t44, ptr %l6, !tbaa !24
  %t45 = load i64, ptr %l6, !tbaa !24
  %t47 = icmp slt i64 %t45, 0
  br i1 %t47, label %bb10, label %bb11
bb10:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/generic:Program", ptr %t49, i32 0, i32 42
  %t52 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l5
  %t53 = load i64, ptr %l3, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H31314c4e7281f5029d6d8eb3044cef10(ptr %v0, ptr %t51, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t52, i64 %t53)
  br label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb25
bb13:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/generic:Program", ptr %t57, i32 0, i32 39
  %t60 = load i64, ptr %l6, !tbaa !24
  %t63 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v0, ptr %t59, i64 %t60)
  store i1 %t63, ptr %l36
  br label %bb14
bb14:
  %t64 = load i1, ptr %l36, !tbaa !21
  %t65 = xor i1 %t64, true
  br i1 %t65, label %bb15, label %bb16
bb15:
  br label %bb23
bb16:
  br label %bb17
bb17:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/generic:Program", ptr %t67, i32 0, i32 39
  %t70 = load i64, ptr %l6, !tbaa !24
  %t73 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t69, i64 %t70)
  %t74 = extractvalue { i32, i64 } %t73, 1
  %t75 = extractvalue { i32, i64 } %t73, 0
  store i32 %t75, ptr %l43
  %t76 = icmp ne i32 %t75, 0
  br i1 %t76, label %bb19, label %ok.77, !prof !99
ok.77:
  store i64 %t74, ptr %l42
  br label %bb18
bb18:
  %t78 = load i64, ptr %l42, !tbaa !24
  store i64 %t78, ptr %l38, !tbaa !24
  br label %bb21
bb19:
  br label %bb20
bb20:
  store i64 -1, ptr %l38, !tbaa !24
  br label %bb21
bb21:
  %t79 = load i64, ptr %l38, !tbaa !24
  store i64 %t79, ptr %l6, !tbaa !24
  br label %bb22
bb22:
  br label %bb13
bb23:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t82 = getelementptr %"compiler/generic:Program", ptr %t80, i32 0, i32 39
  %t83 = load i64, ptr %l6, !tbaa !24
  %t84 = load i64, ptr %l3, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t82, i64 %t83, i64 %t84)
  br label %bb24
bb24:
  br label %bb25
bb25:
  %t88 = load i64, ptr %l4, !tbaa !24
  %t90 = ashr i64 %t88, 40
  %t92 = icmp eq i64 %t90, 4
  br i1 %t92, label %bb26, label %bb27
bb26:
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t96 = getelementptr %"compiler/generic:Program", ptr %t94, i32 0, i32 43
  %t97 = load i64, ptr %l3, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t96, i64 %t97)
  br label %bb28
bb27:
  br label %bb30
bb28:
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t102 = getelementptr %"compiler/generic:Program", ptr %t100, i32 0, i32 44
  %t103 = load i64, ptr %l4, !tbaa !24
  %t104 = shl i64 1, 40
  %t106 = sub i64 %t104, 1
  %t109 = and i64 %t103, %t106
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t102, i64 %t109)
  br label %bb29
bb29:
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eaddFn(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2, i1 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l6 = alloca i64
  %l7 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l8 = alloca i64
  %l11 = alloca i64
  %l13 = alloca ptr
  %l17 = alloca %"compiler/generic:fnRow"
  %l19 = alloca i1
  %l31 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l32 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i32
  %l43 = alloca ptr
  %l44 = alloca i64
  %l54 = alloca i64
  %l60 = alloca i1
  %l64 = alloca { i64, ptr }
  %l65 = alloca i1
  %l66 = alloca i1
  %l84 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l85 = alloca i64
  %l89 = alloca i64
  %l90 = alloca i32
  %l100 = alloca i1
  %l102 = alloca i64
  %l106 = alloca i64
  %l107 = alloca i32
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/generic:Program", ptr %t1, i32 0, i32 31
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3afnRow_3e_2eLen_3ccompiler_2fgeneric_3afnRow_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l11
  br label %bb1
bb1:
  %t6 = load i64, ptr %l11, !tbaa !24
  store i64 %t6, ptr %l4, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/generic:Program", ptr %t7, i32 0, i32 31
  store ptr %t9, ptr %l13, !tbaa !29
  %t10 = load i64, ptr %l1, !tbaa !24
  %t11 = load ptr, ptr %l2, !tbaa !29
  %t16 = call %"compiler/generic:fnRow" @compiler_2fgeneric_3afnRow_2ector(ptr %v1, ptr %v0, i64 %t10, ptr %t11, i1 %a3)
  store %"compiler/generic:fnRow" %t16, ptr %l17
  br label %bb2
bb2:
  %t17 = load ptr, ptr %l13, !tbaa !29
  %t18 = load %"compiler/generic:fnRow", ptr %l17
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3afnRow_3e_2ePush_3ccompiler_2fgeneric_3afnRow_3e(ptr %v0, ptr %v0, ptr %t17, %"compiler/generic:fnRow" %t18)
  br label %bb3
bb3:
  %t19 = load ptr, ptr %l2, !tbaa !29
  %t21 = call i1 @compiler_2fast_2ecompiler_2fast_3aFunc_2eIsBuilder(ptr %v1, ptr %t19)
  store i1 %t21, ptr %l19
  br label %bb4
bb4:
  %t22 = load i1, ptr %l19, !tbaa !21
  br i1 %t22, label %bb5, label %bb6
bb5:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load i64, ptr %l1, !tbaa !24
  %t25 = load ptr, ptr %l2, !tbaa !29
  %t26 = load i64, ptr %l4, !tbaa !24
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eaddBuilder(ptr %v0, ptr %v1, ptr %t23, i64 %t24, ptr %t25, i64 %t26)
  br label %bb7
bb6:
  br label %bb8
bb7:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb8:
  %t31 = load ptr, ptr %l2, !tbaa !29
  %t33 = getelementptr %"compiler/ast:Func", ptr %t31, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !29
  %t36 = icmp eq ptr %t34, null
  br i1 %t36, label %bb9, label %bb10
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t38 = load i64, ptr %l1, !tbaa !24
  %t39 = load ptr, ptr %l2, !tbaa !29
  %t41 = getelementptr %"compiler/ast:Func", ptr %t39, i32 0, i32 2
  %t42 = load i32, ptr %t41, !tbaa !23
  %t44 = sext i32 %t42 to i64
  %t47 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s2, i64 %t38, i64 %t44)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t47, ptr %l31
  br label %bb11
bb10:
  br label %bb20
bb11:
  %t48 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l31
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t48, ptr %l5
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/generic:Program", ptr %t49, i32 0, i32 36
  %t52 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l5
  %t55 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H5696e1a008d256bf9453cde2b49c6c45(ptr %v0, ptr %t51, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t52)
  %t56 = extractvalue { i32, i64 } %t55, 1
  %t57 = extractvalue { i32, i64 } %t55, 0
  store i32 %t57, ptr %l37
  %t58 = icmp ne i32 %t57, 0
  br i1 %t58, label %bb13, label %ok.59, !prof !99
ok.59:
  store i64 %t56, ptr %l36
  br label %bb12
bb12:
  %t60 = load i64, ptr %l36, !tbaa !24
  store i64 %t60, ptr %l32, !tbaa !24
  br label %bb15
bb13:
  br label %bb14
bb14:
  store i64 -1, ptr %l32, !tbaa !24
  br label %bb15
bb15:
  %t61 = load i64, ptr %l32, !tbaa !24
  %t62 = icmp slt i64 %t61, 0
  br i1 %t62, label %bb16, label %bb17
bb16:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/generic:Program", ptr %t64, i32 0, i32 36
  %t67 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l5
  %t68 = load i64, ptr %l4, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H31314c4e7281f5029d6d8eb3044cef10(ptr %v0, ptr %t66, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t67, i64 %t68)
  br label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb20:
  %t72 = load ptr, ptr %l0, !tbaa !29
  store ptr %t72, ptr %l43, !tbaa !29
  %t73 = load i64, ptr %l1, !tbaa !24
  store i64 %t73, ptr %l44, !tbaa !24
  %t74 = load ptr, ptr %l2, !tbaa !29
  %t76 = getelementptr %"compiler/ast:Func", ptr %t74, i32 0, i32 1
  %t77 = load ptr, ptr %t76, !tbaa !29
  %t79 = icmp eq ptr %t77, null
  br i1 %t79, label %bb21, label %bb22
bb21:
  call void @__olang_check_failed(ptr @olang_loc_cab99c6a514cda4c_3636b0df4624338)
  unreachable
bb22:
  br label %bb23
bb23:
  %t81 = load ptr, ptr %l2, !tbaa !29
  %t83 = getelementptr %"compiler/ast:Func", ptr %t81, i32 0, i32 1
  %t84 = load ptr, ptr %t83, !tbaa !29
  %t87 = getelementptr %"compiler/ast:Param", ptr %t84, i32 0, i32 2
  %t88 = load ptr, ptr %t87, !tbaa !29
  %t89 = load ptr, ptr %l2, !tbaa !29
  %t91 = getelementptr %"compiler/ast:Func", ptr %t89, i32 0, i32 5
  %t92 = load { i64, ptr }, ptr %t91, !tbaa !27
  %t93 = load ptr, ptr %l43, !tbaa !29
  %t94 = load i64, ptr %l44, !tbaa !24
  %t97 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2erecvKey(ptr %v0, ptr %v1, ptr %v1, ptr %t93, i64 %t94, ptr %t88, { i64, ptr } %t92)
  store i64 %t97, ptr %l54
  br label %bb24
bb24:
  %t98 = load i64, ptr %l54, !tbaa !24
  store i64 %t98, ptr %l6, !tbaa !24
  %t99 = load i64, ptr %l6, !tbaa !24
  %t101 = icmp slt i64 %t99, 0
  br i1 %t101, label %bb25, label %bb26
bb25:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb26:
  br label %bb27
bb27:
  %t103 = load i64, ptr %l6, !tbaa !24
  %t105 = ashr i64 %t103, 40
  %t107 = icmp eq i64 %t105, 1
  br i1 %t107, label %bb28, label %bb29
bb28:
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t110 = load ptr, ptr %l2, !tbaa !29
  %t112 = getelementptr %"compiler/ast:Func", ptr %t110, i32 0, i32 2
  %t113 = load i32, ptr %t112, !tbaa !23
  %t116 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2etext(ptr %v0, ptr %v0, ptr %t109, i32 %t113)
  store { i64, ptr } %t116, ptr %l64
  br label %bb30
bb29:
  store i1 false, ptr %l60, !tbaa !21
  br label %bb32
bb30:
  %t117 = load { i64, ptr }, ptr %l64, !tbaa !27
  %t118 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t117, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d37, i32 0, i32 1) })
  store i1 %t118, ptr %l65
  br label %bb31
bb31:
  %t119 = load i1, ptr %l65, !tbaa !21
  store i1 %t119, ptr %l60, !tbaa !21
  br label %bb32
bb32:
  %t120 = load i1, ptr %l60, !tbaa !21
  br i1 %t120, label %bb33, label %bb34
bb33:
  %t121 = load ptr, ptr %l2, !tbaa !29
  %t123 = getelementptr %"compiler/ast:Func", ptr %t121, i32 0, i32 3
  %t124 = load ptr, ptr %t123, !tbaa !29
  %t126 = getelementptr %"compiler/ast:Sig", ptr %t124, i32 0, i32 0
  %t127 = load { i64, ptr }, ptr %t126, !tbaa !27
  %t129 = extractvalue { i64, ptr } %t127, 0
  %t131 = icmp eq i64 %t129, 0
  store i1 %t131, ptr %l66, !tbaa !21
  br label %bb35
bb34:
  store i1 false, ptr %l66, !tbaa !21
  br label %bb35
bb35:
  %t133 = load i1, ptr %l66, !tbaa !21
  br i1 %t133, label %bb36, label %bb37
bb36:
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t136 = getelementptr %"compiler/generic:Program", ptr %t134, i32 0, i32 2
  %t137 = load i64, ptr %l6, !tbaa !24
  %t138 = shl i64 1, 40
  %t140 = sub i64 %t138, 1
  %t143 = and i64 %t137, %t140
  %t145 = trunc i64 %t143 to i32
  call void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eMarkCopy(ptr %v0, ptr %t136, i32 %t145)
  br label %bb38
bb37:
  br label %bb39
bb38:
  br label %bb39
bb39:
  %t149 = load i64, ptr %l6, !tbaa !24
  %t150 = load ptr, ptr %l2, !tbaa !29
  %t152 = getelementptr %"compiler/ast:Func", ptr %t150, i32 0, i32 2
  %t153 = load i32, ptr %t152, !tbaa !23
  %t155 = sext i32 %t153 to i64
  %t158 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s0, i64 %t149, i64 %t155)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t158, ptr %l84
  br label %bb40
bb40:
  %t159 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l84
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t159, ptr %l7
  %t160 = load ptr, ptr %l0, !tbaa !29
  %t162 = getelementptr %"compiler/generic:Program", ptr %t160, i32 0, i32 38
  %t163 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l7
  %t166 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H5696e1a008d256bf9453cde2b49c6c45(ptr %v0, ptr %t162, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t163)
  %t167 = extractvalue { i32, i64 } %t166, 1
  %t168 = extractvalue { i32, i64 } %t166, 0
  store i32 %t168, ptr %l90
  %t169 = icmp ne i32 %t168, 0
  br i1 %t169, label %bb42, label %ok.170, !prof !99
ok.170:
  store i64 %t167, ptr %l89
  br label %bb41
bb41:
  %t171 = load i64, ptr %l89, !tbaa !24
  store i64 %t171, ptr %l85, !tbaa !24
  br label %bb44
bb42:
  br label %bb43
bb43:
  store i64 -1, ptr %l85, !tbaa !24
  br label %bb44
bb44:
  %t172 = load i64, ptr %l85, !tbaa !24
  store i64 %t172, ptr %l8, !tbaa !24
  %t173 = load i64, ptr %l8, !tbaa !24
  %t175 = icmp slt i64 %t173, 0
  br i1 %t175, label %bb45, label %bb46
bb45:
  %t177 = load ptr, ptr %l0, !tbaa !29
  %t179 = getelementptr %"compiler/generic:Program", ptr %t177, i32 0, i32 38
  %t180 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l7
  %t181 = load i64, ptr %l4, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H31314c4e7281f5029d6d8eb3044cef10(ptr %v0, ptr %t179, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t180, i64 %t181)
  br label %bb47
bb46:
  br label %bb48
bb47:
  br label %bb60
bb48:
  %t185 = load ptr, ptr %l0, !tbaa !29
  %t187 = getelementptr %"compiler/generic:Program", ptr %t185, i32 0, i32 39
  %t188 = load i64, ptr %l8, !tbaa !24
  %t191 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v0, ptr %t187, i64 %t188)
  store i1 %t191, ptr %l100
  br label %bb49
bb49:
  %t192 = load i1, ptr %l100, !tbaa !21
  %t193 = xor i1 %t192, true
  br i1 %t193, label %bb50, label %bb51
bb50:
  br label %bb58
bb51:
  br label %bb52
bb52:
  %t195 = load ptr, ptr %l0, !tbaa !29
  %t197 = getelementptr %"compiler/generic:Program", ptr %t195, i32 0, i32 39
  %t198 = load i64, ptr %l8, !tbaa !24
  %t201 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t197, i64 %t198)
  %t202 = extractvalue { i32, i64 } %t201, 1
  %t203 = extractvalue { i32, i64 } %t201, 0
  store i32 %t203, ptr %l107
  %t204 = icmp ne i32 %t203, 0
  br i1 %t204, label %bb54, label %ok.205, !prof !99
ok.205:
  store i64 %t202, ptr %l106
  br label %bb53
bb53:
  %t206 = load i64, ptr %l106, !tbaa !24
  store i64 %t206, ptr %l102, !tbaa !24
  br label %bb56
bb54:
  br label %bb55
bb55:
  store i64 -1, ptr %l102, !tbaa !24
  br label %bb56
bb56:
  %t207 = load i64, ptr %l102, !tbaa !24
  store i64 %t207, ptr %l8, !tbaa !24
  br label %bb57
bb57:
  br label %bb48
bb58:
  %t208 = load ptr, ptr %l0, !tbaa !29
  %t210 = getelementptr %"compiler/generic:Program", ptr %t208, i32 0, i32 39
  %t211 = load i64, ptr %l8, !tbaa !24
  %t212 = load i64, ptr %l4, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t210, i64 %t211, i64 %t212)
  br label %bb59
bb59:
  br label %bb60
bb60:
  %t216 = load i64, ptr %l6, !tbaa !24
  %t218 = ashr i64 %t216, 40
  %t220 = icmp eq i64 %t218, 4
  br i1 %t220, label %bb61, label %bb62
bb61:
  %t222 = load ptr, ptr %l0, !tbaa !29
  %t224 = getelementptr %"compiler/generic:Program", ptr %t222, i32 0, i32 40
  %t225 = load i64, ptr %l4, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t224, i64 %t225)
  br label %bb63
bb62:
  br label %bb65
bb63:
  %t228 = load ptr, ptr %l0, !tbaa !29
  %t230 = getelementptr %"compiler/generic:Program", ptr %t228, i32 0, i32 41
  %t231 = load i64, ptr %l6, !tbaa !24
  %t232 = shl i64 1, 40
  %t234 = sub i64 %t232, 1
  %t237 = and i64 %t231, %t234
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t230, i64 %t237)
  br label %bb64
bb64:
  br label %bb65
bb65:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eanonEnum(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l17 = alloca i64
  %l22 = alloca i64
  %l26 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l32 = alloca i64
  %l35 = alloca i64
  %l54 = alloca { i64, ptr }
  %l58 = alloca i64
  %l61 = alloca { i64, ptr }
  %l64 = alloca i32
  %l65 = alloca { i64, ptr }
  %l71 = alloca { i64, ptr }
  %l81 = alloca { i64, ptr }
  %l94 = alloca ptr
  %l95 = alloca { i64, ptr }
  %l99 = alloca i32
  %l101 = alloca { i64, ptr }
  %l102 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  store i64 %t3, ptr %l17, !tbaa !24
  %t4 = load i64, ptr %l17, !tbaa !24
  %t5 = icmp sge i64 %t4, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load i64, ptr %l17, !tbaa !24
  %t8 = icmp sle i64 %t7, 2305843009213693951
  br i1 %t8, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_c23c218140effa50_4db4b783113412a4)
  unreachable
bb3:
  %t10 = load i64, ptr %l17, !tbaa !24
  %t11 = mul i64 %t10, 4
  %t12 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t11)
  %t13 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l3, !tbaa !27
  %t16 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t18 = extractvalue { i64, ptr } %t16, 0
  store i64 %t18, ptr %l22, !tbaa !24
  %t19 = load i64, ptr %l22, !tbaa !24
  %t20 = icmp sge i64 %t19, 0
  br i1 %t20, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_c23c218140effa50_4db4b783113412a4)
  unreachable
bb5:
  %t22 = load i64, ptr %l22, !tbaa !24
  %t23 = icmp sle i64 %t22, 2305843009213693951
  br i1 %t23, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_7e185c750e76a77d_541671d994da32b1)
  unreachable
bb7:
  %t25 = load i64, ptr %l22, !tbaa !24
  %t26 = mul i64 %t25, 4
  %t27 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t26)
  %t28 = insertvalue { i64, ptr } undef, i64 %t25, 0
  %t29 = insertvalue { i64, ptr } %t28, ptr %t27, 1
  store { i64, ptr } %t29, ptr %l4, !tbaa !27
  %t31 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t31, ptr %l26
  br label %bb9
bb8:
  call void @__olang_check_failed(ptr @olang_loc_7e185c750e76a77d_541671d994da32b1)
  unreachable
bb9:
  %t32 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l26
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t32, ptr %l5
  store i64 0, ptr %l6, !tbaa !24
  %t33 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t35 = extractvalue { i64, ptr } %t33, 0
  store i64 %t35, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t37 = load i64, ptr %l7, !tbaa !24
  %t38 = load i64, ptr %l6, !tbaa !24
  %t41 = icmp sgt i64 %t37, %t38
  br i1 %t41, label %bb10, label %bb11
bb10:
  %t43 = load i64, ptr %l8, !tbaa !24
  %t45 = icmp sgt i64 %t43, 0
  br i1 %t45, label %bb12, label %bb13
bb11:
  store i64 0, ptr %l32, !tbaa !24
  br label %bb15
bb12:
  %t47 = load i64, ptr %l7, !tbaa !24
  %t48 = load i64, ptr %l6, !tbaa !24
  %t51 = sub i64 %t47, %t48
  %t52 = load i64, ptr %l8, !tbaa !24
  %t55 = add i64 %t51, %t52
  %t57 = sub i64 %t55, 1
  %t58 = load i64, ptr %l8, !tbaa !24
  %t61 = sdiv i64 %t57, %t58
  store i64 %t61, ptr %l35, !tbaa !24
  br label %bb14
bb13:
  store i64 0, ptr %l35, !tbaa !24
  br label %bb14
bb14:
  %t63 = load i64, ptr %l35, !tbaa !24
  store i64 %t63, ptr %l32, !tbaa !24
  br label %bb15
bb15:
  %t64 = load i64, ptr %l32, !tbaa !24
  store i64 %t64, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb16
bb16:
  %t65 = load i64, ptr %l10, !tbaa !24
  %t66 = load i64, ptr %l9, !tbaa !24
  %t69 = icmp slt i64 %t65, %t66
  %t71 = xor i1 %t69, true
  br i1 %t71, label %bb17, label %bb18
bb17:
  br label %bb32
bb18:
  br label %bb19
bb19:
  %t73 = load i64, ptr %l6, !tbaa !24
  %t74 = load i64, ptr %l10, !tbaa !24
  %t75 = load i64, ptr %l8, !tbaa !24
  %t78 = mul i64 %t74, %t75
  %t81 = add i64 %t73, %t78
  store i64 %t81, ptr %l11, !tbaa !24
  %t83 = load i64, ptr %l11, !tbaa !24
  %t84 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t84, ptr %l54, !tbaa !27
  %t85 = load i64, ptr %l11, !tbaa !24
  %t87 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t88 = load ptr, ptr %t87, !tbaa !27
  %t89 = getelementptr ptr, ptr %t88, i64 %t85
  %t90 = load ptr, ptr %t89, !tbaa !39
  %t92 = getelementptr %"compiler/ast:CaseDecl", ptr %t90, i32 0, i32 1
  %t93 = load i32, ptr %t92, !tbaa !23
  %t96 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t97 = load ptr, ptr %t96, !tbaa !27
  %t98 = getelementptr i32, ptr %t97, i64 %t83
  store i32 %t93, ptr %t98, !tbaa !33
  %t99 = load i64, ptr %l11, !tbaa !24
  store i64 %t99, ptr %l58, !tbaa !24
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t102 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t102, ptr %l61, !tbaa !27
  %t103 = load i64, ptr %l11, !tbaa !24
  %t105 = getelementptr { i64, ptr }, ptr %l61, i32 0, i32 1
  %t106 = load ptr, ptr %t105, !tbaa !27
  %t107 = getelementptr ptr, ptr %t106, i64 %t103
  %t108 = load ptr, ptr %t107, !tbaa !39
  %t112 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2epayload(ptr %v0, ptr %v1, ptr %v2, ptr %t100, ptr %a1, ptr %t108, i32 -1)
  store i32 %t112, ptr %l64
  br label %bb20
bb20:
  %t113 = load i32, ptr %l64, !tbaa !23
  %t114 = load i64, ptr %l58, !tbaa !24
  %t115 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t116 = load ptr, ptr %t115, !tbaa !27
  %t117 = getelementptr i32, ptr %t116, i64 %t114
  store i32 %t113, ptr %t117, !tbaa !33
  %t118 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t118, ptr %l65, !tbaa !27
  %t119 = load i64, ptr %l11, !tbaa !24
  %t121 = getelementptr { i64, ptr }, ptr %l65, i32 0, i32 1
  %t122 = load ptr, ptr %t121, !tbaa !27
  %t123 = getelementptr ptr, ptr %t122, i64 %t119
  %t124 = load ptr, ptr %t123, !tbaa !39
  %t126 = getelementptr %"compiler/ast:CaseDecl", ptr %t124, i32 0, i32 2
  %t127 = load { i64, ptr }, ptr %t126, !tbaa !27
  %t129 = extractvalue { i64, ptr } %t127, 0
  %t131 = icmp sgt i64 %t129, 0
  br i1 %t131, label %bb21, label %bb22
bb21:
  %t133 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t133, ptr %l71, !tbaa !27
  %t134 = load i64, ptr %l11, !tbaa !24
  %t136 = getelementptr { i64, ptr }, ptr %l71, i32 0, i32 1
  %t137 = load ptr, ptr %t136, !tbaa !27
  %t138 = getelementptr ptr, ptr %t137, i64 %t134
  %t139 = load ptr, ptr %t138, !tbaa !39
  %t141 = getelementptr %"compiler/ast:CaseDecl", ptr %t139, i32 0, i32 2
  %t142 = load { i64, ptr }, ptr %t141, !tbaa !27
  store { i64, ptr } %t142, ptr %l12, !tbaa !27
  store i64 0, ptr %l13, !tbaa !24
  %t144 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t146 = extractvalue { i64, ptr } %t144, 0
  store i64 %t146, ptr %l14, !tbaa !24
  br label %bb23
bb22:
  br label %bb30
bb23:
  %t148 = load i64, ptr %l13, !tbaa !24
  %t149 = load i64, ptr %l14, !tbaa !24
  %t152 = icmp slt i64 %t148, %t149
  %t154 = xor i1 %t152, true
  br i1 %t154, label %bb24, label %bb25
bb24:
  br label %bb29
bb25:
  br label %bb26
bb26:
  %t156 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t156, ptr %l81, !tbaa !27
  %t157 = load i64, ptr %l13, !tbaa !24
  %t159 = getelementptr { i64, ptr }, ptr %l81, i32 0, i32 1
  %t160 = load ptr, ptr %t159, !tbaa !27
  %t161 = getelementptr ptr, ptr %t160, i64 %t157
  %t162 = load ptr, ptr %t161, !tbaa !39
  %t166 = getelementptr %"compiler/ast:Param", ptr %t162, i32 0, i32 1
  %t167 = load i32, ptr %t166, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ePush_3ccompiler_2fsource_3aNameId_3e(ptr %s0, ptr %l5, i32 %t167)
  br label %bb27
bb27:
  br label %bb28
bb28:
  %t170 = load i64, ptr %l13, !tbaa !24
  %t173 = add i64 %t170, 1
  store i64 %t173, ptr %l13, !tbaa !24
  br label %bb23
bb29:
  br label %bb30
bb30:
  br label %bb31
bb31:
  %t175 = load i64, ptr %l10, !tbaa !24
  %t178 = add i64 %t175, 1
  store i64 %t178, ptr %l10, !tbaa !24
  br label %bb16
bb32:
  %t180 = load ptr, ptr %l0, !tbaa !29
  %t182 = getelementptr %"compiler/generic:Program", ptr %t180, i32 0, i32 2
  store ptr %t182, ptr %l94, !tbaa !29
  %t183 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t183, ptr %l95, !tbaa !27
  %t184 = load ptr, ptr %l0, !tbaa !29
  %t186 = getelementptr %"compiler/generic:Program", ptr %t184, i32 0, i32 2
  %t187 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t190 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s0, ptr %t186, { i64, ptr } %t187)
  store i32 %t190, ptr %l99
  br label %bb33
bb33:
  %t192 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eToArra_H4d02a0b2e27e8f31ffc99daa43750593(ptr %s0, ptr %s0, ptr %l5)
  store { i64, ptr } %t192, ptr %l101
  br label %bb34
bb34:
  %t193 = load ptr, ptr %l94, !tbaa !29
  %t194 = load { i64, ptr }, ptr %l95, !tbaa !27
  %t195 = load i32, ptr %l99, !tbaa !23
  %t196 = load { i64, ptr }, ptr %l101, !tbaa !27
  %t197 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAnonEnum(ptr %v0, ptr %s0, ptr %s0, ptr %t193, { i64, ptr } %t194, i32 %t195, { i64, ptr } %t196)
  store i32 %t197, ptr %l102
  br label %bb35
bb35:
  call void @__olang_scope_close(ptr %s0)
  %t198 = load i32, ptr %l102, !tbaa !23
  store i32 %t198, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ebodiesOf(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i32
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i32
  %l22 = alloca i1
  %l29 = alloca i32
  %l34 = alloca i1
  %l37 = alloca ptr
  %l41 = alloca i32
  %l42 = alloca { i64, ptr }
  %l49 = alloca { i64, ptr }
  %l58 = alloca ptr
  %l62 = alloca i32
  %l63 = alloca { i64, ptr }
  %l70 = alloca { i64, ptr }
  %l81 = alloca ptr
  %l85 = alloca i32
  %l86 = alloca i32
  %l89 = alloca ptr
  %l93 = alloca i32
  %l96 = alloca ptr
  %l100 = alloca i32
  %l106 = alloca ptr
  %l110 = alloca i32
  %l111 = alloca { i64, ptr }
  %l118 = alloca { i64, ptr }
  %l129 = alloca ptr
  %l133 = alloca i32
  %l134 = alloca { i64, ptr }
  %l141 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/generic:Program", ptr %t1, i32 0, i32 62
  %t4 = load i32, ptr %l1, !tbaa !23
  %t7 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_Hb3133f486435530b533aaf49461c92b5(ptr %v0, ptr %t3, i32 %t4)
  store i1 %t7, ptr %l22
  br label %bb1
bb1:
  %t8 = load i1, ptr %l22, !tbaa !21
  br i1 %t8, label %bb2, label %bb3
bb2:
  br label %ret
bb3:
  br label %bb4
bb4:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/generic:Program", ptr %t9, i32 0, i32 62
  %t12 = load i32, ptr %l1, !tbaa !23
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_H64d9be73b6c9bed004c541bdf7f0ca0a(ptr %v0, ptr %t11, i32 %t12, i1 true)
  br label %bb5
bb5:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/generic:Program", ptr %t15, i32 0, i32 2
  %t18 = load i32, ptr %l1, !tbaa !23
  %t21 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t17, i32 %t18)
  store i32 %t21, ptr %l29
  br label %bb6
bb6:
  %t22 = load i32, ptr %l29, !range !{i32 0, i32 33}
  store i32 %t22, ptr %l2
  %t23 = load i32, ptr %l2, !range !{i32 0, i32 33}
  %t25 = trunc i64 18 to i32
  %t26 = icmp eq i32 %t23, %t25
  br i1 %t26, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb42
bb9:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load i32, ptr %l1, !tbaa !23
  %t32 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %t28, i32 %t29)
  store i1 %t32, ptr %l34
  br label %bb10
bb10:
  %t33 = load i1, ptr %l34, !tbaa !21
  %t34 = xor i1 %t33, true
  br i1 %t34, label %bb11, label %bb12
bb11:
  br label %ret
bb12:
  br label %bb13
bb13:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/generic:Program", ptr %t36, i32 0, i32 2
  store ptr %t38, ptr %l37, !tbaa !29
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/generic:Program", ptr %t39, i32 0, i32 2
  %t42 = load i32, ptr %l1, !tbaa !23
  %t45 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t41, i32 %t42)
  store i32 %t45, ptr %l41
  br label %bb14
bb14:
  %t46 = load ptr, ptr %l37, !tbaa !29
  %t47 = load i32, ptr %l41, !tbaa !23
  %t48 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t46, i32 %t47)
  store { i64, ptr } %t48, ptr %l42
  br label %bb15
bb15:
  %t49 = load { i64, ptr }, ptr %l42, !tbaa !27
  store { i64, ptr } %t49, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t50 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t52 = extractvalue { i64, ptr } %t50, 0
  store i64 %t52, ptr %l5, !tbaa !24
  br label %bb16
bb16:
  %t54 = load i64, ptr %l4, !tbaa !24
  %t55 = load i64, ptr %l5, !tbaa !24
  %t58 = icmp slt i64 %t54, %t55
  %t60 = xor i1 %t58, true
  br i1 %t60, label %bb17, label %bb18
bb17:
  br label %bb22
bb18:
  br label %bb19
bb19:
  %t62 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t62, ptr %l49, !tbaa !27
  %t63 = load i64, ptr %l4, !tbaa !24
  %t65 = getelementptr { i64, ptr }, ptr %l49, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !27
  %t67 = getelementptr i32, ptr %t66, i64 %t63
  %t68 = load i32, ptr %t67, !tbaa !33
  %t70 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ebodiesOf(ptr %v0, ptr %t70, i32 %t68)
  br label %bb20
bb20:
  br label %bb21
bb21:
  %t74 = load i64, ptr %l4, !tbaa !24
  %t77 = add i64 %t74, 1
  store i64 %t77, ptr %l4, !tbaa !24
  br label %bb16
bb22:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/generic:Program", ptr %t79, i32 0, i32 2
  store ptr %t81, ptr %l58, !tbaa !29
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/generic:Program", ptr %t82, i32 0, i32 2
  %t85 = load i32, ptr %l1, !tbaa !23
  %t88 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %t84, i32 %t85)
  store i32 %t88, ptr %l62
  br label %bb23
bb23:
  %t89 = load ptr, ptr %l58, !tbaa !29
  %t90 = load i32, ptr %l62, !tbaa !23
  %t91 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t89, i32 %t90)
  store { i64, ptr } %t91, ptr %l63
  br label %bb24
bb24:
  %t92 = load { i64, ptr }, ptr %l63, !tbaa !27
  store { i64, ptr } %t92, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t93 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t95 = extractvalue { i64, ptr } %t93, 0
  store i64 %t95, ptr %l9, !tbaa !24
  br label %bb25
bb25:
  %t97 = load i64, ptr %l8, !tbaa !24
  %t98 = load i64, ptr %l9, !tbaa !24
  %t101 = icmp slt i64 %t97, %t98
  %t103 = xor i1 %t101, true
  br i1 %t103, label %bb26, label %bb27
bb26:
  br label %bb34
bb27:
  br label %bb28
bb28:
  %t105 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t105, ptr %l70, !tbaa !27
  %t106 = load i64, ptr %l8, !tbaa !24
  %t108 = getelementptr { i64, ptr }, ptr %l70, i32 0, i32 1
  %t109 = load ptr, ptr %t108, !tbaa !27
  %t110 = getelementptr i32, ptr %t109, i64 %t106
  %t111 = load i32, ptr %t110, !tbaa !33
  store i32 %t111, ptr %l10, !tbaa !23
  %t113 = load i32, ptr %l10, !tbaa !23
  %t115 = icmp ne i32 %t113, 0
  br i1 %t115, label %bb29, label %bb30
bb29:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t118 = load i32, ptr %l10, !tbaa !23
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ebodiesOf(ptr %v0, ptr %t117, i32 %t118)
  br label %bb31
bb30:
  br label %bb32
bb31:
  br label %bb32
bb32:
  br label %bb33
bb33:
  %t121 = load i64, ptr %l8, !tbaa !24
  %t124 = add i64 %t121, 1
  store i64 %t124, ptr %l8, !tbaa !24
  br label %bb25
bb34:
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t128 = getelementptr %"compiler/generic:Program", ptr %t126, i32 0, i32 2
  store ptr %t128, ptr %l81, !tbaa !29
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t131 = getelementptr %"compiler/generic:Program", ptr %t129, i32 0, i32 2
  %t132 = load i32, ptr %l1, !tbaa !23
  %t135 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t131, i32 %t132)
  store i32 %t135, ptr %l85
  br label %bb35
bb35:
  %t136 = load ptr, ptr %l81, !tbaa !29
  %t137 = load i32, ptr %l85, !tbaa !23
  %t138 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t136, i32 %t137)
  store i32 %t138, ptr %l86
  br label %bb36
bb36:
  %t139 = load i32, ptr %l86, !range !{i32 0, i32 6}
  %t141 = trunc i64 4 to i32
  %t142 = icmp eq i32 %t139, %t141
  br i1 %t142, label %bb37, label %bb38
bb37:
  %t144 = load ptr, ptr %l0, !tbaa !29
  store ptr %t144, ptr %l89, !tbaa !29
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t147 = getelementptr %"compiler/generic:Program", ptr %t145, i32 0, i32 2
  %t148 = load i32, ptr %l1, !tbaa !23
  %t151 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %t147, i32 %t148)
  store i32 %t151, ptr %l93
  br label %bb39
bb38:
  br label %bb41
bb39:
  %t152 = load ptr, ptr %l89, !tbaa !29
  %t153 = load i32, ptr %l93, !tbaa !23
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ebodiesOf(ptr %v0, ptr %t152, i32 %t153)
  br label %bb40
bb40:
  br label %bb41
bb41:
  br label %bb84
bb42:
  %t154 = load i32, ptr %l2, !range !{i32 0, i32 33}
  %t156 = trunc i64 19 to i32
  %t157 = icmp eq i32 %t154, %t156
  br i1 %t157, label %bb43, label %bb44
bb43:
  br label %bb45
bb44:
  br label %bb48
bb45:
  %t159 = load ptr, ptr %l0, !tbaa !29
  store ptr %t159, ptr %l96, !tbaa !29
  %t160 = load ptr, ptr %l0, !tbaa !29
  %t162 = getelementptr %"compiler/generic:Program", ptr %t160, i32 0, i32 2
  %t163 = load i32, ptr %l1, !tbaa !23
  %t166 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t162, i32 %t163)
  store i32 %t166, ptr %l100
  br label %bb46
bb46:
  %t167 = load ptr, ptr %l96, !tbaa !29
  %t168 = load i32, ptr %l100, !tbaa !23
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ebodiesOf(ptr %v0, ptr %t167, i32 %t168)
  br label %bb47
bb47:
  br label %bb84
bb48:
  %t169 = load i32, ptr %l2, !range !{i32 0, i32 33}
  %t171 = trunc i64 22 to i32
  %t172 = icmp eq i32 %t169, %t171
  br i1 %t172, label %bb49, label %bb50
bb49:
  br label %bb53
bb50:
  %t174 = load i32, ptr %l2, !range !{i32 0, i32 33}
  %t176 = trunc i64 23 to i32
  %t177 = icmp eq i32 %t174, %t176
  br i1 %t177, label %bb51, label %bb52
bb51:
  br label %bb53
bb52:
  br label %bb63
bb53:
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t181 = getelementptr %"compiler/generic:Program", ptr %t179, i32 0, i32 2
  store ptr %t181, ptr %l106, !tbaa !29
  %t182 = load ptr, ptr %l0, !tbaa !29
  %t184 = getelementptr %"compiler/generic:Program", ptr %t182, i32 0, i32 2
  %t185 = load i32, ptr %l1, !tbaa !23
  %t188 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t184, i32 %t185)
  store i32 %t188, ptr %l110
  br label %bb54
bb54:
  %t189 = load ptr, ptr %l106, !tbaa !29
  %t190 = load i32, ptr %l110, !tbaa !23
  %t191 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t189, i32 %t190)
  store { i64, ptr } %t191, ptr %l111
  br label %bb55
bb55:
  %t192 = load { i64, ptr }, ptr %l111, !tbaa !27
  store { i64, ptr } %t192, ptr %l11, !tbaa !27
  store i64 0, ptr %l12, !tbaa !24
  %t193 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t195 = extractvalue { i64, ptr } %t193, 0
  store i64 %t195, ptr %l13, !tbaa !24
  br label %bb56
bb56:
  %t197 = load i64, ptr %l12, !tbaa !24
  %t198 = load i64, ptr %l13, !tbaa !24
  %t201 = icmp slt i64 %t197, %t198
  %t203 = xor i1 %t201, true
  br i1 %t203, label %bb57, label %bb58
bb57:
  br label %bb62
bb58:
  br label %bb59
bb59:
  %t205 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t205, ptr %l118, !tbaa !27
  %t206 = load i64, ptr %l12, !tbaa !24
  %t208 = getelementptr { i64, ptr }, ptr %l118, i32 0, i32 1
  %t209 = load ptr, ptr %t208, !tbaa !27
  %t210 = getelementptr i32, ptr %t209, i64 %t206
  %t211 = load i32, ptr %t210, !tbaa !33
  %t213 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ebodiesOf(ptr %v0, ptr %t213, i32 %t211)
  br label %bb60
bb60:
  br label %bb61
bb61:
  %t217 = load i64, ptr %l12, !tbaa !24
  %t220 = add i64 %t217, 1
  store i64 %t220, ptr %l12, !tbaa !24
  br label %bb56
bb62:
  br label %bb84
bb63:
  %t222 = load i32, ptr %l2, !range !{i32 0, i32 33}
  %t224 = trunc i64 24 to i32
  %t225 = icmp eq i32 %t222, %t224
  br i1 %t225, label %bb64, label %bb65
bb64:
  br label %bb66
bb65:
  br label %bb79
bb66:
  %t227 = load ptr, ptr %l0, !tbaa !29
  %t229 = getelementptr %"compiler/generic:Program", ptr %t227, i32 0, i32 2
  store ptr %t229, ptr %l129, !tbaa !29
  %t230 = load ptr, ptr %l0, !tbaa !29
  %t232 = getelementptr %"compiler/generic:Program", ptr %t230, i32 0, i32 2
  %t233 = load i32, ptr %l1, !tbaa !23
  %t236 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeCases(ptr %v0, ptr %t232, i32 %t233)
  store i32 %t236, ptr %l133
  br label %bb67
bb67:
  %t237 = load ptr, ptr %l129, !tbaa !29
  %t238 = load i32, ptr %l133, !tbaa !23
  %t239 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t237, i32 %t238)
  store { i64, ptr } %t239, ptr %l134
  br label %bb68
bb68:
  %t240 = load { i64, ptr }, ptr %l134, !tbaa !27
  store { i64, ptr } %t240, ptr %l15, !tbaa !27
  store i64 0, ptr %l16, !tbaa !24
  %t241 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t243 = extractvalue { i64, ptr } %t241, 0
  store i64 %t243, ptr %l17, !tbaa !24
  br label %bb69
bb69:
  %t245 = load i64, ptr %l16, !tbaa !24
  %t246 = load i64, ptr %l17, !tbaa !24
  %t249 = icmp slt i64 %t245, %t246
  %t251 = xor i1 %t249, true
  br i1 %t251, label %bb70, label %bb71
bb70:
  br label %bb78
bb71:
  br label %bb72
bb72:
  %t253 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t253, ptr %l141, !tbaa !27
  %t254 = load i64, ptr %l16, !tbaa !24
  %t256 = getelementptr { i64, ptr }, ptr %l141, i32 0, i32 1
  %t257 = load ptr, ptr %t256, !tbaa !27
  %t258 = getelementptr i32, ptr %t257, i64 %t254
  %t259 = load i32, ptr %t258, !tbaa !33
  store i32 %t259, ptr %l18, !tbaa !23
  %t261 = load i32, ptr %l18, !tbaa !23
  %t263 = icmp ne i32 %t261, 0
  br i1 %t263, label %bb73, label %bb74
bb73:
  %t265 = load ptr, ptr %l0, !tbaa !29
  %t266 = load i32, ptr %l18, !tbaa !23
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ebodiesOf(ptr %v0, ptr %t265, i32 %t266)
  br label %bb75
bb74:
  br label %bb76
bb75:
  br label %bb76
bb76:
  br label %bb77
bb77:
  %t269 = load i64, ptr %l16, !tbaa !24
  %t272 = add i64 %t269, 1
  store i64 %t272, ptr %l16, !tbaa !24
  br label %bb69
bb78:
  br label %bb84
bb79:
  br i1 true, label %bb80, label %bb81
bb80:
  br label %bb82
bb81:
  br label %bb83
bb82:
  br label %bb84
bb83:
  call void @__olang_check_failed(ptr @olang_loc_4f8ba0791f7285d_6734ddd6ace13789)
  unreachable
bb84:
  br label %ret
ret:
  ret void
}

define dso_local { i32, i32 } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ecanonInner(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i1
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca i32
  %l12 = alloca i64
  %l13 = alloca i32
  %l14 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l17 = alloca i1
  %l18 = alloca i32
  %l22 = alloca i32
  %l23 = alloca i32
  %l26 = alloca i1
  %l27 = alloca i32
  %l31 = alloca i32
  %l32 = alloca i32
  %l45 = alloca ptr
  %l47 = alloca { i64, ptr }
  %l48 = alloca i1
  %l50 = alloca i32
  %l53 = alloca i32
  %l54 = alloca i32
  %l57 = alloca i1
  %l60 = alloca i32
  %l65 = alloca i32
  %l66 = alloca i32
  %l72 = alloca i1
  %l74 = alloca ptr
  %l75 = alloca i32
  %l78 = alloca i32
  %l79 = alloca i32
  %l81 = alloca i32
  %l83 = alloca i1
  %l84 = alloca i32
  %l87 = alloca i32
  %l88 = alloca i32
  %l91 = alloca i1
  %l93 = alloca ptr
  %l94 = alloca i32
  %l97 = alloca i32
  %l98 = alloca i32
  %l100 = alloca i32
  %l102 = alloca i1
  %l103 = alloca i32
  %l106 = alloca i32
  %l107 = alloca i32
  %l110 = alloca i1
  %l112 = alloca ptr
  %l115 = alloca i32
  %l116 = alloca i64
  %l118 = alloca i64
  %l119 = alloca i32
  %l121 = alloca i32
  %l123 = alloca i1
  %l130 = alloca i32
  %l139 = alloca i1
  %l141 = alloca i8
  %l142 = alloca i1
  %l144 = alloca ptr
  %l149 = alloca { i64, ptr }
  %l150 = alloca i64
  %l152 = alloca i64
  %l153 = alloca i64
  %l159 = alloca i8
  %l162 = alloca i1
  %l165 = alloca i1
  %l168 = alloca i1
  %l173 = alloca i32
  %l179 = alloca ptr
  %l191 = alloca i1
  %l193 = alloca i8
  %l194 = alloca i1
  %l195 = alloca i1
  %l197 = alloca i8
  %l199 = alloca i1
  %l201 = alloca i8
  %l204 = alloca ptr
  %l208 = alloca i32
  %l209 = alloca ptr
  %l210 = alloca { i64, ptr }
  %l212 = alloca { i64, ptr }
  %l213 = alloca i64
  %l215 = alloca i64
  %l216 = alloca i64
  %l221 = alloca i32
  %l222 = alloca i32
  %l225 = alloca i1
  %l229 = alloca i32
  %l232 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l234 = alloca i64
  %l235 = alloca i64
  %l239 = alloca i64
  %l242 = alloca ptr
  %l243 = alloca i32
  %l246 = alloca i32
  %l247 = alloca i32
  %l250 = alloca i1
  %l252 = alloca i1
  %l255 = alloca ptr
  %l256 = alloca i32
  %l258 = alloca ptr
  %l260 = alloca { i64, ptr }
  %l261 = alloca i32
  %l262 = alloca i32
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %rv = alloca { i32, i32 }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3acursor_2eeat(ptr %v1, ptr %s0, ptr %t1, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d38, i32 0, i32 1) })
  store i1 %t3, ptr %l17
  br label %bb1
bb1:
  %t4 = load i1, ptr %l17, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t6 = load ptr, ptr %l1, !tbaa !29
  %t7 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t11 = call { i32, i32 } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ecanonFunc(ptr %v0, ptr %v1, ptr %t5, ptr %t6, i1 false, i32 %t7)
  %t12 = extractvalue { i32, i32 } %t11, 1
  %t13 = extractvalue { i32, i32 } %t11, 0
  store i32 %t13, ptr %l23
  %t14 = icmp ne i32 %t13, 0
  br i1 %t14, label %bb5, label %ok.15, !prof !99
ok.15:
  store i32 %t12, ptr %l22
  br label %bb4
bb3:
  br label %bb7
bb4:
  %t16 = load i32, ptr %l22, !tbaa !23
  store i32 %t16, ptr %l18, !tbaa !23
  br label %bb6
bb5:
  %t17 = load i32, ptr %l23, !tbaa !23
  %t18 = lshr i32 %t17, 16
  %t19 = and i32 %t17, 65535
  %t20 = icmp eq i32 %t18, 1
  %t21 = select i1 %t20, i32 1, i32 0
  %t22 = icmp eq i32 %t18, 2
  %t23 = select i1 %t22, i32 2, i32 %t21
  %t24 = icmp eq i32 %t17, 0
  %t25 = shl i32 %t23, 16
  %t26 = or i32 %t25, %t19
  %t27 = select i1 %t24, i32 0, i32 %t26
  call void @__olang_scope_close(ptr %s0)
  %t29 = insertvalue { i32, i32 } zeroinitializer, i32 %t27, 0
  store { i32, i32 } %t29, ptr %rv
  br label %ret
bb6:
  call void @__olang_scope_close(ptr %s0)
  %t30 = load i32, ptr %l18, !tbaa !23
  %t31 = insertvalue { i32, i32 } zeroinitializer, i32 %t30, 1
  store { i32, i32 } %t31, ptr %rv
  br label %ret
bb7:
  %t32 = load ptr, ptr %l1, !tbaa !29
  %t34 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3acursor_2eeat(ptr %v1, ptr %s0, ptr %t32, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d39, i32 0, i32 1) })
  store i1 %t34, ptr %l26
  br label %bb8
bb8:
  %t35 = load i1, ptr %l26, !tbaa !21
  br i1 %t35, label %bb9, label %bb10
bb9:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t37 = load ptr, ptr %l1, !tbaa !29
  %t38 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t42 = call { i32, i32 } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ecanonFunc(ptr %v0, ptr %v1, ptr %t36, ptr %t37, i1 true, i32 %t38)
  %t43 = extractvalue { i32, i32 } %t42, 1
  %t44 = extractvalue { i32, i32 } %t42, 0
  store i32 %t44, ptr %l32
  %t45 = icmp ne i32 %t44, 0
  br i1 %t45, label %bb12, label %ok.46, !prof !99
ok.46:
  store i32 %t43, ptr %l31
  br label %bb11
bb10:
  br label %bb14
bb11:
  %t47 = load i32, ptr %l31, !tbaa !23
  store i32 %t47, ptr %l27, !tbaa !23
  br label %bb13
bb12:
  %t48 = load i32, ptr %l32, !tbaa !23
  %t49 = lshr i32 %t48, 16
  %t50 = and i32 %t48, 65535
  %t51 = icmp eq i32 %t49, 1
  %t52 = select i1 %t51, i32 1, i32 0
  %t53 = icmp eq i32 %t49, 2
  %t54 = select i1 %t53, i32 2, i32 %t52
  %t55 = icmp eq i32 %t48, 0
  %t56 = shl i32 %t54, 16
  %t57 = or i32 %t56, %t50
  %t58 = select i1 %t55, i32 0, i32 %t57
  call void @__olang_scope_close(ptr %s0)
  %t60 = insertvalue { i32, i32 } zeroinitializer, i32 %t58, 0
  store { i32, i32 } %t60, ptr %rv
  br label %ret
bb13:
  call void @__olang_scope_close(ptr %s0)
  %t61 = load i32, ptr %l27, !tbaa !23
  %t62 = insertvalue { i32, i32 } zeroinitializer, i32 %t61, 1
  store { i32, i32 } %t62, ptr %rv
  br label %ret
bb14:
  store %olang.scope zeroinitializer, ptr %s3
  %t63 = insertvalue [2 x i1] undef, i1 false, 0
  %t64 = insertvalue [2 x i1] %t63, i1 true, 1
  %t66 = call ptr @__olang_scope_alloc_a(ptr %s3, i64 2, i64 8)
  store [2 x i1] %t64, ptr %t66
  store ptr %t66, ptr %l2
  store i64 0, ptr %l3, !tbaa !24
  %t68 = load ptr, ptr %l2
  store i64 2, ptr %l4, !tbaa !24
  br label %bb15
bb15:
  store %olang.scope zeroinitializer, ptr %s4
  %t71 = load i64, ptr %l3, !tbaa !24
  %t72 = load i64, ptr %l4, !tbaa !24
  %t75 = icmp slt i64 %t71, %t72
  %t77 = xor i1 %t75, true
  br i1 %t77, label %bb16, label %bb17
bb16:
  call void @__olang_scope_close(ptr %s4)
  br label %bb37
bb17:
  br label %bb18
bb18:
  %t79 = load ptr, ptr %l2
  %t80 = load i64, ptr %l3, !tbaa !24
  %t83 = getelementptr [2 x i1], ptr %t79, i64 0, i64 %t80
  %t84 = load i1, ptr %t83, !tbaa !31
  store i1 %t84, ptr %l5, !tbaa !21
  %t86 = load ptr, ptr %l1, !tbaa !29
  store ptr %t86, ptr %l45, !tbaa !29
  %t87 = load i1, ptr %l5, !tbaa !21
  br i1 %t87, label %bb19, label %bb20
bb19:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d40, i32 0, i32 1) }, ptr %l47, !tbaa !27
  br label %bb21
bb20:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d41, i32 0, i32 1) }, ptr %l47, !tbaa !27
  br label %bb21
bb21:
  %t89 = load ptr, ptr %l45, !tbaa !29
  %t90 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t91 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3acursor_2eeat(ptr %v1, ptr %s4, ptr %t89, { i64, ptr } %t90)
  store i1 %t91, ptr %l48
  br label %bb22
bb22:
  %t92 = load i1, ptr %l48, !tbaa !21
  %t93 = xor i1 %t92, true
  br i1 %t93, label %bb23, label %bb24
bb23:
  call void @__olang_scope_close(ptr %s4)
  br label %bb36
bb24:
  br label %bb25
bb25:
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t96 = load ptr, ptr %l1, !tbaa !29
  %t99 = call { i32, i32 } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ecanonType(ptr %v0, ptr %v1, ptr %t95, ptr %t96)
  %t100 = extractvalue { i32, i32 } %t99, 1
  %t101 = extractvalue { i32, i32 } %t99, 0
  store i32 %t101, ptr %l54
  %t102 = icmp ne i32 %t101, 0
  br i1 %t102, label %bb27, label %ok.103, !prof !99
ok.103:
  store i32 %t100, ptr %l53
  br label %bb26
bb26:
  %t104 = load i32, ptr %l53, !tbaa !23
  store i32 %t104, ptr %l50, !tbaa !23
  br label %bb28
bb27:
  %t105 = load i32, ptr %l54, !tbaa !23
  %t106 = lshr i32 %t105, 16
  %t107 = and i32 %t105, 65535
  %t108 = icmp eq i32 %t106, 1
  %t109 = select i1 %t108, i32 1, i32 0
  %t110 = icmp eq i32 %t106, 2
  %t111 = select i1 %t110, i32 2, i32 %t109
  %t112 = icmp eq i32 %t105, 0
  %t113 = shl i32 %t111, 16
  %t114 = or i32 %t113, %t107
  %t115 = select i1 %t112, i32 0, i32 %t114
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t117 = insertvalue { i32, i32 } zeroinitializer, i32 %t115, 0
  store { i32, i32 } %t117, ptr %rv
  br label %ret
bb28:
  %t118 = load i32, ptr %l50, !tbaa !23
  store i32 %t118, ptr %l6, !tbaa !23
  %t119 = load ptr, ptr %l1, !tbaa !29
  %t121 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3acursor_2eeat(ptr %v1, ptr %s4, ptr %t119, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d42, i32 0, i32 1) })
  store i1 %t121, ptr %l57
  br label %bb29
bb29:
  %t122 = load i1, ptr %l57, !tbaa !21
  %t123 = xor i1 %t122, true
  br i1 %t123, label %bb30, label %bb31
bb30:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t126 = insertvalue { i32, i32 } zeroinitializer, i32 65536, 0
  store { i32, i32 } %t126, ptr %rv
  br label %ret
bb31:
  br label %bb32
bb32:
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t128 = load ptr, ptr %l1, !tbaa !29
  %t129 = load i1, ptr %l5, !tbaa !21
  %t130 = load i32, ptr %l6, !tbaa !23
  %t135 = call { i32, i32 } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ecanonFunc(ptr %v0, ptr %v1, ptr %t127, ptr %t128, i1 %t129, i32 %t130)
  %t136 = extractvalue { i32, i32 } %t135, 1
  %t137 = extractvalue { i32, i32 } %t135, 0
  store i32 %t137, ptr %l66
  %t138 = icmp ne i32 %t137, 0
  br i1 %t138, label %bb34, label %ok.139, !prof !99
ok.139:
  store i32 %t136, ptr %l65
  br label %bb33
bb33:
  %t140 = load i32, ptr %l65, !tbaa !23
  store i32 %t140, ptr %l60, !tbaa !23
  br label %bb35
bb34:
  %t141 = load i32, ptr %l66, !tbaa !23
  %t142 = lshr i32 %t141, 16
  %t143 = and i32 %t141, 65535
  %t144 = icmp eq i32 %t142, 1
  %t145 = select i1 %t144, i32 1, i32 0
  %t146 = icmp eq i32 %t142, 2
  %t147 = select i1 %t146, i32 2, i32 %t145
  %t148 = icmp eq i32 %t141, 0
  %t149 = shl i32 %t147, 16
  %t150 = or i32 %t149, %t143
  %t151 = select i1 %t148, i32 0, i32 %t150
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t153 = insertvalue { i32, i32 } zeroinitializer, i32 %t151, 0
  store { i32, i32 } %t153, ptr %rv
  br label %ret
bb35:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t154 = load i32, ptr %l60, !tbaa !23
  %t155 = insertvalue { i32, i32 } zeroinitializer, i32 %t154, 1
  store { i32, i32 } %t155, ptr %rv
  br label %ret
bb36:
  %t156 = load i64, ptr %l3, !tbaa !24
  %t159 = add i64 %t156, 1
  store i64 %t159, ptr %l3, !tbaa !24
  br label %bb15
bb37:
  call void @__olang_scope_close(ptr %s3)
  %t161 = load ptr, ptr %l1, !tbaa !29
  %t163 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3acursor_2eeat(ptr %v1, ptr %s0, ptr %t161, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d43, i32 0, i32 1) })
  store i1 %t163, ptr %l72
  br label %bb38
bb38:
  %t164 = load i1, ptr %l72, !tbaa !21
  br i1 %t164, label %bb39, label %bb40
bb39:
  store %olang.scope zeroinitializer, ptr %s8
  %t165 = load ptr, ptr %l0, !tbaa !29
  %t167 = getelementptr %"compiler/generic:Program", ptr %t165, i32 0, i32 2
  store ptr %t167, ptr %l74, !tbaa !29
  %t168 = load ptr, ptr %l0, !tbaa !29
  %t169 = load ptr, ptr %l1, !tbaa !29
  %t172 = call { i32, i32 } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ecanonList(ptr %v0, ptr %v1, ptr %s8, ptr %t168, ptr %t169, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d44, i32 0, i32 1) })
  %t173 = extractvalue { i32, i32 } %t172, 1
  %t174 = extractvalue { i32, i32 } %t172, 0
  store i32 %t174, ptr %l79
  %t175 = icmp ne i32 %t174, 0
  br i1 %t175, label %bb42, label %ok.176, !prof !99
ok.176:
  store i32 %t173, ptr %l78
  br label %bb41
bb40:
  br label %bb45
bb41:
  %t177 = load i32, ptr %l78, !tbaa !23
  store i32 %t177, ptr %l75, !tbaa !23
  br label %bb43
bb42:
  %t178 = load i32, ptr %l79, !tbaa !23
  %t179 = lshr i32 %t178, 16
  %t180 = and i32 %t178, 65535
  %t181 = icmp eq i32 %t179, 1
  %t182 = select i1 %t181, i32 1, i32 0
  %t183 = icmp eq i32 %t179, 2
  %t184 = select i1 %t183, i32 2, i32 %t182
  %t185 = icmp eq i32 %t178, 0
  %t186 = shl i32 %t184, 16
  %t187 = or i32 %t186, %t180
  %t188 = select i1 %t185, i32 0, i32 %t187
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  %t190 = insertvalue { i32, i32 } zeroinitializer, i32 %t188, 0
  store { i32, i32 } %t190, ptr %rv
  br label %ret
bb43:
  %t191 = load ptr, ptr %l74, !tbaa !29
  %t192 = load i32, ptr %l75, !tbaa !23
  %t193 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRecord(ptr %v0, ptr %t191, i32 %t192)
  store i32 %t193, ptr %l81
  br label %bb44
bb44:
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  %t194 = load i32, ptr %l81, !tbaa !23
  %t195 = insertvalue { i32, i32 } zeroinitializer, i32 %t194, 1
  store { i32, i32 } %t195, ptr %rv
  br label %ret
bb45:
  %t196 = load ptr, ptr %l1, !tbaa !29
  %t198 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3acursor_2eeat(ptr %v1, ptr %s0, ptr %t196, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d45, i32 0, i32 1) })
  store i1 %t198, ptr %l83
  br label %bb46
bb46:
  %t199 = load i1, ptr %l83, !tbaa !21
  br i1 %t199, label %bb47, label %bb48
bb47:
  %t200 = load ptr, ptr %l0, !tbaa !29
  %t201 = load ptr, ptr %l1, !tbaa !29
  %t204 = call { i32, i32 } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ecanonEnum(ptr %v0, ptr %v1, ptr %t200, ptr %t201)
  %t205 = extractvalue { i32, i32 } %t204, 1
  %t206 = extractvalue { i32, i32 } %t204, 0
  store i32 %t206, ptr %l88
  %t207 = icmp ne i32 %t206, 0
  br i1 %t207, label %bb50, label %ok.208, !prof !99
ok.208:
  store i32 %t205, ptr %l87
  br label %bb49
bb48:
  br label %bb52
bb49:
  %t209 = load i32, ptr %l87, !tbaa !23
  store i32 %t209, ptr %l84, !tbaa !23
  br label %bb51
bb50:
  %t210 = load i32, ptr %l88, !tbaa !23
  %t211 = lshr i32 %t210, 16
  %t212 = and i32 %t210, 65535
  %t213 = icmp eq i32 %t211, 1
  %t214 = select i1 %t213, i32 1, i32 0
  %t215 = icmp eq i32 %t211, 2
  %t216 = select i1 %t215, i32 2, i32 %t214
  %t217 = icmp eq i32 %t210, 0
  %t218 = shl i32 %t216, 16
  %t219 = or i32 %t218, %t212
  %t220 = select i1 %t217, i32 0, i32 %t219
  call void @__olang_scope_close(ptr %s0)
  %t222 = insertvalue { i32, i32 } zeroinitializer, i32 %t220, 0
  store { i32, i32 } %t222, ptr %rv
  br label %ret
bb51:
  call void @__olang_scope_close(ptr %s0)
  %t223 = load i32, ptr %l84, !tbaa !23
  %t224 = insertvalue { i32, i32 } zeroinitializer, i32 %t223, 1
  store { i32, i32 } %t224, ptr %rv
  br label %ret
bb52:
  %t225 = load ptr, ptr %l1, !tbaa !29
  %t227 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3acursor_2eeat(ptr %v1, ptr %s0, ptr %t225, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d46, i32 0, i32 1) })
  store i1 %t227, ptr %l91
  br label %bb53
bb53:
  %t228 = load i1, ptr %l91, !tbaa !21
  br i1 %t228, label %bb54, label %bb55
bb54:
  store %olang.scope zeroinitializer, ptr %s10
  %t229 = load ptr, ptr %l0, !tbaa !29
  %t231 = getelementptr %"compiler/generic:Program", ptr %t229, i32 0, i32 2
  store ptr %t231, ptr %l93, !tbaa !29
  %t232 = load ptr, ptr %l0, !tbaa !29
  %t233 = load ptr, ptr %l1, !tbaa !29
  %t236 = call { i32, i32 } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ecanonList(ptr %v0, ptr %v1, ptr %s10, ptr %t232, ptr %t233, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d47, i32 0, i32 1) })
  %t237 = extractvalue { i32, i32 } %t236, 1
  %t238 = extractvalue { i32, i32 } %t236, 0
  store i32 %t238, ptr %l98
  %t239 = icmp ne i32 %t238, 0
  br i1 %t239, label %bb57, label %ok.240, !prof !99
ok.240:
  store i32 %t237, ptr %l97
  br label %bb56
bb55:
  br label %bb60
bb56:
  %t241 = load i32, ptr %l97, !tbaa !23
  store i32 %t241, ptr %l94, !tbaa !23
  br label %bb58
bb57:
  %t242 = load i32, ptr %l98, !tbaa !23
  %t243 = lshr i32 %t242, 16
  %t244 = and i32 %t242, 65535
  %t245 = icmp eq i32 %t243, 1
  %t246 = select i1 %t245, i32 1, i32 0
  %t247 = icmp eq i32 %t243, 2
  %t248 = select i1 %t247, i32 2, i32 %t246
  %t249 = icmp eq i32 %t242, 0
  %t250 = shl i32 %t248, 16
  %t251 = or i32 %t250, %t244
  %t252 = select i1 %t249, i32 0, i32 %t251
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s0)
  %t254 = insertvalue { i32, i32 } zeroinitializer, i32 %t252, 0
  store { i32, i32 } %t254, ptr %rv
  br label %ret
bb58:
  %t255 = load ptr, ptr %l93, !tbaa !29
  %t256 = load i32, ptr %l94, !tbaa !23
  %t257 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eTuple(ptr %v0, ptr %t255, i32 %t256)
  store i32 %t257, ptr %l100
  br label %bb59
bb59:
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s0)
  %t258 = load i32, ptr %l100, !tbaa !23
  %t259 = insertvalue { i32, i32 } zeroinitializer, i32 %t258, 1
  store { i32, i32 } %t259, ptr %rv
  br label %ret
bb60:
  %t260 = load ptr, ptr %l1, !tbaa !29
  %t262 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3acursor_2eeat(ptr %v1, ptr %s0, ptr %t260, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d48, i32 0, i32 1) })
  store i1 %t262, ptr %l102
  br label %bb61
bb61:
  %t263 = load i1, ptr %l102, !tbaa !21
  br i1 %t263, label %bb62, label %bb63
bb62:
  store %olang.scope zeroinitializer, ptr %s11
  %t264 = load ptr, ptr %l0, !tbaa !29
  %t265 = load ptr, ptr %l1, !tbaa !29
  %t268 = call { i32, i32 } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ecanonType(ptr %v0, ptr %v1, ptr %t264, ptr %t265)
  %t269 = extractvalue { i32, i32 } %t268, 1
  %t270 = extractvalue { i32, i32 } %t268, 0
  store i32 %t270, ptr %l107
  %t271 = icmp ne i32 %t270, 0
  br i1 %t271, label %bb65, label %ok.272, !prof !99
ok.272:
  store i32 %t269, ptr %l106
  br label %bb64
bb63:
  br label %bb81
bb64:
  %t273 = load i32, ptr %l106, !tbaa !23
  store i32 %t273, ptr %l103, !tbaa !23
  br label %bb66
bb65:
  %t274 = load i32, ptr %l107, !tbaa !23
  %t275 = lshr i32 %t274, 16
  %t276 = and i32 %t274, 65535
  %t277 = icmp eq i32 %t275, 1
  %t278 = select i1 %t277, i32 1, i32 0
  %t279 = icmp eq i32 %t275, 2
  %t280 = select i1 %t279, i32 2, i32 %t278
  %t281 = icmp eq i32 %t274, 0
  %t282 = shl i32 %t280, 16
  %t283 = or i32 %t282, %t276
  %t284 = select i1 %t281, i32 0, i32 %t283
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s0)
  %t286 = insertvalue { i32, i32 } zeroinitializer, i32 %t284, 0
  store { i32, i32 } %t286, ptr %rv
  br label %ret
bb66:
  %t287 = load i32, ptr %l103, !tbaa !23
  store i32 %t287, ptr %l7, !tbaa !23
  store i32 0, ptr %l8, !tbaa !23
  %t288 = load ptr, ptr %l1, !tbaa !29
  %t290 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3acursor_2eeat(ptr %v1, ptr %s11, ptr %t288, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d49, i32 0, i32 1) })
  store i1 %t290, ptr %l110
  br label %bb67
bb67:
  %t291 = load i1, ptr %l110, !tbaa !21
  br i1 %t291, label %bb68, label %bb69
bb68:
  store %olang.scope zeroinitializer, ptr %s12
  %t292 = load ptr, ptr %l0, !tbaa !29
  %t294 = getelementptr %"compiler/generic:Program", ptr %t292, i32 0, i32 2
  store ptr %t294, ptr %l112, !tbaa !29
  %t295 = load ptr, ptr %l0, !tbaa !29
  %t297 = getelementptr %"compiler/generic:Program", ptr %t295, i32 0, i32 2
  %t299 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s12, ptr %t297, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d50, i32 0, i32 1) })
  store i32 %t299, ptr %l115
  br label %bb70
bb69:
  br label %bb75
bb70:
  %t300 = load ptr, ptr %l1, !tbaa !29
  %t302 = call { i32, i64 } @compiler_2fgeneric_2ecanonNumber(ptr %v1, ptr %t300)
  %t303 = extractvalue { i32, i64 } %t302, 1
  %t304 = extractvalue { i32, i64 } %t302, 0
  store i32 %t304, ptr %l119
  %t305 = icmp ne i32 %t304, 0
  br i1 %t305, label %bb72, label %ok.306, !prof !99
ok.306:
  store i64 %t303, ptr %l118
  br label %bb71
bb71:
  %t307 = load i64, ptr %l118, !tbaa !24
  store i64 %t307, ptr %l116, !tbaa !24
  br label %bb73
bb72:
  %t308 = load i32, ptr %l119, !tbaa !23
  %t309 = lshr i32 %t308, 16
  %t310 = and i32 %t308, 65535
  %t311 = icmp eq i32 %t309, 1
  %t312 = select i1 %t311, i32 1, i32 0
  %t313 = icmp eq i32 %t308, 0
  %t314 = shl i32 %t312, 16
  %t315 = or i32 %t314, %t310
  %t316 = select i1 %t313, i32 0, i32 %t315
  call void @__olang_scope_close(ptr %s12)
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s0)
  %t318 = insertvalue { i32, i32 } zeroinitializer, i32 %t316, 0
  store { i32, i32 } %t318, ptr %rv
  br label %ret
bb73:
  %t319 = load ptr, ptr %l112, !tbaa !29
  %t320 = load i32, ptr %l115, !tbaa !23
  %t321 = load i64, ptr %l116, !tbaa !24
  %t322 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConst(ptr %v0, ptr %t319, i32 %t320, i64 %t321)
  store i32 %t322, ptr %l121
  br label %bb74
bb74:
  %t323 = load i32, ptr %l121, !tbaa !23
  store i32 %t323, ptr %l8, !tbaa !23
  call void @__olang_scope_close(ptr %s12)
  br label %bb75
bb75:
  %t324 = load ptr, ptr %l1, !tbaa !29
  %t326 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3acursor_2eeat(ptr %v1, ptr %s11, ptr %t324, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d51, i32 0, i32 1) })
  store i1 %t326, ptr %l123
  br label %bb76
bb76:
  %t327 = load i1, ptr %l123, !tbaa !21
  %t328 = xor i1 %t327, true
  br i1 %t328, label %bb77, label %bb78
bb77:
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s0)
  %t331 = insertvalue { i32, i32 } zeroinitializer, i32 65536, 0
  store { i32, i32 } %t331, ptr %rv
  br label %ret
bb78:
  br label %bb79
bb79:
  %t332 = load ptr, ptr %l0, !tbaa !29
  %t334 = getelementptr %"compiler/generic:Program", ptr %t332, i32 0, i32 2
  %t335 = load i32, ptr %l7, !tbaa !23
  %t336 = load i32, ptr %l8, !tbaa !23
  %t340 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArray(ptr %v0, ptr %t334, i32 %t335, i32 %t336)
  store i32 %t340, ptr %l130
  br label %bb80
bb80:
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s0)
  %t341 = load i32, ptr %l130, !tbaa !23
  %t342 = insertvalue { i32, i32 } zeroinitializer, i32 %t341, 1
  store { i32, i32 } %t342, ptr %rv
  br label %ret
bb81:
  %t343 = load ptr, ptr %l1, !tbaa !29
  %t345 = getelementptr %"compiler/generic:cursor", ptr %t343, i32 0, i32 1
  %t346 = load i64, ptr %t345, !tbaa !24
  store i64 %t346, ptr %l9, !tbaa !24
  br label %bb82
bb82:
  %t348 = load ptr, ptr %l1, !tbaa !29
  %t350 = getelementptr %"compiler/generic:cursor", ptr %t348, i32 0, i32 1
  %t351 = load i64, ptr %t350, !tbaa !24
  %t352 = load ptr, ptr %l1, !tbaa !29
  %t354 = getelementptr %"compiler/generic:cursor", ptr %t352, i32 0, i32 0
  %t355 = load { i64, ptr }, ptr %t354, !tbaa !27
  %t357 = extractvalue { i64, ptr } %t355, 0
  %t360 = icmp slt i64 %t351, %t357
  br i1 %t360, label %bb83, label %bb84
bb83:
  %t362 = load ptr, ptr %l1, !tbaa !29
  %t364 = call i8 @compiler_2fgeneric_2ecompiler_2fgeneric_3acursor_2epeek(ptr %v1, ptr %t362)
  store i8 %t364, ptr %l141
  br label %bb85
bb84:
  store i1 false, ptr %l139, !tbaa !21
  br label %bb87
bb85:
  %t365 = load i8, ptr %l141, !tbaa !22
  %t366 = call i1 @compiler_2fgeneric_2enameChar(i8 %t365)
  store i1 %t366, ptr %l142
  br label %bb86
bb86:
  %t367 = load i1, ptr %l142, !tbaa !21
  store i1 %t367, ptr %l139, !tbaa !21
  br label %bb87
bb87:
  %t368 = load i1, ptr %l139, !tbaa !21
  %t369 = xor i1 %t368, true
  br i1 %t369, label %bb88, label %bb89
bb88:
  br label %bb92
bb89:
  br label %bb90
bb90:
  %t371 = load ptr, ptr %l1, !tbaa !29
  store ptr %t371, ptr %l144, !tbaa !29
  %t372 = load ptr, ptr %l144, !tbaa !29
  %t373 = getelementptr %"compiler/generic:cursor", ptr %t372, i32 0, i32 1
  %t374 = load i64, ptr %t373, !tbaa !24
  %t377 = add i64 %t374, 1
  %t379 = load ptr, ptr %l144, !tbaa !29
  %t380 = getelementptr %"compiler/generic:cursor", ptr %t379, i32 0, i32 1
  store i64 %t377, ptr %t380, !tbaa !24
  br label %bb91
bb91:
  br label %bb82
bb92:
  %t381 = load ptr, ptr %l1, !tbaa !29
  %t383 = getelementptr %"compiler/generic:cursor", ptr %t381, i32 0, i32 0
  %t384 = load { i64, ptr }, ptr %t383, !tbaa !27
  store { i64, ptr } %t384, ptr %l149, !tbaa !27
  %t385 = load i64, ptr %l9, !tbaa !24
  store i64 %t385, ptr %l150, !tbaa !24
  %t386 = load ptr, ptr %l1, !tbaa !29
  %t388 = getelementptr %"compiler/generic:cursor", ptr %t386, i32 0, i32 1
  %t389 = load i64, ptr %t388, !tbaa !24
  store i64 %t389, ptr %l152, !tbaa !24
  %t390 = load { i64, ptr }, ptr %l149, !tbaa !27
  %t391 = extractvalue { i64, ptr } %t390, 0
  store i64 %t391, ptr %l153, !tbaa !24
  %t392 = load i64, ptr %l150, !tbaa !24
  %t393 = icmp sge i64 %t392, 0
  br i1 %t393, label %bb93, label %bb94
bb93:
  %t395 = load i64, ptr %l150, !tbaa !24
  %t396 = load i64, ptr %l152, !tbaa !24
  %t397 = icmp sle i64 %t395, %t396
  br i1 %t397, label %bb95, label %bb96
bb94:
  call void @__olang_check_failed(ptr @olang_loc_22c778cd655270ba_6d5936a0bf98512e)
  unreachable
bb95:
  %t399 = load i64, ptr %l152, !tbaa !24
  %t400 = load i64, ptr %l153, !tbaa !24
  %t401 = icmp sle i64 %t399, %t400
  br i1 %t401, label %bb97, label %bb98
bb96:
  call void @__olang_check_failed(ptr @olang_loc_22c778cd655270ba_6d5936a0bf98512e)
  unreachable
bb97:
  %t403 = getelementptr { i64, ptr }, ptr %l149, i32 0, i32 1
  %t404 = load ptr, ptr %t403, !tbaa !27
  %t405 = load i64, ptr %l150, !tbaa !24
  %t406 = load i64, ptr %l152, !tbaa !24
  %t407 = getelementptr i8, ptr %t404, i64 %t405
  %t408 = sub i64 %t406, %t405
  %t409 = insertvalue { i64, ptr } undef, i64 %t408, 0
  %t410 = insertvalue { i64, ptr } %t409, ptr %t407, 1
  store { i64, ptr } %t410, ptr %l10, !tbaa !27
  %t412 = load ptr, ptr %l1, !tbaa !29
  %t414 = call i8 @compiler_2fgeneric_2ecompiler_2fgeneric_3acursor_2epeek(ptr %v1, ptr %t412)
  store i8 %t414, ptr %l159
  br label %bb99
bb98:
  call void @__olang_check_failed(ptr @olang_loc_22c778cd655270ba_6d5936a0bf98512e)
  unreachable
bb99:
  %t415 = load i8, ptr %l159, !tbaa !22
  %t416 = icmp ne i8 %t415, 58
  br i1 %t416, label %bb100, label %bb101
bb100:
  store %olang.scope zeroinitializer, ptr %s15
  %t418 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t420 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s15, { i64, ptr } %t418, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d52, i32 0, i32 1) })
  store i1 %t420, ptr %l162
  br label %bb102
bb101:
  br label %bb118
bb102:
  %t421 = load i1, ptr %l162, !tbaa !21
  br i1 %t421, label %bb103, label %bb104
bb103:
  %t422 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  call void @__olang_scope_close(ptr %s15)
  call void @__olang_scope_close(ptr %s0)
  %t424 = insertvalue { i32, i32 } zeroinitializer, i32 %t422, 1
  store { i32, i32 } %t424, ptr %rv
  br label %ret
bb104:
  br label %bb105
bb105:
  %t425 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t427 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s15, { i64, ptr } %t425, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d53, i32 0, i32 1) })
  store i1 %t427, ptr %l165
  br label %bb106
bb106:
  %t428 = load i1, ptr %l165, !tbaa !21
  br i1 %t428, label %bb107, label %bb108
bb107:
  %t429 = load i32, ptr @G_2ecompiler_2ftypes_2eDefaultErrT, !tbaa !23
  call void @__olang_scope_close(ptr %s15)
  call void @__olang_scope_close(ptr %s0)
  %t431 = insertvalue { i32, i32 } zeroinitializer, i32 %t429, 1
  store { i32, i32 } %t431, ptr %rv
  br label %ret
bb108:
  br label %bb109
bb109:
  %t432 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t434 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s15, { i64, ptr } %t432, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d54, i32 0, i32 1) })
  store i1 %t434, ptr %l168
  br label %bb110
bb110:
  %t435 = load i1, ptr %l168, !tbaa !21
  br i1 %t435, label %bb111, label %bb112
bb111:
  %t436 = load i32, ptr @G_2ecompiler_2ftypes_2eNoreturnT, !tbaa !23
  call void @__olang_scope_close(ptr %s15)
  call void @__olang_scope_close(ptr %s0)
  %t438 = insertvalue { i32, i32 } zeroinitializer, i32 %t436, 1
  store { i32, i32 } %t438, ptr %rv
  br label %ret
bb112:
  br label %bb113
bb113:
  %t439 = load ptr, ptr %l0, !tbaa !29
  %t441 = getelementptr %"compiler/generic:Program", ptr %t439, i32 0, i32 2
  %t442 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t445 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %v1, ptr %t441, { i64, ptr } %t442)
  store i32 %t445, ptr %l173
  br label %bb114
bb114:
  %t446 = load i32, ptr %l173, !tbaa !23
  store i32 %t446, ptr %l11, !tbaa !23
  %t447 = load i32, ptr %l11, !tbaa !23
  %t448 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t451 = icmp eq i32 %t447, %t448
  br i1 %t451, label %bb115, label %bb116
bb115:
  call void @__olang_scope_close(ptr %s15)
  call void @__olang_scope_close(ptr %s0)
  %t454 = insertvalue { i32, i32 } zeroinitializer, i32 65536, 0
  store { i32, i32 } %t454, ptr %rv
  br label %ret
bb116:
  br label %bb117
bb117:
  %t455 = load i32, ptr %l11, !tbaa !23
  call void @__olang_scope_close(ptr %s15)
  call void @__olang_scope_close(ptr %s0)
  %t457 = insertvalue { i32, i32 } zeroinitializer, i32 %t455, 1
  store { i32, i32 } %t457, ptr %rv
  br label %ret
bb118:
  %t458 = load ptr, ptr %l1, !tbaa !29
  store ptr %t458, ptr %l179, !tbaa !29
  %t459 = load ptr, ptr %l179, !tbaa !29
  %t460 = getelementptr %"compiler/generic:cursor", ptr %t459, i32 0, i32 1
  %t461 = load i64, ptr %t460, !tbaa !24
  %t464 = add i64 %t461, 1
  %t466 = load ptr, ptr %l179, !tbaa !29
  %t467 = getelementptr %"compiler/generic:cursor", ptr %t466, i32 0, i32 1
  store i64 %t464, ptr %t467, !tbaa !24
  %t468 = load ptr, ptr %l1, !tbaa !29
  %t470 = getelementptr %"compiler/generic:cursor", ptr %t468, i32 0, i32 1
  %t471 = load i64, ptr %t470, !tbaa !24
  store i64 %t471, ptr %l12, !tbaa !24
  br label %bb119
bb119:
  %t473 = load ptr, ptr %l1, !tbaa !29
  %t475 = getelementptr %"compiler/generic:cursor", ptr %t473, i32 0, i32 1
  %t476 = load i64, ptr %t475, !tbaa !24
  %t477 = load ptr, ptr %l1, !tbaa !29
  %t479 = getelementptr %"compiler/generic:cursor", ptr %t477, i32 0, i32 0
  %t480 = load { i64, ptr }, ptr %t479, !tbaa !27
  %t482 = extractvalue { i64, ptr } %t480, 0
  %t485 = icmp slt i64 %t476, %t482
  br i1 %t485, label %bb120, label %bb121
bb120:
  %t487 = load ptr, ptr %l1, !tbaa !29
  %t489 = call i8 @compiler_2fgeneric_2ecompiler_2fgeneric_3acursor_2epeek(ptr %v1, ptr %t487)
  store i8 %t489, ptr %l193
  br label %bb122
bb121:
  store i1 false, ptr %l191, !tbaa !21
  br label %bb124
bb122:
  %t490 = load i8, ptr %l193, !tbaa !22
  %t491 = call i1 @compiler_2fgeneric_2enameChar(i8 %t490)
  store i1 %t491, ptr %l194
  br label %bb123
bb123:
  %t492 = load i1, ptr %l194, !tbaa !21
  store i1 %t492, ptr %l191, !tbaa !21
  br label %bb124
bb124:
  %t493 = load i1, ptr %l191, !tbaa !21
  br i1 %t493, label %bb125, label %bb126
bb125:
  %t494 = load ptr, ptr %l1, !tbaa !29
  %t496 = call i8 @compiler_2fgeneric_2ecompiler_2fgeneric_3acursor_2epeek(ptr %v1, ptr %t494)
  store i8 %t496, ptr %l197
  br label %bb127
bb126:
  store i1 false, ptr %l195, !tbaa !21
  br label %bb128
bb127:
  %t497 = load i8, ptr %l197, !tbaa !22
  %t498 = icmp ne i8 %t497, 47
  store i1 %t498, ptr %l195, !tbaa !21
  br label %bb128
bb128:
  %t500 = load i1, ptr %l195, !tbaa !21
  br i1 %t500, label %bb129, label %bb130
bb129:
  %t501 = load ptr, ptr %l1, !tbaa !29
  %t503 = call i8 @compiler_2fgeneric_2ecompiler_2fgeneric_3acursor_2epeek(ptr %v1, ptr %t501)
  store i8 %t503, ptr %l201
  br label %bb131
bb130:
  store i1 false, ptr %l199, !tbaa !21
  br label %bb132
bb131:
  %t504 = load i8, ptr %l201, !tbaa !22
  %t505 = icmp ne i8 %t504, 46
  store i1 %t505, ptr %l199, !tbaa !21
  br label %bb132
bb132:
  %t507 = load i1, ptr %l199, !tbaa !21
  %t508 = xor i1 %t507, true
  br i1 %t508, label %bb133, label %bb134
bb133:
  br label %bb137
bb134:
  br label %bb135
bb135:
  %t510 = load ptr, ptr %l1, !tbaa !29
  store ptr %t510, ptr %l204, !tbaa !29
  %t511 = load ptr, ptr %l204, !tbaa !29
  %t512 = getelementptr %"compiler/generic:cursor", ptr %t511, i32 0, i32 1
  %t513 = load i64, ptr %t512, !tbaa !24
  %t516 = add i64 %t513, 1
  %t518 = load ptr, ptr %l204, !tbaa !29
  %t519 = getelementptr %"compiler/generic:cursor", ptr %t518, i32 0, i32 1
  store i64 %t516, ptr %t519, !tbaa !24
  br label %bb136
bb136:
  br label %bb119
bb137:
  %t520 = load ptr, ptr %l0, !tbaa !29
  store ptr %t520, ptr %l209, !tbaa !29
  %t521 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t521, ptr %l210, !tbaa !27
  %t522 = load ptr, ptr %l1, !tbaa !29
  %t524 = getelementptr %"compiler/generic:cursor", ptr %t522, i32 0, i32 0
  %t525 = load { i64, ptr }, ptr %t524, !tbaa !27
  store { i64, ptr } %t525, ptr %l212, !tbaa !27
  %t526 = load i64, ptr %l12, !tbaa !24
  store i64 %t526, ptr %l213, !tbaa !24
  %t527 = load ptr, ptr %l1, !tbaa !29
  %t529 = getelementptr %"compiler/generic:cursor", ptr %t527, i32 0, i32 1
  %t530 = load i64, ptr %t529, !tbaa !24
  store i64 %t530, ptr %l215, !tbaa !24
  %t531 = load { i64, ptr }, ptr %l212, !tbaa !27
  %t532 = extractvalue { i64, ptr } %t531, 0
  store i64 %t532, ptr %l216, !tbaa !24
  %t533 = load i64, ptr %l213, !tbaa !24
  %t534 = icmp sge i64 %t533, 0
  br i1 %t534, label %bb138, label %bb139
bb138:
  %t536 = load i64, ptr %l213, !tbaa !24
  %t537 = load i64, ptr %l215, !tbaa !24
  %t538 = icmp sle i64 %t536, %t537
  br i1 %t538, label %bb140, label %bb141
bb139:
  call void @__olang_check_failed(ptr @olang_loc_55983e17b45d1397_8723e16cd5d53a2b)
  unreachable
bb140:
  %t540 = load i64, ptr %l215, !tbaa !24
  %t541 = load i64, ptr %l216, !tbaa !24
  %t542 = icmp sle i64 %t540, %t541
  br i1 %t542, label %bb142, label %bb143
bb141:
  call void @__olang_check_failed(ptr @olang_loc_55983e17b45d1397_8723e16cd5d53a2b)
  unreachable
bb142:
  %t544 = getelementptr { i64, ptr }, ptr %l212, i32 0, i32 1
  %t545 = load ptr, ptr %t544, !tbaa !27
  %t546 = load i64, ptr %l213, !tbaa !24
  %t547 = load i64, ptr %l215, !tbaa !24
  %t548 = getelementptr i8, ptr %t545, i64 %t546
  %t549 = sub i64 %t547, %t546
  %t550 = insertvalue { i64, ptr } undef, i64 %t549, 0
  %t551 = insertvalue { i64, ptr } %t550, ptr %t548, 1
  %t552 = load ptr, ptr %l209, !tbaa !29
  %t553 = load { i64, ptr }, ptr %l210, !tbaa !27
  %t555 = call { i32, i32 } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFindDecl(ptr %v0, ptr %v1, ptr %v1, ptr %t552, { i64, ptr } %t553, { i64, ptr } %t551)
  %t556 = extractvalue { i32, i32 } %t555, 1
  %t557 = extractvalue { i32, i32 } %t555, 0
  store i32 %t557, ptr %l222
  %t558 = icmp ne i32 %t557, 0
  br i1 %t558, label %bb145, label %ok.559, !prof !99
ok.559:
  store i32 %t556, ptr %l221
  br label %bb144
bb143:
  call void @__olang_check_failed(ptr @olang_loc_55983e17b45d1397_8723e16cd5d53a2b)
  unreachable
bb144:
  %t560 = load i32, ptr %l221, !tbaa !23
  store i32 %t560, ptr %l208, !tbaa !23
  br label %bb146
bb145:
  %t561 = load i32, ptr %l222, !tbaa !23
  %t562 = lshr i32 %t561, 16
  %t563 = and i32 %t561, 65535
  %t564 = icmp eq i32 %t562, 1
  %t565 = select i1 %t564, i32 2, i32 0
  %t566 = icmp eq i32 %t561, 0
  %t567 = shl i32 %t565, 16
  %t568 = or i32 %t567, %t563
  %t569 = select i1 %t566, i32 0, i32 %t568
  call void @__olang_scope_close(ptr %s0)
  %t571 = insertvalue { i32, i32 } zeroinitializer, i32 %t569, 0
  store { i32, i32 } %t571, ptr %rv
  br label %ret
bb146:
  %t572 = load i32, ptr %l208, !tbaa !23
  store i32 %t572, ptr %l13, !tbaa !23
  %t573 = load ptr, ptr %l1, !tbaa !29
  %t575 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3acursor_2eeat(ptr %v1, ptr %s0, ptr %t573, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d55, i32 0, i32 1) })
  store i1 %t575, ptr %l225
  br label %bb147
bb147:
  %t576 = load i1, ptr %l225, !tbaa !21
  %t577 = xor i1 %t576, true
  br i1 %t577, label %bb148, label %bb149
bb148:
  %t579 = load ptr, ptr %l0, !tbaa !29
  %t580 = load i32, ptr %l13, !tbaa !23
  %t583 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstance(ptr %v0, ptr %t579, i32 %t580, i32 0)
  store i32 %t583, ptr %l229
  br label %bb150
bb149:
  br label %bb151
bb150:
  call void @__olang_scope_close(ptr %s0)
  %t584 = load i32, ptr %l229, !tbaa !23
  %t585 = insertvalue { i32, i32 } zeroinitializer, i32 %t584, 1
  store { i32, i32 } %t585, ptr %rv
  br label %ret
bb151:
  %t586 = load ptr, ptr %l0, !tbaa !29
  %t587 = load i32, ptr %l13, !tbaa !23
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2edeclVars(ptr %v0, ptr %t586, i32 %t587)
  br label %bb152
bb152:
  %t590 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t590, ptr %l232
  br label %bb153
bb153:
  %t591 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l232
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t591, ptr %l14
  br label %bb154
bb154:
  store %olang.scope zeroinitializer, ptr %s22
  %t593 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %l14)
  store i64 %t593, ptr %l234
  br label %bb155
bb155:
  %t594 = load i64, ptr %l234, !tbaa !24
  store i64 %t594, ptr %l235, !tbaa !24
  %t596 = load ptr, ptr %l0, !tbaa !29
  %t598 = getelementptr %"compiler/generic:Program", ptr %t596, i32 0, i32 2
  %t599 = load i32, ptr %l13, !tbaa !23
  %t602 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclParams(ptr %v0, ptr %t598, i32 %t599)
  store i64 %t602, ptr %l239
  br label %bb156
bb156:
  %t603 = load i64, ptr %l235, !tbaa !24
  %t604 = load i64, ptr %l239, !tbaa !24
  %t605 = icmp sge i64 %t603, %t604
  br i1 %t605, label %bb157, label %bb158
bb157:
  call void @__olang_scope_close(ptr %s22)
  call void @__olang_scope_close(ptr %s0)
  %t608 = insertvalue { i32, i32 } zeroinitializer, i32 65536, 0
  store { i32, i32 } %t608, ptr %rv
  br label %ret
bb158:
  br label %bb159
bb159:
  store ptr %l14, ptr %l242, !tbaa !29
  %t609 = load ptr, ptr %l0, !tbaa !29
  %t610 = load ptr, ptr %l1, !tbaa !29
  %t613 = call { i32, i32 } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ecanonType(ptr %v0, ptr %v1, ptr %t609, ptr %t610)
  %t614 = extractvalue { i32, i32 } %t613, 1
  %t615 = extractvalue { i32, i32 } %t613, 0
  store i32 %t615, ptr %l247
  %t616 = icmp ne i32 %t615, 0
  br i1 %t616, label %bb161, label %ok.617, !prof !99
ok.617:
  store i32 %t614, ptr %l246
  br label %bb160
bb160:
  %t618 = load i32, ptr %l246, !tbaa !23
  store i32 %t618, ptr %l243, !tbaa !23
  br label %bb162
bb161:
  %t619 = load i32, ptr %l247, !tbaa !23
  %t620 = lshr i32 %t619, 16
  %t621 = and i32 %t619, 65535
  %t622 = icmp eq i32 %t620, 1
  %t623 = select i1 %t622, i32 1, i32 0
  %t624 = icmp eq i32 %t620, 2
  %t625 = select i1 %t624, i32 2, i32 %t623
  %t626 = icmp eq i32 %t619, 0
  %t627 = shl i32 %t625, 16
  %t628 = or i32 %t627, %t621
  %t629 = select i1 %t626, i32 0, i32 %t628
  call void @__olang_scope_close(ptr %s22)
  call void @__olang_scope_close(ptr %s0)
  %t631 = insertvalue { i32, i32 } zeroinitializer, i32 %t629, 0
  store { i32, i32 } %t631, ptr %rv
  br label %ret
bb162:
  %t632 = load ptr, ptr %l242, !tbaa !29
  %t633 = load i32, ptr %l243, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %t632, i32 %t633)
  br label %bb163
bb163:
  %t634 = load ptr, ptr %l1, !tbaa !29
  %t636 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3acursor_2eeat(ptr %v1, ptr %s22, ptr %t634, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d56, i32 0, i32 1) })
  store i1 %t636, ptr %l250
  br label %bb164
bb164:
  %t637 = load i1, ptr %l250, !tbaa !21
  br i1 %t637, label %bb165, label %bb166
bb165:
  call void @__olang_scope_close(ptr %s22)
  br label %bb173
bb166:
  br label %bb167
bb167:
  %t638 = load ptr, ptr %l1, !tbaa !29
  %t640 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3acursor_2eeat(ptr %v1, ptr %s22, ptr %t638, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d57, i32 0, i32 1) })
  store i1 %t640, ptr %l252
  br label %bb168
bb168:
  %t641 = load i1, ptr %l252, !tbaa !21
  %t642 = xor i1 %t641, true
  br i1 %t642, label %bb169, label %bb170
bb169:
  call void @__olang_scope_close(ptr %s22)
  call void @__olang_scope_close(ptr %s0)
  %t645 = insertvalue { i32, i32 } zeroinitializer, i32 65536, 0
  store { i32, i32 } %t645, ptr %rv
  br label %ret
bb170:
  br label %bb171
bb171:
  call void @__olang_scope_close(ptr %s22)
  br label %bb172
bb172:
  br label %bb154
bb173:
  %t646 = load ptr, ptr %l0, !tbaa !29
  store ptr %t646, ptr %l255, !tbaa !29
  %t647 = load i32, ptr %l13, !tbaa !23
  store i32 %t647, ptr %l256, !tbaa !23
  %t648 = load ptr, ptr %l0, !tbaa !29
  %t650 = getelementptr %"compiler/generic:Program", ptr %t648, i32 0, i32 2
  store ptr %t650, ptr %l258, !tbaa !29
  %t652 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eToArray_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %s0, ptr %l14)
  store { i64, ptr } %t652, ptr %l260
  br label %bb174
bb174:
  %t653 = load ptr, ptr %l258, !tbaa !29
  %t654 = load { i64, ptr }, ptr %l260, !tbaa !27
  %t655 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s0, ptr %t653, { i64, ptr } %t654)
  store i32 %t655, ptr %l261
  br label %bb175
bb175:
  %t656 = load ptr, ptr %l255, !tbaa !29
  %t657 = load i32, ptr %l256, !tbaa !23
  %t658 = load i32, ptr %l261, !tbaa !23
  %t659 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstance(ptr %v0, ptr %t656, i32 %t657, i32 %t658)
  store i32 %t659, ptr %l262
  br label %bb176
bb176:
  call void @__olang_scope_close(ptr %s0)
  %t660 = load i32, ptr %l262, !tbaa !23
  %t661 = insertvalue { i32, i32 } zeroinitializer, i32 %t660, 1
  store { i32, i32 } %t661, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i32 }, ptr %rv
  ret { i32, i32 } %rr
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2econstOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, %"compiler/generic:folded" %a2, i32 %a3, ptr %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/generic:folded"
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca i32
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i1
  %l10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca %"compiler/generic:ConstAsk"
  %l13 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9"
  %l17 = alloca %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa"
  %l24 = alloca ptr
  %l25 = alloca i32
  %l29 = alloca i64
  %l30 = alloca i32
  %l34 = alloca i1
  %l38 = alloca i1
  %l42 = alloca i1
  %l45 = alloca i1
  %l49 = alloca %"compiler/generic:folded"
  %l53 = alloca i1
  %l58 = alloca %"compiler/source:Span"
  %l60 = alloca ptr
  %l61 = alloca i64
  %l73 = alloca i32
  %l75 = alloca ptr
  %l79 = alloca i64
  %l87 = alloca %"compiler/generic:pattern"
  %l92 = alloca i1
  %l99 = alloca { i64, ptr }
  %l104 = alloca i1
  %l105 = alloca i64
  %l109 = alloca i64
  %l110 = alloca i32
  %l115 = alloca i32
  %l117 = alloca ptr
  %l118 = alloca i32
  %l122 = alloca i64
  %l123 = alloca i32
  %l126 = alloca i64
  %l128 = alloca i64
  %l133 = alloca %"compiler/generic:ConstAsk"
  %l136 = alloca i1
  %l144 = alloca i64
  %l150 = alloca i64
  %l156 = alloca %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9"
  %l157 = alloca %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa"
  %l159 = alloca %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa"
  %l160 = alloca i32
  %l162 = alloca i1
  %l165 = alloca { i64, ptr }
  %l168 = alloca { i64, ptr }
  %l175 = alloca ptr
  %l185 = alloca %"compiler/generic:ConstAsk"
  %l187 = alloca i32
  %s2 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store %"compiler/generic:folded" %a2, ptr %l2
  store i32 %a3, ptr %l3
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/generic:folded", ptr %l2, i32 0, i32 0
  %t2 = load i64, ptr %t1, !tbaa !24
  %t3 = load i64, ptr @G_2ecompiler_2fgeneric_2eFolded, !tbaa !24
  %t6 = icmp eq i64 %t2, %t3
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/generic:Program", ptr %t8, i32 0, i32 2
  store ptr %t10, ptr %l24, !tbaa !29
  %t11 = load i32, ptr %l3, !tbaa !23
  store i32 %t11, ptr %l25, !tbaa !23
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/generic:folded", ptr %l2, i32 0, i32 1
  %t14 = load i64, ptr %t13, !tbaa !24
  %t15 = load i32, ptr %l3, !tbaa !23
  %t19 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ewrap(ptr %v0, ptr %t12, i64 %t14, i32 %t15)
  store i64 %t19, ptr %l29
  br label %bb3
bb2:
  br label %bb5
bb3:
  %t20 = load ptr, ptr %l24, !tbaa !29
  %t21 = load i32, ptr %l25, !tbaa !23
  %t22 = load i64, ptr %l29, !tbaa !24
  %t23 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConst(ptr %v0, ptr %t20, i32 %t21, i64 %t22)
  store i32 %t23, ptr %l30
  br label %bb4
bb4:
  %t24 = load i32, ptr %l30, !tbaa !23
  store i32 %t24, ptr %rv
  br label %ret
bb5:
  %t25 = getelementptr %"compiler/generic:folded", ptr %l2, i32 0, i32 0
  %t26 = load i64, ptr %t25, !tbaa !24
  %t27 = load i64, ptr @G_2ecompiler_2fgeneric_2eUnfolded, !tbaa !24
  %t30 = icmp eq i64 %t26, %t27
  br i1 %t30, label %bb6, label %bb7
bb6:
  %t32 = load ptr, ptr %l4, !tbaa !29
  %t34 = icmp eq ptr %t32, null
  %t36 = xor i1 %t34, true
  store i1 %t36, ptr %l34, !tbaa !21
  br label %bb8
bb7:
  store i1 false, ptr %l34, !tbaa !21
  br label %bb8
bb8:
  %t38 = load i1, ptr %l34, !tbaa !21
  br i1 %t38, label %bb9, label %bb10
bb9:
  %t39 = load ptr, ptr %l1, !tbaa !29
  %t41 = getelementptr %"compiler/generic:Context", ptr %t39, i32 0, i32 1
  %t42 = load i64, ptr %t41, !tbaa !24
  %t44 = icmp sge i64 %t42, 0
  store i1 %t44, ptr %l38, !tbaa !21
  br label %bb11
bb10:
  store i1 false, ptr %l38, !tbaa !21
  br label %bb11
bb11:
  %t46 = load i1, ptr %l38, !tbaa !21
  br i1 %t46, label %bb12, label %bb13
bb12:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t48 = load ptr, ptr %l1, !tbaa !29
  %t51 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2evarsBound(ptr %v0, ptr %v1, ptr %t47, ptr %t48)
  store i1 %t51, ptr %l45
  br label %bb14
bb13:
  store i1 false, ptr %l42, !tbaa !21
  br label %bb15
bb14:
  %t52 = load i1, ptr %l45, !tbaa !21
  %t53 = xor i1 %t52, true
  store i1 %t53, ptr %l42, !tbaa !21
  br label %bb15
bb15:
  %t55 = load i1, ptr %l42, !tbaa !21
  br i1 %t55, label %bb16, label %bb17
bb16:
  store %olang.scope zeroinitializer, ptr %s2
  %t56 = load i64, ptr @G_2ecompiler_2fgeneric_2ePending, !tbaa !24
  %t57 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t60 = call %"compiler/generic:folded" @compiler_2fgeneric_3afolded_2ector(ptr %s2, i64 %t56, i64 0, i32 %t57)
  store %"compiler/generic:folded" %t60, ptr %l49
  br label %bb18
bb17:
  br label %bb19
bb18:
  %t61 = load %"compiler/generic:folded", ptr %l49
  store %"compiler/generic:folded" %t61, ptr %l2
  call void @__olang_scope_close(ptr %s2)
  br label %bb19
bb19:
  %t62 = getelementptr %"compiler/generic:folded", ptr %l2, i32 0, i32 0
  %t63 = load i64, ptr %t62, !tbaa !24
  %t64 = load i64, ptr @G_2ecompiler_2fgeneric_2ePending, !tbaa !24
  %t67 = icmp eq i64 %t63, %t64
  br i1 %t67, label %bb20, label %bb21
bb20:
  %t69 = load ptr, ptr %l4, !tbaa !29
  %t71 = icmp eq ptr %t69, null
  %t73 = xor i1 %t71, true
  store i1 %t73, ptr %l53, !tbaa !21
  br label %bb22
bb21:
  store i1 false, ptr %l53, !tbaa !21
  br label %bb22
bb22:
  %t75 = load i1, ptr %l53, !tbaa !21
  br i1 %t75, label %bb23, label %bb24
bb23:
  %t76 = load ptr, ptr %l4, !tbaa !29
  %t78 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t76)
  store %"compiler/source:Span" %t78, ptr %l58
  br label %bb25
bb24:
  br label %bb32
bb25:
  %t79 = load %"compiler/source:Span", ptr %l58
  store %"compiler/source:Span" %t79, ptr %l5
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t82 = getelementptr %"compiler/generic:Program", ptr %t80, i32 0, i32 2
  store ptr %t82, ptr %l60, !tbaa !29
  %t83 = call ptr @__olang_scope_hold(ptr %v0)
  %t84 = ptrtoint ptr %t83 to i64
  store i64 %t84, ptr %l61, !tbaa !24
  %t85 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t85, label %bb26, label %bb27
bb26:
  %t87 = call ptr @__olang_region_make(ptr %v0)
  %t88 = ptrtoint ptr %t87 to i64
  store i64 %t88, ptr %l61, !tbaa !24
  br label %bb27
bb27:
  %t89 = load ptr, ptr %l1, !tbaa !29
  %t91 = getelementptr %"compiler/generic:Context", ptr %t89, i32 0, i32 1
  %t92 = load i64, ptr %t91, !tbaa !24
  %t93 = load ptr, ptr %l1, !tbaa !29
  %t95 = getelementptr %"compiler/generic:Context", ptr %t93, i32 0, i32 0
  %t96 = load i64, ptr %t95, !tbaa !24
  %t97 = getelementptr %"compiler/source:Span", ptr %l5, i32 0, i32 0
  %t98 = load i32, ptr %t97, !tbaa !23
  %t99 = getelementptr %"compiler/source:Span", ptr %l5, i32 0, i32 1
  %t100 = load i32, ptr %t99, !tbaa !23
  %t101 = load i32, ptr %l3, !tbaa !23
  %t103 = sext i32 %t101 to i64
  %t105 = call i64 @__olang_fmt_i64(ptr null, i64 %t92)
  %t106 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d58, i32 0, i32 1) }, 1
  %t107 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d58, i32 0, i32 1) }, 0
  %t108 = add i64 %t105, %t107
  %t110 = call i64 @__olang_fmt_i64(ptr null, i64 %t96)
  %t111 = add i64 %t108, %t110
  %t112 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d58, i32 0, i32 1) }, 1
  %t113 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d58, i32 0, i32 1) }, 0
  %t114 = add i64 %t111, %t113
  %t116 = sext i32 %t98 to i64
  %t117 = call i64 @__olang_fmt_i64(ptr null, i64 %t116)
  %t118 = add i64 %t114, %t117
  %t119 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d58, i32 0, i32 1) }, 1
  %t120 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d58, i32 0, i32 1) }, 0
  %t121 = add i64 %t118, %t120
  %t123 = sext i32 %t100 to i64
  %t124 = call i64 @__olang_fmt_i64(ptr null, i64 %t123)
  %t125 = add i64 %t121, %t124
  %t126 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d58, i32 0, i32 1) }, 1
  %t127 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d58, i32 0, i32 1) }, 0
  %t128 = add i64 %t125, %t127
  %t130 = call i64 @__olang_fmt_i64(ptr null, i64 %t103)
  %t131 = add i64 %t128, %t130
  %t132 = load i64, ptr %l61
  %t133 = inttoptr i64 %t132 to ptr
  %t134 = call ptr @__olang_held_alloc(ptr %t133, i64 %t131)
  %t135 = call i64 @__olang_fmt_i64(ptr %t134, i64 %t92)
  %t136 = getelementptr i8, ptr %t134, i64 %t105
  call void @olang_textcopy(ptr %t136, ptr %t106, i64 %t107)
  %t137 = getelementptr i8, ptr %t136, i64 %t107
  %t138 = call i64 @__olang_fmt_i64(ptr %t137, i64 %t96)
  %t139 = getelementptr i8, ptr %t137, i64 %t110
  call void @olang_textcopy(ptr %t139, ptr %t112, i64 %t113)
  %t140 = getelementptr i8, ptr %t139, i64 %t113
  %t141 = call i64 @__olang_fmt_i64(ptr %t140, i64 %t116)
  %t142 = getelementptr i8, ptr %t140, i64 %t117
  call void @olang_textcopy(ptr %t142, ptr %t119, i64 %t120)
  %t143 = getelementptr i8, ptr %t142, i64 %t120
  %t144 = call i64 @__olang_fmt_i64(ptr %t143, i64 %t123)
  %t145 = getelementptr i8, ptr %t143, i64 %t124
  call void @olang_textcopy(ptr %t145, ptr %t126, i64 %t127)
  %t146 = getelementptr i8, ptr %t145, i64 %t127
  %t147 = call i64 @__olang_fmt_i64(ptr %t146, i64 %t103)
  %t148 = insertvalue { i64, ptr } undef, i64 %t131, 0
  %t149 = insertvalue { i64, ptr } %t148, ptr %t134, 1
  %t151 = load ptr, ptr %l60, !tbaa !29
  %t153 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstExpr(ptr %v0, ptr %v0, ptr %t151, { i64, ptr } %t149)
  store i32 %t153, ptr %l73
  br label %bb28
bb28:
  %t154 = load i32, ptr %l73, !tbaa !23
  store i32 %t154, ptr %l6, !tbaa !23
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t157 = getelementptr %"compiler/generic:Program", ptr %t155, i32 0, i32 30
  store ptr %t157, ptr %l75, !tbaa !29
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t160 = getelementptr %"compiler/generic:Program", ptr %t158, i32 0, i32 2
  %t161 = load i32, ptr %l6, !tbaa !23
  %t164 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eA(ptr %v0, ptr %t160, i32 %t161)
  store i64 %t164, ptr %l79
  br label %bb29
bb29:
  %t165 = load ptr, ptr %l4, !tbaa !29
  %t167 = load ptr, ptr %l1, !tbaa !29
  %t169 = getelementptr %"compiler/generic:Context", ptr %t167, i32 0, i32 0
  %t170 = load i64, ptr %t169, !tbaa !24
  %t171 = load ptr, ptr %l1, !tbaa !29
  %t173 = getelementptr %"compiler/generic:Context", ptr %t171, i32 0, i32 1
  %t174 = load i64, ptr %t173, !tbaa !24
  %t175 = load i32, ptr %l3, !tbaa !23
  %t180 = call %"compiler/generic:pattern" @compiler_2fgeneric_3apattern_2ector(ptr %v2, ptr %v0, ptr %v0, ptr %t165, i64 %t170, i64 %t174, i32 %t175, ptr null)
  store %"compiler/generic:pattern" %t180, ptr %l87
  br label %bb30
bb30:
  %t181 = load ptr, ptr %l75, !tbaa !29
  %t182 = load i64, ptr %l79, !tbaa !24
  %t183 = load %"compiler/generic:pattern", ptr %l87
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fgeneric_3apattern__Hf2f2cd44709958e8fc0de9f437e62e6b(ptr %v0, ptr %v0, ptr %t181, i64 %t182, %"compiler/generic:pattern" %t183)
  br label %bb31
bb31:
  %t184 = load i32, ptr %l6, !tbaa !23
  store i32 %t184, ptr %rv
  br label %ret
bb32:
  %t186 = getelementptr %"compiler/generic:folded", ptr %l2, i32 0, i32 0
  %t187 = load i64, ptr %t186, !tbaa !24
  %t188 = load i64, ptr @G_2ecompiler_2fgeneric_2eUnfolded, !tbaa !24
  %t191 = icmp eq i64 %t187, %t188
  br i1 %t191, label %bb33, label %bb34
bb33:
  %t193 = load ptr, ptr %l4, !tbaa !29
  %t195 = icmp eq ptr %t193, null
  %t197 = xor i1 %t195, true
  store i1 %t197, ptr %l92, !tbaa !21
  br label %bb35
bb34:
  store i1 false, ptr %l92, !tbaa !21
  br label %bb35
bb35:
  %t199 = load i1, ptr %l92, !tbaa !21
  br i1 %t199, label %bb36, label %bb37
bb36:
  %t200 = load ptr, ptr %l0, !tbaa !29
  %t201 = load ptr, ptr %l1, !tbaa !29
  %t202 = load ptr, ptr %l4, !tbaa !29
  %t206 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eLengthKey(ptr %v0, ptr %v1, ptr %v2, ptr %v0, ptr %t200, ptr %t201, ptr %t202)
  store { i64, ptr } %t206, ptr %l99
  br label %bb38
bb37:
  br label %bb87
bb38:
  %t207 = load { i64, ptr }, ptr %l99, !tbaa !27
  store { i64, ptr } %t207, ptr %l7, !tbaa !27
  %t209 = load ptr, ptr %l0, !tbaa !29
  %t211 = getelementptr %"compiler/generic:Program", ptr %t209, i32 0, i32 63
  %t212 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t215 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9b83f66eba65594537030636cb0b52b7(ptr %v0, ptr %v0, ptr %t211, { i64, ptr } %t212)
  store i1 %t215, ptr %l104
  br label %bb39
bb39:
  %t216 = load i1, ptr %l104, !tbaa !21
  br i1 %t216, label %bb40, label %bb41
bb40:
  %t217 = load ptr, ptr %l0, !tbaa !29
  %t219 = getelementptr %"compiler/generic:Program", ptr %t217, i32 0, i32 63
  %t220 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t223 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9162e3b7f03fcbf954b681204d5f6cca(ptr %v0, ptr %v0, ptr %t219, { i64, ptr } %t220)
  %t224 = extractvalue { i32, i64 } %t223, 1
  %t225 = extractvalue { i32, i64 } %t223, 0
  store i32 %t225, ptr %l110
  %t226 = icmp ne i32 %t225, 0
  br i1 %t226, label %bb43, label %ok.227, !prof !99
ok.227:
  store i64 %t224, ptr %l109
  br label %bb42
bb41:
  br label %bb51
bb42:
  %t228 = load i64, ptr %l109, !tbaa !24
  store i64 %t228, ptr %l105, !tbaa !24
  br label %bb45
bb43:
  br label %bb44
bb44:
  %t229 = load i64, ptr @G_2ecompiler_2fgeneric_2eRunTimeLength, !tbaa !24
  store i64 %t229, ptr %l105, !tbaa !24
  br label %bb45
bb45:
  %t231 = load i64, ptr %l105, !tbaa !24
  store i64 %t231, ptr %l8, !tbaa !24
  %t232 = load i64, ptr %l8, !tbaa !24
  %t233 = load i64, ptr @G_2ecompiler_2fgeneric_2eRunTimeLength, !tbaa !24
  %t236 = icmp eq i64 %t232, %t233
  br i1 %t236, label %bb46, label %bb47
bb46:
  store i32 0, ptr %l115, !tbaa !23
  br label %bb50
bb47:
  %t238 = load ptr, ptr %l0, !tbaa !29
  %t240 = getelementptr %"compiler/generic:Program", ptr %t238, i32 0, i32 2
  store ptr %t240, ptr %l117, !tbaa !29
  %t241 = load i32, ptr %l3, !tbaa !23
  store i32 %t241, ptr %l118, !tbaa !23
  %t242 = load ptr, ptr %l0, !tbaa !29
  %t243 = load i64, ptr %l8, !tbaa !24
  %t244 = load i32, ptr %l3, !tbaa !23
  %t248 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ewrap(ptr %v0, ptr %t242, i64 %t243, i32 %t244)
  store i64 %t248, ptr %l122
  br label %bb48
bb48:
  %t249 = load ptr, ptr %l117, !tbaa !29
  %t250 = load i32, ptr %l118, !tbaa !23
  %t251 = load i64, ptr %l122, !tbaa !24
  %t252 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConst(ptr %v0, ptr %t249, i32 %t250, i64 %t251)
  store i32 %t252, ptr %l123
  br label %bb49
bb49:
  %t253 = load i32, ptr %l123, !tbaa !23
  store i32 %t253, ptr %l115, !tbaa !23
  br label %bb50
bb50:
  %t254 = load i32, ptr %l115, !tbaa !23
  store i32 %t254, ptr %rv
  br label %ret
bb51:
  store i1 false, ptr %l9, !tbaa !21
  %t255 = load ptr, ptr %l0, !tbaa !29
  %t257 = getelementptr %"compiler/generic:Program", ptr %t255, i32 0, i32 64
  store ptr %t257, ptr %l10, !tbaa !29
  store i64 0, ptr %l11, !tbaa !24
  br label %bb52
bb52:
  %t259 = load i64, ptr %l11, !tbaa !24
  store i64 %t259, ptr %l126, !tbaa !24
  %t260 = load ptr, ptr %l10, !tbaa !29
  %t262 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3aConstAsk_3e_2eLen_H192b02349624a37821a23e7def80c714(ptr %v0, ptr %t260)
  store i64 %t262, ptr %l128
  br label %bb53
bb53:
  %t263 = load i64, ptr %l126, !tbaa !24
  %t264 = load i64, ptr %l128, !tbaa !24
  %t265 = icmp slt i64 %t263, %t264
  %t267 = xor i1 %t265, true
  br i1 %t267, label %bb54, label %bb55
bb54:
  br label %bb63
bb55:
  br label %bb56
bb56:
  %t269 = load ptr, ptr %l10, !tbaa !29
  %t270 = load i64, ptr %l11, !tbaa !24
  %t273 = call %"compiler/generic:ConstAsk" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3aConstAsk_3e_2eAt__H3f4459851a287fa27378a94ef8fff763(ptr %v0, ptr %v0, ptr %t269, i64 %t270)
  store %"compiler/generic:ConstAsk" %t273, ptr %l133
  br label %bb57
bb57:
  %t274 = load %"compiler/generic:ConstAsk", ptr %l133
  store %"compiler/generic:ConstAsk" %t274, ptr %l12
  %t275 = getelementptr %"compiler/generic:ConstAsk", ptr %l12, i32 0, i32 6
  %t276 = load { i64, ptr }, ptr %t275, !tbaa !27
  %t277 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t280 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v0, { i64, ptr } %t276, { i64, ptr } %t277)
  store i1 %t280, ptr %l136
  br label %bb58
bb58:
  %t281 = load i1, ptr %l136, !tbaa !21
  br i1 %t281, label %bb59, label %bb60
bb59:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb61
bb60:
  br label %bb61
bb61:
  br label %bb62
bb62:
  %t282 = load i64, ptr %l11, !tbaa !24
  %t285 = add i64 %t282, 1
  store i64 %t285, ptr %l11, !tbaa !24
  br label %bb52
bb63:
  %t287 = load i1, ptr %l9, !tbaa !21
  %t289 = xor i1 %t287, true
  br i1 %t289, label %bb64, label %bb65
bb64:
  %t291 = load ptr, ptr %l1, !tbaa !29
  %t293 = getelementptr %"compiler/generic:Context", ptr %t291, i32 0, i32 2
  %t295 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_H0e73c22773457b60eb954c2c4a2643e9(ptr %v1, ptr %t293)
  store i64 %t295, ptr %l144
  br label %bb66
bb65:
  br label %bb86
bb66:
  %t296 = load i64, ptr %l144, !tbaa !24
  %t297 = icmp sge i64 %t296, 0
  br i1 %t297, label %bb67, label %bb68
bb67:
  %t299 = load i64, ptr %l144, !tbaa !24
  %t300 = icmp sle i64 %t299, 2305843009213693951
  br i1 %t300, label %bb69, label %bb70
bb68:
  call void @__olang_check_failed(ptr @olang_loc_846e8cf19a14b6db_3af1bf273e789227)
  unreachable
bb69:
  %t302 = load i64, ptr %l144, !tbaa !24
  %t303 = mul i64 %t302, 4
  %t304 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t303)
  %t305 = insertvalue { i64, ptr } undef, i64 %t302, 0
  %t306 = insertvalue { i64, ptr } %t305, ptr %t304, 1
  store { i64, ptr } %t306, ptr %l13, !tbaa !27
  %t308 = load ptr, ptr %l1, !tbaa !29
  %t310 = getelementptr %"compiler/generic:Context", ptr %t308, i32 0, i32 2
  %t312 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_H0e73c22773457b60eb954c2c4a2643e9(ptr %v1, ptr %t310)
  store i64 %t312, ptr %l150
  br label %bb71
bb70:
  call void @__olang_check_failed(ptr @olang_loc_846e8cf19a14b6db_3af1bf273e789227)
  unreachable
bb71:
  %t313 = load i64, ptr %l150, !tbaa !24
  %t314 = icmp sge i64 %t313, 0
  br i1 %t314, label %bb72, label %bb73
bb72:
  %t316 = load i64, ptr %l150, !tbaa !24
  %t317 = icmp sle i64 %t316, 2305843009213693951
  br i1 %t317, label %bb74, label %bb75
bb73:
  call void @__olang_check_failed(ptr @olang_loc_7486412f18d83346_49a9869342f97632)
  unreachable
bb74:
  %t319 = load i64, ptr %l150, !tbaa !24
  %t320 = mul i64 %t319, 4
  %t321 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t320)
  %t322 = insertvalue { i64, ptr } undef, i64 %t319, 0
  %t323 = insertvalue { i64, ptr } %t322, ptr %t321, 1
  store { i64, ptr } %t323, ptr %l14, !tbaa !27
  store i64 0, ptr %l15, !tbaa !24
  %t325 = load ptr, ptr %l1, !tbaa !29
  %t327 = getelementptr %"compiler/generic:Context", ptr %t325, i32 0, i32 2
  %t329 = call %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_Ha72624ba64524ee3315305b5d1bfb369(ptr %v1, ptr %v1, ptr %t327)
  store %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" %t329, ptr %l156
  br label %bb76
bb75:
  call void @__olang_check_failed(ptr @olang_loc_7486412f18d83346_49a9869342f97632)
  unreachable
bb76:
  %t330 = load %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9", ptr %l156
  store %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" %t330, ptr %l16
  br label %bb77
bb77:
  %t332 = call { i32, %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapIter_3ccompiler_2fsource_3aNameId_2c_20co_H6cf169b12565f300e9fe11f1c8d55061(ptr %v1, ptr %l16)
  %t333 = extractvalue { i32, %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" } %t332, 1
  %t334 = extractvalue { i32, %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" } %t332, 0
  store i32 %t334, ptr %l160
  %t335 = icmp ne i32 %t334, 0
  br i1 %t335, label %bb79, label %ok.336, !prof !99
ok.336:
  store %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" %t333, ptr %l159
  br label %bb78
bb78:
  %t337 = load %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa", ptr %l159
  store %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" %t337, ptr %l157
  br label %bb81
bb79:
  %t338 = load i32, ptr %l160, !tbaa !23
  %t339 = ashr i32 %t338, 16
  %t341 = icmp eq i32 %t339, 1
  store i1 %t341, ptr %l162, !tbaa !21
  br label %bb80
bb80:
  br label %bb83
bb81:
  %t342 = load %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa", ptr %l157
  store %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" %t342, ptr %l17
  %t343 = getelementptr %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa", ptr %l17, i32 0, i32 0
  %t344 = load i32, ptr %t343, !tbaa !23
  %t346 = getelementptr %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa", ptr %l17, i32 0, i32 1
  %t347 = load i32, ptr %t346, !tbaa !23
  %t349 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t349, ptr %l165, !tbaa !27
  %t350 = load i64, ptr %l15, !tbaa !24
  %t354 = getelementptr { i64, ptr }, ptr %l165, i32 0, i32 1
  %t355 = load ptr, ptr %t354, !tbaa !27
  %t356 = getelementptr i32, ptr %t355, i64 %t350
  store i32 %t344, ptr %t356, !tbaa !33
  %t357 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t357, ptr %l168, !tbaa !27
  %t358 = load i64, ptr %l15, !tbaa !24
  %t362 = getelementptr { i64, ptr }, ptr %l168, i32 0, i32 1
  %t363 = load ptr, ptr %t362, !tbaa !27
  %t364 = getelementptr i32, ptr %t363, i64 %t358
  store i32 %t347, ptr %t364, !tbaa !33
  %t365 = load i64, ptr %l15, !tbaa !24
  %t368 = add i64 %t365, 1
  store i64 %t368, ptr %l15, !tbaa !24
  br label %bb82
bb82:
  br label %bb77
bb83:
  %t370 = load ptr, ptr %l0, !tbaa !29
  %t372 = getelementptr %"compiler/generic:Program", ptr %t370, i32 0, i32 64
  store ptr %t372, ptr %l175, !tbaa !29
  %t373 = load ptr, ptr %l1, !tbaa !29
  %t375 = getelementptr %"compiler/generic:Context", ptr %t373, i32 0, i32 0
  %t376 = load i64, ptr %t375, !tbaa !24
  %t377 = load ptr, ptr %l4, !tbaa !29
  %t378 = load i32, ptr %l3, !tbaa !23
  %t379 = load ptr, ptr %l1, !tbaa !29
  %t381 = getelementptr %"compiler/generic:Context", ptr %t379, i32 0, i32 1
  %t382 = load i64, ptr %t381, !tbaa !24
  %t383 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t384 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t385 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t393 = call %"compiler/generic:ConstAsk" @compiler_2fgeneric_3aConstAsk_2ector(ptr %v2, ptr %v0, ptr %v0, ptr %v0, ptr %v0, i64 %t376, ptr %t377, i32 %t378, i64 %t382, { i64, ptr } %t383, { i64, ptr } %t384, { i64, ptr } %t385)
  store %"compiler/generic:ConstAsk" %t393, ptr %l185
  br label %bb84
bb84:
  %t394 = load ptr, ptr %l175, !tbaa !29
  %t395 = load %"compiler/generic:ConstAsk", ptr %l185
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3aConstAsk_3e_2ePus_H9314813d35e39659e36ddfdc05758427(ptr %v0, ptr %v0, ptr %t394, %"compiler/generic:ConstAsk" %t395)
  br label %bb85
bb85:
  br label %bb86
bb86:
  br label %bb87
bb87:
  %t396 = load ptr, ptr %l0, !tbaa !29
  %t398 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eUnknownConst(ptr %v0, ptr %t396)
  store i32 %t398, ptr %l187
  br label %bb88
bb88:
  %t399 = load i32, ptr %l187, !tbaa !23
  store i32 %t399, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2edefaultRow(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l4 = alloca %"compiler/source:Span"
  %lp5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca ptr
  %l9 = alloca %"compiler/source:Span"
  %l16 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i32
  %l26 = alloca ptr
  %l32 = alloca ptr
  %l39 = alloca { i64, ptr }
  %l41 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i64
  %l49 = alloca i64
  %l55 = alloca ptr
  %l56 = alloca i64
  %l58 = alloca i64
  %l59 = alloca ptr
  %l60 = alloca i64
  %l63 = alloca %"compiler/generic:Context"
  %l64 = alloca %"compiler/generic:Context"
  %l65 = alloca i64
  %l67 = alloca { i64, ptr }
  %l68 = alloca i64
  %l69 = alloca { i64, ptr }
  %l73 = alloca i64
  %l75 = alloca { i64, ptr }
  %l76 = alloca i64
  %l77 = alloca { i64, ptr }
  %l81 = alloca i64
  %l83 = alloca { i64, ptr }
  %l84 = alloca i64
  %l85 = alloca { i64, ptr }
  %l89 = alloca i64
  %l91 = alloca { i64, ptr }
  %l92 = alloca i64
  %l93 = alloca { i64, ptr }
  %l97 = alloca i64
  %l99 = alloca { i64, ptr }
  %l100 = alloca i64
  %l101 = alloca { i64, ptr }
  %l105 = alloca i64
  %l107 = alloca { i64, ptr }
  %l108 = alloca i64
  %l109 = alloca { i64, ptr }
  %l114 = alloca %"compiler/generic:FnDefault"
  %l116 = alloca %"compiler/generic:FnDefault"
  %s0 = alloca %olang.scope
  %rv = alloca i64
  %t509 = alloca %"compiler/generic:FnDefault", align 8
  %t512 = alloca %"compiler/generic:Context", align 8
  %t513 = alloca %"compiler/generic:FnDefault", align 8
  %t517 = alloca %"compiler/generic:FnDefault", align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t1)
  store %"compiler/source:Span" %t3, ptr %l9
  br label %bb1
bb1:
  %t4 = load %"compiler/source:Span", ptr %l9
  store %"compiler/source:Span" %t4, ptr %l4
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t7 = getelementptr %"compiler/generic:Context", ptr %t5, i32 0, i32 0
  %t8 = load i64, ptr %t7, !tbaa !24
  %t9 = getelementptr %"compiler/source:Span", ptr %l4, i32 0, i32 0
  %t10 = load i32, ptr %t9, !tbaa !23
  %t13 = sext i32 %a3 to i64
  %t15 = call i64 @__olang_fmt_i64(ptr null, i64 %t8)
  %t16 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d59, i32 0, i32 1) }, 1
  %t17 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d59, i32 0, i32 1) }, 0
  %t18 = add i64 %t15, %t17
  %t20 = sext i32 %t10 to i64
  %t21 = call i64 @__olang_fmt_i64(ptr null, i64 %t20)
  %t22 = add i64 %t18, %t21
  %t23 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d59, i32 0, i32 1) }, 1
  %t24 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d59, i32 0, i32 1) }, 0
  %t25 = add i64 %t22, %t24
  %t27 = call i64 @__olang_fmt_i64(ptr null, i64 %t13)
  %t28 = add i64 %t25, %t27
  %t29 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t28)
  %t30 = call i64 @__olang_fmt_i64(ptr %t29, i64 %t8)
  %t31 = getelementptr i8, ptr %t29, i64 %t15
  call void @olang_textcopy(ptr %t31, ptr %t16, i64 %t17)
  %t32 = getelementptr i8, ptr %t31, i64 %t17
  %t33 = call i64 @__olang_fmt_i64(ptr %t32, i64 %t20)
  %t34 = getelementptr i8, ptr %t32, i64 %t21
  call void @olang_textcopy(ptr %t34, ptr %t23, i64 %t24)
  %t35 = getelementptr i8, ptr %t34, i64 %t24
  %t36 = call i64 @__olang_fmt_i64(ptr %t35, i64 %t13)
  %t37 = insertvalue { i64, ptr } undef, i64 %t28, 0
  %t38 = insertvalue { i64, ptr } %t37, ptr %t29, 1
  %t39 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 16, i64 8)
  store ptr %t39, ptr %lp5
  %t41 = load ptr, ptr %lp5
  store { i64, ptr } %t38, ptr %t41, !tbaa !27
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/generic:Program", ptr %t42, i32 0, i32 13
  %t45 = load ptr, ptr %lp5
  %t46 = load { i64, ptr }, ptr %t45, !tbaa !27
  %t49 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9162e3b7f03fcbf954b681204d5f6cca(ptr %v0, ptr %v0, ptr %t44, { i64, ptr } %t46)
  %t50 = extractvalue { i32, i64 } %t49, 1
  %t51 = extractvalue { i32, i64 } %t49, 0
  store i32 %t51, ptr %l21
  %t52 = icmp ne i32 %t51, 0
  br i1 %t52, label %bb3, label %ok.53, !prof !99
ok.53:
  store i64 %t50, ptr %l20
  br label %bb2
bb2:
  %t54 = load i64, ptr %l20, !tbaa !24
  store i64 %t54, ptr %l16, !tbaa !24
  br label %bb5
bb3:
  br label %bb4
bb4:
  store i64 0, ptr %l16, !tbaa !24
  br label %bb5
bb5:
  %t55 = load i64, ptr %l16, !tbaa !24
  store i64 %t55, ptr %l6, !tbaa !24
  %t56 = load i64, ptr %l6, !tbaa !24
  %t58 = icmp ne i64 %t56, 0
  br i1 %t58, label %bb6, label %bb7
bb6:
  %t60 = load i64, ptr %l6, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t60, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/generic:Program", ptr %t62, i32 0, i32 2
  store ptr %t64, ptr %l26, !tbaa !29
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/generic:Program", ptr %t65, i32 0, i32 0
  %t68 = load ptr, ptr %t67, !tbaa !29
  %t70 = getelementptr %"compiler/load:Loader", ptr %t68, i32 0, i32 10
  %t71 = load ptr, ptr %l1, !tbaa !29
  %t73 = getelementptr %"compiler/generic:Context", ptr %t71, i32 0, i32 0
  %t74 = load i64, ptr %t73, !tbaa !24
  %t77 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t70, i64 %t74)
  store ptr %t77, ptr %l32
  br label %bb9
bb9:
  %t78 = load ptr, ptr %l32, !tbaa !29
  %t80 = getelementptr %"compiler/load:Module", ptr %t78, i32 0, i32 6
  %t81 = load ptr, ptr %t80, !tbaa !29
  store ptr %t81, ptr %l7, !tbaa !29
  %t83 = load ptr, ptr %l7, !tbaa !29
  %t85 = icmp eq ptr %t83, null
  br i1 %t85, label %bb10, label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_a38131017e96f420_b77c6395c7c31534)
  unreachable
bb11:
  br label %bb12
bb12:
  %t87 = load ptr, ptr %l7, !tbaa !29
  %t90 = getelementptr %"compiler/source:Source", ptr %t87, i32 0, i32 1
  %t91 = load { i64, ptr }, ptr %t90, !tbaa !27
  store { i64, ptr } %t91, ptr %l39, !tbaa !27
  %t92 = getelementptr %"compiler/source:Span", ptr %l4, i32 0, i32 0
  %t93 = load i32, ptr %t92, !tbaa !23
  %t95 = sext i32 %t93 to i64
  store i64 %t95, ptr %l41, !tbaa !24
  %t96 = getelementptr %"compiler/source:Span", ptr %l4, i32 0, i32 1
  %t97 = load i32, ptr %t96, !tbaa !23
  %t99 = sext i32 %t97 to i64
  store i64 %t99, ptr %l43, !tbaa !24
  %t100 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t101 = extractvalue { i64, ptr } %t100, 0
  store i64 %t101, ptr %l44, !tbaa !24
  %t102 = load i64, ptr %l41, !tbaa !24
  %t103 = icmp sge i64 %t102, 0
  br i1 %t103, label %bb13, label %bb14
bb13:
  %t105 = load i64, ptr %l41, !tbaa !24
  %t106 = load i64, ptr %l43, !tbaa !24
  %t107 = icmp sle i64 %t105, %t106
  br i1 %t107, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_693dd3c2c5a77285_e5bce5d7f9614999)
  unreachable
bb15:
  %t109 = load i64, ptr %l43, !tbaa !24
  %t110 = load i64, ptr %l44, !tbaa !24
  %t111 = icmp sle i64 %t109, %t110
  br i1 %t111, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_693dd3c2c5a77285_e5bce5d7f9614999)
  unreachable
bb17:
  %t113 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t114 = load ptr, ptr %t113, !tbaa !27
  %t115 = load i64, ptr %l41, !tbaa !24
  %t116 = load i64, ptr %l43, !tbaa !24
  %t117 = getelementptr i8, ptr %t114, i64 %t115
  %t118 = sub i64 %t116, %t115
  %t119 = insertvalue { i64, ptr } undef, i64 %t118, 0
  %t120 = insertvalue { i64, ptr } %t119, ptr %t117, 1
  %t121 = load ptr, ptr %l26, !tbaa !29
  %t123 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDefault(ptr %v0, ptr %v0, ptr %t121, { i64, ptr } %t120)
  store i64 %t123, ptr %l49
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_693dd3c2c5a77285_e5bce5d7f9614999)
  unreachable
bb19:
  %t124 = load i64, ptr %l49, !tbaa !24
  store i64 %t124, ptr %l6, !tbaa !24
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t127 = getelementptr %"compiler/generic:Program", ptr %t125, i32 0, i32 13
  %t128 = load ptr, ptr %lp5
  %t129 = load { i64, ptr }, ptr %t128, !tbaa !27
  %t130 = load i64, ptr %l6, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha091d021a90ce6aa48813730c00df6d2(ptr %v0, ptr %v0, ptr %t127, { i64, ptr } %t129, i64 %t130)
  br label %bb20
bb20:
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t136 = getelementptr %"compiler/generic:Program", ptr %t134, i32 0, i32 12
  store ptr %t136, ptr %l55, !tbaa !29
  %t137 = load i64, ptr %l6, !tbaa !24
  store i64 %t137, ptr %l56, !tbaa !24
  %t138 = load ptr, ptr %l1, !tbaa !29
  %t140 = getelementptr %"compiler/generic:Context", ptr %t138, i32 0, i32 0
  %t141 = load i64, ptr %t140, !tbaa !24
  store i64 %t141, ptr %l58, !tbaa !24
  %t142 = load ptr, ptr %l2, !tbaa !29
  store ptr %t142, ptr %l59, !tbaa !29
  %t143 = call ptr @__olang_scope_hold(ptr %v0)
  %t144 = ptrtoint ptr %t143 to i64
  store i64 %t144, ptr %l60, !tbaa !24
  %t145 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aFnDefault_2e2
  br i1 %t145, label %bb21, label %bb22
bb21:
  %t147 = call ptr @__olang_region_make(ptr %v0)
  %t148 = ptrtoint ptr %t147 to i64
  store i64 %t148, ptr %l60, !tbaa !24
  br label %bb22
bb22:
  %t149 = load ptr, ptr %l1, !tbaa !29
  call void @llvm.memmove.p0.p0.i64(ptr %l63, ptr %t149, i64 160, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %l64, ptr %l63, i64 160, i1 false)
  %t151 = load i64, ptr %l60
  %t152 = inttoptr i64 %t151 to ptr
  %t153 = call ptr @__olang_scope_hold(ptr %t152)
  %t154 = ptrtoint ptr %t153 to i64
  store i64 %t154, ptr %l65, !tbaa !24
  %t155 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compiler_2ftypes_3aTypeId_3e_2e0
  br i1 %t155, label %bb23, label %bb24
bb23:
  %t157 = load i64, ptr %l60
  %t158 = inttoptr i64 %t157 to ptr
  %t159 = call ptr @__olang_region_make_part(ptr %t158)
  %t160 = ptrtoint ptr %t159 to i64
  store i64 %t160, ptr %l65, !tbaa !24
  br label %bb24
bb24:
  %t161 = getelementptr %"compiler/generic:Context", ptr %l64, i32 0, i32 2
  %t162 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t161, i32 0, i32 0
  %t163 = load { i64, ptr }, ptr %t162, !tbaa !27
  store { i64, ptr } %t163, ptr %l67, !tbaa !27
  %t164 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t165 = extractvalue { i64, ptr } %t164, 0
  store i64 %t165, ptr %l68, !tbaa !24
  %t166 = load i64, ptr %l68, !tbaa !24
  %t167 = mul i64 %t166, 8
  %t168 = load i64, ptr %l65
  %t169 = inttoptr i64 %t168 to ptr
  %t170 = call ptr @__olang_held_alloc(ptr %t169, i64 %t167)
  %t171 = insertvalue { i64, ptr } undef, i64 %t166, 0
  %t172 = insertvalue { i64, ptr } %t171, ptr %t170, 1
  store { i64, ptr } %t172, ptr %l69, !tbaa !27
  %t173 = getelementptr { i64, ptr }, ptr %l69, i32 0, i32 1
  %t174 = load ptr, ptr %t173, !tbaa !27
  %t175 = getelementptr { i64, ptr }, ptr %l67, i32 0, i32 1
  %t176 = load ptr, ptr %t175, !tbaa !27
  %t177 = load i64, ptr %l68, !tbaa !24
  %t178 = mul i64 %t177, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t174, ptr %t176, i64 %t178, i1 false)
  %t179 = load { i64, ptr }, ptr %l69, !tbaa !27
  %t180 = getelementptr %"compiler/generic:Context", ptr %l64, i32 0, i32 2
  %t181 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t180, i32 0, i32 0
  store { i64, ptr } %t179, ptr %t181, !tbaa !27
  %t182 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compiler_2ftypes_3aTypeId_3e_2e0
  br i1 %t182, label %bb25, label %bb26
bb25:
  %t184 = getelementptr %"compiler/generic:Context", ptr %l64, i32 0, i32 2
  %t185 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t184, i32 0, i32 0
  %t186 = load { i64, ptr }, ptr %t185, !tbaa !27
  %t187 = extractvalue { i64, ptr } %t186, 0
  %t189 = icmp eq i64 %t187, 0
  br i1 %t189, label %bb27, label %bb28
bb26:
  %t191 = load i64, ptr %l60
  %t192 = inttoptr i64 %t191 to ptr
  %t193 = call ptr @__olang_scope_hold(ptr %t192)
  %t194 = ptrtoint ptr %t193 to i64
  store i64 %t194, ptr %l73, !tbaa !24
  %t195 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compiler_2ftypes_3aTypeId_3e_2e1
  br i1 %t195, label %bb29, label %bb30
bb27:
  %t197 = getelementptr %"compiler/generic:Context", ptr %l64, i32 0, i32 2
  %t198 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t197, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t198, !tbaa !27
  br label %bb28
bb28:
  %t199 = getelementptr %"compiler/generic:Context", ptr %l64, i32 0, i32 2
  %t200 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t199, i32 0, i32 0
  %t201 = load i64, ptr %l65
  %t202 = inttoptr i64 %t201 to ptr
  %t203 = load { i64, ptr }, ptr %t200
  %t204 = extractvalue { i64, ptr } %t203, 1
  %t205 = call ptr @__olang_region_or(ptr %t204, ptr null)
  %t206 = icmp ne ptr %t205, null
  %t207 = select i1 %t206, ptr %t205, ptr null
  call void @__olang_region_settle_in(ptr %t202, ptr %t207)
  br label %bb26
bb29:
  %t208 = load i64, ptr %l60
  %t209 = inttoptr i64 %t208 to ptr
  %t210 = call ptr @__olang_region_make_part(ptr %t209)
  %t211 = ptrtoint ptr %t210 to i64
  store i64 %t211, ptr %l73, !tbaa !24
  br label %bb30
bb30:
  %t212 = getelementptr %"compiler/generic:Context", ptr %l64, i32 0, i32 2
  %t213 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t212, i32 0, i32 1
  %t214 = load { i64, ptr }, ptr %t213, !tbaa !27
  store { i64, ptr } %t214, ptr %l75, !tbaa !27
  %t215 = load { i64, ptr }, ptr %l75, !tbaa !27
  %t216 = extractvalue { i64, ptr } %t215, 0
  store i64 %t216, ptr %l76, !tbaa !24
  %t217 = load i64, ptr %l76, !tbaa !24
  %t218 = mul i64 %t217, 8
  %t219 = load i64, ptr %l73
  %t220 = inttoptr i64 %t219 to ptr
  %t221 = call ptr @__olang_held_alloc(ptr %t220, i64 %t218)
  %t222 = insertvalue { i64, ptr } undef, i64 %t217, 0
  %t223 = insertvalue { i64, ptr } %t222, ptr %t221, 1
  store { i64, ptr } %t223, ptr %l77, !tbaa !27
  %t224 = getelementptr { i64, ptr }, ptr %l77, i32 0, i32 1
  %t225 = load ptr, ptr %t224, !tbaa !27
  %t226 = getelementptr { i64, ptr }, ptr %l75, i32 0, i32 1
  %t227 = load ptr, ptr %t226, !tbaa !27
  %t228 = load i64, ptr %l76, !tbaa !24
  %t229 = mul i64 %t228, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t225, ptr %t227, i64 %t229, i1 false)
  %t230 = load { i64, ptr }, ptr %l77, !tbaa !27
  %t231 = getelementptr %"compiler/generic:Context", ptr %l64, i32 0, i32 2
  %t232 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t231, i32 0, i32 1
  store { i64, ptr } %t230, ptr %t232, !tbaa !27
  %t233 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compiler_2ftypes_3aTypeId_3e_2e1
  br i1 %t233, label %bb31, label %bb32
bb31:
  %t235 = getelementptr %"compiler/generic:Context", ptr %l64, i32 0, i32 2
  %t236 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t235, i32 0, i32 1
  %t237 = load { i64, ptr }, ptr %t236, !tbaa !27
  %t238 = extractvalue { i64, ptr } %t237, 0
  %t240 = icmp eq i64 %t238, 0
  br i1 %t240, label %bb33, label %bb34
bb32:
  %t242 = load i64, ptr %l60
  %t243 = inttoptr i64 %t242 to ptr
  %t244 = call ptr @__olang_scope_hold(ptr %t243)
  %t245 = ptrtoint ptr %t244 to i64
  store i64 %t245, ptr %l81, !tbaa !24
  %t246 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compiler_2ftypes_3aTypeId_3e_2e2
  br i1 %t246, label %bb35, label %bb36
bb33:
  %t248 = getelementptr %"compiler/generic:Context", ptr %l64, i32 0, i32 2
  %t249 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t248, i32 0, i32 1
  store { i64, ptr } zeroinitializer, ptr %t249, !tbaa !27
  br label %bb34
bb34:
  %t250 = getelementptr %"compiler/generic:Context", ptr %l64, i32 0, i32 2
  %t251 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t250, i32 0, i32 1
  %t252 = load i64, ptr %l73
  %t253 = inttoptr i64 %t252 to ptr
  %t254 = load { i64, ptr }, ptr %t251
  %t255 = extractvalue { i64, ptr } %t254, 1
  %t256 = call ptr @__olang_region_or(ptr %t255, ptr null)
  %t257 = icmp ne ptr %t256, null
  %t258 = select i1 %t257, ptr %t256, ptr null
  call void @__olang_region_settle_in(ptr %t253, ptr %t258)
  br label %bb32
bb35:
  %t259 = load i64, ptr %l60
  %t260 = inttoptr i64 %t259 to ptr
  %t261 = call ptr @__olang_region_make_part(ptr %t260)
  %t262 = ptrtoint ptr %t261 to i64
  store i64 %t262, ptr %l81, !tbaa !24
  br label %bb36
bb36:
  %t263 = getelementptr %"compiler/generic:Context", ptr %l64, i32 0, i32 2
  %t264 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t263, i32 0, i32 2
  %t265 = load { i64, ptr }, ptr %t264, !tbaa !27
  store { i64, ptr } %t265, ptr %l83, !tbaa !27
  %t266 = load { i64, ptr }, ptr %l83, !tbaa !27
  %t267 = extractvalue { i64, ptr } %t266, 0
  store i64 %t267, ptr %l84, !tbaa !24
  %t268 = load i64, ptr %l84, !tbaa !24
  %t269 = mul i64 %t268, 8
  %t270 = load i64, ptr %l81
  %t271 = inttoptr i64 %t270 to ptr
  %t272 = call ptr @__olang_held_alloc(ptr %t271, i64 %t269)
  %t273 = insertvalue { i64, ptr } undef, i64 %t268, 0
  %t274 = insertvalue { i64, ptr } %t273, ptr %t272, 1
  store { i64, ptr } %t274, ptr %l85, !tbaa !27
  %t275 = getelementptr { i64, ptr }, ptr %l85, i32 0, i32 1
  %t276 = load ptr, ptr %t275, !tbaa !27
  %t277 = getelementptr { i64, ptr }, ptr %l83, i32 0, i32 1
  %t278 = load ptr, ptr %t277, !tbaa !27
  %t279 = load i64, ptr %l84, !tbaa !24
  %t280 = mul i64 %t279, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t276, ptr %t278, i64 %t280, i1 false)
  %t281 = load { i64, ptr }, ptr %l85, !tbaa !27
  %t282 = getelementptr %"compiler/generic:Context", ptr %l64, i32 0, i32 2
  %t283 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t282, i32 0, i32 2
  store { i64, ptr } %t281, ptr %t283, !tbaa !27
  %t284 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compiler_2ftypes_3aTypeId_3e_2e2
  br i1 %t284, label %bb37, label %bb38
bb37:
  %t286 = getelementptr %"compiler/generic:Context", ptr %l64, i32 0, i32 2
  %t287 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t286, i32 0, i32 2
  %t288 = load { i64, ptr }, ptr %t287, !tbaa !27
  %t289 = extractvalue { i64, ptr } %t288, 0
  %t291 = icmp eq i64 %t289, 0
  br i1 %t291, label %bb39, label %bb40
bb38:
  %t293 = load i64, ptr %l60
  %t294 = inttoptr i64 %t293 to ptr
  %t295 = call ptr @__olang_scope_hold(ptr %t294)
  %t296 = ptrtoint ptr %t295 to i64
  store i64 %t296, ptr %l89, !tbaa !24
  %t297 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compiler_2ftypes_3aTypeId_3e_2e0
  br i1 %t297, label %bb41, label %bb42
bb39:
  %t299 = getelementptr %"compiler/generic:Context", ptr %l64, i32 0, i32 2
  %t300 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t299, i32 0, i32 2
  store { i64, ptr } zeroinitializer, ptr %t300, !tbaa !27
  br label %bb40
bb40:
  %t301 = getelementptr %"compiler/generic:Context", ptr %l64, i32 0, i32 2
  %t302 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t301, i32 0, i32 2
  %t303 = load i64, ptr %l81
  %t304 = inttoptr i64 %t303 to ptr
  %t305 = load { i64, ptr }, ptr %t302
  %t306 = extractvalue { i64, ptr } %t305, 1
  %t307 = call ptr @__olang_region_or(ptr %t306, ptr null)
  %t308 = icmp ne ptr %t307, null
  %t309 = select i1 %t308, ptr %t307, ptr null
  call void @__olang_region_settle_in(ptr %t304, ptr %t309)
  br label %bb38
bb41:
  %t310 = load i64, ptr %l60
  %t311 = inttoptr i64 %t310 to ptr
  %t312 = call ptr @__olang_region_make_part(ptr %t311)
  %t313 = ptrtoint ptr %t312 to i64
  store i64 %t313, ptr %l89, !tbaa !24
  br label %bb42
bb42:
  %t314 = getelementptr %"compiler/generic:Context", ptr %l64, i32 0, i32 3
  %t315 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t314, i32 0, i32 0
  %t316 = load { i64, ptr }, ptr %t315, !tbaa !27
  store { i64, ptr } %t316, ptr %l91, !tbaa !27
  %t317 = load { i64, ptr }, ptr %l91, !tbaa !27
  %t318 = extractvalue { i64, ptr } %t317, 0
  store i64 %t318, ptr %l92, !tbaa !24
  %t319 = load i64, ptr %l92, !tbaa !24
  %t320 = mul i64 %t319, 8
  %t321 = load i64, ptr %l89
  %t322 = inttoptr i64 %t321 to ptr
  %t323 = call ptr @__olang_held_alloc(ptr %t322, i64 %t320)
  %t324 = insertvalue { i64, ptr } undef, i64 %t319, 0
  %t325 = insertvalue { i64, ptr } %t324, ptr %t323, 1
  store { i64, ptr } %t325, ptr %l93, !tbaa !27
  %t326 = getelementptr { i64, ptr }, ptr %l93, i32 0, i32 1
  %t327 = load ptr, ptr %t326, !tbaa !27
  %t328 = getelementptr { i64, ptr }, ptr %l91, i32 0, i32 1
  %t329 = load ptr, ptr %t328, !tbaa !27
  %t330 = load i64, ptr %l92, !tbaa !24
  %t331 = mul i64 %t330, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t327, ptr %t329, i64 %t331, i1 false)
  %t332 = load { i64, ptr }, ptr %l93, !tbaa !27
  %t333 = getelementptr %"compiler/generic:Context", ptr %l64, i32 0, i32 3
  %t334 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t333, i32 0, i32 0
  store { i64, ptr } %t332, ptr %t334, !tbaa !27
  %t335 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compiler_2ftypes_3aTypeId_3e_2e0
  br i1 %t335, label %bb43, label %bb44
bb43:
  %t337 = getelementptr %"compiler/generic:Context", ptr %l64, i32 0, i32 3
  %t338 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t337, i32 0, i32 0
  %t339 = load { i64, ptr }, ptr %t338, !tbaa !27
  %t340 = extractvalue { i64, ptr } %t339, 0
  %t342 = icmp eq i64 %t340, 0
  br i1 %t342, label %bb45, label %bb46
bb44:
  %t344 = load i64, ptr %l60
  %t345 = inttoptr i64 %t344 to ptr
  %t346 = call ptr @__olang_scope_hold(ptr %t345)
  %t347 = ptrtoint ptr %t346 to i64
  store i64 %t347, ptr %l97, !tbaa !24
  %t348 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compiler_2ftypes_3aTypeId_3e_2e1
  br i1 %t348, label %bb47, label %bb48
bb45:
  %t350 = getelementptr %"compiler/generic:Context", ptr %l64, i32 0, i32 3
  %t351 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t350, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t351, !tbaa !27
  br label %bb46
bb46:
  %t352 = getelementptr %"compiler/generic:Context", ptr %l64, i32 0, i32 3
  %t353 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t352, i32 0, i32 0
  %t354 = load i64, ptr %l89
  %t355 = inttoptr i64 %t354 to ptr
  %t356 = load { i64, ptr }, ptr %t353
  %t357 = extractvalue { i64, ptr } %t356, 1
  %t358 = call ptr @__olang_region_or(ptr %t357, ptr null)
  %t359 = icmp ne ptr %t358, null
  %t360 = select i1 %t359, ptr %t358, ptr null
  call void @__olang_region_settle_in(ptr %t355, ptr %t360)
  br label %bb44
bb47:
  %t361 = load i64, ptr %l60
  %t362 = inttoptr i64 %t361 to ptr
  %t363 = call ptr @__olang_region_make_part(ptr %t362)
  %t364 = ptrtoint ptr %t363 to i64
  store i64 %t364, ptr %l97, !tbaa !24
  br label %bb48
bb48:
  %t365 = getelementptr %"compiler/generic:Context", ptr %l64, i32 0, i32 3
  %t366 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t365, i32 0, i32 1
  %t367 = load { i64, ptr }, ptr %t366, !tbaa !27
  store { i64, ptr } %t367, ptr %l99, !tbaa !27
  %t368 = load { i64, ptr }, ptr %l99, !tbaa !27
  %t369 = extractvalue { i64, ptr } %t368, 0
  store i64 %t369, ptr %l100, !tbaa !24
  %t370 = load i64, ptr %l100, !tbaa !24
  %t371 = mul i64 %t370, 8
  %t372 = load i64, ptr %l97
  %t373 = inttoptr i64 %t372 to ptr
  %t374 = call ptr @__olang_held_alloc(ptr %t373, i64 %t371)
  %t375 = insertvalue { i64, ptr } undef, i64 %t370, 0
  %t376 = insertvalue { i64, ptr } %t375, ptr %t374, 1
  store { i64, ptr } %t376, ptr %l101, !tbaa !27
  %t377 = getelementptr { i64, ptr }, ptr %l101, i32 0, i32 1
  %t378 = load ptr, ptr %t377, !tbaa !27
  %t379 = getelementptr { i64, ptr }, ptr %l99, i32 0, i32 1
  %t380 = load ptr, ptr %t379, !tbaa !27
  %t381 = load i64, ptr %l100, !tbaa !24
  %t382 = mul i64 %t381, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t378, ptr %t380, i64 %t382, i1 false)
  %t383 = load { i64, ptr }, ptr %l101, !tbaa !27
  %t384 = getelementptr %"compiler/generic:Context", ptr %l64, i32 0, i32 3
  %t385 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t384, i32 0, i32 1
  store { i64, ptr } %t383, ptr %t385, !tbaa !27
  %t386 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compiler_2ftypes_3aTypeId_3e_2e1
  br i1 %t386, label %bb49, label %bb50
bb49:
  %t388 = getelementptr %"compiler/generic:Context", ptr %l64, i32 0, i32 3
  %t389 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t388, i32 0, i32 1
  %t390 = load { i64, ptr }, ptr %t389, !tbaa !27
  %t391 = extractvalue { i64, ptr } %t390, 0
  %t393 = icmp eq i64 %t391, 0
  br i1 %t393, label %bb51, label %bb52
bb50:
  %t395 = load i64, ptr %l60
  %t396 = inttoptr i64 %t395 to ptr
  %t397 = call ptr @__olang_scope_hold(ptr %t396)
  %t398 = ptrtoint ptr %t397 to i64
  store i64 %t398, ptr %l105, !tbaa !24
  %t399 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compiler_2ftypes_3aTypeId_3e_2e2
  br i1 %t399, label %bb53, label %bb54
bb51:
  %t401 = getelementptr %"compiler/generic:Context", ptr %l64, i32 0, i32 3
  %t402 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t401, i32 0, i32 1
  store { i64, ptr } zeroinitializer, ptr %t402, !tbaa !27
  br label %bb52
bb52:
  %t403 = getelementptr %"compiler/generic:Context", ptr %l64, i32 0, i32 3
  %t404 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t403, i32 0, i32 1
  %t405 = load i64, ptr %l97
  %t406 = inttoptr i64 %t405 to ptr
  %t407 = load { i64, ptr }, ptr %t404
  %t408 = extractvalue { i64, ptr } %t407, 1
  %t409 = call ptr @__olang_region_or(ptr %t408, ptr null)
  %t410 = icmp ne ptr %t409, null
  %t411 = select i1 %t410, ptr %t409, ptr null
  call void @__olang_region_settle_in(ptr %t406, ptr %t411)
  br label %bb50
bb53:
  %t412 = load i64, ptr %l60
  %t413 = inttoptr i64 %t412 to ptr
  %t414 = call ptr @__olang_region_make_part(ptr %t413)
  %t415 = ptrtoint ptr %t414 to i64
  store i64 %t415, ptr %l105, !tbaa !24
  br label %bb54
bb54:
  %t416 = getelementptr %"compiler/generic:Context", ptr %l64, i32 0, i32 3
  %t417 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t416, i32 0, i32 2
  %t418 = load { i64, ptr }, ptr %t417, !tbaa !27
  store { i64, ptr } %t418, ptr %l107, !tbaa !27
  %t419 = load { i64, ptr }, ptr %l107, !tbaa !27
  %t420 = extractvalue { i64, ptr } %t419, 0
  store i64 %t420, ptr %l108, !tbaa !24
  %t421 = load i64, ptr %l108, !tbaa !24
  %t422 = mul i64 %t421, 8
  %t423 = load i64, ptr %l105
  %t424 = inttoptr i64 %t423 to ptr
  %t425 = call ptr @__olang_held_alloc(ptr %t424, i64 %t422)
  %t426 = insertvalue { i64, ptr } undef, i64 %t421, 0
  %t427 = insertvalue { i64, ptr } %t426, ptr %t425, 1
  store { i64, ptr } %t427, ptr %l109, !tbaa !27
  %t428 = getelementptr { i64, ptr }, ptr %l109, i32 0, i32 1
  %t429 = load ptr, ptr %t428, !tbaa !27
  %t430 = getelementptr { i64, ptr }, ptr %l107, i32 0, i32 1
  %t431 = load ptr, ptr %t430, !tbaa !27
  %t432 = load i64, ptr %l108, !tbaa !24
  %t433 = mul i64 %t432, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t429, ptr %t431, i64 %t433, i1 false)
  %t434 = load { i64, ptr }, ptr %l109, !tbaa !27
  %t435 = getelementptr %"compiler/generic:Context", ptr %l64, i32 0, i32 3
  %t436 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t435, i32 0, i32 2
  store { i64, ptr } %t434, ptr %t436, !tbaa !27
  %t437 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compiler_2ftypes_3aTypeId_3e_2e2
  br i1 %t437, label %bb55, label %bb56
bb55:
  %t439 = getelementptr %"compiler/generic:Context", ptr %l64, i32 0, i32 3
  %t440 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t439, i32 0, i32 2
  %t441 = load { i64, ptr }, ptr %t440, !tbaa !27
  %t442 = extractvalue { i64, ptr } %t441, 0
  %t444 = icmp eq i64 %t442, 0
  br i1 %t444, label %bb57, label %bb58
bb56:
  %t446 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aFnDefault_2e2
  br i1 %t446, label %bb59, label %bb60
bb57:
  %t448 = getelementptr %"compiler/generic:Context", ptr %l64, i32 0, i32 3
  %t449 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t448, i32 0, i32 2
  store { i64, ptr } zeroinitializer, ptr %t449, !tbaa !27
  br label %bb58
bb58:
  %t450 = getelementptr %"compiler/generic:Context", ptr %l64, i32 0, i32 3
  %t451 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t450, i32 0, i32 2
  %t452 = load i64, ptr %l105
  %t453 = inttoptr i64 %t452 to ptr
  %t454 = load { i64, ptr }, ptr %t451
  %t455 = extractvalue { i64, ptr } %t454, 1
  %t456 = call ptr @__olang_region_or(ptr %t455, ptr null)
  %t457 = icmp ne ptr %t456, null
  %t458 = select i1 %t457, ptr %t456, ptr null
  call void @__olang_region_settle_in(ptr %t453, ptr %t458)
  br label %bb56
bb59:
  %t459 = load i64, ptr %l60
  %t460 = inttoptr i64 %t459 to ptr
  %t461 = getelementptr %"compiler/generic:Context", ptr %l64, i32 0, i32 3
  %t462 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t461, i32 0, i32 2
  %t463 = load { i64, ptr }, ptr %t462
  %t464 = extractvalue { i64, ptr } %t463, 1
  %t465 = call ptr @__olang_region_or(ptr %t464, ptr null)
  %t466 = call ptr @__olang_region_home(ptr %t465)
  %t467 = icmp ne ptr %t466, null
  %t468 = select i1 %t467, ptr %t466, ptr null
  %t469 = getelementptr %"compiler/generic:Context", ptr %l64, i32 0, i32 3
  %t470 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t469, i32 0, i32 1
  %t471 = load { i64, ptr }, ptr %t470
  %t472 = extractvalue { i64, ptr } %t471, 1
  %t473 = call ptr @__olang_region_or(ptr %t472, ptr null)
  %t474 = call ptr @__olang_region_home(ptr %t473)
  %t475 = icmp ne ptr %t474, null
  %t476 = select i1 %t475, ptr %t474, ptr %t468
  %t477 = getelementptr %"compiler/generic:Context", ptr %l64, i32 0, i32 3
  %t478 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t477, i32 0, i32 0
  %t479 = load { i64, ptr }, ptr %t478
  %t480 = extractvalue { i64, ptr } %t479, 1
  %t481 = call ptr @__olang_region_or(ptr %t480, ptr null)
  %t482 = call ptr @__olang_region_home(ptr %t481)
  %t483 = icmp ne ptr %t482, null
  %t484 = select i1 %t483, ptr %t482, ptr %t476
  %t485 = getelementptr %"compiler/generic:Context", ptr %l64, i32 0, i32 2
  %t486 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t485, i32 0, i32 2
  %t487 = load { i64, ptr }, ptr %t486
  %t488 = extractvalue { i64, ptr } %t487, 1
  %t489 = call ptr @__olang_region_or(ptr %t488, ptr null)
  %t490 = call ptr @__olang_region_home(ptr %t489)
  %t491 = icmp ne ptr %t490, null
  %t492 = select i1 %t491, ptr %t490, ptr %t484
  %t493 = getelementptr %"compiler/generic:Context", ptr %l64, i32 0, i32 2
  %t494 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t493, i32 0, i32 1
  %t495 = load { i64, ptr }, ptr %t494
  %t496 = extractvalue { i64, ptr } %t495, 1
  %t497 = call ptr @__olang_region_or(ptr %t496, ptr null)
  %t498 = call ptr @__olang_region_home(ptr %t497)
  %t499 = icmp ne ptr %t498, null
  %t500 = select i1 %t499, ptr %t498, ptr %t492
  %t501 = getelementptr %"compiler/generic:Context", ptr %l64, i32 0, i32 2
  %t502 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t501, i32 0, i32 0
  %t503 = load { i64, ptr }, ptr %t502
  %t504 = extractvalue { i64, ptr } %t503, 1
  %t505 = call ptr @__olang_region_or(ptr %t504, ptr null)
  %t506 = call ptr @__olang_region_home(ptr %t505)
  %t507 = icmp ne ptr %t506, null
  %t508 = select i1 %t507, ptr %t506, ptr %t500
  call void @__olang_region_settle_in(ptr %t460, ptr %t508)
  br label %bb60
bb60:
  %t510 = load i64, ptr %l58, !tbaa !24
  %t511 = load ptr, ptr %l59, !tbaa !29
  call void @llvm.memmove.p0.p0.i64(ptr %t512, ptr %l64, i64 160, i1 false)
  call void @compiler_2fgeneric_3aFnDefault_2ector(ptr %t509, ptr %v2, ptr %v0, ptr %v0, i64 %t510, ptr %t511, ptr %t512)
  call void @llvm.memmove.p0.p0.i64(ptr %l114, ptr %t509, i64 176, i1 false)
  br label %bb61
bb61:
  call void @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2fgeneric_3aFnDefault(ptr %t513, ptr %s0, ptr %l114)
  call void @llvm.memmove.p0.p0.i64(ptr %l116, ptr %t513, i64 176, i1 false)
  br label %bb62
bb62:
  %t515 = load ptr, ptr %l55, !tbaa !29
  %t516 = load i64, ptr %l56, !tbaa !24
  call void @llvm.memmove.p0.p0.i64(ptr %t517, ptr %l116, i64 176, i1 false)
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fgeneric_3aFnDefaul_Heccae358bebde09a47984c7dc693f64e(ptr %v0, ptr %v0, ptr %t515, i64 %t516, ptr %t517)
  br label %bb63
bb63:
  %t518 = load i64, ptr %l6, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t518, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local %"compiler/generic:folded" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eevalBinary(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, i32 %a2, ptr %a3, ptr %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca %"compiler/generic:folded"
  %l6 = alloca %"compiler/generic:folded"
  %l7 = alloca %"compiler/generic:folded"
  %l8 = alloca i32
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i1
  %l12 = alloca i1
  %l14 = alloca i64
  %l15 = alloca i64
  %l18 = alloca i1
  %l24 = alloca %"compiler/generic:folded"
  %l31 = alloca i1
  %l34 = alloca i1
  %l37 = alloca i1
  %l44 = alloca %"compiler/generic:folded"
  %l48 = alloca %"compiler/generic:folded"
  %l52 = alloca %"compiler/generic:folded"
  %l56 = alloca i1
  %l60 = alloca %"compiler/generic:folded"
  %l64 = alloca i1
  %l70 = alloca %"compiler/generic:folded"
  %l74 = alloca i32
  %l77 = alloca i1
  %l80 = alloca i1
  %l81 = alloca %"compiler/generic:folded"
  %l87 = alloca i1
  %l89 = alloca ptr
  %l92 = alloca i32
  %l93 = alloca i1
  %l96 = alloca i1
  %l99 = alloca i1
  %l102 = alloca i1
  %l105 = alloca i1
  %l108 = alloca i1
  %l112 = alloca i1
  %l121 = alloca i1
  %l138 = alloca i1
  %l146 = alloca i1
  %l152 = alloca i64
  %l154 = alloca i64
  %l156 = alloca %"compiler/generic:folded"
  %l178 = alloca %"compiler/generic:folded"
  %l182 = alloca i64
  %l197 = alloca i64
  %l226 = alloca i32
  %l231 = alloca i32
  %l237 = alloca i64
  %l239 = alloca ptr
  %l242 = alloca i32
  %l243 = alloca i64
  %l246 = alloca i1
  %l250 = alloca %"compiler/generic:folded"
  %l254 = alloca i64
  %l259 = alloca i1
  %l261 = alloca ptr
  %l264 = alloca i32
  %l265 = alloca i1
  %l266 = alloca i64
  %l270 = alloca i64
  %l274 = alloca i64
  %l283 = alloca i64
  %l284 = alloca %"compiler/generic:folded"
  %l290 = alloca %"compiler/generic:folded"
  %l291 = alloca i64
  %l295 = alloca i64
  %l299 = alloca i64
  %l302 = alloca %"compiler/generic:folded"
  %s0 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s30 = alloca %olang.scope
  %rv = alloca %"compiler/generic:folded"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  store ptr %a3, ptr %l3
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t3 = trunc i64 45 to i32
  %t4 = icmp eq i32 %t1, %t3
  br i1 %t4, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l18, !tbaa !21
  br label %bb3
bb2:
  %t6 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t8 = trunc i64 46 to i32
  %t9 = icmp eq i32 %t6, %t8
  store i1 %t9, ptr %l18, !tbaa !21
  br label %bb3
bb3:
  %t11 = load i1, ptr %l18, !tbaa !21
  br i1 %t11, label %bb4, label %bb5
bb4:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load ptr, ptr %l1, !tbaa !29
  %t14 = load ptr, ptr %l3, !tbaa !29
  %t18 = call %"compiler/generic:folded" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eeval(ptr %v0, ptr %v1, ptr %v2, ptr %t12, ptr %t13, ptr %t14)
  store %"compiler/generic:folded" %t18, ptr %l24
  br label %bb6
bb5:
  br label %bb23
bb6:
  %t19 = load %"compiler/generic:folded", ptr %l24
  store %"compiler/generic:folded" %t19, ptr %l5
  %t20 = getelementptr %"compiler/generic:folded", ptr %l5, i32 0, i32 0
  %t21 = load i64, ptr %t20, !tbaa !24
  %t22 = load i64, ptr @G_2ecompiler_2fgeneric_2eFolded, !tbaa !24
  %t25 = icmp ne i64 %t21, %t22
  br i1 %t25, label %bb7, label %bb8
bb7:
  %t27 = load %"compiler/generic:folded", ptr %l5
  call void @__olang_scope_close(ptr %s0)
  store %"compiler/generic:folded" %t27, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t29 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t31 = trunc i64 45 to i32
  %t32 = icmp eq i32 %t29, %t31
  br i1 %t32, label %bb10, label %bb11
bb10:
  %t34 = getelementptr %"compiler/generic:folded", ptr %l5, i32 0, i32 1
  %t35 = load i64, ptr %t34, !tbaa !24
  %t37 = icmp eq i64 %t35, 0
  store i1 %t37, ptr %l31, !tbaa !21
  br label %bb12
bb11:
  store i1 false, ptr %l31, !tbaa !21
  br label %bb12
bb12:
  %t39 = load i1, ptr %l31, !tbaa !21
  br i1 %t39, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l34, !tbaa !21
  br label %bb18
bb14:
  %t40 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t42 = trunc i64 46 to i32
  %t43 = icmp eq i32 %t40, %t42
  br i1 %t43, label %bb15, label %bb16
bb15:
  %t45 = getelementptr %"compiler/generic:folded", ptr %l5, i32 0, i32 1
  %t46 = load i64, ptr %t45, !tbaa !24
  %t48 = icmp ne i64 %t46, 0
  store i1 %t48, ptr %l37, !tbaa !21
  br label %bb17
bb16:
  store i1 false, ptr %l37, !tbaa !21
  br label %bb17
bb17:
  %t50 = load i1, ptr %l37, !tbaa !21
  store i1 %t50, ptr %l34, !tbaa !21
  br label %bb18
bb18:
  %t51 = load i1, ptr %l34, !tbaa !21
  br i1 %t51, label %bb19, label %bb20
bb19:
  %t52 = load %"compiler/generic:folded", ptr %l5
  call void @__olang_scope_close(ptr %s0)
  store %"compiler/generic:folded" %t52, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t55 = load ptr, ptr %l1, !tbaa !29
  %t56 = load ptr, ptr %l4, !tbaa !29
  %t60 = call %"compiler/generic:folded" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eeval(ptr %v0, ptr %v1, ptr %v3, ptr %t54, ptr %t55, ptr %t56)
  store %"compiler/generic:folded" %t60, ptr %l44
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s0)
  %t61 = load %"compiler/generic:folded", ptr %l44
  store %"compiler/generic:folded" %t61, ptr %rv
  br label %ret
bb23:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t63 = load ptr, ptr %l1, !tbaa !29
  %t64 = load ptr, ptr %l3, !tbaa !29
  %t68 = call %"compiler/generic:folded" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eeval(ptr %v0, ptr %v1, ptr %v2, ptr %t62, ptr %t63, ptr %t64)
  store %"compiler/generic:folded" %t68, ptr %l48
  br label %bb24
bb24:
  %t69 = load %"compiler/generic:folded", ptr %l48
  store %"compiler/generic:folded" %t69, ptr %l6
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t71 = load ptr, ptr %l1, !tbaa !29
  %t72 = load ptr, ptr %l4, !tbaa !29
  %t76 = call %"compiler/generic:folded" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eeval(ptr %v0, ptr %v1, ptr %v3, ptr %t70, ptr %t71, ptr %t72)
  store %"compiler/generic:folded" %t76, ptr %l52
  br label %bb25
bb25:
  %t77 = load %"compiler/generic:folded", ptr %l52
  store %"compiler/generic:folded" %t77, ptr %l7
  %t78 = getelementptr %"compiler/generic:folded", ptr %l6, i32 0, i32 0
  %t79 = load i64, ptr %t78, !tbaa !24
  %t80 = load i64, ptr @G_2ecompiler_2fgeneric_2eUnfolded, !tbaa !24
  %t83 = icmp eq i64 %t79, %t80
  br i1 %t83, label %bb26, label %bb27
bb26:
  store i1 true, ptr %l56, !tbaa !21
  br label %bb28
bb27:
  %t85 = getelementptr %"compiler/generic:folded", ptr %l7, i32 0, i32 0
  %t86 = load i64, ptr %t85, !tbaa !24
  %t87 = load i64, ptr @G_2ecompiler_2fgeneric_2eUnfolded, !tbaa !24
  %t90 = icmp eq i64 %t86, %t87
  store i1 %t90, ptr %l56, !tbaa !21
  br label %bb28
bb28:
  %t92 = load i1, ptr %l56, !tbaa !21
  br i1 %t92, label %bb29, label %bb30
bb29:
  %t93 = call %"compiler/generic:folded" @compiler_2fgeneric_2efolded_2eunfolded()
  store %"compiler/generic:folded" %t93, ptr %l60
  br label %bb31
bb30:
  br label %bb32
bb31:
  call void @__olang_scope_close(ptr %s0)
  %t94 = load %"compiler/generic:folded", ptr %l60
  store %"compiler/generic:folded" %t94, ptr %rv
  br label %ret
bb32:
  %t95 = getelementptr %"compiler/generic:folded", ptr %l6, i32 0, i32 0
  %t96 = load i64, ptr %t95, !tbaa !24
  %t97 = load i64, ptr @G_2ecompiler_2fgeneric_2ePending, !tbaa !24
  %t100 = icmp eq i64 %t96, %t97
  br i1 %t100, label %bb33, label %bb34
bb33:
  store i1 true, ptr %l64, !tbaa !21
  br label %bb35
bb34:
  %t102 = getelementptr %"compiler/generic:folded", ptr %l7, i32 0, i32 0
  %t103 = load i64, ptr %t102, !tbaa !24
  %t104 = load i64, ptr @G_2ecompiler_2fgeneric_2ePending, !tbaa !24
  %t107 = icmp eq i64 %t103, %t104
  store i1 %t107, ptr %l64, !tbaa !21
  br label %bb35
bb35:
  %t109 = load i1, ptr %l64, !tbaa !21
  br i1 %t109, label %bb36, label %bb37
bb36:
  store %olang.scope zeroinitializer, ptr %s5
  %t110 = load i64, ptr @G_2ecompiler_2fgeneric_2ePending, !tbaa !24
  %t111 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t114 = call %"compiler/generic:folded" @compiler_2fgeneric_3afolded_2ector(ptr %s5, i64 %t110, i64 0, i32 %t111)
  store %"compiler/generic:folded" %t114, ptr %l70
  br label %bb38
bb37:
  br label %bb39
bb38:
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  %t115 = load %"compiler/generic:folded", ptr %l70
  store %"compiler/generic:folded" %t115, ptr %rv
  br label %ret
bb39:
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t117 = load %"compiler/generic:folded", ptr %l6
  %t118 = load %"compiler/generic:folded", ptr %l7
  %t122 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2emeet(ptr %v0, ptr %t116, %"compiler/generic:folded" %t117, %"compiler/generic:folded" %t118)
  store i32 %t122, ptr %l74
  br label %bb40
bb40:
  %t123 = load i32, ptr %l74, !tbaa !23
  store i32 %t123, ptr %l8, !tbaa !23
  %t124 = load i32, ptr %l8, !tbaa !23
  %t126 = icmp eq i32 %t124, -1
  br i1 %t126, label %bb41, label %bb42
bb41:
  store i1 true, ptr %l77, !tbaa !21
  br label %bb44
bb42:
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t129 = load i32, ptr %l8, !tbaa !23
  %t132 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ewide(ptr %v0, ptr %t128, i32 %t129)
  store i1 %t132, ptr %l80
  br label %bb43
bb43:
  %t133 = load i1, ptr %l80, !tbaa !21
  store i1 %t133, ptr %l77, !tbaa !21
  br label %bb44
bb44:
  %t134 = load i1, ptr %l77, !tbaa !21
  br i1 %t134, label %bb45, label %bb46
bb45:
  %t135 = call %"compiler/generic:folded" @compiler_2fgeneric_2efolded_2eunfolded()
  store %"compiler/generic:folded" %t135, ptr %l81
  br label %bb47
bb46:
  br label %bb48
bb47:
  call void @__olang_scope_close(ptr %s0)
  %t136 = load %"compiler/generic:folded", ptr %l81
  store %"compiler/generic:folded" %t136, ptr %rv
  br label %ret
bb48:
  %t137 = getelementptr %"compiler/generic:folded", ptr %l6, i32 0, i32 1
  %t138 = load i64, ptr %t137, !tbaa !24
  store i64 %t138, ptr %l9, !tbaa !24
  %t140 = getelementptr %"compiler/generic:folded", ptr %l7, i32 0, i32 1
  %t141 = load i64, ptr %t140, !tbaa !24
  store i64 %t141, ptr %l10, !tbaa !24
  %t143 = load i32, ptr %l8, !tbaa !23
  %t144 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t147 = icmp ne i32 %t143, %t144
  br i1 %t147, label %bb49, label %bb50
bb49:
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t151 = getelementptr %"compiler/generic:Program", ptr %t149, i32 0, i32 2
  store ptr %t151, ptr %l89, !tbaa !29
  %t152 = load ptr, ptr %l0, !tbaa !29
  %t153 = load i32, ptr %l8, !tbaa !23
  %t156 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2enumberOf(ptr %v0, ptr %t152, i32 %t153)
  store i32 %t156, ptr %l92
  br label %bb51
bb50:
  store i1 false, ptr %l87, !tbaa !21
  br label %bb53
bb51:
  %t157 = load ptr, ptr %l89, !tbaa !29
  %t158 = load i32, ptr %l92, !tbaa !23
  %t159 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %t157, i32 %t158)
  store i1 %t159, ptr %l93
  br label %bb52
bb52:
  %t160 = load i1, ptr %l93, !tbaa !21
  store i1 %t160, ptr %l87, !tbaa !21
  br label %bb53
bb53:
  %t161 = load i1, ptr %l87, !tbaa !21
  store i1 %t161, ptr %l11, !tbaa !21
  %t162 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t164 = trunc i64 95 to i32
  %t165 = icmp eq i32 %t162, %t164
  br i1 %t165, label %bb54, label %bb55
bb54:
  store i1 true, ptr %l96, !tbaa !21
  br label %bb56
bb55:
  %t167 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t169 = trunc i64 96 to i32
  %t170 = icmp eq i32 %t167, %t169
  store i1 %t170, ptr %l96, !tbaa !21
  br label %bb56
bb56:
  %t172 = load i1, ptr %l96, !tbaa !21
  br i1 %t172, label %bb57, label %bb58
bb57:
  store i1 true, ptr %l99, !tbaa !21
  br label %bb59
bb58:
  %t173 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t175 = trunc i64 98 to i32
  %t176 = icmp eq i32 %t173, %t175
  store i1 %t176, ptr %l99, !tbaa !21
  br label %bb59
bb59:
  %t178 = load i1, ptr %l99, !tbaa !21
  br i1 %t178, label %bb60, label %bb61
bb60:
  store i1 true, ptr %l102, !tbaa !21
  br label %bb62
bb61:
  %t179 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t181 = trunc i64 99 to i32
  %t182 = icmp eq i32 %t179, %t181
  store i1 %t182, ptr %l102, !tbaa !21
  br label %bb62
bb62:
  %t184 = load i1, ptr %l102, !tbaa !21
  br i1 %t184, label %bb63, label %bb64
bb63:
  store i1 true, ptr %l105, !tbaa !21
  br label %bb65
bb64:
  %t185 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t187 = trunc i64 100 to i32
  %t188 = icmp eq i32 %t185, %t187
  store i1 %t188, ptr %l105, !tbaa !21
  br label %bb65
bb65:
  %t190 = load i1, ptr %l105, !tbaa !21
  br i1 %t190, label %bb66, label %bb67
bb66:
  store i1 true, ptr %l108, !tbaa !21
  br label %bb68
bb67:
  %t191 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t193 = trunc i64 101 to i32
  %t194 = icmp eq i32 %t191, %t193
  store i1 %t194, ptr %l108, !tbaa !21
  br label %bb68
bb68:
  %t196 = load i1, ptr %l108, !tbaa !21
  br i1 %t196, label %bb69, label %bb70
bb69:
  store %olang.scope zeroinitializer, ptr %s7
  %t197 = load i1, ptr %l11, !tbaa !21
  br i1 %t197, label %bb71, label %bb72
bb70:
  br label %bb109
bb71:
  %t199 = load i64, ptr %l9, !tbaa !24
  %t201 = load i64, ptr %l10, !tbaa !24
  %t205 = icmp ult i64 %t199, %t201
  store i1 %t205, ptr %l112, !tbaa !21
  br label %bb73
bb72:
  %t207 = load i64, ptr %l9, !tbaa !24
  %t208 = load i64, ptr %l10, !tbaa !24
  %t211 = icmp slt i64 %t207, %t208
  store i1 %t211, ptr %l112, !tbaa !21
  br label %bb73
bb73:
  %t213 = load i1, ptr %l112, !tbaa !21
  store i1 %t213, ptr %l12, !tbaa !21
  %t214 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t216 = trunc i64 95 to i32
  %t217 = icmp eq i32 %t214, %t216
  br i1 %t217, label %bb74, label %bb75
bb74:
  br label %bb76
bb75:
  br label %bb77
bb76:
  %t219 = load i64, ptr %l9, !tbaa !24
  %t220 = load i64, ptr %l10, !tbaa !24
  %t223 = icmp eq i64 %t219, %t220
  store i1 %t223, ptr %l121, !tbaa !21
  br label %bb104
bb77:
  %t225 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t227 = trunc i64 96 to i32
  %t228 = icmp eq i32 %t225, %t227
  br i1 %t228, label %bb78, label %bb79
bb78:
  br label %bb80
bb79:
  br label %bb81
bb80:
  %t230 = load i64, ptr %l9, !tbaa !24
  %t231 = load i64, ptr %l10, !tbaa !24
  %t234 = icmp ne i64 %t230, %t231
  store i1 %t234, ptr %l121, !tbaa !21
  br label %bb104
bb81:
  %t236 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t238 = trunc i64 98 to i32
  %t239 = icmp eq i32 %t236, %t238
  br i1 %t239, label %bb82, label %bb83
bb82:
  br label %bb84
bb83:
  br label %bb85
bb84:
  %t241 = load i1, ptr %l12, !tbaa !21
  store i1 %t241, ptr %l121, !tbaa !21
  br label %bb104
bb85:
  %t243 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t245 = trunc i64 99 to i32
  %t246 = icmp eq i32 %t243, %t245
  br i1 %t246, label %bb86, label %bb87
bb86:
  br label %bb88
bb87:
  br label %bb92
bb88:
  %t248 = load i1, ptr %l12, !tbaa !21
  br i1 %t248, label %bb89, label %bb90
bb89:
  store i1 true, ptr %l138, !tbaa !21
  br label %bb91
bb90:
  %t250 = load i64, ptr %l9, !tbaa !24
  %t251 = load i64, ptr %l10, !tbaa !24
  %t254 = icmp eq i64 %t250, %t251
  store i1 %t254, ptr %l138, !tbaa !21
  br label %bb91
bb91:
  %t256 = load i1, ptr %l138, !tbaa !21
  store i1 %t256, ptr %l121, !tbaa !21
  br label %bb104
bb92:
  %t257 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t259 = trunc i64 100 to i32
  %t260 = icmp eq i32 %t257, %t259
  br i1 %t260, label %bb93, label %bb94
bb93:
  br label %bb95
bb94:
  br label %bb99
bb95:
  %t262 = load i1, ptr %l12, !tbaa !21
  %t264 = xor i1 %t262, true
  br i1 %t264, label %bb96, label %bb97
bb96:
  %t266 = load i64, ptr %l9, !tbaa !24
  %t267 = load i64, ptr %l10, !tbaa !24
  %t270 = icmp ne i64 %t266, %t267
  store i1 %t270, ptr %l146, !tbaa !21
  br label %bb98
bb97:
  store i1 false, ptr %l146, !tbaa !21
  br label %bb98
bb98:
  %t272 = load i1, ptr %l146, !tbaa !21
  store i1 %t272, ptr %l121, !tbaa !21
  br label %bb104
bb99:
  br i1 true, label %bb100, label %bb101
bb100:
  br label %bb102
bb101:
  br label %bb103
bb102:
  %t273 = load i1, ptr %l12, !tbaa !21
  %t275 = xor i1 %t273, true
  store i1 %t275, ptr %l121, !tbaa !21
  br label %bb104
bb103:
  call void @__olang_check_failed(ptr @olang_loc_fa05ab364d453a8b_cb1072875564fc6f)
  unreachable
bb104:
  %t277 = load i1, ptr %l121, !tbaa !21
  %t278 = load i64, ptr @G_2ecompiler_2fgeneric_2eFolded, !tbaa !24
  store i64 %t278, ptr %l152, !tbaa !24
  br i1 %t277, label %bb105, label %bb106
bb105:
  store i64 1, ptr %l154, !tbaa !24
  br label %bb107
bb106:
  store i64 0, ptr %l154, !tbaa !24
  br label %bb107
bb107:
  %t281 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t282 = load i64, ptr %l152, !tbaa !24
  %t283 = load i64, ptr %l154, !tbaa !24
  %t285 = call %"compiler/generic:folded" @compiler_2fgeneric_3afolded_2ector(ptr %s7, i64 %t282, i64 %t283, i32 %t281)
  store %"compiler/generic:folded" %t285, ptr %l156
  br label %bb108
bb108:
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s0)
  %t286 = load %"compiler/generic:folded", ptr %l156
  store %"compiler/generic:folded" %t286, ptr %rv
  br label %ret
bb109:
  store i64 0, ptr %l14, !tbaa !24
  %t287 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t289 = trunc i64 68 to i32
  %t290 = icmp eq i32 %t287, %t289
  br i1 %t290, label %bb110, label %bb111
bb110:
  br label %bb112
bb111:
  br label %bb113
bb112:
  %t292 = load i64, ptr %l9, !tbaa !24
  %t293 = load i64, ptr %l10, !tbaa !24
  %t296 = add i64 %t292, %t293
  store i64 %t296, ptr %l14, !tbaa !24
  br label %bb200
bb113:
  %t298 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t300 = trunc i64 69 to i32
  %t301 = icmp eq i32 %t298, %t300
  br i1 %t301, label %bb114, label %bb115
bb114:
  br label %bb116
bb115:
  br label %bb117
bb116:
  %t303 = load i64, ptr %l9, !tbaa !24
  %t304 = load i64, ptr %l10, !tbaa !24
  %t307 = sub i64 %t303, %t304
  store i64 %t307, ptr %l14, !tbaa !24
  br label %bb200
bb117:
  %t309 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t311 = trunc i64 70 to i32
  %t312 = icmp eq i32 %t309, %t311
  br i1 %t312, label %bb118, label %bb119
bb118:
  br label %bb120
bb119:
  br label %bb121
bb120:
  %t314 = load i64, ptr %l9, !tbaa !24
  %t315 = load i64, ptr %l10, !tbaa !24
  %t318 = mul i64 %t314, %t315
  store i64 %t318, ptr %l14, !tbaa !24
  br label %bb200
bb121:
  %t320 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t322 = trunc i64 72 to i32
  %t323 = icmp eq i32 %t320, %t322
  br i1 %t323, label %bb122, label %bb123
bb122:
  br label %bb126
bb123:
  %t325 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t327 = trunc i64 73 to i32
  %t328 = icmp eq i32 %t325, %t327
  br i1 %t328, label %bb124, label %bb125
bb124:
  br label %bb126
bb125:
  br label %bb140
bb126:
  %t330 = load i64, ptr %l10, !tbaa !24
  %t332 = icmp eq i64 %t330, 0
  br i1 %t332, label %bb127, label %bb128
bb127:
  %t334 = call %"compiler/generic:folded" @compiler_2fgeneric_2efolded_2eunfolded()
  store %"compiler/generic:folded" %t334, ptr %l178
  br label %bb129
bb128:
  br label %bb130
bb129:
  call void @__olang_scope_close(ptr %s0)
  %t335 = load %"compiler/generic:folded", ptr %l178
  store %"compiler/generic:folded" %t335, ptr %rv
  br label %ret
bb130:
  %t336 = load i1, ptr %l11, !tbaa !21
  br i1 %t336, label %bb131, label %bb132
bb131:
  %t338 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t340 = trunc i64 72 to i32
  %t341 = icmp eq i32 %t338, %t340
  br i1 %t341, label %bb133, label %bb134
bb132:
  %t343 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t345 = trunc i64 72 to i32
  %t346 = icmp eq i32 %t343, %t345
  br i1 %t346, label %bb136, label %bb137
bb133:
  %t348 = load i64, ptr %l9, !tbaa !24
  %t350 = load i64, ptr %l10, !tbaa !24
  %t354 = udiv i64 %t348, %t350
  store i64 %t354, ptr %l182, !tbaa !24
  br label %bb135
bb134:
  %t357 = load i64, ptr %l9, !tbaa !24
  %t359 = load i64, ptr %l10, !tbaa !24
  %t363 = urem i64 %t357, %t359
  store i64 %t363, ptr %l182, !tbaa !24
  br label %bb135
bb135:
  %t366 = load i64, ptr %l182, !tbaa !24
  store i64 %t366, ptr %l14, !tbaa !24
  br label %bb139
bb136:
  %t367 = load i64, ptr %l9, !tbaa !24
  %t368 = load i64, ptr %l10, !tbaa !24
  %t371 = sdiv i64 %t367, %t368
  store i64 %t371, ptr %l197, !tbaa !24
  br label %bb138
bb137:
  %t373 = load i64, ptr %l9, !tbaa !24
  %t374 = load i64, ptr %l10, !tbaa !24
  %t377 = srem i64 %t373, %t374
  store i64 %t377, ptr %l197, !tbaa !24
  br label %bb138
bb138:
  %t379 = load i64, ptr %l197, !tbaa !24
  store i64 %t379, ptr %l14, !tbaa !24
  br label %bb139
bb139:
  br label %bb200
bb140:
  %t380 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t382 = trunc i64 102 to i32
  %t383 = icmp eq i32 %t380, %t382
  br i1 %t383, label %bb141, label %bb142
bb141:
  br label %bb143
bb142:
  br label %bb144
bb143:
  %t385 = load i64, ptr %l9, !tbaa !24
  %t386 = load i64, ptr %l10, !tbaa !24
  %t389 = and i64 %t385, %t386
  store i64 %t389, ptr %l14, !tbaa !24
  br label %bb200
bb144:
  %t391 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t393 = trunc i64 103 to i32
  %t394 = icmp eq i32 %t391, %t393
  br i1 %t394, label %bb145, label %bb146
bb145:
  br label %bb147
bb146:
  br label %bb148
bb147:
  %t396 = load i64, ptr %l9, !tbaa !24
  %t397 = load i64, ptr %l10, !tbaa !24
  %t400 = or i64 %t396, %t397
  store i64 %t400, ptr %l14, !tbaa !24
  br label %bb200
bb148:
  %t402 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t404 = trunc i64 104 to i32
  %t405 = icmp eq i32 %t402, %t404
  br i1 %t405, label %bb149, label %bb150
bb149:
  br label %bb151
bb150:
  br label %bb152
bb151:
  %t407 = load i64, ptr %l9, !tbaa !24
  %t408 = load i64, ptr %l10, !tbaa !24
  %t411 = xor i64 %t407, %t408
  store i64 %t411, ptr %l14, !tbaa !24
  br label %bb200
bb152:
  %t413 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t415 = trunc i64 108 to i32
  %t416 = icmp eq i32 %t413, %t415
  br i1 %t416, label %bb153, label %bb154
bb153:
  br label %bb157
bb154:
  %t418 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t420 = trunc i64 109 to i32
  %t421 = icmp eq i32 %t418, %t420
  br i1 %t421, label %bb155, label %bb156
bb155:
  br label %bb157
bb156:
  br label %bb187
bb157:
  %t423 = getelementptr %"compiler/generic:folded", ptr %l6, i32 0, i32 2
  %t424 = load i32, ptr %t423, !tbaa !23
  %t425 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t428 = icmp ne i32 %t424, %t425
  br i1 %t428, label %bb158, label %bb159
bb158:
  %t430 = getelementptr %"compiler/generic:folded", ptr %l6, i32 0, i32 2
  %t431 = load i32, ptr %t430, !tbaa !23
  store i32 %t431, ptr %l226, !tbaa !23
  br label %bb163
bb159:
  %t433 = getelementptr %"compiler/generic:folded", ptr %l7, i32 0, i32 2
  %t434 = load i32, ptr %t433, !tbaa !23
  %t435 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t438 = icmp eq i32 %t434, %t435
  br i1 %t438, label %bb160, label %bb161
bb160:
  %t440 = getelementptr %"compiler/generic:folded", ptr %l7, i32 0, i32 2
  %t441 = load i32, ptr %t440, !tbaa !23
  store i32 %t441, ptr %l231, !tbaa !23
  br label %bb162
bb161:
  %t443 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t443, ptr %l231, !tbaa !23
  br label %bb162
bb162:
  %t445 = load i32, ptr %l231, !tbaa !23
  store i32 %t445, ptr %l226, !tbaa !23
  br label %bb163
bb163:
  %t446 = load i32, ptr %l226, !tbaa !23
  store i32 %t446, ptr %l8, !tbaa !23
  %t447 = load i32, ptr %l8, !tbaa !23
  %t448 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t451 = icmp eq i32 %t447, %t448
  br i1 %t451, label %bb164, label %bb165
bb164:
  store i64 64, ptr %l237, !tbaa !24
  br label %bb168
bb165:
  %t453 = load ptr, ptr %l0, !tbaa !29
  %t455 = getelementptr %"compiler/generic:Program", ptr %t453, i32 0, i32 2
  store ptr %t455, ptr %l239, !tbaa !29
  %t456 = load ptr, ptr %l0, !tbaa !29
  %t457 = load i32, ptr %l8, !tbaa !23
  %t460 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2enumberOf(ptr %v0, ptr %t456, i32 %t457)
  store i32 %t460, ptr %l242
  br label %bb166
bb166:
  %t461 = load ptr, ptr %l239, !tbaa !29
  %t462 = load i32, ptr %l242, !tbaa !23
  %t463 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %t461, i32 %t462)
  store i64 %t463, ptr %l243
  br label %bb167
bb167:
  %t464 = load i64, ptr %l243, !tbaa !24
  store i64 %t464, ptr %l237, !tbaa !24
  br label %bb168
bb168:
  %t465 = load i64, ptr %l237, !tbaa !24
  store i64 %t465, ptr %l15, !tbaa !24
  %t466 = load i64, ptr %l10, !tbaa !24
  %t468 = icmp slt i64 %t466, 0
  br i1 %t468, label %bb169, label %bb170
bb169:
  store i1 true, ptr %l246, !tbaa !21
  br label %bb171
bb170:
  %t470 = load i64, ptr %l10, !tbaa !24
  %t471 = load i64, ptr %l15, !tbaa !24
  %t474 = icmp sge i64 %t470, %t471
  store i1 %t474, ptr %l246, !tbaa !21
  br label %bb171
bb171:
  %t476 = load i1, ptr %l246, !tbaa !21
  br i1 %t476, label %bb172, label %bb173
bb172:
  %t477 = call %"compiler/generic:folded" @compiler_2fgeneric_2efolded_2eunfolded()
  store %"compiler/generic:folded" %t477, ptr %l250
  br label %bb174
bb173:
  br label %bb175
bb174:
  call void @__olang_scope_close(ptr %s0)
  %t478 = load %"compiler/generic:folded", ptr %l250
  store %"compiler/generic:folded" %t478, ptr %rv
  br label %ret
bb175:
  %t479 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t481 = trunc i64 108 to i32
  %t482 = icmp eq i32 %t479, %t481
  br i1 %t482, label %bb176, label %bb177
bb176:
  %t484 = load i64, ptr %l9, !tbaa !24
  %t485 = load i64, ptr %l10, !tbaa !24
  store i64 %t485, ptr %l254, !tbaa !24
  %t487 = load i64, ptr %l254, !tbaa !24
  %t488 = load i64, ptr %l254, !tbaa !24
  %t489 = shl i64 %t484, %t488
  store i64 %t489, ptr %l14, !tbaa !24
  br label %bb186
bb177:
  %t491 = load i32, ptr %l8, !tbaa !23
  %t492 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t495 = icmp ne i32 %t491, %t492
  br i1 %t495, label %bb178, label %bb179
bb178:
  %t497 = load ptr, ptr %l0, !tbaa !29
  %t499 = getelementptr %"compiler/generic:Program", ptr %t497, i32 0, i32 2
  store ptr %t499, ptr %l261, !tbaa !29
  %t500 = load ptr, ptr %l0, !tbaa !29
  %t501 = load i32, ptr %l8, !tbaa !23
  %t504 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2enumberOf(ptr %v0, ptr %t500, i32 %t501)
  store i32 %t504, ptr %l264
  br label %bb180
bb179:
  store i1 false, ptr %l259, !tbaa !21
  br label %bb182
bb180:
  %t505 = load ptr, ptr %l261, !tbaa !29
  %t506 = load i32, ptr %l264, !tbaa !23
  %t507 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %t505, i32 %t506)
  store i1 %t507, ptr %l265
  br label %bb181
bb181:
  %t508 = load i1, ptr %l265, !tbaa !21
  store i1 %t508, ptr %l259, !tbaa !21
  br label %bb182
bb182:
  %t509 = load i1, ptr %l259, !tbaa !21
  br i1 %t509, label %bb183, label %bb184
bb183:
  %t510 = load i64, ptr %l9, !tbaa !24
  %t512 = load i64, ptr %l10, !tbaa !24
  store i64 %t512, ptr %l270, !tbaa !65
  %t515 = load i64, ptr %l270, !tbaa !65
  %t516 = load i64, ptr %l270, !tbaa !65
  %t517 = lshr i64 %t510, %t516
  store i64 %t517, ptr %l266, !tbaa !24
  br label %bb185
bb184:
  %t520 = load i64, ptr %l9, !tbaa !24
  %t521 = load i64, ptr %l10, !tbaa !24
  store i64 %t521, ptr %l274, !tbaa !24
  %t523 = load i64, ptr %l274, !tbaa !24
  %t524 = load i64, ptr %l274, !tbaa !24
  %t525 = ashr i64 %t520, %t524
  store i64 %t525, ptr %l266, !tbaa !24
  br label %bb185
bb185:
  %t527 = load i64, ptr %l266, !tbaa !24
  store i64 %t527, ptr %l14, !tbaa !24
  br label %bb186
bb186:
  br label %bb200
bb187:
  %t528 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t530 = trunc i64 47 to i32
  %t531 = icmp eq i32 %t528, %t530
  br i1 %t531, label %bb188, label %bb189
bb188:
  br label %bb190
bb189:
  br label %bb194
bb190:
  %t533 = load i64, ptr %l9, !tbaa !24
  %t535 = icmp ne i64 %t533, 0
  %t536 = load i64, ptr %l10, !tbaa !24
  %t538 = icmp ne i64 %t536, 0
  %t541 = icmp ne i1 %t535, %t538
  br i1 %t541, label %bb191, label %bb192
bb191:
  store i64 1, ptr %l283, !tbaa !24
  br label %bb193
bb192:
  store i64 0, ptr %l283, !tbaa !24
  br label %bb193
bb193:
  %t543 = load i64, ptr %l283, !tbaa !24
  store i64 %t543, ptr %l14, !tbaa !24
  br label %bb200
bb194:
  br i1 true, label %bb195, label %bb196
bb195:
  br label %bb197
bb196:
  br label %bb199
bb197:
  %t544 = call %"compiler/generic:folded" @compiler_2fgeneric_2efolded_2eunfolded()
  store %"compiler/generic:folded" %t544, ptr %l284
  br label %bb198
bb198:
  call void @__olang_scope_close(ptr %s0)
  %t545 = load %"compiler/generic:folded", ptr %l284
  store %"compiler/generic:folded" %t545, ptr %rv
  br label %ret
bb199:
  call void @__olang_check_failed(ptr @olang_loc_415c77be4516d04a_7550ee8386647fae)
  unreachable
bb200:
  %t546 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t548 = trunc i64 47 to i32
  %t549 = icmp eq i32 %t546, %t548
  br i1 %t549, label %bb201, label %bb202
bb201:
  store %olang.scope zeroinitializer, ptr %s30
  %t551 = load i64, ptr @G_2ecompiler_2fgeneric_2eFolded, !tbaa !24
  %t552 = load i64, ptr %l14, !tbaa !24
  %t553 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t557 = call %"compiler/generic:folded" @compiler_2fgeneric_3afolded_2ector(ptr %s30, i64 %t551, i64 %t552, i32 %t553)
  store %"compiler/generic:folded" %t557, ptr %l290
  br label %bb203
bb202:
  br label %bb204
bb203:
  call void @__olang_scope_close(ptr %s30)
  call void @__olang_scope_close(ptr %s0)
  %t558 = load %"compiler/generic:folded", ptr %l290
  store %"compiler/generic:folded" %t558, ptr %rv
  br label %ret
bb204:
  %t559 = load i64, ptr @G_2ecompiler_2fgeneric_2eFolded, !tbaa !24
  store i64 %t559, ptr %l291, !tbaa !24
  %t560 = load i32, ptr %l8, !tbaa !23
  %t561 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t564 = icmp ne i32 %t560, %t561
  br i1 %t564, label %bb205, label %bb206
bb205:
  %t566 = load ptr, ptr %l0, !tbaa !29
  %t567 = load i64, ptr %l14, !tbaa !24
  %t568 = load i32, ptr %l8, !tbaa !23
  %t572 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ewrap(ptr %v0, ptr %t566, i64 %t567, i32 %t568)
  store i64 %t572, ptr %l299
  br label %bb207
bb206:
  %t573 = load i64, ptr %l14, !tbaa !24
  store i64 %t573, ptr %l295, !tbaa !24
  br label %bb208
bb207:
  %t575 = load i64, ptr %l299, !tbaa !24
  store i64 %t575, ptr %l295, !tbaa !24
  br label %bb208
bb208:
  %t576 = load i32, ptr %l8, !tbaa !23
  %t577 = load i64, ptr %l291, !tbaa !24
  %t578 = load i64, ptr %l295, !tbaa !24
  %t580 = call %"compiler/generic:folded" @compiler_2fgeneric_3afolded_2ector(ptr %s0, i64 %t577, i64 %t578, i32 %t576)
  store %"compiler/generic:folded" %t580, ptr %l302
  br label %bb209
bb209:
  call void @__olang_scope_close(ptr %s0)
  %t581 = load %"compiler/generic:folded", ptr %l302
  store %"compiler/generic:folded" %t581, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/generic:folded", ptr %rv
  ret %"compiler/generic:folded" %rr
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2efields(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l9 = alloca %"std/prelude/iterator:ViewGenerator.00c7c71992d6e1815cd052c47b979cdd"
  %l10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i32
  %l18 = alloca ptr
  %l19 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l28 = alloca { i64, ptr }
  %l35 = alloca ptr
  %l37 = alloca i32
  %l43 = alloca i32
  %l47 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l54 = alloca %"std/prelude/iterator:ViewGenerator.00c7c71992d6e1815cd052c47b979cdd"
  %l55 = alloca ptr
  %l57 = alloca ptr
  %l58 = alloca i32
  %l60 = alloca i1
  %l67 = alloca i64
  %l70 = alloca i64
  %l96 = alloca ptr
  %l98 = alloca { i64, ptr }
  %l102 = alloca ptr
  %l103 = alloca ptr
  %l108 = alloca i32
  %l109 = alloca i32
  %l114 = alloca ptr
  %l115 = alloca ptr
  %l121 = alloca i32
  %l127 = alloca ptr
  %l129 = alloca { i64, ptr }
  %l133 = alloca i32
  %l134 = alloca i32
  %l137 = alloca { i64, ptr }
  %l140 = alloca i32
  %l141 = alloca i32
  %l145 = alloca { i64, ptr }
  %l155 = alloca ptr
  %l157 = alloca { i64, ptr }
  %l158 = alloca i32
  %s0 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %wh6 = alloca ptr
  %wc6 = alloca ptr
  %ws6 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_Hcd3bbe8e64537e19c3182f51d0fe16c9(ptr %s0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l19
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l19
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %l3
  %t3 = load ptr, ptr %l2, !tbaa !29
  %t5 = getelementptr %"compiler/ast:StructBody", ptr %t3, i32 0, i32 0
  %t6 = load { i64, ptr }, ptr %t5, !tbaa !27
  store { i64, ptr } %t6, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t8 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t8, 0
  store i64 %t10, ptr %l6, !tbaa !24
  br label %bb2
bb2:
  %t12 = load i64, ptr %l5, !tbaa !24
  %t13 = load i64, ptr %l6, !tbaa !24
  %t16 = icmp slt i64 %t12, %t13
  %t18 = xor i1 %t16, true
  br i1 %t18, label %bb3, label %bb4
bb3:
  br label %bb12
bb4:
  br label %bb5
bb5:
  %t20 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t20, ptr %l28, !tbaa !27
  %t21 = load i64, ptr %l5, !tbaa !24
  %t23 = getelementptr { i64, ptr }, ptr %l28, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !27
  %t25 = getelementptr ptr, ptr %t24, i64 %t21
  %t26 = load ptr, ptr %t25, !tbaa !39
  store ptr %t26, ptr %l7, !tbaa !29
  %t28 = load ptr, ptr %l7, !tbaa !29
  %t30 = getelementptr %"compiler/ast:Param", ptr %t28, i32 0, i32 2
  %t31 = load ptr, ptr %t30, !tbaa !29
  %t33 = icmp eq ptr %t31, null
  %t35 = xor i1 %t33, true
  br i1 %t35, label %bb6, label %bb7
bb6:
  store ptr %l3, ptr %l35, !tbaa !29
  %t37 = load ptr, ptr %l7, !tbaa !29
  %t39 = getelementptr %"compiler/ast:Param", ptr %t37, i32 0, i32 1
  %t40 = load i32, ptr %t39, !tbaa !23
  store i32 %t40, ptr %l37, !tbaa !23
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t42 = load ptr, ptr %l1, !tbaa !29
  %t43 = load ptr, ptr %l7, !tbaa !29
  %t45 = getelementptr %"compiler/ast:Param", ptr %t43, i32 0, i32 2
  %t46 = load ptr, ptr %t45, !tbaa !29
  %t51 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eResolve(ptr %v0, ptr %v1, ptr %v2, ptr %t41, ptr %t42, ptr %t46)
  store i32 %t51, ptr %l43
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t52 = load ptr, ptr %l35, !tbaa !29
  %t53 = load i32, ptr %l37, !tbaa !23
  %t54 = load i32, ptr %l43, !tbaa !23
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_H943a9bb03970f71acf57214091669a7d(ptr %s0, ptr %t52, i32 %t53, i32 %t54)
  br label %bb9
bb9:
  br label %bb10
bb10:
  br label %bb11
bb11:
  %t55 = load i64, ptr %l5, !tbaa !24
  %t58 = add i64 %t55, 1
  store i64 %t58, ptr %l5, !tbaa !24
  br label %bb2
bb12:
  %t60 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t60, ptr %l47
  br label %bb13
bb13:
  %t61 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l47
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t61, ptr %l8
  %t62 = load ptr, ptr %l2, !tbaa !29
  %t64 = getelementptr %"compiler/ast:StructBody", ptr %t62, i32 0, i32 2
  %t65 = load { i64, ptr }, ptr %t64, !tbaa !27
  %t67 = extractvalue { i64, ptr } %t65, 0
  %t69 = icmp eq i64 %t67, 0
  br i1 %t69, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  store %olang.scope zeroinitializer, ptr %s6
  %t72 = load ptr, ptr %l2, !tbaa !29
  %t74 = call %"std/prelude/iterator:ViewGenerator.00c7c71992d6e1815cd052c47b979cdd" @compiler_2fgeneric_2eFieldDecls.walk(ptr %v2, ptr %s6, ptr %t72)
  %t75 = extractvalue %"std/prelude/iterator:ViewGenerator.00c7c71992d6e1815cd052c47b979cdd" %t74, 0, 1
  %t76 = extractvalue %"std/prelude/iterator:ViewGenerator.00c7c71992d6e1815cd052c47b979cdd" %t74, 0, 0
  store ptr %t75, ptr %wh6
  store ptr %t76, ptr %wc6
  store %"std/prelude/iterator:ViewGenerator.00c7c71992d6e1815cd052c47b979cdd" %t74, ptr %l54
  br label %bb17
bb17:
  %t77 = load %"std/prelude/iterator:ViewGenerator.00c7c71992d6e1815cd052c47b979cdd", ptr %l54
  store %"std/prelude/iterator:ViewGenerator.00c7c71992d6e1815cd052c47b979cdd" %t77, ptr %l9
  br label %bb18
bb18:
  %t79 = call { i32, ptr } @std_2fprelude_2fiterator_2estd_2fprelude_2fiterator_3aViewGenerator_3ccompiler_2fast_3aV_Hf179e857cb72c72900f4614cd5df5a25(ptr %s6, ptr %l9)
  %t80 = extractvalue { i32, ptr } %t79, 1
  %t81 = extractvalue { i32, ptr } %t79, 0
  store i32 %t81, ptr %l58
  %t82 = icmp ne i32 %t81, 0
  br i1 %t82, label %bb20, label %ok.83, !prof !99
ok.83:
  store ptr %t80, ptr %l57
  br label %bb19
bb19:
  %t84 = load ptr, ptr %l57, !tbaa !29
  store ptr %t84, ptr %l55, !tbaa !29
  br label %bb22
bb20:
  %t85 = load i32, ptr %l58, !tbaa !23
  %t86 = ashr i32 %t85, 16
  %t88 = icmp eq i32 %t86, 1
  store i1 %t88, ptr %l60, !tbaa !21
  br label %bb21
bb21:
  br label %bb58
bb22:
  %t89 = load ptr, ptr %l55, !tbaa !29
  store ptr %t89, ptr %l10, !tbaa !29
  store i64 0, ptr %l11, !tbaa !24
  %t90 = load ptr, ptr %l10, !tbaa !29
  %t92 = getelementptr %"compiler/ast:VarDecl", ptr %t90, i32 0, i32 0
  %t93 = load { i64, ptr }, ptr %t92, !tbaa !27
  %t95 = extractvalue { i64, ptr } %t93, 0
  store i64 %t95, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t97 = load i64, ptr %l12, !tbaa !24
  %t98 = load i64, ptr %l11, !tbaa !24
  %t101 = icmp sgt i64 %t97, %t98
  br i1 %t101, label %bb23, label %bb24
bb23:
  %t103 = load i64, ptr %l13, !tbaa !24
  %t105 = icmp sgt i64 %t103, 0
  br i1 %t105, label %bb25, label %bb26
bb24:
  store i64 0, ptr %l67, !tbaa !24
  br label %bb28
bb25:
  %t107 = load i64, ptr %l12, !tbaa !24
  %t108 = load i64, ptr %l11, !tbaa !24
  %t111 = sub i64 %t107, %t108
  %t112 = load i64, ptr %l13, !tbaa !24
  %t115 = add i64 %t111, %t112
  %t117 = sub i64 %t115, 1
  %t118 = load i64, ptr %l13, !tbaa !24
  %t121 = sdiv i64 %t117, %t118
  store i64 %t121, ptr %l70, !tbaa !24
  br label %bb27
bb26:
  store i64 0, ptr %l70, !tbaa !24
  br label %bb27
bb27:
  %t123 = load i64, ptr %l70, !tbaa !24
  store i64 %t123, ptr %l67, !tbaa !24
  br label %bb28
bb28:
  %t124 = load i64, ptr %l67, !tbaa !24
  store i64 %t124, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb29
bb29:
  %t125 = load i64, ptr %l15, !tbaa !24
  %t126 = load i64, ptr %l14, !tbaa !24
  %t129 = icmp slt i64 %t125, %t126
  %t131 = xor i1 %t129, true
  br i1 %t131, label %bb30, label %bb31
bb30:
  br label %bb56
bb31:
  br label %bb32
bb32:
  %t133 = load i64, ptr %l11, !tbaa !24
  %t134 = load i64, ptr %l15, !tbaa !24
  %t135 = load i64, ptr %l13, !tbaa !24
  %t138 = mul i64 %t134, %t135
  %t141 = add i64 %t133, %t138
  store i64 %t141, ptr %l16, !tbaa !24
  %t143 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t143, ptr %l17, !tbaa !23
  %t145 = load ptr, ptr %l10, !tbaa !29
  %t147 = getelementptr %"compiler/ast:VarDecl", ptr %t145, i32 0, i32 4
  %t148 = load i1, ptr %t147, !tbaa !21
  br i1 %t148, label %bb33, label %bb34
bb33:
  %t150 = load i64, ptr %l16, !tbaa !24
  %t151 = load ptr, ptr %l10, !tbaa !29
  %t153 = getelementptr %"compiler/ast:VarDecl", ptr %t151, i32 0, i32 3
  %t154 = load { i64, ptr }, ptr %t153, !tbaa !27
  %t156 = extractvalue { i64, ptr } %t154, 0
  %t159 = icmp slt i64 %t150, %t156
  br i1 %t159, label %bb35, label %bb36
bb34:
  %t161 = load ptr, ptr %l10, !tbaa !29
  %t163 = getelementptr %"compiler/ast:VarDecl", ptr %t161, i32 0, i32 2
  %t164 = load ptr, ptr %t163, !tbaa !29
  %t166 = icmp eq ptr %t164, null
  %t168 = xor i1 %t166, true
  br i1 %t168, label %bb40, label %bb41
bb35:
  %t170 = load ptr, ptr %l10, !tbaa !29
  %t172 = getelementptr %"compiler/ast:VarDecl", ptr %t170, i32 0, i32 3
  %t173 = load { i64, ptr }, ptr %t172, !tbaa !27
  store { i64, ptr } %t173, ptr %l98, !tbaa !27
  %t174 = load i64, ptr %l16, !tbaa !24
  %t176 = getelementptr { i64, ptr }, ptr %l98, i32 0, i32 1
  %t177 = load ptr, ptr %t176, !tbaa !27
  %t178 = getelementptr ptr, ptr %t177, i64 %t174
  %t179 = load ptr, ptr %t178, !tbaa !39
  store ptr %t179, ptr %l96, !tbaa !29
  br label %bb37
bb36:
  store ptr null, ptr %l96, !tbaa !29
  br label %bb37
bb37:
  %t182 = load ptr, ptr %l96, !tbaa !29
  store ptr %t182, ptr %l18, !tbaa !29
  %t183 = load ptr, ptr %l0, !tbaa !29
  store ptr %t183, ptr %l102, !tbaa !29
  %t184 = load ptr, ptr %l18, !tbaa !29
  store ptr %t184, ptr %l103, !tbaa !29
  %t185 = load ptr, ptr %l0, !tbaa !29
  %t186 = load ptr, ptr %l1, !tbaa !29
  %t187 = load ptr, ptr %l18, !tbaa !29
  %t192 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInfer(ptr %v0, ptr %v1, ptr %s0, ptr %v2, ptr %t185, ptr %t186, ptr %l3, ptr %t187)
  store i32 %t192, ptr %l108
  br label %bb38
bb38:
  %t193 = load ptr, ptr %l102, !tbaa !29
  %t194 = load ptr, ptr %l103, !tbaa !29
  %t195 = load i32, ptr %l108, !tbaa !23
  %t196 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eslotOf(ptr %v0, ptr %v2, ptr %t193, ptr %t194, i32 %t195)
  store i32 %t196, ptr %l109
  br label %bb39
bb39:
  %t197 = load i32, ptr %l109, !tbaa !23
  store i32 %t197, ptr %l17, !tbaa !23
  br label %bb52
bb40:
  %t198 = load ptr, ptr %l0, !tbaa !29
  store ptr %t198, ptr %l114, !tbaa !29
  %t199 = load ptr, ptr %l1, !tbaa !29
  store ptr %t199, ptr %l115, !tbaa !29
  %t200 = load ptr, ptr %l0, !tbaa !29
  %t201 = load ptr, ptr %l1, !tbaa !29
  %t202 = load ptr, ptr %l10, !tbaa !29
  %t204 = getelementptr %"compiler/ast:VarDecl", ptr %t202, i32 0, i32 2
  %t205 = load ptr, ptr %t204, !tbaa !29
  %t210 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eResolve(ptr %v0, ptr %v1, ptr %v2, ptr %t200, ptr %t201, ptr %t205)
  store i32 %t210, ptr %l121
  br label %bb42
bb41:
  %t211 = load ptr, ptr %l10, !tbaa !29
  %t213 = getelementptr %"compiler/ast:VarDecl", ptr %t211, i32 0, i32 0
  %t214 = load { i64, ptr }, ptr %t213, !tbaa !27
  store { i64, ptr } %t214, ptr %l137, !tbaa !27
  %t215 = load i64, ptr %l16, !tbaa !24
  %t217 = getelementptr { i64, ptr }, ptr %l137, i32 0, i32 1
  %t218 = load ptr, ptr %t217, !tbaa !27
  %t219 = getelementptr i32, ptr %t218, i64 %t215
  %t220 = load i32, ptr %t219, !tbaa !33
  %t223 = call { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_Hfd0413fe7fd4e5914f6cad5b418b7a6d(ptr %s0, ptr %l3, i32 %t220)
  %t224 = extractvalue { i32, i32 } %t223, 1
  %t225 = extractvalue { i32, i32 } %t223, 0
  store i32 %t225, ptr %l141
  %t226 = icmp ne i32 %t225, 0
  br i1 %t226, label %bb48, label %ok.227, !prof !99
ok.227:
  store i32 %t224, ptr %l140
  br label %bb47
bb42:
  %t228 = load i64, ptr %l16, !tbaa !24
  %t229 = load ptr, ptr %l10, !tbaa !29
  %t231 = getelementptr %"compiler/ast:VarDecl", ptr %t229, i32 0, i32 3
  %t232 = load { i64, ptr }, ptr %t231, !tbaa !27
  %t234 = extractvalue { i64, ptr } %t232, 0
  %t237 = icmp slt i64 %t228, %t234
  br i1 %t237, label %bb43, label %bb44
bb43:
  %t239 = load ptr, ptr %l10, !tbaa !29
  %t241 = getelementptr %"compiler/ast:VarDecl", ptr %t239, i32 0, i32 3
  %t242 = load { i64, ptr }, ptr %t241, !tbaa !27
  store { i64, ptr } %t242, ptr %l129, !tbaa !27
  %t243 = load i64, ptr %l16, !tbaa !24
  %t245 = getelementptr { i64, ptr }, ptr %l129, i32 0, i32 1
  %t246 = load ptr, ptr %t245, !tbaa !27
  %t247 = getelementptr ptr, ptr %t246, i64 %t243
  %t248 = load ptr, ptr %t247, !tbaa !39
  store ptr %t248, ptr %l127, !tbaa !29
  br label %bb45
bb44:
  store ptr null, ptr %l127, !tbaa !29
  br label %bb45
bb45:
  %t251 = load ptr, ptr %l114, !tbaa !29
  %t252 = load ptr, ptr %l115, !tbaa !29
  %t253 = load i32, ptr %l121, !tbaa !23
  %t254 = load ptr, ptr %l127, !tbaa !29
  %t255 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eStorageOf(ptr %v0, ptr %v1, ptr %v2, ptr %t251, ptr %t252, i32 %t253, ptr %t254)
  store i32 %t255, ptr %l133
  br label %bb46
bb46:
  %t256 = load i32, ptr %l133, !tbaa !23
  store i32 %t256, ptr %l17, !tbaa !23
  br label %bb51
bb47:
  %t257 = load i32, ptr %l140, !tbaa !23
  store i32 %t257, ptr %l134, !tbaa !23
  br label %bb50
bb48:
  br label %bb49
bb49:
  %t258 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t258, ptr %l134, !tbaa !23
  br label %bb50
bb50:
  %t260 = load i32, ptr %l134, !tbaa !23
  store i32 %t260, ptr %l17, !tbaa !23
  br label %bb51
bb51:
  br label %bb52
bb52:
  %t261 = load ptr, ptr %l10, !tbaa !29
  %t263 = getelementptr %"compiler/ast:VarDecl", ptr %t261, i32 0, i32 0
  %t264 = load { i64, ptr }, ptr %t263, !tbaa !27
  store { i64, ptr } %t264, ptr %l145, !tbaa !27
  %t265 = load i64, ptr %l16, !tbaa !24
  %t267 = getelementptr { i64, ptr }, ptr %l145, i32 0, i32 1
  %t268 = load ptr, ptr %t267, !tbaa !27
  %t269 = getelementptr i32, ptr %t268, i64 %t265
  %t270 = load i32, ptr %t269, !tbaa !33
  %t271 = load i32, ptr %l17, !tbaa !23
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_H943a9bb03970f71acf57214091669a7d(ptr %s0, ptr %l3, i32 %t270, i32 %t271)
  br label %bb53
bb53:
  %t275 = load i32, ptr %l17, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %l8, i32 %t275)
  br label %bb54
bb54:
  br label %bb55
bb55:
  %t278 = load i64, ptr %l15, !tbaa !24
  %t281 = add i64 %t278, 1
  store i64 %t281, ptr %l15, !tbaa !24
  br label %bb29
bb56:
  br label %bb57
bb57:
  br label %bb18
bb58:
  store i32 0, ptr %ws6
  br label %wend6
wend6.c0:
  call void @__olang_scope_close(ptr %s6)
  %t283 = load ptr, ptr %l0, !tbaa !29
  %t285 = getelementptr %"compiler/generic:Program", ptr %t283, i32 0, i32 2
  store ptr %t285, ptr %l155, !tbaa !29
  %t287 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eToArray_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %s0, ptr %l8)
  store { i64, ptr } %t287, ptr %l157
  br label %bb59
bb59:
  %t288 = load ptr, ptr %l155, !tbaa !29
  %t289 = load { i64, ptr }, ptr %l157, !tbaa !27
  %t290 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s0, ptr %t288, { i64, ptr } %t289)
  store i32 %t290, ptr %l158
  br label %bb60
bb60:
  call void @__olang_scope_close(ptr %s0)
  %t291 = load i32, ptr %l158, !tbaa !23
  store i32 %t291, ptr %rv
  br label %ret
wend6:
  %t292 = load ptr, ptr %wh6
  %t293 = load ptr, ptr %wc6
  %t294 = call ptr @llvm.coro.promise(ptr %t292, i32 8, i1 false)
  %t295 = getelementptr { { i32, ptr }, i32 }, ptr %t294, i32 0, i32 1
  store i32 2, ptr %t295
  %t296 = call { i32, ptr } %t293(ptr %t292, ptr null)
  %t297 = load i32, ptr %ws6
  switch i32 %t297, label %wend6.c0 [ ]
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2efold(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l9 = alloca %"compiler/generic:folded"
  %l13 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  store ptr %t2, ptr %l5, !tbaa !29
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t4 = load ptr, ptr %l1, !tbaa !29
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t9 = call %"compiler/generic:folded" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eeval(ptr %v0, ptr %v1, ptr %v2, ptr %t3, ptr %t4, ptr %t5)
  store %"compiler/generic:folded" %t9, ptr %l9
  br label %bb1
bb1:
  %t11 = load ptr, ptr %l2, !tbaa !29
  %t13 = load ptr, ptr %l4, !tbaa !29
  %t14 = load ptr, ptr %l5, !tbaa !29
  %t15 = load %"compiler/generic:folded", ptr %l9
  %t18 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2econstOf(ptr %v0, ptr %v1, ptr %v2, ptr %t13, ptr %t14, %"compiler/generic:folded" %t15, i32 %a3, ptr %t11)
  store i32 %t18, ptr %l13
  br label %bb2
bb2:
  %t19 = load i32, ptr %l13, !tbaa !23
  store i32 %t19, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local %"compiler/generic:folded" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2efoldPath(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, %"compiler/source:Span" %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca { i64, ptr }
  %l4 = alloca i32
  %l5 = alloca i64
  %l6 = alloca %"compiler/names:Ref"
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l16 = alloca i32
  %l19 = alloca { i64, ptr }
  %l21 = alloca i32
  %l22 = alloca i32
  %l28 = alloca i32
  %l31 = alloca i64
  %l35 = alloca i64
  %l39 = alloca i32
  %l40 = alloca %"compiler/generic:folded"
  %l43 = alloca %"compiler/generic:folded"
  %l50 = alloca ptr
  %l54 = alloca i64
  %l56 = alloca %"compiler/names:Ref"
  %l60 = alloca %"compiler/generic:folded"
  %l68 = alloca i64
  %l71 = alloca i64
  %l91 = alloca { i64, ptr }
  %l94 = alloca i64
  %l97 = alloca %"compiler/generic:folded"
  %l103 = alloca { i64, ptr }
  %l108 = alloca %"compiler/generic:folded"
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca %"compiler/generic:folded"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 1
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load ptr, ptr %l1, !tbaa !29
  %t9 = getelementptr %"compiler/generic:Context", ptr %t7, i32 0, i32 2
  %t10 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t10, ptr %l19, !tbaa !27
  %t11 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t12 = load ptr, ptr %t11, !tbaa !27
  %t13 = getelementptr i32, ptr %t12, i64 0
  %t14 = load i32, ptr %t13, !tbaa !33
  %t17 = call { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_Hfd0413fe7fd4e5914f6cad5b418b7a6d(ptr %v1, ptr %t9, i32 %t14)
  %t18 = extractvalue { i32, i32 } %t17, 1
  %t19 = extractvalue { i32, i32 } %t17, 0
  store i32 %t19, ptr %l22
  %t20 = icmp ne i32 %t19, 0
  br i1 %t20, label %bb4, label %ok.21, !prof !99
ok.21:
  store i32 %t18, ptr %l21
  br label %bb3
bb2:
  br label %bb18
bb3:
  %t22 = load i32, ptr %l21, !tbaa !23
  store i32 %t22, ptr %l16, !tbaa !23
  br label %bb6
bb4:
  br label %bb5
bb5:
  store i32 -1, ptr %l16, !tbaa !23
  br label %bb6
bb6:
  %t23 = load i32, ptr %l16, !tbaa !23
  store i32 %t23, ptr %l4, !tbaa !23
  %t24 = load i32, ptr %l4, !tbaa !23
  %t26 = icmp sge i32 %t24, 0
  br i1 %t26, label %bb7, label %bb8
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/generic:Program", ptr %t28, i32 0, i32 2
  %t31 = load i32, ptr %l4, !tbaa !23
  %t34 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t30, i32 %t31)
  store i32 %t34, ptr %l28
  br label %bb9
bb8:
  br label %bb17
bb9:
  %t35 = load i32, ptr %l28, !range !{i32 0, i32 33}
  %t37 = trunc i64 26 to i32
  %t38 = icmp eq i32 %t35, %t37
  br i1 %t38, label %bb10, label %bb11
bb10:
  store %olang.scope zeroinitializer, ptr %s3
  %t40 = load i64, ptr @G_2ecompiler_2fgeneric_2eFolded, !tbaa !24
  store i64 %t40, ptr %l31, !tbaa !24
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/generic:Program", ptr %t41, i32 0, i32 2
  %t44 = load i32, ptr %l4, !tbaa !23
  %t47 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstValue(ptr %v0, ptr %t43, i32 %t44)
  store i64 %t47, ptr %l35
  br label %bb12
bb11:
  br label %bb15
bb12:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/generic:Program", ptr %t48, i32 0, i32 2
  %t51 = load i32, ptr %l4, !tbaa !23
  %t54 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstType(ptr %v0, ptr %t50, i32 %t51)
  store i32 %t54, ptr %l39
  br label %bb13
bb13:
  %t55 = load i64, ptr %l31, !tbaa !24
  %t56 = load i64, ptr %l35, !tbaa !24
  %t57 = load i32, ptr %l39, !tbaa !23
  %t58 = call %"compiler/generic:folded" @compiler_2fgeneric_3afolded_2ector(ptr %s3, i64 %t55, i64 %t56, i32 %t57)
  store %"compiler/generic:folded" %t58, ptr %l40
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  %t59 = load %"compiler/generic:folded", ptr %l40
  store %"compiler/generic:folded" %t59, ptr %rv
  br label %ret
bb15:
  %t60 = load i64, ptr @G_2ecompiler_2fgeneric_2ePending, !tbaa !24
  %t61 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t64 = call %"compiler/generic:folded" @compiler_2fgeneric_3afolded_2ector(ptr %s2, i64 %t60, i64 0, i32 %t61)
  store %"compiler/generic:folded" %t64, ptr %l43
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s2)
  %t65 = load %"compiler/generic:folded", ptr %l43
  store %"compiler/generic:folded" %t65, ptr %rv
  br label %ret
bb17:
  br label %bb18
bb18:
  %t66 = load ptr, ptr %l1, !tbaa !29
  %t68 = getelementptr %"compiler/generic:Context", ptr %t66, i32 0, i32 0
  %t69 = load i64, ptr %t68, !tbaa !24
  store i64 %t69, ptr %l5, !tbaa !24
  %t71 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t73 = extractvalue { i64, ptr } %t71, 0
  %t75 = icmp sgt i64 %t73, 1
  br i1 %t75, label %bb19, label %bb20
bb19:
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/generic:Program", ptr %t77, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !29
  store ptr %t80, ptr %l50, !tbaa !29
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t82 = load ptr, ptr %l1, !tbaa !29
  %t84 = getelementptr %"compiler/generic:Context", ptr %t82, i32 0, i32 0
  %t85 = load i64, ptr %t84, !tbaa !24
  %t88 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2efile(ptr %v0, ptr %t81, i64 %t85)
  store i64 %t88, ptr %l54
  br label %bb21
bb20:
  br label %bb44
bb21:
  %t89 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t90 = load i32, ptr %t89, !tbaa !23
  %t91 = load ptr, ptr %l50, !tbaa !29
  %t92 = load i64, ptr %l54, !tbaa !24
  %t94 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %t91, i64 %t92, i32 %t90)
  store %"compiler/names:Ref" %t94, ptr %l56
  br label %bb22
bb22:
  %t95 = load %"compiler/names:Ref", ptr %l56
  store %"compiler/names:Ref" %t95, ptr %l6
  %t96 = getelementptr %"compiler/names:Ref", ptr %l6, i32 0, i32 0
  %t97 = load i32, ptr %t96, !range !{i32 0, i32 9}
  %t99 = trunc i64 5 to i32
  %t100 = icmp eq i32 %t97, %t99
  %t102 = xor i1 %t100, true
  br i1 %t102, label %bb23, label %bb24
bb23:
  %t104 = call %"compiler/generic:folded" @compiler_2fgeneric_2efolded_2eunfolded()
  store %"compiler/generic:folded" %t104, ptr %l60
  br label %bb25
bb24:
  br label %bb26
bb25:
  %t105 = load %"compiler/generic:folded", ptr %l60
  store %"compiler/generic:folded" %t105, ptr %rv
  br label %ret
bb26:
  %t106 = getelementptr %"compiler/names:Ref", ptr %l6, i32 0, i32 1
  %t107 = load i64, ptr %t106, !tbaa !24
  store i64 %t107, ptr %l5, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t109 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t111 = extractvalue { i64, ptr } %t109, 0
  %t113 = sub i64 %t111, 1
  store i64 %t113, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t115 = load i64, ptr %l8, !tbaa !24
  %t116 = load i64, ptr %l7, !tbaa !24
  %t119 = icmp sgt i64 %t115, %t116
  br i1 %t119, label %bb27, label %bb28
bb27:
  %t121 = load i64, ptr %l9, !tbaa !24
  %t123 = icmp sgt i64 %t121, 0
  br i1 %t123, label %bb29, label %bb30
bb28:
  store i64 0, ptr %l68, !tbaa !24
  br label %bb32
bb29:
  %t125 = load i64, ptr %l8, !tbaa !24
  %t126 = load i64, ptr %l7, !tbaa !24
  %t129 = sub i64 %t125, %t126
  %t130 = load i64, ptr %l9, !tbaa !24
  %t133 = add i64 %t129, %t130
  %t135 = sub i64 %t133, 1
  %t136 = load i64, ptr %l9, !tbaa !24
  %t139 = sdiv i64 %t135, %t136
  store i64 %t139, ptr %l71, !tbaa !24
  br label %bb31
bb30:
  store i64 0, ptr %l71, !tbaa !24
  br label %bb31
bb31:
  %t141 = load i64, ptr %l71, !tbaa !24
  store i64 %t141, ptr %l68, !tbaa !24
  br label %bb32
bb32:
  %t142 = load i64, ptr %l68, !tbaa !24
  store i64 %t142, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb33
bb33:
  %t143 = load i64, ptr %l11, !tbaa !24
  %t144 = load i64, ptr %l10, !tbaa !24
  %t147 = icmp slt i64 %t143, %t144
  %t149 = xor i1 %t147, true
  br i1 %t149, label %bb34, label %bb35
bb34:
  br label %bb43
bb35:
  br label %bb36
bb36:
  %t151 = load i64, ptr %l7, !tbaa !24
  %t152 = load i64, ptr %l11, !tbaa !24
  %t153 = load i64, ptr %l9, !tbaa !24
  %t156 = mul i64 %t152, %t153
  %t159 = add i64 %t151, %t156
  %t161 = load ptr, ptr %l0, !tbaa !29
  %t162 = load i64, ptr %l5, !tbaa !24
  %t163 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t163, ptr %l91, !tbaa !27
  %t166 = getelementptr { i64, ptr }, ptr %l91, i32 0, i32 1
  %t167 = load ptr, ptr %t166, !tbaa !27
  %t168 = getelementptr i32, ptr %t167, i64 %t159
  %t169 = load i32, ptr %t168, !tbaa !33
  %t173 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ealiasStep(ptr %v0, ptr %t161, i64 %t162, i32 %t169)
  store i64 %t173, ptr %l94
  br label %bb37
bb37:
  %t174 = load i64, ptr %l94, !tbaa !24
  store i64 %t174, ptr %l5, !tbaa !24
  %t175 = load i64, ptr %l5, !tbaa !24
  %t177 = icmp slt i64 %t175, 0
  br i1 %t177, label %bb38, label %bb39
bb38:
  %t179 = call %"compiler/generic:folded" @compiler_2fgeneric_2efolded_2eunfolded()
  store %"compiler/generic:folded" %t179, ptr %l97
  br label %bb40
bb39:
  br label %bb41
bb40:
  %t180 = load %"compiler/generic:folded", ptr %l97
  store %"compiler/generic:folded" %t180, ptr %rv
  br label %ret
bb41:
  br label %bb42
bb42:
  %t181 = load i64, ptr %l11, !tbaa !24
  %t184 = add i64 %t181, 1
  store i64 %t184, ptr %l11, !tbaa !24
  br label %bb33
bb43:
  br label %bb44
bb44:
  %t186 = load ptr, ptr %l0, !tbaa !29
  %t187 = load i64, ptr %l5, !tbaa !24
  %t188 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t188, ptr %l103, !tbaa !27
  %t189 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t191 = extractvalue { i64, ptr } %t189, 0
  %t193 = sub i64 %t191, 1
  %t195 = getelementptr { i64, ptr }, ptr %l103, i32 0, i32 1
  %t196 = load ptr, ptr %t195, !tbaa !27
  %t197 = getelementptr i32, ptr %t196, i64 %t193
  %t198 = load i32, ptr %t197, !tbaa !33
  %t202 = call %"compiler/generic:folded" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2efoldGlobal(ptr %v0, ptr %t186, i64 %t187, i32 %t198)
  store %"compiler/generic:folded" %t202, ptr %l108
  br label %bb45
bb45:
  %t203 = load %"compiler/generic:folded", ptr %l108
  store %"compiler/generic:folded" %t203, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/generic:folded", ptr %rv
  ret %"compiler/generic:folded" %rr
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2egenericCall(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca %"compiler/names:Ref"
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca i32
  %l7 = alloca %"compiler/source:Span"
  %l8 = alloca i32
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l17 = alloca %"compiler/names:Ref"
  %l18 = alloca ptr
  %l19 = alloca i1
  %l27 = alloca ptr
  %l31 = alloca i64
  %l33 = alloca %"compiler/names:Ref"
  %l36 = alloca i1
  %l39 = alloca { i64, ptr }
  %l40 = alloca i1
  %l46 = alloca ptr
  %l49 = alloca { i64, ptr }
  %l52 = alloca i32
  %l53 = alloca i32
  %l54 = alloca ptr
  %l55 = alloca i1
  %l61 = alloca ptr
  %l65 = alloca i64
  %l67 = alloca %"compiler/names:Ref"
  %l71 = alloca i1
  %l78 = alloca i32
  %l82 = alloca i64
  %l86 = alloca i64
  %l90 = alloca i64
  %l99 = alloca i64
  %l102 = alloca i64
  %l120 = alloca i64
  %l123 = alloca { i64, ptr }
  %l127 = alloca i32
  %l131 = alloca ptr
  %l132 = alloca ptr
  %l133 = alloca i32
  %l137 = alloca i32
  %l138 = alloca i32
  %l139 = alloca i32
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t2 = call %"compiler/names:Ref" @compiler_2fnames_3aRef_2ector(ptr %s0, i32 0, i64 -1, i64 -1)
  store %"compiler/names:Ref" %t2, ptr %l17
  br label %bb1
bb1:
  %t3 = load %"compiler/names:Ref", ptr %l17
  store %"compiler/names:Ref" %t3, ptr %l4
  %t4 = load ptr, ptr %l2, !tbaa !29
  store ptr %t4, ptr %l18, !tbaa !29
  store i1 false, ptr %l19, !tbaa !21
  %t5 = load ptr, ptr %l18, !tbaa !29
  %t6 = icmp ne ptr %t5, null
  br i1 %t6, label %bb2, label %bb3
bb2:
  %t8 = load ptr, ptr %l18, !tbaa !29
  %t9 = load i64, ptr %t8, !range !{i64 0, i64 28}
  %t11 = icmp eq i64 %t9, 0
  store i1 %t11, ptr %l19, !tbaa !21
  br label %bb3
bb3:
  %t12 = load i1, ptr %l19, !tbaa !21
  br i1 %t12, label %bb4, label %bb5
bb4:
  %t13 = load ptr, ptr %l2, !tbaa !29
  %t15 = getelementptr { i64, [4 x i64] }, ptr %t13, i32 0, i32 1
  %t16 = getelementptr { %"compiler/source:Span", i32 }, ptr %t15, i32 0, i32 0
  %t17 = load %"compiler/source:Span", ptr %t16
  store %"compiler/source:Span" %t17, ptr %l5
  %t19 = load ptr, ptr %l2, !tbaa !29
  %t21 = getelementptr { i64, [4 x i64] }, ptr %t19, i32 0, i32 1
  %t22 = getelementptr { %"compiler/source:Span", i32 }, ptr %t21, i32 0, i32 1
  %t23 = load i32, ptr %t22
  store i32 %t23, ptr %l6, !tbaa !23
  br label %bb6
bb5:
  br label %bb22
bb6:
  store %olang.scope zeroinitializer, ptr %s1
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/generic:Program", ptr %t25, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !29
  store ptr %t28, ptr %l27, !tbaa !29
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t30 = load ptr, ptr %l1, !tbaa !29
  %t32 = getelementptr %"compiler/generic:Context", ptr %t30, i32 0, i32 0
  %t33 = load i64, ptr %t32, !tbaa !24
  %t36 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2efile(ptr %v0, ptr %t29, i64 %t33)
  store i64 %t36, ptr %l31
  br label %bb7
bb7:
  %t37 = getelementptr %"compiler/source:Span", ptr %l5, i32 0, i32 0
  %t38 = load i32, ptr %t37, !tbaa !23
  %t39 = load ptr, ptr %l27, !tbaa !29
  %t40 = load i64, ptr %l31, !tbaa !24
  %t42 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %t39, i64 %t40, i32 %t38)
  store %"compiler/names:Ref" %t42, ptr %l33
  br label %bb8
bb8:
  %t43 = load %"compiler/names:Ref", ptr %l33
  store %"compiler/names:Ref" %t43, ptr %l4
  %t44 = getelementptr %"compiler/names:Ref", ptr %l4, i32 0, i32 0
  %t45 = load i32, ptr %t44, !range !{i32 0, i32 9}
  %t47 = trunc i64 7 to i32
  %t48 = icmp eq i32 %t45, %t47
  br i1 %t48, label %bb9, label %bb10
bb9:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t51 = load i32, ptr %l6, !tbaa !23
  %t54 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2etext(ptr %v0, ptr %v0, ptr %t50, i32 %t51)
  store { i64, ptr } %t54, ptr %l39
  br label %bb11
bb10:
  store i1 false, ptr %l36, !tbaa !21
  br label %bb13
bb11:
  %t55 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t56 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s1, { i64, ptr } %t55, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d60, i32 0, i32 1) })
  store i1 %t56, ptr %l40
  br label %bb12
bb12:
  %t57 = load i1, ptr %l40, !tbaa !21
  store i1 %t57, ptr %l36, !tbaa !21
  br label %bb13
bb13:
  %t58 = load i1, ptr %l36, !tbaa !21
  br i1 %t58, label %bb14, label %bb15
bb14:
  %t59 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t61 = extractvalue { i64, ptr } %t59, 0
  %t63 = icmp ne i64 %t61, 1
  br i1 %t63, label %bb16, label %bb17
bb15:
  br label %bb21
bb16:
  %t65 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  store i32 %t65, ptr %rv
  br label %ret
bb17:
  br label %bb18
bb18:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/generic:Program", ptr %t67, i32 0, i32 2
  store ptr %t69, ptr %l46, !tbaa !29
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t71 = load ptr, ptr %l1, !tbaa !29
  %t72 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t72, ptr %l49, !tbaa !27
  %t73 = getelementptr { i64, ptr }, ptr %l49, i32 0, i32 1
  %t74 = load ptr, ptr %t73, !tbaa !27
  %t75 = getelementptr ptr, ptr %t74, i64 0
  %t76 = load ptr, ptr %t75, !tbaa !39
  %t81 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eResolve(ptr %v0, ptr %v1, ptr %v3, ptr %t70, ptr %t71, ptr %t76)
  store i32 %t81, ptr %l52
  br label %bb19
bb19:
  %t82 = load ptr, ptr %l46, !tbaa !29
  %t83 = load i32, ptr %l52, !tbaa !23
  %t84 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArray(ptr %v0, ptr %t82, i32 %t83, i32 0)
  store i32 %t84, ptr %l53
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t85 = load i32, ptr %l53, !tbaa !23
  store i32 %t85, ptr %rv
  br label %ret
bb21:
  call void @__olang_scope_close(ptr %s1)
  br label %bb35
bb22:
  %t86 = load ptr, ptr %l2, !tbaa !29
  store ptr %t86, ptr %l54, !tbaa !29
  store i1 false, ptr %l55, !tbaa !21
  %t87 = load ptr, ptr %l54, !tbaa !29
  %t88 = icmp ne ptr %t87, null
  br i1 %t88, label %bb23, label %bb24
bb23:
  %t90 = load ptr, ptr %l54, !tbaa !29
  %t91 = load i64, ptr %t90, !range !{i64 0, i64 28}
  %t93 = icmp eq i64 %t91, 12
  store i1 %t93, ptr %l55, !tbaa !21
  br label %bb24
bb24:
  %t94 = load i1, ptr %l55, !tbaa !21
  br i1 %t94, label %bb25, label %bb26
bb25:
  %t95 = load ptr, ptr %l2, !tbaa !29
  %t97 = getelementptr { i64, [4 x i64] }, ptr %t95, i32 0, i32 1
  %t98 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t97, i32 0, i32 0
  %t99 = load %"compiler/source:Span", ptr %t98
  store %"compiler/source:Span" %t99, ptr %l7
  br label %bb27
bb26:
  br label %bb30
bb27:
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t103 = getelementptr %"compiler/generic:Program", ptr %t101, i32 0, i32 1
  %t104 = load ptr, ptr %t103, !tbaa !29
  store ptr %t104, ptr %l61, !tbaa !29
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t106 = load ptr, ptr %l1, !tbaa !29
  %t108 = getelementptr %"compiler/generic:Context", ptr %t106, i32 0, i32 0
  %t109 = load i64, ptr %t108, !tbaa !24
  %t112 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2efile(ptr %v0, ptr %t105, i64 %t109)
  store i64 %t112, ptr %l65
  br label %bb28
bb28:
  %t113 = getelementptr %"compiler/source:Span", ptr %l7, i32 0, i32 1
  %t114 = load i32, ptr %t113, !tbaa !23
  %t115 = load ptr, ptr %l61, !tbaa !29
  %t116 = load i64, ptr %l65, !tbaa !24
  %t118 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eMember(ptr %v0, ptr %t115, i64 %t116, i32 %t114)
  store %"compiler/names:Ref" %t118, ptr %l67
  br label %bb29
bb29:
  %t119 = load %"compiler/names:Ref", ptr %l67
  store %"compiler/names:Ref" %t119, ptr %l4
  br label %bb35
bb30:
  br i1 true, label %bb31, label %bb32
bb31:
  br label %bb33
bb32:
  br label %bb34
bb33:
  br label %bb35
bb34:
  call void @__olang_check_failed(ptr @olang_loc_8c7d78b449474581_137735cf7503269d)
  unreachable
bb35:
  %t120 = getelementptr %"compiler/names:Ref", ptr %l4, i32 0, i32 0
  %t121 = load i32, ptr %t120, !range !{i32 0, i32 9}
  %t123 = trunc i64 4 to i32
  %t124 = icmp eq i32 %t121, %t123
  %t126 = xor i1 %t124, true
  br i1 %t126, label %bb36, label %bb37
bb36:
  store i1 true, ptr %l71, !tbaa !21
  br label %bb38
bb37:
  %t128 = getelementptr %"compiler/names:Ref", ptr %l4, i32 0, i32 2
  %t129 = load i64, ptr %t128, !tbaa !24
  %t131 = icmp slt i64 %t129, 0
  store i1 %t131, ptr %l71, !tbaa !21
  br label %bb38
bb38:
  %t133 = load i1, ptr %l71, !tbaa !21
  br i1 %t133, label %bb39, label %bb40
bb39:
  %t134 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t134, ptr %rv
  br label %ret
bb40:
  br label %bb41
bb41:
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t137 = getelementptr %"compiler/names:Ref", ptr %l4, i32 0, i32 1
  %t138 = load i64, ptr %t137, !tbaa !24
  %t139 = getelementptr %"compiler/names:Ref", ptr %l4, i32 0, i32 2
  %t140 = load i64, ptr %t139, !tbaa !24
  %t144 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclFor(ptr %v0, ptr %t136, i64 %t138, i64 %t140)
  store i32 %t144, ptr %l78
  br label %bb42
bb42:
  %t145 = load i32, ptr %l78, !tbaa !23
  store i32 %t145, ptr %l8, !tbaa !23
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t147 = load i32, ptr %l8, !tbaa !23
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2edeclVars(ptr %v0, ptr %t146, i32 %t147)
  br label %bb43
bb43:
  %t150 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t152 = extractvalue { i64, ptr } %t150, 0
  store i64 %t152, ptr %l82, !tbaa !24
  %t153 = load ptr, ptr %l0, !tbaa !29
  %t155 = getelementptr %"compiler/generic:Program", ptr %t153, i32 0, i32 2
  %t156 = load i32, ptr %l8, !tbaa !23
  %t159 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclParams(ptr %v0, ptr %t155, i32 %t156)
  store i64 %t159, ptr %l86
  br label %bb44
bb44:
  %t160 = load i64, ptr %l82, !tbaa !24
  %t161 = load i64, ptr %l86, !tbaa !24
  %t162 = icmp ne i64 %t160, %t161
  br i1 %t162, label %bb45, label %bb46
bb45:
  %t164 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t164, ptr %rv
  br label %ret
bb46:
  br label %bb47
bb47:
  %t166 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t168 = extractvalue { i64, ptr } %t166, 0
  store i64 %t168, ptr %l90, !tbaa !24
  %t169 = load i64, ptr %l90, !tbaa !24
  %t170 = icmp sge i64 %t169, 0
  br i1 %t170, label %bb48, label %bb49
bb48:
  %t172 = load i64, ptr %l90, !tbaa !24
  %t173 = icmp sle i64 %t172, 2305843009213693951
  br i1 %t173, label %bb50, label %bb51
bb49:
  call void @__olang_check_failed(ptr @olang_loc_bfcccee69af0f127_f3360b8adb85577b)
  unreachable
bb50:
  %t175 = load i64, ptr %l90, !tbaa !24
  %t176 = mul i64 %t175, 4
  %t177 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t176)
  %t178 = insertvalue { i64, ptr } undef, i64 %t175, 0
  %t179 = insertvalue { i64, ptr } %t178, ptr %t177, 1
  store { i64, ptr } %t179, ptr %l9, !tbaa !27
  store i64 0, ptr %l10, !tbaa !24
  %t181 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t183 = extractvalue { i64, ptr } %t181, 0
  store i64 %t183, ptr %l11, !tbaa !24
  store i64 1, ptr %l12, !tbaa !24
  %t185 = load i64, ptr %l11, !tbaa !24
  %t186 = load i64, ptr %l10, !tbaa !24
  %t189 = icmp sgt i64 %t185, %t186
  br i1 %t189, label %bb52, label %bb53
bb51:
  call void @__olang_check_failed(ptr @olang_loc_bfcccee69af0f127_f3360b8adb85577b)
  unreachable
bb52:
  %t191 = load i64, ptr %l12, !tbaa !24
  %t193 = icmp sgt i64 %t191, 0
  br i1 %t193, label %bb54, label %bb55
bb53:
  store i64 0, ptr %l99, !tbaa !24
  br label %bb57
bb54:
  %t195 = load i64, ptr %l11, !tbaa !24
  %t196 = load i64, ptr %l10, !tbaa !24
  %t199 = sub i64 %t195, %t196
  %t200 = load i64, ptr %l12, !tbaa !24
  %t203 = add i64 %t199, %t200
  %t205 = sub i64 %t203, 1
  %t206 = load i64, ptr %l12, !tbaa !24
  %t209 = sdiv i64 %t205, %t206
  store i64 %t209, ptr %l102, !tbaa !24
  br label %bb56
bb55:
  store i64 0, ptr %l102, !tbaa !24
  br label %bb56
bb56:
  %t211 = load i64, ptr %l102, !tbaa !24
  store i64 %t211, ptr %l99, !tbaa !24
  br label %bb57
bb57:
  %t212 = load i64, ptr %l99, !tbaa !24
  store i64 %t212, ptr %l13, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  br label %bb58
bb58:
  %t213 = load i64, ptr %l14, !tbaa !24
  %t214 = load i64, ptr %l13, !tbaa !24
  %t217 = icmp slt i64 %t213, %t214
  %t219 = xor i1 %t217, true
  br i1 %t219, label %bb59, label %bb60
bb59:
  br label %bb64
bb60:
  br label %bb61
bb61:
  %t221 = load i64, ptr %l10, !tbaa !24
  %t222 = load i64, ptr %l14, !tbaa !24
  %t223 = load i64, ptr %l12, !tbaa !24
  %t226 = mul i64 %t222, %t223
  %t229 = add i64 %t221, %t226
  store i64 %t229, ptr %l15, !tbaa !24
  %t231 = load i64, ptr %l15, !tbaa !24
  store i64 %t231, ptr %l120, !tbaa !24
  %t232 = load ptr, ptr %l0, !tbaa !29
  %t233 = load ptr, ptr %l1, !tbaa !29
  %t234 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t234, ptr %l123, !tbaa !27
  %t235 = load i64, ptr %l15, !tbaa !24
  %t237 = getelementptr { i64, ptr }, ptr %l123, i32 0, i32 1
  %t238 = load ptr, ptr %t237, !tbaa !27
  %t239 = getelementptr ptr, ptr %t238, i64 %t235
  %t240 = load ptr, ptr %t239, !tbaa !39
  %t245 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eResolve(ptr %v0, ptr %v1, ptr %v3, ptr %t232, ptr %t233, ptr %t240)
  store i32 %t245, ptr %l127
  br label %bb62
bb62:
  %t246 = load i32, ptr %l127, !tbaa !23
  %t247 = load i64, ptr %l120, !tbaa !24
  %t248 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t249 = load ptr, ptr %t248, !tbaa !27
  %t250 = getelementptr i32, ptr %t249, i64 %t247
  store i32 %t246, ptr %t250, !tbaa !33
  br label %bb63
bb63:
  %t251 = load i64, ptr %l14, !tbaa !24
  %t254 = add i64 %t251, 1
  store i64 %t254, ptr %l14, !tbaa !24
  br label %bb58
bb64:
  %t256 = load ptr, ptr %l0, !tbaa !29
  store ptr %t256, ptr %l131, !tbaa !29
  %t257 = load ptr, ptr %l0, !tbaa !29
  store ptr %t257, ptr %l132, !tbaa !29
  %t258 = load i32, ptr %l8, !tbaa !23
  store i32 %t258, ptr %l133, !tbaa !23
  %t259 = load ptr, ptr %l0, !tbaa !29
  %t261 = getelementptr %"compiler/generic:Program", ptr %t259, i32 0, i32 2
  %t262 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t265 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s0, ptr %t261, { i64, ptr } %t262)
  store i32 %t265, ptr %l137
  br label %bb65
bb65:
  %t266 = load ptr, ptr %l132, !tbaa !29
  %t267 = load i32, ptr %l133, !tbaa !23
  %t268 = load i32, ptr %l137, !tbaa !23
  %t269 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstance(ptr %v0, ptr %t266, i32 %t267, i32 %t268)
  store i32 %t269, ptr %l138
  br label %bb66
bb66:
  %t270 = load ptr, ptr %l131, !tbaa !29
  %t271 = load i32, ptr %l138, !tbaa !23
  %t272 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eheld(ptr %v0, ptr %t270, i32 %t271)
  store i32 %t272, ptr %l139
  br label %bb67
bb67:
  call void @__olang_scope_close(ptr %s0)
  %t273 = load i32, ptr %l139, !tbaa !23
  store i32 %t273, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eholdsItself(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca %"compiler/names:Entry"
  %l8 = alloca i32
  %l15 = alloca i32
  %l16 = alloca i1
  %l21 = alloca i1
  %l22 = alloca i32
  %l31 = alloca i64
  %l36 = alloca ptr
  %l38 = alloca ptr
  %l43 = alloca i64
  %l44 = alloca %"compiler/names:Entry"
  %l47 = alloca ptr
  %l51 = alloca { i64, [3 x i64] }
  %l56 = alloca { i64, ptr }
  %l58 = alloca { i64, ptr }
  %l60 = alloca %"compiler/diagmsg:Msg"
  %l61 = alloca i64
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/generic:Program", ptr %t1, i32 0, i32 2
  %t4 = load i32, ptr %l1, !tbaa !23
  %t7 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t3, i32 %t4)
  store i32 %t7, ptr %l8
  br label %bb1
bb1:
  %t8 = load i32, ptr %l8, !range !{i32 0, i32 33}
  %t10 = trunc i64 18 to i32
  %t11 = icmp eq i32 %t8, %t10
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb3:
  br label %bb4
bb4:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/generic:Program", ptr %t15, i32 0, i32 2
  %t18 = load i32, ptr %l1, !tbaa !23
  %t21 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t17, i32 %t18)
  store i32 %t21, ptr %l15
  br label %bb5
bb5:
  %t22 = load i32, ptr %l15, !tbaa !23
  store i32 %t22, ptr %l2, !tbaa !23
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/generic:Program", ptr %t23, i32 0, i32 56
  %t26 = load i32, ptr %l2, !tbaa !23
  %t28 = sext i32 %t26 to i64
  %t31 = call { i32, i1 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eGet_3cI64_2c_20Bool_3e(ptr %v0, ptr %t25, i64 %t28)
  %t32 = extractvalue { i32, i1 } %t31, 1
  %t33 = extractvalue { i32, i1 } %t31, 0
  store i32 %t33, ptr %l22
  %t34 = icmp ne i32 %t33, 0
  br i1 %t34, label %bb7, label %ok.35, !prof !99
ok.35:
  store i1 %t32, ptr %l21
  br label %bb6
bb6:
  %t36 = load i1, ptr %l21, !tbaa !21
  store i1 %t36, ptr %l16, !tbaa !21
  br label %bb9
bb7:
  br label %bb8
bb8:
  store i1 false, ptr %l16, !tbaa !21
  br label %bb9
bb9:
  %t37 = load i1, ptr %l16, !tbaa !21
  br i1 %t37, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb11:
  br label %bb12
bb12:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/generic:Program", ptr %t38, i32 0, i32 56
  %t41 = load i32, ptr %l2, !tbaa !23
  %t43 = sext i32 %t41 to i64
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t40, i64 %t43, i1 true)
  br label %bb13
bb13:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/generic:Program", ptr %t46, i32 0, i32 14
  %t49 = load i32, ptr %l2, !tbaa !23
  %t51 = sext i32 %t49 to i64
  %t54 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t48, i64 %t51)
  store i64 %t54, ptr %l31
  br label %bb14
bb14:
  %t55 = load i64, ptr %l31, !tbaa !24
  store i64 %t55, ptr %l3, !tbaa !24
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/generic:Program", ptr %t56, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !29
  %t61 = getelementptr %"compiler/names:Resolver", ptr %t59, i32 0, i32 1
  %t62 = load i64, ptr %l3, !tbaa !24
  %t65 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_Hc2ccbbc5952c057a60f016e9cc1626d2(ptr %v0, ptr %v0, ptr %t61, i64 %t62)
  store ptr %t65, ptr %l36
  br label %bb15
bb15:
  %t66 = load ptr, ptr %l36, !tbaa !29
  %t68 = getelementptr %"compiler/names:Table", ptr %t66, i32 0, i32 0
  store ptr %t68, ptr %l38, !tbaa !29
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/generic:Program", ptr %t69, i32 0, i32 15
  %t72 = load i32, ptr %l2, !tbaa !23
  %t74 = sext i32 %t72 to i64
  %t77 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t71, i64 %t74)
  store i64 %t77, ptr %l43
  br label %bb16
bb16:
  %t78 = load ptr, ptr %l38, !tbaa !29
  %t79 = load i64, ptr %l43, !tbaa !24
  %t80 = call %"compiler/names:Entry" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eAt_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %v0, ptr %t78, i64 %t79)
  store %"compiler/names:Entry" %t80, ptr %l44
  br label %bb17
bb17:
  %t81 = load %"compiler/names:Entry", ptr %l44
  store %"compiler/names:Entry" %t81, ptr %l4
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/generic:Program", ptr %t82, i32 0, i32 0
  %t85 = load ptr, ptr %t84, !tbaa !29
  %t87 = getelementptr %"compiler/load:Loader", ptr %t85, i32 0, i32 4
  %t88 = load ptr, ptr %t87, !tbaa !29
  store ptr %t88, ptr %l47, !tbaa !29
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t90 = load i64, ptr %l3, !tbaa !24
  %t91 = getelementptr %"compiler/names:Entry", ptr %l4, i32 0, i32 1
  %t92 = load %"compiler/source:Span", ptr %t91
  %t96 = call { i64, [3 x i64] } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eat(ptr %v0, ptr %t89, i64 %t90, %"compiler/source:Span" %t92)
  store { i64, [3 x i64] } %t96, ptr %l51
  br label %bb18
bb18:
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = getelementptr %"compiler/generic:Program", ptr %t97, i32 0, i32 2
  %t100 = load i32, ptr %l1, !tbaa !23
  %t102 = inttoptr i64 0 to ptr
  %t105 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %s0, ptr %t102, ptr %t99, i32 %t100)
  store { i64, ptr } %t105, ptr %l56
  br label %bb19
bb19:
  %t106 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t108 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %s0, ptr %s0, { i64, ptr } %t106)
  store { i64, ptr } %t108, ptr %l58
  br label %bb20
bb20:
  %t109 = load { i64, ptr }, ptr %l58, !tbaa !27
  %t111 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTypeHoldsItself(ptr %s0, ptr %v0, { i64, ptr } %t109)
  store %"compiler/diagmsg:Msg" %t111, ptr %l60
  br label %bb21
bb21:
  %t112 = load ptr, ptr %l47, !tbaa !29
  %t113 = load { i64, [3 x i64] }, ptr %l51
  %t114 = load %"compiler/diagmsg:Msg", ptr %l60
  %t115 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v0, ptr %t112, { i64, [3 x i64] } %t113, %"compiler/diagmsg:Msg" %t114)
  store i64 %t115, ptr %l61
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2emeet(ptr %v0, ptr %a0, %"compiler/generic:folded" %a1, %"compiler/generic:folded" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/generic:folded"
  %l2 = alloca %"compiler/generic:folded"
  %l6 = alloca i1
  %l17 = alloca i64
  %l20 = alloca i32
  %l22 = alloca ptr
  %l25 = alloca i32
  %l27 = alloca i32
  %l34 = alloca i64
  %l37 = alloca i32
  %l39 = alloca ptr
  %l40 = alloca i32
  %l43 = alloca i32
  %l44 = alloca i32
  %l48 = alloca i32
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store %"compiler/generic:folded" %a1, ptr %l1
  store %"compiler/generic:folded" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/generic:folded", ptr %l1, i32 0, i32 2
  %t2 = load i32, ptr %t1, !tbaa !23
  %t3 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t6 = icmp eq i32 %t2, %t3
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t8 = getelementptr %"compiler/generic:folded", ptr %l2, i32 0, i32 2
  %t9 = load i32, ptr %t8, !tbaa !23
  %t10 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t13 = icmp eq i32 %t9, %t10
  store i1 %t13, ptr %l6, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l6, !tbaa !21
  br label %bb3
bb3:
  %t15 = load i1, ptr %l6, !tbaa !21
  br i1 %t15, label %bb4, label %bb5
bb4:
  %t16 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t16, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t18 = getelementptr %"compiler/generic:folded", ptr %l1, i32 0, i32 2
  %t19 = load i32, ptr %t18, !tbaa !23
  %t20 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t23 = icmp eq i32 %t19, %t20
  br i1 %t23, label %bb7, label %bb8
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/generic:folded", ptr %l1, i32 0, i32 1
  %t27 = load i64, ptr %t26, !tbaa !24
  %t28 = getelementptr %"compiler/generic:folded", ptr %l2, i32 0, i32 2
  %t29 = load i32, ptr %t28, !tbaa !23
  %t33 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ewrap(ptr %v0, ptr %t25, i64 %t27, i32 %t29)
  store i64 %t33, ptr %l17
  br label %bb9
bb8:
  br label %bb15
bb9:
  %t34 = getelementptr %"compiler/generic:folded", ptr %l1, i32 0, i32 1
  %t35 = load i64, ptr %t34, !tbaa !24
  %t36 = load i64, ptr %l17, !tbaa !24
  %t38 = icmp eq i64 %t36, %t35
  br i1 %t38, label %bb10, label %bb11
bb10:
  %t40 = getelementptr %"compiler/generic:folded", ptr %l2, i32 0, i32 2
  %t41 = load i32, ptr %t40, !tbaa !23
  store i32 %t41, ptr %l20, !tbaa !23
  br label %bb14
bb11:
  %t43 = load ptr, ptr %l0, !tbaa !29
  store ptr %t43, ptr %l22, !tbaa !29
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/generic:Program", ptr %t44, i32 0, i32 2
  %t48 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s2, ptr %t46, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d61, i32 0, i32 1) })
  store i32 %t48, ptr %l25
  br label %bb12
bb12:
  %t49 = getelementptr %"compiler/generic:folded", ptr %l2, i32 0, i32 2
  %t50 = load i32, ptr %t49, !tbaa !23
  %t51 = load ptr, ptr %l22, !tbaa !29
  %t52 = load i32, ptr %l25, !tbaa !23
  %t54 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2emeetTyped(ptr %v0, ptr %t51, i32 %t52, i32 %t50)
  store i32 %t54, ptr %l27
  br label %bb13
bb13:
  %t55 = load i32, ptr %l27, !tbaa !23
  store i32 %t55, ptr %l20, !tbaa !23
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s2)
  %t56 = load i32, ptr %l20, !tbaa !23
  store i32 %t56, ptr %rv
  br label %ret
bb15:
  %t57 = getelementptr %"compiler/generic:folded", ptr %l2, i32 0, i32 2
  %t58 = load i32, ptr %t57, !tbaa !23
  %t59 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t62 = icmp eq i32 %t58, %t59
  br i1 %t62, label %bb16, label %bb17
bb16:
  store %olang.scope zeroinitializer, ptr %s3
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/generic:folded", ptr %l2, i32 0, i32 1
  %t66 = load i64, ptr %t65, !tbaa !24
  %t67 = getelementptr %"compiler/generic:folded", ptr %l1, i32 0, i32 2
  %t68 = load i32, ptr %t67, !tbaa !23
  %t72 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ewrap(ptr %v0, ptr %t64, i64 %t66, i32 %t68)
  store i64 %t72, ptr %l34
  br label %bb18
bb17:
  br label %bb24
bb18:
  %t73 = getelementptr %"compiler/generic:folded", ptr %l2, i32 0, i32 1
  %t74 = load i64, ptr %t73, !tbaa !24
  %t75 = load i64, ptr %l34, !tbaa !24
  %t77 = icmp eq i64 %t75, %t74
  br i1 %t77, label %bb19, label %bb20
bb19:
  %t79 = getelementptr %"compiler/generic:folded", ptr %l1, i32 0, i32 2
  %t80 = load i32, ptr %t79, !tbaa !23
  store i32 %t80, ptr %l37, !tbaa !23
  br label %bb23
bb20:
  %t82 = load ptr, ptr %l0, !tbaa !29
  store ptr %t82, ptr %l39, !tbaa !29
  %t83 = getelementptr %"compiler/generic:folded", ptr %l1, i32 0, i32 2
  %t84 = load i32, ptr %t83, !tbaa !23
  store i32 %t84, ptr %l40, !tbaa !23
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"compiler/generic:Program", ptr %t85, i32 0, i32 2
  %t89 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s3, ptr %t87, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d62, i32 0, i32 1) })
  store i32 %t89, ptr %l43
  br label %bb21
bb21:
  %t90 = load ptr, ptr %l39, !tbaa !29
  %t91 = load i32, ptr %l40, !tbaa !23
  %t92 = load i32, ptr %l43, !tbaa !23
  %t93 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2emeetTyped(ptr %v0, ptr %t90, i32 %t91, i32 %t92)
  store i32 %t93, ptr %l44
  br label %bb22
bb22:
  %t94 = load i32, ptr %l44, !tbaa !23
  store i32 %t94, ptr %l37, !tbaa !23
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s3)
  %t95 = load i32, ptr %l37, !tbaa !23
  store i32 %t95, ptr %rv
  br label %ret
bb24:
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t97 = getelementptr %"compiler/generic:folded", ptr %l1, i32 0, i32 2
  %t98 = load i32, ptr %t97, !tbaa !23
  %t99 = getelementptr %"compiler/generic:folded", ptr %l2, i32 0, i32 2
  %t100 = load i32, ptr %t99, !tbaa !23
  %t104 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2emeetTyped(ptr %v0, ptr %t96, i32 %t98, i32 %t100)
  store i32 %t104, ptr %l48
  br label %bb25
bb25:
  %t105 = load i32, ptr %l48, !tbaa !23
  store i32 %t105, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ementionsList(ptr %v0, ptr %a0, i32 %a1, i64 %a2, i64 %a3, i64 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l12 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l28 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/generic:Program", ptr %t1, i32 0, i32 2
  %t7 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t3, i32 %a1)
  store { i64, ptr } %t7, ptr %l12
  br label %bb1
bb1:
  %t8 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t8, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t9 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t9, 0
  store i64 %t11, ptr %l7, !tbaa !24
  br label %bb2
bb2:
  %t13 = load i64, ptr %l6, !tbaa !24
  %t14 = load i64, ptr %l7, !tbaa !24
  %t17 = icmp slt i64 %t13, %t14
  %t19 = xor i1 %t17, true
  br i1 %t19, label %bb3, label %bb4
bb3:
  br label %bb11
bb4:
  br label %bb5
bb5:
  %t21 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t21, ptr %l19, !tbaa !27
  %t22 = load i64, ptr %l6, !tbaa !24
  %t24 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = getelementptr i32, ptr %t25, i64 %t22
  %t27 = load i32, ptr %t26, !tbaa !33
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t35 = add i64 %a4, 1
  %t41 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ementionsVar(ptr %v0, ptr %t29, i32 %t27, i64 %a2, i64 %a3, i64 %t35)
  store i1 %t41, ptr %l28
  br label %bb6
bb6:
  %t42 = load i1, ptr %l28, !tbaa !21
  br i1 %t42, label %bb7, label %bb8
bb7:
  store i1 true, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t44 = load i64, ptr %l6, !tbaa !24
  %t47 = add i64 %t44, 1
  store i64 %t47, ptr %l6, !tbaa !24
  br label %bb2
bb11:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ementionsVar(ptr %v0, ptr %a0, i32 %a1, i64 %a2, i64 %a3, i64 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i32
  %l12 = alloca i32
  %l18 = alloca i64
  %l21 = alloca i1
  %l25 = alloca i64
  %l30 = alloca ptr
  %l34 = alloca i32
  %l39 = alloca i1
  %l42 = alloca ptr
  %l46 = alloca i32
  %l51 = alloca i1
  %l54 = alloca ptr
  %l58 = alloca i32
  %l63 = alloca i1
  %l66 = alloca ptr
  %l70 = alloca i32
  %l74 = alloca i1
  %l79 = alloca ptr
  %l83 = alloca i32
  %l87 = alloca i1
  %l90 = alloca ptr
  %l94 = alloca i32
  %l98 = alloca i1
  %l99 = alloca i1
  %l100 = alloca ptr
  %l104 = alloca i32
  %l109 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i64 %a2, ptr %l2
  store i64 %a3, ptr %l3
  store i64 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l4, !tbaa !24
  %t3 = icmp sgt i64 %t1, 32
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/generic:Program", ptr %t6, i32 0, i32 2
  %t9 = load i32, ptr %l1, !tbaa !23
  %t12 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t8, i32 %t9)
  store i32 %t12, ptr %l12
  br label %bb4
bb4:
  %t13 = load i32, ptr %l12, !range !{i32 0, i32 33}
  store i32 %t13, ptr %l5
  %t14 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t16 = trunc i64 25 to i32
  %t17 = icmp eq i32 %t14, %t16
  br i1 %t17, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb13
bb7:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/generic:Program", ptr %t19, i32 0, i32 2
  %t22 = load i32, ptr %l1, !tbaa !23
  %t25 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eA(ptr %v0, ptr %t21, i32 %t22)
  store i64 %t25, ptr %l18
  br label %bb8
bb8:
  %t26 = load i64, ptr %l2, !tbaa !24
  %t27 = load i64, ptr %l18, !tbaa !24
  %t29 = icmp eq i64 %t27, %t26
  br i1 %t29, label %bb9, label %bb10
bb9:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/generic:Program", ptr %t31, i32 0, i32 2
  %t34 = load i32, ptr %l1, !tbaa !23
  %t37 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eB(ptr %v0, ptr %t33, i32 %t34)
  store i64 %t37, ptr %l25
  br label %bb11
bb10:
  store i1 false, ptr %l21, !tbaa !21
  br label %bb12
bb11:
  %t38 = load i64, ptr %l3, !tbaa !24
  %t39 = load i64, ptr %l25, !tbaa !24
  %t41 = icmp eq i64 %t39, %t38
  store i1 %t41, ptr %l21, !tbaa !21
  br label %bb12
bb12:
  %t43 = load i1, ptr %l21, !tbaa !21
  store i1 %t43, ptr %rv
  br label %ret
bb13:
  %t44 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t46 = trunc i64 20 to i32
  %t47 = icmp eq i32 %t44, %t46
  br i1 %t47, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb19
bb16:
  %t49 = load ptr, ptr %l0, !tbaa !29
  store ptr %t49, ptr %l30, !tbaa !29
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/generic:Program", ptr %t50, i32 0, i32 2
  %t53 = load i32, ptr %l1, !tbaa !23
  %t56 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t52, i32 %t53)
  store i32 %t56, ptr %l34
  br label %bb17
bb17:
  %t57 = load i64, ptr %l2, !tbaa !24
  %t58 = load i64, ptr %l3, !tbaa !24
  %t59 = load i64, ptr %l4, !tbaa !24
  %t61 = add i64 %t59, 1
  %t62 = load ptr, ptr %l30, !tbaa !29
  %t63 = load i32, ptr %l34, !tbaa !23
  %t67 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ementionsVar(ptr %v0, ptr %t62, i32 %t63, i64 %t57, i64 %t58, i64 %t61)
  store i1 %t67, ptr %l39
  br label %bb18
bb18:
  %t68 = load i1, ptr %l39, !tbaa !21
  store i1 %t68, ptr %rv
  br label %ret
bb19:
  %t69 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t71 = trunc i64 19 to i32
  %t72 = icmp eq i32 %t69, %t71
  br i1 %t72, label %bb20, label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb25
bb22:
  %t74 = load ptr, ptr %l0, !tbaa !29
  store ptr %t74, ptr %l42, !tbaa !29
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = getelementptr %"compiler/generic:Program", ptr %t75, i32 0, i32 2
  %t78 = load i32, ptr %l1, !tbaa !23
  %t81 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t77, i32 %t78)
  store i32 %t81, ptr %l46
  br label %bb23
bb23:
  %t82 = load i64, ptr %l2, !tbaa !24
  %t83 = load i64, ptr %l3, !tbaa !24
  %t84 = load i64, ptr %l4, !tbaa !24
  %t86 = add i64 %t84, 1
  %t87 = load ptr, ptr %l42, !tbaa !29
  %t88 = load i32, ptr %l46, !tbaa !23
  %t92 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ementionsVar(ptr %v0, ptr %t87, i32 %t88, i64 %t82, i64 %t83, i64 %t86)
  store i1 %t92, ptr %l51
  br label %bb24
bb24:
  %t93 = load i1, ptr %l51, !tbaa !21
  store i1 %t93, ptr %rv
  br label %ret
bb25:
  %t94 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t96 = trunc i64 29 to i32
  %t97 = icmp eq i32 %t94, %t96
  br i1 %t97, label %bb26, label %bb27
bb26:
  br label %bb28
bb27:
  br label %bb31
bb28:
  %t99 = load ptr, ptr %l0, !tbaa !29
  store ptr %t99, ptr %l54, !tbaa !29
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t102 = getelementptr %"compiler/generic:Program", ptr %t100, i32 0, i32 2
  %t103 = load i32, ptr %l1, !tbaa !23
  %t106 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAnyTrait(ptr %v0, ptr %t102, i32 %t103)
  store i32 %t106, ptr %l58
  br label %bb29
bb29:
  %t107 = load i64, ptr %l2, !tbaa !24
  %t108 = load i64, ptr %l3, !tbaa !24
  %t109 = load i64, ptr %l4, !tbaa !24
  %t111 = add i64 %t109, 1
  %t112 = load ptr, ptr %l54, !tbaa !29
  %t113 = load i32, ptr %l58, !tbaa !23
  %t117 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ementionsVar(ptr %v0, ptr %t112, i32 %t113, i64 %t107, i64 %t108, i64 %t111)
  store i1 %t117, ptr %l63
  br label %bb30
bb30:
  %t118 = load i1, ptr %l63, !tbaa !21
  store i1 %t118, ptr %rv
  br label %ret
bb31:
  %t119 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t121 = trunc i64 18 to i32
  %t122 = icmp eq i32 %t119, %t121
  br i1 %t122, label %bb32, label %bb33
bb32:
  br label %bb34
bb33:
  br label %bb37
bb34:
  %t124 = load ptr, ptr %l0, !tbaa !29
  store ptr %t124, ptr %l66, !tbaa !29
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t127 = getelementptr %"compiler/generic:Program", ptr %t125, i32 0, i32 2
  %t128 = load i32, ptr %l1, !tbaa !23
  %t131 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %t127, i32 %t128)
  store i32 %t131, ptr %l70
  br label %bb35
bb35:
  %t132 = load i64, ptr %l2, !tbaa !24
  %t133 = load i64, ptr %l3, !tbaa !24
  %t134 = load i64, ptr %l4, !tbaa !24
  %t135 = load ptr, ptr %l66, !tbaa !29
  %t136 = load i32, ptr %l70, !tbaa !23
  %t140 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ementionsList(ptr %v0, ptr %t135, i32 %t136, i64 %t132, i64 %t133, i64 %t134)
  store i1 %t140, ptr %l74
  br label %bb36
bb36:
  %t141 = load i1, ptr %l74, !tbaa !21
  store i1 %t141, ptr %rv
  br label %ret
bb37:
  %t142 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t144 = trunc i64 22 to i32
  %t145 = icmp eq i32 %t142, %t144
  br i1 %t145, label %bb38, label %bb39
bb38:
  br label %bb42
bb39:
  %t147 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t149 = trunc i64 23 to i32
  %t150 = icmp eq i32 %t147, %t149
  br i1 %t150, label %bb40, label %bb41
bb40:
  br label %bb42
bb41:
  br label %bb45
bb42:
  %t152 = load ptr, ptr %l0, !tbaa !29
  store ptr %t152, ptr %l79, !tbaa !29
  %t153 = load ptr, ptr %l0, !tbaa !29
  %t155 = getelementptr %"compiler/generic:Program", ptr %t153, i32 0, i32 2
  %t156 = load i32, ptr %l1, !tbaa !23
  %t159 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t155, i32 %t156)
  store i32 %t159, ptr %l83
  br label %bb43
bb43:
  %t160 = load i64, ptr %l2, !tbaa !24
  %t161 = load i64, ptr %l3, !tbaa !24
  %t162 = load i64, ptr %l4, !tbaa !24
  %t163 = load ptr, ptr %l79, !tbaa !29
  %t164 = load i32, ptr %l83, !tbaa !23
  %t168 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ementionsList(ptr %v0, ptr %t163, i32 %t164, i64 %t160, i64 %t161, i64 %t162)
  store i1 %t168, ptr %l87
  br label %bb44
bb44:
  %t169 = load i1, ptr %l87, !tbaa !21
  store i1 %t169, ptr %rv
  br label %ret
bb45:
  %t170 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t172 = trunc i64 21 to i32
  %t173 = icmp eq i32 %t170, %t172
  br i1 %t173, label %bb46, label %bb47
bb46:
  br label %bb48
bb47:
  br label %bb56
bb48:
  %t175 = load ptr, ptr %l0, !tbaa !29
  store ptr %t175, ptr %l90, !tbaa !29
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t178 = getelementptr %"compiler/generic:Program", ptr %t176, i32 0, i32 2
  %t179 = load i32, ptr %l1, !tbaa !23
  %t182 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t178, i32 %t179)
  store i32 %t182, ptr %l94
  br label %bb49
bb49:
  %t183 = load i64, ptr %l2, !tbaa !24
  %t184 = load i64, ptr %l3, !tbaa !24
  %t185 = load i64, ptr %l4, !tbaa !24
  %t186 = load ptr, ptr %l90, !tbaa !29
  %t187 = load i32, ptr %l94, !tbaa !23
  %t191 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ementionsList(ptr %v0, ptr %t186, i32 %t187, i64 %t183, i64 %t184, i64 %t185)
  store i1 %t191, ptr %l98
  br label %bb50
bb50:
  %t192 = load i1, ptr %l98, !tbaa !21
  br i1 %t192, label %bb51, label %bb52
bb51:
  store i1 true, ptr %l99, !tbaa !21
  br label %bb55
bb52:
  %t193 = load ptr, ptr %l0, !tbaa !29
  store ptr %t193, ptr %l100, !tbaa !29
  %t194 = load ptr, ptr %l0, !tbaa !29
  %t196 = getelementptr %"compiler/generic:Program", ptr %t194, i32 0, i32 2
  %t197 = load i32, ptr %l1, !tbaa !23
  %t200 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t196, i32 %t197)
  store i32 %t200, ptr %l104
  br label %bb53
bb53:
  %t201 = load i64, ptr %l2, !tbaa !24
  %t202 = load i64, ptr %l3, !tbaa !24
  %t203 = load i64, ptr %l4, !tbaa !24
  %t205 = add i64 %t203, 1
  %t206 = load ptr, ptr %l100, !tbaa !29
  %t207 = load i32, ptr %l104, !tbaa !23
  %t211 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ementionsVar(ptr %v0, ptr %t206, i32 %t207, i64 %t201, i64 %t202, i64 %t205)
  store i1 %t211, ptr %l109
  br label %bb54
bb54:
  %t212 = load i1, ptr %l109, !tbaa !21
  store i1 %t212, ptr %l99, !tbaa !21
  br label %bb55
bb55:
  %t213 = load i1, ptr %l99, !tbaa !21
  store i1 %t213, ptr %rv
  br label %ret
bb56:
  br i1 true, label %bb57, label %bb58
bb57:
  br label %bb59
bb58:
  br label %bb60
bb59:
  store i1 false, ptr %rv
  br label %ret
bb60:
  call void @__olang_check_failed(ptr @olang_loc_536ccd1a63d69f5a_f4e0a4d3c2cbc46e)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2enoteRawType(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i32
  %l11 = alloca i32
  %l15 = alloca i32
  %l18 = alloca i1
  %l22 = alloca i32
  %l24 = alloca ptr
  %l28 = alloca i32
  %l32 = alloca i32
  %l36 = alloca i1
  %l38 = alloca ptr
  %l42 = alloca i32
  %l43 = alloca i32
  %l50 = alloca i32
  %l54 = alloca i32
  %l59 = alloca ptr
  %l62 = alloca i1
  %l68 = alloca ptr
  %l69 = alloca i1
  %l76 = alloca ptr
  %l79 = alloca %"compiler/generic:Context"
  %l83 = alloca i32
  %l85 = alloca ptr
  %l89 = alloca i32
  %l90 = alloca i1
  %l91 = alloca i1
  %l93 = alloca ptr
  %l97 = alloca i32
  %l98 = alloca i64
  %s5 = alloca %olang.scope
  %t142 = alloca %"compiler/generic:Context", align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/generic:Program", ptr %t1, i32 0, i32 2
  %t7 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t3, i32 %a1)
  store i32 %t7, ptr %l11
  br label %bb1
bb1:
  %t8 = load i32, ptr %l11, !tbaa !23
  store i32 %t8, ptr %l2, !tbaa !23
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/generic:Program", ptr %t9, i32 0, i32 2
  %t12 = load i32, ptr %l2, !tbaa !23
  %t15 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t11, i32 %t12)
  store i32 %t15, ptr %l15
  br label %bb2
bb2:
  %t16 = load i32, ptr %l15, !range !{i32 0, i32 33}
  %t18 = trunc i64 19 to i32
  %t19 = icmp eq i32 %t16, %t18
  br i1 %t19, label %bb3, label %bb4
bb3:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/generic:Program", ptr %t21, i32 0, i32 2
  %t24 = load i32, ptr %l2, !tbaa !23
  %t27 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t23, i32 %t24)
  store i32 %t27, ptr %l22
  br label %bb5
bb4:
  store i1 false, ptr %l18, !tbaa !21
  br label %bb6
bb5:
  %t28 = load i32, ptr %l22, !tbaa !23
  %t29 = icmp ne i32 %t28, 0
  store i1 %t29, ptr %l18, !tbaa !21
  br label %bb6
bb6:
  %t31 = load i1, ptr %l18, !tbaa !21
  br i1 %t31, label %bb7, label %bb8
bb7:
  %t32 = load ptr, ptr %l0, !tbaa !29
  store ptr %t32, ptr %l24, !tbaa !29
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/generic:Program", ptr %t33, i32 0, i32 2
  %t36 = load i32, ptr %l2, !tbaa !23
  %t39 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t35, i32 %t36)
  store i32 %t39, ptr %l28
  br label %bb9
bb8:
  br label %bb11
bb9:
  %t40 = load ptr, ptr %l24, !tbaa !29
  %t41 = load i32, ptr %l28, !tbaa !23
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2enoteRawType(ptr %v0, ptr %t40, i32 %t41)
  br label %bb10
bb10:
  br label %ret
bb11:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/generic:Program", ptr %t42, i32 0, i32 2
  %t45 = load i32, ptr %l2, !tbaa !23
  %t48 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t44, i32 %t45)
  store i32 %t48, ptr %l32
  br label %bb12
bb12:
  %t49 = load i32, ptr %l32, !range !{i32 0, i32 33}
  %t51 = trunc i64 18 to i32
  %t52 = icmp eq i32 %t49, %t51
  %t54 = xor i1 %t52, true
  br i1 %t54, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l36, !tbaa !21
  br label %bb17
bb14:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/generic:Program", ptr %t56, i32 0, i32 2
  store ptr %t58, ptr %l38, !tbaa !29
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/generic:Program", ptr %t59, i32 0, i32 2
  %t62 = load i32, ptr %l2, !tbaa !23
  %t65 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t61, i32 %t62)
  store i32 %t65, ptr %l42
  br label %bb15
bb15:
  %t66 = load ptr, ptr %l38, !tbaa !29
  %t67 = load i32, ptr %l42, !tbaa !23
  %t68 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t66, i32 %t67)
  store i32 %t68, ptr %l43
  br label %bb16
bb16:
  %t69 = load i32, ptr %l43, !range !{i32 0, i32 6}
  %t71 = trunc i64 1 to i32
  %t72 = icmp eq i32 %t69, %t71
  %t74 = xor i1 %t72, true
  store i1 %t74, ptr %l36, !tbaa !21
  br label %bb17
bb17:
  %t76 = load i1, ptr %l36, !tbaa !21
  br i1 %t76, label %bb18, label %bb19
bb18:
  br label %ret
bb19:
  br label %bb20
bb20:
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/generic:Program", ptr %t77, i32 0, i32 2
  %t80 = load i32, ptr %l2, !tbaa !23
  %t83 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t79, i32 %t80)
  store i32 %t83, ptr %l50
  br label %bb21
bb21:
  %t84 = load i32, ptr %l50, !tbaa !23
  store i32 %t84, ptr %l3, !tbaa !23
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"compiler/generic:Program", ptr %t85, i32 0, i32 2
  %t88 = load i32, ptr %l2, !tbaa !23
  %t91 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRawType(ptr %v0, ptr %t87, i32 %t88)
  store i32 %t91, ptr %l54
  br label %bb22
bb22:
  %t92 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t93 = load i32, ptr %l54, !tbaa !23
  %t95 = icmp ne i32 %t93, %t92
  br i1 %t95, label %bb23, label %bb24
bb23:
  br label %ret
bb24:
  br label %bb25
bb25:
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t98 = load i32, ptr %l3, !tbaa !23
  %t101 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2etypeDecl(ptr %v0, ptr %v0, ptr %t97, i32 %t98)
  store ptr %t101, ptr %l59
  br label %bb26
bb26:
  %t102 = load ptr, ptr %l59, !tbaa !29
  store ptr %t102, ptr %l4, !tbaa !29
  %t103 = load ptr, ptr %l4, !tbaa !29
  %t105 = icmp eq ptr %t103, null
  br i1 %t105, label %bb27, label %bb28
bb27:
  store i1 true, ptr %l62, !tbaa !21
  br label %bb29
bb28:
  %t107 = load ptr, ptr %l4, !tbaa !29
  %t109 = getelementptr %"compiler/ast:TypeDecl", ptr %t107, i32 0, i32 3
  %t110 = load ptr, ptr %t109, !tbaa !29
  %t112 = icmp eq ptr %t110, null
  store i1 %t112, ptr %l62, !tbaa !21
  br label %bb29
bb29:
  %t114 = load i1, ptr %l62, !tbaa !21
  br i1 %t114, label %bb30, label %bb31
bb30:
  br label %ret
bb31:
  br label %bb32
bb32:
  %t115 = load ptr, ptr %l4, !tbaa !29
  %t117 = getelementptr %"compiler/ast:TypeDecl", ptr %t115, i32 0, i32 3
  %t118 = load ptr, ptr %t117, !tbaa !29
  store ptr %t118, ptr %l5, !tbaa !29
  %t120 = load ptr, ptr %l5, !tbaa !29
  store ptr %t120, ptr %l68, !tbaa !29
  store i1 false, ptr %l69, !tbaa !21
  %t121 = load ptr, ptr %l68, !tbaa !29
  %t122 = icmp ne ptr %t121, null
  br i1 %t122, label %bb33, label %bb34
bb33:
  %t124 = load ptr, ptr %l68, !tbaa !29
  %t125 = load i64, ptr %t124, !range !{i64 0, i64 5}
  %t127 = icmp eq i64 %t125, 1
  store i1 %t127, ptr %l69, !tbaa !21
  br label %bb34
bb34:
  %t128 = load i1, ptr %l69, !tbaa !21
  br i1 %t128, label %bb35, label %bb36
bb35:
  %t129 = load ptr, ptr %l5, !tbaa !29
  %t131 = getelementptr { i64, [6 x i64] }, ptr %t129, i32 0, i32 1
  %t132 = getelementptr { { i64, ptr }, ptr }, ptr %t131, i32 0, i32 1
  %t133 = load ptr, ptr %t132
  store ptr %t133, ptr %l6, !tbaa !29
  br label %bb37
bb36:
  br label %bb54
bb37:
  store %olang.scope zeroinitializer, ptr %s5
  %t135 = load ptr, ptr %l6, !tbaa !29
  %t137 = icmp eq ptr %t135, null
  br i1 %t137, label %bb38, label %bb39
bb38:
  call void @__olang_scope_close(ptr %s5)
  br label %ret
bb39:
  br label %bb40
bb40:
  %t139 = load ptr, ptr %l0, !tbaa !29
  store ptr %t139, ptr %l76, !tbaa !29
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t141 = load i32, ptr %l3, !tbaa !23
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2edeclContext(ptr %t142, ptr %v0, ptr %s5, ptr %t140, i32 %t141)
  call void @llvm.memmove.p0.p0.i64(ptr %l79, ptr %t142, i64 160, i1 false)
  br label %bb41
bb41:
  %t145 = call ptr @__olang_scope_alloc_a(ptr %s5, i64 160, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t145, ptr %l79, i64 160, i1 false)
  %t146 = load ptr, ptr %l6, !tbaa !29
  %t148 = load ptr, ptr %l76, !tbaa !29
  %t151 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eResolve(ptr %v0, ptr %s5, ptr %v0, ptr %t148, ptr %t145, ptr %t146)
  store i32 %t151, ptr %l83
  br label %bb42
bb42:
  %t152 = load i32, ptr %l83, !tbaa !23
  store i32 %t152, ptr %l7, !tbaa !23
  %t153 = load ptr, ptr %l0, !tbaa !29
  %t155 = getelementptr %"compiler/generic:Program", ptr %t153, i32 0, i32 2
  store ptr %t155, ptr %l85, !tbaa !29
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t158 = getelementptr %"compiler/generic:Program", ptr %t156, i32 0, i32 2
  %t159 = load i32, ptr %l7, !tbaa !23
  %t162 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t158, i32 %t159)
  store i32 %t162, ptr %l89
  br label %bb43
bb43:
  %t163 = load ptr, ptr %l85, !tbaa !29
  %t164 = load i32, ptr %l89, !tbaa !23
  %t165 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %t163, i32 %t164)
  store i1 %t165, ptr %l90
  br label %bb44
bb44:
  %t166 = load i1, ptr %l90, !tbaa !21
  br i1 %t166, label %bb45, label %bb46
bb45:
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t169 = getelementptr %"compiler/generic:Program", ptr %t167, i32 0, i32 2
  store ptr %t169, ptr %l93, !tbaa !29
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t172 = getelementptr %"compiler/generic:Program", ptr %t170, i32 0, i32 2
  %t173 = load i32, ptr %l7, !tbaa !23
  %t176 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t172, i32 %t173)
  store i32 %t176, ptr %l97
  br label %bb47
bb46:
  store i1 false, ptr %l91, !tbaa !21
  br label %bb49
bb47:
  %t177 = load ptr, ptr %l93, !tbaa !29
  %t178 = load i32, ptr %l97, !tbaa !23
  %t179 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %t177, i32 %t178)
  store i64 %t179, ptr %l98
  br label %bb48
bb48:
  %t180 = load i64, ptr %l98, !tbaa !24
  %t181 = icmp sle i64 %t180, 64
  store i1 %t181, ptr %l91, !tbaa !21
  br label %bb49
bb49:
  %t183 = load i1, ptr %l91, !tbaa !21
  br i1 %t183, label %bb50, label %bb51
bb50:
  %t184 = load ptr, ptr %l0, !tbaa !29
  %t186 = getelementptr %"compiler/generic:Program", ptr %t184, i32 0, i32 2
  %t187 = load i32, ptr %l3, !tbaa !23
  %t188 = load i32, ptr %l7, !tbaa !23
  call void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSetRawType(ptr %v0, ptr %t186, i32 %t187, i32 %t188)
  br label %bb52
bb51:
  br label %bb53
bb52:
  br label %bb53
bb53:
  call void @__olang_scope_close(ptr %s5)
  br label %bb59
bb54:
  br i1 true, label %bb55, label %bb56
bb55:
  br label %bb57
bb56:
  br label %bb58
bb57:
  br label %bb59
bb58:
  call void @__olang_check_failed(ptr @olang_loc_a1c12b43cfcb5ca8_7f9e794136c316fc)
  unreachable
bb59:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2epromisesOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca i64
  %l29 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l30 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l39 = alloca { i64, ptr }
  %l44 = alloca i64
  %l51 = alloca ptr
  %l52 = alloca ptr
  %l53 = alloca ptr
  %l56 = alloca { i64, ptr }
  %l57 = alloca %"compiler/diagmsg:Msg"
  %l61 = alloca i1
  %l64 = alloca ptr
  %l65 = alloca ptr
  %l66 = alloca ptr
  %l67 = alloca %"compiler/diagmsg:Msg"
  %l71 = alloca i1
  %l74 = alloca i1
  %l76 = alloca ptr
  %l77 = alloca ptr
  %l78 = alloca ptr
  %l79 = alloca %"compiler/diagmsg:Msg"
  %l88 = alloca i64
  %l96 = alloca i1
  %l97 = alloca ptr
  %l98 = alloca ptr
  %l99 = alloca ptr
  %l102 = alloca { i64, ptr }
  %l104 = alloca { i64, ptr }
  %l107 = alloca %"compiler/diagmsg:Msg"
  %l110 = alloca i1
  %l112 = alloca ptr
  %l113 = alloca ptr
  %l114 = alloca ptr
  %l115 = alloca %"compiler/diagmsg:Msg"
  %l116 = alloca ptr
  %l118 = alloca ptr
  %l122 = alloca i32
  %l123 = alloca { i64, ptr }
  %l124 = alloca { i64, ptr }
  %l127 = alloca i1
  %l129 = alloca ptr
  %l130 = alloca ptr
  %l131 = alloca ptr
  %l134 = alloca { i64, ptr }
  %l136 = alloca { i64, ptr }
  %l137 = alloca %"compiler/diagmsg:Msg"
  %l146 = alloca { i64, ptr }
  %l151 = alloca i64
  %l156 = alloca i64
  %l159 = alloca i64
  %l180 = alloca i64
  %l183 = alloca i1
  %l188 = alloca i64
  %l191 = alloca i1
  %l196 = alloca i64
  %l199 = alloca ptr
  %l200 = alloca ptr
  %l201 = alloca ptr
  %l203 = alloca ptr
  %l205 = alloca ptr
  %l206 = alloca i32
  %l209 = alloca i64
  %l210 = alloca i32
  %l215 = alloca { i64, ptr }
  %l217 = alloca %"compiler/diagmsg:Msg"
  %l228 = alloca { i64, ptr }
  %l243 = alloca i1
  %l245 = alloca i64
  %l247 = alloca ptr
  %l248 = alloca ptr
  %l250 = alloca { i64, ptr }
  %l251 = alloca ptr
  %l252 = alloca %"compiler/diagmsg:Msg"
  %l254 = alloca ptr
  %l255 = alloca i64
  %l257 = alloca { i64, ptr }
  %l259 = alloca { i64, ptr }
  %l260 = alloca i64
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/ast:Sig", ptr %t1, i32 0, i32 7
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t8 = icmp eq i64 %t6, 0
  br i1 %t8, label %bb1, label %bb2
bb1:
  call void @__olang_scope_close(ptr %s0)
  store i64 0, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  store i64 0, ptr %l4, !tbaa !24
  %t11 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t11, ptr %l29
  br label %bb4
bb4:
  %t12 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l29
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t12, ptr %l5
  %t13 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t13, ptr %l30
  br label %bb5
bb5:
  %t14 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l30
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t14, ptr %l6
  %t15 = load ptr, ptr %l2, !tbaa !29
  %t17 = getelementptr %"compiler/ast:Sig", ptr %t15, i32 0, i32 7
  %t18 = load { i64, ptr }, ptr %t17, !tbaa !27
  store { i64, ptr } %t18, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t20 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t22 = extractvalue { i64, ptr } %t20, 0
  store i64 %t22, ptr %l9, !tbaa !24
  br label %bb6
bb6:
  store %olang.scope zeroinitializer, ptr %s3
  %t24 = load i64, ptr %l8, !tbaa !24
  %t25 = load i64, ptr %l9, !tbaa !24
  %t28 = icmp slt i64 %t24, %t25
  %t30 = xor i1 %t28, true
  br i1 %t30, label %bb7, label %bb8
bb7:
  call void @__olang_scope_close(ptr %s3)
  br label %bb109
bb8:
  br label %bb9
bb9:
  %t32 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t32, ptr %l39, !tbaa !27
  %t33 = load i64, ptr %l8, !tbaa !24
  %t35 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !27
  %t37 = getelementptr ptr, ptr %t36, i64 %t33
  %t38 = load ptr, ptr %t37, !tbaa !39
  store ptr %t38, ptr %l10, !tbaa !29
  %t40 = load ptr, ptr %l10, !tbaa !29
  %t42 = getelementptr %"compiler/ast:Promise", ptr %t40, i32 0, i32 1
  %t43 = load i32, ptr %t42, !range !{i32 0, i32 116}
  %t45 = call i64 @compiler_2fgeneric_2epromiseBit(i32 %t43)
  store i64 %t45, ptr %l44
  br label %bb10
bb10:
  %t46 = load i64, ptr %l44, !tbaa !24
  store i64 %t46, ptr %l11, !tbaa !24
  %t47 = load i64, ptr %l11, !tbaa !24
  %t49 = icmp ne i64 %t47, 0
  br i1 %t49, label %bb11, label %bb12
bb11:
  %t51 = load i64, ptr %l4, !tbaa !24
  %t52 = load i64, ptr %l11, !tbaa !24
  %t55 = and i64 %t51, %t52
  %t57 = icmp ne i64 %t55, 0
  br i1 %t57, label %bb13, label %bb14
bb12:
  br label %bb36
bb13:
  store %olang.scope zeroinitializer, ptr %s5
  %t59 = load ptr, ptr %l0, !tbaa !29
  store ptr %t59, ptr %l51, !tbaa !29
  %t60 = load ptr, ptr %l1, !tbaa !29
  store ptr %t60, ptr %l52, !tbaa !29
  %t61 = load ptr, ptr %l10, !tbaa !29
  store ptr %t61, ptr %l53, !tbaa !29
  %t62 = load ptr, ptr %l10, !tbaa !29
  %t64 = getelementptr %"compiler/ast:Promise", ptr %t62, i32 0, i32 1
  %t65 = load i32, ptr %t64, !range !{i32 0, i32 116}
  %t67 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s5, i32 %t65)
  store { i64, ptr } %t67, ptr %l56
  br label %bb15
bb14:
  br label %bb18
bb15:
  %t68 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t69 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePromiseTwice(ptr %s5, ptr %v0, { i64, ptr } %t68)
  store %"compiler/diagmsg:Msg" %t69, ptr %l57
  br label %bb16
bb16:
  %t70 = load ptr, ptr %l51, !tbaa !29
  %t71 = load ptr, ptr %l52, !tbaa !29
  %t72 = load ptr, ptr %l53, !tbaa !29
  %t73 = load %"compiler/diagmsg:Msg", ptr %l57
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2epromiseErr(ptr %v0, ptr %v1, ptr %v2, ptr %v0, ptr %t70, ptr %t71, ptr %t72, %"compiler/diagmsg:Msg" %t73)
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s5)
  br label %bb18
bb18:
  %t74 = load ptr, ptr %l10, !tbaa !29
  %t76 = getelementptr %"compiler/ast:Promise", ptr %t74, i32 0, i32 1
  %t77 = load i32, ptr %t76, !range !{i32 0, i32 116}
  %t79 = trunc i64 57 to i32
  %t80 = icmp eq i32 %t77, %t79
  br i1 %t80, label %bb19, label %bb20
bb19:
  %t82 = load ptr, ptr %l2, !tbaa !29
  %t84 = getelementptr %"compiler/ast:Sig", ptr %t82, i32 0, i32 4
  %t85 = load i1, ptr %t84, !tbaa !21
  store i1 %t85, ptr %l61, !tbaa !21
  br label %bb21
bb20:
  store i1 false, ptr %l61, !tbaa !21
  br label %bb21
bb21:
  %t87 = load i1, ptr %l61, !tbaa !21
  br i1 %t87, label %bb22, label %bb23
bb22:
  %t88 = load ptr, ptr %l0, !tbaa !29
  store ptr %t88, ptr %l64, !tbaa !29
  %t89 = load ptr, ptr %l1, !tbaa !29
  store ptr %t89, ptr %l65, !tbaa !29
  %t90 = load ptr, ptr %l10, !tbaa !29
  store ptr %t90, ptr %l66, !tbaa !29
  %t91 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePromiseReturnsNoreturn(ptr %v0)
  store %"compiler/diagmsg:Msg" %t91, ptr %l67
  br label %bb24
bb23:
  br label %bb26
bb24:
  %t92 = load ptr, ptr %l64, !tbaa !29
  %t93 = load ptr, ptr %l65, !tbaa !29
  %t94 = load ptr, ptr %l66, !tbaa !29
  %t95 = load %"compiler/diagmsg:Msg", ptr %l67
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2epromiseErr(ptr %v0, ptr %v1, ptr %v2, ptr %v0, ptr %t92, ptr %t93, ptr %t94, %"compiler/diagmsg:Msg" %t95)
  br label %bb25
bb25:
  br label %bb26
bb26:
  %t96 = load ptr, ptr %l10, !tbaa !29
  %t98 = getelementptr %"compiler/ast:Promise", ptr %t96, i32 0, i32 1
  %t99 = load i32, ptr %t98, !range !{i32 0, i32 116}
  %t101 = trunc i64 66 to i32
  %t102 = icmp eq i32 %t99, %t101
  br i1 %t102, label %bb27, label %bb28
bb27:
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t105 = load i32, ptr %l3, !tbaa !23
  %t108 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eresultMayHold(ptr %v0, ptr %t104, i32 %t105)
  store i1 %t108, ptr %l74
  br label %bb29
bb28:
  store i1 false, ptr %l71, !tbaa !21
  br label %bb30
bb29:
  %t109 = load i1, ptr %l74, !tbaa !21
  %t110 = xor i1 %t109, true
  store i1 %t110, ptr %l71, !tbaa !21
  br label %bb30
bb30:
  %t112 = load i1, ptr %l71, !tbaa !21
  br i1 %t112, label %bb31, label %bb32
bb31:
  store %olang.scope zeroinitializer, ptr %s7
  %t113 = load ptr, ptr %l0, !tbaa !29
  store ptr %t113, ptr %l76, !tbaa !29
  %t114 = load ptr, ptr %l1, !tbaa !29
  store ptr %t114, ptr %l77, !tbaa !29
  %t115 = load ptr, ptr %l10, !tbaa !29
  store ptr %t115, ptr %l78, !tbaa !29
  %t116 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePromiseBorrowsNothing(ptr %s7, ptr %v0, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d63, i32 0, i32 1) })
  store %"compiler/diagmsg:Msg" %t116, ptr %l79
  br label %bb33
bb32:
  br label %bb35
bb33:
  %t117 = load ptr, ptr %l76, !tbaa !29
  %t118 = load ptr, ptr %l77, !tbaa !29
  %t119 = load ptr, ptr %l78, !tbaa !29
  %t120 = load %"compiler/diagmsg:Msg", ptr %l79
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2epromiseErr(ptr %v0, ptr %v1, ptr %v2, ptr %v0, ptr %t117, ptr %t118, ptr %t119, %"compiler/diagmsg:Msg" %t120)
  br label %bb34
bb34:
  call void @__olang_scope_close(ptr %s7)
  br label %bb35
bb35:
  %t121 = load i64, ptr %l4, !tbaa !24
  %t123 = load i64, ptr %l11, !tbaa !24
  %t126 = or i64 %t121, %t123
  store i64 %t126, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb108
bb36:
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t129 = load ptr, ptr %l1, !tbaa !29
  %t130 = load ptr, ptr %l2, !tbaa !29
  %t131 = load ptr, ptr %l10, !tbaa !29
  %t136 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2epromiseParam(ptr %v0, ptr %v1, ptr %v2, ptr %v2, ptr %t128, ptr %t129, ptr %t130, ptr %t131, i64 0)
  store i64 %t136, ptr %l88
  br label %bb37
bb37:
  %t137 = load i64, ptr %l88, !tbaa !24
  store i64 %t137, ptr %l12, !tbaa !24
  %t138 = load i64, ptr %l12, !tbaa !24
  %t140 = icmp slt i64 %t138, 0
  br i1 %t140, label %bb38, label %bb39
bb38:
  call void @__olang_scope_close(ptr %s3)
  br label %bb108
bb39:
  br label %bb40
bb40:
  %t142 = load ptr, ptr %l10, !tbaa !29
  %t144 = getelementptr %"compiler/ast:Promise", ptr %t142, i32 0, i32 1
  %t145 = load i32, ptr %t144, !range !{i32 0, i32 116}
  %t147 = trunc i64 65 to i32
  %t148 = icmp eq i32 %t145, %t147
  br i1 %t148, label %bb41, label %bb42
bb41:
  %t150 = load i64, ptr %l12, !tbaa !24
  %t153 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eHas_3cI64_3e(ptr %s0, ptr %l5, i64 %t150)
  store i1 %t153, ptr %l96
  br label %bb43
bb42:
  br label %bb66
bb43:
  %t154 = load i1, ptr %l96, !tbaa !21
  br i1 %t154, label %bb44, label %bb45
bb44:
  store %olang.scope zeroinitializer, ptr %s10
  %t155 = load ptr, ptr %l0, !tbaa !29
  store ptr %t155, ptr %l97, !tbaa !29
  %t156 = load ptr, ptr %l1, !tbaa !29
  store ptr %t156, ptr %l98, !tbaa !29
  %t157 = load ptr, ptr %l10, !tbaa !29
  store ptr %t157, ptr %l99, !tbaa !29
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t159 = load ptr, ptr %l10, !tbaa !29
  %t161 = getelementptr %"compiler/ast:Promise", ptr %t159, i32 0, i32 2
  %t162 = load { i64, ptr }, ptr %t161, !tbaa !27
  store { i64, ptr } %t162, ptr %l102, !tbaa !27
  %t163 = getelementptr { i64, ptr }, ptr %l102, i32 0, i32 1
  %t164 = load ptr, ptr %t163, !tbaa !27
  %t165 = getelementptr i32, ptr %t164, i64 0
  %t166 = load i32, ptr %t165, !tbaa !33
  %t169 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2etext(ptr %v0, ptr %s10, ptr %t158, i32 %t166)
  store { i64, ptr } %t169, ptr %l104
  br label %bb46
bb45:
  br label %bb49
bb46:
  %t170 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d64, i32 0, i32 1) }, 1
  %t171 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d64, i32 0, i32 1) }, 0
  %t172 = load { i64, ptr }, ptr %l104, !tbaa !27
  %t173 = extractvalue { i64, ptr } %t172, 1
  %t174 = extractvalue { i64, ptr } %t172, 0
  %t175 = add i64 %t171, %t174
  %t176 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t175)
  call void @olang_textcopy(ptr %t176, ptr %t170, i64 %t171)
  %t177 = getelementptr i8, ptr %t176, i64 %t171
  call void @olang_textcopy(ptr %t177, ptr %t173, i64 %t174)
  %t178 = insertvalue { i64, ptr } undef, i64 %t175, 0
  %t179 = insertvalue { i64, ptr } %t178, ptr %t176, 1
  %t182 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePromiseTwice(ptr %s10, ptr %v0, { i64, ptr } %t179)
  store %"compiler/diagmsg:Msg" %t182, ptr %l107
  br label %bb47
bb47:
  %t183 = load ptr, ptr %l97, !tbaa !29
  %t184 = load ptr, ptr %l98, !tbaa !29
  %t185 = load ptr, ptr %l99, !tbaa !29
  %t186 = load %"compiler/diagmsg:Msg", ptr %l107
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2epromiseErr(ptr %v0, ptr %v1, ptr %v2, ptr %v0, ptr %t183, ptr %t184, ptr %t185, %"compiler/diagmsg:Msg" %t186)
  br label %bb48
bb48:
  call void @__olang_scope_close(ptr %s10)
  br label %bb49
bb49:
  %t187 = load ptr, ptr %l0, !tbaa !29
  %t188 = load i32, ptr %l3, !tbaa !23
  %t191 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eresultMayHold(ptr %v0, ptr %t187, i32 %t188)
  store i1 %t191, ptr %l110
  br label %bb50
bb50:
  %t192 = load i1, ptr %l110, !tbaa !21
  %t193 = xor i1 %t192, true
  br i1 %t193, label %bb51, label %bb52
bb51:
  store %olang.scope zeroinitializer, ptr %s12
  %t195 = load ptr, ptr %l0, !tbaa !29
  store ptr %t195, ptr %l112, !tbaa !29
  %t196 = load ptr, ptr %l1, !tbaa !29
  store ptr %t196, ptr %l113, !tbaa !29
  %t197 = load ptr, ptr %l10, !tbaa !29
  store ptr %t197, ptr %l114, !tbaa !29
  %t198 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePromiseBorrowsNothing(ptr %s12, ptr %v0, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d65, i32 0, i32 1) })
  store %"compiler/diagmsg:Msg" %t198, ptr %l115
  br label %bb53
bb52:
  store %olang.scope zeroinitializer, ptr %s13
  %t199 = load ptr, ptr %l0, !tbaa !29
  store ptr %t199, ptr %l116, !tbaa !29
  %t200 = load ptr, ptr %l0, !tbaa !29
  %t202 = getelementptr %"compiler/generic:Program", ptr %t200, i32 0, i32 2
  store ptr %t202, ptr %l118, !tbaa !29
  %t203 = load ptr, ptr %l0, !tbaa !29
  %t205 = getelementptr %"compiler/generic:Program", ptr %t203, i32 0, i32 2
  %t206 = load i32, ptr %l3, !tbaa !23
  %t209 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t205, i32 %t206)
  store i32 %t209, ptr %l122
  br label %bb55
bb53:
  %t210 = load ptr, ptr %l112, !tbaa !29
  %t211 = load ptr, ptr %l113, !tbaa !29
  %t212 = load ptr, ptr %l114, !tbaa !29
  %t213 = load %"compiler/diagmsg:Msg", ptr %l115
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2epromiseErr(ptr %v0, ptr %v1, ptr %v2, ptr %v0, ptr %t210, ptr %t211, ptr %t212, %"compiler/diagmsg:Msg" %t213)
  br label %bb54
bb54:
  call void @__olang_scope_close(ptr %s12)
  br label %bb64
bb55:
  %t214 = load ptr, ptr %l118, !tbaa !29
  %t215 = load i32, ptr %l122, !tbaa !23
  %t216 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s13, ptr %t214, i32 %t215)
  store { i64, ptr } %t216, ptr %l123
  br label %bb56
bb56:
  %t217 = load { i64, ptr }, ptr %l123, !tbaa !27
  store { i64, ptr } %t217, ptr %l124, !tbaa !27
  %t218 = load i64, ptr %l12, !tbaa !24
  %t220 = getelementptr { i64, ptr }, ptr %l124, i32 0, i32 1
  %t221 = load ptr, ptr %t220, !tbaa !27
  %t222 = getelementptr i32, ptr %t221, i64 %t218
  %t223 = load i32, ptr %t222, !tbaa !33
  %t224 = load ptr, ptr %l116, !tbaa !29
  %t226 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2emayHold(ptr %v0, ptr %t224, i32 %t223)
  store i1 %t226, ptr %l127
  br label %bb57
bb57:
  %t227 = load i1, ptr %l127, !tbaa !21
  %t228 = xor i1 %t227, true
  br i1 %t228, label %bb58, label %bb59
bb58:
  %t230 = load ptr, ptr %l0, !tbaa !29
  store ptr %t230, ptr %l129, !tbaa !29
  %t231 = load ptr, ptr %l1, !tbaa !29
  store ptr %t231, ptr %l130, !tbaa !29
  %t232 = load ptr, ptr %l10, !tbaa !29
  store ptr %t232, ptr %l131, !tbaa !29
  %t233 = load ptr, ptr %l0, !tbaa !29
  %t234 = load ptr, ptr %l10, !tbaa !29
  %t236 = getelementptr %"compiler/ast:Promise", ptr %t234, i32 0, i32 2
  %t237 = load { i64, ptr }, ptr %t236, !tbaa !27
  store { i64, ptr } %t237, ptr %l134, !tbaa !27
  %t238 = getelementptr { i64, ptr }, ptr %l134, i32 0, i32 1
  %t239 = load ptr, ptr %t238, !tbaa !27
  %t240 = getelementptr i32, ptr %t239, i64 0
  %t241 = load i32, ptr %t240, !tbaa !33
  %t244 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2etext(ptr %v0, ptr %v0, ptr %t233, i32 %t241)
  store { i64, ptr } %t244, ptr %l136
  br label %bb60
bb59:
  br label %bb63
bb60:
  %t245 = load { i64, ptr }, ptr %l136, !tbaa !27
  %t246 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePromiseBorrowsValue(ptr %v0, ptr %v0, { i64, ptr } %t245)
  store %"compiler/diagmsg:Msg" %t246, ptr %l137
  br label %bb61
bb61:
  %t247 = load ptr, ptr %l129, !tbaa !29
  %t248 = load ptr, ptr %l130, !tbaa !29
  %t249 = load ptr, ptr %l131, !tbaa !29
  %t250 = load %"compiler/diagmsg:Msg", ptr %l137
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2epromiseErr(ptr %v0, ptr %v1, ptr %v2, ptr %v0, ptr %t247, ptr %t248, ptr %t249, %"compiler/diagmsg:Msg" %t250)
  br label %bb62
bb62:
  br label %bb63
bb63:
  call void @__olang_scope_close(ptr %s13)
  br label %bb64
bb64:
  %t251 = load i64, ptr %l12, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l5, i64 %t251)
  br label %bb65
bb65:
  call void @__olang_scope_close(ptr %s3)
  br label %bb108
bb66:
  %t254 = load ptr, ptr %l0, !tbaa !29
  %t255 = load ptr, ptr %l1, !tbaa !29
  %t256 = load ptr, ptr %l2, !tbaa !29
  %t257 = load i32, ptr %l3, !tbaa !23
  %t258 = load ptr, ptr %l10, !tbaa !29
  %t259 = load i64, ptr %l12, !tbaa !24
  %t266 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ekeepsPromise(ptr %v0, ptr %v1, ptr %v2, ptr %v2, ptr %s3, ptr %t254, ptr %t255, ptr %t256, i32 %t257, ptr %t258, i64 %t259)
  store { i64, ptr } %t266, ptr %l146
  br label %bb67
bb67:
  %t267 = load { i64, ptr }, ptr %l146, !tbaa !27
  store { i64, ptr } %t267, ptr %l13, !tbaa !27
  %t268 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t270 = extractvalue { i64, ptr } %t268, 0
  %t272 = icmp eq i64 %t270, 0
  br i1 %t272, label %bb68, label %bb69
bb68:
  call void @__olang_scope_close(ptr %s3)
  br label %bb108
bb69:
  br label %bb70
bb70:
  store i64 0, ptr %l14, !tbaa !24
  %t275 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l6)
  store i64 %t275, ptr %l151
  br label %bb71
bb71:
  %t276 = load i64, ptr %l151, !tbaa !24
  %t277 = sdiv i64 %t276, 3
  store i64 %t277, ptr %l15, !tbaa !24
  store i64 1, ptr %l16, !tbaa !24
  %t279 = load i64, ptr %l15, !tbaa !24
  %t280 = load i64, ptr %l14, !tbaa !24
  %t283 = icmp sgt i64 %t279, %t280
  br i1 %t283, label %bb72, label %bb73
bb72:
  %t285 = load i64, ptr %l16, !tbaa !24
  %t287 = icmp sgt i64 %t285, 0
  br i1 %t287, label %bb74, label %bb75
bb73:
  store i64 0, ptr %l156, !tbaa !24
  br label %bb77
bb74:
  %t289 = load i64, ptr %l15, !tbaa !24
  %t290 = load i64, ptr %l14, !tbaa !24
  %t293 = sub i64 %t289, %t290
  %t294 = load i64, ptr %l16, !tbaa !24
  %t297 = add i64 %t293, %t294
  %t299 = sub i64 %t297, 1
  %t300 = load i64, ptr %l16, !tbaa !24
  %t303 = sdiv i64 %t299, %t300
  store i64 %t303, ptr %l159, !tbaa !24
  br label %bb76
bb75:
  store i64 0, ptr %l159, !tbaa !24
  br label %bb76
bb76:
  %t305 = load i64, ptr %l159, !tbaa !24
  store i64 %t305, ptr %l156, !tbaa !24
  br label %bb77
bb77:
  %t306 = load i64, ptr %l156, !tbaa !24
  store i64 %t306, ptr %l17, !tbaa !24
  store i64 0, ptr %l18, !tbaa !24
  br label %bb78
bb78:
  %t307 = load i64, ptr %l18, !tbaa !24
  %t308 = load i64, ptr %l17, !tbaa !24
  %t311 = icmp slt i64 %t307, %t308
  %t313 = xor i1 %t311, true
  br i1 %t313, label %bb79, label %bb80
bb79:
  br label %bb100
bb80:
  br label %bb81
bb81:
  %t315 = load i64, ptr %l14, !tbaa !24
  %t316 = load i64, ptr %l18, !tbaa !24
  %t317 = load i64, ptr %l16, !tbaa !24
  %t320 = mul i64 %t316, %t317
  %t323 = add i64 %t315, %t320
  store i64 %t323, ptr %l19, !tbaa !24
  %t325 = load i64, ptr %l19, !tbaa !24
  %t327 = mul i64 3, %t325
  %t330 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l6, i64 %t327)
  store i64 %t330, ptr %l180
  br label %bb82
bb82:
  %t331 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t332 = load ptr, ptr %t331, !tbaa !27
  %t333 = getelementptr i64, ptr %t332, i64 0
  %t334 = load i64, ptr %t333, !tbaa !34
  %t335 = load i64, ptr %l180, !tbaa !24
  %t337 = icmp eq i64 %t335, %t334
  br i1 %t337, label %bb83, label %bb84
bb83:
  %t339 = load i64, ptr %l19, !tbaa !24
  %t341 = mul i64 3, %t339
  %t343 = add i64 %t341, 1
  %t346 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l6, i64 %t343)
  store i64 %t346, ptr %l188
  br label %bb85
bb84:
  store i1 false, ptr %l183, !tbaa !21
  br label %bb86
bb85:
  %t347 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t348 = load ptr, ptr %t347, !tbaa !27
  %t349 = getelementptr i64, ptr %t348, i64 1
  %t350 = load i64, ptr %t349, !tbaa !34
  %t351 = load i64, ptr %l188, !tbaa !24
  %t353 = icmp eq i64 %t351, %t350
  store i1 %t353, ptr %l183, !tbaa !21
  br label %bb86
bb86:
  %t355 = load i1, ptr %l183, !tbaa !21
  br i1 %t355, label %bb87, label %bb88
bb87:
  %t356 = load i64, ptr %l19, !tbaa !24
  %t358 = mul i64 3, %t356
  %t360 = add i64 %t358, 2
  %t363 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l6, i64 %t360)
  store i64 %t363, ptr %l196
  br label %bb89
bb88:
  store i1 false, ptr %l191, !tbaa !21
  br label %bb90
bb89:
  %t364 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t365 = load ptr, ptr %t364, !tbaa !27
  %t366 = getelementptr i64, ptr %t365, i64 2
  %t367 = load i64, ptr %t366, !tbaa !34
  %t368 = load i64, ptr %l196, !tbaa !24
  %t370 = icmp eq i64 %t368, %t367
  store i1 %t370, ptr %l191, !tbaa !21
  br label %bb90
bb90:
  %t372 = load i1, ptr %l191, !tbaa !21
  br i1 %t372, label %bb91, label %bb92
bb91:
  store %olang.scope zeroinitializer, ptr %s18
  %t373 = load ptr, ptr %l0, !tbaa !29
  store ptr %t373, ptr %l199, !tbaa !29
  %t374 = load ptr, ptr %l1, !tbaa !29
  store ptr %t374, ptr %l200, !tbaa !29
  %t375 = load ptr, ptr %l10, !tbaa !29
  store ptr %t375, ptr %l201, !tbaa !29
  %t376 = load ptr, ptr %l0, !tbaa !29
  %t378 = getelementptr %"compiler/generic:Program", ptr %t376, i32 0, i32 2
  store ptr %t378, ptr %l203, !tbaa !29
  %t379 = load ptr, ptr %l0, !tbaa !29
  %t381 = getelementptr %"compiler/generic:Program", ptr %t379, i32 0, i32 2
  store ptr %t381, ptr %l205, !tbaa !29
  %t382 = load i32, ptr %l3, !tbaa !23
  store i32 %t382, ptr %l206, !tbaa !23
  %t383 = load ptr, ptr %l0, !tbaa !29
  %t384 = load ptr, ptr %l2, !tbaa !29
  %t387 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSigNames(ptr %v0, ptr %v2, ptr %t383, ptr %t384)
  store i64 %t387, ptr %l209
  br label %bb93
bb92:
  br label %bb98
bb93:
  %t388 = load ptr, ptr %l205, !tbaa !29
  %t389 = load i32, ptr %l206, !tbaa !23
  %t390 = load i64, ptr %l209, !tbaa !24
  %t391 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eWithNames(ptr %v0, ptr %t388, i32 %t389, i64 %t390)
  store i32 %t391, ptr %l210
  br label %bb94
bb94:
  %t392 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t393 = load ptr, ptr %t392, !tbaa !27
  %t394 = getelementptr i64, ptr %t393, i64 0
  %t395 = load i64, ptr %t394, !tbaa !34
  %t396 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t397 = load ptr, ptr %t396, !tbaa !27
  %t398 = getelementptr i64, ptr %t397, i64 1
  %t399 = load i64, ptr %t398, !tbaa !34
  %t400 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t401 = load ptr, ptr %t400, !tbaa !27
  %t402 = getelementptr i64, ptr %t401, i64 2
  %t403 = load i64, ptr %t402, !tbaa !34
  %t405 = inttoptr i64 0 to ptr
  %t406 = load ptr, ptr %l203, !tbaa !29
  %t407 = load i32, ptr %l210, !tbaa !23
  %t411 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKeepsText(ptr %v0, ptr %s18, ptr %t405, ptr %t406, i32 %t407, i64 %t395, i64 %t399, i64 %t403)
  store { i64, ptr } %t411, ptr %l215
  br label %bb95
bb95:
  %t412 = load { i64, ptr }, ptr %l215, !tbaa !27
  %t414 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePromiseTwice(ptr %s18, ptr %v0, { i64, ptr } %t412)
  store %"compiler/diagmsg:Msg" %t414, ptr %l217
  br label %bb96
bb96:
  %t415 = load ptr, ptr %l199, !tbaa !29
  %t416 = load ptr, ptr %l200, !tbaa !29
  %t417 = load ptr, ptr %l201, !tbaa !29
  %t418 = load %"compiler/diagmsg:Msg", ptr %l217
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2epromiseErr(ptr %v0, ptr %v1, ptr %v2, ptr %v0, ptr %t415, ptr %t416, ptr %t417, %"compiler/diagmsg:Msg" %t418)
  br label %bb97
bb97:
  call void @__olang_scope_close(ptr %s18)
  br label %bb98
bb98:
  br label %bb99
bb99:
  %t419 = load i64, ptr %l18, !tbaa !24
  %t422 = add i64 %t419, 1
  store i64 %t422, ptr %l18, !tbaa !24
  br label %bb78
bb100:
  %t424 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t424, ptr %l20, !tbaa !27
  store i64 0, ptr %l21, !tbaa !24
  %t426 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t428 = extractvalue { i64, ptr } %t426, 0
  store i64 %t428, ptr %l22, !tbaa !24
  br label %bb101
bb101:
  %t430 = load i64, ptr %l21, !tbaa !24
  %t431 = load i64, ptr %l22, !tbaa !24
  %t434 = icmp slt i64 %t430, %t431
  %t436 = xor i1 %t434, true
  br i1 %t436, label %bb102, label %bb103
bb102:
  br label %bb107
bb103:
  br label %bb104
bb104:
  %t438 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t438, ptr %l228, !tbaa !27
  %t439 = load i64, ptr %l21, !tbaa !24
  %t441 = getelementptr { i64, ptr }, ptr %l228, i32 0, i32 1
  %t442 = load ptr, ptr %t441, !tbaa !27
  %t443 = getelementptr i64, ptr %t442, i64 %t439
  %t444 = load i64, ptr %t443, !tbaa !34
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l6, i64 %t444)
  br label %bb105
bb105:
  br label %bb106
bb106:
  %t449 = load i64, ptr %l21, !tbaa !24
  %t452 = add i64 %t449, 1
  store i64 %t452, ptr %l21, !tbaa !24
  br label %bb101
bb107:
  call void @__olang_scope_close(ptr %s3)
  br label %bb108
bb108:
  %t454 = load i64, ptr %l8, !tbaa !24
  %t457 = add i64 %t454, 1
  store i64 %t457, ptr %l8, !tbaa !24
  br label %bb6
bb109:
  %t459 = load i64, ptr %l4, !tbaa !24
  %t460 = load i64, ptr @G_2ecompiler_2ftypes_2ePromNoborrow, !tbaa !24
  %t463 = and i64 %t459, %t460
  %t465 = icmp ne i64 %t463, 0
  br i1 %t465, label %bb110, label %bb111
bb110:
  %t468 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l5)
  store i64 %t468, ptr %l245
  br label %bb112
bb111:
  store i1 false, ptr %l243, !tbaa !21
  br label %bb113
bb112:
  %t469 = load i64, ptr %l245, !tbaa !24
  %t470 = icmp sgt i64 %t469, 0
  store i1 %t470, ptr %l243, !tbaa !21
  br label %bb113
bb113:
  %t472 = load i1, ptr %l243, !tbaa !21
  br i1 %t472, label %bb114, label %bb115
bb114:
  %t473 = load ptr, ptr %l0, !tbaa !29
  store ptr %t473, ptr %l247, !tbaa !29
  %t474 = load ptr, ptr %l1, !tbaa !29
  store ptr %t474, ptr %l248, !tbaa !29
  %t475 = load ptr, ptr %l2, !tbaa !29
  %t477 = getelementptr %"compiler/ast:Sig", ptr %t475, i32 0, i32 7
  %t478 = load { i64, ptr }, ptr %t477, !tbaa !27
  store { i64, ptr } %t478, ptr %l250, !tbaa !27
  %t479 = getelementptr { i64, ptr }, ptr %l250, i32 0, i32 1
  %t480 = load ptr, ptr %t479, !tbaa !27
  %t481 = getelementptr ptr, ptr %t480, i64 0
  %t482 = load ptr, ptr %t481, !tbaa !39
  store ptr %t482, ptr %l251, !tbaa !29
  %t483 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePromiseBorrowsBoth(ptr %v0)
  store %"compiler/diagmsg:Msg" %t483, ptr %l252
  br label %bb116
bb115:
  br label %bb118
bb116:
  %t484 = load ptr, ptr %l247, !tbaa !29
  %t485 = load ptr, ptr %l248, !tbaa !29
  %t486 = load ptr, ptr %l251, !tbaa !29
  %t487 = load %"compiler/diagmsg:Msg", ptr %l252
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2epromiseErr(ptr %v0, ptr %v1, ptr %v2, ptr %v0, ptr %t484, ptr %t485, ptr %t486, %"compiler/diagmsg:Msg" %t487)
  br label %bb117
bb117:
  br label %bb118
bb118:
  %t488 = load ptr, ptr %l0, !tbaa !29
  %t490 = getelementptr %"compiler/generic:Program", ptr %t488, i32 0, i32 2
  store ptr %t490, ptr %l254, !tbaa !29
  %t491 = load i64, ptr %l4, !tbaa !24
  store i64 %t491, ptr %l255, !tbaa !24
  %t493 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eToArray_3cI64_3e(ptr %s0, ptr %s0, ptr %l5)
  store { i64, ptr } %t493, ptr %l257
  br label %bb119
bb119:
  %t495 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eToArray_3cI64_3e(ptr %s0, ptr %s0, ptr %l6)
  store { i64, ptr } %t495, ptr %l259
  br label %bb120
bb120:
  %t496 = load ptr, ptr %l254, !tbaa !29
  %t497 = load i64, ptr %l255, !tbaa !24
  %t498 = load { i64, ptr }, ptr %l257, !tbaa !27
  %t499 = load { i64, ptr }, ptr %l259, !tbaa !27
  %t500 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePromises(ptr %v0, ptr %s0, ptr %s0, ptr %t496, i64 %t497, { i64, ptr } %t498, { i64, ptr } %t499)
  store i64 %t500, ptr %l260
  br label %bb121
bb121:
  call void @__olang_scope_close(ptr %s0)
  %t501 = load i64, ptr %l260, !tbaa !24
  store i64 %t501, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ereachesDefault(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l14 = alloca i64
  %l17 = alloca i64
  %l38 = alloca i1
  %l42 = alloca i1
  %l48 = alloca i32
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i32 %a1, ptr %l3, !tbaa !23
  store i64 0, ptr %l4, !tbaa !24
  store i64 16, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t3 = load i64, ptr %l5, !tbaa !24
  %t4 = load i64, ptr %l4, !tbaa !24
  %t7 = icmp sgt i64 %t3, %t4
  br i1 %t7, label %bb1, label %bb2
bb1:
  %t9 = load i64, ptr %l6, !tbaa !24
  %t11 = icmp sgt i64 %t9, 0
  br i1 %t11, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l14, !tbaa !24
  br label %bb6
bb3:
  %t13 = load i64, ptr %l5, !tbaa !24
  %t14 = load i64, ptr %l4, !tbaa !24
  %t17 = sub i64 %t13, %t14
  %t18 = load i64, ptr %l6, !tbaa !24
  %t21 = add i64 %t17, %t18
  %t23 = sub i64 %t21, 1
  %t24 = load i64, ptr %l6, !tbaa !24
  %t27 = sdiv i64 %t23, %t24
  store i64 %t27, ptr %l17, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l17, !tbaa !24
  br label %bb5
bb5:
  %t29 = load i64, ptr %l17, !tbaa !24
  store i64 %t29, ptr %l14, !tbaa !24
  br label %bb6
bb6:
  %t30 = load i64, ptr %l14, !tbaa !24
  store i64 %t30, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb7
bb7:
  %t31 = load i64, ptr %l8, !tbaa !24
  %t32 = load i64, ptr %l7, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  %t37 = xor i1 %t35, true
  br i1 %t37, label %bb8, label %bb9
bb8:
  br label %bb21
bb9:
  br label %bb10
bb10:
  %t39 = load i64, ptr %l4, !tbaa !24
  %t40 = load i64, ptr %l8, !tbaa !24
  %t41 = load i64, ptr %l6, !tbaa !24
  %t44 = mul i64 %t40, %t41
  %t47 = add i64 %t39, %t44
  store i64 %t47, ptr %l9, !tbaa !24
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t50 = load i32, ptr %l3, !tbaa !23
  %t55 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSatisfies(ptr %v0, ptr %t49, i32 %t50, i32 %a2)
  store i1 %t55, ptr %l38
  br label %bb11
bb11:
  %t56 = load i1, ptr %l38, !tbaa !21
  br i1 %t56, label %bb12, label %bb13
bb12:
  store i1 true, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = load i32, ptr %l3, !tbaa !23
  %t62 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eExtends(ptr %v0, ptr %t58, i32 %t59)
  store i1 %t62, ptr %l42
  br label %bb15
bb15:
  %t63 = load i1, ptr %l42, !tbaa !21
  %t64 = xor i1 %t63, true
  br i1 %t64, label %bb16, label %bb17
bb16:
  store i1 false, ptr %rv
  br label %ret
bb17:
  br label %bb18
bb18:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/generic:Program", ptr %t67, i32 0, i32 2
  %t70 = load i32, ptr %l3, !tbaa !23
  %t73 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %t69, i32 %t70)
  store i32 %t73, ptr %l48
  br label %bb19
bb19:
  %t74 = load i32, ptr %l48, !tbaa !23
  store i32 %t74, ptr %l3, !tbaa !23
  br label %bb20
bb20:
  %t75 = load i64, ptr %l8, !tbaa !24
  %t78 = add i64 %t75, 1
  store i64 %t78, ptr %l8, !tbaa !24
  br label %bb7
bb21:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eresultMayHold(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l9 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l22 = alloca i1
  %s1 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s1
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/generic:Program", ptr %t1, i32 0, i32 2
  %t7 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResults(ptr %v0, ptr %s1, ptr %t3, i32 %a1)
  store { i64, ptr } %t7, ptr %l9
  br label %bb1
bb1:
  %t8 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t8, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  %t14 = load i64, ptr %l3, !tbaa !24
  %t15 = load i64, ptr %l4, !tbaa !24
  %t18 = icmp slt i64 %t14, %t15
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb3, label %bb4
bb3:
  br label %bb11
bb4:
  br label %bb5
bb5:
  %t22 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t22, ptr %l17, !tbaa !27
  %t23 = load i64, ptr %l3, !tbaa !24
  %t25 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr i32, ptr %t26, i64 %t23
  %t28 = load i32, ptr %t27, !tbaa !33
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t34 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2emayHold(ptr %v0, ptr %t30, i32 %t28)
  store i1 %t34, ptr %l22
  br label %bb6
bb6:
  %t35 = load i1, ptr %l22, !tbaa !21
  br i1 %t35, label %bb7, label %bb8
bb7:
  call void @__olang_scope_close(ptr %s1)
  store i1 true, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t37 = load i64, ptr %l3, !tbaa !24
  %t40 = add i64 %t37, 1
  store i64 %t40, ptr %l3, !tbaa !24
  br label %bb2
bb11:
  call void @__olang_scope_close(ptr %s1)
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eslotOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l5 = alloca i1
  %l9 = alloca i32
  %l13 = alloca i1
  %l15 = alloca ptr
  %l19 = alloca i32
  %l20 = alloca i1
  %l24 = alloca i1
  %l25 = alloca i32
  %l29 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l5, !tbaa !21
  br label %bb4
bb2:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/generic:Program", ptr %t5, i32 0, i32 2
  %t8 = load i32, ptr %l2, !tbaa !23
  %t11 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t7, i32 %t8)
  store i32 %t11, ptr %l9
  br label %bb3
bb3:
  %t12 = load i32, ptr %l9, !range !{i32 0, i32 33}
  %t14 = trunc i64 20 to i32
  %t15 = icmp eq i32 %t12, %t14
  %t17 = xor i1 %t15, true
  store i1 %t17, ptr %l5, !tbaa !21
  br label %bb4
bb4:
  %t19 = load i1, ptr %l5, !tbaa !21
  br i1 %t19, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l13, !tbaa !21
  br label %bb9
bb6:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/generic:Program", ptr %t20, i32 0, i32 2
  store ptr %t22, ptr %l15, !tbaa !29
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/generic:Program", ptr %t23, i32 0, i32 2
  %t26 = load i32, ptr %l2, !tbaa !23
  %t29 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t25, i32 %t26)
  store i32 %t29, ptr %l19
  br label %bb7
bb7:
  %t30 = load ptr, ptr %l15, !tbaa !29
  %t31 = load i32, ptr %l19, !tbaa !23
  %t32 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNeedsDrop(ptr %v0, ptr %t30, i32 %t31)
  store i1 %t32, ptr %l20
  br label %bb8
bb8:
  %t33 = load i1, ptr %l20, !tbaa !21
  %t34 = xor i1 %t33, true
  store i1 %t34, ptr %l13, !tbaa !21
  br label %bb9
bb9:
  %t36 = load i1, ptr %l13, !tbaa !21
  br i1 %t36, label %bb10, label %bb11
bb10:
  %t37 = load i32, ptr %l2, !tbaa !23
  store i32 %t37, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t39 = load ptr, ptr %l1, !tbaa !29
  %t41 = call i1 @compiler_2fgeneric_2emadeByCall(ptr %v1, ptr %t39)
  store i1 %t41, ptr %l24
  br label %bb13
bb13:
  %t42 = load i1, ptr %l24, !tbaa !21
  br i1 %t42, label %bb14, label %bb15
bb14:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/generic:Program", ptr %t43, i32 0, i32 2
  %t46 = load i32, ptr %l2, !tbaa !23
  %t49 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t45, i32 %t46)
  store i32 %t49, ptr %l29
  br label %bb16
bb15:
  %t50 = load i32, ptr %l2, !tbaa !23
  store i32 %t50, ptr %l25, !tbaa !23
  br label %bb17
bb16:
  %t52 = load i32, ptr %l29, !tbaa !23
  store i32 %t52, ptr %l25, !tbaa !23
  br label %bb17
bb17:
  %t53 = load i32, ptr %l25, !tbaa !23
  store i32 %t53, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eunifyErrs(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i32
  %l10 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i32
  %l18 = alloca i1
  %l24 = alloca i32
  %l26 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l30 = alloca { i64, ptr }
  %l37 = alloca { i64, ptr }
  %l43 = alloca i1
  %l47 = alloca i64
  %l53 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l57 = alloca { i64, ptr }
  %l64 = alloca { i64, ptr }
  %l70 = alloca i1
  %l77 = alloca i1
  %l84 = alloca ptr
  %l85 = alloca ptr
  %l86 = alloca i64
  %l87 = alloca ptr
  %l89 = alloca ptr
  %l91 = alloca { i64, ptr }
  %l92 = alloca i32
  %l93 = alloca i32
  %l94 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t3 = load ptr, ptr %l3, !tbaa !29
  %t7 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eerrsHaveVar(ptr %v0, ptr %v1, ptr %t1, i32 %t2, ptr %t3)
  store i1 %t7, ptr %l18
  br label %bb1
bb1:
  %t8 = load i1, ptr %l18, !tbaa !21
  %t9 = xor i1 %t8, true
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load i32, ptr %l1, !tbaa !23
  %t13 = load i32, ptr %l2, !tbaa !23
  %t14 = load ptr, ptr %l3, !tbaa !29
  %t19 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eunifyLists(ptr %v0, ptr %v1, ptr %t11, i32 %t12, i32 %t13, ptr %t14, i1 false)
  store i32 %t19, ptr %l24
  %t20 = icmp ne i32 %t19, 0
  br i1 %t20, label %bb5, label %ok.21, !prof !99
ok.21:
  br label %bb4
bb3:
  br label %bb7
bb4:
  br label %bb6
bb5:
  %t22 = load i32, ptr %l24, !tbaa !23
  %t23 = lshr i32 %t22, 16
  %t24 = and i32 %t22, 65535
  %t25 = icmp eq i32 %t23, 1
  %t26 = select i1 %t25, i32 1, i32 0
  %t27 = icmp eq i32 %t22, 0
  %t28 = shl i32 %t26, 16
  %t29 = or i32 %t28, %t24
  %t30 = select i1 %t27, i32 0, i32 %t29
  call void @__olang_scope_close(ptr %s0)
  store i32 %t30, ptr %rv
  br label %ret
bb6:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
bb7:
  %t32 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t32, ptr %l26
  br label %bb8
bb8:
  %t33 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l26
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t33, ptr %l4
  store i64 -1, ptr %l5, !tbaa !24
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/generic:Program", ptr %t34, i32 0, i32 2
  %t37 = load i32, ptr %l1, !tbaa !23
  %t40 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t36, i32 %t37)
  store { i64, ptr } %t40, ptr %l30
  br label %bb9
bb9:
  %t41 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t41, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t42 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t44 = extractvalue { i64, ptr } %t42, 0
  store i64 %t44, ptr %l8, !tbaa !24
  br label %bb10
bb10:
  %t46 = load i64, ptr %l7, !tbaa !24
  %t47 = load i64, ptr %l8, !tbaa !24
  %t50 = icmp slt i64 %t46, %t47
  %t52 = xor i1 %t50, true
  br i1 %t52, label %bb11, label %bb12
bb11:
  br label %bb21
bb12:
  br label %bb13
bb13:
  %t54 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t54, ptr %l37, !tbaa !27
  %t55 = load i64, ptr %l7, !tbaa !24
  %t57 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t58 = load ptr, ptr %t57, !tbaa !27
  %t59 = getelementptr i32, ptr %t58, i64 %t55
  %t60 = load i32, ptr %t59, !tbaa !33
  store i32 %t60, ptr %l9, !tbaa !23
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t63 = load i32, ptr %l9, !tbaa !23
  %t64 = load ptr, ptr %l3, !tbaa !29
  %t68 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eisVar(ptr %v0, ptr %v1, ptr %t62, i32 %t63, ptr %t64)
  store i1 %t68, ptr %l43
  br label %bb14
bb14:
  %t69 = load i1, ptr %l43, !tbaa !21
  br i1 %t69, label %bb15, label %bb16
bb15:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/generic:Program", ptr %t70, i32 0, i32 2
  %t73 = load i32, ptr %l9, !tbaa !23
  %t76 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eB(ptr %v0, ptr %t72, i32 %t73)
  store i64 %t76, ptr %l47
  br label %bb17
bb16:
  %t77 = load i32, ptr %l9, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %l4, i32 %t77)
  br label %bb18
bb17:
  %t80 = load i64, ptr %l47, !tbaa !24
  store i64 %t80, ptr %l5, !tbaa !24
  br label %bb19
bb18:
  br label %bb19
bb19:
  br label %bb20
bb20:
  %t81 = load i64, ptr %l7, !tbaa !24
  %t84 = add i64 %t81, 1
  store i64 %t84, ptr %l7, !tbaa !24
  br label %bb10
bb21:
  %t86 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t86, ptr %l53
  br label %bb22
bb22:
  %t87 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l53
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t87, ptr %l10
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t90 = getelementptr %"compiler/generic:Program", ptr %t88, i32 0, i32 2
  %t91 = load i32, ptr %l2, !tbaa !23
  %t94 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t90, i32 %t91)
  store { i64, ptr } %t94, ptr %l57
  br label %bb23
bb23:
  %t95 = load { i64, ptr }, ptr %l57, !tbaa !27
  store { i64, ptr } %t95, ptr %l11, !tbaa !27
  store i64 0, ptr %l12, !tbaa !24
  %t96 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t98 = extractvalue { i64, ptr } %t96, 0
  store i64 %t98, ptr %l13, !tbaa !24
  br label %bb24
bb24:
  %t100 = load i64, ptr %l12, !tbaa !24
  %t101 = load i64, ptr %l13, !tbaa !24
  %t104 = icmp slt i64 %t100, %t101
  %t106 = xor i1 %t104, true
  br i1 %t106, label %bb25, label %bb26
bb25:
  br label %bb40
bb26:
  br label %bb27
bb27:
  %t108 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t108, ptr %l64, !tbaa !27
  %t109 = load i64, ptr %l12, !tbaa !24
  %t111 = getelementptr { i64, ptr }, ptr %l64, i32 0, i32 1
  %t112 = load ptr, ptr %t111, !tbaa !27
  %t113 = getelementptr i32, ptr %t112, i64 %t109
  %t114 = load i32, ptr %t113, !tbaa !33
  store i32 %t114, ptr %l14, !tbaa !23
  %t116 = load i32, ptr %l14, !tbaa !23
  %t117 = load i32, ptr @G_2ecompiler_2ftypes_2eDefaultErrT, !tbaa !23
  %t120 = icmp eq i32 %t116, %t117
  br i1 %t120, label %bb28, label %bb29
bb28:
  store i1 true, ptr %l70, !tbaa !21
  br label %bb30
bb29:
  %t122 = load i32, ptr %l14, !tbaa !23
  %t123 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t126 = icmp eq i32 %t122, %t123
  store i1 %t126, ptr %l70, !tbaa !21
  br label %bb30
bb30:
  %t128 = load i1, ptr %l70, !tbaa !21
  br i1 %t128, label %bb31, label %bb32
bb31:
  br label %bb39
bb32:
  br label %bb33
bb33:
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t130 = load i32, ptr %l14, !tbaa !23
  %t134 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eentryHeld(ptr %v0, ptr %s0, ptr %t129, i32 %t130, ptr %l4)
  store i1 %t134, ptr %l77
  br label %bb34
bb34:
  %t135 = load i1, ptr %l77, !tbaa !21
  %t136 = xor i1 %t135, true
  br i1 %t136, label %bb35, label %bb36
bb35:
  %t138 = load i32, ptr %l14, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %l10, i32 %t138)
  br label %bb37
bb36:
  br label %bb38
bb37:
  br label %bb38
bb38:
  br label %bb39
bb39:
  %t141 = load i64, ptr %l12, !tbaa !24
  %t144 = add i64 %t141, 1
  store i64 %t144, ptr %l12, !tbaa !24
  br label %bb24
bb40:
  %t146 = load ptr, ptr %l0, !tbaa !29
  store ptr %t146, ptr %l84, !tbaa !29
  %t147 = load ptr, ptr %l3, !tbaa !29
  store ptr %t147, ptr %l85, !tbaa !29
  %t148 = load i64, ptr %l5, !tbaa !24
  store i64 %t148, ptr %l86, !tbaa !24
  %t149 = load ptr, ptr %l0, !tbaa !29
  store ptr %t149, ptr %l87, !tbaa !29
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t152 = getelementptr %"compiler/generic:Program", ptr %t150, i32 0, i32 2
  store ptr %t152, ptr %l89, !tbaa !29
  %t154 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eToArray_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %s0, ptr %l10)
  store { i64, ptr } %t154, ptr %l91
  br label %bb41
bb41:
  %t155 = load ptr, ptr %l89, !tbaa !29
  %t156 = load { i64, ptr }, ptr %l91, !tbaa !27
  %t157 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s0, ptr %t155, { i64, ptr } %t156)
  store i32 %t157, ptr %l92
  br label %bb42
bb42:
  %t158 = load ptr, ptr %l87, !tbaa !29
  %t159 = load i32, ptr %l92, !tbaa !23
  %t160 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrSetOf(ptr %v0, ptr %t158, i32 %t159)
  store i32 %t160, ptr %l93
  br label %bb43
bb43:
  %t161 = load ptr, ptr %l84, !tbaa !29
  %t162 = load ptr, ptr %l85, !tbaa !29
  %t163 = load i64, ptr %l86, !tbaa !24
  %t164 = load i32, ptr %l93, !tbaa !23
  %t165 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ebind(ptr %v0, ptr %v1, ptr %t161, ptr %t162, i64 %t163, i32 %t164, i1 false, i1 false)
  store i32 %t165, ptr %l94
  %t166 = icmp ne i32 %t165, 0
  br i1 %t166, label %bb45, label %ok.167, !prof !99
ok.167:
  br label %bb44
bb44:
  br label %bb46
bb45:
  %t168 = load i32, ptr %l94, !tbaa !23
  %t169 = lshr i32 %t168, 16
  %t170 = and i32 %t168, 65535
  %t171 = icmp eq i32 %t169, 1
  %t172 = select i1 %t171, i32 1, i32 0
  %t173 = icmp eq i32 %t168, 0
  %t174 = shl i32 %t172, 16
  %t175 = or i32 %t174, %t170
  %t176 = select i1 %t173, i32 0, i32 %t175
  call void @__olang_scope_close(ptr %s0)
  store i32 %t176, ptr %rv
  br label %ret
bb46:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2fgeneric_2elitOnly(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i1
  %l4 = alloca ptr
  %l5 = alloca i1
  %l8 = alloca ptr
  %l9 = alloca i1
  %l15 = alloca i1
  %l16 = alloca ptr
  %l17 = alloca i1
  %l23 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 28}
  %t8 = icmp eq i64 %t6, 1
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb6
bb5:
  store i1 true, ptr %l3, !tbaa !21
  br label %bb25
bb6:
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t11 = load ptr, ptr %l8, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb7, label %bb8
bb7:
  %t14 = load ptr, ptr %l8, !tbaa !29
  %t15 = load i64, ptr %t14, !range !{i64 0, i64 28}
  %t17 = icmp eq i64 %t15, 3
  store i1 %t17, ptr %l9, !tbaa !21
  br label %bb8
bb8:
  %t18 = load i1, ptr %l9, !tbaa !21
  br i1 %t18, label %bb9, label %bb10
bb9:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr { i64, [4 x i64] }, ptr %t19, i32 0, i32 1
  %t22 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t21, i32 0, i32 2
  %t23 = load ptr, ptr %t22
  store ptr %t23, ptr %l1, !tbaa !29
  br label %bb11
bb10:
  br label %bb13
bb11:
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = call i1 @compiler_2fgeneric_2elitOnly(ptr %v0, ptr %t25)
  store i1 %t27, ptr %l15
  br label %bb12
bb12:
  %t28 = load i1, ptr %l15, !tbaa !21
  store i1 %t28, ptr %l3, !tbaa !21
  br label %bb25
bb13:
  %t29 = load ptr, ptr %l0, !tbaa !29
  store ptr %t29, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t30 = load ptr, ptr %l16, !tbaa !29
  %t31 = icmp ne ptr %t30, null
  br i1 %t31, label %bb14, label %bb15
bb14:
  %t33 = load ptr, ptr %l16, !tbaa !29
  %t34 = load i64, ptr %t33, !range !{i64 0, i64 28}
  %t36 = icmp eq i64 %t34, 2
  store i1 %t36, ptr %l17, !tbaa !21
  br label %bb15
bb15:
  %t37 = load i1, ptr %l17, !tbaa !21
  br i1 %t37, label %bb16, label %bb17
bb16:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr { i64, [4 x i64] }, ptr %t38, i32 0, i32 1
  %t41 = getelementptr { %"compiler/source:Span", ptr }, ptr %t40, i32 0, i32 1
  %t42 = load ptr, ptr %t41
  store ptr %t42, ptr %l2, !tbaa !29
  br label %bb18
bb17:
  br label %bb20
bb18:
  %t44 = load ptr, ptr %l2, !tbaa !29
  %t46 = call i1 @compiler_2fgeneric_2elitOnly(ptr %v0, ptr %t44)
  store i1 %t46, ptr %l23
  br label %bb19
bb19:
  %t47 = load i1, ptr %l23, !tbaa !21
  store i1 %t47, ptr %l3, !tbaa !21
  br label %bb25
bb20:
  br i1 true, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  store i1 false, ptr %l3, !tbaa !21
  br label %bb25
bb24:
  call void @__olang_check_failed(ptr @olang_loc_de533036e7174fdb_fce805c56f435877)
  unreachable
bb25:
  %t48 = load i1, ptr %l3, !tbaa !21
  store i1 %t48, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fgeneric_2emadeByCall(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca ptr
  %l4 = alloca i1
  %l7 = alloca ptr
  %l8 = alloca i1
  %l13 = alloca ptr
  %l14 = alloca i1
  %l20 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  store i1 false, ptr %l4, !tbaa !21
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 28}
  %t8 = icmp eq i64 %t6, 10
  store i1 %t8, ptr %l4, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l4, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb6
bb5:
  store i1 true, ptr %l2, !tbaa !21
  br label %bb22
bb6:
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l7, !tbaa !29
  store i1 false, ptr %l8, !tbaa !21
  %t11 = load ptr, ptr %l7, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb7, label %bb8
bb7:
  %t14 = load ptr, ptr %l7, !tbaa !29
  %t15 = load i64, ptr %t14, !range !{i64 0, i64 28}
  %t17 = icmp eq i64 %t15, 2
  store i1 %t17, ptr %l8, !tbaa !21
  br label %bb8
bb8:
  %t18 = load i1, ptr %l8, !tbaa !21
  br i1 %t18, label %bb9, label %bb10
bb9:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr { i64, [4 x i64] }, ptr %t19, i32 0, i32 1
  %t22 = getelementptr { %"compiler/source:Span", ptr }, ptr %t21, i32 0, i32 1
  %t23 = load ptr, ptr %t22
  store ptr %t23, ptr %l1, !tbaa !29
  br label %bb15
bb10:
  %t25 = load ptr, ptr %l0, !tbaa !29
  store ptr %t25, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t26 = load ptr, ptr %l13, !tbaa !29
  %t27 = icmp ne ptr %t26, null
  br i1 %t27, label %bb11, label %bb12
bb11:
  %t29 = load ptr, ptr %l13, !tbaa !29
  %t30 = load i64, ptr %t29, !range !{i64 0, i64 28}
  %t32 = icmp eq i64 %t30, 19
  store i1 %t32, ptr %l14, !tbaa !21
  br label %bb12
bb12:
  %t33 = load i1, ptr %l14, !tbaa !21
  br i1 %t33, label %bb13, label %bb14
bb13:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr { i64, [4 x i64] }, ptr %t34, i32 0, i32 1
  %t37 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t36, i32 0, i32 1
  %t38 = load ptr, ptr %t37
  store ptr %t38, ptr %l1, !tbaa !29
  br label %bb15
bb14:
  br label %bb17
bb15:
  %t40 = load ptr, ptr %l1, !tbaa !29
  %t42 = call i1 @compiler_2fgeneric_2emadeByCall(ptr %v0, ptr %t40)
  store i1 %t42, ptr %l20
  br label %bb16
bb16:
  %t43 = load i1, ptr %l20, !tbaa !21
  store i1 %t43, ptr %l2, !tbaa !21
  br label %bb22
bb17:
  br i1 true, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb21
bb20:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb22
bb21:
  call void @__olang_check_failed(ptr @olang_loc_56a9f796d6022e8a_9e3c205a980da41e)
  unreachable
bb22:
  %t44 = load i1, ptr %l2, !tbaa !21
  store i1 %t44, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fgeneric_2enameChar(i8 %a0) #0 {
entry:
  %l0 = alloca i8
  %l2 = alloca i1
  %l3 = alloca i1
  %l5 = alloca i1
  %l6 = alloca i1
  %l9 = alloca i1
  %l12 = alloca i1
  %l15 = alloca i1
  %l18 = alloca i1
  %rv = alloca i1
  store i8 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i8, ptr %l0, !tbaa !22
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %t1)
  store i1 %t3, ptr %l2
  br label %bb1
bb1:
  %t4 = load i1, ptr %l2, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l3, !tbaa !21
  br label %bb5
bb3:
  %t5 = load i8, ptr %l0, !tbaa !22
  %t7 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t5)
  store i1 %t7, ptr %l5
  br label %bb4
bb4:
  %t8 = load i1, ptr %l5, !tbaa !21
  store i1 %t8, ptr %l3, !tbaa !21
  br label %bb5
bb5:
  %t9 = load i1, ptr %l3, !tbaa !21
  br i1 %t9, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb8
bb7:
  %t10 = load i8, ptr %l0, !tbaa !22
  %t12 = icmp eq i8 %t10, 95
  store i1 %t12, ptr %l6, !tbaa !21
  br label %bb8
bb8:
  %t14 = load i1, ptr %l6, !tbaa !21
  br i1 %t14, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb11
bb10:
  %t15 = load i8, ptr %l0, !tbaa !22
  %t17 = icmp eq i8 %t15, 47
  store i1 %t17, ptr %l9, !tbaa !21
  br label %bb11
bb11:
  %t19 = load i1, ptr %l9, !tbaa !21
  br i1 %t19, label %bb12, label %bb13
bb12:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb14
bb13:
  %t20 = load i8, ptr %l0, !tbaa !22
  %t22 = icmp eq i8 %t20, 46
  store i1 %t22, ptr %l12, !tbaa !21
  br label %bb14
bb14:
  %t24 = load i1, ptr %l12, !tbaa !21
  br i1 %t24, label %bb15, label %bb16
bb15:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb17
bb16:
  %t25 = load i8, ptr %l0, !tbaa !22
  %t27 = icmp eq i8 %t25, 45
  store i1 %t27, ptr %l15, !tbaa !21
  br label %bb17
bb17:
  %t29 = load i1, ptr %l15, !tbaa !21
  br i1 %t29, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l18, !tbaa !21
  br label %bb20
bb19:
  %t30 = load i8, ptr %l0, !tbaa !22
  %t32 = icmp eq i8 %t30, 64
  store i1 %t32, ptr %l18, !tbaa !21
  br label %bb20
bb20:
  %t34 = load i1, ptr %l18, !tbaa !21
  store i1 %t34, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2fgeneric_2epromiseBit(i32 %a0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca i64
  %rv = alloca i64
  store i32 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t3 = trunc i64 57 to i32
  %t4 = icmp eq i32 %t1, %t3
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t6 = load i64, ptr @G_2ecompiler_2ftypes_2ePromReturns, !tbaa !24
  store i64 %t6, ptr %l1, !tbaa !24
  br label %bb37
bb4:
  %t8 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t10 = trunc i64 58 to i32
  %t11 = icmp eq i32 %t8, %t10
  br i1 %t11, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb8
bb7:
  %t13 = load i64, ptr @G_2ecompiler_2ftypes_2ePromNoalloc, !tbaa !24
  store i64 %t13, ptr %l1, !tbaa !24
  br label %bb37
bb8:
  %t15 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t17 = trunc i64 59 to i32
  %t18 = icmp eq i32 %t15, %t17
  br i1 %t18, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  %t20 = load i64, ptr @G_2ecompiler_2ftypes_2ePromNoblock, !tbaa !24
  store i64 %t20, ptr %l1, !tbaa !24
  br label %bb37
bb12:
  %t22 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t24 = trunc i64 60 to i32
  %t25 = icmp eq i32 %t22, %t24
  br i1 %t25, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  %t27 = load i64, ptr @G_2ecompiler_2ftypes_2ePromNospawn, !tbaa !24
  store i64 %t27, ptr %l1, !tbaa !24
  br label %bb37
bb16:
  %t29 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t31 = trunc i64 61 to i32
  %t32 = icmp eq i32 %t29, %t31
  br i1 %t32, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  %t34 = load i64, ptr @G_2ecompiler_2ftypes_2ePromNorecurse, !tbaa !24
  store i64 %t34, ptr %l1, !tbaa !24
  br label %bb37
bb20:
  %t36 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t38 = trunc i64 62 to i32
  %t39 = icmp eq i32 %t36, %t38
  br i1 %t39, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  %t41 = load i64, ptr @G_2ecompiler_2ftypes_2ePromNoextern, !tbaa !24
  store i64 %t41, ptr %l1, !tbaa !24
  br label %bb37
bb24:
  %t43 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t45 = trunc i64 63 to i32
  %t46 = icmp eq i32 %t43, %t45
  br i1 %t46, label %bb25, label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb28
bb27:
  %t48 = load i64, ptr @G_2ecompiler_2ftypes_2ePromPure, !tbaa !24
  store i64 %t48, ptr %l1, !tbaa !24
  br label %bb37
bb28:
  %t50 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t52 = trunc i64 66 to i32
  %t53 = icmp eq i32 %t50, %t52
  br i1 %t53, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb32
bb31:
  %t55 = load i64, ptr @G_2ecompiler_2ftypes_2ePromNoborrow, !tbaa !24
  store i64 %t55, ptr %l1, !tbaa !24
  br label %bb37
bb32:
  br i1 true, label %bb33, label %bb34
bb33:
  br label %bb35
bb34:
  br label %bb36
bb35:
  store i64 0, ptr %l1, !tbaa !24
  br label %bb37
bb36:
  call void @__olang_check_failed(ptr @olang_loc_5e6ea17f09d33e2_77348db42693dffe)
  unreachable
bb37:
  %t57 = load i64, ptr %l1, !tbaa !24
  store i64 %t57, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fgeneric_2etestLoad(ptr %out, ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %lp2 = alloca ptr
  %lp3 = alloca ptr
  %l9 = alloca i32
  %l11 = alloca i1
  %l14 = alloca %"compiler/cond:Consts"
  %l16 = alloca ptr
  %l17 = alloca i64
  %l19 = alloca i64
  %l23 = alloca { i64, ptr }
  %l24 = alloca i64
  %l29 = alloca %"compiler/fetch:Fetcher"
  %l30 = alloca ptr
  %l31 = alloca i64
  %l33 = alloca %"compiler/source:Names"
  %l34 = alloca ptr
  %l35 = alloca %"compiler/diag:Diagnostics"
  %l37 = alloca %"compiler/load:Loader"
  %l38 = alloca ptr
  %l39 = alloca i64
  %l44 = alloca i64
  %l45 = alloca %"compiler/load:Loader"
  %s0 = alloca %olang.scope
  %t29 = alloca %"compiler/cond:Consts", align 8
  %t89 = alloca %"compiler/fetch:Fetcher", align 8
  %t114 = alloca %"compiler/diag:Diagnostics", align 8
  %t116 = alloca %"compiler/load:Loader", align 8
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 1
  %t4 = extractvalue { i64, ptr } %t1, 0
  %t5 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d66, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d66, i32 0, i32 1) }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t17 = call i32 @std_2fos_2eWriteFile(ptr %s0, ptr %v1, { i64, ptr } %t11, { i64, ptr } %a1)
  store i32 %t17, ptr %l9
  %t18 = icmp ne i32 %t17, 0
  br i1 %t18, label %bb2, label %ok.19, !prof !99
ok.19:
  br label %bb1
bb1:
  br label %bb6
bb2:
  %t20 = load i32, ptr %l9, !tbaa !23
  %t21 = ashr i32 %t20, 16
  %t23 = icmp eq i32 %t21, 1
  store i1 %t23, ptr %l11, !tbaa !21
  %t24 = load i32, ptr %l9, !tbaa !23
  %t25 = ashr i32 %t24, 16
  %t27 = icmp eq i32 %t25, 1
  br i1 %t27, label %bb3, label %bb4
bb3:
  call void @__olang_errpay_pop()
  br label %bb4
bb4:
  br label %bb5
bb5:
  br label %bb6
bb6:
  call void @compiler_2fcond_3aConsts_2ector(ptr %t29, ptr %v2)
  call void @llvm.memmove.p0.p0.i64(ptr %l14, ptr %t29, i64 256, i1 false)
  br label %bb7
bb7:
  %t30 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 256, i64 8)
  store ptr %t30, ptr %lp2
  %t31 = load ptr, ptr %lp2
  call void @llvm.memmove.p0.p0.i64(ptr %t31, ptr %l14, i64 256, i1 false)
  %t32 = load ptr, ptr %lp2
  call void @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eBuiltins(ptr %v2, ptr %v2, ptr %v2, ptr %v2, ptr %t32, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d67, i32 0, i32 1) }, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d68, i32 0, i32 1) }, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d69, i32 0, i32 1) }, i64 128, i64 0, i1 false, i1 false, i1 false, i64 0)
  br label %bb8
bb8:
  %t34 = load ptr, ptr %lp2
  store ptr %t34, ptr %l16, !tbaa !29
  %t35 = call ptr @__olang_scope_hold(ptr %v2)
  %t36 = ptrtoint ptr %t35 to i64
  store i64 %t36, ptr %l17, !tbaa !24
  %t37 = load i1, ptr @olang_2esole_2ecompiler_2fload_3aLoader_2e2
  br i1 %t37, label %bb9, label %bb10
bb9:
  %t39 = call ptr @__olang_region_make(ptr %v2)
  %t40 = ptrtoint ptr %t39 to i64
  store i64 %t40, ptr %l17, !tbaa !24
  br label %bb10
bb10:
  %t41 = load i64, ptr %l17
  %t42 = inttoptr i64 %t41 to ptr
  %t43 = call ptr @__olang_scope_hold(ptr %t42)
  %t44 = ptrtoint ptr %t43 to i64
  store i64 %t44, ptr %l19, !tbaa !24
  %t45 = load i1, ptr @olang_2esole_2ecompiler_2ffetch_3aFetcher_2e0
  br i1 %t45, label %bb11, label %bb12
bb11:
  %t47 = load i64, ptr %l17
  %t48 = inttoptr i64 %t47 to ptr
  %t49 = call ptr @__olang_region_make(ptr %t48)
  %t50 = ptrtoint ptr %t49 to i64
  store i64 %t50, ptr %l19, !tbaa !24
  br label %bb12
bb12:
  %t51 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t53 = extractvalue { i64, ptr } %t51, 1
  %t54 = extractvalue { i64, ptr } %t51, 0
  %t55 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d70, i32 0, i32 1) }, 1
  %t56 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d70, i32 0, i32 1) }, 0
  %t57 = add i64 %t54, %t56
  %t58 = load i64, ptr %l19
  %t59 = inttoptr i64 %t58 to ptr
  %t60 = call ptr @__olang_held_alloc(ptr %t59, i64 %t57)
  call void @olang_textcopy(ptr %t60, ptr %t53, i64 %t54)
  %t61 = getelementptr i8, ptr %t60, i64 %t54
  call void @olang_textcopy(ptr %t61, ptr %t55, i64 %t56)
  %t62 = insertvalue { i64, ptr } undef, i64 %t57, 0
  %t63 = insertvalue { i64, ptr } %t62, ptr %t60, 1
  store { i64, ptr } %t63, ptr %l23, !tbaa !27
  %t65 = load i64, ptr %l17
  %t66 = inttoptr i64 %t65 to ptr
  %t67 = call ptr @__olang_scope_hold(ptr %t66)
  %t68 = ptrtoint ptr %t67 to i64
  store i64 %t68, ptr %l24, !tbaa !24
  %t69 = load i1, ptr @olang_2esole_2ecompiler_2ffetch_3aFetcher_2e1
  br i1 %t69, label %bb13, label %bb14
bb13:
  %t71 = load i64, ptr %l17
  %t72 = inttoptr i64 %t71 to ptr
  %t73 = call ptr @__olang_region_make(ptr %t72)
  %t74 = ptrtoint ptr %t73 to i64
  store i64 %t74, ptr %l24, !tbaa !24
  br label %bb14
bb14:
  %t75 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t77 = extractvalue { i64, ptr } %t75, 1
  %t78 = extractvalue { i64, ptr } %t75, 0
  %t79 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d71, i32 0, i32 1) }, 1
  %t80 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d71, i32 0, i32 1) }, 0
  %t81 = add i64 %t78, %t80
  %t82 = load i64, ptr %l24
  %t83 = inttoptr i64 %t82 to ptr
  %t84 = call ptr @__olang_held_alloc(ptr %t83, i64 %t81)
  call void @olang_textcopy(ptr %t84, ptr %t77, i64 %t78)
  %t85 = getelementptr i8, ptr %t84, i64 %t78
  call void @olang_textcopy(ptr %t85, ptr %t79, i64 %t80)
  %t86 = insertvalue { i64, ptr } undef, i64 %t81, 0
  %t87 = insertvalue { i64, ptr } %t86, ptr %t84, 1
  %t90 = load i64, ptr %l17
  %t91 = inttoptr i64 %t90 to ptr
  %t92 = load i64, ptr %l17
  %t93 = inttoptr i64 %t92 to ptr
  %t94 = load i64, ptr %l17
  %t95 = inttoptr i64 %t94 to ptr
  %t96 = load { i64, ptr }, ptr %l23, !tbaa !27
  call void @compiler_2ffetch_3aFetcher_2ector(ptr %t89, ptr %t91, ptr %t93, ptr %v2, ptr %t95, { i64, ptr } %t96, { i64, ptr } %t87, { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d72, i32 0, i32 1) }, i1 false, i1 true)
  call void @llvm.memmove.p0.p0.i64(ptr %l29, ptr %t89, i64 184, i1 false)
  br label %bb15
bb15:
  %t98 = load i64, ptr %l17
  %t99 = inttoptr i64 %t98 to ptr
  %t100 = call ptr @__olang_scope_alloc_a(ptr %t99, i64 184, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t100, ptr %l29, i64 184, i1 false)
  store ptr %t100, ptr %l30, !tbaa !29
  %t101 = call ptr @__olang_scope_hold(ptr %v2)
  %t102 = ptrtoint ptr %t101 to i64
  store i64 %t102, ptr %l31, !tbaa !24
  %t103 = load i1, ptr @olang_2esole_2ecompiler_2fload_3aLoader_2e3
  br i1 %t103, label %bb16, label %bb17
bb16:
  %t105 = call ptr @__olang_region_make(ptr %v2)
  %t106 = ptrtoint ptr %t105 to i64
  store i64 %t106, ptr %l31, !tbaa !24
  br label %bb17
bb17:
  %t107 = load i64, ptr %l31
  %t108 = inttoptr i64 %t107 to ptr
  %t109 = call %"compiler/source:Names" @compiler_2fsource_3aNames_2ector(ptr %t108)
  store %"compiler/source:Names" %t109, ptr %l33
  br label %bb18
bb18:
  %t110 = load %"compiler/source:Names", ptr %l33
  %t111 = load i64, ptr %l31
  %t112 = inttoptr i64 %t111 to ptr
  %t113 = call ptr @__olang_scope_alloc_a(ptr %t112, i64 104, i64 8)
  store %"compiler/source:Names" %t110, ptr %t113
  store ptr %t113, ptr %l34, !tbaa !29
  call void @compiler_2fdiag_3aDiagnostics_2ector(ptr %t114, ptr %v2, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %l35, ptr %t114, i64 704, i1 false)
  br label %bb19
bb19:
  %t115 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 704, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t115, ptr %l35, i64 704, i1 false)
  %t117 = load ptr, ptr %l16, !tbaa !29
  %t118 = load ptr, ptr %l30, !tbaa !29
  %t119 = load ptr, ptr %l34, !tbaa !29
  call void @compiler_2fload_3aLoader_2ector(ptr %t116, ptr %v2, ptr %v2, ptr %v2, ptr %v2, ptr %v2, ptr %v2, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d73, i32 0, i32 1) }, ptr %t117, ptr %t118, ptr %t119, ptr %t115)
  call void @llvm.memmove.p0.p0.i64(ptr %l37, ptr %t116, i64 864, i1 false)
  br label %bb20
bb20:
  %t121 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 864, i64 8)
  store ptr %t121, ptr %lp3
  %t122 = load ptr, ptr %lp3
  call void @llvm.memmove.p0.p0.i64(ptr %t122, ptr %l37, i64 864, i1 false)
  %t123 = load ptr, ptr %lp3
  store ptr %t123, ptr %l38, !tbaa !29
  %t124 = call ptr @__olang_scope_hold(ptr %v2)
  %t125 = ptrtoint ptr %t124 to i64
  store i64 %t125, ptr %l39, !tbaa !24
  %t126 = load i1, ptr @olang_2esole_2ecompiler_2fload_3aModule_2e0
  br i1 %t126, label %bb21, label %bb22
bb21:
  %t128 = call ptr @__olang_region_make(ptr %v2)
  %t129 = ptrtoint ptr %t128 to i64
  store i64 %t129, ptr %l39, !tbaa !24
  br label %bb22
bb22:
  %t130 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t132 = extractvalue { i64, ptr } %t130, 1
  %t133 = extractvalue { i64, ptr } %t130, 0
  %t134 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d74, i32 0, i32 1) }, 1
  %t135 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d74, i32 0, i32 1) }, 0
  %t136 = add i64 %t133, %t135
  %t137 = load i64, ptr %l39
  %t138 = inttoptr i64 %t137 to ptr
  %t139 = call ptr @__olang_held_alloc(ptr %t138, i64 %t136)
  call void @olang_textcopy(ptr %t139, ptr %t132, i64 %t133)
  %t140 = getelementptr i8, ptr %t139, i64 %t133
  call void @olang_textcopy(ptr %t140, ptr %t134, i64 %t135)
  %t141 = insertvalue { i64, ptr } undef, i64 %t136, 0
  %t142 = insertvalue { i64, ptr } %t141, ptr %t139, 1
  %t144 = load ptr, ptr %l38, !tbaa !29
  %t146 = call i64 @compiler_2fload_2ecompiler_2fload_3aLoader_2eLoad(ptr %v2, ptr %v2, ptr %t144, { i64, ptr } %t142)
  store i64 %t146, ptr %l44
  br label %bb23
bb23:
  %t147 = load ptr, ptr %lp3
  call void @llvm.memmove.p0.p0.i64(ptr %l45, ptr %t147, i64 864, i1 false)
  call void @__olang_scope_close(ptr %s0)
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l45, i64 864, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/generic:AnySlot" @compiler_2fgeneric_3aAnySlot_2ector(ptr %v0, i32 %a0, i32 %a1, i64 %a2, i64 %a3, i1 %a4, i32 %a5) #0 {
entry:
  %rv = alloca %"compiler/generic:AnySlot"
  br label %start
start:
  br label %bb0
bb0:
  %t13 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t16 = insertvalue %"compiler/generic:AnySlot" undef, i32 %a0, 0
  %t18 = insertvalue %"compiler/generic:AnySlot" %t16, i32 %a1, 1
  %t20 = insertvalue %"compiler/generic:AnySlot" %t18, i64 %a2, 2
  %t22 = insertvalue %"compiler/generic:AnySlot" %t20, i64 %a3, 3
  %t24 = insertvalue %"compiler/generic:AnySlot" %t22, i1 %a4, 4
  %t26 = insertvalue %"compiler/generic:AnySlot" %t24, i32 %a5, 5
  %t28 = insertvalue %"compiler/generic:AnySlot" %t26, i32 %t13, 6
  store %"compiler/generic:AnySlot" %t28, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/generic:AnySlot", ptr %rv
  ret %"compiler/generic:AnySlot" %rr
}

define dso_local %"compiler/generic:Binding" @compiler_2fgeneric_3aBinding_2ector(ptr %v0, i64 %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l9 = alloca i64
  %l11 = alloca i64
  %l15 = alloca i64
  %l17 = alloca i64
  %l20 = alloca i64
  %l22 = alloca i64
  %rv = alloca %"compiler/generic:Binding"
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i64 %a0, ptr %l2, !tbaa !24
  %t3 = load i64, ptr %l1, !tbaa !24
  store i64 %t3, ptr %l3, !tbaa !24
  %t5 = call ptr @__olang_scope_hold(ptr %v0)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l9, !tbaa !24
  %t7 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aBinding_2e2
  br i1 %t7, label %bb1, label %bb2
bb1:
  %t9 = call ptr @__olang_region_make(ptr %v0)
  %t10 = ptrtoint ptr %t9 to i64
  store i64 %t10, ptr %l9, !tbaa !24
  br label %bb2
bb2:
  %t11 = load i64, ptr %l1, !tbaa !24
  store i64 %t11, ptr %l11, !tbaa !24
  %t12 = load i64, ptr %l11, !tbaa !24
  %t13 = icmp sge i64 %t12, 0
  br i1 %t13, label %bb3, label %bb4
bb3:
  %t15 = load i64, ptr %l11, !tbaa !24
  %t16 = icmp sle i64 %t15, 2305843009213693951
  br i1 %t16, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_8e4da92f4f682bfd_d3a5cd4c92991ca9)
  unreachable
bb5:
  %t18 = load i64, ptr %l11, !tbaa !24
  %t19 = mul i64 %t18, 4
  %t20 = load i64, ptr %l9
  %t21 = inttoptr i64 %t20 to ptr
  %t22 = call ptr @__olang_scope_alloc_zeroed(ptr %t21, i64 %t19)
  %t23 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t24 = insertvalue { i64, ptr } %t23, ptr %t22, 1
  store { i64, ptr } %t24, ptr %l4, !tbaa !27
  %t26 = call ptr @__olang_scope_hold(ptr %v0)
  %t27 = ptrtoint ptr %t26 to i64
  store i64 %t27, ptr %l15, !tbaa !24
  %t28 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aBinding_2e3
  br i1 %t28, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_8e4da92f4f682bfd_d3a5cd4c92991ca9)
  unreachable
bb7:
  %t30 = call ptr @__olang_region_make(ptr %v0)
  %t31 = ptrtoint ptr %t30 to i64
  store i64 %t31, ptr %l15, !tbaa !24
  br label %bb8
bb8:
  %t32 = load i64, ptr %l1, !tbaa !24
  store i64 %t32, ptr %l17, !tbaa !24
  %t33 = load i64, ptr %l17, !tbaa !24
  %t34 = icmp sge i64 %t33, 0
  br i1 %t34, label %bb9, label %bb10
bb9:
  %t36 = load i64, ptr %l17, !tbaa !24
  %t37 = mul i64 %t36, 1
  %t38 = load i64, ptr %l15
  %t39 = inttoptr i64 %t38 to ptr
  %t40 = call ptr @__olang_scope_alloc_zeroed(ptr %t39, i64 %t37)
  %t41 = insertvalue { i64, ptr } undef, i64 %t36, 0
  %t42 = insertvalue { i64, ptr } %t41, ptr %t40, 1
  store { i64, ptr } %t42, ptr %l5, !tbaa !27
  %t44 = call ptr @__olang_scope_hold(ptr %v0)
  %t45 = ptrtoint ptr %t44 to i64
  store i64 %t45, ptr %l20, !tbaa !24
  %t46 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aBinding_2e4
  br i1 %t46, label %bb11, label %bb12
bb10:
  call void @__olang_check_failed(ptr @olang_loc_d2716e3b81e17ed0_f7580b05837cd1dc)
  unreachable
bb11:
  %t48 = call ptr @__olang_region_make(ptr %v0)
  %t49 = ptrtoint ptr %t48 to i64
  store i64 %t49, ptr %l20, !tbaa !24
  br label %bb12
bb12:
  %t50 = load i64, ptr %l1, !tbaa !24
  store i64 %t50, ptr %l22, !tbaa !24
  %t51 = load i64, ptr %l22, !tbaa !24
  %t52 = icmp sge i64 %t51, 0
  br i1 %t52, label %bb13, label %bb14
bb13:
  %t54 = load i64, ptr %l22, !tbaa !24
  %t55 = mul i64 %t54, 1
  %t56 = load i64, ptr %l20
  %t57 = inttoptr i64 %t56 to ptr
  %t58 = call ptr @__olang_scope_alloc_zeroed(ptr %t57, i64 %t55)
  %t59 = insertvalue { i64, ptr } undef, i64 %t54, 0
  %t60 = insertvalue { i64, ptr } %t59, ptr %t58, 1
  %t62 = load i64, ptr %l2, !tbaa !24
  %t63 = insertvalue %"compiler/generic:Binding" undef, i64 %t62, 0
  %t64 = load i64, ptr %l3, !tbaa !24
  %t65 = insertvalue %"compiler/generic:Binding" %t63, i64 %t64, 1
  %t66 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t67 = insertvalue %"compiler/generic:Binding" %t65, { i64, ptr } %t66, 2
  %t68 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t69 = insertvalue %"compiler/generic:Binding" %t67, { i64, ptr } %t68, 3
  %t71 = insertvalue %"compiler/generic:Binding" %t69, { i64, ptr } %t60, 4
  store %"compiler/generic:Binding" %t71, ptr %rv
  br label %ret
bb14:
  call void @__olang_check_failed(ptr @olang_loc_7f889b865e0796f3_e5c04d4d88f5fb3f)
  unreachable
ret:
  %rr = load %"compiler/generic:Binding", ptr %rv
  ret %"compiler/generic:Binding" %rr
}

define dso_local void @compiler_2fgeneric_3aFnDefault_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, i64 %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l2 = alloca %"compiler/generic:Context"
  %l5 = alloca %"compiler/generic:Context"
  %l8 = alloca %"compiler/generic:Context"
  %l9 = alloca %"compiler/generic:FnDefault"
  call void @llvm.memmove.p0.p0.i64(ptr %l2, ptr %a2, i64 160, i1 false)
  br label %start
start:
  br label %bb0
bb0:
  call void @llvm.memmove.p0.p0.i64(ptr %l8, ptr %l2, i64 160, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %l5, ptr %l8, i64 160, i1 false)
  %t5 = getelementptr %"compiler/generic:FnDefault", ptr %l9, i32 0, i32 0
  store i64 %a0, ptr %t5, !tbaa !24
  %t7 = getelementptr %"compiler/generic:FnDefault", ptr %l9, i32 0, i32 1
  store ptr %a1, ptr %t7, !tbaa !29
  %t9 = getelementptr %"compiler/generic:FnDefault", ptr %l9, i32 0, i32 2
  call void @llvm.memmove.p0.p0.i64(ptr %t9, ptr %l5, i64 160, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l9, i64 176, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/generic:fnRow" @compiler_2fgeneric_3afnRow_2ector(ptr %v0, ptr %v1, i64 %a0, ptr %a1, i1 %a2) #0 {
entry:
  %rv = alloca %"compiler/generic:fnRow"
  br label %start
start:
  br label %bb0
bb0:
  %t8 = insertvalue %"compiler/generic:fnRow" undef, i64 %a0, 0
  %t10 = insertvalue %"compiler/generic:fnRow" %t8, ptr %a1, 1
  %t12 = insertvalue %"compiler/generic:fnRow" %t10, i1 %a2, 2
  store %"compiler/generic:fnRow" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/generic:fnRow", ptr %rv
  ret %"compiler/generic:fnRow" %rr
}

declare void @__olang_check_failed(ptr) cold noreturn
@__olang_empty_array = external constant [16 x i64]
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %dh = load ptr, ptr %dheadptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  %hasd = icmp ne ptr %dh, null
  %owns = or i1 %hasf, %hasd
  br i1 %owns, label %owned, label %chunks
owned:
  call void @__olang_scope_close_owned(ptr %scope)
  br label %chunks
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ; B19b: a benchmark build counts what this thread allocates - here and at the slow path's own bump, so each
  ; allocation is counted once wherever it is made (a region's and a forwarded scope's come back through here)
; @bench %bna = load i64, ptr @__olang_bench_allocs
; @bench %bna1 = add i64 %bna, 1
; @bench store i64 %bna1, ptr @__olang_bench_allocs
; @bench %bnb = load i64, ptr @__olang_bench_bytes
; @bench %bnb1 = add i64 %bnb, %size
; @bench store i64 %bnb1, ptr @__olang_bench_bytes
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare ptr @llvm.coro.promise(ptr, i32, i1)
@.d0 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I64" }>, align 8
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
@.d1 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Type" }>, align 8
@.d2 = private constant <{ i64, [60 x i8] }> <{ i64 0, [60 x i8] c"only a field, a parameter, a result or a function has a Type" }>, align 8
@.d3 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Base" }>, align 8
@.d4 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d5 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d6 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"Element" }>, align 8
@.d7 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d8 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d9 = private constant <{ i64, [56 x i8] }> <{ i64 0, [56 x i8] c"only an array, a Columns and a ColumnVec have an Element" }>, align 8
@.d10 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"Target" }>, align 8
@.d11 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d12 = private constant <{ i64, [29 x i8] }> <{ i64 0, [29 x i8] c"only a reference has a Target" }>, align 8
@.d13 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"Errors" }>, align 8
@.d14 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d15 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d16 = private constant <{ i64, [31 x i8] }> <{ i64 0, [31 x i8] c"only a function type has Errors" }>, align 8
@.d17 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d18 = private constant <{ i64, [76 x i8] }> <{ i64 0, [76 x i8] c"the defaults of two of its traits give it one; it declares its own to choose" }>, align 8
@.d19 = private constant <{ i64, [32 x i8] }> <{ i64 0, [32 x i8] c"only a function type has results" }>, align 8
@.d20 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d21 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d22 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d23 = private constant <{ i64, [50 x i8] }> <{ i64 0, [50 x i8] c"only a type a program declares has methods to walk" }>, align 8
@.d24 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d25 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d26 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d27 = private constant <{ i64, [66 x i8] }> <{ i64 0, [66 x i8] c"only a function type and a type with a constructor have parameters" }>, align 8
@.d28 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d29 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d30 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d31 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d32 = private constant <{ i64, [36 x i8] }> <{ i64 0, [36 x i8] c"only a struct and an enum have cases" }>, align 8
define available_externally ptr @__olang_scope_hold(ptr %s) alwaysinline {
entry:
  %none = icmp eq ptr %s, null
  br i1 %none, label %plain, label %look
look:
  ; atomic: on a scope that is no stand-in this word is its parts list, which other threads push onto (__olang_scope_part)
  %mp = getelementptr %olang.scope, ptr %s, i32 0, i32 4
  %m = load atomic ptr, ptr %mp monotonic, align 8
  %fresh = icmp eq ptr %m, @__olang_standin_mark
  br i1 %fresh, label %make, label %kept
kept:
  %mi = ptrtoint ptr %m to i64
  %bit = and i64 %mi, 1
  %has = icmp ne i64 %bit, 0
  br i1 %has, label %keeper, label %plain
keeper:
  %ki = and i64 %mi, -2
  %k = inttoptr i64 %ki to ptr
  ret ptr %k
make:
  %f = call ptr @__olang_standin_keeper(ptr %s)
  ret ptr %f
plain:
  ret ptr %s
}
@olang_2esole_2ecompiler__2fgeneric__2ecompiler__2fgeneric__3aProgram__2eReflItems_2elocal_2e46 = weak hidden constant i1 false
declare ptr @__olang_region_make(ptr) noinline
@.d33 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare void @__olang_region_release(ptr) noinline
@.d34 = private constant <{ i64, [71 x i8] }> <{ i64 0, [71 x i8] c"an enum's fields are its cases' - walk T.Cases, then each case's Fields" }>, align 8
@.d35 = private constant <{ i64, [44 x i8] }> <{ i64 0, [44 x i8] c"only a struct and an enum's case have fields" }>, align 8
@.d36 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2ecompiler_2fgeneric_3aProgram_2e70 = weak hidden constant i1 false
declare ptr @__olang_region_or(ptr, ptr)
declare ptr @__olang_region_home(ptr)
declare void @__olang_region_settle_in(ptr, ptr)
declare void @__olang_region_drop(ptr) noinline
@olang_2esole_2ecompiler_2fgeneric_3aAnyTable_2e5 = weak hidden constant i1 false
@olang_2esole_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3aAnyTable_3e_2e0 = weak hidden constant i1 false
@olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0 = weak hidden constant i1 false
declare void @__olang_region_release_part(ptr, i64) noinline
@olang_2esole_2ecompiler_2fgeneric_3aProgram_2e71 = weak hidden constant i1 false
@olang_2esole_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20I64_3e_2e0 = weak hidden constant i1 false
@olang_2esole_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20I64_3e_2e1 = weak hidden constant i1 false
@olang_2esole_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20I64_3e_2e2 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fast_3aVarDecl_2e0 = weak hidden constant i1 false
define available_externally noalias ptr @__olang_held_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
@olang_2esole_2ecompiler_2fast_3aVarDecl_2e1 = weak hidden constant i1 false
@.d37 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Copy" }>, align 8
@.d38 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"fn(" }>, align 8
@.d39 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"fn?(" }>, align 8
@.d40 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"fn?[" }>, align 8
@.d41 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"fn[" }>, align 8
@.d42 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"](" }>, align 8
@.d43 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"struct(" }>, align 8
@.d44 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d45 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"enum{" }>, align 8
@.d46 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d47 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d48 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"Array<" }>, align 8
@.d49 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d50 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I64" }>, align 8
@.d51 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c">" }>, align 8
@.d52 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Bool" }>, align 8
@.d53 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"default" }>, align 8
@.d54 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"noreturn" }>, align 8
@.d55 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"<" }>, align 8
@.d56 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c">" }>, align 8
@.d57 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1 = weak hidden constant i1 false
declare i64 @__olang_fmt_i64(ptr, i64)
@.d58 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c":" }>, align 8
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
@.d59 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c":" }>, align 8
@olang_2esole_2ecompiler_2fgeneric_3aFnDefault_2e2 = weak hidden constant i1 false
@olang_2esole_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compiler_2ftypes_3aTypeId_3e_2e0 = weak hidden constant i1 false
declare ptr @__olang_region_make_part(ptr) noinline
@olang_2esole_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compiler_2ftypes_3aTypeId_3e_2e1 = weak hidden constant i1 false
@olang_2esole_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compiler_2ftypes_3aTypeId_3e_2e2 = weak hidden constant i1 false
define linkonce_odr void @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2fgeneric_3aFnDefault(ptr %out, ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"compiler/generic:FnDefault"
  %l3 = alloca %"compiler/generic:Context"
  %t3 = alloca %"compiler/generic:Context", align 8
  br label %start
start:
  br label %bb0
bb0:
  call void @llvm.memmove.p0.p0.i64(ptr %l1, ptr %a0, i64 176, i1 false)
  %t2 = getelementptr %"compiler/generic:FnDefault", ptr %l1, i32 0, i32 2
  call void @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2fgeneric_3aContext(ptr %t3, ptr %v0, ptr %t2)
  call void @llvm.memmove.p0.p0.i64(ptr %l3, ptr %t3, i64 160, i1 false)
  br label %bb1
bb1:
  %t5 = getelementptr %"compiler/generic:FnDefault", ptr %l1, i32 0, i32 2
  call void @llvm.memmove.p0.p0.i64(ptr %t5, ptr %l3, i64 160, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l1, i64 176, i1 false)
  br label %ret
ret:
  ret void
}

define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_Hcd3bbe8e64537e19c3182f51d0fe16c9(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compiler_2ftypes_3aTypeId_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

@.d60 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"Array" }>, align 8
@.d61 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I64" }>, align 8
@.d62 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I64" }>, align 8
@.d63 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"noborrow" }>, align 8
@.d64 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"borrows " }>, align 8
@.d65 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"borrows" }>, align 8
@.d66 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"/main.olang" }>, align 8
declare void @__olang_errpay_pop()
@.d67 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"linux" }>, align 8
@.d68 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"x86_64" }>, align 8
@.d69 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"x86-64" }>, align 8
@olang_2esole_2ecompiler_2fload_3aLoader_2e2 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ffetch_3aFetcher_2e0 = weak hidden constant i1 false
@.d70 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"/olang.lock" }>, align 8
@olang_2esole_2ecompiler_2ffetch_3aFetcher_2e1 = weak hidden constant i1 false
@.d71 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"/cache" }>, align 8
@.d72 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"file:///nowhere/" }>, align 8
@olang_2esole_2ecompiler_2fload_3aLoader_2e3 = weak hidden constant i1 false
@.d73 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"std" }>, align 8
@olang_2esole_2ecompiler_2fload_3aModule_2e0 = weak hidden constant i1 false
@.d74 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"/main.olang" }>, align 8
@olang_2esole_2ecompiler_2fgeneric_3aBinding_2e2 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fgeneric_3aBinding_2e3 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fgeneric_3aBinding_2e4 = weak hidden constant i1 false
declare void @__olang_scope_close_owned(ptr) noinline
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
@__olang_standin_mark = external global i64
declare ptr @__olang_standin_keeper(ptr) noinline
define available_externally noalias ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  %head = load ptr, ptr %scope, !tbaa !59
  %isslot = icmp eq ptr %head, @__olang_slot_chunk
  br i1 %isslot, label %slot, label %plain
slot:
  %s = call ptr @__olang_slot_alloc(ptr %scope, i64 %rawsize)
  ret ptr %s
plain:
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
define linkonce_odr void @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2fgeneric_3aContext(ptr %out, ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"compiler/generic:Context"
  %l3 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l5 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  call void @llvm.memmove.p0.p0.i64(ptr %l1, ptr %a0, i64 160, i1 false)
  %t2 = getelementptr %"compiler/generic:Context", ptr %l1, i32 0, i32 2
  %t4 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_Ha3611e7042201d9891a66cc0e2a71916(ptr %v0, ptr %t2)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t4, ptr %l3
  br label %bb1
bb1:
  %t5 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l3
  %t6 = getelementptr %"compiler/generic:Context", ptr %l1, i32 0, i32 2
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t5, ptr %t6
  %t7 = getelementptr %"compiler/generic:Context", ptr %l1, i32 0, i32 3
  %t9 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_Ha3611e7042201d9891a66cc0e2a71916(ptr %v0, ptr %t7)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t9, ptr %l5
  br label %bb2
bb2:
  %t10 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l5
  %t11 = getelementptr %"compiler/generic:Context", ptr %l1, i32 0, i32 3
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t10, ptr %t11
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l1, i64 160, i1 false)
  br label %ret
ret:
  ret void
}

@__olang_slot_chunk = external global %olang.chunk
declare noalias ptr @__olang_slot_alloc(ptr, i64) noinline
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_Ha3611e7042201d9891a66cc0e2a71916(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %a0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 8
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 1
  %t21 = load { i64, ptr }, ptr %t20, !tbaa !27
  store { i64, ptr } %t21, ptr %l5, !tbaa !27
  %t22 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t22, 0
  store i64 %t23, ptr %l6, !tbaa !24
  %t24 = load i64, ptr %l6, !tbaa !24
  %t25 = mul i64 %t24, 8
  %t26 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t25)
  %t27 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  store { i64, ptr } %t28, ptr %l7, !tbaa !27
  %t29 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !27
  %t31 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = load i64, ptr %l6, !tbaa !24
  %t34 = mul i64 %t33, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t30, ptr %t32, i64 %t34, i1 false)
  %t35 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t36 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 1
  store { i64, ptr } %t35, ptr %t36, !tbaa !27
  %t37 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 2
  %t38 = load { i64, ptr }, ptr %t37, !tbaa !27
  store { i64, ptr } %t38, ptr %l8, !tbaa !27
  %t39 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t40 = extractvalue { i64, ptr } %t39, 0
  store i64 %t40, ptr %l9, !tbaa !24
  %t41 = load i64, ptr %l9, !tbaa !24
  %t42 = mul i64 %t41, 8
  %t43 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t42)
  %t44 = insertvalue { i64, ptr } undef, i64 %t41, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t43, 1
  store { i64, ptr } %t45, ptr %l10, !tbaa !27
  %t46 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !27
  %t48 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !27
  %t50 = load i64, ptr %l9, !tbaa !24
  %t51 = mul i64 %t50, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t47, ptr %t49, i64 %t51, i1 false)
  %t52 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t53 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 2
  store { i64, ptr } %t52, ptr %t53, !tbaa !27
  %t54 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t54, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

declare { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Array_3_H5ded0725d411df67b2648301e639bd4e(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_c2f0255997df361c_a6c9f390e9e9df68 = external constant [0 x i8]
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Array_3_H9e3d6110ebf70523261e6bda2644191a(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eallFns(ptr %v0, ptr %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3aAnySlot_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ector(ptr %v0, i64 %a0)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAnyCovers(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2etypeDecl(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_b551b6343ae0ce4b_58fdc1bfeb477ccf = external constant [0 x i8]
declare i1 @compiler_2fast_2ecompiler_2fast_3aFunc_2eIsBuilder(ptr %v0, ptr %a0)
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eHas_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ePush_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTraitSig(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2, i32 %a3)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAny(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eWritable = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ftypes_2eReadOnly = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReceiverPromises(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eWithPromises(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3aAnySlot_3e_2ePush_H53ed042998733b8f648bef68c9e795c2(ptr %v0, ptr %a0, %"compiler/generic:AnySlot" %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
@G_2ecompiler_2ftypes_2eUnknownT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
declare %"compiler/generic:fnRow" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3afnRow_3e_2eAt_3ccompiler_2fgeneric_3afnRow_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3aAnySlot_3e_2eLen__H711cec3afad496782566ddd729023773(ptr %v0, ptr %a0)
@olang_loc_98166f45573479aa_46aa63c900b34a36 = external constant [0 x i8]
declare %"compiler/generic:AnySlot" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3aAnySlot_3e_2eAt_3ccompiler_2fgeneric_3aAnySlot_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Array_3_H5c1f2db077436d08712784f933dc3852(ptr %v0, ptr %v1, ptr %a0, i32 %a1, { i64, ptr } %a2)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fgeneric_2eFnOwner(i64 %a0)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eA(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eB(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInferThroughBounds(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare %"compiler/msgs:Nearest" @compiler_2fmsgs_3aNearest_2ector(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_Hc2ccbbc5952c057a60f016e9cc1626d2(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eLen_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %a0)
declare %"compiler/names:Entry" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eAt_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2etext(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i1 @compiler_2fload_2ePublic(ptr %v0, { i64, ptr } %a0)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclFor(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2fmsgs_2ecompiler_2fmsgs_3aNearest_2eOffer(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2fmsgs_2ecompiler_2fmsgs_3aNearest_2eHint(ptr %v0, ptr %v1, ptr %a0)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eToArra_H4d02a0b2e27e8f31ffc99daa43750593(ptr %v0, ptr %v1, ptr %a0)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsColumns(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eColumnsRow(ptr %v0, ptr %a0, i32 %a1)
declare %"std/prelude/iterator:ViewGenerator.00c7c71992d6e1815cd052c47b979cdd" @compiler_2fgeneric_2eFieldDecls.walk(ptr %v0, ptr %v1, ptr %a0)
declare { i32, ptr } @std_2fprelude_2fiterator_2estd_2fprelude_2fiterator_3aViewGenerator_3ccompiler_2fast_3aV_Hf179e857cb72c72900f4614cd5df5a25(ptr %v0, ptr %a0)
@olang_loc_2a66b784d9289786_f31abe169e6a7bb2 = external constant [0 x i8]
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ereadsLocal(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare %"compiler/generic:folded" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eeval(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
@G_2ecompiler_2fgeneric_2eUnfolded = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2evarsBound(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eLengthKey(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9b83f66eba65594537030636cb0b52b7(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9162e3b7f03fcbf954b681204d5f6cca(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@G_2ecompiler_2fgeneric_2eRunTimeLength = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\80" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConst(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3aConstAsk_3e_2eLen_H192b02349624a37821a23e7def80c714(ptr %v0, ptr %a0)
declare %"compiler/generic:ConstAsk" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3aConstAsk_3e_2eAt__H3f4459851a287fa27378a94ef8fff763(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_H0e73c22773457b60eb954c2c4a2643e9(ptr %v0, ptr %a0)
@olang_loc_99cf014ebb3d252c_a323a427e7fb0b10 = external constant [0 x i8]
@olang_loc_9c491d6513909eb9_b2019bc0b634333d = external constant [0 x i8]
declare %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_Ha72624ba64524ee3315305b5d1bfb369(ptr %v0, ptr %v1, ptr %a0)
declare { i32, %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapIter_3ccompiler_2fsource_3aNameId_2c_20co_H6cf169b12565f300e9fe11f1c8d55061(ptr %v0, ptr %a0)
declare %"compiler/generic:ConstAsk" @compiler_2fgeneric_3aConstAsk_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, i64 %a0, ptr %a1, i32 %a2, i64 %a3, { i64, ptr } %a4, { i64, ptr } %a5, { i64, ptr } %a6)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3aConstAsk_3e_2ePus_H9314813d35e39659e36ddfdc05758427(ptr %v0, ptr %v1, ptr %a0, %"compiler/generic:ConstAsk" %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eUnknownConst(ptr %v0, ptr %a0)
@G_2ecompiler_2fgeneric_2eFolded = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFlows(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLayoutState(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eLaidOut = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ftypes_2eNoLayout = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ftypes_2eLayingOut = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fgeneric_2eMaxChain = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\E8\03\00\00\00\00\00\00" }>, align 8
declare void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eunbounded(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSetLayoutState(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ereprReady(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eEmbedded(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePacked(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eComputeLayout(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3amemberRow_3e_2eLe_Hffef742b46d9f4381d344302148f855f(ptr %v0, ptr %a0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2etypeKey(ptr %v0, ptr %a0, i32 %a1)
declare %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %v0, i64 %a0, i64 %a1)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H5696e1a008d256bf9453cde2b49c6c45(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare %"compiler/generic:memberRow" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3amemberRow_3e_2eAt_H0818468919c31b926123191f6718935b(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSelfType(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/generic:Unmet" @compiler_2fgeneric_2eUnmet_2emet()
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/generic:Unmet" @compiler_2fgeneric_3aUnmet_2ector(ptr %v0, i64 %a0, i32 %a1, i32 %a2, i1 %a3, i1 %a4, i1 %a5)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAnyTrait(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMember(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2edeclContext(ptr %out, ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eResolve(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare i64 @compiler_2fgeneric_2eDeclOwner(i32 %a0)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2emeetsBuilder(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2, ptr %a3)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2emeets(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2, i32 %a3, ptr %a4)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclModule(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_baaca818f0e4393a_2cd871f7f771e33e = external constant [0 x i8]
declare void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2efnsIn(ptr %v0, ptr %a0, i64 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3afnRow_3e_2eLen_3ccompiler_2fgeneric_3afnRow_3e(ptr %v0, ptr %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsUpper(i8 %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eToArray_3cI64_3e(ptr %v0, ptr %v1, ptr %a0)
declare %"compiler/generic:Desc" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDescOf(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2fgeneric_2eDescNone = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare { i32, { i64, ptr } } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDescType(ptr %v0, ptr %v1, ptr %a0, %"compiler/generic:Desc" %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eReflUnder(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrSetOf(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2fgeneric_2eDescFunc = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\05\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMemberType(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eNoMemberWhy(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@G_2ecompiler_2fgeneric_2eListResults = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResults(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@G_2ecompiler_2fgeneric_2eListFunctions = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fgeneric_2eListBuilders = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\06\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fgeneric_2eListMethods = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\05\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fgeneric_2eListParams = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCtorSig(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2fgeneric_2eListCases = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrValCodes(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eisEnumT(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCaseNames(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eisStructT(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCaseFieldNames(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i64 %a2)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %a0, i32 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3aAnyTable_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20I64_3e_2ector(ptr %v0)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsErrVar(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrSetItems(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eC(ptr %v0, ptr %a0, i32 %a1)
declare { i32, %"compiler/generic:pattern" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fgeneric_3apattern__He653b1131e20b64758f13c09ef1dc8c5(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"compiler/generic:pattern" @compiler_2fgeneric_3apattern_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, i64 %a2, i32 %a3, ptr %a4)
declare void @compiler_2fgeneric_3aContext_2ector(ptr %out, ptr %v0, i64 %a0, i64 %a1)
declare %"compiler/generic:varRow" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarAt(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_H943a9bb03970f71acf57214091669a7d(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
@olang_loc_58f0122f37ec3c06_2c6a4c04431557c2 = external constant [0 x i8]
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2esubstList(ptr %v0, ptr %a0, i32 %a1, i64 %a2, i32 %a3)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstance(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArray(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFuncTag(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2esubstErrs(ptr %v0, ptr %a0, i32 %a1, i64 %a2, i32 %a3)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopesOf(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNamesIdOf(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFuncNullable(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePromisesOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i32 %a3, i32 %a4, i64 %a5, i1 %a6, i32 %a7, i64 %a8)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eTuple(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRecord(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeNames(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeCases(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeFields(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAnonEnum(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i32 %a2, { i64, ptr } %a3)
@olang_loc_55e2d1aec6f2d594_eb547a8d425546e0 = external constant [0 x i8]
@olang_loc_c20939017dfa028a_da62df5ce2abe84e = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v0, ptr %a0)
declare %"compiler/ast:VarDecl" @compiler_2fast_3aVarDecl_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, ptr %a2, { i64, ptr } %a3, i1 %a4, i1 %a5, i1 %a6)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H6466f280e8b3243621b03e95613f722a(ptr %v0, ptr %v1, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1, ptr %a2)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2erecvKey(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, ptr %a2, { i64, ptr } %a3)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eownerApplies(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
@olang_loc_8878e002d59779fd_75c347076df58361 = external constant [0 x i8]
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2erecvApplies(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
@olang_loc_b441b4212013472a_a2c9244dd812c346 = external constant [0 x i8]
@G_2ecompiler_2ftypes_2eOwnScope = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FF\FF\FF\FF\FF\FF\FF\FF" }>, align 8
@olang_loc_aa576265ebda78ff_b2b17010594f46db = external constant [0 x i8]
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShareOf(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
@olang_loc_df1b6a3560be039c_3d298a2e16c742f8 = external constant [0 x i8]
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResultFrom(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRole(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopes(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, { i64, ptr } %a2, { i64, ptr } %a3)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H31314c4e7281f5029d6d8eb3044cef10(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1, i64 %a2)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3afnRow_3e_2ePush_3ccompiler_2fgeneric_3afnRow_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/generic:fnRow" %a1)
@olang_loc_cab99c6a514cda4c_3636b0df4624338 = external constant [0 x i8]
declare void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eMarkCopy(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_c23c218140effa50_4db4b783113412a4 = external constant [0 x i8]
@olang_loc_7e185c750e76a77d_541671d994da32b1 = external constant [0 x i8]
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2epayload(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, i32 %a3)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_Hb3133f486435530b533aaf49461c92b5(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_H64d9be73b6c9bed004c541bdf7f0ca0a(ptr %v0, ptr %a0, i32 %a1, i1 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_4f8ba0791f7285d_6734ddd6ace13789 = external constant [0 x i8]
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3acursor_2eeat(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i32, i32 } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ecanonFunc(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2, i32 %a3)
declare { i32, i32 } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ecanonType(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i32, i32 } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ecanonList(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, { i64, ptr } %a2)
declare { i32, i32 } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ecanonEnum(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i32, i64 } @compiler_2fgeneric_2ecanonNumber(ptr %v0, ptr %a0)
declare i8 @compiler_2fgeneric_2ecompiler_2fgeneric_3acursor_2epeek(ptr %v0, ptr %a0)
@olang_loc_22c778cd655270ba_6d5936a0bf98512e = external constant [0 x i8]
@G_2ecompiler_2ftypes_2eBoolT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
@G_2ecompiler_2ftypes_2eDefaultErrT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\10\00\00\00" }>, align 8
@G_2ecompiler_2ftypes_2eNoreturnT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\11\00\00\00" }>, align 8
@olang_loc_55983e17b45d1397_8723e16cd5d53a2b = external constant [0 x i8]
declare { i32, i32 } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFindDecl(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2edeclVars(ptr %v0, ptr %a0, i32 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %v0, i64 %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclParams(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eToArray_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %v1, ptr %a0)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ewrap(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
@G_2ecompiler_2fgeneric_2ePending = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare %"compiler/generic:folded" @compiler_2fgeneric_3afolded_2ector(ptr %v0, i64 %a0, i64 %a1, i32 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstExpr(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fgeneric_3apattern__Hf2f2cd44709958e8fc0de9f437e62e6b(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"compiler/generic:pattern" %a2)
@olang_loc_846e8cf19a14b6db_3af1bf273e789227 = external constant [0 x i8]
@olang_loc_7486412f18d83346_49a9869342f97632 = external constant [0 x i8]
@olang_loc_a38131017e96f420_b77c6395c7c31534 = external constant [0 x i8]
@olang_loc_693dd3c2c5a77285_e5bce5d7f9614999 = external constant [0 x i8]
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDefault(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha091d021a90ce6aa48813730c00df6d2(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i64 %a2)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fgeneric_3aFnDefaul_Heccae358bebde09a47984c7dc693f64e(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare %"compiler/generic:folded" @compiler_2fgeneric_2efolded_2eunfolded()
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ewide(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2enumberOf(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_fa05ab364d453a8b_cb1072875564fc6f = external constant [0 x i8]
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_415c77be4516d04a_7550ee8386647fae = external constant [0 x i8]
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInfer(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, ptr %a3)
declare { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_Hfd0413fe7fd4e5914f6cad5b418b7a6d(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eStorageOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2, ptr %a3)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstValue(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstType(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2efile(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ealiasStep(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare %"compiler/generic:folded" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2efoldGlobal(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare %"compiler/names:Ref" @compiler_2fnames_3aRef_2ector(ptr %v0, i32 %a0, i64 %a1, i64 %a2)
declare %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eMember(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
@olang_loc_8c7d78b449474581_137735cf7503269d = external constant [0 x i8]
@olang_loc_bfcccee69af0f127_f3360b8adb85577b = external constant [0 x i8]
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eheld(ptr %v0, ptr %a0, i32 %a1)
declare { i32, i1 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eGet_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
declare { i64, [3 x i64] } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eat(ptr %v0, ptr %a0, i64 %a1, %"compiler/source:Span" %a2)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fmsgs_2eTok(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTypeHoldsItself(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, %"compiler/diagmsg:Msg" %a2)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2emeetTyped(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
@olang_loc_536ccd1a63d69f5a_f4e0a4d3c2cbc46e = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRawType(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSetRawType(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
@olang_loc_a1c12b43cfcb5ca8_7f9e794136c316fc = external constant [0 x i8]
declare { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %v0, i32 %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePromiseTwice(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2epromiseErr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, %"compiler/diagmsg:Msg" %a3)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePromiseReturnsNoreturn(ptr %v0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePromiseBorrowsNothing(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2epromiseParam(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, ptr %a3, i64 %a4)
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eHas_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2emayHold(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePromiseBorrowsValue(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ekeepsPromise(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, ptr %a2, i32 %a3, ptr %a4, i64 %a5)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSigNames(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eWithNames(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKeepsText(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, i64 %a2, i64 %a3, i64 %a4)
@G_2ecompiler_2ftypes_2ePromNoborrow = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\80\00\00\00\00\00\00\00" }>, align 8
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePromiseBorrowsBoth(ptr %v0)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePromises(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, { i64, ptr } %a2, { i64, ptr } %a3)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSatisfies(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eExtends(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNeedsDrop(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eerrsHaveVar(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eunifyLists(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2, ptr %a3, i1 %a4)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eisVar(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eentryHeld(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ebind(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2, i32 %a3, i1 %a4, i1 %a5)
@olang_loc_de533036e7174fdb_fce805c56f435877 = external constant [0 x i8]
@olang_loc_56a9f796d6022e8a_9e3c205a980da41e = external constant [0 x i8]
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %a0)
@G_2ecompiler_2ftypes_2ePromReturns = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ftypes_2ePromNoalloc = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ftypes_2ePromNoblock = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ftypes_2ePromNospawn = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\08\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ftypes_2ePromNorecurse = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\10\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ftypes_2ePromNoextern = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\20\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ftypes_2ePromPure = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\40\00\00\00\00\00\00\00" }>, align 8
@olang_loc_5e6ea17f09d33e2_77348db42693dffe = external constant [0 x i8]
declare i32 @std_2fos_2eWriteFile(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare void @compiler_2fcond_3aConsts_2ector(ptr %out, ptr %v0)
declare void @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eBuiltins(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, i64 %a4, i64 %a5, i1 %a6, i1 %a7, i1 %a8, i64 %a9)
declare void @compiler_2ffetch_3aFetcher_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, i1 %a3, i1 %a4)
declare %"compiler/source:Names" @compiler_2fsource_3aNames_2ector(ptr %v0)
declare void @compiler_2fdiag_3aDiagnostics_2ector(ptr %out, ptr %v0, i1 %a0)
declare void @compiler_2fload_3aLoader_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, { i64, ptr } %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4)
declare i64 @compiler_2fload_2ecompiler_2fload_3aLoader_2eLoad(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_8e4da92f4f682bfd_d3a5cd4c92991ca9 = external constant [0 x i8]
@olang_loc_d2716e3b81e17ed0_f7580b05837cd1dc = external constant [0 x i8]
@olang_loc_7f889b865e0796f3_e5c04d4d88f5fb3f = external constant [0 x i8]
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compiler_2ftypes_3aTypeId_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
